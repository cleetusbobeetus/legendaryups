setblock 249 109 323 minecraft:mushroom_stem
fill 249 109 324 249 112 324 minecraft:moss_block
setblock 249 109 363 minecraft:mushroom_stem
fill 250 109 323 250 112 323 minecraft:moss_block
setblock 250 109 362 minecraft:mushroom_stem
fill 250 109 363 250 112 363 minecraft:moss_block
setblock 251 109 361 minecraft:mushroom_stem
fill 251 109 362 251 112 362 minecraft:moss_block
setblock 252 109 324 minecraft:moss_block
fill 252 109 361 252 112 361 minecraft:moss_block
setblock 254 109 323 minecraft:mushroom_stem
setblock 254 109 325 minecraft:light[level=15]
setblock 254 109 333 minecraft:light[level=15]
setblock 254 109 341 minecraft:light[level=15]
setblock 254 109 349 minecraft:light[level=15]
setblock 254 109 357 minecraft:light[level=15]
setblock 254 109 363 minecraft:mushroom_stem
fill 255 109 323 255 112 323 minecraft:moss_block
setblock 255 109 362 minecraft:mushroom_stem
fill 255 109 363 255 112 363 minecraft:moss_block
fill 256 109 362 256 110 362 minecraft:moss_block
setblock 259 109 363 minecraft:mushroom_stem
setblock 262 109 325 minecraft:light[level=15]
setblock 262 109 333 minecraft:light[level=15]
setblock 262 109 341 minecraft:light[level=15]
setblock 262 109 349 minecraft:light[level=15]
setblock 262 109 357 minecraft:light[level=15]
setblock 263 109 323 minecraft:red_mushroom_block
setblock 264 109 363 minecraft:mushroom_stem
setblock 264 109 364 minecraft:red_mushroom_block
fill 265 109 363 265 112 363 minecraft:moss_block
fill 266 109 323 266 111 323 minecraft:moss_block
fill 268 109 362 268 110 362 minecraft:moss_block
setblock 269 109 323 minecraft:mushroom_stem
fill 269 109 324 270 111 324 minecraft:moss_block
setblock 269 109 363 minecraft:mushroom_stem
fill 270 109 323 270 112 323 minecraft:moss_block
setblock 270 109 325 minecraft:light[level=15]
setblock 270 109 333 minecraft:light[level=15]
setblock 270 109 341 minecraft:light[level=15]
setblock 270 109 349 minecraft:light[level=15]
setblock 270 109 357 minecraft:light[level=15]
setblock 270 109 362 minecraft:mushroom_stem
fill 270 109 363 270 112 363 minecraft:moss_block
fill 271 109 362 271 112 362 minecraft:moss_block
setblock 272 109 324 minecraft:moss_block
setblock 273 109 324 minecraft:mushroom_stem
setblock 274 109 323 minecraft:mushroom_stem
fill 274 109 324 275 111 324 minecraft:moss_block
setblock 274 109 338 minecraft:mushroom_stem
fill 274 109 339 274 110 339 minecraft:moss_block
setblock 274 109 343 minecraft:mushroom_stem
setblock 274 109 363 minecraft:mushroom_stem
fill 275 109 323 275 112 323 minecraft:moss_block
setblock 275 109 337 minecraft:mushroom_stem
fill 275 109 338 275 112 338 minecraft:moss_block
setblock 275 109 342 minecraft:mushroom_stem
fill 275 109 343 275 112 343 minecraft:moss_block
fill 275 109 363 275 112 363 minecraft:moss_block
setblock 276 109 326 minecraft:mushroom_stem
fill 276 109 327 276 110 329 minecraft:moss_block
fill 276 109 332 276 112 332 minecraft:moss_block
setblock 276 109 336 minecraft:mushroom_stem
fill 276 109 337 276 112 337 minecraft:moss_block
setblock 276 109 341 minecraft:mushroom_stem
fill 276 109 342 276 112 342 minecraft:moss_block
setblock 276 109 346 minecraft:mushroom_stem
setblock 276 109 354 minecraft:red_mushroom_block
fill 276 109 362 276 112 362 minecraft:moss_block
fill 235 110 351 235 147 351 minecraft:brown_terracotta
fill 236 110 323 237 110 323 minecraft:moss_block
setblock 236 110 325 minecraft:mushroom_stem
fill 236 110 326 236 113 326 minecraft:moss_block
setblock 236 110 338 minecraft:red_mushroom_block
setblock 236 110 340 minecraft:mushroom_stem
fill 236 110 341 236 111 341 minecraft:moss_block
setblock 236 110 357 minecraft:red_mushroom_block
setblock 236 110 360 minecraft:mushroom_stem
fill 236 110 361 236 113 361 minecraft:moss_block
setblock 237 110 324 minecraft:mushroom_stem
fill 237 110 325 237 113 325 minecraft:moss_block
setblock 237 110 363 minecraft:moss_block
setblock 238 110 323 minecraft:mushroom_stem
fill 238 110 324 239 112 324 minecraft:moss_block
setblock 238 110 363 minecraft:mushroom_stem
fill 239 110 323 239 113 323 minecraft:moss_block
fill 239 110 363 239 113 363 minecraft:moss_block
fill 240 110 362 240 113 362 minecraft:moss_block
setblock 241 110 324 minecraft:moss_block
setblock 242 110 324 minecraft:mushroom_stem
setblock 243 110 323 minecraft:mushroom_stem
fill 243 110 324 243 113 324 minecraft:moss_block
setblock 243 110 363 minecraft:mushroom_stem
fill 244 110 323 244 113 323 minecraft:moss_block
setblock 244 110 361 minecraft:moss_block
setblock 244 110 362 minecraft:mushroom_stem
fill 244 110 363 244 113 363 minecraft:moss_block
setblock 245 110 361 minecraft:mushroom_stem
fill 245 110 362 245 113 362 minecraft:moss_block
fill 246 110 361 246 113 361 minecraft:moss_block
setblock 247 110 324 minecraft:mushroom_stem
setblock 248 110 323 minecraft:mushroom_stem
fill 248 110 324 248 113 324 minecraft:moss_block
setblock 248 110 363 minecraft:mushroom_stem
fill 249 110 323 249 113 323 minecraft:moss_block
fill 249 110 360 249 111 360 minecraft:moss_block
setblock 249 110 362 minecraft:mushroom_stem
fill 249 110 363 249 113 363 minecraft:moss_block
setblock 250 110 361 minecraft:mushroom_stem
fill 250 110 362 250 113 362 minecraft:moss_block
fill 251 110 361 251 113 361 minecraft:moss_block
setblock 252 110 324 minecraft:mushroom_stem
setblock 253 110 323 minecraft:mushroom_stem
setblock 253 110 363 minecraft:mushroom_stem
fill 254 110 323 254 113 323 minecraft:moss_block
setblock 254 110 362 minecraft:mushroom_stem
fill 254 110 363 254 113 363 minecraft:moss_block
fill 255 110 362 255 112 362 minecraft:moss_block
setblock 257 110 323 minecraft:red_mushroom_block
setblock 258 110 363 minecraft:mushroom_stem
fill 259 110 363 260 112 363 minecraft:moss_block
setblock 262 110 363 minecraft:moss_block
setblock 263 110 363 minecraft:mushroom_stem
fill 264 110 323 265 112 323 minecraft:moss_block
fill 264 110 363 264 113 363 minecraft:moss_block
fill 264 110 364 264 147 364 minecraft:brown_terracotta
setblock 267 110 324 minecraft:mushroom_stem
fill 267 110 362 267 111 362 minecraft:moss_block
setblock 268 110 323 minecraft:mushroom_stem
fill 268 110 324 268 113 324 minecraft:moss_block
setblock 268 110 363 minecraft:mushroom_stem
fill 269 110 323 269 113 323 minecraft:moss_block
setblock 269 110 362 minecraft:mushroom_stem
fill 269 110 363 269 113 363 minecraft:moss_block
fill 270 110 362 270 113 362 minecraft:moss_block
setblock 272 110 324 minecraft:mushroom_stem
setblock 273 110 323 minecraft:mushroom_stem
fill 273 110 324 273 113 324 minecraft:moss_block
setblock 273 110 363 minecraft:mushroom_stem
fill 274 110 323 274 113 323 minecraft:moss_block
setblock 274 110 342 minecraft:mushroom_stem
fill 274 110 343 274 112 343 minecraft:moss_block
fill 274 110 363 274 113 363 minecraft:moss_block
setblock 275 110 325 minecraft:moss_block
setblock 275 110 326 minecraft:mushroom_stem
setblock 275 110 336 minecraft:mushroom_stem
fill 275 110 337 275 111 337 minecraft:moss_block
setblock 275 110 341 minecraft:mushroom_stem
fill 275 110 342 275 113 342 minecraft:moss_block
setblock 276 110 325 minecraft:mushroom_stem
fill 276 110 326 276 113 326 minecraft:moss_block
setblock 276 110 330 minecraft:mushroom_stem
fill 276 110 331 276 113 331 minecraft:moss_block
setblock 276 110 335 minecraft:mushroom_stem
fill 276 110 336 276 113 336 minecraft:moss_block
setblock 276 110 340 minecraft:mushroom_stem
fill 276 110 341 276 113 341 minecraft:moss_block
setblock 276 110 345 minecraft:mushroom_stem
fill 276 110 346 276 113 346 minecraft:moss_block
setblock 276 110 348 minecraft:red_mushroom_block
setblock 236 111 323 minecraft:moss_block
setblock 236 111 324 minecraft:mushroom_stem
fill 236 111 325 236 114 325 minecraft:moss_block
setblock 236 111 329 minecraft:mushroom_stem
setblock 236 111 344 minecraft:mushroom_stem
fill 236 111 360 236 113 360 minecraft:moss_block
setblock 237 111 323 minecraft:mushroom_stem
fill 237 111 324 237 114 324 minecraft:moss_block
setblock 237 111 363 minecraft:mushroom_stem
fill 238 111 323 238 114 323 minecraft:moss_block
setblock 238 111 325 minecraft:light[level=12]
setblock 238 111 332 minecraft:light[level=12]
setblock 238 111 339 minecraft:light[level=12]
setblock 238 111 346 minecraft:light[level=12]
setblock 238 111 353 minecraft:light[level=12]
setblock 238 111 360 minecraft:light[level=12]
fill 238 111 363 238 114 363 minecraft:moss_block
fill 239 111 362 239 114 362 minecraft:moss_block
setblock 240 111 324 minecraft:moss_block
setblock 241 111 324 minecraft:mushroom_stem
setblock 242 111 323 minecraft:mushroom_stem
fill 242 111 324 242 114 324 minecraft:moss_block
setblock 242 111 363 minecraft:mushroom_stem
fill 243 111 323 243 114 323 minecraft:moss_block
setblock 243 111 362 minecraft:mushroom_stem
fill 243 111 363 243 114 363 minecraft:moss_block
setblock 244 111 361 minecraft:mushroom_stem
fill 244 111 362 244 114 362 minecraft:moss_block
setblock 245 111 325 minecraft:light[level=12]
setblock 245 111 332 minecraft:light[level=12]
setblock 245 111 339 minecraft:light[level=12]
setblock 245 111 346 minecraft:light[level=12]
setblock 245 111 353 minecraft:light[level=12]
setblock 245 111 360 minecraft:light[level=12]
fill 245 111 361 245 114 361 minecraft:moss_block
setblock 246 111 323 minecraft:moss_block
setblock 246 111 324 minecraft:mushroom_stem
fill 246 111 325 248 112 325 minecraft:moss_block
setblock 247 111 323 minecraft:mushroom_stem
fill 247 111 324 247 114 324 minecraft:moss_block
setblock 247 111 363 minecraft:mushroom_stem
fill 248 111 323 248 114 323 minecraft:moss_block
fill 248 111 360 248 112 360 minecraft:moss_block
setblock 248 111 362 minecraft:mushroom_stem
fill 248 111 363 248 114 363 minecraft:moss_block
fill 249 111 322 255 136 322 minecraft:brown_terracotta
setblock 249 111 361 minecraft:mushroom_stem
fill 249 111 362 249 114 362 minecraft:moss_block
fill 250 111 361 250 114 361 minecraft:moss_block
setblock 251 111 324 minecraft:mushroom_stem
setblock 252 111 323 minecraft:mushroom_stem
fill 252 111 324 253 113 324 minecraft:moss_block
setblock 252 111 325 minecraft:light[level=12]
setblock 252 111 332 minecraft:light[level=12]
setblock 252 111 339 minecraft:light[level=12]
setblock 252 111 346 minecraft:light[level=12]
setblock 252 111 353 minecraft:light[level=12]
setblock 252 111 360 minecraft:light[level=12]
setblock 252 111 363 minecraft:mushroom_stem
fill 253 111 323 253 114 323 minecraft:moss_block
setblock 253 111 362 minecraft:mushroom_stem
fill 253 111 363 253 114 363 minecraft:moss_block
fill 254 111 362 254 113 362 minecraft:moss_block
setblock 256 111 322 minecraft:shroomlight
setblock 256 111 323 minecraft:moss_block
fill 257 111 322 259 122 322 minecraft:brown_terracotta
setblock 257 111 363 minecraft:mushroom_stem
fill 258 111 363 258 114 363 minecraft:moss_block
setblock 259 111 325 minecraft:light[level=12]
setblock 259 111 332 minecraft:light[level=12]
setblock 259 111 339 minecraft:light[level=12]
setblock 259 111 346 minecraft:light[level=12]
setblock 259 111 353 minecraft:light[level=12]
setblock 259 111 360 minecraft:light[level=12]
setblock 261 111 363 minecraft:moss_block
setblock 262 111 363 minecraft:mushroom_stem
fill 263 111 323 263 114 323 minecraft:moss_block
fill 263 111 363 263 114 363 minecraft:moss_block
setblock 265 111 324 minecraft:moss_block
setblock 266 111 324 minecraft:mushroom_stem
setblock 266 111 325 minecraft:light[level=12]
setblock 266 111 332 minecraft:light[level=12]
setblock 266 111 339 minecraft:light[level=12]
setblock 266 111 346 minecraft:light[level=12]
setblock 266 111 353 minecraft:light[level=12]
setblock 266 111 360 minecraft:light[level=12]
fill 266 111 362 266 112 362 minecraft:moss_block
setblock 267 111 323 minecraft:mushroom_stem
fill 267 111 324 267 114 324 minecraft:moss_block
setblock 267 111 363 minecraft:mushroom_stem
fill 268 111 323 268 114 323 minecraft:moss_block
setblock 268 111 360 minecraft:shroomlight
setblock 268 111 362 minecraft:mushroom_stem
fill 268 111 363 268 114 363 minecraft:moss_block
setblock 269 111 325 minecraft:moss_block
fill 269 111 362 269 114 362 minecraft:moss_block
setblock 270 111 325 minecraft:mushroom_stem
setblock 271 111 323 minecraft:moss_block
setblock 271 111 324 minecraft:mushroom_stem
fill 271 111 325 273 112 325 minecraft:moss_block
setblock 272 111 323 minecraft:mushroom_stem
fill 272 111 324 272 114 324 minecraft:moss_block
setblock 272 111 363 minecraft:mushroom_stem
fill 273 111 323 273 114 323 minecraft:moss_block
setblock 273 111 332 minecraft:light[level=12]
setblock 273 111 339 minecraft:light[level=12]
setblock 273 111 353 minecraft:light[level=12]
setblock 273 111 360 minecraft:light[level=12]
fill 273 111 363 273 114 363 minecraft:moss_block
setblock 274 111 341 minecraft:mushroom_stem
fill 274 111 342 274 112 342 minecraft:moss_block
setblock 274 111 344 minecraft:moss_block
setblock 275 111 325 minecraft:mushroom_stem
fill 275 111 326 275 113 327 minecraft:moss_block
setblock 275 111 340 minecraft:mushroom_stem
fill 275 111 341 275 113 341 minecraft:moss_block
setblock 275 111 345 minecraft:mushroom_stem
setblock 276 111 324 minecraft:mushroom_stem
fill 276 111 325 276 114 325 minecraft:moss_block
fill 276 111 327 276 111 328 minecraft:moss_block
setblock 276 111 329 minecraft:mushroom_stem
fill 276 111 330 276 114 330 minecraft:moss_block
setblock 276 111 334 minecraft:mushroom_stem
fill 276 111 335 276 113 335 minecraft:moss_block
setblock 276 111 339 minecraft:mushroom_stem
fill 276 111 340 276 114 340 minecraft:moss_block
setblock 276 111 344 minecraft:mushroom_stem
fill 276 111 345 276 114 345 minecraft:moss_block
fill 276 111 347 276 112 347 minecraft:moss_block
fill 277 111 323 277 120 327 minecraft:brown_terracotta
setblock 277 111 328 minecraft:shroomlight
fill 277 111 329 277 147 329 minecraft:brown_terracotta
fill 235 112 339 235 144 344 minecraft:brown_terracotta
setblock 235 112 345 minecraft:shroomlight
fill 235 112 346 235 114 349 minecraft:brown_terracotta
setblock 236 112 323 minecraft:mushroom_stem
fill 236 112 324 236 115 324 minecraft:moss_block
setblock 236 112 327 minecraft:moss_block
setblock 236 112 328 minecraft:mushroom_stem
fill 236 112 329 236 115 329 minecraft:moss_block
setblock 236 112 343 minecraft:mushroom_stem
fill 236 112 344 236 114 344 minecraft:moss_block
setblock 236 112 350 minecraft:red_mushroom_block
setblock 236 112 362 minecraft:moss_block
setblock 236 112 363 minecraft:mushroom_stem
fill 237 112 323 237 115 323 minecraft:moss_block
setblock 237 112 326 minecraft:moss_block
fill 237 112 363 237 115 363 minecraft:moss_block
fill 238 112 362 238 114 362 minecraft:moss_block
setblock 240 112 324 minecraft:mushroom_stem
setblock 241 112 323 minecraft:mushroom_stem
fill 241 112 324 241 115 324 minecraft:moss_block
setblock 241 112 363 minecraft:mushroom_stem
fill 242 112 323 242 115 323 minecraft:moss_block
setblock 242 112 362 minecraft:mushroom_stem
fill 242 112 363 242 115 363 minecraft:moss_block
setblock 243 112 361 minecraft:mushroom_stem
fill 243 112 362 243 115 362 minecraft:moss_block
setblock 244 112 324 minecraft:moss_block
setblock 244 112 325 minecraft:mushroom_stem
fill 244 112 361 244 115 361 minecraft:moss_block
setblock 245 112 324 minecraft:mushroom_stem
fill 245 112 325 245 115 325 minecraft:moss_block
setblock 246 112 323 minecraft:mushroom_stem
fill 246 112 324 246 115 324 minecraft:moss_block
setblock 246 112 363 minecraft:mushroom_stem
fill 247 112 323 247 115 323 minecraft:moss_block
setblock 247 112 362 minecraft:mushroom_stem
fill 247 112 363 247 115 363 minecraft:moss_block
setblock 248 112 361 minecraft:mushroom_stem
fill 248 112 362 248 115 362 minecraft:moss_block
setblock 249 112 325 minecraft:mushroom_stem
fill 249 112 361 249 115 361 minecraft:moss_block
setblock 250 112 324 minecraft:mushroom_stem
fill 250 112 325 250 114 325 minecraft:moss_block
setblock 251 112 323 minecraft:mushroom_stem
fill 251 112 324 251 115 324 minecraft:moss_block
setblock 251 112 363 minecraft:mushroom_stem
fill 252 112 323 252 115 323 minecraft:moss_block
setblock 252 112 362 minecraft:mushroom_stem
fill 252 112 363 252 115 363 minecraft:moss_block
fill 253 112 362 253 114 362 minecraft:moss_block
fill 256 112 322 256 144 322 minecraft:brown_terracotta
setblock 256 112 323 minecraft:mushroom_stem
setblock 256 112 363 minecraft:mushroom_stem
fill 257 112 363 257 114 363 minecraft:moss_block
setblock 261 112 323 minecraft:mushroom_stem
setblock 261 112 363 minecraft:mushroom_stem
fill 262 112 323 262 115 323 minecraft:moss_block
fill 262 112 363 262 115 363 minecraft:moss_block
setblock 264 112 324 minecraft:moss_block
setblock 265 112 324 minecraft:mushroom_stem
setblock 266 112 323 minecraft:mushroom_stem
fill 266 112 324 266 115 324 minecraft:moss_block
setblock 266 112 363 minecraft:mushroom_stem
fill 267 112 323 267 115 323 minecraft:moss_block
fill 267 112 325 268 112 325 minecraft:moss_block
setblock 267 112 362 minecraft:mushroom_stem
fill 267 112 363 267 115 363 minecraft:moss_block
fill 268 112 360 268 116 360 minecraft:mushroom_stem
fill 268 112 362 268 114 362 minecraft:moss_block
setblock 269 112 324 minecraft:moss_block
setblock 269 112 325 minecraft:mushroom_stem
setblock 270 112 324 minecraft:mushroom_stem
fill 270 112 325 270 115 325 minecraft:moss_block
setblock 271 112 323 minecraft:mushroom_stem
fill 271 112 324 271 115 324 minecraft:moss_block
setblock 271 112 363 minecraft:mushroom_stem
fill 272 112 323 272 115 323 minecraft:moss_block
fill 272 112 363 272 115 363 minecraft:moss_block
setblock 274 112 324 minecraft:moss_block
setblock 274 112 325 minecraft:mushroom_stem
setblock 274 112 341 minecraft:moss_block
setblock 275 112 324 minecraft:mushroom_stem
fill 275 112 325 275 115 325 minecraft:moss_block
setblock 275 112 328 minecraft:moss_block
setblock 275 112 329 minecraft:mushroom_stem
setblock 275 112 339 minecraft:mushroom_stem
fill 275 112 340 275 113 340 minecraft:moss_block
setblock 275 112 344 minecraft:mushroom_stem
fill 275 112 345 275 113 346 minecraft:moss_block
setblock 276 112 323 minecraft:mushroom_stem
fill 276 112 324 276 115 324 minecraft:moss_block
setblock 276 112 327 minecraft:moss_block
setblock 276 112 328 minecraft:mushroom_stem
fill 276 112 329 276 115 329 minecraft:moss_block
setblock 276 112 333 minecraft:mushroom_stem
fill 276 112 334 276 113 334 minecraft:moss_block
setblock 276 112 338 minecraft:mushroom_stem
fill 276 112 339 276 114 339 minecraft:moss_block
setblock 276 112 343 minecraft:mushroom_stem
fill 276 112 344 276 115 344 minecraft:moss_block
setblock 276 112 361 minecraft:red_mushroom_block
setblock 276 112 363 minecraft:mushroom_stem
fill 277 112 328 277 148 328 minecraft:brown_terracotta
fill 235 113 328 235 147 329 minecraft:brown_terracotta
setblock 235 113 330 minecraft:red_mushroom_block
fill 235 113 331 235 144 332 minecraft:brown_terracotta
fill 235 113 345 235 147 345 minecraft:brown_terracotta
fill 236 113 323 236 116 323 minecraft:moss_block
setblock 236 113 327 minecraft:mushroom_stem
fill 236 113 328 236 116 328 minecraft:moss_block
fill 236 113 330 236 114 330 minecraft:moss_block
setblock 236 113 331 minecraft:red_mushroom_block
setblock 236 113 343 minecraft:moss_block
fill 236 113 345 236 113 346 minecraft:moss_block
setblock 236 113 356 minecraft:red_mushroom_block
setblock 236 113 362 minecraft:mushroom_stem
fill 236 113 363 236 116 363 minecraft:moss_block
setblock 237 113 326 minecraft:mushroom_stem
fill 237 113 327 237 116 327 minecraft:moss_block
setblock 238 113 324 minecraft:moss_block
fill 239 113 322 244 123 322 minecraft:brown_terracotta
setblock 239 113 324 minecraft:mushroom_stem
setblock 240 113 323 minecraft:mushroom_stem
fill 240 113 324 240 116 324 minecraft:moss_block
setblock 240 113 363 minecraft:mushroom_stem
fill 241 113 323 241 116 323 minecraft:moss_block
setblock 241 113 362 minecraft:mushroom_stem
fill 241 113 363 241 116 363 minecraft:moss_block
setblock 242 113 325 minecraft:moss_block
fill 242 113 362 242 116 362 minecraft:moss_block
setblock 243 113 325 minecraft:mushroom_stem
fill 243 113 361 243 116 361 minecraft:moss_block
setblock 244 113 324 minecraft:mushroom_stem
fill 244 113 325 244 116 325 minecraft:moss_block
setblock 245 113 322 minecraft:shroomlight
setblock 245 113 323 minecraft:mushroom_stem
fill 245 113 324 245 116 324 minecraft:moss_block
setblock 245 113 363 minecraft:mushroom_stem
fill 246 113 322 247 142 322 minecraft:brown_terracotta
fill 246 113 323 246 116 323 minecraft:moss_block
fill 246 113 325 247 113 325 minecraft:moss_block
setblock 246 113 362 minecraft:mushroom_stem
fill 246 113 363 246 116 363 minecraft:moss_block
setblock 247 113 361 minecraft:mushroom_stem
fill 247 113 362 247 116 362 minecraft:moss_block
setblock 248 113 325 minecraft:mushroom_stem
fill 248 113 361 248 116 361 minecraft:moss_block
setblock 249 113 324 minecraft:mushroom_stem
fill 249 113 325 249 115 325 minecraft:moss_block
setblock 250 113 323 minecraft:mushroom_stem
fill 250 113 324 250 116 324 minecraft:moss_block
setblock 250 113 363 minecraft:mushroom_stem
fill 251 113 323 251 116 323 minecraft:moss_block
setblock 251 113 362 minecraft:mushroom_stem
fill 251 113 363 251 116 363 minecraft:moss_block
setblock 252 113 361 minecraft:mushroom_stem
fill 252 113 362 252 115 362 minecraft:moss_block
fill 254 113 364 256 121 364 minecraft:brown_terracotta
setblock 255 113 323 minecraft:mushroom_stem
setblock 255 113 363 minecraft:mushroom_stem
fill 256 113 323 257 114 323 minecraft:moss_block
fill 256 113 363 256 114 363 minecraft:moss_block
setblock 257 113 364 minecraft:shroomlight
fill 258 113 364 260 130 364 minecraft:brown_terracotta
setblock 259 113 323 minecraft:moss_block
setblock 259 113 363 minecraft:moss_block
setblock 260 113 323 minecraft:mushroom_stem
setblock 260 113 363 minecraft:mushroom_stem
fill 261 113 323 261 116 323 minecraft:moss_block
fill 261 113 363 261 115 363 minecraft:moss_block
setblock 263 113 324 minecraft:moss_block
setblock 264 113 323 minecraft:moss_block
setblock 264 113 324 minecraft:mushroom_stem
setblock 265 113 323 minecraft:mushroom_stem
fill 265 113 324 265 115 325 minecraft:moss_block
setblock 265 113 362 minecraft:moss_block
setblock 265 113 363 minecraft:mushroom_stem
fill 266 113 323 266 116 323 minecraft:moss_block
fill 266 113 325 267 113 325 minecraft:moss_block
setblock 266 113 362 minecraft:mushroom_stem
fill 266 113 363 266 116 363 minecraft:moss_block
fill 267 113 362 267 115 362 minecraft:moss_block
setblock 268 113 325 minecraft:mushroom_stem
setblock 269 113 324 minecraft:mushroom_stem
fill 269 113 325 269 116 325 minecraft:moss_block
setblock 270 113 323 minecraft:mushroom_stem
fill 270 113 324 270 116 324 minecraft:moss_block
setblock 270 113 363 minecraft:mushroom_stem
fill 271 113 323 271 116 323 minecraft:moss_block
fill 271 113 325 272 113 325 minecraft:moss_block
setblock 271 113 362 minecraft:mushroom_stem
fill 271 113 363 271 116 363 minecraft:moss_block
setblock 273 113 325 minecraft:mushroom_stem
setblock 274 113 322 minecraft:red_mushroom_block
setblock 274 113 324 minecraft:mushroom_stem
fill 274 113 325 274 114 327 minecraft:moss_block
setblock 275 113 323 minecraft:mushroom_stem
fill 275 113 324 275 116 324 minecraft:moss_block
setblock 275 113 328 minecraft:mushroom_stem
fill 275 113 329 275 115 330 minecraft:moss_block
setblock 275 113 343 minecraft:mushroom_stem
fill 275 113 344 275 114 344 minecraft:moss_block
setblock 275 113 363 minecraft:mushroom_stem
fill 276 113 323 276 116 323 minecraft:moss_block
setblock 276 113 327 minecraft:mushroom_stem
fill 276 113 328 276 116 328 minecraft:moss_block
setblock 276 113 332 minecraft:mushroom_stem
fill 276 113 333 276 116 333 minecraft:moss_block
setblock 276 113 337 minecraft:mushroom_stem
fill 276 113 338 276 114 338 minecraft:moss_block
setblock 276 113 342 minecraft:mushroom_stem
fill 276 113 343 276 116 343 minecraft:moss_block
setblock 276 113 347 minecraft:mushroom_stem
fill 276 113 348 276 116 348 minecraft:moss_block
setblock 276 113 355 minecraft:red_mushroom_block
fill 276 113 363 276 114 363 minecraft:moss_block
fill 277 113 336 277 130 336 minecraft:brown_terracotta
setblock 277 113 337 minecraft:shroomlight
fill 235 114 330 235 147 330 minecraft:brown_terracotta
setblock 236 114 326 minecraft:mushroom_stem
fill 236 114 327 236 117 327 minecraft:moss_block
setblock 236 114 337 minecraft:red_mushroom_block
setblock 236 114 345 minecraft:moss_block
setblock 236 114 346 minecraft:mushroom_stem
fill 236 114 347 236 116 347 minecraft:moss_block
setblock 236 114 361 minecraft:mushroom_stem
fill 236 114 362 236 117 362 minecraft:moss_block
setblock 237 114 325 minecraft:mushroom_stem
fill 237 114 326 237 117 326 minecraft:moss_block
setblock 238 114 324 minecraft:mushroom_stem
setblock 239 114 323 minecraft:mushroom_stem
fill 239 114 324 239 117 324 minecraft:moss_block
setblock 239 114 363 minecraft:mushroom_stem
fill 240 114 323 240 117 323 minecraft:moss_block
fill 240 114 325 241 114 325 minecraft:moss_block
setblock 240 114 362 minecraft:mushroom_stem
fill 240 114 363 240 117 363 minecraft:moss_block
fill 241 114 362 241 117 362 minecraft:moss_block
setblock 242 114 325 minecraft:mushroom_stem
setblock 243 114 324 minecraft:mushroom_stem
fill 243 114 325 243 117 325 minecraft:moss_block
setblock 244 114 323 minecraft:mushroom_stem
fill 244 114 324 244 117 324 minecraft:moss_block
fill 244 114 356 245 117 360 minecraft:red_mushroom_block
setblock 244 114 363 minecraft:mushroom_stem
fill 245 114 322 245 147 322 minecraft:brown_terracotta
fill 245 114 323 245 117 323 minecraft:moss_block
setblock 245 114 362 minecraft:mushroom_stem
fill 245 114 363 245 117 363 minecraft:moss_block
setblock 246 114 325 minecraft:moss_block
fill 246 114 356 248 117 357 minecraft:red_mushroom_block
setblock 246 114 358 minecraft:mushroom_stem
fill 246 114 359 248 117 360 minecraft:red_mushroom_block
setblock 246 114 361 minecraft:mushroom_stem
fill 246 114 362 246 117 362 minecraft:moss_block
setblock 247 114 325 minecraft:mushroom_stem
fill 247 114 358 248 117 358 minecraft:red_mushroom_block
fill 247 114 361 247 116 361 minecraft:moss_block
setblock 248 114 324 minecraft:mushroom_stem
fill 248 114 325 248 116 325 minecraft:moss_block
setblock 249 114 323 minecraft:mushroom_stem
fill 249 114 324 249 117 324 minecraft:moss_block
setblock 249 114 363 minecraft:mushroom_stem
fill 250 114 323 250 117 323 minecraft:moss_block
setblock 250 114 362 minecraft:mushroom_stem
fill 250 114 363 250 117 363 minecraft:moss_block
setblock 251 114 361 minecraft:mushroom_stem
fill 251 114 362 251 116 362 minecraft:moss_block
setblock 252 114 324 minecraft:moss_block
setblock 253 114 324 minecraft:mushroom_stem
setblock 254 114 323 minecraft:mushroom_stem
setblock 254 114 363 minecraft:mushroom_stem
fill 255 114 323 255 115 323 minecraft:moss_block
fill 255 114 363 255 115 363 minecraft:moss_block
fill 257 114 364 257 144 364 minecraft:brown_terracotta
setblock 258 114 323 minecraft:moss_block
setblock 259 114 323 minecraft:mushroom_stem
setblock 259 114 363 minecraft:mushroom_stem
fill 260 114 323 260 117 323 minecraft:moss_block
setblock 260 114 363 minecraft:moss_block
setblock 262 114 324 minecraft:moss_block
setblock 263 114 324 minecraft:mushroom_stem
setblock 264 114 323 minecraft:mushroom_stem
fill 264 114 324 264 116 325 minecraft:moss_block
setblock 264 114 363 minecraft:mushroom_stem
fill 265 114 323 265 117 323 minecraft:moss_block
setblock 265 114 362 minecraft:mushroom_stem
fill 265 114 363 265 117 363 minecraft:moss_block
setblock 266 114 325 minecraft:moss_block
setblock 266 114 362 minecraft:moss_block
setblock 267 114 325 minecraft:mushroom_stem
fill 267 114 326 270 114 326 minecraft:moss_block
setblock 268 114 324 minecraft:mushroom_stem
fill 268 114 325 268 117 325 minecraft:moss_block
setblock 269 114 323 minecraft:mushroom_stem
fill 269 114 324 269 117 324 minecraft:moss_block
setblock 269 114 363 minecraft:mushroom_stem
fill 270 114 323 270 117 323 minecraft:moss_block
fill 270 114 363 270 117 363 minecraft:moss_block
setblock 271 114 325 minecraft:moss_block
setblock 271 114 326 minecraft:mushroom_stem
setblock 272 114 325 minecraft:mushroom_stem
setblock 273 114 324 minecraft:mushroom_stem
fill 273 114 325 273 117 325 minecraft:moss_block
fill 274 114 322 274 147 322 minecraft:brown_terracotta
setblock 274 114 323 minecraft:mushroom_stem
fill 274 114 324 274 117 324 minecraft:moss_block
setblock 274 114 363 minecraft:mushroom_stem
fill 275 114 323 275 117 323 minecraft:moss_block
setblock 275 114 326 minecraft:moss_block
setblock 275 114 327 minecraft:mushroom_stem
fill 275 114 328 275 117 328 minecraft:moss_block
setblock 275 114 342 minecraft:mushroom_stem
setblock 275 114 343 minecraft:moss_block
setblock 275 114 345 minecraft:moss_block
fill 275 114 346 276 114 346 minecraft:mushroom_stem
fill 275 114 363 275 115 363 minecraft:moss_block
setblock 276 114 326 minecraft:mushroom_stem
fill 276 114 327 276 117 327 minecraft:moss_block
setblock 276 114 331 minecraft:mushroom_stem
fill 276 114 332 276 117 332 minecraft:moss_block
setblock 276 114 341 minecraft:mushroom_stem
fill 276 114 342 276 115 342 minecraft:moss_block
fill 276 114 347 276 116 347 minecraft:moss_block
setblock 276 114 349 minecraft:red_mushroom_block
fill 277 114 337 277 147 337 minecraft:brown_terracotta
fill 235 115 346 235 147 348 minecraft:brown_terracotta
setblock 235 115 349 minecraft:red_mushroom_block
setblock 236 115 325 minecraft:mushroom_stem
fill 236 115 326 236 118 326 minecraft:moss_block
setblock 236 115 330 minecraft:mushroom_stem
setblock 236 115 343 minecraft:red_mushroom_block
setblock 236 115 346 minecraft:moss_block
setblock 236 115 361 minecraft:moss_block
setblock 237 115 324 minecraft:mushroom_stem
fill 237 115 325 237 118 325 minecraft:moss_block
setblock 237 115 328 minecraft:moss_block
setblock 238 115 323 minecraft:mushroom_stem
fill 238 115 324 238 118 324 minecraft:moss_block
setblock 238 115 363 minecraft:mushroom_stem
fill 239 115 323 239 118 323 minecraft:moss_block
fill 239 115 325 240 115 325 minecraft:moss_block
setblock 239 115 362 minecraft:mushroom_stem
fill 239 115 363 239 118 363 minecraft:moss_block
fill 240 115 362 240 117 362 minecraft:moss_block
setblock 241 115 325 minecraft:mushroom_stem
setblock 242 115 324 minecraft:mushroom_stem
fill 242 115 325 242 118 325 minecraft:moss_block
setblock 243 115 323 minecraft:mushroom_stem
fill 243 115 324 243 118 324 minecraft:moss_block
fill 243 115 357 243 116 359 minecraft:red_mushroom_block
setblock 243 115 363 minecraft:mushroom_stem
fill 244 115 323 244 118 323 minecraft:moss_block
setblock 244 115 362 minecraft:mushroom_stem
fill 244 115 363 244 118 363 minecraft:moss_block
fill 245 115 355 247 116 355 minecraft:red_mushroom_block
setblock 245 115 361 minecraft:mushroom_stem
fill 245 115 362 245 118 362 minecraft:moss_block
setblock 246 115 325 minecraft:mushroom_stem
fill 246 115 358 246 118 358 minecraft:red_mushroom_block
fill 246 115 361 246 117 361 minecraft:moss_block
setblock 247 115 324 minecraft:mushroom_stem
fill 247 115 325 247 117 325 minecraft:moss_block
setblock 248 115 323 minecraft:mushroom_stem
fill 248 115 324 248 118 324 minecraft:moss_block
setblock 248 115 363 minecraft:mushroom_stem
fill 249 115 323 249 118 323 minecraft:moss_block
fill 249 115 357 249 116 359 minecraft:red_mushroom_block
setblock 249 115 362 minecraft:mushroom_stem
fill 249 115 363 249 118 363 minecraft:moss_block
setblock 250 115 361 minecraft:mushroom_stem
fill 250 115 362 250 116 362 minecraft:moss_block
setblock 252 115 324 minecraft:mushroom_stem
setblock 253 115 323 minecraft:mushroom_stem
setblock 253 115 363 minecraft:mushroom_stem
fill 254 115 323 254 116 323 minecraft:moss_block
fill 254 115 363 254 116 363 minecraft:moss_block
setblock 258 115 323 minecraft:mushroom_stem
fill 259 115 323 259 116 323 minecraft:moss_block
setblock 260 115 363 minecraft:red_mushroom_block
setblock 261 115 324 minecraft:moss_block
setblock 262 115 324 minecraft:mushroom_stem
setblock 263 115 323 minecraft:mushroom_stem
fill 263 115 324 263 118 324 minecraft:moss_block
setblock 263 115 363 minecraft:mushroom_stem
fill 264 115 323 264 118 323 minecraft:moss_block
fill 264 115 363 264 118 363 minecraft:moss_block
setblock 266 115 325 minecraft:mushroom_stem
fill 266 115 326 269 115 326 minecraft:moss_block
setblock 267 115 324 minecraft:mushroom_stem
fill 267 115 325 267 118 325 minecraft:moss_block
setblock 268 115 323 minecraft:mushroom_stem
fill 268 115 324 268 118 324 minecraft:moss_block
setblock 268 115 363 minecraft:mushroom_stem
fill 269 115 323 269 118 323 minecraft:moss_block
fill 269 115 363 269 117 363 minecraft:moss_block
setblock 270 115 326 minecraft:mushroom_stem
setblock 271 115 325 minecraft:mushroom_stem
setblock 271 115 326 minecraft:moss_block
setblock 272 115 324 minecraft:mushroom_stem
fill 272 115 325 272 117 325 minecraft:moss_block
setblock 273 115 323 minecraft:mushroom_stem
fill 273 115 324 273 118 324 minecraft:moss_block
setblock 273 115 363 minecraft:mushroom_stem
fill 274 115 323 274 118 323 minecraft:moss_block
fill 274 115 325 274 115 326 minecraft:moss_block
setblock 274 115 327 minecraft:mushroom_stem
fill 274 115 328 274 116 328 minecraft:moss_block
setblock 274 115 363 minecraft:moss_block
setblock 275 115 326 minecraft:mushroom_stem
fill 275 115 327 275 118 327 minecraft:moss_block
fill 275 115 345 275 137 346 minecraft:mushroom_stem
setblock 276 115 325 minecraft:mushroom_stem
fill 276 115 326 276 118 326 minecraft:moss_block
setblock 276 115 330 minecraft:mushroom_stem
fill 276 115 331 276 118 331 minecraft:moss_block
fill 276 115 337 276 116 337 minecraft:red_mushroom_block
setblock 276 115 341 minecraft:moss_block
setblock 276 115 345 minecraft:mushroom_stem
fill 276 115 346 276 116 346 minecraft:moss_block
setblock 276 115 362 minecraft:red_mushroom_block
fill 235 116 349 235 143 349 minecraft:brown_terracotta
setblock 236 116 324 minecraft:mushroom_stem
fill 236 116 325 236 119 325 minecraft:moss_block
setblock 236 116 329 minecraft:mushroom_stem
fill 236 116 330 236 119 330 minecraft:moss_block
setblock 236 116 348 minecraft:moss_block
setblock 236 116 349 minecraft:red_mushroom_block
setblock 237 116 323 minecraft:mushroom_stem
fill 237 116 324 237 118 324 minecraft:moss_block
setblock 237 116 328 minecraft:mushroom_stem
setblock 237 116 363 minecraft:mushroom_stem
fill 238 116 323 238 119 323 minecraft:moss_block
fill 238 116 363 238 119 363 minecraft:moss_block
setblock 239 116 325 minecraft:moss_block
setblock 239 116 362 minecraft:moss_block
setblock 240 116 325 minecraft:mushroom_stem
setblock 241 116 324 minecraft:mushroom_stem
fill 241 116 325 241 118 325 minecraft:moss_block
setblock 242 116 323 minecraft:mushroom_stem
fill 242 116 324 242 119 324 minecraft:moss_block
setblock 242 116 363 minecraft:mushroom_stem
fill 243 116 323 243 119 323 minecraft:moss_block
setblock 243 116 362 minecraft:mushroom_stem
fill 243 116 363 243 119 363 minecraft:moss_block
setblock 244 116 361 minecraft:mushroom_stem
fill 244 116 362 244 119 362 minecraft:moss_block
setblock 245 116 325 minecraft:mushroom_stem
fill 245 116 350 245 148 350 minecraft:mushroom_stem
fill 245 116 361 245 117 361 minecraft:moss_block
setblock 246 116 324 minecraft:mushroom_stem
fill 246 116 325 246 118 325 minecraft:moss_block
fill 246 116 351 246 148 351 minecraft:mushroom_stem
setblock 247 116 323 minecraft:mushroom_stem
fill 247 116 324 247 119 324 minecraft:moss_block
setblock 247 116 363 minecraft:mushroom_stem
fill 248 116 323 248 119 323 minecraft:moss_block
setblock 248 116 362 minecraft:mushroom_stem
fill 248 116 363 248 119 363 minecraft:moss_block
fill 249 116 362 249 117 362 minecraft:moss_block
setblock 251 116 324 minecraft:mushroom_stem
setblock 252 116 323 minecraft:mushroom_stem
setblock 252 116 363 minecraft:mushroom_stem
setblock 253 116 323 minecraft:moss_block
setblock 253 116 363 minecraft:moss_block
setblock 261 116 324 minecraft:mushroom_stem
fill 262 116 322 268 121 322 minecraft:brown_terracotta
setblock 262 116 323 minecraft:mushroom_stem
fill 262 116 324 262 119 324 minecraft:moss_block
setblock 262 116 363 minecraft:mushroom_stem
fill 263 116 323 263 119 323 minecraft:moss_block
fill 263 116 325 263 117 325 minecraft:moss_block
fill 263 116 363 263 117 363 minecraft:moss_block
setblock 265 116 324 minecraft:moss_block
setblock 265 116 325 minecraft:mushroom_stem
setblock 266 116 324 minecraft:mushroom_stem
fill 266 116 325 266 117 326 minecraft:moss_block
setblock 267 116 323 minecraft:mushroom_stem
fill 267 116 324 267 119 324 minecraft:moss_block
fill 267 116 326 268 116 326 minecraft:moss_block
setblock 267 116 363 minecraft:mushroom_stem
fill 268 116 323 268 119 323 minecraft:moss_block
fill 268 116 363 268 117 363 minecraft:moss_block
setblock 269 116 322 minecraft:red_mushroom_block
setblock 269 116 326 minecraft:mushroom_stem
fill 270 116 322 270 147 322 minecraft:brown_terracotta
setblock 270 116 325 minecraft:mushroom_stem
setblock 270 116 326 minecraft:moss_block
setblock 271 116 324 minecraft:mushroom_stem
fill 271 116 325 271 118 325 minecraft:moss_block
setblock 272 116 323 minecraft:mushroom_stem
fill 272 116 324 272 119 324 minecraft:moss_block
setblock 272 116 363 minecraft:mushroom_stem
fill 273 116 323 273 119 323 minecraft:moss_block
setblock 274 116 325 minecraft:moss_block
setblock 274 116 326 minecraft:mushroom_stem
fill 274 116 327 274 117 327 minecraft:moss_block
setblock 275 116 325 minecraft:mushroom_stem
fill 275 116 326 275 119 326 minecraft:moss_block
setblock 275 116 329 minecraft:moss_block
setblock 275 116 330 minecraft:mushroom_stem
setblock 275 116 364 minecraft:shroomlight
setblock 276 116 324 minecraft:mushroom_stem
fill 276 116 325 276 119 325 minecraft:moss_block
setblock 276 116 329 minecraft:mushroom_stem
fill 276 116 330 276 119 330 minecraft:moss_block
setblock 276 116 344 minecraft:mushroom_stem
setblock 276 116 345 minecraft:moss_block
setblock 276 116 356 minecraft:red_mushroom_block
setblock 236 117 323 minecraft:mushroom_stem
fill 236 117 324 236 120 324 minecraft:moss_block
setblock 236 117 328 minecraft:mushroom_stem
fill 236 117 329 236 120 329 minecraft:moss_block
setblock 236 117 336 minecraft:red_mushroom_block
setblock 236 117 355 minecraft:red_mushroom_block
fill 236 117 361 236 118 361 minecraft:red_mushroom_block
setblock 236 117 363 minecraft:mushroom_stem
fill 237 117 323 237 120 323 minecraft:moss_block
setblock 237 117 327 minecraft:mushroom_stem
setblock 237 117 328 minecraft:moss_block
fill 237 117 363 237 119 363 minecraft:moss_block
setblock 238 117 325 minecraft:light[level=15]
setblock 238 117 332 minecraft:light[level=12]
setblock 238 117 333 minecraft:light[level=15]
setblock 238 117 339 minecraft:light[level=12]
setblock 238 117 341 minecraft:light[level=15]
setblock 238 117 346 minecraft:light[level=12]
setblock 238 117 349 minecraft:light[level=15]
setblock 238 117 353 minecraft:light[level=12]
setblock 238 117 357 minecraft:light[level=15]
setblock 238 117 360 minecraft:light[level=12]
setblock 240 117 324 minecraft:mushroom_stem
setblock 240 117 325 minecraft:moss_block
setblock 241 117 323 minecraft:mushroom_stem
fill 241 117 324 241 120 324 minecraft:moss_block
setblock 241 117 363 minecraft:mushroom_stem
fill 242 117 323 242 120 323 minecraft:moss_block
setblock 242 117 362 minecraft:mushroom_stem
fill 242 117 363 242 120 363 minecraft:moss_block
fill 243 117 362 243 120 362 minecraft:moss_block
setblock 244 117 325 minecraft:mushroom_stem
setblock 244 117 361 minecraft:moss_block
setblock 245 117 324 minecraft:mushroom_stem
fill 245 117 325 245 118 325 minecraft:moss_block
setblock 245 117 332 minecraft:light[level=12]
setblock 245 117 339 minecraft:light[level=12]
setblock 245 117 346 minecraft:light[level=12]
setblock 245 117 353 minecraft:light[level=12]
setblock 246 117 323 minecraft:mushroom_stem
fill 246 117 324 246 119 324 minecraft:moss_block
setblock 246 117 333 minecraft:light[level=15]
setblock 246 117 341 minecraft:light[level=15]
setblock 246 117 349 minecraft:light[level=15]
setblock 246 117 363 minecraft:mushroom_stem
fill 247 117 323 247 120 323 minecraft:moss_block
setblock 247 117 362 minecraft:mushroom_stem
fill 247 117 363 247 120 363 minecraft:moss_block
fill 248 117 362 248 118 362 minecraft:moss_block
setblock 250 117 324 minecraft:mushroom_stem
setblock 251 117 323 minecraft:mushroom_stem
setblock 251 117 363 minecraft:mushroom_stem
setblock 252 117 323 minecraft:moss_block
setblock 252 117 325 minecraft:light[level=12]
setblock 252 117 332 minecraft:light[level=12]
setblock 252 117 339 minecraft:light[level=12]
setblock 252 117 346 minecraft:light[level=12]
setblock 252 117 353 minecraft:light[level=12]
setblock 252 117 360 minecraft:light[level=12]
setblock 252 117 363 minecraft:moss_block
setblock 253 117 363 minecraft:red_mushroom_block
setblock 254 117 325 minecraft:light[level=15]
setblock 254 117 333 minecraft:light[level=15]
setblock 254 117 341 minecraft:light[level=15]
setblock 254 117 349 minecraft:light[level=15]
setblock 254 117 357 minecraft:light[level=15]
setblock 259 117 323 minecraft:red_mushroom_block
setblock 259 117 325 minecraft:light[level=12]
setblock 259 117 332 minecraft:light[level=12]
setblock 259 117 339 minecraft:light[level=12]
setblock 259 117 346 minecraft:light[level=12]
setblock 259 117 353 minecraft:light[level=12]
setblock 259 117 360 minecraft:light[level=12]
setblock 261 117 323 minecraft:mushroom_stem
setblock 261 117 324 minecraft:moss_block
fill 262 117 323 262 120 323 minecraft:moss_block
setblock 262 117 325 minecraft:light[level=15]
setblock 262 117 333 minecraft:light[level=15]
setblock 262 117 341 minecraft:light[level=15]
setblock 262 117 349 minecraft:light[level=15]
setblock 262 117 357 minecraft:light[level=15]
setblock 264 117 324 minecraft:moss_block
setblock 264 117 325 minecraft:mushroom_stem
setblock 265 117 324 minecraft:mushroom_stem
fill 265 117 325 265 120 325 minecraft:moss_block
setblock 266 117 323 minecraft:mushroom_stem
fill 266 117 324 266 120 324 minecraft:moss_block
setblock 266 117 332 minecraft:light[level=12]
setblock 266 117 339 minecraft:light[level=12]
setblock 266 117 346 minecraft:light[level=12]
setblock 266 117 353 minecraft:light[level=12]
fill 266 117 359 270 117 361 minecraft:red_mushroom_block
setblock 266 117 363 minecraft:mushroom_stem
fill 267 117 323 267 120 323 minecraft:moss_block
setblock 267 117 326 minecraft:moss_block
fill 267 117 358 269 117 358 minecraft:red_mushroom_block
fill 267 117 362 269 117 362 minecraft:red_mushroom_block
fill 267 117 363 267 118 363 minecraft:moss_block
setblock 268 117 326 minecraft:mushroom_stem
fill 269 117 322 269 147 322 minecraft:brown_terracotta
setblock 269 117 325 minecraft:mushroom_stem
setblock 269 117 326 minecraft:moss_block
setblock 270 117 324 minecraft:mushroom_stem
fill 270 117 325 270 118 325 minecraft:moss_block
setblock 270 117 333 minecraft:light[level=15]
setblock 270 117 341 minecraft:light[level=15]
setblock 270 117 349 minecraft:light[level=15]
setblock 270 117 357 minecraft:light[level=15]
setblock 271 117 323 minecraft:mushroom_stem
fill 271 117 324 271 119 324 minecraft:moss_block
fill 272 117 323 272 120 323 minecraft:moss_block
setblock 272 117 363 minecraft:red_mushroom_block
setblock 273 117 332 minecraft:light[level=12]
setblock 273 117 339 minecraft:light[level=12]
setblock 273 117 353 minecraft:light[level=12]
setblock 273 117 360 minecraft:light[level=12]
setblock 274 117 326 minecraft:moss_block
setblock 275 117 324 minecraft:mushroom_stem
fill 275 117 325 275 119 325 minecraft:moss_block
setblock 275 117 329 minecraft:mushroom_stem
fill 275 117 330 275 120 330 minecraft:moss_block
fill 275 117 364 275 144 364 minecraft:brown_terracotta
setblock 276 117 323 minecraft:mushroom_stem
fill 276 117 324 276 120 324 minecraft:moss_block
setblock 276 117 328 minecraft:mushroom_stem
fill 276 117 329 276 120 329 minecraft:moss_block
setblock 276 117 333 minecraft:mushroom_stem
setblock 276 117 350 minecraft:red_mushroom_block
setblock 277 117 361 minecraft:shroomlight
fill 277 117 362 277 147 363 minecraft:brown_terracotta
fill 236 118 323 236 120 323 minecraft:moss_block
setblock 236 118 327 minecraft:mushroom_stem
fill 236 118 328 236 121 328 minecraft:moss_block
setblock 236 118 342 minecraft:red_mushroom_block
setblock 236 118 363 minecraft:moss_block
setblock 237 118 326 minecraft:mushroom_stem
setblock 237 118 327 minecraft:moss_block
setblock 239 118 324 minecraft:mushroom_stem
setblock 240 118 323 minecraft:mushroom_stem
fill 240 118 324 240 120 324 minecraft:moss_block
setblock 240 118 363 minecraft:mushroom_stem
fill 241 118 323 241 121 323 minecraft:moss_block
setblock 241 118 362 minecraft:mushroom_stem
fill 241 118 363 241 121 363 minecraft:moss_block
fill 242 118 362 242 120 362 minecraft:moss_block
setblock 243 118 325 minecraft:mushroom_stem
setblock 244 118 324 minecraft:mushroom_stem
setblock 244 118 325 minecraft:moss_block
setblock 245 118 323 minecraft:mushroom_stem
fill 245 118 324 245 120 324 minecraft:moss_block
setblock 245 118 363 minecraft:mushroom_stem
fill 246 118 323 246 121 323 minecraft:moss_block
setblock 246 118 362 minecraft:mushroom_stem
fill 246 118 363 246 121 363 minecraft:moss_block
setblock 247 118 362 minecraft:moss_block
setblock 250 118 323 minecraft:mushroom_stem
setblock 250 118 363 minecraft:mushroom_stem
setblock 253 118 323 minecraft:red_mushroom_block
setblock 259 118 363 minecraft:red_mushroom_block
setblock 260 118 323 minecraft:mushroom_stem
fill 261 118 323 261 121 323 minecraft:moss_block
setblock 263 118 325 minecraft:mushroom_stem
setblock 264 118 324 minecraft:mushroom_stem
fill 264 118 325 264 119 325 minecraft:moss_block
setblock 265 118 323 minecraft:mushroom_stem
fill 265 118 324 265 121 324 minecraft:moss_block
setblock 265 118 363 minecraft:mushroom_stem
fill 266 118 323 266 121 323 minecraft:moss_block
fill 266 118 325 266 119 325 minecraft:moss_block
setblock 266 118 363 minecraft:moss_block
setblock 268 118 325 minecraft:mushroom_stem
setblock 269 118 324 minecraft:mushroom_stem
fill 269 118 325 269 119 325 minecraft:moss_block
setblock 270 118 323 minecraft:mushroom_stem
fill 270 118 324 270 119 324 minecraft:moss_block
fill 271 118 323 271 120 323 minecraft:moss_block
setblock 274 118 324 minecraft:mushroom_stem
setblock 275 118 323 minecraft:mushroom_stem
setblock 275 118 324 minecraft:moss_block
setblock 275 118 328 minecraft:mushroom_stem
fill 275 118 329 275 121 329 minecraft:moss_block
fill 276 118 323 276 121 323 minecraft:moss_block
setblock 276 118 327 minecraft:mushroom_stem
fill 276 118 328 276 121 328 minecraft:moss_block
setblock 276 118 332 minecraft:mushroom_stem
setblock 276 118 344 minecraft:red_mushroom_block
fill 277 118 361 277 144 361 minecraft:brown_terracotta
setblock 236 119 326 minecraft:mushroom_stem
fill 236 119 327 236 122 327 minecraft:moss_block
setblock 236 119 348 minecraft:red_mushroom_block
setblock 237 119 325 minecraft:mushroom_stem
setblock 237 119 326 minecraft:moss_block
setblock 238 119 324 minecraft:mushroom_stem
setblock 239 119 323 minecraft:mushroom_stem
setblock 239 119 324 minecraft:moss_block
setblock 239 119 363 minecraft:mushroom_stem
fill 240 119 323 240 122 323 minecraft:moss_block
fill 240 119 363 240 122 363 minecraft:moss_block
setblock 241 119 362 minecraft:moss_block
setblock 243 119 324 minecraft:mushroom_stem
setblock 244 119 323 minecraft:mushroom_stem
fill 244 119 324 244 120 324 minecraft:moss_block
setblock 244 119 363 minecraft:mushroom_stem
fill 245 119 323 245 121 323 minecraft:moss_block
setblock 245 119 362 minecraft:mushroom_stem
fill 245 119 363 245 122 363 minecraft:moss_block
setblock 246 119 362 minecraft:moss_block
setblock 249 119 323 minecraft:mushroom_stem
setblock 249 119 363 minecraft:mushroom_stem
setblock 263 119 324 minecraft:mushroom_stem
setblock 264 119 323 minecraft:mushroom_stem
fill 264 119 324 264 122 324 minecraft:moss_block
fill 265 119 323 265 122 323 minecraft:moss_block
setblock 265 119 363 minecraft:red_mushroom_block
setblock 267 119 325 minecraft:mushroom_stem
setblock 268 119 324 minecraft:mushroom_stem
setblock 268 119 325 minecraft:moss_block
setblock 269 119 323 minecraft:mushroom_stem
fill 269 119 324 269 120 324 minecraft:moss_block
fill 270 119 323 270 121 323 minecraft:moss_block
setblock 274 119 323 minecraft:mushroom_stem
fill 275 119 323 275 120 323 minecraft:moss_block
setblock 275 119 327 minecraft:mushroom_stem
fill 275 119 328 275 122 328 minecraft:moss_block
setblock 276 119 326 minecraft:mushroom_stem
fill 276 119 327 276 122 327 minecraft:moss_block
setblock 276 119 331 minecraft:mushroom_stem
fill 276 119 332 276 122 332 minecraft:moss_block
setblock 276 119 338 minecraft:red_mushroom_block
setblock 276 119 357 minecraft:red_mushroom_block
setblock 236 120 325 minecraft:mushroom_stem
fill 236 120 326 236 123 326 minecraft:moss_block
setblock 236 120 330 minecraft:mushroom_stem
setblock 236 120 335 minecraft:red_mushroom_block
fill 236 120 351 236 122 352 minecraft:moss_block
setblock 236 120 354 minecraft:red_mushroom_block
setblock 238 120 323 minecraft:mushroom_stem
setblock 238 120 363 minecraft:mushroom_stem
fill 239 120 323 239 123 323 minecraft:moss_block
fill 239 120 363 239 123 363 minecraft:moss_block
setblock 242 120 324 minecraft:mushroom_stem
setblock 243 120 323 minecraft:mushroom_stem
setblock 243 120 324 minecraft:moss_block
setblock 243 120 363 minecraft:mushroom_stem
fill 244 120 323 244 122 323 minecraft:moss_block
setblock 244 120 362 minecraft:mushroom_stem
fill 244 120 363 244 123 363 minecraft:moss_block
setblock 244 120 364 minecraft:shroomlight
setblock 245 120 362 minecraft:moss_block
setblock 252 120 363 minecraft:red_mushroom_block
setblock 260 120 323 minecraft:red_mushroom_block
setblock 262 120 324 minecraft:mushroom_stem
setblock 263 120 323 minecraft:mushroom_stem
fill 263 120 324 263 122 324 minecraft:moss_block
fill 264 120 323 264 123 323 minecraft:moss_block
setblock 266 120 325 minecraft:mushroom_stem
setblock 267 120 324 minecraft:mushroom_stem
setblock 268 120 323 minecraft:mushroom_stem
setblock 268 120 324 minecraft:moss_block
fill 269 120 323 269 121 323 minecraft:moss_block
setblock 271 120 363 minecraft:red_mushroom_block
setblock 273 120 323 minecraft:mushroom_stem
setblock 274 120 323 minecraft:moss_block
setblock 275 120 326 minecraft:mushroom_stem
fill 275 120 327 275 123 327 minecraft:moss_block
setblock 276 120 325 minecraft:mushroom_stem
fill 276 120 326 276 123 326 minecraft:moss_block
setblock 276 120 330 minecraft:mushroom_stem
fill 276 120 331 276 123 331 minecraft:moss_block
setblock 276 120 351 minecraft:red_mushroom_block
setblock 236 121 324 minecraft:mushroom_stem
fill 236 121 325 236 124 325 minecraft:moss_block
setblock 236 121 329 minecraft:mushroom_stem
fill 236 121 330 236 124 330 minecraft:moss_block
setblock 236 121 341 minecraft:red_mushroom_block
fill 236 121 350 236 124 350 minecraft:moss_block
setblock 236 121 353 minecraft:moss_block
setblock 236 121 354 minecraft:mushroom_stem
setblock 236 121 360 minecraft:red_mushroom_block
setblock 237 121 323 minecraft:mushroom_stem
fill 238 121 323 238 124 323 minecraft:moss_block
fill 238 121 363 238 124 363 minecraft:moss_block
setblock 241 121 324 minecraft:mushroom_stem
setblock 242 121 323 minecraft:mushroom_stem
setblock 242 121 324 minecraft:moss_block
setblock 242 121 363 minecraft:mushroom_stem
fill 243 121 323 243 124 323 minecraft:moss_block
fill 243 121 343 243 122 343 minecraft:shroomlight
setblock 243 121 362 minecraft:mushroom_stem
fill 243 121 363 243 124 363 minecraft:moss_block
fill 244 121 364 244 147 364 minecraft:brown_terracotta
fill 248 121 356 252 122 360 minecraft:dirt
fill 250 121 361 250 121 362 minecraft:dirt
setblock 254 121 323 minecraft:red_mushroom_block
setblock 258 121 363 minecraft:red_mushroom_block
setblock 262 121 323 minecraft:mushroom_stem
fill 263 121 323 263 124 323 minecraft:moss_block
setblock 266 121 324 minecraft:mushroom_stem
setblock 267 121 323 minecraft:mushroom_stem
setblock 267 121 324 minecraft:moss_block
fill 268 121 323 268 122 323 minecraft:moss_block
setblock 275 121 330 minecraft:mushroom_stem
setblock 276 121 324 minecraft:mushroom_stem
fill 276 121 325 276 124 325 minecraft:moss_block
setblock 276 121 329 minecraft:mushroom_stem
fill 276 121 330 276 124 330 minecraft:moss_block
setblock 276 121 333 minecraft:moss_block
setblock 276 121 345 minecraft:red_mushroom_block
fill 277 121 323 277 143 326 minecraft:brown_terracotta
setblock 277 121 327 minecraft:red_mushroom_block
setblock 236 122 328 minecraft:mushroom_stem
fill 236 122 329 236 125 329 minecraft:moss_block
fill 236 122 331 236 123 331 minecraft:moss_block
setblock 236 122 347 minecraft:red_mushroom_block
setblock 236 122 353 minecraft:mushroom_stem
fill 236 122 354 236 122 357 minecraft:moss_block
setblock 237 122 352 minecraft:mushroom_stem
fill 237 122 353 237 124 354 minecraft:moss_block
setblock 241 122 323 minecraft:mushroom_stem
setblock 241 122 363 minecraft:mushroom_stem
fill 242 122 323 242 125 323 minecraft:moss_block
fill 242 122 363 242 125 363 minecraft:moss_block
setblock 246 122 363 minecraft:mushroom_stem
setblock 248 122 323 minecraft:red_mushroom_block
fill 254 122 364 254 149 364 minecraft:brown_terracotta
setblock 255 122 364 minecraft:red_mushroom_block
fill 256 122 364 256 144 364 minecraft:brown_terracotta
setblock 261 122 323 minecraft:mushroom_stem
fill 262 122 322 263 126 322 minecraft:brown_terracotta
fill 262 122 323 262 125 323 minecraft:moss_block
setblock 264 122 322 minecraft:red_mushroom_block
setblock 264 122 363 minecraft:red_mushroom_block
fill 265 122 322 268 143 322 minecraft:brown_terracotta
setblock 265 122 324 minecraft:mushroom_stem
setblock 266 122 323 minecraft:mushroom_stem
fill 267 122 323 267 125 323 minecraft:moss_block
setblock 273 122 323 minecraft:red_mushroom_block
setblock 275 122 329 minecraft:mushroom_stem
fill 275 122 330 275 125 330 minecraft:moss_block
setblock 276 122 323 minecraft:mushroom_stem
fill 276 122 324 276 125 324 minecraft:moss_block
setblock 276 122 328 minecraft:mushroom_stem
fill 276 122 329 276 125 329 minecraft:moss_block
setblock 276 122 333 minecraft:mushroom_stem
setblock 276 122 339 minecraft:red_mushroom_block
fill 277 122 327 277 144 327 minecraft:brown_terracotta
setblock 236 123 327 minecraft:mushroom_stem
fill 236 123 328 236 126 328 minecraft:moss_block
setblock 236 123 332 minecraft:mushroom_stem
fill 236 123 349 236 125 349 minecraft:moss_block
setblock 236 123 351 minecraft:moss_block
setblock 236 123 352 minecraft:mushroom_stem
fill 236 123 353 236 123 356 minecraft:moss_block
setblock 236 123 357 minecraft:mushroom_stem
fill 236 123 358 236 125 359 minecraft:moss_block
setblock 237 123 350 minecraft:moss_block
setblock 237 123 351 minecraft:mushroom_stem
fill 237 123 352 237 126 352 minecraft:moss_block
setblock 237 123 355 minecraft:moss_block
setblock 237 123 356 minecraft:mushroom_stem
fill 237 123 357 237 126 357 minecraft:moss_block
fill 237 123 363 237 125 363 minecraft:moss_block
setblock 238 123 325 minecraft:light[level=12]
setblock 238 123 332 minecraft:light[level=12]
setblock 238 123 339 minecraft:light[level=12]
setblock 238 123 346 minecraft:light[level=12]
fill 238 123 353 238 124 353 minecraft:moss_block
setblock 238 123 360 minecraft:light[level=12]
setblock 240 123 323 minecraft:mushroom_stem
setblock 240 123 363 minecraft:mushroom_stem
fill 241 123 323 241 126 323 minecraft:moss_block
setblock 241 123 362 minecraft:mushroom_stem
fill 241 123 363 241 126 363 minecraft:moss_block
fill 242 123 362 242 126 362 minecraft:moss_block
fill 243 123 343 243 133 343 minecraft:dirt
setblock 245 123 325 minecraft:light[level=12]
setblock 245 123 332 minecraft:light[level=12]
setblock 245 123 339 minecraft:light[level=12]
setblock 245 123 346 minecraft:light[level=12]
setblock 245 123 353 minecraft:light[level=12]
setblock 245 123 360 minecraft:light[level=12]
setblock 245 123 363 minecraft:mushroom_stem
fill 249 123 358 251 129 358 minecraft:mushroom_stem
fill 250 123 357 250 129 357 minecraft:mushroom_stem
fill 250 123 359 250 129 359 minecraft:mushroom_stem
setblock 252 123 325 minecraft:light[level=12]
setblock 252 123 332 minecraft:light[level=12]
setblock 252 123 339 minecraft:light[level=12]
setblock 252 123 346 minecraft:light[level=12]
setblock 252 123 353 minecraft:light[level=12]
setblock 252 123 360 minecraft:light[level=12]
fill 255 123 364 255 143 364 minecraft:brown_terracotta
fill 257 123 322 257 147 322 minecraft:brown_terracotta
setblock 258 123 322 minecraft:shroomlight
fill 259 123 322 259 147 322 minecraft:brown_terracotta
setblock 259 123 325 minecraft:light[level=12]
setblock 259 123 332 minecraft:light[level=12]
setblock 259 123 339 minecraft:light[level=12]
setblock 259 123 346 minecraft:light[level=12]
setblock 259 123 353 minecraft:light[level=12]
setblock 259 123 360 minecraft:light[level=12]
fill 261 123 323 261 126 323 minecraft:moss_block
fill 264 123 322 264 143 322 minecraft:brown_terracotta
setblock 265 123 323 minecraft:mushroom_stem
fill 266 123 323 266 126 323 minecraft:moss_block
setblock 266 123 325 minecraft:light[level=12]
setblock 266 123 332 minecraft:light[level=12]
setblock 266 123 339 minecraft:light[level=12]
setblock 266 123 346 minecraft:light[level=12]
setblock 266 123 353 minecraft:light[level=12]
setblock 266 123 360 minecraft:light[level=12]
setblock 270 123 363 minecraft:red_mushroom_block
setblock 273 123 325 minecraft:light[level=12]
setblock 273 123 332 minecraft:light[level=12]
setblock 273 123 339 minecraft:light[level=12]
setblock 273 123 353 minecraft:light[level=12]
setblock 273 123 360 minecraft:light[level=12]
setblock 275 123 328 minecraft:mushroom_stem
fill 275 123 329 275 126 329 minecraft:moss_block
fill 275 123 331 275 124 331 minecraft:moss_block
fill 276 123 323 276 126 323 minecraft:moss_block
setblock 276 123 327 minecraft:mushroom_stem
fill 276 123 328 276 126 328 minecraft:moss_block
setblock 276 123 332 minecraft:mushroom_stem
fill 276 123 333 276 125 334 minecraft:moss_block
setblock 276 123 358 minecraft:red_mushroom_block
setblock 235 124 327 minecraft:red_mushroom_block
setblock 236 124 326 minecraft:mushroom_stem
fill 236 124 327 236 127 327 minecraft:moss_block
setblock 236 124 331 minecraft:mushroom_stem
fill 236 124 332 236 126 333 minecraft:moss_block
setblock 236 124 334 minecraft:red_mushroom_block
fill 236 124 348 236 126 348 minecraft:moss_block
setblock 236 124 351 minecraft:mushroom_stem
fill 236 124 352 236 124 355 minecraft:moss_block
setblock 236 124 356 minecraft:mushroom_stem
fill 236 124 357 236 127 357 minecraft:moss_block
setblock 236 124 360 minecraft:moss_block
setblock 236 124 361 minecraft:mushroom_stem
fill 236 124 362 236 126 363 minecraft:moss_block
fill 237 124 323 237 125 323 minecraft:moss_block
setblock 237 124 350 minecraft:mushroom_stem
fill 237 124 351 238 126 351 minecraft:moss_block
setblock 237 124 355 minecraft:mushroom_stem
fill 237 124 356 238 126 356 minecraft:moss_block
fill 237 124 358 237 124 359 minecraft:moss_block
fill 238 124 352 238 125 352 minecraft:moss_block
setblock 238 124 354 minecraft:mushroom_stem
fill 238 124 355 238 127 355 minecraft:moss_block
fill 238 124 357 238 125 357 minecraft:moss_block
fill 239 124 322 240 147 322 minecraft:brown_terracotta
setblock 239 124 323 minecraft:mushroom_stem
setblock 239 124 362 minecraft:moss_block
setblock 239 124 363 minecraft:mushroom_stem
fill 240 124 323 240 127 323 minecraft:moss_block
setblock 240 124 362 minecraft:mushroom_stem
fill 240 124 363 240 127 363 minecraft:moss_block
setblock 241 124 322 minecraft:red_mushroom_block
fill 241 124 362 241 127 362 minecraft:moss_block
fill 242 124 322 244 143 322 minecraft:brown_terracotta
fill 243 124 344 243 133 344 minecraft:dirt
fill 243 124 362 243 125 362 minecraft:moss_block
fill 244 124 343 244 133 343 minecraft:dirt
setblock 244 124 363 minecraft:mushroom_stem
fill 245 124 363 245 127 363 minecraft:moss_block
setblock 251 124 363 minecraft:red_mushroom_block
fill 255 124 323 255 125 323 minecraft:red_mushroom_block
fill 258 124 322 258 143 322 minecraft:brown_terracotta
fill 260 124 323 260 127 323 minecraft:moss_block
setblock 264 124 323 minecraft:mushroom_stem
fill 265 124 323 265 127 323 minecraft:moss_block
setblock 275 124 327 minecraft:mushroom_stem
fill 275 124 328 275 127 328 minecraft:moss_block
setblock 275 124 332 minecraft:mushroom_stem
setblock 276 124 326 minecraft:mushroom_stem
fill 276 124 327 276 127 327 minecraft:moss_block
setblock 276 124 331 minecraft:mushroom_stem
fill 276 124 332 276 127 332 minecraft:moss_block
setblock 276 124 335 minecraft:moss_block
fill 276 124 352 276 124 355 minecraft:moss_block
setblock 276 124 356 minecraft:mushroom_stem
fill 276 124 357 276 127 357 minecraft:moss_block
setblock 276 124 363 minecraft:red_mushroom_block
fill 235 125 327 235 128 327 minecraft:brown_terracotta
setblock 236 125 324 minecraft:moss_block
setblock 236 125 325 minecraft:mushroom_stem
fill 236 125 326 236 128 326 minecraft:moss_block
setblock 236 125 330 minecraft:mushroom_stem
fill 236 125 331 237 127 331 minecraft:moss_block
setblock 236 125 334 minecraft:moss_block
setblock 236 125 335 minecraft:mushroom_stem
setblock 236 125 340 minecraft:red_mushroom_block
setblock 236 125 350 minecraft:mushroom_stem
fill 236 125 351 236 125 354 minecraft:moss_block
setblock 236 125 355 minecraft:mushroom_stem
fill 236 125 356 236 128 356 minecraft:moss_block
setblock 236 125 360 minecraft:mushroom_stem
fill 236 125 361 237 127 361 minecraft:moss_block
setblock 237 125 329 minecraft:mushroom_stem
fill 237 125 330 237 128 330 minecraft:moss_block
fill 237 125 332 237 126 332 minecraft:moss_block
setblock 237 125 349 minecraft:mushroom_stem
fill 237 125 350 238 127 350 minecraft:moss_block
setblock 237 125 353 minecraft:moss_block
setblock 237 125 354 minecraft:mushroom_stem
fill 237 125 355 237 128 355 minecraft:moss_block
setblock 237 125 358 minecraft:moss_block
setblock 237 125 359 minecraft:mushroom_stem
fill 237 125 360 237 128 360 minecraft:moss_block
fill 237 125 362 238 125 362 minecraft:moss_block
setblock 238 125 323 minecraft:mushroom_stem
setblock 238 125 325 minecraft:light[level=15]
setblock 238 125 333 minecraft:light[level=15]
setblock 238 125 341 minecraft:light[level=15]
setblock 238 125 349 minecraft:light[level=15]
setblock 238 125 353 minecraft:mushroom_stem
fill 238 125 354 239 127 354 minecraft:moss_block
setblock 238 125 358 minecraft:mushroom_stem
fill 238 125 359 238 128 359 minecraft:moss_block
setblock 238 125 363 minecraft:mushroom_stem
fill 239 125 323 239 128 323 minecraft:moss_block
setblock 239 125 352 minecraft:mushroom_stem
fill 239 125 353 239 128 353 minecraft:moss_block
fill 239 125 355 239 125 356 minecraft:moss_block
setblock 239 125 357 minecraft:mushroom_stem
setblock 239 125 362 minecraft:mushroom_stem
fill 239 125 363 239 128 363 minecraft:moss_block
fill 240 125 362 240 128 362 minecraft:moss_block
fill 241 125 322 241 145 322 minecraft:brown_terracotta
setblock 243 125 363 minecraft:mushroom_stem
fill 244 125 344 244 133 344 minecraft:dirt
fill 244 125 363 244 128 363 minecraft:moss_block
setblock 246 125 325 minecraft:light[level=15]
setblock 246 125 333 minecraft:light[level=15]
setblock 246 125 341 minecraft:light[level=15]
setblock 246 125 349 minecraft:light[level=15]
setblock 246 125 357 minecraft:light[level=15]
setblock 249 125 323 minecraft:red_mushroom_block
setblock 254 125 325 minecraft:light[level=15]
setblock 254 125 333 minecraft:light[level=15]
setblock 254 125 341 minecraft:light[level=15]
setblock 254 125 349 minecraft:light[level=15]
setblock 254 125 357 minecraft:light[level=15]
setblock 257 125 363 minecraft:red_mushroom_block
setblock 262 125 325 minecraft:light[level=15]
setblock 262 125 333 minecraft:light[level=15]
setblock 262 125 341 minecraft:light[level=15]
setblock 262 125 349 minecraft:light[level=15]
setblock 262 125 357 minecraft:light[level=15]
setblock 263 125 323 minecraft:mushroom_stem
fill 264 125 323 264 128 323 minecraft:moss_block
setblock 270 125 325 minecraft:light[level=15]
setblock 270 125 333 minecraft:light[level=15]
setblock 270 125 341 minecraft:light[level=15]
setblock 270 125 349 minecraft:light[level=15]
setblock 270 125 357 minecraft:light[level=15]
setblock 274 125 323 minecraft:red_mushroom_block
fill 275 125 323 275 127 323 minecraft:moss_block
fill 275 125 327 275 128 327 minecraft:moss_block
setblock 275 125 331 minecraft:mushroom_stem
fill 275 125 332 275 126 334 minecraft:moss_block
setblock 276 125 325 minecraft:mushroom_stem
fill 276 125 326 276 128 326 minecraft:moss_block
setblock 276 125 330 minecraft:mushroom_stem
fill 276 125 331 276 128 331 minecraft:moss_block
setblock 276 125 335 minecraft:mushroom_stem
fill 276 125 336 276 128 336 minecraft:moss_block
fill 276 125 340 276 126 340 minecraft:red_mushroom_block
setblock 276 125 346 minecraft:red_mushroom_block
fill 276 125 351 276 125 354 minecraft:moss_block
setblock 276 125 355 minecraft:mushroom_stem
fill 276 125 356 276 128 356 minecraft:moss_block
fill 276 125 358 276 125 359 minecraft:moss_block
setblock 276 125 360 minecraft:mushroom_stem
fill 276 125 361 276 128 361 minecraft:moss_block
setblock 277 125 332 minecraft:red_mushroom_block
fill 277 125 333 277 147 333 minecraft:brown_terracotta
setblock 236 126 323 minecraft:moss_block
setblock 236 126 324 minecraft:mushroom_stem
fill 236 126 325 236 129 325 minecraft:moss_block
setblock 236 126 329 minecraft:mushroom_stem
fill 236 126 330 236 129 330 minecraft:moss_block
setblock 236 126 334 minecraft:mushroom_stem
fill 236 126 335 236 127 337 minecraft:moss_block
setblock 236 126 346 minecraft:red_mushroom_block
fill 236 126 347 236 127 347 minecraft:moss_block
setblock 236 126 349 minecraft:mushroom_stem
fill 236 126 350 236 126 353 minecraft:moss_block
setblock 236 126 354 minecraft:mushroom_stem
fill 236 126 355 236 129 355 minecraft:moss_block
setblock 236 126 358 minecraft:moss_block
setblock 236 126 359 minecraft:mushroom_stem
fill 236 126 360 236 129 360 minecraft:moss_block
setblock 237 126 323 minecraft:mushroom_stem
setblock 237 126 328 minecraft:mushroom_stem
fill 237 126 329 237 129 329 minecraft:moss_block
setblock 237 126 333 minecraft:mushroom_stem
fill 237 126 334 237 129 334 minecraft:moss_block
setblock 237 126 348 minecraft:mushroom_stem
fill 237 126 349 237 129 349 minecraft:moss_block
setblock 237 126 353 minecraft:mushroom_stem
fill 237 126 354 237 129 354 minecraft:moss_block
setblock 237 126 358 minecraft:mushroom_stem
fill 237 126 359 237 129 359 minecraft:moss_block
setblock 237 126 362 minecraft:moss_block
setblock 237 126 363 minecraft:mushroom_stem
fill 238 126 323 238 129 323 minecraft:moss_block
setblock 238 126 352 minecraft:mushroom_stem
fill 238 126 353 238 129 353 minecraft:moss_block
setblock 238 126 357 minecraft:mushroom_stem
fill 238 126 358 239 128 358 minecraft:moss_block
fill 238 126 360 238 126 361 minecraft:moss_block
setblock 238 126 362 minecraft:mushroom_stem
fill 238 126 363 238 129 363 minecraft:moss_block
setblock 239 126 332 minecraft:shroomlight
setblock 239 126 351 minecraft:mushroom_stem
fill 239 126 352 239 129 352 minecraft:moss_block
setblock 239 126 355 minecraft:moss_block
setblock 239 126 356 minecraft:mushroom_stem
fill 239 126 357 239 129 357 minecraft:moss_block
setblock 239 126 361 minecraft:mushroom_stem
fill 239 126 362 239 129 362 minecraft:moss_block
fill 240 126 361 242 127 361 minecraft:moss_block
setblock 242 126 323 minecraft:mushroom_stem
fill 242 126 343 242 133 344 minecraft:dirt
setblock 242 126 363 minecraft:mushroom_stem
setblock 243 126 323 minecraft:red_mushroom_block
fill 243 126 342 244 133 342 minecraft:dirt
fill 243 126 345 244 133 345 minecraft:dirt
setblock 243 126 362 minecraft:mushroom_stem
fill 243 126 363 243 129 363 minecraft:moss_block
fill 244 126 362 244 129 362 minecraft:moss_block
fill 245 126 343 245 133 344 minecraft:dirt
fill 259 126 323 259 128 323 minecraft:moss_block
setblock 261 126 324 minecraft:mushroom_stem
setblock 262 126 323 minecraft:mushroom_stem
fill 262 126 324 263 128 324 minecraft:moss_block
fill 263 126 323 263 129 323 minecraft:moss_block
setblock 263 126 363 minecraft:red_mushroom_block
setblock 267 126 323 minecraft:mushroom_stem
setblock 268 126 323 minecraft:red_mushroom_block
fill 269 126 363 269 127 363 minecraft:red_mushroom_block
fill 274 126 323 274 128 323 minecraft:moss_block
fill 275 126 326 275 129 326 minecraft:moss_block
setblock 275 126 330 minecraft:mushroom_stem
fill 275 126 331 275 129 331 minecraft:moss_block
setblock 275 126 335 minecraft:mushroom_stem
setblock 275 126 355 minecraft:mushroom_stem
fill 275 126 356 275 129 356 minecraft:moss_block
fill 275 126 363 276 126 363 minecraft:moss_block
setblock 276 126 324 minecraft:mushroom_stem
fill 276 126 325 276 129 325 minecraft:moss_block
setblock 276 126 329 minecraft:mushroom_stem
fill 276 126 330 276 129 330 minecraft:moss_block
setblock 276 126 333 minecraft:moss_block
setblock 276 126 334 minecraft:mushroom_stem
fill 276 126 335 276 129 335 minecraft:moss_block
fill 276 126 337 276 126 338 minecraft:moss_block
fill 276 126 350 276 126 353 minecraft:moss_block
setblock 276 126 354 minecraft:mushroom_stem
fill 276 126 355 276 129 355 minecraft:moss_block
setblock 276 126 358 minecraft:moss_block
setblock 276 126 359 minecraft:mushroom_stem
fill 276 126 360 276 129 360 minecraft:moss_block
fill 276 126 362 276 127 362 minecraft:moss_block
fill 277 126 332 277 143 332 minecraft:brown_terracotta
setblock 235 127 352 minecraft:red_mushroom_block
fill 235 127 353 235 144 354 minecraft:brown_terracotta
setblock 236 127 323 minecraft:mushroom_stem
fill 236 127 324 236 130 324 minecraft:moss_block
setblock 236 127 328 minecraft:mushroom_stem
fill 236 127 329 236 130 329 minecraft:moss_block
setblock 236 127 332 minecraft:moss_block
setblock 236 127 333 minecraft:mushroom_stem
fill 236 127 334 236 130 334 minecraft:moss_block
setblock 236 127 338 minecraft:mushroom_stem
fill 236 127 339 236 130 339 minecraft:moss_block
fill 236 127 346 236 128 346 minecraft:moss_block
setblock 236 127 348 minecraft:mushroom_stem
fill 236 127 349 236 127 352 minecraft:moss_block
setblock 236 127 353 minecraft:mushroom_stem
fill 236 127 354 236 130 354 minecraft:moss_block
setblock 236 127 358 minecraft:mushroom_stem
fill 236 127 359 236 130 359 minecraft:moss_block
setblock 236 127 362 minecraft:moss_block
setblock 236 127 363 minecraft:mushroom_stem
fill 237 127 323 237 130 323 minecraft:moss_block
fill 237 127 328 237 128 328 minecraft:moss_block
setblock 237 127 332 minecraft:mushroom_stem
fill 237 127 333 237 130 333 minecraft:moss_block
fill 237 127 335 237 127 336 minecraft:moss_block
setblock 237 127 337 minecraft:mushroom_stem
fill 237 127 348 237 130 348 minecraft:moss_block
setblock 237 127 351 minecraft:moss_block
setblock 237 127 352 minecraft:mushroom_stem
fill 237 127 353 237 130 353 minecraft:moss_block
setblock 237 127 356 minecraft:moss_block
setblock 237 127 357 minecraft:mushroom_stem
fill 237 127 358 237 130 358 minecraft:moss_block
setblock 237 127 362 minecraft:mushroom_stem
fill 237 127 363 237 130 363 minecraft:moss_block
fill 238 127 349 238 128 349 minecraft:moss_block
setblock 238 127 351 minecraft:mushroom_stem
fill 238 127 352 238 130 352 minecraft:moss_block
setblock 238 127 356 minecraft:mushroom_stem
fill 238 127 357 238 130 357 minecraft:moss_block
setblock 238 127 360 minecraft:moss_block
setblock 238 127 361 minecraft:mushroom_stem
fill 238 127 362 238 130 362 minecraft:moss_block
fill 239 127 332 239 131 332 minecraft:mushroom_stem
fill 239 127 351 239 129 351 minecraft:moss_block
setblock 239 127 355 minecraft:mushroom_stem
fill 239 127 356 240 129 356 minecraft:moss_block
setblock 239 127 359 minecraft:moss_block
setblock 239 127 360 minecraft:mushroom_stem
fill 239 127 361 239 130 361 minecraft:moss_block
setblock 240 127 353 minecraft:moss_block
setblock 240 127 354 minecraft:mushroom_stem
fill 240 127 355 240 130 355 minecraft:moss_block
fill 240 127 357 240 128 357 minecraft:moss_block
fill 240 127 360 241 129 360 minecraft:moss_block
setblock 241 127 323 minecraft:mushroom_stem
setblock 241 127 363 minecraft:mushroom_stem
fill 242 127 323 242 128 323 minecraft:moss_block
fill 242 127 342 242 133 342 minecraft:dirt
fill 242 127 345 242 133 345 minecraft:dirt
setblock 242 127 362 minecraft:mushroom_stem
fill 242 127 363 242 130 363 minecraft:moss_block
fill 243 127 362 243 130 362 minecraft:moss_block
fill 245 127 342 245 133 342 minecraft:dirt
setblock 250 127 363 minecraft:red_mushroom_block
fill 258 127 323 258 129 323 minecraft:moss_block
fill 259 127 363 260 127 363 minecraft:moss_block
setblock 260 127 324 minecraft:mushroom_stem
setblock 261 127 323 minecraft:mushroom_stem
fill 261 127 324 261 130 324 minecraft:moss_block
setblock 261 127 363 minecraft:mushroom_stem
setblock 262 127 322 minecraft:shroomlight
fill 262 127 323 262 130 323 minecraft:moss_block
fill 262 127 363 263 129 363 minecraft:moss_block
fill 263 127 322 263 144 322 minecraft:brown_terracotta
setblock 266 127 323 minecraft:mushroom_stem
fill 267 127 323 267 130 323 minecraft:moss_block
fill 272 127 323 273 129 323 minecraft:moss_block
fill 274 127 363 275 127 363 minecraft:moss_block
fill 275 127 325 275 130 325 minecraft:moss_block
setblock 275 127 329 minecraft:mushroom_stem
fill 275 127 330 275 130 330 minecraft:moss_block
fill 275 127 332 275 127 333 minecraft:moss_block
setblock 275 127 334 minecraft:mushroom_stem
fill 275 127 335 275 129 336 minecraft:moss_block
setblock 275 127 353 minecraft:moss_block
setblock 275 127 354 minecraft:mushroom_stem
fill 275 127 355 275 130 355 minecraft:moss_block
fill 275 127 357 275 127 358 minecraft:moss_block
setblock 275 127 359 minecraft:mushroom_stem
fill 275 127 360 275 129 361 minecraft:moss_block
setblock 276 127 323 minecraft:mushroom_stem
fill 276 127 324 276 130 324 minecraft:moss_block
setblock 276 127 328 minecraft:mushroom_stem
fill 276 127 329 276 130 329 minecraft:moss_block
setblock 276 127 333 minecraft:mushroom_stem
fill 276 127 334 276 130 334 minecraft:moss_block
setblock 276 127 337 minecraft:moss_block
setblock 276 127 338 minecraft:mushroom_stem
fill 276 127 339 276 130 339 minecraft:moss_block
fill 276 127 349 276 127 352 minecraft:moss_block
setblock 276 127 353 minecraft:mushroom_stem
fill 276 127 354 276 130 354 minecraft:moss_block
setblock 276 127 358 minecraft:mushroom_stem
fill 276 127 359 276 130 359 minecraft:moss_block
setblock 276 127 363 minecraft:mushroom_stem
fill 235 128 352 235 147 352 minecraft:brown_terracotta
fill 236 128 323 236 131 323 minecraft:moss_block
setblock 236 128 327 minecraft:mushroom_stem
fill 236 128 328 236 131 328 minecraft:moss_block
setblock 236 128 331 minecraft:moss_block
setblock 236 128 332 minecraft:mushroom_stem
fill 236 128 333 236 131 333 minecraft:moss_block
fill 236 128 335 236 128 336 minecraft:moss_block
setblock 236 128 337 minecraft:mushroom_stem
fill 236 128 338 237 130 338 minecraft:moss_block
fill 236 128 340 236 128 341 minecraft:moss_block
setblock 236 128 342 minecraft:mushroom_stem
fill 236 128 343 236 129 345 minecraft:moss_block
setblock 236 128 347 minecraft:mushroom_stem
fill 236 128 348 236 128 351 minecraft:moss_block
setblock 236 128 352 minecraft:mushroom_stem
fill 236 128 353 236 131 353 minecraft:moss_block
setblock 236 128 357 minecraft:mushroom_stem
fill 236 128 358 236 131 358 minecraft:moss_block
setblock 236 128 361 minecraft:moss_block
setblock 236 128 362 minecraft:mushroom_stem
fill 236 128 363 236 131 363 minecraft:moss_block
setblock 237 128 331 minecraft:mushroom_stem
fill 237 128 332 237 131 332 minecraft:moss_block
setblock 237 128 335 minecraft:moss_block
setblock 237 128 336 minecraft:mushroom_stem
fill 237 128 337 237 131 337 minecraft:moss_block
fill 237 128 339 237 129 339 minecraft:moss_block
fill 237 128 347 237 131 347 minecraft:moss_block
setblock 237 128 350 minecraft:moss_block
setblock 237 128 351 minecraft:mushroom_stem
fill 237 128 352 237 131 352 minecraft:moss_block
setblock 237 128 356 minecraft:mushroom_stem
fill 237 128 357 237 131 357 minecraft:moss_block
setblock 237 128 361 minecraft:mushroom_stem
fill 237 128 362 237 131 362 minecraft:moss_block
fill 238 128 333 238 128 334 minecraft:moss_block
setblock 238 128 335 minecraft:mushroom_stem
setblock 238 128 350 minecraft:mushroom_stem
fill 238 128 351 238 131 351 minecraft:moss_block
setblock 238 128 354 minecraft:moss_block
setblock 238 128 355 minecraft:mushroom_stem
fill 238 128 356 238 131 356 minecraft:moss_block
setblock 238 128 360 minecraft:mushroom_stem
fill 238 128 361 238 131 361 minecraft:moss_block
setblock 239 128 354 minecraft:mushroom_stem
fill 239 128 355 239 131 355 minecraft:moss_block
setblock 239 128 359 minecraft:mushroom_stem
fill 239 128 360 239 131 360 minecraft:moss_block
setblock 240 128 323 minecraft:mushroom_stem
setblock 240 128 353 minecraft:mushroom_stem
fill 240 128 354 240 129 354 minecraft:moss_block
setblock 240 128 358 minecraft:mushroom_stem
fill 240 128 361 241 128 361 minecraft:moss_block
setblock 240 128 363 minecraft:mushroom_stem
fill 241 128 323 241 130 323 minecraft:moss_block
fill 241 128 343 241 133 344 minecraft:dirt
setblock 241 128 362 minecraft:mushroom_stem
fill 241 128 363 241 131 363 minecraft:moss_block
setblock 242 128 361 minecraft:mushroom_stem
fill 242 128 362 242 131 362 minecraft:moss_block
fill 243 128 341 244 133 341 minecraft:dirt
fill 243 128 346 244 133 346 minecraft:dirt
fill 243 128 361 243 130 361 minecraft:moss_block
fill 245 128 345 245 133 345 minecraft:dirt
setblock 245 128 363 minecraft:mushroom_stem
fill 246 128 343 246 133 344 minecraft:dirt
setblock 256 128 323 minecraft:red_mushroom_block
setblock 256 128 363 minecraft:red_mushroom_block
fill 257 128 323 257 130 323 minecraft:moss_block
fill 257 128 363 259 128 363 minecraft:moss_block
setblock 259 128 324 minecraft:mushroom_stem
setblock 260 128 323 minecraft:mushroom_stem
fill 260 128 324 260 131 324 minecraft:moss_block
setblock 260 128 363 minecraft:mushroom_stem
fill 261 128 323 261 131 323 minecraft:moss_block
fill 261 128 363 261 131 363 minecraft:moss_block
fill 262 128 322 262 147 322 minecraft:brown_terracotta
setblock 264 128 363 minecraft:moss_block
setblock 265 128 323 minecraft:mushroom_stem
fill 266 128 323 266 131 323 minecraft:moss_block
fill 271 128 323 271 131 323 minecraft:moss_block
fill 272 128 363 274 128 363 minecraft:moss_block
fill 274 128 362 275 128 362 minecraft:moss_block
setblock 275 128 323 minecraft:mushroom_stem
fill 275 128 324 275 131 324 minecraft:moss_block
setblock 275 128 328 minecraft:mushroom_stem
fill 275 128 329 275 131 329 minecraft:moss_block
setblock 275 128 332 minecraft:moss_block
setblock 275 128 333 minecraft:mushroom_stem
fill 275 128 334 275 131 334 minecraft:moss_block
setblock 275 128 337 minecraft:moss_block
setblock 275 128 352 minecraft:moss_block
setblock 275 128 353 minecraft:mushroom_stem
fill 275 128 354 275 131 354 minecraft:moss_block
setblock 275 128 357 minecraft:moss_block
setblock 275 128 358 minecraft:mushroom_stem
fill 275 128 359 275 131 359 minecraft:moss_block
setblock 275 128 363 minecraft:mushroom_stem
fill 276 128 323 276 131 323 minecraft:moss_block
setblock 276 128 327 minecraft:mushroom_stem
fill 276 128 328 276 131 328 minecraft:moss_block
setblock 276 128 332 minecraft:mushroom_stem
fill 276 128 333 276 131 333 minecraft:moss_block
setblock 276 128 337 minecraft:mushroom_stem
fill 276 128 338 276 131 338 minecraft:moss_block
fill 276 128 340 276 129 340 minecraft:moss_block
setblock 276 128 347 minecraft:red_mushroom_block
fill 276 128 349 276 128 351 minecraft:moss_block
setblock 276 128 352 minecraft:mushroom_stem
fill 276 128 353 276 131 353 minecraft:moss_block
setblock 276 128 357 minecraft:mushroom_stem
fill 276 128 358 276 131 358 minecraft:moss_block
setblock 276 128 362 minecraft:mushroom_stem
fill 276 128 363 276 131 363 minecraft:moss_block
setblock 235 129 327 minecraft:red_mushroom_block
setblock 236 129 326 minecraft:mushroom_stem
fill 236 129 327 236 131 327 minecraft:moss_block
setblock 236 129 331 minecraft:mushroom_stem
fill 236 129 332 236 132 332 minecraft:moss_block
setblock 236 129 335 minecraft:moss_block
setblock 236 129 336 minecraft:mushroom_stem
fill 236 129 337 236 132 337 minecraft:moss_block
setblock 236 129 340 minecraft:moss_block
setblock 236 129 341 minecraft:mushroom_stem
fill 236 129 342 236 132 342 minecraft:moss_block
setblock 236 129 346 minecraft:mushroom_stem
fill 236 129 347 236 129 350 minecraft:moss_block
setblock 236 129 351 minecraft:mushroom_stem
fill 236 129 352 236 132 352 minecraft:moss_block
setblock 236 129 356 minecraft:mushroom_stem
fill 236 129 357 236 132 357 minecraft:moss_block
setblock 236 129 361 minecraft:mushroom_stem
fill 236 129 362 236 132 362 minecraft:moss_block
setblock 237 129 330 minecraft:mushroom_stem
fill 237 129 331 237 131 331 minecraft:moss_block
setblock 237 129 335 minecraft:mushroom_stem
fill 237 129 336 238 131 336 minecraft:moss_block
setblock 237 129 340 minecraft:mushroom_stem
fill 237 129 341 237 132 341 minecraft:moss_block
setblock 237 129 350 minecraft:mushroom_stem
fill 237 129 351 237 132 351 minecraft:moss_block
setblock 237 129 355 minecraft:mushroom_stem
fill 237 129 356 237 132 356 minecraft:moss_block
setblock 237 129 360 minecraft:mushroom_stem
fill 237 129 361 237 132 361 minecraft:moss_block
setblock 238 129 325 minecraft:light[level=12]
setblock 238 129 332 minecraft:light[level=12]
setblock 238 129 333 minecraft:moss_block
setblock 238 129 334 minecraft:mushroom_stem
fill 238 129 335 238 131 335 minecraft:moss_block
fill 238 129 337 238 130 337 minecraft:moss_block
setblock 238 129 339 minecraft:light[level=12]
setblock 238 129 346 minecraft:light[level=12]
setblock 238 129 349 minecraft:mushroom_stem
fill 238 129 350 238 131 350 minecraft:moss_block
setblock 238 129 354 minecraft:mushroom_stem
fill 238 129 355 238 132 355 minecraft:moss_block
setblock 238 129 358 minecraft:moss_block
setblock 238 129 359 minecraft:mushroom_stem
fill 238 129 360 238 132 360 minecraft:moss_block
setblock 239 129 323 minecraft:mushroom_stem
setblock 239 129 353 minecraft:mushroom_stem
fill 239 129 354 239 132 354 minecraft:moss_block
setblock 239 129 358 minecraft:mushroom_stem
fill 239 129 359 239 132 359 minecraft:moss_block
setblock 239 129 363 minecraft:mushroom_stem
fill 240 129 323 240 131 323 minecraft:moss_block
setblock 240 129 357 minecraft:mushroom_stem
fill 240 129 358 240 130 358 minecraft:moss_block
setblock 240 129 361 minecraft:moss_block
setblock 240 129 362 minecraft:mushroom_stem
fill 240 129 363 240 132 363 minecraft:moss_block
fill 241 129 342 241 133 342 minecraft:dirt
fill 241 129 345 241 133 345 minecraft:dirt
setblock 241 129 361 minecraft:mushroom_stem
fill 241 129 362 241 132 362 minecraft:moss_block
fill 242 129 341 242 133 341 minecraft:dirt
fill 242 129 346 242 133 346 minecraft:dirt
fill 242 129 361 242 131 361 minecraft:moss_block
setblock 244 129 363 minecraft:mushroom_stem
setblock 245 129 325 minecraft:light[level=12]
setblock 245 129 332 minecraft:light[level=12]
setblock 245 129 339 minecraft:light[level=12]
fill 245 129 341 245 133 341 minecraft:dirt
setblock 245 129 346 minecraft:light[level=12]
setblock 245 129 353 minecraft:light[level=12]
setblock 245 129 360 minecraft:light[level=12]
fill 245 129 363 245 131 363 minecraft:moss_block
fill 246 129 342 246 133 342 minecraft:dirt
setblock 250 129 323 minecraft:red_mushroom_block
setblock 252 129 325 minecraft:light[level=12]
setblock 252 129 332 minecraft:light[level=12]
setblock 252 129 339 minecraft:light[level=12]
setblock 252 129 346 minecraft:light[level=12]
setblock 252 129 353 minecraft:light[level=12]
setblock 252 129 360 minecraft:light[level=12]
fill 256 129 323 256 131 323 minecraft:moss_block
fill 256 129 363 258 129 363 minecraft:moss_block
setblock 259 129 323 minecraft:mushroom_stem
fill 259 129 324 259 132 324 minecraft:moss_block
setblock 259 129 325 minecraft:light[level=12]
setblock 259 129 332 minecraft:light[level=12]
setblock 259 129 339 minecraft:light[level=12]
setblock 259 129 346 minecraft:light[level=12]
setblock 259 129 353 minecraft:light[level=12]
setblock 259 129 360 minecraft:light[level=12]
setblock 259 129 362 minecraft:moss_block
setblock 259 129 363 minecraft:mushroom_stem
fill 260 129 323 260 132 323 minecraft:moss_block
setblock 260 129 362 minecraft:mushroom_stem
fill 260 129 363 260 132 363 minecraft:moss_block
fill 261 129 362 261 132 362 minecraft:moss_block
setblock 262 129 324 minecraft:moss_block
setblock 263 129 324 minecraft:mushroom_stem
setblock 264 129 323 minecraft:mushroom_stem
setblock 264 129 363 minecraft:mushroom_stem
fill 265 129 323 265 132 323 minecraft:moss_block
fill 265 129 363 265 132 363 minecraft:moss_block
setblock 266 129 325 minecraft:light[level=12]
setblock 266 129 332 minecraft:light[level=12]
setblock 266 129 339 minecraft:light[level=12]
setblock 266 129 346 minecraft:light[level=12]
setblock 266 129 353 minecraft:light[level=12]
setblock 266 129 360 minecraft:light[level=12]
setblock 268 129 323 minecraft:moss_block
setblock 269 129 323 minecraft:red_mushroom_block
fill 270 129 323 270 132 323 minecraft:moss_block
fill 271 129 363 273 129 363 minecraft:moss_block
setblock 273 129 325 minecraft:light[level=12]
setblock 273 129 332 minecraft:light[level=12]
setblock 273 129 339 minecraft:light[level=12]
setblock 273 129 353 minecraft:light[level=12]
setblock 273 129 360 minecraft:light[level=12]
fill 273 129 362 274 129 362 minecraft:moss_block
setblock 274 129 323 minecraft:mushroom_stem
setblock 274 129 333 minecraft:mushroom_stem
setblock 274 129 357 minecraft:moss_block
setblock 274 129 358 minecraft:mushroom_stem
fill 274 129 359 274 132 359 minecraft:moss_block
setblock 274 129 363 minecraft:mushroom_stem
fill 275 129 323 275 132 323 minecraft:moss_block
setblock 275 129 327 minecraft:mushroom_stem
fill 275 129 328 275 131 328 minecraft:moss_block
setblock 275 129 332 minecraft:mushroom_stem
fill 275 129 333 275 132 333 minecraft:moss_block
setblock 275 129 337 minecraft:mushroom_stem
fill 275 129 338 275 132 338 minecraft:moss_block
setblock 275 129 352 minecraft:mushroom_stem
fill 275 129 353 275 132 353 minecraft:moss_block
setblock 275 129 357 minecraft:mushroom_stem
fill 275 129 358 275 132 358 minecraft:moss_block
setblock 275 129 362 minecraft:mushroom_stem
fill 275 129 363 275 132 363 minecraft:moss_block
setblock 276 129 326 minecraft:mushroom_stem
fill 276 129 327 276 132 327 minecraft:moss_block
setblock 276 129 331 minecraft:mushroom_stem
fill 276 129 332 276 132 332 minecraft:moss_block
setblock 276 129 336 minecraft:mushroom_stem
fill 276 129 337 276 132 337 minecraft:moss_block
setblock 276 129 341 minecraft:mushroom_stem
fill 276 129 349 276 129 350 minecraft:moss_block
setblock 276 129 351 minecraft:mushroom_stem
fill 276 129 352 276 132 352 minecraft:moss_block
setblock 276 129 356 minecraft:mushroom_stem
fill 276 129 357 276 132 357 minecraft:moss_block
setblock 276 129 361 minecraft:mushroom_stem
fill 276 129 362 276 132 362 minecraft:moss_block
fill 235 130 327 235 145 327 minecraft:brown_terracotta
setblock 236 130 325 minecraft:mushroom_stem
fill 236 130 326 236 131 326 minecraft:moss_block
setblock 236 130 330 minecraft:mushroom_stem
fill 236 130 331 236 133 331 minecraft:moss_block
setblock 236 130 335 minecraft:mushroom_stem
fill 236 130 336 236 133 336 minecraft:moss_block
setblock 236 130 340 minecraft:mushroom_stem
fill 236 130 341 236 133 341 minecraft:moss_block
fill 236 130 343 236 130 344 minecraft:moss_block
setblock 236 130 345 minecraft:mushroom_stem
fill 236 130 346 236 130 349 minecraft:moss_block
setblock 236 130 350 minecraft:mushroom_stem
fill 236 130 351 236 133 351 minecraft:moss_block
setblock 236 130 355 minecraft:mushroom_stem
fill 236 130 356 236 133 356 minecraft:moss_block
setblock 236 130 360 minecraft:mushroom_stem
fill 236 130 361 236 133 361 minecraft:moss_block
setblock 237 130 330 minecraft:moss_block
setblock 237 130 334 minecraft:mushroom_stem
fill 237 130 335 237 133 335 minecraft:moss_block
setblock 237 130 339 minecraft:mushroom_stem
fill 237 130 340 237 133 340 minecraft:moss_block
fill 237 130 342 237 130 343 minecraft:moss_block
setblock 237 130 344 minecraft:mushroom_stem
fill 237 130 345 237 132 346 minecraft:moss_block
setblock 237 130 349 minecraft:mushroom_stem
fill 237 130 350 237 133 350 minecraft:moss_block
setblock 237 130 354 minecraft:mushroom_stem
fill 237 130 355 237 133 355 minecraft:moss_block
setblock 237 130 359 minecraft:mushroom_stem
fill 237 130 360 237 133 360 minecraft:moss_block
setblock 238 130 323 minecraft:mushroom_stem
setblock 238 130 334 minecraft:moss_block
setblock 238 130 338 minecraft:mushroom_stem
fill 238 130 339 238 133 339 minecraft:moss_block
setblock 238 130 349 minecraft:moss_block
setblock 238 130 353 minecraft:mushroom_stem
fill 238 130 354 238 133 354 minecraft:moss_block
setblock 238 130 358 minecraft:mushroom_stem
fill 238 130 359 238 133 359 minecraft:moss_block
setblock 238 130 363 minecraft:mushroom_stem
fill 239 130 323 239 133 323 minecraft:moss_block
setblock 239 130 352 minecraft:mushroom_stem
fill 239 130 353 239 131 353 minecraft:moss_block
setblock 239 130 356 minecraft:moss_block
setblock 239 130 357 minecraft:mushroom_stem
fill 239 130 358 239 133 358 minecraft:moss_block
setblock 239 130 362 minecraft:mushroom_stem
fill 239 130 363 239 133 363 minecraft:moss_block
fill 240 130 343 240 133 344 minecraft:dirt
setblock 240 130 356 minecraft:mushroom_stem
setblock 240 130 357 minecraft:moss_block
setblock 240 130 360 minecraft:moss_block
setblock 240 130 361 minecraft:mushroom_stem
fill 240 130 362 240 133 362 minecraft:moss_block
fill 241 130 341 241 133 341 minecraft:dirt
fill 241 130 346 241 133 346 minecraft:dirt
setblock 241 130 360 minecraft:mushroom_stem
fill 241 130 361 241 133 361 minecraft:moss_block
fill 243 130 340 244 133 340 minecraft:dirt
fill 243 130 347 244 133 347 minecraft:dirt
setblock 243 130 363 minecraft:mushroom_stem
setblock 244 130 323 minecraft:red_mushroom_block
setblock 244 130 362 minecraft:mushroom_stem
fill 244 130 363 244 132 363 minecraft:moss_block
fill 246 130 341 246 133 341 minecraft:dirt
fill 247 130 343 247 133 344 minecraft:dirt
fill 248 130 356 249 133 360 minecraft:red_mushroom_block
setblock 249 130 363 minecraft:red_mushroom_block
fill 250 130 356 252 133 357 minecraft:red_mushroom_block
setblock 250 130 358 minecraft:mushroom_stem
fill 250 130 359 252 133 360 minecraft:red_mushroom_block
fill 251 130 358 252 133 358 minecraft:red_mushroom_block
fill 255 130 363 257 130 363 minecraft:moss_block
fill 257 130 362 258 130 362 minecraft:moss_block
setblock 258 130 323 minecraft:mushroom_stem
fill 258 130 324 258 133 324 minecraft:moss_block
setblock 258 130 363 minecraft:mushroom_stem
fill 259 130 323 259 133 323 minecraft:moss_block
setblock 259 130 362 minecraft:mushroom_stem
fill 259 130 363 259 133 363 minecraft:moss_block
fill 260 130 362 260 133 362 minecraft:moss_block
setblock 262 130 324 minecraft:mushroom_stem
setblock 262 130 363 minecraft:moss_block
setblock 263 130 323 minecraft:mushroom_stem
setblock 263 130 363 minecraft:mushroom_stem
fill 264 130 323 264 133 323 minecraft:moss_block
fill 264 130 363 264 133 363 minecraft:moss_block
setblock 268 130 323 minecraft:mushroom_stem
setblock 268 130 363 minecraft:red_mushroom_block
fill 269 130 323 269 133 323 minecraft:moss_block
fill 269 130 363 272 130 363 minecraft:moss_block
setblock 272 130 323 minecraft:moss_block
fill 272 130 362 273 130 362 minecraft:moss_block
setblock 273 130 323 minecraft:mushroom_stem
setblock 273 130 363 minecraft:mushroom_stem
fill 274 130 323 274 132 324 minecraft:moss_block
setblock 274 130 356 minecraft:moss_block
setblock 274 130 357 minecraft:mushroom_stem
fill 274 130 358 274 133 358 minecraft:moss_block
fill 274 130 360 274 130 361 minecraft:moss_block
setblock 274 130 362 minecraft:mushroom_stem
fill 274 130 363 274 133 363 minecraft:moss_block
setblock 275 130 326 minecraft:mushroom_stem
fill 275 130 327 275 131 327 minecraft:moss_block
setblock 275 130 331 minecraft:mushroom_stem
fill 275 130 332 275 132 332 minecraft:moss_block
setblock 275 130 335 minecraft:moss_block
setblock 275 130 336 minecraft:mushroom_stem
fill 275 130 337 275 133 337 minecraft:moss_block
fill 275 130 339 275 131 339 minecraft:moss_block
fill 275 130 352 275 131 352 minecraft:moss_block
setblock 275 130 356 minecraft:mushroom_stem
fill 275 130 357 275 133 357 minecraft:moss_block
setblock 275 130 360 minecraft:moss_block
setblock 275 130 361 minecraft:mushroom_stem
fill 275 130 362 275 133 362 minecraft:moss_block
setblock 276 130 325 minecraft:mushroom_stem
fill 276 130 326 276 133 326 minecraft:moss_block
setblock 276 130 330 minecraft:mushroom_stem
fill 276 130 331 276 133 331 minecraft:moss_block
setblock 276 130 335 minecraft:mushroom_stem
fill 276 130 336 276 133 336 minecraft:moss_block
setblock 276 130 340 minecraft:mushroom_stem
fill 276 130 341 276 131 343 minecraft:moss_block
setblock 276 130 349 minecraft:moss_block
setblock 276 130 350 minecraft:mushroom_stem
fill 276 130 351 276 133 351 minecraft:moss_block
setblock 276 130 355 minecraft:mushroom_stem
fill 276 130 356 276 133 356 minecraft:moss_block
setblock 276 130 360 minecraft:mushroom_stem
fill 276 130 361 276 133 361 minecraft:moss_block
setblock 277 130 334 minecraft:red_mushroom_block
setblock 236 131 324 minecraft:mushroom_stem
fill 236 131 325 236 132 325 minecraft:moss_block
setblock 236 131 329 minecraft:mushroom_stem
fill 236 131 330 236 132 330 minecraft:moss_block
setblock 236 131 334 minecraft:mushroom_stem
fill 236 131 335 236 134 335 minecraft:moss_block
setblock 236 131 338 minecraft:moss_block
setblock 236 131 339 minecraft:mushroom_stem
fill 236 131 340 236 134 340 minecraft:moss_block
setblock 236 131 343 minecraft:moss_block
setblock 236 131 344 minecraft:mushroom_stem
fill 236 131 345 236 131 348 minecraft:moss_block
setblock 236 131 349 minecraft:mushroom_stem
fill 236 131 350 236 134 350 minecraft:moss_block
setblock 236 131 354 minecraft:mushroom_stem
fill 236 131 355 236 134 355 minecraft:moss_block
setblock 236 131 359 minecraft:mushroom_stem
fill 236 131 360 236 134 360 minecraft:moss_block
setblock 237 131 323 minecraft:mushroom_stem
setblock 237 131 333 minecraft:mushroom_stem
fill 237 131 334 237 133 334 minecraft:moss_block
setblock 237 131 338 minecraft:mushroom_stem
fill 237 131 339 237 134 339 minecraft:moss_block
setblock 237 131 342 minecraft:moss_block
setblock 237 131 343 minecraft:mushroom_stem
fill 237 131 344 237 134 344 minecraft:moss_block
setblock 237 131 348 minecraft:mushroom_stem
fill 237 131 349 237 134 349 minecraft:moss_block
setblock 237 131 353 minecraft:mushroom_stem
fill 237 131 354 237 134 354 minecraft:moss_block
setblock 237 131 358 minecraft:mushroom_stem
fill 237 131 359 237 134 359 minecraft:moss_block
setblock 237 131 363 minecraft:mushroom_stem
fill 238 131 323 238 134 323 minecraft:moss_block
setblock 238 131 337 minecraft:mushroom_stem
fill 238 131 338 238 133 338 minecraft:moss_block
fill 238 131 340 238 132 340 minecraft:moss_block
setblock 238 131 352 minecraft:mushroom_stem
fill 238 131 353 238 133 353 minecraft:moss_block
setblock 238 131 357 minecraft:mushroom_stem
fill 238 131 358 238 134 358 minecraft:moss_block
setblock 238 131 362 minecraft:mushroom_stem
fill 238 131 363 238 134 363 minecraft:moss_block
setblock 239 131 356 minecraft:mushroom_stem
fill 239 131 357 239 133 357 minecraft:moss_block
setblock 239 131 361 minecraft:mushroom_stem
fill 239 131 362 239 134 362 minecraft:moss_block
fill 240 131 342 240 133 342 minecraft:dirt
fill 240 131 345 240 133 345 minecraft:dirt
setblock 240 131 360 minecraft:mushroom_stem
fill 240 131 361 240 134 361 minecraft:moss_block
fill 241 131 340 242 133 340 minecraft:dirt
setblock 241 131 360 minecraft:moss_block
fill 242 131 347 242 133 347 minecraft:dirt
setblock 242 131 363 minecraft:mushroom_stem
setblock 243 131 362 minecraft:mushroom_stem
fill 243 131 363 243 134 363 minecraft:moss_block
fill 244 131 356 246 132 360 minecraft:dirt
fill 245 131 340 245 133 340 minecraft:dirt
fill 246 131 361 246 131 362 minecraft:dirt
fill 247 131 342 247 133 342 minecraft:dirt
fill 247 131 356 247 132 356 minecraft:dirt
fill 247 131 357 247 132 359 minecraft:red_mushroom_block
fill 247 131 360 247 132 360 minecraft:dirt
fill 249 131 355 251 132 355 minecraft:red_mushroom_block
fill 249 131 361 251 132 361 minecraft:red_mushroom_block
fill 250 131 358 250 134 358 minecraft:red_mushroom_block
fill 253 131 357 253 132 359 minecraft:red_mushroom_block
fill 254 131 363 256 131 363 minecraft:moss_block
fill 255 131 323 255 132 323 minecraft:moss_block
fill 256 131 362 257 131 362 minecraft:moss_block
setblock 257 131 323 minecraft:mushroom_stem
setblock 257 131 363 minecraft:mushroom_stem
fill 258 131 323 258 134 323 minecraft:moss_block
setblock 258 131 362 minecraft:mushroom_stem
fill 258 131 363 258 134 363 minecraft:moss_block
fill 258 131 364 259 147 364 minecraft:brown_terracotta
fill 259 131 362 259 134 362 minecraft:moss_block
setblock 260 131 364 minecraft:red_mushroom_block
setblock 261 131 324 minecraft:mushroom_stem
setblock 262 131 323 minecraft:mushroom_stem
setblock 262 131 363 minecraft:mushroom_stem
fill 263 131 323 263 134 323 minecraft:moss_block
fill 263 131 363 263 134 363 minecraft:moss_block
setblock 266 131 363 minecraft:moss_block
setblock 267 131 323 minecraft:mushroom_stem
setblock 268 131 323 minecraft:moss_block
fill 268 131 363 271 131 363 minecraft:moss_block
fill 271 131 362 272 131 362 minecraft:moss_block
setblock 272 131 323 minecraft:mushroom_stem
setblock 272 131 363 minecraft:mushroom_stem
fill 273 131 323 273 134 323 minecraft:moss_block
setblock 273 131 361 minecraft:moss_block
setblock 273 131 362 minecraft:mushroom_stem
fill 273 131 363 273 134 363 minecraft:moss_block
setblock 274 131 356 minecraft:mushroom_stem
fill 274 131 357 274 134 357 minecraft:moss_block
setblock 274 131 360 minecraft:moss_block
setblock 274 131 361 minecraft:mushroom_stem
fill 274 131 362 274 134 362 minecraft:moss_block
setblock 275 131 325 minecraft:mushroom_stem
setblock 275 131 326 minecraft:moss_block
setblock 275 131 330 minecraft:mushroom_stem
fill 275 131 331 275 132 331 minecraft:moss_block
setblock 275 131 335 minecraft:mushroom_stem
fill 275 131 336 275 134 336 minecraft:moss_block
setblock 275 131 355 minecraft:mushroom_stem
fill 275 131 356 275 134 356 minecraft:moss_block
setblock 275 131 360 minecraft:mushroom_stem
fill 275 131 361 275 134 361 minecraft:moss_block
setblock 276 131 324 minecraft:mushroom_stem
fill 276 131 325 276 134 325 minecraft:moss_block
setblock 276 131 329 minecraft:mushroom_stem
fill 276 131 330 276 134 330 minecraft:moss_block
setblock 276 131 334 minecraft:mushroom_stem
fill 276 131 335 276 134 335 minecraft:moss_block
setblock 276 131 339 minecraft:mushroom_stem
fill 276 131 340 276 134 340 minecraft:moss_block
setblock 276 131 348 minecraft:red_mushroom_block
setblock 276 131 349 minecraft:mushroom_stem
fill 276 131 350 276 134 350 minecraft:moss_block
setblock 276 131 354 minecraft:mushroom_stem
fill 276 131 355 276 134 355 minecraft:moss_block
setblock 276 131 359 minecraft:mushroom_stem
fill 276 131 360 276 134 360 minecraft:moss_block
fill 277 131 334 277 143 334 minecraft:brown_terracotta
setblock 277 131 336 minecraft:shroomlight
setblock 236 132 323 minecraft:mushroom_stem
fill 236 132 324 236 135 324 minecraft:moss_block
setblock 236 132 329 minecraft:moss_block
setblock 236 132 333 minecraft:mushroom_stem
fill 236 132 334 236 135 334 minecraft:moss_block
setblock 236 132 338 minecraft:mushroom_stem
fill 236 132 339 236 135 339 minecraft:moss_block
setblock 236 132 343 minecraft:mushroom_stem
fill 236 132 344 236 132 347 minecraft:moss_block
setblock 236 132 348 minecraft:mushroom_stem
fill 236 132 349 236 135 349 minecraft:moss_block
setblock 236 132 353 minecraft:mushroom_stem
fill 236 132 354 236 135 354 minecraft:moss_block
setblock 236 132 358 minecraft:mushroom_stem
fill 236 132 359 236 135 359 minecraft:moss_block
setblock 236 132 363 minecraft:mushroom_stem
fill 237 132 323 237 135 323 minecraft:moss_block
fill 237 132 331 241 132 333 minecraft:red_mushroom_block
setblock 237 132 336 minecraft:moss_block
setblock 237 132 337 minecraft:mushroom_stem
fill 237 132 338 237 135 338 minecraft:moss_block
setblock 237 132 342 minecraft:mushroom_stem
fill 237 132 343 237 135 343 minecraft:moss_block
setblock 237 132 347 minecraft:mushroom_stem
fill 237 132 348 237 134 348 minecraft:moss_block
setblock 237 132 352 minecraft:mushroom_stem
fill 237 132 353 237 135 353 minecraft:moss_block
setblock 237 132 357 minecraft:mushroom_stem
fill 237 132 358 237 135 358 minecraft:moss_block
setblock 237 132 362 minecraft:mushroom_stem
fill 237 132 363 237 135 363 minecraft:moss_block
fill 238 132 330 240 132 330 minecraft:red_mushroom_block
fill 238 132 334 240 132 334 minecraft:red_mushroom_block
setblock 238 132 336 minecraft:mushroom_stem
setblock 238 132 337 minecraft:moss_block
setblock 238 132 351 minecraft:mushroom_stem
fill 238 132 352 238 133 352 minecraft:moss_block
setblock 238 132 356 minecraft:mushroom_stem
fill 238 132 357 238 135 357 minecraft:moss_block
setblock 238 132 361 minecraft:mushroom_stem
fill 238 132 362 238 135 362 minecraft:moss_block
fill 239 132 342 239 133 344 minecraft:dirt
setblock 239 132 355 minecraft:mushroom_stem
fill 239 132 356 239 133 356 minecraft:moss_block
setblock 239 132 360 minecraft:mushroom_stem
fill 239 132 361 239 135 361 minecraft:moss_block
fill 240 132 341 240 133 341 minecraft:dirt
fill 240 132 346 240 133 346 minecraft:dirt
setblock 240 132 360 minecraft:moss_block
fill 241 132 347 241 133 347 minecraft:dirt
setblock 241 132 363 minecraft:mushroom_stem
fill 242 132 339 244 133 339 minecraft:dirt
setblock 242 132 362 minecraft:mushroom_stem
fill 242 132 363 242 135 363 minecraft:moss_block
fill 243 132 348 244 133 348 minecraft:dirt
setblock 243 132 362 minecraft:moss_block
fill 246 132 340 246 133 340 minecraft:dirt
fill 247 132 341 247 133 341 minecraft:dirt
fill 248 132 343 248 133 343 minecraft:dirt
setblock 251 132 323 minecraft:red_mushroom_block
fill 253 132 363 255 132 363 minecraft:moss_block
setblock 256 132 323 minecraft:mushroom_stem
setblock 256 132 362 minecraft:moss_block
setblock 256 132 363 minecraft:mushroom_stem
fill 257 132 323 257 135 323 minecraft:moss_block
setblock 257 132 362 minecraft:mushroom_stem
fill 257 132 363 257 135 363 minecraft:moss_block
fill 258 132 362 258 135 362 minecraft:moss_block
setblock 260 132 324 minecraft:mushroom_stem
fill 260 132 364 260 145 364 minecraft:brown_terracotta
setblock 261 132 323 minecraft:mushroom_stem
setblock 261 132 363 minecraft:mushroom_stem
fill 262 132 323 262 135 323 minecraft:moss_block
fill 262 132 363 262 135 363 minecraft:moss_block
setblock 266 132 323 minecraft:mushroom_stem
setblock 266 132 363 minecraft:mushroom_stem
fill 267 132 363 270 132 363 minecraft:moss_block
fill 268 132 364 270 134 364 minecraft:brown_terracotta
setblock 271 132 323 minecraft:mushroom_stem
setblock 271 132 362 minecraft:moss_block
setblock 271 132 363 minecraft:mushroom_stem
setblock 271 132 364 minecraft:shroomlight
fill 272 132 323 272 135 323 minecraft:moss_block
setblock 272 132 362 minecraft:mushroom_stem
fill 272 132 363 272 135 363 minecraft:moss_block
setblock 273 132 361 minecraft:mushroom_stem
fill 273 132 362 273 135 362 minecraft:moss_block
setblock 274 132 356 minecraft:moss_block
setblock 274 132 360 minecraft:mushroom_stem
fill 274 132 361 274 135 361 minecraft:moss_block
setblock 275 132 324 minecraft:mushroom_stem
setblock 275 132 325 minecraft:moss_block
setblock 275 132 330 minecraft:moss_block
setblock 275 132 334 minecraft:mushroom_stem
fill 275 132 335 275 134 335 minecraft:moss_block
setblock 275 132 339 minecraft:mushroom_stem
fill 275 132 340 275 135 340 minecraft:moss_block
setblock 275 132 354 minecraft:mushroom_stem
fill 275 132 355 275 135 355 minecraft:moss_block
setblock 275 132 359 minecraft:mushroom_stem
fill 275 132 360 275 135 360 minecraft:moss_block
setblock 276 132 323 minecraft:mushroom_stem
fill 276 132 324 276 135 324 minecraft:moss_block
setblock 276 132 328 minecraft:mushroom_stem
fill 276 132 329 276 134 329 minecraft:moss_block
setblock 276 132 333 minecraft:mushroom_stem
fill 276 132 334 276 135 334 minecraft:moss_block
setblock 276 132 338 minecraft:mushroom_stem
fill 276 132 339 276 135 339 minecraft:moss_block
fill 276 132 341 276 132 342 minecraft:moss_block
setblock 276 132 343 minecraft:mushroom_stem
fill 276 132 344 276 135 344 minecraft:moss_block
setblock 276 132 349 minecraft:moss_block
setblock 276 132 353 minecraft:mushroom_stem
fill 276 132 354 276 135 354 minecraft:moss_block
setblock 276 132 358 minecraft:mushroom_stem
fill 276 132 359 276 135 359 minecraft:moss_block
setblock 276 132 363 minecraft:mushroom_stem
fill 277 132 336 277 147 336 minecraft:brown_terracotta
setblock 277 132 355 minecraft:red_mushroom_block
fill 236 133 323 236 136 323 minecraft:moss_block
setblock 236 133 325 minecraft:red_mushroom_block
setblock 236 133 332 minecraft:mushroom_stem
fill 236 133 333 236 135 333 minecraft:moss_block
setblock 236 133 337 minecraft:mushroom_stem
fill 236 133 338 236 136 338 minecraft:moss_block
setblock 236 133 342 minecraft:mushroom_stem
fill 236 133 343 236 133 346 minecraft:moss_block
setblock 236 133 347 minecraft:mushroom_stem
fill 236 133 348 236 136 348 minecraft:moss_block
setblock 236 133 352 minecraft:mushroom_stem
fill 236 133 353 236 136 353 minecraft:moss_block
setblock 236 133 357 minecraft:mushroom_stem
fill 236 133 358 236 136 358 minecraft:moss_block
setblock 236 133 362 minecraft:mushroom_stem
fill 236 133 363 236 136 363 minecraft:moss_block
setblock 237 133 336 minecraft:mushroom_stem
fill 237 133 337 237 136 337 minecraft:moss_block
setblock 237 133 341 minecraft:mushroom_stem
fill 237 133 342 237 136 342 minecraft:moss_block
setblock 237 133 345 minecraft:moss_block
setblock 237 133 346 minecraft:mushroom_stem
fill 237 133 347 237 136 347 minecraft:moss_block
setblock 237 133 351 minecraft:mushroom_stem
fill 237 133 352 237 136 352 minecraft:moss_block
setblock 237 133 356 minecraft:mushroom_stem
fill 237 133 357 237 136 357 minecraft:moss_block
setblock 237 133 361 minecraft:mushroom_stem
fill 237 133 362 237 136 362 minecraft:moss_block
setblock 238 133 325 minecraft:light[level=15]
setblock 238 133 333 minecraft:light[level=15]
setblock 238 133 340 minecraft:mushroom_stem
setblock 238 133 341 minecraft:light[level=15]
setblock 238 133 349 minecraft:light[level=15]
setblock 238 133 355 minecraft:mushroom_stem
fill 238 133 356 238 135 356 minecraft:moss_block
setblock 238 133 360 minecraft:mushroom_stem
fill 238 133 361 238 136 361 minecraft:moss_block
setblock 239 133 341 minecraft:dirt
fill 239 133 345 239 133 346 minecraft:dirt
setblock 239 133 359 minecraft:mushroom_stem
setblock 239 133 360 minecraft:moss_block
setblock 240 133 340 minecraft:dirt
setblock 240 133 347 minecraft:dirt
setblock 240 133 363 minecraft:mushroom_stem
setblock 241 133 339 minecraft:dirt
setblock 241 133 362 minecraft:mushroom_stem
fill 241 133 363 241 136 363 minecraft:moss_block
setblock 242 133 348 minecraft:dirt
setblock 242 133 362 minecraft:moss_block
setblock 245 133 323 minecraft:red_mushroom_block
fill 245 133 339 246 133 339 minecraft:dirt
fill 245 133 358 247 139 358 minecraft:mushroom_stem
setblock 246 133 325 minecraft:light[level=15]
setblock 246 133 333 minecraft:light[level=15]
setblock 246 133 349 minecraft:light[level=15]
fill 246 133 357 246 139 357 minecraft:mushroom_stem
fill 246 133 359 246 139 359 minecraft:mushroom_stem
setblock 247 133 340 minecraft:dirt
fill 247 133 351 247 148 351 minecraft:mushroom_stem
setblock 248 133 342 minecraft:dirt
fill 253 133 363 254 133 363 minecraft:moss_block
setblock 254 133 323 minecraft:moss_block
setblock 254 133 325 minecraft:light[level=15]
setblock 254 133 333 minecraft:light[level=15]
setblock 254 133 341 minecraft:light[level=15]
setblock 254 133 349 minecraft:light[level=15]
setblock 254 133 357 minecraft:light[level=15]
setblock 255 133 323 minecraft:mushroom_stem
setblock 255 133 362 minecraft:moss_block
setblock 255 133 363 minecraft:mushroom_stem
fill 256 133 323 256 136 323 minecraft:moss_block
setblock 256 133 362 minecraft:mushroom_stem
fill 256 133 363 256 136 363 minecraft:moss_block
fill 257 133 362 257 136 362 minecraft:moss_block
setblock 259 133 324 minecraft:mushroom_stem
setblock 260 133 323 minecraft:mushroom_stem
setblock 260 133 363 minecraft:mushroom_stem
fill 261 133 323 261 136 323 minecraft:moss_block
fill 261 133 363 261 136 363 minecraft:moss_block
setblock 262 133 325 minecraft:light[level=15]
setblock 262 133 333 minecraft:light[level=15]
setblock 262 133 341 minecraft:light[level=15]
setblock 262 133 349 minecraft:light[level=15]
setblock 262 133 357 minecraft:light[level=15]
setblock 265 133 323 minecraft:mushroom_stem
setblock 265 133 363 minecraft:mushroom_stem
fill 266 133 363 269 133 363 minecraft:moss_block
setblock 270 133 323 minecraft:mushroom_stem
setblock 270 133 325 minecraft:light[level=15]
setblock 270 133 333 minecraft:light[level=15]
setblock 270 133 341 minecraft:light[level=15]
setblock 270 133 349 minecraft:light[level=15]
setblock 270 133 357 minecraft:light[level=15]
setblock 270 133 362 minecraft:moss_block
setblock 270 133 363 minecraft:mushroom_stem
fill 271 133 323 271 136 323 minecraft:moss_block
setblock 271 133 362 minecraft:mushroom_stem
fill 271 133 363 271 136 363 minecraft:moss_block
fill 271 133 364 271 147 364 minecraft:brown_terracotta
fill 272 133 362 272 136 362 minecraft:moss_block
fill 273 133 361 273 136 361 minecraft:moss_block
setblock 274 133 323 minecraft:moss_block
setblock 274 133 324 minecraft:mushroom_stem
setblock 274 133 359 minecraft:mushroom_stem
fill 274 133 360 274 136 360 minecraft:moss_block
setblock 275 133 323 minecraft:mushroom_stem
fill 275 133 324 275 136 324 minecraft:moss_block
setblock 275 133 333 minecraft:mushroom_stem
setblock 275 133 334 minecraft:moss_block
setblock 275 133 338 minecraft:mushroom_stem
fill 275 133 339 275 136 339 minecraft:moss_block
setblock 275 133 353 minecraft:mushroom_stem
fill 275 133 354 275 135 354 minecraft:moss_block
setblock 275 133 358 minecraft:mushroom_stem
fill 275 133 359 275 136 359 minecraft:moss_block
setblock 275 133 363 minecraft:mushroom_stem
fill 276 133 323 276 136 323 minecraft:moss_block
setblock 276 133 327 minecraft:mushroom_stem
fill 276 133 328 276 134 328 minecraft:moss_block
setblock 276 133 332 minecraft:mushroom_stem
fill 276 133 333 276 135 333 minecraft:moss_block
setblock 276 133 337 minecraft:mushroom_stem
fill 276 133 338 276 136 338 minecraft:moss_block
setblock 276 133 341 minecraft:moss_block
setblock 276 133 342 minecraft:mushroom_stem
fill 276 133 343 276 136 343 minecraft:moss_block
setblock 276 133 352 minecraft:mushroom_stem
fill 276 133 353 276 136 353 minecraft:moss_block
setblock 276 133 357 minecraft:mushroom_stem
fill 276 133 358 276 136 358 minecraft:moss_block
setblock 276 133 362 minecraft:mushroom_stem
fill 276 133 363 276 136 363 minecraft:moss_block
fill 277 133 355 277 147 355 minecraft:brown_terracotta
setblock 236 134 331 minecraft:red_mushroom_block
setblock 236 134 332 minecraft:moss_block
setblock 236 134 336 minecraft:mushroom_stem
fill 236 134 337 236 137 337 minecraft:moss_block
setblock 236 134 341 minecraft:mushroom_stem
fill 236 134 342 236 134 345 minecraft:moss_block
setblock 236 134 346 minecraft:mushroom_stem
fill 236 134 347 236 137 347 minecraft:moss_block
setblock 236 134 351 minecraft:mushroom_stem
fill 236 134 352 236 137 352 minecraft:moss_block
setblock 236 134 356 minecraft:mushroom_stem
fill 236 134 357 236 137 357 minecraft:moss_block
setblock 236 134 361 minecraft:mushroom_stem
fill 236 134 362 236 137 362 minecraft:moss_block
setblock 237 134 335 minecraft:mushroom_stem
fill 237 134 336 237 135 336 minecraft:moss_block
setblock 237 134 340 minecraft:mushroom_stem
fill 237 134 341 237 137 341 minecraft:moss_block
setblock 237 134 345 minecraft:mushroom_stem
fill 237 134 346 237 137 346 minecraft:moss_block
setblock 237 134 350 minecraft:mushroom_stem
fill 237 134 351 237 135 351 minecraft:moss_block
setblock 237 134 355 minecraft:mushroom_stem
fill 237 134 356 237 137 356 minecraft:moss_block
setblock 237 134 360 minecraft:mushroom_stem
fill 237 134 361 237 137 361 minecraft:moss_block
setblock 238 134 354 minecraft:mushroom_stem
setblock 238 134 355 minecraft:moss_block
setblock 238 134 359 minecraft:mushroom_stem
fill 238 134 360 238 137 360 minecraft:moss_block
setblock 239 134 323 minecraft:red_mushroom_block
setblock 239 134 363 minecraft:mushroom_stem
setblock 240 134 362 minecraft:mushroom_stem
fill 240 134 363 240 137 363 minecraft:moss_block
fill 241 134 362 241 135 362 minecraft:moss_block
fill 243 134 343 243 136 343 minecraft:mushroom_stem
setblock 248 134 363 minecraft:red_mushroom_block
fill 252 134 363 253 134 363 minecraft:moss_block
setblock 253 134 323 minecraft:moss_block
setblock 254 134 323 minecraft:mushroom_stem
setblock 254 134 363 minecraft:mushroom_stem
fill 255 134 323 255 137 323 minecraft:moss_block
setblock 255 134 362 minecraft:mushroom_stem
fill 255 134 363 255 137 363 minecraft:moss_block
fill 256 134 362 256 137 362 minecraft:moss_block
setblock 258 134 324 minecraft:mushroom_stem
setblock 259 134 323 minecraft:mushroom_stem
setblock 259 134 363 minecraft:mushroom_stem
fill 260 134 323 260 137 323 minecraft:moss_block
fill 260 134 363 260 137 363 minecraft:moss_block
setblock 264 134 323 minecraft:mushroom_stem
setblock 264 134 363 minecraft:mushroom_stem
fill 265 134 363 268 134 363 minecraft:moss_block
setblock 268 134 323 minecraft:moss_block
setblock 269 134 323 minecraft:mushroom_stem
setblock 269 134 363 minecraft:mushroom_stem
fill 270 134 323 270 137 323 minecraft:moss_block
setblock 270 134 362 minecraft:mushroom_stem
fill 270 134 363 270 137 363 minecraft:moss_block
fill 271 134 362 271 137 362 minecraft:moss_block
fill 272 134 361 272 137 361 minecraft:moss_block
setblock 274 134 323 minecraft:mushroom_stem
fill 274 134 324 274 137 324 minecraft:moss_block
setblock 274 134 358 minecraft:mushroom_stem
fill 274 134 359 274 137 359 minecraft:moss_block
setblock 274 134 363 minecraft:mushroom_stem
fill 275 134 323 275 137 323 minecraft:moss_block
setblock 275 134 337 minecraft:mushroom_stem
fill 275 134 338 275 136 338 minecraft:moss_block
setblock 275 134 357 minecraft:mushroom_stem
fill 275 134 358 275 137 358 minecraft:moss_block
setblock 275 134 362 minecraft:mushroom_stem
fill 275 134 363 275 137 363 minecraft:moss_block
setblock 276 134 326 minecraft:mushroom_stem
fill 276 134 327 276 137 327 minecraft:moss_block
setblock 276 134 331 minecraft:mushroom_stem
fill 276 134 332 276 135 332 minecraft:moss_block
setblock 276 134 336 minecraft:mushroom_stem
fill 276 134 337 276 137 337 minecraft:moss_block
setblock 276 134 341 minecraft:mushroom_stem
fill 276 134 342 276 137 342 minecraft:moss_block
setblock 276 134 345 minecraft:moss_block
setblock 276 134 351 minecraft:mushroom_stem
fill 276 134 352 276 137 352 minecraft:moss_block
setblock 276 134 356 minecraft:mushroom_stem
fill 276 134 357 276 137 357 minecraft:moss_block
setblock 276 134 361 minecraft:mushroom_stem
fill 276 134 362 276 137 362 minecraft:moss_block
setblock 236 135 335 minecraft:mushroom_stem
fill 236 135 336 236 138 336 minecraft:moss_block
setblock 236 135 340 minecraft:mushroom_stem
fill 236 135 341 236 135 344 minecraft:moss_block
setblock 236 135 345 minecraft:mushroom_stem
fill 236 135 346 236 138 346 minecraft:moss_block
setblock 236 135 350 minecraft:mushroom_stem
fill 236 135 351 236 138 351 minecraft:moss_block
setblock 236 135 355 minecraft:mushroom_stem
fill 236 135 356 236 138 356 minecraft:moss_block
setblock 236 135 360 minecraft:mushroom_stem
fill 236 135 361 236 138 361 minecraft:moss_block
setblock 237 135 339 minecraft:mushroom_stem
fill 237 135 340 237 138 340 minecraft:moss_block
setblock 237 135 344 minecraft:mushroom_stem
fill 237 135 345 237 138 345 minecraft:moss_block
setblock 237 135 354 minecraft:mushroom_stem
fill 237 135 355 237 138 355 minecraft:moss_block
setblock 237 135 359 minecraft:mushroom_stem
fill 237 135 360 237 138 360 minecraft:moss_block
setblock 238 135 323 minecraft:mushroom_stem
setblock 238 135 325 minecraft:light[level=12]
setblock 238 135 332 minecraft:light[level=12]
setblock 238 135 339 minecraft:light[level=12]
setblock 238 135 346 minecraft:light[level=12]
setblock 238 135 353 minecraft:light[level=12]
setblock 238 135 358 minecraft:mushroom_stem
fill 238 135 359 238 136 359 minecraft:moss_block
setblock 238 135 363 minecraft:mushroom_stem
setblock 239 135 362 minecraft:mushroom_stem
fill 239 135 363 239 138 363 minecraft:moss_block
fill 240 135 362 240 136 362 minecraft:moss_block
setblock 245 135 325 minecraft:light[level=12]
setblock 245 135 332 minecraft:light[level=12]
setblock 245 135 339 minecraft:light[level=12]
setblock 245 135 346 minecraft:light[level=12]
setblock 245 135 353 minecraft:light[level=12]
setblock 245 135 360 minecraft:light[level=12]
setblock 252 135 323 minecraft:red_mushroom_block
setblock 252 135 325 minecraft:light[level=12]
setblock 252 135 332 minecraft:light[level=12]
setblock 252 135 339 minecraft:light[level=12]
setblock 252 135 346 minecraft:light[level=12]
setblock 252 135 353 minecraft:light[level=12]
setblock 252 135 360 minecraft:light[level=12]
setblock 252 135 363 minecraft:moss_block
setblock 253 135 323 minecraft:mushroom_stem
setblock 253 135 363 minecraft:mushroom_stem
fill 254 135 323 254 138 323 minecraft:moss_block
fill 254 135 363 254 138 363 minecraft:moss_block
fill 255 135 362 255 138 362 minecraft:moss_block
setblock 257 135 324 minecraft:mushroom_stem
setblock 258 135 323 minecraft:mushroom_stem
fill 258 135 324 258 138 324 minecraft:moss_block
setblock 258 135 363 minecraft:mushroom_stem
fill 259 135 323 259 138 323 minecraft:moss_block
schedule function dropper:buildpart/77_3 1t
