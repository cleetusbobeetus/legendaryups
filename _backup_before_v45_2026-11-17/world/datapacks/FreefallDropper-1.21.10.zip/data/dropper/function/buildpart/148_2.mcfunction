fill 189 155 613 189 155 618 minecraft:black_concrete
fill 189 155 621 189 155 626 minecraft:black_concrete
fill 189 155 629 189 155 634 minecraft:black_concrete
fill 189 155 637 189 156 637 minecraft:black_concrete
fill 189 155 639 189 156 639 minecraft:black_concrete
fill 189 155 641 189 156 641 minecraft:black_concrete
fill 189 155 643 189 156 643 minecraft:black_concrete
fill 189 155 645 189 156 645 minecraft:black_concrete
setblock 189 155 646 minecraft:magenta_concrete
fill 190 155 636 190 156 636 minecraft:black_concrete
fill 190 155 638 190 156 638 minecraft:black_concrete
fill 190 155 640 190 156 640 minecraft:black_concrete
fill 190 155 642 190 156 642 minecraft:black_concrete
fill 190 155 644 190 156 644 minecraft:black_concrete
fill 190 155 646 190 156 646 minecraft:cyan_concrete
fill 191 155 637 191 156 637 minecraft:black_concrete
fill 191 155 639 191 156 639 minecraft:black_concrete
fill 191 155 641 191 156 641 minecraft:black_concrete
fill 191 155 643 191 156 643 minecraft:black_concrete
fill 191 155 645 191 156 645 minecraft:black_concrete
fill 192 155 636 192 156 636 minecraft:black_concrete
fill 192 155 638 192 156 638 minecraft:black_concrete
fill 192 155 640 192 156 640 minecraft:black_concrete
fill 192 155 642 192 156 642 minecraft:black_concrete
fill 192 155 644 192 156 644 minecraft:black_concrete
fill 192 155 646 192 156 646 minecraft:cyan_concrete
fill 193 155 637 193 156 637 minecraft:black_concrete
fill 193 155 639 193 156 639 minecraft:black_concrete
fill 193 155 641 193 156 641 minecraft:black_concrete
fill 193 155 643 193 156 643 minecraft:black_concrete
fill 193 155 645 193 156 645 minecraft:black_concrete
fill 194 155 636 194 156 636 minecraft:black_concrete
fill 194 155 638 194 156 638 minecraft:black_concrete
fill 194 155 640 194 156 640 minecraft:black_concrete
fill 194 155 642 194 156 642 minecraft:black_concrete
fill 194 155 644 194 156 644 minecraft:black_concrete
fill 194 155 646 194 156 646 minecraft:cyan_concrete
fill 195 155 637 195 156 637 minecraft:black_concrete
fill 195 155 639 195 156 639 minecraft:black_concrete
fill 195 155 641 195 156 641 minecraft:black_concrete
fill 195 155 643 195 156 643 minecraft:black_concrete
fill 195 155 645 195 156 645 minecraft:black_concrete
fill 196 155 636 196 156 636 minecraft:black_concrete
fill 196 155 638 196 156 638 minecraft:black_concrete
fill 196 155 640 196 156 640 minecraft:black_concrete
fill 196 155 642 196 156 642 minecraft:black_concrete
fill 196 155 644 196 156 644 minecraft:black_concrete
fill 196 155 646 196 156 646 minecraft:cyan_concrete
fill 197 155 645 202 155 645 minecraft:black_concrete
setblock 198 155 604 minecraft:magenta_concrete
fill 199 155 604 202 156 604 minecraft:cyan_concrete
fill 201 155 646 201 156 646 minecraft:cyan_concrete
setblock 202 155 646 minecraft:magenta_concrete
fill 204 155 604 204 156 604 minecraft:cyan_concrete
fill 209 155 604 209 156 604 minecraft:cyan_concrete
setblock 211 155 646 minecraft:magenta_concrete
fill 218 155 646 219 156 646 minecraft:cyan_concrete
setblock 220 155 646 minecraft:magenta_concrete
fill 221 155 646 222 156 646 minecraft:cyan_concrete
setblock 224 155 604 minecraft:magenta_concrete
fill 225 155 604 225 156 604 minecraft:cyan_concrete
setblock 227 155 604 minecraft:magenta_concrete
setblock 229 155 644 minecraft:black_concrete
setblock 230 155 606 minecraft:magenta_concrete
fill 230 155 607 230 156 608 minecraft:cyan_concrete
setblock 230 155 615 minecraft:magenta_concrete
setblock 230 155 618 minecraft:magenta_concrete
fill 230 155 619 230 156 619 minecraft:cyan_concrete
fill 230 155 620 230 155 621 minecraft:magenta_concrete
fill 230 155 626 230 156 628 minecraft:cyan_concrete
setblock 230 155 629 minecraft:magenta_concrete
fill 230 155 634 230 156 634 minecraft:cyan_concrete
setblock 230 155 635 minecraft:magenta_concrete
fill 230 155 636 230 156 636 minecraft:cyan_concrete
fill 230 155 641 230 156 641 minecraft:cyan_concrete
setblock 230 155 642 minecraft:magenta_concrete
fill 230 155 646 230 156 646 minecraft:cyan_concrete
setblock 188 156 612 minecraft:cyan_concrete
setblock 188 156 630 minecraft:cyan_concrete
setblock 188 156 636 minecraft:cyan_concrete
setblock 188 156 639 minecraft:cyan_concrete
setblock 189 156 646 minecraft:cyan_concrete
setblock 198 156 604 minecraft:cyan_concrete
setblock 202 156 646 minecraft:cyan_concrete
setblock 211 156 646 minecraft:cyan_concrete
setblock 220 156 646 minecraft:cyan_concrete
setblock 224 156 604 minecraft:cyan_concrete
setblock 227 156 604 minecraft:cyan_concrete
setblock 230 156 606 minecraft:cyan_concrete
setblock 230 156 615 minecraft:cyan_concrete
setblock 230 156 618 minecraft:cyan_concrete
fill 230 156 620 230 156 621 minecraft:cyan_concrete
setblock 230 156 629 minecraft:cyan_concrete
setblock 230 156 635 minecraft:cyan_concrete
fill 230 156 642 230 159 642 minecraft:cyan_concrete
setblock 230 156 644 minecraft:cyan_concrete
fill 188 157 604 188 157 617 minecraft:magenta_concrete
setblock 188 157 618 minecraft:cyan_concrete
fill 188 157 619 188 228 624 minecraft:magenta_concrete
fill 188 157 626 188 232 628 minecraft:magenta_concrete
fill 188 157 630 188 157 636 minecraft:magenta_concrete
setblock 188 157 637 minecraft:cyan_concrete
fill 188 157 638 188 157 646 minecraft:magenta_concrete
fill 189 157 604 211 157 604 minecraft:magenta_concrete
setblock 189 157 637 minecraft:sea_lantern
setblock 189 157 639 minecraft:sea_lantern
setblock 189 157 641 minecraft:sea_lantern
setblock 189 157 643 minecraft:sea_lantern
setblock 189 157 645 minecraft:sea_lantern
fill 189 157 646 189 233 646 minecraft:magenta_concrete
setblock 190 157 636 minecraft:sea_lantern
setblock 190 157 638 minecraft:sea_lantern
setblock 190 157 640 minecraft:sea_lantern
setblock 190 157 642 minecraft:sea_lantern
setblock 190 157 644 minecraft:sea_lantern
setblock 190 157 646 minecraft:sea_lantern
setblock 191 157 637 minecraft:sea_lantern
setblock 191 157 639 minecraft:sea_lantern
setblock 191 157 641 minecraft:sea_lantern
setblock 191 157 643 minecraft:sea_lantern
setblock 191 157 645 minecraft:sea_lantern
setblock 191 157 646 minecraft:magenta_concrete
setblock 192 157 636 minecraft:sea_lantern
setblock 192 157 638 minecraft:sea_lantern
setblock 192 157 640 minecraft:sea_lantern
setblock 192 157 642 minecraft:sea_lantern
setblock 192 157 644 minecraft:sea_lantern
setblock 192 157 646 minecraft:sea_lantern
setblock 193 157 637 minecraft:sea_lantern
setblock 193 157 639 minecraft:sea_lantern
setblock 193 157 641 minecraft:sea_lantern
setblock 193 157 643 minecraft:sea_lantern
setblock 193 157 645 minecraft:sea_lantern
fill 193 157 646 193 232 646 minecraft:magenta_concrete
setblock 194 157 636 minecraft:sea_lantern
setblock 194 157 638 minecraft:sea_lantern
setblock 194 157 640 minecraft:sea_lantern
setblock 194 157 642 minecraft:sea_lantern
setblock 194 157 644 minecraft:sea_lantern
setblock 194 157 646 minecraft:sea_lantern
setblock 195 157 637 minecraft:sea_lantern
setblock 195 157 639 minecraft:sea_lantern
setblock 195 157 641 minecraft:sea_lantern
setblock 195 157 643 minecraft:sea_lantern
setblock 195 157 645 minecraft:sea_lantern
fill 195 157 646 195 232 646 minecraft:magenta_concrete
setblock 196 157 636 minecraft:sea_lantern
setblock 196 157 638 minecraft:sea_lantern
setblock 196 157 640 minecraft:sea_lantern
setblock 196 157 642 minecraft:sea_lantern
setblock 196 157 644 minecraft:sea_lantern
setblock 196 157 646 minecraft:sea_lantern
fill 197 157 646 198 232 646 minecraft:magenta_concrete
fill 200 157 646 203 157 646 minecraft:magenta_concrete
fill 205 157 646 211 157 646 minecraft:magenta_concrete
fill 212 157 646 213 157 646 minecraft:cyan_concrete
fill 213 157 604 215 229 604 minecraft:magenta_concrete
fill 214 157 646 230 157 646 minecraft:magenta_concrete
fill 217 157 604 218 158 604 minecraft:magenta_concrete
fill 220 157 604 230 157 604 minecraft:magenta_concrete
fill 230 157 605 230 157 611 minecraft:magenta_concrete
setblock 230 157 612 minecraft:cyan_concrete
fill 230 157 613 230 157 637 minecraft:magenta_concrete
fill 230 157 639 230 157 641 minecraft:magenta_concrete
fill 230 157 643 230 157 644 minecraft:magenta_concrete
fill 188 158 604 188 228 608 minecraft:magenta_concrete
fill 188 158 609 188 163 609 minecraft:sea_lantern
fill 188 158 610 188 158 612 minecraft:magenta_concrete
fill 188 158 613 188 158 614 minecraft:cyan_concrete
fill 188 158 615 188 229 616 minecraft:magenta_concrete
fill 188 158 617 188 163 617 minecraft:sea_lantern
setblock 188 158 618 minecraft:magenta_concrete
fill 188 158 625 188 163 625 minecraft:sea_lantern
fill 188 158 629 188 230 632 minecraft:magenta_concrete
fill 188 158 633 188 163 633 minecraft:sea_lantern
fill 188 158 634 188 229 640 minecraft:magenta_concrete
fill 188 158 641 188 163 641 minecraft:sea_lantern
fill 188 158 642 188 233 642 minecraft:magenta_concrete
setblock 188 158 643 minecraft:cyan_concrete
fill 188 158 644 188 158 646 minecraft:magenta_concrete
fill 189 158 604 193 229 604 minecraft:magenta_concrete
fill 189 158 637 189 159 637 minecraft:black_concrete
fill 189 158 639 189 159 639 minecraft:black_concrete
fill 189 158 641 189 159 641 minecraft:black_concrete
fill 189 158 643 189 159 643 minecraft:black_concrete
fill 189 158 645 189 159 645 minecraft:black_concrete
fill 190 158 636 190 159 636 minecraft:black_concrete
fill 190 158 638 190 159 638 minecraft:black_concrete
fill 190 158 640 190 159 640 minecraft:black_concrete
fill 190 158 642 190 159 642 minecraft:black_concrete
fill 190 158 644 190 159 644 minecraft:black_concrete
fill 190 158 646 190 159 646 minecraft:magenta_concrete
fill 191 158 637 191 159 637 minecraft:black_concrete
fill 191 158 639 191 159 639 minecraft:black_concrete
fill 191 158 641 191 159 641 minecraft:black_concrete
fill 191 158 643 191 159 643 minecraft:black_concrete
fill 191 158 645 191 159 645 minecraft:black_concrete
fill 191 158 646 191 163 646 minecraft:sea_lantern
fill 192 158 636 192 159 636 minecraft:black_concrete
fill 192 158 638 192 159 638 minecraft:black_concrete
fill 192 158 640 192 159 640 minecraft:black_concrete
fill 192 158 642 192 159 642 minecraft:black_concrete
fill 192 158 644 192 159 644 minecraft:black_concrete
fill 192 158 646 192 159 646 minecraft:magenta_concrete
fill 193 158 637 193 159 637 minecraft:black_concrete
fill 193 158 639 193 159 639 minecraft:black_concrete
fill 193 158 641 193 159 641 minecraft:black_concrete
fill 193 158 643 193 159 643 minecraft:black_concrete
fill 193 158 645 193 159 645 minecraft:black_concrete
setblock 194 158 604 minecraft:cyan_concrete
fill 194 158 636 194 159 636 minecraft:black_concrete
fill 194 158 638 194 159 638 minecraft:black_concrete
fill 194 158 640 194 159 640 minecraft:black_concrete
fill 194 158 642 194 159 642 minecraft:black_concrete
fill 194 158 644 194 159 644 minecraft:black_concrete
fill 194 158 646 194 159 646 minecraft:magenta_concrete
fill 195 158 604 195 163 604 minecraft:sea_lantern
fill 195 158 637 195 159 637 minecraft:black_concrete
fill 195 158 639 195 159 639 minecraft:black_concrete
fill 195 158 641 195 159 641 minecraft:black_concrete
fill 195 158 643 195 159 643 minecraft:black_concrete
fill 195 158 645 195 159 645 minecraft:black_concrete
setblock 196 158 604 minecraft:cyan_concrete
fill 196 158 636 196 159 636 minecraft:black_concrete
fill 196 158 638 196 159 638 minecraft:black_concrete
fill 196 158 640 196 159 640 minecraft:black_concrete
fill 196 158 642 196 159 642 minecraft:black_concrete
fill 196 158 644 196 159 644 minecraft:black_concrete
fill 196 158 646 196 159 646 minecraft:magenta_concrete
fill 197 158 604 202 229 604 minecraft:magenta_concrete
fill 199 158 646 199 163 646 minecraft:sea_lantern
setblock 200 158 646 minecraft:cyan_concrete
fill 201 158 646 206 158 646 minecraft:magenta_concrete
fill 203 158 604 203 163 604 minecraft:sea_lantern
fill 204 158 604 209 158 604 minecraft:magenta_concrete
fill 207 158 646 207 163 646 minecraft:sea_lantern
fill 208 158 646 209 232 646 minecraft:magenta_concrete
setblock 210 158 604 minecraft:cyan_concrete
setblock 210 158 646 minecraft:cyan_concrete
fill 211 158 604 211 163 604 minecraft:sea_lantern
fill 211 158 646 214 232 646 minecraft:magenta_concrete
fill 212 158 604 212 229 604 minecraft:magenta_concrete
fill 215 158 646 215 163 646 minecraft:sea_lantern
fill 216 158 604 216 232 604 minecraft:magenta_concrete
fill 216 158 646 222 158 646 minecraft:magenta_concrete
fill 219 158 604 219 163 604 minecraft:sea_lantern
fill 220 158 604 221 158 604 minecraft:cyan_concrete
fill 222 158 604 222 232 604 minecraft:magenta_concrete
setblock 223 158 604 minecraft:cyan_concrete
fill 223 158 646 223 163 646 minecraft:sea_lantern
fill 224 158 604 226 230 604 minecraft:magenta_concrete
fill 224 158 646 229 229 646 minecraft:magenta_concrete
fill 227 158 604 227 163 604 minecraft:sea_lantern
fill 228 158 604 229 232 604 minecraft:magenta_concrete
fill 230 158 604 230 158 605 minecraft:cyan_concrete
fill 230 158 606 230 229 608 minecraft:magenta_concrete
fill 230 158 609 230 163 609 minecraft:sea_lantern
setblock 230 158 610 minecraft:cyan_concrete
fill 230 158 611 230 229 615 minecraft:magenta_concrete
setblock 230 158 616 minecraft:cyan_concrete
fill 230 158 617 230 163 617 minecraft:sea_lantern
fill 230 158 618 230 228 618 minecraft:magenta_concrete
setblock 230 158 619 minecraft:cyan_concrete
fill 230 158 620 230 232 624 minecraft:magenta_concrete
fill 230 158 625 230 163 625 minecraft:sea_lantern
fill 230 158 626 230 158 632 minecraft:magenta_concrete
fill 230 158 633 230 163 633 minecraft:sea_lantern
fill 230 158 634 230 158 640 minecraft:magenta_concrete
fill 230 158 641 230 163 641 minecraft:sea_lantern
setblock 230 158 643 minecraft:cyan_concrete
fill 230 158 644 230 158 645 minecraft:magenta_concrete
fill 230 158 646 230 159 646 minecraft:cyan_concrete
fill 188 159 610 188 232 611 minecraft:magenta_concrete
setblock 188 159 612 minecraft:cyan_concrete
fill 188 159 613 188 230 614 minecraft:magenta_concrete
setblock 188 159 618 minecraft:cyan_concrete
fill 188 159 643 188 232 645 minecraft:magenta_concrete
setblock 188 159 646 minecraft:cyan_concrete
setblock 191 159 607 minecraft:light[level=14]
setblock 191 159 615 minecraft:light[level=14]
setblock 191 159 623 minecraft:light[level=14]
setblock 191 159 631 minecraft:light[level=14]
fill 194 159 604 194 229 604 minecraft:magenta_concrete
fill 196 159 604 196 232 604 minecraft:magenta_concrete
setblock 199 159 607 minecraft:light[level=14]
setblock 199 159 615 minecraft:light[level=14]
setblock 199 159 623 minecraft:light[level=14]
setblock 199 159 631 minecraft:light[level=14]
setblock 199 159 639 minecraft:light[level=14]
fill 200 159 646 202 229 646 minecraft:magenta_concrete
setblock 203 159 646 minecraft:cyan_concrete
setblock 204 159 604 minecraft:cyan_concrete
fill 204 159 646 206 228 646 minecraft:magenta_concrete
fill 205 159 604 206 232 604 minecraft:magenta_concrete
setblock 207 159 604 minecraft:cyan_concrete
setblock 207 159 607 minecraft:light[level=14]
setblock 207 159 615 minecraft:light[level=14]
setblock 207 159 623 minecraft:light[level=14]
setblock 207 159 631 minecraft:light[level=14]
setblock 207 159 639 minecraft:light[level=14]
fill 208 159 604 210 228 604 minecraft:magenta_concrete
fill 210 159 634 210 160 635 minecraft:yellow_concrete
fill 210 159 646 210 232 646 minecraft:magenta_concrete
setblock 215 159 607 minecraft:light[level=14]
setblock 215 159 615 minecraft:light[level=14]
setblock 215 159 623 minecraft:light[level=14]
setblock 215 159 631 minecraft:light[level=14]
setblock 215 159 639 minecraft:light[level=14]
fill 216 159 646 216 232 646 minecraft:magenta_concrete
setblock 217 159 604 minecraft:cyan_concrete
setblock 217 159 646 minecraft:cyan_concrete
fill 218 159 604 218 230 604 minecraft:magenta_concrete
fill 218 159 646 221 232 646 minecraft:magenta_concrete
fill 220 159 604 221 232 604 minecraft:magenta_concrete
setblock 222 159 646 minecraft:cyan_concrete
fill 223 159 604 223 229 604 minecraft:magenta_concrete
setblock 223 159 607 minecraft:light[level=14]
setblock 223 159 615 minecraft:light[level=14]
setblock 223 159 623 minecraft:light[level=14]
setblock 223 159 631 minecraft:light[level=14]
setblock 223 159 639 minecraft:light[level=14]
fill 230 159 604 230 229 605 minecraft:magenta_concrete
fill 230 159 610 230 228 610 minecraft:magenta_concrete
fill 230 159 616 230 232 616 minecraft:magenta_concrete
fill 230 159 619 230 232 619 minecraft:magenta_concrete
fill 230 159 626 230 228 630 minecraft:magenta_concrete
setblock 230 159 631 minecraft:cyan_concrete
fill 230 159 632 230 233 632 minecraft:magenta_concrete
fill 230 159 634 230 229 639 minecraft:magenta_concrete
setblock 230 159 640 minecraft:cyan_concrete
fill 230 159 643 230 232 644 minecraft:magenta_concrete
setblock 230 159 645 minecraft:cyan_concrete
fill 188 160 612 188 232 612 minecraft:magenta_concrete
fill 188 160 618 188 233 618 minecraft:magenta_concrete
fill 188 160 646 188 229 646 minecraft:magenta_concrete
setblock 189 160 637 minecraft:sea_lantern
setblock 189 160 639 minecraft:sea_lantern
setblock 189 160 641 minecraft:sea_lantern
setblock 189 160 643 minecraft:sea_lantern
setblock 189 160 645 minecraft:sea_lantern
setblock 190 160 636 minecraft:sea_lantern
setblock 190 160 638 minecraft:sea_lantern
setblock 190 160 640 minecraft:sea_lantern
setblock 190 160 642 minecraft:sea_lantern
setblock 190 160 644 minecraft:sea_lantern
setblock 190 160 646 minecraft:sea_lantern
setblock 191 160 637 minecraft:sea_lantern
setblock 191 160 639 minecraft:sea_lantern
setblock 191 160 641 minecraft:sea_lantern
setblock 191 160 643 minecraft:sea_lantern
setblock 191 160 645 minecraft:sea_lantern
setblock 192 160 636 minecraft:sea_lantern
setblock 192 160 638 minecraft:sea_lantern
setblock 192 160 640 minecraft:sea_lantern
setblock 192 160 642 minecraft:sea_lantern
setblock 192 160 644 minecraft:sea_lantern
setblock 192 160 646 minecraft:sea_lantern
setblock 193 160 637 minecraft:sea_lantern
setblock 193 160 639 minecraft:sea_lantern
setblock 193 160 641 minecraft:sea_lantern
setblock 193 160 643 minecraft:sea_lantern
setblock 193 160 645 minecraft:sea_lantern
setblock 194 160 636 minecraft:sea_lantern
setblock 194 160 638 minecraft:sea_lantern
setblock 194 160 640 minecraft:sea_lantern
setblock 194 160 642 minecraft:sea_lantern
setblock 194 160 644 minecraft:sea_lantern
setblock 194 160 646 minecraft:sea_lantern
setblock 195 160 637 minecraft:sea_lantern
setblock 195 160 639 minecraft:sea_lantern
setblock 195 160 641 minecraft:sea_lantern
setblock 195 160 643 minecraft:sea_lantern
setblock 195 160 645 minecraft:sea_lantern
setblock 196 160 636 minecraft:sea_lantern
setblock 196 160 638 minecraft:sea_lantern
setblock 196 160 640 minecraft:sea_lantern
setblock 196 160 642 minecraft:sea_lantern
setblock 196 160 644 minecraft:sea_lantern
setblock 196 160 646 minecraft:sea_lantern
fill 203 160 646 203 232 646 minecraft:magenta_concrete
fill 204 160 604 204 232 604 minecraft:magenta_concrete
fill 207 160 604 207 232 604 minecraft:magenta_concrete
fill 217 160 604 217 232 604 minecraft:magenta_concrete
fill 217 160 646 217 232 646 minecraft:magenta_concrete
fill 222 160 646 222 229 646 minecraft:magenta_concrete
fill 230 160 631 230 229 631 minecraft:magenta_concrete
fill 230 160 640 230 230 640 minecraft:magenta_concrete
fill 230 160 642 230 230 642 minecraft:magenta_concrete
fill 230 160 645 230 228 646 minecraft:magenta_concrete
fill 189 161 637 189 162 637 minecraft:black_concrete
fill 189 161 639 189 162 639 minecraft:black_concrete
fill 189 161 641 189 162 641 minecraft:black_concrete
fill 189 161 643 189 162 643 minecraft:black_concrete
fill 189 161 645 189 162 645 minecraft:black_concrete
fill 190 161 636 190 162 636 minecraft:black_concrete
fill 190 161 638 190 162 638 minecraft:black_concrete
fill 190 161 640 190 162 640 minecraft:black_concrete
fill 190 161 642 190 162 642 minecraft:black_concrete
fill 190 161 644 190 162 644 minecraft:black_concrete
fill 190 161 646 190 162 646 minecraft:magenta_concrete
fill 191 161 637 191 162 637 minecraft:black_concrete
fill 191 161 639 191 162 639 minecraft:black_concrete
fill 191 161 641 191 162 641 minecraft:black_concrete
fill 191 161 643 191 162 643 minecraft:black_concrete
fill 191 161 645 191 162 645 minecraft:black_concrete
fill 192 161 636 192 162 636 minecraft:black_concrete
fill 192 161 638 192 162 638 minecraft:black_concrete
fill 192 161 640 192 162 640 minecraft:black_concrete
fill 192 161 642 192 162 642 minecraft:black_concrete
fill 192 161 644 192 162 644 minecraft:black_concrete
fill 192 161 646 192 162 646 minecraft:magenta_concrete
fill 193 161 637 193 162 637 minecraft:black_concrete
fill 193 161 639 193 162 639 minecraft:black_concrete
fill 193 161 641 193 162 641 minecraft:black_concrete
fill 193 161 643 193 162 643 minecraft:black_concrete
fill 193 161 645 193 162 645 minecraft:black_concrete
fill 194 161 636 194 162 636 minecraft:black_concrete
fill 194 161 638 194 162 638 minecraft:black_concrete
fill 194 161 640 194 162 640 minecraft:black_concrete
fill 194 161 642 194 162 642 minecraft:black_concrete
fill 194 161 644 194 162 644 minecraft:black_concrete
fill 194 161 646 194 162 646 minecraft:magenta_concrete
fill 195 161 637 195 162 637 minecraft:black_concrete
fill 195 161 639 195 162 639 minecraft:black_concrete
fill 195 161 641 195 162 641 minecraft:black_concrete
fill 195 161 643 195 162 643 minecraft:black_concrete
fill 195 161 645 195 162 645 minecraft:black_concrete
fill 196 161 636 196 162 636 minecraft:black_concrete
fill 196 161 638 196 162 638 minecraft:black_concrete
fill 196 161 640 196 162 640 minecraft:black_concrete
fill 196 161 642 196 162 642 minecraft:black_concrete
fill 196 161 644 196 162 644 minecraft:black_concrete
fill 196 161 646 196 162 646 minecraft:magenta_concrete
fill 216 161 620 216 162 620 minecraft:cyan_concrete
setblock 189 163 637 minecraft:sea_lantern
setblock 189 163 639 minecraft:sea_lantern
setblock 189 163 641 minecraft:sea_lantern
setblock 189 163 643 minecraft:sea_lantern
setblock 189 163 645 minecraft:sea_lantern
setblock 190 163 636 minecraft:sea_lantern
setblock 190 163 638 minecraft:sea_lantern
setblock 190 163 640 minecraft:sea_lantern
setblock 190 163 642 minecraft:sea_lantern
setblock 190 163 644 minecraft:sea_lantern
setblock 190 163 646 minecraft:sea_lantern
setblock 191 163 637 minecraft:sea_lantern
setblock 191 163 639 minecraft:sea_lantern
setblock 191 163 641 minecraft:sea_lantern
setblock 191 163 643 minecraft:sea_lantern
setblock 191 163 645 minecraft:sea_lantern
setblock 192 163 636 minecraft:sea_lantern
setblock 192 163 638 minecraft:sea_lantern
setblock 192 163 640 minecraft:sea_lantern
setblock 192 163 642 minecraft:sea_lantern
setblock 192 163 644 minecraft:sea_lantern
setblock 192 163 646 minecraft:sea_lantern
setblock 193 163 637 minecraft:sea_lantern
setblock 193 163 639 minecraft:sea_lantern
setblock 193 163 641 minecraft:sea_lantern
setblock 193 163 643 minecraft:sea_lantern
setblock 193 163 645 minecraft:sea_lantern
setblock 194 163 636 minecraft:sea_lantern
setblock 194 163 638 minecraft:sea_lantern
setblock 194 163 640 minecraft:sea_lantern
setblock 194 163 642 minecraft:sea_lantern
setblock 194 163 644 minecraft:sea_lantern
setblock 194 163 646 minecraft:sea_lantern
setblock 195 163 637 minecraft:sea_lantern
setblock 195 163 639 minecraft:sea_lantern
setblock 195 163 641 minecraft:sea_lantern
setblock 195 163 643 minecraft:sea_lantern
setblock 195 163 645 minecraft:sea_lantern
setblock 196 163 636 minecraft:sea_lantern
setblock 196 163 638 minecraft:sea_lantern
setblock 196 163 640 minecraft:sea_lantern
setblock 196 163 642 minecraft:sea_lantern
setblock 196 163 644 minecraft:sea_lantern
setblock 196 163 646 minecraft:sea_lantern
fill 188 164 609 188 175 609 minecraft:magenta_concrete
fill 188 164 617 188 175 617 minecraft:magenta_concrete
fill 188 164 625 188 175 625 minecraft:magenta_concrete
fill 188 164 633 188 175 633 minecraft:magenta_concrete
fill 188 164 641 188 175 641 minecraft:magenta_concrete
fill 189 164 637 189 165 637 minecraft:black_concrete
fill 189 164 639 189 165 639 minecraft:black_concrete
fill 189 164 641 189 165 641 minecraft:black_concrete
fill 189 164 643 189 165 643 minecraft:black_concrete
fill 189 164 645 189 165 645 minecraft:black_concrete
fill 190 164 636 190 165 636 minecraft:black_concrete
fill 190 164 638 190 165 638 minecraft:black_concrete
fill 190 164 640 190 165 640 minecraft:black_concrete
fill 190 164 642 190 165 642 minecraft:black_concrete
fill 190 164 644 190 165 644 minecraft:black_concrete
fill 190 164 646 192 175 646 minecraft:magenta_concrete
fill 191 164 637 191 165 637 minecraft:black_concrete
fill 191 164 639 191 165 639 minecraft:black_concrete
fill 191 164 641 191 165 641 minecraft:black_concrete
fill 191 164 643 191 165 643 minecraft:black_concrete
fill 191 164 645 191 165 645 minecraft:black_concrete
fill 192 164 636 192 165 636 minecraft:black_concrete
fill 192 164 638 192 165 638 minecraft:black_concrete
fill 192 164 640 192 165 640 minecraft:black_concrete
fill 192 164 642 192 165 642 minecraft:black_concrete
fill 192 164 644 192 165 644 minecraft:black_concrete
fill 193 164 637 193 165 637 minecraft:black_concrete
fill 193 164 639 193 165 639 minecraft:black_concrete
fill 193 164 641 193 165 641 minecraft:black_concrete
fill 193 164 643 193 165 643 minecraft:black_concrete
fill 193 164 645 193 165 645 minecraft:black_concrete
fill 194 164 636 194 165 636 minecraft:black_concrete
fill 194 164 638 194 165 638 minecraft:black_concrete
fill 194 164 640 194 165 640 minecraft:black_concrete
fill 194 164 642 194 165 642 minecraft:black_concrete
fill 194 164 644 194 165 644 minecraft:black_concrete
fill 194 164 646 194 228 646 minecraft:magenta_concrete
fill 195 164 604 195 175 604 minecraft:magenta_concrete
fill 195 164 637 195 165 637 minecraft:black_concrete
fill 195 164 639 195 165 639 minecraft:black_concrete
fill 195 164 641 195 165 641 minecraft:black_concrete
fill 195 164 643 195 165 643 minecraft:black_concrete
fill 195 164 645 195 165 645 minecraft:black_concrete
fill 196 164 636 196 165 636 minecraft:black_concrete
fill 196 164 638 196 165 638 minecraft:black_concrete
fill 196 164 640 196 165 640 minecraft:black_concrete
fill 196 164 642 196 165 642 minecraft:black_concrete
fill 196 164 644 196 165 644 minecraft:black_concrete
fill 196 164 646 196 232 646 minecraft:magenta_concrete
fill 199 164 646 199 175 646 minecraft:magenta_concrete
fill 203 164 604 203 175 604 minecraft:magenta_concrete
fill 207 164 646 207 175 646 minecraft:magenta_concrete
fill 211 164 604 211 175 604 minecraft:magenta_concrete
fill 215 164 646 215 175 646 minecraft:magenta_concrete
fill 219 164 604 219 175 604 minecraft:magenta_concrete
fill 223 164 646 223 175 646 minecraft:magenta_concrete
fill 227 164 604 227 175 604 minecraft:magenta_concrete
fill 230 164 609 230 175 609 minecraft:magenta_concrete
fill 230 164 617 230 175 617 minecraft:magenta_concrete
fill 230 164 625 230 175 625 minecraft:magenta_concrete
fill 230 164 633 230 175 633 minecraft:magenta_concrete
fill 230 164 641 230 175 641 minecraft:magenta_concrete
setblock 191 167 607 minecraft:light[level=14]
setblock 191 167 615 minecraft:light[level=14]
setblock 191 167 623 minecraft:light[level=14]
setblock 191 167 631 minecraft:light[level=14]
setblock 191 167 639 minecraft:light[level=14]
setblock 199 167 607 minecraft:light[level=14]
setblock 199 167 615 minecraft:light[level=14]
setblock 199 167 623 minecraft:light[level=14]
setblock 199 167 631 minecraft:light[level=14]
setblock 199 167 639 minecraft:light[level=14]
setblock 207 167 607 minecraft:light[level=14]
setblock 207 167 615 minecraft:light[level=14]
setblock 207 167 623 minecraft:light[level=14]
setblock 207 167 631 minecraft:light[level=14]
setblock 207 167 639 minecraft:light[level=14]
setblock 215 167 607 minecraft:light[level=14]
setblock 215 167 615 minecraft:light[level=14]
setblock 215 167 623 minecraft:light[level=14]
setblock 215 167 631 minecraft:light[level=14]
setblock 215 167 639 minecraft:light[level=14]
setblock 223 167 607 minecraft:light[level=14]
setblock 223 167 615 minecraft:light[level=14]
setblock 223 167 623 minecraft:light[level=14]
setblock 223 167 631 minecraft:light[level=14]
setblock 223 167 639 minecraft:light[level=14]
fill 205 170 622 207 170 624 minecraft:redstone_block
fill 205 170 628 207 170 630 minecraft:redstone_block
fill 212 170 621 214 170 623 minecraft:redstone_block
fill 213 170 628 215 170 630 minecraft:redstone_block
fill 194 171 626 199 172 626 minecraft:cyan_concrete
fill 195 171 621 195 172 622 minecraft:black_concrete
fill 195 171 623 200 172 625 minecraft:cyan_concrete
fill 195 171 627 196 172 631 minecraft:cyan_concrete
fill 196 171 619 196 172 621 minecraft:black_concrete
fill 196 171 622 204 171 622 minecraft:cyan_concrete
fill 196 171 632 196 172 633 minecraft:cyan_concrete
fill 197 171 617 197 172 620 minecraft:black_concrete
fill 197 171 621 209 171 621 minecraft:cyan_concrete
fill 197 171 627 197 172 630 minecraft:cyan_concrete
fill 197 171 631 200 172 635 minecraft:black_concrete
fill 198 171 616 199 172 619 minecraft:black_concrete
fill 198 171 620 208 172 620 minecraft:cyan_concrete
fill 198 171 627 198 172 627 minecraft:cyan_concrete
fill 198 171 628 200 172 630 minecraft:black_concrete
fill 198 171 636 200 172 636 minecraft:black_concrete
fill 199 171 615 201 172 615 minecraft:cyan_concrete
fill 199 171 627 202 172 627 minecraft:black_concrete
fill 199 171 637 200 172 637 minecraft:black_concrete
fill 200 171 614 213 172 614 minecraft:cyan_concrete
fill 200 171 616 207 172 618 minecraft:black_concrete
fill 200 171 619 206 172 619 minecraft:cyan_concrete
fill 200 171 626 203 172 626 minecraft:black_concrete
fill 200 171 638 201 172 638 minecraft:black_concrete
fill 201 171 613 212 172 613 minecraft:cyan_concrete
fill 201 171 623 201 172 624 minecraft:cyan_concrete
fill 201 171 625 205 171 625 minecraft:black_concrete
fill 201 171 628 201 172 629 minecraft:black_concrete
fill 201 171 630 204 171 637 minecraft:cyan_concrete
fill 201 171 639 201 172 639 minecraft:black_concrete
fill 202 171 615 203 172 615 minecraft:black_concrete
fill 202 171 623 204 171 623 minecraft:cyan_concrete
fill 202 171 624 204 171 624 minecraft:black_concrete
fill 202 171 628 204 171 629 minecraft:cyan_concrete
fill 202 171 638 208 172 639 minecraft:cyan_concrete
fill 203 171 612 211 172 612 minecraft:cyan_concrete
fill 203 171 627 207 171 627 minecraft:cyan_concrete
fill 203 171 640 210 172 640 minecraft:cyan_concrete
fill 204 171 615 214 172 615 minecraft:cyan_concrete
fill 204 171 626 208 171 626 minecraft:cyan_concrete
fill 205 171 611 209 172 611 minecraft:cyan_concrete
fill 205 171 631 205 171 637 minecraft:cyan_concrete
fill 205 171 641 212 172 641 minecraft:cyan_concrete
fill 206 171 625 207 171 625 minecraft:cyan_concrete
fill 206 171 631 207 171 634 minecraft:black_concrete
fill 206 171 635 206 172 637 minecraft:cyan_concrete
fill 207 171 619 210 172 619 minecraft:black_concrete
fill 207 171 635 209 172 636 minecraft:black_concrete
fill 207 171 637 207 172 637 minecraft:cyan_concrete
fill 208 171 616 214 172 616 minecraft:cyan_concrete
fill 208 171 617 208 172 618 minecraft:black_concrete
fill 208 171 622 209 171 623 minecraft:cyan_concrete
fill 208 171 624 208 171 625 minecraft:black_concrete
fill 208 171 627 208 171 628 minecraft:black_concrete
fill 208 171 629 210 171 631 minecraft:cyan_concrete
fill 208 171 632 208 172 634 minecraft:black_concrete
fill 208 171 637 212 172 637 minecraft:black_concrete
fill 209 171 617 215 172 617 minecraft:cyan_concrete
fill 209 171 618 209 172 618 minecraft:black_concrete
fill 209 171 620 211 171 620 minecraft:black_concrete
fill 209 171 624 210 171 624 minecraft:cyan_concrete
setblock 209 171 628 minecraft:cyan_concrete
fill 209 171 632 213 172 634 minecraft:cyan_concrete
fill 209 171 638 215 172 638 minecraft:black_concrete
fill 209 171 639 209 172 639 minecraft:cyan_concrete
fill 210 171 610 210 172 611 minecraft:black_concrete
fill 210 171 618 215 172 618 minecraft:cyan_concrete
fill 210 171 621 211 171 622 minecraft:black_concrete
fill 210 171 623 210 172 623 minecraft:cyan_concrete
fill 210 171 628 211 171 628 minecraft:black_concrete
fill 210 171 635 223 172 635 minecraft:cyan_concrete
fill 210 171 636 210 172 636 minecraft:black_concrete
fill 210 171 639 219 172 639 minecraft:black_concrete
fill 210 171 642 210 172 642 minecraft:cyan_concrete
fill 211 171 611 215 172 611 minecraft:black_concrete
fill 211 171 619 215 172 619 minecraft:cyan_concrete
fill 211 171 623 211 171 624 minecraft:black_concrete
fill 211 171 629 212 171 630 minecraft:black_concrete
fill 211 171 631 211 172 631 minecraft:cyan_concrete
fill 211 171 636 222 172 636 minecraft:cyan_concrete
fill 211 171 640 217 172 640 minecraft:black_concrete
fill 212 171 612 216 172 612 minecraft:black_concrete
fill 212 171 620 215 171 620 minecraft:cyan_concrete
fill 212 171 624 213 171 625 minecraft:cyan_concrete
fill 212 171 626 215 171 626 minecraft:black_concrete
fill 212 171 627 212 171 628 minecraft:cyan_concrete
fill 212 171 631 221 171 631 minecraft:black_concrete
fill 213 171 613 217 172 613 minecraft:black_concrete
fill 213 171 627 221 171 627 minecraft:cyan_concrete
fill 213 171 637 221 172 637 minecraft:cyan_concrete
fill 213 171 641 215 172 641 minecraft:black_concrete
fill 214 171 614 217 172 614 minecraft:black_concrete
setblock 214 171 624 minecraft:cyan_concrete
fill 214 171 625 216 172 625 minecraft:black_concrete
fill 214 171 632 219 172 632 minecraft:black_concrete
fill 214 171 633 223 172 634 minecraft:cyan_concrete
fill 215 171 615 218 172 616 minecraft:black_concrete
fill 215 171 621 215 171 622 minecraft:cyan_concrete
fill 215 171 623 217 171 624 minecraft:black_concrete
fill 216 171 617 218 172 622 minecraft:black_concrete
fill 216 171 626 222 172 626 minecraft:cyan_concrete
fill 216 171 628 218 171 629 minecraft:cyan_concrete
fill 216 171 630 223 171 630 minecraft:black_concrete
fill 216 171 638 219 172 638 minecraft:cyan_concrete
fill 217 171 612 217 172 612 minecraft:cyan_concrete
fill 217 171 625 222 172 625 minecraft:cyan_concrete
fill 218 171 613 219 172 614 minecraft:cyan_concrete
fill 218 171 623 223 172 624 minecraft:cyan_concrete
fill 219 171 615 221 172 622 minecraft:cyan_concrete
fill 219 171 628 220 172 628 minecraft:cyan_concrete
fill 219 171 629 224 172 629 minecraft:black_concrete
fill 220 171 614 220 172 614 minecraft:cyan_concrete
fill 220 171 632 224 172 632 minecraft:cyan_concrete
fill 220 171 638 220 172 638 minecraft:black_concrete
fill 221 171 628 225 172 628 minecraft:black_concrete
fill 222 171 616 222 172 622 minecraft:cyan_concrete
fill 222 171 627 225 172 627 minecraft:black_concrete
fill 222 171 631 225 172 631 minecraft:cyan_concrete
fill 223 171 617 223 172 622 minecraft:cyan_concrete
fill 223 171 625 225 172 626 minecraft:black_concrete
fill 224 171 619 224 172 622 minecraft:cyan_concrete
fill 224 171 623 225 172 624 minecraft:black_concrete
fill 224 171 630 225 172 630 minecraft:cyan_concrete
fill 224 171 633 224 172 633 minecraft:cyan_concrete
fill 225 171 621 225 172 622 minecraft:black_concrete
fill 225 171 629 225 172 629 minecraft:cyan_concrete
fill 226 171 626 226 172 626 minecraft:black_concrete
fill 189 172 605 193 172 645 minecraft:cyan_concrete
fill 194 172 605 194 172 625 minecraft:cyan_concrete
fill 194 172 627 194 172 645 minecraft:cyan_concrete
fill 195 172 605 195 172 620 minecraft:cyan_concrete
fill 195 172 632 195 172 645 minecraft:cyan_concrete
fill 196 172 605 196 172 618 minecraft:cyan_concrete
fill 196 172 622 203 172 622 minecraft:cyan_concrete
fill 196 172 634 196 172 645 minecraft:cyan_concrete
fill 197 172 605 197 172 616 minecraft:cyan_concrete
fill 197 172 621 203 172 621 minecraft:cyan_concrete
fill 197 172 636 197 172 645 minecraft:cyan_concrete
fill 198 172 605 198 172 615 minecraft:cyan_concrete
fill 198 172 637 198 172 645 minecraft:cyan_concrete
fill 199 172 605 199 172 614 minecraft:cyan_concrete
fill 199 172 638 199 172 645 minecraft:cyan_concrete
fill 200 172 605 200 172 613 minecraft:cyan_concrete
fill 200 172 639 200 172 645 minecraft:cyan_concrete
fill 201 172 605 202 172 612 minecraft:cyan_concrete
fill 201 172 625 203 172 625 minecraft:black_concrete
fill 201 172 630 203 172 637 minecraft:cyan_concrete
fill 201 172 640 202 172 645 minecraft:cyan_concrete
fill 202 172 623 203 172 623 minecraft:cyan_concrete
fill 202 172 624 203 172 624 minecraft:black_concrete
fill 202 172 628 203 172 629 minecraft:cyan_concrete
fill 203 172 605 204 172 611 minecraft:cyan_concrete
setblock 203 172 627 minecraft:cyan_concrete
fill 203 172 641 204 172 645 minecraft:cyan_concrete
fill 204 172 621 204 172 625 minecraft:sea_lantern
fill 204 172 626 207 172 626 minecraft:cyan_concrete
fill 204 172 627 204 172 631 minecraft:sea_lantern
fill 204 172 632 205 172 637 minecraft:cyan_concrete
fill 205 172 605 209 172 610 minecraft:cyan_concrete
fill 205 172 621 208 172 621 minecraft:sea_lantern
fill 205 172 622 207 172 624 minecraft:cyan_concrete
fill 205 172 625 208 172 625 minecraft:sea_lantern
fill 205 172 627 208 172 627 minecraft:sea_lantern
fill 205 172 628 207 172 630 minecraft:cyan_concrete
fill 205 172 631 208 172 631 minecraft:sea_lantern
fill 205 172 642 209 172 645 minecraft:cyan_concrete
fill 206 172 632 207 172 634 minecraft:black_concrete
fill 208 172 622 208 172 624 minecraft:sea_lantern
setblock 208 172 626 minecraft:sea_lantern
fill 208 172 628 208 172 630 minecraft:sea_lantern
fill 209 172 620 210 172 620 minecraft:black_concrete
fill 209 172 621 209 172 623 minecraft:cyan_concrete
fill 209 172 624 215 172 624 minecraft:sea_lantern
fill 209 172 628 212 172 628 minecraft:sea_lantern
fill 209 172 629 210 172 631 minecraft:cyan_concrete
fill 210 172 605 229 172 609 minecraft:cyan_concrete
fill 210 172 621 210 172 622 minecraft:black_concrete
fill 210 172 643 229 172 645 minecraft:cyan_concrete
fill 211 172 610 229 172 610 minecraft:cyan_concrete
fill 211 172 620 211 172 623 minecraft:sea_lantern
fill 211 172 629 211 172 630 minecraft:black_concrete
fill 211 172 642 229 172 642 minecraft:cyan_concrete
fill 212 172 620 215 172 620 minecraft:sea_lantern
fill 212 172 621 214 172 623 minecraft:cyan_concrete
fill 212 172 625 212 172 627 minecraft:sea_lantern
fill 212 172 629 212 172 631 minecraft:sea_lantern
setblock 213 172 625 minecraft:cyan_concrete
fill 213 172 626 215 172 626 minecraft:black_concrete
fill 213 172 627 216 172 627 minecraft:sea_lantern
fill 213 172 628 215 172 630 minecraft:cyan_concrete
fill 213 172 631 216 172 631 minecraft:sea_lantern
fill 215 172 621 215 172 623 minecraft:sea_lantern
fill 216 172 611 229 172 611 minecraft:cyan_concrete
fill 216 172 623 217 172 624 minecraft:black_concrete
fill 216 172 628 216 172 630 minecraft:sea_lantern
fill 216 172 641 229 172 641 minecraft:cyan_concrete
fill 217 172 627 218 172 629 minecraft:cyan_concrete
fill 217 172 630 221 172 631 minecraft:black_concrete
fill 218 172 612 229 172 612 minecraft:cyan_concrete
fill 218 172 640 229 172 640 minecraft:cyan_concrete
fill 219 172 627 221 172 627 minecraft:cyan_concrete
fill 220 172 613 229 172 613 minecraft:cyan_concrete
fill 220 172 639 229 172 639 minecraft:cyan_concrete
fill 221 172 614 229 172 614 minecraft:cyan_concrete
fill 221 172 638 229 172 638 minecraft:cyan_concrete
fill 222 172 615 229 172 615 minecraft:cyan_concrete
fill 222 172 630 223 172 630 minecraft:black_concrete
fill 222 172 637 229 172 637 minecraft:cyan_concrete
fill 223 172 616 229 172 616 minecraft:cyan_concrete
fill 223 172 636 229 172 636 minecraft:cyan_concrete
fill 224 172 617 229 172 618 minecraft:cyan_concrete
fill 224 172 634 229 172 635 minecraft:cyan_concrete
fill 225 172 619 229 172 620 minecraft:cyan_concrete
fill 225 172 632 229 172 633 minecraft:cyan_concrete
fill 226 172 621 229 172 625 minecraft:cyan_concrete
fill 226 172 627 229 172 631 minecraft:cyan_concrete
fill 227 172 626 229 172 626 minecraft:cyan_concrete
fill 196 173 626 198 187 626 minecraft:pink_concrete
fill 197 173 625 197 187 625 minecraft:pink_concrete
fill 197 173 627 197 187 627 minecraft:pink_concrete
fill 200 173 616 201 187 617 minecraft:light_blue_concrete
fill 200 173 635 201 187 636 minecraft:light_blue_concrete
fill 209 173 613 211 187 613 minecraft:pink_concrete
fill 209 173 639 211 187 639 minecraft:pink_concrete
fill 210 173 612 210 187 612 minecraft:pink_concrete
fill 210 173 614 210 187 614 minecraft:pink_concrete
fill 210 173 638 210 187 638 minecraft:pink_concrete
fill 210 173 640 210 187 640 minecraft:pink_concrete
fill 219 173 616 220 187 617 minecraft:light_blue_concrete
fill 219 173 635 220 187 636 minecraft:light_blue_concrete
fill 222 173 626 224 187 626 minecraft:pink_concrete
fill 223 173 625 223 187 625 minecraft:pink_concrete
fill 223 173 627 223 187 627 minecraft:pink_concrete
fill 204 174 625 205 175 627 minecraft:magenta_concrete
fill 205 174 623 205 175 624 minecraft:magenta_concrete
fill 205 174 628 205 175 629 minecraft:magenta_concrete
fill 206 174 622 206 175 623 minecraft:magenta_concrete
fill 206 174 629 206 175 630 minecraft:magenta_concrete
fill 207 174 621 207 175 622 minecraft:magenta_concrete
fill 207 174 630 207 175 631 minecraft:magenta_concrete
fill 208 174 621 213 175 621 minecraft:magenta_concrete
fill 208 174 631 213 175 631 minecraft:magenta_concrete
fill 209 174 620 211 175 620 minecraft:magenta_concrete
fill 209 174 632 211 175 632 minecraft:magenta_concrete
fill 213 174 622 214 175 622 minecraft:magenta_concrete
fill 213 174 630 214 175 630 minecraft:magenta_concrete
fill 214 174 623 215 175 623 minecraft:magenta_concrete
fill 214 174 629 215 175 629 minecraft:magenta_concrete
fill 215 174 624 215 175 628 minecraft:magenta_concrete
fill 216 174 625 216 175 627 minecraft:magenta_concrete
setblock 191 175 607 minecraft:light[level=14]
setblock 191 175 615 minecraft:light[level=14]
setblock 191 175 623 minecraft:light[level=14]
setblock 191 175 631 minecraft:light[level=14]
setblock 191 175 639 minecraft:light[level=14]
setblock 199 175 607 minecraft:light[level=14]
setblock 199 175 615 minecraft:light[level=14]
setblock 199 175 623 minecraft:light[level=14]
setblock 199 175 631 minecraft:light[level=14]
setblock 199 175 639 minecraft:light[level=14]
setblock 207 175 607 minecraft:light[level=14]
setblock 207 175 615 minecraft:light[level=14]
setblock 207 175 623 minecraft:light[level=14]
setblock 207 175 639 minecraft:light[level=14]
setblock 215 175 607 minecraft:light[level=14]
setblock 215 175 615 minecraft:light[level=14]
setblock 215 175 631 minecraft:light[level=14]
setblock 215 175 639 minecraft:light[level=14]
setblock 223 175 607 minecraft:light[level=14]
setblock 223 175 615 minecraft:light[level=14]
setblock 223 175 623 minecraft:light[level=14]
setblock 223 175 631 minecraft:light[level=14]
setblock 223 175 639 minecraft:light[level=14]
fill 188 176 609 188 177 609 minecraft:sea_lantern
fill 188 176 617 188 177 617 minecraft:sea_lantern
fill 188 176 625 188 177 625 minecraft:sea_lantern
fill 188 176 633 188 177 633 minecraft:sea_lantern
fill 188 176 641 188 177 641 minecraft:sea_lantern
fill 189 176 611 189 227 612 minecraft:black_concrete
fill 189 176 619 189 227 620 minecraft:black_concrete
fill 189 176 627 189 227 628 minecraft:black_concrete
fill 189 176 635 189 216 636 minecraft:black_concrete
fill 189 176 643 189 227 644 minecraft:black_concrete
fill 190 176 605 191 227 605 minecraft:black_concrete
fill 190 176 646 190 232 646 minecraft:magenta_concrete
fill 191 176 646 191 177 646 minecraft:sea_lantern
fill 192 176 646 192 232 646 minecraft:magenta_concrete
fill 195 176 604 195 177 604 minecraft:sea_lantern
fill 195 176 645 196 227 645 minecraft:black_concrete
fill 198 176 605 199 227 605 minecraft:black_concrete
fill 199 176 646 199 177 646 minecraft:sea_lantern
fill 203 176 604 203 177 604 minecraft:sea_lantern
fill 203 176 645 204 227 645 minecraft:black_concrete
fill 206 176 605 207 227 605 minecraft:black_concrete
fill 207 176 646 207 177 646 minecraft:sea_lantern
fill 211 176 604 211 177 604 minecraft:sea_lantern
fill 211 176 645 212 227 645 minecraft:black_concrete
fill 214 176 605 215 227 605 minecraft:black_concrete
fill 215 176 646 215 177 646 minecraft:sea_lantern
fill 219 176 604 219 177 604 minecraft:sea_lantern
fill 219 176 645 220 227 645 minecraft:black_concrete
fill 222 176 605 223 227 605 minecraft:black_concrete
fill 223 176 646 223 177 646 minecraft:sea_lantern
fill 227 176 604 227 177 604 minecraft:sea_lantern
fill 227 176 645 228 227 645 minecraft:black_concrete
fill 229 176 606 229 227 607 minecraft:black_concrete
fill 229 176 614 229 227 615 minecraft:black_concrete
fill 229 176 622 229 227 623 minecraft:black_concrete
fill 229 176 630 229 227 631 minecraft:black_concrete
fill 229 176 638 229 227 639 minecraft:black_concrete
fill 230 176 609 230 177 609 minecraft:sea_lantern
fill 230 176 617 230 177 617 minecraft:sea_lantern
fill 230 176 625 230 177 625 minecraft:sea_lantern
fill 230 176 633 230 177 633 minecraft:sea_lantern
fill 230 176 641 230 177 641 minecraft:sea_lantern
fill 188 178 609 188 185 609 minecraft:magenta_concrete
fill 188 178 617 188 185 617 minecraft:magenta_concrete
fill 188 178 625 188 185 625 minecraft:magenta_concrete
fill 188 178 633 188 185 633 minecraft:magenta_concrete
fill 188 178 641 188 185 641 minecraft:magenta_concrete
fill 191 178 646 191 185 646 minecraft:magenta_concrete
fill 195 178 604 195 185 604 minecraft:magenta_concrete
fill 199 178 646 199 185 646 minecraft:magenta_concrete
fill 202 178 625 203 179 627 minecraft:cyan_concrete
fill 203 178 604 203 185 604 minecraft:magenta_concrete
fill 203 178 622 203 179 624 minecraft:cyan_concrete
fill 203 178 628 203 179 630 minecraft:cyan_concrete
fill 204 178 621 204 179 622 minecraft:cyan_concrete
fill 204 178 630 204 179 631 minecraft:cyan_concrete
fill 205 178 620 205 179 621 minecraft:cyan_concrete
fill 205 178 631 205 179 632 minecraft:cyan_concrete
fill 206 178 619 206 179 620 minecraft:cyan_concrete
fill 206 178 632 206 179 633 minecraft:cyan_concrete
fill 207 178 619 214 179 619 minecraft:cyan_concrete
fill 207 178 633 214 179 633 minecraft:cyan_concrete
fill 207 178 646 207 185 646 minecraft:magenta_concrete
fill 209 178 618 211 179 618 minecraft:cyan_concrete
fill 209 178 634 211 179 634 minecraft:cyan_concrete
fill 211 178 604 211 185 604 minecraft:magenta_concrete
fill 214 178 620 215 179 620 minecraft:cyan_concrete
fill 214 178 632 215 179 632 minecraft:cyan_concrete
fill 215 178 621 216 179 621 minecraft:cyan_concrete
fill 215 178 631 216 179 631 minecraft:cyan_concrete
fill 215 178 646 215 185 646 minecraft:magenta_concrete
fill 216 178 622 217 179 622 minecraft:cyan_concrete
fill 216 178 630 217 179 630 minecraft:cyan_concrete
fill 217 178 623 217 179 629 minecraft:cyan_concrete
fill 218 178 625 218 179 627 minecraft:cyan_concrete
fill 219 178 604 219 185 604 minecraft:magenta_concrete
fill 223 178 646 223 185 646 minecraft:magenta_concrete
fill 227 178 604 227 185 604 minecraft:magenta_concrete
fill 230 178 609 230 185 609 minecraft:magenta_concrete
fill 230 178 617 230 185 617 minecraft:magenta_concrete
fill 230 178 625 230 185 625 minecraft:magenta_concrete
fill 230 178 633 230 185 633 minecraft:magenta_concrete
fill 230 178 641 230 185 641 minecraft:magenta_concrete
fill 189 182 605 189 183 610 minecraft:black_concrete
fill 189 182 613 190 182 618 minecraft:black_concrete
fill 189 182 621 190 182 626 minecraft:black_concrete
fill 189 182 629 190 182 634 minecraft:black_concrete
fill 189 182 637 190 182 642 minecraft:black_concrete
fill 189 182 645 194 183 645 minecraft:black_concrete
fill 190 182 606 190 182 612 minecraft:black_concrete
fill 190 182 619 190 182 620 minecraft:black_concrete
fill 190 182 627 190 182 628 minecraft:black_concrete
fill 190 182 635 190 182 636 minecraft:black_concrete
fill 190 182 643 190 182 644 minecraft:black_concrete
fill 191 182 606 228 182 606 minecraft:black_concrete
fill 191 182 644 229 182 644 minecraft:black_concrete
fill 192 182 605 197 183 605 minecraft:black_concrete
fill 197 182 645 202 183 645 minecraft:black_concrete
fill 200 182 605 205 183 605 minecraft:black_concrete
fill 200 182 625 201 183 627 minecraft:lime_concrete
fill 201 182 622 201 183 624 minecraft:lime_concrete
fill 201 182 628 201 183 630 minecraft:lime_concrete
fill 202 182 620 202 183 622 minecraft:lime_concrete
fill 202 182 630 202 183 632 minecraft:lime_concrete
fill 203 182 619 203 183 620 minecraft:lime_concrete
fill 203 182 632 203 183 633 minecraft:lime_concrete
fill 204 182 618 204 183 619 minecraft:lime_concrete
fill 204 182 633 204 183 634 minecraft:lime_concrete
fill 205 182 618 206 183 618 minecraft:lime_concrete
fill 205 182 634 206 183 634 minecraft:lime_concrete
fill 205 182 645 210 183 645 minecraft:black_concrete
fill 206 182 617 214 183 617 minecraft:lime_concrete
fill 206 182 635 214 183 635 minecraft:lime_concrete
fill 208 182 605 213 183 605 minecraft:black_concrete
fill 209 182 616 211 183 616 minecraft:lime_concrete
fill 209 182 636 211 183 636 minecraft:lime_concrete
fill 213 182 645 218 183 645 minecraft:black_concrete
fill 214 182 618 216 183 618 minecraft:lime_concrete
fill 214 182 634 216 183 634 minecraft:lime_concrete
fill 216 182 605 221 183 605 minecraft:black_concrete
fill 216 182 619 217 183 619 minecraft:lime_concrete
fill 216 182 633 217 183 633 minecraft:lime_concrete
fill 217 182 620 218 183 620 minecraft:lime_concrete
fill 217 182 621 217 183 621 minecraft:cyan_concrete
fill 217 182 632 218 183 632 minecraft:lime_concrete
fill 218 182 621 218 183 622 minecraft:lime_concrete
fill 218 182 630 218 183 631 minecraft:lime_concrete
fill 219 182 622 219 183 630 minecraft:lime_concrete
fill 220 182 625 220 183 627 minecraft:lime_concrete
fill 221 182 645 226 183 645 minecraft:black_concrete
fill 224 182 605 229 183 605 minecraft:black_concrete
fill 228 182 607 228 182 643 minecraft:black_concrete
fill 229 182 608 229 183 613 minecraft:black_concrete
fill 229 182 616 229 183 621 minecraft:black_concrete
fill 229 182 624 229 183 629 minecraft:black_concrete
fill 229 182 632 229 183 637 minecraft:black_concrete
fill 229 182 640 229 183 643 minecraft:black_concrete
fill 229 182 645 229 183 645 minecraft:black_concrete
fill 189 183 613 189 183 618 minecraft:black_concrete
fill 189 183 621 189 183 626 minecraft:black_concrete
fill 189 183 629 189 183 634 minecraft:black_concrete
fill 189 183 637 189 183 642 minecraft:black_concrete
setblock 191 183 607 minecraft:light[level=14]
setblock 191 183 615 minecraft:light[level=14]
setblock 191 183 623 minecraft:light[level=14]
setblock 191 183 631 minecraft:light[level=14]
setblock 191 183 639 minecraft:light[level=14]
setblock 199 183 607 minecraft:light[level=14]
setblock 199 183 615 minecraft:light[level=14]
setblock 199 183 623 minecraft:light[level=14]
setblock 199 183 631 minecraft:light[level=14]
setblock 199 183 639 minecraft:light[level=14]
setblock 207 183 607 minecraft:light[level=14]
setblock 207 183 615 minecraft:light[level=14]
setblock 207 183 623 minecraft:light[level=14]
setblock 207 183 631 minecraft:light[level=14]
setblock 207 183 639 minecraft:light[level=14]
setblock 215 183 607 minecraft:light[level=14]
setblock 215 183 615 minecraft:light[level=14]
setblock 215 183 623 minecraft:light[level=14]
setblock 215 183 631 minecraft:light[level=14]
setblock 215 183 639 minecraft:light[level=14]
setblock 223 183 607 minecraft:light[level=14]
setblock 223 183 615 minecraft:light[level=14]
setblock 223 183 623 minecraft:light[level=14]
setblock 223 183 631 minecraft:light[level=14]
setblock 223 183 639 minecraft:light[level=14]
setblock 229 183 644 minecraft:black_concrete
fill 217 184 611 217 185 612 minecraft:cyan_concrete
fill 214 185 611 214 186 611 minecraft:lime_concrete
fill 188 186 609 188 191 609 minecraft:sea_lantern
fill 188 186 617 188 191 617 minecraft:sea_lantern
fill 188 186 625 188 191 625 minecraft:sea_lantern
fill 188 186 633 188 191 633 minecraft:sea_lantern
fill 188 186 641 188 191 641 minecraft:sea_lantern
fill 191 186 646 191 191 646 minecraft:sea_lantern
fill 195 186 604 195 191 604 minecraft:sea_lantern
fill 199 186 646 199 191 646 minecraft:sea_lantern
fill 203 186 604 203 191 604 minecraft:sea_lantern
fill 207 186 646 207 191 646 minecraft:sea_lantern
fill 211 186 604 211 191 604 minecraft:sea_lantern
fill 215 186 646 215 191 646 minecraft:sea_lantern
fill 219 186 604 219 191 604 minecraft:sea_lantern
fill 223 186 646 223 191 646 minecraft:sea_lantern
fill 227 186 604 227 191 604 minecraft:sea_lantern
fill 230 186 609 230 191 609 minecraft:sea_lantern
fill 230 186 617 230 191 617 minecraft:sea_lantern
fill 230 186 625 230 191 625 minecraft:sea_lantern
fill 230 186 633 230 191 633 minecraft:sea_lantern
fill 230 186 641 230 191 641 minecraft:sea_lantern
fill 196 188 626 198 188 626 minecraft:glowstone
setblock 197 188 625 minecraft:glowstone
setblock 197 188 627 minecraft:glowstone
fill 200 188 616 201 188 617 minecraft:glowstone
fill 200 188 635 201 188 636 minecraft:glowstone
setblock 201 188 618 minecraft:glowstone
setblock 201 188 634 minecraft:glowstone
setblock 202 188 617 minecraft:glowstone
setblock 202 188 635 minecraft:glowstone
fill 209 188 613 211 188 613 minecraft:glowstone
fill 209 188 639 211 188 639 minecraft:glowstone
setblock 210 188 612 minecraft:glowstone
setblock 210 188 614 minecraft:glowstone
setblock 210 188 638 minecraft:glowstone
setblock 210 188 640 minecraft:glowstone
fill 218 188 617 220 188 617 minecraft:glowstone
fill 218 188 635 220 188 635 minecraft:glowstone
fill 219 188 616 220 188 616 minecraft:glowstone
setblock 219 188 618 minecraft:glowstone
setblock 219 188 634 minecraft:glowstone
fill 219 188 636 220 188 636 minecraft:glowstone
fill 222 188 626 224 188 626 minecraft:glowstone
setblock 223 188 625 minecraft:glowstone
setblock 223 188 627 minecraft:glowstone
setblock 197 189 625 minecraft:white_stained_glass
fill 194 190 618 196 191 618 minecraft:lime_concrete
fill 195 190 617 195 191 617 minecraft:lime_concrete
fill 195 190 619 195 191 619 minecraft:lime_concrete
fill 197 190 625 198 200 625 minecraft:black_concrete
setblock 191 191 607 minecraft:light[level=14]
setblock 191 191 615 minecraft:light[level=14]
setblock 191 191 623 minecraft:light[level=14]
setblock 191 191 631 minecraft:light[level=14]
setblock 191 191 639 minecraft:light[level=14]
fill 197 191 626 198 200 626 minecraft:black_concrete
setblock 199 191 607 minecraft:light[level=14]
setblock 199 191 615 minecraft:light[level=14]
setblock 199 191 623 minecraft:light[level=14]
setblock 199 191 631 minecraft:light[level=14]
setblock 199 191 639 minecraft:light[level=14]
setblock 207 191 607 minecraft:light[level=14]
setblock 207 191 615 minecraft:light[level=14]
setblock 207 191 623 minecraft:light[level=14]
setblock 207 191 631 minecraft:light[level=14]
setblock 207 191 639 minecraft:light[level=14]
setblock 215 191 607 minecraft:light[level=14]
setblock 215 191 615 minecraft:light[level=14]
setblock 215 191 623 minecraft:light[level=14]
setblock 215 191 631 minecraft:light[level=14]
setblock 215 191 639 minecraft:light[level=14]
setblock 223 191 607 minecraft:light[level=14]
setblock 223 191 615 minecraft:light[level=14]
setblock 223 191 623 minecraft:light[level=14]
setblock 223 191 631 minecraft:light[level=14]
setblock 223 191 639 minecraft:light[level=14]
fill 188 192 609 188 199 609 minecraft:magenta_concrete
fill 188 192 617 188 199 617 minecraft:magenta_concrete
fill 188 192 625 188 199 625 minecraft:magenta_concrete
fill 188 192 633 188 199 633 minecraft:magenta_concrete
fill 188 192 641 188 199 641 minecraft:magenta_concrete
fill 191 192 646 191 199 646 minecraft:magenta_concrete
fill 195 192 604 195 199 604 minecraft:magenta_concrete
fill 196 192 625 196 200 625 minecraft:black_concrete
fill 197 192 624 198 200 624 minecraft:black_concrete
fill 199 192 646 199 199 646 minecraft:magenta_concrete
fill 203 192 604 203 199 604 minecraft:magenta_concrete
fill 207 192 646 207 199 646 minecraft:magenta_concrete
fill 211 192 604 211 199 604 minecraft:magenta_concrete
fill 215 192 646 215 199 646 minecraft:magenta_concrete
fill 219 192 604 219 199 604 minecraft:magenta_concrete
fill 223 192 646 223 199 646 minecraft:magenta_concrete
fill 227 192 604 227 199 604 minecraft:magenta_concrete
fill 230 192 609 230 199 609 minecraft:magenta_concrete
fill 230 192 617 230 199 617 minecraft:magenta_concrete
fill 230 192 625 230 199 625 minecraft:magenta_concrete
fill 230 192 633 230 199 633 minecraft:magenta_concrete
fill 230 192 641 230 199 641 minecraft:magenta_concrete
fill 196 193 624 196 200 624 minecraft:black_concrete
fill 196 193 626 196 200 626 minecraft:black_concrete
fill 197 193 627 198 200 627 minecraft:black_concrete
fill 199 193 624 199 200 626 minecraft:black_concrete
fill 195 194 625 195 200 625 minecraft:black_concrete
fill 196 194 627 196 200 627 minecraft:black_concrete
fill 197 194 623 198 200 623 minecraft:black_concrete
fill 199 194 627 199 200 627 minecraft:black_concrete
fill 191 195 621 192 196 629 minecraft:black_concrete
fill 192 195 618 193 196 620 minecraft:black_concrete
fill 192 195 630 193 196 632 minecraft:black_concrete
fill 193 195 616 194 196 617 minecraft:black_concrete
fill 193 195 633 194 196 634 minecraft:black_concrete
fill 194 195 615 195 196 615 minecraft:black_concrete
fill 194 195 618 194 196 618 minecraft:black_concrete
fill 194 195 632 194 196 632 minecraft:black_concrete
fill 194 195 635 195 196 635 minecraft:black_concrete
fill 195 195 613 196 196 614 minecraft:black_concrete
fill 195 195 616 195 196 616 minecraft:black_concrete
fill 195 195 624 195 200 624 minecraft:black_concrete
fill 195 195 626 195 200 626 minecraft:black_concrete
fill 195 195 634 195 196 634 minecraft:black_concrete
fill 195 195 636 196 196 637 minecraft:black_concrete
fill 196 195 612 198 196 612 minecraft:black_concrete
fill 196 195 623 196 200 623 minecraft:black_concrete
fill 196 195 638 198 196 638 minecraft:black_concrete
fill 197 195 611 200 196 611 minecraft:black_concrete
fill 197 195 613 197 196 613 minecraft:black_concrete
fill 197 195 628 198 200 628 minecraft:black_concrete
fill 197 195 637 197 196 637 minecraft:black_concrete
fill 197 195 639 200 196 639 minecraft:black_concrete
fill 199 195 610 202 196 610 minecraft:black_concrete
fill 199 195 623 199 200 623 minecraft:black_concrete
fill 199 195 640 202 196 640 minecraft:black_concrete
fill 200 195 609 204 196 609 minecraft:black_concrete
fill 200 195 624 200 200 626 minecraft:black_concrete
fill 200 195 641 204 196 641 minecraft:black_concrete
fill 202 195 608 216 196 608 minecraft:black_concrete
fill 202 195 642 216 196 642 minecraft:black_concrete
fill 205 195 607 213 196 607 minecraft:black_concrete
fill 205 195 643 213 196 643 minecraft:black_concrete
fill 214 195 609 218 196 609 minecraft:black_concrete
fill 214 195 641 218 196 641 minecraft:black_concrete
fill 216 195 610 219 196 610 minecraft:black_concrete
fill 216 195 640 219 196 640 minecraft:black_concrete
fill 218 195 611 221 196 611 minecraft:black_concrete
fill 218 195 639 221 196 639 minecraft:black_concrete
fill 220 195 612 222 196 612 minecraft:black_concrete
fill 220 195 638 222 196 638 minecraft:black_concrete
fill 221 195 613 223 196 613 minecraft:black_concrete
fill 221 195 637 223 196 637 minecraft:black_concrete
fill 222 195 614 223 196 614 minecraft:black_concrete
fill 222 195 636 223 196 636 minecraft:black_concrete
fill 223 195 615 224 196 616 minecraft:black_concrete
fill 223 195 634 224 196 635 minecraft:black_concrete
fill 224 195 617 225 196 618 minecraft:black_concrete
fill 224 195 632 225 196 633 minecraft:black_concrete
fill 225 195 616 225 196 616 minecraft:black_concrete
fill 225 195 619 226 196 620 minecraft:black_concrete
fill 225 195 630 226 196 631 minecraft:black_concrete
fill 225 195 634 225 196 634 minecraft:black_concrete
fill 226 195 618 226 196 618 minecraft:black_concrete
fill 226 195 621 227 196 629 minecraft:black_concrete
fill 226 195 632 226 196 632 minecraft:black_concrete
fill 189 196 605 189 197 610 minecraft:black_concrete
fill 189 196 613 190 196 618 minecraft:black_concrete
fill 189 196 621 190 196 626 minecraft:black_concrete
fill 189 196 629 190 196 634 minecraft:black_concrete
fill 189 196 637 190 196 642 minecraft:black_concrete
fill 189 196 645 194 197 645 minecraft:black_concrete
fill 190 196 606 190 196 612 minecraft:black_concrete
fill 190 196 619 190 196 620 minecraft:black_concrete
fill 190 196 627 190 196 628 minecraft:black_concrete
fill 190 196 635 190 196 636 minecraft:black_concrete
fill 190 196 643 190 196 644 minecraft:black_concrete
fill 191 196 606 228 196 606 minecraft:black_concrete
fill 191 196 644 229 196 644 minecraft:black_concrete
fill 192 196 605 197 197 605 minecraft:black_concrete
fill 194 196 625 194 200 625 minecraft:black_concrete
fill 195 196 623 195 200 623 minecraft:black_concrete
fill 195 196 627 195 200 627 minecraft:black_concrete
fill 196 196 622 199 200 622 minecraft:black_concrete
fill 196 196 628 196 200 628 minecraft:black_concrete
fill 197 196 645 202 197 645 minecraft:black_concrete
fill 199 196 628 199 200 628 minecraft:black_concrete
fill 200 196 605 205 197 605 minecraft:black_concrete
fill 200 196 623 200 200 623 minecraft:black_concrete
fill 200 196 627 200 200 627 minecraft:black_concrete
fill 205 196 645 210 197 645 minecraft:black_concrete
fill 208 196 605 213 197 605 minecraft:black_concrete
fill 213 196 645 218 197 645 minecraft:black_concrete
fill 216 196 605 221 197 605 minecraft:black_concrete
fill 221 196 645 226 197 645 minecraft:black_concrete
fill 224 196 605 229 197 605 minecraft:black_concrete
fill 228 196 607 228 196 643 minecraft:black_concrete
fill 229 196 608 229 197 613 minecraft:black_concrete
fill 229 196 616 229 197 621 minecraft:black_concrete
fill 229 196 624 229 197 629 minecraft:black_concrete
fill 229 196 632 229 197 637 minecraft:black_concrete
fill 229 196 640 229 197 643 minecraft:black_concrete
fill 229 196 645 229 197 645 minecraft:black_concrete
fill 189 197 613 189 197 618 minecraft:black_concrete
fill 189 197 621 189 197 626 minecraft:black_concrete
fill 189 197 629 189 197 634 minecraft:black_concrete
fill 189 197 637 189 197 642 minecraft:black_concrete
fill 191 197 621 191 197 628 minecraft:sea_lantern
fill 192 197 618 192 197 620 minecraft:sea_lantern
fill 193 197 616 193 197 617 minecraft:sea_lantern
setblock 194 197 615 minecraft:sea_lantern
fill 194 197 624 194 200 624 minecraft:black_concrete
fill 194 197 626 194 200 627 minecraft:black_concrete
fill 195 197 613 195 197 614 minecraft:sea_lantern
fill 195 197 622 195 200 622 minecraft:black_concrete
fill 195 197 628 195 200 628 minecraft:black_concrete
fill 196 197 612 196 197 613 minecraft:sea_lantern
fill 197 197 611 197 197 612 minecraft:sea_lantern
fill 197 197 629 198 200 629 minecraft:black_concrete
setblock 198 197 611 minecraft:sea_lantern
setblock 199 197 610 minecraft:sea_lantern
fill 200 197 609 201 197 609 minecraft:sea_lantern
fill 200 197 628 200 200 628 minecraft:black_concrete
fill 201 197 624 201 200 626 minecraft:black_concrete
fill 202 197 608 204 197 608 minecraft:sea_lantern
fill 205 197 607 213 197 607 minecraft:sea_lantern
fill 214 197 608 216 197 608 minecraft:sea_lantern
fill 217 197 609 218 197 609 minecraft:sea_lantern
setblock 219 197 610 minecraft:sea_lantern
fill 220 197 611 221 197 611 minecraft:sea_lantern
fill 221 197 612 222 197 612 minecraft:sea_lantern
fill 222 197 613 223 197 613 minecraft:sea_lantern
setblock 223 197 614 minecraft:sea_lantern
setblock 224 197 615 minecraft:sea_lantern
fill 225 197 616 225 197 617 minecraft:sea_lantern
fill 226 197 618 226 197 620 minecraft:sea_lantern
fill 227 197 621 227 197 625 minecraft:sea_lantern
setblock 229 197 644 minecraft:black_concrete
fill 193 198 625 193 200 625 minecraft:black_concrete
fill 194 198 623 194 200 623 minecraft:black_concrete
fill 194 198 628 194 200 628 minecraft:black_concrete
fill 196 198 621 199 200 621 minecraft:black_concrete
fill 196 198 629 196 200 629 minecraft:black_concrete
fill 199 198 629 199 200 629 minecraft:black_concrete
fill 200 198 622 200 200 622 minecraft:black_concrete
fill 201 198 623 201 200 623 minecraft:black_concrete
fill 201 198 627 201 200 627 minecraft:black_concrete
setblock 191 199 607 minecraft:light[level=14]
setblock 191 199 615 minecraft:light[level=14]
setblock 191 199 623 minecraft:light[level=14]
setblock 191 199 631 minecraft:light[level=14]
setblock 191 199 639 minecraft:light[level=14]
fill 193 199 623 193 200 624 minecraft:black_concrete
fill 193 199 626 193 200 627 minecraft:black_concrete
fill 194 199 622 194 200 622 minecraft:black_concrete
fill 195 199 621 195 200 621 minecraft:black_concrete
fill 195 199 629 195 200 629 minecraft:black_concrete
fill 197 199 630 198 200 630 minecraft:black_concrete
setblock 199 199 607 minecraft:light[level=14]
setblock 199 199 615 minecraft:light[level=14]
setblock 199 199 631 minecraft:light[level=14]
setblock 199 199 639 minecraft:light[level=14]
fill 200 199 621 200 200 621 minecraft:black_concrete
fill 200 199 629 200 200 629 minecraft:black_concrete
fill 201 199 622 201 200 622 minecraft:black_concrete
fill 201 199 628 201 200 628 minecraft:black_concrete
fill 202 199 624 202 200 627 minecraft:black_concrete
setblock 207 199 607 minecraft:light[level=14]
setblock 207 199 615 minecraft:light[level=14]
setblock 207 199 623 minecraft:light[level=14]
setblock 207 199 631 minecraft:light[level=14]
setblock 207 199 639 minecraft:light[level=14]
setblock 215 199 607 minecraft:light[level=14]
setblock 215 199 615 minecraft:light[level=14]
setblock 215 199 623 minecraft:light[level=14]
setblock 215 199 631 minecraft:light[level=14]
setblock 215 199 639 minecraft:light[level=14]
setblock 223 199 607 minecraft:light[level=14]
setblock 223 199 615 minecraft:light[level=14]
setblock 223 199 623 minecraft:light[level=14]
setblock 223 199 631 minecraft:light[level=14]
setblock 223 199 639 minecraft:light[level=14]
fill 188 200 609 188 205 609 minecraft:sea_lantern
fill 188 200 617 188 205 617 minecraft:sea_lantern
fill 188 200 625 188 205 625 minecraft:sea_lantern
fill 188 200 633 188 205 633 minecraft:sea_lantern
fill 188 200 641 188 205 641 minecraft:sea_lantern
fill 191 200 646 191 205 646 minecraft:sea_lantern
setblock 192 200 625 minecraft:black_concrete
setblock 193 200 622 minecraft:black_concrete
setblock 193 200 628 minecraft:black_concrete
setblock 194 200 621 minecraft:black_concrete
setblock 194 200 629 minecraft:black_concrete
fill 195 200 604 195 205 604 minecraft:sea_lantern
fill 195 200 630 196 200 630 minecraft:black_concrete
fill 196 200 620 199 200 620 minecraft:black_concrete
setblock 199 200 630 minecraft:black_concrete
fill 199 200 646 199 205 646 minecraft:sea_lantern
setblock 201 200 621 minecraft:black_concrete
setblock 201 200 629 minecraft:black_concrete
setblock 202 200 623 minecraft:black_concrete
setblock 202 200 628 minecraft:black_concrete
fill 203 200 604 203 205 604 minecraft:sea_lantern
fill 207 200 646 207 205 646 minecraft:sea_lantern
fill 211 200 604 211 205 604 minecraft:sea_lantern
fill 215 200 646 215 205 646 minecraft:sea_lantern
fill 219 200 604 219 205 604 minecraft:sea_lantern
fill 223 200 646 223 205 646 minecraft:sea_lantern
fill 227 200 604 227 205 604 minecraft:sea_lantern
fill 230 200 609 230 205 609 minecraft:sea_lantern
fill 230 200 617 230 205 617 minecraft:sea_lantern
fill 230 200 625 230 205 625 minecraft:sea_lantern
fill 230 200 633 230 205 633 minecraft:sea_lantern
fill 230 200 641 230 205 641 minecraft:sea_lantern
fill 197 201 624 198 201 626 minecraft:white_stained_glass
fill 197 202 625 198 202 626 minecraft:white_stained_glass
fill 197 203 625 198 203 625 minecraft:white_stained_glass
setblock 197 204 625 minecraft:white_stained_glass
fill 188 206 609 188 213 609 minecraft:magenta_concrete
fill 188 206 617 188 213 617 minecraft:magenta_concrete
fill 188 206 625 188 213 625 minecraft:magenta_concrete
fill 188 206 633 188 213 633 minecraft:magenta_concrete
fill 188 206 641 188 213 641 minecraft:magenta_concrete
fill 191 206 646 191 213 646 minecraft:magenta_concrete
fill 195 206 604 195 213 604 minecraft:magenta_concrete
fill 199 206 646 199 213 646 minecraft:magenta_concrete
fill 203 206 604 203 213 604 minecraft:magenta_concrete
fill 207 206 646 207 213 646 minecraft:magenta_concrete
fill 211 206 604 211 213 604 minecraft:magenta_concrete
fill 215 206 646 215 213 646 minecraft:magenta_concrete
fill 219 206 604 219 213 604 minecraft:magenta_concrete
fill 223 206 646 223 213 646 minecraft:magenta_concrete
fill 227 206 604 227 213 604 minecraft:magenta_concrete
fill 230 206 609 230 213 609 minecraft:magenta_concrete
fill 230 206 617 230 213 617 minecraft:magenta_concrete
fill 230 206 625 230 213 625 minecraft:magenta_concrete
fill 230 206 633 230 213 633 minecraft:magenta_concrete
fill 230 206 641 230 213 641 minecraft:magenta_concrete
setblock 191 207 607 minecraft:light[level=14]
setblock 191 207 615 minecraft:light[level=14]
setblock 191 207 623 minecraft:light[level=14]
setblock 191 207 631 minecraft:light[level=14]
setblock 191 207 639 minecraft:light[level=14]
setblock 199 207 607 minecraft:light[level=14]
setblock 199 207 615 minecraft:light[level=14]
setblock 199 207 623 minecraft:light[level=14]
setblock 199 207 631 minecraft:light[level=14]
setblock 199 207 639 minecraft:light[level=14]
setblock 207 207 607 minecraft:light[level=14]
setblock 207 207 615 minecraft:light[level=14]
setblock 207 207 623 minecraft:light[level=14]
setblock 207 207 631 minecraft:light[level=14]
setblock 207 207 639 minecraft:light[level=14]
setblock 215 207 607 minecraft:light[level=14]
setblock 215 207 615 minecraft:light[level=14]
setblock 215 207 623 minecraft:light[level=14]
setblock 215 207 631 minecraft:light[level=14]
setblock 215 207 639 minecraft:light[level=14]
setblock 223 207 607 minecraft:light[level=14]
setblock 223 207 615 minecraft:light[level=14]
setblock 223 207 623 minecraft:light[level=14]
setblock 223 207 631 minecraft:light[level=14]
setblock 223 207 639 minecraft:light[level=14]
fill 199 208 633 199 209 633 minecraft:white_stained_glass
fill 189 210 605 189 211 610 minecraft:black_concrete
fill 189 210 613 190 210 618 minecraft:black_concrete
fill 189 210 621 190 210 626 minecraft:black_concrete
fill 189 210 629 190 210 634 minecraft:black_concrete
fill 189 210 637 190 210 642 minecraft:black_concrete
fill 189 210 645 194 211 645 minecraft:black_concrete
fill 190 210 606 190 210 612 minecraft:black_concrete
fill 190 210 619 190 210 620 minecraft:black_concrete
fill 190 210 627 190 210 628 minecraft:black_concrete
fill 190 210 635 190 210 636 minecraft:black_concrete
fill 190 210 643 190 210 644 minecraft:black_concrete
fill 191 210 606 228 210 606 minecraft:black_concrete
fill 191 210 644 229 210 644 minecraft:black_concrete
fill 192 210 605 197 211 605 minecraft:black_concrete
fill 193 210 636 193 215 636 minecraft:white_concrete
fill 197 210 645 202 211 645 minecraft:black_concrete
fill 199 210 633 199 219 633 minecraft:black_concrete
fill 200 210 605 205 211 605 minecraft:black_concrete
fill 205 210 645 210 211 645 minecraft:black_concrete
fill 206 210 611 207 211 611 minecraft:yellow_concrete
fill 208 210 605 213 211 605 minecraft:black_concrete
fill 213 210 645 218 211 645 minecraft:black_concrete
fill 216 210 605 221 211 605 minecraft:black_concrete
fill 221 210 645 226 211 645 minecraft:black_concrete
fill 224 210 605 229 211 605 minecraft:black_concrete
fill 228 210 607 228 210 643 minecraft:black_concrete
fill 229 210 608 229 211 613 minecraft:black_concrete
fill 229 210 616 229 211 621 minecraft:black_concrete
fill 229 210 624 229 211 629 minecraft:black_concrete
fill 229 210 632 229 211 637 minecraft:black_concrete
fill 229 210 640 229 211 643 minecraft:black_concrete
fill 229 210 645 229 211 645 minecraft:black_concrete
fill 189 211 613 189 211 618 minecraft:black_concrete
fill 189 211 621 189 211 626 minecraft:black_concrete
fill 189 211 629 189 211 634 minecraft:black_concrete
fill 189 211 637 189 211 642 minecraft:black_concrete
fill 193 211 635 193 215 635 minecraft:white_concrete
fill 193 211 637 193 215 637 minecraft:white_concrete
fill 194 211 636 194 215 636 minecraft:white_concrete
fill 200 211 633 200 219 633 minecraft:black_concrete
setblock 229 211 644 minecraft:black_concrete
fill 192 212 635 192 215 637 minecraft:white_concrete
fill 194 212 635 194 215 635 minecraft:white_concrete
fill 194 212 637 194 215 637 minecraft:white_concrete
fill 195 212 636 195 215 636 minecraft:white_concrete
fill 199 212 634 200 219 634 minecraft:black_concrete
fill 191 213 635 191 215 637 minecraft:white_concrete
fill 192 213 634 194 215 634 minecraft:white_concrete
fill 192 213 638 194 215 638 minecraft:white_concrete
fill 195 213 635 195 215 635 minecraft:white_concrete
fill 195 213 637 195 215 637 minecraft:white_concrete
fill 198 213 633 198 216 634 minecraft:black_concrete
fill 199 213 632 200 219 632 minecraft:black_concrete
fill 199 213 635 199 219 635 minecraft:black_concrete
fill 201 213 633 201 219 633 minecraft:black_concrete
fill 188 214 609 188 219 609 minecraft:sea_lantern
fill 188 214 617 188 219 617 minecraft:sea_lantern
fill 188 214 625 188 219 625 minecraft:sea_lantern
fill 188 214 633 188 219 633 minecraft:sea_lantern
fill 188 214 641 188 219 641 minecraft:sea_lantern
fill 190 214 636 190 215 636 minecraft:white_concrete
fill 191 214 634 191 215 634 minecraft:white_concrete
fill 191 214 638 191 215 638 minecraft:white_concrete
fill 191 214 646 191 219 646 minecraft:sea_lantern
fill 192 214 633 194 215 633 minecraft:white_concrete
fill 192 214 639 194 215 639 minecraft:white_concrete
fill 195 214 604 195 219 604 minecraft:sea_lantern
fill 195 214 634 195 215 634 minecraft:white_concrete
fill 195 214 638 195 215 638 minecraft:white_concrete
fill 196 214 635 196 215 637 minecraft:white_concrete
fill 198 214 632 198 216 632 minecraft:black_concrete
fill 198 214 635 198 227 635 minecraft:black_concrete
fill 199 214 646 199 219 646 minecraft:sea_lantern
fill 200 214 635 200 219 635 minecraft:black_concrete
fill 201 214 632 201 219 632 minecraft:black_concrete
fill 201 214 634 201 219 634 minecraft:black_concrete
fill 203 214 604 203 219 604 minecraft:sea_lantern
fill 207 214 646 207 219 646 minecraft:sea_lantern
fill 211 214 604 211 219 604 minecraft:sea_lantern
fill 215 214 646 215 219 646 minecraft:sea_lantern
fill 219 214 604 219 219 604 minecraft:sea_lantern
fill 223 214 646 223 219 646 minecraft:sea_lantern
fill 227 214 604 227 219 604 minecraft:sea_lantern
fill 230 214 609 230 219 609 minecraft:sea_lantern
fill 230 214 617 230 219 617 minecraft:sea_lantern
fill 230 214 625 230 219 625 minecraft:sea_lantern
fill 230 214 633 230 219 633 minecraft:sea_lantern
fill 230 214 641 230 219 641 minecraft:sea_lantern
fill 190 215 634 190 215 635 minecraft:white_concrete
fill 190 215 637 190 215 638 minecraft:white_concrete
setblock 191 215 607 minecraft:light[level=14]
setblock 191 215 615 minecraft:light[level=14]
setblock 191 215 623 minecraft:light[level=14]
setblock 191 215 631 minecraft:light[level=14]
setblock 191 215 633 minecraft:white_concrete
setblock 191 215 639 minecraft:white_concrete
setblock 193 215 632 minecraft:white_concrete
setblock 193 215 640 minecraft:white_concrete
setblock 195 215 633 minecraft:white_concrete
setblock 195 215 639 minecraft:white_concrete
setblock 196 215 634 minecraft:white_concrete
setblock 196 215 638 minecraft:white_concrete
fill 197 215 632 197 216 634 minecraft:black_concrete
fill 197 215 635 197 215 637 minecraft:white_concrete
fill 198 215 631 200 219 631 minecraft:black_concrete
setblock 199 215 607 minecraft:light[level=14]
setblock 199 215 615 minecraft:light[level=14]
setblock 199 215 623 minecraft:light[level=14]
setblock 199 215 639 minecraft:light[level=14]
fill 201 215 635 201 219 635 minecraft:black_concrete
fill 202 215 633 202 219 633 minecraft:black_concrete
setblock 207 215 607 minecraft:light[level=14]
setblock 207 215 615 minecraft:light[level=14]
setblock 207 215 623 minecraft:light[level=14]
setblock 207 215 631 minecraft:light[level=14]
setblock 207 215 639 minecraft:light[level=14]
setblock 215 215 607 minecraft:light[level=14]
setblock 215 215 615 minecraft:light[level=14]
setblock 215 215 623 minecraft:light[level=14]
setblock 215 215 631 minecraft:light[level=14]
setblock 215 215 639 minecraft:light[level=14]
setblock 223 215 607 minecraft:light[level=14]
setblock 223 215 615 minecraft:light[level=14]
setblock 223 215 623 minecraft:light[level=14]
setblock 223 215 631 minecraft:light[level=14]
setblock 223 215 639 minecraft:light[level=14]
fill 189 216 631 196 216 634 minecraft:black_concrete
fill 189 216 637 198 216 641 minecraft:black_concrete
fill 190 216 635 197 216 636 minecraft:black_concrete
setblock 197 216 631 minecraft:black_concrete
fill 198 216 636 201 216 636 minecraft:black_concrete
fill 201 216 631 201 219 631 minecraft:black_concrete
fill 202 216 632 202 219 632 minecraft:black_concrete
fill 202 216 634 202 219 635 minecraft:black_concrete
setblock 189 217 631 minecraft:sea_lantern
fill 189 217 632 189 227 632 minecraft:black_concrete
setblock 189 217 633 minecraft:sea_lantern
fill 189 217 634 189 227 634 minecraft:black_concrete
setblock 189 217 635 minecraft:sea_lantern
fill 189 217 636 189 227 636 minecraft:black_concrete
setblock 189 217 637 minecraft:sea_lantern
fill 189 217 638 189 227 638 minecraft:black_concrete
setblock 189 217 639 minecraft:sea_lantern
fill 189 217 640 189 227 640 minecraft:black_concrete
setblock 189 217 641 minecraft:sea_lantern
fill 190 217 631 190 227 631 minecraft:black_concrete
setblock 190 217 632 minecraft:sea_lantern
fill 190 217 633 190 227 633 minecraft:black_concrete
setblock 190 217 634 minecraft:sea_lantern
fill 190 217 635 190 227 635 minecraft:black_concrete
setblock 190 217 636 minecraft:sea_lantern
fill 190 217 637 190 227 637 minecraft:black_concrete
setblock 190 217 638 minecraft:sea_lantern
fill 190 217 639 190 227 639 minecraft:black_concrete
setblock 190 217 640 minecraft:sea_lantern
fill 190 217 641 190 227 641 minecraft:black_concrete
setblock 191 217 631 minecraft:sea_lantern
fill 191 217 632 191 227 632 minecraft:black_concrete
setblock 191 217 633 minecraft:sea_lantern
fill 191 217 634 191 227 634 minecraft:black_concrete
setblock 191 217 635 minecraft:sea_lantern
fill 191 217 636 191 227 636 minecraft:black_concrete
setblock 191 217 637 minecraft:sea_lantern
fill 191 217 638 191 227 638 minecraft:black_concrete
setblock 191 217 639 minecraft:sea_lantern
fill 191 217 640 191 227 640 minecraft:black_concrete
setblock 191 217 641 minecraft:sea_lantern
fill 192 217 631 192 227 631 minecraft:black_concrete
setblock 192 217 632 minecraft:sea_lantern
fill 192 217 633 192 227 633 minecraft:black_concrete
setblock 192 217 634 minecraft:sea_lantern
fill 192 217 635 192 227 635 minecraft:black_concrete
setblock 192 217 636 minecraft:sea_lantern
fill 192 217 637 192 227 637 minecraft:black_concrete
setblock 192 217 638 minecraft:sea_lantern
fill 192 217 639 192 227 639 minecraft:black_concrete
setblock 192 217 640 minecraft:sea_lantern
fill 192 217 641 192 227 641 minecraft:black_concrete
setblock 193 217 631 minecraft:sea_lantern
fill 193 217 632 193 227 632 minecraft:black_concrete
setblock 193 217 633 minecraft:sea_lantern
fill 193 217 634 193 227 634 minecraft:black_concrete
setblock 193 217 635 minecraft:sea_lantern
fill 193 217 636 193 227 636 minecraft:black_concrete
setblock 193 217 637 minecraft:sea_lantern
fill 193 217 638 193 227 638 minecraft:black_concrete
setblock 193 217 639 minecraft:sea_lantern
fill 193 217 640 193 227 640 minecraft:black_concrete
setblock 193 217 641 minecraft:sea_lantern
fill 194 217 631 194 227 631 minecraft:black_concrete
setblock 194 217 632 minecraft:sea_lantern
fill 194 217 633 194 227 633 minecraft:black_concrete
setblock 194 217 634 minecraft:sea_lantern
fill 194 217 635 194 227 635 minecraft:black_concrete
setblock 194 217 636 minecraft:sea_lantern
fill 194 217 637 194 227 637 minecraft:black_concrete
setblock 194 217 638 minecraft:sea_lantern
fill 194 217 639 194 227 639 minecraft:black_concrete
setblock 194 217 640 minecraft:sea_lantern
fill 194 217 641 194 227 641 minecraft:black_concrete
setblock 195 217 631 minecraft:sea_lantern
fill 195 217 632 195 227 632 minecraft:black_concrete
setblock 195 217 633 minecraft:sea_lantern
fill 195 217 634 195 227 634 minecraft:black_concrete
setblock 195 217 635 minecraft:sea_lantern
fill 195 217 636 195 227 636 minecraft:black_concrete
setblock 195 217 637 minecraft:sea_lantern
fill 195 217 638 195 227 638 minecraft:black_concrete
setblock 195 217 639 minecraft:sea_lantern
fill 195 217 640 195 227 640 minecraft:black_concrete
setblock 195 217 641 minecraft:sea_lantern
fill 196 217 631 196 227 631 minecraft:black_concrete
setblock 196 217 632 minecraft:sea_lantern
fill 196 217 633 196 227 633 minecraft:black_concrete
setblock 196 217 634 minecraft:sea_lantern
fill 196 217 635 196 227 635 minecraft:black_concrete
setblock 196 217 636 minecraft:sea_lantern
fill 196 217 637 196 227 637 minecraft:black_concrete
setblock 196 217 638 minecraft:sea_lantern
fill 196 217 639 196 227 639 minecraft:black_concrete
setblock 196 217 640 minecraft:sea_lantern
fill 196 217 641 196 227 641 minecraft:black_concrete
setblock 197 217 631 minecraft:sea_lantern
fill 197 217 632 197 227 632 minecraft:black_concrete
setblock 197 217 633 minecraft:sea_lantern
fill 197 217 634 197 227 634 minecraft:black_concrete
setblock 197 217 635 minecraft:sea_lantern
fill 197 217 636 197 227 636 minecraft:black_concrete
setblock 197 217 637 minecraft:sea_lantern
fill 197 217 638 197 227 638 minecraft:black_concrete
setblock 197 217 639 minecraft:sea_lantern
fill 197 217 640 197 227 640 minecraft:black_concrete
setblock 197 217 641 minecraft:sea_lantern
fill 198 217 630 200 219 630 minecraft:black_concrete
setblock 198 217 632 minecraft:sea_lantern
fill 198 217 633 198 227 633 minecraft:black_concrete
setblock 198 217 634 minecraft:sea_lantern
setblock 198 217 636 minecraft:sea_lantern
fill 198 217 637 198 227 637 minecraft:black_concrete
setblock 198 217 638 minecraft:sea_lantern
fill 198 217 639 198 227 639 minecraft:black_concrete
setblock 198 217 640 minecraft:sea_lantern
fill 198 217 641 198 227 641 minecraft:black_concrete
fill 199 217 636 201 219 636 minecraft:black_concrete
fill 202 217 631 202 219 631 minecraft:black_concrete
fill 189 218 631 189 219 631 minecraft:black_concrete
fill 189 218 633 189 219 633 minecraft:black_concrete
fill 189 218 635 189 219 635 minecraft:black_concrete
fill 189 218 637 189 219 637 minecraft:black_concrete
fill 189 218 639 189 219 639 minecraft:black_concrete
fill 189 218 641 189 219 641 minecraft:black_concrete
fill 190 218 632 190 219 632 minecraft:black_concrete
fill 190 218 634 190 219 634 minecraft:black_concrete
fill 190 218 636 190 219 636 minecraft:black_concrete
fill 190 218 638 190 219 638 minecraft:black_concrete
fill 190 218 640 190 219 640 minecraft:black_concrete
fill 191 218 631 191 219 631 minecraft:black_concrete
fill 191 218 633 191 219 633 minecraft:black_concrete
fill 191 218 635 191 219 635 minecraft:black_concrete
fill 191 218 637 191 219 637 minecraft:black_concrete
fill 191 218 639 191 219 639 minecraft:black_concrete
fill 191 218 641 191 219 641 minecraft:black_concrete
fill 192 218 632 192 219 632 minecraft:black_concrete
fill 192 218 634 192 219 634 minecraft:black_concrete
fill 192 218 636 192 219 636 minecraft:black_concrete
fill 192 218 638 192 219 638 minecraft:black_concrete
fill 192 218 640 192 219 640 minecraft:black_concrete
fill 193 218 631 193 219 631 minecraft:black_concrete
fill 193 218 633 193 219 633 minecraft:black_concrete
fill 193 218 635 193 219 635 minecraft:black_concrete
fill 193 218 637 193 219 637 minecraft:black_concrete
fill 193 218 639 193 219 639 minecraft:black_concrete
fill 193 218 641 193 219 641 minecraft:black_concrete
fill 194 218 632 194 219 632 minecraft:black_concrete
fill 194 218 634 194 219 634 minecraft:black_concrete
fill 194 218 636 194 219 636 minecraft:black_concrete
fill 194 218 638 194 219 638 minecraft:black_concrete
fill 194 218 640 194 219 640 minecraft:black_concrete
fill 195 218 631 195 219 631 minecraft:black_concrete
fill 195 218 633 195 219 633 minecraft:black_concrete
fill 195 218 635 195 219 635 minecraft:black_concrete
fill 195 218 637 195 219 637 minecraft:black_concrete
fill 195 218 639 195 219 639 minecraft:black_concrete
fill 195 218 641 195 219 641 minecraft:black_concrete
fill 196 218 632 196 219 632 minecraft:black_concrete
fill 196 218 634 196 219 634 minecraft:black_concrete
fill 196 218 636 196 219 636 minecraft:black_concrete
fill 196 218 638 196 219 638 minecraft:black_concrete
fill 196 218 640 196 219 640 minecraft:black_concrete
fill 197 218 630 197 219 631 minecraft:black_concrete
fill 197 218 633 197 219 633 minecraft:black_concrete
fill 197 218 635 197 219 635 minecraft:black_concrete
fill 197 218 637 197 219 637 minecraft:black_concrete
fill 197 218 639 197 219 639 minecraft:black_concrete
fill 197 218 641 197 219 641 minecraft:black_concrete
fill 198 218 632 198 219 632 minecraft:black_concrete
fill 198 218 634 198 219 634 minecraft:black_concrete
fill 198 218 636 198 219 636 minecraft:black_concrete
fill 198 218 638 198 219 638 minecraft:black_concrete
fill 198 218 640 198 219 640 minecraft:black_concrete
fill 199 218 637 201 219 637 minecraft:black_concrete
fill 201 218 630 201 219 630 minecraft:black_concrete
fill 202 218 636 202 219 636 minecraft:black_concrete
fill 203 218 632 203 219 635 minecraft:black_concrete
fill 198 219 629 201 219 629 minecraft:black_concrete
setblock 202 219 630 minecraft:black_concrete
setblock 202 219 637 minecraft:black_concrete
setblock 203 219 631 minecraft:black_concrete
setblock 203 219 636 minecraft:black_concrete
fill 212 219 614 212 220 615 minecraft:yellow_concrete
fill 188 220 609 188 229 609 minecraft:magenta_concrete
fill 188 220 617 188 230 617 minecraft:magenta_concrete
fill 188 220 625 188 228 625 minecraft:magenta_concrete
fill 188 220 633 188 230 633 minecraft:magenta_concrete
fill 188 220 641 188 232 641 minecraft:magenta_concrete
setblock 189 220 631 minecraft:sea_lantern
setblock 189 220 633 minecraft:sea_lantern
setblock 189 220 635 minecraft:sea_lantern
setblock 189 220 637 minecraft:sea_lantern
setblock 189 220 639 minecraft:sea_lantern
setblock 189 220 641 minecraft:sea_lantern
setblock 190 220 632 minecraft:sea_lantern
setblock 190 220 634 minecraft:sea_lantern
setblock 190 220 636 minecraft:sea_lantern
setblock 190 220 638 minecraft:sea_lantern
setblock 190 220 640 minecraft:sea_lantern
setblock 191 220 631 minecraft:sea_lantern
setblock 191 220 633 minecraft:sea_lantern
setblock 191 220 635 minecraft:sea_lantern
setblock 191 220 637 minecraft:sea_lantern
setblock 191 220 639 minecraft:sea_lantern
setblock 191 220 641 minecraft:sea_lantern
fill 191 220 646 191 232 646 minecraft:magenta_concrete
setblock 192 220 632 minecraft:sea_lantern
setblock 192 220 634 minecraft:sea_lantern
setblock 192 220 636 minecraft:sea_lantern
setblock 192 220 638 minecraft:sea_lantern
setblock 192 220 640 minecraft:sea_lantern
setblock 193 220 631 minecraft:sea_lantern
setblock 193 220 633 minecraft:sea_lantern
setblock 193 220 635 minecraft:sea_lantern
setblock 193 220 637 minecraft:sea_lantern
setblock 193 220 639 minecraft:sea_lantern
setblock 193 220 641 minecraft:sea_lantern
setblock 194 220 632 minecraft:sea_lantern
setblock 194 220 634 minecraft:sea_lantern
setblock 194 220 636 minecraft:sea_lantern
setblock 194 220 638 minecraft:sea_lantern
setblock 194 220 640 minecraft:sea_lantern
fill 195 220 604 195 232 604 minecraft:magenta_concrete
setblock 195 220 631 minecraft:sea_lantern
setblock 195 220 633 minecraft:sea_lantern
setblock 195 220 635 minecraft:sea_lantern
setblock 195 220 637 minecraft:sea_lantern
setblock 195 220 639 minecraft:sea_lantern
setblock 195 220 641 minecraft:sea_lantern
setblock 196 220 632 minecraft:sea_lantern
setblock 196 220 634 minecraft:sea_lantern
setblock 196 220 636 minecraft:sea_lantern
setblock 196 220 638 minecraft:sea_lantern
setblock 196 220 640 minecraft:sea_lantern
setblock 197 220 631 minecraft:sea_lantern
setblock 197 220 633 minecraft:sea_lantern
setblock 197 220 635 minecraft:sea_lantern
setblock 197 220 637 minecraft:sea_lantern
setblock 197 220 639 minecraft:sea_lantern
setblock 197 220 641 minecraft:sea_lantern
fill 198 220 624 199 221 625 minecraft:magenta_concrete
fill 198 220 631 198 227 631 minecraft:black_concrete
setblock 198 220 632 minecraft:sea_lantern
setblock 198 220 634 minecraft:sea_lantern
setblock 198 220 636 minecraft:sea_lantern
setblock 198 220 638 minecraft:sea_lantern
setblock 198 220 640 minecraft:sea_lantern
fill 199 220 633 200 221 634 minecraft:white_stained_glass
fill 199 220 646 199 232 646 minecraft:magenta_concrete
fill 203 220 604 203 232 604 minecraft:magenta_concrete
fill 207 220 646 207 232 646 minecraft:magenta_concrete
fill 211 220 604 211 232 604 minecraft:magenta_concrete
fill 215 220 646 215 233 646 minecraft:magenta_concrete
fill 219 220 604 219 232 604 minecraft:magenta_concrete
fill 223 220 646 223 232 646 minecraft:magenta_concrete
fill 227 220 604 227 230 604 minecraft:magenta_concrete
fill 230 220 609 230 229 609 minecraft:magenta_concrete
fill 230 220 617 230 229 617 minecraft:magenta_concrete
fill 230 220 625 230 229 625 minecraft:magenta_concrete
fill 230 220 633 230 232 633 minecraft:magenta_concrete
fill 230 220 641 230 232 641 minecraft:magenta_concrete
fill 189 221 631 189 222 631 minecraft:black_concrete
fill 189 221 633 189 222 633 minecraft:black_concrete
fill 189 221 635 189 222 635 minecraft:black_concrete
fill 189 221 637 189 222 637 minecraft:black_concrete
fill 189 221 639 189 222 639 minecraft:black_concrete
fill 189 221 641 189 222 641 minecraft:black_concrete
fill 190 221 632 190 222 632 minecraft:black_concrete
fill 190 221 634 190 222 634 minecraft:black_concrete
fill 190 221 636 190 222 636 minecraft:black_concrete
fill 190 221 638 190 222 638 minecraft:black_concrete
fill 190 221 640 190 222 640 minecraft:black_concrete
fill 191 221 631 191 222 631 minecraft:black_concrete
fill 191 221 633 191 222 633 minecraft:black_concrete
fill 191 221 635 191 222 635 minecraft:black_concrete
fill 191 221 637 191 222 637 minecraft:black_concrete
fill 191 221 639 191 222 639 minecraft:black_concrete
fill 191 221 641 191 222 641 minecraft:black_concrete
fill 192 221 632 192 222 632 minecraft:black_concrete
fill 192 221 634 192 222 634 minecraft:black_concrete
fill 192 221 636 192 222 636 minecraft:black_concrete
fill 192 221 638 192 222 638 minecraft:black_concrete
fill 192 221 640 192 222 640 minecraft:black_concrete
fill 193 221 631 193 222 631 minecraft:black_concrete
fill 193 221 633 193 222 633 minecraft:black_concrete
fill 193 221 635 193 222 635 minecraft:black_concrete
fill 193 221 637 193 222 637 minecraft:black_concrete
fill 193 221 639 193 222 639 minecraft:black_concrete
fill 193 221 641 193 222 641 minecraft:black_concrete
fill 194 221 632 194 222 632 minecraft:black_concrete
fill 194 221 634 194 222 634 minecraft:black_concrete
fill 194 221 636 194 222 636 minecraft:black_concrete
fill 194 221 638 194 222 638 minecraft:black_concrete
fill 194 221 640 194 222 640 minecraft:black_concrete
fill 195 221 631 195 222 631 minecraft:black_concrete
fill 195 221 633 195 222 633 minecraft:black_concrete
fill 195 221 635 195 222 635 minecraft:black_concrete
fill 195 221 637 195 222 637 minecraft:black_concrete
fill 195 221 639 195 222 639 minecraft:black_concrete
fill 195 221 641 195 222 641 minecraft:black_concrete
fill 196 221 632 196 222 632 minecraft:black_concrete
fill 196 221 634 196 222 634 minecraft:black_concrete
fill 196 221 636 196 222 636 minecraft:black_concrete
fill 196 221 638 196 222 638 minecraft:black_concrete
fill 196 221 640 196 222 640 minecraft:black_concrete
fill 197 221 631 197 222 631 minecraft:black_concrete
fill 197 221 633 197 222 633 minecraft:black_concrete
fill 197 221 635 197 222 635 minecraft:black_concrete
fill 197 221 637 197 222 637 minecraft:black_concrete
fill 197 221 639 197 222 639 minecraft:black_concrete
fill 197 221 641 197 222 641 minecraft:black_concrete
fill 198 221 632 198 222 632 minecraft:black_concrete
fill 198 221 634 198 222 634 minecraft:black_concrete
fill 198 221 636 198 222 636 minecraft:black_concrete
fill 198 221 638 198 222 638 minecraft:black_concrete
fill 198 221 640 198 222 640 minecraft:black_concrete
fill 199 222 633 199 222 634 minecraft:white_stained_glass
setblock 200 222 633 minecraft:white_stained_glass
setblock 189 223 631 minecraft:sea_lantern
setblock 189 223 633 minecraft:sea_lantern
setblock 189 223 635 minecraft:sea_lantern
setblock 189 223 637 minecraft:sea_lantern
setblock 189 223 639 minecraft:sea_lantern
setblock 189 223 641 minecraft:sea_lantern
setblock 190 223 632 minecraft:sea_lantern
setblock 190 223 634 minecraft:sea_lantern
setblock 190 223 636 minecraft:sea_lantern
setblock 190 223 638 minecraft:sea_lantern
setblock 190 223 640 minecraft:sea_lantern
setblock 191 223 607 minecraft:light[level=14]
setblock 191 223 615 minecraft:light[level=14]
setblock 191 223 623 minecraft:light[level=14]
setblock 191 223 631 minecraft:sea_lantern
setblock 191 223 633 minecraft:sea_lantern
setblock 191 223 635 minecraft:sea_lantern
setblock 191 223 637 minecraft:sea_lantern
setblock 191 223 639 minecraft:sea_lantern
setblock 191 223 641 minecraft:sea_lantern
setblock 192 223 632 minecraft:sea_lantern
setblock 192 223 634 minecraft:sea_lantern
setblock 192 223 636 minecraft:sea_lantern
setblock 192 223 638 minecraft:sea_lantern
setblock 192 223 640 minecraft:sea_lantern
setblock 193 223 631 minecraft:sea_lantern
setblock 193 223 633 minecraft:sea_lantern
setblock 193 223 635 minecraft:sea_lantern
setblock 193 223 637 minecraft:sea_lantern
setblock 193 223 639 minecraft:sea_lantern
setblock 193 223 641 minecraft:sea_lantern
setblock 194 223 632 minecraft:sea_lantern
setblock 194 223 634 minecraft:sea_lantern
setblock 194 223 636 minecraft:sea_lantern
setblock 194 223 638 minecraft:sea_lantern
setblock 194 223 640 minecraft:sea_lantern
setblock 195 223 631 minecraft:sea_lantern
setblock 195 223 633 minecraft:sea_lantern
setblock 195 223 635 minecraft:sea_lantern
setblock 195 223 637 minecraft:sea_lantern
setblock 195 223 639 minecraft:sea_lantern
setblock 195 223 641 minecraft:sea_lantern
setblock 196 223 632 minecraft:sea_lantern
setblock 196 223 634 minecraft:sea_lantern
setblock 196 223 636 minecraft:sea_lantern
setblock 196 223 638 minecraft:sea_lantern
setblock 196 223 640 minecraft:sea_lantern
setblock 197 223 631 minecraft:sea_lantern
setblock 197 223 633 minecraft:sea_lantern
setblock 197 223 635 minecraft:sea_lantern
setblock 197 223 637 minecraft:sea_lantern
setblock 197 223 639 minecraft:sea_lantern
setblock 197 223 641 minecraft:sea_lantern
setblock 198 223 632 minecraft:sea_lantern
setblock 198 223 634 minecraft:sea_lantern
setblock 198 223 636 minecraft:sea_lantern
setblock 198 223 638 minecraft:sea_lantern
setblock 198 223 640 minecraft:sea_lantern
setblock 199 223 607 minecraft:light[level=14]
setblock 199 223 615 minecraft:light[level=14]
setblock 199 223 623 minecraft:light[level=14]
setblock 199 223 631 minecraft:light[level=14]
setblock 199 223 633 minecraft:white_stained_glass
setblock 199 223 639 minecraft:light[level=14]
setblock 207 223 607 minecraft:light[level=14]
setblock 207 223 615 minecraft:light[level=14]
setblock 207 223 623 minecraft:light[level=14]
setblock 207 223 631 minecraft:light[level=14]
setblock 207 223 639 minecraft:light[level=14]
setblock 215 223 607 minecraft:light[level=14]
setblock 215 223 615 minecraft:light[level=14]
setblock 215 223 623 minecraft:light[level=14]
setblock 215 223 631 minecraft:light[level=14]
setblock 215 223 639 minecraft:light[level=14]
setblock 223 223 607 minecraft:light[level=14]
setblock 223 223 615 minecraft:light[level=14]
setblock 223 223 623 minecraft:light[level=14]
setblock 223 223 631 minecraft:light[level=14]
setblock 223 223 639 minecraft:light[level=14]
fill 189 224 605 189 225 610 minecraft:black_concrete
fill 189 224 613 190 224 618 minecraft:black_concrete
fill 189 224 621 190 224 626 minecraft:black_concrete
fill 189 224 629 189 225 631 minecraft:black_concrete
fill 189 224 633 189 225 633 minecraft:black_concrete
fill 189 224 635 189 225 635 minecraft:black_concrete
fill 189 224 637 189 225 637 minecraft:black_concrete
fill 189 224 639 189 225 639 minecraft:black_concrete
fill 189 224 641 189 225 642 minecraft:black_concrete
fill 189 224 645 194 225 645 minecraft:black_concrete
fill 190 224 606 190 224 612 minecraft:black_concrete
fill 190 224 619 190 224 620 minecraft:black_concrete
fill 190 224 627 190 224 630 minecraft:black_concrete
fill 190 224 632 190 225 632 minecraft:black_concrete
fill 190 224 634 190 225 634 minecraft:black_concrete
fill 190 224 636 190 225 636 minecraft:black_concrete
fill 190 224 638 190 225 638 minecraft:black_concrete
fill 190 224 640 190 225 640 minecraft:black_concrete
fill 190 224 642 190 224 644 minecraft:black_concrete
fill 191 224 606 228 224 606 minecraft:black_concrete
fill 191 224 631 191 225 631 minecraft:black_concrete
fill 191 224 633 191 225 633 minecraft:black_concrete
fill 191 224 635 191 225 635 minecraft:black_concrete
fill 191 224 637 191 225 637 minecraft:black_concrete
fill 191 224 639 191 225 639 minecraft:black_concrete
fill 191 224 641 191 225 641 minecraft:black_concrete
fill 191 224 644 229 224 644 minecraft:black_concrete
fill 192 224 605 197 225 605 minecraft:black_concrete
fill 192 224 632 192 225 632 minecraft:black_concrete
fill 192 224 634 192 225 634 minecraft:black_concrete
fill 192 224 636 192 225 636 minecraft:black_concrete
fill 192 224 638 192 225 638 minecraft:black_concrete
fill 192 224 640 192 225 640 minecraft:black_concrete
fill 193 224 631 193 225 631 minecraft:black_concrete
fill 193 224 633 193 225 633 minecraft:black_concrete
fill 193 224 635 193 225 635 minecraft:black_concrete
fill 193 224 637 193 225 637 minecraft:black_concrete
fill 193 224 639 193 225 639 minecraft:black_concrete
fill 193 224 641 193 225 641 minecraft:black_concrete
fill 194 224 632 194 225 632 minecraft:black_concrete
fill 194 224 634 194 225 634 minecraft:black_concrete
fill 194 224 636 194 225 636 minecraft:black_concrete
fill 194 224 638 194 225 638 minecraft:black_concrete
fill 194 224 640 194 225 640 minecraft:black_concrete
fill 195 224 631 195 225 631 minecraft:black_concrete
fill 195 224 633 195 225 633 minecraft:black_concrete
fill 195 224 635 195 225 635 minecraft:black_concrete
fill 195 224 637 195 225 637 minecraft:black_concrete
fill 195 224 639 195 225 639 minecraft:black_concrete
fill 195 224 641 195 225 641 minecraft:black_concrete
fill 196 224 632 196 225 632 minecraft:black_concrete
fill 196 224 634 196 225 634 minecraft:black_concrete
fill 196 224 636 196 225 636 minecraft:black_concrete
fill 196 224 638 196 225 638 minecraft:black_concrete
fill 196 224 640 196 225 640 minecraft:black_concrete
fill 197 224 631 197 225 631 minecraft:black_concrete
fill 197 224 633 197 225 633 minecraft:black_concrete
fill 197 224 635 197 225 635 minecraft:black_concrete
fill 197 224 637 197 225 637 minecraft:black_concrete
fill 197 224 639 197 225 639 minecraft:black_concrete
fill 197 224 641 197 225 641 minecraft:black_concrete
fill 197 224 645 202 225 645 minecraft:black_concrete
fill 198 224 632 198 225 632 minecraft:black_concrete
fill 198 224 634 198 225 634 minecraft:black_concrete
fill 198 224 636 198 225 636 minecraft:black_concrete
fill 198 224 638 198 225 638 minecraft:black_concrete
fill 198 224 640 198 225 640 minecraft:black_concrete
fill 200 224 605 205 225 605 minecraft:black_concrete
fill 205 224 645 210 225 645 minecraft:black_concrete
fill 208 224 605 213 225 605 minecraft:black_concrete
fill 213 224 645 218 225 645 minecraft:black_concrete
fill 216 224 605 221 225 605 minecraft:black_concrete
fill 221 224 645 226 225 645 minecraft:black_concrete
fill 224 224 605 229 225 605 minecraft:black_concrete
fill 228 224 607 228 224 643 minecraft:black_concrete
fill 229 224 608 229 225 613 minecraft:black_concrete
fill 229 224 616 229 225 621 minecraft:black_concrete
fill 229 224 624 229 225 629 minecraft:black_concrete
fill 229 224 632 229 225 637 minecraft:black_concrete
fill 229 224 640 229 225 643 minecraft:black_concrete
fill 229 224 645 229 225 645 minecraft:black_concrete
fill 189 225 613 189 225 618 minecraft:black_concrete
fill 189 225 621 189 225 626 minecraft:black_concrete
setblock 229 225 644 minecraft:black_concrete
setblock 189 226 631 minecraft:sea_lantern
setblock 189 226 633 minecraft:sea_lantern
setblock 189 226 635 minecraft:sea_lantern
setblock 189 226 637 minecraft:sea_lantern
setblock 189 226 639 minecraft:sea_lantern
setblock 189 226 641 minecraft:sea_lantern
setblock 190 226 632 minecraft:sea_lantern
setblock 190 226 634 minecraft:sea_lantern
setblock 190 226 636 minecraft:sea_lantern
setblock 190 226 638 minecraft:sea_lantern
setblock 190 226 640 minecraft:sea_lantern
setblock 191 226 631 minecraft:sea_lantern
setblock 191 226 633 minecraft:sea_lantern
setblock 191 226 635 minecraft:sea_lantern
setblock 191 226 637 minecraft:sea_lantern
setblock 191 226 639 minecraft:sea_lantern
setblock 191 226 641 minecraft:sea_lantern
setblock 192 226 632 minecraft:sea_lantern
setblock 192 226 634 minecraft:sea_lantern
setblock 192 226 636 minecraft:sea_lantern
setblock 192 226 638 minecraft:sea_lantern
setblock 192 226 640 minecraft:sea_lantern
setblock 193 226 631 minecraft:sea_lantern
setblock 193 226 633 minecraft:sea_lantern
setblock 193 226 635 minecraft:sea_lantern
setblock 193 226 637 minecraft:sea_lantern
setblock 193 226 639 minecraft:sea_lantern
setblock 193 226 641 minecraft:sea_lantern
setblock 194 226 632 minecraft:sea_lantern
setblock 194 226 634 minecraft:sea_lantern
setblock 194 226 636 minecraft:sea_lantern
setblock 194 226 638 minecraft:sea_lantern
setblock 194 226 640 minecraft:sea_lantern
setblock 195 226 631 minecraft:sea_lantern
setblock 195 226 633 minecraft:sea_lantern
setblock 195 226 635 minecraft:sea_lantern
setblock 195 226 637 minecraft:sea_lantern
setblock 195 226 639 minecraft:sea_lantern
setblock 195 226 641 minecraft:sea_lantern
setblock 196 226 632 minecraft:sea_lantern
setblock 196 226 634 minecraft:sea_lantern
setblock 196 226 636 minecraft:sea_lantern
setblock 196 226 638 minecraft:sea_lantern
setblock 196 226 640 minecraft:sea_lantern
setblock 197 226 631 minecraft:sea_lantern
setblock 197 226 633 minecraft:sea_lantern
setblock 197 226 635 minecraft:sea_lantern
setblock 197 226 637 minecraft:sea_lantern
setblock 197 226 639 minecraft:sea_lantern
setblock 197 226 641 minecraft:sea_lantern
setblock 198 226 632 minecraft:sea_lantern
setblock 198 226 634 minecraft:sea_lantern
setblock 198 226 636 minecraft:sea_lantern
setblock 198 226 638 minecraft:sea_lantern
setblock 198 226 640 minecraft:sea_lantern
setblock 189 227 631 minecraft:black_concrete
setblock 189 227 633 minecraft:black_concrete
setblock 189 227 635 minecraft:black_concrete
setblock 189 227 637 minecraft:black_concrete
setblock 189 227 639 minecraft:black_concrete
setblock 189 227 641 minecraft:black_concrete
setblock 190 227 632 minecraft:black_concrete
setblock 190 227 634 minecraft:black_concrete
setblock 190 227 636 minecraft:black_concrete
setblock 190 227 638 minecraft:black_concrete
setblock 190 227 640 minecraft:black_concrete
setblock 191 227 631 minecraft:black_concrete
setblock 191 227 633 minecraft:black_concrete
setblock 191 227 635 minecraft:black_concrete
setblock 191 227 637 minecraft:black_concrete
setblock 191 227 639 minecraft:black_concrete
setblock 191 227 641 minecraft:black_concrete
setblock 192 227 632 minecraft:black_concrete
setblock 192 227 634 minecraft:black_concrete
setblock 192 227 636 minecraft:black_concrete
setblock 192 227 638 minecraft:black_concrete
setblock 192 227 640 minecraft:black_concrete
setblock 193 227 631 minecraft:black_concrete
setblock 193 227 633 minecraft:black_concrete
setblock 193 227 635 minecraft:black_concrete
setblock 193 227 637 minecraft:black_concrete
setblock 193 227 639 minecraft:black_concrete
setblock 193 227 641 minecraft:black_concrete
setblock 194 227 632 minecraft:black_concrete
setblock 194 227 634 minecraft:black_concrete
setblock 194 227 636 minecraft:black_concrete
setblock 194 227 638 minecraft:black_concrete
setblock 194 227 640 minecraft:black_concrete
setblock 195 227 631 minecraft:black_concrete
setblock 195 227 633 minecraft:black_concrete
setblock 195 227 635 minecraft:black_concrete
setblock 195 227 637 minecraft:black_concrete
setblock 195 227 639 minecraft:black_concrete
setblock 195 227 641 minecraft:black_concrete
setblock 196 227 632 minecraft:black_concrete
setblock 196 227 634 minecraft:black_concrete
setblock 196 227 636 minecraft:black_concrete
setblock 196 227 638 minecraft:black_concrete
setblock 196 227 640 minecraft:black_concrete
setblock 197 227 631 minecraft:black_concrete
setblock 197 227 633 minecraft:black_concrete
setblock 197 227 635 minecraft:black_concrete
setblock 197 227 637 minecraft:black_concrete
setblock 197 227 639 minecraft:black_concrete
setblock 197 227 641 minecraft:black_concrete
setblock 198 227 632 minecraft:black_concrete
setblock 198 227 634 minecraft:black_concrete
setblock 198 227 636 minecraft:black_concrete
setblock 198 227 638 minecraft:black_concrete
setblock 198 227 640 minecraft:black_concrete
fill 188 229 604 188 233 604 minecraft:magenta_concrete
setblock 188 229 605 minecraft:lime_concrete
fill 188 229 606 188 232 608 minecraft:magenta_concrete
fill 188 229 619 188 232 620 minecraft:magenta_concrete
setblock 188 229 621 minecraft:lime_concrete
fill 188 229 622 188 232 624 minecraft:magenta_concrete
setblock 188 229 625 minecraft:lime_concrete
setblock 194 229 646 minecraft:lime_concrete
fill 204 229 646 204 232 646 minecraft:magenta_concrete
setblock 205 229 646 minecraft:lime_concrete
fill 206 229 646 206 232 646 minecraft:magenta_concrete
fill 208 229 604 208 232 604 minecraft:magenta_concrete
fill 209 229 604 209 230 604 minecraft:lime_concrete
fill 210 229 604 210 232 604 minecraft:magenta_concrete
setblock 230 229 610 minecraft:lime_concrete
setblock 230 229 618 minecraft:lime_concrete
fill 230 229 626 230 230 627 minecraft:magenta_concrete
setblock 230 229 628 minecraft:lime_concrete
fill 230 229 629 230 232 629 minecraft:magenta_concrete
setblock 230 229 630 minecraft:lime_concrete
fill 230 229 645 230 232 645 minecraft:magenta_concrete
setblock 230 229 646 minecraft:lime_concrete
fill 188 230 605 188 233 605 minecraft:magenta_concrete
setblock 188 230 609 minecraft:lime_concrete
setblock 188 230 615 minecraft:magenta_concrete
setblock 188 230 616 minecraft:lime_concrete
fill 188 230 621 188 232 621 minecraft:magenta_concrete
fill 188 230 625 188 232 625 minecraft:magenta_concrete
fill 188 230 634 188 232 634 minecraft:magenta_concrete
setblock 188 230 635 minecraft:lime_concrete
fill 188 230 636 188 232 640 minecraft:magenta_concrete
fill 188 230 646 188 231 646 minecraft:lime_concrete
setblock 189 230 604 minecraft:lime_concrete
fill 190 230 604 193 232 604 minecraft:magenta_concrete
setblock 194 230 604 minecraft:lime_concrete
fill 194 230 646 194 232 646 minecraft:magenta_concrete
fill 197 230 604 201 232 604 minecraft:magenta_concrete
fill 200 230 646 201 232 646 minecraft:magenta_concrete
setblock 202 230 604 minecraft:lime_concrete
setblock 202 230 646 minecraft:lime_concrete
fill 205 230 646 205 232 646 minecraft:magenta_concrete
fill 212 230 604 213 230 604 minecraft:lime_concrete
fill 214 230 604 215 232 604 minecraft:magenta_concrete
setblock 222 230 646 minecraft:lime_concrete
setblock 223 230 604 minecraft:lime_concrete
fill 224 230 646 225 232 646 minecraft:magenta_concrete
fill 226 230 646 226 231 646 minecraft:lime_concrete
fill 227 230 646 230 230 646 minecraft:magenta_concrete
setblock 230 230 604 minecraft:lime_concrete
fill 230 230 605 230 232 607 minecraft:magenta_concrete
fill 230 230 608 230 230 609 minecraft:lime_concrete
fill 230 230 610 230 232 610 minecraft:magenta_concrete
setblock 230 230 611 minecraft:lime_concrete
fill 230 230 612 230 232 614 minecraft:magenta_concrete
setblock 230 230 615 minecraft:lime_concrete
setblock 230 230 617 minecraft:lime_concrete
setblock 230 230 618 minecraft:magenta_concrete
setblock 230 230 625 minecraft:lime_concrete
fill 230 230 628 230 232 628 minecraft:magenta_concrete
fill 230 230 630 230 234 630 minecraft:magenta_concrete
setblock 230 230 631 minecraft:lime_concrete
fill 230 230 634 230 232 636 minecraft:magenta_concrete
setblock 230 230 637 minecraft:lime_concrete
fill 230 230 638 230 232 639 minecraft:magenta_concrete
fill 188 231 609 188 232 609 minecraft:magenta_concrete
fill 188 231 613 188 233 613 minecraft:magenta_concrete
fill 188 231 614 188 231 615 minecraft:lime_concrete
fill 188 231 616 188 232 616 minecraft:magenta_concrete
setblock 188 231 617 minecraft:lime_concrete
fill 188 231 629 188 232 631 minecraft:magenta_concrete
fill 188 231 632 188 231 633 minecraft:lime_concrete
fill 188 231 635 188 232 635 minecraft:magenta_concrete
fill 189 231 604 189 232 604 minecraft:magenta_concrete
setblock 191 231 607 minecraft:light[level=14]
setblock 191 231 615 minecraft:light[level=14]
setblock 191 231 623 minecraft:light[level=14]
setblock 191 231 631 minecraft:light[level=14]
setblock 191 231 639 minecraft:light[level=14]
fill 194 231 604 194 232 604 minecraft:magenta_concrete
setblock 199 231 607 minecraft:light[level=14]
setblock 199 231 615 minecraft:light[level=14]
setblock 199 231 623 minecraft:light[level=14]
setblock 199 231 631 minecraft:light[level=14]
setblock 199 231 639 minecraft:light[level=14]
fill 202 231 604 202 234 604 minecraft:magenta_concrete
fill 202 231 646 202 233 646 minecraft:magenta_concrete
setblock 207 231 607 minecraft:light[level=14]
setblock 207 231 615 minecraft:light[level=14]
setblock 207 231 623 minecraft:light[level=14]
setblock 207 231 631 minecraft:light[level=14]
setblock 207 231 639 minecraft:light[level=14]
fill 209 231 604 209 233 604 minecraft:magenta_concrete
fill 212 231 604 213 232 604 minecraft:magenta_concrete
setblock 215 231 607 minecraft:light[level=14]
setblock 215 231 615 minecraft:light[level=14]
setblock 215 231 623 minecraft:light[level=14]
setblock 215 231 631 minecraft:light[level=14]
setblock 215 231 639 minecraft:light[level=14]
setblock 218 231 604 minecraft:lime_concrete
fill 222 231 646 222 232 646 minecraft:magenta_concrete
fill 223 231 604 223 232 604 minecraft:magenta_concrete
setblock 223 231 607 minecraft:light[level=14]
setblock 223 231 615 minecraft:light[level=14]
setblock 223 231 623 minecraft:light[level=14]
setblock 223 231 631 minecraft:light[level=14]
setblock 223 231 639 minecraft:light[level=14]
setblock 224 231 604 minecraft:lime_concrete
fill 225 231 604 226 232 604 minecraft:magenta_concrete
setblock 227 231 604 minecraft:lime_concrete
fill 227 231 646 227 232 646 minecraft:magenta_concrete
setblock 228 231 646 minecraft:lime_concrete
fill 229 231 646 230 232 646 minecraft:magenta_concrete
fill 230 231 604 230 232 604 minecraft:magenta_concrete
fill 230 231 608 230 232 609 minecraft:magenta_concrete
fill 230 231 611 230 232 611 minecraft:magenta_concrete
fill 230 231 615 230 233 615 minecraft:magenta_concrete
fill 230 231 617 230 232 617 minecraft:magenta_concrete
setblock 230 231 618 minecraft:lime_concrete
fill 230 231 625 230 233 625 minecraft:magenta_concrete
setblock 230 231 626 minecraft:lime_concrete
fill 230 231 627 230 232 627 minecraft:magenta_concrete
fill 230 231 631 230 232 631 minecraft:magenta_concrete
fill 230 231 637 230 232 637 minecraft:magenta_concrete
setblock 230 231 640 minecraft:lime_concrete
setblock 230 231 642 minecraft:lime_concrete
fill 188 232 614 188 232 615 minecraft:magenta_concrete
setblock 188 232 617 minecraft:magenta_concrete
fill 188 232 632 188 232 633 minecraft:magenta_concrete
setblock 188 232 646 minecraft:magenta_concrete
fill 204 232 628 206 232 630 minecraft:redstone_block
fill 212 232 631 214 232 633 minecraft:redstone_block
fill 213 232 624 215 232 626 minecraft:redstone_block
fill 218 232 604 218 233 604 minecraft:magenta_concrete
setblock 224 232 604 minecraft:magenta_concrete
setblock 226 232 646 minecraft:magenta_concrete
fill 227 232 604 227 233 604 minecraft:magenta_concrete
setblock 228 232 646 minecraft:magenta_concrete
setblock 230 232 618 minecraft:magenta_concrete
setblock 230 232 626 minecraft:magenta_concrete
setblock 230 232 640 minecraft:magenta_concrete
setblock 230 232 642 minecraft:magenta_concrete
fill 188 233 606 188 233 612 minecraft:lime_concrete
fill 188 233 614 188 234 617 minecraft:lime_concrete
fill 188 233 619 188 234 621 minecraft:lime_concrete
fill 188 233 622 230 233 622 minecraft:magenta_concrete
fill 188 233 623 188 234 627 minecraft:lime_concrete
fill 188 233 628 203 233 628 minecraft:magenta_concrete
fill 188 233 629 188 233 641 minecraft:lime_concrete
fill 188 233 643 188 234 646 minecraft:lime_concrete
fill 189 233 604 191 307 604 minecraft:lime_concrete
fill 189 233 605 229 233 621 minecraft:magenta_concrete
fill 189 233 623 208 233 627 minecraft:magenta_concrete
fill 189 233 629 203 233 645 minecraft:magenta_concrete
fill 190 233 646 196 233 646 minecraft:lime_concrete
setblock 192 233 604 minecraft:magenta_concrete
fill 193 233 604 196 233 604 minecraft:lime_concrete
setblock 197 233 604 minecraft:magenta_concrete
fill 197 233 646 197 234 646 minecraft:magenta_concrete
fill 198 233 604 201 233 604 minecraft:lime_concrete
fill 198 233 646 201 233 646 minecraft:lime_concrete
fill 203 233 604 208 233 604 minecraft:lime_concrete
fill 203 233 646 214 234 646 minecraft:lime_concrete
fill 204 233 631 211 233 645 minecraft:magenta_concrete
fill 207 233 628 208 233 630 minecraft:magenta_concrete
fill 209 233 623 212 233 626 minecraft:magenta_concrete
fill 209 233 630 229 233 630 minecraft:magenta_concrete
fill 210 233 604 217 234 604 minecraft:lime_concrete
fill 212 233 627 229 233 629 minecraft:magenta_concrete
fill 212 233 634 229 233 645 minecraft:magenta_concrete
fill 213 233 623 229 233 623 minecraft:magenta_concrete
fill 215 233 631 229 233 633 minecraft:magenta_concrete
fill 216 233 624 229 233 626 minecraft:magenta_concrete
fill 216 233 646 230 233 646 minecraft:lime_concrete
fill 219 233 604 226 233 604 minecraft:lime_concrete
fill 228 233 604 230 307 604 minecraft:lime_concrete
fill 230 233 605 230 233 614 minecraft:lime_concrete
fill 230 233 616 230 241 621 minecraft:lime_concrete
fill 230 233 623 230 307 624 minecraft:lime_concrete
fill 230 233 626 230 234 629 minecraft:lime_concrete
fill 230 233 631 230 234 631 minecraft:lime_concrete
fill 230 233 633 230 233 645 minecraft:lime_concrete
fill 188 234 604 188 307 607 minecraft:lime_concrete
fill 188 234 608 229 234 608 minecraft:magenta_concrete
fill 188 234 609 188 241 613 minecraft:lime_concrete
fill 188 234 618 188 307 618 minecraft:lime_concrete
fill 188 234 622 188 235 622 minecraft:magenta_concrete
fill 188 234 628 188 307 628 minecraft:lime_concrete
setblock 188 234 629 minecraft:magenta_concrete
fill 188 234 630 188 307 631 minecraft:lime_concrete
fill 188 234 632 210 234 632 minecraft:magenta_concrete
fill 188 234 633 188 241 633 minecraft:lime_concrete
setblock 188 234 634 minecraft:magenta_concrete
fill 188 234 635 188 234 642 minecraft:lime_concrete
fill 189 234 605 189 234 607 minecraft:black_concrete
fill 189 234 609 229 234 609 minecraft:magenta_concrete
fill 189 234 610 189 234 613 minecraft:black_concrete
fill 189 234 614 229 234 615 minecraft:magenta_concrete
fill 189 234 616 189 234 619 minecraft:black_concrete
fill 189 234 620 229 234 621 minecraft:magenta_concrete
fill 189 234 622 189 234 625 minecraft:black_concrete
fill 189 234 626 202 234 627 minecraft:magenta_concrete
fill 189 234 628 189 234 631 minecraft:black_concrete
fill 189 234 633 210 234 633 minecraft:magenta_concrete
fill 189 234 634 189 234 637 minecraft:black_concrete
fill 189 234 638 229 234 639 minecraft:magenta_concrete
fill 189 234 640 189 234 643 minecraft:black_concrete
fill 189 234 644 229 234 645 minecraft:magenta_concrete
fill 189 234 646 189 307 646 minecraft:lime_concrete
fill 190 234 605 191 234 606 minecraft:magenta_concrete
fill 190 234 607 229 234 607 minecraft:black_concrete
fill 190 234 610 229 234 610 minecraft:black_concrete
fill 190 234 611 191 234 612 minecraft:magenta_concrete
fill 190 234 613 229 234 613 minecraft:black_concrete
fill 190 234 616 229 234 616 minecraft:black_concrete
fill 190 234 617 191 234 618 minecraft:magenta_concrete
fill 190 234 619 229 234 619 minecraft:black_concrete
fill 190 234 622 229 234 622 minecraft:black_concrete
fill 190 234 623 191 234 624 minecraft:magenta_concrete
fill 190 234 625 211 234 625 minecraft:black_concrete
fill 190 234 628 202 234 628 minecraft:black_concrete
fill 190 234 629 191 234 630 minecraft:magenta_concrete
fill 190 234 631 202 234 631 minecraft:black_concrete
fill 190 234 634 210 234 634 minecraft:black_concrete
fill 190 234 635 191 234 636 minecraft:magenta_concrete
fill 190 234 637 229 234 637 minecraft:black_concrete
fill 190 234 640 229 234 640 minecraft:black_concrete
fill 190 234 641 191 234 642 minecraft:magenta_concrete
fill 190 234 643 229 234 643 minecraft:black_concrete
setblock 190 234 646 minecraft:magenta_concrete
fill 191 234 646 191 241 646 minecraft:lime_concrete
fill 192 234 604 192 307 604 minecraft:lime_concrete
fill 192 234 605 192 234 606 minecraft:black_concrete
fill 192 234 611 192 234 612 minecraft:black_concrete
fill 192 234 617 192 234 618 minecraft:black_concrete
fill 192 234 623 192 234 624 minecraft:black_concrete
fill 192 234 629 192 234 630 minecraft:black_concrete
fill 192 234 635 192 234 636 minecraft:black_concrete
fill 192 234 641 192 234 642 minecraft:black_concrete
setblock 192 234 646 minecraft:magenta_concrete
fill 193 234 604 193 234 606 minecraft:magenta_concrete
fill 193 234 611 194 234 612 minecraft:magenta_concrete
fill 193 234 617 194 234 618 minecraft:magenta_concrete
fill 193 234 623 194 234 624 minecraft:magenta_concrete
fill 193 234 629 194 234 630 minecraft:magenta_concrete
fill 193 234 635 194 234 636 minecraft:magenta_concrete
fill 193 234 641 194 234 642 minecraft:magenta_concrete
fill 193 234 646 196 234 646 minecraft:lime_concrete
fill 194 234 604 199 234 604 minecraft:lime_concrete
fill 194 234 605 194 234 606 minecraft:magenta_concrete
fill 195 234 605 195 234 606 minecraft:black_concrete
fill 195 234 611 195 234 612 minecraft:black_concrete
fill 195 234 617 195 234 618 minecraft:black_concrete
fill 195 234 623 195 234 624 minecraft:black_concrete
fill 195 234 629 195 234 630 minecraft:black_concrete
fill 195 234 635 195 234 636 minecraft:black_concrete
fill 195 234 641 195 234 642 minecraft:black_concrete
fill 196 234 605 197 234 606 minecraft:magenta_concrete
fill 196 234 611 197 234 612 minecraft:magenta_concrete
fill 196 234 617 197 234 618 minecraft:magenta_concrete
fill 196 234 623 197 234 624 minecraft:magenta_concrete
fill 196 234 629 197 234 630 minecraft:magenta_concrete
fill 196 234 635 197 234 636 minecraft:magenta_concrete
fill 196 234 641 197 234 642 minecraft:magenta_concrete
fill 198 234 605 198 234 606 minecraft:black_concrete
fill 198 234 611 198 234 612 minecraft:black_concrete
fill 198 234 617 198 234 618 minecraft:black_concrete
fill 198 234 623 198 234 624 minecraft:black_concrete
fill 198 234 629 198 234 630 minecraft:black_concrete
fill 198 234 635 198 234 636 minecraft:black_concrete
fill 198 234 641 198 234 642 minecraft:black_concrete
fill 198 234 646 199 241 646 minecraft:lime_concrete
fill 199 234 605 200 234 606 minecraft:magenta_concrete
fill 199 234 611 200 234 612 minecraft:magenta_concrete
fill 199 234 617 200 234 618 minecraft:magenta_concrete
fill 199 234 623 200 234 624 minecraft:magenta_concrete
fill 199 234 629 200 234 630 minecraft:magenta_concrete
fill 199 234 635 200 234 636 minecraft:magenta_concrete
fill 199 234 641 200 234 642 minecraft:magenta_concrete
fill 200 234 604 200 235 604 minecraft:magenta_concrete
setblock 200 234 646 minecraft:magenta_concrete
fill 201 234 604 201 307 604 minecraft:lime_concrete
fill 201 234 605 201 234 606 minecraft:black_concrete
fill 201 234 611 201 234 612 minecraft:black_concrete
fill 201 234 617 201 234 618 minecraft:black_concrete
fill 201 234 623 201 234 624 minecraft:black_concrete
fill 201 234 629 201 234 630 minecraft:black_concrete
fill 201 234 635 201 234 636 minecraft:black_concrete
fill 201 234 641 201 234 642 minecraft:black_concrete
fill 201 234 646 202 307 646 minecraft:lime_concrete
fill 202 234 605 203 234 606 minecraft:magenta_concrete
fill 202 234 611 203 234 612 minecraft:magenta_concrete
fill 202 234 617 203 234 618 minecraft:magenta_concrete
fill 202 234 623 203 234 624 minecraft:magenta_concrete
fill 202 234 629 202 234 630 minecraft:magenta_concrete
fill 202 234 635 203 234 636 minecraft:magenta_concrete
fill 202 234 641 203 234 642 minecraft:magenta_concrete
fill 203 234 604 205 241 604 minecraft:lime_concrete
fill 203 234 626 207 234 626 minecraft:magenta_concrete
fill 203 234 627 203 234 631 minecraft:sea_lantern
fill 204 234 605 204 234 606 minecraft:black_concrete
fill 204 234 611 204 234 612 minecraft:black_concrete
fill 204 234 617 204 234 618 minecraft:black_concrete
fill 204 234 623 204 234 624 minecraft:black_concrete
fill 204 234 627 208 234 627 minecraft:sea_lantern
fill 204 234 628 206 234 630 minecraft:magenta_concrete
fill 204 234 631 207 234 631 minecraft:sea_lantern
fill 204 234 635 204 234 636 minecraft:black_concrete
fill 204 234 641 204 234 642 minecraft:black_concrete
fill 205 234 605 206 234 606 minecraft:magenta_concrete
fill 205 234 611 206 234 612 minecraft:magenta_concrete
fill 205 234 617 206 234 618 minecraft:magenta_concrete
fill 205 234 623 206 234 624 minecraft:magenta_concrete
fill 205 234 635 206 234 636 minecraft:magenta_concrete
fill 205 234 641 206 234 642 minecraft:magenta_concrete
setblock 206 234 604 minecraft:magenta_concrete
fill 207 234 604 209 307 604 minecraft:lime_concrete
fill 207 234 605 207 234 606 minecraft:black_concrete
fill 207 234 611 207 234 612 minecraft:black_concrete
fill 207 234 617 207 234 618 minecraft:black_concrete
fill 207 234 623 207 234 624 minecraft:black_concrete
fill 207 234 628 208 234 630 minecraft:sea_lantern
fill 207 234 635 207 234 636 minecraft:black_concrete
fill 207 234 641 207 234 642 minecraft:black_concrete
fill 208 234 605 209 234 606 minecraft:magenta_concrete
fill 208 234 611 209 234 612 minecraft:magenta_concrete
fill 208 234 617 209 234 618 minecraft:magenta_concrete
fill 208 234 623 209 234 624 minecraft:magenta_concrete
fill 208 234 626 212 234 626 minecraft:sea_lantern
fill 208 234 631 210 234 631 minecraft:black_concrete
fill 208 234 635 209 234 636 minecraft:magenta_concrete
fill 208 234 641 209 234 642 minecraft:magenta_concrete
fill 209 234 630 215 234 630 minecraft:sea_lantern
fill 210 234 605 210 234 606 minecraft:black_concrete
fill 210 234 611 210 234 612 minecraft:black_concrete
fill 210 234 617 210 234 618 minecraft:black_concrete
fill 210 234 623 210 234 624 minecraft:black_concrete
fill 210 234 635 210 234 636 minecraft:black_concrete
fill 210 234 641 210 234 642 minecraft:black_concrete
fill 211 234 605 212 234 606 minecraft:magenta_concrete
fill 211 234 611 212 234 612 minecraft:magenta_concrete
fill 211 234 617 212 234 618 minecraft:magenta_concrete
fill 211 234 623 211 234 624 minecraft:magenta_concrete
fill 211 234 631 211 234 634 minecraft:sea_lantern
fill 211 234 635 212 234 636 minecraft:magenta_concrete
fill 211 234 641 212 234 642 minecraft:magenta_concrete
fill 212 234 623 212 234 625 minecraft:sea_lantern
fill 212 234 627 212 234 629 minecraft:sea_lantern
fill 212 234 631 214 234 633 minecraft:magenta_concrete
fill 212 234 634 215 234 634 minecraft:sea_lantern
fill 213 234 605 213 234 606 minecraft:black_concrete
fill 213 234 611 213 234 612 minecraft:black_concrete
fill 213 234 617 213 234 618 minecraft:black_concrete
fill 213 234 623 216 234 623 minecraft:sea_lantern
fill 213 234 624 215 234 626 minecraft:magenta_concrete
fill 213 234 627 216 234 627 minecraft:sea_lantern
fill 213 234 628 213 234 629 minecraft:black_concrete
fill 213 234 635 213 234 636 minecraft:black_concrete
fill 213 234 641 213 234 642 minecraft:black_concrete
fill 214 234 605 215 234 606 minecraft:magenta_concrete
fill 214 234 611 215 234 612 minecraft:magenta_concrete
fill 214 234 617 215 234 618 minecraft:magenta_concrete
fill 214 234 628 229 234 628 minecraft:black_concrete
fill 214 234 629 215 234 629 minecraft:magenta_concrete
fill 214 234 635 215 234 636 minecraft:magenta_concrete
fill 214 234 641 215 234 642 minecraft:magenta_concrete
fill 215 234 631 215 234 633 minecraft:sea_lantern
fill 215 234 646 217 234 646 minecraft:lime_concrete
fill 216 234 605 216 234 606 minecraft:black_concrete
fill 216 234 611 216 234 612 minecraft:black_concrete
fill 216 234 617 216 234 618 minecraft:black_concrete
fill 216 234 624 216 234 626 minecraft:sea_lantern
fill 216 234 629 216 234 631 minecraft:black_concrete
fill 216 234 632 229 234 633 minecraft:magenta_concrete
fill 216 234 634 216 234 636 minecraft:black_concrete
fill 216 234 641 216 234 642 minecraft:black_concrete
fill 217 234 605 218 234 606 minecraft:magenta_concrete
fill 217 234 611 218 234 612 minecraft:magenta_concrete
fill 217 234 617 218 234 618 minecraft:magenta_concrete
fill 217 234 623 218 234 624 minecraft:magenta_concrete
fill 217 234 625 229 234 625 minecraft:black_concrete
fill 217 234 626 229 234 627 minecraft:magenta_concrete
fill 217 234 629 218 234 630 minecraft:magenta_concrete
fill 217 234 631 229 234 631 minecraft:black_concrete
fill 217 234 634 229 234 634 minecraft:black_concrete
fill 217 234 635 218 234 636 minecraft:magenta_concrete
fill 217 234 641 218 234 642 minecraft:magenta_concrete
fill 218 234 604 222 234 604 minecraft:lime_concrete
setblock 218 234 646 minecraft:magenta_concrete
fill 219 234 605 219 234 606 minecraft:black_concrete
fill 219 234 611 219 234 612 minecraft:black_concrete
fill 219 234 617 219 234 618 minecraft:black_concrete
fill 219 234 623 219 234 624 minecraft:black_concrete
fill 219 234 629 219 234 630 minecraft:black_concrete
fill 219 234 635 219 234 636 minecraft:black_concrete
fill 219 234 641 219 234 642 minecraft:black_concrete
fill 219 234 646 230 234 646 minecraft:lime_concrete
fill 220 234 605 221 234 606 minecraft:magenta_concrete
fill 220 234 611 221 234 612 minecraft:magenta_concrete
fill 220 234 617 221 234 618 minecraft:magenta_concrete
fill 220 234 623 221 234 624 minecraft:magenta_concrete
fill 220 234 629 221 234 630 minecraft:magenta_concrete
fill 220 234 635 221 234 636 minecraft:magenta_concrete
fill 220 234 641 221 234 642 minecraft:magenta_concrete
fill 222 234 605 222 234 606 minecraft:black_concrete
fill 222 234 611 222 234 612 minecraft:black_concrete
fill 222 234 617 222 234 618 minecraft:black_concrete
fill 222 234 623 222 234 624 minecraft:black_concrete
fill 222 234 629 222 234 630 minecraft:black_concrete
fill 222 234 635 222 234 636 minecraft:black_concrete
fill 222 234 641 222 234 642 minecraft:black_concrete
fill 223 234 604 223 234 606 minecraft:magenta_concrete
schedule function dropper:buildpart/148_3 1t
