setblock 136 243 587 minecraft:white_concrete
fill 136 243 588 136 254 592 minecraft:black_concrete
setblock 136 243 593 minecraft:white_stained_glass
fill 136 243 594 136 286 594 minecraft:black_concrete
fill 94 244 569 94 286 569 minecraft:black_concrete
fill 94 244 586 94 296 586 minecraft:black_concrete
fill 107 244 570 107 245 570 minecraft:gray_concrete
fill 109 244 599 109 288 599 minecraft:black_concrete
setblock 121 244 599 minecraft:pearlescent_froglight
fill 122 244 599 123 260 599 minecraft:black_concrete
fill 126 244 599 126 307 599 minecraft:black_concrete
setblock 135 244 599 minecraft:pearlescent_froglight
fill 136 244 579 136 278 579 minecraft:black_concrete
fill 136 244 587 136 307 587 minecraft:black_concrete
fill 136 244 593 136 307 593 minecraft:black_concrete
fill 121 245 599 121 276 599 minecraft:black_concrete
fill 135 245 599 135 276 599 minecraft:black_concrete
fill 94 246 565 94 251 565 minecraft:black_concrete
setblock 94 246 581 minecraft:black_concrete
fill 94 246 584 94 247 584 minecraft:black_concrete
setblock 94 246 585 minecraft:pearlescent_froglight
fill 94 246 587 94 256 590 minecraft:black_concrete
fill 94 246 591 94 246 592 minecraft:white_concrete
fill 94 246 593 94 246 594 minecraft:black_concrete
fill 94 246 597 94 251 597 minecraft:black_concrete
fill 98 246 557 98 251 557 minecraft:black_concrete
fill 108 246 599 108 248 599 minecraft:black_concrete
setblock 112 246 557 minecraft:pearlescent_froglight
fill 113 246 557 114 251 557 minecraft:black_concrete
fill 124 246 599 124 251 599 minecraft:black_concrete
fill 130 246 557 130 251 557 minecraft:black_concrete
fill 132 246 580 133 247 581 minecraft:gray_concrete
fill 136 246 567 136 249 567 minecraft:black_concrete
fill 136 246 583 136 251 583 minecraft:black_concrete
setblock 94 247 581 minecraft:white_stained_glass
fill 94 247 585 94 294 585 minecraft:black_concrete
fill 94 247 591 94 286 592 minecraft:black_concrete
setblock 94 247 593 minecraft:white_concrete
fill 94 247 594 94 286 594 minecraft:black_concrete
fill 112 247 557 112 259 557 minecraft:black_concrete
setblock 120 247 557 minecraft:white_stained_glass
fill 121 247 557 121 278 557 minecraft:black_concrete
fill 94 248 581 94 251 581 minecraft:black_concrete
setblock 94 248 584 minecraft:white_stained_glass
fill 94 248 593 94 295 593 minecraft:black_concrete
fill 114 248 593 115 249 593 minecraft:end_stone
fill 120 248 557 120 249 557 minecraft:black_concrete
fill 127 248 599 132 261 599 minecraft:black_concrete
setblock 133 248 599 minecraft:pearlescent_froglight
fill 134 248 599 134 307 599 minecraft:black_concrete
fill 136 248 558 136 261 560 minecraft:black_concrete
setblock 136 248 561 minecraft:white_concrete
fill 136 248 562 136 299 562 minecraft:black_concrete
fill 94 249 584 94 307 584 minecraft:black_concrete
setblock 108 249 599 minecraft:white_stained_glass
fill 116 249 599 119 257 599 minecraft:black_concrete
setblock 120 249 599 minecraft:pearlescent_froglight
fill 130 249 583 130 250 584 minecraft:gray_concrete
fill 133 249 599 133 292 599 minecraft:black_concrete
fill 136 249 561 136 290 561 minecraft:black_concrete
fill 136 249 584 136 269 584 minecraft:black_concrete
setblock 136 249 585 minecraft:white_stained_glass
fill 136 249 586 136 251 586 minecraft:black_concrete
fill 94 250 572 94 256 575 minecraft:black_concrete
setblock 94 250 576 minecraft:white_concrete
setblock 97 250 560 minecraft:light[level=14]
setblock 97 250 568 minecraft:light[level=14]
setblock 97 250 576 minecraft:light[level=14]
setblock 97 250 584 minecraft:light[level=14]
setblock 97 250 592 minecraft:light[level=14]
setblock 105 250 560 minecraft:light[level=14]
setblock 105 250 568 minecraft:light[level=14]
setblock 105 250 576 minecraft:light[level=14]
setblock 105 250 584 minecraft:light[level=14]
setblock 105 250 592 minecraft:light[level=14]
fill 106 250 584 107 251 584 minecraft:gray_concrete
fill 108 250 599 108 251 599 minecraft:black_concrete
setblock 113 250 560 minecraft:light[level=14]
setblock 113 250 568 minecraft:light[level=14]
setblock 113 250 576 minecraft:light[level=14]
setblock 113 250 584 minecraft:light[level=14]
setblock 113 250 592 minecraft:light[level=14]
setblock 120 250 557 minecraft:pearlescent_froglight
fill 120 250 599 120 269 599 minecraft:black_concrete
setblock 121 250 560 minecraft:light[level=14]
setblock 121 250 568 minecraft:light[level=14]
setblock 121 250 576 minecraft:light[level=14]
setblock 121 250 584 minecraft:light[level=14]
setblock 121 250 592 minecraft:light[level=14]
setblock 126 250 557 minecraft:white_concrete
setblock 129 250 560 minecraft:light[level=14]
setblock 129 250 568 minecraft:light[level=14]
setblock 129 250 576 minecraft:light[level=14]
setblock 129 250 584 minecraft:light[level=14]
setblock 129 250 592 minecraft:light[level=14]
setblock 136 250 567 minecraft:white_stained_glass
fill 136 250 585 136 278 585 minecraft:black_concrete
fill 94 251 576 94 290 576 minecraft:black_concrete
fill 95 251 557 95 281 557 minecraft:black_concrete
setblock 96 251 557 minecraft:pearlescent_froglight
fill 97 251 557 97 291 557 minecraft:black_concrete
setblock 97 251 599 minecraft:white_stained_glass
fill 100 251 599 100 258 599 minecraft:black_concrete
setblock 101 251 599 minecraft:pearlescent_froglight
fill 102 251 599 102 307 599 minecraft:black_concrete
fill 111 251 587 112 252 588 minecraft:end_stone
fill 113 251 588 113 252 588 minecraft:end_stone
fill 120 251 557 120 278 557 minecraft:black_concrete
fill 123 251 566 123 252 566 minecraft:end_stone
setblock 125 251 599 minecraft:white_concrete
fill 126 251 557 126 270 557 minecraft:black_concrete
fill 131 251 557 133 284 557 minecraft:black_concrete
setblock 134 251 557 minecraft:white_concrete
fill 135 251 557 135 307 557 minecraft:black_concrete
setblock 136 251 567 minecraft:black_concrete
fill 94 252 565 94 254 565 minecraft:light_gray_concrete
fill 94 252 581 94 254 581 minecraft:light_gray_concrete
fill 94 252 597 94 254 597 minecraft:light_gray_concrete
fill 96 252 557 96 307 557 minecraft:black_concrete
fill 97 252 599 97 274 599 minecraft:black_concrete
fill 98 252 557 98 254 557 minecraft:light_gray_concrete
fill 101 252 599 101 307 599 minecraft:black_concrete
fill 108 252 599 108 254 599 minecraft:light_gray_concrete
fill 113 252 557 113 278 557 minecraft:black_concrete
fill 114 252 557 114 254 557 minecraft:light_gray_concrete
fill 115 252 557 116 278 557 minecraft:black_concrete
setblock 117 252 557 minecraft:pearlescent_froglight
fill 118 252 557 119 278 557 minecraft:black_concrete
fill 124 252 599 124 254 599 minecraft:light_gray_concrete
fill 125 252 599 125 307 599 minecraft:black_concrete
fill 130 252 557 130 254 557 minecraft:light_gray_concrete
fill 134 252 557 134 292 557 minecraft:black_concrete
setblock 136 252 566 minecraft:white_stained_glass
fill 136 252 567 136 254 567 minecraft:light_gray_concrete
fill 136 252 583 136 254 583 minecraft:light_gray_concrete
setblock 136 252 586 minecraft:white_concrete
fill 113 253 568 113 254 569 minecraft:light_gray_concrete
fill 117 253 557 117 278 557 minecraft:black_concrete
setblock 136 253 564 minecraft:white_concrete
fill 136 253 566 136 279 566 minecraft:black_concrete
fill 136 253 586 136 307 586 minecraft:black_concrete
setblock 101 254 557 minecraft:pearlescent_froglight
fill 136 254 564 136 280 564 minecraft:black_concrete
fill 136 254 568 136 278 569 minecraft:black_concrete
setblock 136 254 570 minecraft:white_concrete
fill 136 254 571 136 269 573 minecraft:black_concrete
fill 94 255 565 94 260 565 minecraft:black_concrete
fill 94 255 581 94 260 581 minecraft:black_concrete
fill 94 255 597 94 260 597 minecraft:black_concrete
fill 98 255 557 98 259 557 minecraft:black_concrete
fill 101 255 557 101 307 557 minecraft:black_concrete
fill 108 255 599 108 260 599 minecraft:black_concrete
fill 114 255 557 114 256 557 minecraft:black_concrete
fill 124 255 599 124 260 599 minecraft:black_concrete
setblock 130 255 557 minecraft:black_concrete
fill 136 255 567 136 260 567 minecraft:black_concrete
fill 136 255 570 136 278 570 minecraft:black_concrete
fill 136 255 583 136 260 583 minecraft:black_concrete
fill 136 255 588 136 255 591 minecraft:black_concrete
setblock 136 255 592 minecraft:pearlescent_froglight
fill 101 256 584 101 257 584 minecraft:gray_concrete
fill 110 256 599 113 262 599 minecraft:black_concrete
setblock 114 256 599 minecraft:white_stained_glass
fill 122 256 566 122 257 566 minecraft:white_stained_glass
setblock 130 256 557 minecraft:white_concrete
fill 136 256 588 136 259 590 minecraft:black_concrete
setblock 136 256 591 minecraft:white_concrete
fill 136 256 592 136 301 592 minecraft:black_concrete
fill 94 257 572 94 269 572 minecraft:black_concrete
setblock 94 257 573 minecraft:white_stained_glass
fill 94 257 574 94 273 575 minecraft:black_concrete
setblock 94 257 577 minecraft:white_concrete
fill 94 257 587 94 263 588 minecraft:black_concrete
setblock 94 257 589 minecraft:pearlescent_froglight
fill 94 257 590 94 307 590 minecraft:black_concrete
fill 104 257 570 104 258 570 minecraft:white_stained_glass
fill 107 257 557 107 258 557 minecraft:black_concrete
setblock 108 257 557 minecraft:pearlescent_froglight
fill 109 257 557 109 278 557 minecraft:black_concrete
setblock 114 257 557 minecraft:white_concrete
fill 114 257 599 114 259 599 minecraft:black_concrete
fill 130 257 557 130 260 557 minecraft:black_concrete
fill 136 257 591 136 276 591 minecraft:black_concrete
fill 136 257 596 136 307 596 minecraft:black_concrete
setblock 136 257 597 minecraft:pearlescent_froglight
fill 94 258 573 94 289 573 minecraft:black_concrete
fill 94 258 577 94 307 577 minecraft:black_concrete
fill 94 258 589 94 307 589 minecraft:black_concrete
setblock 97 258 560 minecraft:light[level=14]
setblock 97 258 568 minecraft:light[level=14]
setblock 97 258 576 minecraft:light[level=14]
setblock 97 258 584 minecraft:light[level=14]
setblock 97 258 592 minecraft:light[level=14]
setblock 105 258 560 minecraft:light[level=14]
setblock 105 258 568 minecraft:light[level=14]
setblock 105 258 576 minecraft:light[level=14]
setblock 105 258 584 minecraft:light[level=14]
setblock 105 258 592 minecraft:light[level=14]
fill 108 258 557 108 306 557 minecraft:black_concrete
setblock 113 258 560 minecraft:light[level=14]
setblock 113 258 568 minecraft:light[level=14]
setblock 113 258 576 minecraft:light[level=14]
setblock 113 258 584 minecraft:light[level=14]
setblock 113 258 592 minecraft:light[level=14]
fill 114 258 557 114 260 557 minecraft:black_concrete
fill 116 258 599 116 307 599 minecraft:black_concrete
setblock 117 258 599 minecraft:white_concrete
fill 118 258 599 119 301 599 minecraft:black_concrete
setblock 121 258 560 minecraft:light[level=14]
setblock 121 258 568 minecraft:light[level=14]
setblock 121 258 576 minecraft:light[level=14]
setblock 121 258 584 minecraft:light[level=14]
setblock 121 258 592 minecraft:light[level=14]
fill 122 258 566 122 264 567 minecraft:gray_concrete
setblock 129 258 560 minecraft:light[level=14]
setblock 129 258 568 minecraft:light[level=14]
setblock 129 258 576 minecraft:light[level=14]
setblock 129 258 584 minecraft:light[level=14]
setblock 129 258 592 minecraft:light[level=14]
fill 136 258 597 136 307 597 minecraft:black_concrete
setblock 94 259 570 minecraft:white_concrete
setblock 100 259 599 minecraft:pearlescent_froglight
fill 103 259 570 104 269 570 minecraft:gray_concrete
setblock 107 259 557 minecraft:white_stained_glass
fill 117 259 599 117 296 599 minecraft:black_concrete
fill 121 259 566 121 264 566 minecraft:gray_concrete
fill 130 259 578 131 260 579 minecraft:light_gray_concrete
fill 132 259 578 132 260 578 minecraft:light_gray_concrete
setblock 136 259 563 minecraft:pearlescent_froglight
fill 136 259 581 136 278 581 minecraft:black_concrete
setblock 136 259 582 minecraft:white_stained_glass
fill 94 260 570 94 307 570 minecraft:black_concrete
setblock 98 260 557 minecraft:pearlescent_froglight
fill 100 260 599 100 307 599 minecraft:black_concrete
fill 107 260 557 107 298 557 minecraft:black_concrete
setblock 112 260 557 minecraft:white_stained_glass
setblock 114 260 599 minecraft:white_concrete
fill 121 260 567 121 264 567 minecraft:gray_concrete
fill 122 260 565 122 264 565 minecraft:gray_concrete
fill 123 260 566 123 264 567 minecraft:gray_concrete
fill 136 260 563 136 272 563 minecraft:black_concrete
fill 136 260 582 136 278 582 minecraft:black_concrete
setblock 136 260 588 minecraft:pearlescent_froglight
fill 136 260 589 136 266 590 minecraft:black_concrete
fill 94 261 565 94 263 565 minecraft:light_gray_concrete
fill 94 261 581 94 263 581 minecraft:light_gray_concrete
fill 94 261 597 94 263 597 minecraft:light_gray_concrete
fill 98 261 557 98 263 557 minecraft:light_gray_concrete
fill 103 261 569 104 269 569 minecraft:gray_concrete
fill 103 261 571 104 269 571 minecraft:gray_concrete
fill 105 261 570 105 269 570 minecraft:gray_concrete
fill 108 261 599 108 263 599 minecraft:light_gray_concrete
fill 112 261 557 112 278 557 minecraft:black_concrete
fill 114 261 557 114 263 557 minecraft:light_gray_concrete
fill 114 261 599 114 304 599 minecraft:black_concrete
fill 120 261 566 120 264 566 minecraft:gray_concrete
fill 121 261 565 121 264 565 minecraft:gray_concrete
fill 121 261 568 122 264 568 minecraft:gray_concrete
fill 122 261 599 122 270 599 minecraft:black_concrete
fill 123 261 565 123 264 565 minecraft:gray_concrete
setblock 123 261 599 minecraft:pearlescent_froglight
fill 124 261 599 124 263 599 minecraft:light_gray_concrete
fill 130 261 557 130 263 557 minecraft:light_gray_concrete
fill 136 261 567 136 263 567 minecraft:light_gray_concrete
fill 136 261 583 136 263 583 minecraft:light_gray_concrete
fill 136 261 588 136 307 588 minecraft:black_concrete
fill 102 262 569 102 269 571 minecraft:gray_concrete
fill 105 262 569 105 269 569 minecraft:gray_concrete
fill 105 262 571 105 269 571 minecraft:gray_concrete
fill 120 262 565 120 264 565 minecraft:gray_concrete
fill 120 262 567 120 264 567 minecraft:gray_concrete
fill 123 262 568 123 264 568 minecraft:gray_concrete
fill 123 262 599 123 286 599 minecraft:black_concrete
fill 124 262 566 124 264 567 minecraft:gray_concrete
fill 127 262 579 127 263 580 minecraft:gray_concrete
fill 127 262 599 130 276 599 minecraft:black_concrete
setblock 131 262 599 minecraft:pearlescent_froglight
fill 132 262 599 132 267 599 minecraft:black_concrete
fill 136 262 558 136 293 559 minecraft:black_concrete
setblock 136 262 560 minecraft:white_concrete
setblock 94 263 580 minecraft:pearlescent_froglight
setblock 102 263 557 minecraft:white_concrete
fill 103 263 557 105 274 557 minecraft:black_concrete
fill 103 263 568 105 269 568 minecraft:gray_concrete
fill 103 263 572 105 269 572 minecraft:gray_concrete
fill 106 263 570 106 269 570 minecraft:gray_concrete
fill 110 263 599 111 302 599 minecraft:black_concrete
setblock 112 263 599 minecraft:pearlescent_froglight
fill 113 263 599 113 307 599 minecraft:black_concrete
fill 120 263 568 120 264 568 minecraft:gray_concrete
fill 121 263 564 123 264 564 minecraft:gray_concrete
fill 121 263 569 123 264 569 minecraft:gray_concrete
fill 124 263 565 124 264 565 minecraft:gray_concrete
fill 124 263 568 124 264 568 minecraft:gray_concrete
fill 131 263 599 131 269 599 minecraft:black_concrete
fill 136 263 560 136 305 560 minecraft:black_concrete
setblock 136 263 576 minecraft:white_concrete
fill 94 264 565 94 269 565 minecraft:black_concrete
fill 94 264 580 94 265 581 minecraft:black_concrete
fill 94 264 587 94 277 587 minecraft:black_concrete
setblock 94 264 588 minecraft:white_stained_glass
fill 94 264 597 94 269 597 minecraft:black_concrete
fill 98 264 557 98 269 557 minecraft:black_concrete
fill 101 264 569 101 269 571 minecraft:gray_concrete
fill 102 264 557 102 270 557 minecraft:black_concrete
fill 102 264 568 102 269 568 minecraft:gray_concrete
fill 102 264 572 102 269 572 minecraft:gray_concrete
fill 106 264 569 106 269 569 minecraft:gray_concrete
fill 106 264 571 106 269 571 minecraft:gray_concrete
fill 108 264 599 108 266 599 minecraft:black_concrete
fill 112 264 599 112 307 599 minecraft:black_concrete
fill 114 264 557 114 269 557 minecraft:black_concrete
fill 119 264 565 119 264 568 minecraft:gray_concrete
setblock 120 264 564 minecraft:gray_concrete
setblock 120 264 569 minecraft:gray_concrete
setblock 124 264 564 minecraft:gray_concrete
fill 124 264 599 124 269 599 minecraft:black_concrete
fill 125 264 566 125 264 567 minecraft:gray_concrete
fill 130 264 557 130 269 557 minecraft:black_concrete
fill 136 264 567 136 265 567 minecraft:black_concrete
fill 136 264 576 136 278 576 minecraft:black_concrete
fill 136 264 583 136 269 583 minecraft:black_concrete
fill 94 265 588 94 304 588 minecraft:black_concrete
fill 101 265 568 101 269 568 minecraft:gray_concrete
fill 101 265 572 101 269 572 minecraft:gray_concrete
fill 102 265 567 105 269 567 minecraft:gray_concrete
fill 102 265 573 105 269 573 minecraft:gray_concrete
fill 106 265 568 106 269 568 minecraft:gray_concrete
fill 106 265 572 106 269 572 minecraft:gray_concrete
fill 106 265 582 106 266 582 minecraft:end_stone
fill 107 265 570 107 269 570 minecraft:gray_concrete
fill 120 265 566 120 268 566 minecraft:end_stone
fill 123 265 565 123 266 565 minecraft:end_stone
fill 123 265 568 123 267 568 minecraft:end_stone
setblock 136 265 577 minecraft:white_stained_glass
fill 136 265 578 136 269 578 minecraft:black_concrete
setblock 94 266 580 minecraft:white_stained_glass
fill 94 266 581 94 269 581 minecraft:black_concrete
setblock 97 266 560 minecraft:light[level=14]
setblock 97 266 568 minecraft:light[level=14]
setblock 97 266 576 minecraft:light[level=14]
setblock 97 266 584 minecraft:light[level=14]
setblock 97 266 592 minecraft:light[level=14]
fill 100 266 569 100 269 571 minecraft:gray_concrete
fill 101 266 567 101 269 567 minecraft:gray_concrete
fill 101 266 573 101 269 573 minecraft:gray_concrete
setblock 105 266 560 minecraft:light[level=14]
setblock 105 266 576 minecraft:light[level=14]
setblock 105 266 584 minecraft:light[level=14]
setblock 105 266 592 minecraft:light[level=14]
fill 106 266 567 106 269 567 minecraft:gray_concrete
fill 106 266 573 106 269 573 minecraft:gray_concrete
fill 107 266 569 107 269 569 minecraft:gray_concrete
fill 107 266 571 107 269 572 minecraft:gray_concrete
setblock 113 266 560 minecraft:light[level=14]
setblock 113 266 568 minecraft:light[level=14]
setblock 113 266 576 minecraft:light[level=14]
setblock 113 266 584 minecraft:light[level=14]
setblock 113 266 592 minecraft:light[level=14]
setblock 121 266 560 minecraft:light[level=14]
setblock 121 266 568 minecraft:light[level=14]
setblock 121 266 576 minecraft:light[level=14]
setblock 121 266 584 minecraft:light[level=14]
setblock 121 266 592 minecraft:light[level=14]
setblock 129 266 560 minecraft:light[level=14]
setblock 129 266 568 minecraft:light[level=14]
setblock 129 266 576 minecraft:light[level=14]
setblock 129 266 584 minecraft:light[level=14]
setblock 129 266 592 minecraft:light[level=14]
setblock 136 266 567 minecraft:white_stained_glass
fill 136 266 574 136 277 574 minecraft:black_concrete
setblock 136 266 575 minecraft:pearlescent_froglight
fill 136 266 577 136 278 577 minecraft:black_concrete
fill 94 267 580 94 283 580 minecraft:black_concrete
fill 100 267 568 100 269 568 minecraft:gray_concrete
fill 100 267 572 100 269 572 minecraft:gray_concrete
fill 102 267 566 105 269 566 minecraft:gray_concrete
fill 102 267 574 105 269 574 minecraft:gray_concrete
fill 107 267 568 107 269 568 minecraft:gray_concrete
fill 108 267 570 108 269 570 minecraft:gray_concrete
setblock 108 267 599 minecraft:pearlescent_froglight
fill 125 267 564 126 268 564 minecraft:end_stone
fill 136 267 567 136 269 567 minecraft:black_concrete
fill 136 267 575 136 278 575 minecraft:black_concrete
setblock 136 267 589 minecraft:white_stained_glass
fill 136 267 590 136 307 590 minecraft:black_concrete
fill 99 268 568 99 269 572 minecraft:gray_concrete
fill 100 268 567 100 269 567 minecraft:gray_concrete
fill 100 268 573 100 269 573 minecraft:gray_concrete
fill 101 268 566 101 269 566 minecraft:gray_concrete
fill 101 268 574 101 269 574 minecraft:gray_concrete
fill 106 268 566 106 269 566 minecraft:gray_concrete
fill 106 268 574 106 269 574 minecraft:gray_concrete
fill 107 268 567 107 269 567 minecraft:gray_concrete
fill 107 268 573 107 269 573 minecraft:gray_concrete
fill 108 268 568 108 269 569 minecraft:gray_concrete
fill 108 268 571 108 269 572 minecraft:gray_concrete
fill 108 268 599 108 269 599 minecraft:black_concrete
setblock 132 268 599 minecraft:white_concrete
fill 136 268 589 136 286 589 minecraft:black_concrete
fill 94 269 558 94 272 563 minecraft:black_concrete
setblock 94 269 564 minecraft:white_concrete
setblock 99 269 567 minecraft:gray_concrete
setblock 99 269 573 minecraft:gray_concrete
setblock 100 269 566 minecraft:gray_concrete
setblock 100 269 574 minecraft:gray_concrete
fill 102 269 565 105 269 565 minecraft:gray_concrete
fill 102 269 575 105 269 575 minecraft:gray_concrete
setblock 107 269 566 minecraft:gray_concrete
setblock 107 269 574 minecraft:gray_concrete
setblock 108 269 567 minecraft:gray_concrete
setblock 108 269 573 minecraft:gray_concrete
setblock 109 269 570 minecraft:gray_concrete
fill 110 269 557 110 293 557 minecraft:black_concrete
setblock 111 269 557 minecraft:white_concrete
setblock 115 269 599 minecraft:pearlescent_froglight
fill 132 269 599 132 274 599 minecraft:black_concrete
fill 94 270 564 94 275 564 minecraft:black_concrete
fill 94 270 565 94 272 565 minecraft:light_gray_concrete
setblock 94 270 572 minecraft:white_stained_glass
fill 94 270 581 94 272 581 minecraft:light_gray_concrete
fill 94 270 597 94 272 597 minecraft:light_gray_concrete
fill 98 270 557 98 272 557 minecraft:light_gray_concrete
fill 102 270 569 102 272 569 minecraft:end_stone
fill 103 270 572 103 271 572 minecraft:end_stone
fill 105 270 569 105 273 569 minecraft:end_stone
fill 108 270 599 108 272 599 minecraft:light_gray_concrete
fill 111 270 557 111 277 557 minecraft:black_concrete
fill 114 270 557 114 272 557 minecraft:light_gray_concrete
fill 115 270 599 115 294 599 minecraft:black_concrete
setblock 120 270 599 minecraft:white_stained_glass
fill 124 270 599 124 272 599 minecraft:light_gray_concrete
fill 130 270 557 130 272 557 minecraft:light_gray_concrete
setblock 131 270 599 minecraft:white_concrete
fill 136 270 567 136 272 567 minecraft:light_gray_concrete
setblock 136 270 571 minecraft:white_concrete
fill 136 270 572 136 271 573 minecraft:black_concrete
setblock 136 270 578 minecraft:white_concrete
fill 136 270 583 136 272 583 minecraft:light_gray_concrete
setblock 136 270 584 minecraft:white_stained_glass
setblock 94 271 566 minecraft:white_concrete
fill 94 271 567 94 286 568 minecraft:black_concrete
fill 94 271 572 94 307 572 minecraft:black_concrete
setblock 102 271 557 minecraft:white_stained_glass
fill 120 271 599 120 291 599 minecraft:black_concrete
setblock 122 271 599 minecraft:white_stained_glass
setblock 126 271 557 minecraft:white_stained_glass
fill 131 271 599 131 307 599 minecraft:black_concrete
fill 136 271 571 136 278 571 minecraft:black_concrete
fill 136 271 578 136 278 578 minecraft:black_concrete
fill 136 271 584 136 278 584 minecraft:black_concrete
fill 94 272 566 94 307 566 minecraft:black_concrete
setblock 95 272 599 minecraft:pearlescent_froglight
fill 96 272 599 96 307 599 minecraft:black_concrete
fill 102 272 557 102 307 557 minecraft:black_concrete
fill 122 272 599 122 280 599 minecraft:black_concrete
fill 126 272 557 126 296 557 minecraft:black_concrete
setblock 136 272 572 minecraft:pearlescent_froglight
fill 136 272 573 136 278 573 minecraft:black_concrete
fill 94 273 558 94 296 562 minecraft:black_concrete
setblock 94 273 563 minecraft:white_concrete
fill 94 273 565 94 287 565 minecraft:black_concrete
fill 94 273 581 94 287 581 minecraft:black_concrete
fill 94 273 597 94 287 597 minecraft:black_concrete
fill 95 273 599 95 275 599 minecraft:black_concrete
fill 98 273 557 98 287 557 minecraft:black_concrete
fill 108 273 599 108 287 599 minecraft:black_concrete
fill 114 273 557 114 278 557 minecraft:black_concrete
fill 124 273 599 124 280 599 minecraft:black_concrete
fill 130 273 557 130 287 557 minecraft:black_concrete
setblock 136 273 563 minecraft:white_stained_glass
fill 136 273 567 136 287 567 minecraft:black_concrete
fill 136 273 572 136 278 572 minecraft:black_concrete
fill 136 273 583 136 278 583 minecraft:black_concrete
fill 94 274 563 94 277 563 minecraft:black_concrete
setblock 94 274 574 minecraft:pearlescent_froglight
fill 94 274 575 94 300 575 minecraft:black_concrete
fill 94 274 582 94 307 582 minecraft:black_concrete
setblock 94 274 583 minecraft:white_concrete
setblock 97 274 560 minecraft:light[level=14]
setblock 97 274 568 minecraft:light[level=14]
setblock 97 274 576 minecraft:light[level=14]
setblock 97 274 584 minecraft:light[level=14]
setblock 97 274 592 minecraft:light[level=14]
setblock 105 274 560 minecraft:light[level=14]
setblock 105 274 568 minecraft:light[level=14]
setblock 105 274 576 minecraft:light[level=14]
setblock 105 274 584 minecraft:light[level=14]
setblock 105 274 592 minecraft:light[level=14]
setblock 113 274 560 minecraft:light[level=14]
setblock 113 274 568 minecraft:light[level=14]
setblock 113 274 576 minecraft:light[level=14]
setblock 113 274 584 minecraft:light[level=14]
setblock 113 274 592 minecraft:light[level=14]
setblock 121 274 560 minecraft:light[level=14]
setblock 121 274 568 minecraft:light[level=14]
setblock 121 274 576 minecraft:light[level=14]
setblock 121 274 584 minecraft:light[level=14]
setblock 121 274 592 minecraft:light[level=14]
setblock 129 274 560 minecraft:light[level=14]
setblock 129 274 568 minecraft:light[level=14]
setblock 129 274 576 minecraft:light[level=14]
setblock 129 274 584 minecraft:light[level=14]
setblock 129 274 592 minecraft:light[level=14]
fill 136 274 563 136 307 563 minecraft:black_concrete
fill 94 275 574 94 307 574 minecraft:black_concrete
fill 94 275 583 94 307 583 minecraft:black_concrete
setblock 97 275 599 minecraft:white_concrete
setblock 103 275 557 minecraft:white_concrete
fill 103 275 599 104 292 599 minecraft:black_concrete
fill 104 275 557 105 284 557 minecraft:black_concrete
setblock 105 275 599 minecraft:pearlescent_froglight
setblock 132 275 599 minecraft:white_concrete
setblock 94 276 564 minecraft:pearlescent_froglight
setblock 95 276 599 minecraft:pearlescent_froglight
fill 97 276 599 97 303 599 minecraft:black_concrete
fill 103 276 557 103 296 557 minecraft:black_concrete
fill 105 276 599 105 307 599 minecraft:black_concrete
fill 132 276 599 132 307 599 minecraft:black_concrete
fill 94 277 564 94 307 564 minecraft:black_concrete
fill 95 277 599 95 307 599 minecraft:black_concrete
setblock 121 277 599 minecraft:pearlescent_froglight
fill 127 277 599 127 281 599 minecraft:black_concrete
setblock 128 277 599 minecraft:white_stained_glass
fill 129 277 599 130 307 599 minecraft:black_concrete
setblock 135 277 599 minecraft:pearlescent_froglight
setblock 136 277 591 minecraft:white_stained_glass
setblock 94 278 563 minecraft:white_concrete
setblock 94 278 587 minecraft:pearlescent_froglight
setblock 111 278 557 minecraft:white_stained_glass
fill 121 278 599 121 307 599 minecraft:black_concrete
setblock 128 278 599 minecraft:white_concrete
fill 135 278 599 135 287 599 minecraft:black_concrete
setblock 136 278 574 minecraft:white_stained_glass
fill 136 278 591 136 306 591 minecraft:black_concrete
fill 94 279 563 94 295 563 minecraft:black_concrete
fill 94 279 587 94 283 587 minecraft:black_concrete
fill 96 279 577 114 279 577 minecraft:end_stone
fill 97 279 571 115 279 576 minecraft:end_stone
fill 97 279 578 115 279 583 minecraft:end_stone
fill 98 279 569 136 279 570 minecraft:end_stone
fill 98 279 584 136 279 585 minecraft:end_stone
fill 99 279 567 135 279 568 minecraft:end_stone
fill 99 279 586 135 279 587 minecraft:end_stone
fill 100 279 565 134 279 566 minecraft:end_stone
fill 100 279 588 134 279 589 minecraft:end_stone
fill 101 279 564 133 279 564 minecraft:end_stone
fill 101 279 590 133 279 590 minecraft:end_stone
fill 102 279 563 132 279 563 minecraft:end_stone
fill 102 279 591 132 279 591 minecraft:end_stone
fill 103 279 562 131 279 562 minecraft:end_stone
fill 103 279 592 131 279 592 minecraft:end_stone
fill 104 279 561 130 279 561 minecraft:end_stone
fill 104 279 593 130 279 593 minecraft:end_stone
fill 105 279 560 129 279 560 minecraft:end_stone
fill 105 279 594 129 279 594 minecraft:end_stone
fill 107 279 559 127 279 559 minecraft:end_stone
fill 107 279 595 127 279 595 minecraft:end_stone
setblock 109 279 557 minecraft:pearlescent_froglight
fill 109 279 558 125 279 558 minecraft:end_stone
fill 109 279 596 125 279 596 minecraft:end_stone
fill 111 279 557 123 279 557 minecraft:end_stone
fill 111 279 597 123 279 597 minecraft:end_stone
fill 116 279 571 116 279 575 minecraft:end_stone
fill 116 279 579 116 279 583 minecraft:end_stone
fill 117 279 571 136 279 574 minecraft:end_stone
fill 117 279 580 136 279 583 minecraft:end_stone
fill 117 279 598 117 286 598 minecraft:end_stone
fill 118 279 575 136 279 575 minecraft:end_stone
fill 118 279 579 136 279 579 minecraft:end_stone
fill 119 279 576 136 279 576 minecraft:end_stone
fill 119 279 578 136 279 578 minecraft:end_stone
fill 120 279 577 136 279 577 minecraft:end_stone
fill 128 279 599 128 307 599 minecraft:black_concrete
fill 136 279 568 136 307 568 minecraft:black_concrete
fill 95 280 558 95 280 598 minecraft:end_stone
fill 96 280 558 96 280 576 minecraft:end_stone
fill 96 280 577 96 286 577 minecraft:black_concrete
fill 96 280 578 98 280 598 minecraft:end_stone
fill 97 280 558 98 280 575 minecraft:end_stone
fill 97 280 576 97 286 576 minecraft:black_concrete
fill 97 280 577 111 281 577 minecraft:end_stone
fill 98 280 576 109 282 576 minecraft:end_stone
setblock 99 280 557 minecraft:pearlescent_froglight
fill 99 280 558 99 280 574 minecraft:end_stone
fill 99 280 575 99 286 575 minecraft:black_concrete
fill 99 280 578 99 286 583 minecraft:end_stone
fill 99 280 584 99 286 584 minecraft:black_concrete
fill 99 280 585 103 280 598 minecraft:end_stone
fill 100 280 557 100 286 557 minecraft:black_concrete
fill 100 280 558 101 280 573 minecraft:end_stone
fill 100 280 574 101 285 574 minecraft:black_concrete
fill 100 280 575 111 282 575 minecraft:end_stone
fill 100 280 578 100 286 582 minecraft:end_stone
fill 100 280 583 100 286 583 minecraft:black_concrete
fill 100 280 584 105 284 584 minecraft:end_stone
fill 101 280 578 101 285 580 minecraft:end_stone
fill 101 280 581 101 285 581 minecraft:black_concrete
fill 101 280 582 106 284 583 minecraft:end_stone
fill 102 280 558 104 280 566 minecraft:end_stone
fill 102 280 567 104 285 567 minecraft:black_concrete
fill 102 280 568 102 285 574 minecraft:end_stone
fill 102 280 578 102 285 579 minecraft:end_stone
fill 102 280 580 102 285 580 minecraft:black_concrete
fill 102 280 581 107 283 581 minecraft:end_stone
fill 103 280 568 107 283 572 minecraft:end_stone
fill 103 280 573 104 284 573 minecraft:black_concrete
fill 103 280 574 112 281 574 minecraft:end_stone
fill 103 280 578 104 284 578 minecraft:end_stone
fill 103 280 579 103 285 579 minecraft:black_concrete
fill 103 280 580 108 283 580 minecraft:end_stone
fill 104 280 579 111 282 579 minecraft:end_stone
fill 104 280 585 104 285 588 minecraft:end_stone
fill 104 280 589 104 286 593 minecraft:black_concrete
fill 104 280 594 110 280 598 minecraft:end_stone
fill 105 280 558 113 280 560 minecraft:end_stone
fill 105 280 561 106 286 561 minecraft:black_concrete
fill 105 280 562 107 285 567 minecraft:end_stone
fill 105 280 573 110 282 573 minecraft:end_stone
fill 105 280 578 105 284 578 minecraft:black_concrete
fill 105 280 585 117 282 585 minecraft:end_stone
fill 105 280 586 105 285 586 minecraft:black_concrete
fill 105 280 587 109 284 593 minecraft:end_stone
fill 106 280 578 111 282 578 minecraft:end_stone
fill 106 280 584 106 284 584 minecraft:black_concrete
fill 106 280 586 124 283 586 minecraft:end_stone
fill 107 280 561 116 285 561 minecraft:end_stone
fill 107 280 582 107 283 582 minecraft:black_concrete
fill 107 280 583 136 281 584 minecraft:end_stone
fill 108 280 562 109 286 562 minecraft:black_concrete
fill 108 280 563 111 284 567 minecraft:end_stone
fill 108 280 568 109 284 568 minecraft:black_concrete
fill 108 280 569 110 282 572 minecraft:end_stone
fill 108 280 581 108 283 581 minecraft:black_concrete
fill 108 280 582 114 281 582 minecraft:end_stone
fill 109 280 557 109 307 557 minecraft:black_concrete
fill 109 280 580 109 282 580 minecraft:black_concrete
fill 109 280 581 113 281 581 minecraft:end_stone
fill 110 280 562 129 285 562 minecraft:end_stone
fill 110 280 568 128 283 568 minecraft:end_stone
fill 110 280 576 110 282 576 minecraft:black_concrete
fill 110 280 580 112 281 580 minecraft:end_stone
fill 110 280 587 110 284 591 minecraft:black_concrete
fill 110 280 592 116 285 593 minecraft:end_stone
fill 111 280 557 112 286 557 minecraft:end_stone
fill 111 280 569 111 283 569 minecraft:black_concrete
fill 111 280 570 114 281 572 minecraft:end_stone
fill 111 280 573 111 282 573 minecraft:black_concrete
fill 111 280 576 111 282 576 minecraft:end_stone
fill 111 280 587 114 283 591 minecraft:end_stone
fill 111 280 594 111 286 595 minecraft:black_concrete
fill 111 280 596 111 280 598 minecraft:end_stone
fill 112 280 563 117 284 563 minecraft:end_stone
fill 112 280 564 112 284 564 minecraft:black_concrete
fill 112 280 565 112 283 567 minecraft:end_stone
fill 112 280 569 115 282 569 minecraft:end_stone
fill 112 280 573 113 281 573 minecraft:end_stone
fill 112 280 575 113 281 579 minecraft:light_gray_concrete
fill 112 280 594 117 286 596 minecraft:end_stone
fill 112 280 597 112 286 597 minecraft:black_concrete
fill 112 280 598 116 280 598 minecraft:end_stone
fill 113 280 557 113 307 557 minecraft:black_concrete
fill 113 280 564 123 284 564 minecraft:end_stone
fill 113 280 565 113 284 565 minecraft:black_concrete
fill 113 280 566 113 283 567 minecraft:end_stone
fill 113 280 574 115 281 574 minecraft:light_gray_concrete
fill 113 280 580 115 281 580 minecraft:light_gray_concrete
fill 113 280 597 120 286 597 minecraft:end_stone
fill 114 280 557 121 286 557 minecraft:end_stone
fill 114 280 558 114 286 558 minecraft:black_concrete
fill 114 280 559 114 286 560 minecraft:end_stone
fill 114 280 565 118 284 565 minecraft:end_stone
fill 114 280 566 114 284 566 minecraft:black_concrete
fill 114 280 567 114 283 567 minecraft:end_stone
fill 114 280 573 120 281 573 minecraft:light_gray_concrete
fill 114 280 575 114 281 575 minecraft:light_gray_concrete
fill 114 280 576 114 280 578 minecraft:pearlescent_froglight
fill 114 280 579 114 281 579 minecraft:light_gray_concrete
fill 114 280 581 120 281 581 minecraft:light_gray_concrete
fill 115 280 558 135 280 558 minecraft:end_stone
fill 115 280 559 115 286 559 minecraft:black_concrete
fill 115 280 560 115 286 560 minecraft:end_stone
fill 115 280 566 118 283 566 minecraft:end_stone
fill 115 280 567 115 283 567 minecraft:black_concrete
fill 115 280 570 127 281 571 minecraft:end_stone
fill 115 280 572 119 281 572 minecraft:light_gray_concrete
fill 115 280 575 115 280 576 minecraft:pearlescent_froglight
fill 115 280 578 115 280 579 minecraft:pearlescent_froglight
fill 115 280 582 119 281 582 minecraft:light_gray_concrete
fill 115 280 587 118 283 587 minecraft:end_stone
fill 115 280 588 115 283 589 minecraft:black_concrete
fill 115 280 590 115 284 591 minecraft:end_stone
fill 116 280 559 122 286 559 minecraft:end_stone
fill 116 280 560 116 286 560 minecraft:black_concrete
fill 116 280 567 123 283 567 minecraft:end_stone
fill 116 280 569 116 282 569 minecraft:black_concrete
fill 116 280 574 116 280 575 minecraft:pearlescent_froglight
fill 116 280 579 116 280 580 minecraft:pearlescent_froglight
fill 116 280 588 119 283 590 minecraft:end_stone
fill 116 280 591 116 285 591 minecraft:black_concrete
fill 117 280 560 122 286 560 minecraft:end_stone
fill 117 280 561 117 285 561 minecraft:black_concrete
fill 117 280 569 136 282 569 minecraft:end_stone
fill 117 280 574 118 280 574 minecraft:pearlescent_froglight
fill 117 280 580 118 280 580 minecraft:pearlescent_froglight
fill 117 280 591 124 284 592 minecraft:end_stone
fill 117 280 593 117 285 593 minecraft:black_concrete
fill 118 280 561 129 285 561 minecraft:end_stone
fill 118 280 563 118 285 563 minecraft:black_concrete
fill 118 280 575 119 280 575 minecraft:pearlescent_froglight
fill 118 280 579 119 280 579 minecraft:pearlescent_froglight
fill 118 280 585 118 282 585 minecraft:black_concrete
fill 118 280 593 127 285 593 minecraft:end_stone
fill 118 280 594 118 286 594 minecraft:black_concrete
fill 118 280 595 118 286 596 minecraft:end_stone
fill 118 280 598 135 280 598 minecraft:end_stone
fill 119 280 563 123 285 563 minecraft:end_stone
fill 119 280 565 119 283 566 minecraft:black_concrete
fill 119 280 574 121 281 574 minecraft:light_gray_concrete
fill 119 280 576 120 280 576 minecraft:pearlescent_froglight
fill 119 280 578 120 280 578 minecraft:pearlescent_froglight
fill 119 280 580 121 281 580 minecraft:light_gray_concrete
fill 119 280 585 122 282 585 minecraft:end_stone
fill 119 280 587 119 283 587 minecraft:black_concrete
fill 119 280 594 135 280 594 minecraft:end_stone
fill 119 280 595 119 286 595 minecraft:black_concrete
fill 119 280 596 119 286 596 minecraft:end_stone
fill 120 280 565 123 284 566 minecraft:end_stone
fill 120 280 572 126 281 572 minecraft:end_stone
fill 120 280 575 122 281 575 minecraft:light_gray_concrete
setblock 120 280 577 minecraft:pearlescent_froglight
fill 120 280 579 122 281 579 minecraft:light_gray_concrete
fill 120 280 582 136 281 582 minecraft:end_stone
fill 120 280 587 129 283 587 minecraft:end_stone
fill 120 280 588 120 284 588 minecraft:black_concrete
fill 120 280 589 120 284 590 minecraft:end_stone
fill 120 280 595 135 280 595 minecraft:end_stone
fill 120 280 596 120 286 596 minecraft:black_concrete
fill 121 280 573 125 281 573 minecraft:end_stone
fill 121 280 576 122 281 578 minecraft:light_gray_concrete
fill 121 280 581 122 281 581 minecraft:end_stone
fill 121 280 588 135 280 588 minecraft:end_stone
fill 121 280 589 121 284 589 minecraft:black_concrete
fill 121 280 590 121 284 590 minecraft:end_stone
fill 121 280 596 135 280 596 minecraft:end_stone
fill 121 280 597 121 286 597 minecraft:black_concrete
fill 122 280 557 122 307 557 minecraft:black_concrete
fill 122 280 574 124 281 574 minecraft:end_stone
fill 122 280 580 132 281 580 minecraft:end_stone
fill 122 280 589 135 280 589 minecraft:end_stone
fill 122 280 590 122 284 590 minecraft:black_concrete
fill 122 280 597 135 280 597 minecraft:end_stone
fill 123 280 557 123 286 557 minecraft:end_stone
fill 123 280 559 123 286 560 minecraft:black_concrete
fill 123 280 575 123 281 579 minecraft:end_stone
fill 123 280 581 123 282 581 minecraft:black_concrete
fill 123 280 585 123 283 585 minecraft:black_concrete
fill 123 280 590 135 280 590 minecraft:end_stone
fill 124 280 559 135 280 560 minecraft:end_stone
fill 124 280 563 124 284 567 minecraft:black_concrete
fill 124 280 575 128 282 577 minecraft:end_stone
fill 124 280 578 124 282 578 minecraft:black_concrete
fill 124 280 579 134 282 579 minecraft:end_stone
fill 124 280 581 129 282 581 minecraft:end_stone
fill 124 280 585 136 283 585 minecraft:end_stone
fill 125 280 563 129 284 567 minecraft:end_stone
fill 125 280 574 125 282 574 minecraft:black_concrete
fill 125 280 578 136 282 578 minecraft:end_stone
fill 125 280 586 126 284 586 minecraft:black_concrete
fill 125 280 591 135 280 591 minecraft:end_stone
fill 125 280 592 126 286 592 minecraft:black_concrete
fill 126 280 573 126 283 573 minecraft:black_concrete
fill 126 280 574 131 283 574 minecraft:end_stone
fill 127 280 557 127 307 557 minecraft:black_concrete
fill 127 280 572 127 283 572 minecraft:black_concrete
fill 127 280 573 132 283 573 minecraft:end_stone
fill 127 280 586 135 284 586 minecraft:end_stone
fill 127 280 592 135 280 592 minecraft:end_stone
setblock 128 280 557 minecraft:pearlescent_froglight
fill 128 280 570 128 284 570 minecraft:black_concrete
fill 128 280 571 133 284 572 minecraft:end_stone
fill 128 280 593 129 286 593 minecraft:black_concrete
fill 129 280 568 129 285 568 minecraft:black_concrete
fill 129 280 570 134 284 570 minecraft:end_stone
fill 129 280 575 130 284 575 minecraft:end_stone
fill 129 280 576 129 284 576 minecraft:black_concrete
fill 129 280 577 136 284 577 minecraft:end_stone
fill 130 280 561 130 286 565 minecraft:black_concrete
fill 130 280 566 135 280 568 minecraft:end_stone
fill 130 280 576 136 284 576 minecraft:end_stone
fill 130 280 581 131 284 581 minecraft:black_concrete
fill 130 280 587 132 285 587 minecraft:black_concrete
fill 130 280 593 135 280 593 minecraft:end_stone
fill 131 280 561 135 280 565 minecraft:end_stone
fill 131 280 575 131 285 575 minecraft:black_concrete
fill 132 280 574 132 285 574 minecraft:black_concrete
fill 132 280 575 136 285 575 minecraft:end_stone
fill 132 280 581 136 285 581 minecraft:end_stone
fill 133 280 573 133 285 573 minecraft:black_concrete
fill 133 280 574 136 285 574 minecraft:end_stone
fill 133 280 580 134 285 580 minecraft:black_concrete
fill 133 280 587 135 286 587 minecraft:end_stone
fill 134 280 571 134 286 571 minecraft:black_concrete
fill 134 280 572 136 286 573 minecraft:end_stone
fill 135 280 570 135 286 570 minecraft:black_concrete
fill 135 280 571 136 286 571 minecraft:end_stone
fill 135 280 579 135 286 579 minecraft:black_concrete
fill 135 280 580 136 286 580 minecraft:end_stone
setblock 136 280 566 minecraft:white_stained_glass
fill 136 280 570 136 286 570 minecraft:end_stone
fill 136 280 579 136 286 579 minecraft:end_stone
setblock 94 281 595 minecraft:pearlescent_froglight
fill 94 281 596 94 307 596 minecraft:black_concrete
fill 97 281 571 98 286 575 minecraft:end_stone
fill 97 281 578 98 286 583 minecraft:end_stone
fill 98 281 569 101 286 570 minecraft:end_stone
fill 98 281 584 98 286 585 minecraft:end_stone
fill 99 281 557 99 289 557 minecraft:black_concrete
fill 99 281 567 101 286 568 minecraft:end_stone
fill 99 281 571 99 286 574 minecraft:end_stone
fill 99 281 585 103 285 587 minecraft:end_stone
fill 100 281 565 104 286 566 minecraft:end_stone
fill 100 281 571 101 285 573 minecraft:end_stone
fill 100 281 588 103 286 589 minecraft:end_stone
fill 101 281 564 104 286 564 minecraft:end_stone
fill 101 281 590 103 286 590 minecraft:end_stone
fill 102 281 563 104 286 563 minecraft:end_stone
fill 102 281 591 103 286 591 minecraft:end_stone
fill 103 281 562 104 286 562 minecraft:end_stone
fill 103 281 592 103 286 592 minecraft:end_stone
fill 104 281 561 104 286 561 minecraft:end_stone
fill 105 281 560 113 286 560 minecraft:end_stone
fill 105 281 594 110 286 594 minecraft:end_stone
fill 107 281 559 113 286 559 minecraft:end_stone
fill 107 281 595 110 286 595 minecraft:end_stone
fill 109 281 558 113 286 558 minecraft:end_stone
fill 109 281 596 111 286 596 minecraft:end_stone
fill 111 281 597 111 286 597 minecraft:end_stone
fill 115 281 558 125 286 558 minecraft:end_stone
fill 119 281 594 129 286 594 minecraft:end_stone
fill 120 281 595 127 286 595 minecraft:end_stone
fill 121 281 588 134 284 588 minecraft:end_stone
fill 121 281 596 125 286 596 minecraft:end_stone
fill 122 281 589 134 284 589 minecraft:end_stone
fill 122 281 597 123 286 597 minecraft:end_stone
setblock 122 281 599 minecraft:pearlescent_froglight
fill 123 281 590 133 285 590 minecraft:end_stone
fill 124 281 559 127 286 560 minecraft:end_stone
setblock 124 281 599 minecraft:pearlescent_froglight
fill 125 281 591 132 285 591 minecraft:end_stone
fill 127 281 592 131 286 592 minecraft:end_stone
fill 128 281 557 128 305 557 minecraft:black_concrete
fill 128 281 560 129 286 560 minecraft:end_stone
fill 130 281 566 134 285 568 minecraft:end_stone
fill 130 281 593 130 286 593 minecraft:end_stone
fill 131 281 562 131 286 565 minecraft:end_stone
fill 132 281 563 132 286 565 minecraft:end_stone
fill 133 281 564 133 286 565 minecraft:end_stone
fill 134 281 565 134 286 565 minecraft:end_stone
fill 135 281 567 135 286 568 minecraft:end_stone
setblock 136 281 564 minecraft:pearlescent_froglight
fill 136 281 566 136 304 566 minecraft:black_concrete
fill 94 282 595 94 307 595 minecraft:black_concrete
setblock 95 282 557 minecraft:white_concrete
setblock 97 282 560 minecraft:light[level=14]
setblock 97 282 568 minecraft:light[level=14]
fill 97 282 577 110 282 577 minecraft:end_stone
setblock 97 282 584 minecraft:light[level=14]
setblock 97 282 592 minecraft:light[level=14]
fill 103 282 574 111 282 574 minecraft:end_stone
fill 107 282 583 116 282 584 minecraft:end_stone
fill 108 282 582 113 282 582 minecraft:end_stone
fill 109 282 581 112 282 581 minecraft:end_stone
fill 110 282 580 111 282 580 minecraft:end_stone
fill 111 282 570 113 282 572 minecraft:end_stone
setblock 112 282 573 minecraft:end_stone
setblock 113 282 576 minecraft:light[level=14]
fill 114 282 570 116 282 571 minecraft:end_stone
fill 117 282 570 127 282 570 minecraft:end_stone
fill 117 282 584 136 282 584 minecraft:end_stone
fill 118 282 571 127 282 571 minecraft:end_stone
fill 118 282 583 136 282 583 minecraft:end_stone
fill 121 282 572 126 282 572 minecraft:end_stone
setblock 121 282 576 minecraft:light[level=14]
fill 121 282 582 136 282 582 minecraft:end_stone
fill 122 282 573 125 282 573 minecraft:end_stone
setblock 122 282 581 minecraft:end_stone
fill 122 282 599 122 287 599 minecraft:black_concrete
fill 123 282 574 123 282 576 minecraft:end_stone
fill 123 282 578 123 282 580 minecraft:end_stone
setblock 124 282 574 minecraft:end_stone
fill 124 282 580 132 282 580 minecraft:end_stone
fill 124 282 599 124 287 599 minecraft:black_concrete
setblock 127 282 599 minecraft:white_stained_glass
fill 136 282 564 136 307 564 minecraft:black_concrete
fill 95 283 557 95 287 557 minecraft:black_concrete
fill 97 283 577 108 283 577 minecraft:end_stone
fill 98 283 576 108 283 576 minecraft:end_stone
fill 100 283 575 108 283 575 minecraft:end_stone
fill 103 283 574 108 283 574 minecraft:end_stone
fill 104 283 579 108 283 579 minecraft:end_stone
fill 105 283 573 109 283 573 minecraft:end_stone
fill 105 283 585 113 283 585 minecraft:end_stone
fill 106 283 578 108 283 578 minecraft:end_stone
fill 106 283 599 106 307 599 minecraft:black_concrete
fill 107 283 583 110 283 584 minecraft:end_stone
setblock 107 283 599 minecraft:pearlescent_froglight
fill 108 283 569 109 283 572 minecraft:end_stone
fill 108 283 582 109 283 582 minecraft:end_stone
setblock 109 283 581 minecraft:end_stone
fill 110 283 569 110 283 571 minecraft:end_stone
setblock 111 283 570 minecraft:end_stone
setblock 111 283 584 minecraft:end_stone
fill 112 283 569 113 283 569 minecraft:end_stone
fill 121 283 569 136 283 569 minecraft:end_stone
fill 121 283 585 122 283 585 minecraft:end_stone
fill 123 283 570 127 283 570 minecraft:end_stone
fill 123 283 584 136 283 584 minecraft:end_stone
fill 124 283 571 127 283 571 minecraft:end_stone
fill 124 283 583 136 283 583 minecraft:end_stone
fill 125 283 572 125 283 573 minecraft:end_stone
fill 125 283 581 129 283 582 minecraft:end_stone
setblock 126 283 572 minecraft:end_stone
fill 126 283 575 128 283 580 minecraft:end_stone
fill 127 283 599 127 307 599 minecraft:black_concrete
fill 129 283 578 132 284 580 minecraft:end_stone
fill 130 283 582 136 284 582 minecraft:end_stone
fill 133 283 578 134 285 579 minecraft:end_stone
fill 135 283 578 136 286 578 minecraft:end_stone
setblock 94 284 578 minecraft:white_stained_glass
setblock 94 284 580 minecraft:pearlescent_froglight
setblock 94 284 587 minecraft:white_concrete
fill 97 284 577 105 284 577 minecraft:end_stone
fill 98 284 576 105 284 576 minecraft:end_stone
fill 100 284 575 105 284 575 minecraft:end_stone
fill 102 284 581 106 284 581 minecraft:end_stone
fill 103 284 568 106 284 572 minecraft:end_stone
fill 103 284 574 106 284 574 minecraft:end_stone
fill 103 284 580 106 284 580 minecraft:end_stone
fill 104 284 579 105 284 579 minecraft:end_stone
fill 105 284 573 106 284 573 minecraft:end_stone
fill 105 284 585 108 284 585 minecraft:end_stone
fill 106 284 586 110 284 586 minecraft:end_stone
fill 107 284 568 107 284 571 minecraft:end_stone
fill 107 284 583 107 284 584 minecraft:end_stone
fill 107 284 599 107 307 599 minecraft:black_concrete
fill 108 284 569 108 284 570 minecraft:end_stone
setblock 108 284 584 minecraft:end_stone
setblock 110 284 568 minecraft:end_stone
fill 111 284 587 111 284 591 minecraft:end_stone
fill 112 284 565 112 284 566 minecraft:end_stone
fill 112 284 588 114 284 591 minecraft:end_stone
setblock 113 284 566 minecraft:end_stone
setblock 115 284 589 minecraft:black_concrete
fill 116 284 589 119 284 590 minecraft:end_stone
setblock 119 284 565 minecraft:black_concrete
fill 121 284 573 123 284 573 minecraft:end_stone
setblock 122 284 574 minecraft:end_stone
setblock 123 284 567 minecraft:end_stone
fill 123 284 587 129 284 587 minecraft:end_stone
fill 124 284 568 128 284 568 minecraft:end_stone
setblock 124 284 586 minecraft:end_stone
fill 126 284 569 127 284 570 minecraft:end_stone
fill 126 284 584 136 284 585 minecraft:end_stone
setblock 127 284 571 minecraft:end_stone
fill 127 284 583 136 284 583 minecraft:end_stone
fill 128 284 569 136 284 569 minecraft:end_stone
fill 128 284 573 131 284 574 minecraft:end_stone
fill 128 284 580 128 284 582 minecraft:end_stone
fill 129 284 581 129 284 582 minecraft:end_stone
fill 132 284 573 132 285 573 minecraft:end_stone
setblock 94 285 578 minecraft:black_concrete
fill 94 285 580 94 307 580 minecraft:black_concrete
fill 94 285 587 94 307 587 minecraft:black_concrete
fill 97 285 577 102 285 577 minecraft:end_stone
fill 98 285 576 103 285 576 minecraft:end_stone
fill 100 285 575 103 285 575 minecraft:end_stone
fill 100 285 584 104 285 584 minecraft:end_stone
fill 101 285 582 103 285 583 minecraft:end_stone
fill 102 285 581 103 285 581 minecraft:end_stone
fill 103 285 568 103 285 572 minecraft:end_stone
setblock 103 285 573 minecraft:black_concrete
setblock 103 285 574 minecraft:end_stone
setblock 103 285 578 minecraft:end_stone
setblock 103 285 580 minecraft:end_stone
setblock 104 285 557 minecraft:white_stained_glass
fill 104 285 568 104 285 571 minecraft:end_stone
setblock 104 285 583 minecraft:end_stone
fill 105 285 557 105 307 557 minecraft:black_concrete
fill 105 285 568 105 285 569 minecraft:end_stone
setblock 105 285 585 minecraft:end_stone
fill 105 285 587 107 285 593 minecraft:end_stone
setblock 106 285 568 minecraft:end_stone
setblock 106 285 586 minecraft:end_stone
fill 108 285 563 108 285 566 minecraft:end_stone
fill 108 285 588 108 285 593 minecraft:end_stone
fill 109 285 563 109 285 565 minecraft:end_stone
fill 109 285 589 109 285 593 minecraft:end_stone
fill 110 285 563 111 285 564 minecraft:end_stone
fill 110 285 590 110 285 591 minecraft:black_concrete
fill 111 285 590 111 285 591 minecraft:end_stone
fill 112 285 563 116 285 563 minecraft:end_stone
fill 112 285 591 115 285 591 minecraft:end_stone
fill 117 285 592 124 285 592 minecraft:end_stone
fill 118 285 591 124 285 591 minecraft:end_stone
fill 120 285 566 121 286 567 minecraft:gray_concrete
setblock 123 285 564 minecraft:end_stone
fill 124 285 563 124 285 564 minecraft:black_concrete
fill 125 285 563 129 285 565 minecraft:end_stone
fill 125 285 589 134 285 589 minecraft:end_stone
fill 126 285 566 129 285 566 minecraft:end_stone
fill 126 285 588 134 285 588 minecraft:end_stone
fill 127 285 567 129 285 567 minecraft:end_stone
fill 127 285 587 129 285 587 minecraft:end_stone
setblock 128 285 568 minecraft:end_stone
fill 128 285 586 135 285 586 minecraft:end_stone
fill 129 285 569 136 285 569 minecraft:end_stone
fill 129 285 585 136 285 585 minecraft:end_stone
fill 130 285 570 133 285 571 minecraft:end_stone
fill 130 285 583 136 285 584 minecraft:end_stone
setblock 131 285 557 minecraft:white_concrete
fill 131 285 572 131 285 574 minecraft:end_stone
fill 131 285 576 136 285 576 minecraft:end_stone
fill 131 285 578 132 285 580 minecraft:end_stone
setblock 131 285 581 minecraft:black_concrete
fill 131 285 582 136 285 582 minecraft:end_stone
fill 132 285 557 133 307 557 minecraft:black_concrete
fill 132 285 572 133 285 572 minecraft:end_stone
fill 132 285 577 136 285 577 minecraft:end_stone
fill 134 285 570 134 286 570 minecraft:end_stone
setblock 94 286 578 minecraft:white_stained_glass
fill 97 286 577 100 286 577 minecraft:end_stone
fill 98 286 576 100 286 576 minecraft:end_stone
fill 99 286 585 102 286 587 minecraft:end_stone
fill 100 286 571 100 286 573 minecraft:end_stone
setblock 100 286 574 minecraft:black_concrete
setblock 100 286 575 minecraft:end_stone
fill 100 286 584 101 286 584 minecraft:end_stone
fill 101 286 571 101 286 572 minecraft:end_stone
fill 101 286 582 101 286 583 minecraft:end_stone
fill 102 286 567 103 286 567 minecraft:black_concrete
fill 102 286 568 102 286 569 minecraft:end_stone
fill 103 286 573 103 290 573 minecraft:gray_concrete
setblock 103 286 587 minecraft:end_stone
fill 104 286 557 104 289 557 minecraft:black_concrete
setblock 104 286 588 minecraft:end_stone
fill 105 286 562 105 286 565 minecraft:end_stone
fill 105 286 589 105 286 593 minecraft:end_stone
fill 106 286 562 106 286 564 minecraft:end_stone
fill 106 286 590 106 286 593 minecraft:end_stone
fill 107 286 561 107 286 563 minecraft:end_stone
fill 107 286 591 107 286 593 minecraft:end_stone
fill 108 286 561 112 286 561 minecraft:end_stone
fill 108 286 592 109 286 593 minecraft:end_stone
fill 110 286 593 112 286 593 minecraft:end_stone
fill 122 286 561 129 286 561 minecraft:end_stone
fill 122 286 593 127 286 593 minecraft:end_stone
fill 125 286 562 129 286 562 minecraft:end_stone
fill 126 286 569 128 287 569 minecraft:light_gray_concrete
fill 127 286 563 129 286 563 minecraft:end_stone
fill 127 286 570 128 287 570 minecraft:light_gray_concrete
fill 127 286 591 132 286 591 minecraft:end_stone
fill 128 286 564 129 286 564 minecraft:end_stone
fill 128 286 590 133 286 590 minecraft:end_stone
setblock 129 286 565 minecraft:end_stone
fill 129 286 589 134 286 589 minecraft:end_stone
fill 130 286 566 134 286 566 minecraft:end_stone
fill 130 286 588 134 286 588 minecraft:end_stone
fill 131 286 557 131 296 557 minecraft:black_concrete
fill 131 286 567 134 286 567 minecraft:end_stone
fill 131 286 587 132 286 587 minecraft:black_concrete
fill 132 286 568 134 286 569 minecraft:end_stone
fill 132 286 585 135 286 586 minecraft:end_stone
fill 133 286 570 133 286 572 minecraft:end_stone
fill 133 286 582 136 286 584 minecraft:end_stone
fill 134 286 574 134 286 579 minecraft:end_stone
setblock 134 286 580 minecraft:black_concrete
fill 134 286 581 136 286 581 minecraft:end_stone
fill 135 286 569 136 286 569 minecraft:end_stone
fill 135 286 574 136 286 577 minecraft:end_stone
setblock 136 286 585 minecraft:end_stone
fill 94 287 567 94 307 567 minecraft:black_concrete
setblock 94 287 568 minecraft:white_stained_glass
setblock 94 287 569 minecraft:white_concrete
fill 94 287 578 94 307 578 minecraft:black_concrete
setblock 94 287 591 minecraft:white_stained_glass
fill 94 287 592 94 307 592 minecraft:black_concrete
setblock 94 287 594 minecraft:white_stained_glass
setblock 100 287 557 minecraft:white_stained_glass
fill 102 287 573 102 290 573 minecraft:gray_concrete
fill 103 287 572 103 290 572 minecraft:gray_concrete
fill 103 287 574 103 290 574 minecraft:gray_concrete
fill 104 287 573 104 290 573 minecraft:gray_concrete
fill 111 287 557 112 305 557 minecraft:black_concrete
fill 114 287 557 121 287 557 minecraft:black_concrete
fill 123 287 557 123 307 557 minecraft:black_concrete
setblock 123 287 599 minecraft:pearlescent_froglight
fill 136 287 569 136 303 570 minecraft:black_concrete
setblock 136 287 571 minecraft:white_concrete
fill 136 287 572 136 287 585 minecraft:black_concrete
setblock 136 287 589 minecraft:white_concrete
setblock 136 287 594 minecraft:white_concrete
fill 94 288 565 94 290 565 minecraft:light_gray_concrete
fill 94 288 568 94 288 569 minecraft:black_concrete
fill 94 288 581 94 290 581 minecraft:light_gray_concrete
fill 94 288 591 94 307 591 minecraft:black_concrete
fill 94 288 594 94 307 594 minecraft:black_concrete
fill 94 288 597 94 290 597 minecraft:light_gray_concrete
setblock 95 288 557 minecraft:white_concrete
fill 98 288 557 98 290 557 minecraft:light_gray_concrete
fill 98 288 599 98 289 599 minecraft:white_concrete
fill 100 288 557 100 307 557 minecraft:black_concrete
fill 102 288 572 102 290 572 minecraft:gray_concrete
fill 102 288 574 102 290 574 minecraft:gray_concrete
fill 104 288 572 104 290 572 minecraft:gray_concrete
fill 104 288 574 104 290 574 minecraft:gray_concrete
fill 106 288 583 106 289 583 minecraft:gray_concrete
fill 108 288 599 108 290 599 minecraft:light_gray_concrete
fill 114 288 557 114 290 557 minecraft:light_gray_concrete
fill 115 288 557 121 289 557 minecraft:black_concrete
setblock 122 288 599 minecraft:white_concrete
fill 123 288 599 123 307 599 minecraft:black_concrete
fill 124 288 599 124 290 599 minecraft:light_gray_concrete
fill 130 288 557 130 290 557 minecraft:light_gray_concrete
setblock 135 288 599 minecraft:pearlescent_froglight
fill 136 288 567 136 290 567 minecraft:light_gray_concrete
fill 136 288 571 136 290 582 minecraft:black_concrete
fill 136 288 583 136 290 583 minecraft:light_gray_concrete
fill 136 288 584 136 299 585 minecraft:black_concrete
fill 136 288 589 136 307 589 minecraft:black_concrete
fill 136 288 594 136 306 594 minecraft:black_concrete
setblock 94 289 568 minecraft:pearlescent_froglight
fill 94 289 569 94 307 569 minecraft:black_concrete
fill 95 289 557 95 307 557 minecraft:black_concrete
fill 101 289 572 101 290 573 minecraft:gray_concrete
fill 103 289 571 103 290 571 minecraft:gray_concrete
fill 103 289 575 103 290 575 minecraft:gray_concrete
fill 105 289 573 105 290 573 minecraft:gray_concrete
setblock 109 289 599 minecraft:white_concrete
fill 122 289 599 122 307 599 minecraft:black_concrete
fill 135 289 599 135 294 599 minecraft:black_concrete
fill 94 290 568 94 307 568 minecraft:black_concrete
setblock 94 290 573 minecraft:pearlescent_froglight
setblock 97 290 560 minecraft:light[level=14]
setblock 97 290 568 minecraft:light[level=14]
setblock 97 290 576 minecraft:light[level=14]
setblock 97 290 584 minecraft:light[level=14]
setblock 97 290 592 minecraft:light[level=14]
fill 98 290 599 98 307 599 minecraft:black_concrete
setblock 99 290 557 minecraft:white_concrete
setblock 101 290 574 minecraft:gray_concrete
setblock 102 290 571 minecraft:gray_concrete
setblock 102 290 575 minecraft:gray_concrete
setblock 104 290 557 minecraft:white_concrete
setblock 104 290 571 minecraft:gray_concrete
setblock 104 290 575 minecraft:gray_concrete
setblock 105 290 560 minecraft:light[level=14]
setblock 105 290 568 minecraft:light[level=14]
setblock 105 290 572 minecraft:gray_concrete
setblock 105 290 574 minecraft:gray_concrete
setblock 105 290 576 minecraft:light[level=14]
setblock 105 290 584 minecraft:light[level=14]
setblock 105 290 592 minecraft:light[level=14]
fill 109 290 599 109 307 599 minecraft:black_concrete
setblock 113 290 560 minecraft:light[level=14]
setblock 113 290 568 minecraft:light[level=14]
setblock 113 290 576 minecraft:light[level=14]
setblock 113 290 584 minecraft:light[level=14]
setblock 113 290 592 minecraft:light[level=14]
fill 115 290 557 120 305 557 minecraft:black_concrete
setblock 121 290 557 minecraft:white_stained_glass
setblock 121 290 560 minecraft:light[level=14]
setblock 121 290 568 minecraft:light[level=14]
setblock 121 290 576 minecraft:light[level=14]
setblock 121 290 584 minecraft:light[level=14]
setblock 121 290 592 minecraft:light[level=14]
setblock 129 290 560 minecraft:light[level=14]
setblock 129 290 568 minecraft:light[level=14]
setblock 129 290 576 minecraft:light[level=14]
setblock 129 290 584 minecraft:light[level=14]
setblock 129 290 592 minecraft:light[level=14]
fill 94 291 565 94 294 565 minecraft:black_concrete
fill 94 291 573 94 300 573 minecraft:black_concrete
setblock 94 291 576 minecraft:white_stained_glass
setblock 94 291 581 minecraft:black_concrete
fill 94 291 597 94 296 597 minecraft:black_concrete
fill 98 291 557 99 296 557 minecraft:black_concrete
fill 101 291 572 101 294 572 minecraft:end_stone
fill 103 291 575 103 295 575 minecraft:end_stone
fill 104 291 557 104 297 557 minecraft:black_concrete
fill 104 291 572 104 294 572 minecraft:end_stone
fill 108 291 599 108 296 599 minecraft:black_concrete
fill 114 291 557 114 296 557 minecraft:black_concrete
fill 121 291 557 121 307 557 minecraft:black_concrete
fill 124 291 599 124 296 599 minecraft:black_concrete
fill 126 291 589 126 292 589 minecraft:gray_concrete
fill 130 291 557 130 296 557 minecraft:black_concrete
setblock 136 291 561 minecraft:white_stained_glass
fill 136 291 567 136 296 567 minecraft:black_concrete
fill 136 291 571 136 297 579 minecraft:black_concrete
setblock 136 291 580 minecraft:white_concrete
fill 136 291 581 136 296 583 minecraft:black_concrete
setblock 94 292 571 minecraft:white_stained_glass
fill 94 292 576 94 307 576 minecraft:black_concrete
setblock 94 292 581 minecraft:pearlescent_froglight
setblock 97 292 557 minecraft:pearlescent_froglight
setblock 120 292 599 minecraft:white_concrete
fill 136 292 561 136 307 561 minecraft:black_concrete
setblock 136 292 580 minecraft:black_concrete
fill 94 293 571 94 307 571 minecraft:black_concrete
fill 94 293 581 94 296 581 minecraft:black_concrete
fill 97 293 557 97 307 557 minecraft:black_concrete
setblock 103 293 599 minecraft:white_concrete
fill 104 293 599 104 307 599 minecraft:black_concrete
fill 110 293 588 112 294 588 minecraft:gray_concrete
fill 111 293 587 111 294 587 minecraft:gray_concrete
fill 111 293 589 111 294 589 minecraft:gray_concrete
fill 120 293 599 120 307 599 minecraft:black_concrete
setblock 133 293 599 minecraft:white_concrete
setblock 134 293 557 minecraft:white_stained_glass
setblock 136 293 580 minecraft:white_concrete
fill 103 294 599 103 307 599 minecraft:black_concrete
fill 108 294 593 110 295 593 minecraft:gray_concrete
fill 109 294 592 109 295 592 minecraft:gray_concrete
fill 109 294 594 109 295 594 minecraft:gray_concrete
setblock 110 294 557 minecraft:white_concrete
fill 133 294 599 133 307 599 minecraft:black_concrete
fill 134 294 557 134 307 557 minecraft:black_concrete
setblock 136 294 558 minecraft:pearlescent_froglight
fill 136 294 559 136 307 559 minecraft:black_concrete
fill 136 294 580 136 307 580 minecraft:black_concrete
setblock 94 295 565 minecraft:pearlescent_froglight
setblock 94 295 585 minecraft:white_stained_glass
setblock 110 295 557 minecraft:black_concrete
setblock 115 295 599 minecraft:pearlescent_froglight
setblock 124 295 557 minecraft:white_concrete
setblock 135 295 599 minecraft:white_concrete
fill 136 295 558 136 307 558 minecraft:black_concrete
setblock 94 296 563 minecraft:white_stained_glass
setblock 94 296 565 minecraft:black_concrete
fill 94 296 585 94 307 585 minecraft:black_concrete
setblock 94 296 593 minecraft:white_concrete
setblock 110 296 557 minecraft:white_concrete
fill 115 296 599 115 297 599 minecraft:black_concrete
fill 124 296 557 124 307 557 minecraft:black_concrete
fill 135 296 599 135 307 599 minecraft:black_concrete
fill 94 297 558 94 307 559 minecraft:black_concrete
setblock 94 297 560 minecraft:white_concrete
fill 94 297 561 94 306 563 minecraft:black_concrete
fill 94 297 565 94 299 565 minecraft:light_gray_concrete
fill 94 297 581 94 299 581 minecraft:light_gray_concrete
setblock 94 297 586 minecraft:white_concrete
fill 94 297 593 94 307 593 minecraft:black_concrete
fill 94 297 597 94 299 597 minecraft:light_gray_concrete
fill 98 297 557 98 299 557 minecraft:light_gray_concrete
fill 99 297 557 99 307 557 minecraft:black_concrete
setblock 103 297 557 minecraft:pearlescent_froglight
fill 108 297 599 108 299 599 minecraft:light_gray_concrete
fill 110 297 557 110 307 557 minecraft:black_concrete
fill 114 297 557 114 299 557 minecraft:light_gray_concrete
setblock 117 297 599 minecraft:white_concrete
fill 124 297 599 124 299 599 minecraft:light_gray_concrete
setblock 126 297 557 minecraft:white_concrete
setblock 129 297 557 minecraft:pearlescent_froglight
fill 130 297 557 130 299 557 minecraft:light_gray_concrete
setblock 131 297 557 minecraft:pearlescent_froglight
fill 136 297 567 136 299 567 minecraft:light_gray_concrete
fill 136 297 581 136 301 582 minecraft:black_concrete
fill 136 297 583 136 299 583 minecraft:light_gray_concrete
fill 94 298 560 94 304 560 minecraft:black_concrete
setblock 94 298 586 minecraft:black_concrete
setblock 97 298 560 minecraft:light[level=14]
setblock 97 298 568 minecraft:light[level=14]
setblock 97 298 576 minecraft:light[level=14]
setblock 97 298 584 minecraft:light[level=14]
setblock 97 298 592 minecraft:light[level=14]
fill 103 298 557 103 307 557 minecraft:black_concrete
setblock 104 298 557 minecraft:white_concrete
setblock 105 298 560 minecraft:light[level=14]
setblock 105 298 568 minecraft:light[level=14]
setblock 105 298 576 minecraft:light[level=14]
setblock 105 298 584 minecraft:light[level=14]
setblock 105 298 592 minecraft:light[level=14]
setblock 113 298 560 minecraft:light[level=14]
setblock 113 298 568 minecraft:light[level=14]
setblock 113 298 576 minecraft:light[level=14]
setblock 113 298 584 minecraft:light[level=14]
setblock 113 298 592 minecraft:light[level=14]
setblock 115 298 599 minecraft:pearlescent_froglight
fill 117 298 599 117 304 599 minecraft:black_concrete
setblock 121 298 560 minecraft:light[level=14]
setblock 121 298 568 minecraft:light[level=14]
setblock 121 298 576 minecraft:light[level=14]
setblock 121 298 584 minecraft:light[level=14]
setblock 121 298 592 minecraft:light[level=14]
fill 126 298 557 126 307 557 minecraft:black_concrete
setblock 129 298 557 minecraft:black_concrete
setblock 129 298 560 minecraft:light[level=14]
setblock 129 298 568 minecraft:light[level=14]
setblock 129 298 576 minecraft:light[level=14]
setblock 129 298 584 minecraft:light[level=14]
setblock 129 298 592 minecraft:light[level=14]
fill 131 298 557 131 307 557 minecraft:black_concrete
fill 136 298 571 136 305 573 minecraft:black_concrete
setblock 136 298 574 minecraft:white_concrete
fill 136 298 575 136 300 579 minecraft:black_concrete
setblock 94 299 586 minecraft:white_concrete
fill 104 299 557 104 302 557 minecraft:black_concrete
setblock 107 299 557 minecraft:white_stained_glass
fill 115 299 599 115 307 599 minecraft:black_concrete
setblock 129 299 557 minecraft:pearlescent_froglight
fill 136 299 574 136 307 574 minecraft:black_concrete
fill 94 300 565 94 307 565 minecraft:black_concrete
fill 94 300 581 94 307 581 minecraft:black_concrete
fill 94 300 586 94 307 586 minecraft:black_concrete
fill 94 300 597 94 306 597 minecraft:black_concrete
fill 98 300 557 98 307 557 minecraft:black_concrete
fill 107 300 557 107 307 557 minecraft:black_concrete
fill 108 300 599 108 307 599 minecraft:black_concrete
fill 114 300 557 114 307 557 minecraft:black_concrete
fill 124 300 599 124 307 599 minecraft:black_concrete
fill 129 300 557 130 307 557 minecraft:black_concrete
setblock 136 300 562 minecraft:white_concrete
fill 136 300 567 136 307 567 minecraft:black_concrete
fill 136 300 583 136 302 584 minecraft:black_concrete
setblock 136 300 585 minecraft:white_concrete
setblock 136 300 598 minecraft:white_concrete
setblock 94 301 573 minecraft:white_concrete
setblock 94 301 575 minecraft:pearlescent_froglight
fill 136 301 562 136 307 562 minecraft:black_concrete
fill 136 301 575 136 307 578 minecraft:black_concrete
setblock 136 301 579 minecraft:pearlescent_froglight
fill 136 301 585 136 304 585 minecraft:black_concrete
fill 136 301 598 136 307 598 minecraft:black_concrete
fill 94 302 573 94 307 573 minecraft:black_concrete
fill 94 302 575 94 307 575 minecraft:black_concrete
fill 118 302 599 118 307 599 minecraft:black_concrete
setblock 119 302 599 minecraft:white_stained_glass
fill 136 302 579 136 307 579 minecraft:black_concrete
fill 136 302 581 136 307 581 minecraft:black_concrete
setblock 136 302 582 minecraft:white_stained_glass
setblock 136 302 592 minecraft:white_stained_glass
setblock 104 303 557 minecraft:pearlescent_froglight
fill 110 303 599 110 305 599 minecraft:black_concrete
setblock 111 303 599 minecraft:white_stained_glass
fill 119 303 599 119 307 599 minecraft:black_concrete
fill 136 303 582 136 307 583 minecraft:black_concrete
setblock 136 303 584 minecraft:white_concrete
fill 136 303 592 136 305 592 minecraft:black_concrete
setblock 97 304 599 minecraft:white_concrete
fill 104 304 557 104 307 557 minecraft:black_concrete
fill 111 304 599 111 307 599 minecraft:black_concrete
setblock 136 304 569 minecraft:pearlescent_froglight
fill 136 304 570 136 306 570 minecraft:black_concrete
fill 136 304 584 136 307 584 minecraft:black_concrete
setblock 94 305 560 minecraft:white_stained_glass
setblock 94 305 588 minecraft:white_stained_glass
setblock 97 305 599 minecraft:black_concrete
setblock 114 305 599 minecraft:white_concrete
setblock 117 305 599 minecraft:white_stained_glass
setblock 136 305 566 minecraft:white_concrete
fill 136 305 569 136 307 569 minecraft:black_concrete
setblock 136 305 585 minecraft:white_stained_glass
fill 94 306 560 94 307 560 minecraft:black_concrete
fill 94 306 588 94 307 588 minecraft:black_concrete
setblock 97 306 599 minecraft:white_concrete
setblock 110 306 599 minecraft:pearlescent_froglight
fill 111 306 557 111 307 557 minecraft:black_concrete
setblock 112 306 557 minecraft:pearlescent_froglight
fill 114 306 599 114 307 599 minecraft:black_concrete
fill 115 306 557 119 307 557 minecraft:black_concrete
fill 117 306 599 117 307 599 minecraft:black_concrete
setblock 120 306 557 minecraft:white_concrete
fill 128 306 557 128 307 557 minecraft:white_concrete
setblock 136 306 560 minecraft:pearlescent_froglight
fill 136 306 566 136 307 566 minecraft:black_concrete
fill 136 306 571 136 307 571 minecraft:black_concrete
setblock 136 306 572 minecraft:pearlescent_froglight
fill 136 306 573 136 307 573 minecraft:black_concrete
fill 136 306 585 136 307 585 minecraft:black_concrete
setblock 136 306 592 minecraft:pearlescent_froglight
setblock 94 307 561 minecraft:black_concrete
setblock 94 307 562 minecraft:white_stained_glass
setblock 94 307 563 minecraft:black_concrete
setblock 94 307 597 minecraft:white_stained_glass
setblock 97 307 599 minecraft:black_concrete
setblock 108 307 557 minecraft:white_concrete
setblock 110 307 599 minecraft:black_concrete
setblock 112 307 557 minecraft:black_concrete
setblock 120 307 557 minecraft:black_concrete
setblock 136 307 560 minecraft:black_concrete
setblock 136 307 570 minecraft:pearlescent_froglight
setblock 136 307 572 minecraft:black_concrete
setblock 136 307 591 minecraft:white_stained_glass
setblock 136 307 592 minecraft:black_concrete
setblock 136 307 594 minecraft:white_concrete
