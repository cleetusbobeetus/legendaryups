fill 203 226 338 203 226 341 minecraft:iron_block
fill 203 226 343 203 226 346 minecraft:iron_block
fill 204 226 337 204 226 338 minecraft:iron_block
fill 204 226 346 204 226 347 minecraft:iron_block
fill 205 226 336 205 226 337 minecraft:iron_block
fill 205 226 347 205 226 348 minecraft:iron_block
fill 206 226 336 208 226 336 minecraft:iron_block
fill 206 226 340 206 226 344 minecraft:lime_stained_glass
fill 206 226 348 208 226 348 minecraft:iron_block
fill 207 226 335 211 226 335 minecraft:iron_block
fill 207 226 339 211 226 339 minecraft:lime_stained_glass
fill 207 226 345 211 226 345 minecraft:lime_stained_glass
fill 207 226 349 211 226 349 minecraft:iron_block
fill 210 226 336 213 226 336 minecraft:iron_block
fill 210 226 348 213 226 348 minecraft:iron_block
fill 212 226 340 212 226 344 minecraft:lime_stained_glass
fill 213 226 337 214 226 337 minecraft:iron_block
fill 213 226 347 214 226 347 minecraft:iron_block
fill 214 226 338 215 226 338 minecraft:iron_block
fill 214 226 346 215 226 346 minecraft:iron_block
fill 215 226 339 215 226 341 minecraft:iron_block
fill 215 226 343 215 226 345 minecraft:iron_block
fill 216 226 340 216 226 344 minecraft:iron_block
setblock 218 226 322 minecraft:sea_lantern
setblock 230 226 334 minecraft:ochre_froglight
setblock 188 227 349 minecraft:pearlescent_froglight
fill 192 227 364 192 278 364 minecraft:black_concrete
fill 197 227 364 197 273 364 minecraft:black_concrete
fill 198 227 340 205 228 344 minecraft:light_gray_concrete
fill 199 227 337 207 228 339 minecraft:light_gray_concrete
fill 199 227 345 207 228 347 minecraft:light_gray_concrete
fill 200 227 336 218 230 336 minecraft:light_gray_concrete
fill 200 227 348 218 230 348 minecraft:light_gray_concrete
fill 201 227 335 217 230 335 minecraft:light_gray_concrete
fill 201 227 349 217 230 349 minecraft:light_gray_concrete
fill 202 227 334 216 230 334 minecraft:light_gray_concrete
fill 202 227 350 216 230 350 minecraft:light_gray_concrete
fill 203 227 333 215 230 333 minecraft:light_gray_concrete
fill 203 227 351 215 230 351 minecraft:light_gray_concrete
fill 204 227 332 214 230 332 minecraft:light_gray_concrete
fill 204 227 352 214 230 352 minecraft:light_gray_concrete
fill 206 227 340 206 228 340 minecraft:light_gray_concrete
fill 206 227 344 206 228 344 minecraft:light_gray_concrete
fill 207 227 331 211 230 331 minecraft:light_gray_concrete
fill 207 227 353 211 230 353 minecraft:light_gray_concrete
fill 208 227 337 219 228 338 minecraft:light_gray_concrete
fill 208 227 346 219 228 347 minecraft:light_gray_concrete
fill 211 227 339 219 228 339 minecraft:light_gray_concrete
fill 211 227 345 219 228 345 minecraft:light_gray_concrete
fill 212 227 340 220 228 340 minecraft:light_gray_concrete
fill 212 227 344 220 228 344 minecraft:light_gray_concrete
fill 213 227 341 220 228 343 minecraft:light_gray_concrete
fill 218 227 322 218 269 322 minecraft:black_concrete
setblock 229 227 322 minecraft:white_concrete
fill 230 227 334 230 308 334 minecraft:black_concrete
setblock 230 227 347 minecraft:white_concrete
setblock 230 227 350 minecraft:sea_lantern
setblock 188 228 332 minecraft:white_concrete
fill 188 228 349 188 308 349 minecraft:black_concrete
fill 196 228 338 196 229 346 minecraft:sea_lantern
fill 197 228 336 197 229 339 minecraft:sea_lantern
fill 197 228 340 197 229 344 minecraft:light_gray_concrete
fill 197 228 345 197 229 348 minecraft:sea_lantern
fill 198 228 334 198 229 336 minecraft:sea_lantern
fill 198 228 337 198 229 339 minecraft:light_gray_concrete
fill 198 228 345 198 229 347 minecraft:light_gray_concrete
fill 198 228 348 198 229 350 minecraft:sea_lantern
fill 199 228 333 199 229 334 minecraft:sea_lantern
fill 199 228 335 199 229 336 minecraft:light_gray_concrete
fill 199 228 348 199 229 349 minecraft:light_gray_concrete
fill 199 228 350 199 229 351 minecraft:sea_lantern
fill 200 228 332 200 229 333 minecraft:sea_lantern
fill 200 228 334 200 229 335 minecraft:light_gray_concrete
fill 200 228 349 200 229 350 minecraft:light_gray_concrete
fill 200 228 351 200 229 352 minecraft:sea_lantern
fill 201 228 331 201 229 332 minecraft:sea_lantern
fill 201 228 333 201 229 334 minecraft:light_gray_concrete
fill 201 228 350 201 229 351 minecraft:light_gray_concrete
fill 201 228 352 201 229 353 minecraft:sea_lantern
fill 202 228 331 203 229 331 minecraft:sea_lantern
fill 202 228 332 202 229 333 minecraft:light_gray_concrete
fill 202 228 351 202 229 352 minecraft:light_gray_concrete
fill 202 228 353 203 229 353 minecraft:sea_lantern
fill 203 228 330 206 229 330 minecraft:sea_lantern
fill 203 228 332 203 229 332 minecraft:light_gray_concrete
fill 203 228 352 203 229 352 minecraft:light_gray_concrete
fill 203 228 354 206 229 354 minecraft:sea_lantern
fill 204 228 331 206 229 331 minecraft:light_gray_concrete
fill 204 228 353 206 229 353 minecraft:light_gray_concrete
fill 205 228 329 213 229 329 minecraft:sea_lantern
fill 205 228 355 213 229 355 minecraft:sea_lantern
fill 207 228 330 211 229 330 minecraft:light_gray_concrete
fill 207 228 354 211 229 354 minecraft:light_gray_concrete
setblock 211 228 322 minecraft:ochre_froglight
fill 212 228 330 215 229 330 minecraft:sea_lantern
fill 212 228 331 214 229 331 minecraft:light_gray_concrete
fill 212 228 353 214 229 353 minecraft:light_gray_concrete
fill 212 228 354 215 229 354 minecraft:sea_lantern
fill 215 228 331 217 229 331 minecraft:sea_lantern
fill 215 228 332 216 229 332 minecraft:light_gray_concrete
fill 215 228 352 216 229 352 minecraft:light_gray_concrete
fill 215 228 353 217 229 353 minecraft:sea_lantern
fill 216 228 333 217 229 333 minecraft:light_gray_concrete
fill 216 228 351 217 229 351 minecraft:light_gray_concrete
fill 217 228 332 218 229 332 minecraft:sea_lantern
fill 217 228 334 218 229 334 minecraft:light_gray_concrete
fill 217 228 350 218 229 350 minecraft:light_gray_concrete
fill 217 228 352 218 229 352 minecraft:sea_lantern
fill 218 228 333 219 229 333 minecraft:sea_lantern
fill 218 228 335 219 229 335 minecraft:light_gray_concrete
fill 218 228 349 219 229 349 minecraft:light_gray_concrete
fill 218 228 351 219 229 351 minecraft:sea_lantern
setblock 219 228 322 minecraft:pearlescent_froglight
fill 219 228 334 220 229 334 minecraft:sea_lantern
fill 219 228 336 219 229 336 minecraft:light_gray_concrete
fill 219 228 348 219 229 348 minecraft:light_gray_concrete
fill 219 228 350 220 229 350 minecraft:sea_lantern
fill 220 228 335 220 229 336 minecraft:sea_lantern
fill 220 228 337 220 229 339 minecraft:light_gray_concrete
fill 220 228 345 220 229 347 minecraft:light_gray_concrete
fill 220 228 348 220 229 349 minecraft:sea_lantern
fill 221 228 336 221 229 339 minecraft:sea_lantern
fill 221 228 340 221 229 344 minecraft:light_gray_concrete
fill 221 228 345 221 229 348 minecraft:sea_lantern
fill 222 228 338 222 229 346 minecraft:sea_lantern
fill 229 228 322 229 258 322 minecraft:black_concrete
setblock 230 228 336 minecraft:sea_lantern
fill 230 228 347 230 308 347 minecraft:black_concrete
fill 230 228 350 230 308 350 minecraft:black_concrete
setblock 230 228 359 minecraft:ochre_froglight
fill 188 229 332 188 253 332 minecraft:black_concrete
setblock 191 229 325 minecraft:light[level=12]
setblock 191 229 332 minecraft:light[level=12]
setblock 191 229 339 minecraft:light[level=12]
setblock 191 229 346 minecraft:light[level=12]
setblock 191 229 353 minecraft:light[level=12]
setblock 191 229 360 minecraft:light[level=12]
setblock 198 229 325 minecraft:light[level=12]
setblock 198 229 332 minecraft:light[level=12]
fill 198 229 340 204 229 344 minecraft:light_gray_concrete
setblock 198 229 353 minecraft:light[level=12]
setblock 198 229 360 minecraft:light[level=12]
fill 199 229 337 205 229 339 minecraft:light_gray_concrete
fill 199 229 345 205 229 347 minecraft:light_gray_concrete
setblock 205 229 325 minecraft:light[level=12]
fill 205 229 340 205 231 344 minecraft:light_blue_stained_glass
setblock 205 229 360 minecraft:light[level=12]
fill 206 229 337 206 229 338 minecraft:light_gray_concrete
fill 206 229 339 206 229 340 minecraft:light_blue_stained_glass
fill 206 229 344 206 229 345 minecraft:light_blue_stained_glass
fill 206 229 346 206 229 347 minecraft:light_gray_concrete
fill 207 229 337 219 229 337 minecraft:light_gray_concrete
fill 207 229 338 207 229 339 minecraft:light_blue_stained_glass
fill 207 229 345 207 229 346 minecraft:light_blue_stained_glass
fill 207 229 347 219 229 347 minecraft:light_gray_concrete
fill 208 229 338 211 231 338 minecraft:light_blue_stained_glass
fill 208 229 346 211 231 346 minecraft:light_blue_stained_glass
fill 211 229 322 211 273 322 minecraft:black_concrete
fill 211 229 339 212 229 339 minecraft:light_blue_stained_glass
fill 211 229 345 212 229 345 minecraft:light_blue_stained_glass
setblock 212 229 325 minecraft:light[level=12]
fill 212 229 338 219 229 338 minecraft:light_gray_concrete
fill 212 229 340 213 229 340 minecraft:light_blue_stained_glass
fill 212 229 344 213 229 344 minecraft:light_blue_stained_glass
fill 212 229 346 219 229 346 minecraft:light_gray_concrete
setblock 212 229 360 minecraft:light[level=12]
fill 213 229 339 219 229 339 minecraft:light_gray_concrete
fill 213 229 341 213 231 343 minecraft:light_blue_stained_glass
fill 213 229 345 219 229 345 minecraft:light_gray_concrete
fill 214 229 340 220 229 344 minecraft:light_gray_concrete
fill 219 229 322 219 308 322 minecraft:black_concrete
setblock 219 229 325 minecraft:light[level=12]
setblock 219 229 332 minecraft:light[level=12]
setblock 219 229 353 minecraft:light[level=12]
setblock 219 229 360 minecraft:light[level=12]
setblock 224 229 364 minecraft:pearlescent_froglight
setblock 226 229 325 minecraft:light[level=12]
setblock 226 229 332 minecraft:light[level=12]
setblock 226 229 339 minecraft:light[level=12]
setblock 226 229 346 minecraft:light[level=12]
setblock 226 229 353 minecraft:light[level=12]
setblock 226 229 360 minecraft:light[level=12]
setblock 228 229 364 minecraft:white_concrete
fill 230 229 336 230 239 336 minecraft:black_concrete
fill 230 229 359 230 231 359 minecraft:black_concrete
setblock 188 230 341 minecraft:sea_lantern
fill 198 230 340 203 230 344 minecraft:light_gray_concrete
fill 199 230 337 204 230 339 minecraft:light_gray_concrete
fill 199 230 345 204 230 347 minecraft:light_gray_concrete
fill 204 230 340 204 232 344 minecraft:light_blue_stained_glass
fill 205 230 337 206 230 337 minecraft:light_gray_concrete
fill 205 230 338 206 232 339 minecraft:light_blue_stained_glass
fill 205 230 345 206 232 346 minecraft:light_blue_stained_glass
fill 205 230 347 206 230 347 minecraft:light_gray_concrete
fill 207 230 337 207 232 338 minecraft:light_blue_stained_glass
fill 207 230 346 207 232 347 minecraft:light_blue_stained_glass
fill 207 230 354 208 231 354 minecraft:gray_concrete
fill 208 230 337 211 232 337 minecraft:light_blue_stained_glass
fill 208 230 347 211 232 347 minecraft:light_blue_stained_glass
setblock 209 230 364 minecraft:ochre_froglight
fill 212 230 337 219 230 337 minecraft:light_gray_concrete
fill 212 230 338 213 232 339 minecraft:light_blue_stained_glass
fill 212 230 345 213 232 346 minecraft:light_blue_stained_glass
fill 212 230 347 219 230 347 minecraft:light_gray_concrete
setblock 212 230 364 minecraft:white_concrete
fill 213 230 340 214 232 340 minecraft:light_blue_stained_glass
fill 213 230 344 214 232 344 minecraft:light_blue_stained_glass
fill 214 230 338 219 230 339 minecraft:light_gray_concrete
fill 214 230 341 214 232 343 minecraft:light_blue_stained_glass
fill 214 230 345 219 230 346 minecraft:light_gray_concrete
fill 215 230 340 220 230 344 minecraft:light_gray_concrete
fill 224 230 364 224 308 364 minecraft:black_concrete
fill 228 230 364 228 236 364 minecraft:black_concrete
fill 188 231 341 188 247 341 minecraft:black_concrete
fill 191 231 339 192 232 347 minecraft:light_gray_concrete
fill 192 231 336 193 232 338 minecraft:light_gray_concrete
fill 192 231 348 193 232 350 minecraft:light_gray_concrete
fill 193 231 334 194 232 335 minecraft:light_gray_concrete
fill 193 231 351 194 232 352 minecraft:light_gray_concrete
fill 194 231 333 195 232 333 minecraft:light_gray_concrete
fill 194 231 336 194 232 336 minecraft:light_gray_concrete
fill 194 231 350 194 232 350 minecraft:light_gray_concrete
fill 194 231 353 195 232 353 minecraft:light_gray_concrete
fill 195 231 331 196 232 332 minecraft:light_gray_concrete
fill 195 231 334 195 232 334 minecraft:light_gray_concrete
fill 195 231 352 195 232 352 minecraft:light_gray_concrete
fill 195 231 354 196 232 355 minecraft:light_gray_concrete
fill 196 231 330 198 232 330 minecraft:light_gray_concrete
fill 196 231 356 198 232 356 minecraft:light_gray_concrete
fill 197 231 329 200 232 329 minecraft:light_gray_concrete
fill 197 231 331 197 232 331 minecraft:light_gray_concrete
fill 197 231 355 197 232 355 minecraft:light_gray_concrete
fill 197 231 357 200 232 357 minecraft:light_gray_concrete
fill 199 231 328 202 232 328 minecraft:light_gray_concrete
fill 199 231 358 202 232 358 minecraft:light_gray_concrete
fill 200 231 327 204 232 327 minecraft:light_gray_concrete
fill 200 231 359 204 232 359 minecraft:light_gray_concrete
fill 202 231 326 216 232 326 minecraft:light_gray_concrete
fill 202 231 360 216 232 360 minecraft:light_gray_concrete
setblock 203 231 342 minecraft:light_blue_stained_glass
setblock 204 231 339 minecraft:light_blue_stained_glass
setblock 204 231 345 minecraft:light_blue_stained_glass
fill 205 231 325 213 232 325 minecraft:light_gray_concrete
fill 205 231 361 213 232 361 minecraft:light_gray_concrete
setblock 205 231 364 minecraft:white_concrete
setblock 206 231 337 minecraft:light_blue_stained_glass
setblock 206 231 347 minecraft:light_blue_stained_glass
setblock 209 231 336 minecraft:light_blue_stained_glass
setblock 209 231 348 minecraft:light_blue_stained_glass
fill 209 231 364 209 245 364 minecraft:black_concrete
setblock 212 231 337 minecraft:light_blue_stained_glass
setblock 212 231 347 minecraft:light_blue_stained_glass
fill 212 231 364 212 248 364 minecraft:black_concrete
fill 214 231 327 218 232 327 minecraft:light_gray_concrete
setblock 214 231 339 minecraft:light_blue_stained_glass
setblock 214 231 345 minecraft:light_blue_stained_glass
fill 214 231 359 218 232 359 minecraft:light_gray_concrete
setblock 215 231 342 minecraft:light_blue_stained_glass
fill 216 231 328 219 232 328 minecraft:light_gray_concrete
fill 216 231 358 219 232 358 minecraft:light_gray_concrete
fill 218 231 329 221 232 329 minecraft:light_gray_concrete
fill 218 231 357 221 232 357 minecraft:light_gray_concrete
fill 220 231 330 222 232 330 minecraft:light_gray_concrete
fill 220 231 356 222 232 356 minecraft:light_gray_concrete
fill 221 231 331 223 232 331 minecraft:light_gray_concrete
fill 221 231 355 223 232 355 minecraft:light_gray_concrete
fill 222 231 332 223 232 332 minecraft:light_gray_concrete
fill 222 231 354 223 232 354 minecraft:light_gray_concrete
fill 223 231 333 224 232 334 minecraft:light_gray_concrete
fill 223 231 352 224 232 353 minecraft:light_gray_concrete
setblock 224 231 322 minecraft:sea_lantern
fill 224 231 335 225 232 336 minecraft:light_gray_concrete
fill 224 231 350 225 232 351 minecraft:light_gray_concrete
fill 225 231 334 225 232 334 minecraft:light_gray_concrete
fill 225 231 337 226 232 338 minecraft:light_gray_concrete
fill 225 231 348 226 232 349 minecraft:light_gray_concrete
fill 225 231 352 225 232 352 minecraft:light_gray_concrete
fill 226 231 336 226 232 336 minecraft:light_gray_concrete
fill 226 231 339 227 232 347 minecraft:light_gray_concrete
fill 226 231 350 226 232 350 minecraft:light_gray_concrete
setblock 188 232 343 minecraft:pearlescent_froglight
setblock 191 232 364 minecraft:white_concrete
fill 202 232 332 202 233 332 minecraft:gray_concrete
fill 205 232 340 205 233 340 minecraft:light_blue_stained_glass
fill 205 232 344 205 233 344 minecraft:light_blue_stained_glass
fill 205 232 364 205 237 364 minecraft:black_concrete
fill 211 232 338 211 233 338 minecraft:light_blue_stained_glass
fill 211 232 346 211 233 346 minecraft:light_blue_stained_glass
setblock 215 232 364 minecraft:sea_lantern
fill 224 232 322 224 243 322 minecraft:black_concrete
fill 230 232 351 230 251 352 minecraft:black_concrete
setblock 230 232 353 minecraft:ochre_froglight
setblock 230 232 359 minecraft:sea_lantern
setblock 188 233 333 minecraft:sea_lantern
fill 188 233 343 188 255 343 minecraft:black_concrete
setblock 188 233 350 minecraft:white_concrete
setblock 191 233 325 minecraft:light[level=15]
setblock 191 233 333 minecraft:light[level=15]
fill 191 233 339 191 233 347 minecraft:verdant_froglight
setblock 191 233 349 minecraft:light[level=15]
setblock 191 233 357 minecraft:light[level=15]
fill 191 233 364 191 297 364 minecraft:black_concrete
fill 192 233 336 192 233 338 minecraft:verdant_froglight
fill 192 233 348 192 233 350 minecraft:verdant_froglight
fill 193 233 334 193 233 335 minecraft:verdant_froglight
fill 193 233 351 193 233 352 minecraft:verdant_froglight
setblock 194 233 333 minecraft:verdant_froglight
setblock 194 233 353 minecraft:verdant_froglight
fill 195 233 331 195 233 332 minecraft:verdant_froglight
fill 195 233 354 195 233 355 minecraft:verdant_froglight
fill 196 233 330 196 233 331 minecraft:verdant_froglight
fill 196 233 355 196 233 356 minecraft:verdant_froglight
fill 197 233 329 197 233 330 minecraft:verdant_froglight
fill 197 233 356 197 233 357 minecraft:verdant_froglight
setblock 198 233 329 minecraft:verdant_froglight
setblock 198 233 357 minecraft:verdant_froglight
setblock 199 233 325 minecraft:light[level=15]
setblock 199 233 328 minecraft:verdant_froglight
setblock 199 233 333 minecraft:light[level=15]
setblock 199 233 341 minecraft:light[level=15]
setblock 199 233 349 minecraft:light[level=15]
setblock 199 233 357 minecraft:light[level=15]
setblock 199 233 358 minecraft:verdant_froglight
fill 200 233 327 201 233 327 minecraft:verdant_froglight
fill 200 233 359 201 233 359 minecraft:verdant_froglight
fill 202 233 326 204 233 326 minecraft:verdant_froglight
fill 202 233 360 204 233 360 minecraft:verdant_froglight
fill 205 233 325 213 233 325 minecraft:verdant_froglight
fill 205 233 361 213 233 361 minecraft:verdant_froglight
setblock 207 233 333 minecraft:light[level=15]
setblock 207 233 338 minecraft:light_blue_stained_glass
setblock 207 233 346 minecraft:light_blue_stained_glass
setblock 207 233 349 minecraft:light[level=15]
setblock 207 233 357 minecraft:light[level=15]
setblock 209 233 322 minecraft:sea_lantern
setblock 211 233 364 minecraft:pearlescent_froglight
fill 213 233 327 213 234 328 minecraft:gray_concrete
setblock 213 233 340 minecraft:light_blue_stained_glass
setblock 213 233 344 minecraft:light_blue_stained_glass
fill 214 233 326 216 233 326 minecraft:verdant_froglight
fill 214 233 360 216 233 360 minecraft:verdant_froglight
setblock 215 233 325 minecraft:light[level=15]
setblock 215 233 333 minecraft:light[level=15]
setblock 215 233 341 minecraft:light[level=15]
setblock 215 233 349 minecraft:light[level=15]
setblock 215 233 357 minecraft:light[level=15]
fill 215 233 364 215 308 364 minecraft:black_concrete
fill 217 233 327 218 233 327 minecraft:verdant_froglight
fill 217 233 359 218 233 359 minecraft:verdant_froglight
setblock 219 233 328 minecraft:verdant_froglight
setblock 219 233 358 minecraft:verdant_froglight
fill 220 233 329 221 233 329 minecraft:verdant_froglight
fill 220 233 357 221 233 357 minecraft:verdant_froglight
fill 221 233 330 222 233 330 minecraft:verdant_froglight
fill 221 233 356 222 233 356 minecraft:verdant_froglight
fill 222 233 331 223 233 331 minecraft:verdant_froglight
fill 222 233 355 223 233 355 minecraft:verdant_froglight
setblock 223 233 325 minecraft:light[level=15]
setblock 223 233 332 minecraft:verdant_froglight
setblock 223 233 333 minecraft:light[level=15]
setblock 223 233 341 minecraft:light[level=15]
setblock 223 233 349 minecraft:light[level=15]
setblock 223 233 354 minecraft:verdant_froglight
setblock 223 233 357 minecraft:light[level=15]
setblock 224 233 333 minecraft:verdant_froglight
setblock 224 233 353 minecraft:verdant_froglight
fill 230 233 353 230 249 353 minecraft:black_concrete
fill 230 233 359 230 278 359 minecraft:black_concrete
setblock 188 234 328 minecraft:pearlescent_froglight
fill 188 234 333 188 308 333 minecraft:black_concrete
fill 188 234 350 188 296 350 minecraft:black_concrete
setblock 200 234 364 minecraft:white_concrete
setblock 208 234 322 minecraft:sea_lantern
fill 209 234 322 209 236 322 minecraft:black_concrete
fill 211 234 364 211 241 364 minecraft:black_concrete
setblock 230 234 356 minecraft:pearlescent_froglight
setblock 230 234 357 minecraft:white_concrete
setblock 230 234 361 minecraft:sea_lantern
fill 188 235 328 188 308 328 minecraft:black_concrete
setblock 188 235 334 minecraft:white_concrete
setblock 188 235 346 minecraft:pearlescent_froglight
setblock 191 235 325 minecraft:light[level=12]
setblock 191 235 332 minecraft:light[level=12]
setblock 191 235 339 minecraft:light[level=12]
setblock 191 235 346 minecraft:light[level=12]
setblock 191 235 353 minecraft:light[level=12]
setblock 191 235 360 minecraft:light[level=12]
setblock 198 235 325 minecraft:light[level=12]
setblock 198 235 332 minecraft:light[level=12]
setblock 198 235 339 minecraft:light[level=12]
setblock 198 235 346 minecraft:light[level=12]
setblock 198 235 353 minecraft:light[level=12]
setblock 198 235 360 minecraft:light[level=12]
fill 200 235 364 200 290 364 minecraft:black_concrete
setblock 205 235 325 minecraft:light[level=12]
setblock 205 235 332 minecraft:light[level=12]
setblock 205 235 339 minecraft:light[level=12]
setblock 205 235 346 minecraft:light[level=12]
setblock 205 235 353 minecraft:light[level=12]
setblock 205 235 360 minecraft:light[level=12]
fill 208 235 322 208 258 322 minecraft:black_concrete
setblock 212 235 325 minecraft:light[level=12]
setblock 212 235 332 minecraft:light[level=12]
setblock 212 235 346 minecraft:light[level=12]
setblock 212 235 353 minecraft:light[level=12]
setblock 212 235 360 minecraft:light[level=12]
setblock 219 235 325 minecraft:light[level=12]
setblock 219 235 332 minecraft:light[level=12]
setblock 219 235 339 minecraft:light[level=12]
setblock 219 235 346 minecraft:light[level=12]
setblock 219 235 353 minecraft:light[level=12]
setblock 219 235 360 minecraft:light[level=12]
setblock 226 235 325 minecraft:light[level=12]
setblock 226 235 332 minecraft:light[level=12]
setblock 226 235 339 minecraft:light[level=12]
setblock 226 235 346 minecraft:light[level=12]
setblock 226 235 353 minecraft:light[level=12]
setblock 226 235 360 minecraft:light[level=12]
fill 230 235 356 230 240 357 minecraft:black_concrete
fill 230 235 361 230 274 361 minecraft:black_concrete
fill 188 236 334 188 283 334 minecraft:black_concrete
setblock 188 236 336 minecraft:sea_lantern
fill 188 236 346 188 263 346 minecraft:black_concrete
setblock 188 236 348 minecraft:pearlescent_froglight
setblock 196 236 322 minecraft:sea_lantern
setblock 188 237 326 minecraft:ochre_froglight
fill 188 237 336 188 291 336 minecraft:black_concrete
fill 188 237 348 188 245 348 minecraft:black_concrete
fill 196 237 322 196 247 322 minecraft:black_concrete
setblock 206 237 322 minecraft:white_concrete
setblock 209 237 322 minecraft:ochre_froglight
fill 217 237 356 218 238 357 minecraft:end_stone
setblock 221 237 364 minecraft:white_concrete
setblock 228 237 364 minecraft:sea_lantern
setblock 230 237 323 minecraft:pearlescent_froglight
setblock 230 237 325 minecraft:white_concrete
setblock 230 237 340 minecraft:pearlescent_froglight
fill 188 238 326 188 308 326 minecraft:black_concrete
setblock 193 238 322 minecraft:ochre_froglight
fill 197 238 338 197 240 338 minecraft:lime_stained_glass
setblock 205 238 364 minecraft:white_concrete
fill 206 238 322 206 253 322 minecraft:black_concrete
fill 209 238 322 209 296 322 minecraft:black_concrete
setblock 214 238 364 minecraft:pearlescent_froglight
setblock 219 238 364 minecraft:pearlescent_froglight
fill 221 238 364 221 277 364 minecraft:black_concrete
setblock 223 238 364 minecraft:sea_lantern
fill 228 238 364 228 248 364 minecraft:black_concrete
fill 230 238 323 230 241 323 minecraft:black_concrete
fill 230 238 325 230 241 325 minecraft:black_concrete
fill 230 238 340 230 308 340 minecraft:black_concrete
fill 193 239 322 193 245 322 minecraft:black_concrete
setblock 194 239 364 minecraft:white_concrete
fill 200 239 327 200 240 329 minecraft:end_stone
fill 201 239 327 201 240 328 minecraft:end_stone
setblock 202 239 322 minecraft:ochre_froglight
fill 205 239 364 205 251 364 minecraft:black_concrete
fill 214 239 364 214 299 364 minecraft:black_concrete
setblock 215 239 322 minecraft:ochre_froglight
fill 216 239 355 216 240 355 minecraft:lime_stained_glass
fill 219 239 364 219 240 364 minecraft:black_concrete
fill 223 239 364 223 269 364 minecraft:black_concrete
fill 194 240 364 194 264 364 minecraft:black_concrete
fill 198 240 337 200 241 337 minecraft:end_stone
fill 199 240 336 199 241 336 minecraft:end_stone
fill 199 240 338 199 241 338 minecraft:end_stone
fill 202 240 322 202 285 322 minecraft:black_concrete
fill 215 240 322 215 266 322 minecraft:black_concrete
setblock 230 240 336 minecraft:pearlescent_froglight
setblock 230 240 358 minecraft:ochre_froglight
setblock 188 241 327 minecraft:ochre_froglight
setblock 188 241 335 minecraft:white_concrete
setblock 191 241 325 minecraft:light[level=15]
setblock 191 241 332 minecraft:light[level=12]
setblock 191 241 333 minecraft:light[level=15]
setblock 191 241 339 minecraft:light[level=12]
setblock 191 241 341 minecraft:light[level=15]
setblock 191 241 346 minecraft:light[level=12]
setblock 191 241 349 minecraft:light[level=15]
setblock 191 241 353 minecraft:light[level=12]
setblock 191 241 357 minecraft:light[level=15]
setblock 191 241 360 minecraft:light[level=12]
fill 197 241 338 198 247 339 minecraft:gray_concrete
setblock 198 241 325 minecraft:light[level=12]
setblock 198 241 332 minecraft:light[level=12]
setblock 198 241 346 minecraft:light[level=12]
setblock 198 241 353 minecraft:light[level=12]
setblock 198 241 360 minecraft:light[level=12]
setblock 199 241 325 minecraft:light[level=15]
setblock 199 241 333 minecraft:light[level=15]
setblock 199 241 341 minecraft:light[level=15]
setblock 199 241 349 minecraft:light[level=15]
setblock 199 241 357 minecraft:light[level=15]
setblock 205 241 325 minecraft:light[level=12]
setblock 205 241 332 minecraft:light[level=12]
setblock 205 241 339 minecraft:light[level=12]
setblock 205 241 346 minecraft:light[level=12]
setblock 205 241 353 minecraft:light[level=12]
setblock 205 241 360 minecraft:light[level=12]
setblock 207 241 325 minecraft:light[level=15]
setblock 207 241 333 minecraft:light[level=15]
setblock 207 241 341 minecraft:light[level=15]
setblock 207 241 349 minecraft:light[level=15]
setblock 207 241 357 minecraft:light[level=15]
setblock 212 241 325 minecraft:light[level=12]
setblock 212 241 332 minecraft:light[level=12]
setblock 212 241 339 minecraft:light[level=12]
setblock 212 241 346 minecraft:light[level=12]
setblock 212 241 353 minecraft:light[level=12]
setblock 212 241 360 minecraft:light[level=12]
setblock 215 241 325 minecraft:light[level=15]
setblock 215 241 333 minecraft:light[level=15]
setblock 215 241 341 minecraft:light[level=15]
setblock 215 241 349 minecraft:light[level=15]
setblock 215 241 357 minecraft:light[level=15]
fill 216 241 355 216 251 355 minecraft:gray_concrete
setblock 219 241 325 minecraft:light[level=12]
setblock 219 241 332 minecraft:light[level=12]
setblock 219 241 339 minecraft:light[level=12]
setblock 219 241 346 minecraft:light[level=12]
setblock 219 241 353 minecraft:light[level=12]
setblock 219 241 360 minecraft:light[level=12]
setblock 219 241 364 minecraft:sea_lantern
setblock 223 241 325 minecraft:light[level=15]
setblock 223 241 333 minecraft:light[level=15]
setblock 223 241 341 minecraft:light[level=15]
setblock 223 241 349 minecraft:light[level=15]
setblock 223 241 357 minecraft:light[level=15]
setblock 226 241 325 minecraft:light[level=12]
setblock 226 241 332 minecraft:light[level=12]
fill 226 241 335 226 242 336 minecraft:end_stone
setblock 226 241 339 minecraft:light[level=12]
setblock 226 241 346 minecraft:light[level=12]
setblock 226 241 353 minecraft:light[level=12]
setblock 226 241 360 minecraft:light[level=12]
setblock 230 241 326 minecraft:sea_lantern
fill 230 241 336 230 289 336 minecraft:black_concrete
fill 230 241 356 230 308 356 minecraft:black_concrete
setblock 230 241 357 minecraft:ochre_froglight
fill 230 241 358 230 306 358 minecraft:black_concrete
fill 188 242 327 188 262 327 minecraft:black_concrete
setblock 188 242 329 minecraft:sea_lantern
fill 188 242 335 188 253 335 minecraft:black_concrete
setblock 188 242 359 minecraft:ochre_froglight
setblock 211 242 364 minecraft:pearlescent_froglight
fill 217 242 355 217 251 355 minecraft:gray_concrete
fill 219 242 364 219 263 364 minecraft:black_concrete
fill 223 242 341 224 243 342 minecraft:end_stone
setblock 230 242 323 minecraft:ochre_froglight
setblock 230 242 325 minecraft:white_concrete
fill 230 242 326 230 262 326 minecraft:black_concrete
setblock 230 242 328 minecraft:ochre_froglight
fill 230 242 357 230 256 357 minecraft:black_concrete
fill 188 243 329 188 249 329 minecraft:black_concrete
setblock 188 243 330 minecraft:pearlescent_froglight
fill 188 243 359 188 302 359 minecraft:black_concrete
setblock 188 243 360 minecraft:ochre_froglight
fill 196 243 338 196 247 339 minecraft:gray_concrete
fill 197 243 337 198 247 337 minecraft:gray_concrete
fill 197 243 340 198 247 340 minecraft:gray_concrete
fill 199 243 338 199 247 339 minecraft:gray_concrete
fill 211 243 364 211 308 364 minecraft:black_concrete
fill 215 243 355 215 251 355 minecraft:gray_concrete
fill 216 243 354 217 251 354 minecraft:gray_concrete
fill 216 243 356 217 251 356 minecraft:gray_concrete
fill 230 243 323 230 308 323 minecraft:black_concrete
fill 230 243 325 230 250 325 minecraft:black_concrete
fill 230 243 328 230 308 328 minecraft:black_concrete
setblock 230 243 363 minecraft:sea_lantern
fill 188 244 330 188 250 330 minecraft:black_concrete
fill 188 244 360 188 280 360 minecraft:black_concrete
setblock 190 244 364 minecraft:pearlescent_froglight
fill 196 244 337 196 247 337 minecraft:gray_concrete
fill 196 244 340 196 247 340 minecraft:gray_concrete
fill 199 244 337 199 247 337 minecraft:gray_concrete
fill 199 244 340 199 247 340 minecraft:gray_concrete
setblock 210 244 322 minecraft:pearlescent_froglight
fill 215 244 354 215 251 354 minecraft:gray_concrete
fill 215 244 356 215 251 356 minecraft:gray_concrete
fill 216 244 353 216 251 353 minecraft:gray_concrete
fill 218 244 354 218 251 356 minecraft:gray_concrete
setblock 224 244 322 minecraft:pearlescent_froglight
fill 230 244 363 230 308 363 minecraft:black_concrete
setblock 188 245 347 minecraft:sea_lantern
setblock 189 245 364 minecraft:sea_lantern
fill 190 245 364 190 299 364 minecraft:black_concrete
fill 195 245 337 195 247 340 minecraft:gray_concrete
fill 196 245 336 199 247 336 minecraft:gray_concrete
fill 196 245 341 198 247 341 minecraft:gray_concrete
setblock 198 245 364 minecraft:white_concrete
fill 200 245 338 200 247 339 minecraft:gray_concrete
setblock 201 245 364 minecraft:white_concrete
fill 210 245 322 210 308 322 minecraft:black_concrete
fill 214 245 355 214 251 355 minecraft:gray_concrete
fill 215 245 353 215 251 353 minecraft:gray_concrete
fill 215 245 357 217 251 357 minecraft:gray_concrete
fill 217 245 353 217 251 353 minecraft:gray_concrete
fill 224 245 322 224 249 322 minecraft:black_concrete
fill 224 245 337 224 251 337 minecraft:lime_concrete
setblock 230 245 337 minecraft:pearlescent_froglight
fill 188 246 347 188 308 347 minecraft:black_concrete
setblock 188 246 348 minecraft:sea_lantern
fill 189 246 364 189 308 364 minecraft:black_concrete
setblock 193 246 322 minecraft:sea_lantern
fill 193 246 356 193 252 356 minecraft:lime_concrete
fill 198 246 364 198 308 364 minecraft:black_concrete
fill 199 246 341 199 247 341 minecraft:gray_concrete
fill 200 246 337 200 247 337 minecraft:gray_concrete
fill 200 246 340 200 247 340 minecraft:gray_concrete
fill 201 246 364 201 308 364 minecraft:black_concrete
setblock 209 246 364 minecraft:pearlescent_froglight
fill 214 246 354 214 251 354 minecraft:gray_concrete
fill 214 246 356 214 251 356 minecraft:gray_concrete
fill 216 246 352 216 251 352 minecraft:gray_concrete
setblock 217 246 364 minecraft:ochre_froglight
fill 218 246 353 218 251 353 minecraft:gray_concrete
fill 218 246 357 218 251 357 minecraft:gray_concrete
fill 219 246 354 219 251 356 minecraft:gray_concrete
fill 225 246 337 225 251 337 minecraft:lime_concrete
fill 230 246 337 230 293 337 minecraft:black_concrete
fill 188 247 348 188 300 348 minecraft:black_concrete
setblock 191 247 325 minecraft:light[level=12]
setblock 191 247 332 minecraft:light[level=12]
setblock 191 247 339 minecraft:light[level=12]
setblock 191 247 346 minecraft:light[level=12]
setblock 191 247 353 minecraft:light[level=12]
setblock 191 247 360 minecraft:light[level=12]
fill 193 247 322 193 267 322 minecraft:black_concrete
fill 193 247 355 193 252 355 minecraft:lime_concrete
fill 193 247 357 193 252 357 minecraft:lime_concrete
fill 194 247 337 194 247 340 minecraft:gray_concrete
fill 194 247 356 194 252 356 minecraft:lime_concrete
setblock 195 247 336 minecraft:gray_concrete
setblock 195 247 341 minecraft:gray_concrete
fill 196 247 335 199 247 335 minecraft:gray_concrete
fill 196 247 342 199 247 342 minecraft:gray_concrete
setblock 198 247 325 minecraft:light[level=12]
setblock 198 247 332 minecraft:light[level=12]
setblock 198 247 346 minecraft:light[level=12]
setblock 198 247 353 minecraft:light[level=12]
setblock 198 247 360 minecraft:light[level=12]
setblock 200 247 336 minecraft:gray_concrete
setblock 200 247 341 minecraft:gray_concrete
fill 201 247 337 201 247 340 minecraft:gray_concrete
setblock 205 247 325 minecraft:light[level=12]
setblock 205 247 332 minecraft:light[level=12]
setblock 205 247 339 minecraft:light[level=12]
setblock 205 247 346 minecraft:light[level=12]
setblock 205 247 353 minecraft:light[level=12]
setblock 205 247 360 minecraft:light[level=12]
fill 209 247 364 209 274 364 minecraft:black_concrete
fill 211 247 331 211 248 331 minecraft:lime_stained_glass
setblock 212 247 325 minecraft:light[level=12]
setblock 212 247 332 minecraft:light[level=12]
setblock 212 247 339 minecraft:light[level=12]
setblock 212 247 346 minecraft:light[level=12]
setblock 212 247 353 minecraft:light[level=12]
setblock 212 247 360 minecraft:light[level=12]
fill 213 247 355 213 251 355 minecraft:gray_concrete
fill 214 247 353 214 251 353 minecraft:gray_concrete
fill 214 247 357 214 251 357 minecraft:gray_concrete
fill 215 247 352 215 251 352 minecraft:gray_concrete
fill 215 247 358 218 251 358 minecraft:gray_concrete
fill 217 247 352 218 251 352 minecraft:gray_concrete
fill 217 247 364 217 308 364 minecraft:black_concrete
setblock 219 247 325 minecraft:light[level=12]
setblock 219 247 332 minecraft:light[level=12]
setblock 219 247 339 minecraft:light[level=12]
setblock 219 247 346 minecraft:light[level=12]
fill 219 247 353 219 251 353 minecraft:gray_concrete
fill 219 247 357 219 251 357 minecraft:gray_concrete
setblock 219 247 360 minecraft:light[level=12]
setblock 220 247 322 minecraft:white_concrete
fill 223 247 337 223 251 337 minecraft:lime_concrete
fill 224 247 336 225 251 336 minecraft:lime_concrete
fill 224 247 338 225 251 338 minecraft:lime_concrete
setblock 226 247 325 minecraft:light[level=12]
setblock 226 247 332 minecraft:light[level=12]
setblock 226 247 339 minecraft:light[level=12]
setblock 226 247 346 minecraft:light[level=12]
setblock 226 247 353 minecraft:light[level=12]
setblock 226 247 360 minecraft:light[level=12]
setblock 227 247 322 minecraft:sea_lantern
setblock 188 248 325 minecraft:white_concrete
setblock 188 248 341 minecraft:white_concrete
setblock 188 248 354 minecraft:pearlescent_froglight
fill 192 248 355 192 252 357 minecraft:lime_concrete
fill 194 248 355 194 252 355 minecraft:lime_concrete
fill 194 248 357 194 252 357 minecraft:lime_concrete
fill 195 248 356 195 252 356 minecraft:lime_concrete
setblock 196 248 322 minecraft:pearlescent_froglight
fill 197 248 338 198 250 339 minecraft:lime_stained_glass
fill 213 248 353 213 251 354 minecraft:gray_concrete
fill 213 248 356 213 251 357 minecraft:gray_concrete
fill 214 248 352 214 251 352 minecraft:gray_concrete
fill 214 248 358 214 251 358 minecraft:gray_concrete
fill 216 248 351 216 251 351 minecraft:gray_concrete
fill 219 248 352 219 251 352 minecraft:gray_concrete
fill 220 248 322 220 274 322 minecraft:black_concrete
fill 220 248 354 220 251 356 minecraft:gray_concrete
fill 223 248 336 223 251 336 minecraft:lime_concrete
fill 223 248 338 223 251 338 minecraft:lime_concrete
fill 224 248 335 225 251 335 minecraft:lime_concrete
fill 224 248 339 225 251 339 minecraft:lime_concrete
fill 226 248 336 226 251 338 minecraft:lime_concrete
fill 227 248 322 227 305 322 minecraft:black_concrete
fill 188 249 325 188 305 325 minecraft:black_concrete
fill 188 249 341 188 257 341 minecraft:black_concrete
fill 188 249 354 188 281 354 minecraft:black_concrete
setblock 191 249 325 minecraft:light[level=15]
setblock 191 249 333 minecraft:light[level=15]
setblock 191 249 341 minecraft:light[level=15]
setblock 191 249 349 minecraft:light[level=15]
fill 191 249 355 191 252 357 minecraft:lime_concrete
fill 192 249 354 194 252 354 minecraft:lime_concrete
fill 192 249 358 194 252 358 minecraft:lime_concrete
fill 195 249 355 195 252 355 minecraft:lime_concrete
fill 195 249 357 195 252 357 minecraft:lime_concrete
fill 196 249 322 196 256 322 minecraft:black_concrete
setblock 199 249 325 minecraft:light[level=15]
setblock 199 249 333 minecraft:light[level=15]
setblock 199 249 341 minecraft:light[level=15]
setblock 199 249 349 minecraft:light[level=15]
setblock 199 249 357 minecraft:light[level=15]
setblock 203 249 322 minecraft:ochre_froglight
setblock 207 249 325 minecraft:light[level=15]
setblock 207 249 333 minecraft:light[level=15]
setblock 207 249 341 minecraft:light[level=15]
setblock 207 249 349 minecraft:light[level=15]
setblock 207 249 357 minecraft:light[level=15]
fill 211 249 331 211 256 332 minecraft:gray_concrete
fill 212 249 355 212 251 355 minecraft:gray_concrete
setblock 212 249 364 minecraft:white_concrete
setblock 213 249 322 minecraft:sea_lantern
setblock 215 249 325 minecraft:light[level=15]
setblock 215 249 333 minecraft:light[level=15]
setblock 215 249 341 minecraft:light[level=15]
setblock 215 249 349 minecraft:light[level=15]
fill 215 249 351 215 251 351 minecraft:gray_concrete
fill 215 249 359 218 251 359 minecraft:gray_concrete
fill 217 249 351 218 251 351 minecraft:gray_concrete
fill 219 249 358 219 251 358 minecraft:gray_concrete
fill 220 249 353 220 251 353 minecraft:gray_concrete
fill 220 249 357 220 251 357 minecraft:gray_concrete
fill 222 249 336 222 251 338 minecraft:lime_concrete
setblock 223 249 325 minecraft:light[level=15]
setblock 223 249 333 minecraft:light[level=15]
fill 223 249 335 223 251 335 minecraft:lime_concrete
fill 223 249 339 223 251 339 minecraft:lime_concrete
setblock 223 249 341 minecraft:light[level=15]
setblock 223 249 349 minecraft:light[level=15]
setblock 223 249 357 minecraft:light[level=15]
fill 226 249 335 226 251 335 minecraft:lime_concrete
fill 226 249 339 226 251 339 minecraft:lime_concrete
fill 227 249 337 227 251 337 minecraft:lime_concrete
setblock 228 249 364 minecraft:pearlescent_froglight
setblock 188 250 329 minecraft:sea_lantern
setblock 188 250 351 minecraft:white_concrete
fill 190 250 356 190 252 356 minecraft:lime_concrete
fill 191 250 354 191 252 354 minecraft:lime_concrete
fill 191 250 358 191 252 358 minecraft:lime_concrete
fill 192 250 353 194 252 353 minecraft:lime_concrete
fill 192 250 359 194 252 359 minecraft:lime_concrete
fill 195 250 354 195 252 354 minecraft:lime_concrete
fill 195 250 358 195 252 358 minecraft:lime_concrete
fill 196 250 355 196 252 357 minecraft:lime_concrete
fill 203 250 322 203 308 322 minecraft:black_concrete
fill 212 250 353 212 251 354 minecraft:gray_concrete
fill 212 250 356 212 251 357 minecraft:gray_concrete
fill 212 250 364 212 308 364 minecraft:black_concrete
fill 213 250 322 213 288 322 minecraft:black_concrete
fill 213 250 352 213 251 352 minecraft:gray_concrete
setblock 213 250 358 minecraft:gray_concrete
fill 214 250 351 214 251 351 minecraft:gray_concrete
fill 214 250 359 214 251 359 minecraft:gray_concrete
fill 219 250 351 219 251 351 minecraft:gray_concrete
fill 219 250 359 219 251 359 minecraft:gray_concrete
fill 220 250 352 220 251 352 minecraft:gray_concrete
fill 220 250 358 220 251 358 minecraft:gray_concrete
fill 221 250 337 221 251 337 minecraft:lime_concrete
fill 221 250 354 221 251 356 minecraft:gray_concrete
fill 222 250 335 222 251 335 minecraft:lime_concrete
fill 222 250 339 222 251 339 minecraft:lime_concrete
fill 223 250 334 225 251 334 minecraft:lime_concrete
fill 223 250 340 225 251 340 minecraft:lime_concrete
setblock 224 250 322 minecraft:white_concrete
fill 227 250 336 227 251 336 minecraft:lime_concrete
fill 227 250 338 227 251 338 minecraft:lime_concrete
fill 228 250 364 228 308 364 minecraft:black_concrete
setblock 230 250 353 minecraft:white_concrete
setblock 230 250 362 minecraft:sea_lantern
fill 188 251 329 188 255 329 minecraft:black_concrete
setblock 188 251 330 minecraft:white_concrete
fill 188 251 351 188 282 351 minecraft:black_concrete
fill 190 251 354 190 252 355 minecraft:lime_concrete
fill 190 251 357 190 252 358 minecraft:lime_concrete
fill 191 251 353 191 252 353 minecraft:lime_concrete
fill 191 251 359 191 252 359 minecraft:lime_concrete
fill 193 251 352 193 252 352 minecraft:lime_concrete
fill 193 251 360 193 252 360 minecraft:lime_concrete
fill 195 251 353 195 252 353 minecraft:lime_concrete
fill 195 251 359 195 252 359 minecraft:lime_concrete
fill 196 251 354 196 252 354 minecraft:lime_concrete
fill 196 251 358 196 252 358 minecraft:lime_concrete
fill 197 251 355 197 252 357 minecraft:lime_concrete
setblock 204 251 364 minecraft:ochre_froglight
fill 211 251 354 211 251 355 minecraft:gray_concrete
fill 212 251 331 212 256 332 minecraft:gray_concrete
setblock 212 251 352 minecraft:gray_concrete
setblock 212 251 358 minecraft:gray_concrete
setblock 213 251 351 minecraft:gray_concrete
fill 213 251 358 213 257 358 minecraft:lime_concrete
setblock 213 251 359 minecraft:gray_concrete
fill 215 251 350 218 251 350 minecraft:gray_concrete
fill 215 251 360 218 251 360 minecraft:gray_concrete
fill 220 251 333 220 271 341 minecraft:light_gray_concrete
setblock 220 251 351 minecraft:gray_concrete
setblock 220 251 359 minecraft:gray_concrete
fill 221 251 333 221 271 334 minecraft:light_gray_concrete
fill 221 251 335 221 251 336 minecraft:lime_concrete
fill 221 251 338 221 251 339 minecraft:lime_concrete
fill 221 251 340 221 271 341 minecraft:light_gray_concrete
setblock 221 251 353 minecraft:gray_concrete
setblock 221 251 357 minecraft:gray_concrete
setblock 222 251 322 minecraft:sea_lantern
fill 222 251 333 229 271 333 minecraft:light_gray_concrete
setblock 222 251 334 minecraft:lime_concrete
setblock 222 251 340 minecraft:lime_concrete
fill 222 251 341 229 271 341 minecraft:light_gray_concrete
fill 224 251 322 224 308 322 minecraft:black_concrete
setblock 226 251 334 minecraft:lime_concrete
setblock 226 251 340 minecraft:lime_concrete
fill 227 251 334 229 271 334 minecraft:light_gray_concrete
setblock 227 251 335 minecraft:lime_concrete
setblock 227 251 339 minecraft:lime_concrete
fill 227 251 340 229 271 340 minecraft:light_gray_concrete
fill 228 251 335 229 271 335 minecraft:light_gray_concrete
fill 228 251 336 228 251 338 minecraft:lime_concrete
fill 228 251 339 229 271 339 minecraft:light_gray_concrete
fill 229 251 336 229 271 338 minecraft:light_gray_concrete
setblock 230 251 325 minecraft:white_concrete
fill 230 251 353 230 260 353 minecraft:black_concrete
fill 230 251 362 230 308 362 minecraft:black_concrete
fill 188 252 330 188 290 330 minecraft:black_concrete
setblock 188 252 362 minecraft:ochre_froglight
fill 189 252 351 189 252 353 minecraft:light_gray_concrete
fill 189 252 354 189 252 358 minecraft:lime_concrete
fill 189 252 359 189 252 361 minecraft:light_gray_concrete
fill 190 252 351 190 252 352 minecraft:light_gray_concrete
setblock 190 252 353 minecraft:lime_concrete
setblock 190 252 359 minecraft:lime_concrete
fill 190 252 360 190 252 361 minecraft:light_gray_concrete
fill 191 252 351 198 252 351 minecraft:light_gray_concrete
fill 191 252 352 192 252 352 minecraft:lime_concrete
fill 191 252 360 192 252 360 minecraft:lime_concrete
fill 191 252 361 198 252 361 minecraft:light_gray_concrete
fill 194 252 352 195 252 352 minecraft:lime_concrete
fill 194 252 360 195 252 360 minecraft:lime_concrete
fill 196 252 352 198 252 352 minecraft:light_gray_concrete
setblock 196 252 353 minecraft:lime_concrete
setblock 196 252 359 minecraft:lime_concrete
fill 196 252 360 198 252 360 minecraft:light_gray_concrete
fill 197 252 353 198 252 353 minecraft:light_gray_concrete
setblock 197 252 354 minecraft:lime_concrete
setblock 197 252 358 minecraft:lime_concrete
fill 197 252 359 198 252 359 minecraft:light_gray_concrete
fill 198 252 354 198 252 355 minecraft:light_gray_concrete
setblock 198 252 356 minecraft:lime_concrete
fill 198 252 357 198 252 358 minecraft:light_gray_concrete
fill 204 252 364 204 308 364 minecraft:black_concrete
setblock 205 252 364 minecraft:sea_lantern
fill 210 252 331 210 256 332 minecraft:gray_concrete
fill 211 252 330 211 256 330 minecraft:gray_concrete
fill 213 252 359 213 257 359 minecraft:lime_concrete
fill 216 252 354 217 252 356 minecraft:lime_stained_glass
fill 221 252 335 227 271 339 minecraft:light_gray_concrete
fill 222 252 322 222 263 322 minecraft:black_concrete
fill 222 252 334 226 271 334 minecraft:light_gray_concrete
fill 222 252 340 226 271 340 minecraft:light_gray_concrete
fill 228 252 336 228 271 338 minecraft:light_gray_concrete
fill 230 252 325 230 270 325 minecraft:black_concrete
setblock 230 252 351 minecraft:pearlescent_froglight
fill 230 252 352 230 272 352 minecraft:black_concrete
fill 188 253 362 188 264 362 minecraft:black_concrete
setblock 189 253 351 minecraft:verdant_froglight
fill 189 253 352 189 271 352 minecraft:light_gray_concrete
setblock 189 253 353 minecraft:verdant_froglight
fill 189 253 354 189 271 354 minecraft:light_gray_concrete
setblock 189 253 355 minecraft:verdant_froglight
fill 189 253 356 189 271 356 minecraft:light_gray_concrete
setblock 189 253 357 minecraft:verdant_froglight
fill 189 253 358 189 271 358 minecraft:light_gray_concrete
setblock 189 253 359 minecraft:verdant_froglight
fill 189 253 360 189 271 360 minecraft:light_gray_concrete
setblock 189 253 361 minecraft:verdant_froglight
fill 190 253 351 190 271 351 minecraft:light_gray_concrete
setblock 190 253 352 minecraft:verdant_froglight
fill 190 253 353 190 271 353 minecraft:light_gray_concrete
setblock 190 253 354 minecraft:verdant_froglight
fill 190 253 355 190 271 355 minecraft:light_gray_concrete
setblock 190 253 356 minecraft:verdant_froglight
fill 190 253 357 190 271 357 minecraft:light_gray_concrete
setblock 190 253 358 minecraft:verdant_froglight
fill 190 253 359 190 271 359 minecraft:light_gray_concrete
setblock 190 253 360 minecraft:verdant_froglight
fill 190 253 361 190 271 361 minecraft:light_gray_concrete
setblock 191 253 325 minecraft:light[level=12]
setblock 191 253 332 minecraft:light[level=12]
setblock 191 253 339 minecraft:light[level=12]
setblock 191 253 346 minecraft:light[level=12]
setblock 191 253 351 minecraft:verdant_froglight
fill 191 253 352 191 271 352 minecraft:light_gray_concrete
setblock 191 253 353 minecraft:verdant_froglight
fill 191 253 354 191 271 354 minecraft:light_gray_concrete
setblock 191 253 355 minecraft:verdant_froglight
fill 191 253 356 191 271 356 minecraft:light_gray_concrete
setblock 191 253 357 minecraft:verdant_froglight
fill 191 253 358 191 271 358 minecraft:light_gray_concrete
setblock 191 253 359 minecraft:verdant_froglight
fill 191 253 360 191 271 360 minecraft:light_gray_concrete
setblock 191 253 361 minecraft:verdant_froglight
fill 192 253 351 192 271 351 minecraft:light_gray_concrete
setblock 192 253 352 minecraft:verdant_froglight
fill 192 253 353 192 271 353 minecraft:light_gray_concrete
setblock 192 253 354 minecraft:verdant_froglight
fill 192 253 355 192 271 355 minecraft:light_gray_concrete
setblock 192 253 356 minecraft:verdant_froglight
fill 192 253 357 192 271 357 minecraft:light_gray_concrete
setblock 192 253 358 minecraft:verdant_froglight
fill 192 253 359 192 271 359 minecraft:light_gray_concrete
setblock 192 253 360 minecraft:verdant_froglight
fill 192 253 361 192 271 361 minecraft:light_gray_concrete
setblock 193 253 351 minecraft:verdant_froglight
fill 193 253 352 193 271 352 minecraft:light_gray_concrete
setblock 193 253 353 minecraft:verdant_froglight
fill 193 253 354 193 271 354 minecraft:light_gray_concrete
setblock 193 253 355 minecraft:verdant_froglight
fill 193 253 356 193 271 356 minecraft:light_gray_concrete
setblock 193 253 357 minecraft:verdant_froglight
fill 193 253 358 193 271 358 minecraft:light_gray_concrete
setblock 193 253 359 minecraft:verdant_froglight
fill 193 253 360 193 271 360 minecraft:light_gray_concrete
setblock 193 253 361 minecraft:verdant_froglight
fill 194 253 351 194 271 351 minecraft:light_gray_concrete
setblock 194 253 352 minecraft:verdant_froglight
fill 194 253 353 194 271 353 minecraft:light_gray_concrete
setblock 194 253 354 minecraft:verdant_froglight
fill 194 253 355 194 271 355 minecraft:light_gray_concrete
setblock 194 253 356 minecraft:verdant_froglight
fill 194 253 357 194 271 357 minecraft:light_gray_concrete
setblock 194 253 358 minecraft:verdant_froglight
fill 194 253 359 194 271 359 minecraft:light_gray_concrete
setblock 194 253 360 minecraft:verdant_froglight
fill 194 253 361 194 271 361 minecraft:light_gray_concrete
setblock 195 253 351 minecraft:verdant_froglight
fill 195 253 352 195 264 352 minecraft:light_gray_concrete
setblock 195 253 353 minecraft:verdant_froglight
fill 195 253 354 195 271 354 minecraft:light_gray_concrete
setblock 195 253 355 minecraft:verdant_froglight
fill 195 253 356 195 271 356 minecraft:light_gray_concrete
setblock 195 253 357 minecraft:verdant_froglight
fill 195 253 358 195 271 358 minecraft:light_gray_concrete
setblock 195 253 359 minecraft:verdant_froglight
fill 195 253 360 195 271 360 minecraft:light_gray_concrete
setblock 195 253 361 minecraft:verdant_froglight
fill 196 253 351 196 264 351 minecraft:light_gray_concrete
setblock 196 253 352 minecraft:verdant_froglight
fill 196 253 353 196 271 353 minecraft:light_gray_concrete
setblock 196 253 354 minecraft:verdant_froglight
fill 196 253 355 196 271 355 minecraft:light_gray_concrete
setblock 196 253 356 minecraft:verdant_froglight
fill 196 253 357 196 271 357 minecraft:light_gray_concrete
setblock 196 253 358 minecraft:verdant_froglight
fill 196 253 359 196 271 359 minecraft:light_gray_concrete
setblock 196 253 360 minecraft:verdant_froglight
fill 196 253 361 196 271 361 minecraft:light_gray_concrete
setblock 196 253 364 minecraft:white_concrete
setblock 197 253 351 minecraft:verdant_froglight
fill 197 253 352 197 264 352 minecraft:light_gray_concrete
setblock 197 253 353 minecraft:verdant_froglight
fill 197 253 354 197 271 354 minecraft:light_gray_concrete
setblock 197 253 355 minecraft:verdant_froglight
fill 197 253 356 197 271 356 minecraft:light_gray_concrete
setblock 197 253 357 minecraft:verdant_froglight
fill 197 253 358 197 271 358 minecraft:light_gray_concrete
setblock 197 253 359 minecraft:verdant_froglight
fill 197 253 360 197 271 360 minecraft:light_gray_concrete
setblock 197 253 361 minecraft:verdant_froglight
setblock 198 253 325 minecraft:light[level=12]
setblock 198 253 332 minecraft:light[level=12]
setblock 198 253 339 minecraft:light[level=12]
setblock 198 253 346 minecraft:light[level=12]
fill 198 253 351 198 271 351 minecraft:light_gray_concrete
setblock 198 253 352 minecraft:verdant_froglight
fill 198 253 353 198 271 353 minecraft:light_gray_concrete
setblock 198 253 354 minecraft:verdant_froglight
fill 198 253 355 198 271 355 minecraft:light_gray_concrete
setblock 198 253 356 minecraft:verdant_froglight
fill 198 253 357 198 271 357 minecraft:light_gray_concrete
setblock 198 253 358 minecraft:verdant_froglight
fill 198 253 359 198 271 359 minecraft:light_gray_concrete
setblock 198 253 360 minecraft:verdant_froglight
fill 198 253 361 198 271 361 minecraft:light_gray_concrete
setblock 202 253 364 minecraft:sea_lantern
setblock 205 253 325 minecraft:light[level=12]
setblock 205 253 332 minecraft:light[level=12]
setblock 205 253 339 minecraft:light[level=12]
setblock 205 253 346 minecraft:light[level=12]
setblock 205 253 353 minecraft:light[level=12]
setblock 205 253 360 minecraft:light[level=12]
fill 205 253 364 205 286 364 minecraft:black_concrete
setblock 207 253 322 minecraft:white_concrete
fill 210 253 330 210 256 330 minecraft:gray_concrete
fill 210 253 333 212 256 333 minecraft:gray_concrete
setblock 212 253 325 minecraft:light[level=12]
fill 212 253 330 212 256 330 minecraft:gray_concrete
setblock 212 253 339 minecraft:light[level=12]
setblock 212 253 346 minecraft:light[level=12]
setblock 212 253 353 minecraft:light[level=12]
fill 212 253 357 212 257 359 minecraft:lime_concrete
setblock 212 253 360 minecraft:light[level=12]
fill 213 253 331 213 256 332 minecraft:gray_concrete
fill 213 253 357 214 257 357 minecraft:lime_concrete
fill 214 253 358 214 257 359 minecraft:lime_concrete
fill 216 253 354 216 253 355 minecraft:lime_stained_glass
fill 217 253 355 217 254 355 minecraft:lime_stained_glass
setblock 219 253 325 minecraft:light[level=12]
setblock 219 253 332 minecraft:light[level=12]
setblock 219 253 339 minecraft:light[level=12]
setblock 219 253 346 minecraft:light[level=12]
setblock 219 253 353 minecraft:light[level=12]
setblock 219 253 360 minecraft:light[level=12]
setblock 226 253 325 minecraft:light[level=12]
setblock 226 253 332 minecraft:light[level=12]
setblock 226 253 346 minecraft:light[level=12]
setblock 226 253 353 minecraft:light[level=12]
setblock 226 253 360 minecraft:light[level=12]
setblock 230 253 331 minecraft:sea_lantern
fill 230 253 351 230 308 351 minecraft:black_concrete
setblock 188 254 324 minecraft:pearlescent_froglight
setblock 188 254 332 minecraft:pearlescent_froglight
setblock 188 254 335 minecraft:ochre_froglight
fill 189 254 351 189 255 351 minecraft:light_gray_concrete
fill 189 254 353 189 255 353 minecraft:light_gray_concrete
fill 189 254 355 189 255 355 minecraft:light_gray_concrete
fill 189 254 357 189 255 357 minecraft:light_gray_concrete
fill 189 254 359 189 255 359 minecraft:light_gray_concrete
fill 189 254 361 189 255 361 minecraft:light_gray_concrete
fill 190 254 352 190 255 352 minecraft:light_gray_concrete
fill 190 254 354 190 255 354 minecraft:light_gray_concrete
fill 190 254 356 190 255 356 minecraft:light_gray_concrete
fill 190 254 358 190 255 358 minecraft:light_gray_concrete
fill 190 254 360 190 255 360 minecraft:light_gray_concrete
fill 191 254 351 191 255 351 minecraft:light_gray_concrete
fill 191 254 353 191 255 353 minecraft:light_gray_concrete
fill 191 254 355 191 255 355 minecraft:light_gray_concrete
fill 191 254 357 191 255 357 minecraft:light_gray_concrete
fill 191 254 359 191 255 359 minecraft:light_gray_concrete
fill 191 254 361 191 255 361 minecraft:light_gray_concrete
fill 192 254 352 192 255 352 minecraft:light_gray_concrete
fill 192 254 354 192 255 354 minecraft:light_gray_concrete
fill 192 254 356 192 255 356 minecraft:light_gray_concrete
fill 192 254 358 192 255 358 minecraft:light_gray_concrete
fill 192 254 360 192 255 360 minecraft:light_gray_concrete
fill 193 254 351 193 255 351 minecraft:light_gray_concrete
fill 193 254 353 193 255 353 minecraft:light_gray_concrete
fill 193 254 355 193 255 355 minecraft:light_gray_concrete
fill 193 254 357 193 255 357 minecraft:light_gray_concrete
fill 193 254 359 193 255 359 minecraft:light_gray_concrete
fill 193 254 361 193 255 361 minecraft:light_gray_concrete
fill 194 254 352 194 255 352 minecraft:light_gray_concrete
fill 194 254 354 194 255 354 minecraft:light_gray_concrete
fill 194 254 356 194 255 356 minecraft:light_gray_concrete
fill 194 254 358 194 255 358 minecraft:light_gray_concrete
fill 194 254 360 194 255 360 minecraft:light_gray_concrete
fill 195 254 351 195 255 351 minecraft:light_gray_concrete
fill 195 254 353 195 255 353 minecraft:light_gray_concrete
fill 195 254 355 195 255 355 minecraft:light_gray_concrete
fill 195 254 357 195 255 357 minecraft:light_gray_concrete
fill 195 254 359 195 255 359 minecraft:light_gray_concrete
fill 195 254 361 195 255 361 minecraft:light_gray_concrete
fill 196 254 352 196 255 352 minecraft:light_gray_concrete
fill 196 254 354 196 255 354 minecraft:light_gray_concrete
fill 196 254 356 196 255 356 minecraft:light_gray_concrete
fill 196 254 358 196 255 358 minecraft:light_gray_concrete
fill 196 254 360 196 255 360 minecraft:light_gray_concrete
fill 196 254 364 196 264 364 minecraft:black_concrete
fill 197 254 351 197 255 351 minecraft:light_gray_concrete
fill 197 254 353 197 255 353 minecraft:light_gray_concrete
fill 197 254 355 197 255 355 minecraft:light_gray_concrete
fill 197 254 357 197 255 357 minecraft:light_gray_concrete
fill 197 254 359 197 255 359 minecraft:light_gray_concrete
fill 197 254 361 197 255 361 minecraft:light_gray_concrete
fill 198 254 352 198 255 352 minecraft:light_gray_concrete
fill 198 254 354 198 255 354 minecraft:light_gray_concrete
fill 198 254 356 198 255 356 minecraft:light_gray_concrete
fill 198 254 358 198 255 358 minecraft:light_gray_concrete
fill 198 254 360 198 255 360 minecraft:light_gray_concrete
setblock 199 254 364 minecraft:ochre_froglight
fill 202 254 364 202 270 364 minecraft:black_concrete
setblock 206 254 322 minecraft:sea_lantern
fill 207 254 322 207 277 322 minecraft:black_concrete
fill 209 254 331 209 256 332 minecraft:gray_concrete
fill 211 254 358 211 257 359 minecraft:lime_concrete
fill 212 254 360 214 257 360 minecraft:lime_concrete
fill 213 254 330 213 256 330 minecraft:gray_concrete
fill 213 254 356 213 257 356 minecraft:lime_concrete
fill 215 254 358 215 257 359 minecraft:lime_concrete
fill 216 254 355 216 255 355 minecraft:lime_stained_glass
fill 230 254 331 230 264 331 minecraft:black_concrete
fill 188 255 324 188 307 324 minecraft:black_concrete
fill 188 255 332 188 308 332 minecraft:black_concrete
fill 188 255 335 188 265 335 minecraft:black_concrete
setblock 188 255 357 minecraft:ochre_froglight
fill 199 255 364 199 291 364 minecraft:black_concrete
setblock 201 255 322 minecraft:ochre_froglight
fill 206 255 322 206 257 322 minecraft:black_concrete
fill 209 255 330 209 256 330 minecraft:gray_concrete
fill 209 255 333 209 256 333 minecraft:gray_concrete
fill 210 255 329 212 256 329 minecraft:gray_concrete
fill 210 255 334 212 256 334 minecraft:gray_concrete
fill 211 255 357 211 257 357 minecraft:lime_concrete
fill 211 255 360 211 257 360 minecraft:lime_concrete
fill 212 255 356 212 257 356 minecraft:lime_concrete
fill 212 255 361 214 257 361 minecraft:lime_concrete
fill 213 255 333 213 256 333 minecraft:gray_concrete
fill 214 255 356 214 257 356 minecraft:lime_concrete
fill 215 255 357 215 257 357 minecraft:lime_concrete
fill 215 255 360 215 257 360 minecraft:lime_concrete
setblock 230 255 339 minecraft:ochre_froglight
setblock 188 256 329 minecraft:white_concrete
setblock 188 256 343 minecraft:pearlescent_froglight
setblock 188 256 344 minecraft:ochre_froglight
fill 188 256 357 188 279 357 minecraft:black_concrete
setblock 189 256 351 minecraft:verdant_froglight
setblock 189 256 353 minecraft:verdant_froglight
setblock 189 256 355 minecraft:verdant_froglight
setblock 189 256 357 minecraft:verdant_froglight
setblock 189 256 359 minecraft:verdant_froglight
setblock 189 256 361 minecraft:verdant_froglight
setblock 190 256 352 minecraft:verdant_froglight
setblock 190 256 354 minecraft:verdant_froglight
setblock 190 256 356 minecraft:verdant_froglight
setblock 190 256 358 minecraft:verdant_froglight
setblock 190 256 360 minecraft:verdant_froglight
setblock 191 256 351 minecraft:verdant_froglight
setblock 191 256 353 minecraft:verdant_froglight
setblock 191 256 355 minecraft:verdant_froglight
setblock 191 256 357 minecraft:verdant_froglight
setblock 191 256 359 minecraft:verdant_froglight
setblock 191 256 361 minecraft:verdant_froglight
setblock 192 256 352 minecraft:verdant_froglight
setblock 192 256 354 minecraft:verdant_froglight
setblock 192 256 356 minecraft:verdant_froglight
setblock 192 256 358 minecraft:verdant_froglight
setblock 192 256 360 minecraft:verdant_froglight
setblock 193 256 351 minecraft:verdant_froglight
setblock 193 256 353 minecraft:verdant_froglight
setblock 193 256 355 minecraft:verdant_froglight
setblock 193 256 357 minecraft:verdant_froglight
setblock 193 256 359 minecraft:verdant_froglight
setblock 193 256 361 minecraft:verdant_froglight
setblock 194 256 352 minecraft:verdant_froglight
setblock 194 256 354 minecraft:verdant_froglight
setblock 194 256 356 minecraft:verdant_froglight
setblock 194 256 358 minecraft:verdant_froglight
setblock 194 256 360 minecraft:verdant_froglight
setblock 195 256 351 minecraft:verdant_froglight
setblock 195 256 353 minecraft:verdant_froglight
setblock 195 256 355 minecraft:verdant_froglight
setblock 195 256 357 minecraft:verdant_froglight
setblock 195 256 359 minecraft:verdant_froglight
setblock 195 256 361 minecraft:verdant_froglight
setblock 196 256 352 minecraft:verdant_froglight
setblock 196 256 354 minecraft:verdant_froglight
setblock 196 256 356 minecraft:verdant_froglight
setblock 196 256 358 minecraft:verdant_froglight
setblock 196 256 360 minecraft:verdant_froglight
setblock 197 256 351 minecraft:verdant_froglight
setblock 197 256 353 minecraft:verdant_froglight
setblock 197 256 355 minecraft:verdant_froglight
setblock 197 256 357 minecraft:verdant_froglight
setblock 197 256 359 minecraft:verdant_froglight
setblock 197 256 361 minecraft:verdant_froglight
setblock 198 256 352 minecraft:verdant_froglight
setblock 198 256 354 minecraft:verdant_froglight
setblock 198 256 356 minecraft:verdant_froglight
setblock 198 256 358 minecraft:verdant_froglight
setblock 198 256 360 minecraft:verdant_froglight
fill 201 256 322 201 291 322 minecraft:black_concrete
fill 208 256 331 208 256 332 minecraft:gray_concrete
setblock 209 256 329 minecraft:gray_concrete
setblock 209 256 334 minecraft:gray_concrete
fill 210 256 357 210 257 360 minecraft:lime_concrete
fill 211 256 356 211 257 356 minecraft:lime_concrete
fill 211 256 361 211 257 361 minecraft:lime_concrete
fill 212 256 355 214 257 355 minecraft:lime_concrete
setblock 213 256 329 minecraft:gray_concrete
setblock 213 256 334 minecraft:gray_concrete
fill 214 256 330 214 256 333 minecraft:gray_concrete
fill 215 256 356 215 257 356 minecraft:lime_concrete
fill 215 256 361 215 257 361 minecraft:lime_concrete
fill 216 256 357 216 257 360 minecraft:lime_concrete
fill 230 256 339 230 272 339 minecraft:black_concrete
setblock 188 257 329 minecraft:black_concrete
fill 188 257 343 188 279 344 minecraft:black_concrete
fill 189 257 351 189 258 351 minecraft:light_gray_concrete
fill 189 257 353 189 258 353 minecraft:light_gray_concrete
fill 189 257 355 189 258 355 minecraft:light_gray_concrete
fill 189 257 357 189 258 357 minecraft:light_gray_concrete
fill 189 257 359 189 258 359 minecraft:light_gray_concrete
fill 189 257 361 189 258 361 minecraft:light_gray_concrete
fill 190 257 352 190 258 352 minecraft:light_gray_concrete
fill 190 257 354 190 258 354 minecraft:light_gray_concrete
fill 190 257 356 190 258 356 minecraft:light_gray_concrete
fill 190 257 358 190 258 358 minecraft:light_gray_concrete
fill 190 257 360 190 258 360 minecraft:light_gray_concrete
setblock 191 257 325 minecraft:light[level=15]
setblock 191 257 333 minecraft:light[level=15]
setblock 191 257 341 minecraft:light[level=15]
setblock 191 257 349 minecraft:light[level=15]
fill 191 257 351 191 258 351 minecraft:light_gray_concrete
fill 191 257 353 191 258 353 minecraft:light_gray_concrete
fill 191 257 355 191 258 355 minecraft:light_gray_concrete
fill 191 257 357 191 258 357 minecraft:light_gray_concrete
fill 191 257 359 191 258 359 minecraft:light_gray_concrete
fill 191 257 361 191 258 361 minecraft:light_gray_concrete
fill 192 257 352 192 258 352 minecraft:light_gray_concrete
fill 192 257 354 192 258 354 minecraft:light_gray_concrete
fill 192 257 356 192 258 356 minecraft:light_gray_concrete
fill 192 257 358 192 258 358 minecraft:light_gray_concrete
fill 192 257 360 192 258 360 minecraft:light_gray_concrete
fill 193 257 351 193 258 351 minecraft:light_gray_concrete
fill 193 257 353 193 258 353 minecraft:light_gray_concrete
fill 193 257 355 193 258 355 minecraft:light_gray_concrete
fill 193 257 357 193 258 357 minecraft:light_gray_concrete
fill 193 257 359 193 258 359 minecraft:light_gray_concrete
fill 193 257 361 193 258 361 minecraft:light_gray_concrete
fill 194 257 352 194 258 352 minecraft:light_gray_concrete
fill 194 257 354 194 258 354 minecraft:light_gray_concrete
fill 194 257 356 194 258 356 minecraft:light_gray_concrete
fill 194 257 358 194 258 358 minecraft:light_gray_concrete
fill 194 257 360 194 258 360 minecraft:light_gray_concrete
fill 195 257 351 195 258 351 minecraft:light_gray_concrete
fill 195 257 353 195 258 353 minecraft:light_gray_concrete
fill 195 257 355 195 258 355 minecraft:light_gray_concrete
fill 195 257 357 195 258 357 minecraft:light_gray_concrete
fill 195 257 359 195 258 359 minecraft:light_gray_concrete
fill 195 257 361 195 258 361 minecraft:light_gray_concrete
setblock 196 257 322 minecraft:ochre_froglight
fill 196 257 352 196 258 352 minecraft:light_gray_concrete
fill 196 257 354 196 258 354 minecraft:light_gray_concrete
fill 196 257 356 196 258 356 minecraft:light_gray_concrete
fill 196 257 358 196 258 358 minecraft:light_gray_concrete
fill 196 257 360 196 258 360 minecraft:light_gray_concrete
fill 197 257 351 197 258 351 minecraft:light_gray_concrete
fill 197 257 353 197 258 353 minecraft:light_gray_concrete
fill 197 257 355 197 258 355 minecraft:light_gray_concrete
fill 197 257 357 197 258 357 minecraft:light_gray_concrete
fill 197 257 359 197 258 359 minecraft:light_gray_concrete
fill 197 257 361 197 258 361 minecraft:light_gray_concrete
fill 198 257 352 198 258 352 minecraft:light_gray_concrete
fill 198 257 354 198 258 354 minecraft:light_gray_concrete
fill 198 257 356 198 258 356 minecraft:light_gray_concrete
fill 198 257 358 198 258 358 minecraft:light_gray_concrete
fill 198 257 360 198 258 360 minecraft:light_gray_concrete
setblock 199 257 325 minecraft:light[level=15]
setblock 199 257 333 minecraft:light[level=15]
setblock 199 257 341 minecraft:light[level=15]
setblock 199 257 349 minecraft:light[level=15]
setblock 199 257 357 minecraft:light[level=15]
setblock 207 257 325 minecraft:light[level=15]
setblock 207 257 333 minecraft:light[level=15]
setblock 207 257 341 minecraft:light[level=15]
setblock 207 257 349 minecraft:light[level=15]
fill 207 257 354 208 257 363 minecraft:light_gray_concrete
fill 209 257 354 209 258 356 minecraft:light_gray_concrete
fill 209 257 357 209 257 359 minecraft:lime_concrete
fill 209 257 360 209 257 363 minecraft:light_gray_concrete
fill 210 257 331 212 257 332 minecraft:lime_stained_glass
fill 210 257 354 210 258 355 minecraft:light_gray_concrete
setblock 210 257 356 minecraft:lime_concrete
setblock 210 257 361 minecraft:lime_concrete
fill 210 257 362 210 258 363 minecraft:light_gray_concrete
fill 211 257 354 212 258 354 minecraft:light_gray_concrete
setblock 211 257 355 minecraft:lime_concrete
fill 211 257 362 215 257 362 minecraft:lime_concrete
fill 211 257 363 219 258 363 minecraft:light_gray_concrete
setblock 213 257 354 minecraft:lime_concrete
setblock 213 257 364 minecraft:white_concrete
fill 214 257 354 219 258 354 minecraft:light_gray_concrete
setblock 215 257 325 minecraft:light[level=15]
setblock 215 257 333 minecraft:light[level=15]
setblock 215 257 341 minecraft:light[level=15]
setblock 215 257 349 minecraft:light[level=15]
setblock 215 257 355 minecraft:lime_concrete
fill 216 257 355 219 258 355 minecraft:light_gray_concrete
setblock 216 257 356 minecraft:lime_concrete
setblock 216 257 361 minecraft:lime_concrete
fill 216 257 362 219 258 362 minecraft:light_gray_concrete
fill 217 257 356 219 258 356 minecraft:light_gray_concrete
fill 217 257 357 217 257 359 minecraft:lime_concrete
fill 217 257 360 219 258 361 minecraft:light_gray_concrete
fill 218 257 357 219 258 359 minecraft:light_gray_concrete
setblock 223 257 325 minecraft:light[level=15]
setblock 223 257 349 minecraft:light[level=15]
setblock 223 257 357 minecraft:light[level=15]
setblock 230 257 357 minecraft:sea_lantern
setblock 188 258 329 minecraft:sea_lantern
setblock 188 258 341 minecraft:ochre_froglight
fill 196 258 322 196 271 322 minecraft:black_concrete
setblock 206 258 322 minecraft:sea_lantern
setblock 206 258 364 minecraft:white_concrete
fill 207 258 354 207 258 363 minecraft:light_gray_concrete
fill 208 258 354 208 258 359 minecraft:light_gray_concrete
fill 208 258 360 209 258 361 minecraft:gray_concrete
fill 208 258 362 209 258 363 minecraft:light_gray_concrete
fill 209 258 357 217 258 359 minecraft:light_gray_concrete
fill 210 258 356 216 258 356 minecraft:light_gray_concrete
fill 210 258 360 216 258 361 minecraft:light_gray_concrete
fill 211 258 331 212 258 332 minecraft:lime_stained_glass
fill 211 258 355 215 258 355 minecraft:light_gray_concrete
fill 211 258 362 215 258 362 minecraft:light_gray_concrete
fill 213 258 354 213 271 354 minecraft:light_gray_concrete
fill 213 258 364 213 276 364 minecraft:black_concrete
fill 230 258 357 230 308 357 minecraft:black_concrete
fill 188 259 329 188 290 329 minecraft:black_concrete
fill 188 259 341 188 308 341 minecraft:black_concrete
setblock 189 259 351 minecraft:verdant_froglight
setblock 189 259 353 minecraft:verdant_froglight
setblock 189 259 355 minecraft:verdant_froglight
setblock 189 259 357 minecraft:verdant_froglight
setblock 189 259 359 minecraft:verdant_froglight
setblock 189 259 361 minecraft:verdant_froglight
setblock 190 259 352 minecraft:verdant_froglight
setblock 190 259 354 minecraft:verdant_froglight
setblock 190 259 356 minecraft:verdant_froglight
setblock 190 259 358 minecraft:verdant_froglight
setblock 190 259 360 minecraft:verdant_froglight
setblock 191 259 325 minecraft:light[level=12]
setblock 191 259 332 minecraft:light[level=12]
setblock 191 259 339 minecraft:light[level=12]
setblock 191 259 346 minecraft:light[level=12]
setblock 191 259 351 minecraft:verdant_froglight
setblock 191 259 353 minecraft:verdant_froglight
setblock 191 259 355 minecraft:verdant_froglight
setblock 191 259 357 minecraft:verdant_froglight
setblock 191 259 359 minecraft:verdant_froglight
setblock 191 259 361 minecraft:verdant_froglight
setblock 192 259 352 minecraft:verdant_froglight
setblock 192 259 354 minecraft:verdant_froglight
setblock 192 259 356 minecraft:verdant_froglight
setblock 192 259 358 minecraft:verdant_froglight
setblock 192 259 360 minecraft:verdant_froglight
setblock 193 259 351 minecraft:verdant_froglight
setblock 193 259 353 minecraft:verdant_froglight
setblock 193 259 355 minecraft:verdant_froglight
setblock 193 259 357 minecraft:verdant_froglight
setblock 193 259 359 minecraft:verdant_froglight
setblock 193 259 361 minecraft:verdant_froglight
setblock 194 259 352 minecraft:verdant_froglight
setblock 194 259 354 minecraft:verdant_froglight
setblock 194 259 356 minecraft:verdant_froglight
setblock 194 259 358 minecraft:verdant_froglight
setblock 194 259 360 minecraft:verdant_froglight
setblock 195 259 351 minecraft:verdant_froglight
setblock 195 259 353 minecraft:verdant_froglight
setblock 195 259 355 minecraft:verdant_froglight
setblock 195 259 357 minecraft:verdant_froglight
setblock 195 259 359 minecraft:verdant_froglight
setblock 195 259 361 minecraft:verdant_froglight
setblock 196 259 352 minecraft:verdant_froglight
setblock 196 259 354 minecraft:verdant_froglight
setblock 196 259 356 minecraft:verdant_froglight
setblock 196 259 358 minecraft:verdant_froglight
setblock 196 259 360 minecraft:verdant_froglight
setblock 197 259 351 minecraft:verdant_froglight
setblock 197 259 353 minecraft:verdant_froglight
setblock 197 259 355 minecraft:verdant_froglight
setblock 197 259 357 minecraft:verdant_froglight
setblock 197 259 359 minecraft:verdant_froglight
setblock 197 259 361 minecraft:verdant_froglight
setblock 198 259 325 minecraft:light[level=12]
setblock 198 259 332 minecraft:light[level=12]
setblock 198 259 339 minecraft:light[level=12]
setblock 198 259 346 minecraft:light[level=12]
setblock 198 259 352 minecraft:verdant_froglight
setblock 198 259 354 minecraft:verdant_froglight
setblock 198 259 356 minecraft:verdant_froglight
setblock 198 259 358 minecraft:verdant_froglight
setblock 198 259 360 minecraft:verdant_froglight
setblock 205 259 325 minecraft:light[level=12]
setblock 205 259 332 minecraft:light[level=12]
setblock 205 259 339 minecraft:light[level=12]
setblock 205 259 346 minecraft:light[level=12]
setblock 205 259 353 minecraft:light[level=12]
setblock 205 259 360 minecraft:light[level=12]
fill 206 259 322 206 308 322 minecraft:black_concrete
fill 206 259 364 206 268 364 minecraft:black_concrete
fill 207 259 354 207 271 354 minecraft:light_gray_concrete
setblock 207 259 355 minecraft:verdant_froglight
fill 207 259 356 207 271 356 minecraft:light_gray_concrete
setblock 207 259 357 minecraft:verdant_froglight
fill 207 259 358 207 271 358 minecraft:light_gray_concrete
setblock 207 259 359 minecraft:verdant_froglight
fill 207 259 360 207 271 360 minecraft:light_gray_concrete
setblock 207 259 361 minecraft:verdant_froglight
fill 207 259 362 207 271 362 minecraft:light_gray_concrete
setblock 207 259 363 minecraft:verdant_froglight
setblock 208 259 322 minecraft:sea_lantern
setblock 208 259 354 minecraft:verdant_froglight
fill 208 259 355 208 271 355 minecraft:light_gray_concrete
setblock 208 259 356 minecraft:verdant_froglight
fill 208 259 357 208 271 357 minecraft:light_gray_concrete
setblock 208 259 358 minecraft:verdant_froglight
fill 208 259 359 208 271 359 minecraft:light_gray_concrete
setblock 208 259 360 minecraft:verdant_froglight
setblock 208 259 361 minecraft:gray_concrete
setblock 208 259 362 minecraft:verdant_froglight
fill 208 259 363 208 271 363 minecraft:light_gray_concrete
fill 209 259 354 209 271 354 minecraft:light_gray_concrete
setblock 209 259 355 minecraft:verdant_froglight
fill 209 259 356 209 271 356 minecraft:light_gray_concrete
setblock 209 259 357 minecraft:verdant_froglight
fill 209 259 358 209 271 358 minecraft:light_gray_concrete
setblock 209 259 359 minecraft:verdant_froglight
setblock 209 259 360 minecraft:gray_concrete
setblock 209 259 361 minecraft:verdant_froglight
fill 209 259 362 209 271 362 minecraft:light_gray_concrete
setblock 209 259 363 minecraft:verdant_froglight
setblock 210 259 354 minecraft:verdant_froglight
fill 210 259 355 210 271 355 minecraft:light_gray_concrete
setblock 210 259 356 minecraft:verdant_froglight
fill 210 259 357 210 271 357 minecraft:light_gray_concrete
setblock 210 259 358 minecraft:verdant_froglight
fill 210 259 359 210 271 359 minecraft:light_gray_concrete
setblock 210 259 360 minecraft:verdant_froglight
fill 210 259 361 210 271 361 minecraft:light_gray_concrete
setblock 210 259 362 minecraft:verdant_froglight
fill 210 259 363 210 271 363 minecraft:light_gray_concrete
fill 211 259 331 211 259 332 minecraft:lime_stained_glass
fill 211 259 354 211 271 354 minecraft:light_gray_concrete
setblock 211 259 355 minecraft:verdant_froglight
fill 211 259 356 211 271 356 minecraft:light_gray_concrete
setblock 211 259 357 minecraft:verdant_froglight
fill 211 259 358 211 271 358 minecraft:light_gray_concrete
setblock 211 259 359 minecraft:verdant_froglight
fill 211 259 360 211 271 360 minecraft:light_gray_concrete
setblock 211 259 361 minecraft:verdant_froglight
fill 211 259 362 211 271 362 minecraft:light_gray_concrete
setblock 211 259 363 minecraft:verdant_froglight
setblock 212 259 325 minecraft:light[level=12]
setblock 212 259 332 minecraft:light[level=12]
setblock 212 259 339 minecraft:light[level=12]
setblock 212 259 346 minecraft:light[level=12]
setblock 212 259 353 minecraft:light[level=12]
setblock 212 259 354 minecraft:verdant_froglight
fill 212 259 355 212 271 355 minecraft:light_gray_concrete
setblock 212 259 356 minecraft:verdant_froglight
fill 212 259 357 212 271 357 minecraft:light_gray_concrete
setblock 212 259 358 minecraft:verdant_froglight
fill 212 259 359 212 271 359 minecraft:light_gray_concrete
setblock 212 259 360 minecraft:verdant_froglight
fill 212 259 361 212 271 361 minecraft:light_gray_concrete
setblock 212 259 362 minecraft:verdant_froglight
fill 212 259 363 212 271 363 minecraft:light_gray_concrete
setblock 213 259 355 minecraft:verdant_froglight
fill 213 259 356 213 271 356 minecraft:light_gray_concrete
setblock 213 259 357 minecraft:verdant_froglight
fill 213 259 358 213 271 358 minecraft:light_gray_concrete
setblock 213 259 359 minecraft:verdant_froglight
fill 213 259 360 213 271 360 minecraft:light_gray_concrete
setblock 213 259 361 minecraft:verdant_froglight
fill 213 259 362 213 271 362 minecraft:light_gray_concrete
setblock 213 259 363 minecraft:verdant_froglight
setblock 214 259 354 minecraft:verdant_froglight
fill 214 259 355 214 271 355 minecraft:light_gray_concrete
setblock 214 259 356 minecraft:verdant_froglight
fill 214 259 357 214 271 357 minecraft:light_gray_concrete
setblock 214 259 358 minecraft:verdant_froglight
fill 214 259 359 214 271 359 minecraft:light_gray_concrete
setblock 214 259 360 minecraft:verdant_froglight
fill 214 259 361 214 271 361 minecraft:light_gray_concrete
setblock 214 259 362 minecraft:verdant_froglight
fill 214 259 363 214 271 363 minecraft:light_gray_concrete
fill 215 259 354 215 271 354 minecraft:light_gray_concrete
setblock 215 259 355 minecraft:verdant_froglight
fill 215 259 356 215 271 356 minecraft:light_gray_concrete
setblock 215 259 357 minecraft:verdant_froglight
fill 215 259 358 215 271 358 minecraft:light_gray_concrete
setblock 215 259 359 minecraft:verdant_froglight
fill 215 259 360 215 271 360 minecraft:light_gray_concrete
setblock 215 259 361 minecraft:verdant_froglight
fill 215 259 362 215 271 362 minecraft:light_gray_concrete
setblock 215 259 363 minecraft:verdant_froglight
setblock 216 259 354 minecraft:verdant_froglight
fill 216 259 355 216 271 355 minecraft:light_gray_concrete
setblock 216 259 356 minecraft:verdant_froglight
fill 216 259 357 216 271 357 minecraft:light_gray_concrete
setblock 216 259 358 minecraft:verdant_froglight
fill 216 259 359 216 271 359 minecraft:light_gray_concrete
setblock 216 259 360 minecraft:verdant_froglight
fill 216 259 361 216 271 361 minecraft:light_gray_concrete
setblock 216 259 362 minecraft:verdant_froglight
fill 216 259 363 216 271 363 minecraft:light_gray_concrete
fill 217 259 354 217 271 354 minecraft:light_gray_concrete
setblock 217 259 355 minecraft:verdant_froglight
fill 217 259 356 217 271 356 minecraft:light_gray_concrete
setblock 217 259 357 minecraft:verdant_froglight
fill 217 259 358 217 271 358 minecraft:light_gray_concrete
setblock 217 259 359 minecraft:verdant_froglight
fill 217 259 360 217 271 360 minecraft:light_gray_concrete
setblock 217 259 361 minecraft:verdant_froglight
fill 217 259 362 217 271 362 minecraft:light_gray_concrete
setblock 217 259 363 minecraft:verdant_froglight
setblock 218 259 354 minecraft:verdant_froglight
fill 218 259 355 218 271 355 minecraft:light_gray_concrete
setblock 218 259 356 minecraft:verdant_froglight
fill 218 259 357 218 271 357 minecraft:light_gray_concrete
setblock 218 259 358 minecraft:verdant_froglight
fill 218 259 359 218 271 359 minecraft:light_gray_concrete
setblock 218 259 360 minecraft:verdant_froglight
fill 218 259 361 218 271 361 minecraft:light_gray_concrete
setblock 218 259 362 minecraft:verdant_froglight
fill 218 259 363 218 271 363 minecraft:light_gray_concrete
setblock 219 259 325 minecraft:light[level=12]
setblock 219 259 332 minecraft:light[level=12]
setblock 219 259 339 minecraft:light[level=12]
setblock 219 259 346 minecraft:light[level=12]
setblock 219 259 353 minecraft:light[level=12]
fill 219 259 354 219 271 354 minecraft:light_gray_concrete
setblock 219 259 355 minecraft:verdant_froglight
fill 219 259 356 219 271 356 minecraft:light_gray_concrete
setblock 219 259 357 minecraft:verdant_froglight
fill 219 259 358 219 271 358 minecraft:light_gray_concrete
setblock 219 259 359 minecraft:verdant_froglight
fill 219 259 360 219 271 360 minecraft:light_gray_concrete
setblock 219 259 361 minecraft:verdant_froglight
fill 219 259 362 219 271 362 minecraft:light_gray_concrete
setblock 219 259 363 minecraft:verdant_froglight
setblock 226 259 325 minecraft:light[level=12]
setblock 226 259 332 minecraft:light[level=12]
setblock 226 259 346 minecraft:light[level=12]
setblock 226 259 353 minecraft:light[level=12]
setblock 226 259 360 minecraft:light[level=12]
setblock 229 259 322 minecraft:white_concrete
fill 189 260 351 189 261 351 minecraft:light_gray_concrete
fill 189 260 353 189 261 353 minecraft:light_gray_concrete
fill 189 260 355 189 261 355 minecraft:light_gray_concrete
fill 189 260 357 189 261 357 minecraft:light_gray_concrete
fill 189 260 359 189 261 359 minecraft:light_gray_concrete
fill 189 260 361 189 261 361 minecraft:light_gray_concrete
setblock 190 260 322 minecraft:sea_lantern
fill 190 260 352 190 261 352 minecraft:light_gray_concrete
fill 190 260 354 190 261 354 minecraft:light_gray_concrete
fill 190 260 356 190 261 356 minecraft:light_gray_concrete
fill 190 260 358 190 261 358 minecraft:light_gray_concrete
fill 190 260 360 190 261 360 minecraft:light_gray_concrete
fill 191 260 351 191 261 351 minecraft:light_gray_concrete
fill 191 260 353 191 261 353 minecraft:light_gray_concrete
fill 191 260 355 191 261 355 minecraft:light_gray_concrete
fill 191 260 357 191 261 357 minecraft:light_gray_concrete
fill 191 260 359 191 261 359 minecraft:light_gray_concrete
fill 191 260 361 191 261 361 minecraft:light_gray_concrete
fill 192 260 352 192 261 352 minecraft:light_gray_concrete
fill 192 260 354 192 261 354 minecraft:light_gray_concrete
fill 192 260 356 192 261 356 minecraft:light_gray_concrete
fill 192 260 358 192 261 358 minecraft:light_gray_concrete
fill 192 260 360 192 261 360 minecraft:light_gray_concrete
fill 193 260 351 193 261 351 minecraft:light_gray_concrete
fill 193 260 353 193 261 353 minecraft:light_gray_concrete
fill 193 260 355 193 261 355 minecraft:light_gray_concrete
fill 193 260 357 193 261 357 minecraft:light_gray_concrete
fill 193 260 359 193 261 359 minecraft:light_gray_concrete
fill 193 260 361 193 261 361 minecraft:light_gray_concrete
fill 194 260 352 194 261 352 minecraft:light_gray_concrete
fill 194 260 354 194 261 354 minecraft:light_gray_concrete
fill 194 260 356 194 261 356 minecraft:light_gray_concrete
fill 194 260 358 194 261 358 minecraft:light_gray_concrete
fill 194 260 360 194 261 360 minecraft:light_gray_concrete
fill 195 260 351 195 261 351 minecraft:light_gray_concrete
fill 195 260 353 195 261 353 minecraft:light_gray_concrete
fill 195 260 355 195 261 355 minecraft:light_gray_concrete
fill 195 260 357 195 261 357 minecraft:light_gray_concrete
fill 195 260 359 195 261 359 minecraft:light_gray_concrete
fill 195 260 361 195 261 361 minecraft:light_gray_concrete
fill 196 260 352 196 261 352 minecraft:light_gray_concrete
fill 196 260 354 196 261 354 minecraft:light_gray_concrete
fill 196 260 356 196 261 356 minecraft:light_gray_concrete
fill 196 260 358 196 261 358 minecraft:light_gray_concrete
fill 196 260 360 196 261 360 minecraft:light_gray_concrete
fill 197 260 351 197 261 351 minecraft:light_gray_concrete
fill 197 260 353 197 261 353 minecraft:light_gray_concrete
fill 197 260 355 197 261 355 minecraft:light_gray_concrete
fill 197 260 357 197 261 357 minecraft:light_gray_concrete
fill 197 260 359 197 261 359 minecraft:light_gray_concrete
fill 197 260 361 197 261 361 minecraft:light_gray_concrete
fill 198 260 352 198 261 352 minecraft:light_gray_concrete
fill 198 260 354 198 261 354 minecraft:light_gray_concrete
fill 198 260 356 198 261 356 minecraft:light_gray_concrete
fill 198 260 358 198 261 358 minecraft:light_gray_concrete
fill 198 260 360 198 261 360 minecraft:light_gray_concrete
setblock 200 260 322 minecraft:pearlescent_froglight
fill 207 260 355 207 261 355 minecraft:light_gray_concrete
fill 207 260 357 207 261 357 minecraft:light_gray_concrete
fill 207 260 359 207 261 359 minecraft:light_gray_concrete
fill 207 260 361 209 261 361 minecraft:light_gray_concrete
fill 207 260 363 207 261 363 minecraft:light_gray_concrete
fill 208 260 322 208 308 322 minecraft:black_concrete
fill 208 260 354 208 261 354 minecraft:light_gray_concrete
fill 208 260 356 208 261 356 minecraft:light_gray_concrete
fill 208 260 358 208 261 358 minecraft:light_gray_concrete
fill 208 260 360 210 261 360 minecraft:light_gray_concrete
fill 208 260 362 208 261 362 minecraft:light_gray_concrete
fill 209 260 355 209 261 355 minecraft:light_gray_concrete
fill 209 260 357 209 261 357 minecraft:light_gray_concrete
fill 209 260 359 209 261 359 minecraft:light_gray_concrete
fill 209 260 363 209 261 363 minecraft:light_gray_concrete
fill 210 260 354 210 261 354 minecraft:light_gray_concrete
fill 210 260 356 210 261 356 minecraft:light_gray_concrete
fill 210 260 358 210 261 358 minecraft:light_gray_concrete
fill 210 260 362 210 261 362 minecraft:light_gray_concrete
setblock 211 260 331 minecraft:lime_stained_glass
fill 211 260 355 211 261 355 minecraft:light_gray_concrete
fill 211 260 357 211 261 357 minecraft:light_gray_concrete
fill 211 260 359 211 261 359 minecraft:light_gray_concrete
fill 211 260 361 211 261 361 minecraft:light_gray_concrete
fill 211 260 363 211 261 363 minecraft:light_gray_concrete
fill 212 260 354 212 261 354 minecraft:light_gray_concrete
fill 212 260 356 212 261 356 minecraft:light_gray_concrete
fill 212 260 358 212 261 358 minecraft:light_gray_concrete
fill 212 260 360 212 261 360 minecraft:light_gray_concrete
fill 212 260 362 212 261 362 minecraft:light_gray_concrete
fill 213 260 355 213 261 355 minecraft:light_gray_concrete
fill 213 260 357 213 261 357 minecraft:light_gray_concrete
fill 213 260 359 213 261 359 minecraft:light_gray_concrete
fill 213 260 361 213 261 361 minecraft:light_gray_concrete
fill 213 260 363 213 261 363 minecraft:light_gray_concrete
fill 214 260 354 214 261 354 minecraft:light_gray_concrete
fill 214 260 356 214 261 356 minecraft:light_gray_concrete
fill 214 260 358 214 261 358 minecraft:light_gray_concrete
fill 214 260 360 214 261 360 minecraft:light_gray_concrete
fill 214 260 362 214 261 362 minecraft:light_gray_concrete
fill 215 260 355 215 261 355 minecraft:light_gray_concrete
fill 215 260 357 215 261 357 minecraft:light_gray_concrete
fill 215 260 359 215 261 359 minecraft:light_gray_concrete
fill 215 260 361 215 261 361 minecraft:light_gray_concrete
fill 215 260 363 215 261 363 minecraft:light_gray_concrete
fill 216 260 354 216 261 354 minecraft:light_gray_concrete
fill 216 260 356 216 261 356 minecraft:light_gray_concrete
fill 216 260 358 216 261 358 minecraft:light_gray_concrete
fill 216 260 360 216 261 360 minecraft:light_gray_concrete
fill 216 260 362 216 261 362 minecraft:light_gray_concrete
fill 217 260 355 217 261 355 minecraft:light_gray_concrete
fill 217 260 357 217 261 357 minecraft:light_gray_concrete
fill 217 260 359 217 261 359 minecraft:light_gray_concrete
fill 217 260 361 217 261 361 minecraft:light_gray_concrete
fill 217 260 363 217 261 363 minecraft:light_gray_concrete
fill 218 260 354 218 261 354 minecraft:light_gray_concrete
fill 218 260 356 218 261 356 minecraft:light_gray_concrete
fill 218 260 358 218 261 358 minecraft:light_gray_concrete
fill 218 260 360 218 261 360 minecraft:light_gray_concrete
fill 218 260 362 218 261 362 minecraft:light_gray_concrete
fill 219 260 355 219 261 355 minecraft:light_gray_concrete
fill 219 260 357 219 261 357 minecraft:light_gray_concrete
fill 219 260 359 219 261 359 minecraft:light_gray_concrete
fill 219 260 361 219 261 361 minecraft:light_gray_concrete
fill 219 260 363 219 261 363 minecraft:light_gray_concrete
fill 229 260 322 229 308 322 minecraft:black_concrete
fill 190 261 322 190 263 322 minecraft:black_concrete
fill 200 261 322 200 291 322 minecraft:black_concrete
setblock 230 261 349 minecraft:white_concrete
setblock 230 261 353 minecraft:sea_lantern
setblock 188 262 355 minecraft:ochre_froglight
setblock 189 262 351 minecraft:verdant_froglight
setblock 189 262 353 minecraft:verdant_froglight
setblock 189 262 355 minecraft:verdant_froglight
setblock 189 262 357 minecraft:verdant_froglight
setblock 189 262 359 minecraft:verdant_froglight
setblock 189 262 361 minecraft:verdant_froglight
setblock 190 262 352 minecraft:verdant_froglight
setblock 190 262 354 minecraft:verdant_froglight
setblock 190 262 356 minecraft:verdant_froglight
setblock 190 262 358 minecraft:verdant_froglight
setblock 190 262 360 minecraft:verdant_froglight
setblock 191 262 351 minecraft:verdant_froglight
setblock 191 262 353 minecraft:verdant_froglight
setblock 191 262 355 minecraft:verdant_froglight
setblock 191 262 357 minecraft:verdant_froglight
setblock 191 262 359 minecraft:verdant_froglight
setblock 191 262 361 minecraft:verdant_froglight
setblock 192 262 352 minecraft:verdant_froglight
setblock 192 262 354 minecraft:verdant_froglight
setblock 192 262 356 minecraft:verdant_froglight
setblock 192 262 358 minecraft:verdant_froglight
setblock 192 262 360 minecraft:verdant_froglight
setblock 193 262 351 minecraft:verdant_froglight
setblock 193 262 353 minecraft:verdant_froglight
setblock 193 262 355 minecraft:verdant_froglight
setblock 193 262 357 minecraft:verdant_froglight
setblock 193 262 359 minecraft:verdant_froglight
setblock 193 262 361 minecraft:verdant_froglight
setblock 194 262 352 minecraft:verdant_froglight
setblock 194 262 354 minecraft:verdant_froglight
setblock 194 262 356 minecraft:verdant_froglight
setblock 194 262 358 minecraft:verdant_froglight
setblock 194 262 360 minecraft:verdant_froglight
setblock 195 262 351 minecraft:verdant_froglight
setblock 195 262 353 minecraft:verdant_froglight
setblock 195 262 355 minecraft:verdant_froglight
setblock 195 262 357 minecraft:verdant_froglight
setblock 195 262 359 minecraft:verdant_froglight
setblock 195 262 361 minecraft:verdant_froglight
setblock 196 262 352 minecraft:verdant_froglight
setblock 196 262 354 minecraft:verdant_froglight
setblock 196 262 356 minecraft:verdant_froglight
setblock 196 262 358 minecraft:verdant_froglight
setblock 196 262 360 minecraft:verdant_froglight
setblock 197 262 351 minecraft:verdant_froglight
setblock 197 262 353 minecraft:verdant_froglight
setblock 197 262 355 minecraft:verdant_froglight
setblock 197 262 357 minecraft:verdant_froglight
setblock 197 262 359 minecraft:verdant_froglight
setblock 197 262 361 minecraft:verdant_froglight
setblock 198 262 352 minecraft:verdant_froglight
setblock 198 262 354 minecraft:verdant_froglight
setblock 198 262 356 minecraft:verdant_froglight
setblock 198 262 358 minecraft:verdant_froglight
setblock 198 262 360 minecraft:verdant_froglight
setblock 203 262 364 minecraft:ochre_froglight
setblock 207 262 355 minecraft:verdant_froglight
setblock 207 262 357 minecraft:verdant_froglight
setblock 207 262 359 minecraft:verdant_froglight
setblock 207 262 361 minecraft:verdant_froglight
setblock 207 262 363 minecraft:verdant_froglight
setblock 208 262 354 minecraft:verdant_froglight
setblock 208 262 356 minecraft:verdant_froglight
setblock 208 262 358 minecraft:verdant_froglight
setblock 208 262 360 minecraft:verdant_froglight
fill 208 262 361 208 271 361 minecraft:light_gray_concrete
setblock 208 262 362 minecraft:verdant_froglight
setblock 209 262 355 minecraft:verdant_froglight
setblock 209 262 357 minecraft:verdant_froglight
setblock 209 262 359 minecraft:verdant_froglight
fill 209 262 360 209 271 360 minecraft:light_gray_concrete
setblock 209 262 361 minecraft:verdant_froglight
setblock 209 262 363 minecraft:verdant_froglight
setblock 210 262 354 minecraft:verdant_froglight
setblock 210 262 356 minecraft:verdant_froglight
setblock 210 262 358 minecraft:verdant_froglight
setblock 210 262 360 minecraft:verdant_froglight
setblock 210 262 362 minecraft:verdant_froglight
setblock 211 262 355 minecraft:verdant_froglight
setblock 211 262 357 minecraft:verdant_froglight
setblock 211 262 359 minecraft:verdant_froglight
setblock 211 262 361 minecraft:verdant_froglight
setblock 211 262 363 minecraft:verdant_froglight
setblock 212 262 354 minecraft:verdant_froglight
setblock 212 262 356 minecraft:verdant_froglight
setblock 212 262 358 minecraft:verdant_froglight
setblock 212 262 360 minecraft:verdant_froglight
setblock 212 262 362 minecraft:verdant_froglight
setblock 213 262 355 minecraft:verdant_froglight
setblock 213 262 357 minecraft:verdant_froglight
setblock 213 262 359 minecraft:verdant_froglight
setblock 213 262 361 minecraft:verdant_froglight
setblock 213 262 363 minecraft:verdant_froglight
setblock 214 262 354 minecraft:verdant_froglight
setblock 214 262 356 minecraft:verdant_froglight
setblock 214 262 358 minecraft:verdant_froglight
setblock 214 262 360 minecraft:verdant_froglight
setblock 214 262 362 minecraft:verdant_froglight
setblock 215 262 355 minecraft:verdant_froglight
setblock 215 262 357 minecraft:verdant_froglight
setblock 215 262 359 minecraft:verdant_froglight
setblock 215 262 361 minecraft:verdant_froglight
setblock 215 262 363 minecraft:verdant_froglight
setblock 216 262 354 minecraft:verdant_froglight
setblock 216 262 356 minecraft:verdant_froglight
setblock 216 262 358 minecraft:verdant_froglight
setblock 216 262 360 minecraft:verdant_froglight
setblock 216 262 362 minecraft:verdant_froglight
setblock 217 262 355 minecraft:verdant_froglight
setblock 217 262 357 minecraft:verdant_froglight
setblock 217 262 359 minecraft:verdant_froglight
setblock 217 262 361 minecraft:verdant_froglight
setblock 217 262 363 minecraft:verdant_froglight
setblock 218 262 354 minecraft:verdant_froglight
setblock 218 262 356 minecraft:verdant_froglight
setblock 218 262 358 minecraft:verdant_froglight
setblock 218 262 360 minecraft:verdant_froglight
setblock 218 262 362 minecraft:verdant_froglight
setblock 218 262 364 minecraft:white_concrete
setblock 219 262 355 minecraft:verdant_froglight
setblock 219 262 357 minecraft:verdant_froglight
setblock 219 262 359 minecraft:verdant_froglight
setblock 219 262 361 minecraft:verdant_froglight
setblock 219 262 363 minecraft:verdant_froglight
fill 230 262 349 230 308 349 minecraft:black_concrete
fill 230 262 353 230 273 353 minecraft:black_concrete
setblock 188 263 327 minecraft:sea_lantern
fill 188 263 355 188 289 355 minecraft:black_concrete
setblock 189 263 322 minecraft:pearlescent_froglight
fill 189 263 351 189 264 351 minecraft:light_gray_concrete
fill 189 263 353 189 264 353 minecraft:light_gray_concrete
fill 189 263 355 189 264 355 minecraft:light_gray_concrete
fill 189 263 357 189 264 357 minecraft:light_gray_concrete
fill 189 263 359 189 264 359 minecraft:light_gray_concrete
fill 189 263 361 189 264 361 minecraft:light_gray_concrete
fill 190 263 352 190 264 352 minecraft:light_gray_concrete
fill 190 263 354 190 264 354 minecraft:light_gray_concrete
fill 190 263 356 190 264 356 minecraft:light_gray_concrete
fill 190 263 358 190 264 358 minecraft:light_gray_concrete
fill 190 263 360 190 264 360 minecraft:light_gray_concrete
fill 191 263 351 191 264 351 minecraft:light_gray_concrete
fill 191 263 353 191 264 353 minecraft:light_gray_concrete
fill 191 263 355 191 264 355 minecraft:light_gray_concrete
fill 191 263 357 191 264 357 minecraft:light_gray_concrete
fill 191 263 359 191 264 359 minecraft:light_gray_concrete
fill 191 263 361 191 264 361 minecraft:light_gray_concrete
fill 192 263 352 192 264 352 minecraft:light_gray_concrete
fill 192 263 354 192 264 354 minecraft:light_gray_concrete
fill 192 263 356 192 264 356 minecraft:light_gray_concrete
fill 192 263 358 192 264 358 minecraft:light_gray_concrete
fill 192 263 360 192 264 360 minecraft:light_gray_concrete
fill 193 263 351 193 264 351 minecraft:light_gray_concrete
fill 193 263 353 193 264 353 minecraft:light_gray_concrete
fill 193 263 355 193 264 355 minecraft:light_gray_concrete
fill 193 263 357 193 264 357 minecraft:light_gray_concrete
fill 193 263 359 193 264 359 minecraft:light_gray_concrete
fill 193 263 361 193 264 361 minecraft:light_gray_concrete
fill 194 263 352 194 264 352 minecraft:light_gray_concrete
fill 194 263 354 194 264 354 minecraft:light_gray_concrete
fill 194 263 356 194 264 356 minecraft:light_gray_concrete
fill 194 263 358 194 264 358 minecraft:light_gray_concrete
fill 194 263 360 194 264 360 minecraft:light_gray_concrete
fill 195 263 351 195 264 351 minecraft:light_gray_concrete
fill 195 263 353 195 264 353 minecraft:light_gray_concrete
fill 195 263 355 195 264 355 minecraft:light_gray_concrete
fill 195 263 357 195 264 357 minecraft:light_gray_concrete
fill 195 263 359 195 264 359 minecraft:light_gray_concrete
fill 195 263 361 195 264 361 minecraft:light_gray_concrete
fill 196 263 352 196 264 352 minecraft:light_gray_concrete
fill 196 263 354 196 264 354 minecraft:light_gray_concrete
fill 196 263 356 196 264 356 minecraft:light_gray_concrete
fill 196 263 358 196 264 358 minecraft:light_gray_concrete
fill 196 263 360 196 264 360 minecraft:light_gray_concrete
fill 197 263 351 197 264 351 minecraft:light_gray_concrete
fill 197 263 353 197 264 353 minecraft:light_gray_concrete
fill 197 263 355 197 264 355 minecraft:light_gray_concrete
fill 197 263 357 197 264 357 minecraft:light_gray_concrete
fill 197 263 359 197 264 359 minecraft:light_gray_concrete
fill 197 263 361 197 264 361 minecraft:light_gray_concrete
fill 198 263 352 198 264 352 minecraft:light_gray_concrete
fill 198 263 354 198 264 354 minecraft:light_gray_concrete
fill 198 263 356 198 264 356 minecraft:light_gray_concrete
fill 198 263 358 198 264 358 minecraft:light_gray_concrete
fill 198 263 360 198 264 360 minecraft:light_gray_concrete
fill 203 263 364 203 266 364 minecraft:black_concrete
fill 207 263 355 207 264 355 minecraft:light_gray_concrete
fill 207 263 357 207 264 357 minecraft:light_gray_concrete
fill 207 263 359 207 264 359 minecraft:light_gray_concrete
fill 207 263 361 207 264 361 minecraft:light_gray_concrete
fill 207 263 363 207 264 363 minecraft:light_gray_concrete
fill 208 263 354 208 264 354 minecraft:light_gray_concrete
fill 208 263 356 208 264 356 minecraft:light_gray_concrete
fill 208 263 358 208 264 358 minecraft:light_gray_concrete
fill 208 263 360 208 264 360 minecraft:light_gray_concrete
fill 208 263 362 208 264 362 minecraft:light_gray_concrete
fill 209 263 355 209 264 355 minecraft:light_gray_concrete
fill 209 263 357 209 264 357 minecraft:light_gray_concrete
fill 209 263 359 209 264 359 minecraft:light_gray_concrete
fill 209 263 361 209 264 361 minecraft:light_gray_concrete
fill 209 263 363 209 264 363 minecraft:light_gray_concrete
fill 210 263 354 210 264 354 minecraft:light_gray_concrete
fill 210 263 356 210 264 356 minecraft:light_gray_concrete
fill 210 263 358 210 264 358 minecraft:light_gray_concrete
fill 210 263 360 210 264 360 minecraft:light_gray_concrete
fill 210 263 362 210 264 362 minecraft:light_gray_concrete
fill 211 263 355 211 264 355 minecraft:light_gray_concrete
fill 211 263 357 211 264 357 minecraft:light_gray_concrete
fill 211 263 359 211 264 359 minecraft:light_gray_concrete
fill 211 263 361 211 264 361 minecraft:light_gray_concrete
fill 211 263 363 211 264 363 minecraft:light_gray_concrete
fill 212 263 354 212 264 354 minecraft:light_gray_concrete
fill 212 263 356 212 264 356 minecraft:light_gray_concrete
fill 212 263 358 212 264 358 minecraft:light_gray_concrete
fill 212 263 360 212 264 360 minecraft:light_gray_concrete
fill 212 263 362 212 264 362 minecraft:light_gray_concrete
fill 213 263 355 213 264 355 minecraft:light_gray_concrete
fill 213 263 357 213 264 357 minecraft:light_gray_concrete
fill 213 263 359 213 264 359 minecraft:light_gray_concrete
fill 213 263 361 213 264 361 minecraft:light_gray_concrete
fill 213 263 363 213 264 363 minecraft:light_gray_concrete
fill 214 263 354 214 264 354 minecraft:light_gray_concrete
fill 214 263 356 214 264 356 minecraft:light_gray_concrete
fill 214 263 358 214 264 358 minecraft:light_gray_concrete
fill 214 263 360 214 264 360 minecraft:light_gray_concrete
fill 214 263 362 214 264 362 minecraft:light_gray_concrete
fill 215 263 355 215 264 355 minecraft:light_gray_concrete
fill 215 263 357 215 264 357 minecraft:light_gray_concrete
fill 215 263 359 215 264 359 minecraft:light_gray_concrete
fill 215 263 361 215 264 361 minecraft:light_gray_concrete
fill 215 263 363 215 264 363 minecraft:light_gray_concrete
fill 216 263 354 216 264 354 minecraft:light_gray_concrete
fill 216 263 356 216 264 356 minecraft:light_gray_concrete
fill 216 263 358 216 264 358 minecraft:light_gray_concrete
fill 216 263 360 216 264 360 minecraft:light_gray_concrete
fill 216 263 362 216 264 362 minecraft:light_gray_concrete
fill 217 263 355 217 264 355 minecraft:light_gray_concrete
fill 217 263 357 217 264 357 minecraft:light_gray_concrete
fill 217 263 359 217 264 359 minecraft:light_gray_concrete
fill 217 263 361 217 264 361 minecraft:light_gray_concrete
fill 217 263 363 217 264 363 minecraft:light_gray_concrete
fill 218 263 354 218 264 354 minecraft:light_gray_concrete
fill 218 263 356 218 264 356 minecraft:light_gray_concrete
fill 218 263 358 218 264 358 minecraft:light_gray_concrete
fill 218 263 360 218 264 360 minecraft:light_gray_concrete
fill 218 263 362 218 264 362 minecraft:light_gray_concrete
fill 218 263 364 218 308 364 minecraft:black_concrete
fill 219 263 355 219 264 355 minecraft:light_gray_concrete
fill 219 263 357 219 264 357 minecraft:light_gray_concrete
fill 219 263 359 219 264 359 minecraft:light_gray_concrete
fill 219 263 361 219 264 361 minecraft:light_gray_concrete
fill 219 263 363 219 264 363 minecraft:light_gray_concrete
setblock 228 263 322 minecraft:ochre_froglight
setblock 230 263 326 minecraft:sea_lantern
fill 188 264 327 188 266 327 minecraft:black_concrete
setblock 188 264 346 minecraft:white_concrete
fill 189 264 322 189 269 322 minecraft:black_concrete
setblock 190 264 322 minecraft:pearlescent_froglight
setblock 197 264 322 minecraft:white_concrete
fill 209 264 334 210 265 335 minecraft:end_stone
setblock 219 264 364 minecraft:white_concrete
setblock 222 264 322 minecraft:white_concrete
fill 228 264 322 228 278 322 minecraft:black_concrete
fill 230 264 326 230 308 326 minecraft:black_concrete
fill 188 265 346 188 308 346 minecraft:black_concrete
setblock 188 265 362 minecraft:sea_lantern
setblock 189 265 351 minecraft:verdant_froglight
setblock 189 265 353 minecraft:verdant_froglight
setblock 189 265 355 minecraft:verdant_froglight
setblock 189 265 357 minecraft:verdant_froglight
setblock 189 265 359 minecraft:verdant_froglight
setblock 189 265 361 minecraft:verdant_froglight
fill 190 265 322 190 275 322 minecraft:black_concrete
setblock 190 265 352 minecraft:verdant_froglight
setblock 190 265 354 minecraft:verdant_froglight
setblock 190 265 356 minecraft:verdant_froglight
setblock 190 265 358 minecraft:verdant_froglight
setblock 190 265 360 minecraft:verdant_froglight
setblock 191 265 325 minecraft:light[level=15]
setblock 191 265 332 minecraft:light[level=12]
setblock 191 265 333 minecraft:light[level=15]
setblock 191 265 339 minecraft:light[level=12]
setblock 191 265 341 minecraft:light[level=15]
setblock 191 265 346 minecraft:light[level=12]
setblock 191 265 349 minecraft:light[level=15]
setblock 191 265 351 minecraft:verdant_froglight
setblock 191 265 353 minecraft:verdant_froglight
setblock 191 265 355 minecraft:verdant_froglight
setblock 191 265 357 minecraft:verdant_froglight
setblock 191 265 359 minecraft:verdant_froglight
setblock 191 265 361 minecraft:verdant_froglight
setblock 192 265 352 minecraft:verdant_froglight
setblock 192 265 354 minecraft:verdant_froglight
setblock 192 265 356 minecraft:verdant_froglight
setblock 192 265 358 minecraft:verdant_froglight
setblock 192 265 360 minecraft:verdant_froglight
setblock 193 265 351 minecraft:verdant_froglight
setblock 193 265 353 minecraft:verdant_froglight
setblock 193 265 355 minecraft:verdant_froglight
setblock 193 265 357 minecraft:verdant_froglight
setblock 193 265 359 minecraft:verdant_froglight
setblock 193 265 361 minecraft:verdant_froglight
setblock 194 265 352 minecraft:verdant_froglight
setblock 194 265 354 minecraft:verdant_froglight
setblock 194 265 356 minecraft:verdant_froglight
setblock 194 265 358 minecraft:verdant_froglight
setblock 194 265 360 minecraft:verdant_froglight
setblock 194 265 364 minecraft:sea_lantern
setblock 195 265 351 minecraft:verdant_froglight
fill 195 265 352 195 266 352 minecraft:end_stone
setblock 195 265 353 minecraft:verdant_froglight
setblock 195 265 355 minecraft:verdant_froglight
setblock 195 265 357 minecraft:verdant_froglight
setblock 195 265 359 minecraft:verdant_froglight
setblock 195 265 361 minecraft:verdant_froglight
fill 196 265 351 196 266 351 minecraft:end_stone
setblock 196 265 352 minecraft:verdant_froglight
setblock 196 265 354 minecraft:verdant_froglight
setblock 196 265 356 minecraft:verdant_froglight
setblock 196 265 358 minecraft:verdant_froglight
setblock 196 265 360 minecraft:verdant_froglight
setblock 196 265 364 minecraft:ochre_froglight
fill 197 265 322 197 308 322 minecraft:black_concrete
setblock 197 265 351 minecraft:verdant_froglight
fill 197 265 352 197 266 352 minecraft:end_stone
setblock 197 265 353 minecraft:verdant_froglight
setblock 197 265 355 minecraft:verdant_froglight
setblock 197 265 357 minecraft:verdant_froglight
setblock 197 265 359 minecraft:verdant_froglight
setblock 197 265 361 minecraft:verdant_froglight
setblock 198 265 325 minecraft:light[level=12]
setblock 198 265 332 minecraft:light[level=12]
setblock 198 265 339 minecraft:light[level=12]
setblock 198 265 346 minecraft:light[level=12]
setblock 198 265 352 minecraft:verdant_froglight
setblock 198 265 354 minecraft:verdant_froglight
setblock 198 265 356 minecraft:verdant_froglight
setblock 198 265 358 minecraft:verdant_froglight
setblock 198 265 360 minecraft:verdant_froglight
setblock 199 265 325 minecraft:light[level=15]
setblock 199 265 333 minecraft:light[level=15]
setblock 199 265 341 minecraft:light[level=15]
setblock 199 265 349 minecraft:light[level=15]
setblock 199 265 357 minecraft:light[level=15]
setblock 205 265 325 minecraft:light[level=12]
setblock 205 265 332 minecraft:light[level=12]
setblock 205 265 339 minecraft:light[level=12]
setblock 205 265 346 minecraft:light[level=12]
setblock 205 265 353 minecraft:light[level=12]
setblock 205 265 360 minecraft:light[level=12]
setblock 207 265 325 minecraft:light[level=15]
setblock 207 265 333 minecraft:light[level=15]
setblock 207 265 341 minecraft:light[level=15]
setblock 207 265 349 minecraft:light[level=15]
setblock 207 265 355 minecraft:verdant_froglight
setblock 207 265 357 minecraft:verdant_froglight
setblock 207 265 359 minecraft:verdant_froglight
setblock 207 265 361 minecraft:verdant_froglight
setblock 207 265 363 minecraft:verdant_froglight
setblock 208 265 354 minecraft:verdant_froglight
setblock 208 265 356 minecraft:verdant_froglight
setblock 208 265 358 minecraft:verdant_froglight
setblock 208 265 360 minecraft:verdant_froglight
setblock 208 265 362 minecraft:verdant_froglight
setblock 209 265 355 minecraft:verdant_froglight
setblock 209 265 357 minecraft:verdant_froglight
setblock 209 265 359 minecraft:verdant_froglight
setblock 209 265 361 minecraft:verdant_froglight
setblock 209 265 363 minecraft:verdant_froglight
setblock 210 265 354 minecraft:verdant_froglight
setblock 210 265 356 minecraft:verdant_froglight
setblock 210 265 358 minecraft:verdant_froglight
setblock 210 265 360 minecraft:verdant_froglight
setblock 210 265 362 minecraft:verdant_froglight
setblock 211 265 355 minecraft:verdant_froglight
setblock 211 265 357 minecraft:verdant_froglight
setblock 211 265 359 minecraft:verdant_froglight
setblock 211 265 361 minecraft:verdant_froglight
setblock 211 265 363 minecraft:verdant_froglight
setblock 212 265 325 minecraft:light[level=12]
setblock 212 265 332 minecraft:light[level=12]
setblock 212 265 339 minecraft:light[level=12]
setblock 212 265 346 minecraft:light[level=12]
setblock 212 265 353 minecraft:light[level=12]
setblock 212 265 354 minecraft:verdant_froglight
setblock 212 265 356 minecraft:verdant_froglight
setblock 212 265 358 minecraft:verdant_froglight
setblock 212 265 360 minecraft:verdant_froglight
setblock 212 265 362 minecraft:verdant_froglight
setblock 213 265 355 minecraft:verdant_froglight
setblock 213 265 357 minecraft:verdant_froglight
setblock 213 265 359 minecraft:verdant_froglight
setblock 213 265 361 minecraft:verdant_froglight
setblock 213 265 363 minecraft:verdant_froglight
setblock 214 265 322 minecraft:ochre_froglight
setblock 214 265 354 minecraft:verdant_froglight
setblock 214 265 356 minecraft:verdant_froglight
setblock 214 265 358 minecraft:verdant_froglight
setblock 214 265 360 minecraft:verdant_froglight
setblock 214 265 362 minecraft:verdant_froglight
setblock 215 265 325 minecraft:light[level=15]
setblock 215 265 333 minecraft:light[level=15]
setblock 215 265 341 minecraft:light[level=15]
setblock 215 265 349 minecraft:light[level=15]
setblock 215 265 355 minecraft:verdant_froglight
setblock 215 265 357 minecraft:verdant_froglight
setblock 215 265 359 minecraft:verdant_froglight
setblock 215 265 361 minecraft:verdant_froglight
setblock 215 265 363 minecraft:verdant_froglight
setblock 216 265 354 minecraft:verdant_froglight
setblock 216 265 356 minecraft:verdant_froglight
setblock 216 265 358 minecraft:verdant_froglight
setblock 216 265 360 minecraft:verdant_froglight
setblock 216 265 362 minecraft:verdant_froglight
setblock 217 265 355 minecraft:verdant_froglight
setblock 217 265 357 minecraft:verdant_froglight
setblock 217 265 359 minecraft:verdant_froglight
setblock 217 265 361 minecraft:verdant_froglight
setblock 217 265 363 minecraft:verdant_froglight
setblock 218 265 354 minecraft:verdant_froglight
setblock 218 265 356 minecraft:verdant_froglight
setblock 218 265 358 minecraft:verdant_froglight
setblock 218 265 360 minecraft:verdant_froglight
setblock 218 265 362 minecraft:verdant_froglight
setblock 219 265 325 minecraft:light[level=12]
setblock 219 265 332 minecraft:light[level=12]
setblock 219 265 339 minecraft:light[level=12]
setblock 219 265 346 minecraft:light[level=12]
setblock 219 265 353 minecraft:light[level=12]
setblock 219 265 355 minecraft:verdant_froglight
setblock 219 265 357 minecraft:verdant_froglight
setblock 219 265 359 minecraft:verdant_froglight
setblock 219 265 361 minecraft:verdant_froglight
setblock 219 265 363 minecraft:verdant_froglight
fill 219 265 364 219 290 364 minecraft:black_concrete
fill 222 265 322 222 308 322 minecraft:black_concrete
setblock 223 265 325 minecraft:light[level=15]
setblock 223 265 349 minecraft:light[level=15]
setblock 223 265 357 minecraft:light[level=15]
setblock 226 265 325 minecraft:light[level=12]
setblock 226 265 332 minecraft:light[level=12]
setblock 226 265 346 minecraft:light[level=12]
setblock 226 265 353 minecraft:light[level=12]
setblock 226 265 360 minecraft:light[level=12]
setblock 230 265 331 minecraft:pearlescent_froglight
setblock 188 266 335 minecraft:white_concrete
setblock 188 266 338 minecraft:sea_lantern
fill 188 266 362 188 308 362 minecraft:black_concrete
fill 189 266 351 189 267 351 minecraft:light_gray_concrete
fill 189 266 353 189 267 353 minecraft:light_gray_concrete
fill 189 266 355 189 267 355 minecraft:light_gray_concrete
fill 189 266 357 189 267 357 minecraft:light_gray_concrete
fill 189 266 359 189 267 359 minecraft:light_gray_concrete
fill 189 266 361 189 267 361 minecraft:light_gray_concrete
fill 190 266 352 190 267 352 minecraft:light_gray_concrete
fill 190 266 354 190 267 354 minecraft:light_gray_concrete
fill 190 266 356 190 267 356 minecraft:light_gray_concrete
fill 190 266 358 190 267 358 minecraft:light_gray_concrete
fill 190 266 360 190 267 360 minecraft:light_gray_concrete
fill 191 266 351 191 267 351 minecraft:light_gray_concrete
fill 191 266 353 191 267 353 minecraft:light_gray_concrete
fill 191 266 355 191 267 355 minecraft:light_gray_concrete
fill 191 266 357 191 267 357 minecraft:light_gray_concrete
fill 191 266 359 191 267 359 minecraft:light_gray_concrete
fill 191 266 361 191 267 361 minecraft:light_gray_concrete
fill 192 266 352 192 267 352 minecraft:light_gray_concrete
fill 192 266 354 192 267 354 minecraft:light_gray_concrete
fill 192 266 356 192 267 356 minecraft:light_gray_concrete
fill 192 266 358 192 267 358 minecraft:light_gray_concrete
fill 192 266 360 192 267 360 minecraft:light_gray_concrete
fill 193 266 351 193 267 351 minecraft:light_gray_concrete
fill 193 266 353 193 267 353 minecraft:light_gray_concrete
fill 193 266 355 193 267 355 minecraft:light_gray_concrete
fill 193 266 357 193 267 357 minecraft:light_gray_concrete
fill 193 266 359 193 267 359 minecraft:light_gray_concrete
fill 193 266 361 193 267 361 minecraft:light_gray_concrete
fill 194 266 352 194 267 352 minecraft:light_gray_concrete
fill 194 266 354 194 267 354 minecraft:light_gray_concrete
fill 194 266 356 194 267 356 minecraft:light_gray_concrete
fill 194 266 358 194 267 358 minecraft:light_gray_concrete
fill 194 266 360 194 267 360 minecraft:light_gray_concrete
fill 194 266 364 194 308 364 minecraft:black_concrete
fill 195 266 351 195 267 351 minecraft:light_gray_concrete
fill 195 266 353 195 267 353 minecraft:light_gray_concrete
fill 195 266 355 195 267 355 minecraft:light_gray_concrete
fill 195 266 357 195 267 357 minecraft:light_gray_concrete
fill 195 266 359 195 267 359 minecraft:light_gray_concrete
fill 195 266 361 195 267 361 minecraft:light_gray_concrete
setblock 196 266 352 minecraft:end_stone
fill 196 266 354 196 267 354 minecraft:light_gray_concrete
fill 196 266 356 196 267 356 minecraft:light_gray_concrete
fill 196 266 358 196 267 358 minecraft:light_gray_concrete
fill 196 266 360 196 267 360 minecraft:light_gray_concrete
fill 196 266 364 196 270 364 minecraft:black_concrete
fill 197 266 351 197 267 351 minecraft:light_gray_concrete
fill 197 266 353 197 267 353 minecraft:light_gray_concrete
fill 197 266 355 197 267 355 minecraft:light_gray_concrete
fill 197 266 357 197 267 357 minecraft:light_gray_concrete
fill 197 266 359 197 267 359 minecraft:light_gray_concrete
fill 197 266 361 197 267 361 minecraft:light_gray_concrete
fill 198 266 352 198 267 352 minecraft:light_gray_concrete
fill 198 266 354 198 267 354 minecraft:light_gray_concrete
fill 198 266 356 198 267 356 minecraft:light_gray_concrete
fill 198 266 358 198 267 358 minecraft:light_gray_concrete
fill 198 266 360 198 267 360 minecraft:light_gray_concrete
fill 207 266 355 207 267 355 minecraft:light_gray_concrete
fill 207 266 357 207 267 357 minecraft:light_gray_concrete
fill 207 266 359 207 267 359 minecraft:light_gray_concrete
fill 207 266 361 207 267 361 minecraft:light_gray_concrete
fill 207 266 363 207 267 363 minecraft:light_gray_concrete
fill 208 266 354 208 267 354 minecraft:light_gray_concrete
fill 208 266 356 208 267 356 minecraft:light_gray_concrete
fill 208 266 358 208 267 358 minecraft:light_gray_concrete
fill 208 266 360 208 267 360 minecraft:light_gray_concrete
fill 208 266 362 208 267 362 minecraft:light_gray_concrete
fill 209 266 355 209 267 355 minecraft:light_gray_concrete
fill 209 266 357 209 267 357 minecraft:light_gray_concrete
fill 209 266 359 209 267 359 minecraft:light_gray_concrete
fill 209 266 361 209 267 361 minecraft:light_gray_concrete
fill 209 266 363 209 267 363 minecraft:light_gray_concrete
fill 210 266 354 210 267 354 minecraft:light_gray_concrete
fill 210 266 356 210 267 356 minecraft:light_gray_concrete
fill 210 266 358 210 267 358 minecraft:light_gray_concrete
fill 210 266 360 210 267 360 minecraft:light_gray_concrete
fill 210 266 362 210 267 362 minecraft:light_gray_concrete
fill 211 266 355 211 267 355 minecraft:light_gray_concrete
fill 211 266 357 211 267 357 minecraft:light_gray_concrete
fill 211 266 359 211 267 359 minecraft:light_gray_concrete
fill 211 266 361 211 267 361 minecraft:light_gray_concrete
fill 211 266 363 211 267 363 minecraft:light_gray_concrete
fill 212 266 354 212 267 354 minecraft:light_gray_concrete
fill 212 266 356 212 267 356 minecraft:light_gray_concrete
fill 212 266 358 212 267 358 minecraft:light_gray_concrete
fill 212 266 360 212 267 360 minecraft:light_gray_concrete
fill 212 266 362 212 267 362 minecraft:light_gray_concrete
fill 213 266 355 213 267 355 minecraft:light_gray_concrete
fill 213 266 357 213 267 357 minecraft:light_gray_concrete
fill 213 266 359 213 267 359 minecraft:light_gray_concrete
fill 213 266 361 213 267 361 minecraft:light_gray_concrete
fill 213 266 363 213 267 363 minecraft:light_gray_concrete
fill 214 266 322 214 308 322 minecraft:black_concrete
fill 214 266 354 214 267 354 minecraft:light_gray_concrete
fill 214 266 356 214 267 356 minecraft:light_gray_concrete
fill 214 266 358 214 267 358 minecraft:light_gray_concrete
fill 214 266 360 214 267 360 minecraft:light_gray_concrete
fill 214 266 362 214 267 362 minecraft:light_gray_concrete
fill 215 266 355 215 267 355 minecraft:light_gray_concrete
fill 215 266 357 215 267 357 minecraft:light_gray_concrete
fill 215 266 359 215 267 359 minecraft:light_gray_concrete
fill 215 266 361 215 267 361 minecraft:light_gray_concrete
fill 215 266 363 215 267 363 minecraft:light_gray_concrete
fill 216 266 354 216 267 354 minecraft:light_gray_concrete
fill 216 266 356 216 267 356 minecraft:light_gray_concrete
fill 216 266 358 216 267 358 minecraft:light_gray_concrete
fill 216 266 360 216 267 360 minecraft:light_gray_concrete
fill 216 266 362 216 267 362 minecraft:light_gray_concrete
fill 217 266 355 217 267 355 minecraft:light_gray_concrete
fill 217 266 357 217 267 357 minecraft:light_gray_concrete
fill 217 266 359 217 267 359 minecraft:light_gray_concrete
fill 217 266 361 217 267 361 minecraft:light_gray_concrete
fill 217 266 363 217 267 363 minecraft:light_gray_concrete
fill 218 266 354 218 267 354 minecraft:light_gray_concrete
fill 218 266 356 218 267 356 minecraft:light_gray_concrete
fill 218 266 358 218 267 358 minecraft:light_gray_concrete
fill 218 266 360 218 267 360 minecraft:light_gray_concrete
fill 218 266 362 218 267 362 minecraft:light_gray_concrete
fill 219 266 355 219 267 355 minecraft:light_gray_concrete
fill 219 266 357 219 267 357 minecraft:light_gray_concrete
fill 219 266 359 219 267 359 minecraft:light_gray_concrete
fill 219 266 361 219 267 361 minecraft:light_gray_concrete
fill 219 266 363 219 267 363 minecraft:light_gray_concrete
fill 230 266 331 230 295 331 minecraft:black_concrete
setblock 188 267 323 minecraft:pearlescent_froglight
setblock 188 267 327 minecraft:sea_lantern
fill 188 267 335 188 308 335 minecraft:black_concrete
fill 188 267 338 188 276 338 minecraft:black_concrete
fill 195 267 352 197 267 352 minecraft:light_gray_concrete
setblock 195 267 364 minecraft:pearlescent_froglight
fill 196 267 351 196 271 351 minecraft:light_gray_concrete
setblock 203 267 364 minecraft:white_concrete
setblock 215 267 322 minecraft:pearlescent_froglight
fill 188 268 323 188 284 323 minecraft:black_concrete
fill 188 268 327 188 308 327 minecraft:black_concrete
setblock 189 268 351 minecraft:verdant_froglight
setblock 189 268 353 minecraft:verdant_froglight
setblock 189 268 355 minecraft:verdant_froglight
setblock 189 268 357 minecraft:verdant_froglight
setblock 189 268 359 minecraft:verdant_froglight
setblock 189 268 361 minecraft:verdant_froglight
setblock 190 268 352 minecraft:verdant_froglight
setblock 190 268 354 minecraft:verdant_froglight
setblock 190 268 356 minecraft:verdant_froglight
setblock 190 268 358 minecraft:verdant_froglight
setblock 190 268 360 minecraft:verdant_froglight
setblock 191 268 351 minecraft:verdant_froglight
setblock 191 268 353 minecraft:verdant_froglight
setblock 191 268 355 minecraft:verdant_froglight
setblock 191 268 357 minecraft:verdant_froglight
setblock 191 268 359 minecraft:verdant_froglight
setblock 191 268 361 minecraft:verdant_froglight
setblock 192 268 322 minecraft:sea_lantern
setblock 192 268 352 minecraft:verdant_froglight
setblock 192 268 354 minecraft:verdant_froglight
setblock 192 268 356 minecraft:verdant_froglight
setblock 192 268 358 minecraft:verdant_froglight
setblock 192 268 360 minecraft:verdant_froglight
setblock 193 268 322 minecraft:pearlescent_froglight
setblock 193 268 351 minecraft:verdant_froglight
setblock 193 268 353 minecraft:verdant_froglight
setblock 193 268 355 minecraft:verdant_froglight
setblock 193 268 357 minecraft:verdant_froglight
setblock 193 268 359 minecraft:verdant_froglight
setblock 193 268 361 minecraft:verdant_froglight
setblock 194 268 352 minecraft:verdant_froglight
setblock 194 268 354 minecraft:verdant_froglight
setblock 194 268 356 minecraft:verdant_froglight
setblock 194 268 358 minecraft:verdant_froglight
setblock 194 268 360 minecraft:verdant_froglight
setblock 195 268 351 minecraft:verdant_froglight
fill 195 268 352 195 271 352 minecraft:light_gray_concrete
setblock 195 268 353 minecraft:verdant_froglight
setblock 195 268 355 minecraft:verdant_froglight
setblock 195 268 357 minecraft:verdant_froglight
setblock 195 268 359 minecraft:verdant_froglight
setblock 195 268 361 minecraft:verdant_froglight
setblock 195 268 364 minecraft:sea_lantern
setblock 196 268 352 minecraft:verdant_froglight
setblock 196 268 354 minecraft:verdant_froglight
setblock 196 268 356 minecraft:verdant_froglight
setblock 196 268 358 minecraft:verdant_froglight
setblock 196 268 360 minecraft:verdant_froglight
setblock 197 268 351 minecraft:verdant_froglight
fill 197 268 352 197 271 352 minecraft:light_gray_concrete
setblock 197 268 353 minecraft:verdant_froglight
setblock 197 268 355 minecraft:verdant_froglight
setblock 197 268 357 minecraft:verdant_froglight
setblock 197 268 359 minecraft:verdant_froglight
setblock 197 268 361 minecraft:verdant_froglight
setblock 198 268 352 minecraft:verdant_froglight
setblock 198 268 354 minecraft:verdant_froglight
setblock 198 268 356 minecraft:verdant_froglight
setblock 198 268 358 minecraft:verdant_froglight
setblock 198 268 360 minecraft:verdant_froglight
fill 203 268 364 203 278 364 minecraft:black_concrete
fill 206 268 343 206 268 345 minecraft:lime_stained_glass
fill 207 268 341 207 269 341 minecraft:lime_stained_glass
fill 207 268 347 207 269 347 minecraft:lime_stained_glass
setblock 207 268 355 minecraft:verdant_froglight
setblock 207 268 357 minecraft:verdant_froglight
setblock 207 268 359 minecraft:verdant_froglight
setblock 207 268 361 minecraft:verdant_froglight
setblock 207 268 363 minecraft:verdant_froglight
fill 208 268 340 208 269 340 minecraft:lime_stained_glass
fill 208 268 348 208 269 348 minecraft:lime_stained_glass
setblock 208 268 354 minecraft:verdant_froglight
setblock 208 268 356 minecraft:verdant_froglight
setblock 208 268 358 minecraft:verdant_froglight
setblock 208 268 360 minecraft:verdant_froglight
setblock 208 268 362 minecraft:verdant_froglight
setblock 209 268 355 minecraft:verdant_froglight
setblock 209 268 357 minecraft:verdant_froglight
setblock 209 268 359 minecraft:verdant_froglight
setblock 209 268 361 minecraft:verdant_froglight
setblock 209 268 363 minecraft:verdant_froglight
fill 210 268 339 212 268 339 minecraft:lime_stained_glass
fill 210 268 349 212 268 349 minecraft:lime_stained_glass
setblock 210 268 354 minecraft:verdant_froglight
setblock 210 268 356 minecraft:verdant_froglight
setblock 210 268 358 minecraft:verdant_froglight
setblock 210 268 360 minecraft:verdant_froglight
setblock 210 268 362 minecraft:verdant_froglight
setblock 211 268 355 minecraft:verdant_froglight
setblock 211 268 357 minecraft:verdant_froglight
setblock 211 268 359 minecraft:verdant_froglight
setblock 211 268 361 minecraft:verdant_froglight
setblock 211 268 363 minecraft:verdant_froglight
setblock 212 268 322 minecraft:white_concrete
setblock 212 268 354 minecraft:verdant_froglight
setblock 212 268 356 minecraft:verdant_froglight
setblock 212 268 358 minecraft:verdant_froglight
setblock 212 268 360 minecraft:verdant_froglight
setblock 212 268 362 minecraft:verdant_froglight
setblock 213 268 355 minecraft:verdant_froglight
setblock 213 268 357 minecraft:verdant_froglight
setblock 213 268 359 minecraft:verdant_froglight
setblock 213 268 361 minecraft:verdant_froglight
setblock 213 268 363 minecraft:verdant_froglight
fill 214 268 340 214 269 340 minecraft:lime_stained_glass
fill 214 268 348 214 269 348 minecraft:lime_stained_glass
setblock 214 268 354 minecraft:verdant_froglight
setblock 214 268 356 minecraft:verdant_froglight
setblock 214 268 358 minecraft:verdant_froglight
setblock 214 268 360 minecraft:verdant_froglight
setblock 214 268 362 minecraft:verdant_froglight
fill 215 268 322 215 276 322 minecraft:black_concrete
fill 215 268 341 215 269 341 minecraft:lime_stained_glass
fill 215 268 347 215 269 347 minecraft:lime_stained_glass
setblock 215 268 355 minecraft:verdant_froglight
setblock 215 268 357 minecraft:verdant_froglight
setblock 215 268 359 minecraft:verdant_froglight
setblock 215 268 361 minecraft:verdant_froglight
setblock 215 268 363 minecraft:verdant_froglight
fill 216 268 343 216 268 345 minecraft:lime_stained_glass
setblock 216 268 354 minecraft:verdant_froglight
setblock 216 268 356 minecraft:verdant_froglight
setblock 216 268 358 minecraft:verdant_froglight
setblock 216 268 360 minecraft:verdant_froglight
setblock 216 268 362 minecraft:verdant_froglight
setblock 217 268 355 minecraft:verdant_froglight
setblock 217 268 357 minecraft:verdant_froglight
setblock 217 268 359 minecraft:verdant_froglight
setblock 217 268 361 minecraft:verdant_froglight
setblock 217 268 363 minecraft:verdant_froglight
setblock 218 268 354 minecraft:verdant_froglight
setblock 218 268 356 minecraft:verdant_froglight
setblock 218 268 358 minecraft:verdant_froglight
setblock 218 268 360 minecraft:verdant_froglight
setblock 218 268 362 minecraft:verdant_froglight
setblock 219 268 355 minecraft:verdant_froglight
setblock 219 268 357 minecraft:verdant_froglight
setblock 219 268 359 minecraft:verdant_froglight
setblock 219 268 361 minecraft:verdant_froglight
setblock 219 268 363 minecraft:verdant_froglight
fill 189 269 351 189 271 351 minecraft:light_gray_concrete
fill 189 269 353 189 271 353 minecraft:light_gray_concrete
fill 189 269 355 189 271 355 minecraft:light_gray_concrete
fill 189 269 357 189 271 357 minecraft:light_gray_concrete
fill 189 269 359 189 271 359 minecraft:light_gray_concrete
fill 189 269 361 189 271 361 minecraft:light_gray_concrete
fill 190 269 352 190 271 352 minecraft:light_gray_concrete
fill 190 269 354 190 271 354 minecraft:light_gray_concrete
fill 190 269 356 190 271 356 minecraft:light_gray_concrete
fill 190 269 358 190 271 358 minecraft:light_gray_concrete
fill 190 269 360 190 271 360 minecraft:light_gray_concrete
fill 191 269 351 191 271 351 minecraft:light_gray_concrete
fill 191 269 353 191 271 353 minecraft:light_gray_concrete
fill 191 269 355 191 271 355 minecraft:light_gray_concrete
fill 191 269 357 191 271 357 minecraft:light_gray_concrete
fill 191 269 359 191 271 359 minecraft:light_gray_concrete
fill 191 269 361 191 271 361 minecraft:light_gray_concrete
fill 192 269 322 192 308 322 minecraft:black_concrete
fill 192 269 352 192 271 352 minecraft:light_gray_concrete
fill 192 269 354 192 271 354 minecraft:light_gray_concrete
fill 192 269 356 192 271 356 minecraft:light_gray_concrete
fill 192 269 358 192 271 358 minecraft:light_gray_concrete
fill 192 269 360 192 271 360 minecraft:light_gray_concrete
setblock 193 269 322 minecraft:sea_lantern
fill 193 269 351 193 271 351 minecraft:light_gray_concrete
fill 193 269 353 193 271 353 minecraft:light_gray_concrete
fill 193 269 355 193 271 355 minecraft:light_gray_concrete
fill 193 269 357 193 271 357 minecraft:light_gray_concrete
fill 193 269 359 193 271 359 minecraft:light_gray_concrete
fill 193 269 361 193 271 361 minecraft:light_gray_concrete
fill 194 269 352 194 271 352 minecraft:light_gray_concrete
fill 194 269 354 194 271 354 minecraft:light_gray_concrete
fill 194 269 356 194 271 356 minecraft:light_gray_concrete
fill 194 269 358 194 271 358 minecraft:light_gray_concrete
fill 194 269 360 194 271 360 minecraft:light_gray_concrete
fill 195 269 351 195 271 351 minecraft:light_gray_concrete
fill 195 269 353 195 271 353 minecraft:light_gray_concrete
fill 195 269 355 195 271 355 minecraft:light_gray_concrete
fill 195 269 357 195 271 357 minecraft:light_gray_concrete
fill 195 269 359 195 271 359 minecraft:light_gray_concrete
fill 195 269 361 195 271 361 minecraft:light_gray_concrete
fill 195 269 364 195 308 364 minecraft:black_concrete
fill 196 269 352 196 271 352 minecraft:light_gray_concrete
fill 196 269 354 196 271 354 minecraft:light_gray_concrete
fill 196 269 356 196 271 356 minecraft:light_gray_concrete
fill 196 269 358 196 271 358 minecraft:light_gray_concrete
fill 196 269 360 196 271 360 minecraft:light_gray_concrete
fill 197 269 351 197 271 351 minecraft:light_gray_concrete
fill 197 269 353 197 271 353 minecraft:light_gray_concrete
fill 197 269 355 197 271 355 minecraft:light_gray_concrete
fill 197 269 357 197 271 357 minecraft:light_gray_concrete
fill 197 269 359 197 271 359 minecraft:light_gray_concrete
fill 197 269 361 197 271 361 minecraft:light_gray_concrete
fill 198 269 352 198 271 352 minecraft:light_gray_concrete
fill 198 269 354 198 271 354 minecraft:light_gray_concrete
fill 198 269 356 198 271 356 minecraft:light_gray_concrete
fill 198 269 358 198 271 358 minecraft:light_gray_concrete
fill 198 269 360 198 271 360 minecraft:light_gray_concrete
setblock 206 269 344 minecraft:lime_stained_glass
setblock 206 269 364 minecraft:sea_lantern
fill 207 269 342 207 271 342 minecraft:lime_stained_glass
fill 207 269 346 207 271 346 minecraft:lime_stained_glass
fill 207 269 355 207 271 355 minecraft:light_gray_concrete
fill 207 269 357 207 271 357 minecraft:light_gray_concrete
fill 207 269 359 207 271 359 minecraft:light_gray_concrete
fill 207 269 361 207 271 361 minecraft:light_gray_concrete
fill 207 269 363 207 271 363 minecraft:light_gray_concrete
fill 208 269 354 208 271 354 minecraft:light_gray_concrete
fill 208 269 356 208 271 356 minecraft:light_gray_concrete
fill 208 269 358 208 271 358 minecraft:light_gray_concrete
fill 208 269 360 208 271 360 minecraft:light_gray_concrete
fill 208 269 362 208 271 362 minecraft:light_gray_concrete
fill 209 269 340 209 271 340 minecraft:lime_stained_glass
fill 209 269 348 209 271 348 minecraft:lime_stained_glass
fill 209 269 355 209 271 355 minecraft:light_gray_concrete
fill 209 269 357 209 271 357 minecraft:light_gray_concrete
fill 209 269 359 209 271 359 minecraft:light_gray_concrete
fill 209 269 361 209 271 361 minecraft:light_gray_concrete
fill 209 269 363 209 271 363 minecraft:light_gray_concrete
fill 210 269 354 210 271 354 minecraft:light_gray_concrete
fill 210 269 356 210 271 356 minecraft:light_gray_concrete
fill 210 269 358 210 271 358 minecraft:light_gray_concrete
fill 210 269 360 210 271 360 minecraft:light_gray_concrete
fill 210 269 362 210 271 362 minecraft:light_gray_concrete
setblock 211 269 339 minecraft:lime_stained_glass
setblock 211 269 349 minecraft:lime_stained_glass
fill 211 269 355 211 271 355 minecraft:light_gray_concrete
fill 211 269 357 211 271 357 minecraft:light_gray_concrete
fill 211 269 359 211 271 359 minecraft:light_gray_concrete
fill 211 269 361 211 271 361 minecraft:light_gray_concrete
fill 211 269 363 211 271 363 minecraft:light_gray_concrete
fill 212 269 322 212 296 322 minecraft:black_concrete
fill 212 269 354 212 271 354 minecraft:light_gray_concrete
fill 212 269 356 212 271 356 minecraft:light_gray_concrete
fill 212 269 358 212 271 358 minecraft:light_gray_concrete
fill 212 269 360 212 271 360 minecraft:light_gray_concrete
fill 212 269 362 212 271 362 minecraft:light_gray_concrete
fill 213 269 340 213 271 340 minecraft:lime_stained_glass
fill 213 269 348 213 271 348 minecraft:lime_stained_glass
fill 213 269 355 213 271 355 minecraft:light_gray_concrete
fill 213 269 357 213 271 357 minecraft:light_gray_concrete
fill 213 269 359 213 271 359 minecraft:light_gray_concrete
fill 213 269 361 213 271 361 minecraft:light_gray_concrete
fill 213 269 363 213 271 363 minecraft:light_gray_concrete
schedule function dropper:buildpart/76_3 1t
