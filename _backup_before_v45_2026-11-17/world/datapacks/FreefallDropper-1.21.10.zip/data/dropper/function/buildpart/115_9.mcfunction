fill 361 257 504 361 260 504 minecraft:pink_terracotta
setblock 362 257 502 minecraft:red_nether_bricks
fill 362 257 503 362 260 503 minecraft:pink_terracotta
setblock 363 257 501 minecraft:red_nether_bricks
fill 363 257 502 363 259 502 minecraft:pink_terracotta
setblock 364 257 465 minecraft:red_nether_bricks
fill 364 257 481 364 268 481 minecraft:iron_block
setblock 365 257 464 minecraft:red_nether_bricks
setblock 365 257 504 minecraft:red_nether_bricks
fill 366 257 464 366 259 464 minecraft:pink_terracotta
setblock 366 257 503 minecraft:red_nether_bricks
fill 366 257 504 366 260 504 minecraft:pink_terracotta
fill 367 257 503 367 258 503 minecraft:pink_terracotta
setblock 370 257 464 minecraft:white_concrete
setblock 370 257 480 minecraft:pink_terracotta
setblock 370 257 484 minecraft:red_nether_bricks
fill 370 257 485 370 260 485 minecraft:pink_terracotta
setblock 370 257 489 minecraft:red_nether_bricks
setblock 370 257 499 minecraft:red_nether_bricks
setblock 370 257 500 minecraft:pink_terracotta
setblock 370 257 504 minecraft:red_nether_bricks
setblock 330 258 466 minecraft:white_concrete
setblock 330 258 479 minecraft:pink_terracotta
setblock 330 258 482 minecraft:pink_terracotta
setblock 330 258 483 minecraft:red_nether_bricks
fill 330 258 484 330 261 484 minecraft:pink_terracotta
setblock 330 258 488 minecraft:red_nether_bricks
fill 330 258 489 330 261 489 minecraft:pink_terracotta
setblock 331 258 482 minecraft:red_nether_bricks
fill 331 258 483 331 261 483 minecraft:pink_terracotta
setblock 334 258 464 minecraft:red_nether_bricks
fill 335 258 464 338 258 464 minecraft:pink_terracotta
fill 335 258 504 338 258 504 minecraft:pink_terracotta
fill 336 258 465 337 258 465 minecraft:pink_terracotta
setblock 338 258 465 minecraft:red_nether_bricks
setblock 339 258 464 minecraft:red_nether_bricks
fill 339 258 465 339 260 466 minecraft:pink_terracotta
setblock 339 258 504 minecraft:red_nether_bricks
fill 340 258 464 340 261 464 minecraft:pink_terracotta
setblock 340 258 503 minecraft:red_nether_bricks
fill 340 258 504 340 261 504 minecraft:pink_terracotta
fill 341 258 503 341 259 503 minecraft:pink_terracotta
setblock 342 258 466 minecraft:red_nether_bricks
setblock 343 258 465 minecraft:red_nether_bricks
fill 343 258 466 343 261 466 minecraft:pink_terracotta
setblock 344 258 464 minecraft:red_nether_bricks
fill 344 258 465 344 261 465 minecraft:pink_terracotta
setblock 344 258 504 minecraft:red_nether_bricks
fill 345 258 464 348 258 464 minecraft:pink_terracotta
fill 345 258 504 348 258 504 minecraft:pink_terracotta
setblock 348 258 465 minecraft:red_nether_bricks
setblock 349 258 464 minecraft:red_nether_bricks
setblock 349 258 465 minecraft:pink_terracotta
setblock 349 258 504 minecraft:red_nether_bricks
fill 350 258 464 350 261 464 minecraft:pink_terracotta
fill 350 258 504 350 261 504 minecraft:pink_terracotta
setblock 353 258 465 minecraft:red_nether_bricks
setblock 354 258 464 minecraft:red_nether_bricks
fill 354 258 465 357 258 465 minecraft:pink_terracotta
setblock 354 258 504 minecraft:red_nether_bricks
fill 355 258 464 355 261 464 minecraft:pink_terracotta
setblock 355 258 503 minecraft:red_nether_bricks
fill 355 258 504 355 261 504 minecraft:pink_terracotta
fill 356 258 503 356 261 503 minecraft:pink_terracotta
fill 357 258 502 357 261 502 minecraft:pink_terracotta
setblock 358 258 465 minecraft:red_nether_bricks
setblock 359 258 464 minecraft:red_nether_bricks
fill 359 258 465 359 261 465 minecraft:pink_terracotta
setblock 359 258 504 minecraft:red_nether_bricks
fill 360 258 464 360 261 464 minecraft:pink_terracotta
setblock 360 258 503 minecraft:red_nether_bricks
fill 360 258 504 360 261 504 minecraft:pink_terracotta
setblock 361 258 502 minecraft:red_nether_bricks
fill 361 258 503 361 261 503 minecraft:pink_terracotta
fill 362 258 502 362 260 502 minecraft:pink_terracotta
setblock 363 258 465 minecraft:red_nether_bricks
setblock 364 258 464 minecraft:red_nether_bricks
setblock 364 258 465 minecraft:pink_terracotta
setblock 364 258 504 minecraft:red_nether_bricks
fill 365 258 464 365 261 464 minecraft:pink_terracotta
setblock 365 258 503 minecraft:red_nether_bricks
fill 365 258 504 365 261 504 minecraft:pink_terracotta
fill 366 258 503 366 259 503 minecraft:pink_terracotta
setblock 369 258 504 minecraft:red_nether_bricks
setblock 370 258 483 minecraft:red_nether_bricks
fill 370 258 484 370 261 484 minecraft:pink_terracotta
setblock 370 258 488 minecraft:red_nether_bricks
fill 370 258 489 370 261 489 minecraft:pink_terracotta
setblock 370 258 503 minecraft:red_nether_bricks
setblock 370 258 504 minecraft:pink_terracotta
setblock 330 259 472 minecraft:white_concrete
setblock 330 259 482 minecraft:red_nether_bricks
fill 330 259 483 330 262 483 minecraft:pink_terracotta
setblock 330 259 487 minecraft:red_nether_bricks
fill 330 259 488 330 262 488 minecraft:pink_terracotta
setblock 330 259 491 minecraft:white_concrete
setblock 331 259 482 minecraft:pink_terracotta
setblock 331 259 486 minecraft:red_nether_bricks
fill 334 259 464 337 259 464 minecraft:pink_terracotta
fill 335 259 504 337 259 504 minecraft:pink_terracotta
setblock 336 259 465 minecraft:pink_terracotta
setblock 337 259 465 minecraft:red_nether_bricks
setblock 338 259 464 minecraft:red_nether_bricks
fill 338 259 465 338 261 466 minecraft:pink_terracotta
setblock 338 259 504 minecraft:red_nether_bricks
fill 339 259 464 339 262 464 minecraft:pink_terracotta
fill 339 259 504 339 262 504 minecraft:pink_terracotta
setblock 340 259 503 minecraft:pink_terracotta
setblock 341 259 466 minecraft:red_nether_bricks
setblock 342 259 465 minecraft:red_nether_bricks
fill 342 259 466 342 262 466 minecraft:pink_terracotta
setblock 343 259 464 minecraft:red_nether_bricks
fill 343 259 465 343 262 465 minecraft:pink_terracotta
setblock 343 259 504 minecraft:red_nether_bricks
fill 344 259 464 347 259 464 minecraft:pink_terracotta
fill 344 259 504 347 259 504 minecraft:pink_terracotta
setblock 347 259 465 minecraft:red_nether_bricks
setblock 348 259 464 minecraft:red_nether_bricks
fill 348 259 465 348 262 465 minecraft:pink_terracotta
setblock 348 259 504 minecraft:red_nether_bricks
fill 349 259 464 349 262 464 minecraft:pink_terracotta
fill 349 259 504 349 262 504 minecraft:pink_terracotta
setblock 352 259 465 minecraft:red_nether_bricks
setblock 353 259 464 minecraft:red_nether_bricks
fill 353 259 465 356 259 465 minecraft:pink_terracotta
setblock 353 259 504 minecraft:red_nether_bricks
fill 354 259 464 354 262 464 minecraft:pink_terracotta
setblock 354 259 503 minecraft:red_nether_bricks
fill 354 259 504 354 262 504 minecraft:pink_terracotta
fill 355 259 503 355 262 503 minecraft:pink_terracotta
setblock 357 259 465 minecraft:red_nether_bricks
setblock 358 259 464 minecraft:red_nether_bricks
fill 358 259 465 358 262 465 minecraft:pink_terracotta
setblock 358 259 504 minecraft:red_nether_bricks
fill 359 259 464 359 262 464 minecraft:pink_terracotta
setblock 359 259 503 minecraft:red_nether_bricks
fill 359 259 504 359 262 504 minecraft:pink_terracotta
setblock 360 259 502 minecraft:red_nether_bricks
fill 360 259 503 360 262 503 minecraft:pink_terracotta
fill 361 259 502 361 261 502 minecraft:pink_terracotta
setblock 362 259 465 minecraft:red_nether_bricks
setblock 363 259 464 minecraft:red_nether_bricks
fill 363 259 465 363 260 465 minecraft:pink_terracotta
setblock 363 259 504 minecraft:red_nether_bricks
fill 364 259 464 364 262 464 minecraft:pink_terracotta
setblock 364 259 503 minecraft:red_nether_bricks
fill 364 259 504 364 262 504 minecraft:pink_terracotta
fill 365 259 503 365 260 503 minecraft:pink_terracotta
setblock 368 259 504 minecraft:red_nether_bricks
setblock 369 259 504 minecraft:pink_terracotta
setblock 370 259 477 minecraft:white_concrete
setblock 370 259 482 minecraft:red_nether_bricks
fill 370 259 483 370 262 483 minecraft:pink_terracotta
setblock 370 259 487 minecraft:red_nether_bricks
fill 370 259 488 370 262 488 minecraft:pink_terracotta
setblock 370 259 496 minecraft:white_concrete
setblock 330 260 478 minecraft:white_concrete
setblock 330 260 481 minecraft:red_nether_bricks
fill 330 260 482 330 263 482 minecraft:pink_terracotta
setblock 330 260 486 minecraft:red_nether_bricks
fill 330 260 487 330 263 487 minecraft:pink_terracotta
setblock 330 260 497 minecraft:white_concrete
setblock 331 260 485 minecraft:red_nether_bricks
fill 331 260 486 331 263 486 minecraft:pink_terracotta
fill 333 260 464 336 260 464 minecraft:pink_terracotta
setblock 335 260 465 minecraft:pink_terracotta
fill 335 260 504 336 260 504 minecraft:pink_terracotta
setblock 336 260 465 minecraft:red_nether_bricks
setblock 337 260 464 minecraft:red_nether_bricks
fill 337 260 465 337 262 466 minecraft:pink_terracotta
setblock 337 260 504 minecraft:red_nether_bricks
fill 338 260 464 338 263 464 minecraft:pink_terracotta
fill 338 260 504 338 263 504 minecraft:pink_terracotta
setblock 340 260 465 minecraft:pink_terracotta
setblock 340 260 466 minecraft:red_nether_bricks
setblock 341 260 465 minecraft:red_nether_bricks
fill 341 260 466 341 263 466 minecraft:pink_terracotta
setblock 342 260 464 minecraft:red_nether_bricks
fill 342 260 465 342 263 465 minecraft:pink_terracotta
setblock 342 260 504 minecraft:red_nether_bricks
fill 343 260 464 346 260 464 minecraft:pink_terracotta
fill 343 260 504 346 260 504 minecraft:pink_terracotta
setblock 346 260 465 minecraft:red_nether_bricks
setblock 347 260 464 minecraft:red_nether_bricks
fill 347 260 465 347 263 465 minecraft:pink_terracotta
setblock 347 260 504 minecraft:red_nether_bricks
fill 348 260 464 348 263 464 minecraft:pink_terracotta
fill 348 260 504 348 263 504 minecraft:pink_terracotta
fill 349 260 465 349 261 465 minecraft:pink_terracotta
setblock 351 260 465 minecraft:red_nether_bricks
setblock 352 260 464 minecraft:red_nether_bricks
fill 352 260 465 355 260 465 minecraft:pink_terracotta
setblock 352 260 504 minecraft:red_nether_bricks
fill 353 260 464 353 263 464 minecraft:pink_terracotta
fill 353 260 504 353 263 504 minecraft:pink_terracotta
fill 354 260 503 354 263 503 minecraft:pink_terracotta
setblock 356 260 465 minecraft:red_nether_bricks
setblock 357 260 464 minecraft:red_nether_bricks
fill 357 260 465 357 263 465 minecraft:pink_terracotta
setblock 357 260 504 minecraft:red_nether_bricks
fill 358 260 464 358 263 464 minecraft:pink_terracotta
setblock 358 260 503 minecraft:red_nether_bricks
fill 358 260 504 358 263 504 minecraft:pink_terracotta
setblock 359 260 502 minecraft:red_nether_bricks
fill 359 260 503 359 263 503 minecraft:pink_terracotta
fill 360 260 502 360 262 502 minecraft:pink_terracotta
setblock 361 260 465 minecraft:red_nether_bricks
setblock 362 260 464 minecraft:red_nether_bricks
fill 362 260 465 362 263 465 minecraft:pink_terracotta
setblock 362 260 504 minecraft:red_nether_bricks
fill 363 260 464 363 263 464 minecraft:pink_terracotta
setblock 363 260 503 minecraft:red_nether_bricks
fill 363 260 504 363 263 504 minecraft:pink_terracotta
fill 364 260 503 364 261 503 minecraft:pink_terracotta
setblock 367 260 504 minecraft:red_nether_bricks
setblock 368 260 504 minecraft:pink_terracotta
setblock 370 260 471 minecraft:white_concrete
fill 370 260 482 370 263 482 minecraft:pink_terracotta
setblock 370 260 486 minecraft:red_nether_bricks
fill 370 260 487 370 263 487 minecraft:pink_terracotta
setblock 370 260 490 minecraft:pink_terracotta
setblock 330 261 480 minecraft:red_nether_bricks
fill 330 261 481 330 264 481 minecraft:pink_terracotta
setblock 330 261 485 minecraft:red_nether_bricks
fill 330 261 486 330 264 486 minecraft:pink_terracotta
setblock 330 261 490 minecraft:red_nether_bricks
setblock 330 261 503 minecraft:white_concrete
setblock 331 261 484 minecraft:red_nether_bricks
fill 331 261 485 331 264 485 minecraft:pink_terracotta
fill 331 261 487 331 262 487 minecraft:pink_terracotta
fill 332 261 464 335 261 464 minecraft:pink_terracotta
setblock 334 261 465 minecraft:pink_terracotta
setblock 335 261 465 minecraft:red_nether_bricks
setblock 335 261 504 minecraft:pink_terracotta
setblock 336 261 464 minecraft:red_nether_bricks
fill 336 261 465 336 263 466 minecraft:pink_terracotta
setblock 336 261 504 minecraft:red_nether_bricks
fill 337 261 464 337 264 464 minecraft:pink_terracotta
fill 337 261 504 337 264 504 minecraft:pink_terracotta
setblock 339 261 465 minecraft:pink_terracotta
setblock 339 261 466 minecraft:red_nether_bricks
setblock 340 261 465 minecraft:red_nether_bricks
fill 340 261 466 340 264 466 minecraft:pink_terracotta
setblock 341 261 464 minecraft:red_nether_bricks
fill 341 261 465 341 264 465 minecraft:pink_terracotta
setblock 341 261 504 minecraft:red_nether_bricks
fill 342 261 464 345 261 464 minecraft:pink_terracotta
fill 342 261 504 345 261 504 minecraft:pink_terracotta
setblock 344 261 466 minecraft:red_nether_bricks
setblock 345 261 465 minecraft:red_nether_bricks
setblock 346 261 464 minecraft:red_nether_bricks
fill 346 261 465 346 264 465 minecraft:pink_terracotta
setblock 346 261 504 minecraft:red_nether_bricks
fill 347 261 464 347 264 464 minecraft:pink_terracotta
fill 347 261 504 347 264 504 minecraft:pink_terracotta
setblock 350 261 465 minecraft:red_nether_bricks
setblock 351 261 464 minecraft:red_nether_bricks
fill 351 261 465 354 261 465 minecraft:pink_terracotta
setblock 351 261 504 minecraft:red_nether_bricks
fill 352 261 464 352 264 464 minecraft:pink_terracotta
fill 352 261 504 352 264 504 minecraft:pink_terracotta
fill 353 261 503 353 264 503 minecraft:pink_terracotta
setblock 355 261 465 minecraft:red_nether_bricks
setblock 356 261 464 minecraft:red_nether_bricks
fill 356 261 465 356 264 465 minecraft:pink_terracotta
setblock 356 261 504 minecraft:red_nether_bricks
fill 357 261 464 357 264 464 minecraft:pink_terracotta
fill 357 261 466 358 261 466 minecraft:pink_terracotta
setblock 357 261 503 minecraft:red_nether_bricks
fill 357 261 504 357 264 504 minecraft:pink_terracotta
setblock 358 261 502 minecraft:red_nether_bricks
fill 358 261 503 358 264 503 minecraft:pink_terracotta
fill 359 261 502 359 264 502 minecraft:pink_terracotta
setblock 360 261 465 minecraft:red_nether_bricks
setblock 361 261 464 minecraft:red_nether_bricks
fill 361 261 465 361 264 465 minecraft:pink_terracotta
setblock 361 261 504 minecraft:red_nether_bricks
fill 362 261 464 362 264 464 minecraft:pink_terracotta
setblock 362 261 503 minecraft:red_nether_bricks
fill 362 261 504 362 264 504 minecraft:pink_terracotta
fill 363 261 503 363 262 503 minecraft:pink_terracotta
setblock 366 261 504 minecraft:red_nether_bricks
setblock 367 261 504 minecraft:pink_terracotta
setblock 370 261 465 minecraft:white_concrete
setblock 370 261 485 minecraft:red_nether_bricks
fill 370 261 486 370 264 486 minecraft:pink_terracotta
setblock 370 261 490 minecraft:red_nether_bricks
fill 370 261 491 370 264 491 minecraft:pink_terracotta
setblock 330 262 465 minecraft:white_concrete
fill 330 262 480 330 265 480 minecraft:pink_terracotta
setblock 330 262 484 minecraft:red_nether_bricks
fill 330 262 485 330 265 485 minecraft:pink_terracotta
setblock 330 262 489 minecraft:red_nether_bricks
fill 330 262 490 330 265 490 minecraft:pink_terracotta
fill 331 262 464 334 262 464 minecraft:pink_terracotta
setblock 331 262 483 minecraft:red_nether_bricks
fill 331 262 484 331 265 484 minecraft:pink_terracotta
setblock 331 262 488 minecraft:red_nether_bricks
setblock 333 262 465 minecraft:pink_terracotta
setblock 334 262 465 minecraft:red_nether_bricks
setblock 335 262 464 minecraft:red_nether_bricks
fill 335 262 465 335 264 466 minecraft:pink_terracotta
setblock 335 262 504 minecraft:red_nether_bricks
fill 336 262 464 336 265 464 minecraft:pink_terracotta
fill 336 262 504 336 265 504 minecraft:pink_terracotta
setblock 338 262 465 minecraft:pink_terracotta
setblock 338 262 466 minecraft:red_nether_bricks
setblock 339 262 465 minecraft:red_nether_bricks
fill 339 262 466 339 264 467 minecraft:pink_terracotta
setblock 340 262 464 minecraft:red_nether_bricks
fill 340 262 465 340 265 465 minecraft:pink_terracotta
setblock 340 262 504 minecraft:red_nether_bricks
fill 341 262 464 344 262 464 minecraft:pink_terracotta
fill 341 262 504 344 262 504 minecraft:pink_terracotta
setblock 343 262 466 minecraft:red_nether_bricks
setblock 344 262 465 minecraft:red_nether_bricks
fill 344 262 466 344 265 466 minecraft:pink_terracotta
setblock 345 262 464 minecraft:red_nether_bricks
fill 345 262 465 345 265 465 minecraft:pink_terracotta
setblock 345 262 504 minecraft:red_nether_bricks
fill 346 262 464 346 265 464 minecraft:pink_terracotta
fill 346 262 504 346 265 504 minecraft:pink_terracotta
setblock 349 262 465 minecraft:red_nether_bricks
setblock 350 262 464 minecraft:red_nether_bricks
fill 350 262 465 353 262 465 minecraft:pink_terracotta
setblock 350 262 504 minecraft:red_nether_bricks
fill 351 262 464 351 265 464 minecraft:pink_terracotta
fill 351 262 504 351 265 504 minecraft:pink_terracotta
setblock 354 262 465 minecraft:red_nether_bricks
setblock 355 262 464 minecraft:red_nether_bricks
fill 355 262 465 355 264 466 minecraft:pink_terracotta
setblock 355 262 504 minecraft:red_nether_bricks
fill 356 262 464 356 265 464 minecraft:pink_terracotta
fill 356 262 466 357 262 466 minecraft:pink_terracotta
setblock 356 262 503 minecraft:red_nether_bricks
fill 356 262 504 356 265 504 minecraft:pink_terracotta
setblock 357 262 502 minecraft:red_nether_bricks
fill 357 262 503 357 265 503 minecraft:pink_terracotta
setblock 358 262 466 minecraft:red_nether_bricks
fill 358 262 502 358 265 502 minecraft:pink_terracotta
setblock 359 262 465 minecraft:red_nether_bricks
fill 359 262 466 359 265 466 minecraft:pink_terracotta
setblock 360 262 464 minecraft:red_nether_bricks
fill 360 262 465 360 265 465 minecraft:pink_terracotta
setblock 360 262 504 minecraft:red_nether_bricks
fill 361 262 464 361 265 464 minecraft:pink_terracotta
setblock 361 262 503 minecraft:red_nether_bricks
fill 361 262 504 361 265 504 minecraft:pink_terracotta
fill 362 262 503 362 264 503 minecraft:pink_terracotta
setblock 365 262 464 minecraft:red_nether_bricks
setblock 365 262 504 minecraft:red_nether_bricks
setblock 366 262 504 minecraft:pink_terracotta
fill 369 262 486 369 262 489 minecraft:pink_terracotta
setblock 370 262 478 minecraft:white_concrete
setblock 370 262 484 minecraft:red_nether_bricks
fill 370 262 485 370 265 485 minecraft:pink_terracotta
setblock 370 262 489 minecraft:red_nether_bricks
fill 370 262 490 370 265 490 minecraft:pink_terracotta
fill 370 262 492 370 263 492 minecraft:pink_terracotta
setblock 370 262 503 minecraft:white_concrete
fill 330 263 464 330 263 467 minecraft:pink_terracotta
setblock 330 263 468 minecraft:red_nether_bricks
fill 330 263 469 330 265 470 minecraft:pink_terracotta
setblock 330 263 471 minecraft:white_concrete
setblock 330 263 483 minecraft:red_nether_bricks
fill 330 263 484 330 266 484 minecraft:pink_terracotta
setblock 330 263 488 minecraft:red_nether_bricks
fill 330 263 489 331 265 489 minecraft:pink_terracotta
fill 330 263 491 330 264 491 minecraft:pink_terracotta
setblock 330 263 496 minecraft:white_concrete
fill 331 263 464 333 263 464 minecraft:pink_terracotta
setblock 331 263 482 minecraft:red_nether_bricks
fill 331 263 483 331 266 483 minecraft:pink_terracotta
setblock 331 263 487 minecraft:red_nether_bricks
fill 331 263 488 331 266 488 minecraft:pink_terracotta
setblock 332 263 465 minecraft:pink_terracotta
setblock 332 263 466 minecraft:light[level=12]
setblock 332 263 474 minecraft:light[level=12]
setblock 332 263 482 minecraft:light[level=12]
setblock 332 263 490 minecraft:light[level=12]
setblock 332 263 498 minecraft:light[level=12]
setblock 333 263 465 minecraft:red_nether_bricks
setblock 334 263 464 minecraft:red_nether_bricks
fill 334 263 465 334 265 466 minecraft:pink_terracotta
setblock 334 263 504 minecraft:red_nether_bricks
fill 335 263 464 335 266 464 minecraft:pink_terracotta
fill 335 263 504 335 266 504 minecraft:pink_terracotta
setblock 337 263 465 minecraft:pink_terracotta
setblock 337 263 466 minecraft:red_nether_bricks
fill 337 263 467 338 265 467 minecraft:pink_terracotta
setblock 338 263 465 minecraft:red_nether_bricks
fill 338 263 466 338 266 466 minecraft:pink_terracotta
setblock 339 263 464 minecraft:red_nether_bricks
fill 339 263 465 339 266 465 minecraft:pink_terracotta
setblock 339 263 504 minecraft:red_nether_bricks
fill 340 263 464 343 263 464 minecraft:pink_terracotta
setblock 340 263 467 minecraft:pink_terracotta
setblock 340 263 474 minecraft:light[level=12]
setblock 340 263 482 minecraft:light[level=12]
setblock 340 263 490 minecraft:light[level=12]
setblock 340 263 498 minecraft:light[level=12]
fill 340 263 504 343 263 504 minecraft:pink_terracotta
setblock 341 263 467 minecraft:red_nether_bricks
setblock 342 263 466 minecraft:red_nether_bricks
setblock 343 263 465 minecraft:red_nether_bricks
fill 343 263 466 343 266 466 minecraft:pink_terracotta
setblock 344 263 464 minecraft:red_nether_bricks
fill 344 263 465 344 266 465 minecraft:pink_terracotta
setblock 344 263 504 minecraft:red_nether_bricks
fill 345 263 464 345 266 464 minecraft:pink_terracotta
fill 345 263 504 345 266 504 minecraft:pink_terracotta
setblock 348 263 465 minecraft:red_nether_bricks
setblock 348 263 466 minecraft:light[level=12]
setblock 348 263 474 minecraft:light[level=12]
setblock 348 263 482 minecraft:light[level=12]
setblock 348 263 490 minecraft:light[level=12]
setblock 348 263 498 minecraft:light[level=12]
setblock 349 263 464 minecraft:red_nether_bricks
fill 349 263 465 352 263 465 minecraft:pink_terracotta
setblock 349 263 504 minecraft:red_nether_bricks
fill 350 263 464 350 266 464 minecraft:pink_terracotta
fill 350 263 504 350 266 504 minecraft:pink_terracotta
setblock 353 263 465 minecraft:red_nether_bricks
fill 353 263 466 354 265 466 minecraft:pink_terracotta
setblock 354 263 464 minecraft:red_nether_bricks
fill 354 263 465 354 266 465 minecraft:pink_terracotta
setblock 354 263 504 minecraft:red_nether_bricks
fill 355 263 464 355 266 464 minecraft:pink_terracotta
setblock 355 263 503 minecraft:red_nether_bricks
fill 355 263 504 355 266 504 minecraft:pink_terracotta
setblock 356 263 466 minecraft:pink_terracotta
setblock 356 263 474 minecraft:light[level=12]
setblock 356 263 482 minecraft:light[level=12]
setblock 356 263 490 minecraft:light[level=12]
setblock 356 263 498 minecraft:light[level=12]
setblock 356 263 502 minecraft:red_nether_bricks
fill 356 263 503 356 266 503 minecraft:pink_terracotta
setblock 357 263 466 minecraft:red_nether_bricks
fill 357 263 502 357 266 502 minecraft:pink_terracotta
setblock 358 263 465 minecraft:red_nether_bricks
fill 358 263 466 358 266 466 minecraft:pink_terracotta
setblock 359 263 464 minecraft:red_nether_bricks
fill 359 263 465 359 266 465 minecraft:pink_terracotta
setblock 359 263 504 minecraft:red_nether_bricks
fill 360 263 464 360 266 464 minecraft:pink_terracotta
setblock 360 263 503 minecraft:red_nether_bricks
fill 360 263 504 360 266 504 minecraft:pink_terracotta
fill 361 263 503 361 266 503 minecraft:pink_terracotta
setblock 364 263 464 minecraft:red_nether_bricks
setblock 364 263 466 minecraft:light[level=12]
setblock 364 263 474 minecraft:light[level=12]
setblock 364 263 482 minecraft:light[level=12]
setblock 364 263 490 minecraft:light[level=12]
setblock 364 263 498 minecraft:light[level=12]
setblock 364 263 504 minecraft:red_nether_bricks
fill 365 263 504 365 264 504 minecraft:pink_terracotta
setblock 366 263 504 minecraft:white_concrete
fill 369 263 485 369 263 488 minecraft:pink_terracotta
setblock 369 263 489 minecraft:red_nether_bricks
fill 369 263 490 369 266 490 minecraft:pink_terracotta
setblock 370 263 472 minecraft:white_concrete
setblock 370 263 483 minecraft:red_nether_bricks
fill 370 263 484 370 266 484 minecraft:pink_terracotta
setblock 370 263 488 minecraft:red_nether_bricks
fill 370 263 489 370 266 489 minecraft:pink_terracotta
setblock 370 263 493 minecraft:red_nether_bricks
setblock 370 263 497 minecraft:white_concrete
fill 330 264 464 330 264 466 minecraft:pink_terracotta
setblock 330 264 467 minecraft:red_nether_bricks
fill 330 264 468 331 266 468 minecraft:pink_terracotta
setblock 330 264 471 minecraft:pink_terracotta
setblock 330 264 472 minecraft:red_nether_bricks
fill 330 264 473 330 266 474 minecraft:pink_terracotta
setblock 330 264 477 minecraft:white_concrete
fill 330 264 478 330 266 479 minecraft:pink_terracotta
setblock 330 264 482 minecraft:red_nether_bricks
fill 330 264 483 330 267 483 minecraft:pink_terracotta
setblock 330 264 487 minecraft:red_nether_bricks
fill 330 264 488 330 267 488 minecraft:pink_terracotta
setblock 330 264 492 minecraft:red_nether_bricks
setblock 330 264 502 minecraft:white_concrete
fill 331 264 464 331 264 465 minecraft:pink_terracotta
setblock 331 264 466 minecraft:red_nether_bricks
fill 331 264 467 331 267 467 minecraft:pink_terracotta
fill 331 264 469 331 264 470 minecraft:pink_terracotta
setblock 331 264 471 minecraft:red_nether_bricks
fill 331 264 482 331 267 482 minecraft:pink_terracotta
setblock 331 264 486 minecraft:red_nether_bricks
fill 331 264 487 332 266 487 minecraft:pink_terracotta
setblock 331 264 490 minecraft:pink_terracotta
setblock 331 264 491 minecraft:red_nether_bricks
setblock 332 264 464 minecraft:pink_terracotta
setblock 332 264 465 minecraft:red_nether_bricks
setblock 332 264 485 minecraft:red_nether_bricks
fill 332 264 486 332 267 486 minecraft:pink_terracotta
fill 332 264 488 332 265 488 minecraft:pink_terracotta
setblock 333 264 464 minecraft:red_nether_bricks
fill 333 264 465 333 266 466 minecraft:pink_terracotta
fill 334 264 464 334 267 464 minecraft:pink_terracotta
fill 334 264 504 334 267 504 minecraft:pink_terracotta
setblock 335 264 467 minecraft:red_nether_bricks
setblock 336 264 465 minecraft:pink_terracotta
setblock 336 264 466 minecraft:red_nether_bricks
fill 336 264 467 336 267 467 minecraft:pink_terracotta
setblock 337 264 465 minecraft:red_nether_bricks
fill 337 264 466 337 267 466 minecraft:pink_terracotta
setblock 338 264 464 minecraft:red_nether_bricks
fill 338 264 465 338 267 465 minecraft:pink_terracotta
setblock 338 264 504 minecraft:red_nether_bricks
fill 339 264 464 342 264 464 minecraft:pink_terracotta
fill 339 264 504 342 264 504 minecraft:pink_terracotta
setblock 340 264 467 minecraft:red_nether_bricks
setblock 341 264 466 minecraft:red_nether_bricks
fill 341 264 467 341 267 467 minecraft:pink_terracotta
setblock 342 264 465 minecraft:red_nether_bricks
fill 342 264 466 342 267 466 minecraft:pink_terracotta
setblock 343 264 464 minecraft:red_nether_bricks
fill 343 264 465 343 267 465 minecraft:pink_terracotta
setblock 343 264 504 minecraft:red_nether_bricks
fill 344 264 464 344 267 464 minecraft:pink_terracotta
fill 344 264 504 344 267 504 minecraft:pink_terracotta
setblock 345 264 466 minecraft:pink_terracotta
setblock 347 264 465 minecraft:red_nether_bricks
setblock 348 264 464 minecraft:red_nether_bricks
fill 348 264 465 351 264 465 minecraft:pink_terracotta
setblock 348 264 504 minecraft:red_nether_bricks
fill 349 264 464 349 267 464 minecraft:pink_terracotta
fill 349 264 504 349 267 504 minecraft:pink_terracotta
setblock 351 264 466 minecraft:red_nether_bricks
setblock 352 264 465 minecraft:red_nether_bricks
fill 352 264 466 352 267 466 minecraft:pink_terracotta
fill 352 264 503 352 265 503 minecraft:pink_terracotta
setblock 353 264 464 minecraft:red_nether_bricks
fill 353 264 465 353 267 465 minecraft:pink_terracotta
setblock 353 264 504 minecraft:red_nether_bricks
fill 354 264 464 354 267 464 minecraft:pink_terracotta
setblock 354 264 503 minecraft:red_nether_bricks
fill 354 264 504 354 267 504 minecraft:pink_terracotta
fill 355 264 503 355 267 503 minecraft:pink_terracotta
setblock 356 264 466 minecraft:red_nether_bricks
fill 356 264 502 356 267 502 minecraft:pink_terracotta
setblock 357 264 465 minecraft:red_nether_bricks
fill 357 264 466 357 267 466 minecraft:pink_terracotta
setblock 358 264 464 minecraft:red_nether_bricks
fill 358 264 465 358 267 465 minecraft:pink_terracotta
setblock 358 264 504 minecraft:red_nether_bricks
fill 359 264 464 359 267 464 minecraft:pink_terracotta
setblock 359 264 503 minecraft:red_nether_bricks
fill 359 264 504 359 267 504 minecraft:pink_terracotta
fill 360 264 503 360 267 503 minecraft:pink_terracotta
setblock 362 264 465 minecraft:red_nether_bricks
setblock 363 264 464 minecraft:red_nether_bricks
setblock 363 264 504 minecraft:red_nether_bricks
fill 364 264 464 364 265 464 minecraft:pink_terracotta
fill 364 264 504 364 265 504 minecraft:pink_terracotta
fill 369 264 484 369 264 487 minecraft:pink_terracotta
setblock 369 264 488 minecraft:red_nether_bricks
fill 369 264 489 369 267 489 minecraft:pink_terracotta
fill 369 264 491 369 264 492 minecraft:pink_terracotta
setblock 370 264 466 minecraft:white_concrete
setblock 370 264 481 minecraft:pink_terracotta
setblock 370 264 482 minecraft:red_nether_bricks
fill 370 264 483 370 267 483 minecraft:pink_terracotta
setblock 370 264 487 minecraft:red_nether_bricks
fill 370 264 488 370 267 488 minecraft:pink_terracotta
setblock 370 264 492 minecraft:red_nether_bricks
fill 370 264 493 370 265 495 minecraft:pink_terracotta
fill 330 265 464 330 265 465 minecraft:pink_terracotta
setblock 330 265 466 minecraft:red_nether_bricks
fill 330 265 467 330 268 467 minecraft:pink_terracotta
setblock 330 265 471 minecraft:red_nether_bricks
fill 330 265 472 332 266 472 minecraft:pink_terracotta
setblock 330 265 475 minecraft:pink_terracotta
setblock 330 265 476 minecraft:red_nether_bricks
fill 330 265 477 330 268 477 minecraft:pink_terracotta
setblock 330 265 481 minecraft:red_nether_bricks
fill 330 265 482 330 268 482 minecraft:pink_terracotta
setblock 330 265 486 minecraft:red_nether_bricks
fill 330 265 487 330 268 487 minecraft:pink_terracotta
setblock 330 265 491 minecraft:red_nether_bricks
fill 330 265 492 330 266 494 minecraft:pink_terracotta
setblock 331 265 464 minecraft:pink_terracotta
setblock 331 265 465 minecraft:red_nether_bricks
fill 331 265 466 332 267 466 minecraft:pink_terracotta
setblock 331 265 469 minecraft:pink_terracotta
setblock 331 265 470 minecraft:red_nether_bricks
fill 331 265 471 332 267 471 minecraft:pink_terracotta
fill 331 265 473 331 265 474 minecraft:pink_terracotta
fill 331 265 481 331 268 481 minecraft:pink_terracotta
setblock 331 265 485 minecraft:red_nether_bricks
fill 331 265 486 331 268 486 minecraft:pink_terracotta
setblock 331 265 490 minecraft:red_nether_bricks
fill 331 265 491 331 267 492 minecraft:pink_terracotta
setblock 332 265 464 minecraft:red_nether_bricks
fill 332 265 465 332 268 465 minecraft:pink_terracotta
fill 332 265 467 332 265 468 minecraft:pink_terracotta
setblock 332 265 469 minecraft:red_nether_bricks
fill 332 265 470 332 268 470 minecraft:pink_terracotta
setblock 332 265 484 minecraft:red_nether_bricks
fill 332 265 485 332 268 485 minecraft:pink_terracotta
setblock 332 265 489 minecraft:red_nether_bricks
fill 333 265 464 333 268 464 minecraft:pink_terracotta
fill 333 265 504 333 268 504 minecraft:pink_terracotta
setblock 334 265 467 minecraft:red_nether_bricks
setblock 335 265 465 minecraft:pink_terracotta
setblock 335 265 466 minecraft:red_nether_bricks
fill 335 265 467 335 268 467 minecraft:pink_terracotta
setblock 336 265 465 minecraft:red_nether_bricks
fill 336 265 466 336 268 466 minecraft:pink_terracotta
setblock 337 265 464 minecraft:red_nether_bricks
fill 337 265 465 337 268 465 minecraft:pink_terracotta
setblock 337 265 504 minecraft:red_nether_bricks
fill 338 265 464 341 265 464 minecraft:pink_terracotta
fill 338 265 504 341 265 504 minecraft:pink_terracotta
setblock 339 265 466 minecraft:pink_terracotta
setblock 339 265 467 minecraft:red_nether_bricks
setblock 340 265 466 minecraft:red_nether_bricks
fill 340 265 467 340 268 467 minecraft:pink_terracotta
setblock 341 265 465 minecraft:red_nether_bricks
fill 341 265 466 341 268 466 minecraft:pink_terracotta
setblock 342 265 464 minecraft:red_nether_bricks
fill 342 265 465 342 268 465 minecraft:pink_terracotta
setblock 342 265 504 minecraft:red_nether_bricks
fill 343 265 464 343 268 464 minecraft:pink_terracotta
fill 343 265 504 343 267 504 minecraft:pink_terracotta
setblock 345 265 466 minecraft:red_nether_bricks
setblock 346 265 465 minecraft:red_nether_bricks
setblock 347 265 464 minecraft:red_nether_bricks
fill 347 265 465 350 265 465 minecraft:pink_terracotta
setblock 347 265 504 minecraft:red_nether_bricks
fill 348 265 464 348 268 464 minecraft:pink_terracotta
fill 348 265 504 348 268 504 minecraft:pink_terracotta
setblock 350 265 466 minecraft:red_nether_bricks
setblock 351 265 465 minecraft:red_nether_bricks
fill 351 265 466 351 268 466 minecraft:pink_terracotta
fill 351 265 503 351 266 503 minecraft:pink_terracotta
setblock 352 265 464 minecraft:red_nether_bricks
fill 352 265 465 352 268 465 minecraft:pink_terracotta
setblock 352 265 504 minecraft:red_nether_bricks
fill 353 265 464 353 268 464 minecraft:pink_terracotta
setblock 353 265 503 minecraft:red_nether_bricks
fill 353 265 504 353 268 504 minecraft:pink_terracotta
fill 354 265 503 354 268 503 minecraft:pink_terracotta
setblock 355 265 465 minecraft:pink_terracotta
setblock 355 265 466 minecraft:red_nether_bricks
fill 355 265 502 355 268 502 minecraft:pink_terracotta
setblock 356 265 465 minecraft:red_nether_bricks
fill 356 265 466 356 268 466 minecraft:pink_terracotta
setblock 357 265 464 minecraft:red_nether_bricks
fill 357 265 465 357 268 465 minecraft:pink_terracotta
setblock 357 265 504 minecraft:red_nether_bricks
fill 358 265 464 358 268 464 minecraft:pink_terracotta
setblock 358 265 503 minecraft:red_nether_bricks
fill 358 265 504 358 268 504 minecraft:pink_terracotta
fill 359 265 503 359 268 503 minecraft:pink_terracotta
setblock 361 265 465 minecraft:red_nether_bricks
setblock 362 265 464 minecraft:red_nether_bricks
setblock 362 265 465 minecraft:pink_terracotta
setblock 362 265 504 minecraft:red_nether_bricks
fill 363 265 464 363 266 464 minecraft:pink_terracotta
fill 363 265 504 363 266 504 minecraft:pink_terracotta
setblock 366 265 464 minecraft:white_concrete
setblock 368 265 488 minecraft:red_nether_bricks
fill 368 265 489 368 268 489 minecraft:pink_terracotta
fill 369 265 484 369 265 486 minecraft:pink_terracotta
setblock 369 265 487 minecraft:red_nether_bricks
fill 369 265 488 369 268 488 minecraft:pink_terracotta
setblock 369 265 491 minecraft:pink_terracotta
setblock 369 265 492 minecraft:red_nether_bricks
fill 369 265 493 369 268 493 minecraft:pink_terracotta
setblock 370 265 465 minecraft:pink_terracotta
setblock 370 265 466 minecraft:red_nether_bricks
fill 370 265 467 370 265 470 minecraft:pink_terracotta
setblock 370 265 471 minecraft:red_nether_bricks
setblock 370 265 479 minecraft:white_concrete
setblock 370 265 481 minecraft:red_nether_bricks
fill 370 265 482 370 268 482 minecraft:pink_terracotta
setblock 370 265 486 minecraft:red_nether_bricks
fill 370 265 487 370 268 487 minecraft:pink_terracotta
setblock 370 265 491 minecraft:red_nether_bricks
fill 370 265 492 370 268 492 minecraft:pink_terracotta
setblock 370 265 496 minecraft:red_nether_bricks
setblock 330 266 464 minecraft:pink_terracotta
setblock 330 266 465 minecraft:red_nether_bricks
fill 330 266 466 330 269 466 minecraft:pink_terracotta
setblock 330 266 469 minecraft:pink_terracotta
setblock 330 266 470 minecraft:red_nether_bricks
fill 330 266 471 330 269 471 minecraft:pink_terracotta
setblock 330 266 475 minecraft:red_nether_bricks
fill 330 266 476 331 268 476 minecraft:pink_terracotta
setblock 330 266 480 minecraft:red_nether_bricks
fill 330 266 481 330 269 481 minecraft:pink_terracotta
setblock 330 266 485 minecraft:red_nether_bricks
fill 330 266 486 330 269 486 minecraft:pink_terracotta
setblock 330 266 489 minecraft:pink_terracotta
setblock 330 266 490 minecraft:red_nether_bricks
fill 330 266 491 330 269 491 minecraft:pink_terracotta
setblock 330 266 495 minecraft:red_nether_bricks
setblock 331 266 464 minecraft:red_nether_bricks
fill 331 266 465 331 269 465 minecraft:pink_terracotta
setblock 331 266 469 minecraft:red_nether_bricks
fill 331 266 470 331 269 470 minecraft:pink_terracotta
setblock 331 266 473 minecraft:pink_terracotta
setblock 331 266 474 minecraft:red_nether_bricks
fill 331 266 475 331 269 475 minecraft:pink_terracotta
fill 331 266 477 331 266 478 minecraft:pink_terracotta
setblock 331 266 479 minecraft:red_nether_bricks
fill 331 266 480 331 269 480 minecraft:pink_terracotta
setblock 331 266 484 minecraft:red_nether_bricks
fill 331 266 485 331 269 485 minecraft:pink_terracotta
setblock 331 266 489 minecraft:red_nether_bricks
fill 331 266 490 332 268 490 minecraft:pink_terracotta
setblock 331 266 493 minecraft:pink_terracotta
fill 332 266 464 332 269 464 minecraft:pink_terracotta
setblock 332 266 467 minecraft:pink_terracotta
setblock 332 266 468 minecraft:red_nether_bricks
fill 332 266 469 333 268 469 minecraft:pink_terracotta
setblock 332 266 473 minecraft:red_nether_bricks
fill 332 266 474 332 269 474 minecraft:pink_terracotta
fill 332 266 484 332 267 484 minecraft:pink_terracotta
setblock 332 266 488 minecraft:red_nether_bricks
fill 332 266 489 332 269 489 minecraft:pink_terracotta
fill 332 266 491 332 267 491 minecraft:pink_terracotta
setblock 333 266 467 minecraft:red_nether_bricks
fill 333 266 468 333 269 468 minecraft:pink_terracotta
fill 333 266 470 333 266 471 minecraft:pink_terracotta
setblock 333 266 472 minecraft:red_nether_bricks
setblock 334 266 465 minecraft:pink_terracotta
setblock 334 266 466 minecraft:red_nether_bricks
fill 334 266 467 334 269 467 minecraft:pink_terracotta
setblock 335 266 465 minecraft:red_nether_bricks
fill 335 266 466 335 269 466 minecraft:pink_terracotta
fill 335 266 468 336 266 468 minecraft:pink_terracotta
setblock 336 266 464 minecraft:red_nether_bricks
fill 336 266 465 336 269 465 minecraft:pink_terracotta
setblock 336 266 504 minecraft:red_nether_bricks
fill 337 266 464 340 266 464 minecraft:pink_terracotta
setblock 337 266 467 minecraft:pink_terracotta
setblock 337 266 468 minecraft:red_nether_bricks
fill 337 266 504 340 266 504 minecraft:pink_terracotta
setblock 338 266 467 minecraft:red_nether_bricks
fill 338 266 468 338 267 468 minecraft:pink_terracotta
setblock 339 266 466 minecraft:red_nether_bricks
fill 339 266 467 339 269 467 minecraft:pink_terracotta
setblock 340 266 465 minecraft:red_nether_bricks
fill 340 266 466 340 269 466 minecraft:pink_terracotta
setblock 341 266 464 minecraft:red_nether_bricks
fill 341 266 465 341 269 465 minecraft:pink_terracotta
setblock 341 266 504 minecraft:red_nether_bricks
fill 342 266 464 342 269 464 minecraft:pink_terracotta
fill 342 266 504 342 267 504 minecraft:pink_terracotta
setblock 344 266 466 minecraft:red_nether_bricks
setblock 345 266 465 minecraft:red_nether_bricks
setblock 345 266 466 minecraft:pink_terracotta
setblock 346 266 464 minecraft:red_nether_bricks
fill 346 266 465 349 266 465 minecraft:pink_terracotta
setblock 346 266 504 minecraft:red_nether_bricks
fill 347 266 464 347 269 464 minecraft:pink_terracotta
fill 347 266 504 347 269 504 minecraft:pink_terracotta
setblock 349 266 466 minecraft:red_nether_bricks
setblock 350 266 465 minecraft:red_nether_bricks
fill 350 266 466 350 269 466 minecraft:pink_terracotta
setblock 351 266 464 minecraft:red_nether_bricks
fill 351 266 465 351 269 465 minecraft:pink_terracotta
setblock 351 266 504 minecraft:red_nether_bricks
fill 352 266 464 352 269 464 minecraft:pink_terracotta
setblock 352 266 503 minecraft:red_nether_bricks
fill 352 266 504 352 269 504 minecraft:pink_terracotta
setblock 353 266 466 minecraft:pink_terracotta
fill 353 266 503 353 269 503 minecraft:pink_terracotta
setblock 354 266 466 minecraft:red_nether_bricks
fill 354 266 502 354 269 502 minecraft:pink_terracotta
setblock 355 266 465 minecraft:red_nether_bricks
fill 355 266 466 355 269 466 minecraft:pink_terracotta
setblock 356 266 464 minecraft:red_nether_bricks
fill 356 266 465 356 269 465 minecraft:pink_terracotta
setblock 356 266 504 minecraft:red_nether_bricks
fill 357 266 464 357 269 464 minecraft:pink_terracotta
setblock 357 266 503 minecraft:red_nether_bricks
fill 357 266 504 357 269 504 minecraft:pink_terracotta
setblock 358 266 502 minecraft:red_nether_bricks
fill 358 266 503 358 269 503 minecraft:pink_terracotta
setblock 359 266 466 minecraft:red_nether_bricks
setblock 360 266 465 minecraft:red_nether_bricks
setblock 361 266 464 minecraft:red_nether_bricks
setblock 361 266 465 minecraft:pink_terracotta
setblock 361 266 504 minecraft:red_nether_bricks
fill 362 266 464 362 267 464 minecraft:pink_terracotta
fill 362 266 504 362 267 504 minecraft:pink_terracotta
setblock 365 266 504 minecraft:white_concrete
setblock 368 266 487 minecraft:red_nether_bricks
fill 368 266 488 368 269 488 minecraft:pink_terracotta
fill 368 266 490 368 266 491 minecraft:pink_terracotta
fill 369 266 484 369 266 485 minecraft:pink_terracotta
setblock 369 266 486 minecraft:red_nether_bricks
fill 369 266 487 369 269 487 minecraft:pink_terracotta
setblock 369 266 491 minecraft:red_nether_bricks
fill 369 266 492 369 269 492 minecraft:pink_terracotta
fill 369 266 494 370 266 494 minecraft:pink_terracotta
setblock 370 266 464 minecraft:pink_terracotta
setblock 370 266 465 minecraft:red_nether_bricks
fill 370 266 466 370 266 469 minecraft:pink_terracotta
setblock 370 266 470 minecraft:red_nether_bricks
fill 370 266 471 370 266 474 minecraft:pink_terracotta
setblock 370 266 475 minecraft:red_nether_bricks
setblock 370 266 479 minecraft:pink_terracotta
setblock 370 266 480 minecraft:red_nether_bricks
fill 370 266 481 370 269 481 minecraft:pink_terracotta
setblock 370 266 485 minecraft:red_nether_bricks
fill 370 266 486 370 269 486 minecraft:pink_terracotta
setblock 370 266 490 minecraft:red_nether_bricks
fill 370 266 491 370 269 491 minecraft:pink_terracotta
fill 370 266 493 370 267 493 minecraft:pink_terracotta
setblock 370 266 495 minecraft:red_nether_bricks
fill 370 266 496 370 268 497 minecraft:pink_terracotta
setblock 370 266 498 minecraft:white_concrete
setblock 330 267 464 minecraft:red_nether_bricks
fill 330 267 465 330 270 465 minecraft:pink_terracotta
setblock 330 267 468 minecraft:pink_terracotta
setblock 330 267 469 minecraft:red_nether_bricks
fill 330 267 470 330 270 470 minecraft:pink_terracotta
fill 330 267 472 330 267 473 minecraft:pink_terracotta
setblock 330 267 474 minecraft:red_nether_bricks
fill 330 267 475 330 270 475 minecraft:pink_terracotta
setblock 330 267 478 minecraft:pink_terracotta
setblock 330 267 479 minecraft:red_nether_bricks
fill 330 267 480 330 270 480 minecraft:pink_terracotta
setblock 330 267 484 minecraft:red_nether_bricks
fill 330 267 485 330 270 485 minecraft:pink_terracotta
setblock 330 267 489 minecraft:red_nether_bricks
fill 330 267 490 330 270 490 minecraft:pink_terracotta
fill 330 267 492 330 267 493 minecraft:pink_terracotta
setblock 330 267 494 minecraft:red_nether_bricks
fill 330 267 495 330 269 496 minecraft:pink_terracotta
setblock 330 267 501 minecraft:white_concrete
fill 331 267 464 331 270 464 minecraft:pink_terracotta
setblock 331 267 468 minecraft:red_nether_bricks
fill 331 267 469 331 270 469 minecraft:pink_terracotta
setblock 331 267 472 minecraft:pink_terracotta
setblock 331 267 473 minecraft:red_nether_bricks
fill 331 267 474 331 270 474 minecraft:pink_terracotta
setblock 331 267 477 minecraft:pink_terracotta
setblock 331 267 478 minecraft:red_nether_bricks
fill 331 267 479 331 270 479 minecraft:pink_terracotta
setblock 331 267 483 minecraft:red_nether_bricks
fill 331 267 484 331 270 484 minecraft:pink_terracotta
setblock 331 267 487 minecraft:pink_terracotta
setblock 331 267 488 minecraft:red_nether_bricks
fill 331 267 489 331 270 489 minecraft:pink_terracotta
setblock 331 267 493 minecraft:red_nether_bricks
fill 331 267 494 331 270 494 minecraft:pink_terracotta
setblock 332 267 467 minecraft:red_nether_bricks
fill 332 267 468 332 270 468 minecraft:pink_terracotta
setblock 332 267 472 minecraft:red_nether_bricks
fill 332 267 473 333 269 473 minecraft:pink_terracotta
fill 332 267 475 332 267 476 minecraft:pink_terracotta
setblock 332 267 487 minecraft:red_nether_bricks
fill 332 267 488 332 269 488 minecraft:pink_terracotta
setblock 332 267 492 minecraft:red_nether_bricks
fill 332 267 504 332 269 504 minecraft:pink_terracotta
setblock 333 267 465 minecraft:pink_terracotta
setblock 333 267 466 minecraft:red_nether_bricks
fill 333 267 467 333 270 467 minecraft:pink_terracotta
setblock 333 267 470 minecraft:pink_terracotta
setblock 333 267 471 minecraft:red_nether_bricks
fill 333 267 472 333 270 472 minecraft:pink_terracotta
setblock 334 267 465 minecraft:red_nether_bricks
fill 334 267 466 334 270 466 minecraft:pink_terracotta
fill 334 267 468 334 267 469 minecraft:pink_terracotta
setblock 334 267 470 minecraft:red_nether_bricks
setblock 335 267 464 minecraft:red_nether_bricks
fill 335 267 465 335 270 465 minecraft:pink_terracotta
setblock 335 267 468 minecraft:pink_terracotta
setblock 335 267 504 minecraft:red_nether_bricks
fill 336 267 464 339 267 464 minecraft:pink_terracotta
setblock 336 267 468 minecraft:red_nether_bricks
fill 336 267 504 339 267 504 minecraft:pink_terracotta
setblock 337 267 467 minecraft:red_nether_bricks
fill 337 267 468 337 268 468 minecraft:pink_terracotta
setblock 338 267 466 minecraft:red_nether_bricks
fill 338 267 467 338 269 467 minecraft:pink_terracotta
setblock 339 267 465 minecraft:red_nether_bricks
fill 339 267 466 339 270 466 minecraft:pink_terracotta
setblock 340 267 464 minecraft:red_nether_bricks
fill 340 267 465 340 270 465 minecraft:pink_terracotta
setblock 340 267 504 minecraft:red_nether_bricks
fill 341 267 464 341 270 464 minecraft:pink_terracotta
fill 341 267 504 341 268 504 minecraft:pink_terracotta
setblock 343 267 466 minecraft:red_nether_bricks
setblock 344 267 465 minecraft:red_nether_bricks
setblock 344 267 466 minecraft:pink_terracotta
setblock 345 267 464 minecraft:red_nether_bricks
fill 345 267 465 348 267 465 minecraft:pink_terracotta
setblock 345 267 504 minecraft:red_nether_bricks
fill 346 267 464 346 270 464 minecraft:pink_terracotta
fill 346 267 504 346 268 504 minecraft:pink_terracotta
setblock 349 267 465 minecraft:red_nether_bricks
fill 349 267 466 349 268 466 minecraft:pink_terracotta
setblock 350 267 464 minecraft:red_nether_bricks
fill 350 267 465 350 270 465 minecraft:pink_terracotta
setblock 350 267 503 minecraft:pink_terracotta
setblock 350 267 504 minecraft:red_nether_bricks
fill 351 267 464 351 270 464 minecraft:pink_terracotta
setblock 351 267 503 minecraft:red_nether_bricks
fill 351 267 504 351 270 504 minecraft:pink_terracotta
fill 352 267 503 352 270 503 minecraft:pink_terracotta
setblock 353 267 466 minecraft:red_nether_bricks
setblock 354 267 465 minecraft:red_nether_bricks
fill 354 267 466 354 269 466 minecraft:pink_terracotta
setblock 355 267 464 minecraft:red_nether_bricks
fill 355 267 465 355 270 465 minecraft:pink_terracotta
setblock 355 267 504 minecraft:red_nether_bricks
fill 356 267 464 356 270 464 minecraft:pink_terracotta
setblock 356 267 503 minecraft:red_nether_bricks
fill 356 267 504 356 270 504 minecraft:pink_terracotta
setblock 357 267 502 minecraft:red_nether_bricks
fill 357 267 503 357 270 503 minecraft:pink_terracotta
setblock 358 267 466 minecraft:red_nether_bricks
setblock 359 267 465 minecraft:red_nether_bricks
setblock 360 267 464 minecraft:red_nether_bricks
setblock 360 267 465 minecraft:pink_terracotta
setblock 360 267 504 minecraft:red_nether_bricks
fill 361 267 464 361 268 464 minecraft:pink_terracotta
fill 361 267 504 361 268 504 minecraft:pink_terracotta
setblock 368 267 487 minecraft:pink_terracotta
setblock 368 267 490 minecraft:pink_terracotta
setblock 368 267 491 minecraft:red_nether_bricks
fill 368 267 492 368 270 492 minecraft:pink_terracotta
setblock 369 267 484 minecraft:pink_terracotta
setblock 369 267 485 minecraft:red_nether_bricks
fill 369 267 486 369 270 486 minecraft:pink_terracotta
setblock 369 267 490 minecraft:red_nether_bricks
fill 369 267 491 369 270 491 minecraft:pink_terracotta
setblock 369 267 494 minecraft:pink_terracotta
setblock 369 267 495 minecraft:red_nether_bricks
setblock 370 267 464 minecraft:red_nether_bricks
fill 370 267 465 370 267 468 minecraft:pink_terracotta
setblock 370 267 469 minecraft:red_nether_bricks
fill 370 267 470 370 267 473 minecraft:pink_terracotta
setblock 370 267 474 minecraft:red_nether_bricks
fill 370 267 475 370 267 478 minecraft:pink_terracotta
setblock 370 267 479 minecraft:red_nether_bricks
fill 370 267 480 370 270 480 minecraft:pink_terracotta
setblock 370 267 484 minecraft:red_nether_bricks
fill 370 267 485 370 270 485 minecraft:pink_terracotta
setblock 370 267 489 minecraft:red_nether_bricks
fill 370 267 490 370 270 490 minecraft:pink_terracotta
setblock 370 267 494 minecraft:red_nether_bricks
fill 370 267 495 370 270 495 minecraft:pink_terracotta
setblock 370 267 498 minecraft:pink_terracotta
fill 330 268 464 330 271 464 minecraft:pink_terracotta
setblock 330 268 468 minecraft:red_nether_bricks
fill 330 268 469 330 271 469 minecraft:pink_terracotta
setblock 330 268 472 minecraft:pink_terracotta
setblock 330 268 473 minecraft:red_nether_bricks
fill 330 268 474 330 271 474 minecraft:pink_terracotta
setblock 330 268 478 minecraft:red_nether_bricks
fill 330 268 479 330 271 479 minecraft:pink_terracotta
setblock 330 268 483 minecraft:red_nether_bricks
fill 330 268 484 330 271 484 minecraft:pink_terracotta
setblock 330 268 488 minecraft:red_nether_bricks
fill 330 268 489 330 271 489 minecraft:pink_terracotta
setblock 330 268 492 minecraft:pink_terracotta
setblock 330 268 493 minecraft:red_nether_bricks
fill 330 268 494 330 271 494 minecraft:pink_terracotta
setblock 330 268 497 minecraft:pink_terracotta
setblock 331 268 466 minecraft:pink_terracotta
setblock 331 268 467 minecraft:red_nether_bricks
fill 331 268 468 331 271 468 minecraft:pink_terracotta
setblock 331 268 471 minecraft:pink_terracotta
setblock 331 268 472 minecraft:red_nether_bricks
fill 331 268 473 331 271 473 minecraft:pink_terracotta
setblock 331 268 477 minecraft:red_nether_bricks
fill 331 268 478 331 271 478 minecraft:pink_terracotta
setblock 331 268 482 minecraft:red_nether_bricks
fill 331 268 483 331 270 483 minecraft:pink_terracotta
setblock 331 268 487 minecraft:red_nether_bricks
fill 331 268 488 331 271 488 minecraft:pink_terracotta
setblock 331 268 491 minecraft:pink_terracotta
setblock 331 268 492 minecraft:red_nether_bricks
fill 331 268 493 331 271 493 minecraft:pink_terracotta
fill 331 268 495 331 269 495 minecraft:pink_terracotta
setblock 332 268 466 minecraft:red_nether_bricks
fill 332 268 467 332 271 467 minecraft:pink_terracotta
setblock 332 268 471 minecraft:red_nether_bricks
fill 332 268 472 332 271 472 minecraft:pink_terracotta
setblock 332 268 475 minecraft:pink_terracotta
setblock 332 268 476 minecraft:red_nether_bricks
fill 332 268 477 332 271 477 minecraft:pink_terracotta
setblock 332 268 486 minecraft:red_nether_bricks
fill 332 268 487 332 269 487 minecraft:pink_terracotta
setblock 332 268 491 minecraft:red_nether_bricks
fill 332 268 492 332 270 492 minecraft:pink_terracotta
setblock 333 268 465 minecraft:red_nether_bricks
fill 333 268 466 333 271 466 minecraft:pink_terracotta
setblock 333 268 470 minecraft:red_nether_bricks
fill 333 268 471 334 270 471 minecraft:pink_terracotta
setblock 333 268 474 minecraft:pink_terracotta
setblock 334 268 464 minecraft:red_nether_bricks
fill 334 268 465 334 271 465 minecraft:pink_terracotta
setblock 334 268 468 minecraft:pink_terracotta
setblock 334 268 469 minecraft:red_nether_bricks
fill 334 268 470 334 270 470 minecraft:pink_terracotta
fill 334 268 472 334 269 472 minecraft:pink_terracotta
setblock 334 268 504 minecraft:red_nether_bricks
fill 335 268 464 338 268 464 minecraft:pink_terracotta
setblock 335 268 468 minecraft:red_nether_bricks
fill 335 268 504 338 268 504 minecraft:pink_terracotta
setblock 336 268 467 minecraft:red_nether_bricks
setblock 336 268 468 minecraft:pink_terracotta
setblock 337 268 466 minecraft:red_nether_bricks
fill 337 268 467 337 270 467 minecraft:pink_terracotta
setblock 338 268 465 minecraft:red_nether_bricks
fill 338 268 466 338 270 466 minecraft:pink_terracotta
setblock 339 268 464 minecraft:red_nether_bricks
fill 339 268 465 339 271 465 minecraft:pink_terracotta
setblock 339 268 504 minecraft:red_nether_bricks
fill 340 268 464 340 271 464 minecraft:pink_terracotta
fill 340 268 504 340 269 504 minecraft:pink_terracotta
setblock 342 268 466 minecraft:red_nether_bricks
setblock 343 268 465 minecraft:red_nether_bricks
setblock 344 268 464 minecraft:red_nether_bricks
fill 344 268 465 347 268 465 minecraft:pink_terracotta
fill 345 268 464 345 271 464 minecraft:pink_terracotta
setblock 348 268 465 minecraft:red_nether_bricks
setblock 349 268 464 minecraft:red_nether_bricks
fill 349 268 465 349 270 465 minecraft:pink_terracotta
setblock 349 268 504 minecraft:red_nether_bricks
fill 350 268 464 350 271 464 minecraft:pink_terracotta
setblock 350 268 503 minecraft:red_nether_bricks
fill 350 268 504 350 271 504 minecraft:pink_terracotta
fill 351 268 503 351 271 503 minecraft:pink_terracotta
setblock 352 268 466 minecraft:red_nether_bricks
setblock 353 268 465 minecraft:red_nether_bricks
fill 353 268 466 353 269 466 minecraft:pink_terracotta
setblock 354 268 464 minecraft:red_nether_bricks
fill 354 268 465 354 271 465 minecraft:pink_terracotta
setblock 354 268 504 minecraft:red_nether_bricks
fill 355 268 464 355 271 464 minecraft:pink_terracotta
setblock 355 268 503 minecraft:red_nether_bricks
fill 355 268 504 355 271 504 minecraft:pink_terracotta
setblock 356 268 502 minecraft:red_nether_bricks
fill 356 268 503 356 271 503 minecraft:pink_terracotta
setblock 357 268 466 minecraft:red_nether_bricks
setblock 358 268 465 minecraft:red_nether_bricks
setblock 359 268 464 minecraft:red_nether_bricks
setblock 359 268 465 minecraft:pink_terracotta
setblock 359 268 504 minecraft:red_nether_bricks
fill 360 268 464 360 269 464 minecraft:pink_terracotta
fill 360 268 504 360 269 504 minecraft:pink_terracotta
setblock 367 268 464 minecraft:white_concrete
setblock 368 268 490 minecraft:red_nether_bricks
fill 368 268 491 368 271 491 minecraft:pink_terracotta
fill 368 268 493 368 269 493 minecraft:pink_terracotta
setblock 369 268 469 minecraft:red_nether_bricks
fill 369 268 470 370 268 472 minecraft:pink_terracotta
setblock 369 268 484 minecraft:red_nether_bricks
fill 369 268 485 369 271 485 minecraft:pink_terracotta
setblock 369 268 489 minecraft:red_nether_bricks
fill 369 268 490 369 271 490 minecraft:pink_terracotta
setblock 369 268 494 minecraft:red_nether_bricks
fill 369 268 495 369 270 496 minecraft:pink_terracotta
fill 370 268 464 370 268 467 minecraft:pink_terracotta
setblock 370 268 468 minecraft:red_nether_bricks
fill 370 268 469 370 271 469 minecraft:pink_terracotta
setblock 370 268 473 minecraft:red_nether_bricks
fill 370 268 474 370 268 477 minecraft:pink_terracotta
setblock 370 268 478 minecraft:red_nether_bricks
fill 370 268 479 370 271 479 minecraft:pink_terracotta
setblock 370 268 483 minecraft:red_nether_bricks
fill 370 268 484 370 271 484 minecraft:pink_terracotta
setblock 370 268 488 minecraft:red_nether_bricks
fill 370 268 489 370 271 489 minecraft:pink_terracotta
setblock 370 268 493 minecraft:red_nether_bricks
fill 370 268 494 370 271 494 minecraft:pink_terracotta
setblock 370 268 498 minecraft:red_nether_bricks
fill 370 268 499 370 271 499 minecraft:pink_terracotta
setblock 330 269 467 minecraft:red_nether_bricks
fill 330 269 468 330 272 468 minecraft:pink_terracotta
setblock 330 269 472 minecraft:red_nether_bricks
fill 330 269 473 330 272 473 minecraft:pink_terracotta
setblock 330 269 476 minecraft:pink_terracotta
setblock 330 269 477 minecraft:red_nether_bricks
fill 330 269 478 330 272 478 minecraft:pink_terracotta
setblock 330 269 482 minecraft:red_nether_bricks
fill 330 269 483 330 272 483 minecraft:pink_terracotta
setblock 330 269 487 minecraft:red_nether_bricks
fill 330 269 488 330 272 488 minecraft:pink_terracotta
setblock 330 269 492 minecraft:red_nether_bricks
fill 330 269 493 330 272 493 minecraft:pink_terracotta
setblock 330 269 497 minecraft:red_nether_bricks
setblock 331 269 466 minecraft:red_nether_bricks
fill 331 269 467 331 272 467 minecraft:pink_terracotta
setblock 331 269 471 minecraft:red_nether_bricks
fill 331 269 472 331 272 472 minecraft:pink_terracotta
setblock 331 269 476 minecraft:red_nether_bricks
fill 331 269 477 331 272 477 minecraft:pink_terracotta
setblock 331 269 481 minecraft:red_nether_bricks
fill 331 269 482 331 270 482 minecraft:pink_terracotta
setblock 331 269 486 minecraft:red_nether_bricks
fill 331 269 487 331 271 487 minecraft:pink_terracotta
setblock 331 269 490 minecraft:pink_terracotta
setblock 331 269 491 minecraft:red_nether_bricks
fill 331 269 492 331 272 492 minecraft:pink_terracotta
setblock 332 269 465 minecraft:red_nether_bricks
fill 332 269 466 332 271 466 minecraft:pink_terracotta
setblock 332 269 469 minecraft:pink_terracotta
setblock 332 269 470 minecraft:red_nether_bricks
fill 332 269 471 332 272 471 minecraft:pink_terracotta
setblock 332 269 475 minecraft:red_nether_bricks
fill 332 269 476 332 272 476 minecraft:pink_terracotta
fill 332 269 478 332 270 478 minecraft:pink_terracotta
setblock 332 269 490 minecraft:red_nether_bricks
fill 332 269 491 332 270 491 minecraft:pink_terracotta
setblock 332 269 493 minecraft:pink_terracotta
setblock 333 269 464 minecraft:red_nether_bricks
fill 333 269 465 333 272 465 minecraft:pink_terracotta
setblock 333 269 469 minecraft:red_nether_bricks
fill 333 269 470 333 272 470 minecraft:pink_terracotta
setblock 333 269 474 minecraft:red_nether_bricks
fill 333 269 475 333 272 475 minecraft:pink_terracotta
setblock 333 269 504 minecraft:red_nether_bricks
fill 334 269 464 337 269 464 minecraft:pink_terracotta
setblock 334 269 469 minecraft:pink_terracotta
fill 334 269 504 337 269 504 minecraft:pink_terracotta
setblock 335 269 467 minecraft:red_nether_bricks
setblock 335 269 468 minecraft:pink_terracotta
setblock 336 269 466 minecraft:red_nether_bricks
fill 336 269 467 336 270 467 minecraft:pink_terracotta
setblock 337 269 465 minecraft:red_nether_bricks
fill 337 269 466 337 271 466 minecraft:pink_terracotta
setblock 338 269 464 minecraft:red_nether_bricks
fill 338 269 465 338 271 465 minecraft:pink_terracotta
setblock 338 269 504 minecraft:red_nether_bricks
fill 339 269 464 339 272 464 minecraft:pink_terracotta
setblock 339 269 504 minecraft:pink_terracotta
setblock 341 269 466 minecraft:red_nether_bricks
setblock 342 269 465 minecraft:red_nether_bricks
setblock 343 269 464 minecraft:red_nether_bricks
fill 343 269 465 346 269 465 minecraft:pink_terracotta
fill 344 269 464 344 270 464 minecraft:pink_terracotta
setblock 347 269 465 minecraft:red_nether_bricks
setblock 348 269 464 minecraft:red_nether_bricks
fill 348 269 465 348 270 465 minecraft:pink_terracotta
setblock 348 269 504 minecraft:red_nether_bricks
fill 349 269 464 349 272 464 minecraft:pink_terracotta
fill 349 269 504 349 272 504 minecraft:pink_terracotta
fill 350 269 503 350 272 503 minecraft:pink_terracotta
setblock 351 269 466 minecraft:red_nether_bricks
setblock 352 269 465 minecraft:red_nether_bricks
setblock 352 269 466 minecraft:pink_terracotta
setblock 353 269 464 minecraft:red_nether_bricks
fill 353 269 465 353 271 465 minecraft:pink_terracotta
setblock 353 269 504 minecraft:red_nether_bricks
fill 354 269 464 354 272 464 minecraft:pink_terracotta
setblock 354 269 503 minecraft:red_nether_bricks
fill 354 269 504 354 272 504 minecraft:pink_terracotta
setblock 355 269 502 minecraft:red_nether_bricks
fill 355 269 503 355 272 503 minecraft:pink_terracotta
setblock 356 269 466 minecraft:red_nether_bricks
setblock 357 269 465 minecraft:red_nether_bricks
setblock 358 269 464 minecraft:red_nether_bricks
setblock 358 269 465 minecraft:pink_terracotta
setblock 358 269 504 minecraft:red_nether_bricks
setblock 359 269 464 minecraft:pink_terracotta
fill 359 269 504 359 270 504 minecraft:pink_terracotta
setblock 361 269 464 minecraft:white_concrete
setblock 368 269 489 minecraft:red_nether_bricks
fill 368 269 490 368 270 490 minecraft:pink_terracotta
fill 369 269 469 369 269 472 minecraft:pink_terracotta
setblock 369 269 473 minecraft:red_nether_bricks
fill 369 269 474 370 270 475 minecraft:pink_terracotta
fill 369 269 484 369 270 484 minecraft:pink_terracotta
setblock 369 269 488 minecraft:red_nether_bricks
fill 369 269 489 369 272 489 minecraft:pink_terracotta
setblock 369 269 493 minecraft:red_nether_bricks
fill 369 269 494 369 272 494 minecraft:pink_terracotta
fill 370 269 465 370 269 466 minecraft:pink_terracotta
setblock 370 269 467 minecraft:red_nether_bricks
fill 370 269 468 370 272 468 minecraft:pink_terracotta
fill 370 269 470 370 269 471 minecraft:pink_terracotta
setblock 370 269 472 minecraft:red_nether_bricks
fill 370 269 473 370 272 473 minecraft:pink_terracotta
setblock 370 269 476 minecraft:pink_terracotta
setblock 370 269 477 minecraft:red_nether_bricks
fill 370 269 478 370 272 478 minecraft:pink_terracotta
setblock 370 269 482 minecraft:red_nether_bricks
fill 370 269 483 370 272 483 minecraft:pink_terracotta
setblock 370 269 487 minecraft:red_nether_bricks
fill 370 269 488 370 272 488 minecraft:pink_terracotta
setblock 370 269 492 minecraft:red_nether_bricks
fill 370 269 493 370 272 493 minecraft:pink_terracotta
setblock 370 269 496 minecraft:pink_terracotta
setblock 370 269 497 minecraft:red_nether_bricks
fill 370 269 498 370 272 498 minecraft:pink_terracotta
setblock 330 270 466 minecraft:red_nether_bricks
fill 330 270 467 330 273 467 minecraft:pink_terracotta
setblock 330 270 471 minecraft:red_nether_bricks
fill 330 270 472 330 273 472 minecraft:pink_terracotta
setblock 330 270 476 minecraft:red_nether_bricks
fill 330 270 477 330 273 477 minecraft:pink_terracotta
setblock 330 270 481 minecraft:red_nether_bricks
fill 330 270 482 330 273 482 minecraft:pink_terracotta
setblock 330 270 486 minecraft:red_nether_bricks
fill 330 270 487 330 273 487 minecraft:pink_terracotta
setblock 330 270 491 minecraft:red_nether_bricks
fill 330 270 492 330 273 492 minecraft:pink_terracotta
setblock 330 270 495 minecraft:pink_terracotta
setblock 330 270 496 minecraft:red_nether_bricks
fill 330 270 497 330 272 498 minecraft:pink_terracotta
setblock 331 270 465 minecraft:red_nether_bricks
fill 331 270 466 331 273 466 minecraft:pink_terracotta
setblock 331 270 470 minecraft:red_nether_bricks
fill 331 270 471 331 273 471 minecraft:pink_terracotta
setblock 331 270 475 minecraft:red_nether_bricks
fill 331 270 476 331 273 476 minecraft:pink_terracotta
setblock 331 270 480 minecraft:red_nether_bricks
fill 331 270 481 331 271 481 minecraft:pink_terracotta
setblock 331 270 485 minecraft:red_nether_bricks
setblock 331 270 486 minecraft:pink_terracotta
setblock 331 270 490 minecraft:red_nether_bricks
fill 331 270 491 331 273 491 minecraft:pink_terracotta
setblock 331 270 495 minecraft:red_nether_bricks
fill 331 270 496 331 273 496 minecraft:pink_terracotta
setblock 332 270 464 minecraft:red_nether_bricks
fill 332 270 465 332 273 465 minecraft:pink_terracotta
setblock 332 270 469 minecraft:red_nether_bricks
fill 332 270 470 332 273 470 minecraft:pink_terracotta
setblock 332 270 473 minecraft:pink_terracotta
setblock 332 270 474 minecraft:red_nether_bricks
fill 332 270 475 332 273 475 minecraft:pink_terracotta
fill 332 270 484 332 273 484 minecraft:white_concrete
setblock 332 270 490 minecraft:pink_terracotta
fill 333 270 464 336 270 464 minecraft:pink_terracotta
setblock 333 270 468 minecraft:red_nether_bricks
fill 333 270 469 333 272 469 minecraft:pink_terracotta
setblock 333 270 473 minecraft:red_nether_bricks
fill 333 270 474 333 273 474 minecraft:pink_terracotta
fill 333 270 504 336 270 504 minecraft:pink_terracotta
setblock 334 270 467 minecraft:red_nether_bricks
setblock 334 270 472 minecraft:red_nether_bricks
setblock 335 270 466 minecraft:red_nether_bricks
setblock 335 270 467 minecraft:pink_terracotta
setblock 336 270 465 minecraft:red_nether_bricks
fill 336 270 466 336 271 466 minecraft:pink_terracotta
setblock 337 270 464 minecraft:red_nether_bricks
fill 337 270 465 337 272 465 minecraft:pink_terracotta
setblock 337 270 504 minecraft:red_nether_bricks
fill 338 270 464 338 273 464 minecraft:pink_terracotta
setblock 338 270 504 minecraft:pink_terracotta
setblock 341 270 465 minecraft:red_nether_bricks
setblock 342 270 464 minecraft:red_nether_bricks
fill 343 270 464 343 271 464 minecraft:pink_terracotta
fill 343 270 500 343 270 502 minecraft:white_concrete
fill 344 270 499 345 270 499 minecraft:white_concrete
fill 344 270 502 344 270 503 minecraft:white_concrete
fill 345 270 503 345 270 504 minecraft:white_concrete
fill 346 270 500 346 271 502 minecraft:white_concrete
setblock 347 270 464 minecraft:red_nether_bricks
setblock 347 270 501 minecraft:white_concrete
setblock 347 270 504 minecraft:red_nether_bricks
fill 348 270 464 348 273 464 minecraft:pink_terracotta
fill 348 270 504 348 273 504 minecraft:pink_terracotta
setblock 351 270 465 minecraft:red_nether_bricks
setblock 352 270 464 minecraft:red_nether_bricks
fill 352 270 465 352 271 465 minecraft:pink_terracotta
setblock 352 270 504 minecraft:red_nether_bricks
fill 353 270 464 353 273 464 minecraft:pink_terracotta
setblock 353 270 503 minecraft:red_nether_bricks
fill 353 270 504 353 273 504 minecraft:pink_terracotta
fill 354 270 503 354 273 503 minecraft:pink_terracotta
setblock 356 270 465 minecraft:red_nether_bricks
setblock 357 270 464 minecraft:red_nether_bricks
setblock 357 270 504 minecraft:red_nether_bricks
setblock 358 270 464 minecraft:pink_terracotta
fill 358 270 504 358 271 504 minecraft:pink_terracotta
fill 361 270 494 361 270 497 minecraft:white_concrete
fill 362 270 493 362 270 494 minecraft:white_concrete
fill 362 270 497 362 270 498 minecraft:white_concrete
fill 363 270 493 364 270 493 minecraft:white_concrete
fill 363 270 498 364 270 498 minecraft:white_concrete
fill 364 270 494 365 271 494 minecraft:white_concrete
fill 364 270 497 365 271 497 minecraft:white_concrete
setblock 364 270 504 minecraft:white_concrete
fill 365 270 495 366 270 496 minecraft:white_concrete
setblock 368 270 489 minecraft:pink_terracotta
setblock 368 270 493 minecraft:red_nether_bricks
fill 369 270 469 369 270 471 minecraft:pink_terracotta
setblock 369 270 472 minecraft:red_nether_bricks
fill 369 270 473 369 273 473 minecraft:pink_terracotta
setblock 369 270 476 minecraft:pink_terracotta
setblock 369 270 487 minecraft:red_nether_bricks
fill 369 270 488 369 273 488 minecraft:pink_terracotta
setblock 369 270 492 minecraft:red_nether_bricks
fill 369 270 493 369 273 493 minecraft:pink_terracotta
setblock 370 270 465 minecraft:pink_terracotta
setblock 370 270 466 minecraft:red_nether_bricks
fill 370 270 467 370 273 467 minecraft:pink_terracotta
setblock 370 270 470 minecraft:pink_terracotta
setblock 370 270 471 minecraft:red_nether_bricks
fill 370 270 472 370 273 472 minecraft:pink_terracotta
setblock 370 270 476 minecraft:red_nether_bricks
fill 370 270 477 370 273 477 minecraft:pink_terracotta
setblock 370 270 481 minecraft:red_nether_bricks
fill 370 270 482 370 273 482 minecraft:pink_terracotta
setblock 370 270 486 minecraft:red_nether_bricks
fill 370 270 487 370 273 487 minecraft:pink_terracotta
setblock 370 270 491 minecraft:red_nether_bricks
fill 370 270 492 370 273 492 minecraft:pink_terracotta
setblock 370 270 496 minecraft:red_nether_bricks
fill 370 270 497 370 273 497 minecraft:pink_terracotta
setblock 330 271 465 minecraft:red_nether_bricks
fill 330 271 466 330 273 466 minecraft:pink_terracotta
setblock 330 271 470 minecraft:red_nether_bricks
fill 330 271 471 330 273 471 minecraft:pink_terracotta
setblock 330 271 475 minecraft:red_nether_bricks
fill 330 271 476 330 273 476 minecraft:pink_terracotta
setblock 330 271 480 minecraft:red_nether_bricks
fill 330 271 481 330 273 481 minecraft:pink_terracotta
setblock 330 271 485 minecraft:red_nether_bricks
fill 330 271 486 330 273 486 minecraft:pink_terracotta
setblock 330 271 490 minecraft:red_nether_bricks
fill 330 271 491 330 273 491 minecraft:pink_terracotta
setblock 330 271 495 minecraft:red_nether_bricks
fill 330 271 496 330 273 496 minecraft:pink_terracotta
setblock 330 271 500 minecraft:white_concrete
setblock 331 271 464 minecraft:red_nether_bricks
fill 331 271 465 331 273 465 minecraft:pink_terracotta
setblock 331 271 469 minecraft:red_nether_bricks
fill 331 271 470 331 273 470 minecraft:pink_terracotta
setblock 331 271 474 minecraft:red_nether_bricks
fill 331 271 475 331 273 475 minecraft:pink_terracotta
setblock 331 271 479 minecraft:red_nether_bricks
fill 331 271 480 331 273 480 minecraft:pink_terracotta
fill 331 271 482 331 272 486 minecraft:white_concrete
setblock 331 271 489 minecraft:red_nether_bricks
fill 331 271 490 331 272 490 minecraft:pink_terracotta
setblock 331 271 494 minecraft:red_nether_bricks
fill 331 271 495 331 273 495 minecraft:pink_terracotta
fill 332 271 464 335 271 464 minecraft:pink_terracotta
setblock 332 271 468 minecraft:red_nether_bricks
fill 332 271 469 332 273 469 minecraft:pink_terracotta
setblock 332 271 473 minecraft:red_nether_bricks
fill 332 271 474 332 273 474 minecraft:pink_terracotta
setblock 332 271 478 minecraft:red_nether_bricks
setblock 332 271 482 minecraft:light[level=12]
fill 332 271 483 332 272 483 minecraft:white_concrete
fill 332 271 485 332 272 485 minecraft:white_concrete
setblock 332 271 490 minecraft:light[level=12]
setblock 332 271 498 minecraft:light[level=12]
setblock 333 271 468 minecraft:pink_terracotta
setblock 333 271 471 minecraft:pink_terracotta
setblock 333 271 472 minecraft:red_nether_bricks
fill 333 271 473 333 273 473 minecraft:pink_terracotta
fill 333 271 484 333 272 484 minecraft:red_concrete
fill 333 271 504 335 271 504 minecraft:pink_terracotta
setblock 334 271 466 minecraft:red_nether_bricks
setblock 335 271 465 minecraft:red_nether_bricks
fill 335 271 466 335 272 466 minecraft:pink_terracotta
setblock 336 271 464 minecraft:red_nether_bricks
fill 336 271 465 336 272 465 minecraft:pink_terracotta
setblock 336 271 504 minecraft:red_nether_bricks
fill 337 271 464 337 273 464 minecraft:pink_terracotta
setblock 340 271 466 minecraft:light[level=12]
setblock 340 271 474 minecraft:light[level=12]
setblock 340 271 482 minecraft:light[level=12]
setblock 340 271 490 minecraft:light[level=12]
setblock 340 271 498 minecraft:light[level=12]
setblock 341 271 464 minecraft:red_nether_bricks
setblock 342 271 464 minecraft:pink_terracotta
fill 343 271 500 343 271 501 minecraft:white_concrete
fill 344 271 502 344 272 502 minecraft:white_concrete
setblock 346 271 464 minecraft:red_nether_bricks
fill 347 271 464 347 272 464 minecraft:pink_terracotta
fill 347 271 504 347 273 504 minecraft:pink_terracotta
setblock 348 271 466 minecraft:light[level=12]
setblock 348 271 474 minecraft:light[level=12]
setblock 348 271 482 minecraft:light[level=12]
setblock 348 271 490 minecraft:light[level=12]
setblock 348 271 498 minecraft:light[level=12]
setblock 350 271 465 minecraft:red_nether_bricks
setblock 351 271 464 minecraft:red_nether_bricks
setblock 351 271 465 minecraft:pink_terracotta
setblock 351 271 504 minecraft:red_nether_bricks
fill 352 271 464 352 273 464 minecraft:pink_terracotta
setblock 352 271 503 minecraft:red_nether_bricks
fill 352 271 504 352 273 504 minecraft:pink_terracotta
fill 353 271 503 353 273 503 minecraft:pink_terracotta
setblock 356 271 464 minecraft:red_nether_bricks
setblock 356 271 466 minecraft:light[level=12]
setblock 356 271 474 minecraft:light[level=12]
setblock 356 271 482 minecraft:light[level=12]
setblock 356 271 490 minecraft:light[level=12]
setblock 356 271 498 minecraft:light[level=12]
setblock 356 271 504 minecraft:red_nether_bricks
setblock 357 271 464 minecraft:pink_terracotta
fill 357 271 504 357 272 504 minecraft:pink_terracotta
fill 361 271 495 361 271 497 minecraft:white_concrete
fill 362 271 494 362 272 494 minecraft:white_concrete
fill 362 271 497 362 272 497 minecraft:white_concrete
setblock 363 271 498 minecraft:white_concrete
setblock 364 271 466 minecraft:light[level=12]
setblock 364 271 474 minecraft:light[level=12]
setblock 364 271 482 minecraft:light[level=12]
setblock 364 271 490 minecraft:light[level=12]
setblock 364 271 498 minecraft:light[level=12]
fill 365 271 495 365 272 496 minecraft:white_concrete
setblock 368 271 492 minecraft:red_nether_bricks
setblock 368 271 493 minecraft:pink_terracotta
fill 369 271 469 369 271 470 minecraft:pink_terracotta
setblock 369 271 471 minecraft:red_nether_bricks
fill 369 271 472 369 273 472 minecraft:pink_terracotta
fill 369 271 474 369 271 475 minecraft:pink_terracotta
setblock 369 271 476 minecraft:red_nether_bricks
fill 369 271 477 369 273 478 minecraft:pink_terracotta
setblock 369 271 486 minecraft:red_nether_bricks
fill 369 271 487 369 272 487 minecraft:pink_terracotta
setblock 369 271 491 minecraft:red_nether_bricks
fill 369 271 492 369 273 492 minecraft:pink_terracotta
setblock 369 271 495 minecraft:pink_terracotta
setblock 369 271 496 minecraft:red_nether_bricks
fill 369 271 497 369 273 497 minecraft:pink_terracotta
fill 370 271 466 370 272 466 minecraft:pink_terracotta
setblock 370 271 470 minecraft:red_nether_bricks
fill 370 271 471 370 273 471 minecraft:pink_terracotta
setblock 370 271 474 minecraft:pink_terracotta
setblock 370 271 475 minecraft:red_nether_bricks
fill 370 271 476 370 273 476 minecraft:pink_terracotta
setblock 370 271 480 minecraft:red_nether_bricks
fill 370 271 481 370 273 481 minecraft:pink_terracotta
setblock 370 271 485 minecraft:red_nether_bricks
fill 370 271 486 370 273 486 minecraft:pink_terracotta
setblock 370 271 490 minecraft:red_nether_bricks
fill 370 271 491 370 273 491 minecraft:pink_terracotta
setblock 370 271 495 minecraft:red_nether_bricks
fill 370 271 496 370 273 496 minecraft:pink_terracotta
setblock 370 271 504 minecraft:white_concrete
setblock 330 272 464 minecraft:red_nether_bricks
fill 330 272 465 330 273 465 minecraft:pink_terracotta
setblock 330 272 469 minecraft:red_nether_bricks
fill 330 272 470 330 273 470 minecraft:pink_terracotta
setblock 330 272 474 minecraft:red_nether_bricks
fill 330 272 475 330 273 475 minecraft:pink_terracotta
setblock 330 272 479 minecraft:red_nether_bricks
fill 330 272 480 330 273 480 minecraft:pink_terracotta
setblock 330 272 484 minecraft:red_nether_bricks
fill 330 272 485 330 273 485 minecraft:pink_terracotta
setblock 330 272 489 minecraft:red_nether_bricks
fill 330 272 490 330 273 490 minecraft:pink_terracotta
setblock 330 272 494 minecraft:red_nether_bricks
fill 330 272 495 330 273 495 minecraft:pink_terracotta
setblock 330 272 499 minecraft:red_nether_bricks
fill 331 272 464 334 272 464 minecraft:pink_terracotta
setblock 331 272 468 minecraft:red_nether_bricks
fill 331 272 469 331 273 469 minecraft:pink_terracotta
setblock 331 272 473 minecraft:red_nether_bricks
fill 331 272 474 331 273 474 minecraft:pink_terracotta
setblock 331 272 478 minecraft:red_nether_bricks
fill 331 272 479 331 273 479 minecraft:pink_terracotta
setblock 331 272 489 minecraft:pink_terracotta
setblock 331 272 493 minecraft:red_nether_bricks
fill 331 272 494 331 273 494 minecraft:pink_terracotta
setblock 332 272 467 minecraft:red_nether_bricks
fill 332 272 468 332 273 468 minecraft:pink_terracotta
setblock 332 272 472 minecraft:red_nether_bricks
fill 332 272 473 332 273 473 minecraft:pink_terracotta
setblock 332 272 477 minecraft:red_nether_bricks
fill 332 272 478 332 273 478 minecraft:pink_terracotta
setblock 332 272 504 minecraft:white_concrete
setblock 333 272 466 minecraft:red_nether_bricks
setblock 333 272 471 minecraft:red_nether_bricks
fill 333 272 472 333 273 472 minecraft:pink_terracotta
setblock 334 272 465 minecraft:red_nether_bricks
setblock 334 272 466 minecraft:pink_terracotta
setblock 335 272 464 minecraft:red_nether_bricks
fill 335 272 465 335 273 465 minecraft:pink_terracotta
fill 336 272 464 336 273 464 minecraft:pink_terracotta
setblock 340 272 464 minecraft:red_nether_bricks
setblock 343 272 464 minecraft:white_concrete
setblock 346 272 501 minecraft:white_concrete
setblock 350 272 464 minecraft:red_nether_bricks
setblock 350 272 504 minecraft:red_nether_bricks
fill 351 272 464 351 273 464 minecraft:pink_terracotta
setblock 351 272 503 minecraft:red_nether_bricks
fill 351 272 504 351 273 504 minecraft:pink_terracotta
fill 352 272 503 352 273 503 minecraft:pink_terracotta
setblock 355 272 464 minecraft:red_nether_bricks
setblock 355 272 504 minecraft:red_nether_bricks
fill 356 272 504 356 273 504 minecraft:pink_terracotta
setblock 364 272 494 minecraft:white_concrete
setblock 364 272 497 minecraft:white_concrete
setblock 368 272 464 minecraft:white_concrete
setblock 369 272 470 minecraft:red_nether_bricks
fill 369 272 471 369 273 471 minecraft:pink_terracotta
setblock 369 272 474 minecraft:pink_terracotta
setblock 369 272 475 minecraft:red_nether_bricks
fill 369 272 476 369 273 476 minecraft:pink_terracotta
setblock 369 272 479 minecraft:pink_terracotta
setblock 369 272 486 minecraft:pink_terracotta
setblock 369 272 490 minecraft:red_nether_bricks
fill 369 272 491 369 273 491 minecraft:pink_terracotta
setblock 369 272 495 minecraft:red_nether_bricks
fill 369 272 496 369 273 496 minecraft:pink_terracotta
setblock 370 272 469 minecraft:red_nether_bricks
fill 370 272 470 370 273 470 minecraft:pink_terracotta
setblock 370 272 474 minecraft:red_nether_bricks
fill 370 272 475 370 273 475 minecraft:pink_terracotta
setblock 370 272 479 minecraft:red_nether_bricks
fill 370 272 480 370 273 480 minecraft:pink_terracotta
setblock 370 272 484 minecraft:red_nether_bricks
fill 370 272 485 370 273 485 minecraft:pink_terracotta
setblock 370 272 489 minecraft:red_nether_bricks
fill 370 272 490 370 273 490 minecraft:pink_terracotta
setblock 370 272 494 minecraft:red_nether_bricks
fill 370 272 495 370 273 495 minecraft:pink_terracotta
setblock 370 272 499 minecraft:red_nether_bricks
fill 330 273 464 333 273 464 minecraft:pink_terracotta
setblock 330 273 468 minecraft:red_nether_bricks
setblock 330 273 469 minecraft:pink_terracotta
setblock 330 273 473 minecraft:red_nether_bricks
setblock 330 273 474 minecraft:pink_terracotta
setblock 330 273 478 minecraft:red_nether_bricks
setblock 330 273 479 minecraft:pink_terracotta
setblock 330 273 483 minecraft:red_nether_bricks
setblock 330 273 484 minecraft:pink_terracotta
setblock 330 273 488 minecraft:red_nether_bricks
setblock 330 273 489 minecraft:pink_terracotta
setblock 330 273 493 minecraft:red_nether_bricks
setblock 330 273 494 minecraft:pink_terracotta
setblock 330 273 497 minecraft:pink_terracotta
setblock 330 273 498 minecraft:red_nether_bricks
setblock 330 273 499 minecraft:pink_terracotta
setblock 331 273 467 minecraft:red_nether_bricks
setblock 331 273 468 minecraft:pink_terracotta
setblock 331 273 472 minecraft:red_nether_bricks
setblock 331 273 473 minecraft:pink_terracotta
setblock 331 273 477 minecraft:red_nether_bricks
setblock 331 273 478 minecraft:pink_terracotta
fill 331 273 483 331 273 485 minecraft:white_concrete
setblock 331 273 492 minecraft:red_nether_bricks
setblock 331 273 493 minecraft:pink_terracotta
setblock 332 273 467 minecraft:pink_terracotta
setblock 332 273 471 minecraft:red_nether_bricks
setblock 332 273 472 minecraft:pink_terracotta
setblock 332 273 476 minecraft:red_nether_bricks
setblock 332 273 477 minecraft:pink_terracotta
setblock 333 273 465 minecraft:red_nether_bricks
setblock 333 273 470 minecraft:red_nether_bricks
setblock 333 273 471 minecraft:pink_terracotta
setblock 333 273 475 minecraft:red_nether_bricks
setblock 334 273 464 minecraft:red_nether_bricks
setblock 334 273 465 minecraft:pink_terracotta
setblock 335 273 464 minecraft:pink_terracotta
setblock 338 273 504 minecraft:white_concrete
setblock 349 273 464 minecraft:red_nether_bricks
setblock 349 273 504 minecraft:red_nether_bricks
setblock 350 273 464 minecraft:pink_terracotta
setblock 350 273 503 minecraft:red_nether_bricks
setblock 350 273 504 minecraft:pink_terracotta
setblock 351 273 503 minecraft:pink_terracotta
setblock 354 273 504 minecraft:red_nether_bricks
setblock 355 273 504 minecraft:pink_terracotta
setblock 356 273 464 minecraft:white_concrete
setblock 362 273 464 minecraft:white_concrete
setblock 363 273 504 minecraft:white_concrete
setblock 369 273 470 minecraft:pink_terracotta
setblock 369 273 474 minecraft:red_nether_bricks
setblock 369 273 475 minecraft:pink_terracotta
setblock 369 273 479 minecraft:red_nether_bricks
setblock 369 273 480 minecraft:pink_terracotta
setblock 369 273 489 minecraft:red_nether_bricks
setblock 369 273 490 minecraft:pink_terracotta
setblock 369 273 494 minecraft:red_nether_bricks
setblock 369 273 495 minecraft:pink_terracotta
setblock 370 273 468 minecraft:red_nether_bricks
setblock 370 273 469 minecraft:pink_terracotta
setblock 370 273 473 minecraft:red_nether_bricks
setblock 370 273 474 minecraft:pink_terracotta
setblock 370 273 478 minecraft:red_nether_bricks
setblock 370 273 479 minecraft:pink_terracotta
setblock 370 273 483 minecraft:red_nether_bricks
setblock 370 273 484 minecraft:pink_terracotta
setblock 370 273 488 minecraft:red_nether_bricks
setblock 370 273 489 minecraft:pink_terracotta
setblock 370 273 493 minecraft:red_nether_bricks
setblock 370 273 494 minecraft:pink_terracotta
setblock 370 273 498 minecraft:red_nether_bricks
fill 370 273 499 370 273 500 minecraft:pink_terracotta
fill 330 279 464 330 280 475 minecraft:pink_terracotta
fill 330 279 476 330 280 476 minecraft:red_terracotta
fill 330 279 477 330 280 490 minecraft:pink_terracotta
fill 330 279 491 330 280 492 minecraft:red_terracotta
fill 330 279 493 331 280 504 minecraft:pink_terracotta
fill 331 279 464 331 280 473 minecraft:pink_terracotta
fill 331 279 474 331 280 475 minecraft:red_terracotta
fill 331 279 476 331 280 489 minecraft:pink_terracotta
fill 331 279 490 331 280 490 minecraft:red_terracotta
fill 331 279 491 339 280 492 minecraft:pink_terracotta
fill 332 279 464 332 280 472 minecraft:pink_terracotta
fill 332 279 473 332 280 473 minecraft:red_terracotta
fill 332 279 474 332 280 487 minecraft:pink_terracotta
fill 332 279 488 332 280 489 minecraft:red_terracotta
fill 332 279 490 341 280 490 minecraft:pink_terracotta
fill 332 279 493 332 280 503 minecraft:pink_terracotta
fill 332 279 504 332 280 504 minecraft:red_terracotta
fill 333 279 464 333 280 470 minecraft:pink_terracotta
fill 333 279 471 333 280 472 minecraft:red_terracotta
fill 333 279 473 333 280 486 minecraft:pink_terracotta
fill 333 279 487 333 280 487 minecraft:red_terracotta
fill 333 279 488 341 280 489 minecraft:pink_terracotta
fill 333 279 493 333 280 502 minecraft:pink_terracotta
fill 333 279 503 333 280 503 minecraft:red_terracotta
fill 333 279 504 342 280 504 minecraft:pink_terracotta
fill 334 279 464 334 280 469 minecraft:pink_terracotta
fill 334 279 470 334 280 470 minecraft:red_terracotta
fill 334 279 471 334 280 484 minecraft:pink_terracotta
fill 334 279 485 334 280 486 minecraft:red_terracotta
fill 334 279 487 343 280 487 minecraft:pink_terracotta
fill 334 279 493 334 280 500 minecraft:pink_terracotta
fill 334 279 501 334 280 502 minecraft:red_terracotta
fill 334 279 503 342 280 503 minecraft:pink_terracotta
fill 335 279 464 335 280 467 minecraft:pink_terracotta
fill 335 279 468 335 280 469 minecraft:red_terracotta
fill 335 279 470 335 280 483 minecraft:pink_terracotta
fill 335 279 484 335 280 484 minecraft:red_terracotta
fill 335 279 485 343 280 486 minecraft:pink_terracotta
fill 335 279 493 335 280 499 minecraft:pink_terracotta
fill 335 279 500 335 280 500 minecraft:red_terracotta
fill 335 279 501 343 280 502 minecraft:pink_terracotta
fill 336 279 464 336 280 466 minecraft:pink_terracotta
fill 336 279 467 336 280 467 minecraft:red_terracotta
fill 336 279 468 336 280 481 minecraft:pink_terracotta
fill 336 279 482 336 280 483 minecraft:red_terracotta
fill 336 279 484 345 280 484 minecraft:pink_terracotta
fill 336 279 493 336 280 497 minecraft:pink_terracotta
fill 336 279 498 336 280 499 minecraft:red_terracotta
fill 336 279 500 344 280 500 minecraft:pink_terracotta
fill 337 279 464 337 280 464 minecraft:pink_terracotta
fill 337 279 465 337 280 466 minecraft:red_terracotta
fill 337 279 467 337 280 480 minecraft:pink_terracotta
fill 337 279 481 337 280 481 minecraft:red_terracotta
fill 337 279 482 345 280 483 minecraft:pink_terracotta
fill 337 279 493 337 280 496 minecraft:pink_terracotta
fill 337 279 497 337 280 497 minecraft:red_terracotta
fill 337 279 498 345 280 499 minecraft:pink_terracotta
fill 338 279 464 338 280 464 minecraft:red_terracotta
fill 338 279 465 338 280 478 minecraft:pink_terracotta
fill 338 279 479 338 280 480 minecraft:red_terracotta
fill 338 279 481 347 280 481 minecraft:pink_terracotta
fill 338 279 493 338 280 494 minecraft:pink_terracotta
fill 338 279 495 338 280 496 minecraft:red_terracotta
fill 338 279 497 346 280 497 minecraft:pink_terracotta
fill 339 279 464 339 280 477 minecraft:pink_terracotta
fill 339 279 478 339 280 478 minecraft:red_terracotta
fill 339 279 479 347 280 480 minecraft:pink_terracotta
fill 339 279 493 339 280 493 minecraft:pink_terracotta
fill 339 279 494 339 280 494 minecraft:red_terracotta
fill 339 279 495 347 280 496 minecraft:pink_terracotta
fill 340 279 464 340 280 475 minecraft:pink_terracotta
fill 340 279 476 340 280 477 minecraft:red_terracotta
fill 340 279 478 349 280 478 minecraft:pink_terracotta
fill 340 279 491 340 280 491 minecraft:pink_terracotta
fill 340 279 492 340 280 493 minecraft:red_terracotta
fill 340 279 494 348 280 494 minecraft:pink_terracotta
fill 341 279 464 341 280 474 minecraft:pink_terracotta
fill 341 279 475 341 280 475 minecraft:red_terracotta
fill 341 279 476 349 280 477 minecraft:pink_terracotta
fill 341 279 491 341 280 491 minecraft:red_terracotta
fill 341 279 492 349 280 493 minecraft:pink_terracotta
fill 342 279 464 342 280 472 minecraft:pink_terracotta
fill 342 279 473 342 280 474 minecraft:red_terracotta
fill 342 279 475 351 280 475 minecraft:pink_terracotta
fill 342 279 488 342 280 488 minecraft:pink_terracotta
fill 342 279 489 342 280 490 minecraft:red_terracotta
fill 342 279 491 350 280 491 minecraft:pink_terracotta
fill 343 279 464 343 280 471 minecraft:pink_terracotta
fill 343 279 472 343 280 472 minecraft:red_terracotta
fill 343 279 473 351 280 474 minecraft:pink_terracotta
fill 343 279 488 343 280 488 minecraft:red_terracotta
fill 343 279 489 349 279 490 minecraft:pink_terracotta
fill 343 279 503 343 280 504 minecraft:red_terracotta
fill 344 279 464 344 280 469 minecraft:pink_terracotta
fill 344 279 470 344 280 471 minecraft:red_terracotta
fill 344 279 472 353 280 472 minecraft:pink_terracotta
fill 344 279 485 344 280 485 minecraft:pink_terracotta
fill 344 279 486 344 280 487 minecraft:red_terracotta
fill 344 279 488 348 279 488 minecraft:pink_terracotta
fill 344 279 501 344 280 501 minecraft:pink_terracotta
fill 344 279 502 344 280 502 minecraft:red_terracotta
fill 344 279 503 352 280 504 minecraft:pink_terracotta
fill 345 279 464 345 280 468 minecraft:pink_terracotta
fill 345 279 469 345 280 469 minecraft:red_terracotta
fill 345 279 470 353 280 471 minecraft:pink_terracotta
fill 345 279 485 345 280 485 minecraft:red_terracotta
fill 345 279 486 347 279 487 minecraft:pink_terracotta
fill 345 279 500 345 280 501 minecraft:red_terracotta
fill 345 279 502 354 280 502 minecraft:pink_terracotta
fill 346 279 464 346 280 466 minecraft:pink_terracotta
fill 346 279 467 346 280 468 minecraft:red_terracotta
fill 346 279 469 355 280 469 minecraft:pink_terracotta
fill 346 279 482 346 280 482 minecraft:pink_terracotta
fill 346 279 483 346 280 484 minecraft:red_terracotta
fill 346 279 485 349 279 485 minecraft:pink_terracotta
fill 346 279 498 346 280 498 minecraft:pink_terracotta
fill 346 279 499 346 280 499 minecraft:red_terracotta
fill 346 279 500 354 280 501 minecraft:pink_terracotta
fill 347 279 464 347 280 465 minecraft:pink_terracotta
fill 347 279 466 347 280 466 minecraft:red_terracotta
fill 347 279 467 355 280 468 minecraft:pink_terracotta
fill 347 279 482 347 280 482 minecraft:red_terracotta
fill 347 279 483 355 279 484 minecraft:pink_terracotta
fill 347 279 497 347 280 498 minecraft:red_terracotta
fill 347 279 499 356 280 499 minecraft:pink_terracotta
fill 348 279 464 348 280 465 minecraft:red_terracotta
fill 348 279 466 357 280 466 minecraft:pink_terracotta
fill 348 279 479 348 280 479 minecraft:pink_terracotta
fill 348 279 480 348 280 481 minecraft:red_terracotta
fill 348 279 482 356 280 482 minecraft:pink_terracotta
setblock 348 279 486 minecraft:pink_terracotta
fill 348 279 495 348 280 495 minecraft:pink_terracotta
fill 348 279 496 348 280 496 minecraft:red_terracotta
fill 348 279 497 356 280 498 minecraft:pink_terracotta
fill 349 279 464 357 280 465 minecraft:pink_terracotta
fill 349 279 479 349 280 479 minecraft:red_terracotta
fill 349 279 480 357 280 481 minecraft:pink_terracotta
fill 349 279 494 349 280 495 minecraft:red_terracotta
fill 349 279 496 358 280 496 minecraft:pink_terracotta
fill 350 279 476 350 280 476 minecraft:pink_terracotta
fill 350 279 477 350 280 478 minecraft:red_terracotta
fill 350 279 479 358 280 479 minecraft:pink_terracotta
fill 350 279 490 351 279 490 minecraft:pink_terracotta
fill 350 279 492 350 280 492 minecraft:pink_terracotta
fill 350 279 493 350 280 493 minecraft:red_terracotta
fill 350 279 494 358 280 495 minecraft:pink_terracotta
fill 351 279 476 351 280 476 minecraft:red_terracotta
fill 351 279 477 359 280 478 minecraft:pink_terracotta
fill 351 279 485 354 279 485 minecraft:pink_terracotta
fill 351 279 489 352 279 489 minecraft:pink_terracotta
fill 351 279 491 351 280 492 minecraft:red_terracotta
fill 351 279 493 360 280 493 minecraft:pink_terracotta
fill 352 279 473 352 280 473 minecraft:pink_terracotta
fill 352 279 474 352 280 475 minecraft:red_terracotta
fill 352 279 476 360 280 476 minecraft:pink_terracotta
fill 352 279 486 354 279 486 minecraft:pink_terracotta
setblock 352 279 488 minecraft:pink_terracotta
fill 352 279 490 352 280 490 minecraft:red_terracotta
fill 352 279 491 360 280 492 minecraft:pink_terracotta
fill 353 279 473 353 280 473 minecraft:red_terracotta
fill 353 279 474 361 280 475 minecraft:pink_terracotta
setblock 353 279 487 minecraft:pink_terracotta
fill 353 279 488 353 279 489 minecraft:red_terracotta
fill 353 279 490 362 280 490 minecraft:pink_terracotta
fill 353 279 503 353 280 503 minecraft:pink_terracotta
fill 353 279 504 353 280 504 minecraft:red_terracotta
fill 354 279 470 354 280 470 minecraft:pink_terracotta
fill 354 279 471 354 280 472 minecraft:red_terracotta
fill 354 279 473 362 280 473 minecraft:pink_terracotta
fill 354 279 487 354 280 487 minecraft:red_terracotta
fill 354 279 488 362 280 489 minecraft:pink_terracotta
fill 354 279 503 354 280 503 minecraft:red_terracotta
fill 354 279 504 363 280 504 minecraft:pink_terracotta
fill 355 279 470 355 280 470 minecraft:red_terracotta
fill 355 279 471 363 280 472 minecraft:pink_terracotta
fill 355 279 485 355 280 486 minecraft:red_terracotta
fill 355 279 487 364 280 487 minecraft:pink_terracotta
fill 355 279 500 355 280 500 minecraft:pink_terracotta
fill 355 279 501 355 280 502 minecraft:red_terracotta
fill 355 279 503 363 280 503 minecraft:pink_terracotta
fill 356 279 467 356 280 467 minecraft:pink_terracotta
fill 356 279 468 356 280 469 minecraft:red_terracotta
fill 356 279 470 364 280 470 minecraft:pink_terracotta
fill 356 279 483 356 280 483 minecraft:pink_terracotta
fill 356 279 484 356 280 484 minecraft:red_terracotta
fill 356 279 485 364 280 486 minecraft:pink_terracotta
fill 356 279 500 356 280 500 minecraft:red_terracotta
fill 356 279 501 364 280 502 minecraft:pink_terracotta
fill 357 279 467 357 280 467 minecraft:red_terracotta
fill 357 279 468 365 280 469 minecraft:pink_terracotta
fill 357 279 482 357 280 483 minecraft:red_terracotta
fill 357 279 484 366 280 484 minecraft:pink_terracotta
fill 357 279 497 357 280 497 minecraft:pink_terracotta
fill 357 279 498 357 280 499 minecraft:red_terracotta
fill 357 279 500 365 280 500 minecraft:pink_terracotta
fill 358 279 464 358 280 464 minecraft:pink_terracotta
fill 358 279 465 358 280 466 minecraft:red_terracotta
fill 358 279 467 366 280 467 minecraft:pink_terracotta
fill 358 279 480 358 280 480 minecraft:pink_terracotta
fill 358 279 481 358 280 481 minecraft:red_terracotta
fill 358 279 482 366 280 483 minecraft:pink_terracotta
fill 358 279 497 358 280 497 minecraft:red_terracotta
fill 358 279 498 366 280 499 minecraft:pink_terracotta
fill 359 279 464 359 280 464 minecraft:red_terracotta
fill 359 279 465 367 280 466 minecraft:pink_terracotta
fill 359 279 479 359 280 480 minecraft:red_terracotta
fill 359 279 481 368 280 481 minecraft:pink_terracotta
fill 359 279 494 359 280 494 minecraft:pink_terracotta
fill 359 279 495 359 280 496 minecraft:red_terracotta
fill 359 279 497 367 280 497 minecraft:pink_terracotta
fill 360 279 464 368 280 464 minecraft:pink_terracotta
fill 360 279 477 360 280 477 minecraft:pink_terracotta
fill 360 279 478 360 280 478 minecraft:red_terracotta
fill 360 279 479 368 280 480 minecraft:pink_terracotta
fill 360 279 494 360 280 494 minecraft:red_terracotta
fill 360 279 495 368 280 496 minecraft:pink_terracotta
fill 361 279 476 361 280 477 minecraft:red_terracotta
fill 361 279 478 370 280 478 minecraft:pink_terracotta
fill 361 279 491 361 280 491 minecraft:pink_terracotta
fill 361 279 492 361 280 493 minecraft:red_terracotta
fill 361 279 494 369 280 494 minecraft:pink_terracotta
fill 362 279 474 362 280 474 minecraft:pink_terracotta
fill 362 279 475 362 280 475 minecraft:red_terracotta
fill 362 279 476 370 280 477 minecraft:pink_terracotta
fill 362 279 491 362 280 491 minecraft:red_terracotta
fill 362 279 492 370 280 493 minecraft:pink_terracotta
fill 363 279 473 363 280 474 minecraft:red_terracotta
fill 363 279 475 370 280 475 minecraft:pink_terracotta
fill 363 279 488 363 280 488 minecraft:pink_terracotta
fill 363 279 489 363 280 490 minecraft:red_terracotta
fill 363 279 491 370 280 491 minecraft:pink_terracotta
fill 364 279 471 364 280 471 minecraft:pink_terracotta
fill 364 279 472 364 280 472 minecraft:red_terracotta
fill 364 279 473 370 280 474 minecraft:pink_terracotta
fill 364 279 488 364 280 488 minecraft:red_terracotta
fill 364 279 489 370 280 490 minecraft:pink_terracotta
fill 364 279 503 364 280 504 minecraft:red_terracotta
fill 365 279 470 365 280 471 minecraft:red_terracotta
fill 365 279 472 370 280 472 minecraft:pink_terracotta
fill 365 279 485 365 280 485 minecraft:pink_terracotta
fill 365 279 486 365 280 487 minecraft:red_terracotta
fill 365 279 488 370 280 488 minecraft:pink_terracotta
fill 365 279 501 365 280 501 minecraft:pink_terracotta
fill 365 279 502 365 280 502 minecraft:red_terracotta
fill 365 279 503 370 280 504 minecraft:pink_terracotta
fill 366 279 468 366 280 468 minecraft:pink_terracotta
fill 366 279 469 366 280 469 minecraft:red_terracotta
fill 366 279 470 370 280 471 minecraft:pink_terracotta
fill 366 279 485 366 280 485 minecraft:red_terracotta
fill 366 279 486 370 280 487 minecraft:pink_terracotta
fill 366 279 500 366 280 501 minecraft:red_terracotta
fill 366 279 502 370 280 502 minecraft:pink_terracotta
fill 367 279 467 367 280 468 minecraft:red_terracotta
fill 367 279 469 370 280 469 minecraft:pink_terracotta
fill 367 279 482 367 280 482 minecraft:pink_terracotta
fill 367 279 483 367 280 484 minecraft:red_terracotta
fill 367 279 485 370 280 485 minecraft:pink_terracotta
fill 367 279 498 367 280 498 minecraft:pink_terracotta
fill 367 279 499 367 280 499 minecraft:red_terracotta
fill 367 279 500 370 280 501 minecraft:pink_terracotta
fill 368 279 465 368 280 465 minecraft:pink_terracotta
fill 368 279 466 368 280 466 minecraft:red_terracotta
fill 368 279 467 370 280 468 minecraft:pink_terracotta
fill 368 279 482 368 280 482 minecraft:red_terracotta
fill 368 279 483 370 280 484 minecraft:pink_terracotta
fill 368 279 497 368 280 498 minecraft:red_terracotta
fill 368 279 499 370 280 499 minecraft:pink_terracotta
fill 369 279 464 369 280 465 minecraft:red_terracotta
fill 369 279 466 370 280 466 minecraft:pink_terracotta
fill 369 279 479 369 280 479 minecraft:pink_terracotta
fill 369 279 480 369 280 481 minecraft:red_terracotta
fill 369 279 482 370 280 482 minecraft:pink_terracotta
fill 369 279 495 369 280 495 minecraft:pink_terracotta
fill 369 279 496 369 280 496 minecraft:red_terracotta
fill 369 279 497 370 280 498 minecraft:pink_terracotta
fill 370 279 464 370 280 465 minecraft:pink_terracotta
fill 370 279 479 370 280 479 minecraft:red_terracotta
fill 370 279 480 370 280 481 minecraft:pink_terracotta
fill 370 279 494 370 280 495 minecraft:red_terracotta
fill 370 279 496 370 280 496 minecraft:pink_terracotta
fill 343 280 489 347 280 490 minecraft:pink_terracotta
fill 344 280 488 346 280 488 minecraft:pink_terracotta
fill 345 280 486 346 280 487 minecraft:pink_terracotta
fill 346 280 485 347 280 485 minecraft:pink_terracotta
fill 347 280 483 348 280 484 minecraft:pink_terracotta
fill 347 280 486 347 280 488 minecraft:shroomlight
fill 348 280 485 348 280 486 minecraft:shroomlight
fill 348 280 488 348 280 489 minecraft:shroomlight
setblock 348 280 490 minecraft:pink_terracotta
fill 349 280 483 355 280 483 minecraft:pink_terracotta
fill 349 280 484 349 280 485 minecraft:shroomlight
fill 349 280 489 349 280 490 minecraft:shroomlight
fill 350 280 484 351 280 484 minecraft:shroomlight
fill 350 280 490 351 280 490 minecraft:shroomlight
fill 351 280 485 352 280 485 minecraft:shroomlight
fill 351 280 489 352 280 489 minecraft:shroomlight
fill 352 280 484 355 280 484 minecraft:pink_terracotta
fill 352 280 486 353 280 486 minecraft:shroomlight
fill 352 280 488 353 280 488 minecraft:shroomlight
fill 353 280 485 354 280 485 minecraft:pink_terracotta
setblock 353 280 487 minecraft:shroomlight
setblock 353 280 489 minecraft:red_terracotta
setblock 354 280 486 minecraft:pink_terracotta
fill 330 284 464 330 284 466 minecraft:pink_terracotta
setblock 330 284 467 minecraft:red_nether_bricks
fill 330 284 468 330 284 471 minecraft:pink_terracotta
setblock 330 284 472 minecraft:red_nether_bricks
fill 330 284 473 330 284 476 minecraft:pink_terracotta
setblock 330 284 477 minecraft:red_nether_bricks
fill 330 284 478 330 284 481 minecraft:pink_terracotta
setblock 330 284 482 minecraft:red_nether_bricks
fill 330 284 483 330 284 486 minecraft:pink_terracotta
setblock 330 284 487 minecraft:red_nether_bricks
setblock 330 284 496 minecraft:pink_terracotta
setblock 330 284 497 minecraft:red_nether_bricks
fill 330 284 498 330 284 501 minecraft:pink_terracotta
setblock 330 284 502 minecraft:red_nether_bricks
fill 330 284 503 332 284 504 minecraft:pink_terracotta
fill 331 284 464 331 284 465 minecraft:pink_terracotta
setblock 331 284 466 minecraft:red_nether_bricks
fill 331 284 467 331 284 468 minecraft:pink_terracotta
fill 331 284 474 331 284 475 minecraft:pink_terracotta
setblock 331 284 476 minecraft:red_nether_bricks
fill 331 284 477 331 284 480 minecraft:pink_terracotta
setblock 331 284 481 minecraft:red_nether_bricks
fill 331 284 482 331 284 483 minecraft:pink_terracotta
fill 331 284 499 331 284 500 minecraft:pink_terracotta
setblock 331 284 501 minecraft:red_nether_bricks
fill 331 284 502 332 284 502 minecraft:pink_terracotta
setblock 332 284 464 minecraft:pink_terracotta
setblock 332 284 465 minecraft:red_nether_bricks
setblock 333 284 464 minecraft:red_nether_bricks
fill 333 284 465 333 285 465 minecraft:pink_terracotta
setblock 333 284 503 minecraft:pink_terracotta
setblock 333 284 504 minecraft:red_nether_bricks
fill 334 284 464 337 284 464 minecraft:pink_terracotta
setblock 334 284 503 minecraft:red_nether_bricks
fill 334 284 504 337 284 504 minecraft:pink_terracotta
fill 335 284 503 338 284 503 minecraft:pink_terracotta
setblock 338 284 464 minecraft:red_nether_bricks
fill 338 284 502 339 284 502 minecraft:pink_terracotta
setblock 338 284 504 minecraft:red_nether_bricks
fill 339 284 464 342 284 464 minecraft:pink_terracotta
setblock 339 284 503 minecraft:red_nether_bricks
fill 339 284 504 342 284 504 minecraft:pink_terracotta
setblock 340 284 502 minecraft:red_nether_bricks
fill 340 284 503 343 284 503 minecraft:pink_terracotta
fill 341 284 501 341 285 501 minecraft:white_concrete
fill 341 284 502 344 284 502 minecraft:pink_terracotta
setblock 342 284 465 minecraft:red_nether_bricks
fill 342 284 501 345 284 501 minecraft:pink_terracotta
setblock 343 284 464 minecraft:red_nether_bricks
fill 343 284 465 346 284 465 minecraft:pink_terracotta
setblock 343 284 504 minecraft:red_nether_bricks
fill 344 284 464 347 284 464 minecraft:pink_terracotta
setblock 344 284 503 minecraft:red_nether_bricks
fill 344 284 504 347 284 504 minecraft:pink_terracotta
setblock 345 284 502 minecraft:red_nether_bricks
fill 345 284 503 348 284 503 minecraft:pink_terracotta
setblock 346 284 501 minecraft:red_nether_bricks
fill 346 284 502 349 284 502 minecraft:pink_terracotta
setblock 347 284 465 minecraft:red_nether_bricks
fill 347 284 501 350 284 501 minecraft:pink_terracotta
setblock 348 284 464 minecraft:red_nether_bricks
setblock 348 284 465 minecraft:pink_terracotta
setblock 348 284 504 minecraft:red_nether_bricks
fill 349 284 464 351 285 464 minecraft:pink_terracotta
setblock 349 284 503 minecraft:red_nether_bricks
fill 349 284 504 352 284 504 minecraft:pink_terracotta
setblock 350 284 502 minecraft:red_nether_bricks
fill 350 284 503 353 284 503 minecraft:pink_terracotta
fill 351 284 502 352 284 502 minecraft:pink_terracotta
setblock 353 284 464 minecraft:white_concrete
setblock 353 284 504 minecraft:red_nether_bricks
setblock 354 284 503 minecraft:red_nether_bricks
fill 354 284 504 357 284 504 minecraft:pink_terracotta
setblock 358 284 504 minecraft:red_nether_bricks
setblock 359 284 464 minecraft:white_concrete
fill 359 284 504 362 284 504 minecraft:pink_terracotta
setblock 362 284 464 minecraft:pink_terracotta
fill 362 284 503 363 284 503 minecraft:pink_terracotta
setblock 363 284 464 minecraft:red_nether_bricks
setblock 363 284 504 minecraft:red_nether_bricks
fill 364 284 464 366 284 465 minecraft:pink_terracotta
setblock 364 284 503 minecraft:red_nether_bricks
fill 364 284 504 367 284 504 minecraft:pink_terracotta
fill 365 284 503 368 284 503 minecraft:pink_terracotta
fill 366 284 479 366 284 480 minecraft:pink_terracotta
setblock 366 284 481 minecraft:red_nether_bricks
fill 366 284 482 369 284 482 minecraft:pink_terracotta
fill 366 284 502 367 284 502 minecraft:pink_terracotta
setblock 367 284 464 minecraft:pink_terracotta
setblock 367 284 465 minecraft:red_nether_bricks
setblock 367 284 475 minecraft:red_nether_bricks
fill 367 284 476 367 284 479 minecraft:pink_terracotta
setblock 367 284 480 minecraft:red_nether_bricks
fill 367 284 481 370 284 481 minecraft:pink_terracotta
fill 367 284 483 367 284 484 minecraft:pink_terracotta
setblock 367 284 485 minecraft:red_nether_bricks
setblock 368 284 464 minecraft:red_nether_bricks
fill 368 284 465 370 285 465 minecraft:pink_terracotta
setblock 368 284 473 minecraft:pink_terracotta
setblock 368 284 474 minecraft:red_nether_bricks
fill 368 284 475 368 284 478 minecraft:pink_terracotta
setblock 368 284 479 minecraft:red_nether_bricks
fill 368 284 480 370 285 480 minecraft:pink_terracotta
setblock 368 284 483 minecraft:pink_terracotta
setblock 368 284 484 minecraft:red_nether_bricks
fill 368 284 485 370 284 486 minecraft:pink_terracotta
setblock 368 284 504 minecraft:red_nether_bricks
fill 369 284 464 370 286 464 minecraft:pink_terracotta
fill 369 284 466 369 284 467 minecraft:pink_terracotta
setblock 369 284 468 minecraft:red_nether_bricks
fill 369 284 469 369 284 472 minecraft:pink_terracotta
setblock 369 284 473 minecraft:red_nether_bricks
fill 369 284 474 369 284 477 minecraft:pink_terracotta
setblock 369 284 478 minecraft:red_nether_bricks
fill 369 284 479 370 286 479 minecraft:pink_terracotta
setblock 369 284 483 minecraft:red_nether_bricks
fill 369 284 484 370 286 484 minecraft:pink_terracotta
setblock 369 284 487 minecraft:pink_terracotta
setblock 369 284 488 minecraft:red_nether_bricks
setblock 369 284 498 minecraft:red_nether_bricks
fill 369 284 499 369 284 502 minecraft:pink_terracotta
setblock 369 284 503 minecraft:red_nether_bricks
fill 369 284 504 370 286 504 minecraft:pink_terracotta
setblock 370 284 466 minecraft:pink_terracotta
setblock 370 284 467 minecraft:red_nether_bricks
fill 370 284 468 370 284 471 minecraft:pink_terracotta
setblock 370 284 472 minecraft:red_nether_bricks
fill 370 284 473 370 284 476 minecraft:pink_terracotta
setblock 370 284 477 minecraft:red_nether_bricks
fill 370 284 478 370 287 478 minecraft:pink_terracotta
setblock 370 284 482 minecraft:red_nether_bricks
fill 370 284 483 370 287 483 minecraft:pink_terracotta
setblock 370 284 487 minecraft:red_nether_bricks
fill 370 284 488 370 284 490 minecraft:pink_terracotta
fill 370 284 491 370 285 491 minecraft:white_concrete
setblock 370 284 496 minecraft:pink_terracotta
setblock 370 284 497 minecraft:red_nether_bricks
fill 370 284 498 370 284 501 minecraft:pink_terracotta
setblock 370 284 502 minecraft:red_nether_bricks
fill 370 284 503 370 287 503 minecraft:pink_terracotta
fill 330 285 464 330 285 465 minecraft:pink_terracotta
setblock 330 285 466 minecraft:red_nether_bricks
fill 330 285 467 330 285 470 minecraft:pink_terracotta
setblock 330 285 471 minecraft:red_nether_bricks
fill 330 285 472 330 285 475 minecraft:pink_terracotta
setblock 330 285 476 minecraft:red_nether_bricks
fill 330 285 477 330 285 480 minecraft:pink_terracotta
setblock 330 285 481 minecraft:red_nether_bricks
fill 330 285 482 330 285 485 minecraft:pink_terracotta
setblock 330 285 486 minecraft:red_nether_bricks
fill 330 285 497 330 285 500 minecraft:pink_terracotta
setblock 330 285 501 minecraft:red_nether_bricks
fill 330 285 502 331 285 504 minecraft:pink_terracotta
setblock 331 285 464 minecraft:pink_terracotta
setblock 331 285 465 minecraft:red_nether_bricks
fill 331 285 466 331 285 467 minecraft:pink_terracotta
fill 331 285 478 331 285 479 minecraft:pink_terracotta
setblock 331 285 480 minecraft:red_nether_bricks
setblock 331 285 481 minecraft:pink_terracotta
setblock 331 285 500 minecraft:red_nether_bricks
fill 331 285 501 331 286 501 minecraft:pink_terracotta
setblock 332 285 464 minecraft:red_nether_bricks
fill 332 285 465 332 287 465 minecraft:pink_terracotta
setblock 332 285 503 minecraft:pink_terracotta
setblock 332 285 504 minecraft:red_nether_bricks
fill 333 285 464 336 285 464 minecraft:pink_terracotta
setblock 333 285 503 minecraft:red_nether_bricks
fill 333 285 504 336 285 504 minecraft:pink_terracotta
fill 334 285 503 337 285 503 minecraft:pink_terracotta
setblock 337 285 464 minecraft:red_nether_bricks
setblock 337 285 504 minecraft:red_nether_bricks
fill 338 285 464 341 285 464 minecraft:pink_terracotta
setblock 338 285 503 minecraft:red_nether_bricks
fill 338 285 504 341 285 504 minecraft:pink_terracotta
setblock 339 285 502 minecraft:red_nether_bricks
fill 339 285 503 342 285 503 minecraft:pink_terracotta
fill 340 285 502 343 285 502 minecraft:pink_terracotta
setblock 341 285 465 minecraft:red_nether_bricks
setblock 342 285 464 minecraft:red_nether_bricks
fill 342 285 465 345 285 465 minecraft:pink_terracotta
setblock 342 285 500 minecraft:black_concrete
fill 342 285 501 344 285 501 minecraft:pink_terracotta
setblock 342 285 504 minecraft:red_nether_bricks
fill 343 285 464 346 285 464 minecraft:pink_terracotta
setblock 343 285 503 minecraft:red_nether_bricks
fill 343 285 504 346 285 504 minecraft:pink_terracotta
setblock 344 285 502 minecraft:red_nether_bricks
fill 344 285 503 347 285 503 minecraft:pink_terracotta
setblock 345 285 501 minecraft:red_nether_bricks
fill 345 285 502 348 285 502 minecraft:pink_terracotta
setblock 346 285 465 minecraft:red_nether_bricks
fill 346 285 501 349 285 501 minecraft:pink_terracotta
setblock 347 285 464 minecraft:red_nether_bricks
fill 347 285 465 347 286 465 minecraft:pink_terracotta
setblock 347 285 504 minecraft:red_nether_bricks
fill 348 285 464 348 288 464 minecraft:pink_terracotta
setblock 348 285 503 minecraft:red_nether_bricks
fill 348 285 504 351 285 504 minecraft:pink_terracotta
setblock 349 285 502 minecraft:red_nether_bricks
fill 349 285 503 352 285 503 minecraft:pink_terracotta
fill 350 285 502 351 285 502 minecraft:pink_terracotta
setblock 352 285 504 minecraft:red_nether_bricks
setblock 353 285 503 minecraft:red_nether_bricks
fill 353 285 504 356 285 504 minecraft:pink_terracotta
setblock 357 285 504 minecraft:red_nether_bricks
fill 358 285 504 361 285 504 minecraft:pink_terracotta
setblock 361 285 464 minecraft:pink_terracotta
setblock 362 285 464 minecraft:red_nether_bricks
setblock 362 285 503 minecraft:pink_terracotta
setblock 362 285 504 minecraft:red_nether_bricks
fill 363 285 464 366 285 464 minecraft:pink_terracotta
setblock 363 285 503 minecraft:red_nether_bricks
fill 363 285 504 366 285 504 minecraft:pink_terracotta
fill 364 285 465 365 285 465 minecraft:pink_terracotta
fill 364 285 503 367 285 503 minecraft:pink_terracotta
setblock 366 285 465 minecraft:red_nether_bricks
setblock 367 285 464 minecraft:red_nether_bricks
fill 367 285 465 367 288 465 minecraft:pink_terracotta
fill 367 285 477 367 285 478 minecraft:pink_terracotta
setblock 367 285 479 minecraft:red_nether_bricks
fill 367 285 480 367 285 483 minecraft:pink_terracotta
setblock 367 285 484 minecraft:red_nether_bricks
setblock 367 285 504 minecraft:red_nether_bricks
fill 368 285 464 368 288 464 minecraft:pink_terracotta
fill 368 285 474 368 285 477 minecraft:pink_terracotta
setblock 368 285 478 minecraft:red_nether_bricks
fill 368 285 479 368 287 479 minecraft:pink_terracotta
fill 368 285 481 368 285 482 minecraft:pink_terracotta
setblock 368 285 483 minecraft:red_nether_bricks
fill 368 285 484 368 285 486 minecraft:pink_terracotta
setblock 368 285 503 minecraft:red_nether_bricks
fill 368 285 504 368 288 504 minecraft:pink_terracotta
setblock 369 285 466 minecraft:pink_terracotta
setblock 369 285 467 minecraft:red_nether_bricks
fill 369 285 468 369 285 471 minecraft:pink_terracotta
setblock 369 285 472 minecraft:red_nether_bricks
fill 369 285 473 369 285 476 minecraft:pink_terracotta
setblock 369 285 477 minecraft:red_nether_bricks
fill 369 285 478 369 288 478 minecraft:pink_terracotta
setblock 369 285 481 minecraft:pink_terracotta
setblock 369 285 482 minecraft:red_nether_bricks
fill 369 285 483 369 288 483 minecraft:pink_terracotta
fill 369 285 485 369 285 486 minecraft:pink_terracotta
setblock 369 285 487 minecraft:red_nether_bricks
fill 369 285 500 369 285 501 minecraft:pink_terracotta
setblock 369 285 502 minecraft:red_nether_bricks
fill 369 285 503 369 286 503 minecraft:pink_terracotta
setblock 370 285 466 minecraft:red_nether_bricks
fill 370 285 467 370 285 470 minecraft:pink_terracotta
setblock 370 285 471 minecraft:red_nether_bricks
fill 370 285 472 370 285 475 minecraft:pink_terracotta
setblock 370 285 476 minecraft:red_nether_bricks
fill 370 285 477 370 288 477 minecraft:pink_terracotta
setblock 370 285 481 minecraft:red_nether_bricks
fill 370 285 482 370 288 482 minecraft:pink_terracotta
setblock 370 285 485 minecraft:pink_terracotta
setblock 370 285 486 minecraft:red_nether_bricks
fill 370 285 487 370 285 489 minecraft:pink_terracotta
fill 370 285 498 370 285 500 minecraft:pink_terracotta
setblock 370 285 501 minecraft:red_nether_bricks
fill 370 285 502 370 287 502 minecraft:pink_terracotta
setblock 330 286 464 minecraft:pink_terracotta
setblock 330 286 465 minecraft:red_nether_bricks
fill 330 286 466 330 286 469 minecraft:pink_terracotta
setblock 330 286 470 minecraft:red_nether_bricks
fill 330 286 471 330 286 474 minecraft:pink_terracotta
setblock 330 286 475 minecraft:red_nether_bricks
fill 330 286 476 330 286 479 minecraft:pink_terracotta
setblock 330 286 480 minecraft:red_nether_bricks
fill 330 286 481 330 286 484 minecraft:pink_terracotta
setblock 330 286 485 minecraft:red_nether_bricks
setblock 330 286 486 minecraft:pink_terracotta
fill 330 286 489 330 287 489 minecraft:white_concrete
fill 330 286 498 330 286 499 minecraft:pink_terracotta
setblock 330 286 500 minecraft:red_nether_bricks
fill 330 286 501 330 286 504 minecraft:pink_terracotta
setblock 331 286 464 minecraft:red_nether_bricks
fill 331 286 465 331 287 466 minecraft:pink_terracotta
fill 331 286 502 331 286 503 minecraft:pink_terracotta
setblock 331 286 504 minecraft:red_nether_bricks
fill 332 286 464 335 286 464 minecraft:pink_terracotta
setblock 332 286 503 minecraft:red_nether_bricks
fill 332 286 504 335 286 504 minecraft:pink_terracotta
fill 333 286 503 336 286 503 minecraft:pink_terracotta
setblock 336 286 464 minecraft:red_nether_bricks
setblock 336 286 504 minecraft:red_nether_bricks
fill 337 286 464 340 286 464 minecraft:pink_terracotta
setblock 337 286 503 minecraft:red_nether_bricks
fill 337 286 504 340 286 504 minecraft:pink_terracotta
fill 338 286 503 341 286 503 minecraft:pink_terracotta
fill 339 286 502 342 286 502 minecraft:pink_terracotta
setblock 341 286 464 minecraft:red_nether_bricks
fill 341 286 465 344 286 465 minecraft:pink_terracotta
setblock 341 286 504 minecraft:red_nether_bricks
fill 342 286 464 345 286 464 minecraft:pink_terracotta
setblock 342 286 501 minecraft:white_concrete
setblock 342 286 503 minecraft:red_nether_bricks
fill 342 286 504 345 286 504 minecraft:pink_terracotta
setblock 343 286 501 minecraft:pink_terracotta
setblock 343 286 502 minecraft:red_nether_bricks
fill 343 286 503 346 286 503 minecraft:pink_terracotta
setblock 344 286 501 minecraft:red_nether_bricks
fill 344 286 502 347 286 502 minecraft:pink_terracotta
setblock 345 286 465 minecraft:red_nether_bricks
fill 345 286 501 347 286 501 minecraft:pink_terracotta
setblock 346 286 464 minecraft:red_nether_bricks
fill 346 286 465 346 288 465 minecraft:pink_terracotta
setblock 346 286 504 minecraft:red_nether_bricks
fill 347 286 464 347 289 464 minecraft:pink_terracotta
setblock 347 286 503 minecraft:red_nether_bricks
fill 347 286 504 350 286 504 minecraft:pink_terracotta
setblock 348 286 502 minecraft:red_nether_bricks
fill 348 286 503 351 286 503 minecraft:pink_terracotta
fill 349 286 464 350 286 464 minecraft:pink_terracotta
fill 349 286 502 350 286 502 minecraft:pink_terracotta
setblock 351 286 504 minecraft:red_nether_bricks
setblock 352 286 503 minecraft:red_nether_bricks
fill 352 286 504 354 286 504 minecraft:pink_terracotta
fill 359 286 504 360 286 504 minecraft:pink_terracotta
setblock 360 286 464 minecraft:pink_terracotta
setblock 361 286 464 minecraft:red_nether_bricks
setblock 361 286 504 minecraft:red_nether_bricks
fill 362 286 464 365 286 464 minecraft:pink_terracotta
setblock 362 286 503 minecraft:red_nether_bricks
fill 362 286 504 365 286 504 minecraft:pink_terracotta
fill 363 286 465 364 286 465 minecraft:pink_terracotta
fill 363 286 503 366 286 503 minecraft:pink_terracotta
setblock 365 286 465 minecraft:red_nether_bricks
setblock 366 286 464 minecraft:red_nether_bricks
fill 366 286 465 366 289 465 minecraft:pink_terracotta
setblock 366 286 504 minecraft:red_nether_bricks
fill 367 286 464 367 289 464 minecraft:pink_terracotta
fill 367 286 479 367 286 482 minecraft:pink_terracotta
setblock 367 286 483 minecraft:red_nether_bricks
fill 367 286 484 368 286 484 minecraft:pink_terracotta
setblock 367 286 503 minecraft:red_nether_bricks
fill 367 286 504 367 289 504 minecraft:pink_terracotta
fill 368 286 465 369 286 465 minecraft:pink_terracotta
setblock 368 286 476 minecraft:pink_terracotta
setblock 368 286 477 minecraft:red_nether_bricks
fill 368 286 478 368 287 478 minecraft:pink_terracotta
fill 368 286 480 368 286 481 minecraft:pink_terracotta
setblock 368 286 482 minecraft:red_nether_bricks
fill 368 286 483 368 288 483 minecraft:pink_terracotta
fill 368 286 485 369 286 485 minecraft:pink_terracotta
fill 368 286 503 368 287 503 minecraft:pink_terracotta
setblock 369 286 466 minecraft:red_nether_bricks
fill 369 286 467 370 286 469 minecraft:pink_terracotta
fill 369 286 472 369 286 475 minecraft:pink_terracotta
setblock 369 286 476 minecraft:red_nether_bricks
fill 369 286 477 369 287 477 minecraft:pink_terracotta
setblock 369 286 480 minecraft:pink_terracotta
setblock 369 286 481 minecraft:red_nether_bricks
fill 369 286 482 369 289 482 minecraft:pink_terracotta
setblock 369 286 486 minecraft:red_nether_bricks
fill 369 286 487 370 286 487 minecraft:pink_terracotta
setblock 369 286 502 minecraft:pink_terracotta
setblock 370 286 465 minecraft:red_nether_bricks
fill 370 286 466 370 289 466 minecraft:pink_terracotta
setblock 370 286 470 minecraft:red_nether_bricks
fill 370 286 471 370 286 474 minecraft:pink_terracotta
setblock 370 286 475 minecraft:red_nether_bricks
fill 370 286 476 370 288 476 minecraft:pink_terracotta
setblock 370 286 480 minecraft:red_nether_bricks
fill 370 286 481 370 289 481 minecraft:pink_terracotta
setblock 370 286 485 minecraft:red_nether_bricks
fill 370 286 486 370 289 486 minecraft:pink_terracotta
setblock 370 286 488 minecraft:pink_terracotta
setblock 370 286 500 minecraft:red_nether_bricks
setblock 370 286 501 minecraft:pink_terracotta
setblock 330 287 464 minecraft:red_nether_bricks
fill 330 287 465 330 287 468 minecraft:pink_terracotta
setblock 330 287 469 minecraft:red_nether_bricks
setblock 330 287 470 minecraft:pink_terracotta
setblock 330 287 478 minecraft:pink_terracotta
setblock 330 287 479 minecraft:red_nether_bricks
fill 330 287 480 330 287 483 minecraft:pink_terracotta
setblock 330 287 484 minecraft:red_nether_bricks
setblock 330 287 485 minecraft:pink_terracotta
setblock 330 287 495 minecraft:white_concrete
fill 330 287 500 330 287 503 minecraft:pink_terracotta
setblock 330 287 504 minecraft:red_nether_bricks
fill 331 287 464 334 287 464 minecraft:pink_terracotta
setblock 331 287 502 minecraft:pink_terracotta
setblock 331 287 503 minecraft:red_nether_bricks
fill 331 287 504 334 287 504 minecraft:pink_terracotta
setblock 332 287 466 minecraft:light[level=12]
setblock 332 287 474 minecraft:light[level=12]
setblock 332 287 482 minecraft:light[level=12]
setblock 332 287 490 minecraft:light[level=12]
setblock 332 287 498 minecraft:light[level=12]
fill 332 287 503 335 287 503 minecraft:pink_terracotta
setblock 335 287 464 minecraft:red_nether_bricks
fill 335 287 478 335 288 479 minecraft:pink_concrete
setblock 335 287 504 minecraft:red_nether_bricks
fill 336 287 464 339 287 464 minecraft:pink_terracotta
setblock 336 287 503 minecraft:red_nether_bricks
fill 336 287 504 339 287 504 minecraft:pink_terracotta
fill 337 287 503 340 287 503 minecraft:pink_terracotta
setblock 340 287 464 minecraft:red_nether_bricks
fill 340 287 465 343 287 465 minecraft:pink_terracotta
setblock 340 287 466 minecraft:light[level=12]
setblock 340 287 474 minecraft:light[level=12]
setblock 340 287 482 minecraft:light[level=12]
setblock 340 287 490 minecraft:light[level=12]
setblock 340 287 498 minecraft:light[level=12]
fill 340 287 502 341 287 502 minecraft:pink_terracotta
setblock 340 287 504 minecraft:red_nether_bricks
fill 341 287 464 344 287 464 minecraft:pink_terracotta
setblock 341 287 503 minecraft:red_nether_bricks
fill 341 287 504 344 287 504 minecraft:pink_terracotta
setblock 342 287 502 minecraft:red_nether_bricks
fill 342 287 503 345 287 503 minecraft:pink_terracotta
fill 343 287 502 346 287 502 minecraft:pink_terracotta
setblock 344 287 465 minecraft:red_nether_bricks
setblock 345 287 464 minecraft:red_nether_bricks
fill 345 287 465 345 290 465 minecraft:pink_terracotta
setblock 345 287 504 minecraft:red_nether_bricks
fill 346 287 464 346 290 464 minecraft:pink_terracotta
setblock 346 287 503 minecraft:red_nether_bricks
fill 346 287 504 349 287 504 minecraft:pink_terracotta
setblock 347 287 502 minecraft:red_nether_bricks
fill 347 287 503 350 287 503 minecraft:pink_terracotta
setblock 348 287 466 minecraft:light[level=12]
setblock 348 287 474 minecraft:light[level=12]
setblock 348 287 482 minecraft:light[level=12]
setblock 348 287 490 minecraft:light[level=12]
setblock 348 287 498 minecraft:light[level=12]
setblock 348 287 502 minecraft:pink_terracotta
setblock 349 287 464 minecraft:pink_terracotta
setblock 350 287 464 minecraft:red_nether_bricks
setblock 350 287 504 minecraft:red_nether_bricks
fill 351 287 504 353 287 504 minecraft:pink_terracotta
setblock 356 287 466 minecraft:light[level=12]
setblock 356 287 474 minecraft:light[level=12]
setblock 356 287 482 minecraft:light[level=12]
setblock 356 287 490 minecraft:light[level=12]
setblock 356 287 498 minecraft:light[level=12]
setblock 359 287 504 minecraft:pink_terracotta
setblock 360 287 464 minecraft:red_nether_bricks
setblock 360 287 504 minecraft:red_nether_bricks
fill 361 287 464 364 287 464 minecraft:pink_terracotta
fill 361 287 504 364 287 504 minecraft:pink_terracotta
setblock 363 287 465 minecraft:pink_terracotta
fill 363 287 503 365 287 503 minecraft:pink_terracotta
setblock 364 287 465 minecraft:red_nether_bricks
setblock 364 287 466 minecraft:light[level=12]
setblock 364 287 474 minecraft:light[level=12]
setblock 364 287 482 minecraft:light[level=12]
setblock 364 287 490 minecraft:light[level=12]
setblock 364 287 498 minecraft:light[level=12]
setblock 365 287 464 minecraft:red_nether_bricks
fill 365 287 465 365 290 465 minecraft:pink_terracotta
setblock 365 287 504 minecraft:red_nether_bricks
fill 366 287 464 366 290 464 minecraft:pink_terracotta
setblock 366 287 503 minecraft:red_nether_bricks
fill 366 287 504 366 290 504 minecraft:pink_terracotta
setblock 367 287 503 minecraft:pink_terracotta
setblock 368 287 465 minecraft:pink_terracotta
setblock 368 287 480 minecraft:pink_terracotta
setblock 368 287 481 minecraft:red_nether_bricks
fill 368 287 482 368 288 482 minecraft:pink_terracotta
fill 368 287 484 368 287 485 minecraft:pink_terracotta
setblock 369 287 464 minecraft:pink_terracotta
setblock 369 287 465 minecraft:red_nether_bricks
fill 369 287 466 369 288 468 minecraft:pink_terracotta
setblock 369 287 475 minecraft:red_nether_bricks
setblock 369 287 476 minecraft:pink_terracotta
setblock 369 287 479 minecraft:pink_terracotta
setblock 369 287 480 minecraft:red_nether_bricks
fill 369 287 481 369 289 481 minecraft:pink_terracotta
setblock 369 287 484 minecraft:pink_terracotta
setblock 369 287 485 minecraft:red_nether_bricks
setblock 369 287 486 minecraft:pink_terracotta
setblock 369 287 504 minecraft:pink_terracotta
setblock 370 287 464 minecraft:red_nether_bricks
fill 370 287 465 370 290 465 minecraft:pink_terracotta
fill 370 287 467 370 287 468 minecraft:pink_terracotta
setblock 370 287 469 minecraft:red_nether_bricks
fill 370 287 470 370 287 473 minecraft:pink_terracotta
setblock 370 287 474 minecraft:red_nether_bricks
fill 370 287 475 370 288 475 minecraft:pink_terracotta
setblock 370 287 479 minecraft:red_nether_bricks
fill 370 287 480 370 290 480 minecraft:pink_terracotta
setblock 370 287 484 minecraft:red_nether_bricks
fill 370 287 485 370 290 485 minecraft:pink_terracotta
fill 370 287 487 370 288 487 minecraft:pink_terracotta
setblock 370 287 498 minecraft:white_concrete
setblock 370 287 504 minecraft:red_nether_bricks
fill 330 288 464 330 288 467 minecraft:pink_terracotta
setblock 330 288 468 minecraft:red_nether_bricks
setblock 330 288 469 minecraft:pink_terracotta
setblock 330 288 476 minecraft:white_concrete
fill 330 288 501 330 288 502 minecraft:pink_terracotta
setblock 330 288 503 minecraft:red_nether_bricks
fill 330 288 504 333 288 504 minecraft:pink_terracotta
fill 331 288 464 331 289 465 minecraft:pink_terracotta
fill 332 288 464 333 288 464 minecraft:pink_terracotta
setblock 334 288 464 minecraft:red_nether_bricks
setblock 334 288 504 minecraft:red_nether_bricks
fill 335 288 464 338 288 464 minecraft:pink_terracotta
fill 335 288 504 338 288 504 minecraft:pink_terracotta
fill 336 288 503 339 288 503 minecraft:pink_terracotta
fill 337 288 502 339 291 502 minecraft:white_concrete
fill 338 288 501 338 291 501 minecraft:white_concrete
setblock 339 288 464 minecraft:red_nether_bricks
setblock 339 288 504 minecraft:red_nether_bricks
fill 340 288 464 342 288 465 minecraft:pink_terracotta
setblock 340 288 502 minecraft:pink_terracotta
setblock 340 288 503 minecraft:red_nether_bricks
fill 340 288 504 343 288 504 minecraft:pink_terracotta
setblock 341 288 502 minecraft:red_nether_bricks
fill 341 288 503 344 288 503 minecraft:pink_terracotta
fill 342 288 502 345 288 502 minecraft:pink_terracotta
setblock 343 288 464 minecraft:pink_terracotta
setblock 343 288 465 minecraft:red_nether_bricks
setblock 344 288 464 minecraft:red_nether_bricks
fill 344 288 465 344 291 465 minecraft:pink_terracotta
setblock 344 288 504 minecraft:red_nether_bricks
fill 345 288 464 345 291 464 minecraft:pink_terracotta
setblock 345 288 503 minecraft:red_nether_bricks
fill 345 288 504 348 288 504 minecraft:pink_terracotta
setblock 346 288 502 minecraft:red_nether_bricks
fill 346 288 503 349 288 503 minecraft:pink_terracotta
setblock 347 288 502 minecraft:pink_terracotta
setblock 349 288 464 minecraft:red_nether_bricks
setblock 349 288 504 minecraft:red_nether_bricks
fill 350 288 504 352 288 504 minecraft:pink_terracotta
setblock 354 288 464 minecraft:white_concrete
setblock 359 288 464 minecraft:red_nether_bricks
fill 360 288 464 363 288 464 minecraft:pink_terracotta
fill 360 288 504 363 288 504 minecraft:pink_terracotta
setblock 362 288 465 minecraft:pink_terracotta
setblock 363 288 465 minecraft:red_nether_bricks
setblock 364 288 464 minecraft:red_nether_bricks
fill 364 288 465 364 291 465 minecraft:pink_terracotta
setblock 364 288 503 minecraft:pink_terracotta
setblock 364 288 504 minecraft:red_nether_bricks
fill 365 288 464 365 291 464 minecraft:pink_terracotta
setblock 365 288 503 minecraft:red_nether_bricks
fill 365 288 504 365 291 504 minecraft:pink_terracotta
setblock 368 288 465 minecraft:red_nether_bricks
setblock 368 288 481 minecraft:pink_terracotta
setblock 369 288 464 minecraft:red_nether_bricks
fill 369 288 465 369 291 465 minecraft:pink_terracotta
setblock 369 288 479 minecraft:red_nether_bricks
setblock 369 288 480 minecraft:pink_terracotta
setblock 369 288 484 minecraft:red_nether_bricks
setblock 369 288 485 minecraft:pink_terracotta
setblock 369 288 504 minecraft:red_nether_bricks
fill 370 288 464 370 291 464 minecraft:pink_terracotta
setblock 370 288 467 minecraft:pink_terracotta
setblock 370 288 468 minecraft:red_nether_bricks
fill 370 288 469 370 288 472 minecraft:pink_terracotta
setblock 370 288 478 minecraft:red_nether_bricks
fill 370 288 479 370 289 479 minecraft:pink_terracotta
setblock 370 288 483 minecraft:red_nether_bricks
fill 370 288 484 370 291 484 minecraft:pink_terracotta
setblock 370 288 492 minecraft:white_concrete
setblock 370 288 503 minecraft:red_nether_bricks
fill 370 288 504 370 289 504 minecraft:pink_terracotta
fill 330 289 464 330 289 466 minecraft:pink_terracotta
setblock 330 289 467 minecraft:red_nether_bricks
fill 330 289 468 330 292 468 minecraft:pink_terracotta
setblock 330 289 482 minecraft:white_concrete
setblock 330 289 502 minecraft:red_nether_bricks
fill 330 289 503 330 291 504 minecraft:pink_terracotta
fill 331 289 504 332 289 504 minecraft:pink_terracotta
setblock 332 289 464 minecraft:pink_terracotta
setblock 333 289 464 minecraft:red_nether_bricks
setblock 333 289 504 minecraft:red_nether_bricks
fill 334 289 464 337 289 464 minecraft:pink_terracotta
fill 334 289 504 337 289 504 minecraft:pink_terracotta
fill 336 289 502 336 290 502 minecraft:white_concrete
fill 336 289 503 338 289 503 minecraft:pink_terracotta
fill 337 289 501 337 290 501 minecraft:white_concrete
setblock 338 289 464 minecraft:red_nether_bricks
setblock 338 289 504 minecraft:red_nether_bricks
fill 339 289 464 341 289 465 minecraft:pink_terracotta
fill 339 289 501 339 290 501 minecraft:white_concrete
setblock 339 289 503 minecraft:red_nether_bricks
fill 339 289 504 342 289 504 minecraft:pink_terracotta
setblock 340 289 502 minecraft:red_nether_bricks
fill 340 289 503 343 289 503 minecraft:pink_terracotta
fill 341 289 502 344 289 502 minecraft:pink_terracotta
setblock 342 289 464 minecraft:pink_terracotta
setblock 342 289 465 minecraft:red_nether_bricks
setblock 343 289 464 minecraft:red_nether_bricks
fill 343 289 465 343 292 465 minecraft:pink_terracotta
setblock 343 289 504 minecraft:red_nether_bricks
fill 344 289 464 344 292 464 minecraft:pink_terracotta
setblock 344 289 503 minecraft:red_nether_bricks
fill 344 289 504 347 289 504 minecraft:pink_terracotta
setblock 345 289 502 minecraft:red_nether_bricks
fill 345 289 503 348 289 503 minecraft:pink_terracotta
setblock 348 289 464 minecraft:red_nether_bricks
setblock 348 289 504 minecraft:red_nether_bricks
setblock 349 289 464 minecraft:pink_terracotta
fill 349 289 504 350 290 504 minecraft:pink_terracotta
setblock 352 289 504 minecraft:white_concrete
fill 359 289 464 362 289 464 minecraft:pink_terracotta
fill 360 289 504 362 289 504 minecraft:pink_terracotta
setblock 361 289 465 minecraft:pink_terracotta
setblock 362 289 465 minecraft:red_nether_bricks
setblock 363 289 464 minecraft:red_nether_bricks
fill 363 289 465 363 292 465 minecraft:pink_terracotta
setblock 363 289 504 minecraft:red_nether_bricks
fill 364 289 464 364 292 464 minecraft:pink_terracotta
fill 364 289 504 364 292 504 minecraft:pink_terracotta
schedule function dropper:buildpart/115_10 1t
