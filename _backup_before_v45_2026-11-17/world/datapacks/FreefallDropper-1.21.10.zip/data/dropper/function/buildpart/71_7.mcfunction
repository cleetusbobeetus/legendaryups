fill 536 279 294 536 280 294 minecraft:white_concrete
fill 536 279 296 536 279 298 minecraft:white_concrete
fill 536 279 300 536 279 302 minecraft:white_concrete
fill 536 279 304 538 279 304 minecraft:orange_terracotta
setblock 536 279 305 minecraft:red_concrete
fill 536 279 306 538 279 306 minecraft:orange_terracotta
fill 536 279 308 543 279 308 minecraft:orange_terracotta
fill 536 279 309 542 279 309 minecraft:white_concrete
setblock 536 279 312 minecraft:white_wool
fill 536 279 313 538 279 313 minecraft:snow_block
setblock 536 279 316 minecraft:white_wool
fill 537 279 276 537 279 278 minecraft:snow_block
setblock 537 279 279 minecraft:white_wool
fill 537 279 280 537 279 282 minecraft:snow_block
setblock 537 279 283 minecraft:white_wool
fill 537 279 284 539 279 284 minecraft:snow_block
setblock 537 279 287 minecraft:white_wool
fill 537 279 288 538 279 288 minecraft:snow_block
fill 537 279 291 541 279 291 minecraft:white_concrete
fill 537 279 294 541 279 294 minecraft:orange_terracotta
fill 537 279 296 538 279 296 minecraft:white_concrete
fill 537 279 302 538 279 302 minecraft:white_concrete
setblock 537 279 305 minecraft:orange_terracotta
fill 537 279 307 541 279 307 minecraft:white_concrete
setblock 537 279 311 minecraft:white_wool
fill 537 279 312 539 279 312 minecraft:snow_block
setblock 537 279 315 minecraft:white_wool
fill 537 279 316 539 279 316 minecraft:snow_block
fill 538 279 276 538 279 277 minecraft:snow_block
setblock 538 279 278 minecraft:white_wool
fill 538 279 279 538 279 281 minecraft:snow_block
setblock 538 279 282 minecraft:white_wool
fill 538 279 283 540 279 283 minecraft:snow_block
setblock 538 279 286 minecraft:white_wool
fill 538 279 287 540 279 287 minecraft:snow_block
fill 538 279 295 540 279 295 minecraft:white_concrete
fill 538 279 303 540 279 303 minecraft:white_concrete
setblock 538 279 305 minecraft:lime_concrete
setblock 538 279 310 minecraft:white_wool
fill 538 279 311 540 279 311 minecraft:snow_block
setblock 538 279 314 minecraft:white_wool
fill 538 279 315 540 279 315 minecraft:snow_block
setblock 539 279 276 minecraft:snow_block
setblock 539 279 277 minecraft:white_wool
fill 539 279 278 539 279 280 minecraft:snow_block
setblock 539 279 281 minecraft:white_wool
fill 539 279 282 541 279 282 minecraft:snow_block
setblock 539 279 285 minecraft:white_wool
fill 539 279 286 541 279 286 minecraft:snow_block
setblock 539 279 288 minecraft:orange_terracotta
setblock 539 279 304 minecraft:lime_concrete
setblock 539 279 306 minecraft:lime_concrete
setblock 539 279 310 minecraft:orange_terracotta
setblock 539 279 313 minecraft:white_wool
fill 539 279 314 541 279 314 minecraft:snow_block
setblock 540 279 276 minecraft:white_wool
fill 540 279 277 540 279 279 minecraft:snow_block
setblock 540 279 280 minecraft:white_wool
fill 540 279 281 542 279 281 minecraft:snow_block
setblock 540 279 284 minecraft:white_wool
fill 540 279 285 542 279 285 minecraft:snow_block
setblock 540 279 288 minecraft:white_wool
fill 540 279 296 542 279 296 minecraft:white_concrete
fill 540 279 302 542 279 302 minecraft:white_concrete
fill 540 279 304 542 279 304 minecraft:orange_terracotta
setblock 540 279 305 minecraft:lime_concrete
fill 540 279 306 542 279 306 minecraft:orange_terracotta
fill 540 279 310 541 279 310 minecraft:snow_block
setblock 540 279 312 minecraft:white_wool
fill 540 279 313 542 279 313 minecraft:snow_block
setblock 540 279 316 minecraft:white_wool
fill 541 279 276 541 279 278 minecraft:snow_block
setblock 541 279 279 minecraft:white_wool
fill 541 279 280 543 279 280 minecraft:snow_block
setblock 541 279 283 minecraft:white_wool
fill 541 279 284 543 279 284 minecraft:snow_block
setblock 541 279 287 minecraft:white_wool
fill 541 279 288 543 279 288 minecraft:snow_block
fill 541 279 295 545 279 295 minecraft:orange_terracotta
fill 541 279 303 545 279 303 minecraft:orange_terracotta
setblock 541 279 305 minecraft:orange_terracotta
setblock 541 279 311 minecraft:white_wool
fill 541 279 312 543 279 312 minecraft:snow_block
setblock 541 279 315 minecraft:white_wool
fill 541 279 316 543 279 316 minecraft:snow_block
fill 542 279 276 542 279 277 minecraft:snow_block
setblock 542 279 278 minecraft:white_wool
fill 542 279 279 544 279 279 minecraft:snow_block
setblock 542 279 282 minecraft:white_wool
fill 542 279 283 544 279 283 minecraft:snow_block
setblock 542 279 286 minecraft:white_wool
fill 542 279 287 544 279 287 minecraft:snow_block
fill 542 279 291 544 279 291 minecraft:orange_terracotta
fill 542 279 294 542 280 294 minecraft:white_concrete
fill 542 279 297 542 279 298 minecraft:white_concrete
fill 542 279 300 542 279 301 minecraft:white_concrete
setblock 542 279 305 minecraft:light_blue_concrete
fill 542 279 307 544 279 307 minecraft:orange_terracotta
setblock 542 279 310 minecraft:white_wool
fill 542 279 311 544 279 311 minecraft:snow_block
setblock 542 279 314 minecraft:white_wool
fill 542 279 315 544 279 315 minecraft:snow_block
setblock 543 279 276 minecraft:snow_block
setblock 543 279 277 minecraft:white_wool
fill 543 279 278 545 279 278 minecraft:snow_block
setblock 543 279 281 minecraft:white_wool
fill 543 279 282 545 279 282 minecraft:snow_block
setblock 543 279 285 minecraft:white_wool
fill 543 279 286 545 279 286 minecraft:snow_block
setblock 543 279 289 minecraft:orange_terracotta
setblock 543 279 292 minecraft:white_concrete
fill 543 279 294 544 279 294 minecraft:orange_terracotta
fill 543 279 296 546 279 297 minecraft:orange_terracotta
fill 543 279 298 543 279 300 minecraft:white_concrete
fill 543 279 301 546 279 302 minecraft:orange_terracotta
setblock 543 279 304 minecraft:light_blue_concrete
setblock 543 279 306 minecraft:light_blue_concrete
setblock 543 279 309 minecraft:orange_terracotta
fill 543 279 310 545 279 310 minecraft:snow_block
setblock 543 279 313 minecraft:white_wool
fill 543 279 314 545 279 314 minecraft:snow_block
setblock 544 279 276 minecraft:white_wool
fill 544 279 277 546 279 277 minecraft:snow_block
setblock 544 279 280 minecraft:white_wool
fill 544 279 281 546 279 281 minecraft:snow_block
setblock 544 279 284 minecraft:white_wool
fill 544 279 285 546 279 285 minecraft:snow_block
setblock 544 279 288 minecraft:white_wool
fill 544 279 289 546 279 289 minecraft:snow_block
setblock 544 279 290 minecraft:white_concrete
fill 544 279 292 545 279 292 minecraft:orange_terracotta
setblock 544 279 293 minecraft:white_concrete
fill 544 279 298 546 279 300 minecraft:orange_terracotta
setblock 544 279 304 minecraft:orange_terracotta
setblock 544 279 305 minecraft:light_blue_concrete
fill 544 279 306 545 279 306 minecraft:orange_terracotta
setblock 544 279 308 minecraft:white_concrete
fill 544 279 309 546 279 309 minecraft:snow_block
setblock 544 279 312 minecraft:white_wool
fill 544 279 313 546 279 313 minecraft:snow_block
setblock 544 279 316 minecraft:white_wool
fill 545 279 276 547 279 276 minecraft:snow_block
setblock 545 279 279 minecraft:white_wool
fill 545 279 280 547 279 280 minecraft:snow_block
setblock 545 279 283 minecraft:white_wool
fill 545 279 284 547 279 284 minecraft:snow_block
setblock 545 279 287 minecraft:white_wool
fill 545 279 288 547 279 288 minecraft:snow_block
setblock 545 279 290 minecraft:orange_terracotta
fill 545 279 291 546 279 291 minecraft:white_concrete
fill 545 279 293 546 279 293 minecraft:orange_terracotta
setblock 545 279 294 minecraft:white_concrete
setblock 545 279 304 minecraft:white_concrete
fill 545 279 305 546 279 305 minecraft:orange_terracotta
fill 545 279 307 546 279 307 minecraft:white_concrete
setblock 545 279 308 minecraft:orange_terracotta
setblock 545 279 311 minecraft:white_wool
fill 545 279 312 547 279 312 minecraft:snow_block
setblock 545 279 315 minecraft:white_wool
fill 545 279 316 547 279 316 minecraft:snow_block
setblock 546 279 278 minecraft:white_wool
fill 546 279 279 548 279 279 minecraft:snow_block
setblock 546 279 282 minecraft:white_wool
fill 546 279 283 548 279 283 minecraft:snow_block
setblock 546 279 286 minecraft:white_wool
fill 546 279 287 548 279 287 minecraft:snow_block
setblock 546 279 290 minecraft:white_wool
fill 546 279 292 547 279 292 minecraft:white_concrete
fill 546 279 294 547 279 294 minecraft:orange_terracotta
setblock 546 279 295 minecraft:white_concrete
setblock 546 279 303 minecraft:white_concrete
fill 546 279 304 547 279 304 minecraft:orange_terracotta
fill 546 279 306 547 279 306 minecraft:white_concrete
fill 546 279 308 547 279 308 minecraft:snow_block
setblock 546 279 310 minecraft:white_wool
fill 546 279 311 548 279 311 minecraft:snow_block
setblock 546 279 314 minecraft:white_wool
fill 546 279 315 548 279 315 minecraft:snow_block
setblock 547 279 277 minecraft:white_wool
fill 547 279 278 549 279 278 minecraft:snow_block
setblock 547 279 281 minecraft:white_wool
fill 547 279 282 549 279 282 minecraft:snow_block
setblock 547 279 285 minecraft:white_wool
fill 547 279 286 549 279 286 minecraft:snow_block
setblock 547 279 289 minecraft:white_wool
fill 547 279 290 548 279 291 minecraft:snow_block
setblock 547 279 293 minecraft:white_concrete
fill 547 279 295 548 279 296 minecraft:orange_terracotta
fill 547 279 297 547 279 301 minecraft:white_concrete
fill 547 279 302 548 279 303 minecraft:orange_terracotta
setblock 547 279 305 minecraft:white_concrete
fill 547 279 307 548 279 307 minecraft:snow_block
setblock 547 279 309 minecraft:white_wool
fill 547 279 310 549 279 310 minecraft:snow_block
setblock 547 279 313 minecraft:white_wool
fill 547 279 314 549 279 314 minecraft:snow_block
setblock 548 279 276 minecraft:white_wool
fill 548 279 277 550 279 277 minecraft:snow_block
setblock 548 279 280 minecraft:white_wool
fill 548 279 281 550 279 281 minecraft:snow_block
setblock 548 279 284 minecraft:white_wool
fill 548 279 285 550 279 285 minecraft:snow_block
setblock 548 279 288 minecraft:white_wool
fill 548 279 289 550 279 289 minecraft:snow_block
setblock 548 279 292 minecraft:white_wool
setblock 548 279 293 minecraft:orange_terracotta
setblock 548 279 294 minecraft:white_concrete
fill 548 279 297 548 279 301 minecraft:orange_terracotta
setblock 548 279 304 minecraft:white_concrete
setblock 548 279 305 minecraft:orange_terracotta
fill 548 279 306 549 279 306 minecraft:snow_block
setblock 548 279 308 minecraft:white_wool
fill 548 279 309 550 279 309 minecraft:snow_block
setblock 548 279 312 minecraft:white_wool
fill 548 279 313 550 279 313 minecraft:snow_block
setblock 548 279 316 minecraft:white_wool
fill 549 279 276 551 279 276 minecraft:snow_block
setblock 549 279 279 minecraft:white_wool
fill 549 279 280 551 279 280 minecraft:snow_block
setblock 549 279 283 minecraft:white_wool
fill 549 279 284 551 279 284 minecraft:snow_block
setblock 549 279 287 minecraft:white_wool
fill 549 279 288 551 279 288 minecraft:snow_block
setblock 549 279 290 minecraft:snow_block
setblock 549 279 291 minecraft:white_wool
fill 549 279 292 549 279 294 minecraft:snow_block
setblock 549 279 295 minecraft:orange_terracotta
fill 549 279 296 549 279 302 minecraft:white_concrete
setblock 549 279 303 minecraft:orange_terracotta
fill 549 279 304 550 279 305 minecraft:snow_block
setblock 549 279 307 minecraft:white_wool
fill 549 279 308 551 279 308 minecraft:snow_block
setblock 549 279 311 minecraft:white_wool
fill 549 279 312 551 279 312 minecraft:snow_block
setblock 549 279 315 minecraft:white_wool
fill 549 279 316 551 279 316 minecraft:snow_block
setblock 550 279 278 minecraft:white_wool
fill 550 279 279 552 279 279 minecraft:snow_block
setblock 550 279 282 minecraft:white_wool
fill 550 279 283 552 279 283 minecraft:snow_block
setblock 550 279 286 minecraft:white_wool
fill 550 279 287 552 279 287 minecraft:snow_block
setblock 550 279 290 minecraft:white_wool
fill 550 279 291 550 279 293 minecraft:snow_block
setblock 550 279 294 minecraft:white_wool
fill 550 279 295 550 279 297 minecraft:snow_block
setblock 550 279 298 minecraft:white_wool
setblock 550 279 299 minecraft:orange_terracotta
fill 550 279 300 550 279 301 minecraft:snow_block
setblock 550 279 302 minecraft:white_wool
fill 550 279 303 552 279 303 minecraft:snow_block
setblock 550 279 306 minecraft:white_wool
fill 550 279 307 552 279 307 minecraft:snow_block
setblock 550 279 310 minecraft:white_wool
fill 550 279 311 552 279 311 minecraft:snow_block
setblock 550 279 314 minecraft:white_wool
fill 550 279 315 552 279 315 minecraft:snow_block
setblock 551 279 277 minecraft:white_wool
fill 551 279 278 553 279 278 minecraft:snow_block
setblock 551 279 281 minecraft:white_wool
fill 551 279 282 553 279 282 minecraft:snow_block
setblock 551 279 285 minecraft:white_wool
fill 551 279 286 553 279 286 minecraft:snow_block
setblock 551 279 289 minecraft:white_wool
fill 551 279 290 551 279 292 minecraft:snow_block
setblock 551 279 293 minecraft:white_wool
fill 551 279 294 551 279 296 minecraft:snow_block
setblock 551 279 297 minecraft:white_wool
fill 551 279 298 551 279 300 minecraft:snow_block
setblock 551 279 301 minecraft:white_wool
fill 551 279 302 553 279 302 minecraft:snow_block
setblock 551 279 304 minecraft:snow_block
setblock 551 279 305 minecraft:white_wool
fill 551 279 306 553 279 306 minecraft:snow_block
setblock 551 279 309 minecraft:white_wool
fill 551 279 310 553 279 310 minecraft:snow_block
setblock 551 279 313 minecraft:white_wool
fill 551 279 314 553 279 314 minecraft:snow_block
setblock 552 279 276 minecraft:white_wool
fill 552 279 277 554 279 277 minecraft:snow_block
setblock 552 279 280 minecraft:white_wool
fill 552 279 281 554 279 281 minecraft:snow_block
setblock 552 279 284 minecraft:white_wool
fill 552 279 285 554 279 285 minecraft:snow_block
setblock 552 279 288 minecraft:white_wool
fill 552 279 289 552 279 291 minecraft:snow_block
setblock 552 279 292 minecraft:white_wool
fill 552 279 293 552 279 295 minecraft:snow_block
setblock 552 279 296 minecraft:white_wool
fill 552 279 297 552 279 299 minecraft:snow_block
setblock 552 279 300 minecraft:white_wool
fill 552 279 301 554 279 301 minecraft:snow_block
setblock 552 279 304 minecraft:white_wool
fill 552 279 305 554 279 305 minecraft:snow_block
setblock 552 279 308 minecraft:white_wool
fill 552 279 309 554 279 309 minecraft:snow_block
setblock 552 279 312 minecraft:white_wool
fill 552 279 313 554 279 313 minecraft:snow_block
setblock 552 279 316 minecraft:white_wool
fill 553 279 276 555 279 276 minecraft:snow_block
setblock 553 279 279 minecraft:white_wool
fill 553 279 280 555 279 280 minecraft:snow_block
setblock 553 279 283 minecraft:white_wool
fill 553 279 284 555 279 284 minecraft:snow_block
setblock 553 279 287 minecraft:white_wool
fill 553 279 288 553 279 290 minecraft:snow_block
setblock 553 279 291 minecraft:white_wool
fill 553 279 292 553 279 294 minecraft:snow_block
setblock 553 279 295 minecraft:white_wool
fill 553 279 296 553 279 298 minecraft:snow_block
setblock 553 279 299 minecraft:white_wool
fill 553 279 300 555 279 300 minecraft:snow_block
setblock 553 279 303 minecraft:white_wool
fill 553 279 304 555 279 304 minecraft:snow_block
setblock 553 279 307 minecraft:white_wool
fill 553 279 308 555 279 308 minecraft:snow_block
setblock 553 279 311 minecraft:white_wool
fill 553 279 312 555 279 312 minecraft:snow_block
setblock 553 279 315 minecraft:white_wool
fill 553 279 316 555 279 316 minecraft:snow_block
setblock 554 279 278 minecraft:white_wool
fill 554 279 279 556 279 279 minecraft:snow_block
setblock 554 279 282 minecraft:white_wool
fill 554 279 283 556 279 283 minecraft:snow_block
setblock 554 279 286 minecraft:white_wool
fill 554 279 287 554 279 289 minecraft:snow_block
setblock 554 279 290 minecraft:white_wool
fill 554 279 291 554 279 293 minecraft:snow_block
setblock 554 279 294 minecraft:white_wool
fill 554 279 295 554 279 297 minecraft:snow_block
setblock 554 279 298 minecraft:white_wool
fill 554 279 299 556 279 299 minecraft:snow_block
setblock 554 279 302 minecraft:white_wool
fill 554 279 303 556 279 303 minecraft:snow_block
setblock 554 279 306 minecraft:white_wool
fill 554 279 307 556 279 307 minecraft:snow_block
setblock 554 279 310 minecraft:white_wool
fill 554 279 311 556 279 311 minecraft:snow_block
setblock 554 279 314 minecraft:white_wool
fill 554 279 315 556 279 315 minecraft:snow_block
setblock 555 279 277 minecraft:white_wool
fill 555 279 278 557 279 278 minecraft:snow_block
setblock 555 279 281 minecraft:white_wool
fill 555 279 282 557 279 282 minecraft:snow_block
setblock 555 279 285 minecraft:white_wool
fill 555 279 286 555 279 288 minecraft:snow_block
setblock 555 279 289 minecraft:white_wool
fill 555 279 290 555 279 292 minecraft:snow_block
setblock 555 279 293 minecraft:white_wool
fill 555 279 294 555 279 296 minecraft:snow_block
setblock 555 279 297 minecraft:white_wool
fill 555 279 298 557 279 298 minecraft:snow_block
setblock 555 279 301 minecraft:white_wool
fill 555 279 302 557 279 302 minecraft:snow_block
setblock 555 279 305 minecraft:white_wool
fill 555 279 306 557 279 306 minecraft:snow_block
setblock 555 279 309 minecraft:white_wool
fill 555 279 310 557 279 310 minecraft:snow_block
setblock 555 279 313 minecraft:white_wool
fill 555 279 314 557 279 314 minecraft:snow_block
setblock 556 279 276 minecraft:white_wool
fill 556 279 277 558 279 277 minecraft:snow_block
setblock 556 279 280 minecraft:white_wool
fill 556 279 281 558 279 281 minecraft:snow_block
setblock 556 279 284 minecraft:white_wool
fill 556 279 285 556 279 287 minecraft:snow_block
setblock 556 279 288 minecraft:white_wool
fill 556 279 289 556 279 291 minecraft:snow_block
setblock 556 279 292 minecraft:white_wool
fill 556 279 293 556 279 295 minecraft:snow_block
setblock 556 279 296 minecraft:white_wool
fill 556 279 297 558 279 297 minecraft:snow_block
setblock 556 279 300 minecraft:white_wool
fill 556 279 301 558 279 301 minecraft:snow_block
setblock 556 279 304 minecraft:white_wool
fill 556 279 305 558 279 305 minecraft:snow_block
setblock 556 279 308 minecraft:white_wool
fill 556 279 309 558 279 309 minecraft:snow_block
setblock 556 279 312 minecraft:white_wool
fill 556 279 313 558 279 313 minecraft:snow_block
setblock 556 279 316 minecraft:white_wool
fill 557 279 276 558 279 276 minecraft:snow_block
setblock 557 279 279 minecraft:white_wool
fill 557 279 280 558 279 280 minecraft:snow_block
setblock 557 279 283 minecraft:white_wool
fill 557 279 284 557 279 286 minecraft:snow_block
setblock 557 279 287 minecraft:white_wool
fill 557 279 288 557 279 290 minecraft:snow_block
setblock 557 279 291 minecraft:white_wool
fill 557 279 292 557 279 294 minecraft:snow_block
setblock 557 279 295 minecraft:white_wool
fill 557 279 296 558 279 296 minecraft:snow_block
setblock 557 279 299 minecraft:white_wool
fill 557 279 300 558 279 300 minecraft:snow_block
setblock 557 279 303 minecraft:white_wool
fill 557 279 304 558 279 304 minecraft:snow_block
setblock 557 279 307 minecraft:white_wool
fill 557 279 308 558 279 308 minecraft:snow_block
setblock 557 279 311 minecraft:white_wool
fill 557 279 312 558 279 312 minecraft:snow_block
setblock 557 279 315 minecraft:white_wool
fill 557 279 316 558 279 316 minecraft:snow_block
setblock 558 279 278 minecraft:white_wool
setblock 558 279 279 minecraft:snow_block
setblock 558 279 282 minecraft:white_wool
fill 558 279 283 558 279 285 minecraft:snow_block
setblock 558 279 286 minecraft:white_wool
fill 558 279 287 558 279 289 minecraft:snow_block
setblock 558 279 290 minecraft:white_wool
fill 558 279 291 558 279 293 minecraft:snow_block
setblock 558 279 294 minecraft:white_wool
setblock 558 279 295 minecraft:snow_block
setblock 558 279 298 minecraft:white_wool
setblock 558 279 299 minecraft:snow_block
setblock 558 279 302 minecraft:white_wool
setblock 558 279 303 minecraft:snow_block
setblock 558 279 306 minecraft:white_wool
setblock 558 279 307 minecraft:snow_block
setblock 558 279 310 minecraft:white_wool
setblock 558 279 311 minecraft:snow_block
setblock 558 279 314 minecraft:white_wool
setblock 558 279 315 minecraft:snow_block
setblock 517 283 277 minecraft:white_concrete
setblock 517 283 281 minecraft:white_concrete
fill 517 283 285 525 283 285 minecraft:white_concrete
fill 517 283 289 525 283 289 minecraft:white_concrete
setblock 517 283 293 minecraft:white_concrete
setblock 517 283 297 minecraft:white_concrete
setblock 517 283 301 minecraft:white_concrete
setblock 517 283 305 minecraft:white_concrete
setblock 517 283 309 minecraft:white_concrete
setblock 517 283 313 minecraft:white_concrete
setblock 517 283 317 minecraft:white_concrete
fill 518 283 276 520 300 276 minecraft:white_concrete
fill 518 283 284 525 284 284 minecraft:white_concrete
fill 518 283 286 525 285 288 minecraft:white_concrete
fill 518 283 290 525 285 290 minecraft:white_concrete
fill 518 283 298 518 300 300 minecraft:white_concrete
fill 518 283 310 518 300 312 minecraft:white_concrete
setblock 519 283 275 minecraft:white_concrete
fill 519 283 297 519 285 299 minecraft:white_concrete
fill 519 283 309 519 285 311 minecraft:white_concrete
setblock 519 283 317 minecraft:white_concrete
setblock 520 283 278 minecraft:light[level=12]
setblock 520 283 292 minecraft:light[level=12]
setblock 520 283 299 minecraft:light[level=12]
setblock 520 283 306 minecraft:light[level=12]
setblock 520 283 313 minecraft:light[level=12]
setblock 523 283 275 minecraft:white_concrete
setblock 523 283 317 minecraft:white_concrete
fill 524 283 316 526 300 316 minecraft:white_concrete
fill 525 283 315 527 285 315 minecraft:white_concrete
setblock 527 283 275 minecraft:white_concrete
setblock 527 283 278 minecraft:light[level=12]
setblock 527 283 285 minecraft:light[level=12]
setblock 527 283 292 minecraft:light[level=12]
setblock 527 283 299 minecraft:light[level=12]
setblock 527 283 306 minecraft:light[level=12]
setblock 527 283 313 minecraft:light[level=12]
setblock 527 283 317 minecraft:white_concrete
fill 529 283 277 531 285 277 minecraft:white_concrete
fill 530 283 276 532 300 276 minecraft:white_concrete
setblock 531 283 275 minecraft:white_concrete
setblock 531 283 317 minecraft:white_concrete
setblock 534 283 278 minecraft:light[level=12]
setblock 534 283 285 minecraft:light[level=12]
setblock 534 283 292 minecraft:light[level=12]
setblock 534 283 299 minecraft:light[level=12]
setblock 534 283 306 minecraft:light[level=12]
setblock 534 283 313 minecraft:light[level=12]
setblock 535 283 275 minecraft:white_concrete
setblock 535 283 317 minecraft:white_concrete
fill 536 283 316 538 300 316 minecraft:white_concrete
fill 537 283 315 539 285 315 minecraft:white_concrete
setblock 539 283 275 minecraft:white_concrete
setblock 539 283 317 minecraft:white_concrete
fill 541 283 277 543 285 277 minecraft:white_concrete
setblock 541 283 278 minecraft:light[level=12]
setblock 541 283 285 minecraft:light[level=12]
setblock 541 283 292 minecraft:light[level=12]
setblock 541 283 299 minecraft:light[level=12]
setblock 541 283 306 minecraft:light[level=12]
setblock 541 283 313 minecraft:light[level=12]
fill 542 283 276 544 300 276 minecraft:white_concrete
setblock 543 283 275 minecraft:white_concrete
setblock 543 283 317 minecraft:white_concrete
setblock 547 283 275 minecraft:white_concrete
setblock 547 283 317 minecraft:white_concrete
setblock 548 283 278 minecraft:light[level=12]
setblock 548 283 285 minecraft:light[level=12]
setblock 548 283 292 minecraft:light[level=12]
setblock 548 283 299 minecraft:light[level=12]
setblock 548 283 306 minecraft:light[level=12]
setblock 548 283 313 minecraft:light[level=12]
fill 548 283 316 550 300 316 minecraft:white_concrete
fill 549 283 315 551 285 315 minecraft:white_concrete
setblock 551 283 275 minecraft:white_concrete
setblock 551 283 280 minecraft:brown_terracotta
fill 551 283 290 553 283 290 minecraft:white_concrete
setblock 551 283 317 minecraft:white_concrete
setblock 552 283 279 minecraft:brown_terracotta
fill 552 283 280 555 300 280 minecraft:white_concrete
fill 552 283 281 552 283 282 minecraft:brown_terracotta
setblock 552 283 289 minecraft:white_concrete
fill 553 283 277 555 285 277 minecraft:white_concrete
fill 553 283 278 555 283 278 minecraft:brown_terracotta
fill 553 283 279 554 300 279 minecraft:white_concrete
fill 553 283 281 555 300 281 minecraft:white_concrete
fill 553 283 282 555 283 282 minecraft:brown_terracotta
fill 554 283 276 556 300 276 minecraft:white_concrete
setblock 555 283 275 minecraft:white_concrete
setblock 555 283 279 minecraft:brown_terracotta
setblock 555 283 285 minecraft:light[level=12]
setblock 555 283 292 minecraft:light[level=12]
setblock 555 283 299 minecraft:light[level=12]
setblock 555 283 306 minecraft:light[level=12]
setblock 555 283 313 minecraft:light[level=12]
setblock 555 283 317 minecraft:white_concrete
fill 556 283 280 556 283 281 minecraft:brown_terracotta
fill 557 283 285 557 285 287 minecraft:white_concrete
fill 557 283 297 557 285 299 minecraft:white_concrete
fill 557 283 309 557 285 311 minecraft:white_concrete
fill 558 283 284 558 300 286 minecraft:white_concrete
fill 558 283 296 558 296 298 minecraft:white_concrete
fill 558 283 308 558 300 310 minecraft:white_concrete
setblock 559 283 275 minecraft:white_concrete
setblock 559 283 277 minecraft:white_concrete
setblock 559 283 281 minecraft:white_concrete
setblock 559 283 285 minecraft:white_concrete
setblock 559 283 289 minecraft:white_concrete
setblock 559 283 293 minecraft:white_concrete
setblock 559 283 297 minecraft:white_concrete
setblock 559 283 301 minecraft:white_concrete
setblock 559 283 305 minecraft:white_concrete
setblock 559 283 309 minecraft:white_concrete
setblock 559 283 313 minecraft:white_concrete
setblock 559 283 317 minecraft:white_concrete
setblock 517 284 276 minecraft:white_concrete
fill 517 284 277 517 291 277 minecraft:brown_terracotta
setblock 517 284 278 minecraft:white_concrete
setblock 517 284 280 minecraft:white_concrete
fill 517 284 281 517 285 281 minecraft:brown_terracotta
setblock 517 284 282 minecraft:white_concrete
setblock 517 284 284 minecraft:white_concrete
fill 517 284 285 517 291 285 minecraft:brown_terracotta
setblock 517 284 286 minecraft:white_concrete
setblock 517 284 288 minecraft:white_concrete
fill 517 284 289 517 291 289 minecraft:brown_terracotta
setblock 517 284 290 minecraft:white_concrete
setblock 517 284 292 minecraft:white_concrete
fill 517 284 293 517 285 293 minecraft:brown_terracotta
setblock 517 284 294 minecraft:white_concrete
setblock 517 284 296 minecraft:white_concrete
fill 517 284 297 517 291 297 minecraft:brown_terracotta
setblock 517 284 298 minecraft:white_concrete
setblock 517 284 300 minecraft:white_concrete
fill 517 284 301 517 291 301 minecraft:brown_terracotta
setblock 517 284 302 minecraft:white_concrete
setblock 517 284 304 minecraft:white_concrete
fill 517 284 305 517 285 305 minecraft:brown_terracotta
setblock 517 284 306 minecraft:white_concrete
setblock 517 284 308 minecraft:white_concrete
fill 517 284 309 517 291 309 minecraft:brown_terracotta
setblock 517 284 310 minecraft:white_concrete
setblock 517 284 312 minecraft:white_concrete
fill 517 284 313 517 291 313 minecraft:brown_terracotta
setblock 517 284 314 minecraft:white_concrete
setblock 517 284 316 minecraft:white_concrete
setblock 517 284 317 minecraft:brown_terracotta
setblock 518 284 275 minecraft:white_concrete
fill 518 284 285 525 285 285 minecraft:white_concrete
fill 518 284 289 525 285 289 minecraft:white_concrete
setblock 518 284 317 minecraft:white_concrete
fill 519 284 275 519 291 275 minecraft:brown_terracotta
fill 519 284 317 519 285 317 minecraft:brown_terracotta
setblock 520 284 275 minecraft:white_concrete
setblock 520 284 317 minecraft:white_concrete
setblock 522 284 275 minecraft:white_concrete
setblock 522 284 317 minecraft:white_concrete
fill 523 284 275 523 291 275 minecraft:brown_terracotta
fill 523 284 317 523 291 317 minecraft:brown_terracotta
setblock 524 284 275 minecraft:white_concrete
setblock 524 284 317 minecraft:white_concrete
setblock 526 284 275 minecraft:white_concrete
fill 526 284 286 527 285 287 minecraft:red_concrete
setblock 526 284 317 minecraft:white_concrete
fill 527 284 275 527 285 275 minecraft:brown_terracotta
fill 527 284 317 527 291 317 minecraft:brown_terracotta
setblock 528 284 275 minecraft:white_concrete
fill 528 284 294 529 285 295 minecraft:white_concrete
setblock 528 284 317 minecraft:white_concrete
setblock 530 284 275 minecraft:white_concrete
setblock 530 284 317 minecraft:white_concrete
fill 531 284 275 531 291 275 minecraft:brown_terracotta
fill 531 284 317 531 285 317 minecraft:brown_terracotta
setblock 532 284 275 minecraft:white_concrete
setblock 532 284 317 minecraft:white_concrete
setblock 534 284 275 minecraft:white_concrete
setblock 534 284 317 minecraft:white_concrete
fill 535 284 275 535 291 275 minecraft:brown_terracotta
fill 535 284 317 535 291 317 minecraft:brown_terracotta
setblock 536 284 275 minecraft:white_concrete
setblock 536 284 317 minecraft:white_concrete
setblock 538 284 275 minecraft:white_concrete
setblock 538 284 317 minecraft:white_concrete
fill 539 284 275 539 285 275 minecraft:brown_terracotta
fill 539 284 317 539 291 317 minecraft:brown_terracotta
setblock 540 284 275 minecraft:white_concrete
setblock 540 284 317 minecraft:white_concrete
setblock 542 284 275 minecraft:white_concrete
setblock 542 284 317 minecraft:white_concrete
fill 543 284 275 543 291 275 minecraft:brown_terracotta
fill 543 284 317 543 285 317 minecraft:brown_terracotta
setblock 544 284 275 minecraft:white_concrete
setblock 544 284 317 minecraft:white_concrete
setblock 546 284 275 minecraft:white_concrete
setblock 546 284 317 minecraft:white_concrete
fill 547 284 275 547 291 275 minecraft:brown_terracotta
fill 547 284 317 547 291 317 minecraft:brown_terracotta
setblock 548 284 275 minecraft:white_concrete
setblock 548 284 317 minecraft:white_concrete
setblock 550 284 275 minecraft:white_concrete
setblock 550 284 317 minecraft:white_concrete
fill 551 284 275 551 285 275 minecraft:brown_terracotta
fill 551 284 317 551 291 317 minecraft:brown_terracotta
setblock 552 284 275 minecraft:white_concrete
setblock 552 284 317 minecraft:white_concrete
fill 553 284 306 553 285 307 minecraft:red_concrete
setblock 554 284 275 minecraft:white_concrete
setblock 554 284 317 minecraft:white_concrete
fill 555 284 275 555 291 275 minecraft:brown_terracotta
fill 555 284 317 555 285 317 minecraft:brown_terracotta
setblock 556 284 275 minecraft:white_concrete
setblock 556 284 317 minecraft:white_concrete
setblock 558 284 275 minecraft:white_concrete
setblock 558 284 317 minecraft:white_concrete
setblock 559 284 275 minecraft:brown_terracotta
setblock 559 284 276 minecraft:white_concrete
fill 559 284 277 559 285 277 minecraft:brown_terracotta
setblock 559 284 278 minecraft:white_concrete
setblock 559 284 280 minecraft:white_concrete
fill 559 284 281 559 291 281 minecraft:brown_terracotta
setblock 559 284 282 minecraft:white_concrete
setblock 559 284 284 minecraft:white_concrete
fill 559 284 285 559 291 285 minecraft:brown_terracotta
setblock 559 284 286 minecraft:white_concrete
setblock 559 284 288 minecraft:white_concrete
fill 559 284 289 559 285 289 minecraft:brown_terracotta
setblock 559 284 290 minecraft:white_concrete
setblock 559 284 292 minecraft:white_concrete
fill 559 284 293 559 291 293 minecraft:brown_terracotta
setblock 559 284 294 minecraft:white_concrete
setblock 559 284 296 minecraft:white_concrete
fill 559 284 297 559 291 297 minecraft:brown_terracotta
setblock 559 284 298 minecraft:white_concrete
setblock 559 284 300 minecraft:white_concrete
fill 559 284 301 559 285 301 minecraft:brown_terracotta
setblock 559 284 302 minecraft:white_concrete
setblock 559 284 304 minecraft:white_concrete
fill 559 284 305 559 291 305 minecraft:brown_terracotta
setblock 559 284 306 minecraft:white_concrete
setblock 559 284 308 minecraft:white_concrete
fill 559 284 309 559 291 309 minecraft:brown_terracotta
setblock 559 284 310 minecraft:white_concrete
setblock 559 284 312 minecraft:white_concrete
fill 559 284 313 559 285 313 minecraft:brown_terracotta
setblock 559 284 314 minecraft:white_concrete
setblock 559 284 316 minecraft:white_concrete
fill 559 284 317 559 291 317 minecraft:brown_terracotta
setblock 517 285 275 minecraft:white_concrete
fill 517 285 276 517 292 276 minecraft:brown_terracotta
fill 517 285 278 517 292 278 minecraft:brown_terracotta
setblock 517 285 279 minecraft:white_concrete
fill 517 285 280 518 285 280 minecraft:brown_terracotta
fill 517 285 282 518 285 282 minecraft:brown_terracotta
setblock 517 285 283 minecraft:white_concrete
fill 517 285 284 518 285 284 minecraft:brown_terracotta
fill 517 285 286 517 292 286 minecraft:brown_terracotta
setblock 517 285 287 minecraft:white_concrete
fill 517 285 288 517 292 288 minecraft:brown_terracotta
fill 517 285 290 517 292 290 minecraft:brown_terracotta
setblock 517 285 291 minecraft:white_concrete
fill 517 285 292 518 285 292 minecraft:brown_terracotta
fill 517 285 294 518 285 294 minecraft:brown_terracotta
setblock 517 285 295 minecraft:white_concrete
fill 517 285 296 518 285 296 minecraft:brown_terracotta
fill 517 285 298 517 292 298 minecraft:brown_terracotta
setblock 517 285 299 minecraft:white_concrete
fill 517 285 300 517 292 300 minecraft:brown_terracotta
fill 517 285 302 517 292 302 minecraft:brown_terracotta
setblock 517 285 303 minecraft:white_concrete
fill 517 285 304 518 285 304 minecraft:brown_terracotta
fill 517 285 306 518 285 306 minecraft:brown_terracotta
setblock 517 285 307 minecraft:white_concrete
fill 517 285 308 518 285 308 minecraft:brown_terracotta
fill 517 285 310 517 292 310 minecraft:brown_terracotta
setblock 517 285 311 minecraft:white_concrete
fill 517 285 312 517 292 312 minecraft:brown_terracotta
fill 517 285 314 517 292 314 minecraft:brown_terracotta
setblock 517 285 315 minecraft:white_concrete
fill 517 285 316 522 285 316 minecraft:brown_terracotta
setblock 517 285 317 minecraft:white_concrete
fill 518 285 275 518 292 275 minecraft:brown_terracotta
setblock 518 285 279 minecraft:brown_terracotta
setblock 518 285 281 minecraft:brown_terracotta
setblock 518 285 283 minecraft:brown_terracotta
setblock 518 285 291 minecraft:brown_terracotta
setblock 518 285 293 minecraft:brown_terracotta
setblock 518 285 295 minecraft:brown_terracotta
setblock 518 285 303 minecraft:brown_terracotta
setblock 518 285 305 minecraft:brown_terracotta
setblock 518 285 307 minecraft:brown_terracotta
setblock 518 285 315 minecraft:brown_terracotta
setblock 518 285 317 minecraft:brown_terracotta
fill 519 285 284 525 285 284 minecraft:white_concrete
fill 520 285 275 520 292 275 minecraft:brown_terracotta
setblock 520 285 278 minecraft:light[level=15]
setblock 520 285 294 minecraft:light[level=15]
setblock 520 285 302 minecraft:light[level=15]
setblock 520 285 310 minecraft:light[level=15]
setblock 520 285 317 minecraft:brown_terracotta
setblock 521 285 275 minecraft:white_concrete
setblock 521 285 317 minecraft:white_concrete
fill 522 285 275 522 285 276 minecraft:brown_terracotta
fill 522 285 317 522 292 317 minecraft:brown_terracotta
fill 523 285 276 527 285 276 minecraft:brown_terracotta
setblock 524 285 275 minecraft:brown_terracotta
fill 524 285 317 524 292 317 minecraft:brown_terracotta
setblock 525 285 275 minecraft:white_concrete
setblock 525 285 317 minecraft:white_concrete
setblock 526 285 275 minecraft:brown_terracotta
fill 526 285 317 526 292 317 minecraft:brown_terracotta
fill 528 285 275 528 292 275 minecraft:brown_terracotta
setblock 528 285 278 minecraft:light[level=15]
setblock 528 285 286 minecraft:light[level=15]
setblock 528 285 302 minecraft:light[level=15]
setblock 528 285 310 minecraft:light[level=15]
fill 528 285 317 528 292 317 minecraft:brown_terracotta
setblock 529 285 275 minecraft:white_concrete
fill 529 285 316 534 285 316 minecraft:brown_terracotta
setblock 529 285 317 minecraft:white_concrete
fill 530 285 275 530 292 275 minecraft:brown_terracotta
setblock 530 285 317 minecraft:brown_terracotta
fill 532 285 275 532 292 275 minecraft:brown_terracotta
setblock 532 285 317 minecraft:brown_terracotta
setblock 533 285 275 minecraft:white_concrete
setblock 533 285 317 minecraft:white_concrete
fill 534 285 275 534 285 276 minecraft:brown_terracotta
fill 534 285 317 534 292 317 minecraft:brown_terracotta
fill 535 285 276 539 285 276 minecraft:brown_terracotta
setblock 536 285 275 minecraft:brown_terracotta
setblock 536 285 278 minecraft:light[level=15]
setblock 536 285 286 minecraft:light[level=15]
setblock 536 285 294 minecraft:light[level=15]
setblock 536 285 302 minecraft:light[level=15]
setblock 536 285 310 minecraft:light[level=15]
fill 536 285 317 536 292 317 minecraft:brown_terracotta
setblock 537 285 275 minecraft:white_concrete
setblock 537 285 317 minecraft:white_concrete
setblock 538 285 275 minecraft:brown_terracotta
fill 538 285 317 538 292 317 minecraft:brown_terracotta
fill 540 285 275 540 292 275 minecraft:brown_terracotta
fill 540 285 317 540 292 317 minecraft:brown_terracotta
setblock 541 285 275 minecraft:white_concrete
fill 541 285 316 546 285 316 minecraft:brown_terracotta
setblock 541 285 317 minecraft:white_concrete
fill 542 285 275 542 292 275 minecraft:brown_terracotta
setblock 542 285 317 minecraft:brown_terracotta
fill 544 285 275 544 292 275 minecraft:brown_terracotta
setblock 544 285 278 minecraft:light[level=15]
setblock 544 285 286 minecraft:light[level=15]
setblock 544 285 294 minecraft:light[level=15]
setblock 544 285 302 minecraft:light[level=15]
setblock 544 285 310 minecraft:light[level=15]
setblock 544 285 317 minecraft:brown_terracotta
setblock 545 285 275 minecraft:white_concrete
setblock 545 285 317 minecraft:white_concrete
fill 546 285 275 546 285 276 minecraft:brown_terracotta
fill 546 285 317 546 292 317 minecraft:brown_terracotta
fill 547 285 276 551 285 276 minecraft:brown_terracotta
setblock 548 285 275 minecraft:brown_terracotta
fill 548 285 317 548 292 317 minecraft:brown_terracotta
setblock 549 285 275 minecraft:white_concrete
setblock 549 285 317 minecraft:white_concrete
setblock 550 285 275 minecraft:brown_terracotta
fill 550 285 317 550 292 317 minecraft:brown_terracotta
fill 552 285 275 552 292 275 minecraft:brown_terracotta
setblock 552 285 278 minecraft:light[level=15]
setblock 552 285 286 minecraft:light[level=15]
setblock 552 285 294 minecraft:light[level=15]
setblock 552 285 302 minecraft:light[level=15]
setblock 552 285 310 minecraft:light[level=15]
fill 552 285 317 552 292 317 minecraft:brown_terracotta
setblock 553 285 275 minecraft:white_concrete
fill 553 285 316 559 285 316 minecraft:brown_terracotta
setblock 553 285 317 minecraft:white_concrete
fill 554 285 275 554 292 275 minecraft:brown_terracotta
setblock 554 285 317 minecraft:brown_terracotta
fill 556 285 275 556 292 275 minecraft:brown_terracotta
setblock 556 285 317 minecraft:brown_terracotta
setblock 557 285 275 minecraft:white_concrete
setblock 557 285 317 minecraft:white_concrete
fill 558 285 275 558 285 281 minecraft:brown_terracotta
fill 558 285 288 558 285 293 minecraft:brown_terracotta
fill 558 285 300 558 285 305 minecraft:brown_terracotta
fill 558 285 312 558 285 315 minecraft:brown_terracotta
fill 558 285 317 558 292 317 minecraft:brown_terracotta
setblock 559 285 275 minecraft:white_concrete
setblock 559 285 276 minecraft:brown_terracotta
setblock 559 285 278 minecraft:brown_terracotta
setblock 559 285 279 minecraft:white_concrete
fill 559 285 280 559 292 280 minecraft:brown_terracotta
fill 559 285 282 559 292 282 minecraft:brown_terracotta
setblock 559 285 283 minecraft:white_concrete
fill 559 285 284 559 292 284 minecraft:brown_terracotta
fill 559 285 286 559 292 286 minecraft:brown_terracotta
setblock 559 285 287 minecraft:white_concrete
setblock 559 285 288 minecraft:brown_terracotta
setblock 559 285 290 minecraft:brown_terracotta
setblock 559 285 291 minecraft:white_concrete
fill 559 285 292 559 292 292 minecraft:brown_terracotta
fill 559 285 294 559 292 294 minecraft:brown_terracotta
setblock 559 285 295 minecraft:white_concrete
fill 559 285 296 559 292 296 minecraft:brown_terracotta
fill 559 285 298 559 292 298 minecraft:brown_terracotta
setblock 559 285 299 minecraft:white_concrete
setblock 559 285 300 minecraft:brown_terracotta
setblock 559 285 302 minecraft:brown_terracotta
setblock 559 285 303 minecraft:white_concrete
fill 559 285 304 559 292 304 minecraft:brown_terracotta
fill 559 285 306 559 292 306 minecraft:brown_terracotta
setblock 559 285 307 minecraft:white_concrete
fill 559 285 308 559 292 308 minecraft:brown_terracotta
fill 559 285 310 559 292 310 minecraft:brown_terracotta
setblock 559 285 311 minecraft:white_concrete
setblock 559 285 312 minecraft:brown_terracotta
setblock 559 285 314 minecraft:brown_terracotta
setblock 559 285 315 minecraft:white_concrete
fill 517 286 275 517 293 275 minecraft:brown_terracotta
fill 517 286 279 517 292 280 minecraft:brown_terracotta
fill 517 286 281 517 291 284 minecraft:shroomlight
fill 517 286 287 517 293 287 minecraft:brown_terracotta
fill 517 286 291 517 292 292 minecraft:brown_terracotta
fill 517 286 293 517 291 296 minecraft:shroomlight
fill 517 286 299 517 293 299 minecraft:brown_terracotta
fill 517 286 303 517 292 304 minecraft:brown_terracotta
fill 517 286 305 517 291 308 minecraft:shroomlight
fill 517 286 311 517 293 311 minecraft:brown_terracotta
fill 517 286 315 517 292 316 minecraft:brown_terracotta
fill 517 286 317 520 291 317 minecraft:shroomlight
setblock 518 286 284 minecraft:shroomlight
fill 518 286 285 518 300 285 minecraft:white_concrete
setblock 518 286 286 minecraft:shroomlight
fill 518 286 287 518 300 287 minecraft:white_concrete
setblock 518 286 288 minecraft:shroomlight
fill 518 286 289 518 300 289 minecraft:white_concrete
setblock 518 286 290 minecraft:shroomlight
fill 519 286 284 519 300 284 minecraft:white_concrete
setblock 519 286 285 minecraft:shroomlight
fill 519 286 286 519 300 286 minecraft:white_concrete
setblock 519 286 287 minecraft:shroomlight
fill 519 286 288 519 300 288 minecraft:white_concrete
setblock 519 286 289 minecraft:shroomlight
fill 519 286 290 519 300 290 minecraft:white_concrete
setblock 520 286 284 minecraft:shroomlight
fill 520 286 285 520 300 285 minecraft:white_concrete
setblock 520 286 286 minecraft:shroomlight
fill 520 286 287 520 300 287 minecraft:white_concrete
setblock 520 286 288 minecraft:shroomlight
fill 520 286 289 520 300 289 minecraft:white_concrete
setblock 520 286 290 minecraft:shroomlight
fill 521 286 275 522 292 275 minecraft:brown_terracotta
fill 521 286 284 521 300 284 minecraft:white_concrete
setblock 521 286 285 minecraft:shroomlight
fill 521 286 286 521 300 286 minecraft:white_concrete
setblock 521 286 287 minecraft:shroomlight
fill 521 286 288 521 300 288 minecraft:white_concrete
setblock 521 286 289 minecraft:shroomlight
fill 521 286 290 521 300 290 minecraft:white_concrete
fill 521 286 317 521 293 317 minecraft:brown_terracotta
setblock 522 286 284 minecraft:shroomlight
fill 522 286 285 522 300 285 minecraft:white_concrete
setblock 522 286 286 minecraft:shroomlight
fill 522 286 287 522 300 287 minecraft:white_concrete
setblock 522 286 288 minecraft:shroomlight
fill 522 286 289 522 300 289 minecraft:white_concrete
setblock 522 286 290 minecraft:shroomlight
fill 523 286 284 523 300 284 minecraft:white_concrete
setblock 523 286 285 minecraft:shroomlight
fill 523 286 286 523 300 286 minecraft:white_concrete
setblock 523 286 287 minecraft:shroomlight
fill 523 286 288 523 300 288 minecraft:white_concrete
setblock 523 286 289 minecraft:shroomlight
fill 523 286 290 523 300 290 minecraft:white_concrete
fill 524 286 275 527 291 275 minecraft:shroomlight
setblock 524 286 284 minecraft:shroomlight
fill 524 286 285 524 300 285 minecraft:white_concrete
setblock 524 286 286 minecraft:shroomlight
fill 524 286 287 524 300 287 minecraft:white_concrete
setblock 524 286 288 minecraft:shroomlight
fill 524 286 289 524 300 289 minecraft:white_concrete
setblock 524 286 290 minecraft:shroomlight
fill 525 286 284 525 300 284 minecraft:white_concrete
setblock 525 286 285 minecraft:shroomlight
fill 525 286 286 525 300 286 minecraft:white_concrete
setblock 525 286 287 minecraft:shroomlight
fill 525 286 288 525 300 288 minecraft:white_concrete
setblock 525 286 289 minecraft:shroomlight
fill 525 286 290 525 300 290 minecraft:white_concrete
fill 525 286 317 525 293 317 minecraft:brown_terracotta
fill 529 286 275 529 293 275 minecraft:brown_terracotta
fill 529 286 317 532 291 317 minecraft:shroomlight
fill 533 286 275 534 292 275 minecraft:brown_terracotta
fill 533 286 317 533 293 317 minecraft:brown_terracotta
fill 536 286 275 539 291 275 minecraft:shroomlight
fill 537 286 317 537 293 317 minecraft:brown_terracotta
fill 541 286 275 541 293 275 minecraft:brown_terracotta
fill 541 286 317 544 291 317 minecraft:shroomlight
fill 545 286 275 546 292 275 minecraft:brown_terracotta
fill 545 286 317 545 293 317 minecraft:brown_terracotta
fill 548 286 275 551 291 275 minecraft:shroomlight
fill 549 286 317 549 293 317 minecraft:brown_terracotta
fill 553 286 275 553 293 275 minecraft:brown_terracotta
fill 553 286 317 556 291 317 minecraft:shroomlight
fill 557 286 275 559 291 275 minecraft:brown_terracotta
fill 557 286 317 557 293 317 minecraft:brown_terracotta
fill 559 286 276 559 291 279 minecraft:shroomlight
fill 559 286 283 559 293 283 minecraft:brown_terracotta
fill 559 286 287 559 293 287 minecraft:brown_terracotta
fill 559 286 288 559 291 291 minecraft:shroomlight
fill 559 286 295 559 293 295 minecraft:brown_terracotta
fill 559 286 299 559 293 299 minecraft:brown_terracotta
fill 559 286 300 559 291 303 minecraft:shroomlight
fill 559 286 307 559 293 307 minecraft:brown_terracotta
fill 559 286 311 559 293 311 minecraft:brown_terracotta
fill 559 286 312 559 291 315 minecraft:shroomlight
fill 559 286 316 559 292 316 minecraft:brown_terracotta
fill 518 287 284 518 288 284 minecraft:white_concrete
fill 518 287 286 518 288 286 minecraft:white_concrete
fill 518 287 288 518 288 288 minecraft:white_concrete
fill 518 287 290 518 288 290 minecraft:white_concrete
fill 519 287 285 519 288 285 minecraft:white_concrete
fill 519 287 287 519 288 287 minecraft:white_concrete
fill 519 287 289 519 288 289 minecraft:white_concrete
fill 520 287 284 520 288 284 minecraft:white_concrete
fill 520 287 286 520 288 286 minecraft:white_concrete
fill 520 287 288 520 288 288 minecraft:white_concrete
fill 520 287 290 520 288 290 minecraft:white_concrete
fill 521 287 285 521 288 285 minecraft:white_concrete
fill 521 287 287 521 288 287 minecraft:white_concrete
fill 521 287 289 521 288 289 minecraft:white_concrete
fill 522 287 284 522 288 284 minecraft:white_concrete
fill 522 287 286 522 288 286 minecraft:white_concrete
fill 522 287 288 522 288 288 minecraft:white_concrete
fill 522 287 290 522 288 290 minecraft:white_concrete
fill 523 287 285 523 288 285 minecraft:white_concrete
fill 523 287 287 523 288 287 minecraft:white_concrete
fill 523 287 289 523 288 289 minecraft:white_concrete
fill 524 287 284 524 288 284 minecraft:white_concrete
fill 524 287 286 524 288 286 minecraft:white_concrete
fill 524 287 288 524 288 288 minecraft:white_concrete
fill 524 287 290 524 288 290 minecraft:white_concrete
fill 525 287 285 525 288 285 minecraft:white_concrete
fill 525 287 287 525 288 287 minecraft:white_concrete
fill 525 287 289 525 288 289 minecraft:white_concrete
fill 551 288 293 552 289 294 minecraft:red_concrete
fill 551 288 305 552 289 306 minecraft:red_concrete
setblock 518 289 284 minecraft:shroomlight
setblock 518 289 286 minecraft:shroomlight
setblock 518 289 288 minecraft:shroomlight
setblock 518 289 290 minecraft:shroomlight
setblock 519 289 285 minecraft:shroomlight
setblock 519 289 287 minecraft:shroomlight
setblock 519 289 289 minecraft:shroomlight
setblock 520 289 278 minecraft:light[level=12]
setblock 520 289 284 minecraft:shroomlight
setblock 520 289 286 minecraft:shroomlight
setblock 520 289 288 minecraft:shroomlight
setblock 520 289 290 minecraft:shroomlight
setblock 520 289 292 minecraft:light[level=12]
setblock 520 289 299 minecraft:light[level=12]
setblock 520 289 306 minecraft:light[level=12]
setblock 520 289 313 minecraft:light[level=12]
setblock 521 289 285 minecraft:shroomlight
setblock 521 289 287 minecraft:shroomlight
setblock 521 289 289 minecraft:shroomlight
setblock 522 289 284 minecraft:shroomlight
setblock 522 289 286 minecraft:shroomlight
setblock 522 289 288 minecraft:shroomlight
setblock 522 289 290 minecraft:shroomlight
setblock 523 289 285 minecraft:shroomlight
setblock 523 289 287 minecraft:shroomlight
setblock 523 289 289 minecraft:shroomlight
setblock 524 289 284 minecraft:shroomlight
setblock 524 289 286 minecraft:shroomlight
setblock 524 289 288 minecraft:shroomlight
setblock 524 289 290 minecraft:shroomlight
setblock 525 289 285 minecraft:shroomlight
setblock 525 289 287 minecraft:shroomlight
setblock 525 289 289 minecraft:shroomlight
setblock 527 289 278 minecraft:light[level=12]
setblock 527 289 285 minecraft:light[level=12]
setblock 527 289 292 minecraft:light[level=12]
setblock 527 289 299 minecraft:light[level=12]
setblock 527 289 306 minecraft:light[level=12]
setblock 527 289 313 minecraft:light[level=12]
setblock 534 289 278 minecraft:light[level=12]
setblock 534 289 285 minecraft:light[level=12]
setblock 534 289 292 minecraft:light[level=12]
setblock 534 289 299 minecraft:light[level=12]
setblock 534 289 306 minecraft:light[level=12]
setblock 534 289 313 minecraft:light[level=12]
setblock 541 289 278 minecraft:light[level=12]
setblock 541 289 285 minecraft:light[level=12]
setblock 541 289 292 minecraft:light[level=12]
setblock 541 289 299 minecraft:light[level=12]
setblock 541 289 306 minecraft:light[level=12]
setblock 541 289 313 minecraft:light[level=12]
setblock 548 289 278 minecraft:light[level=12]
setblock 548 289 285 minecraft:light[level=12]
setblock 548 289 292 minecraft:light[level=12]
setblock 548 289 299 minecraft:light[level=12]
setblock 548 289 306 minecraft:light[level=12]
setblock 548 289 313 minecraft:light[level=12]
setblock 555 289 278 minecraft:light[level=12]
setblock 555 289 285 minecraft:light[level=12]
setblock 555 289 292 minecraft:light[level=12]
setblock 555 289 299 minecraft:light[level=12]
setblock 555 289 306 minecraft:light[level=12]
setblock 555 289 313 minecraft:light[level=12]
fill 518 290 284 518 291 284 minecraft:white_concrete
fill 518 290 286 518 291 286 minecraft:white_concrete
fill 518 290 288 518 291 288 minecraft:white_concrete
fill 518 290 290 518 291 290 minecraft:white_concrete
fill 519 290 285 519 291 285 minecraft:white_concrete
fill 519 290 287 519 291 287 minecraft:white_concrete
fill 519 290 289 519 291 289 minecraft:white_concrete
fill 520 290 284 520 291 284 minecraft:white_concrete
fill 520 290 286 520 291 286 minecraft:white_concrete
fill 520 290 288 520 291 288 minecraft:white_concrete
fill 520 290 290 520 291 290 minecraft:white_concrete
fill 521 290 285 521 291 285 minecraft:white_concrete
fill 521 290 287 521 291 287 minecraft:white_concrete
fill 521 290 289 521 291 289 minecraft:white_concrete
fill 522 290 284 522 291 284 minecraft:white_concrete
fill 522 290 286 522 291 286 minecraft:white_concrete
fill 522 290 288 522 291 288 minecraft:white_concrete
fill 522 290 290 522 291 290 minecraft:white_concrete
fill 523 290 285 523 291 285 minecraft:white_concrete
fill 523 290 287 523 291 287 minecraft:white_concrete
fill 523 290 289 523 291 289 minecraft:white_concrete
fill 524 290 284 524 291 284 minecraft:white_concrete
fill 524 290 286 524 291 286 minecraft:white_concrete
fill 524 290 288 524 291 288 minecraft:white_concrete
fill 524 290 290 524 291 290 minecraft:white_concrete
fill 525 290 285 525 291 285 minecraft:white_concrete
fill 525 290 287 525 291 287 minecraft:white_concrete
fill 525 290 289 525 291 289 minecraft:white_concrete
fill 529 291 307 530 292 308 minecraft:lime_concrete
setblock 551 291 280 minecraft:brown_terracotta
setblock 552 291 279 minecraft:brown_terracotta
fill 552 291 281 552 291 282 minecraft:brown_terracotta
fill 553 291 278 555 291 278 minecraft:brown_terracotta
fill 553 291 282 555 291 282 minecraft:brown_terracotta
fill 553 291 296 553 294 296 minecraft:iron_block
setblock 555 291 279 minecraft:brown_terracotta
fill 556 291 280 556 291 281 minecraft:brown_terracotta
setblock 517 292 277 minecraft:white_concrete
setblock 517 292 281 minecraft:white_concrete
fill 517 292 282 517 292 283 minecraft:shroomlight
setblock 517 292 284 minecraft:brown_terracotta
setblock 517 292 285 minecraft:white_concrete
setblock 517 292 289 minecraft:white_concrete
setblock 517 292 293 minecraft:white_concrete
fill 517 292 294 517 292 295 minecraft:shroomlight
setblock 517 292 296 minecraft:brown_terracotta
setblock 517 292 297 minecraft:white_concrete
setblock 517 292 301 minecraft:white_concrete
setblock 517 292 305 minecraft:white_concrete
fill 517 292 306 517 292 307 minecraft:shroomlight
setblock 517 292 308 minecraft:brown_terracotta
setblock 517 292 309 minecraft:white_concrete
setblock 517 292 313 minecraft:white_concrete
setblock 517 292 317 minecraft:white_concrete
setblock 518 292 284 minecraft:shroomlight
setblock 518 292 286 minecraft:shroomlight
setblock 518 292 288 minecraft:shroomlight
setblock 518 292 290 minecraft:shroomlight
fill 518 292 317 519 292 317 minecraft:shroomlight
setblock 519 292 275 minecraft:white_concrete
setblock 519 292 285 minecraft:shroomlight
setblock 519 292 287 minecraft:shroomlight
setblock 519 292 289 minecraft:shroomlight
setblock 520 292 284 minecraft:shroomlight
setblock 520 292 286 minecraft:shroomlight
setblock 520 292 288 minecraft:shroomlight
setblock 520 292 290 minecraft:shroomlight
setblock 520 292 317 minecraft:brown_terracotta
setblock 521 292 285 minecraft:shroomlight
setblock 521 292 287 minecraft:shroomlight
setblock 521 292 289 minecraft:shroomlight
setblock 522 292 284 minecraft:shroomlight
setblock 522 292 286 minecraft:shroomlight
setblock 522 292 288 minecraft:shroomlight
setblock 522 292 290 minecraft:shroomlight
setblock 523 292 275 minecraft:white_concrete
setblock 523 292 285 minecraft:shroomlight
setblock 523 292 287 minecraft:shroomlight
setblock 523 292 289 minecraft:shroomlight
setblock 523 292 317 minecraft:white_concrete
setblock 524 292 275 minecraft:brown_terracotta
setblock 524 292 284 minecraft:shroomlight
setblock 524 292 286 minecraft:shroomlight
setblock 524 292 288 minecraft:shroomlight
setblock 524 292 290 minecraft:shroomlight
fill 525 292 275 526 292 275 minecraft:shroomlight
setblock 525 292 285 minecraft:shroomlight
setblock 525 292 287 minecraft:shroomlight
setblock 525 292 289 minecraft:shroomlight
setblock 527 292 275 minecraft:white_concrete
setblock 527 292 317 minecraft:white_concrete
fill 529 292 317 529 293 317 minecraft:brown_terracotta
fill 530 292 317 531 292 317 minecraft:shroomlight
setblock 531 292 275 minecraft:white_concrete
setblock 532 292 317 minecraft:brown_terracotta
setblock 535 292 275 minecraft:white_concrete
setblock 535 292 317 minecraft:white_concrete
setblock 536 292 275 minecraft:brown_terracotta
fill 537 292 275 538 292 275 minecraft:shroomlight
setblock 539 292 275 minecraft:white_concrete
setblock 539 292 317 minecraft:white_concrete
fill 541 292 317 541 293 317 minecraft:brown_terracotta
fill 542 292 317 543 292 317 minecraft:shroomlight
setblock 543 292 275 minecraft:white_concrete
setblock 544 292 317 minecraft:brown_terracotta
setblock 547 292 275 minecraft:white_concrete
setblock 547 292 317 minecraft:white_concrete
setblock 548 292 275 minecraft:brown_terracotta
fill 549 292 275 550 292 275 minecraft:shroomlight
setblock 551 292 275 minecraft:white_concrete
setblock 551 292 317 minecraft:white_concrete
fill 553 292 317 553 293 317 minecraft:brown_terracotta
fill 554 292 317 555 292 317 minecraft:shroomlight
setblock 555 292 275 minecraft:white_concrete
setblock 556 292 317 minecraft:brown_terracotta
fill 557 292 275 558 292 275 minecraft:brown_terracotta
setblock 559 292 275 minecraft:white_concrete
setblock 559 292 276 minecraft:brown_terracotta
fill 559 292 277 559 292 278 minecraft:shroomlight
fill 559 292 279 559 293 279 minecraft:brown_terracotta
setblock 559 292 281 minecraft:white_concrete
setblock 559 292 285 minecraft:white_concrete
setblock 559 292 288 minecraft:brown_terracotta
fill 559 292 289 559 292 290 minecraft:shroomlight
fill 559 292 291 559 293 291 minecraft:brown_terracotta
setblock 559 292 293 minecraft:white_concrete
setblock 559 292 297 minecraft:white_concrete
setblock 559 292 300 minecraft:brown_terracotta
fill 559 292 301 559 292 302 minecraft:shroomlight
fill 559 292 303 559 293 303 minecraft:brown_terracotta
setblock 559 292 305 minecraft:white_concrete
setblock 559 292 309 minecraft:white_concrete
setblock 559 292 312 minecraft:brown_terracotta
fill 559 292 313 559 292 314 minecraft:shroomlight
fill 559 292 315 559 293 315 minecraft:brown_terracotta
setblock 559 292 317 minecraft:white_concrete
setblock 517 293 276 minecraft:white_concrete
fill 517 293 277 517 300 277 minecraft:brown_terracotta
setblock 517 293 278 minecraft:white_concrete
setblock 517 293 279 minecraft:brown_terracotta
setblock 517 293 280 minecraft:white_concrete
fill 517 293 281 517 300 281 minecraft:brown_terracotta
setblock 517 293 282 minecraft:white_concrete
setblock 517 293 283 minecraft:brown_terracotta
fill 517 293 284 518 293 284 minecraft:white_concrete
fill 517 293 285 517 300 285 minecraft:brown_terracotta
fill 517 293 286 518 293 286 minecraft:white_concrete
fill 517 293 288 518 293 288 minecraft:white_concrete
fill 517 293 289 517 300 289 minecraft:brown_terracotta
fill 517 293 290 518 293 290 minecraft:white_concrete
setblock 517 293 291 minecraft:brown_terracotta
setblock 517 293 292 minecraft:white_concrete
fill 517 293 293 517 300 293 minecraft:brown_terracotta
setblock 517 293 294 minecraft:white_concrete
setblock 517 293 295 minecraft:brown_terracotta
setblock 517 293 296 minecraft:white_concrete
fill 517 293 297 517 300 297 minecraft:brown_terracotta
setblock 517 293 298 minecraft:white_concrete
setblock 517 293 300 minecraft:white_concrete
fill 517 293 301 517 300 301 minecraft:brown_terracotta
setblock 517 293 302 minecraft:white_concrete
setblock 517 293 303 minecraft:brown_terracotta
setblock 517 293 304 minecraft:white_concrete
fill 517 293 305 517 300 305 minecraft:brown_terracotta
setblock 517 293 306 minecraft:white_concrete
setblock 517 293 307 minecraft:brown_terracotta
setblock 517 293 308 minecraft:white_concrete
fill 517 293 309 517 300 309 minecraft:brown_terracotta
setblock 517 293 310 minecraft:white_concrete
setblock 517 293 312 minecraft:white_concrete
fill 517 293 313 517 300 313 minecraft:brown_terracotta
setblock 517 293 314 minecraft:white_concrete
setblock 517 293 315 minecraft:brown_terracotta
setblock 517 293 316 minecraft:white_concrete
setblock 517 293 317 minecraft:brown_terracotta
setblock 518 293 275 minecraft:white_concrete
setblock 518 293 317 minecraft:white_concrete
fill 519 293 275 519 300 275 minecraft:brown_terracotta
fill 519 293 285 519 294 285 minecraft:white_concrete
fill 519 293 287 519 294 287 minecraft:white_concrete
fill 519 293 289 519 294 289 minecraft:white_concrete
fill 519 293 317 519 300 317 minecraft:brown_terracotta
setblock 520 293 275 minecraft:white_concrete
setblock 520 293 278 minecraft:light[level=15]
fill 520 293 284 520 294 284 minecraft:white_concrete
fill 520 293 286 520 294 286 minecraft:white_concrete
fill 520 293 288 520 294 288 minecraft:white_concrete
fill 520 293 290 520 294 290 minecraft:white_concrete
setblock 520 293 294 minecraft:light[level=15]
setblock 520 293 302 minecraft:light[level=15]
setblock 520 293 310 minecraft:light[level=15]
setblock 520 293 317 minecraft:white_concrete
setblock 521 293 275 minecraft:brown_terracotta
fill 521 293 285 521 294 285 minecraft:white_concrete
fill 521 293 287 521 294 287 minecraft:white_concrete
fill 521 293 289 521 294 289 minecraft:white_concrete
setblock 522 293 275 minecraft:white_concrete
fill 522 293 284 522 294 284 minecraft:white_concrete
fill 522 293 286 522 294 286 minecraft:white_concrete
fill 522 293 288 522 294 288 minecraft:white_concrete
fill 522 293 290 522 294 290 minecraft:white_concrete
setblock 522 293 317 minecraft:white_concrete
fill 523 293 275 523 300 275 minecraft:brown_terracotta
fill 523 293 285 523 294 285 minecraft:white_concrete
fill 523 293 287 523 294 287 minecraft:white_concrete
fill 523 293 289 523 294 289 minecraft:white_concrete
fill 523 293 317 523 300 317 minecraft:brown_terracotta
setblock 524 293 275 minecraft:white_concrete
fill 524 293 284 524 294 284 minecraft:white_concrete
fill 524 293 286 524 294 286 minecraft:white_concrete
fill 524 293 288 524 294 288 minecraft:white_concrete
fill 524 293 290 524 294 290 minecraft:white_concrete
setblock 524 293 317 minecraft:white_concrete
setblock 525 293 275 minecraft:brown_terracotta
fill 525 293 285 525 294 285 minecraft:white_concrete
fill 525 293 287 525 294 287 minecraft:white_concrete
fill 525 293 289 525 294 289 minecraft:white_concrete
setblock 526 293 275 minecraft:white_concrete
setblock 526 293 317 minecraft:white_concrete
fill 527 293 275 527 300 275 minecraft:brown_terracotta
fill 527 293 317 527 300 317 minecraft:brown_terracotta
setblock 528 293 275 minecraft:white_concrete
setblock 528 293 278 minecraft:light[level=15]
setblock 528 293 286 minecraft:light[level=15]
setblock 528 293 294 minecraft:light[level=15]
setblock 528 293 302 minecraft:light[level=15]
setblock 528 293 310 minecraft:light[level=15]
setblock 528 293 317 minecraft:white_concrete
setblock 530 293 275 minecraft:white_concrete
setblock 530 293 317 minecraft:white_concrete
fill 531 293 275 531 300 275 minecraft:brown_terracotta
fill 531 293 317 531 300 317 minecraft:brown_terracotta
setblock 532 293 275 minecraft:white_concrete
setblock 532 293 317 minecraft:white_concrete
setblock 533 293 275 minecraft:brown_terracotta
setblock 534 293 275 minecraft:white_concrete
setblock 534 293 317 minecraft:white_concrete
fill 535 293 275 535 300 275 minecraft:brown_terracotta
fill 535 293 317 535 300 317 minecraft:brown_terracotta
setblock 536 293 275 minecraft:white_concrete
setblock 536 293 278 minecraft:light[level=15]
setblock 536 293 286 minecraft:light[level=15]
setblock 536 293 294 minecraft:light[level=15]
setblock 536 293 302 minecraft:light[level=15]
setblock 536 293 310 minecraft:light[level=15]
setblock 536 293 317 minecraft:white_concrete
setblock 537 293 275 minecraft:brown_terracotta
setblock 538 293 275 minecraft:white_concrete
setblock 538 293 317 minecraft:white_concrete
fill 539 293 275 539 300 275 minecraft:brown_terracotta
fill 539 293 317 539 300 317 minecraft:brown_terracotta
setblock 540 293 275 minecraft:white_concrete
setblock 540 293 317 minecraft:white_concrete
setblock 542 293 275 minecraft:white_concrete
setblock 542 293 317 minecraft:white_concrete
fill 543 293 275 543 300 275 minecraft:brown_terracotta
fill 543 293 317 543 300 317 minecraft:brown_terracotta
setblock 544 293 275 minecraft:white_concrete
setblock 544 293 278 minecraft:light[level=15]
setblock 544 293 286 minecraft:light[level=15]
setblock 544 293 294 minecraft:light[level=15]
setblock 544 293 302 minecraft:light[level=15]
setblock 544 293 310 minecraft:light[level=15]
setblock 544 293 317 minecraft:white_concrete
setblock 545 293 275 minecraft:brown_terracotta
setblock 546 293 275 minecraft:white_concrete
setblock 546 293 317 minecraft:white_concrete
fill 547 293 275 547 300 275 minecraft:brown_terracotta
fill 547 293 317 547 300 317 minecraft:brown_terracotta
setblock 548 293 275 minecraft:white_concrete
setblock 548 293 317 minecraft:white_concrete
setblock 549 293 275 minecraft:brown_terracotta
setblock 550 293 275 minecraft:white_concrete
setblock 550 293 317 minecraft:white_concrete
fill 551 293 275 551 300 275 minecraft:brown_terracotta
fill 551 293 317 551 300 317 minecraft:brown_terracotta
setblock 552 293 275 minecraft:white_concrete
setblock 552 293 278 minecraft:light[level=15]
setblock 552 293 286 minecraft:light[level=15]
setblock 552 293 294 minecraft:light[level=15]
setblock 552 293 302 minecraft:light[level=15]
setblock 552 293 310 minecraft:light[level=15]
setblock 552 293 317 minecraft:white_concrete
setblock 554 293 275 minecraft:white_concrete
setblock 554 293 317 minecraft:white_concrete
fill 555 293 275 555 300 275 minecraft:brown_terracotta
fill 555 293 317 555 300 317 minecraft:brown_terracotta
setblock 556 293 275 minecraft:white_concrete
setblock 556 293 317 minecraft:white_concrete
setblock 557 293 275 minecraft:brown_terracotta
setblock 558 293 275 minecraft:white_concrete
setblock 558 293 317 minecraft:white_concrete
setblock 559 293 275 minecraft:brown_terracotta
setblock 559 293 276 minecraft:white_concrete
fill 559 293 277 559 300 277 minecraft:brown_terracotta
setblock 559 293 278 minecraft:white_concrete
setblock 559 293 280 minecraft:white_concrete
fill 559 293 281 559 300 281 minecraft:brown_terracotta
setblock 559 293 282 minecraft:white_concrete
setblock 559 293 284 minecraft:white_concrete
fill 559 293 285 559 300 285 minecraft:brown_terracotta
setblock 559 293 286 minecraft:white_concrete
setblock 559 293 288 minecraft:white_concrete
fill 559 293 289 559 300 289 minecraft:brown_terracotta
setblock 559 293 290 minecraft:white_concrete
setblock 559 293 292 minecraft:white_concrete
fill 559 293 293 559 300 293 minecraft:brown_terracotta
setblock 559 293 294 minecraft:white_concrete
setblock 559 293 296 minecraft:white_concrete
fill 559 293 297 559 300 297 minecraft:brown_terracotta
setblock 559 293 298 minecraft:white_concrete
setblock 559 293 300 minecraft:white_concrete
fill 559 293 301 559 300 301 minecraft:brown_terracotta
setblock 559 293 302 minecraft:white_concrete
setblock 559 293 304 minecraft:white_concrete
fill 559 293 305 559 300 305 minecraft:brown_terracotta
setblock 559 293 306 minecraft:white_concrete
setblock 559 293 308 minecraft:white_concrete
fill 559 293 309 559 300 309 minecraft:brown_terracotta
setblock 559 293 310 minecraft:white_concrete
setblock 559 293 312 minecraft:white_concrete
fill 559 293 313 559 300 313 minecraft:brown_terracotta
setblock 559 293 314 minecraft:white_concrete
setblock 559 293 316 minecraft:white_concrete
fill 559 293 317 559 300 317 minecraft:brown_terracotta
setblock 517 294 275 minecraft:white_concrete
fill 517 294 276 517 301 276 minecraft:brown_terracotta
fill 517 294 278 517 301 278 minecraft:brown_terracotta
setblock 517 294 279 minecraft:white_concrete
fill 517 294 280 517 301 280 minecraft:brown_terracotta
fill 517 294 282 517 301 282 minecraft:brown_terracotta
setblock 517 294 283 minecraft:white_concrete
fill 517 294 284 517 301 284 minecraft:brown_terracotta
fill 517 294 286 517 301 286 minecraft:brown_terracotta
setblock 517 294 287 minecraft:white_concrete
fill 517 294 288 517 301 288 minecraft:brown_terracotta
fill 517 294 290 517 301 290 minecraft:brown_terracotta
setblock 517 294 291 minecraft:white_concrete
fill 517 294 292 517 301 292 minecraft:brown_terracotta
fill 517 294 294 517 301 294 minecraft:brown_terracotta
setblock 517 294 295 minecraft:white_concrete
fill 517 294 296 517 301 296 minecraft:brown_terracotta
fill 517 294 298 517 301 298 minecraft:brown_terracotta
setblock 517 294 299 minecraft:white_concrete
fill 517 294 300 517 301 300 minecraft:brown_terracotta
fill 517 294 302 517 301 302 minecraft:brown_terracotta
setblock 517 294 303 minecraft:white_concrete
fill 517 294 304 517 301 304 minecraft:brown_terracotta
fill 517 294 306 517 301 306 minecraft:brown_terracotta
setblock 517 294 307 minecraft:white_concrete
fill 517 294 308 517 301 308 minecraft:brown_terracotta
fill 517 294 310 517 301 310 minecraft:brown_terracotta
setblock 517 294 311 minecraft:white_concrete
fill 517 294 312 517 301 312 minecraft:brown_terracotta
fill 517 294 314 517 301 314 minecraft:brown_terracotta
setblock 517 294 315 minecraft:white_concrete
fill 517 294 316 517 301 316 minecraft:brown_terracotta
setblock 517 294 317 minecraft:white_concrete
fill 518 294 275 518 301 275 minecraft:brown_terracotta
setblock 518 294 284 minecraft:white_concrete
setblock 518 294 286 minecraft:white_concrete
setblock 518 294 288 minecraft:white_concrete
setblock 518 294 290 minecraft:white_concrete
fill 518 294 317 518 301 317 minecraft:brown_terracotta
fill 520 294 275 520 301 275 minecraft:brown_terracotta
fill 520 294 317 520 301 317 minecraft:brown_terracotta
setblock 521 294 275 minecraft:white_concrete
setblock 521 294 317 minecraft:white_concrete
fill 522 294 275 522 301 275 minecraft:brown_terracotta
fill 522 294 317 522 301 317 minecraft:brown_terracotta
fill 524 294 275 524 301 275 minecraft:brown_terracotta
fill 524 294 317 524 301 317 minecraft:brown_terracotta
setblock 525 294 275 minecraft:white_concrete
setblock 525 294 317 minecraft:white_concrete
fill 526 294 275 526 301 275 minecraft:brown_terracotta
fill 526 294 317 526 301 317 minecraft:brown_terracotta
fill 528 294 275 528 301 275 minecraft:brown_terracotta
fill 528 294 317 528 301 317 minecraft:brown_terracotta
setblock 529 294 275 minecraft:white_concrete
setblock 529 294 317 minecraft:white_concrete
fill 530 294 275 530 301 275 minecraft:brown_terracotta
fill 530 294 317 530 301 317 minecraft:brown_terracotta
fill 532 294 275 532 301 275 minecraft:brown_terracotta
fill 532 294 317 532 301 317 minecraft:brown_terracotta
setblock 533 294 275 minecraft:white_concrete
setblock 533 294 317 minecraft:white_concrete
fill 534 294 275 534 301 275 minecraft:brown_terracotta
fill 534 294 317 534 301 317 minecraft:brown_terracotta
fill 536 294 275 536 301 275 minecraft:brown_terracotta
fill 536 294 317 536 301 317 minecraft:brown_terracotta
setblock 537 294 275 minecraft:white_concrete
setblock 537 294 317 minecraft:white_concrete
fill 538 294 275 538 301 275 minecraft:brown_terracotta
fill 538 294 317 538 301 317 minecraft:brown_terracotta
fill 540 294 275 540 301 275 minecraft:brown_terracotta
fill 540 294 317 540 301 317 minecraft:brown_terracotta
setblock 541 294 275 minecraft:white_concrete
setblock 541 294 317 minecraft:white_concrete
fill 542 294 275 542 301 275 minecraft:brown_terracotta
fill 542 294 317 542 301 317 minecraft:brown_terracotta
fill 544 294 275 544 301 275 minecraft:brown_terracotta
fill 544 294 317 544 301 317 minecraft:brown_terracotta
setblock 545 294 275 minecraft:white_concrete
setblock 545 294 317 minecraft:white_concrete
fill 546 294 275 546 301 275 minecraft:brown_terracotta
fill 546 294 317 546 301 317 minecraft:brown_terracotta
fill 548 294 275 548 301 275 minecraft:brown_terracotta
fill 548 294 317 548 301 317 minecraft:brown_terracotta
setblock 549 294 275 minecraft:white_concrete
setblock 549 294 317 minecraft:white_concrete
fill 550 294 275 550 301 275 minecraft:brown_terracotta
fill 550 294 317 550 301 317 minecraft:brown_terracotta
fill 552 294 275 552 301 275 minecraft:brown_terracotta
fill 552 294 317 552 301 317 minecraft:brown_terracotta
setblock 553 294 275 minecraft:white_concrete
setblock 553 294 317 minecraft:white_concrete
fill 554 294 275 554 301 275 minecraft:brown_terracotta
fill 554 294 317 554 301 317 minecraft:brown_terracotta
fill 556 294 275 556 301 275 minecraft:brown_terracotta
fill 556 294 317 556 301 317 minecraft:brown_terracotta
setblock 557 294 275 minecraft:white_concrete
setblock 557 294 317 minecraft:white_concrete
fill 558 294 275 558 301 275 minecraft:brown_terracotta
fill 558 294 317 558 301 317 minecraft:brown_terracotta
setblock 559 294 275 minecraft:white_concrete
fill 559 294 276 559 301 276 minecraft:brown_terracotta
fill 559 294 278 559 301 278 minecraft:brown_terracotta
setblock 559 294 279 minecraft:white_concrete
fill 559 294 280 559 301 280 minecraft:brown_terracotta
fill 559 294 282 559 301 282 minecraft:brown_terracotta
setblock 559 294 283 minecraft:white_concrete
fill 559 294 284 559 301 284 minecraft:brown_terracotta
fill 559 294 286 559 301 286 minecraft:brown_terracotta
setblock 559 294 287 minecraft:white_concrete
fill 559 294 288 559 301 288 minecraft:brown_terracotta
fill 559 294 290 559 301 290 minecraft:brown_terracotta
setblock 559 294 291 minecraft:white_concrete
fill 559 294 292 559 301 292 minecraft:brown_terracotta
fill 559 294 294 559 301 294 minecraft:brown_terracotta
setblock 559 294 295 minecraft:white_concrete
fill 559 294 296 559 301 296 minecraft:brown_terracotta
fill 559 294 298 559 301 298 minecraft:brown_terracotta
setblock 559 294 299 minecraft:white_concrete
fill 559 294 300 559 301 300 minecraft:brown_terracotta
fill 559 294 302 559 301 302 minecraft:brown_terracotta
setblock 559 294 303 minecraft:white_concrete
fill 559 294 304 559 301 304 minecraft:brown_terracotta
fill 559 294 306 559 301 306 minecraft:brown_terracotta
setblock 559 294 307 minecraft:white_concrete
fill 559 294 308 559 301 308 minecraft:brown_terracotta
fill 559 294 310 559 301 310 minecraft:brown_terracotta
setblock 559 294 311 minecraft:white_concrete
fill 559 294 312 559 301 312 minecraft:brown_terracotta
fill 559 294 314 559 301 314 minecraft:brown_terracotta
setblock 559 294 315 minecraft:white_concrete
fill 559 294 316 559 301 316 minecraft:brown_terracotta
fill 517 295 275 517 302 275 minecraft:brown_terracotta
fill 517 295 279 517 302 279 minecraft:brown_terracotta
fill 517 295 283 517 302 283 minecraft:brown_terracotta
fill 517 295 287 517 302 287 minecraft:brown_terracotta
fill 517 295 291 517 302 291 minecraft:brown_terracotta
fill 517 295 295 517 302 295 minecraft:brown_terracotta
fill 517 295 299 517 302 299 minecraft:brown_terracotta
fill 517 295 303 517 302 303 minecraft:brown_terracotta
fill 517 295 307 517 302 307 minecraft:brown_terracotta
fill 517 295 311 517 302 311 minecraft:brown_terracotta
fill 517 295 315 517 302 315 minecraft:brown_terracotta
fill 517 295 317 517 300 317 minecraft:brown_terracotta
setblock 518 295 284 minecraft:shroomlight
setblock 518 295 286 minecraft:shroomlight
setblock 518 295 288 minecraft:shroomlight
setblock 518 295 290 minecraft:shroomlight
setblock 519 295 285 minecraft:shroomlight
setblock 519 295 287 minecraft:shroomlight
setblock 519 295 289 minecraft:shroomlight
setblock 520 295 278 minecraft:light[level=12]
setblock 520 295 284 minecraft:shroomlight
setblock 520 295 286 minecraft:shroomlight
setblock 520 295 288 minecraft:shroomlight
setblock 520 295 290 minecraft:shroomlight
setblock 520 295 292 minecraft:light[level=12]
setblock 520 295 299 minecraft:light[level=12]
setblock 520 295 306 minecraft:light[level=12]
setblock 520 295 313 minecraft:light[level=12]
fill 521 295 275 521 302 275 minecraft:brown_terracotta
setblock 521 295 285 minecraft:shroomlight
setblock 521 295 287 minecraft:shroomlight
setblock 521 295 289 minecraft:shroomlight
fill 521 295 317 521 302 317 minecraft:brown_terracotta
setblock 522 295 284 minecraft:shroomlight
setblock 522 295 286 minecraft:shroomlight
setblock 522 295 288 minecraft:shroomlight
setblock 522 295 290 minecraft:shroomlight
setblock 523 295 285 minecraft:shroomlight
setblock 523 295 287 minecraft:shroomlight
setblock 523 295 289 minecraft:shroomlight
setblock 524 295 284 minecraft:shroomlight
setblock 524 295 286 minecraft:shroomlight
setblock 524 295 288 minecraft:shroomlight
setblock 524 295 290 minecraft:shroomlight
fill 525 295 275 525 302 275 minecraft:brown_terracotta
setblock 525 295 285 minecraft:shroomlight
setblock 525 295 287 minecraft:shroomlight
setblock 525 295 289 minecraft:shroomlight
fill 525 295 317 525 302 317 minecraft:brown_terracotta
setblock 527 295 278 minecraft:light[level=12]
setblock 527 295 285 minecraft:light[level=12]
setblock 527 295 292 minecraft:light[level=12]
setblock 527 295 299 minecraft:light[level=12]
setblock 527 295 306 minecraft:light[level=12]
setblock 527 295 313 minecraft:light[level=12]
fill 529 295 275 529 302 275 minecraft:brown_terracotta
fill 529 295 317 529 302 317 minecraft:brown_terracotta
fill 533 295 275 533 302 275 minecraft:brown_terracotta
fill 533 295 317 533 302 317 minecraft:brown_terracotta
setblock 534 295 278 minecraft:light[level=12]
setblock 534 295 285 minecraft:light[level=12]
setblock 534 295 292 minecraft:light[level=12]
setblock 534 295 299 minecraft:light[level=12]
setblock 534 295 306 minecraft:light[level=12]
setblock 534 295 313 minecraft:light[level=12]
fill 537 295 275 537 302 275 minecraft:brown_terracotta
fill 537 295 317 537 302 317 minecraft:brown_terracotta
fill 541 295 275 541 302 275 minecraft:brown_terracotta
setblock 541 295 278 minecraft:light[level=12]
setblock 541 295 285 minecraft:light[level=12]
setblock 541 295 292 minecraft:light[level=12]
setblock 541 295 299 minecraft:light[level=12]
setblock 541 295 306 minecraft:light[level=12]
setblock 541 295 313 minecraft:light[level=12]
fill 541 295 317 541 302 317 minecraft:brown_terracotta
fill 545 295 275 545 302 275 minecraft:brown_terracotta
fill 545 295 317 545 302 317 minecraft:brown_terracotta
setblock 548 295 278 minecraft:light[level=12]
setblock 548 295 285 minecraft:light[level=12]
setblock 548 295 292 minecraft:light[level=12]
setblock 548 295 299 minecraft:light[level=12]
setblock 548 295 306 minecraft:light[level=12]
setblock 548 295 313 minecraft:light[level=12]
fill 549 295 275 549 302 275 minecraft:brown_terracotta
fill 549 295 317 549 302 317 minecraft:brown_terracotta
fill 553 295 275 553 302 275 minecraft:brown_terracotta
fill 553 295 291 557 295 301 minecraft:brown_terracotta
fill 553 295 317 553 302 317 minecraft:brown_terracotta
setblock 555 295 278 minecraft:light[level=12]
setblock 555 295 285 minecraft:light[level=12]
setblock 555 295 306 minecraft:light[level=12]
setblock 555 295 313 minecraft:light[level=12]
fill 557 295 275 557 302 275 minecraft:brown_terracotta
fill 557 295 317 557 302 317 minecraft:brown_terracotta
fill 559 295 275 559 300 275 minecraft:brown_terracotta
fill 559 295 279 559 302 279 minecraft:brown_terracotta
fill 559 295 283 559 302 283 minecraft:brown_terracotta
fill 559 295 287 559 302 287 minecraft:brown_terracotta
fill 559 295 291 559 302 291 minecraft:brown_terracotta
fill 559 295 295 559 302 295 minecraft:brown_terracotta
fill 559 295 299 559 302 299 minecraft:brown_terracotta
fill 559 295 303 559 302 303 minecraft:brown_terracotta
fill 559 295 307 559 302 307 minecraft:brown_terracotta
fill 559 295 311 559 302 311 minecraft:brown_terracotta
fill 559 295 315 559 302 315 minecraft:brown_terracotta
fill 518 296 284 518 297 284 minecraft:white_concrete
fill 518 296 286 518 297 286 minecraft:white_concrete
fill 518 296 288 518 297 288 minecraft:white_concrete
fill 518 296 290 518 297 290 minecraft:white_concrete
fill 519 296 285 519 297 285 minecraft:white_concrete
fill 519 296 287 519 297 287 minecraft:white_concrete
fill 519 296 289 519 297 289 minecraft:white_concrete
fill 520 296 284 520 297 284 minecraft:white_concrete
fill 520 296 286 520 297 286 minecraft:white_concrete
fill 520 296 288 520 297 288 minecraft:white_concrete
fill 520 296 290 520 297 290 minecraft:white_concrete
fill 521 296 285 521 297 285 minecraft:white_concrete
fill 521 296 287 521 297 287 minecraft:white_concrete
fill 521 296 289 521 297 289 minecraft:white_concrete
fill 522 296 284 522 297 284 minecraft:white_concrete
fill 522 296 286 522 297 286 minecraft:white_concrete
fill 522 296 288 522 297 288 minecraft:white_concrete
fill 522 296 290 522 297 290 minecraft:white_concrete
fill 523 296 285 523 297 285 minecraft:white_concrete
fill 523 296 287 523 297 287 minecraft:white_concrete
fill 523 296 289 523 297 289 minecraft:white_concrete
fill 524 296 284 524 297 284 minecraft:white_concrete
fill 524 296 286 524 297 286 minecraft:white_concrete
fill 524 296 288 524 297 288 minecraft:white_concrete
fill 524 296 290 524 297 290 minecraft:white_concrete
fill 525 296 285 525 297 285 minecraft:white_concrete
fill 525 296 287 525 297 287 minecraft:white_concrete
fill 525 296 289 525 297 289 minecraft:white_concrete
fill 553 296 291 557 296 301 minecraft:white_concrete
fill 520 297 296 524 297 300 minecraft:orange_terracotta
fill 529 297 312 530 298 313 minecraft:lime_concrete
fill 531 297 282 531 298 283 minecraft:white_concrete
fill 553 297 291 553 297 301 minecraft:red_concrete
fill 558 297 295 558 300 297 minecraft:shroomlight
fill 558 297 298 558 300 298 minecraft:white_concrete
setblock 518 298 284 minecraft:shroomlight
setblock 518 298 286 minecraft:shroomlight
setblock 518 298 288 minecraft:shroomlight
setblock 518 298 290 minecraft:shroomlight
setblock 519 298 285 minecraft:shroomlight
setblock 519 298 287 minecraft:shroomlight
setblock 519 298 289 minecraft:shroomlight
setblock 520 298 284 minecraft:shroomlight
setblock 520 298 286 minecraft:shroomlight
setblock 520 298 288 minecraft:shroomlight
setblock 520 298 290 minecraft:shroomlight
fill 520 298 296 521 301 300 minecraft:orange_terracotta
setblock 521 298 285 minecraft:shroomlight
setblock 521 298 287 minecraft:shroomlight
setblock 521 298 289 minecraft:shroomlight
setblock 522 298 284 minecraft:shroomlight
setblock 522 298 286 minecraft:shroomlight
setblock 522 298 288 minecraft:shroomlight
setblock 522 298 290 minecraft:shroomlight
fill 522 298 296 524 301 297 minecraft:orange_terracotta
fill 522 298 298 522 299 298 minecraft:ochre_froglight
fill 522 298 299 524 301 300 minecraft:orange_terracotta
setblock 523 298 285 minecraft:shroomlight
setblock 523 298 287 minecraft:shroomlight
setblock 523 298 289 minecraft:shroomlight
fill 523 298 298 524 301 298 minecraft:orange_terracotta
setblock 524 298 284 minecraft:shroomlight
setblock 524 298 286 minecraft:shroomlight
setblock 524 298 288 minecraft:shroomlight
setblock 524 298 290 minecraft:shroomlight
setblock 525 298 285 minecraft:shroomlight
setblock 525 298 287 minecraft:shroomlight
setblock 525 298 289 minecraft:shroomlight
fill 526 298 298 526 299 298 minecraft:white_concrete
setblock 553 298 291 minecraft:white_concrete
setblock 553 298 296 minecraft:white_concrete
setblock 553 298 301 minecraft:white_concrete
fill 518 299 284 518 300 284 minecraft:white_concrete
fill 518 299 286 518 300 286 minecraft:white_concrete
fill 518 299 288 518 300 288 minecraft:white_concrete
fill 518 299 290 518 300 290 minecraft:white_concrete
fill 519 299 285 519 300 285 minecraft:white_concrete
fill 519 299 287 519 300 287 minecraft:white_concrete
fill 519 299 289 519 300 289 minecraft:white_concrete
fill 520 299 284 520 300 284 minecraft:white_concrete
fill 520 299 286 520 300 286 minecraft:white_concrete
fill 520 299 288 520 300 288 minecraft:white_concrete
fill 520 299 290 520 300 290 minecraft:white_concrete
fill 521 299 285 521 300 285 minecraft:white_concrete
fill 521 299 287 521 300 287 minecraft:white_concrete
fill 521 299 289 521 300 289 minecraft:white_concrete
fill 522 299 284 522 300 284 minecraft:white_concrete
fill 522 299 286 522 300 286 minecraft:white_concrete
fill 522 299 288 522 300 288 minecraft:white_concrete
fill 522 299 290 522 300 290 minecraft:white_concrete
fill 523 299 285 523 300 285 minecraft:white_concrete
fill 523 299 287 523 300 287 minecraft:white_concrete
fill 523 299 289 523 300 289 minecraft:white_concrete
fill 524 299 284 524 300 284 minecraft:white_concrete
fill 524 299 286 524 300 286 minecraft:white_concrete
fill 524 299 288 524 300 288 minecraft:white_concrete
fill 524 299 290 524 300 290 minecraft:white_concrete
fill 525 299 285 525 300 285 minecraft:white_concrete
fill 525 299 287 525 300 287 minecraft:white_concrete
fill 525 299 289 525 300 289 minecraft:white_concrete
setblock 551 299 280 minecraft:brown_terracotta
setblock 552 299 279 minecraft:brown_terracotta
fill 552 299 281 552 299 282 minecraft:brown_terracotta
fill 553 299 278 555 299 278 minecraft:brown_terracotta
fill 553 299 282 555 299 282 minecraft:brown_terracotta
setblock 555 299 279 minecraft:brown_terracotta
fill 556 299 280 556 299 281 minecraft:brown_terracotta
fill 519 300 297 519 300 299 minecraft:white_concrete
fill 519 300 309 519 300 311 minecraft:white_concrete
fill 522 300 298 522 301 298 minecraft:orange_terracotta
fill 525 300 315 527 300 315 minecraft:white_concrete
fill 529 300 277 531 300 277 minecraft:white_concrete
fill 537 300 315 539 300 315 minecraft:white_concrete
fill 541 300 277 543 300 277 minecraft:white_concrete
fill 549 300 315 551 300 315 minecraft:white_concrete
setblock 552 300 279 minecraft:red_concrete
setblock 552 300 281 minecraft:red_concrete
fill 553 300 277 555 300 277 minecraft:white_concrete
fill 553 300 278 554 300 278 minecraft:red_concrete
fill 553 300 282 555 300 282 minecraft:red_concrete
setblock 555 300 279 minecraft:red_concrete
fill 557 300 285 557 300 287 minecraft:white_concrete
fill 557 300 297 557 300 299 minecraft:white_concrete
fill 557 300 309 557 300 311 minecraft:white_concrete
setblock 517 301 277 minecraft:white_concrete
setblock 517 301 281 minecraft:white_concrete
setblock 517 301 285 minecraft:white_concrete
setblock 517 301 289 minecraft:white_concrete
setblock 517 301 293 minecraft:white_concrete
setblock 517 301 297 minecraft:white_concrete
setblock 517 301 301 minecraft:white_concrete
setblock 517 301 305 minecraft:white_concrete
setblock 517 301 309 minecraft:white_concrete
setblock 517 301 313 minecraft:white_concrete
setblock 517 301 317 minecraft:white_concrete
setblock 519 301 275 minecraft:white_concrete
setblock 519 301 317 minecraft:white_concrete
setblock 520 301 278 minecraft:light[level=15]
setblock 520 301 285 minecraft:light[level=12]
setblock 520 301 286 minecraft:light[level=15]
setblock 520 301 292 minecraft:light[level=12]
setblock 520 301 294 minecraft:light[level=15]
setblock 520 301 302 minecraft:light[level=15]
setblock 520 301 306 minecraft:light[level=12]
setblock 520 301 310 minecraft:light[level=15]
setblock 520 301 313 minecraft:light[level=12]
setblock 523 301 275 minecraft:white_concrete
setblock 523 301 317 minecraft:white_concrete
setblock 527 301 275 minecraft:white_concrete
setblock 527 301 278 minecraft:light[level=12]
setblock 527 301 285 minecraft:light[level=12]
setblock 527 301 292 minecraft:light[level=12]
setblock 527 301 299 minecraft:light[level=12]
setblock 527 301 306 minecraft:light[level=12]
setblock 527 301 313 minecraft:light[level=12]
setblock 527 301 317 minecraft:white_concrete
setblock 528 301 278 minecraft:light[level=15]
setblock 528 301 286 minecraft:light[level=15]
setblock 528 301 294 minecraft:light[level=15]
setblock 528 301 302 minecraft:light[level=15]
setblock 528 301 310 minecraft:light[level=15]
setblock 531 301 275 minecraft:white_concrete
setblock 531 301 317 minecraft:white_concrete
setblock 534 301 278 minecraft:light[level=12]
setblock 534 301 285 minecraft:light[level=12]
setblock 534 301 292 minecraft:light[level=12]
setblock 534 301 299 minecraft:light[level=12]
setblock 534 301 306 minecraft:light[level=12]
setblock 534 301 313 minecraft:light[level=12]
setblock 535 301 275 minecraft:white_concrete
setblock 535 301 317 minecraft:white_concrete
setblock 536 301 278 minecraft:light[level=15]
setblock 536 301 286 minecraft:light[level=15]
setblock 536 301 294 minecraft:light[level=15]
setblock 536 301 302 minecraft:light[level=15]
setblock 536 301 310 minecraft:light[level=15]
setblock 539 301 275 minecraft:white_concrete
setblock 539 301 317 minecraft:white_concrete
setblock 541 301 278 minecraft:light[level=12]
setblock 541 301 285 minecraft:light[level=12]
setblock 541 301 292 minecraft:light[level=12]
setblock 541 301 299 minecraft:light[level=12]
setblock 541 301 306 minecraft:light[level=12]
setblock 541 301 313 minecraft:light[level=12]
setblock 543 301 275 minecraft:white_concrete
setblock 543 301 317 minecraft:white_concrete
setblock 544 301 278 minecraft:light[level=15]
setblock 544 301 286 minecraft:light[level=15]
setblock 544 301 294 minecraft:light[level=15]
setblock 544 301 302 minecraft:light[level=15]
setblock 544 301 310 minecraft:light[level=15]
setblock 547 301 275 minecraft:white_concrete
setblock 547 301 317 minecraft:white_concrete
setblock 548 301 278 minecraft:light[level=12]
setblock 548 301 285 minecraft:light[level=12]
setblock 548 301 292 minecraft:light[level=12]
setblock 548 301 299 minecraft:light[level=12]
setblock 548 301 306 minecraft:light[level=12]
setblock 548 301 313 minecraft:light[level=12]
setblock 551 301 275 minecraft:white_concrete
setblock 551 301 317 minecraft:white_concrete
setblock 552 301 278 minecraft:light[level=15]
setblock 552 301 286 minecraft:light[level=15]
setblock 552 301 294 minecraft:light[level=15]
setblock 552 301 302 minecraft:light[level=15]
setblock 552 301 310 minecraft:light[level=15]
setblock 555 301 275 minecraft:white_concrete
setblock 555 301 278 minecraft:light[level=12]
setblock 555 301 285 minecraft:light[level=12]
setblock 555 301 292 minecraft:light[level=12]
setblock 555 301 299 minecraft:light[level=12]
setblock 555 301 306 minecraft:light[level=12]
setblock 555 301 313 minecraft:light[level=12]
setblock 555 301 317 minecraft:white_concrete
setblock 559 301 275 minecraft:white_concrete
setblock 559 301 277 minecraft:white_concrete
setblock 559 301 281 minecraft:white_concrete
setblock 559 301 285 minecraft:white_concrete
setblock 559 301 289 minecraft:white_concrete
setblock 559 301 293 minecraft:white_concrete
setblock 559 301 297 minecraft:white_concrete
setblock 559 301 301 minecraft:white_concrete
setblock 559 301 305 minecraft:white_concrete
setblock 559 301 309 minecraft:white_concrete
setblock 559 301 313 minecraft:white_concrete
setblock 559 301 317 minecraft:white_concrete
setblock 517 302 276 minecraft:white_concrete
fill 517 302 277 517 308 277 minecraft:brown_terracotta
setblock 517 302 278 minecraft:white_concrete
setblock 517 302 280 minecraft:white_concrete
fill 517 302 281 517 308 281 minecraft:brown_terracotta
setblock 517 302 282 minecraft:white_concrete
setblock 517 302 284 minecraft:white_concrete
fill 517 302 285 517 308 285 minecraft:brown_terracotta
setblock 517 302 286 minecraft:white_concrete
setblock 517 302 288 minecraft:white_concrete
fill 517 302 289 517 308 289 minecraft:brown_terracotta
setblock 517 302 290 minecraft:white_concrete
setblock 517 302 292 minecraft:white_concrete
fill 517 302 293 517 308 293 minecraft:brown_terracotta
setblock 517 302 294 minecraft:white_concrete
setblock 517 302 296 minecraft:white_concrete
fill 517 302 297 517 308 297 minecraft:brown_terracotta
setblock 517 302 298 minecraft:white_concrete
setblock 517 302 300 minecraft:white_concrete
fill 517 302 301 517 308 301 minecraft:brown_terracotta
setblock 517 302 302 minecraft:white_concrete
setblock 517 302 304 minecraft:white_concrete
fill 517 302 305 517 308 305 minecraft:brown_terracotta
setblock 517 302 306 minecraft:white_concrete
setblock 517 302 308 minecraft:white_concrete
fill 517 302 309 517 308 309 minecraft:brown_terracotta
setblock 517 302 310 minecraft:white_concrete
setblock 517 302 312 minecraft:white_concrete
fill 517 302 313 517 308 313 minecraft:brown_terracotta
setblock 517 302 314 minecraft:white_concrete
setblock 517 302 316 minecraft:white_concrete
setblock 517 302 317 minecraft:brown_terracotta
setblock 518 302 275 minecraft:white_concrete
setblock 518 302 317 minecraft:white_concrete
fill 519 302 275 519 308 275 minecraft:brown_terracotta
fill 519 302 317 519 308 317 minecraft:brown_terracotta
setblock 520 302 275 minecraft:white_concrete
fill 520 302 296 524 302 300 minecraft:white_concrete
setblock 520 302 317 minecraft:white_concrete
setblock 522 302 275 minecraft:white_concrete
setblock 522 302 317 minecraft:white_concrete
fill 523 302 275 523 308 275 minecraft:brown_terracotta
fill 523 302 317 523 308 317 minecraft:brown_terracotta
setblock 524 302 275 minecraft:white_concrete
setblock 524 302 317 minecraft:white_concrete
setblock 526 302 275 minecraft:white_concrete
setblock 526 302 317 minecraft:white_concrete
fill 527 302 275 527 308 275 minecraft:brown_terracotta
fill 527 302 317 527 308 317 minecraft:brown_terracotta
setblock 528 302 275 minecraft:white_concrete
setblock 528 302 317 minecraft:white_concrete
setblock 530 302 275 minecraft:white_concrete
setblock 530 302 317 minecraft:white_concrete
fill 531 302 275 531 308 275 minecraft:brown_terracotta
fill 531 302 317 531 308 317 minecraft:brown_terracotta
setblock 532 302 275 minecraft:white_concrete
setblock 532 302 317 minecraft:white_concrete
setblock 534 302 275 minecraft:white_concrete
setblock 534 302 317 minecraft:white_concrete
fill 535 302 275 535 308 275 minecraft:brown_terracotta
fill 535 302 317 535 308 317 minecraft:brown_terracotta
setblock 536 302 275 minecraft:white_concrete
setblock 536 302 317 minecraft:white_concrete
setblock 538 302 275 minecraft:white_concrete
setblock 538 302 317 minecraft:white_concrete
fill 539 302 275 539 308 275 minecraft:brown_terracotta
fill 539 302 317 539 308 317 minecraft:brown_terracotta
setblock 540 302 275 minecraft:white_concrete
setblock 540 302 317 minecraft:white_concrete
setblock 542 302 275 minecraft:white_concrete
setblock 542 302 317 minecraft:white_concrete
fill 543 302 275 543 308 275 minecraft:brown_terracotta
fill 543 302 317 543 308 317 minecraft:brown_terracotta
setblock 544 302 275 minecraft:white_concrete
setblock 544 302 317 minecraft:white_concrete
setblock 546 302 275 minecraft:white_concrete
setblock 546 302 317 minecraft:white_concrete
fill 547 302 275 547 308 275 minecraft:brown_terracotta
fill 547 302 317 547 308 317 minecraft:brown_terracotta
setblock 548 302 275 minecraft:white_concrete
setblock 548 302 317 minecraft:white_concrete
setblock 550 302 275 minecraft:white_concrete
setblock 550 302 317 minecraft:white_concrete
fill 551 302 275 551 308 275 minecraft:brown_terracotta
fill 551 302 317 551 308 317 minecraft:brown_terracotta
setblock 552 302 275 minecraft:white_concrete
setblock 552 302 317 minecraft:white_concrete
setblock 554 302 275 minecraft:white_concrete
setblock 554 302 317 minecraft:white_concrete
fill 555 302 275 555 308 275 minecraft:brown_terracotta
fill 555 302 317 555 308 317 minecraft:brown_terracotta
setblock 556 302 275 minecraft:white_concrete
setblock 556 302 317 minecraft:white_concrete
setblock 558 302 275 minecraft:white_concrete
setblock 558 302 317 minecraft:white_concrete
setblock 559 302 275 minecraft:brown_terracotta
setblock 559 302 276 minecraft:white_concrete
fill 559 302 277 559 308 277 minecraft:brown_terracotta
setblock 559 302 278 minecraft:white_concrete
setblock 559 302 280 minecraft:white_concrete
fill 559 302 281 559 308 281 minecraft:brown_terracotta
setblock 559 302 282 minecraft:white_concrete
setblock 559 302 284 minecraft:white_concrete
fill 559 302 285 559 308 285 minecraft:brown_terracotta
setblock 559 302 286 minecraft:white_concrete
setblock 559 302 288 minecraft:white_concrete
fill 559 302 289 559 308 289 minecraft:brown_terracotta
setblock 559 302 290 minecraft:white_concrete
setblock 559 302 292 minecraft:white_concrete
fill 559 302 293 559 308 293 minecraft:brown_terracotta
setblock 559 302 294 minecraft:white_concrete
setblock 559 302 296 minecraft:white_concrete
fill 559 302 297 559 308 297 minecraft:brown_terracotta
setblock 559 302 298 minecraft:white_concrete
setblock 559 302 300 minecraft:white_concrete
fill 559 302 301 559 308 301 minecraft:brown_terracotta
setblock 559 302 302 minecraft:white_concrete
setblock 559 302 304 minecraft:white_concrete
fill 559 302 305 559 308 305 minecraft:brown_terracotta
setblock 559 302 306 minecraft:white_concrete
setblock 559 302 308 minecraft:white_concrete
fill 559 302 309 559 308 309 minecraft:brown_terracotta
setblock 559 302 310 minecraft:white_concrete
setblock 559 302 312 minecraft:white_concrete
fill 559 302 313 559 308 313 minecraft:brown_terracotta
setblock 559 302 314 minecraft:white_concrete
setblock 559 302 316 minecraft:white_concrete
fill 559 302 317 559 308 317 minecraft:brown_terracotta
setblock 517 303 275 minecraft:white_concrete
fill 517 303 276 517 308 276 minecraft:brown_terracotta
fill 517 303 278 517 308 278 minecraft:brown_terracotta
setblock 517 303 279 minecraft:white_concrete
fill 517 303 280 517 308 280 minecraft:brown_terracotta
fill 517 303 282 517 308 282 minecraft:brown_terracotta
setblock 517 303 283 minecraft:white_concrete
fill 517 303 284 517 308 284 minecraft:brown_terracotta
fill 517 303 286 517 308 286 minecraft:brown_terracotta
setblock 517 303 287 minecraft:white_concrete
fill 517 303 288 517 308 288 minecraft:brown_terracotta
fill 517 303 290 517 308 290 minecraft:brown_terracotta
setblock 517 303 291 minecraft:white_concrete
fill 517 303 292 517 308 292 minecraft:brown_terracotta
fill 517 303 294 517 308 294 minecraft:brown_terracotta
setblock 517 303 295 minecraft:white_concrete
fill 517 303 296 517 308 296 minecraft:brown_terracotta
fill 517 303 298 517 308 298 minecraft:brown_terracotta
setblock 517 303 299 minecraft:white_concrete
fill 517 303 300 517 308 300 minecraft:brown_terracotta
fill 517 303 302 517 308 302 minecraft:brown_terracotta
setblock 517 303 303 minecraft:white_concrete
fill 517 303 304 517 308 304 minecraft:brown_terracotta
fill 517 303 306 517 308 306 minecraft:brown_terracotta
setblock 517 303 307 minecraft:white_concrete
fill 517 303 308 517 308 308 minecraft:brown_terracotta
fill 517 303 310 517 308 310 minecraft:brown_terracotta
setblock 517 303 311 minecraft:white_concrete
fill 517 303 312 517 308 312 minecraft:brown_terracotta
fill 517 303 314 517 308 314 minecraft:brown_terracotta
setblock 517 303 315 minecraft:white_concrete
fill 517 303 316 517 308 316 minecraft:brown_terracotta
setblock 517 303 317 minecraft:white_concrete
fill 518 303 275 518 308 275 minecraft:brown_terracotta
fill 518 303 317 518 308 317 minecraft:brown_terracotta
fill 520 303 275 520 308 275 minecraft:brown_terracotta
fill 520 303 317 520 308 317 minecraft:brown_terracotta
setblock 521 303 275 minecraft:white_concrete
fill 521 303 296 523 303 300 minecraft:white_concrete
setblock 521 303 317 minecraft:white_concrete
fill 522 303 275 522 308 275 minecraft:brown_terracotta
fill 522 303 317 522 308 317 minecraft:brown_terracotta
fill 524 303 275 524 308 275 minecraft:brown_terracotta
fill 524 303 317 524 308 317 minecraft:brown_terracotta
setblock 525 303 275 minecraft:white_concrete
setblock 525 303 317 minecraft:white_concrete
fill 526 303 275 526 308 275 minecraft:brown_terracotta
fill 526 303 317 526 308 317 minecraft:brown_terracotta
fill 528 303 275 528 308 275 minecraft:brown_terracotta
fill 528 303 317 528 308 317 minecraft:brown_terracotta
setblock 529 303 275 minecraft:white_concrete
setblock 529 303 317 minecraft:white_concrete
fill 530 303 275 530 308 275 minecraft:brown_terracotta
fill 530 303 317 530 308 317 minecraft:brown_terracotta
fill 532 303 275 532 308 275 minecraft:brown_terracotta
fill 532 303 317 532 308 317 minecraft:brown_terracotta
setblock 533 303 275 minecraft:white_concrete
setblock 533 303 317 minecraft:white_concrete
fill 534 303 275 534 308 275 minecraft:brown_terracotta
fill 534 303 317 534 308 317 minecraft:brown_terracotta
fill 536 303 275 536 308 275 minecraft:brown_terracotta
fill 536 303 317 536 308 317 minecraft:brown_terracotta
setblock 537 303 275 minecraft:white_concrete
setblock 537 303 317 minecraft:white_concrete
fill 538 303 275 538 308 275 minecraft:brown_terracotta
fill 538 303 317 538 308 317 minecraft:brown_terracotta
fill 540 303 275 540 308 275 minecraft:brown_terracotta
fill 540 303 317 540 308 317 minecraft:brown_terracotta
setblock 541 303 275 minecraft:white_concrete
setblock 541 303 317 minecraft:white_concrete
fill 542 303 275 542 308 275 minecraft:brown_terracotta
fill 542 303 317 542 308 317 minecraft:brown_terracotta
fill 544 303 275 544 308 275 minecraft:brown_terracotta
fill 544 303 317 544 308 317 minecraft:brown_terracotta
setblock 545 303 275 minecraft:white_concrete
setblock 545 303 317 minecraft:white_concrete
fill 546 303 275 546 308 275 minecraft:brown_terracotta
fill 546 303 317 546 308 317 minecraft:brown_terracotta
fill 548 303 275 548 308 275 minecraft:brown_terracotta
fill 548 303 317 548 308 317 minecraft:brown_terracotta
setblock 549 303 275 minecraft:white_concrete
setblock 549 303 317 minecraft:white_concrete
fill 550 303 275 550 308 275 minecraft:brown_terracotta
fill 550 303 317 550 308 317 minecraft:brown_terracotta
fill 552 303 275 552 308 275 minecraft:brown_terracotta
fill 552 303 317 552 308 317 minecraft:brown_terracotta
setblock 553 303 275 minecraft:white_concrete
setblock 553 303 317 minecraft:white_concrete
fill 554 303 275 554 308 275 minecraft:brown_terracotta
fill 554 303 317 554 308 317 minecraft:brown_terracotta
fill 556 303 275 556 308 275 minecraft:brown_terracotta
fill 556 303 317 556 308 317 minecraft:brown_terracotta
setblock 557 303 275 minecraft:white_concrete
setblock 557 303 317 minecraft:white_concrete
fill 558 303 275 558 308 275 minecraft:brown_terracotta
fill 558 303 317 558 308 317 minecraft:brown_terracotta
setblock 559 303 275 minecraft:white_concrete
fill 559 303 276 559 308 276 minecraft:brown_terracotta
fill 559 303 278 559 308 278 minecraft:brown_terracotta
setblock 559 303 279 minecraft:white_concrete
fill 559 303 280 559 308 280 minecraft:brown_terracotta
fill 559 303 282 559 308 282 minecraft:brown_terracotta
setblock 559 303 283 minecraft:white_concrete
fill 559 303 284 559 308 284 minecraft:brown_terracotta
fill 559 303 286 559 308 286 minecraft:brown_terracotta
setblock 559 303 287 minecraft:white_concrete
fill 559 303 288 559 308 288 minecraft:brown_terracotta
fill 559 303 290 559 308 290 minecraft:brown_terracotta
setblock 559 303 291 minecraft:white_concrete
fill 559 303 292 559 308 292 minecraft:brown_terracotta
fill 559 303 294 559 308 294 minecraft:brown_terracotta
setblock 559 303 295 minecraft:white_concrete
fill 559 303 296 559 308 296 minecraft:brown_terracotta
fill 559 303 298 559 308 298 minecraft:brown_terracotta
setblock 559 303 299 minecraft:white_concrete
fill 559 303 300 559 308 300 minecraft:brown_terracotta
fill 559 303 302 559 308 302 minecraft:brown_terracotta
setblock 559 303 303 minecraft:white_concrete
fill 559 303 304 559 308 304 minecraft:brown_terracotta
fill 559 303 306 559 308 306 minecraft:brown_terracotta
setblock 559 303 307 minecraft:white_concrete
fill 559 303 308 559 308 308 minecraft:brown_terracotta
fill 559 303 310 559 308 310 minecraft:brown_terracotta
setblock 559 303 311 minecraft:white_concrete
fill 559 303 312 559 308 312 minecraft:brown_terracotta
fill 559 303 314 559 308 314 minecraft:brown_terracotta
setblock 559 303 315 minecraft:white_concrete
fill 559 303 316 559 308 316 minecraft:brown_terracotta
fill 517 304 275 517 308 275 minecraft:brown_terracotta
fill 517 304 279 517 308 279 minecraft:brown_terracotta
fill 517 304 283 517 308 283 minecraft:brown_terracotta
fill 517 304 287 517 308 287 minecraft:brown_terracotta
fill 517 304 291 517 308 291 minecraft:brown_terracotta
fill 517 304 295 517 308 295 minecraft:brown_terracotta
fill 517 304 299 517 308 299 minecraft:brown_terracotta
fill 517 304 303 517 308 303 minecraft:brown_terracotta
fill 517 304 307 517 308 307 minecraft:brown_terracotta
fill 517 304 311 517 308 311 minecraft:brown_terracotta
fill 517 304 315 517 308 315 minecraft:brown_terracotta
fill 517 304 317 517 308 317 minecraft:brown_terracotta
fill 521 304 275 521 308 275 minecraft:brown_terracotta
fill 521 304 317 521 308 317 minecraft:brown_terracotta
fill 525 304 275 525 308 275 minecraft:brown_terracotta
fill 525 304 317 525 308 317 minecraft:brown_terracotta
fill 529 304 275 529 308 275 minecraft:brown_terracotta
fill 529 304 317 529 308 317 minecraft:brown_terracotta
fill 533 304 275 533 308 275 minecraft:brown_terracotta
fill 533 304 317 533 308 317 minecraft:brown_terracotta
fill 537 304 275 537 308 275 minecraft:brown_terracotta
fill 537 304 317 537 308 317 minecraft:brown_terracotta
fill 541 304 275 541 308 275 minecraft:brown_terracotta
fill 541 304 317 541 308 317 minecraft:brown_terracotta
fill 545 304 275 545 308 275 minecraft:brown_terracotta
fill 545 304 317 545 308 317 minecraft:brown_terracotta
fill 549 304 275 549 308 275 minecraft:brown_terracotta
fill 549 304 317 549 308 317 minecraft:brown_terracotta
fill 553 304 275 553 308 275 minecraft:brown_terracotta
fill 553 304 317 553 308 317 minecraft:brown_terracotta
fill 557 304 275 557 308 275 minecraft:brown_terracotta
fill 557 304 317 557 308 317 minecraft:brown_terracotta
fill 559 304 275 559 308 275 minecraft:brown_terracotta
fill 559 304 279 559 308 279 minecraft:brown_terracotta
fill 559 304 283 559 308 283 minecraft:brown_terracotta
fill 559 304 287 559 308 287 minecraft:brown_terracotta
fill 559 304 291 559 308 291 minecraft:brown_terracotta
fill 559 304 295 559 308 295 minecraft:brown_terracotta
fill 559 304 299 559 308 299 minecraft:brown_terracotta
fill 559 304 303 559 308 303 minecraft:brown_terracotta
fill 559 304 307 559 308 307 minecraft:brown_terracotta
fill 559 304 311 559 308 311 minecraft:brown_terracotta
fill 559 304 315 559 308 315 minecraft:brown_terracotta
