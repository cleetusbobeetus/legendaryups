fill 377 168 635 377 168 637 minecraft:polished_blackstone
fill 377 168 639 377 168 641 minecraft:polished_blackstone
fill 377 168 643 377 168 645 minecraft:polished_blackstone
fill 378 168 646 379 168 646 minecraft:red_concrete
fill 379 168 604 380 169 604 minecraft:red_concrete
fill 379 168 645 381 168 645 minecraft:polished_blackstone
fill 380 168 646 380 173 646 minecraft:purple_terracotta
fill 381 168 605 383 168 605 minecraft:polished_blackstone
fill 383 168 645 385 168 645 minecraft:polished_blackstone
fill 385 168 605 387 168 605 minecraft:polished_blackstone
fill 386 168 604 386 170 604 minecraft:purple_terracotta
fill 386 168 646 387 169 646 minecraft:red_concrete
fill 387 168 645 389 168 645 minecraft:polished_blackstone
setblock 388 168 604 minecraft:red_concrete
fill 388 168 646 389 173 646 minecraft:purple_terracotta
fill 389 168 604 390 173 604 minecraft:purple_terracotta
fill 389 168 605 391 168 605 minecraft:polished_blackstone
fill 389 168 630 389 169 630 minecraft:blackstone
fill 391 168 604 392 169 604 minecraft:red_concrete
fill 391 168 645 393 168 645 minecraft:polished_blackstone
fill 393 168 605 395 168 605 minecraft:polished_blackstone
fill 395 168 645 397 168 645 minecraft:polished_blackstone
fill 397 168 604 398 173 604 minecraft:purple_terracotta
fill 397 168 605 399 168 605 minecraft:polished_blackstone
fill 398 168 646 399 168 646 minecraft:red_concrete
fill 399 168 604 400 168 604 minecraft:red_concrete
fill 399 168 645 401 168 645 minecraft:polished_blackstone
fill 400 168 646 401 173 646 minecraft:purple_terracotta
fill 401 168 605 403 168 605 minecraft:polished_blackstone
fill 403 168 645 405 168 645 minecraft:polished_blackstone
fill 405 168 605 407 168 605 minecraft:polished_blackstone
fill 407 168 645 409 168 645 minecraft:polished_blackstone
fill 407 168 646 407 169 646 minecraft:red_concrete
fill 408 168 613 408 168 615 minecraft:crying_obsidian
fill 408 168 646 409 173 646 minecraft:purple_terracotta
fill 409 168 604 410 173 604 minecraft:purple_terracotta
fill 409 168 605 411 168 605 minecraft:polished_blackstone
setblock 410 168 646 minecraft:red_concrete
fill 411 168 604 412 169 604 minecraft:red_concrete
fill 411 168 645 413 168 645 minecraft:polished_blackstone
fill 412 168 646 412 173 646 minecraft:purple_terracotta
fill 413 168 605 415 168 605 minecraft:polished_blackstone
fill 415 168 645 417 168 645 minecraft:polished_blackstone
fill 417 168 605 417 168 607 minecraft:polished_blackstone
fill 417 168 609 417 168 611 minecraft:polished_blackstone
fill 417 168 613 417 168 615 minecraft:polished_blackstone
fill 417 168 617 417 168 619 minecraft:polished_blackstone
fill 417 168 621 417 168 623 minecraft:polished_blackstone
fill 417 168 625 417 168 627 minecraft:polished_blackstone
fill 417 168 629 417 168 631 minecraft:polished_blackstone
fill 417 168 633 417 168 635 minecraft:polished_blackstone
fill 417 168 637 417 168 639 minecraft:polished_blackstone
fill 417 168 641 417 168 643 minecraft:polished_blackstone
fill 418 168 604 418 173 604 minecraft:purple_terracotta
fill 418 168 605 418 168 606 minecraft:red_concrete
fill 418 168 607 418 169 608 minecraft:purple_terracotta
fill 418 168 609 418 169 609 minecraft:red_concrete
fill 418 168 615 418 173 616 minecraft:purple_terracotta
fill 418 168 617 418 169 618 minecraft:red_concrete
setblock 418 168 626 minecraft:red_concrete
fill 418 168 627 418 173 628 minecraft:purple_terracotta
fill 418 168 629 418 169 630 minecraft:red_concrete
fill 418 168 635 418 173 636 minecraft:purple_terracotta
fill 418 168 637 418 168 638 minecraft:red_concrete
fill 418 168 639 418 173 639 minecraft:purple_terracotta
fill 418 168 646 418 169 646 minecraft:red_concrete
fill 376 169 612 376 169 613 minecraft:red_concrete
setblock 376 169 616 minecraft:red_concrete
fill 376 169 617 376 172 617 minecraft:purple_terracotta
fill 376 169 628 376 172 628 minecraft:purple_terracotta
setblock 376 169 633 minecraft:red_concrete
setblock 376 169 644 minecraft:red_concrete
fill 378 169 646 379 172 646 minecraft:purple_terracotta
setblock 383 169 604 minecraft:red_concrete
fill 384 169 604 384 171 604 minecraft:purple_terracotta
fill 388 169 604 388 172 604 minecraft:purple_terracotta
setblock 395 169 646 minecraft:red_concrete
setblock 398 169 646 minecraft:red_concrete
fill 399 169 604 399 172 604 minecraft:purple_terracotta
fill 399 169 646 399 172 646 minecraft:purple_terracotta
setblock 400 169 604 minecraft:red_concrete
setblock 403 169 604 minecraft:red_concrete
setblock 406 169 646 minecraft:red_concrete
fill 408 169 611 408 169 613 minecraft:crying_obsidian
fill 410 169 646 410 172 646 minecraft:purple_terracotta
fill 418 169 605 418 172 606 minecraft:purple_terracotta
setblock 418 169 610 minecraft:red_concrete
setblock 418 169 621 minecraft:red_concrete
fill 418 169 626 418 172 626 minecraft:purple_terracotta
fill 418 169 637 418 172 637 minecraft:purple_terracotta
setblock 418 169 638 minecraft:red_concrete
fill 418 169 641 418 169 642 minecraft:red_concrete
fill 376 170 604 376 175 605 minecraft:purple_terracotta
fill 376 170 611 376 171 611 minecraft:red_concrete
fill 376 170 612 376 175 613 minecraft:purple_terracotta
setblock 376 170 614 minecraft:red_concrete
fill 376 170 616 376 175 616 minecraft:purple_terracotta
fill 376 170 622 376 171 623 minecraft:red_concrete
fill 376 170 624 376 175 625 minecraft:purple_terracotta
fill 376 170 633 376 175 633 minecraft:purple_terracotta
fill 376 170 634 376 170 635 minecraft:red_concrete
fill 376 170 636 376 175 637 minecraft:purple_terracotta
fill 376 170 642 376 171 643 minecraft:red_concrete
fill 376 170 644 376 175 645 minecraft:purple_terracotta
setblock 376 170 646 minecraft:red_concrete
fill 377 170 646 377 173 646 minecraft:purple_terracotta
fill 379 170 604 380 175 604 minecraft:purple_terracotta
setblock 379 170 607 minecraft:light[level=12]
setblock 379 170 615 minecraft:light[level=12]
setblock 379 170 623 minecraft:light[level=12]
setblock 379 170 631 minecraft:light[level=12]
setblock 379 170 639 minecraft:light[level=12]
fill 381 170 604 382 170 604 minecraft:red_concrete
fill 383 170 604 383 171 604 minecraft:purple_terracotta
fill 384 170 646 385 171 646 minecraft:red_concrete
fill 386 170 646 387 175 646 minecraft:purple_terracotta
setblock 387 170 607 minecraft:light[level=12]
setblock 387 170 615 minecraft:light[level=12]
setblock 387 170 623 minecraft:light[level=12]
setblock 387 170 631 minecraft:light[level=12]
setblock 387 170 639 minecraft:light[level=12]
fill 391 170 604 392 175 604 minecraft:purple_terracotta
fill 393 170 604 394 171 604 minecraft:red_concrete
fill 393 170 646 393 171 646 minecraft:red_concrete
setblock 395 170 607 minecraft:light[level=12]
setblock 395 170 615 minecraft:light[level=12]
setblock 395 170 623 minecraft:light[level=12]
setblock 395 170 631 minecraft:light[level=12]
setblock 395 170 639 minecraft:light[level=12]
fill 395 170 646 395 175 646 minecraft:purple_terracotta
fill 396 170 646 397 170 646 minecraft:red_concrete
fill 398 170 646 398 175 646 minecraft:purple_terracotta
fill 400 170 604 400 175 604 minecraft:purple_terracotta
fill 401 170 604 402 170 604 minecraft:red_concrete
fill 403 170 604 403 175 604 minecraft:purple_terracotta
setblock 403 170 607 minecraft:light[level=12]
setblock 403 170 615 minecraft:light[level=12]
setblock 403 170 623 minecraft:light[level=12]
setblock 403 170 631 minecraft:light[level=12]
setblock 403 170 639 minecraft:light[level=12]
fill 404 170 646 405 171 646 minecraft:red_concrete
fill 405 170 604 405 171 604 minecraft:red_concrete
fill 406 170 646 407 175 646 minecraft:purple_terracotta
fill 407 170 610 408 170 610 minecraft:crying_obsidian
fill 408 170 609 408 171 609 minecraft:crying_obsidian
setblock 408 170 611 minecraft:crying_obsidian
fill 411 170 604 412 175 604 minecraft:purple_terracotta
setblock 411 170 607 minecraft:light[level=12]
setblock 411 170 615 minecraft:light[level=12]
setblock 411 170 623 minecraft:light[level=12]
setblock 411 170 631 minecraft:light[level=12]
setblock 411 170 639 minecraft:light[level=12]
fill 413 170 604 414 171 604 minecraft:red_concrete
fill 416 170 646 417 170 646 minecraft:red_concrete
fill 418 170 607 418 173 607 minecraft:purple_terracotta
setblock 418 170 608 minecraft:red_concrete
fill 418 170 609 418 175 610 minecraft:purple_terracotta
fill 418 170 611 418 171 612 minecraft:red_concrete
fill 418 170 617 418 175 618 minecraft:purple_terracotta
fill 418 170 619 418 170 620 minecraft:red_concrete
fill 418 170 621 418 175 621 minecraft:purple_terracotta
fill 418 170 629 418 175 630 minecraft:purple_terracotta
fill 418 170 631 418 171 632 minecraft:red_concrete
fill 418 170 638 418 175 638 minecraft:purple_terracotta
setblock 418 170 640 minecraft:red_concrete
fill 418 170 641 418 175 642 minecraft:purple_terracotta
fill 418 170 643 418 171 643 minecraft:red_concrete
fill 418 170 646 418 175 646 minecraft:purple_terracotta
setblock 376 171 610 minecraft:red_concrete
fill 376 171 614 376 174 614 minecraft:purple_terracotta
fill 376 171 630 376 171 631 minecraft:red_concrete
setblock 376 171 634 minecraft:red_concrete
fill 376 171 635 376 174 635 minecraft:purple_terracotta
fill 376 171 646 376 174 646 minecraft:purple_terracotta
fill 381 171 604 381 174 604 minecraft:purple_terracotta
setblock 381 171 646 minecraft:red_concrete
setblock 382 171 604 minecraft:red_concrete
fill 385 171 604 386 171 604 minecraft:red_concrete
setblock 392 171 646 minecraft:red_concrete
fill 396 171 646 397 174 646 minecraft:purple_terracotta
fill 401 171 604 402 173 604 minecraft:purple_terracotta
setblock 406 171 604 minecraft:red_concrete
setblock 408 171 610 minecraft:crying_obsidian
fill 413 171 630 413 172 631 minecraft:magma_block
setblock 413 171 646 minecraft:red_concrete
setblock 416 171 646 minecraft:red_concrete
setblock 417 171 604 minecraft:red_concrete
fill 417 171 646 417 174 646 minecraft:purple_terracotta
fill 418 171 608 418 174 608 minecraft:purple_terracotta
fill 418 171 619 418 174 619 minecraft:purple_terracotta
setblock 418 171 620 minecraft:red_concrete
fill 418 171 623 418 171 624 minecraft:red_concrete
fill 418 171 640 418 174 640 minecraft:purple_terracotta
setblock 418 171 644 minecraft:red_concrete
fill 376 172 608 376 173 609 minecraft:red_concrete
fill 376 172 610 376 177 611 minecraft:purple_terracotta
fill 376 172 620 376 172 621 minecraft:red_concrete
fill 376 172 622 376 177 623 minecraft:purple_terracotta
fill 376 172 629 376 173 629 minecraft:red_concrete
fill 376 172 630 376 177 631 minecraft:purple_terracotta
setblock 376 172 632 minecraft:red_concrete
fill 376 172 634 376 177 634 minecraft:purple_terracotta
fill 376 172 640 376 173 641 minecraft:red_concrete
fill 376 172 642 376 177 643 minecraft:purple_terracotta
fill 381 172 646 381 177 646 minecraft:purple_terracotta
fill 382 172 604 382 177 604 minecraft:purple_terracotta
fill 382 172 646 383 172 646 minecraft:red_concrete
fill 383 172 604 384 172 604 minecraft:red_concrete
fill 384 172 646 385 177 646 minecraft:purple_terracotta
fill 385 172 604 386 173 604 minecraft:purple_terracotta
fill 387 172 604 387 173 604 minecraft:red_concrete
fill 390 172 646 391 173 646 minecraft:red_concrete
fill 392 172 646 393 177 646 minecraft:purple_terracotta
fill 393 172 604 394 177 604 minecraft:purple_terracotta
setblock 394 172 646 minecraft:red_concrete
fill 395 172 604 396 173 604 minecraft:red_concrete
fill 402 172 646 403 173 646 minecraft:red_concrete
setblock 404 172 604 minecraft:red_concrete
fill 404 172 646 405 177 646 minecraft:purple_terracotta
fill 405 172 604 406 177 604 minecraft:purple_terracotta
fill 407 172 604 408 173 604 minecraft:red_concrete
fill 411 172 646 411 173 646 minecraft:red_concrete
fill 413 172 604 414 177 604 minecraft:purple_terracotta
fill 413 172 646 413 177 646 minecraft:purple_terracotta
fill 414 172 646 415 172 646 minecraft:red_concrete
fill 415 172 604 416 172 604 minecraft:red_concrete
fill 416 172 646 416 177 646 minecraft:purple_terracotta
fill 417 172 604 417 177 604 minecraft:purple_terracotta
fill 418 172 611 418 177 612 minecraft:purple_terracotta
fill 418 172 613 418 173 614 minecraft:red_concrete
fill 418 172 620 418 177 620 minecraft:purple_terracotta
setblock 418 172 622 minecraft:red_concrete
fill 418 172 623 418 177 624 minecraft:purple_terracotta
fill 418 172 625 418 173 625 minecraft:red_concrete
fill 418 172 631 418 177 632 minecraft:purple_terracotta
fill 418 172 633 418 172 634 minecraft:red_concrete
fill 418 172 643 418 177 644 minecraft:purple_terracotta
fill 418 172 645 418 173 645 minecraft:red_concrete
setblock 376 173 617 minecraft:red_concrete
setblock 376 173 620 minecraft:red_concrete
fill 376 173 621 376 176 621 minecraft:purple_terracotta
setblock 376 173 628 minecraft:red_concrete
fill 376 173 632 376 176 632 minecraft:purple_terracotta
fill 378 173 646 379 173 646 minecraft:red_concrete
setblock 382 173 646 minecraft:red_concrete
fill 383 173 604 384 175 604 minecraft:purple_terracotta
fill 383 173 646 383 176 646 minecraft:purple_terracotta
setblock 388 173 604 minecraft:red_concrete
fill 388 173 608 388 174 610 minecraft:blackstone
fill 389 173 608 389 174 609 minecraft:blackstone
fill 394 173 646 394 176 646 minecraft:purple_terracotta
setblock 399 173 604 minecraft:red_concrete
setblock 399 173 646 minecraft:red_concrete
fill 404 173 604 404 175 604 minecraft:purple_terracotta
setblock 410 173 646 minecraft:red_concrete
fill 414 173 646 415 176 646 minecraft:purple_terracotta
fill 415 173 604 415 176 604 minecraft:purple_terracotta
setblock 416 173 604 minecraft:red_concrete
fill 418 173 605 418 173 606 minecraft:red_concrete
fill 418 173 622 418 176 622 minecraft:purple_terracotta
setblock 418 173 626 minecraft:red_concrete
fill 418 173 633 418 176 633 minecraft:purple_terracotta
setblock 418 173 634 minecraft:red_concrete
setblock 418 173 637 minecraft:red_concrete
fill 376 174 606 376 175 607 minecraft:red_concrete
fill 376 174 608 376 179 609 minecraft:purple_terracotta
fill 376 174 615 376 175 615 minecraft:red_concrete
fill 376 174 617 376 179 617 minecraft:purple_terracotta
fill 376 174 618 376 174 619 minecraft:red_concrete
fill 376 174 620 376 179 620 minecraft:purple_terracotta
fill 376 174 626 376 175 627 minecraft:red_concrete
fill 376 174 628 376 179 629 minecraft:purple_terracotta
fill 376 174 638 376 174 639 minecraft:red_concrete
fill 376 174 640 376 179 641 minecraft:purple_terracotta
fill 377 174 604 378 175 604 minecraft:red_concrete
fill 377 174 605 379 174 605 minecraft:polished_blackstone
fill 377 174 607 377 174 609 minecraft:polished_blackstone
fill 377 174 611 377 174 613 minecraft:polished_blackstone
fill 377 174 615 377 174 617 minecraft:polished_blackstone
fill 377 174 619 377 174 621 minecraft:polished_blackstone
fill 377 174 623 377 174 625 minecraft:polished_blackstone
fill 377 174 627 377 174 629 minecraft:polished_blackstone
fill 377 174 631 377 174 633 minecraft:polished_blackstone
fill 377 174 635 377 174 637 minecraft:polished_blackstone
fill 377 174 639 377 174 641 minecraft:polished_blackstone
fill 377 174 643 377 174 645 minecraft:polished_blackstone
fill 377 174 646 377 175 646 minecraft:red_concrete
fill 378 174 646 379 179 646 minecraft:purple_terracotta
fill 379 174 645 381 174 645 minecraft:polished_blackstone
setblock 380 174 646 minecraft:red_concrete
fill 381 174 605 383 174 605 minecraft:polished_blackstone
fill 382 174 646 382 179 646 minecraft:purple_terracotta
fill 383 174 645 385 174 645 minecraft:polished_blackstone
fill 385 174 604 385 177 604 minecraft:purple_terracotta
fill 385 174 605 387 174 605 minecraft:polished_blackstone
setblock 386 174 604 minecraft:red_concrete
fill 387 174 604 388 179 604 minecraft:purple_terracotta
fill 387 174 645 389 174 645 minecraft:polished_blackstone
fill 388 174 646 389 175 646 minecraft:red_concrete
fill 389 174 604 390 175 604 minecraft:red_concrete
fill 389 174 605 391 174 605 minecraft:polished_blackstone
fill 390 174 646 391 179 646 minecraft:purple_terracotta
fill 391 174 645 393 174 645 minecraft:polished_blackstone
fill 393 174 605 395 174 605 minecraft:polished_blackstone
fill 395 174 604 396 176 604 minecraft:purple_terracotta
fill 395 174 645 397 174 645 minecraft:polished_blackstone
fill 397 174 604 398 174 604 minecraft:red_concrete
fill 397 174 605 399 174 605 minecraft:polished_blackstone
fill 399 174 604 399 179 604 minecraft:purple_terracotta
fill 399 174 645 401 174 645 minecraft:polished_blackstone
fill 399 174 646 399 179 646 minecraft:purple_terracotta
fill 400 174 646 401 174 646 minecraft:red_concrete
fill 401 174 604 401 175 604 minecraft:red_concrete
fill 401 174 605 403 174 605 minecraft:polished_blackstone
setblock 402 174 604 minecraft:purple_terracotta
fill 402 174 646 403 179 646 minecraft:purple_terracotta
fill 403 174 645 405 174 645 minecraft:polished_blackstone
fill 405 174 605 407 174 605 minecraft:polished_blackstone
fill 407 174 604 408 179 604 minecraft:purple_terracotta
fill 407 174 645 409 174 645 minecraft:polished_blackstone
fill 408 174 646 409 175 646 minecraft:red_concrete
fill 409 174 604 410 175 604 minecraft:red_concrete
fill 409 174 605 411 174 605 minecraft:polished_blackstone
fill 410 174 646 411 179 646 minecraft:purple_terracotta
fill 411 174 645 413 174 645 minecraft:polished_blackstone
setblock 412 174 646 minecraft:red_concrete
fill 413 174 605 415 174 605 minecraft:polished_blackstone
fill 415 174 645 417 174 645 minecraft:polished_blackstone
fill 416 174 604 416 179 604 minecraft:purple_terracotta
fill 417 174 605 417 174 607 minecraft:polished_blackstone
fill 417 174 609 417 174 611 minecraft:polished_blackstone
fill 417 174 613 417 174 615 minecraft:polished_blackstone
fill 417 174 617 417 174 619 minecraft:polished_blackstone
fill 417 174 621 417 174 623 minecraft:polished_blackstone
fill 417 174 625 417 174 627 minecraft:polished_blackstone
fill 417 174 629 417 174 631 minecraft:polished_blackstone
fill 417 174 633 417 174 635 minecraft:polished_blackstone
fill 417 174 637 417 174 639 minecraft:polished_blackstone
fill 417 174 641 417 174 643 minecraft:polished_blackstone
setblock 418 174 604 minecraft:red_concrete
fill 418 174 605 418 179 606 minecraft:purple_terracotta
fill 418 174 607 418 175 607 minecraft:red_concrete
fill 418 174 613 418 179 614 minecraft:purple_terracotta
fill 418 174 615 418 174 616 minecraft:red_concrete
fill 418 174 625 418 179 626 minecraft:purple_terracotta
fill 418 174 627 418 175 628 minecraft:red_concrete
fill 418 174 634 418 179 634 minecraft:purple_terracotta
fill 418 174 635 418 174 636 minecraft:red_concrete
fill 418 174 637 418 179 637 minecraft:purple_terracotta
fill 418 174 639 418 175 639 minecraft:red_concrete
fill 418 174 645 418 179 645 minecraft:purple_terracotta
setblock 376 175 614 minecraft:red_concrete
fill 376 175 618 376 178 619 minecraft:purple_terracotta
setblock 376 175 635 minecraft:red_concrete
setblock 376 175 638 minecraft:red_concrete
fill 376 175 639 376 178 639 minecraft:purple_terracotta
setblock 376 175 646 minecraft:red_concrete
fill 380 175 646 380 178 646 minecraft:purple_terracotta
setblock 381 175 604 minecraft:red_concrete
fill 386 175 604 386 177 604 minecraft:purple_terracotta
fill 396 175 646 397 175 646 minecraft:red_concrete
fill 397 175 604 397 178 604 minecraft:purple_terracotta
setblock 398 175 604 minecraft:red_concrete
setblock 400 175 646 minecraft:red_concrete
fill 401 175 646 401 178 646 minecraft:purple_terracotta
setblock 402 175 604 minecraft:red_concrete
fill 412 175 646 412 178 646 minecraft:purple_terracotta
setblock 417 175 646 minecraft:red_concrete
fill 418 175 604 418 178 604 minecraft:purple_terracotta
setblock 418 175 608 minecraft:red_concrete
fill 418 175 615 418 178 615 minecraft:purple_terracotta
setblock 418 175 616 minecraft:red_concrete
setblock 418 175 619 minecraft:red_concrete
fill 418 175 635 418 178 636 minecraft:purple_terracotta
setblock 418 175 640 minecraft:red_concrete
fill 376 176 604 376 176 605 minecraft:red_concrete
fill 376 176 606 376 181 607 minecraft:purple_terracotta
fill 376 176 612 376 177 613 minecraft:red_concrete
fill 376 176 614 376 181 615 minecraft:purple_terracotta
setblock 376 176 616 minecraft:red_concrete
fill 376 176 624 376 177 625 minecraft:red_concrete
fill 376 176 626 376 181 627 minecraft:purple_terracotta
fill 376 176 633 376 177 633 minecraft:red_concrete
fill 376 176 635 376 181 635 minecraft:purple_terracotta
fill 376 176 636 376 176 637 minecraft:red_concrete
fill 376 176 638 376 181 638 minecraft:purple_terracotta
fill 376 176 644 376 177 645 minecraft:red_concrete
fill 376 176 646 377 181 646 minecraft:purple_terracotta
fill 377 176 604 378 178 604 minecraft:purple_terracotta
fill 379 176 604 380 176 604 minecraft:red_concrete
fill 381 176 604 381 181 604 minecraft:purple_terracotta
fill 383 176 604 383 177 604 minecraft:red_concrete
setblock 384 176 604 minecraft:purple_terracotta
fill 386 176 646 387 176 646 minecraft:red_concrete
fill 388 176 646 389 181 646 minecraft:purple_terracotta
fill 389 176 604 390 181 604 minecraft:purple_terracotta
fill 391 176 604 392 177 604 minecraft:red_concrete
fill 395 176 646 395 177 646 minecraft:red_concrete
fill 396 176 646 397 181 646 minecraft:purple_terracotta
fill 398 176 604 398 178 604 minecraft:purple_terracotta
setblock 398 176 646 minecraft:red_concrete
setblock 400 176 604 minecraft:red_concrete
fill 400 176 646 400 181 646 minecraft:purple_terracotta
fill 401 176 604 402 181 604 minecraft:purple_terracotta
fill 403 176 604 404 177 604 minecraft:red_concrete
fill 406 176 646 407 177 646 minecraft:red_concrete
fill 408 176 646 409 181 646 minecraft:purple_terracotta
fill 409 176 604 410 181 604 minecraft:purple_terracotta
fill 411 176 604 412 176 604 minecraft:red_concrete
fill 417 176 646 417 181 646 minecraft:purple_terracotta
fill 418 176 607 418 181 608 minecraft:purple_terracotta
fill 418 176 609 418 177 610 minecraft:red_concrete
fill 418 176 616 418 181 616 minecraft:purple_terracotta
fill 418 176 617 418 176 618 minecraft:red_concrete
fill 418 176 619 418 181 619 minecraft:purple_terracotta
fill 418 176 621 418 177 621 minecraft:red_concrete
fill 418 176 627 418 181 628 minecraft:purple_terracotta
fill 418 176 629 418 177 630 minecraft:red_concrete
setblock 418 176 638 minecraft:red_concrete
fill 418 176 639 418 181 640 minecraft:purple_terracotta
fill 418 176 641 418 177 642 minecraft:red_concrete
fill 418 176 646 418 177 646 minecraft:red_concrete
setblock 376 177 604 minecraft:red_concrete
fill 376 177 605 376 180 605 minecraft:purple_terracotta
fill 376 177 616 376 180 616 minecraft:purple_terracotta
setblock 376 177 621 minecraft:red_concrete
setblock 376 177 632 minecraft:red_concrete
fill 376 177 636 376 180 637 minecraft:purple_terracotta
fill 379 177 604 379 180 604 minecraft:purple_terracotta
setblock 380 177 604 minecraft:red_concrete
setblock 383 177 646 minecraft:red_concrete
setblock 384 177 604 minecraft:red_concrete
setblock 386 177 646 minecraft:red_concrete
fill 387 177 646 387 180 646 minecraft:purple_terracotta
setblock 394 177 646 minecraft:red_concrete
setblock 395 177 604 minecraft:red_concrete
fill 396 177 604 396 179 604 minecraft:purple_terracotta
fill 398 177 646 398 180 646 minecraft:purple_terracotta
fill 400 177 604 400 180 604 minecraft:purple_terracotta
fill 411 177 604 411 180 604 minecraft:purple_terracotta
setblock 412 177 604 minecraft:red_concrete
fill 414 177 646 415 177 646 minecraft:red_concrete
setblock 415 177 604 minecraft:red_concrete
fill 418 177 617 418 180 618 minecraft:purple_terracotta
setblock 418 177 622 minecraft:red_concrete
setblock 418 177 633 minecraft:red_concrete
fill 418 177 638 418 180 638 minecraft:purple_terracotta
fill 376 178 604 376 183 604 minecraft:purple_terracotta
fill 376 178 610 376 179 611 minecraft:red_concrete
fill 376 178 612 376 183 613 minecraft:purple_terracotta
fill 376 178 621 376 183 621 minecraft:purple_terracotta
fill 376 178 622 376 178 623 minecraft:red_concrete
fill 376 178 624 376 183 625 minecraft:purple_terracotta
fill 376 178 630 376 179 631 minecraft:red_concrete
fill 376 178 632 376 183 633 minecraft:purple_terracotta
setblock 376 178 634 minecraft:red_concrete
fill 376 178 642 376 179 643 minecraft:red_concrete
fill 376 178 644 376 183 645 minecraft:purple_terracotta
setblock 379 178 607 minecraft:light[level=12]
setblock 379 178 615 minecraft:light[level=12]
setblock 379 178 623 minecraft:light[level=12]
setblock 379 178 631 minecraft:light[level=12]
setblock 379 178 639 minecraft:light[level=12]
fill 380 178 604 380 180 604 minecraft:purple_terracotta
fill 381 178 646 381 179 646 minecraft:red_concrete
setblock 382 178 604 minecraft:red_concrete
fill 383 178 604 384 183 604 minecraft:purple_terracotta
fill 383 178 646 383 183 646 minecraft:purple_terracotta
fill 384 178 646 385 178 646 minecraft:red_concrete
fill 385 178 604 386 179 604 minecraft:red_concrete
fill 386 178 646 386 183 646 minecraft:purple_terracotta
setblock 387 178 607 minecraft:light[level=12]
setblock 387 178 615 minecraft:light[level=12]
setblock 387 178 623 minecraft:light[level=12]
setblock 387 178 631 minecraft:light[level=12]
setblock 387 178 639 minecraft:light[level=12]
fill 391 178 604 392 183 604 minecraft:purple_terracotta
fill 392 178 646 393 179 646 minecraft:red_concrete
fill 393 178 604 394 178 604 minecraft:red_concrete
fill 394 178 646 395 183 646 minecraft:purple_terracotta
fill 395 178 604 395 179 604 minecraft:purple_terracotta
setblock 395 178 607 minecraft:light[level=12]
setblock 395 178 615 minecraft:light[level=12]
setblock 395 178 623 minecraft:light[level=12]
setblock 395 178 631 minecraft:light[level=12]
setblock 395 178 639 minecraft:light[level=12]
fill 403 178 604 404 183 604 minecraft:purple_terracotta
setblock 403 178 607 minecraft:light[level=12]
setblock 403 178 615 minecraft:light[level=12]
setblock 403 178 623 minecraft:light[level=12]
setblock 403 178 631 minecraft:light[level=12]
setblock 403 178 639 minecraft:light[level=12]
fill 404 178 646 405 178 646 minecraft:red_concrete
fill 405 178 604 406 179 604 minecraft:red_concrete
fill 406 178 646 407 183 646 minecraft:purple_terracotta
setblock 411 178 607 minecraft:light[level=12]
setblock 411 178 615 minecraft:light[level=12]
setblock 411 178 623 minecraft:light[level=12]
setblock 411 178 631 minecraft:light[level=12]
setblock 411 178 639 minecraft:light[level=12]
fill 412 178 604 412 183 604 minecraft:purple_terracotta
fill 413 178 604 414 178 604 minecraft:red_concrete
fill 413 178 646 413 179 646 minecraft:red_concrete
fill 414 178 646 415 183 646 minecraft:purple_terracotta
fill 415 178 604 415 183 604 minecraft:purple_terracotta
setblock 416 178 646 minecraft:red_concrete
fill 417 178 604 417 179 604 minecraft:red_concrete
fill 418 178 609 418 183 610 minecraft:purple_terracotta
fill 418 178 611 418 179 612 minecraft:red_concrete
setblock 418 178 620 minecraft:red_concrete
fill 418 178 621 418 183 622 minecraft:purple_terracotta
fill 418 178 623 418 179 624 minecraft:red_concrete
fill 418 178 629 418 183 630 minecraft:purple_terracotta
fill 418 178 631 418 178 632 minecraft:red_concrete
fill 418 178 633 418 183 633 minecraft:purple_terracotta
fill 418 178 641 418 183 642 minecraft:purple_terracotta
fill 418 178 643 418 179 644 minecraft:red_concrete
fill 418 178 646 418 183 646 minecraft:purple_terracotta
fill 376 179 618 376 179 619 minecraft:red_concrete
setblock 376 179 622 minecraft:red_concrete
fill 376 179 623 376 182 623 minecraft:purple_terracotta
fill 376 179 634 376 182 634 minecraft:purple_terracotta
setblock 376 179 639 minecraft:red_concrete
setblock 377 179 604 minecraft:red_concrete
fill 378 179 604 378 181 604 minecraft:purple_terracotta
setblock 380 179 646 minecraft:red_concrete
fill 382 179 604 382 182 604 minecraft:purple_terracotta
fill 384 179 646 385 182 646 minecraft:purple_terracotta
fill 393 179 604 393 182 604 minecraft:purple_terracotta
setblock 394 179 604 minecraft:red_concrete
fill 397 179 604 398 179 604 minecraft:red_concrete
setblock 401 179 646 minecraft:red_concrete
setblock 404 179 646 minecraft:red_concrete
fill 405 179 646 405 182 646 minecraft:purple_terracotta
setblock 412 179 646 minecraft:red_concrete
fill 413 179 604 414 181 604 minecraft:purple_terracotta
fill 416 179 646 416 182 646 minecraft:purple_terracotta
setblock 418 179 604 minecraft:red_concrete
setblock 418 179 615 minecraft:red_concrete
fill 418 179 620 418 182 620 minecraft:purple_terracotta
fill 418 179 631 418 182 631 minecraft:purple_terracotta
setblock 418 179 632 minecraft:red_concrete
fill 418 179 635 418 179 636 minecraft:red_concrete
fill 376 180 608 376 180 609 minecraft:red_concrete
fill 376 180 610 376 185 611 minecraft:purple_terracotta
fill 376 180 617 376 181 617 minecraft:red_concrete
fill 376 180 618 376 185 619 minecraft:purple_terracotta
setblock 376 180 620 minecraft:red_concrete
fill 376 180 622 376 185 622 minecraft:purple_terracotta
fill 376 180 628 376 181 629 minecraft:red_concrete
fill 376 180 630 376 185 631 minecraft:purple_terracotta
fill 376 180 639 376 185 639 minecraft:purple_terracotta
fill 376 180 640 376 180 641 minecraft:red_concrete
fill 376 180 642 376 185 643 minecraft:purple_terracotta
fill 377 180 604 377 185 604 minecraft:purple_terracotta
fill 377 180 605 379 180 605 minecraft:polished_blackstone
fill 377 180 607 377 180 609 minecraft:polished_blackstone
fill 377 180 611 377 180 613 minecraft:polished_blackstone
fill 377 180 615 377 180 617 minecraft:polished_blackstone
fill 377 180 619 377 180 621 minecraft:polished_blackstone
fill 377 180 623 377 180 625 minecraft:polished_blackstone
fill 377 180 627 377 180 629 minecraft:polished_blackstone
fill 377 180 631 377 180 633 minecraft:polished_blackstone
fill 377 180 635 377 180 637 minecraft:polished_blackstone
fill 377 180 639 377 180 641 minecraft:polished_blackstone
fill 377 180 643 377 180 645 minecraft:polished_blackstone
fill 378 180 646 379 181 646 minecraft:red_concrete
fill 379 180 645 381 180 645 minecraft:polished_blackstone
fill 380 180 646 381 185 646 minecraft:purple_terracotta
fill 381 180 605 383 180 605 minecraft:polished_blackstone
setblock 382 180 646 minecraft:red_concrete
fill 383 180 645 385 180 645 minecraft:polished_blackstone
fill 385 180 604 386 185 604 minecraft:purple_terracotta
fill 385 180 605 387 180 605 minecraft:polished_blackstone
fill 387 180 604 388 181 604 minecraft:red_concrete
fill 387 180 645 389 180 645 minecraft:polished_blackstone
fill 389 180 605 391 180 605 minecraft:polished_blackstone
fill 390 180 646 391 181 646 minecraft:red_concrete
fill 391 180 645 393 180 645 minecraft:polished_blackstone
fill 392 180 646 393 185 646 minecraft:purple_terracotta
fill 393 180 605 395 180 605 minecraft:polished_blackstone
fill 394 180 604 394 185 604 minecraft:purple_terracotta
fill 395 180 604 396 180 604 minecraft:red_concrete
fill 395 180 645 397 180 645 minecraft:polished_blackstone
fill 397 180 604 398 181 604 minecraft:purple_terracotta
fill 397 180 605 399 180 605 minecraft:polished_blackstone
fill 399 180 604 399 181 604 minecraft:red_concrete
fill 399 180 645 401 180 645 minecraft:polished_blackstone
fill 399 180 646 399 181 646 minecraft:red_concrete
fill 401 180 605 403 180 605 minecraft:polished_blackstone
fill 401 180 646 401 185 646 minecraft:purple_terracotta
fill 402 180 646 403 180 646 minecraft:red_concrete
fill 403 180 645 405 180 645 minecraft:polished_blackstone
fill 404 180 646 404 185 646 minecraft:purple_terracotta
fill 405 180 604 406 185 604 minecraft:purple_terracotta
fill 405 180 605 407 180 605 minecraft:polished_blackstone
fill 407 180 604 408 181 604 minecraft:red_concrete
fill 407 180 645 409 180 645 minecraft:polished_blackstone
fill 409 180 605 411 180 605 minecraft:polished_blackstone
fill 410 180 646 411 181 646 minecraft:red_concrete
fill 411 180 645 413 180 645 minecraft:polished_blackstone
fill 412 180 646 413 185 646 minecraft:purple_terracotta
fill 413 180 605 415 180 605 minecraft:polished_blackstone
fill 415 180 645 417 180 645 minecraft:polished_blackstone
setblock 416 180 604 minecraft:red_concrete
fill 417 180 604 418 185 604 minecraft:purple_terracotta
fill 417 180 605 417 180 607 minecraft:polished_blackstone
fill 417 180 609 417 180 611 minecraft:polished_blackstone
fill 417 180 613 417 180 615 minecraft:polished_blackstone
fill 417 180 617 417 180 619 minecraft:polished_blackstone
fill 417 180 621 417 180 623 minecraft:polished_blackstone
fill 417 180 625 417 180 627 minecraft:polished_blackstone
fill 417 180 629 417 180 631 minecraft:polished_blackstone
fill 417 180 633 417 180 635 minecraft:polished_blackstone
fill 417 180 637 417 180 639 minecraft:polished_blackstone
fill 417 180 641 417 180 643 minecraft:polished_blackstone
fill 418 180 605 418 181 606 minecraft:red_concrete
fill 418 180 611 418 185 612 minecraft:purple_terracotta
fill 418 180 613 418 180 614 minecraft:red_concrete
fill 418 180 615 418 185 615 minecraft:purple_terracotta
fill 418 180 623 418 185 624 minecraft:purple_terracotta
fill 418 180 625 418 181 626 minecraft:red_concrete
fill 418 180 632 418 185 632 minecraft:purple_terracotta
setblock 418 180 634 minecraft:red_concrete
fill 418 180 635 418 185 636 minecraft:purple_terracotta
fill 418 180 637 418 181 637 minecraft:red_concrete
fill 418 180 643 418 185 644 minecraft:purple_terracotta
setblock 418 180 645 minecraft:red_concrete
setblock 376 181 605 minecraft:red_concrete
setblock 376 181 608 minecraft:red_concrete
fill 376 181 609 376 184 609 minecraft:purple_terracotta
setblock 376 181 616 minecraft:red_concrete
fill 376 181 620 376 184 620 minecraft:purple_terracotta
fill 376 181 636 376 181 637 minecraft:red_concrete
setblock 376 181 640 minecraft:red_concrete
fill 376 181 641 376 184 641 minecraft:purple_terracotta
fill 379 181 604 380 181 604 minecraft:red_concrete
fill 382 181 646 382 184 646 minecraft:purple_terracotta
setblock 387 181 646 minecraft:red_concrete
fill 395 181 604 396 183 604 minecraft:purple_terracotta
setblock 398 181 646 minecraft:red_concrete
setblock 400 181 604 minecraft:red_concrete
fill 402 181 646 403 184 646 minecraft:purple_terracotta
setblock 411 181 604 minecraft:red_concrete
fill 416 181 604 416 183 604 minecraft:purple_terracotta
fill 418 181 613 418 184 613 minecraft:purple_terracotta
setblock 418 181 614 minecraft:red_concrete
fill 418 181 617 418 181 618 minecraft:red_concrete
fill 418 181 634 418 184 634 minecraft:purple_terracotta
setblock 418 181 638 minecraft:red_concrete
fill 418 181 645 418 184 645 minecraft:purple_terracotta
fill 376 182 605 376 187 605 minecraft:purple_terracotta
fill 376 182 606 376 182 607 minecraft:red_concrete
fill 376 182 608 376 187 608 minecraft:purple_terracotta
fill 376 182 614 376 183 615 minecraft:red_concrete
fill 376 182 616 376 187 617 minecraft:purple_terracotta
fill 376 182 626 376 182 627 minecraft:red_concrete
fill 376 182 628 376 187 629 minecraft:purple_terracotta
fill 376 182 635 376 183 635 minecraft:red_concrete
fill 376 182 636 376 187 637 minecraft:purple_terracotta
setblock 376 182 638 minecraft:red_concrete
fill 376 182 640 376 187 640 minecraft:purple_terracotta
fill 376 182 646 377 183 646 minecraft:red_concrete
setblock 378 182 604 minecraft:red_concrete
fill 378 182 646 379 187 646 minecraft:purple_terracotta
fill 379 182 604 380 187 604 minecraft:purple_terracotta
fill 381 182 604 381 183 604 minecraft:red_concrete
fill 387 182 604 388 187 604 minecraft:purple_terracotta
fill 387 182 646 387 187 646 minecraft:purple_terracotta
fill 388 182 646 389 182 646 minecraft:red_concrete
fill 389 182 604 390 183 604 minecraft:red_concrete
fill 390 182 646 391 187 646 minecraft:purple_terracotta
fill 396 182 646 397 183 646 minecraft:red_concrete
fill 397 182 604 397 185 604 minecraft:purple_terracotta
setblock 398 182 604 minecraft:red_concrete
fill 398 182 646 399 187 646 minecraft:purple_terracotta
fill 399 182 604 400 187 604 minecraft:purple_terracotta
setblock 400 182 646 minecraft:red_concrete
fill 401 182 604 402 183 604 minecraft:red_concrete
fill 407 182 604 408 184 604 minecraft:purple_terracotta
fill 408 182 646 409 183 646 minecraft:red_concrete
fill 409 182 604 410 182 604 minecraft:red_concrete
fill 410 182 646 411 187 646 minecraft:purple_terracotta
fill 411 182 604 411 187 604 minecraft:purple_terracotta
fill 413 182 604 413 183 604 minecraft:red_concrete
setblock 414 182 604 minecraft:purple_terracotta
fill 417 182 646 417 183 646 minecraft:red_concrete
fill 418 182 605 418 187 606 minecraft:purple_terracotta
fill 418 182 607 418 183 608 minecraft:red_concrete
fill 418 182 614 418 187 614 minecraft:purple_terracotta
setblock 418 182 616 minecraft:red_concrete
fill 418 182 617 418 187 618 minecraft:purple_terracotta
fill 418 182 619 418 183 619 minecraft:red_concrete
fill 418 182 625 418 187 626 minecraft:purple_terracotta
fill 418 182 627 418 182 628 minecraft:red_concrete
fill 418 182 637 418 187 638 minecraft:purple_terracotta
fill 418 182 639 418 183 640 minecraft:red_concrete
fill 376 183 606 376 186 607 minecraft:purple_terracotta
setblock 376 183 623 minecraft:red_concrete
setblock 376 183 626 minecraft:red_concrete
fill 376 183 627 376 186 627 minecraft:purple_terracotta
setblock 376 183 634 minecraft:red_concrete
fill 376 183 638 376 186 638 minecraft:purple_terracotta
fill 378 183 604 378 186 604 minecraft:purple_terracotta
setblock 382 183 604 minecraft:red_concrete
fill 384 183 646 385 183 646 minecraft:red_concrete
setblock 388 183 646 minecraft:red_concrete
fill 389 183 646 389 186 646 minecraft:purple_terracotta
setblock 393 183 604 minecraft:red_concrete
fill 398 183 604 398 185 604 minecraft:purple_terracotta
fill 400 183 646 400 186 646 minecraft:purple_terracotta
setblock 405 183 646 minecraft:red_concrete
fill 409 183 604 409 186 604 minecraft:purple_terracotta
setblock 410 183 604 minecraft:red_concrete
setblock 414 183 604 minecraft:red_concrete
setblock 416 183 646 minecraft:red_concrete
fill 418 183 616 418 186 616 minecraft:purple_terracotta
setblock 418 183 620 minecraft:red_concrete
fill 418 183 627 418 186 627 minecraft:purple_terracotta
setblock 418 183 628 minecraft:red_concrete
setblock 418 183 631 minecraft:red_concrete
setblock 376 184 604 minecraft:red_concrete
fill 376 184 612 376 185 613 minecraft:red_concrete
fill 376 184 614 376 189 615 minecraft:purple_terracotta
fill 376 184 621 376 185 621 minecraft:red_concrete
fill 376 184 623 376 189 623 minecraft:purple_terracotta
fill 376 184 624 376 184 625 minecraft:red_concrete
fill 376 184 626 376 189 626 minecraft:purple_terracotta
fill 376 184 632 376 185 633 minecraft:red_concrete
fill 376 184 634 376 189 635 minecraft:purple_terracotta
fill 376 184 644 376 184 645 minecraft:red_concrete
fill 376 184 646 377 189 646 minecraft:purple_terracotta
fill 381 184 604 382 189 604 minecraft:purple_terracotta
fill 383 184 604 384 185 604 minecraft:red_concrete
fill 383 184 646 383 185 646 minecraft:red_concrete
fill 384 184 646 385 189 646 minecraft:purple_terracotta
setblock 386 184 646 minecraft:red_concrete
fill 388 184 646 388 189 646 minecraft:purple_terracotta
fill 389 184 604 390 186 604 minecraft:purple_terracotta
fill 391 184 604 392 184 604 minecraft:red_concrete
fill 393 184 604 393 189 604 minecraft:purple_terracotta
fill 394 184 646 395 185 646 minecraft:red_concrete
fill 395 184 604 395 185 604 minecraft:red_concrete
setblock 396 184 604 minecraft:purple_terracotta
fill 396 184 646 397 189 646 minecraft:purple_terracotta
fill 401 184 604 402 189 604 minecraft:purple_terracotta
fill 403 184 604 404 185 604 minecraft:red_concrete
fill 405 184 646 405 189 646 minecraft:purple_terracotta
fill 406 184 646 407 184 646 minecraft:red_concrete
fill 408 184 646 409 189 646 minecraft:purple_terracotta
fill 410 184 604 410 186 604 minecraft:purple_terracotta
setblock 412 184 604 minecraft:red_concrete
fill 413 184 604 414 189 604 minecraft:purple_terracotta
fill 414 184 646 415 185 646 minecraft:red_concrete
fill 415 184 604 416 185 604 minecraft:red_concrete
fill 416 184 646 417 189 646 minecraft:purple_terracotta
fill 418 184 607 418 189 608 minecraft:purple_terracotta
fill 418 184 609 418 184 610 minecraft:red_concrete
fill 418 184 619 418 189 620 minecraft:purple_terracotta
fill 418 184 621 418 185 622 minecraft:red_concrete
fill 418 184 628 418 189 628 minecraft:purple_terracotta
fill 418 184 629 418 184 630 minecraft:red_concrete
fill 418 184 631 418 189 631 minecraft:purple_terracotta
fill 418 184 633 418 185 633 minecraft:red_concrete
fill 418 184 639 418 189 640 minecraft:purple_terracotta
fill 418 184 641 418 185 642 minecraft:red_concrete
setblock 418 184 646 minecraft:red_concrete
fill 376 185 604 376 188 604 minecraft:purple_terracotta
setblock 376 185 609 minecraft:red_concrete
setblock 376 185 620 minecraft:red_concrete
fill 376 185 624 376 188 625 minecraft:purple_terracotta
setblock 376 185 641 minecraft:red_concrete
setblock 376 185 644 minecraft:red_concrete
fill 376 185 645 376 188 645 minecraft:purple_terracotta
setblock 382 185 646 minecraft:red_concrete
fill 386 185 646 386 188 646 minecraft:purple_terracotta
fill 391 185 604 391 188 604 minecraft:purple_terracotta
setblock 392 185 604 minecraft:red_concrete
setblock 396 185 604 minecraft:red_concrete
fill 402 185 646 403 185 646 minecraft:red_concrete
setblock 406 185 646 minecraft:red_concrete
setblock 407 185 604 minecraft:red_concrete
fill 407 185 646 407 188 646 minecraft:purple_terracotta
fill 408 185 604 408 187 604 minecraft:purple_terracotta
fill 412 185 604 412 188 604 minecraft:purple_terracotta
fill 418 185 609 418 188 609 minecraft:purple_terracotta
setblock 418 185 610 minecraft:red_concrete
setblock 418 185 613 minecraft:red_concrete
fill 418 185 629 418 188 630 minecraft:purple_terracotta
setblock 418 185 634 minecraft:red_concrete
setblock 418 185 645 minecraft:red_concrete
fill 418 185 646 418 188 646 minecraft:purple_terracotta
fill 376 186 609 376 191 609 minecraft:purple_terracotta
fill 376 186 610 376 186 611 minecraft:red_concrete
fill 376 186 612 376 191 613 minecraft:purple_terracotta
fill 376 186 618 376 187 619 minecraft:red_concrete
fill 376 186 620 376 191 621 minecraft:purple_terracotta
setblock 376 186 622 minecraft:red_concrete
fill 376 186 630 376 187 631 minecraft:red_concrete
fill 376 186 632 376 191 633 minecraft:purple_terracotta
fill 376 186 639 376 187 639 minecraft:red_concrete
fill 376 186 641 376 191 641 minecraft:purple_terracotta
fill 376 186 642 376 186 643 minecraft:red_concrete
fill 376 186 644 376 191 644 minecraft:purple_terracotta
fill 377 186 604 377 187 604 minecraft:red_concrete
fill 377 186 605 379 186 605 minecraft:polished_blackstone
fill 377 186 607 377 186 609 minecraft:polished_blackstone
fill 377 186 611 377 186 613 minecraft:polished_blackstone
fill 377 186 615 377 186 617 minecraft:polished_blackstone
fill 377 186 619 377 186 621 minecraft:polished_blackstone
fill 377 186 623 377 186 625 minecraft:polished_blackstone
fill 377 186 627 377 186 629 minecraft:polished_blackstone
fill 377 186 631 377 186 633 minecraft:polished_blackstone
fill 377 186 635 377 186 637 minecraft:polished_blackstone
fill 377 186 639 377 186 641 minecraft:polished_blackstone
fill 377 186 643 377 186 645 minecraft:polished_blackstone
setblock 379 186 607 minecraft:light[level=12]
setblock 379 186 615 minecraft:light[level=12]
setblock 379 186 623 minecraft:light[level=12]
setblock 379 186 631 minecraft:light[level=12]
setblock 379 186 639 minecraft:light[level=12]
fill 379 186 645 381 186 645 minecraft:polished_blackstone
fill 380 186 646 381 187 646 minecraft:red_concrete
fill 381 186 605 383 186 605 minecraft:polished_blackstone
fill 382 186 646 383 191 646 minecraft:purple_terracotta
fill 383 186 604 384 191 604 minecraft:purple_terracotta
fill 383 186 645 385 186 645 minecraft:polished_blackstone
fill 385 186 604 386 187 604 minecraft:red_concrete
fill 385 186 605 387 186 605 minecraft:polished_blackstone
setblock 387 186 607 minecraft:light[level=12]
setblock 387 186 615 minecraft:light[level=12]
setblock 387 186 623 minecraft:light[level=12]
setblock 387 186 631 minecraft:light[level=12]
setblock 387 186 639 minecraft:light[level=12]
fill 387 186 645 389 186 645 minecraft:polished_blackstone
fill 389 186 605 391 186 605 minecraft:polished_blackstone
fill 391 186 645 393 186 645 minecraft:polished_blackstone
fill 392 186 604 392 188 604 minecraft:purple_terracotta
fill 392 186 646 393 186 646 minecraft:red_concrete
fill 393 186 605 395 186 605 minecraft:polished_blackstone
setblock 394 186 604 minecraft:red_concrete
fill 394 186 646 395 191 646 minecraft:purple_terracotta
fill 395 186 604 396 191 604 minecraft:purple_terracotta
setblock 395 186 607 minecraft:light[level=12]
setblock 395 186 615 minecraft:light[level=12]
setblock 395 186 623 minecraft:light[level=12]
setblock 395 186 631 minecraft:light[level=12]
setblock 395 186 639 minecraft:light[level=12]
fill 395 186 645 397 186 645 minecraft:polished_blackstone
fill 397 186 604 398 187 604 minecraft:red_concrete
fill 397 186 605 399 186 605 minecraft:polished_blackstone
fill 399 186 645 401 186 645 minecraft:polished_blackstone
fill 401 186 605 403 186 605 minecraft:polished_blackstone
fill 401 186 646 401 187 646 minecraft:red_concrete
fill 402 186 646 403 191 646 minecraft:purple_terracotta
fill 403 186 604 404 191 604 minecraft:purple_terracotta
setblock 403 186 607 minecraft:light[level=12]
setblock 403 186 615 minecraft:light[level=12]
setblock 403 186 623 minecraft:light[level=12]
setblock 403 186 631 minecraft:light[level=12]
setblock 403 186 639 minecraft:light[level=12]
fill 403 186 645 405 186 645 minecraft:polished_blackstone
setblock 404 186 646 minecraft:red_concrete
fill 405 186 604 406 186 604 minecraft:red_concrete
fill 405 186 605 407 186 605 minecraft:polished_blackstone
fill 406 186 646 406 191 646 minecraft:purple_terracotta
fill 407 186 604 407 187 604 minecraft:purple_terracotta
fill 407 186 645 409 186 645 minecraft:polished_blackstone
fill 409 186 605 411 186 605 minecraft:polished_blackstone
setblock 411 186 607 minecraft:light[level=12]
setblock 411 186 615 minecraft:light[level=12]
setblock 411 186 623 minecraft:light[level=12]
setblock 411 186 631 minecraft:light[level=12]
setblock 411 186 639 minecraft:light[level=12]
fill 411 186 645 413 186 645 minecraft:polished_blackstone
fill 412 186 646 413 187 646 minecraft:red_concrete
fill 413 186 605 415 186 605 minecraft:polished_blackstone
fill 414 186 646 415 191 646 minecraft:purple_terracotta
fill 415 186 604 416 191 604 minecraft:purple_terracotta
fill 415 186 645 417 186 645 minecraft:polished_blackstone
fill 417 186 604 418 187 604 minecraft:red_concrete
fill 417 186 605 417 186 607 minecraft:polished_blackstone
fill 417 186 609 417 186 611 minecraft:polished_blackstone
fill 417 186 613 417 186 615 minecraft:polished_blackstone
fill 417 186 617 417 186 619 minecraft:polished_blackstone
fill 417 186 621 417 186 623 minecraft:polished_blackstone
fill 417 186 625 417 186 627 minecraft:polished_blackstone
fill 417 186 629 417 186 631 minecraft:polished_blackstone
fill 417 186 633 417 186 635 minecraft:polished_blackstone
fill 417 186 637 417 186 639 minecraft:polished_blackstone
fill 417 186 641 417 186 643 minecraft:polished_blackstone
fill 418 186 610 418 191 610 minecraft:purple_terracotta
fill 418 186 611 418 186 612 minecraft:red_concrete
fill 418 186 613 418 191 613 minecraft:purple_terracotta
fill 418 186 615 418 187 615 minecraft:red_concrete
fill 418 186 621 418 191 622 minecraft:purple_terracotta
fill 418 186 623 418 187 624 minecraft:red_concrete
setblock 418 186 632 minecraft:red_concrete
fill 418 186 633 418 191 634 minecraft:purple_terracotta
fill 418 186 635 418 187 636 minecraft:red_concrete
fill 418 186 641 418 191 642 minecraft:purple_terracotta
fill 418 186 643 418 186 644 minecraft:red_concrete
fill 418 186 645 418 191 645 minecraft:purple_terracotta
fill 376 187 606 376 187 607 minecraft:red_concrete
setblock 376 187 610 minecraft:red_concrete
fill 376 187 611 376 190 611 minecraft:purple_terracotta
fill 376 187 622 376 190 622 minecraft:purple_terracotta
setblock 376 187 627 minecraft:red_concrete
setblock 376 187 638 minecraft:red_concrete
fill 376 187 642 376 190 643 minecraft:purple_terracotta
setblock 378 187 604 minecraft:red_concrete
setblock 389 187 604 minecraft:red_concrete
setblock 389 187 646 minecraft:red_concrete
fill 390 187 604 390 189 604 minecraft:purple_terracotta
setblock 392 187 646 minecraft:red_concrete
fill 393 187 646 393 190 646 minecraft:purple_terracotta
fill 394 187 604 394 190 604 minecraft:purple_terracotta
setblock 400 187 646 minecraft:red_concrete
fill 404 187 646 404 190 646 minecraft:purple_terracotta
fill 405 187 604 405 190 604 minecraft:purple_terracotta
setblock 406 187 604 minecraft:red_concrete
fill 409 187 604 410 187 604 minecraft:red_concrete
fill 418 187 611 418 189 612 minecraft:purple_terracotta
setblock 418 187 616 minecraft:red_concrete
setblock 418 187 627 minecraft:red_concrete
fill 418 187 632 418 190 632 minecraft:purple_terracotta
fill 418 187 643 418 190 643 minecraft:purple_terracotta
setblock 418 187 644 minecraft:red_concrete
fill 376 188 605 376 189 605 minecraft:red_concrete
fill 376 188 606 376 193 607 minecraft:purple_terracotta
setblock 376 188 608 minecraft:red_concrete
fill 376 188 610 376 193 610 minecraft:purple_terracotta
fill 376 188 616 376 189 617 minecraft:red_concrete
fill 376 188 618 376 193 619 minecraft:purple_terracotta
fill 376 188 627 376 193 627 minecraft:purple_terracotta
fill 376 188 628 376 188 629 minecraft:red_concrete
fill 376 188 630 376 193 631 minecraft:purple_terracotta
fill 376 188 636 376 189 637 minecraft:red_concrete
fill 376 188 638 376 193 639 minecraft:purple_terracotta
setblock 376 188 640 minecraft:red_concrete
fill 377 188 604 378 193 604 minecraft:purple_terracotta
fill 378 188 646 379 189 646 minecraft:red_concrete
fill 379 188 604 380 189 604 minecraft:red_concrete
fill 380 188 646 381 193 646 minecraft:purple_terracotta
fill 385 188 604 386 193 604 minecraft:purple_terracotta
fill 387 188 604 388 188 604 minecraft:red_concrete
fill 387 188 646 387 189 646 minecraft:red_concrete
fill 389 188 604 389 193 604 minecraft:purple_terracotta
fill 389 188 646 389 193 646 minecraft:purple_terracotta
fill 390 188 646 391 188 646 minecraft:red_concrete
fill 392 188 646 392 193 646 minecraft:purple_terracotta
fill 397 188 604 398 193 604 minecraft:purple_terracotta
fill 398 188 646 399 189 646 minecraft:red_concrete
fill 399 188 604 400 189 604 minecraft:red_concrete
fill 400 188 646 401 193 646 minecraft:purple_terracotta
fill 406 188 604 406 193 604 minecraft:purple_terracotta
fill 407 188 604 408 188 604 minecraft:red_concrete
fill 409 188 604 410 189 604 minecraft:purple_terracotta
fill 410 188 646 411 188 646 minecraft:red_concrete
fill 411 188 604 411 189 604 minecraft:red_concrete
fill 412 188 646 413 193 646 minecraft:purple_terracotta
fill 417 188 604 418 193 604 minecraft:purple_terracotta
fill 418 188 605 418 189 606 minecraft:red_concrete
setblock 418 188 614 minecraft:red_concrete
fill 418 188 615 418 193 616 minecraft:purple_terracotta
fill 418 188 617 418 189 618 minecraft:red_concrete
fill 418 188 623 418 193 624 minecraft:purple_terracotta
fill 418 188 625 418 188 626 minecraft:red_concrete
fill 418 188 627 418 193 627 minecraft:purple_terracotta
fill 418 188 635 418 193 636 minecraft:purple_terracotta
fill 418 188 637 418 189 638 minecraft:red_concrete
fill 418 188 644 418 193 644 minecraft:purple_terracotta
setblock 376 189 604 minecraft:red_concrete
fill 376 189 608 376 192 608 minecraft:purple_terracotta
fill 376 189 624 376 189 625 minecraft:red_concrete
setblock 376 189 628 minecraft:red_concrete
fill 376 189 629 376 192 629 minecraft:purple_terracotta
fill 376 189 640 376 192 640 minecraft:purple_terracotta
setblock 376 189 645 minecraft:red_concrete
setblock 386 189 646 minecraft:red_concrete
fill 387 189 604 387 192 604 minecraft:purple_terracotta
setblock 388 189 604 minecraft:red_concrete
fill 390 189 646 391 192 646 minecraft:purple_terracotta
fill 391 189 604 392 189 604 minecraft:red_concrete
fill 407 189 604 408 191 604 minecraft:purple_terracotta
setblock 407 189 646 minecraft:red_concrete
setblock 410 189 646 minecraft:red_concrete
fill 411 189 646 411 192 646 minecraft:purple_terracotta
setblock 412 189 604 minecraft:red_concrete
setblock 418 189 609 minecraft:red_concrete
fill 418 189 614 418 191 614 minecraft:purple_terracotta
fill 418 189 625 418 192 625 minecraft:purple_terracotta
setblock 418 189 626 minecraft:red_concrete
fill 418 189 629 418 189 630 minecraft:red_concrete
setblock 418 189 646 minecraft:red_concrete
fill 376 190 604 376 195 605 minecraft:purple_terracotta
fill 376 190 614 376 190 615 minecraft:red_concrete
fill 376 190 616 376 195 617 minecraft:purple_terracotta
fill 376 190 623 376 191 623 minecraft:red_concrete
fill 376 190 624 376 195 625 minecraft:purple_terracotta
setblock 376 190 626 minecraft:red_concrete
fill 376 190 628 376 195 628 minecraft:purple_terracotta
fill 376 190 634 376 191 635 minecraft:red_concrete
fill 376 190 636 376 195 637 minecraft:purple_terracotta
fill 376 190 645 376 195 645 minecraft:purple_terracotta
fill 376 190 646 377 190 646 minecraft:red_concrete
fill 378 190 646 379 195 646 minecraft:purple_terracotta
fill 379 190 604 380 195 604 minecraft:purple_terracotta
fill 381 190 604 382 191 604 minecraft:red_concrete
fill 384 190 646 385 191 646 minecraft:red_concrete
fill 386 190 646 387 195 646 minecraft:purple_terracotta
fill 388 190 604 388 195 604 minecraft:purple_terracotta
setblock 388 190 646 minecraft:red_concrete
setblock 390 190 604 minecraft:red_concrete
fill 391 190 604 392 195 604 minecraft:purple_terracotta
fill 393 190 604 393 191 604 minecraft:red_concrete
fill 396 190 646 397 191 646 minecraft:red_concrete
fill 398 190 646 399 195 646 minecraft:purple_terracotta
fill 399 190 604 400 195 604 minecraft:purple_terracotta
fill 401 190 604 402 191 604 minecraft:red_concrete
fill 405 190 646 405 191 646 minecraft:red_concrete
fill 407 190 646 407 195 646 minecraft:purple_terracotta
fill 408 190 646 409 190 646 minecraft:red_concrete
fill 409 190 604 409 193 604 minecraft:purple_terracotta
setblock 410 190 604 minecraft:red_concrete
fill 410 190 646 410 195 646 minecraft:purple_terracotta
fill 411 190 604 412 195 604 minecraft:purple_terracotta
fill 413 190 604 414 191 604 minecraft:red_concrete
fill 416 190 646 417 191 646 minecraft:red_concrete
fill 418 190 605 418 192 606 minecraft:purple_terracotta
fill 418 190 607 418 190 608 minecraft:red_concrete
fill 418 190 609 418 195 609 minecraft:purple_terracotta
fill 418 190 611 418 191 611 minecraft:red_concrete
setblock 418 190 612 minecraft:purple_terracotta
fill 418 190 617 418 195 618 minecraft:purple_terracotta
fill 418 190 619 418 191 620 minecraft:red_concrete
fill 418 190 626 418 195 626 minecraft:purple_terracotta
setblock 418 190 628 minecraft:red_concrete
fill 418 190 629 418 195 630 minecraft:purple_terracotta
fill 418 190 631 418 191 631 minecraft:red_concrete
fill 418 190 637 418 195 638 minecraft:purple_terracotta
fill 418 190 639 418 190 640 minecraft:red_concrete
fill 418 190 646 418 195 646 minecraft:purple_terracotta
setblock 376 191 611 minecraft:red_concrete
setblock 376 191 614 minecraft:red_concrete
fill 376 191 615 376 194 615 minecraft:purple_terracotta
setblock 376 191 622 minecraft:red_concrete
fill 376 191 626 376 194 626 minecraft:purple_terracotta
fill 376 191 642 376 191 643 minecraft:red_concrete
setblock 376 191 646 minecraft:red_concrete
fill 377 191 646 377 194 646 minecraft:purple_terracotta
fill 388 191 646 388 194 646 minecraft:purple_terracotta
fill 390 191 604 390 194 604 minecraft:purple_terracotta
setblock 393 191 646 minecraft:red_concrete
setblock 394 191 604 minecraft:red_concrete
setblock 404 191 646 minecraft:red_concrete
setblock 405 191 604 minecraft:red_concrete
fill 408 191 646 409 194 646 minecraft:purple_terracotta
fill 410 191 604 410 193 604 minecraft:purple_terracotta
fill 418 191 607 418 194 607 minecraft:purple_terracotta
setblock 418 191 608 minecraft:red_concrete
setblock 418 191 612 minecraft:red_concrete
fill 418 191 628 418 194 628 minecraft:purple_terracotta
setblock 418 191 632 minecraft:red_concrete
fill 418 191 639 418 194 639 minecraft:purple_terracotta
setblock 418 191 640 minecraft:red_concrete
setblock 418 191 643 minecraft:red_concrete
fill 376 192 609 376 193 609 minecraft:red_concrete
fill 376 192 611 376 197 611 minecraft:purple_terracotta
fill 376 192 612 376 192 613 minecraft:red_concrete
fill 376 192 614 376 197 614 minecraft:purple_terracotta
fill 376 192 620 376 193 621 minecraft:red_concrete
fill 376 192 622 376 197 623 minecraft:purple_terracotta
fill 376 192 632 376 192 633 minecraft:red_concrete
fill 376 192 634 376 197 635 minecraft:purple_terracotta
fill 376 192 641 376 193 641 minecraft:red_concrete
fill 376 192 642 376 197 643 minecraft:purple_terracotta
setblock 376 192 644 minecraft:red_concrete
fill 376 192 646 376 197 646 minecraft:purple_terracotta
fill 377 192 605 379 192 605 minecraft:polished_blackstone
fill 377 192 607 377 192 609 minecraft:polished_blackstone
fill 377 192 611 377 192 613 minecraft:polished_blackstone
fill 377 192 615 377 192 617 minecraft:polished_blackstone
fill 377 192 619 377 192 621 minecraft:polished_blackstone
fill 377 192 623 377 192 625 minecraft:polished_blackstone
fill 377 192 627 377 192 629 minecraft:polished_blackstone
fill 377 192 631 377 192 633 minecraft:polished_blackstone
fill 377 192 635 377 192 637 minecraft:polished_blackstone
fill 377 192 639 377 192 641 minecraft:polished_blackstone
fill 377 192 643 377 192 645 minecraft:polished_blackstone
fill 379 192 645 381 192 645 minecraft:polished_blackstone
fill 381 192 604 382 197 604 minecraft:purple_terracotta
fill 381 192 605 383 192 605 minecraft:polished_blackstone
fill 382 192 646 383 193 646 minecraft:red_concrete
fill 383 192 604 384 192 604 minecraft:red_concrete
fill 383 192 645 385 192 645 minecraft:polished_blackstone
fill 384 192 646 385 197 646 minecraft:purple_terracotta
fill 385 192 605 387 192 605 minecraft:polished_blackstone
fill 387 192 645 389 192 645 minecraft:polished_blackstone
fill 389 192 605 391 192 605 minecraft:polished_blackstone
fill 391 192 645 393 192 645 minecraft:polished_blackstone
fill 393 192 604 394 197 604 minecraft:purple_terracotta
fill 393 192 605 395 192 605 minecraft:polished_blackstone
fill 393 192 646 393 197 646 minecraft:purple_terracotta
fill 394 192 646 395 192 646 minecraft:red_concrete
fill 395 192 604 396 193 604 minecraft:red_concrete
fill 395 192 645 397 192 645 minecraft:polished_blackstone
fill 396 192 646 397 197 646 minecraft:purple_terracotta
fill 397 192 605 399 192 605 minecraft:polished_blackstone
fill 399 192 645 401 192 645 minecraft:polished_blackstone
fill 401 192 604 402 194 604 minecraft:purple_terracotta
fill 401 192 605 403 192 605 minecraft:polished_blackstone
fill 402 192 646 403 193 646 minecraft:red_concrete
fill 403 192 604 404 192 604 minecraft:red_concrete
fill 403 192 645 405 192 645 minecraft:polished_blackstone
fill 404 192 646 405 197 646 minecraft:purple_terracotta
fill 405 192 604 405 197 604 minecraft:purple_terracotta
fill 405 192 605 407 192 605 minecraft:polished_blackstone
setblock 406 192 646 minecraft:red_concrete
fill 407 192 604 407 193 604 minecraft:red_concrete
fill 407 192 645 409 192 645 minecraft:polished_blackstone
setblock 408 192 604 minecraft:purple_terracotta
fill 409 192 605 411 192 605 minecraft:polished_blackstone
fill 411 192 645 413 192 645 minecraft:polished_blackstone
fill 413 192 604 414 197 604 minecraft:purple_terracotta
fill 413 192 605 415 192 605 minecraft:polished_blackstone
fill 414 192 646 415 193 646 minecraft:red_concrete
fill 415 192 604 416 193 604 minecraft:red_concrete
fill 415 192 645 417 192 645 minecraft:polished_blackstone
fill 416 192 646 417 197 646 minecraft:purple_terracotta
fill 417 192 605 417 192 607 minecraft:polished_blackstone
fill 417 192 609 417 192 611 minecraft:polished_blackstone
fill 417 192 613 417 192 615 minecraft:polished_blackstone
fill 417 192 617 417 192 619 minecraft:polished_blackstone
fill 417 192 621 417 192 623 minecraft:polished_blackstone
fill 417 192 625 417 192 627 minecraft:polished_blackstone
fill 417 192 629 417 192 631 minecraft:polished_blackstone
fill 417 192 633 417 192 635 minecraft:polished_blackstone
fill 417 192 637 417 192 639 minecraft:polished_blackstone
fill 417 192 641 417 192 643 minecraft:polished_blackstone
fill 418 192 608 418 194 608 minecraft:purple_terracotta
setblock 418 192 610 minecraft:red_concrete
fill 418 192 611 418 197 612 minecraft:purple_terracotta
fill 418 192 613 418 193 614 minecraft:red_concrete
fill 418 192 619 418 197 620 minecraft:purple_terracotta
fill 418 192 621 418 192 622 minecraft:red_concrete
fill 418 192 631 418 197 632 minecraft:purple_terracotta
fill 418 192 633 418 193 634 minecraft:red_concrete
fill 418 192 640 418 197 640 minecraft:purple_terracotta
fill 418 192 641 418 192 642 minecraft:red_concrete
fill 418 192 643 418 197 643 minecraft:purple_terracotta
fill 418 192 645 418 193 645 minecraft:red_concrete
setblock 376 193 608 minecraft:red_concrete
fill 376 193 612 376 196 613 minecraft:purple_terracotta
setblock 376 193 629 minecraft:red_concrete
setblock 376 193 632 minecraft:red_concrete
fill 376 193 633 376 196 633 minecraft:purple_terracotta
setblock 376 193 640 minecraft:red_concrete
fill 376 193 644 376 196 644 minecraft:purple_terracotta
fill 383 193 604 383 196 604 minecraft:purple_terracotta
setblock 384 193 604 minecraft:red_concrete
setblock 387 193 604 minecraft:red_concrete
fill 390 193 646 391 193 646 minecraft:red_concrete
setblock 394 193 646 minecraft:red_concrete
fill 395 193 646 395 196 646 minecraft:purple_terracotta
fill 403 193 604 403 196 604 minecraft:purple_terracotta
setblock 404 193 604 minecraft:red_concrete
fill 406 193 646 406 196 646 minecraft:purple_terracotta
setblock 408 193 604 minecraft:red_concrete
setblock 411 193 646 minecraft:red_concrete
setblock 418 193 605 minecraft:red_concrete
fill 418 193 606 418 195 606 minecraft:purple_terracotta
fill 418 193 610 418 196 610 minecraft:purple_terracotta
fill 418 193 621 418 196 621 minecraft:purple_terracotta
setblock 418 193 622 minecraft:red_concrete
setblock 418 193 625 minecraft:red_concrete
fill 418 193 641 418 196 642 minecraft:purple_terracotta
fill 376 194 606 376 195 607 minecraft:red_concrete
fill 376 194 608 376 205 609 minecraft:purple_terracotta
setblock 376 194 610 minecraft:red_concrete
fill 376 194 618 376 195 619 minecraft:red_concrete
fill 376 194 620 376 204 621 minecraft:purple_terracotta
fill 376 194 627 376 195 627 minecraft:red_concrete
fill 376 194 629 376 207 629 minecraft:purple_terracotta
fill 376 194 630 376 194 631 minecraft:red_concrete
fill 376 194 632 376 207 632 minecraft:purple_terracotta
fill 376 194 638 376 195 639 minecraft:red_concrete
fill 376 194 640 376 205 641 minecraft:purple_terracotta
fill 377 194 604 378 195 604 minecraft:red_concrete
setblock 379 194 607 minecraft:light[level=12]
setblock 379 194 615 minecraft:light[level=12]
setblock 379 194 623 minecraft:light[level=12]
setblock 379 194 631 minecraft:light[level=12]
setblock 379 194 639 minecraft:light[level=12]
fill 380 194 646 381 194 646 minecraft:red_concrete
fill 382 194 646 383 203 646 minecraft:purple_terracotta
fill 384 194 604 384 207 604 minecraft:purple_terracotta
fill 385 194 604 386 194 604 minecraft:red_concrete
fill 387 194 604 387 204 604 minecraft:purple_terracotta
setblock 387 194 607 minecraft:light[level=12]
setblock 387 194 615 minecraft:light[level=12]
setblock 387 194 623 minecraft:light[level=12]
setblock 387 194 631 minecraft:light[level=12]
setblock 387 194 639 minecraft:light[level=12]
fill 389 194 604 389 195 604 minecraft:red_concrete
fill 389 194 646 389 195 646 minecraft:red_concrete
fill 390 194 646 391 207 646 minecraft:purple_terracotta
fill 392 194 640 393 199 642 minecraft:light_blue_concrete
setblock 392 194 646 minecraft:red_concrete
fill 394 194 646 394 207 646 minecraft:purple_terracotta
fill 395 194 604 396 204 604 minecraft:purple_terracotta
setblock 395 194 607 minecraft:light[level=12]
setblock 395 194 615 minecraft:light[level=12]
setblock 395 194 623 minecraft:light[level=12]
setblock 395 194 631 minecraft:light[level=12]
setblock 395 194 639 minecraft:light[level=12]
fill 397 194 604 398 195 604 minecraft:red_concrete
fill 400 194 646 401 195 646 minecraft:red_concrete
fill 402 194 646 403 203 646 minecraft:purple_terracotta
setblock 403 194 607 minecraft:light[level=12]
setblock 403 194 615 minecraft:light[level=12]
setblock 403 194 623 minecraft:light[level=12]
setblock 403 194 631 minecraft:light[level=12]
setblock 403 194 639 minecraft:light[level=12]
fill 404 194 604 404 196 604 minecraft:purple_terracotta
setblock 406 194 604 minecraft:red_concrete
fill 407 194 604 408 207 604 minecraft:purple_terracotta
fill 409 194 604 410 195 604 minecraft:red_concrete
setblock 411 194 607 minecraft:light[level=12]
setblock 411 194 615 minecraft:light[level=12]
setblock 411 194 623 minecraft:light[level=12]
setblock 411 194 631 minecraft:light[level=12]
setblock 411 194 639 minecraft:light[level=12]
fill 411 194 646 411 207 646 minecraft:purple_terracotta
fill 412 194 646 413 194 646 minecraft:red_concrete
fill 414 194 646 415 207 646 minecraft:purple_terracotta
fill 415 194 604 416 207 604 minecraft:purple_terracotta
fill 417 194 604 418 194 604 minecraft:red_concrete
fill 418 194 605 418 195 605 minecraft:purple_terracotta
fill 418 194 613 418 203 614 minecraft:purple_terracotta
fill 418 194 615 418 195 616 minecraft:red_concrete
fill 418 194 622 418 203 622 minecraft:purple_terracotta
fill 418 194 623 418 194 624 minecraft:red_concrete
fill 418 194 625 418 204 625 minecraft:purple_terracotta
fill 418 194 627 418 195 627 minecraft:red_concrete
fill 418 194 633 418 204 634 minecraft:purple_terracotta
fill 418 194 635 418 195 636 minecraft:red_concrete
setblock 418 194 644 minecraft:red_concrete
fill 418 194 645 418 204 645 minecraft:purple_terracotta
fill 376 195 610 376 198 610 minecraft:purple_terracotta
setblock 376 195 615 minecraft:red_concrete
setblock 376 195 626 minecraft:red_concrete
fill 376 195 630 376 198 631 minecraft:purple_terracotta
setblock 377 195 646 minecraft:red_concrete
setblock 380 195 646 minecraft:red_concrete
fill 381 195 646 381 198 646 minecraft:purple_terracotta
fill 385 195 604 386 198 604 minecraft:purple_terracotta
setblock 388 195 646 minecraft:red_concrete
setblock 390 195 604 minecraft:red_concrete
fill 391 195 640 391 198 642 minecraft:light_blue_concrete
fill 392 195 639 393 198 639 minecraft:light_blue_concrete
fill 392 195 643 393 198 643 minecraft:light_blue_concrete
fill 392 195 646 392 198 646 minecraft:purple_terracotta
fill 394 195 640 394 198 642 minecraft:light_blue_concrete
setblock 401 195 604 minecraft:red_concrete
fill 402 195 604 402 197 604 minecraft:purple_terracotta
fill 406 195 604 406 198 604 minecraft:purple_terracotta
fill 408 195 646 409 195 646 minecraft:red_concrete
setblock 412 195 646 minecraft:red_concrete
fill 413 195 646 413 198 646 minecraft:purple_terracotta
fill 417 195 604 417 198 604 minecraft:purple_terracotta
setblock 418 195 604 minecraft:red_concrete
fill 418 195 607 418 195 608 minecraft:red_concrete
fill 418 195 623 418 197 624 minecraft:purple_terracotta
setblock 418 195 628 minecraft:red_concrete
setblock 418 195 639 minecraft:red_concrete
fill 418 195 644 418 198 644 minecraft:purple_terracotta
fill 376 196 604 376 197 605 minecraft:red_concrete
fill 376 196 606 376 203 607 minecraft:purple_terracotta
fill 376 196 615 376 203 615 minecraft:purple_terracotta
fill 376 196 616 376 196 617 minecraft:red_concrete
fill 376 196 618 376 207 619 minecraft:purple_terracotta
fill 376 196 624 376 197 625 minecraft:red_concrete
fill 376 196 626 376 204 627 minecraft:purple_terracotta
setblock 376 196 628 minecraft:red_concrete
fill 376 196 636 376 197 637 minecraft:red_concrete
fill 376 196 638 376 205 639 minecraft:purple_terracotta
fill 376 196 645 376 197 645 minecraft:red_concrete
fill 377 196 604 378 203 604 minecraft:purple_terracotta
fill 377 196 646 377 204 646 minecraft:purple_terracotta
fill 378 196 646 379 196 646 minecraft:red_concrete
fill 379 196 604 380 197 604 minecraft:red_concrete
fill 380 196 646 380 203 646 minecraft:purple_terracotta
fill 386 196 646 387 197 646 minecraft:red_concrete
setblock 388 196 604 minecraft:red_concrete
fill 388 196 646 389 207 646 minecraft:purple_terracotta
fill 389 196 604 390 207 604 minecraft:purple_terracotta
fill 390 196 641 390 197 642 minecraft:light_blue_concrete
fill 391 196 604 392 197 604 minecraft:red_concrete
fill 391 196 639 391 197 639 minecraft:light_blue_concrete
fill 391 196 643 391 197 643 minecraft:light_blue_concrete
fill 394 196 639 394 197 639 minecraft:light_blue_concrete
fill 394 196 643 394 197 643 minecraft:light_blue_concrete
fill 395 196 640 395 197 642 minecraft:light_blue_concrete
fill 397 196 604 398 203 604 minecraft:purple_terracotta
fill 398 196 646 399 196 646 minecraft:red_concrete
fill 399 196 604 400 196 604 minecraft:red_concrete
fill 400 196 646 401 207 646 minecraft:purple_terracotta
fill 401 196 604 401 207 604 minecraft:purple_terracotta
fill 407 196 646 407 197 646 minecraft:red_concrete
fill 408 196 646 409 207 646 minecraft:purple_terracotta
fill 409 196 604 410 207 604 minecraft:purple_terracotta
setblock 410 196 646 minecraft:red_concrete
fill 411 196 604 412 197 604 minecraft:red_concrete
fill 412 196 646 412 207 646 minecraft:purple_terracotta
fill 418 196 604 418 209 604 minecraft:purple_terracotta
fill 418 196 605 418 196 606 minecraft:red_concrete
fill 418 196 607 418 197 608 minecraft:purple_terracotta
fill 418 196 609 418 197 609 minecraft:red_concrete
fill 418 196 615 418 204 616 minecraft:purple_terracotta
fill 418 196 617 418 197 618 minecraft:red_concrete
setblock 418 196 626 minecraft:red_concrete
fill 418 196 627 418 203 628 minecraft:purple_terracotta
fill 418 196 629 418 197 630 minecraft:red_concrete
fill 418 196 635 418 203 636 minecraft:purple_terracotta
fill 418 196 637 418 196 638 minecraft:red_concrete
fill 418 196 639 418 207 639 minecraft:purple_terracotta
fill 418 196 646 418 197 646 minecraft:red_concrete
fill 376 197 612 376 197 613 minecraft:red_concrete
setblock 376 197 616 minecraft:red_concrete
fill 376 197 617 376 207 617 minecraft:purple_terracotta
fill 376 197 628 376 207 628 minecraft:purple_terracotta
setblock 376 197 633 minecraft:red_concrete
setblock 376 197 644 minecraft:red_concrete
fill 378 197 646 379 207 646 minecraft:purple_terracotta
setblock 383 197 604 minecraft:red_concrete
fill 388 197 604 388 207 604 minecraft:purple_terracotta
setblock 395 197 646 minecraft:red_concrete
setblock 398 197 646 minecraft:red_concrete
fill 399 197 604 399 207 604 minecraft:purple_terracotta
fill 399 197 646 399 207 646 minecraft:purple_terracotta
setblock 400 197 604 minecraft:red_concrete
fill 400 197 614 401 198 615 minecraft:magma_block
fill 403 197 604 404 197 604 minecraft:red_concrete
setblock 406 197 646 minecraft:red_concrete
fill 410 197 646 410 207 646 minecraft:purple_terracotta
fill 418 197 605 418 204 606 minecraft:purple_terracotta
setblock 418 197 610 minecraft:red_concrete
setblock 418 197 621 minecraft:red_concrete
fill 418 197 626 418 204 626 minecraft:purple_terracotta
fill 418 197 637 418 208 637 minecraft:purple_terracotta
setblock 418 197 638 minecraft:red_concrete
fill 418 197 641 418 197 642 minecraft:red_concrete
fill 376 198 604 376 204 605 minecraft:purple_terracotta
fill 376 198 611 376 199 611 minecraft:red_concrete
fill 376 198 612 376 205 613 minecraft:purple_terracotta
setblock 376 198 614 minecraft:red_concrete
fill 376 198 616 376 208 616 minecraft:purple_terracotta
fill 376 198 622 376 199 623 minecraft:red_concrete
fill 376 198 624 376 207 625 minecraft:purple_terracotta
fill 376 198 633 376 208 633 minecraft:purple_terracotta
fill 376 198 634 376 198 635 minecraft:red_concrete
fill 376 198 636 376 205 637 minecraft:purple_terracotta
fill 376 198 642 376 199 643 minecraft:red_concrete
fill 376 198 644 376 207 645 minecraft:purple_terracotta
setblock 376 198 646 minecraft:red_concrete
fill 377 198 605 379 198 605 minecraft:polished_blackstone
fill 377 198 607 377 198 609 minecraft:polished_blackstone
fill 377 198 611 377 198 613 minecraft:polished_blackstone
fill 377 198 615 377 198 617 minecraft:polished_blackstone
fill 377 198 619 377 198 621 minecraft:polished_blackstone
fill 377 198 623 377 198 625 minecraft:polished_blackstone
fill 377 198 627 377 198 629 minecraft:polished_blackstone
fill 377 198 631 377 198 633 minecraft:polished_blackstone
fill 377 198 635 377 198 637 minecraft:polished_blackstone
fill 377 198 639 377 198 641 minecraft:polished_blackstone
fill 377 198 643 377 198 645 minecraft:polished_blackstone
fill 379 198 604 380 203 604 minecraft:purple_terracotta
fill 379 198 645 381 198 645 minecraft:polished_blackstone
fill 381 198 604 382 198 604 minecraft:red_concrete
fill 381 198 605 383 198 605 minecraft:polished_blackstone
fill 383 198 604 383 207 604 minecraft:purple_terracotta
fill 383 198 645 385 198 645 minecraft:polished_blackstone
fill 384 198 646 385 199 646 minecraft:red_concrete
fill 385 198 605 387 198 605 minecraft:polished_blackstone
fill 386 198 646 387 203 646 minecraft:purple_terracotta
fill 387 198 645 389 198 645 minecraft:polished_blackstone
fill 389 198 605 391 198 605 minecraft:polished_blackstone
fill 391 198 604 392 205 604 minecraft:purple_terracotta
fill 391 198 645 393 198 645 minecraft:polished_blackstone
fill 393 198 604 394 199 604 minecraft:red_concrete
fill 393 198 605 395 198 605 minecraft:polished_blackstone
fill 393 198 646 393 199 646 minecraft:red_concrete
fill 395 198 645 397 198 645 minecraft:polished_blackstone
fill 395 198 646 395 207 646 minecraft:purple_terracotta
fill 396 198 646 397 198 646 minecraft:red_concrete
fill 397 198 605 399 198 605 minecraft:polished_blackstone
fill 398 198 646 398 204 646 minecraft:purple_terracotta
fill 399 198 645 401 198 645 minecraft:polished_blackstone
fill 400 198 604 400 207 604 minecraft:purple_terracotta
fill 401 198 605 403 198 605 minecraft:polished_blackstone
setblock 402 198 604 minecraft:red_concrete
fill 403 198 604 404 207 604 minecraft:purple_terracotta
fill 403 198 645 405 198 645 minecraft:polished_blackstone
fill 404 198 646 405 199 646 minecraft:red_concrete
fill 405 198 604 405 199 604 minecraft:red_concrete
fill 405 198 605 407 198 605 minecraft:polished_blackstone
fill 406 198 646 407 207 646 minecraft:purple_terracotta
fill 407 198 645 409 198 645 minecraft:polished_blackstone
fill 409 198 605 411 198 605 minecraft:polished_blackstone
fill 411 198 604 412 205 604 minecraft:purple_terracotta
fill 411 198 645 413 198 645 minecraft:polished_blackstone
fill 413 198 604 414 199 604 minecraft:red_concrete
fill 413 198 605 415 198 605 minecraft:polished_blackstone
fill 415 198 645 417 198 645 minecraft:polished_blackstone
fill 416 198 646 417 198 646 minecraft:red_concrete
fill 417 198 605 417 198 607 minecraft:polished_blackstone
fill 417 198 609 417 198 611 minecraft:polished_blackstone
fill 417 198 613 417 198 615 minecraft:polished_blackstone
fill 417 198 617 417 198 619 minecraft:polished_blackstone
fill 417 198 621 417 198 623 minecraft:polished_blackstone
fill 417 198 625 417 198 627 minecraft:polished_blackstone
fill 417 198 629 417 198 631 minecraft:polished_blackstone
fill 417 198 633 417 198 635 minecraft:polished_blackstone
fill 417 198 637 417 198 639 minecraft:polished_blackstone
fill 417 198 641 417 198 643 minecraft:polished_blackstone
fill 418 198 607 418 203 607 minecraft:purple_terracotta
setblock 418 198 608 minecraft:red_concrete
fill 418 198 609 418 204 610 minecraft:purple_terracotta
fill 418 198 611 418 199 612 minecraft:red_concrete
fill 418 198 617 418 203 618 minecraft:purple_terracotta
fill 418 198 619 418 198 620 minecraft:red_concrete
fill 418 198 621 418 204 621 minecraft:purple_terracotta
fill 418 198 623 418 199 623 minecraft:red_concrete
setblock 418 198 624 minecraft:purple_terracotta
fill 418 198 629 418 204 630 minecraft:purple_terracotta
fill 418 198 631 418 199 632 minecraft:red_concrete
fill 418 198 638 418 203 638 minecraft:purple_terracotta
setblock 418 198 640 minecraft:red_concrete
fill 418 198 641 418 207 642 minecraft:purple_terracotta
fill 418 198 643 418 199 643 minecraft:red_concrete
fill 418 198 646 418 203 646 minecraft:purple_terracotta
setblock 376 199 610 minecraft:red_concrete
fill 376 199 614 376 205 614 minecraft:purple_terracotta
fill 376 199 630 376 199 631 minecraft:red_concrete
setblock 376 199 634 minecraft:red_concrete
fill 376 199 635 376 207 635 minecraft:purple_terracotta
fill 376 199 646 376 203 646 minecraft:purple_terracotta
fill 381 199 604 381 205 604 minecraft:purple_terracotta
setblock 381 199 646 minecraft:red_concrete
setblock 382 199 604 minecraft:red_concrete
fill 385 199 604 386 199 604 minecraft:red_concrete
setblock 392 199 646 minecraft:red_concrete
fill 396 199 646 397 205 646 minecraft:purple_terracotta
fill 402 199 604 402 204 604 minecraft:purple_terracotta
setblock 406 199 604 minecraft:red_concrete
setblock 413 199 646 minecraft:red_concrete
setblock 416 199 646 minecraft:red_concrete
setblock 417 199 604 minecraft:red_concrete
fill 417 199 646 417 204 646 minecraft:purple_terracotta
fill 418 199 608 418 204 608 minecraft:purple_terracotta
fill 418 199 619 418 204 619 minecraft:purple_terracotta
setblock 418 199 620 minecraft:red_concrete
setblock 418 199 624 minecraft:red_concrete
fill 418 199 640 418 207 640 minecraft:purple_terracotta
setblock 418 199 644 minecraft:red_concrete
fill 376 200 610 376 207 611 minecraft:purple_terracotta
fill 376 200 622 376 203 623 minecraft:purple_terracotta
fill 376 200 630 376 207 631 minecraft:purple_terracotta
fill 376 200 634 376 205 634 minecraft:purple_terracotta
fill 376 200 642 376 207 643 minecraft:purple_terracotta
fill 381 200 646 381 207 646 minecraft:purple_terracotta
fill 382 200 604 382 207 604 minecraft:purple_terracotta
fill 384 200 646 385 207 646 minecraft:purple_terracotta
fill 385 200 604 386 207 604 minecraft:purple_terracotta
fill 392 200 646 393 203 646 minecraft:purple_terracotta
fill 393 200 604 394 207 604 minecraft:purple_terracotta
fill 404 200 646 405 207 646 minecraft:purple_terracotta
fill 405 200 604 406 207 604 minecraft:purple_terracotta
fill 413 200 604 414 207 604 minecraft:purple_terracotta
fill 413 200 646 413 207 646 minecraft:purple_terracotta
fill 416 200 646 416 207 646 minecraft:purple_terracotta
fill 417 200 604 417 207 604 minecraft:purple_terracotta
fill 418 200 611 418 203 612 minecraft:purple_terracotta
fill 418 200 620 418 204 620 minecraft:purple_terracotta
fill 418 200 623 418 204 624 minecraft:purple_terracotta
fill 418 200 631 418 203 632 minecraft:purple_terracotta
fill 418 200 643 418 207 644 minecraft:purple_terracotta
setblock 379 202 607 minecraft:light[level=12]
setblock 379 202 615 minecraft:light[level=12]
setblock 379 202 623 minecraft:light[level=12]
setblock 379 202 631 minecraft:light[level=12]
setblock 379 202 639 minecraft:light[level=12]
setblock 387 202 607 minecraft:light[level=12]
setblock 387 202 615 minecraft:light[level=12]
setblock 387 202 623 minecraft:light[level=12]
setblock 387 202 631 minecraft:light[level=12]
setblock 387 202 639 minecraft:light[level=12]
setblock 395 202 607 minecraft:light[level=12]
setblock 395 202 615 minecraft:light[level=12]
setblock 395 202 623 minecraft:light[level=12]
setblock 395 202 631 minecraft:light[level=12]
setblock 395 202 639 minecraft:light[level=12]
setblock 403 202 607 minecraft:light[level=12]
setblock 403 202 615 minecraft:light[level=12]
setblock 403 202 623 minecraft:light[level=12]
setblock 403 202 631 minecraft:light[level=12]
setblock 403 202 639 minecraft:light[level=12]
setblock 411 202 607 minecraft:light[level=12]
setblock 411 202 615 minecraft:light[level=12]
setblock 411 202 623 minecraft:light[level=12]
setblock 411 202 631 minecraft:light[level=12]
setblock 411 202 639 minecraft:light[level=12]
fill 376 204 606 376 207 606 minecraft:purple_terracotta
setblock 376 204 607 minecraft:black_concrete
setblock 376 204 615 minecraft:black_concrete
fill 376 204 622 376 207 622 minecraft:purple_terracotta
setblock 376 204 623 minecraft:black_concrete
setblock 376 204 646 minecraft:black_concrete
fill 377 204 604 377 206 604 minecraft:black_concrete
fill 378 204 604 379 207 604 minecraft:purple_terracotta
setblock 380 204 604 minecraft:black_concrete
setblock 380 204 646 minecraft:black_concrete
fill 382 204 646 382 205 646 minecraft:black_concrete
fill 383 204 646 383 207 646 minecraft:purple_terracotta
setblock 386 204 646 minecraft:black_concrete
setblock 387 204 646 minecraft:purple_terracotta
setblock 392 204 646 minecraft:black_concrete
fill 393 204 646 393 205 646 minecraft:purple_terracotta
fill 395 204 621 397 204 623 minecraft:redstone_block
fill 395 204 627 397 204 629 minecraft:redstone_block
fill 397 204 604 397 207 604 minecraft:purple_terracotta
setblock 398 204 604 minecraft:black_concrete
fill 400 204 629 402 204 631 minecraft:redstone_block
fill 402 204 620 404 204 622 minecraft:redstone_block
fill 402 204 646 402 207 646 minecraft:purple_terracotta
setblock 403 204 646 minecraft:black_concrete
setblock 418 204 607 minecraft:black_concrete
fill 418 204 611 418 204 613 minecraft:black_concrete
fill 418 204 614 418 207 614 minecraft:purple_terracotta
setblock 418 204 617 minecraft:purple_terracotta
setblock 418 204 618 minecraft:black_concrete
setblock 418 204 622 minecraft:black_concrete
setblock 418 204 627 minecraft:black_concrete
setblock 418 204 628 minecraft:purple_terracotta
setblock 418 204 631 minecraft:purple_terracotta
setblock 418 204 632 minecraft:black_concrete
fill 418 204 635 418 207 635 minecraft:purple_terracotta
setblock 418 204 636 minecraft:black_concrete
setblock 418 204 638 minecraft:black_concrete
fill 418 204 646 418 206 646 minecraft:black_concrete
setblock 376 205 604 minecraft:black_concrete
fill 376 205 605 376 207 605 minecraft:purple_terracotta
fill 376 205 607 376 207 607 minecraft:purple_terracotta
fill 376 205 615 376 207 615 minecraft:purple_terracotta
setblock 376 205 620 minecraft:black_concrete
setblock 376 205 621 minecraft:purple_terracotta
fill 376 205 623 376 207 623 minecraft:purple_terracotta
setblock 376 205 626 minecraft:black_concrete
fill 376 205 627 376 207 627 minecraft:purple_terracotta
setblock 376 205 646 minecraft:purple_terracotta
setblock 377 205 646 minecraft:black_concrete
fill 380 205 604 380 209 604 minecraft:purple_terracotta
fill 380 205 625 398 205 625 minecraft:blackstone
fill 380 205 646 380 207 646 minecraft:purple_terracotta
fill 381 205 619 394 205 624 minecraft:blackstone
fill 381 205 626 394 205 631 minecraft:blackstone
fill 382 205 617 418 205 618 minecraft:blackstone
fill 382 205 632 418 205 633 minecraft:blackstone
fill 383 205 615 417 205 616 minecraft:blackstone
fill 383 205 634 417 205 635 minecraft:blackstone
fill 384 205 613 416 205 614 minecraft:blackstone
fill 384 205 636 416 205 637 minecraft:blackstone
fill 385 205 612 415 205 612 minecraft:blackstone
fill 385 205 638 415 205 638 minecraft:blackstone
fill 386 205 611 414 205 611 minecraft:blackstone
fill 386 205 639 414 205 639 minecraft:blackstone
fill 386 205 646 386 207 646 minecraft:purple_terracotta
setblock 387 205 604 minecraft:black_concrete
fill 387 205 610 413 205 610 minecraft:blackstone
fill 387 205 640 413 205 640 minecraft:blackstone
setblock 387 205 646 minecraft:black_concrete
fill 388 205 609 412 205 609 minecraft:blackstone
fill 388 205 641 412 205 641 minecraft:blackstone
fill 390 205 608 410 205 608 minecraft:blackstone
fill 390 205 642 410 205 642 minecraft:blackstone
fill 392 205 607 408 205 607 minecraft:blackstone
fill 392 205 643 408 205 643 minecraft:blackstone
fill 392 205 646 392 207 646 minecraft:purple_terracotta
fill 394 205 606 406 205 606 minecraft:blackstone
fill 394 205 644 406 205 644 minecraft:blackstone
setblock 395 205 604 minecraft:purple_terracotta
fill 395 205 619 401 205 620 minecraft:blackstone
fill 395 205 624 398 205 624 minecraft:blackstone
fill 395 205 626 398 205 626 minecraft:blackstone
fill 395 205 630 399 205 631 minecraft:blackstone
setblock 396 205 604 minecraft:black_concrete
fill 398 205 604 398 208 604 minecraft:purple_terracotta
fill 398 205 621 401 205 623 minecraft:blackstone
fill 398 205 627 399 205 629 minecraft:blackstone
setblock 398 205 646 minecraft:black_concrete
fill 400 205 605 400 212 605 minecraft:blackstone
fill 400 205 627 418 205 628 minecraft:blackstone
fill 400 205 645 400 212 645 minecraft:blackstone
setblock 402 205 604 minecraft:black_concrete
fill 402 205 619 418 205 619 minecraft:blackstone
fill 402 205 623 418 205 626 minecraft:blackstone
fill 403 205 629 418 205 631 minecraft:blackstone
fill 403 205 646 403 207 646 minecraft:purple_terracotta
fill 405 205 620 418 205 622 minecraft:blackstone
setblock 417 205 646 minecraft:black_concrete
fill 418 205 605 418 207 605 minecraft:purple_terracotta
setblock 418 205 606 minecraft:black_concrete
fill 418 205 607 418 207 607 minecraft:purple_terracotta
fill 418 205 608 418 205 609 minecraft:black_concrete
fill 418 205 610 418 207 613 minecraft:purple_terracotta
setblock 418 205 615 minecraft:purple_terracotta
setblock 418 205 616 minecraft:black_concrete
fill 418 205 634 418 207 634 minecraft:purple_terracotta
fill 418 205 636 418 207 636 minecraft:purple_terracotta
fill 418 205 638 418 207 638 minecraft:purple_terracotta
setblock 418 205 645 minecraft:black_concrete
fill 376 206 604 376 207 604 minecraft:purple_terracotta
fill 376 206 608 389 206 608 minecraft:black_concrete
fill 376 206 609 376 207 609 minecraft:purple_terracotta
fill 376 206 612 384 206 612 minecraft:black_concrete
fill 376 206 613 376 207 613 minecraft:purple_terracotta
fill 376 206 614 383 206 614 minecraft:black_concrete
fill 376 206 620 376 207 620 minecraft:purple_terracotta
fill 376 206 621 380 206 621 minecraft:black_concrete
fill 376 206 626 376 207 626 minecraft:purple_terracotta
fill 376 206 634 382 206 634 minecraft:black_concrete
fill 376 206 636 383 206 637 minecraft:black_concrete
fill 376 206 638 376 207 638 minecraft:purple_terracotta
fill 376 206 639 385 206 639 minecraft:black_concrete
fill 376 206 640 376 207 640 minecraft:purple_terracotta
fill 376 206 641 387 206 641 minecraft:black_concrete
setblock 376 206 646 minecraft:black_concrete
fill 377 206 605 391 206 607 minecraft:black_concrete
fill 377 206 609 385 206 611 minecraft:black_concrete
fill 377 206 613 383 206 613 minecraft:black_concrete
fill 377 206 615 380 206 620 minecraft:black_concrete
fill 377 206 622 379 206 633 minecraft:black_concrete
fill 377 206 635 382 206 635 minecraft:black_concrete
fill 377 206 638 384 206 638 minecraft:black_concrete
fill 377 206 640 386 206 640 minecraft:black_concrete
fill 377 206 642 389 206 645 minecraft:black_concrete
fill 377 206 646 377 207 646 minecraft:purple_terracotta
fill 380 206 622 380 206 624 minecraft:black_concrete
fill 380 206 625 394 208 625 minecraft:blackstone
fill 380 206 626 380 206 633 minecraft:black_concrete
setblock 381 206 604 minecraft:black_concrete
fill 381 206 615 381 206 618 minecraft:black_concrete
fill 381 206 619 381 212 624 minecraft:blackstone
fill 381 206 626 382 212 631 minecraft:blackstone
fill 381 206 632 381 206 633 minecraft:black_concrete
fill 382 206 615 382 206 616 minecraft:black_concrete
fill 382 206 617 382 212 622 minecraft:blackstone
fill 382 206 623 382 212 623 minecraft:red_concrete
fill 382 206 624 392 209 624 minecraft:blackstone
fill 382 206 632 382 212 632 minecraft:red_concrete
fill 382 206 633 400 209 633 minecraft:blackstone
fill 382 206 646 382 207 646 minecraft:purple_terracotta
fill 383 206 615 384 212 621 minecraft:blackstone
fill 383 206 622 384 212 622 minecraft:red_concrete
fill 383 206 623 393 208 623 minecraft:blackstone
fill 383 206 626 383 212 630 minecraft:blackstone
fill 383 206 631 383 212 631 minecraft:red_concrete
fill 383 206 632 388 211 632 minecraft:blackstone
fill 383 206 634 387 212 635 minecraft:blackstone
fill 384 206 613 395 210 614 minecraft:blackstone
fill 384 206 626 384 212 628 minecraft:blackstone
fill 384 206 629 384 212 629 minecraft:red_concrete
fill 384 206 630 389 210 631 minecraft:blackstone
fill 384 206 636 386 212 637 minecraft:blackstone
fill 385 206 612 394 211 612 minecraft:blackstone
fill 385 206 615 387 212 615 minecraft:red_concrete
fill 385 206 616 385 212 622 minecraft:blackstone
fill 385 206 626 385 211 627 minecraft:blackstone
fill 385 206 628 385 212 628 minecraft:red_concrete
fill 385 206 629 390 210 629 minecraft:blackstone
fill 385 206 638 386 212 638 minecraft:blackstone
fill 386 206 609 386 206 610 minecraft:black_concrete
fill 386 206 611 400 211 611 minecraft:blackstone
fill 386 206 616 390 210 620 minecraft:blackstone
fill 386 206 621 387 211 621 minecraft:red_concrete
fill 386 206 622 393 208 622 minecraft:blackstone
fill 386 206 626 387 211 626 minecraft:blackstone
fill 386 206 627 386 211 627 minecraft:red_concrete
fill 386 206 628 391 209 628 minecraft:blackstone
fill 386 206 639 386 212 639 minecraft:blackstone
fill 387 206 604 387 208 604 minecraft:purple_terracotta
setblock 387 206 609 minecraft:black_concrete
fill 387 206 610 390 212 610 minecraft:blackstone
fill 387 206 627 393 208 627 minecraft:blackstone
fill 387 206 636 392 211 636 minecraft:blackstone
fill 387 206 637 387 212 640 minecraft:red_concrete
fill 387 206 646 387 207 646 minecraft:purple_terracotta
fill 388 206 609 389 212 609 minecraft:red_concrete
fill 388 206 615 397 210 615 minecraft:blackstone
fill 388 206 621 393 209 621 minecraft:blackstone
fill 388 206 626 388 210 626 minecraft:red_concrete
fill 388 206 634 388 211 634 minecraft:red_concrete
fill 388 206 635 392 211 635 minecraft:blackstone
fill 388 206 637 392 211 641 minecraft:blackstone
fill 389 206 626 393 208 626 minecraft:blackstone
fill 389 206 632 389 211 632 minecraft:red_concrete
fill 389 206 634 407 209 634 minecraft:blackstone
fill 390 206 608 398 212 609 minecraft:blackstone
fill 390 206 630 390 210 630 minecraft:red_concrete
fill 390 206 631 398 208 632 minecraft:blackstone
fill 390 206 642 393 212 642 minecraft:blackstone
fill 390 206 643 391 206 645 minecraft:black_concrete
setblock 391 206 604 minecraft:black_concrete
fill 391 206 610 392 212 610 minecraft:red_concrete
fill 391 206 616 392 210 616 minecraft:red_concrete
fill 391 206 617 393 209 620 minecraft:blackstone
fill 391 206 629 391 209 629 minecraft:red_concrete
fill 391 206 630 393 209 630 minecraft:blackstone
fill 392 206 604 392 207 604 minecraft:purple_terracotta
fill 392 206 605 393 206 606 minecraft:black_concrete
fill 392 206 607 397 212 607 minecraft:blackstone
fill 392 206 628 392 209 628 minecraft:red_concrete
fill 392 206 629 393 209 629 minecraft:blackstone
fill 392 206 643 393 212 643 minecraft:blackstone
fill 392 206 644 393 206 645 minecraft:black_concrete
fill 393 206 610 412 211 610 minecraft:blackstone
fill 393 206 616 411 209 616 minecraft:blackstone
fill 393 206 624 393 208 624 minecraft:red_concrete
fill 393 206 628 393 208 628 minecraft:blackstone
fill 393 206 635 393 210 639 minecraft:red_concrete
fill 393 206 640 399 211 641 minecraft:blackstone
setblock 393 206 646 minecraft:black_concrete
fill 394 206 605 399 206 605 minecraft:black_concrete
fill 394 206 606 396 212 606 minecraft:blackstone
fill 394 206 617 394 209 617 minecraft:red_concrete
fill 394 206 618 400 208 619 minecraft:blackstone
fill 394 206 620 394 206 624 minecraft:shroomlight
fill 394 206 626 394 206 630 minecraft:shroomlight
fill 394 206 635 397 210 639 minecraft:blackstone
fill 394 206 642 394 212 643 minecraft:red_concrete
fill 394 206 644 402 212 644 minecraft:blackstone
fill 394 206 645 399 206 645 minecraft:black_concrete
setblock 395 206 604 minecraft:black_concrete
fill 395 206 612 395 211 612 minecraft:red_concrete
fill 395 206 617 398 209 617 minecraft:blackstone
fill 395 206 620 398 206 620 minecraft:shroomlight
fill 395 206 621 397 206 623 minecraft:black_concrete
fill 395 206 624 398 206 624 minecraft:shroomlight
fill 395 206 625 397 207 625 minecraft:magma_block
fill 395 206 626 398 206 626 minecraft:shroomlight
fill 395 206 627 397 206 629 minecraft:black_concrete
fill 395 206 630 399 206 630 minecraft:shroomlight
fill 395 206 642 400 212 643 minecraft:blackstone
fill 396 206 604 396 207 604 minecraft:purple_terracotta
fill 396 206 612 406 211 612 minecraft:blackstone
fill 396 206 613 396 210 613 minecraft:red_concrete
fill 396 206 614 396 210 614 minecraft:blackstone
setblock 396 206 646 minecraft:black_concrete
fill 397 206 606 397 212 606 minecraft:red_concrete
fill 397 206 613 401 210 613 minecraft:blackstone
fill 397 206 614 397 210 614 minecraft:red_concrete
fill 397 206 646 398 207 646 minecraft:purple_terracotta
fill 398 206 606 406 212 606 minecraft:blackstone
fill 398 206 607 398 212 607 minecraft:red_concrete
fill 398 206 614 401 210 614 minecraft:blackstone
fill 398 206 615 398 209 615 minecraft:red_concrete
fill 398 206 621 398 206 623 minecraft:shroomlight
setblock 398 206 625 minecraft:shroomlight
fill 398 206 627 399 206 629 minecraft:shroomlight
fill 398 206 635 401 209 635 minecraft:blackstone
fill 398 206 636 398 210 637 minecraft:red_concrete
fill 398 206 638 398 211 639 minecraft:blackstone
fill 399 206 607 405 212 607 minecraft:blackstone
fill 399 206 608 399 212 608 minecraft:red_concrete
fill 399 206 609 399 212 609 minecraft:blackstone
fill 399 206 615 406 209 615 minecraft:blackstone
fill 399 206 617 399 209 617 minecraft:red_concrete
fill 399 206 620 400 207 622 minecraft:magma_block
fill 399 206 623 405 206 623 minecraft:shroomlight
fill 399 206 631 399 206 632 minecraft:shroomlight
fill 399 206 636 402 210 638 minecraft:blackstone
fill 399 206 639 399 211 639 minecraft:red_concrete
fill 400 206 608 405 212 608 minecraft:blackstone
fill 400 206 609 400 212 609 minecraft:red_concrete
fill 400 206 617 418 209 617 minecraft:blackstone
fill 400 206 627 402 206 628 minecraft:shroomlight
fill 400 206 629 402 206 631 minecraft:black_concrete
fill 400 206 632 403 206 632 minecraft:shroomlight
fill 400 206 639 407 211 640 minecraft:blackstone
fill 400 206 641 400 212 641 minecraft:red_concrete
fill 401 206 605 417 206 605 minecraft:black_concrete
fill 401 206 609 412 212 609 minecraft:blackstone
fill 401 206 611 401 211 611 minecraft:red_concrete
fill 401 206 618 410 208 618 minecraft:blackstone
fill 401 206 619 401 206 622 minecraft:shroomlight
fill 401 206 633 401 209 633 minecraft:red_concrete
fill 401 206 641 410 212 641 minecraft:blackstone
fill 401 206 642 401 212 642 minecraft:red_concrete
fill 401 206 643 401 212 643 minecraft:blackstone
fill 401 206 645 417 206 645 minecraft:black_concrete
fill 402 206 604 402 207 604 minecraft:purple_terracotta
fill 402 206 611 406 211 611 minecraft:blackstone
fill 402 206 613 402 210 614 minecraft:red_concrete
fill 402 206 619 405 206 619 minecraft:shroomlight
fill 402 206 620 404 206 622 minecraft:black_concrete
fill 402 206 624 402 206 626 minecraft:shroomlight
fill 402 206 633 405 209 633 minecraft:blackstone
fill 402 206 635 402 209 635 minecraft:red_concrete
fill 402 206 642 410 212 642 minecraft:blackstone
fill 402 206 643 402 212 643 minecraft:red_concrete
fill 403 206 613 406 210 614 minecraft:blackstone
fill 403 206 624 404 207 627 minecraft:magma_block
fill 403 206 628 403 206 631 minecraft:shroomlight
fill 403 206 635 412 210 635 minecraft:blackstone
fill 403 206 636 403 210 636 minecraft:red_concrete
fill 403 206 637 403 210 638 minecraft:blackstone
fill 403 206 643 408 212 643 minecraft:blackstone
fill 403 206 644 403 212 644 minecraft:red_concrete
fill 404 206 628 404 207 628 minecraft:magma_block
fill 404 206 629 405 208 632 minecraft:blackstone
fill 404 206 636 416 210 636 minecraft:blackstone
fill 404 206 637 404 210 637 minecraft:red_concrete
fill 404 206 638 404 211 638 minecraft:blackstone
fill 404 206 644 406 212 644 minecraft:blackstone
fill 405 206 620 405 206 622 minecraft:shroomlight
fill 405 206 624 405 207 626 minecraft:magma_block
fill 405 206 627 415 208 628 minecraft:blackstone
fill 405 206 637 416 211 637 minecraft:blackstone
fill 405 206 638 405 211 638 minecraft:red_concrete
fill 406 206 607 406 212 608 minecraft:red_concrete
fill 406 206 619 406 208 626 minecraft:blackstone
fill 406 206 629 406 208 629 minecraft:red_concrete
fill 406 206 630 418 209 632 minecraft:blackstone
fill 406 206 633 406 209 633 minecraft:red_concrete
fill 406 206 638 415 211 638 minecraft:blackstone
fill 407 206 606 417 206 606 minecraft:black_concrete
fill 407 206 607 408 212 608 minecraft:blackstone
fill 407 206 611 407 210 615 minecraft:red_concrete
fill 407 206 619 407 208 625 minecraft:blackstone
fill 407 206 626 407 208 626 minecraft:red_concrete
fill 407 206 629 412 209 629 minecraft:blackstone
fill 407 206 633 418 210 633 minecraft:blackstone
fill 407 206 644 417 206 644 minecraft:black_concrete
fill 408 206 611 412 211 615 minecraft:blackstone
fill 408 206 619 408 209 621 minecraft:blackstone
fill 408 206 622 408 209 622 minecraft:red_concrete
fill 408 206 623 411 209 626 minecraft:blackstone
fill 408 206 634 409 210 634 minecraft:red_concrete
fill 408 206 639 414 212 639 minecraft:blackstone
fill 408 206 640 409 212 640 minecraft:red_concrete
fill 409 206 607 417 206 607 minecraft:black_concrete
fill 409 206 608 410 212 608 minecraft:blackstone
fill 409 206 619 409 210 620 minecraft:blackstone
fill 409 206 621 409 209 621 minecraft:red_concrete
fill 409 206 622 414 209 622 minecraft:blackstone
fill 409 206 643 417 206 643 minecraft:black_concrete
fill 410 206 619 416 210 619 minecraft:blackstone
fill 410 206 620 410 210 620 minecraft:red_concrete
fill 410 206 621 415 210 621 minecraft:blackstone
fill 410 206 634 417 211 634 minecraft:blackstone
fill 410 206 640 413 212 640 minecraft:blackstone
fill 411 206 604 411 207 604 minecraft:purple_terracotta
fill 411 206 608 417 206 608 minecraft:black_concrete
fill 411 206 618 411 211 618 minecraft:red_concrete
fill 411 206 620 418 210 620 minecraft:blackstone
fill 411 206 641 412 212 641 minecraft:red_concrete
fill 411 206 642 417 206 642 minecraft:black_concrete
setblock 412 206 604 minecraft:black_concrete
fill 412 206 616 412 211 616 minecraft:red_concrete
fill 412 206 618 417 211 618 minecraft:blackstone
fill 412 206 623 413 210 623 minecraft:blackstone
fill 412 206 624 412 210 624 minecraft:red_concrete
fill 412 206 625 418 210 626 minecraft:blackstone
fill 413 206 609 417 206 609 minecraft:black_concrete
fill 413 206 610 413 212 613 minecraft:red_concrete
fill 413 206 614 416 212 616 minecraft:blackstone
fill 413 206 624 418 211 624 minecraft:blackstone
fill 413 206 629 414 211 629 minecraft:red_concrete
fill 413 206 635 415 212 635 minecraft:red_concrete
fill 413 206 641 417 206 641 minecraft:black_concrete
fill 414 206 610 417 206 610 minecraft:black_concrete
fill 414 206 611 414 212 613 minecraft:blackstone
fill 414 206 623 414 211 623 minecraft:red_concrete
fill 414 206 640 417 206 640 minecraft:black_concrete
fill 415 206 611 417 206 611 minecraft:black_concrete
fill 415 206 612 415 212 613 minecraft:blackstone
fill 415 206 622 415 212 622 minecraft:red_concrete
fill 415 206 623 418 211 623 minecraft:blackstone
fill 415 206 629 418 212 629 minecraft:blackstone
fill 415 206 639 417 206 639 minecraft:black_concrete
fill 416 206 612 417 206 612 minecraft:black_concrete
fill 416 206 613 416 212 613 minecraft:blackstone
fill 416 206 621 416 212 621 minecraft:red_concrete
fill 416 206 622 418 212 622 minecraft:blackstone
fill 416 206 627 417 212 627 minecraft:blackstone
fill 416 206 628 417 212 628 minecraft:red_concrete
fill 416 206 635 417 212 635 minecraft:blackstone
fill 416 206 638 417 206 638 minecraft:black_concrete
fill 417 206 613 417 206 614 minecraft:black_concrete
fill 417 206 615 417 212 616 minecraft:blackstone
fill 417 206 619 417 212 619 minecraft:red_concrete
fill 417 206 621 418 212 621 minecraft:blackstone
fill 417 206 636 417 206 637 minecraft:black_concrete
fill 417 206 646 417 207 646 minecraft:purple_terracotta
fill 418 206 606 418 207 606 minecraft:purple_terracotta
fill 418 206 608 418 207 609 minecraft:purple_terracotta
setblock 418 206 615 minecraft:black_concrete
fill 418 206 616 418 207 616 minecraft:purple_terracotta
fill 418 206 618 418 212 618 minecraft:red_concrete
fill 418 206 619 418 212 619 minecraft:blackstone
fill 418 206 627 418 212 627 minecraft:red_concrete
fill 418 206 628 418 212 628 minecraft:blackstone
fill 418 206 645 418 207 645 minecraft:purple_terracotta
setblock 376 207 608 minecraft:purple_terracotta
setblock 376 207 612 minecraft:purple_terracotta
setblock 376 207 614 minecraft:purple_terracotta
setblock 376 207 621 minecraft:purple_terracotta
setblock 376 207 634 minecraft:purple_terracotta
fill 376 207 636 376 207 637 minecraft:purple_terracotta
fill 376 207 639 376 208 639 minecraft:purple_terracotta
setblock 376 207 641 minecraft:purple_terracotta
setblock 376 207 646 minecraft:purple_terracotta
setblock 377 207 604 minecraft:purple_terracotta
setblock 381 207 604 minecraft:purple_terracotta
setblock 391 207 604 minecraft:purple_terracotta
setblock 393 207 646 minecraft:purple_terracotta
fill 394 207 620 398 208 620 minecraft:blackstone
fill 394 207 621 394 208 621 minecraft:red_concrete
fill 394 207 622 394 208 624 minecraft:blackstone
fill 394 207 626 394 208 630 minecraft:blackstone
setblock 395 207 604 minecraft:purple_terracotta
fill 395 207 621 395 208 623 minecraft:blackstone
fill 395 207 624 397 207 624 minecraft:magma_block
fill 395 207 626 397 207 626 minecraft:magma_block
fill 395 207 627 395 208 630 minecraft:blackstone
fill 396 207 621 396 208 621 minecraft:blackstone
fill 396 207 622 398 207 623 minecraft:magma_block
fill 396 207 627 398 207 628 minecraft:magma_block
fill 396 207 629 396 208 630 minecraft:blackstone
setblock 396 207 646 minecraft:purple_terracotta
fill 397 207 621 398 207 621 minecraft:magma_block
fill 397 207 629 403 207 629 minecraft:magma_block
fill 397 207 630 398 208 630 minecraft:blackstone
fill 399 207 628 403 207 628 minecraft:magma_block
fill 399 207 630 401 207 630 minecraft:magma_block
fill 399 207 631 403 208 632 minecraft:blackstone
fill 401 207 619 405 208 619 minecraft:blackstone
fill 401 207 620 401 207 622 minecraft:magma_block
fill 402 207 620 405 208 620 minecraft:blackstone
fill 402 207 621 403 207 623 minecraft:magma_block
setblock 402 207 627 minecraft:magma_block
fill 402 207 630 403 208 630 minecraft:blackstone
fill 404 207 621 405 208 621 minecraft:blackstone
fill 404 207 622 404 207 623 minecraft:magma_block
fill 405 207 622 405 208 623 minecraft:blackstone
setblock 412 207 604 minecraft:purple_terracotta
setblock 418 207 615 minecraft:purple_terracotta
setblock 418 207 646 minecraft:purple_terracotta
fill 376 208 604 376 209 615 minecraft:black_concrete
fill 376 208 617 376 208 632 minecraft:black_concrete
fill 376 208 634 376 209 638 minecraft:black_concrete
fill 376 208 640 376 212 641 minecraft:black_concrete
setblock 376 208 642 minecraft:purple_terracotta
fill 376 208 643 376 211 644 minecraft:black_concrete
setblock 376 208 645 minecraft:purple_terracotta
fill 376 208 646 377 208 646 minecraft:black_concrete
fill 377 208 604 377 213 604 minecraft:black_concrete
fill 378 208 604 378 209 604 minecraft:purple_terracotta
setblock 378 208 646 minecraft:purple_terracotta
fill 379 208 604 379 215 604 minecraft:black_concrete
fill 379 208 646 390 208 646 minecraft:black_concrete
fill 381 208 604 386 208 604 minecraft:black_concrete
fill 388 208 604 393 209 604 minecraft:black_concrete
setblock 391 208 646 minecraft:purple_terracotta
fill 392 208 646 418 208 646 minecraft:black_concrete
setblock 394 208 604 minecraft:purple_terracotta
fill 395 208 604 397 211 604 minecraft:black_concrete
fill 399 208 604 406 208 604 minecraft:black_concrete
setblock 407 208 604 minecraft:purple_terracotta
fill 408 208 604 408 215 604 minecraft:black_concrete
setblock 409 208 604 minecraft:purple_terracotta
fill 410 208 604 417 209 604 minecraft:black_concrete
fill 418 208 605 418 208 616 minecraft:black_concrete
fill 418 208 634 418 212 636 minecraft:black_concrete
fill 418 208 638 418 209 645 minecraft:black_concrete
fill 376 209 616 376 211 621 minecraft:black_concrete
setblock 376 209 622 minecraft:purple_terracotta
fill 376 209 623 376 209 630 minecraft:black_concrete
setblock 376 209 631 minecraft:purple_terracotta
fill 376 209 632 376 211 633 minecraft:black_concrete
fill 376 209 639 376 213 639 minecraft:black_concrete
fill 376 209 642 376 213 642 minecraft:black_concrete
fill 376 209 645 376 211 645 minecraft:black_concrete
setblock 376 209 646 minecraft:purple_terracotta
fill 377 209 646 387 209 646 minecraft:black_concrete
fill 380 209 625 392 209 625 minecraft:blackstone
fill 381 209 604 382 209 604 minecraft:black_concrete
setblock 383 209 604 minecraft:purple_terracotta
fill 383 209 623 392 209 623 minecraft:blackstone
fill 384 209 604 387 209 604 minecraft:black_concrete
fill 386 209 622 392 209 622 minecraft:blackstone
fill 387 209 627 392 209 627 minecraft:blackstone
setblock 388 209 646 minecraft:purple_terracotta
fill 389 209 626 392 209 626 minecraft:blackstone
fill 389 209 646 407 209 646 minecraft:black_concrete
fill 390 209 631 395 209 632 minecraft:blackstone
fill 394 209 604 394 213 604 minecraft:black_concrete
fill 394 209 618 394 209 620 minecraft:blackstone
setblock 394 209 630 minecraft:blackstone
fill 395 209 618 395 209 619 minecraft:blackstone
setblock 396 209 618 minecraft:blackstone
setblock 396 209 632 minecraft:blackstone
fill 398 209 604 400 209 604 minecraft:black_concrete
setblock 401 209 604 minecraft:purple_terracotta
fill 402 209 604 407 209 604 minecraft:black_concrete
fill 404 209 618 410 209 618 minecraft:blackstone
fill 404 209 632 405 209 632 minecraft:blackstone
fill 405 209 619 407 209 619 minecraft:blackstone
setblock 405 209 631 minecraft:blackstone
fill 406 209 620 407 209 620 minecraft:blackstone
setblock 407 209 621 minecraft:blackstone
fill 408 209 627 415 209 628 minecraft:blackstone
setblock 408 209 646 minecraft:purple_terracotta
setblock 409 209 604 minecraft:black_concrete
setblock 409 209 646 minecraft:black_concrete
setblock 410 209 646 minecraft:purple_terracotta
fill 411 209 646 418 209 646 minecraft:black_concrete
fill 418 209 605 418 209 611 minecraft:black_concrete
setblock 418 209 612 minecraft:purple_terracotta
fill 418 209 613 418 212 615 minecraft:black_concrete
setblock 418 209 616 minecraft:purple_terracotta
fill 418 209 637 418 215 637 minecraft:black_concrete
fill 376 210 604 376 211 605 minecraft:black_concrete
fill 376 210 606 376 210 607 minecraft:red_concrete
fill 376 210 608 376 212 609 minecraft:black_concrete
setblock 376 210 610 minecraft:purple_terracotta
fill 376 210 611 376 211 613 minecraft:black_concrete
fill 376 210 614 376 211 615 minecraft:red_concrete
fill 376 210 622 376 210 623 minecraft:black_concrete
setblock 376 210 624 minecraft:purple_terracotta
fill 376 210 625 376 211 625 minecraft:black_concrete
fill 376 210 626 376 210 627 minecraft:red_concrete
fill 376 210 628 376 210 630 minecraft:purple_terracotta
fill 376 210 631 376 213 631 minecraft:black_concrete
setblock 376 210 634 minecraft:black_concrete
fill 376 210 635 376 211 635 minecraft:red_concrete
setblock 376 210 636 minecraft:purple_terracotta
fill 376 210 637 376 215 637 minecraft:black_concrete
setblock 376 210 638 minecraft:red_concrete
fill 376 210 646 377 211 646 minecraft:red_concrete
fill 377 210 605 379 210 605 minecraft:polished_blackstone
fill 377 210 607 377 210 609 minecraft:polished_blackstone
fill 377 210 611 377 210 613 minecraft:polished_blackstone
fill 377 210 615 377 210 617 minecraft:polished_blackstone
fill 377 210 619 377 210 621 minecraft:polished_blackstone
fill 377 210 623 377 210 625 minecraft:polished_blackstone
fill 377 210 627 377 210 629 minecraft:polished_blackstone
fill 377 210 631 377 210 633 minecraft:polished_blackstone
fill 377 210 635 377 210 637 minecraft:polished_blackstone
fill 377 210 639 377 210 641 minecraft:polished_blackstone
fill 377 210 643 377 210 645 minecraft:polished_blackstone
setblock 378 210 604 minecraft:red_concrete
fill 378 210 646 379 215 646 minecraft:black_concrete
setblock 379 210 607 minecraft:light[level=12]
setblock 379 210 615 minecraft:light[level=12]
setblock 379 210 623 minecraft:light[level=12]
setblock 379 210 631 minecraft:light[level=12]
setblock 379 210 639 minecraft:light[level=12]
fill 379 210 645 381 210 645 minecraft:polished_blackstone
fill 380 210 604 380 215 604 minecraft:black_concrete
fill 380 210 625 389 210 625 minecraft:blackstone
setblock 380 210 646 minecraft:purple_terracotta
fill 381 210 604 381 211 604 minecraft:red_concrete
fill 381 210 605 383 210 605 minecraft:polished_blackstone
fill 381 210 646 387 210 646 minecraft:black_concrete
fill 382 210 604 385 210 604 minecraft:black_concrete
fill 382 210 624 389 210 624 minecraft:blackstone
fill 382 210 633 393 210 633 minecraft:blackstone
fill 383 210 623 389 210 623 minecraft:blackstone
fill 383 210 645 385 210 645 minecraft:polished_blackstone
fill 385 210 605 387 210 605 minecraft:polished_blackstone
setblock 386 210 604 minecraft:purple_terracotta
fill 386 210 622 390 210 622 minecraft:blackstone
fill 386 210 628 390 210 628 minecraft:blackstone
fill 387 210 604 388 215 604 minecraft:black_concrete
setblock 387 210 607 minecraft:light[level=12]
fill 387 210 627 389 210 627 minecraft:blackstone
fill 387 210 645 389 210 645 minecraft:polished_blackstone
fill 388 210 621 390 210 621 minecraft:blackstone
fill 388 210 646 389 210 646 minecraft:red_concrete
fill 389 210 604 390 210 604 minecraft:red_concrete
fill 389 210 605 391 210 605 minecraft:polished_blackstone
setblock 389 210 626 minecraft:blackstone
fill 389 210 634 395 210 634 minecraft:blackstone
fill 390 210 631 391 210 632 minecraft:blackstone
fill 390 210 646 393 213 646 minecraft:black_concrete
fill 391 210 604 392 211 604 minecraft:black_concrete
fill 391 210 617 391 210 620 minecraft:blackstone
setblock 391 210 630 minecraft:blackstone
fill 391 210 645 393 210 645 minecraft:polished_blackstone
fill 392 210 617 392 210 618 minecraft:blackstone
setblock 392 210 632 minecraft:blackstone
setblock 393 210 604 minecraft:purple_terracotta
fill 393 210 605 395 210 605 minecraft:polished_blackstone
fill 393 210 616 393 210 617 minecraft:blackstone
fill 394 210 616 395 210 616 minecraft:blackstone
setblock 394 210 646 minecraft:purple_terracotta
setblock 395 210 623 minecraft:light[level=12]
setblock 395 210 631 minecraft:light[level=12]
fill 395 210 645 397 210 645 minecraft:polished_blackstone
fill 395 210 646 395 211 646 minecraft:black_concrete
fill 396 210 646 397 211 646 minecraft:red_concrete
fill 397 210 605 399 210 605 minecraft:polished_blackstone
fill 398 210 604 398 213 604 minecraft:black_concrete
setblock 398 210 646 minecraft:purple_terracotta
setblock 399 210 604 minecraft:purple_terracotta
setblock 399 210 645 minecraft:polished_blackstone
fill 399 210 646 399 215 646 minecraft:black_concrete
fill 400 210 604 400 215 604 minecraft:black_concrete
setblock 400 210 646 minecraft:red_concrete
fill 401 210 604 402 211 604 minecraft:red_concrete
fill 401 210 605 403 210 605 minecraft:polished_blackstone
setblock 401 210 645 minecraft:polished_blackstone
fill 401 210 646 403 212 646 minecraft:black_concrete
fill 403 210 604 403 211 604 minecraft:black_concrete
fill 403 210 615 406 210 615 minecraft:blackstone
setblock 403 210 623 minecraft:light[level=12]
setblock 403 210 631 minecraft:light[level=12]
fill 403 210 645 405 210 645 minecraft:polished_blackstone
setblock 404 210 604 minecraft:purple_terracotta
setblock 404 210 646 minecraft:purple_terracotta
fill 405 210 604 407 212 604 minecraft:black_concrete
fill 405 210 605 407 210 605 minecraft:polished_blackstone
fill 405 210 616 411 210 616 minecraft:blackstone
fill 405 210 634 407 210 634 minecraft:blackstone
fill 405 210 646 407 210 646 minecraft:black_concrete
fill 407 210 617 418 210 617 minecraft:blackstone
fill 407 210 645 409 210 645 minecraft:polished_blackstone
fill 408 210 618 410 210 618 minecraft:blackstone
fill 408 210 632 418 210 632 minecraft:blackstone
fill 408 210 646 409 211 646 minecraft:red_concrete
fill 409 210 604 410 210 604 minecraft:red_concrete
fill 409 210 605 411 210 605 minecraft:polished_blackstone
fill 409 210 630 418 210 631 minecraft:blackstone
fill 410 210 622 414 210 622 minecraft:blackstone
fill 410 210 628 412 210 629 minecraft:blackstone
fill 410 210 646 410 215 646 minecraft:black_concrete
fill 411 210 604 411 215 604 minecraft:black_concrete
setblock 411 210 607 minecraft:light[level=12]
fill 411 210 623 411 210 627 minecraft:blackstone
fill 411 210 645 413 210 645 minecraft:polished_blackstone
setblock 411 210 646 minecraft:purple_terracotta
setblock 412 210 604 minecraft:purple_terracotta
fill 412 210 627 415 210 627 minecraft:blackstone
fill 412 210 646 416 210 646 minecraft:black_concrete
fill 413 210 604 413 211 604 minecraft:red_concrete
fill 413 210 605 415 210 605 minecraft:polished_blackstone
fill 413 210 628 415 211 628 minecraft:blackstone
fill 414 210 604 418 210 604 minecraft:black_concrete
fill 415 210 645 417 210 645 minecraft:polished_blackstone
fill 417 210 605 417 210 607 minecraft:polished_blackstone
fill 417 210 609 417 210 611 minecraft:polished_blackstone
fill 417 210 613 417 210 614 minecraft:polished_blackstone
fill 417 210 637 417 210 639 minecraft:polished_blackstone
fill 417 210 641 417 210 643 minecraft:polished_blackstone
fill 417 210 646 417 211 646 minecraft:red_concrete
fill 418 210 605 418 215 606 minecraft:black_concrete
fill 418 210 607 418 211 608 minecraft:red_concrete
fill 418 210 609 418 211 609 minecraft:black_concrete
setblock 418 210 610 minecraft:purple_terracotta
fill 418 210 611 418 210 612 minecraft:black_concrete
setblock 418 210 616 minecraft:red_concrete
fill 418 210 638 418 215 638 minecraft:black_concrete
fill 418 210 639 418 211 640 minecraft:red_concrete
fill 418 210 641 418 211 646 minecraft:black_concrete
fill 376 211 606 376 214 607 minecraft:black_concrete
fill 376 211 610 376 213 610 minecraft:black_concrete
fill 376 211 622 376 213 622 minecraft:black_concrete
setblock 376 211 623 minecraft:red_concrete
setblock 376 211 624 minecraft:black_concrete
setblock 376 211 626 minecraft:red_concrete
fill 376 211 627 376 213 630 minecraft:black_concrete
setblock 376 211 634 minecraft:red_concrete
fill 376 211 636 376 215 636 minecraft:black_concrete
fill 376 211 638 376 214 638 minecraft:black_concrete
fill 378 211 604 378 214 604 minecraft:black_concrete
fill 380 211 625 387 211 625 minecraft:blackstone
fill 380 211 646 383 211 646 minecraft:black_concrete
setblock 382 211 604 minecraft:red_concrete
fill 382 211 624 387 211 624 minecraft:blackstone
fill 382 211 633 390 211 633 minecraft:blackstone
fill 383 211 604 386 211 604 minecraft:black_concrete
fill 383 211 623 387 211 623 minecraft:blackstone
fill 384 211 613 393 211 614 minecraft:blackstone
fill 384 211 630 388 211 631 minecraft:blackstone
fill 384 211 646 385 211 646 minecraft:red_concrete
fill 385 211 629 387 211 629 minecraft:blackstone
fill 386 211 616 388 211 620 minecraft:blackstone
fill 386 211 622 387 211 622 minecraft:blackstone
fill 386 211 628 387 211 628 minecraft:blackstone
fill 386 211 646 387 211 646 minecraft:black_concrete
setblock 387 211 627 minecraft:blackstone
fill 388 211 615 392 211 615 minecraft:blackstone
setblock 388 211 646 minecraft:red_concrete
fill 389 211 604 389 214 604 minecraft:black_concrete
fill 389 211 616 389 211 618 minecraft:blackstone
fill 389 211 634 390 211 634 minecraft:blackstone
fill 389 211 646 389 214 646 minecraft:black_concrete
setblock 390 211 604 minecraft:red_concrete
fill 390 211 616 390 211 617 minecraft:blackstone
setblock 393 211 604 minecraft:red_concrete
fill 393 211 636 393 211 639 minecraft:red_concrete
fill 394 211 613 395 211 613 minecraft:blackstone
fill 394 211 637 395 211 639 minecraft:blackstone
setblock 394 211 646 minecraft:black_concrete
fill 396 211 638 397 211 639 minecraft:blackstone
fill 398 211 646 398 215 646 minecraft:black_concrete
fill 399 211 604 399 215 604 minecraft:black_concrete
fill 399 211 638 403 211 638 minecraft:blackstone
fill 400 211 646 400 214 646 minecraft:black_concrete
setblock 404 211 604 minecraft:black_concrete
fill 404 211 646 404 213 646 minecraft:black_concrete
fill 405 211 613 406 211 613 minecraft:blackstone
setblock 405 211 646 minecraft:red_concrete
fill 406 211 646 407 211 646 minecraft:black_concrete
fill 407 211 611 407 211 614 minecraft:red_concrete
fill 407 211 636 416 211 636 minecraft:blackstone
fill 408 211 635 412 211 635 minecraft:blackstone
fill 409 211 604 410 214 604 minecraft:black_concrete
fill 410 211 616 411 211 617 minecraft:blackstone
fill 410 211 633 418 211 633 minecraft:blackstone
fill 411 211 632 418 211 632 minecraft:blackstone
fill 411 211 646 415 211 646 minecraft:black_concrete
setblock 412 211 604 minecraft:black_concrete
fill 412 211 617 418 211 617 minecraft:blackstone
fill 412 211 619 416 211 620 minecraft:blackstone
fill 412 211 630 418 211 631 minecraft:blackstone
fill 413 211 621 413 211 623 minecraft:blackstone
fill 413 211 625 415 211 627 minecraft:blackstone
setblock 414 211 604 minecraft:red_concrete
fill 414 211 621 414 211 622 minecraft:blackstone
fill 415 211 604 418 211 604 minecraft:black_concrete
fill 415 211 621 415 212 621 minecraft:blackstone
fill 416 211 625 418 212 626 minecraft:blackstone
setblock 416 211 646 minecraft:red_concrete
fill 417 211 620 418 212 620 minecraft:blackstone
setblock 418 211 610 minecraft:black_concrete
setblock 418 211 611 minecraft:red_concrete
fill 418 211 612 418 213 612 minecraft:black_concrete
fill 418 211 616 418 214 616 minecraft:black_concrete
setblock 376 212 604 minecraft:red_concrete
fill 376 212 605 376 215 605 minecraft:black_concrete
fill 376 212 611 376 213 611 minecraft:black_concrete
fill 376 212 612 376 213 613 minecraft:red_concrete
fill 376 212 614 376 212 620 minecraft:black_concrete
fill 376 212 621 376 213 621 minecraft:red_concrete
fill 376 212 623 376 217 623 minecraft:black_concrete
fill 376 212 624 376 212 625 minecraft:red_concrete
fill 376 212 626 376 217 626 minecraft:black_concrete
fill 376 212 632 376 213 633 minecraft:red_concrete
fill 376 212 634 376 217 635 minecraft:black_concrete
fill 376 212 643 376 213 643 minecraft:black_concrete
fill 376 212 644 376 212 645 minecraft:red_concrete
fill 376 212 646 377 217 646 minecraft:black_concrete
fill 380 212 625 384 212 625 minecraft:blackstone
fill 380 212 646 382 212 646 minecraft:black_concrete
fill 381 212 604 382 217 604 minecraft:black_concrete
fill 382 212 624 384 212 624 minecraft:blackstone
fill 382 212 633 387 212 633 minecraft:blackstone
fill 383 212 604 384 213 604 minecraft:red_concrete
fill 383 212 623 384 212 623 minecraft:blackstone
fill 383 212 632 386 212 632 minecraft:blackstone
fill 383 212 646 383 213 646 minecraft:red_concrete
fill 384 212 613 389 212 614 minecraft:blackstone
fill 384 212 630 385 212 631 minecraft:blackstone
fill 384 212 646 385 217 646 minecraft:black_concrete
fill 385 212 604 386 213 604 minecraft:black_concrete
fill 385 212 612 392 212 612 minecraft:blackstone
setblock 385 212 629 minecraft:blackstone
fill 386 212 611 393 212 611 minecraft:blackstone
fill 386 212 616 386 212 618 minecraft:blackstone
setblock 386 212 646 minecraft:red_concrete
fill 387 212 616 387 212 617 minecraft:blackstone
fill 387 212 636 389 212 636 minecraft:blackstone
fill 387 212 646 388 215 646 minecraft:black_concrete
setblock 388 212 615 minecraft:blackstone
setblock 388 212 635 minecraft:blackstone
fill 388 212 637 390 212 641 minecraft:blackstone
fill 390 212 604 390 217 604 minecraft:black_concrete
setblock 390 212 613 minecraft:blackstone
fill 391 212 604 392 212 604 minecraft:red_concrete
fill 391 212 638 392 212 641 minecraft:blackstone
fill 393 212 604 393 217 604 minecraft:black_concrete
fill 393 212 610 397 212 610 minecraft:blackstone
setblock 393 212 639 minecraft:red_concrete
fill 393 212 640 397 212 641 minecraft:blackstone
fill 394 212 646 395 213 646 minecraft:red_concrete
fill 395 212 604 395 213 604 minecraft:red_concrete
fill 396 212 604 397 212 604 minecraft:black_concrete
fill 396 212 646 397 217 646 minecraft:black_concrete
fill 398 212 641 399 212 641 minecraft:blackstone
fill 401 212 604 402 217 604 minecraft:black_concrete
fill 403 212 604 404 213 604 minecraft:red_concrete
fill 403 212 610 412 212 610 minecraft:blackstone
fill 403 212 640 407 212 640 minecraft:blackstone
fill 405 212 646 405 217 646 minecraft:black_concrete
fill 406 212 628 409 240 628 minecraft:polished_blackstone
fill 406 212 646 407 212 646 minecraft:red_concrete
setblock 407 212 611 minecraft:red_concrete
fill 407 212 627 408 240 627 minecraft:polished_blackstone
fill 407 212 629 408 240 629 minecraft:polished_blackstone
setblock 407 212 639 minecraft:blackstone
fill 408 212 611 412 212 612 minecraft:blackstone
fill 408 212 638 415 212 638 minecraft:blackstone
fill 408 212 646 409 217 646 minecraft:black_concrete
fill 410 212 613 412 212 613 minecraft:blackstone
fill 410 212 637 416 212 637 minecraft:blackstone
fill 411 212 614 412 212 614 minecraft:blackstone
fill 411 212 636 416 212 636 minecraft:blackstone
fill 411 212 646 413 213 646 minecraft:black_concrete
setblock 412 212 604 minecraft:red_concrete
setblock 412 212 615 minecraft:blackstone
setblock 412 212 635 minecraft:blackstone
fill 413 212 604 414 217 604 minecraft:black_concrete
fill 413 212 617 418 212 617 minecraft:blackstone
fill 413 212 633 417 212 634 minecraft:blackstone
fill 414 212 618 417 212 618 minecraft:blackstone
fill 414 212 632 418 212 632 minecraft:blackstone
fill 414 212 646 415 213 646 minecraft:red_concrete
fill 415 212 604 416 213 604 minecraft:red_concrete
fill 415 212 619 416 212 620 minecraft:blackstone
setblock 415 212 628 minecraft:blackstone
fill 415 212 630 418 212 631 minecraft:blackstone
fill 416 212 623 418 212 624 minecraft:blackstone
fill 416 212 646 417 217 646 minecraft:black_concrete
fill 417 212 604 418 213 604 minecraft:black_concrete
fill 418 212 607 418 217 608 minecraft:black_concrete
fill 418 212 609 418 212 610 minecraft:red_concrete
fill 418 212 611 418 217 611 minecraft:black_concrete
setblock 418 212 633 minecraft:blackstone
fill 418 212 639 418 217 640 minecraft:black_concrete
fill 418 212 641 418 213 642 minecraft:red_concrete
fill 418 212 643 418 212 645 minecraft:black_concrete
setblock 418 212 646 minecraft:red_concrete
fill 376 213 604 376 216 604 minecraft:black_concrete
fill 376 213 608 376 215 608 minecraft:black_concrete
setblock 376 213 609 minecraft:red_concrete
fill 376 213 614 376 213 619 minecraft:black_concrete
setblock 376 213 620 minecraft:red_concrete
fill 376 213 624 376 216 625 minecraft:black_concrete
fill 376 213 640 376 215 640 minecraft:black_concrete
setblock 376 213 641 minecraft:red_concrete
setblock 376 213 644 minecraft:red_concrete
fill 376 213 645 376 216 645 minecraft:black_concrete
fill 380 213 646 381 213 646 minecraft:black_concrete
setblock 382 213 646 minecraft:red_concrete
fill 386 213 646 386 216 646 minecraft:black_concrete
fill 391 213 604 392 216 604 minecraft:black_concrete
fill 392 213 637 392 214 637 minecraft:crying_obsidian
setblock 396 213 604 minecraft:red_concrete
setblock 397 213 604 minecraft:black_concrete
setblock 401 213 646 minecraft:black_concrete
fill 402 213 646 403 213 646 minecraft:red_concrete
fill 405 213 604 406 213 604 minecraft:black_concrete
fill 406 213 627 406 214 627 minecraft:black_concrete
fill 406 213 629 406 214 629 minecraft:black_concrete
setblock 406 213 646 minecraft:red_concrete
setblock 407 213 604 minecraft:red_concrete
fill 407 213 626 408 214 626 minecraft:black_concrete
fill 407 213 630 408 214 630 minecraft:black_concrete
fill 407 213 646 407 216 646 minecraft:black_concrete
fill 409 213 627 409 214 627 minecraft:black_concrete
fill 409 213 629 409 214 629 minecraft:black_concrete
fill 412 213 604 412 216 604 minecraft:black_concrete
fill 418 213 609 418 216 609 minecraft:black_concrete
setblock 418 213 610 minecraft:red_concrete
fill 418 213 613 418 213 614 minecraft:red_concrete
setblock 418 213 615 minecraft:black_concrete
fill 418 213 617 418 215 620 minecraft:black_concrete
fill 418 213 621 418 213 622 minecraft:red_concrete
fill 418 213 623 418 213 632 minecraft:black_concrete
fill 418 213 633 418 213 634 minecraft:red_concrete
fill 418 213 635 418 213 636 minecraft:black_concrete
fill 418 213 643 418 213 644 minecraft:black_concrete
setblock 418 213 645 minecraft:red_concrete
fill 418 213 646 418 215 646 minecraft:black_concrete
fill 376 214 609 376 219 609 minecraft:black_concrete
fill 376 214 610 376 214 611 minecraft:red_concrete
fill 376 214 612 376 215 617 minecraft:black_concrete
fill 376 214 618 376 215 619 minecraft:red_concrete
fill 376 214 620 376 219 621 minecraft:black_concrete
setblock 376 214 622 minecraft:red_concrete
fill 376 214 627 376 214 629 minecraft:black_concrete
fill 376 214 630 376 215 631 minecraft:red_concrete
fill 376 214 632 376 219 633 minecraft:black_concrete
fill 376 214 639 376 215 639 minecraft:red_concrete
fill 376 214 641 376 219 641 minecraft:black_concrete
fill 376 214 642 376 214 643 minecraft:red_concrete
fill 376 214 644 376 219 644 minecraft:black_concrete
fill 377 214 604 377 215 604 minecraft:red_concrete
fill 380 214 646 381 215 646 minecraft:red_concrete
fill 382 214 646 383 219 646 minecraft:black_concrete
fill 383 214 604 384 219 604 minecraft:black_concrete
fill 385 214 604 386 215 604 minecraft:red_concrete
fill 390 214 646 391 215 646 minecraft:black_concrete
fill 392 214 638 393 214 638 minecraft:crying_obsidian
fill 392 214 646 393 214 646 minecraft:red_concrete
fill 393 214 639 393 215 639 minecraft:crying_obsidian
setblock 394 214 604 minecraft:red_concrete
fill 394 214 646 395 219 646 minecraft:black_concrete
fill 395 214 604 396 219 604 minecraft:black_concrete
fill 397 214 604 398 215 604 minecraft:red_concrete
fill 401 214 646 401 215 646 minecraft:red_concrete
fill 402 214 646 403 219 646 minecraft:black_concrete
fill 403 214 604 404 219 604 minecraft:black_concrete
setblock 404 214 646 minecraft:red_concrete
fill 405 214 604 406 214 604 minecraft:red_concrete
fill 405 214 627 405 214 629 minecraft:black_concrete
setblock 406 214 626 minecraft:black_concrete
setblock 406 214 630 minecraft:black_concrete
fill 406 214 646 406 219 646 minecraft:black_concrete
fill 407 214 604 407 219 604 minecraft:black_concrete
fill 408 214 625 408 215 625 minecraft:magma_block
setblock 409 214 626 minecraft:black_concrete
setblock 409 214 630 minecraft:black_concrete
fill 410 214 627 410 214 629 minecraft:black_concrete
fill 411 214 646 411 215 646 minecraft:black_concrete
fill 412 214 646 413 215 646 minecraft:red_concrete
fill 414 214 646 415 219 646 minecraft:black_concrete
fill 415 214 604 416 219 604 minecraft:black_concrete
fill 417 214 604 418 215 604 minecraft:red_concrete
fill 418 214 610 418 219 610 minecraft:black_concrete
setblock 418 214 612 minecraft:red_concrete
fill 418 214 613 418 219 614 minecraft:black_concrete
fill 418 214 615 418 215 615 minecraft:red_concrete
fill 418 214 621 418 219 622 minecraft:black_concrete
fill 418 214 623 418 215 624 minecraft:red_concrete
fill 418 214 625 418 214 631 minecraft:black_concrete
setblock 418 214 632 minecraft:red_concrete
fill 418 214 633 418 219 634 minecraft:black_concrete
fill 418 214 635 418 215 636 minecraft:red_concrete
fill 418 214 641 418 216 642 minecraft:black_concrete
fill 418 214 643 418 214 644 minecraft:red_concrete
fill 418 214 645 418 219 645 minecraft:black_concrete
fill 376 215 606 376 215 607 minecraft:red_concrete
setblock 376 215 610 minecraft:red_concrete
fill 376 215 611 376 218 611 minecraft:black_concrete
fill 376 215 622 376 218 622 minecraft:black_concrete
setblock 376 215 627 minecraft:red_concrete
fill 376 215 628 376 215 629 minecraft:black_concrete
setblock 376 215 638 minecraft:red_concrete
fill 376 215 642 376 218 643 minecraft:black_concrete
setblock 378 215 604 minecraft:red_concrete
fill 384 215 625 384 216 625 minecraft:red_concrete
setblock 389 215 604 minecraft:red_concrete
setblock 389 215 646 minecraft:red_concrete
setblock 392 215 646 minecraft:red_concrete
setblock 393 215 638 minecraft:crying_obsidian
fill 393 215 646 393 218 646 minecraft:black_concrete
fill 394 215 604 394 218 604 minecraft:black_concrete
fill 394 215 639 394 215 640 minecraft:crying_obsidian
setblock 400 215 646 minecraft:red_concrete
fill 402 215 636 405 220 637 minecraft:light_blue_concrete
fill 403 215 635 405 220 635 minecraft:light_blue_concrete
fill 403 215 638 405 220 638 minecraft:light_blue_concrete
fill 404 215 646 404 218 646 minecraft:black_concrete
fill 405 215 604 405 218 604 minecraft:black_concrete
setblock 406 215 604 minecraft:red_concrete
setblock 408 215 626 minecraft:magma_block
fill 409 215 604 410 215 604 minecraft:red_concrete
fill 418 215 612 418 218 612 minecraft:black_concrete
setblock 418 215 616 minecraft:red_concrete
fill 418 215 625 418 215 626 minecraft:black_concrete
setblock 418 215 627 minecraft:red_concrete
fill 418 215 628 418 215 632 minecraft:black_concrete
fill 418 215 643 418 218 643 minecraft:black_concrete
setblock 418 215 644 minecraft:red_concrete
fill 376 216 605 376 217 605 minecraft:red_concrete
fill 376 216 606 376 221 607 minecraft:black_concrete
setblock 376 216 608 minecraft:red_concrete
fill 376 216 610 376 221 610 minecraft:black_concrete
fill 376 216 612 376 217 615 minecraft:black_concrete
fill 376 216 616 376 217 617 minecraft:red_concrete
fill 376 216 618 376 221 619 minecraft:black_concrete
fill 376 216 627 376 221 627 minecraft:black_concrete
fill 376 216 628 376 216 629 minecraft:red_concrete
fill 376 216 630 376 221 631 minecraft:black_concrete
fill 376 216 636 376 217 637 minecraft:red_concrete
fill 376 216 638 376 221 639 minecraft:black_concrete
setblock 376 216 640 minecraft:red_concrete
fill 377 216 604 378 221 604 minecraft:black_concrete
fill 377 216 605 379 216 605 minecraft:polished_blackstone
fill 377 216 607 377 216 609 minecraft:polished_blackstone
fill 377 216 611 377 216 613 minecraft:polished_blackstone
fill 377 216 615 377 216 617 minecraft:polished_blackstone
fill 377 216 619 377 216 621 minecraft:polished_blackstone
fill 377 216 623 377 216 625 minecraft:polished_blackstone
fill 377 216 627 377 216 629 minecraft:polished_blackstone
fill 377 216 631 377 216 633 minecraft:polished_blackstone
schedule function dropper:buildpart/152_4 1t
