fill 418 221 228 418 222 228 minecraft:green_terracotta
setblock 418 221 230 minecraft:lime_terracotta
fill 418 221 231 418 222 231 minecraft:green_terracotta
fill 418 221 234 418 221 235 minecraft:lime_terracotta
fill 418 221 236 418 222 236 minecraft:green_terracotta
fill 418 221 262 418 222 262 minecraft:green_terracotta
fill 418 221 265 418 222 265 minecraft:green_terracotta
setblock 376 222 253 minecraft:green_terracotta
setblock 376 222 258 minecraft:green_terracotta
fill 376 222 260 376 226 260 minecraft:jungle_leaves[persistent=true]
fill 376 222 267 376 224 267 minecraft:green_terracotta
fill 377 222 229 382 222 269 minecraft:oak_leaves[persistent=true]
setblock 377 222 270 minecraft:green_concrete
setblock 378 222 228 minecraft:green_terracotta
fill 380 222 270 381 222 270 minecraft:green_terracotta
setblock 382 222 228 minecraft:green_terracotta
fill 383 222 229 385 222 242 minecraft:oak_leaves[persistent=true]
fill 383 222 243 383 223 243 minecraft:bone_block
fill 383 222 244 384 222 251 minecraft:oak_leaves[persistent=true]
fill 383 222 252 383 228 252 minecraft:bone_block
fill 383 222 253 384 223 260 minecraft:oak_leaves[persistent=true]
fill 383 222 261 383 223 261 minecraft:bone_block
fill 383 222 262 390 222 269 minecraft:oak_leaves[persistent=true]
fill 384 222 243 384 224 243 minecraft:oak_leaves[persistent=true]
fill 384 222 252 384 224 252 minecraft:oak_leaves[persistent=true]
fill 384 222 261 385 222 261 minecraft:oak_leaves[persistent=true]
setblock 385 222 243 minecraft:lime_terracotta
fill 385 222 244 385 222 246 minecraft:green_terracotta
setblock 385 222 247 minecraft:lime_terracotta
fill 385 222 248 385 226 248 minecraft:green_terracotta
setblock 385 222 251 minecraft:lime_terracotta
fill 385 222 252 385 223 253 minecraft:green_terracotta
fill 385 222 254 385 222 260 minecraft:oak_leaves[persistent=true]
setblock 386 222 228 minecraft:green_terracotta
fill 386 222 229 386 222 240 minecraft:oak_leaves[persistent=true]
fill 386 222 241 386 224 242 minecraft:green_terracotta
fill 386 222 243 386 223 243 minecraft:bone_block
fill 386 222 244 386 223 245 minecraft:green_terracotta
fill 386 222 251 386 227 251 minecraft:green_terracotta
fill 386 222 252 386 228 252 minecraft:bone_block
fill 386 222 253 386 227 253 minecraft:green_terracotta
setblock 386 222 255 minecraft:green_terracotta
fill 386 222 256 386 222 260 minecraft:oak_leaves[persistent=true]
fill 386 222 261 386 223 261 minecraft:bone_block
fill 387 222 229 387 222 238 minecraft:oak_leaves[persistent=true]
fill 387 222 239 387 223 239 minecraft:brown_terracotta
setblock 387 222 257 minecraft:lime_terracotta
fill 387 222 258 387 222 261 minecraft:oak_leaves[persistent=true]
fill 388 222 229 388 223 236 minecraft:oak_leaves[persistent=true]
fill 388 222 237 388 224 237 minecraft:brown_terracotta
fill 388 222 239 388 224 239 minecraft:green_terracotta
fill 388 222 250 388 222 254 minecraft:pink_terracotta
setblock 388 222 258 minecraft:lime_terracotta
fill 388 222 259 388 228 259 minecraft:green_terracotta
fill 388 222 260 388 223 261 minecraft:oak_leaves[persistent=true]
fill 389 222 229 389 223 235 minecraft:oak_leaves[persistent=true]
fill 389 222 236 389 223 236 minecraft:brown_terracotta
fill 389 222 237 389 231 237 minecraft:green_terracotta
fill 389 222 243 389 223 243 minecraft:bone_block
setblock 389 222 249 minecraft:pink_terracotta
setblock 389 222 255 minecraft:pink_terracotta
fill 389 222 260 389 223 260 minecraft:green_terracotta
fill 389 222 261 389 223 261 minecraft:bone_block
fill 390 222 229 390 223 234 minecraft:oak_leaves[persistent=true]
fill 390 222 235 390 223 235 minecraft:brown_terracotta
fill 390 222 236 390 231 236 minecraft:green_terracotta
fill 390 222 243 391 229 243 minecraft:green_terracotta
setblock 390 222 248 minecraft:pink_terracotta
fill 390 222 256 391 222 256 minecraft:pink_terracotta
fill 390 222 261 390 224 261 minecraft:green_terracotta
setblock 391 222 228 minecraft:green_terracotta
fill 391 222 229 392 222 233 minecraft:oak_leaves[persistent=true]
fill 391 222 234 392 222 234 minecraft:brown_terracotta
fill 391 222 235 391 231 235 minecraft:green_terracotta
fill 391 222 246 391 223 246 minecraft:green_terracotta
fill 391 222 247 394 222 247 minecraft:pink_terracotta
fill 391 222 262 391 223 262 minecraft:green_terracotta
fill 391 222 263 392 222 269 minecraft:oak_leaves[persistent=true]
fill 392 222 243 392 223 243 minecraft:bone_block
fill 392 222 257 393 222 257 minecraft:pink_terracotta
fill 392 222 261 392 223 261 minecraft:bone_block
setblock 392 222 262 minecraft:lime_terracotta
fill 393 222 229 394 223 232 minecraft:oak_leaves[persistent=true]
fill 393 222 233 394 223 233 minecraft:brown_terracotta
fill 393 222 234 394 224 234 minecraft:green_terracotta
fill 393 222 262 394 225 262 minecraft:green_terracotta
setblock 393 222 263 minecraft:lime_terracotta
fill 393 222 264 394 223 269 minecraft:oak_leaves[persistent=true]
fill 394 222 243 394 226 243 minecraft:green_terracotta
fill 394 222 256 395 222 256 minecraft:pink_terracotta
setblock 394 222 257 minecraft:green_terracotta
fill 394 222 261 394 234 261 minecraft:green_terracotta
setblock 394 222 263 minecraft:green_terracotta
fill 395 222 243 395 223 243 minecraft:bone_block
fill 395 222 247 396 222 247 minecraft:green_terracotta
setblock 395 222 248 minecraft:pink_terracotta
fill 395 222 261 395 223 261 minecraft:bone_block
fill 396 222 243 396 227 243 minecraft:green_terracotta
fill 396 222 248 397 222 248 minecraft:green_terracotta
setblock 396 222 249 minecraft:pink_terracotta
fill 396 222 254 396 222 255 minecraft:pink_terracotta
fill 396 222 256 397 223 256 minecraft:green_terracotta
fill 396 222 263 396 232 263 minecraft:green_terracotta
setblock 396 222 270 minecraft:green_terracotta
fill 397 222 249 398 222 249 minecraft:green_terracotta
fill 397 222 250 397 222 253 minecraft:pink_terracotta
setblock 397 222 254 minecraft:green_terracotta
fill 397 222 261 397 234 261 minecraft:green_terracotta
setblock 397 222 263 minecraft:lime_terracotta
fill 398 222 243 398 223 243 minecraft:bone_block
fill 398 222 250 399 223 250 minecraft:green_terracotta
fill 398 222 252 398 228 252 minecraft:bone_block
fill 398 222 261 398 223 261 minecraft:bone_block
fill 398 222 263 400 225 263 minecraft:green_terracotta
setblock 399 222 228 minecraft:moss_block
fill 399 222 243 400 229 243 minecraft:green_terracotta
fill 399 222 252 400 224 252 minecraft:green_terracotta
fill 399 222 261 399 226 261 minecraft:green_terracotta
fill 400 222 233 401 223 233 minecraft:brown_terracotta
fill 400 222 234 401 231 234 minecraft:green_terracotta
fill 401 222 228 401 223 228 minecraft:green_terracotta
fill 401 222 243 401 223 243 minecraft:bone_block
fill 401 222 252 401 232 252 minecraft:bone_block
fill 401 222 261 401 223 261 minecraft:bone_block
fill 401 222 262 401 224 262 minecraft:green_terracotta
setblock 401 222 263 minecraft:lime_terracotta
setblock 401 222 270 minecraft:green_terracotta
fill 402 222 233 417 222 233 minecraft:oak_leaves[persistent=true]
fill 402 222 234 403 222 234 minecraft:brown_terracotta
fill 402 222 263 417 222 263 minecraft:oak_leaves[persistent=true]
fill 403 222 235 403 223 235 minecraft:green_terracotta
fill 403 222 262 403 223 262 minecraft:green_terracotta
setblock 404 222 228 minecraft:green_terracotta
fill 404 222 234 417 223 234 minecraft:oak_leaves[persistent=true]
fill 404 222 235 404 223 235 minecraft:brown_terracotta
fill 404 222 236 404 224 236 minecraft:green_terracotta
setblock 404 222 261 minecraft:green_terracotta
fill 404 222 262 417 223 262 minecraft:oak_leaves[persistent=true]
fill 405 222 235 417 223 235 minecraft:oak_leaves[persistent=true]
fill 405 222 236 405 223 236 minecraft:brown_terracotta
fill 405 222 237 405 231 237 minecraft:green_terracotta
fill 405 222 260 405 227 260 minecraft:green_terracotta
fill 405 222 261 417 223 261 minecraft:oak_leaves[persistent=true]
fill 406 222 236 417 223 236 minecraft:oak_leaves[persistent=true]
fill 406 222 237 406 224 237 minecraft:brown_terracotta
fill 406 222 239 406 224 239 minecraft:green_terracotta
fill 406 222 257 406 232 257 minecraft:green_terracotta
setblock 406 222 259 minecraft:green_terracotta
fill 406 222 260 417 223 260 minecraft:oak_leaves[persistent=true]
fill 407 222 237 417 222 238 minecraft:oak_leaves[persistent=true]
fill 407 222 239 407 223 239 minecraft:brown_terracotta
setblock 407 222 257 minecraft:lime_terracotta
fill 407 222 258 417 222 259 minecraft:oak_leaves[persistent=true]
fill 408 222 239 417 222 240 minecraft:oak_leaves[persistent=true]
setblock 408 222 241 minecraft:green_terracotta
setblock 408 222 242 minecraft:lime_terracotta
fill 408 222 243 408 226 243 minecraft:green_terracotta
fill 408 222 251 408 226 253 minecraft:green_terracotta
setblock 408 222 254 minecraft:lime_terracotta
fill 408 222 255 408 228 255 minecraft:green_terracotta
fill 408 222 256 417 222 257 minecraft:oak_leaves[persistent=true]
fill 408 222 270 408 223 270 minecraft:green_terracotta
fill 409 222 241 417 222 242 minecraft:oak_leaves[persistent=true]
setblock 409 222 243 minecraft:lime_terracotta
fill 409 222 244 409 222 246 minecraft:green_terracotta
setblock 409 222 247 minecraft:lime_terracotta
fill 409 222 248 409 232 248 minecraft:green_terracotta
setblock 409 222 251 minecraft:lime_terracotta
fill 409 222 252 409 223 253 minecraft:green_terracotta
fill 409 222 254 417 222 255 minecraft:oak_leaves[persistent=true]
fill 410 222 243 417 222 245 minecraft:oak_leaves[persistent=true]
fill 410 222 251 417 223 253 minecraft:oak_leaves[persistent=true]
setblock 416 222 270 minecraft:green_terracotta
setblock 418 222 230 minecraft:green_terracotta
fill 418 222 234 418 222 235 minecraft:green_terracotta
fill 418 222 237 418 226 238 minecraft:azalea_leaves[persistent=true]
setblock 418 222 264 minecraft:green_concrete
fill 376 223 228 376 223 229 minecraft:lime_terracotta
setblock 376 223 230 minecraft:jungle_log
fill 376 223 231 376 248 233 minecraft:lime_terracotta
fill 376 223 235 376 226 236 minecraft:azalea_leaves[persistent=true]
fill 376 223 237 376 223 249 minecraft:lime_terracotta
fill 376 223 251 376 223 257 minecraft:lime_terracotta
fill 376 223 258 376 226 259 minecraft:jungle_leaves[persistent=true]
fill 376 223 261 376 227 261 minecraft:jungle_leaves[persistent=true]
fill 376 223 263 376 225 264 minecraft:jungle_leaves[persistent=true]
fill 376 223 265 376 224 265 minecraft:jungle_log
fill 376 223 266 376 235 266 minecraft:lime_terracotta
fill 376 223 268 376 224 270 minecraft:lime_terracotta
fill 377 223 228 386 223 228 minecraft:lime_terracotta
fill 377 223 229 378 224 269 minecraft:oak_leaves[persistent=true]
fill 377 223 270 377 227 270 minecraft:lime_terracotta
fill 379 223 229 381 223 247 minecraft:oak_leaves[persistent=true]
fill 379 223 248 379 224 248 minecraft:green_concrete
fill 379 223 249 380 223 269 minecraft:oak_leaves[persistent=true]
fill 379 223 270 381 235 270 minecraft:lime_terracotta
fill 380 223 248 383 223 248 minecraft:oak_leaves[persistent=true]
fill 381 223 249 382 223 255 minecraft:oak_leaves[persistent=true]
fill 381 223 256 381 224 256 minecraft:azalea_leaves[persistent=true]
fill 381 223 257 382 224 269 minecraft:oak_leaves[persistent=true]
fill 382 223 229 382 224 243 minecraft:oak_leaves[persistent=true]
fill 382 223 244 382 224 244 minecraft:green_concrete
fill 382 223 245 384 223 247 minecraft:oak_leaves[persistent=true]
setblock 382 223 256 minecraft:oak_leaves[persistent=true]
setblock 382 223 270 minecraft:green_terracotta
fill 383 223 229 384 224 242 minecraft:oak_leaves[persistent=true]
fill 383 223 244 384 223 244 minecraft:oak_leaves[persistent=true]
fill 383 223 249 384 223 251 minecraft:oak_leaves[persistent=true]
fill 383 223 262 389 223 269 minecraft:oak_leaves[persistent=true]
fill 383 223 270 384 247 270 minecraft:lime_terracotta
setblock 384 223 248 minecraft:green_terracotta
setblock 384 223 261 minecraft:oak_leaves[persistent=true]
fill 385 223 229 385 223 241 minecraft:oak_leaves[persistent=true]
setblock 385 223 242 minecraft:lime_terracotta
fill 385 223 243 385 224 245 minecraft:green_terracotta
setblock 385 223 246 minecraft:lime_terracotta
fill 385 223 247 385 226 247 minecraft:green_terracotta
fill 385 223 249 385 226 249 minecraft:green_terracotta
setblock 385 223 250 minecraft:lime_terracotta
fill 385 223 251 385 229 251 minecraft:green_terracotta
setblock 385 223 254 minecraft:lime_terracotta
fill 385 223 255 385 223 260 minecraft:oak_leaves[persistent=true]
fill 385 223 261 385 225 261 minecraft:green_concrete
setblock 385 223 270 minecraft:green_terracotta
fill 386 223 229 387 224 237 minecraft:oak_leaves[persistent=true]
fill 386 223 238 386 224 239 minecraft:azalea_leaves[persistent=true]
setblock 386 223 240 minecraft:green_terracotta
setblock 386 223 255 minecraft:lime_terracotta
fill 386 223 256 386 225 256 minecraft:green_terracotta
fill 386 223 257 386 223 260 minecraft:oak_leaves[persistent=true]
fill 386 223 270 388 229 270 minecraft:lime_terracotta
setblock 387 223 238 minecraft:brown_terracotta
fill 387 223 257 387 224 258 minecraft:green_terracotta
fill 387 223 259 387 224 261 minecraft:oak_leaves[persistent=true]
fill 388 223 228 388 224 228 minecraft:green_terracotta
fill 388 223 238 388 224 238 minecraft:green_terracotta
fill 388 223 247 388 225 248 minecraft:green_terracotta
fill 388 223 249 388 224 254 minecraft:red_terracotta
fill 388 223 258 388 226 258 minecraft:green_terracotta
fill 389 223 228 395 224 228 minecraft:lime_terracotta
fill 389 223 248 389 224 248 minecraft:red_terracotta
fill 389 223 255 389 224 255 minecraft:red_terracotta
setblock 389 223 270 minecraft:green_terracotta
fill 390 223 245 390 224 246 minecraft:green_terracotta
fill 390 223 247 391 223 247 minecraft:red_terracotta
fill 390 223 256 390 224 256 minecraft:red_terracotta
setblock 390 223 262 minecraft:oak_leaves[persistent=true]
fill 390 223 263 390 224 263 minecraft:jungle_leaves[persistent=true]
fill 390 223 264 392 224 269 minecraft:oak_leaves[persistent=true]
fill 390 223 270 392 224 270 minecraft:lime_terracotta
fill 391 223 229 391 224 233 minecraft:oak_leaves[persistent=true]
fill 391 223 234 391 224 234 minecraft:brown_terracotta
fill 391 223 257 394 224 257 minecraft:red_terracotta
setblock 391 223 263 minecraft:oak_leaves[persistent=true]
fill 392 223 229 392 224 232 minecraft:oak_leaves[persistent=true]
fill 392 223 233 392 230 233 minecraft:brown_terracotta
setblock 392 223 234 minecraft:green_terracotta
fill 392 223 246 394 223 246 minecraft:red_terracotta
fill 392 223 262 392 224 263 minecraft:green_terracotta
fill 393 223 263 393 225 263 minecraft:green_terracotta
setblock 394 223 263 minecraft:lime_terracotta
fill 394 223 270 399 223 270 minecraft:lime_terracotta
fill 395 223 229 417 224 231 minecraft:oak_leaves[persistent=true]
fill 395 223 232 399 223 232 minecraft:brown_terracotta
fill 395 223 233 399 223 233 minecraft:green_terracotta
setblock 395 223 246 minecraft:green_terracotta
setblock 395 223 247 minecraft:red_terracotta
setblock 395 223 256 minecraft:red_terracotta
setblock 395 223 264 minecraft:lime_terracotta
fill 395 223 265 395 223 269 minecraft:oak_leaves[persistent=true]
setblock 396 223 228 minecraft:mossy_cobblestone
setblock 396 223 247 minecraft:green_terracotta
setblock 396 223 248 minecraft:red_terracotta
setblock 396 223 255 minecraft:red_terracotta
fill 396 223 264 398 223 264 minecraft:green_terracotta
fill 396 223 265 417 223 265 minecraft:oak_leaves[persistent=true]
fill 396 223 266 396 224 266 minecraft:green_concrete
fill 396 223 267 417 224 269 minecraft:oak_leaves[persistent=true]
fill 397 223 228 399 223 228 minecraft:lime_terracotta
setblock 397 223 248 minecraft:green_terracotta
fill 397 223 249 397 223 250 minecraft:red_terracotta
fill 397 223 253 397 223 254 minecraft:red_terracotta
fill 397 223 263 397 225 263 minecraft:green_terracotta
fill 397 223 266 417 224 266 minecraft:oak_leaves[persistent=true]
setblock 398 223 249 minecraft:green_terracotta
fill 398 223 251 398 224 251 minecraft:red_terracotta
fill 399 223 251 400 224 251 minecraft:green_terracotta
setblock 399 223 264 minecraft:lime_terracotta
fill 400 223 232 417 223 232 minecraft:oak_leaves[persistent=true]
fill 400 223 264 417 223 264 minecraft:oak_leaves[persistent=true]
fill 401 223 263 401 224 263 minecraft:green_terracotta
fill 401 223 270 402 229 270 minecraft:lime_terracotta
fill 402 223 228 405 223 228 minecraft:lime_terracotta
fill 402 223 233 402 230 233 minecraft:brown_terracotta
fill 402 223 234 402 224 234 minecraft:azalea_leaves[persistent=true]
fill 402 223 263 402 225 263 minecraft:green_concrete
fill 403 223 233 417 224 233 minecraft:oak_leaves[persistent=true]
setblock 403 223 234 minecraft:brown_terracotta
fill 403 223 263 417 223 263 minecraft:oak_leaves[persistent=true]
setblock 404 223 261 minecraft:lime_terracotta
fill 404 223 270 405 260 270 minecraft:lime_terracotta
fill 406 223 238 406 224 238 minecraft:green_terracotta
setblock 406 223 259 minecraft:lime_terracotta
setblock 406 223 270 minecraft:green_terracotta
fill 407 223 237 407 224 237 minecraft:oak_leaves[persistent=true]
setblock 407 223 238 minecraft:brown_terracotta
fill 407 223 257 407 224 258 minecraft:green_terracotta
setblock 407 223 259 minecraft:oak_leaves[persistent=true]
fill 407 223 270 407 261 270 minecraft:lime_terracotta
fill 408 223 228 410 223 228 minecraft:lime_terracotta
fill 408 223 237 408 224 237 minecraft:jungle_leaves[persistent=true]
fill 408 223 238 417 223 239 minecraft:oak_leaves[persistent=true]
setblock 408 223 240 minecraft:green_terracotta
setblock 408 223 241 minecraft:lime_terracotta
fill 408 223 242 408 226 242 minecraft:green_terracotta
fill 408 223 254 408 225 254 minecraft:green_terracotta
setblock 408 223 256 minecraft:green_terracotta
fill 408 223 257 417 223 258 minecraft:oak_leaves[persistent=true]
fill 408 223 259 409 224 259 minecraft:green_concrete
fill 409 223 237 417 224 237 minecraft:oak_leaves[persistent=true]
fill 409 223 240 417 223 241 minecraft:oak_leaves[persistent=true]
setblock 409 223 242 minecraft:lime_terracotta
fill 409 223 243 409 225 245 minecraft:green_terracotta
setblock 409 223 246 minecraft:lime_terracotta
fill 409 223 247 409 229 247 minecraft:green_terracotta
fill 409 223 249 409 231 249 minecraft:green_terracotta
setblock 409 223 250 minecraft:lime_terracotta
fill 409 223 251 409 229 251 minecraft:green_terracotta
setblock 409 223 254 minecraft:lime_terracotta
fill 409 223 255 411 223 256 minecraft:oak_leaves[persistent=true]
fill 409 223 270 414 223 270 minecraft:lime_terracotta
fill 410 223 242 412 223 247 minecraft:oak_leaves[persistent=true]
fill 410 223 248 410 225 248 minecraft:green_terracotta
fill 410 223 249 417 223 250 minecraft:oak_leaves[persistent=true]
fill 410 223 254 411 223 254 minecraft:oak_leaves[persistent=true]
fill 410 223 259 417 224 259 minecraft:oak_leaves[persistent=true]
setblock 411 223 228 minecraft:jungle_leaves[persistent=true]
fill 411 223 248 414 223 248 minecraft:oak_leaves[persistent=true]
fill 412 223 228 413 224 228 minecraft:lime_terracotta
fill 412 223 254 412 224 255 minecraft:azalea_leaves[persistent=true]
fill 412 223 256 417 224 256 minecraft:oak_leaves[persistent=true]
fill 413 223 242 417 224 242 minecraft:oak_leaves[persistent=true]
fill 413 223 243 413 224 244 minecraft:jungle_leaves[persistent=true]
fill 413 223 245 417 223 247 minecraft:oak_leaves[persistent=true]
fill 413 223 254 417 224 255 minecraft:oak_leaves[persistent=true]
fill 414 223 243 417 224 244 minecraft:oak_leaves[persistent=true]
fill 415 223 228 418 223 228 minecraft:lime_terracotta
fill 415 223 248 415 224 248 minecraft:azalea_leaves[persistent=true]
fill 415 223 270 415 224 270 minecraft:green_terracotta
fill 416 223 248 417 224 248 minecraft:oak_leaves[persistent=true]
fill 416 223 270 418 225 270 minecraft:lime_terracotta
fill 418 223 229 418 223 231 minecraft:lime_terracotta
fill 418 223 232 418 224 232 minecraft:jungle_log
fill 418 223 233 418 257 235 minecraft:lime_terracotta
fill 418 223 236 418 226 236 minecraft:azalea_leaves[persistent=true]
fill 418 223 239 418 226 239 minecraft:azalea_leaves[persistent=true]
fill 418 223 240 418 223 241 minecraft:lime_terracotta
fill 418 223 243 418 226 246 minecraft:lime_terracotta
fill 418 223 248 418 223 258 minecraft:lime_terracotta
fill 418 223 259 418 227 259 minecraft:jungle_leaves[persistent=true]
fill 418 223 260 418 226 262 minecraft:azalea_leaves[persistent=true]
fill 418 223 263 418 223 269 minecraft:lime_terracotta
fill 376 224 228 376 225 230 minecraft:oak_leaves[persistent=true]
fill 376 224 234 376 257 234 minecraft:lime_terracotta
fill 376 224 237 376 225 238 minecraft:azalea_leaves[persistent=true]
fill 376 224 239 376 224 242 minecraft:lime_terracotta
setblock 376 224 243 minecraft:green_terracotta
fill 376 224 244 376 224 250 minecraft:lime_terracotta
setblock 376 224 251 minecraft:green_terracotta
fill 376 224 252 376 224 257 minecraft:lime_terracotta
fill 376 224 262 376 226 262 minecraft:jungle_leaves[persistent=true]
fill 377 224 228 378 235 228 minecraft:lime_terracotta
fill 378 224 270 378 262 270 minecraft:lime_terracotta
setblock 379 224 228 minecraft:mossy_cobblestone
fill 379 224 229 379 224 247 minecraft:oak_leaves[persistent=true]
fill 379 224 249 379 224 269 minecraft:oak_leaves[persistent=true]
fill 380 224 228 387 224 228 minecraft:lime_terracotta
fill 380 224 229 381 224 246 minecraft:oak_leaves[persistent=true]
fill 380 224 247 380 225 247 minecraft:jungle_leaves[persistent=true]
fill 380 224 248 380 225 248 minecraft:green_concrete
fill 380 224 249 380 225 249 minecraft:azalea_leaves[persistent=true]
fill 380 224 250 380 224 269 minecraft:oak_leaves[persistent=true]
fill 381 224 247 382 224 254 minecraft:oak_leaves[persistent=true]
fill 381 224 255 382 225 255 minecraft:azalea_leaves[persistent=true]
fill 382 224 245 383 224 245 minecraft:green_concrete
setblock 382 224 246 minecraft:oak_leaves[persistent=true]
fill 382 224 256 382 225 256 minecraft:jungle_leaves[persistent=true]
fill 382 224 270 382 261 270 minecraft:lime_terracotta
setblock 383 224 243 minecraft:oak_leaves[persistent=true]
fill 383 224 244 383 225 244 minecraft:bone_block
setblock 383 224 246 minecraft:azalea_leaves[persistent=true]
fill 383 224 247 383 224 251 minecraft:oak_leaves[persistent=true]
fill 383 224 253 384 224 259 minecraft:oak_leaves[persistent=true]
fill 383 224 260 383 225 260 minecraft:bone_block
fill 383 224 261 383 224 269 minecraft:oak_leaves[persistent=true]
fill 384 224 244 384 225 244 minecraft:azalea_leaves[persistent=true]
fill 384 224 245 384 224 247 minecraft:green_terracotta
setblock 384 224 248 minecraft:lime_terracotta
fill 384 224 249 384 224 251 minecraft:green_terracotta
setblock 384 224 260 minecraft:oak_leaves[persistent=true]
setblock 384 224 261 minecraft:green_concrete
fill 384 224 262 384 224 269 minecraft:oak_leaves[persistent=true]
fill 385 224 229 385 224 240 minecraft:oak_leaves[persistent=true]
setblock 385 224 241 minecraft:lime_terracotta
fill 385 224 242 385 226 242 minecraft:green_terracotta
fill 385 224 246 385 226 246 minecraft:green_terracotta
fill 385 224 250 385 230 250 minecraft:green_terracotta
fill 385 224 252 385 228 252 minecraft:green_terracotta
setblock 385 224 253 minecraft:lime_terracotta
fill 385 224 254 385 225 255 minecraft:green_terracotta
fill 385 224 256 385 224 259 minecraft:oak_leaves[persistent=true]
fill 385 224 260 385 225 260 minecraft:green_concrete
setblock 385 224 262 minecraft:green_concrete
fill 385 224 263 388 224 269 minecraft:oak_leaves[persistent=true]
fill 385 224 270 385 246 270 minecraft:lime_terracotta
setblock 386 224 240 minecraft:azalea_leaves[persistent=true]
fill 386 224 243 386 227 243 minecraft:green_terracotta
fill 386 224 244 386 225 244 minecraft:bone_block
fill 386 224 245 386 225 245 minecraft:green_terracotta
fill 386 224 255 386 230 255 minecraft:green_terracotta
setblock 386 224 257 minecraft:green_terracotta
fill 386 224 258 386 224 259 minecraft:oak_leaves[persistent=true]
fill 386 224 260 386 225 260 minecraft:bone_block
fill 386 224 261 386 225 261 minecraft:green_concrete
fill 386 224 262 388 224 262 minecraft:oak_leaves[persistent=true]
fill 387 224 238 387 225 239 minecraft:azalea_leaves[persistent=true]
fill 388 224 229 388 224 235 minecraft:oak_leaves[persistent=true]
fill 388 224 236 388 229 236 minecraft:brown_terracotta
setblock 388 224 260 minecraft:lime_terracotta
setblock 388 224 261 minecraft:oak_leaves[persistent=true]
fill 389 224 229 389 224 234 minecraft:oak_leaves[persistent=true]
fill 389 224 235 389 229 235 minecraft:brown_terracotta
fill 389 224 236 389 229 236 minecraft:green_terracotta
fill 389 224 243 389 226 243 minecraft:green_terracotta
fill 389 224 244 389 225 244 minecraft:bone_block
fill 389 224 245 389 225 246 minecraft:green_terracotta
fill 389 224 252 389 228 252 minecraft:bone_block
fill 389 224 260 389 225 260 minecraft:bone_block
setblock 389 224 261 minecraft:lime_terracotta
fill 389 224 262 389 224 263 minecraft:green_concrete
fill 389 224 264 389 224 269 minecraft:oak_leaves[persistent=true]
fill 389 224 270 389 308 270 minecraft:lime_terracotta
fill 390 224 229 390 224 233 minecraft:oak_leaves[persistent=true]
fill 390 224 234 390 229 234 minecraft:brown_terracotta
fill 390 224 235 390 229 235 minecraft:green_terracotta
setblock 390 224 247 minecraft:red_terracotta
fill 390 224 262 391 225 262 minecraft:jungle_leaves[persistent=true]
fill 391 224 244 391 227 244 minecraft:green_terracotta
fill 391 224 246 392 224 246 minecraft:red_terracotta
fill 391 224 263 391 225 263 minecraft:jungle_leaves[persistent=true]
fill 392 224 234 392 224 235 minecraft:azalea_leaves[persistent=true]
setblock 392 224 236 minecraft:green_concrete
fill 392 224 243 392 227 243 minecraft:green_terracotta
fill 392 224 244 392 225 244 minecraft:bone_block
setblock 392 224 245 minecraft:green_terracotta
fill 392 224 260 392 225 260 minecraft:bone_block
fill 392 224 261 392 225 261 minecraft:green_terracotta
fill 393 224 229 393 224 232 minecraft:oak_leaves[persistent=true]
setblock 393 224 233 minecraft:brown_terracotta
setblock 393 224 235 minecraft:azalea_leaves[persistent=true]
setblock 393 224 236 minecraft:green_terracotta
fill 393 224 244 393 225 244 minecraft:green_terracotta
setblock 393 224 245 minecraft:red_terracotta
fill 393 224 260 394 226 260 minecraft:green_terracotta
fill 393 224 264 393 224 269 minecraft:oak_leaves[persistent=true]
fill 393 224 270 394 224 270 minecraft:lime_terracotta
fill 394 224 229 394 224 231 minecraft:oak_leaves[persistent=true]
fill 394 224 232 394 229 232 minecraft:brown_terracotta
setblock 394 224 233 minecraft:green_terracotta
setblock 394 224 245 minecraft:green_terracotta
fill 394 224 246 395 224 246 minecraft:red_terracotta
fill 394 224 263 394 224 264 minecraft:green_terracotta
fill 394 224 265 394 224 269 minecraft:oak_leaves[persistent=true]
fill 395 224 232 395 224 233 minecraft:green_concrete
setblock 395 224 234 minecraft:green_terracotta
fill 395 224 243 395 227 243 minecraft:green_terracotta
fill 395 224 244 395 225 244 minecraft:bone_block
fill 395 224 252 395 228 252 minecraft:bone_block
setblock 395 224 257 minecraft:red_terracotta
fill 395 224 260 395 225 260 minecraft:bone_block
fill 395 224 261 395 233 261 minecraft:green_terracotta
setblock 395 224 264 minecraft:green_terracotta
fill 395 224 265 395 224 266 minecraft:green_concrete
fill 395 224 267 395 224 269 minecraft:oak_leaves[persistent=true]
setblock 395 224 270 minecraft:jungle_leaves[persistent=true]
setblock 396 224 228 minecraft:lime_terracotta
fill 396 224 232 400 229 232 minecraft:brown_terracotta
fill 396 224 233 396 225 234 minecraft:green_concrete
fill 396 224 244 397 226 244 minecraft:green_terracotta
setblock 396 224 247 minecraft:red_terracotta
setblock 396 224 256 minecraft:red_terracotta
fill 396 224 260 397 231 260 minecraft:green_terracotta
setblock 396 224 264 minecraft:lime_terracotta
fill 396 224 265 397 225 265 minecraft:green_concrete
fill 396 224 270 400 225 270 minecraft:lime_terracotta
setblock 397 224 228 minecraft:green_terracotta
fill 397 224 233 399 224 234 minecraft:green_terracotta
setblock 397 224 248 minecraft:red_terracotta
setblock 397 224 255 minecraft:red_terracotta
setblock 397 224 256 minecraft:green_terracotta
fill 397 224 264 399 224 264 minecraft:green_terracotta
fill 398 224 228 401 224 228 minecraft:lime_terracotta
fill 398 224 243 398 229 243 minecraft:green_terracotta
fill 398 224 244 398 225 244 minecraft:bone_block
fill 398 224 249 398 224 250 minecraft:red_terracotta
fill 398 224 253 398 224 254 minecraft:red_terracotta
setblock 398 224 255 minecraft:green_terracotta
fill 398 224 260 398 225 260 minecraft:bone_block
fill 398 224 261 398 228 261 minecraft:green_terracotta
fill 398 224 265 417 224 265 minecraft:oak_leaves[persistent=true]
fill 399 224 244 400 229 244 minecraft:green_terracotta
setblock 399 224 250 minecraft:green_terracotta
fill 400 224 233 400 229 233 minecraft:green_terracotta
setblock 400 224 264 minecraft:lime_terracotta
fill 401 224 232 417 224 232 minecraft:oak_leaves[persistent=true]
setblock 401 224 233 minecraft:brown_terracotta
setblock 401 224 235 minecraft:green_terracotta
fill 401 224 243 401 231 243 minecraft:green_terracotta
fill 401 224 244 401 225 244 minecraft:bone_block
fill 401 224 259 401 225 259 minecraft:green_terracotta
fill 401 224 260 401 225 260 minecraft:bone_block
setblock 401 224 261 minecraft:green_terracotta
fill 401 224 264 417 224 264 minecraft:oak_leaves[persistent=true]
setblock 402 224 228 minecraft:green_terracotta
fill 402 224 235 402 225 235 minecraft:azalea_leaves[persistent=true]
fill 402 224 262 403 225 262 minecraft:green_concrete
fill 403 224 228 408 248 228 minecraft:lime_terracotta
fill 403 224 234 403 224 235 minecraft:green_concrete
setblock 403 224 263 minecraft:green_concrete
fill 403 224 270 403 240 270 minecraft:lime_terracotta
fill 404 224 234 404 229 234 minecraft:brown_terracotta
fill 404 224 235 404 229 235 minecraft:green_terracotta
fill 404 224 261 404 225 262 minecraft:green_terracotta
fill 404 224 263 417 224 263 minecraft:oak_leaves[persistent=true]
fill 405 224 234 417 224 234 minecraft:oak_leaves[persistent=true]
fill 405 224 235 405 229 235 minecraft:brown_terracotta
fill 405 224 236 405 229 236 minecraft:green_terracotta
setblock 405 224 261 minecraft:lime_terracotta
fill 405 224 262 417 224 262 minecraft:oak_leaves[persistent=true]
fill 406 224 235 417 224 235 minecraft:oak_leaves[persistent=true]
fill 406 224 236 406 229 236 minecraft:brown_terracotta
fill 406 224 259 406 224 260 minecraft:green_terracotta
fill 406 224 261 417 224 261 minecraft:oak_leaves[persistent=true]
fill 406 224 270 406 235 270 minecraft:lime_terracotta
fill 407 224 236 417 224 236 minecraft:oak_leaves[persistent=true]
fill 407 224 238 408 225 238 minecraft:jungle_leaves[persistent=true]
setblock 407 224 239 minecraft:green_terracotta
fill 407 224 259 407 225 259 minecraft:green_concrete
fill 407 224 260 417 224 260 minecraft:oak_leaves[persistent=true]
setblock 408 224 239 minecraft:brown_terracotta
setblock 408 224 240 minecraft:lime_terracotta
fill 408 224 241 408 226 241 minecraft:green_terracotta
setblock 408 224 256 minecraft:lime_terracotta
setblock 408 224 257 minecraft:green_terracotta
fill 408 224 258 408 225 258 minecraft:green_concrete
fill 408 224 270 411 229 270 minecraft:lime_terracotta
setblock 409 224 228 minecraft:green_terracotta
setblock 409 224 238 minecraft:green_concrete
fill 409 224 239 417 224 240 minecraft:oak_leaves[persistent=true]
setblock 409 224 241 minecraft:lime_terracotta
fill 409 224 242 409 226 242 minecraft:green_terracotta
fill 409 224 246 409 226 246 minecraft:green_terracotta
fill 409 224 250 409 230 250 minecraft:green_terracotta
fill 409 224 252 409 227 252 minecraft:green_terracotta
setblock 409 224 253 minecraft:lime_terracotta
fill 409 224 254 409 224 255 minecraft:green_terracotta
fill 409 224 256 411 224 258 minecraft:oak_leaves[persistent=true]
fill 410 224 228 411 267 228 minecraft:lime_terracotta
fill 410 224 238 417 224 238 minecraft:oak_leaves[persistent=true]
fill 410 224 241 411 224 244 minecraft:oak_leaves[persistent=true]
setblock 410 224 245 minecraft:green_terracotta
setblock 410 224 246 minecraft:lime_terracotta
fill 410 224 247 410 226 247 minecraft:green_terracotta
setblock 410 224 249 minecraft:green_terracotta
setblock 410 224 250 minecraft:lime_terracotta
fill 410 224 251 410 226 251 minecraft:green_terracotta
fill 410 224 252 410 224 255 minecraft:oak_leaves[persistent=true]
fill 411 224 245 413 224 253 minecraft:oak_leaves[persistent=true]
fill 411 224 254 411 225 254 minecraft:green_concrete
fill 411 224 255 411 225 255 minecraft:azalea_leaves[persistent=true]
fill 412 224 241 412 224 242 minecraft:oak_leaves[persistent=true]
fill 412 224 243 412 225 244 minecraft:jungle_leaves[persistent=true]
fill 412 224 257 417 224 258 minecraft:oak_leaves[persistent=true]
setblock 412 224 270 minecraft:green_terracotta
fill 413 224 241 417 224 241 minecraft:oak_leaves[persistent=true]
fill 413 224 270 414 224 270 minecraft:lime_terracotta
fill 414 224 228 416 228 228 minecraft:lime_terracotta
fill 414 224 245 417 224 246 minecraft:oak_leaves[persistent=true]
fill 414 224 247 414 225 248 minecraft:azalea_leaves[persistent=true]
fill 414 224 249 414 226 249 minecraft:green_concrete
fill 414 224 250 417 224 253 minecraft:oak_leaves[persistent=true]
setblock 415 224 247 minecraft:azalea_leaves[persistent=true]
fill 415 224 249 417 224 249 minecraft:oak_leaves[persistent=true]
fill 416 224 247 417 224 247 minecraft:oak_leaves[persistent=true]
setblock 417 224 228 minecraft:green_terracotta
fill 418 224 228 418 249 229 minecraft:lime_terracotta
setblock 418 224 230 minecraft:green_terracotta
setblock 418 224 231 minecraft:jungle_log
fill 418 224 240 418 226 240 minecraft:azalea_leaves[persistent=true]
fill 418 224 241 418 256 241 minecraft:lime_terracotta
fill 418 224 247 418 228 257 minecraft:lime_terracotta
fill 418 224 258 418 225 258 minecraft:jungle_leaves[persistent=true]
fill 418 224 263 418 226 263 minecraft:azalea_leaves[persistent=true]
fill 418 224 264 418 262 264 minecraft:lime_terracotta
setblock 418 224 265 minecraft:green_terracotta
fill 418 224 266 418 224 269 minecraft:lime_terracotta
setblock 376 225 239 minecraft:green_terracotta
fill 376 225 240 376 265 243 minecraft:lime_terracotta
setblock 376 225 244 minecraft:green_terracotta
fill 376 225 245 376 232 253 minecraft:lime_terracotta
setblock 376 225 254 minecraft:mossy_cobblestone
fill 376 225 255 376 228 257 minecraft:lime_terracotta
fill 376 225 265 376 228 265 minecraft:lime_terracotta
fill 376 225 267 376 231 269 minecraft:lime_terracotta
setblock 376 225 270 minecraft:green_terracotta
fill 377 225 231 383 259 233 minecraft:jungle_log
fill 377 225 236 377 225 237 minecraft:azalea_leaves[persistent=true]
fill 377 225 258 378 225 262 minecraft:jungle_leaves[persistent=true]
fill 377 225 265 383 227 267 minecraft:jungle_log
fill 378 225 230 382 279 230 minecraft:jungle_log
fill 378 225 234 382 279 234 minecraft:jungle_log
fill 378 225 264 382 279 264 minecraft:jungle_log
fill 378 225 268 382 279 268 minecraft:jungle_log
fill 379 225 228 380 235 228 minecraft:lime_terracotta
fill 379 225 229 381 279 229 minecraft:jungle_log
fill 379 225 235 381 279 235 minecraft:jungle_log
setblock 379 225 238 minecraft:light[level=12]
setblock 379 225 245 minecraft:light[level=12]
setblock 379 225 252 minecraft:light[level=12]
fill 379 225 257 381 225 261 minecraft:jungle_leaves[persistent=true]
fill 379 225 263 381 279 263 minecraft:jungle_log
fill 379 225 269 381 279 269 minecraft:jungle_log
fill 380 225 250 381 225 250 minecraft:jungle_leaves[persistent=true]
setblock 381 225 228 minecraft:green_terracotta
fill 381 225 247 381 226 247 minecraft:jungle_leaves[persistent=true]
fill 381 225 248 381 225 249 minecraft:green_concrete
setblock 381 225 254 minecraft:green_concrete
fill 382 225 228 383 230 228 minecraft:lime_terracotta
setblock 382 225 249 minecraft:azalea_leaves[persistent=true]
setblock 382 225 253 minecraft:green_concrete
fill 382 225 254 382 226 254 minecraft:azalea_leaves[persistent=true]
fill 382 225 258 382 225 260 minecraft:jungle_leaves[persistent=true]
fill 383 225 245 383 225 246 minecraft:green_concrete
fill 383 225 255 383 227 255 minecraft:jungle_leaves[persistent=true]
setblock 384 225 228 minecraft:green_terracotta
fill 384 225 234 386 225 237 minecraft:azalea_leaves[persistent=true]
setblock 384 225 245 minecraft:azalea_leaves[persistent=true]
fill 384 225 246 384 226 246 minecraft:green_concrete
setblock 384 225 247 minecraft:azalea_leaves[persistent=true]
fill 384 225 248 384 225 250 minecraft:green_terracotta
setblock 384 225 251 minecraft:lime_terracotta
fill 384 225 252 384 226 252 minecraft:green_terracotta
fill 384 225 260 384 226 260 minecraft:green_concrete
fill 385 225 228 390 248 228 minecraft:lime_terracotta
fill 385 225 238 386 225 238 minecraft:azalea_leaves[persistent=true]
fill 385 225 241 385 227 241 minecraft:green_terracotta
setblock 385 225 243 minecraft:green_terracotta
fill 385 225 244 385 226 244 minecraft:azalea_leaves[persistent=true]
setblock 385 225 245 minecraft:green_terracotta
fill 385 225 253 385 227 253 minecraft:green_terracotta
setblock 386 225 231 minecraft:light[level=12]
setblock 386 225 233 minecraft:azalea_leaves[persistent=true]
fill 386 225 239 386 225 240 minecraft:jungle_leaves[persistent=true]
setblock 386 225 241 minecraft:azalea_leaves[persistent=true]
fill 386 225 242 387 225 242 minecraft:green_terracotta
setblock 386 225 257 minecraft:lime_terracotta
setblock 386 225 259 minecraft:azalea_leaves[persistent=true]
setblock 386 225 262 minecraft:green_concrete
setblock 386 225 266 minecraft:light[level=12]
fill 387 225 234 387 225 236 minecraft:azalea_leaves[persistent=true]
fill 387 225 237 387 228 237 minecraft:brown_terracotta
fill 387 225 240 387 226 241 minecraft:jungle_leaves[persistent=true]
fill 387 225 257 387 226 257 minecraft:green_terracotta
setblock 387 225 258 minecraft:lime_terracotta
setblock 387 225 259 minecraft:green_terracotta
fill 387 225 260 387 226 260 minecraft:azalea_leaves[persistent=true]
fill 387 225 261 387 226 261 minecraft:green_concrete
setblock 388 225 235 minecraft:azalea_leaves[persistent=true]
fill 388 225 237 388 228 237 minecraft:green_terracotta
fill 388 225 238 388 226 239 minecraft:azalea_leaves[persistent=true]
setblock 388 225 240 minecraft:green_terracotta
fill 388 225 249 388 225 254 minecraft:pink_terracotta
setblock 388 225 260 minecraft:green_terracotta
fill 389 225 247 389 225 248 minecraft:pink_terracotta
setblock 389 225 255 minecraft:pink_terracotta
fill 389 225 261 389 225 262 minecraft:green_concrete
fill 390 225 245 390 226 245 minecraft:green_terracotta
setblock 390 225 246 minecraft:pink_terracotta
setblock 390 225 256 minecraft:pink_terracotta
fill 390 225 261 390 226 261 minecraft:green_concrete
setblock 390 225 263 minecraft:azalea_leaves[persistent=true]
setblock 390 225 270 minecraft:green_terracotta
setblock 391 225 228 minecraft:green_terracotta
fill 391 225 233 391 228 233 minecraft:brown_terracotta
fill 391 225 234 393 228 234 minecraft:green_terracotta
fill 391 225 236 391 225 237 minecraft:green_concrete
fill 391 225 245 395 225 245 minecraft:pink_terracotta
fill 391 225 257 392 225 257 minecraft:pink_terracotta
fill 391 225 261 391 226 261 minecraft:jungle_leaves[persistent=true]
fill 391 225 270 392 225 270 minecraft:lime_terracotta
fill 392 225 228 395 246 228 minecraft:lime_terracotta
fill 392 225 235 392 225 236 minecraft:azalea_leaves[persistent=true]
setblock 392 225 237 minecraft:green_concrete
fill 392 225 262 392 226 263 minecraft:jungle_leaves[persistent=true]
setblock 393 225 231 minecraft:light[level=12]
fill 393 225 232 393 228 232 minecraft:brown_terracotta
fill 393 225 233 393 228 233 minecraft:green_terracotta
fill 393 225 235 393 228 236 minecraft:green_concrete
fill 393 225 237 402 225 237 minecraft:green_terracotta
fill 393 225 258 394 225 258 minecraft:pink_terracotta
setblock 393 225 264 minecraft:lime_terracotta
setblock 393 225 266 minecraft:light[level=12]
setblock 393 225 270 minecraft:jungle_leaves[persistent=true]
fill 394 225 233 395 225 234 minecraft:green_concrete
fill 394 225 235 396 225 235 minecraft:green_terracotta
setblock 394 225 263 minecraft:green_terracotta
fill 394 225 264 395 225 264 minecraft:green_concrete
fill 394 225 270 395 268 270 minecraft:lime_terracotta
fill 395 225 232 395 230 232 minecraft:brown_terracotta
fill 395 225 257 396 225 257 minecraft:pink_terracotta
setblock 395 225 258 minecraft:green_terracotta
setblock 395 225 265 minecraft:green_concrete
setblock 396 225 228 minecraft:green_terracotta
setblock 396 225 246 minecraft:pink_terracotta
setblock 396 225 264 minecraft:jungle_leaves[persistent=true]
fill 397 225 228 400 229 228 minecraft:lime_terracotta
fill 397 225 233 399 230 233 minecraft:green_terracotta
fill 397 225 234 397 226 235 minecraft:green_concrete
setblock 397 225 247 minecraft:pink_terracotta
setblock 397 225 256 minecraft:pink_terracotta
fill 397 225 257 398 226 257 minecraft:green_terracotta
fill 397 225 264 397 226 264 minecraft:green_concrete
fill 398 225 234 399 225 235 minecraft:green_terracotta
fill 398 225 248 398 225 249 minecraft:pink_terracotta
fill 398 225 254 398 225 255 minecraft:pink_terracotta
setblock 398 225 264 minecraft:jungle_leaves[persistent=true]
fill 399 225 250 399 225 253 minecraft:pink_terracotta
fill 399 225 264 400 225 264 minecraft:green_terracotta
setblock 400 225 231 minecraft:light[level=12]
fill 400 225 235 400 233 235 minecraft:green_terracotta
fill 400 225 251 400 226 252 minecraft:green_terracotta
setblock 400 225 266 minecraft:light[level=12]
setblock 401 225 228 minecraft:green_terracotta
fill 401 225 232 401 228 232 minecraft:brown_terracotta
fill 401 225 233 401 228 233 minecraft:green_terracotta
fill 401 225 235 401 225 236 minecraft:azalea_leaves[persistent=true]
fill 401 225 261 401 226 261 minecraft:azalea_leaves[persistent=true]
fill 401 225 262 401 225 263 minecraft:green_concrete
setblock 401 225 264 minecraft:lime_terracotta
fill 402 225 228 402 267 228 minecraft:lime_terracotta
fill 402 225 234 403 228 234 minecraft:green_terracotta
fill 402 225 236 402 226 236 minecraft:azalea_leaves[persistent=true]
setblock 402 225 261 minecraft:jungle_leaves[persistent=true]
fill 403 225 233 403 228 233 minecraft:brown_terracotta
fill 403 225 235 403 225 236 minecraft:green_concrete
fill 403 225 261 403 226 261 minecraft:green_concrete
fill 403 225 263 403 227 263 minecraft:green_terracotta
fill 404 225 236 404 226 236 minecraft:green_concrete
fill 405 225 231 408 225 234 minecraft:jungle_leaves[persistent=true]
fill 405 225 261 405 227 261 minecraft:green_terracotta
fill 406 225 230 408 225 230 minecraft:jungle_leaves[persistent=true]
fill 406 225 237 406 228 237 minecraft:green_terracotta
fill 406 225 238 406 225 239 minecraft:azalea_leaves[persistent=true]
setblock 406 225 258 minecraft:azalea_leaves[persistent=true]
fill 406 225 259 406 226 259 minecraft:green_concrete
setblock 406 225 260 minecraft:green_terracotta
fill 407 225 237 407 228 237 minecraft:brown_terracotta
fill 407 225 239 407 226 239 minecraft:azalea_leaves[persistent=true]
fill 407 225 257 407 226 258 minecraft:green_concrete
setblock 407 225 266 minecraft:light[level=12]
fill 408 225 239 409 225 239 minecraft:green_concrete
setblock 408 225 240 minecraft:green_terracotta
fill 408 225 256 408 226 256 minecraft:green_terracotta
fill 408 225 257 408 226 257 minecraft:green_concrete
setblock 408 225 259 minecraft:green_concrete
fill 409 225 228 409 245 228 minecraft:lime_terracotta
fill 409 225 231 409 225 233 minecraft:jungle_leaves[persistent=true]
fill 409 225 241 409 226 241 minecraft:green_terracotta
setblock 409 225 253 minecraft:green_terracotta
fill 409 225 254 410 226 254 minecraft:green_concrete
setblock 409 225 255 minecraft:green_terracotta
fill 409 225 258 411 225 262 minecraft:oak_leaves[persistent=true]
setblock 410 225 243 minecraft:green_concrete
setblock 410 225 244 minecraft:green_terracotta
setblock 410 225 245 minecraft:lime_terracotta
fill 410 225 246 410 227 246 minecraft:green_terracotta
setblock 410 225 249 minecraft:lime_terracotta
fill 410 225 250 410 227 250 minecraft:green_terracotta
setblock 410 225 252 minecraft:green_terracotta
fill 410 225 255 410 226 255 minecraft:azalea_leaves[persistent=true]
fill 411 225 231 417 229 233 minecraft:jungle_log
fill 411 225 242 411 226 242 minecraft:azalea_leaves[persistent=true]
fill 411 225 243 411 225 245 minecraft:jungle_leaves[persistent=true]
fill 411 225 253 411 226 253 minecraft:jungle_leaves[persistent=true]
fill 411 225 265 417 279 267 minecraft:jungle_log
fill 412 225 228 412 235 228 minecraft:lime_terracotta
fill 412 225 230 416 279 230 minecraft:jungle_log
fill 412 225 234 416 279 234 minecraft:jungle_log
fill 412 225 258 412 225 261 minecraft:oak_leaves[persistent=true]
fill 412 225 264 416 279 264 minecraft:jungle_log
fill 412 225 268 416 279 268 minecraft:jungle_log
fill 412 225 270 412 300 270 minecraft:lime_terracotta
setblock 413 225 228 minecraft:green_terracotta
fill 413 225 229 415 279 229 minecraft:jungle_log
fill 413 225 235 415 279 235 minecraft:jungle_log
fill 413 225 247 413 226 247 minecraft:azalea_leaves[persistent=true]
fill 413 225 248 413 225 249 minecraft:green_concrete
setblock 413 225 260 minecraft:oak_leaves[persistent=true]
fill 413 225 263 415 279 263 minecraft:jungle_log
fill 413 225 269 415 279 269 minecraft:jungle_log
setblock 413 225 270 minecraft:green_terracotta
setblock 414 225 238 minecraft:light[level=12]
setblock 414 225 245 minecraft:light[level=12]
fill 414 225 246 414 226 246 minecraft:jungle_leaves[persistent=true]
setblock 414 225 252 minecraft:light[level=12]
setblock 414 225 259 minecraft:light[level=12]
fill 414 225 270 415 263 270 minecraft:lime_terracotta
fill 415 225 259 416 225 261 minecraft:jungle_leaves[persistent=true]
fill 416 225 237 417 225 239 minecraft:azalea_leaves[persistent=true]
setblock 416 225 247 minecraft:green_wool
fill 416 225 258 417 226 258 minecraft:jungle_leaves[persistent=true]
setblock 416 225 262 minecraft:jungle_leaves[persistent=true]
fill 417 225 228 417 228 228 minecraft:lime_terracotta
fill 417 225 236 417 226 236 minecraft:azalea_leaves[persistent=true]
fill 417 225 259 417 226 260 minecraft:jungle_leaves[persistent=true]
fill 417 225 261 417 225 263 minecraft:azalea_leaves[persistent=true]
fill 418 225 230 418 235 232 minecraft:lime_terracotta
fill 418 225 242 418 308 242 minecraft:lime_terracotta
fill 418 225 265 418 235 267 minecraft:lime_terracotta
setblock 418 225 268 minecraft:green_terracotta
fill 418 225 269 418 262 269 minecraft:lime_terracotta
fill 376 226 228 376 235 228 minecraft:lime_terracotta
setblock 376 226 229 minecraft:oak_leaves[persistent=true]
fill 376 226 230 376 253 230 minecraft:lime_terracotta
setblock 376 226 237 minecraft:azalea_leaves[persistent=true]
fill 376 226 238 376 305 239 minecraft:lime_terracotta
fill 376 226 244 376 253 244 minecraft:lime_terracotta
fill 376 226 254 376 238 254 minecraft:lime_terracotta
fill 376 226 263 376 249 263 minecraft:lime_terracotta
setblock 376 226 264 minecraft:green_concrete
fill 376 226 270 376 248 270 minecraft:lime_terracotta
fill 377 226 259 377 226 262 minecraft:jungle_leaves[persistent=true]
fill 378 226 258 381 226 260 minecraft:jungle_leaves[persistent=true]
setblock 379 226 239 minecraft:light[level=15]
setblock 379 226 247 minecraft:light[level=15]
setblock 379 226 255 minecraft:light[level=15]
setblock 380 226 248 minecraft:moss_block
setblock 380 226 261 minecraft:jungle_leaves[persistent=true]
fill 381 226 228 381 265 228 minecraft:lime_terracotta
fill 381 226 246 382 227 246 minecraft:jungle_leaves[persistent=true]
fill 381 226 248 382 226 248 minecraft:green_concrete
setblock 381 226 249 minecraft:azalea_leaves[persistent=true]
fill 381 226 250 381 226 251 minecraft:jungle_leaves[persistent=true]
fill 382 226 249 382 227 249 minecraft:green_concrete
fill 382 226 250 383 226 250 minecraft:azalea_leaves[persistent=true]
fill 382 226 251 382 227 251 minecraft:jungle_leaves[persistent=true]
setblock 382 226 252 minecraft:green_concrete
fill 382 226 253 382 227 253 minecraft:azalea_leaves[persistent=true]
fill 382 226 258 382 226 259 minecraft:jungle_leaves[persistent=true]
fill 383 226 245 383 227 245 minecraft:bone_block
setblock 383 226 246 minecraft:green_concrete
setblock 383 226 253 minecraft:green_concrete
setblock 383 226 256 minecraft:jungle_leaves[persistent=true]
fill 383 226 259 383 227 259 minecraft:bone_block
fill 384 226 228 384 234 228 minecraft:lime_terracotta
fill 384 226 236 386 226 237 minecraft:azalea_leaves[persistent=true]
fill 384 226 244 384 227 244 minecraft:green_terracotta
fill 384 226 245 385 226 245 minecraft:green_concrete
fill 384 226 247 384 227 247 minecraft:green_concrete
setblock 384 226 248 minecraft:azalea_leaves[persistent=true]
setblock 384 226 249 minecraft:green_terracotta
setblock 384 226 250 minecraft:lime_terracotta
fill 384 226 251 384 228 251 minecraft:green_terracotta
fill 384 226 259 385 226 259 minecraft:green_concrete
fill 385 226 234 386 226 235 minecraft:azalea_leaves[persistent=true]
setblock 385 226 243 minecraft:lime_terracotta
setblock 385 226 254 minecraft:green_terracotta
setblock 385 226 255 minecraft:lime_terracotta
fill 386 226 239 386 229 239 minecraft:brown_terracotta
fill 386 226 240 386 226 241 minecraft:jungle_leaves[persistent=true]
fill 386 226 242 387 226 242 minecraft:azalea_leaves[persistent=true]
fill 386 226 244 386 227 244 minecraft:azalea_leaves[persistent=true]
fill 386 226 245 386 227 245 minecraft:bone_block
setblock 386 226 256 minecraft:lime_terracotta
fill 386 226 257 386 227 257 minecraft:green_terracotta
fill 386 226 259 386 227 259 minecraft:bone_block
setblock 387 226 231 minecraft:light[level=15]
fill 387 226 235 387 226 236 minecraft:azalea_leaves[persistent=true]
fill 387 226 238 387 230 238 minecraft:brown_terracotta
fill 387 226 239 387 229 239 minecraft:green_terracotta
fill 387 226 258 387 226 259 minecraft:azalea_leaves[persistent=true]
setblock 387 226 262 minecraft:green_concrete
setblock 387 226 263 minecraft:light[level=15]
fill 388 226 240 389 226 240 minecraft:azalea_leaves[persistent=true]
fill 388 226 241 388 227 242 minecraft:jungle_leaves[persistent=true]
fill 388 226 247 388 229 247 minecraft:green_terracotta
fill 388 226 248 388 227 254 minecraft:red_terracotta
fill 388 226 260 388 227 260 minecraft:azalea_leaves[persistent=true]
fill 388 226 261 389 227 261 minecraft:green_concrete
fill 389 226 238 389 227 238 minecraft:azalea_leaves[persistent=true]
setblock 389 226 239 minecraft:green_terracotta
fill 389 226 244 389 232 244 minecraft:green_terracotta
fill 389 226 245 389 227 245 minecraft:bone_block
setblock 389 226 246 minecraft:green_terracotta
fill 389 226 247 389 227 247 minecraft:red_terracotta
fill 389 226 255 389 227 255 minecraft:red_terracotta
fill 389 226 259 389 227 259 minecraft:bone_block
setblock 389 226 260 minecraft:green_concrete
setblock 390 226 246 minecraft:red_terracotta
fill 390 226 256 390 227 256 minecraft:red_terracotta
fill 390 226 262 390 227 262 minecraft:green_terracotta
fill 390 226 270 391 252 270 minecraft:lime_terracotta
fill 391 226 228 391 303 228 minecraft:lime_terracotta
setblock 391 226 236 minecraft:green_concrete
fill 391 226 237 392 226 237 minecraft:azalea_leaves[persistent=true]
fill 391 226 238 392 226 238 minecraft:green_concrete
fill 391 226 245 391 227 245 minecraft:red_terracotta
fill 391 226 257 391 227 257 minecraft:red_terracotta
setblock 391 226 262 minecraft:jungle_leaves[persistent=true]
fill 391 226 263 391 227 263 minecraft:green_terracotta
fill 392 226 235 392 232 235 minecraft:green_terracotta
setblock 392 226 236 minecraft:azalea_leaves[persistent=true]
fill 392 226 244 395 226 244 minecraft:red_terracotta
fill 392 226 245 392 227 245 minecraft:bone_block
fill 392 226 258 395 226 258 minecraft:red_terracotta
fill 392 226 259 392 227 259 minecraft:bone_block
fill 392 226 260 392 227 261 minecraft:jungle_leaves[persistent=true]
setblock 392 226 270 minecraft:moss_block
fill 393 226 237 393 227 237 minecraft:green_concrete
fill 393 226 238 400 226 238 minecraft:green_terracotta
fill 393 226 262 393 226 263 minecraft:jungle_leaves[persistent=true]
fill 393 226 264 393 228 264 minecraft:green_terracotta
fill 393 226 270 393 257 270 minecraft:lime_terracotta
fill 394 226 233 396 229 233 minecraft:green_terracotta
fill 394 226 234 394 226 235 minecraft:green_concrete
fill 394 226 236 397 226 237 minecraft:green_terracotta
fill 394 226 259 394 227 259 minecraft:green_terracotta
fill 394 226 262 394 226 264 minecraft:green_concrete
setblock 395 226 231 minecraft:light[level=15]
fill 395 226 234 395 226 235 minecraft:jungle_leaves[persistent=true]
fill 395 226 245 395 227 245 minecraft:bone_block
setblock 395 226 247 minecraft:light[level=15]
setblock 395 226 255 minecraft:light[level=15]
fill 395 226 259 395 227 259 minecraft:bone_block
fill 395 226 260 395 231 260 minecraft:green_terracotta
setblock 395 226 263 minecraft:green_concrete
setblock 395 226 264 minecraft:azalea_leaves[persistent=true]
fill 396 226 228 396 308 228 minecraft:lime_terracotta
fill 396 226 234 396 226 235 minecraft:azalea_leaves[persistent=true]
setblock 396 226 245 minecraft:red_terracotta
setblock 396 226 257 minecraft:red_terracotta
fill 396 226 259 396 228 259 minecraft:green_terracotta
fill 396 226 264 396 227 264 minecraft:green_terracotta
fill 396 226 270 399 231 270 minecraft:lime_terracotta
setblock 397 226 245 minecraft:green_terracotta
setblock 397 226 246 minecraft:red_terracotta
setblock 397 226 256 minecraft:red_terracotta
fill 397 226 263 397 227 263 minecraft:jungle_leaves[persistent=true]
setblock 397 226 265 minecraft:green_concrete
fill 398 226 234 399 232 234 minecraft:green_terracotta
fill 398 226 235 398 227 236 minecraft:green_concrete
fill 398 226 237 400 226 237 minecraft:green_terracotta
fill 398 226 244 398 228 244 minecraft:green_terracotta
fill 398 226 245 398 227 245 minecraft:bone_block
fill 398 226 246 399 226 246 minecraft:green_terracotta
setblock 398 226 247 minecraft:red_terracotta
setblock 398 226 255 minecraft:red_terracotta
fill 398 226 259 398 227 259 minecraft:bone_block
fill 398 226 260 398 228 260 minecraft:green_terracotta
setblock 398 226 263 minecraft:green_terracotta
fill 398 226 264 398 227 264 minecraft:green_concrete
fill 399 226 235 399 233 236 minecraft:green_terracotta
fill 399 226 247 400 226 247 minecraft:green_terracotta
fill 399 226 248 399 226 254 minecraft:red_terracotta
fill 399 226 255 399 226 256 minecraft:green_terracotta
fill 399 226 259 400 226 259 minecraft:green_terracotta
fill 399 226 262 399 232 262 minecraft:green_terracotta
fill 399 226 263 399 226 264 minecraft:jungle_leaves[persistent=true]
fill 400 226 236 400 234 236 minecraft:green_terracotta
fill 400 226 245 400 229 245 minecraft:green_terracotta
fill 400 226 248 401 227 248 minecraft:green_terracotta
fill 400 226 262 401 226 262 minecraft:green_concrete
fill 400 226 263 401 226 264 minecraft:green_terracotta
setblock 400 226 270 minecraft:moss_block
fill 401 226 228 401 239 228 minecraft:lime_terracotta
fill 401 226 235 403 231 235 minecraft:green_terracotta
fill 401 226 236 401 226 238 minecraft:azalea_leaves[persistent=true]
fill 401 226 244 401 230 244 minecraft:green_terracotta
fill 401 226 245 401 227 245 minecraft:bone_block
fill 401 226 259 401 227 259 minecraft:bone_block
fill 401 226 260 402 227 260 minecraft:azalea_leaves[persistent=true]
fill 402 226 237 402 226 238 minecraft:green_terracotta
fill 402 226 245 402 231 245 minecraft:green_terracotta
fill 402 226 251 403 226 251 minecraft:green_terracotta
setblock 402 226 261 minecraft:azalea_leaves[persistent=true]
fill 402 226 262 402 226 263 minecraft:green_terracotta
setblock 403 226 231 minecraft:light[level=15]
fill 403 226 236 403 227 236 minecraft:green_concrete
setblock 403 226 237 minecraft:jungle_leaves[persistent=true]
fill 403 226 238 403 227 238 minecraft:green_terracotta
fill 403 226 252 404 226 252 minecraft:green_terracotta
fill 403 226 259 403 227 259 minecraft:jungle_leaves[persistent=true]
fill 403 226 260 403 227 260 minecraft:green_concrete
fill 403 226 262 403 228 262 minecraft:green_terracotta
fill 404 226 237 404 227 237 minecraft:green_concrete
fill 404 226 251 406 232 251 minecraft:bone_block
fill 404 226 253 405 232 254 minecraft:bone_block
fill 404 226 261 404 230 261 minecraft:green_terracotta
setblock 404 226 262 minecraft:lime_terracotta
fill 405 226 232 408 226 232 minecraft:jungle_leaves[persistent=true]
fill 405 226 238 405 226 240 minecraft:azalea_leaves[persistent=true]
fill 405 226 252 407 232 252 minecraft:bone_block
setblock 405 226 258 minecraft:azalea_leaves[persistent=true]
fill 405 226 259 405 227 259 minecraft:green_concrete
fill 406 226 231 408 226 231 minecraft:jungle_leaves[persistent=true]
fill 406 226 233 408 226 234 minecraft:jungle_leaves[persistent=true]
fill 406 226 238 406 226 239 minecraft:jungle_leaves[persistent=true]
setblock 406 226 240 minecraft:azalea_leaves[persistent=true]
fill 406 226 253 406 226 254 minecraft:green_terracotta
fill 406 226 258 406 227 258 minecraft:green_concrete
setblock 406 226 260 minecraft:lime_terracotta
setblock 407 226 238 minecraft:jungle_leaves[persistent=true]
fill 407 226 255 407 227 255 minecraft:green_terracotta
fill 407 226 256 407 227 256 minecraft:green_concrete
setblock 407 226 259 minecraft:azalea_leaves[persistent=true]
fill 408 226 239 408 226 240 minecraft:green_concrete
fill 408 226 254 408 227 254 minecraft:green_concrete
setblock 409 226 240 minecraft:green_concrete
setblock 409 226 243 minecraft:green_concrete
fill 409 226 244 409 226 245 minecraft:green_terracotta
setblock 409 226 253 minecraft:green_concrete
fill 409 226 255 409 227 256 minecraft:azalea_leaves[persistent=true]
fill 409 226 259 412 226 261 minecraft:oak_leaves[persistent=true]
setblock 410 226 242 minecraft:green_concrete
fill 410 226 243 410 226 245 minecraft:jungle_leaves[persistent=true]
setblock 410 226 248 minecraft:lime_terracotta
fill 410 226 249 410 228 249 minecraft:green_terracotta
setblock 410 226 252 minecraft:lime_terracotta
fill 410 226 253 410 227 253 minecraft:jungle_leaves[persistent=true]
setblock 410 226 256 minecraft:azalea_leaves[persistent=true]
fill 410 226 258 411 226 258 minecraft:oak_leaves[persistent=true]
setblock 411 226 239 minecraft:light[level=15]
fill 411 226 243 411 226 244 minecraft:jungle_leaves[persistent=true]
fill 411 226 245 411 227 245 minecraft:green_concrete
setblock 411 226 247 minecraft:light[level=15]
setblock 411 226 254 minecraft:jungle_leaves[persistent=true]
setblock 411 226 255 minecraft:light[level=15]
setblock 411 226 262 minecraft:oak_leaves[persistent=true]
setblock 411 226 263 minecraft:light[level=15]
setblock 412 226 244 minecraft:green_concrete
fill 412 226 247 412 227 247 minecraft:azalea_leaves[persistent=true]
fill 412 226 249 412 228 250 minecraft:green_concrete
fill 413 226 228 413 235 228 minecraft:lime_terracotta
fill 413 226 245 413 227 246 minecraft:jungle_leaves[persistent=true]
fill 413 226 249 413 227 249 minecraft:green_concrete
fill 413 226 270 413 274 270 minecraft:lime_terracotta
fill 415 226 260 416 226 260 minecraft:jungle_leaves[persistent=true]
fill 416 226 237 417 226 237 minecraft:azalea_leaves[persistent=true]
setblock 416 226 259 minecraft:jungle_leaves[persistent=true]
fill 416 226 261 417 226 261 minecraft:jungle_leaves[persistent=true]
fill 416 226 270 416 308 270 minecraft:lime_terracotta
fill 417 226 238 417 226 239 minecraft:azalea_leaves[persistent=true]
setblock 417 226 262 minecraft:azalea_leaves[persistent=true]
setblock 417 226 270 minecraft:jungle_leaves[persistent=true]
fill 418 226 258 418 274 258 minecraft:lime_terracotta
fill 418 226 268 418 255 268 minecraft:lime_terracotta
fill 418 226 270 418 262 270 minecraft:lime_terracotta
fill 376 227 229 376 232 229 minecraft:lime_terracotta
fill 376 227 235 376 241 237 minecraft:lime_terracotta
fill 376 227 258 376 242 258 minecraft:lime_terracotta
setblock 376 227 259 minecraft:jungle_leaves[persistent=true]
fill 376 227 260 376 248 260 minecraft:lime_terracotta
fill 376 227 262 376 247 262 minecraft:lime_terracotta
fill 376 227 264 376 248 264 minecraft:lime_terracotta
fill 379 227 259 381 227 259 minecraft:jungle_leaves[persistent=true]
setblock 381 227 251 minecraft:jungle_leaves[persistent=true]
fill 382 227 245 382 228 245 minecraft:jungle_leaves[persistent=true]
fill 382 227 248 385 227 248 minecraft:green_concrete
fill 382 227 252 382 228 252 minecraft:jungle_leaves[persistent=true]
fill 383 227 246 383 229 246 minecraft:bone_block
fill 383 227 249 383 229 249 minecraft:green_concrete
fill 383 227 250 384 227 250 minecraft:azalea_leaves[persistent=true]
setblock 383 227 253 minecraft:azalea_leaves[persistent=true]
fill 383 227 258 383 229 258 minecraft:bone_block
setblock 384 227 245 minecraft:lime_terracotta
fill 384 227 246 384 229 246 minecraft:green_terracotta
setblock 384 227 249 minecraft:lime_terracotta
setblock 384 227 252 minecraft:green_concrete
fill 384 227 255 384 228 255 minecraft:jungle_leaves[persistent=true]
fill 384 227 258 384 227 259 minecraft:green_concrete
fill 385 227 235 385 227 236 minecraft:azalea_leaves[persistent=true]
setblock 385 227 242 minecraft:lime_terracotta
fill 385 227 243 385 228 244 minecraft:green_terracotta
fill 385 227 245 385 227 247 minecraft:green_concrete
setblock 385 227 249 minecraft:azalea_leaves[persistent=true]
setblock 385 227 254 minecraft:lime_terracotta
setblock 385 227 255 minecraft:green_terracotta
fill 386 227 240 388 229 240 minecraft:green_terracotta
fill 386 227 241 386 227 242 minecraft:jungle_leaves[persistent=true]
fill 386 227 246 386 229 246 minecraft:bone_block
fill 386 227 256 386 229 256 minecraft:green_terracotta
fill 386 227 258 386 229 258 minecraft:bone_block
setblock 387 227 236 minecraft:azalea_leaves[persistent=true]
fill 387 227 241 387 233 241 minecraft:green_terracotta
fill 387 227 242 387 227 244 minecraft:azalea_leaves[persistent=true]
fill 387 227 257 388 227 257 minecraft:azalea_leaves[persistent=true]
fill 387 227 258 387 228 258 minecraft:green_concrete
setblock 387 227 259 minecraft:green_terracotta
fill 388 227 238 388 230 239 minecraft:green_terracotta
setblock 388 227 258 minecraft:azalea_leaves[persistent=true]
setblock 388 227 262 minecraft:green_concrete
fill 389 227 239 389 227 240 minecraft:azalea_leaves[persistent=true]
fill 389 227 241 390 227 241 minecraft:green_terracotta
fill 389 227 242 389 227 243 minecraft:jungle_leaves[persistent=true]
fill 389 227 246 389 229 246 minecraft:bone_block
fill 389 227 258 389 229 258 minecraft:bone_block
fill 389 227 260 389 228 260 minecraft:azalea_leaves[persistent=true]
fill 390 227 238 390 227 239 minecraft:green_concrete
fill 390 227 240 390 229 240 minecraft:azalea_leaves[persistent=true]
fill 390 227 242 390 233 242 minecraft:green_terracotta
setblock 390 227 245 minecraft:red_terracotta
setblock 390 227 261 minecraft:green_terracotta
fill 391 227 236 392 227 236 minecraft:green_terracotta
fill 391 227 237 391 227 238 minecraft:azalea_leaves[persistent=true]
fill 391 227 239 392 227 239 minecraft:green_concrete
setblock 391 227 261 minecraft:azalea_leaves[persistent=true]
fill 391 227 262 392 228 262 minecraft:green_terracotta
fill 392 227 237 392 227 238 minecraft:green_concrete
fill 392 227 244 393 227 244 minecraft:red_terracotta
fill 392 227 246 392 229 246 minecraft:bone_block
fill 392 227 258 392 229 258 minecraft:bone_block
fill 392 227 263 393 228 263 minecraft:green_terracotta
fill 392 227 270 392 238 270 minecraft:lime_terracotta
fill 393 227 238 393 229 238 minecraft:green_concrete
fill 393 227 239 399 227 239 minecraft:green_terracotta
fill 393 227 258 394 227 258 minecraft:red_terracotta
fill 393 227 259 393 227 262 minecraft:jungle_leaves[persistent=true]
fill 394 227 234 397 231 234 minecraft:green_terracotta
setblock 394 227 235 minecraft:green_concrete
fill 394 227 236 394 228 236 minecraft:jungle_leaves[persistent=true]
fill 394 227 237 397 227 238 minecraft:green_terracotta
setblock 394 227 243 minecraft:red_terracotta
fill 394 227 260 394 231 260 minecraft:green_terracotta
fill 394 227 262 395 228 262 minecraft:jungle_leaves[persistent=true]
setblock 394 227 263 minecraft:green_concrete
setblock 394 227 264 minecraft:azalea_leaves[persistent=true]
fill 395 227 235 395 233 236 minecraft:green_terracotta
fill 395 227 244 396 227 244 minecraft:red_terracotta
fill 395 227 246 395 229 246 minecraft:bone_block
fill 395 227 258 395 229 258 minecraft:bone_block
fill 395 227 263 395 231 263 minecraft:green_terracotta
setblock 395 227 264 minecraft:lime_terracotta
fill 396 227 235 397 227 235 minecraft:azalea_leaves[persistent=true]
setblock 396 227 236 minecraft:green_terracotta
setblock 396 227 258 minecraft:red_terracotta
fill 396 227 262 397 233 262 minecraft:green_terracotta
fill 397 227 236 397 229 236 minecraft:azalea_leaves[persistent=true]
setblock 397 227 244 minecraft:green_terracotta
setblock 397 227 245 minecraft:red_terracotta
setblock 397 227 257 minecraft:red_terracotta
setblock 397 227 258 minecraft:green_terracotta
fill 397 227 264 397 228 264 minecraft:green_terracotta
fill 398 227 237 398 228 237 minecraft:green_concrete
fill 398 227 238 399 234 238 minecraft:green_terracotta
fill 398 227 246 398 229 246 minecraft:bone_block
setblock 398 227 256 minecraft:red_terracotta
setblock 398 227 257 minecraft:green_terracotta
fill 398 227 258 398 229 258 minecraft:bone_block
fill 398 227 262 398 229 262 minecraft:jungle_leaves[persistent=true]
fill 398 227 263 399 227 263 minecraft:green_concrete
fill 399 227 237 400 234 237 minecraft:green_terracotta
setblock 399 227 246 minecraft:green_terracotta
fill 399 227 247 399 227 248 minecraft:red_terracotta
fill 399 227 254 399 227 255 minecraft:red_terracotta
setblock 399 227 256 minecraft:green_terracotta
fill 399 227 258 399 230 259 minecraft:green_terracotta
fill 399 227 261 400 228 261 minecraft:green_concrete
setblock 399 227 264 minecraft:green_concrete
fill 400 227 238 400 228 239 minecraft:azalea_leaves[persistent=true]
setblock 400 227 247 minecraft:green_terracotta
fill 400 227 249 400 227 253 minecraft:red_terracotta
setblock 400 227 259 minecraft:azalea_leaves[persistent=true]
setblock 400 227 262 minecraft:green_concrete
setblock 400 227 263 minecraft:jungle_leaves[persistent=true]
fill 400 227 264 401 227 264 minecraft:green_terracotta
fill 400 227 270 400 308 270 minecraft:lime_terracotta
fill 401 227 236 402 233 236 minecraft:green_terracotta
fill 401 227 237 401 227 238 minecraft:azalea_leaves[persistent=true]
fill 401 227 239 403 228 239 minecraft:green_terracotta
fill 401 227 246 401 229 246 minecraft:bone_block
fill 401 227 249 402 227 250 minecraft:green_terracotta
fill 401 227 253 401 227 254 minecraft:green_terracotta
fill 401 227 256 401 228 257 minecraft:green_terracotta
fill 401 227 258 401 229 258 minecraft:bone_block
fill 401 227 261 401 229 263 minecraft:green_terracotta
fill 402 227 237 403 227 237 minecraft:green_concrete
fill 402 227 238 402 234 238 minecraft:green_terracotta
fill 402 227 246 403 230 246 minecraft:green_terracotta
setblock 402 227 251 minecraft:green_terracotta
fill 402 227 253 403 231 253 minecraft:bone_block
setblock 402 227 254 minecraft:green_terracotta
fill 402 227 257 402 227 258 minecraft:green_terracotta
fill 402 227 259 402 228 259 minecraft:azalea_leaves[persistent=true]
fill 402 227 261 402 231 262 minecraft:green_terracotta
setblock 402 227 263 minecraft:lime_terracotta
fill 403 227 240 403 236 240 minecraft:green_terracotta
fill 403 227 250 403 232 252 minecraft:bone_block
fill 403 227 254 403 231 254 minecraft:bone_block
fill 403 227 258 404 227 258 minecraft:jungle_leaves[persistent=true]
fill 403 227 261 403 232 261 minecraft:green_terracotta
fill 404 227 236 404 231 236 minecraft:green_terracotta
fill 404 227 238 405 227 238 minecraft:green_concrete
fill 404 227 239 404 227 240 minecraft:azalea_leaves[persistent=true]
fill 404 227 249 405 231 250 minecraft:bone_block
fill 404 227 252 404 233 252 minecraft:bone_block
fill 404 227 257 405 227 257 minecraft:azalea_leaves[persistent=true]
fill 404 227 259 404 227 260 minecraft:green_concrete
fill 404 227 262 404 229 262 minecraft:green_terracotta
fill 405 227 239 406 227 239 minecraft:jungle_leaves[persistent=true]
setblock 405 227 240 minecraft:azalea_leaves[persistent=true]
fill 405 227 255 405 227 256 minecraft:green_terracotta
fill 405 227 258 405 228 258 minecraft:green_concrete
fill 406 227 238 406 230 238 minecraft:green_terracotta
fill 406 227 240 406 228 240 minecraft:green_concrete
setblock 406 227 249 minecraft:green_terracotta
fill 406 227 250 406 233 250 minecraft:bone_block
fill 406 227 253 407 232 254 minecraft:bone_block
fill 406 227 256 406 228 256 minecraft:green_concrete
setblock 406 227 259 minecraft:azalea_leaves[persistent=true]
fill 406 227 260 406 229 260 minecraft:green_terracotta
fill 407 227 233 407 227 234 minecraft:jungle_leaves[persistent=true]
fill 407 227 238 407 230 238 minecraft:brown_terracotta
setblock 407 227 239 minecraft:green_concrete
setblock 407 227 250 minecraft:green_terracotta
fill 407 227 251 407 233 251 minecraft:bone_block
setblock 407 227 257 minecraft:green_concrete
fill 407 227 258 407 227 259 minecraft:green_terracotta
fill 408 227 239 408 229 239 minecraft:brown_terracotta
fill 408 227 240 408 227 243 minecraft:green_concrete
setblock 408 227 251 minecraft:green_terracotta
fill 408 227 252 408 231 253 minecraft:bone_block
fill 408 227 256 408 228 256 minecraft:azalea_leaves[persistent=true]
setblock 408 227 257 minecraft:lime_terracotta
fill 409 227 241 409 227 242 minecraft:green_concrete
fill 409 227 243 410 227 243 minecraft:jungle_leaves[persistent=true]
setblock 409 227 244 minecraft:green_terracotta
fill 409 227 245 409 227 246 minecraft:jungle_leaves[persistent=true]
setblock 409 227 253 minecraft:jungle_leaves[persistent=true]
setblock 409 227 254 minecraft:green_concrete
fill 410 227 242 410 228 242 minecraft:azalea_leaves[persistent=true]
setblock 410 227 244 minecraft:jungle_leaves[persistent=true]
fill 410 227 245 410 228 245 minecraft:green_concrete
setblock 410 227 247 minecraft:lime_terracotta
fill 410 227 248 410 229 248 minecraft:green_terracotta
setblock 410 227 251 minecraft:lime_terracotta
fill 410 227 252 410 228 252 minecraft:green_terracotta
fill 410 227 260 411 227 260 minecraft:oak_leaves[persistent=true]
setblock 411 227 244 minecraft:green_concrete
fill 411 227 246 411 228 247 minecraft:azalea_leaves[persistent=true]
fill 411 227 250 411 230 250 minecraft:green_concrete
fill 412 227 245 412 228 245 minecraft:jungle_leaves[persistent=true]
setblock 412 227 246 minecraft:azalea_leaves[persistent=true]
setblock 413 227 250 minecraft:green_concrete
fill 417 227 270 417 244 270 minecraft:lime_terracotta
fill 418 227 236 418 250 236 minecraft:lime_terracotta
setblock 418 227 237 minecraft:azalea_leaves[persistent=true]
fill 418 227 238 418 262 240 minecraft:lime_terracotta
setblock 418 227 243 minecraft:green_concrete
fill 418 227 244 418 240 246 minecraft:lime_terracotta
fill 418 227 260 418 247 263 minecraft:lime_terracotta
fill 376 228 259 376 249 259 minecraft:lime_terracotta
fill 376 228 261 376 247 261 minecraft:lime_terracotta
fill 377 228 265 381 279 267 minecraft:jungle_log
setblock 377 228 270 minecraft:mossy_cobblestone
setblock 382 228 251 minecraft:green_concrete
fill 382 228 265 383 279 266 minecraft:jungle_log
fill 382 228 267 382 235 267 minecraft:jungle_leaves[persistent=true]
fill 383 228 245 383 229 245 minecraft:jungle_leaves[persistent=true]
fill 383 228 248 385 228 248 minecraft:green_concrete
fill 383 228 251 383 231 251 minecraft:bone_block
fill 383 228 253 383 231 253 minecraft:bone_block
fill 383 228 267 383 279 267 minecraft:jungle_log
setblock 384 228 244 minecraft:lime_terracotta
fill 384 228 245 385 229 245 minecraft:green_terracotta
setblock 384 228 247 minecraft:green_terracotta
fill 384 228 249 385 229 249 minecraft:green_concrete
setblock 384 228 250 minecraft:azalea_leaves[persistent=true]
setblock 384 228 252 minecraft:lime_terracotta
fill 384 228 257 384 228 258 minecraft:green_concrete
setblock 385 228 241 minecraft:lime_terracotta
fill 385 228 242 385 230 242 minecraft:green_terracotta
fill 385 228 246 385 230 246 minecraft:green_terracotta
setblock 385 228 247 minecraft:jungle_leaves[persistent=true]
setblock 385 228 253 minecraft:lime_terracotta
fill 385 228 254 385 229 255 minecraft:jungle_leaves[persistent=true]
fill 386 228 241 386 231 241 minecraft:green_terracotta
fill 386 228 242 386 229 243 minecraft:jungle_leaves[persistent=true]
fill 386 228 244 386 233 244 minecraft:green_terracotta
setblock 386 228 245 minecraft:green_concrete
fill 386 228 248 386 229 248 minecraft:jungle_leaves[persistent=true]
fill 386 228 251 386 231 251 minecraft:bone_block
fill 386 228 253 386 231 253 minecraft:bone_block
fill 386 228 257 387 228 257 minecraft:green_concrete
fill 387 228 242 389 232 242 minecraft:green_terracotta
fill 387 228 243 387 228 244 minecraft:azalea_leaves[persistent=true]
setblock 387 228 259 minecraft:lime_terracotta
fill 388 228 241 389 234 241 minecraft:green_terracotta
fill 388 228 248 388 228 253 minecraft:pink_terracotta
fill 388 228 254 388 233 254 minecraft:green_terracotta
setblock 388 228 257 minecraft:azalea_leaves[persistent=true]
fill 388 228 258 388 232 258 minecraft:green_terracotta
setblock 388 228 260 minecraft:lime_terracotta
fill 389 228 238 389 232 239 minecraft:green_terracotta
setblock 389 228 240 minecraft:azalea_leaves[persistent=true]
setblock 389 228 243 minecraft:jungle_leaves[persistent=true]
fill 389 228 245 389 229 245 minecraft:green_terracotta
setblock 389 228 247 minecraft:pink_terracotta
fill 389 228 251 389 231 251 minecraft:bone_block
fill 389 228 253 389 231 253 minecraft:bone_block
fill 389 228 254 389 228 255 minecraft:pink_terracotta
setblock 389 228 259 minecraft:green_concrete
fill 389 228 261 389 228 262 minecraft:green_concrete
fill 390 228 238 391 228 238 minecraft:azalea_leaves[persistent=true]
setblock 390 228 239 minecraft:green_concrete
setblock 390 228 241 minecraft:azalea_leaves[persistent=true]
setblock 390 228 245 minecraft:pink_terracotta
setblock 390 228 256 minecraft:pink_terracotta
fill 390 228 261 390 229 261 minecraft:green_concrete
setblock 390 228 262 minecraft:lime_terracotta
fill 391 228 236 391 232 237 minecraft:green_terracotta
fill 391 228 239 391 229 239 minecraft:azalea_leaves[persistent=true]
setblock 391 228 244 minecraft:pink_terracotta
setblock 391 228 257 minecraft:pink_terracotta
fill 391 228 261 392 232 261 minecraft:green_terracotta
setblock 391 228 263 minecraft:lime_terracotta
fill 392 228 236 392 229 236 minecraft:green_concrete
fill 392 228 237 392 234 237 minecraft:green_terracotta
setblock 392 228 238 minecraft:green_concrete
setblock 392 228 239 minecraft:jungle_leaves[persistent=true]
fill 392 228 243 396 228 243 minecraft:pink_terracotta
setblock 392 228 259 minecraft:green_terracotta
fill 392 228 260 392 229 260 minecraft:azalea_leaves[persistent=true]
fill 393 228 237 394 228 237 minecraft:jungle_leaves[persistent=true]
fill 393 228 239 393 230 239 minecraft:green_concrete
setblock 393 228 258 minecraft:pink_terracotta
fill 393 228 259 393 228 260 minecraft:jungle_leaves[persistent=true]
setblock 393 228 261 minecraft:green_concrete
fill 393 228 262 393 229 262 minecraft:azalea_leaves[persistent=true]
fill 394 228 235 394 233 235 minecraft:green_terracotta
fill 394 228 238 397 232 239 minecraft:green_terracotta
setblock 394 228 259 minecraft:pink_terracotta
setblock 394 228 263 minecraft:azalea_leaves[persistent=true]
fill 394 228 264 395 229 264 minecraft:green_terracotta
fill 395 228 237 397 228 237 minecraft:green_terracotta
fill 395 228 251 395 231 251 minecraft:bone_block
fill 395 228 253 395 231 253 minecraft:bone_block
setblock 395 228 259 minecraft:green_terracotta
fill 396 228 235 398 233 235 minecraft:green_terracotta
setblock 396 228 236 minecraft:azalea_leaves[persistent=true]
fill 396 228 258 397 228 258 minecraft:pink_terracotta
setblock 396 228 264 minecraft:lime_terracotta
setblock 397 228 244 minecraft:pink_terracotta
fill 397 228 263 397 232 263 minecraft:green_terracotta
setblock 398 228 236 minecraft:green_concrete
fill 398 228 239 399 232 239 minecraft:green_terracotta
setblock 398 228 245 minecraft:pink_terracotta
fill 398 228 251 398 231 251 minecraft:bone_block
fill 398 228 253 398 231 253 minecraft:bone_block
setblock 398 228 257 minecraft:pink_terracotta
fill 398 228 259 398 230 259 minecraft:green_terracotta
setblock 398 228 263 minecraft:jungle_leaves[persistent=true]
fill 398 228 264 399 229 264 minecraft:green_terracotta
setblock 399 228 246 minecraft:pink_terracotta
fill 399 228 255 399 228 256 minecraft:pink_terracotta
fill 399 228 263 400 228 263 minecraft:green_concrete
fill 400 228 247 400 228 250 minecraft:pink_terracotta
fill 400 228 252 400 228 254 minecraft:pink_terracotta
fill 400 228 259 401 233 259 minecraft:green_terracotta
fill 400 228 262 400 233 262 minecraft:green_terracotta
setblock 400 228 264 minecraft:lime_terracotta
fill 401 228 237 402 234 237 minecraft:green_terracotta
setblock 401 228 238 minecraft:azalea_leaves[persistent=true]
fill 401 228 245 401 230 245 minecraft:green_terracotta
fill 401 228 248 401 228 250 minecraft:green_terracotta
fill 401 228 251 402 231 251 minecraft:bone_block
fill 401 228 253 401 231 253 minecraft:bone_block
fill 401 228 254 401 229 254 minecraft:green_terracotta
fill 401 228 260 404 228 260 minecraft:green_terracotta
setblock 401 228 264 minecraft:green_terracotta
fill 402 228 249 402 229 249 minecraft:green_terracotta
fill 402 228 250 402 231 250 minecraft:bone_block
fill 402 228 252 402 232 252 minecraft:bone_block
fill 402 228 254 402 231 254 minecraft:bone_block
fill 402 228 255 402 231 255 minecraft:green_terracotta
fill 402 228 257 402 233 257 minecraft:green_terracotta
fill 402 228 258 402 229 258 minecraft:azalea_leaves[persistent=true]
fill 402 228 263 402 230 263 minecraft:green_terracotta
fill 403 228 236 403 232 236 minecraft:green_terracotta
fill 403 228 237 403 228 238 minecraft:green_concrete
fill 403 228 248 403 231 248 minecraft:green_terracotta
fill 403 228 249 403 231 249 minecraft:bone_block
fill 403 228 255 407 230 255 minecraft:bone_block
setblock 403 228 258 minecraft:jungle_leaves[persistent=true]
fill 403 228 259 403 234 259 minecraft:green_terracotta
setblock 403 228 263 minecraft:lime_terracotta
fill 404 228 237 404 232 237 minecraft:green_terracotta
fill 404 228 238 404 229 240 minecraft:jungle_leaves[persistent=true]
fill 404 228 248 404 230 248 minecraft:bone_block
fill 404 228 257 404 228 259 minecraft:green_concrete
setblock 405 228 238 minecraft:green_concrete
fill 405 228 239 405 228 240 minecraft:jungle_leaves[persistent=true]
setblock 405 228 248 minecraft:green_terracotta
fill 405 228 256 405 234 257 minecraft:green_terracotta
fill 405 228 259 405 228 260 minecraft:azalea_leaves[persistent=true]
setblock 405 228 261 minecraft:lime_terracotta
setblock 406 228 239 minecraft:green_concrete
fill 406 228 249 406 232 249 minecraft:bone_block
fill 406 228 258 406 230 259 minecraft:green_terracotta
fill 406 228 267 406 244 267 minecraft:moss_block
fill 407 228 239 407 229 239 minecraft:green_terracotta
fill 407 228 250 407 233 250 minecraft:bone_block
fill 407 228 256 407 229 256 minecraft:azalea_leaves[persistent=true]
fill 407 228 257 407 228 258 minecraft:green_terracotta
setblock 407 228 259 minecraft:lime_terracotta
setblock 408 228 240 minecraft:lime_terracotta
fill 408 228 241 409 229 241 minecraft:azalea_leaves[persistent=true]
fill 408 228 242 408 229 242 minecraft:green_concrete
fill 408 228 243 409 228 243 minecraft:jungle_leaves[persistent=true]
fill 408 228 251 408 232 251 minecraft:bone_block
fill 408 228 254 408 231 254 minecraft:bone_block
fill 408 228 257 408 229 257 minecraft:green_terracotta
setblock 409 228 242 minecraft:azalea_leaves[persistent=true]
setblock 409 228 244 minecraft:jungle_leaves[persistent=true]
fill 409 228 245 409 229 245 minecraft:green_concrete
setblock 409 228 246 minecraft:jungle_leaves[persistent=true]
setblock 409 228 252 minecraft:jungle_leaves[persistent=true]
fill 409 228 253 409 230 253 minecraft:bone_block
fill 409 228 254 409 229 255 minecraft:green_terracotta
setblock 410 228 244 minecraft:green_terracotta
fill 410 228 246 410 229 246 minecraft:azalea_leaves[persistent=true]
fill 410 228 247 410 229 247 minecraft:green_terracotta
setblock 410 228 250 minecraft:lime_terracotta
fill 410 228 251 410 229 251 minecraft:green_terracotta
fill 411 228 244 412 229 244 minecraft:jungle_leaves[persistent=true]
fill 418 228 237 418 287 237 minecraft:lime_terracotta
fill 418 228 243 418 308 243 minecraft:lime_terracotta
fill 418 228 259 418 248 259 minecraft:lime_terracotta
fill 376 229 255 376 263 256 minecraft:lime_terracotta
setblock 376 229 257 minecraft:moss_block
setblock 376 229 265 minecraft:mossy_cobblestone
fill 377 229 270 377 248 270 minecraft:lime_terracotta
fill 383 229 247 383 230 247 minecraft:bone_block
setblock 383 229 252 minecraft:azalea_leaves[persistent=true]
fill 383 229 257 383 230 257 minecraft:bone_block
setblock 384 229 247 minecraft:lime_terracotta
fill 384 229 248 384 230 248 minecraft:green_terracotta
setblock 384 229 250 minecraft:green_terracotta
setblock 384 229 251 minecraft:lime_terracotta
fill 384 229 256 384 229 257 minecraft:green_concrete
setblock 385 229 241 minecraft:green_terracotta
setblock 385 229 243 minecraft:green_terracotta
setblock 385 229 244 minecraft:lime_terracotta
setblock 385 229 247 minecraft:green_terracotta
setblock 385 229 248 minecraft:green_concrete
setblock 385 229 252 minecraft:lime_terracotta
fill 385 229 253 385 231 253 minecraft:green_terracotta
fill 386 229 245 386 232 245 minecraft:green_terracotta
fill 386 229 247 386 230 247 minecraft:bone_block
fill 386 229 252 386 230 252 minecraft:green_terracotta
fill 386 229 254 386 230 254 minecraft:jungle_leaves[persistent=true]
fill 386 229 257 386 230 257 minecraft:bone_block
fill 387 229 243 387 233 244 minecraft:green_terracotta
fill 387 229 245 387 229 246 minecraft:green_concrete
fill 387 229 247 387 234 248 minecraft:green_terracotta
fill 387 229 254 387 232 254 minecraft:green_terracotta
setblock 387 229 257 minecraft:green_concrete
setblock 387 229 258 minecraft:lime_terracotta
fill 388 229 237 388 231 237 minecraft:brown_terracotta
fill 388 229 248 388 230 253 minecraft:red_terracotta
fill 388 229 257 388 233 257 minecraft:green_terracotta
setblock 388 229 259 minecraft:lime_terracotta
fill 388 229 260 389 229 260 minecraft:green_terracotta
fill 389 229 240 389 234 240 minecraft:green_terracotta
fill 389 229 243 389 235 243 minecraft:green_terracotta
fill 389 229 247 389 230 247 minecraft:bone_block
fill 389 229 254 389 230 255 minecraft:red_terracotta
fill 389 229 257 389 230 257 minecraft:bone_block
fill 389 229 259 389 232 259 minecraft:green_terracotta
setblock 389 229 261 minecraft:green_terracotta
fill 390 229 238 390 233 239 minecraft:green_terracotta
fill 390 229 241 390 236 241 minecraft:green_terracotta
setblock 390 229 245 minecraft:red_terracotta
fill 390 229 256 390 230 256 minecraft:red_terracotta
setblock 390 229 262 minecraft:green_terracotta
fill 391 229 234 391 231 234 minecraft:brown_terracotta
setblock 391 229 238 minecraft:azalea_leaves[persistent=true]
fill 391 229 240 392 233 240 minecraft:green_terracotta
setblock 391 229 244 minecraft:red_terracotta
setblock 391 229 257 minecraft:red_terracotta
setblock 391 229 262 minecraft:lime_terracotta
fill 392 229 234 393 230 234 minecraft:green_terracotta
fill 392 229 238 392 234 238 minecraft:green_terracotta
setblock 392 229 239 minecraft:green_concrete
setblock 392 229 243 minecraft:red_terracotta
fill 392 229 247 392 230 247 minecraft:bone_block
fill 392 229 253 392 231 253 minecraft:bone_block
fill 392 229 257 392 230 257 minecraft:bone_block
fill 392 229 259 393 230 259 minecraft:azalea_leaves[persistent=true]
fill 392 229 262 392 232 262 minecraft:green_terracotta
setblock 392 229 263 minecraft:lime_terracotta
fill 393 229 233 393 231 233 minecraft:brown_terracotta
fill 393 229 235 393 232 236 minecraft:green_terracotta
setblock 393 229 237 minecraft:jungle_leaves[persistent=true]
fill 393 229 240 393 230 240 minecraft:green_concrete
fill 393 229 242 396 229 242 minecraft:red_terracotta
setblock 393 229 260 minecraft:jungle_leaves[persistent=true]
fill 393 229 261 393 230 261 minecraft:azalea_leaves[persistent=true]
fill 393 229 263 394 229 263 minecraft:green_terracotta
fill 394 229 236 394 234 237 minecraft:green_terracotta
fill 394 229 259 396 230 259 minecraft:red_terracotta
setblock 394 229 262 minecraft:azalea_leaves[persistent=true]
fill 395 229 237 396 235 237 minecraft:green_terracotta
fill 395 229 247 395 230 247 minecraft:bone_block
fill 395 229 257 395 230 257 minecraft:bone_block
fill 395 229 262 395 232 262 minecraft:green_terracotta
fill 396 229 236 396 234 236 minecraft:green_terracotta
fill 396 229 264 396 230 264 minecraft:green_terracotta
fill 397 229 237 397 230 237 minecraft:azalea_leaves[persistent=true]
setblock 397 229 243 minecraft:red_terracotta
setblock 397 229 258 minecraft:red_terracotta
setblock 397 229 264 minecraft:lime_terracotta
fill 398 229 236 398 234 237 minecraft:green_terracotta
setblock 398 229 244 minecraft:red_terracotta
fill 398 229 247 398 230 247 minecraft:bone_block
fill 398 229 257 398 230 257 minecraft:bone_block
fill 398 229 260 399 229 261 minecraft:green_concrete
fill 398 229 263 400 230 263 minecraft:green_terracotta
setblock 399 229 245 minecraft:red_terracotta
setblock 399 229 256 minecraft:red_terracotta
fill 400 229 238 401 235 238 minecraft:green_terracotta
setblock 400 229 239 minecraft:azalea_leaves[persistent=true]
fill 400 229 246 400 229 247 minecraft:red_terracotta
fill 400 229 254 400 229 255 minecraft:red_terracotta
fill 400 229 256 400 229 257 minecraft:green_terracotta
fill 400 229 260 400 234 261 minecraft:green_terracotta
setblock 400 229 264 minecraft:green_terracotta
fill 401 229 233 401 231 233 minecraft:brown_terracotta
fill 401 229 239 402 235 239 minecraft:green_terracotta
fill 401 229 247 401 230 247 minecraft:bone_block
fill 401 229 248 401 229 250 minecraft:red_terracotta
setblock 401 229 256 minecraft:green_terracotta
fill 401 229 257 401 230 257 minecraft:bone_block
fill 401 229 260 403 233 260 minecraft:green_terracotta
fill 402 229 234 402 230 234 minecraft:green_terracotta
fill 402 229 259 402 234 259 minecraft:green_terracotta
fill 403 229 234 403 231 234 minecraft:brown_terracotta
fill 403 229 237 403 233 237 minecraft:green_terracotta
fill 403 229 238 403 229 239 minecraft:green_concrete
fill 403 229 258 403 235 258 minecraft:green_terracotta
setblock 403 229 262 minecraft:lime_terracotta
fill 404 229 241 404 236 241 minecraft:green_terracotta
fill 404 229 257 404 234 257 minecraft:green_terracotta
fill 404 229 258 404 229 259 minecraft:green_concrete
setblock 404 229 260 minecraft:azalea_leaves[persistent=true]
fill 405 229 238 405 232 239 minecraft:green_terracotta
fill 405 229 240 405 229 241 minecraft:green_concrete
fill 405 229 248 405 230 248 minecraft:bone_block
fill 405 229 258 405 233 258 minecraft:green_terracotta
setblock 405 229 259 minecraft:azalea_leaves[persistent=true]
fill 405 229 260 405 229 261 minecraft:green_terracotta
fill 406 229 237 406 231 237 minecraft:brown_terracotta
fill 406 229 239 406 231 240 minecraft:green_terracotta
fill 406 229 256 406 233 256 minecraft:green_terracotta
setblock 407 229 257 minecraft:green_terracotta
setblock 407 229 258 minecraft:lime_terracotta
fill 408 229 240 408 230 240 minecraft:green_terracotta
setblock 408 229 243 minecraft:jungle_leaves[persistent=true]
setblock 408 229 245 minecraft:green_concrete
fill 408 229 246 408 232 247 minecraft:green_terracotta
setblock 408 229 255 minecraft:bone_block
fill 408 229 256 408 230 256 minecraft:green_terracotta
fill 409 229 242 409 229 243 minecraft:green_terracotta
setblock 409 229 244 minecraft:lime_terracotta
setblock 409 229 246 minecraft:green_concrete
fill 409 229 252 409 230 252 minecraft:bone_block
setblock 410 229 245 minecraft:lime_terracotta
setblock 410 229 249 minecraft:lime_terracotta
setblock 410 229 250 minecraft:green_terracotta
fill 411 229 251 411 230 251 minecraft:green_concrete
setblock 412 229 250 minecraft:green_concrete
fill 414 229 228 414 235 228 minecraft:lime_terracotta
setblock 415 229 228 minecraft:jungle_leaves[persistent=true]
fill 416 229 228 416 248 228 minecraft:lime_terracotta
setblock 417 229 228 minecraft:green_concrete
setblock 418 229 247 minecraft:moss_block
fill 418 229 248 418 236 257 minecraft:lime_terracotta
fill 376 230 257 376 271 257 minecraft:lime_terracotta
fill 376 230 265 376 248 265 minecraft:lime_terracotta
fill 383 230 248 383 231 248 minecraft:bone_block
fill 383 230 256 383 231 256 minecraft:bone_block
setblock 384 230 249 minecraft:green_concrete
setblock 384 230 256 minecraft:green_concrete
setblock 385 230 243 minecraft:lime_terracotta
fill 385 230 244 385 231 245 minecraft:green_terracotta
setblock 385 230 247 minecraft:lime_terracotta
fill 385 230 248 385 231 249 minecraft:green_terracotta
setblock 385 230 251 minecraft:lime_terracotta
setblock 385 230 252 minecraft:green_terracotta
setblock 385 230 254 minecraft:green_terracotta
setblock 386 230 240 minecraft:lime_terracotta
fill 386 230 242 386 231 242 minecraft:green_terracotta
setblock 386 230 243 minecraft:jungle_leaves[persistent=true]
fill 386 230 246 386 233 246 minecraft:green_terracotta
fill 386 230 248 386 231 248 minecraft:bone_block
fill 386 230 256 386 231 256 minecraft:bone_block
fill 386 230 270 386 274 270 minecraft:lime_terracotta
fill 387 230 239 387 231 239 minecraft:brown_terracotta
fill 387 230 240 388 230 240 minecraft:green_terracotta
fill 387 230 245 387 233 245 minecraft:green_terracotta
setblock 387 230 246 minecraft:green_concrete
setblock 387 230 257 minecraft:lime_terracotta
setblock 387 230 258 minecraft:green_terracotta
setblock 387 230 270 minecraft:moss_block
setblock 388 230 247 minecraft:red_terracotta
fill 388 230 256 388 234 256 minecraft:green_terracotta
fill 388 230 259 388 231 259 minecraft:green_terracotta
fill 388 230 270 388 287 270 minecraft:lime_terracotta
fill 389 230 236 389 231 236 minecraft:brown_terracotta
fill 389 230 245 389 230 246 minecraft:red_terracotta
fill 389 230 248 389 231 248 minecraft:bone_block
fill 389 230 256 389 231 256 minecraft:bone_block
fill 389 230 258 389 233 258 minecraft:green_terracotta
fill 389 230 260 389 231 260 minecraft:green_terracotta
fill 390 230 235 390 231 235 minecraft:brown_terracotta
fill 390 230 240 390 235 240 minecraft:green_terracotta
fill 390 230 243 390 231 243 minecraft:green_terracotta
setblock 390 230 244 minecraft:red_terracotta
setblock 390 230 257 minecraft:red_terracotta
fill 390 230 261 390 231 261 minecraft:green_terracotta
fill 391 230 238 391 234 239 minecraft:green_terracotta
setblock 391 230 243 minecraft:red_terracotta
fill 391 230 258 392 230 258 minecraft:red_terracotta
fill 391 230 262 391 231 262 minecraft:green_terracotta
fill 392 230 236 392 233 236 minecraft:green_terracotta
fill 392 230 239 392 235 239 minecraft:green_terracotta
fill 392 230 242 394 230 242 minecraft:red_terracotta
fill 392 230 248 392 231 248 minecraft:bone_block
fill 392 230 256 392 231 256 minecraft:bone_block
fill 392 230 260 393 233 260 minecraft:green_terracotta
setblock 392 230 263 minecraft:green_terracotta
fill 393 230 237 393 234 238 minecraft:green_terracotta
fill 393 230 246 393 231 246 minecraft:white_terracotta
fill 393 230 248 393 231 248 minecraft:white_terracotta
fill 393 230 250 393 231 250 minecraft:white_terracotta
fill 393 230 262 394 231 262 minecraft:green_terracotta
setblock 393 230 263 minecraft:lime_terracotta
fill 394 230 233 394 231 233 minecraft:brown_terracotta
fill 394 230 243 394 231 243 minecraft:white_terracotta
fill 394 230 255 394 231 255 minecraft:white_terracotta
setblock 394 230 263 minecraft:green_terracotta
fill 395 230 233 396 230 233 minecraft:green_terracotta
setblock 395 230 241 minecraft:red_terracotta
fill 395 230 248 395 231 248 minecraft:bone_block
fill 395 230 256 395 231 256 minecraft:bone_block
setblock 395 230 264 minecraft:green_terracotta
fill 396 230 232 399 230 232 minecraft:brown_terracotta
setblock 396 230 241 minecraft:green_terracotta
fill 396 230 242 398 231 242 minecraft:white_terracotta
fill 396 230 256 397 231 256 minecraft:white_terracotta
fill 397 230 228 398 252 228 minecraft:lime_terracotta
fill 397 230 236 397 234 236 minecraft:green_terracotta
fill 397 230 241 397 232 241 minecraft:white_terracotta
fill 397 230 257 397 232 257 minecraft:white_terracotta
setblock 397 230 259 minecraft:red_terracotta
setblock 397 230 264 minecraft:green_terracotta
setblock 398 230 241 minecraft:green_terracotta
setblock 398 230 243 minecraft:red_terracotta
fill 398 230 248 398 231 248 minecraft:bone_block
fill 398 230 256 398 231 256 minecraft:bone_block
setblock 398 230 258 minecraft:red_terracotta
setblock 398 230 260 minecraft:green_concrete
fill 398 230 261 398 233 262 minecraft:green_terracotta
setblock 398 230 264 minecraft:lime_terracotta
setblock 399 230 228 minecraft:moss_block
fill 399 230 242 399 230 243 minecraft:green_terracotta
setblock 399 230 244 minecraft:red_terracotta
setblock 399 230 257 minecraft:red_terracotta
fill 399 230 260 399 233 261 minecraft:green_terracotta
setblock 399 230 264 minecraft:green_terracotta
fill 400 230 228 400 243 228 minecraft:lime_terracotta
fill 400 230 233 400 231 233 minecraft:brown_terracotta
fill 400 230 239 400 234 239 minecraft:green_terracotta
fill 400 230 243 400 231 243 minecraft:white_terracotta
setblock 400 230 244 minecraft:green_terracotta
setblock 400 230 245 minecraft:red_terracotta
fill 400 230 255 400 231 255 minecraft:white_terracotta
setblock 400 230 256 minecraft:red_terracotta
setblock 400 230 257 minecraft:green_terracotta
fill 401 230 246 401 231 246 minecraft:white_terracotta
fill 401 230 248 401 231 248 minecraft:bone_block
setblock 401 230 250 minecraft:white_terracotta
fill 401 230 254 401 230 255 minecraft:red_terracotta
fill 401 230 256 401 231 256 minecraft:bone_block
fill 401 230 258 402 233 258 minecraft:green_terracotta
fill 401 230 261 401 232 262 minecraft:green_terracotta
setblock 401 230 263 minecraft:lime_terracotta
fill 401 230 270 401 308 270 minecraft:lime_terracotta
setblock 402 230 249 minecraft:red_terracotta
setblock 402 230 270 minecraft:green_concrete
fill 403 230 238 404 233 238 minecraft:green_terracotta
setblock 403 230 239 minecraft:green_concrete
fill 403 230 262 403 231 262 minecraft:green_terracotta
fill 404 230 235 404 231 235 minecraft:brown_terracotta
fill 404 230 239 404 234 240 minecraft:green_terracotta
fill 404 230 258 404 233 258 minecraft:green_terracotta
setblock 404 230 259 minecraft:azalea_leaves[persistent=true]
fill 404 230 260 405 231 260 minecraft:green_terracotta
fill 404 230 268 404 239 268 minecraft:green_wool
fill 405 230 236 405 231 236 minecraft:brown_terracotta
fill 405 230 240 405 234 240 minecraft:green_terracotta
setblock 405 230 241 minecraft:green_concrete
fill 405 230 259 405 232 259 minecraft:green_terracotta
fill 407 230 239 407 231 239 minecraft:brown_terracotta
fill 407 230 249 407 231 249 minecraft:bone_block
setblock 407 230 256 minecraft:green_terracotta
setblock 407 230 257 minecraft:lime_terracotta
setblock 407 230 258 minecraft:green_terracotta
fill 408 230 241 408 230 243 minecraft:green_terracotta
fill 408 230 245 409 231 245 minecraft:green_terracotta
fill 408 230 248 408 233 249 minecraft:green_terracotta
fill 408 230 250 408 231 250 minecraft:bone_block
fill 408 230 255 408 231 255 minecraft:green_terracotta
fill 408 230 270 408 260 270 minecraft:lime_terracotta
setblock 409 230 242 minecraft:green_terracotta
setblock 409 230 243 minecraft:lime_terracotta
fill 409 230 244 409 231 244 minecraft:green_terracotta
setblock 409 230 246 minecraft:green_terracotta
setblock 409 230 247 minecraft:lime_terracotta
setblock 409 230 251 minecraft:lime_terracotta
setblock 409 230 254 minecraft:green_terracotta
setblock 409 230 270 minecraft:green_concrete
setblock 410 230 248 minecraft:lime_terracotta
fill 410 230 270 411 235 270 minecraft:lime_terracotta
fill 411 230 231 414 279 233 minecraft:jungle_log
fill 415 230 228 415 249 228 minecraft:lime_terracotta
fill 415 230 231 417 279 231 minecraft:jungle_log
fill 415 230 232 415 237 232 minecraft:moss_block
fill 415 230 233 417 279 233 minecraft:jungle_log
fill 416 230 232 417 279 232 minecraft:jungle_log
fill 417 230 228 417 249 228 minecraft:lime_terracotta
fill 418 230 247 418 308 247 minecraft:lime_terracotta
setblock 379 231 238 minecraft:light[level=12]
setblock 379 231 245 minecraft:light[level=12]
setblock 379 231 252 minecraft:light[level=12]
setblock 379 231 259 minecraft:light[level=12]
fill 381 231 252 391 232 252 minecraft:bone_block
setblock 382 231 228 minecraft:mossy_cobblestone
fill 383 231 228 383 238 228 minecraft:lime_terracotta
fill 383 231 249 383 231 250 minecraft:bone_block
fill 383 231 254 383 231 255 minecraft:bone_block
fill 385 231 243 386 231 243 minecraft:green_terracotta
setblock 385 231 246 minecraft:lime_terracotta
fill 385 231 247 386 232 247 minecraft:green_terracotta
setblock 385 231 250 minecraft:lime_terracotta
setblock 385 231 251 minecraft:green_terracotta
setblock 386 231 231 minecraft:light[level=12]
setblock 386 231 238 minecraft:light[level=12]
fill 386 231 249 386 231 250 minecraft:bone_block
fill 386 231 254 386 231 255 minecraft:bone_block
setblock 386 231 259 minecraft:light[level=12]
setblock 386 231 266 minecraft:light[level=12]
setblock 387 231 240 minecraft:lime_terracotta
fill 387 231 246 387 235 246 minecraft:green_terracotta
setblock 387 231 255 minecraft:green_terracotta
setblock 387 231 256 minecraft:lime_terracotta
setblock 387 231 257 minecraft:green_terracotta
fill 387 231 270 387 275 270 minecraft:lime_terracotta
fill 388 231 238 388 232 238 minecraft:brown_terracotta
fill 388 231 239 388 231 240 minecraft:green_terracotta
fill 388 231 247 388 231 251 minecraft:pink_terracotta
setblock 388 231 253 minecraft:pink_terracotta
fill 389 231 245 389 231 246 minecraft:pink_terracotta
fill 389 231 249 389 231 250 minecraft:bone_block
fill 389 231 254 389 231 255 minecraft:bone_block
fill 389 231 257 389 234 257 minecraft:green_terracotta
setblock 390 231 244 minecraft:pink_terracotta
fill 390 231 256 390 231 257 minecraft:pink_terracotta
setblock 391 231 243 minecraft:pink_terracotta
fill 391 231 258 392 231 258 minecraft:pink_terracotta
fill 392 231 234 392 232 234 minecraft:brown_terracotta
setblock 392 231 241 minecraft:green_terracotta
setblock 392 231 242 minecraft:pink_terracotta
fill 392 231 246 392 233 246 minecraft:white_terracotta
fill 392 231 249 392 231 250 minecraft:bone_block
fill 392 231 254 392 231 255 minecraft:bone_block
setblock 392 231 259 minecraft:green_terracotta
setblock 393 231 231 minecraft:light[level=12]
setblock 393 231 234 minecraft:green_terracotta
fill 393 231 239 393 232 240 minecraft:green_terracotta
fill 393 231 241 394 231 241 minecraft:pink_terracotta
fill 393 231 244 393 233 244 minecraft:white_terracotta
setblock 393 231 245 minecraft:light[level=12]
fill 393 231 254 393 233 254 minecraft:white_terracotta
fill 393 231 259 398 231 259 minecraft:pink_terracotta
fill 393 231 261 393 233 261 minecraft:green_terracotta
setblock 393 231 263 minecraft:green_terracotta
setblock 393 231 266 minecraft:light[level=12]
fill 394 231 242 394 233 242 minecraft:white_terracotta
fill 394 231 252 400 232 252 minecraft:bone_block
fill 394 231 256 394 233 256 minecraft:white_terracotta
setblock 394 231 263 minecraft:lime_terracotta
fill 395 231 233 399 232 233 minecraft:brown_terracotta
fill 395 231 241 396 233 241 minecraft:white_terracotta
fill 395 231 249 395 231 250 minecraft:bone_block
fill 395 231 254 395 231 255 minecraft:bone_block
fill 395 231 257 396 233 257 minecraft:white_terracotta
fill 397 231 237 397 235 237 minecraft:green_terracotta
fill 398 231 241 399 233 241 minecraft:white_terracotta
fill 398 231 249 398 231 250 minecraft:bone_block
fill 398 231 254 398 231 255 minecraft:bone_block
fill 398 231 257 399 233 257 minecraft:white_terracotta
fill 398 231 260 398 232 260 minecraft:green_terracotta
setblock 398 231 263 minecraft:lime_terracotta
fill 399 231 228 399 308 228 minecraft:lime_terracotta
setblock 399 231 242 minecraft:green_terracotta
setblock 399 231 243 minecraft:pink_terracotta
setblock 399 231 258 minecraft:pink_terracotta
fill 399 231 259 399 232 259 minecraft:green_terracotta
fill 399 231 263 401 231 263 minecraft:green_terracotta
setblock 400 231 231 minecraft:light[level=12]
fill 400 231 242 400 233 242 minecraft:white_terracotta
setblock 400 231 244 minecraft:pink_terracotta
setblock 400 231 245 minecraft:light[level=12]
fill 400 231 256 400 233 256 minecraft:white_terracotta
setblock 400 231 257 minecraft:pink_terracotta
setblock 400 231 266 minecraft:light[level=12]
fill 401 231 244 401 233 244 minecraft:white_terracotta
setblock 401 231 245 minecraft:pink_terracotta
fill 401 231 249 401 231 250 minecraft:bone_block
fill 401 231 254 401 231 255 minecraft:bone_block
setblock 401 231 257 minecraft:green_terracotta
fill 402 231 234 402 232 234 minecraft:brown_terracotta
fill 402 231 246 402 233 246 minecraft:white_terracotta
setblock 402 231 247 minecraft:pink_terracotta
fill 402 231 248 402 233 248 minecraft:white_terracotta
setblock 402 231 249 minecraft:pink_terracotta
fill 402 231 267 402 242 267 minecraft:green_wool
fill 402 231 270 402 287 270 minecraft:lime_terracotta
fill 403 231 231 403 241 231 minecraft:jungle_leaves[persistent=true]
fill 403 231 239 403 234 239 minecraft:green_terracotta
fill 403 231 246 403 231 247 minecraft:green_terracotta
fill 403 231 255 403 233 255 minecraft:green_terracotta
fill 404 231 247 404 232 248 minecraft:green_terracotta
fill 404 231 255 407 231 255 minecraft:bone_block
fill 404 231 259 404 232 259 minecraft:green_terracotta
setblock 404 231 261 minecraft:lime_terracotta
fill 405 231 241 405 235 241 minecraft:green_terracotta
fill 405 231 248 405 235 248 minecraft:green_terracotta
fill 406 231 238 406 232 238 minecraft:brown_terracotta
setblock 406 231 258 minecraft:green_terracotta
setblock 406 231 259 minecraft:lime_terracotta
setblock 407 231 231 minecraft:light[level=12]
setblock 407 231 238 minecraft:light[level=12]
setblock 407 231 240 minecraft:lime_terracotta
setblock 407 231 256 minecraft:lime_terracotta
setblock 407 231 257 minecraft:green_terracotta
setblock 407 231 259 minecraft:light[level=12]
setblock 407 231 266 minecraft:light[level=12]
setblock 408 231 241 minecraft:lime_terracotta
fill 408 231 242 408 232 243 minecraft:green_terracotta
setblock 409 231 243 minecraft:green_terracotta
setblock 409 231 246 minecraft:lime_terracotta
fill 409 231 247 409 232 247 minecraft:green_terracotta
setblock 409 231 250 minecraft:lime_terracotta
fill 409 231 251 409 231 253 minecraft:green_terracotta
fill 409 231 270 409 260 270 minecraft:lime_terracotta
setblock 414 231 238 minecraft:light[level=12]
setblock 414 231 245 minecraft:light[level=12]
setblock 414 231 252 minecraft:light[level=12]
setblock 414 231 259 minecraft:light[level=12]
fill 376 232 267 376 265 267 minecraft:lime_terracotta
setblock 376 232 268 minecraft:mossy_cobblestone
fill 376 232 269 376 249 269 minecraft:lime_terracotta
fill 382 232 228 382 258 228 minecraft:lime_terracotta
setblock 385 232 246 minecraft:green_terracotta
fill 385 232 248 386 232 248 minecraft:green_terracotta
setblock 385 232 249 minecraft:lime_terracotta
fill 385 232 250 386 232 250 minecraft:green_terracotta
setblock 386 232 242 minecraft:lime_terracotta
setblock 386 232 243 minecraft:green_terracotta
setblock 386 232 249 minecraft:green_terracotta
fill 386 232 251 386 233 251 minecraft:green_terracotta
setblock 386 232 253 minecraft:green_terracotta
setblock 386 232 254 minecraft:lime_terracotta
fill 387 232 240 388 232 240 minecraft:green_terracotta
setblock 387 232 255 minecraft:lime_terracotta
setblock 387 232 256 minecraft:green_terracotta
fill 388 232 239 388 233 239 minecraft:brown_terracotta
fill 388 232 247 388 233 251 minecraft:red_terracotta
fill 388 232 253 388 233 253 minecraft:red_terracotta
setblock 389 232 237 minecraft:brown_terracotta
fill 389 232 245 389 233 246 minecraft:red_terracotta
fill 389 232 254 389 233 255 minecraft:red_terracotta
fill 389 232 256 389 234 256 minecraft:green_terracotta
setblock 390 232 236 minecraft:brown_terracotta
fill 390 232 243 390 232 244 minecraft:red_terracotta
fill 390 232 256 390 233 257 minecraft:red_terracotta
setblock 391 232 235 minecraft:brown_terracotta
fill 391 232 242 391 233 242 minecraft:red_terracotta
fill 391 232 245 391 233 248 minecraft:white_terracotta
fill 391 232 250 391 233 251 minecraft:white_terracotta
fill 391 232 253 392 233 253 minecraft:white_terracotta
fill 391 232 258 391 233 258 minecraft:red_terracotta
fill 392 232 241 392 233 241 minecraft:red_terracotta
fill 392 232 243 393 233 243 minecraft:white_terracotta
fill 392 232 245 392 233 245 minecraft:white_terracotta
fill 392 232 248 392 233 248 minecraft:white_terracotta
fill 392 232 250 392 233 250 minecraft:white_terracotta
fill 392 232 255 393 233 255 minecraft:white_terracotta
fill 392 232 259 393 233 259 minecraft:red_terracotta
fill 393 232 234 394 232 234 minecraft:brown_terracotta
fill 393 232 241 393 233 242 minecraft:white_terracotta
fill 393 232 256 393 233 257 minecraft:white_terracotta
setblock 393 232 262 minecraft:green_terracotta
setblock 394 232 240 minecraft:red_terracotta
fill 394 232 241 394 233 241 minecraft:white_terracotta
fill 394 232 257 394 233 257 minecraft:white_terracotta
fill 394 232 260 397 233 260 minecraft:red_terracotta
setblock 394 232 262 minecraft:lime_terracotta
fill 395 232 234 397 232 234 minecraft:green_terracotta
fill 395 232 240 399 233 240 minecraft:white_terracotta
fill 395 232 258 399 233 258 minecraft:white_terracotta
setblock 395 232 263 minecraft:lime_terracotta
fill 396 232 270 398 307 270 minecraft:lime_terracotta
setblock 398 232 259 minecraft:red_terracotta
setblock 398 232 263 minecraft:green_terracotta
setblock 399 232 242 minecraft:red_terracotta
setblock 399 232 263 minecraft:lime_terracotta
setblock 399 232 270 minecraft:moss_block
fill 400 232 234 401 232 234 minecraft:brown_terracotta
fill 400 232 240 401 232 240 minecraft:green_terracotta
fill 400 232 241 401 233 241 minecraft:white_terracotta
setblock 400 232 243 minecraft:red_terracotta
fill 400 232 257 401 233 257 minecraft:white_terracotta
fill 401 232 235 402 232 235 minecraft:green_terracotta
fill 401 232 242 401 233 243 minecraft:white_terracotta
fill 401 232 254 401 233 256 minecraft:white_terracotta
fill 402 232 241 402 232 242 minecraft:green_terracotta
fill 402 232 243 402 233 243 minecraft:white_terracotta
fill 402 232 245 403 233 245 minecraft:white_terracotta
setblock 402 232 247 minecraft:red_terracotta
fill 402 232 250 402 233 250 minecraft:white_terracotta
setblock 402 232 251 minecraft:bone_block
fill 402 232 253 402 233 253 minecraft:white_terracotta
setblock 402 232 254 minecraft:red_terracotta
fill 402 232 255 402 233 255 minecraft:white_terracotta
setblock 402 232 261 minecraft:green_terracotta
setblock 402 232 262 minecraft:lime_terracotta
setblock 403 232 235 minecraft:brown_terracotta
fill 403 232 242 403 234 243 minecraft:green_terracotta
fill 403 232 246 403 233 248 minecraft:white_terracotta
fill 403 232 249 403 233 249 minecraft:red_terracotta
setblock 403 232 253 minecraft:bone_block
setblock 403 232 254 minecraft:green_terracotta
setblock 404 232 236 minecraft:brown_terracotta
fill 404 232 243 404 235 243 minecraft:green_terracotta
fill 404 232 249 405 233 249 minecraft:green_terracotta
fill 404 232 250 405 232 250 minecraft:bone_block
fill 404 232 255 406 232 255 minecraft:bone_block
setblock 404 232 260 minecraft:lime_terracotta
setblock 405 232 237 minecraft:brown_terracotta
fill 406 232 239 406 233 239 minecraft:brown_terracotta
fill 406 232 240 407 232 240 minecraft:green_terracotta
setblock 406 232 258 minecraft:lime_terracotta
fill 407 232 249 407 233 249 minecraft:green_terracotta
setblock 407 232 255 minecraft:lime_terracotta
setblock 407 232 256 minecraft:green_terracotta
setblock 408 232 244 minecraft:lime_terracotta
fill 408 232 245 408 233 245 minecraft:green_terracotta
fill 408 232 250 409 232 250 minecraft:green_terracotta
setblock 408 232 252 minecraft:lime_terracotta
fill 408 232 253 408 232 254 minecraft:green_terracotta
setblock 409 232 246 minecraft:green_terracotta
setblock 409 232 249 minecraft:lime_terracotta
setblock 376 233 229 minecraft:moss_block
fill 376 233 245 376 238 248 minecraft:lime_terracotta
setblock 376 233 249 minecraft:jungle_leaves[persistent=true]
fill 376 233 250 376 250 253 minecraft:lime_terracotta
fill 376 233 268 376 252 268 minecraft:lime_terracotta
setblock 379 233 239 minecraft:light[level=15]
setblock 379 233 247 minecraft:light[level=15]
setblock 379 233 255 minecraft:light[level=15]
setblock 386 233 245 minecraft:lime_terracotta
fill 386 233 247 386 233 248 minecraft:green_terracotta
setblock 386 233 249 minecraft:lime_terracotta
setblock 386 233 250 minecraft:green_terracotta
fill 386 233 252 387 233 252 minecraft:green_terracotta
setblock 387 233 231 minecraft:light[level=15]
setblock 387 233 239 minecraft:light[level=15]
setblock 387 233 242 minecraft:lime_terracotta
setblock 387 233 254 minecraft:lime_terracotta
setblock 387 233 255 minecraft:green_terracotta
setblock 387 233 263 minecraft:light[level=15]
fill 388 233 240 388 234 240 minecraft:green_terracotta
fill 388 233 242 389 233 242 minecraft:green_terracotta
setblock 388 233 252 minecraft:red_terracotta
setblock 389 233 238 minecraft:brown_terracotta
setblock 389 233 239 minecraft:green_terracotta
setblock 389 233 244 minecraft:red_terracotta
setblock 390 233 237 minecraft:brown_terracotta
setblock 390 233 243 minecraft:red_terracotta
fill 390 233 247 390 233 248 minecraft:white_terracotta
fill 390 233 250 390 233 251 minecraft:white_terracotta
setblock 391 233 236 minecraft:brown_terracotta
setblock 391 233 237 minecraft:green_terracotta
setblock 391 233 244 minecraft:white_terracotta
setblock 391 233 252 minecraft:white_terracotta
setblock 391 233 254 minecraft:white_terracotta
fill 392 233 235 393 233 235 minecraft:brown_terracotta
setblock 392 233 242 minecraft:white_terracotta
setblock 392 233 256 minecraft:white_terracotta
setblock 392 233 261 minecraft:green_terracotta
setblock 393 233 236 minecraft:green_terracotta
fill 393 233 239 394 233 239 minecraft:green_terracotta
setblock 393 233 240 minecraft:red_terracotta
fill 394 233 234 400 233 234 minecraft:brown_terracotta
fill 394 233 238 397 234 238 minecraft:green_terracotta
setblock 394 233 240 minecraft:white_terracotta
setblock 394 233 258 minecraft:white_terracotta
setblock 394 233 262 minecraft:green_terracotta
setblock 395 233 231 minecraft:light[level=15]
fill 395 233 239 399 233 239 minecraft:white_terracotta
setblock 395 233 247 minecraft:light[level=15]
setblock 395 233 255 minecraft:light[level=15]
fill 395 233 259 399 233 259 minecraft:white_terracotta
setblock 395 233 262 minecraft:lime_terracotta
setblock 395 233 263 minecraft:light[level=15]
setblock 398 233 260 minecraft:red_terracotta
setblock 399 233 262 minecraft:lime_terracotta
fill 399 233 270 399 308 270 minecraft:lime_terracotta
setblock 400 233 240 minecraft:white_terracotta
setblock 400 233 258 minecraft:white_terracotta
fill 401 233 235 402 233 235 minecraft:brown_terracotta
fill 401 233 240 401 234 240 minecraft:green_terracotta
setblock 401 233 261 minecraft:green_terracotta
fill 402 233 241 402 234 241 minecraft:green_terracotta
setblock 402 233 242 minecraft:white_terracotta
setblock 402 233 244 minecraft:red_terracotta
fill 402 233 252 403 233 252 minecraft:white_terracotta
setblock 402 233 256 minecraft:white_terracotta
setblock 402 233 261 minecraft:lime_terracotta
setblock 403 233 236 minecraft:brown_terracotta
setblock 403 233 244 minecraft:white_terracotta
fill 403 233 250 404 233 250 minecraft:white_terracotta
setblock 403 233 251 minecraft:bone_block
fill 403 233 253 403 233 254 minecraft:white_terracotta
setblock 403 233 263 minecraft:light[level=15]
setblock 404 233 237 minecraft:brown_terracotta
fill 404 233 244 405 235 244 minecraft:green_terracotta
fill 404 233 247 404 233 248 minecraft:white_terracotta
setblock 404 233 251 minecraft:white_terracotta
fill 404 233 253 404 233 255 minecraft:green_terracotta
setblock 404 233 259 minecraft:lime_terracotta
setblock 405 233 238 minecraft:brown_terracotta
setblock 405 233 239 minecraft:green_terracotta
fill 405 233 250 405 234 250 minecraft:green_terracotta
fill 405 233 251 405 233 254 minecraft:bone_block
fill 405 233 255 407 233 255 minecraft:green_terracotta
setblock 406 233 240 minecraft:green_terracotta
fill 406 233 249 406 236 249 minecraft:green_terracotta
fill 406 233 251 406 233 252 minecraft:bone_block
fill 406 233 253 407 233 253 minecraft:green_terracotta
setblock 406 233 254 minecraft:bone_block
setblock 406 233 257 minecraft:lime_terracotta
setblock 407 233 241 minecraft:green_terracotta
setblock 407 233 242 minecraft:lime_terracotta
fill 407 233 252 408 233 252 minecraft:green_terracotta
setblock 407 233 254 minecraft:lime_terracotta
setblock 408 233 244 minecraft:green_terracotta
setblock 408 233 246 minecraft:green_terracotta
setblock 408 233 247 minecraft:lime_terracotta
setblock 408 233 250 minecraft:green_terracotta
setblock 408 233 251 minecraft:lime_terracotta
setblock 411 233 239 minecraft:light[level=15]
setblock 411 233 247 minecraft:light[level=15]
setblock 411 233 255 minecraft:light[level=15]
setblock 411 233 263 minecraft:light[level=15]
fill 376 234 229 376 236 229 minecraft:lime_terracotta
fill 376 234 249 376 308 249 minecraft:lime_terracotta
fill 385 234 242 386 237 242 minecraft:orange_concrete
fill 386 234 241 386 237 241 minecraft:orange_concrete
fill 386 234 243 386 237 243 minecraft:orange_concrete
setblock 386 234 248 minecraft:lime_terracotta
fill 387 234 241 387 237 243 minecraft:black_concrete
setblock 387 234 244 minecraft:green_terracotta
setblock 387 234 245 minecraft:lime_terracotta
setblock 387 234 249 minecraft:lime_terracotta
setblock 387 234 252 minecraft:green_terracotta
setblock 387 234 253 minecraft:lime_terracotta
fill 388 234 242 388 237 242 minecraft:orange_concrete
fill 388 234 246 388 234 253 minecraft:pink_terracotta
setblock 388 234 254 minecraft:lime_terracotta
setblock 389 234 239 minecraft:brown_terracotta
setblock 389 234 242 minecraft:green_terracotta
fill 389 234 244 389 234 245 minecraft:pink_terracotta
fill 389 234 254 389 234 255 minecraft:pink_terracotta
setblock 390 234 238 minecraft:brown_terracotta
setblock 390 234 239 minecraft:green_terracotta
fill 390 234 242 390 234 243 minecraft:pink_terracotta
fill 390 234 256 390 234 257 minecraft:pink_terracotta
setblock 391 234 237 minecraft:brown_terracotta
fill 391 234 240 391 235 240 minecraft:green_terracotta
setblock 391 234 241 minecraft:pink_terracotta
setblock 391 234 258 minecraft:pink_terracotta
fill 392 234 236 393 234 236 minecraft:brown_terracotta
fill 392 234 240 393 234 240 minecraft:pink_terracotta
setblock 392 234 259 minecraft:pink_terracotta
setblock 392 234 260 minecraft:green_terracotta
setblock 393 234 239 minecraft:green_terracotta
fill 393 234 260 399 234 260 minecraft:pink_terracotta
fill 394 234 235 400 234 235 minecraft:brown_terracotta
fill 394 234 239 398 234 239 minecraft:pink_terracotta
setblock 395 234 236 minecraft:green_terracotta
setblock 395 234 261 minecraft:lime_terracotta
setblock 398 234 261 minecraft:green_terracotta
setblock 399 234 236 minecraft:green_terracotta
setblock 399 234 239 minecraft:green_terracotta
fill 399 234 240 400 234 240 minecraft:pink_terracotta
setblock 399 234 261 minecraft:lime_terracotta
setblock 400 234 259 minecraft:pink_terracotta
fill 401 234 236 402 234 236 minecraft:brown_terracotta
setblock 401 234 241 minecraft:pink_terracotta
setblock 401 234 258 minecraft:pink_terracotta
fill 401 234 259 401 234 260 minecraft:green_terracotta
fill 402 234 242 402 234 243 minecraft:pink_terracotta
fill 402 234 256 402 234 257 minecraft:pink_terracotta
setblock 402 234 258 minecraft:green_terracotta
setblock 402 234 260 minecraft:lime_terracotta
setblock 403 234 237 minecraft:brown_terracotta
setblock 403 234 238 minecraft:green_terracotta
fill 403 234 244 403 234 245 minecraft:pink_terracotta
fill 403 234 254 403 234 255 minecraft:pink_terracotta
setblock 404 234 238 minecraft:brown_terracotta
fill 404 234 246 404 234 253 minecraft:pink_terracotta
fill 404 234 254 406 234 255 minecraft:green_terracotta
setblock 404 234 258 minecraft:lime_terracotta
setblock 405 234 239 minecraft:brown_terracotta
setblock 405 234 242 minecraft:green_terracotta
setblock 405 234 249 minecraft:green_terracotta
fill 405 234 251 406 234 253 minecraft:green_terracotta
setblock 406 234 240 minecraft:lime_terracotta
fill 406 234 242 407 237 242 minecraft:orange_concrete
fill 406 234 250 407 235 250 minecraft:green_terracotta
setblock 406 234 256 minecraft:lime_terracotta
fill 407 234 241 407 237 241 minecraft:orange_concrete
fill 407 234 243 407 237 243 minecraft:orange_concrete
setblock 407 234 245 minecraft:lime_terracotta
setblock 407 234 249 minecraft:lime_terracotta
fill 407 234 251 407 234 252 minecraft:green_terracotta
setblock 407 234 253 minecraft:lime_terracotta
fill 408 234 241 408 237 243 minecraft:black_concrete
setblock 408 234 248 minecraft:green_terracotta
fill 409 234 242 409 237 242 minecraft:orange_concrete
setblock 384 235 228 minecraft:moss_block
fill 385 235 241 385 236 241 minecraft:orange_concrete
fill 385 235 243 385 236 243 minecraft:orange_concrete
fill 385 235 261 385 240 261 minecraft:jungle_leaves[persistent=true]
fill 386 235 240 387 236 240 minecraft:orange_concrete
fill 386 235 244 387 236 244 minecraft:orange_concrete
setblock 387 235 247 minecraft:green_terracotta
setblock 387 235 248 minecraft:lime_terracotta
setblock 387 235 249 minecraft:green_terracotta
fill 388 235 241 388 236 241 minecraft:orange_concrete
fill 388 235 243 388 236 243 minecraft:orange_concrete
setblock 388 235 244 minecraft:green_terracotta
setblock 388 235 245 minecraft:lime_terracotta
fill 388 235 246 388 235 253 minecraft:red_terracotta
setblock 388 235 254 minecraft:green_terracotta
setblock 389 235 241 minecraft:green_terracotta
setblock 389 235 242 minecraft:lime_terracotta
fill 389 235 244 389 236 245 minecraft:red_terracotta
fill 389 235 254 389 235 255 minecraft:red_terracotta
fill 390 235 239 391 235 239 minecraft:brown_terracotta
fill 390 235 242 390 235 243 minecraft:red_terracotta
fill 390 235 256 390 235 257 minecraft:red_terracotta
fill 391 235 238 392 235 238 minecraft:brown_terracotta
fill 391 235 241 391 236 241 minecraft:red_terracotta
fill 391 235 245 391 238 245 minecraft:bone_block
fill 391 235 247 392 235 247 minecraft:bone_block
fill 391 235 249 392 235 249 minecraft:bone_block
fill 391 235 251 391 237 251 minecraft:bone_block
fill 391 235 253 391 238 253 minecraft:bone_block
setblock 391 235 258 minecraft:red_terracotta
fill 392 235 237 394 235 237 minecraft:brown_terracotta
setblock 392 235 240 minecraft:red_terracotta
fill 392 235 244 392 236 244 minecraft:bone_block
setblock 392 235 246 minecraft:bone_block
fill 392 235 254 392 236 254 minecraft:bone_block
setblock 392 235 259 minecraft:red_terracotta
fill 393 235 238 394 235 238 minecraft:green_terracotta
fill 393 235 239 394 235 239 minecraft:red_terracotta
fill 393 235 242 393 235 243 minecraft:bone_block
fill 393 235 255 393 235 256 minecraft:bone_block
fill 394 235 236 400 235 236 minecraft:brown_terracotta
fill 394 235 241 394 235 242 minecraft:bone_block
fill 394 235 256 394 235 257 minecraft:bone_block
setblock 394 235 260 minecraft:red_terracotta
fill 394 235 262 394 236 263 minecraft:black_concrete
fill 395 235 238 398 236 238 minecraft:red_terracotta
fill 395 235 240 395 235 241 minecraft:bone_block
fill 395 235 257 395 235 258 minecraft:bone_block
fill 396 235 240 396 236 240 minecraft:bone_block
fill 396 235 258 396 236 258 minecraft:bone_block
fill 398 235 237 399 235 237 minecraft:green_terracotta
fill 398 235 240 399 236 240 minecraft:bone_block
fill 398 235 258 399 236 258 minecraft:bone_block
fill 398 235 260 399 235 260 minecraft:red_terracotta
setblock 399 235 238 minecraft:green_terracotta
fill 399 235 239 400 235 239 minecraft:red_terracotta
fill 399 235 241 400 235 241 minecraft:bone_block
fill 399 235 257 400 235 257 minecraft:bone_block
fill 400 235 237 402 235 237 minecraft:brown_terracotta
fill 400 235 242 401 235 242 minecraft:bone_block
fill 400 235 256 401 235 256 minecraft:bone_block
fill 400 235 259 401 235 259 minecraft:red_terracotta
setblock 400 235 260 minecraft:green_terracotta
fill 400 235 262 400 236 263 minecraft:black_concrete
setblock 401 235 240 minecraft:red_terracotta
setblock 401 235 243 minecraft:bone_block
setblock 401 235 255 minecraft:bone_block
fill 402 235 238 403 235 238 minecraft:brown_terracotta
fill 402 235 241 402 235 242 minecraft:red_terracotta
fill 402 235 244 402 236 244 minecraft:bone_block
fill 402 235 246 402 235 247 minecraft:bone_block
fill 402 235 249 403 235 249 minecraft:bone_block
fill 402 235 251 402 235 252 minecraft:bone_block
fill 402 235 254 402 236 254 minecraft:bone_block
fill 402 235 257 402 235 258 minecraft:red_terracotta
setblock 402 235 259 minecraft:lime_terracotta
fill 403 235 239 404 235 239 minecraft:brown_terracotta
setblock 403 235 242 minecraft:green_terracotta
fill 403 235 243 403 235 244 minecraft:red_terracotta
fill 403 235 245 403 238 245 minecraft:bone_block
fill 403 235 247 403 237 247 minecraft:bone_block
fill 403 235 251 403 237 251 minecraft:bone_block
fill 403 235 253 403 238 253 minecraft:bone_block
fill 403 235 255 403 235 256 minecraft:red_terracotta
setblock 404 235 240 minecraft:green_terracotta
fill 404 235 245 404 235 248 minecraft:red_terracotta
fill 404 235 251 404 235 254 minecraft:red_terracotta
fill 404 235 255 404 235 256 minecraft:green_terracotta
setblock 404 235 257 minecraft:lime_terracotta
setblock 405 235 242 minecraft:lime_terracotta
fill 405 235 245 406 235 245 minecraft:green_terracotta
fill 405 235 249 405 236 250 minecraft:red_terracotta
fill 405 235 251 405 235 253 minecraft:green_terracotta
setblock 405 235 254 minecraft:lime_terracotta
setblock 405 235 255 minecraft:green_terracotta
fill 406 235 241 406 236 241 minecraft:orange_concrete
fill 406 235 243 406 236 243 minecraft:orange_concrete
setblock 406 235 251 minecraft:lime_terracotta
fill 406 235 252 406 235 254 minecraft:green_terracotta
fill 407 235 240 408 236 240 minecraft:orange_concrete
fill 407 235 244 408 236 244 minecraft:orange_concrete
setblock 407 235 248 minecraft:lime_terracotta
setblock 407 235 249 minecraft:green_terracotta
fill 409 235 241 409 236 241 minecraft:orange_concrete
fill 409 235 243 409 236 243 minecraft:orange_concrete
fill 414 235 259 414 239 260 minecraft:oak_leaves[persistent=true]
fill 415 235 259 415 240 259 minecraft:oak_leaves[persistent=true]
fill 376 236 228 377 239 228 minecraft:jungle_leaves[persistent=true]
fill 376 236 266 376 237 266 minecraft:jungle_log
fill 377 236 229 378 236 229 minecraft:jungle_log
fill 378 236 228 378 237 228 minecraft:jungle_log
fill 379 236 228 379 287 228 minecraft:lime_terracotta
fill 379 236 270 379 298 270 minecraft:lime_terracotta
fill 380 236 228 380 237 228 minecraft:jungle_log
fill 380 236 270 380 237 270 minecraft:jungle_log
fill 381 236 270 381 308 270 minecraft:lime_terracotta
fill 382 236 263 383 236 263 minecraft:jungle_log
fill 382 236 267 382 279 267 minecraft:jungle_log
fill 383 236 260 384 238 262 minecraft:jungle_leaves[persistent=true]
fill 384 236 228 384 271 228 minecraft:lime_terracotta
fill 384 236 259 385 239 259 minecraft:jungle_leaves[persistent=true]
fill 385 236 260 386 239 260 minecraft:jungle_leaves[persistent=true]
fill 385 236 262 386 239 262 minecraft:jungle_leaves[persistent=true]
fill 386 236 261 386 239 261 minecraft:jungle_leaves[persistent=true]
fill 388 236 246 388 236 250 minecraft:red_terracotta
setblock 389 236 243 minecraft:red_terracotta
setblock 390 236 242 minecraft:red_terracotta
fill 390 236 247 391 237 247 minecraft:bone_block
fill 390 236 249 391 237 249 minecraft:bone_block
fill 390 236 251 390 238 251 minecraft:bone_block
setblock 391 236 240 minecraft:red_terracotta
fill 391 236 243 392 237 243 minecraft:bone_block
fill 391 236 255 392 237 255 minecraft:bone_block
fill 392 236 239 393 236 239 minecraft:red_terracotta
fill 392 236 242 393 236 242 minecraft:bone_block
fill 392 236 256 393 236 256 minecraft:bone_block
setblock 393 236 238 minecraft:brown_terracotta
fill 393 236 240 394 236 241 minecraft:bone_block
fill 393 236 257 394 236 258 minecraft:bone_block
setblock 394 236 238 minecraft:red_terracotta
fill 395 236 237 399 236 237 minecraft:brown_terracotta
fill 395 236 239 395 237 240 minecraft:bone_block
fill 395 236 258 395 237 259 minecraft:bone_block
fill 396 236 239 399 237 239 minecraft:bone_block
fill 396 236 259 399 237 259 minecraft:bone_block
setblock 399 236 238 minecraft:red_terracotta
fill 400 236 238 401 236 238 minecraft:brown_terracotta
fill 400 236 239 401 236 239 minecraft:red_terracotta
fill 400 236 240 401 236 241 minecraft:bone_block
fill 400 236 257 401 236 258 minecraft:bone_block
fill 401 236 242 402 236 242 minecraft:bone_block
fill 401 236 256 402 236 256 minecraft:bone_block
setblock 402 236 239 minecraft:brown_terracotta
setblock 402 236 240 minecraft:red_terracotta
fill 402 236 243 403 237 243 minecraft:bone_block
fill 402 236 255 403 237 255 minecraft:bone_block
fill 403 236 241 403 236 242 minecraft:red_terracotta
fill 403 236 249 404 237 249 minecraft:bone_block
fill 404 236 243 404 236 244 minecraft:red_terracotta
fill 404 236 247 404 238 247 minecraft:bone_block
fill 404 236 251 404 238 251 minecraft:bone_block
fill 404 236 254 404 236 255 minecraft:red_terracotta
setblock 405 236 244 minecraft:green_terracotta
fill 405 236 245 405 236 248 minecraft:red_terracotta
fill 405 236 251 405 236 253 minecraft:red_terracotta
setblock 406 236 246 minecraft:lime_terracotta
setblock 406 236 247 minecraft:green_terracotta
setblock 406 236 250 minecraft:lime_terracotta
setblock 406 236 270 minecraft:moss_block
setblock 410 236 270 minecraft:green_concrete
fill 411 236 270 411 268 270 minecraft:lime_terracotta
fill 412 236 228 414 237 228 minecraft:jungle_log
fill 413 236 258 413 239 260 minecraft:oak_leaves[persistent=true]
fill 414 236 258 416 239 258 minecraft:oak_leaves[persistent=true]
fill 414 236 261 415 237 261 minecraft:oak_leaves[persistent=true]
fill 414 236 262 415 237 262 minecraft:jungle_log
fill 415 236 260 416 239 260 minecraft:oak_leaves[persistent=true]
fill 416 236 259 416 239 259 minecraft:oak_leaves[persistent=true]
fill 417 236 230 418 236 230 minecraft:jungle_log
fill 418 236 231 418 237 231 minecraft:jungle_log
fill 418 236 232 418 308 232 minecraft:lime_terracotta
fill 418 236 265 418 237 267 minecraft:jungle_log
fill 376 237 229 377 238 229 minecraft:jungle_leaves[persistent=true]
setblock 378 237 229 minecraft:jungle_log
setblock 379 237 238 minecraft:light[level=12]
setblock 379 237 245 minecraft:light[level=12]
setblock 379 237 252 minecraft:light[level=12]
setblock 379 237 259 minecraft:light[level=12]
setblock 382 237 263 minecraft:jungle_log
fill 383 237 259 383 238 259 minecraft:jungle_leaves[persistent=true]
fill 383 237 263 385 237 263 minecraft:jungle_leaves[persistent=true]
setblock 386 237 231 minecraft:light[level=12]
setblock 386 237 238 minecraft:light[level=12]
setblock 386 237 245 minecraft:light[level=12]
setblock 386 237 252 minecraft:light[level=12]
fill 386 237 259 386 238 259 minecraft:jungle_leaves[persistent=true]
setblock 386 237 266 minecraft:light[level=12]
fill 387 237 261 387 238 261 minecraft:jungle_leaves[persistent=true]
fill 389 237 246 389 238 252 minecraft:bone_block
fill 390 237 242 390 238 246 minecraft:bone_block
fill 390 237 248 390 238 248 minecraft:bone_block
fill 390 237 250 390 238 250 minecraft:bone_block
fill 390 237 252 390 238 256 minecraft:bone_block
fill 391 237 241 392 238 242 minecraft:bone_block
fill 391 237 244 391 238 244 minecraft:bone_block
fill 391 237 254 391 238 254 minecraft:bone_block
fill 391 237 256 392 238 257 minecraft:bone_block
fill 392 237 240 394 238 240 minecraft:bone_block
fill 392 237 258 394 238 258 minecraft:bone_block
setblock 393 237 231 minecraft:light[level=12]
setblock 393 237 238 minecraft:light[level=12]
fill 393 237 239 394 238 239 minecraft:bone_block
fill 393 237 241 393 238 241 minecraft:bone_block
setblock 393 237 245 minecraft:light[level=12]
fill 393 237 257 393 238 257 minecraft:bone_block
fill 393 237 259 394 238 259 minecraft:bone_block
setblock 393 237 266 minecraft:light[level=12]
fill 394 237 238 400 238 238 minecraft:bone_block
fill 394 237 260 400 238 260 minecraft:bone_block
fill 396 237 237 396 238 237 minecraft:bone_block
fill 396 237 261 396 238 261 minecraft:bone_block
fill 398 237 230 398 251 230 minecraft:jungle_leaves[persistent=true]
fill 398 237 237 398 238 237 minecraft:bone_block
fill 398 237 261 398 238 261 minecraft:bone_block
fill 399 237 240 402 237 240 minecraft:bone_block
fill 399 237 258 402 237 258 minecraft:bone_block
setblock 400 237 231 minecraft:light[level=12]
fill 400 237 239 401 238 239 minecraft:bone_block
setblock 400 237 245 minecraft:light[level=12]
setblock 400 237 252 minecraft:light[level=12]
fill 400 237 259 401 238 259 minecraft:bone_block
setblock 400 237 266 minecraft:light[level=12]
fill 401 237 241 403 238 241 minecraft:bone_block
fill 401 237 257 403 238 257 minecraft:bone_block
fill 402 237 231 402 253 231 minecraft:moss_block
fill 402 237 242 404 238 242 minecraft:bone_block
fill 402 237 256 404 238 256 minecraft:bone_block
fill 403 237 244 404 238 244 minecraft:bone_block
fill 403 237 254 404 238 254 minecraft:bone_block
fill 404 237 243 404 238 243 minecraft:bone_block
fill 404 237 245 404 238 246 minecraft:bone_block
fill 404 237 248 405 238 248 minecraft:bone_block
fill 404 237 250 405 238 250 minecraft:bone_block
fill 404 237 252 404 238 253 minecraft:bone_block
fill 404 237 255 404 238 255 minecraft:bone_block
fill 405 237 246 405 238 247 minecraft:bone_block
fill 405 237 249 405 238 249 minecraft:bone_block
fill 405 237 251 405 238 252 minecraft:bone_block
fill 406 237 270 406 262 270 minecraft:lime_terracotta
setblock 407 237 231 minecraft:light[level=12]
setblock 407 237 238 minecraft:light[level=12]
setblock 407 237 245 minecraft:light[level=12]
setblock 407 237 252 minecraft:light[level=12]
setblock 407 237 259 minecraft:light[level=12]
setblock 407 237 266 minecraft:light[level=12]
fill 410 237 270 410 242 270 minecraft:lime_terracotta
fill 412 237 260 412 238 260 minecraft:oak_leaves[persistent=true]
fill 413 237 257 415 238 257 minecraft:oak_leaves[persistent=true]
setblock 414 237 238 minecraft:light[level=12]
setblock 414 237 245 minecraft:light[level=12]
setblock 414 237 252 minecraft:light[level=12]
fill 416 237 261 416 239 261 minecraft:oak_leaves[persistent=true]
fill 417 237 259 417 237 260 minecraft:oak_leaves[persistent=true]
fill 418 237 230 418 238 230 minecraft:jungle_leaves[persistent=true]
fill 418 237 248 418 295 248 minecraft:lime_terracotta
setblock 418 237 249 minecraft:jungle_leaves[persistent=true]
fill 418 237 250 418 263 257 minecraft:lime_terracotta
fill 376 238 266 376 306 266 minecraft:lime_terracotta
setblock 378 238 228 minecraft:jungle_leaves[persistent=true]
fill 380 238 228 380 265 228 minecraft:lime_terracotta
fill 380 238 270 380 308 270 minecraft:lime_terracotta
fill 384 238 263 385 238 263 minecraft:jungle_leaves[persistent=true]
fill 385 238 243 385 239 244 minecraft:brown_terracotta
fill 386 238 240 386 238 243 minecraft:brown_terracotta
fill 387 238 239 387 238 241 minecraft:brown_terracotta
setblock 387 238 260 minecraft:jungle_leaves[persistent=true]
fill 388 238 239 388 238 240 minecraft:brown_terracotta
fill 388 238 246 388 238 247 minecraft:bone_block
setblock 388 238 249 minecraft:bone_block
fill 388 238 251 388 238 252 minecraft:bone_block
fill 389 238 244 389 238 245 minecraft:bone_block
fill 389 238 253 389 238 254 minecraft:bone_block
setblock 390 238 247 minecraft:bone_block
setblock 390 238 249 minecraft:bone_block
setblock 391 238 240 minecraft:bone_block
setblock 391 238 243 minecraft:bone_block
setblock 391 238 255 minecraft:bone_block
setblock 391 238 258 minecraft:bone_block
fill 392 238 234 392 255 234 minecraft:iron_block
setblock 392 238 239 minecraft:bone_block
setblock 392 238 259 minecraft:bone_block
setblock 393 238 238 minecraft:bone_block
setblock 393 238 260 minecraft:bone_block
fill 394 238 237 395 238 237 minecraft:bone_block
fill 394 238 261 395 238 261 minecraft:bone_block
fill 395 238 239 396 238 239 minecraft:bone_block
fill 395 238 259 396 238 259 minecraft:bone_block
setblock 397 238 237 minecraft:bone_block
setblock 397 238 261 minecraft:bone_block
fill 398 238 239 399 238 239 minecraft:bone_block
fill 398 238 259 399 238 259 minecraft:bone_block
fill 399 238 237 400 238 237 minecraft:bone_block
fill 399 238 261 400 238 261 minecraft:bone_block
fill 400 238 240 403 238 240 minecraft:bone_block
fill 400 238 258 403 238 258 minecraft:bone_block
setblock 401 238 238 minecraft:bone_block
setblock 401 238 260 minecraft:bone_block
setblock 402 238 239 minecraft:bone_block
setblock 402 238 259 minecraft:bone_block
setblock 403 238 243 minecraft:bone_block
setblock 403 238 255 minecraft:bone_block
setblock 404 238 249 minecraft:bone_block
fill 405 238 244 405 238 245 minecraft:bone_block
fill 405 238 253 405 238 254 minecraft:bone_block
fill 406 238 239 407 238 240 minecraft:brown_terracotta
fill 406 238 246 406 238 247 minecraft:bone_block
setblock 406 238 249 minecraft:bone_block
fill 406 238 251 406 238 252 minecraft:bone_block
fill 407 238 241 408 239 241 minecraft:brown_terracotta
setblock 408 238 240 minecraft:brown_terracotta
fill 408 238 242 408 239 243 minecraft:brown_terracotta
fill 409 238 243 409 239 244 minecraft:brown_terracotta
fill 412 238 228 414 246 228 minecraft:lime_terracotta
setblock 414 238 256 minecraft:oak_leaves[persistent=true]
fill 415 238 232 415 279 232 minecraft:jungle_log
fill 415 238 261 415 239 261 minecraft:oak_leaves[persistent=true]
fill 417 238 260 417 238 261 minecraft:oak_leaves[persistent=true]
fill 418 238 231 418 242 231 minecraft:lime_terracotta
fill 418 238 249 418 308 249 minecraft:lime_terracotta
fill 418 238 265 418 248 267 minecraft:lime_terracotta
fill 376 239 229 376 295 229 minecraft:lime_terracotta
fill 376 239 245 376 252 247 minecraft:lime_terracotta
setblock 376 239 248 minecraft:moss_block
setblock 376 239 254 minecraft:moss_block
fill 378 239 228 378 248 228 minecraft:lime_terracotta
setblock 383 239 228 minecraft:jungle_leaves[persistent=true]
fill 383 239 260 384 239 261 minecraft:jungle_leaves[persistent=true]
schedule function dropper:buildpart/56_4 1t
