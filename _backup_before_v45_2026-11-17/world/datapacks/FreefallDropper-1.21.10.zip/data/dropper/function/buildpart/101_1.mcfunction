setblock 238 117 435 minecraft:light[level=12]
setblock 238 117 443 minecraft:light[level=12]
setblock 238 117 451 minecraft:light[level=12]
setblock 244 117 420 minecraft:amethyst_block
setblock 246 117 419 minecraft:light[level=12]
setblock 246 117 427 minecraft:light[level=12]
setblock 246 117 435 minecraft:light[level=12]
setblock 246 117 443 minecraft:light[level=12]
setblock 246 117 451 minecraft:light[level=12]
setblock 249 117 416 minecraft:crying_obsidian
setblock 254 117 419 minecraft:light[level=12]
setblock 254 117 427 minecraft:light[level=12]
setblock 254 117 435 minecraft:light[level=12]
setblock 254 117 443 minecraft:light[level=12]
setblock 254 117 451 minecraft:light[level=12]
fill 255 117 458 255 180 458 minecraft:black_concrete
setblock 262 117 419 minecraft:light[level=12]
setblock 262 117 427 minecraft:light[level=12]
setblock 262 117 435 minecraft:light[level=12]
setblock 262 117 443 minecraft:light[level=12]
setblock 262 117 451 minecraft:light[level=12]
fill 269 117 458 269 121 458 minecraft:black_concrete
setblock 270 117 419 minecraft:light[level=12]
setblock 270 117 427 minecraft:light[level=12]
setblock 270 117 435 minecraft:light[level=12]
setblock 270 117 443 minecraft:light[level=12]
setblock 270 117 451 minecraft:light[level=12]
setblock 270 117 458 minecraft:white_concrete
fill 235 118 424 235 119 424 minecraft:purple_concrete
fill 235 118 440 235 119 440 minecraft:purple_concrete
setblock 235 118 442 minecraft:crying_obsidian
fill 235 118 456 235 119 456 minecraft:purple_concrete
fill 239 118 416 239 119 416 minecraft:purple_concrete
fill 240 118 416 240 128 416 minecraft:black_concrete
fill 249 118 416 249 126 416 minecraft:black_concrete
fill 249 118 458 249 119 458 minecraft:purple_concrete
fill 255 118 416 255 119 416 minecraft:purple_concrete
setblock 256 118 458 minecraft:amethyst_block
setblock 260 118 416 minecraft:crying_obsidian
fill 265 118 458 265 119 458 minecraft:purple_concrete
setblock 266 118 416 minecraft:white_concrete
fill 266 118 455 266 134 455 minecraft:obsidian
fill 270 118 458 270 223 458 minecraft:black_concrete
fill 271 118 416 271 119 416 minecraft:purple_concrete
fill 277 118 426 277 119 426 minecraft:purple_concrete
setblock 277 118 435 minecraft:white_concrete
fill 277 118 442 277 119 442 minecraft:purple_concrete
fill 235 119 442 235 166 442 minecraft:black_concrete
fill 249 119 443 250 120 444 minecraft:obsidian
fill 256 119 458 256 124 458 minecraft:black_concrete
fill 260 119 416 260 197 416 minecraft:black_concrete
fill 266 119 416 266 120 416 minecraft:black_concrete
setblock 273 119 416 minecraft:white_concrete
setblock 277 119 434 minecraft:amethyst_block
fill 277 119 435 277 213 435 minecraft:black_concrete
setblock 235 120 423 minecraft:amethyst_block
fill 235 120 424 235 125 424 minecraft:black_concrete
fill 235 120 440 235 126 440 minecraft:black_concrete
fill 235 120 456 235 126 456 minecraft:black_concrete
fill 239 120 416 239 126 416 minecraft:black_concrete
fill 249 120 458 249 126 458 minecraft:black_concrete
fill 251 120 421 252 121 422 minecraft:obsidian
fill 252 120 420 252 121 420 minecraft:obsidian
fill 255 120 416 255 123 416 minecraft:black_concrete
fill 265 120 458 265 126 458 minecraft:black_concrete
fill 271 120 416 271 126 416 minecraft:black_concrete
fill 273 120 416 273 215 416 minecraft:black_concrete
fill 277 120 426 277 126 426 minecraft:black_concrete
fill 277 120 434 277 255 434 minecraft:black_concrete
fill 277 120 442 277 126 442 minecraft:black_concrete
setblock 277 120 446 minecraft:amethyst_block
setblock 277 120 454 minecraft:amethyst_block
setblock 235 121 421 minecraft:amethyst_block
fill 235 121 423 235 153 423 minecraft:black_concrete
setblock 235 121 439 minecraft:amethyst_block
setblock 240 121 458 minecraft:crying_obsidian
setblock 254 121 416 minecraft:crying_obsidian
setblock 266 121 416 minecraft:white_concrete
fill 269 121 441 271 122 441 minecraft:crying_obsidian
fill 270 121 440 270 122 440 minecraft:crying_obsidian
fill 270 121 442 270 122 442 minecraft:crying_obsidian
setblock 277 121 438 minecraft:white_concrete
fill 277 121 446 277 184 446 minecraft:black_concrete
fill 277 121 450 277 122 450 minecraft:white_concrete
fill 277 121 454 277 153 454 minecraft:black_concrete
fill 235 122 421 235 182 421 minecraft:black_concrete
fill 235 122 439 235 222 439 minecraft:black_concrete
setblock 237 122 458 minecraft:white_concrete
fill 240 122 458 240 134 458 minecraft:black_concrete
fill 252 122 418 252 132 418 minecraft:obsidian
fill 254 122 416 254 143 416 minecraft:black_concrete
fill 266 122 416 266 127 416 minecraft:black_concrete
setblock 269 122 458 minecraft:amethyst_block
fill 277 122 438 277 159 438 minecraft:black_concrete
setblock 235 123 443 minecraft:crying_obsidian
setblock 235 123 450 minecraft:crying_obsidian
fill 237 123 458 237 307 458 minecraft:black_concrete
setblock 244 123 458 minecraft:crying_obsidian
fill 269 123 458 269 183 458 minecraft:black_concrete
fill 277 123 450 277 210 450 minecraft:black_concrete
setblock 277 123 453 minecraft:crying_obsidian
fill 235 124 443 235 178 443 minecraft:black_concrete
fill 235 124 450 235 164 450 minecraft:black_concrete
fill 244 124 458 244 174 458 minecraft:black_concrete
setblock 255 124 416 minecraft:crying_obsidian
fill 259 124 454 259 125 454 minecraft:crying_obsidian
setblock 268 124 458 minecraft:white_concrete
fill 277 124 453 277 152 453 minecraft:black_concrete
setblock 238 125 419 minecraft:light[level=12]
setblock 238 125 427 minecraft:light[level=12]
setblock 238 125 435 minecraft:light[level=12]
setblock 238 125 443 minecraft:light[level=12]
setblock 238 125 451 minecraft:light[level=12]
setblock 246 125 419 minecraft:light[level=12]
setblock 246 125 427 minecraft:light[level=12]
setblock 246 125 435 minecraft:light[level=12]
setblock 246 125 443 minecraft:light[level=12]
setblock 246 125 451 minecraft:light[level=12]
setblock 251 125 416 minecraft:crying_obsidian
setblock 254 125 419 minecraft:light[level=12]
setblock 254 125 427 minecraft:light[level=12]
setblock 254 125 435 minecraft:light[level=12]
setblock 254 125 443 minecraft:light[level=12]
setblock 254 125 451 minecraft:light[level=12]
fill 255 125 416 255 126 416 minecraft:black_concrete
setblock 256 125 458 minecraft:amethyst_block
setblock 262 125 416 minecraft:crying_obsidian
setblock 262 125 419 minecraft:light[level=12]
setblock 262 125 427 minecraft:light[level=12]
setblock 262 125 435 minecraft:light[level=12]
setblock 262 125 443 minecraft:light[level=12]
setblock 262 125 451 minecraft:light[level=12]
fill 268 125 458 268 161 458 minecraft:black_concrete
setblock 270 125 419 minecraft:light[level=12]
setblock 270 125 427 minecraft:light[level=12]
setblock 270 125 435 minecraft:light[level=12]
setblock 270 125 443 minecraft:light[level=12]
setblock 270 125 451 minecraft:light[level=12]
setblock 277 125 419 minecraft:crying_obsidian
setblock 235 126 424 minecraft:crying_obsidian
setblock 235 126 441 minecraft:crying_obsidian
fill 251 126 416 251 150 416 minecraft:black_concrete
fill 256 126 458 256 131 458 minecraft:black_concrete
fill 262 126 416 262 159 416 minecraft:black_concrete
fill 277 126 419 277 127 419 minecraft:black_concrete
setblock 235 127 418 minecraft:white_concrete
fill 235 127 424 235 128 424 minecraft:purple_concrete
setblock 235 127 427 minecraft:amethyst_block
fill 235 127 440 235 128 440 minecraft:purple_concrete
fill 235 127 441 235 140 441 minecraft:black_concrete
fill 235 127 456 235 128 456 minecraft:purple_concrete
fill 239 127 416 239 128 416 minecraft:purple_concrete
setblock 249 127 416 minecraft:white_concrete
fill 249 127 458 249 128 458 minecraft:purple_concrete
fill 252 127 445 252 128 445 minecraft:amethyst_block
fill 255 127 416 255 128 416 minecraft:purple_concrete
fill 265 127 458 265 128 458 minecraft:purple_concrete
fill 271 127 416 271 128 416 minecraft:purple_concrete
fill 277 127 426 277 128 426 minecraft:purple_concrete
fill 277 127 442 277 128 442 minecraft:purple_concrete
fill 235 128 418 235 133 418 minecraft:black_concrete
fill 235 128 427 235 169 427 minecraft:black_concrete
setblock 235 128 435 minecraft:amethyst_block
fill 249 128 416 249 150 416 minecraft:black_concrete
setblock 266 128 416 minecraft:white_concrete
setblock 277 128 419 minecraft:crying_obsidian
fill 235 129 424 235 135 424 minecraft:black_concrete
fill 235 129 435 235 222 435 minecraft:black_concrete
fill 235 129 440 235 135 440 minecraft:black_concrete
fill 235 129 456 235 135 456 minecraft:black_concrete
setblock 235 129 457 minecraft:white_concrete
fill 239 129 416 239 135 416 minecraft:black_concrete
setblock 240 129 416 minecraft:amethyst_block
fill 249 129 458 249 135 458 minecraft:black_concrete
fill 255 129 416 255 135 416 minecraft:black_concrete
fill 265 129 458 265 135 458 minecraft:black_concrete
fill 266 129 416 266 200 416 minecraft:black_concrete
fill 271 129 416 271 135 416 minecraft:black_concrete
fill 277 129 419 277 156 419 minecraft:black_concrete
fill 277 129 426 277 135 426 minecraft:black_concrete
fill 277 129 442 277 135 442 minecraft:black_concrete
setblock 235 130 422 minecraft:white_concrete
fill 235 130 457 235 161 457 minecraft:black_concrete
fill 240 130 416 240 191 416 minecraft:black_concrete
setblock 250 130 416 minecraft:amethyst_block
fill 256 130 428 256 131 428 minecraft:crying_obsidian
fill 260 130 426 260 131 426 minecraft:amethyst_block
fill 235 131 422 235 143 422 minecraft:black_concrete
fill 250 131 416 250 220 416 minecraft:black_concrete
setblock 254 131 458 minecraft:crying_obsidian
setblock 236 132 458 minecraft:white_concrete
setblock 247 132 416 minecraft:crying_obsidian
fill 254 132 458 254 190 458 minecraft:black_concrete
setblock 256 132 458 minecraft:white_concrete
fill 260 132 426 260 139 426 minecraft:black_concrete
setblock 235 133 437 minecraft:white_concrete
fill 236 133 458 236 307 458 minecraft:black_concrete
setblock 238 133 419 minecraft:light[level=12]
setblock 238 133 427 minecraft:light[level=12]
setblock 238 133 435 minecraft:light[level=12]
setblock 238 133 443 minecraft:light[level=12]
setblock 238 133 451 minecraft:light[level=12]
setblock 246 133 419 minecraft:light[level=12]
setblock 246 133 427 minecraft:light[level=12]
setblock 246 133 435 minecraft:light[level=12]
setblock 246 133 443 minecraft:light[level=12]
setblock 246 133 451 minecraft:light[level=12]
fill 247 133 416 247 138 416 minecraft:black_concrete
setblock 254 133 419 minecraft:light[level=12]
setblock 254 133 427 minecraft:light[level=12]
setblock 254 133 435 minecraft:light[level=12]
setblock 254 133 443 minecraft:light[level=12]
setblock 254 133 451 minecraft:light[level=12]
fill 256 133 458 256 200 458 minecraft:black_concrete
fill 259 133 426 259 139 426 minecraft:black_concrete
fill 260 133 427 260 139 427 minecraft:black_concrete
setblock 262 133 419 minecraft:light[level=12]
setblock 262 133 427 minecraft:light[level=12]
setblock 262 133 435 minecraft:light[level=12]
setblock 262 133 443 minecraft:light[level=12]
setblock 262 133 451 minecraft:light[level=12]
setblock 270 133 419 minecraft:light[level=12]
setblock 270 133 427 minecraft:light[level=12]
setblock 270 133 435 minecraft:light[level=12]
setblock 270 133 443 minecraft:light[level=12]
setblock 270 133 451 minecraft:light[level=12]
setblock 277 133 427 minecraft:white_concrete
setblock 277 133 439 minecraft:crying_obsidian
setblock 235 134 418 minecraft:crying_obsidian
fill 235 134 437 235 214 437 minecraft:black_concrete
fill 259 134 425 260 139 425 minecraft:black_concrete
fill 259 134 427 259 139 427 minecraft:black_concrete
fill 261 134 426 261 139 426 minecraft:black_concrete
setblock 265 134 416 minecraft:white_concrete
fill 277 134 427 277 191 427 minecraft:black_concrete
fill 277 134 439 277 232 439 minecraft:black_concrete
setblock 277 134 440 minecraft:amethyst_block
fill 235 135 418 235 307 418 minecraft:black_concrete
fill 240 135 449 240 136 450 minecraft:amethyst_block
setblock 240 135 458 minecraft:amethyst_block
fill 258 135 426 258 139 427 minecraft:black_concrete
fill 260 135 428 260 139 428 minecraft:black_concrete
fill 261 135 425 261 139 425 minecraft:black_concrete
fill 261 135 427 261 139 427 minecraft:black_concrete
fill 265 135 416 265 283 416 minecraft:black_concrete
fill 277 135 440 277 152 440 minecraft:black_concrete
setblock 277 135 457 minecraft:amethyst_block
fill 235 136 424 235 137 424 minecraft:purple_concrete
fill 235 136 440 235 137 440 minecraft:purple_concrete
fill 235 136 456 235 137 456 minecraft:purple_concrete
fill 236 136 427 237 139 429 minecraft:amethyst_block
fill 239 136 416 239 137 416 minecraft:purple_concrete
fill 239 136 451 241 136 457 minecraft:amethyst_block
setblock 240 136 458 minecraft:black_concrete
fill 249 136 458 249 137 458 minecraft:purple_concrete
fill 255 136 416 255 137 416 minecraft:purple_concrete
fill 258 136 425 258 139 425 minecraft:black_concrete
fill 259 136 424 260 139 424 minecraft:black_concrete
fill 259 136 428 259 139 428 minecraft:black_concrete
fill 261 136 428 261 139 428 minecraft:black_concrete
fill 262 136 426 262 139 426 minecraft:black_concrete
fill 265 136 458 265 137 458 minecraft:purple_concrete
fill 271 136 416 271 137 416 minecraft:purple_concrete
setblock 277 136 421 minecraft:amethyst_block
fill 277 136 426 277 137 426 minecraft:purple_concrete
fill 277 136 442 277 137 442 minecraft:purple_concrete
fill 277 136 457 277 143 457 minecraft:black_concrete
fill 236 137 426 237 138 426 minecraft:amethyst_block
fill 236 137 430 237 138 430 minecraft:amethyst_block
fill 238 137 427 238 139 429 minecraft:amethyst_block
fill 238 137 456 242 138 456 minecraft:amethyst_block
fill 239 137 428 239 139 428 minecraft:amethyst_block
fill 239 137 452 241 137 455 minecraft:amethyst_block
fill 239 137 457 241 139 457 minecraft:amethyst_block
setblock 240 137 451 minecraft:amethyst_block
setblock 240 137 458 minecraft:crying_obsidian
fill 257 137 426 257 139 427 minecraft:black_concrete
fill 258 137 424 258 139 424 minecraft:black_concrete
fill 258 137 428 258 139 428 minecraft:black_concrete
fill 261 137 424 261 139 424 minecraft:black_concrete
fill 262 137 425 262 139 425 minecraft:black_concrete
fill 262 137 427 262 139 427 minecraft:black_concrete
fill 277 137 421 277 170 421 minecraft:black_concrete
setblock 277 137 436 minecraft:white_concrete
fill 235 138 424 235 144 424 minecraft:black_concrete
fill 235 138 440 235 139 440 minecraft:black_concrete
fill 235 138 456 235 144 456 minecraft:black_concrete
setblock 239 138 416 minecraft:black_concrete
setblock 239 138 427 minecraft:amethyst_block
setblock 239 138 429 minecraft:amethyst_block
fill 239 138 454 241 138 455 minecraft:amethyst_block
fill 240 138 428 240 139 428 minecraft:amethyst_block
setblock 240 138 453 minecraft:amethyst_block
fill 240 138 458 240 232 458 minecraft:black_concrete
setblock 242 138 458 minecraft:white_concrete
setblock 245 138 458 minecraft:crying_obsidian
fill 249 138 458 249 144 458 minecraft:black_concrete
fill 255 138 416 255 144 416 minecraft:black_concrete
fill 257 138 425 257 139 425 minecraft:black_concrete
fill 257 138 428 257 139 428 minecraft:black_concrete
fill 259 138 423 260 139 423 minecraft:black_concrete
fill 259 138 429 261 139 429 minecraft:black_concrete
fill 262 138 424 262 139 424 minecraft:black_concrete
fill 262 138 428 262 139 428 minecraft:black_concrete
fill 263 138 426 263 139 426 minecraft:black_concrete
fill 265 138 458 265 144 458 minecraft:black_concrete
setblock 269 138 416 minecraft:crying_obsidian
fill 271 138 416 271 144 416 minecraft:black_concrete
fill 277 138 426 277 144 426 minecraft:black_concrete
fill 277 138 436 277 190 436 minecraft:black_concrete
fill 277 138 442 277 144 442 minecraft:black_concrete
setblock 235 139 431 minecraft:crying_obsidian
setblock 235 139 453 minecraft:white_concrete
setblock 235 139 455 minecraft:amethyst_block
setblock 239 139 416 minecraft:amethyst_block
fill 239 139 455 241 139 456 minecraft:amethyst_block
fill 242 139 458 242 174 458 minecraft:black_concrete
fill 245 139 458 245 182 458 minecraft:black_concrete
setblock 247 139 416 minecraft:crying_obsidian
fill 256 139 426 256 139 427 minecraft:black_concrete
setblock 257 139 424 minecraft:black_concrete
setblock 258 139 423 minecraft:black_concrete
setblock 258 139 429 minecraft:black_concrete
setblock 261 139 423 minecraft:black_concrete
setblock 262 139 429 minecraft:black_concrete
setblock 263 139 425 minecraft:black_concrete
setblock 263 139 427 minecraft:black_concrete
fill 269 139 416 269 212 416 minecraft:black_concrete
fill 235 140 431 235 243 431 minecraft:black_concrete
setblock 235 140 440 minecraft:amethyst_block
fill 235 140 453 235 204 453 minecraft:black_concrete
fill 235 140 455 235 147 455 minecraft:black_concrete
fill 239 140 416 239 144 416 minecraft:black_concrete
fill 247 140 416 247 214 416 minecraft:black_concrete
fill 259 140 426 260 140 427 minecraft:amethyst_block
setblock 260 140 425 minecraft:amethyst_block
setblock 268 140 416 minecraft:amethyst_block
setblock 277 140 430 minecraft:amethyst_block
fill 235 141 440 235 144 440 minecraft:black_concrete
setblock 235 141 441 minecraft:amethyst_block
setblock 237 141 416 minecraft:white_concrete
setblock 238 141 419 minecraft:light[level=12]
setblock 238 141 427 minecraft:light[level=12]
setblock 238 141 435 minecraft:light[level=12]
setblock 238 141 443 minecraft:light[level=12]
setblock 238 141 451 minecraft:light[level=12]
setblock 246 141 419 minecraft:light[level=12]
setblock 246 141 427 minecraft:light[level=12]
setblock 246 141 435 minecraft:light[level=12]
setblock 246 141 443 minecraft:light[level=12]
setblock 246 141 451 minecraft:light[level=12]
setblock 254 141 419 minecraft:light[level=12]
setblock 254 141 427 minecraft:light[level=12]
setblock 254 141 435 minecraft:light[level=12]
setblock 254 141 443 minecraft:light[level=12]
setblock 254 141 451 minecraft:light[level=12]
fill 259 141 426 260 142 426 minecraft:amethyst_block
setblock 260 141 427 minecraft:amethyst_block
setblock 262 141 419 minecraft:light[level=12]
setblock 262 141 427 minecraft:light[level=12]
setblock 262 141 435 minecraft:light[level=12]
setblock 262 141 443 minecraft:light[level=12]
setblock 262 141 451 minecraft:light[level=12]
fill 268 141 416 268 260 416 minecraft:black_concrete
setblock 270 141 419 minecraft:light[level=12]
setblock 270 141 427 minecraft:light[level=12]
setblock 270 141 435 minecraft:light[level=12]
setblock 270 141 443 minecraft:light[level=12]
setblock 270 141 451 minecraft:light[level=12]
fill 277 141 430 277 251 430 minecraft:black_concrete
fill 235 142 441 235 197 441 minecraft:black_concrete
fill 237 142 416 237 255 416 minecraft:black_concrete
setblock 277 142 429 minecraft:white_concrete
setblock 235 143 434 minecraft:amethyst_block
setblock 260 143 426 minecraft:amethyst_block
fill 277 143 429 277 307 429 minecraft:black_concrete
setblock 277 143 452 minecraft:crying_obsidian
setblock 235 144 422 minecraft:white_concrete
setblock 235 144 428 minecraft:amethyst_block
fill 235 144 434 235 167 434 minecraft:black_concrete
setblock 235 144 446 minecraft:white_concrete
setblock 254 144 416 minecraft:crying_obsidian
setblock 259 144 416 minecraft:amethyst_block
fill 277 144 452 277 159 452 minecraft:black_concrete
setblock 277 144 455 minecraft:white_concrete
setblock 277 144 457 minecraft:crying_obsidian
fill 235 145 422 235 199 422 minecraft:black_concrete
fill 235 145 424 235 146 424 minecraft:purple_concrete
fill 235 145 428 235 190 428 minecraft:black_concrete
fill 235 145 440 235 146 440 minecraft:purple_concrete
fill 235 145 446 235 153 446 minecraft:black_concrete
setblock 235 145 451 minecraft:amethyst_block
fill 235 145 456 235 146 456 minecraft:purple_concrete
fill 239 145 416 239 146 416 minecraft:purple_concrete
setblock 243 145 458 minecraft:white_concrete
setblock 246 145 458 minecraft:crying_obsidian
fill 249 145 458 249 146 458 minecraft:purple_concrete
fill 254 145 416 254 214 416 minecraft:black_concrete
fill 255 145 416 255 146 416 minecraft:purple_concrete
fill 259 145 416 259 225 416 minecraft:black_concrete
fill 265 145 458 265 146 458 minecraft:purple_concrete
fill 271 145 416 271 146 416 minecraft:purple_concrete
setblock 277 145 423 minecraft:white_concrete
setblock 277 145 425 minecraft:crying_obsidian
fill 277 145 426 277 146 426 minecraft:purple_concrete
fill 277 145 442 277 146 442 minecraft:purple_concrete
fill 277 145 455 277 307 455 minecraft:black_concrete
fill 277 145 457 277 208 457 minecraft:black_concrete
fill 235 146 451 235 171 451 minecraft:black_concrete
fill 243 146 458 243 173 458 minecraft:black_concrete
fill 246 146 458 246 172 458 minecraft:black_concrete
fill 277 146 423 277 212 423 minecraft:black_concrete
fill 277 146 425 277 233 425 minecraft:black_concrete
fill 235 147 424 235 161 424 minecraft:black_concrete
fill 235 147 440 235 161 440 minecraft:black_concrete
fill 235 147 456 235 161 456 minecraft:black_concrete
fill 239 147 416 239 161 416 minecraft:black_concrete
fill 249 147 458 249 161 458 minecraft:black_concrete
fill 255 147 416 255 161 416 minecraft:black_concrete
fill 265 147 458 265 161 458 minecraft:black_concrete
fill 271 147 416 271 161 416 minecraft:black_concrete
fill 277 147 426 277 161 426 minecraft:black_concrete
fill 277 147 442 277 161 442 minecraft:black_concrete
setblock 235 148 455 minecraft:amethyst_block
setblock 244 148 416 minecraft:crying_obsidian
setblock 267 148 416 minecraft:crying_obsidian
fill 235 149 455 235 157 455 minecraft:black_concrete
setblock 238 149 419 minecraft:light[level=12]
setblock 238 149 427 minecraft:light[level=12]
setblock 238 149 435 minecraft:light[level=12]
setblock 238 149 443 minecraft:light[level=12]
setblock 238 149 451 minecraft:light[level=12]
setblock 244 149 416 minecraft:black_concrete
setblock 246 149 419 minecraft:light[level=12]
setblock 246 149 427 minecraft:light[level=12]
setblock 246 149 435 minecraft:light[level=12]
setblock 246 149 443 minecraft:light[level=12]
setblock 246 149 451 minecraft:light[level=12]
setblock 254 149 419 minecraft:light[level=12]
setblock 254 149 427 minecraft:light[level=12]
setblock 254 149 435 minecraft:light[level=12]
setblock 254 149 443 minecraft:light[level=12]
setblock 254 149 451 minecraft:light[level=12]
setblock 262 149 419 minecraft:light[level=12]
setblock 262 149 427 minecraft:light[level=12]
setblock 262 149 435 minecraft:light[level=12]
setblock 262 149 443 minecraft:light[level=12]
setblock 262 149 451 minecraft:light[level=12]
fill 267 149 416 267 307 416 minecraft:black_concrete
setblock 270 149 419 minecraft:light[level=12]
setblock 270 149 427 minecraft:light[level=12]
setblock 270 149 435 minecraft:light[level=12]
setblock 270 149 443 minecraft:light[level=12]
setblock 270 149 451 minecraft:light[level=12]
setblock 244 150 416 minecraft:amethyst_block
setblock 244 151 416 minecraft:black_concrete
setblock 249 151 416 minecraft:amethyst_block
setblock 251 151 416 minecraft:crying_obsidian
setblock 263 151 416 minecraft:crying_obsidian
fill 242 152 438 243 153 438 minecraft:black_concrete
fill 243 152 435 244 153 437 minecraft:black_concrete
fill 243 152 439 244 153 441 minecraft:black_concrete
setblock 244 152 416 minecraft:white_concrete
fill 244 152 433 245 152 434 minecraft:black_concrete
fill 244 152 438 251 152 438 minecraft:purple_concrete
fill 244 152 442 245 152 443 minecraft:black_concrete
fill 245 152 432 248 152 432 minecraft:black_concrete
fill 245 152 435 251 152 437 minecraft:purple_concrete
fill 245 152 439 251 152 441 minecraft:purple_concrete
fill 245 152 444 248 152 444 minecraft:black_concrete
setblock 246 152 433 minecraft:black_concrete
fill 246 152 434 254 152 434 minecraft:purple_concrete
fill 246 152 442 254 152 442 minecraft:purple_concrete
setblock 246 152 443 minecraft:black_concrete
fill 247 152 431 250 152 431 minecraft:black_concrete
fill 247 152 433 255 152 433 minecraft:purple_concrete
fill 247 152 443 255 152 443 minecraft:purple_concrete
fill 247 152 445 250 152 445 minecraft:black_concrete
fill 248 152 430 255 152 430 minecraft:black_concrete
fill 248 152 446 255 152 446 minecraft:black_concrete
fill 249 152 416 249 166 416 minecraft:black_concrete
fill 249 152 432 265 152 432 minecraft:purple_concrete
fill 249 152 444 265 152 444 minecraft:purple_concrete
fill 251 152 416 251 185 416 minecraft:black_concrete
fill 251 152 429 263 152 429 minecraft:black_concrete
fill 251 152 431 263 152 431 minecraft:purple_concrete
fill 251 152 445 263 152 445 minecraft:purple_concrete
fill 251 152 447 263 152 447 minecraft:black_concrete
setblock 252 152 435 minecraft:purple_concrete
setblock 252 152 436 minecraft:magenta_concrete
setblock 252 152 437 minecraft:purple_concrete
fill 252 152 438 254 152 438 minecraft:magenta_concrete
setblock 252 152 439 minecraft:purple_concrete
setblock 252 152 440 minecraft:magenta_concrete
setblock 252 152 441 minecraft:purple_concrete
fill 253 152 435 255 152 435 minecraft:magenta_concrete
setblock 253 152 436 minecraft:purple_concrete
fill 253 152 437 254 152 437 minecraft:magenta_concrete
fill 253 152 439 254 152 439 minecraft:magenta_concrete
setblock 253 152 440 minecraft:purple_concrete
fill 253 152 441 255 152 441 minecraft:magenta_concrete
fill 254 152 436 255 152 436 minecraft:magenta_concrete
fill 254 152 440 255 152 440 minecraft:magenta_concrete
fill 255 152 434 256 152 434 minecraft:magenta_concrete
setblock 255 152 437 minecraft:black_concrete
setblock 255 152 439 minecraft:black_concrete
fill 255 152 442 256 152 442 minecraft:magenta_concrete
fill 256 152 428 258 152 428 minecraft:black_concrete
fill 256 152 430 258 152 430 minecraft:purple_concrete
setblock 256 152 433 minecraft:magenta_concrete
fill 256 152 435 258 152 435 minecraft:purple_concrete
setblock 256 152 436 minecraft:black_concrete
setblock 256 152 440 minecraft:black_concrete
fill 256 152 441 258 152 441 minecraft:purple_concrete
setblock 256 152 443 minecraft:magenta_concrete
fill 256 152 446 258 152 446 minecraft:purple_concrete
fill 256 152 448 258 152 448 minecraft:black_concrete
fill 257 152 433 257 152 434 minecraft:purple_concrete
fill 257 152 442 257 152 443 minecraft:purple_concrete
fill 258 152 433 258 152 434 minecraft:magenta_concrete
setblock 258 152 436 minecraft:black_concrete
setblock 258 152 440 minecraft:black_concrete
fill 258 152 442 258 152 443 minecraft:magenta_concrete
fill 259 152 430 266 152 430 minecraft:black_concrete
fill 259 152 433 267 152 433 minecraft:purple_concrete
fill 259 152 434 259 152 436 minecraft:magenta_concrete
setblock 259 152 437 minecraft:black_concrete
setblock 259 152 439 minecraft:black_concrete
fill 259 152 440 259 152 442 minecraft:magenta_concrete
fill 259 152 443 267 152 443 minecraft:purple_concrete
fill 259 152 446 266 152 446 minecraft:black_concrete
fill 260 152 434 268 152 434 minecraft:purple_concrete
fill 260 152 435 260 152 441 minecraft:magenta_concrete
fill 260 152 442 268 152 442 minecraft:purple_concrete
setblock 261 152 435 minecraft:magenta_concrete
setblock 261 152 436 minecraft:purple_concrete
fill 261 152 437 261 152 439 minecraft:magenta_concrete
setblock 261 152 440 minecraft:purple_concrete
setblock 261 152 441 minecraft:magenta_concrete
fill 262 152 435 269 152 435 minecraft:purple_concrete
setblock 262 152 436 minecraft:magenta_concrete
fill 262 152 437 269 152 437 minecraft:purple_concrete
setblock 262 152 438 minecraft:magenta_concrete
fill 262 152 439 269 152 439 minecraft:purple_concrete
setblock 262 152 440 minecraft:magenta_concrete
fill 262 152 441 269 152 441 minecraft:purple_concrete
fill 263 152 416 263 305 416 minecraft:black_concrete
fill 263 152 436 269 152 436 minecraft:purple_concrete
fill 263 152 438 270 152 438 minecraft:purple_concrete
fill 263 152 440 269 152 440 minecraft:purple_concrete
fill 264 152 431 267 152 431 minecraft:black_concrete
fill 264 152 445 267 152 445 minecraft:black_concrete
fill 266 152 432 269 152 432 minecraft:black_concrete
fill 266 152 444 269 152 444 minecraft:black_concrete
fill 268 152 433 270 152 433 minecraft:black_concrete
fill 268 152 443 270 152 443 minecraft:black_concrete
fill 269 152 434 270 153 434 minecraft:black_concrete
fill 269 152 442 270 153 442 minecraft:black_concrete
fill 270 152 435 271 153 437 minecraft:black_concrete
fill 270 152 439 271 153 441 minecraft:black_concrete
fill 271 152 438 272 153 438 minecraft:black_concrete
fill 236 153 417 241 153 457 minecraft:black_concrete
fill 242 153 417 242 153 437 minecraft:black_concrete
fill 242 153 439 242 153 457 minecraft:black_concrete
fill 243 153 417 244 153 434 minecraft:black_concrete
fill 243 153 442 244 153 457 minecraft:black_concrete
fill 244 153 416 244 171 416 minecraft:black_concrete
fill 244 153 438 253 154 438 minecraft:iron_block
fill 245 153 417 245 153 432 minecraft:black_concrete
fill 245 153 433 269 154 433 minecraft:iron_block
setblock 245 153 434 minecraft:black_concrete
fill 245 153 435 246 153 436 minecraft:purple_concrete
fill 245 153 437 245 154 437 minecraft:iron_block
fill 245 153 439 245 154 439 minecraft:iron_block
fill 245 153 440 246 153 441 minecraft:purple_concrete
setblock 245 153 442 minecraft:black_concrete
fill 245 153 443 269 154 443 minecraft:iron_block
fill 245 153 444 245 153 457 minecraft:black_concrete
fill 246 153 417 248 153 431 minecraft:black_concrete
fill 246 153 432 268 154 432 minecraft:iron_block
fill 246 153 434 268 154 434 minecraft:iron_block
setblock 246 153 437 minecraft:purple_concrete
setblock 246 153 439 minecraft:purple_concrete
fill 246 153 442 268 154 442 minecraft:iron_block
fill 246 153 444 268 154 444 minecraft:iron_block
fill 246 153 445 248 153 457 minecraft:black_concrete
fill 247 153 435 253 154 437 minecraft:iron_block
fill 247 153 439 253 154 441 minecraft:iron_block
fill 249 153 417 253 153 427 minecraft:black_concrete
fill 249 153 428 250 154 429 minecraft:iron_block
setblock 249 153 430 minecraft:black_concrete
fill 249 153 431 265 154 431 minecraft:iron_block
fill 249 153 445 265 154 445 minecraft:iron_block
setblock 249 153 446 minecraft:black_concrete
fill 249 153 447 250 154 448 minecraft:iron_block
fill 249 153 449 253 153 457 minecraft:black_concrete
fill 250 153 430 264 154 430 minecraft:iron_block
fill 250 153 446 264 154 446 minecraft:iron_block
fill 251 153 428 252 153 428 minecraft:black_concrete
fill 251 153 429 265 154 429 minecraft:iron_block
fill 251 153 447 265 154 447 minecraft:iron_block
fill 251 153 448 252 153 448 minecraft:black_concrete
fill 253 153 428 261 154 428 minecraft:iron_block
fill 253 153 448 261 154 448 minecraft:iron_block
fill 254 153 417 276 153 425 minecraft:black_concrete
fill 254 153 426 255 154 427 minecraft:iron_block
fill 254 153 435 254 154 436 minecraft:iron_block
fill 254 153 437 254 155 439 minecraft:waxed_copper_block
fill 254 153 440 254 154 441 minecraft:iron_block
fill 254 153 449 255 154 450 minecraft:iron_block
fill 254 153 451 276 153 457 minecraft:black_concrete
fill 255 153 435 255 154 435 minecraft:iron_block
fill 255 153 436 255 153 437 minecraft:waxed_copper_block
fill 255 153 439 255 153 440 minecraft:waxed_copper_block
fill 255 153 441 255 154 441 minecraft:iron_block
fill 256 153 426 256 153 427 minecraft:black_concrete
fill 256 153 435 256 153 436 minecraft:waxed_copper_block
fill 256 153 440 256 153 441 minecraft:waxed_copper_block
fill 256 153 449 256 153 450 minecraft:black_concrete
fill 257 153 426 258 153 426 minecraft:black_concrete
fill 257 153 427 257 154 427 minecraft:iron_block
fill 257 153 435 258 155 435 minecraft:waxed_copper_block
fill 257 153 441 258 155 441 minecraft:waxed_copper_block
fill 257 153 449 257 154 449 minecraft:iron_block
fill 257 153 450 258 153 450 minecraft:black_concrete
setblock 258 153 427 minecraft:black_concrete
fill 258 153 436 259 153 436 minecraft:waxed_copper_block
fill 258 153 440 259 153 440 minecraft:waxed_copper_block
setblock 258 153 449 minecraft:black_concrete
fill 259 153 426 260 154 427 minecraft:iron_block
fill 259 153 435 267 154 435 minecraft:iron_block
fill 259 153 437 260 153 437 minecraft:waxed_copper_block
fill 259 153 439 260 153 439 minecraft:waxed_copper_block
fill 259 153 441 267 154 441 minecraft:iron_block
fill 259 153 449 260 154 450 minecraft:iron_block
fill 260 153 436 267 154 436 minecraft:iron_block
fill 260 153 438 260 155 438 minecraft:waxed_copper_block
fill 260 153 440 267 154 440 minecraft:iron_block
fill 261 153 426 276 153 427 minecraft:black_concrete
fill 261 153 437 267 154 439 minecraft:iron_block
fill 261 153 449 276 153 450 minecraft:black_concrete
fill 262 153 428 263 153 428 minecraft:black_concrete
fill 262 153 448 263 153 448 minecraft:black_concrete
fill 264 153 428 265 154 428 minecraft:iron_block
fill 264 153 448 265 154 448 minecraft:iron_block
fill 265 153 430 276 153 430 minecraft:black_concrete
fill 265 153 446 276 153 446 minecraft:black_concrete
fill 266 153 428 276 153 429 minecraft:black_concrete
fill 266 153 431 276 153 431 minecraft:black_concrete
fill 266 153 445 276 153 445 minecraft:black_concrete
fill 266 153 447 276 153 448 minecraft:black_concrete
fill 268 153 435 268 153 437 minecraft:purple_concrete
fill 268 153 438 270 154 438 minecraft:iron_block
fill 268 153 439 268 153 441 minecraft:purple_concrete
fill 269 153 432 276 153 432 minecraft:black_concrete
fill 269 153 435 269 153 436 minecraft:purple_concrete
fill 269 153 437 269 154 437 minecraft:iron_block
fill 269 153 439 269 154 439 minecraft:iron_block
fill 269 153 440 269 153 441 minecraft:purple_concrete
fill 269 153 444 276 153 444 minecraft:black_concrete
fill 270 153 433 276 153 433 minecraft:black_concrete
fill 270 153 443 276 153 443 minecraft:black_concrete
fill 271 153 434 276 153 434 minecraft:black_concrete
fill 271 153 442 276 153 442 minecraft:black_concrete
fill 272 153 435 276 153 437 minecraft:black_concrete
fill 272 153 439 276 153 441 minecraft:black_concrete
fill 273 153 438 276 153 438 minecraft:black_concrete
setblock 277 153 440 minecraft:white_concrete
setblock 277 153 453 minecraft:white_concrete
setblock 235 154 423 minecraft:white_concrete
setblock 235 154 446 minecraft:white_concrete
setblock 235 154 452 minecraft:white_concrete
setblock 235 154 454 minecraft:white_concrete
setblock 255 154 436 minecraft:waxed_copper_block
setblock 255 154 440 minecraft:waxed_copper_block
fill 256 154 435 256 155 435 minecraft:waxed_copper_block
fill 256 154 441 256 155 441 minecraft:waxed_copper_block
setblock 257 154 458 minecraft:amethyst_block
setblock 259 154 436 minecraft:waxed_copper_block
setblock 259 154 440 minecraft:waxed_copper_block
fill 260 154 437 260 155 437 minecraft:waxed_copper_block
fill 260 154 439 260 155 439 minecraft:waxed_copper_block
fill 277 154 440 277 169 440 minecraft:black_concrete
setblock 277 154 453 minecraft:crying_obsidian
setblock 277 154 454 minecraft:amethyst_block
fill 235 155 423 235 246 423 minecraft:black_concrete
fill 235 155 446 235 177 446 minecraft:black_concrete
fill 235 155 452 235 176 452 minecraft:black_concrete
fill 235 155 454 235 178 454 minecraft:black_concrete
fill 250 155 436 250 155 440 minecraft:waxed_oxidized_copper
fill 251 155 434 251 155 435 minecraft:waxed_oxidized_copper
fill 251 155 441 251 155 442 minecraft:waxed_oxidized_copper
setblock 252 155 433 minecraft:waxed_oxidized_copper
setblock 252 155 443 minecraft:waxed_oxidized_copper
fill 253 155 432 254 155 432 minecraft:waxed_oxidized_copper
fill 253 155 444 254 155 444 minecraft:waxed_oxidized_copper
fill 255 155 431 259 155 431 minecraft:waxed_oxidized_copper
fill 255 155 445 259 155 445 minecraft:waxed_oxidized_copper
fill 257 155 458 257 173 458 minecraft:black_concrete
fill 260 155 432 261 155 432 minecraft:waxed_oxidized_copper
fill 260 155 444 261 155 444 minecraft:waxed_oxidized_copper
setblock 262 155 433 minecraft:waxed_oxidized_copper
setblock 262 155 443 minecraft:waxed_oxidized_copper
fill 263 155 434 263 155 435 minecraft:waxed_oxidized_copper
fill 263 155 441 263 155 442 minecraft:waxed_oxidized_copper
fill 264 155 436 264 155 440 minecraft:waxed_oxidized_copper
fill 277 155 453 277 200 453 minecraft:black_concrete
setblock 277 155 454 minecraft:white_concrete
setblock 261 156 458 minecraft:crying_obsidian
fill 277 156 454 277 179 454 minecraft:black_concrete
setblock 238 157 419 minecraft:light[level=12]
setblock 238 157 427 minecraft:light[level=12]
setblock 238 157 435 minecraft:light[level=12]
setblock 238 157 443 minecraft:light[level=12]
setblock 238 157 451 minecraft:light[level=12]
setblock 246 157 419 minecraft:light[level=12]
setblock 246 157 427 minecraft:light[level=12]
setblock 246 157 435 minecraft:light[level=12]
setblock 246 157 443 minecraft:light[level=12]
setblock 246 157 451 minecraft:light[level=12]
setblock 254 157 419 minecraft:light[level=12]
setblock 254 157 427 minecraft:light[level=12]
setblock 254 157 435 minecraft:light[level=12]
setblock 254 157 443 minecraft:light[level=12]
setblock 254 157 451 minecraft:light[level=12]
fill 261 157 458 261 278 458 minecraft:black_concrete
setblock 262 157 419 minecraft:light[level=12]
setblock 262 157 427 minecraft:light[level=12]
setblock 262 157 435 minecraft:light[level=12]
setblock 262 157 443 minecraft:light[level=12]
setblock 262 157 451 minecraft:light[level=12]
setblock 264 157 458 minecraft:amethyst_block
setblock 270 157 419 minecraft:light[level=12]
setblock 270 157 427 minecraft:light[level=12]
setblock 270 157 435 minecraft:light[level=12]
setblock 270 157 443 minecraft:light[level=12]
setblock 270 157 451 minecraft:light[level=12]
setblock 277 157 419 minecraft:crying_obsidian
setblock 277 157 420 minecraft:amethyst_block
setblock 235 158 455 minecraft:white_concrete
setblock 264 158 458 minecraft:black_concrete
fill 277 158 419 277 190 420 minecraft:black_concrete
fill 235 159 455 235 169 455 minecraft:black_concrete
fill 261 159 435 262 159 441 minecraft:waxed_copper_block
fill 262 159 434 270 160 434 minecraft:waxed_copper_block
fill 262 159 442 270 160 442 minecraft:waxed_copper_block
fill 263 159 433 269 160 433 minecraft:waxed_copper_block
fill 263 159 435 263 160 437 minecraft:waxed_copper_block
fill 263 159 439 263 160 441 minecraft:waxed_copper_block
fill 263 159 443 269 160 443 minecraft:waxed_copper_block
fill 264 159 435 265 160 435 minecraft:waxed_copper_block
fill 264 159 441 265 160 441 minecraft:waxed_copper_block
setblock 264 159 458 minecraft:white_concrete
fill 266 159 432 266 160 432 minecraft:waxed_copper_block
fill 266 159 444 266 160 444 minecraft:waxed_copper_block
fill 267 159 435 271 160 435 minecraft:waxed_copper_block
fill 267 159 441 271 160 441 minecraft:waxed_copper_block
fill 269 159 436 271 160 437 minecraft:waxed_copper_block
fill 269 159 439 271 160 440 minecraft:waxed_copper_block
fill 270 159 438 272 160 438 minecraft:waxed_copper_block
setblock 274 159 458 minecraft:white_concrete
setblock 253 160 416 minecraft:white_concrete
fill 261 160 435 262 160 436 minecraft:waxed_copper_block
fill 261 160 440 262 160 441 minecraft:waxed_copper_block
setblock 262 160 416 minecraft:crying_obsidian
fill 262 160 437 262 160 439 minecraft:waxed_copper_block
fill 264 160 458 264 181 458 minecraft:black_concrete
fill 274 160 458 274 210 458 minecraft:black_concrete
setblock 277 160 438 minecraft:amethyst_block
setblock 277 160 452 minecraft:white_concrete
setblock 235 161 420 minecraft:amethyst_block
setblock 251 161 458 minecraft:amethyst_block
fill 253 161 416 253 306 416 minecraft:black_concrete
fill 262 161 416 262 307 416 minecraft:black_concrete
fill 277 161 438 277 174 438 minecraft:black_concrete
setblock 277 161 452 minecraft:amethyst_block
fill 235 162 420 235 220 420 minecraft:black_concrete
fill 235 162 424 235 164 424 minecraft:purple_concrete
fill 235 162 440 235 164 440 minecraft:purple_concrete
fill 235 162 456 235 164 456 minecraft:purple_concrete
setblock 235 162 457 minecraft:white_concrete
fill 239 162 416 239 164 416 minecraft:purple_concrete
setblock 239 162 458 minecraft:white_concrete
fill 249 162 458 249 164 458 minecraft:purple_concrete
fill 251 162 458 251 278 458 minecraft:black_concrete
fill 255 162 416 255 164 416 minecraft:purple_concrete
fill 265 162 458 265 164 458 minecraft:purple_concrete
setblock 268 162 458 minecraft:amethyst_block
fill 271 162 416 271 164 416 minecraft:purple_concrete
fill 277 162 426 277 164 426 minecraft:purple_concrete
fill 277 162 442 277 164 442 minecraft:purple_concrete
fill 277 162 452 277 194 452 minecraft:black_concrete
setblock 235 163 457 minecraft:crying_obsidian
fill 239 163 458 239 201 458 minecraft:black_concrete
setblock 248 163 458 minecraft:white_concrete
setblock 256 163 416 minecraft:crying_obsidian
fill 268 163 458 268 187 458 minecraft:black_concrete
fill 235 164 457 235 169 457 minecraft:black_concrete
fill 245 164 427 246 165 428 minecraft:obsidian
setblock 248 164 458 minecraft:black_concrete
fill 256 164 416 256 206 416 minecraft:black_concrete
fill 235 165 424 235 170 424 minecraft:black_concrete
fill 235 165 440 235 170 440 minecraft:black_concrete
setblock 235 165 450 minecraft:amethyst_block
fill 235 165 456 235 170 456 minecraft:black_concrete
setblock 238 165 419 minecraft:light[level=12]
setblock 238 165 427 minecraft:light[level=12]
setblock 238 165 435 minecraft:light[level=12]
setblock 238 165 443 minecraft:light[level=12]
setblock 238 165 451 minecraft:light[level=12]
fill 239 165 416 239 170 416 minecraft:black_concrete
setblock 246 165 419 minecraft:light[level=12]
setblock 246 165 435 minecraft:light[level=12]
setblock 246 165 443 minecraft:light[level=12]
setblock 246 165 451 minecraft:light[level=12]
setblock 248 165 458 minecraft:white_concrete
fill 249 165 458 249 170 458 minecraft:black_concrete
fill 251 165 445 252 166 446 minecraft:amethyst_block
setblock 254 165 419 minecraft:light[level=12]
setblock 254 165 427 minecraft:light[level=12]
setblock 254 165 435 minecraft:light[level=12]
setblock 254 165 443 minecraft:light[level=12]
setblock 254 165 451 minecraft:light[level=12]
fill 255 165 416 255 170 416 minecraft:black_concrete
setblock 262 165 419 minecraft:light[level=12]
setblock 262 165 427 minecraft:light[level=12]
setblock 262 165 435 minecraft:light[level=12]
setblock 262 165 443 minecraft:light[level=12]
setblock 262 165 451 minecraft:light[level=12]
fill 265 165 458 265 170 458 minecraft:black_concrete
setblock 270 165 419 minecraft:light[level=12]
setblock 270 165 427 minecraft:light[level=12]
setblock 270 165 435 minecraft:light[level=12]
setblock 270 165 443 minecraft:light[level=12]
setblock 270 165 451 minecraft:light[level=12]
fill 271 165 416 271 170 416 minecraft:black_concrete
setblock 275 165 416 minecraft:crying_obsidian
fill 277 165 426 277 169 426 minecraft:black_concrete
fill 277 165 442 277 170 442 minecraft:black_concrete
fill 235 166 450 235 216 450 minecraft:black_concrete
fill 244 166 449 244 166 453 minecraft:amethyst_block
fill 244 166 455 244 168 455 minecraft:amethyst_block
setblock 248 166 416 minecraft:crying_obsidian
fill 248 166 458 248 274 458 minecraft:black_concrete
setblock 264 166 416 minecraft:amethyst_block
fill 275 166 416 275 186 416 minecraft:black_concrete
setblock 235 167 442 minecraft:amethyst_block
fill 243 167 453 243 167 456 minecraft:amethyst_block
fill 244 167 451 244 167 454 minecraft:amethyst_block
fill 244 167 456 244 168 457 minecraft:amethyst_block
fill 245 167 453 245 167 456 minecraft:amethyst_block
setblock 246 167 416 minecraft:amethyst_block
fill 248 167 416 248 207 416 minecraft:black_concrete
setblock 249 167 416 minecraft:crying_obsidian
fill 264 167 416 264 267 416 minecraft:black_concrete
setblock 235 168 434 minecraft:white_concrete
fill 235 168 442 235 307 442 minecraft:black_concrete
setblock 235 168 445 minecraft:amethyst_block
setblock 243 168 456 minecraft:amethyst_block
setblock 244 168 454 minecraft:amethyst_block
setblock 245 168 456 minecraft:amethyst_block
fill 246 168 416 246 241 416 minecraft:black_concrete
fill 249 168 416 249 214 416 minecraft:black_concrete
fill 264 168 452 265 169 453 minecraft:amethyst_block
fill 265 168 454 265 169 454 minecraft:amethyst_block
setblock 277 168 437 minecraft:amethyst_block
fill 235 169 434 235 283 434 minecraft:black_concrete
fill 235 169 445 235 198 445 minecraft:black_concrete
setblock 259 169 458 minecraft:crying_obsidian
fill 277 169 437 277 260 437 minecraft:black_concrete
setblock 277 169 444 minecraft:white_concrete
setblock 277 169 447 minecraft:amethyst_block
setblock 235 170 427 minecraft:amethyst_block
setblock 235 170 433 minecraft:amethyst_block
setblock 235 170 455 minecraft:crying_obsidian
setblock 235 170 457 minecraft:crying_obsidian
setblock 238 170 458 minecraft:crying_obsidian
fill 245 170 417 247 173 417 minecraft:amethyst_block
fill 246 170 418 246 172 419 minecraft:amethyst_block
fill 259 170 458 259 278 458 minecraft:black_concrete
setblock 277 170 426 minecraft:amethyst_block
setblock 277 170 440 minecraft:white_concrete
fill 277 170 444 277 212 444 minecraft:black_concrete
fill 277 170 447 277 221 447 minecraft:black_concrete
fill 235 171 424 235 173 424 minecraft:purple_concrete
fill 235 171 427 235 307 427 minecraft:black_concrete
fill 235 171 433 235 175 433 minecraft:black_concrete
fill 235 171 440 235 173 440 minecraft:purple_concrete
fill 235 171 455 235 204 455 minecraft:black_concrete
fill 235 171 456 235 173 456 minecraft:purple_concrete
fill 235 171 457 235 182 457 minecraft:black_concrete
fill 238 171 458 238 228 458 minecraft:black_concrete
fill 239 171 416 239 173 416 minecraft:purple_concrete
fill 245 171 418 245 172 419 minecraft:amethyst_block
fill 246 171 420 246 171 421 minecraft:amethyst_block
fill 247 171 418 247 172 419 minecraft:amethyst_block
fill 248 171 420 248 184 420 minecraft:obsidian
fill 249 171 458 249 173 458 minecraft:purple_concrete
fill 255 171 416 255 173 416 minecraft:purple_concrete
fill 265 171 458 265 173 458 minecraft:purple_concrete
fill 271 171 416 271 173 416 minecraft:purple_concrete
setblock 277 171 421 minecraft:amethyst_block
fill 277 171 426 277 173 426 minecraft:purple_concrete
fill 277 171 440 277 187 440 minecraft:black_concrete
fill 277 171 442 277 173 442 minecraft:purple_concrete
setblock 235 172 451 minecraft:crying_obsidian
setblock 244 172 416 minecraft:crying_obsidian
setblock 246 172 420 minecraft:amethyst_block
fill 277 172 421 277 307 421 minecraft:black_concrete
setblock 235 173 429 minecraft:amethyst_block
fill 235 173 451 235 206 451 minecraft:black_concrete
setblock 238 173 419 minecraft:light[level=12]
setblock 238 173 427 minecraft:light[level=12]
setblock 238 173 435 minecraft:light[level=12]
setblock 238 173 443 minecraft:light[level=12]
setblock 238 173 451 minecraft:light[level=12]
fill 244 173 416 244 236 416 minecraft:black_concrete
setblock 246 173 418 minecraft:amethyst_block
setblock 246 173 419 minecraft:light[level=12]
setblock 246 173 427 minecraft:light[level=12]
setblock 246 173 435 minecraft:light[level=12]
setblock 246 173 443 minecraft:light[level=12]
setblock 246 173 451 minecraft:light[level=12]
setblock 246 173 458 minecraft:amethyst_block
setblock 254 173 419 minecraft:light[level=12]
setblock 254 173 427 minecraft:light[level=12]
setblock 254 173 435 minecraft:light[level=12]
setblock 254 173 443 minecraft:light[level=12]
setblock 254 173 451 minecraft:light[level=12]
setblock 262 173 419 minecraft:light[level=12]
setblock 262 173 427 minecraft:light[level=12]
setblock 262 173 435 minecraft:light[level=12]
setblock 262 173 443 minecraft:light[level=12]
setblock 262 173 451 minecraft:light[level=12]
setblock 270 173 419 minecraft:light[level=12]
setblock 270 173 427 minecraft:light[level=12]
setblock 270 173 435 minecraft:light[level=12]
setblock 270 173 443 minecraft:light[level=12]
setblock 270 173 451 minecraft:light[level=12]
fill 235 174 424 235 179 424 minecraft:black_concrete
fill 235 174 429 235 214 429 minecraft:black_concrete
fill 235 174 440 235 179 440 minecraft:black_concrete
fill 235 174 456 235 179 456 minecraft:black_concrete
fill 239 174 416 239 179 416 minecraft:black_concrete
setblock 243 174 458 minecraft:white_concrete
fill 246 174 458 246 224 458 minecraft:black_concrete
fill 249 174 458 249 179 458 minecraft:black_concrete
fill 255 174 416 255 179 416 minecraft:black_concrete
setblock 257 174 458 minecraft:crying_obsidian
fill 265 174 458 265 179 458 minecraft:black_concrete
fill 270 174 429 271 175 430 minecraft:crying_obsidian
fill 271 174 416 271 177 416 minecraft:black_concrete
fill 277 174 426 277 179 426 minecraft:black_concrete
fill 277 174 442 277 179 442 minecraft:black_concrete
setblock 242 175 458 minecraft:crying_obsidian
fill 243 175 458 243 307 458 minecraft:black_concrete
setblock 244 175 458 minecraft:amethyst_block
fill 257 175 458 257 196 458 minecraft:black_concrete
setblock 277 175 438 minecraft:crying_obsidian
setblock 277 175 448 minecraft:white_concrete
setblock 235 176 433 minecraft:crying_obsidian
fill 242 176 458 242 192 458 minecraft:black_concrete
fill 244 176 458 244 208 458 minecraft:black_concrete
setblock 250 176 458 minecraft:amethyst_block
fill 277 176 438 277 193 438 minecraft:black_concrete
fill 277 176 448 277 232 448 minecraft:black_concrete
setblock 277 176 456 minecraft:amethyst_block
fill 235 177 433 235 293 433 minecraft:black_concrete
setblock 235 177 452 minecraft:white_concrete
fill 250 177 458 250 256 458 minecraft:black_concrete
fill 277 177 456 277 198 456 minecraft:black_concrete
setblock 235 178 446 minecraft:amethyst_block
fill 235 178 452 235 192 452 minecraft:black_concrete
setblock 243 178 416 minecraft:amethyst_block
fill 265 178 446 266 179 446 minecraft:amethyst_block
setblock 271 178 416 minecraft:white_concrete
setblock 235 179 426 minecraft:white_concrete
setblock 235 179 432 minecraft:white_concrete
setblock 235 179 443 minecraft:crying_obsidian
fill 235 179 446 235 211 446 minecraft:black_concrete
setblock 235 179 448 minecraft:crying_obsidian
setblock 235 179 454 minecraft:white_concrete
fill 243 179 416 243 181 416 minecraft:black_concrete
setblock 271 179 416 minecraft:black_concrete
fill 235 180 424 235 182 424 minecraft:purple_concrete
fill 235 180 426 235 188 426 minecraft:black_concrete
setblock 235 180 432 minecraft:crying_obsidian
fill 235 180 440 235 182 440 minecraft:purple_concrete
fill 235 180 443 235 300 443 minecraft:black_concrete
fill 235 180 448 235 276 448 minecraft:black_concrete
fill 235 180 454 235 304 454 minecraft:black_concrete
fill 235 180 456 235 182 456 minecraft:purple_concrete
fill 237 180 441 237 192 441 minecraft:obsidian
fill 239 180 416 239 182 416 minecraft:purple_concrete
fill 249 180 458 249 182 458 minecraft:purple_concrete
fill 255 180 416 255 182 416 minecraft:purple_concrete
fill 265 180 458 265 182 458 minecraft:purple_concrete
fill 271 180 416 271 182 416 minecraft:purple_concrete
fill 277 180 426 277 182 426 minecraft:purple_concrete
fill 277 180 442 277 182 442 minecraft:purple_concrete
setblock 277 180 454 minecraft:crying_obsidian
setblock 235 181 425 minecraft:amethyst_block
fill 235 181 432 235 281 432 minecraft:black_concrete
setblock 235 181 436 minecraft:crying_obsidian
setblock 238 181 419 minecraft:light[level=12]
setblock 238 181 427 minecraft:light[level=12]
setblock 238 181 435 minecraft:light[level=12]
setblock 238 181 443 minecraft:light[level=12]
setblock 238 181 451 minecraft:light[level=12]
setblock 246 181 419 minecraft:light[level=12]
setblock 246 181 427 minecraft:light[level=12]
setblock 246 181 435 minecraft:light[level=12]
setblock 246 181 443 minecraft:light[level=12]
setblock 246 181 451 minecraft:light[level=12]
setblock 254 181 419 minecraft:light[level=12]
setblock 254 181 427 minecraft:light[level=12]
setblock 254 181 435 minecraft:light[level=12]
setblock 254 181 443 minecraft:light[level=12]
setblock 254 181 451 minecraft:light[level=12]
setblock 255 181 458 minecraft:amethyst_block
setblock 262 181 419 minecraft:light[level=12]
setblock 262 181 427 minecraft:light[level=12]
setblock 262 181 435 minecraft:light[level=12]
setblock 262 181 443 minecraft:light[level=12]
setblock 262 181 451 minecraft:light[level=12]
setblock 270 181 419 minecraft:light[level=12]
setblock 270 181 427 minecraft:light[level=12]
setblock 270 181 435 minecraft:light[level=12]
setblock 270 181 443 minecraft:light[level=12]
setblock 270 181 451 minecraft:light[level=12]
fill 277 181 454 277 307 454 minecraft:black_concrete
fill 235 182 425 235 293 425 minecraft:black_concrete
fill 235 182 436 235 241 436 minecraft:black_concrete
setblock 243 182 416 minecraft:amethyst_block
fill 255 182 458 255 278 458 minecraft:black_concrete
setblock 261 182 416 minecraft:crying_obsidian
setblock 263 182 458 minecraft:amethyst_block
setblock 264 182 458 minecraft:white_concrete
fill 272 182 430 272 183 431 minecraft:crying_obsidian
setblock 235 183 421 minecraft:amethyst_block
fill 235 183 424 235 188 424 minecraft:black_concrete
fill 235 183 440 235 186 440 minecraft:black_concrete
fill 235 183 456 235 188 456 minecraft:black_concrete
setblock 235 183 457 minecraft:crying_obsidian
fill 239 183 416 239 188 416 minecraft:black_concrete
fill 243 183 416 243 256 416 minecraft:black_concrete
setblock 245 183 458 minecraft:amethyst_block
fill 249 183 458 249 188 458 minecraft:black_concrete
fill 255 183 416 255 188 416 minecraft:black_concrete
fill 261 183 416 261 267 416 minecraft:black_concrete
fill 263 183 458 265 188 458 minecraft:black_concrete
fill 271 183 416 271 188 416 minecraft:black_concrete
fill 277 183 426 277 188 426 minecraft:black_concrete
fill 277 183 442 277 188 442 minecraft:black_concrete
fill 235 184 421 235 272 421 minecraft:black_concrete
fill 235 184 457 235 236 457 minecraft:black_concrete
fill 245 184 458 245 198 458 minecraft:black_concrete
setblock 269 184 458 minecraft:amethyst_block
setblock 277 184 433 minecraft:amethyst_block
setblock 277 184 443 minecraft:crying_obsidian
setblock 235 185 417 minecraft:amethyst_block
setblock 238 185 416 minecraft:amethyst_block
fill 269 185 458 269 243 458 minecraft:black_concrete
fill 277 185 433 277 204 433 minecraft:black_concrete
fill 277 185 443 277 191 443 minecraft:black_concrete
setblock 277 185 446 minecraft:amethyst_block
setblock 277 185 449 minecraft:amethyst_block
fill 235 186 417 235 215 417 minecraft:black_concrete
setblock 235 186 438 minecraft:white_concrete
fill 238 186 416 238 196 416 minecraft:black_concrete
setblock 251 186 416 minecraft:white_concrete
fill 277 186 446 277 204 446 minecraft:black_concrete
setblock 277 186 449 minecraft:black_concrete
fill 235 187 438 235 236 438 minecraft:black_concrete
setblock 235 187 440 minecraft:white_concrete
fill 251 187 416 251 307 416 minecraft:black_concrete
setblock 275 187 416 minecraft:crying_obsidian
setblock 277 187 449 minecraft:white_concrete
setblock 235 188 440 minecraft:black_concrete
setblock 247 188 458 minecraft:white_concrete
setblock 268 188 458 minecraft:amethyst_block
fill 275 188 416 275 189 416 minecraft:black_concrete
setblock 277 188 440 minecraft:amethyst_block
fill 277 188 449 277 210 449 minecraft:black_concrete
fill 235 189 424 235 191 424 minecraft:purple_concrete
setblock 235 189 426 minecraft:amethyst_block
fill 235 189 440 235 191 440 minecraft:purple_concrete
fill 235 189 456 235 191 456 minecraft:purple_concrete
setblock 238 189 419 minecraft:light[level=12]
setblock 238 189 427 minecraft:light[level=12]
setblock 238 189 435 minecraft:light[level=12]
setblock 238 189 443 minecraft:light[level=12]
setblock 238 189 451 minecraft:light[level=12]
fill 239 189 416 239 191 416 minecraft:purple_concrete
setblock 246 189 419 minecraft:light[level=12]
setblock 246 189 427 minecraft:light[level=12]
setblock 246 189 435 minecraft:light[level=12]
setblock 246 189 443 minecraft:light[level=12]
setblock 246 189 451 minecraft:light[level=12]
fill 247 189 458 247 283 458 minecraft:black_concrete
fill 249 189 458 249 191 458 minecraft:purple_concrete
setblock 254 189 419 minecraft:light[level=12]
setblock 254 189 427 minecraft:light[level=12]
setblock 254 189 435 minecraft:light[level=12]
setblock 254 189 443 minecraft:light[level=12]
setblock 254 189 451 minecraft:light[level=12]
fill 255 189 416 255 191 416 minecraft:purple_concrete
setblock 262 189 419 minecraft:light[level=12]
setblock 262 189 427 minecraft:light[level=12]
setblock 262 189 435 minecraft:light[level=12]
setblock 262 189 443 minecraft:light[level=12]
setblock 262 189 451 minecraft:light[level=12]
fill 263 189 458 264 199 458 minecraft:black_concrete
fill 265 189 458 265 191 458 minecraft:purple_concrete
fill 268 189 458 268 292 458 minecraft:black_concrete
setblock 270 189 419 minecraft:light[level=12]
setblock 270 189 427 minecraft:light[level=12]
setblock 270 189 435 minecraft:light[level=12]
setblock 270 189 443 minecraft:light[level=12]
setblock 270 189 451 minecraft:light[level=12]
fill 271 189 416 271 191 416 minecraft:purple_concrete
fill 277 189 426 277 191 426 minecraft:purple_concrete
setblock 277 189 440 minecraft:black_concrete
fill 277 189 442 277 191 442 minecraft:purple_concrete
fill 235 190 426 235 294 426 minecraft:black_concrete
setblock 245 190 416 minecraft:crying_obsidian
setblock 275 190 416 minecraft:amethyst_block
setblock 277 190 440 minecraft:crying_obsidian
setblock 235 191 428 minecraft:amethyst_block
fill 245 191 416 245 195 416 minecraft:black_concrete
setblock 254 191 458 minecraft:crying_obsidian
fill 261 191 421 262 192 422 minecraft:crying_obsidian
fill 275 191 416 275 305 416 minecraft:black_concrete
setblock 277 191 419 minecraft:amethyst_block
fill 277 191 420 277 222 420 minecraft:black_concrete
setblock 277 191 436 minecraft:white_concrete
fill 277 191 440 277 281 440 minecraft:black_concrete
fill 235 192 424 235 197 424 minecraft:black_concrete
fill 235 192 428 235 222 428 minecraft:black_concrete
fill 235 192 440 235 197 440 minecraft:black_concrete
fill 235 192 456 235 197 456 minecraft:black_concrete
fill 239 192 416 239 197 416 minecraft:black_concrete
setblock 240 192 416 minecraft:amethyst_block
fill 249 192 458 249 197 458 minecraft:black_concrete
fill 254 192 458 254 201 458 minecraft:black_concrete
fill 255 192 416 255 197 416 minecraft:black_concrete
fill 265 192 458 265 197 458 minecraft:black_concrete
fill 270 192 423 271 192 423 minecraft:amethyst_block
fill 271 192 416 271 197 416 minecraft:black_concrete
setblock 274 192 416 minecraft:amethyst_block
fill 277 192 419 277 210 419 minecraft:black_concrete
fill 277 192 426 277 197 426 minecraft:black_concrete
setblock 277 192 427 minecraft:crying_obsidian
fill 277 192 436 277 202 436 minecraft:black_concrete
fill 277 192 442 277 197 442 minecraft:black_concrete
setblock 277 192 443 minecraft:crying_obsidian
setblock 235 193 444 minecraft:crying_obsidian
setblock 235 193 452 minecraft:white_concrete
fill 240 193 416 240 209 416 minecraft:black_concrete
setblock 242 193 458 minecraft:amethyst_block
fill 271 193 423 274 193 423 minecraft:amethyst_block
fill 274 193 416 274 195 416 minecraft:black_concrete
fill 277 193 427 277 307 427 minecraft:black_concrete
fill 277 193 443 277 272 443 minecraft:black_concrete
fill 235 194 444 235 196 444 minecraft:black_concrete
fill 235 194 452 235 199 452 minecraft:black_concrete
fill 242 194 458 242 290 458 minecraft:black_concrete
setblock 262 194 458 minecraft:white_concrete
fill 272 194 423 276 194 423 minecraft:amethyst_block
fill 274 194 422 275 194 422 minecraft:amethyst_block
fill 274 194 424 275 194 424 minecraft:amethyst_block
setblock 277 194 438 minecraft:amethyst_block
fill 262 195 458 262 198 458 minecraft:black_concrete
fill 274 195 423 276 195 423 minecraft:amethyst_block
setblock 275 195 422 minecraft:amethyst_block
setblock 275 195 424 minecraft:amethyst_block
fill 277 195 438 277 251 438 minecraft:black_concrete
setblock 277 195 452 minecraft:amethyst_block
setblock 245 196 416 minecraft:white_concrete
setblock 252 196 416 minecraft:crying_obsidian
setblock 258 196 458 minecraft:crying_obsidian
setblock 274 196 416 minecraft:crying_obsidian
fill 275 196 458 276 196 458 minecraft:white_concrete
fill 277 196 452 277 307 452 minecraft:black_concrete
setblock 235 197 444 minecraft:white_concrete
setblock 238 197 416 minecraft:crying_obsidian
setblock 238 197 419 minecraft:light[level=12]
setblock 238 197 427 minecraft:light[level=12]
setblock 238 197 435 minecraft:light[level=12]
setblock 238 197 443 minecraft:light[level=12]
setblock 238 197 451 minecraft:light[level=12]
fill 245 197 416 245 241 416 minecraft:black_concrete
setblock 246 197 419 minecraft:light[level=12]
setblock 246 197 427 minecraft:light[level=12]
setblock 246 197 435 minecraft:light[level=12]
setblock 246 197 443 minecraft:light[level=12]
setblock 246 197 451 minecraft:light[level=12]
fill 252 197 416 252 236 416 minecraft:black_concrete
setblock 254 197 419 minecraft:light[level=12]
setblock 254 197 427 minecraft:light[level=12]
setblock 254 197 435 minecraft:light[level=12]
setblock 254 197 443 minecraft:light[level=12]
setblock 254 197 451 minecraft:light[level=12]
setblock 257 197 458 minecraft:amethyst_block
fill 258 197 458 258 221 458 minecraft:black_concrete
setblock 262 197 419 minecraft:light[level=12]
setblock 262 197 427 minecraft:light[level=12]
setblock 262 197 435 minecraft:light[level=12]
setblock 262 197 443 minecraft:light[level=12]
setblock 262 197 451 minecraft:light[level=12]
setblock 270 197 419 minecraft:light[level=12]
setblock 270 197 427 minecraft:light[level=12]
setblock 270 197 435 minecraft:light[level=12]
setblock 270 197 443 minecraft:light[level=12]
setblock 270 197 451 minecraft:light[level=12]
fill 274 197 416 274 202 416 minecraft:black_concrete
fill 275 197 458 276 232 458 minecraft:black_concrete
fill 235 198 424 235 200 424 minecraft:purple_concrete
fill 235 198 440 235 200 440 minecraft:purple_concrete
setblock 235 198 441 minecraft:crying_obsidian
setblock 235 198 444 minecraft:amethyst_block
fill 235 198 456 235 200 456 minecraft:purple_concrete
fill 238 198 416 238 252 416 minecraft:black_concrete
fill 239 198 416 239 200 416 minecraft:purple_concrete
fill 249 198 458 249 200 458 minecraft:purple_concrete
fill 255 198 416 255 200 416 minecraft:purple_concrete
fill 257 198 458 257 278 458 minecraft:black_concrete
setblock 260 198 416 minecraft:white_concrete
fill 265 198 458 265 200 458 minecraft:purple_concrete
fill 271 198 416 271 200 416 minecraft:purple_concrete
fill 277 198 426 277 200 426 minecraft:purple_concrete
fill 277 198 442 277 200 442 minecraft:purple_concrete
fill 235 199 441 235 270 441 minecraft:black_concrete
fill 235 199 444 235 255 444 minecraft:black_concrete
setblock 235 199 445 minecraft:crying_obsidian
setblock 245 199 458 minecraft:crying_obsidian
fill 260 199 416 260 307 416 minecraft:black_concrete
setblock 262 199 458 minecraft:white_concrete
setblock 277 199 456 minecraft:crying_obsidian
setblock 235 200 422 minecraft:crying_obsidian
fill 235 200 445 235 234 445 minecraft:black_concrete
setblock 235 200 452 minecraft:crying_obsidian
fill 245 200 458 245 202 458 minecraft:black_concrete
fill 262 200 458 263 278 458 minecraft:black_concrete
setblock 264 200 458 minecraft:crying_obsidian
fill 277 200 456 277 307 456 minecraft:black_concrete
fill 235 201 422 235 217 422 minecraft:black_concrete
fill 235 201 424 235 206 424 minecraft:black_concrete
fill 235 201 440 235 206 440 minecraft:black_concrete
fill 235 201 452 235 233 452 minecraft:black_concrete
fill 235 201 456 235 206 456 minecraft:black_concrete
fill 239 201 416 239 206 416 minecraft:black_concrete
fill 249 201 458 249 206 458 minecraft:black_concrete
fill 255 201 416 255 206 416 minecraft:black_concrete
setblock 256 201 458 minecraft:amethyst_block
fill 264 201 458 265 206 458 minecraft:black_concrete
setblock 266 201 416 minecraft:amethyst_block
fill 266 201 423 266 202 424 minecraft:crying_obsidian
fill 271 201 416 271 202 416 minecraft:black_concrete
fill 277 201 426 277 204 426 minecraft:black_concrete
setblock 277 201 431 minecraft:crying_obsidian
fill 277 201 442 277 206 442 minecraft:black_concrete
setblock 277 201 453 minecraft:white_concrete
setblock 239 202 458 minecraft:crying_obsidian
setblock 254 202 458 minecraft:crying_obsidian
fill 256 202 458 256 204 458 minecraft:black_concrete
fill 261 202 447 261 203 447 minecraft:obsidian
fill 266 202 416 266 243 416 minecraft:black_concrete
fill 277 202 431 277 237 431 minecraft:black_concrete
fill 277 202 453 277 236 453 minecraft:black_concrete
fill 239 203 458 239 225 458 minecraft:black_concrete
setblock 245 203 458 minecraft:crying_obsidian
fill 254 203 458 254 278 458 minecraft:black_concrete
setblock 271 203 416 minecraft:amethyst_block
setblock 274 203 416 minecraft:amethyst_block
setblock 277 203 436 minecraft:crying_obsidian
fill 245 204 458 245 225 458 minecraft:black_concrete
setblock 258 204 416 minecraft:amethyst_block
fill 271 204 416 271 206 416 minecraft:black_concrete
fill 274 204 416 274 255 416 minecraft:black_concrete
fill 277 204 436 277 307 436 minecraft:black_concrete
setblock 235 205 453 minecraft:amethyst_block
setblock 235 205 455 minecraft:amethyst_block
setblock 238 205 419 minecraft:light[level=12]
setblock 238 205 427 minecraft:light[level=12]
setblock 238 205 435 minecraft:light[level=12]
setblock 238 205 443 minecraft:light[level=12]
setblock 238 205 451 minecraft:light[level=12]
setblock 246 205 419 minecraft:light[level=12]
setblock 246 205 427 minecraft:light[level=12]
setblock 246 205 435 minecraft:light[level=12]
setblock 246 205 443 minecraft:light[level=12]
setblock 246 205 451 minecraft:light[level=12]
setblock 254 205 419 minecraft:light[level=12]
setblock 254 205 427 minecraft:light[level=12]
setblock 254 205 435 minecraft:light[level=12]
setblock 254 205 443 minecraft:light[level=12]
setblock 254 205 451 minecraft:light[level=12]
setblock 256 205 458 minecraft:white_concrete
fill 258 205 416 258 302 416 minecraft:black_concrete
setblock 260 205 458 minecraft:amethyst_block
setblock 262 205 419 minecraft:light[level=12]
setblock 262 205 427 minecraft:light[level=12]
setblock 262 205 435 minecraft:light[level=12]
setblock 262 205 443 minecraft:light[level=12]
setblock 262 205 451 minecraft:light[level=12]
setblock 270 205 419 minecraft:light[level=12]
setblock 270 205 427 minecraft:light[level=12]
setblock 270 205 435 minecraft:light[level=12]
setblock 270 205 443 minecraft:light[level=12]
setblock 270 205 451 minecraft:light[level=12]
setblock 277 205 426 minecraft:amethyst_block
setblock 277 205 433 minecraft:crying_obsidian
setblock 277 205 446 minecraft:crying_obsidian
fill 235 206 453 235 291 453 minecraft:black_concrete
fill 235 206 455 235 241 455 minecraft:black_concrete
fill 256 206 458 256 278 458 minecraft:black_concrete
fill 258 206 445 260 207 445 minecraft:obsidian
fill 259 206 444 259 207 444 minecraft:obsidian
fill 259 206 446 259 207 446 minecraft:obsidian
fill 260 206 458 260 278 458 minecraft:black_concrete
setblock 276 206 416 minecraft:crying_obsidian
setblock 277 206 422 minecraft:crying_obsidian
setblock 277 206 426 minecraft:black_concrete
fill 277 206 433 277 261 433 minecraft:black_concrete
fill 277 206 446 277 307 446 minecraft:black_concrete
fill 235 207 424 235 209 424 minecraft:purple_concrete
fill 235 207 440 235 209 440 minecraft:purple_concrete
setblock 235 207 451 minecraft:crying_obsidian
fill 235 207 456 235 209 456 minecraft:purple_concrete
fill 239 207 416 239 209 416 minecraft:purple_concrete
fill 249 207 458 249 209 458 minecraft:purple_concrete
fill 255 207 416 255 209 416 minecraft:purple_concrete
setblock 256 207 416 minecraft:white_concrete
fill 264 207 458 264 208 458 minecraft:black_concrete
fill 265 207 458 265 209 458 minecraft:purple_concrete
fill 271 207 416 271 209 416 minecraft:purple_concrete
fill 276 207 416 276 241 416 minecraft:black_concrete
fill 277 207 422 277 307 422 minecraft:black_concrete
fill 277 207 426 277 209 426 minecraft:purple_concrete
fill 277 207 442 277 209 442 minecraft:purple_concrete
fill 235 208 451 235 307 451 minecraft:black_concrete
setblock 248 208 416 minecraft:crying_obsidian
fill 256 208 416 256 233 416 minecraft:black_concrete
setblock 241 209 416 minecraft:crying_obsidian
setblock 244 209 458 minecraft:crying_obsidian
fill 248 209 416 248 223 416 minecraft:black_concrete
setblock 264 209 458 minecraft:white_concrete
setblock 277 209 428 minecraft:white_concrete
setblock 277 209 457 minecraft:white_concrete
fill 235 210 424 235 211 424 minecraft:black_concrete
fill 235 210 440 235 215 440 minecraft:black_concrete
fill 235 210 456 235 215 456 minecraft:black_concrete
fill 239 210 416 239 215 416 minecraft:black_concrete
setblock 240 210 416 minecraft:crying_obsidian
fill 241 210 416 241 273 416 minecraft:black_concrete
fill 244 210 458 244 283 458 minecraft:black_concrete
fill 249 210 458 249 215 458 minecraft:black_concrete
fill 255 210 416 255 215 416 minecraft:black_concrete
fill 264 210 458 265 215 458 minecraft:black_concrete
fill 271 210 416 271 215 416 minecraft:black_concrete
fill 277 210 426 277 215 426 minecraft:black_concrete
fill 277 210 428 277 217 428 minecraft:black_concrete
fill 277 210 442 277 215 442 minecraft:black_concrete
fill 277 210 457 277 211 457 minecraft:black_concrete
fill 240 211 416 240 234 416 minecraft:black_concrete
setblock 274 211 458 minecraft:amethyst_block
fill 277 211 418 277 211 419 minecraft:white_concrete
setblock 277 211 449 minecraft:white_concrete
setblock 277 211 450 minecraft:amethyst_block
setblock 235 212 424 minecraft:crying_obsidian
setblock 235 212 446 minecraft:white_concrete
fill 274 212 458 274 227 458 minecraft:black_concrete
fill 277 212 418 277 246 419 minecraft:black_concrete
fill 277 212 449 277 307 450 minecraft:black_concrete
setblock 277 212 457 minecraft:white_concrete
fill 235 213 424 235 215 424 minecraft:black_concrete
fill 235 213 446 235 307 446 minecraft:black_concrete
setblock 235 213 449 minecraft:amethyst_block
setblock 238 213 419 minecraft:light[level=12]
setblock 238 213 427 minecraft:light[level=12]
setblock 238 213 435 minecraft:light[level=12]
setblock 238 213 443 minecraft:light[level=12]
setblock 238 213 451 minecraft:light[level=12]
setblock 246 213 419 minecraft:light[level=12]
setblock 246 213 427 minecraft:light[level=12]
setblock 246 213 435 minecraft:light[level=12]
setblock 246 213 443 minecraft:light[level=12]
setblock 246 213 451 minecraft:light[level=12]
setblock 254 213 419 minecraft:light[level=12]
setblock 254 213 427 minecraft:light[level=12]
setblock 254 213 435 minecraft:light[level=12]
setblock 254 213 443 minecraft:light[level=12]
setblock 254 213 451 minecraft:light[level=12]
setblock 262 213 419 minecraft:light[level=12]
setblock 262 213 427 minecraft:light[level=12]
fill 262 213 429 263 214 430 minecraft:amethyst_block
setblock 262 213 435 minecraft:light[level=12]
setblock 262 213 443 minecraft:light[level=12]
setblock 262 213 451 minecraft:light[level=12]
setblock 269 213 416 minecraft:amethyst_block
setblock 270 213 419 minecraft:light[level=12]
setblock 270 213 427 minecraft:light[level=12]
setblock 270 213 435 minecraft:light[level=12]
setblock 270 213 443 minecraft:light[level=12]
setblock 270 213 451 minecraft:light[level=12]
fill 277 213 423 277 213 424 minecraft:white_concrete
setblock 277 213 444 minecraft:crying_obsidian
fill 277 213 457 277 307 457 minecraft:black_concrete
fill 235 214 449 235 246 449 minecraft:black_concrete
fill 269 214 416 269 307 416 minecraft:black_concrete
fill 277 214 423 277 246 424 minecraft:black_concrete
setblock 277 214 432 minecraft:white_concrete
setblock 277 214 435 minecraft:crying_obsidian
fill 277 214 444 277 220 444 minecraft:black_concrete
setblock 235 215 429 minecraft:crying_obsidian
setblock 235 215 437 minecraft:white_concrete
setblock 247 215 416 minecraft:amethyst_block
setblock 249 215 416 minecraft:white_concrete
setblock 254 215 416 minecraft:crying_obsidian
fill 277 215 432 277 254 432 minecraft:black_concrete
fill 277 215 435 277 299 435 minecraft:black_concrete
setblock 235 216 417 minecraft:crying_obsidian
fill 235 216 424 235 218 424 minecraft:purple_concrete
fill 235 216 429 235 307 429 minecraft:black_concrete
fill 235 216 437 235 307 437 minecraft:black_concrete
fill 235 216 440 235 218 440 minecraft:purple_concrete
fill 235 216 456 235 218 456 minecraft:purple_concrete
fill 239 216 416 239 218 416 minecraft:purple_concrete
fill 247 216 416 247 217 416 minecraft:black_concrete
fill 249 216 416 249 307 416 minecraft:black_concrete
fill 249 216 458 249 218 458 minecraft:purple_concrete
fill 254 216 416 254 257 416 minecraft:black_concrete
fill 255 216 416 255 218 416 minecraft:purple_concrete
fill 264 216 458 264 278 458 minecraft:black_concrete
fill 265 216 458 265 218 458 minecraft:purple_concrete
fill 267 216 421 267 218 421 minecraft:obsidian
fill 271 216 416 271 218 416 minecraft:purple_concrete
setblock 273 216 416 minecraft:crying_obsidian
fill 277 216 426 277 218 426 minecraft:purple_concrete
fill 277 216 442 277 218 442 minecraft:purple_concrete
fill 235 217 417 235 275 417 minecraft:black_concrete
setblock 235 217 450 minecraft:white_concrete
setblock 273 217 416 minecraft:white_concrete
setblock 235 218 422 minecraft:white_concrete
fill 235 218 450 235 242 450 minecraft:black_concrete
setblock 245 218 444 minecraft:amethyst_block
setblock 247 218 416 minecraft:white_concrete
fill 273 218 416 273 228 416 minecraft:black_concrete
setblock 277 218 428 minecraft:crying_obsidian
fill 235 219 422 235 307 422 minecraft:black_concrete
fill 235 219 424 235 232 424 minecraft:black_concrete
fill 235 219 440 235 232 440 minecraft:black_concrete
fill 235 219 456 235 233 456 minecraft:black_concrete
fill 239 219 416 239 233 416 minecraft:black_concrete
setblock 241 219 458 minecraft:crying_obsidian
fill 247 219 416 247 245 416 minecraft:black_concrete
fill 249 219 458 249 232 458 minecraft:black_concrete
fill 255 219 416 255 233 416 minecraft:black_concrete
fill 265 219 458 265 233 458 minecraft:black_concrete
fill 271 219 416 271 233 416 minecraft:black_concrete
fill 277 219 426 277 233 426 minecraft:black_concrete
fill 277 219 428 277 250 428 minecraft:black_concrete
fill 277 219 442 277 233 442 minecraft:black_concrete
fill 241 220 458 241 307 458 minecraft:black_concrete
setblock 235 221 420 minecraft:amethyst_block
setblock 238 221 419 minecraft:light[level=12]
setblock 238 221 427 minecraft:light[level=12]
setblock 238 221 435 minecraft:light[level=12]
setblock 238 221 443 minecraft:light[level=12]
setblock 238 221 451 minecraft:light[level=12]
setblock 246 221 419 minecraft:light[level=12]
setblock 246 221 427 minecraft:light[level=12]
setblock 246 221 435 minecraft:light[level=12]
setblock 246 221 443 minecraft:light[level=12]
setblock 246 221 451 minecraft:light[level=12]
setblock 250 221 416 minecraft:white_concrete
setblock 254 221 419 minecraft:light[level=12]
setblock 254 221 427 minecraft:light[level=12]
setblock 254 221 435 minecraft:light[level=12]
setblock 254 221 443 minecraft:light[level=12]
setblock 254 221 451 minecraft:light[level=12]
setblock 262 221 419 minecraft:light[level=12]
setblock 262 221 427 minecraft:light[level=12]
setblock 262 221 435 minecraft:light[level=12]
setblock 262 221 443 minecraft:light[level=12]
setblock 262 221 451 minecraft:light[level=12]
setblock 270 221 419 minecraft:light[level=12]
setblock 270 221 427 minecraft:light[level=12]
setblock 270 221 435 minecraft:light[level=12]
setblock 270 221 443 minecraft:light[level=12]
setblock 270 221 451 minecraft:light[level=12]
setblock 277 221 444 minecraft:crying_obsidian
fill 235 222 420 235 307 420 minecraft:black_concrete
fill 250 222 416 250 223 416 minecraft:black_concrete
setblock 258 222 458 minecraft:amethyst_block
fill 277 222 444 277 248 444 minecraft:black_concrete
setblock 277 222 447 minecraft:white_concrete
setblock 235 223 428 minecraft:white_concrete
setblock 235 223 435 minecraft:crying_obsidian
setblock 235 223 439 minecraft:crying_obsidian
fill 258 223 458 258 228 458 minecraft:black_concrete
setblock 267 223 458 minecraft:amethyst_block
setblock 277 223 420 minecraft:amethyst_block
fill 277 223 447 277 234 447 minecraft:black_concrete
fill 235 224 428 235 230 428 minecraft:black_concrete
fill 235 224 435 235 284 435 minecraft:black_concrete
fill 235 224 439 235 256 439 minecraft:black_concrete
fill 245 224 436 245 226 438 minecraft:amethyst_block
fill 246 224 433 246 226 436 minecraft:amethyst_block
fill 246 224 437 251 224 437 minecraft:black_concrete
fill 246 224 438 246 226 441 minecraft:amethyst_block
fill 247 224 432 247 226 433 minecraft:amethyst_block
fill 247 224 434 252 224 436 minecraft:black_concrete
fill 247 224 438 252 224 440 minecraft:black_concrete
fill 247 224 441 247 226 442 minecraft:amethyst_block
setblock 248 224 416 minecraft:crying_obsidian
fill 248 224 431 248 226 431 minecraft:amethyst_block
fill 248 224 432 260 225 433 minecraft:black_concrete
fill 248 224 441 260 225 442 minecraft:black_concrete
fill 248 224 443 248 226 443 minecraft:amethyst_block
fill 249 224 430 250 226 430 minecraft:amethyst_block
fill 249 224 431 259 225 431 minecraft:black_concrete
fill 249 224 443 259 225 443 minecraft:black_concrete
fill 249 224 444 250 226 444 minecraft:amethyst_block
setblock 250 224 416 minecraft:amethyst_block
fill 250 224 429 253 226 429 minecraft:amethyst_block
fill 250 224 445 253 226 445 minecraft:amethyst_block
fill 251 224 430 257 225 430 minecraft:black_concrete
fill 251 224 444 257 225 444 minecraft:black_concrete
fill 253 224 428 255 226 428 minecraft:amethyst_block
fill 253 224 434 253 224 435 minecraft:black_concrete
fill 253 224 439 253 224 440 minecraft:black_concrete
fill 253 224 446 255 226 446 minecraft:amethyst_block
fill 254 224 429 254 225 429 minecraft:black_concrete
fill 254 224 434 261 224 434 minecraft:black_concrete
fill 254 224 440 261 224 440 minecraft:black_concrete
fill 254 224 445 254 225 445 minecraft:black_concrete
fill 255 224 429 258 226 429 minecraft:amethyst_block
fill 255 224 435 261 224 435 minecraft:black_concrete
fill 255 224 439 261 224 439 minecraft:black_concrete
fill 255 224 445 258 226 445 minecraft:amethyst_block
fill 256 224 436 261 224 436 minecraft:black_concrete
fill 256 224 438 261 224 438 minecraft:black_concrete
fill 257 224 437 262 224 437 minecraft:black_concrete
fill 258 224 430 259 226 430 minecraft:amethyst_block
fill 258 224 444 259 226 444 minecraft:amethyst_block
fill 260 224 431 260 226 431 minecraft:amethyst_block
fill 260 224 443 260 226 443 minecraft:amethyst_block
fill 261 224 432 261 226 433 minecraft:amethyst_block
fill 261 224 441 261 226 442 minecraft:amethyst_block
fill 262 224 433 262 226 436 minecraft:amethyst_block
fill 262 224 438 262 226 441 minecraft:amethyst_block
fill 263 224 436 263 226 438 minecraft:amethyst_block
fill 267 224 458 267 250 458 minecraft:black_concrete
setblock 270 224 458 minecraft:white_concrete
fill 277 224 420 277 236 420 minecraft:black_concrete
fill 236 225 417 244 225 457 minecraft:obsidian
fill 245 225 417 245 225 433 minecraft:obsidian
fill 245 225 434 245 225 435 minecraft:amethyst_block
fill 245 225 439 245 225 440 minecraft:amethyst_block
fill 245 225 441 245 225 457 minecraft:obsidian
fill 246 225 417 246 225 431 minecraft:obsidian
setblock 246 225 432 minecraft:amethyst_block
fill 246 225 437 250 225 437 minecraft:black_concrete
setblock 246 225 442 minecraft:amethyst_block
fill 246 225 443 246 225 457 minecraft:obsidian
setblock 246 225 458 minecraft:amethyst_block
fill 247 225 417 247 225 430 minecraft:obsidian
setblock 247 225 431 minecraft:amethyst_block
fill 247 225 434 250 225 436 minecraft:black_concrete
fill 247 225 438 250 225 440 minecraft:black_concrete
setblock 247 225 443 minecraft:amethyst_block
fill 247 225 444 247 225 457 minecraft:obsidian
fill 248 225 416 248 307 416 minecraft:black_concrete
fill 248 225 417 248 225 429 minecraft:obsidian
setblock 248 225 430 minecraft:amethyst_block
setblock 248 225 444 minecraft:amethyst_block
fill 248 225 445 248 225 457 minecraft:obsidian
fill 249 225 417 250 225 428 minecraft:obsidian
setblock 249 225 429 minecraft:amethyst_block
setblock 249 225 445 minecraft:amethyst_block
fill 249 225 446 250 225 457 minecraft:obsidian
fill 250 225 416 250 240 416 minecraft:black_concrete
fill 251 225 417 276 225 427 minecraft:obsidian
fill 251 225 428 252 225 428 minecraft:amethyst_block
fill 251 225 434 251 225 435 minecraft:black_concrete
fill 251 225 436 251 225 438 minecraft:crying_obsidian
fill 251 225 439 251 225 440 minecraft:black_concrete
fill 251 225 446 252 225 446 minecraft:amethyst_block
fill 251 225 447 276 225 457 minecraft:obsidian
setblock 252 225 434 minecraft:black_concrete
fill 252 225 435 252 225 436 minecraft:crying_obsidian
fill 252 225 438 252 225 439 minecraft:crying_obsidian
setblock 252 225 440 minecraft:black_concrete
fill 253 225 434 253 225 435 minecraft:crying_obsidian
fill 253 225 439 253 225 440 minecraft:crying_obsidian
fill 254 225 434 255 225 434 minecraft:crying_obsidian
fill 254 225 440 255 225 440 minecraft:crying_obsidian
fill 255 225 435 256 225 435 minecraft:crying_obsidian
fill 255 225 439 256 225 439 minecraft:crying_obsidian
fill 256 225 428 257 225 428 minecraft:amethyst_block
fill 256 225 434 261 225 434 minecraft:black_concrete
fill 256 225 436 257 225 436 minecraft:crying_obsidian
fill 256 225 438 257 225 438 minecraft:crying_obsidian
fill 256 225 440 261 225 440 minecraft:black_concrete
fill 256 225 446 257 225 446 minecraft:amethyst_block
fill 257 225 435 261 225 435 minecraft:black_concrete
setblock 257 225 437 minecraft:crying_obsidian
fill 257 225 439 261 225 439 minecraft:black_concrete
fill 258 225 428 276 225 428 minecraft:obsidian
fill 258 225 436 261 225 438 minecraft:black_concrete
fill 258 225 446 276 225 446 minecraft:obsidian
setblock 259 225 429 minecraft:amethyst_block
setblock 259 225 445 minecraft:amethyst_block
fill 260 225 429 276 225 429 minecraft:obsidian
setblock 260 225 430 minecraft:amethyst_block
setblock 260 225 444 minecraft:amethyst_block
fill 260 225 445 276 225 445 minecraft:obsidian
fill 261 225 430 276 225 430 minecraft:obsidian
setblock 261 225 431 minecraft:amethyst_block
setblock 261 225 443 minecraft:amethyst_block
fill 261 225 444 276 225 444 minecraft:obsidian
fill 262 225 431 276 225 431 minecraft:obsidian
setblock 262 225 432 minecraft:amethyst_block
setblock 262 225 437 minecraft:black_concrete
setblock 262 225 442 minecraft:amethyst_block
fill 262 225 443 276 225 443 minecraft:obsidian
fill 263 225 432 276 225 433 minecraft:obsidian
fill 263 225 434 263 225 435 minecraft:amethyst_block
fill 263 225 439 263 225 440 minecraft:amethyst_block
fill 263 225 441 276 225 442 minecraft:obsidian
fill 264 225 434 276 225 440 minecraft:obsidian
fill 270 225 458 270 306 458 minecraft:black_concrete
setblock 239 226 458 minecraft:amethyst_block
setblock 245 226 458 minecraft:crying_obsidian
fill 246 226 437 247 226 437 minecraft:amethyst_block
fill 246 226 458 246 304 458 minecraft:black_concrete
fill 247 226 434 247 226 436 minecraft:amethyst_block
fill 247 226 438 247 226 440 minecraft:amethyst_block
fill 248 226 432 248 226 433 minecraft:amethyst_block
fill 248 226 441 248 226 442 minecraft:amethyst_block
fill 249 226 431 249 226 432 minecraft:amethyst_block
fill 249 226 442 249 226 443 minecraft:amethyst_block
setblock 250 226 431 minecraft:amethyst_block
setblock 250 226 443 minecraft:amethyst_block
fill 251 226 430 257 226 430 minecraft:amethyst_block
fill 251 226 444 257 226 444 minecraft:amethyst_block
setblock 254 226 429 minecraft:amethyst_block
setblock 254 226 445 minecraft:amethyst_block
fill 258 226 431 259 226 431 minecraft:amethyst_block
fill 258 226 443 259 226 443 minecraft:amethyst_block
setblock 259 226 416 minecraft:amethyst_block
fill 259 226 432 260 226 432 minecraft:amethyst_block
fill 259 226 442 260 226 442 minecraft:amethyst_block
setblock 260 226 433 minecraft:amethyst_block
setblock 260 226 441 minecraft:amethyst_block
fill 261 226 434 261 226 440 minecraft:amethyst_block
setblock 262 226 437 minecraft:amethyst_block
setblock 272 226 458 minecraft:crying_obsidian
fill 239 227 458 239 307 458 minecraft:black_concrete
fill 245 227 458 245 252 458 minecraft:black_concrete
fill 259 227 416 259 307 416 minecraft:black_concrete
fill 272 227 458 272 307 458 minecraft:black_concrete
setblock 274 228 458 minecraft:amethyst_block
setblock 238 229 419 minecraft:light[level=12]
setblock 238 229 427 minecraft:light[level=12]
setblock 238 229 435 minecraft:light[level=12]
setblock 238 229 443 minecraft:light[level=12]
setblock 238 229 451 minecraft:light[level=12]
setblock 238 229 458 minecraft:amethyst_block
fill 241 229 443 250 230 445 minecraft:black_concrete
fill 242 229 441 248 230 442 minecraft:black_concrete
fill 242 229 446 249 230 447 minecraft:black_concrete
fill 243 229 448 248 230 448 minecraft:black_concrete
fill 244 229 440 247 230 440 minecraft:black_concrete
setblock 246 229 419 minecraft:light[level=12]
setblock 246 229 427 minecraft:light[level=12]
setblock 246 229 435 minecraft:light[level=12]
setblock 246 229 451 minecraft:light[level=12]
fill 249 229 442 249 230 442 minecraft:black_concrete
setblock 254 229 419 minecraft:light[level=12]
setblock 254 229 427 minecraft:light[level=12]
setblock 254 229 435 minecraft:light[level=12]
setblock 254 229 443 minecraft:light[level=12]
setblock 254 229 451 minecraft:light[level=12]
setblock 258 229 458 minecraft:white_concrete
setblock 262 229 419 minecraft:light[level=12]
setblock 262 229 427 minecraft:light[level=12]
setblock 262 229 435 minecraft:light[level=12]
setblock 262 229 443 minecraft:light[level=12]
setblock 262 229 451 minecraft:light[level=12]
fill 267 229 421 267 234 421 minecraft:obsidian
setblock 270 229 419 minecraft:light[level=12]
setblock 270 229 427 minecraft:light[level=12]
setblock 270 229 435 minecraft:light[level=12]
setblock 270 229 443 minecraft:light[level=12]
setblock 270 229 451 minecraft:light[level=12]
setblock 273 229 416 minecraft:white_concrete
fill 274 229 458 274 230 458 minecraft:black_concrete
fill 238 230 458 238 237 458 minecraft:black_concrete
setblock 241 230 442 minecraft:black_concrete
setblock 241 230 446 minecraft:black_concrete
setblock 242 230 448 minecraft:black_concrete
setblock 243 230 440 minecraft:black_concrete
fill 244 230 449 247 230 449 minecraft:black_concrete
fill 245 230 439 246 230 439 minecraft:black_concrete
setblock 248 230 440 minecraft:black_concrete
setblock 249 230 441 minecraft:black_concrete
setblock 250 230 442 minecraft:black_concrete
setblock 250 230 446 minecraft:black_concrete
fill 258 230 458 258 259 458 minecraft:black_concrete
fill 273 230 416 273 307 416 minecraft:black_concrete
setblock 235 231 428 minecraft:white_concrete
fill 245 231 443 245 231 445 minecraft:amethyst_block
fill 246 231 444 246 232 445 minecraft:amethyst_block
setblock 274 231 458 minecraft:white_concrete
fill 235 232 428 235 307 428 minecraft:black_concrete
fill 245 232 444 245 232 445 minecraft:amethyst_block
fill 246 232 433 247 233 433 minecraft:crying_obsidian
fill 274 232 458 274 307 458 minecraft:black_concrete
setblock 235 233 424 minecraft:white_concrete
setblock 235 233 440 minecraft:white_concrete
setblock 240 233 458 minecraft:crying_obsidian
fill 245 233 444 246 233 444 minecraft:amethyst_block
setblock 249 233 458 minecraft:amethyst_block
setblock 275 233 458 minecraft:crying_obsidian
fill 276 233 458 276 264 458 minecraft:black_concrete
setblock 277 233 439 minecraft:crying_obsidian
setblock 277 233 448 minecraft:amethyst_block
fill 235 234 424 235 236 424 minecraft:purple_concrete
fill 235 234 440 235 236 440 minecraft:purple_concrete
setblock 235 234 452 minecraft:crying_obsidian
fill 235 234 456 235 236 456 minecraft:purple_concrete
fill 239 234 416 239 236 416 minecraft:purple_concrete
fill 240 234 458 240 306 458 minecraft:black_concrete
setblock 245 234 444 minecraft:amethyst_block
fill 247 234 418 247 234 424 minecraft:amethyst_block
fill 249 234 458 249 236 458 minecraft:purple_concrete
fill 255 234 416 255 236 416 minecraft:purple_concrete
setblock 256 234 416 minecraft:amethyst_block
fill 265 234 458 265 236 458 minecraft:purple_concrete
fill 271 234 416 271 236 416 minecraft:purple_concrete
fill 275 234 458 275 303 458 minecraft:black_concrete
setblock 277 234 425 minecraft:white_concrete
fill 277 234 426 277 236 426 minecraft:purple_concrete
fill 277 234 439 277 249 439 minecraft:black_concrete
fill 277 234 442 277 236 442 minecraft:purple_concrete
fill 277 234 448 277 250 448 minecraft:black_concrete
setblock 235 235 445 minecraft:white_concrete
fill 235 235 452 235 307 452 minecraft:black_concrete
setblock 240 235 416 minecraft:crying_obsidian
fill 246 235 417 248 235 420 minecraft:amethyst_block
setblock 247 235 421 minecraft:amethyst_block
fill 256 235 416 256 258 416 minecraft:black_concrete
fill 277 235 425 277 276 425 minecraft:black_concrete
setblock 277 235 447 minecraft:crying_obsidian
fill 235 236 445 235 273 445 minecraft:black_concrete
fill 240 236 416 240 307 416 minecraft:black_concrete
fill 246 236 417 248 236 417 minecraft:amethyst_block
fill 247 236 418 247 236 419 minecraft:amethyst_block
setblock 266 236 458 minecraft:crying_obsidian
fill 268 236 440 275 236 440 minecraft:amethyst_block
fill 271 236 439 271 238 439 minecraft:amethyst_block
fill 271 236 441 271 238 441 minecraft:amethyst_block
fill 272 236 434 276 238 434 minecraft:amethyst_block
fill 273 236 433 276 239 433 minecraft:amethyst_block
fill 273 236 435 276 239 435 minecraft:amethyst_block
fill 277 236 447 277 260 447 minecraft:black_concrete
fill 235 237 424 235 242 424 minecraft:black_concrete
setblock 235 237 438 minecraft:amethyst_block
fill 235 237 440 235 242 440 minecraft:black_concrete
fill 235 237 456 235 242 456 minecraft:black_concrete
setblock 235 237 457 minecraft:crying_obsidian
setblock 238 237 419 minecraft:light[level=12]
setblock 238 237 427 minecraft:light[level=12]
setblock 238 237 435 minecraft:light[level=12]
setblock 238 237 443 minecraft:light[level=12]
setblock 238 237 451 minecraft:light[level=12]
fill 239 237 416 239 242 416 minecraft:black_concrete
setblock 244 237 416 minecraft:white_concrete
setblock 246 237 419 minecraft:light[level=12]
setblock 246 237 427 minecraft:light[level=12]
setblock 246 237 435 minecraft:light[level=12]
setblock 246 237 443 minecraft:light[level=12]
setblock 246 237 451 minecraft:light[level=12]
fill 249 237 458 249 242 458 minecraft:black_concrete
setblock 252 237 416 minecraft:crying_obsidian
setblock 254 237 419 minecraft:light[level=12]
setblock 254 237 427 minecraft:light[level=12]
setblock 254 237 435 minecraft:light[level=12]
setblock 254 237 443 minecraft:light[level=12]
setblock 254 237 451 minecraft:light[level=12]
fill 255 237 416 255 242 416 minecraft:black_concrete
setblock 262 237 419 minecraft:light[level=12]
setblock 262 237 427 minecraft:light[level=12]
setblock 262 237 435 minecraft:light[level=12]
setblock 262 237 443 minecraft:light[level=12]
setblock 262 237 451 minecraft:light[level=12]
fill 265 237 458 266 242 458 minecraft:black_concrete
fill 269 237 434 271 237 434 minecraft:amethyst_block
fill 269 237 440 276 237 440 minecraft:amethyst_block
setblock 270 237 419 minecraft:light[level=12]
setblock 270 237 427 minecraft:light[level=12]
setblock 270 237 435 minecraft:light[level=12]
setblock 270 237 439 minecraft:amethyst_block
setblock 270 237 441 minecraft:amethyst_block
setblock 270 237 443 minecraft:light[level=12]
setblock 270 237 451 minecraft:light[level=12]
fill 271 237 416 271 242 416 minecraft:black_concrete
fill 271 237 433 272 238 433 minecraft:amethyst_block
fill 271 237 435 272 238 435 minecraft:amethyst_block
fill 272 237 439 276 239 439 minecraft:amethyst_block
fill 272 237 441 276 239 441 minecraft:amethyst_block
fill 274 237 432 276 238 432 minecraft:amethyst_block
fill 274 237 436 276 238 436 minecraft:amethyst_block
fill 275 237 438 275 240 438 minecraft:amethyst_block
fill 275 237 442 275 240 442 minecraft:amethyst_block
setblock 277 237 420 minecraft:white_concrete
fill 277 237 426 277 242 426 minecraft:black_concrete
fill 277 237 442 277 242 442 minecraft:black_concrete
setblock 277 237 451 minecraft:white_concrete
setblock 277 237 453 minecraft:amethyst_block
fill 235 238 438 235 249 438 minecraft:black_concrete
fill 235 238 457 235 247 457 minecraft:black_concrete
setblock 238 238 458 minecraft:white_concrete
fill 244 238 416 244 307 416 minecraft:black_concrete
fill 252 238 416 252 307 416 minecraft:black_concrete
fill 270 238 434 271 238 434 minecraft:amethyst_block
fill 270 238 440 276 238 440 minecraft:amethyst_block
fill 273 238 438 274 238 438 minecraft:amethyst_block
fill 273 238 442 274 238 442 minecraft:amethyst_block
fill 276 238 438 276 239 438 minecraft:amethyst_block
fill 276 238 442 276 239 442 minecraft:amethyst_block
fill 277 238 420 277 243 420 minecraft:black_concrete
setblock 277 238 431 minecraft:crying_obsidian
fill 277 238 451 277 307 451 minecraft:black_concrete
fill 277 238 453 277 300 453 minecraft:black_concrete
fill 238 239 458 238 246 458 minecraft:black_concrete
fill 272 239 440 276 239 440 minecraft:amethyst_block
fill 273 239 434 276 239 434 minecraft:amethyst_block
setblock 274 239 438 minecraft:amethyst_block
setblock 274 239 442 minecraft:amethyst_block
fill 277 239 431 277 249 431 minecraft:black_concrete
fill 242 240 433 243 241 433 minecraft:crying_obsidian
fill 246 240 429 246 241 430 minecraft:amethyst_block
fill 273 240 440 276 240 440 minecraft:amethyst_block
fill 274 240 439 276 240 439 minecraft:amethyst_block
fill 274 240 441 276 240 441 minecraft:amethyst_block
setblock 250 241 416 minecraft:crying_obsidian
setblock 275 241 440 minecraft:amethyst_block
setblock 235 242 430 minecraft:amethyst_block
setblock 235 242 436 minecraft:amethyst_block
setblock 235 242 455 minecraft:crying_obsidian
setblock 245 242 416 minecraft:amethyst_block
setblock 246 242 416 minecraft:white_concrete
fill 250 242 416 250 291 416 minecraft:black_concrete
setblock 276 242 416 minecraft:white_concrete
fill 235 243 424 235 245 424 minecraft:purple_concrete
fill 235 243 430 235 248 430 minecraft:black_concrete
fill 235 243 436 235 307 436 minecraft:black_concrete
fill 235 243 440 235 245 440 minecraft:purple_concrete
setblock 235 243 450 minecraft:white_concrete
fill 235 243 455 235 307 455 minecraft:black_concrete
fill 235 243 456 235 245 456 minecraft:purple_concrete
fill 239 243 416 239 245 416 minecraft:purple_concrete
fill 245 243 416 246 266 416 minecraft:black_concrete
fill 249 243 458 249 245 458 minecraft:purple_concrete
fill 255 243 416 255 245 416 minecraft:purple_concrete
fill 265 243 458 265 245 458 minecraft:purple_concrete
fill 266 243 458 266 265 458 minecraft:black_concrete
fill 271 243 416 271 245 416 minecraft:purple_concrete
fill 276 243 416 276 303 416 minecraft:black_concrete
fill 277 243 426 277 245 426 minecraft:purple_concrete
fill 277 243 442 277 245 442 minecraft:purple_concrete
setblock 235 244 431 minecraft:white_concrete
fill 235 244 450 235 250 450 minecraft:black_concrete
fill 250 244 426 250 245 426 minecraft:amethyst_block
setblock 266 244 416 minecraft:white_concrete
setblock 269 244 458 minecraft:amethyst_block
setblock 277 244 420 minecraft:crying_obsidian
fill 235 245 431 235 307 431 minecraft:black_concrete
setblock 238 245 419 minecraft:light[level=12]
setblock 238 245 427 minecraft:light[level=12]
setblock 238 245 435 minecraft:light[level=12]
setblock 238 245 443 minecraft:light[level=12]
setblock 238 245 451 minecraft:light[level=12]
setblock 246 245 419 minecraft:light[level=12]
setblock 246 245 427 minecraft:light[level=12]
setblock 246 245 435 minecraft:light[level=12]
setblock 246 245 443 minecraft:light[level=12]
setblock 246 245 451 minecraft:light[level=12]
setblock 254 245 419 minecraft:light[level=12]
setblock 254 245 427 minecraft:light[level=12]
setblock 254 245 435 minecraft:light[level=12]
setblock 254 245 443 minecraft:light[level=12]
setblock 254 245 451 minecraft:light[level=12]
setblock 262 245 419 minecraft:light[level=12]
setblock 262 245 427 minecraft:light[level=12]
setblock 262 245 435 minecraft:light[level=12]
setblock 262 245 443 minecraft:light[level=12]
setblock 262 245 451 minecraft:light[level=12]
fill 263 245 433 264 246 433 minecraft:crying_obsidian
fill 266 245 416 266 305 416 minecraft:black_concrete
fill 269 245 458 269 276 458 minecraft:black_concrete
setblock 270 245 419 minecraft:light[level=12]
setblock 270 245 427 minecraft:light[level=12]
setblock 270 245 435 minecraft:light[level=12]
setblock 270 245 443 minecraft:light[level=12]
setblock 270 245 451 minecraft:light[level=12]
fill 277 245 420 277 307 420 minecraft:black_concrete
fill 235 246 424 235 251 424 minecraft:black_concrete
fill 235 246 440 235 251 440 minecraft:black_concrete
fill 235 246 456 235 251 456 minecraft:black_concrete
fill 239 246 416 239 251 416 minecraft:black_concrete
setblock 247 246 416 minecraft:white_concrete
fill 249 246 458 249 251 458 minecraft:black_concrete
fill 255 246 416 255 251 416 minecraft:black_concrete
fill 265 246 458 265 251 458 minecraft:black_concrete
fill 271 246 416 271 251 416 minecraft:black_concrete
fill 277 246 426 277 251 426 minecraft:black_concrete
fill 277 246 442 277 251 442 minecraft:black_concrete
setblock 235 247 423 minecraft:amethyst_block
setblock 235 247 449 minecraft:amethyst_block
setblock 238 247 458 minecraft:amethyst_block
fill 247 247 416 247 307 416 minecraft:black_concrete
setblock 277 247 418 minecraft:amethyst_block
fill 277 247 419 277 255 419 minecraft:black_concrete
fill 277 247 423 277 307 423 minecraft:black_concrete
setblock 277 247 424 minecraft:crying_obsidian
fill 235 248 423 235 285 423 minecraft:black_concrete
fill 235 248 449 235 307 449 minecraft:black_concrete
setblock 235 248 457 minecraft:white_concrete
fill 238 248 458 238 254 458 minecraft:black_concrete
fill 249 248 448 249 249 448 minecraft:obsidian
setblock 257 248 416 minecraft:crying_obsidian
fill 277 248 418 277 266 418 minecraft:black_concrete
fill 277 248 424 277 307 424 minecraft:black_concrete
setblock 235 249 430 minecraft:white_concrete
fill 235 249 457 235 307 457 minecraft:black_concrete
fill 257 249 416 257 307 416 minecraft:black_concrete
setblock 273 249 458 minecraft:crying_obsidian
setblock 277 249 444 minecraft:crying_obsidian
fill 235 250 430 235 254 430 minecraft:black_concrete
setblock 235 250 438 minecraft:crying_obsidian
fill 273 250 458 273 307 458 minecraft:black_concrete
setblock 277 250 431 minecraft:amethyst_block
setblock 277 250 439 minecraft:white_concrete
fill 277 250 444 277 307 444 minecraft:black_concrete
fill 235 251 438 235 297 438 minecraft:black_concrete
setblock 235 251 450 minecraft:crying_obsidian
setblock 267 251 458 minecraft:amethyst_block
setblock 277 251 428 minecraft:white_concrete
fill 277 251 431 277 291 431 minecraft:black_concrete
fill 277 251 439 277 278 439 minecraft:black_concrete
setblock 277 251 448 minecraft:white_concrete
fill 235 252 424 235 254 424 minecraft:purple_concrete
fill 235 252 440 235 254 440 minecraft:purple_concrete
fill 235 252 450 235 253 450 minecraft:black_concrete
fill 235 252 456 235 254 456 minecraft:purple_concrete
fill 239 252 416 239 254 416 minecraft:purple_concrete
fill 249 252 458 249 254 458 minecraft:purple_concrete
fill 255 252 416 255 254 416 minecraft:purple_concrete
fill 265 252 458 265 254 458 minecraft:purple_concrete
fill 267 252 458 267 280 458 minecraft:black_concrete
fill 271 252 416 271 254 416 minecraft:purple_concrete
fill 277 252 426 277 254 426 minecraft:purple_concrete
fill 277 252 428 277 307 428 minecraft:black_concrete
setblock 277 252 430 minecraft:white_concrete
setblock 277 252 438 minecraft:white_concrete
fill 277 252 442 277 254 442 minecraft:purple_concrete
fill 277 252 448 277 270 448 minecraft:black_concrete
setblock 238 253 416 minecraft:white_concrete
setblock 238 253 419 minecraft:light[level=12]
setblock 238 253 427 minecraft:light[level=12]
setblock 238 253 435 minecraft:light[level=12]
setblock 238 253 443 minecraft:light[level=12]
setblock 238 253 451 minecraft:light[level=12]
setblock 245 253 458 minecraft:amethyst_block
setblock 246 253 419 minecraft:light[level=12]
setblock 246 253 427 minecraft:light[level=12]
setblock 246 253 435 minecraft:light[level=12]
setblock 246 253 443 minecraft:light[level=12]
setblock 246 253 451 minecraft:light[level=12]
setblock 254 253 419 minecraft:light[level=12]
setblock 254 253 427 minecraft:light[level=12]
setblock 254 253 435 minecraft:light[level=12]
setblock 254 253 443 minecraft:light[level=12]
setblock 254 253 451 minecraft:light[level=12]
setblock 262 253 419 minecraft:light[level=12]
setblock 262 253 427 minecraft:light[level=12]
setblock 262 253 435 minecraft:light[level=12]
setblock 262 253 443 minecraft:light[level=12]
setblock 262 253 451 minecraft:light[level=12]
setblock 270 253 419 minecraft:light[level=12]
setblock 270 253 427 minecraft:light[level=12]
setblock 270 253 435 minecraft:light[level=12]
setblock 270 253 443 minecraft:light[level=12]
setblock 270 253 451 minecraft:light[level=12]
fill 277 253 430 277 277 430 minecraft:black_concrete
fill 277 253 438 277 307 438 minecraft:black_concrete
setblock 235 254 450 minecraft:white_concrete
fill 238 254 416 238 275 416 minecraft:black_concrete
fill 240 254 440 240 262 440 minecraft:obsidian
fill 245 254 458 245 307 458 minecraft:black_concrete
fill 235 255 424 235 257 424 minecraft:black_concrete
setblock 235 255 430 minecraft:amethyst_block
fill 235 255 440 235 260 440 minecraft:black_concrete
fill 235 255 450 235 307 450 minecraft:black_concrete
fill 235 255 456 235 260 456 minecraft:black_concrete
setblock 238 255 458 minecraft:amethyst_block
fill 239 255 416 239 260 416 minecraft:black_concrete
fill 249 255 458 249 259 458 minecraft:black_concrete
fill 255 255 416 255 260 416 minecraft:black_concrete
fill 265 255 458 265 260 458 minecraft:black_concrete
fill 271 255 416 271 260 416 minecraft:black_concrete
fill 277 255 426 277 260 426 minecraft:black_concrete
setblock 277 255 432 minecraft:crying_obsidian
fill 277 255 442 277 260 442 minecraft:black_concrete
fill 235 256 430 235 307 430 minecraft:black_concrete
setblock 235 256 444 minecraft:white_concrete
setblock 237 256 416 minecraft:amethyst_block
fill 238 256 458 238 273 458 minecraft:black_concrete
setblock 274 256 416 minecraft:white_concrete
setblock 277 256 419 minecraft:white_concrete
fill 277 256 432 277 307 432 minecraft:black_concrete
setblock 277 256 434 minecraft:amethyst_block
setblock 235 257 439 minecraft:white_concrete
fill 235 257 444 235 307 444 minecraft:black_concrete
fill 237 257 416 237 307 416 minecraft:black_concrete
setblock 243 257 416 minecraft:white_concrete
setblock 250 257 458 minecraft:crying_obsidian
fill 274 257 416 274 307 416 minecraft:black_concrete
fill 277 257 419 277 307 419 minecraft:black_concrete
fill 277 257 434 277 307 434 minecraft:black_concrete
setblock 235 258 424 minecraft:amethyst_block
fill 235 258 439 235 278 439 minecraft:black_concrete
fill 243 258 416 243 273 416 minecraft:black_concrete
fill 250 258 458 250 278 458 minecraft:black_concrete
setblock 254 258 416 minecraft:amethyst_block
fill 235 259 424 235 260 424 minecraft:black_concrete
fill 254 259 416 254 307 416 minecraft:black_concrete
setblock 256 259 416 minecraft:crying_obsidian
setblock 249 260 458 minecraft:crying_obsidian
setblock 252 260 458 minecraft:white_concrete
fill 256 260 416 256 271 416 minecraft:black_concrete
setblock 258 260 458 minecraft:amethyst_block
fill 235 261 424 235 263 424 minecraft:purple_concrete
fill 235 261 440 235 263 440 minecraft:purple_concrete
fill 235 261 456 235 263 456 minecraft:purple_concrete
setblock 238 261 419 minecraft:light[level=12]
setblock 238 261 427 minecraft:light[level=12]
setblock 238 261 435 minecraft:light[level=12]
setblock 238 261 443 minecraft:light[level=12]
setblock 238 261 451 minecraft:light[level=12]
fill 239 261 416 239 263 416 minecraft:purple_concrete
setblock 246 261 419 minecraft:light[level=12]
setblock 246 261 427 minecraft:light[level=12]
setblock 246 261 435 minecraft:light[level=12]
setblock 246 261 443 minecraft:light[level=12]
setblock 246 261 451 minecraft:light[level=12]
fill 249 261 458 249 263 458 minecraft:purple_concrete
fill 252 261 458 252 278 458 minecraft:black_concrete
setblock 254 261 419 minecraft:light[level=12]
setblock 254 261 427 minecraft:light[level=12]
setblock 254 261 435 minecraft:light[level=12]
setblock 254 261 443 minecraft:light[level=12]
setblock 254 261 451 minecraft:light[level=12]
fill 255 261 416 255 263 416 minecraft:purple_concrete
fill 258 261 458 258 278 458 minecraft:black_concrete
setblock 262 261 419 minecraft:light[level=12]
setblock 262 261 427 minecraft:light[level=12]
setblock 262 261 435 minecraft:light[level=12]
setblock 262 261 443 minecraft:light[level=12]
setblock 262 261 451 minecraft:light[level=12]
fill 265 261 458 265 263 458 minecraft:purple_concrete
setblock 268 261 416 minecraft:white_concrete
setblock 270 261 416 minecraft:amethyst_block
setblock 270 261 419 minecraft:light[level=12]
setblock 270 261 427 minecraft:light[level=12]
setblock 270 261 435 minecraft:light[level=12]
setblock 270 261 443 minecraft:light[level=12]
setblock 270 261 451 minecraft:light[level=12]
fill 271 261 416 271 263 416 minecraft:purple_concrete
fill 277 261 426 277 263 426 minecraft:purple_concrete
setblock 277 261 437 minecraft:crying_obsidian
fill 277 261 442 277 263 442 minecraft:purple_concrete
setblock 277 261 447 minecraft:amethyst_block
fill 268 262 416 268 278 416 minecraft:black_concrete
fill 270 262 416 270 307 416 minecraft:black_concrete
setblock 277 262 433 minecraft:white_concrete
fill 277 262 437 277 307 437 minecraft:black_concrete
fill 277 262 447 277 307 447 minecraft:black_concrete
fill 277 263 433 277 297 433 minecraft:black_concrete
fill 235 264 424 235 269 424 minecraft:black_concrete
fill 235 264 440 235 269 440 minecraft:black_concrete
fill 235 264 456 235 269 456 minecraft:black_concrete
fill 239 264 416 239 268 416 minecraft:black_concrete
fill 249 264 458 249 269 458 minecraft:black_concrete
fill 255 264 416 255 269 416 minecraft:black_concrete
fill 265 264 458 265 269 458 minecraft:black_concrete
fill 271 264 416 271 267 416 minecraft:black_concrete
fill 277 264 426 277 269 426 minecraft:black_concrete
fill 277 264 442 277 269 442 minecraft:black_concrete
setblock 276 265 458 minecraft:amethyst_block
setblock 266 266 458 minecraft:white_concrete
fill 276 266 458 276 282 458 minecraft:black_concrete
fill 245 267 416 245 272 416 minecraft:black_concrete
setblock 246 267 416 minecraft:amethyst_block
fill 266 267 458 266 307 458 minecraft:black_concrete
setblock 277 267 418 minecraft:crying_obsidian
fill 246 268 416 246 307 416 minecraft:black_concrete
setblock 261 268 416 minecraft:crying_obsidian
setblock 264 268 416 minecraft:amethyst_block
setblock 271 268 416 minecraft:amethyst_block
fill 277 268 418 277 269 418 minecraft:black_concrete
setblock 238 269 419 minecraft:light[level=12]
setblock 238 269 427 minecraft:light[level=12]
setblock 238 269 435 minecraft:light[level=12]
setblock 238 269 443 minecraft:light[level=12]
setblock 238 269 451 minecraft:light[level=12]
setblock 239 269 416 minecraft:crying_obsidian
setblock 246 269 419 minecraft:light[level=12]
setblock 246 269 427 minecraft:light[level=12]
setblock 246 269 435 minecraft:light[level=12]
setblock 246 269 443 minecraft:light[level=12]
setblock 246 269 451 minecraft:light[level=12]
setblock 254 269 419 minecraft:light[level=12]
setblock 254 269 427 minecraft:light[level=12]
setblock 254 269 435 minecraft:light[level=12]
setblock 254 269 443 minecraft:light[level=12]
setblock 254 269 451 minecraft:light[level=12]
fill 261 269 416 261 274 416 minecraft:black_concrete
setblock 262 269 419 minecraft:light[level=12]
setblock 262 269 427 minecraft:light[level=12]
setblock 262 269 435 minecraft:light[level=12]
setblock 262 269 443 minecraft:light[level=12]
setblock 262 269 451 minecraft:light[level=12]
fill 264 269 416 264 307 416 minecraft:black_concrete
setblock 270 269 419 minecraft:light[level=12]
setblock 270 269 427 minecraft:light[level=12]
setblock 270 269 435 minecraft:light[level=12]
setblock 270 269 443 minecraft:light[level=12]
setblock 270 269 451 minecraft:light[level=12]
setblock 271 269 416 minecraft:black_concrete
fill 235 270 424 235 272 424 minecraft:purple_concrete
fill 235 270 440 235 272 440 minecraft:purple_concrete
fill 235 270 456 235 272 456 minecraft:purple_concrete
fill 239 270 416 239 272 416 minecraft:purple_concrete
fill 249 270 458 249 272 458 minecraft:purple_concrete
fill 255 270 416 255 272 416 minecraft:purple_concrete
fill 265 270 458 265 272 458 minecraft:purple_concrete
fill 271 270 416 271 272 416 minecraft:purple_concrete
setblock 277 270 418 minecraft:white_concrete
fill 277 270 426 277 272 426 minecraft:purple_concrete
fill 277 270 442 277 272 442 minecraft:purple_concrete
setblock 235 271 441 minecraft:amethyst_block
fill 277 271 418 277 307 418 minecraft:black_concrete
setblock 277 271 448 minecraft:white_concrete
fill 235 272 441 235 307 441 minecraft:black_concrete
setblock 256 272 416 minecraft:white_concrete
fill 277 272 448 277 307 448 minecraft:black_concrete
setblock 235 273 421 minecraft:amethyst_block
fill 235 273 424 235 283 424 minecraft:black_concrete
fill 235 273 440 235 287 440 minecraft:black_concrete
fill 235 273 456 235 287 456 minecraft:black_concrete
fill 239 273 416 239 286 416 minecraft:black_concrete
setblock 245 273 416 minecraft:crying_obsidian
fill 249 273 458 249 274 458 minecraft:black_concrete
fill 255 273 416 256 277 416 minecraft:black_concrete
fill 265 273 458 265 287 458 minecraft:black_concrete
fill 271 273 416 271 287 416 minecraft:black_concrete
fill 277 273 426 277 287 426 minecraft:black_concrete
fill 277 273 442 277 287 442 minecraft:black_concrete
setblock 277 273 443 minecraft:white_concrete
fill 235 274 421 235 307 421 minecraft:black_concrete
setblock 235 274 445 minecraft:white_concrete
setblock 238 274 458 minecraft:crying_obsidian
setblock 241 274 416 minecraft:amethyst_block
setblock 243 274 416 minecraft:crying_obsidian
fill 245 274 416 245 307 416 minecraft:black_concrete
fill 277 274 443 277 281 443 minecraft:black_concrete
fill 235 275 445 235 307 445 minecraft:black_concrete
fill 238 275 458 238 301 458 minecraft:black_concrete
fill 241 275 416 241 307 416 minecraft:black_concrete
fill 243 275 416 243 303 416 minecraft:black_concrete
setblock 248 275 458 minecraft:crying_obsidian
setblock 249 275 458 minecraft:white_concrete
setblock 261 275 416 minecraft:crying_obsidian
setblock 235 276 417 minecraft:amethyst_block
setblock 238 276 416 minecraft:white_concrete
fill 248 276 458 249 278 458 minecraft:black_concrete
fill 261 276 416 261 307 416 minecraft:black_concrete
fill 235 277 417 235 307 417 minecraft:black_concrete
setblock 235 277 448 minecraft:crying_obsidian
fill 238 277 416 238 286 416 minecraft:black_concrete
setblock 238 277 419 minecraft:light[level=12]
setblock 238 277 427 minecraft:light[level=12]
setblock 238 277 435 minecraft:light[level=12]
setblock 238 277 443 minecraft:light[level=12]
setblock 238 277 451 minecraft:light[level=12]
setblock 246 277 419 minecraft:light[level=12]
setblock 246 277 427 minecraft:light[level=12]
setblock 246 277 435 minecraft:light[level=12]
setblock 246 277 443 minecraft:light[level=12]
setblock 246 277 451 minecraft:light[level=12]
setblock 254 277 419 minecraft:light[level=12]
setblock 254 277 427 minecraft:light[level=12]
setblock 254 277 435 minecraft:light[level=12]
setblock 254 277 443 minecraft:light[level=12]
setblock 254 277 451 minecraft:light[level=12]
setblock 262 277 419 minecraft:light[level=12]
setblock 262 277 427 minecraft:light[level=12]
setblock 262 277 435 minecraft:light[level=12]
setblock 262 277 443 minecraft:light[level=12]
setblock 262 277 451 minecraft:light[level=12]
setblock 269 277 458 minecraft:crying_obsidian
setblock 270 277 419 minecraft:light[level=12]
setblock 270 277 427 minecraft:light[level=12]
setblock 270 277 435 minecraft:light[level=12]
setblock 270 277 443 minecraft:light[level=12]
setblock 270 277 451 minecraft:light[level=12]
setblock 277 277 425 minecraft:white_concrete
fill 235 278 448 235 307 448 minecraft:black_concrete
setblock 255 278 416 minecraft:crying_obsidian
fill 256 278 416 256 301 416 minecraft:black_concrete
fill 269 278 458 269 307 458 minecraft:black_concrete
fill 277 278 425 277 297 425 minecraft:black_concrete
setblock 277 278 430 minecraft:amethyst_block
setblock 277 278 441 minecraft:amethyst_block
fill 235 279 439 253 279 439 minecraft:obsidian
fill 236 279 433 253 279 438 minecraft:obsidian
fill 236 279 440 253 279 445 minecraft:obsidian
fill 237 279 431 275 279 432 minecraft:obsidian
fill 237 279 446 275 279 447 minecraft:obsidian
fill 238 279 429 274 279 430 minecraft:obsidian
fill 238 279 448 274 279 449 minecraft:obsidian
fill 239 279 427 273 279 428 minecraft:obsidian
fill 239 279 450 273 279 451 minecraft:obsidian
fill 240 279 426 272 279 426 minecraft:obsidian
fill 240 279 452 272 279 452 minecraft:obsidian
fill 241 279 425 271 279 425 minecraft:obsidian
fill 241 279 453 271 279 453 minecraft:obsidian
fill 242 279 424 270 279 424 minecraft:obsidian
fill 242 279 454 270 279 454 minecraft:obsidian
fill 243 279 423 269 279 423 minecraft:obsidian
fill 243 279 455 269 279 455 minecraft:obsidian
fill 244 279 422 268 279 422 minecraft:obsidian
fill 244 279 456 268 279 456 minecraft:obsidian
fill 246 279 421 266 279 421 minecraft:obsidian
fill 246 279 457 266 279 457 minecraft:obsidian
fill 248 279 420 264 279 420 minecraft:obsidian
fill 248 279 458 264 279 458 minecraft:obsidian
fill 250 279 419 262 279 419 minecraft:obsidian
fill 254 279 433 254 279 437 minecraft:obsidian
fill 254 279 441 254 279 445 minecraft:obsidian
fill 255 279 416 255 287 416 minecraft:black_concrete
fill 255 279 433 276 279 436 minecraft:obsidian
fill 255 279 442 276 279 445 minecraft:obsidian
fill 256 279 418 256 286 418 minecraft:obsidian
fill 258 279 437 276 279 437 minecraft:obsidian
fill 258 279 441 276 279 441 minecraft:obsidian
fill 259 279 438 276 279 440 minecraft:obsidian
setblock 268 279 416 minecraft:white_concrete
fill 277 279 430 277 307 430 minecraft:black_concrete
setblock 277 279 439 minecraft:obsidian
fill 277 279 441 277 289 441 minecraft:black_concrete
fill 235 280 439 235 286 439 minecraft:purple_concrete
fill 236 280 417 236 280 432 minecraft:black_concrete
fill 236 280 433 237 286 437 minecraft:obsidian
fill 236 280 438 236 286 438 minecraft:purple_concrete
fill 236 280 439 238 286 445 minecraft:obsidian
fill 236 280 446 236 280 457 minecraft:black_concrete
fill 237 280 417 237 280 430 minecraft:black_concrete
fill 237 280 431 249 283 432 minecraft:obsidian
fill 237 280 438 248 282 438 minecraft:obsidian
fill 237 280 446 237 286 447 minecraft:obsidian
fill 237 280 448 237 280 457 minecraft:black_concrete
fill 238 280 417 238 280 428 minecraft:black_concrete
fill 238 280 429 240 286 430 minecraft:obsidian
fill 238 280 433 238 286 436 minecraft:obsidian
fill 238 280 437 238 286 437 minecraft:purple_concrete
fill 238 280 446 238 286 446 minecraft:purple_concrete
fill 238 280 447 243 285 449 minecraft:obsidian
fill 238 280 450 238 280 457 minecraft:black_concrete
fill 239 280 417 239 280 426 minecraft:black_concrete
fill 239 280 427 251 284 428 minecraft:obsidian
fill 239 280 433 241 285 435 minecraft:obsidian
fill 239 280 436 240 285 436 minecraft:purple_concrete
fill 239 280 437 250 281 437 minecraft:obsidian
fill 239 280 439 239 285 444 minecraft:obsidian
fill 239 280 445 239 286 445 minecraft:purple_concrete
fill 239 280 446 244 284 446 minecraft:obsidian
fill 239 280 450 242 286 451 minecraft:obsidian
fill 239 280 452 239 280 457 minecraft:black_concrete
fill 240 280 417 240 280 425 minecraft:black_concrete
fill 240 280 426 250 284 426 minecraft:obsidian
fill 240 280 439 240 285 442 minecraft:obsidian
fill 240 280 443 240 285 443 minecraft:purple_concrete
fill 240 280 444 245 284 445 minecraft:obsidian
fill 240 280 452 242 286 452 minecraft:obsidian
fill 240 280 453 240 280 457 minecraft:black_concrete
fill 241 280 417 241 280 424 minecraft:black_concrete
fill 241 280 425 256 284 425 minecraft:obsidian
fill 241 280 429 243 285 429 minecraft:purple_concrete
fill 241 280 430 246 284 430 minecraft:obsidian
fill 241 280 436 251 281 436 minecraft:obsidian
fill 241 280 439 241 285 441 minecraft:obsidian
fill 241 280 442 241 285 442 minecraft:purple_concrete
fill 241 280 443 246 283 443 minecraft:obsidian
fill 241 280 453 242 286 453 minecraft:obsidian
fill 241 280 454 241 280 457 minecraft:black_concrete
fill 242 280 417 242 280 423 minecraft:black_concrete
fill 242 280 424 246 286 424 minecraft:obsidian
fill 242 280 433 253 281 434 minecraft:obsidian
fill 242 280 435 243 284 435 minecraft:purple_concrete
fill 242 280 439 243 284 440 minecraft:obsidian
fill 242 280 441 242 284 441 minecraft:purple_concrete
fill 242 280 442 247 283 442 minecraft:obsidian
fill 242 280 454 242 286 454 minecraft:obsidian
fill 242 280 455 242 280 457 minecraft:black_concrete
fill 243 280 417 243 280 422 minecraft:black_concrete
fill 243 280 423 243 286 423 minecraft:obsidian
fill 243 280 441 250 281 441 minecraft:obsidian
fill 243 280 450 248 284 450 minecraft:obsidian
fill 243 280 451 243 286 455 minecraft:purple_concrete
fill 243 280 456 243 280 457 minecraft:black_concrete
fill 244 280 417 245 280 421 minecraft:black_concrete
fill 244 280 422 254 285 422 minecraft:obsidian
fill 244 280 423 245 286 423 minecraft:purple_concrete
fill 244 280 429 253 283 429 minecraft:obsidian
fill 244 280 435 249 282 435 minecraft:obsidian
fill 244 280 439 250 281 439 minecraft:obsidian
fill 244 280 440 244 284 440 minecraft:purple_concrete
fill 244 280 447 256 282 447 minecraft:obsidian
fill 244 280 448 244 285 448 minecraft:purple_concrete
fill 244 280 449 248 284 449 minecraft:obsidian
fill 244 280 451 248 284 456 minecraft:obsidian
fill 244 280 457 245 280 457 minecraft:black_concrete
fill 245 280 440 250 281 440 minecraft:obsidian
fill 245 280 446 245 284 446 minecraft:purple_concrete
fill 245 280 448 263 282 448 minecraft:obsidian
fill 246 280 417 247 280 420 minecraft:black_concrete
fill 246 280 421 253 286 421 minecraft:obsidian
fill 246 280 423 255 285 423 minecraft:obsidian
fill 246 280 444 246 283 444 minecraft:purple_concrete
fill 246 280 445 275 281 446 minecraft:obsidian
fill 246 280 457 249 286 457 minecraft:obsidian
fill 247 280 424 248 285 424 minecraft:purple_concrete
fill 247 280 430 248 284 430 minecraft:purple_concrete
fill 247 280 443 247 283 443 minecraft:purple_concrete
fill 247 280 444 253 281 444 minecraft:obsidian
fill 248 280 417 249 280 419 minecraft:black_concrete
fill 248 280 420 252 286 420 minecraft:obsidian
fill 248 280 442 248 282 442 minecraft:purple_concrete
fill 248 280 443 252 281 443 minecraft:obsidian
fill 248 280 458 258 286 458 minecraft:obsidian
fill 249 280 424 268 285 424 minecraft:obsidian
fill 249 280 430 267 282 430 minecraft:obsidian
fill 249 280 438 249 282 438 minecraft:purple_concrete
fill 249 280 442 251 281 442 minecraft:obsidian
fill 249 280 449 249 284 453 minecraft:purple_concrete
fill 249 280 454 249 285 456 minecraft:obsidian
fill 250 280 417 255 280 418 minecraft:black_concrete
fill 250 280 419 251 286 419 minecraft:obsidian
fill 250 280 431 250 283 431 minecraft:purple_concrete
fill 250 280 432 266 282 432 minecraft:obsidian
fill 250 280 435 250 282 435 minecraft:purple_concrete
fill 250 280 438 250 281 438 minecraft:obsidian
fill 250 280 449 253 283 455 minecraft:obsidian
fill 250 280 456 250 286 457 minecraft:purple_concrete
fill 251 280 426 251 284 426 minecraft:purple_concrete
fill 251 280 431 254 282 431 minecraft:obsidian
fill 251 280 435 252 281 435 minecraft:obsidian
fill 251 280 437 253 280 441 minecraft:crying_obsidian
fill 251 280 456 256 285 457 minecraft:obsidian
fill 252 280 419 252 286 419 minecraft:purple_concrete
fill 252 280 426 262 284 426 minecraft:obsidian
fill 252 280 427 252 284 427 minecraft:purple_concrete
fill 252 280 428 252 283 428 minecraft:obsidian
fill 252 280 436 260 280 436 minecraft:crying_obsidian
fill 252 280 442 260 280 442 minecraft:crying_obsidian
fill 253 280 419 260 286 419 minecraft:obsidian
fill 253 280 420 253 286 420 minecraft:purple_concrete
fill 253 280 427 257 284 427 minecraft:obsidian
fill 253 280 428 253 283 428 minecraft:purple_concrete
fill 253 280 435 259 281 435 minecraft:crying_obsidian
fill 253 280 443 259 281 443 minecraft:crying_obsidian
fill 254 280 420 264 286 420 minecraft:obsidian
fill 254 280 421 254 286 421 minecraft:purple_concrete
fill 254 280 428 257 283 428 minecraft:obsidian
fill 254 280 429 254 283 429 minecraft:purple_concrete
fill 254 280 433 272 281 433 minecraft:obsidian
fill 254 280 434 258 281 434 minecraft:crying_obsidian
setblock 254 280 437 minecraft:crying_obsidian
setblock 254 280 441 minecraft:crying_obsidian
fill 254 280 444 258 281 444 minecraft:crying_obsidian
fill 254 280 449 257 283 449 minecraft:obsidian
fill 254 280 450 254 283 451 minecraft:purple_concrete
fill 254 280 452 254 284 455 minecraft:obsidian
fill 255 280 421 261 286 421 minecraft:obsidian
fill 255 280 422 255 285 422 minecraft:purple_concrete
fill 255 280 429 262 283 429 minecraft:obsidian
fill 255 280 431 255 282 431 minecraft:purple_concrete
fill 255 280 450 258 283 452 minecraft:obsidian
fill 255 280 453 255 284 453 minecraft:purple_concrete
fill 255 280 454 255 285 455 minecraft:obsidian
fill 256 280 417 276 280 417 minecraft:black_concrete
fill 256 280 422 261 285 422 minecraft:obsidian
fill 256 280 423 256 285 423 minecraft:purple_concrete
fill 256 280 431 275 282 431 minecraft:obsidian
fill 256 280 453 263 284 454 minecraft:obsidian
fill 256 280 455 256 285 455 minecraft:purple_concrete
fill 257 280 418 276 280 418 minecraft:black_concrete
fill 257 280 423 268 285 423 minecraft:obsidian
fill 257 280 425 257 284 425 minecraft:purple_concrete
fill 257 280 447 257 282 447 minecraft:purple_concrete
fill 257 280 455 266 285 455 minecraft:obsidian
fill 257 280 456 257 285 456 minecraft:purple_concrete
fill 257 280 457 257 286 457 minecraft:obsidian
fill 258 280 425 262 284 425 minecraft:obsidian
fill 258 280 427 258 283 428 minecraft:purple_concrete
fill 258 280 437 261 280 437 minecraft:crying_obsidian
fill 258 280 441 261 280 441 minecraft:crying_obsidian
fill 258 280 447 261 282 447 minecraft:obsidian
fill 258 280 449 258 283 449 minecraft:purple_concrete
fill 258 280 456 268 285 456 minecraft:obsidian
fill 258 280 457 258 286 457 minecraft:purple_concrete
fill 259 280 427 262 283 428 minecraft:obsidian
fill 259 280 434 265 281 434 minecraft:obsidian
fill 259 280 438 261 280 440 minecraft:crying_obsidian
fill 259 280 444 276 281 444 minecraft:obsidian
fill 259 280 449 268 283 449 minecraft:obsidian
fill 259 280 450 259 283 450 minecraft:purple_concrete
fill 259 280 451 259 284 452 minecraft:obsidian
fill 259 280 457 266 286 457 minecraft:obsidian
fill 259 280 458 259 286 458 minecraft:purple_concrete
fill 260 280 435 264 281 435 minecraft:obsidian
fill 260 280 443 261 281 443 minecraft:obsidian
fill 260 280 450 273 283 450 minecraft:obsidian
fill 260 280 451 260 284 451 minecraft:purple_concrete
fill 260 280 452 260 284 452 minecraft:obsidian
fill 260 280 458 264 286 458 minecraft:obsidian
fill 261 280 419 261 286 419 minecraft:purple_concrete
fill 261 280 436 263 281 436 minecraft:obsidian
fill 261 280 442 271 281 442 minecraft:obsidian
fill 261 280 451 273 284 451 minecraft:obsidian
fill 261 280 452 261 284 452 minecraft:purple_concrete
fill 262 280 419 262 286 419 minecraft:obsidian
fill 262 280 421 262 286 422 minecraft:purple_concrete
fill 262 280 437 262 281 441 minecraft:obsidian
fill 262 280 443 262 282 443 minecraft:purple_concrete
fill 262 280 447 262 283 447 minecraft:purple_concrete
fill 262 280 452 272 284 452 minecraft:obsidian
fill 263 280 419 276 280 419 minecraft:black_concrete
fill 263 280 421 266 286 422 minecraft:obsidian
fill 263 280 425 263 284 429 minecraft:purple_concrete
fill 263 280 437 267 282 439 minecraft:obsidian
fill 263 280 440 263 282 440 minecraft:purple_concrete
fill 263 280 441 273 282 441 minecraft:obsidian
fill 263 280 443 268 282 443 minecraft:obsidian
fill 263 280 447 275 283 447 minecraft:obsidian
fill 264 280 425 268 284 429 minecraft:obsidian
fill 264 280 436 264 282 436 minecraft:purple_concrete
fill 264 280 440 275 282 440 minecraft:obsidian
fill 264 280 448 265 284 448 minecraft:purple_concrete
fill 264 280 453 271 285 453 minecraft:obsidian
fill 264 280 454 265 285 454 minecraft:purple_concrete
fill 265 280 420 276 280 420 minecraft:black_concrete
fill 265 280 435 265 283 435 minecraft:purple_concrete
fill 265 280 436 270 283 436 minecraft:obsidian
fill 266 280 434 266 283 434 minecraft:purple_concrete
fill 266 280 435 271 283 435 minecraft:obsidian
fill 266 280 448 274 284 448 minecraft:obsidian
fill 266 280 454 270 286 454 minecraft:obsidian
fill 267 280 421 276 280 421 minecraft:black_concrete
fill 267 280 422 268 286 422 minecraft:obsidian
fill 267 280 432 267 284 432 minecraft:purple_concrete
fill 267 280 434 276 284 434 minecraft:obsidian
fill 267 280 455 268 286 455 minecraft:purple_concrete
fill 267 280 457 276 280 457 minecraft:black_concrete
fill 268 280 416 268 282 416 minecraft:black_concrete
fill 268 280 430 268 285 430 minecraft:purple_concrete
fill 268 280 432 273 284 432 minecraft:obsidian
fill 268 280 437 269 284 437 minecraft:obsidian
fill 268 280 438 268 284 438 minecraft:purple_concrete
fill 268 280 439 276 284 439 minecraft:obsidian
fill 269 280 422 276 280 422 minecraft:black_concrete
fill 269 280 423 269 286 427 minecraft:purple_concrete
fill 269 280 428 273 285 430 minecraft:obsidian
fill 269 280 438 276 284 438 minecraft:obsidian
fill 269 280 443 270 284 443 minecraft:purple_concrete
fill 269 280 449 271 285 449 minecraft:purple_concrete
fill 269 280 455 269 286 455 minecraft:obsidian
fill 269 280 456 276 280 456 minecraft:black_concrete
fill 270 280 423 276 280 423 minecraft:black_concrete
fill 270 280 424 270 286 427 minecraft:obsidian
fill 270 280 437 270 284 437 minecraft:purple_concrete
fill 270 280 455 276 280 455 minecraft:black_concrete
fill 271 280 424 276 280 424 minecraft:black_concrete
schedule function dropper:buildpart/101_2 1t
