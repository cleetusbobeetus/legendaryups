setblock 87 35 595 minecraft:cobbled_deepslate
setblock 87 35 596 minecraft:calcite
fill 87 35 597 87 38 597 minecraft:cobbled_deepslate
setblock 88 35 560 minecraft:calcite
fill 88 35 561 88 38 561 minecraft:cobbled_deepslate
setblock 88 35 565 minecraft:calcite
fill 88 35 566 88 38 566 minecraft:cobbled_deepslate
setblock 88 35 570 minecraft:calcite
fill 88 35 571 88 38 571 minecraft:cobbled_deepslate
setblock 88 35 575 minecraft:calcite
fill 88 35 576 88 38 576 minecraft:cobbled_deepslate
setblock 88 35 580 minecraft:calcite
fill 88 35 581 88 38 581 minecraft:cobbled_deepslate
setblock 88 35 585 minecraft:calcite
fill 88 35 586 88 37 586 minecraft:cobbled_deepslate
setblock 88 35 590 minecraft:calcite
fill 88 35 591 88 38 591 minecraft:cobbled_deepslate
setblock 88 35 595 minecraft:calcite
fill 88 35 596 88 38 596 minecraft:cobbled_deepslate
setblock 48 36 558 minecraft:cobbled_deepslate
setblock 48 36 559 minecraft:calcite
fill 48 36 560 48 36 563 minecraft:cobbled_deepslate
setblock 48 36 564 minecraft:calcite
fill 48 36 565 48 39 565 minecraft:cobbled_deepslate
setblock 48 36 569 minecraft:calcite
fill 48 36 570 48 39 570 minecraft:cobbled_deepslate
setblock 48 36 574 minecraft:calcite
fill 48 36 575 48 39 575 minecraft:cobbled_deepslate
setblock 48 36 579 minecraft:calcite
fill 48 36 580 48 39 580 minecraft:cobbled_deepslate
setblock 48 36 589 minecraft:calcite
fill 48 36 590 48 38 590 minecraft:cobbled_deepslate
setblock 48 36 594 minecraft:calcite
fill 48 36 595 48 39 595 minecraft:cobbled_deepslate
setblock 49 36 558 minecraft:calcite
fill 49 36 559 49 36 562 minecraft:cobbled_deepslate
setblock 49 36 563 minecraft:calcite
fill 49 36 564 49 37 564 minecraft:cobbled_deepslate
setblock 49 36 568 minecraft:calcite
fill 49 36 569 49 38 569 minecraft:cobbled_deepslate
setblock 49 36 573 minecraft:calcite
fill 49 36 574 49 39 574 minecraft:cobbled_deepslate
setblock 49 36 578 minecraft:calcite
setblock 49 36 593 minecraft:calcite
fill 49 36 594 49 39 594 minecraft:cobbled_deepslate
setblock 49 36 598 minecraft:calcite
fill 50 36 558 50 39 558 minecraft:cobbled_deepslate
setblock 50 36 560 minecraft:light[level=14]
setblock 50 36 568 minecraft:light[level=14]
setblock 50 36 572 minecraft:calcite
setblock 50 36 573 minecraft:cobbled_deepslate
setblock 50 36 576 minecraft:light[level=14]
setblock 50 36 584 minecraft:light[level=14]
setblock 50 36 592 minecraft:light[level=14]
setblock 50 36 597 minecraft:calcite
fill 50 36 598 50 39 598 minecraft:cobbled_deepslate
setblock 51 36 596 minecraft:calcite
fill 51 36 597 51 39 597 minecraft:cobbled_deepslate
setblock 52 36 596 minecraft:cobbled_deepslate
setblock 54 36 558 minecraft:calcite
setblock 54 36 597 minecraft:cobbled_deepslate
setblock 54 36 598 minecraft:calcite
fill 55 36 558 58 36 558 minecraft:cobbled_deepslate
setblock 55 36 597 minecraft:calcite
fill 55 36 598 58 36 598 minecraft:cobbled_deepslate
fill 56 36 597 59 36 597 minecraft:cobbled_deepslate
fill 57 36 596 60 36 596 minecraft:cobbled_deepslate
setblock 58 36 560 minecraft:light[level=14]
setblock 58 36 568 minecraft:light[level=14]
setblock 58 36 576 minecraft:light[level=14]
setblock 58 36 584 minecraft:light[level=14]
setblock 58 36 592 minecraft:light[level=14]
setblock 59 36 558 minecraft:calcite
setblock 59 36 598 minecraft:calcite
fill 60 36 558 60 39 558 minecraft:cobbled_deepslate
fill 60 36 595 61 36 595 minecraft:cobbled_deepslate
setblock 60 36 597 minecraft:calcite
fill 60 36 598 63 36 598 minecraft:cobbled_deepslate
setblock 61 36 596 minecraft:calcite
fill 61 36 597 61 39 597 minecraft:cobbled_deepslate
setblock 62 36 559 minecraft:cobbled_deepslate
setblock 62 36 595 minecraft:calcite
fill 62 36 596 62 39 596 minecraft:cobbled_deepslate
setblock 63 36 559 minecraft:calcite
fill 63 36 595 63 39 595 minecraft:cobbled_deepslate
setblock 64 36 558 minecraft:calcite
fill 64 36 559 64 39 559 minecraft:cobbled_deepslate
fill 64 36 594 64 37 594 minecraft:cobbled_deepslate
setblock 64 36 598 minecraft:calcite
fill 65 36 558 65 39 558 minecraft:cobbled_deepslate
setblock 65 36 597 minecraft:calcite
fill 65 36 598 65 39 598 minecraft:cobbled_deepslate
setblock 66 36 560 minecraft:light[level=14]
setblock 66 36 568 minecraft:light[level=14]
setblock 66 36 576 minecraft:light[level=14]
setblock 66 36 584 minecraft:light[level=14]
setblock 66 36 592 minecraft:light[level=14]
setblock 66 36 596 minecraft:calcite
fill 66 36 597 66 39 597 minecraft:cobbled_deepslate
setblock 67 36 559 minecraft:cobbled_deepslate
setblock 67 36 594 minecraft:cobbled_deepslate
setblock 67 36 595 minecraft:calcite
fill 67 36 596 67 39 596 minecraft:cobbled_deepslate
fill 68 36 595 68 38 595 minecraft:cobbled_deepslate
setblock 69 36 558 minecraft:calcite
setblock 69 36 598 minecraft:calcite
fill 70 36 558 70 38 558 minecraft:cobbled_deepslate
setblock 70 36 597 minecraft:calcite
fill 70 36 598 70 39 598 minecraft:cobbled_deepslate
setblock 71 36 596 minecraft:calcite
fill 71 36 597 71 39 597 minecraft:cobbled_deepslate
setblock 72 36 596 minecraft:cobbled_deepslate
setblock 74 36 560 minecraft:light[level=14]
setblock 74 36 568 minecraft:light[level=14]
setblock 74 36 576 minecraft:light[level=14]
setblock 74 36 584 minecraft:light[level=14]
setblock 74 36 592 minecraft:light[level=14]
setblock 74 36 598 minecraft:calcite
fill 75 36 598 75 38 598 minecraft:cobbled_deepslate
fill 77 36 598 78 36 598 minecraft:cobbled_deepslate
setblock 79 36 598 minecraft:calcite
fill 80 36 598 83 36 598 minecraft:cobbled_deepslate
fill 81 36 558 83 36 558 minecraft:cobbled_deepslate
fill 81 36 597 84 36 597 minecraft:cobbled_deepslate
setblock 82 36 560 minecraft:light[level=14]
setblock 82 36 568 minecraft:light[level=14]
setblock 82 36 576 minecraft:light[level=14]
setblock 82 36 584 minecraft:light[level=14]
setblock 82 36 592 minecraft:light[level=14]
setblock 84 36 558 minecraft:calcite
fill 84 36 559 84 39 559 minecraft:cobbled_deepslate
setblock 84 36 572 minecraft:cobbled_deepslate
setblock 84 36 573 minecraft:calcite
fill 84 36 574 84 38 575 minecraft:cobbled_deepslate
fill 84 36 596 85 36 596 minecraft:cobbled_deepslate
setblock 84 36 598 minecraft:calcite
fill 85 36 558 85 39 558 minecraft:cobbled_deepslate
setblock 85 36 568 minecraft:cobbled_deepslate
setblock 85 36 572 minecraft:calcite
fill 85 36 573 85 39 573 minecraft:cobbled_deepslate
fill 85 36 575 85 36 576 minecraft:cobbled_deepslate
setblock 85 36 577 minecraft:calcite
fill 85 36 578 85 39 578 minecraft:cobbled_deepslate
setblock 85 36 597 minecraft:calcite
fill 85 36 598 85 39 598 minecraft:cobbled_deepslate
setblock 86 36 566 minecraft:calcite
fill 86 36 567 86 38 567 minecraft:cobbled_deepslate
setblock 86 36 571 minecraft:calcite
fill 86 36 572 86 39 572 minecraft:cobbled_deepslate
setblock 86 36 576 minecraft:calcite
fill 86 36 577 86 39 577 minecraft:cobbled_deepslate
setblock 86 36 580 minecraft:cobbled_deepslate
setblock 86 36 581 minecraft:calcite
setblock 86 36 596 minecraft:calcite
fill 86 36 597 86 39 597 minecraft:cobbled_deepslate
setblock 87 36 560 minecraft:calcite
fill 87 36 561 87 39 561 minecraft:cobbled_deepslate
setblock 87 36 565 minecraft:calcite
fill 87 36 566 87 39 566 minecraft:cobbled_deepslate
setblock 87 36 570 minecraft:calcite
fill 87 36 571 87 39 571 minecraft:cobbled_deepslate
setblock 87 36 575 minecraft:calcite
fill 87 36 576 87 39 576 minecraft:cobbled_deepslate
setblock 87 36 580 minecraft:calcite
fill 87 36 581 87 39 581 minecraft:cobbled_deepslate
setblock 87 36 590 minecraft:calcite
fill 87 36 591 87 37 591 minecraft:cobbled_deepslate
setblock 87 36 595 minecraft:calcite
fill 87 36 596 87 39 596 minecraft:cobbled_deepslate
setblock 88 36 559 minecraft:calcite
fill 88 36 560 88 39 560 minecraft:cobbled_deepslate
setblock 88 36 564 minecraft:calcite
fill 88 36 565 88 39 565 minecraft:cobbled_deepslate
setblock 88 36 569 minecraft:calcite
fill 88 36 570 88 39 570 minecraft:cobbled_deepslate
setblock 88 36 574 minecraft:calcite
fill 88 36 575 88 39 575 minecraft:cobbled_deepslate
setblock 88 36 579 minecraft:calcite
fill 88 36 580 88 39 580 minecraft:cobbled_deepslate
setblock 88 36 584 minecraft:calcite
fill 88 36 585 88 37 585 minecraft:cobbled_deepslate
setblock 88 36 589 minecraft:calcite
fill 88 36 590 88 38 590 minecraft:cobbled_deepslate
setblock 88 36 594 minecraft:calcite
fill 88 36 595 88 39 595 minecraft:cobbled_deepslate
setblock 48 37 558 minecraft:calcite
fill 48 37 559 48 37 562 minecraft:cobbled_deepslate
setblock 48 37 563 minecraft:calcite
fill 48 37 564 48 40 564 minecraft:cobbled_deepslate
setblock 48 37 568 minecraft:calcite
fill 48 37 569 48 40 569 minecraft:cobbled_deepslate
setblock 48 37 573 minecraft:calcite
fill 48 37 574 48 40 574 minecraft:cobbled_deepslate
setblock 48 37 578 minecraft:calcite
fill 48 37 579 48 40 579 minecraft:cobbled_deepslate
setblock 48 37 589 minecraft:cobbled_deepslate
setblock 48 37 593 minecraft:calcite
fill 48 37 594 48 40 594 minecraft:cobbled_deepslate
setblock 48 37 598 minecraft:calcite
fill 49 37 558 49 37 561 minecraft:cobbled_deepslate
setblock 49 37 562 minecraft:calcite
setblock 49 37 563 minecraft:cobbled_deepslate
setblock 49 37 567 minecraft:calcite
fill 49 37 568 49 38 568 minecraft:cobbled_deepslate
setblock 49 37 572 minecraft:calcite
fill 49 37 573 49 39 573 minecraft:cobbled_deepslate
setblock 49 37 577 minecraft:calcite
setblock 49 37 578 minecraft:cobbled_deepslate
setblock 49 37 592 minecraft:calcite
fill 49 37 593 49 38 593 minecraft:cobbled_deepslate
setblock 49 37 597 minecraft:calcite
fill 49 37 598 49 40 598 minecraft:cobbled_deepslate
setblock 50 37 596 minecraft:calcite
fill 50 37 597 50 40 597 minecraft:cobbled_deepslate
setblock 51 37 596 minecraft:cobbled_deepslate
setblock 52 37 559 minecraft:calcite
setblock 53 37 558 minecraft:calcite
setblock 53 37 598 minecraft:calcite
fill 54 37 558 57 37 558 minecraft:cobbled_deepslate
setblock 54 37 597 minecraft:calcite
fill 54 37 598 57 37 598 minecraft:cobbled_deepslate
fill 55 37 597 58 37 597 minecraft:cobbled_deepslate
fill 57 37 596 59 37 596 minecraft:cobbled_deepslate
setblock 58 37 558 minecraft:calcite
setblock 58 37 598 minecraft:calcite
fill 59 37 558 59 40 558 minecraft:cobbled_deepslate
setblock 59 37 597 minecraft:calcite
fill 59 37 598 62 37 598 minecraft:cobbled_deepslate
setblock 60 37 595 minecraft:cobbled_deepslate
setblock 60 37 596 minecraft:calcite
fill 60 37 597 60 40 597 minecraft:cobbled_deepslate
setblock 61 37 559 minecraft:cobbled_deepslate
setblock 61 37 595 minecraft:calcite
fill 61 37 596 61 40 596 minecraft:cobbled_deepslate
setblock 62 37 559 minecraft:calcite
fill 62 37 595 62 40 595 minecraft:cobbled_deepslate
setblock 63 37 558 minecraft:calcite
fill 63 37 559 63 40 559 minecraft:cobbled_deepslate
setblock 63 37 598 minecraft:calcite
fill 64 37 558 64 40 558 minecraft:cobbled_deepslate
setblock 64 37 597 minecraft:calcite
fill 64 37 598 64 40 598 minecraft:cobbled_deepslate
setblock 65 37 596 minecraft:calcite
fill 65 37 597 65 40 597 minecraft:cobbled_deepslate
setblock 66 37 595 minecraft:calcite
fill 66 37 596 66 40 596 minecraft:cobbled_deepslate
fill 67 37 595 67 38 595 minecraft:cobbled_deepslate
setblock 68 37 558 minecraft:calcite
setblock 68 37 598 minecraft:calcite
fill 69 37 558 69 39 558 minecraft:cobbled_deepslate
setblock 69 37 597 minecraft:calcite
fill 69 37 598 69 40 598 minecraft:cobbled_deepslate
setblock 70 37 596 minecraft:calcite
fill 70 37 597 70 40 597 minecraft:cobbled_deepslate
setblock 71 37 596 minecraft:cobbled_deepslate
setblock 73 37 597 minecraft:cobbled_deepslate
setblock 73 37 598 minecraft:calcite
fill 74 37 598 74 39 598 minecraft:cobbled_deepslate
setblock 77 37 598 minecraft:cobbled_deepslate
setblock 78 37 598 minecraft:calcite
fill 79 37 598 82 37 598 minecraft:cobbled_deepslate
fill 80 37 558 82 37 558 minecraft:cobbled_deepslate
fill 80 37 597 83 37 597 minecraft:cobbled_deepslate
setblock 83 37 558 minecraft:calcite
fill 83 37 559 83 40 559 minecraft:cobbled_deepslate
setblock 83 37 598 minecraft:calcite
fill 84 37 558 84 40 558 minecraft:cobbled_deepslate
setblock 84 37 572 minecraft:calcite
setblock 84 37 573 minecraft:cobbled_deepslate
setblock 84 37 576 minecraft:cobbled_deepslate
setblock 84 37 596 minecraft:cobbled_deepslate
setblock 84 37 597 minecraft:calcite
fill 84 37 598 84 40 598 minecraft:cobbled_deepslate
fill 85 37 559 86 37 559 minecraft:cobbled_deepslate
setblock 85 37 571 minecraft:calcite
fill 85 37 572 85 39 572 minecraft:cobbled_deepslate
setblock 85 37 575 minecraft:cobbled_deepslate
setblock 85 37 576 minecraft:calcite
fill 85 37 577 85 40 577 minecraft:cobbled_deepslate
fill 85 37 579 85 38 579 minecraft:cobbled_deepslate
setblock 85 37 596 minecraft:calcite
fill 85 37 597 85 40 597 minecraft:cobbled_deepslate
setblock 86 37 566 minecraft:cobbled_deepslate
setblock 86 37 570 minecraft:calcite
fill 86 37 571 86 40 571 minecraft:cobbled_deepslate
setblock 86 37 575 minecraft:calcite
fill 86 37 576 86 40 576 minecraft:cobbled_deepslate
setblock 86 37 580 minecraft:calcite
setblock 86 37 581 minecraft:cobbled_deepslate
setblock 86 37 595 minecraft:calcite
setblock 86 37 596 minecraft:cobbled_deepslate
setblock 87 37 559 minecraft:calcite
fill 87 37 560 87 40 560 minecraft:cobbled_deepslate
setblock 87 37 564 minecraft:calcite
fill 87 37 565 87 39 565 minecraft:cobbled_deepslate
setblock 87 37 569 minecraft:calcite
fill 87 37 570 87 40 570 minecraft:cobbled_deepslate
setblock 87 37 574 minecraft:calcite
fill 87 37 575 87 40 575 minecraft:cobbled_deepslate
setblock 87 37 579 minecraft:calcite
fill 87 37 580 87 40 580 minecraft:cobbled_deepslate
setblock 87 37 594 minecraft:calcite
fill 87 37 595 87 39 595 minecraft:cobbled_deepslate
setblock 88 37 558 minecraft:calcite
fill 88 37 559 88 40 559 minecraft:cobbled_deepslate
setblock 88 37 563 minecraft:calcite
fill 88 37 564 88 40 564 minecraft:cobbled_deepslate
setblock 88 37 568 minecraft:calcite
fill 88 37 569 88 40 569 minecraft:cobbled_deepslate
setblock 88 37 573 minecraft:calcite
fill 88 37 574 88 40 574 minecraft:cobbled_deepslate
setblock 88 37 578 minecraft:calcite
fill 88 37 579 88 40 579 minecraft:cobbled_deepslate
setblock 88 37 583 minecraft:calcite
fill 88 37 584 88 38 584 minecraft:cobbled_deepslate
setblock 88 37 588 minecraft:calcite
setblock 88 37 589 minecraft:cobbled_deepslate
setblock 88 37 593 minecraft:calcite
fill 88 37 594 88 40 594 minecraft:cobbled_deepslate
setblock 88 37 598 minecraft:calcite
fill 48 38 558 48 38 561 minecraft:cobbled_deepslate
setblock 48 38 562 minecraft:calcite
fill 48 38 563 48 41 563 minecraft:cobbled_deepslate
setblock 48 38 567 minecraft:calcite
fill 48 38 568 48 40 568 minecraft:cobbled_deepslate
setblock 48 38 572 minecraft:calcite
fill 48 38 573 48 41 573 minecraft:cobbled_deepslate
setblock 48 38 577 minecraft:calcite
fill 48 38 578 48 41 578 minecraft:cobbled_deepslate
setblock 48 38 592 minecraft:calcite
fill 48 38 593 48 40 593 minecraft:cobbled_deepslate
setblock 48 38 597 minecraft:calcite
fill 48 38 598 48 41 598 minecraft:cobbled_deepslate
fill 49 38 558 49 38 560 minecraft:cobbled_deepslate
setblock 49 38 561 minecraft:calcite
setblock 49 38 562 minecraft:cobbled_deepslate
setblock 49 38 571 minecraft:calcite
setblock 49 38 572 minecraft:cobbled_deepslate
setblock 49 38 576 minecraft:calcite
setblock 49 38 577 minecraft:cobbled_deepslate
setblock 49 38 596 minecraft:calcite
fill 49 38 597 49 41 597 minecraft:cobbled_deepslate
setblock 50 38 596 minecraft:cobbled_deepslate
setblock 51 38 559 minecraft:calcite
setblock 52 38 558 minecraft:calcite
setblock 52 38 559 minecraft:cobbled_deepslate
setblock 52 38 598 minecraft:calcite
fill 53 38 558 56 38 558 minecraft:cobbled_deepslate
setblock 53 38 597 minecraft:calcite
fill 53 38 598 56 38 598 minecraft:cobbled_deepslate
fill 54 38 597 57 38 597 minecraft:cobbled_deepslate
fill 55 38 573 58 99 574 minecraft:calcite
fill 56 38 572 57 99 572 minecraft:calcite
fill 56 38 575 58 99 575 minecraft:calcite
setblock 57 38 558 minecraft:calcite
fill 57 38 596 58 38 596 minecraft:cobbled_deepslate
setblock 57 38 598 minecraft:calcite
fill 58 38 558 58 41 558 minecraft:cobbled_deepslate
setblock 58 38 597 minecraft:calcite
fill 58 38 598 61 38 598 minecraft:cobbled_deepslate
setblock 59 38 596 minecraft:calcite
fill 59 38 597 59 41 597 minecraft:cobbled_deepslate
setblock 60 38 559 minecraft:cobbled_deepslate
setblock 60 38 595 minecraft:calcite
fill 60 38 596 60 41 596 minecraft:cobbled_deepslate
setblock 61 38 559 minecraft:calcite
fill 61 38 595 61 39 595 minecraft:cobbled_deepslate
setblock 62 38 558 minecraft:calcite
fill 62 38 559 62 41 559 minecraft:cobbled_deepslate
setblock 62 38 598 minecraft:calcite
fill 63 38 558 63 41 558 minecraft:cobbled_deepslate
setblock 63 38 597 minecraft:calcite
fill 63 38 598 63 41 598 minecraft:cobbled_deepslate
setblock 64 38 596 minecraft:calcite
fill 64 38 597 64 41 597 minecraft:cobbled_deepslate
setblock 65 38 559 minecraft:cobbled_deepslate
setblock 65 38 595 minecraft:calcite
fill 65 38 596 65 41 596 minecraft:cobbled_deepslate
setblock 66 38 559 minecraft:calcite
fill 66 38 595 66 39 595 minecraft:cobbled_deepslate
setblock 67 38 558 minecraft:calcite
setblock 67 38 598 minecraft:calcite
fill 68 38 558 68 41 558 minecraft:cobbled_deepslate
setblock 68 38 597 minecraft:calcite
fill 68 38 598 68 41 598 minecraft:cobbled_deepslate
setblock 69 38 596 minecraft:calcite
fill 69 38 597 69 40 597 minecraft:cobbled_deepslate
setblock 70 38 596 minecraft:cobbled_deepslate
setblock 72 38 598 minecraft:calcite
fill 73 38 598 73 39 598 minecraft:cobbled_deepslate
setblock 77 38 598 minecraft:calcite
fill 78 38 598 81 38 598 minecraft:cobbled_deepslate
fill 80 38 558 81 38 558 minecraft:cobbled_deepslate
fill 80 38 597 82 38 597 minecraft:cobbled_deepslate
setblock 82 38 558 minecraft:calcite
fill 82 38 559 82 41 559 minecraft:cobbled_deepslate
setblock 82 38 598 minecraft:calcite
fill 83 38 558 83 41 558 minecraft:cobbled_deepslate
setblock 83 38 597 minecraft:calcite
fill 83 38 598 83 41 598 minecraft:cobbled_deepslate
fill 84 38 597 84 41 597 minecraft:cobbled_deepslate
setblock 85 38 559 minecraft:cobbled_deepslate
setblock 85 38 570 minecraft:calcite
fill 85 38 571 85 39 571 minecraft:cobbled_deepslate
setblock 85 38 575 minecraft:calcite
fill 85 38 576 85 40 576 minecraft:cobbled_deepslate
setblock 86 38 558 minecraft:cobbled_deepslate
setblock 86 38 559 minecraft:calcite
setblock 86 38 569 minecraft:calcite
fill 86 38 570 86 40 570 minecraft:cobbled_deepslate
setblock 86 38 574 minecraft:calcite
fill 86 38 575 86 41 575 minecraft:cobbled_deepslate
setblock 86 38 579 minecraft:calcite
fill 86 38 580 86 39 580 minecraft:cobbled_deepslate
setblock 87 38 558 minecraft:calcite
fill 87 38 559 87 41 559 minecraft:cobbled_deepslate
setblock 87 38 563 minecraft:calcite
fill 87 38 564 87 40 564 minecraft:cobbled_deepslate
setblock 87 38 568 minecraft:calcite
fill 87 38 569 87 40 569 minecraft:cobbled_deepslate
setblock 87 38 573 minecraft:calcite
fill 87 38 574 87 41 574 minecraft:cobbled_deepslate
setblock 87 38 578 minecraft:calcite
fill 87 38 579 87 41 579 minecraft:cobbled_deepslate
setblock 87 38 593 minecraft:calcite
setblock 87 38 594 minecraft:cobbled_deepslate
setblock 87 38 598 minecraft:calcite
fill 88 38 558 88 41 558 minecraft:cobbled_deepslate
setblock 88 38 562 minecraft:calcite
fill 88 38 563 88 41 563 minecraft:cobbled_deepslate
setblock 88 38 567 minecraft:calcite
fill 88 38 568 88 41 568 minecraft:cobbled_deepslate
setblock 88 38 572 minecraft:calcite
fill 88 38 573 88 41 573 minecraft:cobbled_deepslate
setblock 88 38 577 minecraft:calcite
fill 88 38 578 88 41 578 minecraft:cobbled_deepslate
setblock 88 38 582 minecraft:calcite
fill 88 38 583 88 39 583 minecraft:cobbled_deepslate
setblock 88 38 592 minecraft:calcite
fill 88 38 593 88 39 593 minecraft:cobbled_deepslate
setblock 88 38 597 minecraft:calcite
fill 88 38 598 88 41 598 minecraft:cobbled_deepslate
fill 48 39 558 48 39 560 minecraft:cobbled_deepslate
setblock 48 39 561 minecraft:calcite
fill 48 39 562 48 42 562 minecraft:cobbled_deepslate
setblock 48 39 566 minecraft:calcite
fill 48 39 567 48 40 567 minecraft:cobbled_deepslate
setblock 48 39 571 minecraft:calcite
fill 48 39 572 48 40 572 minecraft:cobbled_deepslate
setblock 48 39 576 minecraft:calcite
fill 48 39 577 48 41 577 minecraft:cobbled_deepslate
setblock 48 39 591 minecraft:calcite
setblock 48 39 592 minecraft:cobbled_deepslate
setblock 48 39 596 minecraft:calcite
fill 48 39 597 48 42 597 minecraft:cobbled_deepslate
fill 49 39 558 49 39 559 minecraft:cobbled_deepslate
setblock 49 39 560 minecraft:calcite
setblock 49 39 561 minecraft:cobbled_deepslate
setblock 49 39 575 minecraft:calcite
setblock 49 39 576 minecraft:cobbled_deepslate
setblock 49 39 595 minecraft:calcite
fill 49 39 596 49 41 596 minecraft:cobbled_deepslate
setblock 50 39 559 minecraft:calcite
setblock 51 39 558 minecraft:calcite
setblock 51 39 559 minecraft:cobbled_deepslate
setblock 51 39 598 minecraft:calcite
fill 52 39 558 55 39 558 minecraft:cobbled_deepslate
setblock 52 39 597 minecraft:calcite
fill 52 39 598 55 39 598 minecraft:cobbled_deepslate
fill 53 39 597 56 39 597 minecraft:cobbled_deepslate
fill 54 39 573 54 40 574 minecraft:deepslate
fill 55 39 572 55 40 572 minecraft:deepslate
fill 55 39 575 55 40 576 minecraft:deepslate
setblock 56 39 558 minecraft:calcite
fill 56 39 576 58 40 576 minecraft:deepslate
setblock 56 39 598 minecraft:calcite
fill 57 39 558 57 42 558 minecraft:cobbled_deepslate
setblock 57 39 596 minecraft:cobbled_deepslate
setblock 57 39 597 minecraft:calcite
fill 57 39 598 60 39 598 minecraft:cobbled_deepslate
fill 58 39 572 58 40 572 minecraft:deepslate
setblock 58 39 596 minecraft:calcite
fill 58 39 597 58 42 597 minecraft:cobbled_deepslate
fill 59 39 573 59 40 575 minecraft:deepslate
fill 59 39 596 59 42 596 minecraft:cobbled_deepslate
setblock 60 39 559 minecraft:calcite
setblock 61 39 558 minecraft:calcite
fill 61 39 559 61 42 559 minecraft:cobbled_deepslate
setblock 61 39 598 minecraft:calcite
fill 62 39 558 62 42 558 minecraft:cobbled_deepslate
setblock 62 39 597 minecraft:calcite
fill 62 39 598 62 42 598 minecraft:cobbled_deepslate
setblock 63 39 596 minecraft:calcite
fill 63 39 597 63 42 597 minecraft:cobbled_deepslate
setblock 64 39 595 minecraft:calcite
fill 64 39 596 64 42 596 minecraft:cobbled_deepslate
setblock 65 39 559 minecraft:calcite
setblock 65 39 595 minecraft:cobbled_deepslate
setblock 66 39 558 minecraft:calcite
setblock 66 39 598 minecraft:calcite
fill 67 39 558 67 42 558 minecraft:cobbled_deepslate
setblock 67 39 597 minecraft:calcite
fill 67 39 598 67 42 598 minecraft:cobbled_deepslate
setblock 68 39 596 minecraft:calcite
fill 68 39 597 68 41 597 minecraft:cobbled_deepslate
setblock 69 39 596 minecraft:cobbled_deepslate
setblock 71 39 598 minecraft:calcite
fill 72 39 598 72 40 598 minecraft:cobbled_deepslate
fill 77 39 598 80 39 598 minecraft:cobbled_deepslate
fill 79 39 558 80 39 558 minecraft:cobbled_deepslate
setblock 81 39 558 minecraft:calcite
setblock 81 39 597 minecraft:cobbled_deepslate
setblock 81 39 598 minecraft:calcite
fill 82 39 558 82 42 558 minecraft:cobbled_deepslate
setblock 82 39 597 minecraft:calcite
fill 82 39 598 82 42 598 minecraft:cobbled_deepslate
fill 83 39 597 83 41 597 minecraft:cobbled_deepslate
setblock 85 39 559 minecraft:calcite
setblock 85 39 574 minecraft:calcite
fill 85 39 575 85 40 575 minecraft:cobbled_deepslate
setblock 86 39 558 minecraft:calcite
fill 86 39 559 86 42 559 minecraft:cobbled_deepslate
setblock 86 39 568 minecraft:calcite
setblock 86 39 569 minecraft:cobbled_deepslate
setblock 86 39 573 minecraft:calcite
fill 86 39 574 86 41 574 minecraft:cobbled_deepslate
setblock 86 39 578 minecraft:calcite
fill 86 39 579 86 41 579 minecraft:cobbled_deepslate
setblock 86 39 598 minecraft:calcite
fill 87 39 558 87 42 558 minecraft:cobbled_deepslate
setblock 87 39 562 minecraft:calcite
fill 87 39 563 87 40 563 minecraft:cobbled_deepslate
setblock 87 39 567 minecraft:calcite
fill 87 39 568 87 40 568 minecraft:cobbled_deepslate
setblock 87 39 572 minecraft:calcite
fill 87 39 573 87 42 573 minecraft:cobbled_deepslate
setblock 87 39 577 minecraft:calcite
fill 87 39 578 87 42 578 minecraft:cobbled_deepslate
setblock 87 39 597 minecraft:calcite
fill 87 39 598 87 42 598 minecraft:cobbled_deepslate
setblock 88 39 561 minecraft:calcite
fill 88 39 562 88 42 562 minecraft:cobbled_deepslate
setblock 88 39 566 minecraft:calcite
fill 88 39 567 88 42 567 minecraft:cobbled_deepslate
setblock 88 39 571 minecraft:calcite
fill 88 39 572 88 42 572 minecraft:cobbled_deepslate
setblock 88 39 576 minecraft:calcite
fill 88 39 577 88 42 577 minecraft:cobbled_deepslate
setblock 88 39 581 minecraft:calcite
fill 88 39 582 88 41 582 minecraft:cobbled_deepslate
setblock 88 39 592 minecraft:cobbled_deepslate
setblock 88 39 596 minecraft:calcite
fill 88 39 597 88 42 597 minecraft:cobbled_deepslate
fill 48 40 558 48 40 559 minecraft:cobbled_deepslate
setblock 48 40 560 minecraft:calcite
fill 48 40 561 48 43 561 minecraft:cobbled_deepslate
setblock 48 40 565 minecraft:calcite
setblock 48 40 566 minecraft:cobbled_deepslate
setblock 48 40 570 minecraft:calcite
setblock 48 40 571 minecraft:cobbled_deepslate
setblock 48 40 575 minecraft:calcite
fill 48 40 576 48 41 576 minecraft:cobbled_deepslate
setblock 48 40 580 minecraft:calcite
setblock 48 40 595 minecraft:calcite
fill 48 40 596 48 43 596 minecraft:cobbled_deepslate
setblock 49 40 558 minecraft:cobbled_deepslate
setblock 49 40 559 minecraft:calcite
fill 49 40 560 49 41 560 minecraft:cobbled_deepslate
setblock 49 40 595 minecraft:cobbled_deepslate
setblock 50 40 558 minecraft:calcite
fill 50 40 559 50 41 559 minecraft:cobbled_deepslate
setblock 50 40 598 minecraft:calcite
fill 51 40 558 54 40 558 minecraft:cobbled_deepslate
setblock 51 40 597 minecraft:calcite
fill 51 40 598 54 40 598 minecraft:cobbled_deepslate
fill 52 40 597 55 40 597 minecraft:cobbled_deepslate
setblock 54 40 572 minecraft:deepslate
fill 54 40 575 54 40 576 minecraft:deepslate
setblock 55 40 558 minecraft:calcite
fill 55 40 571 58 40 571 minecraft:deepslate
setblock 55 40 598 minecraft:calcite
fill 56 40 558 56 43 558 minecraft:cobbled_deepslate
fill 56 40 577 57 40 577 minecraft:deepslate
setblock 56 40 597 minecraft:calcite
fill 56 40 598 59 40 598 minecraft:cobbled_deepslate
fill 57 40 597 57 43 597 minecraft:cobbled_deepslate
fill 58 40 596 58 41 596 minecraft:cobbled_deepslate
setblock 59 40 559 minecraft:calcite
setblock 59 40 572 minecraft:deepslate
setblock 59 40 576 minecraft:deepslate
setblock 60 40 558 minecraft:calcite
fill 60 40 559 60 43 559 minecraft:cobbled_deepslate
setblock 60 40 574 minecraft:deepslate
setblock 60 40 598 minecraft:calcite
fill 61 40 558 61 43 558 minecraft:cobbled_deepslate
setblock 61 40 597 minecraft:calcite
fill 61 40 598 61 43 598 minecraft:cobbled_deepslate
setblock 62 40 596 minecraft:calcite
fill 62 40 597 62 43 597 minecraft:cobbled_deepslate
setblock 63 40 595 minecraft:calcite
fill 63 40 596 63 43 596 minecraft:cobbled_deepslate
setblock 64 40 559 minecraft:calcite
setblock 64 40 595 minecraft:cobbled_deepslate
setblock 65 40 558 minecraft:calcite
setblock 65 40 559 minecraft:cobbled_deepslate
setblock 65 40 598 minecraft:calcite
fill 66 40 558 66 43 558 minecraft:cobbled_deepslate
setblock 66 40 597 minecraft:calcite
fill 66 40 598 66 43 598 minecraft:cobbled_deepslate
setblock 67 40 596 minecraft:calcite
fill 67 40 597 67 42 597 minecraft:cobbled_deepslate
setblock 70 40 598 minecraft:calcite
fill 71 40 598 71 41 598 minecraft:cobbled_deepslate
fill 77 40 598 79 40 598 minecraft:cobbled_deepslate
setblock 79 40 558 minecraft:cobbled_deepslate
setblock 80 40 558 minecraft:calcite
setblock 80 40 598 minecraft:calcite
fill 81 40 558 81 42 559 minecraft:cobbled_deepslate
setblock 81 40 597 minecraft:calcite
fill 81 40 598 81 43 598 minecraft:cobbled_deepslate
fill 82 40 597 82 41 597 minecraft:cobbled_deepslate
setblock 84 40 559 minecraft:calcite
setblock 85 40 558 minecraft:calcite
fill 85 40 559 85 43 559 minecraft:cobbled_deepslate
setblock 85 40 573 minecraft:calcite
setblock 85 40 574 minecraft:cobbled_deepslate
setblock 85 40 598 minecraft:calcite
fill 86 40 558 86 43 558 minecraft:cobbled_deepslate
setblock 86 40 572 minecraft:calcite
fill 86 40 573 86 41 573 minecraft:cobbled_deepslate
setblock 86 40 577 minecraft:calcite
fill 86 40 578 86 42 578 minecraft:cobbled_deepslate
setblock 86 40 597 minecraft:calcite
fill 86 40 598 86 43 598 minecraft:cobbled_deepslate
setblock 87 40 561 minecraft:calcite
fill 87 40 562 87 43 562 minecraft:cobbled_deepslate
setblock 87 40 566 minecraft:calcite
setblock 87 40 567 minecraft:cobbled_deepslate
setblock 87 40 571 minecraft:calcite
fill 87 40 572 87 42 572 minecraft:cobbled_deepslate
setblock 87 40 576 minecraft:calcite
fill 87 40 577 87 43 577 minecraft:cobbled_deepslate
setblock 87 40 581 minecraft:calcite
setblock 87 40 596 minecraft:calcite
setblock 87 40 597 minecraft:cobbled_deepslate
setblock 88 40 560 minecraft:calcite
fill 88 40 561 88 43 561 minecraft:cobbled_deepslate
setblock 88 40 565 minecraft:calcite
fill 88 40 566 88 42 566 minecraft:cobbled_deepslate
setblock 88 40 570 minecraft:calcite
fill 88 40 571 88 42 571 minecraft:cobbled_deepslate
setblock 88 40 575 minecraft:calcite
fill 88 40 576 88 43 576 minecraft:cobbled_deepslate
setblock 88 40 580 minecraft:calcite
fill 88 40 581 88 43 581 minecraft:cobbled_deepslate
setblock 88 40 595 minecraft:calcite
fill 88 40 596 88 41 596 minecraft:cobbled_deepslate
setblock 48 41 558 minecraft:cobbled_deepslate
setblock 48 41 559 minecraft:calcite
fill 48 41 560 48 44 560 minecraft:cobbled_deepslate
setblock 48 41 564 minecraft:calcite
setblock 48 41 574 minecraft:calcite
setblock 48 41 575 minecraft:cobbled_deepslate
setblock 48 41 579 minecraft:calcite
setblock 48 41 594 minecraft:calcite
fill 48 41 595 48 43 595 minecraft:cobbled_deepslate
setblock 49 41 558 minecraft:calcite
fill 49 41 559 49 44 559 minecraft:cobbled_deepslate
setblock 49 41 598 minecraft:calcite
fill 50 41 558 53 41 558 minecraft:cobbled_deepslate
setblock 50 41 597 minecraft:calcite
fill 50 41 598 53 41 598 minecraft:cobbled_deepslate
setblock 51 41 597 minecraft:cobbled_deepslate
fill 53 41 597 54 41 597 minecraft:cobbled_deepslate
setblock 54 41 558 minecraft:calcite
setblock 54 41 598 minecraft:calcite
fill 55 41 558 55 44 558 minecraft:cobbled_deepslate
setblock 55 41 597 minecraft:calcite
fill 55 41 598 58 41 598 minecraft:cobbled_deepslate
fill 56 41 597 56 44 597 minecraft:cobbled_deepslate
setblock 59 41 558 minecraft:calcite
fill 59 41 559 59 44 559 minecraft:cobbled_deepslate
setblock 59 41 598 minecraft:calcite
fill 60 41 558 60 44 558 minecraft:cobbled_deepslate
setblock 60 41 597 minecraft:calcite
fill 60 41 598 60 44 598 minecraft:cobbled_deepslate
setblock 61 41 596 minecraft:calcite
fill 61 41 597 61 44 597 minecraft:cobbled_deepslate
fill 62 41 596 62 44 596 minecraft:cobbled_deepslate
setblock 63 41 559 minecraft:calcite
setblock 64 41 558 minecraft:calcite
fill 64 41 559 64 44 559 minecraft:cobbled_deepslate
setblock 64 41 598 minecraft:calcite
fill 65 41 558 65 44 558 minecraft:cobbled_deepslate
setblock 65 41 597 minecraft:calcite
fill 65 41 598 65 44 598 minecraft:cobbled_deepslate
setblock 66 41 596 minecraft:calcite
fill 66 41 597 66 43 597 minecraft:cobbled_deepslate
setblock 69 41 598 minecraft:calcite
fill 70 41 598 70 42 598 minecraft:cobbled_deepslate
setblock 78 41 558 minecraft:cobbled_deepslate
setblock 78 41 598 minecraft:cobbled_deepslate
setblock 79 41 558 minecraft:calcite
setblock 79 41 598 minecraft:calcite
fill 80 41 558 80 44 558 minecraft:cobbled_deepslate
fill 80 41 598 80 44 598 minecraft:cobbled_deepslate
setblock 83 41 559 minecraft:calcite
setblock 84 41 558 minecraft:calcite
fill 84 41 559 84 44 559 minecraft:cobbled_deepslate
setblock 84 41 598 minecraft:calcite
fill 85 41 558 85 44 558 minecraft:cobbled_deepslate
setblock 85 41 597 minecraft:calcite
fill 85 41 598 85 44 598 minecraft:cobbled_deepslate
setblock 86 41 572 minecraft:cobbled_deepslate
setblock 86 41 576 minecraft:calcite
fill 86 41 577 86 42 577 minecraft:cobbled_deepslate
setblock 86 41 597 minecraft:cobbled_deepslate
setblock 87 41 560 minecraft:calcite
fill 87 41 561 87 44 561 minecraft:cobbled_deepslate
setblock 87 41 570 minecraft:calcite
setblock 87 41 571 minecraft:cobbled_deepslate
setblock 87 41 575 minecraft:calcite
fill 87 41 576 87 43 576 minecraft:cobbled_deepslate
setblock 87 41 580 minecraft:calcite
setblock 88 41 559 minecraft:calcite
fill 88 41 560 88 44 560 minecraft:cobbled_deepslate
setblock 88 41 564 minecraft:calcite
fill 88 41 565 88 44 565 minecraft:cobbled_deepslate
setblock 88 41 569 minecraft:calcite
fill 88 41 570 88 42 570 minecraft:cobbled_deepslate
setblock 88 41 574 minecraft:calcite
fill 88 41 575 88 44 575 minecraft:cobbled_deepslate
setblock 88 41 579 minecraft:calcite
fill 88 41 580 88 44 580 minecraft:cobbled_deepslate
setblock 48 42 558 minecraft:calcite
fill 48 42 559 48 45 559 minecraft:cobbled_deepslate
setblock 48 42 563 minecraft:calcite
setblock 48 42 598 minecraft:calcite
fill 49 42 558 52 42 558 minecraft:cobbled_deepslate
fill 49 42 598 52 42 598 minecraft:cobbled_deepslate
setblock 53 42 558 minecraft:calcite
setblock 53 42 598 minecraft:calcite
fill 54 42 558 54 45 558 minecraft:cobbled_deepslate
fill 54 42 598 57 42 598 minecraft:cobbled_deepslate
fill 55 42 597 55 45 597 minecraft:cobbled_deepslate
setblock 58 42 558 minecraft:calcite
fill 58 42 559 58 45 559 minecraft:cobbled_deepslate
setblock 58 42 598 minecraft:calcite
fill 59 42 558 59 45 558 minecraft:cobbled_deepslate
setblock 59 42 597 minecraft:calcite
fill 59 42 598 59 45 598 minecraft:cobbled_deepslate
setblock 60 42 596 minecraft:calcite
fill 60 42 597 60 45 597 minecraft:cobbled_deepslate
fill 61 42 596 61 45 596 minecraft:cobbled_deepslate
setblock 62 42 559 minecraft:calcite
setblock 63 42 558 minecraft:calcite
fill 63 42 559 63 45 559 minecraft:cobbled_deepslate
setblock 63 42 598 minecraft:calcite
fill 64 42 558 64 45 558 minecraft:cobbled_deepslate
setblock 64 42 597 minecraft:calcite
fill 64 42 598 64 45 598 minecraft:cobbled_deepslate
setblock 65 42 596 minecraft:calcite
fill 65 42 597 65 45 597 minecraft:cobbled_deepslate
setblock 68 42 598 minecraft:calcite
setblock 69 42 598 minecraft:cobbled_deepslate
setblock 78 42 558 minecraft:calcite
setblock 78 42 598 minecraft:calcite
fill 79 42 558 79 45 558 minecraft:cobbled_deepslate
fill 79 42 598 79 45 598 minecraft:cobbled_deepslate
fill 80 42 559 80 43 559 minecraft:cobbled_deepslate
setblock 82 42 559 minecraft:calcite
setblock 83 42 558 minecraft:calcite
fill 83 42 559 83 45 559 minecraft:cobbled_deepslate
setblock 83 42 598 minecraft:calcite
fill 84 42 558 84 45 558 minecraft:cobbled_deepslate
fill 84 42 598 84 45 598 minecraft:cobbled_deepslate
setblock 86 42 575 minecraft:calcite
setblock 86 42 576 minecraft:cobbled_deepslate
setblock 87 42 559 minecraft:calcite
fill 87 42 560 87 45 560 minecraft:cobbled_deepslate
setblock 87 42 574 minecraft:calcite
fill 87 42 575 87 43 575 minecraft:cobbled_deepslate
setblock 87 42 579 minecraft:calcite
setblock 87 42 580 minecraft:cobbled_deepslate
setblock 88 42 558 minecraft:calcite
fill 88 42 559 88 45 559 minecraft:cobbled_deepslate
setblock 88 42 563 minecraft:calcite
fill 88 42 564 88 45 564 minecraft:cobbled_deepslate
setblock 88 42 568 minecraft:calcite
setblock 88 42 569 minecraft:cobbled_deepslate
setblock 88 42 573 minecraft:calcite
fill 88 42 574 88 44 574 minecraft:cobbled_deepslate
setblock 88 42 578 minecraft:calcite
fill 88 42 579 88 45 579 minecraft:cobbled_deepslate
setblock 88 42 598 minecraft:calcite
fill 48 43 558 51 43 558 minecraft:cobbled_deepslate
setblock 48 43 562 minecraft:calcite
fill 48 43 563 48 46 563 minecraft:cobbled_deepslate
setblock 48 43 597 minecraft:calcite
fill 48 43 598 51 43 598 minecraft:cobbled_deepslate
setblock 52 43 558 minecraft:calcite
setblock 52 43 598 minecraft:calcite
fill 53 43 558 53 46 558 minecraft:cobbled_deepslate
fill 53 43 598 56 43 598 minecraft:cobbled_deepslate
setblock 57 43 558 minecraft:calcite
fill 57 43 559 57 46 559 minecraft:cobbled_deepslate
setblock 57 43 598 minecraft:calcite
fill 58 43 558 58 46 558 minecraft:cobbled_deepslate
setblock 58 43 597 minecraft:calcite
fill 58 43 598 58 46 598 minecraft:cobbled_deepslate
setblock 59 43 596 minecraft:calcite
fill 59 43 597 59 46 597 minecraft:cobbled_deepslate
fill 60 43 596 60 46 596 minecraft:cobbled_deepslate
setblock 61 43 559 minecraft:calcite
setblock 62 43 558 minecraft:calcite
fill 62 43 559 62 46 559 minecraft:cobbled_deepslate
setblock 62 43 598 minecraft:calcite
fill 63 43 558 63 46 558 minecraft:cobbled_deepslate
setblock 63 43 597 minecraft:calcite
fill 63 43 598 63 46 598 minecraft:cobbled_deepslate
fill 64 43 597 64 46 597 minecraft:cobbled_deepslate
setblock 67 43 558 minecraft:calcite
setblock 67 43 598 minecraft:calcite
fill 68 43 598 68 44 598 minecraft:cobbled_deepslate
setblock 77 43 558 minecraft:calcite
fill 78 43 558 78 46 558 minecraft:cobbled_deepslate
fill 78 43 567 78 45 567 minecraft:light_blue_stained_glass
fill 78 43 598 78 46 598 minecraft:cobbled_deepslate
fill 79 43 559 79 44 559 minecraft:cobbled_deepslate
fill 79 43 579 83 99 580 minecraft:calcite
fill 80 43 578 82 99 578 minecraft:calcite
fill 80 43 581 82 99 581 minecraft:calcite
setblock 81 43 558 minecraft:cobbled_deepslate
setblock 81 43 559 minecraft:calcite
setblock 82 43 558 minecraft:calcite
fill 82 43 559 82 45 560 minecraft:cobbled_deepslate
setblock 82 43 598 minecraft:calcite
fill 83 43 558 83 46 558 minecraft:cobbled_deepslate
fill 83 43 560 84 43 560 minecraft:cobbled_deepslate
fill 83 43 598 83 46 598 minecraft:cobbled_deepslate
setblock 85 43 560 minecraft:calcite
setblock 86 43 559 minecraft:calcite
setblock 87 43 558 minecraft:calcite
fill 87 43 559 87 46 559 minecraft:cobbled_deepslate
setblock 87 43 578 minecraft:calcite
setblock 87 43 579 minecraft:cobbled_deepslate
setblock 87 43 598 minecraft:calcite
fill 88 43 558 88 46 558 minecraft:cobbled_deepslate
setblock 88 43 562 minecraft:calcite
fill 88 43 563 88 46 563 minecraft:cobbled_deepslate
setblock 88 43 572 minecraft:calcite
setblock 88 43 573 minecraft:cobbled_deepslate
setblock 88 43 577 minecraft:calcite
fill 88 43 578 88 46 578 minecraft:cobbled_deepslate
fill 88 43 598 88 44 598 minecraft:cobbled_deepslate
fill 48 44 558 50 44 558 minecraft:cobbled_deepslate
setblock 48 44 561 minecraft:calcite
fill 48 44 562 48 47 562 minecraft:cobbled_deepslate
setblock 48 44 596 minecraft:calcite
fill 48 44 597 48 46 598 minecraft:cobbled_deepslate
fill 49 44 598 50 44 598 minecraft:cobbled_deepslate
setblock 50 44 560 minecraft:light[level=14]
setblock 50 44 568 minecraft:light[level=14]
setblock 50 44 576 minecraft:light[level=14]
setblock 50 44 584 minecraft:light[level=14]
setblock 50 44 592 minecraft:light[level=14]
setblock 51 44 558 minecraft:calcite
setblock 51 44 598 minecraft:calcite
fill 52 44 558 52 47 558 minecraft:cobbled_deepslate
fill 52 44 598 55 44 598 minecraft:cobbled_deepslate
setblock 56 44 558 minecraft:calcite
fill 56 44 559 56 47 559 minecraft:cobbled_deepslate
setblock 56 44 598 minecraft:calcite
fill 57 44 558 57 47 558 minecraft:cobbled_deepslate
setblock 57 44 597 minecraft:calcite
fill 57 44 598 57 47 598 minecraft:cobbled_deepslate
setblock 58 44 560 minecraft:light[level=14]
setblock 58 44 568 minecraft:light[level=14]
setblock 58 44 576 minecraft:light[level=14]
setblock 58 44 584 minecraft:light[level=14]
setblock 58 44 592 minecraft:light[level=14]
fill 58 44 597 58 47 597 minecraft:cobbled_deepslate
fill 59 44 596 59 47 596 minecraft:cobbled_deepslate
setblock 60 44 559 minecraft:calcite
setblock 61 44 558 minecraft:calcite
fill 61 44 559 61 47 559 minecraft:cobbled_deepslate
setblock 61 44 598 minecraft:calcite
fill 62 44 558 62 47 558 minecraft:cobbled_deepslate
setblock 62 44 597 minecraft:calcite
fill 62 44 598 62 47 598 minecraft:cobbled_deepslate
fill 63 44 597 63 47 597 minecraft:cobbled_deepslate
setblock 66 44 558 minecraft:calcite
setblock 66 44 560 minecraft:light[level=14]
setblock 66 44 568 minecraft:light[level=14]
setblock 66 44 576 minecraft:light[level=14]
setblock 66 44 584 minecraft:light[level=14]
setblock 66 44 592 minecraft:light[level=14]
setblock 66 44 598 minecraft:calcite
fill 67 44 598 67 45 598 minecraft:cobbled_deepslate
setblock 74 44 560 minecraft:light[level=14]
setblock 74 44 568 minecraft:light[level=14]
setblock 74 44 576 minecraft:light[level=14]
setblock 74 44 584 minecraft:light[level=14]
setblock 74 44 592 minecraft:light[level=14]
setblock 76 44 558 minecraft:calcite
fill 77 44 558 77 47 558 minecraft:cobbled_deepslate
fill 78 44 559 78 45 559 minecraft:cobbled_deepslate
fill 78 44 579 78 45 580 minecraft:deepslate
fill 79 44 578 79 45 578 minecraft:deepslate
fill 79 44 581 79 45 581 minecraft:deepslate
setblock 80 44 559 minecraft:calcite
fill 80 44 577 82 45 577 minecraft:deepslate
fill 80 44 582 82 45 582 minecraft:deepslate
setblock 81 44 558 minecraft:calcite
fill 81 44 559 81 46 560 minecraft:cobbled_deepslate
setblock 81 44 598 minecraft:calcite
fill 82 44 558 82 47 558 minecraft:cobbled_deepslate
setblock 82 44 568 minecraft:light[level=14]
setblock 82 44 576 minecraft:light[level=14]
setblock 82 44 584 minecraft:light[level=14]
setblock 82 44 592 minecraft:light[level=14]
fill 82 44 598 82 47 598 minecraft:cobbled_deepslate
setblock 83 44 560 minecraft:cobbled_deepslate
fill 83 44 578 83 45 578 minecraft:deepslate
fill 83 44 581 83 45 581 minecraft:deepslate
setblock 84 44 560 minecraft:calcite
setblock 85 44 559 minecraft:calcite
fill 85 44 560 85 47 560 minecraft:cobbled_deepslate
setblock 86 44 558 minecraft:calcite
fill 86 44 559 86 47 559 minecraft:cobbled_deepslate
setblock 86 44 598 minecraft:calcite
fill 87 44 558 87 47 558 minecraft:cobbled_deepslate
setblock 87 44 562 minecraft:calcite
fill 87 44 563 87 47 563 minecraft:cobbled_deepslate
fill 87 44 598 87 46 598 minecraft:cobbled_deepslate
setblock 88 44 561 minecraft:calcite
fill 88 44 562 88 47 562 minecraft:cobbled_deepslate
setblock 88 44 576 minecraft:calcite
fill 88 44 577 88 45 577 minecraft:cobbled_deepslate
setblock 88 44 581 minecraft:calcite
fill 48 45 558 49 45 558 minecraft:cobbled_deepslate
setblock 48 45 560 minecraft:calcite
fill 48 45 561 48 48 561 minecraft:cobbled_deepslate
setblock 48 45 596 minecraft:cobbled_deepslate
setblock 49 45 559 minecraft:calcite
fill 49 45 560 49 48 560 minecraft:cobbled_deepslate
setblock 49 45 598 minecraft:cobbled_deepslate
setblock 50 45 558 minecraft:calcite
fill 50 45 559 50 48 559 minecraft:cobbled_deepslate
setblock 50 45 598 minecraft:calcite
fill 51 45 558 51 48 558 minecraft:cobbled_deepslate
fill 51 45 598 54 45 598 minecraft:cobbled_deepslate
setblock 54 45 559 minecraft:calcite
fill 54 45 597 54 46 597 minecraft:cobbled_deepslate
setblock 55 45 558 minecraft:calcite
fill 55 45 559 55 48 559 minecraft:cobbled_deepslate
setblock 55 45 598 minecraft:calcite
fill 56 45 558 56 48 558 minecraft:cobbled_deepslate
setblock 56 45 597 minecraft:calcite
fill 56 45 598 56 48 598 minecraft:cobbled_deepslate
fill 57 45 597 57 48 597 minecraft:cobbled_deepslate
setblock 59 45 559 minecraft:calcite
setblock 60 45 558 minecraft:calcite
fill 60 45 559 60 48 559 minecraft:cobbled_deepslate
setblock 60 45 598 minecraft:calcite
fill 61 45 558 61 48 558 minecraft:cobbled_deepslate
setblock 61 45 597 minecraft:calcite
fill 61 45 598 61 48 598 minecraft:cobbled_deepslate
fill 62 45 597 62 48 597 minecraft:cobbled_deepslate
setblock 64 45 559 minecraft:calcite
setblock 65 45 558 minecraft:calcite
setblock 65 45 598 minecraft:calcite
fill 66 45 558 66 48 558 minecraft:cobbled_deepslate
fill 66 45 598 66 47 598 minecraft:cobbled_deepslate
setblock 75 45 558 minecraft:calcite
fill 76 45 558 76 48 558 minecraft:cobbled_deepslate
fill 77 45 559 77 46 559 minecraft:cobbled_deepslate
fill 77 45 598 77 47 598 minecraft:cobbled_deepslate
fill 78 45 577 78 45 578 minecraft:deepslate
fill 78 45 581 78 45 582 minecraft:deepslate
setblock 79 45 559 minecraft:calcite
fill 79 45 560 80 47 560 minecraft:cobbled_deepslate
setblock 79 45 577 minecraft:deepslate
setblock 79 45 582 minecraft:deepslate
setblock 80 45 558 minecraft:calcite
fill 80 45 559 80 48 559 minecraft:cobbled_deepslate
fill 80 45 576 82 45 576 minecraft:deepslate
fill 80 45 583 82 45 583 minecraft:deepslate
setblock 80 45 598 minecraft:calcite
fill 81 45 558 81 48 558 minecraft:cobbled_deepslate
fill 81 45 598 81 48 598 minecraft:cobbled_deepslate
setblock 83 45 560 minecraft:calcite
setblock 83 45 577 minecraft:deepslate
setblock 83 45 582 minecraft:deepslate
setblock 84 45 559 minecraft:calcite
fill 84 45 560 84 48 560 minecraft:cobbled_deepslate
fill 84 45 578 84 45 581 minecraft:deepslate
setblock 85 45 558 minecraft:calcite
fill 85 45 559 85 48 559 minecraft:cobbled_deepslate
setblock 85 45 598 minecraft:calcite
fill 86 45 558 86 48 558 minecraft:cobbled_deepslate
fill 86 45 560 86 45 561 minecraft:cobbled_deepslate
fill 86 45 598 86 48 598 minecraft:cobbled_deepslate
setblock 87 45 561 minecraft:calcite
fill 87 45 562 87 48 562 minecraft:cobbled_deepslate
fill 87 45 564 87 46 564 minecraft:cobbled_deepslate
setblock 88 45 560 minecraft:calcite
fill 88 45 561 88 48 561 minecraft:cobbled_deepslate
setblock 88 45 565 minecraft:calcite
fill 88 45 566 88 48 566 minecraft:cobbled_deepslate
setblock 88 45 576 minecraft:cobbled_deepslate
setblock 88 45 580 minecraft:calcite
fill 88 45 581 88 48 581 minecraft:cobbled_deepslate
setblock 48 46 558 minecraft:cobbled_deepslate
setblock 48 46 559 minecraft:calcite
fill 48 46 560 48 49 560 minecraft:cobbled_deepslate
setblock 48 46 564 minecraft:calcite
setblock 49 46 558 minecraft:calcite
fill 49 46 559 49 49 559 minecraft:cobbled_deepslate
setblock 49 46 598 minecraft:calcite
fill 50 46 558 50 49 558 minecraft:cobbled_deepslate
fill 50 46 598 53 46 598 minecraft:cobbled_deepslate
fill 51 46 559 52 46 559 minecraft:cobbled_deepslate
setblock 53 46 559 minecraft:calcite
setblock 54 46 558 minecraft:calcite
fill 54 46 559 54 49 559 minecraft:cobbled_deepslate
setblock 54 46 598 minecraft:calcite
fill 55 46 558 55 49 558 minecraft:cobbled_deepslate
setblock 55 46 597 minecraft:calcite
fill 55 46 598 55 49 598 minecraft:cobbled_deepslate
fill 56 46 597 56 49 597 minecraft:cobbled_deepslate
setblock 58 46 559 minecraft:calcite
setblock 59 46 558 minecraft:calcite
fill 59 46 559 59 49 559 minecraft:cobbled_deepslate
setblock 59 46 598 minecraft:calcite
fill 60 46 558 60 49 558 minecraft:cobbled_deepslate
setblock 60 46 597 minecraft:calcite
fill 60 46 598 60 49 598 minecraft:cobbled_deepslate
fill 61 46 597 61 49 597 minecraft:cobbled_deepslate
fill 62 46 560 64 49 560 minecraft:light_blue_stained_glass
setblock 63 46 559 minecraft:calcite
setblock 64 46 558 minecraft:calcite
fill 64 46 559 64 47 559 minecraft:cobbled_deepslate
setblock 64 46 598 minecraft:calcite
fill 65 46 558 65 49 558 minecraft:cobbled_deepslate
fill 65 46 559 65 49 559 minecraft:light_blue_stained_glass
fill 65 46 598 65 48 598 minecraft:cobbled_deepslate
setblock 74 46 558 minecraft:calcite
fill 75 46 558 75 49 558 minecraft:cobbled_deepslate
fill 76 46 559 76 47 559 minecraft:cobbled_deepslate
setblock 78 46 559 minecraft:calcite
fill 78 46 560 78 49 560 minecraft:cobbled_deepslate
fill 78 46 567 79 53 568 minecraft:deepslate
setblock 79 46 558 minecraft:calcite
fill 79 46 559 79 49 559 minecraft:cobbled_deepslate
setblock 79 46 598 minecraft:calcite
fill 80 46 558 80 49 558 minecraft:cobbled_deepslate
fill 80 46 598 80 49 598 minecraft:cobbled_deepslate
setblock 82 46 559 minecraft:cobbled_deepslate
setblock 82 46 560 minecraft:calcite
setblock 83 46 559 minecraft:calcite
fill 83 46 560 83 49 560 minecraft:cobbled_deepslate
setblock 84 46 558 minecraft:calcite
fill 84 46 559 84 49 559 minecraft:cobbled_deepslate
setblock 84 46 598 minecraft:calcite
fill 85 46 558 85 49 558 minecraft:cobbled_deepslate
fill 85 46 598 85 49 598 minecraft:cobbled_deepslate
setblock 86 46 560 minecraft:cobbled_deepslate
setblock 86 46 561 minecraft:calcite
fill 86 46 562 86 49 562 minecraft:cobbled_deepslate
setblock 87 46 560 minecraft:calcite
fill 87 46 561 87 49 561 minecraft:cobbled_deepslate
setblock 88 46 559 minecraft:calcite
fill 88 46 560 88 49 560 minecraft:cobbled_deepslate
setblock 88 46 564 minecraft:calcite
fill 88 46 565 88 49 565 minecraft:cobbled_deepslate
setblock 88 46 579 minecraft:calcite
fill 88 46 580 88 48 580 minecraft:cobbled_deepslate
setblock 48 47 558 minecraft:calcite
fill 48 47 559 48 50 559 minecraft:cobbled_deepslate
setblock 48 47 563 minecraft:calcite
fill 48 47 564 48 50 564 minecraft:cobbled_deepslate
setblock 48 47 597 minecraft:cobbled_deepslate
setblock 48 47 598 minecraft:calcite
fill 49 47 558 49 50 558 minecraft:cobbled_deepslate
setblock 49 47 561 minecraft:cobbled_deepslate
fill 49 47 598 52 47 598 minecraft:cobbled_deepslate
setblock 51 47 559 minecraft:cobbled_deepslate
setblock 52 47 559 minecraft:calcite
setblock 53 47 558 minecraft:calcite
fill 53 47 559 53 50 559 minecraft:cobbled_deepslate
setblock 53 47 597 minecraft:cobbled_deepslate
setblock 53 47 598 minecraft:calcite
fill 54 47 558 54 50 558 minecraft:cobbled_deepslate
setblock 54 47 597 minecraft:calcite
fill 54 47 598 54 50 598 minecraft:cobbled_deepslate
fill 55 47 597 55 50 597 minecraft:cobbled_deepslate
setblock 57 47 559 minecraft:calcite
fill 57 47 560 60 47 560 minecraft:cobbled_deepslate
setblock 58 47 558 minecraft:calcite
fill 58 47 559 58 50 559 minecraft:cobbled_deepslate
fill 58 47 596 58 48 596 minecraft:cobbled_deepslate
setblock 58 47 598 minecraft:calcite
fill 59 47 558 59 50 558 minecraft:cobbled_deepslate
setblock 59 47 597 minecraft:calcite
fill 59 47 598 59 50 598 minecraft:cobbled_deepslate
setblock 60 47 596 minecraft:calcite
fill 60 47 597 60 50 597 minecraft:cobbled_deepslate
fill 61 47 560 61 48 560 minecraft:light_blue_stained_glass
setblock 62 47 559 minecraft:calcite
fill 62 47 561 64 49 561 minecraft:light_blue_stained_glass
setblock 63 47 558 minecraft:calcite
fill 63 47 559 63 49 559 minecraft:cobbled_deepslate
fill 63 47 562 63 49 562 minecraft:light_blue_stained_glass
setblock 63 47 598 minecraft:calcite
fill 64 47 558 64 50 558 minecraft:cobbled_deepslate
fill 64 47 598 64 50 598 minecraft:cobbled_deepslate
fill 65 47 560 65 48 560 minecraft:light_blue_stained_glass
setblock 73 47 558 minecraft:calcite
fill 74 47 558 74 50 558 minecraft:cobbled_deepslate
fill 75 47 559 75 48 559 minecraft:cobbled_deepslate
fill 76 47 596 78 52 597 minecraft:light_blue_stained_glass
fill 76 47 598 76 48 598 minecraft:cobbled_deepslate
setblock 77 47 559 minecraft:calcite
fill 77 47 560 77 50 560 minecraft:cobbled_deepslate
fill 77 47 567 77 53 567 minecraft:deepslate
setblock 78 47 558 minecraft:calcite
fill 78 47 559 78 50 559 minecraft:cobbled_deepslate
fill 78 47 566 79 53 566 minecraft:deepslate
setblock 78 47 598 minecraft:calcite
fill 79 47 558 79 50 558 minecraft:cobbled_deepslate
setblock 79 47 561 minecraft:cobbled_deepslate
fill 79 47 598 79 50 598 minecraft:cobbled_deepslate
setblock 80 47 561 minecraft:calcite
setblock 81 47 559 minecraft:cobbled_deepslate
setblock 81 47 560 minecraft:calcite
fill 81 47 561 83 48 561 minecraft:cobbled_deepslate
setblock 82 47 559 minecraft:calcite
fill 82 47 560 82 50 560 minecraft:cobbled_deepslate
setblock 83 47 558 minecraft:calcite
fill 83 47 559 83 50 559 minecraft:cobbled_deepslate
setblock 83 47 598 minecraft:calcite
fill 84 47 558 84 50 558 minecraft:cobbled_deepslate
fill 84 47 598 84 50 598 minecraft:cobbled_deepslate
setblock 86 47 560 minecraft:calcite
fill 86 47 561 86 50 561 minecraft:cobbled_deepslate
fill 86 47 563 86 48 563 minecraft:cobbled_deepslate
setblock 87 47 559 minecraft:calcite
fill 87 47 560 87 50 560 minecraft:cobbled_deepslate
setblock 87 47 564 minecraft:calcite
fill 87 47 565 87 50 565 minecraft:cobbled_deepslate
setblock 88 47 558 minecraft:calcite
fill 88 47 559 88 50 559 minecraft:cobbled_deepslate
setblock 88 47 563 minecraft:calcite
fill 88 47 564 88 50 564 minecraft:cobbled_deepslate
setblock 88 47 567 minecraft:cobbled_deepslate
setblock 88 47 579 minecraft:cobbled_deepslate
fill 48 48 558 48 51 558 minecraft:cobbled_deepslate
setblock 48 48 562 minecraft:calcite
fill 48 48 563 48 51 563 minecraft:cobbled_deepslate
fill 48 48 565 48 49 565 minecraft:cobbled_deepslate
setblock 48 48 582 minecraft:calcite
fill 48 48 583 48 49 585 minecraft:cobbled_deepslate
setblock 48 48 597 minecraft:calcite
fill 48 48 598 51 48 598 minecraft:cobbled_deepslate
setblock 49 48 561 minecraft:calcite
fill 49 48 562 49 51 562 minecraft:cobbled_deepslate
setblock 51 48 559 minecraft:calcite
setblock 52 48 558 minecraft:calcite
fill 52 48 559 52 51 559 minecraft:cobbled_deepslate
setblock 52 48 598 minecraft:calcite
fill 53 48 558 53 51 558 minecraft:cobbled_deepslate
setblock 53 48 597 minecraft:calcite
fill 53 48 598 53 51 598 minecraft:cobbled_deepslate
fill 54 48 597 54 51 597 minecraft:cobbled_deepslate
setblock 55 48 560 minecraft:calcite
setblock 56 48 559 minecraft:calcite
fill 56 48 560 59 48 560 minecraft:cobbled_deepslate
setblock 57 48 558 minecraft:calcite
fill 57 48 559 57 51 559 minecraft:cobbled_deepslate
fill 57 48 596 57 49 596 minecraft:cobbled_deepslate
setblock 57 48 598 minecraft:calcite
fill 58 48 558 58 51 558 minecraft:cobbled_deepslate
setblock 58 48 597 minecraft:calcite
fill 58 48 598 58 51 598 minecraft:cobbled_deepslate
setblock 59 48 596 minecraft:calcite
fill 59 48 597 59 51 597 minecraft:cobbled_deepslate
setblock 60 48 560 minecraft:calcite
setblock 61 48 559 minecraft:calcite
setblock 62 48 558 minecraft:calcite
fill 62 48 559 62 50 559 minecraft:cobbled_deepslate
fill 62 48 562 62 49 562 minecraft:light_blue_stained_glass
setblock 62 48 598 minecraft:calcite
fill 63 48 558 63 51 558 minecraft:cobbled_deepslate
fill 63 48 563 63 49 563 minecraft:light_blue_stained_glass
setblock 63 48 597 minecraft:calcite
fill 63 48 598 63 51 598 minecraft:cobbled_deepslate
fill 64 48 559 64 50 559 minecraft:light_blue_stained_glass
fill 64 48 562 64 49 562 minecraft:light_blue_stained_glass
setblock 72 48 558 minecraft:calcite
fill 73 48 558 73 51 558 minecraft:cobbled_deepslate
fill 74 48 559 74 49 559 minecraft:cobbled_deepslate
fill 75 48 596 75 49 598 minecraft:light_blue_stained_glass
setblock 76 48 559 minecraft:calcite
fill 76 48 560 76 51 560 minecraft:cobbled_deepslate
fill 76 48 595 78 51 595 minecraft:light_blue_stained_glass
setblock 77 48 558 minecraft:calcite
fill 77 48 559 77 51 559 minecraft:cobbled_deepslate
fill 77 48 566 77 53 566 minecraft:deepslate
fill 77 48 568 77 53 568 minecraft:deepslate
setblock 77 48 598 minecraft:calcite
fill 78 48 558 78 51 558 minecraft:cobbled_deepslate
setblock 78 48 561 minecraft:cobbled_deepslate
fill 78 48 569 79 53 569 minecraft:deepslate
fill 78 48 598 78 51 598 minecraft:cobbled_deepslate
setblock 79 48 560 minecraft:cobbled_deepslate
setblock 79 48 561 minecraft:calcite
fill 79 48 596 79 51 597 minecraft:light_blue_stained_glass
setblock 80 48 560 minecraft:calcite
fill 80 48 561 80 51 561 minecraft:cobbled_deepslate
fill 80 48 567 80 53 568 minecraft:deepslate
setblock 81 48 559 minecraft:calcite
fill 81 48 560 81 51 560 minecraft:cobbled_deepslate
setblock 82 48 558 minecraft:calcite
fill 82 48 559 82 51 559 minecraft:cobbled_deepslate
setblock 82 48 598 minecraft:calcite
fill 83 48 558 83 51 558 minecraft:cobbled_deepslate
fill 83 48 598 83 50 598 minecraft:cobbled_deepslate
setblock 84 48 561 minecraft:calcite
setblock 85 48 560 minecraft:calcite
setblock 86 48 559 minecraft:calcite
fill 86 48 560 86 51 560 minecraft:cobbled_deepslate
setblock 86 48 564 minecraft:calcite
setblock 87 48 558 minecraft:calcite
fill 87 48 559 87 51 559 minecraft:cobbled_deepslate
setblock 87 48 563 minecraft:calcite
fill 87 48 564 87 51 564 minecraft:cobbled_deepslate
fill 87 48 566 87 49 566 minecraft:cobbled_deepslate
fill 88 48 558 88 51 558 minecraft:cobbled_deepslate
setblock 88 48 562 minecraft:calcite
fill 88 48 563 88 51 563 minecraft:cobbled_deepslate
setblock 88 48 567 minecraft:calcite
fill 88 48 568 88 51 568 minecraft:cobbled_deepslate
setblock 88 48 582 minecraft:calcite
setblock 48 49 561 minecraft:calcite
fill 48 49 562 48 52 562 minecraft:cobbled_deepslate
setblock 48 49 581 minecraft:calcite
fill 48 49 582 48 52 582 minecraft:cobbled_deepslate
setblock 48 49 586 minecraft:calcite
fill 48 49 587 48 51 588 minecraft:cobbled_deepslate
setblock 48 49 596 minecraft:calcite
fill 48 49 597 48 51 598 minecraft:cobbled_deepslate
setblock 49 49 560 minecraft:calcite
fill 49 49 561 49 52 561 minecraft:cobbled_deepslate
fill 49 49 563 49 50 563 minecraft:cobbled_deepslate
fill 49 49 598 50 49 598 minecraft:cobbled_deepslate
setblock 50 49 559 minecraft:calcite
setblock 51 49 558 minecraft:calcite
fill 51 49 559 51 52 559 minecraft:cobbled_deepslate
setblock 51 49 598 minecraft:calcite
fill 52 49 558 52 52 558 minecraft:cobbled_deepslate
setblock 52 49 597 minecraft:calcite
fill 52 49 598 52 52 598 minecraft:cobbled_deepslate
fill 53 49 597 53 52 597 minecraft:cobbled_deepslate
setblock 54 49 560 minecraft:calcite
setblock 55 49 559 minecraft:calcite
fill 55 49 560 58 49 560 minecraft:cobbled_deepslate
setblock 56 49 558 minecraft:calcite
fill 56 49 559 56 52 559 minecraft:cobbled_deepslate
setblock 56 49 598 minecraft:calcite
fill 57 49 558 57 52 558 minecraft:cobbled_deepslate
setblock 57 49 597 minecraft:calcite
fill 57 49 598 57 52 598 minecraft:cobbled_deepslate
setblock 58 49 596 minecraft:calcite
fill 58 49 597 58 52 597 minecraft:cobbled_deepslate
setblock 59 49 560 minecraft:calcite
setblock 59 49 596 minecraft:cobbled_deepslate
setblock 60 49 559 minecraft:calcite
fill 60 49 560 60 50 560 minecraft:cobbled_deepslate
setblock 61 49 558 minecraft:calcite
fill 61 49 559 61 51 559 minecraft:cobbled_deepslate
setblock 61 49 598 minecraft:calcite
fill 62 49 558 62 51 558 minecraft:cobbled_deepslate
setblock 62 49 597 minecraft:calcite
fill 62 49 598 62 51 598 minecraft:cobbled_deepslate
setblock 63 49 564 minecraft:light_blue_stained_glass
fill 72 49 558 72 52 558 minecraft:cobbled_deepslate
fill 73 49 559 73 50 559 minecraft:cobbled_deepslate
setblock 75 49 559 minecraft:calcite
fill 75 49 560 75 52 560 minecraft:cobbled_deepslate
fill 75 49 595 75 50 595 minecraft:light_blue_stained_glass
setblock 76 49 558 minecraft:calcite
fill 76 49 559 76 52 559 minecraft:cobbled_deepslate
fill 76 49 567 76 53 567 minecraft:deepslate
fill 76 49 594 78 51 594 minecraft:light_blue_stained_glass
setblock 76 49 598 minecraft:calcite
fill 77 49 558 77 52 558 minecraft:cobbled_deepslate
setblock 77 49 561 minecraft:cobbled_deepslate
fill 77 49 569 77 53 569 minecraft:deepslate
fill 77 49 593 77 51 593 minecraft:light_blue_stained_glass
fill 77 49 598 77 52 598 minecraft:cobbled_deepslate
setblock 78 49 561 minecraft:calcite
fill 78 49 565 79 53 565 minecraft:deepslate
setblock 79 49 560 minecraft:calcite
fill 79 49 561 79 52 561 minecraft:cobbled_deepslate
fill 79 49 595 79 50 595 minecraft:light_blue_stained_glass
setblock 80 49 559 minecraft:calcite
fill 80 49 560 80 52 560 minecraft:cobbled_deepslate
fill 80 49 566 80 53 566 minecraft:deepslate
fill 80 49 569 80 53 569 minecraft:deepslate
setblock 81 49 558 minecraft:calcite
fill 81 49 559 81 52 559 minecraft:cobbled_deepslate
fill 81 49 561 82 49 561 minecraft:cobbled_deepslate
setblock 81 49 598 minecraft:calcite
fill 82 49 558 82 52 558 minecraft:cobbled_deepslate
fill 82 49 598 82 51 598 minecraft:cobbled_deepslate
setblock 83 49 561 minecraft:calcite
setblock 84 49 560 minecraft:calcite
fill 84 49 561 84 50 561 minecraft:cobbled_deepslate
setblock 85 49 559 minecraft:calcite
fill 85 49 560 85 51 560 minecraft:cobbled_deepslate
setblock 86 49 558 minecraft:calcite
fill 86 49 559 86 52 559 minecraft:cobbled_deepslate
setblock 86 49 563 minecraft:calcite
fill 86 49 564 86 52 564 minecraft:cobbled_deepslate
fill 87 49 558 87 52 558 minecraft:cobbled_deepslate
setblock 87 49 562 minecraft:calcite
fill 87 49 563 87 52 563 minecraft:cobbled_deepslate
setblock 88 49 561 minecraft:calcite
fill 88 49 562 88 52 562 minecraft:cobbled_deepslate
setblock 88 49 566 minecraft:calcite
fill 88 49 567 88 52 567 minecraft:cobbled_deepslate
setblock 88 49 581 minecraft:calcite
fill 88 49 582 88 49 583 minecraft:cobbled_deepslate
setblock 48 50 560 minecraft:calcite
fill 48 50 561 48 53 561 minecraft:cobbled_deepslate
setblock 48 50 565 minecraft:calcite
fill 48 50 566 48 53 566 minecraft:cobbled_deepslate
fill 48 50 583 48 50 584 minecraft:cobbled_deepslate
setblock 48 50 585 minecraft:calcite
fill 48 50 586 48 53 586 minecraft:cobbled_deepslate
setblock 48 50 589 minecraft:cobbled_deepslate
setblock 48 50 590 minecraft:calcite
setblock 48 50 596 minecraft:cobbled_deepslate
setblock 49 50 559 minecraft:calcite
fill 49 50 560 49 51 560 minecraft:cobbled_deepslate
setblock 49 50 598 minecraft:cobbled_deepslate
setblock 50 50 558 minecraft:calcite
fill 50 50 559 50 51 559 minecraft:cobbled_deepslate
setblock 50 50 598 minecraft:calcite
fill 51 50 558 51 53 558 minecraft:cobbled_deepslate
fill 51 50 598 51 53 598 minecraft:cobbled_deepslate
fill 52 50 597 52 52 597 minecraft:cobbled_deepslate
setblock 54 50 559 minecraft:calcite
fill 54 50 560 57 50 560 minecraft:cobbled_deepslate
setblock 55 50 558 minecraft:calcite
fill 55 50 559 55 53 559 minecraft:cobbled_deepslate
setblock 55 50 598 minecraft:calcite
fill 56 50 558 56 53 558 minecraft:cobbled_deepslate
setblock 56 50 597 minecraft:calcite
fill 56 50 598 56 53 598 minecraft:cobbled_deepslate
setblock 57 50 596 minecraft:calcite
fill 57 50 597 57 53 597 minecraft:cobbled_deepslate
setblock 58 50 560 minecraft:calcite
setblock 58 50 596 minecraft:cobbled_deepslate
setblock 59 50 559 minecraft:calcite
setblock 59 50 560 minecraft:cobbled_deepslate
setblock 60 50 558 minecraft:calcite
fill 60 50 559 60 51 559 minecraft:cobbled_deepslate
setblock 60 50 598 minecraft:calcite
fill 61 50 558 61 52 558 minecraft:cobbled_deepslate
setblock 61 50 597 minecraft:calcite
fill 61 50 598 61 52 598 minecraft:cobbled_deepslate
fill 63 50 559 63 50 560 minecraft:light_blue_stained_glass
setblock 71 50 558 minecraft:cobbled_deepslate
setblock 74 50 559 minecraft:calcite
fill 74 50 560 74 52 560 minecraft:cobbled_deepslate
setblock 75 50 558 minecraft:calcite
fill 75 50 559 75 53 559 minecraft:cobbled_deepslate
fill 75 50 596 75 51 597 minecraft:light_blue_stained_glass
setblock 75 50 598 minecraft:calcite
fill 76 50 558 76 53 558 minecraft:cobbled_deepslate
setblock 76 50 561 minecraft:cobbled_deepslate
fill 76 50 566 76 53 566 minecraft:deepslate
fill 76 50 568 76 53 569 minecraft:deepslate
setblock 76 50 593 minecraft:light_blue_stained_glass
fill 76 50 598 76 52 598 minecraft:cobbled_deepslate
setblock 77 50 561 minecraft:calcite
fill 77 50 565 77 53 565 minecraft:deepslate
setblock 77 50 592 minecraft:light_blue_stained_glass
setblock 78 50 560 minecraft:calcite
fill 78 50 561 78 53 561 minecraft:cobbled_deepslate
fill 78 50 570 79 53 570 minecraft:deepslate
setblock 78 50 593 minecraft:light_blue_stained_glass
setblock 79 50 559 minecraft:calcite
fill 79 50 560 79 53 560 minecraft:cobbled_deepslate
setblock 79 50 562 minecraft:cobbled_deepslate
setblock 80 50 558 minecraft:calcite
fill 80 50 559 80 53 559 minecraft:cobbled_deepslate
fill 80 50 565 80 53 565 minecraft:deepslate
setblock 80 50 598 minecraft:calcite
fill 81 50 558 81 53 558 minecraft:cobbled_deepslate
setblock 81 50 561 minecraft:cobbled_deepslate
fill 81 50 566 81 53 568 minecraft:deepslate
fill 81 50 598 81 52 598 minecraft:cobbled_deepslate
setblock 82 50 561 minecraft:calcite
setblock 83 50 560 minecraft:calcite
fill 83 50 561 83 51 561 minecraft:cobbled_deepslate
setblock 84 50 559 minecraft:calcite
fill 84 50 560 84 52 560 minecraft:cobbled_deepslate
setblock 85 50 558 minecraft:calcite
fill 85 50 559 85 53 559 minecraft:cobbled_deepslate
fill 86 50 558 86 53 558 minecraft:cobbled_deepslate
setblock 86 50 562 minecraft:calcite
fill 86 50 563 86 52 563 minecraft:cobbled_deepslate
fill 86 50 565 86 51 565 minecraft:cobbled_deepslate
setblock 87 50 561 minecraft:calcite
fill 87 50 562 87 53 562 minecraft:cobbled_deepslate
setblock 87 50 566 minecraft:calcite
fill 87 50 567 87 52 567 minecraft:cobbled_deepslate
setblock 88 50 560 minecraft:calcite
fill 88 50 561 88 53 561 minecraft:cobbled_deepslate
setblock 88 50 565 minecraft:calcite
fill 88 50 566 88 53 566 minecraft:cobbled_deepslate
fill 88 50 583 88 50 584 minecraft:cobbled_deepslate
setblock 48 51 559 minecraft:calcite
fill 48 51 560 48 54 560 minecraft:cobbled_deepslate
setblock 48 51 564 minecraft:calcite
fill 48 51 565 48 54 565 minecraft:cobbled_deepslate
setblock 48 51 583 minecraft:cobbled_deepslate
setblock 48 51 584 minecraft:calcite
fill 48 51 585 49 53 585 minecraft:cobbled_deepslate
setblock 48 51 589 minecraft:calcite
fill 48 51 590 48 52 592 minecraft:cobbled_deepslate
setblock 49 51 558 minecraft:calcite
setblock 49 51 559 minecraft:cobbled_deepslate
setblock 49 51 563 minecraft:calcite
fill 49 51 586 49 51 587 minecraft:cobbled_deepslate
setblock 49 51 598 minecraft:calcite
fill 50 51 558 50 53 558 minecraft:cobbled_deepslate
fill 50 51 598 50 54 598 minecraft:cobbled_deepslate
setblock 53 51 559 minecraft:calcite
setblock 54 51 558 minecraft:calcite
fill 54 51 559 54 53 559 minecraft:cobbled_deepslate
setblock 54 51 598 minecraft:calcite
fill 55 51 558 55 54 558 minecraft:cobbled_deepslate
fill 55 51 560 56 51 560 minecraft:cobbled_deepslate
setblock 55 51 597 minecraft:calcite
fill 55 51 598 55 54 598 minecraft:cobbled_deepslate
fill 56 51 597 56 54 597 minecraft:cobbled_deepslate
setblock 57 51 560 minecraft:calcite
setblock 58 51 559 minecraft:calcite
setblock 58 51 560 minecraft:cobbled_deepslate
setblock 59 51 558 minecraft:calcite
fill 59 51 559 59 52 559 minecraft:cobbled_deepslate
setblock 59 51 598 minecraft:calcite
fill 60 51 558 60 53 558 minecraft:cobbled_deepslate
setblock 60 51 597 minecraft:calcite
fill 60 51 598 60 53 598 minecraft:cobbled_deepslate
setblock 73 51 559 minecraft:calcite
setblock 74 51 558 minecraft:calcite
fill 74 51 559 74 54 559 minecraft:cobbled_deepslate
fill 75 51 558 75 54 558 minecraft:cobbled_deepslate
setblock 75 51 598 minecraft:light_blue_stained_glass
setblock 76 51 561 minecraft:calcite
fill 76 51 565 76 53 565 minecraft:deepslate
setblock 77 51 560 minecraft:calcite
fill 77 51 561 77 53 561 minecraft:cobbled_deepslate
fill 77 51 570 77 53 570 minecraft:deepslate
setblock 78 51 559 minecraft:calcite
fill 78 51 560 78 54 560 minecraft:cobbled_deepslate
fill 78 51 564 79 53 564 minecraft:deepslate
setblock 79 51 558 minecraft:calcite
fill 79 51 559 79 54 559 minecraft:cobbled_deepslate
setblock 79 51 598 minecraft:calcite
fill 80 51 558 80 54 558 minecraft:cobbled_deepslate
fill 80 51 570 80 53 570 minecraft:deepslate
fill 80 51 598 80 52 598 minecraft:cobbled_deepslate
setblock 81 51 561 minecraft:calcite
fill 81 51 565 81 53 565 minecraft:deepslate
fill 81 51 569 81 53 569 minecraft:deepslate
setblock 82 51 560 minecraft:calcite
setblock 82 51 561 minecraft:cobbled_deepslate
setblock 83 51 559 minecraft:calcite
fill 83 51 560 83 52 560 minecraft:cobbled_deepslate
setblock 84 51 558 minecraft:calcite
fill 84 51 559 84 53 559 minecraft:cobbled_deepslate
fill 85 51 558 85 54 558 minecraft:cobbled_deepslate
setblock 86 51 561 minecraft:calcite
fill 86 51 562 86 52 562 minecraft:cobbled_deepslate
setblock 87 51 560 minecraft:calcite
fill 87 51 561 87 54 561 minecraft:cobbled_deepslate
setblock 87 51 565 minecraft:calcite
fill 87 51 566 87 54 566 minecraft:cobbled_deepslate
setblock 88 51 559 minecraft:calcite
fill 88 51 560 88 54 560 minecraft:cobbled_deepslate
setblock 88 51 564 minecraft:calcite
fill 88 51 565 88 54 565 minecraft:cobbled_deepslate
setblock 88 51 569 minecraft:calcite
setblock 88 51 584 minecraft:calcite
setblock 88 51 585 minecraft:cobbled_deepslate
setblock 48 52 558 minecraft:calcite
fill 48 52 559 48 53 559 minecraft:cobbled_deepslate
setblock 48 52 563 minecraft:calcite
fill 48 52 564 48 55 564 minecraft:cobbled_deepslate
setblock 48 52 583 minecraft:calcite
fill 48 52 584 48 55 584 minecraft:cobbled_deepslate
setblock 48 52 587 minecraft:cobbled_deepslate
setblock 48 52 588 minecraft:calcite
fill 48 52 589 49 54 589 minecraft:cobbled_deepslate
setblock 48 52 593 minecraft:calcite
setblock 48 52 598 minecraft:calcite
fill 49 52 558 49 53 558 minecraft:cobbled_deepslate
setblock 49 52 562 minecraft:calcite
setblock 49 52 586 minecraft:cobbled_deepslate
setblock 49 52 587 minecraft:calcite
fill 49 52 588 49 55 588 minecraft:cobbled_deepslate
fill 49 52 598 49 53 598 minecraft:cobbled_deepslate
setblock 50 52 560 minecraft:light[level=14]
setblock 50 52 568 minecraft:light[level=14]
setblock 50 52 576 minecraft:light[level=14]
setblock 50 52 584 minecraft:light[level=14]
setblock 50 52 592 minecraft:light[level=14]
setblock 52 52 559 minecraft:calcite
setblock 53 52 558 minecraft:calcite
fill 53 52 559 53 53 559 minecraft:cobbled_deepslate
setblock 53 52 598 minecraft:calcite
fill 54 52 558 54 55 558 minecraft:cobbled_deepslate
setblock 54 52 597 minecraft:calcite
fill 54 52 598 54 55 598 minecraft:cobbled_deepslate
fill 55 52 597 55 55 597 minecraft:cobbled_deepslate
setblock 57 52 559 minecraft:calcite
setblock 58 52 558 minecraft:calcite
setblock 58 52 559 minecraft:cobbled_deepslate
setblock 58 52 560 minecraft:light[level=14]
setblock 58 52 568 minecraft:light[level=14]
setblock 58 52 576 minecraft:light[level=14]
setblock 58 52 584 minecraft:light[level=14]
setblock 58 52 592 minecraft:light[level=14]
setblock 58 52 598 minecraft:calcite
fill 59 52 558 59 53 558 minecraft:cobbled_deepslate
setblock 59 52 597 minecraft:calcite
fill 59 52 598 59 54 598 minecraft:cobbled_deepslate
setblock 66 52 560 minecraft:light[level=14]
setblock 66 52 568 minecraft:light[level=14]
setblock 66 52 576 minecraft:light[level=14]
setblock 66 52 584 minecraft:light[level=14]
setblock 66 52 592 minecraft:light[level=14]
setblock 73 52 558 minecraft:calcite
fill 73 52 559 73 53 559 minecraft:cobbled_deepslate
fill 74 52 558 74 55 558 minecraft:cobbled_deepslate
setblock 74 52 568 minecraft:light[level=14]
setblock 74 52 576 minecraft:light[level=14]
setblock 74 52 584 minecraft:light[level=14]
setblock 74 52 592 minecraft:light[level=14]
fill 75 52 566 75 53 569 minecraft:deepslate
setblock 76 52 560 minecraft:calcite
setblock 76 52 561 minecraft:cobbled_deepslate
fill 76 52 570 76 53 570 minecraft:deepslate
setblock 77 52 559 minecraft:calcite
fill 77 52 560 77 54 560 minecraft:cobbled_deepslate
fill 77 52 564 77 53 564 minecraft:deepslate
fill 77 52 571 80 53 571 minecraft:deepslate
setblock 78 52 558 minecraft:calcite
fill 78 52 559 78 55 559 minecraft:cobbled_deepslate
setblock 78 52 598 minecraft:calcite
fill 79 52 558 79 55 558 minecraft:cobbled_deepslate
setblock 79 52 598 minecraft:cobbled_deepslate
setblock 80 52 561 minecraft:calcite
fill 80 52 564 80 53 564 minecraft:deepslate
setblock 81 52 560 minecraft:calcite
setblock 81 52 561 minecraft:cobbled_deepslate
fill 81 52 570 81 53 570 minecraft:deepslate
setblock 82 52 559 minecraft:calcite
fill 82 52 560 82 53 560 minecraft:cobbled_deepslate
fill 82 52 566 82 53 569 minecraft:deepslate
setblock 82 52 576 minecraft:light[level=14]
setblock 82 52 584 minecraft:light[level=14]
setblock 82 52 592 minecraft:light[level=14]
setblock 83 52 558 minecraft:calcite
fill 83 52 559 83 53 559 minecraft:cobbled_deepslate
fill 84 52 558 84 54 558 minecraft:cobbled_deepslate
setblock 87 52 559 minecraft:calcite
fill 87 52 560 87 53 560 minecraft:cobbled_deepslate
setblock 87 52 564 minecraft:calcite
fill 87 52 565 87 55 565 minecraft:cobbled_deepslate
setblock 88 52 558 minecraft:calcite
fill 88 52 559 88 55 559 minecraft:cobbled_deepslate
setblock 88 52 563 minecraft:calcite
fill 88 52 564 88 55 564 minecraft:cobbled_deepslate
setblock 88 52 568 minecraft:calcite
fill 88 52 569 88 55 569 minecraft:cobbled_deepslate
setblock 48 53 558 minecraft:cobbled_deepslate
setblock 48 53 562 minecraft:calcite
fill 48 53 563 48 55 563 minecraft:cobbled_deepslate
setblock 48 53 583 minecraft:cobbled_deepslate
setblock 48 53 587 minecraft:calcite
fill 48 53 588 48 56 588 minecraft:cobbled_deepslate
fill 48 53 590 48 53 591 minecraft:cobbled_deepslate
setblock 48 53 592 minecraft:calcite
fill 48 53 593 48 55 594 minecraft:cobbled_deepslate
setblock 49 53 586 minecraft:calcite
fill 49 53 587 49 56 587 minecraft:cobbled_deepslate
setblock 49 53 590 minecraft:cobbled_deepslate
setblock 52 53 558 minecraft:calcite
setblock 52 53 598 minecraft:calcite
fill 53 53 558 53 55 558 minecraft:cobbled_deepslate
setblock 53 53 597 minecraft:calcite
fill 53 53 598 53 56 598 minecraft:cobbled_deepslate
fill 54 53 597 54 55 597 minecraft:cobbled_deepslate
setblock 56 53 559 minecraft:calcite
setblock 57 53 558 minecraft:calcite
setblock 57 53 559 minecraft:cobbled_deepslate
setblock 57 53 598 minecraft:calcite
fill 58 53 558 58 54 558 minecraft:cobbled_deepslate
setblock 58 53 597 minecraft:calcite
fill 58 53 598 58 55 598 minecraft:cobbled_deepslate
setblock 72 53 558 minecraft:calcite
fill 73 53 558 73 56 558 minecraft:cobbled_deepslate
setblock 75 53 560 minecraft:calcite
setblock 75 53 565 minecraft:deepslate
setblock 75 53 570 minecraft:deepslate
setblock 76 53 559 minecraft:calcite
fill 76 53 560 76 54 560 minecraft:cobbled_deepslate
setblock 76 53 564 minecraft:deepslate
setblock 76 53 571 minecraft:deepslate
setblock 77 53 558 minecraft:calcite
fill 77 53 559 77 56 559 minecraft:cobbled_deepslate
setblock 77 53 598 minecraft:calcite
fill 78 53 558 78 56 558 minecraft:cobbled_deepslate
fill 78 53 563 79 53 563 minecraft:deepslate
setblock 78 53 598 minecraft:cobbled_deepslate
setblock 79 53 561 minecraft:calcite
setblock 80 53 560 minecraft:calcite
setblock 81 53 559 minecraft:calcite
setblock 81 53 560 minecraft:cobbled_deepslate
setblock 81 53 564 minecraft:deepslate
setblock 81 53 571 minecraft:deepslate
setblock 82 53 558 minecraft:calcite
fill 82 53 559 82 54 559 minecraft:cobbled_deepslate
setblock 82 53 565 minecraft:deepslate
setblock 82 53 570 minecraft:deepslate
fill 83 53 558 83 54 558 minecraft:cobbled_deepslate
setblock 87 53 558 minecraft:calcite
setblock 87 53 563 minecraft:calcite
fill 87 53 564 87 55 564 minecraft:cobbled_deepslate
fill 88 53 558 88 54 558 minecraft:cobbled_deepslate
setblock 88 53 562 minecraft:calcite
fill 88 53 563 88 56 563 minecraft:cobbled_deepslate
setblock 88 53 567 minecraft:calcite
fill 88 53 568 88 56 568 minecraft:cobbled_deepslate
setblock 48 54 561 minecraft:calcite
setblock 48 54 562 minecraft:cobbled_deepslate
setblock 48 54 566 minecraft:calcite
setblock 48 54 585 minecraft:cobbled_deepslate
setblock 48 54 586 minecraft:calcite
fill 48 54 587 48 57 587 minecraft:cobbled_deepslate
setblock 48 54 590 minecraft:cobbled_deepslate
setblock 48 54 591 minecraft:calcite
fill 48 54 592 48 57 592 minecraft:cobbled_deepslate
setblock 49 54 585 minecraft:calcite
fill 49 54 586 49 57 586 minecraft:cobbled_deepslate
setblock 49 54 590 minecraft:calcite
fill 49 54 591 49 57 591 minecraft:cobbled_deepslate
setblock 51 54 558 minecraft:calcite
setblock 51 54 598 minecraft:calcite
fill 52 54 558 52 55 558 minecraft:cobbled_deepslate
fill 52 54 598 52 57 598 minecraft:cobbled_deepslate
setblock 53 54 597 minecraft:cobbled_deepslate
setblock 56 54 558 minecraft:calcite
setblock 56 54 598 minecraft:calcite
setblock 57 54 558 minecraft:cobbled_deepslate
fill 57 54 598 57 56 598 minecraft:cobbled_deepslate
setblock 75 54 559 minecraft:calcite
setblock 75 54 560 minecraft:cobbled_deepslate
setblock 76 54 558 minecraft:calcite
fill 76 54 559 76 56 559 minecraft:cobbled_deepslate
fill 77 54 558 77 57 558 minecraft:cobbled_deepslate
fill 78 54 567 79 55 568 minecraft:light_blue_stained_glass
setblock 79 54 560 minecraft:calcite
setblock 80 54 559 minecraft:calcite
setblock 80 54 560 minecraft:cobbled_deepslate
setblock 81 54 558 minecraft:calcite
setblock 81 54 559 minecraft:cobbled_deepslate
fill 82 54 558 82 55 558 minecraft:cobbled_deepslate
setblock 86 54 558 minecraft:calcite
setblock 87 54 558 minecraft:cobbled_deepslate
setblock 87 54 562 minecraft:calcite
setblock 87 54 563 minecraft:cobbled_deepslate
setblock 88 54 561 minecraft:calcite
fill 88 54 562 88 57 562 minecraft:cobbled_deepslate
setblock 88 54 566 minecraft:calcite
fill 88 54 567 88 57 567 minecraft:cobbled_deepslate
setblock 48 55 565 minecraft:calcite
setblock 48 55 585 minecraft:calcite
fill 48 55 586 48 58 586 minecraft:cobbled_deepslate
setblock 48 55 589 minecraft:cobbled_deepslate
setblock 48 55 590 minecraft:calcite
fill 48 55 591 48 58 591 minecraft:cobbled_deepslate
setblock 48 55 595 minecraft:calcite
setblock 49 55 585 minecraft:cobbled_deepslate
setblock 49 55 589 minecraft:calcite
fill 49 55 590 49 58 590 minecraft:cobbled_deepslate
fill 49 55 592 49 56 592 minecraft:cobbled_deepslate
setblock 50 55 588 minecraft:calcite
fill 50 55 589 50 58 589 minecraft:cobbled_deepslate
setblock 50 55 598 minecraft:calcite
fill 51 55 598 51 58 598 minecraft:cobbled_deepslate
setblock 55 55 558 minecraft:calcite
setblock 55 55 598 minecraft:calcite
setblock 56 55 558 minecraft:cobbled_deepslate
fill 56 55 598 56 58 598 minecraft:cobbled_deepslate
setblock 74 55 559 minecraft:calcite
setblock 75 55 558 minecraft:calcite
fill 75 55 559 75 56 559 minecraft:cobbled_deepslate
fill 76 55 558 76 58 558 minecraft:cobbled_deepslate
setblock 79 55 559 minecraft:calcite
setblock 80 55 558 minecraft:calcite
setblock 80 55 559 minecraft:cobbled_deepslate
setblock 81 55 558 minecraft:cobbled_deepslate
setblock 88 55 560 minecraft:calcite
fill 88 55 561 88 57 561 minecraft:cobbled_deepslate
setblock 88 55 565 minecraft:calcite
fill 88 55 566 88 58 566 minecraft:cobbled_deepslate
setblock 48 56 584 minecraft:calcite
fill 48 56 585 48 59 585 minecraft:cobbled_deepslate
setblock 48 56 589 minecraft:calcite
fill 48 56 590 48 59 590 minecraft:cobbled_deepslate
setblock 48 56 593 minecraft:cobbled_deepslate
setblock 48 56 594 minecraft:calcite
fill 48 56 595 48 59 595 minecraft:cobbled_deepslate
setblock 49 56 588 minecraft:calcite
fill 49 56 589 49 59 589 minecraft:cobbled_deepslate
setblock 49 56 593 minecraft:calcite
setblock 50 56 587 minecraft:calcite
fill 50 56 588 50 59 588 minecraft:cobbled_deepslate
fill 50 56 590 50 57 590 minecraft:cobbled_deepslate
fill 50 56 598 50 59 598 minecraft:cobbled_deepslate
setblock 54 56 598 minecraft:calcite
fill 55 56 598 55 59 598 minecraft:cobbled_deepslate
setblock 74 56 558 minecraft:calcite
fill 75 56 558 75 59 558 minecraft:cobbled_deepslate
fill 78 56 567 78 56 568 minecraft:light_blue_stained_glass
setblock 79 56 558 minecraft:calcite
setblock 79 56 567 minecraft:light_blue_stained_glass
setblock 80 56 558 minecraft:cobbled_deepslate
setblock 88 56 560 minecraft:cobbled_deepslate
setblock 88 56 564 minecraft:calcite
fill 88 56 565 88 59 565 minecraft:cobbled_deepslate
setblock 88 56 569 minecraft:calcite
setblock 88 56 589 minecraft:calcite
fill 88 56 590 88 58 591 minecraft:cobbled_deepslate
fill 48 57 584 48 60 584 minecraft:cobbled_deepslate
setblock 48 57 588 minecraft:calcite
fill 48 57 589 48 60 589 minecraft:cobbled_deepslate
setblock 48 57 593 minecraft:calcite
fill 48 57 594 49 59 594 minecraft:cobbled_deepslate
fill 48 57 596 48 58 596 minecraft:cobbled_deepslate
setblock 49 57 587 minecraft:calcite
fill 49 57 588 49 60 588 minecraft:cobbled_deepslate
setblock 49 57 592 minecraft:calcite
fill 49 57 593 49 60 593 minecraft:cobbled_deepslate
fill 50 57 587 50 60 587 minecraft:cobbled_deepslate
setblock 50 57 591 minecraft:calcite
fill 50 57 592 50 60 592 minecraft:cobbled_deepslate
setblock 53 57 598 minecraft:calcite
fill 54 57 598 54 60 598 minecraft:cobbled_deepslate
setblock 73 57 558 minecraft:calcite
fill 74 57 558 74 60 558 minecraft:cobbled_deepslate
fill 74 57 559 74 60 559 minecraft:deepslate
setblock 78 57 558 minecraft:calcite
setblock 79 57 558 minecraft:cobbled_deepslate
setblock 88 57 563 minecraft:calcite
fill 88 57 564 88 60 564 minecraft:cobbled_deepslate
setblock 88 57 568 minecraft:calcite
fill 88 57 569 88 60 569 minecraft:cobbled_deepslate
setblock 88 57 588 minecraft:calcite
fill 88 57 589 88 60 589 minecraft:cobbled_deepslate
setblock 88 57 592 minecraft:cobbled_deepslate
setblock 88 57 593 minecraft:calcite
setblock 48 58 587 minecraft:calcite
fill 48 58 588 48 61 588 minecraft:cobbled_deepslate
setblock 48 58 592 minecraft:calcite
fill 48 58 593 48 61 593 minecraft:cobbled_deepslate
setblock 48 58 597 minecraft:calcite
setblock 49 58 586 minecraft:calcite
fill 49 58 587 49 61 587 minecraft:cobbled_deepslate
setblock 49 58 591 minecraft:calcite
fill 49 58 592 49 61 592 minecraft:cobbled_deepslate
setblock 49 58 595 minecraft:cobbled_deepslate
fill 49 58 598 49 60 598 minecraft:cobbled_deepslate
setblock 50 58 590 minecraft:calcite
fill 50 58 591 50 61 591 minecraft:cobbled_deepslate
fill 50 58 593 50 59 593 minecraft:cobbled_deepslate
setblock 52 58 597 minecraft:cobbled_deepslate
setblock 52 58 598 minecraft:calcite
setblock 53 58 597 minecraft:calcite
fill 53 58 598 53 61 598 minecraft:cobbled_deepslate
fill 54 58 597 54 61 597 minecraft:cobbled_deepslate
fill 73 58 558 73 61 558 minecraft:cobbled_deepslate
setblock 77 58 558 minecraft:calcite
fill 78 58 558 78 61 558 minecraft:cobbled_deepslate
setblock 88 58 562 minecraft:calcite
fill 88 58 563 88 61 563 minecraft:cobbled_deepslate
setblock 88 58 567 minecraft:calcite
fill 88 58 568 88 61 568 minecraft:cobbled_deepslate
fill 88 58 570 88 59 570 minecraft:cobbled_deepslate
fill 88 58 588 88 61 588 minecraft:cobbled_deepslate
setblock 88 58 592 minecraft:calcite
fill 88 58 593 88 58 596 minecraft:cobbled_deepslate
fill 48 59 567 48 59 570 minecraft:cobbled_deepslate
setblock 48 59 586 minecraft:calcite
fill 48 59 587 48 62 587 minecraft:cobbled_deepslate
setblock 48 59 591 minecraft:calcite
fill 48 59 592 48 62 592 minecraft:cobbled_deepslate
setblock 48 59 596 minecraft:calcite
fill 48 59 597 48 61 598 minecraft:cobbled_deepslate
setblock 49 59 585 minecraft:calcite
fill 49 59 586 49 62 586 minecraft:cobbled_deepslate
setblock 49 59 590 minecraft:calcite
fill 49 59 591 49 62 591 minecraft:cobbled_deepslate
setblock 49 59 595 minecraft:calcite
fill 49 59 596 49 62 596 minecraft:cobbled_deepslate
setblock 50 59 589 minecraft:calcite
fill 50 59 590 51 61 590 minecraft:cobbled_deepslate
setblock 50 59 594 minecraft:calcite
fill 50 59 597 51 59 597 minecraft:cobbled_deepslate
fill 51 59 589 51 62 589 minecraft:cobbled_deepslate
fill 51 59 591 51 59 592 minecraft:cobbled_deepslate
setblock 51 59 598 minecraft:calcite
setblock 52 59 597 minecraft:calcite
fill 52 59 598 52 62 598 minecraft:cobbled_deepslate
fill 53 59 597 53 62 597 minecraft:cobbled_deepslate
setblock 56 59 598 minecraft:calcite
fill 72 59 558 72 62 558 minecraft:cobbled_deepslate
setblock 76 59 558 minecraft:calcite
fill 77 59 558 77 62 558 minecraft:cobbled_deepslate
fill 88 59 562 88 62 562 minecraft:cobbled_deepslate
setblock 88 59 566 minecraft:calcite
fill 88 59 567 88 62 567 minecraft:cobbled_deepslate
setblock 88 59 571 minecraft:calcite
fill 88 59 587 88 62 587 minecraft:cobbled_deepslate
setblock 88 59 590 minecraft:cobbled_deepslate
setblock 88 59 591 minecraft:calcite
fill 88 59 592 88 59 595 minecraft:cobbled_deepslate
setblock 88 59 596 minecraft:calcite
fill 88 59 597 88 61 598 minecraft:cobbled_deepslate
fill 48 60 566 48 60 569 minecraft:cobbled_deepslate
setblock 48 60 570 minecraft:calcite
fill 48 60 571 48 61 573 minecraft:cobbled_deepslate
fill 48 60 583 48 61 583 minecraft:cobbled_deepslate
setblock 48 60 585 minecraft:calcite
fill 48 60 586 48 63 586 minecraft:cobbled_deepslate
setblock 48 60 590 minecraft:calcite
fill 48 60 591 48 63 591 minecraft:cobbled_deepslate
setblock 48 60 594 minecraft:cobbled_deepslate
setblock 48 60 595 minecraft:calcite
fill 48 60 596 48 63 596 minecraft:cobbled_deepslate
fill 49 60 585 49 63 585 minecraft:cobbled_deepslate
setblock 49 60 589 minecraft:calcite
fill 49 60 590 49 63 590 minecraft:cobbled_deepslate
setblock 49 60 594 minecraft:calcite
fill 49 60 595 50 62 595 minecraft:cobbled_deepslate
fill 49 60 597 50 60 597 minecraft:cobbled_deepslate
setblock 50 60 560 minecraft:light[level=14]
setblock 50 60 568 minecraft:light[level=14]
setblock 50 60 576 minecraft:light[level=14]
setblock 50 60 584 minecraft:light[level=14]
fill 50 60 586 50 61 586 minecraft:cobbled_deepslate
setblock 50 60 588 minecraft:calcite
fill 50 60 589 50 63 589 minecraft:cobbled_deepslate
setblock 50 60 593 minecraft:calcite
fill 50 60 594 50 63 594 minecraft:cobbled_deepslate
fill 50 60 596 51 60 596 minecraft:cobbled_deepslate
setblock 50 60 598 minecraft:calcite
fill 51 60 588 51 63 588 minecraft:cobbled_deepslate
setblock 51 60 591 minecraft:cobbled_deepslate
setblock 51 60 592 minecraft:calcite
fill 51 60 593 51 63 593 minecraft:cobbled_deepslate
setblock 51 60 597 minecraft:calcite
fill 51 60 598 51 63 598 minecraft:cobbled_deepslate
setblock 52 60 596 minecraft:calcite
fill 52 60 597 52 63 597 minecraft:cobbled_deepslate
fill 53 60 596 53 63 596 minecraft:cobbled_deepslate
setblock 55 60 597 minecraft:cobbled_deepslate
setblock 55 60 598 minecraft:calcite
fill 56 60 598 56 63 598 minecraft:cobbled_deepslate
setblock 58 60 560 minecraft:light[level=14]
setblock 58 60 568 minecraft:light[level=14]
setblock 58 60 576 minecraft:light[level=14]
setblock 58 60 584 minecraft:light[level=14]
setblock 58 60 592 minecraft:light[level=14]
setblock 66 60 560 minecraft:light[level=14]
setblock 66 60 568 minecraft:light[level=14]
setblock 66 60 576 minecraft:light[level=14]
setblock 66 60 584 minecraft:light[level=14]
setblock 66 60 592 minecraft:light[level=14]
fill 71 60 558 71 63 558 minecraft:cobbled_deepslate
setblock 73 60 559 minecraft:deepslate
fill 73 60 598 74 60 598 minecraft:cobbled_deepslate
fill 74 60 560 74 61 560 minecraft:deepslate
setblock 74 60 568 minecraft:light[level=14]
setblock 74 60 576 minecraft:light[level=14]
setblock 74 60 584 minecraft:light[level=14]
setblock 74 60 592 minecraft:light[level=14]
setblock 75 60 558 minecraft:calcite
fill 75 60 559 75 61 559 minecraft:deepslate
setblock 75 60 598 minecraft:calcite
fill 76 60 558 76 63 558 minecraft:cobbled_deepslate
setblock 82 60 560 minecraft:light[level=14]
setblock 82 60 568 minecraft:light[level=14]
setblock 82 60 576 minecraft:light[level=14]
setblock 82 60 584 minecraft:light[level=14]
setblock 82 60 592 minecraft:light[level=14]
setblock 87 60 591 minecraft:calcite
fill 87 60 592 88 60 594 minecraft:cobbled_deepslate
fill 87 60 598 87 62 598 minecraft:cobbled_deepslate
fill 88 60 558 88 60 559 minecraft:cobbled_deepslate
fill 88 60 561 88 63 561 minecraft:cobbled_deepslate
setblock 88 60 565 minecraft:calcite
fill 88 60 566 88 63 566 minecraft:cobbled_deepslate
setblock 88 60 570 minecraft:calcite
fill 88 60 571 88 62 572 minecraft:cobbled_deepslate
fill 88 60 586 88 63 586 minecraft:cobbled_deepslate
setblock 88 60 590 minecraft:calcite
fill 88 60 591 88 63 591 minecraft:cobbled_deepslate
setblock 88 60 595 minecraft:calcite
fill 88 60 596 88 63 596 minecraft:cobbled_deepslate
fill 48 61 565 48 61 568 minecraft:cobbled_deepslate
setblock 48 61 569 minecraft:calcite
fill 48 61 570 49 63 570 minecraft:cobbled_deepslate
setblock 48 61 574 minecraft:calcite
fill 48 61 575 48 63 576 minecraft:cobbled_deepslate
fill 48 61 582 48 62 582 minecraft:cobbled_deepslate
setblock 48 61 584 minecraft:calcite
fill 48 61 585 48 64 585 minecraft:cobbled_deepslate
setblock 48 61 589 minecraft:calcite
fill 48 61 590 48 64 590 minecraft:cobbled_deepslate
setblock 48 61 594 minecraft:calcite
fill 48 61 595 48 64 595 minecraft:cobbled_deepslate
setblock 49 61 568 minecraft:calcite
fill 49 61 569 49 64 569 minecraft:cobbled_deepslate
fill 49 61 571 49 61 572 minecraft:cobbled_deepslate
setblock 49 61 573 minecraft:calcite
fill 49 61 584 49 64 584 minecraft:cobbled_deepslate
setblock 49 61 588 minecraft:calcite
fill 49 61 589 49 64 589 minecraft:cobbled_deepslate
setblock 49 61 593 minecraft:calcite
fill 49 61 594 49 64 594 minecraft:cobbled_deepslate
setblock 49 61 597 minecraft:cobbled_deepslate
setblock 49 61 598 minecraft:calcite
setblock 50 61 587 minecraft:calcite
fill 50 61 588 50 64 588 minecraft:cobbled_deepslate
setblock 50 61 592 minecraft:calcite
fill 50 61 593 50 64 593 minecraft:cobbled_deepslate
setblock 50 61 596 minecraft:cobbled_deepslate
setblock 50 61 597 minecraft:calcite
fill 50 61 598 50 64 598 minecraft:cobbled_deepslate
setblock 51 61 591 minecraft:calcite
fill 51 61 592 51 64 592 minecraft:cobbled_deepslate
fill 51 61 594 51 61 595 minecraft:cobbled_deepslate
setblock 51 61 596 minecraft:calcite
fill 51 61 597 51 64 597 minecraft:cobbled_deepslate
fill 52 61 596 52 64 596 minecraft:cobbled_deepslate
fill 54 61 596 54 62 596 minecraft:cobbled_deepslate
setblock 54 61 598 minecraft:calcite
setblock 55 61 597 minecraft:calcite
fill 55 61 598 55 64 598 minecraft:cobbled_deepslate
fill 70 61 558 70 64 558 minecraft:cobbled_deepslate
fill 70 61 598 73 61 598 minecraft:cobbled_deepslate
setblock 73 61 559 minecraft:calcite
setblock 73 61 560 minecraft:deepslate
setblock 74 61 558 minecraft:calcite
fill 74 61 559 74 64 559 minecraft:cobbled_deepslate
setblock 74 61 598 minecraft:calcite
fill 75 61 558 75 64 558 minecraft:cobbled_deepslate
setblock 75 61 560 minecraft:deepslate
fill 75 61 598 77 62 598 minecraft:cobbled_deepslate
fill 85 61 598 86 63 598 minecraft:cobbled_deepslate
fill 87 61 558 88 61 558 minecraft:cobbled_deepslate
setblock 87 61 569 minecraft:light_blue_stained_glass
setblock 87 61 589 minecraft:cobbled_deepslate
setblock 87 61 590 minecraft:calcite
fill 87 61 591 87 61 594 minecraft:cobbled_deepslate
setblock 87 61 595 minecraft:calcite
fill 87 61 596 87 63 597 minecraft:cobbled_deepslate
setblock 88 61 559 minecraft:calcite
fill 88 61 560 88 64 560 minecraft:cobbled_deepslate
setblock 88 61 564 minecraft:calcite
fill 88 61 565 88 64 565 minecraft:cobbled_deepslate
setblock 88 61 569 minecraft:calcite
fill 88 61 570 88 64 570 minecraft:cobbled_deepslate
setblock 88 61 573 minecraft:cobbled_deepslate
setblock 88 61 574 minecraft:calcite
setblock 88 61 589 minecraft:calcite
fill 88 61 590 88 64 590 minecraft:cobbled_deepslate
fill 88 61 592 88 61 593 minecraft:cobbled_deepslate
setblock 88 61 594 minecraft:calcite
fill 88 61 595 88 64 595 minecraft:cobbled_deepslate
fill 48 62 565 48 62 567 minecraft:cobbled_deepslate
setblock 48 62 568 minecraft:calcite
fill 48 62 569 48 65 569 minecraft:cobbled_deepslate
fill 48 62 571 48 62 572 minecraft:cobbled_deepslate
setblock 48 62 573 minecraft:calcite
fill 48 62 574 49 64 574 minecraft:cobbled_deepslate
setblock 48 62 577 minecraft:cobbled_deepslate
setblock 48 62 578 minecraft:calcite
fill 48 62 579 48 63 581 minecraft:cobbled_deepslate
setblock 48 62 583 minecraft:calcite
fill 48 62 584 48 65 584 minecraft:cobbled_deepslate
setblock 48 62 588 minecraft:calcite
fill 48 62 589 48 65 589 minecraft:cobbled_deepslate
setblock 48 62 593 minecraft:calcite
fill 48 62 594 48 65 594 minecraft:cobbled_deepslate
setblock 48 62 597 minecraft:cobbled_deepslate
setblock 48 62 598 minecraft:calcite
fill 49 62 558 52 62 558 minecraft:cobbled_deepslate
setblock 49 62 567 minecraft:calcite
fill 49 62 568 49 65 568 minecraft:cobbled_deepslate
setblock 49 62 571 minecraft:cobbled_deepslate
setblock 49 62 572 minecraft:calcite
fill 49 62 573 49 65 573 minecraft:cobbled_deepslate
fill 49 62 575 49 62 576 minecraft:cobbled_deepslate
setblock 49 62 577 minecraft:calcite
fill 49 62 583 49 65 583 minecraft:cobbled_deepslate
setblock 49 62 587 minecraft:calcite
fill 49 62 588 49 65 588 minecraft:cobbled_deepslate
setblock 49 62 592 minecraft:calcite
fill 49 62 593 49 65 593 minecraft:cobbled_deepslate
setblock 49 62 597 minecraft:calcite
fill 49 62 598 49 65 598 minecraft:cobbled_deepslate
setblock 50 62 571 minecraft:calcite
fill 50 62 572 50 65 572 minecraft:cobbled_deepslate
setblock 50 62 585 minecraft:cobbled_deepslate
setblock 50 62 586 minecraft:calcite
fill 50 62 587 50 65 587 minecraft:cobbled_deepslate
setblock 50 62 590 minecraft:cobbled_deepslate
setblock 50 62 591 minecraft:calcite
fill 50 62 592 50 65 592 minecraft:cobbled_deepslate
setblock 50 62 596 minecraft:calcite
fill 50 62 597 50 65 597 minecraft:cobbled_deepslate
setblock 51 62 590 minecraft:calcite
fill 51 62 591 51 65 591 minecraft:cobbled_deepslate
setblock 51 62 594 minecraft:cobbled_deepslate
setblock 51 62 595 minecraft:calcite
fill 51 62 596 51 65 596 minecraft:cobbled_deepslate
fill 52 62 595 53 64 595 minecraft:cobbled_deepslate
setblock 53 62 598 minecraft:calcite
setblock 54 62 597 minecraft:calcite
fill 54 62 598 54 65 598 minecraft:cobbled_deepslate
fill 55 62 597 56 64 597 minecraft:cobbled_deepslate
setblock 57 62 598 minecraft:cobbled_deepslate
setblock 68 62 558 minecraft:calcite
setblock 68 62 598 minecraft:calcite
fill 69 62 558 69 65 558 minecraft:cobbled_deepslate
fill 69 62 598 72 62 598 minecraft:cobbled_deepslate
setblock 71 62 559 minecraft:cobbled_deepslate
fill 71 62 597 73 62 597 minecraft:cobbled_deepslate
setblock 72 62 559 minecraft:calcite
setblock 73 62 558 minecraft:calcite
fill 73 62 559 73 65 559 minecraft:cobbled_deepslate
setblock 73 62 598 minecraft:calcite
fill 74 62 558 74 65 558 minecraft:cobbled_deepslate
setblock 74 62 597 minecraft:calcite
fill 74 62 598 74 65 598 minecraft:cobbled_deepslate
fill 75 62 559 75 63 559 minecraft:cobbled_deepslate
fill 75 62 597 75 65 597 minecraft:cobbled_deepslate
setblock 78 62 558 minecraft:calcite
setblock 78 62 598 minecraft:calcite
fill 79 62 558 79 65 558 minecraft:cobbled_deepslate
fill 79 62 598 82 62 598 minecraft:cobbled_deepslate
setblock 83 62 598 minecraft:calcite
fill 84 62 558 87 62 558 minecraft:cobbled_deepslate
fill 84 62 598 84 65 598 minecraft:cobbled_deepslate
fill 85 62 568 86 65 570 minecraft:light_blue_stained_glass
fill 85 62 597 86 64 597 minecraft:cobbled_deepslate
fill 87 62 567 87 62 568 minecraft:cobbled_deepslate
setblock 87 62 569 minecraft:calcite
fill 87 62 570 87 64 571 minecraft:cobbled_deepslate
setblock 87 62 589 minecraft:calcite
fill 87 62 590 87 62 593 minecraft:cobbled_deepslate
setblock 87 62 594 minecraft:calcite
fill 87 62 595 87 65 595 minecraft:cobbled_deepslate
setblock 88 62 558 minecraft:calcite
fill 88 62 559 88 65 559 minecraft:cobbled_deepslate
setblock 88 62 563 minecraft:calcite
fill 88 62 564 88 65 564 minecraft:cobbled_deepslate
setblock 88 62 568 minecraft:calcite
fill 88 62 569 88 65 569 minecraft:cobbled_deepslate
setblock 88 62 573 minecraft:calcite
fill 88 62 574 88 63 576 minecraft:cobbled_deepslate
fill 88 62 585 88 64 585 minecraft:cobbled_deepslate
setblock 88 62 588 minecraft:calcite
fill 88 62 589 88 65 589 minecraft:cobbled_deepslate
setblock 88 62 592 minecraft:cobbled_deepslate
setblock 88 62 593 minecraft:calcite
fill 88 62 594 88 65 594 minecraft:cobbled_deepslate
setblock 88 62 597 minecraft:cobbled_deepslate
setblock 88 62 598 minecraft:calcite
fill 48 63 558 48 65 559 minecraft:cobbled_deepslate
fill 48 63 564 48 63 566 minecraft:cobbled_deepslate
setblock 48 63 567 minecraft:calcite
fill 48 63 568 48 66 568 minecraft:cobbled_deepslate
setblock 48 63 571 minecraft:cobbled_deepslate
setblock 48 63 572 minecraft:calcite
fill 48 63 573 48 66 573 minecraft:cobbled_deepslate
setblock 48 63 577 minecraft:calcite
fill 48 63 578 49 65 578 minecraft:cobbled_deepslate
setblock 48 63 582 minecraft:calcite
fill 48 63 583 48 66 583 minecraft:cobbled_deepslate
setblock 48 63 587 minecraft:calcite
fill 48 63 588 48 66 588 minecraft:cobbled_deepslate
setblock 48 63 592 minecraft:calcite
fill 48 63 593 48 66 593 minecraft:cobbled_deepslate
setblock 48 63 597 minecraft:calcite
fill 48 63 598 48 66 598 minecraft:cobbled_deepslate
fill 49 63 558 51 63 558 minecraft:cobbled_deepslate
fill 49 63 567 49 65 567 minecraft:cobbled_deepslate
setblock 49 63 571 minecraft:calcite
fill 49 63 572 49 66 572 minecraft:cobbled_deepslate
setblock 49 63 575 minecraft:cobbled_deepslate
setblock 49 63 576 minecraft:calcite
fill 49 63 577 49 66 577 minecraft:cobbled_deepslate
fill 49 63 579 49 63 580 minecraft:cobbled_deepslate
setblock 49 63 581 minecraft:calcite
fill 49 63 582 49 66 582 minecraft:cobbled_deepslate
setblock 49 63 586 minecraft:calcite
fill 49 63 587 49 66 587 minecraft:cobbled_deepslate
setblock 49 63 591 minecraft:calcite
fill 49 63 592 49 66 592 minecraft:cobbled_deepslate
setblock 49 63 595 minecraft:cobbled_deepslate
setblock 49 63 596 minecraft:calcite
fill 49 63 597 49 66 597 minecraft:cobbled_deepslate
setblock 50 63 570 minecraft:calcite
fill 50 63 571 50 66 571 minecraft:cobbled_deepslate
fill 50 63 573 50 63 574 minecraft:cobbled_deepslate
setblock 50 63 575 minecraft:calcite
fill 50 63 576 50 66 576 minecraft:cobbled_deepslate
setblock 50 63 585 minecraft:calcite
fill 50 63 586 50 66 586 minecraft:cobbled_deepslate
setblock 50 63 590 minecraft:calcite
fill 50 63 591 50 66 591 minecraft:cobbled_deepslate
setblock 50 63 595 minecraft:calcite
fill 50 63 596 50 66 596 minecraft:cobbled_deepslate
setblock 51 63 589 minecraft:calcite
fill 51 63 590 51 66 590 minecraft:cobbled_deepslate
setblock 51 63 594 minecraft:calcite
fill 51 63 595 51 66 595 minecraft:cobbled_deepslate
setblock 52 63 558 minecraft:calcite
setblock 52 63 598 minecraft:calcite
fill 53 63 558 53 66 558 minecraft:cobbled_deepslate
setblock 53 63 597 minecraft:calcite
fill 53 63 598 53 66 598 minecraft:cobbled_deepslate
setblock 54 63 596 minecraft:calcite
fill 54 63 597 54 66 597 minecraft:cobbled_deepslate
fill 55 63 596 55 64 596 minecraft:cobbled_deepslate
setblock 57 63 598 minecraft:calcite
setblock 67 63 558 minecraft:calcite
setblock 67 63 598 minecraft:calcite
fill 68 63 558 68 66 558 minecraft:cobbled_deepslate
fill 68 63 598 71 63 598 minecraft:cobbled_deepslate
fill 69 63 597 72 63 597 minecraft:cobbled_deepslate
setblock 70 63 559 minecraft:cobbled_deepslate
setblock 71 63 559 minecraft:calcite
setblock 72 63 558 minecraft:calcite
fill 72 63 559 72 66 559 minecraft:cobbled_deepslate
setblock 72 63 598 minecraft:calcite
fill 73 63 558 73 66 558 minecraft:cobbled_deepslate
setblock 73 63 597 minecraft:calcite
fill 73 63 598 73 66 598 minecraft:cobbled_deepslate
fill 74 63 597 74 66 597 minecraft:cobbled_deepslate
fill 75 63 598 76 63 598 minecraft:cobbled_deepslate
setblock 76 63 559 minecraft:calcite
fill 76 63 597 77 63 597 minecraft:cobbled_deepslate
setblock 77 63 558 minecraft:calcite
setblock 77 63 598 minecraft:calcite
fill 78 63 558 78 66 558 minecraft:cobbled_deepslate
fill 78 63 598 81 63 598 minecraft:cobbled_deepslate
fill 80 63 558 81 63 558 minecraft:cobbled_deepslate
setblock 82 63 558 minecraft:calcite
setblock 82 63 598 minecraft:calcite
fill 83 63 558 86 63 558 minecraft:cobbled_deepslate
fill 83 63 568 84 64 570 minecraft:light_blue_stained_glass
setblock 83 63 597 minecraft:calcite
fill 83 63 598 83 66 598 minecraft:cobbled_deepslate
fill 84 63 597 84 66 597 minecraft:cobbled_deepslate
fill 85 63 567 86 64 567 minecraft:light_blue_stained_glass
fill 85 63 571 86 64 571 minecraft:light_blue_stained_glass
fill 86 63 592 86 63 593 minecraft:cobbled_deepslate
setblock 86 63 594 minecraft:calcite
fill 86 63 595 86 65 596 minecraft:cobbled_deepslate
setblock 87 63 558 minecraft:calcite
setblock 87 63 567 minecraft:cobbled_deepslate
setblock 87 63 568 minecraft:calcite
fill 87 63 569 87 66 569 minecraft:cobbled_deepslate
setblock 87 63 572 minecraft:cobbled_deepslate
setblock 87 63 573 minecraft:calcite
setblock 87 63 588 minecraft:calcite
fill 87 63 589 87 63 592 minecraft:cobbled_deepslate
setblock 87 63 593 minecraft:calcite
fill 87 63 594 87 66 594 minecraft:cobbled_deepslate
setblock 87 63 598 minecraft:calcite
fill 88 63 558 88 66 558 minecraft:cobbled_deepslate
setblock 88 63 562 minecraft:calcite
fill 88 63 563 88 66 563 minecraft:cobbled_deepslate
setblock 88 63 567 minecraft:calcite
fill 88 63 568 88 66 568 minecraft:cobbled_deepslate
setblock 88 63 571 minecraft:cobbled_deepslate
setblock 88 63 572 minecraft:calcite
fill 88 63 573 88 66 573 minecraft:cobbled_deepslate
setblock 88 63 577 minecraft:calcite
fill 88 63 578 88 66 578 minecraft:cobbled_deepslate
fill 88 63 584 88 65 584 minecraft:cobbled_deepslate
setblock 88 63 587 minecraft:calcite
fill 88 63 588 88 66 588 minecraft:cobbled_deepslate
setblock 88 63 592 minecraft:calcite
fill 88 63 593 88 66 593 minecraft:cobbled_deepslate
setblock 88 63 597 minecraft:calcite
fill 88 63 598 88 66 598 minecraft:cobbled_deepslate
setblock 48 64 560 minecraft:cobbled_deepslate
fill 48 64 564 48 64 565 minecraft:cobbled_deepslate
setblock 48 64 566 minecraft:calcite
fill 48 64 567 48 67 567 minecraft:cobbled_deepslate
setblock 48 64 570 minecraft:cobbled_deepslate
setblock 48 64 571 minecraft:calcite
fill 48 64 572 48 67 572 minecraft:cobbled_deepslate
setblock 48 64 575 minecraft:cobbled_deepslate
setblock 48 64 576 minecraft:calcite
fill 48 64 577 48 67 577 minecraft:cobbled_deepslate
fill 48 64 579 48 64 580 minecraft:cobbled_deepslate
setblock 48 64 581 minecraft:calcite
fill 48 64 582 48 67 582 minecraft:cobbled_deepslate
setblock 48 64 586 minecraft:calcite
fill 48 64 587 48 67 587 minecraft:cobbled_deepslate
setblock 48 64 591 minecraft:calcite
fill 48 64 592 48 67 592 minecraft:cobbled_deepslate
setblock 48 64 596 minecraft:calcite
fill 48 64 597 48 67 597 minecraft:cobbled_deepslate
fill 49 64 558 50 64 558 minecraft:cobbled_deepslate
setblock 49 64 570 minecraft:calcite
fill 49 64 571 49 67 571 minecraft:cobbled_deepslate
setblock 49 64 575 minecraft:calcite
fill 49 64 576 49 67 576 minecraft:cobbled_deepslate
setblock 49 64 579 minecraft:cobbled_deepslate
setblock 49 64 580 minecraft:calcite
fill 49 64 581 49 67 581 minecraft:cobbled_deepslate
setblock 49 64 585 minecraft:calcite
fill 49 64 586 49 67 586 minecraft:cobbled_deepslate
setblock 49 64 590 minecraft:calcite
fill 49 64 591 49 67 591 minecraft:cobbled_deepslate
setblock 49 64 595 minecraft:calcite
fill 49 64 596 49 67 596 minecraft:cobbled_deepslate
fill 50 64 570 50 66 570 minecraft:cobbled_deepslate
setblock 50 64 573 minecraft:cobbled_deepslate
setblock 50 64 574 minecraft:calcite
fill 50 64 575 50 67 575 minecraft:cobbled_deepslate
fill 50 64 577 50 64 578 minecraft:cobbled_deepslate
setblock 50 64 579 minecraft:calcite
setblock 50 64 584 minecraft:calcite
fill 50 64 585 50 66 585 minecraft:cobbled_deepslate
setblock 50 64 589 minecraft:calcite
fill 50 64 590 50 67 590 minecraft:cobbled_deepslate
setblock 50 64 594 minecraft:calcite
fill 50 64 595 50 67 595 minecraft:cobbled_deepslate
setblock 51 64 558 minecraft:calcite
setblock 51 64 588 minecraft:calcite
fill 51 64 589 51 65 589 minecraft:cobbled_deepslate
setblock 51 64 593 minecraft:calcite
fill 51 64 594 51 67 594 minecraft:cobbled_deepslate
setblock 51 64 598 minecraft:calcite
fill 52 64 558 52 67 558 minecraft:cobbled_deepslate
setblock 52 64 597 minecraft:calcite
fill 52 64 598 52 67 598 minecraft:cobbled_deepslate
setblock 53 64 596 minecraft:calcite
fill 53 64 597 53 67 597 minecraft:cobbled_deepslate
fill 54 64 596 54 66 596 minecraft:cobbled_deepslate
setblock 56 64 598 minecraft:calcite
fill 57 64 598 57 67 598 minecraft:cobbled_deepslate
setblock 65 64 598 minecraft:cobbled_deepslate
setblock 66 64 558 minecraft:calcite
setblock 66 64 598 minecraft:calcite
fill 67 64 558 67 67 558 minecraft:cobbled_deepslate
setblock 67 64 597 minecraft:calcite
fill 67 64 598 70 64 598 minecraft:cobbled_deepslate
fill 68 64 559 69 64 559 minecraft:cobbled_deepslate
fill 68 64 597 71 64 597 minecraft:cobbled_deepslate
setblock 70 64 559 minecraft:calcite
fill 70 64 596 72 64 596 minecraft:cobbled_deepslate
setblock 71 64 558 minecraft:calcite
fill 71 64 559 71 67 559 minecraft:cobbled_deepslate
setblock 71 64 598 minecraft:calcite
fill 72 64 558 72 67 558 minecraft:cobbled_deepslate
setblock 72 64 597 minecraft:calcite
fill 72 64 598 72 67 598 minecraft:cobbled_deepslate
setblock 73 64 596 minecraft:calcite
fill 73 64 597 73 67 597 minecraft:cobbled_deepslate
setblock 75 64 559 minecraft:calcite
setblock 75 64 598 minecraft:cobbled_deepslate
setblock 76 64 558 minecraft:calcite
fill 76 64 559 76 67 559 minecraft:cobbled_deepslate
setblock 76 64 597 minecraft:cobbled_deepslate
setblock 76 64 598 minecraft:calcite
fill 77 64 558 77 67 558 minecraft:cobbled_deepslate
setblock 77 64 597 minecraft:calcite
fill 77 64 598 80 64 598 minecraft:cobbled_deepslate
fill 78 64 597 81 64 597 minecraft:cobbled_deepslate
setblock 80 64 558 minecraft:cobbled_deepslate
setblock 81 64 558 minecraft:calcite
fill 81 64 569 82 64 569 minecraft:light_blue_stained_glass
setblock 81 64 598 minecraft:calcite
fill 82 64 558 85 64 558 minecraft:cobbled_deepslate
setblock 82 64 597 minecraft:calcite
fill 82 64 598 82 67 598 minecraft:cobbled_deepslate
fill 83 64 597 83 67 597 minecraft:cobbled_deepslate
fill 84 64 596 85 66 596 minecraft:cobbled_deepslate
setblock 85 64 598 minecraft:cobbled_deepslate
setblock 86 64 558 minecraft:calcite
fill 86 64 591 86 64 592 minecraft:cobbled_deepslate
setblock 86 64 593 minecraft:calcite
fill 86 64 594 86 67 594 minecraft:cobbled_deepslate
setblock 86 64 598 minecraft:calcite
fill 87 64 558 87 66 559 minecraft:cobbled_deepslate
setblock 87 64 567 minecraft:calcite
fill 87 64 568 87 65 568 minecraft:cobbled_deepslate
setblock 87 64 572 minecraft:calcite
fill 87 64 573 87 65 575 minecraft:cobbled_deepslate
fill 87 64 588 87 64 591 minecraft:cobbled_deepslate
setblock 87 64 592 minecraft:calcite
fill 87 64 593 87 67 593 minecraft:cobbled_deepslate
setblock 87 64 596 minecraft:cobbled_deepslate
setblock 87 64 597 minecraft:calcite
fill 87 64 598 87 67 598 minecraft:cobbled_deepslate
setblock 88 64 561 minecraft:calcite
fill 88 64 562 88 67 562 minecraft:cobbled_deepslate
setblock 88 64 566 minecraft:calcite
fill 88 64 567 88 67 567 minecraft:cobbled_deepslate
setblock 88 64 571 minecraft:calcite
fill 88 64 572 88 67 572 minecraft:cobbled_deepslate
fill 88 64 574 88 64 575 minecraft:cobbled_deepslate
setblock 88 64 576 minecraft:calcite
fill 88 64 577 88 67 577 minecraft:cobbled_deepslate
fill 88 64 579 88 64 580 minecraft:cobbled_deepslate
setblock 88 64 581 minecraft:calcite
fill 88 64 582 88 66 583 minecraft:cobbled_deepslate
setblock 88 64 586 minecraft:calcite
fill 88 64 587 88 67 587 minecraft:cobbled_deepslate
setblock 88 64 591 minecraft:calcite
fill 88 64 592 88 67 592 minecraft:cobbled_deepslate
setblock 88 64 596 minecraft:calcite
fill 88 64 597 88 67 597 minecraft:cobbled_deepslate
setblock 48 65 560 minecraft:calcite
fill 48 65 561 48 68 561 minecraft:cobbled_deepslate
setblock 48 65 564 minecraft:cobbled_deepslate
setblock 48 65 565 minecraft:calcite
fill 48 65 566 48 67 566 minecraft:cobbled_deepslate
setblock 48 65 570 minecraft:calcite
fill 48 65 571 48 68 571 minecraft:cobbled_deepslate
setblock 48 65 574 minecraft:cobbled_deepslate
setblock 48 65 575 minecraft:calcite
fill 48 65 576 48 68 576 minecraft:cobbled_deepslate
setblock 48 65 579 minecraft:cobbled_deepslate
setblock 48 65 580 minecraft:calcite
fill 48 65 581 48 68 581 minecraft:cobbled_deepslate
setblock 48 65 585 minecraft:calcite
fill 48 65 586 48 68 586 minecraft:cobbled_deepslate
setblock 48 65 590 minecraft:calcite
fill 48 65 591 48 68 591 minecraft:cobbled_deepslate
setblock 48 65 595 minecraft:calcite
fill 48 65 596 48 68 596 minecraft:cobbled_deepslate
setblock 49 65 558 minecraft:cobbled_deepslate
setblock 49 65 569 minecraft:calcite
fill 49 65 570 49 68 570 minecraft:cobbled_deepslate
setblock 49 65 574 minecraft:calcite
fill 49 65 575 49 68 575 minecraft:cobbled_deepslate
setblock 49 65 579 minecraft:calcite
fill 49 65 580 50 67 580 minecraft:cobbled_deepslate
setblock 49 65 584 minecraft:calcite
fill 49 65 585 49 68 585 minecraft:cobbled_deepslate
setblock 49 65 589 minecraft:calcite
fill 49 65 590 49 68 590 minecraft:cobbled_deepslate
setblock 49 65 594 minecraft:calcite
fill 49 65 595 49 68 595 minecraft:cobbled_deepslate
setblock 50 65 558 minecraft:calcite
setblock 50 65 573 minecraft:calcite
fill 50 65 574 51 67 574 minecraft:cobbled_deepslate
setblock 50 65 577 minecraft:cobbled_deepslate
setblock 50 65 578 minecraft:calcite
fill 50 65 579 50 68 579 minecraft:cobbled_deepslate
fill 50 65 581 50 65 582 minecraft:cobbled_deepslate
setblock 50 65 583 minecraft:calcite
fill 50 65 584 50 66 584 minecraft:cobbled_deepslate
setblock 50 65 588 minecraft:calcite
fill 50 65 589 50 67 589 minecraft:cobbled_deepslate
setblock 50 65 593 minecraft:calcite
fill 50 65 594 50 68 594 minecraft:cobbled_deepslate
setblock 50 65 598 minecraft:calcite
fill 51 65 558 51 68 558 minecraft:cobbled_deepslate
fill 51 65 573 51 66 573 minecraft:cobbled_deepslate
fill 51 65 575 51 65 576 minecraft:cobbled_deepslate
setblock 51 65 592 minecraft:calcite
fill 51 65 593 51 67 593 minecraft:cobbled_deepslate
setblock 51 65 597 minecraft:calcite
fill 51 65 598 51 68 598 minecraft:cobbled_deepslate
setblock 52 65 595 minecraft:cobbled_deepslate
setblock 52 65 596 minecraft:calcite
fill 52 65 597 52 68 597 minecraft:cobbled_deepslate
setblock 53 65 595 minecraft:calcite
fill 53 65 596 53 67 596 minecraft:cobbled_deepslate
setblock 55 65 597 minecraft:cobbled_deepslate
setblock 55 65 598 minecraft:calcite
setblock 56 65 597 minecraft:calcite
fill 56 65 598 56 68 598 minecraft:cobbled_deepslate
setblock 58 65 598 minecraft:cobbled_deepslate
setblock 64 65 598 minecraft:cobbled_deepslate
setblock 65 65 558 minecraft:calcite
setblock 65 65 598 minecraft:calcite
fill 66 65 558 66 68 558 minecraft:cobbled_deepslate
setblock 66 65 597 minecraft:calcite
fill 66 65 598 69 65 598 minecraft:cobbled_deepslate
fill 67 65 559 68 65 559 minecraft:cobbled_deepslate
fill 67 65 597 70 65 597 minecraft:cobbled_deepslate
setblock 69 65 559 minecraft:calcite
fill 69 65 596 71 65 596 minecraft:cobbled_deepslate
setblock 70 65 558 minecraft:calcite
fill 70 65 559 70 68 559 minecraft:cobbled_deepslate
setblock 70 65 598 minecraft:calcite
fill 71 65 558 71 68 558 minecraft:cobbled_deepslate
fill 71 65 560 71 66 560 minecraft:cobbled_deepslate
setblock 71 65 597 minecraft:calcite
fill 71 65 598 71 68 598 minecraft:cobbled_deepslate
setblock 72 65 596 minecraft:calcite
fill 72 65 597 72 68 597 minecraft:cobbled_deepslate
fill 73 65 596 74 65 596 minecraft:cobbled_deepslate
setblock 74 65 559 minecraft:calcite
setblock 75 65 558 minecraft:calcite
fill 75 65 559 75 68 559 minecraft:cobbled_deepslate
setblock 75 65 598 minecraft:calcite
fill 76 65 558 76 68 558 minecraft:cobbled_deepslate
setblock 76 65 597 minecraft:calcite
fill 76 65 598 79 65 598 minecraft:cobbled_deepslate
fill 77 65 597 80 65 597 minecraft:cobbled_deepslate
setblock 80 65 558 minecraft:calcite
setblock 80 65 598 minecraft:calcite
fill 81 65 558 84 65 558 minecraft:cobbled_deepslate
setblock 81 65 597 minecraft:calcite
fill 81 65 598 81 68 598 minecraft:cobbled_deepslate
fill 82 65 597 82 68 597 minecraft:cobbled_deepslate
fill 83 65 569 84 65 569 minecraft:light_blue_stained_glass
fill 83 65 596 83 68 596 minecraft:cobbled_deepslate
setblock 84 65 568 minecraft:light_blue_stained_glass
setblock 84 65 570 minecraft:light_blue_stained_glass
setblock 85 65 558 minecraft:calcite
fill 85 65 559 86 67 559 minecraft:cobbled_deepslate
setblock 85 65 597 minecraft:cobbled_deepslate
setblock 85 65 598 minecraft:calcite
fill 86 65 558 86 68 558 minecraft:cobbled_deepslate
setblock 86 65 591 minecraft:cobbled_deepslate
setblock 86 65 592 minecraft:calcite
fill 86 65 593 86 68 593 minecraft:cobbled_deepslate
setblock 86 65 597 minecraft:calcite
fill 86 65 598 86 68 598 minecraft:cobbled_deepslate
setblock 87 65 560 minecraft:cobbled_deepslate
setblock 87 65 567 minecraft:light_blue_stained_glass
setblock 87 65 570 minecraft:cobbled_deepslate
setblock 87 65 571 minecraft:calcite
fill 87 65 572 87 68 572 minecraft:cobbled_deepslate
setblock 87 65 576 minecraft:calcite
fill 87 65 577 87 68 577 minecraft:cobbled_deepslate
fill 87 65 587 87 65 590 minecraft:cobbled_deepslate
setblock 87 65 591 minecraft:calcite
fill 87 65 592 87 68 592 minecraft:cobbled_deepslate
setblock 87 65 596 minecraft:calcite
fill 87 65 597 87 68 597 minecraft:cobbled_deepslate
setblock 88 65 560 minecraft:calcite
fill 88 65 561 88 68 561 minecraft:cobbled_deepslate
setblock 88 65 565 minecraft:calcite
fill 88 65 566 88 68 566 minecraft:cobbled_deepslate
setblock 88 65 570 minecraft:calcite
fill 88 65 571 88 68 571 minecraft:cobbled_deepslate
setblock 88 65 574 minecraft:cobbled_deepslate
setblock 88 65 575 minecraft:calcite
fill 88 65 576 88 68 576 minecraft:cobbled_deepslate
setblock 88 65 579 minecraft:cobbled_deepslate
setblock 88 65 580 minecraft:calcite
fill 88 65 581 88 68 581 minecraft:cobbled_deepslate
setblock 88 65 585 minecraft:calcite
fill 88 65 586 88 68 586 minecraft:cobbled_deepslate
setblock 88 65 590 minecraft:calcite
fill 88 65 591 88 68 591 minecraft:cobbled_deepslate
setblock 88 65 595 minecraft:calcite
fill 88 65 596 88 68 596 minecraft:cobbled_deepslate
setblock 48 66 558 minecraft:cobbled_deepslate
setblock 48 66 559 minecraft:calcite
fill 48 66 560 48 69 560 minecraft:cobbled_deepslate
setblock 48 66 565 minecraft:cobbled_deepslate
setblock 48 66 569 minecraft:calcite
fill 48 66 570 48 69 570 minecraft:cobbled_deepslate
setblock 48 66 574 minecraft:calcite
fill 48 66 575 48 69 575 minecraft:cobbled_deepslate
setblock 48 66 578 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_2 1t
