setblock 66 229 288 minecraft:light_blue_stained_glass
fill 66 229 289 68 229 289 minecraft:white_stained_glass
fill 66 229 293 67 229 293 minecraft:sea_lantern
fill 66 229 299 67 229 299 minecraft:sea_lantern
setblock 66 229 304 minecraft:light_blue_stained_glass
fill 66 229 305 68 229 305 minecraft:white_stained_glass
setblock 66 229 308 minecraft:light_blue_stained_glass
fill 66 229 309 68 229 309 minecraft:white_stained_glass
setblock 66 229 312 minecraft:light_blue_stained_glass
fill 66 229 313 68 229 313 minecraft:white_stained_glass
setblock 66 229 316 minecraft:light_blue_stained_glass
fill 66 229 317 66 249 317 minecraft:cyan_concrete
fill 67 229 276 67 229 278 minecraft:white_stained_glass
setblock 67 229 279 minecraft:light_blue_stained_glass
fill 67 229 280 67 229 282 minecraft:white_stained_glass
setblock 67 229 283 minecraft:light_blue_stained_glass
fill 67 229 284 69 229 284 minecraft:white_stained_glass
setblock 67 229 287 minecraft:light_blue_stained_glass
fill 67 229 288 69 229 288 minecraft:white_stained_glass
setblock 67 229 291 minecraft:spruce_log
setblock 67 229 301 minecraft:spruce_log
setblock 67 229 303 minecraft:light_blue_stained_glass
fill 67 229 304 69 229 304 minecraft:white_stained_glass
setblock 67 229 307 minecraft:light_blue_stained_glass
fill 67 229 308 69 229 308 minecraft:white_stained_glass
setblock 67 229 311 minecraft:light_blue_stained_glass
fill 67 229 312 69 229 312 minecraft:white_stained_glass
setblock 67 229 315 minecraft:light_blue_stained_glass
fill 67 229 316 69 229 316 minecraft:white_stained_glass
fill 68 229 276 68 229 277 minecraft:white_stained_glass
setblock 68 229 278 minecraft:light_blue_stained_glass
fill 68 229 279 68 229 281 minecraft:white_stained_glass
setblock 68 229 282 minecraft:light_blue_stained_glass
fill 68 229 283 70 229 283 minecraft:white_stained_glass
setblock 68 229 286 minecraft:light_blue_stained_glass
fill 68 229 287 70 229 287 minecraft:white_stained_glass
setblock 68 229 290 minecraft:light_blue_stained_glass
fill 68 229 291 69 231 291 minecraft:dark_oak_planks
fill 68 229 293 72 229 293 minecraft:dark_oak_planks
fill 68 229 294 68 229 295 minecraft:sea_lantern
fill 68 229 297 68 229 298 minecraft:sea_lantern
fill 68 229 299 72 229 299 minecraft:dark_oak_planks
fill 68 229 301 69 231 301 minecraft:dark_oak_planks
setblock 68 229 302 minecraft:light_blue_stained_glass
fill 68 229 303 70 229 303 minecraft:white_stained_glass
setblock 68 229 306 minecraft:light_blue_stained_glass
fill 68 229 307 70 229 307 minecraft:white_stained_glass
setblock 68 229 310 minecraft:light_blue_stained_glass
fill 68 229 311 70 229 311 minecraft:white_stained_glass
setblock 68 229 314 minecraft:light_blue_stained_glass
fill 68 229 315 70 229 315 minecraft:white_stained_glass
setblock 69 229 276 minecraft:white_stained_glass
setblock 69 229 277 minecraft:light_blue_stained_glass
fill 69 229 278 69 229 280 minecraft:white_stained_glass
setblock 69 229 281 minecraft:light_blue_stained_glass
fill 69 229 282 71 229 282 minecraft:white_stained_glass
setblock 69 229 285 minecraft:light_blue_stained_glass
fill 69 229 286 71 229 286 minecraft:white_stained_glass
setblock 69 229 289 minecraft:light_blue_stained_glass
fill 69 229 290 71 229 290 minecraft:white_stained_glass
fill 69 229 294 69 229 295 minecraft:dark_oak_planks
fill 69 229 297 69 229 298 minecraft:dark_oak_planks
fill 69 229 302 71 229 302 minecraft:white_stained_glass
setblock 69 229 305 minecraft:light_blue_stained_glass
fill 69 229 306 71 229 306 minecraft:white_stained_glass
setblock 69 229 309 minecraft:light_blue_stained_glass
fill 69 229 310 71 229 310 minecraft:white_stained_glass
setblock 69 229 313 minecraft:light_blue_stained_glass
fill 69 229 314 71 229 314 minecraft:white_stained_glass
setblock 70 229 276 minecraft:light_blue_stained_glass
fill 70 229 277 70 229 279 minecraft:white_stained_glass
setblock 70 229 280 minecraft:light_blue_stained_glass
fill 70 229 281 72 229 281 minecraft:white_stained_glass
setblock 70 229 284 minecraft:light_blue_stained_glass
fill 70 229 285 72 229 285 minecraft:white_stained_glass
setblock 70 229 288 minecraft:light_blue_stained_glass
fill 70 229 289 72 229 289 minecraft:white_stained_glass
setblock 70 229 291 minecraft:white_stained_glass
fill 70 229 294 74 229 294 minecraft:dark_oak_planks
fill 70 229 298 74 229 298 minecraft:dark_oak_planks
fill 70 229 301 72 229 301 minecraft:white_stained_glass
setblock 70 229 304 minecraft:light_blue_stained_glass
fill 70 229 305 72 229 305 minecraft:white_stained_glass
setblock 70 229 308 minecraft:light_blue_stained_glass
fill 70 229 309 72 229 309 minecraft:white_stained_glass
setblock 70 229 312 minecraft:light_blue_stained_glass
fill 70 229 313 72 229 313 minecraft:white_stained_glass
setblock 70 229 316 minecraft:light_blue_stained_glass
fill 71 229 276 71 229 278 minecraft:white_stained_glass
setblock 71 229 279 minecraft:light_blue_stained_glass
fill 71 229 280 73 229 280 minecraft:white_stained_glass
setblock 71 229 283 minecraft:light_blue_stained_glass
fill 71 229 284 73 229 284 minecraft:white_stained_glass
setblock 71 229 287 minecraft:light_blue_stained_glass
fill 71 229 288 73 229 288 minecraft:white_stained_glass
setblock 71 229 291 minecraft:light_blue_stained_glass
fill 71 229 292 73 229 292 minecraft:white_stained_glass
fill 71 229 295 74 229 295 minecraft:dark_oak_planks
fill 71 229 297 74 229 297 minecraft:dark_oak_planks
fill 71 229 300 73 229 300 minecraft:white_stained_glass
setblock 71 229 303 minecraft:light_blue_stained_glass
fill 71 229 304 73 229 304 minecraft:white_stained_glass
setblock 71 229 307 minecraft:light_blue_stained_glass
fill 71 229 308 73 229 308 minecraft:white_stained_glass
setblock 71 229 311 minecraft:light_blue_stained_glass
fill 71 229 312 73 229 312 minecraft:white_stained_glass
setblock 71 229 315 minecraft:light_blue_stained_glass
fill 71 229 316 73 229 316 minecraft:white_stained_glass
fill 72 229 276 72 229 277 minecraft:white_stained_glass
setblock 72 229 278 minecraft:light_blue_stained_glass
fill 72 229 279 74 229 279 minecraft:white_stained_glass
setblock 72 229 282 minecraft:light_blue_stained_glass
fill 72 229 283 74 229 283 minecraft:white_stained_glass
setblock 72 229 286 minecraft:light_blue_stained_glass
fill 72 229 287 74 229 287 minecraft:white_stained_glass
setblock 72 229 290 minecraft:light_blue_stained_glass
fill 72 229 291 74 229 291 minecraft:white_stained_glass
fill 72 229 296 74 229 296 minecraft:dark_oak_planks
setblock 72 229 302 minecraft:light_blue_stained_glass
fill 72 229 303 74 229 303 minecraft:white_stained_glass
setblock 72 229 306 minecraft:light_blue_stained_glass
fill 72 229 307 74 229 307 minecraft:white_stained_glass
setblock 72 229 310 minecraft:light_blue_stained_glass
fill 72 229 311 74 229 311 minecraft:white_stained_glass
setblock 72 229 314 minecraft:light_blue_stained_glass
fill 72 229 315 74 229 315 minecraft:white_stained_glass
setblock 73 229 276 minecraft:white_stained_glass
setblock 73 229 277 minecraft:light_blue_stained_glass
fill 73 229 278 75 229 278 minecraft:white_stained_glass
setblock 73 229 281 minecraft:light_blue_stained_glass
fill 73 229 282 75 229 282 minecraft:white_stained_glass
setblock 73 229 285 minecraft:light_blue_stained_glass
fill 73 229 286 75 229 286 minecraft:white_stained_glass
setblock 73 229 289 minecraft:light_blue_stained_glass
fill 73 229 290 75 229 290 minecraft:white_stained_glass
setblock 73 229 293 minecraft:light_blue_stained_glass
fill 73 229 299 74 229 299 minecraft:white_stained_glass
setblock 73 229 301 minecraft:light_blue_stained_glass
fill 73 229 302 75 229 302 minecraft:white_stained_glass
setblock 73 229 305 minecraft:light_blue_stained_glass
fill 73 229 306 75 229 306 minecraft:white_stained_glass
setblock 73 229 309 minecraft:light_blue_stained_glass
fill 73 229 310 75 229 310 minecraft:white_stained_glass
setblock 73 229 313 minecraft:light_blue_stained_glass
fill 73 229 314 75 229 314 minecraft:white_stained_glass
setblock 74 229 276 minecraft:light_blue_stained_glass
fill 74 229 277 76 229 277 minecraft:white_stained_glass
setblock 74 229 280 minecraft:light_blue_stained_glass
fill 74 229 281 76 229 281 minecraft:white_stained_glass
setblock 74 229 284 minecraft:light_blue_stained_glass
fill 74 229 285 76 229 285 minecraft:white_stained_glass
setblock 74 229 288 minecraft:light_blue_stained_glass
fill 74 229 289 76 229 289 minecraft:white_stained_glass
setblock 74 229 292 minecraft:light_blue_stained_glass
fill 74 229 293 76 229 293 minecraft:white_stained_glass
setblock 74 229 300 minecraft:light_blue_stained_glass
fill 74 229 301 76 229 301 minecraft:white_stained_glass
setblock 74 229 304 minecraft:light_blue_stained_glass
fill 74 229 305 76 229 305 minecraft:white_stained_glass
setblock 74 229 308 minecraft:light_blue_stained_glass
fill 74 229 309 76 229 309 minecraft:white_stained_glass
setblock 74 229 312 minecraft:light_blue_stained_glass
fill 74 229 313 76 229 313 minecraft:white_stained_glass
setblock 74 229 316 minecraft:light_blue_stained_glass
fill 75 229 276 77 229 276 minecraft:white_stained_glass
setblock 75 229 279 minecraft:light_blue_stained_glass
fill 75 229 280 77 229 280 minecraft:white_stained_glass
setblock 75 229 283 minecraft:light_blue_stained_glass
fill 75 229 284 77 229 284 minecraft:white_stained_glass
setblock 75 229 287 minecraft:light_blue_stained_glass
fill 75 229 288 77 229 288 minecraft:white_stained_glass
setblock 75 229 291 minecraft:light_blue_stained_glass
fill 75 229 292 77 229 292 minecraft:white_stained_glass
setblock 75 229 294 minecraft:white_stained_glass
setblock 75 229 295 minecraft:light_blue_stained_glass
fill 75 229 296 75 229 298 minecraft:white_stained_glass
setblock 75 229 299 minecraft:light_blue_stained_glass
fill 75 229 300 77 229 300 minecraft:white_stained_glass
setblock 75 229 303 minecraft:light_blue_stained_glass
fill 75 229 304 77 229 304 minecraft:white_stained_glass
setblock 75 229 307 minecraft:light_blue_stained_glass
fill 75 229 308 77 229 308 minecraft:white_stained_glass
setblock 75 229 311 minecraft:light_blue_stained_glass
fill 75 229 312 77 229 312 minecraft:white_stained_glass
setblock 75 229 315 minecraft:light_blue_stained_glass
fill 75 229 316 77 229 316 minecraft:white_stained_glass
setblock 76 229 278 minecraft:light_blue_stained_glass
fill 76 229 279 78 229 279 minecraft:white_stained_glass
setblock 76 229 282 minecraft:light_blue_stained_glass
fill 76 229 283 78 229 283 minecraft:white_stained_glass
setblock 76 229 286 minecraft:light_blue_stained_glass
fill 76 229 287 78 229 287 minecraft:white_stained_glass
setblock 76 229 290 minecraft:light_blue_stained_glass
fill 76 229 291 78 229 291 minecraft:white_stained_glass
setblock 76 229 294 minecraft:light_blue_stained_glass
fill 76 229 295 76 229 297 minecraft:white_stained_glass
setblock 76 229 298 minecraft:light_blue_stained_glass
fill 76 229 299 78 229 299 minecraft:white_stained_glass
setblock 76 229 302 minecraft:light_blue_stained_glass
fill 76 229 303 78 229 303 minecraft:white_stained_glass
setblock 76 229 306 minecraft:light_blue_stained_glass
fill 76 229 307 78 229 307 minecraft:white_stained_glass
setblock 76 229 310 minecraft:light_blue_stained_glass
fill 76 229 311 78 229 311 minecraft:white_stained_glass
setblock 76 229 314 minecraft:light_blue_stained_glass
fill 76 229 315 78 229 315 minecraft:white_stained_glass
setblock 77 229 277 minecraft:light_blue_stained_glass
fill 77 229 278 79 229 278 minecraft:white_stained_glass
setblock 77 229 281 minecraft:light_blue_stained_glass
fill 77 229 282 79 229 282 minecraft:white_stained_glass
setblock 77 229 285 minecraft:light_blue_stained_glass
fill 77 229 286 79 229 286 minecraft:white_stained_glass
setblock 77 229 289 minecraft:light_blue_stained_glass
fill 77 229 290 79 229 290 minecraft:white_stained_glass
setblock 77 229 293 minecraft:light_blue_stained_glass
fill 77 229 294 77 229 296 minecraft:white_stained_glass
setblock 77 229 297 minecraft:light_blue_stained_glass
fill 77 229 298 79 229 298 minecraft:white_stained_glass
setblock 77 229 301 minecraft:light_blue_stained_glass
fill 77 229 302 79 229 302 minecraft:white_stained_glass
setblock 77 229 305 minecraft:light_blue_stained_glass
fill 77 229 306 79 229 306 minecraft:white_stained_glass
setblock 77 229 309 minecraft:light_blue_stained_glass
fill 77 229 310 79 229 310 minecraft:white_stained_glass
setblock 77 229 313 minecraft:light_blue_stained_glass
fill 77 229 314 79 229 314 minecraft:white_stained_glass
setblock 78 229 276 minecraft:light_blue_stained_glass
fill 78 229 277 80 229 277 minecraft:white_stained_glass
setblock 78 229 280 minecraft:light_blue_stained_glass
fill 78 229 281 80 229 281 minecraft:white_stained_glass
setblock 78 229 284 minecraft:light_blue_stained_glass
fill 78 229 285 80 229 285 minecraft:white_stained_glass
setblock 78 229 288 minecraft:light_blue_stained_glass
fill 78 229 289 80 229 289 minecraft:white_stained_glass
setblock 78 229 292 minecraft:light_blue_stained_glass
fill 78 229 293 78 229 295 minecraft:white_stained_glass
setblock 78 229 296 minecraft:light_blue_stained_glass
fill 78 229 297 80 229 297 minecraft:white_stained_glass
setblock 78 229 300 minecraft:light_blue_stained_glass
fill 78 229 301 80 229 301 minecraft:white_stained_glass
setblock 78 229 304 minecraft:light_blue_stained_glass
fill 78 229 305 80 229 305 minecraft:white_stained_glass
setblock 78 229 308 minecraft:light_blue_stained_glass
fill 78 229 309 80 229 309 minecraft:white_stained_glass
setblock 78 229 312 minecraft:light_blue_stained_glass
fill 78 229 313 80 229 313 minecraft:white_stained_glass
setblock 78 229 316 minecraft:light_blue_stained_glass
fill 79 229 276 81 229 276 minecraft:white_stained_glass
setblock 79 229 279 minecraft:light_blue_stained_glass
fill 79 229 280 81 229 280 minecraft:white_stained_glass
setblock 79 229 283 minecraft:light_blue_stained_glass
fill 79 229 284 81 229 284 minecraft:white_stained_glass
setblock 79 229 287 minecraft:light_blue_stained_glass
fill 79 229 288 81 229 288 minecraft:white_stained_glass
setblock 79 229 291 minecraft:light_blue_stained_glass
fill 79 229 292 79 229 294 minecraft:white_stained_glass
setblock 79 229 295 minecraft:light_blue_stained_glass
fill 79 229 296 81 229 296 minecraft:white_stained_glass
setblock 79 229 299 minecraft:light_blue_stained_glass
fill 79 229 300 81 229 300 minecraft:white_stained_glass
setblock 79 229 303 minecraft:light_blue_stained_glass
fill 79 229 304 81 229 304 minecraft:white_stained_glass
setblock 79 229 307 minecraft:light_blue_stained_glass
fill 79 229 308 81 229 308 minecraft:white_stained_glass
setblock 79 229 311 minecraft:light_blue_stained_glass
fill 79 229 312 81 229 312 minecraft:white_stained_glass
setblock 79 229 315 minecraft:light_blue_stained_glass
fill 79 229 316 81 229 316 minecraft:white_stained_glass
setblock 80 229 278 minecraft:light_blue_stained_glass
fill 80 229 279 82 229 279 minecraft:white_stained_glass
setblock 80 229 282 minecraft:light_blue_stained_glass
fill 80 229 283 82 229 283 minecraft:white_stained_glass
setblock 80 229 286 minecraft:light_blue_stained_glass
fill 80 229 287 82 229 287 minecraft:white_stained_glass
setblock 80 229 290 minecraft:light_blue_stained_glass
fill 80 229 291 80 229 293 minecraft:white_stained_glass
setblock 80 229 294 minecraft:light_blue_stained_glass
fill 80 229 295 82 229 295 minecraft:white_stained_glass
setblock 80 229 298 minecraft:light_blue_stained_glass
fill 80 229 299 82 229 299 minecraft:white_stained_glass
setblock 80 229 302 minecraft:light_blue_stained_glass
fill 80 229 303 82 229 303 minecraft:white_stained_glass
setblock 80 229 306 minecraft:light_blue_stained_glass
fill 80 229 307 82 229 307 minecraft:white_stained_glass
setblock 80 229 310 minecraft:light_blue_stained_glass
fill 80 229 311 82 229 311 minecraft:white_stained_glass
setblock 80 229 314 minecraft:light_blue_stained_glass
fill 80 229 315 82 229 315 minecraft:white_stained_glass
setblock 81 229 277 minecraft:light_blue_stained_glass
fill 81 229 278 83 229 278 minecraft:white_stained_glass
setblock 81 229 281 minecraft:light_blue_stained_glass
fill 81 229 282 83 229 282 minecraft:white_stained_glass
setblock 81 229 285 minecraft:light_blue_stained_glass
fill 81 229 286 83 229 286 minecraft:white_stained_glass
setblock 81 229 289 minecraft:light_blue_stained_glass
fill 81 229 290 81 229 292 minecraft:white_stained_glass
setblock 81 229 293 minecraft:light_blue_stained_glass
fill 81 229 294 83 229 294 minecraft:white_stained_glass
setblock 81 229 297 minecraft:light_blue_stained_glass
fill 81 229 298 83 229 298 minecraft:white_stained_glass
setblock 81 229 301 minecraft:light_blue_stained_glass
fill 81 229 302 83 229 302 minecraft:white_stained_glass
setblock 81 229 305 minecraft:light_blue_stained_glass
fill 81 229 306 83 229 306 minecraft:white_stained_glass
setblock 81 229 309 minecraft:light_blue_stained_glass
fill 81 229 310 83 229 310 minecraft:white_stained_glass
setblock 81 229 313 minecraft:light_blue_stained_glass
fill 81 229 314 83 229 314 minecraft:white_stained_glass
setblock 82 229 276 minecraft:light_blue_stained_glass
fill 82 229 277 84 229 277 minecraft:white_stained_glass
setblock 82 229 280 minecraft:light_blue_stained_glass
fill 82 229 281 84 229 281 minecraft:white_stained_glass
setblock 82 229 284 minecraft:light_blue_stained_glass
fill 82 229 285 84 229 285 minecraft:white_stained_glass
setblock 82 229 288 minecraft:light_blue_stained_glass
fill 82 229 289 82 229 291 minecraft:white_stained_glass
setblock 82 229 292 minecraft:light_blue_stained_glass
fill 82 229 293 84 229 293 minecraft:white_stained_glass
setblock 82 229 296 minecraft:light_blue_stained_glass
fill 82 229 297 84 229 297 minecraft:white_stained_glass
setblock 82 229 300 minecraft:light_blue_stained_glass
fill 82 229 301 84 229 301 minecraft:white_stained_glass
setblock 82 229 304 minecraft:light_blue_stained_glass
fill 82 229 305 84 229 305 minecraft:white_stained_glass
setblock 82 229 308 minecraft:light_blue_stained_glass
fill 82 229 309 84 229 309 minecraft:white_stained_glass
setblock 82 229 312 minecraft:light_blue_stained_glass
fill 82 229 313 83 229 313 minecraft:white_stained_glass
setblock 82 229 316 minecraft:light_blue_stained_glass
fill 83 229 276 85 229 276 minecraft:white_stained_glass
setblock 83 229 279 minecraft:light_blue_stained_glass
fill 83 229 280 85 229 280 minecraft:white_stained_glass
setblock 83 229 283 minecraft:light_blue_stained_glass
fill 83 229 284 85 229 284 minecraft:white_stained_glass
setblock 83 229 287 minecraft:light_blue_stained_glass
fill 83 229 288 83 229 290 minecraft:white_stained_glass
setblock 83 229 291 minecraft:light_blue_stained_glass
fill 83 229 292 85 229 292 minecraft:white_stained_glass
setblock 83 229 295 minecraft:light_blue_stained_glass
fill 83 229 296 85 229 296 minecraft:white_stained_glass
setblock 83 229 299 minecraft:light_blue_stained_glass
fill 83 229 300 85 229 300 minecraft:white_stained_glass
setblock 83 229 303 minecraft:light_blue_stained_glass
fill 83 229 304 85 229 304 minecraft:white_stained_glass
setblock 83 229 307 minecraft:light_blue_stained_glass
fill 83 229 308 85 229 308 minecraft:white_stained_glass
setblock 83 229 311 minecraft:light_blue_stained_glass
setblock 83 229 315 minecraft:light_blue_stained_glass
fill 83 229 316 85 229 316 minecraft:white_stained_glass
setblock 84 229 278 minecraft:light_blue_stained_glass
fill 84 229 279 86 229 279 minecraft:white_stained_glass
setblock 84 229 282 minecraft:light_blue_stained_glass
fill 84 229 283 86 229 283 minecraft:white_stained_glass
setblock 84 229 286 minecraft:light_blue_stained_glass
fill 84 229 287 84 229 289 minecraft:white_stained_glass
setblock 84 229 290 minecraft:light_blue_stained_glass
fill 84 229 291 86 229 291 minecraft:white_stained_glass
setblock 84 229 294 minecraft:light_blue_stained_glass
fill 84 229 295 86 229 295 minecraft:white_stained_glass
setblock 84 229 298 minecraft:light_blue_stained_glass
fill 84 229 299 86 229 299 minecraft:white_stained_glass
setblock 84 229 302 minecraft:light_blue_stained_glass
fill 84 229 303 86 229 303 minecraft:white_stained_glass
setblock 84 229 306 minecraft:light_blue_stained_glass
fill 84 229 307 86 229 307 minecraft:white_stained_glass
setblock 84 229 310 minecraft:light_blue_stained_glass
setblock 84 229 314 minecraft:light_blue_stained_glass
fill 84 229 315 86 229 315 minecraft:white_stained_glass
fill 84 229 317 84 237 317 minecraft:cyan_concrete
setblock 85 229 277 minecraft:light_blue_stained_glass
fill 85 229 278 87 229 278 minecraft:white_stained_glass
setblock 85 229 281 minecraft:light_blue_stained_glass
fill 85 229 282 87 229 282 minecraft:white_stained_glass
setblock 85 229 285 minecraft:light_blue_stained_glass
fill 85 229 286 85 229 288 minecraft:white_stained_glass
setblock 85 229 289 minecraft:light_blue_stained_glass
fill 85 229 290 87 229 290 minecraft:white_stained_glass
setblock 85 229 293 minecraft:light_blue_stained_glass
fill 85 229 294 87 229 294 minecraft:white_stained_glass
setblock 85 229 297 minecraft:light_blue_stained_glass
fill 85 229 298 87 229 298 minecraft:white_stained_glass
setblock 85 229 301 minecraft:light_blue_stained_glass
fill 85 229 302 87 229 302 minecraft:white_stained_glass
setblock 85 229 305 minecraft:light_blue_stained_glass
fill 85 229 306 87 229 306 minecraft:white_stained_glass
setblock 85 229 309 minecraft:light_blue_stained_glass
fill 85 229 310 86 229 311 minecraft:white_stained_glass
setblock 85 229 313 minecraft:light_blue_stained_glass
fill 85 229 314 87 229 314 minecraft:white_stained_glass
setblock 85 229 317 minecraft:light_blue_wool
setblock 86 229 276 minecraft:light_blue_stained_glass
fill 86 229 277 88 229 277 minecraft:white_stained_glass
setblock 86 229 280 minecraft:light_blue_stained_glass
fill 86 229 281 88 229 281 minecraft:white_stained_glass
setblock 86 229 284 minecraft:light_blue_stained_glass
fill 86 229 285 86 229 287 minecraft:white_stained_glass
setblock 86 229 288 minecraft:light_blue_stained_glass
fill 86 229 289 88 229 289 minecraft:white_stained_glass
setblock 86 229 292 minecraft:light_blue_stained_glass
fill 86 229 293 88 229 293 minecraft:white_stained_glass
setblock 86 229 296 minecraft:light_blue_stained_glass
fill 86 229 297 88 229 297 minecraft:white_stained_glass
setblock 86 229 300 minecraft:light_blue_stained_glass
fill 86 229 301 88 229 301 minecraft:white_stained_glass
setblock 86 229 304 minecraft:light_blue_stained_glass
fill 86 229 305 88 229 305 minecraft:white_stained_glass
setblock 86 229 308 minecraft:light_blue_stained_glass
fill 86 229 309 88 229 309 minecraft:white_stained_glass
setblock 86 229 312 minecraft:light_blue_stained_glass
fill 86 229 313 88 229 313 minecraft:white_stained_glass
setblock 86 229 316 minecraft:light_blue_stained_glass
fill 86 229 317 87 242 317 minecraft:cyan_concrete
fill 87 229 276 88 229 276 minecraft:white_stained_glass
setblock 87 229 279 minecraft:light_blue_stained_glass
fill 87 229 280 88 229 280 minecraft:white_stained_glass
setblock 87 229 283 minecraft:light_blue_stained_glass
fill 87 229 284 87 229 286 minecraft:white_stained_glass
setblock 87 229 287 minecraft:light_blue_stained_glass
fill 87 229 288 88 229 288 minecraft:white_stained_glass
setblock 87 229 291 minecraft:light_blue_stained_glass
fill 87 229 292 88 229 292 minecraft:white_stained_glass
setblock 87 229 295 minecraft:light_blue_stained_glass
fill 87 229 296 88 229 296 minecraft:white_stained_glass
setblock 87 229 299 minecraft:light_blue_stained_glass
fill 87 229 300 88 229 300 minecraft:white_stained_glass
setblock 87 229 303 minecraft:light_blue_stained_glass
fill 87 229 304 88 229 304 minecraft:white_stained_glass
setblock 87 229 307 minecraft:light_blue_stained_glass
fill 87 229 308 88 229 308 minecraft:white_stained_glass
setblock 87 229 310 minecraft:white_stained_glass
setblock 87 229 311 minecraft:light_blue_stained_glass
fill 87 229 312 88 229 312 minecraft:white_stained_glass
setblock 87 229 315 minecraft:light_blue_stained_glass
fill 87 229 316 88 229 316 minecraft:white_stained_glass
setblock 88 229 278 minecraft:light_blue_stained_glass
setblock 88 229 279 minecraft:white_stained_glass
setblock 88 229 282 minecraft:light_blue_stained_glass
fill 88 229 283 88 229 285 minecraft:white_stained_glass
setblock 88 229 286 minecraft:light_blue_stained_glass
setblock 88 229 287 minecraft:white_stained_glass
setblock 88 229 290 minecraft:light_blue_stained_glass
setblock 88 229 291 minecraft:white_stained_glass
setblock 88 229 294 minecraft:light_blue_stained_glass
setblock 88 229 295 minecraft:white_stained_glass
setblock 88 229 298 minecraft:light_blue_stained_glass
setblock 88 229 299 minecraft:white_stained_glass
setblock 88 229 302 minecraft:light_blue_stained_glass
setblock 88 229 303 minecraft:white_stained_glass
setblock 88 229 306 minecraft:light_blue_stained_glass
setblock 88 229 307 minecraft:white_stained_glass
setblock 88 229 310 minecraft:light_blue_stained_glass
setblock 88 229 311 minecraft:white_stained_glass
setblock 88 229 314 minecraft:light_blue_stained_glass
setblock 88 229 315 minecraft:white_stained_glass
setblock 47 230 313 minecraft:light_blue_wool
fill 53 230 296 55 230 296 minecraft:dark_oak_planks
fill 54 230 294 55 230 295 minecraft:dark_oak_planks
fill 54 230 297 55 230 298 minecraft:dark_oak_planks
fill 55 230 293 57 230 293 minecraft:dark_oak_planks
fill 55 230 299 57 230 299 minecraft:dark_oak_planks
fill 56 230 292 61 230 292 minecraft:dark_oak_planks
fill 56 230 300 61 230 300 minecraft:dark_oak_planks
fill 56 230 317 56 251 317 minecraft:cyan_concrete
fill 59 230 291 60 230 291 minecraft:dark_oak_planks
fill 59 230 294 59 231 298 minecraft:dark_oak_planks
fill 59 230 301 60 230 301 minecraft:dark_oak_planks
fill 60 230 293 60 231 293 minecraft:dark_oak_planks
fill 60 230 299 60 231 299 minecraft:dark_oak_planks
fill 63 230 291 67 230 291 minecraft:dark_oak_planks
fill 63 230 301 67 230 301 minecraft:dark_oak_planks
fill 69 230 292 74 230 292 minecraft:dark_oak_planks
fill 69 230 300 74 230 300 minecraft:dark_oak_planks
fill 70 230 291 71 230 291 minecraft:dark_oak_planks
fill 70 230 293 70 231 293 minecraft:dark_oak_planks
fill 70 230 299 70 231 299 minecraft:dark_oak_planks
fill 70 230 301 71 230 301 minecraft:dark_oak_planks
fill 71 230 294 71 231 298 minecraft:dark_oak_planks
fill 73 230 293 75 230 293 minecraft:dark_oak_planks
fill 73 230 299 75 230 299 minecraft:dark_oak_planks
fill 75 230 294 76 230 298 minecraft:dark_oak_planks
setblock 77 230 296 minecraft:dark_oak_planks
fill 85 230 317 85 247 317 minecraft:cyan_concrete
fill 47 231 313 47 251 313 minecraft:cyan_concrete
setblock 50 231 278 minecraft:light[level=12]
setblock 50 231 285 minecraft:light[level=12]
setblock 50 231 292 minecraft:light[level=12]
setblock 50 231 299 minecraft:light[level=12]
setblock 50 231 306 minecraft:light[level=12]
setblock 50 231 313 minecraft:light[level=12]
fill 52 231 295 52 232 297 minecraft:dark_oak_planks
fill 53 231 294 53 231 295 minecraft:dark_oak_planks
fill 53 231 297 53 231 298 minecraft:dark_oak_planks
setblock 54 231 293 minecraft:dark_oak_planks
setblock 54 231 299 minecraft:dark_oak_planks
fill 55 231 292 56 231 292 minecraft:dark_oak_planks
fill 55 231 300 56 231 300 minecraft:dark_oak_planks
setblock 57 231 278 minecraft:light[level=12]
setblock 57 231 285 minecraft:light[level=12]
fill 57 231 291 59 231 291 minecraft:dark_oak_planks
setblock 57 231 292 minecraft:light[level=12]
setblock 57 231 299 minecraft:light[level=12]
fill 57 231 301 59 231 301 minecraft:dark_oak_planks
setblock 57 231 306 minecraft:light[level=12]
setblock 57 231 313 minecraft:light[level=12]
fill 60 231 290 62 232 290 minecraft:dark_oak_planks
fill 60 231 292 61 231 292 minecraft:dark_oak_planks
fill 60 231 300 61 231 300 minecraft:dark_oak_planks
fill 60 231 302 62 232 302 minecraft:dark_oak_planks
setblock 64 231 278 minecraft:light[level=12]
setblock 64 231 285 minecraft:light[level=12]
setblock 64 231 292 minecraft:light[level=12]
setblock 64 231 306 minecraft:light[level=12]
setblock 64 231 313 minecraft:light[level=12]
fill 68 231 290 70 232 290 minecraft:dark_oak_planks
fill 68 231 302 70 232 302 minecraft:dark_oak_planks
fill 69 231 292 70 231 292 minecraft:dark_oak_planks
fill 69 231 300 70 231 300 minecraft:dark_oak_planks
setblock 71 231 278 minecraft:light[level=12]
setblock 71 231 285 minecraft:light[level=12]
fill 71 231 291 73 231 291 minecraft:dark_oak_planks
setblock 71 231 292 minecraft:light[level=12]
setblock 71 231 299 minecraft:light[level=12]
fill 71 231 301 73 231 301 minecraft:dark_oak_planks
setblock 71 231 306 minecraft:light[level=12]
setblock 71 231 313 minecraft:light[level=12]
setblock 71 231 317 minecraft:light_blue_wool
fill 72 231 317 72 246 317 minecraft:cyan_concrete
fill 74 231 292 75 231 292 minecraft:dark_oak_planks
fill 74 231 300 75 231 300 minecraft:dark_oak_planks
setblock 76 231 293 minecraft:dark_oak_planks
setblock 76 231 299 minecraft:dark_oak_planks
fill 77 231 294 77 231 295 minecraft:dark_oak_planks
fill 77 231 297 77 231 298 minecraft:dark_oak_planks
setblock 78 231 278 minecraft:light[level=12]
setblock 78 231 285 minecraft:light[level=12]
setblock 78 231 292 minecraft:light[level=12]
fill 78 231 295 78 232 297 minecraft:dark_oak_planks
setblock 78 231 299 minecraft:light[level=12]
setblock 78 231 306 minecraft:light[level=12]
setblock 78 231 313 minecraft:light[level=12]
setblock 85 231 278 minecraft:light[level=12]
setblock 85 231 285 minecraft:light[level=12]
setblock 85 231 292 minecraft:light[level=12]
setblock 85 231 299 minecraft:light[level=12]
setblock 85 231 306 minecraft:light[level=12]
setblock 85 231 313 minecraft:light[level=12]
setblock 47 232 299 minecraft:white_wool
setblock 52 232 294 minecraft:dark_oak_planks
setblock 52 232 298 minecraft:dark_oak_planks
setblock 53 232 293 minecraft:dark_oak_planks
setblock 53 232 299 minecraft:dark_oak_planks
fill 54 232 292 55 232 292 minecraft:dark_oak_planks
fill 54 232 300 55 232 300 minecraft:dark_oak_planks
fill 56 232 291 57 232 291 minecraft:dark_oak_planks
fill 56 232 301 57 232 301 minecraft:dark_oak_planks
fill 58 232 290 59 232 290 minecraft:dark_oak_planks
fill 58 232 302 59 232 302 minecraft:dark_oak_planks
fill 71 232 290 72 232 290 minecraft:dark_oak_planks
fill 71 232 302 72 232 302 minecraft:dark_oak_planks
fill 71 232 317 71 235 317 minecraft:cyan_concrete
fill 73 232 291 74 232 291 minecraft:dark_oak_planks
fill 73 232 301 74 232 301 minecraft:dark_oak_planks
fill 75 232 292 76 232 292 minecraft:dark_oak_planks
fill 75 232 300 76 232 300 minecraft:dark_oak_planks
setblock 77 232 293 minecraft:dark_oak_planks
setblock 77 232 299 minecraft:dark_oak_planks
setblock 78 232 294 minecraft:dark_oak_planks
setblock 78 232 298 minecraft:dark_oak_planks
fill 47 233 299 47 235 299 minecraft:cyan_concrete
setblock 48 233 276 minecraft:spruce_planks
fill 48 233 280 48 233 281 minecraft:spruce_planks
setblock 48 233 283 minecraft:spruce_planks
fill 48 233 286 77 233 286 minecraft:spruce_planks
fill 48 233 288 48 272 288 minecraft:spruce_planks
setblock 48 233 290 minecraft:spruce_planks
fill 48 233 292 51 233 292 minecraft:spruce_planks
fill 48 233 295 48 272 295 minecraft:spruce_planks
fill 48 233 297 48 234 298 minecraft:spruce_planks
fill 48 233 302 48 272 302 minecraft:spruce_planks
fill 48 233 304 57 233 304 minecraft:spruce_planks
fill 48 233 309 48 233 311 minecraft:spruce_planks
fill 48 233 316 48 272 316 minecraft:spruce_planks
fill 49 233 280 50 233 280 minecraft:spruce_planks
fill 49 233 298 60 233 298 minecraft:spruce_planks
fill 49 233 310 50 233 310 minecraft:spruce_planks
fill 50 233 276 50 272 276 minecraft:spruce_planks
setblock 50 233 278 minecraft:light[level=15]
fill 50 233 289 50 244 289 minecraft:green_terracotta
setblock 50 233 294 minecraft:light[level=15]
setblock 50 233 302 minecraft:light[level=15]
setblock 50 233 316 minecraft:spruce_planks
fill 52 233 294 60 233 297 minecraft:spruce_planks
fill 53 233 293 61 233 293 minecraft:spruce_planks
fill 53 233 299 61 233 299 minecraft:spruce_planks
fill 54 233 280 88 233 280 minecraft:spruce_planks
fill 54 233 292 62 233 292 minecraft:spruce_planks
fill 54 233 300 62 233 300 minecraft:spruce_planks
setblock 54 233 310 minecraft:iron_bars
setblock 55 233 276 minecraft:spruce_planks
fill 55 233 316 55 272 316 minecraft:spruce_planks
fill 56 233 291 74 233 291 minecraft:spruce_planks
fill 56 233 301 74 233 301 minecraft:spruce_planks
fill 57 233 276 57 272 276 minecraft:spruce_planks
setblock 57 233 316 minecraft:spruce_planks
setblock 58 233 278 minecraft:light[level=15]
fill 58 233 290 72 233 290 minecraft:spruce_planks
fill 58 233 302 72 233 302 minecraft:spruce_planks
fill 58 233 303 58 233 316 minecraft:iron_bars
fill 59 233 304 75 233 304 minecraft:spruce_planks
setblock 62 233 276 minecraft:spruce_planks
fill 62 233 316 62 272 316 minecraft:spruce_planks
fill 64 233 276 64 272 276 minecraft:spruce_planks
fill 64 233 306 72 233 316 minecraft:spruce_planks
setblock 66 233 278 minecraft:light[level=15]
fill 68 233 292 76 233 292 minecraft:spruce_planks
fill 68 233 300 76 233 300 minecraft:spruce_planks
setblock 69 233 276 minecraft:spruce_planks
fill 69 233 293 77 233 293 minecraft:spruce_planks
fill 69 233 299 77 233 299 minecraft:spruce_planks
fill 70 233 294 78 233 298 minecraft:spruce_planks
fill 71 233 276 71 272 276 minecraft:spruce_planks
setblock 74 233 278 minecraft:light[level=15]
setblock 74 233 302 minecraft:light[level=15]
setblock 74 233 310 minecraft:light[level=15]
fill 74 233 311 74 234 311 minecraft:iron_bars
setblock 75 233 275 minecraft:light_blue_wool
fill 76 233 275 78 247 275 minecraft:cyan_concrete
setblock 76 233 276 minecraft:spruce_planks
fill 76 233 301 76 233 315 minecraft:iron_bars
fill 76 233 316 81 234 316 minecraft:spruce_planks
fill 77 233 304 88 233 304 minecraft:spruce_planks
fill 77 233 312 81 234 315 minecraft:spruce_planks
fill 78 233 276 78 272 276 minecraft:spruce_planks
fill 78 233 303 81 234 303 minecraft:spruce_planks
setblock 82 233 278 minecraft:light[level=15]
setblock 82 233 286 minecraft:light[level=15]
setblock 82 233 294 minecraft:light[level=15]
setblock 82 233 302 minecraft:light[level=15]
fill 82 233 303 82 234 303 minecraft:iron_bars
fill 82 233 305 82 233 316 minecraft:iron_bars
setblock 83 233 276 minecraft:spruce_planks
fill 83 233 303 88 233 303 minecraft:spruce_planks
fill 83 233 316 83 272 316 minecraft:spruce_planks
fill 85 233 276 85 272 276 minecraft:spruce_planks
setblock 85 233 316 minecraft:spruce_planks
fill 86 233 307 86 234 311 minecraft:white_wool
setblock 88 233 278 minecraft:spruce_planks
setblock 88 233 285 minecraft:spruce_planks
fill 88 233 287 88 272 287 minecraft:spruce_planks
setblock 88 233 292 minecraft:spruce_planks
fill 88 233 294 88 272 294 minecraft:spruce_planks
setblock 88 233 299 minecraft:spruce_planks
fill 88 233 301 88 272 301 minecraft:spruce_planks
setblock 88 233 306 minecraft:spruce_planks
fill 88 233 308 88 272 308 minecraft:spruce_planks
setblock 88 233 313 minecraft:spruce_planks
fill 88 233 315 88 272 315 minecraft:spruce_planks
setblock 48 234 277 minecraft:spruce_planks
fill 48 234 279 51 235 279 minecraft:spruce_planks
fill 48 234 281 48 272 281 minecraft:spruce_planks
fill 48 234 284 48 234 285 minecraft:spruce_planks
fill 48 234 291 56 234 291 minecraft:spruce_planks
fill 48 234 303 57 234 303 minecraft:spruce_planks
setblock 48 234 305 minecraft:spruce_planks
fill 48 234 309 60 235 309 minecraft:spruce_planks
setblock 48 234 312 minecraft:spruce_planks
fill 48 234 315 69 234 315 minecraft:spruce_planks
fill 49 234 285 50 235 285 minecraft:spruce_planks
fill 49 234 297 57 234 297 minecraft:spruce_planks
setblock 51 234 316 minecraft:spruce_planks
fill 52 234 276 52 235 278 minecraft:iron_bars
fill 53 234 279 57 235 279 minecraft:spruce_planks
setblock 54 234 276 minecraft:spruce_planks
fill 58 234 276 58 234 295 minecraft:iron_bars
fill 58 234 296 58 237 296 minecraft:stripped_dark_oak_log
fill 58 234 297 58 234 306 minecraft:iron_bars
setblock 58 234 316 minecraft:spruce_planks
fill 59 234 279 63 235 279 minecraft:spruce_planks
fill 59 234 297 59 235 297 minecraft:spruce_planks
fill 59 234 303 69 234 303 minecraft:spruce_planks
setblock 61 234 276 minecraft:spruce_planks
fill 64 234 277 64 235 279 minecraft:iron_bars
fill 64 234 306 69 234 314 minecraft:spruce_planks
fill 64 234 316 69 234 316 minecraft:spruce_planks
fill 65 234 279 69 235 279 minecraft:spruce_planks
setblock 68 234 276 minecraft:spruce_planks
fill 70 234 276 70 234 294 minecraft:iron_bars
fill 70 234 298 70 234 316 minecraft:iron_bars
fill 71 234 279 75 234 279 minecraft:spruce_planks
fill 71 234 297 75 234 297 minecraft:spruce_planks
fill 71 234 303 75 234 303 minecraft:spruce_planks
fill 71 234 306 72 234 316 minecraft:spruce_planks
fill 73 234 315 76 234 315 minecraft:spruce_planks
fill 75 234 275 75 251 275 minecraft:cyan_concrete
setblock 75 234 276 minecraft:spruce_planks
fill 76 234 276 76 234 305 minecraft:iron_bars
fill 76 234 312 76 234 314 minecraft:spruce_planks
fill 77 234 279 81 234 279 minecraft:spruce_planks
fill 77 234 297 81 234 297 minecraft:spruce_planks
setblock 77 234 303 minecraft:spruce_planks
setblock 82 234 276 minecraft:spruce_planks
fill 82 234 277 82 234 302 minecraft:iron_bars
fill 82 234 304 82 234 308 minecraft:iron_bars
fill 82 234 312 82 234 316 minecraft:spruce_planks
fill 83 234 279 87 234 279 minecraft:spruce_planks
fill 83 234 297 88 234 297 minecraft:spruce_planks
fill 83 234 303 84 234 303 minecraft:spruce_planks
fill 83 234 315 87 235 315 minecraft:spruce_planks
setblock 86 234 316 minecraft:spruce_planks
setblock 88 234 277 minecraft:spruce_planks
fill 88 234 280 88 272 280 minecraft:spruce_planks
setblock 88 234 284 minecraft:spruce_planks
fill 88 234 291 88 235 291 minecraft:spruce_planks
setblock 88 234 298 minecraft:spruce_planks
setblock 88 234 305 minecraft:spruce_planks
setblock 88 234 312 minecraft:spruce_planks
setblock 48 235 278 minecraft:spruce_planks
setblock 48 235 285 minecraft:spruce_planks
fill 48 235 291 48 235 292 minecraft:spruce_planks
fill 48 235 297 51 235 297 minecraft:spruce_planks
setblock 48 235 299 minecraft:spruce_planks
fill 48 235 303 50 235 303 minecraft:spruce_planks
setblock 48 235 306 minecraft:spruce_planks
setblock 48 235 313 minecraft:spruce_planks
fill 48 235 315 62 235 315 minecraft:spruce_planks
fill 49 235 291 51 235 291 minecraft:spruce_planks
setblock 51 235 285 minecraft:spruce_planks
fill 52 235 282 52 235 308 minecraft:iron_bars
setblock 52 235 316 minecraft:spruce_planks
setblock 53 235 276 minecraft:spruce_planks
fill 53 235 285 63 235 285 minecraft:spruce_planks
fill 53 235 291 63 235 291 minecraft:spruce_planks
fill 53 235 297 58 235 297 minecraft:spruce_planks
fill 58 235 276 58 235 278 minecraft:iron_bars
setblock 58 235 279 minecraft:spruce_planks
setblock 59 235 316 minecraft:spruce_planks
setblock 60 235 276 minecraft:spruce_planks
fill 60 235 297 61 235 297 minecraft:spruce_planks
fill 61 235 309 63 235 309 minecraft:spruce_planks
fill 63 235 313 63 236 315 minecraft:iron_bars
fill 64 235 280 64 235 294 minecraft:iron_bars
fill 64 235 301 64 235 305 minecraft:iron_bars
setblock 64 235 306 minecraft:shroomlight
setblock 64 235 307 minecraft:iron_bars
setblock 64 235 308 minecraft:shroomlight
setblock 64 235 309 minecraft:iron_bars
setblock 64 235 310 minecraft:shroomlight
setblock 64 235 311 minecraft:iron_bars
setblock 64 235 312 minecraft:shroomlight
setblock 64 235 313 minecraft:iron_bars
setblock 64 235 314 minecraft:shroomlight
fill 64 235 315 64 236 315 minecraft:iron_bars
setblock 64 235 316 minecraft:shroomlight
fill 65 235 285 69 235 285 minecraft:spruce_planks
fill 65 235 291 87 235 291 minecraft:spruce_planks
fill 65 235 306 65 248 306 minecraft:spruce_planks
setblock 65 235 307 minecraft:shroomlight
fill 65 235 308 65 248 308 minecraft:spruce_planks
setblock 65 235 309 minecraft:shroomlight
fill 65 235 310 65 248 310 minecraft:spruce_planks
setblock 65 235 311 minecraft:shroomlight
fill 65 235 312 65 248 312 minecraft:spruce_planks
setblock 65 235 313 minecraft:shroomlight
fill 65 235 314 65 248 314 minecraft:spruce_planks
setblock 65 235 315 minecraft:shroomlight
fill 65 235 316 65 248 316 minecraft:spruce_planks
setblock 66 235 306 minecraft:shroomlight
fill 66 235 307 66 248 307 minecraft:spruce_planks
setblock 66 235 308 minecraft:shroomlight
fill 66 235 309 66 248 309 minecraft:spruce_planks
setblock 66 235 310 minecraft:shroomlight
fill 66 235 311 66 248 311 minecraft:spruce_planks
setblock 66 235 312 minecraft:shroomlight
fill 66 235 313 66 248 313 minecraft:spruce_planks
setblock 66 235 314 minecraft:shroomlight
fill 66 235 315 66 248 315 minecraft:spruce_planks
setblock 66 235 316 minecraft:shroomlight
setblock 67 235 276 minecraft:spruce_planks
fill 67 235 306 67 248 306 minecraft:spruce_planks
setblock 67 235 307 minecraft:shroomlight
fill 67 235 308 67 248 308 minecraft:spruce_planks
setblock 67 235 309 minecraft:shroomlight
fill 67 235 310 67 248 310 minecraft:spruce_planks
setblock 67 235 311 minecraft:shroomlight
fill 67 235 312 67 248 312 minecraft:spruce_planks
setblock 67 235 313 minecraft:shroomlight
fill 67 235 314 67 248 314 minecraft:spruce_planks
setblock 67 235 315 minecraft:shroomlight
fill 67 235 316 67 248 316 minecraft:spruce_planks
setblock 68 235 306 minecraft:shroomlight
fill 68 235 307 68 248 307 minecraft:spruce_planks
setblock 68 235 308 minecraft:shroomlight
fill 68 235 309 68 248 309 minecraft:spruce_planks
setblock 68 235 310 minecraft:shroomlight
fill 68 235 311 68 248 311 minecraft:spruce_planks
setblock 68 235 312 minecraft:shroomlight
fill 68 235 313 68 248 313 minecraft:spruce_planks
setblock 68 235 314 minecraft:shroomlight
fill 68 235 315 68 248 315 minecraft:spruce_planks
setblock 68 235 316 minecraft:shroomlight
setblock 69 235 306 minecraft:spruce_planks
setblock 69 235 307 minecraft:shroomlight
setblock 69 235 308 minecraft:spruce_planks
setblock 69 235 309 minecraft:shroomlight
setblock 69 235 310 minecraft:spruce_planks
setblock 69 235 311 minecraft:shroomlight
setblock 69 235 312 minecraft:spruce_planks
setblock 69 235 313 minecraft:shroomlight
setblock 69 235 314 minecraft:spruce_planks
setblock 69 235 315 minecraft:shroomlight
fill 69 235 316 69 272 316 minecraft:spruce_planks
fill 70 235 276 70 235 288 minecraft:iron_bars
setblock 70 235 306 minecraft:shroomlight
fill 70 235 307 70 248 307 minecraft:spruce_planks
setblock 70 235 308 minecraft:shroomlight
fill 70 235 309 70 248 309 minecraft:spruce_planks
setblock 70 235 310 minecraft:shroomlight
fill 70 235 311 70 248 311 minecraft:spruce_planks
setblock 70 235 312 minecraft:shroomlight
fill 70 235 313 70 248 313 minecraft:spruce_planks
setblock 70 235 314 minecraft:shroomlight
fill 70 235 315 70 248 315 minecraft:spruce_planks
setblock 70 235 316 minecraft:shroomlight
setblock 71 235 279 minecraft:spruce_planks
fill 71 235 285 77 235 285 minecraft:spruce_planks
fill 71 235 306 71 248 306 minecraft:spruce_planks
setblock 71 235 307 minecraft:shroomlight
fill 71 235 308 71 248 308 minecraft:spruce_planks
setblock 71 235 309 minecraft:shroomlight
fill 71 235 310 71 248 310 minecraft:spruce_planks
setblock 71 235 311 minecraft:shroomlight
fill 71 235 312 71 248 312 minecraft:spruce_planks
setblock 71 235 313 minecraft:shroomlight
fill 71 235 314 71 248 314 minecraft:spruce_planks
setblock 71 235 315 minecraft:shroomlight
fill 71 235 316 71 248 316 minecraft:spruce_planks
setblock 72 235 306 minecraft:shroomlight
fill 72 235 307 72 248 307 minecraft:spruce_planks
setblock 72 235 308 minecraft:shroomlight
fill 72 235 309 74 235 309 minecraft:spruce_planks
setblock 72 235 310 minecraft:shroomlight
fill 72 235 311 72 248 311 minecraft:spruce_planks
setblock 72 235 312 minecraft:shroomlight
fill 72 235 313 72 248 313 minecraft:spruce_planks
setblock 72 235 314 minecraft:shroomlight
fill 72 235 315 74 236 315 minecraft:spruce_planks
setblock 72 235 316 minecraft:shroomlight
fill 73 235 311 74 235 314 minecraft:dark_oak_planks
setblock 73 235 316 minecraft:spruce_planks
setblock 74 235 276 minecraft:spruce_planks
fill 75 235 307 75 235 316 minecraft:iron_bars
fill 76 235 276 76 235 278 minecraft:iron_bars
fill 76 235 309 88 235 309 minecraft:spruce_planks
fill 76 235 311 77 235 311 minecraft:dark_oak_planks
setblock 76 235 312 minecraft:shroomlight
fill 76 235 313 76 248 313 minecraft:spruce_planks
setblock 76 235 314 minecraft:shroomlight
fill 76 235 315 76 248 315 minecraft:spruce_planks
setblock 76 235 316 minecraft:shroomlight
fill 77 235 312 77 248 312 minecraft:spruce_planks
setblock 77 235 313 minecraft:shroomlight
fill 77 235 314 77 248 314 minecraft:spruce_planks
setblock 77 235 315 minecraft:shroomlight
fill 77 235 316 77 248 316 minecraft:spruce_planks
setblock 78 235 312 minecraft:shroomlight
fill 78 235 313 78 248 313 minecraft:spruce_planks
setblock 78 235 314 minecraft:shroomlight
fill 78 235 315 78 248 315 minecraft:spruce_planks
setblock 78 235 316 minecraft:shroomlight
fill 79 235 312 79 248 312 minecraft:spruce_planks
setblock 79 235 313 minecraft:shroomlight
fill 79 235 314 79 248 314 minecraft:spruce_planks
setblock 79 235 315 minecraft:shroomlight
fill 79 235 316 79 248 316 minecraft:spruce_planks
setblock 80 235 312 minecraft:shroomlight
fill 80 235 313 80 248 313 minecraft:spruce_planks
setblock 80 235 314 minecraft:shroomlight
fill 80 235 315 80 248 315 minecraft:spruce_planks
setblock 80 235 316 minecraft:shroomlight
setblock 81 235 276 minecraft:spruce_planks
setblock 81 235 312 minecraft:spruce_planks
setblock 81 235 313 minecraft:shroomlight
setblock 81 235 314 minecraft:spruce_planks
setblock 81 235 315 minecraft:shroomlight
fill 81 235 316 81 248 316 minecraft:spruce_planks
fill 82 235 276 82 235 278 minecraft:iron_bars
setblock 82 235 312 minecraft:shroomlight
fill 82 235 313 82 248 313 minecraft:spruce_planks
setblock 82 235 314 minecraft:shroomlight
fill 82 235 315 82 248 315 minecraft:spruce_planks
setblock 82 235 316 minecraft:shroomlight
fill 86 235 307 86 237 308 minecraft:white_wool
fill 86 235 310 86 237 311 minecraft:white_wool
setblock 87 235 316 minecraft:spruce_planks
setblock 88 235 276 minecraft:spruce_planks
setblock 88 235 283 minecraft:spruce_planks
setblock 88 235 290 minecraft:spruce_planks
setblock 88 235 297 minecraft:spruce_planks
setblock 88 235 304 minecraft:spruce_planks
setblock 88 235 311 minecraft:spruce_planks
setblock 47 236 299 minecraft:white_wool
setblock 48 236 279 minecraft:spruce_planks
setblock 48 236 286 minecraft:spruce_planks
setblock 48 236 293 minecraft:spruce_planks
setblock 48 236 300 minecraft:spruce_planks
setblock 48 236 307 minecraft:spruce_planks
fill 48 236 309 48 272 309 minecraft:spruce_planks
setblock 48 236 314 minecraft:spruce_planks
fill 51 236 276 51 236 278 minecraft:iron_bars
fill 52 236 275 53 251 275 minecraft:cyan_concrete
setblock 52 236 276 minecraft:spruce_planks
fill 52 236 303 52 236 316 minecraft:iron_bars
setblock 53 236 316 minecraft:spruce_planks
setblock 54 236 275 minecraft:light_blue_wool
fill 55 236 275 55 247 275 minecraft:cyan_concrete
fill 57 236 277 57 237 281 minecraft:iron_bars
setblock 59 236 276 minecraft:spruce_planks
setblock 60 236 316 minecraft:spruce_planks
fill 63 236 276 63 236 294 minecraft:iron_bars
fill 63 236 300 63 236 312 minecraft:iron_bars
fill 64 236 306 64 237 314 minecraft:spruce_planks
fill 64 236 316 64 237 316 minecraft:spruce_planks
fill 65 236 307 65 237 307 minecraft:spruce_planks
fill 65 236 309 65 237 309 minecraft:spruce_planks
fill 65 236 311 65 237 311 minecraft:spruce_planks
fill 65 236 313 65 237 313 minecraft:spruce_planks
fill 65 236 315 65 237 315 minecraft:spruce_planks
setblock 66 236 276 minecraft:spruce_planks
fill 66 236 306 66 237 306 minecraft:spruce_planks
fill 66 236 308 66 237 308 minecraft:spruce_planks
fill 66 236 310 66 237 310 minecraft:spruce_planks
fill 66 236 312 66 237 312 minecraft:spruce_planks
fill 66 236 314 66 237 314 minecraft:spruce_planks
fill 66 236 316 66 237 316 minecraft:spruce_planks
fill 67 236 307 67 237 307 minecraft:spruce_planks
fill 67 236 309 67 237 309 minecraft:spruce_planks
fill 67 236 311 67 237 311 minecraft:spruce_planks
fill 67 236 313 67 237 313 minecraft:spruce_planks
fill 67 236 315 67 237 315 minecraft:spruce_planks
fill 68 236 306 68 237 306 minecraft:spruce_planks
fill 68 236 308 68 237 308 minecraft:spruce_planks
fill 68 236 310 68 237 310 minecraft:spruce_planks
fill 68 236 312 68 237 312 minecraft:spruce_planks
fill 68 236 314 68 237 314 minecraft:spruce_planks
fill 68 236 316 68 237 316 minecraft:spruce_planks
fill 69 236 276 69 236 296 minecraft:iron_bars
fill 69 236 299 69 236 315 minecraft:iron_bars
fill 70 236 306 70 237 306 minecraft:spruce_planks
fill 70 236 308 70 237 308 minecraft:spruce_planks
fill 70 236 310 70 237 310 minecraft:spruce_planks
fill 70 236 312 70 237 312 minecraft:spruce_planks
fill 70 236 314 70 237 314 minecraft:spruce_planks
fill 70 236 316 70 237 316 minecraft:spruce_planks
fill 71 236 307 71 237 307 minecraft:spruce_planks
fill 71 236 309 72 237 309 minecraft:spruce_planks
fill 71 236 311 71 237 311 minecraft:spruce_planks
fill 71 236 313 71 237 313 minecraft:spruce_planks
fill 71 236 315 71 237 315 minecraft:spruce_planks
setblock 71 236 317 minecraft:light_blue_wool
fill 72 236 285 88 236 285 minecraft:spruce_planks
fill 72 236 306 72 237 306 minecraft:spruce_planks
fill 72 236 308 72 237 308 minecraft:spruce_planks
fill 72 236 310 72 237 310 minecraft:spruce_planks
fill 72 236 312 74 236 312 minecraft:spruce_planks
fill 72 236 314 76 236 314 minecraft:spruce_planks
fill 72 236 316 72 237 316 minecraft:spruce_planks
setblock 73 236 276 minecraft:spruce_planks
fill 73 236 311 74 236 311 minecraft:spruce_planks
fill 73 236 313 74 236 313 minecraft:spruce_planks
setblock 74 236 316 minecraft:spruce_planks
fill 75 236 276 75 236 284 minecraft:iron_bars
fill 75 236 286 75 236 313 minecraft:iron_bars
setblock 75 236 315 minecraft:spruce_planks
fill 76 236 311 76 236 312 minecraft:spruce_planks
fill 76 236 316 76 237 316 minecraft:spruce_planks
setblock 77 236 311 minecraft:spruce_planks
fill 77 236 313 77 237 313 minecraft:spruce_planks
fill 77 236 315 77 237 315 minecraft:spruce_planks
fill 78 236 312 78 237 312 minecraft:spruce_planks
fill 78 236 314 78 237 314 minecraft:spruce_planks
fill 78 236 316 78 237 316 minecraft:spruce_planks
fill 79 236 313 79 237 313 minecraft:spruce_planks
fill 79 236 315 79 237 315 minecraft:spruce_planks
setblock 80 236 276 minecraft:spruce_planks
fill 80 236 312 80 237 312 minecraft:spruce_planks
fill 80 236 314 80 237 314 minecraft:spruce_planks
fill 80 236 316 80 237 316 minecraft:spruce_planks
fill 81 236 276 81 236 284 minecraft:iron_bars
fill 81 236 286 81 236 315 minecraft:iron_bars
fill 82 236 312 82 237 312 minecraft:spruce_planks
fill 82 236 314 82 237 314 minecraft:spruce_planks
fill 82 236 316 82 237 316 minecraft:spruce_planks
fill 86 236 309 86 237 309 minecraft:white_wool
setblock 87 236 276 minecraft:spruce_planks
fill 87 236 277 87 237 284 minecraft:iron_bars
fill 87 236 286 87 237 315 minecraft:iron_bars
setblock 88 236 282 minecraft:spruce_planks
setblock 88 236 289 minecraft:spruce_planks
setblock 88 236 296 minecraft:spruce_planks
setblock 88 236 303 minecraft:spruce_planks
setblock 88 236 310 minecraft:spruce_planks
setblock 88 236 316 minecraft:spruce_planks
setblock 89 236 313 minecraft:white_wool
fill 89 236 314 89 252 314 minecraft:cyan_concrete
fill 47 237 299 47 249 299 minecraft:cyan_concrete
setblock 48 237 280 minecraft:spruce_planks
setblock 48 237 287 minecraft:spruce_planks
setblock 48 237 294 minecraft:spruce_planks
setblock 48 237 301 minecraft:spruce_planks
setblock 48 237 308 minecraft:spruce_planks
setblock 48 237 315 minecraft:spruce_planks
setblock 50 237 278 minecraft:light[level=12]
setblock 50 237 285 minecraft:light[level=12]
setblock 50 237 292 minecraft:light[level=12]
setblock 50 237 299 minecraft:light[level=12]
setblock 50 237 306 minecraft:light[level=12]
setblock 50 237 313 minecraft:light[level=12]
setblock 51 237 276 minecraft:spruce_planks
fill 51 237 277 51 237 279 minecraft:iron_bars
fill 51 237 281 51 237 304 minecraft:iron_bars
fill 54 237 275 54 251 275 minecraft:cyan_concrete
setblock 54 237 316 minecraft:spruce_planks
fill 57 237 282 57 237 316 minecraft:iron_bars
setblock 58 237 276 minecraft:spruce_planks
setblock 61 237 316 minecraft:spruce_planks
fill 63 237 276 63 237 279 minecraft:iron_bars
setblock 64 237 278 minecraft:light[level=12]
setblock 64 237 285 minecraft:light[level=12]
setblock 64 237 292 minecraft:light[level=12]
setblock 64 237 299 minecraft:light[level=12]
fill 64 237 315 64 248 315 minecraft:spruce_planks
setblock 65 237 276 minecraft:spruce_planks
fill 69 237 276 69 237 288 minecraft:iron_bars
fill 69 237 306 69 237 315 minecraft:spruce_planks
setblock 71 237 278 minecraft:light[level=12]
setblock 71 237 285 minecraft:light[level=12]
setblock 71 237 292 minecraft:light[level=12]
setblock 71 237 299 minecraft:light[level=12]
fill 71 237 317 71 251 317 minecraft:cyan_concrete
setblock 72 237 276 minecraft:spruce_planks
setblock 72 237 312 minecraft:spruce_planks
fill 72 237 314 72 237 315 minecraft:spruce_planks
fill 73 237 311 77 237 311 minecraft:dark_oak_planks
fill 73 237 316 75 240 316 minecraft:shroomlight
fill 75 237 276 75 237 278 minecraft:iron_bars
setblock 76 237 312 minecraft:spruce_planks
setblock 76 237 314 minecraft:spruce_planks
setblock 78 237 278 minecraft:light[level=12]
setblock 78 237 285 minecraft:light[level=12]
setblock 78 237 292 minecraft:light[level=12]
setblock 78 237 299 minecraft:light[level=12]
setblock 78 237 306 minecraft:light[level=12]
setblock 79 237 276 minecraft:spruce_planks
fill 81 237 276 81 237 282 minecraft:iron_bars
fill 81 237 312 81 237 315 minecraft:spruce_planks
setblock 85 237 278 minecraft:light[level=12]
setblock 85 237 285 minecraft:light[level=12]
setblock 85 237 292 minecraft:light[level=12]
setblock 85 237 299 minecraft:light[level=12]
setblock 85 237 306 minecraft:light[level=12]
setblock 85 237 313 minecraft:light[level=12]
setblock 86 237 276 minecraft:spruce_planks
setblock 87 237 276 minecraft:iron_bars
setblock 87 237 285 minecraft:iron_bars
setblock 88 237 281 minecraft:spruce_planks
setblock 88 237 288 minecraft:spruce_planks
setblock 88 237 295 minecraft:spruce_planks
setblock 88 237 302 minecraft:spruce_planks
setblock 88 237 309 minecraft:spruce_planks
fill 89 237 313 89 240 313 minecraft:cyan_concrete
fill 47 238 289 47 251 289 minecraft:cyan_concrete
setblock 47 238 290 minecraft:light_blue_wool
fill 47 238 291 47 249 291 minecraft:cyan_concrete
setblock 47 238 292 minecraft:white_wool
fill 47 238 293 47 251 294 minecraft:cyan_concrete
setblock 47 238 296 minecraft:light_blue_wool
fill 51 238 300 51 238 316 minecraft:iron_bars
fill 58 238 292 58 247 300 minecraft:white_wool
setblock 64 238 306 minecraft:shroomlight
fill 64 238 307 64 248 307 minecraft:spruce_planks
setblock 64 238 308 minecraft:shroomlight
fill 64 238 309 64 248 309 minecraft:spruce_planks
setblock 64 238 310 minecraft:shroomlight
fill 64 238 311 64 248 311 minecraft:spruce_planks
setblock 64 238 312 minecraft:shroomlight
fill 64 238 313 64 248 313 minecraft:spruce_planks
setblock 64 238 314 minecraft:shroomlight
setblock 64 238 316 minecraft:shroomlight
setblock 65 238 307 minecraft:shroomlight
setblock 65 238 309 minecraft:shroomlight
setblock 65 238 311 minecraft:shroomlight
setblock 65 238 313 minecraft:shroomlight
setblock 65 238 315 minecraft:shroomlight
setblock 66 238 306 minecraft:shroomlight
setblock 66 238 308 minecraft:shroomlight
setblock 66 238 310 minecraft:shroomlight
setblock 66 238 312 minecraft:shroomlight
setblock 66 238 314 minecraft:shroomlight
setblock 66 238 316 minecraft:shroomlight
setblock 67 238 307 minecraft:shroomlight
setblock 67 238 309 minecraft:shroomlight
setblock 67 238 311 minecraft:shroomlight
setblock 67 238 313 minecraft:shroomlight
setblock 67 238 315 minecraft:shroomlight
setblock 68 238 306 minecraft:shroomlight
setblock 68 238 308 minecraft:shroomlight
setblock 68 238 310 minecraft:shroomlight
setblock 68 238 312 minecraft:shroomlight
setblock 68 238 314 minecraft:shroomlight
setblock 68 238 316 minecraft:shroomlight
fill 69 238 306 69 248 306 minecraft:spruce_planks
setblock 69 238 307 minecraft:shroomlight
fill 69 238 308 69 248 308 minecraft:spruce_planks
setblock 69 238 309 minecraft:shroomlight
fill 69 238 310 69 248 310 minecraft:spruce_planks
setblock 69 238 311 minecraft:shroomlight
fill 69 238 312 69 248 312 minecraft:spruce_planks
setblock 69 238 313 minecraft:shroomlight
fill 69 238 314 69 248 314 minecraft:spruce_planks
setblock 69 238 315 minecraft:shroomlight
setblock 70 238 306 minecraft:shroomlight
setblock 70 238 308 minecraft:shroomlight
setblock 70 238 310 minecraft:shroomlight
setblock 70 238 312 minecraft:shroomlight
setblock 70 238 314 minecraft:shroomlight
setblock 70 238 316 minecraft:shroomlight
setblock 71 238 307 minecraft:shroomlight
setblock 71 238 309 minecraft:shroomlight
setblock 71 238 311 minecraft:shroomlight
setblock 71 238 313 minecraft:shroomlight
setblock 71 238 315 minecraft:shroomlight
setblock 72 238 306 minecraft:shroomlight
setblock 72 238 308 minecraft:shroomlight
fill 72 238 309 72 248 309 minecraft:spruce_planks
setblock 72 238 310 minecraft:shroomlight
setblock 72 238 312 minecraft:shroomlight
setblock 72 238 314 minecraft:shroomlight
fill 72 238 315 72 248 315 minecraft:spruce_planks
setblock 72 238 316 minecraft:shroomlight
setblock 74 238 311 minecraft:spruce_planks
setblock 76 238 312 minecraft:shroomlight
setblock 76 238 314 minecraft:shroomlight
setblock 76 238 316 minecraft:shroomlight
setblock 77 238 311 minecraft:spruce_planks
setblock 77 238 313 minecraft:shroomlight
setblock 77 238 315 minecraft:shroomlight
setblock 78 238 312 minecraft:shroomlight
setblock 78 238 314 minecraft:shroomlight
setblock 78 238 316 minecraft:shroomlight
setblock 79 238 313 minecraft:shroomlight
setblock 79 238 315 minecraft:shroomlight
setblock 80 238 312 minecraft:shroomlight
setblock 80 238 314 minecraft:shroomlight
setblock 80 238 316 minecraft:shroomlight
setblock 81 238 312 minecraft:spruce_planks
setblock 81 238 313 minecraft:shroomlight
fill 81 238 314 81 248 314 minecraft:spruce_planks
setblock 81 238 315 minecraft:shroomlight
setblock 82 238 312 minecraft:shroomlight
setblock 82 238 314 minecraft:shroomlight
setblock 82 238 316 minecraft:shroomlight
setblock 84 238 317 minecraft:light_blue_wool
fill 86 238 306 86 238 312 minecraft:iron_bars
setblock 89 238 285 minecraft:light_blue_wool
fill 89 238 286 89 251 286 minecraft:cyan_concrete
fill 47 239 290 47 251 290 minecraft:cyan_concrete
fill 47 239 292 47 252 292 minecraft:cyan_concrete
fill 47 239 296 47 248 296 minecraft:cyan_concrete
fill 48 239 280 56 245 280 minecraft:white_wool
fill 48 239 282 48 240 282 minecraft:spruce_planks
fill 48 239 289 48 240 289 minecraft:spruce_planks
fill 48 239 296 48 240 296 minecraft:spruce_planks
fill 48 239 303 48 240 303 minecraft:spruce_planks
fill 48 239 310 48 240 310 minecraft:spruce_planks
fill 49 239 276 49 240 276 minecraft:spruce_planks
fill 49 239 316 49 240 316 minecraft:spruce_planks
fill 56 239 276 56 240 276 minecraft:spruce_planks
fill 56 239 316 56 240 316 minecraft:spruce_planks
fill 63 239 276 63 240 276 minecraft:spruce_planks
fill 63 239 316 64 240 316 minecraft:spruce_planks
fill 64 239 306 64 240 306 minecraft:spruce_planks
fill 64 239 308 64 240 308 minecraft:spruce_planks
fill 64 239 310 64 240 310 minecraft:spruce_planks
fill 64 239 312 64 240 312 minecraft:spruce_planks
fill 64 239 314 64 240 314 minecraft:spruce_planks
fill 65 239 307 65 240 307 minecraft:spruce_planks
fill 65 239 309 65 240 309 minecraft:spruce_planks
fill 65 239 311 65 240 311 minecraft:spruce_planks
fill 65 239 313 65 240 313 minecraft:spruce_planks
fill 65 239 315 65 240 315 minecraft:spruce_planks
fill 66 239 306 66 240 306 minecraft:spruce_planks
fill 66 239 308 66 240 308 minecraft:spruce_planks
fill 66 239 310 66 240 310 minecraft:spruce_planks
fill 66 239 312 66 240 312 minecraft:spruce_planks
fill 66 239 314 66 240 314 minecraft:spruce_planks
fill 66 239 316 66 240 316 minecraft:spruce_planks
fill 67 239 307 67 240 307 minecraft:spruce_planks
fill 67 239 309 67 240 309 minecraft:spruce_planks
fill 67 239 311 67 240 311 minecraft:spruce_planks
fill 67 239 313 67 240 313 minecraft:spruce_planks
fill 67 239 315 67 240 315 minecraft:spruce_planks
fill 68 239 306 68 240 306 minecraft:spruce_planks
fill 68 239 308 68 240 308 minecraft:spruce_planks
fill 68 239 310 68 240 310 minecraft:spruce_planks
fill 68 239 312 68 240 312 minecraft:spruce_planks
fill 68 239 314 68 240 314 minecraft:spruce_planks
fill 68 239 316 68 240 316 minecraft:spruce_planks
fill 69 239 307 69 240 307 minecraft:spruce_planks
fill 69 239 309 69 240 309 minecraft:spruce_planks
fill 69 239 311 69 240 311 minecraft:spruce_planks
fill 69 239 313 69 240 313 minecraft:spruce_planks
fill 69 239 315 69 240 315 minecraft:spruce_planks
fill 70 239 276 70 240 276 minecraft:spruce_planks
fill 70 239 306 70 240 306 minecraft:spruce_planks
fill 70 239 308 70 240 308 minecraft:spruce_planks
fill 70 239 310 70 240 310 minecraft:spruce_planks
fill 70 239 312 70 240 312 minecraft:spruce_planks
fill 70 239 314 70 240 314 minecraft:spruce_planks
fill 70 239 316 70 240 316 minecraft:spruce_planks
fill 71 239 307 71 240 307 minecraft:spruce_planks
fill 71 239 309 71 240 309 minecraft:spruce_planks
fill 71 239 311 71 240 311 minecraft:spruce_planks
fill 71 239 313 71 240 313 minecraft:spruce_planks
fill 71 239 315 71 240 315 minecraft:spruce_planks
fill 72 239 306 72 240 306 minecraft:spruce_planks
fill 72 239 308 72 240 308 minecraft:spruce_planks
fill 72 239 310 72 240 310 minecraft:spruce_planks
fill 72 239 312 72 240 312 minecraft:spruce_planks
fill 72 239 314 72 240 314 minecraft:spruce_planks
fill 72 239 316 72 240 316 minecraft:spruce_planks
fill 76 239 312 76 240 312 minecraft:spruce_planks
fill 76 239 314 76 240 314 minecraft:spruce_planks
fill 76 239 316 76 240 316 minecraft:spruce_planks
fill 77 239 276 77 240 276 minecraft:spruce_planks
fill 77 239 313 77 240 313 minecraft:spruce_planks
fill 77 239 315 77 240 315 minecraft:spruce_planks
fill 78 239 312 78 240 312 minecraft:spruce_planks
fill 78 239 314 78 240 314 minecraft:spruce_planks
fill 78 239 316 78 240 316 minecraft:spruce_planks
fill 79 239 313 79 240 313 minecraft:spruce_planks
fill 79 239 315 79 240 315 minecraft:spruce_planks
fill 80 239 312 88 240 312 minecraft:white_wool
fill 80 239 314 80 240 314 minecraft:spruce_planks
fill 80 239 316 80 240 316 minecraft:spruce_planks
fill 81 239 313 81 240 313 minecraft:spruce_planks
fill 81 239 315 81 240 315 minecraft:spruce_planks
fill 82 239 314 82 240 314 minecraft:spruce_planks
fill 82 239 316 82 240 316 minecraft:spruce_planks
fill 84 239 276 84 240 276 minecraft:spruce_planks
fill 84 239 316 84 240 316 minecraft:spruce_planks
fill 84 239 317 84 247 317 minecraft:cyan_concrete
fill 86 239 306 86 239 311 minecraft:iron_bars
fill 88 239 279 88 240 279 minecraft:spruce_planks
fill 88 239 286 88 240 286 minecraft:spruce_planks
fill 88 239 293 88 240 293 minecraft:spruce_planks
fill 88 239 300 88 240 300 minecraft:spruce_planks
fill 88 239 307 88 240 307 minecraft:spruce_planks
fill 88 239 314 88 240 314 minecraft:spruce_planks
setblock 89 239 278 minecraft:light_blue_wool
fill 89 239 279 89 251 280 minecraft:cyan_concrete
fill 89 239 285 89 248 285 minecraft:cyan_concrete
fill 89 239 291 89 251 294 minecraft:cyan_concrete
setblock 89 239 295 minecraft:light_blue_wool
fill 89 239 296 89 247 296 minecraft:cyan_concrete
setblock 89 239 307 minecraft:white_wool
fill 47 240 277 47 251 277 minecraft:cyan_concrete
setblock 47 240 278 minecraft:light_blue_wool
setblock 47 240 316 minecraft:light_blue_wool
fill 48 240 276 48 240 279 minecraft:spruce_planks
fill 48 240 283 48 240 287 minecraft:spruce_planks
fill 48 240 290 48 240 294 minecraft:spruce_planks
fill 48 240 297 48 240 301 minecraft:spruce_planks
fill 48 240 304 48 240 308 minecraft:spruce_planks
fill 48 240 311 48 240 315 minecraft:spruce_planks
setblock 48 240 317 minecraft:light_blue_wool
fill 50 240 316 54 240 316 minecraft:spruce_planks
fill 51 240 276 55 240 276 minecraft:spruce_planks
fill 57 240 316 61 240 316 minecraft:spruce_planks
fill 58 240 276 62 240 276 minecraft:spruce_planks
setblock 58 240 317 minecraft:light_blue_wool
fill 65 240 276 69 240 276 minecraft:spruce_planks
fill 72 240 276 76 240 276 minecraft:spruce_planks
fill 77 240 317 77 243 317 minecraft:cyan_concrete
setblock 78 240 317 minecraft:white_wool
fill 79 240 276 83 240 276 minecraft:spruce_planks
fill 79 240 317 79 251 317 minecraft:cyan_concrete
fill 85 240 316 88 240 316 minecraft:spruce_planks
fill 86 240 276 88 240 276 minecraft:spruce_planks
fill 88 240 277 88 240 278 minecraft:spruce_planks
fill 88 240 281 88 240 285 minecraft:spruce_planks
fill 88 240 288 88 240 292 minecraft:spruce_planks
fill 88 240 295 88 240 299 minecraft:spruce_planks
fill 88 240 302 88 240 306 minecraft:spruce_planks
fill 88 240 309 88 240 311 minecraft:spruce_planks
setblock 88 240 313 minecraft:spruce_planks
fill 89 240 278 89 247 278 minecraft:cyan_concrete
setblock 89 240 290 minecraft:white_wool
fill 89 240 295 89 251 295 minecraft:cyan_concrete
fill 89 240 307 89 248 307 minecraft:cyan_concrete
fill 47 241 278 47 251 278 minecraft:cyan_concrete
fill 47 241 316 47 252 316 minecraft:cyan_concrete
setblock 48 241 277 minecraft:spruce_planks
setblock 48 241 284 minecraft:spruce_planks
setblock 48 241 291 minecraft:spruce_planks
setblock 48 241 298 minecraft:spruce_planks
setblock 48 241 305 minecraft:spruce_planks
setblock 48 241 312 minecraft:spruce_planks
fill 48 241 317 48 249 317 minecraft:cyan_concrete
setblock 50 241 278 minecraft:light[level=15]
setblock 50 241 286 minecraft:light[level=15]
setblock 50 241 294 minecraft:light[level=15]
setblock 50 241 302 minecraft:light[level=15]
setblock 50 241 310 minecraft:light[level=15]
setblock 51 241 316 minecraft:spruce_planks
setblock 54 241 276 minecraft:spruce_planks
setblock 58 241 278 minecraft:light[level=15]
setblock 58 241 286 minecraft:light[level=15]
setblock 58 241 302 minecraft:light[level=15]
setblock 58 241 310 minecraft:light[level=15]
setblock 58 241 316 minecraft:spruce_planks
fill 58 241 317 58 249 317 minecraft:cyan_concrete
setblock 61 241 276 minecraft:spruce_planks
setblock 64 241 306 minecraft:shroomlight
setblock 64 241 308 minecraft:shroomlight
setblock 64 241 310 minecraft:shroomlight
setblock 64 241 312 minecraft:shroomlight
setblock 64 241 314 minecraft:shroomlight
setblock 64 241 316 minecraft:shroomlight
setblock 65 241 307 minecraft:shroomlight
setblock 65 241 309 minecraft:shroomlight
setblock 65 241 311 minecraft:shroomlight
setblock 65 241 313 minecraft:shroomlight
setblock 65 241 315 minecraft:shroomlight
setblock 66 241 278 minecraft:light[level=15]
setblock 66 241 286 minecraft:light[level=15]
setblock 66 241 294 minecraft:light[level=15]
setblock 66 241 302 minecraft:light[level=15]
setblock 66 241 306 minecraft:shroomlight
setblock 66 241 308 minecraft:shroomlight
setblock 66 241 310 minecraft:shroomlight
setblock 66 241 312 minecraft:shroomlight
setblock 66 241 314 minecraft:shroomlight
setblock 66 241 316 minecraft:shroomlight
setblock 67 241 307 minecraft:shroomlight
setblock 67 241 309 minecraft:shroomlight
setblock 67 241 311 minecraft:shroomlight
setblock 67 241 313 minecraft:shroomlight
setblock 67 241 315 minecraft:shroomlight
setblock 68 241 276 minecraft:spruce_planks
setblock 68 241 306 minecraft:shroomlight
setblock 68 241 308 minecraft:shroomlight
setblock 68 241 310 minecraft:shroomlight
setblock 68 241 312 minecraft:shroomlight
setblock 68 241 314 minecraft:shroomlight
setblock 68 241 316 minecraft:shroomlight
setblock 69 241 307 minecraft:shroomlight
setblock 69 241 309 minecraft:shroomlight
setblock 69 241 311 minecraft:shroomlight
setblock 69 241 313 minecraft:shroomlight
setblock 69 241 315 minecraft:shroomlight
setblock 70 241 306 minecraft:shroomlight
setblock 70 241 308 minecraft:shroomlight
setblock 70 241 310 minecraft:shroomlight
setblock 70 241 312 minecraft:shroomlight
setblock 70 241 314 minecraft:shroomlight
setblock 70 241 316 minecraft:shroomlight
setblock 71 241 307 minecraft:shroomlight
setblock 71 241 309 minecraft:shroomlight
setblock 71 241 311 minecraft:shroomlight
setblock 71 241 313 minecraft:shroomlight
setblock 71 241 315 minecraft:shroomlight
setblock 72 241 306 minecraft:shroomlight
setblock 72 241 308 minecraft:shroomlight
setblock 72 241 310 minecraft:shroomlight
setblock 72 241 312 minecraft:shroomlight
setblock 72 241 314 minecraft:shroomlight
setblock 72 241 316 minecraft:shroomlight
setblock 74 241 278 minecraft:light[level=15]
setblock 74 241 286 minecraft:light[level=15]
setblock 74 241 294 minecraft:light[level=15]
setblock 74 241 302 minecraft:light[level=15]
setblock 74 241 310 minecraft:light[level=15]
setblock 75 241 276 minecraft:spruce_planks
setblock 76 241 312 minecraft:shroomlight
setblock 76 241 314 minecraft:shroomlight
setblock 76 241 316 minecraft:shroomlight
setblock 77 241 313 minecraft:shroomlight
setblock 77 241 315 minecraft:shroomlight
setblock 78 241 312 minecraft:shroomlight
setblock 78 241 314 minecraft:shroomlight
setblock 78 241 316 minecraft:shroomlight
fill 78 241 317 78 248 317 minecraft:cyan_concrete
setblock 79 241 313 minecraft:shroomlight
setblock 79 241 315 minecraft:shroomlight
setblock 80 241 312 minecraft:shroomlight
setblock 80 241 314 minecraft:shroomlight
setblock 80 241 316 minecraft:shroomlight
fill 81 241 312 81 245 312 minecraft:white_wool
setblock 81 241 313 minecraft:shroomlight
setblock 81 241 315 minecraft:shroomlight
setblock 82 241 276 minecraft:spruce_planks
setblock 82 241 278 minecraft:light[level=15]
setblock 82 241 286 minecraft:light[level=15]
fill 82 241 289 82 244 289 minecraft:iron_bars
setblock 82 241 294 minecraft:light[level=15]
setblock 82 241 302 minecraft:light[level=15]
setblock 82 241 310 minecraft:light[level=15]
setblock 82 241 312 minecraft:shroomlight
setblock 82 241 314 minecraft:shroomlight
setblock 82 241 316 minecraft:shroomlight
fill 83 241 312 88 245 312 minecraft:white_wool
setblock 86 241 316 minecraft:spruce_planks
setblock 88 241 277 minecraft:spruce_planks
setblock 88 241 284 minecraft:spruce_planks
setblock 88 241 291 minecraft:spruce_planks
setblock 88 241 298 minecraft:spruce_planks
setblock 88 241 305 minecraft:spruce_planks
fill 89 241 290 89 251 290 minecraft:cyan_concrete
setblock 89 241 313 minecraft:white_wool
setblock 48 242 278 minecraft:spruce_planks
setblock 48 242 285 minecraft:spruce_planks
setblock 48 242 292 minecraft:spruce_planks
setblock 48 242 299 minecraft:spruce_planks
setblock 48 242 306 minecraft:spruce_planks
setblock 48 242 313 minecraft:spruce_planks
setblock 51 242 317 minecraft:light_blue_wool
setblock 52 242 316 minecraft:spruce_planks
setblock 53 242 276 minecraft:spruce_planks
fill 58 242 313 58 243 315 minecraft:iron_bars
setblock 59 242 316 minecraft:spruce_planks
setblock 60 242 276 minecraft:spruce_planks
fill 64 242 306 64 243 306 minecraft:spruce_planks
fill 64 242 308 64 243 308 minecraft:spruce_planks
fill 64 242 310 64 243 310 minecraft:spruce_planks
fill 64 242 312 64 243 312 minecraft:spruce_planks
fill 64 242 314 64 243 314 minecraft:spruce_planks
fill 64 242 316 64 243 316 minecraft:spruce_planks
setblock 64 242 317 minecraft:light_blue_wool
fill 65 242 307 65 243 307 minecraft:spruce_planks
fill 65 242 309 65 243 309 minecraft:spruce_planks
fill 65 242 311 65 243 311 minecraft:spruce_planks
fill 65 242 313 65 243 313 minecraft:spruce_planks
fill 65 242 315 65 243 315 minecraft:spruce_planks
fill 66 242 306 66 243 306 minecraft:spruce_planks
fill 66 242 308 66 243 308 minecraft:spruce_planks
fill 66 242 310 66 243 310 minecraft:spruce_planks
fill 66 242 312 66 243 312 minecraft:spruce_planks
fill 66 242 314 66 243 314 minecraft:spruce_planks
fill 66 242 316 66 243 316 minecraft:spruce_planks
setblock 67 242 276 minecraft:spruce_planks
fill 67 242 307 67 243 307 minecraft:spruce_planks
fill 67 242 309 67 243 309 minecraft:spruce_planks
fill 67 242 311 67 243 311 minecraft:spruce_planks
fill 67 242 313 67 243 313 minecraft:spruce_planks
fill 67 242 315 67 243 315 minecraft:spruce_planks
setblock 68 242 275 minecraft:light_blue_wool
fill 68 242 306 68 243 306 minecraft:spruce_planks
fill 68 242 308 68 243 308 minecraft:spruce_planks
fill 68 242 310 68 243 310 minecraft:spruce_planks
fill 68 242 312 68 243 312 minecraft:spruce_planks
fill 68 242 314 68 243 314 minecraft:spruce_planks
fill 68 242 316 68 243 316 minecraft:spruce_planks
fill 69 242 307 69 243 307 minecraft:spruce_planks
fill 69 242 309 69 243 309 minecraft:spruce_planks
fill 69 242 311 69 243 311 minecraft:spruce_planks
fill 69 242 313 69 243 313 minecraft:spruce_planks
fill 69 242 315 69 243 315 minecraft:spruce_planks
fill 70 242 306 70 243 306 minecraft:spruce_planks
fill 70 242 308 70 243 308 minecraft:spruce_planks
fill 70 242 310 70 243 310 minecraft:spruce_planks
fill 70 242 312 70 243 312 minecraft:spruce_planks
fill 70 242 314 70 243 314 minecraft:spruce_planks
fill 70 242 316 70 243 316 minecraft:spruce_planks
fill 71 242 307 71 243 307 minecraft:spruce_planks
fill 71 242 309 71 243 309 minecraft:spruce_planks
fill 71 242 311 71 243 311 minecraft:spruce_planks
fill 71 242 313 71 243 313 minecraft:spruce_planks
fill 71 242 315 71 243 315 minecraft:spruce_planks
fill 72 242 306 72 243 306 minecraft:spruce_planks
fill 72 242 308 72 243 308 minecraft:spruce_planks
fill 72 242 310 72 243 310 minecraft:spruce_planks
fill 72 242 312 72 243 312 minecraft:spruce_planks
fill 72 242 314 72 243 314 minecraft:spruce_planks
fill 72 242 316 73 242 316 minecraft:spruce_planks
setblock 74 242 276 minecraft:spruce_planks
fill 76 242 312 76 243 312 minecraft:spruce_planks
fill 76 242 314 76 243 314 minecraft:spruce_planks
fill 76 242 316 76 243 316 minecraft:spruce_planks
fill 77 242 313 77 243 313 minecraft:spruce_planks
fill 77 242 315 77 243 315 minecraft:spruce_planks
fill 78 242 312 78 243 312 minecraft:spruce_planks
fill 78 242 314 78 243 314 minecraft:spruce_planks
fill 78 242 316 78 243 316 minecraft:spruce_planks
fill 79 242 313 79 243 313 minecraft:spruce_planks
fill 79 242 315 79 243 315 minecraft:spruce_planks
fill 80 242 312 80 243 312 minecraft:white_wool
fill 80 242 314 80 243 314 minecraft:spruce_planks
fill 80 242 316 80 243 316 minecraft:spruce_planks
setblock 81 242 276 minecraft:spruce_planks
fill 81 242 313 81 243 313 minecraft:spruce_planks
fill 81 242 315 81 243 315 minecraft:spruce_planks
fill 82 242 312 82 243 312 minecraft:white_wool
fill 82 242 314 82 243 314 minecraft:spruce_planks
fill 82 242 316 82 243 316 minecraft:spruce_planks
setblock 87 242 316 minecraft:spruce_planks
setblock 88 242 276 minecraft:spruce_planks
setblock 88 242 283 minecraft:spruce_planks
setblock 88 242 290 minecraft:spruce_planks
setblock 88 242 297 minecraft:spruce_planks
setblock 88 242 304 minecraft:spruce_planks
setblock 88 242 311 minecraft:spruce_planks
fill 89 242 313 89 252 313 minecraft:cyan_concrete
setblock 48 243 279 minecraft:spruce_planks
setblock 48 243 286 minecraft:spruce_planks
setblock 48 243 293 minecraft:spruce_planks
setblock 48 243 300 minecraft:spruce_planks
setblock 48 243 307 minecraft:spruce_planks
setblock 48 243 314 minecraft:spruce_planks
setblock 49 243 275 minecraft:white_wool
setblock 50 243 278 minecraft:light[level=12]
setblock 50 243 285 minecraft:light[level=12]
setblock 50 243 292 minecraft:light[level=12]
setblock 50 243 299 minecraft:light[level=12]
setblock 50 243 306 minecraft:light[level=12]
setblock 50 243 313 minecraft:light[level=12]
fill 51 243 317 51 251 317 minecraft:cyan_concrete
setblock 52 243 276 minecraft:spruce_planks
setblock 53 243 316 minecraft:spruce_planks
setblock 57 243 278 minecraft:light[level=12]
setblock 57 243 285 minecraft:light[level=12]
setblock 57 243 292 minecraft:light[level=12]
setblock 57 243 299 minecraft:light[level=12]
setblock 57 243 306 minecraft:light[level=12]
setblock 57 243 313 minecraft:light[level=12]
setblock 59 243 276 minecraft:spruce_planks
setblock 60 243 316 minecraft:spruce_planks
setblock 64 243 278 minecraft:light[level=12]
setblock 64 243 285 minecraft:light[level=12]
setblock 64 243 292 minecraft:light[level=12]
setblock 64 243 299 minecraft:light[level=12]
fill 64 243 317 64 251 317 minecraft:cyan_concrete
setblock 66 243 276 minecraft:spruce_planks
fill 68 243 275 68 249 275 minecraft:cyan_concrete
setblock 71 243 278 minecraft:light[level=12]
setblock 71 243 285 minecraft:light[level=12]
setblock 71 243 292 minecraft:light[level=12]
setblock 71 243 299 minecraft:light[level=12]
setblock 72 243 316 minecraft:spruce_planks
setblock 73 243 276 minecraft:spruce_planks
setblock 74 243 316 minecraft:spruce_planks
setblock 78 243 278 minecraft:light[level=12]
setblock 78 243 285 minecraft:light[level=12]
setblock 78 243 292 minecraft:light[level=12]
setblock 78 243 299 minecraft:light[level=12]
setblock 78 243 306 minecraft:light[level=12]
setblock 80 243 276 minecraft:spruce_planks
fill 80 243 281 80 246 281 minecraft:iron_bars
fill 84 243 297 84 250 297 minecraft:green_terracotta
setblock 85 243 278 minecraft:light[level=12]
setblock 85 243 285 minecraft:light[level=12]
setblock 85 243 292 minecraft:light[level=12]
setblock 85 243 299 minecraft:light[level=12]
setblock 85 243 306 minecraft:light[level=12]
setblock 85 243 313 minecraft:light[level=12]
fill 86 243 317 86 251 317 minecraft:cyan_concrete
setblock 87 243 276 minecraft:spruce_planks
setblock 87 243 317 minecraft:light_blue_wool
setblock 88 243 282 minecraft:spruce_planks
setblock 88 243 289 minecraft:spruce_planks
setblock 88 243 296 minecraft:spruce_planks
setblock 88 243 303 minecraft:spruce_planks
setblock 88 243 310 minecraft:spruce_planks
setblock 88 243 316 minecraft:spruce_planks
setblock 47 244 279 minecraft:white_wool
setblock 48 244 287 minecraft:spruce_planks
setblock 48 244 294 minecraft:spruce_planks
setblock 48 244 301 minecraft:spruce_planks
setblock 48 244 308 minecraft:spruce_planks
setblock 48 244 315 minecraft:spruce_planks
fill 49 244 275 49 251 275 minecraft:cyan_concrete
setblock 51 244 276 minecraft:spruce_planks
setblock 54 244 316 minecraft:spruce_planks
setblock 58 244 276 minecraft:spruce_planks
setblock 61 244 316 minecraft:spruce_planks
setblock 64 244 306 minecraft:shroomlight
setblock 64 244 308 minecraft:shroomlight
setblock 64 244 310 minecraft:shroomlight
setblock 64 244 312 minecraft:shroomlight
setblock 64 244 314 minecraft:shroomlight
setblock 64 244 316 minecraft:shroomlight
setblock 65 244 276 minecraft:spruce_planks
setblock 65 244 307 minecraft:shroomlight
setblock 65 244 309 minecraft:shroomlight
setblock 65 244 311 minecraft:shroomlight
setblock 65 244 313 minecraft:shroomlight
setblock 65 244 315 minecraft:shroomlight
setblock 66 244 306 minecraft:shroomlight
setblock 66 244 308 minecraft:shroomlight
setblock 66 244 310 minecraft:shroomlight
setblock 66 244 312 minecraft:shroomlight
setblock 66 244 314 minecraft:shroomlight
setblock 66 244 316 minecraft:shroomlight
setblock 67 244 307 minecraft:shroomlight
setblock 67 244 309 minecraft:shroomlight
setblock 67 244 311 minecraft:shroomlight
setblock 67 244 313 minecraft:shroomlight
setblock 67 244 315 minecraft:shroomlight
setblock 68 244 306 minecraft:shroomlight
setblock 68 244 308 minecraft:shroomlight
setblock 68 244 310 minecraft:shroomlight
setblock 68 244 312 minecraft:shroomlight
setblock 68 244 314 minecraft:shroomlight
setblock 68 244 316 minecraft:shroomlight
setblock 69 244 307 minecraft:shroomlight
setblock 69 244 309 minecraft:shroomlight
setblock 69 244 311 minecraft:shroomlight
setblock 69 244 313 minecraft:shroomlight
setblock 69 244 315 minecraft:shroomlight
setblock 70 244 306 minecraft:shroomlight
setblock 70 244 308 minecraft:shroomlight
setblock 70 244 310 minecraft:shroomlight
setblock 70 244 312 minecraft:shroomlight
setblock 70 244 314 minecraft:shroomlight
setblock 70 244 316 minecraft:shroomlight
setblock 71 244 307 minecraft:shroomlight
setblock 71 244 309 minecraft:shroomlight
setblock 71 244 311 minecraft:shroomlight
setblock 71 244 313 minecraft:shroomlight
setblock 71 244 315 minecraft:shroomlight
setblock 72 244 276 minecraft:spruce_planks
setblock 72 244 306 minecraft:shroomlight
setblock 72 244 308 minecraft:shroomlight
setblock 72 244 310 minecraft:shroomlight
setblock 72 244 312 minecraft:shroomlight
setblock 72 244 314 minecraft:shroomlight
setblock 72 244 316 minecraft:shroomlight
setblock 75 244 316 minecraft:spruce_planks
setblock 76 244 312 minecraft:shroomlight
setblock 76 244 314 minecraft:shroomlight
setblock 76 244 316 minecraft:shroomlight
setblock 77 244 313 minecraft:shroomlight
setblock 77 244 315 minecraft:shroomlight
setblock 77 244 317 minecraft:light_blue_wool
setblock 78 244 312 minecraft:shroomlight
setblock 78 244 314 minecraft:shroomlight
setblock 78 244 316 minecraft:shroomlight
setblock 79 244 276 minecraft:spruce_planks
setblock 79 244 313 minecraft:shroomlight
setblock 79 244 315 minecraft:shroomlight
setblock 80 244 312 minecraft:shroomlight
setblock 80 244 314 minecraft:shroomlight
setblock 80 244 316 minecraft:shroomlight
setblock 81 244 313 minecraft:shroomlight
setblock 81 244 315 minecraft:shroomlight
setblock 82 244 312 minecraft:shroomlight
setblock 82 244 314 minecraft:shroomlight
setblock 82 244 316 minecraft:shroomlight
setblock 86 244 276 minecraft:spruce_planks
fill 87 244 317 87 251 317 minecraft:cyan_concrete
setblock 88 244 275 minecraft:light_blue_wool
setblock 88 244 281 minecraft:spruce_planks
setblock 88 244 288 minecraft:spruce_planks
setblock 88 244 295 minecraft:spruce_planks
setblock 88 244 302 minecraft:spruce_planks
setblock 88 244 309 minecraft:spruce_planks
fill 89 244 275 89 247 275 minecraft:cyan_concrete
fill 47 245 279 47 247 279 minecraft:cyan_concrete
fill 57 245 275 58 251 275 minecraft:cyan_concrete
setblock 57 245 317 minecraft:light_blue_wool
setblock 59 245 275 minecraft:light_blue_wool
fill 64 245 306 64 246 306 minecraft:spruce_planks
fill 64 245 308 64 246 308 minecraft:spruce_planks
fill 64 245 310 64 246 310 minecraft:spruce_planks
fill 64 245 312 64 246 312 minecraft:spruce_planks
fill 64 245 314 64 246 314 minecraft:spruce_planks
fill 64 245 316 64 246 316 minecraft:spruce_planks
fill 65 245 307 65 246 307 minecraft:spruce_planks
fill 65 245 309 65 246 309 minecraft:spruce_planks
fill 65 245 311 65 246 311 minecraft:spruce_planks
fill 65 245 313 65 246 313 minecraft:spruce_planks
fill 65 245 315 65 246 315 minecraft:spruce_planks
fill 66 245 306 66 246 306 minecraft:spruce_planks
fill 66 245 308 66 246 308 minecraft:spruce_planks
fill 66 245 310 66 246 310 minecraft:spruce_planks
fill 66 245 312 66 246 312 minecraft:spruce_planks
fill 66 245 314 66 246 314 minecraft:spruce_planks
fill 66 245 316 66 246 316 minecraft:spruce_planks
fill 67 245 307 67 246 307 minecraft:spruce_planks
fill 67 245 309 67 246 309 minecraft:spruce_planks
fill 67 245 311 67 246 311 minecraft:spruce_planks
fill 67 245 313 67 246 313 minecraft:spruce_planks
fill 67 245 315 67 246 315 minecraft:spruce_planks
fill 68 245 306 68 246 306 minecraft:spruce_planks
fill 68 245 308 68 246 308 minecraft:spruce_planks
fill 68 245 310 68 246 310 minecraft:spruce_planks
fill 68 245 312 68 246 312 minecraft:spruce_planks
fill 68 245 314 68 246 314 minecraft:spruce_planks
fill 68 245 316 68 246 316 minecraft:spruce_planks
fill 69 245 307 69 246 307 minecraft:spruce_planks
fill 69 245 309 69 246 309 minecraft:spruce_planks
fill 69 245 311 69 246 311 minecraft:spruce_planks
fill 69 245 313 69 246 313 minecraft:spruce_planks
fill 69 245 315 69 246 315 minecraft:spruce_planks
fill 70 245 306 70 246 306 minecraft:spruce_planks
fill 70 245 308 70 246 308 minecraft:spruce_planks
fill 70 245 310 70 246 310 minecraft:spruce_planks
fill 70 245 312 70 246 312 minecraft:spruce_planks
fill 70 245 314 70 246 314 minecraft:spruce_planks
fill 70 245 316 70 246 316 minecraft:spruce_planks
fill 71 245 307 71 246 307 minecraft:spruce_planks
fill 71 245 309 71 246 309 minecraft:spruce_planks
fill 71 245 311 71 246 311 minecraft:spruce_planks
fill 71 245 313 71 246 313 minecraft:spruce_planks
fill 71 245 315 71 246 315 minecraft:spruce_planks
fill 72 245 306 72 246 306 minecraft:spruce_planks
fill 72 245 308 72 246 308 minecraft:spruce_planks
fill 72 245 310 72 246 310 minecraft:spruce_planks
fill 72 245 312 72 246 312 minecraft:spruce_planks
fill 72 245 314 72 246 314 minecraft:spruce_planks
fill 72 245 316 72 246 316 minecraft:spruce_planks
fill 76 245 312 76 246 312 minecraft:spruce_planks
fill 76 245 314 76 246 314 minecraft:spruce_planks
fill 76 245 316 76 246 316 minecraft:spruce_planks
fill 77 245 313 77 246 313 minecraft:spruce_planks
fill 77 245 315 77 246 315 minecraft:spruce_planks
fill 77 245 317 77 251 317 minecraft:cyan_concrete
fill 78 245 312 78 246 312 minecraft:spruce_planks
fill 78 245 314 78 246 314 minecraft:spruce_planks
fill 78 245 316 78 246 316 minecraft:spruce_planks
fill 79 245 313 79 246 313 minecraft:spruce_planks
fill 79 245 315 79 246 315 minecraft:spruce_planks
setblock 80 245 312 minecraft:white_wool
fill 80 245 314 80 246 314 minecraft:spruce_planks
fill 80 245 316 80 246 316 minecraft:spruce_planks
fill 81 245 313 81 246 313 minecraft:spruce_planks
fill 81 245 315 81 246 315 minecraft:spruce_planks
fill 82 245 286 87 245 292 minecraft:dark_oak_planks
setblock 82 245 312 minecraft:white_wool
fill 82 245 314 82 246 314 minecraft:spruce_planks
fill 82 245 316 82 246 316 minecraft:spruce_planks
fill 88 245 275 88 251 275 minecraft:cyan_concrete
fill 48 246 280 56 246 280 minecraft:spruce_log
setblock 48 246 282 minecraft:spruce_planks
setblock 48 246 289 minecraft:spruce_planks
setblock 48 246 296 minecraft:spruce_planks
setblock 48 246 303 minecraft:spruce_planks
setblock 48 246 310 minecraft:spruce_planks
setblock 49 246 276 minecraft:spruce_planks
setblock 49 246 316 minecraft:spruce_planks
setblock 56 246 276 minecraft:spruce_planks
setblock 56 246 316 minecraft:spruce_planks
fill 57 246 317 57 251 317 minecraft:cyan_concrete
fill 59 246 275 59 251 275 minecraft:cyan_concrete
setblock 63 246 276 minecraft:spruce_planks
setblock 63 246 316 minecraft:spruce_planks
setblock 70 246 276 minecraft:spruce_planks
setblock 71 246 275 minecraft:white_wool
fill 72 246 275 72 247 275 minecraft:cyan_concrete
setblock 77 246 276 minecraft:spruce_planks
fill 80 246 312 88 246 312 minecraft:spruce_log
fill 82 246 286 87 246 292 minecraft:spruce_planks
setblock 84 246 276 minecraft:spruce_planks
setblock 84 246 316 minecraft:spruce_planks
setblock 88 246 279 minecraft:spruce_planks
setblock 88 246 286 minecraft:spruce_planks
setblock 88 246 293 minecraft:spruce_planks
setblock 88 246 300 minecraft:spruce_planks
setblock 88 246 307 minecraft:spruce_planks
setblock 88 246 314 minecraft:spruce_planks
setblock 47 247 314 minecraft:white_wool
fill 47 247 315 47 249 315 minecraft:cyan_concrete
setblock 48 247 276 minecraft:spruce_planks
setblock 48 247 283 minecraft:spruce_planks
setblock 48 247 290 minecraft:spruce_planks
setblock 48 247 297 minecraft:spruce_planks
setblock 48 247 304 minecraft:spruce_planks
setblock 48 247 311 minecraft:spruce_planks
setblock 50 247 316 minecraft:spruce_planks
fill 51 247 280 53 262 280 minecraft:spruce_log
setblock 55 247 276 minecraft:spruce_planks
setblock 57 247 316 minecraft:spruce_planks
setblock 62 247 276 minecraft:spruce_planks
setblock 64 247 306 minecraft:shroomlight
setblock 64 247 308 minecraft:shroomlight
setblock 64 247 310 minecraft:shroomlight
setblock 64 247 312 minecraft:shroomlight
setblock 64 247 314 minecraft:shroomlight
setblock 64 247 316 minecraft:shroomlight
setblock 65 247 307 minecraft:shroomlight
setblock 65 247 309 minecraft:shroomlight
setblock 65 247 311 minecraft:shroomlight
setblock 65 247 313 minecraft:shroomlight
setblock 65 247 315 minecraft:shroomlight
setblock 66 247 306 minecraft:shroomlight
setblock 66 247 308 minecraft:shroomlight
setblock 66 247 310 minecraft:shroomlight
setblock 66 247 312 minecraft:shroomlight
setblock 66 247 314 minecraft:shroomlight
setblock 66 247 316 minecraft:shroomlight
setblock 67 247 307 minecraft:shroomlight
setblock 67 247 309 minecraft:shroomlight
setblock 67 247 311 minecraft:shroomlight
setblock 67 247 313 minecraft:shroomlight
setblock 67 247 315 minecraft:shroomlight
setblock 68 247 306 minecraft:shroomlight
setblock 68 247 308 minecraft:shroomlight
setblock 68 247 310 minecraft:shroomlight
setblock 68 247 312 minecraft:shroomlight
setblock 68 247 314 minecraft:shroomlight
setblock 68 247 316 minecraft:shroomlight
setblock 69 247 276 minecraft:spruce_planks
setblock 69 247 307 minecraft:shroomlight
setblock 69 247 309 minecraft:shroomlight
setblock 69 247 311 minecraft:shroomlight
setblock 69 247 313 minecraft:shroomlight
setblock 69 247 315 minecraft:shroomlight
setblock 70 247 306 minecraft:shroomlight
setblock 70 247 308 minecraft:shroomlight
setblock 70 247 310 minecraft:shroomlight
setblock 70 247 312 minecraft:shroomlight
setblock 70 247 314 minecraft:shroomlight
setblock 70 247 316 minecraft:shroomlight
fill 71 247 275 71 251 275 minecraft:cyan_concrete
setblock 71 247 307 minecraft:shroomlight
setblock 71 247 309 minecraft:shroomlight
setblock 71 247 311 minecraft:shroomlight
setblock 71 247 313 minecraft:shroomlight
setblock 71 247 315 minecraft:shroomlight
setblock 72 247 306 minecraft:shroomlight
setblock 72 247 308 minecraft:shroomlight
setblock 72 247 310 minecraft:shroomlight
setblock 72 247 312 minecraft:shroomlight
setblock 72 247 314 minecraft:shroomlight
setblock 72 247 316 minecraft:shroomlight
setblock 72 247 317 minecraft:light_blue_wool
fill 76 247 276 76 248 276 minecraft:spruce_planks
fill 76 247 277 84 247 281 minecraft:dark_oak_planks
setblock 76 247 312 minecraft:shroomlight
setblock 76 247 314 minecraft:shroomlight
setblock 76 247 316 minecraft:shroomlight
setblock 77 247 276 minecraft:dark_oak_planks
setblock 77 247 313 minecraft:shroomlight
setblock 77 247 315 minecraft:shroomlight
setblock 78 247 312 minecraft:shroomlight
setblock 78 247 314 minecraft:shroomlight
setblock 78 247 316 minecraft:shroomlight
fill 79 247 276 82 247 276 minecraft:dark_oak_planks
setblock 79 247 313 minecraft:shroomlight
setblock 79 247 315 minecraft:shroomlight
setblock 80 247 312 minecraft:shroomlight
setblock 80 247 314 minecraft:shroomlight
setblock 80 247 316 minecraft:shroomlight
setblock 81 247 275 minecraft:white_wool
fill 81 247 312 81 248 312 minecraft:spruce_planks
setblock 81 247 313 minecraft:shroomlight
setblock 81 247 315 minecraft:shroomlight
fill 82 247 286 82 247 292 minecraft:dark_oak_planks
setblock 82 247 312 minecraft:shroomlight
setblock 82 247 314 minecraft:shroomlight
setblock 82 247 316 minecraft:shroomlight
fill 83 247 276 83 248 276 minecraft:spruce_planks
fill 83 247 312 85 262 312 minecraft:spruce_log
setblock 84 247 276 minecraft:dark_oak_planks
setblock 85 247 316 minecraft:spruce_planks
setblock 88 247 278 minecraft:spruce_planks
setblock 88 247 285 minecraft:spruce_planks
fill 88 247 288 88 250 290 minecraft:shroomlight
setblock 88 247 292 minecraft:spruce_planks
setblock 88 247 299 minecraft:spruce_planks
setblock 88 247 306 minecraft:spruce_planks
setblock 88 247 313 minecraft:spruce_planks
setblock 47 248 279 minecraft:light_blue_concrete
setblock 47 248 287 minecraft:light_blue_concrete
setblock 47 248 301 minecraft:light_blue_concrete
fill 47 248 302 47 248 303 minecraft:cyan_concrete
fill 47 248 314 47 251 314 minecraft:cyan_concrete
setblock 48 248 277 minecraft:spruce_planks
setblock 48 248 284 minecraft:spruce_planks
setblock 48 248 291 minecraft:spruce_planks
setblock 48 248 298 minecraft:spruce_planks
setblock 48 248 305 minecraft:spruce_planks
setblock 48 248 312 minecraft:spruce_planks
setblock 51 248 275 minecraft:light_blue_concrete
setblock 51 248 316 minecraft:spruce_planks
fill 52 248 317 52 251 317 minecraft:cyan_concrete
setblock 53 248 317 minecraft:light_blue_wool
setblock 54 248 276 minecraft:spruce_planks
fill 54 248 317 54 251 317 minecraft:cyan_concrete
setblock 55 248 275 minecraft:light_blue_wool
fill 58 248 296 58 249 296 minecraft:stripped_dark_oak_log
setblock 58 248 316 minecraft:spruce_planks
setblock 61 248 276 minecraft:spruce_planks
setblock 63 248 317 minecraft:light_blue_concrete
fill 64 248 275 65 248 275 minecraft:light_blue_concrete
setblock 64 248 306 minecraft:spruce_planks
setblock 64 248 308 minecraft:spruce_planks
setblock 64 248 310 minecraft:spruce_planks
setblock 64 248 312 minecraft:spruce_planks
setblock 64 248 314 minecraft:spruce_planks
setblock 64 248 316 minecraft:spruce_planks
setblock 65 248 307 minecraft:spruce_planks
setblock 65 248 309 minecraft:spruce_planks
setblock 65 248 311 minecraft:spruce_planks
setblock 65 248 313 minecraft:spruce_planks
setblock 65 248 315 minecraft:spruce_planks
fill 66 248 275 67 251 275 minecraft:cyan_concrete
setblock 66 248 306 minecraft:spruce_planks
setblock 66 248 308 minecraft:spruce_planks
setblock 66 248 310 minecraft:spruce_planks
setblock 66 248 312 minecraft:spruce_planks
setblock 66 248 314 minecraft:spruce_planks
fill 66 248 316 66 250 316 minecraft:spruce_planks
setblock 67 248 307 minecraft:spruce_planks
setblock 67 248 309 minecraft:spruce_planks
setblock 67 248 311 minecraft:spruce_planks
setblock 67 248 313 minecraft:spruce_planks
setblock 67 248 315 minecraft:spruce_planks
setblock 68 248 276 minecraft:spruce_planks
setblock 68 248 306 minecraft:spruce_planks
setblock 68 248 308 minecraft:spruce_planks
setblock 68 248 310 minecraft:spruce_planks
setblock 68 248 312 minecraft:spruce_planks
setblock 68 248 314 minecraft:spruce_planks
setblock 68 248 316 minecraft:spruce_planks
setblock 69 248 307 minecraft:spruce_planks
setblock 69 248 309 minecraft:spruce_planks
setblock 69 248 311 minecraft:spruce_planks
setblock 69 248 313 minecraft:spruce_planks
setblock 69 248 315 minecraft:spruce_planks
setblock 70 248 306 minecraft:spruce_planks
setblock 70 248 308 minecraft:spruce_planks
setblock 70 248 310 minecraft:spruce_planks
setblock 70 248 312 minecraft:spruce_planks
setblock 70 248 314 minecraft:spruce_planks
setblock 70 248 316 minecraft:spruce_planks
setblock 71 248 307 minecraft:spruce_planks
setblock 71 248 309 minecraft:spruce_planks
setblock 71 248 311 minecraft:spruce_planks
setblock 71 248 313 minecraft:spruce_planks
setblock 71 248 315 minecraft:spruce_planks
fill 72 248 275 72 249 275 minecraft:light_blue_concrete
setblock 72 248 306 minecraft:spruce_planks
setblock 72 248 308 minecraft:spruce_planks
setblock 72 248 310 minecraft:spruce_planks
setblock 72 248 312 minecraft:spruce_planks
setblock 72 248 314 minecraft:spruce_planks
setblock 72 248 316 minecraft:spruce_planks
setblock 72 248 317 minecraft:cyan_concrete
setblock 75 248 276 minecraft:spruce_planks
setblock 76 248 275 minecraft:white_wool
fill 76 248 277 84 248 281 minecraft:spruce_planks
setblock 76 248 312 minecraft:spruce_planks
setblock 76 248 314 minecraft:spruce_planks
fill 76 248 316 76 272 316 minecraft:spruce_planks
setblock 77 248 275 minecraft:cyan_concrete
setblock 77 248 276 minecraft:spruce_planks
setblock 77 248 313 minecraft:spruce_planks
setblock 77 248 315 minecraft:spruce_planks
setblock 78 248 275 minecraft:light_blue_concrete
setblock 78 248 312 minecraft:spruce_planks
setblock 78 248 314 minecraft:spruce_planks
setblock 78 248 316 minecraft:spruce_planks
fill 79 248 276 82 248 276 minecraft:spruce_planks
setblock 79 248 313 minecraft:spruce_planks
setblock 79 248 315 minecraft:spruce_planks
setblock 80 248 312 minecraft:spruce_planks
setblock 80 248 314 minecraft:spruce_planks
fill 80 248 316 80 250 316 minecraft:spruce_planks
setblock 81 248 275 minecraft:cyan_concrete
setblock 81 248 313 minecraft:spruce_planks
setblock 81 248 315 minecraft:spruce_planks
setblock 81 248 317 minecraft:light_blue_concrete
setblock 82 248 286 minecraft:spruce_planks
setblock 82 248 289 minecraft:spruce_planks
setblock 82 248 292 minecraft:spruce_planks
setblock 82 248 312 minecraft:spruce_planks
setblock 82 248 314 minecraft:spruce_planks
setblock 82 248 316 minecraft:spruce_planks
fill 83 248 275 83 251 275 minecraft:cyan_concrete
setblock 84 248 275 minecraft:light_blue_concrete
setblock 84 248 276 minecraft:spruce_planks
fill 84 248 317 85 248 317 minecraft:light_blue_concrete
fill 86 248 275 87 248 275 minecraft:light_blue_concrete
setblock 86 248 316 minecraft:spruce_planks
setblock 88 248 277 minecraft:spruce_planks
setblock 88 248 284 minecraft:spruce_planks
setblock 88 248 291 minecraft:spruce_planks
setblock 88 248 298 minecraft:spruce_planks
setblock 88 248 305 minecraft:spruce_planks
setblock 88 248 312 minecraft:spruce_planks
fill 89 248 275 89 249 275 minecraft:light_blue_concrete
fill 89 248 277 89 248 278 minecraft:light_blue_concrete
fill 89 248 282 89 250 282 minecraft:light_blue_concrete
fill 89 248 283 89 251 283 minecraft:cyan_concrete
setblock 89 248 296 minecraft:light_blue_wool
fill 47 249 279 47 252 279 minecraft:cyan_concrete
fill 47 249 287 47 251 287 minecraft:cyan_concrete
setblock 47 249 296 minecraft:light_blue_concrete
fill 47 249 301 47 249 302 minecraft:cyan_concrete
setblock 47 249 303 minecraft:light_blue_concrete
fill 48 249 278 48 250 278 minecraft:spruce_planks
fill 48 249 285 48 250 285 minecraft:spruce_planks
fill 48 249 292 48 250 292 minecraft:spruce_planks
fill 48 249 299 48 250 299 minecraft:spruce_planks
fill 48 249 306 48 250 306 minecraft:spruce_planks
fill 48 249 313 48 250 313 minecraft:spruce_planks
setblock 50 249 275 minecraft:light_blue_concrete
setblock 50 249 278 minecraft:light[level=15]
setblock 50 249 285 minecraft:light[level=12]
setblock 50 249 286 minecraft:light[level=15]
setblock 50 249 292 minecraft:light[level=12]
setblock 50 249 294 minecraft:light[level=15]
setblock 50 249 299 minecraft:light[level=12]
setblock 50 249 302 minecraft:light[level=15]
setblock 50 249 306 minecraft:light[level=12]
setblock 50 249 310 minecraft:light[level=15]
setblock 50 249 313 minecraft:light[level=12]
setblock 50 249 317 minecraft:light_blue_concrete
fill 51 249 275 51 251 275 minecraft:cyan_concrete
fill 52 249 276 52 249 278 minecraft:iron_bars
fill 52 249 316 52 250 316 minecraft:spruce_planks
fill 53 249 276 53 250 276 minecraft:spruce_planks
fill 53 249 317 53 251 317 minecraft:cyan_concrete
fill 55 249 275 55 251 275 minecraft:cyan_concrete
setblock 57 249 278 minecraft:light[level=12]
setblock 57 249 285 minecraft:light[level=12]
setblock 57 249 292 minecraft:light[level=12]
setblock 57 249 299 minecraft:light[level=12]
setblock 57 249 306 minecraft:light[level=12]
setblock 57 249 313 minecraft:light[level=12]
setblock 58 249 278 minecraft:light[level=15]
setblock 58 249 286 minecraft:light[level=15]
setblock 58 249 294 minecraft:light[level=15]
setblock 58 249 302 minecraft:light[level=15]
setblock 58 249 310 minecraft:light[level=15]
fill 59 249 316 59 250 316 minecraft:spruce_planks
fill 60 249 276 60 250 276 minecraft:spruce_planks
setblock 60 249 317 minecraft:light_blue_concrete
fill 63 249 317 63 251 317 minecraft:cyan_concrete
fill 64 249 275 65 251 275 minecraft:cyan_concrete
setblock 64 249 278 minecraft:light[level=12]
setblock 64 249 285 minecraft:light[level=12]
setblock 64 249 292 minecraft:light[level=12]
setblock 64 249 299 minecraft:light[level=12]
setblock 64 249 306 minecraft:light[level=12]
setblock 64 249 313 minecraft:light[level=12]
setblock 66 249 278 minecraft:light[level=15]
setblock 66 249 286 minecraft:light[level=15]
setblock 66 249 294 minecraft:light[level=15]
setblock 66 249 302 minecraft:light[level=15]
setblock 66 249 310 minecraft:light[level=15]
fill 67 249 276 67 250 276 minecraft:spruce_planks
setblock 67 249 317 minecraft:light_blue_concrete
fill 69 249 275 69 250 275 minecraft:light_blue_concrete
setblock 70 249 275 minecraft:white_wool
setblock 71 249 278 minecraft:light[level=12]
setblock 71 249 285 minecraft:light[level=12]
setblock 71 249 292 minecraft:light[level=12]
setblock 71 249 299 minecraft:light[level=12]
setblock 71 249 306 minecraft:light[level=12]
setblock 71 249 313 minecraft:light[level=12]
setblock 72 249 317 minecraft:light_blue_concrete
fill 73 249 316 73 250 316 minecraft:spruce_planks
fill 74 249 276 74 250 276 minecraft:spruce_planks
setblock 74 249 278 minecraft:light[level=15]
setblock 74 249 286 minecraft:light[level=15]
setblock 74 249 294 minecraft:light[level=15]
setblock 74 249 302 minecraft:light[level=15]
setblock 74 249 310 minecraft:light[level=15]
setblock 76 249 275 minecraft:cyan_concrete
fill 76 249 281 84 249 281 minecraft:dark_oak_planks
setblock 77 249 275 minecraft:light_blue_concrete
fill 78 249 275 78 251 275 minecraft:cyan_concrete
setblock 78 249 278 minecraft:light[level=12]
setblock 78 249 285 minecraft:light[level=12]
setblock 78 249 292 minecraft:light[level=12]
setblock 78 249 299 minecraft:light[level=12]
setblock 78 249 306 minecraft:light[level=12]
setblock 78 249 313 minecraft:light[level=12]
setblock 78 249 317 minecraft:light_blue_concrete
fill 79 249 275 81 252 275 minecraft:shroomlight
fill 81 249 276 81 250 276 minecraft:spruce_planks
fill 81 249 317 81 251 317 minecraft:cyan_concrete
setblock 82 249 278 minecraft:light[level=15]
setblock 82 249 286 minecraft:light[level=15]
setblock 82 249 294 minecraft:light[level=15]
setblock 82 249 302 minecraft:light[level=15]
setblock 82 249 310 minecraft:light[level=15]
setblock 84 249 275 minecraft:cyan_concrete
fill 84 249 317 85 251 317 minecraft:cyan_concrete
setblock 85 249 278 minecraft:light[level=12]
setblock 85 249 285 minecraft:light[level=12]
setblock 85 249 292 minecraft:light[level=12]
setblock 85 249 299 minecraft:light[level=12]
setblock 85 249 306 minecraft:light[level=12]
setblock 85 249 313 minecraft:light[level=12]
fill 86 249 275 87 251 275 minecraft:cyan_concrete
fill 87 249 316 87 250 316 minecraft:spruce_planks
fill 88 249 276 88 250 276 minecraft:spruce_planks
fill 88 249 283 88 250 283 minecraft:spruce_planks
fill 88 249 297 88 250 297 minecraft:spruce_planks
fill 88 249 304 88 250 304 minecraft:spruce_planks
fill 88 249 311 88 250 311 minecraft:spruce_planks
fill 89 249 277 89 251 278 minecraft:cyan_concrete
setblock 89 249 285 minecraft:light_blue_concrete
setblock 89 249 288 minecraft:light_blue_concrete
setblock 89 249 296 minecraft:light_blue_concrete
setblock 89 249 304 minecraft:light_blue_concrete
setblock 89 249 307 minecraft:light_blue_concrete
setblock 47 250 276 minecraft:light_blue_concrete
setblock 47 250 284 minecraft:light_blue_concrete
setblock 47 250 291 minecraft:light_blue_wool
fill 47 250 296 47 251 296 minecraft:cyan_concrete
setblock 47 250 299 minecraft:light_blue_concrete
setblock 47 250 301 minecraft:light_blue_concrete
fill 47 250 302 47 251 303 minecraft:cyan_concrete
fill 47 250 307 47 251 307 minecraft:cyan_concrete
setblock 47 250 308 minecraft:light_blue_concrete
fill 47 250 309 47 251 310 minecraft:cyan_concrete
setblock 47 250 312 minecraft:light_blue_concrete
setblock 47 250 315 minecraft:light_blue_concrete
fill 47 250 317 48 250 317 minecraft:light_blue_concrete
fill 48 250 276 48 250 277 minecraft:spruce_planks
fill 48 250 279 48 250 280 minecraft:spruce_planks
fill 48 250 282 48 250 284 minecraft:spruce_planks
fill 48 250 286 48 250 287 minecraft:spruce_planks
fill 48 250 289 48 250 291 minecraft:spruce_planks
fill 48 250 293 48 250 294 minecraft:spruce_planks
fill 48 250 296 48 250 298 minecraft:spruce_planks
fill 48 250 300 48 250 301 minecraft:spruce_planks
fill 48 250 303 48 250 305 minecraft:spruce_planks
fill 48 250 307 48 250 308 minecraft:spruce_planks
fill 48 250 310 48 250 312 minecraft:spruce_planks
fill 48 250 314 48 250 315 minecraft:spruce_planks
setblock 49 250 276 minecraft:spruce_planks
fill 49 250 316 51 250 316 minecraft:spruce_planks
fill 50 250 275 50 251 275 minecraft:cyan_concrete
fill 50 250 317 50 251 317 minecraft:cyan_concrete
fill 51 250 276 52 250 276 minecraft:spruce_planks
fill 52 250 277 52 250 278 minecraft:iron_bars
fill 53 250 316 54 250 316 minecraft:spruce_planks
fill 54 250 276 56 250 276 minecraft:spruce_planks
fill 56 250 316 58 250 316 minecraft:spruce_planks
fill 58 250 276 59 250 276 minecraft:spruce_planks
setblock 58 250 317 minecraft:light_blue_concrete
fill 60 250 316 61 250 316 minecraft:spruce_planks
fill 60 250 317 60 251 317 minecraft:cyan_concrete
fill 61 250 276 63 250 276 minecraft:spruce_planks
setblock 61 250 317 minecraft:light_blue_concrete
setblock 62 250 275 minecraft:light_blue_concrete
fill 62 250 317 62 251 317 minecraft:cyan_concrete
fill 63 250 316 65 250 316 minecraft:spruce_planks
fill 65 250 276 66 250 276 minecraft:spruce_planks
setblock 66 250 317 minecraft:light_blue_concrete
fill 67 250 316 68 250 316 minecraft:spruce_planks
fill 67 250 317 67 251 317 minecraft:cyan_concrete
setblock 68 250 275 minecraft:light_blue_wool
fill 68 250 276 70 250 276 minecraft:spruce_planks
setblock 69 250 317 minecraft:light_blue_concrete
fill 70 250 275 70 251 275 minecraft:cyan_concrete
fill 70 250 316 72 250 316 minecraft:spruce_planks
fill 72 250 275 72 251 275 minecraft:cyan_concrete
fill 72 250 276 73 250 276 minecraft:spruce_planks
fill 72 250 317 72 251 317 minecraft:cyan_concrete
fill 74 250 316 75 250 316 minecraft:spruce_planks
fill 75 250 276 77 250 276 minecraft:spruce_planks
setblock 76 250 275 minecraft:light_blue_concrete
setblock 76 250 281 minecraft:spruce_planks
fill 77 250 275 77 251 275 minecraft:cyan_concrete
fill 77 250 316 79 250 316 minecraft:spruce_planks
fill 78 250 317 78 251 317 minecraft:cyan_concrete
fill 79 250 276 80 250 276 minecraft:spruce_planks
setblock 80 250 281 minecraft:spruce_planks
fill 81 250 316 82 250 316 minecraft:spruce_planks
fill 82 250 276 84 250 276 minecraft:spruce_planks
setblock 84 250 275 minecraft:light_blue_concrete
setblock 84 250 281 minecraft:spruce_planks
fill 84 250 316 86 250 316 minecraft:spruce_planks
fill 86 250 276 87 250 276 minecraft:spruce_planks
fill 88 250 277 88 250 279 minecraft:spruce_planks
fill 88 250 281 88 250 282 minecraft:spruce_planks
fill 88 250 284 88 250 286 minecraft:spruce_planks
fill 88 250 291 88 250 293 minecraft:spruce_planks
fill 88 250 295 88 250 296 minecraft:spruce_planks
fill 88 250 298 88 250 300 minecraft:spruce_planks
fill 88 250 302 88 250 303 minecraft:spruce_planks
fill 88 250 305 88 250 307 minecraft:spruce_planks
fill 88 250 309 88 250 310 minecraft:spruce_planks
fill 88 250 312 88 250 314 minecraft:spruce_planks
setblock 88 250 316 minecraft:spruce_planks
fill 89 250 275 89 251 275 minecraft:cyan_concrete
setblock 89 250 284 minecraft:light_blue_concrete
fill 89 250 285 89 251 285 minecraft:cyan_concrete
fill 89 250 288 89 251 288 minecraft:cyan_concrete
fill 89 250 296 89 251 296 minecraft:cyan_concrete
fill 89 250 304 89 251 304 minecraft:cyan_concrete
fill 89 250 307 89 252 307 minecraft:cyan_concrete
fill 89 250 309 89 252 309 minecraft:cyan_concrete
setblock 89 250 310 minecraft:light_blue_concrete
setblock 89 250 317 minecraft:light_blue_concrete
setblock 47 251 276 minecraft:cyan_concrete
setblock 47 251 284 minecraft:cyan_concrete
setblock 47 251 291 minecraft:cyan_concrete
setblock 47 251 299 minecraft:cyan_concrete
setblock 47 251 301 minecraft:cyan_concrete
setblock 47 251 308 minecraft:cyan_concrete
setblock 47 251 312 minecraft:cyan_concrete
setblock 47 251 315 minecraft:cyan_concrete
fill 47 251 317 48 251 317 minecraft:cyan_concrete
setblock 48 251 275 minecraft:light_blue_wool
setblock 48 251 280 minecraft:spruce_planks
setblock 48 251 287 minecraft:spruce_planks
setblock 48 251 294 minecraft:spruce_planks
setblock 48 251 301 minecraft:spruce_planks
setblock 48 251 308 minecraft:spruce_planks
setblock 48 251 315 minecraft:spruce_planks
fill 49 251 288 49 259 288 minecraft:white_wool
setblock 51 251 276 minecraft:spruce_planks
setblock 54 251 316 minecraft:spruce_planks
setblock 58 251 276 minecraft:spruce_planks
setblock 58 251 317 minecraft:cyan_concrete
setblock 61 251 316 minecraft:spruce_planks
setblock 61 251 317 minecraft:cyan_concrete
fill 62 251 275 62 252 275 minecraft:cyan_concrete
setblock 65 251 276 minecraft:spruce_planks
setblock 66 251 317 minecraft:cyan_concrete
fill 68 251 275 69 251 275 minecraft:cyan_concrete
setblock 68 251 316 minecraft:spruce_planks
setblock 69 251 317 minecraft:cyan_concrete
setblock 72 251 276 minecraft:spruce_planks
setblock 75 251 316 minecraft:spruce_planks
setblock 76 251 275 minecraft:cyan_concrete
setblock 79 251 276 minecraft:spruce_planks
setblock 82 251 316 minecraft:spruce_planks
setblock 84 251 275 minecraft:cyan_concrete
setblock 86 251 276 minecraft:spruce_planks
setblock 88 251 281 minecraft:spruce_planks
setblock 88 251 288 minecraft:spruce_planks
setblock 88 251 295 minecraft:spruce_planks
setblock 88 251 302 minecraft:spruce_planks
setblock 88 251 309 minecraft:spruce_planks
setblock 89 251 282 minecraft:cyan_concrete
setblock 89 251 284 minecraft:cyan_concrete
setblock 89 251 305 minecraft:white_wool
setblock 89 251 310 minecraft:cyan_concrete
setblock 89 251 317 minecraft:cyan_concrete
fill 47 252 275 47 252 277 minecraft:light_blue_concrete
setblock 47 252 278 minecraft:white_wool
fill 47 252 280 47 255 282 minecraft:light_blue_concrete
fill 47 252 284 47 259 285 minecraft:light_blue_concrete
fill 47 252 287 47 268 291 minecraft:light_blue_concrete
fill 47 252 293 47 253 315 minecraft:light_blue_concrete
fill 47 252 317 47 308 317 minecraft:light_blue_concrete
setblock 48 252 275 minecraft:cyan_concrete
setblock 48 252 317 minecraft:cyan_concrete
fill 49 252 275 56 252 275 minecraft:light_blue_concrete
fill 49 252 286 49 259 287 minecraft:white_wool
fill 49 252 289 49 259 290 minecraft:white_wool
fill 49 252 317 58 252 317 minecraft:light_blue_concrete
setblock 57 252 275 minecraft:cyan_concrete
fill 58 252 275 61 278 275 minecraft:light_blue_concrete
fill 60 252 317 75 252 317 minecraft:light_blue_concrete
fill 63 252 275 63 306 275 minecraft:light_blue_concrete
setblock 64 252 275 minecraft:cyan_concrete
fill 65 252 275 78 252 275 minecraft:light_blue_concrete
setblock 76 252 317 minecraft:white_wool
fill 77 252 317 82 252 317 minecraft:light_blue_concrete
fill 82 252 275 89 252 275 minecraft:light_blue_concrete
setblock 84 252 317 minecraft:cyan_concrete
fill 85 252 317 89 252 317 minecraft:light_blue_concrete
fill 89 252 276 89 252 304 minecraft:light_blue_concrete
setblock 89 252 305 minecraft:cyan_concrete
fill 89 252 308 89 271 308 minecraft:light_blue_concrete
fill 89 252 310 89 254 312 minecraft:light_blue_concrete
fill 89 252 315 89 289 316 minecraft:light_blue_concrete
fill 47 253 275 54 259 275 minecraft:light_blue_concrete
setblock 47 253 276 minecraft:cyan_concrete
fill 47 253 277 47 278 278 minecraft:light_blue_concrete
setblock 47 253 279 minecraft:white_wool
fill 47 253 283 47 308 283 minecraft:light_blue_concrete
fill 47 253 286 47 308 286 minecraft:light_blue_concrete
fill 47 253 292 47 308 292 minecraft:light_blue_concrete
fill 47 253 316 47 308 316 minecraft:light_blue_concrete
setblock 48 253 282 minecraft:spruce_planks
setblock 48 253 289 minecraft:spruce_planks
setblock 48 253 296 minecraft:spruce_planks
setblock 48 253 303 minecraft:spruce_planks
setblock 48 253 310 minecraft:spruce_planks
fill 48 253 317 48 308 317 minecraft:light_blue_concrete
setblock 49 253 276 minecraft:spruce_planks
setblock 49 253 316 minecraft:spruce_planks
setblock 49 253 317 minecraft:white_wool
fill 50 253 317 52 255 317 minecraft:light_blue_concrete
setblock 53 253 317 minecraft:cyan_concrete
fill 54 253 317 60 254 317 minecraft:light_blue_concrete
setblock 55 253 275 minecraft:cyan_concrete
fill 56 253 275 57 253 275 minecraft:light_blue_concrete
setblock 56 253 276 minecraft:spruce_planks
setblock 56 253 316 minecraft:spruce_planks
fill 59 253 314 59 261 314 minecraft:white_wool
setblock 61 253 317 minecraft:light_blue_wool
fill 62 253 275 62 308 275 minecraft:light_blue_concrete
setblock 62 253 317 minecraft:cyan_concrete
setblock 63 253 276 minecraft:spruce_planks
setblock 63 253 316 minecraft:spruce_planks
fill 63 253 317 63 296 317 minecraft:light_blue_concrete
fill 64 253 275 72 276 275 minecraft:light_blue_concrete
setblock 64 253 317 minecraft:cyan_concrete
fill 65 253 317 70 253 317 minecraft:light_blue_concrete
setblock 70 253 276 minecraft:spruce_planks
setblock 70 253 316 minecraft:spruce_planks
setblock 71 253 317 minecraft:cyan_concrete
fill 72 253 317 76 263 317 minecraft:light_blue_concrete
fill 73 253 275 73 254 275 minecraft:cyan_concrete
fill 74 253 275 88 253 275 minecraft:light_blue_concrete
setblock 77 253 276 minecraft:spruce_planks
setblock 77 253 316 minecraft:spruce_planks
fill 77 253 317 78 253 317 minecraft:cyan_concrete
fill 79 253 317 79 289 317 minecraft:light_blue_concrete
setblock 80 253 317 minecraft:cyan_concrete
fill 81 253 317 87 253 317 minecraft:light_blue_concrete
setblock 84 253 276 minecraft:spruce_planks
setblock 84 253 316 minecraft:spruce_planks
setblock 88 253 279 minecraft:spruce_planks
setblock 88 253 286 minecraft:spruce_planks
setblock 88 253 293 minecraft:spruce_planks
setblock 88 253 300 minecraft:spruce_planks
setblock 88 253 307 minecraft:spruce_planks
setblock 88 253 314 minecraft:spruce_planks
fill 88 253 317 88 254 317 minecraft:cyan_concrete
fill 89 253 275 89 253 277 minecraft:cyan_concrete
fill 89 253 278 89 272 280 minecraft:light_blue_concrete
fill 89 253 281 89 253 282 minecraft:cyan_concrete
fill 89 253 283 89 253 293 minecraft:light_blue_concrete
setblock 89 253 294 minecraft:cyan_concrete
fill 89 253 295 89 253 307 minecraft:light_blue_concrete
fill 89 253 309 89 301 309 minecraft:light_blue_concrete
fill 89 253 313 89 288 313 minecraft:light_blue_concrete
setblock 89 253 314 minecraft:white_wool
setblock 89 253 317 minecraft:light_blue_concrete
fill 47 254 276 47 308 276 minecraft:light_blue_concrete
fill 47 254 279 47 301 279 minecraft:light_blue_concrete
fill 47 254 293 47 255 293 minecraft:light_blue_concrete
fill 47 254 294 47 254 295 minecraft:cyan_concrete
fill 47 254 296 47 258 308 minecraft:light_blue_concrete
setblock 47 254 309 minecraft:cyan_concrete
fill 47 254 310 47 257 315 minecraft:light_blue_concrete
setblock 48 254 276 minecraft:spruce_planks
setblock 48 254 283 minecraft:spruce_planks
setblock 48 254 290 minecraft:spruce_planks
setblock 48 254 297 minecraft:spruce_planks
setblock 48 254 304 minecraft:spruce_planks
setblock 48 254 311 minecraft:spruce_planks
setblock 49 254 317 minecraft:cyan_concrete
setblock 50 254 316 minecraft:spruce_planks
fill 53 254 317 53 259 317 minecraft:light_blue_concrete
fill 55 254 275 55 289 275 minecraft:light_blue_concrete
setblock 55 254 276 minecraft:spruce_planks
setblock 56 254 275 minecraft:cyan_concrete
fill 57 254 275 57 308 275 minecraft:light_blue_concrete
fill 57 254 314 58 261 314 minecraft:white_wool
setblock 57 254 316 minecraft:spruce_planks
fill 60 254 314 61 261 314 minecraft:white_wool
fill 61 254 317 62 257 317 minecraft:light_blue_concrete
setblock 62 254 276 minecraft:spruce_planks
setblock 64 254 316 minecraft:spruce_planks
fill 64 254 317 67 276 317 minecraft:light_blue_concrete
setblock 68 254 317 minecraft:cyan_concrete
setblock 69 254 276 minecraft:spruce_planks
fill 69 254 317 71 275 317 minecraft:light_blue_concrete
setblock 71 254 316 minecraft:spruce_planks
fill 74 254 275 84 259 275 minecraft:light_blue_concrete
setblock 76 254 276 minecraft:spruce_planks
fill 77 254 317 78 269 317 minecraft:light_blue_concrete
setblock 78 254 316 minecraft:spruce_planks
fill 80 254 317 85 265 317 minecraft:light_blue_concrete
setblock 83 254 276 minecraft:spruce_planks
setblock 85 254 275 minecraft:cyan_concrete
setblock 85 254 316 minecraft:spruce_planks
fill 86 254 275 89 268 275 minecraft:light_blue_concrete
setblock 86 254 317 minecraft:cyan_concrete
fill 87 254 317 87 308 317 minecraft:light_blue_concrete
setblock 88 254 278 minecraft:spruce_planks
setblock 88 254 285 minecraft:spruce_planks
setblock 88 254 292 minecraft:spruce_planks
setblock 88 254 299 minecraft:spruce_planks
setblock 88 254 306 minecraft:spruce_planks
setblock 88 254 313 minecraft:spruce_planks
fill 89 254 276 89 308 276 minecraft:light_blue_concrete
setblock 89 254 277 minecraft:white_wool
fill 89 254 281 89 261 282 minecraft:light_blue_concrete
setblock 89 254 283 minecraft:cyan_concrete
fill 89 254 284 89 259 288 minecraft:light_blue_concrete
setblock 89 254 289 minecraft:cyan_concrete
fill 89 254 290 89 263 296 minecraft:light_blue_concrete
setblock 89 254 297 minecraft:cyan_concrete
fill 89 254 298 89 270 306 minecraft:light_blue_concrete
setblock 89 254 307 minecraft:cyan_concrete
fill 89 254 314 89 308 314 minecraft:light_blue_concrete
setblock 89 254 317 minecraft:cyan_concrete
fill 47 255 294 47 277 295 minecraft:light_blue_concrete
fill 47 255 309 47 256 309 minecraft:light_blue_concrete
setblock 48 255 277 minecraft:spruce_planks
setblock 48 255 284 minecraft:spruce_planks
setblock 48 255 291 minecraft:spruce_planks
setblock 48 255 298 minecraft:spruce_planks
setblock 48 255 305 minecraft:spruce_planks
setblock 48 255 312 minecraft:spruce_planks
fill 49 255 317 49 301 317 minecraft:light_blue_concrete
setblock 50 255 278 minecraft:light[level=12]
setblock 50 255 285 minecraft:light[level=12]
setblock 50 255 292 minecraft:light[level=12]
setblock 50 255 299 minecraft:light[level=12]
setblock 50 255 306 minecraft:light[level=12]
setblock 50 255 313 minecraft:light[level=12]
setblock 51 255 316 minecraft:spruce_planks
setblock 54 255 276 minecraft:spruce_planks
fill 54 255 317 56 259 317 minecraft:light_blue_concrete
fill 56 255 275 56 291 275 minecraft:light_blue_concrete
setblock 57 255 278 minecraft:light[level=12]
setblock 57 255 285 minecraft:light[level=12]
setblock 57 255 292 minecraft:light[level=12]
setblock 57 255 299 minecraft:light[level=12]
setblock 57 255 306 minecraft:light[level=12]
setblock 57 255 313 minecraft:light[level=12]
setblock 57 255 317 minecraft:white_wool
setblock 58 255 316 minecraft:spruce_planks
fill 58 255 317 60 308 317 minecraft:light_blue_concrete
setblock 61 255 276 minecraft:spruce_planks
setblock 64 255 278 minecraft:light[level=12]
setblock 64 255 285 minecraft:light[level=12]
setblock 64 255 292 minecraft:light[level=12]
setblock 64 255 299 minecraft:light[level=12]
setblock 64 255 306 minecraft:light[level=12]
setblock 64 255 313 minecraft:light[level=12]
setblock 65 255 316 minecraft:spruce_planks
setblock 68 255 276 minecraft:spruce_planks
fill 68 255 317 68 285 317 minecraft:light_blue_concrete
setblock 71 255 278 minecraft:light[level=12]
setblock 71 255 285 minecraft:light[level=12]
setblock 71 255 292 minecraft:light[level=12]
setblock 71 255 299 minecraft:light[level=12]
setblock 71 255 306 minecraft:light[level=12]
setblock 71 255 313 minecraft:light[level=12]
setblock 72 255 316 minecraft:spruce_planks
fill 73 255 275 73 289 275 minecraft:light_blue_concrete
setblock 75 255 276 minecraft:spruce_planks
setblock 78 255 278 minecraft:light[level=12]
setblock 78 255 285 minecraft:light[level=12]
setblock 78 255 292 minecraft:light[level=12]
setblock 78 255 299 minecraft:light[level=12]
setblock 78 255 306 minecraft:light[level=12]
setblock 78 255 313 minecraft:light[level=12]
setblock 79 255 316 minecraft:spruce_planks
setblock 82 255 276 minecraft:spruce_planks
fill 85 255 275 85 308 275 minecraft:light_blue_concrete
setblock 85 255 278 minecraft:light[level=12]
setblock 85 255 285 minecraft:light[level=12]
setblock 85 255 292 minecraft:light[level=12]
setblock 85 255 299 minecraft:light[level=12]
setblock 85 255 306 minecraft:light[level=12]
setblock 85 255 313 minecraft:light[level=12]
setblock 86 255 316 minecraft:spruce_planks
fill 86 255 317 86 276 317 minecraft:light_blue_concrete
setblock 88 255 277 minecraft:spruce_planks
setblock 88 255 284 minecraft:spruce_planks
setblock 88 255 291 minecraft:spruce_planks
setblock 88 255 298 minecraft:spruce_planks
setblock 88 255 305 minecraft:spruce_planks
setblock 88 255 312 minecraft:spruce_planks
fill 88 255 317 89 308 317 minecraft:light_blue_concrete
fill 89 255 277 89 278 277 minecraft:light_blue_concrete
fill 89 255 283 89 291 283 minecraft:light_blue_concrete
fill 89 255 289 89 284 289 minecraft:light_blue_concrete
fill 89 255 297 89 306 297 minecraft:light_blue_concrete
fill 89 255 307 89 291 307 minecraft:light_blue_concrete
setblock 89 255 310 minecraft:white_wool
fill 89 255 311 89 308 312 minecraft:light_blue_concrete
fill 47 256 280 47 275 281 minecraft:light_blue_concrete
setblock 47 256 282 minecraft:white_wool
setblock 47 256 293 minecraft:white_wool
setblock 48 256 278 minecraft:spruce_planks
setblock 48 256 285 minecraft:spruce_planks
setblock 48 256 292 minecraft:spruce_planks
setblock 48 256 299 minecraft:spruce_planks
setblock 48 256 306 minecraft:spruce_planks
setblock 48 256 313 minecraft:spruce_planks
fill 50 256 317 51 264 317 minecraft:light_blue_concrete
setblock 52 256 316 minecraft:spruce_planks
setblock 52 256 317 minecraft:white_wool
setblock 53 256 276 minecraft:spruce_planks
fill 57 256 317 57 308 317 minecraft:light_blue_concrete
setblock 59 256 316 minecraft:spruce_planks
setblock 60 256 276 minecraft:spruce_planks
setblock 66 256 316 minecraft:spruce_planks
setblock 67 256 276 minecraft:spruce_planks
setblock 73 256 316 minecraft:spruce_planks
setblock 74 256 276 minecraft:spruce_planks
setblock 80 256 316 minecraft:spruce_planks
setblock 81 256 276 minecraft:spruce_planks
schedule function dropper:buildpart/61_4 1t
