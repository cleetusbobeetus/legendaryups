setblock 305 67 310 minecraft:pearlescent_froglight
setblock 305 67 312 minecraft:pearlescent_froglight
setblock 305 67 314 minecraft:pearlescent_froglight
setblock 305 67 316 minecraft:pearlescent_froglight
setblock 306 67 309 minecraft:pearlescent_froglight
setblock 306 67 311 minecraft:pearlescent_froglight
setblock 306 67 313 minecraft:pearlescent_froglight
setblock 306 67 315 minecraft:pearlescent_froglight
fill 306 67 317 309 67 317 minecraft:pearlescent_froglight
setblock 307 67 310 minecraft:pearlescent_froglight
setblock 307 67 312 minecraft:pearlescent_froglight
setblock 307 67 314 minecraft:pearlescent_froglight
setblock 307 67 316 minecraft:pearlescent_froglight
fill 313 67 276 315 68 276 minecraft:iron_block
fill 315 67 275 318 67 275 minecraft:pearlescent_froglight
fill 316 67 317 319 67 317 minecraft:pearlescent_froglight
fill 324 67 276 324 67 279 minecraft:pearlescent_froglight
fill 324 67 286 324 67 289 minecraft:pearlescent_froglight
fill 324 67 296 324 67 299 minecraft:pearlescent_froglight
fill 324 67 306 324 67 309 minecraft:pearlescent_froglight
setblock 324 67 316 minecraft:pearlescent_froglight
fill 282 68 281 282 75 284 minecraft:iron_block
fill 282 68 291 282 69 294 minecraft:iron_block
fill 282 68 301 282 75 304 minecraft:iron_block
fill 282 68 311 282 75 314 minecraft:iron_block
fill 283 68 276 283 69 276 minecraft:iron_block
fill 283 68 278 283 69 278 minecraft:iron_block
fill 283 68 280 283 69 280 minecraft:iron_block
fill 283 68 282 283 69 282 minecraft:iron_block
fill 283 68 284 283 69 284 minecraft:iron_block
fill 283 68 286 283 69 286 minecraft:iron_block
fill 283 68 288 283 69 288 minecraft:iron_block
fill 284 68 277 284 69 277 minecraft:iron_block
fill 284 68 279 284 69 279 minecraft:iron_block
fill 284 68 281 284 69 281 minecraft:iron_block
fill 284 68 283 284 69 283 minecraft:iron_block
fill 284 68 285 284 69 285 minecraft:iron_block
fill 284 68 287 284 69 287 minecraft:iron_block
fill 285 68 275 285 69 276 minecraft:iron_block
fill 285 68 278 285 69 278 minecraft:iron_block
fill 285 68 280 285 69 280 minecraft:iron_block
fill 285 68 282 285 69 282 minecraft:iron_block
fill 285 68 284 285 69 284 minecraft:iron_block
fill 285 68 286 285 69 286 minecraft:iron_block
fill 285 68 288 285 69 288 minecraft:iron_block
fill 286 68 275 288 68 275 minecraft:iron_block
fill 286 68 277 286 69 277 minecraft:iron_block
fill 286 68 279 286 69 279 minecraft:iron_block
fill 286 68 281 286 69 281 minecraft:iron_block
fill 286 68 283 286 69 283 minecraft:iron_block
fill 286 68 285 286 69 285 minecraft:iron_block
fill 286 68 287 286 69 287 minecraft:iron_block
fill 286 68 317 289 75 317 minecraft:iron_block
fill 287 68 276 287 69 276 minecraft:iron_block
fill 287 68 278 287 69 278 minecraft:iron_block
fill 287 68 280 287 69 280 minecraft:iron_block
fill 287 68 282 287 69 282 minecraft:iron_block
fill 287 68 284 287 69 284 minecraft:iron_block
fill 287 68 286 287 69 286 minecraft:iron_block
fill 287 68 288 287 69 288 minecraft:iron_block
fill 288 68 277 288 69 277 minecraft:iron_block
fill 288 68 279 288 69 279 minecraft:iron_block
fill 288 68 281 288 69 281 minecraft:iron_block
fill 288 68 283 288 69 283 minecraft:iron_block
fill 288 68 285 288 69 285 minecraft:iron_block
fill 288 68 287 288 69 287 minecraft:iron_block
setblock 289 68 278 minecraft:gray_concrete
setblock 289 68 282 minecraft:gray_concrete
fill 290 68 279 290 68 281 minecraft:gray_concrete
fill 295 68 275 298 75 275 minecraft:iron_block
fill 296 68 317 299 75 317 minecraft:iron_block
fill 298 68 278 298 68 280 minecraft:iron_block
fill 299 68 278 300 68 278 minecraft:iron_block
fill 299 68 280 300 68 280 minecraft:iron_block
fill 299 68 310 299 69 310 minecraft:iron_block
fill 299 68 312 299 69 312 minecraft:iron_block
fill 299 68 314 299 69 314 minecraft:iron_block
fill 299 68 316 299 69 316 minecraft:iron_block
setblock 300 68 279 minecraft:iron_block
fill 300 68 309 300 69 309 minecraft:iron_block
fill 300 68 311 300 69 311 minecraft:iron_block
fill 300 68 313 300 69 313 minecraft:iron_block
fill 300 68 315 300 69 315 minecraft:iron_block
fill 301 68 310 301 69 310 minecraft:iron_block
fill 301 68 312 301 69 312 minecraft:iron_block
fill 301 68 314 301 69 314 minecraft:iron_block
fill 301 68 316 301 69 316 minecraft:iron_block
fill 302 68 309 302 69 309 minecraft:iron_block
fill 302 68 311 302 69 311 minecraft:iron_block
fill 302 68 313 302 69 313 minecraft:iron_block
fill 302 68 315 302 69 315 minecraft:iron_block
fill 303 68 310 303 69 310 minecraft:iron_block
fill 303 68 312 303 69 312 minecraft:iron_block
fill 303 68 314 303 69 314 minecraft:iron_block
fill 303 68 316 303 69 316 minecraft:iron_block
fill 304 68 309 304 69 309 minecraft:iron_block
fill 304 68 311 304 69 311 minecraft:iron_block
fill 304 68 313 304 69 313 minecraft:iron_block
fill 304 68 315 304 69 315 minecraft:iron_block
fill 305 68 275 308 74 275 minecraft:iron_block
fill 305 68 310 305 69 310 minecraft:iron_block
fill 305 68 312 305 69 312 minecraft:iron_block
fill 305 68 314 305 69 314 minecraft:iron_block
fill 305 68 316 305 69 316 minecraft:iron_block
fill 306 68 309 306 69 309 minecraft:iron_block
fill 306 68 311 306 69 311 minecraft:iron_block
fill 306 68 313 306 69 313 minecraft:iron_block
fill 306 68 315 306 69 315 minecraft:iron_block
fill 306 68 317 309 73 317 minecraft:iron_block
fill 307 68 310 307 69 310 minecraft:iron_block
fill 307 68 312 307 69 312 minecraft:iron_block
fill 307 68 314 307 69 314 minecraft:iron_block
fill 307 68 316 307 69 316 minecraft:iron_block
setblock 314 68 281 minecraft:pearlescent_froglight
fill 315 68 275 318 75 275 minecraft:iron_block
fill 316 68 295 320 69 299 minecraft:gray_concrete
fill 316 68 317 319 75 317 minecraft:iron_block
fill 321 68 297 322 68 297 minecraft:gray_concrete
fill 324 68 276 324 75 279 minecraft:iron_block
fill 324 68 286 324 75 289 minecraft:iron_block
fill 324 68 295 324 69 299 minecraft:iron_block
fill 324 68 306 324 75 309 minecraft:iron_block
fill 324 68 316 324 75 316 minecraft:iron_block
setblock 286 69 275 minecraft:sea_lantern
fill 287 69 275 288 75 275 minecraft:iron_block
fill 282 70 291 282 75 291 minecraft:iron_block
setblock 282 70 292 minecraft:redstone_block
fill 282 70 293 282 75 294 minecraft:iron_block
setblock 283 70 276 minecraft:pearlescent_froglight
setblock 283 70 278 minecraft:pearlescent_froglight
setblock 283 70 280 minecraft:pearlescent_froglight
setblock 283 70 282 minecraft:pearlescent_froglight
setblock 283 70 284 minecraft:pearlescent_froglight
setblock 283 70 286 minecraft:pearlescent_froglight
setblock 283 70 288 minecraft:pearlescent_froglight
setblock 284 70 277 minecraft:pearlescent_froglight
setblock 284 70 279 minecraft:pearlescent_froglight
setblock 284 70 281 minecraft:pearlescent_froglight
setblock 284 70 283 minecraft:pearlescent_froglight
setblock 284 70 285 minecraft:pearlescent_froglight
setblock 284 70 287 minecraft:pearlescent_froglight
fill 285 70 275 286 74 275 minecraft:iron_block
setblock 285 70 276 minecraft:pearlescent_froglight
setblock 285 70 278 minecraft:pearlescent_froglight
setblock 285 70 280 minecraft:pearlescent_froglight
setblock 285 70 282 minecraft:pearlescent_froglight
setblock 285 70 284 minecraft:pearlescent_froglight
setblock 285 70 286 minecraft:pearlescent_froglight
setblock 285 70 288 minecraft:pearlescent_froglight
setblock 286 70 277 minecraft:pearlescent_froglight
setblock 286 70 279 minecraft:pearlescent_froglight
setblock 286 70 281 minecraft:pearlescent_froglight
setblock 286 70 283 minecraft:pearlescent_froglight
setblock 286 70 285 minecraft:pearlescent_froglight
setblock 286 70 287 minecraft:pearlescent_froglight
setblock 287 70 276 minecraft:pearlescent_froglight
setblock 287 70 278 minecraft:pearlescent_froglight
setblock 287 70 280 minecraft:pearlescent_froglight
setblock 287 70 282 minecraft:pearlescent_froglight
setblock 287 70 284 minecraft:pearlescent_froglight
setblock 287 70 286 minecraft:pearlescent_froglight
setblock 287 70 288 minecraft:pearlescent_froglight
setblock 288 70 277 minecraft:pearlescent_froglight
setblock 288 70 279 minecraft:pearlescent_froglight
setblock 288 70 281 minecraft:pearlescent_froglight
setblock 288 70 283 minecraft:pearlescent_froglight
setblock 288 70 285 minecraft:pearlescent_froglight
setblock 288 70 287 minecraft:pearlescent_froglight
setblock 299 70 310 minecraft:pearlescent_froglight
setblock 299 70 312 minecraft:pearlescent_froglight
setblock 299 70 314 minecraft:pearlescent_froglight
setblock 299 70 316 minecraft:pearlescent_froglight
setblock 300 70 309 minecraft:pearlescent_froglight
setblock 300 70 311 minecraft:pearlescent_froglight
setblock 300 70 313 minecraft:pearlescent_froglight
setblock 300 70 315 minecraft:pearlescent_froglight
setblock 301 70 310 minecraft:pearlescent_froglight
setblock 301 70 312 minecraft:pearlescent_froglight
setblock 301 70 314 minecraft:pearlescent_froglight
setblock 301 70 316 minecraft:pearlescent_froglight
setblock 302 70 309 minecraft:pearlescent_froglight
setblock 302 70 311 minecraft:pearlescent_froglight
setblock 302 70 313 minecraft:pearlescent_froglight
setblock 302 70 315 minecraft:pearlescent_froglight
setblock 303 70 310 minecraft:pearlescent_froglight
setblock 303 70 312 minecraft:pearlescent_froglight
setblock 303 70 314 minecraft:pearlescent_froglight
setblock 303 70 316 minecraft:pearlescent_froglight
setblock 304 70 309 minecraft:pearlescent_froglight
setblock 304 70 311 minecraft:pearlescent_froglight
setblock 304 70 313 minecraft:pearlescent_froglight
setblock 304 70 315 minecraft:pearlescent_froglight
setblock 305 70 310 minecraft:pearlescent_froglight
setblock 305 70 312 minecraft:pearlescent_froglight
setblock 305 70 314 minecraft:pearlescent_froglight
setblock 305 70 316 minecraft:pearlescent_froglight
setblock 306 70 309 minecraft:pearlescent_froglight
setblock 306 70 311 minecraft:pearlescent_froglight
setblock 306 70 313 minecraft:pearlescent_froglight
setblock 306 70 315 minecraft:pearlescent_froglight
setblock 307 70 310 minecraft:pearlescent_froglight
setblock 307 70 312 minecraft:pearlescent_froglight
setblock 307 70 314 minecraft:pearlescent_froglight
setblock 307 70 316 minecraft:pearlescent_froglight
fill 324 70 295 324 80 295 minecraft:iron_block
setblock 324 70 296 minecraft:sea_lantern
fill 324 70 297 324 75 299 minecraft:iron_block
fill 282 71 292 282 75 292 minecraft:iron_block
fill 283 71 276 283 72 276 minecraft:iron_block
fill 283 71 278 283 72 278 minecraft:iron_block
fill 283 71 280 283 72 280 minecraft:iron_block
fill 283 71 282 283 72 282 minecraft:iron_block
fill 283 71 284 283 72 284 minecraft:iron_block
fill 283 71 286 283 72 286 minecraft:iron_block
fill 283 71 288 283 72 288 minecraft:iron_block
fill 284 71 277 284 72 277 minecraft:iron_block
fill 284 71 279 284 72 279 minecraft:iron_block
fill 284 71 281 284 72 281 minecraft:iron_block
fill 284 71 283 284 72 283 minecraft:iron_block
fill 284 71 285 284 72 285 minecraft:iron_block
fill 284 71 287 284 72 287 minecraft:iron_block
fill 285 71 276 285 72 276 minecraft:iron_block
fill 285 71 278 285 72 278 minecraft:iron_block
fill 285 71 280 285 72 280 minecraft:iron_block
fill 285 71 282 285 72 282 minecraft:iron_block
fill 285 71 284 285 72 284 minecraft:iron_block
fill 285 71 286 285 72 286 minecraft:iron_block
fill 285 71 288 285 72 288 minecraft:iron_block
fill 286 71 277 286 72 277 minecraft:iron_block
fill 286 71 279 286 72 279 minecraft:iron_block
fill 286 71 281 286 72 281 minecraft:iron_block
fill 286 71 283 286 72 283 minecraft:iron_block
fill 286 71 285 286 72 285 minecraft:iron_block
fill 286 71 287 286 72 287 minecraft:iron_block
fill 287 71 276 287 72 276 minecraft:iron_block
fill 287 71 278 287 72 278 minecraft:iron_block
fill 287 71 280 287 72 280 minecraft:iron_block
fill 287 71 282 287 72 282 minecraft:iron_block
fill 287 71 284 287 72 284 minecraft:iron_block
fill 287 71 286 287 72 286 minecraft:iron_block
fill 287 71 288 287 72 288 minecraft:iron_block
fill 288 71 277 288 72 277 minecraft:iron_block
fill 288 71 279 288 72 279 minecraft:iron_block
fill 288 71 281 288 72 281 minecraft:iron_block
fill 288 71 283 288 72 283 minecraft:iron_block
fill 288 71 285 288 72 285 minecraft:iron_block
fill 288 71 287 288 72 287 minecraft:iron_block
fill 299 71 310 299 72 310 minecraft:iron_block
fill 299 71 312 299 72 312 minecraft:iron_block
fill 299 71 314 299 72 314 minecraft:iron_block
fill 299 71 316 299 72 316 minecraft:iron_block
fill 300 71 309 300 72 309 minecraft:iron_block
fill 300 71 311 300 72 311 minecraft:iron_block
fill 300 71 313 300 72 313 minecraft:iron_block
fill 300 71 315 300 72 315 minecraft:iron_block
fill 301 71 310 301 72 310 minecraft:iron_block
fill 301 71 312 301 72 312 minecraft:iron_block
fill 301 71 314 301 72 314 minecraft:iron_block
fill 301 71 316 301 72 316 minecraft:iron_block
fill 302 71 309 302 72 309 minecraft:iron_block
fill 302 71 311 302 72 311 minecraft:iron_block
fill 302 71 313 302 72 313 minecraft:iron_block
fill 302 71 315 302 72 315 minecraft:iron_block
fill 303 71 310 303 72 310 minecraft:iron_block
fill 303 71 312 303 72 312 minecraft:iron_block
fill 303 71 314 303 72 314 minecraft:iron_block
fill 303 71 316 303 72 316 minecraft:iron_block
fill 304 71 309 304 72 309 minecraft:iron_block
fill 304 71 311 304 72 311 minecraft:iron_block
fill 304 71 313 304 72 313 minecraft:iron_block
fill 304 71 315 304 72 315 minecraft:iron_block
fill 305 71 310 305 72 310 minecraft:iron_block
fill 305 71 312 305 72 312 minecraft:iron_block
fill 305 71 314 305 72 314 minecraft:iron_block
fill 305 71 316 305 72 316 minecraft:iron_block
fill 306 71 309 306 72 309 minecraft:iron_block
fill 306 71 311 306 72 311 minecraft:iron_block
fill 306 71 313 306 72 313 minecraft:iron_block
fill 306 71 315 306 72 315 minecraft:iron_block
fill 307 71 310 307 72 310 minecraft:iron_block
fill 307 71 312 307 72 312 minecraft:iron_block
fill 307 71 314 307 72 314 minecraft:iron_block
fill 307 71 316 307 72 316 minecraft:iron_block
fill 324 71 296 324 75 296 minecraft:iron_block
fill 283 72 290 283 72 293 minecraft:iron_block
setblock 283 72 298 minecraft:iron_block
fill 283 72 300 283 72 303 minecraft:iron_block
setblock 283 72 308 minecraft:iron_block
fill 283 72 310 283 72 313 minecraft:iron_block
setblock 285 72 292 minecraft:light[level=12]
setblock 285 72 294 minecraft:light[level=15]
setblock 285 72 299 minecraft:light[level=12]
setblock 285 72 302 minecraft:light[level=15]
setblock 285 72 306 minecraft:light[level=12]
setblock 285 72 310 minecraft:light[level=15]
setblock 285 72 313 minecraft:light[level=12]
setblock 285 72 316 minecraft:iron_block
fill 287 72 316 290 72 316 minecraft:iron_block
setblock 289 72 276 minecraft:iron_block
setblock 292 72 278 minecraft:light[level=12]
setblock 292 72 285 minecraft:light[level=12]
setblock 292 72 292 minecraft:light[level=12]
setblock 292 72 299 minecraft:light[level=12]
setblock 292 72 306 minecraft:light[level=12]
setblock 292 72 313 minecraft:light[level=12]
setblock 293 72 278 minecraft:light[level=15]
setblock 293 72 286 minecraft:light[level=15]
setblock 293 72 294 minecraft:light[level=15]
setblock 293 72 302 minecraft:light[level=15]
setblock 293 72 310 minecraft:light[level=15]
fill 294 72 276 297 72 276 minecraft:iron_block
setblock 295 72 316 minecraft:iron_block
fill 297 72 316 298 72 316 minecraft:iron_block
setblock 299 72 276 minecraft:iron_block
setblock 299 72 278 minecraft:light[level=12]
setblock 299 72 285 minecraft:light[level=12]
setblock 299 72 292 minecraft:light[level=12]
setblock 299 72 299 minecraft:light[level=12]
setblock 299 72 306 minecraft:light[level=12]
setblock 301 72 278 minecraft:light[level=15]
setblock 301 72 286 minecraft:light[level=15]
setblock 301 72 294 minecraft:light[level=15]
setblock 301 72 302 minecraft:light[level=15]
fill 304 72 276 307 72 276 minecraft:iron_block
setblock 306 72 278 minecraft:light[level=12]
setblock 306 72 285 minecraft:light[level=12]
setblock 306 72 292 minecraft:light[level=12]
setblock 306 72 299 minecraft:light[level=12]
setblock 306 72 306 minecraft:light[level=12]
fill 308 72 316 310 72 316 minecraft:iron_block
setblock 309 72 276 minecraft:iron_block
setblock 309 72 278 minecraft:light[level=15]
setblock 309 72 286 minecraft:light[level=15]
setblock 309 72 294 minecraft:light[level=15]
setblock 309 72 302 minecraft:light[level=15]
setblock 309 72 310 minecraft:light[level=15]
fill 312 72 278 312 72 280 minecraft:iron_block
fill 313 72 277 315 72 277 minecraft:iron_block
fill 313 72 281 315 72 281 minecraft:iron_block
setblock 313 72 292 minecraft:light[level=12]
setblock 313 72 299 minecraft:light[level=12]
setblock 313 72 306 minecraft:light[level=12]
setblock 313 72 313 minecraft:light[level=12]
fill 314 72 276 317 72 276 minecraft:iron_block
setblock 315 72 316 minecraft:iron_block
fill 316 72 278 316 72 280 minecraft:iron_block
setblock 317 72 278 minecraft:light[level=15]
setblock 317 72 294 minecraft:light[level=15]
setblock 317 72 302 minecraft:light[level=15]
setblock 317 72 310 minecraft:light[level=15]
fill 317 72 316 320 72 316 minecraft:iron_block
setblock 319 72 276 minecraft:iron_block
setblock 320 72 278 minecraft:light[level=12]
setblock 320 72 292 minecraft:light[level=12]
setblock 320 72 299 minecraft:light[level=12]
setblock 320 72 306 minecraft:light[level=12]
setblock 320 72 313 minecraft:light[level=12]
fill 323 72 277 323 72 280 minecraft:iron_block
setblock 323 72 282 minecraft:iron_block
setblock 323 72 292 minecraft:iron_block
fill 323 72 297 323 72 300 minecraft:iron_block
setblock 323 72 302 minecraft:iron_block
fill 323 72 307 323 72 310 minecraft:iron_block
setblock 323 72 312 minecraft:iron_block
setblock 283 73 276 minecraft:pearlescent_froglight
setblock 283 73 278 minecraft:pearlescent_froglight
setblock 283 73 280 minecraft:pearlescent_froglight
setblock 283 73 282 minecraft:pearlescent_froglight
setblock 283 73 284 minecraft:pearlescent_froglight
setblock 283 73 286 minecraft:pearlescent_froglight
setblock 283 73 288 minecraft:pearlescent_froglight
setblock 284 73 277 minecraft:pearlescent_froglight
setblock 284 73 279 minecraft:pearlescent_froglight
setblock 284 73 281 minecraft:pearlescent_froglight
setblock 284 73 283 minecraft:pearlescent_froglight
setblock 284 73 285 minecraft:pearlescent_froglight
setblock 284 73 287 minecraft:pearlescent_froglight
setblock 285 73 276 minecraft:pearlescent_froglight
setblock 285 73 278 minecraft:pearlescent_froglight
setblock 285 73 280 minecraft:pearlescent_froglight
setblock 285 73 282 minecraft:pearlescent_froglight
setblock 285 73 284 minecraft:pearlescent_froglight
setblock 285 73 286 minecraft:pearlescent_froglight
setblock 285 73 288 minecraft:pearlescent_froglight
setblock 286 73 277 minecraft:pearlescent_froglight
setblock 286 73 279 minecraft:pearlescent_froglight
setblock 286 73 281 minecraft:pearlescent_froglight
setblock 286 73 283 minecraft:pearlescent_froglight
setblock 286 73 285 minecraft:pearlescent_froglight
setblock 286 73 287 minecraft:pearlescent_froglight
setblock 287 73 276 minecraft:pearlescent_froglight
setblock 287 73 278 minecraft:pearlescent_froglight
setblock 287 73 280 minecraft:pearlescent_froglight
setblock 287 73 282 minecraft:pearlescent_froglight
setblock 287 73 284 minecraft:pearlescent_froglight
setblock 287 73 286 minecraft:pearlescent_froglight
setblock 287 73 288 minecraft:pearlescent_froglight
setblock 288 73 277 minecraft:pearlescent_froglight
setblock 288 73 279 minecraft:pearlescent_froglight
setblock 288 73 281 minecraft:pearlescent_froglight
setblock 288 73 283 minecraft:pearlescent_froglight
setblock 288 73 285 minecraft:pearlescent_froglight
setblock 288 73 287 minecraft:pearlescent_froglight
fill 290 73 275 292 80 275 minecraft:iron_block
setblock 293 73 275 minecraft:sea_lantern
fill 294 73 275 294 80 275 minecraft:iron_block
setblock 299 73 310 minecraft:pearlescent_froglight
setblock 299 73 312 minecraft:pearlescent_froglight
setblock 299 73 314 minecraft:pearlescent_froglight
setblock 299 73 316 minecraft:pearlescent_froglight
setblock 300 73 309 minecraft:pearlescent_froglight
setblock 300 73 311 minecraft:pearlescent_froglight
setblock 300 73 313 minecraft:pearlescent_froglight
setblock 300 73 315 minecraft:pearlescent_froglight
setblock 301 73 310 minecraft:pearlescent_froglight
setblock 301 73 312 minecraft:pearlescent_froglight
setblock 301 73 314 minecraft:pearlescent_froglight
setblock 301 73 316 minecraft:pearlescent_froglight
setblock 302 73 309 minecraft:pearlescent_froglight
setblock 302 73 311 minecraft:pearlescent_froglight
setblock 302 73 313 minecraft:pearlescent_froglight
setblock 302 73 315 minecraft:pearlescent_froglight
setblock 303 73 310 minecraft:pearlescent_froglight
setblock 303 73 312 minecraft:pearlescent_froglight
setblock 303 73 314 minecraft:pearlescent_froglight
setblock 303 73 316 minecraft:pearlescent_froglight
setblock 304 73 309 minecraft:pearlescent_froglight
setblock 304 73 311 minecraft:pearlescent_froglight
setblock 304 73 313 minecraft:pearlescent_froglight
setblock 304 73 315 minecraft:pearlescent_froglight
setblock 305 73 310 minecraft:pearlescent_froglight
setblock 305 73 312 minecraft:pearlescent_froglight
setblock 305 73 314 minecraft:pearlescent_froglight
setblock 305 73 316 minecraft:pearlescent_froglight
setblock 306 73 309 minecraft:pearlescent_froglight
setblock 306 73 311 minecraft:pearlescent_froglight
setblock 306 73 313 minecraft:pearlescent_froglight
setblock 306 73 315 minecraft:pearlescent_froglight
setblock 307 73 310 minecraft:pearlescent_froglight
setblock 307 73 312 minecraft:pearlescent_froglight
setblock 307 73 314 minecraft:pearlescent_froglight
setblock 307 73 316 minecraft:pearlescent_froglight
fill 315 73 295 315 74 299 minecraft:iron_block
fill 316 73 294 316 74 295 minecraft:iron_block
fill 316 73 297 321 74 297 minecraft:iron_block
fill 316 73 299 316 74 300 minecraft:iron_block
fill 317 73 294 320 74 294 minecraft:iron_block
fill 317 73 300 320 74 300 minecraft:iron_block
fill 318 73 295 318 74 296 minecraft:iron_block
fill 318 73 298 318 74 299 minecraft:iron_block
fill 320 73 295 321 74 295 minecraft:iron_block
fill 320 73 299 321 74 299 minecraft:iron_block
fill 321 73 296 321 74 296 minecraft:iron_block
fill 321 73 298 321 74 298 minecraft:iron_block
fill 283 74 276 283 76 276 minecraft:iron_block
fill 283 74 278 283 76 278 minecraft:iron_block
fill 283 74 280 283 76 280 minecraft:iron_block
fill 283 74 282 283 76 282 minecraft:iron_block
fill 283 74 284 283 76 284 minecraft:iron_block
fill 283 74 286 283 76 286 minecraft:iron_block
fill 283 74 288 283 76 288 minecraft:iron_block
fill 284 74 277 284 76 277 minecraft:iron_block
fill 284 74 279 284 76 279 minecraft:iron_block
fill 284 74 281 284 76 281 minecraft:iron_block
fill 284 74 283 284 76 283 minecraft:iron_block
fill 284 74 285 284 76 285 minecraft:iron_block
fill 284 74 287 284 76 287 minecraft:iron_block
fill 285 74 276 285 76 276 minecraft:iron_block
fill 285 74 278 285 76 278 minecraft:iron_block
fill 285 74 280 285 76 280 minecraft:iron_block
fill 285 74 282 285 76 282 minecraft:iron_block
fill 285 74 284 285 76 284 minecraft:iron_block
fill 285 74 286 285 76 286 minecraft:iron_block
fill 285 74 288 285 76 288 minecraft:iron_block
fill 286 74 277 286 76 277 minecraft:iron_block
fill 286 74 279 286 76 279 minecraft:iron_block
fill 286 74 281 286 76 281 minecraft:iron_block
fill 286 74 283 286 76 283 minecraft:iron_block
fill 286 74 285 286 76 285 minecraft:iron_block
fill 286 74 287 286 76 287 minecraft:iron_block
fill 287 74 276 287 76 276 minecraft:iron_block
fill 287 74 278 287 76 278 minecraft:iron_block
fill 287 74 280 287 127 280 minecraft:iron_block
fill 287 74 282 287 76 282 minecraft:iron_block
fill 287 74 284 287 76 284 minecraft:iron_block
fill 287 74 286 287 76 286 minecraft:iron_block
fill 287 74 288 287 76 288 minecraft:iron_block
fill 288 74 277 288 76 277 minecraft:iron_block
fill 288 74 279 288 127 279 minecraft:iron_block
fill 288 74 281 288 127 281 minecraft:iron_block
fill 288 74 283 288 76 283 minecraft:iron_block
fill 288 74 285 288 76 285 minecraft:iron_block
fill 288 74 287 288 76 287 minecraft:iron_block
fill 293 74 275 293 80 275 minecraft:iron_block
fill 299 74 310 299 75 310 minecraft:iron_block
fill 299 74 312 299 75 312 minecraft:iron_block
fill 299 74 314 299 75 314 minecraft:iron_block
fill 299 74 316 299 75 316 minecraft:iron_block
fill 300 74 309 300 75 309 minecraft:iron_block
fill 300 74 311 300 75 311 minecraft:iron_block
fill 300 74 313 300 75 313 minecraft:iron_block
fill 300 74 315 300 75 315 minecraft:iron_block
fill 301 74 310 301 75 310 minecraft:iron_block
fill 301 74 312 301 75 312 minecraft:iron_block
fill 301 74 314 301 75 314 minecraft:iron_block
fill 301 74 316 301 75 316 minecraft:iron_block
fill 302 74 309 302 75 309 minecraft:iron_block
fill 302 74 311 302 75 311 minecraft:iron_block
fill 302 74 313 302 75 313 minecraft:iron_block
fill 302 74 315 302 75 315 minecraft:iron_block
fill 303 74 310 303 75 310 minecraft:iron_block
fill 303 74 312 303 75 312 minecraft:iron_block
fill 303 74 314 303 75 314 minecraft:iron_block
fill 303 74 316 303 75 316 minecraft:iron_block
fill 304 74 309 304 75 309 minecraft:iron_block
fill 304 74 311 304 75 311 minecraft:iron_block
fill 304 74 313 304 75 313 minecraft:iron_block
fill 304 74 315 304 75 315 minecraft:iron_block
fill 305 74 310 305 75 310 minecraft:iron_block
fill 305 74 312 305 75 312 minecraft:iron_block
fill 305 74 314 305 75 314 minecraft:iron_block
fill 305 74 316 305 75 316 minecraft:iron_block
fill 306 74 309 306 75 309 minecraft:iron_block
fill 306 74 311 306 75 311 minecraft:iron_block
fill 306 74 313 306 75 313 minecraft:iron_block
fill 306 74 315 306 75 315 minecraft:iron_block
fill 306 74 317 306 75 317 minecraft:iron_block
fill 307 74 310 307 75 310 minecraft:iron_block
fill 307 74 312 307 75 312 minecraft:iron_block
fill 307 74 314 307 75 314 minecraft:iron_block
fill 307 74 316 307 75 316 minecraft:iron_block
setblock 307 74 317 minecraft:sea_lantern
fill 308 74 317 309 75 317 minecraft:iron_block
setblock 324 74 280 minecraft:redstone_block
fill 324 74 281 324 80 285 minecraft:iron_block
setblock 285 75 275 minecraft:iron_block
setblock 286 75 275 minecraft:redstone_block
fill 298 75 278 298 75 280 minecraft:iron_block
fill 299 75 278 300 75 278 minecraft:iron_block
fill 299 75 280 300 75 280 minecraft:iron_block
setblock 300 75 279 minecraft:iron_block
fill 305 75 275 306 75 275 minecraft:iron_block
setblock 307 75 275 minecraft:redstone_block
setblock 307 75 317 minecraft:iron_block
setblock 308 75 275 minecraft:iron_block
fill 323 75 283 323 127 283 minecraft:iron_block
fill 324 75 280 324 80 280 minecraft:iron_block
fill 324 75 291 324 80 291 minecraft:iron_block
fill 282 76 281 282 76 284 minecraft:pearlescent_froglight
fill 282 76 291 282 76 294 minecraft:pearlescent_froglight
fill 282 76 301 282 76 304 minecraft:pearlescent_froglight
fill 282 76 311 282 76 314 minecraft:pearlescent_froglight
fill 285 76 275 288 76 275 minecraft:pearlescent_froglight
fill 285 76 291 285 94 291 minecraft:iron_block
fill 286 76 317 289 76 317 minecraft:pearlescent_froglight
setblock 289 76 278 minecraft:gray_concrete
setblock 289 76 282 minecraft:gray_concrete
fill 290 76 279 290 76 281 minecraft:gray_concrete
fill 295 76 275 298 76 275 minecraft:pearlescent_froglight
fill 296 76 317 299 76 317 minecraft:pearlescent_froglight
setblock 299 76 310 minecraft:pearlescent_froglight
setblock 299 76 312 minecraft:pearlescent_froglight
setblock 299 76 314 minecraft:pearlescent_froglight
setblock 299 76 316 minecraft:pearlescent_froglight
setblock 300 76 309 minecraft:pearlescent_froglight
setblock 300 76 311 minecraft:pearlescent_froglight
setblock 300 76 313 minecraft:pearlescent_froglight
setblock 300 76 315 minecraft:pearlescent_froglight
setblock 301 76 310 minecraft:pearlescent_froglight
setblock 301 76 312 minecraft:pearlescent_froglight
setblock 301 76 314 minecraft:pearlescent_froglight
setblock 301 76 316 minecraft:pearlescent_froglight
setblock 302 76 309 minecraft:pearlescent_froglight
setblock 302 76 311 minecraft:pearlescent_froglight
setblock 302 76 313 minecraft:pearlescent_froglight
setblock 302 76 315 minecraft:pearlescent_froglight
setblock 303 76 310 minecraft:pearlescent_froglight
setblock 303 76 312 minecraft:pearlescent_froglight
setblock 303 76 314 minecraft:pearlescent_froglight
setblock 303 76 316 minecraft:pearlescent_froglight
setblock 304 76 309 minecraft:pearlescent_froglight
setblock 304 76 311 minecraft:pearlescent_froglight
setblock 304 76 313 minecraft:pearlescent_froglight
setblock 304 76 315 minecraft:pearlescent_froglight
fill 305 76 275 308 76 275 minecraft:pearlescent_froglight
setblock 305 76 310 minecraft:pearlescent_froglight
setblock 305 76 312 minecraft:pearlescent_froglight
setblock 305 76 314 minecraft:pearlescent_froglight
setblock 305 76 316 minecraft:pearlescent_froglight
setblock 306 76 309 minecraft:pearlescent_froglight
setblock 306 76 311 minecraft:pearlescent_froglight
setblock 306 76 313 minecraft:pearlescent_froglight
setblock 306 76 315 minecraft:pearlescent_froglight
fill 306 76 317 309 76 317 minecraft:pearlescent_froglight
setblock 307 76 310 minecraft:pearlescent_froglight
setblock 307 76 312 minecraft:pearlescent_froglight
setblock 307 76 314 minecraft:pearlescent_froglight
setblock 307 76 316 minecraft:pearlescent_froglight
fill 315 76 275 318 76 275 minecraft:pearlescent_froglight
fill 316 76 317 319 76 317 minecraft:pearlescent_froglight
fill 324 76 276 324 76 279 minecraft:pearlescent_froglight
fill 324 76 286 324 76 289 minecraft:pearlescent_froglight
fill 324 76 296 324 76 299 minecraft:pearlescent_froglight
fill 324 76 300 324 80 302 minecraft:iron_block
setblock 324 76 303 minecraft:sea_lantern
fill 324 76 304 324 80 305 minecraft:iron_block
fill 324 76 306 324 76 309 minecraft:pearlescent_froglight
fill 324 76 313 324 80 313 minecraft:iron_block
setblock 324 76 314 minecraft:sea_lantern
fill 324 76 315 324 80 315 minecraft:iron_block
setblock 324 76 316 minecraft:pearlescent_froglight
fill 282 77 281 282 80 284 minecraft:iron_block
fill 282 77 291 282 80 294 minecraft:iron_block
fill 282 77 301 282 80 304 minecraft:iron_block
fill 282 77 311 282 80 314 minecraft:iron_block
fill 283 77 290 284 86 292 minecraft:iron_block
fill 284 77 289 286 88 289 minecraft:iron_block
fill 284 77 293 286 88 293 minecraft:iron_block
fill 285 77 275 288 80 275 minecraft:iron_block
fill 285 77 290 287 93 290 minecraft:iron_block
fill 285 77 292 287 93 292 minecraft:iron_block
fill 286 77 291 287 94 291 minecraft:iron_block
fill 286 77 317 289 80 317 minecraft:iron_block
fill 295 77 275 298 80 275 minecraft:iron_block
fill 296 77 317 299 80 317 minecraft:iron_block
fill 299 77 310 299 78 310 minecraft:iron_block
fill 299 77 312 299 78 312 minecraft:iron_block
fill 299 77 314 299 78 314 minecraft:iron_block
fill 299 77 316 299 78 316 minecraft:iron_block
fill 300 77 309 300 78 309 minecraft:iron_block
fill 300 77 311 300 78 311 minecraft:iron_block
fill 300 77 313 300 78 313 minecraft:iron_block
fill 300 77 315 300 78 315 minecraft:iron_block
fill 301 77 310 301 78 310 minecraft:iron_block
fill 301 77 312 301 78 312 minecraft:iron_block
fill 301 77 314 301 78 314 minecraft:iron_block
fill 301 77 316 301 78 316 minecraft:iron_block
fill 302 77 309 302 78 309 minecraft:iron_block
fill 302 77 311 302 78 311 minecraft:iron_block
fill 302 77 313 302 78 313 minecraft:iron_block
fill 302 77 315 302 78 315 minecraft:iron_block
fill 303 77 310 303 78 310 minecraft:iron_block
fill 303 77 312 303 78 312 minecraft:iron_block
fill 303 77 314 303 78 314 minecraft:iron_block
fill 303 77 316 303 78 316 minecraft:iron_block
fill 304 77 309 304 78 309 minecraft:iron_block
fill 304 77 311 304 78 311 minecraft:iron_block
fill 304 77 313 304 78 313 minecraft:iron_block
fill 304 77 315 304 78 315 minecraft:iron_block
fill 305 77 275 308 80 275 minecraft:iron_block
fill 305 77 310 305 78 310 minecraft:iron_block
fill 305 77 312 305 78 312 minecraft:iron_block
fill 305 77 314 305 78 314 minecraft:iron_block
fill 305 77 316 305 78 316 minecraft:iron_block
fill 306 77 309 306 78 309 minecraft:iron_block
fill 306 77 311 306 78 311 minecraft:iron_block
fill 306 77 313 306 78 313 minecraft:iron_block
fill 306 77 315 306 78 315 minecraft:iron_block
fill 306 77 317 309 80 317 minecraft:iron_block
fill 307 77 310 307 78 310 minecraft:iron_block
fill 307 77 312 307 78 312 minecraft:iron_block
fill 307 77 314 307 78 314 minecraft:iron_block
fill 307 77 316 307 78 316 minecraft:iron_block
fill 315 77 275 318 80 275 minecraft:iron_block
fill 316 77 317 319 80 317 minecraft:iron_block
fill 324 77 276 324 80 279 minecraft:iron_block
fill 324 77 286 324 80 289 minecraft:iron_block
fill 324 77 296 324 80 299 minecraft:iron_block
fill 324 77 303 324 80 303 minecraft:iron_block
fill 324 77 306 324 80 308 minecraft:iron_block
setblock 324 77 309 minecraft:redstone_block
fill 324 77 314 324 80 314 minecraft:iron_block
fill 324 77 316 324 80 316 minecraft:iron_block
setblock 283 78 278 minecraft:iron_block
fill 283 78 288 283 82 289 minecraft:iron_block
fill 283 78 293 283 85 293 minecraft:iron_block
setblock 283 78 298 minecraft:iron_block
setblock 283 78 308 minecraft:iron_block
fill 284 78 288 286 85 288 minecraft:iron_block
fill 284 78 294 286 85 294 minecraft:iron_block
setblock 285 78 278 minecraft:light[level=12]
setblock 285 78 285 minecraft:light[level=12]
setblock 285 78 299 minecraft:light[level=12]
setblock 285 78 306 minecraft:light[level=12]
setblock 285 78 313 minecraft:light[level=12]
setblock 285 78 316 minecraft:iron_block
fill 287 78 289 287 95 289 minecraft:iron_block
fill 287 78 293 287 95 293 minecraft:iron_block
fill 288 78 290 288 95 292 minecraft:iron_block
setblock 289 78 276 minecraft:iron_block
setblock 290 78 317 minecraft:redstone_block
fill 291 78 317 295 78 317 minecraft:iron_block
setblock 292 78 278 minecraft:light[level=12]
setblock 292 78 285 minecraft:light[level=12]
setblock 292 78 292 minecraft:light[level=12]
setblock 292 78 299 minecraft:light[level=12]
setblock 292 78 306 minecraft:light[level=12]
setblock 292 78 313 minecraft:light[level=12]
setblock 295 78 316 minecraft:iron_block
setblock 299 78 276 minecraft:iron_block
setblock 299 78 278 minecraft:light[level=12]
setblock 299 78 285 minecraft:light[level=12]
setblock 299 78 292 minecraft:light[level=12]
setblock 299 78 299 minecraft:light[level=12]
setblock 299 78 306 minecraft:light[level=12]
setblock 306 78 278 minecraft:light[level=12]
setblock 306 78 285 minecraft:light[level=12]
setblock 306 78 292 minecraft:light[level=12]
setblock 306 78 299 minecraft:light[level=12]
setblock 306 78 306 minecraft:light[level=12]
setblock 309 78 276 minecraft:iron_block
fill 312 78 278 312 78 280 minecraft:iron_block
fill 313 78 277 315 78 277 minecraft:iron_block
fill 313 78 281 315 78 281 minecraft:iron_block
setblock 313 78 285 minecraft:light[level=12]
setblock 313 78 292 minecraft:light[level=12]
setblock 313 78 299 minecraft:light[level=12]
setblock 313 78 306 minecraft:light[level=12]
setblock 313 78 313 minecraft:light[level=12]
setblock 315 78 316 minecraft:iron_block
fill 316 78 278 316 78 280 minecraft:iron_block
setblock 319 78 276 minecraft:iron_block
setblock 320 78 278 minecraft:light[level=12]
setblock 320 78 285 minecraft:light[level=12]
setblock 320 78 292 minecraft:light[level=12]
setblock 320 78 299 minecraft:light[level=12]
setblock 320 78 306 minecraft:light[level=12]
setblock 320 78 313 minecraft:light[level=12]
setblock 323 78 282 minecraft:iron_block
setblock 323 78 292 minecraft:iron_block
setblock 323 78 302 minecraft:iron_block
setblock 323 78 312 minecraft:iron_block
fill 324 78 309 324 80 309 minecraft:iron_block
fill 283 79 294 283 82 294 minecraft:iron_block
fill 287 79 288 287 94 288 minecraft:iron_block
fill 287 79 294 287 94 294 minecraft:iron_block
fill 288 79 289 288 95 289 minecraft:iron_block
fill 288 79 293 288 95 293 minecraft:iron_block
fill 290 79 317 292 80 317 minecraft:iron_block
setblock 293 79 317 minecraft:sea_lantern
fill 294 79 317 295 80 317 minecraft:iron_block
fill 319 79 275 319 80 275 minecraft:iron_block
setblock 320 79 275 minecraft:sea_lantern
fill 321 79 275 324 80 275 minecraft:iron_block
setblock 285 80 278 minecraft:light[level=15]
setblock 285 80 286 minecraft:light[level=15]
fill 285 80 287 285 82 287 minecraft:iron_block
fill 285 80 295 285 82 295 minecraft:iron_block
setblock 285 80 302 minecraft:light[level=15]
setblock 285 80 310 minecraft:light[level=15]
fill 289 80 290 289 95 292 minecraft:iron_block
setblock 293 80 278 minecraft:light[level=15]
setblock 293 80 286 minecraft:light[level=15]
setblock 293 80 294 minecraft:light[level=15]
setblock 293 80 302 minecraft:light[level=15]
setblock 293 80 310 minecraft:light[level=15]
setblock 293 80 317 minecraft:iron_block
fill 299 80 275 302 80 275 minecraft:iron_block
setblock 301 80 278 minecraft:light[level=15]
setblock 301 80 286 minecraft:light[level=15]
setblock 301 80 294 minecraft:light[level=15]
setblock 301 80 302 minecraft:light[level=15]
setblock 301 80 310 minecraft:light[level=15]
setblock 303 80 275 minecraft:sea_lantern
setblock 309 80 278 minecraft:light[level=15]
setblock 309 80 286 minecraft:light[level=15]
setblock 309 80 294 minecraft:light[level=15]
setblock 309 80 302 minecraft:light[level=15]
setblock 309 80 310 minecraft:light[level=15]
setblock 317 80 278 minecraft:light[level=15]
setblock 317 80 286 minecraft:light[level=15]
setblock 317 80 294 minecraft:light[level=15]
setblock 317 80 302 minecraft:light[level=15]
setblock 317 80 310 minecraft:light[level=15]
setblock 320 80 275 minecraft:iron_block
fill 282 81 275 282 82 276 minecraft:yellow_concrete
fill 282 81 277 282 82 278 minecraft:black_concrete
fill 282 81 279 282 82 280 minecraft:yellow_concrete
fill 282 81 281 282 82 282 minecraft:black_concrete
fill 282 81 283 282 82 284 minecraft:yellow_concrete
fill 282 81 285 282 82 286 minecraft:black_concrete
fill 282 81 287 282 82 288 minecraft:yellow_concrete
fill 282 81 289 282 82 290 minecraft:black_concrete
fill 282 81 291 282 82 292 minecraft:yellow_concrete
fill 282 81 293 282 82 294 minecraft:black_concrete
fill 282 81 295 282 82 296 minecraft:yellow_concrete
fill 282 81 297 282 82 298 minecraft:black_concrete
fill 282 81 299 282 82 300 minecraft:yellow_concrete
fill 282 81 301 282 82 302 minecraft:black_concrete
fill 282 81 303 282 82 304 minecraft:yellow_concrete
fill 282 81 305 282 82 306 minecraft:black_concrete
fill 282 81 307 282 82 308 minecraft:yellow_concrete
fill 282 81 309 282 82 310 minecraft:black_concrete
fill 282 81 311 282 82 312 minecraft:yellow_concrete
fill 282 81 313 282 82 314 minecraft:black_concrete
fill 282 81 315 282 82 316 minecraft:yellow_concrete
fill 282 81 317 282 82 317 minecraft:black_concrete
fill 283 81 275 283 82 275 minecraft:yellow_concrete
fill 283 81 280 283 81 283 minecraft:iron_block
fill 283 81 300 283 81 303 minecraft:iron_block
fill 283 81 310 283 81 313 minecraft:iron_block
fill 283 81 317 283 82 317 minecraft:yellow_concrete
fill 284 81 275 285 82 275 minecraft:black_concrete
fill 284 81 276 287 81 276 minecraft:iron_block
fill 284 81 317 285 82 317 minecraft:black_concrete
fill 286 81 275 287 82 275 minecraft:yellow_concrete
fill 286 81 287 286 85 287 minecraft:iron_block
fill 286 81 295 286 85 295 minecraft:iron_block
fill 286 81 317 287 82 317 minecraft:yellow_concrete
fill 287 81 316 290 81 316 minecraft:iron_block
fill 288 81 275 289 82 275 minecraft:black_concrete
fill 288 81 288 288 95 288 minecraft:iron_block
fill 288 81 294 288 95 294 minecraft:iron_block
fill 288 81 317 289 82 317 minecraft:black_concrete
fill 289 81 289 289 95 289 minecraft:iron_block
fill 289 81 293 289 95 293 minecraft:iron_block
fill 290 81 275 291 82 275 minecraft:yellow_concrete
fill 290 81 317 291 82 317 minecraft:yellow_concrete
fill 292 81 275 293 82 275 minecraft:black_concrete
fill 292 81 317 293 82 317 minecraft:black_concrete
fill 294 81 275 295 82 275 minecraft:yellow_concrete
fill 294 81 276 297 81 276 minecraft:iron_block
fill 294 81 317 295 82 317 minecraft:yellow_concrete
fill 296 81 275 297 82 275 minecraft:black_concrete
fill 296 81 317 297 82 317 minecraft:black_concrete
fill 297 81 316 300 81 316 minecraft:iron_block
fill 298 81 275 299 82 275 minecraft:yellow_concrete
fill 298 81 317 299 82 317 minecraft:yellow_concrete
fill 300 81 275 301 82 275 minecraft:black_concrete
fill 300 81 317 301 82 317 minecraft:black_concrete
fill 302 81 275 303 82 275 minecraft:yellow_concrete
fill 302 81 317 303 82 317 minecraft:yellow_concrete
fill 304 81 275 305 82 275 minecraft:black_concrete
fill 304 81 276 307 81 276 minecraft:iron_block
fill 304 81 317 305 82 317 minecraft:black_concrete
fill 306 81 275 307 82 275 minecraft:yellow_concrete
fill 306 81 317 307 82 317 minecraft:yellow_concrete
fill 307 81 316 310 81 316 minecraft:iron_block
fill 308 81 275 309 82 275 minecraft:black_concrete
fill 308 81 317 309 82 317 minecraft:black_concrete
fill 310 81 275 311 82 275 minecraft:yellow_concrete
fill 310 81 317 311 82 317 minecraft:yellow_concrete
fill 312 81 275 313 82 275 minecraft:black_concrete
fill 312 81 317 313 82 317 minecraft:black_concrete
fill 314 81 275 315 82 275 minecraft:yellow_concrete
fill 314 81 276 317 81 276 minecraft:iron_block
fill 314 81 317 315 82 317 minecraft:yellow_concrete
fill 316 81 275 317 82 275 minecraft:black_concrete
fill 316 81 317 317 82 317 minecraft:black_concrete
fill 317 81 316 320 81 316 minecraft:iron_block
fill 318 81 275 319 82 275 minecraft:yellow_concrete
fill 318 81 317 319 82 317 minecraft:yellow_concrete
fill 320 81 275 321 82 275 minecraft:black_concrete
fill 320 81 317 321 82 317 minecraft:black_concrete
fill 322 81 275 323 82 275 minecraft:yellow_concrete
fill 322 81 317 323 82 317 minecraft:yellow_concrete
fill 323 81 277 323 81 280 minecraft:iron_block
fill 323 81 287 323 81 290 minecraft:iron_block
fill 323 81 293 323 127 293 minecraft:iron_block
fill 323 81 297 323 81 300 minecraft:iron_block
fill 323 81 307 323 81 310 minecraft:iron_block
fill 324 81 275 324 82 275 minecraft:black_concrete
fill 324 81 276 324 82 276 minecraft:yellow_concrete
fill 324 81 277 324 82 278 minecraft:black_concrete
fill 324 81 279 324 82 280 minecraft:yellow_concrete
fill 324 81 281 324 82 282 minecraft:black_concrete
fill 324 81 283 324 82 284 minecraft:yellow_concrete
fill 324 81 285 324 82 286 minecraft:black_concrete
fill 324 81 287 324 82 288 minecraft:yellow_concrete
fill 324 81 289 324 82 290 minecraft:black_concrete
fill 324 81 291 324 82 292 minecraft:yellow_concrete
fill 324 81 293 324 82 294 minecraft:black_concrete
fill 324 81 295 324 82 296 minecraft:yellow_concrete
fill 324 81 297 324 82 298 minecraft:black_concrete
fill 324 81 299 324 82 300 minecraft:yellow_concrete
fill 324 81 301 324 82 302 minecraft:black_concrete
fill 324 81 303 324 82 304 minecraft:yellow_concrete
fill 324 81 305 324 82 306 minecraft:black_concrete
fill 324 81 307 324 82 308 minecraft:yellow_concrete
fill 324 81 309 324 82 310 minecraft:black_concrete
fill 324 81 311 324 82 312 minecraft:yellow_concrete
fill 324 81 313 324 82 314 minecraft:black_concrete
fill 324 81 315 324 82 316 minecraft:yellow_concrete
fill 324 81 317 324 82 317 minecraft:black_concrete
fill 298 82 278 298 82 280 minecraft:iron_block
fill 299 82 278 300 82 278 minecraft:iron_block
fill 299 82 280 300 82 280 minecraft:iron_block
setblock 300 82 279 minecraft:iron_block
fill 282 83 275 282 84 311 minecraft:iron_block
setblock 282 83 312 minecraft:redstone_block
fill 282 83 313 282 84 317 minecraft:iron_block
fill 283 83 275 306 84 275 minecraft:iron_block
fill 283 83 289 283 85 289 minecraft:iron_block
fill 283 83 317 324 84 317 minecraft:iron_block
fill 290 83 290 290 95 292 minecraft:iron_block
setblock 307 83 275 minecraft:redstone_block
fill 308 83 275 324 84 275 minecraft:iron_block
fill 324 83 276 324 83 316 minecraft:iron_block
setblock 282 84 312 minecraft:iron_block
setblock 283 84 278 minecraft:iron_block
setblock 283 84 288 minecraft:iron_block
setblock 283 84 298 minecraft:iron_block
setblock 283 84 308 minecraft:iron_block
setblock 285 84 278 minecraft:light[level=12]
setblock 285 84 285 minecraft:light[level=12]
setblock 285 84 299 minecraft:light[level=12]
setblock 285 84 306 minecraft:light[level=12]
setblock 285 84 313 minecraft:light[level=12]
setblock 285 84 316 minecraft:iron_block
setblock 286 84 279 minecraft:gray_concrete
fill 286 84 281 286 84 282 minecraft:gray_concrete
fill 287 84 278 289 84 278 minecraft:gray_concrete
setblock 287 84 282 minecraft:gray_concrete
fill 287 84 287 287 94 287 minecraft:iron_block
fill 287 84 295 287 94 295 minecraft:iron_block
setblock 289 84 276 minecraft:iron_block
setblock 289 84 282 minecraft:gray_concrete
fill 289 84 288 289 95 288 minecraft:iron_block
fill 289 84 294 289 95 294 minecraft:iron_block
fill 290 84 279 290 84 281 minecraft:gray_concrete
fill 290 84 289 290 95 289 minecraft:iron_block
fill 290 84 293 290 95 293 minecraft:iron_block
setblock 292 84 278 minecraft:light[level=12]
setblock 292 84 285 minecraft:light[level=12]
setblock 292 84 292 minecraft:light[level=12]
setblock 292 84 299 minecraft:light[level=12]
setblock 292 84 306 minecraft:light[level=12]
setblock 292 84 313 minecraft:light[level=12]
setblock 295 84 316 minecraft:iron_block
setblock 299 84 276 minecraft:iron_block
setblock 299 84 278 minecraft:light[level=12]
setblock 299 84 285 minecraft:light[level=12]
setblock 299 84 292 minecraft:light[level=12]
setblock 299 84 299 minecraft:light[level=12]
setblock 299 84 306 minecraft:light[level=12]
setblock 299 84 313 minecraft:light[level=12]
setblock 305 84 316 minecraft:iron_block
setblock 306 84 278 minecraft:light[level=12]
setblock 306 84 285 minecraft:light[level=12]
setblock 306 84 292 minecraft:light[level=12]
setblock 306 84 299 minecraft:light[level=12]
setblock 306 84 306 minecraft:light[level=12]
setblock 306 84 313 minecraft:light[level=12]
setblock 307 84 275 minecraft:iron_block
setblock 309 84 276 minecraft:iron_block
fill 312 84 278 312 84 280 minecraft:iron_block
fill 313 84 277 315 84 277 minecraft:iron_block
fill 313 84 281 315 84 281 minecraft:iron_block
setblock 313 84 285 minecraft:light[level=12]
setblock 313 84 292 minecraft:light[level=12]
setblock 313 84 299 minecraft:light[level=12]
setblock 313 84 306 minecraft:light[level=12]
setblock 313 84 313 minecraft:light[level=12]
setblock 315 84 316 minecraft:iron_block
fill 316 84 278 316 84 280 minecraft:iron_block
setblock 319 84 276 minecraft:iron_block
setblock 320 84 278 minecraft:light[level=12]
setblock 320 84 285 minecraft:light[level=12]
setblock 320 84 292 minecraft:light[level=12]
setblock 320 84 299 minecraft:light[level=12]
setblock 320 84 306 minecraft:light[level=12]
setblock 320 84 313 minecraft:light[level=12]
fill 323 84 282 324 84 282 minecraft:iron_block
fill 323 84 292 324 84 292 minecraft:iron_block
fill 323 84 302 324 84 302 minecraft:iron_block
fill 323 84 312 324 84 312 minecraft:iron_block
fill 324 84 276 324 84 281 minecraft:iron_block
fill 324 84 283 324 84 290 minecraft:iron_block
setblock 324 84 291 minecraft:sea_lantern
fill 324 84 293 324 84 301 minecraft:iron_block
fill 324 84 303 324 84 311 minecraft:iron_block
fill 324 84 313 324 84 316 minecraft:iron_block
fill 282 85 275 282 108 280 minecraft:iron_block
fill 282 85 281 282 85 284 minecraft:pearlescent_froglight
fill 282 85 285 282 85 290 minecraft:iron_block
fill 282 85 291 282 85 294 minecraft:pearlescent_froglight
fill 282 85 295 282 102 300 minecraft:iron_block
fill 282 85 301 282 85 304 minecraft:pearlescent_froglight
fill 282 85 305 282 89 310 minecraft:iron_block
fill 282 85 311 282 85 314 minecraft:pearlescent_froglight
fill 282 85 315 282 103 317 minecraft:iron_block
fill 283 85 275 284 108 275 minecraft:iron_block
fill 283 85 317 285 108 317 minecraft:iron_block
fill 285 85 275 288 85 275 minecraft:pearlescent_froglight
fill 286 85 317 289 85 317 minecraft:pearlescent_froglight
fill 289 85 275 294 85 275 minecraft:iron_block
fill 290 85 317 295 98 317 minecraft:iron_block
fill 295 85 275 298 85 275 minecraft:pearlescent_froglight
fill 296 85 317 299 85 317 minecraft:pearlescent_froglight
fill 299 85 275 304 92 275 minecraft:iron_block
fill 300 85 317 305 107 317 minecraft:iron_block
fill 305 85 275 308 85 275 minecraft:pearlescent_froglight
fill 306 85 317 309 85 317 minecraft:pearlescent_froglight
fill 309 85 275 314 90 275 minecraft:iron_block
fill 310 85 317 315 108 317 minecraft:iron_block
fill 315 85 275 318 85 275 minecraft:pearlescent_froglight
fill 316 85 317 319 85 317 minecraft:pearlescent_froglight
fill 319 85 275 324 89 275 minecraft:iron_block
fill 320 85 317 324 95 317 minecraft:iron_block
fill 324 85 276 324 85 279 minecraft:pearlescent_froglight
fill 324 85 280 324 87 285 minecraft:iron_block
fill 324 85 286 324 85 289 minecraft:pearlescent_froglight
fill 324 85 290 324 87 295 minecraft:iron_block
fill 324 85 296 324 85 299 minecraft:pearlescent_froglight
fill 324 85 300 324 102 305 minecraft:iron_block
fill 324 85 306 324 85 309 minecraft:pearlescent_froglight
fill 324 85 310 324 108 315 minecraft:iron_block
setblock 324 85 316 minecraft:pearlescent_froglight
fill 282 86 281 282 93 285 minecraft:iron_block
setblock 282 86 286 minecraft:redstone_block
fill 282 86 287 282 87 294 minecraft:iron_block
fill 282 86 301 282 93 304 minecraft:iron_block
fill 282 86 311 282 93 314 minecraft:iron_block
fill 285 86 275 290 88 275 minecraft:iron_block
fill 285 86 288 286 88 288 minecraft:iron_block
fill 285 86 294 286 88 294 minecraft:iron_block
fill 286 86 317 288 93 317 minecraft:iron_block
setblock 289 86 317 minecraft:sea_lantern
setblock 291 86 275 minecraft:sea_lantern
fill 291 86 290 291 95 292 minecraft:iron_block
fill 292 86 275 298 93 275 minecraft:iron_block
fill 296 86 317 299 93 317 minecraft:iron_block
fill 305 86 275 308 93 275 minecraft:iron_block
fill 306 86 317 309 93 317 minecraft:iron_block
fill 315 86 275 318 93 275 minecraft:iron_block
fill 316 86 317 319 93 317 minecraft:iron_block
fill 324 86 276 324 93 279 minecraft:iron_block
fill 324 86 286 324 93 289 minecraft:iron_block
fill 324 86 296 324 93 299 minecraft:iron_block
fill 324 86 306 324 87 309 minecraft:iron_block
fill 324 86 316 324 93 316 minecraft:iron_block
fill 282 87 286 282 108 286 minecraft:iron_block
fill 284 87 290 284 92 292 minecraft:iron_block
fill 288 87 287 288 94 287 minecraft:iron_block
fill 288 87 295 288 94 295 minecraft:iron_block
fill 289 87 317 289 93 317 minecraft:iron_block
fill 290 87 288 292 95 288 minecraft:iron_block
fill 290 87 294 292 95 294 minecraft:iron_block
fill 291 87 275 291 108 275 minecraft:iron_block
fill 291 87 289 293 95 289 minecraft:iron_block
fill 291 87 293 293 95 293 minecraft:iron_block
fill 292 87 290 293 95 292 minecraft:iron_block
fill 282 88 287 282 108 287 minecraft:iron_block
setblock 282 88 288 minecraft:redstone_block
fill 282 88 289 282 90 294 minecraft:iron_block
setblock 285 88 278 minecraft:light[level=15]
setblock 285 88 286 minecraft:light[level=15]
setblock 285 88 302 minecraft:light[level=15]
setblock 285 88 310 minecraft:light[level=15]
fill 289 88 287 293 94 287 minecraft:iron_block
fill 289 88 295 293 94 295 minecraft:iron_block
fill 290 88 286 290 94 286 minecraft:iron_block
fill 290 88 296 290 94 296 minecraft:iron_block
setblock 293 88 278 minecraft:light[level=15]
setblock 293 88 286 minecraft:light[level=15]
fill 293 88 288 294 94 288 minecraft:iron_block
fill 293 88 294 294 94 294 minecraft:iron_block
setblock 293 88 302 minecraft:light[level=15]
setblock 293 88 310 minecraft:light[level=15]
fill 294 88 289 294 94 293 minecraft:iron_block
fill 295 88 291 295 94 291 minecraft:iron_block
setblock 301 88 278 minecraft:light[level=15]
setblock 301 88 286 minecraft:light[level=15]
setblock 301 88 294 minecraft:light[level=15]
setblock 301 88 302 minecraft:light[level=15]
setblock 301 88 310 minecraft:light[level=15]
setblock 309 88 278 minecraft:light[level=15]
setblock 309 88 286 minecraft:light[level=15]
setblock 309 88 294 minecraft:light[level=15]
setblock 309 88 302 minecraft:light[level=15]
setblock 309 88 310 minecraft:light[level=15]
setblock 317 88 278 minecraft:light[level=15]
setblock 317 88 286 minecraft:light[level=15]
setblock 317 88 294 minecraft:light[level=15]
setblock 317 88 302 minecraft:light[level=15]
setblock 317 88 310 minecraft:light[level=15]
fill 324 88 280 324 98 280 minecraft:iron_block
setblock 324 88 281 minecraft:sea_lantern
fill 324 88 282 324 108 285 minecraft:iron_block
fill 324 88 290 324 94 293 minecraft:iron_block
setblock 324 88 294 minecraft:redstone_block
fill 324 88 295 324 108 295 minecraft:iron_block
fill 324 88 306 324 93 308 minecraft:iron_block
setblock 324 88 309 minecraft:redstone_block
fill 282 89 288 282 108 288 minecraft:iron_block
fill 285 89 275 285 93 275 minecraft:iron_block
fill 285 89 289 286 93 289 minecraft:iron_block
fill 285 89 293 286 93 293 minecraft:iron_block
setblock 286 89 275 minecraft:sea_lantern
fill 286 89 287 286 93 288 minecraft:iron_block
fill 286 89 294 286 93 295 minecraft:iron_block
fill 287 89 275 290 93 275 minecraft:iron_block
fill 288 89 286 289 93 286 minecraft:iron_block
fill 288 89 296 289 93 296 minecraft:iron_block
fill 291 89 286 292 93 286 minecraft:iron_block
fill 291 89 296 292 93 296 minecraft:iron_block
fill 294 89 287 294 93 287 minecraft:iron_block
fill 294 89 295 294 93 295 minecraft:iron_block
fill 295 89 289 295 93 290 minecraft:iron_block
fill 295 89 292 295 93 293 minecraft:iron_block
fill 298 89 278 298 89 280 minecraft:iron_block
fill 299 89 278 300 89 278 minecraft:iron_block
fill 299 89 280 300 89 280 minecraft:iron_block
setblock 300 89 279 minecraft:iron_block
fill 324 89 281 324 103 281 minecraft:iron_block
fill 324 89 294 324 108 294 minecraft:iron_block
fill 324 89 309 324 93 309 minecraft:iron_block
fill 282 90 305 282 102 309 minecraft:iron_block
setblock 282 90 310 minecraft:redstone_block
setblock 283 90 278 minecraft:iron_block
fill 283 90 280 283 90 283 minecraft:iron_block
setblock 283 90 288 minecraft:iron_block
fill 283 90 290 283 90 293 minecraft:iron_block
setblock 283 90 298 minecraft:iron_block
fill 283 90 300 283 90 303 minecraft:iron_block
setblock 283 90 308 minecraft:iron_block
fill 283 90 310 283 90 313 minecraft:iron_block
fill 284 90 276 287 90 276 minecraft:iron_block
setblock 285 90 278 minecraft:light[level=12]
setblock 285 90 285 minecraft:light[level=12]
fill 285 90 288 285 92 288 minecraft:iron_block
fill 285 90 294 285 92 294 minecraft:iron_block
setblock 285 90 299 minecraft:light[level=12]
setblock 285 90 306 minecraft:light[level=12]
setblock 285 90 313 minecraft:light[level=12]
setblock 285 90 316 minecraft:iron_block
fill 286 90 275 286 93 275 minecraft:iron_block
fill 287 90 286 287 92 286 minecraft:iron_block
fill 287 90 296 287 92 296 minecraft:iron_block
fill 287 90 316 290 90 316 minecraft:iron_block
setblock 289 90 276 minecraft:iron_block
fill 289 90 285 291 92 285 minecraft:iron_block
fill 289 90 297 291 92 297 minecraft:iron_block
setblock 292 90 278 minecraft:light[level=12]
setblock 292 90 285 minecraft:light[level=12]
setblock 292 90 299 minecraft:light[level=12]
setblock 292 90 306 minecraft:light[level=12]
setblock 292 90 313 minecraft:light[level=12]
fill 293 90 286 293 92 286 minecraft:iron_block
fill 293 90 296 293 92 296 minecraft:iron_block
fill 294 90 276 297 90 276 minecraft:iron_block
fill 295 90 288 295 92 288 minecraft:iron_block
fill 295 90 294 295 92 294 minecraft:iron_block
setblock 295 90 316 minecraft:iron_block
fill 296 90 290 296 92 292 minecraft:iron_block
fill 297 90 316 300 90 316 minecraft:iron_block
setblock 299 90 276 minecraft:iron_block
setblock 299 90 278 minecraft:light[level=12]
setblock 299 90 285 minecraft:light[level=12]
setblock 299 90 292 minecraft:light[level=12]
setblock 299 90 299 minecraft:light[level=12]
setblock 299 90 306 minecraft:light[level=12]
setblock 299 90 313 minecraft:light[level=12]
fill 304 90 276 307 90 276 minecraft:iron_block
setblock 305 90 316 minecraft:iron_block
setblock 306 90 278 minecraft:light[level=12]
setblock 306 90 285 minecraft:light[level=12]
setblock 306 90 292 minecraft:light[level=12]
setblock 306 90 299 minecraft:light[level=12]
setblock 306 90 306 minecraft:light[level=12]
setblock 306 90 313 minecraft:light[level=12]
fill 307 90 316 310 90 316 minecraft:iron_block
setblock 309 90 276 minecraft:iron_block
fill 312 90 278 312 90 280 minecraft:iron_block
fill 313 90 277 315 90 277 minecraft:iron_block
fill 313 90 281 315 90 281 minecraft:iron_block
setblock 313 90 285 minecraft:light[level=12]
setblock 313 90 292 minecraft:light[level=12]
setblock 313 90 299 minecraft:light[level=12]
setblock 313 90 306 minecraft:light[level=12]
setblock 313 90 313 minecraft:light[level=12]
fill 314 90 276 317 90 276 minecraft:iron_block
setblock 315 90 316 minecraft:iron_block
fill 316 90 278 316 90 280 minecraft:iron_block
fill 317 90 316 320 90 316 minecraft:iron_block
fill 319 90 275 319 90 276 minecraft:iron_block
fill 320 90 275 322 108 275 minecraft:iron_block
setblock 320 90 278 minecraft:light[level=12]
setblock 320 90 285 minecraft:light[level=12]
setblock 320 90 292 minecraft:light[level=12]
setblock 320 90 299 minecraft:light[level=12]
setblock 320 90 306 minecraft:light[level=12]
setblock 320 90 313 minecraft:light[level=12]
setblock 323 90 275 minecraft:sea_lantern
fill 323 90 277 323 90 280 minecraft:iron_block
setblock 323 90 282 minecraft:iron_block
fill 323 90 287 323 90 290 minecraft:iron_block
setblock 323 90 292 minecraft:iron_block
fill 323 90 297 323 90 300 minecraft:iron_block
setblock 323 90 302 minecraft:iron_block
fill 323 90 307 323 90 310 minecraft:iron_block
setblock 323 90 312 minecraft:iron_block
fill 324 90 275 324 108 275 minecraft:iron_block
fill 282 91 289 282 93 291 minecraft:iron_block
setblock 282 91 292 minecraft:redstone_block
fill 282 91 293 282 93 294 minecraft:iron_block
fill 282 91 310 282 108 310 minecraft:iron_block
fill 309 91 275 312 95 275 minecraft:iron_block
setblock 313 91 275 minecraft:sea_lantern
fill 314 91 275 314 108 275 minecraft:iron_block
fill 319 91 275 319 108 275 minecraft:iron_block
fill 323 91 275 323 108 275 minecraft:iron_block
fill 282 92 292 282 93 292 minecraft:iron_block
setblock 286 92 279 minecraft:gray_concrete
fill 286 92 281 286 92 282 minecraft:gray_concrete
fill 287 92 278 289 92 278 minecraft:gray_concrete
setblock 287 92 282 minecraft:gray_concrete
setblock 289 92 282 minecraft:gray_concrete
fill 290 92 279 290 92 281 minecraft:gray_concrete
fill 313 92 275 313 102 275 minecraft:iron_block
fill 288 93 299 289 100 299 minecraft:iron_block
fill 299 93 275 300 102 275 minecraft:iron_block
setblock 301 93 275 minecraft:redstone_block
fill 302 93 275 304 108 275 minecraft:iron_block
fill 282 94 281 282 94 284 minecraft:pearlescent_froglight
fill 282 94 285 282 108 285 minecraft:iron_block
fill 282 94 289 282 98 290 minecraft:iron_block
fill 282 94 291 282 94 294 minecraft:pearlescent_froglight
fill 282 94 301 282 94 304 minecraft:pearlescent_froglight
fill 282 94 311 282 94 314 minecraft:pearlescent_froglight
fill 285 94 275 288 94 275 minecraft:pearlescent_froglight
fill 285 94 313 285 95 315 minecraft:iron_block
fill 286 94 288 286 94 290 minecraft:iron_block
fill 286 94 292 286 94 294 minecraft:iron_block
fill 286 94 317 289 94 317 minecraft:pearlescent_froglight
fill 287 94 290 287 95 290 minecraft:iron_block
fill 287 94 292 287 95 292 minecraft:iron_block
fill 289 94 275 290 97 275 minecraft:iron_block
fill 292 94 275 294 108 275 minecraft:iron_block
fill 295 94 275 298 94 275 minecraft:pearlescent_froglight
fill 296 94 317 299 94 317 minecraft:pearlescent_froglight
fill 301 94 275 301 108 275 minecraft:iron_block
fill 305 94 275 308 94 275 minecraft:pearlescent_froglight
fill 306 94 317 309 94 317 minecraft:pearlescent_froglight
fill 315 94 275 318 94 275 minecraft:pearlescent_froglight
fill 316 94 317 319 94 317 minecraft:pearlescent_froglight
fill 324 94 276 324 94 279 minecraft:pearlescent_froglight
fill 324 94 286 324 94 289 minecraft:pearlescent_froglight
fill 324 94 296 324 94 299 minecraft:pearlescent_froglight
fill 324 94 306 324 94 309 minecraft:pearlescent_froglight
setblock 324 94 316 minecraft:pearlescent_froglight
fill 282 95 281 282 102 284 minecraft:iron_block
fill 282 95 291 282 102 294 minecraft:iron_block
fill 282 95 301 282 102 304 minecraft:iron_block
fill 282 95 311 282 102 314 minecraft:iron_block
fill 285 95 275 288 102 275 minecraft:iron_block
fill 286 95 317 289 102 317 minecraft:iron_block
setblock 287 95 291 minecraft:iron_block
fill 295 95 275 298 96 275 minecraft:iron_block
fill 296 95 317 299 102 317 minecraft:iron_block
fill 305 95 275 308 102 275 minecraft:iron_block
fill 306 95 317 309 95 317 minecraft:iron_block
fill 315 95 275 318 95 275 minecraft:iron_block
fill 316 95 317 319 102 317 minecraft:iron_block
fill 324 95 276 324 102 279 minecraft:iron_block
fill 324 95 286 324 102 290 minecraft:iron_block
setblock 324 95 291 minecraft:redstone_block
fill 324 95 292 324 108 293 minecraft:iron_block
fill 324 95 296 324 102 299 minecraft:iron_block
fill 324 95 306 324 102 309 minecraft:iron_block
fill 324 95 316 324 102 316 minecraft:iron_block
setblock 283 96 278 minecraft:iron_block
setblock 283 96 288 minecraft:iron_block
setblock 283 96 298 minecraft:iron_block
setblock 283 96 308 minecraft:iron_block
setblock 285 96 278 minecraft:light[level=15]
setblock 285 96 285 minecraft:light[level=12]
setblock 285 96 286 minecraft:light[level=15]
setblock 285 96 292 minecraft:light[level=12]
setblock 285 96 294 minecraft:light[level=15]
setblock 285 96 299 minecraft:light[level=12]
setblock 285 96 302 minecraft:light[level=15]
setblock 285 96 306 minecraft:light[level=12]
setblock 285 96 310 minecraft:light[level=15]
setblock 285 96 313 minecraft:light[level=12]
setblock 285 96 316 minecraft:iron_block
setblock 289 96 276 minecraft:iron_block
setblock 292 96 278 minecraft:light[level=12]
setblock 292 96 285 minecraft:light[level=12]
setblock 292 96 292 minecraft:light[level=12]
setblock 292 96 299 minecraft:light[level=12]
setblock 292 96 306 minecraft:light[level=12]
setblock 292 96 313 minecraft:light[level=12]
setblock 293 96 278 minecraft:light[level=15]
setblock 293 96 286 minecraft:light[level=15]
setblock 293 96 294 minecraft:light[level=15]
setblock 293 96 302 minecraft:light[level=15]
setblock 293 96 310 minecraft:light[level=15]
setblock 295 96 316 minecraft:iron_block
fill 298 96 278 298 96 280 minecraft:iron_block
setblock 299 96 276 minecraft:iron_block
fill 299 96 278 300 96 278 minecraft:iron_block
fill 299 96 280 300 96 280 minecraft:iron_block
setblock 299 96 285 minecraft:light[level=12]
setblock 299 96 292 minecraft:light[level=12]
setblock 299 96 299 minecraft:light[level=12]
setblock 299 96 306 minecraft:light[level=12]
setblock 299 96 313 minecraft:light[level=12]
setblock 300 96 279 minecraft:iron_block
setblock 301 96 278 minecraft:light[level=15]
setblock 301 96 286 minecraft:light[level=15]
setblock 301 96 294 minecraft:light[level=15]
setblock 301 96 302 minecraft:light[level=15]
setblock 301 96 310 minecraft:light[level=15]
setblock 305 96 316 minecraft:iron_block
setblock 306 96 278 minecraft:light[level=12]
setblock 306 96 285 minecraft:light[level=12]
setblock 306 96 292 minecraft:light[level=12]
setblock 306 96 299 minecraft:light[level=12]
setblock 306 96 306 minecraft:light[level=12]
setblock 306 96 313 minecraft:light[level=12]
fill 306 96 317 306 102 317 minecraft:iron_block
setblock 307 96 317 minecraft:redstone_block
fill 308 96 317 309 102 317 minecraft:iron_block
setblock 309 96 275 minecraft:redstone_block
setblock 309 96 276 minecraft:iron_block
setblock 309 96 278 minecraft:light[level=15]
setblock 309 96 286 minecraft:light[level=15]
setblock 309 96 294 minecraft:light[level=15]
setblock 309 96 302 minecraft:light[level=15]
setblock 309 96 310 minecraft:light[level=15]
fill 310 96 275 312 108 275 minecraft:iron_block
fill 312 96 278 312 96 280 minecraft:iron_block
fill 313 96 277 315 96 277 minecraft:iron_block
fill 313 96 281 315 96 281 minecraft:iron_block
setblock 313 96 285 minecraft:light[level=12]
setblock 313 96 292 minecraft:light[level=12]
setblock 313 96 299 minecraft:light[level=12]
setblock 313 96 306 minecraft:light[level=12]
setblock 313 96 313 minecraft:light[level=12]
setblock 315 96 275 minecraft:sea_lantern
setblock 315 96 316 minecraft:iron_block
fill 316 96 275 318 102 275 minecraft:iron_block
fill 316 96 278 316 96 280 minecraft:iron_block
setblock 317 96 278 minecraft:light[level=15]
setblock 317 96 286 minecraft:light[level=15]
setblock 317 96 294 minecraft:light[level=15]
setblock 317 96 302 minecraft:light[level=15]
setblock 317 96 310 minecraft:light[level=15]
setblock 319 96 276 minecraft:iron_block
setblock 320 96 278 minecraft:light[level=12]
setblock 320 96 285 minecraft:light[level=12]
setblock 320 96 292 minecraft:light[level=12]
setblock 320 96 299 minecraft:light[level=12]
setblock 320 96 306 minecraft:light[level=12]
setblock 320 96 313 minecraft:light[level=12]
setblock 320 96 317 minecraft:redstone_block
fill 321 96 317 324 96 317 minecraft:iron_block
setblock 323 96 282 minecraft:iron_block
setblock 323 96 292 minecraft:iron_block
setblock 323 96 302 minecraft:iron_block
setblock 323 96 312 minecraft:iron_block
fill 324 96 291 324 108 291 minecraft:iron_block
setblock 295 97 275 minecraft:sea_lantern
fill 296 97 275 298 102 275 minecraft:iron_block
fill 307 97 317 307 102 317 minecraft:iron_block
fill 309 97 275 309 108 275 minecraft:iron_block
fill 315 97 275 315 102 275 minecraft:iron_block
fill 320 97 317 320 108 317 minecraft:iron_block
setblock 321 97 317 minecraft:redstone_block
fill 322 97 317 324 108 317 minecraft:iron_block
fill 289 98 275 289 108 275 minecraft:iron_block
setblock 290 98 275 minecraft:redstone_block
fill 295 98 275 295 102 275 minecraft:iron_block
fill 321 98 317 321 108 317 minecraft:iron_block
fill 282 99 289 282 108 289 minecraft:iron_block
setblock 282 99 290 minecraft:redstone_block
fill 283 99 280 283 99 283 minecraft:iron_block
fill 283 99 290 283 99 293 minecraft:iron_block
fill 283 99 300 283 99 303 minecraft:iron_block
fill 283 99 310 283 99 313 minecraft:iron_block
fill 284 99 276 287 99 276 minecraft:iron_block
fill 287 99 316 290 99 316 minecraft:iron_block
setblock 290 99 275 minecraft:iron_block
fill 290 99 317 290 108 317 minecraft:iron_block
setblock 291 99 317 minecraft:redstone_block
fill 292 99 317 295 108 317 minecraft:iron_block
fill 294 99 276 297 99 276 minecraft:iron_block
fill 297 99 316 300 99 316 minecraft:iron_block
fill 304 99 276 307 99 276 minecraft:iron_block
fill 307 99 316 310 99 316 minecraft:iron_block
fill 314 99 276 317 99 276 minecraft:iron_block
fill 317 99 316 320 99 316 minecraft:iron_block
fill 323 99 277 323 99 280 minecraft:iron_block
fill 323 99 287 323 99 290 minecraft:iron_block
fill 323 99 297 323 99 300 minecraft:iron_block
fill 323 99 307 323 99 310 minecraft:iron_block
setblock 324 99 280 minecraft:sea_lantern
fill 282 100 290 282 108 290 minecraft:iron_block
setblock 286 100 279 minecraft:gray_concrete
fill 286 100 281 286 100 282 minecraft:gray_concrete
fill 287 100 278 289 100 278 minecraft:gray_concrete
setblock 287 100 282 minecraft:gray_concrete
setblock 289 100 282 minecraft:gray_concrete
setblock 290 100 275 minecraft:sea_lantern
fill 290 100 279 290 100 281 minecraft:gray_concrete
fill 291 100 317 291 108 317 minecraft:iron_block
fill 324 100 280 324 108 280 minecraft:iron_block
fill 290 101 275 290 108 275 minecraft:iron_block
setblock 283 102 278 minecraft:iron_block
setblock 283 102 288 minecraft:iron_block
setblock 283 102 298 minecraft:iron_block
setblock 283 102 308 minecraft:iron_block
setblock 285 102 278 minecraft:light[level=12]
setblock 285 102 285 minecraft:light[level=12]
setblock 285 102 292 minecraft:light[level=12]
setblock 285 102 299 minecraft:light[level=12]
setblock 285 102 306 minecraft:light[level=12]
setblock 285 102 313 minecraft:light[level=12]
setblock 285 102 316 minecraft:iron_block
setblock 289 102 276 minecraft:iron_block
setblock 292 102 278 minecraft:light[level=12]
setblock 292 102 285 minecraft:light[level=12]
setblock 292 102 292 minecraft:light[level=12]
setblock 292 102 299 minecraft:light[level=12]
setblock 292 102 306 minecraft:light[level=12]
setblock 292 102 313 minecraft:light[level=12]
fill 294 102 281 294 120 281 minecraft:iron_block
setblock 295 102 316 minecraft:iron_block
setblock 299 102 276 minecraft:iron_block
setblock 299 102 278 minecraft:light[level=12]
setblock 299 102 285 minecraft:light[level=12]
setblock 299 102 292 minecraft:light[level=12]
setblock 299 102 299 minecraft:light[level=12]
setblock 299 102 306 minecraft:light[level=12]
setblock 299 102 313 minecraft:light[level=12]
setblock 305 102 316 minecraft:iron_block
setblock 306 102 278 minecraft:light[level=12]
setblock 306 102 285 minecraft:light[level=12]
setblock 306 102 292 minecraft:light[level=12]
setblock 306 102 299 minecraft:light[level=12]
setblock 306 102 306 minecraft:light[level=12]
setblock 306 102 313 minecraft:light[level=12]
setblock 309 102 276 minecraft:iron_block
fill 312 102 278 312 102 280 minecraft:iron_block
fill 313 102 277 315 102 277 minecraft:iron_block
fill 313 102 281 315 102 281 minecraft:iron_block
setblock 313 102 285 minecraft:light[level=12]
setblock 313 102 292 minecraft:light[level=12]
setblock 313 102 299 minecraft:light[level=12]
setblock 313 102 306 minecraft:light[level=12]
setblock 313 102 313 minecraft:light[level=12]
setblock 315 102 316 minecraft:iron_block
fill 316 102 278 316 102 280 minecraft:iron_block
setblock 319 102 276 minecraft:iron_block
setblock 320 102 278 minecraft:light[level=12]
setblock 320 102 285 minecraft:light[level=12]
setblock 320 102 292 minecraft:light[level=12]
setblock 320 102 299 minecraft:light[level=12]
setblock 320 102 306 minecraft:light[level=12]
setblock 320 102 313 minecraft:light[level=12]
setblock 323 102 282 minecraft:iron_block
setblock 323 102 292 minecraft:iron_block
setblock 323 102 302 minecraft:iron_block
setblock 323 102 312 minecraft:iron_block
fill 282 103 281 282 103 284 minecraft:pearlescent_froglight
fill 282 103 291 282 103 294 minecraft:pearlescent_froglight
fill 282 103 295 282 108 296 minecraft:iron_block
setblock 282 103 297 minecraft:redstone_block
fill 282 103 298 282 108 300 minecraft:iron_block
fill 282 103 301 282 103 304 minecraft:pearlescent_froglight
fill 282 103 305 282 108 305 minecraft:iron_block
setblock 282 103 306 minecraft:redstone_block
fill 282 103 307 282 108 309 minecraft:iron_block
fill 282 103 311 282 103 314 minecraft:pearlescent_froglight
fill 285 103 275 288 103 275 minecraft:pearlescent_froglight
fill 286 103 317 289 103 317 minecraft:pearlescent_froglight
fill 295 103 275 298 103 275 minecraft:pearlescent_froglight
fill 296 103 317 299 103 317 minecraft:pearlescent_froglight
fill 298 103 278 298 103 280 minecraft:iron_block
fill 299 103 275 299 108 275 minecraft:iron_block
fill 299 103 278 300 103 278 minecraft:iron_block
fill 299 103 280 300 103 280 minecraft:iron_block
setblock 300 103 275 minecraft:redstone_block
setblock 300 103 279 minecraft:iron_block
fill 305 103 275 308 103 275 minecraft:pearlescent_froglight
fill 306 103 317 309 103 317 minecraft:pearlescent_froglight
setblock 313 103 275 minecraft:sea_lantern
fill 315 103 275 318 103 275 minecraft:pearlescent_froglight
fill 316 103 317 319 103 317 minecraft:pearlescent_froglight
fill 324 103 276 324 103 279 minecraft:pearlescent_froglight
fill 324 103 286 324 103 289 minecraft:pearlescent_froglight
fill 324 103 290 324 108 290 minecraft:iron_block
fill 324 103 296 324 103 299 minecraft:pearlescent_froglight
fill 324 103 300 324 108 300 minecraft:iron_block
setblock 324 103 301 minecraft:sea_lantern
fill 324 103 302 324 108 305 minecraft:iron_block
fill 324 103 306 324 103 309 minecraft:pearlescent_froglight
setblock 324 103 316 minecraft:pearlescent_froglight
fill 282 104 281 282 108 284 minecraft:iron_block
fill 282 104 291 282 104 294 minecraft:iron_block
fill 282 104 297 282 108 297 minecraft:iron_block
fill 282 104 301 282 108 304 minecraft:iron_block
fill 282 104 306 282 108 306 minecraft:iron_block
fill 282 104 311 282 108 315 minecraft:iron_block
setblock 282 104 316 minecraft:sea_lantern
fill 282 104 317 282 108 317 minecraft:iron_block
fill 285 104 275 288 108 275 minecraft:iron_block
setblock 285 104 278 minecraft:light[level=15]
setblock 285 104 286 minecraft:light[level=15]
setblock 285 104 294 minecraft:light[level=15]
setblock 285 104 302 minecraft:light[level=15]
setblock 285 104 310 minecraft:light[level=15]
fill 286 104 317 289 108 317 minecraft:iron_block
setblock 293 104 278 minecraft:light[level=15]
setblock 293 104 286 minecraft:light[level=15]
setblock 293 104 294 minecraft:light[level=15]
setblock 293 104 302 minecraft:light[level=15]
setblock 293 104 310 minecraft:light[level=15]
fill 295 104 275 298 108 275 minecraft:iron_block
fill 296 104 317 299 108 317 minecraft:iron_block
fill 300 104 275 300 108 275 minecraft:iron_block
setblock 301 104 278 minecraft:light[level=15]
setblock 301 104 286 minecraft:light[level=15]
setblock 301 104 294 minecraft:light[level=15]
setblock 301 104 302 minecraft:light[level=15]
setblock 301 104 310 minecraft:light[level=15]
fill 305 104 275 308 108 275 minecraft:iron_block
fill 306 104 317 309 108 317 minecraft:iron_block
setblock 309 104 278 minecraft:light[level=15]
setblock 309 104 286 minecraft:light[level=15]
setblock 309 104 294 minecraft:light[level=15]
setblock 309 104 302 minecraft:light[level=15]
setblock 309 104 310 minecraft:light[level=15]
fill 313 104 275 313 108 275 minecraft:iron_block
fill 315 104 275 318 108 275 minecraft:iron_block
fill 316 104 317 319 108 317 minecraft:iron_block
setblock 317 104 278 minecraft:light[level=15]
setblock 317 104 286 minecraft:light[level=15]
setblock 317 104 294 minecraft:light[level=15]
setblock 317 104 302 minecraft:light[level=15]
setblock 317 104 310 minecraft:light[level=15]
fill 324 104 276 324 105 279 minecraft:iron_block
setblock 324 104 281 minecraft:redstone_block
fill 324 104 286 324 108 289 minecraft:iron_block
fill 324 104 296 324 108 299 minecraft:iron_block
fill 324 104 301 324 108 301 minecraft:iron_block
fill 324 104 306 324 105 309 minecraft:iron_block
fill 324 104 316 324 108 316 minecraft:iron_block
fill 282 105 291 282 108 292 minecraft:iron_block
setblock 282 105 293 minecraft:sea_lantern
fill 282 105 294 282 108 294 minecraft:iron_block
fill 282 105 316 282 108 316 minecraft:iron_block
fill 294 105 312 294 114 312 minecraft:iron_block
fill 324 105 281 324 108 281 minecraft:iron_block
fill 282 106 293 282 108 293 minecraft:iron_block
fill 283 106 304 285 107 304 minecraft:iron_block
setblock 324 106 276 minecraft:sea_lantern
fill 324 106 277 324 106 279 minecraft:iron_block
fill 324 106 306 324 108 308 minecraft:iron_block
fill 324 106 309 324 107 309 minecraft:sea_lantern
fill 324 107 276 324 108 278 minecraft:iron_block
setblock 324 107 279 minecraft:sea_lantern
setblock 283 108 278 minecraft:iron_block
fill 283 108 280 283 108 283 minecraft:iron_block
setblock 283 108 288 minecraft:iron_block
fill 283 108 290 283 108 293 minecraft:iron_block
setblock 283 108 298 minecraft:iron_block
fill 283 108 300 283 108 303 minecraft:iron_block
setblock 283 108 308 minecraft:iron_block
fill 283 108 310 283 108 313 minecraft:iron_block
fill 284 108 276 287 108 276 minecraft:iron_block
setblock 285 108 278 minecraft:light[level=12]
setblock 285 108 285 minecraft:light[level=12]
setblock 285 108 292 minecraft:light[level=12]
setblock 285 108 299 minecraft:light[level=12]
setblock 285 108 306 minecraft:light[level=12]
setblock 285 108 313 minecraft:light[level=12]
setblock 285 108 316 minecraft:iron_block
setblock 286 108 279 minecraft:gray_concrete
fill 286 108 281 286 108 282 minecraft:gray_concrete
fill 287 108 278 289 108 278 minecraft:gray_concrete
setblock 287 108 282 minecraft:gray_concrete
fill 287 108 316 290 108 316 minecraft:iron_block
setblock 289 108 276 minecraft:iron_block
setblock 289 108 282 minecraft:gray_concrete
fill 290 108 279 290 108 281 minecraft:gray_concrete
setblock 292 108 278 minecraft:light[level=12]
setblock 292 108 285 minecraft:light[level=12]
setblock 292 108 292 minecraft:light[level=12]
setblock 292 108 299 minecraft:light[level=12]
setblock 292 108 306 minecraft:light[level=12]
setblock 292 108 313 minecraft:light[level=12]
fill 294 108 276 297 108 276 minecraft:iron_block
setblock 295 108 316 minecraft:iron_block
fill 297 108 316 300 108 316 minecraft:iron_block
setblock 299 108 276 minecraft:iron_block
setblock 299 108 278 minecraft:light[level=12]
setblock 299 108 285 minecraft:light[level=12]
setblock 299 108 292 minecraft:light[level=12]
setblock 299 108 299 minecraft:light[level=12]
setblock 299 108 306 minecraft:light[level=12]
setblock 299 108 313 minecraft:light[level=12]
fill 300 108 317 302 108 317 minecraft:iron_block
setblock 303 108 317 minecraft:sea_lantern
fill 304 108 276 307 108 276 minecraft:iron_block
fill 304 108 317 305 108 317 minecraft:iron_block
setblock 305 108 316 minecraft:iron_block
setblock 306 108 278 minecraft:light[level=12]
setblock 306 108 285 minecraft:light[level=12]
setblock 306 108 292 minecraft:light[level=12]
setblock 306 108 299 minecraft:light[level=12]
setblock 306 108 306 minecraft:light[level=12]
setblock 306 108 313 minecraft:light[level=12]
fill 307 108 316 310 108 316 minecraft:iron_block
setblock 309 108 276 minecraft:iron_block
fill 312 108 278 312 108 280 minecraft:iron_block
fill 313 108 277 315 108 277 minecraft:iron_block
fill 313 108 281 315 108 281 minecraft:iron_block
setblock 313 108 285 minecraft:light[level=12]
setblock 313 108 292 minecraft:light[level=12]
setblock 313 108 299 minecraft:light[level=12]
setblock 313 108 306 minecraft:light[level=12]
setblock 313 108 313 minecraft:light[level=12]
fill 314 108 276 317 108 276 minecraft:iron_block
setblock 315 108 316 minecraft:iron_block
fill 316 108 278 316 108 280 minecraft:iron_block
fill 317 108 316 320 108 316 minecraft:iron_block
setblock 319 108 276 minecraft:iron_block
setblock 320 108 278 minecraft:light[level=12]
setblock 320 108 285 minecraft:light[level=12]
setblock 320 108 292 minecraft:light[level=12]
setblock 320 108 299 minecraft:light[level=12]
setblock 320 108 306 minecraft:light[level=12]
setblock 320 108 313 minecraft:light[level=12]
fill 323 108 277 323 108 280 minecraft:iron_block
setblock 323 108 282 minecraft:iron_block
fill 323 108 287 323 108 290 minecraft:iron_block
setblock 323 108 292 minecraft:iron_block
fill 323 108 297 323 108 300 minecraft:iron_block
setblock 323 108 302 minecraft:iron_block
fill 323 108 307 323 108 310 minecraft:iron_block
setblock 323 108 312 minecraft:iron_block
setblock 324 108 279 minecraft:iron_block
setblock 324 108 309 minecraft:iron_block
fill 282 109 275 282 110 276 minecraft:yellow_concrete
fill 282 109 277 282 110 278 minecraft:black_concrete
fill 282 109 279 282 110 280 minecraft:yellow_concrete
fill 282 109 281 282 110 282 minecraft:black_concrete
fill 282 109 283 282 110 284 minecraft:yellow_concrete
fill 282 109 285 282 110 286 minecraft:black_concrete
fill 282 109 287 282 110 288 minecraft:yellow_concrete
fill 282 109 289 282 110 290 minecraft:black_concrete
fill 282 109 291 282 110 292 minecraft:yellow_concrete
fill 282 109 293 282 110 294 minecraft:black_concrete
fill 282 109 295 282 110 296 minecraft:yellow_concrete
fill 282 109 297 282 110 298 minecraft:black_concrete
fill 282 109 299 282 110 300 minecraft:yellow_concrete
fill 282 109 301 282 110 302 minecraft:black_concrete
fill 282 109 303 282 110 304 minecraft:yellow_concrete
fill 282 109 305 282 110 306 minecraft:black_concrete
fill 282 109 307 282 110 308 minecraft:yellow_concrete
fill 282 109 309 282 110 310 minecraft:black_concrete
fill 282 109 311 282 110 312 minecraft:yellow_concrete
fill 282 109 313 282 110 314 minecraft:black_concrete
fill 282 109 315 282 110 316 minecraft:yellow_concrete
fill 282 109 317 282 110 317 minecraft:black_concrete
fill 283 109 275 283 110 275 minecraft:yellow_concrete
fill 283 109 317 283 110 317 minecraft:yellow_concrete
fill 284 109 275 285 110 275 minecraft:black_concrete
fill 284 109 317 285 110 317 minecraft:black_concrete
fill 286 109 275 287 110 275 minecraft:yellow_concrete
fill 286 109 317 287 110 317 minecraft:yellow_concrete
fill 288 109 275 289 110 275 minecraft:black_concrete
fill 288 109 317 289 110 317 minecraft:black_concrete
fill 290 109 275 291 110 275 minecraft:yellow_concrete
fill 290 109 317 291 110 317 minecraft:yellow_concrete
fill 292 109 275 293 110 275 minecraft:black_concrete
fill 292 109 317 293 110 317 minecraft:black_concrete
fill 294 109 275 295 110 275 minecraft:yellow_concrete
fill 294 109 317 295 110 317 minecraft:yellow_concrete
fill 296 109 275 297 110 275 minecraft:black_concrete
fill 296 109 317 297 110 317 minecraft:black_concrete
fill 298 109 275 299 110 275 minecraft:yellow_concrete
fill 298 109 317 299 110 317 minecraft:yellow_concrete
fill 300 109 275 301 110 275 minecraft:black_concrete
fill 300 109 317 301 110 317 minecraft:black_concrete
fill 302 109 275 303 110 275 minecraft:yellow_concrete
fill 302 109 317 303 110 317 minecraft:yellow_concrete
fill 304 109 275 305 110 275 minecraft:black_concrete
fill 304 109 317 305 110 317 minecraft:black_concrete
fill 306 109 275 307 110 275 minecraft:yellow_concrete
fill 306 109 317 307 110 317 minecraft:yellow_concrete
fill 308 109 275 309 110 275 minecraft:black_concrete
fill 308 109 317 309 110 317 minecraft:black_concrete
fill 310 109 275 311 110 275 minecraft:yellow_concrete
fill 310 109 317 311 110 317 minecraft:yellow_concrete
fill 312 109 275 313 110 275 minecraft:black_concrete
fill 312 109 317 313 110 317 minecraft:black_concrete
fill 314 109 275 315 110 275 minecraft:yellow_concrete
fill 314 109 317 315 110 317 minecraft:yellow_concrete
fill 316 109 275 317 110 275 minecraft:black_concrete
fill 316 109 317 317 110 317 minecraft:black_concrete
fill 318 109 275 319 110 275 minecraft:yellow_concrete
fill 318 109 317 319 110 317 minecraft:yellow_concrete
fill 320 109 275 321 110 275 minecraft:black_concrete
fill 320 109 317 321 110 317 minecraft:black_concrete
fill 322 109 275 323 110 275 minecraft:yellow_concrete
fill 322 109 317 323 110 317 minecraft:yellow_concrete
fill 324 109 275 324 110 275 minecraft:black_concrete
fill 324 109 276 324 110 276 minecraft:yellow_concrete
fill 324 109 277 324 110 278 minecraft:black_concrete
fill 324 109 279 324 110 280 minecraft:yellow_concrete
fill 324 109 281 324 110 282 minecraft:black_concrete
fill 324 109 283 324 110 284 minecraft:yellow_concrete
fill 324 109 285 324 110 286 minecraft:black_concrete
fill 324 109 287 324 110 288 minecraft:yellow_concrete
fill 324 109 289 324 110 290 minecraft:black_concrete
fill 324 109 291 324 110 292 minecraft:yellow_concrete
fill 324 109 293 324 110 294 minecraft:black_concrete
fill 324 109 295 324 110 296 minecraft:yellow_concrete
fill 324 109 297 324 110 298 minecraft:black_concrete
fill 324 109 299 324 110 300 minecraft:yellow_concrete
fill 324 109 301 324 110 302 minecraft:black_concrete
fill 324 109 303 324 110 304 minecraft:yellow_concrete
fill 324 109 305 324 110 306 minecraft:black_concrete
fill 324 109 307 324 110 308 minecraft:yellow_concrete
fill 324 109 309 324 110 310 minecraft:black_concrete
fill 324 109 311 324 110 312 minecraft:yellow_concrete
fill 324 109 313 324 110 314 minecraft:black_concrete
fill 324 109 315 324 110 316 minecraft:yellow_concrete
fill 324 109 317 324 110 317 minecraft:black_concrete
fill 298 110 278 298 110 280 minecraft:iron_block
fill 299 110 278 300 110 278 minecraft:iron_block
fill 299 110 280 300 110 280 minecraft:iron_block
setblock 300 110 279 minecraft:iron_block
fill 282 111 275 282 111 317 minecraft:iron_block
fill 283 111 275 318 111 275 minecraft:iron_block
fill 283 111 317 324 111 317 minecraft:iron_block
setblock 319 111 275 minecraft:sea_lantern
fill 320 111 275 324 129 275 minecraft:iron_block
fill 324 111 276 324 111 316 minecraft:iron_block
fill 282 112 275 282 130 280 minecraft:iron_block
fill 282 112 281 282 112 284 minecraft:pearlescent_froglight
fill 282 112 285 282 129 290 minecraft:iron_block
fill 282 112 291 282 112 294 minecraft:pearlescent_froglight
fill 282 112 295 282 114 300 minecraft:iron_block
fill 282 112 301 282 112 304 minecraft:pearlescent_froglight
fill 282 112 305 282 133 305 minecraft:iron_block
setblock 282 112 306 minecraft:redstone_block
fill 282 112 307 282 133 310 minecraft:iron_block
fill 282 112 311 282 112 314 minecraft:pearlescent_froglight
fill 282 112 315 282 133 317 minecraft:iron_block
fill 283 112 275 284 131 275 minecraft:iron_block
fill 283 112 317 285 113 317 minecraft:iron_block
fill 285 112 275 288 112 275 minecraft:pearlescent_froglight
setblock 285 112 278 minecraft:light[level=15]
setblock 285 112 286 minecraft:light[level=15]
setblock 285 112 294 minecraft:light[level=15]
setblock 285 112 302 minecraft:light[level=15]
setblock 285 112 310 minecraft:light[level=15]
fill 286 112 317 289 112 317 minecraft:pearlescent_froglight
fill 289 112 275 294 113 275 minecraft:iron_block
fill 290 112 317 295 129 317 minecraft:iron_block
setblock 293 112 278 minecraft:light[level=15]
setblock 293 112 286 minecraft:light[level=15]
setblock 293 112 294 minecraft:light[level=15]
setblock 293 112 302 minecraft:light[level=15]
setblock 293 112 310 minecraft:light[level=15]
fill 295 112 275 298 112 275 minecraft:pearlescent_froglight
fill 296 112 317 299 112 317 minecraft:pearlescent_froglight
fill 299 112 275 304 129 275 minecraft:iron_block
fill 300 112 317 305 119 317 minecraft:iron_block
setblock 301 112 278 minecraft:light[level=15]
setblock 301 112 286 minecraft:light[level=15]
setblock 301 112 294 minecraft:light[level=15]
setblock 301 112 302 minecraft:light[level=15]
setblock 301 112 310 minecraft:light[level=15]
fill 305 112 275 308 112 275 minecraft:pearlescent_froglight
fill 306 112 317 309 112 317 minecraft:pearlescent_froglight
fill 309 112 275 314 130 275 minecraft:iron_block
setblock 309 112 278 minecraft:light[level=15]
setblock 309 112 286 minecraft:light[level=15]
setblock 309 112 294 minecraft:light[level=15]
setblock 309 112 302 minecraft:light[level=15]
setblock 309 112 310 minecraft:light[level=15]
fill 310 112 317 315 115 317 minecraft:iron_block
fill 315 112 275 318 112 275 minecraft:pearlescent_froglight
fill 316 112 317 319 112 317 minecraft:pearlescent_froglight
setblock 317 112 278 minecraft:light[level=15]
setblock 317 112 286 minecraft:light[level=15]
setblock 317 112 294 minecraft:light[level=15]
setblock 317 112 302 minecraft:light[level=15]
setblock 317 112 310 minecraft:light[level=15]
fill 319 112 275 319 133 275 minecraft:iron_block
fill 320 112 317 324 126 317 minecraft:iron_block
fill 324 112 276 324 112 279 minecraft:pearlescent_froglight
fill 324 112 280 324 130 285 minecraft:iron_block
fill 324 112 286 324 112 289 minecraft:pearlescent_froglight
fill 324 112 290 324 115 295 minecraft:iron_block
fill 324 112 296 324 112 299 minecraft:pearlescent_froglight
fill 324 112 300 324 119 305 minecraft:iron_block
fill 324 112 306 324 112 309 minecraft:pearlescent_froglight
fill 324 112 310 324 117 315 minecraft:iron_block
setblock 324 112 316 minecraft:pearlescent_froglight
fill 282 113 281 282 120 284 minecraft:iron_block
fill 282 113 291 282 120 294 minecraft:iron_block
fill 282 113 301 282 120 304 minecraft:iron_block
fill 282 113 306 282 133 306 minecraft:iron_block
fill 282 113 311 282 120 314 minecraft:iron_block
fill 285 113 275 288 120 275 minecraft:iron_block
fill 286 113 317 289 120 317 minecraft:iron_block
fill 295 113 275 298 115 275 minecraft:iron_block
fill 296 113 317 299 120 317 minecraft:iron_block
fill 305 113 275 308 120 275 minecraft:iron_block
fill 306 113 317 309 120 317 minecraft:iron_block
fill 315 113 275 318 120 275 minecraft:iron_block
fill 316 113 317 319 114 317 minecraft:iron_block
fill 324 113 276 324 120 279 minecraft:iron_block
fill 324 113 286 324 120 289 minecraft:iron_block
fill 324 113 296 324 120 298 minecraft:iron_block
setblock 324 113 299 minecraft:sea_lantern
fill 324 113 306 324 119 309 minecraft:iron_block
fill 324 113 316 324 120 316 minecraft:iron_block
setblock 283 114 278 minecraft:iron_block
setblock 283 114 288 minecraft:iron_block
setblock 283 114 298 minecraft:iron_block
fill 283 114 306 289 114 306 minecraft:gray_concrete
setblock 283 114 308 minecraft:iron_block
fill 283 114 317 284 133 317 minecraft:iron_block
setblock 285 114 278 minecraft:light[level=12]
setblock 285 114 285 minecraft:light[level=12]
setblock 285 114 292 minecraft:light[level=12]
setblock 285 114 299 minecraft:light[level=12]
fill 285 114 304 289 115 305 minecraft:gray_concrete
fill 285 114 307 289 115 308 minecraft:gray_concrete
setblock 285 114 313 minecraft:light[level=12]
setblock 285 114 316 minecraft:iron_block
setblock 285 114 317 minecraft:sea_lantern
fill 289 114 275 289 114 276 minecraft:iron_block
fill 290 114 275 290 128 275 minecraft:iron_block
setblock 291 114 275 minecraft:sea_lantern
fill 292 114 275 294 130 275 minecraft:iron_block
setblock 292 114 278 minecraft:light[level=12]
setblock 292 114 285 minecraft:light[level=12]
setblock 292 114 292 minecraft:light[level=12]
setblock 292 114 299 minecraft:light[level=12]
setblock 292 114 306 minecraft:light[level=12]
setblock 292 114 313 minecraft:light[level=12]
setblock 295 114 316 minecraft:iron_block
setblock 299 114 276 minecraft:iron_block
setblock 299 114 278 minecraft:light[level=12]
setblock 299 114 285 minecraft:light[level=12]
setblock 299 114 292 minecraft:light[level=12]
setblock 299 114 299 minecraft:light[level=12]
setblock 299 114 306 minecraft:light[level=12]
setblock 299 114 313 minecraft:light[level=12]
setblock 305 114 316 minecraft:iron_block
setblock 306 114 278 minecraft:light[level=12]
setblock 306 114 285 minecraft:light[level=12]
setblock 306 114 292 minecraft:light[level=12]
setblock 306 114 299 minecraft:light[level=12]
setblock 306 114 306 minecraft:light[level=12]
setblock 306 114 313 minecraft:light[level=12]
setblock 309 114 276 minecraft:iron_block
fill 312 114 278 312 114 280 minecraft:iron_block
fill 313 114 277 315 114 277 minecraft:iron_block
fill 313 114 281 315 114 281 minecraft:iron_block
setblock 313 114 285 minecraft:light[level=12]
setblock 313 114 292 minecraft:light[level=12]
setblock 313 114 299 minecraft:light[level=12]
setblock 313 114 306 minecraft:light[level=12]
setblock 313 114 313 minecraft:light[level=12]
setblock 315 114 316 minecraft:iron_block
fill 316 114 278 316 114 280 minecraft:iron_block
setblock 319 114 276 minecraft:iron_block
setblock 320 114 278 minecraft:light[level=12]
setblock 320 114 285 minecraft:light[level=12]
setblock 320 114 292 minecraft:light[level=12]
setblock 320 114 299 minecraft:light[level=12]
setblock 320 114 306 minecraft:light[level=12]
setblock 320 114 313 minecraft:light[level=12]
setblock 323 114 282 minecraft:iron_block
setblock 323 114 292 minecraft:iron_block
setblock 323 114 302 minecraft:iron_block
setblock 323 114 312 minecraft:iron_block
fill 324 114 299 324 120 299 minecraft:iron_block
fill 282 115 295 282 131 296 minecraft:iron_block
setblock 282 115 297 minecraft:redstone_block
fill 282 115 298 282 132 300 minecraft:iron_block
fill 285 115 306 289 115 306 minecraft:gray_concrete
fill 285 115 317 285 133 317 minecraft:iron_block
fill 289 115 275 289 133 275 minecraft:iron_block
fill 291 115 275 291 126 275 minecraft:iron_block
fill 316 115 317 317 120 317 minecraft:iron_block
setblock 318 115 317 minecraft:redstone_block
fill 319 115 317 319 120 317 minecraft:iron_block
fill 282 116 297 282 133 297 minecraft:iron_block
setblock 286 116 279 minecraft:gray_concrete
fill 286 116 281 286 116 283 minecraft:gray_concrete
fill 286 116 311 286 117 311 minecraft:gray_concrete
fill 287 116 278 289 116 278 minecraft:gray_concrete
setblock 287 116 282 minecraft:gray_concrete
setblock 289 116 282 minecraft:gray_concrete
fill 290 116 279 290 116 281 minecraft:gray_concrete
fill 295 116 275 297 120 275 minecraft:iron_block
setblock 298 116 275 minecraft:sea_lantern
fill 310 116 317 312 119 317 minecraft:iron_block
fill 312 116 279 312 117 279 minecraft:gray_concrete
setblock 313 116 317 minecraft:redstone_block
fill 314 116 317 315 131 317 minecraft:iron_block
fill 316 116 279 316 117 279 minecraft:gray_concrete
fill 318 116 317 318 120 317 minecraft:iron_block
fill 319 116 308 319 117 308 minecraft:gray_concrete
fill 319 116 312 319 117 312 minecraft:gray_concrete
fill 324 116 290 324 133 291 minecraft:iron_block
setblock 324 116 292 minecraft:sea_lantern
fill 324 116 293 324 129 295 minecraft:iron_block
fill 283 117 280 283 117 283 minecraft:iron_block
fill 283 117 290 283 117 293 minecraft:iron_block
fill 283 117 300 283 117 303 minecraft:iron_block
fill 283 117 310 283 117 313 minecraft:iron_block
fill 284 117 276 287 117 276 minecraft:iron_block
fill 285 117 283 286 117 283 minecraft:gray_concrete
fill 285 117 311 285 118 311 minecraft:gray_concrete
fill 287 117 316 290 117 316 minecraft:iron_block
fill 294 117 276 297 117 276 minecraft:iron_block
fill 297 117 316 300 117 316 minecraft:iron_block
fill 298 117 275 298 120 275 minecraft:iron_block
fill 298 117 278 298 117 280 minecraft:iron_block
fill 299 117 278 300 117 278 minecraft:iron_block
fill 299 117 280 300 117 280 minecraft:iron_block
setblock 300 117 279 minecraft:iron_block
fill 304 117 276 307 117 276 minecraft:iron_block
fill 307 117 316 310 117 316 minecraft:iron_block
fill 312 117 278 312 118 278 minecraft:gray_concrete
fill 313 117 317 313 133 317 minecraft:iron_block
fill 314 117 276 317 117 276 minecraft:iron_block
fill 316 117 278 316 118 278 minecraft:gray_concrete
fill 317 117 316 320 117 316 minecraft:iron_block
fill 320 117 308 320 118 308 minecraft:gray_concrete
fill 320 117 312 320 118 312 minecraft:gray_concrete
fill 323 117 277 323 117 280 minecraft:iron_block
fill 323 117 287 323 117 290 minecraft:iron_block
fill 323 117 297 323 117 300 minecraft:iron_block
fill 323 117 307 323 117 310 minecraft:iron_block
fill 324 117 292 324 129 292 minecraft:iron_block
fill 284 118 283 285 118 283 minecraft:gray_concrete
fill 284 118 311 284 119 311 minecraft:gray_concrete
fill 312 118 277 312 119 277 minecraft:gray_concrete
fill 316 118 277 316 119 277 minecraft:gray_concrete
fill 321 118 308 321 119 308 minecraft:gray_concrete
fill 321 118 312 321 119 312 minecraft:gray_concrete
fill 324 118 310 324 133 314 minecraft:iron_block
setblock 324 118 315 minecraft:sea_lantern
fill 283 119 283 284 119 283 minecraft:gray_concrete
fill 283 119 311 283 120 311 minecraft:gray_concrete
fill 284 119 304 284 120 308 minecraft:iron_block
fill 285 119 303 285 121 304 minecraft:iron_block
fill 285 119 306 290 120 306 minecraft:iron_block
fill 285 119 308 285 120 309 minecraft:iron_block
fill 286 119 303 289 120 303 minecraft:iron_block
fill 286 119 309 289 120 309 minecraft:iron_block
fill 287 119 304 287 120 305 minecraft:iron_block
fill 287 119 307 287 120 308 minecraft:iron_block
fill 289 119 304 290 120 304 minecraft:iron_block
fill 289 119 308 290 120 308 minecraft:iron_block
fill 290 119 305 290 120 305 minecraft:iron_block
fill 290 119 307 290 120 307 minecraft:iron_block
fill 312 119 276 312 120 276 minecraft:gray_concrete
fill 316 119 276 316 120 276 minecraft:gray_concrete
fill 322 119 308 322 120 308 minecraft:gray_concrete
fill 322 119 312 322 120 312 minecraft:gray_concrete
fill 324 119 315 324 129 315 minecraft:iron_block
fill 283 120 278 283 121 278 minecraft:iron_block
setblock 283 120 283 minecraft:gray_concrete
fill 283 120 288 283 121 288 minecraft:iron_block
setblock 283 120 298 minecraft:iron_block
fill 283 120 308 283 121 308 minecraft:iron_block
setblock 285 120 278 minecraft:light[level=15]
setblock 285 120 285 minecraft:light[level=12]
setblock 285 120 286 minecraft:light[level=15]
setblock 285 120 292 minecraft:light[level=12]
setblock 285 120 294 minecraft:light[level=15]
setblock 285 120 299 minecraft:light[level=12]
setblock 285 120 302 minecraft:light[level=15]
fill 285 120 305 286 120 305 minecraft:gray_concrete
setblock 285 120 307 minecraft:gray_concrete
setblock 285 120 310 minecraft:light[level=15]
setblock 285 120 313 minecraft:light[level=12]
fill 285 120 316 285 121 316 minecraft:iron_block
setblock 286 120 283 minecraft:pearlescent_froglight
setblock 286 120 289 minecraft:pearlescent_froglight
setblock 286 120 295 minecraft:pearlescent_froglight
setblock 286 120 301 minecraft:pearlescent_froglight
setblock 286 120 307 minecraft:pearlescent_froglight
setblock 286 120 308 minecraft:gray_concrete
setblock 286 120 313 minecraft:pearlescent_froglight
fill 288 120 305 289 121 305 minecraft:gray_concrete
fill 288 120 307 288 121 308 minecraft:gray_concrete
fill 289 120 276 289 121 276 minecraft:iron_block
fill 289 120 307 289 121 307 minecraft:gray_concrete
setblock 290 120 279 minecraft:pearlescent_froglight
setblock 292 120 278 minecraft:light[level=12]
setblock 292 120 285 minecraft:light[level=12]
setblock 292 120 292 minecraft:light[level=12]
setblock 292 120 299 minecraft:light[level=12]
setblock 292 120 306 minecraft:light[level=12]
setblock 292 120 313 minecraft:pearlescent_froglight
setblock 293 120 278 minecraft:light[level=15]
setblock 293 120 286 minecraft:light[level=15]
setblock 293 120 294 minecraft:light[level=15]
setblock 293 120 302 minecraft:light[level=15]
setblock 293 120 310 minecraft:light[level=15]
setblock 295 120 316 minecraft:iron_block
setblock 296 120 279 minecraft:pearlescent_froglight
setblock 298 120 313 minecraft:pearlescent_froglight
setblock 299 120 276 minecraft:iron_block
setblock 299 120 278 minecraft:light[level=12]
setblock 299 120 285 minecraft:light[level=12]
setblock 299 120 292 minecraft:light[level=12]
setblock 299 120 299 minecraft:light[level=12]
setblock 299 120 306 minecraft:light[level=12]
setblock 299 120 313 minecraft:light[level=12]
fill 300 120 317 300 133 317 minecraft:iron_block
setblock 301 120 278 minecraft:light[level=15]
setblock 301 120 286 minecraft:light[level=15]
setblock 301 120 294 minecraft:light[level=15]
setblock 301 120 302 minecraft:light[level=15]
setblock 301 120 310 minecraft:light[level=15]
setblock 301 120 317 minecraft:sea_lantern
setblock 302 120 279 minecraft:pearlescent_froglight
fill 302 120 317 305 128 317 minecraft:iron_block
setblock 304 120 313 minecraft:pearlescent_froglight
fill 305 120 316 305 121 316 minecraft:iron_block
setblock 306 120 278 minecraft:light[level=12]
setblock 306 120 285 minecraft:light[level=12]
setblock 306 120 292 minecraft:light[level=12]
setblock 306 120 299 minecraft:light[level=12]
setblock 306 120 306 minecraft:light[level=12]
setblock 306 120 313 minecraft:light[level=12]
setblock 308 120 279 minecraft:pearlescent_froglight
fill 309 120 276 309 121 276 minecraft:iron_block
setblock 309 120 278 minecraft:light[level=15]
setblock 309 120 286 minecraft:light[level=15]
setblock 309 120 294 minecraft:light[level=15]
setblock 309 120 302 minecraft:light[level=15]
setblock 309 120 310 minecraft:light[level=15]
setblock 310 120 313 minecraft:pearlescent_froglight
setblock 310 120 317 minecraft:sea_lantern
fill 311 120 317 312 133 317 minecraft:iron_block
fill 312 120 278 313 120 280 minecraft:iron_block
fill 313 120 277 315 120 277 minecraft:iron_block
fill 313 120 281 315 120 281 minecraft:iron_block
setblock 313 120 285 minecraft:light[level=12]
setblock 313 120 292 minecraft:light[level=12]
setblock 313 120 299 minecraft:light[level=12]
setblock 313 120 306 minecraft:light[level=12]
setblock 313 120 313 minecraft:light[level=12]
fill 314 120 278 316 121 278 minecraft:iron_block
setblock 314 120 279 minecraft:pearlescent_froglight
fill 314 120 280 316 120 280 minecraft:iron_block
fill 315 120 279 316 121 279 minecraft:iron_block
fill 315 120 316 315 121 316 minecraft:iron_block
setblock 316 120 313 minecraft:pearlescent_froglight
setblock 317 120 278 minecraft:light[level=15]
setblock 317 120 286 minecraft:light[level=15]
setblock 317 120 294 minecraft:light[level=15]
setblock 317 120 302 minecraft:light[level=15]
setblock 317 120 310 minecraft:light[level=15]
fill 319 120 276 319 121 276 minecraft:iron_block
setblock 320 120 278 minecraft:light[level=12]
setblock 320 120 279 minecraft:pearlescent_froglight
setblock 320 120 285 minecraft:pearlescent_froglight
setblock 320 120 291 minecraft:pearlescent_froglight
setblock 320 120 292 minecraft:light[level=12]
setblock 320 120 297 minecraft:pearlescent_froglight
setblock 320 120 299 minecraft:light[level=12]
setblock 320 120 303 minecraft:pearlescent_froglight
setblock 320 120 306 minecraft:light[level=12]
setblock 320 120 309 minecraft:pearlescent_froglight
setblock 320 120 313 minecraft:light[level=12]
setblock 323 120 282 minecraft:iron_block
fill 323 120 292 323 121 292 minecraft:iron_block
fill 323 120 302 324 121 302 minecraft:iron_block
setblock 323 120 312 minecraft:iron_block
fill 324 120 300 324 131 301 minecraft:iron_block
fill 324 120 303 324 133 303 minecraft:iron_block
setblock 324 120 304 minecraft:redstone_block
fill 324 120 305 324 120 307 minecraft:iron_block
setblock 324 120 308 minecraft:redstone_block
setblock 324 120 309 minecraft:iron_block
fill 282 121 281 282 121 284 minecraft:pearlescent_froglight
fill 282 121 291 282 121 294 minecraft:pearlescent_froglight
fill 282 121 301 282 121 304 minecraft:pearlescent_froglight
fill 282 121 311 282 121 314 minecraft:pearlescent_froglight
setblock 283 121 276 minecraft:iron_block
setblock 283 121 279 minecraft:iron_block
fill 283 121 281 283 121 282 minecraft:iron_block
fill 283 121 284 283 121 285 minecraft:iron_block
fill 283 121 290 283 121 291 minecraft:iron_block
fill 283 121 293 283 121 294 minecraft:iron_block
fill 283 121 296 284 121 296 minecraft:iron_block
fill 283 121 299 283 121 300 minecraft:iron_block
fill 283 121 302 283 121 303 minecraft:iron_block
fill 283 121 305 283 121 306 minecraft:iron_block
setblock 283 121 309 minecraft:iron_block
fill 283 121 311 283 121 312 minecraft:iron_block
fill 283 121 314 283 121 315 minecraft:iron_block
fill 284 121 277 284 121 278 minecraft:iron_block
fill 284 121 280 284 121 281 minecraft:iron_block
fill 284 121 283 284 121 284 minecraft:iron_block
fill 284 121 286 284 121 287 minecraft:iron_block
fill 284 121 289 284 121 290 minecraft:iron_block
fill 284 121 292 284 121 293 minecraft:iron_block
fill 284 121 295 285 121 295 minecraft:iron_block
fill 284 121 298 284 121 299 minecraft:iron_block
fill 284 121 301 284 121 302 minecraft:iron_block
fill 284 121 304 284 121 305 minecraft:iron_block
fill 284 121 307 284 121 308 minecraft:iron_block
fill 284 121 310 284 121 311 minecraft:iron_block
fill 284 121 313 284 121 314 minecraft:iron_block
fill 285 121 275 288 121 275 minecraft:pearlescent_froglight
fill 285 121 276 285 121 277 minecraft:iron_block
fill 285 121 279 285 121 280 minecraft:iron_block
fill 285 121 282 285 121 283 minecraft:iron_block
fill 285 121 285 285 121 286 minecraft:iron_block
fill 285 121 288 285 121 289 minecraft:iron_block
fill 285 121 291 285 121 292 minecraft:iron_block
fill 285 121 294 286 121 294 minecraft:iron_block
fill 285 121 297 285 121 298 minecraft:iron_block
fill 285 121 300 285 121 301 minecraft:iron_block
setblock 285 121 305 minecraft:gray_concrete
fill 285 121 306 285 121 307 minecraft:iron_block
setblock 285 121 308 minecraft:gray_concrete
fill 285 121 309 285 121 310 minecraft:iron_block
fill 285 121 312 285 121 313 minecraft:iron_block
fill 285 121 315 286 121 315 minecraft:iron_block
setblock 286 121 276 minecraft:iron_block
fill 286 121 278 286 121 279 minecraft:iron_block
fill 286 121 281 286 121 282 minecraft:iron_block
fill 286 121 284 286 121 285 minecraft:iron_block
fill 286 121 287 286 121 288 minecraft:iron_block
fill 286 121 290 286 121 291 minecraft:iron_block
setblock 286 121 293 minecraft:iron_block
fill 286 121 296 286 121 297 minecraft:iron_block
fill 286 121 299 286 121 300 minecraft:iron_block
fill 286 121 302 286 121 303 minecraft:iron_block
fill 286 121 305 286 121 306 minecraft:iron_block
fill 286 121 307 287 121 307 minecraft:gray_concrete
fill 286 121 308 286 121 309 minecraft:iron_block
fill 286 121 311 286 121 312 minecraft:iron_block
fill 286 121 314 287 121 314 minecraft:iron_block
fill 286 121 317 289 121 317 minecraft:pearlescent_froglight
fill 287 121 277 287 121 278 minecraft:iron_block
fill 287 121 305 287 121 306 minecraft:gray_concrete
fill 287 121 308 287 121 309 minecraft:gray_concrete
fill 287 121 313 288 121 313 minecraft:iron_block
fill 287 121 316 288 121 316 minecraft:iron_block
fill 288 121 276 288 121 277 minecraft:iron_block
fill 288 121 306 289 121 306 minecraft:gray_concrete
fill 288 121 309 289 121 309 minecraft:gray_concrete
fill 288 121 315 289 121 315 minecraft:iron_block
fill 289 121 278 290 121 278 minecraft:iron_block
setblock 289 121 308 minecraft:gray_concrete
fill 289 121 314 290 121 314 minecraft:iron_block
fill 290 121 277 291 121 277 minecraft:iron_block
fill 290 121 313 291 121 313 minecraft:iron_block
fill 290 121 316 291 121 316 minecraft:iron_block
fill 291 121 276 292 121 276 minecraft:iron_block
fill 291 121 279 292 121 279 minecraft:iron_block
fill 291 121 315 292 121 315 minecraft:iron_block
fill 292 121 278 293 121 278 minecraft:iron_block
fill 292 121 314 293 121 314 minecraft:iron_block
fill 293 121 277 294 121 277 minecraft:iron_block
fill 293 121 313 294 121 313 minecraft:iron_block
setblock 293 121 316 minecraft:iron_block
fill 294 121 276 295 121 276 minecraft:iron_block
fill 294 121 279 295 121 279 minecraft:iron_block
fill 294 121 315 295 121 315 minecraft:iron_block
fill 295 121 275 298 121 275 minecraft:pearlescent_froglight
fill 295 121 278 296 121 278 minecraft:iron_block
fill 295 121 314 296 121 314 minecraft:iron_block
fill 296 121 277 297 121 277 minecraft:iron_block
fill 296 121 313 297 121 313 minecraft:iron_block
fill 296 121 316 297 121 316 minecraft:iron_block
fill 296 121 317 299 121 317 minecraft:pearlescent_froglight
fill 297 121 276 298 121 276 minecraft:iron_block
fill 297 121 279 298 121 279 minecraft:iron_block
fill 297 121 315 298 121 315 minecraft:iron_block
fill 298 121 278 299 121 278 minecraft:iron_block
fill 298 121 314 299 121 314 minecraft:iron_block
fill 299 121 277 300 121 277 minecraft:iron_block
fill 299 121 313 300 121 313 minecraft:iron_block
fill 299 121 316 300 121 316 minecraft:iron_block
fill 300 121 279 301 121 279 minecraft:iron_block
fill 300 121 315 301 121 315 minecraft:iron_block
setblock 301 121 276 minecraft:iron_block
fill 301 121 278 302 121 278 minecraft:iron_block
fill 301 121 314 302 121 314 minecraft:iron_block
fill 301 121 317 301 133 317 minecraft:iron_block
fill 302 121 277 303 121 277 minecraft:iron_block
fill 302 121 313 303 121 313 minecraft:iron_block
fill 302 121 316 303 121 316 minecraft:iron_block
fill 303 121 276 304 121 276 minecraft:iron_block
fill 303 121 279 304 121 279 minecraft:iron_block
fill 303 121 315 304 121 315 minecraft:iron_block
fill 304 121 278 305 121 278 minecraft:iron_block
fill 304 121 314 305 121 314 minecraft:iron_block
fill 305 121 275 308 121 275 minecraft:pearlescent_froglight
fill 305 121 277 306 121 277 minecraft:iron_block
fill 305 121 313 306 121 313 minecraft:iron_block
fill 306 121 276 307 121 276 minecraft:iron_block
fill 306 121 279 307 121 279 minecraft:iron_block
fill 306 121 315 306 121 316 minecraft:iron_block
fill 306 121 317 309 121 317 minecraft:pearlescent_froglight
fill 307 121 278 308 121 278 minecraft:iron_block
fill 307 121 314 307 121 315 minecraft:iron_block
fill 308 121 277 309 121 277 minecraft:iron_block
fill 308 121 313 308 121 314 minecraft:iron_block
fill 308 121 316 309 121 316 minecraft:iron_block
fill 309 121 279 310 121 279 minecraft:iron_block
setblock 309 121 313 minecraft:iron_block
fill 309 121 315 310 121 315 minecraft:iron_block
fill 310 121 278 311 121 278 minecraft:iron_block
fill 310 121 314 311 121 314 minecraft:iron_block
fill 310 121 317 310 134 317 minecraft:iron_block
fill 311 121 277 312 121 277 minecraft:iron_block
fill 311 121 313 312 121 313 minecraft:iron_block
fill 311 121 316 312 121 316 minecraft:iron_block
fill 312 121 276 313 121 276 minecraft:iron_block
fill 312 121 279 314 121 279 minecraft:iron_block
fill 312 121 315 313 121 315 minecraft:iron_block
fill 313 121 278 313 127 278 minecraft:iron_block
fill 313 121 280 315 127 280 minecraft:iron_block
fill 313 121 314 314 121 314 minecraft:iron_block
fill 314 121 277 315 121 277 minecraft:iron_block
fill 314 121 313 315 121 313 minecraft:iron_block
fill 315 121 275 318 121 275 minecraft:pearlescent_froglight
fill 315 121 276 316 121 276 minecraft:iron_block
fill 315 121 315 316 121 315 minecraft:iron_block
fill 316 121 314 317 121 314 minecraft:iron_block
fill 316 121 317 319 121 317 minecraft:pearlescent_froglight
fill 317 121 277 317 121 278 minecraft:iron_block
fill 317 121 313 318 121 313 minecraft:iron_block
fill 317 121 316 318 121 316 minecraft:iron_block
fill 318 121 276 318 121 277 minecraft:iron_block
fill 318 121 279 319 121 279 minecraft:iron_block
fill 318 121 315 319 121 315 minecraft:iron_block
fill 319 121 278 320 121 278 minecraft:iron_block
fill 319 121 314 320 121 314 minecraft:iron_block
fill 320 121 277 321 121 277 minecraft:iron_block
fill 320 121 280 320 121 281 minecraft:iron_block
fill 320 121 283 320 121 284 minecraft:iron_block
fill 320 121 286 320 121 287 minecraft:iron_block
fill 320 121 289 320 121 290 minecraft:iron_block
fill 320 121 292 320 121 293 minecraft:iron_block
fill 320 121 295 320 121 296 minecraft:iron_block
fill 320 121 298 320 121 299 minecraft:iron_block
fill 320 121 301 320 121 302 minecraft:iron_block
fill 320 121 304 320 121 305 minecraft:iron_block
fill 320 121 307 320 121 308 minecraft:iron_block
fill 320 121 310 320 121 311 minecraft:iron_block
fill 320 121 313 321 121 313 minecraft:iron_block
fill 320 121 316 321 121 316 minecraft:iron_block
fill 321 121 276 322 121 276 minecraft:iron_block
fill 321 121 279 321 121 280 minecraft:iron_block
fill 321 121 282 321 121 283 minecraft:iron_block
fill 321 121 285 321 121 286 minecraft:iron_block
fill 321 121 288 321 121 289 minecraft:iron_block
fill 321 121 291 321 121 292 minecraft:iron_block
fill 321 121 294 321 121 295 minecraft:iron_block
fill 321 121 297 321 121 298 minecraft:iron_block
fill 321 121 300 321 121 301 minecraft:iron_block
fill 321 121 303 321 121 304 minecraft:iron_block
fill 321 121 306 321 121 307 minecraft:iron_block
fill 321 121 309 321 121 310 minecraft:iron_block
fill 321 121 312 322 121 312 minecraft:iron_block
fill 321 121 315 322 121 315 minecraft:iron_block
fill 322 121 278 322 121 279 minecraft:iron_block
fill 322 121 281 322 121 282 minecraft:iron_block
fill 322 121 284 322 121 285 minecraft:iron_block
fill 322 121 287 322 121 288 minecraft:iron_block
fill 322 121 290 322 121 291 minecraft:iron_block
fill 322 121 293 322 121 294 minecraft:iron_block
fill 322 121 296 322 121 297 minecraft:iron_block
fill 322 121 299 322 121 300 minecraft:iron_block
fill 322 121 302 322 121 303 minecraft:iron_block
fill 322 121 305 322 121 306 minecraft:iron_block
fill 322 121 308 322 121 309 minecraft:iron_block
fill 322 121 311 323 121 311 minecraft:iron_block
fill 322 121 314 323 121 314 minecraft:iron_block
fill 323 121 277 323 121 278 minecraft:iron_block
fill 323 121 280 323 121 281 minecraft:iron_block
setblock 323 121 284 minecraft:iron_block
fill 323 121 286 323 121 287 minecraft:iron_block
fill 323 121 289 323 121 290 minecraft:iron_block
fill 323 121 295 323 121 296 minecraft:iron_block
fill 323 121 298 323 121 299 minecraft:iron_block
setblock 323 121 301 minecraft:iron_block
fill 323 121 304 324 121 305 minecraft:iron_block
fill 323 121 307 323 121 308 minecraft:iron_block
setblock 323 121 310 minecraft:iron_block
setblock 323 121 316 minecraft:iron_block
fill 324 121 276 324 121 279 minecraft:pearlescent_froglight
fill 324 121 286 324 121 289 minecraft:pearlescent_froglight
fill 324 121 296 324 121 299 minecraft:pearlescent_froglight
fill 324 121 306 324 121 309 minecraft:pearlescent_froglight
setblock 324 121 316 minecraft:pearlescent_froglight
fill 282 122 281 282 131 284 minecraft:iron_block
fill 282 122 291 282 129 294 minecraft:iron_block
fill 282 122 301 282 128 304 minecraft:iron_block
fill 282 122 311 282 125 314 minecraft:iron_block
fill 285 122 275 288 130 275 minecraft:iron_block
setblock 286 122 279 minecraft:light_gray_concrete
fill 286 122 281 286 122 313 minecraft:light_gray_concrete
fill 286 122 317 289 131 317 minecraft:iron_block
fill 287 122 313 320 122 313 minecraft:light_gray_concrete
fill 290 122 279 298 122 279 minecraft:light_gray_concrete
fill 295 122 275 298 130 275 minecraft:iron_block
fill 296 122 317 299 130 317 minecraft:iron_block
fill 300 122 279 312 122 279 minecraft:light_gray_concrete
fill 305 122 275 308 125 275 minecraft:iron_block
fill 306 122 317 309 131 317 minecraft:iron_block
fill 313 122 279 315 127 279 minecraft:iron_block
fill 314 122 278 315 127 278 minecraft:iron_block
fill 315 122 275 318 122 275 minecraft:iron_block
fill 316 122 279 320 122 279 minecraft:light_gray_concrete
fill 316 122 317 319 130 317 minecraft:iron_block
fill 320 122 280 320 122 312 minecraft:light_gray_concrete
fill 324 122 276 324 129 279 minecraft:iron_block
fill 324 122 286 324 133 289 minecraft:iron_block
fill 324 122 296 324 129 299 minecraft:iron_block
fill 324 122 302 324 129 302 minecraft:iron_block
fill 324 122 304 324 124 309 minecraft:iron_block
fill 324 122 316 324 133 316 minecraft:iron_block
fill 315 123 275 315 133 275 minecraft:iron_block
setblock 316 123 275 minecraft:sea_lantern
fill 317 123 275 318 133 275 minecraft:iron_block
setblock 286 124 279 minecraft:gray_concrete
fill 286 124 281 286 124 282 minecraft:gray_concrete
fill 287 124 278 289 124 278 minecraft:gray_concrete
setblock 287 124 282 minecraft:gray_concrete
setblock 289 124 282 minecraft:gray_concrete
fill 290 124 279 290 124 281 minecraft:gray_concrete
fill 298 124 278 298 124 280 minecraft:iron_block
fill 299 124 278 300 124 278 minecraft:iron_block
fill 299 124 280 300 124 280 minecraft:iron_block
setblock 300 124 279 minecraft:iron_block
fill 316 124 275 316 129 275 minecraft:iron_block
fill 284 125 305 284 126 309 minecraft:iron_block
fill 285 125 304 285 126 305 minecraft:iron_block
fill 285 125 307 290 126 307 minecraft:iron_block
fill 285 125 309 285 126 310 minecraft:iron_block
fill 286 125 304 289 126 304 minecraft:iron_block
fill 286 125 310 289 126 310 minecraft:iron_block
fill 287 125 305 287 126 306 minecraft:iron_block
fill 287 125 308 287 126 309 minecraft:iron_block
fill 289 125 305 290 126 305 minecraft:iron_block
fill 289 125 309 290 126 309 minecraft:iron_block
fill 290 125 306 290 126 306 minecraft:iron_block
fill 290 125 308 290 126 308 minecraft:iron_block
fill 324 125 304 324 134 304 minecraft:iron_block
setblock 324 125 305 minecraft:sea_lantern
fill 324 125 306 324 125 309 minecraft:iron_block
fill 282 126 311 283 126 313 minecraft:iron_block
setblock 282 126 314 minecraft:sea_lantern
setblock 283 126 278 minecraft:iron_block
fill 283 126 280 283 126 283 minecraft:iron_block
setblock 283 126 288 minecraft:iron_block
fill 283 126 290 283 126 293 minecraft:iron_block
setblock 283 126 298 minecraft:iron_block
fill 283 126 300 283 126 303 minecraft:iron_block
setblock 283 126 308 minecraft:iron_block
setblock 283 126 310 minecraft:iron_block
fill 284 126 276 287 126 276 minecraft:iron_block
setblock 285 126 278 minecraft:light[level=12]
setblock 285 126 285 minecraft:light[level=12]
setblock 285 126 292 minecraft:light[level=12]
setblock 285 126 299 minecraft:light[level=12]
setblock 285 126 306 minecraft:light[level=12]
setblock 285 126 313 minecraft:light[level=12]
setblock 285 126 316 minecraft:iron_block
fill 286 126 279 286 127 279 minecraft:light_gray_concrete
fill 286 126 281 286 127 281 minecraft:light_gray_concrete
fill 287 126 278 288 127 278 minecraft:light_gray_concrete
fill 287 126 282 287 127 282 minecraft:light_gray_concrete
fill 287 126 316 290 126 316 minecraft:iron_block
setblock 289 126 276 minecraft:iron_block
fill 289 126 282 289 127 282 minecraft:light_gray_concrete
fill 290 126 280 290 127 281 minecraft:light_gray_concrete
setblock 292 126 278 minecraft:light[level=12]
setblock 292 126 285 minecraft:light[level=12]
setblock 292 126 292 minecraft:light[level=12]
setblock 292 126 299 minecraft:light[level=12]
setblock 292 126 306 minecraft:light[level=12]
setblock 292 126 313 minecraft:light[level=12]
fill 294 126 276 297 126 276 minecraft:iron_block
setblock 295 126 316 minecraft:iron_block
fill 297 126 316 300 126 316 minecraft:iron_block
setblock 299 126 276 minecraft:iron_block
setblock 299 126 278 minecraft:light[level=12]
setblock 299 126 285 minecraft:light[level=12]
setblock 299 126 292 minecraft:light[level=12]
setblock 299 126 299 minecraft:light[level=12]
setblock 299 126 306 minecraft:light[level=12]
setblock 299 126 313 minecraft:light[level=12]
fill 304 126 276 307 126 276 minecraft:iron_block
fill 305 126 275 306 129 275 minecraft:iron_block
setblock 305 126 316 minecraft:iron_block
setblock 306 126 278 minecraft:light[level=12]
setblock 306 126 285 minecraft:light[level=12]
setblock 306 126 292 minecraft:light[level=12]
setblock 306 126 299 minecraft:light[level=12]
setblock 306 126 306 minecraft:light[level=12]
setblock 306 126 313 minecraft:light[level=12]
setblock 307 126 275 minecraft:sea_lantern
fill 307 126 316 310 126 316 minecraft:iron_block
fill 308 126 275 308 133 275 minecraft:iron_block
setblock 309 126 276 minecraft:iron_block
fill 312 126 278 312 126 280 minecraft:iron_block
fill 313 126 277 315 126 277 minecraft:iron_block
fill 313 126 281 315 126 281 minecraft:iron_block
setblock 313 126 285 minecraft:light[level=12]
setblock 313 126 292 minecraft:light[level=12]
setblock 313 126 299 minecraft:light[level=12]
setblock 313 126 306 minecraft:light[level=12]
setblock 313 126 313 minecraft:light[level=12]
fill 314 126 276 317 126 276 minecraft:iron_block
setblock 315 126 316 minecraft:iron_block
fill 316 126 278 316 126 280 minecraft:iron_block
fill 317 126 316 320 126 316 minecraft:iron_block
setblock 319 126 276 minecraft:iron_block
setblock 320 126 278 minecraft:light[level=12]
setblock 320 126 285 minecraft:light[level=12]
setblock 320 126 292 minecraft:light[level=12]
setblock 320 126 299 minecraft:light[level=12]
setblock 320 126 306 minecraft:light[level=12]
setblock 320 126 313 minecraft:light[level=12]
fill 323 126 277 323 126 280 minecraft:iron_block
setblock 323 126 282 minecraft:iron_block
fill 323 126 287 323 126 290 minecraft:iron_block
setblock 323 126 292 minecraft:iron_block
fill 323 126 297 323 126 300 minecraft:iron_block
setblock 323 126 302 minecraft:iron_block
fill 323 126 307 323 126 310 minecraft:iron_block
setblock 323 126 312 minecraft:iron_block
fill 324 126 305 324 130 305 minecraft:iron_block
setblock 324 126 306 minecraft:redstone_block
fill 324 126 307 324 133 309 minecraft:iron_block
fill 282 127 311 282 129 314 minecraft:iron_block
setblock 291 127 275 minecraft:sea_lantern
fill 307 127 275 307 133 275 minecraft:iron_block
fill 320 127 317 320 133 317 minecraft:iron_block
setblock 321 127 317 minecraft:sea_lantern
fill 322 127 317 324 133 317 minecraft:iron_block
fill 324 127 306 324 133 306 minecraft:iron_block
setblock 285 128 278 minecraft:light[level=15]
setblock 285 128 286 minecraft:light[level=15]
setblock 285 128 294 minecraft:light[level=15]
setblock 285 128 302 minecraft:light[level=15]
setblock 285 128 310 minecraft:light[level=15]
fill 291 128 275 291 133 275 minecraft:iron_block
setblock 293 128 278 minecraft:light[level=15]
setblock 293 128 286 minecraft:light[level=15]
setblock 293 128 294 minecraft:light[level=15]
setblock 293 128 302 minecraft:light[level=15]
setblock 293 128 310 minecraft:light[level=15]
setblock 301 128 278 minecraft:light[level=15]
setblock 301 128 286 minecraft:light[level=15]
setblock 301 128 294 minecraft:light[level=15]
setblock 301 128 302 minecraft:light[level=15]
setblock 301 128 310 minecraft:light[level=15]
setblock 309 128 278 minecraft:light[level=15]
setblock 309 128 286 minecraft:light[level=15]
setblock 309 128 294 minecraft:light[level=15]
setblock 309 128 302 minecraft:light[level=15]
setblock 309 128 310 minecraft:light[level=15]
setblock 317 128 278 minecraft:light[level=15]
setblock 317 128 286 minecraft:light[level=15]
setblock 317 128 294 minecraft:light[level=15]
setblock 317 128 302 minecraft:light[level=15]
setblock 317 128 310 minecraft:light[level=15]
fill 321 128 317 321 133 317 minecraft:iron_block
fill 282 129 301 282 131 303 minecraft:iron_block
setblock 282 129 304 minecraft:redstone_block
setblock 290 129 275 minecraft:sea_lantern
fill 302 129 317 302 133 317 minecraft:iron_block
setblock 303 129 317 minecraft:sea_lantern
fill 304 129 317 305 131 317 minecraft:iron_block
fill 282 130 285 282 130 287 minecraft:iron_block
fill 282 130 288 282 130 289 minecraft:gray_concrete
fill 282 130 290 282 133 292 minecraft:iron_block
setblock 282 130 293 minecraft:gray_concrete
fill 282 130 294 282 133 294 minecraft:iron_block
fill 282 130 304 282 133 304 minecraft:iron_block
fill 282 130 311 282 133 311 minecraft:iron_block
setblock 282 130 312 minecraft:gray_concrete
fill 282 130 313 282 131 314 minecraft:iron_block
fill 290 130 275 290 133 275 minecraft:iron_block
fill 290 130 317 291 133 317 minecraft:iron_block
setblock 292 130 317 minecraft:gray_concrete
fill 293 130 317 295 130 317 minecraft:iron_block
fill 299 130 275 300 131 275 minecraft:iron_block
setblock 301 130 275 minecraft:gray_concrete
fill 302 130 275 304 130 275 minecraft:iron_block
fill 303 130 317 303 135 317 minecraft:iron_block
setblock 305 130 275 minecraft:gray_concrete
fill 306 130 275 306 133 275 minecraft:iron_block
setblock 316 130 275 minecraft:gray_concrete
schedule function dropper:buildpart/66_2 1t
