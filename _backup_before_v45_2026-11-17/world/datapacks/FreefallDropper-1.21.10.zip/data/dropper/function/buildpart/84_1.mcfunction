fill 42 85 370 42 85 373 minecraft:sea_lantern
fill 42 85 380 42 85 383 minecraft:sea_lantern
fill 42 85 384 42 192 384 minecraft:blue_terracotta
fill 42 85 388 42 190 389 minecraft:blue_terracotta
fill 42 85 390 42 85 393 minecraft:sea_lantern
fill 42 85 400 42 85 403 minecraft:sea_lantern
setblock 42 85 410 minecraft:sea_lantern
fill 0 86 375 0 93 378 minecraft:blue_terracotta
fill 0 86 385 0 93 388 minecraft:blue_terracotta
fill 0 86 395 0 93 398 minecraft:blue_terracotta
fill 0 86 405 0 93 408 minecraft:blue_terracotta
fill 3 86 369 6 93 369 minecraft:blue_terracotta
fill 4 86 411 7 93 411 minecraft:blue_terracotta
fill 13 86 369 16 93 369 minecraft:blue_terracotta
fill 14 86 411 17 93 411 minecraft:blue_terracotta
fill 23 86 369 26 93 369 minecraft:blue_terracotta
fill 24 86 411 27 93 411 minecraft:blue_terracotta
fill 33 86 369 36 93 369 minecraft:blue_terracotta
fill 34 86 411 37 93 411 minecraft:blue_terracotta
fill 36 86 370 36 87 371 minecraft:iron_block
fill 42 86 370 42 93 373 minecraft:blue_terracotta
fill 42 86 380 42 93 383 minecraft:blue_terracotta
fill 42 86 390 42 93 393 minecraft:blue_terracotta
fill 42 86 400 42 93 403 minecraft:blue_terracotta
fill 42 86 410 42 93 410 minecraft:blue_terracotta
setblock 36 87 375 minecraft:sea_lantern
fill 1 88 382 1 88 383 minecraft:gray_concrete
fill 2 88 380 4 88 380 minecraft:gray_concrete
fill 2 88 384 4 88 384 minecraft:gray_concrete
fill 5 88 381 5 88 383 minecraft:gray_concrete
setblock 35 88 372 minecraft:gray_concrete
setblock 35 88 374 minecraft:gray_concrete
setblock 37 88 372 minecraft:gray_concrete
setblock 37 88 374 minecraft:gray_concrete
setblock 1 90 372 minecraft:gray_concrete
fill 1 90 374 1 90 377 minecraft:gray_concrete
setblock 1 90 382 minecraft:gray_concrete
fill 1 90 384 1 90 387 minecraft:gray_concrete
setblock 1 90 392 minecraft:gray_concrete
fill 1 90 394 1 90 397 minecraft:gray_concrete
setblock 1 90 402 minecraft:gray_concrete
fill 1 90 404 1 90 407 minecraft:gray_concrete
fill 2 90 370 5 90 370 minecraft:gray_concrete
setblock 3 90 410 minecraft:gray_concrete
fill 5 90 410 8 90 410 minecraft:gray_concrete
setblock 7 90 370 minecraft:gray_concrete
fill 12 90 370 15 90 370 minecraft:gray_concrete
setblock 13 90 410 minecraft:gray_concrete
fill 15 90 410 18 90 410 minecraft:gray_concrete
setblock 17 90 370 minecraft:gray_concrete
fill 22 90 370 25 90 370 minecraft:gray_concrete
setblock 23 90 410 minecraft:gray_concrete
fill 25 90 410 28 90 410 minecraft:gray_concrete
setblock 27 90 370 minecraft:gray_concrete
fill 32 90 370 35 90 370 minecraft:gray_concrete
setblock 33 90 410 minecraft:gray_concrete
fill 35 90 410 38 90 410 minecraft:gray_concrete
setblock 37 90 370 minecraft:gray_concrete
fill 41 90 371 41 90 374 minecraft:gray_concrete
setblock 41 90 376 minecraft:gray_concrete
fill 41 90 381 41 90 384 minecraft:gray_concrete
setblock 41 90 386 minecraft:gray_concrete
fill 41 90 391 41 90 394 minecraft:gray_concrete
setblock 41 90 396 minecraft:gray_concrete
fill 41 90 401 41 90 404 minecraft:gray_concrete
setblock 41 90 406 minecraft:gray_concrete
setblock 3 93 372 minecraft:light[level=14]
setblock 3 93 380 minecraft:light[level=14]
setblock 3 93 388 minecraft:light[level=14]
setblock 3 93 396 minecraft:light[level=14]
setblock 3 93 404 minecraft:light[level=14]
setblock 11 93 372 minecraft:light[level=14]
setblock 11 93 380 minecraft:light[level=14]
setblock 11 93 388 minecraft:light[level=14]
setblock 11 93 396 minecraft:light[level=14]
setblock 11 93 404 minecraft:light[level=14]
setblock 19 93 372 minecraft:light[level=14]
setblock 19 93 380 minecraft:light[level=14]
setblock 19 93 388 minecraft:light[level=14]
setblock 19 93 396 minecraft:light[level=14]
setblock 19 93 404 minecraft:light[level=14]
setblock 27 93 372 minecraft:light[level=14]
setblock 27 93 380 minecraft:light[level=14]
setblock 27 93 388 minecraft:light[level=14]
setblock 27 93 396 minecraft:light[level=14]
setblock 27 93 404 minecraft:light[level=14]
setblock 35 93 372 minecraft:light[level=14]
setblock 35 93 380 minecraft:light[level=14]
setblock 35 93 388 minecraft:light[level=14]
setblock 35 93 396 minecraft:light[level=14]
setblock 35 93 404 minecraft:light[level=14]
fill 0 94 375 0 94 378 minecraft:sea_lantern
fill 0 94 385 0 94 388 minecraft:sea_lantern
fill 0 94 395 0 94 398 minecraft:sea_lantern
fill 0 94 405 0 94 408 minecraft:sea_lantern
fill 1 94 382 1 94 383 minecraft:gray_concrete
fill 2 94 380 4 94 380 minecraft:gray_concrete
fill 2 94 384 4 94 384 minecraft:gray_concrete
fill 3 94 369 6 94 369 minecraft:sea_lantern
fill 4 94 411 7 94 411 minecraft:sea_lantern
fill 5 94 381 5 94 383 minecraft:gray_concrete
fill 13 94 369 16 94 369 minecraft:sea_lantern
fill 14 94 411 17 94 411 minecraft:sea_lantern
fill 23 94 369 26 94 369 minecraft:sea_lantern
fill 24 94 411 27 94 411 minecraft:sea_lantern
fill 33 94 369 36 94 369 minecraft:sea_lantern
fill 34 94 411 37 94 411 minecraft:sea_lantern
setblock 35 94 372 minecraft:gray_concrete
setblock 35 94 374 minecraft:gray_concrete
setblock 37 94 372 minecraft:gray_concrete
setblock 37 94 374 minecraft:gray_concrete
fill 42 94 370 42 94 373 minecraft:sea_lantern
fill 42 94 380 42 94 383 minecraft:sea_lantern
fill 42 94 390 42 94 393 minecraft:sea_lantern
fill 42 94 400 42 94 403 minecraft:sea_lantern
setblock 42 94 410 minecraft:sea_lantern
fill 0 95 375 0 102 378 minecraft:blue_terracotta
fill 0 95 385 0 102 388 minecraft:blue_terracotta
fill 0 95 395 0 102 398 minecraft:blue_terracotta
fill 0 95 405 0 102 408 minecraft:blue_terracotta
fill 3 95 369 6 102 369 minecraft:blue_terracotta
fill 4 95 411 7 102 411 minecraft:blue_terracotta
fill 13 95 369 16 102 369 minecraft:blue_terracotta
fill 14 95 411 17 102 411 minecraft:blue_terracotta
fill 23 95 369 26 102 369 minecraft:blue_terracotta
fill 24 95 411 27 102 411 minecraft:blue_terracotta
fill 33 95 369 36 102 369 minecraft:blue_terracotta
fill 34 95 411 37 102 411 minecraft:blue_terracotta
fill 42 95 370 42 102 373 minecraft:blue_terracotta
fill 42 95 380 42 102 383 minecraft:blue_terracotta
fill 42 95 390 42 102 393 minecraft:blue_terracotta
fill 42 95 400 42 102 403 minecraft:blue_terracotta
fill 42 95 410 42 102 410 minecraft:blue_terracotta
setblock 1 96 372 minecraft:gray_concrete
setblock 1 96 382 minecraft:gray_concrete
setblock 1 96 392 minecraft:gray_concrete
setblock 1 96 402 minecraft:gray_concrete
setblock 3 96 410 minecraft:gray_concrete
setblock 7 96 370 minecraft:gray_concrete
setblock 13 96 410 minecraft:gray_concrete
setblock 17 96 370 minecraft:gray_concrete
setblock 23 96 410 minecraft:gray_concrete
setblock 27 96 370 minecraft:gray_concrete
setblock 33 96 410 minecraft:gray_concrete
setblock 37 96 370 minecraft:gray_concrete
setblock 41 96 376 minecraft:gray_concrete
setblock 41 96 386 minecraft:gray_concrete
setblock 41 96 396 minecraft:gray_concrete
setblock 41 96 406 minecraft:gray_concrete
fill 17 97 399 18 98 400 minecraft:white_stained_glass
fill 1 99 374 1 99 377 minecraft:gray_concrete
fill 1 99 384 1 99 387 minecraft:gray_concrete
fill 1 99 394 1 99 397 minecraft:gray_concrete
fill 1 99 404 1 99 407 minecraft:gray_concrete
fill 2 99 370 5 99 370 minecraft:gray_concrete
fill 5 99 410 8 99 410 minecraft:gray_concrete
fill 12 99 370 15 99 370 minecraft:gray_concrete
fill 15 99 410 18 99 410 minecraft:gray_concrete
fill 22 99 370 25 99 370 minecraft:gray_concrete
fill 25 99 410 28 99 410 minecraft:gray_concrete
fill 32 99 370 35 99 370 minecraft:gray_concrete
fill 35 99 410 38 99 410 minecraft:gray_concrete
fill 41 99 371 41 99 374 minecraft:gray_concrete
fill 41 99 381 41 99 384 minecraft:gray_concrete
fill 41 99 391 41 99 394 minecraft:gray_concrete
fill 41 99 401 41 99 404 minecraft:gray_concrete
fill 1 100 382 1 100 383 minecraft:gray_concrete
fill 2 100 380 4 100 380 minecraft:gray_concrete
fill 2 100 384 4 100 384 minecraft:gray_concrete
fill 5 100 381 5 100 383 minecraft:gray_concrete
setblock 35 100 372 minecraft:gray_concrete
setblock 35 100 374 minecraft:gray_concrete
setblock 37 100 372 minecraft:gray_concrete
setblock 37 100 374 minecraft:gray_concrete
setblock 3 101 372 minecraft:light[level=14]
setblock 3 101 380 minecraft:light[level=14]
setblock 3 101 388 minecraft:light[level=14]
setblock 3 101 396 minecraft:light[level=14]
setblock 3 101 404 minecraft:light[level=14]
setblock 11 101 372 minecraft:light[level=14]
setblock 11 101 380 minecraft:light[level=14]
setblock 11 101 388 minecraft:light[level=14]
setblock 11 101 396 minecraft:light[level=14]
setblock 11 101 404 minecraft:light[level=14]
setblock 19 101 372 minecraft:light[level=14]
setblock 19 101 380 minecraft:light[level=14]
setblock 19 101 388 minecraft:light[level=14]
setblock 19 101 396 minecraft:light[level=14]
setblock 19 101 404 minecraft:light[level=14]
setblock 27 101 372 minecraft:light[level=14]
setblock 27 101 380 minecraft:light[level=14]
setblock 27 101 388 minecraft:light[level=14]
setblock 27 101 396 minecraft:light[level=14]
setblock 27 101 404 minecraft:light[level=14]
setblock 35 101 372 minecraft:light[level=14]
setblock 35 101 380 minecraft:light[level=14]
setblock 35 101 388 minecraft:light[level=14]
setblock 35 101 396 minecraft:light[level=14]
setblock 35 101 404 minecraft:light[level=14]
setblock 1 102 372 minecraft:gray_concrete
setblock 1 102 382 minecraft:gray_concrete
setblock 1 102 392 minecraft:gray_concrete
setblock 1 102 402 minecraft:gray_concrete
setblock 3 102 410 minecraft:gray_concrete
setblock 7 102 370 minecraft:gray_concrete
setblock 13 102 410 minecraft:gray_concrete
setblock 17 102 370 minecraft:gray_concrete
setblock 23 102 410 minecraft:gray_concrete
setblock 27 102 370 minecraft:gray_concrete
setblock 33 102 410 minecraft:gray_concrete
setblock 37 102 370 minecraft:gray_concrete
setblock 41 102 376 minecraft:gray_concrete
setblock 41 102 386 minecraft:gray_concrete
setblock 41 102 396 minecraft:gray_concrete
setblock 41 102 406 minecraft:gray_concrete
fill 0 103 375 0 103 378 minecraft:sea_lantern
fill 0 103 385 0 103 388 minecraft:sea_lantern
fill 0 103 395 0 103 398 minecraft:sea_lantern
fill 0 103 405 0 103 408 minecraft:sea_lantern
fill 3 103 369 6 103 369 minecraft:sea_lantern
fill 4 103 411 7 103 411 minecraft:sea_lantern
fill 13 103 369 16 103 369 minecraft:sea_lantern
fill 14 103 411 17 103 411 minecraft:sea_lantern
fill 23 103 369 26 103 369 minecraft:sea_lantern
fill 24 103 411 27 103 411 minecraft:sea_lantern
fill 33 103 369 36 103 369 minecraft:sea_lantern
fill 34 103 411 37 103 411 minecraft:sea_lantern
fill 42 103 370 42 103 373 minecraft:sea_lantern
fill 42 103 380 42 103 383 minecraft:sea_lantern
fill 42 103 390 42 103 393 minecraft:sea_lantern
fill 42 103 400 42 103 403 minecraft:sea_lantern
setblock 42 103 410 minecraft:sea_lantern
fill 0 104 375 0 111 378 minecraft:blue_terracotta
fill 0 104 385 0 111 388 minecraft:blue_terracotta
fill 0 104 395 0 111 398 minecraft:blue_terracotta
fill 0 104 405 0 111 408 minecraft:blue_terracotta
fill 3 104 369 6 111 369 minecraft:blue_terracotta
fill 4 104 411 7 111 411 minecraft:blue_terracotta
fill 13 104 369 16 111 369 minecraft:blue_terracotta
fill 14 104 411 17 111 411 minecraft:blue_terracotta
fill 23 104 369 26 111 369 minecraft:blue_terracotta
fill 24 104 411 27 111 411 minecraft:blue_terracotta
fill 33 104 369 36 111 369 minecraft:blue_terracotta
fill 34 104 411 37 111 411 minecraft:blue_terracotta
fill 42 104 370 42 111 373 minecraft:blue_terracotta
fill 42 104 380 42 111 383 minecraft:blue_terracotta
fill 42 104 390 42 111 393 minecraft:blue_terracotta
fill 42 104 400 42 111 403 minecraft:blue_terracotta
fill 42 104 410 42 111 410 minecraft:blue_terracotta
fill 1 106 382 1 106 383 minecraft:gray_concrete
fill 2 106 380 4 106 380 minecraft:gray_concrete
fill 2 106 384 4 106 384 minecraft:gray_concrete
fill 5 106 381 5 106 383 minecraft:gray_concrete
setblock 35 106 372 minecraft:gray_concrete
setblock 35 106 374 minecraft:gray_concrete
setblock 37 106 372 minecraft:gray_concrete
setblock 37 106 374 minecraft:gray_concrete
setblock 1 108 372 minecraft:gray_concrete
fill 1 108 374 1 108 377 minecraft:gray_concrete
setblock 1 108 382 minecraft:gray_concrete
fill 1 108 384 1 108 387 minecraft:gray_concrete
setblock 1 108 392 minecraft:gray_concrete
fill 1 108 394 1 108 397 minecraft:gray_concrete
setblock 1 108 402 minecraft:gray_concrete
fill 1 108 404 1 108 407 minecraft:gray_concrete
fill 2 108 370 5 108 370 minecraft:gray_concrete
setblock 3 108 410 minecraft:gray_concrete
fill 5 108 410 8 108 410 minecraft:gray_concrete
fill 6 108 383 6 109 384 minecraft:white_stained_glass
setblock 7 108 370 minecraft:gray_concrete
fill 12 108 370 15 108 370 minecraft:gray_concrete
setblock 13 108 410 minecraft:gray_concrete
fill 15 108 410 18 108 410 minecraft:gray_concrete
setblock 17 108 370 minecraft:gray_concrete
fill 22 108 370 25 108 370 minecraft:gray_concrete
setblock 23 108 410 minecraft:gray_concrete
fill 25 108 410 28 108 410 minecraft:gray_concrete
setblock 27 108 370 minecraft:gray_concrete
fill 32 108 370 35 108 370 minecraft:gray_concrete
setblock 33 108 410 minecraft:gray_concrete
fill 35 108 410 38 108 410 minecraft:gray_concrete
setblock 37 108 370 minecraft:gray_concrete
fill 41 108 371 41 108 374 minecraft:gray_concrete
setblock 41 108 376 minecraft:gray_concrete
fill 41 108 381 41 108 384 minecraft:gray_concrete
setblock 41 108 386 minecraft:gray_concrete
fill 41 108 391 41 108 394 minecraft:gray_concrete
setblock 41 108 396 minecraft:gray_concrete
fill 41 108 401 41 108 404 minecraft:gray_concrete
setblock 41 108 406 minecraft:gray_concrete
setblock 3 109 372 minecraft:light[level=14]
setblock 3 109 380 minecraft:light[level=14]
setblock 3 109 388 minecraft:light[level=14]
setblock 3 109 396 minecraft:light[level=14]
setblock 3 109 404 minecraft:light[level=14]
setblock 11 109 372 minecraft:light[level=14]
setblock 11 109 380 minecraft:light[level=14]
setblock 11 109 388 minecraft:light[level=14]
setblock 11 109 396 minecraft:light[level=14]
setblock 11 109 404 minecraft:light[level=14]
setblock 19 109 372 minecraft:light[level=14]
setblock 19 109 380 minecraft:light[level=14]
setblock 19 109 388 minecraft:light[level=14]
setblock 19 109 396 minecraft:light[level=14]
setblock 19 109 404 minecraft:light[level=14]
fill 21 109 398 22 110 399 minecraft:white_stained_glass
setblock 27 109 372 minecraft:light[level=14]
setblock 27 109 380 minecraft:light[level=14]
setblock 27 109 388 minecraft:light[level=14]
setblock 27 109 396 minecraft:light[level=14]
setblock 27 109 404 minecraft:light[level=14]
setblock 35 109 372 minecraft:light[level=14]
setblock 35 109 380 minecraft:light[level=14]
setblock 35 109 388 minecraft:light[level=14]
setblock 35 109 396 minecraft:light[level=14]
setblock 35 109 404 minecraft:light[level=14]
fill 0 112 375 0 112 378 minecraft:sea_lantern
fill 0 112 385 0 112 388 minecraft:sea_lantern
fill 0 112 395 0 112 398 minecraft:sea_lantern
fill 0 112 405 0 112 408 minecraft:sea_lantern
fill 1 112 382 1 112 383 minecraft:gray_concrete
fill 2 112 380 4 112 380 minecraft:gray_concrete
fill 2 112 384 4 112 384 minecraft:gray_concrete
fill 3 112 369 6 112 369 minecraft:sea_lantern
fill 4 112 411 7 112 411 minecraft:sea_lantern
fill 5 112 381 5 112 383 minecraft:gray_concrete
fill 13 112 369 16 112 369 minecraft:sea_lantern
fill 14 112 411 17 112 411 minecraft:sea_lantern
fill 23 112 369 26 112 369 minecraft:sea_lantern
fill 24 112 411 27 112 411 minecraft:sea_lantern
fill 33 112 369 36 112 369 minecraft:sea_lantern
fill 34 112 411 37 112 411 minecraft:sea_lantern
setblock 35 112 372 minecraft:gray_concrete
setblock 35 112 374 minecraft:gray_concrete
fill 35 112 401 36 113 401 minecraft:white_stained_glass
setblock 37 112 372 minecraft:gray_concrete
setblock 37 112 374 minecraft:gray_concrete
fill 42 112 370 42 112 373 minecraft:sea_lantern
fill 42 112 380 42 112 383 minecraft:sea_lantern
fill 42 112 390 42 112 393 minecraft:sea_lantern
fill 42 112 400 42 112 403 minecraft:sea_lantern
setblock 42 112 410 minecraft:sea_lantern
fill 0 113 375 0 120 378 minecraft:blue_terracotta
fill 0 113 385 0 120 388 minecraft:blue_terracotta
fill 0 113 395 0 120 398 minecraft:blue_terracotta
fill 0 113 405 0 120 408 minecraft:blue_terracotta
fill 3 113 369 6 120 369 minecraft:blue_terracotta
fill 4 113 411 7 120 411 minecraft:blue_terracotta
fill 13 113 369 16 120 369 minecraft:blue_terracotta
fill 14 113 411 17 120 411 minecraft:blue_terracotta
fill 23 113 369 26 120 369 minecraft:blue_terracotta
fill 24 113 411 27 120 411 minecraft:blue_terracotta
fill 33 113 369 36 120 369 minecraft:blue_terracotta
fill 34 113 411 37 120 411 minecraft:blue_terracotta
fill 42 113 370 42 120 373 minecraft:blue_terracotta
fill 42 113 380 42 120 383 minecraft:blue_terracotta
fill 42 113 390 42 120 393 minecraft:blue_terracotta
fill 42 113 400 42 120 403 minecraft:blue_terracotta
fill 42 113 410 42 120 410 minecraft:blue_terracotta
setblock 1 114 372 minecraft:gray_concrete
setblock 1 114 382 minecraft:gray_concrete
setblock 1 114 392 minecraft:gray_concrete
setblock 1 114 402 minecraft:gray_concrete
setblock 3 114 410 minecraft:gray_concrete
setblock 7 114 370 minecraft:gray_concrete
setblock 13 114 410 minecraft:gray_concrete
setblock 17 114 370 minecraft:gray_concrete
setblock 23 114 410 minecraft:gray_concrete
setblock 27 114 370 minecraft:gray_concrete
setblock 33 114 410 minecraft:gray_concrete
setblock 37 114 370 minecraft:gray_concrete
setblock 41 114 376 minecraft:gray_concrete
setblock 41 114 386 minecraft:gray_concrete
setblock 41 114 396 minecraft:gray_concrete
setblock 41 114 406 minecraft:gray_concrete
fill 27 115 400 29 116 400 minecraft:white_stained_glass
fill 28 115 399 28 116 399 minecraft:white_stained_glass
fill 28 115 401 28 116 401 minecraft:white_stained_glass
fill 33 115 381 33 116 381 minecraft:white_stained_glass
fill 1 116 382 1 117 383 minecraft:iron_block
fill 38 116 402 38 127 402 minecraft:green_terracotta
fill 1 117 374 1 117 377 minecraft:gray_concrete
fill 1 117 384 1 117 387 minecraft:gray_concrete
fill 1 117 394 1 117 397 minecraft:gray_concrete
fill 1 117 404 1 117 407 minecraft:gray_concrete
fill 2 117 370 5 117 370 minecraft:gray_concrete
setblock 3 117 372 minecraft:light[level=14]
setblock 3 117 380 minecraft:light[level=14]
setblock 3 117 388 minecraft:light[level=14]
setblock 3 117 396 minecraft:light[level=14]
setblock 3 117 404 minecraft:light[level=14]
setblock 5 117 382 minecraft:sea_lantern
fill 5 117 410 8 117 410 minecraft:gray_concrete
setblock 11 117 372 minecraft:light[level=14]
setblock 11 117 380 minecraft:light[level=14]
setblock 11 117 388 minecraft:light[level=14]
setblock 11 117 396 minecraft:light[level=14]
setblock 11 117 404 minecraft:light[level=14]
fill 12 117 370 15 117 370 minecraft:gray_concrete
fill 15 117 410 18 117 410 minecraft:gray_concrete
setblock 19 117 372 minecraft:light[level=14]
setblock 19 117 380 minecraft:light[level=14]
setblock 19 117 388 minecraft:light[level=14]
setblock 19 117 396 minecraft:light[level=14]
setblock 19 117 404 minecraft:light[level=14]
fill 22 117 370 25 117 370 minecraft:gray_concrete
fill 25 117 410 28 117 410 minecraft:gray_concrete
setblock 27 117 372 minecraft:light[level=14]
setblock 27 117 380 minecraft:light[level=14]
setblock 27 117 388 minecraft:light[level=14]
setblock 27 117 396 minecraft:light[level=14]
setblock 27 117 404 minecraft:light[level=14]
fill 32 117 370 35 117 370 minecraft:gray_concrete
setblock 35 117 372 minecraft:light[level=14]
setblock 35 117 380 minecraft:light[level=14]
setblock 35 117 388 minecraft:light[level=14]
setblock 35 117 396 minecraft:light[level=14]
setblock 35 117 404 minecraft:light[level=14]
fill 35 117 410 38 117 410 minecraft:gray_concrete
fill 41 117 371 41 117 374 minecraft:gray_concrete
fill 41 117 381 41 117 384 minecraft:gray_concrete
fill 41 117 391 41 117 394 minecraft:gray_concrete
fill 41 117 401 41 117 404 minecraft:gray_concrete
fill 1 118 382 1 118 383 minecraft:gray_concrete
fill 2 118 380 4 118 380 minecraft:gray_concrete
fill 2 118 384 4 118 384 minecraft:gray_concrete
fill 5 118 381 5 118 383 minecraft:gray_concrete
fill 13 118 398 14 119 399 minecraft:white_stained_glass
setblock 35 118 372 minecraft:gray_concrete
setblock 35 118 374 minecraft:gray_concrete
setblock 37 118 372 minecraft:gray_concrete
setblock 37 118 374 minecraft:gray_concrete
setblock 1 120 372 minecraft:gray_concrete
setblock 1 120 382 minecraft:gray_concrete
setblock 1 120 392 minecraft:gray_concrete
setblock 1 120 402 minecraft:gray_concrete
setblock 3 120 410 minecraft:gray_concrete
setblock 7 120 370 minecraft:gray_concrete
setblock 13 120 410 minecraft:gray_concrete
setblock 17 120 370 minecraft:gray_concrete
setblock 23 120 410 minecraft:gray_concrete
setblock 27 120 370 minecraft:gray_concrete
setblock 33 120 410 minecraft:gray_concrete
setblock 37 120 370 minecraft:gray_concrete
setblock 41 120 376 minecraft:gray_concrete
setblock 41 120 386 minecraft:gray_concrete
setblock 41 120 396 minecraft:gray_concrete
setblock 41 120 406 minecraft:gray_concrete
fill 0 121 375 0 121 378 minecraft:sea_lantern
fill 0 121 385 0 121 388 minecraft:sea_lantern
fill 0 121 395 0 121 398 minecraft:sea_lantern
fill 0 121 405 0 121 408 minecraft:sea_lantern
fill 3 121 369 6 121 369 minecraft:sea_lantern
fill 4 121 411 7 121 411 minecraft:sea_lantern
fill 13 121 369 16 121 369 minecraft:sea_lantern
fill 14 121 411 17 121 411 minecraft:sea_lantern
fill 23 121 369 26 121 369 minecraft:sea_lantern
fill 24 121 411 27 121 411 minecraft:sea_lantern
fill 33 121 369 36 121 369 minecraft:sea_lantern
fill 34 121 411 37 121 411 minecraft:sea_lantern
fill 42 121 370 42 121 373 minecraft:sea_lantern
fill 42 121 380 42 121 383 minecraft:sea_lantern
fill 42 121 390 42 121 393 minecraft:sea_lantern
fill 42 121 400 42 121 403 minecraft:sea_lantern
setblock 42 121 410 minecraft:sea_lantern
fill 0 122 375 0 129 378 minecraft:blue_terracotta
fill 0 122 385 0 129 388 minecraft:blue_terracotta
fill 0 122 395 0 129 398 minecraft:blue_terracotta
fill 0 122 405 0 129 408 minecraft:blue_terracotta
fill 3 122 369 6 129 369 minecraft:blue_terracotta
fill 4 122 411 7 129 411 minecraft:blue_terracotta
fill 13 122 369 16 129 369 minecraft:blue_terracotta
fill 14 122 411 17 129 411 minecraft:blue_terracotta
fill 23 122 369 26 129 369 minecraft:blue_terracotta
fill 24 122 411 27 129 411 minecraft:blue_terracotta
fill 30 122 393 32 123 393 minecraft:white_stained_glass
fill 31 122 394 32 123 394 minecraft:white_stained_glass
fill 33 122 369 36 129 369 minecraft:blue_terracotta
fill 34 122 411 37 129 411 minecraft:blue_terracotta
fill 42 122 370 42 129 373 minecraft:blue_terracotta
fill 42 122 380 42 129 383 minecraft:blue_terracotta
fill 42 122 390 42 129 393 minecraft:blue_terracotta
fill 42 122 400 42 129 403 minecraft:blue_terracotta
fill 42 122 410 42 129 410 minecraft:blue_terracotta
fill 1 124 382 1 124 383 minecraft:gray_concrete
fill 2 124 380 4 124 380 minecraft:gray_concrete
fill 2 124 384 4 124 384 minecraft:gray_concrete
fill 5 124 381 5 124 383 minecraft:gray_concrete
setblock 35 124 372 minecraft:gray_concrete
setblock 35 124 374 minecraft:gray_concrete
setblock 37 124 372 minecraft:gray_concrete
setblock 37 124 374 minecraft:gray_concrete
setblock 3 125 372 minecraft:light[level=14]
setblock 3 125 380 minecraft:light[level=14]
setblock 3 125 388 minecraft:light[level=14]
setblock 3 125 396 minecraft:light[level=14]
setblock 3 125 404 minecraft:light[level=14]
setblock 11 125 372 minecraft:light[level=14]
setblock 11 125 380 minecraft:light[level=14]
setblock 11 125 388 minecraft:light[level=14]
setblock 11 125 396 minecraft:light[level=14]
setblock 11 125 404 minecraft:light[level=14]
setblock 19 125 372 minecraft:light[level=14]
setblock 19 125 380 minecraft:light[level=14]
setblock 19 125 388 minecraft:light[level=14]
setblock 19 125 396 minecraft:light[level=14]
setblock 19 125 404 minecraft:light[level=14]
setblock 27 125 372 minecraft:light[level=14]
setblock 27 125 380 minecraft:light[level=14]
setblock 27 125 388 minecraft:light[level=14]
setblock 27 125 396 minecraft:light[level=14]
setblock 27 125 404 minecraft:light[level=14]
setblock 35 125 372 minecraft:light[level=14]
setblock 35 125 380 minecraft:light[level=14]
setblock 35 125 388 minecraft:light[level=14]
setblock 35 125 396 minecraft:light[level=14]
setblock 35 125 404 minecraft:light[level=14]
setblock 1 126 372 minecraft:gray_concrete
fill 1 126 374 1 126 377 minecraft:gray_concrete
setblock 1 126 382 minecraft:gray_concrete
fill 1 126 384 1 126 387 minecraft:gray_concrete
setblock 1 126 392 minecraft:gray_concrete
fill 1 126 394 1 126 397 minecraft:gray_concrete
setblock 1 126 402 minecraft:gray_concrete
fill 1 126 404 1 126 407 minecraft:gray_concrete
fill 2 126 370 5 126 370 minecraft:gray_concrete
setblock 3 126 410 minecraft:gray_concrete
fill 5 126 410 8 126 410 minecraft:gray_concrete
setblock 7 126 370 minecraft:gray_concrete
fill 12 126 370 15 126 370 minecraft:gray_concrete
setblock 13 126 410 minecraft:gray_concrete
fill 15 126 410 18 126 410 minecraft:gray_concrete
setblock 17 126 370 minecraft:gray_concrete
fill 22 126 370 25 126 370 minecraft:gray_concrete
setblock 23 126 410 minecraft:gray_concrete
fill 25 126 410 28 126 410 minecraft:gray_concrete
setblock 27 126 370 minecraft:gray_concrete
fill 32 126 370 35 126 370 minecraft:gray_concrete
setblock 33 126 410 minecraft:gray_concrete
fill 35 126 410 38 126 410 minecraft:gray_concrete
setblock 37 126 370 minecraft:gray_concrete
fill 41 126 371 41 126 374 minecraft:gray_concrete
setblock 41 126 376 minecraft:gray_concrete
fill 41 126 381 41 126 384 minecraft:gray_concrete
setblock 41 126 386 minecraft:gray_concrete
fill 41 126 391 41 126 394 minecraft:gray_concrete
setblock 41 126 396 minecraft:gray_concrete
fill 41 126 401 41 126 404 minecraft:gray_concrete
setblock 41 126 406 minecraft:gray_concrete
fill 17 129 375 18 130 376 minecraft:light_blue_stained_glass
fill 0 130 375 0 130 378 minecraft:sea_lantern
fill 0 130 385 0 130 388 minecraft:sea_lantern
fill 0 130 395 0 130 398 minecraft:sea_lantern
fill 0 130 405 0 130 408 minecraft:sea_lantern
fill 1 130 382 1 130 383 minecraft:gray_concrete
fill 2 130 380 4 130 380 minecraft:gray_concrete
fill 2 130 384 4 130 384 minecraft:gray_concrete
fill 3 130 369 6 130 369 minecraft:sea_lantern
fill 4 130 411 7 130 411 minecraft:sea_lantern
fill 5 130 381 5 130 383 minecraft:gray_concrete
fill 13 130 369 16 130 369 minecraft:sea_lantern
fill 14 130 411 17 130 411 minecraft:sea_lantern
fill 23 130 369 26 130 369 minecraft:sea_lantern
fill 24 130 411 27 130 411 minecraft:sea_lantern
fill 33 130 369 36 130 369 minecraft:sea_lantern
fill 34 130 411 37 130 411 minecraft:sea_lantern
setblock 35 130 372 minecraft:gray_concrete
setblock 35 130 374 minecraft:gray_concrete
setblock 37 130 372 minecraft:gray_concrete
setblock 37 130 374 minecraft:gray_concrete
fill 42 130 370 42 130 373 minecraft:sea_lantern
fill 42 130 380 42 130 383 minecraft:sea_lantern
fill 42 130 390 42 130 393 minecraft:sea_lantern
fill 42 130 400 42 130 403 minecraft:sea_lantern
setblock 42 130 410 minecraft:sea_lantern
fill 0 131 375 0 147 378 minecraft:blue_terracotta
fill 0 131 385 0 147 388 minecraft:blue_terracotta
fill 0 131 395 0 147 398 minecraft:blue_terracotta
fill 0 131 405 0 147 408 minecraft:blue_terracotta
fill 3 131 369 6 147 369 minecraft:blue_terracotta
fill 4 131 411 7 147 411 minecraft:blue_terracotta
fill 13 131 369 16 147 369 minecraft:blue_terracotta
fill 14 131 411 17 147 411 minecraft:blue_terracotta
fill 23 131 369 26 147 369 minecraft:blue_terracotta
fill 24 131 411 27 147 411 minecraft:blue_terracotta
fill 33 131 369 36 147 369 minecraft:blue_terracotta
fill 34 131 411 37 147 411 minecraft:blue_terracotta
fill 42 131 370 42 147 373 minecraft:blue_terracotta
fill 42 131 380 42 147 383 minecraft:blue_terracotta
fill 42 131 390 42 147 393 minecraft:blue_terracotta
fill 42 131 400 42 147 403 minecraft:blue_terracotta
fill 42 131 410 42 147 410 minecraft:blue_terracotta
setblock 1 132 372 minecraft:gray_concrete
setblock 1 132 382 minecraft:gray_concrete
setblock 1 132 392 minecraft:gray_concrete
setblock 1 132 402 minecraft:gray_concrete
setblock 3 132 410 minecraft:gray_concrete
setblock 7 132 370 minecraft:gray_concrete
setblock 13 132 410 minecraft:gray_concrete
setblock 17 132 370 minecraft:gray_concrete
setblock 23 132 410 minecraft:gray_concrete
setblock 27 132 370 minecraft:gray_concrete
setblock 33 132 410 minecraft:gray_concrete
setblock 37 132 370 minecraft:gray_concrete
setblock 41 132 376 minecraft:gray_concrete
setblock 41 132 386 minecraft:gray_concrete
setblock 41 132 396 minecraft:gray_concrete
setblock 41 132 406 minecraft:gray_concrete
setblock 3 133 372 minecraft:light[level=14]
setblock 3 133 380 minecraft:light[level=14]
setblock 3 133 388 minecraft:light[level=14]
setblock 3 133 396 minecraft:light[level=14]
setblock 3 133 404 minecraft:light[level=14]
setblock 11 133 372 minecraft:light[level=14]
setblock 11 133 380 minecraft:light[level=14]
setblock 11 133 388 minecraft:light[level=14]
setblock 11 133 396 minecraft:light[level=14]
setblock 11 133 404 minecraft:light[level=14]
setblock 19 133 372 minecraft:light[level=14]
setblock 19 133 380 minecraft:light[level=14]
setblock 19 133 388 minecraft:light[level=14]
setblock 19 133 396 minecraft:light[level=14]
setblock 19 133 404 minecraft:light[level=14]
setblock 27 133 372 minecraft:light[level=14]
setblock 27 133 380 minecraft:light[level=14]
setblock 27 133 388 minecraft:light[level=14]
setblock 27 133 396 minecraft:light[level=14]
setblock 27 133 404 minecraft:light[level=14]
setblock 35 133 372 minecraft:light[level=14]
setblock 35 133 380 minecraft:light[level=14]
setblock 35 133 388 minecraft:light[level=14]
setblock 35 133 396 minecraft:light[level=14]
setblock 35 133 404 minecraft:light[level=14]
fill 1 135 374 1 135 377 minecraft:gray_concrete
fill 1 135 384 1 135 387 minecraft:gray_concrete
fill 1 135 394 1 135 397 minecraft:gray_concrete
fill 1 135 404 1 135 407 minecraft:gray_concrete
fill 2 135 370 5 135 370 minecraft:gray_concrete
fill 5 135 410 8 135 410 minecraft:gray_concrete
fill 12 135 370 15 135 370 minecraft:gray_concrete
fill 15 135 410 18 135 410 minecraft:gray_concrete
fill 22 135 370 25 135 370 minecraft:gray_concrete
fill 25 135 410 28 135 410 minecraft:gray_concrete
fill 32 135 370 35 135 370 minecraft:gray_concrete
fill 35 135 410 38 135 410 minecraft:gray_concrete
fill 41 135 371 41 135 374 minecraft:gray_concrete
fill 41 135 381 41 135 384 minecraft:gray_concrete
fill 41 135 391 41 135 394 minecraft:gray_concrete
fill 41 135 401 41 135 404 minecraft:gray_concrete
fill 1 136 382 1 136 383 minecraft:gray_concrete
fill 2 136 380 4 136 380 minecraft:gray_concrete
fill 2 136 384 4 136 384 minecraft:gray_concrete
fill 5 136 381 5 136 383 minecraft:gray_concrete
setblock 35 136 372 minecraft:gray_concrete
setblock 35 136 374 minecraft:gray_concrete
setblock 37 136 372 minecraft:gray_concrete
setblock 37 136 374 minecraft:gray_concrete
setblock 3 141 372 minecraft:light[level=14]
setblock 3 141 380 minecraft:light[level=14]
setblock 3 141 388 minecraft:light[level=14]
setblock 3 141 396 minecraft:light[level=14]
setblock 3 141 404 minecraft:light[level=14]
setblock 11 141 372 minecraft:light[level=14]
setblock 11 141 380 minecraft:light[level=14]
setblock 11 141 388 minecraft:light[level=14]
setblock 11 141 396 minecraft:light[level=14]
setblock 11 141 404 minecraft:light[level=14]
setblock 19 141 372 minecraft:light[level=14]
setblock 19 141 380 minecraft:light[level=14]
setblock 19 141 388 minecraft:light[level=14]
setblock 19 141 396 minecraft:light[level=14]
setblock 19 141 404 minecraft:light[level=14]
setblock 27 141 372 minecraft:light[level=14]
setblock 27 141 380 minecraft:light[level=14]
setblock 27 141 388 minecraft:light[level=14]
setblock 27 141 396 minecraft:light[level=14]
setblock 27 141 404 minecraft:light[level=14]
setblock 35 141 372 minecraft:light[level=14]
setblock 35 141 380 minecraft:light[level=14]
setblock 35 141 388 minecraft:light[level=14]
setblock 35 141 396 minecraft:light[level=14]
setblock 35 141 404 minecraft:light[level=14]
fill 12 143 389 18 143 389 minecraft:iron_block
fill 13 143 386 13 144 388 minecraft:iron_block
fill 13 143 393 26 144 393 minecraft:iron_block
fill 14 143 387 18 143 388 minecraft:iron_block
fill 14 143 392 27 143 392 minecraft:iron_block
fill 14 143 394 26 144 394 minecraft:iron_block
fill 15 143 383 24 144 383 minecraft:iron_block
fill 15 143 386 28 143 386 minecraft:iron_block
fill 15 143 390 18 143 391 minecraft:iron_block
fill 15 143 395 15 144 395 minecraft:iron_block
fill 16 143 382 18 144 382 minecraft:iron_block
fill 16 143 384 28 143 385 minecraft:iron_block
fill 17 143 381 17 144 381 minecraft:iron_block
fill 18 143 395 27 144 395 minecraft:iron_block
fill 18 143 397 21 144 397 minecraft:iron_block
setblock 19 143 387 minecraft:iron_block
setblock 19 143 391 minecraft:iron_block
fill 19 143 396 21 144 396 minecraft:iron_block
fill 21 143 380 21 144 382 minecraft:iron_block
fill 21 143 398 21 144 398 minecraft:iron_block
fill 22 143 381 23 144 382 minecraft:iron_block
fill 23 143 387 27 143 387 minecraft:iron_block
fill 23 143 391 29 143 391 minecraft:iron_block
fill 24 143 381 24 144 381 minecraft:iron_block
fill 24 143 388 27 143 390 minecraft:iron_block
fill 24 143 396 26 144 396 minecraft:iron_block
fill 25 143 397 25 144 397 minecraft:iron_block
fill 27 143 383 27 144 383 minecraft:iron_block
fill 28 143 389 29 144 390 minecraft:iron_block
fill 29 143 385 29 144 385 minecraft:iron_block
fill 29 143 392 29 144 392 minecraft:iron_block
fill 30 143 389 30 144 389 minecraft:iron_block
fill 1 144 370 12 144 410 minecraft:iron_block
fill 13 144 370 14 144 385 minecraft:iron_block
fill 13 144 389 16 144 392 minecraft:iron_block
fill 13 144 394 13 144 410 minecraft:iron_block
fill 14 144 386 17 144 388 minecraft:iron_block
fill 14 144 395 14 144 410 minecraft:iron_block
fill 15 144 370 15 144 382 minecraft:iron_block
fill 15 144 384 18 144 385 minecraft:iron_block
fill 15 144 396 17 144 410 minecraft:iron_block
fill 16 144 370 16 144 381 minecraft:iron_block
fill 16 144 395 17 144 395 minecraft:iron_block
fill 17 144 370 20 144 380 minecraft:iron_block
setblock 17 144 389 minecraft:iron_block
fill 17 144 390 17 144 391 minecraft:red_concrete
setblock 17 144 392 minecraft:iron_block
fill 18 144 381 20 144 381 minecraft:iron_block
setblock 18 144 386 minecraft:iron_block
fill 18 144 387 18 144 391 minecraft:sea_lantern
setblock 18 144 392 minecraft:red_concrete
setblock 18 144 396 minecraft:iron_block
fill 18 144 398 20 144 410 minecraft:iron_block
fill 19 144 382 20 144 382 minecraft:iron_block
fill 19 144 384 41 144 384 minecraft:iron_block
fill 19 144 385 23 144 385 minecraft:red_concrete
fill 19 144 386 19 144 387 minecraft:sea_lantern
fill 19 144 391 19 144 392 minecraft:sea_lantern
fill 20 144 386 23 144 386 minecraft:sea_lantern
fill 20 144 392 23 144 392 minecraft:sea_lantern
fill 21 144 370 41 144 379 minecraft:iron_block
fill 21 144 399 41 144 410 minecraft:iron_block
fill 22 144 380 41 144 380 minecraft:iron_block
fill 22 144 396 23 144 398 minecraft:iron_block
fill 23 144 387 24 144 387 minecraft:sea_lantern
fill 23 144 391 24 144 391 minecraft:sea_lantern
fill 24 144 382 41 144 382 minecraft:iron_block
fill 24 144 385 28 144 386 minecraft:iron_block
fill 24 144 388 24 144 390 minecraft:sea_lantern
setblock 24 144 392 minecraft:red_concrete
fill 24 144 397 24 144 398 minecraft:iron_block
fill 25 144 381 41 144 381 minecraft:iron_block
fill 25 144 383 26 144 383 minecraft:iron_block
fill 25 144 387 41 144 388 minecraft:iron_block
fill 25 144 389 25 144 391 minecraft:red_concrete
fill 25 144 392 28 144 392 minecraft:iron_block
fill 25 144 398 41 144 398 minecraft:iron_block
fill 26 144 389 27 144 391 minecraft:iron_block
fill 26 144 397 41 144 397 minecraft:iron_block
fill 27 144 393 41 144 394 minecraft:iron_block
fill 27 144 396 41 144 396 minecraft:iron_block
fill 28 144 383 41 144 383 minecraft:iron_block
fill 28 144 391 41 144 391 minecraft:iron_block
fill 28 144 395 41 144 395 minecraft:iron_block
fill 29 144 386 41 144 386 minecraft:iron_block
fill 30 144 385 41 144 385 minecraft:iron_block
fill 30 144 390 41 144 390 minecraft:iron_block
fill 30 144 392 41 144 392 minecraft:iron_block
fill 31 144 389 41 144 389 minecraft:iron_block
fill 7 145 389 9 159 389 minecraft:pink_concrete
fill 8 145 388 8 159 388 minecraft:pink_concrete
fill 8 145 390 8 159 390 minecraft:pink_concrete
fill 11 145 379 12 159 380 minecraft:light_blue_concrete
fill 11 145 398 12 159 399 minecraft:light_blue_concrete
fill 20 145 376 22 159 376 minecraft:pink_concrete
fill 20 145 402 22 159 402 minecraft:pink_concrete
fill 21 145 375 21 159 375 minecraft:pink_concrete
fill 21 145 377 21 159 377 minecraft:pink_concrete
fill 21 145 401 21 159 401 minecraft:pink_concrete
fill 21 145 403 21 159 403 minecraft:pink_concrete
fill 30 145 379 31 159 380 minecraft:light_blue_concrete
fill 30 145 398 31 159 399 minecraft:light_blue_concrete
fill 33 145 389 35 159 389 minecraft:pink_concrete
fill 34 145 388 34 159 388 minecraft:pink_concrete
fill 34 145 390 34 159 390 minecraft:pink_concrete
fill 14 146 388 15 147 390 minecraft:magenta_concrete
fill 15 146 386 15 147 387 minecraft:magenta_concrete
fill 15 146 391 15 147 392 minecraft:magenta_concrete
fill 16 146 384 16 147 385 minecraft:magenta_concrete
fill 16 146 393 16 147 394 minecraft:magenta_concrete
fill 17 146 384 17 147 384 minecraft:magenta_concrete
fill 17 146 394 17 147 394 minecraft:magenta_concrete
fill 18 146 383 24 147 383 minecraft:magenta_concrete
fill 18 146 395 24 147 395 minecraft:magenta_concrete
fill 20 146 382 22 147 382 minecraft:magenta_concrete
fill 20 146 396 22 147 396 minecraft:magenta_concrete
fill 25 146 384 26 147 384 minecraft:magenta_concrete
fill 25 146 394 26 147 394 minecraft:magenta_concrete
fill 26 146 385 26 147 385 minecraft:magenta_concrete
fill 26 146 393 26 147 393 minecraft:magenta_concrete
fill 27 146 386 27 147 392 minecraft:magenta_concrete
fill 28 146 388 28 147 390 minecraft:magenta_concrete
fill 0 148 375 0 148 378 minecraft:sea_lantern
fill 0 148 385 0 148 388 minecraft:sea_lantern
fill 0 148 395 0 148 398 minecraft:sea_lantern
fill 0 148 405 0 148 408 minecraft:sea_lantern
fill 1 148 371 1 212 371 minecraft:iron_block
fill 1 148 381 1 212 381 minecraft:iron_block
fill 1 148 391 1 212 391 minecraft:iron_block
fill 1 148 401 1 212 401 minecraft:iron_block
fill 2 148 410 2 212 410 minecraft:iron_block
fill 3 148 369 6 148 369 minecraft:sea_lantern
fill 4 148 411 7 148 411 minecraft:sea_lantern
fill 5 148 407 5 212 407 minecraft:iron_block
fill 8 148 370 8 212 370 minecraft:iron_block
fill 9 148 405 11 212 407 minecraft:iron_block
fill 12 148 390 13 149 391 minecraft:white_stained_glass
fill 12 148 410 12 212 410 minecraft:iron_block
fill 13 148 369 16 148 369 minecraft:sea_lantern
fill 14 148 411 17 148 411 minecraft:sea_lantern
fill 18 148 370 18 212 370 minecraft:iron_block
fill 22 148 410 22 212 410 minecraft:iron_block
fill 23 148 369 26 148 369 minecraft:sea_lantern
fill 24 148 411 27 148 411 minecraft:sea_lantern
fill 28 148 370 28 212 370 minecraft:iron_block
fill 32 148 410 32 212 410 minecraft:iron_block
fill 33 148 369 36 148 369 minecraft:sea_lantern
fill 34 148 411 37 148 411 minecraft:sea_lantern
fill 38 148 370 38 212 370 minecraft:iron_block
fill 41 148 377 41 212 377 minecraft:iron_block
fill 41 148 387 41 212 387 minecraft:iron_block
fill 41 148 397 41 212 397 minecraft:iron_block
fill 41 148 407 41 212 407 minecraft:iron_block
fill 42 148 370 42 148 373 minecraft:sea_lantern
fill 42 148 380 42 148 383 minecraft:sea_lantern
fill 42 148 390 42 148 393 minecraft:sea_lantern
fill 42 148 400 42 148 403 minecraft:sea_lantern
setblock 42 148 410 minecraft:sea_lantern
fill 0 149 375 0 156 378 minecraft:blue_terracotta
fill 0 149 385 0 156 388 minecraft:blue_terracotta
fill 0 149 395 0 156 398 minecraft:blue_terracotta
fill 0 149 405 0 156 408 minecraft:blue_terracotta
fill 3 149 369 6 156 369 minecraft:blue_terracotta
setblock 3 149 372 minecraft:light[level=14]
setblock 3 149 380 minecraft:light[level=14]
setblock 3 149 388 minecraft:light[level=14]
setblock 3 149 396 minecraft:light[level=14]
setblock 3 149 404 minecraft:light[level=14]
fill 4 149 411 7 156 411 minecraft:blue_terracotta
setblock 11 149 372 minecraft:light[level=14]
setblock 11 149 388 minecraft:light[level=14]
setblock 11 149 396 minecraft:light[level=14]
setblock 11 149 404 minecraft:light[level=14]
fill 13 149 369 16 156 369 minecraft:blue_terracotta
fill 14 149 411 17 156 411 minecraft:blue_terracotta
setblock 19 149 372 minecraft:light[level=14]
setblock 19 149 380 minecraft:light[level=14]
setblock 19 149 388 minecraft:light[level=14]
setblock 19 149 396 minecraft:light[level=14]
setblock 19 149 404 minecraft:light[level=14]
fill 23 149 369 26 156 369 minecraft:blue_terracotta
fill 24 149 411 27 156 411 minecraft:blue_terracotta
setblock 27 149 372 minecraft:light[level=14]
setblock 27 149 380 minecraft:light[level=14]
setblock 27 149 388 minecraft:light[level=14]
setblock 27 149 396 minecraft:light[level=14]
setblock 27 149 404 minecraft:light[level=14]
fill 33 149 369 36 156 369 minecraft:blue_terracotta
fill 34 149 411 37 156 411 minecraft:blue_terracotta
setblock 35 149 372 minecraft:light[level=14]
setblock 35 149 380 minecraft:light[level=14]
setblock 35 149 388 minecraft:light[level=14]
setblock 35 149 396 minecraft:light[level=14]
setblock 35 149 404 minecraft:light[level=14]
fill 42 149 370 42 156 373 minecraft:blue_terracotta
fill 42 149 380 42 156 383 minecraft:blue_terracotta
fill 42 149 390 42 156 393 minecraft:blue_terracotta
fill 42 149 400 42 156 403 minecraft:blue_terracotta
fill 42 149 410 42 156 410 minecraft:blue_terracotta
setblock 1 150 372 minecraft:gray_concrete
setblock 1 150 382 minecraft:gray_concrete
setblock 1 150 392 minecraft:gray_concrete
setblock 1 150 402 minecraft:gray_concrete
setblock 3 150 410 minecraft:gray_concrete
fill 4 150 406 4 150 408 minecraft:gray_concrete
fill 5 150 406 6 150 406 minecraft:gray_concrete
fill 5 150 408 6 150 408 minecraft:gray_concrete
setblock 6 150 407 minecraft:gray_concrete
setblock 7 150 370 minecraft:gray_concrete
fill 8 150 405 8 150 407 minecraft:gray_concrete
fill 9 150 404 11 150 404 minecraft:gray_concrete
fill 9 150 408 11 150 408 minecraft:gray_concrete
fill 12 150 388 13 151 390 minecraft:cyan_concrete
fill 12 150 405 12 150 407 minecraft:gray_concrete
fill 13 150 385 13 151 387 minecraft:cyan_concrete
fill 13 150 391 13 151 393 minecraft:cyan_concrete
setblock 13 150 410 minecraft:gray_concrete
fill 14 150 384 14 151 385 minecraft:cyan_concrete
fill 14 150 393 14 151 394 minecraft:cyan_concrete
fill 15 150 383 15 151 383 minecraft:cyan_concrete
fill 15 150 395 15 151 395 minecraft:cyan_concrete
fill 16 150 382 17 151 382 minecraft:cyan_concrete
fill 16 150 396 17 151 396 minecraft:cyan_concrete
setblock 17 150 370 minecraft:gray_concrete
fill 17 150 381 25 151 381 minecraft:cyan_concrete
fill 17 150 397 25 151 397 minecraft:cyan_concrete
fill 20 150 380 22 151 380 minecraft:cyan_concrete
fill 20 150 398 22 151 398 minecraft:cyan_concrete
setblock 23 150 410 minecraft:gray_concrete
fill 25 150 382 26 151 382 minecraft:cyan_concrete
fill 25 150 396 26 151 396 minecraft:cyan_concrete
setblock 27 150 370 minecraft:gray_concrete
fill 27 150 383 27 151 383 minecraft:cyan_concrete
fill 27 150 395 27 151 395 minecraft:cyan_concrete
fill 28 150 384 28 151 385 minecraft:cyan_concrete
fill 28 150 393 28 151 394 minecraft:cyan_concrete
fill 29 150 385 29 151 393 minecraft:cyan_concrete
fill 30 150 388 30 151 390 minecraft:cyan_concrete
setblock 33 150 410 minecraft:gray_concrete
setblock 37 150 370 minecraft:gray_concrete
setblock 41 150 376 minecraft:gray_concrete
setblock 41 150 386 minecraft:gray_concrete
setblock 41 150 396 minecraft:gray_concrete
setblock 41 150 406 minecraft:gray_concrete
fill 1 153 374 1 153 377 minecraft:gray_concrete
fill 1 153 384 1 153 387 minecraft:gray_concrete
fill 1 153 394 1 153 397 minecraft:gray_concrete
fill 1 153 404 1 153 407 minecraft:gray_concrete
fill 2 153 370 5 153 370 minecraft:gray_concrete
fill 5 153 410 8 153 410 minecraft:gray_concrete
fill 12 153 370 15 153 370 minecraft:gray_concrete
fill 15 153 410 18 153 410 minecraft:gray_concrete
fill 22 153 370 25 153 370 minecraft:gray_concrete
fill 25 153 410 28 153 410 minecraft:gray_concrete
fill 32 153 370 35 153 370 minecraft:gray_concrete
fill 35 153 410 38 153 410 minecraft:gray_concrete
fill 41 153 371 41 153 374 minecraft:gray_concrete
fill 41 153 381 41 153 384 minecraft:gray_concrete
fill 41 153 391 41 153 394 minecraft:gray_concrete
fill 41 153 401 41 153 404 minecraft:gray_concrete
fill 10 154 388 11 155 390 minecraft:lime_concrete
fill 11 154 385 11 155 387 minecraft:lime_concrete
fill 11 154 391 11 155 393 minecraft:lime_concrete
fill 12 154 383 12 155 384 minecraft:lime_concrete
fill 12 154 394 12 155 395 minecraft:lime_concrete
fill 13 154 382 13 155 383 minecraft:lime_concrete
fill 13 154 395 13 155 396 minecraft:lime_concrete
fill 14 154 381 14 155 382 minecraft:lime_concrete
fill 14 154 396 14 155 397 minecraft:lime_concrete
fill 15 154 380 15 155 381 minecraft:lime_concrete
fill 15 154 397 15 155 398 minecraft:lime_concrete
fill 16 154 380 16 155 380 minecraft:lime_concrete
fill 16 154 398 16 155 398 minecraft:lime_concrete
fill 17 154 379 25 155 379 minecraft:lime_concrete
fill 17 154 399 25 155 399 minecraft:lime_concrete
fill 20 154 378 22 155 378 minecraft:lime_concrete
fill 20 154 400 22 155 400 minecraft:lime_concrete
fill 26 154 380 27 155 380 minecraft:lime_concrete
fill 26 154 398 27 155 398 minecraft:lime_concrete
fill 27 154 381 28 155 381 minecraft:lime_concrete
fill 27 154 397 28 155 397 minecraft:lime_concrete
fill 28 154 382 29 155 382 minecraft:lime_concrete
fill 28 154 396 29 155 396 minecraft:lime_concrete
fill 29 154 383 30 155 383 minecraft:lime_concrete
fill 29 154 395 30 155 395 minecraft:lime_concrete
fill 30 154 384 30 155 384 minecraft:lime_concrete
fill 30 154 394 30 155 394 minecraft:lime_concrete
fill 31 154 385 31 155 393 minecraft:lime_concrete
fill 32 154 388 32 155 390 minecraft:lime_concrete
fill 8 155 405 8 155 407 minecraft:gray_concrete
fill 9 155 404 11 155 404 minecraft:gray_concrete
fill 9 155 408 11 155 408 minecraft:gray_concrete
fill 12 155 405 12 155 407 minecraft:gray_concrete
setblock 1 156 372 minecraft:gray_concrete
setblock 1 156 382 minecraft:gray_concrete
setblock 1 156 392 minecraft:gray_concrete
setblock 1 156 402 minecraft:gray_concrete
setblock 3 156 410 minecraft:gray_concrete
fill 4 156 406 4 156 408 minecraft:gray_concrete
fill 5 156 406 6 156 406 minecraft:gray_concrete
fill 5 156 408 6 156 408 minecraft:gray_concrete
setblock 6 156 407 minecraft:gray_concrete
setblock 7 156 370 minecraft:gray_concrete
setblock 13 156 410 minecraft:gray_concrete
setblock 17 156 370 minecraft:gray_concrete
setblock 23 156 410 minecraft:gray_concrete
setblock 27 156 370 minecraft:gray_concrete
setblock 33 156 410 minecraft:gray_concrete
setblock 37 156 370 minecraft:gray_concrete
setblock 41 156 376 minecraft:gray_concrete
setblock 41 156 386 minecraft:gray_concrete
setblock 41 156 396 minecraft:gray_concrete
setblock 41 156 406 minecraft:gray_concrete
fill 0 157 375 0 157 378 minecraft:sea_lantern
fill 0 157 385 0 157 388 minecraft:sea_lantern
fill 0 157 395 0 157 398 minecraft:sea_lantern
fill 0 157 405 0 157 408 minecraft:sea_lantern
fill 3 157 369 6 157 369 minecraft:sea_lantern
setblock 3 157 372 minecraft:light[level=14]
setblock 3 157 380 minecraft:light[level=14]
setblock 3 157 388 minecraft:light[level=14]
setblock 3 157 396 minecraft:light[level=14]
setblock 3 157 404 minecraft:light[level=14]
fill 4 157 411 7 157 411 minecraft:sea_lantern
setblock 11 157 372 minecraft:light[level=14]
setblock 11 157 388 minecraft:light[level=14]
setblock 11 157 396 minecraft:light[level=14]
setblock 11 157 404 minecraft:light[level=14]
fill 13 157 369 16 157 369 minecraft:sea_lantern
fill 14 157 411 17 157 411 minecraft:sea_lantern
setblock 19 157 372 minecraft:light[level=14]
setblock 19 157 380 minecraft:light[level=14]
setblock 19 157 388 minecraft:light[level=14]
setblock 19 157 396 minecraft:light[level=14]
setblock 19 157 404 minecraft:light[level=14]
fill 23 157 369 26 157 369 minecraft:sea_lantern
fill 24 157 411 27 157 411 minecraft:sea_lantern
setblock 27 157 372 minecraft:light[level=14]
setblock 27 157 380 minecraft:light[level=14]
setblock 27 157 388 minecraft:light[level=14]
setblock 27 157 396 minecraft:light[level=14]
setblock 27 157 404 minecraft:light[level=14]
fill 33 157 369 36 157 369 minecraft:sea_lantern
fill 34 157 411 37 157 411 minecraft:sea_lantern
setblock 35 157 372 minecraft:light[level=14]
setblock 35 157 380 minecraft:light[level=14]
setblock 35 157 388 minecraft:light[level=14]
setblock 35 157 396 minecraft:light[level=14]
setblock 35 157 404 minecraft:light[level=14]
fill 42 157 370 42 157 373 minecraft:sea_lantern
fill 42 157 380 42 157 383 minecraft:sea_lantern
fill 42 157 390 42 157 393 minecraft:sea_lantern
fill 42 157 400 42 157 403 minecraft:sea_lantern
setblock 42 157 410 minecraft:sea_lantern
fill 0 158 375 0 165 378 minecraft:blue_terracotta
fill 0 158 385 0 165 388 minecraft:blue_terracotta
fill 0 158 395 0 165 398 minecraft:blue_terracotta
fill 0 158 405 0 165 408 minecraft:blue_terracotta
fill 3 158 369 6 165 369 minecraft:blue_terracotta
fill 4 158 411 7 165 411 minecraft:blue_terracotta
fill 13 158 369 16 165 369 minecraft:blue_terracotta
fill 14 158 411 17 165 411 minecraft:blue_terracotta
fill 23 158 369 26 165 369 minecraft:blue_terracotta
fill 24 158 411 27 165 411 minecraft:blue_terracotta
fill 29 158 382 29 159 382 minecraft:white_stained_glass
fill 33 158 369 36 165 369 minecraft:blue_terracotta
fill 34 158 411 37 165 411 minecraft:blue_terracotta
fill 42 158 370 42 165 373 minecraft:blue_terracotta
fill 42 158 380 42 165 383 minecraft:blue_terracotta
fill 42 158 390 42 165 393 minecraft:blue_terracotta
fill 42 158 400 42 165 403 minecraft:blue_terracotta
fill 42 158 410 42 165 410 minecraft:blue_terracotta
fill 3 160 386 3 161 386 minecraft:light_blue_stained_glass
fill 7 160 389 9 160 389 minecraft:glowstone
setblock 8 160 388 minecraft:glowstone
setblock 8 160 390 minecraft:glowstone
fill 8 160 405 8 160 407 minecraft:gray_concrete
fill 9 160 404 11 160 404 minecraft:gray_concrete
fill 9 160 408 11 160 408 minecraft:gray_concrete
fill 11 160 379 12 160 380 minecraft:glowstone
fill 11 160 398 12 160 399 minecraft:glowstone
setblock 12 160 381 minecraft:glowstone
setblock 12 160 397 minecraft:glowstone
fill 12 160 405 12 160 407 minecraft:gray_concrete
setblock 13 160 380 minecraft:glowstone
setblock 13 160 398 minecraft:glowstone
fill 20 160 376 22 160 376 minecraft:glowstone
fill 20 160 402 22 160 402 minecraft:glowstone
setblock 21 160 375 minecraft:glowstone
setblock 21 160 377 minecraft:glowstone
setblock 21 160 401 minecraft:glowstone
setblock 21 160 403 minecraft:glowstone
fill 29 160 380 31 160 380 minecraft:glowstone
fill 29 160 398 31 160 398 minecraft:glowstone
fill 30 160 379 31 160 379 minecraft:glowstone
setblock 30 160 381 minecraft:glowstone
setblock 30 160 397 minecraft:glowstone
fill 30 160 399 31 160 399 minecraft:glowstone
fill 33 160 389 35 160 389 minecraft:glowstone
setblock 34 160 388 minecraft:glowstone
setblock 34 160 390 minecraft:glowstone
fill 5 161 408 5 161 410 minecraft:iron_block
setblock 1 162 372 minecraft:gray_concrete
fill 1 162 374 1 162 377 minecraft:gray_concrete
setblock 1 162 382 minecraft:gray_concrete
fill 1 162 384 1 162 387 minecraft:gray_concrete
setblock 1 162 392 minecraft:gray_concrete
fill 1 162 394 1 162 397 minecraft:gray_concrete
setblock 1 162 402 minecraft:gray_concrete
fill 1 162 404 1 162 407 minecraft:gray_concrete
fill 2 162 370 5 162 370 minecraft:gray_concrete
setblock 3 162 410 minecraft:gray_concrete
fill 4 162 406 4 162 408 minecraft:gray_concrete
fill 5 162 406 6 162 406 minecraft:gray_concrete
fill 5 162 408 6 162 408 minecraft:gray_concrete
setblock 5 162 409 minecraft:iron_block
fill 5 162 410 8 162 410 minecraft:gray_concrete
setblock 6 162 407 minecraft:gray_concrete
setblock 7 162 370 minecraft:gray_concrete
fill 12 162 370 15 162 370 minecraft:gray_concrete
setblock 13 162 410 minecraft:gray_concrete
fill 15 162 410 18 162 410 minecraft:gray_concrete
setblock 17 162 370 minecraft:gray_concrete
fill 22 162 370 25 162 370 minecraft:gray_concrete
setblock 23 162 410 minecraft:gray_concrete
fill 25 162 410 28 162 410 minecraft:gray_concrete
setblock 27 162 370 minecraft:gray_concrete
fill 32 162 370 35 162 370 minecraft:gray_concrete
setblock 33 162 410 minecraft:gray_concrete
fill 35 162 410 38 162 410 minecraft:gray_concrete
setblock 37 162 370 minecraft:gray_concrete
fill 41 162 371 41 162 374 minecraft:gray_concrete
setblock 41 162 376 minecraft:gray_concrete
fill 41 162 381 41 162 384 minecraft:gray_concrete
setblock 41 162 386 minecraft:gray_concrete
fill 41 162 391 41 162 394 minecraft:gray_concrete
setblock 41 162 396 minecraft:gray_concrete
fill 41 162 401 41 162 404 minecraft:gray_concrete
setblock 41 162 406 minecraft:gray_concrete
fill 11 163 403 11 174 403 minecraft:iron_block
setblock 3 165 372 minecraft:light[level=14]
setblock 3 165 380 minecraft:light[level=14]
setblock 3 165 388 minecraft:light[level=14]
setblock 3 165 396 minecraft:light[level=14]
setblock 3 165 404 minecraft:light[level=14]
fill 8 165 405 8 165 407 minecraft:gray_concrete
fill 9 165 404 11 165 404 minecraft:gray_concrete
fill 9 165 408 11 165 408 minecraft:gray_concrete
setblock 11 165 372 minecraft:light[level=14]
setblock 11 165 380 minecraft:light[level=14]
setblock 11 165 388 minecraft:light[level=14]
setblock 11 165 396 minecraft:light[level=14]
fill 12 165 405 12 165 407 minecraft:gray_concrete
setblock 19 165 372 minecraft:light[level=14]
setblock 19 165 380 minecraft:light[level=14]
setblock 19 165 388 minecraft:light[level=14]
setblock 19 165 396 minecraft:light[level=14]
setblock 19 165 404 minecraft:light[level=14]
setblock 27 165 372 minecraft:light[level=14]
setblock 27 165 380 minecraft:light[level=14]
setblock 27 165 388 minecraft:light[level=14]
setblock 27 165 396 minecraft:light[level=14]
setblock 27 165 404 minecraft:light[level=14]
setblock 35 165 372 minecraft:light[level=14]
setblock 35 165 380 minecraft:light[level=14]
setblock 35 165 388 minecraft:light[level=14]
setblock 35 165 396 minecraft:light[level=14]
setblock 35 165 404 minecraft:light[level=14]
fill 0 166 375 0 166 378 minecraft:sea_lantern
fill 0 166 385 0 166 388 minecraft:sea_lantern
fill 0 166 395 0 166 398 minecraft:sea_lantern
fill 0 166 405 0 166 408 minecraft:sea_lantern
fill 3 166 369 6 166 369 minecraft:sea_lantern
fill 4 166 411 7 166 411 minecraft:sea_lantern
fill 13 166 369 16 166 369 minecraft:sea_lantern
fill 14 166 411 17 166 411 minecraft:sea_lantern
fill 23 166 369 26 166 369 minecraft:sea_lantern
fill 24 166 411 27 166 411 minecraft:sea_lantern
fill 33 166 369 36 166 369 minecraft:sea_lantern
fill 34 166 411 37 166 411 minecraft:sea_lantern
fill 42 166 370 42 166 373 minecraft:sea_lantern
fill 42 166 380 42 166 383 minecraft:sea_lantern
fill 42 166 390 42 166 393 minecraft:sea_lantern
fill 42 166 400 42 166 403 minecraft:sea_lantern
setblock 42 166 410 minecraft:sea_lantern
fill 0 167 375 0 174 378 minecraft:blue_terracotta
fill 0 167 385 0 174 388 minecraft:blue_terracotta
fill 0 167 395 0 174 398 minecraft:blue_terracotta
fill 0 167 405 0 174 408 minecraft:blue_terracotta
fill 3 167 369 6 174 369 minecraft:blue_terracotta
fill 4 167 411 7 174 411 minecraft:blue_terracotta
fill 13 167 369 16 174 369 minecraft:blue_terracotta
fill 14 167 411 17 174 411 minecraft:blue_terracotta
fill 23 167 369 26 174 369 minecraft:blue_terracotta
fill 24 167 411 27 174 411 minecraft:blue_terracotta
fill 33 167 369 36 174 369 minecraft:blue_terracotta
fill 34 167 411 37 174 411 minecraft:blue_terracotta
fill 42 167 370 42 174 373 minecraft:blue_terracotta
fill 42 167 380 42 174 383 minecraft:blue_terracotta
fill 42 167 390 42 174 393 minecraft:blue_terracotta
fill 42 167 400 42 174 403 minecraft:blue_terracotta
fill 42 167 410 42 174 410 minecraft:blue_terracotta
setblock 1 168 372 minecraft:gray_concrete
setblock 1 168 382 minecraft:gray_concrete
setblock 1 168 392 minecraft:gray_concrete
setblock 1 168 402 minecraft:gray_concrete
setblock 3 168 410 minecraft:gray_concrete
fill 4 168 406 4 168 408 minecraft:gray_concrete
fill 5 168 406 6 168 406 minecraft:gray_concrete
fill 5 168 408 6 168 408 minecraft:gray_concrete
setblock 6 168 407 minecraft:gray_concrete
setblock 7 168 370 minecraft:gray_concrete
setblock 13 168 410 minecraft:gray_concrete
setblock 17 168 370 minecraft:gray_concrete
setblock 23 168 410 minecraft:gray_concrete
setblock 27 168 370 minecraft:gray_concrete
setblock 33 168 410 minecraft:gray_concrete
setblock 37 168 370 minecraft:gray_concrete
setblock 41 168 376 minecraft:gray_concrete
setblock 41 168 386 minecraft:gray_concrete
setblock 41 168 396 minecraft:gray_concrete
setblock 41 168 406 minecraft:gray_concrete
fill 8 170 405 8 170 407 minecraft:gray_concrete
fill 9 170 404 11 170 404 minecraft:gray_concrete
fill 9 170 408 11 170 408 minecraft:gray_concrete
fill 12 170 405 12 170 407 minecraft:gray_concrete
fill 1 171 374 1 171 377 minecraft:gray_concrete
fill 1 171 384 1 171 387 minecraft:gray_concrete
fill 1 171 394 1 171 397 minecraft:gray_concrete
fill 1 171 404 1 171 407 minecraft:gray_concrete
fill 2 171 370 5 171 370 minecraft:gray_concrete
fill 5 171 410 8 171 410 minecraft:gray_concrete
fill 12 171 370 15 171 370 minecraft:gray_concrete
fill 15 171 410 18 171 410 minecraft:gray_concrete
fill 22 171 370 25 171 370 minecraft:gray_concrete
fill 25 171 410 28 171 410 minecraft:gray_concrete
fill 32 171 370 35 171 370 minecraft:gray_concrete
fill 35 171 410 38 171 410 minecraft:gray_concrete
fill 41 171 371 41 171 374 minecraft:gray_concrete
fill 41 171 381 41 171 384 minecraft:gray_concrete
fill 41 171 391 41 171 394 minecraft:gray_concrete
fill 41 171 401 41 171 404 minecraft:gray_concrete
setblock 3 173 372 minecraft:light[level=14]
setblock 3 173 380 minecraft:light[level=14]
setblock 3 173 388 minecraft:light[level=14]
setblock 3 173 396 minecraft:light[level=14]
setblock 3 173 404 minecraft:light[level=14]
setblock 11 173 372 minecraft:light[level=14]
setblock 11 173 380 minecraft:light[level=14]
setblock 11 173 388 minecraft:light[level=14]
setblock 11 173 396 minecraft:light[level=14]
setblock 11 173 404 minecraft:light[level=14]
setblock 19 173 372 minecraft:light[level=14]
setblock 19 173 380 minecraft:light[level=14]
setblock 19 173 388 minecraft:light[level=14]
setblock 19 173 396 minecraft:light[level=14]
setblock 19 173 404 minecraft:light[level=14]
setblock 27 173 372 minecraft:light[level=14]
setblock 27 173 380 minecraft:light[level=14]
setblock 27 173 388 minecraft:light[level=14]
setblock 27 173 396 minecraft:light[level=14]
setblock 27 173 404 minecraft:light[level=14]
setblock 35 173 372 minecraft:light[level=14]
setblock 35 173 380 minecraft:light[level=14]
setblock 35 173 388 minecraft:light[level=14]
setblock 35 173 396 minecraft:light[level=14]
setblock 35 173 404 minecraft:light[level=14]
setblock 1 174 372 minecraft:gray_concrete
setblock 1 174 382 minecraft:gray_concrete
setblock 1 174 392 minecraft:gray_concrete
setblock 1 174 402 minecraft:gray_concrete
setblock 3 174 410 minecraft:gray_concrete
fill 4 174 406 4 174 408 minecraft:gray_concrete
fill 5 174 406 6 174 406 minecraft:gray_concrete
fill 5 174 408 6 174 408 minecraft:gray_concrete
setblock 6 174 407 minecraft:gray_concrete
setblock 7 174 370 minecraft:gray_concrete
setblock 13 174 410 minecraft:gray_concrete
setblock 17 174 370 minecraft:gray_concrete
setblock 23 174 410 minecraft:gray_concrete
setblock 27 174 370 minecraft:gray_concrete
setblock 33 174 410 minecraft:gray_concrete
setblock 37 174 370 minecraft:gray_concrete
setblock 41 174 376 minecraft:gray_concrete
setblock 41 174 386 minecraft:gray_concrete
setblock 41 174 396 minecraft:gray_concrete
setblock 41 174 406 minecraft:gray_concrete
fill 0 175 375 0 175 378 minecraft:sea_lantern
fill 0 175 385 0 175 388 minecraft:sea_lantern
fill 0 175 395 0 175 398 minecraft:sea_lantern
fill 0 175 405 0 175 408 minecraft:sea_lantern
fill 3 175 369 6 175 369 minecraft:sea_lantern
fill 4 175 411 7 175 411 minecraft:sea_lantern
fill 8 175 405 8 175 407 minecraft:gray_concrete
fill 9 175 404 11 175 404 minecraft:gray_concrete
fill 9 175 408 11 175 408 minecraft:gray_concrete
fill 12 175 405 12 175 407 minecraft:gray_concrete
fill 13 175 369 16 175 369 minecraft:sea_lantern
fill 14 175 411 17 175 411 minecraft:sea_lantern
fill 23 175 369 26 175 369 minecraft:sea_lantern
fill 24 175 411 27 175 411 minecraft:sea_lantern
fill 25 175 408 25 187 408 minecraft:green_terracotta
fill 33 175 369 36 175 369 minecraft:sea_lantern
fill 34 175 411 37 175 411 minecraft:sea_lantern
fill 42 175 370 42 175 373 minecraft:sea_lantern
fill 42 175 380 42 175 383 minecraft:sea_lantern
fill 42 175 390 42 175 393 minecraft:sea_lantern
fill 42 175 400 42 175 403 minecraft:sea_lantern
setblock 42 175 410 minecraft:sea_lantern
fill 0 176 375 0 183 378 minecraft:blue_terracotta
fill 0 176 385 0 183 388 minecraft:blue_terracotta
fill 0 176 395 0 183 398 minecraft:blue_terracotta
fill 0 176 405 0 183 408 minecraft:blue_terracotta
fill 3 176 369 6 183 369 minecraft:blue_terracotta
fill 4 176 411 7 183 411 minecraft:blue_terracotta
fill 13 176 369 16 183 369 minecraft:blue_terracotta
fill 14 176 411 17 183 411 minecraft:blue_terracotta
fill 23 176 369 26 183 369 minecraft:blue_terracotta
fill 24 176 411 27 183 411 minecraft:blue_terracotta
fill 33 176 369 36 183 369 minecraft:blue_terracotta
fill 34 176 411 37 183 411 minecraft:blue_terracotta
fill 42 176 370 42 183 373 minecraft:blue_terracotta
fill 42 176 380 42 183 383 minecraft:blue_terracotta
fill 42 176 390 42 183 393 minecraft:blue_terracotta
fill 42 176 400 42 183 403 minecraft:blue_terracotta
fill 42 176 410 42 183 410 minecraft:blue_terracotta
setblock 1 180 372 minecraft:gray_concrete
fill 1 180 374 1 180 377 minecraft:gray_concrete
setblock 1 180 382 minecraft:gray_concrete
fill 1 180 384 1 180 387 minecraft:gray_concrete
setblock 1 180 392 minecraft:gray_concrete
fill 1 180 394 1 180 397 minecraft:gray_concrete
setblock 1 180 402 minecraft:gray_concrete
fill 1 180 404 1 180 407 minecraft:gray_concrete
fill 2 180 370 5 180 370 minecraft:gray_concrete
setblock 3 180 410 minecraft:gray_concrete
fill 4 180 406 4 180 408 minecraft:gray_concrete
fill 5 180 406 6 180 406 minecraft:gray_concrete
fill 5 180 408 6 180 408 minecraft:gray_concrete
fill 5 180 410 8 180 410 minecraft:gray_concrete
setblock 6 180 407 minecraft:gray_concrete
setblock 7 180 370 minecraft:gray_concrete
fill 8 180 405 8 180 407 minecraft:gray_concrete
fill 9 180 404 11 180 404 minecraft:gray_concrete
fill 9 180 408 11 180 408 minecraft:gray_concrete
fill 12 180 370 15 180 370 minecraft:gray_concrete
fill 12 180 405 12 180 407 minecraft:gray_concrete
setblock 13 180 410 minecraft:gray_concrete
fill 15 180 410 18 180 410 minecraft:gray_concrete
setblock 17 180 370 minecraft:gray_concrete
fill 22 180 370 25 180 370 minecraft:gray_concrete
setblock 23 180 410 minecraft:gray_concrete
fill 25 180 410 28 180 410 minecraft:gray_concrete
setblock 27 180 370 minecraft:gray_concrete
fill 32 180 370 35 180 370 minecraft:gray_concrete
setblock 33 180 410 minecraft:gray_concrete
fill 35 180 410 38 180 410 minecraft:gray_concrete
setblock 37 180 370 minecraft:gray_concrete
fill 41 180 371 41 180 374 minecraft:gray_concrete
setblock 41 180 376 minecraft:gray_concrete
fill 41 180 381 41 180 384 minecraft:gray_concrete
setblock 41 180 386 minecraft:gray_concrete
fill 41 180 391 41 180 394 minecraft:gray_concrete
setblock 41 180 396 minecraft:gray_concrete
fill 41 180 401 41 180 404 minecraft:gray_concrete
setblock 41 180 406 minecraft:gray_concrete
setblock 3 181 372 minecraft:light[level=14]
setblock 3 181 380 minecraft:light[level=14]
setblock 3 181 388 minecraft:light[level=14]
setblock 3 181 396 minecraft:light[level=14]
setblock 3 181 404 minecraft:light[level=14]
fill 8 181 387 9 182 387 minecraft:light_blue_stained_glass
fill 9 181 386 9 182 386 minecraft:light_blue_stained_glass
fill 9 181 388 9 182 388 minecraft:light_blue_stained_glass
setblock 11 181 372 minecraft:light[level=14]
setblock 11 181 380 minecraft:light[level=14]
setblock 11 181 388 minecraft:light[level=14]
setblock 11 181 396 minecraft:light[level=14]
setblock 11 181 404 minecraft:light[level=14]
setblock 19 181 372 minecraft:light[level=14]
setblock 19 181 380 minecraft:light[level=14]
setblock 19 181 388 minecraft:light[level=14]
setblock 19 181 396 minecraft:light[level=14]
setblock 19 181 404 minecraft:light[level=14]
setblock 27 181 372 minecraft:light[level=14]
setblock 27 181 380 minecraft:light[level=14]
setblock 27 181 388 minecraft:light[level=14]
setblock 27 181 396 minecraft:light[level=14]
setblock 27 181 404 minecraft:light[level=14]
setblock 35 181 372 minecraft:light[level=14]
setblock 35 181 380 minecraft:light[level=14]
setblock 35 181 388 minecraft:light[level=14]
setblock 35 181 396 minecraft:light[level=14]
setblock 35 181 404 minecraft:light[level=14]
fill 0 184 375 0 184 378 minecraft:sea_lantern
fill 0 184 385 0 184 388 minecraft:sea_lantern
fill 0 184 395 0 184 398 minecraft:sea_lantern
fill 0 184 405 0 184 408 minecraft:sea_lantern
fill 3 184 369 6 184 369 minecraft:sea_lantern
fill 4 184 411 7 184 411 minecraft:sea_lantern
fill 13 184 369 16 184 369 minecraft:sea_lantern
fill 14 184 411 17 184 411 minecraft:sea_lantern
fill 23 184 369 26 184 369 minecraft:sea_lantern
fill 24 184 411 27 184 411 minecraft:sea_lantern
fill 33 184 369 36 184 369 minecraft:sea_lantern
fill 34 184 411 37 184 411 minecraft:sea_lantern
fill 42 184 370 42 184 373 minecraft:sea_lantern
fill 42 184 380 42 184 383 minecraft:sea_lantern
fill 42 184 390 42 184 393 minecraft:sea_lantern
fill 42 184 400 42 184 403 minecraft:sea_lantern
setblock 42 184 410 minecraft:sea_lantern
fill 0 185 375 0 192 378 minecraft:blue_terracotta
fill 0 185 385 0 188 388 minecraft:blue_terracotta
fill 0 185 395 0 188 398 minecraft:blue_terracotta
fill 0 185 405 0 188 408 minecraft:blue_terracotta
fill 3 185 369 6 192 369 minecraft:blue_terracotta
fill 4 185 411 7 192 411 minecraft:blue_terracotta
fill 8 185 405 8 185 407 minecraft:gray_concrete
fill 9 185 404 11 185 404 minecraft:gray_concrete
fill 9 185 408 11 185 408 minecraft:gray_concrete
fill 12 185 405 12 185 407 minecraft:gray_concrete
fill 13 185 369 16 192 369 minecraft:blue_terracotta
fill 14 185 411 17 192 411 minecraft:blue_terracotta
fill 23 185 369 26 189 369 minecraft:blue_terracotta
fill 24 185 411 27 188 411 minecraft:blue_terracotta
fill 33 185 369 36 192 369 minecraft:blue_terracotta
fill 34 185 411 37 190 411 minecraft:blue_terracotta
fill 42 185 370 42 188 373 minecraft:blue_terracotta
fill 42 185 380 42 189 383 minecraft:blue_terracotta
fill 42 185 390 42 188 393 minecraft:blue_terracotta
fill 42 185 400 42 189 403 minecraft:blue_terracotta
fill 42 185 410 42 189 410 minecraft:blue_terracotta
setblock 1 186 372 minecraft:gray_concrete
setblock 1 186 382 minecraft:gray_concrete
setblock 1 186 392 minecraft:gray_concrete
setblock 1 186 402 minecraft:gray_concrete
setblock 3 186 410 minecraft:gray_concrete
fill 4 186 406 4 186 408 minecraft:gray_concrete
fill 5 186 406 6 186 406 minecraft:gray_concrete
fill 5 186 408 6 186 408 minecraft:gray_concrete
setblock 6 186 407 minecraft:gray_concrete
setblock 7 186 370 minecraft:gray_concrete
setblock 13 186 410 minecraft:gray_concrete
setblock 17 186 370 minecraft:gray_concrete
setblock 23 186 410 minecraft:gray_concrete
setblock 27 186 370 minecraft:gray_concrete
setblock 33 186 410 minecraft:gray_concrete
setblock 37 186 370 minecraft:gray_concrete
setblock 41 186 376 minecraft:gray_concrete
setblock 41 186 386 minecraft:gray_concrete
setblock 41 186 396 minecraft:gray_concrete
setblock 41 186 406 minecraft:gray_concrete
fill 17 187 375 17 188 375 minecraft:sea_lantern
setblock 0 189 369 minecraft:blue_concrete
setblock 0 189 370 minecraft:blue_terracotta
setblock 0 189 380 minecraft:blue_terracotta
setblock 0 189 381 minecraft:blue_concrete
fill 0 189 382 0 192 382 minecraft:blue_terracotta
setblock 0 189 385 minecraft:blue_concrete
fill 0 189 386 0 192 388 minecraft:blue_terracotta
setblock 0 189 395 minecraft:blue_concrete
fill 0 189 396 0 190 399 minecraft:blue_terracotta
setblock 0 189 400 minecraft:blue_concrete
fill 0 189 405 0 192 405 minecraft:blue_terracotta
setblock 0 189 406 minecraft:blue_concrete
fill 0 189 407 0 192 408 minecraft:blue_terracotta
fill 1 189 374 1 189 377 minecraft:gray_concrete
fill 1 189 384 1 189 387 minecraft:gray_concrete
fill 1 189 394 1 189 397 minecraft:gray_concrete
fill 1 189 404 1 189 407 minecraft:gray_concrete
fill 2 189 370 5 189 370 minecraft:gray_concrete
setblock 3 189 372 minecraft:light[level=14]
setblock 3 189 380 minecraft:light[level=14]
setblock 3 189 388 minecraft:light[level=14]
setblock 3 189 396 minecraft:light[level=14]
setblock 3 189 404 minecraft:light[level=14]
fill 5 189 410 8 189 410 minecraft:gray_concrete
fill 7 189 369 7 192 369 minecraft:blue_terracotta
setblock 8 189 369 minecraft:blue_concrete
fill 9 189 369 12 192 369 minecraft:blue_terracotta
setblock 11 189 372 minecraft:light[level=14]
setblock 11 189 380 minecraft:light[level=14]
setblock 11 189 388 minecraft:light[level=14]
setblock 11 189 396 minecraft:light[level=14]
setblock 11 189 404 minecraft:light[level=14]
fill 12 189 370 15 189 370 minecraft:gray_concrete
fill 15 189 410 18 189 410 minecraft:gray_concrete
fill 16 189 375 17 199 375 minecraft:black_concrete
setblock 18 189 411 minecraft:blue_concrete
setblock 19 189 372 minecraft:light[level=14]
setblock 19 189 380 minecraft:light[level=14]
setblock 19 189 388 minecraft:light[level=14]
setblock 19 189 396 minecraft:light[level=14]
setblock 19 189 404 minecraft:light[level=14]
fill 19 189 411 19 192 411 minecraft:blue_terracotta
setblock 20 189 411 minecraft:blue_concrete
fill 22 189 370 25 189 370 minecraft:gray_concrete
fill 24 189 411 25 192 411 minecraft:blue_terracotta
fill 25 189 410 28 189 410 minecraft:gray_concrete
setblock 26 189 411 minecraft:blue_concrete
setblock 27 189 372 minecraft:light[level=14]
setblock 27 189 380 minecraft:light[level=14]
setblock 27 189 388 minecraft:light[level=14]
setblock 27 189 396 minecraft:light[level=14]
setblock 27 189 404 minecraft:light[level=14]
fill 27 189 411 27 192 411 minecraft:blue_terracotta
fill 32 189 370 35 189 370 minecraft:gray_concrete
setblock 35 189 372 minecraft:light[level=14]
setblock 35 189 380 minecraft:light[level=14]
setblock 35 189 388 minecraft:light[level=14]
setblock 35 189 396 minecraft:light[level=14]
setblock 35 189 404 minecraft:light[level=14]
fill 35 189 410 38 189 410 minecraft:gray_concrete
fill 39 189 388 39 190 389 minecraft:light_blue_stained_glass
fill 41 189 371 41 189 374 minecraft:gray_concrete
fill 41 189 381 41 189 384 minecraft:gray_concrete
fill 41 189 391 41 189 394 minecraft:gray_concrete
fill 41 189 401 41 189 404 minecraft:gray_concrete
fill 42 189 369 42 189 370 minecraft:blue_concrete
fill 42 189 371 42 192 373 minecraft:blue_terracotta
fill 42 189 385 42 192 385 minecraft:blue_terracotta
setblock 42 189 386 minecraft:blue_concrete
fill 42 189 387 42 192 387 minecraft:blue_terracotta
fill 42 189 390 42 189 391 minecraft:blue_concrete
fill 42 189 392 42 189 393 minecraft:blue_terracotta
fill 0 190 369 0 192 369 minecraft:blue_terracotta
setblock 0 190 370 minecraft:blue_concrete
setblock 0 190 372 minecraft:blue_concrete
fill 0 190 373 0 192 374 minecraft:blue_terracotta
setblock 0 190 380 minecraft:blue_concrete
setblock 0 190 381 minecraft:blue_terracotta
setblock 0 190 385 minecraft:blue_terracotta
setblock 0 190 394 minecraft:blue_concrete
setblock 0 190 395 minecraft:blue_terracotta
fill 0 190 400 0 192 400 minecraft:blue_terracotta
fill 0 190 406 0 192 406 minecraft:blue_terracotta
setblock 1 190 369 minecraft:blue_concrete
fill 2 190 369 2 192 369 minecraft:blue_terracotta
setblock 2 190 411 minecraft:blue_concrete
setblock 8 190 369 minecraft:blue_terracotta
fill 8 190 405 8 190 407 minecraft:gray_concrete
fill 9 190 404 11 190 404 minecraft:gray_concrete
fill 9 190 408 11 190 408 minecraft:gray_concrete
fill 12 190 405 12 190 407 minecraft:gray_concrete
setblock 17 190 369 minecraft:blue_concrete
fill 18 190 369 24 190 369 minecraft:blue_terracotta
fill 18 190 411 18 192 411 minecraft:blue_terracotta
setblock 20 190 411 minecraft:blue_terracotta
setblock 25 190 369 minecraft:blue_concrete
setblock 26 190 369 minecraft:blue_terracotta
fill 26 190 411 26 192 411 minecraft:blue_terracotta
fill 42 190 369 42 192 370 minecraft:blue_terracotta
fill 42 190 374 42 192 377 minecraft:blue_terracotta
setblock 42 190 378 minecraft:blue_concrete
fill 42 190 380 42 192 380 minecraft:blue_terracotta
fill 42 190 381 42 190 382 minecraft:blue_concrete
setblock 42 190 383 minecraft:blue_terracotta
fill 42 190 386 42 193 386 minecraft:blue_terracotta
fill 42 190 390 42 192 392 minecraft:blue_terracotta
setblock 42 190 393 minecraft:blue_concrete
fill 42 190 394 42 192 397 minecraft:blue_terracotta
setblock 42 190 398 minecraft:blue_concrete
fill 42 190 399 42 192 400 minecraft:blue_terracotta
fill 42 190 401 42 190 402 minecraft:blue_concrete
fill 42 190 403 42 192 403 minecraft:blue_terracotta
setblock 42 190 404 minecraft:blue_concrete
fill 42 190 410 42 190 411 minecraft:blue_concrete
fill 0 191 370 0 193 370 minecraft:blue_terracotta
fill 0 191 372 0 192 372 minecraft:blue_terracotta
fill 0 191 380 0 192 380 minecraft:blue_terracotta
setblock 0 191 381 minecraft:blue_concrete
setblock 0 191 385 minecraft:blue_concrete
fill 0 191 394 0 192 394 minecraft:blue_terracotta
setblock 0 191 395 minecraft:blue_concrete
fill 0 191 396 0 192 396 minecraft:blue_terracotta
setblock 0 191 397 minecraft:blue_concrete
fill 0 191 398 0 192 399 minecraft:blue_terracotta
fill 1 191 369 1 192 369 minecraft:blue_terracotta
fill 2 191 411 2 192 411 minecraft:blue_terracotta
setblock 8 191 369 minecraft:blue_concrete
fill 16 191 374 17 199 374 minecraft:black_concrete
fill 16 191 376 17 199 376 minecraft:black_concrete
fill 17 191 369 19 192 369 minecraft:blue_terracotta
fill 19 191 377 19 192 379 minecraft:light_blue_stained_glass
setblock 20 191 369 minecraft:blue_concrete
fill 20 191 377 20 192 378 minecraft:light_blue_stained_glass
setblock 20 191 411 minecraft:blue_concrete
fill 21 191 369 25 192 369 minecraft:blue_terracotta
setblock 26 191 369 minecraft:blue_concrete
fill 34 191 411 34 192 411 minecraft:blue_terracotta
setblock 35 191 411 minecraft:blue_concrete
fill 36 191 411 37 192 411 minecraft:blue_terracotta
setblock 38 191 369 minecraft:blue_concrete
setblock 41 191 369 minecraft:blue_concrete
fill 42 191 378 42 192 378 minecraft:blue_terracotta
fill 42 191 381 42 192 382 minecraft:blue_terracotta
setblock 42 191 383 minecraft:blue_concrete
fill 42 191 388 42 192 388 minecraft:blue_terracotta
setblock 42 191 389 minecraft:blue_concrete
fill 42 191 393 42 192 393 minecraft:blue_terracotta
fill 42 191 398 42 192 398 minecraft:blue_terracotta
fill 42 191 401 42 192 402 minecraft:blue_terracotta
fill 42 191 404 42 192 404 minecraft:blue_terracotta
setblock 42 191 406 minecraft:blue_concrete
fill 42 191 410 42 192 411 minecraft:blue_terracotta
setblock 0 192 381 minecraft:blue_terracotta
setblock 0 192 385 minecraft:blue_terracotta
setblock 0 192 395 minecraft:blue_terracotta
setblock 0 192 397 minecraft:blue_terracotta
setblock 1 192 372 minecraft:gray_concrete
setblock 1 192 382 minecraft:gray_concrete
setblock 1 192 392 minecraft:gray_concrete
setblock 1 192 402 minecraft:gray_concrete
setblock 3 192 410 minecraft:gray_concrete
fill 4 192 406 4 192 408 minecraft:gray_concrete
fill 5 192 406 6 192 406 minecraft:gray_concrete
fill 5 192 408 6 192 408 minecraft:gray_concrete
setblock 6 192 407 minecraft:gray_concrete
setblock 7 192 370 minecraft:gray_concrete
setblock 8 192 369 minecraft:blue_terracotta
setblock 13 192 410 minecraft:gray_concrete
fill 15 192 374 15 199 375 minecraft:black_concrete
setblock 17 192 370 minecraft:gray_concrete
fill 18 192 374 18 199 376 minecraft:black_concrete
setblock 20 192 369 minecraft:blue_terracotta
setblock 20 192 411 minecraft:blue_terracotta
setblock 23 192 410 minecraft:gray_concrete
setblock 26 192 369 minecraft:blue_terracotta
setblock 27 192 370 minecraft:gray_concrete
setblock 33 192 410 minecraft:gray_concrete
setblock 35 192 411 minecraft:blue_terracotta
setblock 37 192 370 minecraft:gray_concrete
setblock 38 192 369 minecraft:blue_terracotta
setblock 41 192 369 minecraft:blue_terracotta
setblock 41 192 376 minecraft:gray_concrete
setblock 41 192 386 minecraft:gray_concrete
setblock 41 192 396 minecraft:gray_concrete
setblock 41 192 406 minecraft:gray_concrete
setblock 42 192 383 minecraft:blue_terracotta
setblock 42 192 389 minecraft:blue_terracotta
setblock 42 192 406 minecraft:blue_terracotta
fill 0 193 369 2 194 369 minecraft:blue_concrete
fill 0 193 372 0 307 372 minecraft:blue_concrete
setblock 0 193 373 minecraft:blue_terracotta
fill 0 193 374 0 307 374 minecraft:blue_concrete
fill 0 193 375 0 193 378 minecraft:sea_lantern
fill 0 193 379 0 307 384 minecraft:blue_concrete
fill 0 193 385 0 193 388 minecraft:sea_lantern
fill 0 193 389 0 307 394 minecraft:blue_concrete
fill 0 193 395 0 193 398 minecraft:sea_lantern
fill 0 193 399 0 307 404 minecraft:blue_concrete
fill 0 193 405 0 193 408 minecraft:sea_lantern
fill 0 193 409 0 193 411 minecraft:blue_concrete
fill 1 193 411 3 307 411 minecraft:blue_concrete
fill 3 193 369 6 193 369 minecraft:sea_lantern
fill 4 193 411 7 193 411 minecraft:sea_lantern
fill 7 193 369 12 193 369 minecraft:blue_concrete
fill 8 193 411 10 193 411 minecraft:blue_concrete
fill 11 193 411 11 194 411 minecraft:blue_terracotta
fill 12 193 411 13 194 411 minecraft:blue_concrete
fill 13 193 369 16 193 369 minecraft:sea_lantern
fill 14 193 411 17 193 411 minecraft:sea_lantern
fill 15 193 376 15 199 376 minecraft:black_concrete
fill 16 193 373 17 199 373 minecraft:black_concrete
fill 16 193 377 17 199 377 minecraft:black_concrete
setblock 17 193 369 minecraft:blue_terracotta
fill 18 193 369 22 194 369 minecraft:blue_concrete
fill 18 193 411 23 193 411 minecraft:blue_concrete
fill 23 193 369 26 193 369 minecraft:sea_lantern
fill 24 193 411 27 193 411 minecraft:sea_lantern
fill 27 193 369 32 194 369 minecraft:blue_concrete
fill 28 193 411 33 193 411 minecraft:blue_concrete
fill 33 193 369 36 193 369 minecraft:sea_lantern
fill 34 193 411 37 193 411 minecraft:sea_lantern
fill 37 193 369 42 193 369 minecraft:blue_concrete
fill 38 193 411 42 193 411 minecraft:blue_concrete
fill 42 193 370 42 193 373 minecraft:sea_lantern
fill 42 193 374 42 193 379 minecraft:blue_concrete
fill 42 193 380 42 193 383 minecraft:sea_lantern
fill 42 193 384 42 307 385 minecraft:blue_concrete
fill 42 193 387 42 194 389 minecraft:blue_concrete
fill 42 193 390 42 193 393 minecraft:sea_lantern
fill 42 193 394 42 307 395 minecraft:blue_concrete
setblock 42 193 396 minecraft:blue_terracotta
fill 42 193 397 42 193 399 minecraft:blue_concrete
fill 42 193 400 42 193 403 minecraft:sea_lantern
fill 42 193 404 42 193 409 minecraft:blue_concrete
setblock 42 193 410 minecraft:sea_lantern
fill 0 194 370 0 307 370 minecraft:blue_concrete
fill 0 194 373 0 307 373 minecraft:blue_concrete
setblock 0 194 375 minecraft:blue_terracotta
fill 0 194 376 0 201 377 minecraft:blue_concrete
setblock 0 194 378 minecraft:blue_terracotta
fill 0 194 385 0 201 385 minecraft:blue_concrete
fill 0 194 386 0 194 387 minecraft:blue_terracotta
fill 0 194 388 0 201 388 minecraft:blue_concrete
fill 0 194 395 0 201 395 minecraft:blue_concrete
setblock 0 194 396 minecraft:blue_terracotta
fill 0 194 397 0 201 398 minecraft:blue_concrete
fill 0 194 405 0 194 409 minecraft:blue_concrete
setblock 0 194 410 minecraft:blue_terracotta
fill 0 194 411 0 307 411 minecraft:blue_concrete
fill 3 194 369 3 201 369 minecraft:blue_concrete
fill 4 194 369 5 194 369 minecraft:blue_terracotta
fill 4 194 411 5 194 411 minecraft:blue_concrete
fill 6 194 369 6 201 369 minecraft:blue_concrete
fill 6 194 411 6 195 411 minecraft:blue_terracotta
fill 7 194 369 9 194 369 minecraft:blue_terracotta
fill 7 194 411 8 201 411 minecraft:blue_concrete
setblock 9 194 411 minecraft:blue_terracotta
fill 10 194 369 17 194 369 minecraft:blue_concrete
fill 10 194 411 10 307 411 minecraft:blue_concrete
fill 14 194 374 14 199 375 minecraft:black_concrete
setblock 14 194 411 minecraft:blue_terracotta
fill 15 194 373 15 199 373 minecraft:black_concrete
fill 15 194 377 15 199 377 minecraft:black_concrete
fill 15 194 411 18 194 411 minecraft:blue_concrete
fill 18 194 373 18 199 373 minecraft:black_concrete
fill 18 194 377 18 199 377 minecraft:black_concrete
fill 19 194 374 19 199 376 minecraft:black_concrete
setblock 19 194 411 minecraft:blue_terracotta
fill 20 194 411 20 307 411 minecraft:blue_concrete
setblock 21 194 411 minecraft:blue_terracotta
fill 22 194 411 22 307 411 minecraft:blue_concrete
fill 23 194 369 26 201 369 minecraft:blue_concrete
setblock 23 194 411 minecraft:blue_terracotta
fill 24 194 411 24 201 411 minecraft:blue_concrete
setblock 25 194 411 minecraft:blue_terracotta
fill 26 194 411 26 201 411 minecraft:blue_concrete
fill 27 194 411 28 194 411 minecraft:blue_terracotta
fill 29 194 411 30 194 411 minecraft:blue_concrete
fill 31 194 411 32 194 411 minecraft:blue_terracotta
fill 33 194 369 41 201 369 minecraft:blue_concrete
fill 33 194 411 35 201 411 minecraft:blue_concrete
setblock 36 194 411 minecraft:blue_terracotta
fill 37 194 411 37 201 411 minecraft:blue_concrete
fill 38 194 411 38 195 411 minecraft:blue_terracotta
fill 39 194 411 42 307 411 minecraft:blue_concrete
setblock 42 194 369 minecraft:blue_terracotta
fill 42 194 370 42 201 372 minecraft:blue_concrete
fill 42 194 373 42 195 373 minecraft:blue_terracotta
fill 42 194 374 42 307 377 minecraft:blue_concrete
setblock 42 194 378 minecraft:blue_terracotta
fill 42 194 379 42 194 383 minecraft:blue_concrete
fill 42 194 386 42 307 386 minecraft:blue_concrete
setblock 42 194 390 minecraft:blue_concrete
setblock 42 194 391 minecraft:blue_terracotta
fill 42 194 392 42 201 393 minecraft:blue_concrete
fill 42 194 396 42 307 397 minecraft:blue_concrete
setblock 42 194 398 minecraft:blue_terracotta
fill 42 194 399 42 201 400 minecraft:blue_concrete
setblock 42 194 401 minecraft:blue_terracotta
fill 42 194 402 42 201 402 minecraft:blue_concrete
setblock 42 194 403 minecraft:blue_terracotta
fill 42 194 404 42 307 404 minecraft:blue_concrete
fill 42 194 405 42 194 406 minecraft:blue_terracotta
fill 42 194 407 42 201 410 minecraft:blue_concrete
fill 0 195 369 1 195 369 minecraft:blue_terracotta
fill 0 195 371 0 307 371 minecraft:blue_concrete
fill 0 195 375 0 201 375 minecraft:blue_concrete
fill 0 195 378 0 201 378 minecraft:blue_concrete
fill 0 195 386 0 201 387 minecraft:blue_concrete
fill 0 195 396 0 201 396 minecraft:blue_concrete
fill 0 195 405 0 201 405 minecraft:blue_concrete
setblock 0 195 406 minecraft:blue_terracotta
fill 0 195 407 0 201 410 minecraft:blue_concrete
fill 2 195 369 2 307 369 minecraft:blue_concrete
fill 4 195 369 5 201 369 minecraft:blue_concrete
setblock 4 195 411 minecraft:blue_terracotta
fill 5 195 411 5 201 411 minecraft:blue_concrete
fill 7 195 369 15 201 369 minecraft:blue_concrete
fill 8 195 405 8 195 407 minecraft:gray_concrete
fill 9 195 404 11 195 404 minecraft:gray_concrete
fill 9 195 408 11 195 408 minecraft:gray_concrete
fill 9 195 411 9 307 411 minecraft:blue_concrete
fill 11 195 411 12 307 411 minecraft:blue_concrete
fill 12 195 405 12 195 407 minecraft:gray_concrete
setblock 13 195 411 minecraft:blue_terracotta
fill 14 195 373 14 199 373 minecraft:black_concrete
fill 14 195 376 14 199 376 minecraft:black_concrete
fill 14 195 411 15 201 411 minecraft:blue_concrete
setblock 16 195 369 minecraft:blue_terracotta
fill 16 195 372 18 199 372 minecraft:black_concrete
fill 16 195 378 17 199 378 minecraft:black_concrete
setblock 16 195 411 minecraft:blue_terracotta
fill 17 195 369 21 307 369 minecraft:blue_concrete
fill 17 195 411 17 201 411 minecraft:blue_concrete
setblock 18 195 411 minecraft:blue_terracotta
fill 19 195 373 19 199 373 minecraft:black_concrete
fill 19 195 377 19 199 377 minecraft:black_concrete
fill 19 195 411 19 307 411 minecraft:blue_concrete
fill 21 195 411 21 307 411 minecraft:blue_concrete
setblock 22 195 369 minecraft:blue_terracotta
fill 23 195 411 23 307 411 minecraft:blue_concrete
fill 25 195 411 25 201 411 minecraft:blue_concrete
fill 27 195 369 29 307 369 minecraft:blue_concrete
fill 27 195 411 28 201 411 minecraft:blue_concrete
fill 29 195 411 30 195 411 minecraft:blue_terracotta
fill 30 195 369 31 195 369 minecraft:blue_terracotta
fill 31 195 411 32 307 411 minecraft:blue_concrete
fill 32 195 369 32 307 369 minecraft:blue_concrete
fill 36 195 411 36 201 411 minecraft:blue_concrete
fill 42 195 369 42 307 369 minecraft:blue_concrete
fill 42 195 378 42 307 379 minecraft:blue_concrete
setblock 42 195 380 minecraft:blue_terracotta
fill 42 195 381 42 201 383 minecraft:blue_concrete
fill 42 195 387 42 307 388 minecraft:blue_concrete
fill 42 195 389 42 195 390 minecraft:blue_terracotta
fill 42 195 391 42 201 391 minecraft:blue_concrete
fill 42 195 398 42 307 398 minecraft:blue_concrete
fill 42 195 401 42 201 401 minecraft:blue_concrete
fill 42 195 403 42 201 403 minecraft:blue_concrete
fill 42 195 405 42 307 406 minecraft:blue_concrete
fill 0 196 369 1 307 369 minecraft:blue_concrete
fill 0 196 406 0 201 406 minecraft:blue_concrete
fill 4 196 411 4 201 411 minecraft:blue_concrete
fill 6 196 411 6 201 411 minecraft:blue_concrete
fill 13 196 374 13 199 376 minecraft:black_concrete
fill 13 196 411 13 307 411 minecraft:blue_concrete
fill 14 196 377 14 199 377 minecraft:black_concrete
fill 15 196 372 15 199 372 minecraft:black_concrete
fill 15 196 378 15 199 378 minecraft:black_concrete
fill 16 196 369 16 201 369 minecraft:blue_concrete
fill 16 196 411 16 201 411 minecraft:blue_concrete
fill 18 196 378 18 199 378 minecraft:black_concrete
fill 18 196 411 18 307 411 minecraft:blue_concrete
fill 19 196 372 19 199 372 minecraft:black_concrete
fill 20 196 374 20 199 376 minecraft:black_concrete
fill 22 196 369 22 307 369 minecraft:blue_concrete
fill 29 196 411 30 307 411 minecraft:blue_concrete
fill 30 196 369 31 307 369 minecraft:blue_concrete
fill 38 196 411 38 307 411 minecraft:blue_concrete
fill 42 196 373 42 201 373 minecraft:blue_concrete
fill 42 196 380 42 201 380 minecraft:blue_concrete
fill 42 196 389 42 201 390 minecraft:blue_concrete
setblock 3 197 372 minecraft:light[level=14]
setblock 3 197 380 minecraft:light[level=14]
setblock 3 197 388 minecraft:light[level=14]
setblock 3 197 396 minecraft:light[level=14]
setblock 3 197 404 minecraft:light[level=14]
setblock 11 197 372 minecraft:light[level=14]
setblock 11 197 380 minecraft:light[level=14]
setblock 11 197 388 minecraft:light[level=14]
setblock 11 197 396 minecraft:light[level=14]
setblock 11 197 404 minecraft:light[level=14]
fill 13 197 373 13 199 373 minecraft:black_concrete
fill 13 197 377 13 199 377 minecraft:black_concrete
fill 14 197 372 14 199 372 minecraft:black_concrete
fill 14 197 378 14 199 378 minecraft:black_concrete
fill 15 197 371 18 199 371 minecraft:black_concrete
fill 16 197 379 17 199 379 minecraft:black_concrete
fill 19 197 378 19 199 378 minecraft:black_concrete
setblock 19 197 380 minecraft:light[level=14]
setblock 19 197 388 minecraft:light[level=14]
setblock 19 197 396 minecraft:light[level=14]
setblock 19 197 404 minecraft:light[level=14]
fill 20 197 373 20 199 373 minecraft:black_concrete
fill 20 197 377 20 199 377 minecraft:black_concrete
setblock 27 197 372 minecraft:light[level=14]
setblock 27 197 380 minecraft:light[level=14]
setblock 27 197 388 minecraft:light[level=14]
setblock 27 197 396 minecraft:light[level=14]
setblock 27 197 404 minecraft:light[level=14]
setblock 35 197 372 minecraft:light[level=14]
setblock 35 197 380 minecraft:light[level=14]
setblock 35 197 388 minecraft:light[level=14]
setblock 35 197 396 minecraft:light[level=14]
setblock 35 197 404 minecraft:light[level=14]
setblock 1 198 372 minecraft:gray_concrete
fill 1 198 374 1 198 377 minecraft:gray_concrete
setblock 1 198 382 minecraft:gray_concrete
fill 1 198 384 1 198 387 minecraft:gray_concrete
setblock 1 198 392 minecraft:gray_concrete
fill 1 198 394 1 198 397 minecraft:gray_concrete
setblock 1 198 402 minecraft:gray_concrete
fill 1 198 404 1 198 407 minecraft:gray_concrete
fill 2 198 370 5 198 370 minecraft:gray_concrete
setblock 3 198 410 minecraft:gray_concrete
fill 4 198 406 4 198 408 minecraft:gray_concrete
fill 5 198 406 6 198 406 minecraft:gray_concrete
fill 5 198 408 6 198 408 minecraft:gray_concrete
fill 5 198 410 8 198 410 minecraft:gray_concrete
setblock 6 198 407 minecraft:gray_concrete
setblock 7 198 370 minecraft:gray_concrete
fill 12 198 370 15 198 370 minecraft:gray_concrete
fill 12 198 374 12 199 376 minecraft:black_concrete
fill 13 198 372 13 199 372 minecraft:black_concrete
fill 13 198 378 13 199 378 minecraft:black_concrete
setblock 13 198 410 minecraft:gray_concrete
fill 14 198 371 14 199 371 minecraft:black_concrete
fill 15 198 379 15 199 379 minecraft:black_concrete
fill 15 198 410 18 198 410 minecraft:gray_concrete
setblock 17 198 370 minecraft:gray_concrete
fill 18 198 379 19 199 379 minecraft:black_concrete
fill 19 198 371 19 199 371 minecraft:black_concrete
fill 20 198 372 20 199 372 minecraft:black_concrete
fill 20 198 378 20 199 378 minecraft:black_concrete
fill 21 198 374 21 199 376 minecraft:black_concrete
fill 22 198 370 25 198 370 minecraft:gray_concrete
setblock 23 198 410 minecraft:gray_concrete
fill 25 198 410 28 198 410 minecraft:gray_concrete
setblock 27 198 370 minecraft:gray_concrete
fill 32 198 370 35 198 370 minecraft:gray_concrete
setblock 33 198 410 minecraft:gray_concrete
fill 35 198 410 38 198 410 minecraft:gray_concrete
setblock 37 198 370 minecraft:gray_concrete
fill 41 198 371 41 198 374 minecraft:gray_concrete
setblock 41 198 376 minecraft:gray_concrete
fill 41 198 381 41 198 384 minecraft:gray_concrete
setblock 41 198 386 minecraft:gray_concrete
fill 41 198 391 41 198 394 minecraft:gray_concrete
setblock 41 198 396 minecraft:gray_concrete
fill 41 198 401 41 198 404 minecraft:gray_concrete
setblock 41 198 406 minecraft:gray_concrete
setblock 12 199 373 minecraft:black_concrete
setblock 12 199 377 minecraft:black_concrete
setblock 14 199 379 minecraft:black_concrete
fill 15 199 370 17 199 370 minecraft:black_concrete
fill 16 199 380 17 199 380 minecraft:black_concrete
setblock 20 199 371 minecraft:black_concrete
setblock 21 199 373 minecraft:black_concrete
setblock 21 199 377 minecraft:black_concrete
fill 8 200 405 8 200 407 minecraft:gray_concrete
fill 9 200 404 11 200 404 minecraft:gray_concrete
fill 9 200 408 11 200 408 minecraft:gray_concrete
fill 12 200 405 12 200 407 minecraft:gray_concrete
fill 13 200 376 13 209 376 minecraft:iron_block
fill 15 200 376 15 201 376 minecraft:gray_concrete
fill 16 200 373 16 204 373 minecraft:gray_concrete
fill 18 200 375 18 204 375 minecraft:gray_concrete
fill 0 202 375 0 202 378 minecraft:sea_lantern
fill 0 202 385 0 202 388 minecraft:sea_lantern
fill 0 202 395 0 202 398 minecraft:sea_lantern
fill 0 202 405 0 202 408 minecraft:sea_lantern
fill 0 202 409 0 307 410 minecraft:blue_concrete
fill 3 202 369 6 202 369 minecraft:sea_lantern
fill 4 202 411 7 202 411 minecraft:sea_lantern
fill 7 202 369 12 307 369 minecraft:blue_concrete
fill 8 202 411 8 307 411 minecraft:blue_concrete
fill 13 202 369 16 202 369 minecraft:sea_lantern
fill 14 202 411 17 202 411 minecraft:sea_lantern
fill 23 202 369 26 202 369 minecraft:sea_lantern
fill 24 202 411 27 202 411 minecraft:sea_lantern
fill 28 202 411 28 307 411 minecraft:blue_concrete
fill 33 202 369 36 202 369 minecraft:sea_lantern
fill 33 202 411 33 307 411 minecraft:blue_concrete
fill 34 202 411 37 202 411 minecraft:sea_lantern
fill 37 202 369 41 307 369 minecraft:blue_concrete
fill 42 202 370 42 202 373 minecraft:sea_lantern
fill 42 202 380 42 202 383 minecraft:sea_lantern
fill 42 202 389 42 307 389 minecraft:blue_concrete
fill 42 202 390 42 202 393 minecraft:sea_lantern
fill 42 202 399 42 307 399 minecraft:blue_concrete
fill 42 202 400 42 202 403 minecraft:sea_lantern
fill 42 202 407 42 307 409 minecraft:blue_concrete
setblock 42 202 410 minecraft:sea_lantern
fill 0 203 375 0 210 378 minecraft:blue_concrete
fill 0 203 385 0 210 388 minecraft:blue_concrete
fill 0 203 395 0 210 398 minecraft:blue_concrete
fill 0 203 405 0 210 408 minecraft:blue_concrete
fill 3 203 369 6 210 369 minecraft:blue_concrete
fill 4 203 411 7 210 411 minecraft:blue_concrete
fill 13 203 369 16 210 369 minecraft:blue_concrete
fill 14 203 411 17 210 411 minecraft:blue_concrete
fill 23 203 369 26 210 369 minecraft:blue_concrete
fill 24 203 411 27 210 411 minecraft:blue_concrete
fill 33 203 369 36 210 369 minecraft:blue_concrete
fill 34 203 411 37 210 411 minecraft:blue_concrete
fill 42 203 370 42 210 373 minecraft:blue_concrete
fill 42 203 380 42 210 383 minecraft:blue_concrete
fill 42 203 390 42 210 393 minecraft:blue_concrete
fill 42 203 400 42 210 403 minecraft:blue_concrete
fill 42 203 410 42 210 410 minecraft:blue_concrete
setblock 1 204 372 minecraft:gray_concrete
setblock 1 204 382 minecraft:gray_concrete
setblock 1 204 392 minecraft:gray_concrete
setblock 1 204 402 minecraft:gray_concrete
setblock 3 204 410 minecraft:gray_concrete
fill 4 204 406 4 204 408 minecraft:gray_concrete
fill 5 204 406 6 204 406 minecraft:gray_concrete
fill 5 204 408 6 204 408 minecraft:gray_concrete
setblock 6 204 407 minecraft:gray_concrete
setblock 7 204 370 minecraft:gray_concrete
setblock 13 204 410 minecraft:gray_concrete
setblock 17 204 370 minecraft:gray_concrete
setblock 23 204 410 minecraft:gray_concrete
setblock 27 204 370 minecraft:gray_concrete
setblock 33 204 410 minecraft:gray_concrete
setblock 37 204 370 minecraft:gray_concrete
setblock 41 204 376 minecraft:gray_concrete
setblock 41 204 386 minecraft:gray_concrete
setblock 41 204 396 minecraft:gray_concrete
setblock 41 204 406 minecraft:gray_concrete
setblock 3 205 372 minecraft:light[level=14]
setblock 3 205 380 minecraft:light[level=14]
setblock 3 205 388 minecraft:light[level=14]
setblock 3 205 396 minecraft:light[level=14]
setblock 3 205 404 minecraft:light[level=14]
fill 8 205 405 8 205 407 minecraft:gray_concrete
fill 9 205 404 11 205 404 minecraft:gray_concrete
fill 9 205 408 11 205 408 minecraft:gray_concrete
setblock 11 205 372 minecraft:light[level=14]
setblock 11 205 380 minecraft:light[level=14]
setblock 11 205 388 minecraft:light[level=14]
setblock 11 205 396 minecraft:light[level=14]
fill 12 205 405 12 205 407 minecraft:gray_concrete
fill 16 205 377 16 206 378 minecraft:light_blue_stained_glass
setblock 19 205 372 minecraft:light[level=14]
setblock 19 205 380 minecraft:light[level=14]
setblock 19 205 388 minecraft:light[level=14]
setblock 19 205 396 minecraft:light[level=14]
setblock 19 205 404 minecraft:light[level=14]
setblock 27 205 372 minecraft:light[level=14]
setblock 27 205 380 minecraft:light[level=14]
setblock 27 205 388 minecraft:light[level=14]
setblock 27 205 396 minecraft:light[level=14]
setblock 27 205 404 minecraft:light[level=14]
setblock 35 205 372 minecraft:light[level=14]
setblock 35 205 380 minecraft:light[level=14]
setblock 35 205 388 minecraft:light[level=14]
setblock 35 205 396 minecraft:light[level=14]
setblock 35 205 404 minecraft:light[level=14]
fill 17 206 403 17 207 403 minecraft:white_stained_glass
fill 1 207 374 1 207 377 minecraft:gray_concrete
fill 1 207 384 1 207 387 minecraft:gray_concrete
fill 1 207 394 1 207 397 minecraft:gray_concrete
fill 1 207 404 1 207 407 minecraft:gray_concrete
fill 2 207 370 5 207 370 minecraft:gray_concrete
fill 5 207 410 8 207 410 minecraft:gray_concrete
fill 12 207 370 15 207 370 minecraft:gray_concrete
fill 15 207 410 18 207 410 minecraft:gray_concrete
fill 22 207 370 25 207 370 minecraft:gray_concrete
fill 25 207 410 28 207 410 minecraft:gray_concrete
fill 32 207 370 35 207 370 minecraft:gray_concrete
fill 35 207 410 38 207 410 minecraft:gray_concrete
fill 41 207 371 41 207 374 minecraft:gray_concrete
fill 41 207 381 41 207 384 minecraft:gray_concrete
fill 41 207 391 41 207 394 minecraft:gray_concrete
fill 41 207 401 41 207 404 minecraft:gray_concrete
fill 9 209 408 11 209 409 minecraft:iron_block
fill 10 209 410 10 210 410 minecraft:iron_block
setblock 1 210 372 minecraft:gray_concrete
setblock 1 210 382 minecraft:gray_concrete
setblock 1 210 392 minecraft:gray_concrete
setblock 1 210 402 minecraft:gray_concrete
setblock 3 210 410 minecraft:gray_concrete
fill 4 210 406 4 210 408 minecraft:gray_concrete
fill 5 210 406 6 210 406 minecraft:gray_concrete
fill 5 210 408 6 210 408 minecraft:gray_concrete
setblock 6 210 407 minecraft:gray_concrete
setblock 7 210 370 minecraft:gray_concrete
fill 8 210 405 8 210 407 minecraft:gray_concrete
fill 9 210 404 11 210 404 minecraft:gray_concrete
fill 9 210 408 11 210 408 minecraft:gray_concrete
fill 9 210 409 11 210 409 minecraft:iron_block
fill 12 210 405 12 210 407 minecraft:gray_concrete
setblock 13 210 410 minecraft:gray_concrete
setblock 17 210 370 minecraft:gray_concrete
setblock 23 210 410 minecraft:gray_concrete
setblock 27 210 370 minecraft:gray_concrete
fill 27 210 372 28 211 373 minecraft:light_blue_stained_glass
setblock 33 210 410 minecraft:gray_concrete
setblock 37 210 370 minecraft:gray_concrete
setblock 41 210 376 minecraft:gray_concrete
setblock 41 210 386 minecraft:gray_concrete
setblock 41 210 396 minecraft:gray_concrete
setblock 41 210 406 minecraft:gray_concrete
fill 0 211 375 0 211 378 minecraft:sea_lantern
fill 0 211 385 0 211 388 minecraft:sea_lantern
fill 0 211 395 0 211 398 minecraft:sea_lantern
fill 0 211 405 0 211 408 minecraft:sea_lantern
fill 3 211 369 6 211 369 minecraft:sea_lantern
fill 4 211 411 7 211 411 minecraft:sea_lantern
fill 13 211 369 16 211 369 minecraft:sea_lantern
fill 14 211 411 17 211 411 minecraft:sea_lantern
fill 23 211 369 26 211 369 minecraft:sea_lantern
fill 24 211 411 27 211 411 minecraft:sea_lantern
fill 33 211 369 36 211 369 minecraft:sea_lantern
fill 34 211 411 37 211 411 minecraft:sea_lantern
fill 42 211 370 42 211 373 minecraft:sea_lantern
fill 42 211 380 42 211 383 minecraft:sea_lantern
fill 42 211 390 42 211 393 minecraft:sea_lantern
fill 42 211 400 42 211 403 minecraft:sea_lantern
setblock 42 211 410 minecraft:sea_lantern
fill 0 212 375 0 228 378 minecraft:blue_concrete
fill 0 212 385 0 228 388 minecraft:blue_concrete
fill 0 212 395 0 228 398 minecraft:blue_concrete
fill 0 212 405 0 228 408 minecraft:blue_concrete
fill 3 212 369 6 228 369 minecraft:blue_concrete
fill 4 212 411 7 228 411 minecraft:blue_concrete
fill 13 212 369 16 228 369 minecraft:blue_concrete
fill 14 212 411 17 228 411 minecraft:blue_concrete
fill 23 212 369 26 228 369 minecraft:blue_concrete
fill 24 212 411 27 228 411 minecraft:blue_concrete
fill 33 212 369 36 228 369 minecraft:blue_concrete
fill 34 212 411 37 228 411 minecraft:blue_concrete
fill 42 212 370 42 228 373 minecraft:blue_concrete
fill 42 212 380 42 228 383 minecraft:blue_concrete
fill 42 212 390 42 228 393 minecraft:blue_concrete
fill 42 212 400 42 228 403 minecraft:blue_concrete
fill 42 212 410 42 228 410 minecraft:blue_concrete
setblock 3 213 372 minecraft:light[level=14]
setblock 3 213 380 minecraft:light[level=14]
setblock 3 213 388 minecraft:light[level=14]
setblock 3 213 396 minecraft:light[level=14]
setblock 3 213 404 minecraft:light[level=14]
setblock 11 213 372 minecraft:light[level=14]
setblock 11 213 380 minecraft:light[level=14]
setblock 11 213 388 minecraft:light[level=14]
setblock 11 213 396 minecraft:light[level=14]
setblock 11 213 404 minecraft:light[level=14]
setblock 19 213 372 minecraft:light[level=14]
setblock 19 213 380 minecraft:light[level=14]
setblock 19 213 388 minecraft:light[level=14]
setblock 19 213 396 minecraft:light[level=14]
setblock 19 213 404 minecraft:light[level=14]
setblock 27 213 372 minecraft:light[level=14]
setblock 27 213 380 minecraft:light[level=14]
setblock 27 213 388 minecraft:light[level=14]
setblock 27 213 396 minecraft:light[level=14]
setblock 27 213 404 minecraft:light[level=14]
setblock 35 213 372 minecraft:light[level=14]
setblock 35 213 380 minecraft:light[level=14]
setblock 35 213 388 minecraft:light[level=14]
setblock 35 213 396 minecraft:light[level=14]
setblock 35 213 404 minecraft:light[level=14]
fill 1 218 370 3 219 380 minecraft:black_concrete
fill 1 218 381 41 219 381 minecraft:yellow_concrete
fill 1 218 382 3 219 392 minecraft:black_concrete
fill 1 218 393 41 219 393 minecraft:yellow_concrete
fill 1 218 394 3 219 404 minecraft:black_concrete
fill 1 218 405 41 219 405 minecraft:yellow_concrete
fill 1 218 406 3 219 410 minecraft:black_concrete
fill 4 218 370 4 219 380 minecraft:gray_concrete
fill 4 218 382 4 219 392 minecraft:gray_concrete
fill 4 218 394 4 219 404 minecraft:gray_concrete
fill 4 218 406 4 219 410 minecraft:gray_concrete
fill 5 218 370 7 219 380 minecraft:black_concrete
fill 5 218 382 7 219 392 minecraft:black_concrete
fill 5 218 394 7 219 404 minecraft:black_concrete
fill 5 218 406 7 219 410 minecraft:black_concrete
fill 8 218 370 8 219 380 minecraft:gray_concrete
fill 8 218 382 8 219 392 minecraft:gray_concrete
fill 8 218 394 8 219 404 minecraft:gray_concrete
fill 8 218 406 8 219 410 minecraft:gray_concrete
fill 9 218 370 11 219 380 minecraft:black_concrete
fill 9 218 382 11 219 392 minecraft:black_concrete
fill 9 218 394 11 219 404 minecraft:black_concrete
fill 9 218 406 11 219 410 minecraft:black_concrete
fill 12 218 370 12 219 380 minecraft:gray_concrete
fill 12 218 382 12 219 392 minecraft:gray_concrete
fill 12 218 394 12 219 404 minecraft:gray_concrete
fill 12 218 406 12 219 410 minecraft:gray_concrete
fill 13 218 370 15 219 380 minecraft:black_concrete
fill 13 218 382 15 219 392 minecraft:black_concrete
fill 13 218 394 15 219 404 minecraft:black_concrete
fill 13 218 406 15 219 410 minecraft:black_concrete
fill 16 218 370 16 219 380 minecraft:gray_concrete
fill 16 218 382 16 219 392 minecraft:gray_concrete
fill 16 218 394 16 219 404 minecraft:gray_concrete
fill 16 218 406 16 219 410 minecraft:gray_concrete
fill 17 218 370 19 219 380 minecraft:black_concrete
fill 17 218 382 19 219 392 minecraft:black_concrete
fill 17 218 394 19 219 404 minecraft:black_concrete
fill 17 218 406 19 219 410 minecraft:black_concrete
fill 20 218 370 20 219 380 minecraft:gray_concrete
fill 20 218 382 20 219 392 minecraft:gray_concrete
fill 20 218 394 20 219 404 minecraft:gray_concrete
fill 20 218 406 20 219 410 minecraft:gray_concrete
fill 21 218 370 23 219 380 minecraft:black_concrete
fill 21 218 382 21 218 392 minecraft:black_concrete
fill 21 218 394 23 219 404 minecraft:black_concrete
fill 21 218 406 23 219 410 minecraft:black_concrete
fill 22 218 382 22 218 387 minecraft:black_concrete
fill 22 218 391 22 218 392 minecraft:black_concrete
fill 23 218 382 23 218 386 minecraft:black_concrete
setblock 23 218 392 minecraft:black_concrete
fill 24 218 370 24 219 380 minecraft:gray_concrete
fill 24 218 382 24 218 386 minecraft:gray_concrete
setblock 24 218 392 minecraft:gray_concrete
fill 24 218 394 24 219 404 minecraft:gray_concrete
fill 24 218 406 24 219 410 minecraft:gray_concrete
fill 25 218 370 27 219 380 minecraft:black_concrete
fill 25 218 382 27 218 386 minecraft:black_concrete
fill 25 218 392 27 218 392 minecraft:black_concrete
fill 25 218 394 27 219 404 minecraft:black_concrete
fill 25 218 406 27 219 410 minecraft:black_concrete
fill 26 218 387 27 218 387 minecraft:black_concrete
fill 26 218 391 27 218 391 minecraft:black_concrete
fill 27 218 388 27 218 390 minecraft:black_concrete
fill 28 218 370 28 219 380 minecraft:gray_concrete
fill 28 218 382 28 219 392 minecraft:gray_concrete
fill 28 218 394 28 219 404 minecraft:gray_concrete
fill 28 218 406 28 219 410 minecraft:gray_concrete
fill 29 218 370 31 219 380 minecraft:black_concrete
fill 29 218 382 31 219 392 minecraft:black_concrete
fill 29 218 394 31 219 404 minecraft:black_concrete
fill 29 218 406 31 219 410 minecraft:black_concrete
fill 32 218 370 32 219 380 minecraft:gray_concrete
fill 32 218 382 32 219 392 minecraft:gray_concrete
fill 32 218 394 32 219 404 minecraft:gray_concrete
fill 32 218 406 32 219 410 minecraft:gray_concrete
fill 33 218 370 35 219 380 minecraft:black_concrete
fill 33 218 382 35 219 392 minecraft:black_concrete
fill 33 218 394 35 219 404 minecraft:black_concrete
fill 33 218 406 35 219 410 minecraft:black_concrete
fill 36 218 370 36 219 380 minecraft:gray_concrete
fill 36 218 382 36 219 392 minecraft:gray_concrete
fill 36 218 394 36 219 404 minecraft:gray_concrete
fill 36 218 406 36 219 410 minecraft:gray_concrete
fill 37 218 370 39 219 380 minecraft:black_concrete
fill 37 218 382 39 219 392 minecraft:black_concrete
fill 37 218 394 39 219 404 minecraft:black_concrete
fill 37 218 406 39 219 410 minecraft:black_concrete
fill 40 218 370 40 219 380 minecraft:gray_concrete
fill 40 218 382 40 219 392 minecraft:gray_concrete
fill 40 218 394 40 219 404 minecraft:gray_concrete
fill 40 218 406 40 219 410 minecraft:gray_concrete
fill 41 218 370 41 219 380 minecraft:black_concrete
fill 41 218 382 41 219 392 minecraft:black_concrete
fill 41 218 394 41 219 404 minecraft:black_concrete
fill 41 218 406 41 219 410 minecraft:black_concrete
fill 21 219 382 21 219 386 minecraft:black_concrete
fill 21 219 387 21 219 391 minecraft:sea_lantern
setblock 21 219 392 minecraft:black_concrete
fill 22 219 382 23 219 385 minecraft:black_concrete
fill 22 219 386 22 219 387 minecraft:sea_lantern
fill 22 219 391 22 219 392 minecraft:sea_lantern
fill 23 219 386 26 219 386 minecraft:sea_lantern
fill 23 219 392 26 219 392 minecraft:sea_lantern
fill 24 219 382 24 219 385 minecraft:gray_concrete
fill 25 219 382 27 219 385 minecraft:black_concrete
fill 26 219 387 27 219 387 minecraft:sea_lantern
fill 26 219 391 27 219 391 minecraft:sea_lantern
setblock 27 219 386 minecraft:black_concrete
fill 27 219 388 27 219 390 minecraft:sea_lantern
setblock 27 219 392 minecraft:black_concrete
setblock 3 221 372 minecraft:light[level=14]
setblock 3 221 380 minecraft:light[level=14]
setblock 3 221 388 minecraft:light[level=14]
setblock 3 221 396 minecraft:light[level=14]
setblock 3 221 404 minecraft:light[level=14]
setblock 11 221 372 minecraft:light[level=14]
setblock 11 221 380 minecraft:light[level=14]
setblock 11 221 388 minecraft:light[level=14]
setblock 11 221 396 minecraft:light[level=14]
setblock 11 221 404 minecraft:light[level=14]
setblock 19 221 372 minecraft:light[level=14]
setblock 19 221 380 minecraft:light[level=14]
setblock 19 221 388 minecraft:light[level=14]
setblock 19 221 396 minecraft:light[level=14]
setblock 19 221 404 minecraft:light[level=14]
setblock 27 221 372 minecraft:light[level=14]
setblock 27 221 380 minecraft:light[level=14]
setblock 27 221 388 minecraft:light[level=14]
setblock 27 221 396 minecraft:light[level=14]
setblock 27 221 404 minecraft:light[level=14]
setblock 35 221 372 minecraft:light[level=14]
setblock 35 221 380 minecraft:light[level=14]
setblock 35 221 388 minecraft:light[level=14]
setblock 35 221 396 minecraft:light[level=14]
setblock 35 221 404 minecraft:light[level=14]
fill 1 223 371 1 271 371 minecraft:iron_block
fill 1 223 381 1 271 381 minecraft:iron_block
fill 1 223 391 1 271 391 minecraft:iron_block
fill 1 223 401 1 271 401 minecraft:iron_block
fill 2 223 410 2 271 410 minecraft:iron_block
fill 8 223 370 8 271 370 minecraft:iron_block
fill 12 223 410 12 271 410 minecraft:iron_block
fill 18 223 370 18 271 370 minecraft:iron_block
fill 22 223 410 22 271 410 minecraft:iron_block
fill 28 223 370 28 271 370 minecraft:iron_block
fill 32 223 410 32 271 410 minecraft:iron_block
fill 36 223 397 38 271 397 minecraft:iron_block
fill 36 223 407 36 271 407 minecraft:iron_block
fill 37 223 396 37 271 396 minecraft:iron_block
fill 37 223 398 37 271 398 minecraft:iron_block
fill 38 223 370 38 271 370 minecraft:iron_block
fill 41 223 377 41 271 377 minecraft:iron_block
fill 41 223 387 41 271 387 minecraft:iron_block
fill 41 223 397 41 271 397 minecraft:iron_block
fill 41 223 407 41 271 407 minecraft:iron_block
fill 1 225 374 1 225 377 minecraft:gray_concrete
fill 1 225 384 1 225 387 minecraft:gray_concrete
fill 1 225 394 1 225 397 minecraft:gray_concrete
fill 1 225 404 1 225 407 minecraft:gray_concrete
fill 2 225 370 5 225 370 minecraft:gray_concrete
fill 5 225 410 8 225 410 minecraft:gray_concrete
fill 12 225 370 15 225 370 minecraft:gray_concrete
fill 15 225 410 18 225 410 minecraft:gray_concrete
fill 22 225 370 25 225 370 minecraft:gray_concrete
fill 25 225 410 28 225 410 minecraft:gray_concrete
fill 32 225 370 35 225 370 minecraft:gray_concrete
fill 35 225 406 35 225 408 minecraft:gray_concrete
fill 35 225 410 38 225 410 minecraft:gray_concrete
setblock 36 225 396 minecraft:gray_concrete
setblock 36 225 398 minecraft:gray_concrete
fill 36 225 406 37 225 406 minecraft:gray_concrete
fill 36 225 408 37 225 408 minecraft:gray_concrete
setblock 37 225 407 minecraft:gray_concrete
setblock 38 225 396 minecraft:gray_concrete
setblock 38 225 398 minecraft:gray_concrete
fill 41 225 371 41 225 374 minecraft:gray_concrete
fill 41 225 381 41 225 384 minecraft:gray_concrete
fill 41 225 391 41 225 394 minecraft:gray_concrete
fill 41 225 401 41 225 404 minecraft:gray_concrete
setblock 1 228 372 minecraft:gray_concrete
setblock 1 228 382 minecraft:gray_concrete
setblock 1 228 392 minecraft:gray_concrete
setblock 1 228 402 minecraft:gray_concrete
setblock 3 228 410 minecraft:gray_concrete
setblock 7 228 370 minecraft:gray_concrete
setblock 13 228 410 minecraft:gray_concrete
setblock 17 228 370 minecraft:gray_concrete
setblock 23 228 410 minecraft:gray_concrete
setblock 27 228 370 minecraft:gray_concrete
setblock 33 228 410 minecraft:gray_concrete
setblock 37 228 370 minecraft:gray_concrete
setblock 41 228 376 minecraft:gray_concrete
setblock 41 228 386 minecraft:gray_concrete
setblock 41 228 396 minecraft:gray_concrete
setblock 41 228 406 minecraft:gray_concrete
fill 0 229 375 0 229 378 minecraft:sea_lantern
fill 0 229 385 0 229 388 minecraft:sea_lantern
fill 0 229 395 0 229 398 minecraft:sea_lantern
fill 0 229 405 0 229 408 minecraft:sea_lantern
fill 3 229 369 6 229 369 minecraft:sea_lantern
setblock 3 229 372 minecraft:light[level=14]
setblock 3 229 380 minecraft:light[level=14]
setblock 3 229 388 minecraft:light[level=14]
setblock 3 229 396 minecraft:light[level=14]
setblock 3 229 404 minecraft:light[level=14]
fill 4 229 411 7 229 411 minecraft:sea_lantern
setblock 11 229 372 minecraft:light[level=14]
setblock 11 229 380 minecraft:light[level=14]
setblock 11 229 388 minecraft:light[level=14]
setblock 11 229 396 minecraft:light[level=14]
setblock 11 229 404 minecraft:light[level=14]
fill 13 229 369 16 229 369 minecraft:sea_lantern
fill 14 229 411 17 229 411 minecraft:sea_lantern
setblock 19 229 372 minecraft:light[level=14]
setblock 19 229 380 minecraft:light[level=14]
setblock 19 229 388 minecraft:light[level=14]
setblock 19 229 396 minecraft:light[level=14]
setblock 19 229 404 minecraft:light[level=14]
fill 23 229 369 26 229 369 minecraft:sea_lantern
fill 24 229 411 27 229 411 minecraft:sea_lantern
setblock 27 229 372 minecraft:light[level=14]
setblock 27 229 380 minecraft:light[level=14]
setblock 27 229 388 minecraft:light[level=14]
setblock 27 229 396 minecraft:light[level=14]
setblock 27 229 404 minecraft:light[level=14]
fill 33 229 369 36 229 369 minecraft:sea_lantern
fill 34 229 411 37 229 411 minecraft:sea_lantern
setblock 35 229 372 minecraft:light[level=14]
setblock 35 229 380 minecraft:light[level=14]
setblock 35 229 388 minecraft:light[level=14]
setblock 35 229 396 minecraft:light[level=14]
setblock 35 229 404 minecraft:light[level=14]
fill 42 229 370 42 229 373 minecraft:sea_lantern
fill 42 229 380 42 229 383 minecraft:sea_lantern
fill 42 229 390 42 229 393 minecraft:sea_lantern
fill 42 229 400 42 229 403 minecraft:sea_lantern
setblock 42 229 410 minecraft:sea_lantern
fill 0 230 375 0 237 378 minecraft:blue_concrete
fill 0 230 385 0 237 388 minecraft:blue_concrete
fill 0 230 395 0 237 398 minecraft:blue_concrete
fill 0 230 405 0 237 408 minecraft:blue_concrete
fill 3 230 369 6 237 369 minecraft:blue_concrete
fill 4 230 411 7 237 411 minecraft:blue_concrete
fill 11 230 397 11 231 397 minecraft:sea_lantern
fill 13 230 369 16 237 369 minecraft:blue_concrete
fill 14 230 411 17 237 411 minecraft:blue_concrete
fill 23 230 369 26 237 369 minecraft:blue_concrete
fill 24 230 411 27 237 411 minecraft:blue_concrete
fill 33 230 369 36 237 369 minecraft:blue_concrete
fill 34 230 411 37 237 411 minecraft:blue_concrete
fill 42 230 370 42 237 373 minecraft:blue_concrete
fill 42 230 380 42 237 383 minecraft:blue_concrete
fill 42 230 390 42 237 393 minecraft:blue_concrete
fill 42 230 400 42 237 403 minecraft:blue_concrete
fill 42 230 410 42 237 410 minecraft:blue_concrete
fill 35 231 406 35 231 408 minecraft:gray_concrete
fill 36 231 385 36 244 385 minecraft:iron_block
fill 36 231 406 37 231 406 minecraft:gray_concrete
fill 36 231 408 37 231 408 minecraft:gray_concrete
setblock 37 231 407 minecraft:gray_concrete
fill 11 232 397 11 240 397 minecraft:black_concrete
fill 11 233 398 11 240 398 minecraft:black_concrete
setblock 36 233 396 minecraft:gray_concrete
setblock 36 233 398 minecraft:gray_concrete
setblock 38 233 396 minecraft:gray_concrete
setblock 38 233 398 minecraft:gray_concrete
setblock 1 234 372 minecraft:gray_concrete
fill 1 234 374 1 234 377 minecraft:gray_concrete
setblock 1 234 382 minecraft:gray_concrete
fill 1 234 384 1 234 387 minecraft:gray_concrete
setblock 1 234 392 minecraft:gray_concrete
fill 1 234 394 1 234 397 minecraft:gray_concrete
setblock 1 234 402 minecraft:gray_concrete
fill 1 234 404 1 234 407 minecraft:gray_concrete
fill 2 234 370 5 234 370 minecraft:gray_concrete
setblock 3 234 410 minecraft:gray_concrete
fill 5 234 410 8 234 410 minecraft:gray_concrete
setblock 7 234 370 minecraft:gray_concrete
fill 12 234 370 15 234 370 minecraft:gray_concrete
fill 12 234 397 12 240 398 minecraft:black_concrete
setblock 13 234 410 minecraft:gray_concrete
fill 15 234 410 18 234 410 minecraft:gray_concrete
setblock 17 234 370 minecraft:gray_concrete
fill 22 234 370 25 234 370 minecraft:gray_concrete
setblock 23 234 410 minecraft:gray_concrete
fill 25 234 410 28 234 410 minecraft:gray_concrete
setblock 27 234 370 minecraft:gray_concrete
fill 32 234 370 35 234 370 minecraft:gray_concrete
setblock 33 234 410 minecraft:gray_concrete
fill 35 234 410 38 234 410 minecraft:gray_concrete
setblock 37 234 370 minecraft:gray_concrete
fill 41 234 371 41 234 374 minecraft:gray_concrete
setblock 41 234 376 minecraft:gray_concrete
fill 41 234 381 41 234 384 minecraft:gray_concrete
setblock 41 234 386 minecraft:gray_concrete
fill 41 234 391 41 234 394 minecraft:gray_concrete
setblock 41 234 396 minecraft:gray_concrete
fill 41 234 401 41 234 404 minecraft:gray_concrete
setblock 41 234 406 minecraft:gray_concrete
fill 10 235 397 10 240 398 minecraft:black_concrete
fill 11 235 396 12 240 396 minecraft:black_concrete
fill 11 235 399 11 240 399 minecraft:black_concrete
fill 3 236 391 4 237 392 minecraft:light_blue_stained_glass
fill 10 236 396 10 240 396 minecraft:black_concrete
fill 10 236 399 10 240 399 minecraft:black_concrete
fill 12 236 399 12 240 399 minecraft:black_concrete
fill 13 236 397 13 240 398 minecraft:black_concrete
fill 27 236 372 27 245 372 minecraft:green_terracotta
setblock 3 237 372 minecraft:light[level=14]
setblock 3 237 380 minecraft:light[level=14]
setblock 3 237 388 minecraft:light[level=14]
setblock 3 237 396 minecraft:light[level=14]
setblock 3 237 404 minecraft:light[level=14]
fill 9 237 396 9 240 398 minecraft:black_concrete
setblock 11 237 372 minecraft:light[level=14]
setblock 11 237 380 minecraft:light[level=14]
setblock 11 237 388 minecraft:light[level=14]
fill 11 237 395 12 240 395 minecraft:black_concrete
setblock 11 237 404 minecraft:light[level=14]
fill 13 237 396 13 240 396 minecraft:black_concrete
fill 13 237 399 13 240 399 minecraft:black_concrete
setblock 19 237 372 minecraft:light[level=14]
setblock 19 237 380 minecraft:light[level=14]
setblock 19 237 388 minecraft:light[level=14]
setblock 19 237 396 minecraft:light[level=14]
setblock 19 237 404 minecraft:light[level=14]
setblock 27 237 380 minecraft:light[level=14]
setblock 27 237 388 minecraft:light[level=14]
setblock 27 237 396 minecraft:light[level=14]
setblock 27 237 404 minecraft:light[level=14]
setblock 35 237 372 minecraft:light[level=14]
setblock 35 237 380 minecraft:light[level=14]
setblock 35 237 388 minecraft:light[level=14]
setblock 35 237 396 minecraft:light[level=14]
setblock 35 237 404 minecraft:light[level=14]
fill 35 237 406 35 237 408 minecraft:gray_concrete
fill 36 237 406 37 237 406 minecraft:gray_concrete
fill 36 237 408 37 237 408 minecraft:gray_concrete
fill 36 237 409 36 238 410 minecraft:iron_block
setblock 37 237 407 minecraft:gray_concrete
fill 0 238 375 0 238 378 minecraft:sea_lantern
fill 0 238 385 0 238 388 minecraft:sea_lantern
fill 0 238 395 0 238 398 minecraft:sea_lantern
fill 0 238 405 0 238 408 minecraft:sea_lantern
fill 3 238 369 6 238 369 minecraft:sea_lantern
fill 4 238 411 7 238 411 minecraft:sea_lantern
fill 9 238 399 9 240 399 minecraft:black_concrete
fill 10 238 395 10 240 395 minecraft:black_concrete
fill 10 238 400 12 240 400 minecraft:black_concrete
fill 13 238 369 16 238 369 minecraft:sea_lantern
fill 13 238 395 13 240 395 minecraft:black_concrete
fill 14 238 397 14 240 398 minecraft:black_concrete
fill 14 238 411 17 238 411 minecraft:sea_lantern
fill 23 238 369 26 238 369 minecraft:sea_lantern
fill 24 238 411 27 238 411 minecraft:sea_lantern
fill 33 238 369 36 238 369 minecraft:sea_lantern
fill 34 238 411 37 238 411 minecraft:sea_lantern
setblock 36 238 406 minecraft:sea_lantern
setblock 36 238 408 minecraft:iron_block
fill 42 238 370 42 238 373 minecraft:sea_lantern
fill 42 238 380 42 238 383 minecraft:sea_lantern
fill 42 238 390 42 238 393 minecraft:sea_lantern
fill 42 238 400 42 238 403 minecraft:sea_lantern
setblock 42 238 410 minecraft:sea_lantern
fill 0 239 375 0 246 378 minecraft:blue_concrete
fill 0 239 385 0 246 388 minecraft:blue_concrete
fill 0 239 395 0 246 398 minecraft:blue_concrete
fill 0 239 405 0 246 408 minecraft:blue_concrete
fill 3 239 369 6 246 369 minecraft:blue_concrete
fill 4 239 411 7 246 411 minecraft:blue_concrete
fill 8 239 377 8 240 377 minecraft:white_stained_glass
fill 8 239 396 8 240 398 minecraft:black_concrete
fill 9 239 395 9 240 395 minecraft:black_concrete
fill 9 239 400 9 240 400 minecraft:black_concrete
fill 11 239 394 12 240 394 minecraft:black_concrete
fill 13 239 369 16 246 369 minecraft:blue_concrete
fill 13 239 400 13 240 400 minecraft:black_concrete
fill 14 239 396 14 240 396 minecraft:black_concrete
fill 14 239 399 14 240 399 minecraft:black_concrete
fill 14 239 411 17 246 411 minecraft:blue_concrete
fill 23 239 369 26 246 369 minecraft:blue_concrete
fill 24 239 411 27 246 411 minecraft:blue_concrete
fill 33 239 369 36 246 369 minecraft:blue_concrete
fill 34 239 411 37 246 411 minecraft:blue_concrete
fill 42 239 370 42 246 373 minecraft:blue_concrete
fill 42 239 380 42 246 383 minecraft:blue_concrete
fill 42 239 390 42 246 393 minecraft:blue_concrete
fill 42 239 400 42 246 403 minecraft:blue_concrete
fill 42 239 410 42 246 410 minecraft:blue_concrete
setblock 1 240 372 minecraft:gray_concrete
setblock 1 240 382 minecraft:gray_concrete
schedule function dropper:buildpart/84_2 1t
