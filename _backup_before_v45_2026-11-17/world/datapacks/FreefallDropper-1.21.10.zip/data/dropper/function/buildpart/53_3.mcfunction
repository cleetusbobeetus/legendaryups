fill 249 135 267 249 136 267 minecraft:gray_concrete
fill 250 135 229 250 136 229 minecraft:gray_concrete
fill 250 135 234 250 136 234 minecraft:gray_concrete
fill 250 135 264 250 136 264 minecraft:gray_concrete
fill 250 135 269 250 136 269 minecraft:gray_concrete
fill 251 135 228 251 177 228 minecraft:black_concrete
fill 252 135 229 252 136 229 minecraft:gray_concrete
fill 252 135 234 252 136 234 minecraft:gray_concrete
fill 252 135 264 252 136 264 minecraft:gray_concrete
fill 252 135 269 252 136 269 minecraft:gray_concrete
fill 254 135 229 254 136 229 minecraft:gray_concrete
fill 254 135 234 254 136 234 minecraft:gray_concrete
fill 254 135 264 254 136 264 minecraft:gray_concrete
fill 254 135 269 254 136 269 minecraft:gray_concrete
fill 256 135 229 256 136 229 minecraft:gray_concrete
fill 256 135 234 256 136 234 minecraft:gray_concrete
fill 256 135 264 256 136 264 minecraft:gray_concrete
fill 256 135 269 256 136 269 minecraft:gray_concrete
fill 258 135 229 258 136 229 minecraft:gray_concrete
fill 258 135 234 258 136 234 minecraft:gray_concrete
fill 258 135 264 258 136 264 minecraft:gray_concrete
fill 258 135 269 258 136 269 minecraft:gray_concrete
fill 260 135 229 260 136 229 minecraft:gray_concrete
fill 260 135 234 260 136 234 minecraft:gray_concrete
fill 260 135 264 260 136 264 minecraft:gray_concrete
fill 260 135 269 260 136 269 minecraft:gray_concrete
fill 262 135 230 262 136 230 minecraft:gray_concrete
fill 262 135 232 262 136 232 minecraft:gray_concrete
fill 262 135 265 262 136 265 minecraft:gray_concrete
fill 262 135 267 262 136 267 minecraft:gray_concrete
fill 268 135 230 268 136 230 minecraft:blue_terracotta
fill 268 135 232 268 136 232 minecraft:blue_terracotta
fill 268 135 234 268 136 234 minecraft:blue_terracotta
fill 268 135 236 268 136 236 minecraft:blue_terracotta
fill 268 135 262 268 136 262 minecraft:gray_concrete
fill 268 135 264 268 136 264 minecraft:gray_concrete
fill 268 135 266 268 136 266 minecraft:gray_concrete
fill 268 135 268 268 136 268 minecraft:gray_concrete
fill 269 135 229 269 136 229 minecraft:blue_terracotta
fill 269 135 237 269 136 237 minecraft:blue_terracotta
fill 269 135 261 269 136 261 minecraft:gray_concrete
fill 269 135 269 269 136 269 minecraft:gray_concrete
fill 271 135 229 271 136 229 minecraft:blue_terracotta
fill 271 135 237 271 136 237 minecraft:blue_terracotta
fill 271 135 243 271 136 243 minecraft:gray_concrete
fill 271 135 245 271 136 245 minecraft:gray_concrete
fill 271 135 247 271 136 247 minecraft:gray_concrete
fill 271 135 249 271 136 249 minecraft:gray_concrete
fill 271 135 251 271 136 251 minecraft:gray_concrete
fill 271 135 253 271 136 253 minecraft:gray_concrete
fill 271 135 261 271 136 261 minecraft:gray_concrete
fill 271 135 269 271 136 269 minecraft:gray_concrete
fill 272 135 242 272 136 242 minecraft:gray_concrete
fill 272 135 255 272 136 255 minecraft:gray_concrete
fill 273 135 229 273 136 229 minecraft:blue_terracotta
fill 273 135 237 273 136 237 minecraft:blue_terracotta
fill 273 135 261 273 136 261 minecraft:gray_concrete
fill 273 135 269 273 136 269 minecraft:gray_concrete
fill 274 135 242 274 136 242 minecraft:gray_concrete
fill 274 135 255 274 136 255 minecraft:gray_concrete
fill 275 135 229 275 136 229 minecraft:blue_terracotta
fill 275 135 237 275 136 237 minecraft:blue_terracotta
fill 275 135 261 275 136 261 minecraft:gray_concrete
fill 275 135 269 275 136 269 minecraft:gray_concrete
setblock 275 135 270 minecraft:magenta_concrete
fill 276 135 230 276 136 230 minecraft:blue_terracotta
fill 276 135 232 276 136 232 minecraft:blue_terracotta
fill 276 135 234 276 136 234 minecraft:blue_terracotta
fill 276 135 236 276 136 236 minecraft:blue_terracotta
fill 276 135 243 276 136 243 minecraft:gray_concrete
fill 276 135 245 276 136 245 minecraft:gray_concrete
fill 276 135 247 276 136 247 minecraft:gray_concrete
fill 276 135 249 276 136 249 minecraft:gray_concrete
fill 276 135 251 276 136 251 minecraft:gray_concrete
fill 276 135 253 276 136 253 minecraft:gray_concrete
fill 276 135 262 276 136 262 minecraft:gray_concrete
fill 276 135 264 276 136 264 minecraft:gray_concrete
fill 276 135 266 276 136 266 minecraft:gray_concrete
fill 276 135 268 276 136 268 minecraft:gray_concrete
setblock 277 135 237 minecraft:pearlescent_froglight
fill 277 135 268 277 236 268 minecraft:black_concrete
fill 235 136 230 235 145 230 minecraft:black_concrete
setblock 235 136 239 minecraft:ochre_froglight
fill 235 136 241 235 276 241 minecraft:black_concrete
setblock 235 136 255 minecraft:sea_lantern
setblock 238 136 239 minecraft:light[level=15]
setblock 246 136 231 minecraft:light[level=15]
setblock 246 136 239 minecraft:light[level=15]
setblock 246 136 247 minecraft:light[level=15]
setblock 246 136 255 minecraft:light[level=15]
setblock 246 136 263 minecraft:light[level=15]
fill 246 136 270 246 143 270 minecraft:black_concrete
setblock 254 136 239 minecraft:light[level=15]
setblock 254 136 247 minecraft:light[level=15]
setblock 254 136 255 minecraft:light[level=15]
setblock 254 136 263 minecraft:light[level=15]
setblock 262 136 239 minecraft:light[level=15]
setblock 262 136 247 minecraft:light[level=15]
setblock 262 136 255 minecraft:light[level=15]
setblock 262 136 263 minecraft:light[level=15]
setblock 267 136 270 minecraft:purple_concrete
setblock 270 136 239 minecraft:light[level=15]
setblock 270 136 247 minecraft:light[level=15]
setblock 270 136 255 minecraft:light[level=15]
setblock 275 136 270 minecraft:black_concrete
fill 277 136 237 277 179 237 minecraft:black_concrete
setblock 277 136 240 minecraft:purple_concrete
fill 277 136 243 277 206 243 minecraft:black_concrete
setblock 277 136 244 minecraft:cyan_concrete
fill 277 136 245 277 150 245 minecraft:black_concrete
setblock 277 136 255 minecraft:purple_concrete
fill 235 137 239 235 142 239 minecraft:black_concrete
fill 235 137 255 235 187 255 minecraft:black_concrete
setblock 236 137 230 minecraft:sea_lantern
setblock 236 137 232 minecraft:magenta_stained_glass
setblock 236 137 234 minecraft:ochre_froglight
setblock 236 137 236 minecraft:light_blue_stained_glass
setblock 236 137 243 minecraft:magenta_stained_glass
setblock 236 137 245 minecraft:black_stained_glass
setblock 236 137 247 minecraft:black_stained_glass
setblock 236 137 249 minecraft:cyan_stained_glass
setblock 236 137 251 minecraft:black_stained_glass
setblock 236 137 253 minecraft:ochre_froglight
setblock 236 137 262 minecraft:sea_lantern
setblock 236 137 264 minecraft:light_blue_stained_glass
setblock 236 137 266 minecraft:black_stained_glass
setblock 236 137 268 minecraft:ochre_froglight
setblock 237 137 229 minecraft:black_stained_glass
setblock 237 137 237 minecraft:light_blue_stained_glass
setblock 237 137 242 minecraft:cyan_stained_glass
setblock 237 137 255 minecraft:pearlescent_froglight
setblock 237 137 261 minecraft:sea_lantern
setblock 237 137 269 minecraft:cyan_stained_glass
setblock 239 137 229 minecraft:light_blue_stained_glass
setblock 239 137 237 minecraft:cyan_stained_glass
setblock 239 137 242 minecraft:black_stained_glass
setblock 239 137 255 minecraft:light_blue_stained_glass
setblock 239 137 261 minecraft:magenta_stained_glass
setblock 239 137 269 minecraft:sea_lantern
setblock 241 137 229 minecraft:black_stained_glass
setblock 241 137 237 minecraft:ochre_froglight
setblock 241 137 243 minecraft:black_stained_glass
setblock 241 137 245 minecraft:ochre_froglight
setblock 241 137 247 minecraft:sea_lantern
setblock 241 137 249 minecraft:black_stained_glass
setblock 241 137 251 minecraft:cyan_stained_glass
setblock 241 137 253 minecraft:black_stained_glass
setblock 241 137 261 minecraft:ochre_froglight
setblock 241 137 269 minecraft:black_stained_glass
setblock 243 137 229 minecraft:light_blue_stained_glass
setblock 243 137 237 minecraft:black_stained_glass
setblock 243 137 261 minecraft:black_stained_glass
setblock 243 137 269 minecraft:light_blue_stained_glass
setblock 244 137 230 minecraft:black_stained_glass
setblock 244 137 232 minecraft:pearlescent_froglight
setblock 244 137 234 minecraft:black_stained_glass
setblock 244 137 236 minecraft:black_stained_glass
setblock 244 137 262 minecraft:black_stained_glass
setblock 244 137 264 minecraft:black_stained_glass
setblock 244 137 266 minecraft:light_blue_stained_glass
setblock 244 137 268 minecraft:ochre_froglight
setblock 249 137 230 minecraft:ochre_froglight
setblock 249 137 232 minecraft:black_stained_glass
setblock 249 137 265 minecraft:black_stained_glass
setblock 249 137 267 minecraft:black_stained_glass
setblock 250 137 229 minecraft:magenta_stained_glass
setblock 250 137 234 minecraft:black_stained_glass
setblock 250 137 264 minecraft:cyan_stained_glass
setblock 250 137 269 minecraft:ochre_froglight
setblock 252 137 229 minecraft:black_stained_glass
setblock 252 137 234 minecraft:black_stained_glass
setblock 252 137 264 minecraft:black_stained_glass
setblock 252 137 269 minecraft:sea_lantern
setblock 254 137 229 minecraft:black_stained_glass
setblock 254 137 234 minecraft:black_stained_glass
setblock 254 137 264 minecraft:black_stained_glass
setblock 254 137 269 minecraft:cyan_stained_glass
setblock 256 137 229 minecraft:magenta_stained_glass
setblock 256 137 234 minecraft:ochre_froglight
setblock 256 137 264 minecraft:black_stained_glass
setblock 256 137 269 minecraft:ochre_froglight
setblock 258 137 229 minecraft:black_stained_glass
setblock 258 137 234 minecraft:black_stained_glass
setblock 258 137 264 minecraft:black_stained_glass
setblock 258 137 269 minecraft:pearlescent_froglight
setblock 260 137 229 minecraft:sea_lantern
setblock 260 137 234 minecraft:black_stained_glass
setblock 260 137 264 minecraft:black_stained_glass
setblock 260 137 269 minecraft:cyan_stained_glass
setblock 262 137 230 minecraft:ochre_froglight
setblock 262 137 232 minecraft:ochre_froglight
setblock 262 137 265 minecraft:sea_lantern
setblock 262 137 267 minecraft:sea_lantern
setblock 264 137 228 minecraft:purple_concrete
fill 267 137 270 267 171 270 minecraft:black_concrete
setblock 268 137 230 minecraft:black_stained_glass
setblock 268 137 232 minecraft:magenta_stained_glass
setblock 268 137 234 minecraft:ochre_froglight
setblock 268 137 236 minecraft:magenta_stained_glass
setblock 268 137 262 minecraft:light_blue_stained_glass
setblock 268 137 264 minecraft:black_stained_glass
setblock 268 137 266 minecraft:cyan_stained_glass
setblock 268 137 268 minecraft:black_stained_glass
setblock 269 137 229 minecraft:light_blue_stained_glass
setblock 269 137 237 minecraft:black_stained_glass
setblock 269 137 261 minecraft:black_stained_glass
setblock 269 137 269 minecraft:black_stained_glass
setblock 271 137 229 minecraft:ochre_froglight
setblock 271 137 237 minecraft:pearlescent_froglight
setblock 271 137 243 minecraft:black_stained_glass
setblock 271 137 245 minecraft:light_blue_stained_glass
setblock 271 137 247 minecraft:black_stained_glass
setblock 271 137 249 minecraft:sea_lantern
setblock 271 137 251 minecraft:black_stained_glass
setblock 271 137 253 minecraft:cyan_stained_glass
setblock 271 137 261 minecraft:black_stained_glass
setblock 271 137 269 minecraft:black_stained_glass
setblock 272 137 242 minecraft:black_stained_glass
setblock 272 137 255 minecraft:light_blue_stained_glass
setblock 273 137 229 minecraft:black_stained_glass
setblock 273 137 237 minecraft:light_blue_stained_glass
setblock 273 137 261 minecraft:sea_lantern
setblock 273 137 269 minecraft:sea_lantern
setblock 274 137 242 minecraft:pearlescent_froglight
setblock 274 137 255 minecraft:light_blue_stained_glass
setblock 275 137 229 minecraft:black_stained_glass
setblock 275 137 237 minecraft:cyan_stained_glass
setblock 275 137 261 minecraft:black_stained_glass
setblock 275 137 269 minecraft:black_stained_glass
setblock 275 137 270 minecraft:cyan_concrete
setblock 276 137 230 minecraft:pearlescent_froglight
setblock 276 137 232 minecraft:cyan_stained_glass
setblock 276 137 234 minecraft:black_stained_glass
setblock 276 137 236 minecraft:cyan_stained_glass
setblock 276 137 243 minecraft:black_stained_glass
setblock 276 137 245 minecraft:black_stained_glass
setblock 276 137 247 minecraft:pearlescent_froglight
setblock 276 137 249 minecraft:light_blue_stained_glass
setblock 276 137 251 minecraft:sea_lantern
setblock 276 137 253 minecraft:magenta_stained_glass
setblock 276 137 262 minecraft:cyan_stained_glass
setblock 276 137 264 minecraft:cyan_stained_glass
setblock 276 137 266 minecraft:black_stained_glass
setblock 276 137 268 minecraft:black_stained_glass
fill 277 137 240 277 140 240 minecraft:black_concrete
fill 277 137 244 277 204 244 minecraft:black_concrete
fill 277 137 255 277 182 255 minecraft:black_concrete
fill 236 138 230 236 139 230 minecraft:gray_concrete
fill 236 138 232 236 139 232 minecraft:gray_concrete
fill 236 138 234 236 139 234 minecraft:gray_concrete
fill 236 138 236 236 139 236 minecraft:gray_concrete
fill 236 138 243 236 139 243 minecraft:black_concrete
fill 236 138 245 236 139 245 minecraft:black_concrete
fill 236 138 247 236 139 247 minecraft:black_concrete
fill 236 138 249 236 139 249 minecraft:black_concrete
fill 236 138 251 236 139 251 minecraft:black_concrete
fill 236 138 253 236 139 253 minecraft:black_concrete
fill 236 138 262 236 139 262 minecraft:blue_terracotta
fill 236 138 264 236 139 264 minecraft:blue_terracotta
fill 236 138 266 236 139 266 minecraft:blue_terracotta
fill 236 138 268 236 139 268 minecraft:blue_terracotta
fill 237 138 229 237 139 229 minecraft:gray_concrete
fill 237 138 237 237 139 237 minecraft:gray_concrete
fill 237 138 242 237 139 242 minecraft:black_concrete
fill 237 138 255 237 139 255 minecraft:black_concrete
fill 237 138 261 237 139 261 minecraft:blue_terracotta
fill 237 138 269 237 139 269 minecraft:blue_terracotta
fill 239 138 229 239 139 229 minecraft:gray_concrete
fill 239 138 237 239 139 237 minecraft:gray_concrete
fill 239 138 242 239 139 242 minecraft:black_concrete
fill 239 138 255 239 139 255 minecraft:black_concrete
fill 239 138 261 239 139 261 minecraft:blue_terracotta
fill 239 138 269 239 139 269 minecraft:blue_terracotta
fill 241 138 229 241 139 229 minecraft:gray_concrete
fill 241 138 237 241 139 237 minecraft:gray_concrete
fill 241 138 243 241 139 243 minecraft:black_concrete
fill 241 138 245 241 139 245 minecraft:black_concrete
fill 241 138 247 241 139 247 minecraft:black_concrete
fill 241 138 249 241 139 249 minecraft:black_concrete
fill 241 138 251 241 139 251 minecraft:black_concrete
fill 241 138 253 241 139 253 minecraft:black_concrete
fill 241 138 261 241 139 261 minecraft:blue_terracotta
fill 241 138 269 241 139 269 minecraft:blue_terracotta
setblock 241 138 270 minecraft:purple_concrete
fill 243 138 229 243 139 229 minecraft:gray_concrete
fill 243 138 237 243 139 237 minecraft:gray_concrete
fill 243 138 261 243 139 261 minecraft:blue_terracotta
fill 243 138 269 243 139 269 minecraft:blue_terracotta
fill 244 138 230 244 139 230 minecraft:gray_concrete
fill 244 138 232 244 139 232 minecraft:gray_concrete
fill 244 138 234 244 139 234 minecraft:gray_concrete
fill 244 138 236 244 139 236 minecraft:gray_concrete
fill 244 138 262 244 139 262 minecraft:blue_terracotta
fill 244 138 264 244 139 264 minecraft:blue_terracotta
fill 244 138 266 244 139 266 minecraft:blue_terracotta
fill 244 138 268 244 139 268 minecraft:blue_terracotta
fill 249 138 230 249 139 230 minecraft:gray_concrete
fill 249 138 232 249 139 232 minecraft:gray_concrete
fill 249 138 265 249 139 265 minecraft:gray_concrete
fill 249 138 267 249 139 267 minecraft:gray_concrete
fill 250 138 229 250 139 229 minecraft:gray_concrete
fill 250 138 234 250 139 234 minecraft:gray_concrete
fill 250 138 264 250 139 264 minecraft:gray_concrete
fill 250 138 269 250 139 269 minecraft:gray_concrete
fill 252 138 229 252 139 229 minecraft:gray_concrete
fill 252 138 234 252 139 234 minecraft:gray_concrete
fill 252 138 264 252 139 264 minecraft:gray_concrete
fill 252 138 269 252 139 269 minecraft:gray_concrete
fill 254 138 229 254 139 229 minecraft:gray_concrete
fill 254 138 234 254 139 234 minecraft:gray_concrete
fill 254 138 264 254 139 264 minecraft:gray_concrete
fill 254 138 269 254 139 269 minecraft:gray_concrete
fill 256 138 229 256 139 229 minecraft:gray_concrete
fill 256 138 234 256 139 234 minecraft:gray_concrete
fill 256 138 264 256 139 264 minecraft:gray_concrete
fill 256 138 269 256 139 269 minecraft:gray_concrete
fill 258 138 229 258 139 229 minecraft:gray_concrete
fill 258 138 234 258 139 234 minecraft:gray_concrete
fill 258 138 264 258 139 264 minecraft:gray_concrete
fill 258 138 269 258 139 269 minecraft:gray_concrete
fill 260 138 229 260 139 229 minecraft:gray_concrete
fill 260 138 234 260 139 234 minecraft:gray_concrete
fill 260 138 264 260 139 264 minecraft:gray_concrete
fill 260 138 269 260 139 269 minecraft:gray_concrete
fill 262 138 230 262 139 230 minecraft:gray_concrete
fill 262 138 232 262 139 232 minecraft:gray_concrete
fill 262 138 265 262 139 265 minecraft:gray_concrete
fill 262 138 267 262 139 267 minecraft:gray_concrete
fill 264 138 228 264 187 228 minecraft:black_concrete
fill 268 138 230 268 139 230 minecraft:blue_terracotta
fill 268 138 232 268 139 232 minecraft:blue_terracotta
fill 268 138 234 268 139 234 minecraft:blue_terracotta
fill 268 138 236 268 139 236 minecraft:blue_terracotta
fill 268 138 262 268 139 262 minecraft:gray_concrete
fill 268 138 264 268 139 264 minecraft:gray_concrete
fill 268 138 266 268 139 266 minecraft:gray_concrete
fill 268 138 268 268 139 268 minecraft:gray_concrete
fill 269 138 229 269 139 229 minecraft:blue_terracotta
fill 269 138 237 269 139 237 minecraft:blue_terracotta
fill 269 138 261 269 139 261 minecraft:gray_concrete
fill 269 138 269 269 139 269 minecraft:gray_concrete
fill 271 138 229 271 139 229 minecraft:blue_terracotta
fill 271 138 237 271 139 237 minecraft:blue_terracotta
fill 271 138 243 271 139 243 minecraft:gray_concrete
fill 271 138 245 271 139 245 minecraft:gray_concrete
fill 271 138 247 271 139 247 minecraft:gray_concrete
fill 271 138 249 271 139 249 minecraft:gray_concrete
fill 271 138 251 271 139 251 minecraft:gray_concrete
fill 271 138 253 271 139 253 minecraft:gray_concrete
fill 271 138 261 271 139 261 minecraft:gray_concrete
fill 271 138 269 271 139 269 minecraft:gray_concrete
fill 272 138 242 272 139 242 minecraft:gray_concrete
fill 272 138 255 272 139 255 minecraft:gray_concrete
fill 273 138 229 273 139 229 minecraft:blue_terracotta
fill 273 138 237 273 139 237 minecraft:blue_terracotta
fill 273 138 261 273 139 261 minecraft:gray_concrete
fill 273 138 269 273 139 269 minecraft:gray_concrete
fill 274 138 242 274 139 242 minecraft:gray_concrete
fill 274 138 255 274 139 255 minecraft:gray_concrete
fill 275 138 229 275 139 229 minecraft:blue_terracotta
fill 275 138 237 275 139 237 minecraft:blue_terracotta
fill 275 138 261 275 139 261 minecraft:gray_concrete
fill 275 138 269 275 139 269 minecraft:gray_concrete
fill 275 138 270 275 157 270 minecraft:black_concrete
setblock 276 138 228 minecraft:ochre_froglight
fill 276 138 230 276 139 230 minecraft:blue_terracotta
fill 276 138 232 276 139 232 minecraft:blue_terracotta
fill 276 138 234 276 139 234 minecraft:blue_terracotta
fill 276 138 236 276 139 236 minecraft:blue_terracotta
fill 276 138 243 276 139 243 minecraft:gray_concrete
fill 276 138 245 276 139 245 minecraft:gray_concrete
fill 276 138 247 276 139 247 minecraft:gray_concrete
fill 276 138 249 276 139 249 minecraft:gray_concrete
fill 276 138 251 276 139 251 minecraft:gray_concrete
fill 276 138 253 276 139 253 minecraft:gray_concrete
fill 276 138 262 276 139 262 minecraft:gray_concrete
fill 276 138 264 276 139 264 minecraft:gray_concrete
fill 276 138 266 276 139 266 minecraft:gray_concrete
fill 276 138 268 276 139 268 minecraft:gray_concrete
fill 277 138 228 277 308 228 minecraft:black_concrete
fill 235 139 259 235 148 259 minecraft:black_concrete
setblock 235 139 260 minecraft:ochre_froglight
setblock 236 139 228 minecraft:sea_lantern
setblock 238 139 238 minecraft:light[level=12]
setblock 238 139 259 minecraft:light[level=12]
fill 241 139 270 241 183 270 minecraft:black_concrete
setblock 245 139 231 minecraft:light[level=12]
setblock 245 139 238 minecraft:light[level=12]
setblock 245 139 245 minecraft:light[level=12]
setblock 245 139 252 minecraft:light[level=12]
setblock 245 139 259 minecraft:light[level=12]
setblock 245 139 266 minecraft:light[level=12]
setblock 252 139 238 minecraft:light[level=12]
setblock 252 139 245 minecraft:light[level=12]
setblock 252 139 252 minecraft:light[level=12]
setblock 252 139 259 minecraft:light[level=12]
setblock 259 139 238 minecraft:light[level=12]
setblock 259 139 245 minecraft:light[level=12]
setblock 259 139 252 minecraft:light[level=12]
setblock 259 139 259 minecraft:light[level=12]
setblock 266 139 231 minecraft:light[level=12]
setblock 266 139 238 minecraft:light[level=12]
setblock 266 139 245 minecraft:light[level=12]
setblock 266 139 252 minecraft:light[level=12]
setblock 266 139 259 minecraft:light[level=12]
setblock 266 139 266 minecraft:light[level=12]
setblock 273 139 238 minecraft:light[level=12]
setblock 273 139 259 minecraft:light[level=12]
fill 276 139 228 276 279 228 minecraft:black_concrete
setblock 277 139 266 minecraft:magenta_concrete
fill 235 140 260 235 186 260 minecraft:black_concrete
fill 236 140 228 236 308 228 minecraft:black_concrete
setblock 236 140 230 minecraft:ochre_froglight
setblock 236 140 232 minecraft:black_stained_glass
setblock 236 140 234 minecraft:magenta_stained_glass
setblock 236 140 236 minecraft:pearlescent_froglight
setblock 236 140 243 minecraft:ochre_froglight
setblock 236 140 245 minecraft:black_stained_glass
setblock 236 140 247 minecraft:ochre_froglight
setblock 236 140 249 minecraft:ochre_froglight
setblock 236 140 251 minecraft:light_blue_stained_glass
setblock 236 140 253 minecraft:magenta_stained_glass
setblock 236 140 262 minecraft:cyan_stained_glass
setblock 236 140 264 minecraft:ochre_froglight
setblock 236 140 266 minecraft:black_stained_glass
setblock 236 140 268 minecraft:black_stained_glass
setblock 237 140 229 minecraft:black_stained_glass
setblock 237 140 237 minecraft:cyan_stained_glass
setblock 237 140 242 minecraft:black_stained_glass
setblock 237 140 255 minecraft:light_blue_stained_glass
setblock 237 140 261 minecraft:sea_lantern
setblock 237 140 269 minecraft:magenta_stained_glass
setblock 239 140 229 minecraft:sea_lantern
setblock 239 140 237 minecraft:black_stained_glass
setblock 239 140 242 minecraft:black_stained_glass
setblock 239 140 255 minecraft:black_stained_glass
setblock 239 140 261 minecraft:black_stained_glass
setblock 239 140 269 minecraft:black_stained_glass
setblock 241 140 229 minecraft:cyan_stained_glass
setblock 241 140 237 minecraft:ochre_froglight
setblock 241 140 243 minecraft:black_stained_glass
setblock 241 140 245 minecraft:sea_lantern
setblock 241 140 247 minecraft:black_stained_glass
setblock 241 140 249 minecraft:pearlescent_froglight
setblock 241 140 251 minecraft:magenta_stained_glass
setblock 241 140 253 minecraft:black_stained_glass
setblock 241 140 261 minecraft:black_stained_glass
setblock 241 140 269 minecraft:cyan_stained_glass
setblock 243 140 228 minecraft:cyan_concrete
setblock 243 140 229 minecraft:black_stained_glass
setblock 243 140 237 minecraft:cyan_stained_glass
setblock 243 140 261 minecraft:light_blue_stained_glass
setblock 243 140 269 minecraft:black_stained_glass
setblock 244 140 230 minecraft:black_stained_glass
setblock 244 140 232 minecraft:light_blue_stained_glass
setblock 244 140 234 minecraft:cyan_stained_glass
setblock 244 140 236 minecraft:cyan_stained_glass
setblock 244 140 262 minecraft:sea_lantern
setblock 244 140 264 minecraft:magenta_stained_glass
setblock 244 140 266 minecraft:ochre_froglight
setblock 244 140 268 minecraft:pearlescent_froglight
setblock 249 140 230 minecraft:pearlescent_froglight
setblock 249 140 232 minecraft:magenta_stained_glass
setblock 249 140 265 minecraft:black_stained_glass
setblock 249 140 267 minecraft:black_stained_glass
setblock 250 140 229 minecraft:black_stained_glass
setblock 250 140 234 minecraft:black_stained_glass
setblock 250 140 264 minecraft:magenta_stained_glass
setblock 250 140 269 minecraft:black_stained_glass
setblock 252 140 229 minecraft:cyan_stained_glass
setblock 252 140 234 minecraft:black_stained_glass
setblock 252 140 264 minecraft:pearlescent_froglight
setblock 252 140 269 minecraft:black_stained_glass
setblock 254 140 229 minecraft:black_stained_glass
setblock 254 140 234 minecraft:black_stained_glass
setblock 254 140 264 minecraft:ochre_froglight
setblock 254 140 269 minecraft:black_stained_glass
setblock 254 140 270 minecraft:magenta_concrete
fill 256 140 228 256 308 228 minecraft:black_concrete
setblock 256 140 229 minecraft:black_stained_glass
setblock 256 140 234 minecraft:black_stained_glass
setblock 256 140 264 minecraft:black_stained_glass
setblock 256 140 269 minecraft:sea_lantern
setblock 257 140 228 minecraft:verdant_froglight
setblock 258 140 229 minecraft:black_stained_glass
setblock 258 140 234 minecraft:black_stained_glass
setblock 258 140 264 minecraft:magenta_stained_glass
setblock 258 140 269 minecraft:sea_lantern
setblock 260 140 229 minecraft:magenta_stained_glass
setblock 260 140 234 minecraft:sea_lantern
setblock 260 140 264 minecraft:light_blue_stained_glass
setblock 260 140 269 minecraft:sea_lantern
setblock 262 140 230 minecraft:black_stained_glass
setblock 262 140 232 minecraft:black_stained_glass
setblock 262 140 265 minecraft:black_stained_glass
setblock 262 140 267 minecraft:ochre_froglight
setblock 268 140 230 minecraft:black_stained_glass
setblock 268 140 232 minecraft:ochre_froglight
setblock 268 140 234 minecraft:black_stained_glass
setblock 268 140 236 minecraft:black_stained_glass
setblock 268 140 262 minecraft:ochre_froglight
setblock 268 140 264 minecraft:black_stained_glass
setblock 268 140 266 minecraft:light_blue_stained_glass
setblock 268 140 268 minecraft:light_blue_stained_glass
setblock 269 140 229 minecraft:cyan_stained_glass
setblock 269 140 237 minecraft:cyan_stained_glass
setblock 269 140 261 minecraft:magenta_stained_glass
setblock 269 140 269 minecraft:black_stained_glass
setblock 271 140 229 minecraft:black_stained_glass
setblock 271 140 237 minecraft:ochre_froglight
setblock 271 140 243 minecraft:black_stained_glass
setblock 271 140 245 minecraft:magenta_stained_glass
setblock 271 140 247 minecraft:black_stained_glass
setblock 271 140 249 minecraft:pearlescent_froglight
setblock 271 140 251 minecraft:black_stained_glass
setblock 271 140 253 minecraft:sea_lantern
setblock 271 140 261 minecraft:pearlescent_froglight
setblock 271 140 269 minecraft:cyan_stained_glass
setblock 272 140 242 minecraft:cyan_stained_glass
setblock 272 140 255 minecraft:black_stained_glass
setblock 273 140 229 minecraft:magenta_stained_glass
setblock 273 140 237 minecraft:magenta_stained_glass
setblock 273 140 261 minecraft:black_stained_glass
setblock 273 140 269 minecraft:black_stained_glass
setblock 274 140 242 minecraft:black_stained_glass
setblock 274 140 255 minecraft:ochre_froglight
setblock 275 140 229 minecraft:ochre_froglight
setblock 275 140 237 minecraft:light_blue_stained_glass
setblock 275 140 261 minecraft:pearlescent_froglight
setblock 275 140 269 minecraft:black_stained_glass
setblock 276 140 230 minecraft:light_blue_stained_glass
setblock 276 140 232 minecraft:light_blue_stained_glass
setblock 276 140 234 minecraft:cyan_stained_glass
setblock 276 140 236 minecraft:black_stained_glass
setblock 276 140 243 minecraft:cyan_stained_glass
setblock 276 140 245 minecraft:sea_lantern
setblock 276 140 247 minecraft:black_stained_glass
setblock 276 140 249 minecraft:sea_lantern
setblock 276 140 251 minecraft:light_blue_stained_glass
setblock 276 140 253 minecraft:black_stained_glass
setblock 276 140 262 minecraft:ochre_froglight
setblock 276 140 264 minecraft:black_stained_glass
setblock 276 140 266 minecraft:cyan_stained_glass
setblock 276 140 268 minecraft:magenta_stained_glass
fill 277 140 266 277 174 266 minecraft:black_concrete
fill 236 141 230 236 142 230 minecraft:gray_concrete
fill 236 141 232 236 142 232 minecraft:gray_concrete
fill 236 141 234 236 142 234 minecraft:gray_concrete
fill 236 141 236 236 142 236 minecraft:gray_concrete
fill 236 141 243 236 142 243 minecraft:black_concrete
fill 236 141 245 236 142 245 minecraft:black_concrete
fill 236 141 247 236 142 247 minecraft:black_concrete
fill 236 141 249 236 142 249 minecraft:black_concrete
fill 236 141 251 236 142 251 minecraft:black_concrete
fill 236 141 253 236 142 253 minecraft:black_concrete
fill 236 141 262 236 142 262 minecraft:blue_terracotta
fill 236 141 264 236 142 264 minecraft:blue_terracotta
fill 236 141 266 236 142 266 minecraft:blue_terracotta
fill 236 141 268 236 142 268 minecraft:blue_terracotta
fill 237 141 229 237 142 229 minecraft:gray_concrete
fill 237 141 237 237 142 237 minecraft:gray_concrete
fill 237 141 242 237 142 242 minecraft:black_concrete
fill 237 141 255 237 142 255 minecraft:black_concrete
fill 237 141 261 237 142 261 minecraft:blue_terracotta
fill 237 141 269 237 142 269 minecraft:blue_terracotta
fill 239 141 229 239 142 229 minecraft:gray_concrete
fill 239 141 237 239 142 237 minecraft:gray_concrete
fill 239 141 242 239 142 242 minecraft:black_concrete
fill 239 141 255 239 142 255 minecraft:black_concrete
fill 239 141 261 239 142 261 minecraft:blue_terracotta
fill 239 141 269 239 142 269 minecraft:blue_terracotta
fill 241 141 229 241 142 229 minecraft:gray_concrete
fill 241 141 237 241 142 237 minecraft:gray_concrete
fill 241 141 243 241 142 243 minecraft:black_concrete
fill 241 141 245 241 142 245 minecraft:black_concrete
fill 241 141 247 241 142 247 minecraft:black_concrete
setblock 241 141 249 minecraft:black_concrete
setblock 241 141 251 minecraft:black_concrete
fill 241 141 253 241 142 253 minecraft:black_concrete
fill 241 141 261 241 142 261 minecraft:blue_terracotta
fill 241 141 269 241 142 269 minecraft:blue_terracotta
fill 243 141 228 243 154 228 minecraft:black_concrete
fill 243 141 229 243 142 229 minecraft:gray_concrete
fill 243 141 237 243 142 237 minecraft:gray_concrete
setblock 243 141 261 minecraft:blue_terracotta
fill 243 141 269 243 142 269 minecraft:blue_terracotta
fill 244 141 230 244 142 230 minecraft:gray_concrete
fill 244 141 232 244 142 232 minecraft:gray_concrete
fill 244 141 234 244 142 234 minecraft:gray_concrete
fill 244 141 236 244 142 236 minecraft:gray_concrete
setblock 244 141 262 minecraft:blue_terracotta
fill 244 141 264 244 142 264 minecraft:blue_terracotta
fill 244 141 266 244 142 266 minecraft:blue_terracotta
fill 244 141 268 244 142 268 minecraft:blue_terracotta
fill 249 141 230 249 142 230 minecraft:gray_concrete
fill 249 141 232 249 142 232 minecraft:gray_concrete
setblock 249 141 265 minecraft:gray_concrete
fill 249 141 267 249 142 267 minecraft:gray_concrete
fill 250 141 229 250 142 229 minecraft:gray_concrete
fill 250 141 234 250 142 234 minecraft:gray_concrete
fill 250 141 264 250 142 264 minecraft:gray_concrete
fill 250 141 269 250 142 269 minecraft:gray_concrete
setblock 251 141 270 minecraft:cyan_concrete
fill 252 141 229 252 142 229 minecraft:gray_concrete
fill 252 141 234 252 142 234 minecraft:gray_concrete
fill 252 141 264 252 142 264 minecraft:gray_concrete
fill 252 141 269 252 142 269 minecraft:gray_concrete
fill 254 141 229 254 142 229 minecraft:gray_concrete
fill 254 141 234 254 142 234 minecraft:gray_concrete
setblock 254 141 264 minecraft:gray_concrete
fill 254 141 269 254 142 269 minecraft:gray_concrete
fill 254 141 270 254 197 270 minecraft:black_concrete
fill 256 141 229 256 142 229 minecraft:gray_concrete
fill 256 141 234 256 142 234 minecraft:gray_concrete
setblock 256 141 264 minecraft:gray_concrete
fill 256 141 269 256 142 269 minecraft:gray_concrete
fill 257 141 228 257 142 228 minecraft:black_concrete
fill 258 141 229 258 142 229 minecraft:gray_concrete
fill 258 141 234 258 142 234 minecraft:gray_concrete
fill 258 141 264 258 142 264 minecraft:gray_concrete
fill 258 141 269 258 142 269 minecraft:gray_concrete
setblock 259 141 270 minecraft:purple_concrete
fill 260 141 229 260 142 229 minecraft:gray_concrete
fill 260 141 234 260 142 234 minecraft:gray_concrete
fill 260 141 264 260 142 264 minecraft:gray_concrete
fill 260 141 269 260 142 269 minecraft:gray_concrete
fill 262 141 230 262 142 230 minecraft:gray_concrete
fill 262 141 232 262 142 232 minecraft:gray_concrete
fill 262 141 265 262 142 265 minecraft:gray_concrete
fill 262 141 267 262 142 267 minecraft:gray_concrete
fill 268 141 230 268 142 230 minecraft:blue_terracotta
fill 268 141 232 268 142 232 minecraft:blue_terracotta
fill 268 141 234 268 142 234 minecraft:blue_terracotta
fill 268 141 236 268 142 236 minecraft:blue_terracotta
fill 268 141 262 268 142 262 minecraft:gray_concrete
fill 268 141 264 268 142 264 minecraft:gray_concrete
fill 268 141 266 268 142 266 minecraft:gray_concrete
fill 268 141 268 268 142 268 minecraft:gray_concrete
fill 269 141 229 269 142 229 minecraft:blue_terracotta
fill 269 141 237 269 142 237 minecraft:blue_terracotta
fill 269 141 261 269 142 261 minecraft:gray_concrete
fill 269 141 269 269 142 269 minecraft:gray_concrete
fill 271 141 229 271 142 229 minecraft:blue_terracotta
fill 271 141 237 271 142 237 minecraft:blue_terracotta
fill 271 141 243 271 142 243 minecraft:gray_concrete
fill 271 141 245 271 142 245 minecraft:gray_concrete
fill 271 141 247 271 142 247 minecraft:gray_concrete
fill 271 141 249 271 142 249 minecraft:gray_concrete
fill 271 141 251 271 142 251 minecraft:gray_concrete
fill 271 141 253 271 142 253 minecraft:gray_concrete
fill 271 141 261 271 142 261 minecraft:gray_concrete
fill 271 141 269 271 142 269 minecraft:gray_concrete
fill 272 141 242 272 142 242 minecraft:gray_concrete
fill 272 141 255 272 142 255 minecraft:gray_concrete
fill 273 141 229 273 142 229 minecraft:blue_terracotta
fill 273 141 237 273 142 237 minecraft:blue_terracotta
fill 273 141 261 273 142 261 minecraft:gray_concrete
fill 273 141 269 273 142 269 minecraft:gray_concrete
fill 274 141 242 274 142 242 minecraft:gray_concrete
fill 274 141 255 274 142 255 minecraft:gray_concrete
fill 275 141 229 275 142 229 minecraft:blue_terracotta
fill 275 141 237 275 142 237 minecraft:blue_terracotta
fill 275 141 261 275 142 261 minecraft:gray_concrete
fill 275 141 269 275 142 269 minecraft:gray_concrete
fill 276 141 230 276 142 230 minecraft:blue_terracotta
fill 276 141 232 276 142 232 minecraft:blue_terracotta
fill 276 141 234 276 142 234 minecraft:blue_terracotta
fill 276 141 236 276 142 236 minecraft:blue_terracotta
fill 276 141 243 276 142 243 minecraft:gray_concrete
fill 276 141 245 276 142 245 minecraft:gray_concrete
fill 276 141 247 276 142 247 minecraft:gray_concrete
fill 276 141 249 276 142 249 minecraft:gray_concrete
fill 276 141 251 276 142 251 minecraft:gray_concrete
fill 276 141 253 276 142 253 minecraft:gray_concrete
fill 276 141 262 276 142 262 minecraft:gray_concrete
fill 276 141 264 276 142 264 minecraft:gray_concrete
fill 276 141 266 276 142 266 minecraft:gray_concrete
fill 276 141 268 276 142 268 minecraft:gray_concrete
setblock 277 141 240 minecraft:blue_concrete
fill 236 142 263 243 148 263 minecraft:blue_terracotta
fill 237 142 262 242 148 262 minecraft:blue_terracotta
fill 238 142 251 239 148 251 minecraft:black_concrete
fill 239 142 250 240 149 250 minecraft:black_concrete
fill 239 142 254 239 148 254 minecraft:black_concrete
fill 240 142 251 241 143 251 minecraft:cyan_stained_glass
fill 240 142 252 240 144 252 minecraft:sea_lantern
fill 240 142 253 240 144 255 minecraft:cyan_stained_glass
fill 240 142 256 240 144 256 minecraft:sea_lantern
fill 240 142 257 241 143 257 minecraft:cyan_stained_glass
fill 241 142 249 241 144 250 minecraft:cyan_stained_glass
fill 241 142 254 241 144 255 minecraft:black_concrete
fill 241 142 258 241 144 259 minecraft:cyan_stained_glass
fill 242 142 247 243 143 247 minecraft:cyan_stained_glass
fill 242 142 248 242 145 248 minecraft:sea_lantern
fill 242 142 260 242 145 260 minecraft:sea_lantern
fill 242 142 261 243 143 261 minecraft:cyan_stained_glass
fill 243 142 246 244 143 246 minecraft:cyan_stained_glass
fill 243 142 262 244 143 262 minecraft:cyan_stained_glass
setblock 244 142 228 minecraft:purple_concrete
fill 244 142 245 244 143 245 minecraft:cyan_stained_glass
fill 244 142 263 244 143 263 minecraft:cyan_stained_glass
fill 245 142 245 245 145 245 minecraft:sea_lantern
fill 245 142 263 245 145 263 minecraft:sea_lantern
fill 246 142 244 248 144 244 minecraft:cyan_stained_glass
fill 246 142 264 248 144 264 minecraft:cyan_stained_glass
fill 248 142 243 248 143 243 minecraft:cyan_stained_glass
fill 248 142 265 248 143 265 minecraft:cyan_stained_glass
fill 249 142 243 249 144 243 minecraft:sea_lantern
fill 249 142 265 249 144 265 minecraft:sea_lantern
fill 250 142 243 252 144 243 minecraft:cyan_stained_glass
fill 250 142 265 252 144 265 minecraft:cyan_stained_glass
fill 251 142 264 251 144 264 minecraft:gray_concrete
fill 251 142 266 251 145 266 minecraft:gray_concrete
fill 251 142 270 251 149 270 minecraft:black_concrete
fill 253 142 243 253 144 243 minecraft:sea_lantern
fill 253 142 265 253 144 265 minecraft:sea_lantern
fill 254 142 243 254 143 244 minecraft:cyan_stained_glass
fill 254 142 264 254 143 265 minecraft:cyan_stained_glass
fill 255 142 244 256 144 244 minecraft:cyan_stained_glass
fill 255 142 264 256 144 264 minecraft:cyan_stained_glass
fill 255 142 265 257 282 265 minecraft:gray_concrete
fill 257 142 245 257 145 245 minecraft:sea_lantern
fill 257 142 263 257 145 263 minecraft:sea_lantern
fill 258 142 245 258 143 246 minecraft:cyan_stained_glass
fill 258 142 262 258 143 263 minecraft:cyan_stained_glass
fill 259 142 246 259 143 247 minecraft:cyan_stained_glass
fill 259 142 261 259 143 262 minecraft:cyan_stained_glass
fill 259 142 270 259 202 270 minecraft:black_concrete
fill 260 142 247 260 143 247 minecraft:cyan_stained_glass
fill 260 142 248 260 145 248 minecraft:sea_lantern
fill 260 142 260 260 145 260 minecraft:sea_lantern
fill 260 142 261 260 143 261 minecraft:cyan_stained_glass
fill 261 142 249 261 144 251 minecraft:cyan_stained_glass
fill 261 142 257 261 144 259 minecraft:cyan_stained_glass
fill 262 142 251 262 143 251 minecraft:cyan_stained_glass
fill 262 142 252 262 144 252 minecraft:sea_lantern
fill 262 142 253 262 144 255 minecraft:cyan_stained_glass
fill 262 142 256 262 144 256 minecraft:sea_lantern
fill 262 142 257 262 143 257 minecraft:cyan_stained_glass
fill 277 142 240 277 162 240 minecraft:black_concrete
setblock 235 143 238 minecraft:ochre_froglight
setblock 235 143 239 minecraft:purple_concrete
setblock 236 143 230 minecraft:black_stained_glass
setblock 236 143 232 minecraft:sea_lantern
setblock 236 143 234 minecraft:black_stained_glass
setblock 236 143 236 minecraft:black_stained_glass
setblock 236 143 243 minecraft:pearlescent_froglight
setblock 236 143 245 minecraft:magenta_stained_glass
setblock 236 143 247 minecraft:magenta_stained_glass
setblock 236 143 249 minecraft:black_stained_glass
setblock 236 143 251 minecraft:black_stained_glass
setblock 236 143 253 minecraft:black_stained_glass
setblock 236 143 262 minecraft:light_blue_stained_glass
setblock 236 143 264 minecraft:ochre_froglight
setblock 236 143 266 minecraft:ochre_froglight
setblock 236 143 268 minecraft:ochre_froglight
setblock 237 143 229 minecraft:black_stained_glass
setblock 237 143 237 minecraft:magenta_stained_glass
setblock 237 143 242 minecraft:pearlescent_froglight
setblock 237 143 255 minecraft:black_stained_glass
setblock 237 143 261 minecraft:ochre_froglight
setblock 237 143 269 minecraft:sea_lantern
setblock 238 143 239 minecraft:light[level=15]
setblock 239 143 229 minecraft:light_blue_stained_glass
setblock 239 143 237 minecraft:cyan_stained_glass
setblock 239 143 242 minecraft:black_stained_glass
setblock 239 143 255 minecraft:pearlescent_froglight
setblock 239 143 261 minecraft:black_stained_glass
setblock 239 143 269 minecraft:sea_lantern
setblock 241 143 229 minecraft:ochre_froglight
setblock 241 143 237 minecraft:magenta_stained_glass
setblock 241 143 243 minecraft:pearlescent_froglight
setblock 241 143 245 minecraft:sea_lantern
setblock 241 143 247 minecraft:pearlescent_froglight
setblock 241 143 253 minecraft:ochre_froglight
setblock 241 143 261 minecraft:cyan_stained_glass
setblock 241 143 269 minecraft:black_stained_glass
fill 242 143 249 242 146 249 minecraft:cyan_stained_glass
fill 242 143 259 242 146 259 minecraft:cyan_stained_glass
setblock 243 143 229 minecraft:light_blue_stained_glass
setblock 243 143 237 minecraft:magenta_stained_glass
setblock 243 143 269 minecraft:sea_lantern
fill 244 143 228 244 165 228 minecraft:black_concrete
setblock 244 143 230 minecraft:light_blue_stained_glass
setblock 244 143 232 minecraft:black_stained_glass
setblock 244 143 234 minecraft:ochre_froglight
setblock 244 143 236 minecraft:pearlescent_froglight
setblock 244 143 264 minecraft:cyan_stained_glass
setblock 244 143 266 minecraft:black_stained_glass
setblock 244 143 268 minecraft:black_stained_glass
setblock 246 143 231 minecraft:light[level=15]
setblock 246 143 239 minecraft:light[level=15]
fill 246 143 245 246 146 245 minecraft:cyan_stained_glass
setblock 246 143 247 minecraft:light[level=15]
setblock 246 143 255 minecraft:light[level=15]
fill 246 143 263 246 146 263 minecraft:cyan_stained_glass
setblock 249 143 230 minecraft:black_stained_glass
setblock 249 143 232 minecraft:light_blue_stained_glass
setblock 249 143 267 minecraft:cyan_stained_glass
setblock 250 143 228 minecraft:blue_concrete
setblock 250 143 229 minecraft:cyan_stained_glass
setblock 250 143 234 minecraft:ochre_froglight
setblock 250 143 264 minecraft:light_blue_stained_glass
setblock 250 143 269 minecraft:black_stained_glass
setblock 252 143 229 minecraft:black_stained_glass
setblock 252 143 234 minecraft:black_stained_glass
setblock 252 143 264 minecraft:magenta_stained_glass
setblock 252 143 269 minecraft:black_stained_glass
setblock 254 143 229 minecraft:ochre_froglight
setblock 254 143 234 minecraft:pearlescent_froglight
setblock 254 143 239 minecraft:light[level=15]
setblock 254 143 247 minecraft:light[level=15]
setblock 254 143 255 minecraft:light[level=15]
setblock 254 143 263 minecraft:light[level=15]
setblock 254 143 269 minecraft:black_stained_glass
setblock 256 143 229 minecraft:black_stained_glass
setblock 256 143 234 minecraft:ochre_froglight
fill 256 143 245 256 146 245 minecraft:cyan_stained_glass
fill 256 143 263 256 146 263 minecraft:cyan_stained_glass
setblock 256 143 269 minecraft:ochre_froglight
setblock 257 143 228 minecraft:cyan_concrete
setblock 258 143 229 minecraft:black_stained_glass
setblock 258 143 234 minecraft:light_blue_stained_glass
setblock 258 143 264 minecraft:black_stained_glass
setblock 258 143 269 minecraft:cyan_stained_glass
setblock 259 143 228 minecraft:blue_concrete
setblock 260 143 229 minecraft:cyan_stained_glass
setblock 260 143 234 minecraft:light_blue_stained_glass
fill 260 143 249 260 146 249 minecraft:cyan_stained_glass
fill 260 143 259 260 146 259 minecraft:cyan_stained_glass
setblock 260 143 264 minecraft:pearlescent_froglight
setblock 260 143 269 minecraft:black_stained_glass
setblock 262 143 230 minecraft:black_stained_glass
setblock 262 143 232 minecraft:light_blue_stained_glass
setblock 262 143 239 minecraft:light[level=15]
setblock 262 143 247 minecraft:light[level=15]
setblock 262 143 263 minecraft:light[level=15]
setblock 262 143 265 minecraft:light_blue_stained_glass
setblock 262 143 267 minecraft:sea_lantern
setblock 268 143 230 minecraft:ochre_froglight
setblock 268 143 232 minecraft:pearlescent_froglight
setblock 268 143 234 minecraft:black_stained_glass
setblock 268 143 236 minecraft:cyan_stained_glass
setblock 268 143 262 minecraft:ochre_froglight
setblock 268 143 264 minecraft:black_stained_glass
setblock 268 143 266 minecraft:black_stained_glass
setblock 268 143 268 minecraft:black_stained_glass
setblock 269 143 229 minecraft:sea_lantern
setblock 269 143 237 minecraft:black_stained_glass
setblock 269 143 261 minecraft:black_stained_glass
setblock 269 143 269 minecraft:black_stained_glass
setblock 270 143 239 minecraft:light[level=15]
setblock 270 143 247 minecraft:light[level=15]
setblock 270 143 255 minecraft:light[level=15]
setblock 271 143 229 minecraft:magenta_stained_glass
setblock 271 143 237 minecraft:black_stained_glass
setblock 271 143 243 minecraft:cyan_stained_glass
setblock 271 143 245 minecraft:magenta_stained_glass
setblock 271 143 247 minecraft:black_stained_glass
setblock 271 143 249 minecraft:cyan_stained_glass
setblock 271 143 251 minecraft:pearlescent_froglight
setblock 271 143 253 minecraft:ochre_froglight
setblock 271 143 261 minecraft:black_stained_glass
setblock 271 143 269 minecraft:ochre_froglight
setblock 272 143 242 minecraft:cyan_stained_glass
setblock 272 143 255 minecraft:sea_lantern
setblock 273 143 229 minecraft:light_blue_stained_glass
setblock 273 143 237 minecraft:black_stained_glass
setblock 273 143 261 minecraft:magenta_stained_glass
setblock 273 143 269 minecraft:black_stained_glass
setblock 274 143 242 minecraft:black_stained_glass
setblock 274 143 255 minecraft:ochre_froglight
setblock 275 143 229 minecraft:cyan_stained_glass
setblock 275 143 237 minecraft:black_stained_glass
setblock 275 143 261 minecraft:ochre_froglight
setblock 275 143 269 minecraft:light_blue_stained_glass
setblock 276 143 230 minecraft:black_stained_glass
setblock 276 143 232 minecraft:cyan_stained_glass
setblock 276 143 234 minecraft:black_stained_glass
setblock 276 143 236 minecraft:black_stained_glass
setblock 276 143 243 minecraft:black_stained_glass
setblock 276 143 245 minecraft:black_stained_glass
setblock 276 143 247 minecraft:ochre_froglight
setblock 276 143 249 minecraft:black_stained_glass
setblock 276 143 251 minecraft:black_stained_glass
setblock 276 143 253 minecraft:light_blue_stained_glass
setblock 276 143 262 minecraft:light_blue_stained_glass
setblock 276 143 264 minecraft:cyan_stained_glass
setblock 276 143 266 minecraft:black_stained_glass
setblock 276 143 268 minecraft:black_stained_glass
fill 235 144 238 235 183 239 minecraft:black_concrete
setblock 235 144 254 minecraft:verdant_froglight
fill 236 144 230 236 145 230 minecraft:gray_concrete
fill 236 144 232 236 145 232 minecraft:gray_concrete
fill 236 144 234 236 145 234 minecraft:gray_concrete
fill 236 144 236 236 145 236 minecraft:gray_concrete
fill 236 144 243 236 145 243 minecraft:black_concrete
fill 236 144 245 236 145 245 minecraft:black_concrete
fill 236 144 247 236 145 247 minecraft:black_concrete
fill 236 144 249 236 145 249 minecraft:black_concrete
fill 236 144 251 236 145 251 minecraft:black_concrete
fill 236 144 253 236 145 253 minecraft:black_concrete
fill 236 144 262 236 145 262 minecraft:blue_terracotta
fill 236 144 264 236 145 264 minecraft:blue_terracotta
fill 236 144 266 236 145 266 minecraft:blue_terracotta
fill 236 144 268 236 145 268 minecraft:blue_terracotta
fill 237 144 229 237 145 229 minecraft:gray_concrete
fill 237 144 237 237 145 237 minecraft:gray_concrete
fill 237 144 242 237 145 242 minecraft:black_concrete
fill 237 144 255 237 145 255 minecraft:black_concrete
fill 237 144 261 237 145 261 minecraft:blue_terracotta
fill 237 144 269 237 145 269 minecraft:blue_terracotta
fill 239 144 229 239 145 229 minecraft:gray_concrete
fill 239 144 237 239 145 237 minecraft:gray_concrete
fill 239 144 242 239 145 242 minecraft:black_concrete
fill 239 144 255 239 145 255 minecraft:black_concrete
fill 239 144 261 239 145 261 minecraft:blue_terracotta
fill 239 144 269 239 145 269 minecraft:blue_terracotta
fill 240 144 251 240 277 251 minecraft:black_concrete
fill 241 144 229 241 145 229 minecraft:gray_concrete
fill 241 144 237 241 145 237 minecraft:gray_concrete
fill 241 144 243 241 145 243 minecraft:black_concrete
fill 241 144 245 241 145 245 minecraft:black_concrete
fill 241 144 247 241 145 247 minecraft:black_concrete
fill 241 144 251 241 146 251 minecraft:cyan_stained_glass
fill 241 144 252 241 146 252 minecraft:sea_lantern
setblock 241 144 253 minecraft:black_concrete
fill 241 144 256 241 146 256 minecraft:sea_lantern
fill 241 144 257 241 146 257 minecraft:cyan_stained_glass
fill 241 144 261 242 145 261 minecraft:blue_terracotta
fill 241 144 269 241 145 269 minecraft:blue_terracotta
fill 243 144 229 243 145 229 minecraft:gray_concrete
fill 243 144 237 243 145 237 minecraft:gray_concrete
fill 243 144 247 243 145 247 minecraft:cyan_stained_glass
fill 243 144 261 243 145 261 minecraft:cyan_stained_glass
fill 243 144 262 243 159 262 minecraft:blue_terracotta
fill 243 144 269 243 145 269 minecraft:blue_terracotta
fill 244 144 230 244 145 230 minecraft:gray_concrete
fill 244 144 232 244 145 232 minecraft:gray_concrete
fill 244 144 234 244 145 234 minecraft:gray_concrete
fill 244 144 236 244 145 236 minecraft:gray_concrete
fill 244 144 245 244 144 247 minecraft:verdant_froglight
fill 244 144 249 244 144 251 minecraft:verdant_froglight
fill 244 144 262 244 146 262 minecraft:cyan_stained_glass
fill 244 144 263 244 145 264 minecraft:blue_terracotta
fill 244 144 266 244 145 266 minecraft:blue_terracotta
fill 244 144 268 244 145 268 minecraft:blue_terracotta
setblock 246 144 270 minecraft:sea_lantern
fill 248 144 261 248 147 261 minecraft:pearlescent_froglight
fill 249 144 230 249 145 230 minecraft:gray_concrete
fill 249 144 232 249 145 232 minecraft:gray_concrete
fill 249 144 244 249 146 244 minecraft:sea_lantern
fill 249 144 264 249 146 264 minecraft:sea_lantern
fill 249 144 267 249 145 267 minecraft:gray_concrete
fill 250 144 228 250 160 228 minecraft:black_concrete
fill 250 144 229 250 145 229 minecraft:gray_concrete
fill 250 144 234 250 145 234 minecraft:gray_concrete
fill 250 144 237 252 144 237 minecraft:pearlescent_froglight
fill 250 144 261 250 148 261 minecraft:pearlescent_froglight
setblock 250 144 264 minecraft:gray_concrete
fill 250 144 269 250 145 269 minecraft:gray_concrete
fill 252 144 229 252 145 229 minecraft:gray_concrete
fill 252 144 234 252 145 234 minecraft:gray_concrete
fill 252 144 261 254 144 261 minecraft:pearlescent_froglight
setblock 252 144 264 minecraft:gray_concrete
fill 252 144 269 252 145 269 minecraft:gray_concrete
fill 253 144 244 253 146 244 minecraft:sea_lantern
fill 253 144 264 253 146 264 minecraft:sea_lantern
fill 254 144 229 254 145 229 minecraft:gray_concrete
fill 254 144 234 254 145 234 minecraft:gray_concrete
fill 254 144 244 254 146 244 minecraft:cyan_stained_glass
fill 254 144 264 254 146 264 minecraft:cyan_stained_glass
fill 254 144 265 254 282 265 minecraft:gray_concrete
fill 254 144 269 254 145 269 minecraft:gray_concrete
fill 256 144 229 256 145 229 minecraft:gray_concrete
fill 256 144 234 256 145 234 minecraft:gray_concrete
fill 256 144 237 256 148 237 minecraft:pearlescent_froglight
fill 256 144 269 256 145 269 minecraft:gray_concrete
fill 257 144 228 257 184 228 minecraft:black_concrete
fill 258 144 229 258 145 229 minecraft:gray_concrete
fill 258 144 234 258 145 234 minecraft:gray_concrete
fill 258 144 246 258 145 246 minecraft:cyan_stained_glass
fill 258 144 261 258 148 261 minecraft:pearlescent_froglight
fill 258 144 262 258 145 262 minecraft:cyan_stained_glass
fill 258 144 264 258 145 264 minecraft:gray_concrete
fill 258 144 269 258 145 269 minecraft:gray_concrete
fill 259 144 228 259 167 228 minecraft:black_concrete
fill 259 144 247 259 145 247 minecraft:cyan_stained_glass
fill 259 144 261 259 145 261 minecraft:cyan_stained_glass
fill 260 144 229 260 145 229 minecraft:gray_concrete
fill 260 144 234 260 145 234 minecraft:gray_concrete
fill 260 144 264 260 145 264 minecraft:gray_concrete
fill 260 144 269 260 145 269 minecraft:gray_concrete
fill 261 144 252 261 146 252 minecraft:sea_lantern
fill 261 144 256 261 146 256 minecraft:sea_lantern
setblock 261 144 261 minecraft:pearlescent_froglight
fill 262 144 230 262 145 230 minecraft:gray_concrete
fill 262 144 232 262 145 232 minecraft:gray_concrete
fill 262 144 265 262 145 265 minecraft:gray_concrete
fill 262 144 267 262 145 267 minecraft:gray_concrete
fill 263 144 237 263 146 237 minecraft:pearlescent_froglight
fill 268 144 230 268 145 230 minecraft:blue_terracotta
fill 268 144 232 268 145 232 minecraft:blue_terracotta
fill 268 144 234 268 145 234 minecraft:blue_terracotta
fill 268 144 236 268 145 236 minecraft:blue_terracotta
fill 268 144 245 268 148 245 minecraft:verdant_froglight
fill 268 144 247 268 147 247 minecraft:verdant_froglight
fill 268 144 249 268 144 251 minecraft:verdant_froglight
setblock 268 144 254 minecraft:verdant_froglight
fill 268 144 262 268 145 262 minecraft:gray_concrete
fill 268 144 264 268 145 264 minecraft:gray_concrete
fill 268 144 266 268 145 266 minecraft:gray_concrete
fill 268 144 268 268 145 268 minecraft:gray_concrete
fill 269 144 229 269 145 229 minecraft:blue_terracotta
fill 269 144 237 269 145 237 minecraft:blue_terracotta
fill 269 144 261 269 145 261 minecraft:gray_concrete
fill 269 144 269 269 145 269 minecraft:gray_concrete
fill 271 144 229 271 145 229 minecraft:blue_terracotta
fill 271 144 237 271 145 237 minecraft:blue_terracotta
fill 271 144 243 271 145 243 minecraft:gray_concrete
fill 271 144 245 271 145 245 minecraft:gray_concrete
fill 271 144 247 271 145 247 minecraft:gray_concrete
fill 271 144 249 271 145 249 minecraft:gray_concrete
fill 271 144 251 271 145 251 minecraft:gray_concrete
fill 271 144 253 271 145 253 minecraft:gray_concrete
fill 271 144 261 271 145 261 minecraft:gray_concrete
fill 271 144 269 271 145 269 minecraft:gray_concrete
fill 272 144 242 272 145 242 minecraft:gray_concrete
fill 272 144 255 272 145 255 minecraft:gray_concrete
fill 273 144 229 273 145 229 minecraft:blue_terracotta
fill 273 144 237 273 145 237 minecraft:blue_terracotta
fill 273 144 261 273 145 261 minecraft:gray_concrete
fill 273 144 269 273 145 269 minecraft:gray_concrete
fill 274 144 242 274 145 242 minecraft:gray_concrete
fill 274 144 255 274 145 255 minecraft:gray_concrete
fill 275 144 229 275 145 229 minecraft:blue_terracotta
fill 275 144 237 275 145 237 minecraft:blue_terracotta
fill 275 144 261 275 145 261 minecraft:gray_concrete
fill 275 144 269 275 145 269 minecraft:gray_concrete
fill 276 144 230 276 145 230 minecraft:blue_terracotta
fill 276 144 232 276 145 232 minecraft:blue_terracotta
fill 276 144 234 276 145 234 minecraft:blue_terracotta
fill 276 144 236 276 145 236 minecraft:blue_terracotta
fill 276 144 243 276 145 243 minecraft:gray_concrete
fill 276 144 245 276 145 245 minecraft:gray_concrete
fill 276 144 247 276 145 247 minecraft:gray_concrete
fill 276 144 249 276 145 249 minecraft:gray_concrete
fill 276 144 251 276 145 251 minecraft:gray_concrete
fill 276 144 253 276 145 253 minecraft:gray_concrete
fill 276 144 262 276 145 262 minecraft:gray_concrete
fill 276 144 264 276 145 264 minecraft:gray_concrete
fill 276 144 266 276 145 266 minecraft:gray_concrete
fill 276 144 268 276 145 268 minecraft:gray_concrete
fill 235 145 254 235 216 254 minecraft:black_concrete
setblock 235 145 267 minecraft:verdant_froglight
setblock 238 145 238 minecraft:light[level=12]
setblock 238 145 259 minecraft:light[level=12]
fill 240 145 252 240 149 255 minecraft:black_concrete
setblock 241 145 249 minecraft:black_concrete
fill 241 145 250 242 145 250 minecraft:cyan_stained_glass
fill 241 145 253 241 147 255 minecraft:cyan_stained_glass
fill 241 145 258 242 145 258 minecraft:cyan_stained_glass
fill 243 145 248 243 147 248 minecraft:cyan_stained_glass
fill 243 145 260 243 147 260 minecraft:cyan_stained_glass
fill 244 145 245 244 148 245 minecraft:verdant_froglight
fill 244 145 246 245 145 246 minecraft:cyan_stained_glass
fill 244 145 247 244 148 247 minecraft:verdant_froglight
fill 244 145 251 244 148 251 minecraft:verdant_froglight
fill 244 145 261 244 147 261 minecraft:cyan_stained_glass
setblock 245 145 231 minecraft:light[level=12]
setblock 245 145 238 minecraft:light[level=12]
setblock 245 145 252 minecraft:light[level=12]
setblock 245 145 259 minecraft:light[level=12]
fill 245 145 262 245 147 262 minecraft:cyan_stained_glass
setblock 245 145 266 minecraft:light[level=12]
fill 246 145 270 246 162 270 minecraft:black_concrete
fill 247 145 244 247 145 245 minecraft:cyan_stained_glass
fill 247 145 263 247 145 264 minecraft:cyan_stained_glass
fill 248 145 244 248 146 244 minecraft:cyan_stained_glass
fill 248 145 264 248 146 264 minecraft:cyan_stained_glass
fill 249 145 265 253 145 265 minecraft:gray_concrete
setblock 250 145 237 minecraft:pearlescent_froglight
fill 250 145 244 252 147 244 minecraft:cyan_stained_glass
fill 250 145 264 252 147 264 minecraft:cyan_stained_glass
setblock 252 145 238 minecraft:light[level=12]
setblock 252 145 245 minecraft:light[level=12]
setblock 252 145 252 minecraft:light[level=12]
setblock 252 145 259 minecraft:light[level=12]
fill 254 145 261 254 148 261 minecraft:pearlescent_froglight
setblock 255 145 228 minecraft:verdant_froglight
fill 255 145 244 255 145 245 minecraft:cyan_stained_glass
fill 255 145 263 255 145 264 minecraft:cyan_stained_glass
setblock 256 145 264 minecraft:gray_concrete
fill 257 145 246 257 147 246 minecraft:cyan_stained_glass
fill 257 145 262 257 147 262 minecraft:cyan_stained_glass
fill 258 145 247 258 147 247 minecraft:cyan_stained_glass
setblock 259 145 238 minecraft:light[level=12]
setblock 259 145 245 minecraft:light[level=12]
fill 259 145 248 259 147 248 minecraft:cyan_stained_glass
setblock 259 145 252 minecraft:light[level=12]
setblock 259 145 259 minecraft:light[level=12]
fill 259 145 260 259 147 260 minecraft:cyan_stained_glass
fill 260 145 250 261 145 250 minecraft:cyan_stained_glass
fill 260 145 258 261 145 258 minecraft:cyan_stained_glass
fill 260 145 261 260 147 261 minecraft:pearlescent_froglight
fill 261 145 251 261 146 251 minecraft:cyan_stained_glass
fill 261 145 253 261 147 255 minecraft:cyan_stained_glass
fill 261 145 257 261 146 257 minecraft:cyan_stained_glass
fill 262 145 261 262 147 261 minecraft:pearlescent_froglight
setblock 266 145 231 minecraft:light[level=12]
setblock 266 145 238 minecraft:light[level=12]
setblock 266 145 245 minecraft:light[level=12]
setblock 266 145 252 minecraft:light[level=12]
setblock 266 145 259 minecraft:light[level=12]
setblock 266 145 266 minecraft:light[level=12]
fill 268 145 249 268 148 249 minecraft:verdant_froglight
fill 268 145 253 268 147 253 minecraft:verdant_froglight
fill 268 145 255 268 147 255 minecraft:verdant_froglight
setblock 273 145 238 minecraft:light[level=12]
setblock 273 145 259 minecraft:light[level=12]
setblock 274 145 270 minecraft:sea_lantern
setblock 277 145 260 minecraft:magenta_concrete
fill 277 145 262 277 146 262 minecraft:verdant_froglight
setblock 235 146 230 minecraft:blue_concrete
fill 235 146 251 235 241 251 minecraft:black_concrete
setblock 235 146 252 minecraft:purple_concrete
fill 235 146 267 235 245 267 minecraft:black_concrete
setblock 236 146 230 minecraft:magenta_stained_glass
setblock 236 146 232 minecraft:black_stained_glass
setblock 236 146 234 minecraft:black_stained_glass
setblock 236 146 236 minecraft:black_stained_glass
setblock 236 146 243 minecraft:black_stained_glass
setblock 236 146 245 minecraft:black_stained_glass
setblock 236 146 247 minecraft:black_stained_glass
setblock 236 146 249 minecraft:sea_lantern
setblock 236 146 251 minecraft:black_stained_glass
setblock 236 146 253 minecraft:pearlescent_froglight
setblock 236 146 262 minecraft:light_blue_stained_glass
setblock 236 146 264 minecraft:magenta_stained_glass
fill 236 146 265 239 146 265 minecraft:blue_terracotta
setblock 236 146 266 minecraft:black_stained_glass
setblock 236 146 268 minecraft:magenta_stained_glass
setblock 237 146 229 minecraft:magenta_stained_glass
setblock 237 146 237 minecraft:black_stained_glass
setblock 237 146 242 minecraft:magenta_stained_glass
setblock 237 146 255 minecraft:ochre_froglight
setblock 237 146 261 minecraft:sea_lantern
setblock 237 146 269 minecraft:light_blue_stained_glass
setblock 239 146 229 minecraft:pearlescent_froglight
setblock 239 146 237 minecraft:light_blue_stained_glass
setblock 239 146 242 minecraft:black_stained_glass
setblock 239 146 255 minecraft:ochre_froglight
setblock 239 146 261 minecraft:black_stained_glass
setblock 239 146 269 minecraft:pearlescent_froglight
fill 240 146 265 243 147 265 minecraft:sea_lantern
setblock 241 146 229 minecraft:cyan_stained_glass
setblock 241 146 237 minecraft:black_stained_glass
setblock 241 146 243 minecraft:cyan_stained_glass
setblock 241 146 245 minecraft:pearlescent_froglight
setblock 241 146 247 minecraft:black_stained_glass
setblock 241 146 249 minecraft:black_stained_glass
fill 241 146 250 241 277 250 minecraft:black_concrete
setblock 241 146 261 minecraft:black_stained_glass
setblock 241 146 269 minecraft:cyan_stained_glass
fill 242 146 250 242 147 251 minecraft:cyan_stained_glass
fill 242 146 257 242 147 258 minecraft:cyan_stained_glass
fill 242 146 261 242 159 261 minecraft:blue_terracotta
setblock 243 146 229 minecraft:black_stained_glass
setblock 243 146 237 minecraft:black_stained_glass
fill 243 146 249 243 148 249 minecraft:sea_lantern
fill 243 146 259 243 148 259 minecraft:sea_lantern
setblock 243 146 261 minecraft:black_stained_glass
setblock 243 146 269 minecraft:magenta_stained_glass
setblock 244 146 230 minecraft:cyan_stained_glass
setblock 244 146 232 minecraft:ochre_froglight
setblock 244 146 234 minecraft:black_stained_glass
setblock 244 146 236 minecraft:black_stained_glass
fill 244 146 263 244 159 263 minecraft:blue_terracotta
setblock 244 146 264 minecraft:cyan_stained_glass
setblock 244 146 265 minecraft:blue_terracotta
setblock 244 146 266 minecraft:pearlescent_froglight
setblock 244 146 268 minecraft:black_stained_glass
fill 245 146 246 245 147 246 minecraft:cyan_stained_glass
fill 246 146 246 246 148 246 minecraft:sea_lantern
fill 246 146 262 246 148 262 minecraft:sea_lantern
fill 247 146 245 248 147 245 minecraft:cyan_stained_glass
fill 247 146 263 248 147 263 minecraft:cyan_stained_glass
fill 247 146 266 253 147 266 minecraft:sea_lantern
setblock 249 146 230 minecraft:sea_lantern
setblock 249 146 232 minecraft:black_stained_glass
setblock 249 146 265 minecraft:ochre_froglight
setblock 249 146 267 minecraft:sea_lantern
setblock 250 146 229 minecraft:sea_lantern
setblock 250 146 234 minecraft:sea_lantern
fill 250 146 265 253 146 265 minecraft:gray_concrete
setblock 250 146 269 minecraft:light_blue_stained_glass
setblock 251 146 237 minecraft:pearlescent_froglight
setblock 252 146 229 minecraft:black_stained_glass
setblock 252 146 234 minecraft:pearlescent_froglight
setblock 252 146 269 minecraft:sea_lantern
setblock 253 146 228 minecraft:ochre_froglight
setblock 253 146 261 minecraft:pearlescent_froglight
fill 254 146 228 255 147 228 minecraft:black_concrete
setblock 254 146 229 minecraft:black_stained_glass
setblock 254 146 234 minecraft:black_stained_glass
fill 254 146 237 255 146 237 minecraft:pearlescent_froglight
fill 254 146 245 255 147 245 minecraft:cyan_stained_glass
fill 254 146 263 255 147 263 minecraft:cyan_stained_glass
fill 254 146 266 256 146 266 minecraft:gray_concrete
setblock 254 146 269 minecraft:black_stained_glass
fill 255 146 264 255 223 264 minecraft:gray_concrete
setblock 256 146 229 minecraft:cyan_stained_glass
setblock 256 146 234 minecraft:ochre_froglight
fill 256 146 246 256 148 246 minecraft:sea_lantern
fill 256 146 262 256 148 262 minecraft:sea_lantern
setblock 256 146 264 minecraft:cyan_stained_glass
setblock 256 146 269 minecraft:black_stained_glass
setblock 257 146 261 minecraft:pearlescent_froglight
setblock 258 146 229 minecraft:black_stained_glass
setblock 258 146 234 minecraft:black_stained_glass
fill 258 146 237 260 146 237 minecraft:pearlescent_froglight
setblock 258 146 264 minecraft:pearlescent_froglight
setblock 258 146 269 minecraft:ochre_froglight
fill 259 146 249 259 148 249 minecraft:sea_lantern
fill 259 146 259 259 148 259 minecraft:sea_lantern
setblock 260 146 229 minecraft:ochre_froglight
setblock 260 146 234 minecraft:magenta_stained_glass
fill 260 146 250 260 147 251 minecraft:cyan_stained_glass
fill 260 146 257 260 147 258 minecraft:cyan_stained_glass
setblock 260 146 264 minecraft:magenta_stained_glass
setblock 260 146 269 minecraft:black_stained_glass
setblock 262 146 230 minecraft:magenta_stained_glass
setblock 262 146 232 minecraft:black_stained_glass
setblock 262 146 265 minecraft:ochre_froglight
setblock 262 146 267 minecraft:black_stained_glass
setblock 268 146 230 minecraft:cyan_stained_glass
setblock 268 146 232 minecraft:cyan_stained_glass
setblock 268 146 234 minecraft:magenta_stained_glass
setblock 268 146 236 minecraft:black_stained_glass
setblock 268 146 250 minecraft:verdant_froglight
setblock 268 146 262 minecraft:light_blue_stained_glass
setblock 268 146 264 minecraft:black_stained_glass
setblock 268 146 266 minecraft:magenta_stained_glass
setblock 268 146 268 minecraft:pearlescent_froglight
setblock 269 146 229 minecraft:cyan_stained_glass
setblock 269 146 237 minecraft:ochre_froglight
setblock 269 146 261 minecraft:black_stained_glass
setblock 269 146 269 minecraft:pearlescent_froglight
setblock 271 146 229 minecraft:magenta_stained_glass
setblock 271 146 237 minecraft:light_blue_stained_glass
setblock 271 146 243 minecraft:black_stained_glass
setblock 271 146 245 minecraft:magenta_stained_glass
setblock 271 146 247 minecraft:pearlescent_froglight
setblock 271 146 249 minecraft:black_stained_glass
setblock 271 146 251 minecraft:ochre_froglight
setblock 271 146 253 minecraft:cyan_stained_glass
setblock 271 146 261 minecraft:pearlescent_froglight
setblock 271 146 269 minecraft:magenta_stained_glass
setblock 272 146 242 minecraft:black_stained_glass
setblock 272 146 255 minecraft:pearlescent_froglight
setblock 273 146 229 minecraft:black_stained_glass
setblock 273 146 237 minecraft:black_stained_glass
setblock 273 146 261 minecraft:pearlescent_froglight
setblock 273 146 269 minecraft:cyan_stained_glass
setblock 274 146 242 minecraft:magenta_stained_glass
setblock 274 146 255 minecraft:black_stained_glass
fill 274 146 270 274 225 270 minecraft:black_concrete
setblock 275 146 229 minecraft:cyan_stained_glass
setblock 275 146 237 minecraft:black_stained_glass
setblock 275 146 261 minecraft:cyan_stained_glass
setblock 275 146 269 minecraft:magenta_stained_glass
setblock 276 146 230 minecraft:sea_lantern
setblock 276 146 232 minecraft:black_stained_glass
setblock 276 146 234 minecraft:black_stained_glass
setblock 276 146 236 minecraft:black_stained_glass
setblock 276 146 243 minecraft:light_blue_stained_glass
setblock 276 146 245 minecraft:black_stained_glass
setblock 276 146 247 minecraft:black_stained_glass
setblock 276 146 249 minecraft:light_blue_stained_glass
setblock 276 146 251 minecraft:sea_lantern
setblock 276 146 253 minecraft:black_stained_glass
setblock 276 146 262 minecraft:pearlescent_froglight
setblock 276 146 264 minecraft:sea_lantern
setblock 276 146 266 minecraft:sea_lantern
setblock 276 146 268 minecraft:sea_lantern
fill 277 146 260 277 217 260 minecraft:black_concrete
fill 235 147 230 235 162 230 minecraft:black_concrete
fill 235 147 252 235 291 252 minecraft:black_concrete
fill 236 147 230 236 148 230 minecraft:gray_concrete
fill 236 147 232 236 148 232 minecraft:gray_concrete
fill 236 147 234 236 148 234 minecraft:gray_concrete
fill 236 147 236 236 148 236 minecraft:gray_concrete
fill 236 147 243 236 148 243 minecraft:black_concrete
fill 236 147 245 236 148 245 minecraft:black_concrete
fill 236 147 247 236 148 247 minecraft:black_concrete
fill 236 147 249 236 148 249 minecraft:black_concrete
fill 236 147 251 236 148 251 minecraft:black_concrete
fill 236 147 253 236 148 253 minecraft:black_concrete
fill 236 147 262 236 148 262 minecraft:blue_terracotta
fill 236 147 264 238 148 266 minecraft:blue_terracotta
fill 236 147 268 236 148 268 minecraft:blue_terracotta
fill 237 147 229 237 148 229 minecraft:gray_concrete
fill 237 147 237 237 148 237 minecraft:gray_concrete
fill 237 147 242 237 148 242 minecraft:black_concrete
fill 237 147 255 237 148 255 minecraft:black_concrete
fill 237 147 261 237 148 261 minecraft:blue_terracotta
fill 237 147 269 237 148 269 minecraft:blue_terracotta
fill 239 147 229 239 148 229 minecraft:gray_concrete
fill 239 147 237 239 148 237 minecraft:gray_concrete
fill 239 147 242 239 148 242 minecraft:black_concrete
fill 239 147 255 239 148 255 minecraft:black_concrete
fill 239 147 261 239 148 261 minecraft:blue_terracotta
fill 239 147 264 239 149 264 minecraft:blue_terracotta
fill 239 147 265 239 148 265 minecraft:light_blue_stained_glass
fill 239 147 266 239 159 266 minecraft:blue_terracotta
fill 239 147 269 239 148 269 minecraft:blue_terracotta
fill 240 147 264 242 148 264 minecraft:light_blue_stained_glass
fill 240 147 266 246 148 266 minecraft:light_blue_stained_glass
fill 241 147 229 241 148 229 minecraft:gray_concrete
fill 241 147 237 241 148 237 minecraft:gray_concrete
fill 241 147 243 241 148 243 minecraft:black_concrete
fill 241 147 245 241 148 245 minecraft:black_concrete
fill 241 147 247 241 148 247 minecraft:black_concrete
fill 241 147 249 241 148 249 minecraft:black_concrete
fill 241 147 251 241 148 252 minecraft:black_concrete
fill 241 147 261 241 148 261 minecraft:blue_terracotta
fill 241 147 269 241 148 269 minecraft:blue_terracotta
fill 242 147 252 242 148 252 minecraft:sea_lantern
fill 242 147 253 242 148 255 minecraft:cyan_stained_glass
fill 242 147 256 242 148 256 minecraft:sea_lantern
fill 243 147 229 243 148 229 minecraft:gray_concrete
fill 243 147 237 243 148 237 minecraft:gray_concrete
fill 243 147 250 243 148 250 minecraft:cyan_stained_glass
fill 243 147 258 243 148 258 minecraft:cyan_stained_glass
fill 243 147 261 243 148 261 minecraft:blue_terracotta
fill 243 147 264 244 148 264 minecraft:blue_terracotta
fill 243 147 269 243 148 269 minecraft:blue_terracotta
fill 244 147 230 244 148 230 minecraft:gray_concrete
fill 244 147 232 244 148 232 minecraft:gray_concrete
fill 244 147 234 244 148 234 minecraft:gray_concrete
fill 244 147 236 244 148 236 minecraft:gray_concrete
fill 244 147 248 244 148 248 minecraft:cyan_stained_glass
fill 244 147 260 244 148 260 minecraft:cyan_stained_glass
fill 244 147 262 244 148 262 minecraft:blue_terracotta
fill 244 147 265 252 148 265 minecraft:light_blue_stained_glass
fill 244 147 268 244 148 268 minecraft:blue_terracotta
fill 245 147 247 245 148 247 minecraft:cyan_stained_glass
fill 245 147 261 245 148 261 minecraft:cyan_stained_glass
fill 247 147 246 247 148 246 minecraft:cyan_stained_glass
fill 247 147 262 247 148 262 minecraft:cyan_stained_glass
setblock 248 147 228 minecraft:verdant_froglight
fill 249 147 230 249 148 230 minecraft:gray_concrete
fill 249 147 232 249 148 232 minecraft:gray_concrete
fill 249 147 245 249 148 245 minecraft:sea_lantern
fill 249 147 263 249 148 263 minecraft:sea_lantern
fill 249 147 264 249 228 264 minecraft:gray_concrete
fill 249 147 267 256 148 267 minecraft:light_blue_stained_glass
fill 250 147 229 250 148 229 minecraft:gray_concrete
fill 250 147 234 250 148 234 minecraft:gray_concrete
fill 250 147 245 252 148 245 minecraft:cyan_stained_glass
fill 250 147 263 252 148 263 minecraft:cyan_stained_glass
fill 250 147 269 250 148 269 minecraft:gray_concrete
fill 252 147 229 252 148 229 minecraft:gray_concrete
fill 252 147 234 252 148 234 minecraft:gray_concrete
setblock 252 147 237 minecraft:pearlescent_froglight
fill 252 147 269 252 148 269 minecraft:gray_concrete
fill 253 147 228 253 157 228 minecraft:black_concrete
fill 253 147 245 253 148 245 minecraft:sea_lantern
fill 253 147 263 253 148 263 minecraft:sea_lantern
fill 253 147 264 253 228 265 minecraft:gray_concrete
fill 254 147 229 254 148 229 minecraft:gray_concrete
fill 254 147 234 254 148 234 minecraft:gray_concrete
fill 254 147 237 254 148 237 minecraft:pearlescent_froglight
fill 254 147 264 254 148 264 minecraft:gray_concrete
fill 254 147 266 256 148 266 minecraft:light_blue_stained_glass
fill 254 147 269 254 148 269 minecraft:gray_concrete
fill 255 147 246 255 148 246 minecraft:cyan_stained_glass
fill 255 147 262 255 148 262 minecraft:cyan_stained_glass
fill 256 147 229 256 148 229 minecraft:gray_concrete
fill 256 147 234 256 148 234 minecraft:gray_concrete
setblock 256 147 261 minecraft:pearlescent_froglight
fill 256 147 264 256 148 264 minecraft:gray_concrete
fill 256 147 269 256 148 269 minecraft:gray_concrete
fill 257 147 247 257 148 247 minecraft:cyan_stained_glass
setblock 257 147 261 minecraft:cyan_stained_glass
fill 258 147 229 258 148 229 minecraft:gray_concrete
fill 258 147 234 258 148 234 minecraft:gray_concrete
fill 258 147 248 258 148 248 minecraft:cyan_stained_glass
fill 258 147 260 258 148 260 minecraft:cyan_stained_glass
fill 258 147 264 258 148 264 minecraft:gray_concrete
fill 258 147 269 258 148 269 minecraft:gray_concrete
fill 259 147 250 259 148 250 minecraft:cyan_stained_glass
fill 259 147 258 259 148 258 minecraft:cyan_stained_glass
fill 260 147 229 260 148 229 minecraft:gray_concrete
fill 260 147 234 260 148 234 minecraft:gray_concrete
fill 260 147 252 260 148 252 minecraft:sea_lantern
fill 260 147 253 260 148 255 minecraft:cyan_stained_glass
fill 260 147 256 260 148 256 minecraft:sea_lantern
fill 260 147 264 260 148 264 minecraft:gray_concrete
fill 260 147 269 260 148 269 minecraft:gray_concrete
fill 262 147 230 262 148 230 minecraft:gray_concrete
fill 262 147 232 262 148 232 minecraft:gray_concrete
fill 262 147 265 262 148 265 minecraft:gray_concrete
fill 262 147 267 262 148 267 minecraft:gray_concrete
fill 264 147 237 264 148 237 minecraft:pearlescent_froglight
fill 268 147 230 268 148 230 minecraft:blue_terracotta
fill 268 147 232 268 148 232 minecraft:blue_terracotta
fill 268 147 234 268 148 234 minecraft:blue_terracotta
fill 268 147 236 268 148 236 minecraft:blue_terracotta
fill 268 147 262 268 148 262 minecraft:gray_concrete
fill 268 147 264 268 148 264 minecraft:gray_concrete
fill 268 147 266 268 148 266 minecraft:gray_concrete
fill 268 147 268 268 148 268 minecraft:gray_concrete
fill 269 147 229 269 148 229 minecraft:blue_terracotta
fill 269 147 237 269 148 237 minecraft:blue_terracotta
fill 269 147 261 269 148 261 minecraft:gray_concrete
fill 269 147 269 269 148 269 minecraft:gray_concrete
fill 271 147 229 271 148 229 minecraft:blue_terracotta
fill 271 147 237 271 148 237 minecraft:blue_terracotta
fill 271 147 243 271 148 243 minecraft:gray_concrete
fill 271 147 245 271 148 245 minecraft:gray_concrete
fill 271 147 247 271 148 247 minecraft:gray_concrete
fill 271 147 249 271 148 249 minecraft:gray_concrete
fill 271 147 251 271 148 251 minecraft:gray_concrete
fill 271 147 253 271 148 253 minecraft:gray_concrete
fill 271 147 261 271 148 261 minecraft:gray_concrete
fill 271 147 269 271 148 269 minecraft:gray_concrete
fill 272 147 242 272 148 242 minecraft:gray_concrete
fill 272 147 255 272 148 255 minecraft:gray_concrete
fill 273 147 229 273 148 229 minecraft:blue_terracotta
fill 273 147 237 273 148 237 minecraft:blue_terracotta
fill 273 147 261 273 148 261 minecraft:gray_concrete
fill 273 147 269 273 148 269 minecraft:gray_concrete
fill 274 147 242 274 148 242 minecraft:gray_concrete
fill 274 147 255 274 148 255 minecraft:gray_concrete
fill 275 147 229 275 148 229 minecraft:blue_terracotta
fill 275 147 237 275 148 237 minecraft:blue_terracotta
fill 275 147 261 275 148 261 minecraft:gray_concrete
fill 275 147 269 275 148 269 minecraft:gray_concrete
fill 276 147 230 276 148 230 minecraft:blue_terracotta
fill 276 147 232 276 148 232 minecraft:blue_terracotta
fill 276 147 234 276 148 234 minecraft:blue_terracotta
fill 276 147 236 276 148 236 minecraft:blue_terracotta
fill 276 147 243 276 148 243 minecraft:gray_concrete
fill 276 147 245 276 148 245 minecraft:gray_concrete
fill 276 147 247 276 148 247 minecraft:gray_concrete
fill 276 147 249 276 148 249 minecraft:gray_concrete
fill 276 147 251 276 148 251 minecraft:gray_concrete
fill 276 147 253 276 148 253 minecraft:gray_concrete
fill 276 147 262 276 148 262 minecraft:gray_concrete
fill 276 147 264 276 148 264 minecraft:gray_concrete
fill 276 147 266 276 148 266 minecraft:gray_concrete
fill 276 147 268 276 148 268 minecraft:gray_concrete
fill 277 147 262 277 162 262 minecraft:black_concrete
fill 240 148 265 243 148 265 minecraft:light_blue_stained_glass
fill 241 148 253 241 148 255 minecraft:black_concrete
fill 242 148 251 243 148 251 minecraft:cyan_stained_glass
fill 242 148 257 243 148 257 minecraft:cyan_stained_glass
fill 243 148 252 243 150 252 minecraft:cyan_stained_glass
fill 243 148 256 243 150 256 minecraft:cyan_stained_glass
fill 244 148 249 244 149 249 minecraft:sea_lantern
fill 244 148 259 244 149 259 minecraft:sea_lantern
fill 244 148 261 244 159 261 minecraft:blue_terracotta
fill 245 148 248 245 150 248 minecraft:cyan_stained_glass
fill 245 148 260 245 150 260 minecraft:cyan_stained_glass
fill 246 148 247 246 149 247 minecraft:sea_lantern
fill 246 148 261 246 149 261 minecraft:sea_lantern
fill 247 148 266 253 148 266 minecraft:light_blue_stained_glass
fill 248 148 228 248 161 228 minecraft:black_concrete
fill 248 148 245 248 148 246 minecraft:cyan_stained_glass
fill 248 148 262 248 148 263 minecraft:cyan_stained_glass
fill 249 148 246 249 150 246 minecraft:cyan_stained_glass
setblock 249 148 261 minecraft:pearlescent_froglight
fill 249 148 262 249 150 262 minecraft:cyan_stained_glass
fill 250 148 237 251 148 237 minecraft:pearlescent_froglight
fill 250 148 264 252 148 264 minecraft:gray_concrete
fill 252 148 261 253 148 261 minecraft:pearlescent_froglight
fill 253 148 246 254 150 246 minecraft:cyan_stained_glass
fill 253 148 262 254 150 262 minecraft:cyan_stained_glass
fill 254 148 228 254 153 228 minecraft:black_concrete
setblock 254 148 245 minecraft:cyan_stained_glass
setblock 254 148 263 minecraft:cyan_stained_glass
setblock 255 148 228 minecraft:sea_lantern
fill 256 148 247 256 149 247 minecraft:sea_lantern
fill 256 148 261 256 149 261 minecraft:sea_lantern
fill 257 148 248 257 150 248 minecraft:cyan_stained_glass
fill 257 148 260 257 150 260 minecraft:cyan_stained_glass
setblock 257 148 261 minecraft:pearlescent_froglight
fill 258 148 249 258 149 249 minecraft:sea_lantern
fill 258 148 259 258 149 259 minecraft:sea_lantern
fill 259 148 251 259 150 252 minecraft:cyan_stained_glass
fill 259 148 256 259 150 257 minecraft:cyan_stained_glass
setblock 260 148 251 minecraft:cyan_stained_glass
setblock 260 148 257 minecraft:cyan_stained_glass
setblock 261 148 261 minecraft:pearlescent_froglight
fill 262 148 237 263 148 237 minecraft:pearlescent_froglight
setblock 268 148 246 minecraft:verdant_froglight
fill 268 148 250 268 148 251 minecraft:verdant_froglight
setblock 268 148 254 minecraft:verdant_froglight
setblock 235 149 229 minecraft:magenta_concrete
setblock 235 149 259 minecraft:cyan_concrete
setblock 236 149 230 minecraft:magenta_stained_glass
setblock 236 149 232 minecraft:light_blue_stained_glass
setblock 236 149 234 minecraft:magenta_stained_glass
setblock 236 149 236 minecraft:black_stained_glass
fill 236 149 238 276 149 241 minecraft:gray_concrete
setblock 236 149 243 minecraft:ochre_froglight
setblock 236 149 245 minecraft:sea_lantern
setblock 236 149 247 minecraft:black_stained_glass
setblock 236 149 249 minecraft:black_stained_glass
setblock 236 149 251 minecraft:black_stained_glass
setblock 236 149 253 minecraft:pearlescent_froglight
fill 236 149 256 238 149 260 minecraft:gray_concrete
setblock 236 149 262 minecraft:ochre_froglight
fill 236 149 263 239 149 263 minecraft:blue_terracotta
setblock 236 149 264 minecraft:pearlescent_froglight
fill 236 149 265 239 149 265 minecraft:blue_terracotta
setblock 236 149 266 minecraft:cyan_stained_glass
setblock 236 149 268 minecraft:black_stained_glass
setblock 237 149 229 minecraft:black_stained_glass
setblock 237 149 237 minecraft:cyan_stained_glass
setblock 237 149 242 minecraft:light_blue_stained_glass
fill 237 149 252 238 149 253 minecraft:black_concrete
setblock 237 149 255 minecraft:light_blue_stained_glass
setblock 237 149 261 minecraft:sea_lantern
fill 237 149 262 239 149 262 minecraft:blue_terracotta
fill 237 149 264 238 159 264 minecraft:blue_terracotta
fill 237 149 266 238 159 266 minecraft:blue_terracotta
setblock 237 149 269 minecraft:pearlescent_froglight
setblock 238 149 251 minecraft:black_concrete
setblock 239 149 229 minecraft:ochre_froglight
setblock 239 149 237 minecraft:magenta_stained_glass
setblock 239 149 242 minecraft:magenta_stained_glass
fill 239 149 251 239 150 257 minecraft:sea_lantern
fill 239 149 258 243 149 260 minecraft:gray_concrete
setblock 239 149 261 minecraft:sea_lantern
setblock 239 149 269 minecraft:black_stained_glass
fill 240 149 256 242 149 257 minecraft:gray_concrete
fill 240 149 262 240 150 265 minecraft:sea_lantern
fill 240 149 266 243 149 266 minecraft:blue_terracotta
setblock 241 149 229 minecraft:pearlescent_froglight
setblock 241 149 237 minecraft:pearlescent_froglight
setblock 241 149 243 minecraft:sea_lantern
setblock 241 149 245 minecraft:cyan_stained_glass
setblock 241 149 247 minecraft:black_stained_glass
setblock 241 149 249 minecraft:black_stained_glass
setblock 241 149 251 minecraft:ochre_froglight
fill 241 149 252 241 277 252 minecraft:black_concrete
setblock 241 149 253 minecraft:pearlescent_froglight
fill 241 149 254 241 277 255 minecraft:black_concrete
setblock 241 149 261 minecraft:ochre_froglight
fill 241 149 262 242 149 265 minecraft:blue_terracotta
setblock 241 149 269 minecraft:black_stained_glass
fill 242 149 242 242 149 255 minecraft:gray_concrete
setblock 243 149 229 minecraft:black_stained_glass
setblock 243 149 237 minecraft:sea_lantern
fill 243 149 242 243 149 250 minecraft:gray_concrete
fill 243 149 251 244 150 251 minecraft:cyan_stained_glass
fill 243 149 253 243 150 255 minecraft:cyan_stained_glass
fill 243 149 257 244 150 257 minecraft:cyan_stained_glass
setblock 243 149 261 minecraft:sea_lantern
fill 243 149 263 243 159 265 minecraft:blue_terracotta
setblock 243 149 269 minecraft:light_blue_stained_glass
setblock 244 149 230 minecraft:cyan_stained_glass
setblock 244 149 232 minecraft:black_stained_glass
setblock 244 149 234 minecraft:pearlescent_froglight
setblock 244 149 236 minecraft:magenta_stained_glass
fill 244 149 242 244 149 248 minecraft:gray_concrete
fill 244 149 250 244 150 250 minecraft:cyan_stained_glass
fill 244 149 252 244 150 252 minecraft:cyan_stained_glass
fill 244 149 253 247 149 255 minecraft:gray_concrete
fill 244 149 256 244 150 256 minecraft:cyan_stained_glass
fill 244 149 258 244 150 258 minecraft:cyan_stained_glass
setblock 244 149 260 minecraft:gray_concrete
setblock 244 149 262 minecraft:black_stained_glass
setblock 244 149 264 minecraft:light_blue_stained_glass
fill 244 149 265 244 159 265 minecraft:blue_terracotta
setblock 244 149 266 minecraft:black_stained_glass
setblock 244 149 268 minecraft:black_stained_glass
setblock 244 149 270 minecraft:sea_lantern
fill 245 149 229 248 149 237 minecraft:gray_concrete
fill 245 149 242 245 149 247 minecraft:gray_concrete
fill 245 149 249 245 150 249 minecraft:cyan_stained_glass
setblock 245 149 250 minecraft:sea_lantern
fill 245 149 251 248 149 252 minecraft:gray_concrete
fill 245 149 256 248 149 257 minecraft:gray_concrete
setblock 245 149 258 minecraft:sea_lantern
fill 245 149 259 245 150 259 minecraft:cyan_stained_glass
fill 245 149 261 245 149 269 minecraft:gray_concrete
fill 246 149 242 247 149 246 minecraft:gray_concrete
fill 246 149 248 246 150 248 minecraft:cyan_stained_glass
fill 246 149 249 256 149 250 minecraft:gray_concrete
fill 246 149 258 256 149 259 minecraft:gray_concrete
fill 246 149 260 246 150 260 minecraft:cyan_stained_glass
fill 246 149 262 247 149 269 minecraft:gray_concrete
fill 247 149 247 249 150 247 minecraft:cyan_stained_glass
setblock 247 149 248 minecraft:sea_lantern
setblock 247 149 260 minecraft:sea_lantern
fill 247 149 261 249 150 261 minecraft:cyan_stained_glass
fill 248 149 242 270 149 245 minecraft:gray_concrete
fill 248 149 246 248 150 246 minecraft:cyan_stained_glass
fill 248 149 248 254 149 248 minecraft:gray_concrete
fill 248 149 260 254 149 260 minecraft:gray_concrete
fill 248 149 262 248 150 262 minecraft:cyan_stained_glass
fill 248 149 263 248 149 269 minecraft:gray_concrete
setblock 249 149 230 minecraft:magenta_stained_glass
setblock 249 149 232 minecraft:ochre_froglight
fill 249 149 235 267 149 237 minecraft:gray_concrete
setblock 249 149 251 minecraft:gray_concrete
setblock 249 149 257 minecraft:gray_concrete
fill 249 149 263 267 149 263 minecraft:gray_concrete
setblock 249 149 265 minecraft:light_blue_stained_glass
fill 249 149 266 256 228 266 minecraft:gray_concrete
setblock 249 149 267 minecraft:black_stained_glass
setblock 250 149 229 minecraft:sea_lantern
setblock 250 149 234 minecraft:black_stained_glass
fill 250 149 246 252 150 246 minecraft:cyan_stained_glass
fill 250 149 247 252 149 247 minecraft:gray_concrete
fill 250 149 261 252 149 261 minecraft:gray_concrete
fill 250 149 262 252 150 262 minecraft:cyan_stained_glass
setblock 250 149 264 minecraft:pearlescent_froglight
fill 250 149 265 252 228 265 minecraft:gray_concrete
fill 250 149 267 256 228 267 minecraft:gray_concrete
setblock 250 149 269 minecraft:black_stained_glass
fill 251 149 264 251 228 264 minecraft:gray_concrete
setblock 252 149 229 minecraft:black_stained_glass
setblock 252 149 234 minecraft:magenta_stained_glass
setblock 252 149 264 minecraft:light_blue_stained_glass
setblock 252 149 269 minecraft:light_blue_stained_glass
fill 253 149 247 255 150 247 minecraft:cyan_stained_glass
fill 253 149 251 257 149 251 minecraft:gray_concrete
fill 253 149 257 257 149 257 minecraft:gray_concrete
fill 253 149 261 255 150 261 minecraft:cyan_stained_glass
setblock 254 149 229 minecraft:magenta_stained_glass
setblock 254 149 234 minecraft:ochre_froglight
fill 254 149 252 257 149 252 minecraft:gray_concrete
fill 254 149 256 257 149 256 minecraft:gray_concrete
setblock 254 149 264 minecraft:black_stained_glass
setblock 254 149 269 minecraft:black_stained_glass
fill 255 149 228 255 155 228 minecraft:black_concrete
fill 255 149 246 270 149 246 minecraft:gray_concrete
setblock 255 149 248 minecraft:sea_lantern
fill 255 149 253 258 149 255 minecraft:gray_concrete
setblock 255 149 260 minecraft:sea_lantern
fill 255 149 262 267 149 262 minecraft:gray_concrete
setblock 256 149 229 minecraft:black_stained_glass
setblock 256 149 234 minecraft:black_stained_glass
fill 256 149 248 256 150 248 minecraft:cyan_stained_glass
fill 256 149 260 256 150 260 minecraft:cyan_stained_glass
setblock 256 149 264 minecraft:black_stained_glass
setblock 256 149 269 minecraft:black_stained_glass
fill 257 149 247 270 149 247 minecraft:gray_concrete
fill 257 149 249 257 150 249 minecraft:cyan_stained_glass
setblock 257 149 250 minecraft:sea_lantern
setblock 257 149 258 minecraft:sea_lantern
fill 257 149 259 257 150 259 minecraft:cyan_stained_glass
fill 257 149 261 267 149 261 minecraft:gray_concrete
setblock 258 149 229 minecraft:magenta_stained_glass
setblock 258 149 234 minecraft:black_stained_glass
fill 258 149 248 270 149 248 minecraft:gray_concrete
fill 258 149 250 258 150 252 minecraft:cyan_stained_glass
fill 258 149 256 258 150 258 minecraft:cyan_stained_glass
fill 258 149 260 276 149 260 minecraft:gray_concrete
setblock 258 149 264 minecraft:black_stained_glass
setblock 258 149 269 minecraft:magenta_stained_glass
fill 259 149 249 270 149 250 minecraft:gray_concrete
fill 259 149 253 259 150 255 minecraft:cyan_stained_glass
fill 259 149 258 276 149 259 minecraft:gray_concrete
setblock 260 149 229 minecraft:pearlescent_froglight
setblock 260 149 234 minecraft:black_stained_glass
fill 260 149 251 270 149 257 minecraft:gray_concrete
setblock 260 149 264 minecraft:black_stained_glass
setblock 260 149 269 minecraft:light_blue_stained_glass
setblock 262 149 230 minecraft:black_stained_glass
setblock 262 149 232 minecraft:black_stained_glass
setblock 262 149 265 minecraft:magenta_stained_glass
setblock 262 149 267 minecraft:black_stained_glass
fill 263 149 229 267 149 234 minecraft:gray_concrete
fill 263 149 264 267 149 269 minecraft:gray_concrete
setblock 268 149 230 minecraft:ochre_froglight
setblock 268 149 232 minecraft:magenta_stained_glass
setblock 268 149 234 minecraft:black_stained_glass
setblock 268 149 236 minecraft:black_stained_glass
setblock 268 149 262 minecraft:black_stained_glass
setblock 268 149 264 minecraft:cyan_stained_glass
setblock 268 149 266 minecraft:black_stained_glass
setblock 268 149 268 minecraft:pearlescent_froglight
setblock 269 149 229 minecraft:black_stained_glass
setblock 269 149 237 minecraft:black_stained_glass
setblock 269 149 261 minecraft:cyan_stained_glass
setblock 269 149 269 minecraft:black_stained_glass
setblock 271 149 229 minecraft:black_stained_glass
setblock 271 149 237 minecraft:light_blue_stained_glass
setblock 271 149 243 minecraft:magenta_stained_glass
setblock 271 149 245 minecraft:magenta_stained_glass
setblock 271 149 247 minecraft:light_blue_stained_glass
setblock 271 149 249 minecraft:cyan_stained_glass
setblock 271 149 251 minecraft:cyan_stained_glass
setblock 271 149 253 minecraft:ochre_froglight
fill 271 149 256 276 149 257 minecraft:gray_concrete
setblock 271 149 261 minecraft:light_blue_stained_glass
setblock 271 149 269 minecraft:light_blue_stained_glass
setblock 272 149 242 minecraft:sea_lantern
setblock 272 149 255 minecraft:black_stained_glass
setblock 273 149 229 minecraft:sea_lantern
setblock 273 149 237 minecraft:light_blue_stained_glass
setblock 273 149 261 minecraft:cyan_stained_glass
setblock 273 149 269 minecraft:cyan_stained_glass
setblock 274 149 242 minecraft:pearlescent_froglight
setblock 274 149 255 minecraft:black_stained_glass
setblock 275 149 229 minecraft:black_stained_glass
setblock 275 149 237 minecraft:black_stained_glass
setblock 275 149 261 minecraft:black_stained_glass
setblock 275 149 269 minecraft:pearlescent_froglight
setblock 276 149 230 minecraft:sea_lantern
setblock 276 149 232 minecraft:black_stained_glass
setblock 276 149 234 minecraft:black_stained_glass
setblock 276 149 236 minecraft:light_blue_stained_glass
setblock 276 149 243 minecraft:cyan_stained_glass
setblock 276 149 245 minecraft:black_stained_glass
setblock 276 149 247 minecraft:ochre_froglight
setblock 276 149 249 minecraft:sea_lantern
setblock 276 149 251 minecraft:black_stained_glass
setblock 276 149 253 minecraft:magenta_stained_glass
setblock 276 149 262 minecraft:magenta_stained_glass
setblock 276 149 264 minecraft:light_blue_stained_glass
setblock 276 149 266 minecraft:light_blue_stained_glass
setblock 276 149 268 minecraft:magenta_stained_glass
fill 235 150 229 235 188 229 minecraft:black_concrete
fill 235 150 259 235 194 259 minecraft:black_concrete
setblock 235 150 265 minecraft:sea_lantern
fill 236 150 230 236 151 230 minecraft:gray_concrete
fill 236 150 232 236 151 232 minecraft:gray_concrete
fill 236 150 234 236 151 234 minecraft:gray_concrete
fill 236 150 236 236 151 236 minecraft:gray_concrete
fill 236 150 243 236 151 243 minecraft:black_concrete
fill 236 150 245 236 151 245 minecraft:black_concrete
fill 236 150 247 236 151 249 minecraft:black_concrete
fill 236 150 251 236 151 251 minecraft:black_concrete
fill 236 150 253 237 151 253 minecraft:black_concrete
fill 236 150 262 236 151 266 minecraft:blue_terracotta
fill 236 150 268 236 151 268 minecraft:blue_terracotta
fill 237 150 229 237 151 229 minecraft:gray_concrete
fill 237 150 237 237 151 237 minecraft:gray_concrete
fill 237 150 242 237 151 242 minecraft:black_concrete
fill 237 150 248 237 277 248 minecraft:black_concrete
fill 237 150 252 237 277 252 minecraft:black_concrete
fill 237 150 255 237 151 255 minecraft:black_concrete
fill 237 150 261 237 151 263 minecraft:blue_terracotta
fill 237 150 265 238 159 265 minecraft:blue_terracotta
fill 237 150 269 237 151 269 minecraft:blue_terracotta
setblock 238 150 239 minecraft:light[level=15]
fill 238 150 248 238 151 256 minecraft:light_blue_stained_glass
fill 238 150 262 238 159 263 minecraft:blue_terracotta
fill 239 150 229 239 151 229 minecraft:gray_concrete
fill 239 150 237 239 151 237 minecraft:gray_concrete
fill 239 150 242 239 151 242 minecraft:black_concrete
fill 239 150 248 239 151 250 minecraft:light_blue_stained_glass
fill 239 150 258 239 151 265 minecraft:light_blue_stained_glass
fill 239 150 269 239 151 269 minecraft:blue_terracotta
setblock 239 150 270 minecraft:blue_concrete
fill 240 150 250 240 277 250 minecraft:black_concrete
fill 240 150 252 240 151 261 minecraft:light_blue_stained_glass
fill 240 150 266 240 151 266 minecraft:light_blue_stained_glass
fill 241 150 229 241 151 229 minecraft:gray_concrete
fill 241 150 237 241 151 237 minecraft:gray_concrete
fill 241 150 243 241 151 243 minecraft:black_concrete
fill 241 150 245 241 151 245 minecraft:black_concrete
fill 241 150 247 241 151 247 minecraft:black_concrete
fill 241 150 249 241 151 249 minecraft:black_concrete
fill 241 150 251 241 151 251 minecraft:black_concrete
fill 241 150 253 241 151 253 minecraft:black_concrete
fill 241 150 261 241 151 262 minecraft:blue_terracotta
fill 241 150 263 241 151 265 minecraft:light_blue_stained_glass
fill 241 150 266 244 151 266 minecraft:blue_terracotta
fill 241 150 269 241 151 269 minecraft:blue_terracotta
fill 242 150 251 242 150 257 minecraft:cyan_stained_glass
fill 242 150 262 242 159 265 minecraft:blue_terracotta
fill 243 150 229 243 151 229 minecraft:gray_concrete
fill 243 150 237 243 151 237 minecraft:gray_concrete
fill 243 150 249 243 150 250 minecraft:cyan_stained_glass
fill 243 150 258 243 150 259 minecraft:cyan_stained_glass
fill 243 150 261 243 151 261 minecraft:blue_terracotta
fill 243 150 269 243 151 269 minecraft:blue_terracotta
fill 244 150 230 244 151 230 minecraft:gray_concrete
fill 244 150 232 244 151 232 minecraft:gray_concrete
fill 244 150 234 244 151 234 minecraft:gray_concrete
fill 244 150 236 244 151 236 minecraft:gray_concrete
fill 244 150 248 244 150 249 minecraft:cyan_stained_glass
fill 244 150 253 246 150 255 minecraft:cyan_stained_glass
fill 244 150 259 244 150 260 minecraft:cyan_stained_glass
fill 244 150 262 244 151 262 minecraft:blue_terracotta
fill 244 150 264 244 151 264 minecraft:blue_terracotta
fill 244 150 268 244 151 268 minecraft:blue_terracotta
fill 244 150 270 244 195 270 minecraft:black_concrete
fill 245 150 247 246 150 247 minecraft:cyan_stained_glass
fill 245 150 250 246 150 252 minecraft:cyan_stained_glass
fill 245 150 256 246 150 258 minecraft:cyan_stained_glass
fill 245 150 261 246 150 261 minecraft:cyan_stained_glass
setblock 246 150 231 minecraft:light[level=15]
setblock 246 150 239 minecraft:light[level=15]
fill 246 150 246 247 150 246 minecraft:cyan_stained_glass
fill 246 150 249 256 150 249 minecraft:cyan_stained_glass
fill 246 150 259 256 150 259 minecraft:cyan_stained_glass
fill 246 150 262 247 150 262 minecraft:cyan_stained_glass
setblock 246 150 263 minecraft:light[level=15]
fill 247 150 248 255 150 248 minecraft:cyan_stained_glass
fill 247 150 250 247 151 251 minecraft:cyan_stained_glass
fill 247 150 252 247 150 256 minecraft:sea_lantern
fill 247 150 257 247 151 258 minecraft:cyan_stained_glass
fill 247 150 260 255 150 260 minecraft:cyan_stained_glass
fill 248 150 245 254 150 245 minecraft:cyan_stained_glass
fill 248 150 250 248 151 250 minecraft:cyan_stained_glass
fill 248 150 251 248 150 252 minecraft:sea_lantern
fill 248 150 256 248 150 257 minecraft:sea_lantern
fill 248 150 258 248 151 258 minecraft:cyan_stained_glass
fill 248 150 263 254 150 263 minecraft:cyan_stained_glass
fill 249 150 230 249 151 230 minecraft:gray_concrete
fill 249 150 232 249 151 232 minecraft:gray_concrete
fill 249 150 250 249 150 251 minecraft:sea_lantern
fill 249 150 257 249 150 258 minecraft:sea_lantern
fill 249 150 265 249 151 265 minecraft:gray_concrete
fill 249 150 267 249 151 267 minecraft:gray_concrete
fill 250 150 229 250 151 229 minecraft:gray_concrete
fill 250 150 234 250 151 234 minecraft:gray_concrete
fill 250 150 247 252 150 247 minecraft:cyan_stained_glass
fill 250 150 250 253 150 250 minecraft:sea_lantern
fill 250 150 258 253 150 258 minecraft:sea_lantern
fill 250 150 261 252 150 261 minecraft:cyan_stained_glass
fill 250 150 264 250 151 264 minecraft:gray_concrete
fill 250 150 269 250 151 269 minecraft:gray_concrete
setblock 251 150 270 minecraft:purple_concrete
fill 252 150 229 252 151 229 minecraft:gray_concrete
fill 252 150 234 252 151 234 minecraft:gray_concrete
fill 252 150 264 252 151 264 minecraft:gray_concrete
fill 252 150 269 252 151 269 minecraft:gray_concrete
fill 253 150 251 254 150 251 minecraft:sea_lantern
fill 253 150 257 254 150 257 minecraft:sea_lantern
fill 254 150 229 254 151 229 minecraft:gray_concrete
fill 254 150 234 254 151 234 minecraft:gray_concrete
setblock 254 150 239 minecraft:light[level=15]
fill 254 150 250 257 150 250 minecraft:cyan_stained_glass
fill 254 150 252 255 150 252 minecraft:sea_lantern
fill 254 150 256 255 150 256 minecraft:sea_lantern
fill 254 150 258 257 150 258 minecraft:cyan_stained_glass
fill 254 150 264 254 151 264 minecraft:gray_concrete
fill 254 150 269 254 151 269 minecraft:gray_concrete
fill 255 150 246 256 150 246 minecraft:cyan_stained_glass
fill 255 150 251 257 150 251 minecraft:cyan_stained_glass
fill 255 150 253 255 150 255 minecraft:sea_lantern
fill 255 150 257 257 150 257 minecraft:cyan_stained_glass
fill 255 150 262 256 150 262 minecraft:cyan_stained_glass
fill 256 150 229 256 151 229 minecraft:gray_concrete
fill 256 150 234 256 151 234 minecraft:gray_concrete
fill 256 150 247 257 150 247 minecraft:cyan_stained_glass
fill 256 150 252 257 150 256 minecraft:cyan_stained_glass
fill 256 150 261 257 150 261 minecraft:cyan_stained_glass
fill 256 150 264 256 151 264 minecraft:gray_concrete
fill 256 150 269 256 151 269 minecraft:gray_concrete
fill 258 150 229 258 151 229 minecraft:gray_concrete
fill 258 150 234 258 151 234 minecraft:gray_concrete
fill 258 150 248 258 150 249 minecraft:cyan_stained_glass
fill 258 150 253 258 150 255 minecraft:cyan_stained_glass
fill 258 150 259 258 150 260 minecraft:cyan_stained_glass
fill 258 150 264 258 151 264 minecraft:gray_concrete
fill 258 150 269 258 151 269 minecraft:gray_concrete
fill 259 150 249 259 150 250 minecraft:cyan_stained_glass
fill 259 150 258 259 150 259 minecraft:cyan_stained_glass
fill 260 150 229 260 151 229 minecraft:gray_concrete
fill 260 150 234 260 151 234 minecraft:gray_concrete
fill 260 150 251 260 150 257 minecraft:cyan_stained_glass
fill 260 150 264 260 151 264 minecraft:gray_concrete
fill 260 150 269 260 151 269 minecraft:gray_concrete
fill 262 150 230 262 151 230 minecraft:gray_concrete
fill 262 150 232 262 151 232 minecraft:gray_concrete
setblock 262 150 239 minecraft:light[level=15]
setblock 262 150 247 minecraft:light[level=15]
setblock 262 150 255 minecraft:light[level=15]
setblock 262 150 263 minecraft:light[level=15]
fill 262 150 265 262 151 265 minecraft:gray_concrete
fill 262 150 267 262 151 267 minecraft:gray_concrete
fill 268 150 230 268 151 230 minecraft:blue_terracotta
fill 268 150 232 268 151 232 minecraft:blue_terracotta
fill 268 150 234 268 151 234 minecraft:blue_terracotta
fill 268 150 236 268 151 236 minecraft:blue_terracotta
fill 268 150 262 268 151 262 minecraft:gray_concrete
fill 268 150 264 268 151 264 minecraft:gray_concrete
fill 268 150 266 268 151 266 minecraft:gray_concrete
fill 268 150 268 268 151 268 minecraft:gray_concrete
fill 269 150 229 269 151 229 minecraft:blue_terracotta
fill 269 150 237 269 151 237 minecraft:blue_terracotta
fill 269 150 261 269 151 261 minecraft:gray_concrete
fill 269 150 269 269 151 269 minecraft:gray_concrete
setblock 270 150 239 minecraft:light[level=15]
setblock 270 150 247 minecraft:light[level=15]
setblock 270 150 255 minecraft:light[level=15]
fill 271 150 229 271 151 229 minecraft:blue_terracotta
fill 271 150 237 271 151 237 minecraft:blue_terracotta
fill 271 150 243 271 151 243 minecraft:gray_concrete
fill 271 150 245 271 151 245 minecraft:gray_concrete
fill 271 150 247 271 151 247 minecraft:gray_concrete
fill 271 150 249 271 151 249 minecraft:gray_concrete
fill 271 150 251 271 151 251 minecraft:gray_concrete
fill 271 150 253 271 151 253 minecraft:gray_concrete
fill 271 150 261 271 151 261 minecraft:gray_concrete
fill 271 150 269 271 151 269 minecraft:gray_concrete
fill 272 150 242 272 151 242 minecraft:gray_concrete
fill 272 150 255 272 151 255 minecraft:gray_concrete
fill 273 150 229 273 151 229 minecraft:blue_terracotta
fill 273 150 237 273 151 237 minecraft:blue_terracotta
fill 273 150 261 273 151 261 minecraft:gray_concrete
fill 273 150 269 273 151 269 minecraft:gray_concrete
fill 274 150 242 274 151 242 minecraft:gray_concrete
fill 274 150 255 274 151 255 minecraft:gray_concrete
fill 275 150 229 275 151 229 minecraft:blue_terracotta
fill 275 150 237 275 151 237 minecraft:blue_terracotta
fill 275 150 261 275 151 261 minecraft:gray_concrete
fill 275 150 269 275 151 269 minecraft:gray_concrete
fill 276 150 230 276 151 230 minecraft:blue_terracotta
fill 276 150 232 276 151 232 minecraft:blue_terracotta
fill 276 150 234 276 151 234 minecraft:blue_terracotta
fill 276 150 236 276 151 236 minecraft:blue_terracotta
fill 276 150 243 276 151 243 minecraft:gray_concrete
fill 276 150 245 276 151 245 minecraft:gray_concrete
fill 276 150 247 276 151 247 minecraft:gray_concrete
fill 276 150 249 276 151 249 minecraft:gray_concrete
fill 276 150 251 276 151 251 minecraft:gray_concrete
fill 276 150 253 276 151 253 minecraft:gray_concrete
fill 276 150 262 276 151 262 minecraft:gray_concrete
fill 276 150 264 276 151 264 minecraft:gray_concrete
fill 276 150 266 276 151 266 minecraft:gray_concrete
fill 276 150 268 276 151 268 minecraft:gray_concrete
fill 235 151 265 235 239 265 minecraft:black_concrete
setblock 238 151 238 minecraft:light[level=12]
setblock 238 151 259 minecraft:light[level=12]
fill 239 151 251 239 151 257 minecraft:light_blue_stained_glass
fill 239 151 270 239 176 270 minecraft:black_concrete
setblock 240 151 228 minecraft:ochre_froglight
fill 240 151 262 240 151 265 minecraft:light_blue_stained_glass
setblock 245 151 231 minecraft:light[level=12]
setblock 245 151 238 minecraft:light[level=12]
setblock 245 151 245 minecraft:light[level=12]
fill 245 151 252 247 151 252 minecraft:cyan_stained_glass
fill 245 151 253 246 151 253 minecraft:sea_lantern
fill 245 151 254 246 151 254 minecraft:cyan_stained_glass
fill 245 151 255 246 151 255 minecraft:sea_lantern
fill 245 151 256 247 151 256 minecraft:cyan_stained_glass
setblock 245 151 259 minecraft:light[level=12]
setblock 245 151 266 minecraft:light[level=12]
fill 246 151 250 246 151 251 minecraft:cyan_stained_glass
fill 246 151 257 246 151 258 minecraft:cyan_stained_glass
fill 247 151 249 249 151 249 minecraft:cyan_stained_glass
fill 247 151 259 249 151 259 minecraft:cyan_stained_glass
fill 248 151 251 248 152 251 minecraft:cyan_stained_glass
fill 248 151 257 248 152 257 minecraft:cyan_stained_glass
setblock 249 151 248 minecraft:cyan_stained_glass
fill 249 151 250 249 152 250 minecraft:cyan_stained_glass
fill 249 151 258 249 152 258 minecraft:cyan_stained_glass
setblock 249 151 260 minecraft:cyan_stained_glass
fill 250 151 248 250 151 249 minecraft:sea_lantern
fill 250 151 259 250 151 260 minecraft:sea_lantern
fill 251 151 248 251 151 249 minecraft:cyan_stained_glass
fill 251 151 259 251 151 260 minecraft:cyan_stained_glass
fill 251 151 270 251 308 270 minecraft:black_concrete
setblock 252 151 238 minecraft:light[level=12]
setblock 252 151 245 minecraft:light[level=12]
fill 252 151 248 252 151 249 minecraft:sea_lantern
fill 252 151 259 252 151 260 minecraft:sea_lantern
fill 253 151 248 253 151 250 minecraft:cyan_stained_glass
fill 253 151 258 253 151 260 minecraft:cyan_stained_glass
fill 254 151 249 255 151 251 minecraft:cyan_stained_glass
fill 254 151 257 255 151 259 minecraft:cyan_stained_glass
fill 255 151 252 257 151 252 minecraft:cyan_stained_glass
fill 255 151 256 257 151 256 minecraft:cyan_stained_glass
fill 256 151 250 256 151 251 minecraft:cyan_stained_glass
fill 256 151 253 257 151 253 minecraft:sea_lantern
fill 256 151 254 257 151 254 minecraft:cyan_stained_glass
fill 256 151 255 257 151 255 minecraft:sea_lantern
fill 256 151 257 256 151 258 minecraft:cyan_stained_glass
setblock 259 151 238 minecraft:light[level=12]
setblock 259 151 245 minecraft:light[level=12]
setblock 259 151 252 minecraft:light[level=12]
setblock 259 151 259 minecraft:light[level=12]
setblock 266 151 231 minecraft:light[level=12]
setblock 266 151 238 minecraft:light[level=12]
setblock 266 151 245 minecraft:light[level=12]
setblock 266 151 252 minecraft:light[level=12]
setblock 266 151 259 minecraft:light[level=12]
setblock 266 151 266 minecraft:light[level=12]
setblock 273 151 238 minecraft:light[level=12]
setblock 273 151 259 minecraft:light[level=12]
setblock 277 151 245 minecraft:verdant_froglight
setblock 236 152 230 minecraft:magenta_stained_glass
setblock 236 152 232 minecraft:black_stained_glass
setblock 236 152 234 minecraft:black_stained_glass
setblock 236 152 236 minecraft:light_blue_stained_glass
setblock 236 152 243 minecraft:sea_lantern
setblock 236 152 245 minecraft:black_stained_glass
setblock 236 152 247 minecraft:light_blue_stained_glass
fill 236 152 248 236 277 248 minecraft:black_concrete
setblock 236 152 249 minecraft:cyan_stained_glass
setblock 236 152 251 minecraft:cyan_stained_glass
setblock 236 152 253 minecraft:black_stained_glass
setblock 236 152 262 minecraft:cyan_stained_glass
fill 236 152 263 237 159 263 minecraft:blue_terracotta
setblock 236 152 264 minecraft:light_blue_stained_glass
fill 236 152 265 236 159 265 minecraft:blue_terracotta
setblock 236 152 266 minecraft:magenta_stained_glass
setblock 236 152 268 minecraft:black_stained_glass
setblock 237 152 229 minecraft:pearlescent_froglight
setblock 237 152 237 minecraft:black_stained_glass
setblock 237 152 242 minecraft:magenta_stained_glass
fill 237 152 253 240 277 253 minecraft:black_concrete
setblock 237 152 255 minecraft:black_stained_glass
setblock 237 152 261 minecraft:ochre_froglight
fill 237 152 262 237 159 262 minecraft:blue_terracotta
setblock 237 152 269 minecraft:black_stained_glass
fill 238 152 248 239 202 252 minecraft:black_concrete
fill 238 152 254 238 277 255 minecraft:black_concrete
setblock 239 152 229 minecraft:black_stained_glass
setblock 239 152 237 minecraft:black_stained_glass
setblock 239 152 242 minecraft:light_blue_stained_glass
fill 239 152 254 240 277 254 minecraft:black_concrete
setblock 239 152 255 minecraft:light_blue_stained_glass
setblock 239 152 261 minecraft:pearlescent_froglight
fill 239 152 262 241 159 265 minecraft:blue_terracotta
setblock 239 152 269 minecraft:pearlescent_froglight
fill 240 152 228 240 162 228 minecraft:black_concrete
fill 240 152 252 240 277 252 minecraft:black_concrete
fill 240 152 255 240 277 255 minecraft:black_concrete
fill 240 152 261 240 159 261 minecraft:blue_terracotta
fill 240 152 266 243 159 266 minecraft:blue_terracotta
setblock 241 152 229 minecraft:pearlescent_froglight
setblock 241 152 237 minecraft:pearlescent_froglight
setblock 241 152 243 minecraft:black_stained_glass
setblock 241 152 245 minecraft:black_stained_glass
setblock 241 152 247 minecraft:black_stained_glass
setblock 241 152 249 minecraft:black_stained_glass
setblock 241 152 251 minecraft:cyan_stained_glass
setblock 241 152 253 minecraft:black_stained_glass
setblock 241 152 261 minecraft:black_stained_glass
setblock 241 152 269 minecraft:magenta_stained_glass
setblock 243 152 229 minecraft:black_stained_glass
setblock 243 152 237 minecraft:light_blue_stained_glass
setblock 243 152 261 minecraft:pearlescent_froglight
setblock 243 152 269 minecraft:light_blue_stained_glass
setblock 244 152 230 minecraft:light_blue_stained_glass
setblock 244 152 232 minecraft:ochre_froglight
setblock 244 152 234 minecraft:black_stained_glass
setblock 244 152 236 minecraft:black_stained_glass
setblock 244 152 262 minecraft:sea_lantern
setblock 244 152 264 minecraft:black_stained_glass
setblock 244 152 266 minecraft:pearlescent_froglight
setblock 244 152 268 minecraft:ochre_froglight
fill 247 152 252 247 152 256 minecraft:cyan_stained_glass
setblock 248 152 252 minecraft:sea_lantern
setblock 248 152 256 minecraft:sea_lantern
setblock 249 152 230 minecraft:cyan_stained_glass
setblock 249 152 232 minecraft:black_stained_glass
setblock 249 152 251 minecraft:sea_lantern
setblock 249 152 257 minecraft:sea_lantern
setblock 249 152 265 minecraft:cyan_stained_glass
setblock 249 152 267 minecraft:sea_lantern
setblock 250 152 229 minecraft:cyan_stained_glass
setblock 250 152 234 minecraft:magenta_stained_glass
fill 250 152 250 253 152 250 minecraft:cyan_stained_glass
fill 250 152 258 253 152 258 minecraft:cyan_stained_glass
setblock 250 152 264 minecraft:cyan_stained_glass
setblock 250 152 269 minecraft:magenta_stained_glass
setblock 252 152 228 minecraft:ochre_froglight
setblock 252 152 229 minecraft:light_blue_stained_glass
setblock 252 152 234 minecraft:sea_lantern
setblock 252 152 264 minecraft:black_stained_glass
setblock 252 152 269 minecraft:cyan_stained_glass
setblock 253 152 251 minecraft:sea_lantern
setblock 253 152 257 minecraft:sea_lantern
setblock 254 152 229 minecraft:magenta_stained_glass
setblock 254 152 234 minecraft:pearlescent_froglight
setblock 254 152 251 minecraft:cyan_stained_glass
setblock 254 152 256 minecraft:sea_lantern
setblock 254 152 257 minecraft:cyan_stained_glass
setblock 254 152 264 minecraft:sea_lantern
setblock 254 152 269 minecraft:black_stained_glass
fill 255 152 252 255 152 256 minecraft:cyan_stained_glass
setblock 256 152 229 minecraft:light_blue_stained_glass
setblock 256 152 234 minecraft:black_stained_glass
setblock 256 152 264 minecraft:cyan_stained_glass
setblock 256 152 269 minecraft:sea_lantern
setblock 258 152 229 minecraft:sea_lantern
setblock 258 152 234 minecraft:cyan_stained_glass
setblock 258 152 264 minecraft:cyan_stained_glass
setblock 258 152 269 minecraft:black_stained_glass
setblock 260 152 229 minecraft:black_stained_glass
setblock 260 152 234 minecraft:cyan_stained_glass
setblock 260 152 264 minecraft:magenta_stained_glass
setblock 260 152 269 minecraft:pearlescent_froglight
setblock 262 152 230 minecraft:black_stained_glass
setblock 262 152 232 minecraft:black_stained_glass
setblock 262 152 265 minecraft:black_stained_glass
setblock 262 152 267 minecraft:light_blue_stained_glass
setblock 268 152 230 minecraft:magenta_stained_glass
setblock 268 152 232 minecraft:ochre_froglight
setblock 268 152 234 minecraft:black_stained_glass
setblock 268 152 236 minecraft:black_stained_glass
setblock 268 152 262 minecraft:black_stained_glass
setblock 268 152 264 minecraft:sea_lantern
setblock 268 152 266 minecraft:magenta_stained_glass
setblock 268 152 268 minecraft:ochre_froglight
setblock 269 152 229 minecraft:black_stained_glass
setblock 269 152 237 minecraft:sea_lantern
setblock 269 152 261 minecraft:sea_lantern
setblock 269 152 269 minecraft:pearlescent_froglight
setblock 271 152 229 minecraft:ochre_froglight
setblock 271 152 237 minecraft:black_stained_glass
setblock 271 152 243 minecraft:cyan_stained_glass
setblock 271 152 245 minecraft:black_stained_glass
setblock 271 152 247 minecraft:black_stained_glass
setblock 271 152 249 minecraft:cyan_stained_glass
setblock 271 152 251 minecraft:cyan_stained_glass
setblock 271 152 253 minecraft:cyan_stained_glass
setblock 271 152 261 minecraft:light_blue_stained_glass
setblock 271 152 269 minecraft:black_stained_glass
setblock 272 152 242 minecraft:light_blue_stained_glass
setblock 272 152 255 minecraft:magenta_stained_glass
setblock 273 152 229 minecraft:ochre_froglight
setblock 273 152 237 minecraft:black_stained_glass
setblock 273 152 261 minecraft:black_stained_glass
setblock 273 152 269 minecraft:sea_lantern
setblock 274 152 242 minecraft:black_stained_glass
setblock 274 152 255 minecraft:black_stained_glass
setblock 275 152 229 minecraft:black_stained_glass
setblock 275 152 237 minecraft:magenta_stained_glass
setblock 275 152 261 minecraft:black_stained_glass
setblock 275 152 269 minecraft:black_stained_glass
setblock 276 152 230 minecraft:pearlescent_froglight
setblock 276 152 232 minecraft:black_stained_glass
setblock 276 152 234 minecraft:black_stained_glass
setblock 276 152 236 minecraft:black_stained_glass
setblock 276 152 243 minecraft:pearlescent_froglight
setblock 276 152 245 minecraft:light_blue_stained_glass
setblock 276 152 247 minecraft:black_stained_glass
setblock 276 152 249 minecraft:magenta_stained_glass
setblock 276 152 251 minecraft:black_stained_glass
setblock 276 152 253 minecraft:magenta_stained_glass
setblock 276 152 262 minecraft:pearlescent_froglight
setblock 276 152 264 minecraft:ochre_froglight
setblock 276 152 266 minecraft:black_stained_glass
setblock 276 152 268 minecraft:light_blue_stained_glass
fill 277 152 245 277 255 245 minecraft:black_concrete
setblock 277 152 267 minecraft:verdant_froglight
fill 236 153 230 236 154 230 minecraft:gray_concrete
fill 236 153 232 236 154 232 minecraft:gray_concrete
fill 236 153 234 236 154 234 minecraft:gray_concrete
fill 236 153 236 236 154 236 minecraft:gray_concrete
fill 236 153 243 236 154 243 minecraft:black_concrete
fill 236 153 245 236 154 245 minecraft:black_concrete
fill 236 153 247 236 154 247 minecraft:black_concrete
fill 236 153 249 236 154 249 minecraft:black_concrete
fill 236 153 251 236 154 251 minecraft:black_concrete
fill 236 153 253 236 154 253 minecraft:black_concrete
fill 236 153 262 236 154 262 minecraft:blue_terracotta
fill 236 153 264 236 154 264 minecraft:blue_terracotta
fill 236 153 266 236 154 266 minecraft:blue_terracotta
fill 236 153 268 236 154 268 minecraft:blue_terracotta
fill 237 153 229 237 154 229 minecraft:gray_concrete
fill 237 153 237 237 154 237 minecraft:gray_concrete
fill 237 153 242 237 154 242 minecraft:black_concrete
fill 237 153 255 237 154 255 minecraft:black_concrete
fill 237 153 261 237 154 261 minecraft:blue_terracotta
fill 237 153 269 237 154 269 minecraft:blue_terracotta
fill 239 153 229 239 154 229 minecraft:gray_concrete
fill 239 153 237 239 154 237 minecraft:gray_concrete
fill 239 153 242 239 154 242 minecraft:black_concrete
fill 239 153 255 239 154 255 minecraft:black_concrete
fill 239 153 261 239 154 261 minecraft:blue_terracotta
fill 239 153 269 239 154 269 minecraft:blue_terracotta
fill 241 153 229 241 154 229 minecraft:gray_concrete
fill 241 153 237 241 154 237 minecraft:gray_concrete
fill 241 153 243 241 154 243 minecraft:black_concrete
fill 241 153 245 241 154 245 minecraft:black_concrete
fill 241 153 247 241 154 247 minecraft:black_concrete
fill 241 153 249 241 154 249 minecraft:black_concrete
fill 241 153 251 241 154 251 minecraft:black_concrete
fill 241 153 253 241 154 253 minecraft:black_concrete
fill 241 153 261 241 154 261 minecraft:blue_terracotta
fill 241 153 269 241 154 269 minecraft:blue_terracotta
fill 243 153 229 243 154 229 minecraft:gray_concrete
fill 243 153 237 243 154 237 minecraft:gray_concrete
fill 243 153 261 243 154 261 minecraft:blue_terracotta
fill 243 153 269 243 154 269 minecraft:blue_terracotta
fill 244 153 230 244 154 230 minecraft:gray_concrete
fill 244 153 232 244 154 232 minecraft:gray_concrete
fill 244 153 234 244 154 234 minecraft:gray_concrete
fill 244 153 236 244 154 236 minecraft:gray_concrete
fill 244 153 262 244 154 262 minecraft:blue_terracotta
fill 244 153 264 244 154 264 minecraft:blue_terracotta
fill 244 153 266 244 154 266 minecraft:blue_terracotta
fill 244 153 268 244 154 268 minecraft:blue_terracotta
fill 249 153 230 249 154 230 minecraft:gray_concrete
fill 249 153 232 249 154 232 minecraft:gray_concrete
fill 249 153 265 249 154 265 minecraft:gray_concrete
fill 249 153 267 249 154 267 minecraft:gray_concrete
fill 250 153 229 250 154 229 minecraft:gray_concrete
fill 250 153 234 250 154 234 minecraft:gray_concrete
fill 250 153 264 250 154 264 minecraft:gray_concrete
fill 250 153 269 250 154 269 minecraft:gray_concrete
setblock 251 153 254 minecraft:cyan_stained_glass
fill 252 153 228 252 220 228 minecraft:black_concrete
fill 252 153 229 252 154 229 minecraft:gray_concrete
fill 252 153 234 252 154 234 minecraft:gray_concrete
fill 252 153 264 252 154 264 minecraft:gray_concrete
fill 252 153 269 252 154 269 minecraft:gray_concrete
fill 254 153 229 254 154 229 minecraft:gray_concrete
fill 254 153 234 254 154 234 minecraft:gray_concrete
fill 254 153 264 254 154 264 minecraft:gray_concrete
fill 254 153 269 254 154 269 minecraft:gray_concrete
fill 256 153 229 256 154 229 minecraft:gray_concrete
fill 256 153 234 256 154 234 minecraft:gray_concrete
fill 256 153 264 256 154 264 minecraft:gray_concrete
fill 256 153 269 256 154 269 minecraft:gray_concrete
fill 258 153 229 258 154 229 minecraft:gray_concrete
fill 258 153 234 258 154 234 minecraft:gray_concrete
fill 258 153 264 258 154 264 minecraft:gray_concrete
fill 258 153 269 258 157 269 minecraft:gray_concrete
fill 260 153 229 260 154 229 minecraft:gray_concrete
fill 260 153 234 260 154 234 minecraft:gray_concrete
fill 260 153 264 260 154 264 minecraft:gray_concrete
fill 260 153 269 260 154 269 minecraft:gray_concrete
fill 262 153 230 262 154 230 minecraft:gray_concrete
fill 262 153 232 262 154 232 minecraft:gray_concrete
fill 262 153 265 262 154 265 minecraft:gray_concrete
fill 262 153 267 262 154 267 minecraft:gray_concrete
fill 268 153 230 268 154 230 minecraft:blue_terracotta
fill 268 153 232 268 154 232 minecraft:blue_terracotta
fill 268 153 234 268 154 234 minecraft:blue_terracotta
fill 268 153 236 268 154 236 minecraft:blue_terracotta
fill 268 153 262 268 154 262 minecraft:gray_concrete
fill 268 153 264 268 154 264 minecraft:gray_concrete
fill 268 153 266 268 154 266 minecraft:gray_concrete
fill 268 153 268 268 154 268 minecraft:gray_concrete
fill 269 153 229 269 154 229 minecraft:blue_terracotta
fill 269 153 237 269 154 237 minecraft:blue_terracotta
fill 269 153 261 269 154 261 minecraft:gray_concrete
fill 269 153 269 269 154 269 minecraft:gray_concrete
fill 271 153 229 271 154 229 minecraft:blue_terracotta
fill 271 153 237 271 154 237 minecraft:blue_terracotta
fill 271 153 243 271 154 243 minecraft:gray_concrete
fill 271 153 245 271 154 245 minecraft:gray_concrete
fill 271 153 247 271 154 247 minecraft:gray_concrete
fill 271 153 249 271 154 249 minecraft:gray_concrete
fill 271 153 251 271 154 251 minecraft:gray_concrete
fill 271 153 253 271 154 253 minecraft:gray_concrete
fill 271 153 261 271 154 261 minecraft:gray_concrete
fill 271 153 269 271 154 269 minecraft:gray_concrete
fill 272 153 242 272 154 242 minecraft:gray_concrete
fill 272 153 255 272 154 255 minecraft:gray_concrete
fill 273 153 229 273 154 229 minecraft:blue_terracotta
fill 273 153 237 273 154 237 minecraft:blue_terracotta
fill 273 153 261 273 154 261 minecraft:gray_concrete
fill 273 153 269 273 154 269 minecraft:gray_concrete
fill 274 153 242 274 154 242 minecraft:gray_concrete
fill 274 153 255 274 154 255 minecraft:gray_concrete
fill 275 153 229 275 154 229 minecraft:blue_terracotta
fill 275 153 237 275 154 237 minecraft:blue_terracotta
fill 275 153 261 275 154 261 minecraft:gray_concrete
fill 275 153 269 275 154 269 minecraft:gray_concrete
fill 276 153 230 276 154 230 minecraft:blue_terracotta
fill 276 153 232 276 154 232 minecraft:blue_terracotta
fill 276 153 234 276 154 234 minecraft:blue_terracotta
fill 276 153 236 276 154 236 minecraft:blue_terracotta
fill 276 153 243 276 154 243 minecraft:gray_concrete
fill 276 153 245 276 154 245 minecraft:gray_concrete
fill 276 153 247 276 154 247 minecraft:gray_concrete
fill 276 153 249 276 154 249 minecraft:gray_concrete
fill 276 153 251 276 154 251 minecraft:gray_concrete
fill 276 153 253 276 154 253 minecraft:gray_concrete
fill 276 153 262 276 154 262 minecraft:gray_concrete
fill 276 153 264 276 154 264 minecraft:gray_concrete
fill 276 153 266 276 154 266 minecraft:gray_concrete
fill 276 153 268 276 154 268 minecraft:gray_concrete
fill 277 153 267 277 209 267 minecraft:black_concrete
setblock 235 154 253 minecraft:ochre_froglight
fill 246 154 263 248 179 269 minecraft:gray_concrete
fill 249 154 263 258 179 263 minecraft:gray_concrete
setblock 254 154 228 minecraft:pearlescent_froglight
fill 263 154 264 267 156 269 minecraft:gray_concrete
setblock 268 154 270 minecraft:purple_concrete
fill 269 154 270 269 186 270 minecraft:black_concrete
fill 235 155 253 235 223 253 minecraft:black_concrete
setblock 236 155 230 minecraft:black_stained_glass
setblock 236 155 232 minecraft:black_stained_glass
setblock 236 155 234 minecraft:black_stained_glass
setblock 236 155 236 minecraft:black_stained_glass
setblock 236 155 243 minecraft:black_stained_glass
setblock 236 155 245 minecraft:cyan_stained_glass
setblock 236 155 247 minecraft:black_stained_glass
setblock 236 155 249 minecraft:cyan_stained_glass
setblock 236 155 251 minecraft:sea_lantern
setblock 236 155 253 minecraft:black_stained_glass
setblock 236 155 262 minecraft:sea_lantern
setblock 236 155 264 minecraft:pearlescent_froglight
setblock 236 155 266 minecraft:magenta_stained_glass
setblock 236 155 268 minecraft:sea_lantern
setblock 237 155 229 minecraft:sea_lantern
setblock 237 155 237 minecraft:sea_lantern
setblock 237 155 242 minecraft:light_blue_stained_glass
setblock 237 155 255 minecraft:black_stained_glass
setblock 237 155 261 minecraft:black_stained_glass
setblock 237 155 269 minecraft:black_stained_glass
setblock 239 155 229 minecraft:black_stained_glass
setblock 239 155 237 minecraft:black_stained_glass
setblock 239 155 242 minecraft:sea_lantern
setblock 239 155 255 minecraft:cyan_stained_glass
setblock 239 155 261 minecraft:sea_lantern
setblock 239 155 269 minecraft:black_stained_glass
setblock 241 155 229 minecraft:black_stained_glass
setblock 241 155 237 minecraft:pearlescent_froglight
setblock 241 155 243 minecraft:sea_lantern
setblock 241 155 245 minecraft:sea_lantern
setblock 241 155 247 minecraft:light_blue_stained_glass
setblock 241 155 249 minecraft:sea_lantern
setblock 241 155 251 minecraft:cyan_stained_glass
setblock 241 155 253 minecraft:black_stained_glass
setblock 241 155 261 minecraft:ochre_froglight
setblock 241 155 269 minecraft:black_stained_glass
setblock 243 155 228 minecraft:magenta_concrete
setblock 243 155 229 minecraft:black_stained_glass
setblock 243 155 237 minecraft:sea_lantern
setblock 243 155 261 minecraft:magenta_stained_glass
setblock 243 155 269 minecraft:black_stained_glass
setblock 244 155 230 minecraft:magenta_stained_glass
setblock 244 155 232 minecraft:black_stained_glass
setblock 244 155 234 minecraft:pearlescent_froglight
setblock 244 155 236 minecraft:black_stained_glass
setblock 244 155 262 minecraft:ochre_froglight
setblock 244 155 264 minecraft:pearlescent_froglight
setblock 244 155 266 minecraft:pearlescent_froglight
setblock 244 155 268 minecraft:black_stained_glass
setblock 249 155 230 minecraft:black_stained_glass
setblock 249 155 232 minecraft:black_stained_glass
setblock 249 155 265 minecraft:magenta_stained_glass
setblock 249 155 267 minecraft:black_stained_glass
setblock 250 155 229 minecraft:ochre_froglight
setblock 250 155 234 minecraft:cyan_stained_glass
setblock 250 155 264 minecraft:black_stained_glass
setblock 250 155 269 minecraft:black_stained_glass
setblock 252 155 229 minecraft:black_stained_glass
setblock 252 155 234 minecraft:ochre_froglight
setblock 252 155 264 minecraft:ochre_froglight
setblock 252 155 269 minecraft:ochre_froglight
fill 254 155 228 254 181 228 minecraft:black_concrete
setblock 254 155 229 minecraft:sea_lantern
setblock 254 155 234 minecraft:black_stained_glass
setblock 254 155 264 minecraft:pearlescent_froglight
setblock 254 155 269 minecraft:black_stained_glass
setblock 256 155 229 minecraft:black_stained_glass
setblock 256 155 234 minecraft:black_stained_glass
setblock 256 155 264 minecraft:magenta_stained_glass
setblock 256 155 269 minecraft:cyan_stained_glass
setblock 258 155 229 minecraft:sea_lantern
setblock 258 155 234 minecraft:black_stained_glass
setblock 258 155 264 minecraft:sea_lantern
setblock 260 155 229 minecraft:sea_lantern
setblock 260 155 234 minecraft:magenta_stained_glass
setblock 260 155 264 minecraft:cyan_stained_glass
setblock 260 155 269 minecraft:light_blue_stained_glass
setblock 262 155 230 minecraft:black_stained_glass
setblock 262 155 232 minecraft:sea_lantern
setblock 262 155 265 minecraft:cyan_stained_glass
setblock 262 155 267 minecraft:ochre_froglight
setblock 268 155 230 minecraft:light_blue_stained_glass
setblock 268 155 232 minecraft:black_stained_glass
setblock 268 155 234 minecraft:black_stained_glass
setblock 268 155 236 minecraft:black_stained_glass
setblock 268 155 262 minecraft:pearlescent_froglight
setblock 268 155 264 minecraft:cyan_stained_glass
setblock 268 155 266 minecraft:black_stained_glass
setblock 268 155 268 minecraft:black_stained_glass
fill 268 155 270 268 250 270 minecraft:black_concrete
setblock 269 155 229 minecraft:black_stained_glass
setblock 269 155 237 minecraft:magenta_stained_glass
setblock 269 155 261 minecraft:light_blue_stained_glass
setblock 269 155 269 minecraft:light_blue_stained_glass
setblock 271 155 229 minecraft:black_stained_glass
setblock 271 155 237 minecraft:black_stained_glass
setblock 271 155 243 minecraft:black_stained_glass
setblock 271 155 245 minecraft:cyan_stained_glass
setblock 271 155 247 minecraft:black_stained_glass
setblock 271 155 249 minecraft:black_stained_glass
setblock 271 155 251 minecraft:light_blue_stained_glass
setblock 271 155 253 minecraft:black_stained_glass
setblock 271 155 261 minecraft:magenta_stained_glass
setblock 271 155 269 minecraft:magenta_stained_glass
setblock 272 155 242 minecraft:black_stained_glass
setblock 272 155 255 minecraft:ochre_froglight
setblock 273 155 229 minecraft:black_stained_glass
setblock 273 155 237 minecraft:black_stained_glass
setblock 273 155 261 minecraft:sea_lantern
setblock 273 155 269 minecraft:cyan_stained_glass
setblock 274 155 242 minecraft:black_stained_glass
setblock 274 155 255 minecraft:black_stained_glass
setblock 275 155 229 minecraft:ochre_froglight
setblock 275 155 237 minecraft:black_stained_glass
setblock 275 155 261 minecraft:black_stained_glass
setblock 275 155 269 minecraft:pearlescent_froglight
setblock 276 155 230 minecraft:black_stained_glass
setblock 276 155 232 minecraft:black_stained_glass
setblock 276 155 234 minecraft:sea_lantern
setblock 276 155 236 minecraft:black_stained_glass
setblock 276 155 243 minecraft:black_stained_glass
setblock 276 155 245 minecraft:pearlescent_froglight
setblock 276 155 247 minecraft:black_stained_glass
setblock 276 155 249 minecraft:black_stained_glass
setblock 276 155 251 minecraft:pearlescent_froglight
setblock 276 155 253 minecraft:black_stained_glass
setblock 276 155 262 minecraft:light_blue_stained_glass
setblock 276 155 264 minecraft:cyan_stained_glass
setblock 276 155 266 minecraft:black_stained_glass
setblock 276 155 268 minecraft:pearlescent_froglight
setblock 277 155 254 minecraft:blue_concrete
fill 236 156 230 236 157 230 minecraft:gray_concrete
fill 236 156 232 236 157 232 minecraft:gray_concrete
fill 236 156 234 236 157 234 minecraft:gray_concrete
fill 236 156 236 236 157 236 minecraft:gray_concrete
fill 236 156 243 236 157 243 minecraft:black_concrete
fill 236 156 245 236 157 245 minecraft:black_concrete
fill 236 156 247 236 157 247 minecraft:black_concrete
fill 236 156 249 236 157 249 minecraft:black_concrete
fill 236 156 251 236 157 251 minecraft:black_concrete
fill 236 156 253 236 157 253 minecraft:black_concrete
fill 236 156 262 236 157 262 minecraft:blue_terracotta
fill 236 156 264 236 157 264 minecraft:blue_terracotta
fill 236 156 266 236 157 266 minecraft:blue_terracotta
fill 236 156 268 236 157 268 minecraft:blue_terracotta
fill 237 156 229 237 157 229 minecraft:gray_concrete
fill 237 156 237 237 157 237 minecraft:gray_concrete
fill 237 156 242 237 157 242 minecraft:black_concrete
fill 237 156 255 237 157 255 minecraft:black_concrete
fill 237 156 261 237 157 261 minecraft:blue_terracotta
fill 237 156 269 237 157 269 minecraft:blue_terracotta
fill 239 156 229 239 157 229 minecraft:gray_concrete
fill 239 156 237 239 157 237 minecraft:gray_concrete
fill 239 156 242 239 157 242 minecraft:black_concrete
fill 239 156 255 239 157 255 minecraft:black_concrete
fill 239 156 261 239 157 261 minecraft:blue_terracotta
fill 239 156 269 239 157 269 minecraft:blue_terracotta
fill 241 156 229 241 157 229 minecraft:gray_concrete
fill 241 156 237 241 157 237 minecraft:gray_concrete
fill 241 156 243 241 157 243 minecraft:black_concrete
fill 241 156 245 241 157 245 minecraft:black_concrete
fill 241 156 247 241 157 247 minecraft:black_concrete
fill 241 156 249 241 157 249 minecraft:black_concrete
fill 241 156 251 241 157 251 minecraft:black_concrete
fill 241 156 253 241 157 253 minecraft:black_concrete
fill 241 156 261 241 157 261 minecraft:blue_terracotta
fill 241 156 269 241 157 269 minecraft:blue_terracotta
fill 243 156 228 243 188 228 minecraft:black_concrete
fill 243 156 229 243 157 229 minecraft:gray_concrete
fill 243 156 237 243 157 237 minecraft:gray_concrete
fill 243 156 261 243 157 261 minecraft:blue_terracotta
fill 243 156 269 243 157 269 minecraft:blue_terracotta
fill 244 156 230 244 157 230 minecraft:gray_concrete
fill 244 156 232 244 157 232 minecraft:gray_concrete
fill 244 156 234 244 157 234 minecraft:gray_concrete
fill 244 156 236 244 157 236 minecraft:gray_concrete
fill 244 156 262 244 157 262 minecraft:blue_terracotta
fill 244 156 264 244 157 264 minecraft:blue_terracotta
fill 244 156 266 244 157 266 minecraft:blue_terracotta
fill 244 156 268 244 157 268 minecraft:blue_terracotta
fill 249 156 230 249 157 230 minecraft:gray_concrete
fill 249 156 232 249 157 232 minecraft:gray_concrete
fill 249 156 265 249 157 265 minecraft:gray_concrete
fill 249 156 267 249 157 267 minecraft:gray_concrete
fill 250 156 229 250 157 229 minecraft:gray_concrete
fill 250 156 234 250 157 234 minecraft:gray_concrete
fill 250 156 264 250 160 264 minecraft:gray_concrete
fill 250 156 269 250 157 269 minecraft:gray_concrete
fill 252 156 229 252 157 229 minecraft:gray_concrete
fill 252 156 234 252 157 234 minecraft:gray_concrete
fill 252 156 264 252 157 264 minecraft:gray_concrete
fill 252 156 269 252 157 269 minecraft:gray_concrete
fill 254 156 229 254 157 229 minecraft:gray_concrete
fill 254 156 234 254 157 234 minecraft:gray_concrete
fill 254 156 264 254 157 264 minecraft:gray_concrete
fill 254 156 269 254 157 269 minecraft:gray_concrete
setblock 255 156 228 minecraft:cyan_concrete
fill 256 156 229 256 157 229 minecraft:gray_concrete
fill 256 156 234 256 157 234 minecraft:gray_concrete
fill 256 156 264 256 157 264 minecraft:gray_concrete
fill 256 156 269 256 157 269 minecraft:gray_concrete
fill 258 156 229 258 157 229 minecraft:gray_concrete
fill 258 156 234 258 157 234 minecraft:gray_concrete
fill 258 156 264 258 157 264 minecraft:gray_concrete
fill 260 156 229 260 157 229 minecraft:gray_concrete
fill 260 156 234 260 157 234 minecraft:gray_concrete
fill 260 156 264 260 157 264 minecraft:gray_concrete
fill 260 156 269 260 157 269 minecraft:gray_concrete
fill 262 156 230 262 157 230 minecraft:gray_concrete
fill 262 156 232 262 157 232 minecraft:gray_concrete
setblock 262 156 265 minecraft:gray_concrete
schedule function dropper:buildpart/53_4 1t
