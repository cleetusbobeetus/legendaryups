setblock 270 186 294 minecraft:light[level=15]
setblock 270 186 302 minecraft:light[level=15]
setblock 270 186 310 minecraft:light[level=15]
fill 271 186 317 274 191 317 minecraft:glowstone
fill 277 186 276 277 191 279 minecraft:glowstone
fill 277 186 288 277 191 291 minecraft:glowstone
fill 277 186 300 277 191 303 minecraft:glowstone
fill 277 186 312 277 191 315 minecraft:glowstone
fill 235 187 288 235 216 288 minecraft:sandstone
setblock 235 187 304 minecraft:lapis_block
fill 238 187 298 242 187 298 minecraft:chiseled_sandstone
setblock 248 187 275 minecraft:blue_terracotta
fill 261 187 275 261 216 275 minecraft:sandstone
setblock 262 187 275 minecraft:lapis_block
fill 263 187 275 263 213 275 minecraft:sandstone
fill 268 187 317 268 191 317 minecraft:sandstone
setblock 277 187 280 minecraft:lapis_block
fill 277 187 293 277 198 296 minecraft:sandstone
setblock 277 187 297 minecraft:lapis_block
fill 235 188 304 235 216 304 minecraft:sandstone
setblock 235 188 316 minecraft:blue_terracotta
setblock 239 188 275 minecraft:lapis_block
fill 239 188 297 241 189 299 minecraft:cut_sandstone
fill 248 188 275 248 198 275 minecraft:sandstone
fill 249 188 310 251 189 312 minecraft:cut_sandstone
fill 262 188 275 262 212 275 minecraft:sandstone
fill 277 188 280 277 193 280 minecraft:sandstone
fill 277 188 297 277 193 297 minecraft:sandstone
fill 235 189 316 235 192 316 minecraft:sandstone
fill 239 189 275 239 213 275 minecraft:sandstone
setblock 277 189 298 minecraft:orange_terracotta
setblock 238 190 278 minecraft:light[level=12]
setblock 238 190 285 minecraft:light[level=12]
setblock 238 190 292 minecraft:light[level=12]
setblock 238 190 299 minecraft:light[level=12]
setblock 238 190 306 minecraft:light[level=12]
setblock 238 190 313 minecraft:light[level=12]
fill 239 190 298 241 192 298 minecraft:cut_sandstone
fill 240 190 297 240 192 297 minecraft:cut_sandstone
fill 240 190 299 240 192 299 minecraft:cut_sandstone
setblock 245 190 278 minecraft:light[level=12]
setblock 245 190 285 minecraft:light[level=12]
setblock 245 190 292 minecraft:light[level=12]
setblock 245 190 299 minecraft:light[level=12]
setblock 245 190 306 minecraft:light[level=12]
setblock 245 190 313 minecraft:light[level=12]
fill 249 190 311 251 192 311 minecraft:cut_sandstone
fill 250 190 310 250 192 310 minecraft:cut_sandstone
fill 250 190 312 250 192 312 minecraft:cut_sandstone
setblock 252 190 278 minecraft:light[level=12]
setblock 252 190 285 minecraft:light[level=12]
setblock 252 190 292 minecraft:light[level=12]
setblock 252 190 299 minecraft:light[level=12]
setblock 252 190 306 minecraft:light[level=12]
setblock 252 190 313 minecraft:light[level=12]
setblock 258 190 275 minecraft:lapis_block
setblock 259 190 278 minecraft:light[level=12]
setblock 259 190 285 minecraft:light[level=12]
setblock 259 190 292 minecraft:light[level=12]
setblock 259 190 299 minecraft:light[level=12]
setblock 259 190 306 minecraft:light[level=12]
setblock 259 190 313 minecraft:light[level=12]
setblock 266 190 278 minecraft:light[level=12]
setblock 266 190 285 minecraft:light[level=12]
setblock 266 190 292 minecraft:light[level=12]
setblock 266 190 299 minecraft:light[level=12]
setblock 266 190 306 minecraft:light[level=12]
setblock 266 190 313 minecraft:light[level=12]
setblock 273 190 278 minecraft:light[level=12]
setblock 273 190 285 minecraft:light[level=12]
setblock 273 190 292 minecraft:light[level=12]
setblock 273 190 299 minecraft:light[level=12]
setblock 273 190 306 minecraft:light[level=12]
setblock 273 190 313 minecraft:light[level=12]
fill 277 190 298 277 216 298 minecraft:sandstone
fill 258 191 275 258 212 275 minecraft:sandstone
setblock 277 191 306 minecraft:blue_terracotta
fill 235 192 281 235 216 281 minecraft:sandstone
fill 235 192 282 235 192 283 minecraft:glowstone
fill 235 192 284 235 212 284 minecraft:sandstone
fill 235 192 293 235 216 293 minecraft:sandstone
fill 235 192 294 235 192 295 minecraft:glowstone
fill 235 192 296 235 204 296 minecraft:sandstone
fill 235 192 305 235 214 305 minecraft:sandstone
fill 235 192 306 235 192 307 minecraft:glowstone
setblock 235 192 308 minecraft:black_terracotta
fill 235 192 317 235 213 317 minecraft:sandstone
fill 236 192 317 237 192 317 minecraft:glowstone
fill 238 192 317 238 216 317 minecraft:sandstone
fill 242 192 275 242 201 275 minecraft:sandstone
fill 243 192 275 244 192 275 minecraft:glowstone
fill 245 192 275 245 206 275 minecraft:sandstone
fill 247 192 317 247 217 317 minecraft:sandstone
fill 248 192 317 249 192 317 minecraft:glowstone
fill 250 192 317 250 209 317 minecraft:sandstone
fill 254 192 275 254 217 275 minecraft:sandstone
fill 255 192 275 256 192 275 minecraft:glowstone
fill 257 192 275 257 216 275 minecraft:sandstone
fill 259 192 317 259 196 317 minecraft:sandstone
fill 260 192 317 261 192 317 minecraft:glowstone
fill 262 192 317 262 198 317 minecraft:sandstone
setblock 266 192 275 minecraft:black_terracotta
fill 267 192 275 268 192 275 minecraft:glowstone
setblock 268 192 317 minecraft:lapis_block
fill 269 192 275 269 203 275 minecraft:sandstone
fill 271 192 317 271 216 317 minecraft:sandstone
fill 272 192 317 273 192 317 minecraft:glowstone
fill 274 192 317 274 213 317 minecraft:sandstone
fill 277 192 276 277 216 276 minecraft:sandstone
fill 277 192 277 277 192 278 minecraft:glowstone
fill 277 192 279 277 194 279 minecraft:sandstone
fill 277 192 288 277 214 288 minecraft:sandstone
fill 277 192 289 277 192 290 minecraft:glowstone
fill 277 192 291 277 202 291 minecraft:sandstone
fill 277 192 300 277 200 300 minecraft:sandstone
fill 277 192 301 277 192 302 minecraft:glowstone
fill 277 192 303 277 197 303 minecraft:sandstone
fill 277 192 306 277 216 306 minecraft:sandstone
fill 277 192 312 277 212 312 minecraft:sandstone
fill 277 192 313 277 192 314 minecraft:glowstone
fill 277 192 315 277 200 315 minecraft:sandstone
fill 235 193 282 235 207 283 minecraft:sandstone
setblock 235 193 287 minecraft:black_terracotta
fill 235 193 294 235 201 295 minecraft:sandstone
fill 235 193 306 235 205 308 minecraft:sandstone
fill 235 193 312 235 210 312 minecraft:sandstone
setblock 235 193 313 minecraft:blue_terracotta
fill 235 193 314 235 205 314 minecraft:sandstone
setblock 235 193 316 minecraft:black_terracotta
fill 236 193 317 237 194 317 minecraft:sandstone
fill 240 193 298 240 197 298 minecraft:cut_sandstone
fill 243 193 275 244 199 275 minecraft:sandstone
fill 248 193 317 249 193 317 minecraft:sandstone
fill 250 193 311 250 197 311 minecraft:cut_sandstone
fill 255 193 275 256 196 275 minecraft:sandstone
fill 260 193 317 261 212 317 minecraft:sandstone
fill 266 193 275 268 205 275 minecraft:sandstone
fill 268 193 317 268 212 317 minecraft:sandstone
fill 272 193 317 273 216 317 minecraft:sandstone
fill 277 193 277 277 207 278 minecraft:sandstone
fill 277 193 289 277 198 290 minecraft:sandstone
fill 277 193 301 277 193 302 minecraft:sandstone
fill 277 193 313 277 202 314 minecraft:sandstone
fill 235 194 287 235 212 287 minecraft:sandstone
setblock 235 194 292 minecraft:orange_terracotta
setblock 235 194 303 minecraft:blue_terracotta
fill 235 194 313 235 213 313 minecraft:sandstone
fill 235 194 316 235 216 316 minecraft:sandstone
setblock 238 194 278 minecraft:light[level=15]
setblock 238 194 286 minecraft:light[level=15]
setblock 238 194 294 minecraft:light[level=15]
setblock 238 194 302 minecraft:light[level=15]
setblock 238 194 310 minecraft:light[level=15]
setblock 246 194 278 minecraft:light[level=15]
setblock 246 194 286 minecraft:light[level=15]
setblock 246 194 294 minecraft:light[level=15]
setblock 246 194 302 minecraft:light[level=15]
setblock 246 194 310 minecraft:light[level=15]
fill 248 194 317 248 216 317 minecraft:sandstone
setblock 249 194 317 minecraft:blue_terracotta
setblock 254 194 278 minecraft:light[level=15]
setblock 254 194 286 minecraft:light[level=15]
setblock 254 194 294 minecraft:light[level=15]
setblock 254 194 302 minecraft:light[level=15]
setblock 254 194 310 minecraft:light[level=15]
setblock 262 194 278 minecraft:light[level=15]
setblock 262 194 286 minecraft:light[level=15]
setblock 262 194 294 minecraft:light[level=15]
setblock 262 194 302 minecraft:light[level=15]
setblock 262 194 310 minecraft:light[level=15]
setblock 270 194 278 minecraft:light[level=15]
setblock 270 194 286 minecraft:light[level=15]
setblock 270 194 294 minecraft:light[level=15]
setblock 270 194 302 minecraft:light[level=15]
setblock 270 194 310 minecraft:light[level=15]
setblock 277 194 280 minecraft:orange_terracotta
setblock 277 194 297 minecraft:lapis_block
setblock 277 194 301 minecraft:blue_terracotta
fill 277 194 302 277 213 302 minecraft:sandstone
fill 235 195 292 235 216 292 minecraft:sandstone
fill 235 195 303 235 199 303 minecraft:sandstone
fill 236 195 317 236 216 317 minecraft:sandstone
setblock 237 195 317 minecraft:orange_terracotta
fill 249 195 317 249 213 317 minecraft:sandstone
setblock 277 195 279 minecraft:orange_terracotta
fill 277 195 280 277 197 280 minecraft:sandstone
fill 277 195 297 277 200 297 minecraft:sandstone
fill 277 195 301 277 214 301 minecraft:sandstone
setblock 236 196 275 minecraft:blue_terracotta
fill 237 196 275 237 216 275 minecraft:sandstone
fill 237 196 317 237 203 317 minecraft:sandstone
setblock 238 196 278 minecraft:light[level=12]
setblock 238 196 285 minecraft:light[level=12]
setblock 238 196 292 minecraft:light[level=12]
setblock 238 196 299 minecraft:light[level=12]
setblock 238 196 306 minecraft:light[level=12]
setblock 238 196 313 minecraft:light[level=12]
setblock 245 196 278 minecraft:light[level=12]
setblock 245 196 285 minecraft:light[level=12]
setblock 245 196 292 minecraft:light[level=12]
setblock 245 196 299 minecraft:light[level=12]
setblock 245 196 306 minecraft:light[level=12]
setblock 245 196 313 minecraft:light[level=12]
setblock 252 196 278 minecraft:light[level=12]
setblock 252 196 285 minecraft:light[level=12]
setblock 252 196 292 minecraft:light[level=12]
setblock 252 196 299 minecraft:light[level=12]
setblock 252 196 306 minecraft:light[level=12]
setblock 252 196 313 minecraft:light[level=12]
setblock 259 196 278 minecraft:light[level=12]
setblock 259 196 285 minecraft:light[level=12]
setblock 259 196 292 minecraft:light[level=12]
setblock 259 196 299 minecraft:light[level=12]
setblock 259 196 306 minecraft:light[level=12]
setblock 259 196 313 minecraft:light[level=12]
setblock 266 196 278 minecraft:light[level=12]
setblock 266 196 285 minecraft:light[level=12]
setblock 266 196 292 minecraft:light[level=12]
setblock 266 196 299 minecraft:light[level=12]
setblock 266 196 306 minecraft:light[level=12]
setblock 266 196 313 minecraft:light[level=12]
setblock 273 196 278 minecraft:light[level=12]
setblock 273 196 285 minecraft:light[level=12]
setblock 273 196 292 minecraft:light[level=12]
setblock 273 196 299 minecraft:light[level=12]
setblock 273 196 306 minecraft:light[level=12]
setblock 273 196 313 minecraft:light[level=12]
fill 277 196 279 277 214 279 minecraft:sandstone
setblock 277 196 304 minecraft:lapis_block
fill 236 197 275 236 217 275 minecraft:sandstone
setblock 253 197 317 minecraft:blue_terracotta
setblock 255 197 275 minecraft:blue_terracotta
fill 256 197 275 256 216 275 minecraft:sandstone
fill 258 197 317 259 197 317 minecraft:black_terracotta
fill 277 197 304 277 212 304 minecraft:sandstone
setblock 240 198 298 minecraft:glowstone
setblock 250 198 311 minecraft:glowstone
fill 253 198 317 253 216 317 minecraft:sandstone
fill 255 198 275 255 216 275 minecraft:sandstone
fill 258 198 317 259 205 317 minecraft:sandstone
setblock 277 198 280 minecraft:blue_terracotta
setblock 277 198 303 minecraft:orange_terracotta
setblock 248 199 275 minecraft:orange_terracotta
setblock 262 199 317 minecraft:lapis_block
fill 277 199 280 277 208 280 minecraft:sandstone
fill 277 199 289 277 212 289 minecraft:sandstone
setblock 277 199 290 minecraft:lapis_block
fill 277 199 293 277 212 295 minecraft:sandstone
setblock 277 199 296 minecraft:black_terracotta
fill 277 199 303 277 216 303 minecraft:sandstone
setblock 235 200 303 minecraft:orange_terracotta
fill 237 200 285 237 203 287 minecraft:cut_sandstone
fill 237 200 297 237 203 299 minecraft:cut_sandstone
fill 237 200 309 237 203 311 minecraft:cut_sandstone
fill 243 200 275 243 214 275 minecraft:sandstone
fill 243 200 315 245 203 315 minecraft:cut_sandstone
setblock 244 200 275 minecraft:orange_terracotta
fill 247 200 277 249 203 277 minecraft:cut_sandstone
fill 248 200 275 248 203 275 minecraft:sandstone
fill 255 200 315 257 203 315 minecraft:cut_sandstone
fill 259 200 277 261 203 277 minecraft:cut_sandstone
fill 262 200 317 262 218 317 minecraft:sandstone
fill 267 200 315 269 203 315 minecraft:cut_sandstone
fill 271 200 277 273 203 277 minecraft:cut_sandstone
fill 275 200 285 275 203 287 minecraft:cut_sandstone
fill 275 200 297 275 203 299 minecraft:cut_sandstone
fill 275 200 309 275 203 311 minecraft:cut_sandstone
fill 277 200 290 277 216 290 minecraft:sandstone
fill 277 200 296 277 214 296 minecraft:sandstone
fill 235 201 303 235 211 303 minecraft:sandstone
fill 244 201 275 244 217 275 minecraft:sandstone
setblock 277 201 297 minecraft:lapis_block
setblock 277 201 300 minecraft:orange_terracotta
setblock 277 201 315 minecraft:black_terracotta
setblock 235 202 294 minecraft:blue_terracotta
fill 235 202 295 235 216 295 minecraft:sandstone
setblock 238 202 278 minecraft:light[level=15]
setblock 238 202 285 minecraft:light[level=12]
setblock 238 202 286 minecraft:light[level=15]
setblock 238 202 292 minecraft:light[level=12]
setblock 238 202 294 minecraft:light[level=15]
setblock 238 202 299 minecraft:light[level=12]
setblock 238 202 302 minecraft:light[level=15]
setblock 238 202 306 minecraft:light[level=12]
setblock 238 202 310 minecraft:light[level=15]
setblock 238 202 313 minecraft:light[level=12]
setblock 242 202 275 minecraft:black_terracotta
setblock 245 202 278 minecraft:light[level=12]
setblock 245 202 285 minecraft:light[level=12]
setblock 245 202 292 minecraft:light[level=12]
setblock 245 202 299 minecraft:light[level=12]
setblock 245 202 306 minecraft:light[level=12]
setblock 245 202 313 minecraft:light[level=12]
setblock 246 202 278 minecraft:light[level=15]
setblock 246 202 286 minecraft:light[level=15]
setblock 246 202 294 minecraft:light[level=15]
setblock 246 202 302 minecraft:light[level=15]
setblock 246 202 310 minecraft:light[level=15]
fill 247 202 300 249 203 300 minecraft:smooth_sandstone
fill 248 202 299 248 203 299 minecraft:smooth_sandstone
setblock 252 202 278 minecraft:light[level=12]
setblock 252 202 285 minecraft:light[level=12]
setblock 252 202 292 minecraft:light[level=12]
setblock 252 202 299 minecraft:light[level=12]
setblock 252 202 306 minecraft:light[level=12]
setblock 252 202 313 minecraft:light[level=12]
setblock 254 202 278 minecraft:light[level=15]
setblock 254 202 286 minecraft:light[level=15]
setblock 254 202 294 minecraft:light[level=15]
setblock 254 202 302 minecraft:light[level=15]
setblock 254 202 310 minecraft:light[level=15]
fill 256 202 306 257 203 307 minecraft:sandstone
setblock 259 202 278 minecraft:light[level=12]
setblock 259 202 285 minecraft:light[level=12]
setblock 259 202 292 minecraft:light[level=12]
setblock 259 202 299 minecraft:light[level=12]
setblock 259 202 306 minecraft:light[level=12]
setblock 259 202 313 minecraft:light[level=12]
setblock 262 202 278 minecraft:light[level=15]
setblock 262 202 286 minecraft:light[level=15]
setblock 262 202 294 minecraft:light[level=15]
setblock 262 202 302 minecraft:light[level=15]
setblock 262 202 310 minecraft:light[level=15]
setblock 266 202 278 minecraft:light[level=12]
setblock 266 202 285 minecraft:light[level=12]
setblock 266 202 292 minecraft:light[level=12]
setblock 266 202 299 minecraft:light[level=12]
setblock 266 202 306 minecraft:light[level=12]
setblock 266 202 313 minecraft:light[level=12]
setblock 270 202 278 minecraft:light[level=15]
setblock 270 202 286 minecraft:light[level=15]
setblock 270 202 294 minecraft:light[level=15]
setblock 270 202 302 minecraft:light[level=15]
setblock 270 202 310 minecraft:light[level=15]
setblock 273 202 278 minecraft:light[level=12]
setblock 273 202 285 minecraft:light[level=12]
setblock 273 202 292 minecraft:light[level=12]
setblock 273 202 299 minecraft:light[level=12]
setblock 273 202 306 minecraft:light[level=12]
setblock 273 202 313 minecraft:light[level=12]
fill 277 202 297 277 216 297 minecraft:sandstone
fill 277 202 300 277 216 300 minecraft:sandstone
setblock 277 202 309 minecraft:orange_terracotta
fill 277 202 315 277 216 315 minecraft:sandstone
fill 235 203 294 235 216 294 minecraft:sandstone
setblock 242 203 275 minecraft:blue_terracotta
setblock 277 203 291 minecraft:blue_terracotta
fill 277 203 309 277 216 309 minecraft:sandstone
fill 277 203 313 277 216 313 minecraft:sandstone
setblock 277 203 314 minecraft:black_terracotta
setblock 237 204 317 minecraft:orange_terracotta
fill 242 204 275 242 205 275 minecraft:sandstone
setblock 248 204 275 minecraft:blue_terracotta
setblock 269 204 275 minecraft:blue_terracotta
fill 277 204 291 277 216 291 minecraft:sandstone
fill 277 204 314 277 208 314 minecraft:sandstone
setblock 235 205 296 minecraft:black_terracotta
fill 237 205 317 237 216 317 minecraft:sandstone
fill 240 205 307 240 207 307 minecraft:shroomlight
fill 248 205 275 248 213 275 minecraft:sandstone
fill 269 205 275 269 216 275 minecraft:sandstone
fill 235 206 296 235 213 296 minecraft:sandstone
fill 235 206 306 235 216 306 minecraft:sandstone
setblock 235 206 307 minecraft:lapis_block
fill 235 206 308 235 216 308 minecraft:sandstone
setblock 235 206 314 minecraft:lapis_block
setblock 242 206 275 minecraft:black_terracotta
setblock 258 206 317 minecraft:orange_terracotta
fill 259 206 317 259 216 317 minecraft:sandstone
fill 266 206 275 267 216 275 minecraft:sandstone
setblock 268 206 275 minecraft:lapis_block
setblock 277 206 286 minecraft:blue_terracotta
fill 235 207 307 235 214 307 minecraft:sandstone
fill 235 207 314 235 213 314 minecraft:sandstone
fill 242 207 275 242 216 275 minecraft:sandstone
setblock 245 207 275 minecraft:orange_terracotta
fill 258 207 317 258 210 317 minecraft:sandstone
fill 268 207 275 268 216 275 minecraft:sandstone
setblock 277 207 283 minecraft:blue_terracotta
fill 277 207 286 277 216 286 minecraft:sandstone
setblock 235 208 282 minecraft:black_terracotta
fill 235 208 283 235 209 283 minecraft:sandstone
setblock 238 208 278 minecraft:light[level=12]
setblock 238 208 285 minecraft:light[level=12]
setblock 238 208 292 minecraft:light[level=12]
setblock 238 208 299 minecraft:light[level=12]
setblock 238 208 306 minecraft:light[level=12]
setblock 238 208 313 minecraft:light[level=12]
fill 245 208 275 245 214 275 minecraft:sandstone
setblock 245 208 278 minecraft:light[level=12]
setblock 245 208 285 minecraft:light[level=12]
setblock 245 208 292 minecraft:light[level=12]
setblock 245 208 299 minecraft:light[level=12]
setblock 245 208 306 minecraft:light[level=12]
setblock 245 208 313 minecraft:light[level=12]
setblock 252 208 278 minecraft:light[level=12]
setblock 252 208 285 minecraft:light[level=12]
setblock 252 208 292 minecraft:light[level=12]
setblock 252 208 299 minecraft:light[level=12]
setblock 252 208 306 minecraft:light[level=12]
setblock 252 208 313 minecraft:light[level=12]
setblock 254 208 277 minecraft:shroomlight
setblock 259 208 278 minecraft:light[level=12]
setblock 259 208 285 minecraft:light[level=12]
setblock 259 208 292 minecraft:light[level=12]
setblock 259 208 306 minecraft:light[level=12]
setblock 259 208 313 minecraft:light[level=12]
setblock 266 208 278 minecraft:light[level=12]
setblock 266 208 285 minecraft:light[level=12]
setblock 266 208 292 minecraft:light[level=12]
setblock 266 208 299 minecraft:light[level=12]
setblock 266 208 306 minecraft:light[level=12]
setblock 266 208 313 minecraft:light[level=12]
fill 270 208 275 270 212 275 minecraft:sandstone
setblock 271 208 275 minecraft:lapis_block
setblock 273 208 278 minecraft:light[level=12]
setblock 273 208 285 minecraft:light[level=12]
setblock 273 208 292 minecraft:light[level=12]
setblock 273 208 299 minecraft:light[level=12]
setblock 273 208 306 minecraft:light[level=12]
setblock 273 208 313 minecraft:light[level=12]
fill 277 208 277 277 216 277 minecraft:sandstone
setblock 277 208 278 minecraft:blue_terracotta
fill 277 208 283 277 211 283 minecraft:sandstone
fill 235 209 282 235 217 282 minecraft:sandstone
fill 236 209 276 255 209 316 minecraft:gold_block
setblock 254 209 317 minecraft:black_terracotta
fill 256 209 276 256 209 295 minecraft:gold_block
fill 256 209 297 256 209 316 minecraft:gold_block
fill 257 209 276 258 209 293 minecraft:gold_block
fill 257 209 299 258 209 316 minecraft:gold_block
fill 259 209 276 276 209 292 minecraft:gold_block
fill 259 209 300 276 209 316 minecraft:gold_block
fill 260 209 293 276 209 293 minecraft:gold_block
fill 260 209 299 276 209 299 minecraft:gold_block
fill 262 209 294 276 209 295 minecraft:gold_block
fill 262 209 297 276 209 298 minecraft:gold_block
fill 263 209 296 276 209 296 minecraft:gold_block
fill 271 209 275 271 216 275 minecraft:sandstone
fill 277 209 278 277 214 278 minecraft:sandstone
setblock 277 209 280 minecraft:black_terracotta
setblock 277 209 310 minecraft:lapis_block
setblock 277 209 314 minecraft:blue_terracotta
setblock 235 210 283 minecraft:lapis_block
fill 236 210 276 276 210 277 minecraft:gold_block
fill 236 210 278 276 210 278 minecraft:lapis_block
fill 236 210 279 276 210 280 minecraft:gold_block
fill 236 210 281 276 210 281 minecraft:lapis_block
fill 236 210 282 276 210 283 minecraft:gold_block
fill 236 210 284 276 210 284 minecraft:lapis_block
fill 236 210 285 276 210 286 minecraft:gold_block
fill 236 210 287 276 210 287 minecraft:lapis_block
fill 236 210 288 276 210 289 minecraft:gold_block
fill 236 210 290 276 210 290 minecraft:lapis_block
fill 236 210 291 255 210 292 minecraft:gold_block
fill 236 210 293 254 210 293 minecraft:lapis_block
fill 236 210 294 253 210 295 minecraft:gold_block
fill 236 210 296 253 210 296 minecraft:lapis_block
fill 236 210 297 253 210 298 minecraft:gold_block
fill 236 210 299 254 210 299 minecraft:lapis_block
fill 236 210 300 255 210 301 minecraft:gold_block
fill 236 210 302 276 210 302 minecraft:lapis_block
fill 236 210 303 276 210 304 minecraft:gold_block
fill 236 210 305 276 210 305 minecraft:lapis_block
fill 236 210 306 276 210 307 minecraft:gold_block
fill 236 210 308 276 210 308 minecraft:lapis_block
fill 236 210 309 276 210 310 minecraft:gold_block
fill 236 210 311 276 210 311 minecraft:lapis_block
fill 236 210 312 276 210 313 minecraft:gold_block
fill 236 210 314 276 210 314 minecraft:lapis_block
fill 236 210 315 276 210 316 minecraft:gold_block
setblock 250 210 317 minecraft:blue_terracotta
fill 254 210 294 255 210 298 minecraft:black_concrete
setblock 254 210 317 minecraft:blue_terracotta
fill 255 210 293 256 210 293 minecraft:black_concrete
fill 255 210 299 256 210 299 minecraft:black_concrete
setblock 256 210 291 minecraft:gold_block
fill 256 210 292 262 210 292 minecraft:black_concrete
fill 256 210 294 256 210 295 minecraft:sea_lantern
fill 256 210 297 256 210 298 minecraft:sea_lantern
fill 256 210 300 262 210 300 minecraft:black_concrete
setblock 256 210 301 minecraft:gold_block
fill 257 210 291 261 210 291 minecraft:black_concrete
fill 257 210 293 258 210 293 minecraft:sea_lantern
fill 257 210 299 258 210 299 minecraft:sea_lantern
fill 257 210 301 261 210 301 minecraft:black_concrete
setblock 259 210 275 minecraft:lapis_block
fill 260 210 293 261 210 293 minecraft:sea_lantern
fill 260 210 299 261 210 299 minecraft:sea_lantern
fill 262 210 291 276 210 291 minecraft:gold_block
fill 262 210 293 263 210 293 minecraft:black_concrete
fill 262 210 294 262 210 295 minecraft:sea_lantern
fill 262 210 297 262 210 298 minecraft:sea_lantern
fill 262 210 299 263 210 299 minecraft:black_concrete
fill 262 210 301 276 210 301 minecraft:gold_block
fill 263 210 292 276 210 292 minecraft:gold_block
fill 263 210 294 264 210 298 minecraft:black_concrete
fill 263 210 300 276 210 300 minecraft:gold_block
fill 264 210 293 276 210 293 minecraft:lapis_block
fill 264 210 299 276 210 299 minecraft:lapis_block
fill 265 210 294 276 210 295 minecraft:gold_block
fill 265 210 296 276 210 296 minecraft:lapis_block
fill 265 210 297 276 210 298 minecraft:gold_block
fill 277 210 280 277 212 280 minecraft:sandstone
fill 277 210 310 277 214 310 minecraft:sandstone
fill 277 210 314 277 212 314 minecraft:sandstone
fill 235 211 283 235 213 283 minecraft:sandstone
setblock 235 211 312 minecraft:blue_terracotta
setblock 245 211 317 minecraft:orange_terracotta
fill 247 211 284 255 212 308 minecraft:prismarine_bricks
fill 250 211 317 250 214 317 minecraft:sandstone
fill 254 211 317 254 216 317 minecraft:sandstone
fill 256 211 284 256 211 294 minecraft:prismarine_bricks
fill 256 211 298 256 211 308 minecraft:prismarine_bricks
fill 257 211 284 257 211 293 minecraft:prismarine_bricks
fill 257 211 299 257 211 308 minecraft:prismarine_bricks
fill 258 211 284 271 212 292 minecraft:prismarine_bricks
fill 258 211 300 271 212 308 minecraft:prismarine_bricks
setblock 258 211 317 minecraft:black_terracotta
fill 259 211 275 259 214 275 minecraft:sandstone
fill 261 211 293 271 211 293 minecraft:prismarine_bricks
fill 261 211 299 271 211 299 minecraft:prismarine_bricks
fill 262 211 294 271 211 294 minecraft:prismarine_bricks
fill 262 211 298 271 211 298 minecraft:prismarine_bricks
fill 263 211 295 271 212 297 minecraft:prismarine_bricks
setblock 235 212 303 minecraft:blue_terracotta
fill 235 212 312 235 217 312 minecraft:sandstone
fill 245 212 317 245 216 317 minecraft:sandstone
fill 256 212 284 256 212 293 minecraft:prismarine_bricks
fill 256 212 299 256 212 308 minecraft:prismarine_bricks
fill 257 212 284 257 212 292 minecraft:prismarine_bricks
fill 257 212 300 257 212 308 minecraft:prismarine_bricks
fill 258 212 317 258 216 317 minecraft:sandstone
fill 262 212 293 271 212 293 minecraft:prismarine_bricks
fill 262 212 299 271 212 299 minecraft:prismarine_bricks
fill 263 212 294 271 212 294 minecraft:prismarine_bricks
fill 263 212 298 271 212 298 minecraft:prismarine_bricks
setblock 264 212 275 minecraft:orange_terracotta
setblock 277 212 283 minecraft:blue_terracotta
setblock 235 213 280 minecraft:smooth_sandstone
setblock 235 213 284 minecraft:smooth_sandstone
setblock 235 213 287 minecraft:smooth_sandstone
setblock 235 213 289 minecraft:black_terracotta
setblock 235 213 297 minecraft:smooth_sandstone
fill 235 213 298 235 214 298 minecraft:sandstone
fill 235 213 303 235 216 303 minecraft:sandstone
fill 240 213 317 242 213 317 minecraft:smooth_sandstone
fill 243 213 317 244 216 317 minecraft:sandstone
fill 248 213 285 248 214 285 minecraft:sea_lantern
fill 248 213 307 248 214 307 minecraft:sea_lantern
fill 249 213 286 255 214 306 minecraft:dark_prismarine
setblock 253 213 275 minecraft:smooth_sandstone
setblock 255 213 317 minecraft:smooth_sandstone
fill 256 213 286 256 214 293 minecraft:dark_prismarine
fill 256 213 299 256 214 306 minecraft:dark_prismarine
fill 257 213 286 269 214 292 minecraft:dark_prismarine
fill 257 213 300 269 214 306 minecraft:dark_prismarine
setblock 258 213 275 minecraft:smooth_sandstone
fill 260 213 317 260 214 317 minecraft:smooth_sandstone
fill 261 213 317 261 216 317 minecraft:sandstone
setblock 262 213 275 minecraft:blue_terracotta
fill 262 213 293 269 214 293 minecraft:dark_prismarine
fill 262 213 299 269 214 299 minecraft:dark_prismarine
fill 263 213 294 269 214 298 minecraft:dark_prismarine
fill 264 213 275 264 217 275 minecraft:sandstone
setblock 268 213 317 minecraft:smooth_sandstone
setblock 270 213 275 minecraft:smooth_sandstone
fill 270 213 285 270 214 285 minecraft:sea_lantern
fill 270 213 307 270 214 307 minecraft:sea_lantern
fill 277 213 280 277 213 281 minecraft:smooth_sandstone
setblock 277 213 283 minecraft:smooth_sandstone
fill 277 213 289 277 214 289 minecraft:smooth_sandstone
fill 277 213 293 277 216 293 minecraft:sandstone
setblock 277 213 294 minecraft:black_terracotta
setblock 277 213 295 minecraft:sandstone
setblock 277 213 304 minecraft:smooth_sandstone
setblock 277 213 312 minecraft:smooth_sandstone
setblock 277 213 314 minecraft:smooth_sandstone
setblock 277 213 316 minecraft:sandstone
setblock 277 213 317 minecraft:smooth_sandstone
fill 235 214 280 235 216 280 minecraft:sandstone
setblock 235 214 283 minecraft:smooth_sandstone
fill 235 214 284 235 216 284 minecraft:sandstone
fill 235 214 287 235 216 287 minecraft:sandstone
fill 235 214 289 235 216 289 minecraft:sandstone
fill 235 214 296 235 215 296 minecraft:smooth_sandstone
fill 235 214 297 235 216 297 minecraft:sandstone
setblock 235 214 310 minecraft:smooth_sandstone
setblock 235 214 313 minecraft:smooth_sandstone
setblock 235 214 314 minecraft:orange_terracotta
setblock 235 214 317 minecraft:smooth_sandstone
fill 236 214 276 238 270 276 minecraft:cut_sandstone
fill 236 214 286 236 270 288 minecraft:cut_sandstone
fill 236 214 298 236 270 300 minecraft:cut_sandstone
fill 236 214 310 236 270 312 minecraft:cut_sandstone
setblock 238 214 278 minecraft:light[level=12]
setblock 238 214 285 minecraft:light[level=12]
setblock 238 214 292 minecraft:light[level=12]
setblock 238 214 299 minecraft:light[level=12]
setblock 238 214 306 minecraft:light[level=12]
setblock 238 214 313 minecraft:light[level=12]
setblock 239 214 275 minecraft:smooth_sandstone
fill 239 214 279 239 214 282 minecraft:chiseled_sandstone
setblock 240 214 278 minecraft:chiseled_sandstone
fill 240 214 279 253 227 281 minecraft:cut_sandstone
fill 240 214 282 242 214 282 minecraft:chiseled_sandstone
fill 240 214 317 241 216 317 minecraft:sandstone
fill 241 214 276 253 224 278 minecraft:cut_sandstone
fill 242 214 316 244 270 316 minecraft:cut_sandstone
setblock 242 214 317 minecraft:smooth_sandstone
setblock 245 214 285 minecraft:light[level=12]
setblock 245 214 292 minecraft:light[level=12]
setblock 245 214 299 minecraft:light[level=12]
setblock 245 214 306 minecraft:light[level=12]
setblock 245 214 313 minecraft:light[level=12]
setblock 246 214 317 minecraft:smooth_sandstone
fill 247 214 275 248 214 275 minecraft:smooth_sandstone
setblock 249 214 317 minecraft:smooth_sandstone
setblock 252 214 285 minecraft:light[level=12]
setblock 252 214 313 minecraft:light[level=12]
fill 253 214 275 253 216 275 minecraft:sandstone
fill 254 214 316 256 270 316 minecraft:cut_sandstone
fill 255 214 317 255 215 317 minecraft:sandstone
fill 258 214 275 258 217 275 minecraft:sandstone
setblock 259 214 278 minecraft:light[level=12]
setblock 259 214 285 minecraft:light[level=12]
setblock 259 214 313 minecraft:light[level=12]
fill 260 214 276 262 270 276 minecraft:cut_sandstone
fill 262 214 275 262 216 275 minecraft:sandstone
setblock 263 214 275 minecraft:smooth_sandstone
setblock 266 214 278 minecraft:light[level=12]
setblock 266 214 285 minecraft:light[level=12]
setblock 266 214 313 minecraft:light[level=12]
fill 266 214 316 268 270 316 minecraft:cut_sandstone
setblock 266 214 317 minecraft:smooth_sandstone
fill 267 214 317 268 216 317 minecraft:sandstone
fill 270 214 275 270 216 275 minecraft:sandstone
fill 270 214 311 270 214 312 minecraft:chiseled_sandstone
setblock 271 214 310 minecraft:chiseled_sandstone
fill 271 214 311 274 227 312 minecraft:cut_sandstone
setblock 271 214 313 minecraft:chiseled_sandstone
fill 272 214 275 273 216 275 minecraft:sandstone
fill 272 214 276 274 270 276 minecraft:cut_sandstone
setblock 272 214 309 minecraft:chiseled_sandstone
fill 272 214 310 273 227 310 minecraft:cut_sandstone
fill 272 214 313 273 227 313 minecraft:cut_sandstone
fill 272 214 314 273 214 314 minecraft:chiseled_sandstone
setblock 273 214 278 minecraft:light[level=12]
setblock 273 214 285 minecraft:light[level=12]
setblock 273 214 292 minecraft:light[level=12]
setblock 273 214 299 minecraft:light[level=12]
setblock 273 214 306 minecraft:light[level=12]
fill 274 214 275 275 214 275 minecraft:smooth_sandstone
setblock 274 214 310 minecraft:chiseled_sandstone
setblock 274 214 313 minecraft:chiseled_sandstone
setblock 274 214 317 minecraft:smooth_sandstone
fill 276 214 284 276 270 286 minecraft:cut_sandstone
fill 276 214 296 276 270 298 minecraft:cut_sandstone
fill 276 214 308 276 270 310 minecraft:cut_sandstone
fill 277 214 280 277 216 281 minecraft:sandstone
fill 277 214 283 277 216 283 minecraft:sandstone
setblock 277 214 287 minecraft:smooth_sandstone
fill 277 214 294 277 216 294 minecraft:sandstone
setblock 277 214 295 minecraft:smooth_sandstone
fill 277 214 302 277 215 302 minecraft:smooth_sandstone
fill 277 214 304 277 216 304 minecraft:sandstone
setblock 277 214 307 minecraft:smooth_sandstone
fill 277 214 312 277 216 312 minecraft:sandstone
fill 277 214 314 277 216 314 minecraft:sandstone
setblock 277 214 316 minecraft:smooth_sandstone
fill 277 214 317 277 216 317 minecraft:sandstone
fill 235 215 283 235 216 283 minecraft:sandstone
setblock 235 215 298 minecraft:smooth_sandstone
setblock 235 215 299 minecraft:orange_terracotta
setblock 235 215 305 minecraft:smooth_sandstone
setblock 235 215 307 minecraft:smooth_sandstone
fill 235 215 310 235 216 310 minecraft:sandstone
fill 235 215 313 235 216 314 minecraft:sandstone
setblock 235 215 315 minecraft:orange_terracotta
fill 235 215 317 235 216 317 minecraft:sandstone
fill 239 215 275 239 216 275 minecraft:sandstone
setblock 239 215 317 minecraft:smooth_sandstone
fill 242 215 317 242 216 317 minecraft:sandstone
setblock 243 215 275 minecraft:smooth_sandstone
setblock 245 215 275 minecraft:smooth_sandstone
fill 246 215 317 246 216 317 minecraft:sandstone
fill 247 215 275 248 216 275 minecraft:sandstone
fill 249 215 317 249 216 317 minecraft:sandstone
setblock 250 215 317 minecraft:smooth_sandstone
fill 251 215 288 254 216 304 minecraft:prismarine_bricks
fill 255 215 288 255 216 294 minecraft:prismarine_bricks
fill 255 215 298 255 216 304 minecraft:prismarine_bricks
fill 256 215 288 256 215 293 minecraft:prismarine_bricks
fill 256 215 299 256 215 304 minecraft:prismarine_bricks
fill 257 215 288 257 216 292 minecraft:prismarine_bricks
fill 257 215 300 257 216 304 minecraft:prismarine_bricks
fill 258 215 288 267 216 291 minecraft:prismarine_bricks
fill 258 215 301 267 216 304 minecraft:prismarine_bricks
setblock 259 215 275 minecraft:smooth_sandstone
fill 260 215 317 260 216 317 minecraft:sandstone
fill 261 215 292 267 216 292 minecraft:prismarine_bricks
fill 261 215 300 267 216 300 minecraft:prismarine_bricks
fill 262 215 293 267 215 293 minecraft:prismarine_bricks
fill 262 215 299 267 215 299 minecraft:prismarine_bricks
fill 263 215 275 263 216 275 minecraft:sandstone
fill 263 215 294 267 216 294 minecraft:prismarine_bricks
fill 263 215 298 267 216 298 minecraft:prismarine_bricks
fill 264 215 295 267 216 297 minecraft:prismarine_bricks
fill 266 215 317 266 216 317 minecraft:sandstone
setblock 270 215 317 minecraft:smooth_sandstone
fill 274 215 275 275 216 275 minecraft:sandstone
fill 274 215 317 274 216 317 minecraft:sandstone
fill 277 215 278 277 215 279 minecraft:smooth_sandstone
fill 277 215 287 277 216 287 minecraft:sandstone
setblock 277 215 288 minecraft:smooth_sandstone
fill 277 215 289 277 216 289 minecraft:sandstone
fill 277 215 295 277 216 295 minecraft:sandstone
setblock 277 215 296 minecraft:smooth_sandstone
setblock 277 215 301 minecraft:smooth_sandstone
fill 277 215 307 277 216 307 minecraft:sandstone
setblock 277 215 310 minecraft:orange_terracotta
fill 277 215 316 277 217 316 minecraft:sandstone
setblock 235 216 296 minecraft:sandstone
setblock 235 216 298 minecraft:black_terracotta
setblock 235 216 299 minecraft:sandstone
setblock 235 216 305 minecraft:sandstone
setblock 235 216 307 minecraft:sandstone
setblock 235 216 315 minecraft:sandstone
fill 239 216 317 239 217 317 minecraft:sandstone
setblock 243 216 275 minecraft:sandstone
setblock 245 216 275 minecraft:sandstone
setblock 250 216 317 minecraft:sandstone
setblock 251 216 275 minecraft:blue_terracotta
setblock 255 216 317 minecraft:blue_terracotta
fill 256 216 288 256 216 292 minecraft:prismarine_bricks
fill 256 216 300 256 216 304 minecraft:prismarine_bricks
setblock 259 216 275 minecraft:sandstone
fill 263 216 293 267 216 293 minecraft:prismarine_bricks
fill 263 216 299 267 216 299 minecraft:prismarine_bricks
setblock 270 216 317 minecraft:sandstone
fill 277 216 278 277 216 279 minecraft:sandstone
setblock 277 216 288 minecraft:sandstone
setblock 277 216 296 minecraft:sandstone
fill 277 216 301 277 216 302 minecraft:sandstone
setblock 277 216 310 minecraft:sandstone
fill 235 217 276 235 225 281 minecraft:smooth_sandstone
fill 235 217 283 235 218 311 minecraft:smooth_sandstone
fill 235 217 313 235 225 317 minecraft:smooth_sandstone
fill 236 217 317 238 225 317 minecraft:smooth_sandstone
fill 237 217 275 239 217 275 minecraft:smooth_sandstone
fill 240 217 317 243 242 317 minecraft:smooth_sandstone
fill 241 217 275 243 225 275 minecraft:smooth_sandstone
setblock 244 217 317 minecraft:sandstone
fill 245 217 275 253 218 275 minecraft:smooth_sandstone
fill 245 217 317 246 237 317 minecraft:smooth_sandstone
fill 248 217 317 259 217 317 minecraft:smooth_sandstone
fill 253 217 290 254 218 302 minecraft:dark_prismarine
fill 255 217 275 257 218 275 minecraft:smooth_sandstone
fill 255 217 290 255 217 294 minecraft:dark_prismarine
fill 255 217 298 255 217 302 minecraft:dark_prismarine
fill 256 217 290 257 217 292 minecraft:dark_prismarine
fill 256 217 300 257 217 302 minecraft:dark_prismarine
fill 258 217 290 265 218 291 minecraft:dark_prismarine
fill 258 217 301 265 218 302 minecraft:dark_prismarine
fill 259 217 275 263 217 275 minecraft:smooth_sandstone
setblock 260 217 317 minecraft:blue_terracotta
fill 261 217 292 265 217 292 minecraft:dark_prismarine
fill 261 217 300 265 217 300 minecraft:dark_prismarine
setblock 261 217 317 minecraft:smooth_sandstone
fill 263 217 293 265 217 294 minecraft:dark_prismarine
fill 263 217 298 265 217 299 minecraft:dark_prismarine
fill 264 217 295 265 218 297 minecraft:dark_prismarine
fill 264 217 317 267 217 317 minecraft:smooth_sandstone
fill 265 217 275 271 217 275 minecraft:smooth_sandstone
setblock 268 217 317 minecraft:sandstone
fill 270 217 317 274 218 317 minecraft:smooth_sandstone
setblock 272 217 275 minecraft:sandstone
fill 273 217 275 277 217 275 minecraft:smooth_sandstone
fill 276 217 317 277 218 317 minecraft:smooth_sandstone
fill 277 217 276 277 217 280 minecraft:smooth_sandstone
setblock 277 217 281 minecraft:sandstone
fill 277 217 282 277 218 283 minecraft:smooth_sandstone
fill 277 217 285 277 217 307 minecraft:smooth_sandstone
setblock 277 217 308 minecraft:lapis_block
fill 277 217 309 277 221 313 minecraft:smooth_sandstone
setblock 277 217 314 minecraft:black_terracotta
fill 277 217 315 277 225 315 minecraft:smooth_sandstone
fill 235 218 275 236 308 275 minecraft:smooth_sandstone
fill 235 218 282 235 223 282 minecraft:smooth_sandstone
fill 235 218 312 235 256 312 minecraft:smooth_sandstone
setblock 237 218 275 minecraft:sandstone
fill 238 218 275 240 237 275 minecraft:smooth_sandstone
setblock 238 218 278 minecraft:light[level=15]
setblock 238 218 286 minecraft:light[level=15]
setblock 238 218 294 minecraft:light[level=15]
setblock 238 218 302 minecraft:light[level=15]
setblock 238 218 310 minecraft:light[level=15]
fill 239 218 317 239 224 317 minecraft:smooth_sandstone
fill 244 218 275 244 225 275 minecraft:smooth_sandstone
fill 244 218 317 244 227 317 minecraft:smooth_sandstone
setblock 246 218 286 minecraft:light[level=15]
setblock 246 218 294 minecraft:light[level=15]
setblock 246 218 302 minecraft:light[level=15]
setblock 246 218 310 minecraft:light[level=15]
fill 247 218 317 249 225 317 minecraft:smooth_sandstone
setblock 250 218 317 minecraft:sandstone
fill 251 218 317 260 225 317 minecraft:smooth_sandstone
fill 254 218 275 254 225 275 minecraft:smooth_sandstone
setblock 254 218 278 minecraft:light[level=15]
setblock 254 218 286 minecraft:light[level=15]
setblock 254 218 310 minecraft:light[level=15]
fill 255 218 290 255 218 293 minecraft:dark_prismarine
fill 255 218 299 255 218 302 minecraft:dark_prismarine
fill 256 218 290 256 218 292 minecraft:dark_prismarine
fill 256 218 300 256 218 302 minecraft:dark_prismarine
fill 257 218 290 257 218 291 minecraft:dark_prismarine
fill 257 218 301 257 218 302 minecraft:dark_prismarine
fill 258 218 275 258 308 275 minecraft:smooth_sandstone
setblock 259 218 275 minecraft:sandstone
fill 260 218 275 265 218 275 minecraft:smooth_sandstone
setblock 261 218 317 minecraft:sandstone
setblock 262 218 278 minecraft:light[level=15]
setblock 262 218 286 minecraft:light[level=15]
fill 262 218 292 265 218 292 minecraft:dark_prismarine
fill 262 218 300 265 218 300 minecraft:dark_prismarine
setblock 262 218 310 minecraft:light[level=15]
fill 263 218 293 265 218 293 minecraft:dark_prismarine
fill 263 218 299 265 218 299 minecraft:dark_prismarine
fill 263 218 317 263 308 317 minecraft:smooth_sandstone
fill 264 218 294 265 218 294 minecraft:dark_prismarine
fill 264 218 298 265 218 298 minecraft:dark_prismarine
fill 264 218 317 264 219 317 minecraft:sandstone
fill 265 218 317 268 219 317 minecraft:smooth_sandstone
setblock 266 218 275 minecraft:sandstone
fill 267 218 275 274 224 275 minecraft:smooth_sandstone
setblock 270 218 278 minecraft:light[level=15]
setblock 270 218 286 minecraft:light[level=15]
setblock 270 218 294 minecraft:light[level=15]
setblock 270 218 302 minecraft:light[level=15]
setblock 270 218 310 minecraft:light[level=15]
setblock 275 218 275 minecraft:blue_terracotta
fill 275 218 317 275 231 317 minecraft:smooth_sandstone
fill 276 218 275 277 308 275 minecraft:smooth_sandstone
fill 277 218 276 277 218 277 minecraft:smooth_sandstone
setblock 277 218 278 minecraft:sandstone
fill 277 218 279 277 225 281 minecraft:smooth_sandstone
fill 277 218 284 277 218 294 minecraft:smooth_sandstone
setblock 277 218 295 minecraft:sandstone
fill 277 218 296 277 270 299 minecraft:smooth_sandstone
setblock 277 218 300 minecraft:sandstone
fill 277 218 301 277 218 307 minecraft:smooth_sandstone
setblock 277 218 308 minecraft:sandstone
fill 277 218 314 277 225 314 minecraft:smooth_sandstone
fill 277 218 316 277 251 316 minecraft:smooth_sandstone
fill 235 219 283 235 225 288 minecraft:smooth_sandstone
setblock 235 219 289 minecraft:sandstone
fill 235 219 290 235 225 296 minecraft:smooth_sandstone
setblock 235 219 297 minecraft:sandstone
fill 235 219 298 235 221 303 minecraft:smooth_sandstone
setblock 235 219 304 minecraft:sandstone
fill 235 219 305 235 225 311 minecraft:smooth_sandstone
fill 237 219 275 237 252 275 minecraft:smooth_sandstone
fill 241 219 299 242 220 300 minecraft:smooth_sandstone
fill 245 219 275 246 225 275 minecraft:smooth_sandstone
setblock 247 219 275 minecraft:sandstone
fill 248 219 275 252 221 275 minecraft:smooth_sandstone
fill 250 219 317 250 225 317 minecraft:smooth_sandstone
setblock 253 219 275 minecraft:sandstone
setblock 255 219 275 minecraft:sandstone
fill 255 219 292 255 220 293 minecraft:prismarine_bricks
fill 255 219 299 255 220 300 minecraft:prismarine_bricks
fill 256 219 275 257 225 275 minecraft:smooth_sandstone
fill 256 219 292 256 220 292 minecraft:prismarine_bricks
fill 256 219 300 256 220 300 minecraft:prismarine_bricks
fill 259 219 275 260 223 275 minecraft:smooth_sandstone
setblock 261 219 275 minecraft:sandstone
fill 261 219 317 262 225 317 minecraft:smooth_sandstone
fill 262 219 275 262 237 275 minecraft:smooth_sandstone
fill 262 219 292 263 220 292 minecraft:prismarine_bricks
fill 262 219 300 263 220 300 minecraft:prismarine_bricks
setblock 263 219 275 minecraft:black_terracotta
fill 263 219 293 263 220 293 minecraft:prismarine_bricks
fill 263 219 299 263 220 299 minecraft:prismarine_bricks
setblock 264 219 275 minecraft:sandstone
fill 265 219 275 266 225 275 minecraft:smooth_sandstone
setblock 270 219 317 minecraft:sandstone
fill 271 219 317 274 223 317 minecraft:smooth_sandstone
fill 275 219 275 275 274 275 minecraft:smooth_sandstone
fill 276 219 317 276 245 317 minecraft:smooth_sandstone
setblock 277 219 276 minecraft:sandstone
fill 277 219 277 277 223 278 minecraft:smooth_sandstone
setblock 277 219 282 minecraft:sandstone
fill 277 219 283 277 219 291 minecraft:smooth_sandstone
setblock 277 219 292 minecraft:black_terracotta
fill 277 219 293 277 267 295 minecraft:smooth_sandstone
fill 277 219 300 277 219 306 minecraft:smooth_sandstone
setblock 277 219 307 minecraft:blue_terracotta
fill 277 219 308 277 227 308 minecraft:smooth_sandstone
setblock 277 219 317 minecraft:sandstone
fill 235 220 289 235 231 289 minecraft:smooth_sandstone
fill 235 220 297 235 242 297 minecraft:smooth_sandstone
fill 235 220 304 235 229 304 minecraft:smooth_sandstone
fill 237 220 285 237 225 287 minecraft:cut_sandstone
fill 237 220 297 237 225 299 minecraft:cut_sandstone
fill 237 220 309 237 225 311 minecraft:cut_sandstone
setblock 238 220 278 minecraft:light[level=12]
setblock 238 220 285 minecraft:light[level=12]
setblock 238 220 292 minecraft:light[level=12]
setblock 238 220 299 minecraft:light[level=12]
setblock 238 220 306 minecraft:light[level=12]
setblock 238 220 313 minecraft:light[level=12]
fill 243 220 315 245 225 315 minecraft:cut_sandstone
setblock 245 220 285 minecraft:light[level=12]
setblock 245 220 292 minecraft:light[level=12]
setblock 245 220 299 minecraft:light[level=12]
setblock 245 220 306 minecraft:light[level=12]
setblock 245 220 313 minecraft:light[level=12]
fill 247 220 275 247 308 275 minecraft:smooth_sandstone
setblock 252 220 285 minecraft:light[level=12]
setblock 252 220 292 minecraft:light[level=12]
setblock 252 220 299 minecraft:light[level=12]
setblock 252 220 306 minecraft:light[level=12]
setblock 252 220 313 minecraft:light[level=12]
fill 253 220 275 253 305 275 minecraft:smooth_sandstone
fill 254 220 281 254 222 281 minecraft:shroomlight
fill 255 220 275 255 225 275 minecraft:smooth_sandstone
fill 255 220 315 257 225 315 minecraft:cut_sandstone
fill 259 220 277 261 225 277 minecraft:cut_sandstone
setblock 259 220 278 minecraft:light[level=12]
setblock 259 220 285 minecraft:light[level=12]
setblock 259 220 306 minecraft:light[level=12]
setblock 259 220 313 minecraft:light[level=12]
fill 261 220 275 261 240 275 minecraft:smooth_sandstone
fill 263 220 275 264 220 275 minecraft:smooth_sandstone
fill 264 220 317 266 227 317 minecraft:smooth_sandstone
setblock 266 220 278 minecraft:light[level=12]
setblock 266 220 285 minecraft:light[level=12]
setblock 266 220 292 minecraft:light[level=12]
setblock 266 220 299 minecraft:light[level=12]
setblock 266 220 306 minecraft:light[level=12]
setblock 266 220 313 minecraft:light[level=12]
fill 267 220 315 269 225 315 minecraft:cut_sandstone
setblock 267 220 317 minecraft:lapis_block
fill 268 220 317 270 237 317 minecraft:smooth_sandstone
fill 271 220 277 273 225 277 minecraft:cut_sandstone
setblock 273 220 278 minecraft:light[level=12]
setblock 273 220 285 minecraft:light[level=12]
setblock 273 220 292 minecraft:light[level=12]
setblock 273 220 299 minecraft:light[level=12]
setblock 273 220 306 minecraft:light[level=12]
fill 275 220 285 275 225 287 minecraft:cut_sandstone
fill 275 220 297 275 225 299 minecraft:cut_sandstone
fill 275 220 309 275 225 311 minecraft:cut_sandstone
fill 277 220 276 277 225 276 minecraft:smooth_sandstone
fill 277 220 282 277 246 282 minecraft:smooth_sandstone
setblock 277 220 283 minecraft:black_terracotta
fill 277 220 284 277 220 292 minecraft:smooth_sandstone
fill 277 220 300 277 225 300 minecraft:smooth_sandstone
setblock 277 220 301 minecraft:lapis_block
fill 277 220 302 277 225 307 minecraft:smooth_sandstone
fill 277 220 317 277 308 317 minecraft:smooth_sandstone
setblock 263 221 275 minecraft:blue_terracotta
fill 264 221 275 264 248 275 minecraft:smooth_sandstone
fill 267 221 317 267 293 317 minecraft:smooth_sandstone
fill 277 221 283 277 230 287 minecraft:smooth_sandstone
setblock 277 221 288 minecraft:lapis_block
fill 277 221 289 277 225 292 minecraft:smooth_sandstone
fill 277 221 301 277 225 301 minecraft:smooth_sandstone
fill 235 222 298 235 249 301 minecraft:smooth_sandstone
setblock 235 222 302 minecraft:black_terracotta
fill 235 222 303 235 308 303 minecraft:smooth_sandstone
fill 239 222 279 239 222 282 minecraft:chiseled_sandstone
fill 239 222 289 239 223 289 minecraft:chiseled_sandstone
fill 239 222 312 239 223 312 minecraft:chiseled_sandstone
setblock 240 222 278 minecraft:chiseled_sandstone
fill 240 222 282 242 222 282 minecraft:chiseled_sandstone
setblock 248 222 275 minecraft:blue_terracotta
fill 249 222 275 252 224 275 minecraft:smooth_sandstone
fill 253 222 312 253 223 312 minecraft:chiseled_sandstone
fill 263 222 275 263 236 275 minecraft:smooth_sandstone
fill 265 222 279 265 223 279 minecraft:chiseled_sandstone
fill 270 222 311 270 222 312 minecraft:chiseled_sandstone
setblock 271 222 310 minecraft:chiseled_sandstone
setblock 271 222 313 minecraft:chiseled_sandstone
fill 272 222 299 272 223 299 minecraft:chiseled_sandstone
setblock 272 222 309 minecraft:chiseled_sandstone
fill 272 222 314 273 222 314 minecraft:chiseled_sandstone
setblock 274 222 310 minecraft:chiseled_sandstone
setblock 274 222 313 minecraft:chiseled_sandstone
fill 277 222 288 277 225 288 minecraft:smooth_sandstone
fill 277 222 309 277 225 312 minecraft:smooth_sandstone
setblock 277 222 313 minecraft:blue_terracotta
fill 235 223 302 235 301 302 minecraft:smooth_sandstone
fill 238 223 282 239 223 282 minecraft:chiseled_sandstone
fill 238 223 289 238 224 289 minecraft:chiseled_sandstone
fill 238 223 312 238 224 312 minecraft:chiseled_sandstone
fill 248 223 275 248 270 275 minecraft:smooth_sandstone
fill 253 223 313 253 224 313 minecraft:chiseled_sandstone
fill 265 223 278 265 224 278 minecraft:chiseled_sandstone
fill 273 223 299 273 224 299 minecraft:chiseled_sandstone
setblock 277 223 313 minecraft:lapis_block
setblock 235 224 282 minecraft:lapis_block
fill 237 224 282 238 224 282 minecraft:chiseled_sandstone
fill 237 224 289 237 225 289 minecraft:chiseled_sandstone
fill 237 224 312 237 225 312 minecraft:chiseled_sandstone
fill 253 224 314 253 225 314 minecraft:chiseled_sandstone
setblock 259 224 275 minecraft:lapis_block
fill 260 224 275 260 252 275 minecraft:smooth_sandstone
fill 265 224 277 265 225 277 minecraft:chiseled_sandstone
fill 271 224 317 273 225 317 minecraft:smooth_sandstone
fill 274 224 299 274 225 299 minecraft:chiseled_sandstone
setblock 274 224 317 minecraft:orange_terracotta
setblock 277 224 277 minecraft:blue_terracotta
fill 277 224 278 277 225 278 minecraft:smooth_sandstone
fill 277 224 313 277 225 313 minecraft:smooth_sandstone
setblock 235 225 282 minecraft:smooth_sandstone
fill 236 225 279 236 225 284 minecraft:chiseled_sandstone
fill 236 225 289 236 226 289 minecraft:chiseled_sandstone
fill 236 225 291 236 225 296 minecraft:chiseled_sandstone
fill 236 225 303 236 225 308 minecraft:chiseled_sandstone
fill 236 225 315 236 225 316 minecraft:chiseled_sandstone
setblock 237 225 282 minecraft:chiseled_sandstone
fill 237 225 316 240 225 316 minecraft:chiseled_sandstone
setblock 239 225 317 minecraft:blue_terracotta
fill 240 225 276 245 225 276 minecraft:chiseled_sandstone
fill 241 225 277 253 235 278 minecraft:cut_sandstone
fill 246 225 276 251 235 276 minecraft:cut_sandstone
fill 247 225 316 252 225 316 minecraft:chiseled_sandstone
fill 249 225 275 250 266 275 minecraft:smooth_sandstone
setblock 251 225 275 minecraft:orange_terracotta
fill 252 225 275 252 268 275 minecraft:smooth_sandstone
fill 252 225 276 257 225 276 minecraft:chiseled_sandstone
fill 253 225 315 253 226 315 minecraft:chiseled_sandstone
fill 259 225 275 259 239 275 minecraft:smooth_sandstone
fill 259 225 316 264 225 316 minecraft:chiseled_sandstone
fill 264 225 276 269 225 276 minecraft:chiseled_sandstone
fill 267 225 275 272 225 275 minecraft:smooth_sandstone
fill 271 225 316 276 225 316 minecraft:chiseled_sandstone
setblock 273 225 275 minecraft:lapis_block
fill 274 225 275 274 308 275 minecraft:smooth_sandstone
setblock 274 225 317 minecraft:smooth_sandstone
fill 276 225 276 276 225 281 minecraft:chiseled_sandstone
fill 276 225 288 276 225 293 minecraft:chiseled_sandstone
fill 276 225 300 276 225 305 minecraft:chiseled_sandstone
fill 276 225 312 276 225 315 minecraft:chiseled_sandstone
setblock 277 225 277 minecraft:smooth_sandstone
fill 235 226 276 235 245 280 minecraft:smooth_sandstone
fill 235 226 281 235 231 284 minecraft:glowstone
fill 235 226 285 235 231 288 minecraft:smooth_sandstone
fill 235 226 290 235 243 292 minecraft:smooth_sandstone
fill 235 226 293 235 231 296 minecraft:glowstone
fill 235 226 305 235 231 308 minecraft:glowstone
fill 235 226 309 235 308 311 minecraft:smooth_sandstone
fill 235 226 313 235 231 316 minecraft:smooth_sandstone
fill 235 226 317 238 231 317 minecraft:glowstone
setblock 236 226 282 minecraft:chiseled_sandstone
setblock 238 226 278 minecraft:light[level=15]
setblock 238 226 285 minecraft:light[level=12]
setblock 238 226 286 minecraft:light[level=15]
setblock 238 226 292 minecraft:light[level=12]
setblock 238 226 294 minecraft:light[level=15]
setblock 238 226 299 minecraft:light[level=12]
setblock 238 226 302 minecraft:light[level=15]
setblock 238 226 306 minecraft:light[level=12]
setblock 238 226 310 minecraft:light[level=15]
setblock 238 226 313 minecraft:light[level=12]
setblock 239 226 283 minecraft:glowstone
setblock 239 226 289 minecraft:glowstone
setblock 239 226 295 minecraft:glowstone
setblock 239 226 301 minecraft:glowstone
setblock 239 226 307 minecraft:glowstone
setblock 239 226 313 minecraft:glowstone
fill 239 226 317 239 237 317 minecraft:smooth_sandstone
fill 241 226 275 241 308 275 minecraft:smooth_sandstone
fill 241 226 276 245 235 276 minecraft:cut_sandstone
fill 242 226 275 245 231 275 minecraft:glowstone
setblock 245 226 285 minecraft:light[level=12]
setblock 245 226 292 minecraft:light[level=12]
setblock 245 226 299 minecraft:light[level=12]
setblock 245 226 306 minecraft:light[level=12]
setblock 245 226 313 minecraft:glowstone
fill 246 226 275 246 240 275 minecraft:smooth_sandstone
setblock 246 226 286 minecraft:light[level=15]
setblock 246 226 294 minecraft:light[level=15]
setblock 246 226 302 minecraft:light[level=15]
setblock 246 226 310 minecraft:light[level=15]
fill 247 226 317 250 231 317 minecraft:glowstone
fill 251 226 275 251 308 275 minecraft:smooth_sandstone
setblock 251 226 313 minecraft:glowstone
fill 251 226 317 258 231 317 minecraft:smooth_sandstone
fill 252 226 276 253 235 276 minecraft:cut_sandstone
setblock 252 226 285 minecraft:light[level=12]
setblock 252 226 292 minecraft:light[level=12]
setblock 252 226 299 minecraft:light[level=12]
setblock 252 226 306 minecraft:light[level=12]
setblock 252 226 313 minecraft:light[level=12]
fill 254 226 275 257 231 275 minecraft:glowstone
setblock 254 226 278 minecraft:light[level=15]
setblock 254 226 286 minecraft:light[level=15]
setblock 254 226 294 minecraft:light[level=15]
setblock 254 226 302 minecraft:light[level=15]
setblock 254 226 310 minecraft:light[level=15]
setblock 255 226 279 minecraft:glowstone
setblock 257 226 313 minecraft:glowstone
setblock 259 226 278 minecraft:light[level=12]
setblock 259 226 285 minecraft:light[level=12]
setblock 259 226 292 minecraft:light[level=12]
setblock 259 226 299 minecraft:light[level=12]
setblock 259 226 306 minecraft:light[level=12]
setblock 259 226 313 minecraft:light[level=12]
fill 259 226 317 262 231 317 minecraft:glowstone
setblock 261 226 279 minecraft:glowstone
setblock 262 226 278 minecraft:light[level=15]
setblock 262 226 286 minecraft:light[level=15]
setblock 262 226 294 minecraft:light[level=15]
setblock 262 226 302 minecraft:light[level=15]
setblock 262 226 310 minecraft:light[level=15]
setblock 263 226 313 minecraft:glowstone
fill 265 226 275 265 272 275 minecraft:smooth_sandstone
setblock 265 226 276 minecraft:chiseled_sandstone
fill 266 226 275 269 231 275 minecraft:glowstone
setblock 266 226 278 minecraft:light[level=12]
setblock 266 226 285 minecraft:light[level=12]
setblock 266 226 292 minecraft:light[level=12]
setblock 266 226 299 minecraft:light[level=12]
setblock 266 226 306 minecraft:light[level=12]
setblock 266 226 313 minecraft:light[level=12]
setblock 267 226 279 minecraft:glowstone
setblock 269 226 313 minecraft:glowstone
fill 270 226 275 273 229 275 minecraft:smooth_sandstone
setblock 270 226 278 minecraft:light[level=15]
setblock 270 226 286 minecraft:light[level=15]
setblock 270 226 294 minecraft:light[level=15]
setblock 270 226 302 minecraft:light[level=15]
setblock 270 226 310 minecraft:light[level=15]
fill 271 226 317 274 231 317 minecraft:glowstone
setblock 273 226 278 minecraft:light[level=12]
setblock 273 226 279 minecraft:glowstone
setblock 273 226 285 minecraft:glowstone
setblock 273 226 291 minecraft:glowstone
setblock 273 226 292 minecraft:light[level=12]
setblock 273 226 297 minecraft:glowstone
setblock 273 226 299 minecraft:light[level=12]
setblock 273 226 303 minecraft:glowstone
setblock 273 226 306 minecraft:light[level=12]
setblock 273 226 309 minecraft:glowstone
setblock 275 226 299 minecraft:chiseled_sandstone
fill 277 226 276 277 231 279 minecraft:glowstone
fill 277 226 280 277 268 281 minecraft:smooth_sandstone
fill 277 226 288 277 231 291 minecraft:glowstone
fill 277 226 292 277 308 292 minecraft:smooth_sandstone
fill 277 226 300 277 231 303 minecraft:glowstone
fill 277 226 304 277 227 307 minecraft:smooth_sandstone
fill 277 226 309 277 308 309 minecraft:smooth_sandstone
setblock 277 226 310 minecraft:lapis_block
fill 277 226 311 277 268 311 minecraft:smooth_sandstone
fill 277 226 312 277 231 315 minecraft:glowstone
fill 236 227 277 239 227 285 minecraft:cut_sandstone
fill 236 227 289 239 227 297 minecraft:cut_sandstone
fill 236 227 301 239 227 309 minecraft:cut_sandstone
fill 236 227 313 241 227 316 minecraft:cut_sandstone
fill 237 227 286 239 227 288 minecraft:cut_sandstone
fill 237 227 298 239 227 300 minecraft:cut_sandstone
fill 237 227 310 239 227 312 minecraft:cut_sandstone
fill 239 227 276 240 227 276 minecraft:cut_sandstone
fill 240 227 277 240 227 278 minecraft:cut_sandstone
fill 242 227 313 271 227 315 minecraft:cut_sandstone
fill 245 227 316 253 227 316 minecraft:cut_sandstone
fill 254 227 276 259 227 279 minecraft:cut_sandstone
fill 257 227 316 265 227 316 minecraft:cut_sandstone
fill 260 227 277 276 227 279 minecraft:cut_sandstone
fill 263 227 276 271 227 276 minecraft:cut_sandstone
fill 269 227 316 276 227 316 minecraft:cut_sandstone
fill 272 227 314 276 227 315 minecraft:cut_sandstone
fill 273 227 280 275 227 309 minecraft:cut_sandstone
fill 274 227 310 275 227 310 minecraft:cut_sandstone
fill 274 227 313 276 227 313 minecraft:cut_sandstone
fill 275 227 276 276 227 276 minecraft:cut_sandstone
fill 275 227 311 276 227 312 minecraft:cut_sandstone
fill 276 227 280 276 227 283 minecraft:cut_sandstone
fill 276 227 287 276 227 295 minecraft:cut_sandstone
fill 276 227 299 276 227 307 minecraft:cut_sandstone
fill 277 227 310 277 232 310 minecraft:smooth_sandstone
setblock 238 228 302 minecraft:sandstone
fill 239 228 279 239 228 313 minecraft:lapis_block
setblock 240 228 279 minecraft:lapis_block
fill 240 228 280 253 235 281 minecraft:cut_sandstone
fill 240 228 313 273 228 313 minecraft:lapis_block
fill 241 228 279 253 235 279 minecraft:cut_sandstone
setblock 244 228 317 minecraft:black_terracotta
fill 254 228 279 273 228 279 minecraft:lapis_block
fill 264 228 317 264 308 317 minecraft:smooth_sandstone
setblock 265 228 317 minecraft:black_terracotta
fill 266 228 317 266 308 317 minecraft:smooth_sandstone
fill 271 228 311 272 270 312 minecraft:cut_sandstone
fill 272 228 310 272 270 310 minecraft:cut_sandstone
fill 273 228 280 273 228 312 minecraft:lapis_block
fill 274 228 311 274 270 312 minecraft:cut_sandstone
setblock 277 228 304 minecraft:blue_terracotta
fill 277 228 305 277 234 307 minecraft:smooth_sandstone
setblock 277 228 308 minecraft:blue_terracotta
fill 240 229 279 240 270 279 minecraft:cut_sandstone
fill 244 229 317 244 233 317 minecraft:smooth_sandstone
fill 265 229 317 265 308 317 minecraft:smooth_sandstone
fill 272 229 313 273 270 313 minecraft:cut_sandstone
fill 273 229 310 273 270 312 minecraft:cut_sandstone
fill 277 229 304 277 255 304 minecraft:smooth_sandstone
fill 277 229 308 277 285 308 minecraft:smooth_sandstone
setblock 235 230 304 minecraft:black_terracotta
fill 239 230 279 239 230 282 minecraft:chiseled_sandstone
setblock 240 230 278 minecraft:chiseled_sandstone
fill 240 230 282 242 230 282 minecraft:chiseled_sandstone
fill 270 230 275 270 258 275 minecraft:smooth_sandstone
fill 270 230 311 270 230 312 minecraft:chiseled_sandstone
setblock 271 230 275 minecraft:blue_terracotta
setblock 271 230 310 minecraft:chiseled_sandstone
setblock 271 230 313 minecraft:chiseled_sandstone
fill 272 230 275 273 289 275 minecraft:smooth_sandstone
setblock 272 230 309 minecraft:chiseled_sandstone
fill 272 230 314 273 230 314 minecraft:chiseled_sandstone
setblock 274 230 310 minecraft:chiseled_sandstone
setblock 274 230 313 minecraft:chiseled_sandstone
fill 235 231 304 235 308 304 minecraft:smooth_sandstone
fill 271 231 275 271 251 275 minecraft:smooth_sandstone
setblock 277 231 283 minecraft:orange_terracotta
fill 277 231 284 277 295 287 minecraft:smooth_sandstone
fill 235 232 281 235 245 281 minecraft:smooth_sandstone
fill 235 232 282 235 232 283 minecraft:glowstone
fill 235 232 284 235 240 287 minecraft:smooth_sandstone
setblock 235 232 288 minecraft:black_terracotta
setblock 235 232 289 minecraft:orange_terracotta
fill 235 232 293 235 242 293 minecraft:smooth_sandstone
fill 235 232 294 235 232 295 minecraft:glowstone
fill 235 232 296 235 245 296 minecraft:smooth_sandstone
fill 235 232 305 235 245 305 minecraft:smooth_sandstone
fill 235 232 306 235 232 307 minecraft:glowstone
fill 235 232 308 235 245 308 minecraft:smooth_sandstone
fill 235 232 313 235 242 314 minecraft:smooth_sandstone
setblock 235 232 315 minecraft:orange_terracotta
fill 235 232 316 235 245 317 minecraft:smooth_sandstone
fill 236 232 317 237 232 317 minecraft:glowstone
setblock 238 232 278 minecraft:light[level=12]
setblock 238 232 285 minecraft:light[level=12]
setblock 238 232 292 minecraft:light[level=12]
setblock 238 232 299 minecraft:light[level=12]
setblock 238 232 306 minecraft:light[level=12]
setblock 238 232 313 minecraft:light[level=12]
fill 238 232 317 238 245 317 minecraft:smooth_sandstone
fill 242 232 275 242 237 275 minecraft:smooth_sandstone
fill 243 232 275 244 232 275 minecraft:glowstone
fill 245 232 275 245 245 275 minecraft:smooth_sandstone
setblock 245 232 285 minecraft:light[level=12]
setblock 245 232 292 minecraft:light[level=12]
setblock 245 232 299 minecraft:light[level=12]
setblock 245 232 306 minecraft:light[level=12]
setblock 245 232 313 minecraft:light[level=12]
fill 247 232 317 247 245 317 minecraft:smooth_sandstone
fill 248 232 317 249 232 317 minecraft:glowstone
fill 250 232 317 256 238 317 minecraft:smooth_sandstone
setblock 252 232 285 minecraft:light[level=12]
setblock 252 232 292 minecraft:light[level=12]
setblock 252 232 299 minecraft:light[level=12]
setblock 252 232 306 minecraft:light[level=12]
setblock 252 232 313 minecraft:light[level=12]
fill 254 232 275 254 245 275 minecraft:smooth_sandstone
fill 255 232 275 256 232 275 minecraft:glowstone
fill 257 232 275 257 233 275 minecraft:smooth_sandstone
setblock 257 232 317 minecraft:lapis_block
fill 258 232 317 259 238 317 minecraft:smooth_sandstone
setblock 259 232 278 minecraft:light[level=12]
setblock 259 232 285 minecraft:light[level=12]
setblock 259 232 292 minecraft:light[level=12]
setblock 259 232 299 minecraft:light[level=12]
setblock 259 232 306 minecraft:light[level=12]
setblock 259 232 313 minecraft:light[level=12]
fill 260 232 317 261 232 317 minecraft:glowstone
fill 262 232 317 262 245 317 minecraft:smooth_sandstone
fill 266 232 275 266 245 275 minecraft:smooth_sandstone
setblock 266 232 278 minecraft:light[level=12]
setblock 266 232 285 minecraft:light[level=12]
setblock 266 232 292 minecraft:light[level=12]
setblock 266 232 299 minecraft:light[level=12]
setblock 266 232 306 minecraft:light[level=12]
setblock 266 232 313 minecraft:light[level=12]
fill 267 232 275 268 232 275 minecraft:glowstone
fill 269 232 275 269 245 275 minecraft:smooth_sandstone
fill 271 232 317 271 245 317 minecraft:smooth_sandstone
fill 272 232 317 273 232 317 minecraft:glowstone
setblock 273 232 278 minecraft:light[level=12]
setblock 273 232 285 minecraft:light[level=12]
setblock 273 232 292 minecraft:light[level=12]
setblock 273 232 299 minecraft:light[level=12]
setblock 273 232 306 minecraft:light[level=12]
fill 274 232 317 274 245 317 minecraft:smooth_sandstone
setblock 275 232 317 minecraft:black_terracotta
fill 277 232 276 277 245 276 minecraft:smooth_sandstone
fill 277 232 277 277 232 278 minecraft:glowstone
fill 277 232 279 277 245 279 minecraft:smooth_sandstone
fill 277 232 283 277 234 283 minecraft:smooth_sandstone
fill 277 232 288 277 245 288 minecraft:smooth_sandstone
fill 277 232 289 277 232 290 minecraft:glowstone
fill 277 232 291 277 245 291 minecraft:smooth_sandstone
fill 277 232 300 277 245 300 minecraft:smooth_sandstone
fill 277 232 301 277 232 302 minecraft:glowstone
fill 277 232 303 277 245 303 minecraft:smooth_sandstone
fill 277 232 312 277 238 312 minecraft:smooth_sandstone
fill 277 232 313 277 232 314 minecraft:glowstone
fill 277 232 315 277 245 315 minecraft:smooth_sandstone
fill 235 233 282 235 245 283 minecraft:smooth_sandstone
fill 235 233 288 235 292 289 minecraft:smooth_sandstone
fill 235 233 294 235 245 295 minecraft:smooth_sandstone
fill 235 233 306 235 241 307 minecraft:smooth_sandstone
fill 235 233 315 235 308 315 minecraft:smooth_sandstone
fill 236 233 317 237 241 317 minecraft:smooth_sandstone
fill 243 233 275 244 245 275 minecraft:smooth_sandstone
fill 248 233 317 249 245 317 minecraft:smooth_sandstone
fill 255 233 275 256 236 275 minecraft:smooth_sandstone
fill 257 233 317 257 269 317 minecraft:smooth_sandstone
setblock 260 233 317 minecraft:lapis_block
fill 261 233 317 261 245 317 minecraft:smooth_sandstone
fill 267 233 275 268 241 275 minecraft:smooth_sandstone
fill 272 233 317 273 244 317 minecraft:smooth_sandstone
fill 275 233 317 275 238 317 minecraft:smooth_sandstone
fill 277 233 277 277 243 278 minecraft:smooth_sandstone
fill 277 233 289 277 245 290 minecraft:smooth_sandstone
fill 277 233 301 277 245 302 minecraft:smooth_sandstone
setblock 277 233 310 minecraft:blue_terracotta
fill 277 233 313 277 245 314 minecraft:smooth_sandstone
setblock 238 234 278 minecraft:light[level=15]
setblock 238 234 286 minecraft:light[level=15]
setblock 238 234 294 minecraft:light[level=15]
setblock 238 234 302 minecraft:light[level=15]
setblock 238 234 310 minecraft:light[level=15]
setblock 244 234 317 minecraft:black_terracotta
setblock 246 234 286 minecraft:light[level=15]
setblock 246 234 294 minecraft:light[level=15]
setblock 246 234 302 minecraft:light[level=15]
setblock 246 234 310 minecraft:light[level=15]
setblock 254 234 278 minecraft:light[level=15]
setblock 254 234 286 minecraft:light[level=15]
setblock 254 234 294 minecraft:light[level=15]
setblock 254 234 302 minecraft:light[level=15]
setblock 254 234 310 minecraft:light[level=15]
setblock 257 234 275 minecraft:orange_terracotta
fill 260 234 317 260 245 317 minecraft:smooth_sandstone
setblock 262 234 278 minecraft:light[level=15]
setblock 262 234 286 minecraft:light[level=15]
setblock 262 234 294 minecraft:light[level=15]
setblock 262 234 302 minecraft:light[level=15]
setblock 262 234 310 minecraft:light[level=15]
setblock 270 234 278 minecraft:light[level=15]
setblock 270 234 286 minecraft:light[level=15]
setblock 270 234 294 minecraft:light[level=15]
setblock 270 234 302 minecraft:light[level=15]
setblock 270 234 310 minecraft:light[level=15]
fill 277 234 310 277 293 310 minecraft:smooth_sandstone
fill 244 235 317 244 301 317 minecraft:smooth_sandstone
fill 257 235 275 257 241 275 minecraft:smooth_sandstone
setblock 277 235 283 minecraft:lapis_block
fill 277 235 305 277 271 306 minecraft:smooth_sandstone
setblock 277 235 307 minecraft:lapis_block
fill 240 236 280 241 270 281 minecraft:cut_sandstone
fill 241 236 279 241 270 279 minecraft:cut_sandstone
fill 242 236 277 252 236 280 minecraft:lapis_block
fill 242 236 281 242 270 281 minecraft:cut_sandstone
fill 248 236 276 250 270 276 minecraft:cut_sandstone
fill 277 236 283 277 270 283 minecraft:smooth_sandstone
fill 277 236 307 277 237 307 minecraft:smooth_sandstone
fill 242 237 279 242 270 280 minecraft:cut_sandstone
fill 243 237 278 251 237 279 minecraft:lapis_block
fill 255 237 275 255 245 275 minecraft:smooth_sandstone
setblock 256 237 275 minecraft:orange_terracotta
setblock 263 237 275 minecraft:lapis_block
fill 238 238 275 239 308 275 minecraft:smooth_sandstone
setblock 238 238 278 minecraft:light[level=12]
setblock 238 238 285 minecraft:light[level=12]
setblock 238 238 292 minecraft:light[level=12]
setblock 238 238 299 minecraft:light[level=12]
setblock 238 238 306 minecraft:light[level=12]
setblock 238 238 313 minecraft:light[level=12]
fill 239 238 279 239 238 282 minecraft:chiseled_sandstone
setblock 239 238 317 minecraft:orange_terracotta
setblock 240 238 275 minecraft:orange_terracotta
fill 240 238 278 242 238 278 minecraft:chiseled_sandstone
fill 240 238 282 242 238 282 minecraft:chiseled_sandstone
setblock 242 238 275 minecraft:lapis_block
fill 243 238 279 243 238 281 minecraft:chiseled_sandstone
fill 244 238 278 250 238 279 minecraft:lapis_block
setblock 245 238 285 minecraft:light[level=12]
setblock 245 238 292 minecraft:light[level=12]
setblock 245 238 299 minecraft:light[level=12]
setblock 245 238 306 minecraft:light[level=12]
setblock 245 238 313 minecraft:light[level=12]
fill 245 238 317 245 308 317 minecraft:smooth_sandstone
setblock 246 238 317 minecraft:blue_terracotta
setblock 252 238 278 minecraft:light[level=12]
setblock 252 238 285 minecraft:light[level=12]
setblock 252 238 292 minecraft:light[level=12]
setblock 252 238 299 minecraft:light[level=12]
setblock 252 238 306 minecraft:light[level=12]
setblock 252 238 313 minecraft:light[level=12]
fill 256 238 275 256 245 275 minecraft:smooth_sandstone
setblock 259 238 278 minecraft:light[level=12]
setblock 259 238 285 minecraft:light[level=12]
setblock 259 238 292 minecraft:light[level=12]
setblock 259 238 299 minecraft:light[level=12]
setblock 259 238 306 minecraft:light[level=12]
setblock 259 238 313 minecraft:light[level=12]
setblock 262 238 275 minecraft:lapis_block
fill 263 238 275 263 300 275 minecraft:smooth_sandstone
setblock 266 238 278 minecraft:light[level=12]
setblock 266 238 285 minecraft:light[level=12]
setblock 266 238 292 minecraft:light[level=12]
setblock 266 238 299 minecraft:light[level=12]
setblock 266 238 306 minecraft:light[level=12]
setblock 266 238 313 minecraft:light[level=12]
fill 268 238 317 268 280 317 minecraft:smooth_sandstone
setblock 269 238 317 minecraft:black_terracotta
fill 270 238 311 270 238 312 minecraft:chiseled_sandstone
fill 270 238 317 270 244 317 minecraft:smooth_sandstone
setblock 271 238 310 minecraft:chiseled_sandstone
setblock 271 238 313 minecraft:chiseled_sandstone
setblock 272 238 309 minecraft:chiseled_sandstone
fill 272 238 314 273 238 314 minecraft:chiseled_sandstone
setblock 273 238 278 minecraft:light[level=12]
setblock 273 238 285 minecraft:light[level=12]
setblock 273 238 292 minecraft:light[level=12]
setblock 273 238 299 minecraft:light[level=12]
setblock 273 238 306 minecraft:light[level=12]
setblock 274 238 310 minecraft:chiseled_sandstone
setblock 274 238 313 minecraft:chiseled_sandstone
setblock 277 238 307 minecraft:lapis_block
fill 239 239 317 239 247 317 minecraft:smooth_sandstone
fill 240 239 275 240 257 275 minecraft:smooth_sandstone
fill 242 239 275 242 245 275 minecraft:smooth_sandstone
fill 245 239 277 249 239 280 minecraft:lapis_block
fill 246 239 317 246 308 317 minecraft:smooth_sandstone
fill 250 239 317 254 245 317 minecraft:smooth_sandstone
setblock 255 239 317 minecraft:orange_terracotta
fill 256 239 317 256 305 317 minecraft:smooth_sandstone
setblock 258 239 317 minecraft:orange_terracotta
fill 259 239 317 259 245 317 minecraft:smooth_sandstone
fill 262 239 275 262 248 275 minecraft:smooth_sandstone
fill 269 239 317 269 308 317 minecraft:smooth_sandstone
setblock 275 239 317 minecraft:orange_terracotta
fill 277 239 307 277 280 307 minecraft:smooth_sandstone
setblock 277 239 312 minecraft:lapis_block
fill 237 240 285 237 245 287 minecraft:cut_sandstone
fill 237 240 297 237 245 299 minecraft:cut_sandstone
fill 237 240 309 237 245 311 minecraft:cut_sandstone
fill 243 240 315 245 245 315 minecraft:cut_sandstone
fill 247 240 277 249 245 277 minecraft:cut_sandstone
fill 255 240 315 257 245 315 minecraft:cut_sandstone
fill 255 240 317 255 295 317 minecraft:smooth_sandstone
fill 258 240 317 258 308 317 minecraft:smooth_sandstone
setblock 259 240 275 minecraft:orange_terracotta
fill 259 240 277 261 245 277 minecraft:cut_sandstone
fill 267 240 315 269 245 315 minecraft:cut_sandstone
fill 271 240 277 273 245 277 minecraft:cut_sandstone
fill 275 240 285 275 245 287 minecraft:cut_sandstone
fill 275 240 297 275 245 299 minecraft:cut_sandstone
fill 275 240 309 275 245 311 minecraft:cut_sandstone
fill 275 240 317 275 308 317 minecraft:smooth_sandstone
fill 277 240 312 277 245 312 minecraft:smooth_sandstone
fill 235 241 284 235 243 286 minecraft:smooth_sandstone
setblock 235 241 287 minecraft:orange_terracotta
setblock 246 241 275 minecraft:lapis_block
fill 259 241 275 259 308 275 minecraft:smooth_sandstone
setblock 261 241 275 minecraft:black_terracotta
fill 235 242 287 235 245 287 minecraft:smooth_sandstone
fill 235 242 306 235 245 306 minecraft:smooth_sandstone
setblock 235 242 307 minecraft:blue_terracotta
fill 236 242 317 236 245 317 minecraft:smooth_sandstone
setblock 237 242 317 minecraft:lapis_block
setblock 238 242 278 minecraft:light[level=15]
setblock 238 242 286 minecraft:light[level=15]
setblock 238 242 294 minecraft:light[level=15]
setblock 238 242 302 minecraft:light[level=15]
setblock 238 242 310 minecraft:light[level=15]
fill 246 242 275 246 302 275 minecraft:smooth_sandstone
setblock 246 242 278 minecraft:light[level=15]
setblock 246 242 286 minecraft:light[level=15]
setblock 246 242 294 minecraft:light[level=15]
setblock 246 242 302 minecraft:light[level=15]
setblock 246 242 310 minecraft:light[level=15]
setblock 254 242 278 minecraft:light[level=15]
setblock 254 242 286 minecraft:light[level=15]
setblock 254 242 294 minecraft:light[level=15]
setblock 254 242 302 minecraft:light[level=15]
setblock 254 242 310 minecraft:light[level=15]
setblock 257 242 275 minecraft:black_terracotta
fill 261 242 275 261 308 275 minecraft:smooth_sandstone
setblock 262 242 278 minecraft:light[level=15]
setblock 262 242 286 minecraft:light[level=15]
setblock 262 242 294 minecraft:light[level=15]
setblock 262 242 302 minecraft:light[level=15]
setblock 262 242 310 minecraft:light[level=15]
setblock 267 242 275 minecraft:lapis_block
fill 268 242 275 268 245 275 minecraft:smooth_sandstone
setblock 270 242 278 minecraft:light[level=15]
setblock 270 242 286 minecraft:light[level=15]
setblock 270 242 294 minecraft:light[level=15]
setblock 270 242 302 minecraft:light[level=15]
setblock 270 242 310 minecraft:light[level=15]
setblock 235 243 293 minecraft:black_terracotta
setblock 235 243 297 minecraft:blue_terracotta
fill 235 243 307 235 245 307 minecraft:smooth_sandstone
setblock 235 243 313 minecraft:orange_terracotta
fill 235 243 314 235 308 314 minecraft:smooth_sandstone
fill 237 243 317 237 245 317 minecraft:smooth_sandstone
fill 240 243 317 241 257 317 minecraft:smooth_sandstone
setblock 242 243 317 minecraft:lapis_block
fill 243 243 317 243 249 317 minecraft:smooth_sandstone
fill 257 243 275 257 245 275 minecraft:smooth_sandstone
fill 267 243 275 267 245 275 minecraft:smooth_sandstone
fill 235 244 284 235 245 284 minecraft:smooth_sandstone
setblock 235 244 285 minecraft:black_terracotta
fill 235 244 286 235 254 286 minecraft:smooth_sandstone
fill 235 244 290 235 251 291 minecraft:smooth_sandstone
setblock 235 244 292 minecraft:blue_terracotta
fill 235 244 293 235 245 293 minecraft:smooth_sandstone
fill 235 244 297 235 280 297 minecraft:smooth_sandstone
fill 235 244 313 235 308 313 minecraft:smooth_sandstone
setblock 238 244 278 minecraft:light[level=12]
setblock 238 244 285 minecraft:light[level=12]
setblock 238 244 292 minecraft:light[level=12]
setblock 238 244 299 minecraft:light[level=12]
setblock 238 244 306 minecraft:light[level=12]
setblock 238 244 313 minecraft:light[level=12]
fill 242 244 317 242 305 317 minecraft:smooth_sandstone
setblock 245 244 278 minecraft:light[level=12]
setblock 245 244 285 minecraft:light[level=12]
setblock 245 244 292 minecraft:light[level=12]
setblock 245 244 299 minecraft:light[level=12]
setblock 245 244 306 minecraft:light[level=12]
setblock 245 244 313 minecraft:light[level=12]
setblock 252 244 278 minecraft:light[level=12]
setblock 252 244 285 minecraft:light[level=12]
setblock 252 244 292 minecraft:light[level=12]
setblock 252 244 299 minecraft:light[level=12]
setblock 252 244 306 minecraft:light[level=12]
setblock 252 244 313 minecraft:light[level=12]
setblock 259 244 278 minecraft:light[level=12]
setblock 259 244 285 minecraft:light[level=12]
setblock 259 244 292 minecraft:light[level=12]
setblock 259 244 299 minecraft:light[level=12]
setblock 259 244 306 minecraft:light[level=12]
setblock 259 244 313 minecraft:light[level=12]
setblock 266 244 278 minecraft:light[level=12]
setblock 266 244 285 minecraft:light[level=12]
setblock 266 244 292 minecraft:light[level=12]
setblock 266 244 299 minecraft:light[level=12]
setblock 266 244 306 minecraft:light[level=12]
setblock 266 244 313 minecraft:light[level=12]
setblock 273 244 278 minecraft:light[level=12]
setblock 273 244 285 minecraft:light[level=12]
setblock 273 244 292 minecraft:light[level=12]
setblock 273 244 299 minecraft:light[level=12]
setblock 273 244 306 minecraft:light[level=12]
fill 277 244 277 277 245 277 minecraft:smooth_sandstone
setblock 277 244 278 minecraft:lapis_block
fill 235 245 285 235 269 285 minecraft:smooth_sandstone
fill 235 245 292 235 260 292 minecraft:smooth_sandstone
fill 236 245 279 236 245 284 minecraft:chiseled_sandstone
fill 236 245 291 236 245 296 minecraft:chiseled_sandstone
fill 236 245 303 236 245 308 minecraft:chiseled_sandstone
fill 236 245 315 236 245 316 minecraft:chiseled_sandstone
fill 237 245 316 240 245 316 minecraft:chiseled_sandstone
fill 240 245 276 245 245 276 minecraft:chiseled_sandstone
fill 247 245 316 252 245 316 minecraft:chiseled_sandstone
fill 252 245 276 257 245 276 minecraft:chiseled_sandstone
fill 259 245 316 264 245 316 minecraft:chiseled_sandstone
fill 264 245 276 269 245 276 minecraft:chiseled_sandstone
setblock 270 245 317 minecraft:blue_terracotta
fill 271 245 316 276 245 316 minecraft:chiseled_sandstone
setblock 272 245 317 minecraft:blue_terracotta
setblock 273 245 317 minecraft:smooth_sandstone
setblock 274 245 310 minecraft:blue_wool
fill 276 245 276 276 245 281 minecraft:chiseled_sandstone
fill 276 245 288 276 245 293 minecraft:chiseled_sandstone
fill 276 245 300 276 245 305 minecraft:chiseled_sandstone
fill 276 245 312 276 245 315 minecraft:chiseled_sandstone
setblock 277 245 278 minecraft:smooth_sandstone
setblock 235 246 276 minecraft:lapis_block
fill 235 246 277 235 255 280 minecraft:smooth_sandstone
fill 235 246 281 235 251 284 minecraft:glowstone
setblock 235 246 287 minecraft:blue_terracotta
fill 235 246 293 235 251 296 minecraft:glowstone
fill 235 246 305 235 251 308 minecraft:glowstone
fill 235 246 316 235 247 316 minecraft:smooth_sandstone
fill 235 246 317 238 251 317 minecraft:glowstone
fill 239 246 279 239 246 282 minecraft:chiseled_sandstone
fill 240 246 278 242 246 278 minecraft:chiseled_sandstone
fill 240 246 282 242 246 282 minecraft:chiseled_sandstone
fill 242 246 275 245 251 275 minecraft:glowstone
fill 243 246 279 243 246 281 minecraft:chiseled_sandstone
fill 247 246 317 250 251 317 minecraft:glowstone
fill 251 246 317 254 264 317 minecraft:smooth_sandstone
fill 254 246 275 257 251 275 minecraft:glowstone
fill 259 246 317 262 251 317 minecraft:glowstone
fill 266 246 275 269 251 275 minecraft:glowstone
fill 270 246 311 270 246 312 minecraft:chiseled_sandstone
fill 270 246 317 270 273 317 minecraft:smooth_sandstone
setblock 271 246 310 minecraft:chiseled_sandstone
setblock 271 246 313 minecraft:chiseled_sandstone
fill 271 246 317 274 251 317 minecraft:glowstone
setblock 272 246 309 minecraft:chiseled_sandstone
fill 272 246 314 273 246 314 minecraft:chiseled_sandstone
fill 274 246 308 274 257 309 minecraft:blue_wool
setblock 274 246 310 minecraft:chiseled_sandstone
setblock 274 246 313 minecraft:chiseled_sandstone
setblock 276 246 317 minecraft:black_terracotta
fill 277 246 276 277 251 279 minecraft:glowstone
fill 277 246 288 277 251 291 minecraft:glowstone
fill 277 246 300 277 251 303 minecraft:glowstone
fill 277 246 312 277 251 315 minecraft:glowstone
fill 235 247 276 235 270 276 minecraft:smooth_sandstone
fill 235 247 287 235 308 287 minecraft:smooth_sandstone
fill 274 247 310 274 253 310 minecraft:blue_wool
fill 276 247 317 276 250 317 minecraft:smooth_sandstone
setblock 277 247 282 minecraft:black_terracotta
setblock 235 248 316 minecraft:black_terracotta
setblock 239 248 317 minecraft:lapis_block
fill 277 248 282 277 269 282 minecraft:smooth_sandstone
fill 235 249 316 235 308 316 minecraft:smooth_sandstone
fill 239 249 317 239 259 317 minecraft:smooth_sandstone
setblock 262 249 275 minecraft:black_terracotta
setblock 264 249 275 minecraft:black_terracotta
fill 235 250 298 235 296 299 minecraft:smooth_sandstone
setblock 235 250 300 minecraft:black_terracotta
fill 235 250 301 235 275 301 minecraft:smooth_sandstone
setblock 238 250 278 minecraft:light[level=15]
setblock 238 250 285 minecraft:light[level=12]
setblock 238 250 286 minecraft:light[level=15]
setblock 238 250 292 minecraft:light[level=12]
setblock 238 250 294 minecraft:light[level=15]
setblock 238 250 299 minecraft:light[level=12]
setblock 238 250 302 minecraft:light[level=15]
setblock 238 250 306 minecraft:light[level=12]
setblock 238 250 310 minecraft:light[level=15]
setblock 238 250 313 minecraft:light[level=12]
setblock 243 250 317 minecraft:orange_terracotta
setblock 245 250 278 minecraft:light[level=12]
setblock 245 250 285 minecraft:light[level=12]
setblock 245 250 292 minecraft:light[level=12]
setblock 245 250 299 minecraft:light[level=12]
setblock 245 250 306 minecraft:light[level=12]
setblock 245 250 313 minecraft:light[level=12]
setblock 246 250 278 minecraft:light[level=15]
setblock 246 250 286 minecraft:light[level=15]
setblock 246 250 294 minecraft:light[level=15]
setblock 246 250 302 minecraft:light[level=15]
setblock 246 250 310 minecraft:light[level=15]
setblock 252 250 278 minecraft:light[level=12]
setblock 252 250 285 minecraft:light[level=12]
setblock 252 250 292 minecraft:light[level=12]
setblock 252 250 299 minecraft:light[level=12]
setblock 252 250 306 minecraft:light[level=12]
setblock 252 250 313 minecraft:light[level=12]
setblock 254 250 278 minecraft:light[level=15]
setblock 254 250 286 minecraft:light[level=15]
setblock 254 250 294 minecraft:light[level=15]
setblock 254 250 302 minecraft:light[level=15]
setblock 254 250 310 minecraft:light[level=15]
setblock 259 250 278 minecraft:light[level=12]
setblock 259 250 285 minecraft:light[level=12]
setblock 259 250 292 minecraft:light[level=12]
setblock 259 250 299 minecraft:light[level=12]
setblock 259 250 306 minecraft:light[level=12]
setblock 259 250 313 minecraft:light[level=12]
fill 262 250 275 262 308 275 minecraft:smooth_sandstone
setblock 262 250 278 minecraft:light[level=15]
setblock 262 250 286 minecraft:light[level=15]
setblock 262 250 294 minecraft:light[level=15]
setblock 262 250 302 minecraft:light[level=15]
setblock 262 250 310 minecraft:light[level=15]
fill 264 250 275 264 297 275 minecraft:smooth_sandstone
setblock 266 250 278 minecraft:light[level=12]
setblock 266 250 285 minecraft:light[level=12]
setblock 266 250 292 minecraft:light[level=12]
setblock 266 250 299 minecraft:light[level=12]
setblock 266 250 306 minecraft:light[level=12]
setblock 266 250 313 minecraft:light[level=12]
fill 269 250 298 273 251 302 minecraft:chiseled_sandstone
setblock 270 250 278 minecraft:light[level=15]
setblock 270 250 286 minecraft:light[level=15]
setblock 270 250 294 minecraft:light[level=15]
setblock 270 250 310 minecraft:light[level=15]
setblock 273 250 278 minecraft:light[level=12]
setblock 273 250 285 minecraft:light[level=12]
setblock 273 250 292 minecraft:light[level=12]
setblock 273 250 306 minecraft:light[level=12]
fill 274 250 300 275 250 300 minecraft:chiseled_sandstone
fill 235 251 300 235 257 300 minecraft:smooth_sandstone
fill 243 251 317 243 261 317 minecraft:smooth_sandstone
setblock 276 251 317 minecraft:lapis_block
fill 235 252 281 235 265 281 minecraft:smooth_sandstone
fill 235 252 282 235 252 283 minecraft:glowstone
fill 235 252 284 235 256 284 minecraft:smooth_sandstone
fill 235 252 290 235 263 290 minecraft:smooth_sandstone
setblock 235 252 291 minecraft:lapis_block
fill 235 252 293 235 265 293 minecraft:smooth_sandstone
fill 235 252 294 235 252 295 minecraft:glowstone
fill 235 252 296 235 265 296 minecraft:smooth_sandstone
fill 235 252 305 235 265 305 minecraft:smooth_sandstone
fill 235 252 306 235 252 307 minecraft:glowstone
fill 235 252 308 235 265 308 minecraft:smooth_sandstone
fill 235 252 317 235 265 317 minecraft:smooth_sandstone
fill 236 252 317 237 252 317 minecraft:glowstone
fill 238 252 317 238 253 317 minecraft:smooth_sandstone
setblock 242 252 275 minecraft:black_terracotta
fill 243 252 275 244 252 275 minecraft:glowstone
fill 245 252 275 245 265 275 minecraft:smooth_sandstone
fill 247 252 317 247 265 317 minecraft:smooth_sandstone
fill 248 252 317 249 252 317 minecraft:glowstone
fill 250 252 317 250 265 317 minecraft:smooth_sandstone
fill 254 252 275 254 265 275 minecraft:smooth_sandstone
fill 255 252 275 256 252 275 minecraft:glowstone
fill 257 252 275 257 265 275 minecraft:smooth_sandstone
fill 259 252 317 259 265 317 minecraft:smooth_sandstone
fill 260 252 317 261 252 317 minecraft:glowstone
fill 262 252 317 262 265 317 minecraft:smooth_sandstone
fill 266 252 275 266 265 275 minecraft:smooth_sandstone
fill 267 252 275 268 252 275 minecraft:glowstone
fill 269 252 275 269 265 275 minecraft:smooth_sandstone
fill 270 252 299 272 253 301 minecraft:cut_sandstone
setblock 271 252 275 minecraft:lapis_block
fill 271 252 317 271 265 317 minecraft:smooth_sandstone
fill 272 252 317 273 252 317 minecraft:glowstone
fill 274 252 317 274 263 317 minecraft:smooth_sandstone
fill 276 252 317 276 308 317 minecraft:smooth_sandstone
fill 277 252 276 277 264 276 minecraft:smooth_sandstone
fill 277 252 277 277 252 278 minecraft:glowstone
fill 277 252 279 277 265 279 minecraft:smooth_sandstone
fill 277 252 288 277 265 288 minecraft:smooth_sandstone
fill 277 252 289 277 252 290 minecraft:glowstone
fill 277 252 291 277 265 291 minecraft:smooth_sandstone
fill 277 252 300 277 265 300 minecraft:smooth_sandstone
fill 277 252 301 277 252 302 minecraft:glowstone
fill 277 252 303 277 265 303 minecraft:smooth_sandstone
fill 277 252 312 277 265 312 minecraft:smooth_sandstone
fill 277 252 313 277 252 314 minecraft:glowstone
fill 277 252 315 277 265 315 minecraft:smooth_sandstone
setblock 277 252 316 minecraft:black_terracotta
fill 235 253 282 235 265 283 minecraft:smooth_sandstone
fill 235 253 291 235 308 291 minecraft:smooth_sandstone
fill 235 253 294 235 259 295 minecraft:smooth_sandstone
fill 235 253 306 235 265 307 minecraft:smooth_sandstone
fill 236 253 317 237 263 317 minecraft:smooth_sandstone
setblock 237 253 275 minecraft:orange_terracotta
fill 242 253 275 244 265 275 minecraft:smooth_sandstone
fill 248 253 317 249 265 317 minecraft:smooth_sandstone
fill 255 253 275 256 265 275 minecraft:smooth_sandstone
setblock 260 253 275 minecraft:lapis_block
fill 260 253 317 261 265 317 minecraft:smooth_sandstone
fill 267 253 275 268 265 275 minecraft:smooth_sandstone
fill 271 253 275 271 308 275 minecraft:smooth_sandstone
fill 272 253 317 273 265 317 minecraft:smooth_sandstone
fill 277 253 277 277 253 278 minecraft:smooth_sandstone
fill 277 253 289 277 256 290 minecraft:smooth_sandstone
fill 277 253 301 277 265 302 minecraft:smooth_sandstone
fill 277 253 313 277 265 314 minecraft:smooth_sandstone
fill 277 253 316 277 254 316 minecraft:smooth_sandstone
fill 237 254 275 237 263 275 minecraft:smooth_sandstone
setblock 238 254 317 minecraft:blue_terracotta
fill 239 254 279 239 254 282 minecraft:chiseled_sandstone
fill 240 254 278 242 254 278 minecraft:chiseled_sandstone
fill 240 254 282 242 254 282 minecraft:chiseled_sandstone
fill 243 254 279 243 254 281 minecraft:chiseled_sandstone
fill 260 254 275 260 274 275 minecraft:smooth_sandstone
fill 270 254 300 272 256 300 minecraft:cut_sandstone
fill 270 254 311 270 254 312 minecraft:chiseled_sandstone
fill 271 254 299 271 256 299 minecraft:cut_sandstone
fill 271 254 301 271 256 301 minecraft:cut_sandstone
setblock 271 254 310 minecraft:chiseled_sandstone
setblock 271 254 313 minecraft:chiseled_sandstone
setblock 272 254 309 minecraft:chiseled_sandstone
fill 272 254 314 273 254 314 minecraft:chiseled_sandstone
setblock 274 254 310 minecraft:chiseled_sandstone
setblock 274 254 313 minecraft:chiseled_sandstone
setblock 277 254 277 minecraft:lapis_block
fill 277 254 278 277 265 278 minecraft:smooth_sandstone
setblock 235 255 286 minecraft:lapis_block
fill 238 255 317 238 260 317 minecraft:smooth_sandstone
fill 274 255 310 274 257 310 minecraft:blue_wool
fill 277 255 277 277 264 277 minecraft:smooth_sandstone
setblock 277 255 316 minecraft:blue_terracotta
fill 235 256 277 235 282 278 minecraft:smooth_sandstone
fill 235 256 279 235 256 280 minecraft:orange_terracotta
fill 235 256 286 235 308 286 minecraft:smooth_sandstone
setblock 238 256 278 minecraft:light[level=12]
setblock 238 256 285 minecraft:light[level=12]
setblock 238 256 292 minecraft:light[level=12]
setblock 238 256 299 minecraft:light[level=12]
setblock 238 256 306 minecraft:light[level=12]
setblock 238 256 313 minecraft:light[level=12]
setblock 245 256 278 minecraft:light[level=12]
setblock 245 256 285 minecraft:light[level=12]
setblock 245 256 292 minecraft:light[level=12]
setblock 245 256 299 minecraft:light[level=12]
setblock 245 256 306 minecraft:light[level=12]
setblock 245 256 313 minecraft:light[level=12]
setblock 252 256 278 minecraft:light[level=12]
setblock 252 256 285 minecraft:light[level=12]
setblock 252 256 292 minecraft:light[level=12]
setblock 252 256 299 minecraft:light[level=12]
setblock 252 256 306 minecraft:light[level=12]
setblock 252 256 313 minecraft:light[level=12]
setblock 259 256 278 minecraft:light[level=12]
setblock 259 256 285 minecraft:light[level=12]
setblock 259 256 292 minecraft:light[level=12]
setblock 259 256 299 minecraft:light[level=12]
setblock 259 256 306 minecraft:light[level=12]
setblock 259 256 313 minecraft:light[level=12]
setblock 266 256 278 minecraft:light[level=12]
setblock 266 256 285 minecraft:light[level=12]
setblock 266 256 292 minecraft:light[level=12]
setblock 266 256 299 minecraft:light[level=12]
setblock 266 256 306 minecraft:light[level=12]
setblock 266 256 313 minecraft:light[level=12]
setblock 273 256 278 minecraft:light[level=12]
setblock 273 256 285 minecraft:light[level=12]
setblock 273 256 292 minecraft:light[level=12]
setblock 273 256 299 minecraft:light[level=12]
setblock 273 256 306 minecraft:light[level=12]
fill 274 256 294 274 258 294 minecraft:shroomlight
setblock 277 256 304 minecraft:lapis_block
fill 277 256 316 277 308 316 minecraft:smooth_sandstone
fill 235 257 279 235 265 280 minecraft:smooth_sandstone
setblock 235 257 284 minecraft:orange_terracotta
setblock 235 257 312 minecraft:orange_terracotta
fill 271 257 300 271 261 300 minecraft:cut_sandstone
fill 277 257 289 277 265 289 minecraft:smooth_sandstone
setblock 277 257 290 minecraft:orange_terracotta
fill 277 257 304 277 308 304 minecraft:smooth_sandstone
fill 235 258 284 235 265 284 minecraft:smooth_sandstone
setblock 235 258 300 minecraft:lapis_block
fill 235 258 312 235 308 312 minecraft:smooth_sandstone
setblock 238 258 278 minecraft:light[level=15]
setblock 238 258 286 minecraft:light[level=15]
setblock 238 258 294 minecraft:light[level=15]
setblock 238 258 302 minecraft:light[level=15]
setblock 238 258 310 minecraft:light[level=15]
setblock 240 258 275 minecraft:orange_terracotta
setblock 240 258 317 minecraft:blue_terracotta
fill 241 258 317 241 308 317 minecraft:smooth_sandstone
setblock 246 258 278 minecraft:light[level=15]
setblock 246 258 286 minecraft:light[level=15]
setblock 246 258 294 minecraft:light[level=15]
setblock 246 258 302 minecraft:light[level=15]
setblock 246 258 310 minecraft:light[level=15]
setblock 254 258 278 minecraft:light[level=15]
setblock 254 258 286 minecraft:light[level=15]
setblock 254 258 294 minecraft:light[level=15]
setblock 254 258 302 minecraft:light[level=15]
setblock 254 258 310 minecraft:light[level=15]
setblock 262 258 278 minecraft:light[level=15]
setblock 262 258 286 minecraft:light[level=15]
setblock 262 258 294 minecraft:light[level=15]
setblock 262 258 302 minecraft:light[level=15]
setblock 262 258 310 minecraft:light[level=15]
setblock 270 258 278 minecraft:light[level=15]
setblock 270 258 286 minecraft:light[level=15]
setblock 270 258 294 minecraft:light[level=15]
setblock 270 258 302 minecraft:light[level=15]
setblock 270 258 310 minecraft:light[level=15]
fill 274 258 307 274 259 310 minecraft:iron_block
fill 274 258 313 274 259 313 minecraft:iron_block
fill 277 258 290 277 262 290 minecraft:smooth_sandstone
fill 235 259 300 235 308 300 minecraft:smooth_sandstone
fill 240 259 275 240 295 275 minecraft:smooth_sandstone
fill 240 259 317 240 308 317 minecraft:smooth_sandstone
fill 258 259 307 259 260 308 minecraft:sandstone
setblock 270 259 275 minecraft:lapis_block
setblock 235 260 294 minecraft:blue_terracotta
fill 235 260 295 235 265 295 minecraft:smooth_sandstone
fill 237 260 285 237 265 287 minecraft:cut_sandstone
fill 237 260 297 237 265 299 minecraft:cut_sandstone
fill 237 260 309 237 265 311 minecraft:cut_sandstone
setblock 239 260 317 minecraft:blue_terracotta
fill 243 260 315 245 265 315 minecraft:cut_sandstone
fill 247 260 277 249 265 277 minecraft:cut_sandstone
fill 255 260 315 257 265 315 minecraft:cut_sandstone
fill 259 260 277 261 265 277 minecraft:cut_sandstone
fill 267 260 315 269 265 315 minecraft:cut_sandstone
fill 270 260 275 270 308 275 minecraft:smooth_sandstone
fill 271 260 277 273 265 277 minecraft:cut_sandstone
fill 275 260 285 275 265 287 minecraft:cut_sandstone
fill 275 260 297 275 265 299 minecraft:cut_sandstone
fill 275 260 309 275 265 311 minecraft:cut_sandstone
setblock 235 261 292 minecraft:black_terracotta
fill 235 261 294 235 265 294 minecraft:smooth_sandstone
setblock 238 261 317 minecraft:orange_terracotta
fill 239 261 317 239 279 317 minecraft:smooth_sandstone
fill 235 262 292 235 308 292 minecraft:smooth_sandstone
setblock 238 262 278 minecraft:light[level=12]
setblock 238 262 285 minecraft:light[level=12]
setblock 238 262 292 minecraft:light[level=12]
setblock 238 262 299 minecraft:light[level=12]
setblock 238 262 306 minecraft:light[level=12]
setblock 238 262 313 minecraft:light[level=12]
fill 238 262 317 238 265 317 minecraft:smooth_sandstone
fill 239 262 279 239 262 282 minecraft:chiseled_sandstone
fill 240 262 278 242 262 278 minecraft:chiseled_sandstone
fill 240 262 282 242 262 282 minecraft:chiseled_sandstone
fill 243 262 279 243 262 281 minecraft:chiseled_sandstone
setblock 243 262 317 minecraft:black_terracotta
setblock 245 262 278 minecraft:light[level=12]
setblock 245 262 285 minecraft:light[level=12]
setblock 245 262 292 minecraft:light[level=12]
setblock 245 262 299 minecraft:light[level=12]
setblock 245 262 306 minecraft:light[level=12]
setblock 245 262 313 minecraft:light[level=12]
setblock 252 262 278 minecraft:light[level=12]
setblock 252 262 285 minecraft:light[level=12]
setblock 252 262 292 minecraft:light[level=12]
setblock 252 262 299 minecraft:light[level=12]
setblock 252 262 306 minecraft:light[level=12]
setblock 252 262 313 minecraft:light[level=12]
setblock 259 262 278 minecraft:light[level=12]
setblock 259 262 285 minecraft:light[level=12]
setblock 259 262 292 minecraft:light[level=12]
setblock 259 262 299 minecraft:light[level=12]
setblock 259 262 306 minecraft:light[level=12]
setblock 259 262 313 minecraft:light[level=12]
setblock 266 262 278 minecraft:light[level=12]
fill 266 262 283 268 263 283 minecraft:smooth_sandstone
setblock 266 262 285 minecraft:light[level=12]
setblock 266 262 292 minecraft:light[level=12]
setblock 266 262 299 minecraft:light[level=12]
setblock 266 262 306 minecraft:light[level=12]
setblock 266 262 313 minecraft:light[level=12]
fill 267 262 284 267 263 284 minecraft:smooth_sandstone
fill 270 262 311 270 262 312 minecraft:chiseled_sandstone
setblock 271 262 300 minecraft:glowstone
setblock 271 262 310 minecraft:chiseled_sandstone
setblock 271 262 313 minecraft:chiseled_sandstone
setblock 272 262 309 minecraft:chiseled_sandstone
fill 272 262 314 273 262 314 minecraft:chiseled_sandstone
setblock 273 262 278 minecraft:light[level=12]
setblock 273 262 285 minecraft:light[level=12]
setblock 273 262 292 minecraft:light[level=12]
setblock 273 262 299 minecraft:light[level=12]
setblock 273 262 306 minecraft:light[level=12]
setblock 274 262 310 minecraft:chiseled_sandstone
setblock 274 262 313 minecraft:chiseled_sandstone
fill 243 263 317 243 264 317 minecraft:smooth_sandstone
setblock 277 263 290 minecraft:orange_terracotta
setblock 235 264 290 minecraft:blue_terracotta
setblock 236 264 317 minecraft:lapis_block
setblock 237 264 275 minecraft:lapis_block
fill 237 264 317 237 265 317 minecraft:smooth_sandstone
setblock 274 264 317 minecraft:blue_terracotta
fill 277 264 290 277 265 290 minecraft:smooth_sandstone
fill 235 265 290 235 308 290 minecraft:smooth_sandstone
fill 236 265 279 236 265 284 minecraft:chiseled_sandstone
fill 236 265 291 236 265 296 minecraft:chiseled_sandstone
fill 236 265 303 236 265 308 minecraft:chiseled_sandstone
fill 236 265 315 236 265 316 minecraft:chiseled_sandstone
setblock 236 265 317 minecraft:smooth_sandstone
fill 237 265 275 237 273 275 minecraft:smooth_sandstone
fill 237 265 316 240 265 316 minecraft:chiseled_sandstone
fill 240 265 276 245 265 276 minecraft:chiseled_sandstone
setblock 243 265 317 minecraft:orange_terracotta
fill 247 265 316 252 265 316 minecraft:chiseled_sandstone
setblock 251 265 317 minecraft:black_terracotta
fill 252 265 276 257 265 276 minecraft:chiseled_sandstone
fill 252 265 317 254 283 317 minecraft:smooth_sandstone
fill 259 265 316 264 265 316 minecraft:chiseled_sandstone
fill 264 265 276 269 265 276 minecraft:chiseled_sandstone
fill 271 265 316 276 265 316 minecraft:chiseled_sandstone
setblock 274 265 317 minecraft:orange_terracotta
fill 276 265 276 276 265 281 minecraft:chiseled_sandstone
fill 276 265 288 276 265 293 minecraft:chiseled_sandstone
fill 276 265 300 276 265 305 minecraft:chiseled_sandstone
fill 276 265 312 276 265 315 minecraft:chiseled_sandstone
setblock 277 265 276 minecraft:blue_terracotta
setblock 277 265 277 minecraft:orange_terracotta
fill 235 266 279 235 292 279 minecraft:smooth_sandstone
setblock 235 266 280 minecraft:orange_terracotta
fill 235 266 281 235 270 284 minecraft:glowstone
fill 235 266 293 235 270 296 minecraft:glowstone
fill 235 266 305 235 270 308 minecraft:glowstone
fill 235 266 317 238 270 317 minecraft:glowstone
setblock 238 266 278 minecraft:light[level=15]
setblock 238 266 286 minecraft:light[level=15]
setblock 238 266 294 minecraft:light[level=15]
setblock 238 266 302 minecraft:light[level=15]
setblock 238 266 310 minecraft:light[level=15]
fill 242 266 275 245 270 275 minecraft:glowstone
fill 243 266 317 243 308 317 minecraft:smooth_sandstone
setblock 246 266 278 minecraft:light[level=15]
setblock 246 266 286 minecraft:light[level=15]
setblock 246 266 294 minecraft:light[level=15]
setblock 246 266 302 minecraft:light[level=15]
setblock 246 266 310 minecraft:light[level=15]
fill 247 266 317 250 270 317 minecraft:glowstone
fill 251 266 317 251 308 317 minecraft:smooth_sandstone
fill 254 266 275 257 270 275 minecraft:glowstone
setblock 254 266 278 minecraft:light[level=15]
setblock 254 266 286 minecraft:light[level=15]
setblock 254 266 294 minecraft:light[level=15]
setblock 254 266 302 minecraft:light[level=15]
setblock 254 266 310 minecraft:light[level=15]
fill 259 266 317 262 270 317 minecraft:glowstone
setblock 262 266 278 minecraft:light[level=15]
setblock 262 266 286 minecraft:light[level=15]
setblock 262 266 294 minecraft:light[level=15]
setblock 262 266 302 minecraft:light[level=15]
setblock 262 266 310 minecraft:light[level=15]
fill 266 266 275 269 270 275 minecraft:glowstone
setblock 270 266 278 minecraft:light[level=15]
setblock 270 266 286 minecraft:light[level=15]
setblock 270 266 294 minecraft:light[level=15]
setblock 270 266 302 minecraft:light[level=15]
setblock 270 266 310 minecraft:light[level=15]
fill 271 266 317 274 270 317 minecraft:glowstone
fill 277 266 276 277 270 279 minecraft:glowstone
fill 277 266 288 277 270 291 minecraft:glowstone
fill 277 266 300 277 270 303 minecraft:glowstone
fill 277 266 312 277 270 315 minecraft:glowstone
fill 235 267 280 235 295 280 minecraft:smooth_sandstone
fill 249 267 275 249 276 275 minecraft:smooth_sandstone
setblock 250 267 275 minecraft:black_terracotta
setblock 238 268 278 minecraft:light[level=12]
setblock 238 268 285 minecraft:light[level=12]
setblock 238 268 292 minecraft:light[level=12]
setblock 238 268 299 minecraft:light[level=12]
setblock 238 268 306 minecraft:light[level=12]
setblock 238 268 313 minecraft:light[level=12]
setblock 245 268 278 minecraft:light[level=12]
setblock 245 268 285 minecraft:light[level=12]
setblock 245 268 292 minecraft:light[level=12]
setblock 245 268 299 minecraft:light[level=12]
setblock 245 268 306 minecraft:light[level=12]
setblock 245 268 313 minecraft:light[level=12]
fill 250 268 275 250 295 275 minecraft:smooth_sandstone
setblock 252 268 278 minecraft:light[level=12]
setblock 252 268 285 minecraft:light[level=12]
setblock 252 268 292 minecraft:light[level=12]
setblock 252 268 299 minecraft:light[level=12]
setblock 252 268 306 minecraft:light[level=12]
setblock 252 268 313 minecraft:light[level=12]
setblock 259 268 278 minecraft:light[level=12]
setblock 259 268 285 minecraft:light[level=12]
setblock 259 268 292 minecraft:light[level=12]
setblock 259 268 299 minecraft:light[level=12]
setblock 259 268 306 minecraft:light[level=12]
setblock 259 268 313 minecraft:light[level=12]
setblock 266 268 278 minecraft:light[level=12]
setblock 266 268 285 minecraft:light[level=12]
setblock 266 268 292 minecraft:light[level=12]
setblock 266 268 299 minecraft:light[level=12]
setblock 266 268 306 minecraft:light[level=12]
setblock 266 268 313 minecraft:light[level=12]
setblock 273 268 278 minecraft:light[level=12]
setblock 273 268 285 minecraft:light[level=12]
setblock 273 268 292 minecraft:light[level=12]
setblock 273 268 299 minecraft:light[level=12]
setblock 273 268 306 minecraft:light[level=12]
setblock 277 268 293 minecraft:black_terracotta
fill 277 268 294 277 280 295 minecraft:smooth_sandstone
fill 239 269 279 239 270 281 minecraft:lapis_block
fill 240 269 278 241 270 278 minecraft:lapis_block
fill 240 269 282 242 270 282 minecraft:lapis_block
fill 243 269 280 243 270 281 minecraft:lapis_block
setblock 252 269 275 minecraft:blue_terracotta
fill 269 269 301 271 270 301 minecraft:smooth_sandstone
fill 270 269 300 270 270 300 minecraft:smooth_sandstone
fill 270 269 302 270 270 302 minecraft:smooth_sandstone
fill 270 269 312 270 270 312 minecraft:lapis_block
fill 271 269 310 271 270 310 minecraft:lapis_block
fill 271 269 313 271 270 313 minecraft:lapis_block
fill 274 269 310 274 270 310 minecraft:lapis_block
fill 274 269 313 274 270 313 minecraft:lapis_block
setblock 277 269 280 minecraft:lapis_block
fill 277 269 281 277 308 281 minecraft:smooth_sandstone
fill 277 269 293 277 295 293 minecraft:smooth_sandstone
setblock 277 269 311 minecraft:blue_terracotta
setblock 235 270 285 minecraft:lapis_block
fill 252 270 275 252 283 275 minecraft:smooth_sandstone
setblock 257 270 317 minecraft:orange_terracotta
fill 277 270 280 277 288 280 minecraft:smooth_sandstone
setblock 277 270 282 minecraft:blue_terracotta
fill 277 270 311 277 308 311 minecraft:smooth_sandstone
setblock 235 271 276 minecraft:black_terracotta
fill 235 271 281 235 282 285 minecraft:smooth_sandstone
fill 235 271 293 235 282 296 minecraft:smooth_sandstone
fill 235 271 305 235 272 308 minecraft:smooth_sandstone
fill 235 271 317 238 276 317 minecraft:smooth_sandstone
fill 242 271 275 245 277 275 minecraft:smooth_sandstone
fill 247 271 317 250 281 317 minecraft:smooth_sandstone
setblock 248 271 275 minecraft:orange_terracotta
fill 254 271 275 257 275 275 minecraft:smooth_sandstone
fill 257 271 317 257 308 317 minecraft:smooth_sandstone
fill 259 271 317 262 272 317 minecraft:smooth_sandstone
fill 266 271 275 269 272 275 minecraft:smooth_sandstone
fill 271 271 317 274 277 317 minecraft:smooth_sandstone
fill 277 271 276 277 274 279 minecraft:smooth_sandstone
fill 277 271 282 277 308 282 minecraft:smooth_sandstone
setblock 277 271 283 minecraft:blue_terracotta
fill 277 271 288 277 275 291 minecraft:smooth_sandstone
fill 277 271 296 277 278 297 minecraft:smooth_sandstone
setblock 277 271 298 minecraft:orange_terracotta
fill 277 271 299 277 280 303 minecraft:smooth_sandstone
fill 277 271 312 277 283 315 minecraft:smooth_sandstone
fill 235 272 276 235 284 276 minecraft:smooth_sandstone
fill 248 272 275 248 308 275 minecraft:smooth_sandstone
fill 277 272 283 277 275 283 minecraft:smooth_sandstone
fill 277 272 298 277 308 298 minecraft:smooth_sandstone
fill 277 272 305 277 306 305 minecraft:smooth_sandstone
setblock 277 272 306 minecraft:lapis_block
fill 235 273 305 235 285 305 minecraft:smooth_sandstone
setblock 235 273 306 minecraft:black_terracotta
fill 235 273 307 235 285 308 minecraft:smooth_sandstone
fill 259 273 317 260 285 317 minecraft:smooth_sandstone
setblock 261 273 317 minecraft:black_terracotta
fill 262 273 317 262 285 317 minecraft:smooth_sandstone
setblock 265 273 275 minecraft:black_terracotta
fill 266 273 275 266 274 275 minecraft:smooth_sandstone
setblock 267 273 275 minecraft:blue_terracotta
fill 268 273 275 269 273 275 minecraft:smooth_sandstone
fill 277 273 306 277 287 306 minecraft:smooth_sandstone
fill 235 274 306 235 285 306 minecraft:smooth_sandstone
setblock 237 274 275 minecraft:lapis_block
setblock 238 274 278 minecraft:light[level=15]
setblock 238 274 285 minecraft:light[level=12]
setblock 238 274 286 minecraft:light[level=15]
setblock 238 274 292 minecraft:light[level=12]
setblock 238 274 294 minecraft:light[level=15]
setblock 238 274 299 minecraft:light[level=12]
setblock 238 274 302 minecraft:light[level=15]
setblock 238 274 306 minecraft:light[level=12]
setblock 238 274 310 minecraft:light[level=15]
setblock 238 274 313 minecraft:light[level=12]
setblock 245 274 278 minecraft:light[level=12]
setblock 245 274 285 minecraft:light[level=12]
setblock 245 274 292 minecraft:light[level=12]
setblock 245 274 299 minecraft:light[level=12]
setblock 245 274 306 minecraft:light[level=12]
setblock 245 274 313 minecraft:light[level=12]
setblock 246 274 278 minecraft:light[level=15]
setblock 246 274 286 minecraft:light[level=15]
setblock 246 274 294 minecraft:light[level=15]
setblock 246 274 302 minecraft:light[level=15]
setblock 246 274 310 minecraft:light[level=15]
setblock 252 274 278 minecraft:light[level=12]
setblock 252 274 285 minecraft:light[level=12]
setblock 252 274 292 minecraft:light[level=12]
setblock 252 274 299 minecraft:light[level=12]
setblock 252 274 306 minecraft:light[level=12]
setblock 252 274 313 minecraft:light[level=12]
setblock 254 274 278 minecraft:light[level=15]
setblock 254 274 286 minecraft:light[level=15]
setblock 254 274 294 minecraft:light[level=15]
setblock 254 274 302 minecraft:light[level=15]
setblock 254 274 310 minecraft:light[level=15]
setblock 259 274 278 minecraft:light[level=12]
setblock 259 274 285 minecraft:light[level=12]
setblock 259 274 292 minecraft:light[level=12]
setblock 259 274 299 minecraft:light[level=12]
setblock 259 274 306 minecraft:light[level=12]
setblock 259 274 313 minecraft:light[level=12]
fill 261 274 317 261 285 317 minecraft:smooth_sandstone
setblock 262 274 278 minecraft:light[level=15]
setblock 262 274 286 minecraft:light[level=15]
setblock 262 274 294 minecraft:light[level=15]
setblock 262 274 302 minecraft:light[level=15]
setblock 262 274 310 minecraft:light[level=15]
fill 265 274 275 265 308 275 minecraft:smooth_sandstone
setblock 266 274 278 minecraft:light[level=12]
setblock 266 274 285 minecraft:light[level=12]
setblock 266 274 292 minecraft:light[level=12]
setblock 266 274 299 minecraft:light[level=12]
setblock 266 274 306 minecraft:light[level=12]
setblock 266 274 313 minecraft:light[level=12]
fill 267 274 275 268 285 275 minecraft:smooth_sandstone
setblock 269 274 275 minecraft:orange_terracotta
setblock 270 274 278 minecraft:light[level=15]
setblock 270 274 286 minecraft:light[level=15]
setblock 270 274 294 minecraft:light[level=15]
setblock 270 274 302 minecraft:light[level=15]
setblock 270 274 310 minecraft:light[level=15]
setblock 270 274 317 minecraft:black_terracotta
setblock 273 274 278 minecraft:light[level=12]
setblock 273 274 285 minecraft:light[level=12]
setblock 273 274 292 minecraft:light[level=12]
setblock 273 274 299 minecraft:light[level=12]
setblock 273 274 306 minecraft:light[level=12]
setblock 273 274 313 minecraft:light[level=12]
fill 237 275 275 237 295 275 minecraft:smooth_sandstone
setblock 260 275 275 minecraft:lapis_block
setblock 266 275 275 minecraft:orange_terracotta
fill 269 275 275 269 281 275 minecraft:smooth_sandstone
fill 270 275 317 270 278 317 minecraft:smooth_sandstone
setblock 275 275 275 minecraft:orange_terracotta
setblock 277 275 276 minecraft:blue_terracotta
fill 277 275 277 277 280 279 minecraft:smooth_sandstone
setblock 235 276 301 minecraft:lapis_block
fill 236 276 276 236 278 276 minecraft:gold_block
fill 236 276 277 236 276 315 minecraft:smooth_sandstone
fill 236 276 316 236 278 316 minecraft:gold_block
fill 237 276 276 275 276 276 minecraft:smooth_sandstone
fill 237 276 277 237 279 277 minecraft:gold_block
fill 237 276 278 237 276 314 minecraft:smooth_sandstone
fill 237 276 315 237 279 315 minecraft:gold_block
fill 237 276 316 275 276 316 minecraft:smooth_sandstone
fill 238 276 277 274 276 277 minecraft:smooth_sandstone
fill 238 276 278 238 279 278 minecraft:gold_block
fill 238 276 279 238 276 313 minecraft:smooth_sandstone
fill 238 276 314 238 279 314 minecraft:gold_block
fill 238 276 315 274 276 315 minecraft:smooth_sandstone
fill 239 276 278 273 276 278 minecraft:smooth_sandstone
fill 239 276 279 239 280 279 minecraft:gold_block
fill 239 276 280 239 276 312 minecraft:smooth_sandstone
fill 239 276 313 239 280 313 minecraft:gold_block
fill 239 276 314 273 276 314 minecraft:smooth_sandstone
fill 240 276 279 272 276 279 minecraft:smooth_sandstone
fill 240 276 280 240 281 280 minecraft:gold_block
fill 240 276 281 240 276 311 minecraft:smooth_sandstone
fill 240 276 312 240 281 312 minecraft:gold_block
fill 240 276 313 272 276 313 minecraft:smooth_sandstone
fill 241 276 280 271 276 280 minecraft:smooth_sandstone
fill 241 276 281 241 282 281 minecraft:gold_block
fill 241 276 282 241 276 310 minecraft:smooth_sandstone
fill 241 276 311 241 282 311 minecraft:gold_block
fill 241 276 312 271 276 312 minecraft:smooth_sandstone
fill 242 276 281 270 276 281 minecraft:smooth_sandstone
fill 242 276 282 242 282 282 minecraft:gold_block
fill 242 276 283 242 276 309 minecraft:smooth_sandstone
fill 242 276 310 242 282 310 minecraft:gold_block
fill 242 276 311 270 276 311 minecraft:smooth_sandstone
fill 243 276 282 269 276 282 minecraft:smooth_sandstone
fill 243 276 283 243 283 283 minecraft:gold_block
fill 243 276 284 243 276 308 minecraft:smooth_sandstone
fill 243 276 309 243 283 309 minecraft:gold_block
fill 243 276 310 269 276 310 minecraft:smooth_sandstone
fill 244 276 283 268 276 283 minecraft:smooth_sandstone
fill 244 276 284 244 284 284 minecraft:gold_block
fill 244 276 285 244 276 307 minecraft:smooth_sandstone
fill 244 276 308 244 284 308 minecraft:gold_block
fill 244 276 309 268 276 309 minecraft:smooth_sandstone
fill 245 276 284 267 276 284 minecraft:smooth_sandstone
fill 245 276 285 245 285 285 minecraft:gold_block
fill 245 276 286 245 276 306 minecraft:smooth_sandstone
fill 245 276 307 245 285 307 minecraft:gold_block
fill 245 276 308 267 276 308 minecraft:smooth_sandstone
fill 246 276 285 266 276 285 minecraft:smooth_sandstone
fill 246 276 286 246 285 286 minecraft:gold_block
fill 246 276 287 246 276 305 minecraft:smooth_sandstone
fill 246 276 306 246 285 306 minecraft:gold_block
fill 246 276 307 266 276 307 minecraft:smooth_sandstone
fill 247 276 286 265 276 286 minecraft:smooth_sandstone
fill 247 276 287 247 286 287 minecraft:gold_block
fill 247 276 288 247 276 304 minecraft:smooth_sandstone
fill 247 276 305 247 286 305 minecraft:gold_block
fill 247 276 306 265 276 306 minecraft:smooth_sandstone
fill 248 276 287 264 276 287 minecraft:smooth_sandstone
fill 248 276 288 248 287 288 minecraft:gold_block
fill 248 276 289 248 276 303 minecraft:smooth_sandstone
fill 248 276 304 248 287 304 minecraft:gold_block
fill 248 276 305 264 276 305 minecraft:smooth_sandstone
fill 249 276 288 263 276 288 minecraft:smooth_sandstone
fill 249 276 289 249 288 289 minecraft:gold_block
fill 249 276 290 249 276 302 minecraft:smooth_sandstone
fill 249 276 303 249 288 303 minecraft:gold_block
fill 249 276 304 263 276 304 minecraft:smooth_sandstone
fill 250 276 289 262 276 289 minecraft:smooth_sandstone
fill 250 276 290 250 288 290 minecraft:gold_block
fill 250 276 291 250 276 301 minecraft:smooth_sandstone
fill 250 276 302 250 288 302 minecraft:gold_block
fill 250 276 303 262 276 303 minecraft:smooth_sandstone
fill 251 276 290 261 276 290 minecraft:smooth_sandstone
fill 251 276 291 251 289 291 minecraft:gold_block
fill 251 276 292 251 276 300 minecraft:smooth_sandstone
fill 251 276 301 251 289 301 minecraft:gold_block
fill 251 276 302 261 276 302 minecraft:smooth_sandstone
fill 252 276 291 255 276 291 minecraft:smooth_sandstone
fill 252 276 292 252 290 292 minecraft:gold_block
fill 252 276 293 252 276 299 minecraft:smooth_sandstone
fill 252 276 300 252 290 300 minecraft:gold_block
fill 252 276 301 260 276 301 minecraft:smooth_sandstone
setblock 253 276 292 minecraft:smooth_sandstone
fill 253 276 293 253 291 293 minecraft:gold_block
fill 253 276 295 253 276 298 minecraft:smooth_sandstone
fill 253 276 299 253 291 299 minecraft:gold_block
fill 253 276 300 259 276 300 minecraft:smooth_sandstone
fill 254 276 275 255 285 275 minecraft:smooth_sandstone
setblock 254 276 297 minecraft:smooth_sandstone
fill 254 276 298 254 291 298 minecraft:gold_block
fill 254 276 299 258 276 299 minecraft:smooth_sandstone
fill 255 276 297 255 292 297 minecraft:gold_block
fill 255 276 298 257 276 298 minecraft:smooth_sandstone
setblock 256 276 275 minecraft:lapis_block
fill 257 276 275 257 285 275 minecraft:smooth_sandstone
fill 257 276 291 260 276 291 minecraft:smooth_sandstone
fill 257 276 297 257 292 297 minecraft:gold_block
fill 258 276 297 276 276 297 minecraft:smooth_sandstone
fill 258 276 298 258 291 298 minecraft:gold_block
setblock 259 276 292 minecraft:smooth_sandstone
fill 259 276 293 259 291 293 minecraft:gold_block
fill 259 276 295 276 276 296 minecraft:smooth_sandstone
fill 259 276 298 276 276 298 minecraft:smooth_sandstone
fill 259 276 299 259 291 299 minecraft:gold_block
fill 260 276 275 260 308 275 minecraft:smooth_sandstone
fill 260 276 292 260 290 292 minecraft:gold_block
fill 260 276 293 276 276 294 minecraft:smooth_sandstone
fill 260 276 299 276 276 299 minecraft:smooth_sandstone
fill 260 276 300 260 290 300 minecraft:gold_block
fill 261 276 291 261 289 291 minecraft:gold_block
fill 261 276 292 276 276 292 minecraft:smooth_sandstone
fill 261 276 300 276 276 300 minecraft:smooth_sandstone
fill 261 276 301 261 289 301 minecraft:gold_block
fill 262 276 290 262 288 290 minecraft:gold_block
fill 262 276 291 277 276 291 minecraft:smooth_sandstone
fill 262 276 301 276 276 301 minecraft:smooth_sandstone
fill 262 276 302 262 288 302 minecraft:gold_block
fill 263 276 289 263 288 289 minecraft:gold_block
fill 263 276 290 276 276 290 minecraft:smooth_sandstone
fill 263 276 302 276 276 302 minecraft:smooth_sandstone
fill 263 276 303 263 288 303 minecraft:gold_block
fill 264 276 288 264 287 288 minecraft:gold_block
fill 264 276 289 276 276 289 minecraft:smooth_sandstone
fill 264 276 303 276 276 303 minecraft:smooth_sandstone
fill 264 276 304 264 287 304 minecraft:gold_block
fill 265 276 287 265 286 287 minecraft:gold_block
fill 265 276 288 277 276 288 minecraft:smooth_sandstone
fill 265 276 304 276 276 304 minecraft:smooth_sandstone
fill 265 276 305 265 286 305 minecraft:gold_block
fill 266 276 275 266 285 275 minecraft:smooth_sandstone
fill 266 276 286 266 285 286 minecraft:gold_block
fill 266 276 287 276 276 287 minecraft:smooth_sandstone
fill 266 276 305 276 276 305 minecraft:smooth_sandstone
fill 266 276 306 266 285 306 minecraft:gold_block
fill 267 276 285 267 285 285 minecraft:gold_block
fill 267 276 286 276 276 286 minecraft:smooth_sandstone
fill 267 276 306 276 276 306 minecraft:smooth_sandstone
fill 267 276 307 267 285 307 minecraft:gold_block
fill 268 276 284 268 284 284 minecraft:gold_block
fill 268 276 285 276 276 285 minecraft:smooth_sandstone
fill 268 276 307 276 276 307 minecraft:smooth_sandstone
fill 268 276 308 268 284 308 minecraft:gold_block
fill 269 276 283 269 283 283 minecraft:gold_block
fill 269 276 284 276 276 284 minecraft:smooth_sandstone
fill 269 276 308 276 276 308 minecraft:smooth_sandstone
fill 269 276 309 269 283 309 minecraft:gold_block
fill 270 276 282 270 282 282 minecraft:gold_block
fill 270 276 283 276 276 283 minecraft:smooth_sandstone
fill 270 276 309 276 276 309 minecraft:smooth_sandstone
fill 270 276 310 270 282 310 minecraft:gold_block
fill 271 276 281 271 282 281 minecraft:gold_block
fill 271 276 282 276 276 282 minecraft:smooth_sandstone
fill 271 276 310 276 276 310 minecraft:smooth_sandstone
fill 271 276 311 271 282 311 minecraft:gold_block
fill 272 276 280 272 281 280 minecraft:gold_block
fill 272 276 281 276 276 281 minecraft:smooth_sandstone
fill 272 276 311 276 276 311 minecraft:smooth_sandstone
fill 272 276 312 272 281 312 minecraft:gold_block
fill 273 276 279 273 280 279 minecraft:gold_block
fill 273 276 280 276 276 280 minecraft:smooth_sandstone
fill 273 276 312 276 276 312 minecraft:smooth_sandstone
fill 273 276 313 273 280 313 minecraft:gold_block
fill 274 276 278 274 279 278 minecraft:gold_block
fill 274 276 279 276 276 279 minecraft:smooth_sandstone
fill 274 276 313 276 276 313 minecraft:smooth_sandstone
fill 274 276 314 274 279 314 minecraft:gold_block
fill 275 276 275 275 308 275 minecraft:smooth_sandstone
fill 275 276 277 275 279 277 minecraft:gold_block
fill 275 276 278 276 276 278 minecraft:smooth_sandstone
fill 275 276 314 276 276 314 minecraft:smooth_sandstone
fill 275 276 315 275 279 315 minecraft:gold_block
fill 276 276 276 276 278 276 minecraft:gold_block
setblock 276 276 277 minecraft:smooth_sandstone
setblock 276 276 315 minecraft:smooth_sandstone
fill 276 276 316 276 278 316 minecraft:gold_block
fill 277 276 276 277 285 276 minecraft:smooth_sandstone
setblock 277 276 283 minecraft:black_terracotta
fill 277 276 289 277 276 290 minecraft:black_terracotta
fill 235 277 301 235 308 301 minecraft:smooth_sandstone
fill 235 277 317 235 285 317 minecraft:smooth_sandstone
fill 236 277 277 236 277 315 minecraft:sandstone
setblock 236 277 317 minecraft:black_terracotta
fill 237 277 276 275 277 276 minecraft:sandstone
fill 237 277 278 237 277 314 minecraft:sandstone
fill 237 277 316 275 277 316 minecraft:sandstone
fill 237 277 317 238 285 317 minecraft:smooth_sandstone
fill 238 277 277 274 277 277 minecraft:sandstone
fill 238 277 279 238 277 313 minecraft:sandstone
fill 238 277 315 274 277 315 minecraft:sandstone
fill 239 277 278 273 277 278 minecraft:sandstone
fill 239 277 280 239 277 312 minecraft:sandstone
fill 239 277 314 273 277 314 minecraft:sandstone
fill 240 277 279 272 277 279 minecraft:sandstone
fill 240 277 281 240 277 311 minecraft:sandstone
fill 240 277 313 272 277 313 minecraft:sandstone
fill 241 277 280 271 277 280 minecraft:sandstone
fill 241 277 282 241 277 310 minecraft:sandstone
fill 241 277 312 271 277 312 minecraft:sandstone
fill 242 277 281 270 277 281 minecraft:sandstone
fill 242 277 283 242 277 309 minecraft:sandstone
fill 242 277 311 270 277 311 minecraft:sandstone
fill 243 277 282 269 277 282 minecraft:sandstone
fill 243 277 284 243 277 308 minecraft:sandstone
fill 243 277 310 269 277 310 minecraft:sandstone
fill 244 277 283 268 277 283 minecraft:sandstone
fill 244 277 285 244 277 307 minecraft:sandstone
fill 244 277 309 268 277 309 minecraft:sandstone
fill 245 277 284 267 277 284 minecraft:sandstone
fill 245 277 286 245 277 306 minecraft:sandstone
fill 245 277 308 267 277 308 minecraft:sandstone
fill 246 277 285 266 277 285 minecraft:sandstone
fill 246 277 287 246 277 305 minecraft:sandstone
fill 246 277 307 266 277 307 minecraft:sandstone
fill 247 277 286 265 277 286 minecraft:sandstone
fill 247 277 288 247 277 304 minecraft:sandstone
fill 247 277 306 265 277 306 minecraft:sandstone
fill 248 277 287 264 277 287 minecraft:sandstone
fill 248 277 289 248 277 303 minecraft:sandstone
fill 248 277 305 264 277 305 minecraft:sandstone
setblock 249 277 275 minecraft:black_terracotta
fill 249 277 288 263 277 288 minecraft:sandstone
fill 249 277 290 249 277 302 minecraft:sandstone
fill 249 277 304 263 277 304 minecraft:sandstone
fill 250 277 289 262 277 289 minecraft:sandstone
fill 250 277 291 250 277 301 minecraft:sandstone
fill 250 277 303 262 277 303 minecraft:sandstone
fill 251 277 290 261 277 290 minecraft:sandstone
fill 251 277 292 251 277 300 minecraft:sandstone
fill 251 277 302 261 277 302 minecraft:sandstone
fill 252 277 291 255 277 291 minecraft:sandstone
fill 252 277 293 252 277 299 minecraft:sandstone
fill 252 277 301 260 277 301 minecraft:sandstone
setblock 253 277 292 minecraft:sandstone
fill 253 277 295 253 277 298 minecraft:sandstone
fill 253 277 300 259 277 300 minecraft:sandstone
setblock 254 277 297 minecraft:sandstone
fill 254 277 299 258 277 299 minecraft:sandstone
fill 255 277 298 257 277 298 minecraft:sandstone
fill 256 277 275 256 285 275 minecraft:smooth_sandstone
fill 257 277 291 260 277 291 minecraft:sandstone
fill 258 277 297 276 277 297 minecraft:sandstone
setblock 259 277 292 minecraft:sandstone
fill 259 277 295 276 277 296 minecraft:sandstone
fill 259 277 298 276 277 298 minecraft:sandstone
fill 260 277 293 276 277 294 minecraft:sandstone
fill 260 277 299 276 277 299 minecraft:sandstone
fill 261 277 292 276 277 292 minecraft:sandstone
fill 261 277 300 276 277 300 minecraft:sandstone
fill 262 277 291 276 277 291 minecraft:sandstone
fill 262 277 301 276 277 301 minecraft:sandstone
fill 263 277 290 276 277 290 minecraft:sandstone
fill 263 277 302 276 277 302 minecraft:sandstone
fill 264 277 289 276 277 289 minecraft:sandstone
fill 264 277 303 276 277 303 minecraft:sandstone
fill 265 277 288 276 277 288 minecraft:sandstone
fill 265 277 304 276 277 304 minecraft:sandstone
fill 266 277 287 276 277 287 minecraft:sandstone
fill 266 277 305 276 277 305 minecraft:sandstone
fill 267 277 286 276 277 286 minecraft:sandstone
fill 267 277 306 276 277 306 minecraft:sandstone
fill 268 277 285 276 277 285 minecraft:sandstone
fill 268 277 307 276 277 307 minecraft:sandstone
fill 269 277 284 276 277 284 minecraft:sandstone
fill 269 277 308 276 277 308 minecraft:sandstone
fill 270 277 283 276 277 283 minecraft:sandstone
fill 270 277 309 276 277 309 minecraft:sandstone
fill 271 277 282 276 277 282 minecraft:sandstone
fill 271 277 310 276 277 310 minecraft:sandstone
fill 272 277 281 276 277 281 minecraft:sandstone
fill 272 277 311 276 277 311 minecraft:sandstone
fill 273 277 280 276 277 280 minecraft:sandstone
fill 273 277 312 276 277 312 minecraft:sandstone
fill 274 277 279 276 277 279 minecraft:sandstone
fill 274 277 313 276 277 313 minecraft:sandstone
fill 275 277 278 276 277 278 minecraft:sandstone
fill 275 277 314 276 277 314 minecraft:sandstone
setblock 276 277 277 minecraft:sandstone
setblock 276 277 315 minecraft:sandstone
fill 277 277 283 277 308 283 minecraft:smooth_sandstone
fill 277 277 288 277 285 291 minecraft:smooth_sandstone
fill 236 278 277 236 278 315 minecraft:smooth_sandstone
fill 236 278 317 236 285 317 minecraft:smooth_sandstone
fill 237 278 276 275 278 276 minecraft:smooth_sandstone
fill 237 278 278 237 278 314 minecraft:smooth_sandstone
fill 237 278 316 275 278 316 minecraft:smooth_sandstone
fill 238 278 277 274 278 277 minecraft:smooth_sandstone
fill 238 278 279 238 278 313 minecraft:smooth_sandstone
fill 238 278 315 274 278 315 minecraft:smooth_sandstone
fill 239 278 278 273 278 278 minecraft:smooth_sandstone
fill 239 278 280 239 278 312 minecraft:smooth_sandstone
fill 239 278 314 273 278 314 minecraft:smooth_sandstone
fill 240 278 279 272 278 279 minecraft:smooth_sandstone
fill 240 278 281 240 278 311 minecraft:smooth_sandstone
fill 240 278 313 272 278 313 minecraft:smooth_sandstone
fill 241 278 280 271 278 280 minecraft:smooth_sandstone
fill 241 278 282 241 278 310 minecraft:smooth_sandstone
fill 241 278 312 271 278 312 minecraft:smooth_sandstone
fill 242 278 275 243 285 275 minecraft:smooth_sandstone
fill 242 278 281 270 278 281 minecraft:smooth_sandstone
fill 242 278 283 242 278 309 minecraft:smooth_sandstone
schedule function dropper:buildpart/65_4 1t
