fill 252 87 234 252 88 234 minecraft:gray_concrete
fill 252 87 264 252 88 264 minecraft:gray_concrete
fill 252 87 269 252 88 269 minecraft:gray_concrete
fill 254 87 229 254 88 229 minecraft:gray_concrete
fill 254 87 234 254 88 234 minecraft:gray_concrete
setblock 254 87 239 minecraft:light[level=15]
setblock 254 87 247 minecraft:light[level=15]
setblock 254 87 255 minecraft:light[level=15]
fill 254 87 264 254 91 264 minecraft:gray_concrete
fill 254 87 269 254 91 269 minecraft:gray_concrete
fill 256 87 229 256 88 229 minecraft:gray_concrete
fill 256 87 234 256 88 234 minecraft:gray_concrete
fill 256 87 264 256 88 264 minecraft:gray_concrete
fill 256 87 269 256 91 269 minecraft:gray_concrete
fill 257 87 270 258 100 270 minecraft:black_concrete
fill 258 87 229 258 88 229 minecraft:gray_concrete
fill 258 87 234 258 88 234 minecraft:gray_concrete
fill 258 87 269 258 88 269 minecraft:gray_concrete
setblock 259 87 270 minecraft:sea_lantern
fill 260 87 229 260 88 229 minecraft:gray_concrete
fill 260 87 234 260 88 234 minecraft:gray_concrete
fill 260 87 264 260 88 264 minecraft:gray_concrete
fill 260 87 269 260 88 269 minecraft:gray_concrete
fill 262 87 230 262 88 230 minecraft:gray_concrete
fill 262 87 232 262 88 232 minecraft:gray_concrete
setblock 262 87 239 minecraft:light[level=15]
setblock 262 87 247 minecraft:light[level=15]
setblock 262 87 255 minecraft:light[level=15]
setblock 262 87 263 minecraft:light[level=15]
fill 262 87 265 262 88 265 minecraft:gray_concrete
fill 262 87 267 262 88 267 minecraft:gray_concrete
fill 268 87 230 268 88 230 minecraft:blue_terracotta
fill 268 87 232 268 88 232 minecraft:blue_terracotta
fill 268 87 234 268 88 234 minecraft:blue_terracotta
fill 268 87 236 268 88 236 minecraft:blue_terracotta
fill 268 87 262 268 88 262 minecraft:gray_concrete
fill 268 87 264 268 88 264 minecraft:gray_concrete
fill 268 87 268 268 88 268 minecraft:gray_concrete
fill 269 87 229 269 88 229 minecraft:blue_terracotta
fill 269 87 237 269 88 237 minecraft:blue_terracotta
fill 269 87 261 269 88 261 minecraft:gray_concrete
fill 269 87 269 269 91 269 minecraft:gray_concrete
setblock 270 87 239 minecraft:light[level=15]
setblock 270 87 247 minecraft:light[level=15]
fill 271 87 229 271 88 229 minecraft:blue_terracotta
fill 271 87 237 271 88 237 minecraft:blue_terracotta
fill 271 87 243 271 88 243 minecraft:gray_concrete
fill 271 87 245 271 88 245 minecraft:gray_concrete
fill 271 87 247 271 88 247 minecraft:gray_concrete
fill 271 87 249 271 88 249 minecraft:gray_concrete
fill 271 87 251 271 88 251 minecraft:gray_concrete
fill 271 87 261 271 88 261 minecraft:gray_concrete
fill 272 87 242 272 88 242 minecraft:gray_concrete
setblock 272 87 255 minecraft:gray_concrete
fill 273 87 229 273 88 229 minecraft:blue_terracotta
fill 273 87 237 273 88 237 minecraft:blue_terracotta
fill 273 87 261 273 88 261 minecraft:gray_concrete
fill 273 87 269 273 88 269 minecraft:gray_concrete
fill 274 87 242 274 88 242 minecraft:gray_concrete
setblock 274 87 255 minecraft:gray_concrete
fill 275 87 229 275 88 229 minecraft:blue_terracotta
fill 275 87 237 275 88 237 minecraft:blue_terracotta
fill 275 87 261 275 88 261 minecraft:gray_concrete
fill 275 87 269 275 88 269 minecraft:gray_concrete
fill 276 87 230 276 88 230 minecraft:blue_terracotta
fill 276 87 232 276 88 232 minecraft:blue_terracotta
fill 276 87 234 276 88 234 minecraft:blue_terracotta
fill 276 87 236 276 88 236 minecraft:blue_terracotta
fill 276 87 243 276 88 243 minecraft:gray_concrete
fill 276 87 245 276 88 245 minecraft:gray_concrete
fill 276 87 247 276 88 247 minecraft:gray_concrete
fill 276 87 249 276 88 249 minecraft:gray_concrete
setblock 276 87 251 minecraft:gray_concrete
setblock 276 87 253 minecraft:gray_concrete
fill 276 87 262 276 88 262 minecraft:gray_concrete
fill 276 87 264 276 88 264 minecraft:gray_concrete
fill 276 87 266 276 88 266 minecraft:gray_concrete
fill 276 87 268 276 88 268 minecraft:gray_concrete
fill 277 87 264 277 295 264 minecraft:black_concrete
fill 277 87 268 277 98 268 minecraft:black_concrete
setblock 277 87 269 minecraft:sea_lantern
fill 235 88 255 235 135 255 minecraft:black_concrete
fill 235 88 257 235 158 257 minecraft:black_concrete
setblock 235 88 258 minecraft:blue_concrete
fill 235 88 259 235 93 262 minecraft:black_concrete
setblock 250 88 228 minecraft:verdant_froglight
fill 251 88 228 258 95 228 minecraft:black_concrete
setblock 259 88 228 minecraft:sea_lantern
fill 259 88 270 259 140 270 minecraft:black_concrete
fill 260 88 228 261 180 228 minecraft:black_concrete
setblock 268 88 265 minecraft:sea_lantern
setblock 268 88 267 minecraft:sea_lantern
setblock 268 88 269 minecraft:sea_lantern
setblock 269 88 264 minecraft:sea_lantern
setblock 269 88 266 minecraft:sea_lantern
setblock 269 88 268 minecraft:sea_lantern
setblock 270 88 251 minecraft:sea_lantern
setblock 270 88 253 minecraft:sea_lantern
setblock 270 88 255 minecraft:sea_lantern
setblock 270 88 265 minecraft:sea_lantern
setblock 270 88 267 minecraft:sea_lantern
setblock 270 88 269 minecraft:sea_lantern
setblock 271 88 250 minecraft:sea_lantern
setblock 271 88 252 minecraft:sea_lantern
setblock 271 88 254 minecraft:sea_lantern
setblock 271 88 256 minecraft:sea_lantern
setblock 271 88 264 minecraft:sea_lantern
setblock 271 88 266 minecraft:sea_lantern
setblock 271 88 268 minecraft:sea_lantern
setblock 272 88 251 minecraft:sea_lantern
setblock 272 88 253 minecraft:sea_lantern
setblock 272 88 255 minecraft:sea_lantern
setblock 272 88 265 minecraft:sea_lantern
setblock 272 88 267 minecraft:sea_lantern
setblock 272 88 269 minecraft:sea_lantern
setblock 273 88 250 minecraft:sea_lantern
setblock 273 88 252 minecraft:sea_lantern
setblock 273 88 254 minecraft:sea_lantern
setblock 273 88 256 minecraft:sea_lantern
setblock 273 88 264 minecraft:sea_lantern
setblock 273 88 266 minecraft:sea_lantern
setblock 273 88 268 minecraft:sea_lantern
setblock 274 88 251 minecraft:sea_lantern
setblock 274 88 253 minecraft:sea_lantern
setblock 274 88 255 minecraft:sea_lantern
setblock 274 88 265 minecraft:sea_lantern
setblock 274 88 267 minecraft:sea_lantern
setblock 274 88 269 minecraft:sea_lantern
setblock 275 88 250 minecraft:sea_lantern
setblock 275 88 252 minecraft:sea_lantern
setblock 275 88 254 minecraft:sea_lantern
setblock 275 88 256 minecraft:sea_lantern
fill 276 88 251 276 89 251 minecraft:sea_lantern
setblock 276 88 253 minecraft:sea_lantern
setblock 276 88 255 minecraft:sea_lantern
setblock 277 88 240 minecraft:ochre_froglight
fill 277 88 269 277 114 269 minecraft:black_concrete
fill 235 89 258 235 166 258 minecraft:black_concrete
setblock 236 89 230 minecraft:pearlescent_froglight
setblock 236 89 232 minecraft:pearlescent_froglight
setblock 236 89 234 minecraft:ochre_froglight
setblock 236 89 236 minecraft:cyan_stained_glass
setblock 236 89 243 minecraft:black_stained_glass
setblock 236 89 245 minecraft:sea_lantern
setblock 236 89 247 minecraft:sea_lantern
setblock 236 89 249 minecraft:pearlescent_froglight
setblock 236 89 251 minecraft:sea_lantern
setblock 236 89 253 minecraft:pearlescent_froglight
setblock 236 89 262 minecraft:cyan_stained_glass
setblock 236 89 264 minecraft:cyan_stained_glass
setblock 236 89 266 minecraft:cyan_stained_glass
setblock 236 89 268 minecraft:black_stained_glass
setblock 237 89 229 minecraft:ochre_froglight
setblock 237 89 237 minecraft:black_stained_glass
setblock 237 89 242 minecraft:cyan_stained_glass
setblock 237 89 255 minecraft:black_stained_glass
setblock 237 89 261 minecraft:pearlescent_froglight
setblock 237 89 269 minecraft:magenta_stained_glass
setblock 239 89 229 minecraft:black_stained_glass
setblock 239 89 237 minecraft:black_stained_glass
setblock 239 89 242 minecraft:black_stained_glass
setblock 239 89 255 minecraft:ochre_froglight
setblock 239 89 261 minecraft:black_stained_glass
setblock 239 89 269 minecraft:black_stained_glass
setblock 241 89 229 minecraft:ochre_froglight
setblock 241 89 237 minecraft:black_stained_glass
setblock 241 89 243 minecraft:black_stained_glass
setblock 241 89 245 minecraft:black_stained_glass
setblock 241 89 247 minecraft:ochre_froglight
setblock 241 89 249 minecraft:black_stained_glass
setblock 241 89 251 minecraft:pearlescent_froglight
setblock 241 89 253 minecraft:cyan_stained_glass
setblock 241 89 261 minecraft:ochre_froglight
setblock 241 89 269 minecraft:black_stained_glass
setblock 243 89 229 minecraft:light_blue_stained_glass
setblock 243 89 237 minecraft:black_stained_glass
setblock 243 89 261 minecraft:cyan_stained_glass
setblock 243 89 269 minecraft:black_stained_glass
fill 243 89 270 244 97 270 minecraft:black_concrete
fill 244 89 228 246 99 228 minecraft:black_concrete
setblock 244 89 230 minecraft:ochre_froglight
setblock 244 89 232 minecraft:light_blue_stained_glass
setblock 244 89 234 minecraft:sea_lantern
setblock 244 89 236 minecraft:black_stained_glass
setblock 244 89 262 minecraft:black_stained_glass
setblock 244 89 264 minecraft:black_stained_glass
setblock 244 89 266 minecraft:black_stained_glass
setblock 244 89 268 minecraft:light_blue_stained_glass
setblock 245 89 270 minecraft:cyan_concrete
setblock 246 89 270 minecraft:ochre_froglight
setblock 247 89 228 minecraft:ochre_froglight
fill 247 89 270 247 183 270 minecraft:black_concrete
setblock 249 89 230 minecraft:pearlescent_froglight
setblock 249 89 232 minecraft:black_stained_glass
setblock 249 89 265 minecraft:black_stained_glass
setblock 249 89 267 minecraft:black_stained_glass
fill 250 89 228 250 142 228 minecraft:black_concrete
setblock 250 89 229 minecraft:black_stained_glass
setblock 250 89 234 minecraft:black_stained_glass
setblock 250 89 269 minecraft:pearlescent_froglight
setblock 252 89 229 minecraft:magenta_stained_glass
setblock 252 89 234 minecraft:magenta_stained_glass
setblock 252 89 264 minecraft:sea_lantern
setblock 252 89 269 minecraft:black_stained_glass
setblock 254 89 229 minecraft:ochre_froglight
setblock 254 89 234 minecraft:pearlescent_froglight
setblock 256 89 229 minecraft:magenta_stained_glass
setblock 256 89 234 minecraft:magenta_stained_glass
setblock 256 89 264 minecraft:cyan_stained_glass
setblock 258 89 229 minecraft:ochre_froglight
setblock 258 89 234 minecraft:black_stained_glass
setblock 258 89 264 minecraft:cyan_stained_glass
setblock 258 89 269 minecraft:cyan_stained_glass
fill 259 89 228 259 90 228 minecraft:black_concrete
setblock 260 89 229 minecraft:black_stained_glass
setblock 260 89 234 minecraft:ochre_froglight
setblock 260 89 264 minecraft:magenta_stained_glass
setblock 260 89 269 minecraft:pearlescent_froglight
setblock 262 89 230 minecraft:black_stained_glass
setblock 262 89 232 minecraft:black_stained_glass
setblock 262 89 265 minecraft:black_stained_glass
setblock 262 89 267 minecraft:black_stained_glass
setblock 268 89 230 minecraft:black_stained_glass
setblock 268 89 232 minecraft:pearlescent_froglight
setblock 268 89 234 minecraft:black_stained_glass
setblock 268 89 236 minecraft:magenta_stained_glass
setblock 268 89 262 minecraft:sea_lantern
setblock 268 89 264 minecraft:ochre_froglight
fill 268 89 265 268 90 265 minecraft:gray_concrete
setblock 268 89 266 minecraft:black_stained_glass
fill 268 89 267 268 90 267 minecraft:gray_concrete
setblock 268 89 268 minecraft:ochre_froglight
fill 268 89 269 268 90 269 minecraft:gray_concrete
setblock 269 89 229 minecraft:pearlescent_froglight
setblock 269 89 237 minecraft:sea_lantern
setblock 269 89 261 minecraft:magenta_stained_glass
fill 269 89 264 269 90 264 minecraft:gray_concrete
fill 269 89 266 269 90 266 minecraft:gray_concrete
fill 269 89 268 269 90 268 minecraft:gray_concrete
fill 270 89 251 270 90 251 minecraft:gray_concrete
fill 270 89 253 270 90 253 minecraft:gray_concrete
fill 270 89 255 270 90 255 minecraft:gray_concrete
fill 270 89 265 270 90 265 minecraft:gray_concrete
fill 270 89 267 270 90 267 minecraft:gray_concrete
fill 270 89 269 270 90 269 minecraft:gray_concrete
fill 271 89 228 271 245 228 minecraft:black_concrete
setblock 271 89 229 minecraft:black_stained_glass
setblock 271 89 237 minecraft:black_stained_glass
setblock 271 89 243 minecraft:black_stained_glass
setblock 271 89 245 minecraft:magenta_stained_glass
setblock 271 89 247 minecraft:sea_lantern
setblock 271 89 249 minecraft:black_stained_glass
fill 271 89 250 271 90 250 minecraft:gray_concrete
setblock 271 89 251 minecraft:magenta_stained_glass
fill 271 89 252 271 90 252 minecraft:gray_concrete
setblock 271 89 253 minecraft:ochre_froglight
fill 271 89 254 271 90 254 minecraft:gray_concrete
fill 271 89 256 271 90 256 minecraft:gray_concrete
setblock 271 89 261 minecraft:black_stained_glass
fill 271 89 264 271 90 264 minecraft:gray_concrete
fill 271 89 266 271 90 266 minecraft:gray_concrete
fill 271 89 268 271 90 268 minecraft:gray_concrete
setblock 271 89 269 minecraft:ochre_froglight
setblock 272 89 228 minecraft:ochre_froglight
setblock 272 89 242 minecraft:sea_lantern
fill 272 89 251 272 90 251 minecraft:gray_concrete
fill 272 89 253 272 90 253 minecraft:gray_concrete
fill 272 89 255 272 90 255 minecraft:gray_concrete
fill 272 89 265 272 90 265 minecraft:gray_concrete
fill 272 89 267 272 90 267 minecraft:gray_concrete
fill 272 89 269 272 90 269 minecraft:gray_concrete
fill 273 89 228 277 110 228 minecraft:black_concrete
setblock 273 89 229 minecraft:sea_lantern
setblock 273 89 237 minecraft:sea_lantern
fill 273 89 250 273 90 250 minecraft:gray_concrete
fill 273 89 252 273 90 252 minecraft:gray_concrete
fill 273 89 254 273 90 254 minecraft:gray_concrete
fill 273 89 256 273 90 256 minecraft:gray_concrete
setblock 273 89 261 minecraft:light_blue_stained_glass
fill 273 89 264 273 90 264 minecraft:gray_concrete
fill 273 89 266 273 90 266 minecraft:gray_concrete
fill 273 89 268 273 90 268 minecraft:gray_concrete
setblock 273 89 269 minecraft:cyan_stained_glass
setblock 274 89 242 minecraft:magenta_stained_glass
fill 274 89 251 274 90 251 minecraft:gray_concrete
fill 274 89 253 274 90 253 minecraft:gray_concrete
setblock 274 89 255 minecraft:black_stained_glass
fill 274 89 265 274 90 265 minecraft:gray_concrete
fill 274 89 267 274 90 267 minecraft:gray_concrete
fill 274 89 269 274 90 269 minecraft:gray_concrete
setblock 275 89 229 minecraft:black_stained_glass
setblock 275 89 237 minecraft:black_stained_glass
fill 275 89 250 275 90 250 minecraft:gray_concrete
fill 275 89 252 275 90 252 minecraft:gray_concrete
fill 275 89 254 275 90 254 minecraft:gray_concrete
fill 275 89 256 275 90 256 minecraft:gray_concrete
setblock 275 89 261 minecraft:black_stained_glass
setblock 275 89 269 minecraft:pearlescent_froglight
setblock 276 89 230 minecraft:magenta_stained_glass
setblock 276 89 232 minecraft:sea_lantern
setblock 276 89 234 minecraft:light_blue_stained_glass
setblock 276 89 236 minecraft:light_blue_stained_glass
setblock 276 89 243 minecraft:black_stained_glass
setblock 276 89 245 minecraft:sea_lantern
setblock 276 89 247 minecraft:ochre_froglight
setblock 276 89 249 minecraft:pearlescent_froglight
fill 276 89 253 276 90 253 minecraft:gray_concrete
fill 276 89 255 276 90 255 minecraft:gray_concrete
setblock 276 89 262 minecraft:magenta_stained_glass
setblock 276 89 264 minecraft:black_stained_glass
setblock 276 89 266 minecraft:black_stained_glass
setblock 276 89 268 minecraft:ochre_froglight
fill 277 89 240 277 105 240 minecraft:black_concrete
setblock 277 89 267 minecraft:magenta_concrete
fill 235 90 266 235 120 268 minecraft:black_concrete
setblock 235 90 269 minecraft:sea_lantern
fill 235 90 270 235 308 270 minecraft:black_concrete
fill 236 90 230 236 91 230 minecraft:gray_concrete
fill 236 90 232 236 91 232 minecraft:gray_concrete
fill 236 90 234 236 91 234 minecraft:gray_concrete
fill 236 90 236 236 91 236 minecraft:gray_concrete
fill 236 90 243 236 91 243 minecraft:black_concrete
fill 236 90 245 236 91 245 minecraft:black_concrete
fill 236 90 247 236 91 247 minecraft:black_concrete
fill 236 90 249 236 91 249 minecraft:black_concrete
fill 236 90 251 236 91 251 minecraft:black_concrete
fill 236 90 253 236 91 253 minecraft:black_concrete
fill 236 90 262 236 91 262 minecraft:blue_terracotta
fill 236 90 264 236 91 264 minecraft:blue_terracotta
fill 236 90 266 236 91 266 minecraft:blue_terracotta
fill 236 90 268 236 91 268 minecraft:blue_terracotta
fill 237 90 229 237 91 229 minecraft:gray_concrete
fill 237 90 237 237 91 237 minecraft:gray_concrete
fill 237 90 242 237 91 242 minecraft:black_concrete
fill 237 90 255 237 91 255 minecraft:black_concrete
fill 237 90 261 237 91 261 minecraft:blue_terracotta
fill 237 90 269 237 91 269 minecraft:blue_terracotta
fill 239 90 229 239 91 229 minecraft:gray_concrete
fill 239 90 237 239 91 237 minecraft:gray_concrete
fill 239 90 242 239 91 242 minecraft:black_concrete
fill 239 90 255 239 91 255 minecraft:black_concrete
fill 239 90 261 239 91 261 minecraft:blue_terracotta
fill 239 90 269 239 91 269 minecraft:blue_terracotta
fill 241 90 229 241 91 229 minecraft:gray_concrete
fill 241 90 237 241 91 237 minecraft:gray_concrete
fill 241 90 243 241 91 243 minecraft:black_concrete
fill 241 90 245 241 91 245 minecraft:black_concrete
fill 241 90 247 241 91 247 minecraft:black_concrete
fill 241 90 249 241 91 249 minecraft:black_concrete
fill 241 90 251 241 91 251 minecraft:black_concrete
fill 241 90 253 241 91 253 minecraft:black_concrete
fill 241 90 261 241 91 261 minecraft:blue_terracotta
fill 241 90 269 241 91 269 minecraft:blue_terracotta
setblock 243 90 228 minecraft:verdant_froglight
fill 243 90 229 243 91 229 minecraft:gray_concrete
fill 243 90 237 243 91 237 minecraft:gray_concrete
fill 243 90 261 243 91 261 minecraft:blue_terracotta
fill 243 90 269 243 91 269 minecraft:blue_terracotta
fill 244 90 230 244 91 230 minecraft:gray_concrete
fill 244 90 232 244 91 232 minecraft:gray_concrete
fill 244 90 234 244 91 234 minecraft:gray_concrete
fill 244 90 236 244 91 236 minecraft:gray_concrete
fill 244 90 262 244 91 262 minecraft:blue_terracotta
fill 244 90 264 244 91 264 minecraft:blue_terracotta
fill 244 90 266 244 91 266 minecraft:blue_terracotta
fill 244 90 268 244 91 268 minecraft:blue_terracotta
fill 245 90 270 246 134 270 minecraft:black_concrete
fill 247 90 228 247 113 228 minecraft:black_concrete
fill 249 90 230 249 91 230 minecraft:gray_concrete
fill 249 90 232 249 91 232 minecraft:gray_concrete
fill 249 90 265 249 91 265 minecraft:gray_concrete
fill 249 90 267 249 91 267 minecraft:gray_concrete
fill 250 90 229 250 91 229 minecraft:gray_concrete
fill 250 90 234 250 91 234 minecraft:gray_concrete
fill 250 90 269 250 91 269 minecraft:gray_concrete
fill 252 90 229 252 91 229 minecraft:gray_concrete
fill 252 90 234 252 91 234 minecraft:gray_concrete
fill 252 90 264 252 91 264 minecraft:gray_concrete
fill 252 90 269 252 91 269 minecraft:gray_concrete
fill 254 90 229 254 91 229 minecraft:gray_concrete
fill 254 90 234 254 91 234 minecraft:gray_concrete
fill 256 90 229 256 91 229 minecraft:gray_concrete
fill 256 90 234 256 91 234 minecraft:gray_concrete
fill 256 90 264 256 94 264 minecraft:gray_concrete
fill 258 90 229 258 91 229 minecraft:gray_concrete
fill 258 90 234 258 91 234 minecraft:gray_concrete
fill 258 90 264 258 91 264 minecraft:gray_concrete
fill 258 90 269 258 91 269 minecraft:gray_concrete
fill 260 90 229 260 91 229 minecraft:gray_concrete
fill 260 90 234 260 91 234 minecraft:gray_concrete
fill 260 90 264 260 91 264 minecraft:gray_concrete
fill 260 90 269 260 91 269 minecraft:gray_concrete
fill 262 90 230 262 91 230 minecraft:gray_concrete
fill 262 90 232 262 91 232 minecraft:gray_concrete
fill 262 90 265 262 91 265 minecraft:gray_concrete
fill 262 90 267 262 91 267 minecraft:gray_concrete
fill 268 90 230 268 91 230 minecraft:blue_terracotta
fill 268 90 232 268 91 232 minecraft:blue_terracotta
fill 268 90 234 268 91 234 minecraft:blue_terracotta
fill 268 90 236 268 91 236 minecraft:blue_terracotta
fill 268 90 262 268 91 262 minecraft:gray_concrete
fill 268 90 264 268 91 264 minecraft:gray_concrete
fill 268 90 266 268 91 266 minecraft:gray_concrete
fill 268 90 268 268 91 268 minecraft:gray_concrete
fill 269 90 229 269 91 229 minecraft:blue_terracotta
fill 269 90 237 269 91 237 minecraft:blue_terracotta
fill 269 90 261 269 91 261 minecraft:gray_concrete
fill 271 90 229 271 91 229 minecraft:blue_terracotta
fill 271 90 237 271 91 237 minecraft:blue_terracotta
fill 271 90 243 271 91 243 minecraft:gray_concrete
fill 271 90 245 271 91 245 minecraft:gray_concrete
fill 271 90 247 271 91 247 minecraft:gray_concrete
fill 271 90 249 271 91 249 minecraft:gray_concrete
fill 271 90 251 271 91 251 minecraft:gray_concrete
fill 271 90 253 271 91 253 minecraft:gray_concrete
fill 271 90 261 271 91 261 minecraft:gray_concrete
fill 271 90 269 271 91 269 minecraft:gray_concrete
fill 272 90 228 272 103 228 minecraft:black_concrete
fill 272 90 242 272 91 242 minecraft:gray_concrete
fill 273 90 229 273 91 229 minecraft:blue_terracotta
fill 273 90 237 273 91 237 minecraft:blue_terracotta
fill 273 90 261 273 91 261 minecraft:gray_concrete
fill 273 90 269 273 91 269 minecraft:gray_concrete
fill 274 90 242 274 91 242 minecraft:gray_concrete
setblock 274 90 255 minecraft:gray_concrete
fill 275 90 229 275 91 229 minecraft:blue_terracotta
fill 275 90 237 275 91 237 minecraft:blue_terracotta
fill 275 90 261 275 91 261 minecraft:gray_concrete
fill 275 90 269 275 91 269 minecraft:gray_concrete
fill 276 90 230 276 91 230 minecraft:blue_terracotta
fill 276 90 232 276 91 232 minecraft:blue_terracotta
fill 276 90 234 276 91 234 minecraft:blue_terracotta
fill 276 90 236 276 91 236 minecraft:blue_terracotta
fill 276 90 243 276 91 243 minecraft:gray_concrete
fill 276 90 245 276 91 245 minecraft:gray_concrete
fill 276 90 247 276 91 247 minecraft:gray_concrete
fill 276 90 249 276 91 249 minecraft:gray_concrete
setblock 276 90 251 minecraft:gray_concrete
fill 276 90 262 276 91 262 minecraft:gray_concrete
fill 276 90 264 276 91 264 minecraft:gray_concrete
fill 276 90 266 276 91 266 minecraft:gray_concrete
fill 276 90 268 276 91 268 minecraft:gray_concrete
setblock 277 90 246 minecraft:magenta_concrete
fill 277 90 267 277 151 267 minecraft:black_concrete
fill 235 91 243 235 107 249 minecraft:black_concrete
setblock 235 91 250 minecraft:pearlescent_froglight
fill 235 91 251 235 145 252 minecraft:black_concrete
fill 235 91 269 235 127 269 minecraft:black_concrete
setblock 238 91 238 minecraft:light[level=12]
setblock 238 91 259 minecraft:light[level=12]
fill 240 91 270 240 96 270 minecraft:black_concrete
setblock 241 91 270 minecraft:purple_concrete
fill 243 91 228 243 98 228 minecraft:black_concrete
setblock 245 91 231 minecraft:light[level=12]
setblock 245 91 238 minecraft:light[level=12]
setblock 245 91 245 minecraft:light[level=12]
setblock 245 91 252 minecraft:light[level=12]
setblock 245 91 259 minecraft:light[level=12]
setblock 245 91 266 minecraft:light[level=12]
setblock 252 91 238 minecraft:light[level=12]
setblock 252 91 245 minecraft:light[level=12]
setblock 252 91 252 minecraft:light[level=12]
setblock 252 91 259 minecraft:light[level=12]
setblock 259 91 228 minecraft:ochre_froglight
setblock 259 91 238 minecraft:light[level=12]
setblock 259 91 245 minecraft:light[level=12]
setblock 259 91 252 minecraft:light[level=12]
setblock 259 91 259 minecraft:light[level=12]
setblock 266 91 231 minecraft:light[level=12]
setblock 266 91 238 minecraft:light[level=12]
setblock 266 91 245 minecraft:light[level=12]
setblock 266 91 252 minecraft:light[level=12]
setblock 266 91 259 minecraft:light[level=12]
setblock 266 91 266 minecraft:light[level=12]
fill 266 91 267 267 104 267 minecraft:cyan_wool
setblock 268 91 265 minecraft:sea_lantern
setblock 268 91 267 minecraft:sea_lantern
setblock 268 91 269 minecraft:sea_lantern
setblock 269 91 264 minecraft:sea_lantern
setblock 269 91 266 minecraft:sea_lantern
setblock 269 91 268 minecraft:sea_lantern
setblock 270 91 251 minecraft:sea_lantern
setblock 270 91 253 minecraft:sea_lantern
setblock 270 91 255 minecraft:sea_lantern
setblock 270 91 265 minecraft:sea_lantern
setblock 270 91 267 minecraft:sea_lantern
setblock 270 91 269 minecraft:sea_lantern
setblock 271 91 250 minecraft:sea_lantern
setblock 271 91 252 minecraft:sea_lantern
setblock 271 91 254 minecraft:sea_lantern
setblock 271 91 256 minecraft:sea_lantern
setblock 271 91 264 minecraft:sea_lantern
setblock 271 91 266 minecraft:sea_lantern
setblock 271 91 268 minecraft:sea_lantern
setblock 272 91 251 minecraft:sea_lantern
setblock 272 91 253 minecraft:sea_lantern
setblock 272 91 255 minecraft:sea_lantern
setblock 272 91 265 minecraft:sea_lantern
setblock 272 91 267 minecraft:sea_lantern
setblock 272 91 269 minecraft:sea_lantern
setblock 273 91 238 minecraft:light[level=12]
setblock 273 91 250 minecraft:sea_lantern
setblock 273 91 252 minecraft:sea_lantern
setblock 273 91 254 minecraft:sea_lantern
setblock 273 91 256 minecraft:sea_lantern
setblock 273 91 259 minecraft:light[level=12]
setblock 273 91 264 minecraft:sea_lantern
setblock 273 91 266 minecraft:sea_lantern
setblock 273 91 268 minecraft:sea_lantern
setblock 274 91 251 minecraft:sea_lantern
setblock 274 91 253 minecraft:sea_lantern
setblock 274 91 255 minecraft:sea_lantern
setblock 274 91 265 minecraft:sea_lantern
setblock 274 91 267 minecraft:sea_lantern
setblock 274 91 269 minecraft:sea_lantern
setblock 275 91 250 minecraft:sea_lantern
setblock 275 91 252 minecraft:sea_lantern
setblock 275 91 254 minecraft:sea_lantern
setblock 275 91 256 minecraft:sea_lantern
setblock 276 91 251 minecraft:sea_lantern
setblock 276 91 253 minecraft:sea_lantern
setblock 276 91 255 minecraft:sea_lantern
fill 277 91 246 277 103 246 minecraft:black_concrete
fill 235 92 250 235 120 250 minecraft:black_concrete
setblock 235 92 264 minecraft:blue_concrete
setblock 236 92 230 minecraft:black_stained_glass
setblock 236 92 232 minecraft:black_stained_glass
setblock 236 92 234 minecraft:black_stained_glass
setblock 236 92 236 minecraft:ochre_froglight
setblock 236 92 243 minecraft:cyan_stained_glass
setblock 236 92 245 minecraft:magenta_stained_glass
setblock 236 92 247 minecraft:sea_lantern
setblock 236 92 249 minecraft:black_stained_glass
setblock 236 92 251 minecraft:sea_lantern
setblock 236 92 253 minecraft:ochre_froglight
setblock 236 92 262 minecraft:ochre_froglight
setblock 236 92 264 minecraft:black_stained_glass
setblock 236 92 266 minecraft:black_stained_glass
setblock 236 92 268 minecraft:sea_lantern
setblock 237 92 229 minecraft:sea_lantern
setblock 237 92 237 minecraft:pearlescent_froglight
setblock 237 92 242 minecraft:ochre_froglight
setblock 237 92 255 minecraft:black_stained_glass
setblock 237 92 261 minecraft:ochre_froglight
setblock 237 92 269 minecraft:cyan_stained_glass
setblock 239 92 229 minecraft:ochre_froglight
setblock 239 92 237 minecraft:black_stained_glass
setblock 239 92 242 minecraft:black_stained_glass
setblock 239 92 255 minecraft:cyan_stained_glass
setblock 239 92 261 minecraft:black_stained_glass
setblock 239 92 269 minecraft:black_stained_glass
setblock 241 92 229 minecraft:magenta_stained_glass
setblock 241 92 237 minecraft:black_stained_glass
setblock 241 92 243 minecraft:sea_lantern
setblock 241 92 245 minecraft:light_blue_stained_glass
setblock 241 92 247 minecraft:sea_lantern
setblock 241 92 249 minecraft:black_stained_glass
setblock 241 92 251 minecraft:light_blue_stained_glass
setblock 241 92 253 minecraft:black_stained_glass
setblock 241 92 261 minecraft:ochre_froglight
setblock 241 92 269 minecraft:sea_lantern
fill 241 92 270 241 137 270 minecraft:black_concrete
setblock 243 92 229 minecraft:light_blue_stained_glass
setblock 243 92 237 minecraft:light_blue_stained_glass
setblock 243 92 261 minecraft:sea_lantern
setblock 243 92 269 minecraft:magenta_stained_glass
setblock 244 92 230 minecraft:ochre_froglight
setblock 244 92 232 minecraft:black_stained_glass
setblock 244 92 234 minecraft:black_stained_glass
setblock 244 92 236 minecraft:black_stained_glass
setblock 244 92 262 minecraft:cyan_stained_glass
setblock 244 92 264 minecraft:black_stained_glass
setblock 244 92 266 minecraft:black_stained_glass
setblock 244 92 268 minecraft:black_stained_glass
setblock 249 92 230 minecraft:cyan_stained_glass
setblock 249 92 232 minecraft:black_stained_glass
setblock 249 92 265 minecraft:black_stained_glass
setblock 249 92 267 minecraft:pearlescent_froglight
setblock 250 92 229 minecraft:cyan_stained_glass
setblock 250 92 234 minecraft:cyan_stained_glass
setblock 250 92 264 minecraft:black_stained_glass
setblock 250 92 269 minecraft:magenta_stained_glass
setblock 252 92 229 minecraft:pearlescent_froglight
setblock 252 92 234 minecraft:black_stained_glass
setblock 252 92 264 minecraft:black_stained_glass
setblock 252 92 269 minecraft:black_stained_glass
setblock 254 92 229 minecraft:pearlescent_froglight
setblock 254 92 234 minecraft:pearlescent_froglight
setblock 254 92 264 minecraft:ochre_froglight
setblock 254 92 269 minecraft:sea_lantern
setblock 256 92 229 minecraft:ochre_froglight
setblock 256 92 234 minecraft:cyan_stained_glass
setblock 256 92 269 minecraft:pearlescent_froglight
setblock 258 92 229 minecraft:ochre_froglight
setblock 258 92 234 minecraft:cyan_stained_glass
setblock 258 92 264 minecraft:pearlescent_froglight
setblock 258 92 269 minecraft:black_stained_glass
fill 259 92 228 259 142 228 minecraft:black_concrete
setblock 260 92 229 minecraft:light_blue_stained_glass
setblock 260 92 234 minecraft:pearlescent_froglight
setblock 260 92 264 minecraft:ochre_froglight
setblock 260 92 269 minecraft:pearlescent_froglight
setblock 262 92 230 minecraft:black_stained_glass
setblock 262 92 232 minecraft:cyan_stained_glass
setblock 262 92 265 minecraft:sea_lantern
setblock 262 92 267 minecraft:pearlescent_froglight
setblock 268 92 230 minecraft:cyan_stained_glass
setblock 268 92 232 minecraft:black_stained_glass
setblock 268 92 234 minecraft:black_stained_glass
setblock 268 92 236 minecraft:black_stained_glass
setblock 268 92 262 minecraft:black_stained_glass
setblock 268 92 264 minecraft:black_stained_glass
fill 268 92 265 268 177 265 minecraft:gray_concrete
setblock 268 92 266 minecraft:cyan_stained_glass
fill 268 92 267 268 185 267 minecraft:gray_concrete
setblock 268 92 268 minecraft:pearlescent_froglight
fill 268 92 269 268 185 269 minecraft:gray_concrete
setblock 269 92 229 minecraft:ochre_froglight
setblock 269 92 237 minecraft:sea_lantern
setblock 269 92 261 minecraft:pearlescent_froglight
fill 269 92 264 269 185 264 minecraft:gray_concrete
fill 269 92 266 269 177 266 minecraft:gray_concrete
fill 269 92 268 269 185 268 minecraft:gray_concrete
setblock 269 92 269 minecraft:black_stained_glass
fill 270 92 251 270 93 251 minecraft:gray_concrete
fill 270 92 253 270 93 253 minecraft:gray_concrete
fill 270 92 255 270 93 255 minecraft:gray_concrete
fill 270 92 265 270 176 265 minecraft:gray_concrete
fill 270 92 267 270 185 267 minecraft:gray_concrete
fill 270 92 269 270 185 269 minecraft:gray_concrete
setblock 271 92 229 minecraft:black_stained_glass
setblock 271 92 237 minecraft:black_stained_glass
setblock 271 92 243 minecraft:magenta_stained_glass
setblock 271 92 245 minecraft:cyan_stained_glass
setblock 271 92 247 minecraft:black_stained_glass
setblock 271 92 249 minecraft:pearlescent_froglight
fill 271 92 250 271 93 250 minecraft:gray_concrete
setblock 271 92 251 minecraft:sea_lantern
fill 271 92 252 271 93 252 minecraft:gray_concrete
setblock 271 92 253 minecraft:magenta_stained_glass
fill 271 92 254 271 93 254 minecraft:gray_concrete
fill 271 92 256 271 93 256 minecraft:gray_concrete
setblock 271 92 261 minecraft:ochre_froglight
fill 271 92 264 271 173 264 minecraft:gray_concrete
fill 271 92 266 271 177 266 minecraft:gray_concrete
fill 271 92 268 271 185 268 minecraft:gray_concrete
setblock 271 92 269 minecraft:black_stained_glass
setblock 272 92 242 minecraft:pearlescent_froglight
fill 272 92 251 272 93 251 minecraft:gray_concrete
fill 272 92 253 272 93 253 minecraft:gray_concrete
setblock 272 92 255 minecraft:magenta_stained_glass
fill 272 92 265 272 172 265 minecraft:gray_concrete
fill 272 92 267 272 185 267 minecraft:gray_concrete
fill 272 92 269 272 185 269 minecraft:gray_concrete
setblock 273 92 229 minecraft:ochre_froglight
setblock 273 92 237 minecraft:cyan_stained_glass
fill 273 92 250 273 93 250 minecraft:gray_concrete
fill 273 92 252 273 93 252 minecraft:gray_concrete
fill 273 92 254 273 93 254 minecraft:gray_concrete
fill 273 92 256 273 93 256 minecraft:gray_concrete
setblock 273 92 261 minecraft:pearlescent_froglight
fill 273 92 264 273 173 264 minecraft:gray_concrete
fill 273 92 266 273 185 266 minecraft:gray_concrete
fill 273 92 268 273 185 268 minecraft:gray_concrete
setblock 273 92 269 minecraft:sea_lantern
setblock 274 92 242 minecraft:black_stained_glass
fill 274 92 251 274 93 251 minecraft:gray_concrete
fill 274 92 253 274 93 253 minecraft:gray_concrete
setblock 274 92 255 minecraft:black_stained_glass
fill 274 92 265 274 185 265 minecraft:gray_concrete
fill 274 92 267 274 185 267 minecraft:gray_concrete
fill 274 92 269 274 185 269 minecraft:gray_concrete
setblock 275 92 229 minecraft:cyan_stained_glass
setblock 275 92 237 minecraft:light_blue_stained_glass
fill 275 92 250 275 93 250 minecraft:gray_concrete
fill 275 92 252 275 93 252 minecraft:gray_concrete
fill 275 92 254 275 93 254 minecraft:gray_concrete
fill 275 92 256 275 93 256 minecraft:gray_concrete
setblock 275 92 261 minecraft:ochre_froglight
setblock 275 92 269 minecraft:black_stained_glass
setblock 276 92 230 minecraft:black_stained_glass
setblock 276 92 232 minecraft:ochre_froglight
setblock 276 92 234 minecraft:cyan_stained_glass
setblock 276 92 236 minecraft:black_stained_glass
setblock 276 92 243 minecraft:ochre_froglight
setblock 276 92 245 minecraft:black_stained_glass
setblock 276 92 247 minecraft:pearlescent_froglight
setblock 276 92 249 minecraft:sea_lantern
setblock 276 92 251 minecraft:magenta_stained_glass
setblock 276 92 253 minecraft:magenta_stained_glass
fill 276 92 255 276 93 255 minecraft:gray_concrete
setblock 276 92 262 minecraft:magenta_stained_glass
setblock 276 92 264 minecraft:black_stained_glass
setblock 276 92 266 minecraft:pearlescent_froglight
setblock 276 92 268 minecraft:black_stained_glass
setblock 277 92 233 minecraft:sea_lantern
fill 277 92 234 277 172 234 minecraft:black_concrete
setblock 277 92 241 minecraft:verdant_froglight
fill 235 93 264 235 116 264 minecraft:black_concrete
setblock 235 93 265 minecraft:purple_concrete
fill 236 93 230 236 94 230 minecraft:gray_concrete
fill 236 93 232 236 94 232 minecraft:gray_concrete
fill 236 93 234 236 94 234 minecraft:gray_concrete
fill 236 93 236 236 94 236 minecraft:gray_concrete
fill 236 93 243 236 94 243 minecraft:black_concrete
fill 236 93 245 236 94 245 minecraft:black_concrete
fill 236 93 247 236 94 247 minecraft:black_concrete
fill 236 93 249 236 94 249 minecraft:black_concrete
fill 236 93 251 236 94 251 minecraft:black_concrete
fill 236 93 253 236 94 253 minecraft:black_concrete
fill 236 93 262 236 94 262 minecraft:blue_terracotta
fill 236 93 264 236 94 264 minecraft:blue_terracotta
fill 236 93 266 236 94 266 minecraft:blue_terracotta
fill 236 93 268 236 94 268 minecraft:blue_terracotta
fill 237 93 229 237 94 229 minecraft:gray_concrete
fill 237 93 237 237 94 237 minecraft:gray_concrete
fill 237 93 242 237 94 242 minecraft:black_concrete
fill 237 93 255 237 94 255 minecraft:black_concrete
fill 237 93 261 237 94 261 minecraft:blue_terracotta
fill 237 93 269 237 94 269 minecraft:blue_terracotta
fill 239 93 229 239 94 229 minecraft:gray_concrete
fill 239 93 237 239 94 237 minecraft:gray_concrete
fill 239 93 242 239 94 242 minecraft:black_concrete
fill 239 93 255 239 94 255 minecraft:black_concrete
fill 239 93 261 239 94 261 minecraft:blue_terracotta
fill 239 93 269 239 94 269 minecraft:blue_terracotta
fill 240 93 228 240 108 228 minecraft:black_concrete
setblock 241 93 228 minecraft:purple_concrete
fill 241 93 229 241 94 229 minecraft:gray_concrete
fill 241 93 237 241 94 237 minecraft:gray_concrete
fill 241 93 243 241 94 243 minecraft:black_concrete
fill 241 93 245 241 94 245 minecraft:black_concrete
fill 241 93 247 241 94 247 minecraft:black_concrete
fill 241 93 249 241 94 249 minecraft:black_concrete
fill 241 93 251 241 94 251 minecraft:black_concrete
fill 241 93 253 241 94 253 minecraft:black_concrete
fill 241 93 261 241 94 261 minecraft:blue_terracotta
fill 241 93 269 241 94 269 minecraft:blue_terracotta
fill 243 93 229 243 94 229 minecraft:gray_concrete
fill 243 93 237 243 94 237 minecraft:gray_concrete
fill 243 93 261 243 94 261 minecraft:blue_terracotta
fill 243 93 269 243 94 269 minecraft:blue_terracotta
fill 244 93 230 244 94 230 minecraft:gray_concrete
fill 244 93 232 244 94 232 minecraft:gray_concrete
fill 244 93 234 244 94 234 minecraft:gray_concrete
fill 244 93 236 244 94 236 minecraft:gray_concrete
fill 244 93 262 244 94 262 minecraft:blue_terracotta
fill 244 93 264 244 94 264 minecraft:blue_terracotta
fill 244 93 266 244 94 266 minecraft:blue_terracotta
fill 244 93 268 244 94 268 minecraft:blue_terracotta
fill 249 93 230 249 94 230 minecraft:gray_concrete
fill 249 93 232 249 94 232 minecraft:gray_concrete
fill 249 93 265 249 94 265 minecraft:gray_concrete
fill 249 93 267 249 94 267 minecraft:gray_concrete
fill 250 93 229 250 94 229 minecraft:gray_concrete
fill 250 93 234 250 94 234 minecraft:gray_concrete
fill 250 93 264 250 94 264 minecraft:gray_concrete
fill 250 93 269 250 94 269 minecraft:gray_concrete
fill 252 93 229 252 94 229 minecraft:gray_concrete
fill 252 93 234 252 94 234 minecraft:gray_concrete
fill 252 93 264 252 94 264 minecraft:gray_concrete
fill 252 93 269 252 94 269 minecraft:gray_concrete
fill 254 93 229 254 94 229 minecraft:gray_concrete
fill 254 93 234 254 94 234 minecraft:gray_concrete
fill 254 93 264 254 94 264 minecraft:gray_concrete
fill 254 93 269 254 94 269 minecraft:gray_concrete
fill 256 93 229 256 94 229 minecraft:gray_concrete
fill 256 93 234 256 94 234 minecraft:gray_concrete
fill 256 93 269 256 94 269 minecraft:gray_concrete
fill 258 93 229 258 94 229 minecraft:gray_concrete
fill 258 93 234 258 94 234 minecraft:gray_concrete
fill 258 93 264 258 94 264 minecraft:gray_concrete
fill 258 93 269 258 94 269 minecraft:gray_concrete
fill 260 93 229 260 94 229 minecraft:gray_concrete
fill 260 93 234 260 94 234 minecraft:gray_concrete
fill 260 93 264 260 94 264 minecraft:gray_concrete
fill 260 93 269 260 94 269 minecraft:gray_concrete
fill 262 93 230 262 94 230 minecraft:gray_concrete
fill 262 93 232 262 94 232 minecraft:gray_concrete
fill 262 93 265 262 94 265 minecraft:gray_concrete
fill 262 93 267 262 94 267 minecraft:gray_concrete
fill 268 93 230 268 94 230 minecraft:blue_terracotta
fill 268 93 232 268 94 232 minecraft:blue_terracotta
fill 268 93 234 268 94 234 minecraft:blue_terracotta
fill 268 93 236 268 94 236 minecraft:blue_terracotta
fill 268 93 262 268 94 262 minecraft:gray_concrete
fill 268 93 264 268 94 264 minecraft:gray_concrete
fill 268 93 266 268 94 266 minecraft:gray_concrete
fill 268 93 268 268 94 268 minecraft:gray_concrete
fill 269 93 229 269 94 229 minecraft:blue_terracotta
fill 269 93 237 269 94 237 minecraft:blue_terracotta
fill 269 93 261 269 94 261 minecraft:gray_concrete
fill 269 93 269 269 94 269 minecraft:gray_concrete
fill 271 93 229 271 94 229 minecraft:blue_terracotta
fill 271 93 237 271 94 237 minecraft:blue_terracotta
fill 271 93 243 271 94 243 minecraft:gray_concrete
fill 271 93 245 271 94 245 minecraft:gray_concrete
fill 271 93 247 271 94 247 minecraft:gray_concrete
fill 271 93 249 271 94 249 minecraft:gray_concrete
fill 271 93 251 271 94 251 minecraft:gray_concrete
fill 271 93 253 271 94 253 minecraft:gray_concrete
fill 271 93 261 271 94 261 minecraft:gray_concrete
fill 271 93 269 271 94 269 minecraft:gray_concrete
fill 272 93 242 272 94 242 minecraft:gray_concrete
setblock 272 93 255 minecraft:gray_concrete
fill 273 93 229 273 94 229 minecraft:blue_terracotta
fill 273 93 237 273 94 237 minecraft:blue_terracotta
fill 273 93 261 273 94 261 minecraft:gray_concrete
fill 273 93 269 273 94 269 minecraft:gray_concrete
fill 274 93 242 274 94 242 minecraft:gray_concrete
setblock 274 93 255 minecraft:gray_concrete
fill 275 93 229 275 94 229 minecraft:blue_terracotta
fill 275 93 237 275 94 237 minecraft:blue_terracotta
fill 275 93 261 275 94 261 minecraft:gray_concrete
fill 275 93 269 275 94 269 minecraft:gray_concrete
fill 276 93 230 276 94 230 minecraft:blue_terracotta
fill 276 93 232 276 94 232 minecraft:blue_terracotta
fill 276 93 234 276 94 234 minecraft:blue_terracotta
fill 276 93 236 276 94 236 minecraft:blue_terracotta
fill 276 93 243 276 94 243 minecraft:gray_concrete
fill 276 93 245 276 94 245 minecraft:gray_concrete
fill 276 93 247 276 94 247 minecraft:gray_concrete
fill 276 93 249 276 94 249 minecraft:gray_concrete
setblock 276 93 251 minecraft:gray_concrete
setblock 276 93 253 minecraft:gray_concrete
fill 276 93 262 276 94 262 minecraft:gray_concrete
fill 276 93 264 276 94 264 minecraft:gray_concrete
fill 276 93 266 276 94 266 minecraft:gray_concrete
fill 276 93 268 276 94 268 minecraft:gray_concrete
fill 277 93 233 277 100 233 minecraft:black_concrete
fill 277 93 241 277 157 241 minecraft:black_concrete
fill 235 94 228 235 94 230 minecraft:black_concrete
setblock 235 94 231 minecraft:magenta_concrete
fill 235 94 232 235 104 234 minecraft:black_concrete
fill 235 94 259 235 138 260 minecraft:black_concrete
setblock 235 94 261 minecraft:blue_concrete
fill 235 94 262 235 228 262 minecraft:black_concrete
fill 235 94 265 235 95 265 minecraft:black_concrete
setblock 238 94 239 minecraft:light[level=15]
setblock 241 94 228 minecraft:black_concrete
setblock 246 94 231 minecraft:light[level=15]
setblock 246 94 239 minecraft:light[level=15]
setblock 246 94 247 minecraft:light[level=15]
setblock 246 94 255 minecraft:light[level=15]
setblock 246 94 263 minecraft:light[level=15]
setblock 254 94 239 minecraft:light[level=15]
setblock 254 94 247 minecraft:light[level=15]
setblock 254 94 255 minecraft:light[level=15]
setblock 254 94 263 minecraft:light[level=15]
setblock 262 94 239 minecraft:light[level=15]
setblock 262 94 247 minecraft:light[level=15]
setblock 262 94 255 minecraft:light[level=15]
setblock 262 94 263 minecraft:light[level=15]
setblock 270 94 239 minecraft:light[level=15]
setblock 270 94 247 minecraft:light[level=15]
setblock 270 94 251 minecraft:sea_lantern
setblock 270 94 253 minecraft:sea_lantern
setblock 270 94 255 minecraft:sea_lantern
setblock 271 94 250 minecraft:sea_lantern
setblock 271 94 252 minecraft:sea_lantern
setblock 271 94 254 minecraft:sea_lantern
setblock 271 94 256 minecraft:sea_lantern
setblock 272 94 251 minecraft:sea_lantern
setblock 272 94 253 minecraft:sea_lantern
setblock 272 94 255 minecraft:sea_lantern
setblock 273 94 250 minecraft:sea_lantern
setblock 273 94 252 minecraft:sea_lantern
setblock 273 94 254 minecraft:sea_lantern
setblock 273 94 256 minecraft:sea_lantern
setblock 274 94 251 minecraft:sea_lantern
setblock 274 94 253 minecraft:sea_lantern
setblock 274 94 255 minecraft:sea_lantern
setblock 275 94 250 minecraft:sea_lantern
setblock 275 94 252 minecraft:sea_lantern
setblock 275 94 254 minecraft:sea_lantern
setblock 275 94 256 minecraft:sea_lantern
setblock 276 94 251 minecraft:sea_lantern
setblock 276 94 253 minecraft:sea_lantern
setblock 276 94 255 minecraft:sea_lantern
fill 235 95 228 235 103 229 minecraft:black_concrete
setblock 235 95 230 minecraft:blue_concrete
fill 235 95 231 235 167 231 minecraft:black_concrete
fill 235 95 261 235 105 261 minecraft:black_concrete
setblock 236 95 230 minecraft:light_blue_stained_glass
setblock 236 95 232 minecraft:light_blue_stained_glass
setblock 236 95 234 minecraft:ochre_froglight
setblock 236 95 236 minecraft:sea_lantern
setblock 236 95 243 minecraft:ochre_froglight
setblock 236 95 245 minecraft:black_stained_glass
setblock 236 95 247 minecraft:light_blue_stained_glass
setblock 236 95 249 minecraft:sea_lantern
setblock 236 95 251 minecraft:pearlescent_froglight
setblock 236 95 253 minecraft:black_stained_glass
setblock 236 95 262 minecraft:black_stained_glass
setblock 236 95 264 minecraft:cyan_stained_glass
setblock 236 95 266 minecraft:black_stained_glass
setblock 236 95 268 minecraft:black_stained_glass
setblock 237 95 229 minecraft:pearlescent_froglight
setblock 237 95 237 minecraft:magenta_stained_glass
setblock 237 95 242 minecraft:black_stained_glass
setblock 237 95 255 minecraft:black_stained_glass
setblock 237 95 261 minecraft:ochre_froglight
setblock 237 95 269 minecraft:black_stained_glass
setblock 239 95 229 minecraft:black_stained_glass
setblock 239 95 237 minecraft:black_stained_glass
setblock 239 95 242 minecraft:black_stained_glass
setblock 239 95 255 minecraft:magenta_stained_glass
setblock 239 95 261 minecraft:light_blue_stained_glass
setblock 239 95 269 minecraft:black_stained_glass
setblock 241 95 228 minecraft:cyan_concrete
setblock 241 95 229 minecraft:sea_lantern
setblock 241 95 237 minecraft:light_blue_stained_glass
setblock 241 95 243 minecraft:light_blue_stained_glass
setblock 241 95 245 minecraft:black_stained_glass
setblock 241 95 247 minecraft:black_stained_glass
setblock 241 95 249 minecraft:light_blue_stained_glass
setblock 241 95 251 minecraft:magenta_stained_glass
setblock 241 95 253 minecraft:black_stained_glass
setblock 241 95 261 minecraft:magenta_stained_glass
setblock 241 95 269 minecraft:sea_lantern
setblock 243 95 229 minecraft:sea_lantern
setblock 243 95 237 minecraft:cyan_stained_glass
setblock 243 95 261 minecraft:cyan_stained_glass
setblock 243 95 269 minecraft:black_stained_glass
setblock 244 95 230 minecraft:ochre_froglight
setblock 244 95 232 minecraft:black_stained_glass
setblock 244 95 234 minecraft:black_stained_glass
setblock 244 95 236 minecraft:magenta_stained_glass
setblock 244 95 262 minecraft:light_blue_stained_glass
setblock 244 95 264 minecraft:ochre_froglight
setblock 244 95 266 minecraft:black_stained_glass
setblock 244 95 268 minecraft:ochre_froglight
setblock 249 95 230 minecraft:light_blue_stained_glass
setblock 249 95 232 minecraft:pearlescent_froglight
setblock 249 95 265 minecraft:cyan_stained_glass
setblock 249 95 267 minecraft:black_stained_glass
setblock 250 95 229 minecraft:pearlescent_froglight
setblock 250 95 234 minecraft:black_stained_glass
setblock 250 95 264 minecraft:light_blue_stained_glass
setblock 250 95 269 minecraft:sea_lantern
setblock 252 95 229 minecraft:black_stained_glass
setblock 252 95 234 minecraft:black_stained_glass
setblock 252 95 264 minecraft:cyan_stained_glass
setblock 252 95 269 minecraft:ochre_froglight
setblock 254 95 229 minecraft:black_stained_glass
setblock 254 95 234 minecraft:ochre_froglight
setblock 254 95 264 minecraft:sea_lantern
setblock 254 95 269 minecraft:black_stained_glass
setblock 256 95 229 minecraft:cyan_stained_glass
setblock 256 95 234 minecraft:black_stained_glass
setblock 256 95 264 minecraft:cyan_stained_glass
setblock 256 95 269 minecraft:light_blue_stained_glass
setblock 258 95 229 minecraft:black_stained_glass
setblock 258 95 234 minecraft:sea_lantern
setblock 258 95 264 minecraft:black_stained_glass
setblock 258 95 269 minecraft:pearlescent_froglight
setblock 260 95 229 minecraft:magenta_stained_glass
setblock 260 95 234 minecraft:black_stained_glass
setblock 260 95 264 minecraft:pearlescent_froglight
setblock 260 95 269 minecraft:black_stained_glass
setblock 262 95 230 minecraft:cyan_stained_glass
setblock 262 95 232 minecraft:black_stained_glass
setblock 262 95 265 minecraft:magenta_stained_glass
setblock 262 95 267 minecraft:black_stained_glass
setblock 268 95 230 minecraft:black_stained_glass
setblock 268 95 232 minecraft:cyan_stained_glass
setblock 268 95 234 minecraft:sea_lantern
setblock 268 95 236 minecraft:cyan_stained_glass
setblock 268 95 262 minecraft:pearlescent_froglight
setblock 268 95 264 minecraft:light_blue_stained_glass
setblock 268 95 266 minecraft:pearlescent_froglight
setblock 268 95 268 minecraft:pearlescent_froglight
setblock 269 95 229 minecraft:black_stained_glass
setblock 269 95 237 minecraft:ochre_froglight
setblock 269 95 261 minecraft:black_stained_glass
setblock 269 95 269 minecraft:pearlescent_froglight
fill 270 95 251 270 96 251 minecraft:gray_concrete
fill 270 95 253 270 96 253 minecraft:gray_concrete
fill 270 95 255 270 96 255 minecraft:gray_concrete
setblock 271 95 229 minecraft:magenta_stained_glass
setblock 271 95 237 minecraft:cyan_stained_glass
setblock 271 95 243 minecraft:black_stained_glass
setblock 271 95 245 minecraft:black_stained_glass
setblock 271 95 247 minecraft:sea_lantern
setblock 271 95 249 minecraft:cyan_stained_glass
fill 271 95 250 271 96 250 minecraft:gray_concrete
setblock 271 95 251 minecraft:cyan_stained_glass
fill 271 95 252 271 96 252 minecraft:gray_concrete
setblock 271 95 253 minecraft:black_stained_glass
fill 271 95 254 271 96 254 minecraft:gray_concrete
fill 271 95 256 271 96 256 minecraft:gray_concrete
setblock 271 95 261 minecraft:magenta_stained_glass
setblock 271 95 269 minecraft:pearlescent_froglight
setblock 272 95 242 minecraft:pearlescent_froglight
fill 272 95 251 272 96 251 minecraft:gray_concrete
fill 272 95 253 272 96 253 minecraft:gray_concrete
setblock 272 95 255 minecraft:black_stained_glass
setblock 273 95 229 minecraft:pearlescent_froglight
setblock 273 95 237 minecraft:cyan_stained_glass
fill 273 95 250 273 96 250 minecraft:gray_concrete
fill 273 95 252 273 96 252 minecraft:gray_concrete
fill 273 95 254 273 96 254 minecraft:gray_concrete
fill 273 95 256 273 96 256 minecraft:gray_concrete
setblock 273 95 261 minecraft:black_stained_glass
setblock 273 95 269 minecraft:magenta_stained_glass
setblock 274 95 242 minecraft:black_stained_glass
fill 274 95 251 274 96 251 minecraft:gray_concrete
fill 274 95 253 274 96 253 minecraft:gray_concrete
setblock 274 95 255 minecraft:black_stained_glass
setblock 275 95 229 minecraft:black_stained_glass
setblock 275 95 237 minecraft:ochre_froglight
fill 275 95 250 275 96 250 minecraft:gray_concrete
fill 275 95 252 275 96 252 minecraft:gray_concrete
fill 275 95 254 275 96 254 minecraft:gray_concrete
fill 275 95 256 275 96 256 minecraft:gray_concrete
setblock 275 95 261 minecraft:light_blue_stained_glass
setblock 275 95 269 minecraft:black_stained_glass
setblock 276 95 230 minecraft:black_stained_glass
setblock 276 95 232 minecraft:black_stained_glass
setblock 276 95 234 minecraft:light_blue_stained_glass
setblock 276 95 236 minecraft:black_stained_glass
setblock 276 95 243 minecraft:magenta_stained_glass
setblock 276 95 245 minecraft:cyan_stained_glass
setblock 276 95 247 minecraft:light_blue_stained_glass
setblock 276 95 249 minecraft:pearlescent_froglight
setblock 276 95 251 minecraft:black_stained_glass
setblock 276 95 253 minecraft:black_stained_glass
fill 276 95 255 276 96 255 minecraft:gray_concrete
setblock 276 95 262 minecraft:ochre_froglight
setblock 276 95 264 minecraft:black_stained_glass
setblock 276 95 266 minecraft:sea_lantern
setblock 276 95 268 minecraft:sea_lantern
fill 235 96 230 235 100 230 minecraft:black_concrete
setblock 235 96 265 minecraft:pearlescent_froglight
fill 236 96 230 236 97 230 minecraft:gray_concrete
fill 236 96 232 236 97 232 minecraft:gray_concrete
fill 236 96 234 236 97 234 minecraft:gray_concrete
fill 236 96 236 236 97 236 minecraft:gray_concrete
fill 236 96 243 236 97 243 minecraft:black_concrete
fill 236 96 245 236 97 245 minecraft:black_concrete
fill 236 96 247 236 97 247 minecraft:black_concrete
fill 236 96 249 236 97 249 minecraft:black_concrete
fill 236 96 251 236 97 251 minecraft:black_concrete
fill 236 96 253 236 97 253 minecraft:black_concrete
fill 236 96 262 236 97 262 minecraft:blue_terracotta
fill 236 96 264 236 97 264 minecraft:blue_terracotta
fill 236 96 266 236 97 266 minecraft:blue_terracotta
fill 236 96 268 236 97 268 minecraft:blue_terracotta
fill 237 96 229 237 97 229 minecraft:gray_concrete
fill 237 96 237 237 97 237 minecraft:gray_concrete
fill 237 96 242 237 97 242 minecraft:black_concrete
fill 237 96 255 237 97 255 minecraft:black_concrete
fill 237 96 261 237 97 261 minecraft:blue_terracotta
fill 237 96 269 237 97 269 minecraft:blue_terracotta
fill 239 96 229 239 97 229 minecraft:gray_concrete
fill 239 96 237 239 97 237 minecraft:gray_concrete
fill 239 96 242 239 97 242 minecraft:black_concrete
fill 239 96 255 239 97 255 minecraft:black_concrete
fill 239 96 261 239 97 261 minecraft:blue_terracotta
fill 239 96 269 239 97 269 minecraft:blue_terracotta
fill 241 96 228 241 157 228 minecraft:black_concrete
fill 241 96 229 241 97 229 minecraft:gray_concrete
fill 241 96 237 241 97 237 minecraft:gray_concrete
fill 241 96 243 241 97 243 minecraft:black_concrete
fill 241 96 245 241 97 245 minecraft:black_concrete
fill 241 96 247 241 97 247 minecraft:black_concrete
fill 241 96 249 241 97 249 minecraft:black_concrete
fill 241 96 251 241 97 251 minecraft:black_concrete
fill 241 96 253 241 97 253 minecraft:black_concrete
fill 241 96 261 241 97 261 minecraft:blue_terracotta
fill 241 96 269 241 97 269 minecraft:blue_terracotta
fill 243 96 229 243 97 229 minecraft:gray_concrete
fill 243 96 237 243 97 237 minecraft:gray_concrete
fill 243 96 261 243 97 261 minecraft:blue_terracotta
fill 243 96 269 243 97 269 minecraft:blue_terracotta
fill 244 96 230 244 97 230 minecraft:gray_concrete
fill 244 96 232 244 97 232 minecraft:gray_concrete
fill 244 96 234 244 97 234 minecraft:gray_concrete
fill 244 96 236 244 97 236 minecraft:gray_concrete
fill 244 96 262 244 97 262 minecraft:blue_terracotta
fill 244 96 264 244 97 264 minecraft:blue_terracotta
fill 244 96 266 244 97 266 minecraft:blue_terracotta
fill 244 96 268 244 97 268 minecraft:blue_terracotta
fill 249 96 230 249 97 230 minecraft:gray_concrete
fill 249 96 232 249 97 232 minecraft:gray_concrete
fill 249 96 265 249 97 265 minecraft:gray_concrete
fill 249 96 267 249 97 267 minecraft:gray_concrete
fill 250 96 229 250 97 229 minecraft:gray_concrete
fill 250 96 234 250 97 234 minecraft:gray_concrete
fill 250 96 264 250 97 264 minecraft:gray_concrete
fill 250 96 269 250 97 269 minecraft:gray_concrete
fill 251 96 228 252 96 228 minecraft:black_concrete
fill 252 96 229 252 97 229 minecraft:gray_concrete
fill 252 96 234 252 97 234 minecraft:gray_concrete
fill 252 96 264 252 97 264 minecraft:gray_concrete
fill 252 96 269 252 97 269 minecraft:gray_concrete
setblock 253 96 228 minecraft:cyan_concrete
fill 254 96 228 258 96 228 minecraft:black_concrete
fill 254 96 229 254 97 229 minecraft:gray_concrete
fill 254 96 234 254 97 234 minecraft:gray_concrete
fill 254 96 264 254 97 264 minecraft:gray_concrete
fill 254 96 269 254 97 269 minecraft:gray_concrete
fill 256 96 229 256 97 229 minecraft:gray_concrete
fill 256 96 234 256 97 234 minecraft:gray_concrete
fill 256 96 264 256 97 264 minecraft:gray_concrete
fill 256 96 269 256 97 269 minecraft:gray_concrete
fill 258 96 229 258 97 229 minecraft:gray_concrete
fill 258 96 234 258 97 234 minecraft:gray_concrete
fill 258 96 264 258 97 264 minecraft:gray_concrete
fill 258 96 269 258 97 269 minecraft:gray_concrete
fill 260 96 229 260 97 229 minecraft:gray_concrete
fill 260 96 234 260 97 234 minecraft:gray_concrete
fill 260 96 264 260 97 264 minecraft:gray_concrete
fill 260 96 269 260 97 269 minecraft:gray_concrete
fill 262 96 230 262 97 230 minecraft:gray_concrete
fill 262 96 232 262 97 232 minecraft:gray_concrete
fill 262 96 265 262 97 265 minecraft:gray_concrete
fill 262 96 267 262 97 267 minecraft:gray_concrete
fill 268 96 230 268 97 230 minecraft:blue_terracotta
fill 268 96 232 268 97 232 minecraft:blue_terracotta
fill 268 96 234 268 97 234 minecraft:blue_terracotta
fill 268 96 236 268 97 236 minecraft:blue_terracotta
fill 268 96 262 268 97 262 minecraft:gray_concrete
fill 268 96 264 268 97 264 minecraft:gray_concrete
fill 268 96 266 268 97 266 minecraft:gray_concrete
fill 268 96 268 268 97 268 minecraft:gray_concrete
fill 269 96 229 269 97 229 minecraft:blue_terracotta
fill 269 96 237 269 97 237 minecraft:blue_terracotta
fill 269 96 261 269 97 261 minecraft:gray_concrete
fill 269 96 269 269 97 269 minecraft:gray_concrete
fill 271 96 229 271 97 229 minecraft:blue_terracotta
fill 271 96 237 271 97 237 minecraft:blue_terracotta
fill 271 96 243 271 97 243 minecraft:gray_concrete
fill 271 96 245 271 97 245 minecraft:gray_concrete
fill 271 96 247 271 97 247 minecraft:gray_concrete
fill 271 96 249 271 97 249 minecraft:gray_concrete
fill 271 96 251 271 97 251 minecraft:gray_concrete
fill 271 96 253 271 97 253 minecraft:gray_concrete
fill 271 96 261 271 97 261 minecraft:gray_concrete
fill 271 96 269 271 97 269 minecraft:gray_concrete
fill 272 96 242 272 97 242 minecraft:gray_concrete
setblock 272 96 255 minecraft:gray_concrete
fill 273 96 229 273 97 229 minecraft:blue_terracotta
fill 273 96 237 273 97 237 minecraft:blue_terracotta
fill 273 96 261 273 97 261 minecraft:gray_concrete
fill 273 96 269 273 97 269 minecraft:gray_concrete
fill 274 96 242 274 97 242 minecraft:gray_concrete
setblock 274 96 255 minecraft:gray_concrete
fill 275 96 229 275 97 229 minecraft:blue_terracotta
fill 275 96 237 275 97 237 minecraft:blue_terracotta
fill 275 96 261 275 97 261 minecraft:gray_concrete
fill 275 96 269 275 97 269 minecraft:gray_concrete
fill 276 96 230 276 97 230 minecraft:blue_terracotta
fill 276 96 232 276 97 232 minecraft:blue_terracotta
fill 276 96 234 276 97 234 minecraft:blue_terracotta
fill 276 96 236 276 97 236 minecraft:blue_terracotta
fill 276 96 243 276 97 243 minecraft:gray_concrete
fill 276 96 245 276 97 245 minecraft:gray_concrete
fill 276 96 247 276 97 247 minecraft:gray_concrete
fill 276 96 249 276 97 249 minecraft:gray_concrete
setblock 276 96 251 minecraft:gray_concrete
setblock 276 96 253 minecraft:gray_concrete
fill 276 96 262 276 97 262 minecraft:gray_concrete
fill 276 96 264 276 97 264 minecraft:gray_concrete
fill 276 96 266 276 97 266 minecraft:gray_concrete
fill 276 96 268 276 97 268 minecraft:gray_concrete
setblock 277 96 257 minecraft:pearlescent_froglight
fill 235 97 265 235 124 265 minecraft:black_concrete
fill 236 97 228 236 138 228 minecraft:black_concrete
setblock 237 97 228 minecraft:pearlescent_froglight
setblock 238 97 228 minecraft:verdant_froglight
setblock 238 97 238 minecraft:light[level=12]
setblock 238 97 259 minecraft:light[level=12]
setblock 240 97 270 minecraft:sea_lantern
setblock 245 97 231 minecraft:light[level=12]
setblock 245 97 238 minecraft:light[level=12]
setblock 245 97 245 minecraft:light[level=12]
setblock 245 97 252 minecraft:light[level=12]
setblock 245 97 259 minecraft:light[level=12]
setblock 245 97 266 minecraft:light[level=12]
setblock 251 97 228 minecraft:sea_lantern
fill 252 97 228 254 121 228 minecraft:black_concrete
setblock 252 97 238 minecraft:light[level=12]
setblock 252 97 245 minecraft:light[level=12]
setblock 252 97 252 minecraft:light[level=12]
setblock 252 97 259 minecraft:light[level=12]
setblock 255 97 228 minecraft:magenta_concrete
fill 256 97 228 258 129 228 minecraft:black_concrete
setblock 259 97 238 minecraft:light[level=12]
setblock 259 97 245 minecraft:light[level=12]
setblock 259 97 252 minecraft:light[level=12]
setblock 259 97 259 minecraft:light[level=12]
setblock 266 97 231 minecraft:light[level=12]
setblock 266 97 238 minecraft:light[level=12]
setblock 266 97 245 minecraft:light[level=12]
setblock 266 97 252 minecraft:light[level=12]
setblock 266 97 259 minecraft:light[level=12]
setblock 266 97 266 minecraft:light[level=12]
setblock 270 97 251 minecraft:sea_lantern
setblock 270 97 253 minecraft:sea_lantern
setblock 270 97 255 minecraft:sea_lantern
setblock 271 97 250 minecraft:sea_lantern
setblock 271 97 252 minecraft:sea_lantern
setblock 271 97 254 minecraft:sea_lantern
setblock 271 97 256 minecraft:sea_lantern
setblock 272 97 251 minecraft:sea_lantern
setblock 272 97 253 minecraft:sea_lantern
setblock 272 97 255 minecraft:sea_lantern
setblock 273 97 238 minecraft:light[level=12]
setblock 273 97 250 minecraft:sea_lantern
setblock 273 97 252 minecraft:sea_lantern
setblock 273 97 254 minecraft:sea_lantern
setblock 273 97 256 minecraft:sea_lantern
setblock 273 97 259 minecraft:light[level=12]
setblock 274 97 251 minecraft:sea_lantern
setblock 274 97 253 minecraft:sea_lantern
setblock 274 97 255 minecraft:sea_lantern
setblock 275 97 250 minecraft:sea_lantern
setblock 275 97 252 minecraft:sea_lantern
setblock 275 97 254 minecraft:sea_lantern
setblock 275 97 256 minecraft:sea_lantern
fill 276 97 251 276 98 251 minecraft:sea_lantern
setblock 276 97 253 minecraft:sea_lantern
setblock 276 97 255 minecraft:sea_lantern
fill 277 97 257 277 293 257 minecraft:black_concrete
setblock 277 97 260 minecraft:sea_lantern
fill 277 97 261 277 174 261 minecraft:black_concrete
setblock 236 98 230 minecraft:black_stained_glass
setblock 236 98 232 minecraft:ochre_froglight
setblock 236 98 234 minecraft:black_stained_glass
setblock 236 98 236 minecraft:sea_lantern
setblock 236 98 243 minecraft:black_stained_glass
setblock 236 98 245 minecraft:black_stained_glass
setblock 236 98 247 minecraft:cyan_stained_glass
setblock 236 98 249 minecraft:black_stained_glass
setblock 236 98 251 minecraft:sea_lantern
setblock 236 98 253 minecraft:ochre_froglight
setblock 236 98 262 minecraft:ochre_froglight
setblock 236 98 264 minecraft:light_blue_stained_glass
setblock 236 98 266 minecraft:black_stained_glass
setblock 236 98 268 minecraft:magenta_stained_glass
fill 237 98 228 238 182 228 minecraft:black_concrete
setblock 237 98 229 minecraft:cyan_stained_glass
setblock 237 98 237 minecraft:pearlescent_froglight
setblock 237 98 242 minecraft:pearlescent_froglight
setblock 237 98 255 minecraft:ochre_froglight
setblock 237 98 261 minecraft:ochre_froglight
setblock 237 98 269 minecraft:pearlescent_froglight
setblock 239 98 229 minecraft:magenta_stained_glass
setblock 239 98 237 minecraft:black_stained_glass
setblock 239 98 242 minecraft:sea_lantern
setblock 239 98 255 minecraft:ochre_froglight
setblock 239 98 261 minecraft:magenta_stained_glass
setblock 239 98 269 minecraft:cyan_stained_glass
fill 240 98 270 240 171 270 minecraft:black_concrete
setblock 241 98 229 minecraft:magenta_stained_glass
setblock 241 98 237 minecraft:black_stained_glass
setblock 241 98 243 minecraft:light_blue_stained_glass
setblock 241 98 245 minecraft:black_stained_glass
setblock 241 98 247 minecraft:ochre_froglight
setblock 241 98 249 minecraft:magenta_stained_glass
setblock 241 98 251 minecraft:pearlescent_froglight
setblock 241 98 253 minecraft:cyan_stained_glass
setblock 241 98 261 minecraft:cyan_stained_glass
setblock 241 98 269 minecraft:ochre_froglight
setblock 243 98 229 minecraft:light_blue_stained_glass
setblock 243 98 237 minecraft:pearlescent_froglight
setblock 243 98 261 minecraft:cyan_stained_glass
setblock 243 98 269 minecraft:cyan_stained_glass
fill 243 98 270 243 120 270 minecraft:black_concrete
setblock 244 98 230 minecraft:sea_lantern
setblock 244 98 232 minecraft:black_stained_glass
setblock 244 98 234 minecraft:light_blue_stained_glass
setblock 244 98 236 minecraft:pearlescent_froglight
setblock 244 98 262 minecraft:pearlescent_froglight
setblock 244 98 264 minecraft:magenta_stained_glass
setblock 244 98 266 minecraft:sea_lantern
setblock 244 98 268 minecraft:cyan_stained_glass
setblock 244 98 270 minecraft:sea_lantern
setblock 248 98 228 minecraft:magenta_concrete
setblock 249 98 230 minecraft:black_stained_glass
setblock 249 98 232 minecraft:pearlescent_froglight
setblock 249 98 265 minecraft:ochre_froglight
setblock 249 98 267 minecraft:cyan_stained_glass
setblock 250 98 229 minecraft:sea_lantern
setblock 250 98 234 minecraft:black_stained_glass
setblock 250 98 264 minecraft:magenta_stained_glass
setblock 250 98 269 minecraft:black_stained_glass
fill 251 98 228 251 133 228 minecraft:black_concrete
setblock 252 98 229 minecraft:sea_lantern
setblock 252 98 234 minecraft:pearlescent_froglight
setblock 252 98 264 minecraft:black_stained_glass
setblock 252 98 269 minecraft:light_blue_stained_glass
setblock 254 98 229 minecraft:sea_lantern
setblock 254 98 234 minecraft:ochre_froglight
setblock 254 98 264 minecraft:ochre_froglight
setblock 254 98 269 minecraft:black_stained_glass
fill 255 98 228 255 144 228 minecraft:black_concrete
setblock 256 98 229 minecraft:black_stained_glass
setblock 256 98 234 minecraft:black_stained_glass
setblock 256 98 264 minecraft:black_stained_glass
setblock 256 98 269 minecraft:black_stained_glass
setblock 258 98 229 minecraft:pearlescent_froglight
setblock 258 98 234 minecraft:black_stained_glass
setblock 258 98 264 minecraft:magenta_stained_glass
setblock 258 98 269 minecraft:ochre_froglight
setblock 260 98 229 minecraft:black_stained_glass
setblock 260 98 234 minecraft:cyan_stained_glass
setblock 260 98 264 minecraft:cyan_stained_glass
setblock 260 98 269 minecraft:sea_lantern
setblock 262 98 230 minecraft:black_stained_glass
setblock 262 98 232 minecraft:black_stained_glass
setblock 262 98 265 minecraft:sea_lantern
setblock 262 98 267 minecraft:pearlescent_froglight
setblock 266 98 270 minecraft:cyan_concrete
setblock 268 98 230 minecraft:sea_lantern
setblock 268 98 232 minecraft:cyan_stained_glass
setblock 268 98 234 minecraft:black_stained_glass
setblock 268 98 236 minecraft:black_stained_glass
setblock 268 98 262 minecraft:pearlescent_froglight
setblock 268 98 264 minecraft:cyan_stained_glass
setblock 268 98 266 minecraft:black_stained_glass
setblock 268 98 268 minecraft:black_stained_glass
setblock 269 98 229 minecraft:cyan_stained_glass
setblock 269 98 237 minecraft:black_stained_glass
setblock 269 98 261 minecraft:black_stained_glass
setblock 269 98 269 minecraft:cyan_stained_glass
fill 270 98 251 270 99 251 minecraft:gray_concrete
fill 270 98 253 270 99 253 minecraft:gray_concrete
fill 270 98 255 270 99 255 minecraft:gray_concrete
setblock 271 98 229 minecraft:black_stained_glass
setblock 271 98 237 minecraft:ochre_froglight
setblock 271 98 243 minecraft:black_stained_glass
setblock 271 98 245 minecraft:black_stained_glass
setblock 271 98 247 minecraft:cyan_stained_glass
setblock 271 98 249 minecraft:light_blue_stained_glass
fill 271 98 250 271 99 250 minecraft:gray_concrete
setblock 271 98 251 minecraft:sea_lantern
fill 271 98 252 271 99 252 minecraft:gray_concrete
setblock 271 98 253 minecraft:sea_lantern
fill 271 98 254 271 99 254 minecraft:gray_concrete
fill 271 98 256 271 99 256 minecraft:gray_concrete
setblock 271 98 261 minecraft:pearlescent_froglight
setblock 271 98 269 minecraft:black_stained_glass
setblock 272 98 242 minecraft:pearlescent_froglight
fill 272 98 251 272 99 251 minecraft:gray_concrete
fill 272 98 253 272 99 253 minecraft:gray_concrete
setblock 272 98 255 minecraft:black_stained_glass
setblock 273 98 229 minecraft:ochre_froglight
setblock 273 98 237 minecraft:pearlescent_froglight
fill 273 98 250 273 99 250 minecraft:gray_concrete
fill 273 98 252 273 99 252 minecraft:gray_concrete
fill 273 98 254 273 99 254 minecraft:gray_concrete
fill 273 98 256 273 99 256 minecraft:gray_concrete
setblock 273 98 261 minecraft:black_stained_glass
setblock 273 98 269 minecraft:black_stained_glass
setblock 274 98 242 minecraft:cyan_stained_glass
fill 274 98 251 274 99 251 minecraft:gray_concrete
fill 274 98 253 274 99 253 minecraft:gray_concrete
setblock 274 98 255 minecraft:black_stained_glass
setblock 275 98 229 minecraft:black_stained_glass
setblock 275 98 237 minecraft:cyan_stained_glass
fill 275 98 250 275 99 250 minecraft:gray_concrete
fill 275 98 252 275 99 252 minecraft:gray_concrete
fill 275 98 254 275 99 254 minecraft:gray_concrete
fill 275 98 256 275 99 256 minecraft:gray_concrete
setblock 275 98 261 minecraft:magenta_stained_glass
setblock 275 98 269 minecraft:black_stained_glass
setblock 276 98 230 minecraft:magenta_stained_glass
setblock 276 98 232 minecraft:black_stained_glass
setblock 276 98 234 minecraft:pearlescent_froglight
setblock 276 98 236 minecraft:black_stained_glass
setblock 276 98 243 minecraft:light_blue_stained_glass
setblock 276 98 245 minecraft:ochre_froglight
setblock 276 98 247 minecraft:black_stained_glass
setblock 276 98 249 minecraft:sea_lantern
setblock 276 98 253 minecraft:black_stained_glass
fill 276 98 255 276 99 255 minecraft:gray_concrete
setblock 276 98 262 minecraft:black_stained_glass
setblock 276 98 264 minecraft:cyan_stained_glass
setblock 276 98 266 minecraft:pearlescent_froglight
setblock 276 98 268 minecraft:black_stained_glass
fill 277 98 260 277 144 260 minecraft:black_concrete
fill 236 99 230 236 100 230 minecraft:gray_concrete
fill 236 99 232 236 100 232 minecraft:gray_concrete
fill 236 99 234 236 100 234 minecraft:gray_concrete
fill 236 99 236 236 100 236 minecraft:gray_concrete
fill 236 99 243 236 100 243 minecraft:black_concrete
fill 236 99 245 236 100 245 minecraft:black_concrete
fill 236 99 247 236 100 247 minecraft:black_concrete
fill 236 99 249 236 100 249 minecraft:black_concrete
fill 236 99 251 236 100 251 minecraft:black_concrete
fill 236 99 253 236 100 253 minecraft:black_concrete
fill 236 99 262 236 100 262 minecraft:blue_terracotta
fill 236 99 264 236 100 264 minecraft:blue_terracotta
fill 236 99 266 236 100 266 minecraft:blue_terracotta
fill 236 99 268 236 100 268 minecraft:blue_terracotta
fill 237 99 229 237 100 229 minecraft:gray_concrete
fill 237 99 237 237 100 237 minecraft:gray_concrete
fill 237 99 242 237 100 242 minecraft:black_concrete
fill 237 99 255 237 100 255 minecraft:black_concrete
fill 237 99 261 237 100 261 minecraft:blue_terracotta
fill 237 99 269 237 100 269 minecraft:blue_terracotta
fill 239 99 229 239 100 229 minecraft:gray_concrete
fill 239 99 237 239 100 237 minecraft:gray_concrete
fill 239 99 242 239 100 242 minecraft:black_concrete
fill 239 99 255 239 100 255 minecraft:black_concrete
fill 239 99 261 239 100 261 minecraft:blue_terracotta
fill 239 99 269 239 100 269 minecraft:blue_terracotta
fill 241 99 229 241 100 229 minecraft:gray_concrete
fill 241 99 237 241 100 237 minecraft:gray_concrete
fill 241 99 243 241 100 243 minecraft:black_concrete
fill 241 99 245 241 100 245 minecraft:black_concrete
fill 241 99 247 241 100 247 minecraft:black_concrete
fill 241 99 249 241 100 249 minecraft:black_concrete
fill 241 99 251 241 100 251 minecraft:black_concrete
fill 241 99 253 241 100 253 minecraft:black_concrete
fill 241 99 261 241 100 261 minecraft:blue_terracotta
fill 241 99 269 241 100 269 minecraft:blue_terracotta
setblock 243 99 228 minecraft:cyan_concrete
fill 243 99 229 243 100 229 minecraft:gray_concrete
fill 243 99 237 243 100 237 minecraft:gray_concrete
fill 243 99 261 243 100 261 minecraft:blue_terracotta
fill 243 99 269 243 100 269 minecraft:blue_terracotta
fill 244 99 230 244 100 230 minecraft:gray_concrete
fill 244 99 232 244 100 232 minecraft:gray_concrete
fill 244 99 234 244 100 234 minecraft:gray_concrete
fill 244 99 236 244 100 236 minecraft:gray_concrete
fill 244 99 262 244 100 262 minecraft:blue_terracotta
fill 244 99 264 244 100 264 minecraft:blue_terracotta
fill 244 99 266 244 100 266 minecraft:blue_terracotta
fill 244 99 268 244 100 268 minecraft:blue_terracotta
fill 244 99 270 244 148 270 minecraft:black_concrete
fill 248 99 228 248 129 228 minecraft:black_concrete
fill 249 99 230 249 100 230 minecraft:gray_concrete
fill 249 99 232 249 100 232 minecraft:gray_concrete
fill 249 99 265 249 100 265 minecraft:gray_concrete
fill 249 99 267 249 100 267 minecraft:gray_concrete
fill 250 99 229 250 100 229 minecraft:gray_concrete
fill 250 99 234 250 100 234 minecraft:gray_concrete
fill 250 99 264 250 100 264 minecraft:gray_concrete
fill 250 99 269 250 100 269 minecraft:gray_concrete
fill 252 99 229 252 100 229 minecraft:gray_concrete
fill 252 99 234 252 100 234 minecraft:gray_concrete
fill 252 99 264 252 100 264 minecraft:gray_concrete
fill 252 99 269 252 100 269 minecraft:gray_concrete
fill 254 99 229 254 100 229 minecraft:gray_concrete
fill 254 99 234 254 100 234 minecraft:gray_concrete
fill 254 99 264 254 100 264 minecraft:gray_concrete
fill 254 99 269 254 100 269 minecraft:gray_concrete
fill 256 99 229 256 100 229 minecraft:gray_concrete
fill 256 99 234 256 100 234 minecraft:gray_concrete
fill 256 99 264 256 100 264 minecraft:gray_concrete
fill 256 99 269 256 100 269 minecraft:gray_concrete
fill 258 99 229 258 100 229 minecraft:gray_concrete
fill 258 99 234 258 100 234 minecraft:gray_concrete
fill 258 99 264 258 100 264 minecraft:gray_concrete
fill 258 99 269 258 100 269 minecraft:gray_concrete
fill 260 99 229 260 100 229 minecraft:gray_concrete
fill 260 99 234 260 100 234 minecraft:gray_concrete
fill 260 99 264 260 100 264 minecraft:gray_concrete
fill 260 99 269 260 100 269 minecraft:gray_concrete
fill 262 99 230 262 100 230 minecraft:gray_concrete
fill 262 99 232 262 100 232 minecraft:gray_concrete
fill 262 99 265 262 100 265 minecraft:gray_concrete
fill 262 99 267 262 100 267 minecraft:gray_concrete
fill 266 99 270 266 117 270 minecraft:black_concrete
fill 268 99 230 268 100 230 minecraft:blue_terracotta
fill 268 99 232 268 100 232 minecraft:blue_terracotta
fill 268 99 234 268 100 234 minecraft:blue_terracotta
fill 268 99 236 268 100 236 minecraft:blue_terracotta
fill 268 99 262 268 100 262 minecraft:gray_concrete
fill 268 99 264 268 100 264 minecraft:gray_concrete
fill 268 99 266 268 100 266 minecraft:gray_concrete
fill 268 99 268 268 100 268 minecraft:gray_concrete
fill 269 99 229 269 100 229 minecraft:blue_terracotta
fill 269 99 237 269 100 237 minecraft:blue_terracotta
fill 269 99 261 269 100 261 minecraft:gray_concrete
fill 269 99 269 269 100 269 minecraft:gray_concrete
fill 271 99 229 271 100 229 minecraft:blue_terracotta
fill 271 99 237 271 100 237 minecraft:blue_terracotta
fill 271 99 243 271 100 243 minecraft:gray_concrete
fill 271 99 245 271 100 245 minecraft:gray_concrete
fill 271 99 247 271 100 247 minecraft:gray_concrete
fill 271 99 249 271 100 249 minecraft:gray_concrete
fill 271 99 251 271 103 251 minecraft:gray_concrete
fill 271 99 253 271 100 253 minecraft:gray_concrete
fill 271 99 261 271 100 261 minecraft:gray_concrete
fill 271 99 269 271 100 269 minecraft:gray_concrete
fill 272 99 242 272 100 242 minecraft:gray_concrete
setblock 272 99 255 minecraft:gray_concrete
fill 273 99 229 273 100 229 minecraft:blue_terracotta
fill 273 99 237 273 100 237 minecraft:blue_terracotta
fill 273 99 261 273 100 261 minecraft:gray_concrete
fill 273 99 269 273 100 269 minecraft:gray_concrete
fill 274 99 242 274 100 242 minecraft:gray_concrete
setblock 274 99 255 minecraft:gray_concrete
fill 275 99 229 275 100 229 minecraft:blue_terracotta
fill 275 99 237 275 100 237 minecraft:blue_terracotta
fill 275 99 261 275 100 261 minecraft:gray_concrete
fill 275 99 269 275 100 269 minecraft:gray_concrete
fill 276 99 230 276 100 230 minecraft:blue_terracotta
fill 276 99 232 276 100 232 minecraft:blue_terracotta
fill 276 99 234 276 100 234 minecraft:blue_terracotta
fill 276 99 236 276 100 236 minecraft:blue_terracotta
fill 276 99 243 276 100 243 minecraft:gray_concrete
fill 276 99 245 276 100 245 minecraft:gray_concrete
fill 276 99 247 276 100 247 minecraft:gray_concrete
fill 276 99 249 276 100 249 minecraft:gray_concrete
setblock 276 99 251 minecraft:gray_concrete
setblock 276 99 253 minecraft:gray_concrete
fill 276 99 262 276 100 262 minecraft:gray_concrete
fill 276 99 264 276 100 264 minecraft:gray_concrete
fill 276 99 266 276 100 266 minecraft:gray_concrete
fill 276 99 268 276 100 268 minecraft:gray_concrete
setblock 277 99 268 minecraft:cyan_concrete
fill 243 100 228 243 110 228 minecraft:black_concrete
setblock 244 100 228 minecraft:purple_concrete
setblock 245 100 228 minecraft:verdant_froglight
fill 246 100 228 246 128 228 minecraft:black_concrete
setblock 250 100 270 minecraft:ochre_froglight
fill 251 100 270 253 114 270 minecraft:black_concrete
setblock 270 100 251 minecraft:sea_lantern
setblock 270 100 253 minecraft:sea_lantern
setblock 270 100 255 minecraft:sea_lantern
setblock 271 100 250 minecraft:sea_lantern
setblock 271 100 252 minecraft:sea_lantern
setblock 271 100 254 minecraft:sea_lantern
setblock 271 100 256 minecraft:sea_lantern
setblock 272 100 251 minecraft:sea_lantern
setblock 272 100 253 minecraft:sea_lantern
setblock 272 100 255 minecraft:sea_lantern
setblock 273 100 250 minecraft:sea_lantern
setblock 273 100 252 minecraft:sea_lantern
setblock 273 100 254 minecraft:sea_lantern
setblock 273 100 256 minecraft:sea_lantern
setblock 274 100 251 minecraft:sea_lantern
setblock 274 100 253 minecraft:sea_lantern
setblock 274 100 255 minecraft:sea_lantern
setblock 275 100 250 minecraft:sea_lantern
setblock 275 100 252 minecraft:sea_lantern
setblock 275 100 254 minecraft:sea_lantern
setblock 275 100 256 minecraft:sea_lantern
setblock 276 100 251 minecraft:sea_lantern
fill 276 100 253 276 101 253 minecraft:sea_lantern
setblock 276 100 255 minecraft:sea_lantern
setblock 277 100 253 minecraft:magenta_concrete
fill 277 100 254 277 154 254 minecraft:black_concrete
fill 277 100 268 277 133 268 minecraft:black_concrete
setblock 235 101 230 minecraft:verdant_froglight
setblock 236 101 230 minecraft:ochre_froglight
setblock 236 101 232 minecraft:black_stained_glass
setblock 236 101 234 minecraft:sea_lantern
setblock 236 101 236 minecraft:magenta_stained_glass
setblock 236 101 243 minecraft:sea_lantern
setblock 236 101 245 minecraft:cyan_stained_glass
setblock 236 101 247 minecraft:pearlescent_froglight
setblock 236 101 249 minecraft:black_stained_glass
setblock 236 101 251 minecraft:black_stained_glass
setblock 236 101 253 minecraft:cyan_stained_glass
setblock 236 101 262 minecraft:black_stained_glass
setblock 236 101 264 minecraft:ochre_froglight
setblock 236 101 266 minecraft:cyan_stained_glass
setblock 236 101 268 minecraft:pearlescent_froglight
setblock 237 101 229 minecraft:black_stained_glass
setblock 237 101 237 minecraft:black_stained_glass
setblock 237 101 242 minecraft:ochre_froglight
setblock 237 101 255 minecraft:black_stained_glass
setblock 237 101 261 minecraft:black_stained_glass
setblock 237 101 269 minecraft:pearlescent_froglight
setblock 238 101 239 minecraft:light[level=15]
setblock 239 101 229 minecraft:light_blue_stained_glass
setblock 239 101 237 minecraft:black_stained_glass
setblock 239 101 242 minecraft:cyan_stained_glass
setblock 239 101 255 minecraft:black_stained_glass
setblock 239 101 261 minecraft:magenta_stained_glass
setblock 239 101 269 minecraft:magenta_stained_glass
setblock 241 101 229 minecraft:cyan_stained_glass
setblock 241 101 237 minecraft:light_blue_stained_glass
setblock 241 101 243 minecraft:pearlescent_froglight
setblock 241 101 245 minecraft:cyan_stained_glass
setblock 241 101 247 minecraft:black_stained_glass
setblock 241 101 249 minecraft:ochre_froglight
setblock 241 101 251 minecraft:ochre_froglight
setblock 241 101 253 minecraft:ochre_froglight
setblock 241 101 261 minecraft:pearlescent_froglight
setblock 241 101 269 minecraft:ochre_froglight
setblock 243 101 229 minecraft:magenta_stained_glass
setblock 243 101 237 minecraft:black_stained_glass
setblock 243 101 261 minecraft:magenta_stained_glass
setblock 243 101 269 minecraft:light_blue_stained_glass
fill 244 101 228 245 129 228 minecraft:black_concrete
setblock 244 101 230 minecraft:black_stained_glass
setblock 244 101 232 minecraft:black_stained_glass
setblock 244 101 234 minecraft:black_stained_glass
setblock 244 101 236 minecraft:black_stained_glass
setblock 244 101 262 minecraft:black_stained_glass
setblock 244 101 264 minecraft:pearlescent_froglight
setblock 244 101 266 minecraft:black_stained_glass
setblock 244 101 268 minecraft:light_blue_stained_glass
setblock 246 101 231 minecraft:light[level=15]
setblock 246 101 239 minecraft:light[level=15]
setblock 246 101 247 minecraft:light[level=15]
setblock 246 101 255 minecraft:light[level=15]
setblock 246 101 263 minecraft:light[level=15]
setblock 249 101 230 minecraft:black_stained_glass
setblock 249 101 232 minecraft:light_blue_stained_glass
setblock 249 101 265 minecraft:black_stained_glass
setblock 249 101 267 minecraft:black_stained_glass
setblock 250 101 229 minecraft:pearlescent_froglight
setblock 250 101 234 minecraft:black_stained_glass
setblock 250 101 264 minecraft:light_blue_stained_glass
setblock 250 101 269 minecraft:black_stained_glass
fill 250 101 270 250 112 270 minecraft:black_concrete
setblock 252 101 229 minecraft:black_stained_glass
setblock 252 101 234 minecraft:light_blue_stained_glass
setblock 252 101 264 minecraft:pearlescent_froglight
setblock 252 101 269 minecraft:black_stained_glass
setblock 254 101 229 minecraft:black_stained_glass
setblock 254 101 234 minecraft:pearlescent_froglight
setblock 254 101 239 minecraft:light[level=15]
setblock 254 101 247 minecraft:light[level=15]
setblock 254 101 255 minecraft:light[level=15]
setblock 254 101 263 minecraft:light[level=15]
setblock 254 101 264 minecraft:pearlescent_froglight
setblock 254 101 269 minecraft:sea_lantern
setblock 256 101 229 minecraft:black_stained_glass
setblock 256 101 234 minecraft:black_stained_glass
setblock 256 101 264 minecraft:sea_lantern
setblock 256 101 269 minecraft:ochre_froglight
setblock 257 101 270 minecraft:sea_lantern
setblock 258 101 229 minecraft:ochre_froglight
setblock 258 101 234 minecraft:black_stained_glass
setblock 258 101 264 minecraft:sea_lantern
setblock 258 101 269 minecraft:black_stained_glass
fill 258 101 270 258 121 270 minecraft:black_concrete
setblock 260 101 229 minecraft:black_stained_glass
setblock 260 101 234 minecraft:pearlescent_froglight
setblock 260 101 264 minecraft:black_stained_glass
setblock 260 101 269 minecraft:ochre_froglight
setblock 262 101 230 minecraft:black_stained_glass
setblock 262 101 232 minecraft:ochre_froglight
setblock 262 101 239 minecraft:light[level=15]
setblock 262 101 247 minecraft:light[level=15]
setblock 262 101 255 minecraft:light[level=15]
setblock 262 101 263 minecraft:light[level=15]
setblock 262 101 265 minecraft:black_stained_glass
setblock 262 101 267 minecraft:pearlescent_froglight
setblock 268 101 230 minecraft:black_stained_glass
setblock 268 101 232 minecraft:black_stained_glass
setblock 268 101 234 minecraft:black_stained_glass
setblock 268 101 236 minecraft:black_stained_glass
setblock 268 101 262 minecraft:pearlescent_froglight
setblock 268 101 264 minecraft:ochre_froglight
setblock 268 101 266 minecraft:black_stained_glass
setblock 268 101 268 minecraft:black_stained_glass
setblock 269 101 229 minecraft:black_stained_glass
setblock 269 101 237 minecraft:pearlescent_froglight
setblock 269 101 261 minecraft:black_stained_glass
setblock 269 101 269 minecraft:black_stained_glass
setblock 270 101 239 minecraft:light[level=15]
setblock 270 101 247 minecraft:light[level=15]
fill 270 101 251 270 102 251 minecraft:gray_concrete
fill 270 101 253 270 102 253 minecraft:gray_concrete
fill 270 101 255 270 102 255 minecraft:gray_concrete
setblock 271 101 229 minecraft:cyan_stained_glass
setblock 271 101 237 minecraft:black_stained_glass
setblock 271 101 243 minecraft:light_blue_stained_glass
setblock 271 101 245 minecraft:black_stained_glass
setblock 271 101 247 minecraft:black_stained_glass
setblock 271 101 249 minecraft:cyan_stained_glass
fill 271 101 250 271 118 250 minecraft:gray_concrete
fill 271 101 252 271 186 252 minecraft:gray_concrete
setblock 271 101 253 minecraft:black_stained_glass
fill 271 101 254 271 186 254 minecraft:gray_concrete
fill 271 101 256 271 102 256 minecraft:gray_concrete
setblock 271 101 261 minecraft:cyan_stained_glass
setblock 271 101 269 minecraft:pearlescent_froglight
setblock 272 101 242 minecraft:ochre_froglight
fill 272 101 251 272 186 251 minecraft:gray_concrete
fill 272 101 253 272 173 253 minecraft:gray_concrete
setblock 272 101 255 minecraft:black_stained_glass
setblock 273 101 229 minecraft:light_blue_stained_glass
setblock 273 101 237 minecraft:ochre_froglight
fill 273 101 250 273 173 250 minecraft:gray_concrete
fill 273 101 252 273 172 252 minecraft:gray_concrete
fill 273 101 254 273 172 254 minecraft:gray_concrete
fill 273 101 256 273 102 256 minecraft:gray_concrete
setblock 273 101 261 minecraft:cyan_stained_glass
setblock 273 101 269 minecraft:pearlescent_froglight
setblock 274 101 242 minecraft:light_blue_stained_glass
fill 274 101 251 274 173 251 minecraft:gray_concrete
fill 274 101 253 274 173 253 minecraft:gray_concrete
setblock 274 101 255 minecraft:ochre_froglight
setblock 275 101 229 minecraft:cyan_stained_glass
setblock 275 101 237 minecraft:light_blue_stained_glass
fill 275 101 250 275 186 250 minecraft:gray_concrete
fill 275 101 252 275 186 252 minecraft:gray_concrete
fill 275 101 254 275 186 254 minecraft:gray_concrete
fill 275 101 256 275 102 256 minecraft:gray_concrete
setblock 275 101 261 minecraft:black_stained_glass
setblock 275 101 269 minecraft:pearlescent_froglight
setblock 276 101 230 minecraft:black_stained_glass
setblock 276 101 232 minecraft:pearlescent_froglight
setblock 276 101 234 minecraft:black_stained_glass
setblock 276 101 236 minecraft:ochre_froglight
setblock 276 101 243 minecraft:light_blue_stained_glass
setblock 276 101 245 minecraft:black_stained_glass
setblock 276 101 247 minecraft:ochre_froglight
setblock 276 101 249 minecraft:black_stained_glass
fill 276 101 251 276 103 251 minecraft:gray_concrete
fill 276 101 255 276 186 255 minecraft:gray_concrete
setblock 276 101 262 minecraft:light_blue_stained_glass
setblock 276 101 264 minecraft:black_stained_glass
setblock 276 101 266 minecraft:black_stained_glass
setblock 276 101 268 minecraft:pearlescent_froglight
setblock 277 101 233 minecraft:sea_lantern
fill 277 101 249 277 308 249 minecraft:black_concrete
setblock 277 101 250 minecraft:pearlescent_froglight
fill 277 101 251 277 119 251 minecraft:black_concrete
fill 277 101 253 277 246 253 minecraft:black_concrete
fill 235 102 230 235 115 230 minecraft:black_concrete
fill 236 102 230 236 103 230 minecraft:gray_concrete
fill 236 102 232 236 103 232 minecraft:gray_concrete
fill 236 102 234 236 103 234 minecraft:gray_concrete
fill 236 102 236 236 103 236 minecraft:gray_concrete
fill 236 102 243 236 103 243 minecraft:black_concrete
fill 236 102 245 236 103 245 minecraft:black_concrete
fill 236 102 247 236 103 247 minecraft:black_concrete
fill 236 102 249 236 103 249 minecraft:black_concrete
fill 236 102 251 236 103 251 minecraft:black_concrete
fill 236 102 253 236 103 253 minecraft:black_concrete
fill 236 102 262 236 103 262 minecraft:blue_terracotta
fill 236 102 264 236 103 264 minecraft:blue_terracotta
fill 236 102 266 236 103 266 minecraft:blue_terracotta
fill 236 102 268 236 103 268 minecraft:blue_terracotta
fill 237 102 229 237 103 229 minecraft:gray_concrete
fill 237 102 237 237 103 237 minecraft:gray_concrete
fill 237 102 242 237 103 242 minecraft:black_concrete
fill 237 102 255 237 103 255 minecraft:black_concrete
fill 237 102 261 237 103 261 minecraft:blue_terracotta
fill 237 102 269 237 103 269 minecraft:blue_terracotta
fill 239 102 229 239 103 229 minecraft:gray_concrete
fill 239 102 237 239 103 237 minecraft:gray_concrete
fill 239 102 242 239 103 242 minecraft:black_concrete
fill 239 102 255 239 103 255 minecraft:black_concrete
fill 239 102 261 239 103 261 minecraft:blue_terracotta
fill 239 102 269 239 103 269 minecraft:blue_terracotta
fill 241 102 229 241 103 229 minecraft:gray_concrete
fill 241 102 237 241 103 237 minecraft:gray_concrete
fill 241 102 243 241 103 243 minecraft:black_concrete
fill 241 102 245 241 103 245 minecraft:black_concrete
fill 241 102 247 241 103 247 minecraft:black_concrete
fill 241 102 249 241 103 249 minecraft:black_concrete
fill 241 102 251 241 103 251 minecraft:black_concrete
fill 241 102 253 241 103 253 minecraft:black_concrete
fill 241 102 261 241 103 261 minecraft:blue_terracotta
fill 241 102 269 241 103 269 minecraft:blue_terracotta
fill 243 102 229 243 103 229 minecraft:gray_concrete
fill 243 102 237 243 103 237 minecraft:gray_concrete
fill 243 102 261 243 103 261 minecraft:blue_terracotta
fill 243 102 269 243 103 269 minecraft:blue_terracotta
fill 244 102 230 244 103 230 minecraft:gray_concrete
fill 244 102 232 244 103 232 minecraft:gray_concrete
fill 244 102 234 244 103 234 minecraft:gray_concrete
fill 244 102 236 244 103 236 minecraft:gray_concrete
fill 244 102 262 244 103 262 minecraft:blue_terracotta
fill 244 102 264 244 103 264 minecraft:blue_terracotta
fill 244 102 266 244 103 266 minecraft:blue_terracotta
fill 244 102 268 244 103 268 minecraft:blue_terracotta
fill 249 102 230 249 103 230 minecraft:gray_concrete
fill 249 102 232 249 103 232 minecraft:gray_concrete
fill 249 102 265 249 103 265 minecraft:gray_concrete
fill 249 102 267 249 103 267 minecraft:gray_concrete
fill 250 102 229 250 103 229 minecraft:gray_concrete
fill 250 102 234 250 103 234 minecraft:gray_concrete
fill 250 102 264 250 103 264 minecraft:gray_concrete
fill 250 102 269 250 103 269 minecraft:gray_concrete
fill 252 102 229 252 103 229 minecraft:gray_concrete
fill 252 102 234 252 103 234 minecraft:gray_concrete
fill 252 102 264 252 103 264 minecraft:gray_concrete
fill 252 102 269 252 103 269 minecraft:gray_concrete
fill 254 102 229 254 103 229 minecraft:gray_concrete
fill 254 102 234 254 103 234 minecraft:gray_concrete
fill 254 102 264 254 103 264 minecraft:gray_concrete
fill 254 102 269 254 103 269 minecraft:gray_concrete
fill 256 102 229 256 103 229 minecraft:gray_concrete
fill 256 102 234 256 103 234 minecraft:gray_concrete
fill 256 102 264 256 103 264 minecraft:gray_concrete
fill 256 102 269 256 103 269 minecraft:gray_concrete
fill 257 102 270 257 127 270 minecraft:black_concrete
fill 258 102 229 258 103 229 minecraft:gray_concrete
fill 258 102 234 258 103 234 minecraft:gray_concrete
fill 258 102 264 258 103 264 minecraft:gray_concrete
fill 258 102 269 258 103 269 minecraft:gray_concrete
fill 260 102 229 260 103 229 minecraft:gray_concrete
fill 260 102 234 260 103 234 minecraft:gray_concrete
fill 260 102 264 260 103 264 minecraft:gray_concrete
fill 260 102 269 260 103 269 minecraft:gray_concrete
fill 262 102 230 262 103 230 minecraft:gray_concrete
fill 262 102 232 262 103 232 minecraft:gray_concrete
fill 262 102 265 262 103 265 minecraft:gray_concrete
fill 262 102 267 262 103 267 minecraft:gray_concrete
fill 268 102 230 268 103 230 minecraft:blue_terracotta
fill 268 102 232 268 103 232 minecraft:blue_terracotta
fill 268 102 234 268 103 234 minecraft:blue_terracotta
fill 268 102 236 268 103 236 minecraft:blue_terracotta
fill 268 102 262 268 103 262 minecraft:gray_concrete
fill 268 102 264 268 103 264 minecraft:gray_concrete
fill 268 102 266 268 103 266 minecraft:gray_concrete
fill 268 102 268 268 103 268 minecraft:gray_concrete
fill 269 102 229 269 103 229 minecraft:blue_terracotta
fill 269 102 237 269 103 237 minecraft:blue_terracotta
fill 269 102 261 269 103 261 minecraft:gray_concrete
fill 269 102 269 269 103 269 minecraft:gray_concrete
fill 271 102 229 271 103 229 minecraft:blue_terracotta
fill 271 102 237 271 103 237 minecraft:blue_terracotta
fill 271 102 243 271 103 243 minecraft:gray_concrete
fill 271 102 245 271 103 245 minecraft:gray_concrete
fill 271 102 247 271 103 247 minecraft:gray_concrete
fill 271 102 249 271 103 249 minecraft:gray_concrete
fill 271 102 253 271 103 253 minecraft:gray_concrete
fill 271 102 261 271 103 261 minecraft:gray_concrete
fill 271 102 269 271 103 269 minecraft:gray_concrete
setblock 271 102 270 minecraft:magenta_concrete
fill 272 102 242 272 103 242 minecraft:gray_concrete
fill 272 102 255 272 103 255 minecraft:gray_concrete
fill 272 102 270 273 107 270 minecraft:black_concrete
fill 273 102 229 273 103 229 minecraft:blue_terracotta
fill 273 102 237 273 103 237 minecraft:blue_terracotta
fill 273 102 261 273 103 261 minecraft:gray_concrete
fill 273 102 269 273 103 269 minecraft:gray_concrete
fill 274 102 242 274 103 242 minecraft:gray_concrete
fill 274 102 255 274 103 255 minecraft:gray_concrete
fill 275 102 229 275 103 229 minecraft:blue_terracotta
fill 275 102 237 275 103 237 minecraft:blue_terracotta
fill 275 102 261 275 103 261 minecraft:gray_concrete
fill 275 102 269 275 103 269 minecraft:gray_concrete
fill 276 102 230 276 103 230 minecraft:blue_terracotta
fill 276 102 232 276 103 232 minecraft:blue_terracotta
fill 276 102 234 276 103 234 minecraft:blue_terracotta
fill 276 102 236 276 103 236 minecraft:blue_terracotta
fill 276 102 243 276 103 243 minecraft:gray_concrete
fill 276 102 245 276 103 245 minecraft:gray_concrete
fill 276 102 247 276 103 247 minecraft:gray_concrete
fill 276 102 249 276 103 249 minecraft:gray_concrete
fill 276 102 253 276 103 253 minecraft:gray_concrete
fill 276 102 262 276 103 262 minecraft:gray_concrete
fill 276 102 264 276 103 264 minecraft:gray_concrete
fill 276 102 266 276 103 266 minecraft:gray_concrete
fill 276 102 268 276 103 268 minecraft:gray_concrete
setblock 277 102 233 minecraft:blue_concrete
fill 277 102 250 277 249 250 minecraft:black_concrete
setblock 235 103 237 minecraft:magenta_concrete
fill 235 103 238 235 115 238 minecraft:black_concrete
setblock 235 103 239 minecraft:pearlescent_froglight
setblock 238 103 238 minecraft:light[level=12]
setblock 238 103 259 minecraft:light[level=12]
setblock 245 103 231 minecraft:light[level=12]
setblock 245 103 238 minecraft:light[level=12]
setblock 245 103 245 minecraft:light[level=12]
setblock 245 103 252 minecraft:light[level=12]
setblock 245 103 259 minecraft:light[level=12]
setblock 245 103 266 minecraft:light[level=12]
setblock 252 103 238 minecraft:light[level=12]
setblock 252 103 245 minecraft:light[level=12]
setblock 252 103 252 minecraft:light[level=12]
setblock 252 103 259 minecraft:light[level=12]
setblock 259 103 238 minecraft:light[level=12]
setblock 259 103 245 minecraft:light[level=12]
setblock 259 103 252 minecraft:light[level=12]
setblock 259 103 259 minecraft:light[level=12]
setblock 266 103 231 minecraft:light[level=12]
setblock 266 103 238 minecraft:light[level=12]
setblock 266 103 245 minecraft:light[level=12]
setblock 266 103 252 minecraft:light[level=12]
setblock 266 103 259 minecraft:light[level=12]
setblock 266 103 266 minecraft:light[level=12]
fill 271 103 270 271 172 270 minecraft:black_concrete
setblock 273 103 238 minecraft:light[level=12]
setblock 273 103 259 minecraft:light[level=12]
fill 277 103 233 277 118 233 minecraft:black_concrete
fill 235 104 228 235 308 228 minecraft:black_concrete
setblock 235 104 229 minecraft:sea_lantern
fill 235 104 237 235 157 237 minecraft:black_concrete
fill 235 104 239 235 135 239 minecraft:black_concrete
setblock 236 104 230 minecraft:light_blue_stained_glass
setblock 236 104 232 minecraft:cyan_stained_glass
setblock 236 104 234 minecraft:black_stained_glass
setblock 236 104 236 minecraft:pearlescent_froglight
setblock 236 104 243 minecraft:sea_lantern
setblock 236 104 245 minecraft:black_stained_glass
setblock 236 104 247 minecraft:black_stained_glass
setblock 236 104 249 minecraft:pearlescent_froglight
setblock 236 104 251 minecraft:ochre_froglight
setblock 236 104 253 minecraft:light_blue_stained_glass
fill 236 104 258 238 105 258 minecraft:iron_block
setblock 236 104 262 minecraft:black_stained_glass
setblock 236 104 264 minecraft:black_stained_glass
setblock 236 104 266 minecraft:black_stained_glass
setblock 236 104 268 minecraft:ochre_froglight
setblock 237 104 229 minecraft:ochre_froglight
setblock 237 104 237 minecraft:black_stained_glass
setblock 237 104 242 minecraft:black_stained_glass
setblock 237 104 255 minecraft:ochre_froglight
setblock 237 104 261 minecraft:cyan_stained_glass
setblock 237 104 269 minecraft:black_stained_glass
setblock 238 104 270 minecraft:cyan_concrete
setblock 239 104 229 minecraft:pearlescent_froglight
setblock 239 104 237 minecraft:light_blue_stained_glass
setblock 239 104 242 minecraft:magenta_stained_glass
setblock 239 104 255 minecraft:ochre_froglight
setblock 239 104 261 minecraft:sea_lantern
setblock 239 104 269 minecraft:sea_lantern
fill 239 104 270 239 149 270 minecraft:black_concrete
setblock 241 104 229 minecraft:cyan_stained_glass
setblock 241 104 237 minecraft:sea_lantern
setblock 241 104 243 minecraft:ochre_froglight
setblock 241 104 245 minecraft:cyan_stained_glass
setblock 241 104 247 minecraft:cyan_stained_glass
setblock 241 104 249 minecraft:black_stained_glass
setblock 241 104 251 minecraft:magenta_stained_glass
setblock 241 104 253 minecraft:ochre_froglight
setblock 241 104 261 minecraft:black_stained_glass
setblock 241 104 269 minecraft:light_blue_stained_glass
setblock 243 104 229 minecraft:sea_lantern
setblock 243 104 237 minecraft:pearlescent_froglight
setblock 243 104 261 minecraft:black_stained_glass
setblock 243 104 269 minecraft:cyan_stained_glass
setblock 244 104 230 minecraft:black_stained_glass
setblock 244 104 232 minecraft:cyan_stained_glass
setblock 244 104 234 minecraft:light_blue_stained_glass
setblock 244 104 236 minecraft:sea_lantern
setblock 244 104 262 minecraft:ochre_froglight
setblock 244 104 264 minecraft:pearlescent_froglight
setblock 244 104 266 minecraft:black_stained_glass
setblock 244 104 268 minecraft:ochre_froglight
setblock 249 104 230 minecraft:black_stained_glass
setblock 249 104 232 minecraft:pearlescent_froglight
setblock 249 104 265 minecraft:ochre_froglight
setblock 249 104 267 minecraft:light_blue_stained_glass
setblock 250 104 229 minecraft:cyan_stained_glass
setblock 250 104 234 minecraft:pearlescent_froglight
setblock 250 104 264 minecraft:magenta_stained_glass
setblock 250 104 269 minecraft:ochre_froglight
setblock 252 104 229 minecraft:magenta_stained_glass
setblock 252 104 234 minecraft:black_stained_glass
setblock 252 104 264 minecraft:light_blue_stained_glass
setblock 252 104 269 minecraft:magenta_stained_glass
setblock 254 104 229 minecraft:black_stained_glass
setblock 254 104 234 minecraft:cyan_stained_glass
setblock 254 104 264 minecraft:black_stained_glass
setblock 254 104 269 minecraft:magenta_stained_glass
setblock 256 104 229 minecraft:ochre_froglight
setblock 256 104 234 minecraft:magenta_stained_glass
setblock 256 104 264 minecraft:black_stained_glass
setblock 256 104 269 minecraft:black_stained_glass
setblock 258 104 229 minecraft:magenta_stained_glass
setblock 258 104 234 minecraft:black_stained_glass
setblock 258 104 264 minecraft:black_stained_glass
setblock 258 104 269 minecraft:black_stained_glass
setblock 260 104 229 minecraft:magenta_stained_glass
setblock 260 104 234 minecraft:light_blue_stained_glass
setblock 260 104 264 minecraft:sea_lantern
setblock 260 104 269 minecraft:sea_lantern
setblock 262 104 230 minecraft:black_stained_glass
setblock 262 104 232 minecraft:light_blue_stained_glass
setblock 262 104 265 minecraft:magenta_stained_glass
setblock 262 104 267 minecraft:ochre_froglight
setblock 268 104 230 minecraft:black_stained_glass
setblock 268 104 232 minecraft:black_stained_glass
setblock 268 104 234 minecraft:black_stained_glass
setblock 268 104 236 minecraft:light_blue_stained_glass
setblock 268 104 262 minecraft:pearlescent_froglight
setblock 268 104 264 minecraft:sea_lantern
setblock 268 104 266 minecraft:light_blue_stained_glass
setblock 268 104 268 minecraft:light_blue_stained_glass
setblock 269 104 229 minecraft:light_blue_stained_glass
setblock 269 104 237 minecraft:light_blue_stained_glass
setblock 269 104 261 minecraft:black_stained_glass
setblock 269 104 269 minecraft:black_stained_glass
setblock 271 104 229 minecraft:pearlescent_froglight
setblock 271 104 237 minecraft:black_stained_glass
setblock 271 104 243 minecraft:black_stained_glass
setblock 271 104 245 minecraft:ochre_froglight
setblock 271 104 247 minecraft:magenta_stained_glass
setblock 271 104 249 minecraft:light_blue_stained_glass
setblock 271 104 251 minecraft:pearlescent_froglight
setblock 271 104 253 minecraft:light_blue_stained_glass
setblock 271 104 261 minecraft:black_stained_glass
setblock 271 104 269 minecraft:sea_lantern
setblock 272 104 228 minecraft:blue_concrete
setblock 272 104 242 minecraft:black_stained_glass
setblock 272 104 255 minecraft:black_stained_glass
setblock 273 104 229 minecraft:magenta_stained_glass
setblock 273 104 237 minecraft:sea_lantern
setblock 273 104 261 minecraft:light_blue_stained_glass
setblock 273 104 269 minecraft:magenta_stained_glass
setblock 274 104 242 minecraft:pearlescent_froglight
setblock 274 104 255 minecraft:sea_lantern
setblock 275 104 229 minecraft:pearlescent_froglight
setblock 275 104 237 minecraft:black_stained_glass
setblock 275 104 261 minecraft:black_stained_glass
setblock 275 104 269 minecraft:ochre_froglight
setblock 276 104 230 minecraft:black_stained_glass
setblock 276 104 232 minecraft:pearlescent_froglight
setblock 276 104 234 minecraft:sea_lantern
setblock 276 104 236 minecraft:black_stained_glass
setblock 276 104 243 minecraft:black_stained_glass
setblock 276 104 245 minecraft:sea_lantern
setblock 276 104 247 minecraft:black_stained_glass
setblock 276 104 249 minecraft:ochre_froglight
setblock 276 104 251 minecraft:black_stained_glass
setblock 276 104 253 minecraft:ochre_froglight
setblock 276 104 262 minecraft:cyan_stained_glass
setblock 276 104 264 minecraft:black_stained_glass
setblock 276 104 266 minecraft:light_blue_stained_glass
setblock 276 104 268 minecraft:black_stained_glass
setblock 277 104 246 minecraft:magenta_concrete
fill 235 105 229 235 111 229 minecraft:black_concrete
setblock 235 105 232 minecraft:sea_lantern
fill 235 105 233 235 210 234 minecraft:black_concrete
fill 236 105 230 236 106 230 minecraft:gray_concrete
fill 236 105 232 236 106 232 minecraft:gray_concrete
fill 236 105 234 236 106 234 minecraft:gray_concrete
fill 236 105 236 236 106 236 minecraft:gray_concrete
fill 236 105 243 236 106 243 minecraft:black_concrete
fill 236 105 245 236 106 245 minecraft:black_concrete
fill 236 105 247 236 106 247 minecraft:black_concrete
fill 236 105 249 236 106 249 minecraft:black_concrete
fill 236 105 251 236 106 251 minecraft:black_concrete
fill 236 105 253 236 106 253 minecraft:black_concrete
fill 236 105 262 236 106 262 minecraft:blue_terracotta
fill 236 105 264 236 106 264 minecraft:blue_terracotta
fill 236 105 266 236 106 266 minecraft:blue_terracotta
fill 236 105 268 236 106 268 minecraft:blue_terracotta
fill 237 105 229 237 106 229 minecraft:gray_concrete
fill 237 105 237 237 106 237 minecraft:gray_concrete
fill 237 105 242 237 106 242 minecraft:black_concrete
fill 237 105 255 237 106 255 minecraft:black_concrete
fill 237 105 261 237 106 261 minecraft:blue_terracotta
fill 237 105 269 237 106 269 minecraft:blue_terracotta
fill 238 105 270 238 174 270 minecraft:black_concrete
fill 239 105 229 239 106 229 minecraft:gray_concrete
fill 239 105 237 239 106 237 minecraft:gray_concrete
fill 239 105 242 239 106 242 minecraft:black_concrete
fill 239 105 255 239 106 255 minecraft:black_concrete
fill 239 105 261 239 106 261 minecraft:blue_terracotta
fill 239 105 269 239 106 269 minecraft:blue_terracotta
fill 241 105 229 241 106 229 minecraft:gray_concrete
fill 241 105 237 241 106 237 minecraft:gray_concrete
fill 241 105 243 241 106 243 minecraft:black_concrete
fill 241 105 245 241 106 245 minecraft:black_concrete
fill 241 105 247 241 106 247 minecraft:black_concrete
fill 241 105 249 241 106 249 minecraft:black_concrete
fill 241 105 251 241 106 251 minecraft:black_concrete
fill 241 105 253 241 106 253 minecraft:black_concrete
fill 241 105 261 241 106 261 minecraft:blue_terracotta
fill 241 105 269 241 106 269 minecraft:blue_terracotta
fill 243 105 229 243 106 229 minecraft:gray_concrete
fill 243 105 237 243 106 237 minecraft:gray_concrete
fill 243 105 261 243 106 261 minecraft:blue_terracotta
fill 243 105 269 243 106 269 minecraft:blue_terracotta
fill 244 105 230 244 106 230 minecraft:gray_concrete
fill 244 105 232 244 106 232 minecraft:gray_concrete
fill 244 105 234 244 106 234 minecraft:gray_concrete
fill 244 105 236 244 106 236 minecraft:gray_concrete
fill 244 105 262 244 106 262 minecraft:blue_terracotta
fill 244 105 264 244 106 264 minecraft:blue_terracotta
fill 244 105 266 244 106 266 minecraft:blue_terracotta
fill 244 105 268 244 106 268 minecraft:blue_terracotta
fill 249 105 230 249 106 230 minecraft:gray_concrete
fill 249 105 232 249 106 232 minecraft:gray_concrete
fill 249 105 265 249 106 265 minecraft:gray_concrete
fill 249 105 267 249 106 267 minecraft:gray_concrete
fill 250 105 229 250 106 229 minecraft:gray_concrete
fill 250 105 234 250 106 234 minecraft:gray_concrete
fill 250 105 264 250 106 264 minecraft:gray_concrete
fill 250 105 269 250 106 269 minecraft:gray_concrete
fill 252 105 229 252 106 229 minecraft:gray_concrete
fill 252 105 234 252 106 234 minecraft:gray_concrete
fill 252 105 264 252 106 264 minecraft:gray_concrete
fill 252 105 269 252 106 269 minecraft:gray_concrete
fill 254 105 229 254 106 229 minecraft:gray_concrete
fill 254 105 234 254 106 234 minecraft:gray_concrete
fill 254 105 264 254 106 264 minecraft:gray_concrete
fill 254 105 269 254 106 269 minecraft:gray_concrete
fill 256 105 229 256 106 229 minecraft:gray_concrete
fill 256 105 234 256 106 234 minecraft:gray_concrete
fill 256 105 264 256 106 264 minecraft:gray_concrete
fill 256 105 269 256 106 269 minecraft:gray_concrete
fill 258 105 229 258 106 229 minecraft:gray_concrete
fill 258 105 234 258 106 234 minecraft:gray_concrete
fill 258 105 264 258 106 264 minecraft:gray_concrete
fill 258 105 269 258 106 269 minecraft:gray_concrete
fill 260 105 229 260 106 229 minecraft:gray_concrete
fill 260 105 234 260 106 234 minecraft:gray_concrete
fill 260 105 264 260 106 264 minecraft:gray_concrete
fill 260 105 269 260 106 269 minecraft:gray_concrete
fill 262 105 230 262 106 230 minecraft:gray_concrete
fill 262 105 232 262 106 232 minecraft:gray_concrete
fill 262 105 265 262 106 265 minecraft:gray_concrete
fill 262 105 267 262 106 267 minecraft:gray_concrete
fill 265 105 267 267 106 267 minecraft:iron_block
fill 268 105 230 268 106 230 minecraft:blue_terracotta
fill 268 105 232 268 106 232 minecraft:blue_terracotta
fill 268 105 234 268 106 234 minecraft:blue_terracotta
fill 268 105 236 268 106 236 minecraft:blue_terracotta
fill 268 105 262 268 106 262 minecraft:gray_concrete
fill 268 105 264 268 106 264 minecraft:gray_concrete
fill 268 105 266 268 106 266 minecraft:gray_concrete
fill 268 105 268 268 106 268 minecraft:gray_concrete
fill 269 105 229 269 106 229 minecraft:blue_terracotta
fill 269 105 237 269 106 237 minecraft:blue_terracotta
fill 269 105 261 269 106 261 minecraft:gray_concrete
fill 269 105 269 269 106 269 minecraft:gray_concrete
fill 271 105 229 271 106 229 minecraft:blue_terracotta
fill 271 105 237 271 106 237 minecraft:blue_terracotta
fill 271 105 243 271 106 243 minecraft:gray_concrete
fill 271 105 245 271 106 245 minecraft:gray_concrete
fill 271 105 247 271 106 247 minecraft:gray_concrete
fill 271 105 249 271 106 249 minecraft:gray_concrete
fill 271 105 251 271 106 251 minecraft:gray_concrete
fill 271 105 253 271 106 253 minecraft:gray_concrete
fill 271 105 261 271 106 261 minecraft:gray_concrete
fill 271 105 269 271 106 269 minecraft:gray_concrete
fill 272 105 228 272 132 228 minecraft:black_concrete
fill 272 105 242 272 106 242 minecraft:gray_concrete
fill 272 105 255 272 106 255 minecraft:gray_concrete
fill 273 105 229 273 106 229 minecraft:blue_terracotta
fill 273 105 237 273 106 237 minecraft:blue_terracotta
fill 273 105 261 273 106 261 minecraft:gray_concrete
fill 273 105 269 273 106 269 minecraft:gray_concrete
fill 274 105 242 274 106 242 minecraft:gray_concrete
fill 274 105 255 274 106 255 minecraft:gray_concrete
fill 275 105 229 275 106 229 minecraft:blue_terracotta
fill 275 105 237 275 106 237 minecraft:blue_terracotta
fill 275 105 261 275 106 261 minecraft:gray_concrete
fill 275 105 269 275 106 269 minecraft:gray_concrete
fill 276 105 230 276 106 230 minecraft:blue_terracotta
fill 276 105 232 276 106 232 minecraft:blue_terracotta
fill 276 105 234 276 106 234 minecraft:blue_terracotta
fill 276 105 236 276 106 236 minecraft:blue_terracotta
fill 276 105 243 276 106 243 minecraft:gray_concrete
fill 276 105 245 276 106 245 minecraft:gray_concrete
fill 276 105 247 276 106 247 minecraft:gray_concrete
fill 276 105 249 276 106 249 minecraft:gray_concrete
fill 276 105 251 276 106 251 minecraft:gray_concrete
fill 276 105 253 276 106 253 minecraft:gray_concrete
fill 276 105 262 276 106 262 minecraft:gray_concrete
fill 276 105 264 276 106 264 minecraft:gray_concrete
fill 276 105 266 276 106 266 minecraft:gray_concrete
fill 276 105 268 276 106 268 minecraft:gray_concrete
fill 277 105 246 277 308 246 minecraft:black_concrete
fill 235 106 232 235 229 232 minecraft:black_concrete
setblock 235 106 261 minecraft:verdant_froglight
setblock 277 106 240 minecraft:purple_concrete
setblock 235 107 261 minecraft:pearlescent_froglight
setblock 236 107 230 minecraft:black_stained_glass
setblock 236 107 232 minecraft:black_stained_glass
setblock 236 107 234 minecraft:light_blue_stained_glass
setblock 236 107 236 minecraft:light_blue_stained_glass
setblock 236 107 243 minecraft:light_blue_stained_glass
setblock 236 107 245 minecraft:light_blue_stained_glass
setblock 236 107 247 minecraft:ochre_froglight
setblock 236 107 249 minecraft:cyan_stained_glass
setblock 236 107 251 minecraft:sea_lantern
setblock 236 107 253 minecraft:cyan_stained_glass
setblock 236 107 262 minecraft:black_stained_glass
setblock 236 107 264 minecraft:black_stained_glass
setblock 236 107 266 minecraft:sea_lantern
setblock 236 107 268 minecraft:cyan_stained_glass
setblock 237 107 229 minecraft:black_stained_glass
setblock 237 107 237 minecraft:black_stained_glass
setblock 237 107 242 minecraft:magenta_stained_glass
setblock 237 107 255 minecraft:black_stained_glass
setblock 237 107 261 minecraft:cyan_stained_glass
setblock 237 107 269 minecraft:light_blue_stained_glass
setblock 239 107 229 minecraft:sea_lantern
setblock 239 107 237 minecraft:magenta_stained_glass
setblock 239 107 242 minecraft:cyan_stained_glass
setblock 239 107 255 minecraft:black_stained_glass
setblock 239 107 261 minecraft:sea_lantern
setblock 239 107 269 minecraft:black_stained_glass
setblock 241 107 229 minecraft:sea_lantern
setblock 241 107 237 minecraft:ochre_froglight
setblock 241 107 243 minecraft:black_stained_glass
setblock 241 107 245 minecraft:black_stained_glass
setblock 241 107 247 minecraft:ochre_froglight
setblock 241 107 249 minecraft:ochre_froglight
setblock 241 107 251 minecraft:magenta_stained_glass
setblock 241 107 253 minecraft:cyan_stained_glass
setblock 241 107 261 minecraft:cyan_stained_glass
setblock 241 107 269 minecraft:black_stained_glass
setblock 243 107 229 minecraft:magenta_stained_glass
setblock 243 107 237 minecraft:black_stained_glass
setblock 243 107 261 minecraft:magenta_stained_glass
setblock 243 107 269 minecraft:black_stained_glass
setblock 244 107 230 minecraft:cyan_stained_glass
setblock 244 107 232 minecraft:light_blue_stained_glass
setblock 244 107 234 minecraft:light_blue_stained_glass
setblock 244 107 236 minecraft:cyan_stained_glass
setblock 244 107 262 minecraft:pearlescent_froglight
setblock 244 107 264 minecraft:black_stained_glass
setblock 244 107 266 minecraft:black_stained_glass
setblock 244 107 268 minecraft:black_stained_glass
setblock 249 107 230 minecraft:black_stained_glass
setblock 249 107 232 minecraft:magenta_stained_glass
setblock 249 107 265 minecraft:light_blue_stained_glass
setblock 249 107 267 minecraft:ochre_froglight
setblock 250 107 229 minecraft:black_stained_glass
setblock 250 107 234 minecraft:black_stained_glass
setblock 250 107 264 minecraft:magenta_stained_glass
setblock 250 107 269 minecraft:black_stained_glass
setblock 252 107 229 minecraft:black_stained_glass
setblock 252 107 234 minecraft:light_blue_stained_glass
setblock 252 107 264 minecraft:black_stained_glass
setblock 252 107 269 minecraft:sea_lantern
setblock 254 107 229 minecraft:magenta_stained_glass
setblock 254 107 234 minecraft:black_stained_glass
setblock 254 107 264 minecraft:black_stained_glass
setblock 254 107 269 minecraft:light_blue_stained_glass
setblock 256 107 229 minecraft:ochre_froglight
setblock 256 107 234 minecraft:black_stained_glass
setblock 256 107 264 minecraft:black_stained_glass
setblock 256 107 269 minecraft:black_stained_glass
setblock 258 107 229 minecraft:ochre_froglight
setblock 258 107 234 minecraft:black_stained_glass
setblock 258 107 264 minecraft:black_stained_glass
setblock 258 107 269 minecraft:light_blue_stained_glass
setblock 260 107 229 minecraft:cyan_stained_glass
setblock 260 107 234 minecraft:light_blue_stained_glass
setblock 260 107 264 minecraft:sea_lantern
setblock 260 107 269 minecraft:cyan_stained_glass
setblock 260 107 270 minecraft:pearlescent_froglight
setblock 262 107 230 minecraft:cyan_stained_glass
setblock 262 107 232 minecraft:light_blue_stained_glass
setblock 262 107 265 minecraft:cyan_stained_glass
setblock 262 107 267 minecraft:light_blue_stained_glass
setblock 268 107 230 minecraft:sea_lantern
setblock 268 107 232 minecraft:black_stained_glass
setblock 268 107 234 minecraft:magenta_stained_glass
setblock 268 107 236 minecraft:light_blue_stained_glass
setblock 268 107 262 minecraft:light_blue_stained_glass
setblock 268 107 264 minecraft:black_stained_glass
setblock 268 107 266 minecraft:magenta_stained_glass
setblock 268 107 268 minecraft:light_blue_stained_glass
setblock 269 107 229 minecraft:black_stained_glass
setblock 269 107 237 minecraft:black_stained_glass
setblock 269 107 261 minecraft:black_stained_glass
setblock 269 107 269 minecraft:sea_lantern
setblock 271 107 229 minecraft:black_stained_glass
setblock 271 107 237 minecraft:black_stained_glass
setblock 271 107 243 minecraft:black_stained_glass
setblock 271 107 245 minecraft:cyan_stained_glass
setblock 271 107 247 minecraft:ochre_froglight
setblock 271 107 249 minecraft:sea_lantern
setblock 271 107 251 minecraft:magenta_stained_glass
setblock 271 107 253 minecraft:magenta_stained_glass
setblock 271 107 261 minecraft:black_stained_glass
setblock 271 107 269 minecraft:cyan_stained_glass
setblock 272 107 242 minecraft:cyan_stained_glass
setblock 272 107 255 minecraft:black_stained_glass
setblock 273 107 229 minecraft:black_stained_glass
setblock 273 107 237 minecraft:pearlescent_froglight
setblock 273 107 261 minecraft:black_stained_glass
setblock 273 107 269 minecraft:black_stained_glass
setblock 274 107 242 minecraft:magenta_stained_glass
setblock 274 107 255 minecraft:black_stained_glass
setblock 275 107 229 minecraft:magenta_stained_glass
setblock 275 107 237 minecraft:black_stained_glass
setblock 275 107 261 minecraft:black_stained_glass
setblock 275 107 269 minecraft:light_blue_stained_glass
setblock 276 107 230 minecraft:black_stained_glass
setblock 276 107 232 minecraft:black_stained_glass
setblock 276 107 234 minecraft:sea_lantern
setblock 276 107 236 minecraft:ochre_froglight
setblock 276 107 243 minecraft:sea_lantern
setblock 276 107 245 minecraft:sea_lantern
setblock 276 107 247 minecraft:pearlescent_froglight
setblock 276 107 249 minecraft:black_stained_glass
setblock 276 107 251 minecraft:magenta_stained_glass
setblock 276 107 253 minecraft:black_stained_glass
setblock 276 107 262 minecraft:ochre_froglight
setblock 276 107 264 minecraft:ochre_froglight
setblock 276 107 266 minecraft:black_stained_glass
setblock 276 107 268 minecraft:black_stained_glass
fill 277 107 240 277 131 240 minecraft:black_concrete
fill 235 108 243 235 113 247 minecraft:black_concrete
setblock 235 108 248 minecraft:magenta_concrete
fill 235 108 249 236 109 249 minecraft:black_concrete
fill 235 108 261 235 133 261 minecraft:black_concrete
fill 236 108 230 236 109 230 minecraft:gray_concrete
fill 236 108 232 236 109 232 minecraft:gray_concrete
fill 236 108 234 236 109 234 minecraft:gray_concrete
fill 236 108 236 236 109 236 minecraft:gray_concrete
fill 236 108 243 236 109 243 minecraft:black_concrete
fill 236 108 245 236 109 245 minecraft:black_concrete
fill 236 108 247 236 109 247 minecraft:black_concrete
fill 236 108 251 236 109 251 minecraft:black_concrete
fill 236 108 253 236 109 253 minecraft:black_concrete
fill 236 108 262 236 109 262 minecraft:blue_terracotta
fill 236 108 264 236 109 264 minecraft:blue_terracotta
fill 236 108 266 236 109 266 minecraft:blue_terracotta
fill 236 108 268 236 109 268 minecraft:blue_terracotta
fill 237 108 229 237 109 229 minecraft:gray_concrete
fill 237 108 237 237 109 237 minecraft:gray_concrete
fill 237 108 242 237 109 242 minecraft:black_concrete
fill 237 108 255 237 109 255 minecraft:black_concrete
fill 237 108 261 237 109 261 minecraft:blue_terracotta
fill 237 108 269 237 109 269 minecraft:blue_terracotta
setblock 238 108 239 minecraft:light[level=15]
fill 239 108 229 239 109 229 minecraft:gray_concrete
fill 239 108 237 239 109 237 minecraft:gray_concrete
fill 239 108 242 239 109 242 minecraft:black_concrete
fill 239 108 255 239 109 255 minecraft:black_concrete
fill 239 108 261 239 109 261 minecraft:blue_terracotta
fill 239 108 269 239 109 269 minecraft:blue_terracotta
fill 241 108 229 241 109 229 minecraft:gray_concrete
fill 241 108 237 241 109 237 minecraft:gray_concrete
fill 241 108 243 241 109 243 minecraft:black_concrete
fill 241 108 245 241 109 245 minecraft:black_concrete
fill 241 108 247 241 109 247 minecraft:black_concrete
fill 241 108 249 241 109 249 minecraft:black_concrete
fill 241 108 251 241 109 251 minecraft:black_concrete
fill 241 108 253 241 109 253 minecraft:black_concrete
fill 241 108 261 241 109 261 minecraft:blue_terracotta
fill 241 108 269 241 109 269 minecraft:blue_terracotta
fill 243 108 229 243 109 229 minecraft:gray_concrete
fill 243 108 237 243 109 237 minecraft:gray_concrete
fill 243 108 261 243 109 261 minecraft:blue_terracotta
fill 243 108 269 243 109 269 minecraft:blue_terracotta
fill 244 108 230 244 109 230 minecraft:gray_concrete
fill 244 108 232 244 109 232 minecraft:gray_concrete
fill 244 108 234 244 109 234 minecraft:gray_concrete
fill 244 108 236 244 109 236 minecraft:gray_concrete
fill 244 108 262 244 109 262 minecraft:blue_terracotta
fill 244 108 264 244 109 264 minecraft:blue_terracotta
fill 244 108 266 244 109 266 minecraft:blue_terracotta
fill 244 108 268 244 109 268 minecraft:blue_terracotta
setblock 246 108 231 minecraft:light[level=15]
setblock 246 108 239 minecraft:light[level=15]
setblock 246 108 247 minecraft:light[level=15]
setblock 246 108 255 minecraft:light[level=15]
setblock 246 108 263 minecraft:light[level=15]
fill 249 108 230 249 109 230 minecraft:gray_concrete
fill 249 108 232 249 109 232 minecraft:gray_concrete
fill 249 108 265 249 109 265 minecraft:gray_concrete
fill 249 108 267 249 109 267 minecraft:gray_concrete
fill 250 108 229 250 109 229 minecraft:gray_concrete
fill 250 108 234 250 109 234 minecraft:gray_concrete
fill 250 108 264 250 109 264 minecraft:gray_concrete
fill 250 108 269 250 109 269 minecraft:gray_concrete
fill 252 108 229 252 109 229 minecraft:gray_concrete
fill 252 108 234 252 109 234 minecraft:gray_concrete
fill 252 108 264 252 109 264 minecraft:gray_concrete
fill 252 108 269 252 109 269 minecraft:gray_concrete
fill 254 108 229 254 109 229 minecraft:gray_concrete
fill 254 108 234 254 109 234 minecraft:gray_concrete
setblock 254 108 239 minecraft:light[level=15]
setblock 254 108 247 minecraft:light[level=15]
setblock 254 108 255 minecraft:light[level=15]
setblock 254 108 263 minecraft:light[level=15]
fill 254 108 264 254 109 264 minecraft:gray_concrete
fill 254 108 269 254 109 269 minecraft:gray_concrete
fill 256 108 229 256 109 229 minecraft:gray_concrete
fill 256 108 234 256 109 234 minecraft:gray_concrete
fill 256 108 264 256 109 264 minecraft:gray_concrete
fill 256 108 269 256 109 269 minecraft:gray_concrete
fill 258 108 229 258 109 229 minecraft:gray_concrete
fill 258 108 234 258 109 234 minecraft:gray_concrete
fill 258 108 264 258 109 264 minecraft:gray_concrete
fill 258 108 269 258 109 269 minecraft:gray_concrete
fill 260 108 229 260 109 229 minecraft:gray_concrete
fill 260 108 234 260 109 234 minecraft:gray_concrete
fill 260 108 264 260 109 264 minecraft:gray_concrete
fill 260 108 269 260 109 269 minecraft:gray_concrete
fill 260 108 270 260 215 270 minecraft:black_concrete
fill 262 108 230 262 109 230 minecraft:gray_concrete
fill 262 108 232 262 109 232 minecraft:gray_concrete
setblock 262 108 239 minecraft:light[level=15]
setblock 262 108 247 minecraft:light[level=15]
setblock 262 108 255 minecraft:light[level=15]
setblock 262 108 263 minecraft:light[level=15]
fill 262 108 265 262 109 265 minecraft:gray_concrete
fill 262 108 267 262 109 267 minecraft:gray_concrete
setblock 264 108 270 minecraft:sea_lantern
fill 268 108 230 268 109 230 minecraft:blue_terracotta
fill 268 108 232 268 109 232 minecraft:blue_terracotta
fill 268 108 234 268 109 234 minecraft:blue_terracotta
fill 268 108 236 268 109 236 minecraft:blue_terracotta
fill 268 108 262 268 109 262 minecraft:gray_concrete
fill 268 108 264 268 109 264 minecraft:gray_concrete
fill 268 108 266 268 109 266 minecraft:gray_concrete
fill 268 108 268 268 109 268 minecraft:gray_concrete
fill 269 108 229 269 109 229 minecraft:blue_terracotta
fill 269 108 237 269 109 237 minecraft:blue_terracotta
fill 269 108 261 269 109 261 minecraft:gray_concrete
fill 269 108 269 269 109 269 minecraft:gray_concrete
setblock 270 108 239 minecraft:light[level=15]
setblock 270 108 247 minecraft:light[level=15]
setblock 270 108 255 minecraft:light[level=15]
fill 271 108 229 271 109 229 minecraft:blue_terracotta
fill 271 108 237 271 109 237 minecraft:blue_terracotta
fill 271 108 243 271 109 243 minecraft:gray_concrete
fill 271 108 245 271 109 245 minecraft:gray_concrete
fill 271 108 247 271 109 247 minecraft:gray_concrete
fill 271 108 249 271 109 249 minecraft:gray_concrete
fill 271 108 251 271 109 251 minecraft:gray_concrete
fill 271 108 253 271 109 253 minecraft:gray_concrete
fill 271 108 261 271 109 261 minecraft:gray_concrete
fill 271 108 269 271 109 269 minecraft:gray_concrete
fill 272 108 242 272 109 242 minecraft:gray_concrete
fill 272 108 255 272 109 255 minecraft:gray_concrete
fill 272 108 270 272 161 270 minecraft:black_concrete
fill 273 108 229 273 109 229 minecraft:blue_terracotta
fill 273 108 237 273 109 237 minecraft:blue_terracotta
fill 273 108 261 273 109 261 minecraft:gray_concrete
fill 273 108 269 273 109 269 minecraft:gray_concrete
setblock 273 108 270 minecraft:pearlescent_froglight
fill 274 108 242 274 109 242 minecraft:gray_concrete
fill 274 108 255 274 109 255 minecraft:gray_concrete
fill 275 108 229 275 109 229 minecraft:blue_terracotta
fill 275 108 237 275 109 237 minecraft:blue_terracotta
fill 275 108 261 275 109 261 minecraft:gray_concrete
fill 275 108 269 275 109 269 minecraft:gray_concrete
fill 276 108 230 276 109 230 minecraft:blue_terracotta
fill 276 108 232 276 109 232 minecraft:blue_terracotta
fill 276 108 234 276 109 234 minecraft:blue_terracotta
fill 276 108 236 276 109 236 minecraft:blue_terracotta
fill 276 108 243 276 109 243 minecraft:gray_concrete
fill 276 108 245 276 109 245 minecraft:gray_concrete
fill 276 108 247 276 109 247 minecraft:gray_concrete
fill 276 108 249 276 109 249 minecraft:gray_concrete
fill 276 108 251 276 109 251 minecraft:gray_concrete
fill 276 108 253 276 109 253 minecraft:gray_concrete
fill 276 108 262 276 109 262 minecraft:gray_concrete
fill 276 108 264 276 109 264 minecraft:gray_concrete
fill 276 108 266 276 109 266 minecraft:gray_concrete
fill 276 108 268 276 109 268 minecraft:gray_concrete
fill 235 109 248 235 129 248 minecraft:black_concrete
setblock 238 109 238 minecraft:light[level=12]
setblock 238 109 259 minecraft:light[level=12]
setblock 240 109 228 minecraft:blue_concrete
setblock 245 109 231 minecraft:light[level=12]
setblock 245 109 238 minecraft:light[level=12]
setblock 245 109 245 minecraft:light[level=12]
setblock 245 109 252 minecraft:light[level=12]
setblock 245 109 259 minecraft:light[level=12]
setblock 245 109 266 minecraft:light[level=12]
setblock 252 109 238 minecraft:light[level=12]
setblock 252 109 245 minecraft:light[level=12]
setblock 252 109 252 minecraft:light[level=12]
setblock 252 109 259 minecraft:light[level=12]
setblock 259 109 238 minecraft:light[level=12]
setblock 259 109 245 minecraft:light[level=12]
setblock 259 109 252 minecraft:light[level=12]
setblock 259 109 259 minecraft:light[level=12]
fill 261 109 270 261 125 270 minecraft:black_concrete
setblock 262 109 270 minecraft:cyan_concrete
fill 264 109 270 264 185 270 minecraft:black_concrete
setblock 266 109 231 minecraft:light[level=12]
setblock 266 109 238 minecraft:light[level=12]
setblock 266 109 245 minecraft:light[level=12]
setblock 266 109 252 minecraft:light[level=12]
setblock 266 109 259 minecraft:light[level=12]
setblock 266 109 266 minecraft:light[level=12]
setblock 273 109 238 minecraft:light[level=12]
setblock 273 109 259 minecraft:light[level=12]
fill 273 109 270 273 123 270 minecraft:black_concrete
fill 235 110 249 235 113 249 minecraft:black_concrete
setblock 236 110 230 minecraft:black_stained_glass
setblock 236 110 232 minecraft:sea_lantern
setblock 236 110 234 minecraft:black_stained_glass
setblock 236 110 236 minecraft:black_stained_glass
setblock 236 110 243 minecraft:black_stained_glass
setblock 236 110 245 minecraft:light_blue_stained_glass
setblock 236 110 247 minecraft:ochre_froglight
setblock 236 110 249 minecraft:sea_lantern
setblock 236 110 251 minecraft:black_stained_glass
setblock 236 110 253 minecraft:magenta_stained_glass
setblock 236 110 262 minecraft:light_blue_stained_glass
setblock 236 110 264 minecraft:ochre_froglight
setblock 236 110 266 minecraft:black_stained_glass
setblock 236 110 268 minecraft:black_stained_glass
setblock 237 110 229 minecraft:black_stained_glass
setblock 237 110 237 minecraft:ochre_froglight
setblock 237 110 242 minecraft:black_stained_glass
setblock 237 110 255 minecraft:black_stained_glass
setblock 237 110 261 minecraft:black_stained_glass
setblock 237 110 269 minecraft:sea_lantern
setblock 239 110 229 minecraft:sea_lantern
setblock 239 110 237 minecraft:pearlescent_froglight
setblock 239 110 242 minecraft:sea_lantern
setblock 239 110 255 minecraft:magenta_stained_glass
setblock 239 110 261 minecraft:black_stained_glass
setblock 239 110 269 minecraft:pearlescent_froglight
fill 240 110 228 240 150 228 minecraft:black_concrete
setblock 241 110 229 minecraft:pearlescent_froglight
setblock 241 110 237 minecraft:ochre_froglight
schedule function dropper:buildpart/53_2 1t
