setblock 558 125 342 minecraft:stripped_dark_oak_log
setblock 558 125 349 minecraft:stripped_dark_oak_log
setblock 558 125 356 minecraft:stripped_dark_oak_log
setblock 518 127 329 minecraft:stripped_dark_oak_log
setblock 518 127 336 minecraft:stripped_dark_oak_log
setblock 518 127 343 minecraft:stripped_dark_oak_log
setblock 518 127 350 minecraft:stripped_dark_oak_log
setblock 518 127 357 minecraft:stripped_dark_oak_log
setblock 519 127 323 minecraft:stripped_dark_oak_log
setblock 519 127 363 minecraft:stripped_dark_oak_log
setblock 526 127 323 minecraft:stripped_dark_oak_log
setblock 526 127 363 minecraft:stripped_dark_oak_log
fill 532 127 353 532 128 353 minecraft:pink_wool
setblock 533 127 323 minecraft:stripped_dark_oak_log
setblock 533 127 363 minecraft:stripped_dark_oak_log
setblock 540 127 323 minecraft:stripped_dark_oak_log
setblock 540 127 363 minecraft:stripped_dark_oak_log
setblock 547 127 323 minecraft:stripped_dark_oak_log
setblock 547 127 363 minecraft:stripped_dark_oak_log
setblock 554 127 323 minecraft:stripped_dark_oak_log
setblock 554 127 363 minecraft:stripped_dark_oak_log
setblock 558 127 326 minecraft:stripped_dark_oak_log
setblock 558 127 333 minecraft:stripped_dark_oak_log
setblock 558 127 340 minecraft:stripped_dark_oak_log
setblock 558 127 347 minecraft:stripped_dark_oak_log
setblock 558 127 354 minecraft:stripped_dark_oak_log
setblock 558 127 361 minecraft:stripped_dark_oak_log
setblock 518 128 323 minecraft:stripped_dark_oak_log
setblock 518 128 330 minecraft:stripped_dark_oak_log
setblock 518 128 337 minecraft:stripped_dark_oak_log
setblock 518 128 344 minecraft:stripped_dark_oak_log
setblock 518 128 351 minecraft:stripped_dark_oak_log
setblock 518 128 358 minecraft:stripped_dark_oak_log
setblock 520 128 363 minecraft:stripped_dark_oak_log
setblock 525 128 323 minecraft:stripped_dark_oak_log
setblock 527 128 363 minecraft:stripped_dark_oak_log
setblock 532 128 323 minecraft:stripped_dark_oak_log
setblock 534 128 363 minecraft:stripped_dark_oak_log
setblock 539 128 323 minecraft:stripped_dark_oak_log
setblock 541 128 363 minecraft:stripped_dark_oak_log
setblock 546 128 323 minecraft:stripped_dark_oak_log
setblock 548 128 363 minecraft:stripped_dark_oak_log
setblock 553 128 323 minecraft:stripped_dark_oak_log
setblock 555 128 363 minecraft:stripped_dark_oak_log
setblock 558 128 325 minecraft:stripped_dark_oak_log
setblock 558 128 332 minecraft:stripped_dark_oak_log
setblock 558 128 339 minecraft:stripped_dark_oak_log
setblock 558 128 346 minecraft:stripped_dark_oak_log
setblock 558 128 353 minecraft:stripped_dark_oak_log
setblock 558 128 360 minecraft:stripped_dark_oak_log
fill 518 129 324 518 130 324 minecraft:stripped_dark_oak_log
fill 518 129 331 518 130 331 minecraft:stripped_dark_oak_log
fill 518 129 336 520 129 336 minecraft:iron_bars
fill 518 129 338 518 130 338 minecraft:stripped_dark_oak_log
fill 518 129 345 518 130 345 minecraft:stripped_dark_oak_log
fill 518 129 352 518 130 352 minecraft:stripped_dark_oak_log
fill 518 129 359 518 130 359 minecraft:stripped_dark_oak_log
fill 521 129 363 521 130 363 minecraft:stripped_dark_oak_log
fill 524 129 323 524 130 323 minecraft:stripped_dark_oak_log
fill 528 129 363 528 130 363 minecraft:stripped_dark_oak_log
fill 531 129 323 531 130 323 minecraft:stripped_dark_oak_log
fill 535 129 363 535 130 363 minecraft:stripped_dark_oak_log
fill 538 129 323 538 130 323 minecraft:stripped_dark_oak_log
fill 542 129 363 542 130 363 minecraft:stripped_dark_oak_log
fill 545 129 323 545 130 323 minecraft:stripped_dark_oak_log
fill 549 129 363 549 130 363 minecraft:stripped_dark_oak_log
fill 552 129 323 552 130 323 minecraft:stripped_dark_oak_log
fill 556 129 363 556 130 363 minecraft:stripped_dark_oak_log
fill 558 129 324 558 130 324 minecraft:stripped_dark_oak_log
fill 558 129 331 558 130 331 minecraft:stripped_dark_oak_log
fill 558 129 338 558 130 338 minecraft:stripped_dark_oak_log
fill 558 129 345 558 130 345 minecraft:stripped_dark_oak_log
fill 558 129 352 558 130 352 minecraft:stripped_dark_oak_log
fill 558 129 359 558 130 359 minecraft:stripped_dark_oak_log
fill 518 130 323 519 130 323 minecraft:stripped_dark_oak_log
fill 518 130 325 518 130 327 minecraft:stripped_dark_oak_log
fill 518 130 329 518 130 330 minecraft:stripped_dark_oak_log
fill 518 130 332 518 130 334 minecraft:stripped_dark_oak_log
fill 518 130 336 518 130 337 minecraft:stripped_dark_oak_log
fill 518 130 339 518 130 341 minecraft:stripped_dark_oak_log
fill 518 130 343 518 130 344 minecraft:stripped_dark_oak_log
fill 518 130 346 518 130 348 minecraft:stripped_dark_oak_log
fill 518 130 350 518 130 351 minecraft:stripped_dark_oak_log
fill 518 130 353 518 130 355 minecraft:stripped_dark_oak_log
fill 518 130 357 518 130 358 minecraft:stripped_dark_oak_log
fill 518 130 360 518 130 362 minecraft:stripped_dark_oak_log
fill 519 130 336 520 130 336 minecraft:iron_bars
fill 519 130 360 519 131 362 minecraft:iron_bars
fill 519 130 363 520 130 363 minecraft:stripped_dark_oak_log
fill 521 130 323 523 130 323 minecraft:stripped_dark_oak_log
fill 522 130 363 524 130 363 minecraft:stripped_dark_oak_log
fill 525 130 323 526 130 323 minecraft:stripped_dark_oak_log
fill 526 130 363 527 130 363 minecraft:stripped_dark_oak_log
fill 528 130 323 530 130 323 minecraft:stripped_dark_oak_log
fill 529 130 363 531 130 363 minecraft:stripped_dark_oak_log
fill 532 130 323 533 130 323 minecraft:stripped_dark_oak_log
fill 533 130 363 534 130 363 minecraft:stripped_dark_oak_log
fill 535 130 323 537 130 323 minecraft:stripped_dark_oak_log
fill 536 130 363 538 130 363 minecraft:stripped_dark_oak_log
fill 539 130 323 540 130 323 minecraft:stripped_dark_oak_log
fill 540 130 363 541 130 363 minecraft:stripped_dark_oak_log
fill 542 130 323 544 130 323 minecraft:stripped_dark_oak_log
fill 543 130 363 545 130 363 minecraft:stripped_dark_oak_log
fill 546 130 323 547 130 323 minecraft:stripped_dark_oak_log
fill 547 130 363 548 130 363 minecraft:stripped_dark_oak_log
fill 549 130 323 551 130 323 minecraft:stripped_dark_oak_log
fill 550 130 363 552 130 363 minecraft:stripped_dark_oak_log
fill 553 130 323 554 130 323 minecraft:stripped_dark_oak_log
fill 554 130 363 555 130 363 minecraft:stripped_dark_oak_log
fill 556 130 323 558 130 323 minecraft:stripped_dark_oak_log
fill 557 130 363 558 130 363 minecraft:stripped_dark_oak_log
fill 558 130 325 558 130 326 minecraft:stripped_dark_oak_log
fill 558 130 328 558 130 330 minecraft:stripped_dark_oak_log
fill 558 130 332 558 130 333 minecraft:stripped_dark_oak_log
fill 558 130 335 558 130 337 minecraft:stripped_dark_oak_log
fill 558 130 339 558 130 340 minecraft:stripped_dark_oak_log
fill 558 130 342 558 130 344 minecraft:stripped_dark_oak_log
fill 558 130 346 558 130 347 minecraft:stripped_dark_oak_log
fill 558 130 349 558 130 351 minecraft:stripped_dark_oak_log
fill 558 130 353 558 130 354 minecraft:stripped_dark_oak_log
fill 558 130 356 558 130 358 minecraft:stripped_dark_oak_log
fill 558 130 360 558 130 361 minecraft:stripped_dark_oak_log
setblock 518 131 326 minecraft:stripped_dark_oak_log
setblock 518 131 333 minecraft:stripped_dark_oak_log
setblock 518 131 340 minecraft:stripped_dark_oak_log
setblock 518 131 347 minecraft:stripped_dark_oak_log
setblock 518 131 354 minecraft:stripped_dark_oak_log
setblock 518 131 361 minecraft:stripped_dark_oak_log
setblock 522 131 323 minecraft:stripped_dark_oak_log
setblock 523 131 363 minecraft:stripped_dark_oak_log
setblock 529 131 323 minecraft:stripped_dark_oak_log
setblock 530 131 363 minecraft:stripped_dark_oak_log
setblock 536 131 323 minecraft:stripped_dark_oak_log
setblock 537 131 363 minecraft:stripped_dark_oak_log
setblock 543 131 323 minecraft:stripped_dark_oak_log
setblock 544 131 363 minecraft:stripped_dark_oak_log
setblock 550 131 323 minecraft:stripped_dark_oak_log
setblock 551 131 363 minecraft:stripped_dark_oak_log
setblock 557 131 323 minecraft:stripped_dark_oak_log
setblock 558 131 329 minecraft:stripped_dark_oak_log
setblock 558 131 336 minecraft:stripped_dark_oak_log
setblock 558 131 343 minecraft:stripped_dark_oak_log
setblock 558 131 350 minecraft:stripped_dark_oak_log
setblock 558 131 357 minecraft:stripped_dark_oak_log
setblock 558 131 363 minecraft:stripped_dark_oak_log
setblock 518 132 327 minecraft:stripped_dark_oak_log
setblock 518 132 334 minecraft:stripped_dark_oak_log
setblock 518 132 341 minecraft:stripped_dark_oak_log
setblock 518 132 348 minecraft:stripped_dark_oak_log
setblock 518 132 355 minecraft:stripped_dark_oak_log
setblock 518 132 362 minecraft:stripped_dark_oak_log
setblock 520 132 325 minecraft:light[level=14]
setblock 520 132 333 minecraft:light[level=14]
setblock 520 132 341 minecraft:light[level=14]
setblock 520 132 349 minecraft:light[level=14]
setblock 520 132 357 minecraft:light[level=14]
setblock 521 132 323 minecraft:stripped_dark_oak_log
setblock 524 132 363 minecraft:stripped_dark_oak_log
setblock 528 132 323 minecraft:stripped_dark_oak_log
setblock 528 132 325 minecraft:light[level=14]
setblock 528 132 333 minecraft:light[level=14]
setblock 528 132 341 minecraft:light[level=14]
setblock 528 132 349 minecraft:light[level=14]
setblock 528 132 357 minecraft:light[level=14]
setblock 531 132 363 minecraft:stripped_dark_oak_log
setblock 535 132 323 minecraft:stripped_dark_oak_log
setblock 536 132 325 minecraft:light[level=14]
setblock 536 132 333 minecraft:light[level=14]
setblock 536 132 349 minecraft:light[level=14]
setblock 536 132 357 minecraft:light[level=14]
setblock 538 132 363 minecraft:stripped_dark_oak_log
setblock 542 132 323 minecraft:stripped_dark_oak_log
setblock 544 132 325 minecraft:light[level=14]
setblock 544 132 333 minecraft:light[level=14]
setblock 544 132 341 minecraft:light[level=14]
setblock 544 132 349 minecraft:light[level=14]
setblock 544 132 357 minecraft:light[level=14]
setblock 545 132 363 minecraft:stripped_dark_oak_log
setblock 549 132 323 minecraft:stripped_dark_oak_log
setblock 552 132 325 minecraft:light[level=14]
setblock 552 132 333 minecraft:light[level=14]
setblock 552 132 341 minecraft:light[level=14]
setblock 552 132 349 minecraft:light[level=14]
setblock 552 132 357 minecraft:light[level=14]
setblock 552 132 363 minecraft:stripped_dark_oak_log
setblock 556 132 323 minecraft:stripped_dark_oak_log
setblock 558 132 328 minecraft:stripped_dark_oak_log
setblock 558 132 335 minecraft:stripped_dark_oak_log
setblock 558 132 342 minecraft:stripped_dark_oak_log
setblock 558 132 349 minecraft:stripped_dark_oak_log
setblock 558 132 356 minecraft:stripped_dark_oak_log
fill 519 133 329 519 134 335 minecraft:iron_bars
setblock 518 134 329 minecraft:stripped_dark_oak_log
setblock 518 134 336 minecraft:stripped_dark_oak_log
setblock 518 134 343 minecraft:stripped_dark_oak_log
setblock 518 134 350 minecraft:stripped_dark_oak_log
setblock 518 134 357 minecraft:stripped_dark_oak_log
setblock 519 134 323 minecraft:stripped_dark_oak_log
setblock 519 134 363 minecraft:stripped_dark_oak_log
setblock 526 134 323 minecraft:stripped_dark_oak_log
setblock 526 134 363 minecraft:stripped_dark_oak_log
setblock 533 134 323 minecraft:stripped_dark_oak_log
setblock 533 134 363 minecraft:stripped_dark_oak_log
setblock 540 134 323 minecraft:stripped_dark_oak_log
setblock 540 134 363 minecraft:stripped_dark_oak_log
setblock 547 134 323 minecraft:stripped_dark_oak_log
setblock 547 134 363 minecraft:stripped_dark_oak_log
setblock 554 134 323 minecraft:stripped_dark_oak_log
setblock 554 134 363 minecraft:stripped_dark_oak_log
setblock 558 134 326 minecraft:stripped_dark_oak_log
setblock 558 134 333 minecraft:stripped_dark_oak_log
setblock 558 134 340 minecraft:stripped_dark_oak_log
setblock 558 134 347 minecraft:stripped_dark_oak_log
setblock 558 134 354 minecraft:stripped_dark_oak_log
setblock 558 134 361 minecraft:stripped_dark_oak_log
setblock 518 135 323 minecraft:stripped_dark_oak_log
setblock 518 135 330 minecraft:stripped_dark_oak_log
setblock 518 135 337 minecraft:stripped_dark_oak_log
setblock 518 135 344 minecraft:stripped_dark_oak_log
setblock 518 135 351 minecraft:stripped_dark_oak_log
setblock 518 135 358 minecraft:stripped_dark_oak_log
setblock 520 135 363 minecraft:stripped_dark_oak_log
setblock 525 135 323 minecraft:stripped_dark_oak_log
setblock 527 135 363 minecraft:stripped_dark_oak_log
setblock 532 135 323 minecraft:stripped_dark_oak_log
setblock 534 135 363 minecraft:stripped_dark_oak_log
setblock 539 135 323 minecraft:stripped_dark_oak_log
setblock 541 135 363 minecraft:stripped_dark_oak_log
setblock 546 135 323 minecraft:stripped_dark_oak_log
setblock 548 135 363 minecraft:stripped_dark_oak_log
setblock 553 135 323 minecraft:stripped_dark_oak_log
setblock 555 135 363 minecraft:stripped_dark_oak_log
setblock 558 135 325 minecraft:stripped_dark_oak_log
setblock 558 135 332 minecraft:stripped_dark_oak_log
setblock 558 135 339 minecraft:stripped_dark_oak_log
setblock 558 135 346 minecraft:stripped_dark_oak_log
setblock 558 135 353 minecraft:stripped_dark_oak_log
setblock 558 135 360 minecraft:stripped_dark_oak_log
setblock 518 136 324 minecraft:stripped_dark_oak_log
setblock 518 136 331 minecraft:stripped_dark_oak_log
setblock 518 136 338 minecraft:stripped_dark_oak_log
setblock 518 136 345 minecraft:stripped_dark_oak_log
setblock 518 136 352 minecraft:stripped_dark_oak_log
setblock 518 136 359 minecraft:stripped_dark_oak_log
setblock 521 136 363 minecraft:stripped_dark_oak_log
setblock 524 136 323 minecraft:stripped_dark_oak_log
setblock 528 136 363 minecraft:stripped_dark_oak_log
setblock 531 136 323 minecraft:stripped_dark_oak_log
fill 531 136 329 531 137 331 minecraft:pink_wool
fill 532 136 330 532 137 331 minecraft:pink_wool
setblock 535 136 363 minecraft:stripped_dark_oak_log
setblock 538 136 323 minecraft:stripped_dark_oak_log
setblock 542 136 363 minecraft:stripped_dark_oak_log
setblock 545 136 323 minecraft:stripped_dark_oak_log
setblock 549 136 363 minecraft:stripped_dark_oak_log
setblock 552 136 323 minecraft:stripped_dark_oak_log
setblock 556 136 363 minecraft:stripped_dark_oak_log
setblock 558 136 324 minecraft:stripped_dark_oak_log
setblock 558 136 331 minecraft:stripped_dark_oak_log
setblock 558 136 338 minecraft:stripped_dark_oak_log
setblock 558 136 345 minecraft:stripped_dark_oak_log
setblock 558 136 352 minecraft:stripped_dark_oak_log
setblock 558 136 359 minecraft:stripped_dark_oak_log
setblock 518 137 325 minecraft:stripped_dark_oak_log
setblock 518 137 332 minecraft:stripped_dark_oak_log
setblock 518 137 339 minecraft:stripped_dark_oak_log
setblock 518 137 346 minecraft:stripped_dark_oak_log
setblock 518 137 353 minecraft:stripped_dark_oak_log
setblock 518 137 360 minecraft:stripped_dark_oak_log
setblock 522 137 363 minecraft:stripped_dark_oak_log
setblock 523 137 323 minecraft:stripped_dark_oak_log
setblock 529 137 363 minecraft:stripped_dark_oak_log
setblock 530 137 323 minecraft:stripped_dark_oak_log
setblock 536 137 363 minecraft:stripped_dark_oak_log
setblock 537 137 323 minecraft:stripped_dark_oak_log
setblock 543 137 363 minecraft:stripped_dark_oak_log
setblock 544 137 323 minecraft:stripped_dark_oak_log
setblock 550 137 363 minecraft:stripped_dark_oak_log
setblock 551 137 323 minecraft:stripped_dark_oak_log
setblock 557 137 363 minecraft:stripped_dark_oak_log
setblock 558 137 323 minecraft:stripped_dark_oak_log
setblock 558 137 330 minecraft:stripped_dark_oak_log
setblock 558 137 337 minecraft:stripped_dark_oak_log
setblock 558 137 344 minecraft:stripped_dark_oak_log
setblock 558 137 351 minecraft:stripped_dark_oak_log
setblock 558 137 358 minecraft:stripped_dark_oak_log
setblock 518 138 326 minecraft:stripped_dark_oak_log
setblock 518 138 333 minecraft:stripped_dark_oak_log
setblock 518 138 340 minecraft:stripped_dark_oak_log
setblock 518 138 347 minecraft:stripped_dark_oak_log
setblock 518 138 354 minecraft:stripped_dark_oak_log
setblock 518 138 361 minecraft:stripped_dark_oak_log
setblock 522 138 323 minecraft:stripped_dark_oak_log
setblock 523 138 363 minecraft:stripped_dark_oak_log
setblock 529 138 323 minecraft:stripped_dark_oak_log
setblock 530 138 363 minecraft:stripped_dark_oak_log
setblock 536 138 323 minecraft:stripped_dark_oak_log
setblock 537 138 363 minecraft:stripped_dark_oak_log
setblock 543 138 323 minecraft:stripped_dark_oak_log
setblock 544 138 363 minecraft:stripped_dark_oak_log
setblock 550 138 323 minecraft:stripped_dark_oak_log
setblock 551 138 363 minecraft:stripped_dark_oak_log
setblock 557 138 323 minecraft:stripped_dark_oak_log
setblock 558 138 329 minecraft:stripped_dark_oak_log
setblock 558 138 336 minecraft:stripped_dark_oak_log
setblock 558 138 343 minecraft:stripped_dark_oak_log
setblock 558 138 350 minecraft:stripped_dark_oak_log
setblock 558 138 357 minecraft:stripped_dark_oak_log
setblock 558 138 363 minecraft:stripped_dark_oak_log
fill 518 139 327 518 140 327 minecraft:stripped_dark_oak_log
fill 518 139 334 518 140 334 minecraft:stripped_dark_oak_log
fill 518 139 341 518 140 341 minecraft:stripped_dark_oak_log
fill 518 139 348 518 140 348 minecraft:stripped_dark_oak_log
fill 518 139 355 518 140 355 minecraft:stripped_dark_oak_log
fill 518 139 362 518 140 362 minecraft:stripped_dark_oak_log
fill 521 139 323 521 140 323 minecraft:stripped_dark_oak_log
fill 524 139 363 524 140 363 minecraft:stripped_dark_oak_log
fill 528 139 323 528 140 323 minecraft:stripped_dark_oak_log
fill 531 139 363 531 140 363 minecraft:stripped_dark_oak_log
fill 535 139 323 535 140 323 minecraft:stripped_dark_oak_log
fill 538 139 363 538 140 363 minecraft:stripped_dark_oak_log
fill 542 139 323 542 140 323 minecraft:stripped_dark_oak_log
fill 545 139 363 545 140 363 minecraft:stripped_dark_oak_log
fill 549 139 323 549 140 323 minecraft:stripped_dark_oak_log
fill 552 139 363 552 140 363 minecraft:stripped_dark_oak_log
fill 556 139 323 556 140 323 minecraft:stripped_dark_oak_log
fill 558 139 328 558 140 328 minecraft:stripped_dark_oak_log
fill 558 139 335 558 140 335 minecraft:stripped_dark_oak_log
fill 558 139 342 558 140 342 minecraft:stripped_dark_oak_log
fill 558 139 349 558 140 349 minecraft:stripped_dark_oak_log
fill 558 139 356 558 140 356 minecraft:stripped_dark_oak_log
fill 518 140 323 518 140 326 minecraft:stripped_dark_oak_log
fill 518 140 329 518 140 333 minecraft:stripped_dark_oak_log
fill 518 140 336 518 140 340 minecraft:stripped_dark_oak_log
fill 518 140 343 518 140 347 minecraft:stripped_dark_oak_log
fill 518 140 350 518 140 354 minecraft:stripped_dark_oak_log
fill 518 140 357 518 140 361 minecraft:stripped_dark_oak_log
fill 519 140 323 519 141 323 minecraft:stripped_dark_oak_log
fill 519 140 363 523 140 363 minecraft:stripped_dark_oak_log
setblock 520 140 325 minecraft:light[level=14]
setblock 520 140 333 minecraft:light[level=14]
setblock 520 140 341 minecraft:light[level=14]
setblock 520 140 349 minecraft:light[level=14]
setblock 520 140 357 minecraft:light[level=14]
fill 522 140 323 526 140 323 minecraft:stripped_dark_oak_log
fill 526 140 363 530 140 363 minecraft:stripped_dark_oak_log
setblock 528 140 325 minecraft:light[level=14]
setblock 528 140 333 minecraft:light[level=14]
setblock 528 140 341 minecraft:light[level=14]
setblock 528 140 349 minecraft:light[level=14]
setblock 528 140 357 minecraft:light[level=14]
fill 529 140 323 533 140 323 minecraft:stripped_dark_oak_log
fill 533 140 363 537 140 363 minecraft:stripped_dark_oak_log
fill 536 140 323 540 140 323 minecraft:stripped_dark_oak_log
setblock 536 140 325 minecraft:light[level=14]
setblock 536 140 333 minecraft:light[level=14]
setblock 536 140 349 minecraft:light[level=14]
setblock 536 140 357 minecraft:light[level=14]
fill 540 140 363 544 140 363 minecraft:stripped_dark_oak_log
fill 543 140 323 547 140 323 minecraft:stripped_dark_oak_log
setblock 544 140 325 minecraft:light[level=14]
setblock 544 140 333 minecraft:light[level=14]
setblock 544 140 341 minecraft:light[level=14]
setblock 544 140 349 minecraft:light[level=14]
setblock 544 140 357 minecraft:light[level=14]
fill 547 140 363 551 140 363 minecraft:stripped_dark_oak_log
fill 550 140 323 554 140 323 minecraft:stripped_dark_oak_log
setblock 552 140 325 minecraft:light[level=14]
setblock 552 140 333 minecraft:light[level=14]
setblock 552 140 341 minecraft:light[level=14]
setblock 552 140 349 minecraft:light[level=14]
setblock 552 140 357 minecraft:light[level=14]
fill 554 140 363 558 140 363 minecraft:stripped_dark_oak_log
fill 557 140 323 558 140 323 minecraft:stripped_dark_oak_log
fill 558 140 324 558 140 326 minecraft:stripped_dark_oak_log
fill 558 140 329 558 140 333 minecraft:stripped_dark_oak_log
fill 558 140 336 558 140 340 minecraft:stripped_dark_oak_log
fill 558 140 343 558 140 347 minecraft:stripped_dark_oak_log
fill 558 140 350 558 140 354 minecraft:stripped_dark_oak_log
fill 558 140 357 558 140 361 minecraft:stripped_dark_oak_log
setblock 518 141 329 minecraft:stripped_dark_oak_log
setblock 518 141 336 minecraft:stripped_dark_oak_log
setblock 518 141 343 minecraft:stripped_dark_oak_log
setblock 518 141 350 minecraft:stripped_dark_oak_log
setblock 518 141 357 minecraft:stripped_dark_oak_log
setblock 519 141 363 minecraft:stripped_dark_oak_log
setblock 526 141 323 minecraft:stripped_dark_oak_log
setblock 526 141 363 minecraft:stripped_dark_oak_log
setblock 533 141 323 minecraft:stripped_dark_oak_log
setblock 533 141 363 minecraft:stripped_dark_oak_log
setblock 540 141 323 minecraft:stripped_dark_oak_log
setblock 540 141 363 minecraft:stripped_dark_oak_log
setblock 547 141 323 minecraft:stripped_dark_oak_log
setblock 547 141 363 minecraft:stripped_dark_oak_log
setblock 554 141 323 minecraft:stripped_dark_oak_log
setblock 554 141 363 minecraft:stripped_dark_oak_log
setblock 558 141 326 minecraft:stripped_dark_oak_log
setblock 558 141 333 minecraft:stripped_dark_oak_log
setblock 558 141 340 minecraft:stripped_dark_oak_log
setblock 558 141 347 minecraft:stripped_dark_oak_log
setblock 558 141 354 minecraft:stripped_dark_oak_log
setblock 558 141 361 minecraft:stripped_dark_oak_log
setblock 518 142 323 minecraft:stripped_dark_oak_log
setblock 518 142 330 minecraft:stripped_dark_oak_log
setblock 518 142 337 minecraft:stripped_dark_oak_log
setblock 518 142 344 minecraft:stripped_dark_oak_log
setblock 518 142 351 minecraft:stripped_dark_oak_log
setblock 518 142 358 minecraft:stripped_dark_oak_log
setblock 520 142 363 minecraft:stripped_dark_oak_log
setblock 525 142 323 minecraft:stripped_dark_oak_log
setblock 527 142 363 minecraft:stripped_dark_oak_log
setblock 532 142 323 minecraft:stripped_dark_oak_log
setblock 534 142 363 minecraft:stripped_dark_oak_log
setblock 539 142 323 minecraft:stripped_dark_oak_log
setblock 541 142 363 minecraft:stripped_dark_oak_log
setblock 546 142 323 minecraft:stripped_dark_oak_log
setblock 548 142 363 minecraft:stripped_dark_oak_log
setblock 553 142 323 minecraft:stripped_dark_oak_log
setblock 555 142 363 minecraft:stripped_dark_oak_log
setblock 558 142 325 minecraft:stripped_dark_oak_log
setblock 558 142 332 minecraft:stripped_dark_oak_log
setblock 558 142 339 minecraft:stripped_dark_oak_log
setblock 558 142 346 minecraft:stripped_dark_oak_log
setblock 558 142 353 minecraft:stripped_dark_oak_log
setblock 558 142 360 minecraft:stripped_dark_oak_log
setblock 518 143 324 minecraft:stripped_dark_oak_log
setblock 518 143 331 minecraft:stripped_dark_oak_log
setblock 518 143 338 minecraft:stripped_dark_oak_log
setblock 518 143 345 minecraft:stripped_dark_oak_log
setblock 518 143 352 minecraft:stripped_dark_oak_log
setblock 518 143 359 minecraft:stripped_dark_oak_log
setblock 521 143 363 minecraft:stripped_dark_oak_log
setblock 524 143 323 minecraft:stripped_dark_oak_log
setblock 528 143 363 minecraft:stripped_dark_oak_log
setblock 531 143 323 minecraft:stripped_dark_oak_log
setblock 535 143 363 minecraft:stripped_dark_oak_log
setblock 538 143 323 minecraft:stripped_dark_oak_log
setblock 542 143 363 minecraft:stripped_dark_oak_log
setblock 545 143 323 minecraft:stripped_dark_oak_log
setblock 549 143 363 minecraft:stripped_dark_oak_log
setblock 552 143 323 minecraft:stripped_dark_oak_log
setblock 556 143 363 minecraft:stripped_dark_oak_log
setblock 558 143 324 minecraft:stripped_dark_oak_log
setblock 558 143 331 minecraft:stripped_dark_oak_log
setblock 558 143 338 minecraft:stripped_dark_oak_log
setblock 558 143 345 minecraft:stripped_dark_oak_log
setblock 558 143 352 minecraft:stripped_dark_oak_log
setblock 558 143 359 minecraft:stripped_dark_oak_log
setblock 518 144 325 minecraft:stripped_dark_oak_log
setblock 518 144 332 minecraft:stripped_dark_oak_log
setblock 518 144 339 minecraft:stripped_dark_oak_log
setblock 518 144 346 minecraft:stripped_dark_oak_log
setblock 518 144 353 minecraft:stripped_dark_oak_log
setblock 518 144 360 minecraft:stripped_dark_oak_log
setblock 522 144 363 minecraft:stripped_dark_oak_log
setblock 523 144 323 minecraft:stripped_dark_oak_log
setblock 529 144 363 minecraft:stripped_dark_oak_log
setblock 530 144 323 minecraft:stripped_dark_oak_log
setblock 536 144 363 minecraft:stripped_dark_oak_log
setblock 537 144 323 minecraft:stripped_dark_oak_log
setblock 543 144 363 minecraft:stripped_dark_oak_log
setblock 544 144 323 minecraft:stripped_dark_oak_log
setblock 550 144 363 minecraft:stripped_dark_oak_log
setblock 551 144 323 minecraft:stripped_dark_oak_log
setblock 557 144 363 minecraft:stripped_dark_oak_log
setblock 558 144 323 minecraft:stripped_dark_oak_log
setblock 558 144 330 minecraft:stripped_dark_oak_log
setblock 558 144 337 minecraft:stripped_dark_oak_log
setblock 558 144 344 minecraft:stripped_dark_oak_log
setblock 558 144 351 minecraft:stripped_dark_oak_log
setblock 558 144 358 minecraft:stripped_dark_oak_log
setblock 518 145 326 minecraft:stripped_dark_oak_log
setblock 518 145 333 minecraft:stripped_dark_oak_log
setblock 518 145 340 minecraft:stripped_dark_oak_log
setblock 518 145 347 minecraft:stripped_dark_oak_log
setblock 518 145 354 minecraft:stripped_dark_oak_log
setblock 518 145 361 minecraft:stripped_dark_oak_log
setblock 522 145 323 minecraft:stripped_dark_oak_log
setblock 523 145 363 minecraft:stripped_dark_oak_log
fill 524 145 337 525 146 338 minecraft:cherry_leaves[persistent=true]
setblock 529 145 323 minecraft:stripped_dark_oak_log
setblock 530 145 363 minecraft:stripped_dark_oak_log
setblock 536 145 323 minecraft:stripped_dark_oak_log
setblock 537 145 363 minecraft:stripped_dark_oak_log
setblock 543 145 323 minecraft:stripped_dark_oak_log
setblock 544 145 363 minecraft:stripped_dark_oak_log
setblock 550 145 323 minecraft:stripped_dark_oak_log
setblock 551 145 363 minecraft:stripped_dark_oak_log
setblock 557 145 323 minecraft:stripped_dark_oak_log
setblock 558 145 329 minecraft:stripped_dark_oak_log
setblock 558 145 336 minecraft:stripped_dark_oak_log
setblock 558 145 343 minecraft:stripped_dark_oak_log
setblock 558 145 350 minecraft:stripped_dark_oak_log
setblock 558 145 357 minecraft:stripped_dark_oak_log
setblock 558 145 363 minecraft:stripped_dark_oak_log
setblock 518 146 327 minecraft:stripped_dark_oak_log
setblock 518 146 334 minecraft:stripped_dark_oak_log
setblock 518 146 341 minecraft:stripped_dark_oak_log
setblock 518 146 348 minecraft:stripped_dark_oak_log
setblock 518 146 355 minecraft:stripped_dark_oak_log
setblock 518 146 362 minecraft:stripped_dark_oak_log
setblock 521 146 323 minecraft:stripped_dark_oak_log
setblock 524 146 363 minecraft:stripped_dark_oak_log
setblock 528 146 323 minecraft:stripped_dark_oak_log
setblock 531 146 363 minecraft:stripped_dark_oak_log
setblock 535 146 323 minecraft:stripped_dark_oak_log
setblock 538 146 363 minecraft:stripped_dark_oak_log
setblock 542 146 323 minecraft:stripped_dark_oak_log
setblock 545 146 363 minecraft:stripped_dark_oak_log
setblock 549 146 323 minecraft:stripped_dark_oak_log
setblock 552 146 363 minecraft:stripped_dark_oak_log
setblock 556 146 323 minecraft:stripped_dark_oak_log
setblock 558 146 328 minecraft:stripped_dark_oak_log
setblock 558 146 335 minecraft:stripped_dark_oak_log
setblock 558 146 342 minecraft:stripped_dark_oak_log
setblock 558 146 349 minecraft:stripped_dark_oak_log
setblock 558 146 356 minecraft:stripped_dark_oak_log
setblock 518 148 329 minecraft:stripped_dark_oak_log
setblock 518 148 336 minecraft:stripped_dark_oak_log
setblock 518 148 343 minecraft:stripped_dark_oak_log
setblock 518 148 350 minecraft:stripped_dark_oak_log
setblock 518 148 357 minecraft:stripped_dark_oak_log
setblock 519 148 323 minecraft:stripped_dark_oak_log
setblock 519 148 363 minecraft:stripped_dark_oak_log
setblock 520 148 325 minecraft:light[level=14]
setblock 520 148 333 minecraft:light[level=14]
setblock 520 148 341 minecraft:light[level=14]
setblock 520 148 349 minecraft:light[level=14]
setblock 520 148 357 minecraft:light[level=14]
setblock 526 148 323 minecraft:stripped_dark_oak_log
setblock 526 148 363 minecraft:stripped_dark_oak_log
setblock 528 148 325 minecraft:light[level=14]
setblock 528 148 333 minecraft:light[level=14]
setblock 528 148 341 minecraft:light[level=14]
setblock 528 148 349 minecraft:light[level=14]
setblock 528 148 357 minecraft:light[level=14]
setblock 533 148 323 minecraft:stripped_dark_oak_log
setblock 533 148 363 minecraft:stripped_dark_oak_log
setblock 536 148 325 minecraft:light[level=14]
setblock 536 148 333 minecraft:light[level=14]
setblock 536 148 349 minecraft:light[level=14]
setblock 536 148 357 minecraft:light[level=14]
setblock 540 148 323 minecraft:stripped_dark_oak_log
setblock 540 148 363 minecraft:stripped_dark_oak_log
setblock 544 148 325 minecraft:light[level=14]
setblock 544 148 333 minecraft:light[level=14]
setblock 544 148 341 minecraft:light[level=14]
setblock 544 148 349 minecraft:light[level=14]
setblock 544 148 357 minecraft:light[level=14]
setblock 547 148 323 minecraft:stripped_dark_oak_log
setblock 547 148 363 minecraft:stripped_dark_oak_log
setblock 552 148 325 minecraft:light[level=14]
setblock 552 148 333 minecraft:light[level=14]
setblock 552 148 341 minecraft:light[level=14]
setblock 552 148 349 minecraft:light[level=14]
setblock 552 148 357 minecraft:light[level=14]
setblock 554 148 323 minecraft:stripped_dark_oak_log
setblock 554 148 363 minecraft:stripped_dark_oak_log
setblock 558 148 326 minecraft:stripped_dark_oak_log
setblock 558 148 333 minecraft:stripped_dark_oak_log
setblock 558 148 340 minecraft:stripped_dark_oak_log
setblock 558 148 347 minecraft:stripped_dark_oak_log
setblock 558 148 354 minecraft:stripped_dark_oak_log
setblock 558 148 361 minecraft:stripped_dark_oak_log
fill 518 149 323 518 150 323 minecraft:stripped_dark_oak_log
fill 518 149 330 518 150 330 minecraft:stripped_dark_oak_log
fill 518 149 337 518 150 337 minecraft:stripped_dark_oak_log
fill 518 149 344 518 150 344 minecraft:stripped_dark_oak_log
fill 518 149 351 518 150 351 minecraft:stripped_dark_oak_log
fill 518 149 358 518 150 358 minecraft:stripped_dark_oak_log
fill 520 149 363 520 150 363 minecraft:stripped_dark_oak_log
fill 525 149 323 525 150 323 minecraft:stripped_dark_oak_log
fill 527 149 363 527 150 363 minecraft:stripped_dark_oak_log
fill 532 149 323 532 150 323 minecraft:stripped_dark_oak_log
fill 534 149 363 534 150 363 minecraft:stripped_dark_oak_log
fill 539 149 323 539 150 323 minecraft:stripped_dark_oak_log
fill 541 149 363 541 150 363 minecraft:stripped_dark_oak_log
fill 546 149 323 546 150 323 minecraft:stripped_dark_oak_log
fill 548 149 363 548 150 363 minecraft:stripped_dark_oak_log
fill 553 149 323 553 150 323 minecraft:stripped_dark_oak_log
fill 555 149 363 555 150 363 minecraft:stripped_dark_oak_log
fill 558 149 325 558 150 325 minecraft:stripped_dark_oak_log
fill 558 149 332 558 150 332 minecraft:stripped_dark_oak_log
fill 558 149 339 558 150 339 minecraft:stripped_dark_oak_log
fill 558 149 346 558 150 346 minecraft:stripped_dark_oak_log
fill 558 149 353 558 150 353 minecraft:stripped_dark_oak_log
fill 558 149 360 558 150 360 minecraft:stripped_dark_oak_log
fill 518 150 324 518 150 327 minecraft:stripped_dark_oak_log
setblock 518 150 329 minecraft:stripped_dark_oak_log
fill 518 150 331 518 150 334 minecraft:stripped_dark_oak_log
setblock 518 150 336 minecraft:stripped_dark_oak_log
fill 518 150 338 518 150 341 minecraft:stripped_dark_oak_log
setblock 518 150 343 minecraft:stripped_dark_oak_log
fill 518 150 345 518 150 348 minecraft:stripped_dark_oak_log
setblock 518 150 350 minecraft:stripped_dark_oak_log
fill 518 150 352 518 150 355 minecraft:stripped_dark_oak_log
setblock 518 150 357 minecraft:stripped_dark_oak_log
fill 518 150 359 518 150 362 minecraft:stripped_dark_oak_log
setblock 519 150 323 minecraft:stripped_dark_oak_log
setblock 519 150 363 minecraft:stripped_dark_oak_log
fill 521 150 323 524 150 323 minecraft:stripped_dark_oak_log
fill 521 150 363 524 150 363 minecraft:stripped_dark_oak_log
setblock 526 150 323 minecraft:stripped_dark_oak_log
setblock 526 150 363 minecraft:stripped_dark_oak_log
fill 528 150 323 531 150 323 minecraft:stripped_dark_oak_log
fill 528 150 363 531 150 363 minecraft:stripped_dark_oak_log
setblock 533 150 323 minecraft:stripped_dark_oak_log
setblock 533 150 363 minecraft:stripped_dark_oak_log
fill 535 150 323 538 150 323 minecraft:stripped_dark_oak_log
fill 535 150 363 538 150 363 minecraft:stripped_dark_oak_log
setblock 540 150 323 minecraft:stripped_dark_oak_log
setblock 540 150 363 minecraft:stripped_dark_oak_log
fill 542 150 323 545 150 323 minecraft:stripped_dark_oak_log
fill 542 150 363 545 150 363 minecraft:stripped_dark_oak_log
setblock 547 150 323 minecraft:stripped_dark_oak_log
setblock 547 150 363 minecraft:stripped_dark_oak_log
fill 549 150 323 552 150 323 minecraft:stripped_dark_oak_log
fill 549 150 363 552 150 363 minecraft:stripped_dark_oak_log
setblock 554 150 323 minecraft:stripped_dark_oak_log
setblock 554 150 363 minecraft:stripped_dark_oak_log
fill 556 150 323 558 150 323 minecraft:stripped_dark_oak_log
fill 556 150 363 558 150 363 minecraft:stripped_dark_oak_log
setblock 558 150 324 minecraft:stripped_dark_oak_log
setblock 558 150 326 minecraft:stripped_dark_oak_log
fill 558 150 328 558 150 331 minecraft:stripped_dark_oak_log
setblock 558 150 333 minecraft:stripped_dark_oak_log
fill 558 150 335 558 150 338 minecraft:stripped_dark_oak_log
setblock 558 150 340 minecraft:stripped_dark_oak_log
fill 558 150 342 558 150 345 minecraft:stripped_dark_oak_log
setblock 558 150 347 minecraft:stripped_dark_oak_log
fill 558 150 349 558 150 352 minecraft:stripped_dark_oak_log
setblock 558 150 354 minecraft:stripped_dark_oak_log
fill 558 150 356 558 150 359 minecraft:stripped_dark_oak_log
setblock 558 150 361 minecraft:stripped_dark_oak_log
setblock 520 156 325 minecraft:light[level=14]
setblock 520 156 333 minecraft:light[level=14]
setblock 520 156 341 minecraft:light[level=14]
setblock 520 156 349 minecraft:light[level=14]
setblock 520 156 357 minecraft:light[level=14]
fill 524 156 340 534 156 340 minecraft:moss_block
fill 525 156 335 534 156 339 minecraft:moss_block
fill 525 156 341 534 156 345 minecraft:moss_block
fill 526 156 334 548 156 334 minecraft:moss_block
fill 526 156 346 548 156 346 minecraft:moss_block
fill 527 156 332 547 156 333 minecraft:moss_block
fill 527 156 347 547 156 348 minecraft:moss_block
setblock 528 156 325 minecraft:light[level=14]
fill 528 156 331 546 156 331 minecraft:moss_block
fill 528 156 349 546 156 349 minecraft:moss_block
setblock 528 156 357 minecraft:light[level=14]
fill 529 156 330 545 156 330 minecraft:moss_block
fill 529 156 350 545 156 350 minecraft:moss_block
fill 531 156 329 543 156 329 minecraft:moss_block
fill 531 156 351 543 156 351 minecraft:moss_block
fill 532 156 328 542 156 328 minecraft:moss_block
fill 532 156 352 542 156 352 minecraft:moss_block
fill 535 156 335 535 156 338 minecraft:moss_block
fill 535 156 342 535 156 345 minecraft:moss_block
setblock 536 156 325 minecraft:light[level=14]
fill 536 156 335 549 156 337 minecraft:moss_block
fill 536 156 343 549 156 345 minecraft:moss_block
setblock 536 156 357 minecraft:light[level=14]
setblock 537 156 327 minecraft:moss_block
setblock 537 156 353 minecraft:moss_block
fill 539 156 338 549 156 338 minecraft:moss_block
fill 539 156 342 549 156 342 minecraft:moss_block
fill 540 156 339 549 156 341 minecraft:moss_block
setblock 544 156 325 minecraft:light[level=14]
setblock 544 156 357 minecraft:light[level=14]
setblock 550 156 340 minecraft:moss_block
setblock 552 156 325 minecraft:light[level=14]
setblock 552 156 333 minecraft:light[level=14]
setblock 552 156 341 minecraft:light[level=14]
setblock 552 156 349 minecraft:light[level=14]
setblock 552 156 357 minecraft:light[level=14]
fill 518 157 323 558 157 324 minecraft:moss_block
setblock 518 157 325 minecraft:pink_concrete
fill 518 157 326 518 157 330 minecraft:moss_block
setblock 518 157 331 minecraft:pink_concrete
fill 518 157 332 518 157 336 minecraft:moss_block
setblock 518 157 337 minecraft:pink_concrete
fill 518 157 338 518 157 342 minecraft:moss_block
setblock 518 157 343 minecraft:pink_concrete
fill 518 157 344 518 157 348 minecraft:moss_block
setblock 518 157 349 minecraft:pink_concrete
fill 518 157 350 518 157 354 minecraft:moss_block
setblock 518 157 355 minecraft:pink_concrete
fill 518 157 356 518 157 360 minecraft:moss_block
setblock 518 157 361 minecraft:pink_concrete
fill 518 157 362 558 157 363 minecraft:moss_block
fill 519 157 325 519 157 327 minecraft:moss_block
setblock 519 157 328 minecraft:pink_concrete
fill 519 157 329 519 157 333 minecraft:moss_block
setblock 519 157 334 minecraft:pink_concrete
fill 519 157 335 519 157 339 minecraft:moss_block
setblock 519 157 340 minecraft:pink_concrete
fill 519 157 341 519 157 345 minecraft:moss_block
setblock 519 157 346 minecraft:pink_concrete
fill 519 157 347 519 157 351 minecraft:moss_block
setblock 519 157 352 minecraft:pink_concrete
fill 519 157 353 519 157 357 minecraft:moss_block
setblock 519 157 358 minecraft:pink_concrete
fill 519 157 359 519 157 361 minecraft:moss_block
setblock 520 157 325 minecraft:pink_concrete
fill 520 157 326 520 157 330 minecraft:moss_block
setblock 520 157 331 minecraft:pink_concrete
fill 520 157 332 520 157 336 minecraft:moss_block
setblock 520 157 337 minecraft:pink_concrete
fill 520 157 338 520 157 342 minecraft:moss_block
setblock 520 157 343 minecraft:pink_concrete
fill 520 157 344 520 157 348 minecraft:moss_block
setblock 520 157 349 minecraft:pink_concrete
fill 520 157 350 520 157 354 minecraft:moss_block
setblock 520 157 355 minecraft:pink_concrete
fill 520 157 356 520 157 360 minecraft:moss_block
setblock 520 157 361 minecraft:pink_concrete
fill 521 157 325 521 157 327 minecraft:moss_block
setblock 521 157 328 minecraft:pink_concrete
fill 521 157 329 521 157 333 minecraft:moss_block
setblock 521 157 334 minecraft:pink_concrete
fill 521 157 335 521 157 339 minecraft:moss_block
setblock 521 157 340 minecraft:pink_concrete
fill 521 157 341 521 157 345 minecraft:moss_block
setblock 521 157 346 minecraft:pink_concrete
fill 521 157 347 521 157 351 minecraft:moss_block
setblock 521 157 352 minecraft:pink_concrete
fill 521 157 353 521 157 357 minecraft:moss_block
setblock 521 157 358 minecraft:pink_concrete
fill 521 157 359 521 157 361 minecraft:moss_block
setblock 522 157 325 minecraft:pink_concrete
fill 522 157 326 522 157 330 minecraft:moss_block
setblock 522 157 331 minecraft:pink_concrete
fill 522 157 332 522 157 336 minecraft:moss_block
setblock 522 157 337 minecraft:pink_concrete
fill 522 157 338 522 157 342 minecraft:moss_block
setblock 522 157 343 minecraft:pink_concrete
fill 522 157 344 522 157 348 minecraft:moss_block
setblock 522 157 349 minecraft:pink_concrete
fill 522 157 350 522 157 354 minecraft:moss_block
setblock 522 157 355 minecraft:pink_concrete
fill 522 157 356 522 157 360 minecraft:moss_block
setblock 522 157 361 minecraft:pink_concrete
fill 523 157 325 523 157 327 minecraft:moss_block
setblock 523 157 328 minecraft:pink_concrete
fill 523 157 329 523 157 333 minecraft:moss_block
setblock 523 157 334 minecraft:pink_concrete
fill 523 157 335 523 157 339 minecraft:moss_block
setblock 523 157 340 minecraft:pink_concrete
fill 523 157 341 523 157 345 minecraft:moss_block
setblock 523 157 346 minecraft:pink_concrete
fill 523 157 347 523 157 351 minecraft:moss_block
setblock 523 157 352 minecraft:pink_concrete
fill 523 157 353 523 157 357 minecraft:moss_block
setblock 523 157 358 minecraft:pink_concrete
fill 523 157 359 523 157 361 minecraft:moss_block
setblock 524 157 325 minecraft:pink_concrete
fill 524 157 326 524 157 330 minecraft:moss_block
setblock 524 157 331 minecraft:pink_concrete
fill 524 157 332 524 157 336 minecraft:moss_block
setblock 524 157 337 minecraft:pink_concrete
fill 524 157 338 524 157 339 minecraft:moss_block
fill 524 157 340 525 157 340 minecraft:stone
fill 524 157 341 524 157 342 minecraft:moss_block
setblock 524 157 343 minecraft:pink_concrete
fill 524 157 344 524 157 348 minecraft:moss_block
setblock 524 157 349 minecraft:pink_concrete
fill 524 157 350 524 157 354 minecraft:moss_block
setblock 524 157 355 minecraft:pink_concrete
fill 524 157 356 524 157 360 minecraft:moss_block
setblock 524 157 361 minecraft:pink_concrete
fill 525 157 325 525 157 327 minecraft:moss_block
setblock 525 157 328 minecraft:pink_concrete
fill 525 157 329 525 157 333 minecraft:moss_block
setblock 525 157 334 minecraft:pink_concrete
fill 525 157 335 525 157 339 minecraft:stone
fill 525 157 341 525 157 345 minecraft:stone
setblock 525 157 346 minecraft:pink_concrete
fill 525 157 347 525 157 351 minecraft:moss_block
setblock 525 157 352 minecraft:pink_concrete
fill 525 157 353 525 157 357 minecraft:moss_block
setblock 525 157 358 minecraft:pink_concrete
fill 525 157 359 525 157 361 minecraft:moss_block
setblock 526 157 325 minecraft:pink_concrete
fill 526 157 326 526 157 330 minecraft:moss_block
setblock 526 157 331 minecraft:pink_concrete
fill 526 157 332 526 157 333 minecraft:moss_block
fill 526 157 334 526 157 335 minecraft:stone
fill 526 157 336 528 157 344 minecraft:light_blue_concrete
fill 526 157 345 526 157 346 minecraft:stone
fill 526 157 347 526 157 348 minecraft:moss_block
setblock 526 157 349 minecraft:pink_concrete
fill 526 157 350 526 157 354 minecraft:moss_block
setblock 526 157 355 minecraft:pink_concrete
fill 526 157 356 526 157 360 minecraft:moss_block
setblock 526 157 361 minecraft:pink_concrete
fill 527 157 325 527 157 327 minecraft:moss_block
setblock 527 157 328 minecraft:pink_concrete
fill 527 157 329 527 157 331 minecraft:moss_block
fill 527 157 332 527 157 333 minecraft:stone
fill 527 157 334 530 157 335 minecraft:light_blue_concrete
fill 527 157 345 530 157 346 minecraft:light_blue_concrete
fill 527 157 347 527 157 348 minecraft:stone
fill 527 157 349 527 157 351 minecraft:moss_block
setblock 527 157 352 minecraft:pink_concrete
fill 527 157 353 527 157 357 minecraft:moss_block
setblock 527 157 358 minecraft:pink_concrete
fill 527 157 359 527 157 361 minecraft:moss_block
setblock 528 157 325 minecraft:pink_concrete
fill 528 157 326 528 157 330 minecraft:moss_block
fill 528 157 331 528 157 332 minecraft:stone
fill 528 157 333 532 157 333 minecraft:light_blue_concrete
fill 528 157 347 532 157 347 minecraft:light_blue_concrete
fill 528 157 348 528 157 349 minecraft:stone
fill 528 157 350 528 157 354 minecraft:moss_block
setblock 528 157 355 minecraft:pink_concrete
fill 528 157 356 528 157 360 minecraft:moss_block
setblock 528 157 361 minecraft:pink_concrete
fill 529 157 325 529 157 327 minecraft:moss_block
setblock 529 157 328 minecraft:pink_concrete
fill 529 157 329 530 157 329 minecraft:moss_block
fill 529 157 330 529 157 331 minecraft:stone
fill 529 157 332 534 157 332 minecraft:light_blue_concrete
fill 529 157 336 529 157 337 minecraft:light_blue_concrete
fill 529 157 338 529 157 342 minecraft:orange_concrete
fill 529 157 343 529 157 344 minecraft:light_blue_concrete
fill 529 157 348 534 157 348 minecraft:light_blue_concrete
fill 529 157 349 529 157 350 minecraft:stone
fill 529 157 351 530 157 351 minecraft:moss_block
setblock 529 157 352 minecraft:pink_concrete
fill 529 157 353 529 157 357 minecraft:moss_block
setblock 529 157 358 minecraft:pink_concrete
fill 529 157 359 529 157 361 minecraft:moss_block
setblock 530 157 325 minecraft:pink_concrete
fill 530 157 326 530 157 328 minecraft:moss_block
setblock 530 157 330 minecraft:stone
fill 530 157 331 544 157 331 minecraft:light_blue_concrete
fill 530 157 336 530 157 337 minecraft:orange_concrete
fill 530 157 338 533 157 342 minecraft:light_blue_concrete
fill 530 157 343 530 157 344 minecraft:orange_concrete
fill 530 157 349 544 157 349 minecraft:light_blue_concrete
setblock 530 157 350 minecraft:stone
fill 530 157 352 530 157 354 minecraft:moss_block
setblock 530 157 355 minecraft:pink_concrete
fill 530 157 356 530 157 360 minecraft:moss_block
setblock 530 157 361 minecraft:pink_concrete
fill 531 157 325 531 157 327 minecraft:moss_block
setblock 531 157 328 minecraft:pink_concrete
fill 531 157 329 532 157 329 minecraft:stone
fill 531 157 330 543 157 330 minecraft:light_blue_concrete
setblock 531 157 334 minecraft:light_blue_concrete
setblock 531 157 335 minecraft:orange_concrete
fill 531 157 336 534 157 337 minecraft:light_blue_concrete
fill 531 157 343 534 157 344 minecraft:light_blue_concrete
setblock 531 157 345 minecraft:orange_concrete
setblock 531 157 346 minecraft:light_blue_concrete
fill 531 157 350 543 157 350 minecraft:light_blue_concrete
fill 531 157 351 532 157 351 minecraft:stone
setblock 531 157 352 minecraft:pink_concrete
fill 531 157 353 531 157 357 minecraft:moss_block
setblock 531 157 358 minecraft:pink_concrete
fill 531 157 359 531 157 361 minecraft:moss_block
setblock 532 157 325 minecraft:pink_concrete
fill 532 157 326 536 157 327 minecraft:moss_block
fill 532 157 328 542 157 328 minecraft:stone
setblock 532 157 334 minecraft:orange_concrete
fill 532 157 335 542 157 335 minecraft:light_blue_concrete
fill 532 157 345 542 157 345 minecraft:light_blue_concrete
setblock 532 157 346 minecraft:orange_concrete
fill 532 157 352 542 157 352 minecraft:stone
fill 532 157 353 536 157 354 minecraft:moss_block
setblock 532 157 355 minecraft:pink_concrete
fill 532 157 356 532 157 360 minecraft:moss_block
setblock 532 157 361 minecraft:pink_concrete
setblock 533 157 325 minecraft:moss_block
fill 533 157 329 541 157 329 minecraft:light_blue_concrete
fill 533 157 333 534 157 333 minecraft:orange_concrete
fill 533 157 334 541 157 334 minecraft:light_blue_concrete
fill 533 157 346 541 157 346 minecraft:light_blue_concrete
fill 533 157 347 534 157 347 minecraft:orange_concrete
fill 533 157 351 541 157 351 minecraft:light_blue_concrete
fill 533 157 355 533 157 357 minecraft:moss_block
setblock 533 157 358 minecraft:pink_concrete
fill 533 157 359 533 157 361 minecraft:moss_block
setblock 534 157 325 minecraft:pink_concrete
setblock 534 157 338 minecraft:shroomlight
fill 534 157 339 534 157 341 minecraft:ochre_froglight
setblock 534 157 342 minecraft:shroomlight
setblock 534 157 355 minecraft:pink_concrete
fill 534 157 356 534 157 360 minecraft:moss_block
setblock 534 157 361 minecraft:pink_concrete
setblock 535 157 325 minecraft:moss_block
fill 535 157 332 539 157 332 minecraft:orange_concrete
fill 535 157 333 539 157 333 minecraft:light_blue_concrete
fill 535 157 336 543 157 336 minecraft:light_blue_concrete
setblock 535 157 337 minecraft:shroomlight
setblock 535 157 338 minecraft:ochre_froglight
setblock 535 157 342 minecraft:ochre_froglight
setblock 535 157 343 minecraft:shroomlight
fill 535 157 344 543 157 344 minecraft:light_blue_concrete
fill 535 157 347 539 157 347 minecraft:light_blue_concrete
fill 535 157 348 539 157 348 minecraft:orange_concrete
fill 535 157 355 535 157 357 minecraft:moss_block
setblock 535 157 358 minecraft:pink_concrete
fill 535 157 359 535 157 361 minecraft:moss_block
setblock 536 157 325 minecraft:pink_concrete
fill 536 157 337 538 157 337 minecraft:ochre_froglight
fill 536 157 343 538 157 343 minecraft:ochre_froglight
setblock 536 157 355 minecraft:pink_concrete
fill 536 157 356 536 157 360 minecraft:moss_block
setblock 536 157 361 minecraft:pink_concrete
fill 537 157 325 537 157 326 minecraft:moss_block
setblock 537 157 327 minecraft:stone
setblock 537 157 353 minecraft:stone
fill 537 157 354 537 157 357 minecraft:moss_block
setblock 537 157 358 minecraft:pink_concrete
fill 537 157 359 537 157 361 minecraft:moss_block
setblock 538 157 325 minecraft:pink_concrete
fill 538 157 326 558 157 327 minecraft:moss_block
fill 538 157 353 558 157 354 minecraft:moss_block
setblock 538 157 355 minecraft:pink_concrete
fill 538 157 356 538 157 360 minecraft:moss_block
setblock 538 157 361 minecraft:pink_concrete
setblock 539 157 325 minecraft:moss_block
setblock 539 157 337 minecraft:shroomlight
setblock 539 157 338 minecraft:ochre_froglight
setblock 539 157 342 minecraft:ochre_froglight
setblock 539 157 343 minecraft:shroomlight
fill 539 157 355 539 157 357 minecraft:moss_block
setblock 539 157 358 minecraft:pink_concrete
fill 539 157 359 539 157 361 minecraft:moss_block
setblock 540 157 325 minecraft:pink_concrete
fill 540 157 332 545 157 332 minecraft:light_blue_concrete
fill 540 157 333 541 157 333 minecraft:orange_concrete
fill 540 157 337 543 157 337 minecraft:light_blue_concrete
setblock 540 157 338 minecraft:shroomlight
fill 540 157 339 540 157 341 minecraft:ochre_froglight
setblock 540 157 342 minecraft:shroomlight
fill 540 157 343 543 157 343 minecraft:light_blue_concrete
fill 540 157 347 541 157 347 minecraft:orange_concrete
fill 540 157 348 545 157 348 minecraft:light_blue_concrete
setblock 540 157 355 minecraft:pink_concrete
fill 540 157 356 540 157 360 minecraft:moss_block
setblock 540 157 361 minecraft:pink_concrete
setblock 541 157 325 minecraft:moss_block
fill 541 157 338 544 157 342 minecraft:light_blue_concrete
fill 541 157 355 541 157 357 minecraft:moss_block
setblock 541 157 358 minecraft:pink_concrete
fill 541 157 359 541 157 361 minecraft:moss_block
setblock 542 157 325 minecraft:pink_concrete
fill 542 157 329 543 157 329 minecraft:stone
fill 542 157 333 546 157 333 minecraft:light_blue_concrete
setblock 542 157 334 minecraft:orange_concrete
setblock 542 157 346 minecraft:orange_concrete
fill 542 157 347 546 157 347 minecraft:light_blue_concrete
fill 542 157 351 543 157 351 minecraft:stone
setblock 542 157 355 minecraft:pink_concrete
fill 542 157 356 542 157 360 minecraft:moss_block
setblock 542 157 361 minecraft:pink_concrete
setblock 543 157 325 minecraft:moss_block
setblock 543 157 328 minecraft:pink_concrete
fill 543 157 334 547 157 334 minecraft:light_blue_concrete
setblock 543 157 335 minecraft:orange_concrete
setblock 543 157 345 minecraft:orange_concrete
fill 543 157 346 547 157 346 minecraft:light_blue_concrete
setblock 543 157 352 minecraft:pink_concrete
fill 543 157 355 543 157 357 minecraft:moss_block
setblock 543 157 358 minecraft:pink_concrete
fill 543 157 359 543 157 361 minecraft:moss_block
setblock 544 157 325 minecraft:pink_concrete
fill 544 157 328 544 157 329 minecraft:moss_block
fill 544 157 330 545 157 330 minecraft:stone
fill 544 157 335 547 157 335 minecraft:light_blue_concrete
fill 544 157 336 544 157 337 minecraft:orange_concrete
fill 544 157 343 544 157 344 minecraft:orange_concrete
fill 544 157 345 547 157 345 minecraft:light_blue_concrete
fill 544 157 350 545 157 350 minecraft:stone
fill 544 157 351 544 157 352 minecraft:moss_block
setblock 544 157 355 minecraft:pink_concrete
fill 544 157 356 544 157 360 minecraft:moss_block
setblock 544 157 361 minecraft:pink_concrete
setblock 545 157 325 minecraft:moss_block
setblock 545 157 328 minecraft:pink_concrete
fill 545 157 329 558 157 329 minecraft:moss_block
fill 545 157 331 546 157 331 minecraft:stone
fill 545 157 336 548 157 337 minecraft:light_blue_concrete
fill 545 157 338 545 157 342 minecraft:orange_concrete
fill 545 157 343 548 157 344 minecraft:light_blue_concrete
fill 545 157 349 546 157 349 minecraft:stone
fill 545 157 351 558 157 351 minecraft:moss_block
setblock 545 157 352 minecraft:pink_concrete
fill 545 157 355 545 157 357 minecraft:moss_block
setblock 545 157 358 minecraft:pink_concrete
fill 545 157 359 545 157 361 minecraft:moss_block
setblock 546 157 325 minecraft:pink_concrete
setblock 546 157 328 minecraft:moss_block
fill 546 157 330 558 157 330 minecraft:moss_block
fill 546 157 332 547 157 332 minecraft:stone
fill 546 157 338 548 157 342 minecraft:light_blue_concrete
fill 546 157 348 547 157 348 minecraft:stone
fill 546 157 350 558 157 350 minecraft:moss_block
setblock 546 157 352 minecraft:moss_block
setblock 546 157 355 minecraft:pink_concrete
fill 546 157 356 546 157 360 minecraft:moss_block
setblock 546 157 361 minecraft:pink_concrete
setblock 547 157 325 minecraft:moss_block
setblock 547 157 328 minecraft:pink_concrete
setblock 547 157 331 minecraft:moss_block
setblock 547 157 333 minecraft:stone
setblock 547 157 347 minecraft:stone
setblock 547 157 349 minecraft:moss_block
setblock 547 157 352 minecraft:pink_concrete
fill 547 157 355 547 157 357 minecraft:moss_block
setblock 547 157 358 minecraft:pink_concrete
fill 547 157 359 547 157 361 minecraft:moss_block
setblock 548 157 325 minecraft:pink_concrete
setblock 548 157 328 minecraft:moss_block
setblock 548 157 331 minecraft:pink_concrete
fill 548 157 332 558 157 333 minecraft:moss_block
fill 548 157 334 548 157 335 minecraft:stone
fill 548 157 345 548 157 346 minecraft:stone
fill 548 157 347 558 157 348 minecraft:moss_block
setblock 548 157 349 minecraft:pink_concrete
setblock 548 157 352 minecraft:moss_block
setblock 548 157 355 minecraft:pink_concrete
fill 548 157 356 548 157 360 minecraft:moss_block
setblock 548 157 361 minecraft:pink_concrete
setblock 549 157 325 minecraft:moss_block
setblock 549 157 328 minecraft:pink_concrete
setblock 549 157 331 minecraft:moss_block
setblock 549 157 334 minecraft:pink_concrete
fill 549 157 335 549 157 345 minecraft:stone
setblock 549 157 346 minecraft:pink_concrete
setblock 549 157 349 minecraft:moss_block
setblock 549 157 352 minecraft:pink_concrete
fill 549 157 355 549 157 357 minecraft:moss_block
setblock 549 157 358 minecraft:pink_concrete
fill 549 157 359 549 157 361 minecraft:moss_block
setblock 550 157 325 minecraft:pink_concrete
setblock 550 157 328 minecraft:moss_block
setblock 550 157 331 minecraft:pink_concrete
fill 550 157 334 550 157 336 minecraft:moss_block
setblock 550 157 337 minecraft:pink_concrete
fill 550 157 338 558 157 339 minecraft:moss_block
setblock 550 157 340 minecraft:stone
fill 550 157 341 558 157 342 minecraft:moss_block
setblock 550 157 343 minecraft:pink_concrete
fill 550 157 344 550 157 346 minecraft:moss_block
setblock 550 157 349 minecraft:pink_concrete
setblock 550 157 352 minecraft:moss_block
setblock 550 157 355 minecraft:pink_concrete
fill 550 157 356 550 157 360 minecraft:moss_block
setblock 550 157 361 minecraft:pink_concrete
setblock 551 157 325 minecraft:moss_block
setblock 551 157 328 minecraft:pink_concrete
setblock 551 157 331 minecraft:moss_block
setblock 551 157 334 minecraft:pink_concrete
fill 551 157 335 551 157 337 minecraft:moss_block
setblock 551 157 340 minecraft:pink_concrete
fill 551 157 343 551 157 345 minecraft:moss_block
setblock 551 157 346 minecraft:pink_concrete
setblock 551 157 349 minecraft:moss_block
setblock 551 157 352 minecraft:pink_concrete
fill 551 157 355 551 157 357 minecraft:moss_block
setblock 551 157 358 minecraft:pink_concrete
fill 551 157 359 551 157 361 minecraft:moss_block
setblock 552 157 325 minecraft:pink_concrete
setblock 552 157 328 minecraft:moss_block
setblock 552 157 331 minecraft:pink_concrete
fill 552 157 334 552 157 336 minecraft:moss_block
setblock 552 157 337 minecraft:pink_concrete
setblock 552 157 340 minecraft:moss_block
setblock 552 157 343 minecraft:pink_concrete
fill 552 157 344 552 157 346 minecraft:moss_block
setblock 552 157 349 minecraft:pink_concrete
setblock 552 157 352 minecraft:moss_block
setblock 552 157 355 minecraft:pink_concrete
fill 552 157 356 552 157 360 minecraft:moss_block
setblock 552 157 361 minecraft:pink_concrete
setblock 553 157 325 minecraft:moss_block
setblock 553 157 328 minecraft:pink_concrete
setblock 553 157 331 minecraft:moss_block
setblock 553 157 334 minecraft:pink_concrete
fill 553 157 335 553 157 337 minecraft:moss_block
setblock 553 157 340 minecraft:pink_concrete
fill 553 157 343 553 157 345 minecraft:moss_block
setblock 553 157 346 minecraft:pink_concrete
setblock 553 157 349 minecraft:moss_block
setblock 553 157 352 minecraft:pink_concrete
fill 553 157 355 553 157 357 minecraft:moss_block
setblock 553 157 358 minecraft:pink_concrete
fill 553 157 359 553 157 361 minecraft:moss_block
setblock 554 157 325 minecraft:pink_concrete
setblock 554 157 328 minecraft:moss_block
setblock 554 157 331 minecraft:pink_concrete
fill 554 157 334 554 157 336 minecraft:moss_block
setblock 554 157 337 minecraft:pink_concrete
setblock 554 157 340 minecraft:moss_block
setblock 554 157 343 minecraft:pink_concrete
fill 554 157 344 554 157 346 minecraft:moss_block
setblock 554 157 349 minecraft:pink_concrete
setblock 554 157 352 minecraft:moss_block
setblock 554 157 355 minecraft:pink_concrete
fill 554 157 356 554 157 360 minecraft:moss_block
setblock 554 157 361 minecraft:pink_concrete
setblock 555 157 325 minecraft:moss_block
setblock 555 157 328 minecraft:pink_concrete
setblock 555 157 331 minecraft:moss_block
setblock 555 157 334 minecraft:pink_concrete
fill 555 157 335 555 157 337 minecraft:moss_block
setblock 555 157 340 minecraft:pink_concrete
fill 555 157 343 555 157 345 minecraft:moss_block
setblock 555 157 346 minecraft:pink_concrete
setblock 555 157 349 minecraft:moss_block
setblock 555 157 352 minecraft:pink_concrete
fill 555 157 355 555 157 357 minecraft:moss_block
setblock 555 157 358 minecraft:pink_concrete
fill 555 157 359 555 157 361 minecraft:moss_block
setblock 556 157 325 minecraft:pink_concrete
setblock 556 157 328 minecraft:moss_block
setblock 556 157 331 minecraft:pink_concrete
fill 556 157 334 556 157 336 minecraft:moss_block
setblock 556 157 337 minecraft:pink_concrete
setblock 556 157 340 minecraft:moss_block
setblock 556 157 343 minecraft:pink_concrete
fill 556 157 344 556 157 346 minecraft:moss_block
setblock 556 157 349 minecraft:pink_concrete
setblock 556 157 352 minecraft:moss_block
setblock 556 157 355 minecraft:pink_concrete
fill 556 157 356 556 157 360 minecraft:moss_block
setblock 556 157 361 minecraft:pink_concrete
setblock 557 157 325 minecraft:moss_block
setblock 557 157 328 minecraft:pink_concrete
setblock 557 157 331 minecraft:moss_block
setblock 557 157 334 minecraft:pink_concrete
fill 557 157 335 557 157 337 minecraft:moss_block
setblock 557 157 340 minecraft:pink_concrete
fill 557 157 343 557 157 345 minecraft:moss_block
setblock 557 157 346 minecraft:pink_concrete
setblock 557 157 349 minecraft:moss_block
setblock 557 157 352 minecraft:pink_concrete
fill 557 157 355 557 157 357 minecraft:moss_block
setblock 557 157 358 minecraft:pink_concrete
fill 557 157 359 557 157 361 minecraft:moss_block
setblock 558 157 325 minecraft:pink_concrete
setblock 558 157 328 minecraft:moss_block
setblock 558 157 331 minecraft:pink_concrete
fill 558 157 334 558 157 336 minecraft:moss_block
setblock 558 157 337 minecraft:pink_concrete
setblock 558 157 340 minecraft:moss_block
setblock 558 157 343 minecraft:pink_concrete
fill 558 157 344 558 157 346 minecraft:moss_block
setblock 558 157 349 minecraft:pink_concrete
setblock 558 157 352 minecraft:moss_block
setblock 558 157 355 minecraft:pink_concrete
fill 558 157 356 558 157 360 minecraft:moss_block
setblock 558 157 361 minecraft:pink_concrete
fill 528 158 331 528 159 331 minecraft:bone_block
fill 528 158 340 528 164 340 minecraft:bone_block
fill 528 158 349 528 159 349 minecraft:bone_block
fill 531 158 331 531 159 331 minecraft:bone_block
fill 531 158 340 531 164 340 minecraft:bone_block
fill 531 158 349 531 159 349 minecraft:bone_block
fill 534 158 331 534 159 331 minecraft:bone_block
fill 534 158 340 534 164 340 minecraft:bone_block
fill 534 158 349 534 159 349 minecraft:bone_block
fill 537 158 331 537 159 331 minecraft:bone_block
fill 537 158 349 537 159 349 minecraft:bone_block
fill 540 158 331 540 159 331 minecraft:bone_block
fill 540 158 340 540 164 340 minecraft:bone_block
fill 540 158 349 540 159 349 minecraft:bone_block
fill 543 158 331 543 159 331 minecraft:bone_block
fill 543 158 340 543 164 340 minecraft:bone_block
fill 543 158 349 543 159 349 minecraft:bone_block
fill 546 158 331 546 159 331 minecraft:bone_block
fill 546 158 340 546 168 340 minecraft:bone_block
fill 546 158 349 546 159 349 minecraft:bone_block
fill 528 160 332 528 161 332 minecraft:bone_block
fill 528 160 348 528 161 348 minecraft:bone_block
fill 531 160 332 531 161 332 minecraft:bone_block
fill 531 160 348 531 161 348 minecraft:bone_block
fill 534 160 332 534 161 332 minecraft:bone_block
fill 534 160 348 534 161 348 minecraft:bone_block
fill 537 160 332 537 161 332 minecraft:bone_block
fill 537 160 340 537 164 340 minecraft:bone_block
fill 537 160 348 537 161 348 minecraft:bone_block
fill 540 160 332 540 161 332 minecraft:bone_block
fill 540 160 348 540 161 348 minecraft:bone_block
fill 543 160 332 543 161 332 minecraft:bone_block
fill 543 160 348 543 161 348 minecraft:bone_block
fill 546 160 332 546 161 332 minecraft:bone_block
fill 546 160 348 546 161 348 minecraft:bone_block
fill 518 161 328 518 162 339 minecraft:stripped_dark_oak_log
fill 518 161 342 518 217 342 minecraft:stripped_dark_oak_log
fill 518 161 349 518 217 349 minecraft:stripped_dark_oak_log
fill 518 161 356 518 217 356 minecraft:stripped_dark_oak_log
fill 518 161 363 518 217 363 minecraft:stripped_dark_oak_log
fill 519 161 329 521 162 339 minecraft:stripped_dark_oak_log
fill 520 161 323 520 217 323 minecraft:stripped_dark_oak_log
fill 525 161 363 525 217 363 minecraft:stripped_dark_oak_log
fill 527 161 323 527 217 323 minecraft:stripped_dark_oak_log
fill 532 161 363 532 217 363 minecraft:stripped_dark_oak_log
fill 534 161 323 534 217 323 minecraft:stripped_dark_oak_log
fill 539 161 363 539 217 363 minecraft:stripped_dark_oak_log
fill 541 161 323 541 217 323 minecraft:stripped_dark_oak_log
fill 544 161 353 546 169 353 minecraft:dark_oak_planks
fill 545 161 352 546 169 352 minecraft:dark_oak_planks
fill 545 161 354 545 169 354 minecraft:dark_oak_planks
fill 545 161 358 557 162 363 minecraft:stripped_dark_oak_log
fill 548 161 323 548 217 323 minecraft:stripped_dark_oak_log
fill 555 161 323 555 217 323 minecraft:stripped_dark_oak_log
fill 558 161 327 558 217 327 minecraft:stripped_dark_oak_log
fill 558 161 334 558 217 334 minecraft:stripped_dark_oak_log
fill 558 161 341 558 217 341 minecraft:stripped_dark_oak_log
fill 558 161 348 558 217 348 minecraft:stripped_dark_oak_log
fill 558 161 355 558 217 355 minecraft:stripped_dark_oak_log
fill 558 161 362 558 217 362 minecraft:stripped_dark_oak_log
setblock 518 162 343 minecraft:stripped_dark_oak_log
setblock 518 162 350 minecraft:stripped_dark_oak_log
setblock 518 162 357 minecraft:stripped_dark_oak_log
setblock 519 162 323 minecraft:stripped_dark_oak_log
setblock 519 162 363 minecraft:stripped_dark_oak_log
setblock 526 162 323 minecraft:stripped_dark_oak_log
setblock 526 162 363 minecraft:stripped_dark_oak_log
fill 528 162 333 528 163 333 minecraft:bone_block
fill 528 162 347 528 163 347 minecraft:bone_block
fill 531 162 333 531 163 333 minecraft:bone_block
fill 531 162 347 531 163 347 minecraft:bone_block
setblock 533 162 323 minecraft:stripped_dark_oak_log
setblock 533 162 363 minecraft:stripped_dark_oak_log
fill 534 162 333 534 163 333 minecraft:bone_block
fill 534 162 347 534 163 347 minecraft:bone_block
fill 537 162 333 537 163 333 minecraft:bone_block
fill 537 162 347 537 163 347 minecraft:bone_block
setblock 540 162 323 minecraft:stripped_dark_oak_log
fill 540 162 333 540 163 333 minecraft:bone_block
fill 540 162 347 540 163 347 minecraft:bone_block
setblock 540 162 363 minecraft:stripped_dark_oak_log
fill 543 162 333 543 163 333 minecraft:bone_block
fill 543 162 347 543 163 347 minecraft:bone_block
fill 544 162 352 544 169 352 minecraft:dark_oak_planks
fill 544 162 354 544 169 354 minecraft:dark_oak_planks
fill 545 162 351 545 169 351 minecraft:dark_oak_planks
fill 546 162 333 546 163 333 minecraft:bone_block
fill 546 162 347 546 163 347 minecraft:bone_block
fill 546 162 354 546 169 354 minecraft:dark_oak_planks
setblock 547 162 323 minecraft:stripped_dark_oak_log
fill 547 162 353 547 169 353 minecraft:dark_oak_planks
fill 549 162 339 551 168 340 minecraft:bone_block
fill 550 162 341 551 169 341 minecraft:bone_block
fill 552 162 340 552 168 340 minecraft:bone_block
setblock 554 162 323 minecraft:stripped_dark_oak_log
setblock 558 162 326 minecraft:stripped_dark_oak_log
setblock 558 162 333 minecraft:stripped_dark_oak_log
setblock 558 162 340 minecraft:stripped_dark_oak_log
setblock 558 162 347 minecraft:stripped_dark_oak_log
setblock 558 162 354 minecraft:stripped_dark_oak_log
setblock 558 162 361 minecraft:stripped_dark_oak_log
setblock 518 163 323 minecraft:stripped_dark_oak_log
fill 518 163 328 518 217 328 minecraft:stripped_dark_oak_log
setblock 518 163 329 minecraft:shroomlight
fill 518 163 330 518 178 330 minecraft:stripped_dark_oak_log
setblock 518 163 331 minecraft:shroomlight
fill 518 163 332 518 180 332 minecraft:stripped_dark_oak_log
setblock 518 163 333 minecraft:shroomlight
fill 518 163 334 518 178 334 minecraft:stripped_dark_oak_log
setblock 518 163 335 minecraft:shroomlight
fill 518 163 336 518 178 336 minecraft:stripped_dark_oak_log
setblock 518 163 337 minecraft:shroomlight
fill 518 163 338 518 178 338 minecraft:stripped_dark_oak_log
setblock 518 163 339 minecraft:shroomlight
setblock 518 163 344 minecraft:stripped_dark_oak_log
setblock 518 163 351 minecraft:stripped_dark_oak_log
setblock 518 163 358 minecraft:stripped_dark_oak_log
fill 519 163 329 519 178 329 minecraft:stripped_dark_oak_log
setblock 519 163 330 minecraft:shroomlight
fill 519 163 331 519 178 331 minecraft:stripped_dark_oak_log
setblock 519 163 332 minecraft:shroomlight
fill 519 163 333 519 178 333 minecraft:stripped_dark_oak_log
setblock 519 163 334 minecraft:shroomlight
fill 519 163 335 519 178 335 minecraft:stripped_dark_oak_log
setblock 519 163 336 minecraft:shroomlight
fill 519 163 337 519 178 337 minecraft:stripped_dark_oak_log
setblock 519 163 338 minecraft:shroomlight
fill 519 163 339 519 178 339 minecraft:stripped_dark_oak_log
setblock 520 163 329 minecraft:shroomlight
fill 520 163 330 520 178 330 minecraft:stripped_dark_oak_log
setblock 520 163 331 minecraft:shroomlight
fill 520 163 332 520 178 332 minecraft:stripped_dark_oak_log
setblock 520 163 333 minecraft:shroomlight
fill 520 163 334 520 178 334 minecraft:stripped_dark_oak_log
setblock 520 163 335 minecraft:shroomlight
fill 520 163 336 520 178 336 minecraft:stripped_dark_oak_log
setblock 520 163 337 minecraft:shroomlight
fill 520 163 338 520 178 338 minecraft:stripped_dark_oak_log
setblock 520 163 339 minecraft:shroomlight
setblock 520 163 363 minecraft:stripped_dark_oak_log
fill 521 163 329 521 178 329 minecraft:stripped_dark_oak_log
setblock 521 163 330 minecraft:shroomlight
fill 521 163 331 521 178 331 minecraft:stripped_dark_oak_log
setblock 521 163 332 minecraft:shroomlight
fill 521 163 333 521 178 333 minecraft:stripped_dark_oak_log
setblock 521 163 334 minecraft:shroomlight
fill 521 163 335 521 178 335 minecraft:stripped_dark_oak_log
setblock 521 163 336 minecraft:shroomlight
fill 521 163 337 521 178 337 minecraft:stripped_dark_oak_log
setblock 521 163 338 minecraft:shroomlight
fill 521 163 339 521 178 339 minecraft:stripped_dark_oak_log
setblock 525 163 323 minecraft:stripped_dark_oak_log
setblock 527 163 363 minecraft:stripped_dark_oak_log
fill 528 163 334 528 165 334 minecraft:bone_block
fill 528 163 346 528 165 346 minecraft:bone_block
fill 531 163 334 531 165 334 minecraft:bone_block
fill 531 163 346 531 165 346 minecraft:bone_block
setblock 532 163 323 minecraft:stripped_dark_oak_log
fill 534 163 334 534 165 334 minecraft:bone_block
fill 534 163 346 534 165 346 minecraft:bone_block
setblock 534 163 363 minecraft:stripped_dark_oak_log
fill 537 163 334 537 165 334 minecraft:bone_block
fill 537 163 346 537 165 346 minecraft:bone_block
setblock 539 163 323 minecraft:stripped_dark_oak_log
fill 540 163 334 540 165 334 minecraft:bone_block
fill 540 163 346 540 165 346 minecraft:bone_block
setblock 541 163 363 minecraft:stripped_dark_oak_log
fill 543 163 334 543 165 334 minecraft:bone_block
fill 543 163 346 543 165 346 minecraft:bone_block
fill 543 163 353 543 169 353 minecraft:dark_oak_planks
fill 544 163 351 544 169 351 minecraft:dark_oak_planks
fill 545 163 355 546 169 355 minecraft:dark_oak_planks
setblock 545 163 358 minecraft:shroomlight
fill 545 163 359 545 184 359 minecraft:stripped_dark_oak_log
setblock 545 163 360 minecraft:shroomlight
fill 545 163 361 545 184 361 minecraft:stripped_dark_oak_log
setblock 545 163 362 minecraft:shroomlight
fill 545 163 363 545 184 363 minecraft:stripped_dark_oak_log
setblock 546 163 323 minecraft:stripped_dark_oak_log
fill 546 163 334 546 165 334 minecraft:bone_block
fill 546 163 346 546 165 346 minecraft:bone_block
fill 546 163 351 546 169 351 minecraft:dark_oak_planks
fill 546 163 358 546 184 358 minecraft:stripped_dark_oak_log
setblock 546 163 359 minecraft:shroomlight
fill 546 163 360 546 184 360 minecraft:stripped_dark_oak_log
setblock 546 163 361 minecraft:shroomlight
fill 546 163 362 546 184 362 minecraft:stripped_dark_oak_log
setblock 546 163 363 minecraft:shroomlight
fill 547 163 339 548 166 342 minecraft:bone_block
fill 547 163 352 547 169 352 minecraft:dark_oak_planks
fill 547 163 354 547 169 354 minecraft:dark_oak_planks
setblock 547 163 358 minecraft:shroomlight
fill 547 163 359 547 184 359 minecraft:stripped_dark_oak_log
setblock 547 163 360 minecraft:shroomlight
fill 547 163 361 547 184 361 minecraft:stripped_dark_oak_log
setblock 547 163 362 minecraft:shroomlight
fill 547 163 363 547 184 363 minecraft:stripped_dark_oak_log
fill 548 163 338 552 168 338 minecraft:bone_block
fill 548 163 343 550 166 343 minecraft:bone_block
fill 548 163 358 548 184 358 minecraft:stripped_dark_oak_log
setblock 548 163 359 minecraft:shroomlight
fill 548 163 360 548 184 360 minecraft:stripped_dark_oak_log
setblock 548 163 361 minecraft:shroomlight
fill 548 163 362 548 184 362 minecraft:stripped_dark_oak_log
setblock 548 163 363 minecraft:shroomlight
fill 549 163 341 549 168 342 minecraft:bone_block
setblock 549 163 358 minecraft:shroomlight
fill 549 163 359 549 184 359 minecraft:stripped_dark_oak_log
setblock 549 163 360 minecraft:shroomlight
fill 549 163 361 549 184 361 minecraft:stripped_dark_oak_log
setblock 549 163 362 minecraft:shroomlight
fill 549 163 363 549 185 363 minecraft:stripped_dark_oak_log
fill 550 163 342 551 169 342 minecraft:bone_block
fill 550 163 358 550 184 358 minecraft:stripped_dark_oak_log
setblock 550 163 359 minecraft:shroomlight
fill 550 163 360 550 184 360 minecraft:stripped_dark_oak_log
setblock 550 163 361 minecraft:shroomlight
fill 550 163 362 550 184 362 minecraft:stripped_dark_oak_log
setblock 550 163 363 minecraft:shroomlight
setblock 551 163 358 minecraft:shroomlight
fill 551 163 359 551 184 359 minecraft:stripped_dark_oak_log
setblock 551 163 360 minecraft:shroomlight
fill 551 163 361 551 184 361 minecraft:stripped_dark_oak_log
setblock 551 163 362 minecraft:shroomlight
fill 551 163 363 551 184 363 minecraft:stripped_dark_oak_log
fill 552 163 339 553 167 339 minecraft:bone_block
fill 552 163 341 552 169 341 minecraft:bone_block
fill 552 163 358 552 184 358 minecraft:stripped_dark_oak_log
setblock 552 163 359 minecraft:shroomlight
fill 552 163 360 552 184 360 minecraft:stripped_dark_oak_log
setblock 552 163 361 minecraft:shroomlight
fill 552 163 362 552 184 362 minecraft:stripped_dark_oak_log
setblock 552 163 363 minecraft:shroomlight
setblock 553 163 323 minecraft:stripped_dark_oak_log
fill 553 163 340 553 168 340 minecraft:bone_block
setblock 553 163 358 minecraft:shroomlight
fill 553 163 359 553 184 359 minecraft:stripped_dark_oak_log
setblock 553 163 360 minecraft:shroomlight
fill 553 163 361 553 184 361 minecraft:stripped_dark_oak_log
setblock 553 163 362 minecraft:shroomlight
fill 553 163 363 553 217 363 minecraft:stripped_dark_oak_log
fill 554 163 358 554 184 358 minecraft:stripped_dark_oak_log
setblock 554 163 359 minecraft:shroomlight
fill 554 163 360 554 184 360 minecraft:stripped_dark_oak_log
setblock 554 163 361 minecraft:shroomlight
fill 554 163 362 554 184 362 minecraft:stripped_dark_oak_log
setblock 554 163 363 minecraft:shroomlight
setblock 555 163 358 minecraft:shroomlight
fill 555 163 359 555 184 359 minecraft:stripped_dark_oak_log
setblock 555 163 360 minecraft:shroomlight
fill 555 163 361 555 184 361 minecraft:stripped_dark_oak_log
setblock 555 163 362 minecraft:shroomlight
fill 555 163 363 555 184 363 minecraft:stripped_dark_oak_log
fill 556 163 358 556 184 358 minecraft:stripped_dark_oak_log
setblock 556 163 359 minecraft:shroomlight
fill 556 163 360 556 184 360 minecraft:stripped_dark_oak_log
setblock 556 163 361 minecraft:shroomlight
fill 556 163 362 556 184 362 minecraft:stripped_dark_oak_log
setblock 556 163 363 minecraft:shroomlight
setblock 557 163 358 minecraft:shroomlight
fill 557 163 359 557 184 359 minecraft:stripped_dark_oak_log
setblock 557 163 360 minecraft:shroomlight
fill 557 163 361 557 184 361 minecraft:stripped_dark_oak_log
setblock 557 163 362 minecraft:shroomlight
fill 557 163 363 557 184 363 minecraft:stripped_dark_oak_log
setblock 558 163 325 minecraft:stripped_dark_oak_log
setblock 558 163 332 minecraft:stripped_dark_oak_log
setblock 558 163 339 minecraft:stripped_dark_oak_log
setblock 558 163 346 minecraft:stripped_dark_oak_log
setblock 558 163 353 minecraft:stripped_dark_oak_log
setblock 558 163 360 minecraft:stripped_dark_oak_log
setblock 518 164 324 minecraft:stripped_dark_oak_log
fill 518 164 329 518 165 329 minecraft:stripped_dark_oak_log
fill 518 164 331 518 165 331 minecraft:stripped_dark_oak_log
fill 518 164 333 518 165 333 minecraft:stripped_dark_oak_log
fill 518 164 335 518 165 335 minecraft:stripped_dark_oak_log
fill 518 164 337 518 165 337 minecraft:stripped_dark_oak_log
fill 518 164 339 518 165 339 minecraft:stripped_dark_oak_log
setblock 518 164 345 minecraft:stripped_dark_oak_log
setblock 518 164 352 minecraft:stripped_dark_oak_log
setblock 518 164 359 minecraft:stripped_dark_oak_log
fill 519 164 330 519 165 330 minecraft:stripped_dark_oak_log
fill 519 164 332 519 165 332 minecraft:stripped_dark_oak_log
fill 519 164 334 519 165 334 minecraft:stripped_dark_oak_log
fill 519 164 336 519 165 336 minecraft:stripped_dark_oak_log
fill 519 164 338 519 165 338 minecraft:stripped_dark_oak_log
setblock 520 164 325 minecraft:light[level=14]
fill 520 164 329 520 165 329 minecraft:stripped_dark_oak_log
fill 520 164 331 520 165 331 minecraft:stripped_dark_oak_log
fill 520 164 333 520 165 333 minecraft:stripped_dark_oak_log
fill 520 164 335 520 165 335 minecraft:stripped_dark_oak_log
fill 520 164 337 520 165 337 minecraft:stripped_dark_oak_log
fill 520 164 339 520 165 339 minecraft:stripped_dark_oak_log
setblock 520 164 341 minecraft:light[level=14]
setblock 520 164 349 minecraft:light[level=14]
setblock 520 164 357 minecraft:light[level=14]
fill 521 164 330 521 165 330 minecraft:stripped_dark_oak_log
fill 521 164 332 521 165 332 minecraft:stripped_dark_oak_log
fill 521 164 334 521 165 334 minecraft:stripped_dark_oak_log
fill 521 164 336 521 165 336 minecraft:stripped_dark_oak_log
fill 521 164 338 521 165 338 minecraft:stripped_dark_oak_log
setblock 521 164 363 minecraft:stripped_dark_oak_log
setblock 524 164 323 minecraft:stripped_dark_oak_log
setblock 528 164 325 minecraft:light[level=14]
setblock 528 164 333 minecraft:light[level=14]
fill 528 164 339 528 167 339 minecraft:bone_block
fill 528 164 341 528 167 341 minecraft:bone_block
setblock 528 164 349 minecraft:light[level=14]
setblock 528 164 357 minecraft:light[level=14]
setblock 528 164 363 minecraft:stripped_dark_oak_log
setblock 531 164 323 minecraft:stripped_dark_oak_log
fill 531 164 339 531 167 339 minecraft:bone_block
fill 531 164 341 531 167 341 minecraft:bone_block
fill 534 164 339 534 167 339 minecraft:bone_block
setblock 535 164 363 minecraft:stripped_dark_oak_log
setblock 536 164 325 minecraft:light[level=14]
setblock 536 164 333 minecraft:light[level=14]
setblock 536 164 349 minecraft:light[level=14]
setblock 536 164 357 minecraft:light[level=14]
fill 537 164 339 537 167 339 minecraft:bone_block
fill 537 164 341 537 167 341 minecraft:bone_block
setblock 538 164 323 minecraft:stripped_dark_oak_log
fill 540 164 339 540 167 339 minecraft:bone_block
fill 540 164 341 540 167 341 minecraft:bone_block
setblock 542 164 363 minecraft:stripped_dark_oak_log
fill 543 164 339 543 167 339 minecraft:bone_block
fill 543 164 341 543 167 341 minecraft:bone_block
fill 543 164 352 543 169 352 minecraft:dark_oak_planks
fill 543 164 354 543 169 354 minecraft:dark_oak_planks
setblock 544 164 325 minecraft:light[level=14]
setblock 544 164 333 minecraft:light[level=14]
setblock 544 164 341 minecraft:light[level=14]
setblock 544 164 349 minecraft:light[level=14]
fill 544 164 355 544 169 355 minecraft:dark_oak_planks
setblock 544 164 357 minecraft:light[level=14]
setblock 545 164 323 minecraft:stripped_dark_oak_log
fill 545 164 350 545 169 350 minecraft:dark_oak_planks
fill 545 164 358 545 165 358 minecraft:stripped_dark_oak_log
fill 545 164 360 545 165 360 minecraft:stripped_dark_oak_log
fill 545 164 362 545 165 362 minecraft:stripped_dark_oak_log
fill 546 164 339 546 167 339 minecraft:bone_block
fill 546 164 341 546 167 341 minecraft:bone_block
fill 546 164 359 546 165 359 minecraft:stripped_dark_oak_log
fill 546 164 361 546 165 361 minecraft:stripped_dark_oak_log
fill 546 164 363 546 165 363 minecraft:stripped_dark_oak_log
fill 547 164 338 547 166 338 minecraft:bone_block
fill 547 164 343 547 165 343 minecraft:bone_block
fill 547 164 351 547 169 351 minecraft:dark_oak_planks
fill 547 164 355 547 169 355 minecraft:dark_oak_planks
fill 547 164 358 547 165 358 minecraft:stripped_dark_oak_log
fill 547 164 360 547 165 360 minecraft:stripped_dark_oak_log
fill 547 164 362 547 165 362 minecraft:stripped_dark_oak_log
fill 548 164 353 548 169 353 minecraft:dark_oak_planks
fill 548 164 359 548 165 359 minecraft:stripped_dark_oak_log
fill 548 164 361 548 165 361 minecraft:stripped_dark_oak_log
fill 548 164 363 548 165 363 minecraft:stripped_dark_oak_log
fill 549 164 337 552 167 337 minecraft:bone_block
fill 549 164 358 549 165 358 minecraft:stripped_dark_oak_log
fill 549 164 360 549 165 360 minecraft:stripped_dark_oak_log
fill 549 164 362 549 165 362 minecraft:stripped_dark_oak_log
fill 550 164 359 550 165 359 minecraft:stripped_dark_oak_log
fill 550 164 361 550 165 361 minecraft:stripped_dark_oak_log
fill 550 164 363 550 165 363 minecraft:stripped_dark_oak_log
fill 551 164 343 551 168 343 minecraft:bone_block
fill 551 164 358 551 165 358 minecraft:stripped_dark_oak_log
fill 551 164 360 551 165 360 minecraft:stripped_dark_oak_log
fill 551 164 362 551 165 362 minecraft:stripped_dark_oak_log
setblock 552 164 323 minecraft:stripped_dark_oak_log
setblock 552 164 325 minecraft:light[level=14]
setblock 552 164 333 minecraft:light[level=14]
fill 552 164 342 552 169 342 minecraft:bone_block
setblock 552 164 349 minecraft:light[level=14]
setblock 552 164 357 minecraft:light[level=14]
fill 552 164 359 552 165 359 minecraft:stripped_dark_oak_log
fill 552 164 361 552 165 361 minecraft:stripped_dark_oak_log
fill 552 164 363 552 165 363 minecraft:stripped_dark_oak_log
fill 553 164 338 553 167 338 minecraft:bone_block
fill 553 164 341 553 168 341 minecraft:bone_block
fill 553 164 358 553 165 358 minecraft:stripped_dark_oak_log
fill 553 164 360 553 165 360 minecraft:stripped_dark_oak_log
fill 553 164 362 553 165 362 minecraft:stripped_dark_oak_log
fill 554 164 359 554 165 359 minecraft:stripped_dark_oak_log
fill 554 164 361 554 165 361 minecraft:stripped_dark_oak_log
fill 554 164 363 554 165 363 minecraft:stripped_dark_oak_log
fill 555 164 358 555 165 358 minecraft:stripped_dark_oak_log
fill 555 164 360 555 165 360 minecraft:stripped_dark_oak_log
fill 555 164 362 555 165 362 minecraft:stripped_dark_oak_log
fill 556 164 359 556 165 359 minecraft:stripped_dark_oak_log
fill 556 164 361 556 165 361 minecraft:stripped_dark_oak_log
fill 556 164 363 556 165 363 minecraft:stripped_dark_oak_log
fill 557 164 358 557 165 358 minecraft:stripped_dark_oak_log
fill 557 164 360 557 165 360 minecraft:stripped_dark_oak_log
fill 557 164 362 557 165 362 minecraft:stripped_dark_oak_log
setblock 558 164 324 minecraft:stripped_dark_oak_log
setblock 558 164 331 minecraft:stripped_dark_oak_log
setblock 558 164 338 minecraft:stripped_dark_oak_log
setblock 558 164 345 minecraft:stripped_dark_oak_log
setblock 558 164 352 minecraft:stripped_dark_oak_log
setblock 558 164 359 minecraft:stripped_dark_oak_log
setblock 518 165 325 minecraft:stripped_dark_oak_log
setblock 518 165 346 minecraft:stripped_dark_oak_log
setblock 518 165 353 minecraft:stripped_dark_oak_log
setblock 518 165 360 minecraft:stripped_dark_oak_log
setblock 522 165 363 minecraft:stripped_dark_oak_log
setblock 523 165 323 minecraft:stripped_dark_oak_log
fill 528 165 335 528 166 335 minecraft:bone_block
fill 528 165 345 528 166 345 minecraft:bone_block
fill 529 165 357 530 166 358 minecraft:pink_wool
setblock 529 165 363 minecraft:stripped_dark_oak_log
setblock 530 165 323 minecraft:stripped_dark_oak_log
fill 531 165 335 531 166 335 minecraft:bone_block
fill 531 165 345 531 166 345 minecraft:bone_block
fill 534 165 335 534 166 335 minecraft:bone_block
fill 534 165 345 534 166 345 minecraft:bone_block
setblock 536 165 363 minecraft:stripped_dark_oak_log
setblock 537 165 323 minecraft:stripped_dark_oak_log
fill 537 165 335 537 166 335 minecraft:bone_block
fill 537 165 345 537 166 345 minecraft:bone_block
fill 537 165 353 537 166 353 minecraft:cherry_leaves[persistent=true]
fill 540 165 335 540 166 335 minecraft:bone_block
fill 540 165 345 540 166 345 minecraft:bone_block
fill 542 165 353 542 169 353 minecraft:dark_oak_planks
fill 543 165 335 543 166 335 minecraft:bone_block
fill 543 165 345 543 166 345 minecraft:bone_block
fill 543 165 351 543 169 351 minecraft:dark_oak_planks
fill 543 165 355 543 169 355 minecraft:dark_oak_planks
setblock 543 165 363 minecraft:stripped_dark_oak_log
setblock 544 165 323 minecraft:stripped_dark_oak_log
fill 544 165 350 544 169 350 minecraft:dark_oak_planks
fill 545 165 356 546 169 356 minecraft:dark_oak_planks
fill 546 165 335 546 166 335 minecraft:bone_block
setblock 546 165 342 minecraft:bone_block
fill 546 165 345 546 166 345 minecraft:bone_block
fill 546 165 350 547 169 350 minecraft:dark_oak_planks
fill 548 165 337 548 167 337 minecraft:bone_block
fill 548 165 351 548 169 352 minecraft:dark_oak_planks
fill 548 165 354 548 169 354 minecraft:dark_oak_planks
setblock 551 165 323 minecraft:stripped_dark_oak_log
setblock 558 165 323 minecraft:stripped_dark_oak_log
setblock 558 165 330 minecraft:stripped_dark_oak_log
setblock 558 165 337 minecraft:stripped_dark_oak_log
setblock 558 165 344 minecraft:stripped_dark_oak_log
setblock 558 165 351 minecraft:stripped_dark_oak_log
setblock 558 165 358 minecraft:stripped_dark_oak_log
setblock 518 166 326 minecraft:stripped_dark_oak_log
setblock 518 166 329 minecraft:shroomlight
setblock 518 166 331 minecraft:shroomlight
setblock 518 166 333 minecraft:shroomlight
setblock 518 166 335 minecraft:shroomlight
setblock 518 166 337 minecraft:shroomlight
setblock 518 166 339 minecraft:shroomlight
setblock 518 166 340 minecraft:stripped_dark_oak_log
setblock 518 166 347 minecraft:stripped_dark_oak_log
setblock 518 166 354 minecraft:stripped_dark_oak_log
setblock 518 166 361 minecraft:stripped_dark_oak_log
setblock 519 166 330 minecraft:shroomlight
setblock 519 166 332 minecraft:shroomlight
setblock 519 166 334 minecraft:shroomlight
setblock 519 166 336 minecraft:shroomlight
setblock 519 166 338 minecraft:shroomlight
setblock 520 166 329 minecraft:shroomlight
setblock 520 166 331 minecraft:shroomlight
setblock 520 166 333 minecraft:shroomlight
setblock 520 166 335 minecraft:shroomlight
setblock 520 166 337 minecraft:shroomlight
setblock 520 166 339 minecraft:shroomlight
setblock 521 166 330 minecraft:shroomlight
setblock 521 166 332 minecraft:shroomlight
setblock 521 166 334 minecraft:shroomlight
setblock 521 166 336 minecraft:shroomlight
setblock 521 166 338 minecraft:shroomlight
setblock 522 166 323 minecraft:stripped_dark_oak_log
setblock 523 166 363 minecraft:stripped_dark_oak_log
fill 528 166 336 528 167 336 minecraft:bone_block
fill 528 166 344 528 167 344 minecraft:bone_block
setblock 529 166 323 minecraft:stripped_dark_oak_log
setblock 530 166 363 minecraft:stripped_dark_oak_log
fill 531 166 336 531 167 336 minecraft:bone_block
fill 531 166 344 531 167 344 minecraft:bone_block
fill 534 166 336 534 167 336 minecraft:bone_block
fill 534 166 344 534 167 344 minecraft:bone_block
setblock 536 166 323 minecraft:stripped_dark_oak_log
fill 537 166 336 537 167 336 minecraft:bone_block
fill 537 166 344 537 167 344 minecraft:bone_block
setblock 537 166 363 minecraft:stripped_dark_oak_log
fill 540 166 336 540 167 336 minecraft:bone_block
fill 540 166 344 540 167 344 minecraft:bone_block
fill 542 166 351 542 169 352 minecraft:dark_oak_planks
fill 542 166 354 542 169 354 minecraft:dark_oak_planks
setblock 543 166 323 minecraft:stripped_dark_oak_log
fill 543 166 336 543 167 336 minecraft:bone_block
fill 543 166 344 543 167 344 minecraft:bone_block
fill 543 166 350 543 169 350 minecraft:dark_oak_planks
fill 544 166 356 544 169 356 minecraft:dark_oak_planks
setblock 544 166 363 minecraft:stripped_dark_oak_log
fill 545 166 349 545 169 349 minecraft:dark_oak_planks
setblock 545 166 358 minecraft:shroomlight
setblock 545 166 360 minecraft:shroomlight
setblock 545 166 362 minecraft:shroomlight
fill 546 166 336 546 167 336 minecraft:bone_block
fill 546 166 344 546 167 344 minecraft:bone_block
setblock 546 166 359 minecraft:shroomlight
setblock 546 166 361 minecraft:shroomlight
setblock 546 166 363 minecraft:shroomlight
fill 547 166 356 547 169 356 minecraft:dark_oak_planks
setblock 547 166 358 minecraft:shroomlight
setblock 547 166 360 minecraft:shroomlight
setblock 547 166 362 minecraft:shroomlight
fill 548 166 355 548 169 355 minecraft:dark_oak_planks
setblock 548 166 359 minecraft:shroomlight
setblock 548 166 361 minecraft:shroomlight
setblock 548 166 363 minecraft:shroomlight
fill 549 166 353 549 169 353 minecraft:dark_oak_planks
setblock 549 166 358 minecraft:shroomlight
setblock 549 166 360 minecraft:shroomlight
setblock 549 166 362 minecraft:shroomlight
setblock 550 166 323 minecraft:stripped_dark_oak_log
setblock 550 166 336 minecraft:bone_block
setblock 550 166 359 minecraft:shroomlight
setblock 550 166 361 minecraft:shroomlight
setblock 550 166 363 minecraft:shroomlight
setblock 551 166 358 minecraft:shroomlight
setblock 551 166 360 minecraft:shroomlight
setblock 551 166 362 minecraft:shroomlight
fill 552 166 343 552 168 343 minecraft:bone_block
setblock 552 166 359 minecraft:shroomlight
setblock 552 166 361 minecraft:shroomlight
setblock 552 166 363 minecraft:shroomlight
fill 553 166 342 553 167 342 minecraft:bone_block
setblock 553 166 358 minecraft:shroomlight
setblock 553 166 360 minecraft:shroomlight
setblock 553 166 362 minecraft:shroomlight
setblock 554 166 359 minecraft:shroomlight
setblock 554 166 361 minecraft:shroomlight
setblock 554 166 363 minecraft:shroomlight
setblock 555 166 358 minecraft:shroomlight
setblock 555 166 360 minecraft:shroomlight
setblock 555 166 362 minecraft:shroomlight
setblock 556 166 359 minecraft:shroomlight
setblock 556 166 361 minecraft:shroomlight
setblock 556 166 363 minecraft:shroomlight
setblock 557 166 323 minecraft:stripped_dark_oak_log
setblock 557 166 358 minecraft:shroomlight
setblock 557 166 360 minecraft:shroomlight
setblock 557 166 362 minecraft:shroomlight
setblock 558 166 329 minecraft:stripped_dark_oak_log
setblock 558 166 336 minecraft:stripped_dark_oak_log
setblock 558 166 343 minecraft:stripped_dark_oak_log
setblock 558 166 350 minecraft:stripped_dark_oak_log
setblock 558 166 357 minecraft:stripped_dark_oak_log
setblock 558 166 363 minecraft:stripped_dark_oak_log
setblock 518 167 327 minecraft:stripped_dark_oak_log
fill 518 167 329 518 168 329 minecraft:stripped_dark_oak_log
fill 518 167 331 518 168 331 minecraft:stripped_dark_oak_log
fill 518 167 333 518 168 333 minecraft:stripped_dark_oak_log
fill 518 167 335 518 168 335 minecraft:stripped_dark_oak_log
fill 518 167 337 518 168 337 minecraft:stripped_dark_oak_log
fill 518 167 339 518 168 339 minecraft:stripped_dark_oak_log
setblock 518 167 341 minecraft:stripped_dark_oak_log
setblock 518 167 348 minecraft:stripped_dark_oak_log
setblock 518 167 355 minecraft:stripped_dark_oak_log
setblock 518 167 362 minecraft:stripped_dark_oak_log
fill 519 167 330 519 168 330 minecraft:stripped_dark_oak_log
fill 519 167 332 519 168 332 minecraft:stripped_dark_oak_log
fill 519 167 334 519 168 334 minecraft:stripped_dark_oak_log
fill 519 167 336 519 168 336 minecraft:stripped_dark_oak_log
fill 519 167 338 519 168 338 minecraft:stripped_dark_oak_log
fill 520 167 329 520 168 329 minecraft:stripped_dark_oak_log
fill 520 167 331 520 168 331 minecraft:stripped_dark_oak_log
fill 520 167 333 520 168 333 minecraft:stripped_dark_oak_log
fill 520 167 335 520 168 335 minecraft:stripped_dark_oak_log
fill 520 167 337 520 168 337 minecraft:stripped_dark_oak_log
fill 520 167 339 520 168 339 minecraft:stripped_dark_oak_log
setblock 521 167 323 minecraft:stripped_dark_oak_log
fill 521 167 330 521 168 330 minecraft:stripped_dark_oak_log
fill 521 167 332 521 168 332 minecraft:stripped_dark_oak_log
fill 521 167 334 521 168 334 minecraft:stripped_dark_oak_log
fill 521 167 336 521 168 336 minecraft:stripped_dark_oak_log
fill 521 167 338 521 168 338 minecraft:stripped_dark_oak_log
setblock 524 167 363 minecraft:stripped_dark_oak_log
fill 526 167 340 534 168 340 minecraft:bone_block
setblock 528 167 323 minecraft:stripped_dark_oak_log
fill 528 167 337 528 167 338 minecraft:bone_block
fill 528 167 342 528 167 343 minecraft:bone_block
fill 531 167 337 531 167 338 minecraft:bone_block
fill 531 167 342 531 167 343 minecraft:bone_block
setblock 531 167 363 minecraft:stripped_dark_oak_log
fill 534 167 337 534 167 338 minecraft:bone_block
setblock 534 167 343 minecraft:bone_block
setblock 535 167 323 minecraft:stripped_dark_oak_log
fill 536 167 340 545 168 340 minecraft:bone_block
fill 537 167 337 537 167 338 minecraft:bone_block
fill 537 167 342 537 167 343 minecraft:bone_block
setblock 538 167 363 minecraft:stripped_dark_oak_log
fill 540 167 337 540 167 338 minecraft:bone_block
fill 540 167 342 540 167 343 minecraft:bone_block
fill 541 167 353 541 169 353 minecraft:dark_oak_planks
setblock 542 167 323 minecraft:stripped_dark_oak_log
fill 542 167 350 542 169 350 minecraft:dark_oak_planks
fill 542 167 355 542 169 355 minecraft:dark_oak_planks
fill 543 167 337 543 167 338 minecraft:bone_block
fill 543 167 342 543 167 343 minecraft:bone_block
fill 543 167 356 543 169 356 minecraft:dark_oak_planks
fill 544 167 349 544 169 349 minecraft:dark_oak_planks
fill 545 167 357 546 169 357 minecraft:dark_oak_planks
fill 545 167 358 545 168 358 minecraft:stripped_dark_oak_log
fill 545 167 360 545 168 360 minecraft:stripped_dark_oak_log
fill 545 167 362 545 168 362 minecraft:stripped_dark_oak_log
fill 546 167 337 546 167 338 minecraft:bone_block
fill 546 167 342 546 167 343 minecraft:bone_block
fill 546 167 349 547 169 349 minecraft:dark_oak_planks
fill 546 167 359 546 168 359 minecraft:stripped_dark_oak_log
fill 546 167 361 546 168 361 minecraft:stripped_dark_oak_log
fill 546 167 363 546 168 363 minecraft:stripped_dark_oak_log
fill 547 167 339 548 167 341 minecraft:bone_block
fill 547 167 358 547 168 358 minecraft:stripped_dark_oak_log
fill 547 167 360 547 168 360 minecraft:stripped_dark_oak_log
fill 547 167 362 547 168 362 minecraft:stripped_dark_oak_log
setblock 548 167 342 minecraft:bone_block
fill 548 167 350 548 169 350 minecraft:dark_oak_planks
fill 548 167 356 548 169 356 minecraft:dark_oak_planks
fill 548 167 359 548 168 359 minecraft:stripped_dark_oak_log
fill 548 167 361 548 168 361 minecraft:stripped_dark_oak_log
fill 548 167 363 548 168 363 minecraft:stripped_dark_oak_log
setblock 549 167 323 minecraft:stripped_dark_oak_log
fill 549 167 343 550 167 343 minecraft:bone_block
fill 549 167 351 549 169 352 minecraft:dark_oak_planks
fill 549 167 354 549 169 354 minecraft:dark_oak_planks
fill 549 167 358 549 168 358 minecraft:stripped_dark_oak_log
fill 549 167 360 549 168 360 minecraft:stripped_dark_oak_log
fill 549 167 362 549 168 362 minecraft:stripped_dark_oak_log
fill 550 167 359 550 168 359 minecraft:stripped_dark_oak_log
fill 550 167 361 550 168 361 minecraft:stripped_dark_oak_log
fill 550 167 363 550 168 363 minecraft:stripped_dark_oak_log
fill 551 167 358 551 168 358 minecraft:stripped_dark_oak_log
fill 551 167 360 551 168 360 minecraft:stripped_dark_oak_log
fill 551 167 362 551 168 362 minecraft:stripped_dark_oak_log
fill 552 167 359 552 168 359 minecraft:stripped_dark_oak_log
fill 552 167 361 552 168 361 minecraft:stripped_dark_oak_log
fill 552 167 363 552 168 363 minecraft:stripped_dark_oak_log
fill 553 167 358 553 168 358 minecraft:stripped_dark_oak_log
fill 553 167 360 553 168 360 minecraft:stripped_dark_oak_log
fill 553 167 362 553 168 362 minecraft:stripped_dark_oak_log
fill 554 167 359 554 168 359 minecraft:stripped_dark_oak_log
fill 554 167 361 554 168 361 minecraft:stripped_dark_oak_log
fill 554 167 363 554 168 363 minecraft:stripped_dark_oak_log
fill 555 167 358 555 168 358 minecraft:stripped_dark_oak_log
fill 555 167 360 555 168 360 minecraft:stripped_dark_oak_log
fill 555 167 362 555 168 362 minecraft:stripped_dark_oak_log
setblock 556 167 323 minecraft:stripped_dark_oak_log
fill 556 167 359 556 168 359 minecraft:stripped_dark_oak_log
fill 556 167 361 556 168 361 minecraft:stripped_dark_oak_log
fill 556 167 363 556 168 363 minecraft:stripped_dark_oak_log
fill 557 167 358 557 168 358 minecraft:stripped_dark_oak_log
fill 557 167 360 557 168 360 minecraft:stripped_dark_oak_log
fill 557 167 362 557 168 362 minecraft:stripped_dark_oak_log
setblock 558 167 328 minecraft:stripped_dark_oak_log
setblock 558 167 335 minecraft:stripped_dark_oak_log
setblock 558 167 342 minecraft:stripped_dark_oak_log
setblock 558 167 349 minecraft:stripped_dark_oak_log
setblock 558 167 356 minecraft:stripped_dark_oak_log
fill 541 168 351 541 169 352 minecraft:dark_oak_planks
fill 541 168 354 541 169 355 minecraft:dark_oak_planks
fill 542 168 356 542 169 356 minecraft:dark_oak_planks
fill 543 168 349 543 169 349 minecraft:dark_oak_planks
fill 543 168 357 544 169 357 minecraft:dark_oak_planks
fill 545 168 348 545 169 348 minecraft:dark_oak_planks
fill 547 168 340 548 168 340 minecraft:bone_block
fill 547 168 357 547 169 357 minecraft:dark_oak_planks
setblock 548 168 339 minecraft:bone_block
setblock 548 168 341 minecraft:bone_block
fill 548 168 349 548 169 349 minecraft:dark_oak_planks
fill 549 168 337 550 168 337 minecraft:bone_block
fill 549 168 350 549 169 350 minecraft:dark_oak_planks
fill 549 168 355 549 169 355 minecraft:dark_oak_planks
setblock 550 168 343 minecraft:bone_block
fill 550 168 353 550 169 353 minecraft:dark_oak_planks
setblock 552 168 339 minecraft:bone_block
setblock 518 169 329 minecraft:shroomlight
setblock 518 169 331 minecraft:shroomlight
setblock 518 169 333 minecraft:shroomlight
setblock 518 169 335 minecraft:shroomlight
setblock 518 169 337 minecraft:shroomlight
setblock 518 169 339 minecraft:shroomlight
fill 518 169 343 518 170 343 minecraft:stripped_dark_oak_log
fill 518 169 350 518 170 350 minecraft:stripped_dark_oak_log
fill 518 169 357 518 170 357 minecraft:stripped_dark_oak_log
fill 519 169 323 519 170 323 minecraft:stripped_dark_oak_log
setblock 519 169 330 minecraft:shroomlight
setblock 519 169 332 minecraft:shroomlight
setblock 519 169 334 minecraft:shroomlight
setblock 519 169 336 minecraft:shroomlight
setblock 519 169 338 minecraft:shroomlight
fill 519 169 363 519 170 363 minecraft:stripped_dark_oak_log
setblock 520 169 329 minecraft:shroomlight
setblock 520 169 331 minecraft:shroomlight
setblock 520 169 333 minecraft:shroomlight
setblock 520 169 335 minecraft:shroomlight
setblock 520 169 337 minecraft:shroomlight
setblock 520 169 339 minecraft:shroomlight
setblock 521 169 330 minecraft:shroomlight
setblock 521 169 332 minecraft:shroomlight
setblock 521 169 334 minecraft:shroomlight
setblock 521 169 336 minecraft:shroomlight
setblock 521 169 338 minecraft:shroomlight
fill 526 169 323 526 170 323 minecraft:stripped_dark_oak_log
fill 526 169 363 526 170 363 minecraft:stripped_dark_oak_log
fill 533 169 323 533 170 323 minecraft:stripped_dark_oak_log
fill 533 169 363 533 170 363 minecraft:stripped_dark_oak_log
fill 540 169 323 540 170 323 minecraft:stripped_dark_oak_log
setblock 540 169 353 minecraft:dark_oak_planks
fill 540 169 363 540 170 363 minecraft:stripped_dark_oak_log
setblock 541 169 350 minecraft:dark_oak_planks
setblock 542 169 349 minecraft:dark_oak_planks
setblock 544 169 348 minecraft:dark_oak_planks
setblock 545 169 358 minecraft:shroomlight
setblock 545 169 360 minecraft:shroomlight
setblock 545 169 362 minecraft:shroomlight
fill 546 169 348 547 169 348 minecraft:dark_oak_planks
setblock 546 169 359 minecraft:shroomlight
setblock 546 169 361 minecraft:shroomlight
setblock 546 169 363 minecraft:shroomlight
fill 547 169 323 547 170 323 minecraft:stripped_dark_oak_log
setblock 547 169 358 minecraft:shroomlight
setblock 547 169 360 minecraft:shroomlight
setblock 547 169 362 minecraft:shroomlight
setblock 548 169 357 minecraft:dark_oak_planks
setblock 548 169 359 minecraft:shroomlight
setblock 548 169 361 minecraft:shroomlight
setblock 548 169 363 minecraft:shroomlight
fill 549 169 338 550 169 340 minecraft:bone_block
setblock 549 169 341 minecraft:pink_wool
setblock 549 169 356 minecraft:dark_oak_planks
setblock 549 169 358 minecraft:shroomlight
setblock 549 169 360 minecraft:shroomlight
setblock 549 169 362 minecraft:shroomlight
fill 550 169 351 550 169 352 minecraft:dark_oak_planks
fill 550 169 354 550 169 355 minecraft:dark_oak_planks
setblock 550 169 359 minecraft:shroomlight
setblock 550 169 361 minecraft:shroomlight
setblock 550 169 363 minecraft:shroomlight
setblock 551 169 340 minecraft:bone_block
setblock 551 169 358 minecraft:shroomlight
setblock 551 169 360 minecraft:shroomlight
setblock 551 169 362 minecraft:shroomlight
setblock 552 169 359 minecraft:shroomlight
setblock 552 169 361 minecraft:shroomlight
setblock 552 169 363 minecraft:shroomlight
setblock 553 169 358 minecraft:shroomlight
setblock 553 169 360 minecraft:shroomlight
setblock 553 169 362 minecraft:shroomlight
fill 554 169 323 554 170 323 minecraft:stripped_dark_oak_log
setblock 554 169 359 minecraft:shroomlight
setblock 554 169 361 minecraft:shroomlight
setblock 554 169 363 minecraft:shroomlight
setblock 555 169 358 minecraft:shroomlight
setblock 555 169 360 minecraft:shroomlight
setblock 555 169 362 minecraft:shroomlight
setblock 556 169 359 minecraft:shroomlight
setblock 556 169 361 minecraft:shroomlight
setblock 556 169 363 minecraft:shroomlight
setblock 557 169 358 minecraft:shroomlight
setblock 557 169 360 minecraft:shroomlight
setblock 557 169 362 minecraft:shroomlight
fill 558 169 326 558 170 326 minecraft:stripped_dark_oak_log
fill 558 169 333 558 170 333 minecraft:stripped_dark_oak_log
fill 558 169 340 558 170 340 minecraft:stripped_dark_oak_log
fill 558 169 347 558 170 347 minecraft:stripped_dark_oak_log
fill 558 169 354 558 170 354 minecraft:stripped_dark_oak_log
fill 558 169 361 558 170 361 minecraft:stripped_dark_oak_log
fill 518 170 323 518 170 327 minecraft:stripped_dark_oak_log
fill 518 170 329 518 171 329 minecraft:stripped_dark_oak_log
fill 518 170 331 518 171 331 minecraft:stripped_dark_oak_log
fill 518 170 333 518 171 333 minecraft:stripped_dark_oak_log
fill 518 170 335 518 171 335 minecraft:stripped_dark_oak_log
fill 518 170 337 518 171 337 minecraft:stripped_dark_oak_log
fill 518 170 339 518 170 341 minecraft:stripped_dark_oak_log
fill 518 170 344 518 170 348 minecraft:stripped_dark_oak_log
fill 518 170 351 518 170 355 minecraft:stripped_dark_oak_log
fill 518 170 358 518 170 362 minecraft:stripped_dark_oak_log
fill 519 170 330 519 171 330 minecraft:stripped_dark_oak_log
fill 519 170 332 519 171 332 minecraft:stripped_dark_oak_log
fill 519 170 334 519 171 334 minecraft:stripped_dark_oak_log
fill 519 170 336 519 171 336 minecraft:stripped_dark_oak_log
fill 519 170 338 519 171 338 minecraft:stripped_dark_oak_log
fill 520 170 329 520 171 329 minecraft:stripped_dark_oak_log
fill 520 170 331 520 171 331 minecraft:stripped_dark_oak_log
fill 520 170 333 520 171 333 minecraft:stripped_dark_oak_log
fill 520 170 335 520 171 335 minecraft:stripped_dark_oak_log
fill 520 170 337 520 171 337 minecraft:stripped_dark_oak_log
fill 520 170 339 520 171 339 minecraft:stripped_dark_oak_log
fill 520 170 363 524 170 363 minecraft:stripped_dark_oak_log
fill 521 170 323 525 170 323 minecraft:stripped_dark_oak_log
fill 521 170 330 521 171 330 minecraft:stripped_dark_oak_log
fill 521 170 332 521 171 332 minecraft:stripped_dark_oak_log
fill 521 170 334 521 171 334 minecraft:stripped_dark_oak_log
fill 521 170 336 521 171 336 minecraft:stripped_dark_oak_log
fill 521 170 338 521 171 338 minecraft:stripped_dark_oak_log
fill 527 170 363 531 170 363 minecraft:stripped_dark_oak_log
fill 528 170 323 532 170 323 minecraft:stripped_dark_oak_log
fill 534 170 363 538 170 363 minecraft:stripped_dark_oak_log
fill 535 170 323 539 170 323 minecraft:stripped_dark_oak_log
fill 541 170 363 544 170 363 minecraft:stripped_dark_oak_log
fill 542 170 323 546 170 323 minecraft:stripped_dark_oak_log
fill 545 170 353 545 173 353 minecraft:stripped_dark_oak_log
fill 545 170 358 545 171 358 minecraft:stripped_dark_oak_log
fill 545 170 360 545 171 360 minecraft:stripped_dark_oak_log
fill 545 170 362 545 171 362 minecraft:stripped_dark_oak_log
fill 546 170 359 546 171 359 minecraft:stripped_dark_oak_log
fill 546 170 361 546 171 361 minecraft:stripped_dark_oak_log
fill 546 170 363 546 171 363 minecraft:stripped_dark_oak_log
fill 547 170 358 547 171 358 minecraft:stripped_dark_oak_log
fill 547 170 360 547 171 360 minecraft:stripped_dark_oak_log
fill 547 170 362 547 171 362 minecraft:stripped_dark_oak_log
fill 548 170 359 548 171 359 minecraft:stripped_dark_oak_log
fill 548 170 361 548 171 361 minecraft:stripped_dark_oak_log
fill 548 170 363 548 171 363 minecraft:stripped_dark_oak_log
fill 549 170 323 553 170 323 minecraft:stripped_dark_oak_log
fill 549 170 358 549 171 358 minecraft:stripped_dark_oak_log
fill 549 170 360 549 171 360 minecraft:stripped_dark_oak_log
fill 549 170 362 549 171 362 minecraft:stripped_dark_oak_log
fill 550 170 359 550 171 359 minecraft:stripped_dark_oak_log
fill 550 170 361 550 171 361 minecraft:stripped_dark_oak_log
fill 550 170 363 550 171 363 minecraft:stripped_dark_oak_log
fill 551 170 358 551 171 358 minecraft:stripped_dark_oak_log
fill 551 170 360 551 171 360 minecraft:stripped_dark_oak_log
fill 551 170 362 551 171 362 minecraft:stripped_dark_oak_log
fill 552 170 359 552 171 359 minecraft:stripped_dark_oak_log
fill 552 170 361 552 171 361 minecraft:stripped_dark_oak_log
fill 552 170 363 552 171 363 minecraft:stripped_dark_oak_log
fill 553 170 358 553 171 358 minecraft:stripped_dark_oak_log
fill 553 170 360 553 171 360 minecraft:stripped_dark_oak_log
fill 553 170 362 553 171 362 minecraft:stripped_dark_oak_log
fill 554 170 359 554 171 359 minecraft:stripped_dark_oak_log
fill 554 170 361 554 171 361 minecraft:stripped_dark_oak_log
fill 554 170 363 554 171 363 minecraft:stripped_dark_oak_log
fill 555 170 358 555 171 358 minecraft:stripped_dark_oak_log
fill 555 170 360 555 171 360 minecraft:stripped_dark_oak_log
fill 555 170 362 555 171 362 minecraft:stripped_dark_oak_log
fill 556 170 323 558 170 323 minecraft:stripped_dark_oak_log
fill 556 170 359 556 171 359 minecraft:stripped_dark_oak_log
fill 556 170 361 556 171 361 minecraft:stripped_dark_oak_log
fill 556 170 363 556 171 363 minecraft:stripped_dark_oak_log
fill 557 170 358 558 170 358 minecraft:stripped_dark_oak_log
fill 557 170 360 558 170 360 minecraft:stripped_dark_oak_log
fill 557 170 362 557 171 362 minecraft:stripped_dark_oak_log
fill 558 170 324 558 170 325 minecraft:stripped_dark_oak_log
fill 558 170 328 558 170 332 minecraft:stripped_dark_oak_log
fill 558 170 335 558 170 339 minecraft:stripped_dark_oak_log
fill 558 170 342 558 170 346 minecraft:stripped_dark_oak_log
fill 558 170 349 558 170 353 minecraft:stripped_dark_oak_log
fill 558 170 356 558 170 357 minecraft:stripped_dark_oak_log
fill 558 170 359 558 171 359 minecraft:stripped_dark_oak_log
setblock 558 170 363 minecraft:stripped_dark_oak_log
setblock 518 171 324 minecraft:stripped_dark_oak_log
setblock 518 171 339 minecraft:stripped_dark_oak_log
setblock 518 171 345 minecraft:stripped_dark_oak_log
setblock 518 171 352 minecraft:stripped_dark_oak_log
setblock 518 171 359 minecraft:stripped_dark_oak_log
setblock 521 171 363 minecraft:stripped_dark_oak_log
setblock 524 171 323 minecraft:stripped_dark_oak_log
setblock 528 171 363 minecraft:stripped_dark_oak_log
setblock 531 171 323 minecraft:stripped_dark_oak_log
setblock 535 171 363 minecraft:stripped_dark_oak_log
setblock 538 171 323 minecraft:stripped_dark_oak_log
setblock 542 171 363 minecraft:stripped_dark_oak_log
setblock 545 171 323 minecraft:stripped_dark_oak_log
setblock 552 171 323 minecraft:stripped_dark_oak_log
setblock 557 171 358 minecraft:stripped_dark_oak_log
setblock 557 171 360 minecraft:stripped_dark_oak_log
setblock 558 171 324 minecraft:stripped_dark_oak_log
setblock 558 171 331 minecraft:stripped_dark_oak_log
setblock 558 171 338 minecraft:stripped_dark_oak_log
setblock 558 171 345 minecraft:stripped_dark_oak_log
setblock 558 171 352 minecraft:stripped_dark_oak_log
setblock 518 172 325 minecraft:stripped_dark_oak_log
setblock 518 172 329 minecraft:shroomlight
setblock 518 172 331 minecraft:shroomlight
setblock 518 172 333 minecraft:shroomlight
setblock 518 172 335 minecraft:shroomlight
setblock 518 172 337 minecraft:shroomlight
setblock 518 172 339 minecraft:shroomlight
setblock 518 172 346 minecraft:stripped_dark_oak_log
setblock 518 172 353 minecraft:stripped_dark_oak_log
setblock 518 172 360 minecraft:stripped_dark_oak_log
setblock 519 172 330 minecraft:shroomlight
setblock 519 172 332 minecraft:shroomlight
setblock 519 172 334 minecraft:shroomlight
setblock 519 172 336 minecraft:shroomlight
setblock 519 172 338 minecraft:shroomlight
setblock 520 172 325 minecraft:light[level=14]
setblock 520 172 329 minecraft:shroomlight
setblock 520 172 331 minecraft:shroomlight
setblock 520 172 333 minecraft:shroomlight
setblock 520 172 335 minecraft:shroomlight
setblock 520 172 337 minecraft:shroomlight
setblock 520 172 339 minecraft:shroomlight
setblock 520 172 341 minecraft:light[level=14]
setblock 520 172 349 minecraft:light[level=14]
setblock 520 172 357 minecraft:light[level=14]
setblock 521 172 330 minecraft:shroomlight
setblock 521 172 332 minecraft:shroomlight
setblock 521 172 334 minecraft:shroomlight
setblock 521 172 336 minecraft:shroomlight
setblock 521 172 338 minecraft:shroomlight
setblock 522 172 363 minecraft:stripped_dark_oak_log
setblock 523 172 323 minecraft:stripped_dark_oak_log
setblock 528 172 325 minecraft:light[level=14]
setblock 528 172 333 minecraft:light[level=14]
setblock 528 172 341 minecraft:light[level=14]
setblock 528 172 349 minecraft:light[level=14]
setblock 528 172 357 minecraft:light[level=14]
setblock 529 172 363 minecraft:stripped_dark_oak_log
setblock 530 172 323 minecraft:stripped_dark_oak_log
setblock 536 172 325 minecraft:light[level=14]
setblock 536 172 333 minecraft:light[level=14]
setblock 536 172 341 minecraft:light[level=14]
setblock 536 172 349 minecraft:light[level=14]
setblock 536 172 357 minecraft:light[level=14]
setblock 536 172 363 minecraft:stripped_dark_oak_log
setblock 537 172 323 minecraft:stripped_dark_oak_log
setblock 543 172 363 minecraft:stripped_dark_oak_log
setblock 544 172 323 minecraft:stripped_dark_oak_log
setblock 544 172 325 minecraft:light[level=14]
setblock 544 172 333 minecraft:light[level=14]
setblock 544 172 341 minecraft:light[level=14]
setblock 544 172 349 minecraft:light[level=14]
setblock 544 172 357 minecraft:light[level=14]
setblock 545 172 358 minecraft:shroomlight
setblock 545 172 360 minecraft:shroomlight
setblock 545 172 362 minecraft:shroomlight
setblock 546 172 359 minecraft:shroomlight
setblock 546 172 361 minecraft:shroomlight
setblock 546 172 363 minecraft:shroomlight
setblock 547 172 358 minecraft:shroomlight
setblock 547 172 360 minecraft:shroomlight
setblock 547 172 362 minecraft:shroomlight
setblock 548 172 359 minecraft:shroomlight
setblock 548 172 361 minecraft:shroomlight
setblock 548 172 363 minecraft:shroomlight
setblock 549 172 358 minecraft:shroomlight
setblock 549 172 360 minecraft:shroomlight
setblock 549 172 362 minecraft:shroomlight
setblock 550 172 359 minecraft:shroomlight
setblock 550 172 361 minecraft:shroomlight
setblock 550 172 363 minecraft:shroomlight
setblock 551 172 323 minecraft:stripped_dark_oak_log
setblock 551 172 358 minecraft:shroomlight
setblock 551 172 360 minecraft:shroomlight
setblock 551 172 362 minecraft:shroomlight
setblock 552 172 325 minecraft:light[level=14]
setblock 552 172 333 minecraft:light[level=14]
setblock 552 172 341 minecraft:light[level=14]
setblock 552 172 349 minecraft:light[level=14]
setblock 552 172 357 minecraft:light[level=14]
setblock 552 172 359 minecraft:shroomlight
setblock 552 172 361 minecraft:shroomlight
setblock 552 172 363 minecraft:shroomlight
setblock 553 172 358 minecraft:shroomlight
setblock 553 172 360 minecraft:shroomlight
setblock 553 172 362 minecraft:shroomlight
setblock 554 172 359 minecraft:shroomlight
setblock 554 172 361 minecraft:shroomlight
setblock 554 172 363 minecraft:shroomlight
setblock 555 172 358 minecraft:shroomlight
setblock 555 172 360 minecraft:shroomlight
setblock 555 172 362 minecraft:shroomlight
setblock 556 172 359 minecraft:shroomlight
setblock 556 172 361 minecraft:shroomlight
setblock 556 172 363 minecraft:shroomlight
setblock 557 172 358 minecraft:shroomlight
setblock 557 172 360 minecraft:shroomlight
setblock 557 172 362 minecraft:shroomlight
setblock 558 172 323 minecraft:stripped_dark_oak_log
setblock 558 172 330 minecraft:stripped_dark_oak_log
setblock 558 172 337 minecraft:stripped_dark_oak_log
setblock 558 172 344 minecraft:stripped_dark_oak_log
setblock 558 172 351 minecraft:stripped_dark_oak_log
setblock 558 172 358 minecraft:stripped_dark_oak_log
setblock 518 173 326 minecraft:stripped_dark_oak_log
fill 518 173 329 518 174 329 minecraft:stripped_dark_oak_log
fill 518 173 331 518 174 331 minecraft:stripped_dark_oak_log
fill 518 173 333 518 174 333 minecraft:stripped_dark_oak_log
fill 518 173 335 518 174 335 minecraft:stripped_dark_oak_log
fill 518 173 337 518 174 337 minecraft:stripped_dark_oak_log
fill 518 173 339 518 173 340 minecraft:stripped_dark_oak_log
setblock 518 173 347 minecraft:stripped_dark_oak_log
setblock 518 173 354 minecraft:stripped_dark_oak_log
setblock 518 173 361 minecraft:stripped_dark_oak_log
fill 519 173 330 519 174 330 minecraft:stripped_dark_oak_log
fill 519 173 332 519 174 332 minecraft:stripped_dark_oak_log
fill 519 173 334 519 174 334 minecraft:stripped_dark_oak_log
fill 519 173 336 519 174 336 minecraft:stripped_dark_oak_log
fill 519 173 338 519 174 338 minecraft:stripped_dark_oak_log
fill 520 173 329 520 174 329 minecraft:stripped_dark_oak_log
fill 520 173 331 520 174 331 minecraft:stripped_dark_oak_log
fill 520 173 333 520 174 333 minecraft:stripped_dark_oak_log
fill 520 173 335 520 174 335 minecraft:stripped_dark_oak_log
fill 520 173 337 520 174 337 minecraft:stripped_dark_oak_log
fill 520 173 339 520 174 339 minecraft:stripped_dark_oak_log
fill 521 173 330 521 174 330 minecraft:stripped_dark_oak_log
fill 521 173 332 521 174 332 minecraft:stripped_dark_oak_log
fill 521 173 334 521 174 334 minecraft:stripped_dark_oak_log
fill 521 173 336 521 174 336 minecraft:stripped_dark_oak_log
fill 521 173 338 521 174 338 minecraft:stripped_dark_oak_log
setblock 522 173 323 minecraft:stripped_dark_oak_log
setblock 523 173 363 minecraft:stripped_dark_oak_log
setblock 529 173 323 minecraft:stripped_dark_oak_log
setblock 530 173 363 minecraft:stripped_dark_oak_log
setblock 536 173 323 minecraft:stripped_dark_oak_log
setblock 537 173 363 minecraft:stripped_dark_oak_log
setblock 543 173 323 minecraft:stripped_dark_oak_log
fill 544 173 352 544 175 354 minecraft:cherry_leaves[persistent=true]
setblock 544 173 363 minecraft:stripped_dark_oak_log
fill 545 173 351 546 175 352 minecraft:cherry_leaves[persistent=true]
fill 545 173 354 546 175 354 minecraft:cherry_leaves[persistent=true]
fill 545 173 358 545 174 358 minecraft:stripped_dark_oak_log
fill 545 173 360 545 174 360 minecraft:stripped_dark_oak_log
fill 545 173 362 545 174 362 minecraft:stripped_dark_oak_log
fill 546 173 353 547 175 353 minecraft:cherry_leaves[persistent=true]
fill 546 173 359 546 174 359 minecraft:stripped_dark_oak_log
fill 546 173 361 546 174 361 minecraft:stripped_dark_oak_log
fill 546 173 363 546 174 363 minecraft:stripped_dark_oak_log
fill 547 173 352 547 175 352 minecraft:cherry_leaves[persistent=true]
fill 547 173 358 547 174 358 minecraft:stripped_dark_oak_log
fill 547 173 360 547 174 360 minecraft:stripped_dark_oak_log
fill 547 173 362 547 174 362 minecraft:stripped_dark_oak_log
fill 548 173 359 548 174 359 minecraft:stripped_dark_oak_log
fill 548 173 361 548 174 361 minecraft:stripped_dark_oak_log
fill 548 173 363 548 174 363 minecraft:stripped_dark_oak_log
fill 549 173 358 549 174 358 minecraft:stripped_dark_oak_log
fill 549 173 360 549 174 360 minecraft:stripped_dark_oak_log
fill 549 173 362 549 174 362 minecraft:stripped_dark_oak_log
setblock 550 173 323 minecraft:stripped_dark_oak_log
fill 550 173 359 550 174 359 minecraft:stripped_dark_oak_log
fill 550 173 361 550 174 361 minecraft:stripped_dark_oak_log
fill 550 173 363 550 174 363 minecraft:stripped_dark_oak_log
fill 551 173 358 551 174 358 minecraft:stripped_dark_oak_log
fill 551 173 360 551 174 360 minecraft:stripped_dark_oak_log
fill 551 173 362 551 174 362 minecraft:stripped_dark_oak_log
fill 552 173 359 552 174 359 minecraft:stripped_dark_oak_log
fill 552 173 361 552 174 361 minecraft:stripped_dark_oak_log
fill 552 173 363 552 174 363 minecraft:stripped_dark_oak_log
fill 553 173 358 553 174 358 minecraft:stripped_dark_oak_log
fill 553 173 360 553 174 360 minecraft:stripped_dark_oak_log
fill 553 173 362 553 174 362 minecraft:stripped_dark_oak_log
fill 554 173 359 554 174 359 minecraft:stripped_dark_oak_log
fill 554 173 361 554 174 361 minecraft:stripped_dark_oak_log
fill 554 173 363 554 174 363 minecraft:stripped_dark_oak_log
fill 555 173 358 555 174 358 minecraft:stripped_dark_oak_log
fill 555 173 360 555 174 360 minecraft:stripped_dark_oak_log
fill 555 173 362 555 174 362 minecraft:stripped_dark_oak_log
fill 556 173 359 556 174 359 minecraft:stripped_dark_oak_log
fill 556 173 361 556 174 361 minecraft:stripped_dark_oak_log
fill 556 173 363 556 174 363 minecraft:stripped_dark_oak_log
setblock 557 173 323 minecraft:stripped_dark_oak_log
fill 557 173 358 557 174 358 minecraft:stripped_dark_oak_log
fill 557 173 360 557 174 360 minecraft:stripped_dark_oak_log
fill 557 173 362 557 174 362 minecraft:stripped_dark_oak_log
setblock 558 173 329 minecraft:stripped_dark_oak_log
setblock 558 173 336 minecraft:stripped_dark_oak_log
setblock 558 173 343 minecraft:stripped_dark_oak_log
setblock 558 173 350 minecraft:stripped_dark_oak_log
setblock 558 173 357 minecraft:stripped_dark_oak_log
setblock 558 173 363 minecraft:stripped_dark_oak_log
setblock 518 174 327 minecraft:stripped_dark_oak_log
setblock 518 174 339 minecraft:stripped_dark_oak_log
setblock 518 174 341 minecraft:stripped_dark_oak_log
setblock 518 174 348 minecraft:stripped_dark_oak_log
setblock 518 174 355 minecraft:stripped_dark_oak_log
setblock 518 174 362 minecraft:stripped_dark_oak_log
setblock 521 174 323 minecraft:stripped_dark_oak_log
setblock 524 174 363 minecraft:stripped_dark_oak_log
setblock 528 174 323 minecraft:stripped_dark_oak_log
setblock 531 174 363 minecraft:stripped_dark_oak_log
setblock 535 174 323 minecraft:stripped_dark_oak_log
fill 535 174 331 535 175 332 minecraft:pink_wool
setblock 538 174 363 minecraft:stripped_dark_oak_log
setblock 542 174 323 minecraft:stripped_dark_oak_log
fill 543 174 352 543 174 353 minecraft:cherry_leaves[persistent=true]
setblock 544 174 351 minecraft:cherry_leaves[persistent=true]
fill 545 174 353 545 175 353 minecraft:cherry_leaves[persistent=true]
fill 545 174 355 546 174 355 minecraft:cherry_leaves[persistent=true]
setblock 547 174 354 minecraft:cherry_leaves[persistent=true]
setblock 549 174 323 minecraft:stripped_dark_oak_log
setblock 556 174 323 minecraft:stripped_dark_oak_log
setblock 558 174 328 minecraft:stripped_dark_oak_log
setblock 558 174 335 minecraft:stripped_dark_oak_log
setblock 558 174 342 minecraft:stripped_dark_oak_log
setblock 558 174 349 minecraft:stripped_dark_oak_log
setblock 558 174 356 minecraft:stripped_dark_oak_log
setblock 518 175 329 minecraft:shroomlight
setblock 518 175 331 minecraft:shroomlight
setblock 518 175 333 minecraft:shroomlight
setblock 518 175 335 minecraft:shroomlight
setblock 518 175 337 minecraft:shroomlight
setblock 518 175 339 minecraft:shroomlight
setblock 519 175 330 minecraft:shroomlight
setblock 519 175 332 minecraft:shroomlight
setblock 519 175 334 minecraft:shroomlight
setblock 519 175 336 minecraft:shroomlight
setblock 519 175 338 minecraft:shroomlight
setblock 520 175 329 minecraft:shroomlight
setblock 520 175 331 minecraft:shroomlight
setblock 520 175 333 minecraft:shroomlight
setblock 520 175 335 minecraft:shroomlight
setblock 520 175 337 minecraft:shroomlight
setblock 520 175 339 minecraft:shroomlight
setblock 521 175 330 minecraft:shroomlight
setblock 521 175 332 minecraft:shroomlight
setblock 521 175 334 minecraft:shroomlight
setblock 521 175 336 minecraft:shroomlight
setblock 521 175 338 minecraft:shroomlight
setblock 545 175 358 minecraft:shroomlight
setblock 545 175 360 minecraft:shroomlight
setblock 545 175 362 minecraft:shroomlight
setblock 546 175 359 minecraft:shroomlight
setblock 546 175 361 minecraft:shroomlight
setblock 546 175 363 minecraft:shroomlight
setblock 547 175 358 minecraft:shroomlight
setblock 547 175 360 minecraft:shroomlight
setblock 547 175 362 minecraft:shroomlight
setblock 548 175 359 minecraft:shroomlight
setblock 548 175 361 minecraft:shroomlight
setblock 548 175 363 minecraft:shroomlight
setblock 549 175 358 minecraft:shroomlight
setblock 549 175 360 minecraft:shroomlight
setblock 549 175 362 minecraft:shroomlight
setblock 550 175 359 minecraft:shroomlight
setblock 550 175 361 minecraft:shroomlight
setblock 550 175 363 minecraft:shroomlight
setblock 551 175 358 minecraft:shroomlight
setblock 551 175 360 minecraft:shroomlight
setblock 551 175 362 minecraft:shroomlight
setblock 552 175 359 minecraft:shroomlight
setblock 552 175 361 minecraft:shroomlight
setblock 552 175 363 minecraft:shroomlight
setblock 553 175 358 minecraft:shroomlight
setblock 553 175 360 minecraft:shroomlight
setblock 553 175 362 minecraft:shroomlight
setblock 554 175 359 minecraft:shroomlight
setblock 554 175 361 minecraft:shroomlight
setblock 554 175 363 minecraft:shroomlight
setblock 555 175 358 minecraft:shroomlight
setblock 555 175 360 minecraft:shroomlight
setblock 555 175 362 minecraft:shroomlight
setblock 556 175 359 minecraft:shroomlight
setblock 556 175 361 minecraft:shroomlight
setblock 556 175 363 minecraft:shroomlight
setblock 557 175 358 minecraft:shroomlight
setblock 557 175 360 minecraft:shroomlight
setblock 557 175 362 minecraft:shroomlight
fill 518 176 329 518 178 329 minecraft:stripped_dark_oak_log
fill 518 176 331 518 178 331 minecraft:stripped_dark_oak_log
fill 518 176 333 518 178 333 minecraft:stripped_dark_oak_log
fill 518 176 335 518 217 335 minecraft:stripped_dark_oak_log
fill 518 176 337 518 178 337 minecraft:stripped_dark_oak_log
fill 518 176 339 518 180 339 minecraft:stripped_dark_oak_log
setblock 518 176 343 minecraft:stripped_dark_oak_log
setblock 518 176 350 minecraft:stripped_dark_oak_log
setblock 518 176 357 minecraft:stripped_dark_oak_log
setblock 519 176 323 minecraft:stripped_dark_oak_log
fill 519 176 330 519 178 330 minecraft:stripped_dark_oak_log
fill 519 176 332 519 178 332 minecraft:stripped_dark_oak_log
fill 519 176 334 519 178 334 minecraft:stripped_dark_oak_log
fill 519 176 336 519 178 336 minecraft:stripped_dark_oak_log
fill 519 176 338 519 178 338 minecraft:stripped_dark_oak_log
setblock 519 176 363 minecraft:stripped_dark_oak_log
fill 520 176 329 520 178 329 minecraft:stripped_dark_oak_log
fill 520 176 331 520 178 331 minecraft:stripped_dark_oak_log
fill 520 176 333 520 178 333 minecraft:stripped_dark_oak_log
fill 520 176 335 520 178 335 minecraft:stripped_dark_oak_log
fill 520 176 337 520 178 337 minecraft:stripped_dark_oak_log
fill 520 176 339 520 178 339 minecraft:stripped_dark_oak_log
fill 521 176 330 521 178 330 minecraft:stripped_dark_oak_log
fill 521 176 332 521 178 332 minecraft:stripped_dark_oak_log
fill 521 176 334 521 178 334 minecraft:stripped_dark_oak_log
fill 521 176 336 521 178 336 minecraft:stripped_dark_oak_log
fill 521 176 338 521 178 338 minecraft:stripped_dark_oak_log
setblock 526 176 323 minecraft:stripped_dark_oak_log
setblock 526 176 363 minecraft:stripped_dark_oak_log
setblock 533 176 323 minecraft:stripped_dark_oak_log
setblock 533 176 363 minecraft:stripped_dark_oak_log
setblock 540 176 323 minecraft:stripped_dark_oak_log
setblock 540 176 363 minecraft:stripped_dark_oak_log
fill 545 176 358 545 177 358 minecraft:stripped_dark_oak_log
fill 545 176 360 545 177 360 minecraft:stripped_dark_oak_log
fill 545 176 362 545 177 362 minecraft:stripped_dark_oak_log
fill 546 176 359 546 177 359 minecraft:stripped_dark_oak_log
fill 546 176 361 546 177 361 minecraft:stripped_dark_oak_log
fill 546 176 363 546 177 363 minecraft:stripped_dark_oak_log
setblock 547 176 323 minecraft:stripped_dark_oak_log
fill 547 176 358 547 177 358 minecraft:stripped_dark_oak_log
fill 547 176 360 547 177 360 minecraft:stripped_dark_oak_log
fill 547 176 362 547 177 362 minecraft:stripped_dark_oak_log
fill 548 176 359 548 177 359 minecraft:stripped_dark_oak_log
fill 548 176 361 548 177 361 minecraft:stripped_dark_oak_log
fill 548 176 363 548 177 363 minecraft:stripped_dark_oak_log
fill 549 176 358 549 177 358 minecraft:stripped_dark_oak_log
fill 549 176 360 549 177 360 minecraft:stripped_dark_oak_log
fill 549 176 362 549 177 362 minecraft:stripped_dark_oak_log
fill 550 176 359 550 177 359 minecraft:stripped_dark_oak_log
fill 550 176 361 550 177 361 minecraft:stripped_dark_oak_log
fill 550 176 363 550 177 363 minecraft:stripped_dark_oak_log
fill 551 176 358 551 177 358 minecraft:stripped_dark_oak_log
fill 551 176 360 551 177 360 minecraft:stripped_dark_oak_log
fill 551 176 362 551 177 362 minecraft:stripped_dark_oak_log
fill 552 176 359 552 177 359 minecraft:stripped_dark_oak_log
fill 552 176 361 552 177 361 minecraft:stripped_dark_oak_log
fill 552 176 363 552 177 363 minecraft:stripped_dark_oak_log
fill 553 176 358 553 177 358 minecraft:stripped_dark_oak_log
fill 553 176 360 553 177 360 minecraft:stripped_dark_oak_log
fill 553 176 362 553 177 362 minecraft:stripped_dark_oak_log
setblock 554 176 323 minecraft:stripped_dark_oak_log
fill 554 176 359 554 177 359 minecraft:stripped_dark_oak_log
fill 554 176 361 554 177 361 minecraft:stripped_dark_oak_log
fill 554 176 363 554 177 363 minecraft:stripped_dark_oak_log
fill 555 176 358 555 177 358 minecraft:stripped_dark_oak_log
fill 555 176 360 555 177 360 minecraft:stripped_dark_oak_log
fill 555 176 362 555 177 362 minecraft:stripped_dark_oak_log
fill 556 176 359 556 177 359 minecraft:stripped_dark_oak_log
fill 556 176 361 556 177 361 minecraft:stripped_dark_oak_log
fill 556 176 363 556 177 363 minecraft:stripped_dark_oak_log
fill 557 176 358 557 177 358 minecraft:stripped_dark_oak_log
fill 557 176 360 557 177 360 minecraft:stripped_dark_oak_log
fill 557 176 362 557 177 362 minecraft:stripped_dark_oak_log
setblock 558 176 326 minecraft:stripped_dark_oak_log
setblock 558 176 333 minecraft:stripped_dark_oak_log
setblock 558 176 340 minecraft:stripped_dark_oak_log
setblock 558 176 347 minecraft:stripped_dark_oak_log
setblock 558 176 354 minecraft:stripped_dark_oak_log
setblock 558 176 361 minecraft:stripped_dark_oak_log
setblock 518 177 323 minecraft:stripped_dark_oak_log
setblock 518 177 344 minecraft:stripped_dark_oak_log
setblock 518 177 351 minecraft:stripped_dark_oak_log
setblock 518 177 358 minecraft:stripped_dark_oak_log
setblock 520 177 363 minecraft:stripped_dark_oak_log
setblock 525 177 323 minecraft:stripped_dark_oak_log
setblock 527 177 363 minecraft:stripped_dark_oak_log
setblock 532 177 323 minecraft:stripped_dark_oak_log
setblock 534 177 363 minecraft:stripped_dark_oak_log
setblock 539 177 323 minecraft:stripped_dark_oak_log
setblock 541 177 363 minecraft:stripped_dark_oak_log
setblock 546 177 323 minecraft:stripped_dark_oak_log
setblock 553 177 323 minecraft:stripped_dark_oak_log
setblock 558 177 325 minecraft:stripped_dark_oak_log
setblock 558 177 332 minecraft:stripped_dark_oak_log
setblock 558 177 339 minecraft:stripped_dark_oak_log
setblock 558 177 346 minecraft:stripped_dark_oak_log
setblock 558 177 353 minecraft:stripped_dark_oak_log
setblock 558 177 360 minecraft:stripped_dark_oak_log
setblock 518 178 324 minecraft:stripped_dark_oak_log
setblock 518 178 345 minecraft:stripped_dark_oak_log
setblock 518 178 352 minecraft:stripped_dark_oak_log
setblock 518 178 359 minecraft:stripped_dark_oak_log
setblock 521 178 363 minecraft:stripped_dark_oak_log
setblock 524 178 323 minecraft:stripped_dark_oak_log
setblock 528 178 363 minecraft:stripped_dark_oak_log
setblock 531 178 323 minecraft:stripped_dark_oak_log
setblock 535 178 363 minecraft:stripped_dark_oak_log
setblock 538 178 323 minecraft:stripped_dark_oak_log
setblock 542 178 363 minecraft:stripped_dark_oak_log
setblock 545 178 323 minecraft:stripped_dark_oak_log
setblock 545 178 358 minecraft:shroomlight
setblock 545 178 360 minecraft:shroomlight
setblock 545 178 362 minecraft:shroomlight
setblock 546 178 359 minecraft:shroomlight
setblock 546 178 361 minecraft:shroomlight
setblock 546 178 363 minecraft:shroomlight
setblock 547 178 358 minecraft:shroomlight
setblock 547 178 360 minecraft:shroomlight
setblock 547 178 362 minecraft:shroomlight
setblock 548 178 359 minecraft:shroomlight
setblock 548 178 361 minecraft:shroomlight
setblock 548 178 363 minecraft:shroomlight
setblock 549 178 358 minecraft:shroomlight
setblock 549 178 360 minecraft:shroomlight
setblock 549 178 362 minecraft:shroomlight
setblock 550 178 359 minecraft:shroomlight
setblock 550 178 361 minecraft:shroomlight
setblock 550 178 363 minecraft:shroomlight
setblock 551 178 358 minecraft:shroomlight
setblock 551 178 360 minecraft:shroomlight
setblock 551 178 362 minecraft:shroomlight
setblock 552 178 323 minecraft:stripped_dark_oak_log
setblock 552 178 359 minecraft:shroomlight
setblock 552 178 361 minecraft:shroomlight
setblock 552 178 363 minecraft:shroomlight
setblock 553 178 358 minecraft:shroomlight
setblock 553 178 360 minecraft:shroomlight
setblock 553 178 362 minecraft:shroomlight
setblock 554 178 359 minecraft:shroomlight
setblock 554 178 361 minecraft:shroomlight
setblock 554 178 363 minecraft:shroomlight
setblock 555 178 358 minecraft:shroomlight
setblock 555 178 360 minecraft:shroomlight
setblock 555 178 362 minecraft:shroomlight
setblock 556 178 359 minecraft:shroomlight
setblock 556 178 361 minecraft:shroomlight
setblock 556 178 363 minecraft:shroomlight
setblock 557 178 358 minecraft:shroomlight
setblock 557 178 360 minecraft:shroomlight
setblock 557 178 362 minecraft:shroomlight
setblock 558 178 324 minecraft:stripped_dark_oak_log
setblock 558 178 331 minecraft:stripped_dark_oak_log
setblock 558 178 338 minecraft:stripped_dark_oak_log
setblock 558 178 345 minecraft:stripped_dark_oak_log
setblock 558 178 352 minecraft:stripped_dark_oak_log
setblock 558 178 359 minecraft:stripped_dark_oak_log
fill 518 179 325 518 180 325 minecraft:stripped_dark_oak_log
fill 518 179 346 518 180 346 minecraft:stripped_dark_oak_log
fill 518 179 353 518 180 353 minecraft:stripped_dark_oak_log
fill 518 179 360 518 180 360 minecraft:stripped_dark_oak_log
fill 519 179 330 520 179 338 minecraft:red_concrete
fill 522 179 363 522 180 363 minecraft:stripped_dark_oak_log
fill 523 179 323 523 180 323 minecraft:stripped_dark_oak_log
fill 529 179 363 529 180 363 minecraft:stripped_dark_oak_log
fill 530 179 323 530 180 323 minecraft:stripped_dark_oak_log
fill 536 179 363 536 180 363 minecraft:stripped_dark_oak_log
fill 537 179 323 537 180 323 minecraft:stripped_dark_oak_log
fill 543 179 363 543 180 363 minecraft:stripped_dark_oak_log
fill 544 179 323 544 180 323 minecraft:stripped_dark_oak_log
fill 545 179 358 545 180 358 minecraft:stripped_dark_oak_log
fill 545 179 360 545 180 360 minecraft:stripped_dark_oak_log
fill 545 179 362 545 180 362 minecraft:stripped_dark_oak_log
fill 546 179 359 546 180 359 minecraft:stripped_dark_oak_log
fill 546 179 361 546 180 361 minecraft:stripped_dark_oak_log
fill 546 179 363 546 180 363 minecraft:stripped_dark_oak_log
fill 547 179 358 547 180 358 minecraft:stripped_dark_oak_log
fill 547 179 360 547 180 360 minecraft:stripped_dark_oak_log
fill 547 179 362 547 180 362 minecraft:stripped_dark_oak_log
fill 548 179 359 548 180 359 minecraft:stripped_dark_oak_log
fill 548 179 361 548 180 361 minecraft:stripped_dark_oak_log
fill 548 179 363 548 180 363 minecraft:stripped_dark_oak_log
fill 549 179 358 549 180 358 minecraft:stripped_dark_oak_log
fill 549 179 360 549 180 360 minecraft:stripped_dark_oak_log
fill 549 179 362 549 180 362 minecraft:stripped_dark_oak_log
fill 550 179 359 550 180 359 minecraft:stripped_dark_oak_log
fill 550 179 361 550 180 361 minecraft:stripped_dark_oak_log
fill 550 179 363 550 180 363 minecraft:stripped_dark_oak_log
fill 551 179 323 551 180 323 minecraft:stripped_dark_oak_log
fill 551 179 358 551 180 358 minecraft:stripped_dark_oak_log
fill 551 179 360 551 180 360 minecraft:stripped_dark_oak_log
fill 551 179 362 551 180 362 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/83_3 1t
