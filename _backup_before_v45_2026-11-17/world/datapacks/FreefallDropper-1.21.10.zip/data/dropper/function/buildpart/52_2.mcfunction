fill 199 282 231 199 283 231 minecraft:white_concrete
fill 199 282 267 199 283 267 minecraft:cyan_terracotta
fill 200 282 231 218 282 231 minecraft:light_gray_concrete
fill 200 282 242 200 283 244 minecraft:light_gray_concrete
fill 200 282 245 200 282 251 minecraft:red_terracotta
fill 200 282 252 200 282 256 minecraft:light_gray_concrete
fill 200 282 267 218 282 267 minecraft:light_gray_concrete
fill 201 282 230 201 283 230 minecraft:white_concrete
setblock 201 282 244 minecraft:red_terracotta
fill 201 282 248 202 283 248 minecraft:bone_block
fill 201 282 250 202 283 250 minecraft:bone_block
setblock 201 282 252 minecraft:red_terracotta
fill 201 282 268 201 283 268 minecraft:cyan_terracotta
fill 202 282 229 216 282 229 minecraft:white_concrete
fill 202 282 230 207 282 230 minecraft:light_gray_concrete
setblock 202 282 243 minecraft:red_terracotta
fill 202 282 246 202 284 247 minecraft:bone_block
fill 202 282 251 202 284 252 minecraft:bone_block
setblock 202 282 253 minecraft:red_terracotta
fill 202 282 268 216 282 268 minecraft:light_gray_concrete
fill 202 282 269 204 282 269 minecraft:cyan_terracotta
setblock 203 282 242 minecraft:red_terracotta
setblock 203 282 254 minecraft:red_terracotta
fill 204 282 239 204 284 240 minecraft:light_gray_concrete
fill 204 282 241 205 282 241 minecraft:red_terracotta
fill 204 282 255 205 282 255 minecraft:red_terracotta
fill 204 282 256 204 283 258 minecraft:light_gray_concrete
fill 205 282 244 205 284 244 minecraft:bone_block
fill 205 282 254 205 284 254 minecraft:bone_block
fill 206 282 234 206 287 235 minecraft:light_gray_concrete
fill 206 282 237 206 286 239 minecraft:light_gray_concrete
fill 206 282 240 213 282 240 minecraft:red_terracotta
fill 206 282 256 214 282 256 minecraft:red_terracotta
fill 206 282 257 225 282 261 minecraft:light_gray_concrete
fill 208 282 243 208 283 244 minecraft:bone_block
fill 208 282 254 208 283 255 minecraft:bone_block
fill 209 282 230 216 282 230 minecraft:light_gray_concrete
fill 209 282 232 220 282 239 minecraft:light_gray_concrete
fill 210 282 243 210 283 244 minecraft:bone_block
fill 210 282 254 210 283 255 minecraft:bone_block
fill 213 282 244 213 284 244 minecraft:bone_block
fill 213 282 254 213 284 254 minecraft:bone_block
fill 214 282 240 227 282 240 minecraft:light_gray_concrete
fill 214 282 241 215 282 241 minecraft:red_terracotta
fill 215 282 247 216 282 247 minecraft:bone_block
fill 215 282 251 216 282 251 minecraft:bone_block
setblock 215 282 255 minecraft:red_terracotta
fill 215 282 256 228 282 256 minecraft:light_gray_concrete
fill 215 282 269 216 282 269 minecraft:cyan_terracotta
fill 216 282 241 227 283 241 minecraft:light_gray_concrete
setblock 216 282 242 minecraft:red_terracotta
fill 216 282 246 216 284 246 minecraft:bone_block
fill 216 282 248 217 283 248 minecraft:bone_block
fill 216 282 250 217 283 250 minecraft:bone_block
fill 216 282 252 216 284 252 minecraft:bone_block
fill 216 282 254 217 282 254 minecraft:red_terracotta
fill 217 282 230 217 283 230 minecraft:white_concrete
setblock 217 282 243 minecraft:red_terracotta
fill 217 282 268 217 283 268 minecraft:cyan_terracotta
setblock 218 282 244 minecraft:red_terracotta
fill 218 282 252 218 282 253 minecraft:red_terracotta
fill 218 282 254 228 283 254 minecraft:light_gray_concrete
fill 219 282 231 219 283 231 minecraft:white_concrete
fill 219 282 245 219 282 246 minecraft:red_terracotta
fill 219 282 250 219 282 251 minecraft:red_terracotta
fill 219 282 253 228 283 253 minecraft:light_gray_concrete
fill 219 282 267 219 283 267 minecraft:cyan_terracotta
fill 220 282 247 220 282 249 minecraft:red_terracotta
setblock 221 282 232 minecraft:white_concrete
fill 221 282 233 221 282 239 minecraft:light_gray_concrete
fill 221 282 247 228 283 249 minecraft:light_gray_concrete
setblock 221 282 266 minecraft:cyan_terracotta
fill 222 282 233 222 283 233 minecraft:white_concrete
fill 222 282 234 222 283 239 minecraft:light_gray_concrete
fill 222 282 265 222 283 265 minecraft:cyan_terracotta
fill 225 282 236 225 283 236 minecraft:white_concrete
fill 225 282 237 225 282 239 minecraft:light_gray_concrete
fill 225 282 262 225 283 262 minecraft:cyan_terracotta
setblock 226 282 237 minecraft:white_concrete
fill 226 282 238 226 282 239 minecraft:light_gray_concrete
fill 226 282 257 226 282 260 minecraft:light_gray_concrete
setblock 226 282 261 minecraft:gray_concrete
fill 227 282 239 227 283 239 minecraft:white_concrete
fill 227 282 257 227 282 258 minecraft:light_gray_concrete
fill 227 282 259 227 283 259 minecraft:cyan_terracotta
fill 228 282 241 228 283 241 minecraft:white_concrete
fill 228 282 257 228 283 257 minecraft:cyan_terracotta
setblock 229 282 242 minecraft:white_concrete
setblock 229 282 256 minecraft:cyan_terracotta
fill 189 283 244 189 283 245 minecraft:cyan_terracotta
setblock 189 283 254 minecraft:cyan_terracotta
fill 190 283 242 190 283 243 minecraft:white_concrete
fill 190 283 244 198 283 254 minecraft:light_gray_concrete
fill 190 283 255 190 283 256 minecraft:cyan_terracotta
setblock 191 283 240 minecraft:white_concrete
fill 191 283 242 199 283 243 minecraft:light_gray_concrete
fill 191 283 255 202 283 256 minecraft:light_gray_concrete
setblock 191 283 258 minecraft:cyan_terracotta
setblock 192 283 238 minecraft:white_concrete
fill 192 283 240 203 283 240 minecraft:light_gray_concrete
fill 192 283 258 203 283 258 minecraft:light_gray_concrete
setblock 192 283 260 minecraft:cyan_terracotta
fill 193 283 237 193 284 237 minecraft:white_concrete
fill 193 283 238 204 283 238 minecraft:light_gray_concrete
fill 193 283 260 202 283 260 minecraft:light_gray_concrete
fill 193 283 261 193 284 261 minecraft:cyan_terracotta
setblock 194 283 235 minecraft:white_concrete
fill 194 283 237 202 284 237 minecraft:light_gray_concrete
fill 194 283 261 224 284 261 minecraft:light_gray_concrete
setblock 194 283 263 minecraft:cyan_terracotta
setblock 195 283 234 minecraft:white_concrete
fill 195 283 235 202 283 235 minecraft:light_gray_concrete
fill 195 283 263 223 283 263 minecraft:light_gray_concrete
setblock 195 283 264 minecraft:cyan_terracotta
fill 196 283 234 203 283 234 minecraft:light_gray_concrete
fill 196 283 264 206 283 264 minecraft:light_gray_concrete
fill 197 283 233 197 284 233 minecraft:white_concrete
fill 197 283 265 197 284 265 minecraft:cyan_terracotta
setblock 198 283 232 minecraft:white_concrete
fill 198 283 233 207 283 233 minecraft:light_gray_concrete
fill 198 283 265 220 283 265 minecraft:light_gray_concrete
setblock 198 283 266 minecraft:cyan_terracotta
fill 199 283 232 207 283 232 minecraft:light_gray_concrete
fill 199 283 244 199 283 245 minecraft:light_gray_concrete
fill 199 283 246 199 283 250 minecraft:pink_terracotta
fill 199 283 251 199 283 254 minecraft:light_gray_concrete
fill 199 283 266 219 283 266 minecraft:light_gray_concrete
setblock 200 283 231 minecraft:white_concrete
setblock 200 283 245 minecraft:pink_terracotta
fill 200 283 247 200 284 251 minecraft:bone_block
setblock 200 283 252 minecraft:pink_terracotta
fill 200 283 253 200 283 254 minecraft:light_gray_concrete
setblock 200 283 267 minecraft:cyan_terracotta
fill 201 283 231 217 283 231 minecraft:light_gray_concrete
fill 201 283 241 201 285 242 minecraft:light_gray_concrete
fill 201 283 243 201 283 244 minecraft:pink_terracotta
fill 201 283 245 201 284 247 minecraft:bone_block
fill 201 283 249 201 284 249 minecraft:bone_block
fill 201 283 251 201 284 253 minecraft:bone_block
setblock 201 283 254 minecraft:light_gray_concrete
fill 201 283 257 203 286 257 minecraft:light_gray_concrete
fill 201 283 267 217 283 267 minecraft:light_gray_concrete
fill 202 283 230 203 283 230 minecraft:white_concrete
fill 202 283 241 202 285 241 minecraft:light_gray_concrete
fill 202 283 242 203 283 242 minecraft:pink_terracotta
fill 202 283 244 203 284 245 minecraft:bone_block
fill 202 283 253 203 284 254 minecraft:bone_block
fill 202 283 268 203 283 268 minecraft:cyan_terracotta
setblock 203 283 246 minecraft:bone_block
setblock 203 283 252 minecraft:bone_block
fill 203 283 255 204 283 255 minecraft:pink_terracotta
fill 203 283 256 203 284 256 minecraft:light_gray_concrete
fill 204 283 229 214 283 229 minecraft:white_concrete
fill 204 283 230 207 283 230 minecraft:light_gray_concrete
fill 204 283 241 205 283 241 minecraft:pink_terracotta
fill 204 283 244 204 284 244 minecraft:bone_block
fill 204 283 254 204 284 254 minecraft:bone_block
fill 204 283 268 214 283 268 minecraft:light_gray_concrete
setblock 204 283 269 minecraft:cyan_terracotta
fill 205 283 243 207 284 243 minecraft:bone_block
fill 205 283 255 207 284 255 minecraft:bone_block
fill 205 283 256 206 283 256 minecraft:pink_terracotta
fill 205 283 257 206 283 260 minecraft:light_gray_concrete
fill 206 283 240 213 283 240 minecraft:pink_terracotta
fill 206 283 244 206 284 244 minecraft:bone_block
fill 206 283 254 206 284 254 minecraft:bone_block
fill 207 283 242 208 284 242 minecraft:bone_block
fill 207 283 256 208 284 256 minecraft:bone_block
fill 207 283 257 212 283 257 minecraft:pink_terracotta
fill 207 283 258 225 283 260 minecraft:light_gray_concrete
fill 208 283 264 222 283 264 minecraft:light_gray_concrete
fill 209 283 230 214 283 230 minecraft:light_gray_concrete
fill 209 283 232 219 283 239 minecraft:light_gray_concrete
fill 210 283 242 211 284 242 minecraft:bone_block
fill 210 283 256 211 284 256 minecraft:bone_block
fill 211 283 243 213 284 243 minecraft:bone_block
fill 211 283 255 213 284 255 minecraft:bone_block
fill 212 283 244 212 284 244 minecraft:bone_block
fill 212 283 254 212 284 254 minecraft:bone_block
fill 213 283 256 214 283 256 minecraft:pink_terracotta
fill 213 283 257 227 283 257 minecraft:light_gray_concrete
fill 214 283 240 226 283 240 minecraft:light_gray_concrete
fill 214 283 241 215 283 241 minecraft:pink_terracotta
fill 214 283 244 216 284 244 minecraft:bone_block
fill 214 283 254 216 284 254 minecraft:bone_block
fill 215 283 230 216 283 230 minecraft:white_concrete
fill 215 283 245 217 284 245 minecraft:bone_block
fill 215 283 253 217 284 253 minecraft:bone_block
fill 215 283 255 216 283 255 minecraft:pink_terracotta
fill 215 283 256 227 283 256 minecraft:light_gray_concrete
fill 215 283 268 216 283 268 minecraft:cyan_terracotta
fill 216 283 242 217 283 242 minecraft:pink_terracotta
fill 216 283 247 218 284 247 minecraft:bone_block
fill 216 283 251 218 284 251 minecraft:bone_block
fill 217 283 246 217 284 246 minecraft:bone_block
fill 217 283 249 218 284 249 minecraft:bone_block
fill 217 283 252 217 284 252 minecraft:bone_block
setblock 217 283 254 minecraft:pink_terracotta
fill 217 283 255 227 283 255 minecraft:light_gray_concrete
setblock 218 283 231 minecraft:white_concrete
fill 218 283 242 227 283 242 minecraft:light_gray_concrete
fill 218 283 243 218 283 244 minecraft:pink_terracotta
fill 218 283 248 218 284 248 minecraft:bone_block
fill 218 283 250 218 284 250 minecraft:bone_block
setblock 218 283 253 minecraft:pink_terracotta
setblock 218 283 267 minecraft:cyan_terracotta
fill 219 283 243 227 284 243 minecraft:light_gray_concrete
fill 219 283 245 219 284 245 minecraft:pink_terracotta
fill 219 283 251 219 283 252 minecraft:pink_terracotta
setblock 220 283 232 minecraft:white_concrete
fill 220 283 233 220 283 239 minecraft:light_gray_concrete
fill 220 283 246 220 284 250 minecraft:pink_terracotta
fill 220 283 252 228 283 252 minecraft:light_gray_concrete
setblock 220 283 266 minecraft:cyan_terracotta
fill 221 283 233 221 284 233 minecraft:white_concrete
fill 221 283 234 221 284 239 minecraft:light_gray_concrete
fill 221 283 246 228 283 246 minecraft:light_gray_concrete
fill 221 283 250 228 284 250 minecraft:light_gray_concrete
fill 221 283 265 221 284 265 minecraft:cyan_terracotta
setblock 223 283 234 minecraft:white_concrete
fill 223 283 235 223 283 239 minecraft:light_gray_concrete
setblock 223 283 264 minecraft:cyan_terracotta
setblock 224 283 235 minecraft:white_concrete
fill 224 283 236 224 283 239 minecraft:light_gray_concrete
setblock 224 283 263 minecraft:cyan_terracotta
fill 225 283 237 225 284 237 minecraft:white_concrete
fill 225 283 238 225 283 239 minecraft:light_gray_concrete
fill 225 283 261 225 284 261 minecraft:cyan_terracotta
setblock 226 283 238 minecraft:white_concrete
setblock 226 283 239 minecraft:light_gray_concrete
fill 226 283 258 226 283 259 minecraft:light_gray_concrete
setblock 226 283 260 minecraft:cyan_terracotta
setblock 227 283 240 minecraft:white_concrete
setblock 227 283 258 minecraft:gray_concrete
fill 228 283 242 228 283 243 minecraft:white_concrete
fill 228 283 255 228 284 255 minecraft:gray_concrete
setblock 228 283 256 minecraft:cyan_terracotta
fill 189 284 248 189 284 250 minecraft:cyan_terracotta
setblock 190 284 243 minecraft:white_concrete
fill 190 284 244 190 284 247 minecraft:cyan_terracotta
fill 190 284 248 198 284 250 minecraft:light_gray_concrete
fill 190 284 251 190 284 255 minecraft:cyan_terracotta
setblock 191 284 231 minecraft:light[level=15]
setblock 191 284 238 minecraft:light[level=15]
fill 191 284 241 191 284 242 minecraft:white_concrete
fill 191 284 243 198 284 247 minecraft:light_gray_concrete
fill 191 284 251 198 284 255 minecraft:light_gray_concrete
fill 191 284 256 191 284 257 minecraft:cyan_terracotta
setblock 191 284 259 minecraft:light[level=15]
setblock 191 284 266 minecraft:light[level=15]
fill 192 284 239 192 284 240 minecraft:white_concrete
fill 192 284 241 200 284 242 minecraft:light_gray_concrete
fill 192 284 256 200 284 257 minecraft:light_gray_concrete
fill 192 284 258 192 285 258 minecraft:gray_concrete
setblock 192 284 259 minecraft:cyan_terracotta
setblock 193 284 238 minecraft:white_concrete
fill 193 284 239 201 284 240 minecraft:light_gray_concrete
fill 193 284 258 225 284 259 minecraft:light_gray_concrete
setblock 193 284 260 minecraft:cyan_terracotta
setblock 194 284 236 minecraft:white_concrete
fill 194 284 238 205 284 238 minecraft:light_gray_concrete
fill 194 284 260 202 284 260 minecraft:light_gray_concrete
setblock 194 284 262 minecraft:cyan_terracotta
setblock 195 284 235 minecraft:white_concrete
fill 195 284 236 206 284 236 minecraft:light_gray_concrete
fill 195 284 262 223 284 262 minecraft:light_gray_concrete
setblock 195 284 263 minecraft:gray_concrete
setblock 196 284 234 minecraft:white_concrete
fill 196 284 235 202 284 235 minecraft:light_gray_concrete
fill 196 284 263 222 284 263 minecraft:light_gray_concrete
setblock 196 284 264 minecraft:cyan_terracotta
fill 197 284 234 203 284 234 minecraft:light_gray_concrete
fill 197 284 264 206 284 264 minecraft:light_gray_concrete
setblock 198 284 231 minecraft:light[level=15]
setblock 198 284 233 minecraft:white_concrete
setblock 198 284 265 minecraft:cyan_terracotta
setblock 198 284 266 minecraft:light[level=15]
fill 199 284 232 200 284 232 minecraft:white_concrete
fill 199 284 233 207 284 233 minecraft:light_gray_concrete
fill 199 284 243 199 285 244 minecraft:light_gray_concrete
fill 199 284 245 199 284 246 minecraft:pink_terracotta
fill 199 284 247 199 284 248 minecraft:bone_block
setblock 199 284 249 minecraft:pink_terracotta
fill 199 284 250 199 284 251 minecraft:bone_block
fill 199 284 252 199 284 255 minecraft:light_gray_concrete
fill 199 284 265 219 284 265 minecraft:light_gray_concrete
fill 199 284 266 200 284 266 minecraft:cyan_terracotta
fill 200 284 243 200 285 243 minecraft:light_gray_concrete
setblock 200 284 244 minecraft:pink_terracotta
fill 200 284 245 200 284 246 minecraft:bone_block
fill 200 284 252 200 284 253 minecraft:bone_block
fill 200 284 254 200 285 255 minecraft:light_gray_concrete
fill 201 284 231 202 284 231 minecraft:white_concrete
fill 201 284 232 207 284 232 minecraft:light_gray_concrete
setblock 201 284 243 minecraft:pink_terracotta
setblock 201 284 248 minecraft:bone_block
setblock 201 284 250 minecraft:bone_block
setblock 201 284 254 minecraft:pink_terracotta
fill 201 284 255 201 285 256 minecraft:light_gray_concrete
fill 201 284 266 217 284 266 minecraft:light_gray_concrete
fill 201 284 267 202 284 267 minecraft:cyan_terracotta
fill 202 284 240 203 286 240 minecraft:light_gray_concrete
setblock 202 284 242 minecraft:pink_terracotta
fill 202 284 243 204 284 243 minecraft:bone_block
fill 202 284 255 204 284 255 minecraft:bone_block
fill 202 284 256 202 285 256 minecraft:light_gray_concrete
fill 203 284 230 207 284 230 minecraft:white_concrete
fill 203 284 231 215 284 231 minecraft:light_gray_concrete
fill 203 284 241 204 284 241 minecraft:pink_terracotta
fill 203 284 267 215 284 267 minecraft:light_gray_concrete
fill 203 284 268 204 284 268 minecraft:cyan_terracotta
fill 204 284 242 206 284 242 minecraft:bone_block
fill 204 284 256 206 284 256 minecraft:bone_block
fill 204 284 257 205 284 257 minecraft:light_gray_concrete
fill 205 284 237 205 288 237 minecraft:light_gray_concrete
fill 205 284 239 205 287 239 minecraft:light_gray_concrete
fill 205 284 240 208 284 240 minecraft:pink_terracotta
setblock 205 284 245 minecraft:light[level=15]
setblock 205 284 252 minecraft:light[level=15]
fill 205 284 260 224 284 260 minecraft:light_gray_concrete
setblock 205 284 268 minecraft:gray_concrete
setblock 206 284 257 minecraft:pink_terracotta
fill 206 284 268 207 285 268 minecraft:cyan_terracotta
fill 207 284 241 208 284 241 minecraft:bone_block
fill 207 284 257 208 284 257 minecraft:bone_block
fill 208 284 229 210 284 229 minecraft:white_concrete
setblock 208 284 243 minecraft:bone_block
setblock 208 284 255 minecraft:bone_block
fill 208 284 264 221 284 264 minecraft:light_gray_concrete
fill 208 284 268 210 284 268 minecraft:light_gray_concrete
fill 208 284 269 210 284 269 minecraft:cyan_terracotta
fill 209 284 230 210 284 230 minecraft:light_gray_concrete
fill 209 284 232 217 284 238 minecraft:light_gray_concrete
fill 209 284 239 210 284 239 minecraft:pink_terracotta
setblock 209 284 242 minecraft:bone_block
setblock 209 284 256 minecraft:bone_block
setblock 209 284 257 minecraft:pink_terracotta
fill 210 284 241 211 284 241 minecraft:bone_block
setblock 210 284 243 minecraft:bone_block
setblock 210 284 255 minecraft:bone_block
fill 210 284 257 211 284 257 minecraft:bone_block
fill 211 284 230 215 284 230 minecraft:white_concrete
fill 211 284 239 220 284 239 minecraft:light_gray_concrete
fill 211 284 240 214 284 240 minecraft:pink_terracotta
fill 211 284 268 211 285 268 minecraft:cyan_terracotta
fill 212 284 242 214 284 242 minecraft:bone_block
setblock 212 284 245 minecraft:light[level=15]
setblock 212 284 252 minecraft:light[level=15]
fill 212 284 256 214 284 256 minecraft:bone_block
fill 212 284 257 213 284 257 minecraft:pink_terracotta
fill 212 284 268 212 285 268 minecraft:gray_concrete
fill 213 284 268 215 284 268 minecraft:cyan_terracotta
fill 214 284 243 216 284 243 minecraft:bone_block
fill 214 284 255 216 284 255 minecraft:bone_block
fill 214 284 257 226 284 257 minecraft:light_gray_concrete
fill 215 284 240 225 285 240 minecraft:light_gray_concrete
fill 215 284 241 216 284 241 minecraft:pink_terracotta
setblock 215 284 256 minecraft:pink_terracotta
fill 216 284 231 217 284 231 minecraft:white_concrete
fill 216 284 256 226 284 256 minecraft:light_gray_concrete
fill 216 284 267 216 285 267 minecraft:cyan_terracotta
fill 217 284 241 226 284 241 minecraft:light_gray_concrete
setblock 217 284 242 minecraft:pink_terracotta
setblock 217 284 248 minecraft:bone_block
setblock 217 284 250 minecraft:bone_block
setblock 217 284 255 minecraft:pink_terracotta
setblock 217 284 267 minecraft:gray_concrete
fill 218 284 232 219 284 232 minecraft:white_concrete
fill 218 284 233 219 284 238 minecraft:light_gray_concrete
fill 218 284 242 226 285 242 minecraft:light_gray_concrete
setblock 218 284 243 minecraft:pink_terracotta
fill 218 284 245 218 284 246 minecraft:bone_block
fill 218 284 252 218 284 253 minecraft:bone_block
setblock 218 284 254 minecraft:pink_terracotta
fill 218 284 255 227 284 255 minecraft:light_gray_concrete
fill 218 284 266 219 284 266 minecraft:cyan_terracotta
setblock 219 284 231 minecraft:light[level=15]
setblock 219 284 244 minecraft:pink_terracotta
fill 219 284 247 219 284 248 minecraft:bone_block
fill 219 284 250 219 284 251 minecraft:bone_block
fill 219 284 252 219 284 253 minecraft:pink_terracotta
fill 219 284 254 227 284 254 minecraft:light_gray_concrete
setblock 220 284 233 minecraft:white_concrete
fill 220 284 234 220 284 238 minecraft:light_gray_concrete
fill 220 284 244 227 284 245 minecraft:light_gray_concrete
setblock 220 284 251 minecraft:pink_terracotta
fill 220 284 252 227 284 253 minecraft:light_gray_concrete
setblock 220 284 265 minecraft:gray_concrete
fill 221 284 246 227 284 249 minecraft:light_gray_concrete
fill 221 284 251 227 285 251 minecraft:light_gray_concrete
setblock 222 284 234 minecraft:white_concrete
fill 222 284 235 222 284 239 minecraft:light_gray_concrete
setblock 222 284 264 minecraft:cyan_terracotta
setblock 223 284 235 minecraft:white_concrete
fill 223 284 236 223 284 239 minecraft:light_gray_concrete
setblock 223 284 263 minecraft:gray_concrete
setblock 224 284 236 minecraft:white_concrete
fill 224 284 237 224 284 239 minecraft:light_gray_concrete
setblock 224 284 262 minecraft:cyan_terracotta
setblock 225 284 238 minecraft:white_concrete
setblock 225 284 239 minecraft:light_gray_concrete
setblock 225 284 260 minecraft:cyan_terracotta
setblock 226 284 231 minecraft:light[level=15]
setblock 226 284 238 minecraft:light[level=15]
setblock 226 284 239 minecraft:gray_concrete
fill 226 284 240 226 285 240 minecraft:white_concrete
fill 226 284 258 226 284 259 minecraft:cyan_terracotta
setblock 226 284 266 minecraft:light[level=15]
fill 227 284 241 227 284 242 minecraft:white_concrete
fill 227 284 256 227 284 257 minecraft:cyan_terracotta
setblock 228 284 243 minecraft:white_concrete
fill 228 284 244 228 284 247 minecraft:cyan_terracotta
fill 228 284 248 228 284 249 minecraft:light_gray_concrete
fill 228 284 251 228 284 254 minecraft:cyan_terracotta
fill 229 284 249 229 284 250 minecraft:cyan_terracotta
fill 188 285 228 188 288 270 minecraft:blue_concrete
fill 189 285 228 230 288 228 minecraft:blue_concrete
fill 189 285 270 230 288 270 minecraft:blue_concrete
fill 190 285 246 190 285 249 minecraft:cyan_terracotta
setblock 190 285 250 minecraft:gray_concrete
fill 190 285 251 190 285 252 minecraft:cyan_terracotta
fill 191 285 242 191 285 244 minecraft:white_concrete
fill 191 285 245 191 286 245 minecraft:cyan_terracotta
fill 191 285 246 197 285 252 minecraft:light_gray_concrete
fill 191 285 253 191 286 253 minecraft:cyan_terracotta
setblock 191 285 254 minecraft:gray_concrete
fill 191 285 255 191 285 256 minecraft:cyan_terracotta
fill 192 285 240 192 285 241 minecraft:white_concrete
fill 192 285 242 198 285 245 minecraft:light_gray_concrete
fill 192 285 253 192 285 256 minecraft:light_gray_concrete
setblock 192 285 257 minecraft:cyan_terracotta
setblock 193 285 239 minecraft:gray_concrete
fill 193 285 240 200 285 241 minecraft:light_gray_concrete
fill 193 285 253 199 285 253 minecraft:light_gray_concrete
fill 193 285 254 194 287 256 minecraft:black_concrete
fill 193 285 257 200 285 258 minecraft:light_gray_concrete
setblock 193 285 259 minecraft:cyan_terracotta
fill 194 285 237 194 285 238 minecraft:white_concrete
fill 194 285 239 201 285 239 minecraft:light_gray_concrete
fill 194 285 259 224 285 259 minecraft:light_gray_concrete
fill 194 285 260 194 285 261 minecraft:cyan_terracotta
setblock 195 285 236 minecraft:white_concrete
fill 195 285 237 202 285 238 minecraft:light_gray_concrete
fill 195 285 254 199 285 256 minecraft:light_gray_concrete
fill 195 285 260 202 285 261 minecraft:light_gray_concrete
setblock 195 285 262 minecraft:cyan_terracotta
setblock 196 285 235 minecraft:white_concrete
fill 196 285 236 206 285 236 minecraft:light_gray_concrete
fill 196 285 262 222 285 262 minecraft:light_gray_concrete
setblock 196 285 263 minecraft:cyan_terracotta
fill 197 285 234 198 285 234 minecraft:white_concrete
fill 197 285 235 202 285 235 minecraft:light_gray_concrete
fill 197 285 263 221 285 263 minecraft:light_gray_concrete
setblock 197 285 264 minecraft:gray_concrete
setblock 198 285 246 minecraft:light_gray_concrete
fill 198 285 247 198 285 250 minecraft:red_terracotta
fill 198 285 251 198 285 252 minecraft:light_gray_concrete
fill 198 285 264 198 286 264 minecraft:cyan_terracotta
setblock 199 285 233 minecraft:white_concrete
fill 199 285 234 203 285 234 minecraft:light_gray_concrete
fill 199 285 242 200 287 242 minecraft:light_gray_concrete
fill 199 285 245 199 285 246 minecraft:red_terracotta
fill 199 285 251 199 285 252 minecraft:red_terracotta
fill 199 285 264 206 285 264 minecraft:light_gray_concrete
setblock 199 285 265 minecraft:gray_concrete
fill 200 285 232 201 285 232 minecraft:white_concrete
fill 200 285 233 218 285 233 minecraft:light_gray_concrete
setblock 200 285 244 minecraft:red_terracotta
setblock 200 285 253 minecraft:red_terracotta
fill 200 285 256 200 288 256 minecraft:light_gray_concrete
fill 200 285 265 218 285 265 minecraft:light_gray_concrete
setblock 200 285 266 minecraft:cyan_terracotta
fill 201 285 240 201 288 240 minecraft:light_gray_concrete
setblock 201 285 243 minecraft:red_terracotta
setblock 201 285 254 minecraft:red_terracotta
fill 201 285 258 207 285 258 minecraft:light_gray_concrete
setblock 201 285 266 minecraft:gray_concrete
fill 202 285 231 205 285 231 minecraft:white_concrete
fill 202 285 232 216 285 232 minecraft:light_gray_concrete
setblock 202 285 242 minecraft:red_terracotta
setblock 202 285 255 minecraft:red_terracotta
fill 202 285 266 216 285 266 minecraft:light_gray_concrete
setblock 202 285 267 minecraft:cyan_terracotta
fill 203 285 238 205 288 238 minecraft:light_gray_concrete
setblock 203 285 241 minecraft:red_terracotta
fill 203 285 256 204 285 256 minecraft:red_terracotta
fill 203 285 261 223 285 261 minecraft:light_gray_concrete
setblock 203 285 267 minecraft:gray_concrete
fill 204 285 239 204 288 239 minecraft:light_gray_concrete
fill 204 285 240 207 285 240 minecraft:red_terracotta
setblock 204 285 257 minecraft:light_gray_concrete
fill 204 285 267 205 285 267 minecraft:cyan_terracotta
fill 205 285 257 207 285 257 minecraft:red_terracotta
fill 205 285 260 223 285 260 minecraft:light_gray_concrete
fill 206 285 230 212 285 230 minecraft:white_concrete
fill 206 285 231 212 285 231 minecraft:light_gray_concrete
fill 206 285 267 212 285 267 minecraft:light_gray_concrete
fill 208 285 234 219 285 238 minecraft:light_gray_concrete
fill 208 285 239 211 285 239 minecraft:red_terracotta
fill 208 285 258 211 285 258 minecraft:red_terracotta
fill 208 285 264 219 285 264 minecraft:light_gray_concrete
fill 208 285 268 210 285 268 minecraft:cyan_terracotta
fill 212 285 239 224 285 239 minecraft:light_gray_concrete
fill 212 285 240 214 285 240 minecraft:red_terracotta
fill 212 285 257 214 285 257 minecraft:red_terracotta
fill 212 285 258 225 285 258 minecraft:light_gray_concrete
fill 213 285 231 216 285 231 minecraft:white_concrete
fill 213 285 267 215 285 267 minecraft:cyan_terracotta
fill 215 285 241 216 285 241 minecraft:red_terracotta
fill 215 285 256 216 285 256 minecraft:red_terracotta
fill 215 285 257 225 285 257 minecraft:light_gray_concrete
fill 217 285 232 218 285 232 minecraft:white_concrete
fill 217 285 241 225 285 241 minecraft:light_gray_concrete
setblock 217 285 242 minecraft:red_terracotta
setblock 217 285 255 minecraft:red_terracotta
fill 217 285 256 223 285 256 minecraft:light_gray_concrete
fill 217 285 266 218 285 266 minecraft:cyan_terracotta
setblock 218 285 243 minecraft:red_terracotta
setblock 218 285 254 minecraft:red_terracotta
fill 218 285 255 223 285 255 minecraft:light_gray_concrete
setblock 219 285 233 minecraft:white_concrete
fill 219 285 243 226 285 243 minecraft:light_gray_concrete
setblock 219 285 244 minecraft:red_terracotta
setblock 219 285 253 minecraft:red_terracotta
fill 219 285 254 223 285 254 minecraft:light_gray_concrete
setblock 219 285 265 minecraft:cyan_terracotta
fill 220 285 234 221 285 234 minecraft:white_concrete
fill 220 285 235 221 285 238 minecraft:light_gray_concrete
fill 220 285 244 226 285 244 minecraft:light_gray_concrete
fill 220 285 245 220 285 247 minecraft:red_terracotta
fill 220 285 250 220 285 252 minecraft:red_terracotta
fill 220 285 253 226 285 253 minecraft:light_gray_concrete
fill 220 285 264 221 285 264 minecraft:cyan_terracotta
fill 221 285 245 226 285 247 minecraft:light_gray_concrete
fill 221 285 248 221 285 249 minecraft:red_terracotta
fill 221 285 250 227 285 250 minecraft:light_gray_concrete
fill 221 285 252 227 285 252 minecraft:light_gray_concrete
setblock 222 285 235 minecraft:white_concrete
fill 222 285 236 222 285 238 minecraft:light_gray_concrete
fill 222 285 248 227 285 249 minecraft:light_gray_concrete
setblock 222 285 263 minecraft:cyan_terracotta
setblock 223 285 236 minecraft:white_concrete
fill 223 285 237 223 285 238 minecraft:light_gray_concrete
setblock 223 285 262 minecraft:cyan_terracotta
fill 224 285 237 224 285 238 minecraft:white_concrete
fill 224 285 254 225 287 256 minecraft:black_concrete
fill 224 285 260 224 286 260 minecraft:gray_concrete
setblock 224 285 261 minecraft:cyan_terracotta
setblock 225 285 239 minecraft:gray_concrete
setblock 225 285 259 minecraft:cyan_terracotta
setblock 226 285 241 minecraft:gray_concrete
fill 226 285 254 226 285 256 minecraft:light_gray_concrete
fill 226 285 257 226 285 258 minecraft:cyan_terracotta
fill 227 285 242 227 285 244 minecraft:white_concrete
fill 227 285 245 227 286 245 minecraft:cyan_terracotta
fill 227 285 246 227 285 247 minecraft:light_gray_concrete
fill 227 285 253 227 285 256 minecraft:cyan_terracotta
fill 228 285 246 228 285 247 minecraft:cyan_terracotta
setblock 228 285 248 minecraft:gray_concrete
fill 228 285 249 228 285 252 minecraft:cyan_terracotta
fill 230 285 229 230 288 269 minecraft:blue_concrete
setblock 191 286 246 minecraft:cyan_terracotta
setblock 191 286 247 minecraft:gray_concrete
fill 191 286 248 191 286 252 minecraft:cyan_terracotta
fill 192 286 242 192 286 244 minecraft:white_concrete
fill 192 286 245 192 286 253 minecraft:light_gray_concrete
fill 192 286 254 192 288 256 minecraft:black_concrete
setblock 193 286 240 minecraft:white_concrete
setblock 193 286 241 minecraft:gray_concrete
fill 193 286 242 197 286 252 minecraft:light_gray_concrete
fill 193 286 253 194 288 253 minecraft:black_concrete
fill 193 286 257 194 288 257 minecraft:black_concrete
setblock 193 286 258 minecraft:cyan_terracotta
fill 194 286 238 195 286 238 minecraft:white_concrete
setblock 194 286 239 minecraft:gray_concrete
fill 194 286 240 200 286 241 minecraft:light_gray_concrete
fill 194 286 258 205 286 258 minecraft:light_gray_concrete
setblock 194 286 259 minecraft:gray_concrete
fill 194 286 260 195 286 260 minecraft:cyan_terracotta
setblock 195 286 237 minecraft:white_concrete
fill 195 286 239 201 286 239 minecraft:light_gray_concrete
fill 195 286 253 198 287 253 minecraft:light_gray_concrete
fill 195 286 254 195 287 256 minecraft:black_concrete
fill 195 286 257 200 287 257 minecraft:light_gray_concrete
fill 195 286 259 223 286 259 minecraft:light_gray_concrete
setblock 195 286 261 minecraft:cyan_terracotta
setblock 196 286 236 minecraft:white_concrete
fill 196 286 237 202 286 238 minecraft:light_gray_concrete
fill 196 286 254 199 286 256 minecraft:light_gray_concrete
fill 196 286 260 202 286 261 minecraft:light_gray_concrete
setblock 196 286 262 minecraft:cyan_terracotta
fill 197 286 235 198 286 235 minecraft:white_concrete
fill 197 286 236 221 286 236 minecraft:light_gray_concrete
fill 197 286 262 221 286 262 minecraft:light_gray_concrete
fill 197 286 263 198 286 263 minecraft:cyan_terracotta
fill 198 286 234 199 286 234 minecraft:white_concrete
fill 198 286 242 198 286 245 minecraft:light_gray_concrete
fill 198 286 246 198 286 251 minecraft:pink_terracotta
setblock 198 286 252 minecraft:light_gray_concrete
fill 199 286 235 202 286 235 minecraft:light_gray_concrete
fill 199 286 243 199 287 243 minecraft:light_gray_concrete
fill 199 286 244 199 286 245 minecraft:pink_terracotta
fill 199 286 252 199 286 253 minecraft:pink_terracotta
fill 199 286 263 219 286 263 minecraft:light_gray_concrete
setblock 199 286 264 minecraft:cyan_terracotta
fill 200 286 233 201 286 233 minecraft:white_concrete
fill 200 286 234 203 286 234 minecraft:light_gray_concrete
fill 200 286 243 200 287 243 minecraft:pink_terracotta
fill 200 286 249 200 288 249 minecraft:white_concrete
setblock 200 286 254 minecraft:pink_terracotta
setblock 200 286 255 minecraft:light_gray_concrete
fill 200 286 264 206 286 264 minecraft:light_gray_concrete
fill 200 286 265 201 286 265 minecraft:cyan_terracotta
fill 201 286 241 201 287 241 minecraft:light_gray_concrete
fill 201 286 242 201 287 242 minecraft:pink_terracotta
fill 201 286 246 201 287 247 minecraft:white_concrete
fill 201 286 251 201 287 252 minecraft:white_concrete
setblock 201 286 255 minecraft:pink_terracotta
setblock 201 286 256 minecraft:light_gray_concrete
fill 202 286 232 204 286 232 minecraft:white_concrete
fill 202 286 233 216 286 233 minecraft:light_gray_concrete
fill 202 286 241 203 286 241 minecraft:pink_terracotta
fill 202 286 246 202 287 246 minecraft:white_concrete
fill 202 286 252 202 287 252 minecraft:white_concrete
fill 202 286 256 203 286 256 minecraft:pink_terracotta
fill 202 286 265 216 286 265 minecraft:light_gray_concrete
fill 202 286 266 204 286 266 minecraft:cyan_terracotta
fill 203 286 245 203 287 245 minecraft:white_concrete
fill 203 286 253 203 287 253 minecraft:white_concrete
fill 203 286 261 222 286 261 minecraft:light_gray_concrete
fill 204 286 240 206 286 240 minecraft:pink_terracotta
fill 204 286 244 204 287 244 minecraft:white_concrete
fill 204 286 254 204 287 254 minecraft:white_concrete
fill 204 286 257 205 286 257 minecraft:pink_terracotta
fill 205 286 231 213 286 231 minecraft:white_concrete
fill 205 286 232 213 286 232 minecraft:light_gray_concrete
fill 205 286 260 222 286 260 minecraft:light_gray_concrete
fill 205 286 266 213 286 266 minecraft:light_gray_concrete
fill 205 286 267 209 286 267 minecraft:cyan_terracotta
fill 206 286 243 206 288 243 minecraft:white_concrete
fill 206 286 255 206 288 255 minecraft:white_concrete
fill 206 286 258 213 287 258 minecraft:pink_terracotta
fill 207 286 234 218 286 235 minecraft:light_gray_concrete
fill 207 286 237 222 286 238 minecraft:light_gray_concrete
fill 207 286 239 212 287 239 minecraft:pink_terracotta
fill 208 286 243 208 287 243 minecraft:white_concrete
fill 208 286 255 208 287 255 minecraft:white_concrete
fill 208 286 264 218 286 264 minecraft:light_gray_concrete
fill 210 286 243 210 287 243 minecraft:white_concrete
fill 210 286 255 210 287 255 minecraft:white_concrete
setblock 210 286 267 minecraft:gray_concrete
fill 211 286 267 213 286 267 minecraft:cyan_terracotta
fill 212 286 243 212 288 243 minecraft:white_concrete
fill 212 286 255 212 288 255 minecraft:white_concrete
fill 213 286 239 223 286 239 minecraft:light_gray_concrete
fill 213 286 240 215 286 240 minecraft:pink_terracotta
fill 214 286 232 216 286 232 minecraft:white_concrete
fill 214 286 244 214 287 244 minecraft:white_concrete
fill 214 286 254 214 287 254 minecraft:white_concrete
fill 214 286 257 215 286 257 minecraft:pink_terracotta
fill 214 286 258 224 286 258 minecraft:light_gray_concrete
fill 214 286 266 214 287 266 minecraft:cyan_terracotta
fill 215 286 245 215 287 245 minecraft:white_concrete
fill 215 286 253 215 287 253 minecraft:white_concrete
setblock 215 286 266 minecraft:gray_concrete
fill 216 286 240 224 286 240 minecraft:light_gray_concrete
fill 216 286 241 216 287 241 minecraft:pink_terracotta
fill 216 286 246 217 287 246 minecraft:white_concrete
fill 216 286 252 217 287 252 minecraft:white_concrete
fill 216 286 256 217 286 256 minecraft:pink_terracotta
fill 216 286 257 223 286 257 minecraft:light_gray_concrete
setblock 216 286 266 minecraft:cyan_terracotta
fill 217 286 233 218 286 233 minecraft:white_concrete
fill 217 286 241 224 286 241 minecraft:light_gray_concrete
setblock 217 286 242 minecraft:pink_terracotta
fill 217 286 247 217 287 247 minecraft:white_concrete
fill 217 286 251 217 287 251 minecraft:white_concrete
fill 217 286 265 218 286 265 minecraft:cyan_terracotta
fill 218 286 242 225 286 242 minecraft:light_gray_concrete
setblock 218 286 243 minecraft:pink_terracotta
fill 218 286 249 218 288 249 minecraft:white_concrete
fill 218 286 255 218 287 255 minecraft:pink_terracotta
fill 218 286 256 222 287 256 minecraft:light_gray_concrete
fill 219 286 234 220 286 234 minecraft:white_concrete
setblock 219 286 235 minecraft:light_gray_concrete
fill 219 286 243 225 286 243 minecraft:light_gray_concrete
setblock 219 286 244 minecraft:pink_terracotta
fill 219 286 253 219 286 254 minecraft:pink_terracotta
fill 219 286 255 222 287 255 minecraft:light_gray_concrete
fill 219 286 264 220 286 264 minecraft:cyan_terracotta
fill 220 286 235 221 286 235 minecraft:white_concrete
fill 220 286 244 225 286 244 minecraft:light_gray_concrete
fill 220 286 245 220 286 246 minecraft:pink_terracotta
fill 220 286 251 220 286 252 minecraft:pink_terracotta
fill 220 286 253 222 286 254 minecraft:light_gray_concrete
fill 220 286 263 221 286 263 minecraft:cyan_terracotta
fill 221 286 245 226 286 246 minecraft:light_gray_concrete
fill 221 286 247 221 287 250 minecraft:pink_terracotta
fill 221 286 251 226 286 252 minecraft:light_gray_concrete
setblock 222 286 236 minecraft:white_concrete
fill 222 286 247 226 286 250 minecraft:light_gray_concrete
setblock 222 286 262 minecraft:cyan_terracotta
fill 223 286 237 223 286 238 minecraft:white_concrete
fill 223 286 253 223 288 253 minecraft:light_gray_concrete
fill 223 286 254 223 287 256 minecraft:black_concrete
fill 223 286 260 223 286 261 minecraft:cyan_terracotta
setblock 224 286 238 minecraft:white_concrete
setblock 224 286 239 minecraft:gray_concrete
fill 224 286 253 225 288 253 minecraft:black_concrete
fill 224 286 257 225 288 257 minecraft:black_concrete
setblock 224 286 259 minecraft:cyan_terracotta
setblock 225 286 240 minecraft:white_concrete
setblock 225 286 241 minecraft:gray_concrete
setblock 225 286 258 minecraft:cyan_terracotta
fill 226 286 242 226 286 243 minecraft:white_concrete
fill 226 286 244 226 287 244 minecraft:gray_concrete
setblock 226 286 253 minecraft:light_gray_concrete
fill 226 286 254 226 288 256 minecraft:black_concrete
fill 227 286 246 227 286 250 minecraft:cyan_terracotta
setblock 227 286 251 minecraft:gray_concrete
fill 227 286 252 227 286 253 minecraft:cyan_terracotta
setblock 192 287 244 minecraft:white_concrete
fill 192 287 245 192 287 250 minecraft:cyan_terracotta
setblock 192 287 251 minecraft:gray_concrete
fill 192 287 252 192 287 253 minecraft:cyan_terracotta
fill 193 287 242 193 287 243 minecraft:white_concrete
setblock 193 287 244 minecraft:gray_concrete
fill 193 287 245 196 287 252 minecraft:light_gray_concrete
setblock 194 287 240 minecraft:white_concrete
setblock 194 287 241 minecraft:gray_concrete
fill 194 287 242 198 287 244 minecraft:light_gray_concrete
setblock 194 287 258 minecraft:cyan_terracotta
setblock 195 287 239 minecraft:gray_concrete
fill 195 287 240 200 287 241 minecraft:light_gray_concrete
fill 195 287 258 204 287 258 minecraft:light_gray_concrete
setblock 195 287 259 minecraft:cyan_terracotta
fill 196 287 237 196 287 238 minecraft:white_concrete
fill 196 287 239 201 287 239 minecraft:light_gray_concrete
fill 196 287 254 198 288 256 minecraft:light_gray_concrete
fill 196 287 259 222 287 259 minecraft:light_gray_concrete
setblock 196 287 260 minecraft:gray_concrete
fill 196 287 261 197 287 261 minecraft:cyan_terracotta
fill 197 287 236 197 287 237 minecraft:white_concrete
fill 197 287 238 202 287 238 minecraft:light_gray_concrete
fill 197 287 245 197 287 246 minecraft:light_gray_concrete
fill 197 287 247 197 287 250 minecraft:pink_terracotta
fill 197 287 251 197 287 252 minecraft:light_gray_concrete
fill 197 287 260 202 287 260 minecraft:light_gray_concrete
fill 197 287 262 198 287 262 minecraft:cyan_terracotta
setblock 198 287 236 minecraft:white_concrete
fill 198 287 237 202 287 237 minecraft:light_gray_concrete
fill 198 287 245 198 287 246 minecraft:pink_terracotta
fill 198 287 251 198 287 252 minecraft:pink_terracotta
fill 198 287 261 220 287 261 minecraft:light_gray_concrete
setblock 199 287 235 minecraft:white_concrete
fill 199 287 236 219 287 236 minecraft:light_gray_concrete
setblock 199 287 244 minecraft:pink_terracotta
fill 199 287 247 200 288 247 minecraft:white_concrete
fill 199 287 249 199 289 249 minecraft:white_concrete
fill 199 287 251 200 288 251 minecraft:white_concrete
fill 199 287 253 199 287 254 minecraft:pink_terracotta
fill 199 287 255 199 288 256 minecraft:light_gray_concrete
fill 199 287 262 219 287 262 minecraft:light_gray_concrete
setblock 199 287 263 minecraft:cyan_terracotta
fill 200 287 234 201 287 234 minecraft:white_concrete
fill 200 287 235 202 287 235 minecraft:light_gray_concrete
fill 200 287 245 200 289 246 minecraft:white_concrete
fill 200 287 252 200 289 253 minecraft:white_concrete
setblock 200 287 255 minecraft:pink_terracotta
fill 200 287 263 218 287 263 minecraft:light_gray_concrete
fill 200 287 264 201 287 264 minecraft:cyan_terracotta
fill 201 287 245 201 288 245 minecraft:white_concrete
fill 201 287 253 201 288 253 minecraft:white_concrete
fill 201 287 256 202 287 256 minecraft:pink_terracotta
fill 201 287 257 202 287 257 minecraft:light_gray_concrete
fill 202 287 233 204 287 233 minecraft:white_concrete
fill 202 287 234 203 287 234 minecraft:light_gray_concrete
fill 202 287 240 202 288 240 minecraft:light_gray_concrete
setblock 202 287 241 minecraft:pink_terracotta
fill 202 287 244 202 289 244 minecraft:white_concrete
fill 202 287 254 202 289 254 minecraft:white_concrete
fill 202 287 264 206 287 264 minecraft:light_gray_concrete
fill 202 287 265 204 287 265 minecraft:cyan_terracotta
fill 203 287 240 205 287 240 minecraft:pink_terracotta
fill 203 287 243 204 288 243 minecraft:white_concrete
fill 203 287 255 204 288 255 minecraft:white_concrete
fill 203 287 257 204 287 257 minecraft:pink_terracotta
fill 204 287 232 214 287 232 minecraft:white_concrete
fill 204 287 266 207 287 266 minecraft:cyan_terracotta
fill 205 287 233 213 287 233 minecraft:light_gray_concrete
setblock 205 287 258 minecraft:pink_terracotta
fill 205 287 260 221 287 260 minecraft:light_gray_concrete
fill 205 287 265 213 287 265 minecraft:light_gray_concrete
fill 206 287 237 220 287 238 minecraft:light_gray_concrete
setblock 206 287 239 minecraft:pink_terracotta
fill 206 287 242 206 289 242 minecraft:white_concrete
fill 206 287 256 206 289 256 minecraft:white_concrete
fill 207 287 234 216 287 235 minecraft:light_gray_concrete
fill 208 287 242 208 288 242 minecraft:white_concrete
fill 208 287 256 208 288 256 minecraft:white_concrete
fill 208 287 264 216 287 264 minecraft:light_gray_concrete
setblock 208 287 266 minecraft:gray_concrete
fill 209 287 266 213 287 266 minecraft:cyan_terracotta
fill 210 287 242 210 288 242 minecraft:white_concrete
fill 210 287 256 210 288 256 minecraft:white_concrete
fill 212 287 242 212 289 242 minecraft:white_concrete
fill 212 287 256 212 289 256 minecraft:white_concrete
setblock 213 287 239 minecraft:pink_terracotta
fill 214 287 233 216 287 233 minecraft:white_concrete
fill 214 287 239 222 287 239 minecraft:light_gray_concrete
fill 214 287 240 215 287 240 minecraft:pink_terracotta
fill 214 287 243 215 288 243 minecraft:white_concrete
fill 214 287 255 215 288 255 minecraft:white_concrete
setblock 214 287 258 minecraft:pink_terracotta
fill 214 287 265 216 287 265 minecraft:cyan_terracotta
fill 215 287 257 216 287 257 minecraft:pink_terracotta
fill 215 287 258 223 287 258 minecraft:light_gray_concrete
fill 216 287 240 223 287 240 minecraft:light_gray_concrete
fill 216 287 244 216 289 244 minecraft:white_concrete
fill 216 287 254 216 289 254 minecraft:white_concrete
fill 217 287 234 218 287 234 minecraft:white_concrete
fill 217 287 235 218 287 235 minecraft:light_gray_concrete
setblock 217 287 241 minecraft:pink_terracotta
fill 217 287 245 218 288 245 minecraft:white_concrete
fill 217 287 253 218 288 253 minecraft:white_concrete
setblock 217 287 256 minecraft:pink_terracotta
fill 217 287 257 223 287 257 minecraft:light_gray_concrete
setblock 217 287 264 minecraft:cyan_terracotta
fill 218 287 241 223 287 241 minecraft:light_gray_concrete
setblock 218 287 242 minecraft:pink_terracotta
fill 218 287 246 218 288 247 minecraft:white_concrete
fill 218 287 251 218 288 252 minecraft:white_concrete
setblock 218 287 264 minecraft:gray_concrete
setblock 219 287 235 minecraft:white_concrete
fill 219 287 242 224 287 242 minecraft:light_gray_concrete
setblock 219 287 243 minecraft:pink_terracotta
fill 219 287 247 219 290 247 minecraft:white_concrete
fill 219 287 249 219 289 249 minecraft:white_concrete
fill 219 287 251 219 290 251 minecraft:white_concrete
setblock 219 287 254 minecraft:pink_terracotta
setblock 219 287 263 minecraft:cyan_terracotta
fill 220 287 236 221 287 236 minecraft:white_concrete
fill 220 287 243 224 287 243 minecraft:light_gray_concrete
fill 220 287 244 220 287 245 minecraft:pink_terracotta
fill 220 287 252 220 287 253 minecraft:pink_terracotta
fill 220 287 254 222 287 254 minecraft:light_gray_concrete
setblock 220 287 262 minecraft:cyan_terracotta
fill 221 287 237 222 287 237 minecraft:white_concrete
setblock 221 287 238 minecraft:light_gray_concrete
fill 221 287 244 224 287 245 minecraft:light_gray_concrete
setblock 221 287 246 minecraft:pink_terracotta
setblock 221 287 251 minecraft:pink_terracotta
fill 221 287 252 222 287 253 minecraft:light_gray_concrete
fill 221 287 261 222 287 261 minecraft:cyan_terracotta
setblock 221 287 262 minecraft:gray_concrete
setblock 222 287 238 minecraft:white_concrete
fill 222 287 246 225 287 251 minecraft:light_gray_concrete
setblock 222 287 260 minecraft:cyan_terracotta
setblock 223 287 239 minecraft:white_concrete
fill 223 287 252 225 287 252 minecraft:light_gray_concrete
setblock 223 287 259 minecraft:cyan_terracotta
setblock 224 287 240 minecraft:white_concrete
setblock 224 287 241 minecraft:gray_concrete
setblock 224 287 258 minecraft:cyan_terracotta
fill 225 287 242 225 287 243 minecraft:white_concrete
setblock 225 287 244 minecraft:gray_concrete
setblock 225 287 245 minecraft:light_gray_concrete
setblock 226 287 245 minecraft:cyan_terracotta
fill 226 287 246 226 287 247 minecraft:gray_concrete
fill 226 287 248 226 287 253 minecraft:cyan_terracotta
fill 193 288 245 194 288 245 minecraft:white_concrete
fill 193 288 246 193 288 247 minecraft:cyan_terracotta
setblock 193 288 248 minecraft:gray_concrete
fill 193 288 249 193 288 252 minecraft:cyan_terracotta
fill 193 288 254 193 289 256 minecraft:black_concrete
fill 194 288 242 194 288 244 minecraft:white_concrete
setblock 194 288 246 minecraft:white_concrete
fill 194 288 247 196 288 251 minecraft:light_gray_concrete
setblock 194 288 252 minecraft:gray_concrete
fill 194 288 254 195 288 255 minecraft:black_concrete
fill 194 288 256 195 288 256 minecraft:white_concrete
fill 195 288 240 195 288 243 minecraft:white_concrete
fill 195 288 244 196 288 246 minecraft:light_gray_concrete
fill 195 288 252 196 288 253 minecraft:light_gray_concrete
fill 195 288 257 196 288 258 minecraft:cyan_terracotta
fill 196 288 239 196 288 241 minecraft:white_concrete
fill 196 288 242 198 288 243 minecraft:light_gray_concrete
fill 196 288 259 197 288 259 minecraft:cyan_terracotta
fill 197 288 238 197 288 239 minecraft:white_concrete
fill 197 288 240 200 288 241 minecraft:light_gray_concrete
fill 197 288 244 197 288 245 minecraft:light_gray_concrete
fill 197 288 246 197 288 252 minecraft:red_terracotta
setblock 197 288 253 minecraft:light_gray_concrete
fill 197 288 257 201 288 258 minecraft:light_gray_concrete
fill 197 288 260 198 288 260 minecraft:cyan_terracotta
fill 198 288 237 198 288 238 minecraft:white_concrete
fill 198 288 239 201 288 239 minecraft:light_gray_concrete
fill 198 288 244 198 288 245 minecraft:red_terracotta
fill 198 288 247 198 290 251 minecraft:white_concrete
setblock 198 288 253 minecraft:red_terracotta
fill 198 288 259 205 288 259 minecraft:light_gray_concrete
setblock 198 288 261 minecraft:gray_concrete
fill 199 288 236 199 288 237 minecraft:white_concrete
fill 199 288 238 202 288 238 minecraft:light_gray_concrete
setblock 199 288 242 minecraft:light_gray_concrete
setblock 199 288 243 minecraft:red_terracotta
fill 199 288 245 199 290 246 minecraft:white_concrete
fill 199 288 248 199 289 248 minecraft:white_concrete
fill 199 288 250 199 289 250 minecraft:white_concrete
fill 199 288 252 199 290 253 minecraft:white_concrete
setblock 199 288 254 minecraft:red_terracotta
fill 199 288 260 202 288 260 minecraft:light_gray_concrete
fill 199 288 261 199 288 262 minecraft:cyan_terracotta
fill 200 288 235 201 288 236 minecraft:white_concrete
fill 200 288 237 202 288 237 minecraft:light_gray_concrete
setblock 200 288 242 minecraft:red_terracotta
setblock 200 288 255 minecraft:red_terracotta
fill 200 288 261 218 288 261 minecraft:light_gray_concrete
setblock 200 288 262 minecraft:gray_concrete
fill 200 288 263 201 288 263 minecraft:cyan_terracotta
fill 201 288 241 202 288 241 minecraft:red_terracotta
fill 201 288 243 201 290 244 minecraft:white_concrete
setblock 201 288 246 minecraft:white_concrete
setblock 201 288 252 minecraft:white_concrete
fill 201 288 254 201 290 255 minecraft:white_concrete
setblock 201 288 256 minecraft:red_terracotta
setblock 201 288 262 minecraft:cyan_terracotta
fill 202 288 234 203 288 235 minecraft:white_concrete
fill 202 288 236 216 288 236 minecraft:light_gray_concrete
fill 202 288 242 202 289 243 minecraft:white_concrete
fill 202 288 255 202 289 256 minecraft:white_concrete
setblock 202 288 257 minecraft:red_terracotta
setblock 202 288 258 minecraft:light_gray_concrete
fill 202 288 262 216 288 262 minecraft:light_gray_concrete
setblock 202 288 263 minecraft:gray_concrete
fill 202 288 264 203 288 264 minecraft:cyan_terracotta
fill 203 288 240 204 288 240 minecraft:red_terracotta
fill 203 288 242 205 289 242 minecraft:white_concrete
fill 203 288 256 205 289 256 minecraft:white_concrete
fill 203 288 258 205 288 258 minecraft:red_terracotta
setblock 203 288 263 minecraft:cyan_terracotta
fill 204 288 234 206 288 234 minecraft:white_concrete
fill 204 288 235 214 288 235 minecraft:light_gray_concrete
fill 204 288 263 214 288 263 minecraft:light_gray_concrete
setblock 204 288 264 minecraft:gray_concrete
fill 205 288 233 213 288 233 minecraft:white_concrete
fill 205 288 239 213 288 239 minecraft:red_terracotta
fill 205 288 241 208 290 241 minecraft:white_concrete
fill 205 288 257 208 290 257 minecraft:white_concrete
fill 205 288 260 219 288 260 minecraft:light_gray_concrete
fill 205 288 264 205 288 265 minecraft:cyan_terracotta
fill 206 288 237 218 288 238 minecraft:light_gray_concrete
fill 206 288 259 212 288 259 minecraft:red_terracotta
setblock 206 288 264 minecraft:cyan_terracotta
setblock 206 288 265 minecraft:gray_concrete
fill 207 288 234 211 288 234 minecraft:light_gray_concrete
fill 207 288 265 212 288 265 minecraft:cyan_terracotta
fill 208 288 240 208 290 240 minecraft:white_concrete
fill 208 288 258 208 290 258 minecraft:white_concrete
fill 208 288 264 211 288 264 minecraft:light_gray_concrete
fill 210 288 240 210 290 241 minecraft:white_concrete
fill 210 288 257 210 290 258 minecraft:white_concrete
fill 211 288 241 213 290 241 minecraft:white_concrete
fill 211 288 257 213 290 257 minecraft:white_concrete
fill 212 288 234 216 288 234 minecraft:white_concrete
fill 212 288 264 216 288 264 minecraft:cyan_terracotta
fill 213 288 242 216 289 242 minecraft:white_concrete
fill 213 288 256 216 289 256 minecraft:white_concrete
fill 213 288 258 215 288 258 minecraft:red_terracotta
fill 213 288 259 220 288 259 minecraft:light_gray_concrete
setblock 213 288 265 minecraft:gray_concrete
fill 214 288 239 220 288 239 minecraft:light_gray_concrete
fill 214 288 240 215 288 240 minecraft:red_terracotta
fill 215 288 235 218 288 235 minecraft:white_concrete
setblock 215 288 263 minecraft:cyan_terracotta
fill 216 288 240 221 288 240 minecraft:light_gray_concrete
fill 216 288 241 217 288 241 minecraft:red_terracotta
fill 216 288 243 217 289 243 minecraft:white_concrete
fill 216 288 255 217 289 255 minecraft:white_concrete
setblock 216 288 257 minecraft:red_terracotta
fill 216 288 258 221 288 258 minecraft:light_gray_concrete
setblock 216 288 263 minecraft:gray_concrete
fill 217 288 236 219 288 236 minecraft:white_concrete
fill 217 288 244 217 290 244 minecraft:white_concrete
setblock 217 288 246 minecraft:white_concrete
setblock 217 288 252 minecraft:white_concrete
fill 217 288 254 217 290 254 minecraft:white_concrete
fill 217 288 256 218 288 256 minecraft:red_terracotta
fill 217 288 257 221 288 257 minecraft:light_gray_concrete
fill 217 288 262 218 288 263 minecraft:cyan_terracotta
fill 218 288 241 221 288 241 minecraft:light_gray_concrete
setblock 218 288 242 minecraft:red_terracotta
fill 219 288 237 220 288 237 minecraft:white_concrete
setblock 219 288 238 minecraft:light_gray_concrete
fill 219 288 242 222 288 242 minecraft:light_gray_concrete
setblock 219 288 243 minecraft:red_terracotta
fill 219 288 245 219 290 246 minecraft:white_concrete
fill 219 288 248 220 289 248 minecraft:white_concrete
fill 219 288 250 220 289 250 minecraft:white_concrete
fill 219 288 252 219 290 253 minecraft:white_concrete
setblock 219 288 255 minecraft:red_terracotta
fill 219 288 256 222 288 256 minecraft:light_gray_concrete
setblock 219 288 261 minecraft:gray_concrete
setblock 219 288 262 minecraft:cyan_terracotta
fill 220 288 238 221 288 238 minecraft:white_concrete
fill 220 288 243 222 288 243 minecraft:light_gray_concrete
setblock 220 288 244 minecraft:red_terracotta
fill 220 288 247 220 290 247 minecraft:white_concrete
fill 220 288 249 220 290 249 minecraft:white_concrete
fill 220 288 251 220 290 251 minecraft:white_concrete
fill 220 288 253 220 288 254 minecraft:red_terracotta
fill 220 288 255 222 288 255 minecraft:light_gray_concrete
fill 220 288 260 220 288 261 minecraft:cyan_terracotta
fill 221 288 239 222 288 239 minecraft:white_concrete
fill 221 288 244 223 288 244 minecraft:light_gray_concrete
fill 221 288 245 221 288 248 minecraft:red_terracotta
fill 221 288 250 221 288 252 minecraft:red_terracotta
fill 221 288 253 222 288 254 minecraft:light_gray_concrete
fill 221 288 259 221 288 260 minecraft:cyan_terracotta
fill 222 288 240 223 288 241 minecraft:white_concrete
fill 222 288 245 223 288 248 minecraft:light_gray_concrete
setblock 222 288 249 minecraft:red_terracotta
fill 222 288 250 223 288 252 minecraft:light_gray_concrete
fill 222 288 257 223 288 258 minecraft:cyan_terracotta
setblock 222 288 259 minecraft:gray_concrete
fill 223 288 242 224 288 243 minecraft:white_concrete
fill 223 288 249 224 288 249 minecraft:light_gray_concrete
fill 223 288 254 225 288 255 minecraft:black_concrete
fill 223 288 256 224 288 256 minecraft:white_concrete
fill 224 288 244 224 288 246 minecraft:white_concrete
fill 224 288 247 224 288 248 minecraft:light_gray_concrete
fill 224 288 250 224 288 251 minecraft:light_gray_concrete
fill 224 288 252 225 288 252 minecraft:cyan_terracotta
setblock 225 288 245 minecraft:white_concrete
fill 225 288 246 225 288 249 minecraft:cyan_terracotta
setblock 225 288 250 minecraft:gray_concrete
setblock 225 288 251 minecraft:cyan_terracotta
fill 225 288 256 225 289 256 minecraft:black_concrete
fill 188 289 228 188 290 231 minecraft:blue_concrete
fill 188 289 232 188 289 233 minecraft:cyan_concrete
fill 188 289 234 188 289 236 minecraft:blue_concrete
fill 188 289 237 188 289 238 minecraft:cyan_concrete
fill 188 289 239 188 289 240 minecraft:blue_concrete
setblock 188 289 241 minecraft:cyan_concrete
fill 188 289 242 188 289 270 minecraft:blue_concrete
setblock 189 289 228 minecraft:white_stained_glass
fill 189 289 270 189 292 270 minecraft:blue_concrete
fill 190 289 228 195 289 228 minecraft:blue_concrete
setblock 190 289 270 minecraft:cyan_concrete
fill 191 289 270 191 294 270 minecraft:blue_concrete
setblock 192 289 270 minecraft:cyan_concrete
fill 193 289 270 195 292 270 minecraft:blue_concrete
fill 194 289 247 194 289 251 minecraft:cyan_terracotta
fill 194 289 254 194 289 256 minecraft:black_concrete
fill 195 289 244 196 289 246 minecraft:white_concrete
fill 195 289 247 195 289 248 minecraft:cyan_terracotta
setblock 195 289 249 minecraft:gray_concrete
fill 195 289 250 195 289 254 minecraft:cyan_terracotta
setblock 196 289 228 minecraft:cyan_concrete
fill 196 289 242 200 289 243 minecraft:white_concrete
fill 196 289 247 196 289 248 minecraft:pink_terracotta
fill 196 289 249 197 290 249 minecraft:white_concrete
setblock 196 289 250 minecraft:pink_terracotta
fill 196 289 251 196 289 252 minecraft:cyan_terracotta
setblock 196 289 253 minecraft:gray_concrete
fill 196 289 254 197 289 256 minecraft:cyan_terracotta
setblock 196 289 270 minecraft:cyan_concrete
fill 197 289 228 202 290 228 minecraft:blue_concrete
fill 197 289 240 200 289 241 minecraft:white_concrete
fill 197 289 244 200 290 244 minecraft:white_concrete
setblock 197 289 245 minecraft:pink_terracotta
fill 197 289 246 197 290 248 minecraft:white_concrete
fill 197 289 250 197 290 252 minecraft:white_concrete
setblock 197 289 253 minecraft:pink_terracotta
setblock 197 289 257 minecraft:gray_concrete
fill 197 289 258 198 289 258 minecraft:cyan_terracotta
fill 197 289 270 197 293 270 minecraft:blue_concrete
fill 198 289 239 203 289 239 minecraft:white_concrete
fill 198 289 245 198 290 246 minecraft:white_concrete
fill 198 289 252 198 290 254 minecraft:white_concrete
fill 198 289 255 198 289 257 minecraft:cyan_terracotta
fill 198 289 259 200 289 259 minecraft:cyan_terracotta
setblock 198 289 270 minecraft:cyan_concrete
fill 199 289 238 219 289 238 minecraft:white_concrete
fill 199 289 247 199 290 247 minecraft:white_concrete
fill 199 289 251 199 290 251 minecraft:white_concrete
fill 199 289 254 200 290 255 minecraft:white_concrete
fill 199 289 256 199 289 257 minecraft:cyan_terracotta
setblock 199 289 258 minecraft:gray_concrete
fill 199 289 260 202 289 260 minecraft:cyan_terracotta
fill 199 289 270 199 291 270 minecraft:blue_concrete
fill 200 289 237 218 289 237 minecraft:white_concrete
fill 200 289 256 201 290 256 minecraft:white_concrete
fill 200 289 257 200 289 258 minecraft:cyan_terracotta
fill 200 289 261 204 289 261 minecraft:cyan_terracotta
setblock 200 289 270 minecraft:light_blue_terracotta
fill 201 289 240 201 290 240 minecraft:white_concrete
setblock 201 289 241 minecraft:pink_terracotta
fill 201 289 242 201 290 242 minecraft:white_concrete
setblock 201 289 257 minecraft:pink_terracotta
setblock 201 289 258 minecraft:cyan_terracotta
setblock 201 289 259 minecraft:gray_concrete
fill 201 289 270 210 289 270 minecraft:blue_concrete
fill 202 289 236 216 289 236 minecraft:white_concrete
fill 202 289 240 203 289 240 minecraft:pink_terracotta
fill 202 289 241 204 290 241 minecraft:white_concrete
fill 202 289 257 204 290 257 minecraft:white_concrete
fill 202 289 258 203 289 258 minecraft:pink_terracotta
fill 202 289 259 204 289 259 minecraft:cyan_terracotta
fill 202 289 262 204 289 262 minecraft:cyan_terracotta
setblock 203 289 228 minecraft:cyan_concrete
setblock 203 289 243 minecraft:white_concrete
setblock 203 289 255 minecraft:white_concrete
setblock 203 289 260 minecraft:gray_concrete
setblock 204 289 228 minecraft:light_blue_terracotta
fill 204 289 235 214 289 235 minecraft:white_concrete
setblock 204 289 239 minecraft:pink_terracotta
fill 204 289 240 207 290 240 minecraft:white_concrete
fill 204 289 258 207 290 258 minecraft:white_concrete
fill 204 289 260 209 289 260 minecraft:cyan_terracotta
fill 204 289 263 208 289 263 minecraft:cyan_terracotta
fill 205 289 228 211 289 228 minecraft:blue_concrete
fill 205 289 239 205 290 239 minecraft:white_concrete
fill 205 289 259 205 290 259 minecraft:white_concrete
fill 205 289 261 205 289 262 minecraft:black_concrete
setblock 205 289 268 minecraft:white_stained_glass
setblock 206 289 239 minecraft:pink_terracotta
setblock 206 289 259 minecraft:pink_terracotta
fill 206 289 261 206 289 262 minecraft:cyan_terracotta
fill 207 289 234 211 289 234 minecraft:white_concrete
fill 207 289 239 208 290 239 minecraft:white_concrete
fill 207 289 259 208 290 259 minecraft:white_concrete
fill 207 289 261 211 289 261 minecraft:cyan_terracotta
setblock 207 289 262 minecraft:gray_concrete
fill 207 289 264 210 289 264 minecraft:cyan_terracotta
fill 208 289 262 212 289 262 minecraft:cyan_terracotta
setblock 209 289 239 minecraft:pink_terracotta
fill 209 289 240 209 290 240 minecraft:white_concrete
fill 209 289 258 209 290 258 minecraft:white_concrete
setblock 209 289 259 minecraft:pink_terracotta
setblock 209 289 263 minecraft:gray_concrete
fill 210 289 239 211 290 239 minecraft:white_concrete
fill 210 289 259 211 290 259 minecraft:white_concrete
setblock 210 289 260 minecraft:gray_concrete
fill 210 289 263 214 289 263 minecraft:cyan_terracotta
fill 211 289 240 214 290 240 minecraft:white_concrete
fill 211 289 258 214 290 258 minecraft:white_concrete
fill 211 289 260 216 289 260 minecraft:cyan_terracotta
setblock 211 289 264 minecraft:gray_concrete
fill 211 289 270 212 289 270 minecraft:cyan_concrete
setblock 212 289 228 minecraft:light_blue_terracotta
setblock 212 289 239 minecraft:pink_terracotta
setblock 212 289 259 minecraft:pink_terracotta
setblock 212 289 261 minecraft:gray_concrete
setblock 213 289 228 minecraft:white_stained_glass
fill 213 289 239 213 290 239 minecraft:white_concrete
fill 213 289 259 213 290 259 minecraft:white_concrete
fill 213 289 261 213 289 262 minecraft:black_concrete
fill 213 289 270 213 290 270 minecraft:blue_concrete
fill 214 289 228 216 290 228 minecraft:blue_concrete
setblock 214 289 239 minecraft:pink_terracotta
fill 214 289 241 216 290 241 minecraft:white_concrete
fill 214 289 257 216 290 257 minecraft:white_concrete
setblock 214 289 259 minecraft:cyan_terracotta
fill 214 289 261 218 289 261 minecraft:cyan_terracotta
setblock 214 289 262 minecraft:gray_concrete
setblock 214 289 270 minecraft:white_stained_glass
fill 215 289 239 220 289 239 minecraft:white_concrete
fill 215 289 240 216 289 240 minecraft:pink_terracotta
setblock 215 289 243 minecraft:white_concrete
setblock 215 289 255 minecraft:white_concrete
fill 215 289 258 216 289 258 minecraft:pink_terracotta
setblock 215 289 259 minecraft:gray_concrete
fill 215 289 262 216 289 262 minecraft:cyan_terracotta
fill 215 289 270 221 290 270 minecraft:blue_concrete
fill 216 289 259 220 289 259 minecraft:cyan_terracotta
fill 217 289 228 218 289 228 minecraft:cyan_concrete
fill 217 289 240 221 289 240 minecraft:white_concrete
setblock 217 289 241 minecraft:pink_terracotta
fill 217 289 242 222 289 242 minecraft:white_concrete
fill 217 289 256 218 290 256 minecraft:white_concrete
setblock 217 289 257 minecraft:pink_terracotta
fill 217 289 258 219 289 258 minecraft:cyan_terracotta
setblock 217 289 260 minecraft:gray_concrete
fill 218 289 241 221 289 241 minecraft:white_concrete
fill 218 289 243 218 289 246 minecraft:white_concrete
fill 218 289 252 218 289 255 minecraft:white_concrete
setblock 218 289 257 minecraft:gray_concrete
fill 218 289 260 219 289 260 minecraft:cyan_terracotta
fill 219 289 228 230 289 228 minecraft:blue_concrete
fill 219 289 243 222 289 244 minecraft:white_concrete
fill 219 289 254 219 290 255 minecraft:white_concrete
fill 219 289 256 221 289 257 minecraft:cyan_terracotta
fill 220 289 245 220 290 246 minecraft:white_concrete
fill 220 289 252 220 290 254 minecraft:white_concrete
setblock 220 289 255 minecraft:cyan_terracotta
setblock 220 289 258 minecraft:gray_concrete
setblock 221 289 245 minecraft:pink_terracotta
fill 221 289 246 221 290 252 minecraft:white_concrete
setblock 221 289 253 minecraft:pink_terracotta
fill 221 289 254 223 289 254 minecraft:cyan_terracotta
setblock 221 289 255 minecraft:gray_concrete
setblock 221 289 258 minecraft:cyan_terracotta
fill 222 289 245 223 289 246 minecraft:white_concrete
fill 222 289 247 222 289 248 minecraft:pink_terracotta
fill 222 289 249 222 290 249 minecraft:white_concrete
fill 222 289 250 222 289 251 minecraft:pink_terracotta
setblock 222 289 252 minecraft:gray_concrete
fill 222 289 253 223 289 253 minecraft:cyan_terracotta
fill 222 289 255 222 289 256 minecraft:cyan_terracotta
setblock 222 289 270 minecraft:cyan_concrete
setblock 223 289 244 minecraft:white_concrete
fill 223 289 247 224 289 248 minecraft:cyan_terracotta
setblock 223 289 249 minecraft:gray_concrete
fill 223 289 250 223 289 252 minecraft:cyan_terracotta
fill 223 289 270 226 292 270 minecraft:blue_concrete
fill 224 289 249 224 289 251 minecraft:cyan_terracotta
fill 224 289 254 224 289 256 minecraft:black_concrete
fill 225 289 254 225 289 255 minecraft:black_concrete
setblock 227 289 270 minecraft:light_blue_wool
fill 228 289 270 230 292 270 minecraft:blue_concrete
fill 230 289 229 230 292 229 minecraft:blue_concrete
setblock 230 289 230 minecraft:cyan_concrete
fill 230 289 231 230 290 231 minecraft:blue_concrete
setblock 230 289 232 minecraft:light_blue_wool
fill 230 289 233 230 289 240 minecraft:blue_concrete
setblock 230 289 241 minecraft:light_blue_wool
fill 230 289 242 230 292 243 minecraft:blue_concrete
setblock 230 289 244 minecraft:light_blue_terracotta
fill 230 289 245 230 291 248 minecraft:blue_concrete
setblock 230 289 249 minecraft:cyan_concrete
fill 230 289 250 230 292 252 minecraft:blue_concrete
setblock 230 289 253 minecraft:cyan_concrete
fill 230 289 254 230 294 254 minecraft:blue_concrete
setblock 230 289 255 minecraft:cyan_concrete
fill 230 289 256 230 289 269 minecraft:blue_concrete
fill 188 290 232 188 290 233 minecraft:blue_concrete
setblock 188 290 234 minecraft:cyan_concrete
fill 188 290 235 188 292 239 minecraft:blue_concrete
setblock 188 290 240 minecraft:cyan_concrete
fill 188 290 241 188 290 244 minecraft:blue_concrete
setblock 188 290 245 minecraft:cyan_concrete
fill 188 290 246 188 291 247 minecraft:blue_concrete
setblock 188 290 248 minecraft:cyan_concrete
fill 188 290 249 188 290 253 minecraft:blue_concrete
setblock 188 290 254 minecraft:light_blue_wool
setblock 188 290 255 minecraft:blue_concrete
setblock 188 290 256 minecraft:cyan_concrete
fill 188 290 257 188 290 258 minecraft:blue_concrete
setblock 188 290 259 minecraft:cyan_concrete
setblock 188 290 260 minecraft:blue_concrete
setblock 188 290 261 minecraft:light_blue_terracotta
fill 188 290 262 188 292 262 minecraft:blue_concrete
fill 188 290 263 188 291 263 minecraft:white_stained_glass
fill 188 290 264 188 290 265 minecraft:blue_concrete
fill 188 290 266 188 290 267 minecraft:light_blue_terracotta
fill 188 290 268 188 292 270 minecraft:blue_concrete
fill 189 290 228 194 292 228 minecraft:blue_concrete
setblock 190 290 234 minecraft:white_stained_glass
fill 190 290 270 190 292 270 minecraft:blue_concrete
setblock 191 290 231 minecraft:light[level=15]
setblock 191 290 238 minecraft:light[level=15]
setblock 191 290 245 minecraft:light[level=15]
setblock 191 290 252 minecraft:light[level=15]
setblock 191 290 259 minecraft:light[level=15]
setblock 191 290 266 minecraft:light[level=15]
setblock 192 290 270 minecraft:light_blue_wool
setblock 195 290 228 minecraft:cyan_concrete
fill 196 290 228 196 292 228 minecraft:blue_concrete
fill 196 290 246 196 290 248 minecraft:white_concrete
fill 196 290 250 196 290 252 minecraft:white_concrete
setblock 196 290 270 minecraft:blue_concrete
setblock 197 290 245 minecraft:white_concrete
fill 197 290 253 197 290 254 minecraft:white_concrete
setblock 198 290 231 minecraft:light[level=15]
setblock 198 290 238 minecraft:light[level=15]
fill 198 290 243 200 290 243 minecraft:white_concrete
setblock 198 290 255 minecraft:white_concrete
setblock 198 290 259 minecraft:light[level=15]
setblock 198 290 266 minecraft:light[level=15]
fill 198 290 270 198 292 270 minecraft:blue_concrete
fill 199 290 242 200 290 242 minecraft:white_concrete
setblock 199 290 256 minecraft:white_concrete
fill 200 290 241 201 290 241 minecraft:white_concrete
setblock 200 290 245 minecraft:white_concrete
setblock 200 290 253 minecraft:white_concrete
fill 200 290 257 201 290 257 minecraft:white_concrete
fill 200 290 270 202 290 270 minecraft:blue_concrete
fill 201 290 258 203 290 258 minecraft:white_concrete
fill 202 290 240 203 290 240 minecraft:white_concrete
fill 202 290 242 203 290 242 minecraft:white_concrete
fill 202 290 256 203 290 256 minecraft:white_concrete
fill 203 290 228 208 291 228 minecraft:blue_concrete
setblock 203 290 270 minecraft:white_stained_glass
setblock 204 290 239 minecraft:white_concrete
setblock 204 290 259 minecraft:white_concrete
fill 204 290 270 204 292 270 minecraft:blue_concrete
setblock 205 290 231 minecraft:light[level=15]
setblock 205 290 238 minecraft:light[level=15]
setblock 205 290 245 minecraft:light[level=15]
setblock 205 290 252 minecraft:light[level=15]
setblock 205 290 266 minecraft:light[level=15]
setblock 205 290 270 minecraft:cyan_concrete
setblock 206 290 239 minecraft:white_concrete
setblock 206 290 259 minecraft:white_concrete
fill 206 290 270 212 290 270 minecraft:blue_concrete
setblock 207 290 229 minecraft:white_stained_glass
fill 207 290 238 208 290 238 minecraft:white_concrete
fill 207 290 260 208 290 260 minecraft:white_concrete
setblock 209 290 228 minecraft:light_blue_terracotta
setblock 209 290 239 minecraft:white_concrete
setblock 209 290 259 minecraft:white_concrete
fill 210 290 228 212 291 228 minecraft:blue_concrete
fill 210 290 238 211 290 238 minecraft:white_concrete
fill 210 290 260 211 290 260 minecraft:white_concrete
setblock 212 290 231 minecraft:light[level=15]
setblock 212 290 238 minecraft:light[level=15]
setblock 212 290 239 minecraft:white_concrete
setblock 212 290 245 minecraft:light[level=15]
setblock 212 290 252 minecraft:light[level=15]
setblock 212 290 259 minecraft:white_concrete
setblock 212 290 266 minecraft:light[level=15]
fill 213 290 228 213 291 228 minecraft:cyan_concrete
setblock 214 290 239 minecraft:white_concrete
setblock 214 290 259 minecraft:white_concrete
fill 214 290 270 214 291 270 minecraft:blue_concrete
fill 215 290 240 217 290 240 minecraft:white_concrete
fill 215 290 242 219 290 242 minecraft:white_concrete
fill 215 290 256 216 290 256 minecraft:white_concrete
fill 215 290 258 217 290 258 minecraft:white_concrete
fill 217 290 228 226 290 228 minecraft:blue_concrete
fill 217 290 241 218 290 241 minecraft:white_concrete
fill 217 290 243 220 290 243 minecraft:white_concrete
fill 217 290 255 218 290 255 minecraft:white_concrete
fill 217 290 257 218 290 257 minecraft:white_concrete
fill 218 290 244 218 290 245 minecraft:white_concrete
fill 218 290 253 218 290 254 minecraft:white_concrete
setblock 219 290 231 minecraft:light[level=15]
setblock 219 290 238 minecraft:light[level=15]
fill 219 290 244 221 290 244 minecraft:white_concrete
setblock 219 290 256 minecraft:white_concrete
setblock 219 290 259 minecraft:light[level=15]
setblock 219 290 266 minecraft:light[level=15]
setblock 220 290 248 minecraft:white_concrete
setblock 220 290 250 minecraft:white_concrete
setblock 220 290 255 minecraft:white_concrete
setblock 221 290 245 minecraft:white_concrete
fill 221 290 253 221 290 254 minecraft:white_concrete
fill 222 290 246 222 290 248 minecraft:white_concrete
fill 222 290 250 222 290 252 minecraft:white_concrete
fill 222 290 270 222 292 270 minecraft:blue_concrete
setblock 226 290 231 minecraft:light[level=15]
setblock 226 290 238 minecraft:light[level=15]
setblock 226 290 245 minecraft:light[level=15]
setblock 226 290 252 minecraft:light[level=15]
setblock 226 290 259 minecraft:light[level=15]
setblock 226 290 266 minecraft:light[level=15]
setblock 227 290 228 minecraft:cyan_concrete
fill 227 290 270 227 292 270 minecraft:blue_concrete
setblock 228 290 228 minecraft:light_blue_terracotta
setblock 228 290 259 minecraft:white_stained_glass
fill 229 290 228 230 292 228 minecraft:blue_concrete
fill 230 290 230 230 292 230 minecraft:blue_concrete
fill 230 290 232 230 290 233 minecraft:blue_concrete
setblock 230 290 234 minecraft:light_blue_wool
fill 230 290 235 230 290 239 minecraft:blue_concrete
setblock 230 290 240 minecraft:cyan_concrete
setblock 230 290 241 minecraft:light_blue_terracotta
setblock 230 290 244 minecraft:cyan_concrete
setblock 230 290 249 minecraft:light_blue_wool
fill 230 290 253 230 292 253 minecraft:blue_concrete
fill 230 290 255 230 291 260 minecraft:blue_concrete
setblock 230 290 261 minecraft:cyan_concrete
fill 230 290 262 230 291 264 minecraft:blue_concrete
setblock 230 290 265 minecraft:cyan_concrete
fill 230 290 266 230 290 268 minecraft:blue_concrete
fill 230 290 269 230 291 269 minecraft:cyan_concrete
fill 188 291 228 188 292 230 minecraft:blue_concrete
fill 188 291 231 188 291 232 minecraft:cyan_concrete
fill 188 291 233 188 292 234 minecraft:blue_concrete
fill 188 291 240 188 291 241 minecraft:blue_concrete
fill 188 291 242 188 292 242 minecraft:light_blue_terracotta
setblock 188 291 243 minecraft:light_blue_wool
fill 188 291 244 188 292 245 minecraft:blue_concrete
fill 188 291 248 188 292 248 minecraft:blue_concrete
setblock 188 291 249 minecraft:cyan_concrete
fill 188 291 250 188 292 251 minecraft:blue_concrete
setblock 188 291 252 minecraft:cyan_concrete
fill 188 291 253 188 291 254 minecraft:blue_concrete
setblock 188 291 255 minecraft:cyan_concrete
fill 188 291 256 188 292 257 minecraft:blue_concrete
setblock 188 291 258 minecraft:light_blue_terracotta
setblock 188 291 259 minecraft:light_blue_wool
setblock 188 291 260 minecraft:white_stained_glass
fill 188 291 261 188 292 261 minecraft:blue_concrete
setblock 188 291 264 minecraft:light_blue_terracotta
fill 188 291 265 188 292 265 minecraft:blue_concrete
setblock 188 291 266 minecraft:cyan_concrete
fill 188 291 267 188 292 267 minecraft:blue_concrete
fill 192 291 270 192 292 270 minecraft:blue_concrete
fill 195 291 228 195 292 228 minecraft:blue_concrete
setblock 196 291 268 minecraft:white_stained_glass
setblock 196 291 270 minecraft:cyan_concrete
fill 197 291 228 198 292 228 minecraft:blue_concrete
setblock 199 291 228 minecraft:light_blue_terracotta
fill 200 291 228 201 292 228 minecraft:blue_concrete
fill 200 291 270 201 292 270 minecraft:blue_concrete
setblock 202 291 228 minecraft:cyan_concrete
setblock 202 291 270 minecraft:cyan_concrete
setblock 203 291 270 minecraft:light_blue_terracotta
setblock 205 291 268 minecraft:white_stained_glass
fill 205 291 270 210 292 270 minecraft:blue_concrete
setblock 209 291 228 minecraft:cyan_concrete
setblock 211 291 270 minecraft:white_stained_glass
fill 212 291 270 212 292 270 minecraft:blue_concrete
setblock 213 291 270 minecraft:cyan_concrete
fill 214 291 228 214 292 228 minecraft:light_blue_wool
fill 215 291 228 221 292 228 minecraft:blue_concrete
fill 215 291 270 218 291 270 minecraft:blue_concrete
setblock 219 291 270 minecraft:white_stained_glass
fill 220 291 270 221 292 270 minecraft:blue_concrete
setblock 222 291 228 minecraft:light_blue_terracotta
fill 223 291 228 225 292 228 minecraft:blue_concrete
setblock 226 291 228 minecraft:white_stained_glass
fill 227 291 228 228 292 228 minecraft:blue_concrete
setblock 230 291 231 minecraft:cyan_concrete
fill 230 291 232 230 292 232 minecraft:blue_concrete
setblock 230 291 233 minecraft:light_blue_wool
fill 230 291 234 230 292 234 minecraft:blue_concrete
setblock 230 291 235 minecraft:light_blue_terracotta
fill 230 291 236 230 292 238 minecraft:blue_concrete
setblock 230 291 239 minecraft:light_blue_terracotta
fill 230 291 240 230 292 240 minecraft:blue_concrete
setblock 230 291 241 minecraft:cyan_concrete
fill 230 291 244 230 292 244 minecraft:blue_concrete
setblock 230 291 249 minecraft:cyan_concrete
fill 230 291 261 230 293 261 minecraft:blue_concrete
fill 230 291 265 230 292 267 minecraft:blue_concrete
setblock 230 291 268 minecraft:light_blue_terracotta
fill 188 292 231 188 292 232 minecraft:blue_concrete
setblock 188 292 240 minecraft:blue_concrete
setblock 188 292 241 minecraft:light_blue_terracotta
setblock 188 292 243 minecraft:white_stained_glass
fill 188 292 246 188 293 246 minecraft:blue_concrete
setblock 188 292 247 minecraft:white_stained_glass
setblock 188 292 249 minecraft:blue_concrete
fill 188 292 252 188 292 253 minecraft:blue_concrete
setblock 188 292 254 minecraft:light_blue_wool
setblock 188 292 255 minecraft:blue_concrete
setblock 188 292 258 minecraft:blue_concrete
setblock 188 292 259 minecraft:light_blue_terracotta
setblock 188 292 260 minecraft:blue_concrete
fill 188 292 263 188 292 264 minecraft:blue_concrete
setblock 188 292 266 minecraft:blue_concrete
fill 189 292 235 190 292 235 minecraft:white_stained_glass
setblock 190 292 255 minecraft:orange_concrete
setblock 190 292 256 minecraft:white_concrete
setblock 196 292 270 minecraft:blue_concrete
setblock 199 292 228 minecraft:blue_concrete
setblock 199 292 270 minecraft:white_stained_glass
fill 202 292 228 207 292 228 minecraft:blue_concrete
fill 202 292 270 203 292 270 minecraft:blue_concrete
setblock 207 292 229 minecraft:white_stained_glass
setblock 208 292 228 minecraft:light_blue_wool
fill 209 292 228 210 292 228 minecraft:blue_concrete
fill 211 292 228 212 292 228 minecraft:light_blue_terracotta
setblock 211 292 270 minecraft:light_blue_wool
setblock 213 292 228 minecraft:blue_concrete
setblock 213 292 270 minecraft:blue_concrete
setblock 214 292 270 minecraft:white_stained_glass
fill 215 292 270 216 292 270 minecraft:blue_concrete
setblock 217 292 270 minecraft:light_blue_wool
fill 218 292 270 219 292 270 minecraft:blue_concrete
setblock 222 292 228 minecraft:blue_concrete
setblock 226 292 228 minecraft:blue_concrete
setblock 228 292 260 minecraft:white_stained_glass
setblock 230 292 231 minecraft:blue_concrete
setblock 230 292 233 minecraft:blue_concrete
setblock 230 292 235 minecraft:blue_concrete
setblock 230 292 239 minecraft:blue_concrete
setblock 230 292 241 minecraft:blue_concrete
setblock 230 292 245 minecraft:blue_concrete
setblock 230 292 246 minecraft:white_stained_glass
fill 230 292 247 230 292 249 minecraft:blue_concrete
fill 230 292 255 230 292 257 minecraft:blue_concrete
setblock 230 292 258 minecraft:light_blue_terracotta
fill 230 292 259 230 292 260 minecraft:blue_concrete
setblock 230 292 262 minecraft:white_stained_glass
fill 230 292 263 230 292 264 minecraft:blue_concrete
fill 230 292 268 230 292 269 minecraft:blue_concrete
fill 188 293 228 188 293 237 minecraft:cyan_concrete
setblock 188 293 238 minecraft:blue_concrete
fill 188 293 239 188 293 241 minecraft:cyan_concrete
setblock 188 293 242 minecraft:blue_concrete
fill 188 293 243 188 293 245 minecraft:cyan_concrete
fill 188 293 247 188 293 251 minecraft:cyan_concrete
setblock 188 293 252 minecraft:white_stained_glass
setblock 188 293 253 minecraft:blue_concrete
fill 188 293 254 188 293 265 minecraft:cyan_concrete
setblock 188 293 266 minecraft:light_blue_wool
fill 188 293 267 188 294 270 minecraft:cyan_concrete
fill 189 293 228 193 293 228 minecraft:cyan_concrete
fill 189 293 270 190 293 270 minecraft:cyan_concrete
setblock 190 293 261 minecraft:orange_concrete
setblock 190 293 262 minecraft:white_concrete
fill 192 293 270 196 294 270 minecraft:cyan_concrete
setblock 194 293 228 minecraft:blue_concrete
fill 195 293 228 196 294 228 minecraft:cyan_concrete
setblock 196 293 268 minecraft:white_stained_glass
setblock 197 293 228 minecraft:light_blue_wool
fill 198 293 228 200 294 228 minecraft:cyan_concrete
fill 198 293 270 198 298 270 minecraft:cyan_concrete
setblock 199 293 270 minecraft:light_blue_terracotta
fill 200 293 270 202 297 270 minecraft:cyan_concrete
setblock 201 293 228 minecraft:blue_concrete
fill 202 293 228 202 300 228 minecraft:cyan_concrete
setblock 203 293 228 minecraft:white_stained_glass
setblock 203 293 270 minecraft:light_blue_wool
setblock 204 293 228 minecraft:light_blue_wool
fill 204 293 270 205 300 270 minecraft:cyan_concrete
fill 205 293 228 205 294 228 minecraft:cyan_concrete
setblock 206 293 228 minecraft:light_blue_terracotta
setblock 206 293 268 minecraft:white_stained_glass
setblock 206 293 270 minecraft:light_blue_terracotta
fill 207 293 228 222 293 228 minecraft:cyan_concrete
fill 207 293 270 215 293 270 minecraft:cyan_concrete
setblock 214 293 268 minecraft:white_stained_glass
setblock 216 293 270 minecraft:blue_concrete
fill 217 293 270 225 293 270 minecraft:cyan_concrete
setblock 218 293 230 minecraft:lime_concrete
setblock 219 293 230 minecraft:white_concrete
setblock 223 293 228 minecraft:blue_concrete
fill 224 293 228 226 300 228 minecraft:cyan_concrete
setblock 226 293 270 minecraft:blue_concrete
setblock 227 293 228 minecraft:light_blue_terracotta
fill 227 293 270 230 293 270 minecraft:cyan_concrete
fill 228 293 228 229 300 228 minecraft:cyan_concrete
fill 230 293 228 230 294 228 minecraft:blue_concrete
fill 230 293 229 230 293 236 minecraft:cyan_concrete
setblock 230 293 237 minecraft:light_blue_wool
fill 230 293 238 230 293 249 minecraft:cyan_concrete
fill 230 293 250 230 294 250 minecraft:blue_concrete
fill 230 293 251 230 297 251 minecraft:cyan_concrete
setblock 230 293 252 minecraft:blue_concrete
fill 230 293 253 230 296 253 minecraft:cyan_concrete
fill 230 293 255 230 294 257 minecraft:cyan_concrete
fill 230 293 258 230 294 258 minecraft:blue_concrete
fill 230 293 259 230 300 260 minecraft:cyan_concrete
fill 230 293 262 230 297 263 minecraft:cyan_concrete
setblock 230 293 264 minecraft:blue_concrete
fill 230 293 265 230 294 267 minecraft:cyan_concrete
setblock 230 293 268 minecraft:white_stained_glass
fill 230 293 269 230 300 269 minecraft:cyan_concrete
fill 188 294 228 191 294 228 minecraft:cyan_concrete
setblock 188 294 229 minecraft:white_stained_glass
fill 188 294 230 188 295 238 minecraft:cyan_concrete
fill 188 294 239 188 294 240 minecraft:white_stained_glass
fill 188 294 241 188 297 241 minecraft:cyan_concrete
setblock 188 294 242 minecraft:light_blue_terracotta
setblock 188 294 243 minecraft:cyan_concrete
fill 188 294 244 188 294 245 minecraft:white_stained_glass
setblock 188 294 246 minecraft:light_blue_terracotta
fill 188 294 247 188 297 248 minecraft:cyan_concrete
fill 188 294 249 188 294 250 minecraft:blue_concrete
fill 188 294 251 188 294 261 minecraft:cyan_concrete
setblock 188 294 262 minecraft:light_blue_terracotta
fill 188 294 263 188 297 264 minecraft:cyan_concrete
setblock 188 294 265 minecraft:blue_concrete
fill 188 294 266 188 300 266 minecraft:cyan_concrete
fill 189 294 236 190 294 236 minecraft:white_stained_glass
setblock 189 294 270 minecraft:white_stained_glass
setblock 190 294 270 minecraft:light_blue_terracotta
fill 192 294 228 193 294 228 minecraft:blue_concrete
fill 194 294 228 194 298 228 minecraft:cyan_concrete
fill 197 294 228 197 300 228 minecraft:cyan_concrete
fill 197 294 270 197 300 270 minecraft:cyan_concrete
fill 199 294 270 199 297 270 minecraft:cyan_concrete
setblock 201 294 228 minecraft:cyan_concrete
fill 203 294 228 204 294 228 minecraft:cyan_concrete
fill 203 294 270 203 300 270 minecraft:cyan_concrete
setblock 205 294 229 minecraft:orange_concrete
fill 206 294 228 214 294 228 minecraft:cyan_concrete
setblock 206 294 229 minecraft:white_concrete
fill 206 294 270 207 294 270 minecraft:cyan_concrete
setblock 207 294 229 minecraft:white_stained_glass
setblock 207 294 230 minecraft:orange_concrete
setblock 208 294 230 minecraft:white_concrete
setblock 208 294 270 minecraft:blue_concrete
fill 209 294 270 217 295 270 minecraft:cyan_concrete
setblock 215 294 228 minecraft:blue_concrete
fill 216 294 228 220 295 228 minecraft:cyan_concrete
setblock 217 294 229 minecraft:lime_concrete
setblock 218 294 229 minecraft:white_concrete
setblock 218 294 270 minecraft:blue_concrete
fill 219 294 270 221 296 270 minecraft:cyan_concrete
fill 221 294 228 221 295 228 minecraft:light_blue_terracotta
fill 222 294 228 223 294 228 minecraft:cyan_concrete
setblock 222 294 270 minecraft:light_blue_terracotta
fill 223 294 270 223 300 270 minecraft:cyan_concrete
setblock 224 294 270 minecraft:blue_concrete
fill 225 294 270 226 300 270 minecraft:cyan_concrete
fill 227 294 228 227 300 228 minecraft:cyan_concrete
fill 227 294 270 227 295 270 minecraft:blue_concrete
setblock 228 294 261 minecraft:white_stained_glass
fill 228 294 270 229 300 270 minecraft:cyan_concrete
setblock 229 294 244 minecraft:white_stained_glass
fill 230 294 229 230 300 231 minecraft:cyan_concrete
setblock 230 294 232 minecraft:white_stained_glass
fill 230 294 233 230 294 235 minecraft:cyan_concrete
fill 230 294 236 230 294 237 minecraft:blue_concrete
setblock 230 294 238 minecraft:cyan_concrete
setblock 230 294 239 minecraft:blue_concrete
fill 230 294 240 230 294 241 minecraft:cyan_concrete
setblock 230 294 242 minecraft:light_blue_wool
fill 230 294 243 230 295 244 minecraft:cyan_concrete
setblock 230 294 245 minecraft:light_blue_terracotta
fill 230 294 246 230 297 246 minecraft:cyan_concrete
setblock 230 294 247 minecraft:white_stained_glass
fill 230 294 248 230 297 249 minecraft:cyan_concrete
fill 230 294 252 230 300 252 minecraft:cyan_concrete
fill 230 294 261 230 298 261 minecraft:cyan_concrete
fill 230 294 264 230 295 264 minecraft:cyan_concrete
fill 230 294 268 230 300 268 minecraft:cyan_concrete
fill 230 294 270 230 295 270 minecraft:blue_concrete
fill 188 295 228 188 296 229 minecraft:cyan_concrete
fill 188 295 239 188 296 240 minecraft:cyan_concrete
fill 188 295 242 188 300 242 minecraft:cyan_concrete
setblock 188 295 243 minecraft:blue_concrete
fill 188 295 244 188 297 244 minecraft:cyan_concrete
setblock 188 295 245 minecraft:light_blue_wool
fill 188 295 246 188 300 246 minecraft:cyan_concrete
fill 188 295 249 188 295 257 minecraft:cyan_concrete
setblock 188 295 258 minecraft:blue_concrete
fill 188 295 259 188 300 260 minecraft:cyan_concrete
setblock 188 295 261 minecraft:white_stained_glass
setblock 188 295 262 minecraft:cyan_concrete
fill 188 295 265 188 296 265 minecraft:cyan_concrete
fill 188 295 267 188 296 267 minecraft:cyan_concrete
setblock 188 295 268 minecraft:blue_concrete
fill 188 295 269 188 300 269 minecraft:cyan_concrete
setblock 188 295 270 minecraft:blue_concrete
setblock 189 295 228 minecraft:blue_concrete
fill 189 295 270 193 296 270 minecraft:cyan_concrete
fill 190 295 228 190 298 228 minecraft:cyan_concrete
fill 190 295 259 190 295 260 minecraft:orange_concrete
setblock 190 295 261 minecraft:white_concrete
setblock 191 295 228 minecraft:light_blue_terracotta
setblock 191 295 238 minecraft:white_stained_glass
fill 192 295 228 193 295 228 minecraft:cyan_concrete
setblock 194 295 270 minecraft:blue_concrete
fill 195 295 228 195 296 228 minecraft:cyan_concrete
setblock 195 295 268 minecraft:white_stained_glass
fill 195 295 270 196 297 270 minecraft:cyan_concrete
setblock 196 295 228 minecraft:light_blue_terracotta
fill 198 295 228 199 298 228 minecraft:cyan_concrete
setblock 200 295 228 minecraft:blue_concrete
setblock 201 295 228 minecraft:white_stained_glass
setblock 203 295 228 minecraft:light_blue_terracotta
fill 204 295 228 204 298 228 minecraft:cyan_concrete
setblock 205 295 228 minecraft:blue_concrete
setblock 205 295 231 minecraft:orange_concrete
setblock 206 295 228 minecraft:light_blue_terracotta
setblock 206 295 231 minecraft:white_concrete
fill 206 295 270 206 300 270 minecraft:cyan_concrete
fill 207 295 228 211 295 228 minecraft:cyan_concrete
setblock 207 295 268 minecraft:white_stained_glass
setblock 207 295 270 minecraft:white_stained_glass
fill 208 295 270 208 301 270 minecraft:cyan_concrete
setblock 211 295 268 minecraft:white_concrete
setblock 212 295 228 minecraft:light_blue_wool
setblock 212 295 268 minecraft:light_blue_concrete
fill 213 295 228 215 298 228 minecraft:cyan_concrete
setblock 214 295 229 minecraft:white_stained_glass
setblock 215 295 268 minecraft:white_stained_glass
fill 218 295 270 218 300 270 minecraft:cyan_concrete
fill 222 295 228 223 295 228 minecraft:blue_concrete
fill 222 295 270 222 300 270 minecraft:cyan_concrete
fill 224 295 270 224 300 270 minecraft:cyan_concrete
setblock 227 295 263 minecraft:black_concrete
setblock 227 295 264 minecraft:yellow_concrete
setblock 228 295 230 minecraft:orange_concrete
setblock 229 295 230 minecraft:white_concrete
setblock 229 295 262 minecraft:black_concrete
setblock 229 295 263 minecraft:yellow_concrete
fill 230 295 228 230 297 228 minecraft:cyan_concrete
fill 230 295 232 230 296 232 minecraft:cyan_concrete
setblock 230 295 233 minecraft:light_blue_wool
fill 230 295 234 230 295 237 minecraft:cyan_concrete
setblock 230 295 238 minecraft:blue_concrete
fill 230 295 239 230 297 240 minecraft:cyan_concrete
setblock 230 295 241 minecraft:blue_concrete
fill 230 295 242 230 300 242 minecraft:cyan_concrete
fill 230 295 245 230 297 245 minecraft:cyan_concrete
setblock 230 295 247 minecraft:light_blue_terracotta
fill 230 295 250 230 300 250 minecraft:cyan_concrete
fill 230 295 254 230 295 256 minecraft:cyan_concrete
setblock 230 295 257 minecraft:blue_concrete
setblock 230 295 258 minecraft:cyan_concrete
setblock 230 295 265 minecraft:light_blue_terracotta
fill 230 295 266 230 300 267 minecraft:cyan_concrete
setblock 188 296 230 minecraft:light_blue_terracotta
fill 188 296 231 188 296 238 minecraft:cyan_concrete
setblock 188 296 243 minecraft:cyan_concrete
fill 188 296 245 188 300 245 minecraft:cyan_concrete
fill 188 296 249 188 296 251 minecraft:cyan_concrete
setblock 188 296 252 minecraft:white_stained_glass
fill 188 296 253 188 297 258 minecraft:cyan_concrete
fill 188 296 261 188 300 261 minecraft:cyan_concrete
setblock 188 296 262 minecraft:light_blue_wool
setblock 188 296 268 minecraft:cyan_concrete
setblock 188 296 270 minecraft:cyan_concrete
fill 189 296 228 189 300 228 minecraft:cyan_concrete
setblock 189 296 233 minecraft:yellow_concrete
setblock 189 296 234 minecraft:black_concrete
fill 189 296 236 190 296 236 minecraft:white_stained_glass
setblock 189 296 256 minecraft:orange_concrete
setblock 189 296 257 minecraft:white_concrete
setblock 189 296 258 minecraft:orange_concrete
setblock 189 296 259 minecraft:white_concrete
setblock 190 296 244 minecraft:orange_concrete
setblock 190 296 245 minecraft:white_concrete
fill 191 296 228 191 300 228 minecraft:cyan_concrete
setblock 191 296 231 minecraft:light[level=15]
setblock 191 296 238 minecraft:light[level=15]
setblock 191 296 245 minecraft:light[level=15]
setblock 191 296 252 minecraft:light[level=15]
setblock 191 296 259 minecraft:light[level=15]
setblock 191 296 266 minecraft:light[level=15]
setblock 192 296 228 minecraft:white_stained_glass
fill 193 296 228 193 300 228 minecraft:cyan_concrete
fill 194 296 270 194 298 270 minecraft:cyan_concrete
fill 196 296 228 196 297 228 minecraft:cyan_concrete
setblock 198 296 231 minecraft:light[level=15]
setblock 198 296 238 minecraft:light[level=15]
setblock 198 296 245 minecraft:light[level=15]
setblock 198 296 252 minecraft:light[level=15]
setblock 198 296 259 minecraft:light[level=15]
setblock 198 296 266 minecraft:light[level=15]
fill 200 296 228 201 296 228 minecraft:cyan_concrete
fill 203 296 228 203 300 228 minecraft:cyan_concrete
setblock 204 296 229 minecraft:orange_concrete
fill 205 296 228 208 296 228 minecraft:cyan_concrete
setblock 205 296 229 minecraft:white_concrete
setblock 205 296 231 minecraft:light[level=15]
setblock 205 296 238 minecraft:light[level=15]
setblock 205 296 245 minecraft:light[level=15]
setblock 205 296 252 minecraft:light[level=15]
setblock 205 296 259 minecraft:light[level=15]
setblock 205 296 266 minecraft:light[level=15]
fill 205 296 267 205 297 267 minecraft:white_concrete
setblock 206 296 231 minecraft:orange_concrete
fill 206 296 267 206 297 267 minecraft:light_blue_concrete
setblock 207 296 229 minecraft:white_stained_glass
fill 207 296 231 208 296 231 minecraft:white_concrete
fill 207 296 270 207 300 270 minecraft:cyan_concrete
setblock 209 296 228 minecraft:light_blue_wool
setblock 209 296 269 minecraft:white_concrete
fill 209 296 270 211 300 270 minecraft:cyan_concrete
fill 210 296 228 212 297 228 minecraft:cyan_concrete
setblock 210 296 269 minecraft:light_blue_concrete
setblock 212 296 231 minecraft:light[level=15]
setblock 212 296 238 minecraft:light[level=15]
setblock 212 296 245 minecraft:light[level=15]
setblock 212 296 252 minecraft:light[level=15]
setblock 212 296 259 minecraft:light[level=15]
setblock 212 296 266 minecraft:light[level=15]
setblock 212 296 270 minecraft:white_stained_glass
fill 213 296 270 216 297 270 minecraft:cyan_concrete
setblock 215 296 229 minecraft:lime_concrete
setblock 216 296 228 minecraft:cyan_concrete
setblock 216 296 229 minecraft:white_concrete
setblock 217 296 228 minecraft:light_blue_wool
setblock 217 296 270 minecraft:light_blue_terracotta
fill 218 296 228 223 296 228 minecraft:cyan_concrete
setblock 219 296 231 minecraft:light[level=15]
setblock 219 296 238 minecraft:light[level=15]
setblock 219 296 245 minecraft:light[level=15]
setblock 219 296 252 minecraft:light[level=15]
setblock 219 296 259 minecraft:light[level=15]
setblock 219 296 266 minecraft:light[level=15]
setblock 226 296 231 minecraft:orange_concrete
setblock 226 296 238 minecraft:light[level=15]
setblock 226 296 245 minecraft:light[level=15]
setblock 226 296 252 minecraft:light[level=15]
setblock 226 296 259 minecraft:light[level=15]
setblock 226 296 266 minecraft:light[level=15]
setblock 227 296 231 minecraft:white_concrete
setblock 227 296 261 minecraft:black_concrete
fill 227 296 262 227 296 263 minecraft:yellow_concrete
fill 227 296 270 227 297 270 minecraft:cyan_concrete
setblock 229 296 244 minecraft:white_stained_glass
setblock 229 296 261 minecraft:black_concrete
setblock 229 296 262 minecraft:yellow_concrete
setblock 229 296 265 minecraft:black_concrete
setblock 229 296 266 minecraft:yellow_concrete
fill 230 296 233 230 296 236 minecraft:cyan_concrete
setblock 230 296 237 minecraft:light_blue_terracotta
fill 230 296 238 230 297 238 minecraft:cyan_concrete
fill 230 296 241 230 300 241 minecraft:cyan_concrete
fill 230 296 243 230 300 243 minecraft:cyan_concrete
setblock 230 296 244 minecraft:light_blue_wool
fill 230 296 247 230 300 247 minecraft:cyan_concrete
fill 230 296 254 230 298 254 minecraft:cyan_concrete
fill 230 296 255 230 296 256 minecraft:light_blue_wool
setblock 230 296 257 minecraft:cyan_concrete
setblock 230 296 258 minecraft:white_stained_glass
setblock 230 296 264 minecraft:light_blue_wool
fill 230 296 265 230 300 265 minecraft:cyan_concrete
fill 230 296 270 230 298 270 minecraft:cyan_concrete
setblock 188 297 228 minecraft:light_blue_concrete
fill 188 297 229 188 297 234 minecraft:cyan_concrete
fill 188 297 235 188 297 236 minecraft:light_blue_terracotta
fill 188 297 237 188 300 238 minecraft:cyan_concrete
setblock 188 297 239 minecraft:light_blue_concrete
fill 188 297 240 188 300 240 minecraft:cyan_concrete
setblock 188 297 243 minecraft:white_stained_glass
setblock 188 297 249 minecraft:light_blue_concrete
fill 188 297 250 188 297 252 minecraft:cyan_concrete
fill 188 297 262 188 300 262 minecraft:cyan_concrete
setblock 188 297 265 minecraft:light_blue_concrete
fill 188 297 267 188 297 268 minecraft:light_blue_concrete
setblock 188 297 270 minecraft:light_blue_concrete
setblock 189 297 249 minecraft:magenta_concrete
setblock 189 297 250 minecraft:white_concrete
fill 189 297 270 192 298 270 minecraft:cyan_concrete
setblock 190 297 231 minecraft:yellow_concrete
setblock 190 297 232 minecraft:black_concrete
setblock 191 297 239 minecraft:white_stained_glass
fill 192 297 228 192 300 228 minecraft:cyan_concrete
setblock 193 297 270 minecraft:light_blue_concrete
setblock 194 297 268 minecraft:white_stained_glass
setblock 195 297 228 minecraft:white_stained_glass
setblock 196 297 231 minecraft:orange_concrete
setblock 197 297 231 minecraft:white_concrete
setblock 199 297 231 minecraft:orange_concrete
fill 200 297 228 200 300 228 minecraft:cyan_concrete
setblock 200 297 230 minecraft:orange_concrete
setblock 200 297 231 minecraft:white_concrete
setblock 201 297 228 minecraft:light_blue_terracotta
setblock 201 297 230 minecraft:white_concrete
setblock 205 297 228 minecraft:light_blue_wool
fill 206 297 228 206 300 228 minecraft:cyan_concrete
setblock 207 297 228 minecraft:white_stained_glass
setblock 207 297 268 minecraft:white_stained_glass
setblock 208 297 228 minecraft:light_blue_terracotta
fill 209 297 228 209 300 228 minecraft:cyan_concrete
fill 212 297 270 212 300 270 minecraft:cyan_concrete
setblock 214 297 229 minecraft:white_stained_glass
setblock 214 297 268 minecraft:white_stained_glass
setblock 216 297 228 minecraft:white_stained_glass
fill 217 297 228 221 298 228 minecraft:cyan_concrete
setblock 217 297 270 minecraft:cyan_concrete
fill 219 297 270 220 299 270 minecraft:cyan_concrete
setblock 221 297 270 minecraft:light_blue_concrete
setblock 222 297 228 minecraft:light_blue_concrete
fill 223 297 228 223 299 228 minecraft:cyan_concrete
setblock 228 297 267 minecraft:black_concrete
setblock 228 297 268 minecraft:yellow_concrete
setblock 229 297 263 minecraft:black_concrete
setblock 229 297 264 minecraft:yellow_concrete
setblock 230 297 232 minecraft:light_blue_concrete
fill 230 297 233 230 300 234 minecraft:cyan_concrete
setblock 230 297 235 minecraft:light_blue_concrete
fill 230 297 236 230 298 237 minecraft:cyan_concrete
fill 230 297 244 230 300 244 minecraft:cyan_concrete
setblock 230 297 253 minecraft:light_blue_concrete
fill 230 297 255 230 298 256 minecraft:cyan_concrete
setblock 230 297 257 minecraft:light_blue_terracotta
fill 230 297 258 230 300 258 minecraft:cyan_concrete
fill 230 297 264 230 300 264 minecraft:cyan_concrete
fill 188 298 228 188 300 228 minecraft:cyan_concrete
setblock 188 298 229 minecraft:light_blue_wool
fill 188 298 230 188 300 230 minecraft:cyan_concrete
setblock 188 298 231 minecraft:light_blue_concrete
fill 188 298 232 188 298 233 minecraft:cyan_concrete
setblock 188 298 234 minecraft:light_blue_wool
fill 188 298 235 188 300 236 minecraft:cyan_concrete
fill 188 298 239 188 300 239 minecraft:cyan_concrete
setblock 188 298 241 minecraft:light_blue_concrete
fill 188 298 243 188 301 243 minecraft:cyan_concrete
setblock 188 298 244 minecraft:light_blue_terracotta
setblock 188 298 247 minecraft:light_blue_concrete
fill 188 298 248 188 298 251 minecraft:cyan_concrete
setblock 188 298 252 minecraft:light_blue_concrete
fill 188 298 253 188 300 253 minecraft:cyan_concrete
setblock 188 298 254 minecraft:light_blue_concrete
fill 188 298 255 188 298 258 minecraft:cyan_concrete
fill 188 298 263 188 301 263 minecraft:cyan_concrete
setblock 188 298 264 minecraft:light_blue_concrete
setblock 188 298 265 minecraft:cyan_concrete
fill 188 298 267 188 298 268 minecraft:cyan_concrete
setblock 188 298 270 minecraft:cyan_concrete
setblock 189 298 251 minecraft:magenta_concrete
setblock 189 298 252 minecraft:white_concrete
setblock 190 298 232 minecraft:yellow_concrete
setblock 190 298 233 minecraft:black_concrete
setblock 190 298 235 minecraft:white_stained_glass
setblock 190 298 237 minecraft:yellow_concrete
setblock 190 298 238 minecraft:black_concrete
setblock 190 298 244 minecraft:orange_concrete
setblock 190 298 245 minecraft:white_concrete
setblock 191 298 236 minecraft:yellow_concrete
setblock 191 298 237 minecraft:black_concrete
setblock 191 298 241 minecraft:lime_concrete
setblock 191 298 242 minecraft:white_concrete
setblock 191 298 243 minecraft:orange_concrete
setblock 191 298 244 minecraft:white_concrete
fill 193 298 270 193 300 270 minecraft:cyan_concrete
fill 195 298 228 195 300 228 minecraft:cyan_concrete
setblock 195 298 270 minecraft:cyan_concrete
setblock 196 298 228 minecraft:light_blue_terracotta
fill 196 298 270 196 299 270 minecraft:light_blue_concrete
setblock 199 298 270 minecraft:white_stained_glass
fill 200 298 270 200 300 270 minecraft:cyan_concrete
fill 201 298 228 201 300 228 minecraft:cyan_concrete
setblock 201 298 270 minecraft:light_blue_wool
setblock 202 298 270 minecraft:cyan_concrete
fill 205 298 228 205 300 228 minecraft:cyan_concrete
fill 207 298 228 208 298 228 minecraft:cyan_concrete
setblock 207 298 268 minecraft:white_concrete
setblock 208 298 229 minecraft:white_stained_glass
setblock 208 298 268 minecraft:light_blue_concrete
fill 210 298 228 211 298 228 minecraft:cyan_concrete
setblock 212 298 228 minecraft:light_blue_concrete
setblock 213 298 270 minecraft:cyan_concrete
setblock 214 298 270 minecraft:light_blue_terracotta
setblock 215 298 230 minecraft:orange_concrete
fill 215 298 270 216 300 270 minecraft:cyan_concrete
setblock 216 298 228 minecraft:cyan_concrete
setblock 216 298 230 minecraft:white_concrete
setblock 217 298 270 minecraft:light_blue_concrete
setblock 221 298 270 minecraft:cyan_concrete
fill 222 298 228 222 300 228 minecraft:cyan_concrete
setblock 223 298 231 minecraft:orange_concrete
setblock 224 298 231 minecraft:white_concrete
fill 227 298 263 227 298 264 minecraft:black_concrete
setblock 227 298 265 minecraft:yellow_concrete
setblock 227 298 270 minecraft:light_blue_terracotta
setblock 229 298 239 minecraft:white_concrete
setblock 229 298 240 minecraft:light_blue_concrete
setblock 229 298 245 minecraft:white_stained_glass
setblock 230 298 228 minecraft:light_blue_concrete
fill 230 298 232 230 300 232 minecraft:cyan_concrete
fill 230 298 235 230 302 235 minecraft:cyan_concrete
fill 230 298 238 230 298 239 minecraft:light_blue_concrete
fill 230 298 240 230 300 240 minecraft:cyan_concrete
setblock 230 298 245 minecraft:light_blue_concrete
setblock 230 298 246 minecraft:light_blue_terracotta
fill 230 298 248 230 299 248 minecraft:cyan_concrete
setblock 230 298 249 minecraft:light_blue_wool
setblock 230 298 251 minecraft:light_blue_concrete
fill 230 298 253 230 300 253 minecraft:cyan_concrete
setblock 230 298 257 minecraft:light_blue_concrete
setblock 230 298 262 minecraft:light_blue_concrete
fill 230 298 263 230 300 263 minecraft:cyan_concrete
fill 188 299 229 188 300 229 minecraft:cyan_concrete
fill 188 299 231 188 300 231 minecraft:cyan_concrete
setblock 188 299 232 minecraft:light_blue_concrete
setblock 188 299 233 minecraft:white_stained_glass
setblock 188 299 234 minecraft:light_blue_concrete
fill 188 299 241 188 300 241 minecraft:cyan_concrete
fill 188 299 244 188 300 244 minecraft:cyan_concrete
fill 188 299 247 188 300 247 minecraft:cyan_concrete
setblock 188 299 248 minecraft:light_blue_concrete
fill 188 299 249 188 300 252 minecraft:cyan_concrete
fill 188 299 254 188 299 257 minecraft:cyan_concrete
setblock 188 299 258 minecraft:light_blue_wool
fill 188 299 264 188 300 264 minecraft:cyan_concrete
setblock 188 299 265 minecraft:light_blue_wool
setblock 188 299 267 minecraft:white_stained_glass
fill 188 299 268 188 300 268 minecraft:cyan_concrete
setblock 188 299 270 minecraft:light_blue_concrete
setblock 189 299 239 minecraft:lime_concrete
setblock 189 299 240 minecraft:white_concrete
fill 189 299 270 191 299 270 minecraft:cyan_concrete
setblock 190 299 228 minecraft:light_blue_concrete
setblock 191 299 234 minecraft:yellow_concrete
setblock 191 299 235 minecraft:black_concrete
setblock 191 299 239 minecraft:white_stained_glass
setblock 191 299 244 minecraft:orange_concrete
setblock 191 299 245 minecraft:white_concrete
setblock 191 299 246 minecraft:orange_concrete
setblock 191 299 247 minecraft:white_concrete
setblock 192 299 270 minecraft:light_blue_terracotta
setblock 193 299 268 minecraft:white_stained_glass
setblock 194 299 228 minecraft:light_blue_concrete
setblock 194 299 270 minecraft:light_blue_concrete
setblock 195 299 270 minecraft:white_stained_glass
fill 196 299 228 196 300 228 minecraft:cyan_concrete
setblock 198 299 228 minecraft:light_blue_wool
setblock 198 299 270 minecraft:light_blue_concrete
fill 199 299 228 199 300 228 minecraft:cyan_concrete
fill 199 299 270 199 300 270 minecraft:cyan_concrete
fill 201 299 270 201 300 270 minecraft:cyan_concrete
setblock 202 299 270 minecraft:light_blue_concrete
setblock 204 299 228 minecraft:light_blue_concrete
setblock 207 299 228 minecraft:light_blue_concrete
fill 208 299 228 208 300 228 minecraft:cyan_concrete
fill 210 299 228 211 299 228 minecraft:light_blue_concrete
fill 212 299 228 212 300 228 minecraft:cyan_concrete
setblock 213 299 228 minecraft:light_blue_concrete
setblock 213 299 270 minecraft:light_blue_terracotta
fill 214 299 228 215 300 228 minecraft:cyan_concrete
setblock 214 299 229 minecraft:white_stained_glass
setblock 214 299 270 minecraft:light_blue_concrete
setblock 215 299 268 minecraft:white_stained_glass
fill 216 299 228 217 299 228 minecraft:light_blue_concrete
fill 217 299 270 217 300 270 minecraft:cyan_concrete
fill 218 299 228 219 300 228 minecraft:cyan_concrete
setblock 219 299 229 minecraft:orange_concrete
setblock 220 299 228 minecraft:light_blue_concrete
setblock 220 299 229 minecraft:white_concrete
fill 221 299 228 221 300 228 minecraft:cyan_concrete
setblock 221 299 270 minecraft:light_blue_wool
setblock 227 299 234 minecraft:white_concrete
setblock 227 299 235 minecraft:light_blue_concrete
fill 227 299 270 227 300 270 minecraft:cyan_concrete
fill 230 299 228 230 301 228 minecraft:cyan_concrete
fill 230 299 236 230 300 236 minecraft:cyan_concrete
setblock 230 299 237 minecraft:light_blue_concrete
fill 230 299 238 230 300 239 minecraft:cyan_concrete
fill 230 299 245 230 300 246 minecraft:cyan_concrete
fill 230 299 249 230 300 249 minecraft:cyan_concrete
fill 230 299 251 230 300 251 minecraft:cyan_concrete
fill 230 299 254 230 299 255 minecraft:light_blue_terracotta
fill 230 299 256 230 299 257 minecraft:cyan_concrete
setblock 230 299 261 minecraft:light_blue_terracotta
fill 230 299 262 230 300 262 minecraft:cyan_concrete
setblock 230 299 270 minecraft:light_blue_concrete
fill 188 300 232 188 300 234 minecraft:cyan_concrete
setblock 188 300 248 minecraft:cyan_concrete
setblock 188 300 254 minecraft:cyan_concrete
setblock 188 300 255 minecraft:light_blue_wool
setblock 188 300 256 minecraft:white_stained_glass
fill 188 300 257 188 300 258 minecraft:cyan_concrete
setblock 188 300 265 minecraft:cyan_concrete
setblock 188 300 267 minecraft:cyan_concrete
setblock 188 300 270 minecraft:cyan_concrete
fill 189 300 270 190 300 270 minecraft:light_blue_terracotta
setblock 190 300 228 minecraft:cyan_concrete
setblock 191 300 250 minecraft:magenta_concrete
setblock 191 300 251 minecraft:white_concrete
fill 191 300 270 192 300 270 minecraft:cyan_concrete
setblock 194 300 228 minecraft:cyan_concrete
fill 194 300 270 196 300 270 minecraft:cyan_concrete
setblock 198 300 228 minecraft:white_stained_glass
setblock 198 300 270 minecraft:cyan_concrete
setblock 202 300 270 minecraft:cyan_concrete
setblock 204 300 228 minecraft:cyan_concrete
setblock 207 300 228 minecraft:cyan_concrete
setblock 207 300 229 minecraft:white_stained_glass
setblock 210 300 228 minecraft:light_blue_terracotta
setblock 211 300 228 minecraft:cyan_concrete
setblock 213 300 228 minecraft:cyan_concrete
fill 213 300 270 214 300 270 minecraft:cyan_concrete
setblock 215 300 230 minecraft:orange_concrete
fill 216 300 228 217 300 228 minecraft:cyan_concrete
setblock 216 300 230 minecraft:white_concrete
setblock 219 300 270 minecraft:cyan_concrete
setblock 220 300 228 minecraft:white_stained_glass
fill 220 300 270 220 301 270 minecraft:white_stained_glass
setblock 221 300 270 minecraft:cyan_concrete
setblock 223 300 228 minecraft:light_blue_wool
setblock 227 300 237 minecraft:white_concrete
setblock 227 300 238 minecraft:light_blue_concrete
setblock 228 300 235 minecraft:white_concrete
setblock 228 300 236 minecraft:light_blue_concrete
setblock 229 300 244 minecraft:white_stained_glass
setblock 230 300 237 minecraft:cyan_concrete
setblock 230 300 248 minecraft:white_stained_glass
fill 230 300 254 230 300 256 minecraft:cyan_concrete
setblock 230 300 257 minecraft:white_stained_glass
setblock 230 300 261 minecraft:cyan_concrete
setblock 230 300 270 minecraft:cyan_concrete
fill 188 301 228 188 301 231 minecraft:light_blue_concrete
setblock 188 301 232 minecraft:white_stained_glass
fill 188 301 233 188 308 233 minecraft:light_blue_concrete
setblock 188 301 234 minecraft:white_stained_glass
fill 188 301 235 188 302 242 minecraft:light_blue_concrete
fill 188 301 244 188 301 247 minecraft:light_blue_concrete
setblock 188 301 248 minecraft:light_blue_wool
fill 188 301 249 188 302 253 minecraft:light_blue_concrete
setblock 188 301 254 minecraft:white_stained_glass
fill 188 301 255 188 301 256 minecraft:light_blue_concrete
fill 188 301 257 188 301 258 minecraft:light_blue_terracotta
fill 188 301 259 188 308 259 minecraft:light_blue_concrete
setblock 188 301 260 minecraft:cyan_concrete
fill 188 301 261 188 302 262 minecraft:light_blue_concrete
fill 188 301 264 188 301 270 minecraft:light_blue_concrete
fill 189 301 228 200 301 228 minecraft:light_blue_concrete
setblock 189 301 241 minecraft:lime_concrete
setblock 189 301 242 minecraft:white_concrete
fill 189 301 270 202 301 270 minecraft:light_blue_concrete
setblock 190 301 239 minecraft:lime_concrete
setblock 190 301 240 minecraft:white_concrete
setblock 190 301 248 minecraft:magenta_concrete
setblock 190 301 249 minecraft:white_concrete
setblock 191 301 239 minecraft:white_stained_glass
setblock 192 301 268 minecraft:white_stained_glass
fill 201 301 228 202 301 228 minecraft:light_blue_terracotta
fill 203 301 228 209 301 228 minecraft:light_blue_concrete
setblock 203 301 270 minecraft:white_stained_glass
fill 204 301 270 207 301 270 minecraft:light_blue_concrete
fill 209 301 270 214 301 270 minecraft:light_blue_concrete
setblock 210 301 228 minecraft:cyan_concrete
fill 211 301 228 224 301 228 minecraft:light_blue_concrete
setblock 214 301 229 minecraft:white_stained_glass
setblock 215 301 270 minecraft:cyan_concrete
setblock 216 301 268 minecraft:white_stained_glass
fill 216 301 270 216 302 270 minecraft:light_blue_concrete
setblock 217 301 270 minecraft:white_stained_glass
fill 218 301 270 219 301 270 minecraft:light_blue_concrete
fill 219 301 229 219 301 230 minecraft:orange_concrete
fill 220 301 229 220 301 230 minecraft:white_concrete
fill 221 301 270 230 301 270 minecraft:light_blue_concrete
fill 225 301 228 225 302 228 minecraft:cyan_concrete
fill 226 301 228 229 301 228 minecraft:light_blue_concrete
fill 230 301 229 230 301 233 minecraft:light_blue_concrete
setblock 230 301 234 minecraft:cyan_concrete
fill 230 301 236 230 302 237 minecraft:light_blue_concrete
fill 230 301 238 230 302 238 minecraft:cyan_concrete
fill 230 301 239 230 303 244 minecraft:light_blue_concrete
setblock 230 301 245 minecraft:cyan_concrete
fill 230 301 246 230 301 269 minecraft:light_blue_concrete
setblock 188 302 228 minecraft:cyan_concrete
fill 188 302 229 188 302 232 minecraft:light_blue_concrete
setblock 188 302 234 minecraft:light_blue_concrete
fill 188 302 243 188 308 243 minecraft:light_blue_concrete
setblock 188 302 244 minecraft:white_stained_glass
fill 188 302 245 188 307 248 minecraft:light_blue_concrete
fill 188 302 254 188 302 255 minecraft:light_blue_concrete
fill 188 302 256 188 303 256 minecraft:cyan_concrete
fill 188 302 257 188 302 258 minecraft:light_blue_concrete
fill 188 302 260 188 303 260 minecraft:light_blue_concrete
fill 188 302 263 188 308 264 minecraft:light_blue_concrete
setblock 188 302 265 minecraft:cyan_concrete
setblock 188 302 266 minecraft:white_stained_glass
fill 188 302 267 188 302 270 minecraft:light_blue_concrete
fill 189 302 228 190 305 228 minecraft:light_blue_concrete
setblock 189 302 270 minecraft:white_stained_glass
fill 190 302 270 190 308 270 minecraft:light_blue_concrete
setblock 191 302 228 minecraft:white_stained_glass
setblock 191 302 231 minecraft:light[level=15]
setblock 191 302 238 minecraft:light[level=15]
setblock 191 302 245 minecraft:light[level=15]
setblock 191 302 252 minecraft:light[level=15]
setblock 191 302 259 minecraft:light[level=15]
setblock 191 302 266 minecraft:light[level=15]
setblock 191 302 270 minecraft:light_blue_terracotta
fill 192 302 228 194 308 228 minecraft:light_blue_concrete
fill 192 302 270 192 303 270 minecraft:cyan_concrete
fill 193 302 270 200 302 270 minecraft:light_blue_concrete
setblock 195 302 228 minecraft:light_blue_terracotta
fill 196 302 228 198 302 228 minecraft:light_blue_concrete
setblock 198 302 231 minecraft:light[level=15]
setblock 198 302 238 minecraft:light[level=15]
setblock 198 302 245 minecraft:light[level=15]
setblock 198 302 252 minecraft:light[level=15]
setblock 198 302 259 minecraft:light[level=15]
setblock 198 302 266 minecraft:light[level=15]
setblock 199 302 228 minecraft:cyan_concrete
fill 200 302 228 200 304 228 minecraft:light_blue_concrete
setblock 201 302 228 minecraft:cyan_concrete
setblock 201 302 270 minecraft:white_stained_glass
fill 202 302 228 208 304 228 minecraft:light_blue_concrete
fill 202 302 270 204 302 270 minecraft:cyan_concrete
setblock 205 302 231 minecraft:light[level=15]
setblock 205 302 238 minecraft:light[level=15]
setblock 205 302 245 minecraft:light[level=15]
setblock 205 302 252 minecraft:light[level=15]
setblock 205 302 259 minecraft:light[level=15]
setblock 205 302 266 minecraft:light[level=15]
fill 205 302 270 212 302 270 minecraft:light_blue_concrete
setblock 209 302 228 minecraft:white_stained_glass
fill 210 302 228 211 308 228 minecraft:light_blue_concrete
setblock 212 302 228 minecraft:light_blue_terracotta
setblock 212 302 231 minecraft:light[level=15]
setblock 212 302 238 minecraft:light[level=15]
setblock 212 302 245 minecraft:light[level=15]
setblock 212 302 252 minecraft:light[level=15]
setblock 212 302 259 minecraft:light[level=15]
setblock 212 302 266 minecraft:light[level=15]
fill 213 302 228 220 302 228 minecraft:light_blue_concrete
fill 213 302 270 213 303 270 minecraft:cyan_concrete
setblock 214 302 270 minecraft:light_blue_concrete
setblock 215 302 270 minecraft:light_blue_wool
fill 217 302 270 218 308 270 minecraft:light_blue_concrete
setblock 219 302 231 minecraft:light[level=15]
setblock 219 302 238 minecraft:light[level=15]
setblock 219 302 245 minecraft:light[level=15]
setblock 219 302 252 minecraft:light[level=15]
setblock 219 302 259 minecraft:light[level=15]
setblock 219 302 266 minecraft:light[level=15]
fill 219 302 270 220 302 270 minecraft:cyan_concrete
setblock 221 302 228 minecraft:cyan_concrete
fill 221 302 270 223 302 270 minecraft:light_blue_concrete
setblock 222 302 228 minecraft:white_stained_glass
setblock 223 302 228 minecraft:cyan_concrete
setblock 224 302 228 minecraft:light_blue_concrete
fill 224 302 270 225 302 270 minecraft:cyan_concrete
fill 226 302 228 228 303 228 minecraft:light_blue_concrete
setblock 226 302 231 minecraft:light[level=15]
setblock 226 302 238 minecraft:light[level=15]
setblock 226 302 245 minecraft:light[level=15]
setblock 226 302 252 minecraft:light[level=15]
setblock 226 302 259 minecraft:light[level=15]
setblock 226 302 266 minecraft:light[level=15]
fill 226 302 270 230 305 270 minecraft:light_blue_concrete
setblock 229 302 228 minecraft:cyan_concrete
setblock 229 302 243 minecraft:white_stained_glass
fill 230 302 228 230 303 231 minecraft:light_blue_concrete
setblock 230 302 232 minecraft:white_stained_glass
fill 230 302 233 230 302 234 minecraft:light_blue_concrete
fill 230 302 245 230 302 250 minecraft:light_blue_concrete
setblock 230 302 251 minecraft:cyan_concrete
fill 230 302 252 230 302 255 minecraft:light_blue_concrete
setblock 230 302 256 minecraft:white_stained_glass
fill 230 302 257 230 302 259 minecraft:light_blue_concrete
setblock 230 302 260 minecraft:light_blue_terracotta
fill 230 302 261 230 304 262 minecraft:light_blue_concrete
setblock 230 302 263 minecraft:cyan_concrete
fill 230 302 264 230 308 264 minecraft:light_blue_concrete
setblock 230 302 265 minecraft:cyan_concrete
fill 230 302 266 230 304 268 minecraft:light_blue_concrete
setblock 230 302 269 minecraft:light_blue_wool
fill 188 303 228 188 304 230 minecraft:light_blue_concrete
fill 188 303 231 188 303 232 minecraft:white_stained_glass
setblock 188 303 234 minecraft:white_stained_glass
fill 188 303 235 188 303 237 minecraft:light_blue_concrete
fill 188 303 238 188 303 240 minecraft:cyan_concrete
fill 188 303 241 188 308 241 minecraft:light_blue_concrete
setblock 188 303 242 minecraft:light_blue_wool
fill 188 303 244 188 308 244 minecraft:light_blue_concrete
fill 188 303 249 188 305 250 minecraft:light_blue_concrete
setblock 188 303 251 minecraft:cyan_concrete
fill 188 303 252 188 304 254 minecraft:light_blue_concrete
setblock 188 303 255 minecraft:cyan_concrete
fill 188 303 257 188 308 257 minecraft:light_blue_concrete
setblock 188 303 258 minecraft:cyan_concrete
setblock 188 303 261 minecraft:light_blue_terracotta
fill 188 303 262 188 308 262 minecraft:light_blue_concrete
fill 188 303 265 188 308 266 minecraft:light_blue_concrete
setblock 188 303 267 minecraft:cyan_concrete
fill 188 303 268 188 308 270 minecraft:light_blue_concrete
fill 189 303 270 189 308 270 minecraft:light_blue_concrete
fill 191 303 228 191 304 228 minecraft:light_blue_concrete
setblock 191 303 239 minecraft:white_stained_glass
fill 191 303 270 191 308 270 minecraft:light_blue_concrete
fill 193 303 270 197 303 270 minecraft:light_blue_concrete
fill 195 303 228 197 308 228 minecraft:light_blue_concrete
setblock 198 303 228 minecraft:cyan_concrete
setblock 198 303 270 minecraft:white_stained_glass
fill 199 303 228 199 304 228 minecraft:light_blue_concrete
fill 199 303 270 200 308 270 minecraft:light_blue_concrete
fill 201 303 228 201 308 228 minecraft:light_blue_concrete
setblock 201 303 270 minecraft:cyan_concrete
fill 202 303 270 207 306 270 minecraft:light_blue_concrete
setblock 208 303 270 minecraft:cyan_concrete
fill 209 303 228 209 308 228 minecraft:light_blue_concrete
fill 209 303 270 212 304 270 minecraft:light_blue_concrete
fill 212 303 228 213 305 228 minecraft:light_blue_concrete
setblock 213 303 229 minecraft:white_stained_glass
setblock 214 303 228 minecraft:cyan_concrete
setblock 214 303 270 minecraft:light_blue_terracotta
fill 215 303 228 221 308 228 minecraft:light_blue_concrete
fill 215 303 270 215 307 270 minecraft:light_blue_concrete
setblock 216 303 270 minecraft:light_blue_wool
fill 219 303 270 220 303 270 minecraft:light_blue_concrete
setblock 221 303 270 minecraft:light_blue_wool
setblock 222 303 228 minecraft:light_blue_terracotta
setblock 222 303 270 minecraft:light_blue_terracotta
fill 223 303 228 223 308 228 minecraft:light_blue_concrete
fill 223 303 270 225 308 270 minecraft:light_blue_concrete
setblock 224 303 228 minecraft:cyan_concrete
fill 225 303 228 225 308 228 minecraft:light_blue_concrete
fill 229 303 228 229 308 228 minecraft:light_blue_concrete
fill 230 303 232 230 308 232 minecraft:light_blue_concrete
setblock 230 303 233 minecraft:cyan_concrete
fill 230 303 234 230 306 235 minecraft:light_blue_concrete
setblock 230 303 236 minecraft:light_blue_wool
fill 230 303 237 230 308 238 minecraft:light_blue_concrete
fill 230 303 245 230 306 246 minecraft:light_blue_concrete
setblock 230 303 247 minecraft:cyan_concrete
fill 230 303 248 230 308 249 minecraft:light_blue_concrete
setblock 230 303 250 minecraft:cyan_concrete
fill 230 303 251 230 308 253 minecraft:light_blue_concrete
setblock 230 303 254 minecraft:cyan_concrete
fill 230 303 255 230 308 257 minecraft:light_blue_concrete
setblock 230 303 258 minecraft:light_blue_wool
fill 230 303 259 230 308 260 minecraft:light_blue_concrete
fill 230 303 263 230 308 263 minecraft:light_blue_concrete
fill 230 303 265 230 308 265 minecraft:light_blue_concrete
setblock 230 303 269 minecraft:white_stained_glass
fill 188 304 231 188 305 232 minecraft:light_blue_concrete
fill 188 304 234 188 308 234 minecraft:light_blue_concrete
setblock 188 304 235 minecraft:light_blue_wool
fill 188 304 236 188 305 240 minecraft:light_blue_concrete
setblock 188 304 242 minecraft:light_blue_concrete
setblock 188 304 251 minecraft:light_blue_wool
setblock 188 304 255 minecraft:light_blue_wool
fill 188 304 256 188 308 256 minecraft:light_blue_concrete
fill 188 304 258 188 308 258 minecraft:light_blue_concrete
setblock 188 304 260 minecraft:light_blue_terracotta
setblock 188 304 261 minecraft:light_blue_wool
fill 188 304 267 188 308 267 minecraft:light_blue_concrete
fill 192 304 270 195 305 270 minecraft:light_blue_concrete
setblock 196 304 270 minecraft:light_blue_terracotta
fill 197 304 270 198 308 270 minecraft:light_blue_concrete
setblock 198 304 228 minecraft:light_blue_concrete
fill 201 304 270 201 305 270 minecraft:light_blue_concrete
fill 208 304 270 208 308 270 minecraft:light_blue_concrete
fill 213 304 270 214 308 270 minecraft:light_blue_concrete
fill 214 304 228 214 306 228 minecraft:light_blue_concrete
fill 216 304 270 216 308 270 minecraft:light_blue_concrete
setblock 219 304 270 minecraft:white_stained_glass
fill 220 304 270 222 305 270 minecraft:light_blue_concrete
fill 222 304 228 222 306 228 minecraft:light_blue_concrete
fill 224 304 228 224 307 228 minecraft:light_blue_concrete
fill 226 304 228 226 308 228 minecraft:light_blue_concrete
setblock 227 304 228 minecraft:light_blue_wool
fill 228 304 228 228 308 228 minecraft:light_blue_concrete
fill 230 304 228 230 308 228 minecraft:light_blue_concrete
setblock 230 304 229 minecraft:light_blue_wool
fill 230 304 230 230 308 231 minecraft:light_blue_concrete
fill 230 304 233 230 308 233 minecraft:light_blue_concrete
fill 230 304 236 230 307 236 minecraft:light_blue_concrete
fill 230 304 239 230 305 241 minecraft:light_blue_concrete
setblock 230 304 242 minecraft:light_blue_terracotta
fill 230 304 243 230 305 244 minecraft:light_blue_concrete
fill 230 304 247 230 308 247 minecraft:light_blue_concrete
fill 230 304 250 230 308 250 minecraft:light_blue_concrete
fill 230 304 254 230 308 254 minecraft:light_blue_concrete
setblock 230 304 258 minecraft:light_blue_concrete
setblock 230 304 269 minecraft:light_blue_wool
fill 188 305 228 188 308 229 minecraft:light_blue_concrete
setblock 188 305 230 minecraft:white_stained_glass
fill 188 305 235 188 308 235 minecraft:light_blue_concrete
setblock 188 305 242 minecraft:white_stained_glass
fill 188 305 251 188 308 253 minecraft:light_blue_concrete
setblock 188 305 254 minecraft:light_blue_wool
fill 188 305 255 188 308 255 minecraft:light_blue_concrete
fill 188 305 260 188 308 261 minecraft:light_blue_concrete
setblock 191 305 228 minecraft:white_stained_glass
fill 196 305 270 196 308 270 minecraft:light_blue_concrete
setblock 198 305 228 minecraft:light_blue_terracotta
fill 199 305 228 200 305 228 minecraft:white_stained_glass
fill 202 305 228 202 308 228 minecraft:light_blue_concrete
setblock 203 305 228 minecraft:light_blue_terracotta
fill 204 305 228 204 308 228 minecraft:light_blue_concrete
setblock 205 305 228 minecraft:white_stained_glass
fill 206 305 228 208 305 228 minecraft:light_blue_concrete
fill 209 305 270 211 305 270 minecraft:light_blue_concrete
setblock 212 305 270 minecraft:light_blue_wool
fill 219 305 270 219 308 270 minecraft:light_blue_concrete
fill 227 305 228 227 308 228 minecraft:light_blue_concrete
setblock 230 305 229 minecraft:light_blue_concrete
fill 230 305 242 230 308 242 minecraft:light_blue_concrete
setblock 230 305 258 minecraft:light_blue_terracotta
setblock 230 305 261 minecraft:light_blue_terracotta
fill 230 305 262 230 308 262 minecraft:light_blue_concrete
fill 230 305 266 230 308 266 minecraft:light_blue_concrete
setblock 230 305 267 minecraft:light_blue_terracotta
fill 230 305 268 230 305 269 minecraft:light_blue_concrete
fill 188 306 230 188 308 230 minecraft:light_blue_concrete
setblock 188 306 231 minecraft:white_stained_glass
fill 188 306 232 188 308 232 minecraft:light_blue_concrete
fill 188 306 236 188 308 236 minecraft:light_blue_concrete
setblock 188 306 237 minecraft:white_stained_glass
fill 188 306 238 188 308 240 minecraft:light_blue_concrete
fill 188 306 242 188 308 242 minecraft:light_blue_concrete
setblock 188 306 249 minecraft:light_blue_terracotta
setblock 188 306 250 minecraft:white_stained_glass
setblock 188 306 254 minecraft:light_blue_concrete
setblock 189 306 228 minecraft:light_blue_terracotta
fill 190 306 228 191 308 228 minecraft:light_blue_concrete
fill 192 306 270 194 308 270 minecraft:light_blue_concrete
setblock 195 306 270 minecraft:light_blue_terracotta
fill 198 306 228 200 307 228 minecraft:light_blue_concrete
setblock 201 306 270 minecraft:white_stained_glass
fill 203 306 228 203 308 228 minecraft:light_blue_concrete
fill 205 306 228 206 308 228 minecraft:light_blue_concrete
setblock 207 306 228 minecraft:light_blue_terracotta
fill 208 306 228 208 308 228 minecraft:light_blue_concrete
fill 209 306 270 210 307 270 minecraft:light_blue_concrete
setblock 211 306 270 minecraft:white_stained_glass
setblock 212 306 228 minecraft:light_blue_terracotta
fill 212 306 270 212 308 270 minecraft:light_blue_concrete
fill 213 306 228 213 308 228 minecraft:light_blue_concrete
fill 220 306 270 220 308 270 minecraft:light_blue_concrete
setblock 221 306 270 minecraft:light_blue_wool
fill 222 306 270 222 308 270 minecraft:light_blue_concrete
fill 226 306 270 228 308 270 minecraft:light_blue_concrete
setblock 229 306 270 minecraft:white_stained_glass
setblock 230 306 229 minecraft:light_blue_terracotta
fill 230 306 239 230 307 239 minecraft:light_blue_concrete
setblock 230 306 240 minecraft:light_blue_wool
fill 230 306 241 230 308 241 minecraft:light_blue_concrete
fill 230 306 243 230 308 243 minecraft:light_blue_concrete
setblock 230 306 244 minecraft:light_blue_terracotta
fill 230 306 258 230 308 258 minecraft:light_blue_concrete
fill 230 306 261 230 308 261 minecraft:light_blue_concrete
fill 230 306 267 230 308 267 minecraft:light_blue_concrete
setblock 230 306 268 minecraft:light_blue_terracotta
fill 230 306 269 230 308 270 minecraft:light_blue_concrete
setblock 188 307 231 minecraft:light_blue_wool
fill 188 307 237 188 308 237 minecraft:light_blue_concrete
fill 188 307 249 188 308 250 minecraft:light_blue_concrete
setblock 188 307 254 minecraft:light_blue_wool
fill 189 307 228 189 308 228 minecraft:light_blue_concrete
fill 195 307 270 195 308 270 minecraft:light_blue_concrete
fill 201 307 270 202 308 270 minecraft:light_blue_concrete
setblock 203 307 270 minecraft:light_blue_terracotta
fill 204 307 270 207 307 270 minecraft:light_blue_concrete
fill 207 307 228 207 308 228 minecraft:light_blue_concrete
fill 211 307 270 211 308 270 minecraft:light_blue_concrete
fill 212 307 228 212 308 228 minecraft:light_blue_concrete
setblock 214 307 228 minecraft:light_blue_terracotta
fill 221 307 270 221 308 270 minecraft:light_blue_concrete
setblock 222 307 228 minecraft:white_stained_glass
fill 229 307 270 229 308 270 minecraft:light_blue_concrete
fill 230 307 229 230 308 229 minecraft:light_blue_concrete
fill 230 307 234 230 308 234 minecraft:light_blue_concrete
setblock 230 307 235 minecraft:light_blue_terracotta
setblock 230 307 240 minecraft:white_stained_glass
fill 230 307 244 230 308 244 minecraft:light_blue_concrete
setblock 230 307 245 minecraft:light_blue_wool
fill 230 307 246 230 308 246 minecraft:light_blue_concrete
fill 230 307 268 230 308 268 minecraft:light_blue_concrete
setblock 188 308 231 minecraft:light_blue_concrete
setblock 188 308 245 minecraft:light_blue_concrete
setblock 188 308 246 minecraft:light_blue_wool
fill 188 308 247 188 308 248 minecraft:light_blue_concrete
setblock 188 308 254 minecraft:light_blue_concrete
setblock 198 308 228 minecraft:white_stained_glass
fill 199 308 228 200 308 228 minecraft:light_blue_concrete
fill 203 308 270 206 308 270 minecraft:light_blue_concrete
setblock 207 308 270 minecraft:white_stained_glass
setblock 209 308 270 minecraft:light_blue_concrete
setblock 210 308 270 minecraft:light_blue_terracotta
setblock 214 308 228 minecraft:light_blue_concrete
setblock 215 308 270 minecraft:white_stained_glass
setblock 222 308 228 minecraft:light_blue_concrete
setblock 224 308 228 minecraft:light_blue_wool
setblock 230 308 235 minecraft:light_blue_concrete
setblock 230 308 236 minecraft:light_blue_wool
setblock 230 308 239 minecraft:light_blue_wool
setblock 230 308 240 minecraft:light_blue_concrete
setblock 230 308 245 minecraft:light_blue_concrete
