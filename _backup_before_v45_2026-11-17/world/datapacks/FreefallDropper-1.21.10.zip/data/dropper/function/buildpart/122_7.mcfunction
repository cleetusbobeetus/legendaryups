fill 95 186 518 95 188 518 minecraft:blackstone
setblock 95 186 522 minecraft:smooth_basalt
fill 95 186 523 95 186 526 minecraft:blackstone
setblock 95 186 527 minecraft:smooth_basalt
fill 95 186 528 95 189 528 minecraft:blackstone
setblock 95 186 532 minecraft:smooth_basalt
fill 95 186 533 95 189 533 minecraft:blackstone
setblock 95 186 537 minecraft:smooth_basalt
fill 95 186 538 95 188 538 minecraft:blackstone
setblock 95 186 542 minecraft:smooth_basalt
fill 95 186 543 95 188 543 minecraft:blackstone
setblock 95 186 547 minecraft:smooth_basalt
fill 95 186 548 95 189 548 minecraft:blackstone
setblock 95 186 551 minecraft:blackstone
setblock 96 186 521 minecraft:smooth_basalt
fill 96 186 522 96 189 522 minecraft:blackstone
setblock 96 186 526 minecraft:smooth_basalt
fill 96 186 527 96 189 527 minecraft:blackstone
setblock 96 186 531 minecraft:smooth_basalt
fill 96 186 532 96 189 532 minecraft:blackstone
setblock 96 186 541 minecraft:smooth_basalt
setblock 96 186 542 minecraft:blackstone
setblock 96 186 546 minecraft:smooth_basalt
fill 96 186 547 96 187 547 minecraft:blackstone
setblock 96 186 551 minecraft:smooth_basalt
setblock 97 186 521 minecraft:blackstone
setblock 97 186 525 minecraft:smooth_basalt
fill 97 186 526 97 189 526 minecraft:blackstone
setblock 97 186 551 minecraft:blackstone
fill 104 186 511 105 186 511 minecraft:blackstone
setblock 105 186 551 minecraft:blackstone
setblock 106 186 511 minecraft:smooth_basalt
setblock 106 186 551 minecraft:smooth_basalt
fill 107 186 511 107 188 512 minecraft:blackstone
setblock 107 186 550 minecraft:smooth_basalt
fill 107 186 551 110 186 551 minecraft:blackstone
setblock 108 186 549 minecraft:smooth_basalt
fill 108 186 550 111 186 550 minecraft:blackstone
fill 109 186 549 112 186 549 minecraft:blackstone
setblock 110 186 511 minecraft:blackstone
setblock 110 186 512 minecraft:smooth_basalt
fill 110 186 513 110 189 513 minecraft:blackstone
setblock 111 186 511 minecraft:smooth_basalt
fill 111 186 512 111 189 512 minecraft:blackstone
fill 111 186 548 112 187 548 minecraft:blackstone
setblock 111 186 551 minecraft:smooth_basalt
fill 112 186 511 112 189 511 minecraft:blackstone
setblock 112 186 550 minecraft:smooth_basalt
fill 112 186 551 112 189 551 minecraft:blackstone
fill 113 186 521 115 187 521 minecraft:gold_block
setblock 113 186 549 minecraft:smooth_basalt
fill 113 186 550 113 189 550 minecraft:blackstone
fill 114 186 522 115 187 522 minecraft:gold_block
setblock 114 186 548 minecraft:smooth_basalt
fill 114 186 549 114 189 549 minecraft:blackstone
setblock 115 186 512 minecraft:smooth_basalt
setblock 116 186 511 minecraft:smooth_basalt
fill 116 186 512 116 187 512 minecraft:blackstone
setblock 116 186 551 minecraft:smooth_basalt
fill 117 186 511 117 189 511 minecraft:blackstone
setblock 117 186 550 minecraft:smooth_basalt
fill 117 186 551 117 189 551 minecraft:blackstone
setblock 118 186 549 minecraft:smooth_basalt
fill 118 186 550 121 186 550 minecraft:blackstone
fill 119 186 549 119 187 549 minecraft:blackstone
setblock 121 186 551 minecraft:smooth_basalt
setblock 122 186 550 minecraft:smooth_basalt
fill 122 186 551 122 189 551 minecraft:blackstone
setblock 123 186 549 minecraft:smooth_basalt
fill 123 186 550 126 186 550 minecraft:blackstone
fill 124 186 549 127 186 549 minecraft:blackstone
setblock 126 186 511 minecraft:smooth_basalt
fill 126 186 548 128 186 548 minecraft:blackstone
setblock 126 186 551 minecraft:smooth_basalt
fill 127 186 511 130 186 511 minecraft:blackstone
setblock 127 186 550 minecraft:smooth_basalt
fill 127 186 551 127 189 551 minecraft:blackstone
setblock 128 186 549 minecraft:smooth_basalt
fill 128 186 550 128 189 550 minecraft:blackstone
setblock 129 186 548 minecraft:smooth_basalt
fill 129 186 549 129 189 549 minecraft:blackstone
setblock 130 186 547 minecraft:smooth_basalt
fill 130 186 548 130 189 548 minecraft:blackstone
setblock 131 186 511 minecraft:smooth_basalt
fill 131 186 544 131 186 545 minecraft:blackstone
setblock 131 186 546 minecraft:smooth_basalt
fill 131 186 547 131 187 547 minecraft:blackstone
setblock 131 186 551 minecraft:smooth_basalt
fill 132 186 511 132 189 511 minecraft:blackstone
setblock 132 186 540 minecraft:smooth_basalt
setblock 132 186 541 minecraft:blackstone
setblock 132 186 545 minecraft:smooth_basalt
fill 132 186 546 132 188 546 minecraft:blackstone
setblock 132 186 550 minecraft:smooth_basalt
fill 132 186 551 132 189 551 minecraft:blackstone
fill 133 186 522 133 186 523 minecraft:blackstone
setblock 133 186 524 minecraft:smooth_basalt
fill 133 186 525 133 189 525 minecraft:blackstone
fill 133 186 527 133 186 528 minecraft:blackstone
setblock 133 186 529 minecraft:smooth_basalt
fill 133 186 530 133 189 530 minecraft:blackstone
fill 133 186 532 133 186 533 minecraft:blackstone
setblock 133 186 539 minecraft:smooth_basalt
fill 133 186 540 133 188 540 minecraft:blackstone
setblock 133 186 544 minecraft:smooth_basalt
fill 133 186 545 133 189 545 minecraft:blackstone
setblock 133 186 549 minecraft:smooth_basalt
fill 133 186 550 133 189 550 minecraft:blackstone
fill 134 186 520 134 186 522 minecraft:blackstone
setblock 134 186 523 minecraft:smooth_basalt
fill 134 186 524 134 189 524 minecraft:blackstone
setblock 134 186 528 minecraft:smooth_basalt
fill 134 186 529 134 189 529 minecraft:blackstone
setblock 134 186 533 minecraft:smooth_basalt
fill 134 186 534 134 189 534 minecraft:blackstone
setblock 134 186 538 minecraft:smooth_basalt
fill 134 186 539 134 189 539 minecraft:blackstone
setblock 134 186 543 minecraft:smooth_basalt
fill 134 186 544 134 189 544 minecraft:blackstone
setblock 134 186 548 minecraft:smooth_basalt
fill 134 186 549 134 189 549 minecraft:blackstone
setblock 135 186 517 minecraft:smooth_basalt
setblock 135 186 518 minecraft:blackstone
setblock 135 186 522 minecraft:smooth_basalt
fill 135 186 523 135 189 523 minecraft:blackstone
setblock 135 186 527 minecraft:smooth_basalt
fill 135 186 528 135 189 528 minecraft:blackstone
setblock 135 186 532 minecraft:smooth_basalt
fill 135 186 533 135 189 533 minecraft:blackstone
setblock 135 186 537 minecraft:smooth_basalt
fill 135 186 538 135 189 538 minecraft:blackstone
setblock 135 186 542 minecraft:smooth_basalt
fill 135 186 543 135 189 543 minecraft:blackstone
setblock 135 186 547 minecraft:smooth_basalt
fill 135 186 548 135 189 548 minecraft:blackstone
setblock 95 187 511 minecraft:smooth_basalt
setblock 95 187 516 minecraft:smooth_basalt
fill 95 187 517 95 188 517 minecraft:blackstone
setblock 95 187 521 minecraft:smooth_basalt
fill 95 187 522 95 187 525 minecraft:blackstone
setblock 95 187 526 minecraft:smooth_basalt
fill 95 187 527 95 190 527 minecraft:blackstone
setblock 95 187 531 minecraft:smooth_basalt
fill 95 187 532 95 190 532 minecraft:blackstone
setblock 95 187 536 minecraft:smooth_basalt
fill 95 187 537 95 188 537 minecraft:blackstone
setblock 95 187 541 minecraft:smooth_basalt
fill 95 187 542 95 188 542 minecraft:blackstone
setblock 95 187 546 minecraft:smooth_basalt
fill 95 187 547 95 189 547 minecraft:blackstone
fill 95 187 549 95 188 549 minecraft:blackstone
setblock 95 187 551 minecraft:smooth_basalt
setblock 96 187 520 minecraft:smooth_basalt
fill 96 187 521 96 188 521 minecraft:blackstone
setblock 96 187 525 minecraft:smooth_basalt
fill 96 187 526 96 190 526 minecraft:blackstone
setblock 96 187 529 minecraft:blackstone
setblock 96 187 530 minecraft:smooth_basalt
fill 96 187 531 96 190 531 minecraft:blackstone
setblock 96 187 545 minecraft:smooth_basalt
setblock 96 187 546 minecraft:blackstone
fill 96 187 551 96 188 551 minecraft:blackstone
setblock 97 187 524 minecraft:smooth_basalt
fill 97 187 525 97 188 525 minecraft:blackstone
setblock 97 187 529 minecraft:smooth_basalt
fill 103 187 511 104 187 511 minecraft:blackstone
setblock 104 187 551 minecraft:blackstone
setblock 105 187 511 minecraft:smooth_basalt
setblock 105 187 551 minecraft:smooth_basalt
fill 106 187 511 106 189 512 minecraft:blackstone
setblock 106 187 550 minecraft:smooth_basalt
fill 106 187 551 109 187 551 minecraft:blackstone
fill 107 187 550 110 187 550 minecraft:blackstone
fill 108 187 549 111 187 549 minecraft:blackstone
setblock 109 187 511 minecraft:blackstone
setblock 109 187 512 minecraft:smooth_basalt
fill 109 187 513 109 190 513 minecraft:blackstone
setblock 110 187 511 minecraft:smooth_basalt
fill 110 187 512 110 190 512 minecraft:blackstone
setblock 110 187 551 minecraft:smooth_basalt
fill 111 187 511 111 190 511 minecraft:blackstone
setblock 111 187 550 minecraft:smooth_basalt
fill 111 187 551 111 190 551 minecraft:blackstone
setblock 112 187 549 minecraft:smooth_basalt
fill 112 187 550 112 190 550 minecraft:blackstone
setblock 113 187 548 minecraft:smooth_basalt
fill 113 187 549 113 190 549 minecraft:blackstone
setblock 114 187 512 minecraft:smooth_basalt
setblock 114 187 548 minecraft:blackstone
setblock 115 187 511 minecraft:smooth_basalt
fill 115 187 512 115 189 512 minecraft:blackstone
setblock 115 187 551 minecraft:smooth_basalt
fill 116 187 511 116 190 511 minecraft:blackstone
setblock 116 187 549 minecraft:blackstone
setblock 116 187 550 minecraft:smooth_basalt
fill 116 187 551 116 190 551 minecraft:blackstone
setblock 117 187 549 minecraft:smooth_basalt
fill 117 187 550 120 187 550 minecraft:blackstone
fill 118 187 549 118 188 549 minecraft:blackstone
setblock 120 187 511 minecraft:smooth_basalt
setblock 120 187 551 minecraft:smooth_basalt
setblock 121 187 550 minecraft:smooth_basalt
fill 121 187 551 121 190 551 minecraft:blackstone
setblock 122 187 549 minecraft:smooth_basalt
fill 122 187 550 125 187 550 minecraft:blackstone
fill 123 187 549 126 187 549 minecraft:blackstone
setblock 125 187 511 minecraft:smooth_basalt
setblock 125 187 551 minecraft:smooth_basalt
fill 126 187 511 129 187 511 minecraft:blackstone
fill 126 187 548 127 187 548 minecraft:blackstone
setblock 126 187 550 minecraft:smooth_basalt
fill 126 187 551 126 190 551 minecraft:blackstone
setblock 127 187 549 minecraft:smooth_basalt
fill 127 187 550 127 190 550 minecraft:blackstone
setblock 128 187 548 minecraft:smooth_basalt
fill 128 187 549 128 190 549 minecraft:blackstone
fill 129 187 548 129 190 548 minecraft:blackstone
setblock 130 187 511 minecraft:smooth_basalt
setblock 130 187 547 minecraft:blackstone
setblock 130 187 551 minecraft:smooth_basalt
fill 131 187 511 131 190 511 minecraft:blackstone
setblock 131 187 546 minecraft:blackstone
setblock 131 187 550 minecraft:smooth_basalt
fill 131 187 551 131 190 551 minecraft:blackstone
setblock 132 187 544 minecraft:smooth_basalt
fill 132 187 545 132 188 545 minecraft:blackstone
setblock 132 187 549 minecraft:smooth_basalt
fill 132 187 550 132 190 550 minecraft:blackstone
setblock 133 187 523 minecraft:smooth_basalt
fill 133 187 524 133 188 524 minecraft:blackstone
setblock 133 187 527 minecraft:blackstone
setblock 133 187 528 minecraft:smooth_basalt
fill 133 187 529 133 190 529 minecraft:blackstone
setblock 133 187 532 minecraft:blackstone
setblock 133 187 533 minecraft:smooth_basalt
setblock 133 187 538 minecraft:smooth_basalt
setblock 133 187 539 minecraft:blackstone
setblock 133 187 543 minecraft:smooth_basalt
fill 133 187 544 133 189 544 minecraft:blackstone
setblock 133 187 548 minecraft:smooth_basalt
fill 133 187 549 133 189 549 minecraft:blackstone
setblock 134 187 521 minecraft:blackstone
setblock 134 187 522 minecraft:smooth_basalt
fill 134 187 523 134 189 523 minecraft:blackstone
setblock 134 187 527 minecraft:smooth_basalt
fill 134 187 528 134 190 528 minecraft:blackstone
setblock 134 187 532 minecraft:smooth_basalt
fill 134 187 533 134 190 533 minecraft:blackstone
setblock 134 187 537 minecraft:smooth_basalt
fill 134 187 538 134 189 538 minecraft:blackstone
setblock 134 187 542 minecraft:smooth_basalt
fill 134 187 543 134 189 543 minecraft:blackstone
setblock 134 187 547 minecraft:smooth_basalt
fill 134 187 548 134 190 548 minecraft:blackstone
setblock 135 187 521 minecraft:smooth_basalt
fill 135 187 522 135 190 522 minecraft:blackstone
setblock 135 187 526 minecraft:smooth_basalt
fill 135 187 527 135 190 527 minecraft:blackstone
setblock 135 187 531 minecraft:smooth_basalt
fill 135 187 532 135 190 532 minecraft:blackstone
setblock 135 187 536 minecraft:smooth_basalt
fill 135 187 537 135 190 537 minecraft:blackstone
setblock 135 187 541 minecraft:smooth_basalt
fill 135 187 542 135 190 542 minecraft:blackstone
setblock 135 187 546 minecraft:smooth_basalt
fill 135 187 547 135 190 547 minecraft:blackstone
setblock 135 187 551 minecraft:smooth_basalt
setblock 95 188 520 minecraft:smooth_basalt
fill 95 188 521 95 188 524 minecraft:blackstone
setblock 95 188 525 minecraft:smooth_basalt
fill 95 188 526 95 191 526 minecraft:blackstone
setblock 95 188 530 minecraft:smooth_basalt
fill 95 188 531 95 191 531 minecraft:blackstone
setblock 95 188 535 minecraft:smooth_basalt
setblock 95 188 536 minecraft:blackstone
setblock 95 188 540 minecraft:smooth_basalt
setblock 95 188 541 minecraft:blackstone
setblock 95 188 545 minecraft:smooth_basalt
fill 95 188 546 95 189 546 minecraft:blackstone
setblock 95 188 550 minecraft:smooth_basalt
fill 95 188 551 95 189 551 minecraft:blackstone
setblock 96 188 520 minecraft:blackstone
setblock 96 188 524 minecraft:smooth_basalt
fill 96 188 525 96 191 525 minecraft:blackstone
setblock 96 188 529 minecraft:smooth_basalt
fill 96 188 530 96 191 530 minecraft:blackstone
setblock 97 188 524 minecraft:blackstone
setblock 97 188 528 minecraft:smooth_basalt
setblock 97 188 529 minecraft:blackstone
setblock 103 188 511 minecraft:blackstone
setblock 103 188 551 minecraft:blackstone
setblock 104 188 511 minecraft:smooth_basalt
setblock 104 188 551 minecraft:smooth_basalt
fill 105 188 511 105 191 511 minecraft:blackstone
fill 105 188 518 105 189 519 minecraft:gilded_blackstone
setblock 105 188 550 minecraft:smooth_basalt
fill 105 188 551 108 188 551 minecraft:blackstone
fill 106 188 550 109 188 550 minecraft:blackstone
fill 107 188 549 110 188 549 minecraft:blackstone
setblock 108 188 511 minecraft:blackstone
setblock 108 188 512 minecraft:smooth_basalt
setblock 109 188 511 minecraft:smooth_basalt
fill 109 188 512 109 191 512 minecraft:blackstone
setblock 109 188 551 minecraft:smooth_basalt
fill 110 188 511 110 191 511 minecraft:blackstone
setblock 110 188 550 minecraft:smooth_basalt
fill 110 188 551 110 191 551 minecraft:blackstone
setblock 111 188 548 minecraft:blackstone
setblock 111 188 549 minecraft:smooth_basalt
fill 111 188 550 111 191 550 minecraft:blackstone
setblock 112 188 513 minecraft:smooth_basalt
setblock 112 188 548 minecraft:smooth_basalt
fill 112 188 549 112 191 549 minecraft:blackstone
setblock 113 188 512 minecraft:smooth_basalt
setblock 114 188 511 minecraft:smooth_basalt
fill 114 188 512 114 191 512 minecraft:blackstone
setblock 114 188 551 minecraft:smooth_basalt
fill 115 188 511 115 191 511 minecraft:blackstone
setblock 115 188 550 minecraft:smooth_basalt
fill 115 188 551 115 191 551 minecraft:blackstone
setblock 116 188 549 minecraft:smooth_basalt
fill 116 188 550 119 188 550 minecraft:blackstone
setblock 117 188 549 minecraft:blackstone
setblock 119 188 511 minecraft:smooth_basalt
setblock 119 188 551 minecraft:smooth_basalt
setblock 120 188 550 minecraft:smooth_basalt
fill 120 188 551 120 191 551 minecraft:blackstone
fill 121 188 550 124 188 550 minecraft:blackstone
fill 122 188 549 125 188 549 minecraft:blackstone
fill 123 188 533 124 189 533 minecraft:gold_block
setblock 124 188 511 minecraft:smooth_basalt
setblock 124 188 551 minecraft:smooth_basalt
fill 125 188 511 128 188 511 minecraft:blackstone
setblock 125 188 550 minecraft:smooth_basalt
fill 125 188 551 125 191 551 minecraft:blackstone
setblock 126 188 548 minecraft:blackstone
setblock 126 188 549 minecraft:smooth_basalt
fill 126 188 550 126 191 550 minecraft:blackstone
setblock 127 188 548 minecraft:smooth_basalt
fill 127 188 549 127 191 549 minecraft:blackstone
fill 128 188 548 128 190 548 minecraft:blackstone
setblock 129 188 511 minecraft:smooth_basalt
setblock 129 188 551 minecraft:smooth_basalt
fill 130 188 511 130 191 511 minecraft:blackstone
setblock 130 188 550 minecraft:smooth_basalt
fill 130 188 551 130 191 551 minecraft:blackstone
setblock 131 188 549 minecraft:smooth_basalt
fill 131 188 550 131 191 550 minecraft:blackstone
setblock 132 188 543 minecraft:smooth_basalt
setblock 132 188 544 minecraft:blackstone
setblock 132 188 548 minecraft:smooth_basalt
fill 132 188 549 132 190 549 minecraft:blackstone
setblock 133 188 527 minecraft:smooth_basalt
fill 133 188 528 133 191 528 minecraft:blackstone
setblock 133 188 532 minecraft:smooth_basalt
fill 133 188 533 133 189 533 minecraft:blackstone
setblock 133 188 542 minecraft:smooth_basalt
fill 133 188 543 133 189 543 minecraft:blackstone
setblock 133 188 547 minecraft:smooth_basalt
fill 133 188 548 133 190 548 minecraft:blackstone
setblock 134 188 511 minecraft:smooth_basalt
setblock 134 188 522 minecraft:blackstone
setblock 134 188 526 minecraft:smooth_basalt
fill 134 188 527 134 191 527 minecraft:blackstone
setblock 134 188 531 minecraft:smooth_basalt
fill 134 188 532 134 191 532 minecraft:blackstone
setblock 134 188 536 minecraft:smooth_basalt
fill 134 188 537 134 189 537 minecraft:blackstone
setblock 134 188 541 minecraft:smooth_basalt
fill 134 188 542 134 189 542 minecraft:blackstone
setblock 134 188 546 minecraft:smooth_basalt
fill 134 188 547 134 190 547 minecraft:blackstone
setblock 134 188 551 minecraft:smooth_basalt
setblock 135 188 520 minecraft:smooth_basalt
fill 135 188 521 135 189 521 minecraft:blackstone
setblock 135 188 525 minecraft:smooth_basalt
fill 135 188 526 135 191 526 minecraft:blackstone
setblock 135 188 530 minecraft:smooth_basalt
fill 135 188 531 135 191 531 minecraft:blackstone
setblock 135 188 535 minecraft:smooth_basalt
fill 135 188 536 135 191 536 minecraft:blackstone
setblock 135 188 540 minecraft:smooth_basalt
fill 135 188 541 135 190 541 minecraft:blackstone
setblock 135 188 545 minecraft:smooth_basalt
fill 135 188 546 135 191 546 minecraft:blackstone
setblock 135 188 550 minecraft:smooth_basalt
fill 135 188 551 135 191 551 minecraft:blackstone
setblock 95 189 519 minecraft:smooth_basalt
fill 95 189 520 95 189 523 minecraft:blackstone
setblock 95 189 524 minecraft:smooth_basalt
fill 95 189 525 95 192 525 minecraft:blackstone
setblock 95 189 529 minecraft:smooth_basalt
fill 95 189 530 95 192 530 minecraft:blackstone
setblock 95 189 534 minecraft:smooth_basalt
setblock 95 189 535 minecraft:blackstone
setblock 95 189 544 minecraft:smooth_basalt
setblock 95 189 545 minecraft:blackstone
setblock 95 189 549 minecraft:smooth_basalt
fill 95 189 550 95 190 550 minecraft:blackstone
setblock 96 189 523 minecraft:smooth_basalt
fill 96 189 524 96 190 524 minecraft:blackstone
setblock 96 189 528 minecraft:smooth_basalt
fill 96 189 529 96 192 529 minecraft:blackstone
setblock 97 189 527 minecraft:smooth_basalt
setblock 102 189 511 minecraft:blackstone
setblock 103 189 511 minecraft:smooth_basalt
setblock 103 189 551 minecraft:smooth_basalt
fill 104 189 511 104 192 511 minecraft:blackstone
fill 104 189 551 107 189 551 minecraft:blackstone
fill 105 189 512 105 190 512 minecraft:blackstone
fill 105 189 550 108 189 550 minecraft:blackstone
setblock 107 189 511 minecraft:blackstone
setblock 107 189 512 minecraft:smooth_basalt
fill 107 189 549 109 189 549 minecraft:blackstone
setblock 108 189 511 minecraft:smooth_basalt
fill 108 189 512 108 191 513 minecraft:blackstone
setblock 108 189 551 minecraft:smooth_basalt
fill 109 189 511 109 192 511 minecraft:blackstone
setblock 109 189 550 minecraft:smooth_basalt
fill 109 189 551 109 192 551 minecraft:blackstone
setblock 110 189 549 minecraft:smooth_basalt
fill 110 189 550 110 192 550 minecraft:blackstone
setblock 111 189 513 minecraft:smooth_basalt
fill 111 189 549 111 192 549 minecraft:blackstone
setblock 112 189 512 minecraft:smooth_basalt
setblock 113 189 511 minecraft:smooth_basalt
fill 113 189 512 113 192 512 minecraft:blackstone
setblock 113 189 551 minecraft:smooth_basalt
fill 114 189 511 114 192 511 minecraft:blackstone
setblock 114 189 550 minecraft:smooth_basalt
fill 114 189 551 114 192 551 minecraft:blackstone
setblock 115 189 549 minecraft:smooth_basalt
fill 115 189 550 118 189 550 minecraft:blackstone
setblock 116 189 549 minecraft:blackstone
setblock 118 189 511 minecraft:smooth_basalt
setblock 118 189 551 minecraft:smooth_basalt
setblock 119 189 511 minecraft:blackstone
setblock 119 189 550 minecraft:smooth_basalt
fill 119 189 551 119 192 551 minecraft:blackstone
fill 120 189 550 123 189 550 minecraft:blackstone
fill 123 189 549 124 189 549 minecraft:blackstone
setblock 123 189 551 minecraft:smooth_basalt
fill 124 189 511 127 189 511 minecraft:blackstone
setblock 124 189 550 minecraft:smooth_basalt
fill 124 189 551 124 192 551 minecraft:blackstone
setblock 125 189 549 minecraft:smooth_basalt
fill 125 189 550 125 192 550 minecraft:blackstone
setblock 126 189 548 minecraft:smooth_basalt
fill 126 189 549 126 192 549 minecraft:blackstone
fill 127 189 548 127 190 548 minecraft:blackstone
setblock 128 189 511 minecraft:smooth_basalt
setblock 128 189 551 minecraft:smooth_basalt
fill 129 189 511 129 192 511 minecraft:blackstone
setblock 129 189 550 minecraft:smooth_basalt
fill 129 189 551 129 192 551 minecraft:blackstone
setblock 130 189 549 minecraft:smooth_basalt
fill 130 189 550 130 192 550 minecraft:blackstone
setblock 131 189 548 minecraft:smooth_basalt
fill 131 189 549 131 191 549 minecraft:blackstone
setblock 132 189 547 minecraft:smooth_basalt
setblock 133 189 511 minecraft:smooth_basalt
setblock 133 189 526 minecraft:smooth_basalt
fill 133 189 527 133 191 527 minecraft:blackstone
setblock 133 189 531 minecraft:smooth_basalt
fill 133 189 532 133 191 532 minecraft:blackstone
setblock 133 189 546 minecraft:smooth_basalt
fill 133 189 547 133 190 547 minecraft:blackstone
setblock 133 189 551 minecraft:smooth_basalt
setblock 134 189 525 minecraft:smooth_basalt
fill 134 189 526 134 192 526 minecraft:blackstone
setblock 134 189 530 minecraft:smooth_basalt
fill 134 189 531 134 192 531 minecraft:blackstone
setblock 134 189 535 minecraft:smooth_basalt
setblock 134 189 536 minecraft:blackstone
setblock 134 189 540 minecraft:smooth_basalt
setblock 134 189 541 minecraft:blackstone
setblock 134 189 545 minecraft:smooth_basalt
fill 134 189 546 134 190 546 minecraft:blackstone
setblock 134 189 550 minecraft:smooth_basalt
fill 134 189 551 134 192 551 minecraft:blackstone
setblock 135 189 524 minecraft:smooth_basalt
fill 135 189 525 135 192 525 minecraft:blackstone
setblock 135 189 529 minecraft:smooth_basalt
fill 135 189 530 135 192 530 minecraft:blackstone
setblock 135 189 534 minecraft:smooth_basalt
fill 135 189 535 135 192 535 minecraft:blackstone
setblock 135 189 539 minecraft:smooth_basalt
fill 135 189 540 135 190 540 minecraft:blackstone
setblock 135 189 544 minecraft:smooth_basalt
fill 135 189 545 135 191 545 minecraft:blackstone
setblock 135 189 549 minecraft:smooth_basalt
fill 135 189 550 135 192 550 minecraft:blackstone
fill 95 190 520 95 190 522 minecraft:blackstone
setblock 95 190 523 minecraft:smooth_basalt
fill 95 190 524 95 193 524 minecraft:blackstone
setblock 95 190 528 minecraft:smooth_basalt
fill 95 190 529 95 193 529 minecraft:blackstone
setblock 95 190 533 minecraft:smooth_basalt
fill 95 190 534 95 192 534 minecraft:blackstone
setblock 95 190 548 minecraft:smooth_basalt
setblock 95 190 549 minecraft:blackstone
setblock 96 190 523 minecraft:blackstone
setblock 96 190 527 minecraft:smooth_basalt
fill 96 190 528 96 192 528 minecraft:blackstone
setblock 101 190 511 minecraft:blackstone
setblock 102 190 511 minecraft:smooth_basalt
setblock 102 190 551 minecraft:smooth_basalt
fill 103 190 511 103 193 511 minecraft:blackstone
fill 103 190 551 106 190 551 minecraft:blackstone
fill 104 190 512 104 191 512 minecraft:blackstone
fill 105 190 550 107 190 550 minecraft:blackstone
setblock 106 190 511 minecraft:blackstone
setblock 106 190 512 minecraft:smooth_basalt
setblock 107 190 511 minecraft:smooth_basalt
fill 107 190 512 107 193 512 minecraft:blackstone
fill 107 190 549 108 190 549 minecraft:blackstone
setblock 107 190 551 minecraft:smooth_basalt
fill 108 190 511 108 193 511 minecraft:blackstone
setblock 108 190 550 minecraft:smooth_basalt
fill 108 190 551 108 193 551 minecraft:blackstone
setblock 109 190 549 minecraft:smooth_basalt
fill 109 190 550 109 193 550 minecraft:blackstone
setblock 110 190 513 minecraft:smooth_basalt
fill 110 190 549 110 193 549 minecraft:blackstone
setblock 111 190 512 minecraft:smooth_basalt
setblock 112 190 511 minecraft:smooth_basalt
fill 112 190 512 112 193 512 minecraft:blackstone
setblock 112 190 551 minecraft:smooth_basalt
fill 113 190 511 113 193 511 minecraft:blackstone
setblock 113 190 550 minecraft:smooth_basalt
fill 113 190 551 113 193 551 minecraft:blackstone
setblock 114 190 549 minecraft:smooth_basalt
fill 114 190 550 117 190 550 minecraft:blackstone
setblock 115 190 549 minecraft:blackstone
setblock 117 190 511 minecraft:smooth_basalt
setblock 117 190 551 minecraft:smooth_basalt
fill 118 190 511 118 191 511 minecraft:blackstone
setblock 118 190 550 minecraft:smooth_basalt
fill 118 190 551 118 193 551 minecraft:blackstone
fill 119 190 550 122 190 550 minecraft:blackstone
setblock 122 190 551 minecraft:smooth_basalt
fill 123 190 511 126 190 511 minecraft:blackstone
setblock 123 190 549 minecraft:blackstone
setblock 123 190 550 minecraft:smooth_basalt
fill 123 190 551 123 193 551 minecraft:blackstone
setblock 124 190 549 minecraft:smooth_basalt
fill 124 190 550 124 193 550 minecraft:blackstone
fill 125 190 549 125 193 549 minecraft:blackstone
setblock 127 190 511 minecraft:smooth_basalt
setblock 127 190 551 minecraft:smooth_basalt
fill 128 190 511 128 193 511 minecraft:blackstone
setblock 128 190 550 minecraft:smooth_basalt
fill 128 190 551 128 193 551 minecraft:blackstone
setblock 129 190 549 minecraft:smooth_basalt
fill 129 190 550 129 193 550 minecraft:blackstone
setblock 130 190 548 minecraft:smooth_basalt
fill 130 190 549 130 192 549 minecraft:blackstone
setblock 132 190 511 minecraft:smooth_basalt
setblock 132 190 551 minecraft:smooth_basalt
setblock 133 190 526 minecraft:blackstone
setblock 133 190 530 minecraft:smooth_basalt
fill 133 190 531 133 193 531 minecraft:blackstone
setblock 133 190 550 minecraft:smooth_basalt
fill 133 190 551 133 193 551 minecraft:blackstone
setblock 134 190 524 minecraft:smooth_basalt
fill 134 190 525 134 191 525 minecraft:blackstone
setblock 134 190 529 minecraft:smooth_basalt
fill 134 190 530 134 193 530 minecraft:blackstone
setblock 134 190 534 minecraft:smooth_basalt
setblock 134 190 535 minecraft:blackstone
setblock 134 190 544 minecraft:smooth_basalt
setblock 134 190 545 minecraft:blackstone
setblock 134 190 549 minecraft:smooth_basalt
setblock 134 190 550 minecraft:blackstone
setblock 135 190 523 minecraft:smooth_basalt
fill 135 190 524 135 192 524 minecraft:blackstone
setblock 135 190 528 minecraft:smooth_basalt
fill 135 190 529 135 193 529 minecraft:blackstone
setblock 135 190 533 minecraft:smooth_basalt
fill 135 190 534 135 193 534 minecraft:blackstone
setblock 135 190 538 minecraft:smooth_basalt
setblock 135 190 539 minecraft:blackstone
setblock 135 190 543 minecraft:smooth_basalt
setblock 135 190 544 minecraft:blackstone
setblock 135 190 548 minecraft:smooth_basalt
fill 135 190 549 135 192 549 minecraft:blackstone
setblock 95 191 521 minecraft:blackstone
setblock 95 191 522 minecraft:smooth_basalt
fill 95 191 523 95 192 523 minecraft:blackstone
setblock 95 191 527 minecraft:smooth_basalt
fill 95 191 528 95 194 528 minecraft:blackstone
setblock 95 191 532 minecraft:smooth_basalt
fill 95 191 533 95 194 533 minecraft:blackstone
setblock 96 191 526 minecraft:smooth_basalt
fill 96 191 527 96 192 527 minecraft:blackstone
setblock 101 191 511 minecraft:smooth_basalt
fill 102 191 511 102 194 511 minecraft:blackstone
fill 102 191 551 105 191 551 minecraft:blackstone
fill 104 191 550 106 191 550 minecraft:blackstone
setblock 105 191 512 minecraft:smooth_basalt
setblock 106 191 511 minecraft:smooth_basalt
fill 106 191 512 106 194 512 minecraft:blackstone
setblock 106 191 551 minecraft:smooth_basalt
fill 107 191 511 107 194 511 minecraft:blackstone
setblock 107 191 549 minecraft:blackstone
setblock 107 191 550 minecraft:smooth_basalt
fill 107 191 551 107 194 551 minecraft:blackstone
setblock 108 191 549 minecraft:smooth_basalt
fill 108 191 550 108 194 550 minecraft:blackstone
setblock 109 191 513 minecraft:smooth_basalt
fill 109 191 549 109 194 549 minecraft:blackstone
setblock 110 191 512 minecraft:smooth_basalt
setblock 111 191 511 minecraft:smooth_basalt
fill 111 191 512 111 194 512 minecraft:blackstone
setblock 111 191 551 minecraft:smooth_basalt
fill 112 191 511 112 194 511 minecraft:blackstone
setblock 112 191 550 minecraft:smooth_basalt
fill 112 191 551 112 194 551 minecraft:blackstone
setblock 113 191 549 minecraft:smooth_basalt
fill 113 191 550 116 191 550 minecraft:blackstone
setblock 116 191 511 minecraft:smooth_basalt
setblock 116 191 551 minecraft:smooth_basalt
fill 117 191 511 117 194 511 minecraft:blackstone
setblock 117 191 550 minecraft:smooth_basalt
fill 117 191 551 117 194 551 minecraft:blackstone
fill 118 191 550 121 191 550 minecraft:blackstone
setblock 121 191 551 minecraft:smooth_basalt
setblock 122 191 550 minecraft:smooth_basalt
fill 122 191 551 122 194 551 minecraft:blackstone
fill 123 191 511 125 191 511 minecraft:blackstone
setblock 123 191 549 minecraft:smooth_basalt
fill 123 191 550 123 194 550 minecraft:blackstone
fill 124 191 549 124 194 549 minecraft:blackstone
setblock 126 191 511 minecraft:smooth_basalt
setblock 126 191 551 minecraft:smooth_basalt
fill 127 191 511 127 194 511 minecraft:blackstone
setblock 127 191 550 minecraft:smooth_basalt
fill 127 191 551 127 194 551 minecraft:blackstone
setblock 128 191 549 minecraft:smooth_basalt
fill 128 191 550 128 194 550 minecraft:blackstone
fill 129 191 549 129 193 549 minecraft:blackstone
setblock 131 191 511 minecraft:smooth_basalt
setblock 131 191 551 minecraft:smooth_basalt
fill 132 191 511 132 192 511 minecraft:blackstone
setblock 132 191 550 minecraft:smooth_basalt
fill 132 191 551 132 194 551 minecraft:blackstone
setblock 133 191 529 minecraft:smooth_basalt
fill 133 191 530 133 193 530 minecraft:blackstone
setblock 133 191 550 minecraft:blackstone
setblock 134 191 528 minecraft:smooth_basalt
fill 134 191 529 134 194 529 minecraft:blackstone
setblock 134 191 533 minecraft:smooth_basalt
fill 134 191 534 134 194 534 minecraft:blackstone
setblock 134 191 548 minecraft:smooth_basalt
setblock 134 191 549 minecraft:blackstone
setblock 135 191 523 minecraft:blackstone
setblock 135 191 527 minecraft:smooth_basalt
fill 135 191 528 135 194 528 minecraft:blackstone
setblock 135 191 532 minecraft:smooth_basalt
fill 135 191 533 135 194 533 minecraft:blackstone
setblock 135 191 537 minecraft:smooth_basalt
setblock 135 191 547 minecraft:smooth_basalt
setblock 135 191 548 minecraft:blackstone
setblock 95 192 526 minecraft:smooth_basalt
fill 95 192 527 95 195 527 minecraft:blackstone
setblock 95 192 531 minecraft:smooth_basalt
fill 95 192 532 95 195 532 minecraft:blackstone
setblock 96 192 530 minecraft:smooth_basalt
setblock 97 192 521 minecraft:light[level=12]
setblock 97 192 529 minecraft:light[level=12]
setblock 97 192 537 minecraft:light[level=12]
setblock 97 192 545 minecraft:light[level=12]
setblock 100 192 511 minecraft:smooth_basalt
fill 101 192 511 101 195 511 minecraft:blackstone
fill 102 192 551 104 192 551 minecraft:blackstone
setblock 103 192 512 minecraft:blackstone
setblock 104 192 512 minecraft:smooth_basalt
fill 104 192 550 105 192 550 minecraft:blackstone
setblock 105 192 511 minecraft:smooth_basalt
fill 105 192 512 105 195 512 minecraft:blackstone
setblock 105 192 513 minecraft:light[level=12]
setblock 105 192 521 minecraft:light[level=12]
setblock 105 192 529 minecraft:light[level=12]
setblock 105 192 537 minecraft:light[level=12]
setblock 105 192 545 minecraft:light[level=12]
setblock 105 192 551 minecraft:smooth_basalt
fill 106 192 511 106 195 511 minecraft:blackstone
setblock 106 192 550 minecraft:smooth_basalt
fill 106 192 551 106 195 551 minecraft:blackstone
setblock 107 192 513 minecraft:blackstone
setblock 107 192 549 minecraft:smooth_basalt
fill 107 192 550 107 195 550 minecraft:blackstone
setblock 108 192 512 minecraft:blackstone
setblock 108 192 513 minecraft:smooth_basalt
fill 108 192 549 108 195 549 minecraft:blackstone
setblock 109 192 512 minecraft:smooth_basalt
fill 109 192 513 109 195 513 minecraft:blackstone
setblock 110 192 511 minecraft:smooth_basalt
fill 110 192 512 110 195 512 minecraft:blackstone
setblock 110 192 551 minecraft:smooth_basalt
fill 111 192 511 111 195 511 minecraft:blackstone
setblock 111 192 550 minecraft:smooth_basalt
fill 111 192 551 111 195 551 minecraft:blackstone
setblock 112 192 549 minecraft:smooth_basalt
fill 112 192 550 115 192 550 minecraft:blackstone
setblock 113 192 513 minecraft:light[level=12]
setblock 113 192 521 minecraft:light[level=12]
setblock 113 192 529 minecraft:light[level=12]
setblock 113 192 537 minecraft:light[level=12]
setblock 113 192 545 minecraft:light[level=12]
setblock 115 192 511 minecraft:smooth_basalt
setblock 115 192 551 minecraft:smooth_basalt
fill 116 192 511 116 195 511 minecraft:blackstone
setblock 116 192 550 minecraft:smooth_basalt
fill 116 192 551 116 195 551 minecraft:blackstone
fill 117 192 550 120 192 550 minecraft:blackstone
setblock 120 192 551 minecraft:smooth_basalt
setblock 121 192 513 minecraft:light[level=12]
setblock 121 192 521 minecraft:light[level=12]
setblock 121 192 529 minecraft:light[level=12]
setblock 121 192 537 minecraft:light[level=12]
setblock 121 192 545 minecraft:light[level=12]
setblock 121 192 550 minecraft:smooth_basalt
fill 121 192 551 121 195 551 minecraft:blackstone
fill 122 192 511 124 192 511 minecraft:blackstone
fill 122 192 550 122 195 550 minecraft:blackstone
setblock 125 192 511 minecraft:smooth_basalt
setblock 125 192 551 minecraft:smooth_basalt
fill 126 192 511 126 195 511 minecraft:blackstone
setblock 126 192 550 minecraft:smooth_basalt
fill 126 192 551 126 195 551 minecraft:blackstone
setblock 127 192 549 minecraft:smooth_basalt
fill 127 192 550 127 195 550 minecraft:blackstone
fill 128 192 549 128 194 549 minecraft:blackstone
setblock 129 192 513 minecraft:light[level=12]
setblock 129 192 521 minecraft:light[level=12]
setblock 129 192 529 minecraft:light[level=12]
setblock 129 192 537 minecraft:light[level=12]
setblock 129 192 545 minecraft:light[level=12]
setblock 130 192 511 minecraft:smooth_basalt
setblock 130 192 551 minecraft:smooth_basalt
fill 131 192 511 131 195 511 minecraft:blackstone
setblock 131 192 550 minecraft:smooth_basalt
fill 131 192 551 131 195 551 minecraft:blackstone
fill 132 192 550 132 193 550 minecraft:blackstone
setblock 133 192 529 minecraft:blackstone
setblock 134 192 527 minecraft:smooth_basalt
fill 134 192 528 134 195 528 minecraft:blackstone
setblock 134 192 532 minecraft:smooth_basalt
fill 134 192 533 134 195 533 minecraft:blackstone
setblock 135 192 526 minecraft:smooth_basalt
fill 135 192 527 135 195 527 minecraft:blackstone
setblock 135 192 531 minecraft:smooth_basalt
fill 135 192 532 135 195 532 minecraft:blackstone
setblock 135 192 536 minecraft:smooth_basalt
setblock 95 193 525 minecraft:smooth_basalt
fill 95 193 526 95 196 526 minecraft:blackstone
setblock 95 193 530 minecraft:smooth_basalt
fill 95 193 531 95 196 531 minecraft:blackstone
setblock 99 193 511 minecraft:smooth_basalt
fill 100 193 511 100 196 511 minecraft:blackstone
fill 101 193 551 103 193 551 minecraft:blackstone
setblock 102 193 512 minecraft:blackstone
setblock 103 193 512 minecraft:smooth_basalt
setblock 104 193 511 minecraft:smooth_basalt
fill 104 193 512 104 196 512 minecraft:blackstone
setblock 104 193 550 minecraft:blackstone
setblock 104 193 551 minecraft:smooth_basalt
fill 105 193 511 105 196 511 minecraft:blackstone
fill 105 193 513 106 193 513 minecraft:blackstone
setblock 105 193 550 minecraft:smooth_basalt
fill 105 193 551 105 196 551 minecraft:blackstone
fill 106 193 550 106 196 550 minecraft:blackstone
setblock 107 193 513 minecraft:smooth_basalt
fill 107 193 549 107 196 549 minecraft:blackstone
setblock 108 193 512 minecraft:smooth_basalt
fill 108 193 513 108 196 513 minecraft:blackstone
setblock 109 193 511 minecraft:smooth_basalt
fill 109 193 512 109 196 512 minecraft:blackstone
setblock 109 193 551 minecraft:smooth_basalt
fill 110 193 511 110 196 511 minecraft:blackstone
setblock 110 193 550 minecraft:smooth_basalt
fill 110 193 551 110 196 551 minecraft:blackstone
setblock 111 193 549 minecraft:smooth_basalt
fill 111 193 550 114 193 550 minecraft:blackstone
setblock 113 193 512 minecraft:smooth_basalt
setblock 114 193 511 minecraft:smooth_basalt
setblock 114 193 551 minecraft:smooth_basalt
fill 115 193 511 115 196 511 minecraft:blackstone
setblock 115 193 550 minecraft:smooth_basalt
fill 115 193 551 115 196 551 minecraft:blackstone
fill 116 193 550 119 193 550 minecraft:blackstone
setblock 118 193 511 minecraft:blackstone
setblock 119 193 551 minecraft:smooth_basalt
fill 120 193 511 123 193 511 minecraft:blackstone
setblock 120 193 550 minecraft:smooth_basalt
fill 120 193 551 120 196 551 minecraft:blackstone
fill 121 193 550 121 196 550 minecraft:blackstone
setblock 124 193 511 minecraft:smooth_basalt
setblock 124 193 551 minecraft:smooth_basalt
fill 125 193 511 125 196 511 minecraft:blackstone
setblock 125 193 550 minecraft:smooth_basalt
fill 125 193 551 125 196 551 minecraft:blackstone
setblock 126 193 549 minecraft:smooth_basalt
fill 126 193 550 126 196 550 minecraft:blackstone
fill 127 193 549 127 196 549 minecraft:blackstone
setblock 129 193 511 minecraft:smooth_basalt
setblock 129 193 551 minecraft:smooth_basalt
fill 130 193 511 130 196 511 minecraft:blackstone
setblock 130 193 550 minecraft:smooth_basalt
fill 130 193 551 130 196 551 minecraft:blackstone
fill 131 193 550 131 194 550 minecraft:blackstone
setblock 134 193 527 minecraft:blackstone
setblock 134 193 531 minecraft:smooth_basalt
fill 134 193 532 134 196 532 minecraft:blackstone
setblock 134 193 551 minecraft:smooth_basalt
setblock 135 193 525 minecraft:smooth_basalt
fill 135 193 526 135 196 526 minecraft:blackstone
setblock 135 193 530 minecraft:smooth_basalt
fill 135 193 531 135 196 531 minecraft:blackstone
setblock 135 193 535 minecraft:smooth_basalt
fill 135 193 536 135 196 536 minecraft:blackstone
fill 95 194 525 95 195 525 minecraft:blackstone
setblock 95 194 529 minecraft:smooth_basalt
fill 95 194 530 95 197 530 minecraft:blackstone
setblock 95 194 534 minecraft:smooth_basalt
fill 96 194 511 97 194 511 minecraft:blackstone
setblock 98 194 511 minecraft:smooth_basalt
fill 99 194 511 99 197 511 minecraft:blackstone
setblock 101 194 512 minecraft:blackstone
fill 101 194 551 102 194 551 minecraft:blackstone
setblock 102 194 512 minecraft:smooth_basalt
setblock 103 194 511 minecraft:smooth_basalt
fill 103 194 512 103 197 512 minecraft:blackstone
setblock 103 194 550 minecraft:blackstone
setblock 103 194 551 minecraft:smooth_basalt
fill 104 194 511 104 197 511 minecraft:blackstone
fill 104 194 513 105 194 513 minecraft:blackstone
setblock 104 194 550 minecraft:smooth_basalt
fill 104 194 551 104 197 551 minecraft:blackstone
fill 105 194 550 105 197 550 minecraft:blackstone
setblock 106 194 513 minecraft:smooth_basalt
setblock 107 194 512 minecraft:smooth_basalt
fill 107 194 513 107 197 513 minecraft:blackstone
setblock 108 194 511 minecraft:smooth_basalt
fill 108 194 512 108 197 512 minecraft:blackstone
setblock 108 194 551 minecraft:smooth_basalt
fill 109 194 511 109 197 511 minecraft:blackstone
setblock 109 194 550 minecraft:smooth_basalt
fill 109 194 551 109 197 551 minecraft:blackstone
setblock 110 194 513 minecraft:blackstone
fill 110 194 550 113 194 550 minecraft:blackstone
setblock 112 194 512 minecraft:smooth_basalt
setblock 113 194 511 minecraft:smooth_basalt
fill 113 194 512 113 197 512 minecraft:blackstone
setblock 113 194 551 minecraft:smooth_basalt
fill 114 194 511 114 197 511 minecraft:blackstone
setblock 114 194 550 minecraft:smooth_basalt
fill 114 194 551 114 197 551 minecraft:blackstone
fill 115 194 550 116 196 550 minecraft:blackstone
setblock 118 194 511 minecraft:smooth_basalt
setblock 118 194 550 minecraft:blackstone
setblock 118 194 551 minecraft:smooth_basalt
fill 119 194 511 122 194 511 minecraft:blackstone
setblock 119 194 550 minecraft:smooth_basalt
fill 119 194 551 119 197 551 minecraft:blackstone
fill 120 194 550 120 197 550 minecraft:blackstone
fill 121 194 525 121 195 525 minecraft:gilded_blackstone
setblock 123 194 511 minecraft:smooth_basalt
setblock 123 194 551 minecraft:smooth_basalt
fill 124 194 511 124 197 511 minecraft:blackstone
setblock 124 194 550 minecraft:smooth_basalt
fill 124 194 551 124 197 551 minecraft:blackstone
setblock 125 194 549 minecraft:smooth_basalt
fill 125 194 550 125 197 550 minecraft:blackstone
fill 126 194 549 126 197 549 minecraft:blackstone
setblock 128 194 511 minecraft:smooth_basalt
setblock 128 194 551 minecraft:smooth_basalt
fill 129 194 511 129 197 511 minecraft:blackstone
setblock 129 194 550 minecraft:smooth_basalt
fill 129 194 551 129 197 551 minecraft:blackstone
fill 130 194 550 130 196 550 minecraft:blackstone
setblock 132 194 511 minecraft:blackstone
setblock 133 194 551 minecraft:smooth_basalt
setblock 134 194 530 minecraft:smooth_basalt
fill 134 194 531 134 197 531 minecraft:blackstone
setblock 135 194 529 minecraft:smooth_basalt
fill 135 194 530 135 197 530 minecraft:blackstone
setblock 135 194 534 minecraft:smooth_basalt
fill 135 194 535 135 197 535 minecraft:blackstone
fill 95 195 511 95 195 512 minecraft:blackstone
setblock 95 195 513 minecraft:smooth_basalt
setblock 95 195 528 minecraft:smooth_basalt
fill 95 195 529 95 198 529 minecraft:blackstone
setblock 95 195 533 minecraft:smooth_basalt
fill 95 195 534 95 198 534 minecraft:blackstone
setblock 96 195 511 minecraft:blackstone
setblock 97 195 511 minecraft:smooth_basalt
fill 98 195 511 98 198 511 minecraft:blackstone
setblock 98 195 512 minecraft:smooth_basalt
fill 99 195 512 100 195 512 minecraft:blackstone
fill 100 195 551 101 195 551 minecraft:blackstone
setblock 101 195 512 minecraft:smooth_basalt
setblock 102 195 511 minecraft:smooth_basalt
fill 102 195 512 102 197 513 minecraft:blackstone
setblock 102 195 551 minecraft:smooth_basalt
fill 103 195 511 103 198 511 minecraft:blackstone
fill 103 195 513 104 195 513 minecraft:blackstone
setblock 103 195 550 minecraft:smooth_basalt
fill 103 195 551 103 198 551 minecraft:blackstone
fill 104 195 550 104 198 550 minecraft:blackstone
setblock 105 195 513 minecraft:smooth_basalt
setblock 106 195 512 minecraft:smooth_basalt
fill 106 195 513 106 198 513 minecraft:blackstone
setblock 107 195 511 minecraft:smooth_basalt
fill 107 195 512 107 198 512 minecraft:blackstone
setblock 107 195 551 minecraft:smooth_basalt
fill 108 195 511 108 198 511 minecraft:blackstone
setblock 108 195 550 minecraft:smooth_basalt
fill 108 195 551 108 198 551 minecraft:blackstone
setblock 109 195 549 minecraft:smooth_basalt
fill 109 195 550 112 195 550 minecraft:blackstone
setblock 110 195 513 minecraft:smooth_basalt
setblock 111 195 512 minecraft:smooth_basalt
setblock 112 195 511 minecraft:smooth_basalt
fill 112 195 512 112 198 512 minecraft:blackstone
setblock 112 195 551 minecraft:smooth_basalt
fill 113 195 511 113 198 511 minecraft:blackstone
setblock 113 195 550 minecraft:smooth_basalt
fill 113 195 551 113 198 551 minecraft:blackstone
fill 114 195 550 114 198 550 minecraft:blackstone
setblock 117 195 511 minecraft:smooth_basalt
setblock 117 195 551 minecraft:smooth_basalt
fill 118 195 511 121 195 511 minecraft:blackstone
setblock 118 195 550 minecraft:smooth_basalt
fill 118 195 551 118 198 551 minecraft:blackstone
fill 119 195 550 119 198 550 minecraft:blackstone
setblock 122 195 511 minecraft:smooth_basalt
setblock 122 195 551 minecraft:smooth_basalt
fill 123 195 511 123 198 511 minecraft:blackstone
setblock 123 195 550 minecraft:smooth_basalt
fill 123 195 551 123 198 551 minecraft:blackstone
fill 124 195 512 125 195 512 minecraft:blackstone
setblock 124 195 549 minecraft:smooth_basalt
fill 124 195 550 124 198 550 minecraft:blackstone
fill 125 195 549 125 198 549 minecraft:blackstone
setblock 126 195 512 minecraft:smooth_basalt
setblock 127 195 511 minecraft:smooth_basalt
fill 127 195 512 128 197 512 minecraft:blackstone
setblock 127 195 551 minecraft:smooth_basalt
fill 128 195 511 128 198 511 minecraft:blackstone
setblock 128 195 550 minecraft:smooth_basalt
fill 128 195 551 128 198 551 minecraft:blackstone
fill 129 195 550 129 198 550 minecraft:blackstone
setblock 132 195 511 minecraft:smooth_basalt
setblock 132 195 551 minecraft:smooth_basalt
fill 133 195 532 133 197 532 minecraft:blackstone
setblock 133 195 551 minecraft:blackstone
setblock 134 195 529 minecraft:smooth_basalt
fill 134 195 530 134 198 530 minecraft:blackstone
setblock 134 195 534 minecraft:smooth_basalt
fill 134 195 535 134 198 535 minecraft:blackstone
setblock 135 195 528 minecraft:smooth_basalt
fill 135 195 529 135 198 529 minecraft:blackstone
setblock 135 195 533 minecraft:smooth_basalt
fill 135 195 534 135 198 534 minecraft:blackstone
setblock 135 195 537 minecraft:blackstone
setblock 95 196 511 minecraft:blackstone
setblock 95 196 512 minecraft:smooth_basalt
fill 95 196 513 95 196 516 minecraft:blackstone
setblock 95 196 527 minecraft:smooth_basalt
fill 95 196 528 95 199 528 minecraft:blackstone
setblock 95 196 532 minecraft:smooth_basalt
fill 95 196 533 95 199 533 minecraft:blackstone
setblock 96 196 511 minecraft:smooth_basalt
fill 97 196 511 97 199 511 minecraft:blackstone
fill 98 196 512 99 196 512 minecraft:blackstone
fill 99 196 551 100 196 551 minecraft:blackstone
setblock 100 196 512 minecraft:smooth_basalt
setblock 101 196 511 minecraft:smooth_basalt
fill 101 196 512 101 198 513 minecraft:blackstone
setblock 101 196 551 minecraft:smooth_basalt
fill 102 196 511 102 199 511 minecraft:blackstone
setblock 102 196 550 minecraft:smooth_basalt
fill 102 196 551 102 199 551 minecraft:blackstone
setblock 103 196 513 minecraft:blackstone
fill 103 196 550 103 199 550 minecraft:blackstone
setblock 104 196 513 minecraft:smooth_basalt
setblock 105 196 512 minecraft:smooth_basalt
fill 105 196 513 105 198 514 minecraft:blackstone
setblock 106 196 511 minecraft:smooth_basalt
fill 106 196 512 106 199 512 minecraft:blackstone
fill 106 196 514 106 197 514 minecraft:blackstone
fill 106 196 549 106 197 549 minecraft:blackstone
setblock 106 196 551 minecraft:smooth_basalt
fill 107 196 511 107 199 511 minecraft:blackstone
setblock 107 196 550 minecraft:smooth_basalt
fill 107 196 551 107 199 551 minecraft:blackstone
setblock 108 196 549 minecraft:smooth_basalt
fill 108 196 550 111 196 550 minecraft:blackstone
setblock 109 196 513 minecraft:smooth_basalt
setblock 110 196 512 minecraft:smooth_basalt
fill 110 196 513 110 199 513 minecraft:blackstone
setblock 111 196 511 minecraft:smooth_basalt
fill 111 196 512 111 199 512 minecraft:blackstone
setblock 111 196 551 minecraft:smooth_basalt
fill 112 196 511 112 199 511 minecraft:blackstone
setblock 112 196 550 minecraft:smooth_basalt
fill 112 196 551 112 199 551 minecraft:blackstone
fill 113 196 550 113 199 550 minecraft:blackstone
setblock 114 196 512 minecraft:blackstone
setblock 116 196 511 minecraft:smooth_basalt
setblock 116 196 551 minecraft:smooth_basalt
fill 117 196 511 120 196 511 minecraft:blackstone
setblock 117 196 550 minecraft:smooth_basalt
fill 117 196 551 117 199 551 minecraft:blackstone
fill 118 196 550 118 199 550 minecraft:blackstone
setblock 121 196 511 minecraft:smooth_basalt
setblock 121 196 551 minecraft:smooth_basalt
fill 122 196 511 122 198 512 minecraft:blackstone
setblock 122 196 550 minecraft:smooth_basalt
fill 122 196 551 122 199 551 minecraft:blackstone
fill 123 196 512 124 196 512 minecraft:blackstone
setblock 123 196 549 minecraft:smooth_basalt
fill 123 196 550 123 199 550 minecraft:blackstone
fill 124 196 549 124 199 549 minecraft:blackstone
setblock 125 196 512 minecraft:smooth_basalt
setblock 126 196 511 minecraft:smooth_basalt
fill 126 196 512 126 199 512 minecraft:blackstone
setblock 126 196 551 minecraft:smooth_basalt
fill 127 196 511 127 199 511 minecraft:blackstone
setblock 127 196 550 minecraft:smooth_basalt
fill 127 196 551 127 199 551 minecraft:blackstone
fill 128 196 550 128 199 550 minecraft:blackstone
setblock 129 196 512 minecraft:blackstone
setblock 131 196 511 minecraft:smooth_basalt
setblock 131 196 551 minecraft:smooth_basalt
fill 132 196 511 132 199 511 minecraft:blackstone
fill 132 196 551 132 197 551 minecraft:blackstone
fill 133 196 531 133 198 531 minecraft:blackstone
setblock 133 196 533 minecraft:blackstone
setblock 134 196 528 minecraft:smooth_basalt
fill 134 196 529 134 199 529 minecraft:blackstone
setblock 134 196 533 minecraft:smooth_basalt
fill 134 196 534 134 199 534 minecraft:blackstone
setblock 135 196 527 minecraft:smooth_basalt
fill 135 196 528 135 199 528 minecraft:blackstone
setblock 135 196 532 minecraft:smooth_basalt
fill 135 196 533 135 199 533 minecraft:blackstone
setblock 135 196 537 minecraft:smooth_basalt
setblock 95 197 511 minecraft:smooth_basalt
fill 95 197 512 95 197 515 minecraft:blackstone
setblock 95 197 516 minecraft:smooth_basalt
fill 95 197 517 95 199 518 minecraft:blackstone
setblock 95 197 526 minecraft:smooth_basalt
fill 95 197 527 95 200 527 minecraft:blackstone
setblock 95 197 531 minecraft:smooth_basalt
fill 95 197 532 95 200 532 minecraft:blackstone
setblock 95 197 535 minecraft:blackstone
fill 96 197 511 96 197 514 minecraft:blackstone
fill 97 197 512 98 197 512 minecraft:blackstone
fill 98 197 551 99 197 551 minecraft:blackstone
setblock 99 197 512 minecraft:smooth_basalt
fill 99 197 513 100 199 513 minecraft:blackstone
setblock 100 197 511 minecraft:smooth_basalt
fill 100 197 512 100 200 512 minecraft:blackstone
setblock 100 197 551 minecraft:smooth_basalt
fill 101 197 511 101 200 511 minecraft:blackstone
setblock 101 197 550 minecraft:smooth_basalt
fill 101 197 551 101 200 551 minecraft:blackstone
setblock 102 197 514 minecraft:smooth_basalt
fill 102 197 550 102 200 550 minecraft:blackstone
setblock 103 197 513 minecraft:smooth_basalt
fill 103 197 514 104 199 514 minecraft:blackstone
setblock 104 197 512 minecraft:smooth_basalt
fill 104 197 513 104 200 513 minecraft:blackstone
setblock 105 197 511 minecraft:smooth_basalt
fill 105 197 512 105 200 512 minecraft:blackstone
setblock 105 197 551 minecraft:smooth_basalt
fill 106 197 511 106 200 511 minecraft:blackstone
setblock 106 197 550 minecraft:smooth_basalt
fill 106 197 551 106 200 551 minecraft:blackstone
setblock 107 197 514 minecraft:smooth_basalt
setblock 107 197 549 minecraft:smooth_basalt
fill 107 197 550 110 197 550 minecraft:blackstone
setblock 108 197 513 minecraft:smooth_basalt
setblock 108 197 549 minecraft:blackstone
setblock 109 197 512 minecraft:smooth_basalt
fill 109 197 513 109 200 513 minecraft:blackstone
setblock 110 197 511 minecraft:smooth_basalt
fill 110 197 512 110 200 512 minecraft:blackstone
setblock 110 197 551 minecraft:smooth_basalt
fill 111 197 511 111 200 511 minecraft:blackstone
fill 111 197 513 111 198 513 minecraft:blackstone
setblock 111 197 550 minecraft:smooth_basalt
fill 111 197 551 111 200 551 minecraft:blackstone
fill 112 197 550 112 199 550 minecraft:blackstone
setblock 114 197 512 minecraft:smooth_basalt
setblock 115 197 511 minecraft:smooth_basalt
setblock 115 197 550 minecraft:blackstone
setblock 115 197 551 minecraft:smooth_basalt
fill 116 197 511 119 197 511 minecraft:blackstone
setblock 116 197 550 minecraft:smooth_basalt
fill 116 197 551 116 200 551 minecraft:blackstone
fill 117 197 550 117 200 550 minecraft:blackstone
setblock 120 197 511 minecraft:smooth_basalt
fill 120 197 512 121 199 512 minecraft:blackstone
setblock 120 197 551 minecraft:smooth_basalt
fill 121 197 511 121 200 511 minecraft:blackstone
setblock 121 197 550 minecraft:smooth_basalt
fill 121 197 551 121 200 551 minecraft:blackstone
fill 122 197 550 122 200 550 minecraft:blackstone
setblock 123 197 512 minecraft:blackstone
fill 123 197 549 123 199 549 minecraft:blackstone
setblock 124 197 512 minecraft:smooth_basalt
setblock 125 197 511 minecraft:smooth_basalt
fill 125 197 512 125 200 512 minecraft:blackstone
setblock 125 197 551 minecraft:smooth_basalt
fill 126 197 511 126 200 511 minecraft:blackstone
setblock 126 197 550 minecraft:smooth_basalt
fill 126 197 551 126 200 551 minecraft:blackstone
fill 127 197 550 127 200 550 minecraft:blackstone
setblock 129 197 512 minecraft:smooth_basalt
setblock 130 197 511 minecraft:smooth_basalt
setblock 130 197 551 minecraft:smooth_basalt
fill 131 197 511 131 200 511 minecraft:blackstone
fill 131 197 551 131 198 551 minecraft:blackstone
fill 133 197 511 133 198 511 minecraft:blackstone
setblock 133 197 533 minecraft:smooth_basalt
fill 133 197 534 133 200 534 minecraft:blackstone
setblock 134 197 528 minecraft:blackstone
setblock 134 197 532 minecraft:smooth_basalt
fill 134 197 533 134 200 533 minecraft:blackstone
setblock 134 197 536 minecraft:blackstone
setblock 135 197 526 minecraft:smooth_basalt
fill 135 197 527 135 200 527 minecraft:blackstone
setblock 135 197 531 minecraft:smooth_basalt
fill 135 197 532 135 200 532 minecraft:blackstone
setblock 135 197 536 minecraft:smooth_basalt
fill 135 197 537 135 199 538 minecraft:blackstone
setblock 94 198 510 minecraft:basalt
fill 94 198 511 96 198 513 minecraft:blackstone
setblock 94 198 515 minecraft:basalt
fill 94 198 516 94 199 526 minecraft:blackstone
setblock 94 198 527 minecraft:basalt
setblock 94 198 528 minecraft:blackstone
setblock 94 198 532 minecraft:basalt
fill 94 198 533 94 199 539 minecraft:blackstone
setblock 95 198 514 minecraft:blackstone
setblock 95 198 515 minecraft:smooth_basalt
fill 95 198 516 96 200 516 minecraft:blackstone
setblock 95 198 519 minecraft:blackstone
setblock 95 198 520 minecraft:smooth_basalt
fill 95 198 526 95 199 526 minecraft:blackstone
setblock 95 198 530 minecraft:smooth_basalt
fill 95 198 531 95 201 531 minecraft:blackstone
setblock 95 198 535 minecraft:smooth_basalt
fill 95 198 536 95 201 536 minecraft:blackstone
setblock 96 198 514 minecraft:smooth_basalt
fill 96 198 515 96 201 515 minecraft:blackstone
fill 97 198 510 97 201 510 minecraft:blackstone
setblock 97 198 512 minecraft:blackstone
setblock 98 198 510 minecraft:basalt
setblock 98 198 512 minecraft:smooth_basalt
fill 98 198 513 98 201 513 minecraft:blackstone
setblock 98 198 551 minecraft:blackstone
setblock 99 198 511 minecraft:smooth_basalt
fill 99 198 512 99 201 512 minecraft:blackstone
setblock 99 198 551 minecraft:smooth_basalt
fill 100 198 511 100 201 511 minecraft:blackstone
fill 100 198 551 100 201 551 minecraft:blackstone
setblock 101 198 514 minecraft:smooth_basalt
fill 101 198 550 101 201 550 minecraft:blackstone
setblock 102 198 512 minecraft:blackstone
setblock 102 198 513 minecraft:smooth_basalt
fill 102 198 514 102 201 514 minecraft:blackstone
fill 102 198 552 102 201 552 minecraft:blackstone
setblock 103 198 512 minecraft:smooth_basalt
fill 103 198 513 103 201 513 minecraft:blackstone
fill 103 198 552 103 199 552 minecraft:basalt
setblock 104 198 511 minecraft:smooth_basalt
fill 104 198 512 104 201 512 minecraft:blackstone
setblock 104 198 551 minecraft:smooth_basalt
fill 104 198 552 104 201 552 minecraft:blackstone
fill 105 198 511 105 201 511 minecraft:blackstone
setblock 105 198 549 minecraft:blackstone
setblock 105 198 550 minecraft:smooth_basalt
fill 105 198 551 105 201 551 minecraft:blackstone
setblock 106 198 514 minecraft:smooth_basalt
setblock 106 198 549 minecraft:smooth_basalt
fill 106 198 550 109 198 550 minecraft:blackstone
setblock 106 198 552 minecraft:basalt
setblock 107 198 513 minecraft:smooth_basalt
fill 107 198 514 108 200 514 minecraft:blackstone
setblock 107 198 549 minecraft:blackstone
fill 107 198 552 109 201 552 minecraft:blackstone
setblock 108 198 512 minecraft:smooth_basalt
fill 108 198 513 108 201 513 minecraft:blackstone
setblock 109 198 511 minecraft:smooth_basalt
fill 109 198 512 109 201 512 minecraft:blackstone
setblock 109 198 551 minecraft:smooth_basalt
fill 110 198 511 110 201 511 minecraft:blackstone
setblock 110 198 550 minecraft:smooth_basalt
fill 110 198 551 110 201 551 minecraft:blackstone
fill 111 198 550 111 200 550 minecraft:blackstone
fill 111 198 552 111 201 552 minecraft:blackstone
setblock 112 198 552 minecraft:basalt
setblock 113 198 512 minecraft:smooth_basalt
fill 113 198 552 116 201 552 minecraft:blackstone
setblock 114 198 511 minecraft:smooth_basalt
fill 114 198 512 115 200 512 minecraft:blackstone
setblock 114 198 551 minecraft:smooth_basalt
fill 115 198 510 116 200 511 minecraft:blackstone
setblock 115 198 550 minecraft:smooth_basalt
fill 115 198 551 115 201 551 minecraft:blackstone
fill 116 198 550 116 199 550 minecraft:blackstone
fill 117 198 510 117 199 510 minecraft:basalt
fill 117 198 511 118 198 511 minecraft:blackstone
fill 118 198 510 119 198 510 minecraft:blackstone
setblock 118 198 512 minecraft:smooth_basalt
fill 118 198 552 119 198 552 minecraft:blackstone
setblock 119 198 511 minecraft:smooth_basalt
fill 119 198 512 119 201 512 minecraft:blackstone
setblock 119 198 551 minecraft:smooth_basalt
setblock 120 198 510 minecraft:basalt
fill 120 198 511 120 201 511 minecraft:blackstone
setblock 120 198 550 minecraft:smooth_basalt
fill 120 198 551 120 201 551 minecraft:blackstone
setblock 120 198 552 minecraft:basalt
fill 121 198 510 123 201 510 minecraft:blackstone
fill 121 198 550 121 201 550 minecraft:blackstone
fill 121 198 552 124 199 552 minecraft:blackstone
fill 122 198 549 122 199 549 minecraft:blackstone
setblock 123 198 512 minecraft:smooth_basalt
setblock 124 198 511 minecraft:smooth_basalt
fill 124 198 512 124 201 512 minecraft:blackstone
setblock 124 198 551 minecraft:smooth_basalt
fill 125 198 510 125 201 511 minecraft:blackstone
setblock 125 198 550 minecraft:smooth_basalt
fill 125 198 551 125 201 551 minecraft:blackstone
setblock 125 198 552 minecraft:basalt
fill 126 198 510 126 201 510 minecraft:blackstone
fill 126 198 550 126 201 550 minecraft:blackstone
fill 126 198 552 128 198 552 minecraft:blackstone
fill 127 198 510 128 198 510 minecraft:basalt
setblock 127 198 512 minecraft:blackstone
setblock 128 198 512 minecraft:smooth_basalt
fill 129 198 510 130 199 510 minecraft:blackstone
setblock 129 198 511 minecraft:smooth_basalt
fill 129 198 512 129 200 512 minecraft:blackstone
setblock 129 198 551 minecraft:smooth_basalt
fill 129 198 552 129 200 552 minecraft:basalt
fill 130 198 511 130 201 511 minecraft:blackstone
fill 130 198 551 130 200 552 minecraft:blackstone
fill 131 198 510 132 198 510 minecraft:basalt
fill 131 198 552 135 201 552 minecraft:blackstone
setblock 133 198 532 minecraft:smooth_basalt
fill 133 198 533 133 200 533 minecraft:blackstone
fill 133 198 535 133 199 535 minecraft:blackstone
setblock 134 198 511 minecraft:smooth_basalt
setblock 134 198 531 minecraft:smooth_basalt
fill 134 198 532 134 201 532 minecraft:blackstone
setblock 134 198 536 minecraft:smooth_basalt
fill 134 198 537 134 201 537 minecraft:blackstone
fill 135 198 511 135 198 514 minecraft:blackstone
setblock 135 198 515 minecraft:smooth_basalt
fill 135 198 516 135 201 516 minecraft:blackstone
fill 135 198 526 135 201 526 minecraft:blackstone
setblock 135 198 530 minecraft:smooth_basalt
fill 135 198 531 135 201 531 minecraft:blackstone
setblock 135 198 535 minecraft:smooth_basalt
fill 135 198 536 135 201 536 minecraft:blackstone
setblock 135 198 539 minecraft:blackstone
setblock 136 198 517 minecraft:basalt
setblock 136 198 534 minecraft:basalt
fill 136 198 535 136 201 535 minecraft:blackstone
fill 136 198 537 136 198 538 minecraft:basalt
fill 94 199 510 94 199 513 minecraft:blackstone
fill 94 199 515 95 201 515 minecraft:blackstone
fill 94 199 527 94 201 527 minecraft:blackstone
fill 94 199 528 94 200 528 minecraft:basalt
fill 94 199 532 94 201 532 minecraft:blackstone
fill 94 199 543 94 199 544 minecraft:basalt
fill 94 199 545 94 201 546 minecraft:blackstone
fill 95 199 511 95 199 513 minecraft:blackstone
setblock 95 199 514 minecraft:smooth_basalt
setblock 95 199 519 minecraft:smooth_basalt
fill 95 199 520 95 200 522 minecraft:blackstone
setblock 95 199 529 minecraft:smooth_basalt
fill 95 199 530 95 201 530 minecraft:blackstone
setblock 95 199 534 minecraft:smooth_basalt
fill 95 199 535 95 202 535 minecraft:blackstone
fill 95 199 537 95 200 537 minecraft:blackstone
fill 96 199 511 96 199 512 minecraft:blackstone
setblock 96 199 513 minecraft:smooth_basalt
fill 96 199 514 97 201 514 minecraft:blackstone
setblock 96 199 517 minecraft:blackstone
setblock 96 199 518 minecraft:smooth_basalt
setblock 97 199 512 minecraft:smooth_basalt
fill 97 199 513 97 202 513 minecraft:blackstone
fill 97 199 515 97 199 516 minecraft:blackstone
setblock 97 199 551 minecraft:blackstone
fill 98 199 510 98 201 510 minecraft:blackstone
setblock 98 199 511 minecraft:smooth_basalt
fill 98 199 512 98 202 512 minecraft:blackstone
setblock 98 199 514 minecraft:smooth_basalt
setblock 98 199 551 minecraft:smooth_basalt
fill 99 199 511 99 202 511 minecraft:blackstone
setblock 99 199 514 minecraft:blackstone
fill 99 199 551 99 202 551 minecraft:blackstone
setblock 100 199 514 minecraft:smooth_basalt
fill 100 199 550 100 202 550 minecraft:blackstone
setblock 100 199 552 minecraft:basalt
setblock 101 199 510 minecraft:basalt
setblock 101 199 512 minecraft:blackstone
setblock 101 199 513 minecraft:smooth_basalt
fill 101 199 514 101 202 514 minecraft:blackstone
fill 102 199 510 103 201 510 minecraft:blackstone
setblock 102 199 512 minecraft:smooth_basalt
fill 102 199 513 102 202 513 minecraft:blackstone
setblock 103 199 511 minecraft:smooth_basalt
fill 103 199 512 103 202 512 minecraft:blackstone
setblock 103 199 551 minecraft:smooth_basalt
fill 104 199 511 104 202 511 minecraft:blackstone
setblock 104 199 550 minecraft:smooth_basalt
fill 104 199 551 104 202 551 minecraft:blackstone
setblock 105 199 513 minecraft:blackstone
setblock 105 199 514 minecraft:smooth_basalt
setblock 105 199 549 minecraft:smooth_basalt
fill 105 199 550 108 199 550 minecraft:blackstone
setblock 106 199 513 minecraft:smooth_basalt
fill 106 199 514 106 202 514 minecraft:blackstone
setblock 106 199 549 minecraft:blackstone
setblock 106 199 552 minecraft:blackstone
setblock 107 199 512 minecraft:smooth_basalt
fill 107 199 513 107 202 513 minecraft:blackstone
setblock 108 199 511 minecraft:smooth_basalt
fill 108 199 512 108 202 512 minecraft:blackstone
setblock 108 199 551 minecraft:smooth_basalt
fill 109 199 510 109 200 510 minecraft:basalt
fill 109 199 511 109 202 511 minecraft:blackstone
setblock 109 199 550 minecraft:smooth_basalt
fill 109 199 551 109 202 551 minecraft:blackstone
fill 110 199 510 111 202 510 minecraft:blackstone
fill 110 199 550 110 201 550 minecraft:blackstone
setblock 111 199 513 minecraft:smooth_basalt
setblock 112 199 512 minecraft:smooth_basalt
setblock 112 199 552 minecraft:blackstone
setblock 113 199 511 minecraft:smooth_basalt
fill 113 199 512 113 201 512 minecraft:blackstone
setblock 113 199 551 minecraft:smooth_basalt
fill 114 199 511 114 202 511 minecraft:blackstone
fill 114 199 551 114 202 551 minecraft:blackstone
setblock 116 199 512 minecraft:blackstone
setblock 117 199 511 minecraft:blackstone
setblock 117 199 512 minecraft:smooth_basalt
setblock 118 199 510 minecraft:basalt
setblock 118 199 511 minecraft:smooth_basalt
fill 118 199 512 118 202 512 minecraft:blackstone
setblock 118 199 551 minecraft:smooth_basalt
fill 118 199 552 119 199 552 minecraft:basalt
fill 119 199 510 119 201 511 minecraft:blackstone
setblock 119 199 550 minecraft:smooth_basalt
fill 119 199 551 119 202 551 minecraft:blackstone
fill 120 199 510 120 201 510 minecraft:blackstone
fill 120 199 550 120 202 550 minecraft:blackstone
fill 120 199 552 120 201 552 minecraft:blackstone
setblock 122 199 511 minecraft:blackstone
setblock 122 199 512 minecraft:smooth_basalt
fill 122 199 513 125 199 513 minecraft:blackstone
setblock 123 199 511 minecraft:smooth_basalt
fill 123 199 512 123 202 512 minecraft:blackstone
setblock 123 199 551 minecraft:smooth_basalt
fill 124 199 511 124 202 511 minecraft:blackstone
setblock 124 199 550 minecraft:smooth_basalt
fill 124 199 551 124 202 551 minecraft:blackstone
fill 125 199 550 125 201 550 minecraft:blackstone
fill 125 199 552 125 201 552 minecraft:blackstone
setblock 126 199 513 minecraft:smooth_basalt
setblock 126 199 552 minecraft:basalt
fill 127 199 510 128 199 510 minecraft:blackstone
setblock 127 199 512 minecraft:smooth_basalt
fill 127 199 552 128 201 552 minecraft:blackstone
setblock 128 199 511 minecraft:smooth_basalt
fill 128 199 512 128 201 512 minecraft:blackstone
setblock 128 199 551 minecraft:smooth_basalt
fill 129 199 511 129 202 511 minecraft:blackstone
fill 129 199 551 129 200 551 minecraft:blackstone
fill 131 199 510 131 200 510 minecraft:basalt
fill 132 199 510 132 201 510 minecraft:blackstone
setblock 133 199 511 minecraft:smooth_basalt
setblock 133 199 532 minecraft:blackstone
fill 134 199 511 135 201 511 minecraft:blackstone
setblock 134 199 530 minecraft:smooth_basalt
fill 134 199 531 134 201 531 minecraft:blackstone
setblock 134 199 535 minecraft:smooth_basalt
fill 134 199 536 134 202 536 minecraft:blackstone
fill 135 199 512 135 199 513 minecraft:blackstone
setblock 135 199 514 minecraft:smooth_basalt
fill 135 199 515 135 202 515 minecraft:blackstone
fill 135 199 517 135 199 518 minecraft:blackstone
fill 135 199 525 135 202 525 minecraft:blackstone
setblock 135 199 529 minecraft:smooth_basalt
fill 135 199 530 135 202 530 minecraft:blackstone
setblock 135 199 534 minecraft:smooth_basalt
fill 135 199 535 135 202 535 minecraft:blackstone
setblock 135 199 539 minecraft:smooth_basalt
setblock 136 199 513 minecraft:basalt
fill 136 199 517 136 201 517 minecraft:blackstone
setblock 136 199 530 minecraft:basalt
setblock 136 199 534 minecraft:blackstone
fill 136 199 537 136 201 538 minecraft:blackstone
fill 94 200 510 94 201 512 minecraft:blackstone
setblock 94 200 513 minecraft:basalt
fill 94 200 516 94 201 518 minecraft:blackstone
setblock 94 200 519 minecraft:basalt
fill 94 200 520 94 201 526 minecraft:blackstone
fill 94 200 533 94 201 533 minecraft:blackstone
setblock 94 200 534 minecraft:basalt
fill 94 200 535 94 201 536 minecraft:blackstone
setblock 94 200 537 minecraft:basalt
fill 94 200 538 94 201 539 minecraft:blackstone
fill 94 200 541 94 201 541 minecraft:blackstone
setblock 94 200 542 minecraft:basalt
fill 94 200 543 94 201 544 minecraft:blackstone
fill 94 200 548 94 201 548 minecraft:blackstone
setblock 94 200 549 minecraft:basalt
fill 94 200 550 94 201 552 minecraft:blackstone
fill 95 200 511 95 200 512 minecraft:blackstone
setblock 95 200 513 minecraft:smooth_basalt
fill 95 200 514 95 203 514 minecraft:blackstone
setblock 95 200 517 minecraft:blackstone
setblock 95 200 518 minecraft:smooth_basalt
fill 95 200 519 96 202 519 minecraft:blackstone
setblock 95 200 523 minecraft:smooth_basalt
setblock 95 200 528 minecraft:smooth_basalt
fill 95 200 529 95 201 529 minecraft:blackstone
setblock 95 200 533 minecraft:smooth_basalt
fill 95 200 534 95 203 534 minecraft:blackstone
setblock 95 200 538 minecraft:smooth_basalt
setblock 96 200 511 minecraft:blackstone
setblock 96 200 512 minecraft:smooth_basalt
fill 96 200 513 96 203 513 minecraft:blackstone
setblock 96 200 517 minecraft:smooth_basalt
fill 96 200 518 96 203 518 minecraft:blackstone
setblock 97 200 511 minecraft:smooth_basalt
fill 97 200 512 97 203 512 minecraft:blackstone
setblock 97 200 515 minecraft:blackstone
setblock 97 200 516 minecraft:smooth_basalt
fill 97 200 517 97 203 517 minecraft:blackstone
setblock 97 200 521 minecraft:light[level=12]
setblock 97 200 529 minecraft:light[level=12]
setblock 97 200 537 minecraft:light[level=12]
setblock 97 200 545 minecraft:light[level=12]
setblock 97 200 551 minecraft:smooth_basalt
fill 97 200 552 98 201 552 minecraft:blackstone
fill 98 200 511 98 203 511 minecraft:blackstone
setblock 98 200 514 minecraft:blackstone
fill 98 200 551 98 203 551 minecraft:blackstone
setblock 99 200 513 minecraft:blackstone
setblock 99 200 514 minecraft:smooth_basalt
setblock 99 200 552 minecraft:basalt
setblock 100 200 513 minecraft:smooth_basalt
fill 100 200 514 100 203 514 minecraft:blackstone
fill 100 200 552 100 201 552 minecraft:blackstone
fill 101 200 510 101 201 510 minecraft:blackstone
setblock 101 200 512 minecraft:smooth_basalt
fill 101 200 513 101 203 513 minecraft:blackstone
setblock 102 200 511 minecraft:smooth_basalt
fill 102 200 512 102 203 512 minecraft:blackstone
setblock 102 200 515 minecraft:blackstone
setblock 102 200 551 minecraft:smooth_basalt
fill 103 200 511 103 203 511 minecraft:blackstone
setblock 103 200 514 minecraft:blackstone
setblock 103 200 515 minecraft:smooth_basalt
setblock 103 200 550 minecraft:smooth_basalt
fill 103 200 551 103 201 552 minecraft:blackstone
setblock 104 200 514 minecraft:smooth_basalt
fill 104 200 515 104 201 515 minecraft:blackstone
fill 104 200 550 107 200 550 minecraft:blackstone
setblock 105 200 513 minecraft:smooth_basalt
fill 105 200 514 105 203 514 minecraft:blackstone
setblock 105 200 521 minecraft:light[level=12]
setblock 105 200 529 minecraft:light[level=12]
setblock 105 200 537 minecraft:light[level=12]
setblock 105 200 545 minecraft:light[level=12]
setblock 106 200 512 minecraft:smooth_basalt
fill 106 200 513 106 203 513 minecraft:blackstone
setblock 106 200 552 minecraft:basalt
setblock 107 200 511 minecraft:smooth_basalt
fill 107 200 512 107 203 512 minecraft:blackstone
setblock 107 200 551 minecraft:smooth_basalt
fill 108 200 511 108 203 511 minecraft:blackstone
setblock 108 200 550 minecraft:smooth_basalt
fill 108 200 551 108 203 551 minecraft:blackstone
fill 109 200 550 109 201 550 minecraft:blackstone
setblock 110 200 513 minecraft:smooth_basalt
setblock 111 200 512 minecraft:smooth_basalt
setblock 112 200 511 minecraft:smooth_basalt
fill 112 200 512 112 201 512 minecraft:blackstone
setblock 112 200 551 minecraft:smooth_basalt
setblock 112 200 552 minecraft:basalt
fill 113 200 511 113 203 511 minecraft:blackstone
setblock 113 200 513 minecraft:light[level=12]
setblock 113 200 521 minecraft:light[level=12]
setblock 113 200 529 minecraft:light[level=12]
setblock 113 200 537 minecraft:light[level=12]
setblock 113 200 545 minecraft:light[level=12]
fill 113 200 551 113 203 551 minecraft:blackstone
setblock 116 200 512 minecraft:smooth_basalt
fill 117 200 510 118 201 510 minecraft:blackstone
setblock 117 200 511 minecraft:smooth_basalt
fill 117 200 512 117 201 512 minecraft:blackstone
setblock 117 200 551 minecraft:smooth_basalt
fill 118 200 511 118 203 511 minecraft:blackstone
setblock 118 200 550 minecraft:smooth_basalt
fill 118 200 551 118 201 552 minecraft:blackstone
fill 119 200 550 119 202 550 minecraft:blackstone
setblock 119 200 552 minecraft:basalt
setblock 120 200 512 minecraft:blackstone
setblock 121 200 512 minecraft:smooth_basalt
fill 121 200 513 124 200 513 minecraft:blackstone
setblock 121 200 521 minecraft:light[level=12]
setblock 121 200 529 minecraft:light[level=12]
setblock 121 200 537 minecraft:light[level=12]
setblock 121 200 545 minecraft:light[level=12]
fill 121 200 552 122 201 552 minecraft:blackstone
setblock 122 200 511 minecraft:smooth_basalt
fill 122 200 512 122 203 512 minecraft:blackstone
setblock 122 200 551 minecraft:smooth_basalt
fill 123 200 511 123 203 511 minecraft:blackstone
setblock 123 200 550 minecraft:smooth_basalt
fill 123 200 551 123 203 551 minecraft:blackstone
setblock 123 200 552 minecraft:basalt
fill 124 200 550 124 202 550 minecraft:blackstone
fill 124 200 552 124 201 552 minecraft:blackstone
setblock 125 200 513 minecraft:smooth_basalt
setblock 126 200 512 minecraft:smooth_basalt
setblock 126 200 513 minecraft:blackstone
fill 126 200 552 126 201 552 minecraft:blackstone
fill 127 200 510 127 201 510 minecraft:blackstone
setblock 127 200 511 minecraft:smooth_basalt
fill 127 200 512 127 202 512 minecraft:blackstone
setblock 127 200 551 minecraft:smooth_basalt
setblock 128 200 510 minecraft:basalt
fill 128 200 511 128 202 511 minecraft:blackstone
fill 128 200 551 128 201 551 minecraft:blackstone
fill 129 200 510 129 201 510 minecraft:blackstone
setblock 129 200 513 minecraft:light[level=12]
setblock 129 200 521 minecraft:light[level=12]
setblock 129 200 529 minecraft:light[level=12]
setblock 129 200 537 minecraft:light[level=12]
setblock 129 200 545 minecraft:light[level=12]
setblock 130 200 510 minecraft:basalt
setblock 132 200 511 minecraft:smooth_basalt
setblock 133 200 511 minecraft:blackstone
setblock 133 200 535 minecraft:smooth_basalt
setblock 134 200 529 minecraft:smooth_basalt
fill 134 200 530 134 201 530 minecraft:blackstone
setblock 134 200 534 minecraft:smooth_basalt
fill 134 200 535 134 203 535 minecraft:blackstone
setblock 134 200 538 minecraft:blackstone
setblock 135 200 512 minecraft:blackstone
setblock 135 200 513 minecraft:smooth_basalt
fill 135 200 514 135 203 514 minecraft:blackstone
setblock 135 200 517 minecraft:blackstone
setblock 135 200 518 minecraft:smooth_basalt
fill 135 200 519 135 201 521 minecraft:blackstone
setblock 135 200 528 minecraft:smooth_basalt
fill 135 200 529 135 203 529 minecraft:blackstone
setblock 135 200 533 minecraft:smooth_basalt
fill 135 200 534 135 203 534 minecraft:blackstone
setblock 135 200 537 minecraft:blackstone
setblock 135 200 538 minecraft:smooth_basalt
fill 135 200 539 135 202 540 minecraft:blackstone
fill 136 200 513 136 201 513 minecraft:blackstone
fill 136 200 520 136 200 521 minecraft:basalt
setblock 136 200 524 minecraft:basalt
fill 136 200 525 136 201 525 minecraft:blackstone
setblock 136 200 527 minecraft:basalt
fill 136 200 530 136 201 530 minecraft:blackstone
setblock 136 200 534 minecraft:basalt
setblock 136 200 543 minecraft:basalt
fill 136 200 545 136 200 546 minecraft:basalt
fill 94 201 513 95 201 513 minecraft:blackstone
setblock 94 201 519 minecraft:blackstone
fill 94 201 528 94 202 528 minecraft:blackstone
setblock 94 201 534 minecraft:blackstone
setblock 94 201 537 minecraft:blackstone
setblock 94 201 542 minecraft:blackstone
setblock 94 201 549 minecraft:blackstone
setblock 95 201 511 minecraft:blackstone
setblock 95 201 512 minecraft:smooth_basalt
setblock 95 201 516 minecraft:blackstone
setblock 95 201 517 minecraft:smooth_basalt
fill 95 201 518 95 204 518 minecraft:blackstone
fill 95 201 520 95 201 521 minecraft:blackstone
setblock 95 201 522 minecraft:smooth_basalt
fill 95 201 523 95 202 524 minecraft:blackstone
setblock 95 201 532 minecraft:smooth_basalt
fill 95 201 533 95 203 533 minecraft:blackstone
setblock 95 201 537 minecraft:smooth_basalt
fill 95 201 538 95 204 538 minecraft:blackstone
setblock 96 201 511 minecraft:smooth_basalt
fill 96 201 512 96 204 512 minecraft:blackstone
setblock 96 201 516 minecraft:smooth_basalt
fill 96 201 517 96 204 517 minecraft:blackstone
setblock 96 201 520 minecraft:blackstone
fill 97 201 511 97 204 511 minecraft:blackstone
setblock 97 201 515 minecraft:smooth_basalt
fill 97 201 516 98 203 516 minecraft:blackstone
fill 97 201 518 97 202 518 minecraft:blackstone
fill 97 201 551 97 203 551 minecraft:blackstone
setblock 98 201 514 minecraft:smooth_basalt
fill 98 201 515 98 204 515 minecraft:blackstone
setblock 99 201 513 minecraft:smooth_basalt
fill 99 201 514 99 204 514 minecraft:blackstone
setblock 99 201 552 minecraft:blackstone
setblock 100 201 512 minecraft:smooth_basalt
fill 100 201 513 100 204 513 minecraft:blackstone
setblock 101 201 511 minecraft:smooth_basalt
fill 101 201 512 101 204 512 minecraft:blackstone
setblock 101 201 515 minecraft:blackstone
setblock 101 201 551 minecraft:smooth_basalt
fill 102 201 511 102 204 511 minecraft:blackstone
setblock 102 201 515 minecraft:smooth_basalt
setblock 102 201 550 minecraft:smooth_basalt
fill 102 201 551 102 204 551 minecraft:blackstone
setblock 103 201 514 minecraft:smooth_basalt
fill 103 201 515 103 202 515 minecraft:blackstone
fill 103 201 550 106 201 550 minecraft:blackstone
setblock 104 201 513 minecraft:smooth_basalt
fill 104 201 514 104 204 514 minecraft:blackstone
setblock 105 201 512 minecraft:smooth_basalt
fill 105 201 513 105 204 513 minecraft:blackstone
setblock 106 201 511 minecraft:smooth_basalt
fill 106 201 512 106 204 512 minecraft:blackstone
setblock 106 201 551 minecraft:smooth_basalt
fill 106 201 552 106 202 552 minecraft:blackstone
fill 107 201 511 107 204 511 minecraft:blackstone
setblock 107 201 514 minecraft:blackstone
setblock 107 201 550 minecraft:smooth_basalt
fill 107 201 551 107 204 551 minecraft:blackstone
fill 108 201 550 108 202 550 minecraft:blackstone
setblock 109 201 510 minecraft:blackstone
setblock 109 201 513 minecraft:smooth_basalt
setblock 110 201 512 minecraft:smooth_basalt
setblock 110 201 513 minecraft:blackstone
setblock 111 201 511 minecraft:smooth_basalt
fill 111 201 512 111 202 512 minecraft:blackstone
setblock 111 201 551 minecraft:smooth_basalt
fill 112 201 511 112 203 511 minecraft:blackstone
fill 112 201 551 112 202 552 minecraft:blackstone
fill 115 201 510 115 201 511 minecraft:blackstone
setblock 116 201 510 minecraft:blackstone
setblock 116 201 511 minecraft:smooth_basalt
setblock 116 201 512 minecraft:blackstone
setblock 116 201 551 minecraft:smooth_basalt
fill 117 201 511 117 204 511 minecraft:blackstone
setblock 117 201 550 minecraft:smooth_basalt
fill 117 201 551 117 204 551 minecraft:blackstone
fill 118 201 550 118 202 550 minecraft:blackstone
setblock 119 201 552 minecraft:blackstone
setblock 120 201 512 minecraft:smooth_basalt
setblock 121 201 511 minecraft:smooth_basalt
fill 121 201 512 121 201 513 minecraft:blackstone
setblock 121 201 551 minecraft:smooth_basalt
fill 122 201 511 122 204 511 minecraft:blackstone
fill 122 201 513 123 201 513 minecraft:blackstone
setblock 122 201 550 minecraft:smooth_basalt
fill 122 201 551 122 204 551 minecraft:blackstone
fill 123 201 550 123 202 550 minecraft:blackstone
setblock 123 201 552 minecraft:blackstone
setblock 124 201 513 minecraft:smooth_basalt
setblock 125 201 512 minecraft:smooth_basalt
setblock 125 201 513 minecraft:blackstone
setblock 126 201 511 minecraft:smooth_basalt
fill 126 201 512 126 202 512 minecraft:blackstone
setblock 126 201 551 minecraft:smooth_basalt
fill 127 201 511 127 203 511 minecraft:blackstone
fill 127 201 551 127 202 551 minecraft:blackstone
setblock 128 201 510 minecraft:blackstone
fill 129 201 552 130 201 552 minecraft:blackstone
fill 130 201 510 131 201 510 minecraft:blackstone
setblock 131 201 511 minecraft:smooth_basalt
setblock 132 201 511 minecraft:blackstone
setblock 134 201 533 minecraft:smooth_basalt
fill 134 201 534 134 203 534 minecraft:blackstone
setblock 134 201 538 minecraft:smooth_basalt
setblock 135 201 512 minecraft:smooth_basalt
fill 135 201 513 135 204 513 minecraft:blackstone
setblock 135 201 517 minecraft:smooth_basalt
fill 135 201 518 135 204 518 minecraft:blackstone
setblock 135 201 522 minecraft:smooth_basalt
fill 135 201 523 135 203 524 minecraft:blackstone
setblock 135 201 527 minecraft:smooth_basalt
fill 135 201 528 135 203 528 minecraft:blackstone
setblock 135 201 532 minecraft:smooth_basalt
fill 135 201 533 135 204 533 minecraft:blackstone
setblock 135 201 537 minecraft:smooth_basalt
fill 135 201 538 135 204 538 minecraft:blackstone
fill 136 201 520 136 201 521 minecraft:blackstone
setblock 136 201 524 minecraft:blackstone
setblock 136 201 527 minecraft:blackstone
setblock 136 201 534 minecraft:blackstone
setblock 136 201 543 minecraft:blackstone
fill 136 201 545 136 201 546 minecraft:blackstone
fill 94 202 510 94 202 513 minecraft:basalt
fill 94 202 515 94 202 521 minecraft:basalt
fill 94 202 522 95 202 522 minecraft:blackstone
fill 94 202 523 94 307 527 minecraft:basalt
fill 94 202 529 94 202 552 minecraft:basalt
fill 95 202 510 109 203 510 minecraft:basalt
setblock 95 202 511 minecraft:smooth_basalt
fill 95 202 512 95 204 513 minecraft:blackstone
setblock 95 202 515 minecraft:blackstone
setblock 95 202 516 minecraft:smooth_basalt
fill 95 202 517 95 205 517 minecraft:blackstone
setblock 95 202 520 minecraft:blackstone
setblock 95 202 521 minecraft:smooth_basalt
setblock 95 202 531 minecraft:smooth_basalt
setblock 95 202 532 minecraft:blackstone
setblock 95 202 536 minecraft:smooth_basalt
fill 95 202 537 95 205 537 minecraft:blackstone
fill 95 202 552 95 203 552 minecraft:basalt
fill 96 202 511 96 205 511 minecraft:blackstone
setblock 96 202 514 minecraft:blackstone
setblock 96 202 515 minecraft:smooth_basalt
fill 96 202 516 96 205 516 minecraft:blackstone
setblock 96 202 520 minecraft:smooth_basalt
fill 96 202 521 96 205 521 minecraft:blackstone
setblock 96 202 552 minecraft:blackstone
setblock 97 202 514 minecraft:smooth_basalt
fill 97 202 515 97 205 515 minecraft:blackstone
setblock 97 202 519 minecraft:smooth_basalt
fill 97 202 552 97 307 552 minecraft:basalt
setblock 98 202 513 minecraft:smooth_basalt
fill 98 202 514 98 204 514 minecraft:blackstone
setblock 98 202 517 minecraft:blackstone
setblock 98 202 552 minecraft:blackstone
setblock 99 202 512 minecraft:smooth_basalt
fill 99 202 513 99 205 513 minecraft:blackstone
fill 99 202 552 105 202 552 minecraft:basalt
setblock 100 202 511 minecraft:smooth_basalt
fill 100 202 512 100 205 512 minecraft:blackstone
setblock 100 202 551 minecraft:smooth_basalt
fill 101 202 511 101 205 511 minecraft:blackstone
setblock 101 202 515 minecraft:smooth_basalt
setblock 101 202 550 minecraft:smooth_basalt
fill 101 202 551 101 205 551 minecraft:blackstone
setblock 102 202 514 minecraft:smooth_basalt
setblock 102 202 515 minecraft:blackstone
fill 102 202 550 105 202 550 minecraft:blackstone
setblock 103 202 513 minecraft:smooth_basalt
fill 103 202 514 103 204 514 minecraft:blackstone
fill 103 202 551 103 203 551 minecraft:blackstone
setblock 104 202 512 minecraft:smooth_basalt
fill 104 202 513 104 205 513 minecraft:blackstone
setblock 105 202 511 minecraft:smooth_basalt
fill 105 202 512 105 205 512 minecraft:blackstone
setblock 105 202 551 minecraft:smooth_basalt
fill 106 202 511 106 205 511 minecraft:blackstone
setblock 106 202 550 minecraft:smooth_basalt
fill 106 202 551 106 205 551 minecraft:blackstone
setblock 107 202 550 minecraft:blackstone
setblock 107 202 552 minecraft:blackstone
setblock 108 202 513 minecraft:smooth_basalt
fill 108 202 552 111 203 552 minecraft:basalt
setblock 109 202 512 minecraft:smooth_basalt
setblock 110 202 511 minecraft:smooth_basalt
setblock 110 202 512 minecraft:blackstone
setblock 110 202 551 minecraft:smooth_basalt
fill 111 202 511 111 203 511 minecraft:blackstone
fill 111 202 551 111 203 551 minecraft:blackstone
fill 112 202 510 134 202 510 minecraft:basalt
fill 113 202 552 127 202 552 minecraft:basalt
setblock 115 202 511 minecraft:smooth_basalt
setblock 115 202 551 minecraft:smooth_basalt
fill 116 202 511 116 203 511 minecraft:blackstone
fill 116 202 551 116 204 551 minecraft:blackstone
fill 118 202 551 118 203 551 minecraft:blackstone
setblock 119 202 511 minecraft:blackstone
setblock 119 202 512 minecraft:smooth_basalt
setblock 120 202 511 minecraft:smooth_basalt
fill 120 202 512 121 203 512 minecraft:blackstone
setblock 120 202 551 minecraft:smooth_basalt
fill 121 202 511 121 205 511 minecraft:blackstone
setblock 121 202 550 minecraft:smooth_basalt
fill 121 202 551 121 205 551 minecraft:blackstone
fill 122 202 550 122 203 550 minecraft:blackstone
setblock 124 202 512 minecraft:smooth_basalt
setblock 125 202 511 minecraft:smooth_basalt
fill 125 202 512 125 203 512 minecraft:blackstone
setblock 125 202 551 minecraft:smooth_basalt
fill 126 202 511 126 203 511 minecraft:blackstone
fill 126 202 551 126 203 551 minecraft:blackstone
setblock 128 202 552 minecraft:blackstone
fill 129 202 552 134 202 552 minecraft:basalt
setblock 134 202 516 minecraft:blackstone
setblock 134 202 517 minecraft:smooth_basalt
setblock 134 202 532 minecraft:smooth_basalt
fill 134 202 533 134 203 533 minecraft:blackstone
setblock 134 202 537 minecraft:smooth_basalt
setblock 134 202 538 minecraft:blackstone
setblock 135 202 510 minecraft:blackstone
setblock 135 202 511 minecraft:smooth_basalt
fill 135 202 512 135 205 512 minecraft:blackstone
setblock 135 202 516 minecraft:smooth_basalt
fill 135 202 517 135 205 517 minecraft:blackstone
fill 135 202 519 135 202 520 minecraft:blackstone
setblock 135 202 521 minecraft:smooth_basalt
fill 135 202 522 135 205 522 minecraft:blackstone
setblock 135 202 526 minecraft:smooth_basalt
fill 135 202 527 135 203 527 minecraft:blackstone
setblock 135 202 531 minecraft:smooth_basalt
fill 135 202 532 135 205 532 minecraft:blackstone
setblock 135 202 536 minecraft:smooth_basalt
fill 135 202 537 135 205 537 minecraft:blackstone
setblock 135 202 552 minecraft:blackstone
fill 136 202 510 136 202 519 minecraft:basalt
fill 136 202 520 136 203 520 minecraft:blackstone
fill 136 202 521 136 202 538 minecraft:basalt
fill 136 202 540 136 202 544 minecraft:basalt
setblock 136 202 545 minecraft:blackstone
fill 136 202 546 136 202 552 minecraft:basalt
setblock 94 203 510 minecraft:blackstone
fill 94 203 511 94 307 513 minecraft:basalt
fill 94 203 515 94 307 518 minecraft:basalt
fill 94 203 519 95 203 519 minecraft:blackstone
fill 94 203 520 94 203 522 minecraft:basalt
fill 94 203 528 94 307 534 minecraft:basalt
setblock 94 203 535 minecraft:blackstone
fill 94 203 536 94 203 543 minecraft:basalt
setblock 94 203 544 minecraft:blackstone
fill 94 203 545 94 307 552 minecraft:basalt
fill 95 203 511 95 206 511 minecraft:blackstone
setblock 95 203 515 minecraft:smooth_basalt
fill 95 203 516 95 206 516 minecraft:blackstone
setblock 95 203 520 minecraft:smooth_basalt
fill 95 203 521 95 204 523 minecraft:blackstone
setblock 95 203 535 minecraft:smooth_basalt
fill 95 203 536 95 204 536 minecraft:blackstone
setblock 95 203 539 minecraft:blackstone
setblock 96 203 514 minecraft:smooth_basalt
fill 96 203 515 96 206 515 minecraft:blackstone
setblock 96 203 519 minecraft:smooth_basalt
fill 96 203 520 96 206 520 minecraft:blackstone
fill 96 203 552 96 307 552 minecraft:basalt
setblock 97 203 513 minecraft:smooth_basalt
fill 97 203 514 97 206 514 minecraft:blackstone
setblock 97 203 518 minecraft:smooth_basalt
fill 97 203 519 97 206 519 minecraft:blackstone
setblock 98 203 512 minecraft:smooth_basalt
fill 98 203 513 98 206 513 minecraft:blackstone
setblock 98 203 517 minecraft:smooth_basalt
fill 98 203 552 101 307 552 minecraft:basalt
setblock 99 203 511 minecraft:smooth_basalt
fill 99 203 512 99 206 512 minecraft:blackstone
setblock 99 203 551 minecraft:smooth_basalt
fill 100 203 511 100 206 511 minecraft:blackstone
fill 100 203 551 100 206 551 minecraft:blackstone
setblock 101 203 514 minecraft:smooth_basalt
fill 101 203 550 104 203 550 minecraft:blackstone
setblock 102 203 513 minecraft:smooth_basalt
fill 102 203 514 102 205 514 minecraft:blackstone
fill 102 203 552 102 204 552 minecraft:blackstone
setblock 103 203 512 minecraft:smooth_basalt
fill 103 203 513 103 206 513 minecraft:blackstone
fill 103 203 552 107 307 552 minecraft:basalt
setblock 104 203 511 minecraft:smooth_basalt
fill 104 203 512 104 206 512 minecraft:blackstone
setblock 104 203 551 minecraft:smooth_basalt
fill 105 203 511 105 206 511 minecraft:blackstone
setblock 105 203 550 minecraft:smooth_basalt
fill 105 203 551 105 206 551 minecraft:blackstone
setblock 106 203 550 minecraft:blackstone
setblock 107 203 513 minecraft:smooth_basalt
setblock 108 203 512 minecraft:smooth_basalt
setblock 109 203 511 minecraft:smooth_basalt
setblock 109 203 512 minecraft:blackstone
setblock 109 203 551 minecraft:smooth_basalt
fill 110 203 510 112 307 510 minecraft:basalt
fill 110 203 511 110 204 511 minecraft:blackstone
setblock 110 203 551 minecraft:blackstone
setblock 112 203 551 minecraft:blackstone
fill 112 203 552 114 307 552 minecraft:basalt
setblock 113 203 510 minecraft:blackstone
fill 114 203 510 136 203 510 minecraft:basalt
setblock 114 203 511 minecraft:smooth_basalt
setblock 114 203 551 minecraft:smooth_basalt
setblock 115 203 511 minecraft:blackstone
fill 115 203 551 115 203 552 minecraft:blackstone
fill 116 203 552 116 307 552 minecraft:basalt
setblock 117 203 552 minecraft:blackstone
fill 118 203 552 120 307 552 minecraft:basalt
setblock 119 203 511 minecraft:smooth_basalt
setblock 119 203 512 minecraft:blackstone
setblock 119 203 551 minecraft:smooth_basalt
fill 120 203 511 120 205 511 minecraft:blackstone
setblock 120 203 550 minecraft:smooth_basalt
fill 120 203 551 120 206 551 minecraft:blackstone
setblock 121 203 550 minecraft:blackstone
setblock 121 203 552 minecraft:blackstone
fill 122 203 552 130 203 552 minecraft:basalt
setblock 123 203 512 minecraft:smooth_basalt
setblock 124 203 511 minecraft:smooth_basalt
setblock 124 203 512 minecraft:blackstone
setblock 124 203 551 minecraft:smooth_basalt
fill 125 203 511 125 204 511 minecraft:blackstone
setblock 125 203 551 minecraft:blackstone
fill 131 203 552 131 204 552 minecraft:blackstone
fill 132 203 552 135 307 552 minecraft:basalt
setblock 134 203 516 minecraft:smooth_basalt
fill 134 203 517 134 205 518 minecraft:blackstone
setblock 134 203 536 minecraft:smooth_basalt
setblock 134 203 537 minecraft:blackstone
setblock 135 203 515 minecraft:smooth_basalt
fill 135 203 516 135 206 516 minecraft:blackstone
setblock 135 203 519 minecraft:blackstone
setblock 135 203 520 minecraft:smooth_basalt
fill 135 203 521 136 204 521 minecraft:blackstone
setblock 135 203 525 minecraft:smooth_basalt
setblock 135 203 526 minecraft:blackstone
setblock 135 203 530 minecraft:smooth_basalt
fill 135 203 531 135 204 531 minecraft:blackstone
setblock 135 203 535 minecraft:smooth_basalt
fill 135 203 536 135 206 536 minecraft:blackstone
setblock 135 203 539 minecraft:blackstone
setblock 135 203 540 minecraft:smooth_basalt
fill 135 203 541 135 206 541 minecraft:blackstone
fill 136 203 511 136 307 512 minecraft:basalt
fill 136 203 513 136 203 514 minecraft:blackstone
fill 136 203 515 136 307 516 minecraft:basalt
fill 136 203 517 136 203 518 minecraft:blackstone
fill 136 203 519 136 307 519 minecraft:basalt
fill 136 203 522 136 307 529 minecraft:basalt
setblock 136 203 530 minecraft:blackstone
fill 136 203 531 136 203 539 minecraft:basalt
fill 136 203 540 136 204 540 minecraft:blackstone
fill 136 203 541 136 307 551 minecraft:basalt
setblock 136 203 552 minecraft:blackstone
fill 94 204 510 98 307 510 minecraft:basalt
fill 94 204 514 94 307 514 minecraft:basalt
fill 94 204 519 94 204 520 minecraft:blackstone
fill 94 204 521 94 307 522 minecraft:basalt
fill 94 204 535 94 307 539 minecraft:basalt
setblock 94 204 540 minecraft:blackstone
fill 94 204 541 94 307 544 minecraft:basalt
setblock 95 204 514 minecraft:smooth_basalt
fill 95 204 515 95 207 515 minecraft:blackstone
setblock 95 204 519 minecraft:smooth_basalt
fill 95 204 520 95 207 520 minecraft:blackstone
setblock 95 204 524 minecraft:smooth_basalt
setblock 95 204 535 minecraft:blackstone
setblock 95 204 539 minecraft:smooth_basalt
setblock 95 204 552 minecraft:blackstone
setblock 96 204 513 minecraft:smooth_basalt
fill 96 204 514 96 207 514 minecraft:blackstone
setblock 96 204 518 minecraft:smooth_basalt
fill 96 204 519 96 207 519 minecraft:blackstone
setblock 96 204 522 minecraft:blackstone
setblock 97 204 512 minecraft:smooth_basalt
fill 97 204 513 97 206 513 minecraft:blackstone
setblock 97 204 516 minecraft:blackstone
setblock 97 204 517 minecraft:smooth_basalt
fill 97 204 518 97 207 518 minecraft:blackstone
fill 97 204 520 97 205 520 minecraft:blackstone
setblock 98 204 511 minecraft:smooth_basalt
fill 98 204 512 98 207 512 minecraft:blackstone
setblock 98 204 516 minecraft:smooth_basalt
fill 98 204 517 98 205 517 minecraft:blackstone
setblock 98 204 551 minecraft:smooth_basalt
fill 99 204 510 99 204 511 minecraft:blackstone
fill 99 204 551 99 207 551 minecraft:blackstone
fill 100 204 510 109 307 510 minecraft:basalt
setblock 100 204 514 minecraft:smooth_basalt
setblock 101 204 513 minecraft:smooth_basalt
fill 101 204 514 101 205 514 minecraft:blackstone
fill 101 204 550 103 204 550 minecraft:blackstone
setblock 102 204 512 minecraft:smooth_basalt
fill 102 204 513 102 206 513 minecraft:blackstone
setblock 103 204 511 minecraft:smooth_basalt
fill 103 204 512 103 207 512 minecraft:blackstone
setblock 103 204 551 minecraft:smooth_basalt
fill 104 204 511 104 207 511 minecraft:blackstone
setblock 104 204 550 minecraft:smooth_basalt
fill 104 204 551 104 207 551 minecraft:blackstone
setblock 106 204 513 minecraft:smooth_basalt
setblock 107 204 512 minecraft:smooth_basalt
setblock 108 204 511 minecraft:smooth_basalt
setblock 108 204 512 minecraft:blackstone
setblock 108 204 551 minecraft:smooth_basalt
setblock 108 204 552 minecraft:blackstone
setblock 109 204 511 minecraft:blackstone
setblock 109 204 551 minecraft:blackstone
fill 109 204 552 111 307 552 minecraft:basalt
fill 113 204 510 114 307 510 minecraft:basalt
setblock 115 204 510 minecraft:blackstone
fill 115 204 552 115 307 552 minecraft:basalt
fill 116 204 510 120 307 510 minecraft:basalt
fill 117 204 552 117 307 552 minecraft:basalt
setblock 118 204 511 minecraft:smooth_basalt
setblock 118 204 551 minecraft:smooth_basalt
fill 119 204 511 119 205 511 minecraft:blackstone
fill 119 204 551 119 207 551 minecraft:blackstone
setblock 121 204 510 minecraft:blackstone
setblock 121 204 512 minecraft:blackstone
fill 121 204 552 121 307 552 minecraft:basalt
fill 122 204 510 124 307 510 minecraft:basalt
setblock 122 204 512 minecraft:smooth_basalt
setblock 122 204 552 minecraft:blackstone
setblock 123 204 511 minecraft:smooth_basalt
setblock 123 204 551 minecraft:smooth_basalt
fill 123 204 552 130 307 552 minecraft:basalt
setblock 124 204 511 minecraft:blackstone
setblock 124 204 551 minecraft:blackstone
setblock 125 204 510 minecraft:blackstone
fill 126 204 510 136 307 510 minecraft:basalt
fill 134 204 516 134 207 516 minecraft:blackstone
setblock 134 204 519 minecraft:blackstone
setblock 135 204 514 minecraft:smooth_basalt
fill 135 204 515 135 207 515 minecraft:blackstone
setblock 135 204 519 minecraft:smooth_basalt
fill 135 204 520 135 207 520 minecraft:blackstone
setblock 135 204 523 minecraft:blackstone
setblock 135 204 524 minecraft:smooth_basalt
fill 135 204 525 135 207 525 minecraft:blackstone
setblock 135 204 530 minecraft:blackstone
setblock 135 204 534 minecraft:smooth_basalt
fill 135 204 535 135 207 535 minecraft:blackstone
setblock 135 204 539 minecraft:smooth_basalt
fill 135 204 540 135 207 540 minecraft:blackstone
fill 136 204 513 136 307 514 minecraft:basalt
fill 136 204 517 136 307 518 minecraft:basalt
fill 136 204 520 136 307 520 minecraft:basalt
fill 136 204 530 136 307 535 minecraft:basalt
setblock 136 204 536 minecraft:blackstone
fill 136 204 537 136 307 539 minecraft:basalt
fill 136 204 552 136 307 552 minecraft:basalt
fill 94 205 519 94 307 520 minecraft:basalt
fill 94 205 540 94 307 540 minecraft:basalt
setblock 95 205 512 minecraft:blackstone
setblock 95 205 513 minecraft:smooth_basalt
fill 95 205 514 95 208 514 minecraft:blackstone
setblock 95 205 518 minecraft:smooth_basalt
fill 95 205 519 95 208 519 minecraft:blackstone
fill 95 205 521 95 205 522 minecraft:blackstone
setblock 95 205 523 minecraft:smooth_basalt
fill 95 205 524 95 208 524 minecraft:blackstone
setblock 95 205 538 minecraft:smooth_basalt
fill 95 205 539 95 208 539 minecraft:blackstone
fill 95 205 552 95 307 552 minecraft:basalt
setblock 96 205 512 minecraft:smooth_basalt
fill 96 205 513 96 208 513 minecraft:blackstone
setblock 96 205 517 minecraft:smooth_basalt
fill 96 205 518 96 208 518 minecraft:blackstone
setblock 96 205 522 minecraft:smooth_basalt
setblock 97 205 511 minecraft:smooth_basalt
fill 97 205 512 97 208 512 minecraft:blackstone
setblock 97 205 516 minecraft:smooth_basalt
fill 97 205 517 97 208 517 minecraft:blackstone
fill 98 205 511 99 207 511 minecraft:blackstone
fill 98 205 514 98 221 515 minecraft:smooth_basalt
setblock 98 205 516 minecraft:blackstone
fill 98 205 551 98 208 551 minecraft:blackstone
fill 99 205 510 99 307 510 minecraft:basalt
fill 99 205 514 99 221 514 minecraft:smooth_basalt
setblock 100 205 513 minecraft:smooth_basalt
setblock 100 205 514 minecraft:blackstone
setblock 101 205 512 minecraft:smooth_basalt
fill 101 205 513 101 207 513 minecraft:blackstone
setblock 102 205 511 minecraft:smooth_basalt
fill 102 205 512 102 208 512 minecraft:blackstone
setblock 102 205 551 minecraft:smooth_basalt
fill 102 205 552 102 307 552 minecraft:basalt
fill 103 205 511 103 208 511 minecraft:blackstone
fill 103 205 551 103 208 551 minecraft:blackstone
setblock 106 205 512 minecraft:smooth_basalt
setblock 107 205 511 minecraft:smooth_basalt
setblock 107 205 551 minecraft:smooth_basalt
setblock 108 205 511 minecraft:blackstone
fill 108 205 552 108 307 552 minecraft:basalt
fill 115 205 510 115 307 510 minecraft:basalt
setblock 117 205 551 minecraft:smooth_basalt
setblock 118 205 511 minecraft:blackstone
fill 118 205 551 118 206 551 minecraft:blackstone
fill 121 205 510 121 307 510 minecraft:basalt
setblock 122 205 511 minecraft:smooth_basalt
setblock 122 205 551 minecraft:smooth_basalt
fill 122 205 552 122 307 552 minecraft:basalt
setblock 123 205 511 minecraft:blackstone
fill 125 205 510 125 307 510 minecraft:basalt
fill 131 205 552 131 307 552 minecraft:basalt
setblock 134 205 519 minecraft:smooth_basalt
fill 134 205 520 134 208 520 minecraft:blackstone
setblock 135 205 513 minecraft:smooth_basalt
fill 135 205 514 135 208 514 minecraft:blackstone
setblock 135 205 518 minecraft:smooth_basalt
fill 135 205 519 135 208 519 minecraft:blackstone
fill 135 205 521 135 206 521 minecraft:blackstone
setblock 135 205 523 minecraft:smooth_basalt
fill 135 205 524 135 208 524 minecraft:blackstone
setblock 135 205 533 minecraft:smooth_basalt
fill 135 205 534 135 206 534 minecraft:blackstone
setblock 135 205 538 minecraft:smooth_basalt
fill 135 205 539 135 208 539 minecraft:blackstone
fill 136 205 521 136 307 521 minecraft:basalt
fill 136 205 536 136 307 536 minecraft:basalt
fill 136 205 540 136 307 540 minecraft:basalt
setblock 95 206 512 minecraft:smooth_basalt
fill 95 206 513 95 209 513 minecraft:blackstone
setblock 95 206 517 minecraft:smooth_basalt
fill 95 206 518 95 209 518 minecraft:blackstone
setblock 95 206 521 minecraft:blackstone
setblock 95 206 522 minecraft:smooth_basalt
fill 95 206 523 95 209 523 minecraft:blackstone
setblock 95 206 538 minecraft:blackstone
fill 95 206 540 95 207 540 minecraft:blackstone
setblock 96 206 511 minecraft:smooth_basalt
fill 96 206 512 96 209 512 minecraft:blackstone
setblock 96 206 516 minecraft:smooth_basalt
fill 96 206 517 96 209 517 minecraft:blackstone
setblock 96 206 521 minecraft:smooth_basalt
fill 96 206 522 96 209 522 minecraft:blackstone
fill 97 206 511 97 209 511 minecraft:blackstone
setblock 97 206 515 minecraft:smooth_basalt
fill 97 206 516 97 209 516 minecraft:blackstone
setblock 97 206 520 minecraft:smooth_basalt
setblock 99 206 513 minecraft:smooth_basalt
setblock 100 206 512 minecraft:smooth_basalt
fill 100 206 513 100 207 513 minecraft:blackstone
setblock 101 206 511 minecraft:smooth_basalt
fill 101 206 512 101 209 512 minecraft:blackstone
setblock 101 206 551 minecraft:smooth_basalt
fill 102 206 511 102 209 511 minecraft:blackstone
fill 102 206 551 102 209 551 minecraft:blackstone
setblock 105 206 512 minecraft:smooth_basalt
setblock 106 206 511 minecraft:smooth_basalt
setblock 106 206 551 minecraft:smooth_basalt
setblock 121 206 551 minecraft:smooth_basalt
setblock 134 206 517 minecraft:blackstone
setblock 134 206 518 minecraft:smooth_basalt
fill 134 206 519 134 209 519 minecraft:blackstone
fill 134 206 521 134 207 521 minecraft:blackstone
fill 135 206 513 135 209 513 minecraft:blackstone
setblock 135 206 517 minecraft:smooth_basalt
fill 135 206 518 135 209 518 minecraft:blackstone
setblock 135 206 522 minecraft:smooth_basalt
fill 135 206 523 135 209 523 minecraft:blackstone
setblock 135 206 526 minecraft:blackstone
setblock 135 206 533 minecraft:blackstone
setblock 135 206 537 minecraft:smooth_basalt
fill 135 206 538 135 209 538 minecraft:blackstone
setblock 95 207 511 minecraft:smooth_basalt
fill 95 207 512 95 210 512 minecraft:blackstone
setblock 95 207 516 minecraft:smooth_basalt
fill 95 207 517 95 210 517 minecraft:blackstone
setblock 95 207 521 minecraft:smooth_basalt
fill 95 207 522 95 210 522 minecraft:blackstone
setblock 95 207 541 minecraft:smooth_basalt
fill 95 207 542 95 210 542 minecraft:blackstone
fill 96 207 511 96 210 511 minecraft:blackstone
setblock 96 207 515 minecraft:smooth_basalt
fill 96 207 516 96 210 516 minecraft:blackstone
setblock 96 207 520 minecraft:smooth_basalt
fill 96 207 521 97 209 521 minecraft:blackstone
fill 96 207 523 96 208 523 minecraft:blackstone
fill 97 207 513 97 207 514 minecraft:smooth_basalt
fill 97 207 515 97 210 515 minecraft:blackstone
setblock 97 207 519 minecraft:smooth_basalt
fill 97 207 520 97 210 520 minecraft:blackstone
fill 98 207 513 98 221 513 minecraft:smooth_basalt
setblock 99 207 512 minecraft:smooth_basalt
setblock 99 207 513 minecraft:blackstone
setblock 100 207 511 minecraft:smooth_basalt
fill 100 207 512 100 210 512 minecraft:blackstone
setblock 100 207 551 minecraft:smooth_basalt
fill 101 207 511 101 210 511 minecraft:blackstone
fill 101 207 551 101 210 551 minecraft:blackstone
setblock 105 207 511 minecraft:smooth_basalt
setblock 105 207 551 minecraft:smooth_basalt
setblock 134 207 517 minecraft:smooth_basalt
fill 134 207 518 134 210 518 minecraft:blackstone
setblock 134 207 522 minecraft:smooth_basalt
setblock 135 207 516 minecraft:smooth_basalt
fill 135 207 517 135 210 517 minecraft:blackstone
setblock 135 207 521 minecraft:smooth_basalt
fill 135 207 522 135 210 522 minecraft:blackstone
setblock 135 207 526 minecraft:smooth_basalt
setblock 135 207 536 minecraft:smooth_basalt
fill 135 207 537 135 210 537 minecraft:blackstone
setblock 135 207 541 minecraft:smooth_basalt
fill 95 208 511 95 211 511 minecraft:blackstone
setblock 95 208 515 minecraft:smooth_basalt
fill 95 208 516 95 211 516 minecraft:blackstone
setblock 95 208 520 minecraft:smooth_basalt
fill 95 208 521 95 211 521 minecraft:blackstone
setblock 95 208 525 minecraft:smooth_basalt
fill 95 208 538 95 209 538 minecraft:blackstone
setblock 95 208 540 minecraft:smooth_basalt
fill 95 208 541 95 211 541 minecraft:blackstone
fill 95 208 543 95 208 544 minecraft:blackstone
setblock 96 208 514 minecraft:smooth_basalt
fill 96 208 515 96 211 515 minecraft:blackstone
setblock 96 208 519 minecraft:smooth_basalt
fill 96 208 520 96 211 520 minecraft:blackstone
fill 97 208 513 97 221 513 minecraft:smooth_basalt
fill 97 208 514 97 211 514 minecraft:blackstone
setblock 97 208 518 minecraft:smooth_basalt
fill 97 208 519 97 211 519 minecraft:blackstone
setblock 97 208 529 minecraft:light[level=12]
setblock 97 208 537 minecraft:light[level=12]
setblock 97 208 545 minecraft:light[level=12]
fill 97 208 551 97 209 551 minecraft:blackstone
setblock 98 208 511 minecraft:blackstone
setblock 98 208 512 minecraft:smooth_basalt
setblock 99 208 511 minecraft:smooth_basalt
fill 99 208 512 99 211 512 minecraft:blackstone
fill 99 208 513 99 221 513 minecraft:smooth_basalt
setblock 99 208 551 minecraft:smooth_basalt
fill 100 208 511 100 211 511 minecraft:blackstone
fill 100 208 551 100 211 551 minecraft:blackstone
setblock 104 208 511 minecraft:smooth_basalt
setblock 104 208 551 minecraft:smooth_basalt
setblock 105 208 513 minecraft:light[level=12]
setblock 105 208 521 minecraft:light[level=12]
setblock 105 208 529 minecraft:light[level=12]
setblock 105 208 537 minecraft:light[level=12]
setblock 105 208 545 minecraft:light[level=12]
setblock 113 208 513 minecraft:light[level=12]
setblock 113 208 521 minecraft:light[level=12]
setblock 113 208 529 minecraft:light[level=12]
setblock 113 208 537 minecraft:light[level=12]
setblock 113 208 545 minecraft:light[level=12]
setblock 121 208 513 minecraft:light[level=12]
setblock 121 208 521 minecraft:light[level=12]
setblock 121 208 529 minecraft:light[level=12]
setblock 121 208 537 minecraft:light[level=12]
setblock 121 208 545 minecraft:light[level=12]
setblock 129 208 513 minecraft:light[level=12]
setblock 129 208 521 minecraft:light[level=12]
setblock 129 208 529 minecraft:light[level=12]
setblock 129 208 537 minecraft:light[level=12]
setblock 129 208 545 minecraft:light[level=12]
setblock 134 208 516 minecraft:smooth_basalt
fill 134 208 517 134 211 517 minecraft:blackstone
setblock 134 208 521 minecraft:smooth_basalt
fill 134 208 522 134 209 524 minecraft:blackstone
setblock 135 208 515 minecraft:smooth_basalt
fill 135 208 516 135 211 516 minecraft:blackstone
setblock 135 208 520 minecraft:smooth_basalt
fill 135 208 521 135 211 521 minecraft:blackstone
setblock 135 208 525 minecraft:smooth_basalt
fill 135 208 526 135 210 527 minecraft:blackstone
fill 135 208 536 135 211 536 minecraft:blackstone
setblock 135 208 540 minecraft:smooth_basalt
fill 135 208 541 135 210 542 minecraft:blackstone
setblock 95 209 514 minecraft:smooth_basalt
fill 95 209 515 95 212 515 minecraft:blackstone
setblock 95 209 519 minecraft:smooth_basalt
fill 95 209 520 95 212 520 minecraft:blackstone
setblock 95 209 524 minecraft:smooth_basalt
fill 95 209 525 95 211 526 minecraft:blackstone
setblock 95 209 539 minecraft:smooth_basalt
fill 95 209 540 95 212 540 minecraft:blackstone
setblock 95 209 543 minecraft:blackstone
setblock 95 209 544 minecraft:smooth_basalt
fill 95 209 545 95 210 547 minecraft:blackstone
setblock 96 209 513 minecraft:smooth_basalt
fill 96 209 514 96 212 514 minecraft:blackstone
setblock 96 209 518 minecraft:smooth_basalt
fill 96 209 519 96 212 519 minecraft:blackstone
setblock 96 209 523 minecraft:smooth_basalt
fill 96 209 524 96 212 524 minecraft:blackstone
fill 96 209 541 96 209 542 minecraft:blackstone
setblock 96 209 543 minecraft:smooth_basalt
fill 96 209 544 96 212 544 minecraft:blackstone
fill 96 209 551 96 210 551 minecraft:blackstone
setblock 97 209 512 minecraft:smooth_basalt
setblock 97 209 517 minecraft:smooth_basalt
fill 97 209 518 97 212 518 minecraft:blackstone
setblock 97 209 522 minecraft:smooth_basalt
setblock 98 209 511 minecraft:smooth_basalt
fill 98 209 512 98 212 512 minecraft:blackstone
setblock 98 209 551 minecraft:smooth_basalt
fill 99 209 511 99 212 511 minecraft:blackstone
fill 99 209 551 99 212 551 minecraft:blackstone
fill 100 209 550 100 212 550 minecraft:blackstone
setblock 103 209 511 minecraft:smooth_basalt
setblock 103 209 551 minecraft:smooth_basalt
fill 104 209 551 104 212 551 minecraft:blackstone
fill 116 209 551 117 209 551 minecraft:blackstone
setblock 118 209 551 minecraft:smooth_basalt
fill 119 209 551 119 212 551 minecraft:blackstone
fill 134 209 516 134 212 516 minecraft:blackstone
setblock 134 209 520 minecraft:smooth_basalt
fill 134 209 521 134 212 521 minecraft:blackstone
setblock 134 209 525 minecraft:smooth_basalt
fill 135 209 512 135 210 512 minecraft:blackstone
setblock 135 209 514 minecraft:smooth_basalt
fill 135 209 515 135 212 515 minecraft:blackstone
setblock 135 209 519 minecraft:smooth_basalt
fill 135 209 520 135 212 520 minecraft:blackstone
setblock 135 209 524 minecraft:smooth_basalt
fill 135 209 525 135 212 525 minecraft:blackstone
setblock 135 209 528 minecraft:blackstone
setblock 135 209 529 minecraft:smooth_basalt
setblock 135 209 539 minecraft:smooth_basalt
fill 135 209 540 135 212 540 minecraft:blackstone
setblock 135 209 543 minecraft:blackstone
setblock 135 209 544 minecraft:smooth_basalt
setblock 95 210 513 minecraft:smooth_basalt
fill 95 210 514 95 213 514 minecraft:blackstone
setblock 95 210 518 minecraft:smooth_basalt
fill 95 210 519 95 213 519 minecraft:blackstone
setblock 95 210 523 minecraft:smooth_basalt
fill 95 210 524 95 213 524 minecraft:blackstone
setblock 95 210 527 minecraft:blackstone
setblock 95 210 538 minecraft:smooth_basalt
fill 95 210 539 95 213 539 minecraft:blackstone
setblock 95 210 543 minecraft:smooth_basalt
fill 95 210 544 95 213 544 minecraft:blackstone
setblock 95 210 548 minecraft:smooth_basalt
fill 95 210 549 95 211 551 minecraft:blackstone
setblock 96 210 512 minecraft:smooth_basalt
fill 96 210 513 96 213 513 minecraft:blackstone
setblock 96 210 517 minecraft:smooth_basalt
fill 96 210 518 96 213 518 minecraft:blackstone
setblock 96 210 521 minecraft:blackstone
setblock 96 210 522 minecraft:smooth_basalt
fill 96 210 523 97 212 523 minecraft:blackstone
fill 96 210 525 96 211 525 minecraft:blackstone
fill 96 210 540 96 210 541 minecraft:blackstone
setblock 96 210 542 minecraft:smooth_basalt
fill 96 210 543 96 213 543 minecraft:blackstone
fill 96 210 545 96 210 546 minecraft:blackstone
setblock 96 210 547 minecraft:smooth_basalt
fill 96 210 548 96 213 548 minecraft:blackstone
setblock 97 210 511 minecraft:smooth_basalt
fill 97 210 512 97 213 512 minecraft:blackstone
setblock 97 210 516 minecraft:smooth_basalt
fill 97 210 517 97 213 517 minecraft:blackstone
setblock 97 210 521 minecraft:smooth_basalt
fill 97 210 522 97 213 522 minecraft:blackstone
setblock 97 210 550 minecraft:blackstone
setblock 97 210 551 minecraft:smooth_basalt
fill 98 210 511 98 213 511 minecraft:blackstone
setblock 98 210 550 minecraft:smooth_basalt
fill 98 210 551 98 213 551 minecraft:blackstone
fill 99 210 550 99 213 550 minecraft:blackstone
setblock 101 210 512 minecraft:smooth_basalt
fill 101 210 550 101 211 550 minecraft:blackstone
setblock 102 210 511 minecraft:smooth_basalt
setblock 102 210 551 minecraft:smooth_basalt
fill 103 210 511 103 211 511 minecraft:blackstone
fill 103 210 551 103 213 551 minecraft:blackstone
fill 114 210 551 116 210 551 minecraft:blackstone
setblock 117 210 551 minecraft:smooth_basalt
fill 118 210 551 118 213 551 minecraft:blackstone
fill 123 210 532 123 211 532 minecraft:gold_block
setblock 133 210 519 minecraft:blackstone
setblock 133 210 520 minecraft:smooth_basalt
fill 133 210 521 133 211 523 minecraft:blackstone
fill 134 210 515 134 213 515 minecraft:blackstone
setblock 134 210 519 minecraft:smooth_basalt
fill 134 210 520 134 213 520 minecraft:blackstone
fill 134 210 522 134 210 523 minecraft:blackstone
setblock 134 210 524 minecraft:smooth_basalt
fill 134 210 525 134 212 526 minecraft:blackstone
fill 135 210 511 135 211 511 minecraft:blackstone
setblock 135 210 513 minecraft:smooth_basalt
fill 135 210 514 135 213 514 minecraft:blackstone
setblock 135 210 518 minecraft:smooth_basalt
fill 135 210 519 135 213 519 minecraft:blackstone
setblock 135 210 523 minecraft:smooth_basalt
fill 135 210 524 135 213 524 minecraft:blackstone
setblock 135 210 528 minecraft:smooth_basalt
fill 135 210 529 135 212 530 minecraft:blackstone
setblock 135 210 538 minecraft:smooth_basalt
fill 135 210 539 135 213 539 minecraft:blackstone
setblock 135 210 543 minecraft:smooth_basalt
fill 135 210 544 135 211 546 minecraft:blackstone
setblock 95 211 512 minecraft:smooth_basalt
fill 95 211 513 95 214 513 minecraft:blackstone
setblock 95 211 517 minecraft:smooth_basalt
fill 95 211 518 95 214 518 minecraft:blackstone
setblock 95 211 522 minecraft:smooth_basalt
fill 95 211 523 95 214 523 minecraft:blackstone
setblock 95 211 527 minecraft:smooth_basalt
fill 95 211 528 95 214 528 minecraft:blackstone
setblock 95 211 537 minecraft:smooth_basalt
fill 95 211 538 95 214 538 minecraft:blackstone
setblock 95 211 542 minecraft:smooth_basalt
fill 95 211 543 95 214 543 minecraft:blackstone
fill 95 211 545 95 211 546 minecraft:blackstone
setblock 95 211 547 minecraft:smooth_basalt
fill 95 211 548 95 214 548 minecraft:blackstone
setblock 96 211 511 minecraft:smooth_basalt
fill 96 211 512 96 214 512 minecraft:blackstone
setblock 96 211 516 minecraft:smooth_basalt
fill 96 211 517 96 214 517 minecraft:blackstone
setblock 96 211 521 minecraft:smooth_basalt
fill 96 211 522 96 214 522 minecraft:blackstone
setblock 96 211 526 minecraft:smooth_basalt
fill 96 211 539 96 211 540 minecraft:blackstone
setblock 96 211 541 minecraft:smooth_basalt
fill 96 211 542 97 213 542 minecraft:blackstone
setblock 96 211 545 minecraft:blackstone
setblock 96 211 546 minecraft:smooth_basalt
fill 96 211 547 97 213 547 minecraft:blackstone
fill 96 211 549 96 211 550 minecraft:blackstone
setblock 96 211 551 minecraft:smooth_basalt
fill 97 211 511 97 214 511 minecraft:blackstone
setblock 97 211 515 minecraft:smooth_basalt
fill 97 211 516 97 214 516 minecraft:blackstone
setblock 97 211 520 minecraft:smooth_basalt
fill 97 211 521 97 214 521 minecraft:blackstone
setblock 97 211 524 minecraft:blackstone
fill 97 211 543 97 211 544 minecraft:blackstone
setblock 97 211 545 minecraft:smooth_basalt
fill 97 211 546 97 214 546 minecraft:blackstone
setblock 97 211 550 minecraft:smooth_basalt
fill 97 211 551 97 214 551 minecraft:blackstone
fill 98 211 550 98 214 550 minecraft:blackstone
setblock 100 211 512 minecraft:smooth_basalt
setblock 101 211 511 minecraft:smooth_basalt
setblock 101 211 551 minecraft:smooth_basalt
fill 102 211 511 102 214 511 minecraft:blackstone
setblock 102 211 550 minecraft:smooth_basalt
fill 102 211 551 102 214 551 minecraft:blackstone
setblock 105 211 551 minecraft:blackstone
fill 112 211 551 115 211 551 minecraft:blackstone
fill 115 211 550 116 211 550 minecraft:blackstone
setblock 116 211 551 minecraft:smooth_basalt
setblock 117 211 550 minecraft:smooth_basalt
fill 117 211 551 117 214 551 minecraft:blackstone
fill 118 211 550 118 214 550 minecraft:blackstone
setblock 120 211 551 minecraft:blackstone
setblock 133 211 518 minecraft:blackstone
setblock 133 211 519 minecraft:smooth_basalt
fill 133 211 520 133 214 520 minecraft:blackstone
setblock 133 211 524 minecraft:smooth_basalt
fill 133 211 525 133 214 525 minecraft:blackstone
fill 134 211 511 134 212 511 minecraft:blackstone
setblock 134 211 518 minecraft:smooth_basalt
fill 134 211 519 134 214 519 minecraft:blackstone
setblock 134 211 522 minecraft:blackstone
setblock 134 211 523 minecraft:smooth_basalt
fill 134 211 524 134 214 524 minecraft:blackstone
setblock 134 211 527 minecraft:blackstone
setblock 134 211 528 minecraft:smooth_basalt
setblock 135 211 512 minecraft:smooth_basalt
fill 135 211 513 135 214 513 minecraft:blackstone
setblock 135 211 517 minecraft:smooth_basalt
fill 135 211 518 135 214 518 minecraft:blackstone
setblock 135 211 522 minecraft:smooth_basalt
fill 135 211 523 135 214 523 minecraft:blackstone
setblock 135 211 526 minecraft:blackstone
setblock 135 211 527 minecraft:smooth_basalt
fill 135 211 528 135 214 528 minecraft:blackstone
setblock 135 211 531 minecraft:blackstone
setblock 135 211 532 minecraft:smooth_basalt
fill 135 211 535 135 212 535 minecraft:blackstone
setblock 135 211 537 minecraft:smooth_basalt
fill 135 211 538 135 214 538 minecraft:blackstone
setblock 135 211 541 minecraft:blackstone
setblock 135 211 542 minecraft:smooth_basalt
fill 135 211 543 135 214 543 minecraft:blackstone
setblock 135 211 547 minecraft:smooth_basalt
fill 135 211 548 135 213 549 minecraft:blackstone
setblock 95 212 511 minecraft:smooth_basalt
fill 95 212 512 95 215 512 minecraft:blackstone
setblock 95 212 516 minecraft:smooth_basalt
fill 95 212 517 95 215 517 minecraft:blackstone
setblock 95 212 521 minecraft:smooth_basalt
fill 95 212 522 95 215 522 minecraft:blackstone
setblock 95 212 525 minecraft:blackstone
setblock 95 212 526 minecraft:smooth_basalt
fill 95 212 527 96 214 527 minecraft:blackstone
fill 95 212 529 95 212 530 minecraft:blackstone
fill 95 212 537 95 215 537 minecraft:blackstone
setblock 95 212 541 minecraft:smooth_basalt
fill 95 212 542 95 215 542 minecraft:blackstone
setblock 95 212 545 minecraft:blackstone
setblock 95 212 546 minecraft:smooth_basalt
fill 95 212 547 95 215 547 minecraft:blackstone
fill 95 212 549 95 212 550 minecraft:blackstone
setblock 95 212 551 minecraft:smooth_basalt
fill 96 212 511 96 215 511 minecraft:blackstone
setblock 96 212 515 minecraft:smooth_basalt
fill 96 212 516 96 215 516 minecraft:blackstone
setblock 96 212 520 minecraft:smooth_basalt
fill 96 212 521 96 215 521 minecraft:blackstone
setblock 96 212 525 minecraft:smooth_basalt
fill 96 212 526 96 215 526 minecraft:blackstone
setblock 96 212 539 minecraft:blackstone
setblock 96 212 540 minecraft:smooth_basalt
fill 96 212 541 97 214 541 minecraft:blackstone
setblock 96 212 545 minecraft:smooth_basalt
fill 96 212 546 96 215 546 minecraft:blackstone
schedule function dropper:buildpart/122_8 1t
