setblock 171 161 363 minecraft:purple_concrete
setblock 172 161 325 minecraft:light[level=12]
setblock 172 161 332 minecraft:light[level=12]
setblock 172 161 339 minecraft:light[level=12]
setblock 172 161 346 minecraft:light[level=12]
setblock 172 161 360 minecraft:light[level=12]
setblock 173 161 323 minecraft:dark_prismarine
fill 174 161 323 174 162 323 minecraft:blue_terracotta
fill 176 161 363 177 161 363 minecraft:blue_terracotta
fill 177 161 337 177 194 337 minecraft:magenta_terracotta
fill 177 161 338 178 161 338 minecraft:pink_terracotta
setblock 178 161 323 minecraft:dark_prismarine
setblock 178 161 363 minecraft:dark_prismarine
fill 179 161 323 179 162 323 minecraft:blue_terracotta
setblock 179 161 325 minecraft:light[level=12]
setblock 179 161 332 minecraft:light[level=12]
fill 179 161 338 179 162 338 minecraft:magenta_terracotta
setblock 179 161 339 minecraft:light[level=12]
setblock 179 161 346 minecraft:light[level=12]
setblock 179 161 353 minecraft:light[level=12]
setblock 179 161 360 minecraft:light[level=12]
setblock 179 161 362 minecraft:dark_prismarine
fill 179 161 363 179 162 363 minecraft:blue_terracotta
setblock 180 161 350 minecraft:blue_terracotta
setblock 180 161 351 minecraft:dark_prismarine
fill 180 161 352 180 162 352 minecraft:blue_terracotta
setblock 180 161 356 minecraft:dark_prismarine
fill 180 161 357 180 162 358 minecraft:blue_terracotta
fill 180 161 362 180 162 362 minecraft:blue_terracotta
setblock 181 161 325 minecraft:dark_prismarine
fill 181 161 326 181 162 326 minecraft:blue_terracotta
setblock 181 161 330 minecraft:dark_prismarine
fill 181 161 331 181 162 331 minecraft:blue_terracotta
fill 181 161 333 181 161 334 minecraft:blue_terracotta
fill 181 161 346 181 161 349 minecraft:blue_terracotta
setblock 181 161 350 minecraft:dark_prismarine
fill 181 161 351 181 162 351 minecraft:blue_terracotta
setblock 181 161 354 minecraft:blue_terracotta
setblock 181 161 355 minecraft:dark_prismarine
fill 181 161 356 181 162 356 minecraft:blue_terracotta
setblock 181 161 359 minecraft:blue_terracotta
setblock 181 161 360 minecraft:dark_prismarine
fill 181 161 361 181 162 361 minecraft:blue_terracotta
setblock 182 161 324 minecraft:dark_prismarine
fill 182 161 325 182 162 325 minecraft:blue_terracotta
setblock 182 161 329 minecraft:dark_prismarine
fill 182 161 330 182 162 330 minecraft:blue_terracotta
setblock 182 161 334 minecraft:dark_prismarine
fill 182 161 335 182 162 335 minecraft:blue_terracotta
fill 182 161 337 182 161 338 minecraft:blue_terracotta
fill 182 161 342 182 162 342 minecraft:blue_terracotta
setblock 182 161 344 minecraft:dark_prismarine
fill 182 161 345 182 162 345 minecraft:blue_terracotta
setblock 182 161 349 minecraft:dark_prismarine
fill 182 161 350 182 162 350 minecraft:blue_terracotta
setblock 182 161 354 minecraft:dark_prismarine
fill 182 161 355 182 162 355 minecraft:blue_terracotta
setblock 182 161 359 minecraft:dark_prismarine
fill 182 161 360 182 162 360 minecraft:blue_terracotta
fill 141 162 329 142 162 329 minecraft:blue_terracotta
setblock 142 162 323 minecraft:dark_prismarine
setblock 142 162 324 minecraft:blue_terracotta
setblock 142 162 328 minecraft:dark_prismarine
setblock 142 162 332 minecraft:blue_terracotta
setblock 142 162 333 minecraft:dark_prismarine
fill 142 162 334 142 162 337 minecraft:blue_terracotta
setblock 142 162 338 minecraft:dark_prismarine
fill 142 162 339 142 162 342 minecraft:blue_terracotta
setblock 142 162 343 minecraft:dark_prismarine
setblock 142 162 344 minecraft:blue_terracotta
setblock 142 162 348 minecraft:dark_prismarine
setblock 142 162 349 minecraft:blue_terracotta
setblock 142 162 353 minecraft:dark_prismarine
setblock 142 162 354 minecraft:blue_terracotta
setblock 142 162 358 minecraft:dark_prismarine
setblock 142 162 359 minecraft:blue_terracotta
setblock 142 162 363 minecraft:dark_prismarine
setblock 143 162 323 minecraft:blue_terracotta
setblock 143 162 327 minecraft:dark_prismarine
setblock 143 162 328 minecraft:blue_terracotta
setblock 143 162 332 minecraft:dark_prismarine
setblock 143 162 333 minecraft:blue_terracotta
setblock 143 162 336 minecraft:blue_terracotta
setblock 143 162 337 minecraft:dark_prismarine
setblock 143 162 338 minecraft:blue_terracotta
setblock 143 162 342 minecraft:dark_prismarine
setblock 143 162 343 minecraft:blue_terracotta
setblock 143 162 347 minecraft:dark_prismarine
setblock 143 162 348 minecraft:blue_terracotta
setblock 143 162 352 minecraft:dark_prismarine
setblock 143 162 353 minecraft:blue_terracotta
setblock 143 162 356 minecraft:blue_terracotta
setblock 143 162 357 minecraft:dark_prismarine
setblock 143 162 358 minecraft:blue_terracotta
setblock 143 162 362 minecraft:dark_prismarine
setblock 143 162 363 minecraft:blue_terracotta
setblock 144 162 330 minecraft:blue_terracotta
setblock 144 162 331 minecraft:dark_prismarine
setblock 144 162 332 minecraft:blue_terracotta
setblock 144 162 335 minecraft:blue_terracotta
setblock 144 162 336 minecraft:dark_prismarine
setblock 144 162 346 minecraft:dark_prismarine
setblock 144 162 347 minecraft:blue_terracotta
setblock 144 162 351 minecraft:dark_prismarine
setblock 144 162 352 minecraft:blue_terracotta
setblock 144 162 356 minecraft:dark_prismarine
setblock 144 162 357 minecraft:blue_terracotta
setblock 144 162 359 minecraft:blue_terracotta
setblock 145 162 350 minecraft:dark_prismarine
setblock 145 162 351 minecraft:blue_terracotta
setblock 145 162 355 minecraft:dark_prismarine
setblock 145 162 356 minecraft:blue_terracotta
setblock 147 162 323 minecraft:purple_concrete
fill 147 162 348 147 185 349 minecraft:magenta_terracotta
fill 152 162 334 152 181 334 minecraft:magenta_terracotta
setblock 155 162 343 minecraft:dark_prismarine
setblock 155 162 357 minecraft:magenta_terracotta
fill 156 162 358 156 186 358 minecraft:magenta_terracotta
setblock 158 162 323 minecraft:blue_terracotta
setblock 158 162 363 minecraft:purple_concrete
setblock 160 162 325 minecraft:dark_prismarine
setblock 161 162 324 minecraft:dark_prismarine
setblock 161 162 325 minecraft:blue_terracotta
setblock 161 162 363 minecraft:blue_terracotta
setblock 162 162 323 minecraft:dark_prismarine
setblock 162 162 324 minecraft:blue_terracotta
setblock 162 162 363 minecraft:dark_prismarine
setblock 163 162 323 minecraft:blue_terracotta
fill 163 162 338 163 162 347 minecraft:purple_concrete
setblock 163 162 362 minecraft:dark_prismarine
setblock 163 162 363 minecraft:blue_terracotta
setblock 164 162 326 minecraft:dark_prismarine
setblock 165 162 325 minecraft:dark_prismarine
setblock 165 162 326 minecraft:blue_terracotta
setblock 166 162 324 minecraft:dark_prismarine
setblock 166 162 325 minecraft:blue_terracotta
setblock 167 162 323 minecraft:dark_prismarine
setblock 167 162 324 minecraft:blue_terracotta
fill 167 162 329 168 180 329 minecraft:magenta_terracotta
setblock 167 162 363 minecraft:dark_prismarine
setblock 168 162 323 minecraft:blue_terracotta
setblock 168 162 363 minecraft:blue_terracotta
fill 171 162 352 172 178 352 minecraft:magenta_terracotta
setblock 172 162 323 minecraft:dark_prismarine
setblock 173 162 323 minecraft:blue_terracotta
fill 175 162 363 176 162 363 minecraft:blue_terracotta
setblock 177 162 323 minecraft:dark_prismarine
fill 177 162 338 178 185 338 minecraft:magenta_terracotta
setblock 177 162 363 minecraft:dark_prismarine
setblock 178 162 323 minecraft:blue_terracotta
setblock 178 162 362 minecraft:dark_prismarine
setblock 178 162 363 minecraft:blue_terracotta
setblock 179 162 362 minecraft:blue_terracotta
setblock 180 162 329 minecraft:blue_terracotta
setblock 180 162 330 minecraft:dark_prismarine
setblock 180 162 349 minecraft:blue_terracotta
setblock 180 162 350 minecraft:dark_prismarine
setblock 180 162 351 minecraft:blue_terracotta
fill 180 162 353 180 162 354 minecraft:blue_terracotta
setblock 180 162 355 minecraft:dark_prismarine
setblock 180 162 356 minecraft:blue_terracotta
setblock 180 162 359 minecraft:blue_terracotta
setblock 180 162 360 minecraft:dark_prismarine
setblock 181 162 324 minecraft:dark_prismarine
setblock 181 162 325 minecraft:blue_terracotta
setblock 181 162 329 minecraft:dark_prismarine
setblock 181 162 330 minecraft:blue_terracotta
setblock 181 162 333 minecraft:blue_terracotta
setblock 181 162 334 minecraft:dark_prismarine
setblock 181 162 335 minecraft:blue_terracotta
fill 181 162 346 181 162 348 minecraft:blue_terracotta
setblock 181 162 349 minecraft:dark_prismarine
setblock 181 162 350 minecraft:blue_terracotta
setblock 181 162 354 minecraft:dark_prismarine
setblock 181 162 355 minecraft:blue_terracotta
setblock 181 162 359 minecraft:dark_prismarine
setblock 181 162 360 minecraft:blue_terracotta
fill 182 162 322 182 220 322 minecraft:blue_terracotta
setblock 182 162 323 minecraft:dark_prismarine
setblock 182 162 324 minecraft:blue_terracotta
setblock 182 162 328 minecraft:dark_prismarine
setblock 182 162 329 minecraft:blue_terracotta
setblock 182 162 333 minecraft:dark_prismarine
setblock 182 162 334 minecraft:blue_terracotta
setblock 182 162 337 minecraft:blue_terracotta
setblock 182 162 338 minecraft:dark_prismarine
fill 182 162 339 182 162 341 minecraft:blue_terracotta
setblock 182 162 343 minecraft:dark_prismarine
setblock 182 162 344 minecraft:blue_terracotta
setblock 182 162 348 minecraft:dark_prismarine
setblock 182 162 349 minecraft:blue_terracotta
setblock 182 162 353 minecraft:dark_prismarine
setblock 182 162 354 minecraft:blue_terracotta
setblock 182 162 358 minecraft:dark_prismarine
setblock 182 162 359 minecraft:blue_terracotta
setblock 182 162 363 minecraft:dark_prismarine
fill 141 163 329 141 220 329 minecraft:blue_terracotta
fill 181 163 322 181 216 322 minecraft:blue_terracotta
fill 155 164 357 155 187 357 minecraft:magenta_terracotta
fill 169 164 328 169 211 328 minecraft:magenta_terracotta
setblock 144 165 325 minecraft:light[level=13]
setblock 144 165 333 minecraft:light[level=13]
setblock 144 165 341 minecraft:light[level=13]
setblock 144 165 349 minecraft:light[level=13]
setblock 144 165 357 minecraft:light[level=13]
fill 147 165 347 147 223 347 minecraft:magenta_terracotta
setblock 152 165 325 minecraft:light[level=13]
setblock 152 165 341 minecraft:light[level=13]
setblock 152 165 349 minecraft:light[level=13]
setblock 152 165 357 minecraft:light[level=13]
setblock 160 165 325 minecraft:light[level=13]
setblock 160 165 333 minecraft:light[level=13]
setblock 160 165 341 minecraft:light[level=13]
setblock 160 165 349 minecraft:light[level=13]
setblock 160 165 357 minecraft:light[level=13]
setblock 168 165 325 minecraft:light[level=13]
setblock 168 165 333 minecraft:light[level=13]
setblock 168 165 341 minecraft:light[level=13]
setblock 168 165 349 minecraft:light[level=13]
setblock 168 165 357 minecraft:light[level=13]
fill 170 165 352 170 187 352 minecraft:magenta_terracotta
setblock 176 165 325 minecraft:light[level=13]
setblock 176 165 333 minecraft:light[level=13]
setblock 176 165 341 minecraft:light[level=13]
setblock 176 165 349 minecraft:light[level=13]
setblock 176 165 357 minecraft:light[level=13]
setblock 178 165 364 minecraft:light_blue_wool
fill 176 166 338 176 214 338 minecraft:magenta_terracotta
fill 178 166 364 178 220 364 minecraft:blue_terracotta
setblock 144 167 325 minecraft:light[level=12]
setblock 144 167 332 minecraft:light[level=12]
setblock 144 167 339 minecraft:light[level=12]
setblock 144 167 346 minecraft:light[level=12]
setblock 144 167 353 minecraft:light[level=12]
setblock 144 167 360 minecraft:light[level=12]
setblock 151 167 325 minecraft:light[level=12]
setblock 151 167 332 minecraft:light[level=12]
setblock 151 167 339 minecraft:light[level=12]
setblock 151 167 346 minecraft:light[level=12]
setblock 151 167 353 minecraft:light[level=12]
setblock 151 167 360 minecraft:light[level=12]
setblock 158 167 325 minecraft:light[level=12]
setblock 158 167 332 minecraft:light[level=12]
setblock 158 167 339 minecraft:light[level=12]
setblock 158 167 346 minecraft:light[level=12]
setblock 158 167 353 minecraft:light[level=12]
setblock 158 167 360 minecraft:light[level=12]
fill 159 167 345 161 182 345 minecraft:white_concrete
fill 160 167 340 161 182 340 minecraft:white_concrete
fill 160 167 344 162 182 344 minecraft:white_concrete
fill 161 167 341 162 182 343 minecraft:white_concrete
setblock 165 167 325 minecraft:light[level=12]
setblock 165 167 332 minecraft:light[level=12]
setblock 165 167 339 minecraft:light[level=12]
setblock 165 167 346 minecraft:light[level=12]
setblock 165 167 353 minecraft:light[level=12]
setblock 165 167 360 minecraft:light[level=12]
setblock 172 167 325 minecraft:light[level=12]
setblock 172 167 332 minecraft:light[level=12]
setblock 172 167 339 minecraft:light[level=12]
setblock 172 167 346 minecraft:light[level=12]
setblock 172 167 360 minecraft:light[level=12]
setblock 179 167 325 minecraft:light[level=12]
setblock 179 167 332 minecraft:light[level=12]
setblock 179 167 339 minecraft:light[level=12]
setblock 179 167 346 minecraft:light[level=12]
setblock 179 167 353 minecraft:light[level=12]
setblock 179 167 360 minecraft:light[level=12]
fill 156 168 340 156 182 340 minecraft:white_concrete
fill 156 168 344 156 182 345 minecraft:white_concrete
fill 157 168 339 163 182 339 minecraft:white_concrete
fill 157 168 345 158 182 346 minecraft:white_concrete
fill 158 168 338 162 182 338 minecraft:white_concrete
fill 158 168 347 162 182 347 minecraft:white_concrete
fill 159 168 346 163 182 346 minecraft:white_concrete
fill 162 168 340 164 182 340 minecraft:white_concrete
fill 162 168 345 164 182 345 minecraft:white_concrete
fill 163 168 341 164 182 344 minecraft:white_concrete
fill 170 168 353 170 203 353 minecraft:magenta_terracotta
fill 154 169 334 154 190 334 minecraft:magenta_terracotta
fill 154 169 341 155 180 344 minecraft:white_concrete
fill 155 169 339 155 181 340 minecraft:white_concrete
fill 155 169 345 155 181 346 minecraft:white_concrete
fill 156 169 338 156 181 339 minecraft:white_concrete
fill 156 169 346 156 181 347 minecraft:white_concrete
fill 157 169 338 157 181 338 minecraft:white_concrete
fill 157 169 347 157 181 347 minecraft:white_concrete
fill 158 169 337 162 181 337 minecraft:white_concrete
fill 158 169 348 162 182 348 minecraft:white_concrete
fill 163 169 338 164 182 338 minecraft:white_concrete
fill 163 169 347 164 182 347 minecraft:white_concrete
fill 164 169 339 165 182 339 minecraft:white_concrete
fill 164 169 346 165 182 346 minecraft:white_concrete
fill 165 169 340 165 182 345 minecraft:white_concrete
fill 166 169 341 166 182 344 minecraft:white_concrete
fill 168 169 327 168 234 327 minecraft:magenta_terracotta
fill 153 170 342 153 179 343 minecraft:white_concrete
fill 154 170 339 154 179 340 minecraft:white_concrete
fill 154 170 345 154 180 346 minecraft:white_concrete
fill 155 170 338 155 180 338 minecraft:white_concrete
fill 155 170 347 155 181 347 minecraft:white_concrete
fill 156 170 337 157 180 337 minecraft:white_concrete
fill 156 170 348 157 181 348 minecraft:white_concrete
fill 158 170 336 162 181 336 minecraft:white_concrete
fill 158 170 349 162 181 349 minecraft:white_concrete
fill 160 170 322 163 180 322 minecraft:blue_terracotta
fill 163 170 337 164 181 337 minecraft:white_concrete
fill 163 170 348 164 181 348 minecraft:white_concrete
setblock 164 170 322 minecraft:cyan_concrete
fill 165 170 322 166 217 322 minecraft:blue_terracotta
fill 165 170 338 165 181 338 minecraft:white_concrete
fill 165 170 347 165 181 347 minecraft:white_concrete
fill 166 170 339 166 181 340 minecraft:white_concrete
fill 166 170 345 166 181 346 minecraft:white_concrete
fill 167 170 342 167 181 343 minecraft:white_concrete
fill 149 171 364 152 217 364 minecraft:blue_terracotta
fill 153 171 340 153 178 341 minecraft:white_concrete
fill 153 171 344 153 179 345 minecraft:white_concrete
setblock 153 171 364 minecraft:light_blue_wool
fill 154 171 338 154 180 338 minecraft:white_concrete
fill 154 171 347 154 180 347 minecraft:white_concrete
fill 154 171 364 156 199 364 minecraft:blue_terracotta
fill 155 171 337 155 180 337 minecraft:white_concrete
fill 155 171 348 155 180 348 minecraft:white_concrete
fill 156 171 336 157 180 336 minecraft:white_concrete
fill 156 171 349 157 180 349 minecraft:white_concrete
fill 158 171 335 162 180 335 minecraft:white_concrete
fill 158 171 350 162 180 350 minecraft:white_concrete
fill 163 171 336 164 180 336 minecraft:white_concrete
fill 163 171 349 164 180 349 minecraft:white_concrete
fill 164 171 322 164 221 322 minecraft:blue_terracotta
fill 165 171 337 165 180 337 minecraft:white_concrete
fill 165 171 348 165 180 348 minecraft:white_concrete
fill 166 171 338 166 180 338 minecraft:white_concrete
fill 166 171 347 166 180 347 minecraft:white_concrete
fill 167 171 340 167 180 341 minecraft:white_concrete
fill 167 171 344 167 180 345 minecraft:white_concrete
setblock 183 171 337 minecraft:cyan_concrete
fill 152 172 341 152 179 344 minecraft:white_concrete
fill 153 172 339 153 179 339 minecraft:white_concrete
fill 153 172 346 153 179 346 minecraft:white_concrete
fill 153 172 364 153 220 364 minecraft:blue_terracotta
fill 154 172 333 154 206 333 minecraft:magenta_terracotta
fill 154 172 337 154 179 337 minecraft:white_concrete
fill 154 172 348 154 179 348 minecraft:white_concrete
fill 155 172 336 155 179 336 minecraft:white_concrete
fill 155 172 349 155 179 349 minecraft:white_concrete
fill 157 172 335 157 179 335 minecraft:white_concrete
fill 157 172 350 157 179 350 minecraft:white_concrete
fill 163 172 335 163 179 335 minecraft:white_concrete
fill 163 172 350 163 179 350 minecraft:white_concrete
fill 165 172 336 165 179 336 minecraft:white_concrete
fill 165 172 349 165 179 349 minecraft:white_concrete
fill 166 172 337 166 179 337 minecraft:white_concrete
fill 166 172 348 166 179 348 minecraft:white_concrete
fill 167 172 339 167 179 339 minecraft:white_concrete
fill 167 172 346 167 179 346 minecraft:white_concrete
fill 168 172 341 168 179 344 minecraft:white_concrete
fill 171 172 354 171 205 354 minecraft:magenta_terracotta
fill 183 172 337 183 207 337 minecraft:blue_terracotta
setblock 144 173 325 minecraft:light[level=13]
setblock 144 173 332 minecraft:light[level=12]
setblock 144 173 333 minecraft:light[level=13]
setblock 144 173 339 minecraft:light[level=12]
setblock 144 173 341 minecraft:light[level=13]
setblock 144 173 346 minecraft:light[level=12]
setblock 144 173 349 minecraft:light[level=13]
setblock 144 173 353 minecraft:light[level=12]
setblock 144 173 357 minecraft:light[level=13]
setblock 144 173 360 minecraft:light[level=12]
setblock 151 173 325 minecraft:light[level=12]
setblock 151 173 332 minecraft:light[level=12]
setblock 151 173 339 minecraft:light[level=12]
setblock 151 173 346 minecraft:light[level=12]
setblock 151 173 353 minecraft:light[level=12]
setblock 151 173 360 minecraft:light[level=12]
setblock 152 173 325 minecraft:light[level=13]
fill 152 173 340 152 178 340 minecraft:white_concrete
fill 152 173 345 152 178 345 minecraft:white_concrete
setblock 152 173 349 minecraft:light[level=13]
setblock 152 173 357 minecraft:light[level=13]
fill 153 173 338 153 178 338 minecraft:white_concrete
fill 153 173 347 153 178 347 minecraft:white_concrete
fill 156 173 335 156 178 335 minecraft:white_concrete
fill 156 173 350 156 178 350 minecraft:white_concrete
setblock 158 173 325 minecraft:light[level=12]
setblock 158 173 332 minecraft:light[level=12]
setblock 158 173 353 minecraft:light[level=12]
setblock 158 173 360 minecraft:light[level=12]
fill 159 173 334 161 178 334 minecraft:white_concrete
fill 159 173 351 161 178 351 minecraft:white_concrete
setblock 160 173 325 minecraft:light[level=13]
setblock 160 173 333 minecraft:light[level=13]
setblock 160 173 357 minecraft:light[level=13]
fill 164 173 335 164 178 335 minecraft:white_concrete
fill 164 173 350 164 178 350 minecraft:white_concrete
setblock 165 173 325 minecraft:light[level=12]
setblock 165 173 332 minecraft:light[level=12]
setblock 165 173 353 minecraft:light[level=12]
setblock 165 173 360 minecraft:light[level=12]
fill 167 173 338 167 178 338 minecraft:white_concrete
fill 167 173 347 167 178 347 minecraft:white_concrete
setblock 168 173 325 minecraft:light[level=13]
setblock 168 173 333 minecraft:light[level=13]
fill 168 173 340 168 178 340 minecraft:white_concrete
fill 168 173 345 168 178 345 minecraft:white_concrete
setblock 168 173 349 minecraft:light[level=13]
setblock 168 173 357 minecraft:light[level=13]
setblock 172 173 325 minecraft:light[level=12]
setblock 172 173 332 minecraft:light[level=12]
setblock 172 173 339 minecraft:light[level=12]
setblock 172 173 346 minecraft:light[level=12]
setblock 172 173 360 minecraft:light[level=12]
setblock 176 173 325 minecraft:light[level=13]
setblock 176 173 333 minecraft:light[level=13]
setblock 176 173 341 minecraft:light[level=13]
setblock 176 173 349 minecraft:light[level=13]
setblock 176 173 357 minecraft:light[level=13]
setblock 179 173 325 minecraft:light[level=12]
setblock 179 173 332 minecraft:light[level=12]
setblock 179 173 339 minecraft:light[level=12]
setblock 179 173 346 minecraft:light[level=12]
setblock 179 173 353 minecraft:light[level=12]
setblock 179 173 360 minecraft:light[level=12]
fill 141 174 330 141 220 330 minecraft:blue_terracotta
setblock 141 174 331 minecraft:light_blue_wool
fill 141 174 332 141 220 335 minecraft:blue_terracotta
fill 152 174 339 152 177 339 minecraft:white_concrete
fill 152 174 346 152 177 346 minecraft:white_concrete
fill 154 174 336 154 177 336 minecraft:white_concrete
fill 154 174 349 154 177 349 minecraft:white_concrete
fill 158 174 334 158 177 334 minecraft:white_concrete
fill 158 174 351 158 177 351 minecraft:white_concrete
fill 162 174 334 162 177 334 minecraft:white_concrete
fill 162 174 351 162 177 351 minecraft:white_concrete
fill 166 174 336 166 177 336 minecraft:white_concrete
fill 166 174 349 166 177 349 minecraft:white_concrete
fill 168 174 339 168 177 339 minecraft:white_concrete
fill 168 174 346 168 177 346 minecraft:white_concrete
fill 141 175 331 141 197 331 minecraft:blue_terracotta
setblock 142 175 323 minecraft:magenta_terracotta
fill 142 175 324 142 175 327 minecraft:purple_terracotta
setblock 142 175 328 minecraft:magenta_terracotta
fill 142 175 329 142 175 332 minecraft:purple_terracotta
setblock 142 175 333 minecraft:magenta_terracotta
fill 142 175 334 142 175 337 minecraft:purple_terracotta
setblock 142 175 338 minecraft:magenta_terracotta
fill 142 175 339 142 175 342 minecraft:purple_terracotta
setblock 142 175 343 minecraft:magenta_terracotta
fill 142 175 344 142 175 347 minecraft:purple_terracotta
setblock 142 175 348 minecraft:magenta_terracotta
fill 142 175 349 142 175 352 minecraft:purple_terracotta
setblock 142 175 353 minecraft:magenta_terracotta
fill 142 175 354 142 175 357 minecraft:purple_terracotta
setblock 142 175 358 minecraft:magenta_terracotta
fill 142 175 359 142 175 362 minecraft:purple_terracotta
setblock 142 175 363 minecraft:magenta_terracotta
fill 143 175 323 146 175 323 minecraft:purple_terracotta
setblock 143 175 324 minecraft:magenta_terracotta
fill 143 175 325 143 175 328 minecraft:purple_terracotta
setblock 143 175 329 minecraft:magenta_terracotta
fill 143 175 330 143 175 333 minecraft:purple_terracotta
setblock 143 175 334 minecraft:magenta_terracotta
fill 143 175 335 143 175 338 minecraft:purple_terracotta
setblock 143 175 339 minecraft:magenta_terracotta
fill 143 175 340 143 175 343 minecraft:purple_terracotta
setblock 143 175 344 minecraft:magenta_terracotta
fill 143 175 345 143 175 348 minecraft:purple_terracotta
setblock 143 175 349 minecraft:magenta_terracotta
fill 143 175 350 143 175 353 minecraft:purple_terracotta
setblock 143 175 354 minecraft:magenta_terracotta
fill 143 175 355 143 175 358 minecraft:purple_terracotta
setblock 143 175 359 minecraft:magenta_terracotta
fill 143 175 360 143 175 363 minecraft:purple_terracotta
fill 144 175 324 147 175 324 minecraft:purple_terracotta
setblock 144 175 325 minecraft:magenta_terracotta
fill 144 175 326 144 175 329 minecraft:purple_terracotta
setblock 144 175 330 minecraft:magenta_terracotta
fill 144 175 331 144 175 334 minecraft:purple_terracotta
setblock 144 175 335 minecraft:magenta_terracotta
fill 144 175 336 144 175 339 minecraft:purple_terracotta
setblock 144 175 340 minecraft:magenta_terracotta
fill 144 175 341 144 175 344 minecraft:purple_terracotta
setblock 144 175 345 minecraft:magenta_terracotta
fill 144 175 346 144 175 349 minecraft:purple_terracotta
setblock 144 175 350 minecraft:magenta_terracotta
fill 144 175 351 144 175 354 minecraft:purple_terracotta
setblock 144 175 355 minecraft:magenta_terracotta
fill 144 175 356 144 175 359 minecraft:purple_terracotta
setblock 144 175 360 minecraft:magenta_terracotta
fill 144 175 361 144 175 363 minecraft:purple_terracotta
fill 145 175 325 148 175 325 minecraft:purple_terracotta
setblock 145 175 326 minecraft:magenta_terracotta
fill 145 175 327 145 175 330 minecraft:purple_terracotta
setblock 145 175 331 minecraft:magenta_terracotta
fill 145 175 332 145 175 335 minecraft:purple_terracotta
setblock 145 175 336 minecraft:magenta_terracotta
fill 145 175 337 145 175 340 minecraft:purple_terracotta
setblock 145 175 341 minecraft:magenta_terracotta
fill 145 175 342 145 175 345 minecraft:purple_terracotta
setblock 145 175 346 minecraft:magenta_terracotta
fill 145 175 347 145 175 350 minecraft:purple_terracotta
setblock 145 175 351 minecraft:magenta_terracotta
fill 145 175 352 145 175 355 minecraft:purple_terracotta
setblock 145 175 356 minecraft:magenta_terracotta
fill 145 175 357 145 175 360 minecraft:purple_terracotta
setblock 145 175 361 minecraft:magenta_terracotta
fill 145 175 362 145 175 363 minecraft:purple_terracotta
fill 146 175 326 149 175 326 minecraft:purple_terracotta
setblock 146 175 327 minecraft:magenta_terracotta
fill 146 175 328 146 175 331 minecraft:purple_terracotta
setblock 146 175 332 minecraft:magenta_terracotta
fill 146 175 333 146 175 336 minecraft:purple_terracotta
setblock 146 175 337 minecraft:magenta_terracotta
fill 146 175 338 146 175 341 minecraft:purple_terracotta
setblock 146 175 342 minecraft:magenta_terracotta
fill 146 175 343 146 175 346 minecraft:purple_terracotta
setblock 146 175 347 minecraft:magenta_terracotta
fill 146 175 350 148 175 351 minecraft:purple_terracotta
setblock 146 175 352 minecraft:magenta_terracotta
fill 146 175 353 146 175 356 minecraft:purple_terracotta
setblock 146 175 357 minecraft:magenta_terracotta
fill 146 175 358 146 175 361 minecraft:purple_terracotta
setblock 146 175 362 minecraft:magenta_terracotta
setblock 146 175 363 minecraft:purple_terracotta
setblock 147 175 323 minecraft:magenta_terracotta
fill 147 175 327 150 175 327 minecraft:purple_terracotta
setblock 147 175 328 minecraft:magenta_terracotta
fill 147 175 329 147 175 332 minecraft:purple_terracotta
setblock 147 175 333 minecraft:magenta_terracotta
fill 147 175 334 147 175 337 minecraft:purple_terracotta
setblock 147 175 338 minecraft:magenta_terracotta
fill 147 175 339 147 175 342 minecraft:purple_terracotta
setblock 147 175 343 minecraft:magenta_terracotta
fill 147 175 344 147 175 346 minecraft:purple_terracotta
fill 147 175 352 150 175 352 minecraft:purple_terracotta
setblock 147 175 353 minecraft:magenta_terracotta
fill 147 175 354 147 175 357 minecraft:purple_terracotta
setblock 147 175 358 minecraft:magenta_terracotta
fill 147 175 359 147 175 362 minecraft:purple_terracotta
setblock 147 175 363 minecraft:magenta_terracotta
fill 148 175 323 151 175 323 minecraft:purple_terracotta
setblock 148 175 324 minecraft:magenta_terracotta
fill 148 175 328 151 175 328 minecraft:purple_terracotta
setblock 148 175 329 minecraft:magenta_terracotta
fill 148 175 330 148 175 333 minecraft:purple_terracotta
setblock 148 175 334 minecraft:magenta_terracotta
fill 148 175 335 148 175 338 minecraft:purple_terracotta
setblock 148 175 339 minecraft:magenta_terracotta
fill 148 175 340 148 175 343 minecraft:purple_terracotta
setblock 148 175 344 minecraft:magenta_terracotta
fill 148 175 345 148 175 347 minecraft:purple_terracotta
fill 148 175 353 151 175 353 minecraft:purple_terracotta
setblock 148 175 354 minecraft:magenta_terracotta
fill 148 175 355 148 175 358 minecraft:purple_terracotta
setblock 148 175 359 minecraft:magenta_terracotta
fill 148 175 360 148 175 363 minecraft:purple_terracotta
fill 149 175 324 152 175 324 minecraft:purple_terracotta
setblock 149 175 325 minecraft:magenta_terracotta
fill 149 175 329 152 175 329 minecraft:purple_terracotta
setblock 149 175 330 minecraft:magenta_terracotta
fill 149 175 331 149 175 334 minecraft:purple_terracotta
setblock 149 175 335 minecraft:magenta_terracotta
fill 149 175 336 149 175 339 minecraft:purple_terracotta
setblock 149 175 340 minecraft:magenta_terracotta
fill 149 175 341 149 175 344 minecraft:purple_terracotta
setblock 149 175 345 minecraft:magenta_terracotta
fill 149 175 346 149 175 349 minecraft:purple_terracotta
setblock 149 175 350 minecraft:magenta_terracotta
setblock 149 175 351 minecraft:purple_terracotta
fill 149 175 354 152 175 354 minecraft:purple_terracotta
setblock 149 175 355 minecraft:magenta_terracotta
fill 149 175 356 149 175 359 minecraft:purple_terracotta
setblock 149 175 360 minecraft:magenta_terracotta
fill 149 175 361 149 175 363 minecraft:purple_terracotta
fill 150 175 325 153 175 325 minecraft:purple_terracotta
setblock 150 175 326 minecraft:magenta_terracotta
fill 150 175 330 153 175 330 minecraft:purple_terracotta
setblock 150 175 331 minecraft:magenta_terracotta
fill 150 175 332 150 175 335 minecraft:purple_terracotta
setblock 150 175 336 minecraft:magenta_terracotta
fill 150 175 337 150 175 340 minecraft:purple_terracotta
setblock 150 175 341 minecraft:magenta_terracotta
fill 150 175 342 150 175 345 minecraft:purple_terracotta
setblock 150 175 346 minecraft:magenta_terracotta
fill 150 175 347 150 175 350 minecraft:purple_terracotta
setblock 150 175 351 minecraft:magenta_terracotta
fill 150 175 355 153 175 355 minecraft:purple_terracotta
setblock 150 175 356 minecraft:magenta_terracotta
fill 150 175 357 150 175 360 minecraft:purple_terracotta
setblock 150 175 361 minecraft:magenta_terracotta
fill 150 175 362 150 175 363 minecraft:purple_terracotta
fill 151 175 326 154 175 326 minecraft:purple_terracotta
setblock 151 175 327 minecraft:magenta_terracotta
fill 151 175 331 154 175 331 minecraft:purple_terracotta
setblock 151 175 332 minecraft:magenta_terracotta
fill 151 175 333 151 175 336 minecraft:purple_terracotta
setblock 151 175 337 minecraft:magenta_terracotta
fill 151 175 338 151 175 341 minecraft:purple_terracotta
setblock 151 175 342 minecraft:magenta_terracotta
fill 151 175 343 151 175 346 minecraft:purple_terracotta
setblock 151 175 347 minecraft:magenta_terracotta
fill 151 175 348 151 175 351 minecraft:purple_terracotta
setblock 151 175 352 minecraft:magenta_terracotta
fill 151 175 356 154 175 356 minecraft:purple_terracotta
setblock 151 175 357 minecraft:magenta_terracotta
fill 151 175 358 151 175 361 minecraft:purple_terracotta
setblock 151 175 362 minecraft:magenta_terracotta
setblock 151 175 363 minecraft:purple_terracotta
setblock 152 175 323 minecraft:magenta_terracotta
fill 152 175 327 155 175 327 minecraft:purple_terracotta
setblock 152 175 328 minecraft:magenta_terracotta
fill 152 175 332 155 175 332 minecraft:purple_terracotta
fill 152 175 335 152 175 337 minecraft:purple_terracotta
setblock 152 175 338 minecraft:magenta_terracotta
setblock 152 175 347 minecraft:purple_terracotta
setblock 152 175 348 minecraft:magenta_terracotta
fill 152 175 349 152 175 352 minecraft:purple_terracotta
setblock 152 175 353 minecraft:magenta_terracotta
fill 152 175 357 154 175 357 minecraft:purple_terracotta
setblock 152 175 358 minecraft:magenta_terracotta
fill 152 175 359 152 175 362 minecraft:purple_terracotta
setblock 152 175 363 minecraft:magenta_terracotta
fill 153 175 323 156 175 323 minecraft:purple_terracotta
setblock 153 175 324 minecraft:magenta_terracotta
fill 153 175 328 156 175 328 minecraft:purple_terracotta
setblock 153 175 329 minecraft:magenta_terracotta
fill 153 175 335 153 175 336 minecraft:purple_terracotta
fill 153 175 337 153 176 337 minecraft:white_concrete
fill 153 175 348 153 176 348 minecraft:white_concrete
setblock 153 175 349 minecraft:magenta_terracotta
fill 153 175 350 153 175 353 minecraft:purple_terracotta
setblock 153 175 354 minecraft:magenta_terracotta
fill 153 175 358 154 175 358 minecraft:purple_terracotta
setblock 153 175 359 minecraft:magenta_terracotta
fill 153 175 360 153 175 363 minecraft:purple_terracotta
fill 154 175 324 157 175 324 minecraft:purple_terracotta
setblock 154 175 325 minecraft:magenta_terracotta
fill 154 175 329 157 175 329 minecraft:purple_terracotta
setblock 154 175 330 minecraft:magenta_terracotta
setblock 154 175 335 minecraft:magenta_terracotta
setblock 154 175 350 minecraft:magenta_terracotta
fill 154 175 351 154 175 354 minecraft:purple_terracotta
setblock 154 175 355 minecraft:magenta_terracotta
fill 154 175 359 155 175 359 minecraft:purple_terracotta
setblock 154 175 360 minecraft:magenta_terracotta
fill 154 175 361 154 175 363 minecraft:purple_terracotta
fill 155 175 325 158 175 325 minecraft:purple_terracotta
setblock 155 175 326 minecraft:magenta_terracotta
fill 155 175 330 158 175 330 minecraft:purple_terracotta
setblock 155 175 331 minecraft:magenta_terracotta
fill 155 175 333 155 175 335 minecraft:purple_terracotta
setblock 155 175 350 minecraft:purple_terracotta
setblock 155 175 351 minecraft:magenta_terracotta
fill 155 175 352 155 175 355 minecraft:purple_terracotta
setblock 155 175 356 minecraft:magenta_terracotta
fill 155 175 360 158 175 360 minecraft:purple_terracotta
setblock 155 175 361 minecraft:magenta_terracotta
fill 155 175 362 155 175 363 minecraft:purple_terracotta
fill 156 175 326 159 175 326 minecraft:purple_terracotta
setblock 156 175 327 minecraft:magenta_terracotta
fill 156 175 331 159 175 331 minecraft:purple_terracotta
setblock 156 175 332 minecraft:magenta_terracotta
fill 156 175 333 156 175 334 minecraft:purple_terracotta
fill 156 175 351 157 175 351 minecraft:purple_terracotta
setblock 156 175 352 minecraft:magenta_terracotta
fill 156 175 353 156 175 356 minecraft:purple_terracotta
fill 156 175 361 159 175 361 minecraft:purple_terracotta
setblock 156 175 362 minecraft:magenta_terracotta
setblock 156 175 363 minecraft:purple_terracotta
setblock 157 175 323 minecraft:magenta_terracotta
fill 157 175 327 160 175 327 minecraft:purple_terracotta
setblock 157 175 328 minecraft:magenta_terracotta
fill 157 175 332 160 175 332 minecraft:purple_terracotta
setblock 157 175 333 minecraft:magenta_terracotta
setblock 157 175 334 minecraft:purple_terracotta
fill 157 175 352 160 175 352 minecraft:purple_terracotta
setblock 157 175 353 minecraft:magenta_terracotta
fill 157 175 354 157 175 356 minecraft:purple_terracotta
fill 157 175 362 160 175 362 minecraft:purple_terracotta
setblock 157 175 363 minecraft:magenta_terracotta
fill 158 175 323 161 175 323 minecraft:purple_terracotta
setblock 158 175 324 minecraft:magenta_terracotta
fill 158 175 328 161 175 328 minecraft:purple_terracotta
setblock 158 175 329 minecraft:magenta_terracotta
fill 158 175 333 161 175 333 minecraft:purple_terracotta
fill 158 175 353 161 175 353 minecraft:purple_terracotta
setblock 158 175 354 minecraft:magenta_terracotta
fill 158 175 355 158 175 358 minecraft:purple_terracotta
setblock 158 175 359 minecraft:magenta_terracotta
fill 158 175 363 161 175 363 minecraft:purple_terracotta
fill 159 175 324 162 175 324 minecraft:purple_terracotta
setblock 159 175 325 minecraft:magenta_terracotta
fill 159 175 329 162 175 329 minecraft:purple_terracotta
setblock 159 175 330 minecraft:magenta_terracotta
fill 159 175 354 162 175 354 minecraft:purple_terracotta
setblock 159 175 355 minecraft:magenta_terracotta
fill 159 175 356 159 175 359 minecraft:purple_terracotta
setblock 159 175 360 minecraft:magenta_terracotta
fill 160 175 325 163 175 325 minecraft:purple_terracotta
setblock 160 175 326 minecraft:magenta_terracotta
fill 160 175 330 163 175 330 minecraft:purple_terracotta
setblock 160 175 331 minecraft:magenta_terracotta
fill 160 175 355 163 175 355 minecraft:purple_terracotta
setblock 160 175 356 minecraft:magenta_terracotta
fill 160 175 357 160 175 360 minecraft:purple_terracotta
setblock 160 175 361 minecraft:magenta_terracotta
fill 161 175 326 164 175 326 minecraft:purple_terracotta
setblock 161 175 327 minecraft:magenta_terracotta
fill 161 175 331 164 175 331 minecraft:purple_terracotta
setblock 161 175 332 minecraft:magenta_terracotta
setblock 161 175 352 minecraft:magenta_terracotta
fill 161 175 356 164 175 356 minecraft:purple_terracotta
setblock 161 175 357 minecraft:magenta_terracotta
fill 161 175 358 161 175 361 minecraft:purple_terracotta
setblock 161 175 362 minecraft:magenta_terracotta
setblock 162 175 323 minecraft:magenta_terracotta
fill 162 175 327 165 175 327 minecraft:purple_terracotta
setblock 162 175 328 minecraft:magenta_terracotta
fill 162 175 332 165 175 332 minecraft:purple_terracotta
setblock 162 175 333 minecraft:magenta_terracotta
fill 162 175 352 165 175 352 minecraft:purple_terracotta
setblock 162 175 353 minecraft:magenta_terracotta
fill 162 175 357 165 175 357 minecraft:purple_terracotta
setblock 162 175 358 minecraft:magenta_terracotta
fill 162 175 359 162 175 362 minecraft:purple_terracotta
setblock 162 175 363 minecraft:magenta_terracotta
fill 163 175 323 166 175 323 minecraft:purple_terracotta
setblock 163 175 324 minecraft:magenta_terracotta
fill 163 175 328 166 175 328 minecraft:purple_terracotta
setblock 163 175 329 minecraft:magenta_terracotta
fill 163 175 333 166 175 333 minecraft:purple_terracotta
setblock 163 175 334 minecraft:magenta_terracotta
fill 163 175 351 164 175 351 minecraft:purple_terracotta
fill 163 175 353 166 175 353 minecraft:purple_terracotta
setblock 163 175 354 minecraft:magenta_terracotta
fill 163 175 358 166 175 358 minecraft:purple_terracotta
setblock 163 175 359 minecraft:magenta_terracotta
fill 163 175 360 163 175 363 minecraft:purple_terracotta
fill 164 175 324 167 175 324 minecraft:purple_terracotta
setblock 164 175 325 minecraft:magenta_terracotta
fill 164 175 329 166 175 329 minecraft:purple_terracotta
setblock 164 175 330 minecraft:magenta_terracotta
fill 164 175 334 167 175 334 minecraft:purple_terracotta
fill 164 175 354 167 175 354 minecraft:purple_terracotta
setblock 164 175 355 minecraft:magenta_terracotta
fill 164 175 359 167 175 359 minecraft:purple_terracotta
setblock 164 175 360 minecraft:magenta_terracotta
fill 164 175 361 164 175 363 minecraft:purple_terracotta
fill 165 175 325 168 175 325 minecraft:purple_terracotta
setblock 165 175 326 minecraft:magenta_terracotta
fill 165 175 330 168 175 330 minecraft:purple_terracotta
setblock 165 175 331 minecraft:magenta_terracotta
fill 165 175 335 168 175 335 minecraft:purple_terracotta
fill 165 175 350 168 175 350 minecraft:purple_terracotta
setblock 165 175 351 minecraft:magenta_terracotta
fill 165 175 355 168 175 355 minecraft:purple_terracotta
setblock 165 175 356 minecraft:magenta_terracotta
fill 165 175 360 168 175 360 minecraft:purple_terracotta
setblock 165 175 361 minecraft:magenta_terracotta
fill 165 175 362 165 175 363 minecraft:purple_terracotta
fill 166 175 326 169 175 326 minecraft:purple_terracotta
setblock 166 175 327 minecraft:magenta_terracotta
fill 166 175 331 169 175 331 minecraft:purple_terracotta
setblock 166 175 332 minecraft:magenta_terracotta
fill 166 175 351 169 175 351 minecraft:purple_terracotta
setblock 166 175 352 minecraft:magenta_terracotta
fill 166 175 356 169 175 356 minecraft:purple_terracotta
setblock 166 175 357 minecraft:magenta_terracotta
fill 166 175 361 169 175 361 minecraft:purple_terracotta
setblock 166 175 362 minecraft:magenta_terracotta
setblock 166 175 363 minecraft:purple_terracotta
setblock 167 175 323 minecraft:magenta_terracotta
setblock 167 175 327 minecraft:purple_terracotta
fill 167 175 332 170 175 332 minecraft:purple_terracotta
setblock 167 175 333 minecraft:magenta_terracotta
fill 167 175 336 169 175 336 minecraft:purple_terracotta
fill 167 175 337 167 176 337 minecraft:white_concrete
fill 167 175 348 167 176 348 minecraft:white_concrete
setblock 167 175 349 minecraft:purple_terracotta
fill 167 175 352 169 175 352 minecraft:purple_terracotta
setblock 167 175 353 minecraft:magenta_terracotta
fill 167 175 357 170 175 357 minecraft:purple_terracotta
setblock 167 175 358 minecraft:magenta_terracotta
fill 167 175 362 170 175 362 minecraft:purple_terracotta
setblock 167 175 363 minecraft:magenta_terracotta
fill 168 175 323 171 175 323 minecraft:purple_terracotta
setblock 168 175 324 minecraft:magenta_terracotta
fill 168 175 333 171 175 333 minecraft:purple_terracotta
setblock 168 175 334 minecraft:magenta_terracotta
fill 168 175 337 170 175 338 minecraft:purple_terracotta
fill 168 175 347 170 175 348 minecraft:purple_terracotta
setblock 168 175 349 minecraft:magenta_terracotta
fill 168 175 353 169 175 353 minecraft:purple_terracotta
setblock 168 175 354 minecraft:magenta_terracotta
fill 168 175 358 171 175 358 minecraft:purple_terracotta
setblock 168 175 359 minecraft:magenta_terracotta
fill 168 175 363 171 175 363 minecraft:purple_terracotta
fill 169 175 324 172 175 324 minecraft:purple_terracotta
setblock 169 175 325 minecraft:magenta_terracotta
fill 169 175 327 170 175 327 minecraft:purple_terracotta
setblock 169 175 330 minecraft:magenta_terracotta
fill 169 175 334 172 175 334 minecraft:purple_terracotta
setblock 169 175 335 minecraft:magenta_terracotta
fill 169 175 339 172 175 339 minecraft:purple_terracotta
setblock 169 175 340 minecraft:magenta_terracotta
fill 169 175 341 169 175 344 minecraft:purple_terracotta
setblock 169 175 345 minecraft:magenta_terracotta
setblock 169 175 346 minecraft:purple_terracotta
fill 169 175 349 172 175 349 minecraft:purple_terracotta
setblock 169 175 350 minecraft:magenta_terracotta
fill 169 175 354 170 175 354 minecraft:purple_terracotta
setblock 169 175 355 minecraft:magenta_terracotta
fill 169 175 359 172 175 359 minecraft:purple_terracotta
setblock 169 175 360 minecraft:magenta_terracotta
fill 170 175 325 173 175 325 minecraft:purple_terracotta
setblock 170 175 326 minecraft:magenta_terracotta
fill 170 175 328 171 175 330 minecraft:purple_terracotta
setblock 170 175 331 minecraft:magenta_terracotta
fill 170 175 335 173 175 335 minecraft:purple_terracotta
setblock 170 175 336 minecraft:magenta_terracotta
fill 170 175 340 173 175 340 minecraft:purple_terracotta
setblock 170 175 341 minecraft:magenta_terracotta
fill 170 175 342 170 175 345 minecraft:purple_terracotta
setblock 170 175 346 minecraft:magenta_terracotta
fill 170 175 350 173 175 350 minecraft:purple_terracotta
setblock 170 175 351 minecraft:magenta_terracotta
fill 170 175 355 173 175 355 minecraft:purple_terracotta
setblock 170 175 356 minecraft:magenta_terracotta
fill 170 175 360 173 175 360 minecraft:purple_terracotta
setblock 170 175 361 minecraft:magenta_terracotta
fill 171 175 326 174 175 326 minecraft:purple_terracotta
setblock 171 175 327 minecraft:magenta_terracotta
fill 171 175 331 174 175 331 minecraft:purple_terracotta
setblock 171 175 332 minecraft:magenta_terracotta
fill 171 175 336 174 175 336 minecraft:purple_terracotta
setblock 171 175 337 minecraft:magenta_terracotta
setblock 171 175 338 minecraft:purple_terracotta
fill 171 175 341 174 175 341 minecraft:purple_terracotta
setblock 171 175 342 minecraft:magenta_terracotta
fill 171 175 343 171 175 346 minecraft:purple_terracotta
setblock 171 175 347 minecraft:magenta_terracotta
setblock 171 175 348 minecraft:purple_terracotta
fill 171 175 351 174 175 351 minecraft:purple_terracotta
fill 171 175 356 174 175 356 minecraft:purple_terracotta
setblock 171 175 357 minecraft:magenta_terracotta
fill 171 175 361 174 175 361 minecraft:purple_terracotta
setblock 171 175 362 minecraft:magenta_terracotta
setblock 172 175 323 minecraft:magenta_terracotta
fill 172 175 327 175 175 327 minecraft:purple_terracotta
setblock 172 175 328 minecraft:magenta_terracotta
fill 172 175 329 172 175 330 minecraft:purple_terracotta
fill 172 175 332 175 175 332 minecraft:purple_terracotta
setblock 172 175 333 minecraft:magenta_terracotta
fill 172 175 337 175 175 337 minecraft:purple_terracotta
setblock 172 175 338 minecraft:magenta_terracotta
fill 172 175 342 175 175 342 minecraft:purple_terracotta
setblock 172 175 343 minecraft:magenta_terracotta
fill 172 175 344 172 175 347 minecraft:purple_terracotta
setblock 172 175 348 minecraft:magenta_terracotta
setblock 172 175 354 minecraft:purple_terracotta
fill 172 175 357 175 175 357 minecraft:purple_terracotta
setblock 172 175 358 minecraft:magenta_terracotta
fill 172 175 362 175 175 362 minecraft:purple_terracotta
setblock 172 175 363 minecraft:magenta_terracotta
fill 173 175 323 176 175 323 minecraft:purple_terracotta
setblock 173 175 324 minecraft:magenta_terracotta
fill 173 175 328 176 175 328 minecraft:purple_terracotta
setblock 173 175 329 minecraft:magenta_terracotta
setblock 173 175 330 minecraft:purple_terracotta
fill 173 175 333 176 175 333 minecraft:purple_terracotta
setblock 173 175 334 minecraft:magenta_terracotta
fill 173 175 338 175 175 338 minecraft:purple_terracotta
setblock 173 175 339 minecraft:magenta_terracotta
fill 173 175 343 176 175 343 minecraft:purple_terracotta
setblock 173 175 344 minecraft:magenta_terracotta
fill 173 175 345 173 175 348 minecraft:purple_terracotta
setblock 173 175 349 minecraft:magenta_terracotta
fill 173 175 352 175 175 353 minecraft:purple_terracotta
setblock 173 175 354 minecraft:magenta_terracotta
fill 173 175 358 176 175 358 minecraft:purple_terracotta
setblock 173 175 359 minecraft:magenta_terracotta
fill 173 175 363 176 175 363 minecraft:purple_terracotta
fill 174 175 324 177 175 324 minecraft:purple_terracotta
setblock 174 175 325 minecraft:magenta_terracotta
fill 174 175 329 177 175 329 minecraft:purple_terracotta
setblock 174 175 330 minecraft:magenta_terracotta
fill 174 175 334 177 175 334 minecraft:purple_terracotta
setblock 174 175 335 minecraft:magenta_terracotta
fill 174 175 339 176 175 339 minecraft:purple_terracotta
setblock 174 175 340 minecraft:magenta_terracotta
fill 174 175 344 177 175 344 minecraft:purple_terracotta
setblock 174 175 345 minecraft:magenta_terracotta
fill 174 175 346 174 175 349 minecraft:purple_terracotta
setblock 174 175 350 minecraft:magenta_terracotta
fill 174 175 354 177 175 354 minecraft:purple_terracotta
setblock 174 175 355 minecraft:magenta_terracotta
fill 174 175 359 177 175 359 minecraft:purple_terracotta
setblock 174 175 360 minecraft:magenta_terracotta
fill 175 175 325 178 175 325 minecraft:purple_terracotta
setblock 175 175 326 minecraft:magenta_terracotta
fill 175 175 330 178 175 330 minecraft:purple_terracotta
setblock 175 175 331 minecraft:magenta_terracotta
fill 175 175 335 178 175 335 minecraft:purple_terracotta
setblock 175 175 336 minecraft:magenta_terracotta
fill 175 175 340 178 175 340 minecraft:purple_terracotta
setblock 175 175 341 minecraft:magenta_terracotta
fill 175 175 345 178 175 345 minecraft:purple_terracotta
setblock 175 175 346 minecraft:magenta_terracotta
fill 175 175 347 175 175 350 minecraft:purple_terracotta
setblock 175 175 351 minecraft:magenta_terracotta
fill 175 175 355 178 175 355 minecraft:purple_terracotta
setblock 175 175 356 minecraft:magenta_terracotta
fill 175 175 360 178 175 360 minecraft:purple_terracotta
setblock 175 175 361 minecraft:magenta_terracotta
fill 176 175 326 179 175 326 minecraft:purple_terracotta
setblock 176 175 327 minecraft:magenta_terracotta
fill 176 175 331 179 175 331 minecraft:purple_terracotta
setblock 176 175 332 minecraft:magenta_terracotta
fill 176 175 336 179 175 336 minecraft:purple_terracotta
setblock 176 175 337 minecraft:magenta_terracotta
fill 176 175 341 179 175 341 minecraft:purple_terracotta
setblock 176 175 342 minecraft:magenta_terracotta
fill 176 175 346 179 175 346 minecraft:purple_terracotta
setblock 176 175 347 minecraft:magenta_terracotta
fill 176 175 348 176 175 351 minecraft:purple_terracotta
setblock 176 175 352 minecraft:magenta_terracotta
setblock 176 175 353 minecraft:purple_terracotta
fill 176 175 356 179 175 356 minecraft:purple_terracotta
setblock 176 175 357 minecraft:magenta_terracotta
fill 176 175 361 179 175 361 minecraft:purple_terracotta
setblock 176 175 362 minecraft:magenta_terracotta
setblock 177 175 323 minecraft:magenta_terracotta
fill 177 175 327 180 175 327 minecraft:purple_terracotta
setblock 177 175 328 minecraft:magenta_terracotta
fill 177 175 332 180 175 332 minecraft:purple_terracotta
setblock 177 175 333 minecraft:magenta_terracotta
fill 177 175 342 180 175 342 minecraft:purple_terracotta
setblock 177 175 343 minecraft:magenta_terracotta
fill 177 175 347 180 175 347 minecraft:purple_terracotta
setblock 177 175 348 minecraft:magenta_terracotta
fill 177 175 349 177 175 352 minecraft:purple_terracotta
setblock 177 175 353 minecraft:magenta_terracotta
fill 177 175 357 180 175 357 minecraft:purple_terracotta
setblock 177 175 358 minecraft:magenta_terracotta
fill 177 175 362 180 175 362 minecraft:purple_terracotta
setblock 177 175 363 minecraft:magenta_terracotta
fill 178 175 323 181 175 323 minecraft:purple_terracotta
setblock 178 175 324 minecraft:magenta_terracotta
fill 178 175 328 181 175 328 minecraft:purple_terracotta
setblock 178 175 329 minecraft:magenta_terracotta
fill 178 175 333 181 175 333 minecraft:purple_terracotta
setblock 178 175 334 minecraft:magenta_terracotta
fill 178 175 343 181 175 343 minecraft:purple_terracotta
setblock 178 175 344 minecraft:magenta_terracotta
fill 178 175 348 181 175 348 minecraft:purple_terracotta
setblock 178 175 349 minecraft:magenta_terracotta
fill 178 175 350 178 175 353 minecraft:purple_terracotta
setblock 178 175 354 minecraft:magenta_terracotta
fill 178 175 358 181 175 358 minecraft:purple_terracotta
setblock 178 175 359 minecraft:magenta_terracotta
fill 178 175 363 181 175 363 minecraft:purple_terracotta
fill 179 175 324 182 175 324 minecraft:purple_terracotta
setblock 179 175 325 minecraft:magenta_terracotta
fill 179 175 329 182 175 329 minecraft:purple_terracotta
setblock 179 175 330 minecraft:magenta_terracotta
fill 179 175 334 182 175 334 minecraft:purple_terracotta
setblock 179 175 335 minecraft:magenta_terracotta
fill 179 175 337 180 175 339 minecraft:purple_terracotta
setblock 179 175 340 minecraft:magenta_terracotta
fill 179 175 344 182 175 344 minecraft:purple_terracotta
setblock 179 175 345 minecraft:magenta_terracotta
fill 179 175 349 182 175 349 minecraft:purple_terracotta
setblock 179 175 350 minecraft:magenta_terracotta
fill 179 175 351 179 175 354 minecraft:purple_terracotta
setblock 179 175 355 minecraft:magenta_terracotta
fill 179 175 359 182 175 359 minecraft:purple_terracotta
setblock 179 175 360 minecraft:magenta_terracotta
fill 180 175 325 182 175 325 minecraft:purple_terracotta
setblock 180 175 326 minecraft:magenta_terracotta
fill 180 175 330 182 175 330 minecraft:purple_terracotta
setblock 180 175 331 minecraft:magenta_terracotta
fill 180 175 335 182 175 335 minecraft:purple_terracotta
setblock 180 175 336 minecraft:magenta_terracotta
fill 180 175 340 182 175 340 minecraft:purple_terracotta
setblock 180 175 341 minecraft:magenta_terracotta
fill 180 175 345 182 175 345 minecraft:purple_terracotta
setblock 180 175 346 minecraft:magenta_terracotta
fill 180 175 350 182 175 350 minecraft:purple_terracotta
setblock 180 175 351 minecraft:magenta_terracotta
fill 180 175 352 180 175 355 minecraft:purple_terracotta
setblock 180 175 356 minecraft:magenta_terracotta
fill 180 175 360 182 175 360 minecraft:purple_terracotta
setblock 180 175 361 minecraft:magenta_terracotta
fill 181 175 326 182 175 326 minecraft:purple_terracotta
setblock 181 175 327 minecraft:magenta_terracotta
fill 181 175 331 182 175 331 minecraft:purple_terracotta
setblock 181 175 332 minecraft:magenta_terracotta
fill 181 175 336 182 175 336 minecraft:purple_terracotta
setblock 181 175 337 minecraft:magenta_terracotta
fill 181 175 338 181 175 339 minecraft:purple_terracotta
fill 181 175 341 182 175 341 minecraft:purple_terracotta
setblock 181 175 342 minecraft:magenta_terracotta
fill 181 175 346 182 175 346 minecraft:purple_terracotta
setblock 181 175 347 minecraft:magenta_terracotta
fill 181 175 351 182 175 351 minecraft:purple_terracotta
setblock 181 175 352 minecraft:magenta_terracotta
fill 181 175 353 181 175 356 minecraft:purple_terracotta
setblock 181 175 357 minecraft:magenta_terracotta
fill 181 175 361 182 175 361 minecraft:purple_terracotta
setblock 181 175 362 minecraft:magenta_terracotta
setblock 182 175 323 minecraft:magenta_terracotta
setblock 182 175 327 minecraft:purple_terracotta
setblock 182 175 328 minecraft:magenta_terracotta
setblock 182 175 332 minecraft:purple_terracotta
setblock 182 175 333 minecraft:magenta_terracotta
setblock 182 175 337 minecraft:purple_terracotta
setblock 182 175 338 minecraft:magenta_terracotta
setblock 182 175 339 minecraft:purple_terracotta
setblock 182 175 342 minecraft:purple_terracotta
setblock 182 175 343 minecraft:magenta_terracotta
setblock 182 175 347 minecraft:purple_terracotta
setblock 182 175 348 minecraft:magenta_terracotta
setblock 182 175 352 minecraft:purple_terracotta
setblock 182 175 353 minecraft:magenta_terracotta
fill 182 175 354 182 175 357 minecraft:purple_terracotta
setblock 182 175 358 minecraft:magenta_terracotta
setblock 182 175 362 minecraft:purple_terracotta
setblock 182 175 363 minecraft:magenta_terracotta
fill 153 176 332 153 208 332 minecraft:magenta_terracotta
fill 154 176 322 155 220 322 minecraft:blue_terracotta
setblock 156 176 322 minecraft:cyan_concrete
fill 157 176 322 158 217 322 minecraft:blue_terracotta
fill 155 177 359 155 234 359 minecraft:magenta_terracotta
fill 156 177 322 156 216 322 minecraft:blue_terracotta
fill 170 178 354 170 216 354 minecraft:magenta_terracotta
setblock 183 178 334 minecraft:light_blue_wool
setblock 183 178 335 minecraft:cyan_concrete
setblock 144 179 325 minecraft:light[level=12]
setblock 144 179 332 minecraft:light[level=12]
setblock 144 179 339 minecraft:light[level=12]
setblock 144 179 346 minecraft:light[level=12]
setblock 144 179 353 minecraft:light[level=12]
setblock 144 179 360 minecraft:light[level=12]
setblock 151 179 325 minecraft:light[level=12]
setblock 151 179 332 minecraft:light[level=12]
setblock 151 179 339 minecraft:light[level=12]
setblock 151 179 346 minecraft:light[level=12]
setblock 151 179 353 minecraft:light[level=12]
setblock 151 179 360 minecraft:light[level=12]
fill 153 179 340 153 180 340 minecraft:yellow_concrete
setblock 153 179 341 minecraft:white_concrete
setblock 158 179 325 minecraft:light[level=12]
setblock 158 179 332 minecraft:light[level=12]
setblock 158 179 353 minecraft:light[level=12]
setblock 158 179 360 minecraft:light[level=12]
setblock 165 179 325 minecraft:light[level=12]
setblock 165 179 332 minecraft:light[level=12]
setblock 165 179 353 minecraft:light[level=12]
setblock 165 179 360 minecraft:light[level=12]
fill 171 179 352 171 186 352 minecraft:magenta_terracotta
setblock 172 179 325 minecraft:light[level=12]
setblock 172 179 332 minecraft:light[level=12]
setblock 172 179 339 minecraft:light[level=12]
setblock 172 179 346 minecraft:light[level=12]
setblock 172 179 360 minecraft:light[level=12]
setblock 179 179 325 minecraft:light[level=12]
setblock 179 179 332 minecraft:light[level=12]
setblock 179 179 339 minecraft:light[level=12]
setblock 179 179 346 minecraft:light[level=12]
setblock 179 179 353 minecraft:light[level=12]
setblock 179 179 360 minecraft:light[level=12]
fill 183 179 334 183 220 335 minecraft:blue_terracotta
fill 183 179 343 183 220 343 minecraft:blue_terracotta
setblock 183 179 344 minecraft:cyan_concrete
fill 153 180 341 153 180 344 minecraft:yellow_concrete
setblock 153 180 345 minecraft:white_concrete
fill 154 180 339 154 181 339 minecraft:yellow_concrete
setblock 154 180 340 minecraft:white_concrete
fill 183 180 344 183 194 344 minecraft:blue_terracotta
fill 141 181 341 141 220 341 minecraft:blue_terracotta
setblock 141 181 342 minecraft:light_blue_wool
setblock 144 181 325 minecraft:light[level=13]
setblock 144 181 333 minecraft:light[level=13]
setblock 144 181 341 minecraft:light[level=13]
setblock 144 181 349 minecraft:light[level=13]
setblock 144 181 357 minecraft:light[level=13]
setblock 152 181 325 minecraft:light[level=13]
setblock 152 181 341 minecraft:light[level=13]
setblock 152 181 349 minecraft:light[level=13]
setblock 152 181 357 minecraft:light[level=13]
fill 153 181 342 153 181 343 minecraft:yellow_concrete
fill 154 181 340 154 181 341 minecraft:yellow_concrete
fill 154 181 342 155 181 343 minecraft:white_concrete
fill 154 181 344 154 181 345 minecraft:yellow_concrete
setblock 154 181 346 minecraft:white_concrete
setblock 155 181 338 minecraft:yellow_concrete
setblock 155 181 341 minecraft:white_concrete
setblock 155 181 344 minecraft:white_concrete
fill 156 181 337 157 181 337 minecraft:yellow_concrete
setblock 160 181 322 minecraft:light_blue_wool
setblock 160 181 325 minecraft:light[level=13]
setblock 160 181 333 minecraft:light[level=13]
setblock 160 181 357 minecraft:light[level=13]
fill 161 181 322 163 207 322 minecraft:blue_terracotta
setblock 168 181 325 minecraft:light[level=13]
fill 168 181 329 168 198 329 minecraft:magenta_terracotta
setblock 168 181 333 minecraft:light[level=13]
setblock 168 181 341 minecraft:light[level=13]
setblock 168 181 349 minecraft:light[level=13]
setblock 168 181 357 minecraft:light[level=13]
setblock 176 181 325 minecraft:light[level=13]
setblock 176 181 333 minecraft:light[level=13]
setblock 176 181 341 minecraft:light[level=13]
setblock 176 181 349 minecraft:light[level=13]
setblock 176 181 357 minecraft:light[level=13]
fill 141 182 342 141 220 342 minecraft:blue_terracotta
fill 148 182 347 148 211 347 minecraft:magenta_terracotta
fill 152 182 341 153 182 344 minecraft:magenta_terracotta
fill 153 182 338 154 182 340 minecraft:magenta_terracotta
fill 153 182 345 154 182 347 minecraft:magenta_terracotta
fill 154 182 332 154 220 332 minecraft:magenta_terracotta
fill 154 182 337 157 182 337 minecraft:magenta_terracotta
fill 154 182 341 154 182 344 minecraft:yellow_concrete
fill 154 182 348 157 182 348 minecraft:magenta_terracotta
fill 155 182 336 165 182 336 minecraft:magenta_terracotta
fill 155 182 338 155 183 338 minecraft:magenta_terracotta
setblock 155 182 339 minecraft:yellow_concrete
fill 155 182 340 155 182 344 minecraft:orange_concrete
fill 155 182 345 155 182 346 minecraft:yellow_concrete
fill 155 182 347 155 183 347 minecraft:magenta_terracotta
fill 155 182 349 165 182 349 minecraft:magenta_terracotta
fill 156 182 338 157 182 338 minecraft:yellow_concrete
setblock 156 182 339 minecraft:orange_concrete
fill 156 182 346 156 182 347 minecraft:yellow_concrete
fill 157 182 335 163 182 335 minecraft:magenta_terracotta
setblock 157 182 347 minecraft:yellow_concrete
fill 157 182 350 163 182 350 minecraft:magenta_terracotta
fill 158 182 337 160 182 337 minecraft:yellow_concrete
fill 160 182 322 160 215 322 minecraft:blue_terracotta
fill 161 182 337 162 182 337 minecraft:white_concrete
fill 163 182 337 166 182 337 minecraft:magenta_terracotta
fill 163 182 348 166 182 348 minecraft:magenta_terracotta
fill 165 182 338 167 182 338 minecraft:magenta_terracotta
fill 165 182 347 167 182 347 minecraft:magenta_terracotta
fill 166 182 339 167 182 340 minecraft:magenta_terracotta
fill 166 182 345 167 182 346 minecraft:magenta_terracotta
fill 167 182 341 168 182 344 minecraft:magenta_terracotta
fill 169 182 327 169 234 327 minecraft:magenta_terracotta
fill 142 183 323 145 183 363 minecraft:purple_terracotta
fill 146 183 323 146 183 347 minecraft:purple_terracotta
fill 146 183 349 146 183 363 minecraft:purple_terracotta
fill 147 183 323 151 183 346 minecraft:purple_terracotta
fill 147 183 350 154 183 363 minecraft:purple_terracotta
fill 149 183 347 154 183 349 minecraft:purple_terracotta
fill 152 183 323 152 183 332 minecraft:purple_terracotta
fill 152 183 334 152 183 346 minecraft:purple_terracotta
fill 153 183 323 166 183 331 minecraft:purple_terracotta
fill 153 183 335 153 183 339 minecraft:purple_terracotta
fill 153 183 340 154 183 345 minecraft:magenta_terracotta
setblock 153 183 346 minecraft:purple_terracotta
fill 154 183 335 154 183 338 minecraft:purple_terracotta
fill 154 183 339 155 183 339 minecraft:magenta_terracotta
fill 154 183 346 156 183 346 minecraft:magenta_terracotta
fill 155 183 332 156 183 336 minecraft:purple_terracotta
fill 155 183 337 165 183 337 minecraft:magenta_terracotta
fill 155 183 340 155 183 344 minecraft:black_concrete
fill 155 183 345 155 184 345 minecraft:magenta_terracotta
fill 155 183 348 165 183 348 minecraft:magenta_terracotta
fill 155 183 349 156 183 356 minecraft:purple_terracotta
fill 155 183 360 182 183 363 minecraft:purple_terracotta
fill 156 183 338 157 184 338 minecraft:magenta_terracotta
fill 156 183 339 156 183 340 minecraft:black_concrete
fill 156 183 344 156 183 345 minecraft:black_concrete
fill 156 183 347 157 184 347 minecraft:magenta_terracotta
fill 157 183 332 182 183 335 minecraft:purple_terracotta
fill 157 183 336 163 183 336 minecraft:magenta_terracotta
fill 157 183 339 160 183 339 minecraft:black_concrete
fill 157 183 345 160 183 345 minecraft:black_concrete
fill 157 183 346 161 183 346 minecraft:yellow_concrete
fill 157 183 349 163 183 349 minecraft:magenta_terracotta
fill 157 183 350 169 183 357 minecraft:purple_terracotta
fill 157 183 359 182 183 359 minecraft:purple_terracotta
fill 158 183 338 161 183 338 minecraft:yellow_concrete
fill 158 183 347 160 183 347 minecraft:yellow_concrete
fill 158 183 358 182 183 358 minecraft:purple_terracotta
fill 160 183 340 161 183 340 minecraft:black_concrete
fill 160 183 344 161 183 344 minecraft:black_concrete
fill 161 183 339 162 183 339 minecraft:yellow_concrete
fill 161 183 341 161 183 343 minecraft:black_concrete
setblock 161 183 345 minecraft:white_concrete
fill 161 183 347 162 183 347 minecraft:white_concrete
setblock 162 183 338 minecraft:white_concrete
fill 162 183 340 163 183 340 minecraft:yellow_concrete
fill 162 183 341 162 183 344 minecraft:white_concrete
setblock 162 183 345 minecraft:yellow_concrete
fill 162 183 346 163 183 346 minecraft:white_concrete
fill 163 183 338 165 183 338 minecraft:magenta_terracotta
setblock 163 183 339 minecraft:white_concrete
fill 163 183 341 163 183 344 minecraft:yellow_concrete
fill 163 183 345 164 183 345 minecraft:white_concrete
fill 163 183 347 165 183 347 minecraft:magenta_terracotta
fill 164 183 336 182 183 336 minecraft:purple_terracotta
fill 164 183 339 166 183 339 minecraft:magenta_terracotta
fill 164 183 340 164 183 344 minecraft:white_concrete
fill 164 183 346 166 183 346 minecraft:magenta_terracotta
fill 164 183 349 182 183 349 minecraft:purple_terracotta
fill 165 183 340 167 183 345 minecraft:magenta_terracotta
fill 166 183 337 175 183 338 minecraft:purple_terracotta
fill 166 183 347 182 183 348 minecraft:purple_terracotta
fill 167 183 323 167 183 327 minecraft:purple_terracotta
fill 167 183 329 167 183 331 minecraft:purple_terracotta
fill 167 183 339 176 183 339 minecraft:purple_terracotta
fill 167 183 346 182 183 346 minecraft:purple_terracotta
fill 168 183 323 182 183 326 minecraft:purple_terracotta
fill 168 183 330 182 183 331 minecraft:purple_terracotta
fill 168 183 340 182 183 345 minecraft:purple_terracotta
fill 170 183 327 182 183 329 minecraft:purple_terracotta
fill 170 183 350 182 183 351 minecraft:purple_terracotta
fill 170 183 355 182 183 357 minecraft:purple_terracotta
fill 172 183 352 182 183 352 minecraft:purple_terracotta
fill 172 183 354 182 183 354 minecraft:purple_terracotta
fill 173 183 353 182 183 353 minecraft:purple_terracotta
setblock 176 183 337 minecraft:purple_terracotta
fill 179 183 337 182 183 339 minecraft:purple_terracotta
fill 154 184 341 155 184 344 minecraft:magenta_terracotta
fill 155 184 339 156 184 340 minecraft:magenta_terracotta
fill 155 184 346 165 184 346 minecraft:magenta_terracotta
fill 156 184 344 156 184 345 minecraft:magenta_terracotta
fill 157 184 337 163 184 337 minecraft:magenta_terracotta
fill 157 184 339 165 184 339 minecraft:magenta_terracotta
fill 157 184 345 158 185 345 minecraft:magenta_terracotta
fill 157 184 348 163 184 348 minecraft:magenta_terracotta
fill 158 184 338 164 184 338 minecraft:magenta_terracotta
fill 158 184 347 164 184 347 minecraft:magenta_terracotta
fill 159 184 345 160 184 345 minecraft:orange_concrete
fill 160 184 340 161 184 340 minecraft:orange_concrete
fill 160 184 344 161 184 344 minecraft:orange_concrete
fill 161 184 341 161 184 343 minecraft:orange_concrete
setblock 161 184 345 minecraft:yellow_concrete
fill 162 184 340 165 184 340 minecraft:magenta_terracotta
fill 162 184 341 162 184 344 minecraft:yellow_concrete
fill 162 184 345 165 184 345 minecraft:magenta_terracotta
fill 163 184 341 166 184 344 minecraft:magenta_terracotta
setblock 144 185 325 minecraft:light[level=12]
setblock 144 185 332 minecraft:light[level=12]
setblock 144 185 339 minecraft:light[level=12]
setblock 144 185 346 minecraft:light[level=12]
setblock 144 185 353 minecraft:light[level=12]
setblock 144 185 360 minecraft:light[level=12]
setblock 151 185 325 minecraft:light[level=12]
setblock 151 185 332 minecraft:light[level=12]
setblock 151 185 339 minecraft:light[level=12]
setblock 151 185 346 minecraft:light[level=12]
setblock 151 185 353 minecraft:light[level=12]
setblock 151 185 360 minecraft:light[level=12]
setblock 156 185 344 minecraft:magenta_terracotta
fill 157 185 339 163 185 339 minecraft:magenta_terracotta
fill 157 185 346 163 185 346 minecraft:magenta_terracotta
setblock 158 185 325 minecraft:light[level=12]
setblock 158 185 332 minecraft:light[level=12]
setblock 158 185 353 minecraft:light[level=12]
setblock 158 185 360 minecraft:light[level=12]
fill 159 185 338 161 185 338 minecraft:magenta_terracotta
fill 159 185 345 163 185 345 minecraft:magenta_terracotta
fill 159 185 347 161 185 347 minecraft:magenta_terracotta
fill 160 185 340 163 185 340 minecraft:magenta_terracotta
fill 160 185 344 164 185 344 minecraft:magenta_terracotta
fill 161 185 341 164 185 343 minecraft:magenta_terracotta
setblock 165 185 325 minecraft:light[level=12]
setblock 165 185 332 minecraft:light[level=12]
setblock 165 185 339 minecraft:light[level=12]
setblock 165 185 346 minecraft:light[level=12]
setblock 165 185 353 minecraft:light[level=12]
setblock 165 185 360 minecraft:light[level=12]
setblock 172 185 325 minecraft:light[level=12]
setblock 172 185 332 minecraft:light[level=12]
setblock 172 185 339 minecraft:light[level=12]
setblock 172 185 346 minecraft:light[level=12]
setblock 172 185 353 minecraft:light[level=12]
setblock 172 185 360 minecraft:light[level=12]
setblock 179 185 325 minecraft:light[level=12]
setblock 179 185 332 minecraft:light[level=12]
setblock 179 185 339 minecraft:light[level=12]
setblock 179 185 346 minecraft:light[level=12]
setblock 179 185 353 minecraft:light[level=12]
setblock 179 185 360 minecraft:light[level=12]
fill 147 186 348 147 187 348 minecraft:pink_terracotta
fill 147 186 349 147 193 349 minecraft:magenta_terracotta
fill 149 186 322 151 218 322 minecraft:blue_terracotta
setblock 152 186 322 minecraft:cyan_concrete
fill 153 186 322 153 216 322 minecraft:blue_terracotta
fill 159 186 343 161 186 343 minecraft:magenta_terracotta
setblock 161 186 342 minecraft:magenta_terracotta
fill 176 186 339 176 211 339 minecraft:magenta_terracotta
fill 177 186 338 177 187 338 minecraft:pink_terracotta
fill 178 186 338 178 199 338 minecraft:magenta_terracotta
setblock 142 187 323 minecraft:dark_prismarine
fill 142 187 324 142 187 327 minecraft:blue_terracotta
setblock 142 187 328 minecraft:dark_prismarine
fill 142 187 329 142 187 332 minecraft:blue_terracotta
setblock 142 187 333 minecraft:dark_prismarine
fill 142 187 334 142 190 334 minecraft:blue_terracotta
fill 142 187 340 142 188 340 minecraft:purple_concrete
fill 142 187 345 142 187 347 minecraft:blue_terracotta
setblock 142 187 348 minecraft:dark_prismarine
fill 142 187 349 142 189 350 minecraft:blue_terracotta
setblock 142 187 359 minecraft:purple_concrete
fill 143 187 323 146 187 323 minecraft:blue_terracotta
fill 143 187 325 143 187 326 minecraft:blue_terracotta
setblock 143 187 327 minecraft:dark_prismarine
fill 143 187 328 143 187 331 minecraft:blue_terracotta
setblock 143 187 332 minecraft:dark_prismarine
fill 144 187 324 145 187 324 minecraft:blue_terracotta
fill 144 187 327 144 188 329 minecraft:blue_terracotta
setblock 145 187 325 minecraft:dark_prismarine
setblock 146 187 324 minecraft:dark_prismarine
fill 146 187 325 149 187 325 minecraft:blue_terracotta
setblock 147 187 323 minecraft:dark_prismarine
fill 147 187 324 150 187 324 minecraft:blue_terracotta
fill 147 187 326 148 187 326 minecraft:blue_terracotta
setblock 147 187 363 minecraft:dark_prismarine
fill 148 187 323 151 187 323 minecraft:blue_terracotta
fill 148 187 363 151 187 363 minecraft:blue_terracotta
setblock 149 187 326 minecraft:dark_prismarine
setblock 150 187 325 minecraft:dark_prismarine
fill 150 187 326 152 187 326 minecraft:blue_terracotta
setblock 151 187 324 minecraft:dark_prismarine
fill 151 187 325 154 187 325 minecraft:blue_terracotta
fill 152 187 322 152 220 322 minecraft:blue_terracotta
setblock 152 187 323 minecraft:dark_prismarine
fill 152 187 324 155 187 324 minecraft:blue_terracotta
setblock 152 187 363 minecraft:dark_prismarine
fill 153 187 323 156 187 323 minecraft:blue_terracotta
fill 153 187 363 155 188 363 minecraft:blue_terracotta
setblock 156 187 324 minecraft:dark_prismarine
setblock 156 187 358 minecraft:pink_terracotta
setblock 157 187 323 minecraft:dark_prismarine
setblock 157 187 363 minecraft:purple_concrete
fill 158 187 323 161 187 323 minecraft:blue_terracotta
setblock 162 187 323 minecraft:dark_prismarine
fill 163 187 323 166 187 323 minecraft:blue_terracotta
fill 163 187 363 166 187 363 minecraft:blue_terracotta
setblock 166 187 324 minecraft:dark_prismarine
setblock 167 187 323 minecraft:dark_prismarine
fill 167 187 324 170 187 324 minecraft:blue_terracotta
setblock 167 187 363 minecraft:dark_prismarine
fill 168 187 323 171 187 323 minecraft:blue_terracotta
setblock 168 187 328 minecraft:pink_terracotta
setblock 168 187 362 minecraft:dark_prismarine
fill 168 187 363 171 187 363 minecraft:blue_terracotta
fill 169 187 362 170 187 362 minecraft:blue_terracotta
setblock 172 187 323 minecraft:dark_prismarine
setblock 172 187 363 minecraft:dark_prismarine
setblock 173 187 323 minecraft:blue_terracotta
setblock 173 187 363 minecraft:blue_terracotta
fill 181 187 347 181 187 348 minecraft:blue_terracotta
setblock 181 187 349 minecraft:dark_prismarine
setblock 182 187 327 minecraft:blue_terracotta
setblock 182 187 328 minecraft:dark_prismarine
fill 182 187 329 182 188 331 minecraft:blue_terracotta
setblock 182 187 342 minecraft:blue_terracotta
setblock 182 187 343 minecraft:dark_prismarine
fill 182 187 344 182 187 347 minecraft:blue_terracotta
setblock 182 187 348 minecraft:dark_prismarine
fill 182 187 349 182 187 352 minecraft:blue_terracotta
setblock 182 187 353 minecraft:dark_prismarine
setblock 182 187 363 minecraft:purple_concrete
setblock 183 187 338 minecraft:cyan_concrete
fill 142 188 323 142 188 326 minecraft:blue_terracotta
setblock 142 188 327 minecraft:dark_prismarine
fill 142 188 328 142 188 331 minecraft:blue_terracotta
setblock 142 188 332 minecraft:dark_prismarine
fill 142 188 333 143 190 333 minecraft:blue_terracotta
fill 142 188 335 142 188 336 minecraft:blue_terracotta
fill 142 188 345 142 188 346 minecraft:blue_terracotta
setblock 142 188 347 minecraft:dark_prismarine
fill 142 188 348 142 191 348 minecraft:blue_terracotta
setblock 142 188 351 minecraft:blue_terracotta
fill 143 188 323 143 188 325 minecraft:blue_terracotta
setblock 143 188 326 minecraft:dark_prismarine
fill 143 188 327 143 188 330 minecraft:blue_terracotta
setblock 143 188 331 minecraft:dark_prismarine
fill 143 188 332 144 190 332 minecraft:blue_terracotta
fill 143 188 334 143 189 334 minecraft:blue_terracotta
fill 144 188 323 144 188 324 minecraft:blue_terracotta
fill 144 188 326 144 191 326 minecraft:blue_terracotta
setblock 144 188 330 minecraft:dark_prismarine
fill 144 188 331 144 191 331 minecraft:blue_terracotta
setblock 144 188 363 minecraft:purple_concrete
setblock 145 188 323 minecraft:blue_terracotta
setblock 145 188 324 minecraft:dark_prismarine
fill 145 188 325 148 188 325 minecraft:blue_terracotta
setblock 145 188 328 minecraft:blue_terracotta
setblock 145 188 329 minecraft:dark_prismarine
setblock 146 188 323 minecraft:dark_prismarine
fill 146 188 324 149 188 324 minecraft:blue_terracotta
fill 146 188 326 147 188 326 minecraft:blue_terracotta
fill 147 188 323 150 188 323 minecraft:blue_terracotta
fill 147 188 348 147 210 348 minecraft:magenta_terracotta
fill 147 188 363 150 188 363 minecraft:blue_terracotta
setblock 148 188 326 minecraft:dark_prismarine
setblock 149 188 325 minecraft:dark_prismarine
fill 149 188 326 151 189 326 minecraft:blue_terracotta
setblock 150 188 324 minecraft:dark_prismarine
fill 150 188 325 153 188 325 minecraft:blue_terracotta
setblock 151 188 323 minecraft:dark_prismarine
fill 151 188 324 154 188 324 minecraft:blue_terracotta
setblock 151 188 363 minecraft:dark_prismarine
fill 152 188 323 155 188 323 minecraft:blue_terracotta
fill 152 188 363 152 191 363 minecraft:blue_terracotta
setblock 154 188 325 minecraft:dark_prismarine
setblock 155 188 324 minecraft:dark_prismarine
setblock 156 188 323 minecraft:dark_prismarine
setblock 156 188 324 minecraft:blue_terracotta
fill 156 188 358 156 234 358 minecraft:magenta_terracotta
fill 157 188 323 160 188 323 minecraft:blue_terracotta
setblock 161 188 323 minecraft:dark_prismarine
fill 162 188 323 165 188 323 minecraft:blue_terracotta
fill 162 188 363 165 188 363 minecraft:blue_terracotta
setblock 166 188 323 minecraft:dark_prismarine
fill 166 188 324 169 188 324 minecraft:blue_terracotta
setblock 166 188 363 minecraft:dark_prismarine
fill 167 188 323 170 188 323 minecraft:blue_terracotta
setblock 167 188 362 minecraft:dark_prismarine
fill 167 188 363 170 188 363 minecraft:blue_terracotta
fill 168 188 328 168 234 328 minecraft:magenta_terracotta
fill 168 188 362 169 190 362 minecraft:blue_terracotta
setblock 170 188 324 minecraft:dark_prismarine
setblock 171 188 323 minecraft:dark_prismarine
setblock 171 188 363 minecraft:dark_prismarine
fill 172 188 323 172 189 323 minecraft:blue_terracotta
fill 172 188 363 172 190 363 minecraft:blue_terracotta
fill 177 188 338 177 213 338 minecraft:magenta_terracotta
setblock 180 188 323 minecraft:purple_concrete
fill 181 188 346 181 188 347 minecraft:blue_terracotta
setblock 181 188 348 minecraft:dark_prismarine
fill 181 188 349 182 188 351 minecraft:blue_terracotta
setblock 182 188 326 minecraft:blue_terracotta
setblock 182 188 327 minecraft:dark_prismarine
fill 182 188 328 182 191 328 minecraft:blue_terracotta
setblock 182 188 332 minecraft:dark_prismarine
fill 182 188 333 182 189 335 minecraft:blue_terracotta
setblock 182 188 340 minecraft:purple_concrete
setblock 182 188 342 minecraft:dark_prismarine
fill 182 188 343 182 188 346 minecraft:blue_terracotta
setblock 182 188 347 minecraft:dark_prismarine
fill 182 188 348 182 191 348 minecraft:blue_terracotta
setblock 182 188 352 minecraft:dark_prismarine
fill 182 188 353 182 190 354 minecraft:blue_terracotta
fill 183 188 338 183 220 338 minecraft:blue_terracotta
fill 142 189 323 142 189 325 minecraft:blue_terracotta
setblock 142 189 326 minecraft:dark_prismarine
fill 142 189 327 142 189 330 minecraft:blue_terracotta
setblock 142 189 331 minecraft:dark_prismarine
fill 142 189 332 142 192 332 minecraft:blue_terracotta
setblock 142 189 335 minecraft:blue_terracotta
setblock 142 189 336 minecraft:dark_prismarine
fill 142 189 337 142 191 338 minecraft:blue_terracotta
fill 142 189 344 142 189 345 minecraft:blue_terracotta
setblock 142 189 346 minecraft:dark_prismarine
fill 142 189 347 142 192 347 minecraft:blue_terracotta
setblock 142 189 351 minecraft:dark_prismarine
fill 142 189 352 142 191 353 minecraft:blue_terracotta
fill 143 189 323 143 189 324 minecraft:blue_terracotta
setblock 143 189 325 minecraft:dark_prismarine
fill 143 189 326 143 189 329 minecraft:blue_terracotta
setblock 143 189 330 minecraft:dark_prismarine
fill 143 189 331 143 192 331 minecraft:blue_terracotta
setblock 143 189 335 minecraft:dark_prismarine
setblock 144 189 323 minecraft:blue_terracotta
setblock 144 189 324 minecraft:dark_prismarine
fill 144 189 325 147 189 325 minecraft:blue_terracotta
fill 144 189 327 144 189 328 minecraft:blue_terracotta
setblock 144 189 329 minecraft:dark_prismarine
fill 144 189 330 145 191 330 minecraft:blue_terracotta
setblock 144 189 333 minecraft:blue_terracotta
setblock 144 189 341 minecraft:light[level=13]
setblock 144 189 349 minecraft:light[level=13]
setblock 144 189 357 minecraft:light[level=13]
setblock 145 189 323 minecraft:dark_prismarine
fill 145 189 324 148 189 324 minecraft:blue_terracotta
fill 145 189 326 145 189 327 minecraft:blue_terracotta
setblock 145 189 328 minecraft:dark_prismarine
fill 145 189 329 145 192 329 minecraft:blue_terracotta
fill 145 189 331 145 190 331 minecraft:blue_terracotta
fill 146 189 323 149 189 323 minecraft:blue_terracotta
setblock 146 189 326 minecraft:blue_terracotta
fill 146 189 363 149 189 363 minecraft:blue_terracotta
setblock 147 189 326 minecraft:dark_prismarine
setblock 148 189 325 minecraft:dark_prismarine
fill 148 189 326 148 192 326 minecraft:blue_terracotta
setblock 149 189 324 minecraft:dark_prismarine
fill 149 189 325 152 189 325 minecraft:blue_terracotta
setblock 150 189 323 minecraft:dark_prismarine
fill 150 189 324 153 189 324 minecraft:blue_terracotta
setblock 150 189 363 minecraft:dark_prismarine
fill 151 189 323 154 189 323 minecraft:blue_terracotta
fill 151 189 363 151 192 363 minecraft:blue_terracotta
setblock 152 189 333 minecraft:light[level=13]
setblock 152 189 341 minecraft:light[level=13]
setblock 152 189 349 minecraft:light[level=13]
setblock 152 189 357 minecraft:light[level=13]
setblock 153 189 325 minecraft:dark_prismarine
fill 153 189 363 154 189 363 minecraft:blue_terracotta
setblock 154 189 324 minecraft:dark_prismarine
setblock 155 189 323 minecraft:dark_prismarine
fill 155 189 324 155 190 324 minecraft:blue_terracotta
setblock 155 189 363 minecraft:dark_prismarine
fill 156 189 323 159 189 323 minecraft:blue_terracotta
setblock 160 189 323 minecraft:dark_prismarine
setblock 160 189 325 minecraft:light[level=13]
setblock 160 189 333 minecraft:light[level=13]
setblock 160 189 349 minecraft:light[level=13]
setblock 160 189 357 minecraft:light[level=13]
fill 161 189 323 164 189 323 minecraft:blue_terracotta
fill 161 189 363 164 189 363 minecraft:blue_terracotta
setblock 165 189 323 minecraft:dark_prismarine
fill 165 189 324 168 189 324 minecraft:blue_terracotta
setblock 165 189 362 minecraft:blue_terracotta
setblock 165 189 363 minecraft:dark_prismarine
fill 166 189 323 169 189 323 minecraft:blue_terracotta
setblock 166 189 362 minecraft:dark_prismarine
fill 166 189 363 169 189 363 minecraft:blue_terracotta
fill 167 189 362 167 192 362 minecraft:blue_terracotta
setblock 168 189 325 minecraft:light[level=13]
setblock 168 189 333 minecraft:light[level=13]
setblock 168 189 341 minecraft:light[level=13]
setblock 168 189 349 minecraft:light[level=13]
setblock 168 189 357 minecraft:light[level=13]
setblock 169 189 324 minecraft:dark_prismarine
setblock 170 189 323 minecraft:dark_prismarine
setblock 170 189 363 minecraft:dark_prismarine
fill 171 189 323 171 190 323 minecraft:blue_terracotta
fill 171 189 363 171 192 363 minecraft:blue_terracotta
fill 173 189 340 173 190 340 minecraft:black_concrete
setblock 174 189 323 minecraft:purple_concrete
setblock 175 189 363 minecraft:purple_concrete
setblock 176 189 325 minecraft:light[level=13]
setblock 176 189 333 minecraft:light[level=13]
setblock 176 189 341 minecraft:light[level=13]
setblock 176 189 349 minecraft:light[level=13]
setblock 176 189 357 minecraft:light[level=13]
fill 178 189 346 178 197 346 minecraft:iron_bars
setblock 181 189 346 minecraft:blue_terracotta
setblock 181 189 347 minecraft:dark_prismarine
fill 181 189 348 181 189 351 minecraft:blue_terracotta
setblock 181 189 352 minecraft:dark_prismarine
setblock 182 189 325 minecraft:blue_terracotta
setblock 182 189 326 minecraft:dark_prismarine
fill 182 189 327 182 192 327 minecraft:blue_terracotta
fill 182 189 329 182 189 330 minecraft:blue_terracotta
setblock 182 189 331 minecraft:dark_prismarine
fill 182 189 332 182 192 332 minecraft:blue_terracotta
setblock 182 189 336 minecraft:dark_prismarine
fill 182 189 337 182 189 340 minecraft:blue_terracotta
setblock 182 189 341 minecraft:dark_prismarine
fill 182 189 342 182 189 345 minecraft:blue_terracotta
setblock 182 189 346 minecraft:dark_prismarine
fill 182 189 347 182 192 347 minecraft:blue_terracotta
fill 182 189 349 182 189 350 minecraft:blue_terracotta
setblock 182 189 351 minecraft:dark_prismarine
fill 182 189 352 182 192 352 minecraft:blue_terracotta
setblock 182 189 355 minecraft:blue_terracotta
setblock 182 189 359 minecraft:purple_concrete
fill 141 190 354 141 220 355 minecraft:blue_terracotta
setblock 141 190 356 minecraft:cyan_concrete
fill 142 190 323 142 190 324 minecraft:blue_terracotta
setblock 142 190 325 minecraft:dark_prismarine
fill 142 190 326 142 190 329 minecraft:blue_terracotta
setblock 142 190 330 minecraft:dark_prismarine
fill 142 190 331 142 193 331 minecraft:blue_terracotta
setblock 142 190 335 minecraft:dark_prismarine
fill 142 190 336 143 192 336 minecraft:blue_terracotta
setblock 142 190 339 minecraft:blue_terracotta
setblock 142 190 340 minecraft:dark_prismarine
fill 142 190 343 142 190 344 minecraft:blue_terracotta
setblock 142 190 345 minecraft:dark_prismarine
fill 142 190 346 142 193 346 minecraft:blue_terracotta
setblock 142 190 349 minecraft:blue_terracotta
setblock 142 190 350 minecraft:dark_prismarine
fill 142 190 351 143 192 351 minecraft:blue_terracotta
setblock 142 190 354 minecraft:blue_terracotta
setblock 142 190 355 minecraft:dark_prismarine
setblock 142 190 358 minecraft:purple_concrete
setblock 143 190 323 minecraft:blue_terracotta
setblock 143 190 324 minecraft:dark_prismarine
fill 143 190 325 143 190 328 minecraft:blue_terracotta
setblock 143 190 329 minecraft:dark_prismarine
fill 143 190 330 143 193 330 minecraft:blue_terracotta
setblock 143 190 334 minecraft:dark_prismarine
fill 143 190 335 144 192 335 minecraft:blue_terracotta
fill 143 190 337 143 191 337 minecraft:blue_terracotta
setblock 143 190 349 minecraft:dark_prismarine
fill 143 190 350 143 193 350 minecraft:blue_terracotta
fill 143 190 352 143 191 352 minecraft:blue_terracotta
setblock 144 190 323 minecraft:dark_prismarine
fill 144 190 324 146 190 325 minecraft:blue_terracotta
setblock 144 190 327 minecraft:blue_terracotta
setblock 144 190 328 minecraft:dark_prismarine
fill 144 190 329 144 193 329 minecraft:blue_terracotta
setblock 144 190 333 minecraft:dark_prismarine
fill 144 190 334 144 193 334 minecraft:blue_terracotta
fill 145 190 323 148 190 323 minecraft:blue_terracotta
setblock 145 190 326 minecraft:blue_terracotta
setblock 145 190 327 minecraft:dark_prismarine
fill 145 190 328 145 193 328 minecraft:blue_terracotta
setblock 145 190 332 minecraft:dark_prismarine
fill 145 190 333 145 193 333 minecraft:blue_terracotta
fill 145 190 363 148 190 363 minecraft:blue_terracotta
setblock 146 190 326 minecraft:dark_prismarine
fill 146 190 329 146 191 329 minecraft:blue_terracotta
setblock 147 190 324 minecraft:blue_terracotta
setblock 147 190 325 minecraft:dark_prismarine
fill 147 190 326 147 193 326 minecraft:blue_terracotta
setblock 148 190 324 minecraft:dark_prismarine
fill 148 190 325 151 190 325 minecraft:blue_terracotta
setblock 149 190 323 minecraft:dark_prismarine
fill 149 190 324 152 190 324 minecraft:blue_terracotta
fill 149 190 326 150 190 326 minecraft:blue_terracotta
setblock 149 190 363 minecraft:dark_prismarine
fill 150 190 323 153 190 323 minecraft:blue_terracotta
fill 150 190 363 150 193 363 minecraft:blue_terracotta
setblock 151 190 326 minecraft:dark_prismarine
setblock 152 190 325 minecraft:dark_prismarine
setblock 153 190 324 minecraft:dark_prismarine
setblock 153 190 325 minecraft:blue_terracotta
setblock 153 190 363 minecraft:blue_terracotta
setblock 154 190 323 minecraft:dark_prismarine
fill 154 190 324 154 191 324 minecraft:blue_terracotta
setblock 154 190 363 minecraft:dark_prismarine
fill 155 190 323 158 190 323 minecraft:blue_terracotta
fill 155 190 363 155 193 363 minecraft:blue_terracotta
setblock 156 190 363 minecraft:purple_concrete
setblock 159 190 323 minecraft:dark_prismarine
fill 160 190 323 163 190 323 minecraft:blue_terracotta
fill 160 190 363 163 190 363 minecraft:blue_terracotta
setblock 164 190 323 minecraft:dark_prismarine
setblock 164 190 362 minecraft:blue_terracotta
setblock 164 190 363 minecraft:dark_prismarine
fill 165 190 323 167 190 324 minecraft:blue_terracotta
setblock 165 190 362 minecraft:dark_prismarine
fill 165 190 363 168 190 363 minecraft:blue_terracotta
fill 166 190 362 166 193 362 minecraft:blue_terracotta
setblock 168 190 323 minecraft:blue_terracotta
setblock 168 190 324 minecraft:dark_prismarine
fill 168 190 337 168 191 337 minecraft:dark_prismarine
setblock 169 190 323 minecraft:dark_prismarine
setblock 169 190 324 minecraft:blue_terracotta
setblock 169 190 363 minecraft:dark_prismarine
fill 170 190 323 170 192 323 minecraft:blue_terracotta
fill 170 190 363 170 193 363 minecraft:blue_terracotta
fill 181 190 328 181 190 330 minecraft:blue_terracotta
setblock 181 190 331 minecraft:dark_prismarine
fill 181 190 332 181 191 334 minecraft:blue_terracotta
setblock 181 190 346 minecraft:dark_prismarine
fill 181 190 347 181 190 350 minecraft:blue_terracotta
setblock 181 190 351 minecraft:dark_prismarine
fill 181 190 352 181 192 353 minecraft:blue_terracotta
setblock 181 190 363 minecraft:purple_concrete
setblock 182 190 325 minecraft:dark_prismarine
fill 182 190 326 182 193 326 minecraft:blue_terracotta
setblock 182 190 329 minecraft:blue_terracotta
setblock 182 190 330 minecraft:dark_prismarine
fill 182 190 331 182 193 331 minecraft:blue_terracotta
fill 182 190 333 182 190 334 minecraft:blue_terracotta
setblock 182 190 335 minecraft:dark_prismarine
fill 182 190 336 182 190 339 minecraft:blue_terracotta
setblock 182 190 340 minecraft:dark_prismarine
fill 182 190 341 182 190 344 minecraft:blue_terracotta
setblock 182 190 345 minecraft:dark_prismarine
fill 182 190 346 182 193 346 minecraft:blue_terracotta
setblock 182 190 349 minecraft:blue_terracotta
setblock 182 190 350 minecraft:dark_prismarine
fill 182 190 351 182 193 351 minecraft:blue_terracotta
setblock 182 190 355 minecraft:dark_prismarine
fill 182 190 356 182 193 356 minecraft:blue_terracotta
setblock 183 190 336 minecraft:light_blue_wool
fill 141 191 345 141 192 347 minecraft:blue_terracotta
setblock 141 191 348 minecraft:cyan_concrete
fill 141 191 356 142 193 356 minecraft:blue_terracotta
setblock 142 191 323 minecraft:blue_terracotta
setblock 142 191 324 minecraft:dark_prismarine
fill 142 191 325 142 191 328 minecraft:blue_terracotta
setblock 142 191 329 minecraft:dark_prismarine
fill 142 191 330 142 194 330 minecraft:blue_terracotta
setblock 142 191 333 minecraft:blue_terracotta
setblock 142 191 334 minecraft:dark_prismarine
fill 142 191 335 142 194 335 minecraft:blue_terracotta
setblock 142 191 339 minecraft:dark_prismarine
fill 142 191 340 142 191 343 minecraft:blue_terracotta
setblock 142 191 344 minecraft:dark_prismarine
fill 142 191 345 142 194 345 minecraft:blue_terracotta
setblock 142 191 349 minecraft:dark_prismarine
fill 142 191 350 142 194 350 minecraft:blue_terracotta
setblock 142 191 354 minecraft:dark_prismarine
fill 142 191 355 142 194 355 minecraft:blue_terracotta
fill 142 191 357 142 192 357 minecraft:blue_terracotta
setblock 143 191 323 minecraft:dark_prismarine
fill 143 191 324 143 191 327 minecraft:blue_terracotta
setblock 143 191 328 minecraft:dark_prismarine
fill 143 191 329 143 194 329 minecraft:blue_terracotta
setblock 143 191 332 minecraft:blue_terracotta
setblock 143 191 333 minecraft:dark_prismarine
fill 143 191 334 143 194 334 minecraft:blue_terracotta
setblock 143 191 338 minecraft:dark_prismarine
setblock 143 191 348 minecraft:dark_prismarine
fill 143 191 349 143 193 349 minecraft:blue_terracotta
setblock 143 191 353 minecraft:dark_prismarine
fill 143 191 354 143 194 354 minecraft:blue_terracotta
setblock 143 191 363 minecraft:purple_concrete
fill 144 191 323 145 191 325 minecraft:blue_terracotta
setblock 144 191 327 minecraft:dark_prismarine
fill 144 191 328 144 194 328 minecraft:blue_terracotta
setblock 144 191 332 minecraft:dark_prismarine
fill 144 191 333 144 194 333 minecraft:blue_terracotta
setblock 144 191 336 minecraft:blue_terracotta
setblock 144 191 339 minecraft:light[level=12]
setblock 144 191 346 minecraft:light[level=12]
setblock 144 191 353 minecraft:light[level=12]
setblock 144 191 360 minecraft:light[level=12]
fill 144 191 363 147 191 363 minecraft:blue_terracotta
setblock 145 191 326 minecraft:dark_prismarine
fill 145 191 327 145 194 327 minecraft:blue_terracotta
setblock 145 191 331 minecraft:dark_prismarine
fill 145 191 332 145 194 332 minecraft:blue_terracotta
fill 145 191 334 145 192 334 minecraft:blue_terracotta
fill 146 191 323 146 191 324 minecraft:blue_terracotta
setblock 146 191 325 minecraft:dark_prismarine
fill 146 191 326 146 193 326 minecraft:blue_terracotta
fill 146 191 328 146 192 328 minecraft:blue_terracotta
setblock 146 191 330 minecraft:dark_prismarine
fill 146 191 331 146 193 331 minecraft:blue_terracotta
setblock 147 191 323 minecraft:blue_terracotta
setblock 147 191 324 minecraft:dark_prismarine
fill 147 191 325 150 191 325 minecraft:blue_terracotta
fill 147 191 362 148 191 362 minecraft:blue_terracotta
setblock 148 191 323 minecraft:dark_prismarine
fill 148 191 324 151 191 324 minecraft:blue_terracotta
setblock 148 191 363 minecraft:dark_prismarine
fill 149 191 323 152 191 323 minecraft:blue_terracotta
setblock 149 191 326 minecraft:blue_terracotta
setblock 149 191 362 minecraft:dark_prismarine
fill 149 191 363 149 194 363 minecraft:blue_terracotta
setblock 150 191 326 minecraft:dark_prismarine
fill 150 191 362 150 194 362 minecraft:blue_terracotta
setblock 151 191 325 minecraft:dark_prismarine
setblock 151 191 332 minecraft:light[level=12]
setblock 151 191 339 minecraft:light[level=12]
setblock 151 191 346 minecraft:light[level=12]
setblock 151 191 353 minecraft:light[level=12]
setblock 151 191 360 minecraft:light[level=12]
setblock 152 191 324 minecraft:dark_prismarine
setblock 152 191 325 minecraft:blue_terracotta
setblock 153 191 323 minecraft:dark_prismarine
fill 153 191 324 153 192 324 minecraft:blue_terracotta
setblock 153 191 363 minecraft:dark_prismarine
fill 154 191 323 157 191 323 minecraft:blue_terracotta
fill 154 191 363 154 194 363 minecraft:blue_terracotta
fill 156 191 363 156 192 363 minecraft:blue_terracotta
setblock 158 191 325 minecraft:light[level=12]
setblock 158 191 332 minecraft:light[level=12]
setblock 158 191 339 minecraft:light[level=12]
setblock 158 191 346 minecraft:light[level=12]
setblock 158 191 353 minecraft:light[level=12]
setblock 158 191 360 minecraft:light[level=12]
fill 159 191 363 162 191 363 minecraft:blue_terracotta
fill 160 191 323 162 191 323 minecraft:blue_terracotta
setblock 163 191 323 minecraft:dark_prismarine
setblock 163 191 362 minecraft:blue_terracotta
setblock 163 191 363 minecraft:dark_prismarine
fill 164 191 323 167 191 323 minecraft:blue_terracotta
setblock 164 191 362 minecraft:dark_prismarine
fill 164 191 363 167 191 363 minecraft:blue_terracotta
fill 165 191 324 166 191 324 minecraft:blue_terracotta
setblock 165 191 325 minecraft:light[level=12]
setblock 165 191 332 minecraft:light[level=12]
setblock 165 191 339 minecraft:light[level=12]
setblock 165 191 346 minecraft:light[level=12]
setblock 165 191 353 minecraft:light[level=12]
setblock 165 191 360 minecraft:light[level=12]
fill 165 191 362 165 194 362 minecraft:blue_terracotta
setblock 167 191 324 minecraft:dark_prismarine
setblock 168 191 323 minecraft:dark_prismarine
setblock 168 191 324 minecraft:blue_terracotta
setblock 168 191 362 minecraft:blue_terracotta
setblock 168 191 363 minecraft:dark_prismarine
fill 169 191 323 169 193 323 minecraft:blue_terracotta
fill 169 191 354 169 216 354 minecraft:magenta_terracotta
setblock 169 191 362 minecraft:dark_prismarine
fill 169 191 363 169 194 363 minecraft:blue_terracotta
setblock 172 191 325 minecraft:light[level=12]
setblock 172 191 332 minecraft:light[level=12]
setblock 172 191 339 minecraft:light[level=12]
setblock 172 191 346 minecraft:light[level=12]
setblock 172 191 353 minecraft:light[level=12]
setblock 172 191 360 minecraft:light[level=12]
setblock 179 191 325 minecraft:light[level=12]
setblock 179 191 332 minecraft:light[level=12]
setblock 179 191 339 minecraft:light[level=12]
setblock 179 191 346 minecraft:light[level=12]
setblock 179 191 353 minecraft:light[level=12]
setblock 179 191 360 minecraft:light[level=12]
setblock 181 191 323 minecraft:purple_concrete
fill 181 191 327 181 191 329 minecraft:blue_terracotta
setblock 181 191 330 minecraft:dark_prismarine
fill 181 191 331 181 194 331 minecraft:blue_terracotta
setblock 181 191 335 minecraft:dark_prismarine
fill 181 191 336 182 192 337 minecraft:blue_terracotta
fill 181 191 346 181 191 349 minecraft:blue_terracotta
setblock 181 191 350 minecraft:dark_prismarine
fill 181 191 351 181 194 351 minecraft:blue_terracotta
setblock 181 191 354 minecraft:blue_terracotta
setblock 182 191 324 minecraft:dark_prismarine
fill 182 191 325 182 194 325 minecraft:blue_terracotta
setblock 182 191 329 minecraft:dark_prismarine
fill 182 191 330 182 194 330 minecraft:blue_terracotta
setblock 182 191 333 minecraft:blue_terracotta
setblock 182 191 334 minecraft:dark_prismarine
fill 182 191 335 182 194 335 minecraft:blue_terracotta
setblock 182 191 338 minecraft:blue_terracotta
setblock 182 191 339 minecraft:dark_prismarine
fill 182 191 340 182 191 343 minecraft:blue_terracotta
setblock 182 191 344 minecraft:dark_prismarine
fill 182 191 345 182 194 345 minecraft:blue_terracotta
setblock 182 191 349 minecraft:dark_prismarine
fill 182 191 350 182 194 350 minecraft:blue_terracotta
setblock 182 191 353 minecraft:blue_terracotta
setblock 182 191 354 minecraft:dark_prismarine
fill 182 191 355 182 194 355 minecraft:blue_terracotta
fill 182 191 357 182 192 357 minecraft:blue_terracotta
fill 183 191 336 183 220 336 minecraft:blue_terracotta
fill 141 192 348 141 216 348 minecraft:blue_terracotta
setblock 142 192 323 minecraft:dark_prismarine
fill 142 192 324 142 192 327 minecraft:blue_terracotta
setblock 142 192 328 minecraft:dark_prismarine
fill 142 192 329 142 195 329 minecraft:blue_terracotta
setblock 142 192 333 minecraft:dark_prismarine
fill 142 192 334 142 195 334 minecraft:blue_terracotta
setblock 142 192 337 minecraft:blue_terracotta
setblock 142 192 338 minecraft:dark_prismarine
fill 142 192 339 142 192 342 minecraft:blue_terracotta
setblock 142 192 343 minecraft:dark_prismarine
fill 142 192 344 142 194 344 minecraft:blue_terracotta
setblock 142 192 348 minecraft:dark_prismarine
fill 142 192 349 142 195 349 minecraft:blue_terracotta
setblock 142 192 352 minecraft:blue_terracotta
setblock 142 192 353 minecraft:dark_prismarine
fill 142 192 354 142 195 354 minecraft:blue_terracotta
setblock 142 192 358 minecraft:dark_prismarine
fill 142 192 359 142 195 359 minecraft:blue_terracotta
fill 143 192 323 143 192 326 minecraft:blue_terracotta
setblock 143 192 327 minecraft:dark_prismarine
fill 143 192 328 143 195 328 minecraft:blue_terracotta
setblock 143 192 332 minecraft:dark_prismarine
fill 143 192 333 143 195 333 minecraft:blue_terracotta
setblock 143 192 337 minecraft:dark_prismarine
fill 143 192 338 143 194 339 minecraft:blue_terracotta
setblock 143 192 348 minecraft:blue_terracotta
setblock 143 192 352 minecraft:dark_prismarine
fill 143 192 353 143 195 353 minecraft:blue_terracotta
fill 143 192 355 143 192 356 minecraft:blue_terracotta
fill 143 192 363 146 192 363 minecraft:blue_terracotta
fill 144 192 323 144 192 325 minecraft:blue_terracotta
setblock 144 192 326 minecraft:dark_prismarine
fill 144 192 327 144 195 327 minecraft:blue_terracotta
setblock 144 192 330 minecraft:blue_terracotta
setblock 144 192 331 minecraft:dark_prismarine
fill 144 192 332 144 195 332 minecraft:blue_terracotta
setblock 144 192 336 minecraft:dark_prismarine
fill 144 192 337 144 195 337 minecraft:blue_terracotta
fill 145 192 323 145 192 324 minecraft:blue_terracotta
setblock 145 192 325 minecraft:dark_prismarine
fill 145 192 326 145 193 326 minecraft:blue_terracotta
setblock 145 192 330 minecraft:dark_prismarine
fill 145 192 331 145 195 331 minecraft:blue_terracotta
setblock 145 192 335 minecraft:dark_prismarine
setblock 146 192 323 minecraft:blue_terracotta
setblock 146 192 324 minecraft:dark_prismarine
fill 146 192 325 149 192 325 minecraft:blue_terracotta
setblock 146 192 329 minecraft:dark_prismarine
fill 146 192 330 146 193 330 minecraft:blue_terracotta
fill 146 192 332 146 193 332 minecraft:blue_terracotta
fill 146 192 362 147 192 362 minecraft:blue_terracotta
setblock 147 192 323 minecraft:dark_prismarine
fill 147 192 324 150 192 324 minecraft:blue_terracotta
setblock 147 192 363 minecraft:dark_prismarine
fill 148 192 323 151 192 323 minecraft:blue_terracotta
setblock 148 192 362 minecraft:dark_prismarine
fill 148 192 363 148 195 363 minecraft:blue_terracotta
setblock 149 192 326 minecraft:dark_prismarine
fill 149 192 362 149 195 362 minecraft:blue_terracotta
setblock 150 192 325 minecraft:dark_prismarine
setblock 151 192 324 minecraft:dark_prismarine
setblock 151 192 325 minecraft:blue_terracotta
setblock 152 192 323 minecraft:dark_prismarine
fill 152 192 324 152 193 324 minecraft:blue_terracotta
setblock 152 192 363 minecraft:dark_prismarine
fill 153 192 323 156 192 323 minecraft:blue_terracotta
fill 153 192 363 153 195 363 minecraft:blue_terracotta
setblock 157 192 363 minecraft:dark_prismarine
fill 158 192 363 161 192 363 minecraft:blue_terracotta
fill 160 192 323 161 192 323 minecraft:blue_terracotta
setblock 162 192 323 minecraft:dark_prismarine
setblock 162 192 362 minecraft:blue_terracotta
setblock 162 192 363 minecraft:dark_prismarine
fill 163 192 323 166 192 323 minecraft:blue_terracotta
setblock 163 192 362 minecraft:dark_prismarine
fill 163 192 363 166 192 363 minecraft:blue_terracotta
fill 164 192 362 164 195 362 minecraft:blue_terracotta
fill 165 192 361 167 193 361 minecraft:blue_terracotta
setblock 167 192 323 minecraft:dark_prismarine
setblock 167 192 363 minecraft:dark_prismarine
fill 168 192 323 168 193 323 minecraft:blue_terracotta
setblock 168 192 362 minecraft:dark_prismarine
fill 168 192 363 168 195 363 minecraft:blue_terracotta
fill 169 192 362 169 193 362 minecraft:blue_terracotta
fill 170 192 355 170 211 355 minecraft:magenta_terracotta
setblock 175 192 323 minecraft:purple_concrete
fill 180 192 332 181 193 332 minecraft:blue_terracotta
fill 181 192 327 181 192 328 minecraft:blue_terracotta
setblock 181 192 329 minecraft:dark_prismarine
fill 181 192 330 181 195 330 minecraft:blue_terracotta
setblock 181 192 333 minecraft:blue_terracotta
setblock 181 192 334 minecraft:dark_prismarine
fill 181 192 335 181 195 335 minecraft:blue_terracotta
setblock 181 192 338 minecraft:blue_terracotta
setblock 181 192 339 minecraft:dark_prismarine
fill 181 192 346 181 192 348 minecraft:blue_terracotta
setblock 181 192 349 minecraft:dark_prismarine
fill 181 192 350 181 195 350 minecraft:blue_terracotta
setblock 181 192 354 minecraft:dark_prismarine
fill 181 192 355 181 195 355 minecraft:blue_terracotta
fill 182 192 324 182 195 324 minecraft:blue_terracotta
setblock 182 192 328 minecraft:dark_prismarine
fill 182 192 329 182 195 329 minecraft:blue_terracotta
setblock 182 192 333 minecraft:dark_prismarine
fill 182 192 334 182 195 334 minecraft:blue_terracotta
setblock 182 192 338 minecraft:dark_prismarine
fill 182 192 339 182 192 342 minecraft:blue_terracotta
setblock 182 192 343 minecraft:dark_prismarine
fill 182 192 344 182 195 344 minecraft:blue_terracotta
setblock 182 192 348 minecraft:dark_prismarine
fill 182 192 349 182 195 349 minecraft:blue_terracotta
setblock 182 192 353 minecraft:dark_prismarine
fill 182 192 354 182 195 354 minecraft:blue_terracotta
setblock 182 192 358 minecraft:dark_prismarine
setblock 182 192 360 minecraft:purple_concrete
fill 183 192 330 183 220 332 minecraft:blue_terracotta
setblock 183 192 333 minecraft:light_blue_wool
fill 141 193 345 141 220 346 minecraft:blue_terracotta
setblock 141 193 347 minecraft:light_blue_wool
fill 142 193 323 142 193 326 minecraft:blue_terracotta
setblock 142 193 327 minecraft:dark_prismarine
fill 142 193 328 142 196 328 minecraft:blue_terracotta
setblock 142 193 332 minecraft:dark_prismarine
fill 142 193 333 142 196 333 minecraft:blue_terracotta
setblock 142 193 336 minecraft:blue_terracotta
setblock 142 193 337 minecraft:dark_prismarine
fill 142 193 338 142 193 341 minecraft:blue_terracotta
setblock 142 193 342 minecraft:dark_prismarine
fill 142 193 343 142 195 343 minecraft:blue_terracotta
setblock 142 193 347 minecraft:dark_prismarine
fill 142 193 348 142 195 348 minecraft:blue_terracotta
setblock 142 193 351 minecraft:blue_terracotta
setblock 142 193 352 minecraft:dark_prismarine
fill 142 193 353 142 196 353 minecraft:blue_terracotta
setblock 142 193 357 minecraft:dark_prismarine
fill 142 193 358 143 195 358 minecraft:blue_terracotta
fill 142 193 360 142 193 361 minecraft:blue_terracotta
setblock 142 193 362 minecraft:dark_prismarine
fill 142 193 363 145 193 363 minecraft:blue_terracotta
fill 143 193 323 143 193 325 minecraft:blue_terracotta
setblock 143 193 326 minecraft:dark_prismarine
fill 143 193 327 143 196 327 minecraft:blue_terracotta
setblock 143 193 331 minecraft:dark_prismarine
fill 143 193 332 143 196 332 minecraft:blue_terracotta
setblock 143 193 335 minecraft:blue_terracotta
setblock 143 193 336 minecraft:dark_prismarine
fill 143 193 337 143 196 337 minecraft:blue_terracotta
setblock 143 193 340 minecraft:blue_terracotta
setblock 143 193 351 minecraft:dark_prismarine
fill 143 193 352 143 196 352 minecraft:blue_terracotta
setblock 143 193 355 minecraft:blue_terracotta
setblock 143 193 356 minecraft:dark_prismarine
fill 143 193 357 143 196 357 minecraft:blue_terracotta
fill 144 193 323 144 193 324 minecraft:blue_terracotta
setblock 144 193 325 minecraft:dark_prismarine
fill 144 193 326 144 196 326 minecraft:blue_terracotta
setblock 144 193 330 minecraft:dark_prismarine
fill 144 193 331 144 196 331 minecraft:blue_terracotta
setblock 144 193 335 minecraft:dark_prismarine
fill 144 193 336 144 196 336 minecraft:blue_terracotta
fill 144 193 353 144 193 354 minecraft:blue_terracotta
setblock 145 193 323 minecraft:blue_terracotta
setblock 145 193 324 minecraft:dark_prismarine
fill 145 193 325 148 193 325 minecraft:blue_terracotta
setblock 145 193 329 minecraft:dark_prismarine
fill 145 193 330 145 195 330 minecraft:blue_terracotta
setblock 145 193 334 minecraft:dark_prismarine
fill 145 193 335 145 195 335 minecraft:blue_terracotta
fill 145 193 362 146 193 362 minecraft:blue_terracotta
setblock 146 193 322 minecraft:cyan_concrete
setblock 146 193 323 minecraft:dark_prismarine
fill 146 193 324 149 193 324 minecraft:blue_terracotta
setblock 146 193 329 minecraft:blue_terracotta
setblock 146 193 363 minecraft:dark_prismarine
fill 147 193 322 147 196 323 minecraft:blue_terracotta
setblock 147 193 362 minecraft:dark_prismarine
fill 147 193 363 147 196 363 minecraft:blue_terracotta
fill 148 193 323 150 193 323 minecraft:blue_terracotta
fill 148 193 362 148 196 362 minecraft:blue_terracotta
setblock 149 193 325 minecraft:dark_prismarine
setblock 150 193 324 minecraft:dark_prismarine
setblock 150 193 325 minecraft:blue_terracotta
setblock 151 193 323 minecraft:dark_prismarine
setblock 151 193 324 minecraft:blue_terracotta
setblock 151 193 363 minecraft:dark_prismarine
fill 152 193 323 154 193 323 minecraft:blue_terracotta
fill 152 193 363 152 196 363 minecraft:blue_terracotta
setblock 156 193 363 minecraft:dark_prismarine
fill 157 193 363 160 193 363 minecraft:blue_terracotta
setblock 161 193 323 minecraft:dark_prismarine
setblock 161 193 362 minecraft:blue_terracotta
setblock 161 193 363 minecraft:dark_prismarine
fill 162 193 323 165 193 323 minecraft:blue_terracotta
setblock 162 193 362 minecraft:dark_prismarine
fill 162 193 363 165 193 363 minecraft:blue_terracotta
fill 163 193 362 163 196 362 minecraft:blue_terracotta
fill 164 193 361 164 196 361 minecraft:blue_terracotta
setblock 166 193 323 minecraft:dark_prismarine
setblock 166 193 363 minecraft:dark_prismarine
fill 167 193 323 167 194 323 minecraft:blue_terracotta
setblock 167 193 362 minecraft:dark_prismarine
fill 167 193 363 167 196 363 minecraft:blue_terracotta
fill 168 193 362 168 195 362 minecraft:blue_terracotta
setblock 174 193 363 minecraft:purple_concrete
fill 180 193 331 180 195 331 minecraft:blue_terracotta
setblock 180 193 333 minecraft:blue_terracotta
setblock 180 193 334 minecraft:dark_prismarine
fill 180 193 335 180 196 335 minecraft:blue_terracotta
setblock 181 193 327 minecraft:blue_terracotta
setblock 181 193 328 minecraft:dark_prismarine
fill 181 193 329 181 196 329 minecraft:blue_terracotta
setblock 181 193 333 minecraft:dark_prismarine
fill 181 193 334 181 196 334 minecraft:blue_terracotta
fill 181 193 336 181 193 337 minecraft:blue_terracotta
setblock 181 193 338 minecraft:dark_prismarine
fill 181 193 339 182 193 341 minecraft:blue_terracotta
fill 181 193 346 181 193 347 minecraft:blue_terracotta
setblock 181 193 348 minecraft:dark_prismarine
fill 181 193 349 181 194 349 minecraft:blue_terracotta
setblock 181 193 352 minecraft:blue_terracotta
setblock 181 193 353 minecraft:dark_prismarine
fill 181 193 354 181 196 354 minecraft:blue_terracotta
fill 181 193 356 181 194 356 minecraft:blue_terracotta
setblock 182 193 327 minecraft:dark_prismarine
fill 182 193 328 182 196 328 minecraft:blue_terracotta
setblock 182 193 332 minecraft:dark_prismarine
fill 182 193 333 183 196 333 minecraft:blue_terracotta
setblock 182 193 336 minecraft:blue_terracotta
setblock 182 193 337 minecraft:dark_prismarine
fill 182 193 338 182 196 338 minecraft:blue_terracotta
setblock 182 193 342 minecraft:dark_prismarine
fill 182 193 343 182 196 343 minecraft:blue_terracotta
setblock 182 193 347 minecraft:dark_prismarine
fill 182 193 348 182 196 348 minecraft:blue_terracotta
setblock 182 193 352 minecraft:dark_prismarine
fill 182 193 353 182 196 353 minecraft:blue_terracotta
setblock 182 193 357 minecraft:dark_prismarine
fill 182 193 358 182 195 359 minecraft:blue_terracotta
fill 141 194 347 142 194 347 minecraft:blue_terracotta
fill 141 194 356 141 220 356 minecraft:blue_terracotta
fill 142 194 323 142 194 325 minecraft:blue_terracotta
setblock 142 194 326 minecraft:dark_prismarine
fill 142 194 327 142 197 327 minecraft:blue_terracotta
setblock 142 194 331 minecraft:dark_prismarine
fill 142 194 332 142 197 332 minecraft:blue_terracotta
setblock 142 194 336 minecraft:dark_prismarine
fill 142 194 337 142 194 340 minecraft:blue_terracotta
setblock 142 194 341 minecraft:dark_prismarine
fill 142 194 342 142 197 342 minecraft:blue_terracotta
setblock 142 194 346 minecraft:dark_prismarine
setblock 142 194 351 minecraft:dark_prismarine
fill 142 194 352 142 197 352 minecraft:blue_terracotta
setblock 142 194 356 minecraft:dark_prismarine
fill 142 194 357 142 197 357 minecraft:blue_terracotta
setblock 142 194 360 minecraft:blue_terracotta
setblock 142 194 361 minecraft:dark_prismarine
fill 142 194 362 142 196 363 minecraft:blue_terracotta
fill 143 194 323 143 194 324 minecraft:blue_terracotta
setblock 143 194 325 minecraft:dark_prismarine
fill 143 194 326 143 197 326 minecraft:blue_terracotta
setblock 143 194 330 minecraft:dark_prismarine
fill 143 194 331 143 197 331 minecraft:blue_terracotta
setblock 143 194 335 minecraft:dark_prismarine
fill 143 194 336 143 197 336 minecraft:blue_terracotta
setblock 143 194 340 minecraft:dark_prismarine
setblock 143 194 350 minecraft:dark_prismarine
fill 143 194 351 143 195 351 minecraft:blue_terracotta
setblock 143 194 355 minecraft:dark_prismarine
fill 143 194 356 144 196 356 minecraft:blue_terracotta
setblock 143 194 359 minecraft:blue_terracotta
setblock 143 194 360 minecraft:dark_prismarine
fill 143 194 363 144 194 363 minecraft:blue_terracotta
setblock 144 194 323 minecraft:blue_terracotta
setblock 144 194 324 minecraft:dark_prismarine
fill 144 194 325 147 194 325 minecraft:blue_terracotta
setblock 144 194 329 minecraft:dark_prismarine
fill 144 194 330 144 197 330 minecraft:blue_terracotta
setblock 144 194 334 minecraft:dark_prismarine
fill 144 194 335 144 197 335 minecraft:blue_terracotta
setblock 144 194 338 minecraft:blue_terracotta
setblock 144 194 354 minecraft:dark_prismarine
fill 144 194 355 144 195 355 minecraft:blue_terracotta
fill 144 194 362 145 194 362 minecraft:blue_terracotta
setblock 145 194 323 minecraft:dark_prismarine
fill 145 194 324 148 194 324 minecraft:blue_terracotta
setblock 145 194 328 minecraft:dark_prismarine
fill 145 194 329 145 195 329 minecraft:blue_terracotta
setblock 145 194 333 minecraft:dark_prismarine
fill 145 194 334 145 196 334 minecraft:blue_terracotta
setblock 145 194 363 minecraft:dark_prismarine
fill 146 194 322 146 197 323 minecraft:blue_terracotta
setblock 146 194 362 minecraft:dark_prismarine
fill 146 194 363 146 197 363 minecraft:blue_terracotta
fill 147 194 362 147 197 362 minecraft:blue_terracotta
fill 148 194 323 149 194 323 minecraft:blue_terracotta
setblock 148 194 325 minecraft:dark_prismarine
setblock 149 194 324 minecraft:dark_prismarine
setblock 150 194 323 minecraft:dark_prismarine
setblock 150 194 324 minecraft:blue_terracotta
setblock 150 194 363 minecraft:dark_prismarine
fill 151 194 323 153 194 323 minecraft:blue_terracotta
fill 151 194 363 151 197 363 minecraft:blue_terracotta
fill 155 194 332 155 221 332 minecraft:magenta_terracotta
setblock 155 194 363 minecraft:dark_prismarine
fill 156 194 363 159 194 363 minecraft:blue_terracotta
setblock 160 194 362 minecraft:blue_terracotta
setblock 160 194 363 minecraft:dark_prismarine
setblock 161 194 362 minecraft:dark_prismarine
fill 161 194 363 164 194 363 minecraft:blue_terracotta
fill 162 194 323 164 194 323 minecraft:blue_terracotta
fill 162 194 362 162 197 362 minecraft:blue_terracotta
fill 163 194 361 163 197 361 minecraft:blue_terracotta
setblock 165 194 323 minecraft:dark_prismarine
fill 165 194 361 166 194 361 minecraft:blue_terracotta
setblock 165 194 363 minecraft:dark_prismarine
setblock 166 194 323 minecraft:blue_terracotta
setblock 166 194 362 minecraft:dark_prismarine
fill 166 194 363 166 197 363 minecraft:blue_terracotta
setblock 167 194 361 minecraft:dark_prismarine
fill 167 194 362 167 196 362 minecraft:blue_terracotta
setblock 170 194 363 minecraft:dark_prismarine
fill 178 194 335 178 195 335 minecraft:black_concrete
setblock 180 194 332 minecraft:blue_terracotta
setblock 180 194 333 minecraft:dark_prismarine
fill 180 194 334 180 197 334 minecraft:blue_terracotta
fill 180 194 336 181 194 336 minecraft:blue_terracotta
setblock 180 194 363 minecraft:purple_concrete
setblock 181 194 327 minecraft:dark_prismarine
fill 181 194 328 181 197 328 minecraft:blue_terracotta
setblock 181 194 332 minecraft:dark_prismarine
fill 181 194 333 181 197 333 minecraft:blue_terracotta
setblock 181 194 337 minecraft:dark_prismarine
fill 181 194 338 181 194 341 minecraft:blue_terracotta
setblock 181 194 348 minecraft:blue_terracotta
setblock 181 194 352 minecraft:dark_prismarine
fill 181 194 353 181 196 353 minecraft:blue_terracotta
fill 182 194 323 182 196 323 minecraft:blue_terracotta
setblock 182 194 326 minecraft:dark_prismarine
fill 182 194 327 182 197 327 minecraft:blue_terracotta
setblock 182 194 331 minecraft:dark_prismarine
fill 182 194 332 182 197 332 minecraft:blue_terracotta
setblock 182 194 336 minecraft:dark_prismarine
fill 182 194 337 182 197 337 minecraft:blue_terracotta
fill 182 194 339 182 194 340 minecraft:blue_terracotta
setblock 182 194 341 minecraft:dark_prismarine
fill 182 194 342 182 197 342 minecraft:blue_terracotta
setblock 182 194 346 minecraft:dark_prismarine
fill 182 194 347 182 197 347 minecraft:blue_terracotta
setblock 182 194 351 minecraft:dark_prismarine
fill 182 194 352 182 197 352 minecraft:blue_terracotta
setblock 182 194 356 minecraft:dark_prismarine
fill 182 194 357 182 197 357 minecraft:blue_terracotta
setblock 182 194 360 minecraft:blue_terracotta
setblock 183 194 356 minecraft:cyan_concrete
fill 141 195 323 143 195 323 minecraft:blue_terracotta
setblock 141 195 324 minecraft:light_blue_wool
fill 141 195 325 141 220 325 minecraft:blue_terracotta
fill 141 195 347 141 220 347 minecraft:blue_terracotta
setblock 142 195 324 minecraft:blue_terracotta
setblock 142 195 325 minecraft:dark_prismarine
fill 142 195 326 142 198 326 minecraft:blue_terracotta
setblock 142 195 330 minecraft:dark_prismarine
fill 142 195 331 142 198 331 minecraft:blue_terracotta
setblock 142 195 335 minecraft:dark_prismarine
fill 142 195 336 142 195 339 minecraft:blue_terracotta
setblock 142 195 340 minecraft:dark_prismarine
fill 142 195 341 142 198 341 minecraft:blue_terracotta
setblock 142 195 344 minecraft:purple_concrete
setblock 142 195 350 minecraft:dark_prismarine
fill 142 195 351 142 197 351 minecraft:blue_terracotta
setblock 142 195 355 minecraft:dark_prismarine
fill 142 195 356 142 198 356 minecraft:blue_terracotta
setblock 142 195 360 minecraft:dark_prismarine
fill 142 195 361 143 197 361 minecraft:blue_terracotta
setblock 143 195 324 minecraft:dark_prismarine
fill 143 195 325 146 195 325 minecraft:blue_terracotta
setblock 143 195 329 minecraft:dark_prismarine
fill 143 195 330 143 198 330 minecraft:blue_terracotta
setblock 143 195 334 minecraft:dark_prismarine
fill 143 195 335 143 198 335 minecraft:blue_terracotta
setblock 143 195 338 minecraft:blue_terracotta
setblock 143 195 339 minecraft:dark_prismarine
fill 143 195 340 143 198 340 minecraft:blue_terracotta
setblock 143 195 354 minecraft:dark_prismarine
fill 143 195 355 143 198 355 minecraft:blue_terracotta
setblock 143 195 359 minecraft:dark_prismarine
fill 143 195 360 143 198 360 minecraft:blue_terracotta
setblock 143 195 363 minecraft:blue_terracotta
setblock 144 195 323 minecraft:dark_prismarine
fill 144 195 324 147 195 324 minecraft:blue_terracotta
setblock 144 195 328 minecraft:dark_prismarine
fill 144 195 329 144 197 329 minecraft:blue_terracotta
setblock 144 195 333 minecraft:dark_prismarine
fill 144 195 334 144 198 334 minecraft:blue_terracotta
setblock 144 195 338 minecraft:dark_prismarine
setblock 144 195 357 minecraft:blue_terracotta
setblock 144 195 362 minecraft:blue_terracotta
setblock 144 195 363 minecraft:dark_prismarine
fill 145 195 323 145 198 323 minecraft:blue_terracotta
setblock 145 195 328 minecraft:blue_terracotta
setblock 145 195 332 minecraft:dark_prismarine
fill 145 195 333 145 196 333 minecraft:blue_terracotta
setblock 145 195 362 minecraft:dark_prismarine
fill 145 195 363 145 198 363 minecraft:blue_terracotta
fill 146 195 362 146 198 362 minecraft:blue_terracotta
setblock 147 195 325 minecraft:dark_prismarine
setblock 148 195 323 minecraft:blue_terracotta
setblock 148 195 324 minecraft:dark_prismarine
setblock 149 195 323 minecraft:dark_prismarine
setblock 149 195 324 minecraft:blue_terracotta
setblock 149 195 363 minecraft:dark_prismarine
fill 150 195 323 152 195 323 minecraft:blue_terracotta
setblock 150 195 362 minecraft:dark_prismarine
fill 150 195 363 150 198 363 minecraft:blue_terracotta
setblock 154 195 363 minecraft:dark_prismarine
fill 155 195 333 155 196 333 minecraft:magenta_terracotta
fill 155 195 363 158 195 363 minecraft:blue_terracotta
setblock 157 195 323 minecraft:purple_concrete
setblock 159 195 363 minecraft:dark_prismarine
setblock 160 195 362 minecraft:dark_prismarine
fill 160 195 363 163 195 363 minecraft:blue_terracotta
fill 161 195 362 161 198 362 minecraft:blue_terracotta
fill 162 195 361 162 198 361 minecraft:blue_terracotta
setblock 163 195 323 minecraft:blue_terracotta
setblock 164 195 323 minecraft:dark_prismarine
setblock 164 195 363 minecraft:dark_prismarine
setblock 165 195 323 minecraft:blue_terracotta
setblock 165 195 361 minecraft:blue_terracotta
setblock 165 195 362 minecraft:dark_prismarine
fill 165 195 363 165 198 363 minecraft:blue_terracotta
setblock 166 195 361 minecraft:dark_prismarine
fill 166 195 362 166 198 362 minecraft:blue_terracotta
setblock 169 195 363 minecraft:dark_prismarine
setblock 176 195 323 minecraft:purple_concrete
setblock 180 195 332 minecraft:dark_prismarine
fill 180 195 333 180 198 333 minecraft:blue_terracotta
setblock 180 195 336 minecraft:blue_terracotta
setblock 180 195 337 minecraft:dark_prismarine
setblock 181 195 331 minecraft:dark_prismarine
fill 181 195 332 181 198 332 minecraft:blue_terracotta
setblock 181 195 336 minecraft:dark_prismarine
fill 181 195 337 181 195 340 minecraft:blue_terracotta
setblock 181 195 341 minecraft:dark_prismarine
fill 181 195 342 181 198 342 minecraft:blue_terracotta
setblock 181 195 351 minecraft:dark_prismarine
fill 181 195 352 181 196 352 minecraft:blue_terracotta
setblock 181 195 356 minecraft:dark_prismarine
setblock 182 195 325 minecraft:dark_prismarine
fill 182 195 326 182 198 326 minecraft:blue_terracotta
setblock 182 195 330 minecraft:dark_prismarine
fill 182 195 331 182 198 331 minecraft:blue_terracotta
setblock 182 195 335 minecraft:dark_prismarine
fill 182 195 336 182 198 336 minecraft:blue_terracotta
setblock 182 195 339 minecraft:blue_terracotta
setblock 182 195 340 minecraft:dark_prismarine
fill 182 195 341 182 198 341 minecraft:blue_terracotta
setblock 182 195 345 minecraft:dark_prismarine
fill 182 195 346 182 198 346 minecraft:blue_terracotta
setblock 182 195 350 minecraft:dark_prismarine
fill 182 195 351 182 198 351 minecraft:blue_terracotta
setblock 182 195 355 minecraft:dark_prismarine
fill 182 195 356 183 198 356 minecraft:blue_terracotta
setblock 182 195 360 minecraft:dark_prismarine
setblock 182 195 361 minecraft:purple_concrete
setblock 183 195 344 minecraft:cyan_concrete
fill 141 196 323 141 218 324 minecraft:blue_terracotta
setblock 142 196 323 minecraft:blue_terracotta
setblock 142 196 324 minecraft:dark_prismarine
fill 142 196 325 143 198 325 minecraft:blue_terracotta
setblock 142 196 329 minecraft:dark_prismarine
fill 142 196 330 142 199 330 minecraft:blue_terracotta
setblock 142 196 334 minecraft:dark_prismarine
fill 142 196 335 142 196 338 minecraft:blue_terracotta
setblock 142 196 339 minecraft:dark_prismarine
fill 142 196 340 142 199 340 minecraft:blue_terracotta
setblock 142 196 349 minecraft:dark_prismarine
setblock 142 196 350 minecraft:blue_terracotta
setblock 142 196 354 minecraft:dark_prismarine
fill 142 196 355 142 199 355 minecraft:blue_terracotta
setblock 142 196 358 minecraft:blue_terracotta
setblock 142 196 359 minecraft:dark_prismarine
fill 142 196 360 142 199 360 minecraft:blue_terracotta
setblock 143 196 323 minecraft:dark_prismarine
fill 143 196 324 146 196 324 minecraft:blue_terracotta
setblock 143 196 328 minecraft:dark_prismarine
fill 143 196 329 143 199 329 minecraft:blue_terracotta
setblock 143 196 333 minecraft:dark_prismarine
fill 143 196 334 143 199 334 minecraft:blue_terracotta
setblock 143 196 338 minecraft:dark_prismarine
fill 143 196 339 143 199 339 minecraft:blue_terracotta
setblock 143 196 353 minecraft:dark_prismarine
fill 143 196 354 143 198 354 minecraft:blue_terracotta
setblock 143 196 358 minecraft:dark_prismarine
fill 143 196 359 143 199 359 minecraft:blue_terracotta
setblock 143 196 362 minecraft:blue_terracotta
setblock 143 196 363 minecraft:dark_prismarine
fill 144 196 323 144 199 323 minecraft:blue_terracotta
setblock 144 196 327 minecraft:dark_prismarine
fill 144 196 328 144 197 328 minecraft:blue_terracotta
setblock 144 196 332 minecraft:dark_prismarine
fill 144 196 333 144 199 333 minecraft:blue_terracotta
setblock 144 196 337 minecraft:dark_prismarine
setblock 144 196 338 minecraft:blue_terracotta
setblock 144 196 357 minecraft:dark_prismarine
setblock 144 196 362 minecraft:dark_prismarine
fill 144 196 363 144 199 363 minecraft:blue_terracotta
setblock 145 196 331 minecraft:dark_prismarine
setblock 145 196 332 minecraft:blue_terracotta
fill 145 196 362 145 199 362 minecraft:blue_terracotta
setblock 147 196 324 minecraft:dark_prismarine
setblock 148 196 323 minecraft:dark_prismarine
setblock 148 196 324 minecraft:blue_terracotta
setblock 148 196 363 minecraft:dark_prismarine
fill 149 196 323 150 196 323 minecraft:blue_terracotta
setblock 149 196 362 minecraft:dark_prismarine
fill 149 196 363 149 199 363 minecraft:blue_terracotta
setblock 151 196 323 minecraft:purple_concrete
setblock 153 196 363 minecraft:dark_prismarine
fill 154 196 331 154 211 331 minecraft:magenta_terracotta
fill 154 196 363 154 197 363 minecraft:purple_concrete
fill 156 196 363 157 196 363 minecraft:blue_terracotta
setblock 158 196 363 minecraft:dark_prismarine
setblock 159 196 362 minecraft:dark_prismarine
fill 159 196 363 162 196 363 minecraft:blue_terracotta
fill 160 196 362 160 199 362 minecraft:blue_terracotta
setblock 163 196 363 minecraft:dark_prismarine
setblock 164 196 362 minecraft:dark_prismarine
fill 164 196 363 164 199 363 minecraft:blue_terracotta
setblock 165 196 361 minecraft:dark_prismarine
fill 165 196 362 165 199 362 minecraft:blue_terracotta
setblock 168 196 363 minecraft:dark_prismarine
setblock 170 196 323 minecraft:purple_concrete
setblock 173 196 363 minecraft:purple_concrete
setblock 180 196 331 minecraft:dark_prismarine
fill 180 196 332 180 199 332 minecraft:blue_terracotta
setblock 180 196 336 minecraft:dark_prismarine
fill 180 196 337 181 197 338 minecraft:blue_terracotta
setblock 181 196 330 minecraft:dark_prismarine
fill 181 196 331 181 199 331 minecraft:blue_terracotta
setblock 181 196 335 minecraft:dark_prismarine
fill 181 196 336 181 199 336 minecraft:blue_terracotta
setblock 181 196 339 minecraft:blue_terracotta
setblock 181 196 340 minecraft:dark_prismarine
fill 181 196 341 181 199 341 minecraft:blue_terracotta
setblock 181 196 355 minecraft:dark_prismarine
fill 181 196 356 181 196 357 minecraft:blue_terracotta
setblock 182 196 324 minecraft:dark_prismarine
fill 182 196 325 182 199 325 minecraft:blue_terracotta
setblock 182 196 329 minecraft:dark_prismarine
fill 182 196 330 182 199 330 minecraft:blue_terracotta
setblock 182 196 334 minecraft:dark_prismarine
fill 182 196 335 182 199 335 minecraft:blue_terracotta
setblock 182 196 339 minecraft:dark_prismarine
fill 182 196 340 182 199 340 minecraft:blue_terracotta
setblock 182 196 344 minecraft:dark_prismarine
fill 182 196 345 182 199 345 minecraft:blue_terracotta
setblock 182 196 349 minecraft:dark_prismarine
fill 182 196 350 182 198 350 minecraft:blue_terracotta
setblock 182 196 354 minecraft:dark_prismarine
fill 182 196 355 182 199 355 minecraft:blue_terracotta
setblock 182 196 358 minecraft:blue_terracotta
setblock 182 196 359 minecraft:dark_prismarine
fill 182 196 360 182 198 361 minecraft:blue_terracotta
fill 183 196 344 183 216 344 minecraft:blue_terracotta
setblock 142 197 323 minecraft:dark_prismarine
fill 142 197 324 145 197 324 minecraft:blue_terracotta
setblock 142 197 328 minecraft:dark_prismarine
fill 142 197 329 142 200 329 minecraft:blue_terracotta
setblock 142 197 333 minecraft:dark_prismarine
fill 142 197 334 142 197 337 minecraft:blue_terracotta
setblock 142 197 338 minecraft:dark_prismarine
fill 142 197 339 142 200 339 minecraft:blue_terracotta
setblock 142 197 353 minecraft:dark_prismarine
fill 142 197 354 142 200 354 minecraft:blue_terracotta
setblock 142 197 358 minecraft:dark_prismarine
fill 142 197 359 142 200 359 minecraft:blue_terracotta
setblock 142 197 362 minecraft:blue_terracotta
setblock 142 197 363 minecraft:dark_prismarine
fill 143 197 323 143 200 323 minecraft:blue_terracotta
setblock 143 197 327 minecraft:dark_prismarine
fill 143 197 328 143 200 328 minecraft:blue_terracotta
setblock 143 197 332 minecraft:dark_prismarine
fill 143 197 333 143 200 333 minecraft:blue_terracotta
setblock 143 197 337 minecraft:dark_prismarine
fill 143 197 338 143 200 338 minecraft:blue_terracotta
setblock 143 197 353 minecraft:blue_terracotta
setblock 143 197 356 minecraft:blue_terracotta
setblock 143 197 357 minecraft:dark_prismarine
fill 143 197 358 143 200 358 minecraft:blue_terracotta
setblock 143 197 362 minecraft:dark_prismarine
fill 143 197 363 143 200 363 minecraft:blue_terracotta
setblock 144 197 325 minecraft:light[level=13]
setblock 144 197 331 minecraft:dark_prismarine
fill 144 197 332 144 199 332 minecraft:blue_terracotta
setblock 144 197 336 minecraft:dark_prismarine
fill 144 197 337 144 198 337 minecraft:blue_terracotta
setblock 144 197 339 minecraft:light[level=12]
setblock 144 197 341 minecraft:light[level=13]
setblock 144 197 346 minecraft:light[level=12]
setblock 144 197 349 minecraft:light[level=13]
setblock 144 197 353 minecraft:light[level=12]
setblock 144 197 357 minecraft:light[level=13]
setblock 144 197 360 minecraft:light[level=12]
fill 144 197 362 144 200 362 minecraft:blue_terracotta
setblock 146 197 324 minecraft:dark_prismarine
fill 147 197 322 147 220 322 minecraft:blue_terracotta
setblock 147 197 323 minecraft:dark_prismarine
fill 147 197 328 147 202 328 minecraft:iron_bars
setblock 147 197 363 minecraft:dark_prismarine
fill 148 197 323 149 197 323 minecraft:blue_terracotta
setblock 148 197 362 minecraft:dark_prismarine
fill 148 197 363 148 200 363 minecraft:blue_terracotta
setblock 151 197 325 minecraft:light[level=12]
setblock 151 197 332 minecraft:light[level=12]
setblock 151 197 339 minecraft:light[level=12]
setblock 151 197 346 minecraft:light[level=12]
setblock 151 197 353 minecraft:light[level=12]
setblock 151 197 360 minecraft:light[level=12]
setblock 152 197 325 minecraft:light[level=13]
setblock 152 197 333 minecraft:light[level=13]
setblock 152 197 341 minecraft:light[level=13]
setblock 152 197 349 minecraft:light[level=13]
setblock 152 197 357 minecraft:light[level=13]
setblock 152 197 363 minecraft:dark_prismarine
setblock 156 197 363 minecraft:blue_terracotta
setblock 157 197 363 minecraft:dark_prismarine
setblock 158 197 325 minecraft:light[level=12]
setblock 158 197 332 minecraft:light[level=12]
setblock 158 197 339 minecraft:light[level=12]
setblock 158 197 346 minecraft:light[level=12]
setblock 158 197 353 minecraft:light[level=12]
setblock 158 197 360 minecraft:light[level=12]
fill 158 197 363 161 197 363 minecraft:blue_terracotta
fill 159 197 362 159 200 362 minecraft:blue_terracotta
setblock 160 197 325 minecraft:light[level=13]
setblock 160 197 333 minecraft:light[level=13]
setblock 160 197 349 minecraft:light[level=13]
setblock 160 197 357 minecraft:light[level=13]
fill 161 197 361 161 199 361 minecraft:blue_terracotta
setblock 162 197 363 minecraft:dark_prismarine
setblock 163 197 362 minecraft:dark_prismarine
fill 163 197 363 163 200 363 minecraft:blue_terracotta
setblock 164 197 323 minecraft:purple_concrete
setblock 164 197 361 minecraft:dark_prismarine
fill 164 197 362 164 200 362 minecraft:blue_terracotta
setblock 165 197 325 minecraft:light[level=12]
setblock 165 197 332 minecraft:light[level=12]
setblock 165 197 339 minecraft:light[level=12]
setblock 165 197 346 minecraft:light[level=12]
setblock 165 197 353 minecraft:light[level=12]
setblock 165 197 360 minecraft:light[level=12]
setblock 165 197 361 minecraft:blue_terracotta
setblock 167 197 363 minecraft:dark_prismarine
setblock 168 197 325 minecraft:light[level=13]
setblock 168 197 333 minecraft:light[level=13]
setblock 168 197 341 minecraft:light[level=13]
setblock 168 197 349 minecraft:light[level=13]
setblock 168 197 357 minecraft:light[level=13]
setblock 168 197 363 minecraft:blue_terracotta
fill 169 197 347 169 198 347 minecraft:black_concrete
setblock 172 197 325 minecraft:light[level=12]
setblock 172 197 332 minecraft:light[level=12]
setblock 172 197 339 minecraft:light[level=12]
setblock 172 197 346 minecraft:light[level=12]
setblock 172 197 353 minecraft:light[level=12]
setblock 172 197 360 minecraft:light[level=12]
setblock 176 197 325 minecraft:light[level=13]
schedule function dropper:buildpart/75_10 1t
