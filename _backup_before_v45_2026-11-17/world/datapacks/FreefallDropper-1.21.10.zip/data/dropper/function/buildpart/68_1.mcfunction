setblock 392 91 276 minecraft:red_terracotta
setblock 393 91 276 minecraft:stripped_oak_log
fill 394 91 276 397 91 276 minecraft:red_terracotta
setblock 395 91 278 minecraft:red_terracotta
setblock 396 91 278 minecraft:stripped_oak_log
setblock 397 91 277 minecraft:stripped_oak_log
fill 397 91 278 397 93 279 minecraft:red_terracotta
setblock 397 91 316 minecraft:red_terracotta
setblock 398 91 276 minecraft:stripped_oak_log
fill 398 91 277 398 94 277 minecraft:red_terracotta
setblock 398 91 316 minecraft:stripped_oak_log
fill 399 91 276 399 94 276 minecraft:red_terracotta
fill 399 91 316 402 91 316 minecraft:red_terracotta
setblock 400 91 279 minecraft:stripped_oak_log
setblock 401 91 278 minecraft:stripped_oak_log
fill 401 91 279 401 94 279 minecraft:red_terracotta
setblock 402 91 277 minecraft:stripped_oak_log
fill 402 91 278 402 94 278 minecraft:red_terracotta
setblock 403 91 276 minecraft:stripped_oak_log
fill 403 91 277 406 91 277 minecraft:red_terracotta
setblock 403 91 316 minecraft:stripped_oak_log
fill 404 91 276 404 94 276 minecraft:red_terracotta
fill 404 91 316 404 94 316 minecraft:red_terracotta
setblock 407 91 277 minecraft:stripped_oak_log
setblock 408 91 276 minecraft:stripped_oak_log
fill 408 91 303 408 99 304 minecraft:brown_terracotta
fill 409 91 276 409 94 276 minecraft:red_terracotta
setblock 411 91 304 minecraft:shroomlight
setblock 411 91 306 minecraft:shroomlight
setblock 411 91 308 minecraft:shroomlight
setblock 411 91 310 minecraft:shroomlight
setblock 411 91 312 minecraft:shroomlight
setblock 411 91 314 minecraft:shroomlight
setblock 412 91 305 minecraft:shroomlight
setblock 412 91 307 minecraft:shroomlight
setblock 412 91 309 minecraft:shroomlight
setblock 412 91 311 minecraft:shroomlight
setblock 412 91 313 minecraft:shroomlight
setblock 413 91 276 minecraft:stripped_oak_log
setblock 413 91 304 minecraft:shroomlight
setblock 413 91 306 minecraft:shroomlight
setblock 413 91 308 minecraft:shroomlight
setblock 413 91 310 minecraft:shroomlight
setblock 413 91 312 minecraft:shroomlight
setblock 413 91 314 minecraft:shroomlight
setblock 413 91 316 minecraft:stripped_oak_log
fill 414 91 276 414 94 276 minecraft:red_terracotta
setblock 414 91 305 minecraft:shroomlight
setblock 414 91 307 minecraft:shroomlight
setblock 414 91 309 minecraft:shroomlight
setblock 414 91 311 minecraft:shroomlight
setblock 414 91 313 minecraft:shroomlight
fill 414 91 316 414 94 316 minecraft:red_terracotta
setblock 415 91 304 minecraft:shroomlight
setblock 415 91 306 minecraft:shroomlight
setblock 415 91 308 minecraft:shroomlight
setblock 415 91 310 minecraft:shroomlight
setblock 415 91 312 minecraft:shroomlight
setblock 415 91 314 minecraft:shroomlight
setblock 416 91 278 minecraft:stripped_oak_log
fill 416 91 279 416 92 281 minecraft:red_terracotta
setblock 416 91 298 minecraft:stripped_oak_log
fill 416 91 299 416 94 299 minecraft:red_terracotta
fill 416 91 301 416 91 302 minecraft:red_terracotta
setblock 416 91 303 minecraft:stripped_oak_log
fill 416 91 304 416 94 304 minecraft:red_terracotta
setblock 416 91 305 minecraft:shroomlight
fill 416 91 306 416 92 306 minecraft:red_terracotta
setblock 416 91 307 minecraft:shroomlight
setblock 416 91 309 minecraft:shroomlight
setblock 416 91 311 minecraft:shroomlight
setblock 416 91 313 minecraft:shroomlight
setblock 417 91 277 minecraft:stripped_oak_log
fill 417 91 278 417 94 278 minecraft:red_terracotta
fill 417 91 281 418 91 281 minecraft:red_terracotta
setblock 417 91 282 minecraft:stripped_oak_log
fill 417 91 283 417 93 284 minecraft:red_terracotta
setblock 417 91 297 minecraft:stripped_oak_log
fill 417 91 298 417 94 298 minecraft:red_terracotta
setblock 417 91 302 minecraft:stripped_oak_log
fill 417 91 303 417 94 303 minecraft:red_terracotta
setblock 417 91 304 minecraft:shroomlight
fill 417 91 305 417 92 305 minecraft:red_terracotta
setblock 417 91 306 minecraft:shroomlight
setblock 417 91 307 minecraft:stripped_oak_log
setblock 417 91 308 minecraft:shroomlight
setblock 417 91 310 minecraft:shroomlight
setblock 417 91 312 minecraft:shroomlight
fill 417 91 313 417 94 313 minecraft:red_terracotta
setblock 417 91 314 minecraft:shroomlight
setblock 418 91 282 minecraft:red_terracotta
fill 376 92 275 376 95 317 minecraft:yellow_terracotta
fill 377 92 275 418 95 275 minecraft:yellow_terracotta
setblock 377 92 276 minecraft:stripped_oak_log
fill 377 92 277 377 95 277 minecraft:red_terracotta
setblock 377 92 281 minecraft:stripped_oak_log
fill 377 92 282 377 95 282 minecraft:red_terracotta
setblock 377 92 285 minecraft:red_terracotta
setblock 377 92 286 minecraft:stripped_oak_log
fill 377 92 287 377 92 290 minecraft:red_terracotta
setblock 377 92 291 minecraft:stripped_oak_log
fill 377 92 292 377 92 295 minecraft:red_terracotta
setblock 377 92 296 minecraft:stripped_oak_log
fill 377 92 297 377 92 300 minecraft:red_terracotta
setblock 377 92 301 minecraft:stripped_oak_log
fill 377 92 302 377 92 305 minecraft:red_terracotta
setblock 377 92 306 minecraft:stripped_oak_log
fill 377 92 307 377 95 307 minecraft:red_terracotta
setblock 377 92 311 minecraft:stripped_oak_log
fill 377 92 312 377 95 312 minecraft:red_terracotta
setblock 377 92 316 minecraft:stripped_oak_log
fill 377 92 317 418 95 317 minecraft:yellow_terracotta
fill 378 92 276 378 95 276 minecraft:red_terracotta
setblock 378 92 280 minecraft:stripped_oak_log
fill 378 92 281 378 95 281 minecraft:red_terracotta
fill 378 92 283 378 92 284 minecraft:red_terracotta
setblock 378 92 285 minecraft:stripped_oak_log
fill 378 92 293 378 93 293 minecraft:red_terracotta
setblock 378 92 295 minecraft:stripped_oak_log
fill 378 92 296 378 95 296 minecraft:red_terracotta
setblock 378 92 300 minecraft:stripped_oak_log
fill 378 92 301 378 95 301 minecraft:red_terracotta
setblock 378 92 305 minecraft:stripped_oak_log
fill 378 92 306 378 95 306 minecraft:red_terracotta
setblock 378 92 310 minecraft:stripped_oak_log
fill 378 92 316 378 95 316 minecraft:red_terracotta
setblock 379 92 299 minecraft:stripped_oak_log
fill 379 92 300 379 95 300 minecraft:red_terracotta
setblock 379 92 304 minecraft:stripped_oak_log
fill 379 92 305 379 95 305 minecraft:red_terracotta
fill 379 92 307 379 93 307 minecraft:red_terracotta
fill 380 92 299 380 93 299 minecraft:red_terracotta
setblock 380 92 303 minecraft:stripped_oak_log
fill 380 92 304 380 95 304 minecraft:red_terracotta
setblock 382 92 276 minecraft:stripped_oak_log
setblock 392 92 276 minecraft:stripped_oak_log
fill 393 92 276 393 94 277 minecraft:red_terracotta
fill 394 92 276 396 92 276 minecraft:red_terracotta
setblock 395 92 278 minecraft:stripped_oak_log
setblock 396 92 277 minecraft:stripped_oak_log
fill 396 92 278 396 94 279 minecraft:red_terracotta
setblock 397 92 276 minecraft:stripped_oak_log
fill 397 92 277 397 95 277 minecraft:red_terracotta
setblock 397 92 316 minecraft:stripped_oak_log
fill 398 92 276 398 95 276 minecraft:red_terracotta
fill 398 92 316 401 92 316 minecraft:red_terracotta
setblock 399 92 279 minecraft:stripped_oak_log
setblock 400 92 278 minecraft:stripped_oak_log
fill 400 92 279 400 95 279 minecraft:red_terracotta
setblock 401 92 277 minecraft:stripped_oak_log
fill 401 92 278 401 95 278 minecraft:red_terracotta
setblock 402 92 276 minecraft:stripped_oak_log
fill 402 92 277 405 92 277 minecraft:red_terracotta
setblock 402 92 316 minecraft:stripped_oak_log
fill 403 92 276 403 95 276 minecraft:red_terracotta
fill 403 92 316 403 95 316 minecraft:red_terracotta
setblock 406 92 277 minecraft:stripped_oak_log
setblock 407 92 276 minecraft:stripped_oak_log
fill 408 92 276 408 95 276 minecraft:red_terracotta
setblock 411 92 304 minecraft:stripped_oak_log
setblock 411 92 306 minecraft:stripped_oak_log
setblock 411 92 308 minecraft:stripped_oak_log
setblock 411 92 310 minecraft:stripped_oak_log
setblock 411 92 312 minecraft:stripped_oak_log
setblock 411 92 314 minecraft:stripped_oak_log
setblock 412 92 276 minecraft:stripped_oak_log
setblock 412 92 305 minecraft:stripped_oak_log
setblock 412 92 307 minecraft:stripped_oak_log
setblock 412 92 309 minecraft:stripped_oak_log
setblock 412 92 311 minecraft:stripped_oak_log
setblock 412 92 313 minecraft:stripped_oak_log
setblock 412 92 316 minecraft:stripped_oak_log
fill 413 92 276 413 95 276 minecraft:red_terracotta
setblock 413 92 304 minecraft:stripped_oak_log
setblock 413 92 306 minecraft:stripped_oak_log
setblock 413 92 308 minecraft:stripped_oak_log
setblock 413 92 310 minecraft:stripped_oak_log
setblock 413 92 312 minecraft:stripped_oak_log
setblock 413 92 314 minecraft:stripped_oak_log
fill 413 92 316 413 95 316 minecraft:red_terracotta
fill 414 92 277 414 93 277 minecraft:red_terracotta
setblock 414 92 305 minecraft:stripped_oak_log
setblock 414 92 307 minecraft:stripped_oak_log
setblock 414 92 309 minecraft:stripped_oak_log
setblock 414 92 311 minecraft:stripped_oak_log
setblock 414 92 313 minecraft:stripped_oak_log
setblock 415 92 302 minecraft:red_terracotta
setblock 415 92 303 minecraft:stripped_oak_log
fill 415 92 304 415 94 305 minecraft:red_terracotta
setblock 415 92 306 minecraft:stripped_oak_log
setblock 415 92 308 minecraft:stripped_oak_log
setblock 415 92 310 minecraft:stripped_oak_log
setblock 415 92 312 minecraft:stripped_oak_log
setblock 415 92 314 minecraft:stripped_oak_log
setblock 416 92 277 minecraft:stripped_oak_log
fill 416 92 278 416 95 278 minecraft:red_terracotta
setblock 416 92 282 minecraft:stripped_oak_log
fill 416 92 298 416 95 298 minecraft:red_terracotta
setblock 416 92 301 minecraft:red_terracotta
setblock 416 92 302 minecraft:stripped_oak_log
fill 416 92 303 416 95 303 minecraft:red_terracotta
fill 416 92 305 416 93 305 minecraft:red_terracotta
setblock 416 92 307 minecraft:stripped_oak_log
fill 416 92 308 416 92 311 minecraft:red_terracotta
setblock 416 92 313 minecraft:stripped_oak_log
fill 416 92 314 416 93 315 minecraft:red_terracotta
setblock 417 92 276 minecraft:stripped_oak_log
fill 417 92 277 417 95 277 minecraft:red_terracotta
setblock 417 92 281 minecraft:stripped_oak_log
fill 417 92 282 417 95 282 minecraft:red_terracotta
setblock 417 92 285 minecraft:red_terracotta
setblock 417 92 286 minecraft:stripped_oak_log
setblock 417 92 296 minecraft:stripped_oak_log
fill 417 92 297 417 95 297 minecraft:red_terracotta
setblock 417 92 301 minecraft:stripped_oak_log
fill 417 92 302 417 95 302 minecraft:red_terracotta
fill 417 92 304 417 93 304 minecraft:red_terracotta
setblock 417 92 306 minecraft:stripped_oak_log
fill 417 92 307 417 94 308 minecraft:red_terracotta
setblock 417 92 310 minecraft:red_terracotta
setblock 417 92 311 minecraft:stripped_oak_log
fill 417 92 312 417 95 312 minecraft:red_terracotta
fill 417 92 314 417 93 314 minecraft:red_terracotta
setblock 417 92 316 minecraft:stripped_oak_log
fill 418 92 276 418 95 316 minecraft:yellow_terracotta
fill 377 93 276 377 96 276 minecraft:red_terracotta
setblock 377 93 279 minecraft:red_terracotta
setblock 377 93 280 minecraft:stripped_oak_log
fill 377 93 281 377 96 281 minecraft:red_terracotta
setblock 377 93 285 minecraft:stripped_oak_log
fill 377 93 286 377 93 289 minecraft:red_terracotta
setblock 377 93 290 minecraft:stripped_oak_log
fill 377 93 291 377 93 294 minecraft:red_terracotta
setblock 377 93 295 minecraft:stripped_oak_log
fill 377 93 296 377 93 299 minecraft:red_terracotta
setblock 377 93 300 minecraft:stripped_oak_log
fill 377 93 301 377 93 304 minecraft:red_terracotta
setblock 377 93 305 minecraft:stripped_oak_log
fill 377 93 306 377 96 306 minecraft:red_terracotta
setblock 377 93 310 minecraft:stripped_oak_log
fill 377 93 311 378 95 311 minecraft:red_terracotta
setblock 377 93 315 minecraft:stripped_oak_log
fill 377 93 316 377 96 316 minecraft:red_terracotta
fill 378 93 277 378 94 277 minecraft:red_terracotta
setblock 378 93 279 minecraft:stripped_oak_log
fill 378 93 280 378 96 280 minecraft:red_terracotta
setblock 378 93 283 minecraft:red_terracotta
setblock 378 93 284 minecraft:stripped_oak_log
fill 378 93 285 378 93 288 minecraft:red_terracotta
setblock 378 93 289 minecraft:stripped_oak_log
fill 378 93 292 378 94 292 minecraft:red_terracotta
setblock 378 93 294 minecraft:stripped_oak_log
fill 378 93 295 378 96 295 minecraft:red_terracotta
setblock 378 93 299 minecraft:stripped_oak_log
fill 378 93 300 378 96 300 minecraft:red_terracotta
setblock 378 93 304 minecraft:stripped_oak_log
fill 378 93 305 378 96 305 minecraft:red_terracotta
setblock 378 93 309 minecraft:stripped_oak_log
fill 378 93 310 378 96 310 minecraft:red_terracotta
setblock 379 93 298 minecraft:stripped_oak_log
fill 379 93 299 379 96 299 minecraft:red_terracotta
setblock 379 93 303 minecraft:stripped_oak_log
fill 379 93 304 379 96 304 minecraft:red_terracotta
setblock 379 93 308 minecraft:stripped_oak_log
setblock 380 93 302 minecraft:stripped_oak_log
fill 380 93 303 380 96 303 minecraft:red_terracotta
fill 380 93 305 380 94 305 minecraft:red_terracotta
setblock 381 93 276 minecraft:stripped_oak_log
setblock 382 93 276 minecraft:red_terracotta
setblock 391 93 276 minecraft:stripped_oak_log
fill 392 93 276 392 95 277 minecraft:red_terracotta
fill 394 93 276 395 93 276 minecraft:red_terracotta
setblock 394 93 278 minecraft:stripped_oak_log
setblock 395 93 277 minecraft:stripped_oak_log
fill 395 93 278 395 95 279 minecraft:red_terracotta
setblock 396 93 276 minecraft:stripped_oak_log
fill 396 93 277 396 96 277 minecraft:red_terracotta
setblock 396 93 316 minecraft:stripped_oak_log
fill 397 93 276 397 96 276 minecraft:red_terracotta
fill 397 93 316 400 93 316 minecraft:red_terracotta
setblock 398 93 278 minecraft:red_terracotta
setblock 398 93 279 minecraft:stripped_oak_log
setblock 399 93 278 minecraft:stripped_oak_log
fill 399 93 279 399 96 279 minecraft:red_terracotta
setblock 400 93 277 minecraft:stripped_oak_log
fill 400 93 278 400 96 278 minecraft:red_terracotta
setblock 401 93 276 minecraft:stripped_oak_log
fill 401 93 277 404 93 277 minecraft:red_terracotta
setblock 401 93 316 minecraft:stripped_oak_log
fill 402 93 276 402 96 276 minecraft:red_terracotta
fill 402 93 316 402 96 316 minecraft:red_terracotta
setblock 405 93 277 minecraft:stripped_oak_log
setblock 406 93 276 minecraft:stripped_oak_log
setblock 406 93 277 minecraft:red_terracotta
fill 407 93 276 407 96 276 minecraft:red_terracotta
fill 407 93 303 407 99 304 minecraft:brown_terracotta
fill 408 93 305 408 99 305 minecraft:brown_terracotta
fill 409 93 303 409 99 304 minecraft:brown_terracotta
setblock 411 93 276 minecraft:stripped_oak_log
setblock 411 93 316 minecraft:stripped_oak_log
fill 412 93 276 412 96 276 minecraft:red_terracotta
fill 412 93 316 412 96 316 minecraft:red_terracotta
fill 414 93 294 414 94 294 minecraft:shroomlight
setblock 415 93 277 minecraft:stripped_oak_log
setblock 415 93 301 minecraft:red_terracotta
setblock 415 93 302 minecraft:stripped_oak_log
fill 415 93 303 415 96 303 minecraft:red_terracotta
setblock 415 93 306 minecraft:red_terracotta
fill 415 93 308 416 95 308 minecraft:red_terracotta
fill 415 93 315 415 94 315 minecraft:red_terracotta
setblock 416 93 276 minecraft:stripped_oak_log
fill 416 93 277 416 96 277 minecraft:red_terracotta
fill 416 93 279 416 93 280 minecraft:red_terracotta
setblock 416 93 281 minecraft:stripped_oak_log
fill 416 93 282 416 94 284 minecraft:red_terracotta
fill 416 93 297 416 96 297 minecraft:red_terracotta
setblock 416 93 301 minecraft:stripped_oak_log
fill 416 93 302 416 96 302 minecraft:red_terracotta
setblock 416 93 306 minecraft:stripped_oak_log
fill 416 93 307 416 96 307 minecraft:red_terracotta
fill 416 93 309 416 93 310 minecraft:red_terracotta
setblock 416 93 311 minecraft:stripped_oak_log
fill 416 93 312 416 95 313 minecraft:red_terracotta
setblock 416 93 316 minecraft:stripped_oak_log
fill 417 93 276 417 96 276 minecraft:red_terracotta
setblock 417 93 280 minecraft:stripped_oak_log
fill 417 93 281 417 96 281 minecraft:red_terracotta
setblock 417 93 285 minecraft:stripped_oak_log
fill 417 93 286 417 94 288 minecraft:red_terracotta
setblock 417 93 294 minecraft:red_terracotta
setblock 417 93 295 minecraft:stripped_oak_log
fill 417 93 296 417 96 296 minecraft:red_terracotta
setblock 417 93 300 minecraft:stripped_oak_log
fill 417 93 301 417 96 301 minecraft:red_terracotta
setblock 417 93 305 minecraft:stripped_oak_log
fill 417 93 306 417 96 306 minecraft:red_terracotta
setblock 417 93 310 minecraft:stripped_oak_log
fill 417 93 311 417 96 311 minecraft:red_terracotta
setblock 417 93 315 minecraft:stripped_oak_log
fill 417 93 316 417 96 316 minecraft:red_terracotta
setblock 377 94 279 minecraft:stripped_oak_log
fill 377 94 280 377 97 280 minecraft:red_terracotta
setblock 377 94 284 minecraft:stripped_oak_log
fill 377 94 285 377 94 288 minecraft:red_terracotta
setblock 377 94 289 minecraft:stripped_oak_log
fill 377 94 290 377 94 293 minecraft:red_terracotta
setblock 377 94 294 minecraft:stripped_oak_log
fill 377 94 295 377 94 298 minecraft:red_terracotta
setblock 377 94 299 minecraft:stripped_oak_log
fill 377 94 300 377 94 303 minecraft:red_terracotta
setblock 377 94 304 minecraft:stripped_oak_log
fill 377 94 305 377 97 305 minecraft:red_terracotta
setblock 377 94 309 minecraft:stripped_oak_log
fill 377 94 310 377 97 310 minecraft:red_terracotta
setblock 377 94 314 minecraft:stripped_oak_log
fill 377 94 315 377 97 315 minecraft:red_terracotta
setblock 378 94 278 minecraft:stripped_oak_log
fill 378 94 279 378 97 279 minecraft:red_terracotta
setblock 378 94 283 minecraft:stripped_oak_log
fill 378 94 284 378 94 287 minecraft:red_terracotta
setblock 378 94 288 minecraft:stripped_oak_log
fill 378 94 289 378 95 291 minecraft:red_terracotta
setblock 378 94 293 minecraft:stripped_oak_log
fill 378 94 294 378 97 294 minecraft:red_terracotta
setblock 378 94 298 minecraft:stripped_oak_log
fill 378 94 299 378 97 299 minecraft:red_terracotta
setblock 378 94 303 minecraft:stripped_oak_log
fill 378 94 304 378 97 304 minecraft:red_terracotta
setblock 378 94 308 minecraft:stripped_oak_log
fill 378 94 309 378 97 309 minecraft:red_terracotta
setblock 379 94 281 minecraft:red_terracotta
setblock 379 94 282 minecraft:stripped_oak_log
fill 379 94 283 379 94 286 minecraft:red_terracotta
setblock 379 94 297 minecraft:stripped_oak_log
fill 379 94 298 379 97 298 minecraft:red_terracotta
setblock 379 94 302 minecraft:stripped_oak_log
fill 379 94 303 379 97 303 minecraft:red_terracotta
setblock 379 94 307 minecraft:stripped_oak_log
fill 379 94 308 379 97 308 minecraft:red_terracotta
setblock 380 94 276 minecraft:stripped_oak_log
setblock 380 94 301 minecraft:stripped_oak_log
fill 380 94 302 380 96 302 minecraft:red_terracotta
fill 381 94 276 381 95 276 minecraft:red_terracotta
fill 391 94 276 391 97 276 minecraft:red_terracotta
setblock 393 94 278 minecraft:stripped_oak_log
setblock 394 94 276 minecraft:red_terracotta
setblock 394 94 277 minecraft:stripped_oak_log
fill 394 94 278 394 97 278 minecraft:red_terracotta
setblock 395 94 276 minecraft:stripped_oak_log
fill 395 94 277 395 97 277 minecraft:red_terracotta
setblock 395 94 316 minecraft:stripped_oak_log
fill 396 94 276 396 97 276 minecraft:red_terracotta
fill 396 94 316 399 94 316 minecraft:red_terracotta
setblock 397 94 278 minecraft:red_terracotta
setblock 397 94 279 minecraft:stripped_oak_log
setblock 398 94 278 minecraft:stripped_oak_log
fill 398 94 279 398 97 279 minecraft:red_terracotta
fill 398 94 280 398 97 280 minecraft:iron_bars
setblock 399 94 277 minecraft:stripped_oak_log
fill 399 94 278 399 97 278 minecraft:red_terracotta
setblock 400 94 276 minecraft:stripped_oak_log
fill 400 94 277 403 94 277 minecraft:red_terracotta
setblock 400 94 316 minecraft:stripped_oak_log
fill 401 94 276 401 97 276 minecraft:red_terracotta
fill 401 94 316 401 97 316 minecraft:red_terracotta
setblock 403 94 278 minecraft:stripped_oak_log
setblock 404 94 277 minecraft:stripped_oak_log
setblock 405 94 276 minecraft:stripped_oak_log
fill 405 94 277 405 95 277 minecraft:red_terracotta
fill 406 94 276 406 97 276 minecraft:red_terracotta
fill 407 94 302 409 99 302 minecraft:brown_terracotta
fill 407 94 305 407 99 305 minecraft:brown_terracotta
fill 409 94 305 409 99 305 minecraft:brown_terracotta
setblock 410 94 276 minecraft:stripped_oak_log
setblock 410 94 316 minecraft:stripped_oak_log
fill 411 94 276 411 97 276 minecraft:red_terracotta
fill 411 94 316 411 97 316 minecraft:red_terracotta
setblock 413 94 277 minecraft:red_terracotta
fill 413 94 285 415 94 287 minecraft:terracotta
setblock 414 94 277 minecraft:stripped_oak_log
fill 414 94 315 414 95 315 minecraft:red_terracotta
setblock 415 94 276 minecraft:stripped_oak_log
fill 415 94 277 415 97 277 minecraft:red_terracotta
setblock 415 94 300 minecraft:red_terracotta
setblock 415 94 301 minecraft:stripped_oak_log
fill 415 94 302 415 97 302 minecraft:red_terracotta
setblock 415 94 306 minecraft:stripped_oak_log
fill 415 94 307 415 97 307 minecraft:red_terracotta
fill 415 94 309 415 94 310 minecraft:red_terracotta
setblock 415 94 316 minecraft:stripped_oak_log
fill 416 94 276 416 97 276 minecraft:red_terracotta
setblock 416 94 279 minecraft:red_terracotta
setblock 416 94 280 minecraft:stripped_oak_log
fill 416 94 281 416 97 281 minecraft:red_terracotta
setblock 416 94 285 minecraft:stripped_oak_log
setblock 416 94 300 minecraft:stripped_oak_log
fill 416 94 301 416 97 301 minecraft:red_terracotta
setblock 416 94 305 minecraft:stripped_oak_log
fill 416 94 306 416 97 306 minecraft:red_terracotta
setblock 416 94 309 minecraft:red_terracotta
setblock 416 94 310 minecraft:stripped_oak_log
fill 416 94 311 416 97 311 minecraft:red_terracotta
setblock 416 94 314 minecraft:red_terracotta
setblock 416 94 315 minecraft:stripped_oak_log
fill 416 94 316 416 97 316 minecraft:red_terracotta
setblock 417 94 279 minecraft:stripped_oak_log
fill 417 94 280 417 97 280 minecraft:red_terracotta
setblock 417 94 283 minecraft:red_terracotta
setblock 417 94 284 minecraft:stripped_oak_log
fill 417 94 285 417 97 285 minecraft:red_terracotta
setblock 417 94 289 minecraft:stripped_oak_log
fill 417 94 290 417 94 293 minecraft:red_terracotta
setblock 417 94 294 minecraft:stripped_oak_log
fill 417 94 295 417 97 295 minecraft:red_terracotta
setblock 417 94 299 minecraft:stripped_oak_log
fill 417 94 300 417 97 300 minecraft:red_terracotta
setblock 417 94 304 minecraft:stripped_oak_log
fill 417 94 305 417 97 305 minecraft:red_terracotta
setblock 417 94 309 minecraft:stripped_oak_log
fill 417 94 310 417 97 310 minecraft:red_terracotta
setblock 417 94 314 minecraft:stripped_oak_log
fill 417 94 315 417 97 315 minecraft:red_terracotta
setblock 377 95 278 minecraft:stripped_oak_log
fill 377 95 279 377 98 279 minecraft:red_terracotta
setblock 377 95 283 minecraft:stripped_oak_log
fill 377 95 284 377 95 287 minecraft:red_terracotta
setblock 377 95 288 minecraft:stripped_oak_log
fill 377 95 289 377 95 292 minecraft:red_terracotta
setblock 377 95 293 minecraft:stripped_oak_log
fill 377 95 294 377 95 297 minecraft:red_terracotta
setblock 377 95 298 minecraft:stripped_oak_log
fill 377 95 299 377 95 302 minecraft:red_terracotta
setblock 377 95 303 minecraft:stripped_oak_log
fill 377 95 304 377 98 304 minecraft:red_terracotta
setblock 377 95 308 minecraft:stripped_oak_log
fill 377 95 309 377 98 309 minecraft:red_terracotta
setblock 377 95 313 minecraft:stripped_oak_log
fill 377 95 314 377 98 314 minecraft:red_terracotta
fill 378 95 278 378 96 278 minecraft:red_terracotta
setblock 378 95 282 minecraft:stripped_oak_log
fill 378 95 283 378 95 286 minecraft:red_terracotta
setblock 378 95 287 minecraft:stripped_oak_log
fill 378 95 288 379 97 288 minecraft:red_terracotta
setblock 378 95 292 minecraft:stripped_oak_log
fill 378 95 293 378 98 293 minecraft:red_terracotta
setblock 378 95 297 minecraft:stripped_oak_log
fill 378 95 298 378 98 298 minecraft:red_terracotta
setblock 378 95 302 minecraft:stripped_oak_log
fill 378 95 303 378 98 303 minecraft:red_terracotta
setblock 378 95 307 minecraft:stripped_oak_log
fill 378 95 308 378 98 308 minecraft:red_terracotta
setblock 378 95 312 minecraft:stripped_oak_log
setblock 379 95 276 minecraft:stripped_oak_log
setblock 379 95 281 minecraft:stripped_oak_log
fill 379 95 282 379 95 285 minecraft:red_terracotta
setblock 379 95 286 minecraft:stripped_oak_log
fill 379 95 287 379 98 287 minecraft:red_terracotta
setblock 379 95 296 minecraft:stripped_oak_log
fill 379 95 297 379 96 297 minecraft:red_terracotta
setblock 379 95 301 minecraft:stripped_oak_log
fill 379 95 302 379 98 302 minecraft:red_terracotta
setblock 379 95 306 minecraft:stripped_oak_log
fill 379 95 307 379 98 307 minecraft:red_terracotta
fill 379 95 309 379 96 309 minecraft:red_terracotta
setblock 379 95 316 minecraft:stripped_oak_log
fill 380 95 276 380 96 276 minecraft:red_terracotta
setblock 380 95 300 minecraft:stripped_oak_log
setblock 380 95 301 minecraft:red_terracotta
setblock 380 95 305 minecraft:stripped_oak_log
fill 390 95 276 390 98 276 minecraft:red_terracotta
fill 391 95 277 391 96 277 minecraft:red_terracotta
setblock 393 95 276 minecraft:red_terracotta
setblock 393 95 277 minecraft:stripped_oak_log
fill 393 95 278 393 98 278 minecraft:red_terracotta
setblock 394 95 276 minecraft:stripped_oak_log
fill 394 95 277 394 98 277 minecraft:red_terracotta
fill 394 95 279 394 96 279 minecraft:red_terracotta
setblock 394 95 316 minecraft:stripped_oak_log
fill 395 95 276 395 98 276 minecraft:red_terracotta
fill 395 95 316 398 95 316 minecraft:red_terracotta
setblock 396 95 278 minecraft:red_terracotta
setblock 396 95 279 minecraft:stripped_oak_log
setblock 397 95 278 minecraft:stripped_oak_log
fill 397 95 279 397 95 280 minecraft:red_terracotta
setblock 398 95 277 minecraft:stripped_oak_log
fill 398 95 278 398 98 278 minecraft:red_terracotta
setblock 399 95 276 minecraft:stripped_oak_log
fill 399 95 277 402 95 277 minecraft:red_terracotta
setblock 399 95 316 minecraft:stripped_oak_log
fill 400 95 276 400 98 276 minecraft:red_terracotta
fill 400 95 316 400 98 316 minecraft:red_terracotta
setblock 402 95 278 minecraft:stripped_oak_log
setblock 403 95 277 minecraft:stripped_oak_log
setblock 404 95 276 minecraft:stripped_oak_log
fill 404 95 277 404 96 277 minecraft:red_terracotta
setblock 404 95 316 minecraft:stripped_oak_log
fill 405 95 276 405 97 276 minecraft:red_terracotta
fill 405 95 316 405 98 316 minecraft:red_terracotta
fill 406 95 303 406 99 304 minecraft:brown_terracotta
fill 408 95 306 408 99 306 minecraft:brown_terracotta
setblock 409 95 276 minecraft:stripped_oak_log
setblock 409 95 316 minecraft:stripped_oak_log
fill 410 95 276 410 98 276 minecraft:red_terracotta
fill 410 95 303 410 99 305 minecraft:brown_terracotta
fill 410 95 316 410 98 316 minecraft:red_terracotta
setblock 413 95 277 minecraft:stripped_oak_log
fill 413 95 315 413 96 315 minecraft:red_terracotta
setblock 414 95 276 minecraft:stripped_oak_log
fill 414 95 277 414 97 277 minecraft:red_terracotta
fill 414 95 286 414 101 286 minecraft:green_concrete
fill 414 95 294 414 104 294 minecraft:brown_terracotta
fill 414 95 303 414 95 305 minecraft:red_terracotta
setblock 414 95 306 minecraft:stripped_oak_log
fill 414 95 307 414 97 308 minecraft:red_terracotta
setblock 414 95 316 minecraft:stripped_oak_log
fill 415 95 276 415 98 276 minecraft:red_terracotta
setblock 415 95 299 minecraft:red_terracotta
setblock 415 95 300 minecraft:stripped_oak_log
fill 415 95 301 415 98 301 minecraft:red_terracotta
setblock 415 95 304 minecraft:red_terracotta
setblock 415 95 305 minecraft:stripped_oak_log
fill 415 95 306 415 98 306 minecraft:red_terracotta
setblock 415 95 309 minecraft:red_terracotta
setblock 415 95 310 minecraft:stripped_oak_log
fill 415 95 311 415 97 312 minecraft:red_terracotta
setblock 415 95 315 minecraft:stripped_oak_log
fill 415 95 316 415 98 316 minecraft:red_terracotta
setblock 416 95 279 minecraft:stripped_oak_log
fill 416 95 280 416 98 280 minecraft:red_terracotta
fill 416 95 282 416 95 283 minecraft:red_terracotta
setblock 416 95 284 minecraft:stripped_oak_log
fill 416 95 285 416 96 287 minecraft:red_terracotta
fill 416 95 296 416 97 296 minecraft:red_terracotta
setblock 416 95 299 minecraft:stripped_oak_log
fill 416 95 300 416 98 300 minecraft:red_terracotta
setblock 416 95 304 minecraft:stripped_oak_log
fill 416 95 305 416 98 305 minecraft:red_terracotta
setblock 416 95 309 minecraft:stripped_oak_log
fill 416 95 310 416 98 310 minecraft:red_terracotta
setblock 416 95 314 minecraft:stripped_oak_log
fill 416 95 315 416 98 315 minecraft:red_terracotta
setblock 417 95 278 minecraft:stripped_oak_log
fill 417 95 279 417 98 279 minecraft:red_terracotta
setblock 417 95 283 minecraft:stripped_oak_log
fill 417 95 284 417 98 284 minecraft:red_terracotta
fill 417 95 286 417 95 287 minecraft:red_terracotta
setblock 417 95 288 minecraft:stripped_oak_log
fill 417 95 289 417 95 292 minecraft:red_terracotta
setblock 417 95 293 minecraft:stripped_oak_log
fill 417 95 294 417 98 294 minecraft:red_terracotta
setblock 417 95 298 minecraft:stripped_oak_log
fill 417 95 299 417 98 299 minecraft:red_terracotta
setblock 417 95 303 minecraft:stripped_oak_log
fill 417 95 304 417 98 304 minecraft:red_terracotta
setblock 417 95 307 minecraft:red_terracotta
setblock 417 95 308 minecraft:stripped_oak_log
fill 417 95 309 417 98 309 minecraft:red_terracotta
setblock 417 95 313 minecraft:stripped_oak_log
fill 417 95 314 417 98 314 minecraft:red_terracotta
fill 376 96 275 376 99 317 minecraft:white_terracotta
fill 377 96 275 418 99 275 minecraft:white_terracotta
setblock 377 96 277 minecraft:stripped_oak_log
fill 377 96 278 377 99 278 minecraft:red_terracotta
setblock 377 96 282 minecraft:stripped_oak_log
fill 377 96 283 377 96 286 minecraft:red_terracotta
setblock 377 96 287 minecraft:stripped_oak_log
fill 377 96 288 377 96 291 minecraft:red_terracotta
setblock 377 96 292 minecraft:stripped_oak_log
fill 377 96 293 377 96 296 minecraft:red_terracotta
setblock 377 96 297 minecraft:stripped_oak_log
fill 377 96 298 377 96 301 minecraft:red_terracotta
setblock 377 96 302 minecraft:stripped_oak_log
fill 377 96 303 377 99 303 minecraft:red_terracotta
setblock 377 96 307 minecraft:stripped_oak_log
fill 377 96 308 377 99 308 minecraft:red_terracotta
setblock 377 96 311 minecraft:red_terracotta
setblock 377 96 312 minecraft:stripped_oak_log
fill 377 96 313 377 99 313 minecraft:red_terracotta
fill 377 96 317 418 99 317 minecraft:white_terracotta
setblock 378 96 276 minecraft:stripped_oak_log
setblock 378 96 281 minecraft:stripped_oak_log
fill 378 96 282 378 96 285 minecraft:red_terracotta
setblock 378 96 286 minecraft:stripped_oak_log
fill 378 96 287 378 99 287 minecraft:red_terracotta
fill 378 96 289 378 96 290 minecraft:red_terracotta
setblock 378 96 291 minecraft:stripped_oak_log
fill 378 96 292 378 99 292 minecraft:red_terracotta
setblock 378 96 296 minecraft:stripped_oak_log
fill 378 96 297 378 99 297 minecraft:red_terracotta
setblock 378 96 301 minecraft:stripped_oak_log
fill 378 96 302 378 99 302 minecraft:red_terracotta
setblock 378 96 306 minecraft:stripped_oak_log
fill 378 96 307 378 99 307 minecraft:red_terracotta
setblock 378 96 311 minecraft:stripped_oak_log
fill 378 96 312 378 99 312 minecraft:red_terracotta
setblock 378 96 316 minecraft:stripped_oak_log
setblock 379 96 276 minecraft:red_terracotta
setblock 379 96 278 minecraft:light[level=15]
fill 379 96 281 379 96 284 minecraft:red_terracotta
setblock 379 96 285 minecraft:stripped_oak_log
fill 379 96 286 379 99 286 minecraft:red_terracotta
setblock 379 96 289 minecraft:red_terracotta
setblock 379 96 290 minecraft:stripped_oak_log
setblock 379 96 292 minecraft:light[level=12]
setblock 379 96 294 minecraft:light[level=15]
setblock 379 96 300 minecraft:stripped_oak_log
fill 379 96 301 379 98 301 minecraft:red_terracotta
setblock 379 96 305 minecraft:stripped_oak_log
fill 379 96 306 379 99 306 minecraft:red_terracotta
setblock 379 96 310 minecraft:light[level=15]
setblock 379 96 313 minecraft:light[level=12]
setblock 380 96 304 minecraft:stripped_oak_log
setblock 380 96 305 minecraft:red_terracotta
setblock 386 96 278 minecraft:light[level=12]
setblock 386 96 285 minecraft:light[level=12]
setblock 386 96 292 minecraft:light[level=12]
setblock 386 96 299 minecraft:light[level=12]
setblock 386 96 306 minecraft:light[level=12]
setblock 386 96 313 minecraft:light[level=12]
setblock 387 96 278 minecraft:light[level=15]
setblock 387 96 286 minecraft:light[level=15]
setblock 387 96 294 minecraft:light[level=15]
setblock 387 96 302 minecraft:light[level=15]
setblock 387 96 310 minecraft:light[level=15]
setblock 392 96 276 minecraft:red_terracotta
setblock 392 96 277 minecraft:stripped_oak_log
fill 392 96 278 392 98 278 minecraft:red_terracotta
setblock 393 96 276 minecraft:stripped_oak_log
fill 393 96 277 393 99 277 minecraft:red_terracotta
setblock 393 96 285 minecraft:light[level=12]
setblock 393 96 292 minecraft:light[level=12]
setblock 393 96 299 minecraft:light[level=12]
setblock 393 96 306 minecraft:light[level=12]
setblock 393 96 313 minecraft:light[level=12]
setblock 393 96 316 minecraft:stripped_oak_log
fill 394 96 276 394 99 276 minecraft:red_terracotta
fill 394 96 316 397 96 316 minecraft:red_terracotta
setblock 395 96 278 minecraft:red_terracotta
setblock 395 96 279 minecraft:stripped_oak_log
setblock 395 96 286 minecraft:light[level=15]
setblock 395 96 294 minecraft:light[level=15]
setblock 395 96 302 minecraft:light[level=15]
setblock 395 96 310 minecraft:light[level=15]
setblock 396 96 278 minecraft:stripped_oak_log
fill 396 96 279 397 98 279 minecraft:red_terracotta
setblock 397 96 277 minecraft:stripped_oak_log
fill 397 96 278 397 99 278 minecraft:red_terracotta
fill 397 96 315 398 96 315 minecraft:red_terracotta
setblock 398 96 276 minecraft:stripped_oak_log
fill 398 96 277 401 96 277 minecraft:red_terracotta
setblock 398 96 316 minecraft:stripped_oak_log
fill 399 96 276 399 99 276 minecraft:red_terracotta
setblock 399 96 315 minecraft:stripped_oak_log
fill 399 96 316 399 99 316 minecraft:red_terracotta
setblock 400 96 279 minecraft:stripped_oak_log
setblock 400 96 285 minecraft:light[level=12]
setblock 400 96 292 minecraft:light[level=12]
setblock 400 96 299 minecraft:light[level=12]
setblock 400 96 306 minecraft:light[level=12]
setblock 400 96 313 minecraft:light[level=12]
setblock 401 96 278 minecraft:stripped_oak_log
setblock 402 96 277 minecraft:stripped_oak_log
setblock 402 96 278 minecraft:red_terracotta
setblock 403 96 276 minecraft:stripped_oak_log
setblock 403 96 277 minecraft:red_terracotta
setblock 403 96 278 minecraft:light[level=15]
setblock 403 96 286 minecraft:light[level=15]
setblock 403 96 294 minecraft:light[level=15]
setblock 403 96 302 minecraft:light[level=15]
setblock 403 96 310 minecraft:light[level=15]
setblock 403 96 316 minecraft:stripped_oak_log
fill 404 96 276 404 98 276 minecraft:red_terracotta
fill 404 96 316 404 98 316 minecraft:red_terracotta
fill 406 96 302 406 99 302 minecraft:brown_terracotta
fill 406 96 305 406 99 305 minecraft:brown_terracotta
setblock 407 96 278 minecraft:light[level=12]
setblock 407 96 285 minecraft:light[level=12]
setblock 407 96 292 minecraft:light[level=12]
setblock 407 96 299 minecraft:light[level=12]
fill 407 96 301 409 99 301 minecraft:brown_terracotta
fill 407 96 306 407 99 306 minecraft:brown_terracotta
setblock 407 96 313 minecraft:light[level=12]
setblock 407 96 316 minecraft:red_terracotta
setblock 408 96 276 minecraft:stripped_oak_log
setblock 408 96 316 minecraft:stripped_oak_log
fill 409 96 276 409 97 276 minecraft:red_terracotta
fill 409 96 306 409 99 306 minecraft:brown_terracotta
fill 409 96 316 409 99 316 minecraft:red_terracotta
fill 410 96 302 410 99 302 minecraft:brown_terracotta
setblock 411 96 278 minecraft:light[level=15]
setblock 411 96 286 minecraft:light[level=15]
setblock 411 96 294 minecraft:light[level=15]
setblock 411 96 302 minecraft:light[level=15]
setblock 411 96 310 minecraft:light[level=15]
fill 412 96 315 412 97 315 minecraft:red_terracotta
setblock 413 96 276 minecraft:stripped_oak_log
setblock 413 96 277 minecraft:red_terracotta
fill 413 96 294 413 104 294 minecraft:brown_terracotta
setblock 413 96 316 minecraft:stripped_oak_log
fill 414 96 276 414 99 276 minecraft:red_terracotta
setblock 414 96 278 minecraft:light[level=12]
setblock 414 96 285 minecraft:light[level=12]
setblock 414 96 292 minecraft:light[level=12]
fill 414 96 295 414 104 295 minecraft:brown_terracotta
setblock 414 96 299 minecraft:light[level=12]
fill 414 96 302 414 96 304 minecraft:red_terracotta
setblock 414 96 305 minecraft:stripped_oak_log
fill 414 96 306 414 99 306 minecraft:red_terracotta
setblock 414 96 309 minecraft:red_terracotta
setblock 414 96 310 minecraft:stripped_oak_log
setblock 414 96 313 minecraft:light[level=12]
setblock 414 96 315 minecraft:stripped_oak_log
fill 414 96 316 414 99 316 minecraft:red_terracotta
fill 415 96 281 415 96 283 minecraft:red_terracotta
setblock 415 96 284 minecraft:stripped_oak_log
setblock 415 96 299 minecraft:stripped_oak_log
fill 415 96 300 415 99 300 minecraft:red_terracotta
setblock 415 96 304 minecraft:stripped_oak_log
fill 415 96 305 415 99 305 minecraft:red_terracotta
setblock 415 96 308 minecraft:red_terracotta
setblock 415 96 309 minecraft:stripped_oak_log
fill 415 96 310 415 99 310 minecraft:red_terracotta
setblock 415 96 313 minecraft:red_terracotta
setblock 415 96 314 minecraft:stripped_oak_log
fill 415 96 315 415 99 315 minecraft:red_terracotta
setblock 416 96 278 minecraft:stripped_oak_log
fill 416 96 279 416 98 279 minecraft:red_terracotta
setblock 416 96 282 minecraft:red_terracotta
setblock 416 96 283 minecraft:stripped_oak_log
fill 416 96 284 416 99 284 minecraft:red_terracotta
setblock 416 96 288 minecraft:stripped_oak_log
fill 416 96 289 417 98 289 minecraft:red_terracotta
setblock 416 96 298 minecraft:stripped_oak_log
fill 416 96 299 416 99 299 minecraft:red_terracotta
setblock 416 96 303 minecraft:stripped_oak_log
fill 416 96 304 416 99 304 minecraft:red_terracotta
setblock 416 96 308 minecraft:stripped_oak_log
fill 416 96 309 416 99 309 minecraft:red_terracotta
setblock 416 96 312 minecraft:red_terracotta
setblock 416 96 313 minecraft:stripped_oak_log
fill 416 96 314 416 99 314 minecraft:red_terracotta
setblock 417 96 277 minecraft:stripped_oak_log
fill 417 96 278 417 99 278 minecraft:red_terracotta
setblock 417 96 282 minecraft:stripped_oak_log
fill 417 96 283 417 99 283 minecraft:red_terracotta
setblock 417 96 286 minecraft:red_terracotta
setblock 417 96 287 minecraft:stripped_oak_log
fill 417 96 288 417 99 288 minecraft:red_terracotta
fill 417 96 290 417 96 291 minecraft:red_terracotta
setblock 417 96 292 minecraft:stripped_oak_log
fill 417 96 293 417 99 293 minecraft:red_terracotta
setblock 417 96 297 minecraft:stripped_oak_log
fill 417 96 298 417 99 298 minecraft:red_terracotta
setblock 417 96 302 minecraft:stripped_oak_log
fill 417 96 303 417 99 303 minecraft:red_terracotta
setblock 417 96 307 minecraft:stripped_oak_log
fill 417 96 308 417 99 308 minecraft:red_terracotta
setblock 417 96 312 minecraft:stripped_oak_log
fill 417 96 313 417 99 313 minecraft:red_terracotta
fill 418 96 276 418 99 316 minecraft:white_terracotta
setblock 377 97 276 minecraft:stripped_oak_log
fill 377 97 277 377 98 277 minecraft:red_terracotta
setblock 377 97 281 minecraft:stripped_oak_log
fill 377 97 282 377 97 285 minecraft:red_terracotta
setblock 377 97 286 minecraft:stripped_oak_log
fill 377 97 287 377 97 290 minecraft:red_terracotta
setblock 377 97 291 minecraft:stripped_oak_log
fill 377 97 292 377 97 295 minecraft:red_terracotta
setblock 377 97 296 minecraft:stripped_oak_log
fill 377 97 297 377 97 300 minecraft:red_terracotta
setblock 377 97 301 minecraft:stripped_oak_log
fill 377 97 302 377 100 302 minecraft:red_terracotta
setblock 377 97 306 minecraft:stripped_oak_log
fill 377 97 307 377 100 307 minecraft:red_terracotta
setblock 377 97 311 minecraft:stripped_oak_log
fill 377 97 312 377 100 312 minecraft:red_terracotta
setblock 377 97 316 minecraft:stripped_oak_log
setblock 378 97 276 minecraft:red_terracotta
setblock 378 97 280 minecraft:stripped_oak_log
fill 378 97 281 378 97 284 minecraft:red_terracotta
setblock 378 97 285 minecraft:stripped_oak_log
fill 378 97 286 378 100 286 minecraft:red_terracotta
setblock 378 97 289 minecraft:red_terracotta
setblock 378 97 290 minecraft:stripped_oak_log
fill 378 97 291 379 99 291 minecraft:red_terracotta
setblock 378 97 295 minecraft:stripped_oak_log
fill 378 97 296 378 100 296 minecraft:red_terracotta
setblock 378 97 300 minecraft:stripped_oak_log
fill 378 97 301 378 100 301 minecraft:red_terracotta
setblock 378 97 305 minecraft:stripped_oak_log
fill 378 97 306 378 100 306 minecraft:red_terracotta
setblock 378 97 310 minecraft:stripped_oak_log
fill 378 97 311 378 100 311 minecraft:red_terracotta
setblock 378 97 316 minecraft:red_terracotta
fill 379 97 282 379 97 283 minecraft:red_terracotta
setblock 379 97 284 minecraft:stripped_oak_log
fill 379 97 285 379 100 285 minecraft:red_terracotta
setblock 379 97 289 minecraft:stripped_oak_log
fill 379 97 290 379 100 290 minecraft:red_terracotta
setblock 379 97 299 minecraft:stripped_oak_log
fill 379 97 300 379 98 300 minecraft:red_terracotta
setblock 379 97 304 minecraft:stripped_oak_log
fill 379 97 305 379 99 305 minecraft:red_terracotta
setblock 379 97 309 minecraft:stripped_oak_log
fill 389 97 276 389 99 276 minecraft:red_terracotta
setblock 391 97 277 minecraft:stripped_oak_log
setblock 392 97 276 minecraft:stripped_oak_log
fill 392 97 277 392 100 277 minecraft:red_terracotta
fill 392 97 279 394 97 280 minecraft:stripped_oak_log
fill 393 97 276 393 100 276 minecraft:red_terracotta
fill 393 97 281 396 149 281 minecraft:stripped_oak_log
fill 393 97 316 396 97 316 minecraft:red_terracotta
setblock 395 97 278 minecraft:stripped_oak_log
fill 395 97 279 395 98 279 minecraft:red_terracotta
fill 395 97 280 397 149 280 minecraft:stripped_oak_log
setblock 396 97 277 minecraft:stripped_oak_log
fill 396 97 278 396 99 278 minecraft:red_terracotta
fill 396 97 315 397 97 315 minecraft:red_terracotta
setblock 397 97 276 minecraft:stripped_oak_log
fill 397 97 277 400 97 277 minecraft:red_terracotta
setblock 397 97 316 minecraft:stripped_oak_log
fill 398 97 276 398 100 276 minecraft:red_terracotta
setblock 398 97 315 minecraft:stripped_oak_log
fill 398 97 316 398 100 316 minecraft:red_terracotta
fill 399 97 315 399 98 315 minecraft:red_terracotta
setblock 400 97 278 minecraft:stripped_oak_log
setblock 401 97 277 minecraft:stripped_oak_log
setblock 402 97 276 minecraft:stripped_oak_log
setblock 402 97 277 minecraft:red_terracotta
setblock 402 97 316 minecraft:stripped_oak_log
fill 403 97 276 403 98 276 minecraft:red_terracotta
fill 403 97 316 403 99 316 minecraft:red_terracotta
fill 405 97 302 405 99 305 minecraft:brown_terracotta
fill 406 97 301 406 99 301 minecraft:brown_terracotta
fill 406 97 306 406 99 306 minecraft:brown_terracotta
setblock 406 97 316 minecraft:red_terracotta
setblock 407 97 316 minecraft:stripped_oak_log
setblock 408 97 276 minecraft:red_terracotta
fill 408 97 316 408 100 316 minecraft:red_terracotta
fill 410 97 301 410 99 301 minecraft:brown_terracotta
fill 410 97 306 410 99 306 minecraft:brown_terracotta
fill 411 97 302 411 99 305 minecraft:brown_terracotta
fill 411 97 315 411 98 315 minecraft:red_terracotta
setblock 412 97 276 minecraft:stripped_oak_log
setblock 412 97 316 minecraft:stripped_oak_log
fill 413 97 276 413 100 276 minecraft:red_terracotta
fill 413 97 295 413 104 295 minecraft:brown_terracotta
setblock 413 97 315 minecraft:stripped_oak_log
fill 413 97 316 413 100 316 minecraft:red_terracotta
fill 414 97 302 414 97 303 minecraft:red_terracotta
setblock 414 97 304 minecraft:stripped_oak_log
fill 414 97 305 414 100 305 minecraft:red_terracotta
setblock 414 97 309 minecraft:stripped_oak_log
fill 414 97 310 414 99 311 minecraft:red_terracotta
setblock 414 97 314 minecraft:stripped_oak_log
fill 414 97 315 414 100 315 minecraft:red_terracotta
setblock 415 97 282 minecraft:red_terracotta
setblock 415 97 283 minecraft:stripped_oak_log
fill 415 97 284 415 98 285 minecraft:red_terracotta
setblock 415 97 299 minecraft:red_terracotta
setblock 415 97 303 minecraft:stripped_oak_log
fill 415 97 304 415 100 304 minecraft:red_terracotta
setblock 415 97 308 minecraft:stripped_oak_log
fill 415 97 309 415 100 309 minecraft:red_terracotta
setblock 415 97 313 minecraft:stripped_oak_log
fill 415 97 314 415 100 314 minecraft:red_terracotta
setblock 416 97 277 minecraft:stripped_oak_log
setblock 416 97 278 minecraft:red_terracotta
setblock 416 97 282 minecraft:stripped_oak_log
fill 416 97 283 416 100 283 minecraft:red_terracotta
fill 416 97 285 416 97 286 minecraft:red_terracotta
setblock 416 97 287 minecraft:stripped_oak_log
fill 416 97 288 416 100 288 minecraft:red_terracotta
fill 416 97 290 416 97 291 minecraft:red_terracotta
fill 416 97 295 416 98 295 minecraft:red_terracotta
setblock 416 97 297 minecraft:stripped_oak_log
fill 416 97 298 416 100 298 minecraft:red_terracotta
setblock 416 97 302 minecraft:stripped_oak_log
fill 416 97 303 416 100 303 minecraft:red_terracotta
setblock 416 97 307 minecraft:stripped_oak_log
fill 416 97 308 416 100 308 minecraft:red_terracotta
setblock 416 97 312 minecraft:stripped_oak_log
fill 416 97 313 416 100 313 minecraft:red_terracotta
setblock 417 97 276 minecraft:stripped_oak_log
fill 417 97 277 417 99 277 minecraft:red_terracotta
setblock 417 97 281 minecraft:stripped_oak_log
fill 417 97 282 417 100 282 minecraft:red_terracotta
setblock 417 97 286 minecraft:stripped_oak_log
fill 417 97 287 417 100 287 minecraft:red_terracotta
setblock 417 97 290 minecraft:red_terracotta
setblock 417 97 291 minecraft:stripped_oak_log
fill 417 97 292 417 100 292 minecraft:red_terracotta
setblock 417 97 296 minecraft:stripped_oak_log
fill 417 97 297 417 100 297 minecraft:red_terracotta
setblock 417 97 301 minecraft:stripped_oak_log
fill 417 97 302 417 100 302 minecraft:red_terracotta
setblock 417 97 306 minecraft:stripped_oak_log
fill 417 97 307 417 100 307 minecraft:red_terracotta
setblock 417 97 311 minecraft:stripped_oak_log
fill 417 97 312 417 100 312 minecraft:red_terracotta
setblock 417 97 316 minecraft:stripped_oak_log
setblock 377 98 276 minecraft:red_terracotta
setblock 377 98 280 minecraft:stripped_oak_log
fill 377 98 281 377 98 284 minecraft:red_terracotta
setblock 377 98 285 minecraft:stripped_oak_log
fill 377 98 286 377 98 289 minecraft:red_terracotta
setblock 377 98 290 minecraft:stripped_oak_log
fill 377 98 291 377 98 294 minecraft:red_terracotta
setblock 377 98 295 minecraft:stripped_oak_log
fill 377 98 296 377 98 299 minecraft:red_terracotta
setblock 377 98 300 minecraft:stripped_oak_log
fill 377 98 301 377 101 301 minecraft:red_terracotta
setblock 377 98 305 minecraft:stripped_oak_log
fill 377 98 306 377 101 306 minecraft:red_terracotta
setblock 377 98 310 minecraft:stripped_oak_log
fill 377 98 311 377 101 311 minecraft:red_terracotta
setblock 377 98 315 minecraft:stripped_oak_log
setblock 377 98 316 minecraft:red_terracotta
fill 378 98 280 378 98 283 minecraft:red_terracotta
setblock 378 98 284 minecraft:stripped_oak_log
fill 378 98 285 378 101 285 minecraft:red_terracotta
setblock 378 98 288 minecraft:red_terracotta
setblock 378 98 289 minecraft:stripped_oak_log
fill 378 98 290 378 101 290 minecraft:red_terracotta
setblock 378 98 294 minecraft:stripped_oak_log
fill 378 98 295 378 100 295 minecraft:red_terracotta
setblock 378 98 299 minecraft:stripped_oak_log
fill 378 98 300 378 100 300 minecraft:red_terracotta
setblock 378 98 304 minecraft:stripped_oak_log
fill 378 98 305 378 101 305 minecraft:red_terracotta
setblock 378 98 309 minecraft:stripped_oak_log
fill 378 98 310 378 101 310 minecraft:red_terracotta
setblock 379 98 283 minecraft:stripped_oak_log
fill 379 98 284 379 99 284 minecraft:red_terracotta
setblock 379 98 288 minecraft:stripped_oak_log
fill 379 98 289 379 101 289 minecraft:red_terracotta
setblock 379 98 303 minecraft:stripped_oak_log
fill 379 98 304 379 99 304 minecraft:red_terracotta
setblock 379 98 308 minecraft:stripped_oak_log
setblock 379 98 309 minecraft:red_terracotta
fill 390 98 278 391 99 279 minecraft:brown_terracotta
setblock 391 98 276 minecraft:stripped_oak_log
fill 391 98 277 391 101 277 minecraft:red_terracotta
fill 391 98 280 391 99 281 minecraft:brown_terracotta
fill 392 98 276 392 101 276 minecraft:red_terracotta
fill 392 98 279 393 149 280 minecraft:stripped_oak_log
fill 392 98 281 392 99 282 minecraft:brown_terracotta
fill 392 98 316 395 98 316 minecraft:red_terracotta
fill 393 98 282 397 99 282 minecraft:brown_terracotta
setblock 394 98 278 minecraft:stripped_oak_log
setblock 394 98 279 minecraft:red_terracotta
fill 394 98 280 394 149 280 minecraft:stripped_oak_log
setblock 395 98 277 minecraft:stripped_oak_log
fill 395 98 278 395 100 278 minecraft:red_terracotta
fill 395 98 315 396 98 315 minecraft:red_terracotta
setblock 396 98 276 minecraft:stripped_oak_log
fill 396 98 277 399 98 277 minecraft:red_terracotta
setblock 396 98 316 minecraft:stripped_oak_log
fill 397 98 276 397 101 276 minecraft:red_terracotta
fill 397 98 281 398 99 281 minecraft:brown_terracotta
setblock 397 98 315 minecraft:stripped_oak_log
fill 397 98 316 397 101 316 minecraft:red_terracotta
fill 398 98 279 402 98 280 minecraft:brown_terracotta
fill 398 98 315 398 100 315 minecraft:red_terracotta
setblock 399 98 278 minecraft:stripped_oak_log
setblock 400 98 277 minecraft:stripped_oak_log
fill 400 98 278 402 98 278 minecraft:brown_terracotta
setblock 401 98 276 minecraft:stripped_oak_log
setblock 401 98 277 minecraft:red_terracotta
setblock 401 98 316 minecraft:stripped_oak_log
fill 402 98 276 402 99 276 minecraft:red_terracotta
setblock 402 98 277 minecraft:brown_terracotta
fill 402 98 316 402 100 316 minecraft:red_terracotta
setblock 406 98 316 minecraft:stripped_oak_log
fill 407 98 300 409 99 300 minecraft:brown_terracotta
fill 407 98 307 409 99 307 minecraft:brown_terracotta
fill 407 98 316 407 101 316 minecraft:red_terracotta
fill 410 98 315 410 99 315 minecraft:red_terracotta
setblock 411 98 276 minecraft:stripped_oak_log
fill 411 98 306 411 99 306 minecraft:brown_terracotta
setblock 411 98 316 minecraft:stripped_oak_log
fill 412 98 276 412 100 276 minecraft:red_terracotta
fill 412 98 294 412 104 295 minecraft:brown_terracotta
setblock 412 98 315 minecraft:stripped_oak_log
fill 412 98 316 412 101 316 minecraft:red_terracotta
fill 413 98 293 414 104 293 minecraft:brown_terracotta
fill 413 98 296 414 104 296 minecraft:brown_terracotta
setblock 413 98 314 minecraft:stripped_oak_log
fill 413 98 315 413 101 315 minecraft:red_terracotta
fill 414 98 287 414 100 287 minecraft:green_concrete
setblock 414 98 302 minecraft:red_terracotta
setblock 414 98 303 minecraft:stripped_oak_log
fill 414 98 304 414 100 304 minecraft:red_terracotta
setblock 414 98 307 minecraft:red_terracotta
setblock 414 98 308 minecraft:stripped_oak_log
fill 414 98 309 414 101 309 minecraft:red_terracotta
fill 414 98 314 414 101 314 minecraft:red_terracotta
setblock 415 98 283 minecraft:red_terracotta
setblock 415 98 286 minecraft:red_terracotta
fill 415 98 294 415 104 295 minecraft:brown_terracotta
setblock 415 98 302 minecraft:stripped_oak_log
fill 415 98 303 415 101 303 minecraft:red_terracotta
setblock 415 98 307 minecraft:stripped_oak_log
fill 415 98 308 415 101 308 minecraft:red_terracotta
setblock 415 98 311 minecraft:red_terracotta
setblock 415 98 312 minecraft:stripped_oak_log
fill 415 98 313 415 101 313 minecraft:red_terracotta
setblock 416 98 276 minecraft:stripped_oak_log
setblock 416 98 281 minecraft:stripped_oak_log
fill 416 98 282 416 100 282 minecraft:red_terracotta
setblock 416 98 285 minecraft:red_terracotta
setblock 416 98 286 minecraft:stripped_oak_log
fill 416 98 287 416 101 287 minecraft:red_terracotta
setblock 416 98 290 minecraft:red_terracotta
setblock 416 98 291 minecraft:stripped_oak_log
fill 416 98 292 416 100 293 minecraft:red_terracotta
setblock 416 98 296 minecraft:stripped_oak_log
fill 416 98 297 416 100 297 minecraft:red_terracotta
setblock 416 98 301 minecraft:stripped_oak_log
fill 416 98 302 416 101 302 minecraft:red_terracotta
setblock 416 98 306 minecraft:stripped_oak_log
fill 416 98 307 416 101 307 minecraft:red_terracotta
setblock 416 98 311 minecraft:stripped_oak_log
fill 416 98 312 416 101 312 minecraft:red_terracotta
setblock 416 98 316 minecraft:stripped_oak_log
setblock 417 98 276 minecraft:red_terracotta
setblock 417 98 280 minecraft:stripped_oak_log
fill 417 98 281 417 100 281 minecraft:red_terracotta
setblock 417 98 285 minecraft:stripped_oak_log
fill 417 98 286 417 101 286 minecraft:red_terracotta
setblock 417 98 290 minecraft:stripped_oak_log
fill 417 98 291 417 101 291 minecraft:red_terracotta
setblock 417 98 295 minecraft:stripped_oak_log
fill 417 98 296 417 101 296 minecraft:red_terracotta
setblock 417 98 300 minecraft:stripped_oak_log
fill 417 98 301 417 101 301 minecraft:red_terracotta
setblock 417 98 305 minecraft:stripped_oak_log
fill 417 98 306 417 101 306 minecraft:red_terracotta
setblock 417 98 310 minecraft:stripped_oak_log
fill 417 98 311 417 101 311 minecraft:red_terracotta
setblock 417 98 315 minecraft:stripped_oak_log
fill 417 98 316 417 101 316 minecraft:red_terracotta
setblock 377 99 279 minecraft:stripped_oak_log
fill 377 99 280 377 99 283 minecraft:red_terracotta
setblock 377 99 284 minecraft:stripped_oak_log
fill 377 99 285 377 99 288 minecraft:red_terracotta
setblock 377 99 289 minecraft:stripped_oak_log
fill 377 99 290 377 99 293 minecraft:red_terracotta
setblock 377 99 294 minecraft:stripped_oak_log
fill 377 99 295 377 99 298 minecraft:red_terracotta
setblock 377 99 299 minecraft:stripped_oak_log
fill 377 99 300 377 102 300 minecraft:red_terracotta
setblock 377 99 304 minecraft:stripped_oak_log
fill 377 99 305 377 102 305 minecraft:red_terracotta
setblock 377 99 309 minecraft:stripped_oak_log
fill 377 99 310 377 102 310 minecraft:red_terracotta
setblock 377 99 314 minecraft:stripped_oak_log
fill 377 99 315 377 100 315 minecraft:red_terracotta
fill 378 99 281 378 99 282 minecraft:red_terracotta
setblock 378 99 283 minecraft:stripped_oak_log
fill 378 99 284 378 102 284 minecraft:red_terracotta
setblock 378 99 288 minecraft:stripped_oak_log
fill 378 99 289 378 102 289 minecraft:red_terracotta
setblock 378 99 293 minecraft:stripped_oak_log
fill 378 99 294 378 102 294 minecraft:red_terracotta
setblock 378 99 298 minecraft:stripped_oak_log
fill 378 99 299 378 100 299 minecraft:red_terracotta
setblock 378 99 303 minecraft:stripped_oak_log
fill 378 99 304 378 101 304 minecraft:red_terracotta
setblock 378 99 308 minecraft:stripped_oak_log
fill 378 99 309 378 101 309 minecraft:red_terracotta
setblock 379 99 287 minecraft:stripped_oak_log
fill 379 99 288 379 101 288 minecraft:red_terracotta
setblock 379 99 303 minecraft:red_terracotta
setblock 379 99 307 minecraft:stripped_oak_log
setblock 379 99 308 minecraft:red_terracotta
fill 389 99 277 389 99 280 minecraft:brown_terracotta
setblock 390 99 276 minecraft:stripped_oak_log
setblock 390 99 277 minecraft:brown_terracotta
fill 390 99 280 390 99 282 minecraft:brown_terracotta
fill 391 99 276 391 102 276 minecraft:red_terracotta
fill 391 99 282 391 99 283 minecraft:brown_terracotta
fill 392 99 278 393 108 278 minecraft:stripped_oak_log
fill 392 99 283 397 99 283 minecraft:brown_terracotta
fill 392 99 316 394 99 316 minecraft:red_terracotta
fill 393 99 284 396 99 284 minecraft:brown_terracotta
setblock 394 99 277 minecraft:stripped_oak_log
fill 394 99 278 394 100 278 minecraft:red_terracotta
fill 394 99 279 397 149 279 minecraft:stripped_oak_log
fill 394 99 315 395 99 315 minecraft:red_terracotta
setblock 395 99 276 minecraft:stripped_oak_log
fill 395 99 277 398 99 277 minecraft:red_terracotta
setblock 395 99 316 minecraft:stripped_oak_log
fill 396 99 276 396 102 276 minecraft:red_terracotta
setblock 396 99 315 minecraft:stripped_oak_log
fill 396 99 316 396 102 316 minecraft:red_terracotta
fill 397 99 315 397 102 315 minecraft:red_terracotta
setblock 398 99 278 minecraft:stripped_oak_log
fill 398 99 279 399 99 280 minecraft:brown_terracotta
setblock 398 99 282 minecraft:brown_terracotta
setblock 399 99 277 minecraft:stripped_oak_log
fill 399 99 278 400 99 278 minecraft:brown_terracotta
setblock 399 99 281 minecraft:brown_terracotta
setblock 400 99 276 minecraft:stripped_oak_log
setblock 400 99 277 minecraft:red_terracotta
setblock 400 99 279 minecraft:brown_terracotta
fill 400 99 280 402 99 280 minecraft:stripped_oak_log
setblock 400 99 316 minecraft:stripped_oak_log
fill 401 99 276 401 100 276 minecraft:red_terracotta
fill 401 99 277 402 99 279 minecraft:stripped_oak_log
fill 401 99 316 401 101 316 minecraft:red_terracotta
fill 404 99 302 404 99 305 minecraft:brown_terracotta
setblock 405 99 301 minecraft:brown_terracotta
setblock 405 99 306 minecraft:brown_terracotta
setblock 406 99 300 minecraft:brown_terracotta
setblock 406 99 307 minecraft:brown_terracotta
fill 406 99 316 406 102 316 minecraft:red_terracotta
setblock 410 99 300 minecraft:brown_terracotta
setblock 410 99 307 minecraft:brown_terracotta
setblock 410 99 316 minecraft:stripped_oak_log
setblock 411 99 276 minecraft:red_terracotta
setblock 411 99 301 minecraft:brown_terracotta
setblock 411 99 315 minecraft:stripped_oak_log
fill 411 99 316 411 102 316 minecraft:red_terracotta
fill 412 99 293 412 104 293 minecraft:brown_terracotta
fill 412 99 296 412 104 296 minecraft:brown_terracotta
fill 412 99 302 412 99 305 minecraft:brown_terracotta
setblock 412 99 314 minecraft:stripped_oak_log
fill 412 99 315 412 102 315 minecraft:red_terracotta
fill 413 99 314 413 102 314 minecraft:red_terracotta
setblock 414 99 303 minecraft:red_terracotta
setblock 414 99 307 minecraft:stripped_oak_log
fill 414 99 308 414 102 308 minecraft:red_terracotta
setblock 414 99 312 minecraft:stripped_oak_log
setblock 415 99 276 minecraft:stripped_oak_log
setblock 415 99 285 minecraft:red_terracotta
setblock 415 99 286 minecraft:stripped_oak_log
setblock 415 99 287 minecraft:red_terracotta
fill 415 99 293 415 104 293 minecraft:brown_terracotta
fill 415 99 296 415 104 296 minecraft:brown_terracotta
setblock 415 99 301 minecraft:stripped_oak_log
fill 415 99 302 415 101 302 minecraft:red_terracotta
setblock 415 99 306 minecraft:stripped_oak_log
fill 415 99 307 415 102 307 minecraft:red_terracotta
setblock 415 99 311 minecraft:stripped_oak_log
fill 415 99 312 415 102 312 minecraft:red_terracotta
setblock 415 99 316 minecraft:stripped_oak_log
setblock 416 99 276 minecraft:red_terracotta
setblock 416 99 281 minecraft:red_terracotta
setblock 416 99 285 minecraft:stripped_oak_log
fill 416 99 286 416 102 286 minecraft:red_terracotta
setblock 416 99 289 minecraft:red_terracotta
setblock 416 99 290 minecraft:stripped_oak_log
fill 416 99 291 416 102 291 minecraft:red_terracotta
setblock 416 99 294 minecraft:red_terracotta
setblock 416 99 295 minecraft:stripped_oak_log
setblock 416 99 296 minecraft:red_terracotta
setblock 416 99 300 minecraft:stripped_oak_log
fill 416 99 301 416 102 301 minecraft:red_terracotta
setblock 416 99 305 minecraft:stripped_oak_log
fill 416 99 306 416 102 306 minecraft:red_terracotta
setblock 416 99 310 minecraft:stripped_oak_log
fill 416 99 311 416 102 311 minecraft:red_terracotta
setblock 416 99 315 minecraft:stripped_oak_log
fill 416 99 316 416 102 316 minecraft:red_terracotta
setblock 417 99 279 minecraft:stripped_oak_log
fill 417 99 280 417 100 280 minecraft:red_terracotta
setblock 417 99 284 minecraft:stripped_oak_log
fill 417 99 285 417 102 285 minecraft:red_terracotta
setblock 417 99 289 minecraft:stripped_oak_log
fill 417 99 290 417 102 290 minecraft:red_terracotta
setblock 417 99 294 minecraft:stripped_oak_log
fill 417 99 295 417 102 295 minecraft:red_terracotta
setblock 417 99 299 minecraft:stripped_oak_log
fill 417 99 300 417 102 300 minecraft:red_terracotta
setblock 417 99 304 minecraft:stripped_oak_log
fill 417 99 305 417 102 305 minecraft:red_terracotta
setblock 417 99 309 minecraft:stripped_oak_log
fill 417 99 310 417 102 310 minecraft:red_terracotta
setblock 417 99 314 minecraft:stripped_oak_log
fill 417 99 315 417 102 315 minecraft:red_terracotta
fill 376 100 275 376 103 317 minecraft:terracotta
fill 377 100 275 396 103 275 minecraft:terracotta
fill 377 100 279 377 100 282 minecraft:red_terracotta
setblock 377 100 283 minecraft:stripped_oak_log
fill 377 100 284 377 100 287 minecraft:red_terracotta
setblock 377 100 288 minecraft:stripped_oak_log
fill 377 100 289 377 100 292 minecraft:red_terracotta
setblock 377 100 293 minecraft:stripped_oak_log
fill 377 100 294 377 100 297 minecraft:red_terracotta
setblock 377 100 298 minecraft:stripped_oak_log
fill 377 100 299 377 103 299 minecraft:red_terracotta
setblock 377 100 303 minecraft:stripped_oak_log
fill 377 100 304 377 103 304 minecraft:red_terracotta
setblock 377 100 308 minecraft:stripped_oak_log
fill 377 100 309 377 103 309 minecraft:red_terracotta
setblock 377 100 313 minecraft:stripped_oak_log
fill 377 100 314 377 101 314 minecraft:red_terracotta
fill 377 100 317 418 103 317 minecraft:terracotta
setblock 378 100 282 minecraft:stripped_oak_log
fill 378 100 283 378 101 283 minecraft:red_terracotta
setblock 378 100 287 minecraft:stripped_oak_log
fill 378 100 288 378 103 288 minecraft:red_terracotta
setblock 378 100 291 minecraft:red_terracotta
setblock 378 100 292 minecraft:stripped_oak_log
fill 378 100 293 378 103 293 minecraft:red_terracotta
setblock 378 100 297 minecraft:stripped_oak_log
setblock 378 100 298 minecraft:red_terracotta
setblock 378 100 302 minecraft:stripped_oak_log
fill 378 100 303 378 101 303 minecraft:red_terracotta
setblock 378 100 307 minecraft:stripped_oak_log
fill 378 100 308 378 102 308 minecraft:red_terracotta
setblock 379 100 286 minecraft:stripped_oak_log
fill 379 100 287 379 101 287 minecraft:red_terracotta
setblock 389 100 276 minecraft:stripped_oak_log
fill 390 100 276 390 103 276 minecraft:red_terracotta
fill 391 100 316 393 100 316 minecraft:red_terracotta
setblock 393 100 277 minecraft:stripped_oak_log
setblock 394 100 276 minecraft:stripped_oak_log
fill 394 100 277 397 100 277 minecraft:red_terracotta
setblock 394 100 315 minecraft:red_terracotta
setblock 394 100 316 minecraft:stripped_oak_log
fill 395 100 276 395 103 276 minecraft:red_terracotta
setblock 395 100 315 minecraft:stripped_oak_log
fill 395 100 316 395 103 316 minecraft:red_terracotta
fill 396 100 278 397 149 278 minecraft:stripped_oak_log
fill 396 100 315 396 103 315 minecraft:red_terracotta
fill 397 100 275 399 103 275 minecraft:shroomlight
setblock 398 100 277 minecraft:stripped_oak_log
fill 398 100 280 402 100 280 minecraft:orange_terracotta
setblock 399 100 276 minecraft:stripped_oak_log
setblock 399 100 316 minecraft:stripped_oak_log
fill 400 100 275 418 103 275 minecraft:terracotta
setblock 400 100 276 minecraft:red_terracotta
fill 400 100 316 400 103 316 minecraft:red_terracotta
fill 407 100 303 409 100 304 minecraft:shroomlight
setblock 409 100 315 minecraft:red_terracotta
setblock 409 100 316 minecraft:stripped_oak_log
setblock 410 100 315 minecraft:stripped_oak_log
fill 410 100 316 410 103 316 minecraft:red_terracotta
fill 411 100 294 411 104 295 minecraft:brown_terracotta
fill 411 100 315 411 103 315 minecraft:red_terracotta
fill 412 100 314 412 103 314 minecraft:red_terracotta
fill 413 100 292 415 104 292 minecraft:brown_terracotta
fill 413 100 297 414 104 297 minecraft:brown_terracotta
setblock 414 100 276 minecraft:stripped_oak_log
setblock 414 100 306 minecraft:stripped_oak_log
fill 414 100 307 414 102 307 minecraft:red_terracotta
setblock 414 100 310 minecraft:red_terracotta
setblock 414 100 311 minecraft:stripped_oak_log
fill 414 100 312 414 101 312 minecraft:red_terracotta
setblock 414 100 316 minecraft:stripped_oak_log
setblock 415 100 276 minecraft:red_terracotta
setblock 415 100 301 minecraft:red_terracotta
setblock 415 100 305 minecraft:stripped_oak_log
fill 415 100 306 415 103 306 minecraft:red_terracotta
setblock 415 100 310 minecraft:stripped_oak_log
fill 415 100 311 415 103 311 minecraft:red_terracotta
setblock 415 100 315 minecraft:stripped_oak_log
fill 415 100 316 415 103 316 minecraft:red_terracotta
setblock 416 100 284 minecraft:stripped_oak_log
fill 416 100 285 416 101 285 minecraft:red_terracotta
setblock 416 100 289 minecraft:stripped_oak_log
fill 416 100 290 416 103 290 minecraft:red_terracotta
fill 416 100 294 416 103 295 minecraft:brown_terracotta
setblock 416 100 299 minecraft:stripped_oak_log
fill 416 100 300 416 101 300 minecraft:red_terracotta
setblock 416 100 304 minecraft:stripped_oak_log
fill 416 100 305 416 103 305 minecraft:red_terracotta
setblock 416 100 309 minecraft:stripped_oak_log
fill 416 100 310 416 103 310 minecraft:red_terracotta
setblock 416 100 314 minecraft:stripped_oak_log
fill 416 100 315 416 102 315 minecraft:red_terracotta
setblock 417 100 283 minecraft:stripped_oak_log
fill 417 100 284 417 102 284 minecraft:red_terracotta
setblock 417 100 288 minecraft:stripped_oak_log
fill 417 100 289 417 103 289 minecraft:red_terracotta
setblock 417 100 293 minecraft:stripped_oak_log
fill 417 100 294 417 103 294 minecraft:red_terracotta
setblock 417 100 298 minecraft:stripped_oak_log
fill 417 100 299 417 103 299 minecraft:red_terracotta
setblock 417 100 303 minecraft:stripped_oak_log
fill 417 100 304 417 103 304 minecraft:red_terracotta
setblock 417 100 308 minecraft:stripped_oak_log
fill 417 100 309 417 103 309 minecraft:red_terracotta
setblock 417 100 313 minecraft:stripped_oak_log
fill 417 100 314 417 103 314 minecraft:red_terracotta
fill 418 100 276 418 103 316 minecraft:terracotta
fill 377 101 280 377 101 281 minecraft:red_terracotta
setblock 377 101 282 minecraft:stripped_oak_log
fill 377 101 283 377 101 286 minecraft:red_terracotta
setblock 377 101 287 minecraft:stripped_oak_log
fill 377 101 288 377 101 291 minecraft:red_terracotta
setblock 377 101 292 minecraft:stripped_oak_log
fill 377 101 293 377 101 296 minecraft:red_terracotta
setblock 377 101 297 minecraft:stripped_oak_log
fill 377 101 298 377 104 298 minecraft:red_terracotta
setblock 377 101 302 minecraft:stripped_oak_log
fill 377 101 303 377 103 303 minecraft:red_terracotta
setblock 377 101 307 minecraft:stripped_oak_log
fill 377 101 308 377 104 308 minecraft:red_terracotta
setblock 377 101 312 minecraft:stripped_oak_log
fill 377 101 313 377 104 313 minecraft:red_terracotta
setblock 378 101 286 minecraft:stripped_oak_log
fill 378 101 287 378 104 287 minecraft:red_terracotta
setblock 378 101 291 minecraft:stripped_oak_log
fill 378 101 292 378 104 292 minecraft:red_terracotta
setblock 378 101 306 minecraft:stripped_oak_log
fill 378 101 307 378 102 307 minecraft:red_terracotta
fill 389 101 276 389 104 276 minecraft:red_terracotta
fill 391 101 316 392 101 316 minecraft:red_terracotta
setblock 392 101 277 minecraft:stripped_oak_log
setblock 393 101 276 minecraft:stripped_oak_log
fill 393 101 277 396 101 277 minecraft:red_terracotta
setblock 393 101 315 minecraft:red_terracotta
setblock 393 101 316 minecraft:stripped_oak_log
fill 394 101 276 394 104 276 minecraft:red_terracotta
fill 394 101 278 395 149 278 minecraft:stripped_oak_log
setblock 394 101 315 minecraft:stripped_oak_log
fill 394 101 316 394 104 316 minecraft:red_terracotta
fill 395 101 315 395 104 315 minecraft:red_terracotta
fill 397 101 277 397 111 277 minecraft:stripped_oak_log
setblock 398 101 276 minecraft:stripped_oak_log
setblock 398 101 280 minecraft:stripped_oak_log
setblock 398 101 316 minecraft:stripped_oak_log
setblock 399 101 276 minecraft:red_terracotta
fill 399 101 316 399 104 316 minecraft:red_terracotta
setblock 402 101 280 minecraft:stripped_oak_log
fill 408 101 303 408 102 304 minecraft:shroomlight
setblock 408 101 316 minecraft:stripped_oak_log
setblock 409 101 315 minecraft:stripped_oak_log
fill 409 101 316 409 104 316 minecraft:red_terracotta
fill 410 101 315 410 104 315 minecraft:red_terracotta
fill 411 101 293 411 104 293 minecraft:brown_terracotta
fill 411 101 296 411 104 296 minecraft:brown_terracotta
fill 411 101 314 411 104 314 minecraft:red_terracotta
fill 412 101 292 412 104 292 minecraft:brown_terracotta
fill 412 101 297 412 104 297 minecraft:brown_terracotta
setblock 413 101 316 minecraft:stripped_oak_log
setblock 414 101 305 minecraft:stripped_oak_log
fill 414 101 306 414 102 306 minecraft:red_terracotta
setblock 414 101 310 minecraft:stripped_oak_log
fill 414 101 311 414 103 311 minecraft:red_terracotta
setblock 414 101 315 minecraft:stripped_oak_log
fill 414 101 316 414 104 316 minecraft:red_terracotta
fill 415 101 297 415 104 297 minecraft:brown_terracotta
setblock 415 101 304 minecraft:stripped_oak_log
fill 415 101 305 415 103 305 minecraft:red_terracotta
setblock 415 101 309 minecraft:stripped_oak_log
fill 415 101 310 415 104 310 minecraft:red_terracotta
setblock 415 101 314 minecraft:stripped_oak_log
fill 415 101 315 415 104 315 minecraft:red_terracotta
setblock 416 101 284 minecraft:red_terracotta
setblock 416 101 288 minecraft:stripped_oak_log
fill 416 101 289 416 104 289 minecraft:red_terracotta
setblock 416 101 292 minecraft:red_terracotta
setblock 416 101 293 minecraft:stripped_oak_log
fill 416 101 296 416 104 296 minecraft:brown_terracotta
setblock 416 101 299 minecraft:red_terracotta
setblock 416 101 303 minecraft:stripped_oak_log
fill 416 101 304 416 104 304 minecraft:red_terracotta
setblock 416 101 308 minecraft:stripped_oak_log
fill 416 101 309 416 104 309 minecraft:red_terracotta
setblock 416 101 313 minecraft:stripped_oak_log
fill 416 101 314 416 104 314 minecraft:red_terracotta
setblock 417 101 282 minecraft:stripped_oak_log
fill 417 101 283 417 102 283 minecraft:red_terracotta
setblock 417 101 287 minecraft:stripped_oak_log
fill 417 101 288 417 104 288 minecraft:red_terracotta
setblock 417 101 292 minecraft:stripped_oak_log
fill 417 101 293 417 104 293 minecraft:red_terracotta
setblock 417 101 297 minecraft:stripped_oak_log
fill 417 101 298 417 104 298 minecraft:red_terracotta
setblock 417 101 302 minecraft:stripped_oak_log
fill 417 101 303 417 104 303 minecraft:red_terracotta
setblock 417 101 307 minecraft:stripped_oak_log
fill 417 101 308 417 104 308 minecraft:red_terracotta
setblock 417 101 312 minecraft:stripped_oak_log
fill 417 101 313 417 104 313 minecraft:red_terracotta
fill 377 102 282 377 102 285 minecraft:red_terracotta
setblock 377 102 286 minecraft:stripped_oak_log
fill 377 102 287 377 102 290 minecraft:red_terracotta
setblock 377 102 291 minecraft:stripped_oak_log
fill 377 102 292 377 102 295 minecraft:red_terracotta
setblock 377 102 296 minecraft:stripped_oak_log
fill 377 102 297 377 105 297 minecraft:red_terracotta
setblock 377 102 301 minecraft:stripped_oak_log
fill 377 102 302 377 103 302 minecraft:red_terracotta
setblock 377 102 306 minecraft:stripped_oak_log
fill 377 102 307 377 104 307 minecraft:red_terracotta
setblock 377 102 311 minecraft:stripped_oak_log
fill 377 102 312 377 105 312 minecraft:red_terracotta
setblock 378 102 285 minecraft:stripped_oak_log
fill 378 102 286 378 104 286 minecraft:red_terracotta
setblock 378 102 290 minecraft:stripped_oak_log
fill 378 102 291 378 105 291 minecraft:red_terracotta
setblock 379 102 278 minecraft:light[level=12]
setblock 379 102 285 minecraft:light[level=12]
setblock 379 102 292 minecraft:light[level=12]
setblock 379 102 299 minecraft:light[level=12]
setblock 379 102 306 minecraft:light[level=12]
setblock 379 102 313 minecraft:light[level=12]
setblock 386 102 278 minecraft:light[level=12]
setblock 386 102 285 minecraft:light[level=12]
setblock 386 102 292 minecraft:light[level=12]
setblock 386 102 299 minecraft:light[level=12]
setblock 386 102 306 minecraft:light[level=12]
setblock 386 102 313 minecraft:light[level=12]
fill 390 102 316 391 102 316 minecraft:red_terracotta
setblock 392 102 276 minecraft:stripped_oak_log
fill 392 102 277 395 102 277 minecraft:red_terracotta
setblock 392 102 316 minecraft:stripped_oak_log
fill 393 102 276 393 105 276 minecraft:red_terracotta
setblock 393 102 285 minecraft:light[level=12]
setblock 393 102 292 minecraft:light[level=12]
setblock 393 102 299 minecraft:light[level=12]
setblock 393 102 306 minecraft:light[level=12]
setblock 393 102 313 minecraft:light[level=12]
setblock 393 102 315 minecraft:stripped_oak_log
fill 393 102 316 393 105 316 minecraft:red_terracotta
fill 394 102 315 394 105 315 minecraft:red_terracotta
fill 396 102 277 396 109 277 minecraft:stripped_oak_log
setblock 397 102 276 minecraft:stripped_oak_log
setblock 397 102 316 minecraft:stripped_oak_log
fill 398 102 276 398 103 276 minecraft:red_terracotta
fill 398 102 316 398 105 316 minecraft:red_terracotta
setblock 400 102 278 minecraft:light[level=12]
setblock 400 102 285 minecraft:light[level=12]
setblock 400 102 292 minecraft:light[level=12]
setblock 400 102 299 minecraft:light[level=12]
setblock 400 102 306 minecraft:light[level=12]
setblock 400 102 313 minecraft:light[level=12]
setblock 407 102 278 minecraft:light[level=12]
setblock 407 102 285 minecraft:light[level=12]
setblock 407 102 292 minecraft:light[level=12]
setblock 407 102 299 minecraft:light[level=12]
setblock 407 102 306 minecraft:light[level=12]
setblock 407 102 313 minecraft:light[level=12]
setblock 407 102 316 minecraft:stripped_oak_log
setblock 408 102 315 minecraft:stripped_oak_log
fill 408 102 316 408 105 316 minecraft:red_terracotta
fill 409 102 315 409 105 315 minecraft:red_terracotta
fill 410 102 294 410 104 295 minecraft:brown_terracotta
fill 411 102 292 411 104 292 minecraft:brown_terracotta
fill 411 102 297 411 104 297 minecraft:brown_terracotta
fill 412 102 291 415 104 291 minecraft:brown_terracotta
setblock 412 102 316 minecraft:stripped_oak_log
fill 413 102 298 414 104 298 minecraft:brown_terracotta
setblock 413 102 315 minecraft:stripped_oak_log
fill 413 102 316 413 105 316 minecraft:red_terracotta
setblock 414 102 278 minecraft:light[level=12]
setblock 414 102 285 minecraft:light[level=12]
setblock 414 102 299 minecraft:light[level=12]
setblock 414 102 309 minecraft:stripped_oak_log
fill 414 102 310 414 103 310 minecraft:red_terracotta
setblock 414 102 313 minecraft:light[level=12]
setblock 414 102 314 minecraft:stripped_oak_log
fill 414 102 315 414 105 315 minecraft:red_terracotta
setblock 415 102 303 minecraft:stripped_oak_log
setblock 415 102 304 minecraft:red_terracotta
setblock 415 102 308 minecraft:stripped_oak_log
fill 415 102 309 415 105 309 minecraft:red_terracotta
setblock 415 102 313 minecraft:stripped_oak_log
setblock 416 102 287 minecraft:stripped_oak_log
fill 416 102 288 416 105 288 minecraft:red_terracotta
setblock 416 102 292 minecraft:stripped_oak_log
fill 416 102 293 416 105 293 minecraft:red_terracotta
fill 416 102 297 416 104 297 minecraft:brown_terracotta
setblock 416 102 302 minecraft:stripped_oak_log
fill 416 102 303 416 103 303 minecraft:red_terracotta
setblock 416 102 307 minecraft:stripped_oak_log
fill 416 102 308 416 105 308 minecraft:red_terracotta
setblock 416 102 312 minecraft:stripped_oak_log
fill 416 102 313 416 105 313 minecraft:red_terracotta
setblock 417 102 286 minecraft:stripped_oak_log
fill 417 102 287 417 105 287 minecraft:red_terracotta
setblock 417 102 291 minecraft:stripped_oak_log
fill 417 102 292 417 105 292 minecraft:red_terracotta
setblock 417 102 296 minecraft:stripped_oak_log
fill 417 102 297 417 105 297 minecraft:red_terracotta
setblock 417 102 301 minecraft:stripped_oak_log
fill 417 102 302 417 105 302 minecraft:red_terracotta
setblock 417 102 306 minecraft:stripped_oak_log
fill 417 102 307 417 105 307 minecraft:red_terracotta
setblock 417 102 311 minecraft:stripped_oak_log
fill 417 102 312 417 105 312 minecraft:red_terracotta
setblock 417 102 316 minecraft:stripped_oak_log
fill 377 103 283 377 103 284 minecraft:red_terracotta
setblock 377 103 285 minecraft:stripped_oak_log
fill 377 103 286 377 103 289 minecraft:red_terracotta
setblock 377 103 290 minecraft:stripped_oak_log
fill 377 103 291 377 103 294 minecraft:red_terracotta
setblock 377 103 295 minecraft:stripped_oak_log
fill 377 103 296 377 106 296 minecraft:red_terracotta
setblock 377 103 300 minecraft:stripped_oak_log
setblock 377 103 301 minecraft:red_terracotta
setblock 377 103 305 minecraft:stripped_oak_log
fill 377 103 306 377 104 306 minecraft:red_terracotta
setblock 377 103 310 minecraft:stripped_oak_log
fill 377 103 311 377 106 311 minecraft:red_terracotta
setblock 378 103 285 minecraft:red_terracotta
setblock 378 103 289 minecraft:stripped_oak_log
fill 378 103 290 378 106 290 minecraft:red_terracotta
setblock 390 103 316 minecraft:red_terracotta
setblock 391 103 276 minecraft:stripped_oak_log
setblock 391 103 316 minecraft:stripped_oak_log
fill 392 103 276 392 105 277 minecraft:red_terracotta
setblock 392 103 315 minecraft:stripped_oak_log
fill 392 103 316 392 106 316 minecraft:red_terracotta
fill 393 103 277 394 103 277 minecraft:red_terracotta
fill 393 103 315 393 106 315 minecraft:red_terracotta
fill 395 103 277 395 108 277 minecraft:stripped_oak_log
setblock 396 103 276 minecraft:stripped_oak_log
setblock 396 103 316 minecraft:stripped_oak_log
fill 397 103 276 397 106 276 minecraft:red_terracotta
setblock 397 103 315 minecraft:stripped_oak_log
fill 397 103 316 397 106 316 minecraft:red_terracotta
setblock 405 103 316 minecraft:red_terracotta
setblock 406 103 316 minecraft:stripped_oak_log
fill 407 103 316 407 106 316 minecraft:red_terracotta
setblock 408 103 304 minecraft:shroomlight
fill 408 103 315 408 106 315 minecraft:red_terracotta
fill 410 103 293 410 104 293 minecraft:brown_terracotta
fill 410 103 296 410 104 296 minecraft:brown_terracotta
fill 410 103 314 410 105 314 minecraft:red_terracotta
fill 411 103 291 411 104 291 minecraft:brown_terracotta
setblock 411 103 316 minecraft:stripped_oak_log
fill 412 103 298 412 104 298 minecraft:brown_terracotta
setblock 412 103 315 minecraft:stripped_oak_log
fill 412 103 316 412 106 316 minecraft:red_terracotta
setblock 413 103 314 minecraft:stripped_oak_log
fill 413 103 315 413 106 315 minecraft:red_terracotta
setblock 414 103 307 minecraft:iron_bars
setblock 414 103 308 minecraft:stripped_oak_log
setblock 414 103 309 minecraft:red_terracotta
fill 414 103 314 414 106 314 minecraft:red_terracotta
fill 415 103 298 415 104 298 minecraft:brown_terracotta
setblock 415 103 307 minecraft:stripped_oak_log
fill 415 103 308 415 105 308 minecraft:red_terracotta
setblock 415 103 312 minecraft:stripped_oak_log
fill 415 103 313 415 106 313 minecraft:red_terracotta
setblock 416 103 287 minecraft:red_terracotta
setblock 416 103 291 minecraft:stripped_oak_log
fill 416 103 292 416 106 292 minecraft:red_terracotta
setblock 416 103 302 minecraft:red_terracotta
setblock 416 103 306 minecraft:stripped_oak_log
fill 416 103 307 416 106 307 minecraft:red_terracotta
setblock 416 103 311 minecraft:stripped_oak_log
fill 416 103 312 416 106 312 minecraft:red_terracotta
setblock 416 103 316 minecraft:stripped_oak_log
setblock 417 103 285 minecraft:stripped_oak_log
fill 417 103 286 417 105 286 minecraft:red_terracotta
setblock 417 103 290 minecraft:stripped_oak_log
fill 417 103 291 417 106 291 minecraft:red_terracotta
setblock 417 103 295 minecraft:stripped_oak_log
fill 417 103 296 417 106 296 minecraft:red_terracotta
setblock 417 103 300 minecraft:stripped_oak_log
fill 417 103 301 417 106 301 minecraft:red_terracotta
setblock 417 103 305 minecraft:stripped_oak_log
fill 417 103 306 417 106 306 minecraft:red_terracotta
setblock 417 103 310 minecraft:stripped_oak_log
fill 417 103 311 417 106 311 minecraft:red_terracotta
setblock 417 103 315 minecraft:stripped_oak_log
setblock 417 103 316 minecraft:red_terracotta
fill 376 104 275 376 107 317 minecraft:brown_terracotta
fill 377 104 275 418 107 275 minecraft:brown_terracotta
setblock 377 104 283 minecraft:red_terracotta
setblock 377 104 284 minecraft:stripped_oak_log
fill 377 104 285 377 104 288 minecraft:red_terracotta
setblock 377 104 289 minecraft:stripped_oak_log
fill 377 104 290 377 104 293 minecraft:red_terracotta
setblock 377 104 294 minecraft:stripped_oak_log
fill 377 104 295 377 107 295 minecraft:red_terracotta
setblock 377 104 305 minecraft:red_terracotta
setblock 377 104 309 minecraft:stripped_oak_log
fill 377 104 310 377 106 310 minecraft:red_terracotta
fill 377 104 317 418 107 317 minecraft:brown_terracotta
setblock 378 104 288 minecraft:stripped_oak_log
fill 378 104 289 378 107 289 minecraft:red_terracotta
setblock 378 104 293 minecraft:stripped_oak_log
setblock 379 104 278 minecraft:light[level=15]
setblock 379 104 286 minecraft:light[level=15]
setblock 379 104 294 minecraft:light[level=15]
setblock 379 104 302 minecraft:light[level=15]
setblock 379 104 310 minecraft:light[level=15]
setblock 387 104 278 minecraft:light[level=15]
setblock 387 104 286 minecraft:light[level=15]
setblock 387 104 294 minecraft:light[level=15]
setblock 387 104 302 minecraft:light[level=15]
setblock 387 104 310 minecraft:light[level=15]
fill 388 104 276 388 105 276 minecraft:red_terracotta
setblock 389 104 316 minecraft:red_terracotta
setblock 390 104 276 minecraft:stripped_oak_log
setblock 390 104 316 minecraft:stripped_oak_log
fill 391 104 276 391 106 277 minecraft:red_terracotta
setblock 391 104 315 minecraft:stripped_oak_log
fill 391 104 316 391 107 316 minecraft:red_terracotta
fill 392 104 315 392 107 315 minecraft:red_terracotta
setblock 393 104 277 minecraft:red_terracotta
setblock 394 104 277 minecraft:stripped_oak_log
setblock 395 104 276 minecraft:stripped_oak_log
setblock 395 104 286 minecraft:light[level=15]
setblock 395 104 294 minecraft:light[level=15]
setblock 395 104 302 minecraft:light[level=15]
setblock 395 104 310 minecraft:light[level=15]
setblock 395 104 316 minecraft:stripped_oak_log
fill 396 104 276 396 107 276 minecraft:red_terracotta
setblock 396 104 315 minecraft:stripped_oak_log
fill 396 104 316 396 107 316 minecraft:red_terracotta
fill 397 104 315 397 107 315 minecraft:red_terracotta
setblock 400 104 316 minecraft:stripped_oak_log
fill 401 104 316 404 104 316 minecraft:red_terracotta
setblock 403 104 278 minecraft:light[level=15]
setblock 403 104 286 minecraft:light[level=15]
setblock 403 104 294 minecraft:light[level=15]
setblock 403 104 302 minecraft:light[level=15]
setblock 403 104 310 minecraft:light[level=15]
setblock 405 104 316 minecraft:stripped_oak_log
setblock 406 104 315 minecraft:stripped_oak_log
fill 406 104 316 406 107 316 minecraft:red_terracotta
fill 407 104 315 407 107 315 minecraft:red_terracotta
fill 409 104 294 409 104 295 minecraft:brown_terracotta
fill 409 104 314 409 106 314 minecraft:red_terracotta
setblock 410 104 292 minecraft:brown_terracotta
setblock 410 104 297 minecraft:brown_terracotta
setblock 410 104 316 minecraft:stripped_oak_log
setblock 411 104 278 minecraft:light[level=15]
setblock 411 104 286 minecraft:light[level=15]
setblock 411 104 298 minecraft:brown_terracotta
setblock 411 104 302 minecraft:light[level=15]
setblock 411 104 310 minecraft:light[level=15]
setblock 411 104 315 minecraft:stripped_oak_log
fill 411 104 316 411 107 316 minecraft:red_terracotta
fill 412 104 290 415 104 290 minecraft:brown_terracotta
setblock 412 104 314 minecraft:stripped_oak_log
fill 412 104 315 412 107 315 minecraft:red_terracotta
fill 413 104 299 414 104 299 minecraft:brown_terracotta
fill 413 104 314 413 107 314 minecraft:red_terracotta
setblock 415 104 306 minecraft:stripped_oak_log
fill 415 104 307 415 105 307 minecraft:red_terracotta
setblock 415 104 311 minecraft:stripped_oak_log
fill 415 104 312 415 107 312 minecraft:red_terracotta
setblock 415 104 316 minecraft:stripped_oak_log
setblock 416 104 290 minecraft:stripped_oak_log
fill 416 104 291 416 107 291 minecraft:red_terracotta
setblock 416 104 294 minecraft:red_terracotta
setblock 416 104 295 minecraft:brown_terracotta
setblock 416 104 298 minecraft:brown_terracotta
setblock 416 104 305 minecraft:stripped_oak_log
fill 416 104 306 416 106 306 minecraft:red_terracotta
setblock 416 104 310 minecraft:stripped_oak_log
fill 416 104 311 416 107 311 minecraft:red_terracotta
fill 416 104 316 416 107 316 minecraft:red_terracotta
setblock 417 104 289 minecraft:stripped_oak_log
fill 417 104 290 417 107 290 minecraft:red_terracotta
setblock 417 104 294 minecraft:stripped_oak_log
fill 417 104 295 417 107 295 minecraft:red_terracotta
setblock 417 104 299 minecraft:stripped_oak_log
fill 417 104 300 417 107 300 minecraft:red_terracotta
setblock 417 104 304 minecraft:stripped_oak_log
fill 417 104 305 417 107 305 minecraft:red_terracotta
setblock 417 104 309 minecraft:stripped_oak_log
fill 417 104 310 417 107 310 minecraft:red_terracotta
setblock 417 104 314 minecraft:stripped_oak_log
fill 417 104 315 417 107 315 minecraft:red_terracotta
fill 418 104 276 418 107 316 minecraft:brown_terracotta
fill 377 105 284 377 105 287 minecraft:red_terracotta
setblock 377 105 288 minecraft:stripped_oak_log
fill 377 105 289 377 105 292 minecraft:red_terracotta
setblock 377 105 293 minecraft:stripped_oak_log
fill 377 105 294 377 108 294 minecraft:red_terracotta
setblock 377 105 308 minecraft:stripped_oak_log
setblock 377 105 309 minecraft:red_terracotta
setblock 378 105 287 minecraft:stripped_oak_log
fill 378 105 288 378 108 288 minecraft:red_terracotta
setblock 378 105 292 minecraft:stripped_oak_log
fill 378 105 293 378 108 293 minecraft:red_terracotta
fill 387 105 276 387 106 276 minecraft:red_terracotta
fill 387 105 316 388 105 316 minecraft:red_terracotta
setblock 389 105 276 minecraft:stripped_oak_log
setblock 389 105 315 minecraft:red_terracotta
setblock 389 105 316 minecraft:stripped_oak_log
fill 390 105 276 390 107 277 minecraft:red_terracotta
setblock 390 105 315 minecraft:stripped_oak_log
fill 390 105 316 390 108 316 minecraft:red_terracotta
fill 391 105 315 391 108 315 minecraft:red_terracotta
setblock 393 105 277 minecraft:stripped_oak_log
setblock 394 105 276 minecraft:stripped_oak_log
fill 394 105 277 394 108 277 minecraft:red_terracotta
setblock 394 105 316 minecraft:stripped_oak_log
fill 395 105 276 395 108 276 minecraft:red_terracotta
setblock 395 105 315 minecraft:stripped_oak_log
fill 395 105 316 395 108 316 minecraft:red_terracotta
fill 396 105 315 396 108 315 minecraft:red_terracotta
fill 398 105 315 398 106 315 minecraft:red_terracotta
setblock 399 105 316 minecraft:stripped_oak_log
fill 400 105 316 403 105 316 minecraft:red_terracotta
fill 401 105 313 401 106 315 minecraft:iron_bars
setblock 404 105 316 minecraft:stripped_oak_log
setblock 405 105 315 minecraft:stripped_oak_log
fill 405 105 316 405 108 316 minecraft:red_terracotta
fill 406 105 315 406 108 315 minecraft:red_terracotta
fill 407 105 314 408 107 314 minecraft:red_terracotta
setblock 409 105 316 minecraft:stripped_oak_log
setblock 410 105 315 minecraft:stripped_oak_log
fill 410 105 316 410 108 316 minecraft:red_terracotta
setblock 411 105 314 minecraft:stripped_oak_log
fill 411 105 315 411 108 315 minecraft:red_terracotta
fill 412 105 314 412 108 314 minecraft:red_terracotta
fill 413 105 293 413 107 293 minecraft:stripped_oak_log
fill 413 105 296 413 107 296 minecraft:stripped_oak_log
setblock 414 105 316 minecraft:stripped_oak_log
fill 415 105 294 416 105 294 minecraft:stripped_oak_log
setblock 415 105 310 minecraft:stripped_oak_log
fill 415 105 311 415 107 311 minecraft:red_terracotta
setblock 415 105 315 minecraft:stripped_oak_log
fill 415 105 316 415 108 316 minecraft:red_terracotta
setblock 416 105 289 minecraft:stripped_oak_log
fill 416 105 290 416 108 290 minecraft:red_terracotta
fill 416 105 295 416 108 295 minecraft:red_terracotta
setblock 416 105 305 minecraft:red_terracotta
setblock 416 105 309 minecraft:stripped_oak_log
fill 416 105 310 416 108 310 minecraft:red_terracotta
setblock 416 105 314 minecraft:stripped_oak_log
setblock 417 105 288 minecraft:stripped_oak_log
fill 417 105 289 417 108 289 minecraft:red_terracotta
setblock 417 105 293 minecraft:stripped_oak_log
fill 417 105 294 417 108 294 minecraft:red_terracotta
setblock 417 105 298 minecraft:stripped_oak_log
fill 417 105 299 417 108 299 minecraft:red_terracotta
setblock 417 105 303 minecraft:stripped_oak_log
fill 417 105 304 417 107 304 minecraft:red_terracotta
setblock 417 105 308 minecraft:stripped_oak_log
fill 417 105 309 417 108 309 minecraft:red_terracotta
setblock 417 105 313 minecraft:stripped_oak_log
fill 417 105 314 417 108 314 minecraft:red_terracotta
fill 377 106 284 377 106 286 minecraft:red_terracotta
setblock 377 106 287 minecraft:stripped_oak_log
fill 377 106 288 377 106 291 minecraft:red_terracotta
setblock 377 106 292 minecraft:stripped_oak_log
fill 377 106 293 377 109 293 minecraft:red_terracotta
setblock 377 106 297 minecraft:stripped_oak_log
fill 377 106 298 377 109 298 minecraft:red_terracotta
setblock 377 106 312 minecraft:stripped_oak_log
setblock 378 106 287 minecraft:red_terracotta
setblock 378 106 291 minecraft:stripped_oak_log
fill 378 106 292 378 109 292 minecraft:red_terracotta
fill 378 106 294 378 107 294 minecraft:red_terracotta
fill 386 106 276 386 107 276 minecraft:red_terracotta
fill 386 106 316 387 106 316 minecraft:red_terracotta
setblock 388 106 276 minecraft:stripped_oak_log
fill 388 106 277 389 108 277 minecraft:red_terracotta
setblock 388 106 315 minecraft:red_terracotta
setblock 388 106 316 minecraft:stripped_oak_log
fill 389 106 276 389 109 276 minecraft:red_terracotta
setblock 389 106 315 minecraft:stripped_oak_log
fill 389 106 316 389 109 316 minecraft:red_terracotta
fill 390 106 315 390 109 315 minecraft:red_terracotta
fill 391 106 314 394 106 314 minecraft:red_terracotta
setblock 392 106 276 minecraft:red_terracotta
setblock 392 106 277 minecraft:stripped_oak_log
setblock 393 106 276 minecraft:stripped_oak_log
fill 393 106 277 393 109 277 minecraft:red_terracotta
setblock 393 106 316 minecraft:stripped_oak_log
fill 394 106 276 394 109 276 minecraft:red_terracotta
setblock 394 106 315 minecraft:stripped_oak_log
fill 394 106 316 394 109 316 minecraft:red_terracotta
fill 395 106 315 395 109 315 minecraft:red_terracotta
setblock 398 106 316 minecraft:stripped_oak_log
setblock 399 106 315 minecraft:stripped_oak_log
fill 399 106 316 402 106 316 minecraft:red_terracotta
setblock 403 106 315 minecraft:red_terracotta
setblock 403 106 316 minecraft:stripped_oak_log
setblock 404 106 315 minecraft:stripped_oak_log
fill 404 106 316 404 109 316 minecraft:red_terracotta
fill 405 106 315 405 109 315 minecraft:red_terracotta
fill 406 106 314 406 109 314 minecraft:red_terracotta
setblock 408 106 316 minecraft:stripped_oak_log
fill 409 106 276 411 107 276 minecraft:red_terracotta
fill 409 106 313 410 106 313 minecraft:red_terracotta
setblock 409 106 315 minecraft:stripped_oak_log
fill 409 106 316 409 109 316 minecraft:red_terracotta
setblock 410 106 314 minecraft:stripped_oak_log
fill 410 106 315 410 109 315 minecraft:red_terracotta
setblock 411 106 313 minecraft:stripped_oak_log
fill 411 106 314 411 109 314 minecraft:red_terracotta
fill 412 106 313 412 109 313 minecraft:red_terracotta
setblock 413 106 316 minecraft:stripped_oak_log
setblock 414 106 315 minecraft:stripped_oak_log
fill 414 106 316 414 109 316 minecraft:red_terracotta
setblock 415 106 294 minecraft:stripped_oak_log
setblock 415 106 309 minecraft:stripped_oak_log
fill 415 106 310 415 107 310 minecraft:red_terracotta
fill 415 106 315 415 109 315 minecraft:red_terracotta
fill 416 106 289 416 109 289 minecraft:red_terracotta
setblock 416 106 293 minecraft:stripped_oak_log
fill 416 106 294 416 109 294 minecraft:red_terracotta
fill 416 106 296 416 107 296 minecraft:red_terracotta
setblock 416 106 308 minecraft:stripped_oak_log
fill 416 106 309 416 108 309 minecraft:red_terracotta
setblock 416 106 313 minecraft:stripped_oak_log
fill 416 106 314 416 109 314 minecraft:red_terracotta
setblock 417 106 287 minecraft:stripped_oak_log
fill 417 106 288 417 109 288 minecraft:red_terracotta
setblock 417 106 292 minecraft:stripped_oak_log
fill 417 106 293 417 109 293 minecraft:red_terracotta
setblock 417 106 297 minecraft:stripped_oak_log
fill 417 106 298 417 109 298 minecraft:red_terracotta
setblock 417 106 302 minecraft:stripped_oak_log
fill 417 106 303 417 107 303 minecraft:red_terracotta
setblock 417 106 307 minecraft:stripped_oak_log
fill 417 106 308 417 109 308 minecraft:red_terracotta
setblock 417 106 312 minecraft:stripped_oak_log
fill 417 106 313 417 109 313 minecraft:red_terracotta
setblock 417 106 316 minecraft:red_terracotta
setblock 377 107 285 minecraft:red_terracotta
setblock 377 107 286 minecraft:stripped_oak_log
fill 377 107 287 377 107 290 minecraft:red_terracotta
setblock 377 107 291 minecraft:stripped_oak_log
fill 377 107 292 377 110 292 minecraft:red_terracotta
setblock 377 107 296 minecraft:stripped_oak_log
fill 377 107 297 377 110 297 minecraft:red_terracotta
setblock 378 107 290 minecraft:stripped_oak_log
fill 378 107 291 378 110 291 minecraft:red_terracotta
setblock 378 107 295 minecraft:stripped_oak_log
fill 384 107 276 385 108 276 minecraft:red_terracotta
fill 385 107 316 386 107 316 minecraft:red_terracotta
setblock 387 107 276 minecraft:stripped_oak_log
fill 387 107 277 387 110 277 minecraft:red_terracotta
setblock 387 107 315 minecraft:red_terracotta
setblock 387 107 316 minecraft:stripped_oak_log
fill 388 107 276 388 110 276 minecraft:red_terracotta
setblock 388 107 315 minecraft:stripped_oak_log
fill 388 107 316 388 110 316 minecraft:red_terracotta
setblock 389 107 314 minecraft:stripped_oak_log
fill 389 107 315 389 110 315 minecraft:red_terracotta
fill 390 107 314 393 107 314 minecraft:red_terracotta
setblock 391 107 276 minecraft:red_terracotta
setblock 391 107 277 minecraft:stripped_oak_log
setblock 392 107 276 minecraft:stripped_oak_log
fill 392 107 277 392 110 277 minecraft:red_terracotta
setblock 392 107 316 minecraft:stripped_oak_log
fill 393 107 276 393 110 276 minecraft:red_terracotta
setblock 393 107 315 minecraft:stripped_oak_log
fill 393 107 316 393 110 316 minecraft:red_terracotta
setblock 394 107 314 minecraft:stripped_oak_log
fill 394 107 315 394 110 315 minecraft:red_terracotta
fill 395 107 314 395 110 314 minecraft:red_terracotta
setblock 397 107 276 minecraft:stripped_oak_log
setblock 397 107 316 minecraft:stripped_oak_log
fill 398 107 276 398 110 276 minecraft:red_terracotta
setblock 398 107 315 minecraft:stripped_oak_log
fill 398 107 316 401 107 316 minecraft:red_terracotta
fill 399 107 315 402 107 315 minecraft:red_terracotta
setblock 402 107 316 minecraft:stripped_oak_log
setblock 403 107 315 minecraft:stripped_oak_log
fill 403 107 316 403 110 316 minecraft:red_terracotta
setblock 404 107 314 minecraft:stripped_oak_log
fill 404 107 315 404 110 315 minecraft:red_terracotta
fill 405 107 314 405 110 314 minecraft:red_terracotta
setblock 406 107 276 minecraft:red_terracotta
setblock 407 107 276 minecraft:stripped_oak_log
setblock 407 107 316 minecraft:stripped_oak_log
fill 408 107 276 408 110 276 minecraft:red_terracotta
fill 408 107 313 409 107 313 minecraft:red_terracotta
setblock 408 107 315 minecraft:stripped_oak_log
fill 408 107 316 408 110 316 minecraft:red_terracotta
setblock 409 107 314 minecraft:stripped_oak_log
fill 409 107 315 409 110 315 minecraft:red_terracotta
setblock 410 107 313 minecraft:stripped_oak_log
fill 410 107 314 410 110 314 minecraft:red_terracotta
fill 411 107 313 411 110 313 minecraft:red_terracotta
setblock 412 107 276 minecraft:stripped_oak_log
setblock 412 107 316 minecraft:stripped_oak_log
setblock 413 107 315 minecraft:stripped_oak_log
fill 413 107 316 413 110 316 minecraft:red_terracotta
setblock 414 107 314 minecraft:stripped_oak_log
fill 414 107 315 414 110 315 minecraft:red_terracotta
setblock 415 107 292 minecraft:red_terracotta
setblock 415 107 293 minecraft:stripped_oak_log
setblock 416 107 292 minecraft:stripped_oak_log
fill 416 107 293 416 110 293 minecraft:red_terracotta
setblock 416 107 297 minecraft:stripped_oak_log
setblock 416 107 307 minecraft:stripped_oak_log
setblock 416 107 308 minecraft:red_terracotta
setblock 416 107 312 minecraft:stripped_oak_log
fill 416 107 313 416 110 313 minecraft:red_terracotta
fill 417 107 287 417 110 287 minecraft:red_terracotta
setblock 417 107 291 minecraft:stripped_oak_log
fill 417 107 292 417 110 292 minecraft:red_terracotta
setblock 417 107 296 minecraft:stripped_oak_log
fill 417 107 297 417 110 297 minecraft:red_terracotta
setblock 417 107 301 minecraft:stripped_oak_log
setblock 417 107 306 minecraft:stripped_oak_log
fill 417 107 307 417 109 307 minecraft:red_terracotta
setblock 417 107 311 minecraft:stripped_oak_log
fill 417 107 312 417 110 312 minecraft:red_terracotta
setblock 417 107 316 minecraft:stripped_oak_log
fill 376 108 275 376 111 317 minecraft:light_gray_terracotta
fill 377 108 275 418 111 275 minecraft:light_gray_terracotta
setblock 377 108 285 minecraft:stripped_oak_log
fill 377 108 286 377 108 289 minecraft:red_terracotta
setblock 377 108 290 minecraft:stripped_oak_log
fill 377 108 291 377 111 291 minecraft:red_terracotta
setblock 377 108 295 minecraft:stripped_oak_log
fill 377 108 296 377 111 296 minecraft:red_terracotta
setblock 377 108 299 minecraft:red_terracotta
fill 377 108 317 418 111 317 minecraft:light_gray_terracotta
setblock 378 108 289 minecraft:stripped_oak_log
fill 378 108 290 378 111 290 minecraft:red_terracotta
setblock 378 108 294 minecraft:stripped_oak_log
fill 378 108 295 378 111 295 minecraft:red_terracotta
setblock 379 108 278 minecraft:light[level=12]
setblock 379 108 285 minecraft:light[level=12]
setblock 379 108 292 minecraft:light[level=12]
setblock 379 108 299 minecraft:light[level=12]
setblock 379 108 306 minecraft:light[level=12]
setblock 379 108 313 minecraft:light[level=12]
fill 383 108 276 383 110 276 minecraft:red_terracotta
fill 383 108 316 385 108 316 minecraft:red_terracotta
setblock 385 108 277 minecraft:stripped_oak_log
fill 385 108 315 386 108 315 minecraft:red_terracotta
setblock 386 108 276 minecraft:stripped_oak_log
fill 386 108 277 386 111 277 minecraft:red_terracotta
setblock 386 108 278 minecraft:light[level=12]
setblock 386 108 285 minecraft:light[level=12]
setblock 386 108 292 minecraft:light[level=12]
setblock 386 108 299 minecraft:light[level=12]
setblock 386 108 306 minecraft:light[level=12]
setblock 386 108 313 minecraft:light[level=12]
setblock 386 108 316 minecraft:stripped_oak_log
fill 387 108 276 387 111 276 minecraft:red_terracotta
setblock 387 108 315 minecraft:stripped_oak_log
fill 387 108 316 387 111 316 minecraft:red_terracotta
setblock 388 108 314 minecraft:stripped_oak_log
fill 388 108 315 388 111 315 minecraft:red_terracotta
setblock 389 108 278 minecraft:stripped_oak_log
fill 389 108 314 392 108 314 minecraft:red_terracotta
setblock 390 108 276 minecraft:red_terracotta
setblock 390 108 277 minecraft:stripped_oak_log
fill 390 108 278 391 110 278 minecraft:red_terracotta
setblock 391 108 276 minecraft:stripped_oak_log
fill 391 108 277 391 111 277 minecraft:red_terracotta
setblock 391 108 316 minecraft:stripped_oak_log
fill 392 108 276 392 111 276 minecraft:red_terracotta
setblock 392 108 315 minecraft:stripped_oak_log
fill 392 108 316 392 111 316 minecraft:red_terracotta
setblock 393 108 285 minecraft:light[level=12]
setblock 393 108 292 minecraft:light[level=12]
setblock 393 108 299 minecraft:light[level=12]
setblock 393 108 306 minecraft:light[level=12]
setblock 393 108 313 minecraft:light[level=12]
setblock 393 108 314 minecraft:stripped_oak_log
fill 393 108 315 393 111 315 minecraft:red_terracotta
fill 394 108 314 394 111 314 minecraft:red_terracotta
setblock 396 108 276 minecraft:stripped_oak_log
fill 396 108 314 396 109 314 minecraft:red_terracotta
setblock 396 108 316 minecraft:stripped_oak_log
fill 397 108 276 397 111 276 minecraft:red_terracotta
setblock 397 108 315 minecraft:stripped_oak_log
fill 397 108 316 400 108 316 minecraft:red_terracotta
fill 398 108 315 401 108 315 minecraft:red_terracotta
fill 399 108 276 400 108 276 minecraft:red_terracotta
setblock 400 108 278 minecraft:light[level=12]
setblock 400 108 285 minecraft:light[level=12]
setblock 400 108 292 minecraft:light[level=12]
setblock 400 108 299 minecraft:light[level=12]
setblock 400 108 306 minecraft:light[level=12]
setblock 400 108 313 minecraft:light[level=12]
setblock 401 108 316 minecraft:stripped_oak_log
setblock 402 108 315 minecraft:stripped_oak_log
fill 402 108 316 402 111 316 minecraft:red_terracotta
fill 403 108 276 405 108 276 minecraft:red_terracotta
setblock 403 108 314 minecraft:stripped_oak_log
fill 403 108 315 403 111 315 minecraft:red_terracotta
fill 404 108 314 404 111 314 minecraft:red_terracotta
setblock 406 108 276 minecraft:stripped_oak_log
fill 406 108 313 408 108 313 minecraft:red_terracotta
setblock 406 108 316 minecraft:stripped_oak_log
fill 407 108 276 407 111 276 minecraft:red_terracotta
setblock 407 108 278 minecraft:light[level=12]
setblock 407 108 285 minecraft:light[level=12]
setblock 407 108 292 minecraft:light[level=12]
setblock 407 108 299 minecraft:light[level=12]
setblock 407 108 306 minecraft:light[level=12]
setblock 407 108 314 minecraft:red_terracotta
setblock 407 108 315 minecraft:stripped_oak_log
fill 407 108 316 407 111 316 minecraft:red_terracotta
setblock 408 108 314 minecraft:stripped_oak_log
fill 408 108 315 408 111 315 minecraft:red_terracotta
fill 409 108 276 410 108 276 minecraft:red_terracotta
setblock 409 108 313 minecraft:stripped_oak_log
fill 409 108 314 409 111 314 minecraft:red_terracotta
fill 410 108 313 410 111 313 minecraft:red_terracotta
setblock 411 108 276 minecraft:stripped_oak_log
setblock 411 108 316 minecraft:stripped_oak_log
fill 412 108 276 413 110 276 minecraft:red_terracotta
setblock 412 108 315 minecraft:stripped_oak_log
fill 412 108 316 412 111 316 minecraft:red_terracotta
setblock 413 108 314 minecraft:stripped_oak_log
fill 413 108 315 413 111 315 minecraft:red_terracotta
setblock 414 108 278 minecraft:light[level=12]
setblock 414 108 285 minecraft:light[level=12]
setblock 414 108 292 minecraft:light[level=12]
setblock 414 108 299 minecraft:light[level=12]
setblock 414 108 306 minecraft:light[level=12]
setblock 414 108 313 minecraft:light[level=12]
fill 414 108 314 414 110 314 minecraft:red_terracotta
setblock 415 108 291 minecraft:red_terracotta
setblock 415 108 292 minecraft:stripped_oak_log
fill 415 108 293 415 108 296 minecraft:red_terracotta
setblock 416 108 291 minecraft:stripped_oak_log
fill 416 108 292 416 111 292 minecraft:red_terracotta
setblock 416 108 296 minecraft:stripped_oak_log
fill 416 108 297 416 110 298 minecraft:red_terracotta
setblock 416 108 311 minecraft:stripped_oak_log
fill 416 108 312 416 110 312 minecraft:red_terracotta
setblock 416 108 315 minecraft:red_terracotta
setblock 416 108 316 minecraft:stripped_oak_log
setblock 417 108 290 minecraft:stripped_oak_log
fill 417 108 291 417 111 291 minecraft:red_terracotta
setblock 417 108 295 minecraft:stripped_oak_log
fill 417 108 296 417 111 296 minecraft:red_terracotta
setblock 417 108 300 minecraft:stripped_oak_log
fill 417 108 301 417 110 302 minecraft:red_terracotta
setblock 417 108 305 minecraft:stripped_oak_log
setblock 417 108 306 minecraft:red_terracotta
setblock 417 108 310 minecraft:stripped_oak_log
fill 417 108 311 417 111 311 minecraft:red_terracotta
setblock 417 108 315 minecraft:stripped_oak_log
fill 417 108 316 417 111 316 minecraft:red_terracotta
fill 418 108 276 418 111 316 minecraft:light_gray_terracotta
fill 377 109 285 377 109 288 minecraft:red_terracotta
setblock 377 109 289 minecraft:stripped_oak_log
fill 377 109 290 377 112 290 minecraft:red_terracotta
setblock 377 109 294 minecraft:stripped_oak_log
fill 377 109 295 377 112 295 minecraft:red_terracotta
setblock 377 109 299 minecraft:stripped_oak_log
setblock 377 109 314 minecraft:stripped_oak_log
fill 377 109 315 377 112 315 minecraft:red_terracotta
setblock 378 109 288 minecraft:stripped_oak_log
fill 378 109 289 378 111 289 minecraft:red_terracotta
setblock 378 109 293 minecraft:stripped_oak_log
fill 378 109 294 378 112 294 minecraft:red_terracotta
fill 378 109 296 378 110 296 minecraft:red_terracotta
fill 379 109 313 379 117 313 minecraft:brown_terracotta
setblock 380 109 276 minecraft:stripped_oak_log
fill 381 109 276 382 111 276 minecraft:red_terracotta
fill 381 109 316 384 109 316 minecraft:red_terracotta
setblock 384 109 276 minecraft:red_terracotta
setblock 384 109 277 minecraft:stripped_oak_log
fill 384 109 315 385 109 315 minecraft:red_terracotta
setblock 385 109 276 minecraft:stripped_oak_log
fill 385 109 277 385 112 277 minecraft:red_terracotta
setblock 385 109 316 minecraft:stripped_oak_log
fill 386 109 276 386 112 276 minecraft:red_terracotta
setblock 386 109 314 minecraft:red_terracotta
setblock 386 109 315 minecraft:stripped_oak_log
fill 386 109 316 386 112 316 minecraft:red_terracotta
setblock 387 109 278 minecraft:red_terracotta
setblock 387 109 314 minecraft:stripped_oak_log
fill 387 109 315 387 112 315 minecraft:red_terracotta
setblock 388 109 277 minecraft:red_terracotta
setblock 388 109 278 minecraft:stripped_oak_log
fill 388 109 314 391 109 314 minecraft:red_terracotta
setblock 389 109 277 minecraft:stripped_oak_log
fill 389 109 278 389 112 278 minecraft:red_terracotta
setblock 390 109 276 minecraft:stripped_oak_log
fill 390 109 277 390 112 277 minecraft:red_terracotta
setblock 390 109 316 minecraft:stripped_oak_log
fill 391 109 276 391 112 276 minecraft:red_terracotta
setblock 391 109 315 minecraft:stripped_oak_log
fill 391 109 316 391 112 316 minecraft:red_terracotta
setblock 392 109 278 minecraft:red_terracotta
setblock 392 109 314 minecraft:stripped_oak_log
fill 392 109 315 392 112 315 minecraft:red_terracotta
setblock 393 109 278 minecraft:stripped_oak_log
fill 393 109 314 393 112 314 minecraft:red_terracotta
setblock 394 109 277 minecraft:stripped_oak_log
setblock 395 109 276 minecraft:stripped_oak_log
fill 395 109 277 395 112 277 minecraft:red_terracotta
setblock 395 109 316 minecraft:stripped_oak_log
fill 396 109 276 396 112 276 minecraft:red_terracotta
setblock 396 109 315 minecraft:stripped_oak_log
fill 396 109 316 399 109 316 minecraft:red_terracotta
setblock 397 109 314 minecraft:stripped_oak_log
fill 397 109 315 400 109 315 minecraft:red_terracotta
setblock 399 109 276 minecraft:red_terracotta
setblock 400 109 276 minecraft:stripped_oak_log
setblock 400 109 316 minecraft:stripped_oak_log
fill 401 109 276 404 109 276 minecraft:red_terracotta
setblock 401 109 314 minecraft:red_terracotta
setblock 401 109 315 minecraft:stripped_oak_log
fill 401 109 316 401 112 316 minecraft:red_terracotta
setblock 402 109 314 minecraft:stripped_oak_log
fill 402 109 315 402 112 315 minecraft:red_terracotta
fill 403 109 314 403 112 314 minecraft:red_terracotta
setblock 405 109 276 minecraft:stripped_oak_log
fill 405 109 313 407 109 313 minecraft:red_terracotta
setblock 405 109 316 minecraft:stripped_oak_log
fill 406 109 276 406 112 276 minecraft:red_terracotta
setblock 406 109 315 minecraft:stripped_oak_log
fill 406 109 316 406 112 316 minecraft:red_terracotta
setblock 407 109 314 minecraft:stripped_oak_log
fill 407 109 315 407 112 315 minecraft:red_terracotta
setblock 408 109 313 minecraft:stripped_oak_log
fill 408 109 314 408 112 314 minecraft:red_terracotta
setblock 409 109 276 minecraft:red_terracotta
fill 409 109 313 409 112 313 minecraft:red_terracotta
setblock 410 109 276 minecraft:stripped_oak_log
setblock 410 109 316 minecraft:stripped_oak_log
fill 411 109 276 411 112 276 minecraft:red_terracotta
setblock 411 109 315 minecraft:stripped_oak_log
fill 411 109 316 411 112 316 minecraft:red_terracotta
setblock 412 109 314 minecraft:stripped_oak_log
fill 412 109 315 412 112 315 minecraft:red_terracotta
fill 413 109 314 413 111 314 minecraft:red_terracotta
setblock 414 109 276 minecraft:red_terracotta
setblock 415 109 291 minecraft:stripped_oak_log
fill 415 109 292 415 109 295 minecraft:red_terracotta
setblock 415 109 296 minecraft:stripped_oak_log
fill 415 109 297 415 112 297 minecraft:red_terracotta
setblock 415 109 316 minecraft:stripped_oak_log
setblock 416 109 290 minecraft:stripped_oak_log
fill 416 109 291 416 112 291 minecraft:red_terracotta
setblock 416 109 295 minecraft:stripped_oak_log
fill 416 109 296 416 112 296 minecraft:red_terracotta
setblock 416 109 299 minecraft:red_terracotta
setblock 416 109 310 minecraft:stripped_oak_log
setblock 416 109 311 minecraft:red_terracotta
setblock 416 109 315 minecraft:stripped_oak_log
fill 416 109 316 416 112 316 minecraft:red_terracotta
setblock 417 109 289 minecraft:stripped_oak_log
fill 417 109 290 417 112 290 minecraft:red_terracotta
setblock 417 109 294 minecraft:stripped_oak_log
fill 417 109 295 417 112 295 minecraft:red_terracotta
setblock 417 109 299 minecraft:stripped_oak_log
fill 417 109 300 417 112 300 minecraft:red_terracotta
setblock 417 109 303 minecraft:red_terracotta
setblock 417 109 309 minecraft:stripped_oak_log
fill 417 109 310 417 111 310 minecraft:red_terracotta
setblock 417 109 314 minecraft:stripped_oak_log
fill 417 109 315 417 112 315 minecraft:red_terracotta
fill 377 110 276 377 110 277 minecraft:red_terracotta
fill 377 110 285 377 110 287 minecraft:red_terracotta
setblock 377 110 288 minecraft:stripped_oak_log
fill 377 110 289 377 113 289 minecraft:red_terracotta
setblock 377 110 293 minecraft:stripped_oak_log
fill 377 110 294 377 113 294 minecraft:red_terracotta
setblock 377 110 298 minecraft:stripped_oak_log
fill 377 110 299 377 113 299 minecraft:red_terracotta
setblock 377 110 314 minecraft:red_terracotta
fill 377 110 316 378 110 316 minecraft:red_terracotta
setblock 378 110 276 minecraft:red_terracotta
setblock 378 110 288 minecraft:red_terracotta
setblock 378 110 292 minecraft:stripped_oak_log
fill 378 110 293 378 113 293 minecraft:red_terracotta
setblock 378 110 297 minecraft:stripped_oak_log
setblock 379 110 276 minecraft:stripped_oak_log
setblock 379 110 316 minecraft:stripped_oak_log
fill 380 110 276 380 113 276 minecraft:red_terracotta
fill 380 110 316 383 110 316 minecraft:red_terracotta
setblock 382 110 277 minecraft:red_terracotta
setblock 383 110 277 minecraft:stripped_oak_log
fill 383 110 315 384 110 315 minecraft:red_terracotta
setblock 384 110 276 minecraft:stripped_oak_log
fill 384 110 277 384 113 277 minecraft:red_terracotta
setblock 384 110 316 minecraft:stripped_oak_log
fill 385 110 276 385 113 276 minecraft:red_terracotta
fill 385 110 278 386 110 278 minecraft:red_terracotta
setblock 385 110 315 minecraft:stripped_oak_log
fill 385 110 316 385 113 316 minecraft:red_terracotta
setblock 386 110 314 minecraft:stripped_oak_log
fill 386 110 315 386 113 315 minecraft:red_terracotta
setblock 387 110 278 minecraft:stripped_oak_log
fill 387 110 314 390 110 314 minecraft:red_terracotta
setblock 388 110 277 minecraft:stripped_oak_log
fill 388 110 278 388 113 278 minecraft:red_terracotta
setblock 389 110 276 minecraft:stripped_oak_log
fill 389 110 277 389 113 277 minecraft:red_terracotta
setblock 389 110 316 minecraft:stripped_oak_log
fill 390 110 276 390 113 276 minecraft:red_terracotta
setblock 390 110 313 minecraft:red_terracotta
setblock 390 110 315 minecraft:stripped_oak_log
fill 390 110 316 390 113 316 minecraft:red_terracotta
setblock 391 110 314 minecraft:stripped_oak_log
fill 391 110 315 391 113 315 minecraft:red_terracotta
setblock 392 110 278 minecraft:stripped_oak_log
fill 392 110 314 392 113 314 minecraft:red_terracotta
setblock 393 110 277 minecraft:stripped_oak_log
fill 393 110 278 393 112 278 minecraft:red_terracotta
setblock 394 110 276 minecraft:stripped_oak_log
fill 394 110 277 394 113 277 minecraft:red_terracotta
setblock 394 110 316 minecraft:stripped_oak_log
fill 395 110 276 395 113 276 minecraft:red_terracotta
setblock 395 110 315 minecraft:stripped_oak_log
fill 395 110 316 398 110 316 minecraft:red_terracotta
fill 396 110 277 396 111 277 minecraft:red_terracotta
setblock 396 110 314 minecraft:stripped_oak_log
fill 396 110 315 399 110 315 minecraft:red_terracotta
fill 397 110 314 400 110 314 minecraft:red_terracotta
setblock 399 110 276 minecraft:stripped_oak_log
setblock 399 110 316 minecraft:stripped_oak_log
fill 400 110 276 403 110 276 minecraft:red_terracotta
setblock 400 110 315 minecraft:stripped_oak_log
fill 400 110 316 400 113 316 minecraft:red_terracotta
setblock 401 110 314 minecraft:stripped_oak_log
fill 401 110 315 401 113 315 minecraft:red_terracotta
fill 402 110 314 402 113 314 minecraft:red_terracotta
setblock 404 110 276 minecraft:stripped_oak_log
fill 404 110 313 406 110 313 minecraft:red_terracotta
setblock 404 110 316 minecraft:stripped_oak_log
fill 405 110 276 405 113 276 minecraft:red_terracotta
setblock 405 110 315 minecraft:stripped_oak_log
fill 405 110 316 405 113 316 minecraft:red_terracotta
fill 406 110 277 407 110 277 minecraft:red_terracotta
setblock 406 110 314 minecraft:stripped_oak_log
fill 406 110 315 406 113 315 minecraft:red_terracotta
setblock 407 110 313 minecraft:stripped_oak_log
fill 407 110 314 407 113 314 minecraft:red_terracotta
setblock 408 110 277 minecraft:stripped_oak_log
fill 408 110 313 408 113 313 minecraft:red_terracotta
setblock 409 110 276 minecraft:stripped_oak_log
fill 409 110 277 410 112 277 minecraft:red_terracotta
setblock 409 110 316 minecraft:stripped_oak_log
fill 410 110 276 410 113 276 minecraft:red_terracotta
setblock 410 110 315 minecraft:stripped_oak_log
fill 410 110 316 410 113 316 minecraft:red_terracotta
setblock 411 110 314 minecraft:stripped_oak_log
fill 411 110 315 411 113 315 minecraft:red_terracotta
fill 412 110 314 412 112 314 minecraft:red_terracotta
setblock 414 110 276 minecraft:stripped_oak_log
setblock 414 110 316 minecraft:stripped_oak_log
fill 415 110 276 415 113 276 minecraft:red_terracotta
fill 415 110 291 415 110 294 minecraft:red_terracotta
setblock 415 110 295 minecraft:stripped_oak_log
fill 415 110 296 415 113 296 minecraft:red_terracotta
fill 415 110 298 415 111 298 minecraft:red_terracotta
setblock 415 110 315 minecraft:stripped_oak_log
fill 415 110 316 415 113 316 minecraft:red_terracotta
setblock 416 110 289 minecraft:stripped_oak_log
fill 416 110 290 416 112 290 minecraft:red_terracotta
setblock 416 110 294 minecraft:stripped_oak_log
fill 416 110 295 416 113 295 minecraft:red_terracotta
setblock 416 110 299 minecraft:stripped_oak_log
fill 416 110 300 416 113 300 minecraft:red_terracotta
setblock 416 110 314 minecraft:stripped_oak_log
setblock 416 110 315 minecraft:red_terracotta
setblock 417 110 288 minecraft:stripped_oak_log
fill 417 110 289 417 113 289 minecraft:red_terracotta
setblock 417 110 293 minecraft:stripped_oak_log
fill 417 110 294 417 113 294 minecraft:red_terracotta
setblock 417 110 298 minecraft:stripped_oak_log
fill 417 110 299 417 113 299 minecraft:red_terracotta
setblock 417 110 303 minecraft:stripped_oak_log
setblock 417 110 308 minecraft:stripped_oak_log
setblock 417 110 309 minecraft:red_terracotta
setblock 417 110 313 minecraft:stripped_oak_log
fill 417 110 314 417 112 314 minecraft:red_terracotta
setblock 377 111 276 minecraft:red_terracotta
setblock 377 111 277 minecraft:stripped_oak_log
fill 377 111 278 377 113 279 minecraft:red_terracotta
fill 377 111 285 377 111 286 minecraft:red_terracotta
setblock 377 111 287 minecraft:stripped_oak_log
fill 377 111 288 377 114 288 minecraft:red_terracotta
setblock 377 111 292 minecraft:stripped_oak_log
fill 377 111 293 377 114 293 minecraft:red_terracotta
setblock 377 111 297 minecraft:stripped_oak_log
fill 377 111 298 377 114 298 minecraft:red_terracotta
fill 377 111 300 377 112 300 minecraft:red_terracotta
fill 377 111 311 379 112 311 minecraft:iron_bars
setblock 377 111 316 minecraft:red_terracotta
setblock 378 111 276 minecraft:stripped_oak_log
setblock 378 111 291 minecraft:stripped_oak_log
fill 378 111 292 378 113 292 minecraft:red_terracotta
setblock 378 111 296 minecraft:stripped_oak_log
fill 378 111 297 378 114 297 minecraft:red_terracotta
setblock 378 111 316 minecraft:stripped_oak_log
fill 379 111 276 379 114 276 minecraft:red_terracotta
fill 379 111 316 382 111 316 minecraft:red_terracotta
setblock 381 111 277 minecraft:red_terracotta
setblock 382 111 277 minecraft:stripped_oak_log
fill 382 111 315 383 111 315 minecraft:red_terracotta
setblock 383 111 276 minecraft:stripped_oak_log
fill 383 111 277 383 114 277 minecraft:red_terracotta
setblock 383 111 316 minecraft:stripped_oak_log
fill 384 111 276 384 114 276 minecraft:red_terracotta
fill 384 111 278 385 111 278 minecraft:red_terracotta
setblock 384 111 315 minecraft:stripped_oak_log
fill 384 111 316 384 114 316 minecraft:red_terracotta
setblock 385 111 314 minecraft:stripped_oak_log
fill 385 111 315 385 114 315 minecraft:red_terracotta
setblock 386 111 278 minecraft:stripped_oak_log
fill 386 111 314 389 111 314 minecraft:red_terracotta
setblock 387 111 277 minecraft:stripped_oak_log
fill 387 111 278 387 114 278 minecraft:red_terracotta
setblock 388 111 276 minecraft:stripped_oak_log
fill 388 111 277 388 114 277 minecraft:red_terracotta
setblock 388 111 316 minecraft:stripped_oak_log
fill 389 111 276 389 114 276 minecraft:red_terracotta
setblock 389 111 315 minecraft:stripped_oak_log
fill 389 111 316 389 114 316 minecraft:red_terracotta
setblock 390 111 278 minecraft:red_terracotta
setblock 390 111 314 minecraft:stripped_oak_log
fill 390 111 315 390 114 315 minecraft:red_terracotta
setblock 391 111 278 minecraft:stripped_oak_log
fill 391 111 314 391 114 314 minecraft:red_terracotta
setblock 392 111 277 minecraft:stripped_oak_log
fill 392 111 278 392 114 278 minecraft:red_terracotta
setblock 393 111 276 minecraft:stripped_oak_log
fill 393 111 277 393 114 277 minecraft:red_terracotta
setblock 393 111 316 minecraft:stripped_oak_log
fill 394 111 276 394 114 276 minecraft:red_terracotta
setblock 394 111 315 minecraft:stripped_oak_log
fill 394 111 316 397 111 316 minecraft:red_terracotta
setblock 395 111 314 minecraft:stripped_oak_log
fill 395 111 315 398 111 315 minecraft:red_terracotta
fill 396 111 314 399 111 314 minecraft:red_terracotta
setblock 398 111 276 minecraft:stripped_oak_log
setblock 398 111 316 minecraft:stripped_oak_log
fill 399 111 276 402 111 276 minecraft:red_terracotta
setblock 399 111 315 minecraft:stripped_oak_log
fill 399 111 316 399 114 316 minecraft:red_terracotta
setblock 400 111 314 minecraft:stripped_oak_log
fill 400 111 315 400 114 315 minecraft:red_terracotta
fill 401 111 314 401 114 314 minecraft:red_terracotta
setblock 403 111 276 minecraft:stripped_oak_log
setblock 403 111 316 minecraft:stripped_oak_log
fill 404 111 276 404 113 277 minecraft:red_terracotta
fill 404 111 313 405 111 313 minecraft:red_terracotta
setblock 404 111 315 minecraft:stripped_oak_log
fill 404 111 316 404 114 316 minecraft:red_terracotta
fill 405 111 277 406 111 277 minecraft:red_terracotta
setblock 405 111 314 minecraft:stripped_oak_log
fill 405 111 315 405 114 315 minecraft:red_terracotta
setblock 406 111 313 minecraft:stripped_oak_log
fill 406 111 314 406 114 314 minecraft:red_terracotta
setblock 407 111 277 minecraft:stripped_oak_log
fill 407 111 313 407 113 313 minecraft:red_terracotta
setblock 408 111 276 minecraft:stripped_oak_log
fill 408 111 277 408 114 277 minecraft:red_terracotta
setblock 408 111 316 minecraft:stripped_oak_log
fill 409 111 276 409 114 276 minecraft:red_terracotta
setblock 409 111 315 minecraft:stripped_oak_log
fill 409 111 316 409 114 316 minecraft:red_terracotta
setblock 410 111 314 minecraft:stripped_oak_log
fill 410 111 315 410 114 315 minecraft:red_terracotta
setblock 411 111 277 minecraft:red_terracotta
setblock 411 111 313 minecraft:stripped_oak_log
fill 411 111 314 411 113 314 minecraft:red_terracotta
setblock 412 111 276 minecraft:red_terracotta
setblock 413 111 276 minecraft:stripped_oak_log
setblock 413 111 316 minecraft:stripped_oak_log
fill 414 111 276 414 114 276 minecraft:red_terracotta
setblock 414 111 315 minecraft:stripped_oak_log
fill 414 111 316 414 114 316 minecraft:red_terracotta
fill 415 111 292 415 111 293 minecraft:red_terracotta
setblock 415 111 294 minecraft:stripped_oak_log
fill 415 111 295 415 114 295 minecraft:red_terracotta
setblock 415 111 315 minecraft:red_terracotta
setblock 416 111 293 minecraft:stripped_oak_log
fill 416 111 294 416 114 294 minecraft:red_terracotta
setblock 416 111 297 minecraft:red_terracotta
setblock 416 111 298 minecraft:stripped_oak_log
fill 416 111 299 416 114 299 minecraft:red_terracotta
fill 417 111 288 417 112 288 minecraft:red_terracotta
setblock 417 111 292 minecraft:stripped_oak_log
fill 417 111 293 417 114 293 minecraft:red_terracotta
setblock 417 111 297 minecraft:stripped_oak_log
fill 417 111 298 417 114 298 minecraft:red_terracotta
setblock 417 111 301 minecraft:red_terracotta
setblock 417 111 302 minecraft:stripped_oak_log
fill 417 111 303 417 112 303 minecraft:red_terracotta
setblock 417 111 312 minecraft:stripped_oak_log
fill 417 111 313 417 112 313 minecraft:red_terracotta
fill 376 112 275 376 115 317 minecraft:orange_terracotta
fill 377 112 275 418 115 275 minecraft:orange_terracotta
setblock 377 112 276 minecraft:stripped_oak_log
fill 377 112 277 377 115 277 minecraft:red_terracotta
setblock 377 112 280 minecraft:red_terracotta
setblock 377 112 286 minecraft:stripped_oak_log
fill 377 112 287 377 113 287 minecraft:red_terracotta
setblock 377 112 291 minecraft:stripped_oak_log
fill 377 112 292 377 115 292 minecraft:red_terracotta
setblock 377 112 296 minecraft:stripped_oak_log
fill 377 112 297 377 115 297 minecraft:red_terracotta
setblock 377 112 316 minecraft:stripped_oak_log
fill 377 112 317 418 115 317 minecraft:orange_terracotta
fill 378 112 276 378 115 276 minecraft:red_terracotta
setblock 378 112 290 minecraft:stripped_oak_log
fill 378 112 291 378 113 291 minecraft:red_terracotta
setblock 378 112 295 minecraft:stripped_oak_log
fill 378 112 296 378 114 296 minecraft:red_terracotta
fill 378 112 316 381 112 316 minecraft:red_terracotta
setblock 379 112 278 minecraft:light[level=15]
setblock 379 112 286 minecraft:light[level=15]
setblock 379 112 294 minecraft:light[level=15]
setblock 379 112 302 minecraft:light[level=15]
setblock 379 112 310 minecraft:light[level=15]
setblock 380 112 277 minecraft:red_terracotta
setblock 381 112 276 minecraft:red_terracotta
setblock 381 112 277 minecraft:stripped_oak_log
setblock 382 112 276 minecraft:stripped_oak_log
fill 382 112 277 382 115 277 minecraft:red_terracotta
setblock 382 112 315 minecraft:red_terracotta
setblock 382 112 316 minecraft:stripped_oak_log
fill 383 112 276 383 115 276 minecraft:red_terracotta
fill 383 112 278 384 112 278 minecraft:red_terracotta
setblock 383 112 315 minecraft:stripped_oak_log
fill 383 112 316 383 115 316 minecraft:red_terracotta
fill 384 112 315 384 115 315 minecraft:red_terracotta
setblock 385 112 278 minecraft:stripped_oak_log
fill 385 112 314 388 112 314 minecraft:red_terracotta
setblock 386 112 277 minecraft:stripped_oak_log
fill 386 112 278 386 114 279 minecraft:red_terracotta
setblock 387 112 276 minecraft:stripped_oak_log
fill 387 112 277 387 115 277 minecraft:red_terracotta
fill 387 112 279 388 112 279 minecraft:red_terracotta
setblock 387 112 286 minecraft:light[level=15]
setblock 387 112 294 minecraft:light[level=15]
setblock 387 112 302 minecraft:light[level=15]
setblock 387 112 310 minecraft:light[level=15]
setblock 387 112 316 minecraft:stripped_oak_log
fill 388 112 276 388 115 276 minecraft:red_terracotta
setblock 388 112 315 minecraft:stripped_oak_log
fill 388 112 316 388 115 316 minecraft:red_terracotta
setblock 389 112 279 minecraft:stripped_oak_log
setblock 389 112 314 minecraft:stripped_oak_log
fill 389 112 315 389 115 315 minecraft:red_terracotta
setblock 390 112 278 minecraft:stripped_oak_log
fill 390 112 314 390 114 314 minecraft:red_terracotta
setblock 391 112 277 minecraft:stripped_oak_log
fill 391 112 278 391 115 278 minecraft:red_terracotta
setblock 392 112 276 minecraft:stripped_oak_log
fill 392 112 277 392 115 277 minecraft:red_terracotta
setblock 392 112 316 minecraft:stripped_oak_log
fill 393 112 276 393 115 276 minecraft:red_terracotta
setblock 393 112 315 minecraft:stripped_oak_log
fill 393 112 316 396 112 316 minecraft:red_terracotta
setblock 394 112 314 minecraft:stripped_oak_log
fill 394 112 315 397 112 315 minecraft:red_terracotta
setblock 395 112 286 minecraft:light[level=15]
setblock 395 112 294 minecraft:light[level=15]
setblock 395 112 302 minecraft:light[level=15]
setblock 395 112 310 minecraft:light[level=15]
fill 395 112 314 396 112 314 minecraft:red_terracotta
setblock 396 112 277 minecraft:stripped_oak_log
setblock 397 112 276 minecraft:stripped_oak_log
setblock 397 112 277 minecraft:red_terracotta
setblock 397 112 316 minecraft:stripped_oak_log
fill 398 112 276 401 112 276 minecraft:red_terracotta
setblock 398 112 315 minecraft:stripped_oak_log
fill 398 112 316 398 115 316 minecraft:red_terracotta
setblock 399 112 314 minecraft:stripped_oak_log
fill 399 112 315 399 115 315 minecraft:red_terracotta
fill 400 112 314 400 113 314 minecraft:red_terracotta
setblock 402 112 276 minecraft:stripped_oak_log
fill 402 112 277 403 114 277 minecraft:red_terracotta
setblock 402 112 316 minecraft:stripped_oak_log
fill 403 112 276 403 115 276 minecraft:red_terracotta
schedule function dropper:buildpart/68_2 1t
