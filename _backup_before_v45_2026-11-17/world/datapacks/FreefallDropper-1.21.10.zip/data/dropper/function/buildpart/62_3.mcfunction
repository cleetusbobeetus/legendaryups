fill 136 116 303 136 117 303 minecraft:red_concrete
fill 136 116 304 136 121 304 minecraft:shroomlight
fill 136 116 305 136 117 306 minecraft:white_concrete
fill 136 116 307 136 117 308 minecraft:red_concrete
fill 136 116 309 136 117 310 minecraft:white_concrete
fill 136 116 311 136 117 311 minecraft:red_concrete
fill 136 116 312 136 121 312 minecraft:shroomlight
fill 136 116 313 136 117 314 minecraft:white_concrete
fill 136 116 315 136 117 316 minecraft:red_concrete
fill 136 116 317 136 117 317 minecraft:white_concrete
fill 95 117 298 95 200 299 minecraft:red_terracotta
setblock 97 117 278 minecraft:light[level=15]
setblock 97 117 285 minecraft:light[level=12]
setblock 97 117 286 minecraft:light[level=15]
fill 97 117 292 97 117 300 minecraft:red_terracotta
setblock 97 117 302 minecraft:light[level=15]
setblock 97 117 306 minecraft:light[level=12]
setblock 97 117 310 minecraft:light[level=15]
setblock 97 117 313 minecraft:light[level=12]
fill 98 117 289 98 117 291 minecraft:red_terracotta
fill 98 117 292 106 117 300 minecraft:bricks
fill 98 117 301 98 117 303 minecraft:red_terracotta
fill 99 117 287 99 117 288 minecraft:red_terracotta
fill 99 117 289 107 117 291 minecraft:bricks
fill 99 117 301 108 117 303 minecraft:bricks
fill 99 117 304 99 117 305 minecraft:red_terracotta
setblock 100 117 286 minecraft:red_terracotta
fill 100 117 287 110 117 288 minecraft:bricks
fill 100 117 304 112 117 305 minecraft:bricks
setblock 100 117 306 minecraft:red_terracotta
setblock 101 117 284 minecraft:red_terracotta
fill 101 117 286 129 117 286 minecraft:bricks
fill 101 117 306 129 117 306 minecraft:bricks
setblock 101 117 308 minecraft:red_terracotta
setblock 102 117 283 minecraft:red_terracotta
fill 102 117 284 128 117 284 minecraft:bricks
fill 102 117 308 128 117 308 minecraft:bricks
setblock 102 117 309 minecraft:red_terracotta
setblock 103 117 282 minecraft:red_terracotta
fill 103 117 283 127 117 283 minecraft:bricks
fill 103 117 309 127 117 309 minecraft:bricks
setblock 103 117 310 minecraft:red_terracotta
setblock 104 117 278 minecraft:light[level=12]
fill 104 117 282 126 117 282 minecraft:bricks
fill 104 117 310 126 117 310 minecraft:bricks
setblock 104 117 313 minecraft:light[level=12]
setblock 105 117 278 minecraft:light[level=15]
setblock 105 117 281 minecraft:red_terracotta
setblock 105 117 311 minecraft:red_terracotta
fill 106 117 280 107 117 280 minecraft:red_terracotta
fill 106 117 281 124 117 281 minecraft:bricks
fill 106 117 311 124 117 311 minecraft:bricks
fill 106 117 312 107 117 312 minecraft:red_terracotta
setblock 107 117 292 minecraft:bricks
fill 107 117 293 107 117 298 minecraft:shroomlight
fill 107 117 299 107 117 300 minecraft:bricks
fill 108 117 279 110 117 279 minecraft:red_terracotta
fill 108 117 280 122 117 280 minecraft:bricks
fill 108 117 289 108 117 290 minecraft:bricks
fill 108 117 291 108 117 292 minecraft:shroomlight
fill 108 117 299 108 117 300 minecraft:shroomlight
fill 108 117 312 122 117 312 minecraft:bricks
fill 108 117 313 110 117 313 minecraft:red_terracotta
setblock 109 117 289 minecraft:bricks
setblock 109 117 290 minecraft:shroomlight
setblock 109 117 301 minecraft:shroomlight
fill 109 117 302 109 117 303 minecraft:bricks
setblock 110 117 289 minecraft:shroomlight
setblock 110 117 302 minecraft:shroomlight
setblock 110 117 303 minecraft:bricks
fill 111 117 278 119 117 278 minecraft:red_terracotta
fill 111 117 279 119 117 279 minecraft:bricks
setblock 111 117 287 minecraft:bricks
setblock 111 117 288 minecraft:shroomlight
setblock 111 117 292 minecraft:light[level=12]
setblock 111 117 299 minecraft:light[level=12]
fill 111 117 303 112 117 303 minecraft:shroomlight
fill 111 117 313 119 117 313 minecraft:bricks
fill 111 117 314 119 117 314 minecraft:red_terracotta
fill 112 117 287 119 117 287 minecraft:shroomlight
setblock 113 117 294 minecraft:light[level=15]
setblock 113 117 302 minecraft:light[level=15]
fill 113 117 304 118 117 304 minecraft:shroomlight
fill 113 117 305 130 117 305 minecraft:bricks
setblock 118 117 292 minecraft:light[level=12]
setblock 118 117 299 minecraft:light[level=12]
fill 119 117 303 120 117 303 minecraft:shroomlight
fill 119 117 304 130 117 304 minecraft:bricks
fill 120 117 279 122 117 279 minecraft:red_terracotta
fill 120 117 287 130 117 287 minecraft:bricks
fill 120 117 288 121 117 288 minecraft:shroomlight
fill 120 117 313 122 117 313 minecraft:red_terracotta
setblock 121 117 278 minecraft:light[level=15]
setblock 121 117 294 minecraft:light[level=15]
setblock 121 117 302 minecraft:shroomlight
fill 121 117 303 131 117 303 minecraft:bricks
fill 122 117 288 130 117 288 minecraft:bricks
setblock 122 117 289 minecraft:shroomlight
setblock 122 117 301 minecraft:shroomlight
fill 122 117 302 131 117 302 minecraft:bricks
fill 123 117 280 124 117 280 minecraft:red_terracotta
fill 123 117 289 131 117 289 minecraft:bricks
fill 123 117 290 123 117 291 minecraft:shroomlight
setblock 123 117 300 minecraft:shroomlight
fill 123 117 301 131 117 301 minecraft:bricks
fill 123 117 312 124 117 312 minecraft:red_terracotta
fill 124 117 290 131 117 291 minecraft:bricks
fill 124 117 292 124 117 299 minecraft:shroomlight
fill 124 117 300 132 117 300 minecraft:bricks
setblock 125 117 278 minecraft:light[level=12]
setblock 125 117 281 minecraft:red_terracotta
fill 125 117 292 132 117 299 minecraft:bricks
setblock 125 117 311 minecraft:red_terracotta
setblock 125 117 313 minecraft:light[level=12]
setblock 127 117 282 minecraft:red_terracotta
setblock 127 117 310 minecraft:red_terracotta
setblock 128 117 283 minecraft:red_terracotta
setblock 128 117 309 minecraft:red_terracotta
setblock 129 117 278 minecraft:light[level=15]
setblock 129 117 284 minecraft:red_terracotta
setblock 129 117 308 minecraft:red_terracotta
setblock 129 117 310 minecraft:light[level=15]
fill 130 117 284 130 200 284 minecraft:iron_block
setblock 130 117 286 minecraft:red_terracotta
setblock 130 117 306 minecraft:red_terracotta
fill 131 117 287 131 117 288 minecraft:red_terracotta
fill 131 117 304 131 117 305 minecraft:red_terracotta
setblock 132 117 278 minecraft:light[level=12]
fill 132 117 289 132 117 291 minecraft:red_terracotta
fill 132 117 301 132 117 303 minecraft:red_terracotta
setblock 132 117 306 minecraft:light[level=12]
setblock 132 117 313 minecraft:light[level=12]
fill 133 117 292 133 117 300 minecraft:red_terracotta
fill 94 118 275 94 119 276 minecraft:white_concrete
fill 94 118 277 94 119 278 minecraft:red_concrete
fill 94 118 279 94 119 279 minecraft:white_concrete
fill 94 118 281 94 119 282 minecraft:red_concrete
fill 94 118 283 94 119 284 minecraft:white_concrete
fill 94 118 285 94 119 286 minecraft:red_concrete
fill 94 118 287 94 119 287 minecraft:white_concrete
fill 94 118 289 94 119 290 minecraft:red_concrete
fill 94 118 291 94 119 292 minecraft:white_concrete
fill 94 118 293 94 119 294 minecraft:red_concrete
fill 94 118 295 94 119 295 minecraft:white_concrete
fill 94 118 297 94 119 298 minecraft:red_concrete
fill 94 118 299 94 119 300 minecraft:white_concrete
fill 94 118 301 94 119 302 minecraft:red_concrete
fill 94 118 303 94 119 303 minecraft:white_concrete
fill 94 118 305 94 119 306 minecraft:red_concrete
fill 94 118 307 94 119 308 minecraft:white_concrete
fill 94 118 309 94 119 310 minecraft:red_concrete
fill 94 118 311 94 119 311 minecraft:white_concrete
fill 94 118 313 94 119 314 minecraft:red_concrete
fill 94 118 315 94 119 316 minecraft:white_concrete
fill 95 118 275 95 119 275 minecraft:white_concrete
fill 95 118 284 98 118 289 minecraft:brown_terracotta
fill 95 118 292 97 118 292 minecraft:brown_terracotta
fill 95 118 317 95 119 317 minecraft:white_concrete
fill 96 118 275 97 119 275 minecraft:red_concrete
fill 96 118 290 97 118 291 minecraft:brown_terracotta
fill 96 118 317 96 119 317 minecraft:red_concrete
fill 98 118 275 99 119 275 minecraft:white_concrete
setblock 98 118 290 minecraft:brown_terracotta
fill 98 118 291 98 118 301 minecraft:red_terracotta
fill 98 118 317 99 119 317 minecraft:white_concrete
fill 99 118 284 99 118 288 minecraft:brown_terracotta
fill 99 118 289 99 119 290 minecraft:red_terracotta
fill 99 118 291 105 118 301 minecraft:bricks
fill 99 118 302 99 118 303 minecraft:red_terracotta
fill 100 118 275 100 119 275 minecraft:red_concrete
fill 100 118 287 100 118 288 minecraft:red_terracotta
fill 100 118 289 107 118 290 minecraft:bricks
fill 100 118 302 108 118 303 minecraft:bricks
fill 100 118 304 100 118 305 minecraft:red_terracotta
fill 100 118 317 101 119 317 minecraft:red_concrete
fill 101 118 285 101 118 286 minecraft:red_terracotta
fill 101 118 287 109 118 288 minecraft:bricks
fill 101 118 304 110 118 305 minecraft:bricks
fill 101 118 306 101 118 307 minecraft:red_terracotta
fill 102 118 275 103 119 275 minecraft:white_concrete
fill 102 118 284 102 118 285 minecraft:red_terracotta
fill 102 118 286 112 118 286 minecraft:bricks
fill 102 118 306 128 118 306 minecraft:bricks
fill 102 118 307 102 118 308 minecraft:red_terracotta
fill 102 118 317 103 119 317 minecraft:white_concrete
fill 103 118 283 103 118 284 minecraft:red_terracotta
fill 103 118 285 127 118 285 minecraft:bricks
fill 103 118 307 127 118 307 minecraft:bricks
fill 103 118 308 103 118 309 minecraft:red_terracotta
fill 104 118 275 105 119 275 minecraft:red_concrete
fill 104 118 282 104 118 283 minecraft:red_terracotta
fill 104 118 284 126 118 284 minecraft:bricks
fill 104 118 308 126 118 308 minecraft:bricks
fill 104 118 309 104 118 310 minecraft:red_terracotta
fill 104 118 317 104 119 317 minecraft:red_concrete
setblock 105 118 282 minecraft:red_terracotta
fill 105 118 283 125 118 283 minecraft:bricks
fill 105 118 309 125 118 309 minecraft:bricks
setblock 105 118 310 minecraft:red_terracotta
fill 106 118 275 107 119 275 minecraft:white_concrete
fill 106 118 281 107 118 281 minecraft:red_terracotta
fill 106 118 282 124 118 282 minecraft:bricks
fill 106 118 291 106 118 292 minecraft:bricks
fill 106 118 293 106 118 297 minecraft:magma_block
fill 106 118 298 106 118 301 minecraft:bricks
fill 106 118 310 124 118 310 minecraft:bricks
fill 106 118 311 107 118 311 minecraft:red_terracotta
fill 106 118 317 107 119 317 minecraft:white_concrete
fill 107 118 291 107 118 292 minecraft:magma_block
fill 107 118 298 107 118 300 minecraft:magma_block
setblock 107 118 301 minecraft:bricks
fill 108 118 275 108 119 275 minecraft:red_concrete
fill 108 118 280 109 118 280 minecraft:red_terracotta
fill 108 118 281 122 118 281 minecraft:bricks
setblock 108 118 289 minecraft:bricks
setblock 108 118 290 minecraft:magma_block
setblock 108 118 301 minecraft:magma_block
fill 108 118 311 122 118 311 minecraft:bricks
fill 108 118 312 109 118 312 minecraft:red_terracotta
fill 108 118 317 109 119 317 minecraft:red_concrete
setblock 109 118 289 minecraft:magma_block
setblock 109 118 302 minecraft:magma_block
setblock 109 118 303 minecraft:bricks
fill 110 118 275 111 119 275 minecraft:white_concrete
fill 110 118 279 120 118 279 minecraft:red_terracotta
fill 110 118 280 120 118 280 minecraft:bricks
setblock 110 118 287 minecraft:bricks
setblock 110 118 288 minecraft:magma_block
setblock 110 118 303 minecraft:magma_block
fill 110 118 312 120 118 312 minecraft:bricks
fill 110 118 313 120 118 313 minecraft:red_terracotta
fill 110 118 317 111 119 317 minecraft:white_concrete
fill 111 118 287 112 118 287 minecraft:magma_block
fill 111 118 304 113 118 304 minecraft:magma_block
fill 111 118 305 113 118 305 minecraft:bricks
fill 112 118 275 113 119 275 minecraft:red_concrete
fill 112 118 317 112 119 317 minecraft:red_concrete
fill 113 118 286 118 119 286 minecraft:magma_block
fill 114 118 275 115 119 275 minecraft:white_concrete
fill 114 118 305 118 118 305 minecraft:magma_block
fill 114 118 317 115 119 317 minecraft:white_concrete
fill 116 118 275 116 119 275 minecraft:red_concrete
fill 116 118 317 117 119 317 minecraft:red_concrete
fill 118 118 275 119 119 275 minecraft:white_concrete
fill 118 118 317 119 119 317 minecraft:white_concrete
fill 119 118 286 128 118 286 minecraft:bricks
fill 119 118 287 120 118 287 minecraft:magma_block
fill 119 118 304 120 118 304 minecraft:magma_block
fill 119 118 305 129 118 305 minecraft:bricks
fill 120 118 275 121 119 275 minecraft:red_concrete
fill 120 118 317 120 119 317 minecraft:red_concrete
fill 121 118 280 122 118 280 minecraft:red_terracotta
fill 121 118 287 129 118 287 minecraft:bricks
setblock 121 118 288 minecraft:magma_block
setblock 121 118 303 minecraft:magma_block
fill 121 118 304 129 118 304 minecraft:bricks
fill 121 118 312 122 118 312 minecraft:red_terracotta
fill 122 118 275 123 119 275 minecraft:white_concrete
fill 122 118 288 129 118 288 minecraft:bricks
setblock 122 118 289 minecraft:magma_block
setblock 122 118 302 minecraft:magma_block
fill 122 118 303 130 118 303 minecraft:bricks
fill 122 118 317 123 119 317 minecraft:white_concrete
fill 123 118 281 124 118 281 minecraft:red_terracotta
fill 123 118 289 130 118 289 minecraft:bricks
setblock 123 118 290 minecraft:magma_block
setblock 123 118 301 minecraft:magma_block
fill 123 118 302 130 118 302 minecraft:bricks
fill 123 118 311 124 118 311 minecraft:red_terracotta
fill 124 118 275 124 119 275 minecraft:red_concrete
fill 124 118 290 130 118 290 minecraft:bricks
fill 124 118 291 124 118 292 minecraft:magma_block
fill 124 118 299 124 118 300 minecraft:magma_block
fill 124 118 301 131 118 301 minecraft:bricks
fill 124 118 317 125 119 317 minecraft:red_concrete
fill 125 118 282 126 118 282 minecraft:red_terracotta
fill 125 118 291 131 118 292 minecraft:bricks
fill 125 118 293 125 119 298 minecraft:magma_block
fill 125 118 299 131 118 300 minecraft:bricks
fill 125 118 310 126 118 310 minecraft:red_terracotta
fill 126 118 275 127 119 275 minecraft:white_concrete
fill 126 118 283 127 118 283 minecraft:red_terracotta
fill 126 118 293 131 118 298 minecraft:bricks
fill 126 118 309 127 118 309 minecraft:red_terracotta
fill 126 118 317 127 119 317 minecraft:white_concrete
fill 127 118 284 128 118 284 minecraft:red_terracotta
fill 127 118 308 128 118 308 minecraft:red_terracotta
fill 128 118 275 129 119 275 minecraft:red_concrete
fill 128 118 285 129 118 285 minecraft:red_terracotta
fill 128 118 307 129 118 307 minecraft:red_terracotta
fill 128 118 317 128 119 317 minecraft:red_concrete
setblock 129 118 286 minecraft:red_terracotta
setblock 129 118 306 minecraft:red_terracotta
fill 130 118 275 131 119 275 minecraft:white_concrete
fill 130 118 285 130 200 285 minecraft:iron_block
fill 130 118 287 130 118 288 minecraft:red_terracotta
fill 130 118 304 130 118 305 minecraft:red_terracotta
fill 130 118 317 131 119 317 minecraft:white_concrete
fill 131 118 289 131 118 290 minecraft:red_terracotta
fill 131 118 302 131 118 303 minecraft:red_terracotta
fill 132 118 275 132 119 275 minecraft:red_concrete
fill 132 118 291 132 118 301 minecraft:red_terracotta
fill 132 118 317 133 119 317 minecraft:red_concrete
fill 134 118 275 135 119 275 minecraft:white_concrete
fill 134 118 317 135 119 317 minecraft:white_concrete
fill 136 118 276 136 119 276 minecraft:white_concrete
fill 136 118 277 136 119 278 minecraft:red_concrete
fill 136 118 279 136 119 279 minecraft:white_concrete
fill 136 118 281 136 119 282 minecraft:red_concrete
fill 136 118 283 136 119 284 minecraft:white_concrete
fill 136 118 285 136 119 286 minecraft:red_concrete
fill 136 118 287 136 119 287 minecraft:white_concrete
fill 136 118 289 136 119 290 minecraft:red_concrete
fill 136 118 291 136 119 292 minecraft:white_concrete
fill 136 118 293 136 119 294 minecraft:red_concrete
fill 136 118 295 136 119 295 minecraft:white_concrete
fill 136 118 297 136 119 298 minecraft:red_concrete
fill 136 118 299 136 119 300 minecraft:white_concrete
fill 136 118 301 136 119 302 minecraft:red_concrete
fill 136 118 303 136 119 303 minecraft:white_concrete
fill 136 118 305 136 119 306 minecraft:red_concrete
fill 136 118 307 136 119 308 minecraft:white_concrete
fill 136 118 309 136 119 310 minecraft:red_concrete
fill 136 118 311 136 119 311 minecraft:white_concrete
fill 136 118 313 136 119 314 minecraft:red_concrete
fill 136 118 315 136 119 316 minecraft:white_concrete
fill 136 118 317 136 119 317 minecraft:red_concrete
fill 95 119 284 98 119 289 minecraft:red_terracotta
fill 95 119 292 99 119 292 minecraft:red_terracotta
fill 96 119 290 98 119 291 minecraft:red_terracotta
fill 99 119 284 99 119 288 minecraft:red_terracotta
setblock 99 119 291 minecraft:red_terracotta
fill 99 119 293 99 119 301 minecraft:red_terracotta
fill 100 119 289 100 119 290 minecraft:red_terracotta
fill 100 119 291 104 119 301 minecraft:bricks
fill 100 119 302 100 119 303 minecraft:red_terracotta
fill 101 119 287 101 119 288 minecraft:red_terracotta
fill 101 119 289 106 119 290 minecraft:bricks
fill 101 119 302 107 119 303 minecraft:bricks
fill 101 119 304 101 119 305 minecraft:red_terracotta
setblock 102 119 286 minecraft:red_terracotta
fill 102 119 287 108 119 288 minecraft:bricks
fill 102 119 304 109 119 305 minecraft:bricks
setblock 102 119 306 minecraft:red_terracotta
setblock 103 119 285 minecraft:red_terracotta
fill 103 119 286 111 119 286 minecraft:bricks
fill 103 119 306 113 119 306 minecraft:bricks
setblock 103 119 307 minecraft:red_terracotta
setblock 104 119 284 minecraft:red_terracotta
fill 104 119 285 126 119 285 minecraft:bricks
fill 104 119 307 126 119 307 minecraft:bricks
setblock 104 119 308 minecraft:red_terracotta
setblock 105 119 283 minecraft:red_terracotta
fill 105 119 284 125 119 284 minecraft:bricks
fill 105 119 291 105 119 294 minecraft:bricks
fill 105 119 295 105 119 297 minecraft:magma_block
fill 105 119 298 105 119 301 minecraft:bricks
fill 105 119 308 125 119 308 minecraft:bricks
setblock 105 119 309 minecraft:red_terracotta
fill 106 119 282 107 119 282 minecraft:red_terracotta
fill 106 119 283 124 119 283 minecraft:bricks
setblock 106 119 291 minecraft:bricks
fill 106 119 292 106 119 294 minecraft:magma_block
fill 106 119 298 106 119 300 minecraft:magma_block
setblock 106 119 301 minecraft:bricks
fill 106 119 309 124 119 309 minecraft:bricks
fill 106 119 310 107 119 310 minecraft:red_terracotta
setblock 107 119 289 minecraft:bricks
fill 107 119 290 107 119 291 minecraft:magma_block
setblock 107 119 301 minecraft:magma_block
fill 108 119 281 109 119 281 minecraft:red_terracotta
fill 108 119 282 122 119 282 minecraft:bricks
setblock 108 119 289 minecraft:magma_block
setblock 108 119 302 minecraft:magma_block
setblock 108 119 303 minecraft:bricks
fill 108 119 310 122 119 310 minecraft:bricks
fill 108 119 311 109 119 311 minecraft:red_terracotta
setblock 109 119 287 minecraft:bricks
setblock 109 119 288 minecraft:magma_block
setblock 109 119 303 minecraft:magma_block
fill 110 119 278 113 200 280 minecraft:red_terracotta
fill 110 119 281 120 119 281 minecraft:bricks
fill 110 119 287 111 119 287 minecraft:magma_block
setblock 110 119 304 minecraft:magma_block
setblock 110 119 305 minecraft:bricks
fill 110 119 311 120 119 311 minecraft:bricks
fill 110 119 312 120 119 312 minecraft:red_terracotta
fill 111 119 305 113 119 305 minecraft:magma_block
setblock 112 119 286 minecraft:magma_block
fill 114 119 279 114 200 280 minecraft:red_terracotta
fill 114 119 306 116 119 306 minecraft:magma_block
fill 115 119 280 120 119 280 minecraft:red_terracotta
fill 117 119 305 119 119 305 minecraft:magma_block
fill 117 119 306 127 119 306 minecraft:bricks
setblock 119 119 286 minecraft:magma_block
fill 120 119 286 127 119 286 minecraft:bricks
fill 120 119 287 121 119 287 minecraft:magma_block
fill 120 119 304 121 119 304 minecraft:magma_block
fill 120 119 305 128 119 305 minecraft:bricks
fill 121 119 281 122 119 281 minecraft:red_terracotta
fill 121 119 311 122 119 311 minecraft:red_terracotta
fill 122 119 287 128 119 287 minecraft:bricks
setblock 122 119 288 minecraft:magma_block
setblock 122 119 303 minecraft:magma_block
fill 122 119 304 128 119 304 minecraft:bricks
fill 123 119 282 124 119 282 minecraft:red_terracotta
fill 123 119 288 128 119 288 minecraft:bricks
setblock 123 119 289 minecraft:magma_block
setblock 123 119 302 minecraft:magma_block
fill 123 119 303 129 119 303 minecraft:bricks
fill 123 119 310 124 119 310 minecraft:red_terracotta
fill 124 119 289 129 119 289 minecraft:bricks
fill 124 119 290 124 119 291 minecraft:magma_block
fill 124 119 300 124 119 301 minecraft:magma_block
fill 124 119 302 129 119 302 minecraft:bricks
setblock 125 119 283 minecraft:red_terracotta
fill 125 119 290 129 119 291 minecraft:bricks
setblock 125 119 292 minecraft:magma_block
setblock 125 119 299 minecraft:magma_block
fill 125 119 300 130 119 301 minecraft:bricks
setblock 125 119 309 minecraft:red_terracotta
setblock 126 119 284 minecraft:red_terracotta
fill 126 119 292 130 119 299 minecraft:bricks
setblock 126 119 308 minecraft:red_terracotta
setblock 127 119 285 minecraft:red_terracotta
setblock 127 119 307 minecraft:red_terracotta
setblock 128 119 286 minecraft:red_terracotta
setblock 128 119 306 minecraft:red_terracotta
fill 129 119 287 129 119 288 minecraft:red_terracotta
fill 129 119 304 129 119 305 minecraft:red_terracotta
fill 130 119 289 130 119 290 minecraft:red_terracotta
setblock 130 119 291 minecraft:bricks
fill 130 119 302 130 119 303 minecraft:red_terracotta
fill 131 119 291 131 119 301 minecraft:red_terracotta
fill 94 120 275 94 121 276 minecraft:red_concrete
fill 94 120 277 94 121 278 minecraft:white_concrete
fill 94 120 279 94 121 279 minecraft:red_concrete
fill 94 120 281 94 121 282 minecraft:white_concrete
fill 94 120 283 94 121 284 minecraft:red_concrete
fill 94 120 285 94 121 286 minecraft:white_concrete
fill 94 120 287 94 123 287 minecraft:shroomlight
fill 94 120 289 94 123 289 minecraft:shroomlight
fill 94 120 290 94 121 290 minecraft:white_concrete
fill 94 120 291 94 121 292 minecraft:red_concrete
fill 94 120 293 94 121 294 minecraft:white_concrete
fill 94 120 295 94 121 295 minecraft:red_concrete
fill 94 120 297 94 121 298 minecraft:white_concrete
fill 94 120 299 94 121 300 minecraft:red_concrete
fill 94 120 301 94 121 302 minecraft:white_concrete
fill 94 120 303 94 121 303 minecraft:red_concrete
fill 94 120 305 94 121 306 minecraft:white_concrete
fill 94 120 307 94 121 308 minecraft:red_concrete
fill 94 120 309 94 121 310 minecraft:white_concrete
fill 94 120 311 94 121 311 minecraft:red_concrete
fill 94 120 313 94 121 314 minecraft:white_concrete
fill 94 120 315 94 121 316 minecraft:red_concrete
fill 95 120 275 95 121 275 minecraft:red_concrete
fill 95 120 317 95 121 317 minecraft:red_concrete
fill 96 120 275 97 121 275 minecraft:white_concrete
fill 96 120 317 96 121 317 minecraft:white_concrete
fill 98 120 275 99 121 275 minecraft:red_concrete
fill 98 120 317 99 121 317 minecraft:red_concrete
fill 99 120 284 99 120 292 minecraft:yellow_concrete
fill 100 120 275 100 121 275 minecraft:white_concrete
fill 100 120 291 100 120 301 minecraft:red_terracotta
fill 100 120 317 101 121 317 minecraft:white_concrete
fill 101 120 289 101 120 293 minecraft:red_terracotta
fill 101 120 294 104 120 298 minecraft:bricks
fill 101 120 299 101 120 303 minecraft:red_terracotta
fill 102 120 275 103 121 275 minecraft:red_concrete
fill 102 120 287 102 120 290 minecraft:red_terracotta
fill 102 120 291 104 120 293 minecraft:bricks
fill 102 120 299 104 120 301 minecraft:bricks
fill 102 120 302 102 120 305 minecraft:red_terracotta
fill 102 120 317 103 121 317 minecraft:red_concrete
fill 103 120 286 103 120 288 minecraft:red_terracotta
fill 103 120 289 105 120 290 minecraft:bricks
fill 103 120 302 106 120 303 minecraft:bricks
fill 103 120 304 103 120 306 minecraft:red_terracotta
fill 104 120 275 105 121 275 minecraft:white_concrete
fill 104 120 285 104 120 286 minecraft:red_terracotta
fill 104 120 287 107 120 288 minecraft:bricks
fill 104 120 304 108 120 305 minecraft:bricks
fill 104 120 306 104 120 307 minecraft:red_terracotta
fill 104 120 317 104 121 317 minecraft:white_concrete
fill 105 120 284 105 120 285 minecraft:red_terracotta
fill 105 120 286 110 120 286 minecraft:bricks
setblock 105 120 291 minecraft:bricks
fill 105 120 292 105 120 299 minecraft:shroomlight
fill 105 120 300 105 120 301 minecraft:bricks
fill 105 120 306 111 120 306 minecraft:bricks
fill 105 120 307 105 120 308 minecraft:red_terracotta
fill 106 120 275 107 121 275 minecraft:red_concrete
fill 106 120 283 107 120 284 minecraft:red_terracotta
fill 106 120 285 112 120 285 minecraft:bricks
setblock 106 120 289 minecraft:bricks
fill 106 120 290 106 120 291 minecraft:shroomlight
fill 106 120 300 106 120 301 minecraft:shroomlight
fill 106 120 307 124 120 307 minecraft:bricks
fill 106 120 308 107 120 309 minecraft:red_terracotta
fill 106 120 317 107 121 317 minecraft:red_concrete
setblock 107 120 289 minecraft:shroomlight
setblock 107 120 302 minecraft:shroomlight
setblock 107 120 303 minecraft:bricks
fill 107 120 310 107 122 310 minecraft:iron_block
fill 108 120 275 108 121 275 minecraft:white_concrete
fill 108 120 282 109 120 283 minecraft:red_terracotta
fill 108 120 284 122 120 284 minecraft:bricks
setblock 108 120 287 minecraft:bricks
setblock 108 120 288 minecraft:shroomlight
setblock 108 120 303 minecraft:shroomlight
fill 108 120 308 122 120 308 minecraft:bricks
fill 108 120 309 109 120 310 minecraft:red_terracotta
fill 108 120 317 109 121 317 minecraft:white_concrete
fill 109 120 278 109 121 281 minecraft:brown_terracotta
fill 109 120 287 110 120 287 minecraft:shroomlight
setblock 109 120 304 minecraft:shroomlight
setblock 109 120 305 minecraft:bricks
fill 110 120 275 111 121 275 minecraft:red_concrete
fill 110 120 277 113 121 277 minecraft:brown_terracotta
fill 110 120 281 112 120 282 minecraft:red_terracotta
fill 110 120 283 120 120 283 minecraft:bricks
fill 110 120 305 111 120 305 minecraft:shroomlight
fill 110 120 309 120 120 309 minecraft:bricks
fill 110 120 310 112 120 311 minecraft:red_terracotta
fill 110 120 317 111 121 317 minecraft:red_concrete
fill 111 120 286 112 120 286 minecraft:shroomlight
fill 112 120 275 113 121 275 minecraft:white_concrete
fill 112 120 306 119 120 306 minecraft:shroomlight
fill 112 120 317 112 121 317 minecraft:white_concrete
fill 113 120 281 120 120 281 minecraft:red_terracotta
fill 113 120 282 117 120 282 minecraft:bricks
fill 113 120 285 117 120 285 minecraft:shroomlight
fill 113 120 310 117 120 310 minecraft:bricks
fill 113 120 311 120 120 311 minecraft:red_terracotta
fill 114 120 275 115 121 275 minecraft:red_concrete
fill 114 120 278 114 121 278 minecraft:brown_terracotta
fill 114 120 317 115 121 317 minecraft:red_concrete
fill 115 120 279 115 121 280 minecraft:brown_terracotta
fill 116 120 275 116 121 275 minecraft:white_concrete
fill 116 120 317 117 121 317 minecraft:white_concrete
fill 118 120 275 119 121 275 minecraft:red_concrete
fill 118 120 282 122 120 282 minecraft:red_terracotta
fill 118 120 285 124 120 285 minecraft:bricks
fill 118 120 286 120 120 286 minecraft:shroomlight
fill 118 120 310 122 120 310 minecraft:red_terracotta
fill 118 120 317 119 121 317 minecraft:red_concrete
fill 120 120 275 121 121 275 minecraft:white_concrete
fill 120 120 305 121 120 305 minecraft:shroomlight
fill 120 120 306 125 120 306 minecraft:bricks
fill 120 120 317 120 121 317 minecraft:white_concrete
fill 121 120 283 124 120 283 minecraft:red_terracotta
fill 121 120 286 125 120 286 minecraft:bricks
setblock 121 120 287 minecraft:shroomlight
fill 121 120 309 124 120 309 minecraft:red_terracotta
fill 122 120 275 123 121 275 minecraft:red_concrete
fill 122 120 287 126 120 287 minecraft:bricks
setblock 122 120 288 minecraft:shroomlight
setblock 122 120 304 minecraft:shroomlight
fill 122 120 305 126 120 305 minecraft:bricks
fill 122 120 317 123 121 317 minecraft:red_concrete
fill 123 120 284 125 120 284 minecraft:red_terracotta
fill 123 120 288 126 120 288 minecraft:bricks
setblock 123 120 289 minecraft:shroomlight
setblock 123 120 303 minecraft:shroomlight
fill 123 120 304 126 120 304 minecraft:bricks
fill 123 120 308 125 120 308 minecraft:red_terracotta
fill 124 120 275 124 121 275 minecraft:white_concrete
fill 124 120 289 127 120 289 minecraft:bricks
setblock 124 120 290 minecraft:shroomlight
fill 124 120 301 124 120 302 minecraft:shroomlight
fill 124 120 303 127 120 303 minecraft:bricks
fill 124 120 317 125 121 317 minecraft:white_concrete
fill 125 120 285 126 120 285 minecraft:red_terracotta
fill 125 120 290 127 120 290 minecraft:bricks
fill 125 120 291 125 120 293 minecraft:shroomlight
fill 125 120 299 125 120 300 minecraft:shroomlight
fill 125 120 301 127 120 302 minecraft:bricks
fill 125 120 307 126 120 307 minecraft:red_terracotta
fill 126 120 275 127 121 275 minecraft:red_concrete
fill 126 120 286 127 120 286 minecraft:red_terracotta
fill 126 120 291 128 120 293 minecraft:bricks
fill 126 120 294 126 120 298 minecraft:shroomlight
fill 126 120 299 128 120 300 minecraft:bricks
fill 126 120 306 127 120 306 minecraft:red_terracotta
fill 126 120 317 127 121 317 minecraft:red_concrete
fill 127 120 287 128 120 288 minecraft:red_terracotta
fill 127 120 294 129 120 298 minecraft:bricks
fill 127 120 304 128 120 305 minecraft:red_terracotta
fill 128 120 275 129 121 275 minecraft:white_concrete
fill 128 120 289 129 120 290 minecraft:red_terracotta
setblock 128 120 301 minecraft:bricks
fill 128 120 302 129 120 303 minecraft:red_terracotta
fill 128 120 317 128 121 317 minecraft:white_concrete
fill 129 120 291 130 120 293 minecraft:red_terracotta
fill 129 120 299 130 120 301 minecraft:red_terracotta
fill 130 120 275 131 121 275 minecraft:red_concrete
fill 130 120 294 130 120 298 minecraft:red_terracotta
fill 130 120 317 131 121 317 minecraft:red_concrete
fill 132 120 275 132 121 275 minecraft:white_concrete
fill 132 120 317 133 121 317 minecraft:white_concrete
fill 134 120 275 135 121 275 minecraft:red_concrete
fill 134 120 317 135 121 317 minecraft:red_concrete
fill 136 120 276 136 121 276 minecraft:red_concrete
fill 136 120 277 136 121 278 minecraft:white_concrete
fill 136 120 279 136 121 279 minecraft:red_concrete
fill 136 120 281 136 121 282 minecraft:white_concrete
fill 136 120 283 136 121 284 minecraft:red_concrete
fill 136 120 285 136 121 286 minecraft:white_concrete
fill 136 120 287 136 121 287 minecraft:red_concrete
fill 136 120 289 136 121 290 minecraft:white_concrete
fill 136 120 291 136 121 292 minecraft:red_concrete
fill 136 120 293 136 121 294 minecraft:white_concrete
fill 136 120 295 136 121 295 minecraft:red_concrete
fill 136 120 297 136 121 298 minecraft:white_concrete
fill 136 120 299 136 121 300 minecraft:red_concrete
fill 136 120 301 136 121 302 minecraft:white_concrete
fill 136 120 303 136 121 303 minecraft:red_concrete
fill 136 120 305 136 121 306 minecraft:white_concrete
fill 136 120 307 136 121 308 minecraft:red_concrete
fill 136 120 309 136 121 310 minecraft:white_concrete
fill 136 120 311 136 121 311 minecraft:red_concrete
fill 136 120 313 136 121 314 minecraft:white_concrete
fill 136 120 315 136 121 316 minecraft:red_concrete
fill 136 120 317 136 121 317 minecraft:white_concrete
setblock 97 121 310 minecraft:brown_terracotta
setblock 97 121 313 minecraft:brown_terracotta
fill 98 121 314 99 121 314 minecraft:brown_terracotta
setblock 99 121 284 minecraft:red_terracotta
setblock 99 121 288 minecraft:red_terracotta
setblock 99 121 292 minecraft:red_terracotta
setblock 99 121 309 minecraft:brown_terracotta
setblock 100 121 310 minecraft:brown_terracotta
setblock 100 121 313 minecraft:brown_terracotta
fill 101 121 294 103 121 298 minecraft:red_terracotta
fill 101 121 311 101 121 312 minecraft:brown_terracotta
fill 102 121 291 103 121 293 minecraft:red_terracotta
fill 102 121 299 103 121 301 minecraft:red_terracotta
fill 103 121 289 105 121 290 minecraft:red_terracotta
fill 103 121 302 105 121 303 minecraft:red_terracotta
fill 104 121 287 106 121 288 minecraft:red_terracotta
fill 104 121 291 104 121 292 minecraft:red_terracotta
fill 104 121 293 104 121 299 minecraft:magma_block
fill 104 121 300 104 121 301 minecraft:red_terracotta
fill 104 121 304 107 121 305 minecraft:red_terracotta
fill 105 121 286 109 121 286 minecraft:red_terracotta
fill 105 121 291 105 121 292 minecraft:magma_block
fill 105 121 300 105 121 301 minecraft:magma_block
fill 105 121 306 109 121 306 minecraft:red_terracotta
fill 106 121 285 111 121 285 minecraft:red_terracotta
fill 106 121 289 106 121 290 minecraft:magma_block
setblock 106 121 302 minecraft:magma_block
setblock 106 121 303 minecraft:red_terracotta
fill 106 121 307 111 121 307 minecraft:red_terracotta
setblock 107 121 287 minecraft:red_terracotta
setblock 107 121 288 minecraft:magma_block
setblock 107 121 303 minecraft:magma_block
fill 108 121 278 108 121 282 minecraft:brown_terracotta
fill 108 121 284 122 121 284 minecraft:red_terracotta
fill 108 121 287 109 121 287 minecraft:magma_block
setblock 108 121 304 minecraft:magma_block
setblock 108 121 305 minecraft:red_terracotta
fill 108 121 308 122 121 308 minecraft:red_terracotta
setblock 109 121 277 minecraft:brown_terracotta
fill 109 121 282 109 121 283 minecraft:brown_terracotta
setblock 109 121 305 minecraft:magma_block
fill 110 121 276 111 121 276 minecraft:brown_terracotta
fill 110 121 281 113 200 281 minecraft:red_terracotta
setblock 110 121 282 minecraft:brown_terracotta
fill 110 121 283 120 121 283 minecraft:red_terracotta
fill 110 121 286 111 121 286 minecraft:magma_block
fill 110 121 306 111 121 306 minecraft:magma_block
fill 110 121 309 120 121 309 minecraft:red_terracotta
fill 111 121 282 117 121 282 minecraft:red_terracotta
fill 112 121 285 119 121 285 minecraft:magma_block
fill 112 121 307 118 121 307 minecraft:magma_block
fill 113 121 310 117 121 310 minecraft:red_terracotta
fill 114 121 276 114 121 277 minecraft:brown_terracotta
fill 114 121 281 116 121 281 minecraft:brown_terracotta
fill 115 121 277 115 121 278 minecraft:brown_terracotta
fill 116 121 279 116 121 280 minecraft:brown_terracotta
fill 119 121 306 120 121 306 minecraft:magma_block
fill 119 121 307 124 121 307 minecraft:red_terracotta
fill 120 121 285 124 121 285 minecraft:red_terracotta
setblock 120 121 286 minecraft:magma_block
fill 121 121 286 125 121 286 minecraft:red_terracotta
fill 121 121 287 122 121 287 minecraft:magma_block
fill 121 121 305 122 121 305 minecraft:magma_block
fill 121 121 306 125 121 306 minecraft:red_terracotta
fill 123 121 287 126 121 287 minecraft:red_terracotta
setblock 123 121 288 minecraft:magma_block
setblock 123 121 304 minecraft:magma_block
fill 123 121 305 126 121 305 minecraft:red_terracotta
fill 124 121 288 126 121 288 minecraft:red_terracotta
fill 124 121 289 124 121 290 minecraft:magma_block
fill 124 121 302 124 121 303 minecraft:magma_block
fill 124 121 304 126 121 304 minecraft:red_terracotta
fill 125 121 289 127 121 290 minecraft:red_terracotta
setblock 125 121 291 minecraft:magma_block
fill 125 121 300 125 121 301 minecraft:magma_block
fill 125 121 302 127 121 303 minecraft:red_terracotta
fill 126 121 291 128 121 291 minecraft:red_terracotta
fill 126 121 292 126 121 299 minecraft:magma_block
fill 126 121 300 128 121 301 minecraft:red_terracotta
fill 127 121 292 128 121 299 minecraft:red_terracotta
fill 129 121 294 129 121 298 minecraft:red_terracotta
fill 94 122 275 94 123 276 minecraft:white_concrete
fill 94 122 277 94 123 278 minecraft:red_concrete
fill 94 122 279 94 123 280 minecraft:white_concrete
fill 94 122 281 94 123 282 minecraft:red_concrete
fill 94 122 283 94 123 284 minecraft:white_concrete
fill 94 122 285 94 123 286 minecraft:red_concrete
fill 94 122 290 94 123 290 minecraft:red_concrete
fill 94 122 291 94 123 292 minecraft:white_concrete
fill 94 122 293 94 123 294 minecraft:red_concrete
fill 94 122 295 94 123 296 minecraft:white_concrete
fill 94 122 297 94 123 298 minecraft:red_concrete
fill 94 122 299 94 123 300 minecraft:white_concrete
fill 94 122 301 94 123 302 minecraft:red_concrete
fill 94 122 303 94 123 304 minecraft:white_concrete
fill 94 122 305 94 123 306 minecraft:red_concrete
fill 94 122 307 94 123 308 minecraft:white_concrete
fill 94 122 309 94 123 310 minecraft:red_concrete
fill 94 122 311 94 123 312 minecraft:white_concrete
fill 94 122 313 94 123 314 minecraft:red_concrete
fill 94 122 315 94 123 316 minecraft:white_concrete
fill 95 122 275 95 123 275 minecraft:white_concrete
fill 95 122 317 95 123 317 minecraft:white_concrete
fill 96 122 275 97 123 275 minecraft:red_concrete
fill 96 122 317 97 123 317 minecraft:red_concrete
fill 98 122 275 99 123 275 minecraft:white_concrete
fill 98 122 317 99 123 317 minecraft:white_concrete
fill 100 122 275 101 123 275 minecraft:red_concrete
fill 100 122 317 101 123 317 minecraft:red_concrete
fill 102 122 275 103 123 275 minecraft:white_concrete
fill 102 122 317 103 123 317 minecraft:white_concrete
fill 104 122 275 105 123 275 minecraft:red_concrete
fill 104 122 317 105 123 317 minecraft:red_concrete
fill 106 122 275 107 123 275 minecraft:white_concrete
fill 106 122 317 107 123 317 minecraft:white_concrete
fill 108 122 275 109 123 275 minecraft:red_concrete
fill 108 122 317 109 123 317 minecraft:red_concrete
fill 110 122 275 111 123 275 minecraft:white_concrete
fill 110 122 317 111 123 317 minecraft:white_concrete
fill 111 122 282 112 200 282 minecraft:red_terracotta
fill 112 122 275 113 123 275 minecraft:red_concrete
fill 112 122 317 113 123 317 minecraft:red_concrete
fill 114 122 275 115 123 275 minecraft:white_concrete
fill 114 122 317 115 123 317 minecraft:white_concrete
fill 116 122 275 117 123 275 minecraft:red_concrete
fill 116 122 317 117 123 317 minecraft:red_concrete
fill 118 122 275 119 123 275 minecraft:white_concrete
fill 118 122 317 119 123 317 minecraft:white_concrete
fill 120 122 275 121 123 275 minecraft:red_concrete
fill 120 122 317 121 123 317 minecraft:red_concrete
fill 122 122 275 123 123 275 minecraft:white_concrete
fill 122 122 317 123 123 317 minecraft:white_concrete
fill 124 122 275 125 123 275 minecraft:red_concrete
fill 124 122 317 125 123 317 minecraft:red_concrete
fill 126 122 275 127 123 275 minecraft:white_concrete
fill 126 122 317 127 123 317 minecraft:white_concrete
fill 128 122 275 129 123 275 minecraft:red_concrete
fill 128 122 317 129 123 317 minecraft:red_concrete
fill 130 122 275 131 123 275 minecraft:white_concrete
fill 130 122 317 131 123 317 minecraft:white_concrete
fill 132 122 275 133 123 275 minecraft:red_concrete
fill 132 122 317 133 123 317 minecraft:red_concrete
fill 134 122 275 135 123 275 minecraft:white_concrete
fill 134 122 317 135 123 317 minecraft:white_concrete
fill 136 122 276 136 123 276 minecraft:white_concrete
fill 136 122 277 136 123 278 minecraft:red_concrete
fill 136 122 279 136 123 280 minecraft:white_concrete
fill 136 122 281 136 123 282 minecraft:red_concrete
fill 136 122 283 136 123 284 minecraft:white_concrete
fill 136 122 285 136 123 286 minecraft:red_concrete
fill 136 122 287 136 123 288 minecraft:white_concrete
fill 136 122 289 136 123 290 minecraft:red_concrete
fill 136 122 291 136 123 292 minecraft:white_concrete
fill 136 122 293 136 123 294 minecraft:red_concrete
fill 136 122 295 136 123 296 minecraft:white_concrete
fill 136 122 297 136 123 298 minecraft:red_concrete
fill 136 122 299 136 123 300 minecraft:white_concrete
fill 136 122 301 136 123 302 minecraft:red_concrete
fill 136 122 303 136 123 304 minecraft:white_concrete
fill 136 122 305 136 123 306 minecraft:red_concrete
fill 136 122 307 136 123 308 minecraft:white_concrete
fill 136 122 309 136 123 310 minecraft:red_concrete
fill 136 122 311 136 123 312 minecraft:white_concrete
fill 136 122 313 136 123 314 minecraft:red_concrete
fill 136 122 315 136 123 316 minecraft:white_concrete
fill 136 122 317 136 123 317 minecraft:red_concrete
setblock 97 123 278 minecraft:light[level=12]
setblock 97 123 285 minecraft:light[level=12]
setblock 97 123 292 minecraft:light[level=12]
setblock 97 123 299 minecraft:light[level=12]
setblock 97 123 306 minecraft:light[level=12]
setblock 97 123 313 minecraft:light[level=12]
fill 103 123 310 111 123 315 minecraft:brown_terracotta
setblock 104 123 278 minecraft:light[level=12]
setblock 104 123 285 minecraft:light[level=12]
setblock 104 123 292 minecraft:light[level=12]
setblock 104 123 299 minecraft:light[level=12]
setblock 104 123 306 minecraft:light[level=12]
setblock 111 123 285 minecraft:light[level=12]
setblock 111 123 292 minecraft:light[level=12]
setblock 111 123 299 minecraft:light[level=12]
setblock 111 123 306 minecraft:light[level=12]
setblock 118 123 278 minecraft:light[level=12]
setblock 118 123 285 minecraft:light[level=12]
setblock 118 123 292 minecraft:light[level=12]
setblock 118 123 299 minecraft:light[level=12]
setblock 118 123 306 minecraft:light[level=12]
setblock 118 123 313 minecraft:light[level=12]
setblock 125 123 278 minecraft:light[level=12]
setblock 125 123 285 minecraft:light[level=12]
setblock 125 123 292 minecraft:light[level=12]
setblock 125 123 299 minecraft:light[level=12]
setblock 125 123 306 minecraft:light[level=12]
setblock 125 123 313 minecraft:light[level=12]
fill 129 123 283 129 123 285 minecraft:red_terracotta
fill 130 123 282 132 123 282 minecraft:red_terracotta
fill 130 123 286 132 123 286 minecraft:red_terracotta
fill 130 123 294 132 200 295 minecraft:red_terracotta
fill 131 123 293 131 200 293 minecraft:red_terracotta
fill 131 123 296 131 200 296 minecraft:red_terracotta
setblock 132 123 278 minecraft:light[level=12]
setblock 132 123 292 minecraft:light[level=12]
setblock 132 123 299 minecraft:light[level=12]
setblock 132 123 306 minecraft:light[level=12]
setblock 132 123 313 minecraft:light[level=12]
fill 133 123 283 133 123 285 minecraft:red_terracotta
fill 94 124 275 94 125 276 minecraft:red_concrete
fill 94 124 277 94 125 278 minecraft:white_concrete
fill 94 124 279 94 125 280 minecraft:red_concrete
fill 94 124 281 94 125 282 minecraft:white_concrete
fill 94 124 283 94 125 284 minecraft:red_concrete
fill 94 124 285 94 125 286 minecraft:white_concrete
fill 94 124 287 94 125 288 minecraft:red_concrete
fill 94 124 289 94 125 290 minecraft:white_concrete
fill 94 124 291 94 125 292 minecraft:red_concrete
fill 94 124 293 94 125 294 minecraft:white_concrete
fill 94 124 295 94 125 296 minecraft:red_concrete
fill 94 124 297 94 125 298 minecraft:white_concrete
fill 94 124 299 94 125 300 minecraft:red_concrete
fill 94 124 301 94 125 302 minecraft:white_concrete
fill 94 124 303 94 125 304 minecraft:red_concrete
fill 94 124 305 94 125 306 minecraft:white_concrete
fill 94 124 307 94 125 308 minecraft:red_concrete
fill 94 124 309 94 125 310 minecraft:white_concrete
fill 94 124 311 94 125 312 minecraft:red_concrete
fill 94 124 313 94 125 314 minecraft:white_concrete
fill 94 124 315 94 125 316 minecraft:red_concrete
fill 95 124 275 95 125 275 minecraft:red_concrete
fill 95 124 317 95 125 317 minecraft:red_concrete
fill 96 124 275 97 125 275 minecraft:white_concrete
fill 96 124 317 97 125 317 minecraft:white_concrete
fill 98 124 275 99 125 275 minecraft:red_concrete
fill 98 124 317 99 125 317 minecraft:red_concrete
fill 100 124 275 101 125 275 minecraft:white_concrete
fill 100 124 317 101 125 317 minecraft:white_concrete
fill 102 124 275 103 125 275 minecraft:red_concrete
fill 102 124 317 103 125 317 minecraft:red_concrete
fill 103 124 310 111 124 315 minecraft:red_terracotta
fill 104 124 275 105 125 275 minecraft:white_concrete
fill 104 124 317 105 125 317 minecraft:white_concrete
fill 106 124 275 107 125 275 minecraft:red_concrete
fill 106 124 317 107 125 317 minecraft:red_concrete
fill 108 124 275 109 125 275 minecraft:white_concrete
fill 108 124 317 109 125 317 minecraft:white_concrete
fill 110 124 275 111 125 275 minecraft:red_concrete
fill 110 124 317 111 125 317 minecraft:red_concrete
fill 112 124 275 113 125 275 minecraft:white_concrete
fill 112 124 317 113 125 317 minecraft:white_concrete
fill 114 124 275 115 125 275 minecraft:red_concrete
fill 114 124 317 115 125 317 minecraft:red_concrete
fill 116 124 275 117 125 275 minecraft:white_concrete
fill 116 124 317 117 125 317 minecraft:white_concrete
fill 118 124 275 119 125 275 minecraft:red_concrete
fill 118 124 317 119 125 317 minecraft:red_concrete
fill 120 124 275 121 125 275 minecraft:white_concrete
fill 120 124 317 121 125 317 minecraft:white_concrete
fill 122 124 275 123 125 275 minecraft:red_concrete
fill 122 124 317 123 125 317 minecraft:red_concrete
fill 124 124 275 125 125 275 minecraft:white_concrete
fill 124 124 317 125 125 317 minecraft:white_concrete
fill 126 124 275 127 125 275 minecraft:red_concrete
fill 126 124 317 127 125 317 minecraft:red_concrete
fill 128 124 275 129 125 275 minecraft:white_concrete
fill 128 124 317 129 125 317 minecraft:white_concrete
fill 129 124 294 129 125 295 minecraft:brown_terracotta
fill 130 124 275 131 125 275 minecraft:red_concrete
fill 130 124 293 130 125 293 minecraft:brown_terracotta
fill 130 124 296 130 125 296 minecraft:brown_terracotta
fill 130 124 317 131 125 317 minecraft:red_concrete
fill 132 124 275 133 125 275 minecraft:white_concrete
fill 132 124 293 132 125 293 minecraft:brown_terracotta
fill 132 124 296 132 125 296 minecraft:brown_terracotta
fill 132 124 317 133 125 317 minecraft:white_concrete
fill 133 124 294 133 125 295 minecraft:brown_terracotta
fill 134 124 275 135 125 275 minecraft:red_concrete
fill 134 124 317 135 125 317 minecraft:red_concrete
fill 136 124 276 136 125 276 minecraft:red_concrete
fill 136 124 277 136 125 278 minecraft:white_concrete
fill 136 124 279 136 125 280 minecraft:red_concrete
fill 136 124 281 136 125 282 minecraft:white_concrete
fill 136 124 283 136 125 284 minecraft:red_concrete
fill 136 124 285 136 125 286 minecraft:white_concrete
fill 136 124 287 136 125 288 minecraft:red_concrete
fill 136 124 289 136 125 290 minecraft:white_concrete
fill 136 124 291 136 125 292 minecraft:red_concrete
fill 136 124 293 136 125 294 minecraft:white_concrete
fill 136 124 295 136 125 296 minecraft:red_concrete
fill 136 124 297 136 125 298 minecraft:white_concrete
fill 136 124 299 136 125 300 minecraft:red_concrete
fill 136 124 301 136 125 302 minecraft:white_concrete
fill 136 124 303 136 125 304 minecraft:red_concrete
fill 136 124 305 136 125 306 minecraft:white_concrete
fill 136 124 307 136 125 308 minecraft:red_concrete
fill 136 124 309 136 125 310 minecraft:white_concrete
fill 136 124 311 136 125 312 minecraft:red_concrete
fill 136 124 313 136 125 314 minecraft:white_concrete
fill 136 124 315 136 125 316 minecraft:red_concrete
fill 136 124 317 136 125 317 minecraft:white_concrete
setblock 97 125 278 minecraft:light[level=15]
setblock 97 125 286 minecraft:light[level=15]
setblock 97 125 294 minecraft:light[level=15]
setblock 97 125 302 minecraft:light[level=15]
setblock 97 125 310 minecraft:light[level=15]
fill 103 125 310 111 125 310 minecraft:yellow_concrete
setblock 105 125 278 minecraft:light[level=15]
setblock 105 125 286 minecraft:light[level=15]
setblock 105 125 294 minecraft:light[level=15]
setblock 105 125 302 minecraft:light[level=15]
fill 106 125 316 108 128 316 minecraft:shroomlight
setblock 113 125 286 minecraft:light[level=15]
setblock 113 125 294 minecraft:light[level=15]
setblock 113 125 302 minecraft:light[level=15]
setblock 113 125 310 minecraft:light[level=15]
setblock 121 125 278 minecraft:light[level=15]
setblock 121 125 286 minecraft:light[level=15]
setblock 121 125 294 minecraft:light[level=15]
setblock 121 125 302 minecraft:light[level=15]
setblock 121 125 310 minecraft:light[level=15]
setblock 129 125 278 minecraft:light[level=15]
setblock 129 125 286 minecraft:light[level=15]
setblock 129 125 293 minecraft:brown_terracotta
setblock 129 125 296 minecraft:brown_terracotta
setblock 129 125 302 minecraft:light[level=15]
setblock 129 125 310 minecraft:light[level=15]
fill 130 125 292 132 125 292 minecraft:brown_terracotta
fill 130 125 297 132 125 297 minecraft:brown_terracotta
setblock 133 125 293 minecraft:brown_terracotta
setblock 133 125 296 minecraft:brown_terracotta
fill 94 126 275 94 127 276 minecraft:white_concrete
fill 94 126 277 94 127 278 minecraft:red_concrete
fill 94 126 279 94 127 280 minecraft:white_concrete
fill 94 126 281 94 127 282 minecraft:red_concrete
fill 94 126 283 94 127 284 minecraft:white_concrete
fill 94 126 285 94 127 286 minecraft:red_concrete
fill 94 126 287 94 127 288 minecraft:white_concrete
fill 94 126 289 94 127 290 minecraft:red_concrete
fill 94 126 291 94 127 292 minecraft:white_concrete
fill 94 126 293 94 127 294 minecraft:red_concrete
fill 94 126 295 94 127 296 minecraft:white_concrete
fill 94 126 297 94 127 298 minecraft:red_concrete
fill 94 126 299 94 127 300 minecraft:white_concrete
fill 94 126 301 94 127 302 minecraft:red_concrete
fill 94 126 303 94 127 304 minecraft:white_concrete
fill 94 126 305 94 127 306 minecraft:red_concrete
fill 94 126 307 94 127 308 minecraft:white_concrete
fill 94 126 309 94 127 310 minecraft:red_concrete
fill 94 126 311 94 127 312 minecraft:white_concrete
fill 94 126 313 94 127 314 minecraft:red_concrete
fill 94 126 315 94 127 316 minecraft:white_concrete
fill 95 126 275 95 127 275 minecraft:white_concrete
fill 95 126 276 95 127 281 minecraft:red_terracotta
fill 95 126 284 96 126 289 minecraft:red_terracotta
fill 95 126 292 96 126 297 minecraft:red_terracotta
fill 95 126 300 96 126 305 minecraft:red_terracotta
fill 95 126 308 96 126 313 minecraft:red_terracotta
fill 95 126 316 100 127 316 minecraft:red_terracotta
fill 95 126 317 95 127 317 minecraft:white_concrete
fill 96 126 275 97 127 275 minecraft:red_concrete
fill 96 126 277 96 126 283 minecraft:red_terracotta
fill 96 126 290 96 126 291 minecraft:red_terracotta
fill 96 126 298 96 126 299 minecraft:red_terracotta
fill 96 126 306 96 126 307 minecraft:red_terracotta
fill 96 126 314 96 126 315 minecraft:red_terracotta
fill 96 126 317 97 127 317 minecraft:red_concrete
fill 97 126 277 134 126 277 minecraft:red_terracotta
fill 97 126 315 135 126 315 minecraft:red_terracotta
fill 98 126 275 99 127 275 minecraft:white_concrete
fill 98 126 276 103 127 276 minecraft:red_terracotta
fill 98 126 317 99 127 317 minecraft:white_concrete
fill 100 126 275 101 127 275 minecraft:red_concrete
fill 100 126 317 101 127 317 minecraft:red_concrete
fill 102 126 275 103 127 275 minecraft:white_concrete
fill 102 126 317 103 127 317 minecraft:white_concrete
setblock 103 126 310 minecraft:red_terracotta
fill 103 126 316 105 127 316 minecraft:red_terracotta
fill 104 126 275 105 127 275 minecraft:red_concrete
fill 104 126 317 105 127 317 minecraft:red_concrete
fill 106 126 275 107 127 275 minecraft:white_concrete
fill 106 126 276 111 127 276 minecraft:red_terracotta
fill 106 126 317 107 127 317 minecraft:white_concrete
setblock 107 126 310 minecraft:red_terracotta
fill 108 126 275 109 127 275 minecraft:red_concrete
fill 108 126 317 109 127 317 minecraft:red_concrete
fill 110 126 275 111 127 275 minecraft:white_concrete
fill 110 126 317 111 127 317 minecraft:white_concrete
setblock 111 126 310 minecraft:red_terracotta
fill 111 126 316 116 127 316 minecraft:red_terracotta
fill 112 126 275 113 127 275 minecraft:red_concrete
fill 112 126 317 113 127 317 minecraft:red_concrete
fill 114 126 275 115 127 275 minecraft:white_concrete
fill 114 126 276 119 127 276 minecraft:red_terracotta
fill 114 126 317 115 127 317 minecraft:white_concrete
fill 116 126 275 117 127 275 minecraft:red_concrete
fill 116 126 317 117 127 317 minecraft:red_concrete
fill 118 126 275 119 127 275 minecraft:white_concrete
fill 118 126 317 119 127 317 minecraft:white_concrete
fill 119 126 316 124 127 316 minecraft:red_terracotta
fill 120 126 275 121 127 275 minecraft:red_concrete
fill 120 126 317 121 127 317 minecraft:red_concrete
fill 122 126 275 123 127 275 minecraft:white_concrete
fill 122 126 276 127 127 276 minecraft:red_terracotta
fill 122 126 317 123 127 317 minecraft:white_concrete
fill 124 126 275 125 127 275 minecraft:red_concrete
fill 124 126 317 125 127 317 minecraft:red_concrete
fill 126 126 275 127 127 275 minecraft:white_concrete
fill 126 126 317 127 127 317 minecraft:white_concrete
fill 127 126 316 132 127 316 minecraft:red_terracotta
fill 128 126 275 129 127 275 minecraft:red_concrete
fill 128 126 317 129 127 317 minecraft:red_concrete
fill 130 126 275 131 127 275 minecraft:white_concrete
fill 130 126 276 135 127 276 minecraft:red_terracotta
fill 130 126 317 131 127 317 minecraft:white_concrete
fill 132 126 275 133 127 275 minecraft:red_concrete
fill 132 126 317 133 127 317 minecraft:red_concrete
fill 134 126 275 135 127 275 minecraft:white_concrete
fill 134 126 278 134 126 314 minecraft:red_terracotta
fill 134 126 317 135 127 317 minecraft:white_concrete
fill 135 126 279 135 127 284 minecraft:red_terracotta
fill 135 126 287 135 127 292 minecraft:red_terracotta
fill 135 126 295 135 127 300 minecraft:red_terracotta
fill 135 126 303 135 127 308 minecraft:red_terracotta
fill 135 126 311 135 127 314 minecraft:red_terracotta
fill 135 126 316 135 127 316 minecraft:red_terracotta
fill 136 126 276 136 127 276 minecraft:white_concrete
fill 136 126 277 136 127 278 minecraft:red_concrete
fill 136 126 279 136 127 280 minecraft:white_concrete
fill 136 126 281 136 127 282 minecraft:red_concrete
fill 136 126 283 136 127 284 minecraft:white_concrete
fill 136 126 285 136 127 286 minecraft:red_concrete
fill 136 126 287 136 127 288 minecraft:white_concrete
fill 136 126 289 136 127 290 minecraft:red_concrete
fill 136 126 291 136 127 292 minecraft:white_concrete
fill 136 126 293 136 127 294 minecraft:red_concrete
fill 136 126 295 136 127 296 minecraft:white_concrete
fill 136 126 297 136 127 298 minecraft:red_concrete
fill 136 126 299 136 127 300 minecraft:white_concrete
fill 136 126 301 136 127 302 minecraft:red_concrete
fill 136 126 303 136 127 304 minecraft:white_concrete
fill 136 126 305 136 127 306 minecraft:red_concrete
fill 136 126 307 136 127 308 minecraft:white_concrete
fill 136 126 309 136 127 310 minecraft:red_concrete
fill 136 126 311 136 127 312 minecraft:white_concrete
fill 136 126 313 136 127 314 minecraft:red_concrete
fill 136 126 315 136 127 316 minecraft:white_concrete
fill 136 126 317 136 127 317 minecraft:red_concrete
fill 95 127 284 95 127 289 minecraft:red_terracotta
fill 95 127 292 95 127 297 minecraft:red_terracotta
fill 95 127 300 95 127 305 minecraft:red_terracotta
fill 95 127 308 95 127 313 minecraft:red_terracotta
setblock 135 127 315 minecraft:red_terracotta
fill 94 128 275 94 129 276 minecraft:red_concrete
fill 94 128 277 94 129 278 minecraft:white_concrete
fill 94 128 279 94 129 280 minecraft:red_concrete
fill 94 128 281 94 129 282 minecraft:white_concrete
fill 94 128 283 94 129 284 minecraft:red_concrete
fill 94 128 285 94 129 286 minecraft:white_concrete
fill 94 128 287 94 129 288 minecraft:red_concrete
fill 94 128 289 94 129 290 minecraft:white_concrete
fill 94 128 291 94 129 292 minecraft:red_concrete
fill 94 128 293 94 129 294 minecraft:white_concrete
fill 94 128 295 94 129 296 minecraft:red_concrete
fill 94 128 297 94 129 298 minecraft:white_concrete
fill 94 128 299 94 129 300 minecraft:red_concrete
fill 94 128 301 94 129 302 minecraft:white_concrete
fill 94 128 303 94 129 304 minecraft:red_concrete
fill 94 128 305 94 129 306 minecraft:white_concrete
fill 94 128 307 94 129 308 minecraft:red_concrete
fill 94 128 309 94 129 310 minecraft:white_concrete
fill 94 128 311 94 129 312 minecraft:red_concrete
fill 94 128 313 94 129 314 minecraft:white_concrete
fill 94 128 315 94 129 316 minecraft:red_concrete
fill 95 128 275 95 129 275 minecraft:red_concrete
fill 95 128 317 95 129 317 minecraft:red_concrete
fill 96 128 275 97 129 275 minecraft:white_concrete
fill 96 128 317 97 129 317 minecraft:white_concrete
fill 98 128 275 99 129 275 minecraft:red_concrete
fill 98 128 317 99 129 317 minecraft:red_concrete
fill 100 128 275 101 129 275 minecraft:white_concrete
fill 100 128 317 101 129 317 minecraft:white_concrete
fill 102 128 275 103 129 275 minecraft:red_concrete
fill 102 128 317 103 129 317 minecraft:red_concrete
fill 104 128 275 105 129 275 minecraft:white_concrete
fill 104 128 317 105 129 317 minecraft:white_concrete
fill 106 128 275 107 129 275 minecraft:red_concrete
fill 106 128 317 107 129 317 minecraft:red_concrete
fill 108 128 275 109 129 275 minecraft:white_concrete
fill 108 128 317 109 129 317 minecraft:white_concrete
fill 110 128 275 111 129 275 minecraft:red_concrete
fill 110 128 317 111 129 317 minecraft:red_concrete
fill 112 128 275 113 129 275 minecraft:white_concrete
fill 112 128 317 113 129 317 minecraft:white_concrete
fill 114 128 275 115 129 275 minecraft:red_concrete
fill 114 128 317 115 129 317 minecraft:red_concrete
fill 116 128 275 117 129 275 minecraft:white_concrete
fill 116 128 317 117 129 317 minecraft:white_concrete
fill 118 128 275 119 129 275 minecraft:red_concrete
fill 118 128 317 119 129 317 minecraft:red_concrete
fill 120 128 275 121 129 275 minecraft:white_concrete
fill 120 128 317 121 129 317 minecraft:white_concrete
fill 122 128 275 123 129 275 minecraft:red_concrete
fill 122 128 317 123 129 317 minecraft:red_concrete
fill 124 128 275 125 129 275 minecraft:white_concrete
fill 124 128 317 125 129 317 minecraft:white_concrete
fill 126 128 275 127 129 275 minecraft:red_concrete
fill 126 128 317 127 129 317 minecraft:red_concrete
fill 128 128 275 129 129 275 minecraft:white_concrete
fill 128 128 317 129 129 317 minecraft:white_concrete
fill 130 128 275 131 129 275 minecraft:red_concrete
fill 130 128 317 131 129 317 minecraft:red_concrete
fill 132 128 275 133 129 275 minecraft:white_concrete
fill 132 128 317 133 129 317 minecraft:white_concrete
fill 134 128 275 135 129 275 minecraft:red_concrete
fill 134 128 317 135 129 317 minecraft:red_concrete
fill 136 128 276 136 129 276 minecraft:red_concrete
fill 136 128 277 136 129 278 minecraft:white_concrete
fill 136 128 279 136 129 280 minecraft:red_concrete
fill 136 128 281 136 129 282 minecraft:white_concrete
fill 136 128 283 136 129 284 minecraft:red_concrete
fill 136 128 285 136 129 286 minecraft:white_concrete
fill 136 128 287 136 129 288 minecraft:red_concrete
fill 136 128 289 136 129 290 minecraft:white_concrete
fill 136 128 291 136 129 292 minecraft:red_concrete
fill 136 128 293 136 129 294 minecraft:white_concrete
fill 136 128 295 136 129 296 minecraft:red_concrete
fill 136 128 297 136 129 298 minecraft:white_concrete
fill 136 128 299 136 129 300 minecraft:red_concrete
fill 136 128 301 136 129 302 minecraft:white_concrete
fill 136 128 303 136 129 304 minecraft:red_concrete
fill 136 128 305 136 129 306 minecraft:white_concrete
fill 136 128 307 136 129 308 minecraft:red_concrete
fill 136 128 309 136 129 310 minecraft:white_concrete
fill 136 128 311 136 129 312 minecraft:red_concrete
fill 136 128 313 136 129 314 minecraft:white_concrete
fill 136 128 315 136 129 316 minecraft:red_concrete
fill 136 128 317 136 129 317 minecraft:white_concrete
setblock 97 129 278 minecraft:light[level=12]
setblock 97 129 285 minecraft:light[level=12]
setblock 97 129 292 minecraft:light[level=12]
setblock 97 129 299 minecraft:light[level=12]
setblock 97 129 306 minecraft:light[level=12]
setblock 97 129 310 minecraft:brown_terracotta
setblock 97 129 313 minecraft:brown_terracotta
fill 98 129 314 99 129 314 minecraft:brown_terracotta
setblock 99 129 309 minecraft:brown_terracotta
setblock 100 129 310 minecraft:brown_terracotta
setblock 100 129 313 minecraft:brown_terracotta
fill 101 129 311 101 129 312 minecraft:brown_terracotta
setblock 104 129 278 minecraft:light[level=12]
setblock 104 129 285 minecraft:light[level=12]
setblock 104 129 292 minecraft:light[level=12]
setblock 104 129 299 minecraft:light[level=12]
setblock 104 129 306 minecraft:light[level=12]
setblock 104 129 313 minecraft:light[level=12]
setblock 111 129 285 minecraft:light[level=12]
setblock 111 129 292 minecraft:light[level=12]
setblock 111 129 299 minecraft:light[level=12]
setblock 111 129 306 minecraft:light[level=12]
setblock 111 129 313 minecraft:light[level=12]
setblock 118 129 278 minecraft:light[level=12]
setblock 118 129 285 minecraft:light[level=12]
setblock 118 129 292 minecraft:light[level=12]
setblock 118 129 299 minecraft:light[level=12]
setblock 118 129 306 minecraft:light[level=12]
setblock 118 129 313 minecraft:light[level=12]
setblock 125 129 278 minecraft:light[level=12]
setblock 125 129 285 minecraft:light[level=12]
setblock 125 129 292 minecraft:light[level=12]
setblock 125 129 299 minecraft:light[level=12]
setblock 125 129 306 minecraft:light[level=12]
setblock 125 129 313 minecraft:light[level=12]
setblock 132 129 278 minecraft:light[level=12]
setblock 132 129 292 minecraft:light[level=12]
setblock 132 129 299 minecraft:light[level=12]
setblock 132 129 306 minecraft:light[level=12]
setblock 132 129 313 minecraft:light[level=12]
fill 94 130 275 94 131 276 minecraft:white_concrete
fill 94 130 277 94 131 278 minecraft:red_concrete
fill 94 130 279 94 131 279 minecraft:white_concrete
fill 94 130 280 94 135 280 minecraft:shroomlight
fill 94 130 281 94 131 282 minecraft:red_concrete
fill 94 130 283 94 131 284 minecraft:white_concrete
fill 94 130 285 94 131 286 minecraft:red_concrete
fill 94 130 287 94 131 287 minecraft:white_concrete
fill 94 130 288 94 135 288 minecraft:shroomlight
fill 94 130 289 94 131 290 minecraft:red_concrete
fill 94 130 291 94 131 292 minecraft:white_concrete
fill 94 130 293 94 131 294 minecraft:red_concrete
fill 94 130 295 94 131 295 minecraft:white_concrete
fill 94 130 296 94 135 296 minecraft:shroomlight
fill 94 130 297 94 131 298 minecraft:red_concrete
fill 94 130 299 94 131 300 minecraft:white_concrete
fill 94 130 301 94 131 302 minecraft:red_concrete
fill 94 130 303 94 131 303 minecraft:white_concrete
fill 94 130 304 94 135 304 minecraft:shroomlight
fill 94 130 305 94 131 306 minecraft:red_concrete
fill 94 130 307 94 131 308 minecraft:white_concrete
fill 94 130 309 94 131 310 minecraft:red_concrete
fill 94 130 311 94 131 311 minecraft:white_concrete
fill 94 130 312 94 135 312 minecraft:shroomlight
fill 94 130 313 94 131 314 minecraft:red_concrete
fill 94 130 315 94 131 316 minecraft:white_concrete
fill 95 130 275 95 131 275 minecraft:white_concrete
fill 95 130 317 95 131 317 minecraft:white_concrete
fill 96 130 275 97 131 275 minecraft:red_concrete
fill 96 130 317 96 131 317 minecraft:red_concrete
fill 97 130 317 97 135 317 minecraft:shroomlight
fill 98 130 275 99 131 275 minecraft:white_concrete
fill 98 130 317 99 131 317 minecraft:white_concrete
fill 100 130 275 100 131 275 minecraft:red_concrete
fill 100 130 317 101 131 317 minecraft:red_concrete
fill 101 130 275 101 135 275 minecraft:shroomlight
fill 102 130 275 103 131 275 minecraft:white_concrete
fill 102 130 317 103 131 317 minecraft:white_concrete
fill 104 130 275 105 131 275 minecraft:red_concrete
fill 104 130 317 104 131 317 minecraft:red_concrete
fill 105 130 317 105 135 317 minecraft:shroomlight
fill 106 130 275 107 131 275 minecraft:white_concrete
fill 106 130 317 107 131 317 minecraft:white_concrete
fill 108 130 275 108 131 275 minecraft:red_concrete
fill 108 130 317 109 131 317 minecraft:red_concrete
fill 109 130 275 109 135 275 minecraft:shroomlight
fill 110 130 275 111 131 275 minecraft:white_concrete
fill 110 130 317 111 131 317 minecraft:white_concrete
fill 112 130 275 113 131 275 minecraft:red_concrete
fill 112 130 317 112 131 317 minecraft:red_concrete
fill 113 130 317 113 135 317 minecraft:shroomlight
fill 114 130 275 115 131 275 minecraft:white_concrete
fill 114 130 317 115 131 317 minecraft:white_concrete
fill 116 130 275 116 131 275 minecraft:red_concrete
fill 116 130 317 117 131 317 minecraft:red_concrete
fill 117 130 275 117 135 275 minecraft:shroomlight
fill 118 130 275 119 131 275 minecraft:white_concrete
fill 118 130 317 119 131 317 minecraft:white_concrete
fill 120 130 275 121 131 275 minecraft:red_concrete
fill 120 130 317 120 131 317 minecraft:red_concrete
fill 121 130 317 121 135 317 minecraft:shroomlight
fill 122 130 275 123 131 275 minecraft:white_concrete
fill 122 130 317 123 131 317 minecraft:white_concrete
fill 124 130 275 124 131 275 minecraft:red_concrete
fill 124 130 317 125 131 317 minecraft:red_concrete
fill 125 130 275 125 135 275 minecraft:shroomlight
fill 126 130 275 127 131 275 minecraft:white_concrete
fill 126 130 317 127 131 317 minecraft:white_concrete
fill 128 130 275 129 131 275 minecraft:red_concrete
fill 128 130 317 128 131 317 minecraft:red_concrete
fill 129 130 317 129 135 317 minecraft:shroomlight
fill 130 130 275 131 131 275 minecraft:white_concrete
fill 130 130 317 131 131 317 minecraft:white_concrete
fill 132 130 275 132 131 275 minecraft:red_concrete
fill 132 130 317 133 131 317 minecraft:red_concrete
fill 133 130 275 133 135 275 minecraft:shroomlight
fill 134 130 275 135 131 275 minecraft:white_concrete
fill 134 130 317 135 131 317 minecraft:white_concrete
fill 136 130 276 136 131 276 minecraft:white_concrete
fill 136 130 277 136 131 278 minecraft:red_concrete
fill 136 130 279 136 131 279 minecraft:white_concrete
fill 136 130 280 136 135 280 minecraft:shroomlight
fill 136 130 281 136 131 282 minecraft:red_concrete
fill 136 130 283 136 131 284 minecraft:white_concrete
fill 136 130 285 136 131 286 minecraft:red_concrete
fill 136 130 287 136 131 287 minecraft:white_concrete
fill 136 130 288 136 135 288 minecraft:shroomlight
fill 136 130 289 136 131 290 minecraft:red_concrete
fill 136 130 291 136 131 292 minecraft:white_concrete
fill 136 130 293 136 131 294 minecraft:red_concrete
fill 136 130 295 136 131 295 minecraft:white_concrete
fill 136 130 296 136 135 296 minecraft:shroomlight
fill 136 130 297 136 131 298 minecraft:red_concrete
fill 136 130 299 136 131 300 minecraft:white_concrete
fill 136 130 301 136 131 302 minecraft:red_concrete
fill 136 130 303 136 131 303 minecraft:white_concrete
fill 136 130 304 136 135 304 minecraft:shroomlight
fill 136 130 305 136 131 306 minecraft:red_concrete
fill 136 130 307 136 131 308 minecraft:white_concrete
fill 136 130 309 136 131 310 minecraft:red_concrete
fill 136 130 311 136 131 311 minecraft:white_concrete
fill 136 130 312 136 135 312 minecraft:shroomlight
fill 136 130 313 136 131 314 minecraft:red_concrete
fill 136 130 315 136 131 316 minecraft:white_concrete
fill 136 130 317 136 131 317 minecraft:red_concrete
fill 129 131 283 129 131 285 minecraft:red_terracotta
fill 130 131 282 132 131 282 minecraft:red_terracotta
fill 130 131 286 132 131 286 minecraft:red_terracotta
fill 133 131 283 133 131 285 minecraft:red_terracotta
fill 94 132 275 94 133 276 minecraft:red_concrete
fill 94 132 277 94 133 278 minecraft:white_concrete
fill 94 132 279 94 133 279 minecraft:red_concrete
fill 94 132 281 94 133 282 minecraft:white_concrete
fill 94 132 283 94 133 284 minecraft:red_concrete
fill 94 132 285 94 133 286 minecraft:white_concrete
fill 94 132 287 94 133 287 minecraft:red_concrete
fill 94 132 289 94 133 290 minecraft:white_concrete
fill 94 132 291 94 133 292 minecraft:red_concrete
fill 94 132 293 94 133 294 minecraft:white_concrete
fill 94 132 295 94 133 295 minecraft:red_concrete
fill 94 132 297 94 133 298 minecraft:white_concrete
fill 94 132 299 94 133 300 minecraft:red_concrete
fill 94 132 301 94 133 302 minecraft:white_concrete
fill 94 132 303 94 133 303 minecraft:red_concrete
fill 94 132 305 94 133 306 minecraft:white_concrete
fill 94 132 307 94 133 308 minecraft:red_concrete
fill 94 132 309 94 133 310 minecraft:white_concrete
fill 94 132 311 94 133 311 minecraft:red_concrete
fill 94 132 313 94 133 314 minecraft:white_concrete
fill 94 132 315 94 133 316 minecraft:red_concrete
fill 95 132 275 95 133 275 minecraft:red_concrete
fill 95 132 317 95 133 317 minecraft:red_concrete
fill 96 132 275 97 133 275 minecraft:white_concrete
fill 96 132 317 96 133 317 minecraft:white_concrete
fill 98 132 275 99 133 275 minecraft:red_concrete
fill 98 132 317 99 133 317 minecraft:red_concrete
fill 100 132 275 100 133 275 minecraft:white_concrete
fill 100 132 317 101 133 317 minecraft:white_concrete
fill 102 132 275 103 133 275 minecraft:red_concrete
fill 102 132 317 103 133 317 minecraft:red_concrete
fill 104 132 275 105 133 275 minecraft:white_concrete
fill 104 132 317 104 133 317 minecraft:white_concrete
fill 106 132 275 107 133 275 minecraft:red_concrete
fill 106 132 317 107 133 317 minecraft:red_concrete
fill 108 132 275 108 133 275 minecraft:white_concrete
fill 108 132 317 109 133 317 minecraft:white_concrete
fill 110 132 275 111 133 275 minecraft:red_concrete
fill 110 132 317 111 133 317 minecraft:red_concrete
fill 112 132 275 113 133 275 minecraft:white_concrete
fill 112 132 317 112 133 317 minecraft:white_concrete
fill 114 132 275 115 133 275 minecraft:red_concrete
fill 114 132 317 115 133 317 minecraft:red_concrete
fill 116 132 275 116 133 275 minecraft:white_concrete
fill 116 132 317 117 133 317 minecraft:white_concrete
fill 118 132 275 119 133 275 minecraft:red_concrete
fill 118 132 317 119 133 317 minecraft:red_concrete
fill 120 132 275 121 133 275 minecraft:white_concrete
fill 120 132 317 120 133 317 minecraft:white_concrete
fill 122 132 275 123 133 275 minecraft:red_concrete
fill 122 132 317 123 133 317 minecraft:red_concrete
fill 124 132 275 124 133 275 minecraft:white_concrete
fill 124 132 317 125 133 317 minecraft:white_concrete
fill 126 132 275 127 133 275 minecraft:red_concrete
fill 126 132 317 127 133 317 minecraft:red_concrete
fill 128 132 275 129 133 275 minecraft:white_concrete
fill 128 132 317 128 133 317 minecraft:white_concrete
fill 130 132 275 131 133 275 minecraft:red_concrete
fill 130 132 317 131 133 317 minecraft:red_concrete
fill 132 132 275 132 133 275 minecraft:white_concrete
fill 132 132 317 133 133 317 minecraft:white_concrete
fill 134 132 275 135 133 275 minecraft:red_concrete
fill 134 132 317 135 133 317 minecraft:red_concrete
fill 136 132 276 136 133 276 minecraft:red_concrete
fill 136 132 277 136 133 278 minecraft:white_concrete
fill 136 132 279 136 133 279 minecraft:red_concrete
fill 136 132 281 136 133 282 minecraft:white_concrete
fill 136 132 283 136 133 284 minecraft:red_concrete
fill 136 132 285 136 133 286 minecraft:white_concrete
fill 136 132 287 136 133 287 minecraft:red_concrete
fill 136 132 289 136 133 290 minecraft:white_concrete
fill 136 132 291 136 133 292 minecraft:red_concrete
fill 136 132 293 136 133 294 minecraft:white_concrete
fill 136 132 295 136 133 295 minecraft:red_concrete
fill 136 132 297 136 133 298 minecraft:white_concrete
fill 136 132 299 136 133 300 minecraft:red_concrete
fill 136 132 301 136 133 302 minecraft:white_concrete
fill 136 132 303 136 133 303 minecraft:red_concrete
fill 136 132 305 136 133 306 minecraft:white_concrete
fill 136 132 307 136 133 308 minecraft:red_concrete
fill 136 132 309 136 133 310 minecraft:white_concrete
fill 136 132 311 136 133 311 minecraft:red_concrete
fill 136 132 313 136 133 314 minecraft:white_concrete
fill 136 132 315 136 133 316 minecraft:red_concrete
fill 136 132 317 136 133 317 minecraft:white_concrete
setblock 97 133 278 minecraft:light[level=15]
setblock 97 133 286 minecraft:light[level=15]
setblock 97 133 294 minecraft:light[level=15]
setblock 97 133 302 minecraft:light[level=15]
setblock 97 133 310 minecraft:light[level=15]
setblock 105 133 278 minecraft:light[level=15]
setblock 105 133 286 minecraft:light[level=15]
setblock 105 133 294 minecraft:light[level=15]
setblock 105 133 302 minecraft:light[level=15]
setblock 105 133 310 minecraft:light[level=15]
setblock 113 133 286 minecraft:light[level=15]
setblock 113 133 294 minecraft:light[level=15]
setblock 113 133 302 minecraft:light[level=15]
setblock 113 133 310 minecraft:light[level=15]
setblock 121 133 278 minecraft:light[level=15]
setblock 121 133 286 minecraft:light[level=15]
setblock 121 133 294 minecraft:light[level=15]
setblock 121 133 302 minecraft:light[level=15]
setblock 121 133 310 minecraft:light[level=15]
setblock 129 133 278 minecraft:light[level=15]
setblock 129 133 286 minecraft:light[level=15]
setblock 129 133 294 minecraft:light[level=15]
setblock 129 133 302 minecraft:light[level=15]
setblock 129 133 310 minecraft:light[level=15]
fill 94 134 275 94 135 276 minecraft:white_concrete
fill 94 134 277 94 135 278 minecraft:red_concrete
fill 94 134 279 94 135 279 minecraft:white_concrete
fill 94 134 281 94 135 282 minecraft:red_concrete
fill 94 134 283 94 135 284 minecraft:white_concrete
fill 94 134 285 94 135 286 minecraft:red_concrete
fill 94 134 287 94 135 287 minecraft:white_concrete
fill 94 134 289 94 135 290 minecraft:red_concrete
fill 94 134 291 94 135 292 minecraft:white_concrete
fill 94 134 293 94 135 294 minecraft:red_concrete
fill 94 134 295 94 135 295 minecraft:white_concrete
fill 94 134 297 94 135 298 minecraft:red_concrete
fill 94 134 299 94 135 300 minecraft:white_concrete
fill 94 134 301 94 135 302 minecraft:red_concrete
fill 94 134 303 94 135 303 minecraft:white_concrete
fill 94 134 305 94 135 306 minecraft:red_concrete
fill 94 134 307 94 135 308 minecraft:white_concrete
fill 94 134 309 94 135 310 minecraft:red_concrete
fill 94 134 311 94 135 311 minecraft:white_concrete
fill 94 134 313 94 135 314 minecraft:red_concrete
fill 94 134 315 94 135 316 minecraft:white_concrete
fill 95 134 275 95 135 275 minecraft:white_concrete
fill 95 134 317 95 135 317 minecraft:white_concrete
fill 96 134 275 97 135 275 minecraft:red_concrete
fill 96 134 317 96 135 317 minecraft:red_concrete
fill 98 134 275 99 135 275 minecraft:white_concrete
fill 98 134 317 99 135 317 minecraft:white_concrete
fill 100 134 275 100 135 275 minecraft:red_concrete
fill 100 134 317 101 135 317 minecraft:red_concrete
fill 102 134 275 103 135 275 minecraft:white_concrete
fill 102 134 317 103 135 317 minecraft:white_concrete
fill 104 134 275 105 135 275 minecraft:red_concrete
fill 104 134 317 104 135 317 minecraft:red_concrete
fill 106 134 275 107 135 275 minecraft:white_concrete
fill 106 134 317 107 135 317 minecraft:white_concrete
fill 108 134 275 108 135 275 minecraft:red_concrete
fill 108 134 317 109 135 317 minecraft:red_concrete
fill 110 134 275 111 135 275 minecraft:white_concrete
fill 110 134 317 111 135 317 minecraft:white_concrete
fill 112 134 275 113 135 275 minecraft:red_concrete
fill 112 134 317 112 135 317 minecraft:red_concrete
fill 114 134 275 115 135 275 minecraft:white_concrete
fill 114 134 317 115 135 317 minecraft:white_concrete
fill 116 134 275 116 135 275 minecraft:red_concrete
fill 116 134 317 117 135 317 minecraft:red_concrete
fill 118 134 275 119 135 275 minecraft:white_concrete
fill 118 134 317 119 135 317 minecraft:white_concrete
fill 120 134 275 121 135 275 minecraft:red_concrete
fill 120 134 317 120 135 317 minecraft:red_concrete
fill 122 134 275 123 135 275 minecraft:white_concrete
fill 122 134 317 123 135 317 minecraft:white_concrete
fill 124 134 275 124 135 275 minecraft:red_concrete
fill 124 134 317 125 135 317 minecraft:red_concrete
fill 126 134 275 127 135 275 minecraft:white_concrete
fill 126 134 317 127 135 317 minecraft:white_concrete
fill 128 134 275 129 135 275 minecraft:red_concrete
fill 128 134 317 128 135 317 minecraft:red_concrete
fill 130 134 275 131 135 275 minecraft:white_concrete
fill 130 134 317 131 135 317 minecraft:white_concrete
fill 132 134 275 132 135 275 minecraft:red_concrete
fill 132 134 317 133 135 317 minecraft:red_concrete
fill 134 134 275 135 135 275 minecraft:white_concrete
fill 134 134 317 135 135 317 minecraft:white_concrete
fill 136 134 276 136 135 276 minecraft:white_concrete
fill 136 134 277 136 135 278 minecraft:red_concrete
fill 136 134 279 136 135 279 minecraft:white_concrete
fill 136 134 281 136 135 282 minecraft:red_concrete
fill 136 134 283 136 135 284 minecraft:white_concrete
fill 136 134 285 136 135 286 minecraft:red_concrete
fill 136 134 287 136 135 287 minecraft:white_concrete
fill 136 134 289 136 135 290 minecraft:red_concrete
fill 136 134 291 136 135 292 minecraft:white_concrete
fill 136 134 293 136 135 294 minecraft:red_concrete
fill 136 134 295 136 135 295 minecraft:white_concrete
fill 136 134 297 136 135 298 minecraft:red_concrete
fill 136 134 299 136 135 300 minecraft:white_concrete
fill 136 134 301 136 135 302 minecraft:red_concrete
fill 136 134 303 136 135 303 minecraft:white_concrete
fill 136 134 305 136 135 306 minecraft:red_concrete
fill 136 134 307 136 135 308 minecraft:white_concrete
fill 136 134 309 136 135 310 minecraft:red_concrete
fill 136 134 311 136 135 311 minecraft:white_concrete
fill 136 134 313 136 135 314 minecraft:red_concrete
fill 136 134 315 136 135 316 minecraft:white_concrete
fill 136 134 317 136 135 317 minecraft:red_concrete
setblock 97 135 278 minecraft:light[level=12]
setblock 97 135 285 minecraft:light[level=12]
setblock 97 135 292 minecraft:light[level=12]
setblock 97 135 299 minecraft:light[level=12]
setblock 97 135 306 minecraft:light[level=12]
setblock 97 135 313 minecraft:light[level=12]
setblock 104 135 278 minecraft:light[level=12]
setblock 104 135 285 minecraft:light[level=12]
setblock 104 135 292 minecraft:light[level=12]
setblock 104 135 299 minecraft:light[level=12]
setblock 104 135 306 minecraft:light[level=12]
setblock 104 135 313 minecraft:light[level=12]
setblock 111 135 285 minecraft:light[level=12]
setblock 111 135 292 minecraft:light[level=12]
setblock 111 135 299 minecraft:light[level=12]
setblock 111 135 306 minecraft:light[level=12]
setblock 111 135 313 minecraft:light[level=12]
setblock 118 135 278 minecraft:light[level=12]
setblock 118 135 285 minecraft:light[level=12]
setblock 118 135 292 minecraft:light[level=12]
setblock 118 135 299 minecraft:light[level=12]
setblock 118 135 306 minecraft:light[level=12]
setblock 118 135 313 minecraft:light[level=12]
setblock 125 135 278 minecraft:light[level=12]
setblock 125 135 285 minecraft:light[level=12]
setblock 125 135 292 minecraft:light[level=12]
setblock 125 135 299 minecraft:light[level=12]
setblock 125 135 306 minecraft:light[level=12]
setblock 125 135 313 minecraft:light[level=12]
setblock 132 135 278 minecraft:light[level=12]
setblock 132 135 292 minecraft:light[level=12]
setblock 132 135 299 minecraft:light[level=12]
setblock 132 135 306 minecraft:light[level=12]
setblock 132 135 313 minecraft:light[level=12]
fill 94 136 275 94 137 276 minecraft:red_concrete
fill 94 136 277 94 137 278 minecraft:white_concrete
fill 94 136 279 94 137 280 minecraft:red_concrete
fill 94 136 281 94 137 282 minecraft:white_concrete
fill 94 136 283 94 137 284 minecraft:red_concrete
fill 94 136 285 94 137 286 minecraft:white_concrete
fill 94 136 287 94 137 288 minecraft:red_concrete
fill 94 136 289 94 137 290 minecraft:white_concrete
fill 94 136 291 94 137 292 minecraft:red_concrete
fill 94 136 293 94 137 294 minecraft:white_concrete
fill 94 136 295 94 137 296 minecraft:red_concrete
fill 94 136 297 94 137 298 minecraft:white_concrete
fill 94 136 299 94 137 300 minecraft:red_concrete
fill 94 136 301 94 137 302 minecraft:white_concrete
fill 94 136 303 94 137 304 minecraft:red_concrete
fill 94 136 305 94 137 306 minecraft:white_concrete
fill 94 136 307 94 137 308 minecraft:red_concrete
fill 94 136 309 94 137 310 minecraft:white_concrete
fill 94 136 311 94 137 312 minecraft:red_concrete
fill 94 136 313 94 137 314 minecraft:white_concrete
fill 94 136 315 94 137 316 minecraft:red_concrete
fill 95 136 275 95 137 275 minecraft:red_concrete
fill 95 136 317 95 137 317 minecraft:red_concrete
fill 96 136 275 97 137 275 minecraft:white_concrete
fill 96 136 317 97 137 317 minecraft:white_concrete
fill 98 136 275 99 137 275 minecraft:red_concrete
fill 98 136 317 99 137 317 minecraft:red_concrete
fill 100 136 275 101 137 275 minecraft:white_concrete
fill 100 136 317 101 137 317 minecraft:white_concrete
fill 102 136 275 103 137 275 minecraft:red_concrete
fill 102 136 317 103 137 317 minecraft:red_concrete
fill 104 136 275 105 137 275 minecraft:white_concrete
fill 104 136 317 105 137 317 minecraft:white_concrete
fill 106 136 275 107 137 275 minecraft:red_concrete
fill 106 136 317 107 137 317 minecraft:red_concrete
fill 108 136 275 109 137 275 minecraft:white_concrete
fill 108 136 317 109 137 317 minecraft:white_concrete
fill 110 136 275 111 137 275 minecraft:red_concrete
fill 110 136 317 111 137 317 minecraft:red_concrete
fill 112 136 275 113 137 275 minecraft:white_concrete
fill 112 136 317 113 137 317 minecraft:white_concrete
fill 114 136 275 115 137 275 minecraft:red_concrete
fill 114 136 317 115 137 317 minecraft:red_concrete
fill 116 136 275 117 137 275 minecraft:white_concrete
fill 116 136 317 117 137 317 minecraft:white_concrete
fill 118 136 275 119 137 275 minecraft:red_concrete
fill 118 136 317 119 137 317 minecraft:red_concrete
fill 120 136 275 121 137 275 minecraft:white_concrete
fill 120 136 317 121 137 317 minecraft:white_concrete
fill 122 136 275 123 137 275 minecraft:red_concrete
fill 122 136 317 123 137 317 minecraft:red_concrete
fill 124 136 275 125 137 275 minecraft:white_concrete
fill 124 136 317 125 137 317 minecraft:white_concrete
fill 126 136 275 127 137 275 minecraft:red_concrete
fill 126 136 317 127 137 317 minecraft:red_concrete
fill 128 136 275 129 137 275 minecraft:white_concrete
fill 128 136 317 129 137 317 minecraft:white_concrete
fill 130 136 275 131 137 275 minecraft:red_concrete
fill 130 136 317 131 137 317 minecraft:red_concrete
fill 132 136 275 133 137 275 minecraft:white_concrete
fill 132 136 317 133 137 317 minecraft:white_concrete
fill 134 136 275 135 137 275 minecraft:red_concrete
fill 134 136 317 135 137 317 minecraft:red_concrete
fill 136 136 276 136 137 276 minecraft:red_concrete
fill 136 136 277 136 137 278 minecraft:white_concrete
fill 136 136 279 136 137 280 minecraft:red_concrete
fill 136 136 281 136 137 282 minecraft:white_concrete
fill 136 136 283 136 137 284 minecraft:red_concrete
fill 136 136 285 136 137 286 minecraft:white_concrete
fill 136 136 287 136 137 288 minecraft:red_concrete
fill 136 136 289 136 137 290 minecraft:white_concrete
fill 136 136 291 136 137 292 minecraft:red_concrete
fill 136 136 293 136 137 294 minecraft:white_concrete
fill 136 136 295 136 137 296 minecraft:red_concrete
fill 136 136 297 136 137 298 minecraft:white_concrete
fill 136 136 299 136 137 300 minecraft:red_concrete
fill 136 136 301 136 137 302 minecraft:white_concrete
fill 136 136 303 136 137 304 minecraft:red_concrete
fill 136 136 305 136 137 306 minecraft:white_concrete
fill 136 136 307 136 137 308 minecraft:red_concrete
fill 136 136 309 136 137 310 minecraft:white_concrete
fill 136 136 311 136 137 312 minecraft:red_concrete
fill 136 136 313 136 137 314 minecraft:white_concrete
fill 136 136 315 136 137 316 minecraft:red_concrete
fill 136 136 317 136 137 317 minecraft:white_concrete
setblock 97 137 310 minecraft:brown_terracotta
setblock 97 137 313 minecraft:brown_terracotta
fill 98 137 314 99 137 314 minecraft:brown_terracotta
setblock 99 137 309 minecraft:brown_terracotta
setblock 100 137 310 minecraft:brown_terracotta
setblock 100 137 313 minecraft:brown_terracotta
fill 101 137 311 101 137 312 minecraft:brown_terracotta
fill 94 138 275 94 139 276 minecraft:white_concrete
fill 94 138 277 94 139 278 minecraft:red_concrete
fill 94 138 279 94 139 280 minecraft:white_concrete
fill 94 138 281 94 139 282 minecraft:red_concrete
fill 94 138 283 94 139 284 minecraft:white_concrete
fill 94 138 285 94 139 286 minecraft:red_concrete
fill 94 138 287 94 139 288 minecraft:white_concrete
fill 94 138 289 94 139 290 minecraft:red_concrete
fill 94 138 291 94 139 292 minecraft:white_concrete
fill 94 138 293 94 139 294 minecraft:red_concrete
fill 94 138 295 94 139 296 minecraft:white_concrete
fill 94 138 297 94 139 298 minecraft:red_concrete
fill 94 138 299 94 139 300 minecraft:white_concrete
fill 94 138 301 94 139 302 minecraft:red_concrete
fill 94 138 303 94 139 304 minecraft:white_concrete
fill 94 138 305 94 139 306 minecraft:red_concrete
fill 94 138 307 94 139 308 minecraft:white_concrete
fill 94 138 309 94 139 310 minecraft:red_concrete
fill 94 138 311 94 139 312 minecraft:white_concrete
fill 94 138 313 94 139 314 minecraft:red_concrete
fill 94 138 315 94 139 316 minecraft:white_concrete
fill 95 138 275 95 139 275 minecraft:white_concrete
fill 95 138 317 95 139 317 minecraft:white_concrete
fill 96 138 275 97 139 275 minecraft:red_concrete
fill 96 138 317 97 139 317 minecraft:red_concrete
fill 98 138 275 99 139 275 minecraft:white_concrete
fill 98 138 317 99 139 317 minecraft:white_concrete
fill 100 138 275 101 139 275 minecraft:red_concrete
fill 100 138 317 101 139 317 minecraft:red_concrete
fill 102 138 275 103 139 275 minecraft:white_concrete
fill 102 138 317 103 139 317 minecraft:white_concrete
fill 104 138 275 105 139 275 minecraft:red_concrete
fill 104 138 317 105 139 317 minecraft:red_concrete
fill 106 138 275 107 139 275 minecraft:white_concrete
fill 106 138 317 107 139 317 minecraft:white_concrete
fill 108 138 275 109 139 275 minecraft:red_concrete
fill 108 138 317 109 139 317 minecraft:red_concrete
fill 110 138 275 111 139 275 minecraft:white_concrete
fill 110 138 317 111 139 317 minecraft:white_concrete
fill 112 138 275 113 139 275 minecraft:red_concrete
fill 112 138 317 113 139 317 minecraft:red_concrete
fill 114 138 275 115 139 275 minecraft:white_concrete
fill 114 138 317 115 139 317 minecraft:white_concrete
fill 116 138 275 117 139 275 minecraft:red_concrete
fill 116 138 317 117 139 317 minecraft:red_concrete
fill 118 138 275 119 139 275 minecraft:white_concrete
fill 118 138 279 118 141 279 minecraft:iron_block
fill 118 138 317 119 139 317 minecraft:white_concrete
fill 120 138 275 121 139 275 minecraft:red_concrete
fill 120 138 317 121 139 317 minecraft:red_concrete
fill 122 138 275 123 139 275 minecraft:white_concrete
fill 122 138 317 123 139 317 minecraft:white_concrete
fill 124 138 275 125 139 275 minecraft:red_concrete
fill 124 138 317 125 139 317 minecraft:red_concrete
fill 126 138 275 127 139 275 minecraft:white_concrete
fill 126 138 317 127 139 317 minecraft:white_concrete
fill 128 138 275 129 139 275 minecraft:red_concrete
fill 128 138 317 129 139 317 minecraft:red_concrete
fill 130 138 275 131 139 275 minecraft:white_concrete
fill 130 138 317 131 139 317 minecraft:white_concrete
fill 132 138 275 133 139 275 minecraft:red_concrete
fill 132 138 317 133 139 317 minecraft:red_concrete
fill 134 138 275 135 139 275 minecraft:white_concrete
fill 134 138 317 135 139 317 minecraft:white_concrete
fill 136 138 276 136 139 276 minecraft:white_concrete
fill 136 138 277 136 139 278 minecraft:red_concrete
fill 136 138 279 136 139 280 minecraft:white_concrete
fill 136 138 281 136 139 282 minecraft:red_concrete
fill 136 138 283 136 139 284 minecraft:white_concrete
fill 136 138 285 136 139 286 minecraft:red_concrete
fill 136 138 287 136 139 288 minecraft:white_concrete
fill 136 138 289 136 139 290 minecraft:red_concrete
fill 136 138 291 136 139 292 minecraft:white_concrete
fill 136 138 293 136 139 294 minecraft:red_concrete
fill 136 138 295 136 139 296 minecraft:white_concrete
fill 136 138 297 136 139 298 minecraft:red_concrete
fill 136 138 299 136 139 300 minecraft:white_concrete
fill 136 138 301 136 139 302 minecraft:red_concrete
fill 136 138 303 136 139 304 minecraft:white_concrete
fill 136 138 305 136 139 306 minecraft:red_concrete
fill 136 138 307 136 139 308 minecraft:white_concrete
fill 136 138 309 136 139 310 minecraft:red_concrete
fill 136 138 311 136 139 312 minecraft:white_concrete
fill 136 138 313 136 139 314 minecraft:red_concrete
fill 136 138 315 136 139 316 minecraft:white_concrete
fill 136 138 317 136 139 317 minecraft:red_concrete
fill 129 139 283 129 139 285 minecraft:red_terracotta
fill 130 139 282 132 139 282 minecraft:red_terracotta
fill 130 139 286 132 139 286 minecraft:red_terracotta
fill 133 139 283 133 139 285 minecraft:red_terracotta
fill 94 140 275 94 141 276 minecraft:red_concrete
fill 94 140 277 94 141 278 minecraft:white_concrete
fill 94 140 279 94 141 280 minecraft:red_concrete
fill 94 140 281 94 141 282 minecraft:white_concrete
fill 94 140 283 94 141 284 minecraft:red_concrete
fill 94 140 285 94 141 286 minecraft:white_concrete
fill 94 140 287 94 141 288 minecraft:red_concrete
fill 94 140 289 94 141 290 minecraft:white_concrete
fill 94 140 291 94 141 292 minecraft:red_concrete
fill 94 140 293 94 141 294 minecraft:white_concrete
fill 94 140 295 94 141 296 minecraft:red_concrete
fill 94 140 297 94 141 298 minecraft:white_concrete
fill 94 140 299 94 141 300 minecraft:red_concrete
fill 94 140 301 94 141 302 minecraft:white_concrete
fill 94 140 303 94 141 304 minecraft:red_concrete
fill 94 140 305 94 141 306 minecraft:white_concrete
fill 94 140 307 94 141 308 minecraft:red_concrete
fill 94 140 309 94 141 310 minecraft:white_concrete
fill 94 140 311 94 141 312 minecraft:red_concrete
fill 94 140 313 94 141 314 minecraft:white_concrete
fill 94 140 315 94 141 316 minecraft:red_concrete
fill 95 140 275 95 141 275 minecraft:red_concrete
fill 95 140 276 95 141 281 minecraft:red_terracotta
fill 95 140 284 96 140 289 minecraft:red_terracotta
fill 95 140 292 96 140 297 minecraft:red_terracotta
fill 95 140 300 96 140 305 minecraft:red_terracotta
fill 95 140 308 96 140 313 minecraft:red_terracotta
fill 95 140 316 100 141 316 minecraft:red_terracotta
fill 95 140 317 95 141 317 minecraft:red_concrete
fill 96 140 275 97 141 275 minecraft:white_concrete
fill 96 140 277 96 140 283 minecraft:red_terracotta
fill 96 140 290 96 140 291 minecraft:red_terracotta
fill 96 140 298 96 140 299 minecraft:red_terracotta
fill 96 140 306 96 140 307 minecraft:red_terracotta
fill 96 140 314 96 140 315 minecraft:red_terracotta
fill 96 140 317 97 141 317 minecraft:white_concrete
fill 97 140 277 134 140 277 minecraft:red_terracotta
fill 97 140 315 135 140 315 minecraft:red_terracotta
fill 98 140 275 99 141 275 minecraft:red_concrete
fill 98 140 276 103 141 276 minecraft:red_terracotta
fill 98 140 317 99 141 317 minecraft:red_concrete
fill 100 140 275 101 141 275 minecraft:white_concrete
fill 100 140 317 101 141 317 minecraft:white_concrete
fill 102 140 275 103 141 275 minecraft:red_concrete
fill 102 140 317 103 141 317 minecraft:red_concrete
fill 103 140 316 108 141 316 minecraft:red_terracotta
fill 104 140 275 105 141 275 minecraft:white_concrete
fill 104 140 317 105 141 317 minecraft:white_concrete
fill 106 140 275 107 141 275 minecraft:red_concrete
fill 106 140 276 111 141 276 minecraft:red_terracotta
fill 106 140 317 107 141 317 minecraft:red_concrete
fill 108 140 275 109 141 275 minecraft:white_concrete
fill 108 140 317 109 141 317 minecraft:white_concrete
fill 110 140 275 111 141 275 minecraft:red_concrete
fill 110 140 317 111 141 317 minecraft:red_concrete
fill 111 140 316 116 141 316 minecraft:red_terracotta
fill 112 140 275 113 141 275 minecraft:white_concrete
fill 112 140 317 113 141 317 minecraft:white_concrete
fill 114 140 275 115 141 275 minecraft:red_concrete
fill 114 140 276 119 141 276 minecraft:red_terracotta
fill 114 140 317 115 141 317 minecraft:red_concrete
fill 116 140 275 117 141 275 minecraft:white_concrete
fill 116 140 317 117 141 317 minecraft:white_concrete
fill 118 140 275 119 141 275 minecraft:red_concrete
fill 118 140 317 119 141 317 minecraft:red_concrete
fill 119 140 316 124 141 316 minecraft:red_terracotta
fill 120 140 275 121 141 275 minecraft:white_concrete
fill 120 140 317 121 141 317 minecraft:white_concrete
fill 122 140 275 123 141 275 minecraft:red_concrete
fill 122 140 276 127 141 276 minecraft:red_terracotta
fill 122 140 317 123 141 317 minecraft:red_concrete
fill 124 140 275 125 141 275 minecraft:white_concrete
fill 124 140 317 125 141 317 minecraft:white_concrete
fill 126 140 275 127 141 275 minecraft:red_concrete
fill 126 140 317 127 141 317 minecraft:red_concrete
fill 127 140 316 132 141 316 minecraft:red_terracotta
fill 128 140 275 129 141 275 minecraft:white_concrete
fill 128 140 317 129 141 317 minecraft:white_concrete
fill 130 140 275 131 141 275 minecraft:red_concrete
fill 130 140 276 135 141 276 minecraft:red_terracotta
fill 130 140 317 131 141 317 minecraft:red_concrete
fill 132 140 275 133 141 275 minecraft:white_concrete
fill 132 140 317 133 141 317 minecraft:white_concrete
fill 134 140 275 135 141 275 minecraft:red_concrete
fill 134 140 278 134 140 314 minecraft:red_terracotta
fill 134 140 317 135 141 317 minecraft:red_concrete
fill 135 140 279 135 141 284 minecraft:red_terracotta
fill 135 140 287 135 141 292 minecraft:red_terracotta
fill 135 140 295 135 141 300 minecraft:red_terracotta
fill 135 140 303 135 141 308 minecraft:red_terracotta
fill 135 140 311 135 141 314 minecraft:red_terracotta
fill 135 140 316 135 141 316 minecraft:red_terracotta
fill 136 140 276 136 141 276 minecraft:red_concrete
fill 136 140 277 136 141 278 minecraft:white_concrete
fill 136 140 279 136 141 280 minecraft:red_concrete
fill 136 140 281 136 141 282 minecraft:white_concrete
fill 136 140 283 136 141 284 minecraft:red_concrete
fill 136 140 285 136 141 286 minecraft:white_concrete
fill 136 140 287 136 141 288 minecraft:red_concrete
fill 136 140 289 136 141 290 minecraft:white_concrete
fill 136 140 291 136 141 292 minecraft:red_concrete
fill 136 140 293 136 141 294 minecraft:white_concrete
fill 136 140 295 136 141 296 minecraft:red_concrete
fill 136 140 297 136 141 298 minecraft:white_concrete
fill 136 140 299 136 141 300 minecraft:red_concrete
fill 136 140 301 136 141 302 minecraft:white_concrete
fill 136 140 303 136 141 304 minecraft:red_concrete
fill 136 140 305 136 141 306 minecraft:white_concrete
fill 136 140 307 136 141 308 minecraft:red_concrete
fill 136 140 309 136 141 310 minecraft:white_concrete
fill 136 140 311 136 141 312 minecraft:red_concrete
fill 136 140 313 136 141 314 minecraft:white_concrete
fill 136 140 315 136 141 316 minecraft:red_concrete
fill 136 140 317 136 141 317 minecraft:white_concrete
fill 95 141 284 95 141 289 minecraft:red_terracotta
fill 95 141 292 95 141 297 minecraft:red_terracotta
fill 95 141 300 95 141 305 minecraft:red_terracotta
fill 95 141 308 95 141 313 minecraft:red_terracotta
setblock 97 141 278 minecraft:light[level=15]
setblock 97 141 285 minecraft:light[level=12]
setblock 97 141 286 minecraft:light[level=15]
setblock 97 141 292 minecraft:light[level=12]
setblock 97 141 294 minecraft:light[level=15]
setblock 97 141 299 minecraft:light[level=12]
setblock 97 141 302 minecraft:light[level=15]
setblock 97 141 306 minecraft:light[level=12]
setblock 97 141 310 minecraft:light[level=15]
setblock 97 141 313 minecraft:light[level=12]
setblock 104 141 278 minecraft:light[level=12]
setblock 104 141 285 minecraft:light[level=12]
setblock 104 141 292 minecraft:light[level=12]
setblock 104 141 299 minecraft:light[level=12]
setblock 104 141 306 minecraft:light[level=12]
setblock 104 141 313 minecraft:light[level=12]
setblock 105 141 278 minecraft:light[level=15]
setblock 105 141 286 minecraft:light[level=15]
setblock 105 141 294 minecraft:light[level=15]
setblock 105 141 302 minecraft:light[level=15]
setblock 105 141 310 minecraft:light[level=15]
setblock 111 141 285 minecraft:light[level=12]
setblock 111 141 292 minecraft:light[level=12]
setblock 111 141 299 minecraft:light[level=12]
setblock 111 141 306 minecraft:light[level=12]
setblock 111 141 313 minecraft:light[level=12]
setblock 113 141 286 minecraft:light[level=15]
setblock 113 141 294 minecraft:light[level=15]
setblock 113 141 302 minecraft:light[level=15]
setblock 113 141 310 minecraft:light[level=15]
setblock 118 141 278 minecraft:light[level=12]
setblock 118 141 285 minecraft:light[level=12]
setblock 118 141 292 minecraft:light[level=12]
setblock 118 141 299 minecraft:light[level=12]
setblock 118 141 306 minecraft:light[level=12]
setblock 118 141 313 minecraft:light[level=12]
setblock 121 141 278 minecraft:light[level=15]
setblock 121 141 286 minecraft:light[level=15]
setblock 121 141 294 minecraft:light[level=15]
setblock 121 141 302 minecraft:light[level=15]
setblock 121 141 310 minecraft:light[level=15]
setblock 125 141 278 minecraft:light[level=12]
setblock 125 141 285 minecraft:light[level=12]
setblock 125 141 292 minecraft:light[level=12]
setblock 125 141 299 minecraft:light[level=12]
setblock 125 141 306 minecraft:light[level=12]
setblock 125 141 313 minecraft:light[level=12]
setblock 129 141 278 minecraft:light[level=15]
setblock 129 141 286 minecraft:light[level=15]
setblock 129 141 294 minecraft:light[level=15]
setblock 129 141 302 minecraft:light[level=15]
setblock 129 141 310 minecraft:light[level=15]
setblock 132 141 278 minecraft:light[level=12]
setblock 132 141 292 minecraft:light[level=12]
setblock 132 141 299 minecraft:light[level=12]
setblock 132 141 306 minecraft:light[level=12]
setblock 132 141 313 minecraft:light[level=12]
setblock 135 141 315 minecraft:red_terracotta
fill 94 142 275 94 143 276 minecraft:white_concrete
fill 94 142 277 94 143 278 minecraft:red_concrete
fill 94 142 279 94 143 280 minecraft:white_concrete
fill 94 142 281 94 143 282 minecraft:red_concrete
fill 94 142 283 94 143 284 minecraft:white_concrete
fill 94 142 285 94 143 286 minecraft:red_concrete
fill 94 142 287 94 143 288 minecraft:white_concrete
fill 94 142 289 94 143 290 minecraft:red_concrete
fill 94 142 291 94 143 292 minecraft:white_concrete
fill 94 142 293 94 143 294 minecraft:red_concrete
fill 94 142 295 94 143 296 minecraft:white_concrete
fill 94 142 297 94 143 298 minecraft:red_concrete
fill 94 142 299 94 143 300 minecraft:white_concrete
fill 94 142 301 94 143 302 minecraft:red_concrete
fill 94 142 303 94 143 304 minecraft:white_concrete
fill 94 142 305 94 143 306 minecraft:red_concrete
fill 94 142 307 94 143 308 minecraft:white_concrete
fill 94 142 309 94 143 310 minecraft:red_concrete
fill 94 142 311 94 143 312 minecraft:white_concrete
fill 94 142 313 94 143 314 minecraft:red_concrete
fill 94 142 315 94 143 316 minecraft:white_concrete
fill 95 142 275 95 143 275 minecraft:white_concrete
fill 95 142 317 95 143 317 minecraft:white_concrete
fill 96 142 275 97 143 275 minecraft:red_concrete
fill 96 142 317 97 143 317 minecraft:red_concrete
fill 98 142 275 99 143 275 minecraft:white_concrete
fill 98 142 317 99 143 317 minecraft:white_concrete
fill 100 142 275 101 143 275 minecraft:red_concrete
fill 100 142 317 101 143 317 minecraft:red_concrete
fill 102 142 275 103 143 275 minecraft:white_concrete
fill 102 142 317 103 143 317 minecraft:white_concrete
fill 104 142 275 105 143 275 minecraft:red_concrete
fill 104 142 317 105 143 317 minecraft:red_concrete
fill 106 142 275 107 143 275 minecraft:white_concrete
fill 106 142 317 107 143 317 minecraft:white_concrete
fill 108 142 275 109 143 275 minecraft:red_concrete
fill 108 142 317 109 143 317 minecraft:red_concrete
fill 110 142 275 111 143 275 minecraft:white_concrete
fill 110 142 317 111 143 317 minecraft:white_concrete
fill 112 142 275 113 143 275 minecraft:red_concrete
fill 112 142 317 113 143 317 minecraft:red_concrete
fill 114 142 275 115 143 275 minecraft:white_concrete
fill 114 142 317 115 143 317 minecraft:white_concrete
fill 115 142 276 119 142 279 minecraft:brown_terracotta
fill 116 142 275 117 143 275 minecraft:red_concrete
fill 116 142 317 117 143 317 minecraft:red_concrete
fill 118 142 275 119 143 275 minecraft:white_concrete
fill 118 142 317 119 143 317 minecraft:white_concrete
fill 120 142 275 121 143 275 minecraft:red_concrete
fill 120 142 277 121 142 279 minecraft:brown_terracotta
fill 120 142 317 121 143 317 minecraft:red_concrete
fill 122 142 275 123 143 275 minecraft:white_concrete
fill 122 142 317 123 143 317 minecraft:white_concrete
fill 124 142 275 125 143 275 minecraft:red_concrete
fill 124 142 317 125 143 317 minecraft:red_concrete
fill 126 142 275 127 143 275 minecraft:white_concrete
fill 126 142 317 127 143 317 minecraft:white_concrete
fill 128 142 275 129 143 275 minecraft:red_concrete
fill 128 142 317 129 143 317 minecraft:red_concrete
fill 130 142 275 131 143 275 minecraft:white_concrete
fill 130 142 317 131 143 317 minecraft:white_concrete
fill 132 142 275 133 143 275 minecraft:red_concrete
fill 132 142 317 133 143 317 minecraft:red_concrete
fill 134 142 275 135 143 275 minecraft:white_concrete
fill 134 142 317 135 143 317 minecraft:white_concrete
fill 136 142 276 136 143 276 minecraft:white_concrete
fill 136 142 277 136 143 278 minecraft:red_concrete
fill 136 142 279 136 143 280 minecraft:white_concrete
fill 136 142 281 136 143 282 minecraft:red_concrete
fill 136 142 283 136 143 284 minecraft:white_concrete
fill 136 142 285 136 143 286 minecraft:red_concrete
fill 136 142 287 136 143 288 minecraft:white_concrete
fill 136 142 289 136 143 290 minecraft:red_concrete
fill 136 142 291 136 143 292 minecraft:white_concrete
fill 136 142 293 136 143 294 minecraft:red_concrete
fill 136 142 295 136 143 296 minecraft:white_concrete
fill 136 142 297 136 143 298 minecraft:red_concrete
fill 136 142 299 136 143 300 minecraft:white_concrete
fill 136 142 301 136 143 302 minecraft:red_concrete
fill 136 142 303 136 143 304 minecraft:white_concrete
fill 136 142 305 136 143 306 minecraft:red_concrete
fill 136 142 307 136 143 308 minecraft:white_concrete
fill 136 142 309 136 143 310 minecraft:red_concrete
fill 136 142 311 136 143 312 minecraft:white_concrete
fill 136 142 313 136 143 314 minecraft:red_concrete
fill 136 142 315 136 143 316 minecraft:white_concrete
fill 136 142 317 136 143 317 minecraft:red_concrete
fill 115 143 276 119 143 279 minecraft:red_terracotta
fill 120 143 277 121 143 279 minecraft:red_terracotta
fill 94 144 275 94 145 276 minecraft:red_concrete
fill 94 144 277 94 145 278 minecraft:white_concrete
fill 94 144 279 94 145 279 minecraft:red_concrete
fill 94 144 280 94 149 280 minecraft:shroomlight
fill 94 144 281 94 145 282 minecraft:white_concrete
fill 94 144 283 94 145 284 minecraft:red_concrete
fill 94 144 285 94 145 286 minecraft:white_concrete
fill 94 144 287 94 145 287 minecraft:red_concrete
fill 94 144 288 94 149 288 minecraft:shroomlight
fill 94 144 289 94 145 290 minecraft:white_concrete
fill 94 144 291 94 145 292 minecraft:red_concrete
fill 94 144 293 94 145 294 minecraft:white_concrete
fill 94 144 295 94 145 295 minecraft:red_concrete
fill 94 144 296 94 149 296 minecraft:shroomlight
fill 94 144 297 94 145 298 minecraft:white_concrete
fill 94 144 299 94 145 300 minecraft:red_concrete
fill 94 144 301 94 145 302 minecraft:white_concrete
fill 94 144 303 94 145 303 minecraft:red_concrete
fill 94 144 304 94 149 304 minecraft:shroomlight
fill 94 144 305 94 145 306 minecraft:white_concrete
fill 94 144 307 94 145 308 minecraft:red_concrete
fill 94 144 309 94 145 310 minecraft:white_concrete
fill 94 144 311 94 145 311 minecraft:red_concrete
fill 94 144 312 94 149 312 minecraft:shroomlight
fill 94 144 313 94 145 314 minecraft:white_concrete
fill 94 144 315 94 145 316 minecraft:red_concrete
fill 95 144 275 95 145 275 minecraft:red_concrete
fill 95 144 317 95 145 317 minecraft:red_concrete
fill 96 144 275 97 145 275 minecraft:white_concrete
fill 96 144 317 96 145 317 minecraft:white_concrete
fill 97 144 317 97 149 317 minecraft:shroomlight
fill 98 144 275 99 145 275 minecraft:red_concrete
fill 98 144 317 99 145 317 minecraft:red_concrete
fill 100 144 275 100 145 275 minecraft:white_concrete
fill 100 144 317 101 145 317 minecraft:white_concrete
fill 101 144 275 101 149 275 minecraft:shroomlight
fill 102 144 275 103 145 275 minecraft:red_concrete
fill 102 144 317 103 145 317 minecraft:red_concrete
fill 104 144 275 105 145 275 minecraft:white_concrete
fill 104 144 317 104 145 317 minecraft:white_concrete
fill 105 144 317 105 149 317 minecraft:shroomlight
fill 106 144 275 107 145 275 minecraft:red_concrete
fill 106 144 317 107 145 317 minecraft:red_concrete
fill 108 144 275 108 145 275 minecraft:white_concrete
fill 108 144 317 109 145 317 minecraft:white_concrete
fill 109 144 275 109 149 275 minecraft:shroomlight
fill 110 144 275 111 145 275 minecraft:red_concrete
fill 110 144 317 111 145 317 minecraft:red_concrete
fill 112 144 275 113 145 275 minecraft:white_concrete
fill 112 144 317 112 145 317 minecraft:white_concrete
fill 113 144 317 113 149 317 minecraft:shroomlight
fill 114 144 275 115 145 275 minecraft:red_concrete
fill 114 144 317 115 145 317 minecraft:red_concrete
fill 115 144 279 121 144 279 minecraft:yellow_concrete
fill 116 144 275 116 145 275 minecraft:white_concrete
fill 116 144 317 117 145 317 minecraft:white_concrete
fill 117 144 275 119 147 275 minecraft:shroomlight
fill 118 144 317 119 145 317 minecraft:red_concrete
fill 120 144 275 121 145 275 minecraft:white_concrete
fill 120 144 317 120 145 317 minecraft:white_concrete
fill 121 144 317 121 149 317 minecraft:shroomlight
fill 122 144 275 123 145 275 minecraft:red_concrete
fill 122 144 317 123 145 317 minecraft:red_concrete
fill 124 144 275 124 145 275 minecraft:white_concrete
fill 124 144 317 125 145 317 minecraft:white_concrete
fill 125 144 275 125 149 275 minecraft:shroomlight
fill 126 144 275 127 145 275 minecraft:red_concrete
fill 126 144 317 127 145 317 minecraft:red_concrete
fill 128 144 275 129 145 275 minecraft:white_concrete
fill 128 144 317 128 145 317 minecraft:white_concrete
fill 129 144 317 129 149 317 minecraft:shroomlight
fill 130 144 275 131 145 275 minecraft:red_concrete
fill 130 144 317 131 145 317 minecraft:red_concrete
fill 132 144 275 132 145 275 minecraft:white_concrete
fill 132 144 317 133 145 317 minecraft:white_concrete
fill 133 144 275 133 149 275 minecraft:shroomlight
fill 134 144 275 135 145 275 minecraft:red_concrete
fill 134 144 317 135 145 317 minecraft:red_concrete
fill 136 144 276 136 145 276 minecraft:red_concrete
fill 136 144 277 136 145 278 minecraft:white_concrete
fill 136 144 279 136 145 279 minecraft:red_concrete
fill 136 144 280 136 149 280 minecraft:shroomlight
fill 136 144 281 136 145 282 minecraft:white_concrete
fill 136 144 283 136 145 284 minecraft:red_concrete
fill 136 144 285 136 145 286 minecraft:white_concrete
fill 136 144 287 136 145 287 minecraft:red_concrete
fill 136 144 288 136 149 288 minecraft:shroomlight
fill 136 144 289 136 145 290 minecraft:white_concrete
fill 136 144 291 136 145 292 minecraft:red_concrete
fill 136 144 293 136 145 294 minecraft:white_concrete
fill 136 144 295 136 145 295 minecraft:red_concrete
fill 136 144 296 136 149 296 minecraft:shroomlight
fill 136 144 297 136 145 298 minecraft:white_concrete
fill 136 144 299 136 145 300 minecraft:red_concrete
fill 136 144 301 136 145 302 minecraft:white_concrete
fill 136 144 303 136 145 303 minecraft:red_concrete
fill 136 144 304 136 149 304 minecraft:shroomlight
fill 136 144 305 136 145 306 minecraft:white_concrete
fill 136 144 307 136 145 308 minecraft:red_concrete
fill 136 144 309 136 145 310 minecraft:white_concrete
fill 136 144 311 136 145 311 minecraft:red_concrete
fill 136 144 312 136 149 312 minecraft:shroomlight
fill 136 144 313 136 145 314 minecraft:white_concrete
fill 136 144 315 136 145 316 minecraft:red_concrete
fill 136 144 317 136 145 317 minecraft:white_concrete
setblock 97 145 310 minecraft:brown_terracotta
setblock 97 145 313 minecraft:brown_terracotta
fill 98 145 314 99 145 314 minecraft:brown_terracotta
setblock 99 145 309 minecraft:brown_terracotta
setblock 100 145 310 minecraft:brown_terracotta
setblock 100 145 313 minecraft:brown_terracotta
fill 101 145 311 101 145 312 minecraft:brown_terracotta
setblock 115 145 279 minecraft:red_terracotta
setblock 118 145 279 minecraft:red_terracotta
setblock 121 145 279 minecraft:red_terracotta
fill 94 146 275 94 147 276 minecraft:white_concrete
fill 94 146 277 94 147 278 minecraft:red_concrete
fill 94 146 279 94 147 279 minecraft:white_concrete
fill 94 146 281 94 147 282 minecraft:red_concrete
fill 94 146 283 94 147 284 minecraft:white_concrete
fill 94 146 285 94 147 286 minecraft:red_concrete
fill 94 146 287 94 147 287 minecraft:white_concrete
fill 94 146 289 94 147 290 minecraft:red_concrete
fill 94 146 291 94 147 292 minecraft:white_concrete
fill 94 146 293 94 147 294 minecraft:red_concrete
fill 94 146 295 94 147 295 minecraft:white_concrete
fill 94 146 297 94 147 298 minecraft:red_concrete
fill 94 146 299 94 147 300 minecraft:white_concrete
fill 94 146 301 94 147 302 minecraft:red_concrete
fill 94 146 303 94 147 303 minecraft:white_concrete
fill 94 146 305 94 147 306 minecraft:red_concrete
fill 94 146 307 94 147 308 minecraft:white_concrete
fill 94 146 309 94 147 310 minecraft:red_concrete
fill 94 146 311 94 147 311 minecraft:white_concrete
fill 94 146 313 94 147 314 minecraft:red_concrete
fill 94 146 315 94 147 316 minecraft:white_concrete
fill 95 146 275 95 147 275 minecraft:white_concrete
fill 95 146 317 95 147 317 minecraft:white_concrete
fill 96 146 275 97 147 275 minecraft:red_concrete
fill 96 146 317 96 147 317 minecraft:red_concrete
fill 98 146 275 99 147 275 minecraft:white_concrete
fill 98 146 317 99 147 317 minecraft:white_concrete
fill 100 146 275 100 147 275 minecraft:red_concrete
fill 100 146 317 101 147 317 minecraft:red_concrete
fill 102 146 275 103 147 275 minecraft:white_concrete
fill 102 146 317 103 147 317 minecraft:white_concrete
fill 104 146 275 105 147 275 minecraft:red_concrete
fill 104 146 317 104 147 317 minecraft:red_concrete
fill 106 146 275 107 147 275 minecraft:white_concrete
fill 106 146 317 107 147 317 minecraft:white_concrete
fill 108 146 275 108 147 275 minecraft:red_concrete
fill 108 146 317 109 147 317 minecraft:red_concrete
fill 110 146 275 111 147 275 minecraft:white_concrete
fill 110 146 317 111 147 317 minecraft:white_concrete
fill 112 146 275 113 147 275 minecraft:red_concrete
fill 112 146 317 112 147 317 minecraft:red_concrete
fill 114 146 275 115 147 275 minecraft:white_concrete
fill 114 146 317 115 147 317 minecraft:white_concrete
fill 116 146 275 116 147 275 minecraft:red_concrete
fill 116 146 317 117 147 317 minecraft:red_concrete
fill 118 146 317 119 147 317 minecraft:white_concrete
fill 120 146 275 121 147 275 minecraft:red_concrete
fill 120 146 317 120 147 317 minecraft:red_concrete
fill 122 146 275 123 147 275 minecraft:white_concrete
fill 122 146 317 123 147 317 minecraft:white_concrete
fill 124 146 275 124 147 275 minecraft:red_concrete
fill 124 146 317 125 147 317 minecraft:red_concrete
fill 126 146 275 127 147 275 minecraft:white_concrete
fill 126 146 317 127 147 317 minecraft:white_concrete
fill 128 146 275 129 147 275 minecraft:red_concrete
fill 128 146 317 128 147 317 minecraft:red_concrete
fill 130 146 275 131 147 275 minecraft:white_concrete
fill 130 146 317 131 147 317 minecraft:white_concrete
fill 132 146 275 132 147 275 minecraft:red_concrete
fill 132 146 317 133 147 317 minecraft:red_concrete
fill 134 146 275 135 147 275 minecraft:white_concrete
fill 134 146 317 135 147 317 minecraft:white_concrete
fill 136 146 276 136 147 276 minecraft:white_concrete
fill 136 146 277 136 147 278 minecraft:red_concrete
fill 136 146 279 136 147 279 minecraft:white_concrete
fill 136 146 281 136 147 282 minecraft:red_concrete
fill 136 146 283 136 147 284 minecraft:white_concrete
fill 136 146 285 136 147 286 minecraft:red_concrete
fill 136 146 287 136 147 287 minecraft:white_concrete
fill 136 146 289 136 147 290 minecraft:red_concrete
fill 136 146 291 136 147 292 minecraft:white_concrete
fill 136 146 293 136 147 294 minecraft:red_concrete
fill 136 146 295 136 147 295 minecraft:white_concrete
fill 136 146 297 136 147 298 minecraft:red_concrete
fill 136 146 299 136 147 300 minecraft:white_concrete
fill 136 146 301 136 147 302 minecraft:red_concrete
fill 136 146 303 136 147 303 minecraft:white_concrete
fill 136 146 305 136 147 306 minecraft:red_concrete
fill 136 146 307 136 147 308 minecraft:white_concrete
fill 136 146 309 136 147 310 minecraft:red_concrete
fill 136 146 311 136 147 311 minecraft:white_concrete
fill 136 146 313 136 147 314 minecraft:red_concrete
fill 136 146 315 136 147 316 minecraft:white_concrete
fill 136 146 317 136 147 317 minecraft:red_concrete
setblock 97 147 278 minecraft:light[level=12]
setblock 97 147 285 minecraft:light[level=12]
setblock 97 147 292 minecraft:light[level=12]
setblock 97 147 299 minecraft:light[level=12]
setblock 97 147 306 minecraft:light[level=12]
setblock 97 147 313 minecraft:light[level=12]
setblock 104 147 278 minecraft:light[level=12]
setblock 104 147 285 minecraft:light[level=12]
setblock 104 147 292 minecraft:light[level=12]
setblock 104 147 299 minecraft:light[level=12]
setblock 104 147 306 minecraft:light[level=12]
setblock 104 147 313 minecraft:light[level=12]
setblock 111 147 285 minecraft:light[level=12]
setblock 111 147 292 minecraft:light[level=12]
setblock 111 147 299 minecraft:light[level=12]
setblock 111 147 306 minecraft:light[level=12]
setblock 111 147 313 minecraft:light[level=12]
setblock 118 147 278 minecraft:light[level=12]
setblock 118 147 285 minecraft:light[level=12]
setblock 118 147 292 minecraft:light[level=12]
setblock 118 147 299 minecraft:light[level=12]
setblock 118 147 306 minecraft:light[level=12]
setblock 118 147 313 minecraft:light[level=12]
fill 120 147 285 121 148 285 minecraft:red_concrete
setblock 125 147 278 minecraft:light[level=12]
setblock 125 147 285 minecraft:light[level=12]
setblock 125 147 292 minecraft:light[level=12]
setblock 125 147 299 minecraft:light[level=12]
setblock 125 147 306 minecraft:light[level=12]
setblock 125 147 313 minecraft:light[level=12]
fill 129 147 283 129 147 285 minecraft:red_terracotta
fill 130 147 282 132 147 282 minecraft:red_terracotta
fill 130 147 286 132 147 286 minecraft:red_terracotta
setblock 132 147 278 minecraft:light[level=12]
setblock 132 147 292 minecraft:light[level=12]
setblock 132 147 299 minecraft:light[level=12]
setblock 132 147 306 minecraft:light[level=12]
setblock 132 147 313 minecraft:light[level=12]
fill 133 147 283 133 147 285 minecraft:red_terracotta
fill 94 148 275 94 149 276 minecraft:red_concrete
fill 94 148 277 94 149 278 minecraft:white_concrete
fill 94 148 279 94 149 279 minecraft:red_concrete
fill 94 148 281 94 149 282 minecraft:white_concrete
fill 94 148 283 94 149 284 minecraft:red_concrete
fill 94 148 285 94 149 286 minecraft:white_concrete
fill 94 148 287 94 149 287 minecraft:red_concrete
fill 94 148 289 94 149 290 minecraft:white_concrete
fill 94 148 291 94 149 292 minecraft:red_concrete
fill 94 148 293 94 149 294 minecraft:white_concrete
fill 94 148 295 94 149 295 minecraft:red_concrete
fill 94 148 297 94 149 298 minecraft:white_concrete
fill 94 148 299 94 149 300 minecraft:red_concrete
fill 94 148 301 94 149 302 minecraft:white_concrete
fill 94 148 303 94 149 303 minecraft:red_concrete
fill 94 148 305 94 149 306 minecraft:white_concrete
fill 94 148 307 94 149 308 minecraft:red_concrete
fill 94 148 309 94 149 310 minecraft:white_concrete
fill 94 148 311 94 149 311 minecraft:red_concrete
fill 94 148 313 94 149 314 minecraft:white_concrete
fill 94 148 315 94 149 316 minecraft:red_concrete
fill 95 148 275 95 149 275 minecraft:red_concrete
fill 95 148 317 95 149 317 minecraft:red_concrete
fill 96 148 275 97 149 275 minecraft:white_concrete
fill 96 148 317 96 149 317 minecraft:white_concrete
fill 98 148 275 99 149 275 minecraft:red_concrete
fill 98 148 317 99 149 317 minecraft:red_concrete
fill 100 148 275 100 149 275 minecraft:white_concrete
fill 100 148 317 101 149 317 minecraft:white_concrete
fill 102 148 275 103 149 275 minecraft:red_concrete
fill 102 148 317 103 149 317 minecraft:red_concrete
fill 104 148 275 105 149 275 minecraft:white_concrete
fill 104 148 317 104 149 317 minecraft:white_concrete
fill 106 148 275 107 149 275 minecraft:red_concrete
fill 106 148 317 107 149 317 minecraft:red_concrete
fill 108 148 275 108 149 275 minecraft:white_concrete
fill 108 148 317 109 149 317 minecraft:white_concrete
fill 110 148 275 111 149 275 minecraft:red_concrete
fill 110 148 317 111 149 317 minecraft:red_concrete
fill 112 148 275 113 149 275 minecraft:white_concrete
fill 112 148 317 112 149 317 minecraft:white_concrete
fill 114 148 275 115 149 275 minecraft:red_concrete
fill 114 148 317 115 149 317 minecraft:red_concrete
fill 116 148 275 116 149 275 minecraft:white_concrete
fill 116 148 317 117 149 317 minecraft:white_concrete
fill 117 148 275 117 149 275 minecraft:shroomlight
fill 117 148 280 117 164 280 minecraft:yellow_concrete
fill 118 148 275 119 149 275 minecraft:red_concrete
fill 118 148 317 119 149 317 minecraft:red_concrete
fill 120 148 275 121 149 275 minecraft:white_concrete
fill 120 148 317 120 149 317 minecraft:white_concrete
fill 122 148 275 123 149 275 minecraft:red_concrete
fill 122 148 317 123 149 317 minecraft:red_concrete
fill 124 148 275 124 149 275 minecraft:white_concrete
fill 124 148 317 125 149 317 minecraft:white_concrete
fill 126 148 275 127 149 275 minecraft:red_concrete
fill 126 148 317 127 149 317 minecraft:red_concrete
fill 128 148 275 129 149 275 minecraft:white_concrete
fill 128 148 317 128 149 317 minecraft:white_concrete
fill 130 148 275 131 149 275 minecraft:red_concrete
fill 130 148 317 131 149 317 minecraft:red_concrete
fill 132 148 275 132 149 275 minecraft:white_concrete
fill 132 148 317 133 149 317 minecraft:white_concrete
fill 134 148 275 135 149 275 minecraft:red_concrete
fill 134 148 317 135 149 317 minecraft:red_concrete
fill 136 148 276 136 149 276 minecraft:red_concrete
fill 136 148 277 136 149 278 minecraft:white_concrete
fill 136 148 279 136 149 279 minecraft:red_concrete
fill 136 148 281 136 149 282 minecraft:white_concrete
fill 136 148 283 136 149 284 minecraft:red_concrete
fill 136 148 285 136 149 286 minecraft:white_concrete
fill 136 148 287 136 149 287 minecraft:red_concrete
fill 136 148 289 136 149 290 minecraft:white_concrete
fill 136 148 291 136 149 292 minecraft:red_concrete
fill 136 148 293 136 149 294 minecraft:white_concrete
fill 136 148 295 136 149 295 minecraft:red_concrete
fill 136 148 297 136 149 298 minecraft:white_concrete
fill 136 148 299 136 149 300 minecraft:red_concrete
fill 136 148 301 136 149 302 minecraft:white_concrete
fill 136 148 303 136 149 303 minecraft:red_concrete
fill 136 148 305 136 149 306 minecraft:white_concrete
fill 136 148 307 136 149 308 minecraft:red_concrete
fill 136 148 309 136 149 310 minecraft:white_concrete
fill 136 148 311 136 149 311 minecraft:red_concrete
fill 136 148 313 136 149 314 minecraft:white_concrete
fill 136 148 315 136 149 316 minecraft:red_concrete
fill 136 148 317 136 149 317 minecraft:white_concrete
setblock 97 149 278 minecraft:light[level=15]
setblock 97 149 286 minecraft:light[level=15]
setblock 97 149 294 minecraft:light[level=15]
setblock 97 149 302 minecraft:light[level=15]
setblock 97 149 310 minecraft:light[level=15]
setblock 105 149 278 minecraft:light[level=15]
setblock 105 149 286 minecraft:light[level=15]
setblock 105 149 294 minecraft:light[level=15]
setblock 105 149 302 minecraft:light[level=15]
setblock 105 149 310 minecraft:light[level=15]
setblock 113 149 286 minecraft:light[level=15]
setblock 113 149 294 minecraft:light[level=15]
setblock 113 149 302 minecraft:light[level=15]
setblock 113 149 310 minecraft:light[level=15]
fill 114 149 278 120 163 278 minecraft:yellow_concrete
fill 114 149 281 120 163 282 minecraft:yellow_concrete
fill 115 149 277 119 153 277 minecraft:yellow_concrete
fill 115 149 279 116 163 280 minecraft:yellow_concrete
fill 115 149 283 119 163 283 minecraft:yellow_concrete
fill 117 149 279 120 163 279 minecraft:yellow_concrete
fill 118 149 280 120 163 280 minecraft:yellow_concrete
setblock 121 149 278 minecraft:light[level=15]
setblock 121 149 286 minecraft:light[level=15]
setblock 121 149 294 minecraft:light[level=15]
setblock 121 149 302 minecraft:light[level=15]
setblock 121 149 310 minecraft:light[level=15]
setblock 129 149 278 minecraft:light[level=15]
setblock 129 149 286 minecraft:light[level=15]
setblock 129 149 294 minecraft:light[level=15]
setblock 129 149 302 minecraft:light[level=15]
setblock 129 149 310 minecraft:light[level=15]
fill 94 150 275 94 151 276 minecraft:white_concrete
fill 94 150 277 94 151 278 minecraft:red_concrete
fill 94 150 279 94 151 280 minecraft:white_concrete
fill 94 150 281 94 151 282 minecraft:red_concrete
fill 94 150 283 94 151 284 minecraft:white_concrete
fill 94 150 285 94 151 286 minecraft:red_concrete
fill 94 150 287 94 151 288 minecraft:white_concrete
fill 94 150 289 94 151 290 minecraft:red_concrete
fill 94 150 291 94 151 292 minecraft:white_concrete
fill 94 150 293 94 151 294 minecraft:red_concrete
fill 94 150 295 94 151 296 minecraft:white_concrete
fill 94 150 297 94 151 298 minecraft:red_concrete
fill 94 150 299 94 151 300 minecraft:white_concrete
fill 94 150 301 94 151 302 minecraft:red_concrete
fill 94 150 303 94 151 304 minecraft:white_concrete
fill 94 150 305 94 151 306 minecraft:red_concrete
fill 94 150 307 94 151 308 minecraft:white_concrete
fill 94 150 309 94 151 310 minecraft:red_concrete
fill 94 150 311 94 151 312 minecraft:white_concrete
fill 94 150 313 94 151 314 minecraft:red_concrete
fill 94 150 315 94 151 316 minecraft:white_concrete
fill 95 150 275 95 151 275 minecraft:white_concrete
fill 95 150 317 95 151 317 minecraft:white_concrete
fill 96 150 275 97 151 275 minecraft:red_concrete
fill 96 150 317 97 151 317 minecraft:red_concrete
fill 98 150 275 99 151 275 minecraft:white_concrete
fill 98 150 317 99 151 317 minecraft:white_concrete
fill 100 150 275 101 151 275 minecraft:red_concrete
fill 100 150 317 101 151 317 minecraft:red_concrete
fill 102 150 275 103 151 275 minecraft:white_concrete
fill 102 150 317 103 151 317 minecraft:white_concrete
fill 104 150 275 105 151 275 minecraft:red_concrete
fill 104 150 317 105 151 317 minecraft:red_concrete
fill 106 150 275 107 151 275 minecraft:white_concrete
fill 106 150 317 107 151 317 minecraft:white_concrete
fill 108 150 275 109 151 275 minecraft:red_concrete
fill 108 150 317 109 151 317 minecraft:red_concrete
fill 110 150 275 111 151 275 minecraft:white_concrete
fill 110 150 317 111 151 317 minecraft:white_concrete
fill 112 150 275 113 151 275 minecraft:red_concrete
fill 112 150 317 113 151 317 minecraft:red_concrete
fill 113 150 277 114 153 277 minecraft:yellow_concrete
fill 113 150 282 113 162 283 minecraft:yellow_concrete
fill 114 150 275 115 151 275 minecraft:white_concrete
fill 114 150 276 119 153 276 minecraft:yellow_concrete
fill 114 150 283 114 162 284 minecraft:yellow_concrete
fill 114 150 317 115 151 317 minecraft:white_concrete
fill 115 150 284 120 162 284 minecraft:yellow_concrete
fill 116 150 275 117 151 275 minecraft:red_concrete
fill 116 150 285 118 162 285 minecraft:yellow_concrete
fill 116 150 317 117 151 317 minecraft:red_concrete
fill 118 150 275 119 151 275 minecraft:white_concrete
fill 118 150 317 119 151 317 minecraft:white_concrete
fill 120 150 275 121 151 275 minecraft:red_concrete
fill 120 150 277 121 153 277 minecraft:yellow_concrete
fill 120 150 283 121 162 283 minecraft:yellow_concrete
fill 120 150 317 121 151 317 minecraft:red_concrete
fill 121 150 278 121 162 282 minecraft:yellow_concrete
fill 122 150 275 123 151 275 minecraft:white_concrete
fill 122 150 279 122 162 281 minecraft:yellow_concrete
fill 122 150 317 123 151 317 minecraft:white_concrete
fill 124 150 275 125 151 275 minecraft:red_concrete
fill 124 150 317 125 151 317 minecraft:red_concrete
fill 126 150 275 127 151 275 minecraft:white_concrete
fill 126 150 317 127 151 317 minecraft:white_concrete
fill 128 150 275 129 151 275 minecraft:red_concrete
fill 128 150 317 129 151 317 minecraft:red_concrete
fill 130 150 275 131 151 275 minecraft:white_concrete
fill 130 150 317 131 151 317 minecraft:white_concrete
fill 132 150 275 133 151 275 minecraft:red_concrete
fill 132 150 317 133 151 317 minecraft:red_concrete
fill 134 150 275 135 151 275 minecraft:white_concrete
fill 134 150 317 135 151 317 minecraft:white_concrete
fill 136 150 276 136 151 276 minecraft:white_concrete
fill 136 150 277 136 151 278 minecraft:red_concrete
fill 136 150 279 136 151 280 minecraft:white_concrete
fill 136 150 281 136 151 282 minecraft:red_concrete
fill 136 150 283 136 151 284 minecraft:white_concrete
fill 136 150 285 136 151 286 minecraft:red_concrete
fill 136 150 287 136 151 288 minecraft:white_concrete
fill 136 150 289 136 151 290 minecraft:red_concrete
fill 136 150 291 136 151 292 minecraft:white_concrete
fill 136 150 293 136 151 294 minecraft:red_concrete
fill 136 150 295 136 151 296 minecraft:white_concrete
fill 136 150 297 136 151 298 minecraft:red_concrete
fill 136 150 299 136 151 300 minecraft:white_concrete
fill 136 150 301 136 151 302 minecraft:red_concrete
fill 136 150 303 136 151 304 minecraft:white_concrete
fill 136 150 305 136 151 306 minecraft:red_concrete
fill 136 150 307 136 151 308 minecraft:white_concrete
fill 136 150 309 136 151 310 minecraft:red_concrete
fill 136 150 311 136 151 312 minecraft:white_concrete
fill 136 150 313 136 151 314 minecraft:red_concrete
fill 136 150 315 136 151 316 minecraft:white_concrete
fill 136 150 317 136 151 317 minecraft:red_concrete
fill 109 151 304 109 152 304 minecraft:yellow_wool
fill 112 151 277 112 153 277 minecraft:yellow_concrete
fill 112 151 283 112 161 283 minecraft:yellow_concrete
fill 113 151 284 113 161 284 minecraft:yellow_concrete
fill 114 151 285 115 161 285 minecraft:yellow_concrete
fill 116 151 286 118 161 286 minecraft:yellow_concrete
fill 119 151 285 120 161 285 minecraft:yellow_concrete
fill 121 151 284 121 161 284 minecraft:yellow_concrete
fill 122 151 277 122 153 278 minecraft:yellow_concrete
fill 122 151 282 122 161 283 minecraft:yellow_concrete
fill 123 151 279 123 161 281 minecraft:yellow_concrete
fill 94 152 275 94 153 276 minecraft:red_concrete
fill 94 152 277 94 153 278 minecraft:white_concrete
fill 94 152 279 94 153 280 minecraft:red_concrete
fill 94 152 281 94 153 282 minecraft:white_concrete
fill 94 152 283 94 153 284 minecraft:red_concrete
fill 94 152 285 94 153 286 minecraft:white_concrete
fill 94 152 287 94 153 288 minecraft:red_concrete
fill 94 152 289 94 153 290 minecraft:white_concrete
fill 94 152 291 94 153 292 minecraft:red_concrete
fill 94 152 293 94 153 294 minecraft:white_concrete
fill 94 152 295 94 153 296 minecraft:red_concrete
fill 94 152 297 94 153 298 minecraft:white_concrete
fill 94 152 299 94 153 300 minecraft:red_concrete
fill 94 152 301 94 153 302 minecraft:white_concrete
fill 94 152 303 94 153 304 minecraft:red_concrete
fill 94 152 305 94 153 306 minecraft:white_concrete
fill 94 152 307 94 153 308 minecraft:red_concrete
fill 94 152 309 94 153 310 minecraft:white_concrete
fill 94 152 311 94 153 312 minecraft:red_concrete
fill 94 152 313 94 153 314 minecraft:white_concrete
fill 94 152 315 94 153 316 minecraft:red_concrete
fill 95 152 275 95 153 275 minecraft:red_concrete
fill 95 152 317 95 153 317 minecraft:red_concrete
fill 96 152 275 97 153 275 minecraft:white_concrete
fill 96 152 317 97 153 317 minecraft:white_concrete
fill 98 152 275 99 153 275 minecraft:red_concrete
fill 98 152 317 99 153 317 minecraft:red_concrete
fill 100 152 275 101 153 275 minecraft:white_concrete
fill 100 152 317 101 153 317 minecraft:white_concrete
fill 102 152 275 103 153 275 minecraft:red_concrete
fill 102 152 317 103 153 317 minecraft:red_concrete
fill 104 152 275 105 153 275 minecraft:white_concrete
fill 104 152 317 105 153 317 minecraft:white_concrete
fill 106 152 275 107 153 275 minecraft:red_concrete
fill 106 152 317 107 153 317 minecraft:red_concrete
fill 108 152 275 109 153 275 minecraft:white_concrete
fill 108 152 317 109 153 317 minecraft:white_concrete
fill 110 152 275 111 153 275 minecraft:red_concrete
fill 110 152 317 111 153 317 minecraft:red_concrete
fill 111 152 277 111 153 277 minecraft:yellow_concrete
fill 111 152 283 111 160 283 minecraft:yellow_concrete
fill 112 152 275 113 153 275 minecraft:white_concrete
fill 112 152 284 112 160 284 minecraft:yellow_concrete
fill 112 152 317 113 153 317 minecraft:white_concrete
fill 113 152 285 113 160 285 minecraft:yellow_concrete
fill 114 152 275 115 153 275 minecraft:red_concrete
fill 114 152 286 115 160 286 minecraft:yellow_concrete
fill 114 152 317 115 153 317 minecraft:red_concrete
fill 116 152 275 117 153 275 minecraft:white_concrete
fill 116 152 317 117 153 317 minecraft:white_concrete
fill 118 152 275 119 153 275 minecraft:red_concrete
fill 118 152 317 119 153 317 minecraft:red_concrete
fill 119 152 286 120 160 286 minecraft:yellow_concrete
fill 120 152 275 121 153 275 minecraft:white_concrete
schedule function dropper:buildpart/62_4 1t
