setblock 471 90 303 minecraft:cobbled_deepslate
fill 471 90 304 471 90 307 minecraft:deepslate_tiles
setblock 471 90 308 minecraft:cobbled_deepslate
fill 471 90 309 471 93 309 minecraft:deepslate_tiles
setblock 471 90 313 minecraft:cobbled_deepslate
fill 471 90 314 471 93 314 minecraft:deepslate_tiles
setblock 472 90 277 minecraft:cobbled_deepslate
fill 472 90 278 472 93 278 minecraft:deepslate_tiles
setblock 472 90 282 minecraft:cobbled_deepslate
fill 472 90 283 472 93 283 minecraft:deepslate_tiles
setblock 472 90 297 minecraft:cobbled_deepslate
fill 472 90 298 472 93 298 minecraft:deepslate_tiles
setblock 472 90 301 minecraft:deepslate_tiles
setblock 472 90 302 minecraft:cobbled_deepslate
fill 472 90 303 472 90 306 minecraft:deepslate_tiles
setblock 472 90 307 minecraft:cobbled_deepslate
fill 472 90 308 473 92 308 minecraft:deepslate_tiles
setblock 472 90 312 minecraft:cobbled_deepslate
fill 472 90 313 472 93 313 minecraft:deepslate_tiles
setblock 472 90 316 minecraft:deepslate_tiles
setblock 473 90 276 minecraft:cobbled_deepslate
fill 473 90 277 473 93 277 minecraft:deepslate_tiles
setblock 473 90 281 minecraft:cobbled_deepslate
setblock 473 90 296 minecraft:cobbled_deepslate
fill 473 90 297 473 93 297 minecraft:deepslate_tiles
setblock 473 90 301 minecraft:cobbled_deepslate
fill 473 90 302 474 92 302 minecraft:deepslate_tiles
setblock 473 90 305 minecraft:deepslate_tiles
setblock 473 90 306 minecraft:cobbled_deepslate
fill 473 90 307 473 93 307 minecraft:deepslate_tiles
setblock 473 90 310 minecraft:deepslate_tiles
setblock 473 90 311 minecraft:cobbled_deepslate
fill 473 90 312 473 92 312 minecraft:deepslate_tiles
setblock 473 90 316 minecraft:cobbled_deepslate
fill 474 90 276 474 93 276 minecraft:deepslate_tiles
setblock 474 90 299 minecraft:deepslate_tiles
setblock 474 90 300 minecraft:cobbled_deepslate
fill 474 90 301 474 93 301 minecraft:deepslate_tiles
fill 474 90 303 474 91 303 minecraft:deepslate_tiles
setblock 474 90 315 minecraft:cobbled_deepslate
fill 474 90 316 474 93 316 minecraft:deepslate_tiles
setblock 475 90 278 minecraft:deepslate_tiles
setblock 475 90 314 minecraft:cobbled_deepslate
fill 475 90 315 475 93 315 minecraft:deepslate_tiles
setblock 476 90 278 minecraft:cobbled_deepslate
fill 476 90 314 476 91 314 minecraft:deepslate_tiles
setblock 477 90 277 minecraft:cobbled_deepslate
fill 477 90 278 477 91 278 minecraft:deepslate_tiles
setblock 478 90 276 minecraft:cobbled_deepslate
fill 478 90 277 478 92 277 minecraft:deepslate_tiles
setblock 478 90 316 minecraft:cobbled_deepslate
setblock 479 90 275 minecraft:redstone_block
fill 479 90 276 479 93 276 minecraft:deepslate_tiles
setblock 479 90 315 minecraft:cobbled_deepslate
fill 479 90 316 479 93 316 minecraft:deepslate_tiles
setblock 480 90 315 minecraft:deepslate_tiles
setblock 483 90 276 minecraft:cobbled_deepslate
setblock 483 90 316 minecraft:cobbled_deepslate
setblock 486 90 275 minecraft:cobbled_deepslate
fill 486 90 276 487 90 276 minecraft:deepslate_tiles
setblock 488 90 276 minecraft:cobbled_deepslate
setblock 488 90 316 minecraft:cobbled_deepslate
fill 489 90 276 489 92 277 minecraft:deepslate_tiles
fill 489 90 316 489 91 316 minecraft:deepslate_tiles
setblock 492 90 277 minecraft:cobbled_deepslate
fill 492 90 278 492 93 278 minecraft:deepslate_tiles
setblock 493 90 276 minecraft:cobbled_deepslate
fill 493 90 277 493 93 277 minecraft:deepslate_tiles
setblock 493 90 316 minecraft:cobbled_deepslate
fill 494 90 276 494 93 276 minecraft:deepslate_tiles
setblock 494 90 279 minecraft:deepslate_tiles
fill 494 90 316 494 93 316 minecraft:deepslate_tiles
setblock 495 90 279 minecraft:cobbled_deepslate
setblock 496 90 277 minecraft:deepslate_tiles
setblock 496 90 278 minecraft:cobbled_deepslate
fill 496 90 279 496 93 279 minecraft:deepslate_tiles
fill 496 90 281 496 91 281 minecraft:black_concrete
fill 496 90 284 496 91 284 minecraft:black_concrete
setblock 497 90 277 minecraft:cobbled_deepslate
fill 497 90 278 497 93 278 minecraft:deepslate_tiles
setblock 498 90 276 minecraft:cobbled_deepslate
fill 498 90 277 498 93 277 minecraft:deepslate_tiles
fill 498 90 279 498 91 279 minecraft:deepslate_tiles
fill 498 90 286 500 91 286 minecraft:black_concrete
setblock 498 90 316 minecraft:cobbled_deepslate
fill 499 90 276 499 93 276 minecraft:deepslate_tiles
fill 499 90 279 500 91 279 minecraft:black_concrete
fill 499 90 316 499 91 316 minecraft:deepslate_tiles
setblock 501 90 278 minecraft:cobbled_deepslate
setblock 502 90 277 minecraft:cobbled_deepslate
fill 502 90 278 502 92 278 minecraft:deepslate_tiles
setblock 503 90 276 minecraft:cobbled_deepslate
fill 503 90 277 503 93 277 minecraft:deepslate_tiles
fill 504 90 276 504 93 276 minecraft:deepslate_tiles
fill 504 90 278 505 90 278 minecraft:deepslate_tiles
setblock 506 90 277 minecraft:deepslate_tiles
setblock 506 90 278 minecraft:cobbled_deepslate
setblock 507 90 277 minecraft:cobbled_deepslate
fill 507 90 278 507 93 278 minecraft:deepslate_tiles
setblock 508 90 276 minecraft:cobbled_deepslate
fill 508 90 277 508 93 277 minecraft:deepslate_tiles
setblock 508 90 316 minecraft:cobbled_deepslate
fill 509 90 276 509 93 276 minecraft:deepslate_tiles
setblock 509 90 280 minecraft:cobbled_deepslate
fill 509 90 281 509 92 282 minecraft:deepslate_tiles
fill 509 90 316 509 93 316 minecraft:deepslate_tiles
setblock 510 90 279 minecraft:cobbled_deepslate
fill 510 90 280 510 93 280 minecraft:deepslate_tiles
setblock 510 90 284 minecraft:cobbled_deepslate
fill 510 90 297 510 90 298 minecraft:deepslate_tiles
setblock 510 90 299 minecraft:cobbled_deepslate
fill 510 90 300 510 92 301 minecraft:deepslate_tiles
fill 510 90 315 510 93 315 minecraft:deepslate_tiles
setblock 511 90 278 minecraft:cobbled_deepslate
fill 511 90 279 511 93 279 minecraft:deepslate_tiles
setblock 511 90 283 minecraft:cobbled_deepslate
fill 511 90 284 511 93 284 minecraft:deepslate_tiles
setblock 511 90 287 minecraft:deepslate_tiles
setblock 511 90 288 minecraft:cobbled_deepslate
fill 511 90 289 511 93 289 minecraft:deepslate_tiles
setblock 511 90 293 minecraft:cobbled_deepslate
fill 511 90 294 511 93 294 minecraft:deepslate_tiles
setblock 511 90 298 minecraft:cobbled_deepslate
fill 511 90 299 511 93 299 minecraft:deepslate_tiles
setblock 511 90 303 minecraft:cobbled_deepslate
fill 511 90 304 511 90 307 minecraft:deepslate_tiles
setblock 511 90 308 minecraft:cobbled_deepslate
fill 511 90 309 511 92 310 minecraft:deepslate_tiles
setblock 511 90 313 minecraft:cobbled_deepslate
fill 511 90 314 511 93 314 minecraft:deepslate_tiles
setblock 470 91 275 minecraft:black_concrete
fill 470 91 276 470 94 276 minecraft:cobbled_deepslate
setblock 470 91 278 minecraft:black_concrete
fill 470 91 279 470 94 279 minecraft:cobbled_deepslate
setblock 470 91 288 minecraft:redstone_block
fill 470 91 302 471 91 302 minecraft:cobbled_deepslate
setblock 470 91 303 minecraft:black_concrete
fill 470 91 308 470 91 309 minecraft:black_concrete
setblock 470 91 311 minecraft:black_concrete
setblock 470 91 313 minecraft:black_concrete
fill 470 91 314 470 94 314 minecraft:cobbled_deepslate
setblock 470 91 315 minecraft:black_concrete
setblock 470 91 317 minecraft:black_concrete
setblock 471 91 277 minecraft:cobbled_deepslate
fill 471 91 278 471 94 278 minecraft:deepslate_tiles
setblock 471 91 281 minecraft:deepslate_tiles
setblock 471 91 282 minecraft:cobbled_deepslate
fill 471 91 283 471 94 283 minecraft:deepslate_tiles
setblock 471 91 286 minecraft:deepslate_tiles
setblock 471 91 292 minecraft:cobbled_deepslate
fill 471 91 293 471 93 294 minecraft:deepslate_tiles
setblock 471 91 296 minecraft:deepslate_tiles
setblock 471 91 297 minecraft:cobbled_deepslate
fill 471 91 298 471 94 298 minecraft:deepslate_tiles
setblock 471 91 301 minecraft:deepslate_tiles
fill 471 91 303 471 91 306 minecraft:deepslate_tiles
setblock 471 91 307 minecraft:cobbled_deepslate
fill 471 91 308 471 94 308 minecraft:deepslate_tiles
setblock 471 91 312 minecraft:cobbled_deepslate
fill 471 91 313 471 94 313 minecraft:deepslate_tiles
setblock 472 91 276 minecraft:cobbled_deepslate
fill 472 91 277 472 94 277 minecraft:deepslate_tiles
setblock 472 91 281 minecraft:cobbled_deepslate
fill 472 91 282 472 94 282 minecraft:deepslate_tiles
fill 472 91 284 472 92 284 minecraft:deepslate_tiles
setblock 472 91 296 minecraft:cobbled_deepslate
fill 472 91 297 472 94 297 minecraft:deepslate_tiles
setblock 472 91 300 minecraft:deepslate_tiles
setblock 472 91 301 minecraft:cobbled_deepslate
fill 472 91 302 472 91 305 minecraft:deepslate_tiles
setblock 472 91 306 minecraft:cobbled_deepslate
fill 472 91 307 472 94 307 minecraft:deepslate_tiles
setblock 472 91 311 minecraft:cobbled_deepslate
fill 472 91 312 472 94 312 minecraft:deepslate_tiles
setblock 472 91 316 minecraft:cobbled_deepslate
setblock 473 91 275 minecraft:black_concrete
fill 473 91 276 473 94 276 minecraft:deepslate_tiles
setblock 473 91 280 minecraft:cobbled_deepslate
fill 473 91 281 473 93 281 minecraft:deepslate_tiles
setblock 473 91 285 minecraft:light[level=12]
setblock 473 91 292 minecraft:light[level=12]
setblock 473 91 296 minecraft:deepslate_tiles
setblock 473 91 300 minecraft:cobbled_deepslate
fill 473 91 301 473 94 301 minecraft:deepslate_tiles
setblock 473 91 305 minecraft:cobbled_deepslate
fill 473 91 306 473 94 306 minecraft:deepslate_tiles
setblock 473 91 309 minecraft:deepslate_tiles
setblock 473 91 310 minecraft:cobbled_deepslate
fill 473 91 311 473 93 311 minecraft:deepslate_tiles
setblock 473 91 315 minecraft:cobbled_deepslate
fill 473 91 316 473 94 316 minecraft:deepslate_tiles
setblock 474 91 299 minecraft:cobbled_deepslate
fill 474 91 300 474 93 300 minecraft:deepslate_tiles
setblock 474 91 304 minecraft:cobbled_deepslate
fill 474 91 305 474 94 305 minecraft:deepslate_tiles
setblock 474 91 314 minecraft:cobbled_deepslate
fill 474 91 315 474 94 315 minecraft:deepslate_tiles
setblock 475 91 275 minecraft:black_concrete
setblock 475 91 278 minecraft:cobbled_deepslate
fill 475 91 314 475 92 314 minecraft:deepslate_tiles
setblock 476 91 277 minecraft:cobbled_deepslate
fill 476 91 278 476 92 278 minecraft:deepslate_tiles
setblock 476 91 317 minecraft:redstone_block
setblock 477 91 276 minecraft:cobbled_deepslate
fill 477 91 277 477 93 277 minecraft:deepslate_tiles
fill 477 91 316 477 91 317 minecraft:cobbled_deepslate
fill 478 91 276 478 93 276 minecraft:deepslate_tiles
setblock 478 91 315 minecraft:cobbled_deepslate
fill 478 91 316 478 93 316 minecraft:deepslate_tiles
fill 478 91 317 480 94 317 minecraft:cobbled_deepslate
fill 479 91 275 479 95 275 minecraft:cobbled_deepslate
setblock 479 91 315 minecraft:deepslate_tiles
setblock 480 91 278 minecraft:light[level=12]
setblock 480 91 285 minecraft:light[level=12]
setblock 480 91 292 minecraft:light[level=12]
setblock 480 91 299 minecraft:light[level=12]
setblock 480 91 306 minecraft:light[level=12]
setblock 480 91 313 minecraft:light[level=12]
setblock 482 91 276 minecraft:cobbled_deepslate
setblock 482 91 316 minecraft:cobbled_deepslate
setblock 482 91 317 minecraft:black_concrete
fill 486 91 275 486 92 275 minecraft:black_concrete
setblock 486 91 276 minecraft:deepslate_tiles
setblock 487 91 276 minecraft:cobbled_deepslate
setblock 487 91 278 minecraft:light[level=12]
setblock 487 91 285 minecraft:light[level=12]
setblock 487 91 292 minecraft:light[level=12]
setblock 487 91 299 minecraft:light[level=12]
setblock 487 91 306 minecraft:light[level=12]
setblock 487 91 313 minecraft:light[level=12]
fill 488 91 276 488 94 276 minecraft:deepslate_tiles
setblock 489 91 275 minecraft:black_concrete
setblock 491 91 276 minecraft:deepslate_tiles
setblock 491 91 277 minecraft:cobbled_deepslate
fill 491 91 278 491 94 278 minecraft:deepslate_tiles
setblock 492 91 276 minecraft:cobbled_deepslate
fill 492 91 277 492 94 277 minecraft:deepslate_tiles
fill 492 91 306 492 92 306 minecraft:white_wool
setblock 492 91 316 minecraft:cobbled_deepslate
fill 493 91 276 493 94 276 minecraft:deepslate_tiles
setblock 493 91 279 minecraft:deepslate_tiles
fill 493 91 316 493 93 316 minecraft:deepslate_tiles
setblock 494 91 278 minecraft:deepslate_tiles
setblock 494 91 279 minecraft:cobbled_deepslate
setblock 494 91 285 minecraft:light[level=12]
setblock 494 91 292 minecraft:light[level=12]
setblock 494 91 299 minecraft:light[level=12]
setblock 494 91 306 minecraft:light[level=12]
setblock 495 91 278 minecraft:cobbled_deepslate
fill 495 91 279 495 93 279 minecraft:deepslate_tiles
fill 495 91 281 495 91 284 minecraft:black_concrete
setblock 496 91 277 minecraft:cobbled_deepslate
fill 496 91 278 496 94 278 minecraft:deepslate_tiles
setblock 496 91 280 minecraft:black_concrete
setblock 496 91 285 minecraft:black_concrete
setblock 497 91 276 minecraft:cobbled_deepslate
fill 497 91 277 497 94 277 minecraft:deepslate_tiles
setblock 497 91 286 minecraft:black_concrete
setblock 497 91 316 minecraft:cobbled_deepslate
fill 498 91 276 498 94 276 minecraft:deepslate_tiles
fill 498 91 316 498 92 316 minecraft:deepslate_tiles
setblock 498 91 317 minecraft:black_concrete
setblock 500 91 278 minecraft:cobbled_deepslate
setblock 501 91 277 minecraft:cobbled_deepslate
fill 501 91 278 501 92 278 minecraft:deepslate_tiles
setblock 501 91 279 minecraft:black_concrete
setblock 501 91 286 minecraft:black_concrete
setblock 501 91 292 minecraft:light[level=12]
setblock 501 91 299 minecraft:light[level=12]
setblock 501 91 306 minecraft:light[level=12]
setblock 501 91 313 minecraft:light[level=12]
setblock 502 91 276 minecraft:cobbled_deepslate
fill 502 91 277 502 94 277 minecraft:deepslate_tiles
setblock 502 91 280 minecraft:black_concrete
setblock 502 91 285 minecraft:black_concrete
fill 503 91 276 503 94 276 minecraft:deepslate_tiles
fill 503 91 281 503 91 284 minecraft:black_concrete
setblock 504 91 278 minecraft:deepslate_tiles
setblock 505 91 278 minecraft:cobbled_deepslate
setblock 506 91 277 minecraft:cobbled_deepslate
fill 506 91 278 506 94 278 minecraft:deepslate_tiles
setblock 507 91 276 minecraft:cobbled_deepslate
fill 507 91 277 507 94 277 minecraft:deepslate_tiles
setblock 507 91 316 minecraft:cobbled_deepslate
fill 508 91 276 508 94 276 minecraft:deepslate_tiles
setblock 508 91 285 minecraft:light[level=12]
setblock 508 91 292 minecraft:light[level=12]
setblock 508 91 299 minecraft:light[level=12]
setblock 508 91 306 minecraft:light[level=12]
setblock 508 91 313 minecraft:light[level=12]
fill 508 91 316 508 94 316 minecraft:deepslate_tiles
setblock 509 91 278 minecraft:deepslate_tiles
setblock 509 91 279 minecraft:cobbled_deepslate
fill 509 91 280 509 94 280 minecraft:deepslate_tiles
setblock 510 91 278 minecraft:cobbled_deepslate
fill 510 91 279 510 94 279 minecraft:deepslate_tiles
setblock 510 91 283 minecraft:cobbled_deepslate
fill 510 91 284 510 93 285 minecraft:deepslate_tiles
setblock 510 91 297 minecraft:deepslate_tiles
setblock 510 91 298 minecraft:cobbled_deepslate
fill 510 91 299 510 93 299 minecraft:deepslate_tiles
setblock 510 91 302 minecraft:deepslate_tiles
setblock 510 91 303 minecraft:cobbled_deepslate
setblock 511 91 277 minecraft:cobbled_deepslate
fill 511 91 278 511 94 278 minecraft:deepslate_tiles
setblock 511 91 282 minecraft:cobbled_deepslate
fill 511 91 283 511 94 283 minecraft:deepslate_tiles
setblock 511 91 287 minecraft:cobbled_deepslate
fill 511 91 288 511 94 288 minecraft:deepslate_tiles
setblock 511 91 292 minecraft:cobbled_deepslate
fill 511 91 293 511 92 293 minecraft:deepslate_tiles
setblock 511 91 297 minecraft:cobbled_deepslate
fill 511 91 298 511 94 298 minecraft:deepslate_tiles
setblock 511 91 301 minecraft:deepslate_tiles
setblock 511 91 302 minecraft:cobbled_deepslate
fill 511 91 303 511 91 306 minecraft:deepslate_tiles
setblock 511 91 307 minecraft:cobbled_deepslate
fill 511 91 308 511 94 308 minecraft:deepslate_tiles
setblock 511 91 312 minecraft:cobbled_deepslate
fill 511 91 313 511 94 313 minecraft:deepslate_tiles
setblock 512 91 283 minecraft:black_concrete
fill 512 91 291 512 92 291 minecraft:black_concrete
setblock 512 91 293 minecraft:black_concrete
setblock 512 91 303 minecraft:black_concrete
setblock 512 91 307 minecraft:black_concrete
fill 470 92 275 471 92 275 minecraft:cobbled_deepslate
fill 470 92 278 470 94 278 minecraft:cobbled_deepslate
setblock 470 92 284 minecraft:cobbled_deepslate
setblock 470 92 285 minecraft:black_concrete
fill 470 92 286 471 92 286 minecraft:cobbled_deepslate
setblock 470 92 287 minecraft:black_concrete
fill 470 92 288 470 94 288 minecraft:cobbled_deepslate
setblock 470 92 299 minecraft:black_concrete
fill 470 92 302 470 94 303 minecraft:cobbled_deepslate
fill 470 92 308 470 94 309 minecraft:cobbled_deepslate
fill 470 92 311 471 92 311 minecraft:cobbled_deepslate
fill 470 92 313 470 94 313 minecraft:cobbled_deepslate
fill 470 92 315 470 94 315 minecraft:cobbled_deepslate
setblock 470 92 317 minecraft:cobbled_deepslate
setblock 471 92 276 minecraft:cobbled_deepslate
fill 471 92 277 471 95 277 minecraft:deepslate_tiles
setblock 471 92 281 minecraft:cobbled_deepslate
fill 471 92 282 471 95 282 minecraft:deepslate_tiles
fill 471 92 287 471 95 287 minecraft:deepslate_tiles
setblock 471 92 296 minecraft:cobbled_deepslate
fill 471 92 297 471 95 297 minecraft:deepslate_tiles
setblock 471 92 301 minecraft:cobbled_deepslate
fill 471 92 302 471 92 305 minecraft:deepslate_tiles
setblock 471 92 306 minecraft:cobbled_deepslate
fill 471 92 307 471 95 307 minecraft:deepslate_tiles
fill 471 92 312 471 95 312 minecraft:deepslate_tiles
setblock 471 92 315 minecraft:deepslate_tiles
setblock 471 92 316 minecraft:cobbled_deepslate
setblock 472 92 275 minecraft:black_concrete
fill 472 92 276 472 95 276 minecraft:deepslate_tiles
setblock 472 92 280 minecraft:cobbled_deepslate
fill 472 92 281 472 95 281 minecraft:deepslate_tiles
setblock 472 92 295 minecraft:cobbled_deepslate
fill 472 92 296 472 94 296 minecraft:deepslate_tiles
setblock 472 92 300 minecraft:cobbled_deepslate
fill 472 92 301 472 92 304 minecraft:deepslate_tiles
setblock 472 92 305 minecraft:cobbled_deepslate
fill 472 92 306 472 95 306 minecraft:deepslate_tiles
setblock 472 92 310 minecraft:cobbled_deepslate
fill 472 92 311 472 95 311 minecraft:deepslate_tiles
setblock 472 92 315 minecraft:cobbled_deepslate
fill 472 92 316 472 95 316 minecraft:deepslate_tiles
fill 473 92 275 473 95 275 minecraft:cobbled_deepslate
setblock 473 92 279 minecraft:cobbled_deepslate
fill 473 92 280 473 94 280 minecraft:deepslate_tiles
setblock 473 92 282 minecraft:deepslate_tiles
setblock 473 92 299 minecraft:cobbled_deepslate
fill 473 92 300 473 95 300 minecraft:deepslate_tiles
setblock 473 92 303 minecraft:deepslate_tiles
setblock 473 92 304 minecraft:cobbled_deepslate
fill 473 92 305 473 95 305 minecraft:deepslate_tiles
setblock 473 92 309 minecraft:cobbled_deepslate
fill 473 92 310 473 95 310 minecraft:deepslate_tiles
setblock 473 92 314 minecraft:cobbled_deepslate
fill 473 92 315 473 95 315 minecraft:deepslate_tiles
setblock 474 92 278 minecraft:cobbled_deepslate
setblock 474 92 299 minecraft:deepslate_tiles
setblock 474 92 303 minecraft:cobbled_deepslate
fill 474 92 304 474 95 304 minecraft:deepslate_tiles
fill 474 92 306 474 93 306 minecraft:deepslate_tiles
setblock 474 92 314 minecraft:deepslate_tiles
fill 475 92 275 475 94 275 minecraft:cobbled_deepslate
setblock 475 92 277 minecraft:cobbled_deepslate
fill 475 92 278 475 93 278 minecraft:deepslate_tiles
setblock 476 92 276 minecraft:cobbled_deepslate
fill 476 92 277 476 93 277 minecraft:deepslate_tiles
fill 476 92 316 476 92 317 minecraft:cobbled_deepslate
fill 477 92 276 477 94 276 minecraft:deepslate_tiles
setblock 477 92 315 minecraft:cobbled_deepslate
fill 477 92 316 477 94 316 minecraft:deepslate_tiles
fill 477 92 317 477 94 317 minecraft:cobbled_deepslate
setblock 478 92 315 minecraft:deepslate_tiles
setblock 481 92 276 minecraft:cobbled_deepslate
fill 482 92 317 482 94 317 minecraft:cobbled_deepslate
fill 487 92 276 487 93 276 minecraft:deepslate_tiles
setblock 489 92 275 minecraft:cobbled_deepslate
setblock 490 92 276 minecraft:deepslate_tiles
setblock 490 92 277 minecraft:cobbled_deepslate
setblock 491 92 276 minecraft:cobbled_deepslate
fill 491 92 277 491 95 277 minecraft:deepslate_tiles
setblock 491 92 316 minecraft:cobbled_deepslate
fill 492 92 276 492 95 276 minecraft:deepslate_tiles
fill 492 92 316 492 93 316 minecraft:deepslate_tiles
setblock 493 92 279 minecraft:cobbled_deepslate
setblock 494 92 278 minecraft:cobbled_deepslate
fill 494 92 279 494 93 279 minecraft:deepslate_tiles
setblock 494 92 317 minecraft:black_concrete
setblock 495 92 275 minecraft:black_concrete
setblock 495 92 277 minecraft:cobbled_deepslate
fill 495 92 278 495 95 278 minecraft:deepslate_tiles
setblock 496 92 276 minecraft:cobbled_deepslate
fill 496 92 277 496 95 277 minecraft:deepslate_tiles
setblock 496 92 316 minecraft:cobbled_deepslate
fill 497 92 276 497 95 276 minecraft:deepslate_tiles
setblock 497 92 316 minecraft:deepslate_tiles
fill 498 92 282 500 92 283 minecraft:white_wool
fill 498 92 317 498 94 317 minecraft:cobbled_deepslate
setblock 499 92 278 minecraft:cobbled_deepslate
setblock 500 92 277 minecraft:cobbled_deepslate
fill 500 92 278 500 93 278 minecraft:deepslate_tiles
setblock 501 92 276 minecraft:cobbled_deepslate
fill 501 92 277 501 94 277 minecraft:deepslate_tiles
fill 502 92 276 502 95 276 minecraft:deepslate_tiles
setblock 504 92 278 minecraft:cobbled_deepslate
fill 504 92 297 508 93 301 minecraft:black_concrete
setblock 505 92 277 minecraft:cobbled_deepslate
fill 505 92 278 505 93 278 minecraft:deepslate_tiles
setblock 506 92 276 minecraft:cobbled_deepslate
fill 506 92 277 506 95 277 minecraft:deepslate_tiles
setblock 506 92 316 minecraft:cobbled_deepslate
setblock 507 92 275 minecraft:black_concrete
fill 507 92 276 507 95 276 minecraft:deepslate_tiles
fill 507 92 316 507 95 316 minecraft:deepslate_tiles
setblock 509 92 278 minecraft:cobbled_deepslate
fill 509 92 279 509 95 279 minecraft:deepslate_tiles
setblock 509 92 283 minecraft:cobbled_deepslate
setblock 509 92 299 minecraft:black_concrete
setblock 510 92 277 minecraft:cobbled_deepslate
fill 510 92 278 510 95 278 minecraft:deepslate_tiles
setblock 510 92 282 minecraft:cobbled_deepslate
fill 510 92 283 510 95 283 minecraft:deepslate_tiles
setblock 510 92 286 minecraft:deepslate_tiles
setblock 510 92 298 minecraft:deepslate_tiles
setblock 510 92 302 minecraft:cobbled_deepslate
fill 510 92 303 511 93 304 minecraft:deepslate_tiles
setblock 510 92 314 minecraft:deepslate_tiles
setblock 511 92 276 minecraft:cobbled_deepslate
fill 511 92 277 511 95 277 minecraft:deepslate_tiles
setblock 511 92 281 minecraft:cobbled_deepslate
fill 511 92 282 511 95 282 minecraft:deepslate_tiles
setblock 511 92 286 minecraft:cobbled_deepslate
fill 511 92 287 511 95 287 minecraft:deepslate_tiles
setblock 511 92 291 minecraft:cobbled_deepslate
setblock 511 92 292 minecraft:deepslate_tiles
setblock 511 92 296 minecraft:cobbled_deepslate
fill 511 92 297 511 95 297 minecraft:deepslate_tiles
setblock 511 92 301 minecraft:cobbled_deepslate
fill 511 92 302 511 95 302 minecraft:deepslate_tiles
setblock 511 92 305 minecraft:deepslate_tiles
setblock 511 92 306 minecraft:cobbled_deepslate
fill 511 92 307 511 95 307 minecraft:deepslate_tiles
setblock 511 92 311 minecraft:cobbled_deepslate
fill 511 92 312 511 95 312 minecraft:deepslate_tiles
setblock 511 92 316 minecraft:cobbled_deepslate
setblock 512 92 277 minecraft:black_concrete
fill 512 92 283 512 94 283 minecraft:cobbled_deepslate
setblock 512 92 287 minecraft:black_concrete
fill 512 92 290 512 93 290 minecraft:black_concrete
fill 512 92 293 512 94 293 minecraft:cobbled_deepslate
setblock 512 92 299 minecraft:black_concrete
fill 512 92 303 512 95 303 minecraft:cobbled_deepslate
fill 512 92 307 512 94 307 minecraft:cobbled_deepslate
fill 512 92 309 512 94 309 minecraft:cobbled_deepslate
setblock 512 92 310 minecraft:black_concrete
fill 512 92 313 512 94 314 minecraft:cobbled_deepslate
setblock 512 92 315 minecraft:black_concrete
setblock 470 93 275 minecraft:black_concrete
setblock 470 93 277 minecraft:redstone_block
setblock 470 93 284 minecraft:black_concrete
fill 470 93 285 470 94 287 minecraft:cobbled_deepslate
fill 470 93 299 470 94 299 minecraft:cobbled_deepslate
setblock 470 93 300 minecraft:black_concrete
fill 470 93 311 470 94 311 minecraft:cobbled_deepslate
fill 470 93 316 470 93 317 minecraft:black_concrete
fill 471 93 275 472 94 275 minecraft:cobbled_deepslate
fill 471 93 276 471 96 276 minecraft:deepslate_tiles
setblock 471 93 280 minecraft:cobbled_deepslate
fill 471 93 281 471 96 281 minecraft:deepslate_tiles
setblock 471 93 284 minecraft:deepslate_tiles
setblock 471 93 285 minecraft:cobbled_deepslate
fill 471 93 286 471 96 286 minecraft:deepslate_tiles
setblock 471 93 295 minecraft:cobbled_deepslate
fill 471 93 296 471 96 296 minecraft:deepslate_tiles
setblock 471 93 300 minecraft:cobbled_deepslate
fill 471 93 301 471 93 304 minecraft:deepslate_tiles
setblock 471 93 305 minecraft:cobbled_deepslate
fill 471 93 306 471 96 306 minecraft:deepslate_tiles
setblock 471 93 310 minecraft:cobbled_deepslate
fill 471 93 311 471 96 311 minecraft:deepslate_tiles
setblock 471 93 315 minecraft:cobbled_deepslate
fill 471 93 316 471 96 316 minecraft:deepslate_tiles
setblock 472 93 279 minecraft:cobbled_deepslate
fill 472 93 280 472 96 280 minecraft:deepslate_tiles
setblock 472 93 284 minecraft:cobbled_deepslate
setblock 472 93 299 minecraft:cobbled_deepslate
fill 472 93 300 472 93 303 minecraft:deepslate_tiles
setblock 472 93 304 minecraft:cobbled_deepslate
fill 472 93 305 472 96 305 minecraft:deepslate_tiles
setblock 472 93 308 minecraft:deepslate_tiles
setblock 472 93 309 minecraft:cobbled_deepslate
fill 472 93 310 472 96 310 minecraft:deepslate_tiles
setblock 472 93 314 minecraft:cobbled_deepslate
fill 472 93 315 472 96 315 minecraft:deepslate_tiles
setblock 473 93 278 minecraft:cobbled_deepslate
fill 473 93 279 473 94 279 minecraft:deepslate_tiles
setblock 473 93 286 minecraft:light[level=13]
setblock 473 93 294 minecraft:light[level=13]
setblock 473 93 298 minecraft:cobbled_deepslate
fill 473 93 299 473 95 299 minecraft:deepslate_tiles
setblock 473 93 302 minecraft:deepslate_tiles
setblock 473 93 303 minecraft:cobbled_deepslate
fill 473 93 304 473 96 304 minecraft:deepslate_tiles
setblock 473 93 308 minecraft:cobbled_deepslate
fill 473 93 309 473 96 309 minecraft:deepslate_tiles
setblock 473 93 314 minecraft:deepslate_tiles
setblock 474 93 277 minecraft:cobbled_deepslate
setblock 474 93 278 minecraft:deepslate_tiles
setblock 474 93 302 minecraft:cobbled_deepslate
fill 474 93 303 474 95 303 minecraft:deepslate_tiles
setblock 475 93 276 minecraft:cobbled_deepslate
fill 475 93 277 475 94 277 minecraft:deepslate_tiles
setblock 475 93 316 minecraft:cobbled_deepslate
fill 476 93 276 476 95 276 minecraft:deepslate_tiles
setblock 476 93 315 minecraft:cobbled_deepslate
fill 476 93 316 476 95 316 minecraft:deepslate_tiles
fill 476 93 317 476 94 317 minecraft:cobbled_deepslate
setblock 477 93 275 minecraft:black_concrete
setblock 477 93 315 minecraft:deepslate_tiles
setblock 481 93 278 minecraft:light[level=13]
setblock 481 93 286 minecraft:light[level=13]
setblock 481 93 294 minecraft:light[level=13]
setblock 481 93 302 minecraft:light[level=13]
setblock 481 93 310 minecraft:light[level=13]
fill 486 93 275 486 94 275 minecraft:cobbled_deepslate
setblock 489 93 275 minecraft:black_concrete
setblock 489 93 276 minecraft:deepslate_tiles
setblock 489 93 277 minecraft:cobbled_deepslate
setblock 489 93 278 minecraft:light[level=13]
setblock 489 93 286 minecraft:light[level=13]
setblock 489 93 294 minecraft:light[level=13]
setblock 489 93 302 minecraft:light[level=13]
setblock 489 93 310 minecraft:light[level=13]
setblock 490 93 275 minecraft:redstone_block
setblock 490 93 276 minecraft:cobbled_deepslate
fill 490 93 277 490 95 277 minecraft:deepslate_tiles
fill 491 93 276 491 96 276 minecraft:deepslate_tiles
setblock 491 93 316 minecraft:deepslate_tiles
fill 492 93 317 492 94 317 minecraft:cobbled_deepslate
setblock 493 93 278 minecraft:cobbled_deepslate
setblock 493 93 279 minecraft:deepslate_tiles
setblock 493 93 317 minecraft:black_concrete
setblock 494 93 277 minecraft:cobbled_deepslate
fill 494 93 278 494 95 278 minecraft:deepslate_tiles
fill 494 93 317 494 94 317 minecraft:cobbled_deepslate
fill 495 93 275 495 93 276 minecraft:cobbled_deepslate
fill 495 93 277 495 96 277 minecraft:deepslate_tiles
setblock 495 93 316 minecraft:cobbled_deepslate
fill 496 93 276 496 96 276 minecraft:deepslate_tiles
setblock 496 93 316 minecraft:deepslate_tiles
setblock 497 93 286 minecraft:light[level=13]
setblock 497 93 294 minecraft:light[level=13]
setblock 497 93 302 minecraft:light[level=13]
setblock 497 93 310 minecraft:light[level=13]
setblock 498 93 278 minecraft:cobbled_deepslate
setblock 499 93 277 minecraft:cobbled_deepslate
setblock 499 93 278 minecraft:deepslate_tiles
fill 499 93 282 499 95 283 minecraft:white_wool
setblock 500 93 276 minecraft:cobbled_deepslate
fill 500 93 277 500 94 277 minecraft:deepslate_tiles
fill 501 93 276 501 95 276 minecraft:deepslate_tiles
setblock 504 93 277 minecraft:cobbled_deepslate
setblock 505 93 276 minecraft:cobbled_deepslate
fill 505 93 277 505 95 277 minecraft:deepslate_tiles
setblock 505 93 286 minecraft:light[level=13]
setblock 505 93 294 minecraft:light[level=13]
setblock 505 93 302 minecraft:light[level=13]
setblock 505 93 310 minecraft:light[level=13]
fill 505 93 317 507 93 317 minecraft:black_concrete
fill 506 93 276 506 96 276 minecraft:deepslate_tiles
fill 507 93 275 507 94 275 minecraft:cobbled_deepslate
setblock 508 93 278 minecraft:cobbled_deepslate
setblock 509 93 277 minecraft:cobbled_deepslate
fill 509 93 278 509 96 278 minecraft:deepslate_tiles
setblock 509 93 281 minecraft:deepslate_tiles
setblock 509 93 282 minecraft:cobbled_deepslate
fill 509 93 283 509 96 283 minecraft:deepslate_tiles
setblock 510 93 276 minecraft:cobbled_deepslate
fill 510 93 277 510 96 277 minecraft:deepslate_tiles
setblock 510 93 281 minecraft:cobbled_deepslate
fill 510 93 282 510 96 282 minecraft:deepslate_tiles
setblock 510 93 286 minecraft:cobbled_deepslate
setblock 510 93 300 minecraft:deepslate_tiles
setblock 510 93 301 minecraft:cobbled_deepslate
fill 510 93 302 510 96 302 minecraft:deepslate_tiles
setblock 510 93 305 minecraft:deepslate_tiles
setblock 510 93 306 minecraft:cobbled_deepslate
setblock 510 93 316 minecraft:cobbled_deepslate
fill 511 93 276 511 96 276 minecraft:deepslate_tiles
setblock 511 93 280 minecraft:cobbled_deepslate
fill 511 93 281 511 96 281 minecraft:deepslate_tiles
setblock 511 93 285 minecraft:cobbled_deepslate
fill 511 93 286 511 96 286 minecraft:deepslate_tiles
setblock 511 93 295 minecraft:cobbled_deepslate
fill 511 93 296 511 94 296 minecraft:deepslate_tiles
setblock 511 93 300 minecraft:cobbled_deepslate
fill 511 93 301 511 96 301 minecraft:deepslate_tiles
setblock 511 93 305 minecraft:cobbled_deepslate
fill 511 93 306 511 96 306 minecraft:deepslate_tiles
setblock 511 93 309 minecraft:deepslate_tiles
fill 511 93 310 512 93 310 minecraft:cobbled_deepslate
fill 511 93 311 511 96 311 minecraft:deepslate_tiles
fill 511 93 315 512 93 315 minecraft:cobbled_deepslate
fill 511 93 316 511 96 316 minecraft:deepslate_tiles
fill 512 93 277 512 94 277 minecraft:cobbled_deepslate
setblock 512 93 285 minecraft:black_concrete
fill 512 93 287 512 94 287 minecraft:cobbled_deepslate
setblock 512 93 288 minecraft:black_concrete
fill 512 93 291 512 94 291 minecraft:cobbled_deepslate
setblock 512 93 298 minecraft:black_concrete
fill 512 93 299 512 94 299 minecraft:cobbled_deepslate
setblock 512 93 306 minecraft:black_concrete
fill 470 94 275 470 95 275 minecraft:cobbled_deepslate
setblock 470 94 277 minecraft:cobbled_deepslate
fill 470 94 284 471 94 284 minecraft:cobbled_deepslate
setblock 470 94 300 minecraft:cobbled_deepslate
fill 470 94 316 470 94 317 minecraft:cobbled_deepslate
setblock 471 94 279 minecraft:cobbled_deepslate
fill 471 94 280 471 97 280 minecraft:deepslate_tiles
fill 471 94 285 471 97 285 minecraft:deepslate_tiles
setblock 471 94 294 minecraft:cobbled_deepslate
fill 471 94 295 471 95 295 minecraft:deepslate_tiles
setblock 471 94 299 minecraft:cobbled_deepslate
fill 471 94 300 471 94 303 minecraft:deepslate_tiles
setblock 471 94 304 minecraft:cobbled_deepslate
fill 471 94 305 471 97 305 minecraft:deepslate_tiles
setblock 471 94 309 minecraft:cobbled_deepslate
fill 471 94 310 471 97 310 minecraft:deepslate_tiles
setblock 471 94 314 minecraft:cobbled_deepslate
fill 471 94 315 471 97 315 minecraft:deepslate_tiles
setblock 472 94 278 minecraft:cobbled_deepslate
fill 472 94 279 472 96 279 minecraft:deepslate_tiles
setblock 472 94 283 minecraft:cobbled_deepslate
fill 472 94 284 472 97 284 minecraft:deepslate_tiles
setblock 472 94 298 minecraft:cobbled_deepslate
fill 472 94 299 472 94 302 minecraft:deepslate_tiles
setblock 472 94 303 minecraft:cobbled_deepslate
fill 472 94 304 472 97 304 minecraft:deepslate_tiles
setblock 472 94 308 minecraft:cobbled_deepslate
fill 472 94 309 472 97 309 minecraft:deepslate_tiles
setblock 472 94 313 minecraft:cobbled_deepslate
fill 472 94 314 472 96 314 minecraft:deepslate_tiles
setblock 473 94 277 minecraft:cobbled_deepslate
setblock 473 94 278 minecraft:deepslate_tiles
setblock 473 94 298 minecraft:deepslate_tiles
setblock 473 94 302 minecraft:cobbled_deepslate
fill 473 94 303 473 97 303 minecraft:deepslate_tiles
setblock 473 94 307 minecraft:cobbled_deepslate
fill 473 94 308 473 97 308 minecraft:deepslate_tiles
setblock 474 94 276 minecraft:cobbled_deepslate
fill 474 94 277 474 95 277 minecraft:deepslate_tiles
setblock 474 94 301 minecraft:cobbled_deepslate
fill 474 94 302 474 95 302 minecraft:deepslate_tiles
setblock 474 94 306 minecraft:cobbled_deepslate
setblock 474 94 316 minecraft:cobbled_deepslate
fill 475 94 276 475 95 276 minecraft:deepslate_tiles
setblock 475 94 315 minecraft:cobbled_deepslate
fill 475 94 316 475 96 316 minecraft:deepslate_tiles
setblock 477 94 275 minecraft:cobbled_deepslate
fill 489 94 275 489 94 276 minecraft:cobbled_deepslate
setblock 489 94 277 minecraft:deepslate_tiles
setblock 490 94 275 minecraft:cobbled_deepslate
fill 490 94 276 490 97 276 minecraft:deepslate_tiles
setblock 492 94 278 minecraft:cobbled_deepslate
setblock 493 94 277 minecraft:cobbled_deepslate
fill 493 94 278 493 95 278 minecraft:deepslate_tiles
setblock 493 94 317 minecraft:cobbled_deepslate
setblock 494 94 276 minecraft:cobbled_deepslate
fill 494 94 277 494 96 277 minecraft:deepslate_tiles
setblock 495 94 275 minecraft:cobbled_deepslate
fill 495 94 276 495 97 276 minecraft:deepslate_tiles
setblock 497 94 278 minecraft:cobbled_deepslate
setblock 498 94 277 minecraft:cobbled_deepslate
setblock 499 94 276 minecraft:cobbled_deepslate
setblock 499 94 277 minecraft:deepslate_tiles
fill 500 94 276 500 95 276 minecraft:deepslate_tiles
setblock 503 94 277 minecraft:cobbled_deepslate
setblock 504 94 276 minecraft:cobbled_deepslate
setblock 504 94 277 minecraft:deepslate_tiles
fill 505 94 276 505 97 276 minecraft:deepslate_tiles
fill 505 94 317 507 94 317 minecraft:cobbled_deepslate
fill 506 94 299 506 99 299 minecraft:bone_block
setblock 507 94 278 minecraft:cobbled_deepslate
setblock 508 94 277 minecraft:cobbled_deepslate
fill 508 94 278 508 96 278 minecraft:deepslate_tiles
setblock 509 94 276 minecraft:cobbled_deepslate
fill 509 94 277 509 97 277 minecraft:deepslate_tiles
setblock 509 94 281 minecraft:cobbled_deepslate
fill 509 94 282 509 97 282 minecraft:deepslate_tiles
fill 509 94 284 510 94 284 minecraft:deepslate_tiles
setblock 509 94 316 minecraft:cobbled_deepslate
fill 510 94 276 510 97 276 minecraft:deepslate_tiles
setblock 510 94 280 minecraft:cobbled_deepslate
fill 510 94 281 510 97 281 minecraft:deepslate_tiles
setblock 510 94 285 minecraft:cobbled_deepslate
fill 510 94 286 510 97 286 minecraft:deepslate_tiles
setblock 510 94 300 minecraft:cobbled_deepslate
fill 510 94 301 510 96 301 minecraft:deepslate_tiles
fill 510 94 303 510 94 304 minecraft:deepslate_tiles
setblock 510 94 305 minecraft:cobbled_deepslate
fill 510 94 306 510 96 307 minecraft:deepslate_tiles
setblock 510 94 315 minecraft:cobbled_deepslate
fill 510 94 316 510 97 316 minecraft:deepslate_tiles
setblock 511 94 279 minecraft:cobbled_deepslate
fill 511 94 280 511 97 280 minecraft:deepslate_tiles
setblock 511 94 284 minecraft:cobbled_deepslate
fill 511 94 285 511 97 285 minecraft:deepslate_tiles
setblock 511 94 289 minecraft:cobbled_deepslate
setblock 511 94 295 minecraft:deepslate_tiles
setblock 511 94 299 minecraft:cobbled_deepslate
fill 511 94 300 511 97 300 minecraft:deepslate_tiles
setblock 511 94 303 minecraft:deepslate_tiles
setblock 511 94 304 minecraft:cobbled_deepslate
fill 511 94 305 511 97 305 minecraft:deepslate_tiles
setblock 511 94 309 minecraft:cobbled_deepslate
fill 511 94 310 511 97 310 minecraft:deepslate_tiles
setblock 511 94 314 minecraft:cobbled_deepslate
fill 511 94 315 511 97 315 minecraft:deepslate_tiles
setblock 512 94 285 minecraft:cobbled_deepslate
fill 512 94 288 512 95 288 minecraft:cobbled_deepslate
setblock 512 94 290 minecraft:cobbled_deepslate
setblock 512 94 298 minecraft:cobbled_deepslate
setblock 512 94 306 minecraft:cobbled_deepslate
setblock 512 94 310 minecraft:cobbled_deepslate
setblock 512 94 315 minecraft:cobbled_deepslate
fill 470 95 276 470 110 283 minecraft:black_concrete
setblock 470 95 284 minecraft:cobbled_deepslate
fill 470 95 285 470 95 291 minecraft:black_concrete
setblock 470 95 292 minecraft:cobbled_deepslate
fill 470 95 293 470 201 293 minecraft:black_concrete
setblock 470 95 294 minecraft:cobbled_deepslate
fill 470 95 295 470 95 303 minecraft:black_concrete
fill 470 95 305 470 95 307 minecraft:black_concrete
fill 470 95 308 471 95 308 minecraft:cobbled_deepslate
fill 470 95 309 470 96 317 minecraft:black_concrete
fill 471 95 275 472 197 275 minecraft:black_concrete
setblock 471 95 278 minecraft:cobbled_deepslate
fill 471 95 279 471 98 279 minecraft:deepslate_tiles
setblock 471 95 283 minecraft:cobbled_deepslate
fill 471 95 284 471 98 284 minecraft:deepslate_tiles
setblock 471 95 298 minecraft:cobbled_deepslate
fill 471 95 299 471 95 302 minecraft:deepslate_tiles
setblock 471 95 303 minecraft:cobbled_deepslate
fill 471 95 304 471 98 304 minecraft:deepslate_tiles
fill 471 95 309 471 98 309 minecraft:deepslate_tiles
setblock 471 95 313 minecraft:cobbled_deepslate
fill 471 95 314 471 98 314 minecraft:deepslate_tiles
fill 471 95 317 477 95 317 minecraft:black_concrete
setblock 472 95 277 minecraft:cobbled_deepslate
fill 472 95 278 472 96 278 minecraft:deepslate_tiles
setblock 472 95 282 minecraft:cobbled_deepslate
fill 472 95 283 472 97 283 minecraft:deepslate_tiles
setblock 472 95 297 minecraft:cobbled_deepslate
fill 472 95 298 472 95 301 minecraft:deepslate_tiles
setblock 472 95 302 minecraft:cobbled_deepslate
fill 472 95 303 472 98 303 minecraft:deepslate_tiles
setblock 472 95 307 minecraft:cobbled_deepslate
fill 472 95 308 472 98 308 minecraft:deepslate_tiles
setblock 472 95 312 minecraft:cobbled_deepslate
fill 472 95 313 472 98 313 minecraft:deepslate_tiles
setblock 473 95 276 minecraft:cobbled_deepslate
setblock 473 95 277 minecraft:deepslate_tiles
setblock 473 95 301 minecraft:cobbled_deepslate
fill 473 95 302 473 98 302 minecraft:deepslate_tiles
setblock 473 95 306 minecraft:cobbled_deepslate
fill 473 95 307 473 98 307 minecraft:deepslate_tiles
setblock 473 95 316 minecraft:cobbled_deepslate
fill 474 95 275 478 95 275 minecraft:black_concrete
fill 474 95 276 474 96 276 minecraft:deepslate_tiles
setblock 474 95 305 minecraft:cobbled_deepslate
setblock 474 95 315 minecraft:cobbled_deepslate
fill 474 95 316 474 97 316 minecraft:deepslate_tiles
setblock 478 95 317 minecraft:cobbled_deepslate
fill 479 95 317 482 155 317 minecraft:black_concrete
fill 480 95 275 487 95 275 minecraft:black_concrete
fill 484 95 317 510 95 317 minecraft:black_concrete
fill 488 95 275 488 95 276 minecraft:cobbled_deepslate
fill 489 95 275 500 116 275 minecraft:black_concrete
fill 489 95 276 489 97 276 minecraft:deepslate_tiles
setblock 492 95 277 minecraft:cobbled_deepslate
setblock 492 95 278 minecraft:deepslate_tiles
setblock 493 95 276 minecraft:cobbled_deepslate
fill 493 95 277 493 97 277 minecraft:deepslate_tiles
fill 494 95 276 494 98 276 minecraft:deepslate_tiles
setblock 497 95 277 minecraft:cobbled_deepslate
setblock 498 95 276 minecraft:cobbled_deepslate
setblock 498 95 277 minecraft:deepslate_tiles
setblock 499 95 276 minecraft:deepslate_tiles
setblock 503 95 275 minecraft:white_wool
setblock 503 95 276 minecraft:cobbled_deepslate
fill 504 95 276 504 98 276 minecraft:deepslate_tiles
fill 504 95 298 505 98 300 minecraft:bone_block
fill 505 95 275 505 100 275 minecraft:black_concrete
fill 505 95 297 507 98 297 minecraft:bone_block
fill 505 95 301 507 98 301 minecraft:bone_block
fill 506 95 298 508 98 298 minecraft:bone_block
fill 506 95 300 508 98 300 minecraft:bone_block
fill 507 95 275 512 95 275 minecraft:black_concrete
setblock 507 95 277 minecraft:cobbled_deepslate
setblock 507 95 278 minecraft:deepslate_tiles
fill 507 95 299 508 98 299 minecraft:bone_block
setblock 508 95 276 minecraft:cobbled_deepslate
fill 508 95 277 508 98 277 minecraft:deepslate_tiles
setblock 508 95 316 minecraft:cobbled_deepslate
fill 509 95 276 509 98 276 minecraft:deepslate_tiles
setblock 509 95 280 minecraft:cobbled_deepslate
fill 509 95 281 509 98 281 minecraft:deepslate_tiles
setblock 509 95 284 minecraft:deepslate_tiles
fill 509 95 316 509 98 316 minecraft:deepslate_tiles
setblock 510 95 279 minecraft:cobbled_deepslate
fill 510 95 280 510 98 280 minecraft:deepslate_tiles
setblock 510 95 284 minecraft:cobbled_deepslate
fill 510 95 285 510 98 285 minecraft:deepslate_tiles
setblock 510 95 300 minecraft:deepslate_tiles
setblock 510 95 303 minecraft:deepslate_tiles
setblock 510 95 304 minecraft:cobbled_deepslate
fill 510 95 305 510 98 305 minecraft:deepslate_tiles
setblock 510 95 308 minecraft:deepslate_tiles
setblock 510 95 309 minecraft:cobbled_deepslate
setblock 510 95 315 minecraft:deepslate_tiles
setblock 511 95 278 minecraft:cobbled_deepslate
fill 511 95 279 511 98 279 minecraft:deepslate_tiles
setblock 511 95 283 minecraft:cobbled_deepslate
fill 511 95 284 511 98 284 minecraft:deepslate_tiles
setblock 511 95 288 minecraft:cobbled_deepslate
fill 511 95 289 511 98 289 minecraft:deepslate_tiles
setblock 511 95 298 minecraft:cobbled_deepslate
fill 511 95 299 511 98 299 minecraft:deepslate_tiles
setblock 511 95 303 minecraft:cobbled_deepslate
fill 511 95 304 511 98 304 minecraft:deepslate_tiles
setblock 511 95 308 minecraft:cobbled_deepslate
fill 511 95 309 511 98 309 minecraft:deepslate_tiles
fill 511 95 313 512 95 313 minecraft:cobbled_deepslate
fill 511 95 314 511 98 314 minecraft:deepslate_tiles
fill 512 95 276 512 150 277 minecraft:black_concrete
fill 512 95 280 512 95 281 minecraft:black_concrete
fill 512 95 283 512 103 287 minecraft:black_concrete
fill 512 95 289 512 95 299 minecraft:black_concrete
setblock 512 95 300 minecraft:cobbled_deepslate
fill 512 95 301 512 95 302 minecraft:black_concrete
fill 512 95 304 512 96 304 minecraft:black_concrete
fill 512 95 306 512 95 309 minecraft:black_concrete
setblock 512 95 310 minecraft:white_wool
fill 512 95 311 512 199 311 minecraft:black_concrete
fill 512 95 314 512 198 317 minecraft:black_concrete
fill 470 96 275 470 201 275 minecraft:black_concrete
fill 470 96 284 470 137 289 minecraft:black_concrete
fill 470 96 290 470 97 290 minecraft:cobbled_deepslate
fill 470 96 291 470 201 292 minecraft:black_concrete
fill 470 96 294 470 198 297 minecraft:black_concrete
setblock 470 96 298 minecraft:cobbled_deepslate
fill 470 96 299 470 96 301 minecraft:black_concrete
fill 470 96 302 471 96 302 minecraft:cobbled_deepslate
fill 470 96 303 470 115 305 minecraft:black_concrete
setblock 470 96 306 minecraft:cobbled_deepslate
fill 470 96 307 470 102 308 minecraft:black_concrete
setblock 471 96 277 minecraft:cobbled_deepslate
fill 471 96 278 471 99 278 minecraft:deepslate_tiles
setblock 471 96 282 minecraft:cobbled_deepslate
fill 471 96 283 471 99 283 minecraft:deepslate_tiles
setblock 471 96 287 minecraft:cobbled_deepslate
fill 471 96 288 471 99 288 minecraft:deepslate_tiles
setblock 471 96 297 minecraft:cobbled_deepslate
fill 471 96 298 471 96 301 minecraft:deepslate_tiles
fill 471 96 303 471 99 303 minecraft:deepslate_tiles
setblock 471 96 307 minecraft:cobbled_deepslate
fill 471 96 308 471 98 308 minecraft:deepslate_tiles
setblock 471 96 312 minecraft:cobbled_deepslate
fill 471 96 313 471 99 313 minecraft:deepslate_tiles
fill 471 96 317 473 111 317 minecraft:black_concrete
setblock 472 96 276 minecraft:cobbled_deepslate
setblock 472 96 277 minecraft:deepslate_tiles
setblock 472 96 281 minecraft:cobbled_deepslate
fill 472 96 282 472 97 282 minecraft:deepslate_tiles
fill 472 96 298 472 96 300 minecraft:deepslate_tiles
setblock 472 96 301 minecraft:cobbled_deepslate
fill 472 96 302 472 99 302 minecraft:deepslate_tiles
setblock 472 96 306 minecraft:cobbled_deepslate
fill 472 96 307 472 99 307 minecraft:deepslate_tiles
setblock 472 96 311 minecraft:cobbled_deepslate
fill 472 96 312 472 99 312 minecraft:deepslate_tiles
setblock 472 96 316 minecraft:cobbled_deepslate
fill 473 96 275 473 199 275 minecraft:black_concrete
fill 473 96 276 473 97 276 minecraft:deepslate_tiles
setblock 473 96 300 minecraft:cobbled_deepslate
fill 473 96 301 473 97 301 minecraft:deepslate_tiles
setblock 473 96 305 minecraft:cobbled_deepslate
fill 473 96 306 473 99 306 minecraft:deepslate_tiles
fill 473 96 312 473 98 312 minecraft:white_wool
fill 473 96 316 473 98 316 minecraft:deepslate_tiles
setblock 474 96 275 minecraft:cobbled_deepslate
fill 474 96 317 475 96 317 minecraft:cobbled_deepslate
fill 475 96 275 481 106 275 minecraft:black_concrete
fill 476 96 317 476 160 317 minecraft:black_concrete
setblock 477 96 317 minecraft:cobbled_deepslate
fill 478 96 317 478 175 317 minecraft:black_concrete
setblock 482 96 275 minecraft:cobbled_deepslate
fill 483 96 275 488 126 275 minecraft:black_concrete
fill 483 96 317 492 96 317 minecraft:black_concrete
setblock 491 96 277 minecraft:cobbled_deepslate
setblock 492 96 276 minecraft:cobbled_deepslate
fill 492 96 277 492 97 277 minecraft:deepslate_tiles
fill 493 96 276 493 99 276 minecraft:deepslate_tiles
setblock 493 96 317 minecraft:cobbled_deepslate
fill 494 96 317 497 101 317 minecraft:black_concrete
setblock 497 96 276 minecraft:cobbled_deepslate
setblock 498 96 276 minecraft:deepslate_tiles
fill 498 96 317 499 96 317 minecraft:cobbled_deepslate
fill 500 96 317 502 118 317 minecraft:black_concrete
fill 501 96 275 504 134 275 minecraft:black_concrete
setblock 503 96 276 minecraft:deepslate_tiles
setblock 503 96 317 minecraft:cobbled_deepslate
fill 504 96 317 504 201 317 minecraft:black_concrete
setblock 505 96 317 minecraft:cobbled_deepslate
fill 506 96 275 506 181 275 minecraft:black_concrete
setblock 506 96 277 minecraft:cobbled_deepslate
fill 506 96 317 511 115 317 minecraft:black_concrete
fill 507 96 275 507 96 276 minecraft:cobbled_deepslate
fill 507 96 277 507 99 277 minecraft:deepslate_tiles
fill 508 96 275 512 96 275 minecraft:black_concrete
fill 508 96 276 508 99 276 minecraft:deepslate_tiles
fill 508 96 316 508 99 316 minecraft:deepslate_tiles
setblock 509 96 279 minecraft:cobbled_deepslate
fill 509 96 280 509 98 280 minecraft:deepslate_tiles
setblock 509 96 284 minecraft:cobbled_deepslate
setblock 510 96 278 minecraft:cobbled_deepslate
fill 510 96 279 510 99 279 minecraft:deepslate_tiles
setblock 510 96 283 minecraft:cobbled_deepslate
fill 510 96 284 510 99 284 minecraft:deepslate_tiles
setblock 510 96 303 minecraft:cobbled_deepslate
fill 510 96 304 510 99 304 minecraft:deepslate_tiles
setblock 510 96 308 minecraft:cobbled_deepslate
fill 510 96 309 510 98 310 minecraft:deepslate_tiles
setblock 511 96 277 minecraft:cobbled_deepslate
fill 511 96 278 511 99 278 minecraft:deepslate_tiles
setblock 511 96 282 minecraft:cobbled_deepslate
fill 511 96 283 511 99 283 minecraft:deepslate_tiles
setblock 511 96 287 minecraft:cobbled_deepslate
fill 511 96 288 511 99 288 minecraft:deepslate_tiles
setblock 511 96 298 minecraft:deepslate_tiles
setblock 511 96 302 minecraft:cobbled_deepslate
fill 511 96 303 511 99 303 minecraft:deepslate_tiles
setblock 511 96 307 minecraft:cobbled_deepslate
fill 511 96 308 511 99 308 minecraft:deepslate_tiles
setblock 511 96 312 minecraft:cobbled_deepslate
fill 511 96 313 511 99 313 minecraft:deepslate_tiles
fill 512 96 278 512 201 279 minecraft:black_concrete
setblock 512 96 280 minecraft:cobbled_deepslate
fill 512 96 281 512 201 282 minecraft:black_concrete
fill 512 96 288 512 96 289 minecraft:black_concrete
setblock 512 96 290 minecraft:cobbled_deepslate
fill 512 96 291 512 150 300 minecraft:black_concrete
setblock 512 96 301 minecraft:cobbled_deepslate
fill 512 96 302 512 184 303 minecraft:black_concrete
fill 512 96 305 512 99 308 minecraft:black_concrete
setblock 512 96 309 minecraft:cobbled_deepslate
fill 512 96 310 512 198 310 minecraft:black_concrete
fill 512 96 312 512 176 313 minecraft:black_concrete
fill 470 97 298 470 201 298 minecraft:black_concrete
setblock 470 97 299 minecraft:cobbled_deepslate
fill 470 97 300 470 201 300 minecraft:black_concrete
fill 470 97 301 470 97 302 minecraft:cobbled_deepslate
fill 470 97 306 470 197 306 minecraft:black_concrete
fill 470 97 309 470 171 309 minecraft:black_concrete
setblock 470 97 310 minecraft:cobbled_deepslate
fill 470 97 311 470 178 311 minecraft:black_concrete
fill 470 97 312 470 97 313 minecraft:cobbled_deepslate
fill 470 97 314 470 140 316 minecraft:black_concrete
setblock 470 97 317 minecraft:cobbled_deepslate
setblock 471 97 276 minecraft:cobbled_deepslate
fill 471 97 277 471 99 277 minecraft:deepslate_tiles
setblock 471 97 281 minecraft:cobbled_deepslate
fill 471 97 282 471 100 282 minecraft:deepslate_tiles
setblock 471 97 286 minecraft:cobbled_deepslate
fill 471 97 287 471 100 287 minecraft:deepslate_tiles
setblock 471 97 296 minecraft:cobbled_deepslate
fill 471 97 297 471 97 300 minecraft:deepslate_tiles
setblock 471 97 301 minecraft:cobbled_deepslate
fill 471 97 302 471 100 302 minecraft:deepslate_tiles
setblock 471 97 306 minecraft:cobbled_deepslate
fill 471 97 307 471 100 307 minecraft:deepslate_tiles
setblock 471 97 311 minecraft:cobbled_deepslate
fill 471 97 312 471 100 312 minecraft:deepslate_tiles
setblock 471 97 316 minecraft:cobbled_deepslate
setblock 472 97 276 minecraft:deepslate_tiles
setblock 472 97 280 minecraft:cobbled_deepslate
setblock 472 97 281 minecraft:deepslate_tiles
setblock 472 97 299 minecraft:deepslate_tiles
setblock 472 97 300 minecraft:cobbled_deepslate
fill 472 97 301 472 100 301 minecraft:deepslate_tiles
setblock 472 97 305 minecraft:cobbled_deepslate
fill 472 97 306 472 100 306 minecraft:deepslate_tiles
setblock 472 97 310 minecraft:cobbled_deepslate
fill 472 97 311 472 100 311 minecraft:deepslate_tiles
fill 472 97 316 472 100 316 minecraft:deepslate_tiles
setblock 473 97 278 minecraft:light[level=12]
setblock 473 97 285 minecraft:light[level=12]
setblock 473 97 292 minecraft:light[level=12]
setblock 473 97 299 minecraft:light[level=12]
setblock 473 97 304 minecraft:cobbled_deepslate
fill 473 97 305 473 100 305 minecraft:deepslate_tiles
setblock 473 97 309 minecraft:cobbled_deepslate
setblock 473 97 313 minecraft:light[level=12]
fill 474 97 275 474 101 275 minecraft:black_concrete
fill 474 97 296 474 98 296 minecraft:black_concrete
setblock 474 97 317 minecraft:cobbled_deepslate
fill 475 97 317 475 201 317 minecraft:black_concrete
fill 477 97 317 477 199 317 minecraft:black_concrete
setblock 480 97 278 minecraft:light[level=12]
setblock 480 97 285 minecraft:light[level=12]
setblock 480 97 292 minecraft:light[level=12]
setblock 480 97 299 minecraft:light[level=12]
setblock 480 97 306 minecraft:light[level=12]
setblock 480 97 313 minecraft:light[level=12]
fill 482 97 275 482 142 275 minecraft:black_concrete
fill 483 97 317 491 100 317 minecraft:black_concrete
setblock 487 97 278 minecraft:light[level=12]
setblock 487 97 285 minecraft:light[level=12]
setblock 487 97 292 minecraft:light[level=12]
setblock 487 97 299 minecraft:light[level=12]
setblock 487 97 306 minecraft:light[level=12]
setblock 487 97 313 minecraft:light[level=12]
setblock 491 97 276 minecraft:cobbled_deepslate
fill 492 97 276 492 100 276 minecraft:deepslate_tiles
setblock 492 97 317 minecraft:cobbled_deepslate
fill 493 97 317 493 197 317 minecraft:black_concrete
setblock 494 97 278 minecraft:light[level=12]
setblock 494 97 285 minecraft:light[level=12]
setblock 494 97 292 minecraft:light[level=12]
setblock 494 97 299 minecraft:light[level=12]
setblock 494 97 306 minecraft:light[level=12]
setblock 494 97 313 minecraft:light[level=12]
setblock 496 97 276 minecraft:cobbled_deepslate
fill 498 97 317 499 122 317 minecraft:black_concrete
setblock 501 97 278 minecraft:light[level=12]
setblock 501 97 285 minecraft:light[level=12]
setblock 501 97 292 minecraft:light[level=12]
setblock 501 97 299 minecraft:light[level=12]
setblock 501 97 306 minecraft:light[level=12]
setblock 501 97 313 minecraft:light[level=12]
fill 503 97 317 503 201 317 minecraft:black_concrete
fill 505 97 317 505 184 317 minecraft:black_concrete
setblock 506 97 276 minecraft:cobbled_deepslate
setblock 506 97 277 minecraft:deepslate_tiles
fill 507 97 275 509 114 275 minecraft:black_concrete
fill 507 97 276 507 100 276 minecraft:deepslate_tiles
fill 507 97 316 507 100 316 minecraft:deepslate_tiles
setblock 508 97 278 minecraft:light[level=12]
setblock 508 97 285 minecraft:light[level=12]
setblock 508 97 292 minecraft:light[level=12]
setblock 508 97 306 minecraft:light[level=12]
setblock 508 97 313 minecraft:light[level=12]
setblock 509 97 278 minecraft:cobbled_deepslate
setblock 509 97 279 minecraft:deepslate_tiles
setblock 509 97 283 minecraft:cobbled_deepslate
fill 509 97 284 509 100 284 minecraft:deepslate_tiles
fill 510 97 275 511 97 275 minecraft:cobbled_deepslate
setblock 510 97 277 minecraft:cobbled_deepslate
fill 510 97 278 510 100 278 minecraft:deepslate_tiles
setblock 510 97 282 minecraft:cobbled_deepslate
fill 510 97 283 510 100 283 minecraft:deepslate_tiles
setblock 510 97 302 minecraft:cobbled_deepslate
fill 510 97 303 510 100 303 minecraft:deepslate_tiles
setblock 510 97 306 minecraft:deepslate_tiles
setblock 510 97 307 minecraft:cobbled_deepslate
fill 510 97 308 510 98 308 minecraft:deepslate_tiles
setblock 510 97 311 minecraft:deepslate_tiles
setblock 510 97 312 minecraft:cobbled_deepslate
setblock 511 97 276 minecraft:cobbled_deepslate
fill 511 97 277 511 100 277 minecraft:deepslate_tiles
setblock 511 97 281 minecraft:cobbled_deepslate
fill 511 97 282 511 100 282 minecraft:deepslate_tiles
setblock 511 97 286 minecraft:cobbled_deepslate
fill 511 97 287 511 100 287 minecraft:deepslate_tiles
setblock 511 97 301 minecraft:cobbled_deepslate
fill 511 97 302 511 100 302 minecraft:deepslate_tiles
setblock 511 97 306 minecraft:cobbled_deepslate
fill 511 97 307 511 100 307 minecraft:deepslate_tiles
setblock 511 97 311 minecraft:cobbled_deepslate
fill 511 97 312 511 100 312 minecraft:deepslate_tiles
setblock 511 97 316 minecraft:cobbled_deepslate
fill 512 97 275 512 197 275 minecraft:black_concrete
fill 512 97 280 512 161 280 minecraft:black_concrete
setblock 512 97 288 minecraft:cobbled_deepslate
fill 512 97 289 512 146 290 minecraft:black_concrete
fill 512 97 301 512 197 301 minecraft:black_concrete
setblock 512 97 304 minecraft:cobbled_deepslate
fill 512 97 309 512 199 309 minecraft:black_concrete
fill 470 98 290 470 201 290 minecraft:black_concrete
fill 470 98 299 470 116 299 minecraft:black_concrete
fill 470 98 301 470 168 301 minecraft:black_concrete
setblock 470 98 302 minecraft:white_wool
fill 470 98 310 470 202 310 minecraft:black_concrete
fill 470 98 312 470 132 313 minecraft:black_concrete
fill 470 98 317 470 202 317 minecraft:black_concrete
setblock 471 98 276 minecraft:deepslate_tiles
setblock 471 98 280 minecraft:cobbled_deepslate
fill 471 98 281 471 101 281 minecraft:deepslate_tiles
setblock 471 98 285 minecraft:cobbled_deepslate
fill 471 98 286 471 101 286 minecraft:deepslate_tiles
setblock 471 98 289 minecraft:deepslate_tiles
fill 471 98 297 471 98 299 minecraft:deepslate_tiles
setblock 471 98 300 minecraft:cobbled_deepslate
fill 471 98 301 471 101 301 minecraft:deepslate_tiles
setblock 471 98 305 minecraft:cobbled_deepslate
fill 471 98 306 471 101 306 minecraft:deepslate_tiles
setblock 471 98 310 minecraft:cobbled_deepslate
fill 471 98 311 471 101 311 minecraft:deepslate_tiles
setblock 471 98 315 minecraft:cobbled_deepslate
fill 471 98 316 471 101 316 minecraft:deepslate_tiles
setblock 472 98 299 minecraft:cobbled_deepslate
fill 472 98 300 472 101 300 minecraft:deepslate_tiles
setblock 472 98 304 minecraft:cobbled_deepslate
fill 472 98 305 472 101 305 minecraft:deepslate_tiles
setblock 472 98 309 minecraft:cobbled_deepslate
fill 472 98 310 472 101 310 minecraft:deepslate_tiles
setblock 473 98 303 minecraft:cobbled_deepslate
fill 473 98 304 473 101 304 minecraft:deepslate_tiles
setblock 473 98 308 minecraft:cobbled_deepslate
fill 473 98 309 473 101 309 minecraft:deepslate_tiles
fill 474 98 317 474 201 317 minecraft:black_concrete
setblock 475 98 312 minecraft:white_wool
setblock 476 98 313 minecraft:white_wool
setblock 477 98 314 minecraft:white_wool
setblock 478 98 315 minecraft:white_wool
setblock 490 98 276 minecraft:cobbled_deepslate
fill 491 98 276 491 101 276 minecraft:deepslate_tiles
fill 492 98 317 492 201 317 minecraft:black_concrete
setblock 503 98 315 minecraft:white_wool
setblock 504 98 314 minecraft:white_wool
setblock 505 98 276 minecraft:cobbled_deepslate
setblock 505 98 313 minecraft:white_wool
fill 506 98 276 506 101 276 minecraft:deepslate_tiles
setblock 506 98 312 minecraft:white_wool
fill 508 98 304 509 99 304 minecraft:cobbled_deepslate
setblock 509 98 277 minecraft:cobbled_deepslate
setblock 509 98 282 minecraft:cobbled_deepslate
fill 509 98 283 509 101 283 minecraft:deepslate_tiles
fill 510 98 275 511 184 275 minecraft:black_concrete
setblock 510 98 276 minecraft:cobbled_deepslate
fill 510 98 277 510 101 277 minecraft:deepslate_tiles
setblock 510 98 281 minecraft:cobbled_deepslate
fill 510 98 282 510 101 282 minecraft:deepslate_tiles
setblock 510 98 286 minecraft:cobbled_deepslate
fill 510 98 287 510 101 287 minecraft:deepslate_tiles
fill 510 98 302 510 101 302 minecraft:deepslate_tiles
setblock 510 98 306 minecraft:cobbled_deepslate
fill 510 98 307 510 101 307 minecraft:deepslate_tiles
setblock 510 98 311 minecraft:cobbled_deepslate
fill 510 98 312 510 98 315 minecraft:deepslate_tiles
setblock 510 98 316 minecraft:cobbled_deepslate
fill 511 98 276 511 101 276 minecraft:deepslate_tiles
setblock 511 98 280 minecraft:cobbled_deepslate
fill 511 98 281 511 101 281 minecraft:deepslate_tiles
setblock 511 98 285 minecraft:cobbled_deepslate
fill 511 98 286 511 101 286 minecraft:deepslate_tiles
setblock 511 98 300 minecraft:cobbled_deepslate
fill 511 98 301 511 101 301 minecraft:deepslate_tiles
setblock 511 98 305 minecraft:cobbled_deepslate
fill 511 98 306 511 101 306 minecraft:deepslate_tiles
setblock 511 98 310 minecraft:cobbled_deepslate
fill 511 98 311 511 101 311 minecraft:deepslate_tiles
setblock 511 98 315 minecraft:cobbled_deepslate
fill 511 98 316 511 101 316 minecraft:deepslate_tiles
fill 512 98 288 512 199 288 minecraft:black_concrete
fill 512 98 304 512 201 304 minecraft:black_concrete
fill 470 99 302 470 199 302 minecraft:black_concrete
setblock 471 99 279 minecraft:cobbled_deepslate
fill 471 99 280 471 102 280 minecraft:deepslate_tiles
setblock 471 99 284 minecraft:cobbled_deepslate
fill 471 99 285 471 102 285 minecraft:deepslate_tiles
setblock 471 99 289 minecraft:cobbled_deepslate
fill 471 99 290 471 102 290 minecraft:deepslate_tiles
fill 471 99 292 483 99 292 minecraft:cobbled_deepslate
fill 471 99 296 510 99 296 minecraft:cobbled_deepslate
fill 471 99 297 471 99 298 minecraft:deepslate_tiles
setblock 471 99 299 minecraft:cobbled_deepslate
fill 471 99 300 471 102 300 minecraft:deepslate_tiles
setblock 471 99 304 minecraft:cobbled_deepslate
fill 471 99 305 471 102 305 minecraft:deepslate_tiles
setblock 471 99 308 minecraft:white_wool
setblock 471 99 309 minecraft:cobbled_deepslate
fill 471 99 310 471 102 310 minecraft:deepslate_tiles
setblock 471 99 314 minecraft:cobbled_deepslate
fill 471 99 315 471 102 315 minecraft:deepslate_tiles
fill 472 99 280 510 99 280 minecraft:cobbled_deepslate
fill 472 99 288 473 100 288 minecraft:cobbled_deepslate
setblock 472 99 303 minecraft:cobbled_deepslate
fill 472 99 304 472 102 304 minecraft:deepslate_tiles
setblock 472 99 308 minecraft:cobbled_deepslate
setblock 472 99 309 minecraft:white_wool
setblock 472 99 313 minecraft:cobbled_deepslate
fill 473 99 300 473 100 300 minecraft:cobbled_deepslate
setblock 473 99 302 minecraft:cobbled_deepslate
fill 473 99 303 473 101 303 minecraft:deepslate_tiles
setblock 473 99 307 minecraft:cobbled_deepslate
fill 473 99 308 473 102 308 minecraft:deepslate_tiles
setblock 473 99 310 minecraft:white_wool
fill 473 99 312 509 99 312 minecraft:cobbled_deepslate
fill 474 99 304 507 99 304 minecraft:cobbled_deepslate
fill 474 99 308 508 99 308 minecraft:cobbled_deepslate
setblock 474 99 311 minecraft:white_wool
fill 490 99 276 490 102 276 minecraft:deepslate_tiles
setblock 504 99 276 minecraft:cobbled_deepslate
fill 505 99 276 505 102 276 minecraft:deepslate_tiles
fill 506 99 316 506 101 316 minecraft:deepslate_tiles
setblock 507 99 311 minecraft:white_wool
setblock 508 99 277 minecraft:cobbled_deepslate
setblock 508 99 310 minecraft:white_wool
setblock 509 99 276 minecraft:cobbled_deepslate
fill 509 99 277 509 102 277 minecraft:deepslate_tiles
setblock 509 99 281 minecraft:cobbled_deepslate
fill 509 99 282 509 102 282 minecraft:deepslate_tiles
setblock 509 99 306 minecraft:cobbled_deepslate
fill 509 99 307 509 101 308 minecraft:deepslate_tiles
setblock 509 99 309 minecraft:white_wool
setblock 509 99 315 minecraft:deepslate_tiles
setblock 509 99 316 minecraft:cobbled_deepslate
fill 510 99 276 510 102 276 minecraft:deepslate_tiles
fill 510 99 281 510 102 281 minecraft:deepslate_tiles
setblock 510 99 285 minecraft:cobbled_deepslate
fill 510 99 286 510 102 286 minecraft:deepslate_tiles
setblock 510 99 305 minecraft:cobbled_deepslate
fill 510 99 306 510 102 306 minecraft:deepslate_tiles
setblock 510 99 308 minecraft:white_wool
setblock 510 99 309 minecraft:deepslate_tiles
setblock 510 99 310 minecraft:cobbled_deepslate
fill 510 99 311 510 99 314 minecraft:deepslate_tiles
setblock 510 99 315 minecraft:cobbled_deepslate
fill 510 99 316 510 102 316 minecraft:deepslate_tiles
setblock 511 99 279 minecraft:cobbled_deepslate
fill 511 99 280 511 102 280 minecraft:deepslate_tiles
setblock 511 99 284 minecraft:cobbled_deepslate
fill 511 99 285 511 102 285 minecraft:deepslate_tiles
setblock 511 99 289 minecraft:cobbled_deepslate
fill 511 99 300 511 102 300 minecraft:deepslate_tiles
setblock 511 99 304 minecraft:cobbled_deepslate
fill 511 99 305 511 102 305 minecraft:deepslate_tiles
setblock 511 99 309 minecraft:cobbled_deepslate
fill 511 99 310 511 102 310 minecraft:deepslate_tiles
setblock 511 99 314 minecraft:cobbled_deepslate
fill 511 99 315 511 102 315 minecraft:deepslate_tiles
setblock 471 100 279 minecraft:deepslate_tiles
setblock 471 100 283 minecraft:cobbled_deepslate
fill 471 100 284 471 103 284 minecraft:deepslate_tiles
setblock 471 100 288 minecraft:cobbled_deepslate
fill 471 100 289 471 103 289 minecraft:deepslate_tiles
fill 471 100 291 471 100 292 minecraft:deepslate_tiles
fill 471 100 296 471 100 297 minecraft:deepslate_tiles
setblock 471 100 298 minecraft:cobbled_deepslate
fill 471 100 299 471 103 299 minecraft:deepslate_tiles
setblock 471 100 303 minecraft:cobbled_deepslate
fill 471 100 304 471 103 304 minecraft:deepslate_tiles
setblock 471 100 308 minecraft:cobbled_deepslate
fill 471 100 309 472 102 309 minecraft:deepslate_tiles
setblock 471 100 313 minecraft:cobbled_deepslate
fill 471 100 314 471 103 314 minecraft:deepslate_tiles
fill 472 100 280 489 100 280 minecraft:cobbled_deepslate
fill 472 100 284 500 100 284 minecraft:cobbled_deepslate
fill 472 100 292 485 100 292 minecraft:cobbled_deepslate
fill 472 100 296 473 100 296 minecraft:cobbled_deepslate
setblock 472 100 302 minecraft:cobbled_deepslate
fill 472 100 303 472 103 303 minecraft:deepslate_tiles
setblock 472 100 307 minecraft:cobbled_deepslate
fill 472 100 308 472 103 308 minecraft:deepslate_tiles
setblock 472 100 312 minecraft:cobbled_deepslate
fill 472 100 313 472 103 313 minecraft:deepslate_tiles
setblock 473 100 306 minecraft:cobbled_deepslate
fill 473 100 307 473 103 307 minecraft:deepslate_tiles
setblock 473 100 310 minecraft:deepslate_tiles
fill 473 100 312 473 113 312 minecraft:white_wool
fill 474 100 288 509 100 288 minecraft:cobbled_deepslate
fill 474 100 295 474 101 297 minecraft:black_concrete
fill 474 100 300 510 100 300 minecraft:cobbled_deepslate
fill 474 100 308 483 100 308 minecraft:cobbled_deepslate
setblock 475 100 296 minecraft:black_concrete
fill 489 100 276 489 103 276 minecraft:deepslate_tiles
setblock 493 100 276 minecraft:cobbled_deepslate
fill 494 100 292 510 100 292 minecraft:cobbled_deepslate
fill 504 100 276 504 103 276 minecraft:deepslate_tiles
fill 505 100 316 505 102 316 minecraft:deepslate_tiles
setblock 506 100 277 minecraft:deepslate_tiles
setblock 507 100 277 minecraft:cobbled_deepslate
setblock 508 100 276 minecraft:cobbled_deepslate
fill 508 100 277 508 103 277 minecraft:deepslate_tiles
setblock 508 100 315 minecraft:deepslate_tiles
setblock 508 100 316 minecraft:cobbled_deepslate
fill 509 100 276 509 103 276 minecraft:deepslate_tiles
setblock 509 100 281 minecraft:deepslate_tiles
setblock 509 100 285 minecraft:cobbled_deepslate
setblock 509 100 305 minecraft:cobbled_deepslate
fill 509 100 306 509 103 306 minecraft:deepslate_tiles
setblock 509 100 309 minecraft:deepslate_tiles
setblock 509 100 310 minecraft:cobbled_deepslate
fill 509 100 311 510 102 311 minecraft:deepslate_tiles
setblock 509 100 315 minecraft:cobbled_deepslate
fill 509 100 316 509 103 316 minecraft:deepslate_tiles
setblock 510 100 279 minecraft:cobbled_deepslate
fill 510 100 280 510 103 280 minecraft:deepslate_tiles
setblock 510 100 284 minecraft:cobbled_deepslate
fill 510 100 285 510 103 285 minecraft:deepslate_tiles
setblock 510 100 288 minecraft:deepslate_tiles
setblock 510 100 304 minecraft:cobbled_deepslate
fill 510 100 305 510 103 305 minecraft:deepslate_tiles
setblock 510 100 308 minecraft:deepslate_tiles
setblock 510 100 309 minecraft:cobbled_deepslate
fill 510 100 310 510 103 310 minecraft:deepslate_tiles
fill 510 100 312 510 100 313 minecraft:deepslate_tiles
setblock 510 100 314 minecraft:cobbled_deepslate
fill 510 100 315 510 103 315 minecraft:deepslate_tiles
setblock 511 100 278 minecraft:cobbled_deepslate
fill 511 100 279 511 103 279 minecraft:deepslate_tiles
setblock 511 100 283 minecraft:cobbled_deepslate
fill 511 100 284 511 103 284 minecraft:deepslate_tiles
setblock 511 100 288 minecraft:cobbled_deepslate
fill 511 100 289 511 102 290 minecraft:deepslate_tiles
setblock 511 100 303 minecraft:cobbled_deepslate
fill 511 100 304 511 103 304 minecraft:deepslate_tiles
setblock 511 100 308 minecraft:cobbled_deepslate
fill 511 100 309 511 103 309 minecraft:deepslate_tiles
setblock 511 100 313 minecraft:cobbled_deepslate
fill 511 100 314 511 103 314 minecraft:deepslate_tiles
fill 512 100 305 512 201 305 minecraft:black_concrete
setblock 512 100 306 minecraft:redstone_block
fill 512 100 307 512 201 308 minecraft:black_concrete
setblock 471 101 282 minecraft:cobbled_deepslate
fill 471 101 283 471 104 283 minecraft:deepslate_tiles
setblock 471 101 287 minecraft:cobbled_deepslate
fill 471 101 288 471 104 288 minecraft:deepslate_tiles
setblock 471 101 291 minecraft:deepslate_tiles
setblock 471 101 292 minecraft:cobbled_deepslate
fill 471 101 293 471 101 296 minecraft:deepslate_tiles
setblock 471 101 297 minecraft:cobbled_deepslate
fill 471 101 298 471 104 298 minecraft:deepslate_tiles
setblock 471 101 302 minecraft:cobbled_deepslate
fill 471 101 303 471 104 303 minecraft:deepslate_tiles
setblock 471 101 307 minecraft:cobbled_deepslate
fill 471 101 308 471 104 308 minecraft:deepslate_tiles
setblock 471 101 312 minecraft:cobbled_deepslate
fill 471 101 313 471 104 313 minecraft:deepslate_tiles
setblock 472 101 286 minecraft:cobbled_deepslate
fill 472 101 287 472 104 287 minecraft:deepslate_tiles
setblock 472 101 301 minecraft:cobbled_deepslate
fill 472 101 302 472 104 302 minecraft:deepslate_tiles
setblock 472 101 306 minecraft:cobbled_deepslate
fill 472 101 307 472 104 307 minecraft:deepslate_tiles
setblock 472 101 311 minecraft:cobbled_deepslate
fill 472 101 312 472 104 312 minecraft:deepslate_tiles
fill 472 101 314 472 102 314 minecraft:deepslate_tiles
setblock 472 101 316 minecraft:cobbled_deepslate
setblock 473 101 278 minecraft:light[level=13]
setblock 473 101 286 minecraft:light[level=13]
setblock 473 101 294 minecraft:light[level=13]
fill 473 101 295 473 101 297 minecraft:black_concrete
setblock 473 101 302 minecraft:light[level=13]
setblock 473 101 305 minecraft:cobbled_deepslate
fill 473 101 306 473 104 306 minecraft:deepslate_tiles
setblock 473 101 310 minecraft:cobbled_deepslate
fill 475 101 276 475 101 315 minecraft:white_wool
fill 479 101 276 479 101 316 minecraft:white_wool
setblock 481 101 278 minecraft:light[level=13]
setblock 481 101 286 minecraft:light[level=13]
setblock 481 101 294 minecraft:light[level=13]
setblock 481 101 302 minecraft:light[level=13]
setblock 481 101 310 minecraft:light[level=13]
fill 483 101 276 483 102 277 minecraft:white_wool
fill 483 101 317 489 109 317 minecraft:black_concrete
fill 487 101 276 487 101 289 minecraft:white_wool
fill 487 101 295 487 102 304 minecraft:white_wool
fill 488 101 276 488 104 276 minecraft:deepslate_tiles
setblock 489 101 278 minecraft:light[level=13]
setblock 489 101 286 minecraft:light[level=13]
setblock 489 101 294 minecraft:light[level=13]
setblock 489 101 302 minecraft:light[level=13]
setblock 489 101 310 minecraft:light[level=13]
setblock 490 101 317 minecraft:redstone_block
fill 491 101 277 491 102 279 minecraft:white_wool
fill 491 101 317 491 103 317 minecraft:black_concrete
setblock 492 101 276 minecraft:cobbled_deepslate
fill 493 101 276 493 104 276 minecraft:deepslate_tiles
fill 495 101 276 495 102 277 minecraft:white_wool
setblock 497 101 278 minecraft:light[level=13]
setblock 497 101 286 minecraft:light[level=13]
setblock 497 101 294 minecraft:light[level=13]
setblock 497 101 302 minecraft:light[level=13]
setblock 497 101 310 minecraft:light[level=13]
fill 498 101 284 509 101 284 minecraft:cobbled_deepslate
fill 499 101 276 499 102 281 minecraft:white_wool
fill 503 101 276 503 104 276 minecraft:deepslate_tiles
fill 503 101 277 503 102 279 minecraft:white_wool
fill 504 101 316 504 103 316 minecraft:deepslate_tiles
setblock 505 101 275 minecraft:white_wool
setblock 505 101 278 minecraft:light[level=13]
setblock 505 101 286 minecraft:light[level=13]
setblock 505 101 294 minecraft:light[level=13]
setblock 505 101 302 minecraft:light[level=13]
setblock 505 101 310 minecraft:light[level=13]
setblock 506 101 277 minecraft:cobbled_deepslate
fill 506 101 315 507 101 315 minecraft:deepslate_tiles
setblock 507 101 276 minecraft:cobbled_deepslate
fill 507 101 277 507 104 277 minecraft:deepslate_tiles
fill 507 101 278 507 101 283 minecraft:white_wool
fill 507 101 285 507 101 314 minecraft:white_wool
setblock 507 101 316 minecraft:cobbled_deepslate
fill 508 101 276 508 104 276 minecraft:deepslate_tiles
setblock 508 101 315 minecraft:cobbled_deepslate
fill 508 101 316 508 104 316 minecraft:deepslate_tiles
fill 509 101 285 509 103 286 minecraft:deepslate_tiles
fill 509 101 305 509 104 305 minecraft:deepslate_tiles
setblock 509 101 309 minecraft:cobbled_deepslate
fill 509 101 310 509 104 310 minecraft:deepslate_tiles
fill 509 101 312 509 101 313 minecraft:deepslate_tiles
setblock 509 101 314 minecraft:cobbled_deepslate
fill 509 101 315 509 104 315 minecraft:deepslate_tiles
setblock 510 101 278 minecraft:cobbled_deepslate
fill 510 101 279 510 103 279 minecraft:deepslate_tiles
setblock 510 101 283 minecraft:cobbled_deepslate
fill 510 101 284 510 104 284 minecraft:deepslate_tiles
setblock 510 101 288 minecraft:cobbled_deepslate
fill 510 101 289 510 104 289 minecraft:deepslate_tiles
setblock 510 101 303 minecraft:cobbled_deepslate
fill 510 101 304 510 104 304 minecraft:deepslate_tiles
setblock 510 101 308 minecraft:cobbled_deepslate
fill 510 101 309 510 104 309 minecraft:deepslate_tiles
setblock 510 101 312 minecraft:deepslate_tiles
setblock 510 101 313 minecraft:cobbled_deepslate
fill 510 101 314 510 104 314 minecraft:deepslate_tiles
setblock 511 101 277 minecraft:cobbled_deepslate
fill 511 101 278 511 104 278 minecraft:deepslate_tiles
setblock 511 101 282 minecraft:cobbled_deepslate
fill 511 101 283 511 104 283 minecraft:deepslate_tiles
setblock 511 101 287 minecraft:cobbled_deepslate
fill 511 101 288 511 104 288 minecraft:deepslate_tiles
setblock 511 101 291 minecraft:deepslate_tiles
setblock 511 101 302 minecraft:cobbled_deepslate
fill 511 101 303 511 104 303 minecraft:deepslate_tiles
setblock 511 101 307 minecraft:cobbled_deepslate
fill 511 101 308 511 104 308 minecraft:deepslate_tiles
setblock 511 101 312 minecraft:cobbled_deepslate
fill 511 101 313 511 104 313 minecraft:deepslate_tiles
fill 512 101 306 512 131 306 minecraft:black_concrete
setblock 471 102 281 minecraft:cobbled_deepslate
fill 471 102 282 471 104 282 minecraft:deepslate_tiles
setblock 471 102 286 minecraft:cobbled_deepslate
fill 471 102 287 471 105 287 minecraft:deepslate_tiles
setblock 471 102 291 minecraft:cobbled_deepslate
fill 471 102 292 471 102 295 minecraft:deepslate_tiles
setblock 471 102 296 minecraft:cobbled_deepslate
fill 471 102 297 471 105 297 minecraft:deepslate_tiles
setblock 471 102 301 minecraft:cobbled_deepslate
fill 471 102 302 471 105 302 minecraft:deepslate_tiles
setblock 471 102 306 minecraft:cobbled_deepslate
fill 471 102 307 471 105 307 minecraft:deepslate_tiles
setblock 471 102 311 minecraft:cobbled_deepslate
fill 471 102 312 471 105 312 minecraft:deepslate_tiles
setblock 471 102 316 minecraft:cobbled_deepslate
setblock 472 102 285 minecraft:cobbled_deepslate
fill 472 102 286 472 105 286 minecraft:deepslate_tiles
fill 472 102 288 472 102 289 minecraft:deepslate_tiles
setblock 472 102 300 minecraft:cobbled_deepslate
fill 472 102 301 472 104 301 minecraft:deepslate_tiles
setblock 472 102 305 minecraft:cobbled_deepslate
fill 472 102 306 472 105 306 minecraft:deepslate_tiles
setblock 472 102 310 minecraft:cobbled_deepslate
fill 472 102 311 473 104 311 minecraft:deepslate_tiles
fill 472 102 316 473 104 316 minecraft:deepslate_tiles
setblock 473 102 304 minecraft:cobbled_deepslate
fill 473 102 305 473 104 305 minecraft:deepslate_tiles
setblock 473 102 309 minecraft:cobbled_deepslate
fill 473 102 310 473 105 310 minecraft:deepslate_tiles
setblock 474 102 275 minecraft:white_wool
fill 475 102 276 475 102 288 minecraft:white_wool
fill 479 102 276 479 102 281 minecraft:white_wool
fill 483 102 278 483 102 315 minecraft:white_wool
fill 487 102 276 487 105 276 minecraft:deepslate_tiles
fill 487 102 277 487 102 289 minecraft:white_wool
fill 487 102 305 487 102 315 minecraft:white_wool
fill 490 102 317 490 198 317 minecraft:black_concrete
setblock 491 102 276 minecraft:cobbled_deepslate
fill 491 102 280 491 102 288 minecraft:white_wool
fill 491 102 296 491 102 316 minecraft:white_wool
fill 492 102 276 492 105 276 minecraft:deepslate_tiles
setblock 494 102 317 minecraft:redstone_block
fill 495 102 278 495 102 311 minecraft:white_wool
fill 495 102 317 497 140 317 minecraft:black_concrete
fill 499 102 282 499 102 316 minecraft:white_wool
fill 502 102 276 502 105 276 minecraft:deepslate_tiles
fill 503 102 280 503 102 315 minecraft:white_wool
fill 503 102 316 503 104 316 minecraft:deepslate_tiles
fill 504 102 315 506 102 315 minecraft:deepslate_tiles
fill 505 102 275 505 179 275 minecraft:black_concrete
setblock 505 102 277 minecraft:cobbled_deepslate
setblock 506 102 276 minecraft:cobbled_deepslate
fill 506 102 277 506 105 277 minecraft:deepslate_tiles
fill 506 102 314 507 102 314 minecraft:deepslate_tiles
setblock 506 102 316 minecraft:cobbled_deepslate
fill 507 102 276 507 105 276 minecraft:deepslate_tiles
setblock 507 102 278 minecraft:white_wool
setblock 507 102 315 minecraft:cobbled_deepslate
fill 507 102 316 507 105 316 minecraft:deepslate_tiles
setblock 508 102 308 minecraft:deepslate_tiles
setblock 508 102 309 minecraft:cobbled_deepslate
fill 508 102 310 508 104 311 minecraft:deepslate_tiles
setblock 508 102 314 minecraft:cobbled_deepslate
fill 508 102 315 508 105 315 minecraft:deepslate_tiles
setblock 509 102 283 minecraft:cobbled_deepslate
fill 509 102 284 509 103 284 minecraft:deepslate_tiles
setblock 509 102 287 minecraft:deepslate_tiles
fill 509 102 304 509 104 304 minecraft:deepslate_tiles
setblock 509 102 307 minecraft:deepslate_tiles
setblock 509 102 308 minecraft:cobbled_deepslate
fill 509 102 309 509 105 309 minecraft:deepslate_tiles
setblock 509 102 312 minecraft:deepslate_tiles
setblock 509 102 313 minecraft:cobbled_deepslate
fill 509 102 314 509 105 314 minecraft:deepslate_tiles
setblock 510 102 277 minecraft:cobbled_deepslate
fill 510 102 278 510 103 278 minecraft:deepslate_tiles
setblock 510 102 282 minecraft:cobbled_deepslate
fill 510 102 283 510 105 283 minecraft:deepslate_tiles
setblock 510 102 287 minecraft:cobbled_deepslate
fill 510 102 288 510 105 288 minecraft:deepslate_tiles
fill 510 102 290 510 103 290 minecraft:deepslate_tiles
setblock 510 102 302 minecraft:cobbled_deepslate
fill 510 102 303 510 105 303 minecraft:deepslate_tiles
setblock 510 102 307 minecraft:cobbled_deepslate
fill 510 102 308 510 105 308 minecraft:deepslate_tiles
setblock 510 102 312 minecraft:cobbled_deepslate
fill 510 102 313 510 105 313 minecraft:deepslate_tiles
setblock 511 102 276 minecraft:cobbled_deepslate
fill 511 102 277 511 105 277 minecraft:deepslate_tiles
setblock 511 102 281 minecraft:cobbled_deepslate
fill 511 102 282 511 105 282 minecraft:deepslate_tiles
setblock 511 102 286 minecraft:cobbled_deepslate
fill 511 102 287 511 105 287 minecraft:deepslate_tiles
setblock 511 102 291 minecraft:cobbled_deepslate
fill 511 102 292 511 105 292 minecraft:deepslate_tiles
setblock 511 102 301 minecraft:cobbled_deepslate
fill 511 102 302 511 105 302 minecraft:deepslate_tiles
setblock 511 102 306 minecraft:cobbled_deepslate
fill 511 102 307 511 105 307 minecraft:deepslate_tiles
setblock 511 102 311 minecraft:cobbled_deepslate
fill 511 102 312 511 105 312 minecraft:deepslate_tiles
setblock 511 102 316 minecraft:cobbled_deepslate
setblock 470 103 307 minecraft:redstone_block
fill 470 103 308 470 201 308 minecraft:black_concrete
setblock 471 103 281 minecraft:deepslate_tiles
setblock 471 103 285 minecraft:cobbled_deepslate
fill 471 103 286 471 106 286 minecraft:deepslate_tiles
setblock 471 103 290 minecraft:cobbled_deepslate
fill 471 103 291 471 103 294 minecraft:deepslate_tiles
setblock 471 103 295 minecraft:cobbled_deepslate
fill 471 103 296 471 106 296 minecraft:deepslate_tiles
setblock 471 103 300 minecraft:cobbled_deepslate
fill 471 103 301 471 106 301 minecraft:deepslate_tiles
setblock 471 103 305 minecraft:cobbled_deepslate
fill 471 103 306 471 106 306 minecraft:deepslate_tiles
setblock 471 103 309 minecraft:deepslate_tiles
setblock 471 103 310 minecraft:cobbled_deepslate
fill 471 103 311 471 106 311 minecraft:deepslate_tiles
setblock 471 103 315 minecraft:cobbled_deepslate
fill 471 103 316 471 106 316 minecraft:deepslate_tiles
setblock 472 103 285 minecraft:deepslate_tiles
setblock 472 103 288 minecraft:deepslate_tiles
setblock 472 103 289 minecraft:cobbled_deepslate
fill 472 103 290 472 105 291 minecraft:deepslate_tiles
setblock 472 103 300 minecraft:deepslate_tiles
setblock 472 103 304 minecraft:cobbled_deepslate
fill 472 103 305 472 106 305 minecraft:deepslate_tiles
setblock 472 103 309 minecraft:cobbled_deepslate
fill 472 103 310 472 106 310 minecraft:deepslate_tiles
setblock 472 103 314 minecraft:cobbled_deepslate
fill 472 103 315 472 106 315 minecraft:deepslate_tiles
setblock 473 103 278 minecraft:light[level=12]
setblock 473 103 285 minecraft:light[level=12]
setblock 473 103 292 minecraft:light[level=12]
setblock 473 103 299 minecraft:light[level=12]
setblock 473 103 304 minecraft:deepslate_tiles
setblock 473 103 308 minecraft:cobbled_deepslate
fill 473 103 309 473 106 309 minecraft:deepslate_tiles
setblock 473 103 313 minecraft:light[level=12]
fill 474 103 275 474 201 275 minecraft:black_concrete
setblock 480 103 278 minecraft:light[level=12]
setblock 480 103 285 minecraft:light[level=12]
setblock 480 103 292 minecraft:light[level=12]
setblock 480 103 299 minecraft:light[level=12]
setblock 480 103 306 minecraft:light[level=12]
setblock 480 103 313 minecraft:light[level=12]
fill 483 103 313 483 103 315 minecraft:white_wool
fill 486 103 276 486 106 276 minecraft:deepslate_tiles
fill 486 103 316 489 103 316 minecraft:deepslate_tiles
setblock 487 103 278 minecraft:light[level=12]
setblock 487 103 285 minecraft:light[level=12]
setblock 487 103 292 minecraft:light[level=12]
setblock 487 103 299 minecraft:light[level=12]
setblock 487 103 306 minecraft:light[level=12]
setblock 487 103 313 minecraft:light[level=12]
setblock 490 103 276 minecraft:cobbled_deepslate
setblock 490 103 316 minecraft:cobbled_deepslate
fill 491 103 276 491 106 276 minecraft:deepslate_tiles
fill 491 103 316 491 106 316 minecraft:deepslate_tiles
setblock 494 103 276 minecraft:deepslate_tiles
setblock 494 103 278 minecraft:light[level=12]
setblock 494 103 285 minecraft:light[level=12]
setblock 494 103 292 minecraft:light[level=12]
setblock 494 103 299 minecraft:light[level=12]
setblock 494 103 306 minecraft:light[level=12]
setblock 494 103 313 minecraft:light[level=12]
fill 494 103 317 494 201 317 minecraft:black_concrete
fill 495 103 309 495 103 315 minecraft:white_wool
setblock 500 103 276 minecraft:cobbled_deepslate
fill 501 103 276 501 106 276 minecraft:deepslate_tiles
setblock 501 103 278 minecraft:light[level=12]
setblock 501 103 285 minecraft:light[level=12]
setblock 501 103 292 minecraft:light[level=12]
setblock 501 103 299 minecraft:light[level=12]
setblock 501 103 306 minecraft:light[level=12]
setblock 501 103 313 minecraft:light[level=12]
fill 501 103 316 502 105 316 minecraft:deepslate_tiles
fill 503 103 315 505 103 315 minecraft:deepslate_tiles
setblock 504 103 277 minecraft:cobbled_deepslate
setblock 505 103 276 minecraft:cobbled_deepslate
fill 505 103 277 505 106 277 minecraft:deepslate_tiles
fill 505 103 314 506 103 314 minecraft:deepslate_tiles
setblock 505 103 316 minecraft:cobbled_deepslate
fill 506 103 276 506 106 276 minecraft:deepslate_tiles
setblock 506 103 315 minecraft:cobbled_deepslate
fill 506 103 316 506 106 316 minecraft:deepslate_tiles
setblock 507 103 313 minecraft:deepslate_tiles
setblock 507 103 314 minecraft:cobbled_deepslate
fill 507 103 315 507 106 315 minecraft:deepslate_tiles
setblock 508 103 278 minecraft:light[level=12]
setblock 508 103 285 minecraft:light[level=12]
setblock 508 103 292 minecraft:light[level=12]
setblock 508 103 299 minecraft:light[level=12]
setblock 508 103 306 minecraft:light[level=12]
setblock 508 103 307 minecraft:deepslate_tiles
setblock 508 103 308 minecraft:cobbled_deepslate
fill 508 103 309 508 106 309 minecraft:deepslate_tiles
setblock 508 103 312 minecraft:deepslate_tiles
setblock 508 103 313 minecraft:cobbled_deepslate
fill 508 103 314 508 106 314 minecraft:deepslate_tiles
setblock 509 103 277 minecraft:cobbled_deepslate
setblock 509 103 283 minecraft:deepslate_tiles
setblock 509 103 287 minecraft:cobbled_deepslate
fill 509 103 288 509 105 288 minecraft:deepslate_tiles
setblock 509 103 307 minecraft:cobbled_deepslate
fill 509 103 308 509 106 308 minecraft:deepslate_tiles
setblock 509 103 311 minecraft:deepslate_tiles
setblock 509 103 312 minecraft:cobbled_deepslate
fill 509 103 313 509 106 313 minecraft:deepslate_tiles
setblock 510 103 276 minecraft:cobbled_deepslate
setblock 510 103 277 minecraft:deepslate_tiles
setblock 510 103 281 minecraft:cobbled_deepslate
fill 510 103 282 510 104 282 minecraft:deepslate_tiles
setblock 510 103 286 minecraft:cobbled_deepslate
fill 510 103 287 510 106 287 minecraft:deepslate_tiles
setblock 510 103 291 minecraft:cobbled_deepslate
fill 510 103 302 510 104 302 minecraft:deepslate_tiles
setblock 510 103 306 minecraft:cobbled_deepslate
fill 510 103 307 510 106 307 minecraft:deepslate_tiles
setblock 510 103 311 minecraft:cobbled_deepslate
fill 510 103 312 510 106 312 minecraft:deepslate_tiles
setblock 510 103 316 minecraft:cobbled_deepslate
fill 511 103 276 511 106 276 minecraft:deepslate_tiles
setblock 511 103 280 minecraft:cobbled_deepslate
fill 511 103 281 511 105 281 minecraft:deepslate_tiles
setblock 511 103 285 minecraft:cobbled_deepslate
fill 511 103 286 511 106 286 minecraft:deepslate_tiles
setblock 511 103 289 minecraft:deepslate_tiles
setblock 511 103 290 minecraft:cobbled_deepslate
fill 511 103 291 511 106 291 minecraft:deepslate_tiles
fill 511 103 293 511 103 294 minecraft:deepslate_tiles
setblock 511 103 299 minecraft:deepslate_tiles
setblock 511 103 300 minecraft:cobbled_deepslate
fill 511 103 301 511 106 301 minecraft:deepslate_tiles
setblock 511 103 305 minecraft:cobbled_deepslate
fill 511 103 306 511 106 306 minecraft:deepslate_tiles
setblock 511 103 310 minecraft:cobbled_deepslate
fill 511 103 311 511 106 311 minecraft:deepslate_tiles
setblock 511 103 315 minecraft:cobbled_deepslate
fill 511 103 316 511 106 316 minecraft:deepslate_tiles
fill 470 104 307 470 201 307 minecraft:black_concrete
setblock 471 104 284 minecraft:cobbled_deepslate
fill 471 104 285 471 107 285 minecraft:deepslate_tiles
setblock 471 104 289 minecraft:cobbled_deepslate
fill 471 104 290 471 104 293 minecraft:deepslate_tiles
setblock 471 104 294 minecraft:cobbled_deepslate
fill 471 104 295 471 107 295 minecraft:deepslate_tiles
setblock 471 104 299 minecraft:cobbled_deepslate
fill 471 104 300 471 107 300 minecraft:deepslate_tiles
setblock 471 104 304 minecraft:cobbled_deepslate
fill 471 104 305 471 107 305 minecraft:deepslate_tiles
setblock 471 104 309 minecraft:cobbled_deepslate
fill 471 104 310 471 107 310 minecraft:deepslate_tiles
setblock 471 104 314 minecraft:cobbled_deepslate
fill 471 104 315 471 107 315 minecraft:deepslate_tiles
setblock 472 104 288 minecraft:cobbled_deepslate
fill 472 104 289 472 107 289 minecraft:deepslate_tiles
setblock 472 104 292 minecraft:deepslate_tiles
setblock 472 104 293 minecraft:cobbled_deepslate
setblock 472 104 303 minecraft:cobbled_deepslate
fill 472 104 304 472 106 304 minecraft:deepslate_tiles
setblock 472 104 308 minecraft:cobbled_deepslate
fill 472 104 309 472 107 309 minecraft:deepslate_tiles
setblock 472 104 313 minecraft:cobbled_deepslate
fill 472 104 314 472 107 314 minecraft:deepslate_tiles
setblock 473 104 307 minecraft:cobbled_deepslate
fill 473 104 308 473 105 308 minecraft:deepslate_tiles
setblock 484 104 276 minecraft:cobbled_deepslate
setblock 484 104 316 minecraft:cobbled_deepslate
fill 485 104 276 485 107 276 minecraft:deepslate_tiles
fill 485 104 316 488 104 316 minecraft:deepslate_tiles
fill 487 104 315 487 106 315 minecraft:deepslate_tiles
setblock 488 104 277 minecraft:cobbled_deepslate
setblock 489 104 276 minecraft:cobbled_deepslate
fill 489 104 277 489 107 277 minecraft:deepslate_tiles
setblock 489 104 316 minecraft:cobbled_deepslate
fill 490 104 276 490 107 276 minecraft:deepslate_tiles
fill 490 104 316 490 107 316 minecraft:deepslate_tiles
setblock 491 104 317 minecraft:redstone_block
fill 492 104 316 492 105 316 minecraft:deepslate_tiles
setblock 494 104 276 minecraft:cobbled_deepslate
setblock 499 104 276 minecraft:cobbled_deepslate
setblock 499 104 316 minecraft:cobbled_deepslate
fill 500 104 276 500 107 276 minecraft:deepslate_tiles
fill 500 104 316 500 107 316 minecraft:deepslate_tiles
fill 501 104 315 504 104 315 minecraft:deepslate_tiles
setblock 503 104 277 minecraft:cobbled_deepslate
fill 503 104 314 505 104 314 minecraft:deepslate_tiles
setblock 504 104 276 minecraft:cobbled_deepslate
fill 504 104 277 504 107 277 minecraft:deepslate_tiles
setblock 504 104 316 minecraft:cobbled_deepslate
fill 505 104 276 505 107 276 minecraft:deepslate_tiles
fill 505 104 313 506 104 313 minecraft:deepslate_tiles
setblock 505 104 315 minecraft:cobbled_deepslate
fill 505 104 316 505 107 316 minecraft:deepslate_tiles
setblock 506 104 314 minecraft:cobbled_deepslate
fill 506 104 315 506 107 315 minecraft:deepslate_tiles
setblock 507 104 313 minecraft:cobbled_deepslate
fill 507 104 314 507 107 314 minecraft:deepslate_tiles
setblock 508 104 277 minecraft:cobbled_deepslate
setblock 508 104 307 minecraft:cobbled_deepslate
fill 508 104 308 508 107 308 minecraft:deepslate_tiles
setblock 508 104 312 minecraft:cobbled_deepslate
fill 508 104 313 508 107 313 minecraft:deepslate_tiles
setblock 509 104 276 minecraft:cobbled_deepslate
fill 509 104 277 509 106 277 minecraft:deepslate_tiles
setblock 509 104 285 minecraft:deepslate_tiles
setblock 509 104 286 minecraft:cobbled_deepslate
fill 509 104 287 509 105 287 minecraft:deepslate_tiles
fill 509 104 289 509 105 289 minecraft:deepslate_tiles
setblock 509 104 306 minecraft:cobbled_deepslate
fill 509 104 307 509 107 307 minecraft:deepslate_tiles
setblock 509 104 311 minecraft:cobbled_deepslate
fill 509 104 312 509 107 312 minecraft:deepslate_tiles
setblock 509 104 316 minecraft:cobbled_deepslate
fill 510 104 276 510 107 276 minecraft:deepslate_tiles
setblock 510 104 281 minecraft:deepslate_tiles
setblock 510 104 285 minecraft:cobbled_deepslate
fill 510 104 286 510 106 286 minecraft:deepslate_tiles
setblock 510 104 290 minecraft:cobbled_deepslate
fill 510 104 291 510 106 292 minecraft:deepslate_tiles
setblock 510 104 305 minecraft:cobbled_deepslate
fill 510 104 306 510 107 306 minecraft:deepslate_tiles
setblock 510 104 310 minecraft:cobbled_deepslate
fill 510 104 311 510 107 311 minecraft:deepslate_tiles
setblock 510 104 315 minecraft:cobbled_deepslate
fill 510 104 316 510 107 316 minecraft:deepslate_tiles
setblock 511 104 279 minecraft:cobbled_deepslate
fill 511 104 280 511 105 280 minecraft:deepslate_tiles
setblock 511 104 284 minecraft:cobbled_deepslate
fill 511 104 285 511 107 285 minecraft:deepslate_tiles
setblock 511 104 289 minecraft:cobbled_deepslate
fill 511 104 290 511 107 290 minecraft:deepslate_tiles
setblock 511 104 293 minecraft:deepslate_tiles
setblock 511 104 294 minecraft:cobbled_deepslate
fill 511 104 295 511 107 295 minecraft:deepslate_tiles
setblock 511 104 299 minecraft:cobbled_deepslate
fill 511 104 300 511 106 300 minecraft:deepslate_tiles
setblock 511 104 304 minecraft:cobbled_deepslate
fill 511 104 305 511 107 305 minecraft:deepslate_tiles
setblock 511 104 309 minecraft:cobbled_deepslate
fill 511 104 310 511 107 310 minecraft:deepslate_tiles
setblock 511 104 314 minecraft:cobbled_deepslate
fill 511 104 315 511 107 315 minecraft:deepslate_tiles
fill 512 104 283 512 201 286 minecraft:black_concrete
setblock 512 104 287 minecraft:white_wool
setblock 471 105 283 minecraft:cobbled_deepslate
fill 471 105 284 471 106 284 minecraft:deepslate_tiles
setblock 471 105 288 minecraft:cobbled_deepslate
fill 471 105 289 471 105 292 minecraft:deepslate_tiles
setblock 471 105 293 minecraft:cobbled_deepslate
fill 471 105 294 472 107 294 minecraft:deepslate_tiles
setblock 471 105 298 minecraft:cobbled_deepslate
fill 471 105 299 471 108 299 minecraft:deepslate_tiles
setblock 471 105 303 minecraft:cobbled_deepslate
fill 471 105 304 471 108 304 minecraft:deepslate_tiles
setblock 471 105 308 minecraft:cobbled_deepslate
fill 471 105 309 471 108 309 minecraft:deepslate_tiles
setblock 471 105 313 minecraft:cobbled_deepslate
fill 471 105 314 471 108 314 minecraft:deepslate_tiles
setblock 472 105 287 minecraft:cobbled_deepslate
fill 472 105 288 472 107 288 minecraft:deepslate_tiles
setblock 472 105 292 minecraft:cobbled_deepslate
fill 472 105 293 472 108 293 minecraft:deepslate_tiles
setblock 472 105 302 minecraft:cobbled_deepslate
fill 472 105 303 472 106 303 minecraft:deepslate_tiles
setblock 472 105 307 minecraft:cobbled_deepslate
fill 472 105 308 472 108 308 minecraft:deepslate_tiles
setblock 472 105 311 minecraft:deepslate_tiles
setblock 472 105 312 minecraft:cobbled_deepslate
fill 472 105 313 472 108 313 minecraft:deepslate_tiles
setblock 472 105 316 minecraft:deepslate_tiles
setblock 473 105 306 minecraft:cobbled_deepslate
setblock 473 105 307 minecraft:deepslate_tiles
setblock 473 105 311 minecraft:cobbled_deepslate
setblock 473 105 316 minecraft:cobbled_deepslate
setblock 482 105 316 minecraft:deepslate_tiles
setblock 483 105 276 minecraft:cobbled_deepslate
setblock 483 105 316 minecraft:cobbled_deepslate
fill 484 105 276 484 108 276 minecraft:deepslate_tiles
fill 484 105 316 487 105 316 minecraft:deepslate_tiles
fill 485 105 315 486 107 315 minecraft:deepslate_tiles
setblock 486 105 277 minecraft:deepslate_tiles
setblock 487 105 277 minecraft:cobbled_deepslate
setblock 488 105 276 minecraft:cobbled_deepslate
fill 488 105 277 488 108 277 minecraft:deepslate_tiles
setblock 488 105 315 minecraft:deepslate_tiles
setblock 488 105 316 minecraft:cobbled_deepslate
fill 489 105 276 489 108 276 minecraft:deepslate_tiles
setblock 489 105 315 minecraft:cobbled_deepslate
fill 489 105 316 489 108 316 minecraft:deepslate_tiles
setblock 490 105 277 minecraft:deepslate_tiles
fill 491 105 317 491 197 317 minecraft:black_concrete
setblock 493 105 276 minecraft:cobbled_deepslate
fill 493 105 312 493 106 312 minecraft:white_wool
setblock 493 105 316 minecraft:cobbled_deepslate
fill 494 105 276 497 105 276 minecraft:deepslate_tiles
setblock 497 105 316 minecraft:deepslate_tiles
setblock 498 105 276 minecraft:cobbled_deepslate
setblock 498 105 316 minecraft:cobbled_deepslate
fill 499 105 276 499 108 276 minecraft:deepslate_tiles
fill 499 105 316 499 108 316 minecraft:deepslate_tiles
fill 500 105 315 503 105 315 minecraft:deepslate_tiles
setblock 502 105 277 minecraft:cobbled_deepslate
fill 502 105 314 504 105 314 minecraft:deepslate_tiles
setblock 503 105 276 minecraft:cobbled_deepslate
fill 503 105 277 503 108 277 minecraft:deepslate_tiles
setblock 503 105 316 minecraft:cobbled_deepslate
fill 504 105 276 504 108 276 minecraft:deepslate_tiles
fill 504 105 313 505 105 313 minecraft:deepslate_tiles
setblock 504 105 315 minecraft:cobbled_deepslate
fill 504 105 316 504 108 316 minecraft:deepslate_tiles
setblock 505 105 314 minecraft:cobbled_deepslate
fill 505 105 315 505 108 315 minecraft:deepslate_tiles
setblock 506 105 313 minecraft:cobbled_deepslate
fill 506 105 314 506 108 314 minecraft:deepslate_tiles
setblock 507 105 277 minecraft:cobbled_deepslate
setblock 507 105 311 minecraft:deepslate_tiles
setblock 507 105 312 minecraft:cobbled_deepslate
fill 507 105 313 507 108 313 minecraft:deepslate_tiles
setblock 508 105 276 minecraft:cobbled_deepslate
fill 508 105 277 508 107 277 minecraft:deepslate_tiles
fill 508 105 307 508 106 307 minecraft:deepslate_tiles
setblock 508 105 310 minecraft:deepslate_tiles
setblock 508 105 311 minecraft:cobbled_deepslate
fill 508 105 312 508 108 312 minecraft:deepslate_tiles
setblock 508 105 316 minecraft:cobbled_deepslate
fill 509 105 276 509 108 276 minecraft:deepslate_tiles
setblock 509 105 305 minecraft:cobbled_deepslate
fill 509 105 306 509 107 306 minecraft:deepslate_tiles
setblock 509 105 310 minecraft:cobbled_deepslate
fill 509 105 311 509 108 311 minecraft:deepslate_tiles
setblock 509 105 315 minecraft:cobbled_deepslate
fill 509 105 316 509 108 316 minecraft:deepslate_tiles
setblock 510 105 284 minecraft:cobbled_deepslate
fill 510 105 285 510 106 285 minecraft:deepslate_tiles
setblock 510 105 289 minecraft:cobbled_deepslate
fill 510 105 290 510 107 290 minecraft:deepslate_tiles
setblock 510 105 304 minecraft:cobbled_deepslate
fill 510 105 305 510 107 305 minecraft:deepslate_tiles
setblock 510 105 309 minecraft:cobbled_deepslate
fill 510 105 310 510 108 310 minecraft:deepslate_tiles
setblock 510 105 314 minecraft:cobbled_deepslate
fill 510 105 315 510 108 315 minecraft:deepslate_tiles
setblock 511 105 278 minecraft:cobbled_deepslate
setblock 511 105 279 minecraft:deepslate_tiles
setblock 511 105 283 minecraft:cobbled_deepslate
fill 511 105 284 511 106 284 minecraft:deepslate_tiles
setblock 511 105 288 minecraft:cobbled_deepslate
fill 511 105 289 511 108 289 minecraft:deepslate_tiles
setblock 511 105 293 minecraft:cobbled_deepslate
fill 511 105 294 511 108 294 minecraft:deepslate_tiles
fill 511 105 296 511 106 296 minecraft:deepslate_tiles
setblock 511 105 299 minecraft:deepslate_tiles
setblock 511 105 303 minecraft:cobbled_deepslate
fill 511 105 304 511 108 304 minecraft:deepslate_tiles
setblock 511 105 308 minecraft:cobbled_deepslate
fill 511 105 309 511 108 309 minecraft:deepslate_tiles
setblock 511 105 313 minecraft:cobbled_deepslate
fill 511 105 314 511 108 314 minecraft:deepslate_tiles
fill 512 105 287 512 201 287 minecraft:black_concrete
setblock 471 106 287 minecraft:cobbled_deepslate
fill 471 106 288 471 106 291 minecraft:deepslate_tiles
setblock 471 106 292 minecraft:cobbled_deepslate
fill 471 106 293 471 109 293 minecraft:deepslate_tiles
setblock 471 106 297 minecraft:cobbled_deepslate
fill 471 106 298 471 109 298 minecraft:deepslate_tiles
setblock 471 106 302 minecraft:cobbled_deepslate
fill 471 106 303 471 109 303 minecraft:deepslate_tiles
setblock 471 106 307 minecraft:cobbled_deepslate
fill 471 106 308 471 109 308 minecraft:deepslate_tiles
setblock 471 106 312 minecraft:cobbled_deepslate
fill 471 106 313 471 109 313 minecraft:deepslate_tiles
setblock 472 106 287 minecraft:deepslate_tiles
setblock 472 106 290 minecraft:deepslate_tiles
setblock 472 106 291 minecraft:cobbled_deepslate
fill 472 106 292 472 109 292 minecraft:deepslate_tiles
setblock 472 106 295 minecraft:deepslate_tiles
setblock 472 106 306 minecraft:cobbled_deepslate
fill 472 106 307 472 108 307 minecraft:deepslate_tiles
setblock 472 106 311 minecraft:cobbled_deepslate
fill 472 106 312 472 108 312 minecraft:deepslate_tiles
setblock 472 106 316 minecraft:cobbled_deepslate
setblock 473 106 310 minecraft:cobbled_deepslate
fill 473 106 316 473 107 316 minecraft:deepslate_tiles
setblock 481 106 316 minecraft:deepslate_tiles
setblock 482 106 316 minecraft:cobbled_deepslate
fill 483 106 276 483 109 276 minecraft:deepslate_tiles
setblock 483 106 315 minecraft:cobbled_deepslate
fill 483 106 316 486 106 316 minecraft:deepslate_tiles
fill 484 106 315 484 109 315 minecraft:deepslate_tiles
setblock 486 106 277 minecraft:cobbled_deepslate
setblock 487 106 276 minecraft:cobbled_deepslate
fill 487 106 277 487 109 277 minecraft:deepslate_tiles
setblock 487 106 316 minecraft:cobbled_deepslate
fill 488 106 276 488 109 276 minecraft:deepslate_tiles
setblock 488 106 315 minecraft:cobbled_deepslate
fill 488 106 316 488 109 316 minecraft:deepslate_tiles
fill 489 106 315 490 107 315 minecraft:deepslate_tiles
setblock 492 106 276 minecraft:cobbled_deepslate
setblock 492 106 316 minecraft:cobbled_deepslate
fill 493 106 276 496 106 276 minecraft:deepslate_tiles
fill 493 106 316 496 106 316 minecraft:deepslate_tiles
setblock 497 106 276 minecraft:cobbled_deepslate
setblock 497 106 316 minecraft:cobbled_deepslate
fill 498 106 276 498 109 276 minecraft:deepslate_tiles
fill 498 106 316 498 109 316 minecraft:deepslate_tiles
fill 499 106 315 502 106 315 minecraft:deepslate_tiles
setblock 501 106 277 minecraft:cobbled_deepslate
fill 501 106 314 503 106 314 minecraft:deepslate_tiles
setblock 501 106 316 minecraft:deepslate_tiles
setblock 502 106 276 minecraft:cobbled_deepslate
fill 502 106 277 502 109 277 minecraft:deepslate_tiles
setblock 502 106 316 minecraft:cobbled_deepslate
fill 503 106 276 503 109 276 minecraft:deepslate_tiles
fill 503 106 313 504 106 313 minecraft:deepslate_tiles
setblock 503 106 315 minecraft:cobbled_deepslate
fill 503 106 316 503 109 316 minecraft:deepslate_tiles
setblock 504 106 314 minecraft:cobbled_deepslate
fill 504 106 315 504 109 315 minecraft:deepslate_tiles
setblock 505 106 313 minecraft:cobbled_deepslate
fill 505 106 314 505 109 314 minecraft:deepslate_tiles
setblock 506 106 277 minecraft:cobbled_deepslate
setblock 506 106 312 minecraft:cobbled_deepslate
fill 506 106 313 506 109 313 minecraft:deepslate_tiles
setblock 507 106 276 minecraft:cobbled_deepslate
fill 507 106 277 507 108 277 minecraft:deepslate_tiles
setblock 507 106 311 minecraft:cobbled_deepslate
fill 507 106 312 507 107 312 minecraft:deepslate_tiles
setblock 507 106 316 minecraft:cobbled_deepslate
fill 508 106 276 508 109 276 minecraft:deepslate_tiles
setblock 508 106 310 minecraft:cobbled_deepslate
fill 508 106 311 508 109 311 minecraft:deepslate_tiles
setblock 508 106 315 minecraft:cobbled_deepslate
fill 508 106 316 508 109 316 minecraft:deepslate_tiles
setblock 509 106 305 minecraft:deepslate_tiles
setblock 509 106 309 minecraft:cobbled_deepslate
fill 509 106 310 509 109 310 minecraft:deepslate_tiles
setblock 509 106 314 minecraft:cobbled_deepslate
fill 509 106 315 509 109 315 minecraft:deepslate_tiles
setblock 510 106 288 minecraft:cobbled_deepslate
fill 510 106 289 510 107 289 minecraft:deepslate_tiles
setblock 510 106 293 minecraft:cobbled_deepslate
setblock 510 106 303 minecraft:cobbled_deepslate
fill 510 106 304 510 107 304 minecraft:deepslate_tiles
setblock 510 106 308 minecraft:cobbled_deepslate
fill 510 106 309 510 109 309 minecraft:deepslate_tiles
setblock 510 106 313 minecraft:cobbled_deepslate
fill 510 106 314 510 109 314 minecraft:deepslate_tiles
setblock 511 106 277 minecraft:cobbled_deepslate
setblock 511 106 283 minecraft:deepslate_tiles
setblock 511 106 287 minecraft:cobbled_deepslate
fill 511 106 288 511 108 288 minecraft:deepslate_tiles
setblock 511 106 292 minecraft:cobbled_deepslate
fill 511 106 293 511 109 293 minecraft:deepslate_tiles
setblock 511 106 297 minecraft:cobbled_deepslate
setblock 511 106 302 minecraft:cobbled_deepslate
fill 511 106 303 511 108 303 minecraft:deepslate_tiles
setblock 511 106 307 minecraft:cobbled_deepslate
fill 511 106 308 511 109 308 minecraft:deepslate_tiles
setblock 511 106 312 minecraft:cobbled_deepslate
fill 511 106 313 511 109 313 minecraft:deepslate_tiles
setblock 471 107 286 minecraft:cobbled_deepslate
fill 471 107 287 471 107 290 minecraft:deepslate_tiles
setblock 471 107 291 minecraft:cobbled_deepslate
fill 471 107 292 471 110 292 minecraft:deepslate_tiles
setblock 471 107 296 minecraft:cobbled_deepslate
fill 471 107 297 471 110 297 minecraft:deepslate_tiles
setblock 471 107 301 minecraft:cobbled_deepslate
fill 471 107 302 471 108 302 minecraft:deepslate_tiles
setblock 471 107 306 minecraft:cobbled_deepslate
fill 471 107 307 471 110 307 minecraft:deepslate_tiles
setblock 471 107 311 minecraft:cobbled_deepslate
fill 471 107 312 471 110 312 minecraft:deepslate_tiles
setblock 471 107 316 minecraft:cobbled_deepslate
setblock 472 107 290 minecraft:cobbled_deepslate
fill 472 107 291 472 109 291 minecraft:deepslate_tiles
setblock 472 107 295 minecraft:cobbled_deepslate
setblock 472 107 305 minecraft:cobbled_deepslate
setblock 472 107 306 minecraft:deepslate_tiles
setblock 472 107 310 minecraft:cobbled_deepslate
fill 472 107 311 472 108 311 minecraft:deepslate_tiles
fill 472 107 316 472 109 316 minecraft:deepslate_tiles
fill 475 107 275 479 192 275 minecraft:black_concrete
setblock 480 107 275 minecraft:white_wool
setblock 480 107 316 minecraft:deepslate_tiles
fill 481 107 275 481 202 275 minecraft:black_concrete
setblock 481 107 316 minecraft:cobbled_deepslate
fill 482 107 276 482 110 276 minecraft:deepslate_tiles
setblock 482 107 315 minecraft:cobbled_deepslate
fill 482 107 316 485 107 316 minecraft:deepslate_tiles
fill 483 107 315 483 110 315 minecraft:deepslate_tiles
setblock 485 107 277 minecraft:cobbled_deepslate
setblock 486 107 276 minecraft:cobbled_deepslate
fill 486 107 277 486 110 277 minecraft:deepslate_tiles
setblock 486 107 316 minecraft:cobbled_deepslate
fill 487 107 276 487 110 276 minecraft:deepslate_tiles
setblock 487 107 315 minecraft:cobbled_deepslate
fill 487 107 316 487 110 316 minecraft:deepslate_tiles
fill 488 107 315 488 109 315 minecraft:deepslate_tiles
setblock 491 107 276 minecraft:cobbled_deepslate
setblock 491 107 316 minecraft:cobbled_deepslate
fill 492 107 276 495 107 276 minecraft:deepslate_tiles
fill 492 107 316 495 107 316 minecraft:deepslate_tiles
setblock 496 107 276 minecraft:cobbled_deepslate
setblock 496 107 316 minecraft:cobbled_deepslate
fill 497 107 276 497 110 276 minecraft:deepslate_tiles
fill 497 107 316 497 110 316 minecraft:deepslate_tiles
fill 498 107 315 501 107 315 minecraft:deepslate_tiles
fill 500 107 314 502 107 314 minecraft:deepslate_tiles
setblock 501 107 276 minecraft:cobbled_deepslate
fill 501 107 277 501 110 277 minecraft:deepslate_tiles
setblock 501 107 316 minecraft:cobbled_deepslate
fill 502 107 276 502 110 276 minecraft:deepslate_tiles
fill 502 107 313 503 107 313 minecraft:deepslate_tiles
setblock 502 107 315 minecraft:cobbled_deepslate
fill 502 107 316 502 110 316 minecraft:deepslate_tiles
setblock 503 107 314 minecraft:cobbled_deepslate
fill 503 107 315 503 110 315 minecraft:deepslate_tiles
setblock 504 107 313 minecraft:cobbled_deepslate
fill 504 107 314 504 110 314 minecraft:deepslate_tiles
setblock 505 107 277 minecraft:cobbled_deepslate
fill 505 107 313 505 110 313 minecraft:deepslate_tiles
setblock 506 107 276 minecraft:cobbled_deepslate
fill 506 107 277 506 110 277 minecraft:deepslate_tiles
setblock 506 107 312 minecraft:deepslate_tiles
setblock 506 107 316 minecraft:cobbled_deepslate
fill 507 107 276 507 110 276 minecraft:deepslate_tiles
setblock 507 107 315 minecraft:cobbled_deepslate
fill 507 107 316 507 110 316 minecraft:deepslate_tiles
setblock 508 107 309 minecraft:cobbled_deepslate
fill 508 107 310 508 108 310 minecraft:deepslate_tiles
setblock 508 107 314 minecraft:cobbled_deepslate
fill 508 107 315 508 110 315 minecraft:deepslate_tiles
setblock 509 107 308 minecraft:cobbled_deepslate
fill 509 107 309 509 109 309 minecraft:deepslate_tiles
setblock 509 107 313 minecraft:cobbled_deepslate
fill 509 107 314 509 110 314 minecraft:deepslate_tiles
setblock 510 107 288 minecraft:deepslate_tiles
setblock 510 107 291 minecraft:deepslate_tiles
setblock 510 107 292 minecraft:cobbled_deepslate
setblock 510 107 293 minecraft:deepslate_tiles
setblock 510 107 307 minecraft:cobbled_deepslate
fill 510 107 308 510 110 308 minecraft:deepslate_tiles
setblock 510 107 312 minecraft:cobbled_deepslate
fill 510 107 313 510 110 313 minecraft:deepslate_tiles
setblock 511 107 276 minecraft:cobbled_deepslate
setblock 511 107 286 minecraft:cobbled_deepslate
fill 511 107 287 511 108 287 minecraft:deepslate_tiles
setblock 511 107 291 minecraft:cobbled_deepslate
fill 511 107 292 511 110 292 minecraft:deepslate_tiles
setblock 511 107 296 minecraft:cobbled_deepslate
setblock 511 107 297 minecraft:deepslate_tiles
setblock 511 107 301 minecraft:cobbled_deepslate
setblock 511 107 302 minecraft:deepslate_tiles
setblock 511 107 306 minecraft:cobbled_deepslate
fill 511 107 307 511 110 307 minecraft:deepslate_tiles
setblock 511 107 311 minecraft:cobbled_deepslate
fill 511 107 312 511 110 312 minecraft:deepslate_tiles
setblock 511 107 316 minecraft:cobbled_deepslate
fill 471 108 286 471 108 289 minecraft:deepslate_tiles
setblock 471 108 290 minecraft:cobbled_deepslate
fill 471 108 291 471 111 291 minecraft:deepslate_tiles
setblock 471 108 294 minecraft:deepslate_tiles
setblock 471 108 295 minecraft:cobbled_deepslate
fill 471 108 296 471 111 296 minecraft:deepslate_tiles
setblock 471 108 300 minecraft:cobbled_deepslate
fill 471 108 301 471 109 301 minecraft:deepslate_tiles
setblock 471 108 305 minecraft:cobbled_deepslate
fill 471 108 306 471 109 306 minecraft:deepslate_tiles
setblock 471 108 310 minecraft:cobbled_deepslate
fill 471 108 311 471 111 311 minecraft:deepslate_tiles
setblock 471 108 315 minecraft:cobbled_deepslate
fill 471 108 316 471 110 316 minecraft:deepslate_tiles
setblock 472 108 290 minecraft:deepslate_tiles
setblock 472 108 294 minecraft:cobbled_deepslate
fill 472 108 295 472 109 295 minecraft:deepslate_tiles
setblock 472 108 309 minecraft:cobbled_deepslate
setblock 472 108 310 minecraft:deepslate_tiles
setblock 472 108 314 minecraft:cobbled_deepslate
setblock 479 108 316 minecraft:deepslate_tiles
fill 480 108 275 480 201 275 minecraft:black_concrete
setblock 480 108 316 minecraft:cobbled_deepslate
fill 481 108 276 481 111 276 minecraft:deepslate_tiles
fill 481 108 316 484 108 316 minecraft:deepslate_tiles
fill 482 108 315 482 111 315 minecraft:deepslate_tiles
setblock 485 108 276 minecraft:cobbled_deepslate
fill 485 108 277 485 111 277 minecraft:deepslate_tiles
setblock 485 108 315 minecraft:deepslate_tiles
setblock 485 108 316 minecraft:cobbled_deepslate
fill 486 108 276 486 111 276 minecraft:deepslate_tiles
setblock 486 108 315 minecraft:cobbled_deepslate
fill 486 108 316 486 111 316 minecraft:deepslate_tiles
fill 487 108 315 487 110 315 minecraft:deepslate_tiles
setblock 489 108 315 minecraft:deepslate_tiles
setblock 490 108 276 minecraft:cobbled_deepslate
setblock 490 108 316 minecraft:cobbled_deepslate
fill 491 108 276 494 108 276 minecraft:deepslate_tiles
fill 491 108 316 494 108 316 minecraft:deepslate_tiles
setblock 495 108 276 minecraft:cobbled_deepslate
setblock 495 108 316 minecraft:cobbled_deepslate
fill 496 108 276 496 111 276 minecraft:deepslate_tiles
fill 496 108 316 496 111 316 minecraft:deepslate_tiles
fill 498 108 315 500 108 315 minecraft:deepslate_tiles
setblock 500 108 276 minecraft:cobbled_deepslate
fill 500 108 277 500 111 277 minecraft:deepslate_tiles
fill 500 108 314 501 108 314 minecraft:deepslate_tiles
setblock 500 108 316 minecraft:cobbled_deepslate
fill 501 108 276 501 111 276 minecraft:deepslate_tiles
setblock 501 108 315 minecraft:cobbled_deepslate
fill 501 108 316 501 111 316 minecraft:deepslate_tiles
setblock 502 108 313 minecraft:deepslate_tiles
setblock 502 108 314 minecraft:cobbled_deepslate
fill 502 108 315 502 111 315 minecraft:deepslate_tiles
setblock 503 108 313 minecraft:cobbled_deepslate
fill 503 108 314 503 111 314 minecraft:deepslate_tiles
setblock 504 108 277 minecraft:cobbled_deepslate
fill 504 108 313 504 111 313 minecraft:deepslate_tiles
setblock 505 108 276 minecraft:cobbled_deepslate
fill 505 108 277 505 111 277 minecraft:deepslate_tiles
setblock 505 108 316 minecraft:cobbled_deepslate
fill 506 108 276 506 111 276 minecraft:deepslate_tiles
setblock 506 108 315 minecraft:cobbled_deepslate
fill 506 108 316 506 111 316 minecraft:deepslate_tiles
setblock 507 108 314 minecraft:cobbled_deepslate
fill 507 108 315 507 111 315 minecraft:deepslate_tiles
setblock 508 108 309 minecraft:deepslate_tiles
setblock 508 108 313 minecraft:cobbled_deepslate
fill 508 108 314 508 111 314 minecraft:deepslate_tiles
setblock 509 108 307 minecraft:cobbled_deepslate
setblock 509 108 308 minecraft:deepslate_tiles
setblock 509 108 312 minecraft:cobbled_deepslate
fill 509 108 313 509 111 313 minecraft:deepslate_tiles
setblock 510 108 276 minecraft:cobbled_deepslate
setblock 510 108 306 minecraft:cobbled_deepslate
fill 510 108 307 510 109 307 minecraft:deepslate_tiles
setblock 510 108 311 minecraft:cobbled_deepslate
fill 510 108 312 510 111 312 minecraft:deepslate_tiles
setblock 510 108 316 minecraft:cobbled_deepslate
setblock 511 108 290 minecraft:cobbled_deepslate
fill 511 108 291 511 109 291 minecraft:deepslate_tiles
setblock 511 108 295 minecraft:cobbled_deepslate
fill 511 108 296 511 109 296 minecraft:deepslate_tiles
setblock 511 108 305 minecraft:cobbled_deepslate
fill 511 108 306 511 110 306 minecraft:deepslate_tiles
setblock 511 108 310 minecraft:cobbled_deepslate
fill 511 108 311 511 111 311 minecraft:deepslate_tiles
setblock 511 108 315 minecraft:cobbled_deepslate
fill 511 108 316 511 111 316 minecraft:deepslate_tiles
setblock 471 109 288 minecraft:deepslate_tiles
setblock 471 109 289 minecraft:cobbled_deepslate
fill 471 109 290 471 111 290 minecraft:deepslate_tiles
setblock 471 109 294 minecraft:cobbled_deepslate
fill 471 109 295 471 112 295 minecraft:deepslate_tiles
setblock 471 109 299 minecraft:cobbled_deepslate
setblock 471 109 300 minecraft:deepslate_tiles
setblock 471 109 304 minecraft:cobbled_deepslate
setblock 471 109 305 minecraft:deepslate_tiles
setblock 471 109 309 minecraft:cobbled_deepslate
fill 471 109 310 471 111 310 minecraft:deepslate_tiles
setblock 471 109 314 minecraft:cobbled_deepslate
fill 471 109 315 471 111 315 minecraft:deepslate_tiles
setblock 472 109 293 minecraft:cobbled_deepslate
fill 472 109 294 472 110 294 minecraft:deepslate_tiles
setblock 473 109 278 minecraft:light[level=13]
setblock 473 109 285 minecraft:light[level=12]
setblock 473 109 286 minecraft:light[level=13]
setblock 473 109 292 minecraft:light[level=12]
setblock 473 109 294 minecraft:light[level=13]
setblock 473 109 299 minecraft:light[level=12]
setblock 473 109 302 minecraft:light[level=13]
setblock 473 109 306 minecraft:light[level=12]
setblock 473 109 310 minecraft:light[level=13]
setblock 473 109 313 minecraft:light[level=12]
setblock 479 109 316 minecraft:cobbled_deepslate
setblock 480 109 278 minecraft:light[level=12]
setblock 480 109 285 minecraft:light[level=12]
setblock 480 109 292 minecraft:light[level=12]
setblock 480 109 299 minecraft:light[level=12]
setblock 480 109 306 minecraft:light[level=12]
setblock 480 109 313 minecraft:light[level=12]
fill 480 109 316 483 109 316 minecraft:deepslate_tiles
setblock 481 109 278 minecraft:light[level=13]
setblock 481 109 286 minecraft:light[level=13]
setblock 481 109 294 minecraft:light[level=13]
setblock 481 109 302 minecraft:light[level=13]
setblock 481 109 310 minecraft:light[level=13]
setblock 484 109 276 minecraft:cobbled_deepslate
fill 484 109 277 484 112 277 minecraft:deepslate_tiles
setblock 484 109 316 minecraft:cobbled_deepslate
fill 485 109 276 485 112 276 minecraft:deepslate_tiles
setblock 485 109 315 minecraft:cobbled_deepslate
fill 485 109 316 485 112 316 minecraft:deepslate_tiles
fill 486 109 315 486 111 315 minecraft:deepslate_tiles
setblock 487 109 278 minecraft:light[level=12]
setblock 487 109 285 minecraft:light[level=12]
setblock 487 109 292 minecraft:light[level=12]
setblock 487 109 299 minecraft:light[level=12]
setblock 487 109 306 minecraft:light[level=12]
setblock 487 109 313 minecraft:light[level=12]
setblock 489 109 276 minecraft:cobbled_deepslate
setblock 489 109 278 minecraft:light[level=13]
setblock 489 109 286 minecraft:light[level=13]
setblock 489 109 294 minecraft:light[level=13]
setblock 489 109 302 minecraft:light[level=13]
setblock 489 109 310 minecraft:light[level=13]
setblock 489 109 316 minecraft:cobbled_deepslate
fill 490 109 276 493 109 276 minecraft:deepslate_tiles
fill 490 109 316 493 109 316 minecraft:deepslate_tiles
setblock 494 109 276 minecraft:cobbled_deepslate
setblock 494 109 278 minecraft:light[level=12]
setblock 494 109 285 minecraft:light[level=12]
setblock 494 109 292 minecraft:light[level=12]
setblock 494 109 299 minecraft:light[level=12]
setblock 494 109 306 minecraft:light[level=12]
setblock 494 109 313 minecraft:light[level=12]
setblock 494 109 316 minecraft:cobbled_deepslate
fill 495 109 276 495 112 276 minecraft:deepslate_tiles
fill 495 109 316 495 112 316 minecraft:deepslate_tiles
setblock 497 109 278 minecraft:light[level=13]
setblock 497 109 286 minecraft:light[level=13]
setblock 497 109 294 minecraft:light[level=13]
setblock 497 109 302 minecraft:light[level=13]
setblock 497 109 310 minecraft:light[level=13]
fill 497 109 315 499 109 315 minecraft:deepslate_tiles
setblock 499 109 276 minecraft:cobbled_deepslate
setblock 499 109 316 minecraft:cobbled_deepslate
fill 500 109 276 500 112 276 minecraft:deepslate_tiles
setblock 500 109 314 minecraft:deepslate_tiles
setblock 500 109 315 minecraft:cobbled_deepslate
fill 500 109 316 500 112 316 minecraft:deepslate_tiles
setblock 501 109 278 minecraft:light[level=12]
setblock 501 109 285 minecraft:light[level=12]
setblock 501 109 292 minecraft:light[level=12]
setblock 501 109 299 minecraft:light[level=12]
setblock 501 109 306 minecraft:light[level=12]
setblock 501 109 313 minecraft:light[level=12]
setblock 501 109 314 minecraft:cobbled_deepslate
fill 501 109 315 501 112 315 minecraft:deepslate_tiles
setblock 502 109 313 minecraft:cobbled_deepslate
fill 502 109 314 502 112 314 minecraft:deepslate_tiles
setblock 503 109 277 minecraft:cobbled_deepslate
fill 503 109 313 503 112 313 minecraft:deepslate_tiles
setblock 504 109 276 minecraft:cobbled_deepslate
fill 504 109 277 504 112 277 minecraft:deepslate_tiles
setblock 504 109 316 minecraft:cobbled_deepslate
fill 505 109 276 505 112 276 minecraft:deepslate_tiles
setblock 505 109 278 minecraft:light[level=13]
setblock 505 109 286 minecraft:light[level=13]
setblock 505 109 294 minecraft:light[level=13]
setblock 505 109 302 minecraft:light[level=13]
setblock 505 109 310 minecraft:light[level=13]
setblock 505 109 315 minecraft:cobbled_deepslate
fill 505 109 316 505 112 316 minecraft:deepslate_tiles
setblock 506 109 314 minecraft:cobbled_deepslate
fill 506 109 315 506 112 315 minecraft:deepslate_tiles
setblock 507 109 313 minecraft:cobbled_deepslate
fill 507 109 314 507 112 314 minecraft:deepslate_tiles
setblock 508 109 278 minecraft:light[level=12]
setblock 508 109 285 minecraft:light[level=12]
setblock 508 109 292 minecraft:light[level=12]
setblock 508 109 299 minecraft:light[level=12]
setblock 508 109 306 minecraft:light[level=12]
setblock 508 109 312 minecraft:cobbled_deepslate
setblock 508 109 313 minecraft:deepslate_tiles
setblock 509 109 276 minecraft:cobbled_deepslate
setblock 509 109 311 minecraft:cobbled_deepslate
fill 509 109 312 509 110 312 minecraft:deepslate_tiles
setblock 509 109 316 minecraft:cobbled_deepslate
setblock 510 109 276 minecraft:deepslate_tiles
setblock 510 109 310 minecraft:cobbled_deepslate
fill 510 109 311 510 111 311 minecraft:deepslate_tiles
setblock 510 109 315 minecraft:cobbled_deepslate
fill 510 109 316 510 112 316 minecraft:deepslate_tiles
setblock 511 109 290 minecraft:deepslate_tiles
setblock 511 109 294 minecraft:cobbled_deepslate
fill 511 109 295 511 111 295 minecraft:deepslate_tiles
setblock 511 109 305 minecraft:deepslate_tiles
setblock 511 109 309 minecraft:cobbled_deepslate
fill 511 109 310 511 112 310 minecraft:deepslate_tiles
setblock 511 109 314 minecraft:cobbled_deepslate
fill 511 109 315 511 112 315 minecraft:deepslate_tiles
setblock 471 110 289 minecraft:deepslate_tiles
setblock 471 110 293 minecraft:cobbled_deepslate
fill 471 110 294 471 113 294 minecraft:deepslate_tiles
setblock 471 110 298 minecraft:cobbled_deepslate
fill 471 110 299 471 113 299 minecraft:deepslate_tiles
setblock 471 110 308 minecraft:cobbled_deepslate
setblock 471 110 309 minecraft:deepslate_tiles
setblock 471 110 313 minecraft:cobbled_deepslate
fill 471 110 314 471 111 314 minecraft:deepslate_tiles
setblock 472 110 293 minecraft:deepslate_tiles
fill 477 110 287 478 111 288 minecraft:white_wool
fill 479 110 316 482 110 316 minecraft:deepslate_tiles
fill 480 110 276 480 112 276 minecraft:deepslate_tiles
setblock 483 110 276 minecraft:cobbled_deepslate
setblock 483 110 316 minecraft:cobbled_deepslate
fill 483 110 317 486 137 317 minecraft:black_concrete
fill 484 110 276 484 113 276 minecraft:deepslate_tiles
setblock 484 110 315 minecraft:cobbled_deepslate
fill 484 110 316 484 113 316 minecraft:deepslate_tiles
fill 485 110 315 485 112 315 minecraft:deepslate_tiles
setblock 487 110 277 minecraft:cobbled_deepslate
setblock 487 110 317 minecraft:white_wool
setblock 488 110 276 minecraft:cobbled_deepslate
setblock 488 110 316 minecraft:cobbled_deepslate
fill 488 110 317 489 137 317 minecraft:black_concrete
fill 489 110 276 492 110 276 minecraft:deepslate_tiles
fill 489 110 316 492 110 316 minecraft:deepslate_tiles
setblock 493 110 276 minecraft:cobbled_deepslate
setblock 493 110 316 minecraft:cobbled_deepslate
fill 494 110 276 494 113 276 minecraft:deepslate_tiles
fill 494 110 316 494 113 316 minecraft:deepslate_tiles
fill 497 110 315 498 110 315 minecraft:deepslate_tiles
setblock 498 110 276 minecraft:cobbled_deepslate
setblock 498 110 316 minecraft:cobbled_deepslate
fill 499 110 276 499 113 276 minecraft:deepslate_tiles
setblock 499 110 314 minecraft:deepslate_tiles
setblock 499 110 315 minecraft:cobbled_deepslate
fill 499 110 316 499 113 316 minecraft:deepslate_tiles
setblock 500 110 314 minecraft:cobbled_deepslate
fill 500 110 315 500 113 315 minecraft:deepslate_tiles
fill 501 110 314 501 113 314 minecraft:deepslate_tiles
setblock 502 110 277 minecraft:cobbled_deepslate
fill 502 110 313 502 111 313 minecraft:deepslate_tiles
setblock 503 110 276 minecraft:cobbled_deepslate
fill 503 110 277 503 113 277 minecraft:deepslate_tiles
setblock 503 110 316 minecraft:cobbled_deepslate
fill 504 110 276 504 113 276 minecraft:deepslate_tiles
setblock 504 110 315 minecraft:cobbled_deepslate
fill 504 110 316 504 113 316 minecraft:deepslate_tiles
setblock 505 110 314 minecraft:cobbled_deepslate
fill 505 110 315 505 113 315 minecraft:deepslate_tiles
setblock 506 110 313 minecraft:cobbled_deepslate
fill 506 110 314 506 113 314 minecraft:deepslate_tiles
setblock 507 110 313 minecraft:deepslate_tiles
setblock 508 110 276 minecraft:cobbled_deepslate
setblock 508 110 316 minecraft:cobbled_deepslate
fill 509 110 276 509 111 276 minecraft:deepslate_tiles
setblock 509 110 311 minecraft:deepslate_tiles
setblock 509 110 315 minecraft:cobbled_deepslate
fill 509 110 316 509 113 316 minecraft:deepslate_tiles
setblock 510 110 309 minecraft:cobbled_deepslate
fill 510 110 310 510 111 310 minecraft:deepslate_tiles
setblock 510 110 314 minecraft:cobbled_deepslate
fill 510 110 315 510 113 315 minecraft:deepslate_tiles
setblock 511 110 293 minecraft:cobbled_deepslate
fill 511 110 294 511 111 294 minecraft:deepslate_tiles
setblock 511 110 308 minecraft:cobbled_deepslate
fill 511 110 309 511 112 309 minecraft:deepslate_tiles
setblock 511 110 313 minecraft:cobbled_deepslate
fill 511 110 314 511 113 314 minecraft:deepslate_tiles
fill 470 111 276 470 117 279 minecraft:black_concrete
setblock 470 111 280 minecraft:white_wool
fill 470 111 281 470 122 283 minecraft:black_concrete
setblock 471 111 292 minecraft:cobbled_deepslate
fill 471 111 293 471 114 293 minecraft:deepslate_tiles
setblock 471 111 297 minecraft:cobbled_deepslate
fill 471 111 298 471 114 298 minecraft:deepslate_tiles
setblock 471 111 312 minecraft:cobbled_deepslate
setblock 471 111 313 minecraft:deepslate_tiles
fill 478 111 316 481 111 316 minecraft:deepslate_tiles
fill 481 111 315 481 112 315 minecraft:deepslate_tiles
setblock 482 111 276 minecraft:cobbled_deepslate
setblock 482 111 316 minecraft:cobbled_deepslate
fill 483 111 276 483 113 277 minecraft:deepslate_tiles
setblock 483 111 315 minecraft:cobbled_deepslate
fill 483 111 316 483 114 316 minecraft:deepslate_tiles
fill 484 111 315 484 114 315 minecraft:deepslate_tiles
setblock 486 111 277 minecraft:cobbled_deepslate
setblock 487 111 276 minecraft:cobbled_deepslate
fill 487 111 277 487 114 277 minecraft:deepslate_tiles
setblock 487 111 316 minecraft:cobbled_deepslate
fill 487 111 317 487 201 317 minecraft:black_concrete
fill 488 111 276 491 111 276 minecraft:deepslate_tiles
fill 488 111 316 491 111 316 minecraft:deepslate_tiles
setblock 492 111 276 minecraft:cobbled_deepslate
setblock 492 111 316 minecraft:cobbled_deepslate
fill 493 111 276 493 114 276 minecraft:deepslate_tiles
fill 493 111 316 493 114 316 minecraft:deepslate_tiles
setblock 497 111 276 minecraft:cobbled_deepslate
setblock 497 111 315 minecraft:deepslate_tiles
setblock 497 111 316 minecraft:cobbled_deepslate
fill 498 111 276 498 114 276 minecraft:deepslate_tiles
setblock 498 111 315 minecraft:cobbled_deepslate
fill 498 111 316 498 114 316 minecraft:deepslate_tiles
fill 499 111 277 499 112 277 minecraft:deepslate_tiles
setblock 499 111 314 minecraft:cobbled_deepslate
fill 499 111 315 499 114 315 minecraft:deepslate_tiles
fill 500 111 314 500 114 314 minecraft:deepslate_tiles
setblock 501 111 277 minecraft:cobbled_deepslate
setblock 502 111 276 minecraft:cobbled_deepslate
fill 502 111 277 502 114 277 minecraft:deepslate_tiles
setblock 502 111 316 minecraft:cobbled_deepslate
fill 503 111 276 503 114 276 minecraft:deepslate_tiles
setblock 503 111 315 minecraft:cobbled_deepslate
fill 503 111 316 503 114 316 minecraft:deepslate_tiles
setblock 504 111 314 minecraft:cobbled_deepslate
fill 504 111 315 504 114 315 minecraft:deepslate_tiles
setblock 505 111 313 minecraft:cobbled_deepslate
fill 505 111 314 505 114 314 minecraft:deepslate_tiles
setblock 506 111 313 minecraft:deepslate_tiles
setblock 507 111 276 minecraft:cobbled_deepslate
setblock 507 111 316 minecraft:cobbled_deepslate
fill 508 111 276 508 114 276 minecraft:deepslate_tiles
setblock 508 111 315 minecraft:cobbled_deepslate
fill 508 111 316 508 114 316 minecraft:deepslate_tiles
setblock 509 111 314 minecraft:cobbled_deepslate
fill 509 111 315 509 114 315 minecraft:deepslate_tiles
setblock 510 111 313 minecraft:cobbled_deepslate
fill 510 111 314 510 113 314 minecraft:deepslate_tiles
setblock 511 111 308 minecraft:deepslate_tiles
setblock 511 111 312 minecraft:cobbled_deepslate
fill 511 111 313 511 114 313 minecraft:deepslate_tiles
fill 470 112 280 470 201 280 minecraft:black_concrete
setblock 471 112 291 minecraft:cobbled_deepslate
fill 471 112 292 471 115 292 minecraft:deepslate_tiles
setblock 471 112 296 minecraft:cobbled_deepslate
fill 471 112 297 471 115 297 minecraft:deepslate_tiles
fill 471 112 317 472 201 317 minecraft:black_concrete
setblock 473 112 317 minecraft:white_wool
fill 478 112 316 480 112 316 minecraft:deepslate_tiles
fill 479 112 276 479 113 276 minecraft:deepslate_tiles
setblock 481 112 276 minecraft:cobbled_deepslate
setblock 481 112 316 minecraft:cobbled_deepslate
fill 482 112 276 482 114 277 minecraft:deepslate_tiles
setblock 482 112 315 minecraft:cobbled_deepslate
fill 482 112 316 482 115 316 minecraft:deepslate_tiles
fill 483 112 315 483 115 315 minecraft:deepslate_tiles
setblock 485 112 277 minecraft:cobbled_deepslate
setblock 486 112 276 minecraft:cobbled_deepslate
fill 486 112 277 486 115 277 minecraft:deepslate_tiles
setblock 486 112 316 minecraft:cobbled_deepslate
fill 487 112 276 490 112 276 minecraft:deepslate_tiles
fill 487 112 316 490 112 316 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_5 1t
