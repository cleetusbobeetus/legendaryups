fill 38 176 503 38 177 503 minecraft:bookshelf
fill 39 176 498 39 177 498 minecraft:bookshelf
fill 39 176 500 39 177 500 minecraft:bookshelf
fill 39 176 502 39 177 502 minecraft:bookshelf
fill 39 176 504 39 177 504 minecraft:bookshelf
fill 40 176 497 40 177 497 minecraft:bookshelf
fill 40 176 499 40 177 499 minecraft:bookshelf
fill 40 176 501 40 177 501 minecraft:bookshelf
fill 40 176 503 40 177 503 minecraft:bookshelf
setblock 41 176 467 minecraft:bookshelf
setblock 41 176 474 minecraft:bookshelf
setblock 41 176 481 minecraft:bookshelf
setblock 41 176 488 minecraft:bookshelf
setblock 41 176 495 minecraft:bookshelf
fill 41 176 498 41 177 498 minecraft:bookshelf
fill 41 176 500 41 177 500 minecraft:bookshelf
fill 41 176 502 41 177 502 minecraft:bookshelf
fill 41 176 504 41 177 504 minecraft:bookshelf
setblock 1 177 464 minecraft:bookshelf
setblock 1 177 471 minecraft:bookshelf
setblock 1 177 478 minecraft:bookshelf
setblock 1 177 485 minecraft:bookshelf
setblock 1 177 492 minecraft:bookshelf
setblock 1 177 499 minecraft:bookshelf
fill 3 177 504 7 177 504 minecraft:bookshelf
fill 5 177 503 11 177 503 minecraft:bookshelf
fill 6 177 502 12 177 502 minecraft:bookshelf
setblock 8 177 464 minecraft:bookshelf
fill 9 177 504 11 177 504 minecraft:bookshelf
setblock 12 177 482 minecraft:dark_oak_planks
setblock 12 177 494 minecraft:dark_oak_planks
setblock 15 177 464 minecraft:bookshelf
setblock 17 177 504 minecraft:bookshelf
setblock 22 177 464 minecraft:bookshelf
setblock 24 177 482 minecraft:dark_oak_planks
setblock 24 177 494 minecraft:dark_oak_planks
setblock 24 177 504 minecraft:bookshelf
setblock 31 177 504 minecraft:bookshelf
setblock 41 177 466 minecraft:bookshelf
setblock 41 177 473 minecraft:bookshelf
setblock 41 177 480 minecraft:bookshelf
setblock 41 177 487 minecraft:bookshelf
setblock 41 177 494 minecraft:bookshelf
setblock 1 178 465 minecraft:bookshelf
setblock 1 178 472 minecraft:bookshelf
setblock 1 178 479 minecraft:bookshelf
setblock 1 178 486 minecraft:bookshelf
setblock 1 178 493 minecraft:bookshelf
fill 1 178 500 1 180 500 minecraft:bookshelf
fill 1 178 502 7 178 503 minecraft:bookshelf
fill 2 178 501 3 179 501 minecraft:bookshelf
fill 2 178 504 6 178 504 minecraft:bookshelf
fill 3 178 500 3 179 500 minecraft:bookshelf
setblock 7 178 464 minecraft:bookshelf
setblock 8 178 502 minecraft:bookshelf
setblock 11 178 504 minecraft:bookshelf
setblock 14 178 464 minecraft:bookshelf
setblock 18 178 504 minecraft:bookshelf
setblock 21 178 464 minecraft:bookshelf
setblock 25 178 504 minecraft:bookshelf
setblock 32 178 504 minecraft:bookshelf
setblock 33 178 498 minecraft:ochre_froglight
setblock 33 178 500 minecraft:ochre_froglight
setblock 33 178 502 minecraft:ochre_froglight
setblock 33 178 504 minecraft:ochre_froglight
setblock 34 178 497 minecraft:ochre_froglight
setblock 34 178 499 minecraft:ochre_froglight
setblock 34 178 501 minecraft:ochre_froglight
setblock 34 178 503 minecraft:ochre_froglight
setblock 35 178 498 minecraft:ochre_froglight
setblock 35 178 500 minecraft:ochre_froglight
setblock 35 178 502 minecraft:ochre_froglight
setblock 35 178 504 minecraft:ochre_froglight
setblock 36 178 497 minecraft:ochre_froglight
setblock 36 178 499 minecraft:ochre_froglight
setblock 36 178 501 minecraft:ochre_froglight
setblock 36 178 503 minecraft:ochre_froglight
setblock 37 178 498 minecraft:ochre_froglight
setblock 37 178 500 minecraft:ochre_froglight
setblock 37 178 502 minecraft:ochre_froglight
setblock 37 178 504 minecraft:ochre_froglight
setblock 38 178 497 minecraft:ochre_froglight
setblock 38 178 499 minecraft:ochre_froglight
setblock 38 178 501 minecraft:ochre_froglight
setblock 38 178 503 minecraft:ochre_froglight
setblock 39 178 498 minecraft:ochre_froglight
setblock 39 178 500 minecraft:ochre_froglight
setblock 39 178 502 minecraft:ochre_froglight
setblock 39 178 504 minecraft:ochre_froglight
setblock 40 178 497 minecraft:ochre_froglight
setblock 40 178 499 minecraft:ochre_froglight
setblock 40 178 501 minecraft:ochre_froglight
setblock 40 178 503 minecraft:ochre_froglight
setblock 41 178 465 minecraft:bookshelf
setblock 41 178 472 minecraft:bookshelf
setblock 41 178 479 minecraft:bookshelf
setblock 41 178 486 minecraft:bookshelf
setblock 41 178 493 minecraft:bookshelf
setblock 41 178 498 minecraft:ochre_froglight
setblock 41 178 500 minecraft:ochre_froglight
setblock 41 178 502 minecraft:ochre_froglight
setblock 41 178 504 minecraft:ochre_froglight
fill 1 179 466 1 180 466 minecraft:bookshelf
fill 1 179 473 1 180 473 minecraft:bookshelf
fill 1 179 480 1 180 480 minecraft:bookshelf
fill 1 179 487 1 180 487 minecraft:bookshelf
fill 1 179 494 1 181 494 minecraft:bookshelf
fill 1 179 498 3 179 499 minecraft:bookshelf
fill 1 179 501 1 180 503 minecraft:bookshelf
fill 2 179 496 3 180 497 minecraft:bookshelf
setblock 2 179 500 minecraft:bookshelf
fill 2 179 502 2 179 503 minecraft:bookshelf
setblock 3 179 502 minecraft:bookshelf
fill 5 179 504 5 180 504 minecraft:bookshelf
fill 6 179 464 6 180 464 minecraft:bookshelf
fill 12 179 504 12 180 504 minecraft:bookshelf
fill 13 179 464 13 180 464 minecraft:bookshelf
fill 19 179 504 19 180 504 minecraft:bookshelf
fill 20 179 464 20 180 464 minecraft:bookshelf
fill 26 179 504 26 180 504 minecraft:bookshelf
fill 27 179 464 27 180 464 minecraft:bookshelf
fill 33 179 498 33 180 498 minecraft:bookshelf
fill 33 179 500 33 180 500 minecraft:bookshelf
fill 33 179 502 33 180 502 minecraft:bookshelf
fill 33 179 504 33 180 504 minecraft:bookshelf
fill 34 179 497 34 180 497 minecraft:bookshelf
fill 34 179 499 34 180 499 minecraft:bookshelf
fill 34 179 501 34 180 501 minecraft:bookshelf
fill 34 179 503 34 180 503 minecraft:bookshelf
fill 35 179 498 35 180 498 minecraft:bookshelf
fill 35 179 500 35 180 500 minecraft:bookshelf
fill 35 179 502 35 180 502 minecraft:bookshelf
fill 35 179 504 35 180 504 minecraft:bookshelf
fill 36 179 497 36 180 497 minecraft:bookshelf
fill 36 179 499 36 180 499 minecraft:bookshelf
fill 36 179 501 36 180 501 minecraft:bookshelf
fill 36 179 503 36 180 503 minecraft:bookshelf
fill 37 179 498 37 180 498 minecraft:bookshelf
fill 37 179 500 37 180 500 minecraft:bookshelf
fill 37 179 502 37 180 502 minecraft:bookshelf
fill 37 179 504 37 180 504 minecraft:bookshelf
fill 38 179 497 38 180 497 minecraft:bookshelf
fill 38 179 499 38 180 499 minecraft:bookshelf
fill 38 179 501 38 180 501 minecraft:bookshelf
fill 38 179 503 38 180 503 minecraft:bookshelf
fill 39 179 498 39 180 498 minecraft:bookshelf
fill 39 179 500 39 180 500 minecraft:bookshelf
fill 39 179 502 39 180 502 minecraft:bookshelf
fill 39 179 504 39 180 504 minecraft:bookshelf
fill 40 179 497 40 180 497 minecraft:bookshelf
fill 40 179 499 40 180 499 minecraft:bookshelf
fill 40 179 501 40 180 501 minecraft:bookshelf
fill 40 179 503 40 180 503 minecraft:bookshelf
fill 41 179 464 41 180 464 minecraft:bookshelf
fill 41 179 471 41 180 471 minecraft:bookshelf
fill 41 179 478 41 180 478 minecraft:bookshelf
fill 41 179 485 41 180 485 minecraft:bookshelf
fill 41 179 492 41 180 492 minecraft:bookshelf
fill 41 179 498 41 180 498 minecraft:bookshelf
fill 41 179 500 41 180 500 minecraft:bookshelf
fill 41 179 502 41 180 502 minecraft:bookshelf
fill 41 179 504 41 180 504 minecraft:bookshelf
fill 1 180 464 1 180 465 minecraft:bookshelf
fill 1 180 467 1 180 468 minecraft:bookshelf
fill 1 180 470 1 180 472 minecraft:bookshelf
fill 1 180 474 1 180 475 minecraft:bookshelf
fill 1 180 477 1 180 479 minecraft:bookshelf
fill 1 180 481 1 180 482 minecraft:bookshelf
fill 1 180 484 1 180 486 minecraft:bookshelf
fill 1 180 488 1 180 489 minecraft:bookshelf
fill 1 180 491 1 181 493 minecraft:bookshelf
fill 1 180 495 1 180 496 minecraft:bookshelf
fill 1 180 498 1 180 499 minecraft:bookshelf
setblock 2 180 464 minecraft:bookshelf
fill 2 180 492 3 180 495 minecraft:bookshelf
setblock 2 180 498 minecraft:bookshelf
fill 2 180 504 4 180 504 minecraft:bookshelf
fill 4 180 464 5 180 464 minecraft:bookshelf
fill 6 180 504 7 180 504 minecraft:bookshelf
fill 7 180 464 9 180 464 minecraft:bookshelf
fill 9 180 504 11 180 504 minecraft:bookshelf
fill 11 180 464 12 180 464 minecraft:bookshelf
fill 13 180 504 14 180 504 minecraft:bookshelf
fill 14 180 464 16 180 464 minecraft:bookshelf
fill 16 180 504 18 180 504 minecraft:bookshelf
fill 18 180 464 19 180 464 minecraft:bookshelf
fill 20 180 504 21 180 504 minecraft:bookshelf
fill 21 180 464 23 180 464 minecraft:bookshelf
fill 23 180 504 25 180 504 minecraft:bookshelf
fill 25 180 464 26 180 464 minecraft:bookshelf
fill 27 180 504 28 180 504 minecraft:bookshelf
fill 30 180 504 32 180 504 minecraft:bookshelf
fill 35 180 485 35 181 486 minecraft:green_wool
setblock 37 180 464 minecraft:bookshelf
fill 39 180 464 40 180 464 minecraft:bookshelf
fill 41 180 465 41 180 467 minecraft:bookshelf
fill 41 180 469 41 180 470 minecraft:bookshelf
fill 41 180 472 41 180 474 minecraft:bookshelf
fill 41 180 476 41 180 477 minecraft:bookshelf
fill 41 180 479 41 180 481 minecraft:bookshelf
fill 41 180 483 41 180 484 minecraft:bookshelf
fill 41 180 486 41 180 488 minecraft:bookshelf
fill 41 180 490 41 180 491 minecraft:bookshelf
fill 41 180 493 41 180 495 minecraft:bookshelf
setblock 1 181 468 minecraft:bookshelf
setblock 1 181 475 minecraft:bookshelf
setblock 1 181 482 minecraft:bookshelf
fill 1 181 489 3 182 489 minecraft:bookshelf
setblock 1 181 496 minecraft:bookshelf
setblock 1 181 503 minecraft:bookshelf
fill 2 181 490 2 181 494 minecraft:bookshelf
fill 3 181 490 3 181 493 minecraft:bookshelf
setblock 4 181 464 minecraft:bookshelf
setblock 7 181 504 minecraft:bookshelf
setblock 11 181 464 minecraft:bookshelf
setblock 14 181 504 minecraft:bookshelf
setblock 18 181 464 minecraft:bookshelf
setblock 21 181 504 minecraft:bookshelf
setblock 25 181 464 minecraft:bookshelf
setblock 28 181 504 minecraft:bookshelf
setblock 33 181 498 minecraft:ochre_froglight
setblock 33 181 500 minecraft:ochre_froglight
setblock 33 181 502 minecraft:ochre_froglight
setblock 33 181 504 minecraft:ochre_froglight
setblock 34 181 497 minecraft:ochre_froglight
setblock 34 181 499 minecraft:ochre_froglight
setblock 34 181 501 minecraft:ochre_froglight
setblock 34 181 503 minecraft:ochre_froglight
setblock 35 181 498 minecraft:ochre_froglight
setblock 35 181 500 minecraft:ochre_froglight
setblock 35 181 502 minecraft:ochre_froglight
setblock 35 181 504 minecraft:ochre_froglight
setblock 36 181 497 minecraft:ochre_froglight
setblock 36 181 499 minecraft:ochre_froglight
setblock 36 181 501 minecraft:ochre_froglight
setblock 36 181 503 minecraft:ochre_froglight
setblock 37 181 498 minecraft:ochre_froglight
setblock 37 181 500 minecraft:ochre_froglight
setblock 37 181 502 minecraft:ochre_froglight
setblock 37 181 504 minecraft:ochre_froglight
setblock 38 181 497 minecraft:ochre_froglight
setblock 38 181 499 minecraft:ochre_froglight
setblock 38 181 501 minecraft:ochre_froglight
setblock 38 181 503 minecraft:ochre_froglight
setblock 39 181 464 minecraft:bookshelf
setblock 39 181 498 minecraft:ochre_froglight
setblock 39 181 500 minecraft:ochre_froglight
setblock 39 181 502 minecraft:ochre_froglight
setblock 39 181 504 minecraft:ochre_froglight
setblock 40 181 497 minecraft:ochre_froglight
setblock 40 181 499 minecraft:ochre_froglight
setblock 40 181 501 minecraft:ochre_froglight
setblock 40 181 503 minecraft:ochre_froglight
setblock 41 181 469 minecraft:bookshelf
setblock 41 181 476 minecraft:bookshelf
setblock 41 181 483 minecraft:bookshelf
setblock 41 181 490 minecraft:bookshelf
setblock 41 181 498 minecraft:ochre_froglight
setblock 41 181 500 minecraft:ochre_froglight
setblock 41 181 502 minecraft:ochre_froglight
setblock 41 181 504 minecraft:ochre_froglight
fill 1 182 486 3 182 488 minecraft:bookshelf
fill 2 182 490 3 182 490 minecraft:bookshelf
setblock 3 182 466 minecraft:light[level=12]
setblock 3 182 474 minecraft:light[level=12]
setblock 3 182 482 minecraft:light[level=12]
setblock 3 182 498 minecraft:light[level=12]
setblock 11 182 466 minecraft:light[level=12]
setblock 11 182 474 minecraft:light[level=12]
setblock 11 182 482 minecraft:light[level=12]
setblock 11 182 490 minecraft:light[level=12]
setblock 11 182 498 minecraft:light[level=12]
setblock 19 182 466 minecraft:light[level=12]
setblock 19 182 474 minecraft:light[level=12]
setblock 19 182 482 minecraft:light[level=12]
setblock 19 182 490 minecraft:light[level=12]
setblock 19 182 498 minecraft:light[level=12]
setblock 27 182 466 minecraft:light[level=12]
setblock 27 182 474 minecraft:light[level=12]
setblock 27 182 482 minecraft:light[level=12]
setblock 27 182 490 minecraft:light[level=12]
setblock 27 182 498 minecraft:light[level=12]
fill 33 182 498 33 183 498 minecraft:bookshelf
fill 33 182 500 33 183 500 minecraft:bookshelf
fill 33 182 502 33 183 502 minecraft:bookshelf
fill 33 182 504 33 183 504 minecraft:bookshelf
fill 34 182 497 34 183 497 minecraft:bookshelf
fill 34 182 499 34 183 499 minecraft:bookshelf
fill 34 182 501 34 183 501 minecraft:bookshelf
fill 34 182 503 34 183 503 minecraft:bookshelf
setblock 35 182 474 minecraft:light[level=12]
setblock 35 182 482 minecraft:light[level=12]
setblock 35 182 490 minecraft:light[level=12]
fill 35 182 498 35 183 498 minecraft:bookshelf
fill 35 182 500 35 183 500 minecraft:bookshelf
fill 35 182 502 35 183 502 minecraft:bookshelf
fill 35 182 504 35 183 504 minecraft:bookshelf
fill 36 182 497 36 183 497 minecraft:bookshelf
fill 36 182 499 36 183 499 minecraft:bookshelf
fill 36 182 501 36 183 501 minecraft:bookshelf
fill 36 182 503 36 183 503 minecraft:bookshelf
fill 37 182 498 37 183 498 minecraft:bookshelf
fill 37 182 500 37 183 500 minecraft:bookshelf
fill 37 182 502 37 183 502 minecraft:bookshelf
fill 37 182 504 37 183 504 minecraft:bookshelf
fill 38 182 497 38 183 497 minecraft:bookshelf
fill 38 182 499 38 183 499 minecraft:bookshelf
fill 38 182 501 38 183 501 minecraft:bookshelf
fill 38 182 503 38 183 503 minecraft:bookshelf
fill 39 182 498 39 183 498 minecraft:bookshelf
fill 39 182 500 39 183 500 minecraft:bookshelf
fill 39 182 502 39 183 502 minecraft:bookshelf
fill 39 182 504 39 183 504 minecraft:bookshelf
fill 40 182 497 40 183 497 minecraft:bookshelf
fill 40 182 499 40 183 499 minecraft:bookshelf
fill 40 182 501 40 183 501 minecraft:bookshelf
fill 40 182 503 40 183 503 minecraft:bookshelf
fill 41 182 498 41 183 498 minecraft:bookshelf
fill 41 182 500 41 183 500 minecraft:bookshelf
fill 41 182 502 41 183 502 minecraft:bookshelf
fill 41 182 504 41 183 504 minecraft:bookshelf
setblock 1 183 470 minecraft:bookshelf
setblock 1 183 477 minecraft:bookshelf
fill 1 183 484 3 183 487 minecraft:bookshelf
setblock 1 183 491 minecraft:bookshelf
setblock 1 183 498 minecraft:bookshelf
setblock 2 183 464 minecraft:bookshelf
fill 2 183 483 3 184 483 minecraft:bookshelf
setblock 2 183 504 minecraft:bookshelf
setblock 9 183 464 minecraft:bookshelf
setblock 9 183 504 minecraft:bookshelf
setblock 16 183 464 minecraft:bookshelf
setblock 16 183 504 minecraft:bookshelf
setblock 23 183 464 minecraft:bookshelf
setblock 23 183 504 minecraft:bookshelf
setblock 30 183 504 minecraft:bookshelf
setblock 37 183 464 minecraft:bookshelf
setblock 41 183 467 minecraft:bookshelf
setblock 41 183 474 minecraft:bookshelf
setblock 41 183 481 minecraft:bookshelf
setblock 41 183 488 minecraft:bookshelf
setblock 41 183 495 minecraft:bookshelf
setblock 1 184 464 minecraft:bookshelf
setblock 1 184 471 minecraft:bookshelf
fill 1 184 478 1 185 478 minecraft:bookshelf
fill 1 184 480 3 184 482 minecraft:bookshelf
fill 1 184 484 1 184 485 minecraft:bookshelf
setblock 1 184 492 minecraft:bookshelf
setblock 1 184 499 minecraft:bookshelf
fill 2 184 484 3 184 484 minecraft:bookshelf
setblock 3 184 504 minecraft:bookshelf
setblock 8 184 464 minecraft:bookshelf
setblock 10 184 504 minecraft:bookshelf
setblock 15 184 464 minecraft:bookshelf
setblock 17 184 504 minecraft:bookshelf
setblock 22 184 464 minecraft:bookshelf
setblock 24 184 504 minecraft:bookshelf
setblock 31 184 504 minecraft:bookshelf
setblock 33 184 498 minecraft:ochre_froglight
setblock 33 184 500 minecraft:ochre_froglight
setblock 33 184 502 minecraft:ochre_froglight
setblock 33 184 504 minecraft:ochre_froglight
setblock 34 184 497 minecraft:ochre_froglight
setblock 34 184 499 minecraft:ochre_froglight
setblock 34 184 501 minecraft:ochre_froglight
setblock 34 184 503 minecraft:ochre_froglight
setblock 35 184 498 minecraft:ochre_froglight
setblock 35 184 500 minecraft:ochre_froglight
setblock 35 184 502 minecraft:ochre_froglight
setblock 35 184 504 minecraft:ochre_froglight
setblock 36 184 497 minecraft:ochre_froglight
setblock 36 184 499 minecraft:ochre_froglight
setblock 36 184 501 minecraft:ochre_froglight
setblock 36 184 503 minecraft:ochre_froglight
setblock 37 184 498 minecraft:ochre_froglight
setblock 37 184 500 minecraft:ochre_froglight
setblock 37 184 502 minecraft:ochre_froglight
setblock 37 184 504 minecraft:ochre_froglight
setblock 38 184 497 minecraft:ochre_froglight
setblock 38 184 499 minecraft:ochre_froglight
setblock 38 184 501 minecraft:ochre_froglight
setblock 38 184 503 minecraft:ochre_froglight
setblock 39 184 498 minecraft:ochre_froglight
setblock 39 184 500 minecraft:ochre_froglight
setblock 39 184 502 minecraft:ochre_froglight
setblock 39 184 504 minecraft:ochre_froglight
setblock 40 184 497 minecraft:ochre_froglight
setblock 40 184 499 minecraft:ochre_froglight
setblock 40 184 501 minecraft:ochre_froglight
setblock 40 184 503 minecraft:ochre_froglight
setblock 41 184 466 minecraft:bookshelf
setblock 41 184 473 minecraft:bookshelf
setblock 41 184 480 minecraft:bookshelf
setblock 41 184 487 minecraft:bookshelf
setblock 41 184 494 minecraft:bookshelf
setblock 41 184 498 minecraft:ochre_froglight
setblock 41 184 500 minecraft:ochre_froglight
setblock 41 184 502 minecraft:ochre_froglight
setblock 41 184 504 minecraft:ochre_froglight
setblock 1 185 465 minecraft:bookshelf
fill 1 185 472 1 187 472 minecraft:bookshelf
fill 1 185 477 3 186 477 minecraft:bookshelf
fill 1 185 479 3 185 481 minecraft:bookshelf
setblock 1 185 486 minecraft:bookshelf
setblock 1 185 493 minecraft:bookshelf
setblock 1 185 500 minecraft:bookshelf
fill 2 185 478 3 186 478 minecraft:bookshelf
setblock 4 185 504 minecraft:bookshelf
setblock 7 185 464 minecraft:bookshelf
setblock 11 185 504 minecraft:bookshelf
setblock 14 185 464 minecraft:bookshelf
setblock 18 185 504 minecraft:bookshelf
setblock 21 185 464 minecraft:bookshelf
fill 25 185 501 25 186 503 minecraft:gold_block
setblock 25 185 504 minecraft:bookshelf
fill 32 185 504 33 185 504 minecraft:bookshelf
fill 33 185 498 33 187 498 minecraft:bookshelf
fill 33 185 500 33 187 500 minecraft:bookshelf
fill 33 185 502 33 187 502 minecraft:bookshelf
fill 34 185 497 34 187 497 minecraft:bookshelf
fill 34 185 499 34 187 499 minecraft:bookshelf
fill 34 185 501 34 187 501 minecraft:bookshelf
fill 34 185 503 34 187 503 minecraft:bookshelf
fill 35 185 498 35 187 498 minecraft:bookshelf
fill 35 185 500 35 187 500 minecraft:bookshelf
fill 35 185 502 35 187 502 minecraft:bookshelf
fill 35 185 504 35 188 504 minecraft:bookshelf
fill 36 185 497 36 187 497 minecraft:bookshelf
fill 36 185 499 36 187 499 minecraft:bookshelf
fill 36 185 501 36 187 501 minecraft:bookshelf
fill 36 185 503 36 187 503 minecraft:bookshelf
fill 37 185 498 37 187 498 minecraft:bookshelf
fill 37 185 500 37 187 500 minecraft:bookshelf
fill 37 185 502 37 187 502 minecraft:bookshelf
fill 37 185 504 37 187 504 minecraft:bookshelf
fill 38 185 497 38 187 497 minecraft:bookshelf
fill 38 185 499 38 187 499 minecraft:bookshelf
fill 38 185 501 38 187 501 minecraft:bookshelf
fill 38 185 503 38 187 503 minecraft:bookshelf
fill 39 185 498 39 187 498 minecraft:bookshelf
fill 39 185 500 39 187 500 minecraft:bookshelf
fill 39 185 502 39 187 502 minecraft:bookshelf
fill 39 185 504 39 187 504 minecraft:bookshelf
fill 40 185 497 40 187 497 minecraft:bookshelf
fill 40 185 499 40 187 499 minecraft:bookshelf
fill 40 185 501 40 187 501 minecraft:bookshelf
fill 40 185 503 40 187 503 minecraft:bookshelf
setblock 41 185 465 minecraft:bookshelf
setblock 41 185 472 minecraft:bookshelf
setblock 41 185 479 minecraft:bookshelf
setblock 41 185 486 minecraft:bookshelf
setblock 41 185 493 minecraft:bookshelf
fill 41 185 498 41 187 498 minecraft:bookshelf
fill 41 185 500 41 187 500 minecraft:bookshelf
fill 41 185 502 41 187 502 minecraft:bookshelf
fill 41 185 504 41 187 504 minecraft:bookshelf
setblock 1 186 466 minecraft:bookshelf
fill 1 186 473 3 186 475 minecraft:bookshelf
setblock 1 186 480 minecraft:bookshelf
setblock 1 186 487 minecraft:bookshelf
setblock 1 186 494 minecraft:bookshelf
setblock 1 186 501 minecraft:bookshelf
fill 2 186 476 3 186 476 minecraft:bookshelf
setblock 5 186 504 minecraft:bookshelf
setblock 6 186 464 minecraft:bookshelf
setblock 12 186 504 minecraft:bookshelf
setblock 13 186 464 minecraft:bookshelf
setblock 19 186 504 minecraft:bookshelf
setblock 20 186 464 minecraft:bookshelf
setblock 26 186 504 minecraft:bookshelf
setblock 27 186 464 minecraft:bookshelf
fill 33 186 504 33 187 504 minecraft:bookshelf
setblock 41 186 464 minecraft:bookshelf
setblock 41 186 471 minecraft:bookshelf
setblock 41 186 478 minecraft:bookshelf
setblock 41 186 485 minecraft:bookshelf
setblock 41 186 492 minecraft:bookshelf
fill 1 187 467 1 188 468 minecraft:bookshelf
fill 1 187 470 3 187 471 minecraft:bookshelf
fill 1 187 473 3 187 474 minecraft:bookshelf
setblock 1 187 481 minecraft:bookshelf
setblock 1 187 488 minecraft:bookshelf
setblock 1 187 495 minecraft:bookshelf
setblock 1 187 502 minecraft:bookshelf
fill 2 187 468 2 188 469 minecraft:bookshelf
fill 2 187 472 3 187 472 minecraft:bookshelf
fill 3 187 469 3 188 469 minecraft:bookshelf
setblock 3 187 475 minecraft:bookshelf
setblock 5 187 464 minecraft:bookshelf
setblock 6 187 504 minecraft:bookshelf
setblock 12 187 464 minecraft:bookshelf
setblock 13 187 504 minecraft:bookshelf
setblock 19 187 464 minecraft:bookshelf
setblock 20 187 504 minecraft:bookshelf
setblock 26 187 464 minecraft:bookshelf
setblock 27 187 504 minecraft:bookshelf
fill 31 187 464 31 220 464 minecraft:bookshelf
setblock 33 187 464 minecraft:bookshelf
setblock 40 187 464 minecraft:bookshelf
setblock 41 187 470 minecraft:bookshelf
setblock 41 187 477 minecraft:bookshelf
setblock 41 187 484 minecraft:bookshelf
setblock 41 187 491 minecraft:bookshelf
fill 1 188 464 2 188 466 minecraft:bookshelf
setblock 1 188 475 minecraft:bookshelf
setblock 1 188 482 minecraft:bookshelf
setblock 1 188 489 minecraft:bookshelf
setblock 1 188 496 minecraft:bookshelf
setblock 1 188 503 minecraft:bookshelf
fill 2 188 467 3 188 467 minecraft:bookshelf
fill 2 188 470 3 188 470 minecraft:bookshelf
fill 3 188 465 4 189 466 minecraft:bookshelf
setblock 3 188 468 minecraft:bookshelf
setblock 3 188 471 minecraft:bookshelf
fill 4 188 464 4 190 464 minecraft:bookshelf
fill 5 188 466 5 189 466 minecraft:bookshelf
setblock 7 188 504 minecraft:bookshelf
setblock 11 188 464 minecraft:bookshelf
setblock 14 188 504 minecraft:bookshelf
setblock 18 188 464 minecraft:bookshelf
setblock 21 188 504 minecraft:bookshelf
setblock 25 188 464 minecraft:bookshelf
setblock 28 188 504 minecraft:bookshelf
setblock 32 188 464 minecraft:bookshelf
setblock 39 188 464 minecraft:bookshelf
setblock 41 188 469 minecraft:bookshelf
setblock 41 188 476 minecraft:bookshelf
setblock 41 188 483 minecraft:bookshelf
setblock 41 188 490 minecraft:bookshelf
fill 1 189 464 2 190 464 minecraft:bookshelf
setblock 2 189 465 minecraft:bookshelf
fill 5 189 464 8 189 465 minecraft:bookshelf
fill 6 189 466 9 189 466 minecraft:bookshelf
fill 9 189 465 9 190 465 minecraft:bookshelf
fill 1 190 465 1 190 468 minecraft:bookshelf
fill 1 190 470 1 190 475 minecraft:bookshelf
fill 1 190 477 1 190 482 minecraft:bookshelf
fill 1 190 484 1 190 489 minecraft:bookshelf
fill 1 190 491 1 190 496 minecraft:bookshelf
fill 1 190 498 1 190 503 minecraft:bookshelf
fill 2 190 504 7 190 504 minecraft:bookshelf
setblock 3 190 466 minecraft:light[level=12]
setblock 3 190 474 minecraft:light[level=12]
setblock 3 190 482 minecraft:light[level=12]
setblock 3 190 490 minecraft:light[level=12]
setblock 3 190 498 minecraft:light[level=12]
fill 5 190 464 9 190 464 minecraft:bookshelf
fill 7 190 465 8 190 465 minecraft:bookshelf
fill 8 190 466 13 190 466 minecraft:bookshelf
fill 9 190 504 14 190 504 minecraft:bookshelf
fill 10 190 465 13 190 465 minecraft:bookshelf
fill 11 190 464 16 191 464 minecraft:bookshelf
setblock 11 190 474 minecraft:light[level=12]
setblock 11 190 482 minecraft:light[level=12]
setblock 11 190 490 minecraft:light[level=12]
setblock 11 190 498 minecraft:light[level=12]
fill 16 190 504 21 190 504 minecraft:bookshelf
fill 18 190 464 23 190 464 minecraft:bookshelf
setblock 19 190 466 minecraft:light[level=12]
setblock 19 190 474 minecraft:light[level=12]
setblock 19 190 482 minecraft:light[level=12]
setblock 19 190 490 minecraft:light[level=12]
setblock 19 190 498 minecraft:light[level=12]
fill 23 190 504 28 190 504 minecraft:bookshelf
fill 25 190 464 30 190 464 minecraft:bookshelf
setblock 27 190 466 minecraft:light[level=12]
setblock 27 190 474 minecraft:light[level=12]
setblock 27 190 482 minecraft:light[level=12]
setblock 27 190 490 minecraft:light[level=12]
setblock 27 190 498 minecraft:light[level=12]
fill 30 190 468 30 191 470 minecraft:white_wool
fill 30 190 504 35 190 504 minecraft:bookshelf
fill 31 190 468 31 191 469 minecraft:white_wool
fill 32 190 464 37 190 464 minecraft:bookshelf
setblock 35 190 466 minecraft:light[level=12]
setblock 35 190 474 minecraft:light[level=12]
setblock 35 190 482 minecraft:light[level=12]
setblock 35 190 490 minecraft:light[level=12]
setblock 35 190 498 minecraft:light[level=12]
fill 37 190 504 41 190 504 minecraft:bookshelf
fill 39 190 464 41 190 464 minecraft:bookshelf
fill 41 190 465 41 190 467 minecraft:bookshelf
fill 41 190 469 41 190 474 minecraft:bookshelf
fill 41 190 476 41 190 481 minecraft:bookshelf
fill 41 190 483 41 190 488 minecraft:bookshelf
fill 41 190 490 41 190 495 minecraft:bookshelf
fill 41 190 497 41 190 502 minecraft:bookshelf
setblock 1 191 464 minecraft:bookshelf
setblock 1 191 471 minecraft:bookshelf
setblock 1 191 478 minecraft:bookshelf
setblock 1 191 485 minecraft:bookshelf
setblock 1 191 492 minecraft:bookshelf
setblock 1 191 499 minecraft:bookshelf
setblock 3 191 504 minecraft:bookshelf
setblock 8 191 464 minecraft:bookshelf
setblock 10 191 504 minecraft:bookshelf
fill 11 191 465 16 191 465 minecraft:bookshelf
fill 12 191 466 16 191 466 minecraft:bookshelf
setblock 17 191 504 minecraft:bookshelf
setblock 22 191 464 minecraft:bookshelf
setblock 24 191 504 minecraft:bookshelf
setblock 29 191 464 minecraft:bookshelf
setblock 31 191 504 minecraft:bookshelf
setblock 36 191 464 minecraft:bookshelf
fill 36 191 474 36 192 475 minecraft:blue_wool
setblock 38 191 504 minecraft:bookshelf
setblock 41 191 466 minecraft:bookshelf
setblock 41 191 473 minecraft:bookshelf
setblock 41 191 480 minecraft:bookshelf
setblock 41 191 487 minecraft:bookshelf
setblock 41 191 494 minecraft:bookshelf
setblock 41 191 501 minecraft:bookshelf
setblock 1 192 465 minecraft:bookshelf
setblock 1 192 472 minecraft:bookshelf
setblock 1 192 479 minecraft:bookshelf
setblock 1 192 486 minecraft:bookshelf
setblock 1 192 493 minecraft:bookshelf
setblock 1 192 500 minecraft:bookshelf
setblock 4 192 504 minecraft:bookshelf
setblock 7 192 464 minecraft:bookshelf
setblock 11 192 504 minecraft:bookshelf
fill 14 192 464 16 192 464 minecraft:bookshelf
fill 15 192 465 19 192 466 minecraft:bookshelf
fill 18 192 464 19 193 464 minecraft:bookshelf
setblock 18 192 504 minecraft:bookshelf
fill 21 192 464 21 194 464 minecraft:bookshelf
setblock 25 192 504 minecraft:bookshelf
setblock 28 192 464 minecraft:bookshelf
setblock 32 192 504 minecraft:bookshelf
setblock 35 192 464 minecraft:bookshelf
setblock 39 192 504 minecraft:bookshelf
setblock 41 192 465 minecraft:bookshelf
setblock 41 192 472 minecraft:bookshelf
setblock 41 192 479 minecraft:bookshelf
setblock 41 192 486 minecraft:bookshelf
setblock 41 192 493 minecraft:bookshelf
setblock 41 192 500 minecraft:bookshelf
setblock 1 193 466 minecraft:bookshelf
setblock 1 193 473 minecraft:bookshelf
setblock 1 193 480 minecraft:bookshelf
setblock 1 193 487 minecraft:bookshelf
setblock 1 193 494 minecraft:bookshelf
setblock 1 193 501 minecraft:bookshelf
setblock 5 193 504 minecraft:bookshelf
setblock 6 193 464 minecraft:bookshelf
setblock 12 193 504 minecraft:bookshelf
setblock 13 193 464 minecraft:bookshelf
fill 18 193 465 22 193 466 minecraft:bookshelf
setblock 19 193 504 minecraft:bookshelf
setblock 20 193 464 minecraft:bookshelf
fill 22 193 464 22 194 464 minecraft:bookshelf
setblock 26 193 504 minecraft:bookshelf
setblock 27 193 464 minecraft:bookshelf
setblock 33 193 504 minecraft:bookshelf
setblock 34 193 464 minecraft:bookshelf
setblock 40 193 504 minecraft:bookshelf
setblock 41 193 464 minecraft:bookshelf
setblock 41 193 471 minecraft:bookshelf
setblock 41 193 478 minecraft:bookshelf
setblock 41 193 485 minecraft:bookshelf
setblock 41 193 492 minecraft:bookshelf
setblock 41 193 499 minecraft:bookshelf
setblock 1 194 467 minecraft:bookshelf
setblock 1 194 474 minecraft:bookshelf
setblock 1 194 481 minecraft:bookshelf
setblock 1 194 488 minecraft:bookshelf
setblock 1 194 495 minecraft:bookshelf
setblock 1 194 502 minecraft:bookshelf
setblock 5 194 464 minecraft:bookshelf
setblock 6 194 504 minecraft:bookshelf
setblock 12 194 464 minecraft:bookshelf
setblock 13 194 504 minecraft:bookshelf
setblock 19 194 464 minecraft:bookshelf
setblock 20 194 504 minecraft:bookshelf
fill 21 194 465 25 194 466 minecraft:bookshelf
setblock 23 194 464 minecraft:bookshelf
fill 25 194 464 26 195 464 minecraft:bookshelf
setblock 27 194 504 minecraft:bookshelf
setblock 33 194 464 minecraft:bookshelf
setblock 34 194 504 minecraft:bookshelf
setblock 40 194 464 minecraft:bookshelf
setblock 41 194 470 minecraft:bookshelf
setblock 41 194 477 minecraft:bookshelf
setblock 41 194 484 minecraft:bookshelf
setblock 41 194 491 minecraft:bookshelf
setblock 41 194 498 minecraft:bookshelf
setblock 41 194 504 minecraft:bookshelf
setblock 1 195 468 minecraft:bookshelf
setblock 1 195 475 minecraft:bookshelf
setblock 1 195 482 minecraft:bookshelf
setblock 1 195 489 minecraft:bookshelf
setblock 1 195 496 minecraft:bookshelf
setblock 1 195 503 minecraft:bookshelf
setblock 4 195 464 minecraft:bookshelf
setblock 7 195 504 minecraft:bookshelf
setblock 11 195 464 minecraft:bookshelf
setblock 14 195 504 minecraft:bookshelf
setblock 18 195 464 minecraft:bookshelf
setblock 21 195 504 minecraft:bookshelf
fill 24 195 465 28 195 466 minecraft:bookshelf
fill 27 195 464 29 195 464 minecraft:bookshelf
fill 27 195 470 29 196 470 minecraft:white_wool
fill 28 195 469 28 196 469 minecraft:white_wool
fill 28 195 471 28 196 471 minecraft:white_wool
setblock 28 195 504 minecraft:bookshelf
fill 32 195 464 32 197 464 minecraft:bookshelf
setblock 35 195 504 minecraft:bookshelf
setblock 39 195 464 minecraft:bookshelf
setblock 41 195 469 minecraft:bookshelf
setblock 41 195 476 minecraft:bookshelf
setblock 41 195 483 minecraft:bookshelf
setblock 41 195 490 minecraft:bookshelf
setblock 41 195 497 minecraft:bookshelf
fill 27 196 465 32 196 466 minecraft:bookshelf
fill 28 196 464 30 196 464 minecraft:bookshelf
fill 33 196 464 33 197 464 minecraft:bookshelf
setblock 1 197 470 minecraft:bookshelf
setblock 1 197 477 minecraft:bookshelf
setblock 1 197 484 minecraft:bookshelf
setblock 1 197 491 minecraft:bookshelf
setblock 1 197 498 minecraft:bookshelf
setblock 2 197 464 minecraft:bookshelf
setblock 2 197 504 minecraft:bookshelf
setblock 9 197 464 minecraft:bookshelf
setblock 9 197 504 minecraft:bookshelf
fill 11 197 489 12 198 490 minecraft:blue_wool
fill 12 197 480 12 198 480 minecraft:blue_wool
setblock 16 197 464 minecraft:bookshelf
setblock 16 197 504 minecraft:bookshelf
setblock 23 197 464 minecraft:bookshelf
setblock 23 197 504 minecraft:bookshelf
setblock 30 197 464 minecraft:bookshelf
fill 30 197 466 36 197 466 minecraft:bookshelf
setblock 30 197 504 minecraft:bookshelf
fill 31 197 465 37 197 465 minecraft:bookshelf
fill 34 197 464 37 197 464 minecraft:bookshelf
setblock 37 197 504 minecraft:bookshelf
setblock 41 197 467 minecraft:bookshelf
setblock 41 197 474 minecraft:bookshelf
setblock 41 197 481 minecraft:bookshelf
setblock 41 197 488 minecraft:bookshelf
setblock 41 197 495 minecraft:bookshelf
setblock 41 197 502 minecraft:bookshelf
fill 0 198 463 0 199 466 minecraft:bookshelf
setblock 0 198 467 minecraft:dark_oak_planks
fill 0 198 469 0 201 469 minecraft:bookshelf
fill 0 198 470 0 199 470 minecraft:dark_oak_planks
fill 0 198 471 0 199 475 minecraft:bookshelf
fill 0 198 479 0 201 479 minecraft:bookshelf
setblock 0 198 480 minecraft:dark_oak_planks
fill 0 198 485 0 201 487 minecraft:bookshelf
fill 0 198 488 0 199 488 minecraft:dark_oak_planks
fill 0 198 489 0 201 491 minecraft:bookshelf
setblock 0 198 492 minecraft:dark_oak_planks
setblock 0 198 500 minecraft:dark_oak_planks
fill 0 198 501 0 198 505 minecraft:bookshelf
setblock 1 198 464 minecraft:bookshelf
setblock 1 198 471 minecraft:bookshelf
setblock 1 198 478 minecraft:bookshelf
setblock 1 198 485 minecraft:bookshelf
setblock 1 198 492 minecraft:bookshelf
setblock 1 198 499 minecraft:bookshelf
fill 2 198 497 3 199 497 minecraft:gold_block
setblock 3 198 463 minecraft:dark_oak_planks
setblock 3 198 466 minecraft:light[level=12]
setblock 3 198 474 minecraft:light[level=12]
setblock 3 198 482 minecraft:light[level=12]
setblock 3 198 490 minecraft:light[level=12]
setblock 3 198 498 minecraft:light[level=12]
setblock 3 198 504 minecraft:bookshelf
setblock 7 198 505 minecraft:dark_oak_planks
fill 8 198 463 8 198 464 minecraft:bookshelf
fill 8 198 505 8 201 505 minecraft:bookshelf
setblock 9 198 463 minecraft:dark_oak_planks
setblock 10 198 504 minecraft:bookshelf
setblock 11 198 466 minecraft:light[level=12]
setblock 11 198 474 minecraft:light[level=12]
setblock 11 198 482 minecraft:light[level=12]
setblock 11 198 498 minecraft:light[level=12]
fill 14 198 467 15 199 467 minecraft:red_wool
setblock 15 198 464 minecraft:bookshelf
fill 15 198 468 15 199 468 minecraft:red_wool
setblock 17 198 504 minecraft:bookshelf
setblock 19 198 466 minecraft:light[level=12]
setblock 19 198 474 minecraft:light[level=12]
setblock 19 198 482 minecraft:light[level=12]
setblock 19 198 490 minecraft:light[level=12]
setblock 19 198 498 minecraft:light[level=12]
fill 19 198 505 19 199 505 minecraft:dark_oak_planks
setblock 20 198 505 minecraft:bookshelf
setblock 22 198 464 minecraft:bookshelf
fill 22 198 505 22 201 505 minecraft:bookshelf
fill 23 198 463 24 198 463 minecraft:bookshelf
setblock 23 198 505 minecraft:dark_oak_planks
fill 24 198 504 24 198 505 minecraft:bookshelf
setblock 25 198 463 minecraft:dark_oak_planks
fill 25 198 505 32 198 505 minecraft:bookshelf
setblock 26 198 463 minecraft:bookshelf
setblock 27 198 466 minecraft:light[level=12]
setblock 27 198 474 minecraft:light[level=12]
setblock 27 198 482 minecraft:light[level=12]
setblock 27 198 490 minecraft:light[level=12]
setblock 27 198 498 minecraft:light[level=12]
setblock 29 198 464 minecraft:bookshelf
setblock 31 198 504 minecraft:bookshelf
fill 33 198 463 33 201 463 minecraft:bookshelf
setblock 33 198 505 minecraft:dark_oak_planks
setblock 34 198 463 minecraft:dark_oak_planks
fill 34 198 466 41 198 466 minecraft:bookshelf
fill 34 198 505 34 199 505 minecraft:bookshelf
fill 35 198 463 38 201 463 minecraft:bookshelf
fill 35 198 465 41 198 465 minecraft:bookshelf
setblock 35 198 474 minecraft:light[level=12]
setblock 35 198 482 minecraft:light[level=12]
setblock 35 198 490 minecraft:light[level=12]
setblock 35 198 498 minecraft:light[level=12]
fill 36 198 464 37 198 464 minecraft:bookshelf
fill 37 198 505 38 198 505 minecraft:dark_oak_planks
setblock 38 198 504 minecraft:bookshelf
setblock 39 198 463 minecraft:dark_oak_planks
fill 39 198 464 41 198 464 minecraft:bookshelf
fill 39 198 467 39 199 468 minecraft:bookshelf
fill 39 198 505 41 199 505 minecraft:bookshelf
fill 40 198 463 42 201 463 minecraft:bookshelf
fill 40 198 467 40 199 467 minecraft:bookshelf
fill 41 198 473 42 198 473 minecraft:bookshelf
setblock 41 198 480 minecraft:bookshelf
setblock 41 198 487 minecraft:bookshelf
setblock 41 198 494 minecraft:bookshelf
setblock 41 198 501 minecraft:bookshelf
setblock 42 198 464 minecraft:dark_oak_planks
setblock 42 198 471 minecraft:dark_oak_planks
setblock 42 198 472 minecraft:bookshelf
fill 42 198 487 42 198 488 minecraft:dark_oak_planks
fill 42 198 496 42 201 496 minecraft:bookshelf
setblock 42 198 497 minecraft:dark_oak_planks
setblock 42 198 499 minecraft:dark_oak_planks
setblock 0 199 467 minecraft:bookshelf
fill 0 199 480 0 202 480 minecraft:bookshelf
fill 0 199 492 0 201 492 minecraft:bookshelf
fill 0 199 494 0 199 497 minecraft:bookshelf
setblock 0 199 498 minecraft:dark_oak_planks
fill 0 199 499 0 199 502 minecraft:bookshelf
fill 0 199 503 0 199 504 minecraft:dark_oak_planks
fill 0 199 505 0 201 505 minecraft:bookshelf
setblock 1 199 463 minecraft:dark_oak_planks
fill 1 199 465 1 200 465 minecraft:bookshelf
fill 1 199 472 1 200 472 minecraft:bookshelf
fill 1 199 479 1 200 479 minecraft:bookshelf
fill 1 199 486 1 200 486 minecraft:bookshelf
fill 1 199 493 1 200 493 minecraft:bookshelf
fill 1 199 500 1 200 500 minecraft:bookshelf
fill 3 199 463 3 201 463 minecraft:bookshelf
fill 4 199 504 4 200 504 minecraft:bookshelf
fill 5 199 463 6 199 463 minecraft:dark_oak_planks
fill 7 199 463 7 199 464 minecraft:bookshelf
fill 7 199 505 7 201 505 minecraft:bookshelf
fill 8 199 463 9 201 463 minecraft:bookshelf
fill 11 199 504 11 200 504 minecraft:bookshelf
fill 14 199 464 14 200 464 minecraft:bookshelf
fill 14 199 505 17 201 505 minecraft:bookshelf
setblock 15 199 463 minecraft:dark_oak_planks
fill 16 199 463 17 201 463 minecraft:bookshelf
fill 18 199 463 19 199 463 minecraft:dark_oak_planks
fill 18 199 504 18 200 504 minecraft:bookshelf
setblock 18 199 505 minecraft:dark_oak_planks
fill 20 199 463 21 199 463 minecraft:bookshelf
setblock 20 199 505 minecraft:dark_oak_planks
fill 21 199 464 21 200 464 minecraft:bookshelf
fill 23 199 463 23 201 463 minecraft:bookshelf
fill 23 199 505 23 201 505 minecraft:bookshelf
setblock 24 199 463 minecraft:dark_oak_planks
setblock 24 199 505 minecraft:dark_oak_planks
fill 25 199 463 25 201 463 minecraft:bookshelf
fill 25 199 504 25 200 505 minecraft:bookshelf
fill 26 199 463 26 200 463 minecraft:dark_oak_planks
fill 26 199 505 26 200 505 minecraft:dark_oak_planks
fill 27 199 505 33 199 505 minecraft:bookshelf
fill 28 199 464 28 200 464 minecraft:bookshelf
fill 32 199 504 32 200 504 minecraft:bookshelf
fill 34 199 463 34 201 463 minecraft:bookshelf
fill 35 199 464 35 200 464 minecraft:bookshelf
setblock 35 199 505 minecraft:dark_oak_planks
fill 37 199 505 37 200 505 minecraft:dark_oak_planks
fill 38 199 505 38 201 505 minecraft:bookshelf
fill 39 199 463 39 204 463 minecraft:bookshelf
fill 39 199 466 42 199 466 minecraft:bookshelf
fill 39 199 469 41 199 472 minecraft:bookshelf
fill 39 199 504 39 200 504 minecraft:bookshelf
fill 40 199 465 42 199 465 minecraft:bookshelf
setblock 40 199 468 minecraft:bookshelf
fill 41 199 464 42 200 464 minecraft:bookshelf
fill 41 199 467 42 200 467 minecraft:bookshelf
fill 41 199 479 41 202 479 minecraft:bookshelf
fill 41 199 486 41 200 486 minecraft:bookshelf
fill 41 199 493 41 200 493 minecraft:bookshelf
fill 41 199 500 41 200 500 minecraft:bookshelf
fill 42 199 468 42 201 469 minecraft:bookshelf
setblock 42 199 470 minecraft:dark_oak_planks
fill 42 199 471 42 201 471 minecraft:bookshelf
setblock 42 199 472 minecraft:dark_oak_planks
fill 42 199 473 42 201 473 minecraft:bookshelf
fill 42 199 487 42 201 488 minecraft:bookshelf
setblock 42 199 497 minecraft:bookshelf
fill 42 199 499 42 201 499 minecraft:bookshelf
setblock 0 200 463 minecraft:dark_oak_planks
fill 0 200 464 0 201 466 minecraft:bookshelf
setblock 0 200 467 minecraft:dark_oak_planks
fill 0 200 470 1 200 470 minecraft:bookshelf
setblock 0 200 471 minecraft:dark_oak_planks
fill 0 200 472 0 201 472 minecraft:bookshelf
setblock 0 200 473 minecraft:dark_oak_planks
fill 0 200 474 1 201 474 minecraft:bookshelf
fill 0 200 475 0 200 476 minecraft:dark_oak_planks
fill 0 200 488 1 201 488 minecraft:bookshelf
fill 0 200 494 1 200 494 minecraft:bookshelf
setblock 0 200 495 minecraft:dark_oak_planks
fill 0 200 496 0 201 501 minecraft:bookshelf
setblock 0 200 502 minecraft:dark_oak_planks
fill 0 200 503 1 200 503 minecraft:bookshelf
setblock 0 200 504 minecraft:dark_oak_planks
fill 1 200 463 1 200 464 minecraft:bookshelf
fill 1 200 466 1 200 468 minecraft:bookshelf
setblock 1 200 471 minecraft:bookshelf
setblock 1 200 473 minecraft:bookshelf
setblock 1 200 475 minecraft:bookshelf
fill 1 200 477 1 200 478 minecraft:bookshelf
fill 1 200 480 1 200 482 minecraft:bookshelf
fill 1 200 484 1 200 485 minecraft:bookshelf
setblock 1 200 487 minecraft:bookshelf
setblock 1 200 489 minecraft:bookshelf
fill 1 200 491 1 200 492 minecraft:bookshelf
fill 1 200 495 1 200 496 minecraft:bookshelf
fill 1 200 498 1 200 499 minecraft:bookshelf
fill 1 200 501 1 200 502 minecraft:bookshelf
setblock 2 200 464 minecraft:bookshelf
fill 2 200 504 3 200 504 minecraft:bookshelf
fill 4 200 464 9 200 464 minecraft:bookshelf
fill 5 200 463 6 201 463 minecraft:bookshelf
fill 5 200 504 7 200 504 minecraft:bookshelf
setblock 7 200 463 minecraft:dark_oak_planks
fill 9 200 504 10 200 504 minecraft:bookshelf
setblock 9 200 505 minecraft:dark_oak_planks
fill 11 200 464 13 200 464 minecraft:bookshelf
fill 12 200 504 14 200 504 minecraft:bookshelf
fill 15 200 463 15 200 464 minecraft:bookshelf
setblock 16 200 464 minecraft:bookshelf
fill 16 200 504 17 200 504 minecraft:bookshelf
fill 18 200 463 20 200 464 minecraft:bookshelf
fill 18 200 505 20 201 505 minecraft:bookshelf
fill 19 200 504 21 200 504 minecraft:bookshelf
setblock 21 200 463 minecraft:dark_oak_planks
setblock 21 200 505 minecraft:dark_oak_planks
fill 22 200 464 23 200 464 minecraft:bookshelf
fill 23 200 504 24 200 504 minecraft:bookshelf
fill 24 200 463 24 201 463 minecraft:bookshelf
fill 24 200 505 24 202 505 minecraft:bookshelf
fill 25 200 464 27 200 464 minecraft:bookshelf
fill 26 200 504 28 200 504 minecraft:bookshelf
setblock 27 200 463 minecraft:dark_oak_planks
fill 27 200 505 31 201 505 minecraft:bookshelf
fill 28 200 463 31 201 463 minecraft:bookshelf
fill 29 200 464 30 200 464 minecraft:bookshelf
fill 30 200 504 31 200 504 minecraft:bookshelf
fill 32 200 464 34 200 464 minecraft:bookshelf
setblock 32 200 505 minecraft:dark_oak_planks
fill 33 200 504 33 200 505 minecraft:bookshelf
fill 34 200 504 35 200 504 minecraft:bookshelf
setblock 34 200 505 minecraft:dark_oak_planks
fill 35 200 505 35 201 505 minecraft:bookshelf
fill 36 200 464 37 200 464 minecraft:bookshelf
fill 37 200 504 38 200 504 minecraft:bookshelf
fill 39 200 464 40 200 464 minecraft:bookshelf
fill 39 200 471 40 200 476 minecraft:bookshelf
setblock 39 200 505 minecraft:dark_oak_planks
fill 40 200 470 42 200 470 minecraft:bookshelf
fill 40 200 504 41 200 505 minecraft:bookshelf
fill 41 200 465 42 200 466 minecraft:bookshelf
setblock 41 200 469 minecraft:bookshelf
fill 41 200 471 41 200 474 minecraft:bookshelf
fill 41 200 476 41 201 478 minecraft:bookshelf
fill 41 200 480 41 200 481 minecraft:bookshelf
fill 41 200 483 41 200 485 minecraft:bookshelf
fill 41 200 487 41 200 488 minecraft:bookshelf
fill 41 200 490 41 200 492 minecraft:bookshelf
fill 41 200 494 41 200 495 minecraft:bookshelf
fill 41 200 497 41 200 499 minecraft:bookshelf
fill 41 200 501 41 200 502 minecraft:bookshelf
fill 42 200 472 42 201 472 minecraft:bookshelf
setblock 42 200 491 minecraft:dark_oak_planks
fill 42 200 497 42 200 498 minecraft:dark_oak_planks
setblock 42 200 503 minecraft:dark_oak_planks
fill 0 201 463 1 201 463 minecraft:bookshelf
fill 0 201 467 1 201 467 minecraft:bookshelf
fill 0 201 470 0 201 471 minecraft:bookshelf
setblock 0 201 473 minecraft:bookshelf
fill 0 201 475 0 201 476 minecraft:bookshelf
fill 0 201 494 0 201 495 minecraft:bookshelf
fill 0 201 502 0 201 504 minecraft:bookshelf
setblock 1 201 481 minecraft:bookshelf
setblock 1 201 495 minecraft:bookshelf
setblock 1 201 502 minecraft:bookshelf
setblock 5 201 464 minecraft:bookshelf
setblock 6 201 504 minecraft:bookshelf
setblock 7 201 463 minecraft:bookshelf
setblock 9 201 505 minecraft:bookshelf
setblock 12 201 464 minecraft:bookshelf
setblock 13 201 504 minecraft:bookshelf
setblock 15 201 463 minecraft:bookshelf
fill 18 201 463 21 201 463 minecraft:bookshelf
setblock 19 201 464 minecraft:bookshelf
setblock 20 201 504 minecraft:bookshelf
setblock 21 201 505 minecraft:bookshelf
fill 25 201 505 26 201 505 minecraft:bookshelf
fill 26 201 463 26 201 464 minecraft:bookshelf
setblock 27 201 463 minecraft:bookshelf
setblock 27 201 504 minecraft:bookshelf
fill 32 201 505 34 201 505 minecraft:bookshelf
setblock 33 201 464 minecraft:bookshelf
setblock 34 201 504 minecraft:bookshelf
setblock 37 201 505 minecraft:bookshelf
fill 39 201 475 40 201 479 minecraft:bookshelf
fill 39 201 505 41 201 505 minecraft:bookshelf
setblock 40 201 464 minecraft:bookshelf
fill 40 201 474 41 201 474 minecraft:bookshelf
fill 41 201 470 42 201 470 minecraft:bookshelf
setblock 41 201 484 minecraft:bookshelf
fill 41 201 491 42 201 491 minecraft:bookshelf
fill 41 201 498 42 201 498 minecraft:bookshelf
setblock 41 201 504 minecraft:bookshelf
fill 42 201 464 42 201 467 minecraft:bookshelf
setblock 42 201 497 minecraft:bookshelf
setblock 42 201 503 minecraft:bookshelf
fill 0 202 463 0 202 464 minecraft:dark_oak_planks
setblock 0 202 465 minecraft:bookshelf
fill 0 202 466 0 202 479 minecraft:dark_oak_planks
fill 0 202 481 0 202 486 minecraft:dark_oak_planks
setblock 0 202 487 minecraft:bookshelf
fill 0 202 488 0 307 488 minecraft:dark_oak_planks
fill 0 202 489 1 202 489 minecraft:bookshelf
fill 0 202 490 0 202 497 minecraft:dark_oak_planks
fill 0 202 498 0 203 498 minecraft:bookshelf
fill 0 202 499 0 202 505 minecraft:dark_oak_planks
fill 1 202 463 8 203 463 minecraft:dark_oak_planks
setblock 1 202 468 minecraft:bookshelf
setblock 1 202 475 minecraft:bookshelf
setblock 1 202 482 minecraft:bookshelf
setblock 1 202 496 minecraft:bookshelf
setblock 1 202 503 minecraft:bookshelf
fill 1 202 505 23 202 505 minecraft:dark_oak_planks
setblock 4 202 464 minecraft:bookshelf
setblock 7 202 504 minecraft:bookshelf
setblock 9 202 463 minecraft:bookshelf
fill 10 202 463 25 202 463 minecraft:dark_oak_planks
setblock 11 202 464 minecraft:bookshelf
setblock 14 202 504 minecraft:bookshelf
setblock 18 202 464 minecraft:bookshelf
setblock 21 202 504 minecraft:bookshelf
setblock 25 202 464 minecraft:bookshelf
fill 25 202 505 38 307 505 minecraft:dark_oak_planks
setblock 26 202 463 minecraft:bookshelf
fill 27 202 463 31 203 463 minecraft:dark_oak_planks
setblock 28 202 504 minecraft:bookshelf
setblock 32 202 464 minecraft:bookshelf
fill 33 202 463 38 203 463 minecraft:dark_oak_planks
setblock 35 202 504 minecraft:bookshelf
setblock 39 202 464 minecraft:bookshelf
fill 39 202 478 40 202 482 minecraft:bookshelf
setblock 39 202 505 minecraft:bookshelf
fill 40 202 463 40 307 463 minecraft:dark_oak_planks
fill 40 202 505 41 307 505 minecraft:dark_oak_planks
fill 41 202 463 42 202 463 minecraft:bookshelf
setblock 41 202 469 minecraft:bookshelf
setblock 41 202 476 minecraft:bookshelf
setblock 41 202 478 minecraft:bookshelf
fill 41 202 480 41 202 481 minecraft:bookshelf
fill 41 202 483 41 203 483 minecraft:bookshelf
setblock 41 202 490 minecraft:bookshelf
setblock 41 202 497 minecraft:bookshelf
fill 42 202 464 42 202 486 minecraft:dark_oak_planks
setblock 42 202 487 minecraft:bookshelf
fill 42 202 488 42 307 488 minecraft:dark_oak_planks
setblock 42 202 489 minecraft:bookshelf
fill 42 202 490 42 202 504 minecraft:dark_oak_planks
fill 0 203 463 0 204 463 minecraft:bookshelf
fill 0 203 464 0 203 474 minecraft:dark_oak_planks
setblock 0 203 475 minecraft:bookshelf
fill 0 203 476 0 307 482 minecraft:dark_oak_planks
setblock 0 203 483 minecraft:bookshelf
fill 0 203 484 0 203 487 minecraft:dark_oak_planks
fill 0 203 489 0 307 489 minecraft:dark_oak_planks
setblock 0 203 490 minecraft:bookshelf
fill 0 203 491 0 203 497 minecraft:dark_oak_planks
fill 0 203 499 0 307 499 minecraft:dark_oak_planks
setblock 0 203 500 minecraft:bookshelf
fill 0 203 501 0 307 505 minecraft:dark_oak_planks
fill 1 203 505 21 203 505 minecraft:dark_oak_planks
fill 9 203 463 15 203 463 minecraft:dark_oak_planks
setblock 16 203 463 minecraft:bookshelf
fill 17 203 463 18 307 463 minecraft:dark_oak_planks
setblock 19 203 463 minecraft:bookshelf
fill 20 203 463 20 307 463 minecraft:dark_oak_planks
setblock 21 203 463 minecraft:bookshelf
fill 22 203 463 26 203 463 minecraft:dark_oak_planks
fill 22 203 505 23 203 505 minecraft:bookshelf
fill 24 203 505 24 307 505 minecraft:dark_oak_planks
fill 39 203 481 40 203 485 minecraft:bookshelf
fill 39 203 505 39 307 505 minecraft:dark_oak_planks
fill 41 203 463 42 307 463 minecraft:dark_oak_planks
fill 41 203 481 41 204 481 minecraft:bookshelf
fill 41 203 484 41 204 485 minecraft:bookshelf
fill 42 203 464 42 203 481 minecraft:dark_oak_planks
setblock 42 203 482 minecraft:bookshelf
fill 42 203 483 42 307 485 minecraft:dark_oak_planks
setblock 42 203 486 minecraft:bookshelf
fill 42 203 487 42 307 487 minecraft:dark_oak_planks
fill 42 203 489 42 307 489 minecraft:dark_oak_planks
setblock 42 203 490 minecraft:bookshelf
fill 42 203 491 42 203 505 minecraft:dark_oak_planks
fill 0 204 464 0 307 469 minecraft:dark_oak_planks
fill 0 204 470 1 204 470 minecraft:bookshelf
fill 0 204 471 0 307 472 minecraft:dark_oak_planks
setblock 0 204 473 minecraft:bookshelf
fill 0 204 474 0 307 475 minecraft:dark_oak_planks
fill 0 204 483 0 307 484 minecraft:dark_oak_planks
setblock 0 204 485 minecraft:bookshelf
fill 0 204 486 0 307 487 minecraft:dark_oak_planks
fill 0 204 490 0 307 493 minecraft:dark_oak_planks
setblock 0 204 494 minecraft:bookshelf
fill 0 204 495 0 307 496 minecraft:dark_oak_planks
setblock 0 204 497 minecraft:bookshelf
fill 0 204 498 0 307 498 minecraft:dark_oak_planks
fill 0 204 500 0 307 500 minecraft:dark_oak_planks
fill 1 204 463 2 307 463 minecraft:dark_oak_planks
setblock 1 204 477 minecraft:bookshelf
setblock 1 204 484 minecraft:bookshelf
setblock 1 204 491 minecraft:bookshelf
setblock 1 204 498 minecraft:bookshelf
fill 1 204 505 1 307 505 minecraft:dark_oak_planks
setblock 2 204 464 minecraft:bookshelf
fill 2 204 504 2 204 505 minecraft:bookshelf
fill 3 204 463 4 204 463 minecraft:bookshelf
fill 3 204 505 8 307 505 minecraft:dark_oak_planks
fill 5 204 463 10 307 463 minecraft:dark_oak_planks
setblock 9 204 464 minecraft:bookshelf
fill 9 204 504 9 204 505 minecraft:bookshelf
fill 10 204 505 23 307 505 minecraft:dark_oak_planks
setblock 11 204 463 minecraft:bookshelf
fill 12 204 463 16 307 463 minecraft:dark_oak_planks
setblock 16 204 464 minecraft:bookshelf
setblock 16 204 504 minecraft:bookshelf
fill 19 204 463 19 307 463 minecraft:dark_oak_planks
fill 21 204 463 22 307 463 minecraft:dark_oak_planks
fill 23 204 463 23 204 464 minecraft:bookshelf
setblock 23 204 504 minecraft:bookshelf
fill 24 204 463 27 307 463 minecraft:dark_oak_planks
fill 28 204 463 29 204 463 minecraft:bookshelf
fill 30 204 463 31 307 463 minecraft:dark_oak_planks
setblock 30 204 464 minecraft:bookshelf
setblock 30 204 504 minecraft:bookshelf
fill 33 204 463 33 307 463 minecraft:dark_oak_planks
setblock 34 204 463 minecraft:bookshelf
fill 35 204 463 38 307 463 minecraft:dark_oak_planks
setblock 37 204 464 minecraft:bookshelf
setblock 37 204 504 minecraft:bookshelf
fill 39 204 484 40 204 488 minecraft:bookshelf
setblock 41 204 467 minecraft:bookshelf
setblock 41 204 474 minecraft:bookshelf
fill 41 204 486 41 204 488 minecraft:bookshelf
setblock 41 204 495 minecraft:bookshelf
setblock 41 204 502 minecraft:bookshelf
setblock 42 204 464 minecraft:bookshelf
fill 42 204 465 42 307 482 minecraft:dark_oak_planks
fill 42 204 486 42 307 486 minecraft:dark_oak_planks
fill 42 204 490 42 307 496 minecraft:dark_oak_planks
setblock 42 204 497 minecraft:bookshelf
fill 42 204 498 42 307 504 minecraft:dark_oak_planks
setblock 42 204 505 minecraft:bookshelf
fill 0 205 463 0 307 463 minecraft:dark_oak_planks
fill 0 205 470 0 307 470 minecraft:dark_oak_planks
fill 0 205 473 0 307 473 minecraft:dark_oak_planks
fill 0 205 485 0 307 485 minecraft:dark_oak_planks
fill 0 205 494 0 307 494 minecraft:dark_oak_planks
fill 0 205 497 0 307 497 minecraft:dark_oak_planks
setblock 1 205 464 minecraft:bookshelf
setblock 1 205 471 minecraft:bookshelf
setblock 1 205 478 minecraft:bookshelf
setblock 1 205 485 minecraft:bookshelf
setblock 1 205 492 minecraft:bookshelf
setblock 1 205 499 minecraft:bookshelf
fill 2 205 505 2 307 505 minecraft:dark_oak_planks
fill 3 205 463 4 307 463 minecraft:dark_oak_planks
setblock 3 205 504 minecraft:bookshelf
setblock 8 205 464 minecraft:bookshelf
fill 9 205 505 9 307 505 minecraft:dark_oak_planks
setblock 10 205 504 minecraft:bookshelf
fill 11 205 463 11 307 463 minecraft:dark_oak_planks
setblock 15 205 464 minecraft:bookshelf
setblock 17 205 504 minecraft:bookshelf
setblock 22 205 464 minecraft:bookshelf
fill 23 205 463 23 307 463 minecraft:dark_oak_planks
setblock 24 205 504 minecraft:bookshelf
fill 28 205 463 29 307 463 minecraft:dark_oak_planks
setblock 29 205 464 minecraft:bookshelf
setblock 31 205 504 minecraft:bookshelf
fill 32 205 463 32 307 463 minecraft:dark_oak_planks
fill 34 205 463 34 307 463 minecraft:dark_oak_planks
setblock 36 205 464 minecraft:bookshelf
setblock 38 205 504 minecraft:bookshelf
fill 39 205 463 39 307 463 minecraft:dark_oak_planks
fill 39 205 487 40 205 491 minecraft:bookshelf
setblock 41 205 466 minecraft:bookshelf
setblock 41 205 473 minecraft:bookshelf
setblock 41 205 480 minecraft:bookshelf
fill 41 205 487 41 205 488 minecraft:bookshelf
fill 41 205 490 41 205 492 minecraft:bookshelf
fill 41 205 494 41 207 494 minecraft:bookshelf
setblock 41 205 501 minecraft:bookshelf
fill 42 205 464 42 307 464 minecraft:dark_oak_planks
fill 42 205 497 42 307 497 minecraft:dark_oak_planks
fill 42 205 505 42 307 505 minecraft:dark_oak_planks
setblock 1 206 465 minecraft:bookshelf
setblock 1 206 472 minecraft:bookshelf
setblock 1 206 479 minecraft:bookshelf
setblock 1 206 486 minecraft:bookshelf
setblock 1 206 493 minecraft:bookshelf
setblock 1 206 500 minecraft:bookshelf
setblock 3 206 466 minecraft:light[level=12]
setblock 3 206 474 minecraft:light[level=12]
setblock 3 206 482 minecraft:light[level=12]
setblock 3 206 490 minecraft:light[level=12]
setblock 3 206 498 minecraft:light[level=12]
setblock 4 206 504 minecraft:bookshelf
setblock 7 206 464 minecraft:bookshelf
setblock 11 206 466 minecraft:light[level=12]
setblock 11 206 474 minecraft:light[level=12]
setblock 11 206 482 minecraft:light[level=12]
setblock 11 206 490 minecraft:light[level=12]
setblock 11 206 498 minecraft:light[level=12]
setblock 11 206 504 minecraft:bookshelf
setblock 14 206 464 minecraft:bookshelf
setblock 18 206 504 minecraft:bookshelf
setblock 19 206 466 minecraft:light[level=12]
setblock 19 206 474 minecraft:light[level=12]
setblock 19 206 482 minecraft:light[level=12]
setblock 19 206 490 minecraft:light[level=12]
setblock 19 206 498 minecraft:light[level=12]
setblock 21 206 464 minecraft:bookshelf
setblock 25 206 504 minecraft:bookshelf
setblock 27 206 466 minecraft:light[level=12]
setblock 27 206 474 minecraft:light[level=12]
setblock 27 206 482 minecraft:light[level=12]
setblock 27 206 490 minecraft:light[level=12]
setblock 27 206 498 minecraft:light[level=12]
setblock 28 206 464 minecraft:bookshelf
setblock 32 206 504 minecraft:bookshelf
setblock 35 206 464 minecraft:bookshelf
setblock 35 206 466 minecraft:light[level=12]
setblock 35 206 474 minecraft:light[level=12]
setblock 35 206 482 minecraft:light[level=12]
setblock 35 206 490 minecraft:light[level=12]
setblock 35 206 498 minecraft:light[level=12]
fill 39 206 490 40 206 495 minecraft:bookshelf
setblock 39 206 504 minecraft:bookshelf
setblock 41 206 465 minecraft:bookshelf
setblock 41 206 472 minecraft:bookshelf
setblock 41 206 479 minecraft:bookshelf
setblock 41 206 486 minecraft:bookshelf
fill 41 206 491 41 206 493 minecraft:bookshelf
fill 41 206 495 41 207 495 minecraft:bookshelf
fill 41 206 500 41 208 500 minecraft:bookshelf
setblock 1 207 466 minecraft:bookshelf
setblock 1 207 473 minecraft:bookshelf
setblock 1 207 480 minecraft:bookshelf
setblock 1 207 487 minecraft:bookshelf
setblock 1 207 494 minecraft:bookshelf
setblock 1 207 501 minecraft:bookshelf
setblock 5 207 504 minecraft:bookshelf
setblock 6 207 464 minecraft:bookshelf
setblock 12 207 504 minecraft:bookshelf
setblock 13 207 464 minecraft:bookshelf
setblock 19 207 504 minecraft:bookshelf
setblock 20 207 464 minecraft:bookshelf
setblock 26 207 504 minecraft:bookshelf
setblock 27 207 464 minecraft:bookshelf
setblock 33 207 504 minecraft:bookshelf
setblock 34 207 464 minecraft:bookshelf
fill 39 207 493 39 207 499 minecraft:bookshelf
fill 40 207 494 40 207 500 minecraft:bookshelf
fill 40 207 504 40 210 504 minecraft:bookshelf
setblock 41 207 464 minecraft:bookshelf
setblock 41 207 471 minecraft:bookshelf
setblock 41 207 478 minecraft:bookshelf
setblock 41 207 485 minecraft:bookshelf
setblock 41 207 492 minecraft:bookshelf
fill 41 207 497 41 207 499 minecraft:bookshelf
fill 41 207 501 41 208 501 minecraft:bookshelf
setblock 1 208 467 minecraft:bookshelf
setblock 1 208 474 minecraft:bookshelf
setblock 1 208 481 minecraft:bookshelf
setblock 1 208 488 minecraft:bookshelf
setblock 1 208 495 minecraft:bookshelf
setblock 1 208 502 minecraft:bookshelf
setblock 5 208 464 minecraft:bookshelf
setblock 6 208 504 minecraft:bookshelf
setblock 12 208 464 minecraft:bookshelf
setblock 13 208 504 minecraft:bookshelf
setblock 19 208 464 minecraft:bookshelf
setblock 20 208 504 minecraft:bookshelf
setblock 26 208 464 minecraft:bookshelf
setblock 27 208 504 minecraft:bookshelf
setblock 33 208 464 minecraft:bookshelf
fill 34 208 504 34 210 504 minecraft:bookshelf
fill 37 208 502 41 208 502 minecraft:bookshelf
fill 38 208 503 40 209 503 minecraft:bookshelf
fill 39 208 497 39 208 501 minecraft:bookshelf
fill 39 208 504 39 210 504 minecraft:bookshelf
setblock 40 208 464 minecraft:bookshelf
fill 40 208 498 40 208 501 minecraft:bookshelf
setblock 41 208 470 minecraft:bookshelf
setblock 41 208 477 minecraft:bookshelf
setblock 41 208 484 minecraft:bookshelf
setblock 41 208 491 minecraft:bookshelf
fill 41 208 498 41 208 499 minecraft:bookshelf
fill 41 208 504 41 210 504 minecraft:bookshelf
fill 1 209 468 1 210 468 minecraft:bookshelf
fill 1 209 475 1 210 475 minecraft:bookshelf
fill 1 209 482 1 210 482 minecraft:bookshelf
fill 1 209 489 1 210 489 minecraft:bookshelf
fill 1 209 496 1 210 496 minecraft:bookshelf
fill 1 209 503 1 210 503 minecraft:bookshelf
fill 4 209 464 4 210 464 minecraft:bookshelf
fill 7 209 504 7 210 504 minecraft:bookshelf
fill 11 209 464 11 210 464 minecraft:bookshelf
fill 14 209 504 14 210 504 minecraft:bookshelf
fill 18 209 464 18 210 464 minecraft:bookshelf
fill 21 209 504 21 210 504 minecraft:bookshelf
fill 25 209 464 25 210 464 minecraft:bookshelf
fill 28 209 504 28 211 504 minecraft:bookshelf
fill 32 209 464 32 210 464 minecraft:bookshelf
fill 33 209 502 37 209 503 minecraft:bookshelf
fill 35 209 504 35 210 504 minecraft:bookshelf
fill 37 209 504 38 210 504 minecraft:bookshelf
fill 38 209 502 39 209 502 minecraft:bookshelf
fill 39 209 464 39 210 464 minecraft:bookshelf
fill 41 209 469 41 210 469 minecraft:bookshelf
fill 41 209 476 41 210 476 minecraft:bookshelf
fill 41 209 483 41 210 483 minecraft:bookshelf
fill 41 209 490 41 210 490 minecraft:bookshelf
fill 41 209 497 41 210 497 minecraft:bookshelf
fill 1 210 464 1 210 467 minecraft:bookshelf
fill 1 210 470 1 210 474 minecraft:bookshelf
fill 1 210 477 1 210 481 minecraft:bookshelf
fill 1 210 484 1 210 488 minecraft:bookshelf
fill 1 210 491 1 210 495 minecraft:bookshelf
fill 1 210 498 1 210 502 minecraft:bookshelf
fill 2 210 464 2 211 464 minecraft:bookshelf
fill 2 210 504 6 210 504 minecraft:bookshelf
fill 5 210 464 9 210 464 minecraft:bookshelf
fill 9 210 504 13 210 504 minecraft:bookshelf
fill 12 210 464 16 210 464 minecraft:bookshelf
fill 16 210 504 20 210 504 minecraft:bookshelf
fill 19 210 464 23 210 464 minecraft:bookshelf
fill 23 210 504 27 210 504 minecraft:bookshelf
fill 26 210 464 30 210 464 minecraft:bookshelf
fill 29 210 502 34 210 503 minecraft:bookshelf
fill 30 210 504 33 210 504 minecraft:bookshelf
fill 33 210 464 37 210 464 minecraft:bookshelf
setblock 35 210 503 minecraft:bookshelf
fill 40 210 464 41 210 464 minecraft:bookshelf
fill 41 210 465 41 210 467 minecraft:bookshelf
fill 41 210 470 41 210 474 minecraft:bookshelf
fill 41 210 477 41 210 481 minecraft:bookshelf
fill 41 210 484 41 210 488 minecraft:bookshelf
fill 41 210 491 41 210 495 minecraft:bookshelf
fill 41 210 498 41 210 502 minecraft:bookshelf
setblock 1 211 470 minecraft:bookshelf
setblock 1 211 477 minecraft:bookshelf
setblock 1 211 484 minecraft:bookshelf
setblock 1 211 491 minecraft:bookshelf
setblock 1 211 498 minecraft:bookshelf
setblock 2 211 504 minecraft:bookshelf
setblock 9 211 464 minecraft:bookshelf
setblock 9 211 504 minecraft:bookshelf
setblock 16 211 464 minecraft:bookshelf
setblock 16 211 504 minecraft:bookshelf
setblock 23 211 464 minecraft:bookshelf
fill 23 211 504 23 213 504 minecraft:bookshelf
fill 26 211 502 27 212 504 minecraft:bookshelf
fill 28 211 502 30 211 503 minecraft:bookshelf
setblock 30 211 464 minecraft:bookshelf
fill 30 211 504 31 211 504 minecraft:bookshelf
setblock 31 211 503 minecraft:bookshelf
setblock 37 211 464 minecraft:bookshelf
setblock 37 211 504 minecraft:bookshelf
setblock 41 211 467 minecraft:bookshelf
setblock 41 211 474 minecraft:bookshelf
setblock 41 211 481 minecraft:bookshelf
setblock 41 211 488 minecraft:bookshelf
setblock 41 211 495 minecraft:bookshelf
setblock 41 211 502 minecraft:bookshelf
setblock 1 212 464 minecraft:bookshelf
setblock 1 212 471 minecraft:bookshelf
setblock 1 212 478 minecraft:bookshelf
setblock 1 212 485 minecraft:bookshelf
setblock 1 212 492 minecraft:bookshelf
setblock 1 212 499 minecraft:bookshelf
setblock 3 212 504 minecraft:bookshelf
setblock 8 212 464 minecraft:bookshelf
setblock 10 212 504 minecraft:bookshelf
setblock 15 212 464 minecraft:bookshelf
setblock 17 212 504 minecraft:bookshelf
setblock 22 212 464 minecraft:bookshelf
fill 23 212 502 25 212 503 minecraft:bookshelf
fill 24 212 504 25 213 504 minecraft:bookshelf
setblock 29 212 464 minecraft:bookshelf
setblock 31 212 504 minecraft:bookshelf
setblock 36 212 464 minecraft:bookshelf
setblock 38 212 504 minecraft:bookshelf
setblock 41 212 466 minecraft:bookshelf
setblock 41 212 473 minecraft:bookshelf
setblock 41 212 480 minecraft:bookshelf
setblock 41 212 487 minecraft:bookshelf
setblock 41 212 494 minecraft:bookshelf
setblock 41 212 501 minecraft:bookshelf
setblock 1 213 465 minecraft:bookshelf
setblock 1 213 472 minecraft:bookshelf
setblock 1 213 479 minecraft:bookshelf
setblock 1 213 486 minecraft:bookshelf
setblock 1 213 493 minecraft:bookshelf
setblock 1 213 500 minecraft:bookshelf
setblock 4 213 504 minecraft:bookshelf
setblock 7 213 464 minecraft:bookshelf
setblock 11 213 504 minecraft:bookshelf
setblock 14 213 464 minecraft:bookshelf
fill 18 213 504 18 215 504 minecraft:bookshelf
fill 20 213 502 21 214 504 minecraft:bookshelf
setblock 21 213 464 minecraft:bookshelf
fill 22 213 502 24 213 503 minecraft:bookshelf
setblock 28 213 464 minecraft:bookshelf
setblock 32 213 504 minecraft:bookshelf
setblock 35 213 464 minecraft:bookshelf
setblock 39 213 504 minecraft:bookshelf
setblock 41 213 465 minecraft:bookshelf
setblock 41 213 472 minecraft:bookshelf
setblock 41 213 479 minecraft:bookshelf
setblock 41 213 486 minecraft:bookshelf
setblock 41 213 493 minecraft:bookshelf
setblock 41 213 500 minecraft:bookshelf
setblock 1 214 466 minecraft:bookshelf
setblock 1 214 473 minecraft:bookshelf
setblock 1 214 480 minecraft:bookshelf
setblock 1 214 487 minecraft:bookshelf
setblock 1 214 494 minecraft:bookshelf
setblock 1 214 501 minecraft:bookshelf
setblock 3 214 466 minecraft:light[level=12]
setblock 3 214 474 minecraft:light[level=12]
setblock 3 214 482 minecraft:light[level=12]
setblock 3 214 490 minecraft:light[level=12]
setblock 3 214 498 minecraft:light[level=12]
setblock 5 214 504 minecraft:bookshelf
setblock 6 214 464 minecraft:bookshelf
setblock 11 214 466 minecraft:light[level=12]
setblock 11 214 474 minecraft:light[level=12]
setblock 11 214 482 minecraft:light[level=12]
setblock 11 214 490 minecraft:light[level=12]
setblock 11 214 498 minecraft:light[level=12]
setblock 12 214 504 minecraft:bookshelf
setblock 13 214 464 minecraft:bookshelf
fill 17 214 502 17 215 504 minecraft:bookshelf
fill 18 214 502 19 214 503 minecraft:bookshelf
setblock 19 214 466 minecraft:light[level=12]
setblock 19 214 474 minecraft:light[level=12]
setblock 19 214 482 minecraft:light[level=12]
setblock 19 214 490 minecraft:light[level=12]
setblock 19 214 498 minecraft:light[level=12]
setblock 19 214 504 minecraft:bookshelf
setblock 20 214 464 minecraft:bookshelf
setblock 26 214 504 minecraft:bookshelf
setblock 27 214 464 minecraft:bookshelf
setblock 27 214 466 minecraft:light[level=12]
setblock 27 214 474 minecraft:light[level=12]
setblock 27 214 482 minecraft:light[level=12]
setblock 27 214 490 minecraft:light[level=12]
setblock 27 214 498 minecraft:light[level=12]
setblock 33 214 504 minecraft:bookshelf
setblock 34 214 464 minecraft:bookshelf
setblock 35 214 466 minecraft:light[level=12]
setblock 35 214 474 minecraft:light[level=12]
setblock 35 214 482 minecraft:light[level=12]
setblock 35 214 490 minecraft:light[level=12]
setblock 35 214 498 minecraft:light[level=12]
setblock 40 214 504 minecraft:bookshelf
setblock 41 214 464 minecraft:bookshelf
setblock 41 214 471 minecraft:bookshelf
setblock 41 214 478 minecraft:bookshelf
setblock 41 214 485 minecraft:bookshelf
setblock 41 214 492 minecraft:bookshelf
setblock 41 214 499 minecraft:bookshelf
setblock 1 215 467 minecraft:bookshelf
setblock 1 215 474 minecraft:bookshelf
setblock 1 215 481 minecraft:bookshelf
setblock 1 215 488 minecraft:bookshelf
setblock 1 215 495 minecraft:bookshelf
setblock 1 215 502 minecraft:bookshelf
setblock 5 215 464 minecraft:bookshelf
setblock 6 215 504 minecraft:bookshelf
setblock 12 215 464 minecraft:bookshelf
fill 13 215 504 14 216 504 minecraft:bookshelf
fill 14 215 502 16 215 503 minecraft:bookshelf
setblock 16 215 504 minecraft:bookshelf
fill 18 215 502 18 215 503 minecraft:bookshelf
setblock 19 215 464 minecraft:bookshelf
setblock 20 215 504 minecraft:bookshelf
setblock 26 215 464 minecraft:bookshelf
setblock 27 215 504 minecraft:bookshelf
setblock 33 215 464 minecraft:bookshelf
setblock 34 215 504 minecraft:bookshelf
setblock 40 215 464 minecraft:bookshelf
setblock 41 215 470 minecraft:bookshelf
setblock 41 215 477 minecraft:bookshelf
setblock 41 215 484 minecraft:bookshelf
setblock 41 215 491 minecraft:bookshelf
setblock 41 215 498 minecraft:bookshelf
setblock 41 215 504 minecraft:bookshelf
setblock 1 216 468 minecraft:bookshelf
setblock 1 216 475 minecraft:bookshelf
setblock 1 216 482 minecraft:bookshelf
setblock 1 216 489 minecraft:bookshelf
setblock 1 216 496 minecraft:bookshelf
setblock 1 216 503 minecraft:bookshelf
setblock 4 216 464 minecraft:bookshelf
fill 7 216 504 7 217 504 minecraft:bookshelf
fill 9 216 504 12 216 504 minecraft:bookshelf
fill 10 216 502 15 216 503 minecraft:bookshelf
setblock 11 216 464 minecraft:bookshelf
setblock 18 216 464 minecraft:bookshelf
setblock 21 216 504 minecraft:bookshelf
setblock 25 216 464 minecraft:bookshelf
setblock 28 216 504 minecraft:bookshelf
setblock 32 216 464 minecraft:bookshelf
setblock 35 216 504 minecraft:bookshelf
setblock 39 216 464 minecraft:bookshelf
setblock 41 216 469 minecraft:bookshelf
setblock 41 216 476 minecraft:bookshelf
setblock 41 216 483 minecraft:bookshelf
setblock 41 216 490 minecraft:bookshelf
setblock 41 216 497 minecraft:bookshelf
fill 4 217 504 6 218 504 minecraft:bookshelf
fill 5 217 503 11 217 503 minecraft:bookshelf
fill 6 217 502 12 217 502 minecraft:bookshelf
fill 9 217 476 11 218 477 minecraft:red_wool
fill 9 217 504 11 217 504 minecraft:bookshelf
setblock 1 218 470 minecraft:bookshelf
setblock 1 218 477 minecraft:bookshelf
setblock 1 218 484 minecraft:bookshelf
setblock 1 218 491 minecraft:bookshelf
fill 1 218 498 1 220 498 minecraft:bookshelf
fill 1 218 502 7 218 503 minecraft:bookshelf
setblock 2 218 464 minecraft:bookshelf
fill 2 218 501 3 219 501 minecraft:bookshelf
fill 2 218 504 3 218 504 minecraft:bookshelf
fill 3 218 500 3 219 500 minecraft:bookshelf
setblock 8 218 502 minecraft:bookshelf
setblock 9 218 464 minecraft:bookshelf
setblock 9 218 504 minecraft:bookshelf
setblock 16 218 464 minecraft:bookshelf
setblock 16 218 504 minecraft:bookshelf
setblock 23 218 464 minecraft:bookshelf
setblock 23 218 504 minecraft:bookshelf
setblock 30 218 464 minecraft:bookshelf
setblock 30 218 504 minecraft:bookshelf
setblock 37 218 464 minecraft:bookshelf
setblock 37 218 504 minecraft:bookshelf
setblock 41 218 467 minecraft:bookshelf
setblock 41 218 474 minecraft:bookshelf
setblock 41 218 481 minecraft:bookshelf
setblock 41 218 488 minecraft:bookshelf
setblock 41 218 495 minecraft:bookshelf
setblock 41 218 502 minecraft:bookshelf
fill 1 219 464 1 220 464 minecraft:bookshelf
fill 1 219 471 1 220 471 minecraft:bookshelf
fill 1 219 478 1 220 478 minecraft:bookshelf
fill 1 219 485 1 220 485 minecraft:bookshelf
fill 1 219 492 1 220 492 minecraft:bookshelf
fill 1 219 499 1 220 503 minecraft:bookshelf
fill 2 219 496 2 219 500 minecraft:bookshelf
fill 2 219 502 2 219 503 minecraft:bookshelf
fill 3 219 496 3 219 499 minecraft:bookshelf
setblock 3 219 502 minecraft:bookshelf
fill 3 219 504 3 220 504 minecraft:bookshelf
fill 8 219 464 8 220 464 minecraft:bookshelf
fill 10 219 504 10 220 504 minecraft:bookshelf
fill 15 219 464 15 220 464 minecraft:bookshelf
fill 17 219 504 17 220 504 minecraft:bookshelf
fill 22 219 464 22 220 464 minecraft:bookshelf
fill 24 219 504 24 220 504 minecraft:bookshelf
fill 29 219 464 29 220 464 minecraft:bookshelf
fill 31 219 504 31 220 504 minecraft:bookshelf
fill 36 219 464 36 220 464 minecraft:bookshelf
fill 38 219 504 38 220 504 minecraft:bookshelf
fill 41 219 466 41 220 466 minecraft:bookshelf
fill 41 219 473 41 220 473 minecraft:bookshelf
fill 41 219 480 41 220 480 minecraft:bookshelf
fill 41 219 487 41 220 487 minecraft:bookshelf
fill 41 219 494 41 220 494 minecraft:bookshelf
fill 41 219 501 41 220 501 minecraft:bookshelf
fill 1 220 465 1 220 468 minecraft:bookshelf
setblock 1 220 470 minecraft:bookshelf
fill 1 220 472 1 220 475 minecraft:bookshelf
setblock 1 220 477 minecraft:bookshelf
fill 1 220 479 1 220 482 minecraft:bookshelf
setblock 1 220 484 minecraft:bookshelf
fill 1 220 486 1 220 489 minecraft:bookshelf
setblock 1 220 491 minecraft:bookshelf
fill 1 220 493 3 220 496 minecraft:bookshelf
setblock 2 220 464 minecraft:bookshelf
fill 2 220 492 3 220 492 minecraft:bookshelf
fill 2 220 497 2 220 498 minecraft:bookshelf
setblock 2 220 504 minecraft:bookshelf
setblock 3 220 497 minecraft:bookshelf
fill 4 220 464 7 220 464 minecraft:bookshelf
fill 4 220 504 7 220 504 minecraft:bookshelf
setblock 9 220 464 minecraft:bookshelf
setblock 9 220 504 minecraft:bookshelf
fill 11 220 464 14 220 464 minecraft:bookshelf
fill 11 220 504 14 220 504 minecraft:bookshelf
setblock 16 220 464 minecraft:bookshelf
setblock 16 220 504 minecraft:bookshelf
fill 18 220 464 21 220 464 minecraft:bookshelf
fill 18 220 504 21 220 504 minecraft:bookshelf
setblock 23 220 464 minecraft:bookshelf
setblock 23 220 504 minecraft:bookshelf
fill 25 220 464 28 220 464 minecraft:bookshelf
fill 25 220 504 28 220 504 minecraft:bookshelf
setblock 30 220 464 minecraft:bookshelf
setblock 30 220 504 minecraft:bookshelf
fill 32 220 464 35 220 464 minecraft:bookshelf
fill 32 220 504 35 220 504 minecraft:bookshelf
setblock 37 220 464 minecraft:bookshelf
setblock 37 220 504 minecraft:bookshelf
fill 39 220 464 41 220 464 minecraft:bookshelf
fill 39 220 504 41 220 504 minecraft:bookshelf
setblock 41 220 465 minecraft:bookshelf
setblock 41 220 467 minecraft:bookshelf
fill 41 220 469 41 220 472 minecraft:bookshelf
setblock 41 220 474 minecraft:bookshelf
fill 41 220 476 41 220 479 minecraft:bookshelf
setblock 41 220 481 minecraft:bookshelf
fill 41 220 483 41 220 486 minecraft:bookshelf
setblock 41 220 488 minecraft:bookshelf
fill 41 220 490 41 220 493 minecraft:bookshelf
setblock 41 220 495 minecraft:bookshelf
fill 41 220 497 41 220 500 minecraft:bookshelf
setblock 41 220 502 minecraft:bookshelf
setblock 3 222 466 minecraft:light[level=12]
setblock 3 222 474 minecraft:light[level=12]
setblock 3 222 482 minecraft:light[level=12]
setblock 3 222 490 minecraft:light[level=12]
setblock 3 222 498 minecraft:light[level=12]
setblock 11 222 466 minecraft:light[level=12]
setblock 11 222 474 minecraft:light[level=12]
setblock 11 222 482 minecraft:light[level=12]
setblock 11 222 490 minecraft:light[level=12]
setblock 11 222 498 minecraft:light[level=12]
setblock 19 222 466 minecraft:light[level=12]
setblock 19 222 474 minecraft:light[level=12]
setblock 19 222 482 minecraft:light[level=12]
setblock 19 222 490 minecraft:light[level=12]
setblock 19 222 498 minecraft:light[level=12]
setblock 27 222 466 minecraft:light[level=12]
setblock 27 222 474 minecraft:light[level=12]
setblock 27 222 482 minecraft:light[level=12]
setblock 27 222 490 minecraft:light[level=12]
setblock 27 222 498 minecraft:light[level=12]
setblock 35 222 466 minecraft:light[level=12]
setblock 35 222 474 minecraft:light[level=12]
setblock 35 222 482 minecraft:light[level=12]
setblock 35 222 490 minecraft:light[level=12]
setblock 35 222 498 minecraft:light[level=12]
fill 1 226 464 4 226 464 minecraft:blue_wool
fill 1 226 465 4 226 468 minecraft:red_wool
fill 1 226 469 4 226 472 minecraft:blue_wool
fill 1 226 473 4 226 476 minecraft:red_wool
fill 1 226 477 4 226 480 minecraft:blue_wool
fill 1 226 481 4 226 484 minecraft:red_wool
fill 1 226 485 4 226 488 minecraft:blue_wool
fill 1 226 489 4 226 492 minecraft:red_wool
fill 1 226 493 4 226 496 minecraft:blue_wool
fill 1 226 497 4 226 500 minecraft:red_wool
fill 1 226 501 4 226 504 minecraft:blue_wool
fill 5 226 464 8 226 464 minecraft:red_wool
fill 5 226 465 8 226 468 minecraft:blue_wool
fill 5 226 469 8 226 472 minecraft:red_wool
fill 5 226 473 8 226 476 minecraft:blue_wool
fill 5 226 477 8 226 480 minecraft:red_wool
fill 5 226 481 8 226 484 minecraft:blue_wool
fill 5 226 485 8 226 488 minecraft:red_wool
fill 5 226 489 8 226 492 minecraft:blue_wool
fill 5 226 493 8 226 496 minecraft:red_wool
fill 5 226 497 8 226 500 minecraft:blue_wool
fill 5 226 501 8 226 504 minecraft:red_wool
fill 9 226 464 12 226 464 minecraft:blue_wool
fill 9 226 465 12 226 468 minecraft:red_wool
fill 9 226 469 12 226 472 minecraft:blue_wool
fill 9 226 473 12 226 476 minecraft:red_wool
fill 9 226 477 12 226 480 minecraft:blue_wool
fill 9 226 481 12 226 484 minecraft:red_wool
fill 9 226 485 12 226 488 minecraft:blue_wool
fill 9 226 489 12 226 492 minecraft:red_wool
fill 9 226 493 12 226 496 minecraft:blue_wool
fill 9 226 497 12 226 500 minecraft:red_wool
fill 9 226 501 12 226 504 minecraft:blue_wool
fill 13 226 464 16 226 464 minecraft:red_wool
fill 13 226 465 16 226 468 minecraft:blue_wool
fill 13 226 469 16 226 472 minecraft:red_wool
fill 13 226 473 16 226 476 minecraft:blue_wool
fill 13 226 477 16 226 480 minecraft:red_wool
fill 13 226 481 15 226 484 minecraft:blue_wool
fill 13 226 485 14 226 488 minecraft:red_wool
fill 13 226 489 16 226 492 minecraft:blue_wool
fill 13 226 493 16 226 496 minecraft:red_wool
fill 13 226 497 16 226 500 minecraft:blue_wool
fill 13 226 501 16 226 504 minecraft:red_wool
fill 15 226 486 15 226 488 minecraft:red_wool
fill 16 226 481 16 226 483 minecraft:blue_wool
fill 16 226 487 16 226 488 minecraft:red_wool
fill 17 226 464 20 226 464 minecraft:blue_wool
fill 17 226 465 20 226 468 minecraft:red_wool
fill 17 226 469 20 226 472 minecraft:blue_wool
fill 17 226 473 20 226 476 minecraft:red_wool
fill 17 226 477 20 226 480 minecraft:blue_wool
fill 17 226 481 20 226 482 minecraft:red_wool
fill 17 226 488 20 226 488 minecraft:blue_wool
fill 17 226 489 20 226 492 minecraft:red_wool
fill 17 226 493 20 226 496 minecraft:blue_wool
fill 17 226 497 20 226 500 minecraft:red_wool
fill 17 226 501 20 226 504 minecraft:blue_wool
fill 18 226 483 20 226 483 minecraft:red_wool
fill 18 226 487 20 226 487 minecraft:blue_wool
fill 19 226 484 20 226 484 minecraft:red_wool
fill 19 226 486 20 226 486 minecraft:blue_wool
setblock 20 226 485 minecraft:blue_wool
fill 21 226 464 24 226 464 minecraft:red_wool
fill 21 226 465 24 226 468 minecraft:blue_wool
fill 21 226 469 24 226 472 minecraft:red_wool
fill 21 226 473 24 226 476 minecraft:blue_wool
fill 21 226 477 24 226 480 minecraft:red_wool
fill 21 226 481 24 226 484 minecraft:blue_wool
fill 21 226 485 24 226 488 minecraft:red_wool
fill 21 226 489 24 226 492 minecraft:blue_wool
fill 21 226 493 24 226 496 minecraft:red_wool
fill 21 226 497 24 226 500 minecraft:blue_wool
fill 21 226 501 24 226 504 minecraft:red_wool
fill 25 226 464 28 226 464 minecraft:blue_wool
fill 25 226 465 28 226 468 minecraft:red_wool
fill 25 226 469 28 226 472 minecraft:blue_wool
fill 25 226 473 28 226 476 minecraft:red_wool
fill 25 226 477 28 226 480 minecraft:blue_wool
fill 25 226 481 28 226 484 minecraft:red_wool
fill 25 226 485 28 226 488 minecraft:blue_wool
fill 25 226 489 28 226 492 minecraft:red_wool
fill 25 226 493 28 226 496 minecraft:blue_wool
fill 25 226 497 28 226 500 minecraft:red_wool
fill 25 226 501 28 226 504 minecraft:blue_wool
fill 29 226 464 32 226 464 minecraft:red_wool
fill 29 226 465 32 226 468 minecraft:blue_wool
fill 29 226 469 32 226 472 minecraft:red_wool
fill 29 226 473 32 226 476 minecraft:blue_wool
fill 29 226 477 32 226 480 minecraft:red_wool
fill 29 226 481 32 226 484 minecraft:blue_wool
fill 29 226 485 32 226 488 minecraft:red_wool
fill 29 226 489 32 226 492 minecraft:blue_wool
fill 29 226 493 32 226 496 minecraft:red_wool
fill 29 226 497 32 226 500 minecraft:blue_wool
fill 29 226 501 32 226 504 minecraft:red_wool
fill 33 226 464 36 226 464 minecraft:blue_wool
fill 33 226 465 36 226 468 minecraft:red_wool
fill 33 226 469 36 226 472 minecraft:blue_wool
fill 33 226 473 36 226 476 minecraft:red_wool
fill 33 226 477 36 226 480 minecraft:blue_wool
fill 33 226 481 36 226 484 minecraft:red_wool
fill 33 226 485 36 226 488 minecraft:blue_wool
fill 33 226 489 36 226 492 minecraft:red_wool
fill 33 226 493 36 226 496 minecraft:blue_wool
fill 33 226 497 36 226 500 minecraft:red_wool
fill 33 226 501 36 226 504 minecraft:blue_wool
fill 37 226 464 40 226 464 minecraft:red_wool
fill 37 226 465 40 226 468 minecraft:blue_wool
fill 37 226 469 40 226 472 minecraft:red_wool
fill 37 226 473 40 226 476 minecraft:blue_wool
fill 37 226 477 40 226 480 minecraft:red_wool
fill 37 226 481 40 226 484 minecraft:blue_wool
fill 37 226 485 40 226 488 minecraft:red_wool
fill 37 226 489 40 226 492 minecraft:blue_wool
fill 37 226 493 40 226 496 minecraft:red_wool
fill 37 226 497 40 226 500 minecraft:blue_wool
fill 37 226 501 40 226 504 minecraft:red_wool
setblock 41 226 464 minecraft:blue_wool
fill 41 226 465 41 226 468 minecraft:red_wool
fill 41 226 469 41 226 472 minecraft:blue_wool
fill 41 226 473 41 226 476 minecraft:red_wool
fill 41 226 477 41 226 480 minecraft:blue_wool
fill 41 226 481 41 226 484 minecraft:red_wool
fill 41 226 485 41 226 488 minecraft:blue_wool
fill 41 226 489 41 226 492 minecraft:red_wool
fill 41 226 493 41 226 496 minecraft:blue_wool
fill 41 226 497 41 226 500 minecraft:red_wool
fill 41 226 501 41 226 504 minecraft:blue_wool
fill 1 227 464 1 227 504 minecraft:dark_oak_planks
fill 2 227 464 4 227 464 minecraft:blue_wool
fill 2 227 465 41 227 465 minecraft:dark_oak_planks
fill 2 227 466 4 227 468 minecraft:red_wool
fill 2 227 469 41 227 469 minecraft:dark_oak_planks
fill 2 227 470 4 227 472 minecraft:blue_wool
fill 2 227 473 41 227 473 minecraft:dark_oak_planks
fill 2 227 474 4 227 476 minecraft:red_wool
fill 2 227 477 41 227 477 minecraft:dark_oak_planks
fill 2 227 478 4 227 480 minecraft:blue_wool
fill 2 227 481 41 227 481 minecraft:dark_oak_planks
fill 2 227 482 4 227 484 minecraft:red_wool
fill 2 227 485 13 227 485 minecraft:dark_oak_planks
fill 2 227 486 4 227 488 minecraft:blue_wool
fill 2 227 489 41 227 489 minecraft:dark_oak_planks
fill 2 227 490 4 227 492 minecraft:red_wool
fill 2 227 493 41 227 493 minecraft:dark_oak_planks
fill 2 227 494 4 227 496 minecraft:blue_wool
fill 2 227 497 41 227 497 minecraft:dark_oak_planks
fill 2 227 498 4 227 500 minecraft:red_wool
fill 2 227 501 41 227 501 minecraft:dark_oak_planks
fill 2 227 502 4 227 504 minecraft:blue_wool
setblock 5 227 464 minecraft:dark_oak_planks
fill 5 227 466 5 227 468 minecraft:dark_oak_planks
fill 5 227 470 5 227 472 minecraft:dark_oak_planks
fill 5 227 474 5 227 476 minecraft:dark_oak_planks
fill 5 227 478 5 227 480 minecraft:dark_oak_planks
fill 5 227 482 5 227 484 minecraft:dark_oak_planks
fill 5 227 486 5 227 488 minecraft:dark_oak_planks
fill 5 227 490 5 227 492 minecraft:dark_oak_planks
fill 5 227 494 5 227 496 minecraft:dark_oak_planks
fill 5 227 498 5 227 500 minecraft:dark_oak_planks
fill 5 227 502 5 227 504 minecraft:dark_oak_planks
fill 6 227 464 8 227 464 minecraft:red_wool
fill 6 227 466 8 227 468 minecraft:blue_wool
fill 6 227 470 8 227 472 minecraft:red_wool
fill 6 227 474 8 227 476 minecraft:blue_wool
fill 6 227 478 8 227 480 minecraft:red_wool
fill 6 227 482 8 227 484 minecraft:blue_wool
fill 6 227 486 8 227 488 minecraft:red_wool
fill 6 227 490 8 227 492 minecraft:blue_wool
fill 6 227 494 8 227 496 minecraft:red_wool
fill 6 227 498 8 227 500 minecraft:blue_wool
fill 6 227 502 8 227 504 minecraft:red_wool
setblock 9 227 464 minecraft:dark_oak_planks
fill 9 227 466 9 227 468 minecraft:dark_oak_planks
fill 9 227 470 9 227 472 minecraft:dark_oak_planks
fill 9 227 474 9 227 476 minecraft:dark_oak_planks
fill 9 227 478 9 227 480 minecraft:dark_oak_planks
fill 9 227 482 9 227 484 minecraft:dark_oak_planks
fill 9 227 486 9 227 488 minecraft:dark_oak_planks
fill 9 227 490 9 227 492 minecraft:dark_oak_planks
fill 9 227 494 9 227 496 minecraft:dark_oak_planks
fill 9 227 498 9 227 500 minecraft:dark_oak_planks
fill 9 227 502 9 227 504 minecraft:dark_oak_planks
fill 10 227 464 12 227 464 minecraft:blue_wool
fill 10 227 466 12 227 468 minecraft:red_wool
fill 10 227 470 12 227 472 minecraft:blue_wool
fill 10 227 474 12 227 476 minecraft:red_wool
fill 10 227 478 12 227 480 minecraft:blue_wool
fill 10 227 482 12 227 484 minecraft:red_wool
fill 10 227 486 12 227 488 minecraft:blue_wool
fill 10 227 490 12 227 492 minecraft:red_wool
fill 10 227 494 12 227 496 minecraft:blue_wool
fill 10 227 498 12 227 500 minecraft:red_wool
fill 10 227 502 12 227 504 minecraft:blue_wool
setblock 13 227 464 minecraft:dark_oak_planks
fill 13 227 466 13 227 468 minecraft:dark_oak_planks
fill 13 227 470 13 227 472 minecraft:dark_oak_planks
fill 13 227 474 13 227 476 minecraft:dark_oak_planks
fill 13 227 478 13 227 480 minecraft:dark_oak_planks
fill 13 227 482 13 227 484 minecraft:dark_oak_planks
fill 13 227 486 13 227 488 minecraft:dark_oak_planks
fill 13 227 490 13 227 492 minecraft:dark_oak_planks
fill 13 227 494 13 227 496 minecraft:dark_oak_planks
fill 13 227 498 13 227 500 minecraft:dark_oak_planks
fill 13 227 502 13 227 504 minecraft:dark_oak_planks
fill 14 227 464 16 227 464 minecraft:red_wool
fill 14 227 466 16 227 468 minecraft:blue_wool
fill 14 227 470 16 227 472 minecraft:red_wool
fill 14 227 474 16 227 476 minecraft:blue_wool
fill 14 227 478 16 227 480 minecraft:red_wool
fill 14 227 482 14 227 483 minecraft:blue_wool
fill 14 227 484 14 227 486 minecraft:ochre_froglight
fill 14 227 487 14 227 488 minecraft:red_wool
fill 14 227 490 16 227 492 minecraft:blue_wool
fill 14 227 494 16 227 496 minecraft:red_wool
fill 14 227 498 16 227 500 minecraft:blue_wool
fill 14 227 502 16 227 504 minecraft:red_wool
setblock 15 227 482 minecraft:blue_wool
fill 15 227 483 15 227 484 minecraft:ochre_froglight
fill 15 227 486 15 227 487 minecraft:ochre_froglight
setblock 15 227 488 minecraft:red_wool
fill 16 227 482 16 227 483 minecraft:ochre_froglight
fill 16 227 487 16 227 488 minecraft:ochre_froglight
setblock 17 227 464 minecraft:dark_oak_planks
fill 17 227 466 17 227 468 minecraft:dark_oak_planks
fill 17 227 470 17 227 472 minecraft:dark_oak_planks
fill 17 227 474 17 227 476 minecraft:dark_oak_planks
fill 17 227 478 17 227 480 minecraft:dark_oak_planks
fill 17 227 482 18 227 482 minecraft:ochre_froglight
fill 17 227 488 18 227 488 minecraft:ochre_froglight
fill 17 227 490 17 227 492 minecraft:dark_oak_planks
fill 17 227 494 17 227 496 minecraft:dark_oak_planks
fill 17 227 498 17 227 500 minecraft:dark_oak_planks
fill 17 227 502 17 227 504 minecraft:dark_oak_planks
fill 18 227 464 20 227 464 minecraft:blue_wool
fill 18 227 466 20 227 468 minecraft:red_wool
fill 18 227 470 20 227 472 minecraft:blue_wool
fill 18 227 474 20 227 476 minecraft:red_wool
fill 18 227 478 20 227 480 minecraft:blue_wool
fill 18 227 483 19 227 483 minecraft:ochre_froglight
fill 18 227 487 19 227 487 minecraft:ochre_froglight
fill 18 227 490 20 227 492 minecraft:red_wool
fill 18 227 494 20 227 496 minecraft:blue_wool
fill 18 227 498 20 227 500 minecraft:red_wool
fill 18 227 502 20 227 504 minecraft:blue_wool
fill 19 227 482 20 227 482 minecraft:red_wool
fill 19 227 484 20 227 484 minecraft:ochre_froglight
fill 19 227 486 20 227 486 minecraft:ochre_froglight
fill 19 227 488 20 227 488 minecraft:blue_wool
setblock 20 227 483 minecraft:red_wool
setblock 20 227 485 minecraft:ochre_froglight
setblock 20 227 487 minecraft:blue_wool
setblock 21 227 464 minecraft:dark_oak_planks
fill 21 227 466 21 227 468 minecraft:dark_oak_planks
fill 21 227 470 21 227 472 minecraft:dark_oak_planks
fill 21 227 474 21 227 476 minecraft:dark_oak_planks
fill 21 227 478 21 227 480 minecraft:dark_oak_planks
fill 21 227 482 21 227 488 minecraft:dark_oak_planks
fill 21 227 490 21 227 492 minecraft:dark_oak_planks
fill 21 227 494 21 227 496 minecraft:dark_oak_planks
fill 21 227 498 21 227 500 minecraft:dark_oak_planks
fill 21 227 502 21 227 504 minecraft:dark_oak_planks
fill 22 227 464 24 227 464 minecraft:red_wool
fill 22 227 466 24 227 468 minecraft:blue_wool
fill 22 227 470 24 227 472 minecraft:red_wool
fill 22 227 474 24 227 476 minecraft:blue_wool
fill 22 227 478 24 227 480 minecraft:red_wool
fill 22 227 482 24 227 484 minecraft:blue_wool
fill 22 227 485 41 227 485 minecraft:dark_oak_planks
fill 22 227 486 24 227 488 minecraft:red_wool
fill 22 227 490 24 227 492 minecraft:blue_wool
fill 22 227 494 24 227 496 minecraft:red_wool
fill 22 227 498 24 227 500 minecraft:blue_wool
fill 22 227 502 24 227 504 minecraft:red_wool
setblock 25 227 464 minecraft:dark_oak_planks
fill 25 227 466 25 227 468 minecraft:dark_oak_planks
fill 25 227 470 25 227 472 minecraft:dark_oak_planks
fill 25 227 474 25 227 476 minecraft:dark_oak_planks
fill 25 227 478 25 227 480 minecraft:dark_oak_planks
fill 25 227 482 25 227 484 minecraft:dark_oak_planks
fill 25 227 486 25 227 488 minecraft:dark_oak_planks
fill 25 227 490 25 227 492 minecraft:dark_oak_planks
fill 25 227 494 25 227 496 minecraft:dark_oak_planks
fill 25 227 498 25 227 500 minecraft:dark_oak_planks
fill 25 227 502 25 227 504 minecraft:dark_oak_planks
fill 26 227 464 28 227 464 minecraft:blue_wool
fill 26 227 466 28 227 468 minecraft:red_wool
fill 26 227 470 28 227 472 minecraft:blue_wool
fill 26 227 474 28 227 476 minecraft:red_wool
fill 26 227 478 28 227 480 minecraft:blue_wool
fill 26 227 482 28 227 484 minecraft:red_wool
fill 26 227 486 28 227 488 minecraft:blue_wool
fill 26 227 490 28 227 492 minecraft:red_wool
fill 26 227 494 28 227 496 minecraft:blue_wool
fill 26 227 498 28 227 500 minecraft:red_wool
fill 26 227 502 28 227 504 minecraft:blue_wool
setblock 29 227 464 minecraft:dark_oak_planks
fill 29 227 466 29 227 468 minecraft:dark_oak_planks
fill 29 227 470 29 227 472 minecraft:dark_oak_planks
fill 29 227 474 29 227 476 minecraft:dark_oak_planks
fill 29 227 478 29 227 480 minecraft:dark_oak_planks
fill 29 227 482 29 227 484 minecraft:dark_oak_planks
fill 29 227 486 29 227 488 minecraft:dark_oak_planks
fill 29 227 490 29 227 492 minecraft:dark_oak_planks
fill 29 227 494 29 227 496 minecraft:dark_oak_planks
fill 29 227 498 29 227 500 minecraft:dark_oak_planks
fill 29 227 502 29 227 504 minecraft:dark_oak_planks
fill 30 227 464 32 227 464 minecraft:red_wool
fill 30 227 466 32 227 468 minecraft:blue_wool
fill 30 227 470 32 227 472 minecraft:red_wool
fill 30 227 474 32 227 476 minecraft:blue_wool
fill 30 227 478 32 227 480 minecraft:red_wool
fill 30 227 482 32 227 484 minecraft:blue_wool
fill 30 227 486 32 227 488 minecraft:red_wool
fill 30 227 490 32 227 492 minecraft:blue_wool
fill 30 227 494 32 227 496 minecraft:red_wool
fill 30 227 498 32 227 500 minecraft:blue_wool
fill 30 227 502 32 227 504 minecraft:red_wool
setblock 33 227 464 minecraft:dark_oak_planks
fill 33 227 466 33 227 468 minecraft:dark_oak_planks
fill 33 227 470 33 227 472 minecraft:dark_oak_planks
fill 33 227 474 33 227 476 minecraft:dark_oak_planks
fill 33 227 478 33 227 480 minecraft:dark_oak_planks
fill 33 227 482 33 227 484 minecraft:dark_oak_planks
fill 33 227 486 33 227 488 minecraft:dark_oak_planks
fill 33 227 490 33 227 492 minecraft:dark_oak_planks
fill 33 227 494 33 227 496 minecraft:dark_oak_planks
fill 33 227 498 33 227 500 minecraft:dark_oak_planks
fill 33 227 502 33 227 504 minecraft:dark_oak_planks
fill 34 227 464 36 227 464 minecraft:blue_wool
fill 34 227 466 36 227 468 minecraft:red_wool
fill 34 227 470 36 227 472 minecraft:blue_wool
fill 34 227 474 36 227 476 minecraft:red_wool
fill 34 227 478 36 227 480 minecraft:blue_wool
fill 34 227 482 36 227 484 minecraft:red_wool
fill 34 227 486 36 227 488 minecraft:blue_wool
fill 34 227 490 36 227 492 minecraft:red_wool
fill 34 227 494 36 227 496 minecraft:blue_wool
fill 34 227 498 36 227 500 minecraft:red_wool
fill 34 227 502 36 227 504 minecraft:blue_wool
setblock 37 227 464 minecraft:dark_oak_planks
fill 37 227 466 37 227 468 minecraft:dark_oak_planks
fill 37 227 470 37 227 472 minecraft:dark_oak_planks
fill 37 227 474 37 227 476 minecraft:dark_oak_planks
fill 37 227 478 37 227 480 minecraft:dark_oak_planks
fill 37 227 482 37 227 484 minecraft:dark_oak_planks
fill 37 227 486 37 227 488 minecraft:dark_oak_planks
fill 37 227 490 37 227 492 minecraft:dark_oak_planks
fill 37 227 494 37 227 496 minecraft:dark_oak_planks
fill 37 227 498 37 227 500 minecraft:dark_oak_planks
fill 37 227 502 37 227 504 minecraft:dark_oak_planks
fill 38 227 464 40 227 464 minecraft:red_wool
fill 38 227 466 40 227 468 minecraft:blue_wool
fill 38 227 470 40 227 472 minecraft:red_wool
fill 38 227 474 40 227 476 minecraft:blue_wool
fill 38 227 478 40 227 480 minecraft:red_wool
fill 38 227 482 40 227 484 minecraft:blue_wool
fill 38 227 486 40 227 488 minecraft:red_wool
fill 38 227 490 40 227 492 minecraft:blue_wool
fill 38 227 494 40 227 496 minecraft:red_wool
fill 38 227 498 40 227 500 minecraft:blue_wool
fill 38 227 502 40 227 504 minecraft:red_wool
setblock 41 227 464 minecraft:dark_oak_planks
fill 41 227 466 41 227 468 minecraft:dark_oak_planks
fill 41 227 470 41 227 472 minecraft:dark_oak_planks
fill 41 227 474 41 227 476 minecraft:dark_oak_planks
fill 41 227 478 41 227 480 minecraft:dark_oak_planks
fill 41 227 482 41 227 484 minecraft:dark_oak_planks
fill 41 227 486 41 227 488 minecraft:dark_oak_planks
fill 41 227 490 41 227 492 minecraft:dark_oak_planks
fill 41 227 494 41 227 496 minecraft:dark_oak_planks
fill 41 227 498 41 227 500 minecraft:dark_oak_planks
fill 41 227 502 41 227 504 minecraft:dark_oak_planks
setblock 3 230 466 minecraft:light[level=12]
setblock 3 230 474 minecraft:light[level=12]
setblock 3 230 482 minecraft:light[level=12]
setblock 3 230 490 minecraft:light[level=12]
setblock 3 230 498 minecraft:light[level=12]
setblock 11 230 466 minecraft:light[level=12]
setblock 11 230 474 minecraft:light[level=12]
setblock 11 230 482 minecraft:light[level=12]
setblock 11 230 490 minecraft:light[level=12]
setblock 11 230 498 minecraft:light[level=12]
setblock 19 230 466 minecraft:light[level=12]
setblock 19 230 474 minecraft:light[level=12]
setblock 19 230 482 minecraft:light[level=12]
setblock 19 230 490 minecraft:light[level=12]
setblock 19 230 498 minecraft:light[level=12]
setblock 27 230 466 minecraft:light[level=12]
setblock 27 230 474 minecraft:light[level=12]
setblock 27 230 482 minecraft:light[level=12]
setblock 27 230 490 minecraft:light[level=12]
setblock 27 230 498 minecraft:light[level=12]
setblock 35 230 466 minecraft:light[level=12]
setblock 35 230 474 minecraft:light[level=12]
setblock 35 230 482 minecraft:light[level=12]
setblock 35 230 490 minecraft:light[level=12]
setblock 35 230 498 minecraft:light[level=12]
fill 1 231 469 1 273 469 minecraft:bookshelf
fill 1 231 476 1 273 476 minecraft:bookshelf
fill 1 231 483 1 273 483 minecraft:bookshelf
fill 1 231 490 1 273 490 minecraft:bookshelf
fill 1 231 497 1 273 497 minecraft:bookshelf
fill 1 231 504 1 273 504 minecraft:bookshelf
fill 3 231 464 3 273 464 minecraft:bookshelf
fill 8 231 504 8 273 504 minecraft:bookshelf
fill 10 231 464 10 273 464 minecraft:bookshelf
fill 15 231 504 15 273 504 minecraft:bookshelf
fill 17 231 464 17 273 464 minecraft:bookshelf
fill 21 231 496 27 231 504 minecraft:bookshelf
fill 24 231 464 24 273 464 minecraft:bookshelf
fill 29 231 504 29 273 504 minecraft:bookshelf
fill 31 231 464 31 273 464 minecraft:bookshelf
fill 36 231 504 36 273 504 minecraft:bookshelf
fill 37 231 474 41 245 486 minecraft:bookshelf
fill 38 231 464 38 273 464 minecraft:bookshelf
fill 41 231 468 41 273 468 minecraft:bookshelf
fill 41 231 489 41 273 489 minecraft:bookshelf
fill 41 231 496 41 273 496 minecraft:bookshelf
fill 41 231 503 41 273 503 minecraft:bookshelf
setblock 1 232 470 minecraft:bookshelf
setblock 1 232 477 minecraft:bookshelf
setblock 1 232 484 minecraft:bookshelf
setblock 1 232 491 minecraft:bookshelf
fill 1 232 493 7 232 493 minecraft:dark_oak_planks
setblock 1 232 498 minecraft:bookshelf
setblock 2 232 464 minecraft:bookshelf
setblock 2 232 504 minecraft:bookshelf
fill 3 232 491 7 233 492 minecraft:dark_oak_planks
fill 3 232 494 7 233 495 minecraft:dark_oak_planks
setblock 9 232 464 minecraft:bookshelf
setblock 9 232 504 minecraft:bookshelf
setblock 16 232 464 minecraft:bookshelf
setblock 16 232 504 minecraft:bookshelf
setblock 21 232 496 minecraft:ochre_froglight
fill 21 232 497 21 246 497 minecraft:bookshelf
setblock 21 232 498 minecraft:ochre_froglight
fill 21 232 499 21 246 499 minecraft:bookshelf
setblock 21 232 500 minecraft:ochre_froglight
fill 21 232 501 21 246 501 minecraft:bookshelf
setblock 21 232 502 minecraft:ochre_froglight
fill 21 232 503 21 246 503 minecraft:bookshelf
setblock 21 232 504 minecraft:ochre_froglight
fill 22 232 496 22 246 496 minecraft:bookshelf
setblock 22 232 497 minecraft:ochre_froglight
fill 22 232 498 22 246 498 minecraft:bookshelf
setblock 22 232 499 minecraft:ochre_froglight
fill 22 232 500 22 246 500 minecraft:bookshelf
setblock 22 232 501 minecraft:ochre_froglight
fill 22 232 502 22 246 502 minecraft:bookshelf
setblock 22 232 503 minecraft:ochre_froglight
fill 22 232 504 22 273 504 minecraft:bookshelf
setblock 23 232 464 minecraft:bookshelf
setblock 23 232 496 minecraft:ochre_froglight
fill 23 232 497 23 246 497 minecraft:bookshelf
setblock 23 232 498 minecraft:ochre_froglight
fill 23 232 499 23 246 499 minecraft:bookshelf
setblock 23 232 500 minecraft:ochre_froglight
fill 23 232 501 23 246 501 minecraft:bookshelf
setblock 23 232 502 minecraft:ochre_froglight
fill 23 232 503 23 246 503 minecraft:bookshelf
setblock 23 232 504 minecraft:ochre_froglight
fill 24 232 496 24 246 496 minecraft:bookshelf
setblock 24 232 497 minecraft:ochre_froglight
fill 24 232 498 24 246 498 minecraft:bookshelf
setblock 24 232 499 minecraft:ochre_froglight
fill 24 232 500 24 246 500 minecraft:bookshelf
setblock 24 232 501 minecraft:ochre_froglight
fill 24 232 502 24 246 502 minecraft:bookshelf
setblock 24 232 503 minecraft:ochre_froglight
fill 24 232 504 24 247 504 minecraft:bookshelf
setblock 25 232 496 minecraft:ochre_froglight
fill 25 232 497 25 246 497 minecraft:bookshelf
setblock 25 232 498 minecraft:ochre_froglight
fill 25 232 499 25 246 499 minecraft:bookshelf
setblock 25 232 500 minecraft:ochre_froglight
fill 25 232 501 25 246 501 minecraft:bookshelf
setblock 25 232 502 minecraft:ochre_froglight
fill 25 232 503 25 246 503 minecraft:bookshelf
setblock 25 232 504 minecraft:ochre_froglight
fill 26 232 496 26 246 496 minecraft:bookshelf
setblock 26 232 497 minecraft:ochre_froglight
fill 26 232 498 26 246 498 minecraft:bookshelf
setblock 26 232 499 minecraft:ochre_froglight
fill 26 232 500 26 246 500 minecraft:bookshelf
setblock 26 232 501 minecraft:ochre_froglight
fill 26 232 502 26 246 502 minecraft:bookshelf
setblock 26 232 503 minecraft:ochre_froglight
fill 26 232 504 26 246 504 minecraft:bookshelf
setblock 27 232 496 minecraft:ochre_froglight
fill 27 232 497 27 246 497 minecraft:bookshelf
setblock 27 232 498 minecraft:ochre_froglight
fill 27 232 499 27 246 499 minecraft:bookshelf
setblock 27 232 500 minecraft:ochre_froglight
fill 27 232 501 27 246 501 minecraft:bookshelf
setblock 27 232 502 minecraft:ochre_froglight
fill 27 232 503 27 246 503 minecraft:bookshelf
setblock 27 232 504 minecraft:ochre_froglight
setblock 30 232 464 minecraft:bookshelf
setblock 30 232 504 minecraft:bookshelf
setblock 37 232 464 minecraft:bookshelf
setblock 37 232 504 minecraft:bookshelf
fill 39 232 487 41 233 488 minecraft:bookshelf
setblock 41 232 467 minecraft:bookshelf
setblock 41 232 495 minecraft:bookshelf
setblock 41 232 502 minecraft:bookshelf
setblock 1 233 464 minecraft:bookshelf
setblock 1 233 471 minecraft:bookshelf
setblock 1 233 478 minecraft:bookshelf
setblock 1 233 485 minecraft:bookshelf
setblock 1 233 492 minecraft:bookshelf
setblock 1 233 499 minecraft:bookshelf
fill 3 233 493 7 233 493 minecraft:dark_oak_planks
setblock 3 233 504 minecraft:bookshelf
setblock 8 233 464 minecraft:bookshelf
setblock 10 233 504 minecraft:bookshelf
setblock 15 233 464 minecraft:bookshelf
setblock 17 233 504 minecraft:bookshelf
fill 21 233 496 21 234 496 minecraft:bookshelf
fill 21 233 498 21 234 498 minecraft:bookshelf
fill 21 233 500 21 234 500 minecraft:bookshelf
fill 21 233 502 21 234 502 minecraft:bookshelf
fill 21 233 504 21 234 504 minecraft:bookshelf
setblock 22 233 464 minecraft:bookshelf
fill 22 233 497 22 234 497 minecraft:bookshelf
fill 22 233 499 22 234 499 minecraft:bookshelf
fill 22 233 501 22 234 501 minecraft:bookshelf
fill 22 233 503 22 234 503 minecraft:bookshelf
fill 23 233 496 23 234 496 minecraft:bookshelf
fill 23 233 498 23 234 498 minecraft:bookshelf
fill 23 233 500 23 234 500 minecraft:bookshelf
fill 23 233 502 23 234 502 minecraft:bookshelf
fill 23 233 504 23 234 504 minecraft:bookshelf
fill 24 233 497 24 234 497 minecraft:bookshelf
fill 24 233 499 24 234 499 minecraft:bookshelf
fill 24 233 501 24 234 501 minecraft:bookshelf
fill 24 233 503 24 234 503 minecraft:bookshelf
fill 25 233 496 25 234 496 minecraft:bookshelf
fill 25 233 498 25 234 498 minecraft:bookshelf
fill 25 233 500 25 234 500 minecraft:bookshelf
fill 25 233 502 25 234 502 minecraft:bookshelf
fill 25 233 504 25 234 504 minecraft:bookshelf
fill 26 233 497 26 234 497 minecraft:bookshelf
fill 26 233 499 26 234 499 minecraft:bookshelf
fill 26 233 501 26 234 501 minecraft:bookshelf
fill 26 233 503 26 234 503 minecraft:bookshelf
fill 27 233 496 27 234 496 minecraft:bookshelf
fill 27 233 498 27 234 498 minecraft:bookshelf
fill 27 233 500 27 234 500 minecraft:bookshelf
fill 27 233 502 27 234 502 minecraft:bookshelf
fill 27 233 504 27 234 504 minecraft:bookshelf
setblock 29 233 464 minecraft:bookshelf
setblock 31 233 504 minecraft:bookshelf
setblock 36 233 464 minecraft:bookshelf
setblock 38 233 504 minecraft:bookshelf
fill 39 233 489 40 233 491 minecraft:bookshelf
setblock 41 233 466 minecraft:bookshelf
setblock 41 233 473 minecraft:bookshelf
fill 41 233 490 41 233 492 minecraft:bookshelf
fill 41 233 494 41 235 494 minecraft:bookshelf
setblock 41 233 501 minecraft:bookshelf
setblock 1 234 465 minecraft:bookshelf
setblock 1 234 472 minecraft:bookshelf
setblock 1 234 479 minecraft:bookshelf
setblock 1 234 486 minecraft:bookshelf
setblock 1 234 493 minecraft:bookshelf
setblock 1 234 500 minecraft:bookshelf
fill 4 234 493 6 238 493 minecraft:purple_concrete
setblock 4 234 504 minecraft:bookshelf
fill 5 234 492 5 238 492 minecraft:purple_concrete
fill 5 234 494 5 238 494 minecraft:purple_concrete
setblock 7 234 464 minecraft:bookshelf
setblock 11 234 504 minecraft:bookshelf
setblock 14 234 464 minecraft:bookshelf
setblock 18 234 504 minecraft:bookshelf
setblock 21 234 464 minecraft:bookshelf
setblock 28 234 464 minecraft:bookshelf
setblock 32 234 504 minecraft:bookshelf
setblock 35 234 464 minecraft:bookshelf
fill 39 234 490 40 234 495 minecraft:bookshelf
setblock 39 234 504 minecraft:bookshelf
setblock 41 234 465 minecraft:bookshelf
setblock 41 234 472 minecraft:bookshelf
fill 41 234 491 41 234 493 minecraft:bookshelf
fill 41 234 495 41 235 495 minecraft:bookshelf
fill 41 234 500 41 236 500 minecraft:bookshelf
setblock 1 235 466 minecraft:bookshelf
setblock 1 235 473 minecraft:bookshelf
setblock 1 235 480 minecraft:bookshelf
setblock 1 235 487 minecraft:bookshelf
setblock 1 235 494 minecraft:bookshelf
setblock 1 235 501 minecraft:bookshelf
setblock 5 235 504 minecraft:bookshelf
setblock 6 235 464 minecraft:bookshelf
setblock 12 235 504 minecraft:bookshelf
setblock 13 235 464 minecraft:bookshelf
setblock 19 235 504 minecraft:bookshelf
setblock 20 235 464 minecraft:bookshelf
setblock 21 235 496 minecraft:ochre_froglight
setblock 21 235 498 minecraft:ochre_froglight
setblock 21 235 500 minecraft:ochre_froglight
setblock 21 235 502 minecraft:ochre_froglight
setblock 21 235 504 minecraft:ochre_froglight
setblock 22 235 497 minecraft:ochre_froglight
setblock 22 235 499 minecraft:ochre_froglight
setblock 22 235 501 minecraft:ochre_froglight
setblock 22 235 503 minecraft:ochre_froglight
setblock 23 235 496 minecraft:ochre_froglight
setblock 23 235 498 minecraft:ochre_froglight
setblock 23 235 500 minecraft:ochre_froglight
setblock 23 235 502 minecraft:ochre_froglight
setblock 23 235 504 minecraft:ochre_froglight
setblock 24 235 497 minecraft:ochre_froglight
setblock 24 235 499 minecraft:ochre_froglight
setblock 24 235 501 minecraft:ochre_froglight
setblock 24 235 503 minecraft:ochre_froglight
setblock 25 235 496 minecraft:ochre_froglight
setblock 25 235 498 minecraft:ochre_froglight
setblock 25 235 500 minecraft:ochre_froglight
setblock 25 235 502 minecraft:ochre_froglight
setblock 25 235 504 minecraft:ochre_froglight
setblock 26 235 497 minecraft:ochre_froglight
setblock 26 235 499 minecraft:ochre_froglight
setblock 26 235 501 minecraft:ochre_froglight
setblock 26 235 503 minecraft:ochre_froglight
setblock 27 235 464 minecraft:bookshelf
setblock 27 235 496 minecraft:ochre_froglight
setblock 27 235 498 minecraft:ochre_froglight
setblock 27 235 500 minecraft:ochre_froglight
setblock 27 235 502 minecraft:ochre_froglight
setblock 27 235 504 minecraft:ochre_froglight
setblock 33 235 504 minecraft:bookshelf
setblock 34 235 464 minecraft:bookshelf
fill 39 235 493 39 235 499 minecraft:bookshelf
fill 40 235 494 40 235 500 minecraft:bookshelf
fill 40 235 504 40 237 504 minecraft:bookshelf
setblock 41 235 464 minecraft:bookshelf
setblock 41 235 471 minecraft:bookshelf
setblock 41 235 492 minecraft:bookshelf
fill 41 235 497 41 235 499 minecraft:bookshelf
fill 41 235 501 41 236 501 minecraft:bookshelf
setblock 1 236 467 minecraft:bookshelf
setblock 1 236 474 minecraft:bookshelf
setblock 1 236 481 minecraft:bookshelf
setblock 1 236 488 minecraft:bookshelf
setblock 1 236 495 minecraft:bookshelf
setblock 1 236 502 minecraft:bookshelf
setblock 5 236 464 minecraft:bookshelf
setblock 6 236 504 minecraft:bookshelf
setblock 12 236 464 minecraft:bookshelf
setblock 13 236 504 minecraft:bookshelf
setblock 19 236 464 minecraft:bookshelf
fill 20 236 504 21 236 504 minecraft:bookshelf
fill 21 236 496 21 237 496 minecraft:bookshelf
fill 21 236 498 21 237 498 minecraft:bookshelf
fill 21 236 500 21 237 500 minecraft:bookshelf
fill 21 236 502 21 237 502 minecraft:bookshelf
fill 22 236 497 22 237 497 minecraft:bookshelf
fill 22 236 499 22 237 499 minecraft:bookshelf
fill 22 236 501 22 237 501 minecraft:bookshelf
fill 22 236 503 22 237 503 minecraft:bookshelf
fill 23 236 496 23 237 496 minecraft:bookshelf
fill 23 236 498 23 237 498 minecraft:bookshelf
fill 23 236 500 23 237 500 minecraft:bookshelf
fill 23 236 502 23 237 502 minecraft:bookshelf
fill 23 236 504 23 237 504 minecraft:bookshelf
fill 24 236 497 24 237 497 minecraft:bookshelf
fill 24 236 499 24 237 499 minecraft:bookshelf
fill 24 236 501 24 237 501 minecraft:bookshelf
fill 24 236 503 24 237 503 minecraft:bookshelf
fill 25 236 496 25 237 496 minecraft:bookshelf
fill 25 236 498 25 237 498 minecraft:bookshelf
fill 25 236 500 25 237 500 minecraft:bookshelf
fill 25 236 502 25 237 502 minecraft:bookshelf
fill 25 236 504 25 237 504 minecraft:bookshelf
setblock 26 236 464 minecraft:bookshelf
fill 26 236 497 26 237 497 minecraft:bookshelf
fill 26 236 499 26 237 499 minecraft:bookshelf
fill 26 236 501 26 237 501 minecraft:bookshelf
fill 26 236 503 26 237 503 minecraft:bookshelf
fill 27 236 496 27 237 496 minecraft:bookshelf
fill 27 236 498 27 237 498 minecraft:bookshelf
fill 27 236 500 27 237 500 minecraft:bookshelf
fill 27 236 502 27 237 502 minecraft:bookshelf
fill 27 236 504 27 237 504 minecraft:bookshelf
setblock 33 236 464 minecraft:bookshelf
fill 34 236 504 34 238 504 minecraft:bookshelf
fill 37 236 502 41 236 502 minecraft:bookshelf
fill 38 236 503 40 237 503 minecraft:bookshelf
fill 39 236 497 39 236 501 minecraft:bookshelf
fill 39 236 504 39 237 504 minecraft:bookshelf
setblock 40 236 464 minecraft:bookshelf
fill 40 236 498 40 236 501 minecraft:bookshelf
setblock 41 236 470 minecraft:bookshelf
setblock 41 236 491 minecraft:bookshelf
fill 41 236 498 41 236 499 minecraft:bookshelf
fill 41 236 504 41 237 504 minecraft:bookshelf
setblock 1 237 468 minecraft:bookshelf
setblock 1 237 475 minecraft:bookshelf
setblock 1 237 482 minecraft:bookshelf
setblock 1 237 489 minecraft:bookshelf
setblock 1 237 496 minecraft:bookshelf
setblock 1 237 503 minecraft:bookshelf
setblock 4 237 464 minecraft:bookshelf
setblock 7 237 504 minecraft:bookshelf
setblock 11 237 464 minecraft:bookshelf
setblock 14 237 504 minecraft:bookshelf
setblock 18 237 464 minecraft:bookshelf
setblock 21 237 504 minecraft:bookshelf
setblock 25 237 464 minecraft:bookshelf
setblock 28 237 504 minecraft:bookshelf
setblock 32 237 464 minecraft:bookshelf
fill 33 237 502 37 237 503 minecraft:bookshelf
fill 35 237 504 35 238 504 minecraft:bookshelf
fill 37 237 504 38 237 504 minecraft:bookshelf
fill 38 237 502 39 237 502 minecraft:bookshelf
setblock 39 237 464 minecraft:bookshelf
setblock 41 237 469 minecraft:bookshelf
setblock 41 237 490 minecraft:bookshelf
setblock 41 237 497 minecraft:bookshelf
setblock 3 238 466 minecraft:light[level=12]
setblock 3 238 474 minecraft:light[level=12]
setblock 3 238 482 minecraft:light[level=12]
setblock 3 238 490 minecraft:light[level=12]
setblock 3 238 498 minecraft:light[level=12]
setblock 11 238 466 minecraft:light[level=12]
setblock 11 238 474 minecraft:light[level=12]
setblock 11 238 482 minecraft:light[level=12]
setblock 11 238 490 minecraft:light[level=12]
setblock 11 238 498 minecraft:light[level=12]
setblock 19 238 466 minecraft:light[level=12]
setblock 19 238 474 minecraft:light[level=12]
setblock 19 238 482 minecraft:light[level=12]
setblock 19 238 490 minecraft:light[level=12]
setblock 19 238 498 minecraft:light[level=12]
setblock 21 238 496 minecraft:ochre_froglight
setblock 21 238 498 minecraft:ochre_froglight
setblock 21 238 500 minecraft:ochre_froglight
setblock 21 238 502 minecraft:ochre_froglight
setblock 21 238 504 minecraft:ochre_froglight
setblock 22 238 497 minecraft:ochre_froglight
setblock 22 238 499 minecraft:ochre_froglight
setblock 22 238 501 minecraft:ochre_froglight
setblock 22 238 503 minecraft:ochre_froglight
setblock 23 238 496 minecraft:ochre_froglight
setblock 23 238 498 minecraft:ochre_froglight
setblock 23 238 500 minecraft:ochre_froglight
setblock 23 238 502 minecraft:ochre_froglight
setblock 23 238 504 minecraft:ochre_froglight
setblock 24 238 497 minecraft:ochre_froglight
setblock 24 238 499 minecraft:ochre_froglight
setblock 24 238 501 minecraft:ochre_froglight
setblock 24 238 503 minecraft:ochre_froglight
setblock 25 238 496 minecraft:ochre_froglight
setblock 25 238 498 minecraft:ochre_froglight
setblock 25 238 500 minecraft:ochre_froglight
setblock 25 238 502 minecraft:ochre_froglight
setblock 25 238 504 minecraft:ochre_froglight
setblock 26 238 497 minecraft:ochre_froglight
setblock 26 238 499 minecraft:ochre_froglight
setblock 26 238 501 minecraft:ochre_froglight
setblock 26 238 503 minecraft:ochre_froglight
setblock 27 238 466 minecraft:light[level=12]
setblock 27 238 474 minecraft:light[level=12]
setblock 27 238 482 minecraft:light[level=12]
setblock 27 238 490 minecraft:light[level=12]
setblock 27 238 496 minecraft:ochre_froglight
setblock 27 238 498 minecraft:ochre_froglight
setblock 27 238 500 minecraft:ochre_froglight
setblock 27 238 502 minecraft:ochre_froglight
setblock 27 238 504 minecraft:ochre_froglight
fill 29 238 502 34 238 503 minecraft:bookshelf
fill 30 238 504 33 238 504 minecraft:bookshelf
setblock 35 238 466 minecraft:light[level=12]
setblock 35 238 474 minecraft:light[level=12]
setblock 35 238 482 minecraft:light[level=12]
setblock 35 238 490 minecraft:light[level=12]
setblock 35 238 498 minecraft:light[level=12]
setblock 35 238 503 minecraft:bookshelf
fill 1 239 470 1 240 470 minecraft:bookshelf
fill 1 239 477 1 240 477 minecraft:bookshelf
fill 1 239 484 1 240 484 minecraft:bookshelf
fill 1 239 491 1 240 491 minecraft:bookshelf
fill 1 239 498 1 240 498 minecraft:bookshelf
fill 2 239 464 2 240 464 minecraft:bookshelf
fill 2 239 504 2 240 504 minecraft:bookshelf
fill 9 239 464 9 240 464 minecraft:bookshelf
fill 9 239 504 9 240 504 minecraft:bookshelf
fill 16 239 464 16 240 464 minecraft:bookshelf
fill 16 239 504 16 240 504 minecraft:bookshelf
fill 21 239 496 21 240 496 minecraft:bookshelf
fill 21 239 498 21 240 498 minecraft:bookshelf
fill 21 239 500 21 240 500 minecraft:bookshelf
fill 21 239 502 21 240 502 minecraft:bookshelf
fill 21 239 504 21 240 504 minecraft:bookshelf
fill 22 239 497 22 240 497 minecraft:bookshelf
fill 22 239 499 22 240 499 minecraft:bookshelf
fill 22 239 501 22 240 501 minecraft:bookshelf
fill 22 239 503 22 240 503 minecraft:bookshelf
fill 23 239 464 23 240 464 minecraft:bookshelf
fill 23 239 496 23 240 496 minecraft:bookshelf
fill 23 239 498 23 240 498 minecraft:bookshelf
fill 23 239 500 23 240 500 minecraft:bookshelf
fill 23 239 502 23 240 502 minecraft:bookshelf
fill 23 239 504 23 240 504 minecraft:bookshelf
fill 24 239 497 24 240 497 minecraft:bookshelf
fill 24 239 499 24 240 499 minecraft:bookshelf
fill 24 239 501 24 240 501 minecraft:bookshelf
fill 24 239 503 24 240 503 minecraft:bookshelf
fill 25 239 496 25 240 496 minecraft:bookshelf
fill 25 239 498 25 240 498 minecraft:bookshelf
fill 25 239 500 25 240 500 minecraft:bookshelf
fill 25 239 502 25 240 502 minecraft:bookshelf
fill 25 239 504 25 240 504 minecraft:bookshelf
fill 26 239 497 26 240 497 minecraft:bookshelf
fill 26 239 499 26 240 499 minecraft:bookshelf
fill 26 239 501 26 240 501 minecraft:bookshelf
fill 26 239 503 26 240 503 minecraft:bookshelf
fill 27 239 496 27 240 496 minecraft:bookshelf
schedule function dropper:buildpart/108_4 1t
