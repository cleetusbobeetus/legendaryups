setblock 160 146 537 minecraft:light[level=12]
setblock 160 146 545 minecraft:light[level=12]
fill 162 146 510 162 153 510 minecraft:crying_obsidian
fill 164 146 511 164 148 512 minecraft:amethyst_block
setblock 168 146 513 minecraft:light[level=12]
setblock 168 146 521 minecraft:light[level=12]
setblock 168 146 529 minecraft:light[level=12]
setblock 168 146 537 minecraft:light[level=12]
setblock 168 146 545 minecraft:light[level=12]
fill 175 146 537 175 147 537 minecraft:amethyst_block
setblock 176 146 513 minecraft:light[level=12]
setblock 176 146 521 minecraft:light[level=12]
setblock 176 146 529 minecraft:light[level=12]
setblock 176 146 545 minecraft:light[level=12]
fill 141 147 518 141 149 518 minecraft:crying_obsidian
fill 141 147 534 141 153 534 minecraft:crying_obsidian
fill 141 147 550 141 153 550 minecraft:crying_obsidian
fill 145 147 510 145 153 510 minecraft:crying_obsidian
fill 155 147 552 155 153 552 minecraft:crying_obsidian
fill 161 147 510 161 153 510 minecraft:crying_obsidian
fill 163 147 511 163 148 513 minecraft:amethyst_block
fill 164 147 513 164 147 515 minecraft:amethyst_block
fill 165 147 511 165 148 513 minecraft:amethyst_block
fill 171 147 552 171 152 552 minecraft:crying_obsidian
setblock 172 147 510 minecraft:white_concrete
fill 174 147 552 174 169 552 minecraft:crying_obsidian
setblock 175 147 552 minecraft:white_concrete
fill 176 147 552 178 152 552 minecraft:crying_obsidian
fill 177 147 510 177 153 510 minecraft:crying_obsidian
fill 183 147 520 183 153 520 minecraft:crying_obsidian
fill 183 147 536 183 153 536 minecraft:crying_obsidian
setblock 183 147 545 minecraft:white_concrete
fill 183 147 546 183 163 548 minecraft:crying_obsidian
setblock 141 148 530 minecraft:white_concrete
fill 141 148 531 141 161 532 minecraft:crying_obsidian
fill 164 148 513 164 148 514 minecraft:amethyst_block
fill 172 148 510 172 193 510 minecraft:crying_obsidian
fill 175 148 552 175 210 552 minecraft:crying_obsidian
fill 183 148 545 183 213 545 minecraft:crying_obsidian
fill 141 149 522 141 181 522 minecraft:crying_obsidian
setblock 141 149 523 minecraft:amethyst_block
fill 141 149 524 141 213 524 minecraft:crying_obsidian
fill 141 149 530 141 209 530 minecraft:crying_obsidian
setblock 141 149 543 minecraft:white_concrete
setblock 164 149 511 minecraft:amethyst_block
fill 172 149 529 172 150 530 minecraft:crying_obsidian
fill 183 149 537 183 167 538 minecraft:crying_obsidian
setblock 183 149 539 minecraft:white_concrete
setblock 141 150 518 minecraft:white_concrete
fill 141 150 523 141 210 523 minecraft:crying_obsidian
fill 141 150 543 141 197 543 minecraft:crying_obsidian
setblock 183 150 515 minecraft:amethyst_block
fill 183 150 539 183 213 539 minecraft:crying_obsidian
fill 141 151 518 141 153 518 minecraft:crying_obsidian
setblock 168 151 510 minecraft:amethyst_block
fill 169 151 510 171 213 510 minecraft:crying_obsidian
fill 183 151 515 183 203 515 minecraft:crying_obsidian
setblock 168 152 510 minecraft:crying_obsidian
setblock 142 153 510 minecraft:amethyst_block
setblock 168 153 510 minecraft:white_concrete
setblock 171 153 552 minecraft:white_concrete
fill 176 153 552 177 213 552 minecraft:crying_obsidian
setblock 178 153 552 minecraft:white_concrete
fill 141 154 518 141 155 518 minecraft:purple_stained_glass
fill 141 154 534 141 155 534 minecraft:purple_stained_glass
fill 141 154 550 141 155 550 minecraft:purple_stained_glass
fill 142 154 510 142 199 510 minecraft:crying_obsidian
setblock 144 154 513 minecraft:light[level=12]
setblock 144 154 521 minecraft:light[level=12]
setblock 144 154 529 minecraft:light[level=12]
setblock 144 154 537 minecraft:light[level=12]
setblock 144 154 545 minecraft:light[level=12]
fill 145 154 510 145 155 510 minecraft:purple_stained_glass
setblock 152 154 513 minecraft:light[level=12]
setblock 152 154 521 minecraft:light[level=12]
setblock 152 154 529 minecraft:light[level=12]
setblock 152 154 537 minecraft:light[level=12]
setblock 152 154 545 minecraft:light[level=12]
fill 155 154 552 155 155 552 minecraft:purple_stained_glass
setblock 160 154 513 minecraft:light[level=12]
setblock 160 154 521 minecraft:light[level=12]
setblock 160 154 529 minecraft:light[level=12]
setblock 160 154 537 minecraft:light[level=12]
setblock 160 154 545 minecraft:light[level=12]
fill 161 154 510 161 155 510 minecraft:purple_stained_glass
setblock 162 154 510 minecraft:amethyst_block
fill 168 154 510 168 213 510 minecraft:crying_obsidian
setblock 168 154 513 minecraft:light[level=12]
setblock 168 154 521 minecraft:light[level=12]
setblock 168 154 529 minecraft:light[level=12]
setblock 168 154 537 minecraft:light[level=12]
setblock 168 154 545 minecraft:light[level=12]
fill 171 154 552 171 155 552 minecraft:purple_stained_glass
setblock 176 154 513 minecraft:light[level=12]
setblock 176 154 521 minecraft:light[level=12]
setblock 176 154 529 minecraft:light[level=12]
setblock 176 154 537 minecraft:light[level=12]
setblock 176 154 545 minecraft:light[level=12]
fill 177 154 510 177 155 510 minecraft:purple_stained_glass
fill 178 154 552 178 213 552 minecraft:crying_obsidian
setblock 183 154 514 minecraft:amethyst_block
fill 183 154 520 183 155 520 minecraft:purple_stained_glass
fill 183 154 526 183 172 526 minecraft:crying_obsidian
setblock 183 154 527 minecraft:amethyst_block
fill 183 154 536 183 155 536 minecraft:purple_stained_glass
fill 162 155 510 162 167 510 minecraft:crying_obsidian
fill 183 155 514 183 214 514 minecraft:crying_obsidian
fill 183 155 527 183 157 527 minecraft:crying_obsidian
fill 141 156 518 141 161 518 minecraft:crying_obsidian
fill 141 156 534 141 161 534 minecraft:crying_obsidian
fill 141 156 550 141 161 550 minecraft:crying_obsidian
fill 145 156 510 145 161 510 minecraft:crying_obsidian
fill 155 156 552 155 161 552 minecraft:crying_obsidian
fill 161 156 510 161 161 510 minecraft:crying_obsidian
fill 171 156 552 171 161 552 minecraft:crying_obsidian
fill 177 156 510 177 161 510 minecraft:crying_obsidian
fill 183 156 520 183 161 520 minecraft:crying_obsidian
fill 183 156 536 183 161 536 minecraft:crying_obsidian
fill 148 157 510 151 164 510 minecraft:crying_obsidian
setblock 152 157 510 minecraft:amethyst_block
setblock 162 157 552 minecraft:amethyst_block
fill 163 157 552 163 183 552 minecraft:crying_obsidian
fill 152 158 510 152 213 510 minecraft:crying_obsidian
fill 162 158 552 162 214 552 minecraft:crying_obsidian
setblock 183 158 527 minecraft:amethyst_block
setblock 183 158 532 minecraft:amethyst_block
fill 141 159 545 141 214 545 minecraft:crying_obsidian
setblock 141 159 546 minecraft:amethyst_block
fill 141 159 547 141 172 549 minecraft:crying_obsidian
setblock 150 159 552 minecraft:white_concrete
setblock 152 159 552 minecraft:amethyst_block
fill 153 159 552 154 207 552 minecraft:crying_obsidian
fill 183 159 527 183 213 527 minecraft:crying_obsidian
fill 183 159 532 183 184 532 minecraft:crying_obsidian
fill 183 159 541 183 159 542 minecraft:amethyst_block
setblock 141 160 515 minecraft:amethyst_block
fill 141 160 516 141 184 516 minecraft:crying_obsidian
fill 141 160 546 141 213 546 minecraft:crying_obsidian
setblock 150 160 552 minecraft:crying_obsidian
fill 152 160 552 152 176 552 minecraft:crying_obsidian
setblock 183 160 511 minecraft:white_concrete
fill 183 160 541 183 172 542 minecraft:crying_obsidian
fill 141 161 515 141 213 515 minecraft:crying_obsidian
setblock 150 161 552 minecraft:amethyst_block
fill 183 161 511 183 213 511 minecraft:crying_obsidian
fill 141 162 518 141 164 518 minecraft:purple_stained_glass
setblock 141 162 531 minecraft:white_concrete
fill 141 162 532 141 213 532 minecraft:crying_obsidian
fill 141 162 534 141 164 534 minecraft:purple_stained_glass
fill 141 162 550 141 164 550 minecraft:purple_stained_glass
setblock 144 162 513 minecraft:light[level=12]
setblock 144 162 521 minecraft:light[level=12]
setblock 144 162 529 minecraft:light[level=12]
setblock 144 162 537 minecraft:light[level=12]
setblock 144 162 545 minecraft:light[level=12]
fill 145 162 510 145 164 510 minecraft:purple_stained_glass
fill 150 162 552 150 213 552 minecraft:crying_obsidian
setblock 152 162 513 minecraft:light[level=12]
setblock 152 162 521 minecraft:light[level=12]
setblock 152 162 529 minecraft:light[level=12]
setblock 152 162 537 minecraft:light[level=12]
setblock 152 162 545 minecraft:light[level=12]
fill 155 162 552 155 164 552 minecraft:purple_stained_glass
setblock 160 162 513 minecraft:light[level=12]
setblock 160 162 521 minecraft:light[level=12]
setblock 160 162 529 minecraft:light[level=12]
setblock 160 162 537 minecraft:light[level=12]
setblock 160 162 545 minecraft:light[level=12]
fill 161 162 510 161 164 510 minecraft:purple_stained_glass
setblock 168 162 513 minecraft:light[level=12]
setblock 168 162 521 minecraft:light[level=12]
setblock 168 162 529 minecraft:light[level=12]
setblock 168 162 537 minecraft:light[level=12]
setblock 168 162 545 minecraft:light[level=12]
fill 171 162 552 171 164 552 minecraft:purple_stained_glass
setblock 176 162 513 minecraft:light[level=12]
setblock 176 162 521 minecraft:light[level=12]
setblock 176 162 529 minecraft:light[level=12]
setblock 176 162 537 minecraft:light[level=12]
setblock 176 162 545 minecraft:light[level=12]
fill 177 162 510 177 164 510 minecraft:purple_stained_glass
fill 183 162 520 183 164 520 minecraft:purple_stained_glass
fill 183 162 536 183 164 536 minecraft:purple_stained_glass
fill 141 163 531 141 210 531 minecraft:crying_obsidian
fill 141 164 512 141 213 512 minecraft:crying_obsidian
setblock 141 164 513 minecraft:amethyst_block
setblock 183 164 535 minecraft:white_concrete
setblock 183 164 546 minecraft:white_concrete
fill 183 164 547 183 195 548 minecraft:crying_obsidian
fill 141 165 513 141 213 513 minecraft:crying_obsidian
fill 141 165 518 141 170 518 minecraft:crying_obsidian
fill 141 165 534 141 170 534 minecraft:crying_obsidian
fill 141 165 550 141 170 550 minecraft:crying_obsidian
fill 145 165 510 145 170 510 minecraft:crying_obsidian
fill 148 165 510 148 213 510 minecraft:crying_obsidian
setblock 149 165 510 minecraft:amethyst_block
fill 150 165 510 151 213 510 minecraft:crying_obsidian
fill 155 165 552 155 170 552 minecraft:crying_obsidian
fill 161 165 510 161 170 510 minecraft:crying_obsidian
fill 171 165 552 171 170 552 minecraft:crying_obsidian
fill 177 165 510 177 170 510 minecraft:crying_obsidian
fill 183 165 520 183 170 520 minecraft:crying_obsidian
fill 183 165 535 183 170 536 minecraft:crying_obsidian
fill 183 165 546 183 210 546 minecraft:crying_obsidian
fill 149 166 510 149 213 510 minecraft:crying_obsidian
setblock 164 166 510 minecraft:white_concrete
setblock 153 167 510 minecraft:white_concrete
fill 154 167 510 155 176 510 minecraft:crying_obsidian
setblock 163 167 510 minecraft:white_concrete
fill 164 167 510 164 213 510 minecraft:crying_obsidian
fill 153 168 510 153 213 510 minecraft:crying_obsidian
setblock 160 168 552 minecraft:white_concrete
setblock 162 168 510 minecraft:amethyst_block
fill 163 168 510 163 194 510 minecraft:crying_obsidian
fill 166 168 545 167 169 545 minecraft:crying_obsidian
setblock 170 168 552 minecraft:amethyst_block
fill 180 168 552 180 212 552 minecraft:crying_obsidian
setblock 181 168 552 minecraft:white_concrete
fill 183 168 537 183 181 537 minecraft:crying_obsidian
setblock 183 168 538 minecraft:white_concrete
fill 160 169 552 160 213 552 minecraft:crying_obsidian
fill 162 169 510 162 213 510 minecraft:crying_obsidian
fill 170 169 552 170 213 552 minecraft:crying_obsidian
setblock 178 169 510 minecraft:white_concrete
fill 181 169 552 181 213 552 minecraft:crying_obsidian
setblock 183 169 531 minecraft:amethyst_block
fill 183 169 538 183 213 538 minecraft:crying_obsidian
setblock 144 170 513 minecraft:light[level=12]
setblock 144 170 521 minecraft:light[level=12]
fill 144 170 527 144 171 529 minecraft:obsidian
setblock 144 170 537 minecraft:light[level=12]
setblock 144 170 545 minecraft:light[level=12]
fill 145 170 528 145 171 528 minecraft:obsidian
setblock 152 170 513 minecraft:light[level=12]
setblock 152 170 521 minecraft:light[level=12]
setblock 152 170 529 minecraft:light[level=12]
setblock 152 170 537 minecraft:light[level=12]
setblock 152 170 545 minecraft:light[level=12]
setblock 160 170 513 minecraft:light[level=12]
setblock 160 170 521 minecraft:light[level=12]
fill 160 170 522 161 171 522 minecraft:crying_obsidian
setblock 160 170 529 minecraft:light[level=12]
setblock 160 170 537 minecraft:light[level=12]
setblock 160 170 545 minecraft:light[level=12]
setblock 168 170 513 minecraft:light[level=12]
setblock 168 170 521 minecraft:light[level=12]
setblock 168 170 529 minecraft:light[level=12]
setblock 168 170 537 minecraft:light[level=12]
setblock 168 170 545 minecraft:light[level=12]
setblock 174 170 552 minecraft:white_concrete
setblock 176 170 513 minecraft:light[level=12]
setblock 176 170 521 minecraft:light[level=12]
setblock 176 170 529 minecraft:light[level=12]
setblock 176 170 537 minecraft:light[level=12]
setblock 176 170 545 minecraft:light[level=12]
fill 178 170 510 178 213 510 minecraft:crying_obsidian
fill 183 170 531 183 209 531 minecraft:crying_obsidian
setblock 183 170 551 minecraft:amethyst_block
fill 141 171 518 141 172 518 minecraft:purple_stained_glass
fill 141 171 534 141 172 534 minecraft:purple_stained_glass
fill 141 171 550 141 172 550 minecraft:purple_stained_glass
setblock 144 171 552 minecraft:white_concrete
fill 145 171 510 145 172 510 minecraft:purple_stained_glass
fill 155 171 552 155 172 552 minecraft:purple_stained_glass
fill 161 171 510 161 172 510 minecraft:purple_stained_glass
fill 171 171 552 171 172 552 minecraft:purple_stained_glass
fill 174 171 552 174 182 552 minecraft:crying_obsidian
fill 177 171 510 177 172 510 minecraft:purple_stained_glass
fill 183 171 520 183 172 520 minecraft:purple_stained_glass
fill 183 171 535 183 213 535 minecraft:crying_obsidian
fill 183 171 536 183 172 536 minecraft:purple_stained_glass
fill 183 171 551 183 211 551 minecraft:crying_obsidian
setblock 141 172 528 minecraft:amethyst_block
fill 141 172 529 141 209 529 minecraft:crying_obsidian
fill 144 172 552 144 213 552 minecraft:crying_obsidian
setblock 151 172 552 minecraft:white_concrete
fill 141 173 518 141 188 518 minecraft:crying_obsidian
fill 141 173 528 141 214 528 minecraft:crying_obsidian
fill 141 173 534 141 188 534 minecraft:crying_obsidian
setblock 141 173 544 minecraft:amethyst_block
fill 141 173 547 141 209 548 minecraft:crying_obsidian
setblock 141 173 549 minecraft:amethyst_block
fill 141 173 550 141 188 550 minecraft:crying_obsidian
fill 145 173 510 145 188 510 minecraft:crying_obsidian
fill 151 173 552 151 211 552 minecraft:crying_obsidian
fill 155 173 552 155 188 552 minecraft:crying_obsidian
fill 161 173 510 161 188 510 minecraft:crying_obsidian
fill 171 173 552 171 188 552 minecraft:crying_obsidian
fill 177 173 510 177 188 510 minecraft:crying_obsidian
fill 183 173 520 183 188 520 minecraft:crying_obsidian
setblock 183 173 526 minecraft:white_concrete
fill 183 173 536 183 174 536 minecraft:crying_obsidian
fill 183 173 541 183 210 541 minecraft:crying_obsidian
setblock 183 173 542 minecraft:white_concrete
fill 141 174 544 141 213 544 minecraft:crying_obsidian
fill 141 174 549 141 175 549 minecraft:crying_obsidian
fill 183 174 526 183 213 526 minecraft:crying_obsidian
fill 183 174 542 183 214 542 minecraft:crying_obsidian
setblock 173 175 552 minecraft:white_concrete
setblock 183 175 536 minecraft:amethyst_block
setblock 141 176 549 minecraft:white_concrete
fill 173 176 552 173 204 552 minecraft:crying_obsidian
setblock 183 176 513 minecraft:amethyst_block
fill 183 176 536 183 188 536 minecraft:crying_obsidian
setblock 141 177 536 minecraft:amethyst_block
fill 141 177 549 141 213 549 minecraft:crying_obsidian
setblock 152 177 552 minecraft:white_concrete
fill 154 177 510 154 213 510 minecraft:crying_obsidian
setblock 155 177 510 minecraft:white_concrete
fill 158 177 530 160 177 532 minecraft:redstone_block
fill 166 177 527 168 177 529 minecraft:redstone_block
fill 166 177 535 168 177 537 minecraft:redstone_block
fill 183 177 513 183 193 513 minecraft:crying_obsidian
fill 141 178 536 141 193 536 minecraft:crying_obsidian
setblock 144 178 513 minecraft:light[level=12]
setblock 144 178 521 minecraft:light[level=12]
setblock 144 178 529 minecraft:light[level=12]
setblock 144 178 537 minecraft:light[level=12]
setblock 144 178 545 minecraft:light[level=12]
fill 150 178 532 151 179 532 minecraft:magenta_concrete
fill 151 178 527 151 179 528 minecraft:purple_concrete
fill 151 178 529 152 179 531 minecraft:magenta_concrete
fill 151 178 533 151 179 533 minecraft:magenta_concrete
fill 151 178 534 154 179 537 minecraft:purple_concrete
setblock 152 178 513 minecraft:light[level=12]
setblock 152 178 521 minecraft:light[level=12]
fill 152 178 525 153 179 527 minecraft:purple_concrete
fill 152 178 528 161 179 528 minecraft:magenta_concrete
fill 152 178 532 157 178 533 minecraft:purple_concrete
fill 152 178 538 154 179 539 minecraft:purple_concrete
setblock 152 178 545 minecraft:light[level=12]
fill 152 178 552 152 213 552 minecraft:crying_obsidian
fill 153 178 524 162 178 524 minecraft:purple_concrete
fill 153 178 529 154 179 530 minecraft:magenta_concrete
fill 153 178 531 157 178 531 minecraft:purple_concrete
fill 153 178 540 154 179 540 minecraft:purple_concrete
fill 154 178 523 161 179 523 minecraft:purple_concrete
fill 154 178 525 163 178 526 minecraft:purple_concrete
fill 154 178 527 160 179 527 minecraft:magenta_concrete
fill 154 178 541 154 179 541 minecraft:purple_concrete
fill 155 178 510 155 209 510 minecraft:crying_obsidian
fill 155 178 522 159 179 522 minecraft:purple_concrete
fill 155 178 529 156 179 529 minecraft:magenta_concrete
fill 155 178 530 157 178 530 minecraft:purple_concrete
fill 155 178 534 155 179 536 minecraft:purple_concrete
fill 155 178 537 157 179 542 minecraft:magenta_concrete
fill 156 178 521 163 179 521 minecraft:magenta_concrete
fill 156 178 534 156 179 534 minecraft:purple_concrete
fill 156 178 535 158 179 536 minecraft:magenta_concrete
fill 156 178 543 158 179 543 minecraft:magenta_concrete
fill 157 178 520 162 179 520 minecraft:magenta_concrete
fill 157 178 529 160 178 529 minecraft:purple_concrete
fill 157 178 534 159 179 534 minecraft:magenta_concrete
fill 157 178 544 158 179 544 minecraft:magenta_concrete
fill 158 178 533 160 178 533 minecraft:magenta_concrete
fill 158 178 537 161 178 542 minecraft:purple_concrete
fill 159 178 519 160 179 519 minecraft:magenta_concrete
fill 159 178 535 161 179 536 minecraft:purple_concrete
fill 159 178 543 164 179 544 minecraft:purple_concrete
fill 159 178 545 159 179 545 minecraft:magenta_concrete
setblock 160 178 513 minecraft:light[level=12]
fill 160 178 522 164 179 522 minecraft:magenta_concrete
fill 160 178 534 161 179 534 minecraft:purple_concrete
fill 160 178 545 167 179 545 minecraft:purple_concrete
fill 161 178 519 168 179 519 minecraft:purple_concrete
fill 161 178 527 164 178 527 minecraft:purple_concrete
fill 161 178 529 162 178 529 minecraft:magenta_concrete
setblock 161 178 530 minecraft:purple_concrete
fill 161 178 531 162 178 533 minecraft:black_concrete
fill 162 178 523 165 179 523 minecraft:magenta_concrete
fill 162 178 528 164 179 528 minecraft:purple_concrete
fill 162 178 530 166 178 530 minecraft:black_concrete
fill 162 178 534 166 178 534 minecraft:black_concrete
fill 162 178 535 162 178 539 minecraft:magenta_concrete
fill 162 178 540 162 178 542 minecraft:purple_concrete
fill 163 178 520 169 179 520 minecraft:purple_concrete
fill 163 178 524 165 178 524 minecraft:magenta_concrete
fill 163 178 529 165 178 529 minecraft:black_concrete
fill 163 178 535 165 178 535 minecraft:black_concrete
fill 163 178 536 163 178 541 minecraft:magenta_concrete
fill 163 178 542 163 179 542 minecraft:purple_concrete
fill 164 178 518 164 179 518 minecraft:purple_concrete
fill 164 178 521 169 179 521 minecraft:purple_concrete
fill 164 178 525 166 178 525 minecraft:magenta_concrete
setblock 164 178 526 minecraft:purple_concrete
fill 164 178 536 165 178 538 minecraft:purple_concrete
fill 164 178 539 164 178 542 minecraft:magenta_concrete
fill 164 178 546 164 179 546 minecraft:purple_concrete
fill 165 178 522 170 179 522 minecraft:purple_concrete
fill 165 178 526 165 178 528 minecraft:magenta_concrete
fill 165 178 539 176 178 539 minecraft:purple_concrete
fill 165 178 540 165 178 543 minecraft:magenta_concrete
fill 165 178 544 165 179 544 minecraft:purple_concrete
fill 166 178 523 170 178 524 minecraft:purple_concrete
setblock 166 178 526 minecraft:magenta_concrete
fill 166 178 531 167 178 533 minecraft:black_concrete
fill 166 178 538 176 178 538 minecraft:purple_concrete
fill 166 178 540 175 178 540 minecraft:purple_concrete
fill 166 178 541 166 179 544 minecraft:magenta_concrete
fill 167 178 525 170 178 526 minecraft:purple_concrete
fill 167 178 530 168 178 530 minecraft:purple_concrete
fill 167 178 534 173 178 534 minecraft:purple_concrete
fill 167 178 541 174 179 541 minecraft:purple_concrete
fill 167 178 542 168 179 544 minecraft:magenta_concrete
setblock 168 178 513 minecraft:light[level=12]
setblock 168 178 529 minecraft:light[level=12]
fill 168 178 531 169 179 532 minecraft:magenta_concrete
fill 168 178 533 175 179 533 minecraft:purple_concrete
setblock 168 178 537 minecraft:light[level=12]
fill 168 178 545 169 179 545 minecraft:magenta_concrete
fill 169 178 519 169 179 519 minecraft:magenta_concrete
fill 169 178 527 169 178 529 minecraft:purple_concrete
fill 169 178 530 171 178 530 minecraft:magenta_concrete
fill 169 178 535 171 178 535 minecraft:purple_concrete
fill 169 178 536 174 178 537 minecraft:magenta_concrete
fill 169 178 542 173 179 542 minecraft:purple_concrete
fill 169 178 543 171 179 544 minecraft:magenta_concrete
fill 170 178 520 171 179 521 minecraft:magenta_concrete
fill 170 178 527 170 179 527 minecraft:purple_concrete
fill 170 178 528 172 179 529 minecraft:magenta_concrete
fill 170 178 531 170 179 531 minecraft:magenta_concrete
fill 170 178 532 176 179 532 minecraft:purple_concrete
fill 171 178 522 173 179 527 minecraft:magenta_concrete
fill 171 178 531 176 179 531 minecraft:purple_concrete
fill 172 178 521 172 179 521 minecraft:magenta_concrete
fill 172 178 530 177 179 530 minecraft:purple_concrete
fill 172 178 535 177 179 535 minecraft:magenta_concrete
fill 172 178 543 172 179 543 minecraft:magenta_concrete
fill 173 178 528 177 179 529 minecraft:purple_concrete
fill 174 178 523 174 179 527 minecraft:purple_concrete
fill 174 178 534 177 179 534 minecraft:magenta_concrete
fill 175 178 524 175 179 527 minecraft:purple_concrete
fill 175 178 536 176 179 536 minecraft:magenta_concrete
fill 175 178 537 177 179 537 minecraft:purple_concrete
setblock 176 178 513 minecraft:light[level=12]
setblock 176 178 521 minecraft:light[level=12]
fill 176 178 525 176 179 527 minecraft:purple_concrete
fill 176 178 533 177 179 533 minecraft:magenta_concrete
setblock 176 178 545 minecraft:light[level=12]
fill 177 178 527 177 179 527 minecraft:purple_concrete
fill 177 178 531 177 179 532 minecraft:magenta_concrete
fill 177 178 536 177 179 536 minecraft:purple_concrete
fill 178 178 532 178 179 532 minecraft:magenta_concrete
setblock 183 178 549 minecraft:amethyst_block
fill 142 179 511 149 179 551 minecraft:black_concrete
fill 150 179 511 150 179 531 minecraft:black_concrete
fill 150 179 533 150 179 551 minecraft:black_concrete
fill 151 179 511 151 179 526 minecraft:black_concrete
fill 151 179 538 151 179 551 minecraft:black_concrete
fill 152 179 511 152 179 524 minecraft:black_concrete
fill 152 179 532 156 179 533 minecraft:purple_concrete
fill 152 179 540 152 179 551 minecraft:black_concrete
fill 153 179 511 153 179 523 minecraft:black_concrete
fill 153 179 524 161 179 524 minecraft:purple_concrete
fill 153 179 531 156 179 531 minecraft:purple_concrete
fill 153 179 541 153 179 551 minecraft:black_concrete
fill 154 179 511 154 179 522 minecraft:black_concrete
fill 154 179 525 159 179 526 minecraft:purple_concrete
fill 154 179 542 154 179 551 minecraft:black_concrete
fill 155 179 511 155 179 521 minecraft:black_concrete
fill 155 179 530 156 179 530 minecraft:purple_concrete
fill 155 179 543 155 179 551 minecraft:black_concrete
fill 156 179 511 156 179 520 minecraft:black_concrete
fill 156 179 544 156 179 551 minecraft:black_concrete
fill 157 179 511 158 179 519 minecraft:black_concrete
fill 157 179 529 157 179 533 minecraft:crying_obsidian
fill 157 179 545 158 179 551 minecraft:black_concrete
fill 158 179 529 161 179 529 minecraft:crying_obsidian
fill 158 179 530 160 179 532 minecraft:black_concrete
fill 158 179 533 161 179 533 minecraft:crying_obsidian
fill 158 179 537 159 179 542 minecraft:purple_concrete
fill 159 179 511 163 179 518 minecraft:black_concrete
fill 159 179 546 163 179 551 minecraft:black_concrete
fill 160 179 525 168 190 526 minecraft:green_terracotta
fill 160 179 537 161 179 537 minecraft:purple_concrete
fill 160 179 538 168 190 539 minecraft:lime_terracotta
fill 160 179 540 161 179 542 minecraft:purple_concrete
setblock 161 179 527 minecraft:purple_concrete
fill 161 179 530 161 179 532 minecraft:crying_obsidian
fill 162 179 524 166 190 524 minecraft:green_terracotta
fill 162 179 527 166 190 527 minecraft:green_terracotta
setblock 162 179 529 minecraft:magenta_concrete
setblock 162 179 530 minecraft:crying_obsidian
fill 162 179 531 162 179 533 minecraft:verdant_froglight
setblock 162 179 534 minecraft:crying_obsidian
fill 162 179 535 162 179 536 minecraft:magenta_concrete
fill 162 179 537 166 190 537 minecraft:lime_terracotta
fill 162 179 540 166 190 540 minecraft:lime_terracotta
fill 162 179 541 162 179 542 minecraft:purple_concrete
fill 163 179 529 164 179 529 minecraft:black_concrete
fill 163 179 530 165 179 530 minecraft:verdant_froglight
fill 163 179 534 165 179 534 minecraft:verdant_froglight
fill 163 179 535 164 179 535 minecraft:black_concrete
setblock 163 179 536 minecraft:magenta_concrete
fill 163 179 541 165 179 541 minecraft:magenta_concrete
fill 164 179 511 182 179 517 minecraft:black_concrete
setblock 164 179 536 minecraft:purple_concrete
fill 164 179 542 165 179 542 minecraft:magenta_concrete
fill 164 179 547 182 179 551 minecraft:black_concrete
fill 165 179 518 182 179 518 minecraft:black_concrete
fill 165 179 528 165 179 529 minecraft:crying_obsidian
fill 165 179 535 165 179 536 minecraft:crying_obsidian
setblock 165 179 543 minecraft:magenta_concrete
fill 165 179 546 182 179 546 minecraft:black_concrete
fill 166 179 523 170 179 523 minecraft:purple_concrete
fill 166 179 528 168 179 529 minecraft:black_concrete
fill 166 179 530 169 179 530 minecraft:crying_obsidian
fill 166 179 531 166 179 533 minecraft:verdant_froglight
fill 166 179 534 169 179 534 minecraft:crying_obsidian
fill 166 179 535 168 179 536 minecraft:black_concrete
fill 167 179 524 170 179 524 minecraft:purple_concrete
fill 167 179 527 168 179 527 minecraft:black_concrete
fill 167 179 531 167 179 533 minecraft:black_concrete
fill 167 179 537 168 179 537 minecraft:black_concrete
fill 167 179 540 175 179 540 minecraft:purple_concrete
fill 169 179 525 170 179 525 minecraft:purple_concrete
fill 169 179 526 169 179 529 minecraft:crying_obsidian
fill 169 179 535 169 179 538 minecraft:crying_obsidian
fill 169 179 539 176 179 539 minecraft:purple_concrete
fill 170 179 519 182 179 519 minecraft:black_concrete
setblock 170 179 526 minecraft:purple_concrete
fill 170 179 530 171 179 530 minecraft:magenta_concrete
fill 170 179 534 171 179 535 minecraft:purple_concrete
fill 170 179 536 174 179 537 minecraft:magenta_concrete
fill 170 179 538 176 179 538 minecraft:purple_concrete
fill 170 179 545 182 179 545 minecraft:black_concrete
fill 172 179 520 182 179 520 minecraft:black_concrete
fill 172 179 534 173 179 534 minecraft:purple_concrete
fill 172 179 544 182 179 544 minecraft:black_concrete
fill 173 179 521 182 179 521 minecraft:black_concrete
fill 173 179 543 182 179 543 minecraft:black_concrete
fill 174 179 522 182 179 522 minecraft:black_concrete
fill 174 179 542 182 179 542 minecraft:black_concrete
fill 175 179 523 182 179 523 minecraft:black_concrete
fill 175 179 541 182 179 541 minecraft:black_concrete
fill 176 179 524 182 179 524 minecraft:black_concrete
fill 176 179 540 182 179 540 minecraft:black_concrete
fill 177 179 525 182 179 526 minecraft:black_concrete
fill 177 179 538 182 179 539 minecraft:black_concrete
fill 178 179 527 182 179 531 minecraft:black_concrete
fill 178 179 533 182 179 537 minecraft:black_concrete
fill 179 179 532 182 179 532 minecraft:black_concrete
setblock 183 179 528 minecraft:white_concrete
fill 183 179 549 183 182 549 minecraft:crying_obsidian
fill 158 180 524 159 189 527 minecraft:green_terracotta
fill 158 180 537 159 189 540 minecraft:lime_terracotta
fill 160 180 524 161 190 524 minecraft:green_terracotta
fill 160 180 527 161 190 527 minecraft:green_terracotta
fill 160 180 537 161 190 537 minecraft:lime_terracotta
fill 160 180 540 161 190 540 minecraft:lime_terracotta
fill 161 180 523 167 189 523 minecraft:green_terracotta
fill 161 180 528 167 187 528 minecraft:green_terracotta
fill 161 180 536 167 187 536 minecraft:lime_terracotta
fill 161 180 541 167 189 541 minecraft:lime_terracotta
fill 167 180 524 170 189 524 minecraft:green_terracotta
fill 167 180 527 170 189 527 minecraft:green_terracotta
fill 167 180 537 170 189 537 minecraft:lime_terracotta
fill 167 180 540 170 189 540 minecraft:lime_terracotta
fill 169 180 525 170 190 526 minecraft:green_terracotta
fill 169 180 538 170 190 539 minecraft:lime_terracotta
fill 183 180 528 183 201 528 minecraft:crying_obsidian
fill 156 181 525 157 189 526 minecraft:green_terracotta
fill 156 181 538 157 189 539 minecraft:lime_terracotta
fill 157 181 524 157 189 524 minecraft:green_terracotta
fill 157 181 527 157 189 527 minecraft:green_terracotta
fill 157 181 537 157 189 537 minecraft:lime_terracotta
fill 157 181 540 157 189 540 minecraft:lime_terracotta
fill 158 181 523 160 188 523 minecraft:green_terracotta
fill 158 181 528 160 188 528 minecraft:green_terracotta
fill 158 181 536 160 188 536 minecraft:lime_terracotta
fill 158 181 541 160 188 541 minecraft:lime_terracotta
fill 163 181 522 165 188 522 minecraft:green_terracotta
fill 163 181 529 165 183 529 minecraft:green_terracotta
fill 163 181 535 165 183 535 minecraft:lime_terracotta
fill 163 181 542 165 188 542 minecraft:lime_terracotta
fill 168 181 523 170 188 523 minecraft:green_terracotta
fill 168 181 528 170 188 528 minecraft:green_terracotta
fill 168 181 536 170 188 536 minecraft:lime_terracotta
fill 168 181 541 170 188 541 minecraft:lime_terracotta
fill 171 181 524 171 189 527 minecraft:green_terracotta
fill 171 181 537 171 189 540 minecraft:lime_terracotta
fill 172 181 525 172 189 526 minecraft:green_terracotta
fill 172 181 538 172 189 539 minecraft:lime_terracotta
setblock 141 182 522 minecraft:white_concrete
fill 155 182 524 155 187 527 minecraft:green_terracotta
fill 155 182 537 155 187 540 minecraft:lime_terracotta
fill 156 182 524 156 188 524 minecraft:green_terracotta
fill 156 182 527 156 188 527 minecraft:green_terracotta
fill 156 182 537 156 188 537 minecraft:lime_terracotta
fill 156 182 540 156 188 540 minecraft:lime_terracotta
fill 157 182 523 157 188 523 minecraft:green_terracotta
fill 157 182 528 157 188 528 minecraft:green_terracotta
fill 157 182 536 157 188 536 minecraft:lime_terracotta
fill 157 182 541 157 188 541 minecraft:lime_terracotta
fill 160 182 522 162 188 522 minecraft:green_terracotta
fill 160 182 529 162 184 529 minecraft:green_terracotta
fill 160 182 535 162 184 535 minecraft:lime_terracotta
fill 160 182 542 162 188 542 minecraft:lime_terracotta
fill 166 182 522 168 188 522 minecraft:green_terracotta
fill 166 182 529 168 184 529 minecraft:green_terracotta
fill 166 182 535 168 184 535 minecraft:lime_terracotta
fill 166 182 542 168 188 542 minecraft:lime_terracotta
fill 171 182 523 171 188 523 minecraft:green_terracotta
fill 171 182 528 171 188 528 minecraft:green_terracotta
fill 171 182 536 171 188 536 minecraft:lime_terracotta
fill 171 182 541 171 188 541 minecraft:lime_terracotta
fill 172 182 524 173 187 524 minecraft:green_terracotta
fill 172 182 527 173 187 527 minecraft:green_terracotta
fill 172 182 537 173 187 537 minecraft:lime_terracotta
fill 172 182 540 173 187 540 minecraft:lime_terracotta
fill 173 182 525 173 188 526 minecraft:green_terracotta
fill 173 182 538 173 188 539 minecraft:lime_terracotta
setblock 183 182 537 minecraft:white_concrete
fill 141 183 522 141 185 522 minecraft:crying_obsidian
fill 147 183 530 154 184 533 minecraft:obsidian
fill 148 183 529 153 184 529 minecraft:obsidian
fill 148 183 534 154 184 534 minecraft:obsidian
fill 149 183 528 152 184 528 minecraft:obsidian
fill 149 183 535 153 184 535 minecraft:obsidian
fill 154 183 525 154 187 526 minecraft:green_terracotta
fill 154 183 538 154 187 539 minecraft:lime_terracotta
fill 156 183 523 156 187 523 minecraft:green_terracotta
fill 156 183 528 156 187 528 minecraft:green_terracotta
fill 156 183 536 156 187 536 minecraft:lime_terracotta
fill 156 183 541 156 187 541 minecraft:lime_terracotta
fill 158 183 522 159 186 522 minecraft:green_terracotta
fill 158 183 529 159 184 529 minecraft:green_terracotta
fill 158 183 535 159 184 535 minecraft:lime_terracotta
fill 158 183 542 159 186 542 minecraft:lime_terracotta
fill 169 183 522 170 186 522 minecraft:green_terracotta
fill 169 183 529 170 185 529 minecraft:green_terracotta
fill 169 183 535 170 185 535 minecraft:lime_terracotta
fill 169 183 542 170 186 542 minecraft:lime_terracotta
fill 172 183 523 172 187 523 minecraft:green_terracotta
fill 172 183 528 172 187 528 minecraft:green_terracotta
fill 172 183 536 172 187 536 minecraft:lime_terracotta
fill 172 183 541 172 187 541 minecraft:lime_terracotta
fill 174 183 525 174 187 526 minecraft:green_terracotta
fill 174 183 538 174 187 539 minecraft:lime_terracotta
setblock 174 183 552 minecraft:white_concrete
fill 183 183 537 183 214 537 minecraft:crying_obsidian
setblock 183 183 549 minecraft:amethyst_block
setblock 141 184 535 minecraft:white_concrete
setblock 146 184 532 minecraft:obsidian
setblock 147 184 529 minecraft:obsidian
setblock 147 184 534 minecraft:obsidian
setblock 148 184 528 minecraft:obsidian
setblock 148 184 535 minecraft:obsidian
fill 150 184 536 152 184 536 minecraft:obsidian
setblock 153 184 528 minecraft:obsidian
fill 154 184 524 154 186 524 minecraft:green_terracotta
fill 154 184 527 154 186 527 minecraft:green_terracotta
setblock 154 184 529 minecraft:obsidian
fill 154 184 537 154 186 537 minecraft:lime_terracotta
fill 154 184 540 154 186 540 minecraft:lime_terracotta
fill 155 184 523 155 185 523 minecraft:green_terracotta
fill 155 184 528 155 185 528 minecraft:green_terracotta
fill 155 184 531 155 184 533 minecraft:obsidian
fill 155 184 536 155 185 536 minecraft:lime_terracotta
fill 155 184 541 155 185 541 minecraft:lime_terracotta
setblock 163 184 529 minecraft:green_terracotta
setblock 163 184 535 minecraft:lime_terracotta
setblock 163 184 552 minecraft:amethyst_block
setblock 165 184 529 minecraft:green_terracotta
setblock 165 184 535 minecraft:lime_terracotta
fill 173 184 523 173 185 523 minecraft:green_terracotta
fill 173 184 528 173 185 528 minecraft:green_terracotta
fill 173 184 536 173 185 536 minecraft:lime_terracotta
fill 173 184 541 173 185 541 minecraft:lime_terracotta
fill 174 184 524 174 186 524 minecraft:green_terracotta
fill 174 184 527 174 186 527 minecraft:green_terracotta
fill 174 184 537 174 186 537 minecraft:lime_terracotta
fill 174 184 540 174 186 540 minecraft:lime_terracotta
fill 174 184 552 174 207 552 minecraft:crying_obsidian
fill 183 184 549 183 196 549 minecraft:crying_obsidian
setblock 141 185 516 minecraft:amethyst_block
fill 141 185 535 141 213 535 minecraft:crying_obsidian
fill 150 185 531 151 186 532 minecraft:amethyst_block
fill 158 185 529 158 187 529 minecraft:white_concrete
fill 158 185 535 158 187 535 minecraft:white_concrete
setblock 158 185 552 minecraft:white_concrete
fill 159 185 529 161 187 529 minecraft:green_terracotta
fill 159 185 535 161 187 535 minecraft:lime_terracotta
fill 162 185 529 162 187 530 minecraft:white_concrete
fill 162 185 534 162 187 535 minecraft:white_concrete
fill 163 185 552 163 209 552 minecraft:crying_obsidian
fill 166 185 529 167 186 529 minecraft:green_terracotta
fill 166 185 535 167 186 535 minecraft:lime_terracotta
fill 168 185 529 168 187 530 minecraft:white_concrete
fill 168 185 534 168 187 535 minecraft:white_concrete
fill 171 185 529 171 187 529 minecraft:white_concrete
fill 171 185 535 171 187 535 minecraft:white_concrete
setblock 183 185 532 minecraft:white_concrete
fill 141 186 516 141 188 516 minecraft:crying_obsidian
setblock 141 186 522 minecraft:white_concrete
fill 142 186 536 147 186 536 minecraft:amethyst_block
setblock 144 186 513 minecraft:light[level=12]
setblock 144 186 521 minecraft:light[level=12]
setblock 144 186 529 minecraft:light[level=12]
setblock 144 186 537 minecraft:light[level=12]
setblock 144 186 545 minecraft:light[level=12]
setblock 152 186 513 minecraft:light[level=12]
setblock 152 186 521 minecraft:light[level=12]
setblock 152 186 529 minecraft:light[level=12]
setblock 152 186 537 minecraft:light[level=12]
setblock 152 186 545 minecraft:light[level=12]
fill 157 186 529 157 187 529 minecraft:white_concrete
fill 157 186 535 157 187 535 minecraft:white_concrete
fill 158 186 530 158 187 530 minecraft:white_concrete
fill 158 186 534 158 187 534 minecraft:white_concrete
fill 158 186 552 158 213 552 minecraft:crying_obsidian
setblock 160 186 513 minecraft:light[level=12]
setblock 160 186 521 minecraft:light[level=12]
setblock 160 186 545 minecraft:light[level=12]
fill 163 186 529 163 187 530 minecraft:white_concrete
fill 163 186 534 163 187 535 minecraft:white_concrete
setblock 168 186 513 minecraft:light[level=12]
setblock 168 186 521 minecraft:light[level=12]
setblock 168 186 545 minecraft:light[level=12]
fill 169 186 529 169 187 530 minecraft:white_concrete
fill 169 186 534 169 187 535 minecraft:white_concrete
setblock 170 186 529 minecraft:green_terracotta
setblock 170 186 535 minecraft:lime_terracotta
fill 171 186 530 171 187 530 minecraft:white_concrete
fill 171 186 534 171 187 534 minecraft:white_concrete
setblock 176 186 513 minecraft:light[level=12]
setblock 176 186 521 minecraft:light[level=12]
setblock 176 186 529 minecraft:light[level=12]
setblock 176 186 537 minecraft:light[level=12]
setblock 176 186 545 minecraft:light[level=12]
fill 183 186 532 183 213 532 minecraft:crying_obsidian
fill 141 187 522 141 189 522 minecraft:crying_obsidian
fill 142 187 535 144 187 537 minecraft:amethyst_block
fill 145 187 536 146 187 536 minecraft:amethyst_block
fill 150 187 532 151 187 532 minecraft:amethyst_block
setblock 151 187 531 minecraft:amethyst_block
setblock 157 187 530 minecraft:white_concrete
setblock 157 187 534 minecraft:white_concrete
setblock 159 187 522 minecraft:green_terracotta
setblock 159 187 542 minecraft:lime_terracotta
fill 167 187 529 167 188 529 minecraft:green_terracotta
fill 167 187 535 167 188 535 minecraft:lime_terracotta
setblock 169 187 522 minecraft:green_terracotta
setblock 169 187 542 minecraft:lime_terracotta
setblock 181 187 510 minecraft:white_concrete
fill 142 188 535 143 188 537 minecraft:amethyst_block
setblock 144 188 536 minecraft:amethyst_block
setblock 151 188 532 minecraft:amethyst_block
fill 155 188 525 155 188 526 minecraft:green_terracotta
fill 155 188 538 155 188 539 minecraft:lime_terracotta
fill 160 188 529 161 188 529 minecraft:green_terracotta
fill 160 188 535 161 188 535 minecraft:lime_terracotta
fill 161 188 528 163 188 528 minecraft:green_terracotta
fill 161 188 536 163 188 536 minecraft:lime_terracotta
fill 165 188 528 167 188 528 minecraft:green_terracotta
fill 165 188 536 167 188 536 minecraft:lime_terracotta
setblock 168 188 529 minecraft:green_terracotta
setblock 168 188 535 minecraft:lime_terracotta
setblock 172 188 524 minecraft:green_terracotta
setblock 172 188 527 minecraft:green_terracotta
setblock 172 188 537 minecraft:lime_terracotta
setblock 172 188 540 minecraft:lime_terracotta
fill 181 188 510 181 202 510 minecraft:crying_obsidian
setblock 183 188 523 minecraft:white_concrete
fill 141 189 516 141 190 516 minecraft:amethyst_block
fill 141 189 518 141 191 518 minecraft:purple_stained_glass
fill 141 189 534 141 191 534 minecraft:purple_stained_glass
fill 141 189 550 141 191 550 minecraft:purple_stained_glass
setblock 142 189 536 minecraft:amethyst_block
fill 145 189 510 145 191 510 minecraft:purple_stained_glass
setblock 145 189 552 minecraft:amethyst_block
fill 153 189 530 155 190 530 minecraft:obsidian
fill 154 189 529 155 190 529 minecraft:obsidian
fill 155 189 552 155 191 552 minecraft:purple_stained_glass
fill 159 189 523 160 189 523 minecraft:green_terracotta
fill 159 189 528 162 189 528 minecraft:green_terracotta
fill 159 189 536 162 189 536 minecraft:lime_terracotta
fill 159 189 541 160 189 541 minecraft:lime_terracotta
fill 161 189 510 161 191 510 minecraft:purple_stained_glass
fill 166 189 528 169 189 528 minecraft:green_terracotta
fill 166 189 536 169 189 536 minecraft:lime_terracotta
fill 168 189 523 169 189 523 minecraft:green_terracotta
fill 168 189 541 169 189 541 minecraft:lime_terracotta
fill 171 189 552 171 191 552 minecraft:purple_stained_glass
fill 177 189 510 177 191 510 minecraft:purple_stained_glass
fill 183 189 520 183 191 520 minecraft:purple_stained_glass
fill 183 189 523 183 207 523 minecraft:crying_obsidian
fill 183 189 536 183 191 536 minecraft:purple_stained_glass
setblock 141 190 522 minecraft:amethyst_block
fill 145 190 552 145 213 552 minecraft:crying_obsidian
fill 157 190 526 159 191 526 minecraft:pearlescent_froglight
fill 157 190 538 159 191 538 minecraft:pearlescent_froglight
fill 158 190 525 158 191 525 minecraft:pearlescent_froglight
fill 158 190 527 158 191 527 minecraft:pearlescent_froglight
fill 158 190 537 158 191 537 minecraft:pearlescent_froglight
fill 158 190 539 158 191 539 minecraft:pearlescent_froglight
fill 159 190 524 159 190 525 minecraft:green_terracotta
setblock 159 190 527 minecraft:green_terracotta
setblock 159 190 537 minecraft:lime_terracotta
fill 159 190 539 159 190 540 minecraft:lime_terracotta
fill 162 190 523 166 190 523 minecraft:green_terracotta
fill 162 190 541 166 190 541 minecraft:lime_terracotta
fill 167 190 524 169 190 524 minecraft:green_terracotta
fill 167 190 527 169 190 527 minecraft:green_terracotta
fill 167 190 537 169 190 537 minecraft:lime_terracotta
fill 167 190 540 169 190 540 minecraft:lime_terracotta
fill 141 191 516 141 213 516 minecraft:crying_obsidian
fill 141 191 522 141 213 522 minecraft:crying_obsidian
fill 161 191 525 167 191 526 minecraft:green_terracotta
fill 161 191 538 167 191 539 minecraft:lime_terracotta
fill 141 192 518 141 197 518 minecraft:crying_obsidian
fill 141 192 534 141 197 534 minecraft:crying_obsidian
fill 141 192 550 141 197 550 minecraft:crying_obsidian
fill 145 192 510 145 197 510 minecraft:crying_obsidian
fill 155 192 552 155 197 552 minecraft:crying_obsidian
setblock 156 192 510 minecraft:white_concrete
fill 161 192 510 161 197 510 minecraft:crying_obsidian
fill 171 192 552 171 197 552 minecraft:crying_obsidian
fill 177 192 510 177 194 510 minecraft:crying_obsidian
fill 183 192 520 183 197 520 minecraft:crying_obsidian
fill 183 192 536 183 197 536 minecraft:crying_obsidian
setblock 141 193 537 minecraft:amethyst_block
fill 156 193 510 156 200 510 minecraft:crying_obsidian
setblock 182 193 552 minecraft:white_concrete
fill 183 193 521 183 213 521 minecraft:crying_obsidian
setblock 183 193 522 minecraft:amethyst_block
setblock 141 194 536 minecraft:amethyst_block
fill 141 194 537 141 213 537 minecraft:crying_obsidian
setblock 144 194 513 minecraft:light[level=12]
setblock 144 194 521 minecraft:light[level=12]
setblock 144 194 529 minecraft:light[level=12]
setblock 144 194 537 minecraft:light[level=12]
setblock 144 194 545 minecraft:light[level=12]
setblock 147 194 552 minecraft:amethyst_block
setblock 152 194 513 minecraft:light[level=12]
setblock 152 194 521 minecraft:light[level=12]
setblock 152 194 529 minecraft:light[level=12]
setblock 152 194 537 minecraft:light[level=12]
setblock 152 194 545 minecraft:light[level=12]
setblock 160 194 513 minecraft:light[level=12]
setblock 160 194 521 minecraft:light[level=12]
setblock 160 194 537 minecraft:light[level=12]
setblock 160 194 545 minecraft:light[level=12]
setblock 168 194 513 minecraft:light[level=12]
setblock 168 194 521 minecraft:light[level=12]
setblock 168 194 537 minecraft:light[level=12]
setblock 168 194 545 minecraft:light[level=12]
setblock 172 194 510 minecraft:amethyst_block
setblock 176 194 513 minecraft:light[level=12]
setblock 176 194 521 minecraft:light[level=12]
setblock 176 194 529 minecraft:light[level=12]
setblock 176 194 537 minecraft:light[level=12]
setblock 176 194 545 minecraft:light[level=12]
fill 182 194 552 182 213 552 minecraft:crying_obsidian
setblock 183 194 513 minecraft:amethyst_block
fill 183 194 522 183 209 522 minecraft:crying_obsidian
fill 141 195 536 141 210 536 minecraft:crying_obsidian
fill 147 195 552 147 211 552 minecraft:crying_obsidian
setblock 163 195 510 minecraft:amethyst_block
fill 172 195 510 172 211 510 minecraft:crying_obsidian
setblock 177 195 510 minecraft:white_concrete
fill 183 195 513 183 213 513 minecraft:crying_obsidian
fill 163 196 510 163 211 510 minecraft:crying_obsidian
fill 177 196 510 177 197 510 minecraft:crying_obsidian
fill 183 196 547 183 206 547 minecraft:crying_obsidian
setblock 183 196 548 minecraft:white_concrete
fill 169 197 511 169 199 515 minecraft:amethyst_block
fill 183 197 548 183 211 548 minecraft:crying_obsidian
setblock 183 197 549 minecraft:white_concrete
fill 141 198 518 141 200 518 minecraft:purple_stained_glass
fill 141 198 534 141 200 534 minecraft:purple_stained_glass
setblock 141 198 543 minecraft:amethyst_block
fill 141 198 550 141 200 550 minecraft:purple_stained_glass
fill 145 198 510 145 200 510 minecraft:purple_stained_glass
fill 155 198 552 155 200 552 minecraft:purple_stained_glass
fill 161 198 510 161 200 510 minecraft:purple_stained_glass
setblock 165 198 552 minecraft:white_concrete
fill 168 198 511 168 198 515 minecraft:amethyst_block
fill 169 198 516 169 198 518 minecraft:amethyst_block
fill 170 198 511 170 198 515 minecraft:amethyst_block
fill 171 198 552 171 200 552 minecraft:purple_stained_glass
fill 177 198 510 177 200 510 minecraft:purple_stained_glass
fill 183 198 520 183 200 520 minecraft:purple_stained_glass
fill 183 198 536 183 200 536 minecraft:purple_stained_glass
fill 183 198 549 183 213 549 minecraft:crying_obsidian
fill 141 199 543 141 213 543 minecraft:crying_obsidian
fill 149 199 511 149 202 511 minecraft:amethyst_block
fill 165 199 552 165 213 552 minecraft:crying_obsidian
fill 168 199 511 168 199 513 minecraft:amethyst_block
fill 170 199 511 170 199 513 minecraft:amethyst_block
setblock 141 200 540 minecraft:amethyst_block
fill 141 200 541 141 213 542 minecraft:crying_obsidian
fill 142 200 510 142 201 510 minecraft:white_concrete
fill 148 200 511 148 201 513 minecraft:amethyst_block
fill 149 200 512 149 202 515 minecraft:amethyst_block
fill 150 200 511 150 201 513 minecraft:amethyst_block
setblock 169 200 511 minecraft:amethyst_block
fill 141 201 518 141 206 518 minecraft:crying_obsidian
fill 141 201 534 141 206 534 minecraft:crying_obsidian
fill 141 201 540 141 213 540 minecraft:crying_obsidian
fill 141 201 550 141 206 550 minecraft:crying_obsidian
fill 145 201 510 145 206 510 minecraft:crying_obsidian
fill 148 201 514 148 201 515 minecraft:amethyst_block
fill 149 201 516 149 201 517 minecraft:amethyst_block
fill 150 201 514 150 201 515 minecraft:amethyst_block
fill 155 201 552 155 206 552 minecraft:crying_obsidian
setblock 156 201 510 minecraft:white_concrete
fill 161 201 510 161 206 510 minecraft:crying_obsidian
fill 171 201 552 171 206 552 minecraft:crying_obsidian
setblock 175 201 510 minecraft:white_concrete
fill 176 201 510 177 206 510 minecraft:crying_obsidian
fill 183 201 520 183 206 520 minecraft:crying_obsidian
fill 183 201 536 183 206 536 minecraft:crying_obsidian
setblock 142 202 510 minecraft:amethyst_block
setblock 144 202 513 minecraft:light[level=12]
setblock 144 202 521 minecraft:light[level=12]
setblock 144 202 529 minecraft:light[level=12]
setblock 144 202 537 minecraft:light[level=12]
setblock 144 202 545 minecraft:light[level=12]
setblock 152 202 513 minecraft:light[level=12]
setblock 152 202 521 minecraft:light[level=12]
setblock 152 202 529 minecraft:light[level=12]
setblock 152 202 537 minecraft:light[level=12]
setblock 152 202 545 minecraft:light[level=12]
fill 156 202 510 156 213 510 minecraft:crying_obsidian
setblock 160 202 513 minecraft:light[level=12]
setblock 160 202 521 minecraft:light[level=12]
setblock 160 202 529 minecraft:light[level=12]
setblock 160 202 537 minecraft:light[level=12]
setblock 160 202 545 minecraft:light[level=12]
setblock 168 202 513 minecraft:light[level=12]
setblock 168 202 521 minecraft:light[level=12]
setblock 168 202 529 minecraft:light[level=12]
setblock 168 202 537 minecraft:light[level=12]
setblock 168 202 545 minecraft:light[level=12]
setblock 172 202 552 minecraft:amethyst_block
fill 175 202 510 175 213 510 minecraft:crying_obsidian
setblock 176 202 513 minecraft:light[level=12]
setblock 176 202 521 minecraft:light[level=12]
setblock 176 202 529 minecraft:light[level=12]
setblock 176 202 537 minecraft:light[level=12]
setblock 176 202 545 minecraft:light[level=12]
setblock 183 202 528 minecraft:amethyst_block
setblock 183 202 550 minecraft:amethyst_block
fill 142 203 510 142 209 510 minecraft:crying_obsidian
fill 172 203 552 172 213 552 minecraft:crying_obsidian
setblock 181 203 510 minecraft:amethyst_block
fill 183 203 528 183 210 528 minecraft:crying_obsidian
fill 183 203 550 183 209 550 minecraft:crying_obsidian
fill 153 204 537 154 205 538 minecraft:crying_obsidian
setblock 173 204 510 minecraft:amethyst_block
fill 181 204 510 181 213 510 minecraft:crying_obsidian
setblock 183 204 515 minecraft:amethyst_block
setblock 183 204 519 minecraft:white_concrete
fill 173 205 510 173 213 510 minecraft:crying_obsidian
setblock 173 205 552 minecraft:white_concrete
fill 183 205 515 183 211 515 minecraft:crying_obsidian
fill 183 205 519 183 214 519 minecraft:crying_obsidian
fill 156 206 552 156 214 552 minecraft:crying_obsidian
setblock 157 206 552 minecraft:amethyst_block
fill 173 206 552 173 213 552 minecraft:crying_obsidian
setblock 183 206 540 minecraft:amethyst_block
fill 141 207 518 141 209 518 minecraft:purple_stained_glass
fill 141 207 534 141 209 534 minecraft:purple_stained_glass
fill 141 207 550 141 209 550 minecraft:purple_stained_glass
fill 145 207 510 145 209 510 minecraft:purple_stained_glass
fill 155 207 552 155 209 552 minecraft:purple_stained_glass
fill 157 207 552 157 209 552 minecraft:crying_obsidian
fill 161 207 510 161 209 510 minecraft:purple_stained_glass
fill 171 207 552 171 209 552 minecraft:purple_stained_glass
fill 176 207 510 176 213 510 minecraft:crying_obsidian
fill 177 207 510 177 209 510 minecraft:purple_stained_glass
fill 183 207 520 183 209 520 minecraft:purple_stained_glass
fill 183 207 536 183 209 536 minecraft:purple_stained_glass
fill 183 207 540 183 215 540 minecraft:crying_obsidian
setblock 183 207 547 minecraft:white_concrete
fill 153 208 552 153 209 552 minecraft:crying_obsidian
setblock 154 208 552 minecraft:white_concrete
setblock 174 208 552 minecraft:white_concrete
setblock 183 208 523 minecraft:amethyst_block
setblock 183 208 544 minecraft:white_concrete
fill 183 208 547 183 209 547 minecraft:crying_obsidian
setblock 141 209 511 minecraft:white_concrete
fill 154 209 552 154 213 552 minecraft:crying_obsidian
fill 174 209 552 174 213 552 minecraft:crying_obsidian
fill 183 209 523 183 213 523 minecraft:crying_obsidian
fill 183 209 544 183 214 544 minecraft:crying_obsidian
fill 141 210 511 141 214 511 minecraft:crying_obsidian
fill 141 210 518 141 213 518 minecraft:crying_obsidian
setblock 141 210 519 minecraft:obsidian
fill 141 210 529 141 210 530 minecraft:obsidian
setblock 141 210 533 minecraft:obsidian
fill 141 210 534 141 213 534 minecraft:crying_obsidian
fill 141 210 547 141 213 547 minecraft:crying_obsidian
setblock 141 210 548 minecraft:obsidian
setblock 141 210 550 minecraft:obsidian
setblock 142 210 510 minecraft:obsidian
setblock 144 210 513 minecraft:light[level=12]
setblock 144 210 521 minecraft:light[level=12]
setblock 144 210 529 minecraft:light[level=12]
setblock 144 210 537 minecraft:light[level=12]
setblock 144 210 545 minecraft:light[level=12]
fill 145 210 510 145 213 510 minecraft:crying_obsidian
setblock 146 210 510 minecraft:obsidian
setblock 152 210 513 minecraft:light[level=12]
setblock 152 210 521 minecraft:light[level=12]
setblock 152 210 529 minecraft:light[level=12]
setblock 152 210 537 minecraft:light[level=12]
setblock 152 210 545 minecraft:light[level=12]
setblock 153 210 552 minecraft:obsidian
setblock 155 210 510 minecraft:obsidian
fill 155 210 552 155 213 552 minecraft:crying_obsidian
setblock 157 210 510 minecraft:obsidian
setblock 157 210 552 minecraft:obsidian
fill 158 210 510 158 213 510 minecraft:crying_obsidian
setblock 159 210 510 minecraft:obsidian
setblock 159 210 552 minecraft:white_concrete
fill 160 210 510 161 213 510 minecraft:crying_obsidian
setblock 160 210 513 minecraft:light[level=12]
setblock 160 210 521 minecraft:light[level=12]
setblock 160 210 529 minecraft:light[level=12]
setblock 160 210 537 minecraft:light[level=12]
setblock 160 210 545 minecraft:light[level=12]
setblock 163 210 552 minecraft:obsidian
setblock 168 210 513 minecraft:light[level=12]
setblock 168 210 521 minecraft:light[level=12]
setblock 168 210 529 minecraft:light[level=12]
setblock 168 210 537 minecraft:light[level=12]
setblock 168 210 545 minecraft:light[level=12]
fill 171 210 552 171 213 552 minecraft:crying_obsidian
setblock 176 210 513 minecraft:light[level=12]
setblock 176 210 521 minecraft:light[level=12]
setblock 176 210 529 minecraft:light[level=12]
setblock 176 210 537 minecraft:light[level=12]
setblock 176 210 545 minecraft:light[level=12]
fill 177 210 510 177 213 510 minecraft:crying_obsidian
fill 183 210 520 183 213 520 minecraft:crying_obsidian
setblock 183 210 522 minecraft:obsidian
setblock 183 210 531 minecraft:obsidian
fill 183 210 536 183 213 536 minecraft:crying_obsidian
setblock 183 210 547 minecraft:amethyst_block
setblock 183 210 550 minecraft:white_concrete
setblock 141 211 510 minecraft:obsidian
fill 141 211 519 141 213 519 minecraft:crying_obsidian
setblock 141 211 523 minecraft:obsidian
fill 141 211 529 141 211 530 minecraft:crying_obsidian
setblock 141 211 531 minecraft:obsidian
fill 141 211 533 141 213 533 minecraft:crying_obsidian
setblock 141 211 536 minecraft:obsidian
setblock 141 211 539 minecraft:obsidian
fill 141 211 548 141 213 548 minecraft:crying_obsidian
fill 141 211 550 141 213 550 minecraft:crying_obsidian
setblock 142 211 510 minecraft:crying_obsidian
setblock 146 211 510 minecraft:crying_obsidian
setblock 149 211 552 minecraft:obsidian
fill 150 211 542 150 212 542 minecraft:amethyst_block
fill 153 211 552 153 214 552 minecraft:crying_obsidian
fill 155 211 510 155 214 510 minecraft:crying_obsidian
fill 157 211 510 157 214 510 minecraft:crying_obsidian
setblock 157 211 552 minecraft:crying_obsidian
setblock 159 211 510 minecraft:amethyst_block
fill 159 211 552 159 213 552 minecraft:crying_obsidian
fill 163 211 552 163 213 552 minecraft:crying_obsidian
setblock 169 211 552 minecraft:amethyst_block
fill 174 211 510 174 212 510 minecraft:obsidian
setblock 175 211 552 minecraft:obsidian
setblock 183 211 522 minecraft:white_concrete
setblock 183 211 525 minecraft:obsidian
setblock 183 211 528 minecraft:obsidian
fill 183 211 529 183 213 529 minecraft:crying_obsidian
setblock 183 211 530 minecraft:obsidian
fill 183 211 531 183 213 531 minecraft:crying_obsidian
setblock 183 211 534 minecraft:obsidian
setblock 183 211 541 minecraft:obsidian
setblock 183 211 546 minecraft:obsidian
fill 183 211 547 183 213 547 minecraft:crying_obsidian
fill 183 211 550 183 213 550 minecraft:crying_obsidian
fill 141 212 510 141 213 510 minecraft:crying_obsidian
setblock 141 212 520 minecraft:obsidian
fill 141 212 523 141 213 523 minecraft:crying_obsidian
setblock 141 212 529 minecraft:amethyst_block
fill 141 212 530 141 213 531 minecraft:crying_obsidian
fill 141 212 536 141 213 536 minecraft:crying_obsidian
fill 141 212 539 141 213 539 minecraft:crying_obsidian
setblock 142 212 510 minecraft:obsidian
setblock 146 212 510 minecraft:obsidian
setblock 147 212 552 minecraft:obsidian
fill 149 212 552 149 213 552 minecraft:crying_obsidian
setblock 151 212 552 minecraft:obsidian
setblock 157 212 552 minecraft:obsidian
fill 159 212 510 159 213 510 minecraft:crying_obsidian
setblock 163 212 510 minecraft:obsidian
fill 169 212 552 169 213 552 minecraft:crying_obsidian
setblock 172 212 510 minecraft:obsidian
fill 175 212 552 175 213 552 minecraft:crying_obsidian
fill 182 212 510 182 213 510 minecraft:crying_obsidian
setblock 183 212 510 minecraft:obsidian
setblock 183 212 515 minecraft:obsidian
fill 183 212 522 183 213 522 minecraft:crying_obsidian
fill 183 212 525 183 213 525 minecraft:crying_obsidian
fill 183 212 528 183 214 528 minecraft:crying_obsidian
fill 183 212 530 183 213 530 minecraft:crying_obsidian
fill 183 212 534 183 213 534 minecraft:crying_obsidian
fill 183 212 541 183 213 541 minecraft:crying_obsidian
fill 183 212 546 183 213 546 minecraft:crying_obsidian
setblock 183 212 548 minecraft:obsidian
setblock 183 212 551 minecraft:obsidian
setblock 141 213 520 minecraft:crying_obsidian
setblock 141 213 529 minecraft:crying_obsidian
setblock 142 213 510 minecraft:crying_obsidian
setblock 146 213 510 minecraft:crying_obsidian
setblock 147 213 552 minecraft:crying_obsidian
fill 150 213 542 150 222 542 minecraft:obsidian
setblock 151 213 552 minecraft:crying_obsidian
setblock 157 213 552 minecraft:crying_obsidian
setblock 163 213 510 minecraft:crying_obsidian
fill 168 213 518 169 214 518 minecraft:crying_obsidian
fill 172 213 510 172 214 510 minecraft:crying_obsidian
setblock 174 213 510 minecraft:crying_obsidian
fill 176 213 527 176 214 527 minecraft:amethyst_block
setblock 180 213 552 minecraft:white_concrete
setblock 183 213 510 minecraft:crying_obsidian
setblock 183 213 515 minecraft:crying_obsidian
setblock 183 213 548 minecraft:crying_obsidian
setblock 183 213 551 minecraft:crying_obsidian
fill 141 214 510 154 214 510 minecraft:obsidian
fill 141 214 512 141 273 512 minecraft:obsidian
setblock 141 214 513 minecraft:amethyst_block
fill 141 214 514 141 215 516 minecraft:obsidian
fill 141 214 518 141 214 526 minecraft:obsidian
fill 141 214 529 141 214 541 minecraft:obsidian
setblock 141 214 542 minecraft:crying_obsidian
fill 141 214 543 141 215 544 minecraft:obsidian
fill 141 214 546 141 214 551 minecraft:obsidian
fill 142 214 552 149 215 552 minecraft:obsidian
setblock 150 214 552 minecraft:white_concrete
fill 151 214 552 152 238 552 minecraft:obsidian
fill 154 214 552 155 215 552 minecraft:obsidian
setblock 156 214 510 minecraft:obsidian
fill 157 214 552 161 215 552 minecraft:obsidian
fill 158 214 510 171 214 510 minecraft:obsidian
fill 163 214 552 182 214 552 minecraft:obsidian
fill 166 214 520 167 215 521 minecraft:obsidian
fill 173 214 510 183 214 510 minecraft:obsidian
fill 183 214 511 183 228 513 minecraft:obsidian
fill 183 214 515 183 215 518 minecraft:obsidian
fill 183 214 520 183 215 527 minecraft:obsidian
fill 183 214 529 183 215 536 minecraft:obsidian
fill 183 214 538 183 238 539 minecraft:obsidian
fill 183 214 541 183 215 541 minecraft:obsidian
fill 183 214 543 183 231 543 minecraft:obsidian
fill 183 214 545 183 214 548 minecraft:obsidian
setblock 183 214 549 minecraft:amethyst_block
fill 183 214 550 183 216 551 minecraft:obsidian
fill 141 215 510 141 244 511 minecraft:obsidian
setblock 141 215 513 minecraft:obsidian
fill 141 215 517 141 215 520 minecraft:obsidian
setblock 141 215 521 minecraft:crying_obsidian
fill 141 215 522 141 215 524 minecraft:obsidian
setblock 141 215 525 minecraft:crying_obsidian
fill 141 215 526 141 215 538 minecraft:obsidian
setblock 141 215 539 minecraft:crying_obsidian
fill 141 215 540 141 215 542 minecraft:obsidian
fill 141 215 545 141 215 548 minecraft:obsidian
fill 141 215 549 141 215 551 minecraft:crying_obsidian
fill 141 215 552 141 307 552 minecraft:obsidian
fill 142 215 510 151 215 510 minecraft:obsidian
fill 149 215 542 149 222 542 minecraft:obsidian
fill 150 215 541 150 222 541 minecraft:obsidian
fill 150 215 543 150 222 543 minecraft:obsidian
fill 150 215 552 150 286 552 minecraft:obsidian
fill 151 215 542 151 222 542 minecraft:obsidian
setblock 152 215 510 minecraft:crying_obsidian
fill 153 215 510 155 215 510 minecraft:obsidian
setblock 153 215 552 minecraft:obsidian
setblock 156 215 510 minecraft:crying_obsidian
fill 156 215 552 156 243 552 minecraft:obsidian
fill 157 215 510 157 258 510 minecraft:obsidian
setblock 158 215 510 minecraft:crying_obsidian
fill 159 215 510 165 215 510 minecraft:obsidian
fill 162 215 552 168 215 552 minecraft:obsidian
setblock 166 215 510 minecraft:crying_obsidian
fill 167 215 510 173 215 510 minecraft:obsidian
setblock 169 215 552 minecraft:crying_obsidian
fill 170 215 552 176 215 552 minecraft:obsidian
setblock 174 215 510 minecraft:crying_obsidian
fill 175 215 510 175 307 510 minecraft:obsidian
fill 176 215 510 176 216 510 minecraft:crying_obsidian
fill 176 215 527 176 224 527 minecraft:obsidian
fill 177 215 510 180 215 510 minecraft:obsidian
fill 177 215 552 178 215 552 minecraft:crying_obsidian
fill 179 215 552 183 215 552 minecraft:obsidian
fill 181 215 510 182 215 510 minecraft:crying_obsidian
setblock 183 215 510 minecraft:obsidian
fill 183 215 514 183 234 514 minecraft:obsidian
fill 183 215 519 183 223 519 minecraft:obsidian
fill 183 215 528 183 243 528 minecraft:obsidian
fill 183 215 537 183 307 537 minecraft:obsidian
fill 183 215 542 183 280 542 minecraft:obsidian
setblock 183 215 544 minecraft:obsidian
fill 183 215 545 183 216 545 minecraft:crying_obsidian
fill 183 215 546 183 231 548 minecraft:obsidian
setblock 183 215 549 minecraft:crying_obsidian
setblock 141 216 513 minecraft:crying_obsidian
fill 141 216 514 141 220 514 minecraft:obsidian
setblock 141 216 515 minecraft:crying_obsidian
fill 141 216 516 141 233 517 minecraft:obsidian
fill 141 216 518 141 218 518 minecraft:purple_stained_glass
setblock 141 216 519 minecraft:crying_obsidian
fill 141 216 520 141 229 523 minecraft:obsidian
setblock 141 216 524 minecraft:crying_obsidian
fill 141 216 525 141 259 528 minecraft:obsidian
setblock 141 216 529 minecraft:crying_obsidian
fill 141 216 530 141 243 533 minecraft:obsidian
fill 141 216 534 141 218 534 minecraft:purple_stained_glass
fill 141 216 535 141 235 540 minecraft:obsidian
setblock 141 216 541 minecraft:crying_obsidian
fill 141 216 542 141 301 542 minecraft:obsidian
setblock 141 216 543 minecraft:crying_obsidian
fill 141 216 544 141 228 545 minecraft:obsidian
setblock 141 216 546 minecraft:crying_obsidian
fill 141 216 547 141 219 549 minecraft:obsidian
fill 141 216 550 141 218 550 minecraft:purple_stained_glass
setblock 141 216 551 minecraft:crying_obsidian
setblock 142 216 510 minecraft:crying_obsidian
setblock 142 216 552 minecraft:crying_obsidian
fill 143 216 510 144 262 510 minecraft:obsidian
fill 143 216 552 148 228 552 minecraft:obsidian
fill 145 216 510 145 218 510 minecraft:purple_stained_glass
fill 146 216 510 152 216 510 minecraft:obsidian
fill 149 216 541 149 222 541 minecraft:obsidian
fill 149 216 543 149 222 543 minecraft:obsidian
setblock 149 216 552 minecraft:crying_obsidian
fill 151 216 541 151 222 541 minecraft:obsidian
fill 151 216 543 151 222 543 minecraft:obsidian
setblock 153 216 510 minecraft:crying_obsidian
setblock 153 216 552 minecraft:crying_obsidian
fill 154 216 510 156 243 510 minecraft:obsidian
fill 154 216 552 154 291 552 minecraft:obsidian
fill 155 216 552 155 218 552 minecraft:purple_stained_glass
setblock 157 216 552 minecraft:crying_obsidian
fill 158 216 510 160 268 510 minecraft:obsidian
fill 158 216 552 162 238 552 minecraft:obsidian
fill 161 216 510 161 218 510 minecraft:purple_stained_glass
fill 162 216 510 164 239 510 minecraft:obsidian
setblock 163 216 552 minecraft:amethyst_block
fill 164 216 552 170 218 552 minecraft:obsidian
setblock 165 216 510 minecraft:crying_obsidian
fill 166 216 510 166 260 510 minecraft:obsidian
setblock 167 216 510 minecraft:crying_obsidian
fill 168 216 510 174 220 510 minecraft:obsidian
fill 171 216 552 171 218 552 minecraft:purple_stained_glass
fill 172 216 552 172 222 552 minecraft:obsidian
setblock 173 216 552 minecraft:crying_obsidian
fill 174 216 552 176 217 552 minecraft:obsidian
fill 177 216 510 177 218 510 minecraft:purple_stained_glass
setblock 177 216 552 minecraft:crying_obsidian
fill 178 216 510 182 228 510 minecraft:obsidian
fill 178 216 552 181 224 552 minecraft:obsidian
setblock 182 216 552 minecraft:crying_obsidian
setblock 183 216 510 minecraft:crying_obsidian
fill 183 216 515 183 307 515 minecraft:obsidian
setblock 183 216 516 minecraft:crying_obsidian
fill 183 216 517 183 222 517 minecraft:obsidian
setblock 183 216 518 minecraft:crying_obsidian
fill 183 216 520 183 218 520 minecraft:purple_stained_glass
fill 183 216 521 183 218 527 minecraft:obsidian
fill 183 216 529 183 217 535 minecraft:obsidian
fill 183 216 536 183 218 536 minecraft:purple_stained_glass
fill 183 216 540 183 255 540 minecraft:obsidian
setblock 183 216 541 minecraft:crying_obsidian
setblock 183 216 544 minecraft:crying_obsidian
setblock 183 216 549 minecraft:obsidian
fill 183 216 552 183 307 552 minecraft:obsidian
fill 141 217 513 141 307 513 minecraft:obsidian
fill 141 217 515 141 297 515 minecraft:obsidian
fill 141 217 519 141 307 519 minecraft:obsidian
fill 141 217 524 141 234 524 minecraft:obsidian
fill 141 217 529 141 228 529 minecraft:obsidian
fill 141 217 541 141 235 541 minecraft:obsidian
fill 141 217 543 141 220 543 minecraft:obsidian
fill 141 217 546 141 305 546 minecraft:obsidian
fill 141 217 551 141 307 551 minecraft:obsidian
fill 142 217 510 142 219 510 minecraft:obsidian
fill 142 217 552 142 280 552 minecraft:obsidian
fill 146 217 510 148 241 510 minecraft:obsidian
fill 148 217 541 148 222 543 minecraft:obsidian
setblock 149 217 510 minecraft:amethyst_block
fill 149 217 540 151 222 540 minecraft:obsidian
fill 149 217 544 151 222 544 minecraft:obsidian
fill 149 217 552 149 307 552 minecraft:obsidian
fill 150 217 510 153 217 510 minecraft:obsidian
fill 152 217 542 152 222 542 minecraft:obsidian
fill 153 217 552 153 276 552 minecraft:obsidian
fill 157 217 552 157 307 552 minecraft:obsidian
fill 163 217 552 163 307 552 minecraft:obsidian
fill 165 217 510 165 263 510 minecraft:obsidian
fill 167 217 510 167 242 510 minecraft:obsidian
fill 173 217 552 173 257 552 minecraft:obsidian
fill 176 217 510 176 307 510 minecraft:obsidian
fill 176 217 526 177 224 526 minecraft:obsidian
fill 177 217 527 177 224 527 minecraft:obsidian
fill 177 217 552 177 222 552 minecraft:obsidian
fill 182 217 552 182 307 552 minecraft:obsidian
fill 183 217 510 183 307 510 minecraft:obsidian
fill 183 217 516 183 255 516 minecraft:obsidian
fill 183 217 518 183 245 518 minecraft:obsidian
fill 183 217 541 183 250 541 minecraft:obsidian
fill 183 217 544 183 237 545 minecraft:obsidian
setblock 183 217 549 minecraft:amethyst_block
fill 183 217 550 183 229 550 minecraft:obsidian
setblock 183 217 551 minecraft:crying_obsidian
setblock 144 218 513 minecraft:light[level=12]
setblock 144 218 521 minecraft:light[level=12]
setblock 144 218 529 minecraft:light[level=12]
setblock 144 218 537 minecraft:light[level=12]
setblock 144 218 545 minecraft:light[level=12]
fill 148 218 540 148 222 540 minecraft:obsidian
fill 148 218 544 148 222 544 minecraft:obsidian
fill 149 218 510 152 220 510 minecraft:obsidian
setblock 152 218 513 minecraft:light[level=12]
setblock 152 218 521 minecraft:light[level=12]
setblock 152 218 529 minecraft:light[level=12]
setblock 152 218 537 minecraft:light[level=12]
fill 152 218 541 152 222 541 minecraft:obsidian
fill 152 218 543 152 222 543 minecraft:obsidian
setblock 152 218 545 minecraft:light[level=12]
setblock 153 218 510 minecraft:amethyst_block
setblock 160 218 513 minecraft:light[level=12]
setblock 160 218 521 minecraft:light[level=12]
setblock 160 218 529 minecraft:light[level=12]
setblock 160 218 537 minecraft:light[level=12]
setblock 160 218 545 minecraft:light[level=12]
setblock 168 218 513 minecraft:light[level=12]
setblock 168 218 521 minecraft:light[level=12]
setblock 168 218 529 minecraft:light[level=12]
setblock 168 218 537 minecraft:light[level=12]
setblock 168 218 545 minecraft:light[level=12]
fill 174 218 552 175 229 552 minecraft:obsidian
fill 175 218 526 175 224 527 minecraft:obsidian
setblock 176 218 513 minecraft:light[level=12]
setblock 176 218 521 minecraft:light[level=12]
fill 176 218 528 177 224 528 minecraft:obsidian
setblock 176 218 529 minecraft:light[level=12]
setblock 176 218 537 minecraft:light[level=12]
setblock 176 218 545 minecraft:light[level=12]
setblock 176 218 552 minecraft:amethyst_block
fill 183 218 529 183 221 530 minecraft:obsidian
setblock 183 218 531 minecraft:white_concrete
fill 183 218 532 183 238 535 minecraft:obsidian
fill 183 218 549 183 307 549 minecraft:obsidian
fill 183 218 551 183 307 551 minecraft:obsidian
fill 141 219 518 141 224 518 minecraft:obsidian
fill 141 219 534 141 224 534 minecraft:obsidian
fill 141 219 550 141 224 550 minecraft:obsidian
fill 145 219 510 145 224 510 minecraft:obsidian
fill 147 219 541 147 222 543 minecraft:obsidian
fill 149 219 539 151 222 539 minecraft:obsidian
fill 149 219 545 151 222 545 minecraft:obsidian
fill 152 219 540 152 222 540 minecraft:obsidian
fill 152 219 544 152 222 544 minecraft:obsidian
fill 153 219 510 153 266 510 minecraft:obsidian
fill 153 219 541 153 222 543 minecraft:obsidian
fill 155 219 552 155 224 552 minecraft:obsidian
fill 161 219 510 161 224 510 minecraft:obsidian
setblock 164 219 552 minecraft:amethyst_block
fill 165 219 552 171 219 552 minecraft:obsidian
fill 175 219 528 175 224 528 minecraft:obsidian
fill 176 219 525 177 224 525 minecraft:obsidian
fill 176 219 552 176 252 552 minecraft:obsidian
fill 177 219 510 177 224 510 minecraft:obsidian
fill 178 219 526 178 224 528 minecraft:obsidian
fill 183 219 520 183 224 520 minecraft:obsidian
setblock 183 219 521 minecraft:amethyst_block
fill 183 219 522 183 230 527 minecraft:obsidian
fill 183 219 531 183 226 531 minecraft:obsidian
fill 183 219 536 183 220 536 minecraft:obsidian
fill 141 220 547 141 230 547 minecraft:obsidian
setblock 141 220 548 minecraft:white_concrete
fill 141 220 549 141 230 549 minecraft:obsidian
setblock 142 220 510 minecraft:white_concrete
fill 147 220 540 147 222 540 minecraft:obsidian
fill 147 220 544 147 222 544 minecraft:obsidian
fill 148 220 539 148 222 539 minecraft:obsidian
fill 148 220 545 148 222 545 minecraft:obsidian
fill 152 220 539 152 222 539 minecraft:obsidian
fill 152 220 545 152 222 545 minecraft:obsidian
fill 153 220 540 153 222 540 minecraft:obsidian
fill 153 220 544 153 222 544 minecraft:obsidian
fill 164 220 552 169 221 552 minecraft:obsidian
setblock 170 220 552 minecraft:amethyst_block
fill 171 220 552 171 224 552 minecraft:obsidian
fill 174 220 526 174 224 527 minecraft:obsidian
fill 175 220 525 175 224 525 minecraft:obsidian
fill 176 220 529 177 224 529 minecraft:obsidian
fill 178 220 525 178 224 525 minecraft:obsidian
fill 183 220 521 183 282 521 minecraft:obsidian
fill 141 221 514 141 222 514 minecraft:amethyst_block
setblock 141 221 543 minecraft:white_concrete
fill 141 221 548 141 307 548 minecraft:obsidian
fill 142 221 510 142 245 510 minecraft:obsidian
fill 146 221 541 146 222 543 minecraft:obsidian
fill 147 221 539 147 222 539 minecraft:obsidian
fill 147 221 545 147 222 545 minecraft:obsidian
setblock 149 221 510 minecraft:crying_obsidian
fill 149 221 538 151 222 538 minecraft:obsidian
fill 149 221 546 151 222 546 minecraft:obsidian
fill 150 221 510 152 256 510 minecraft:obsidian
fill 154 221 541 154 222 543 minecraft:obsidian
fill 168 221 510 172 221 510 minecraft:obsidian
fill 170 221 552 170 230 552 minecraft:obsidian
setblock 173 221 510 minecraft:crying_obsidian
fill 174 221 510 174 270 510 minecraft:obsidian
fill 174 221 525 174 224 525 minecraft:obsidian
fill 174 221 528 174 224 528 minecraft:obsidian
fill 175 221 524 177 224 524 minecraft:obsidian
fill 175 221 529 175 224 529 minecraft:obsidian
fill 178 221 529 178 224 529 minecraft:obsidian
fill 179 221 526 179 224 528 minecraft:obsidian
setblock 183 221 536 minecraft:crying_obsidian
fill 141 222 543 141 280 543 minecraft:obsidian
setblock 146 222 540 minecraft:obsidian
setblock 146 222 544 minecraft:obsidian
setblock 148 222 538 minecraft:obsidian
setblock 148 222 546 minecraft:obsidian
fill 149 222 510 149 282 510 minecraft:obsidian
setblock 152 222 538 minecraft:obsidian
setblock 152 222 546 minecraft:obsidian
setblock 153 222 539 minecraft:obsidian
setblock 153 222 545 minecraft:obsidian
setblock 154 222 540 minecraft:obsidian
setblock 154 222 544 minecraft:obsidian
fill 164 222 552 164 291 552 minecraft:obsidian
setblock 165 222 552 minecraft:amethyst_block
fill 166 222 552 169 222 552 minecraft:obsidian
fill 168 222 510 170 239 510 minecraft:obsidian
setblock 171 222 510 minecraft:white_concrete
fill 172 222 510 173 297 510 minecraft:obsidian
fill 173 222 526 173 224 528 minecraft:obsidian
fill 174 222 529 174 224 529 minecraft:obsidian
fill 175 222 530 177 224 530 minecraft:obsidian
fill 178 222 524 178 224 524 minecraft:obsidian
fill 179 222 525 179 224 525 minecraft:obsidian
fill 179 222 529 179 224 529 minecraft:obsidian
setblock 183 222 529 minecraft:white_concrete
fill 183 222 530 183 274 530 minecraft:obsidian
fill 183 222 536 183 224 536 minecraft:obsidian
setblock 141 223 514 minecraft:obsidian
fill 149 223 542 151 223 542 minecraft:amethyst_block
fill 150 223 541 150 224 541 minecraft:amethyst_block
fill 150 223 543 150 224 543 minecraft:amethyst_block
fill 165 223 552 167 224 552 minecraft:obsidian
setblock 168 223 552 minecraft:crying_obsidian
fill 169 223 552 169 264 552 minecraft:obsidian
fill 171 223 510 171 244 510 minecraft:obsidian
setblock 172 223 552 minecraft:white_concrete
fill 173 223 525 173 224 525 minecraft:obsidian
fill 173 223 529 173 224 529 minecraft:obsidian
fill 174 223 524 174 224 524 minecraft:obsidian
fill 174 223 530 174 224 530 minecraft:obsidian
fill 175 223 523 177 224 523 minecraft:obsidian
setblock 177 223 552 minecraft:crying_obsidian
fill 178 223 530 178 224 530 minecraft:obsidian
fill 179 223 524 179 224 524 minecraft:obsidian
fill 180 223 526 180 224 528 minecraft:obsidian
setblock 183 223 517 minecraft:amethyst_block
setblock 183 223 529 minecraft:obsidian
setblock 141 224 514 minecraft:crying_obsidian
fill 149 224 542 150 224 542 minecraft:amethyst_block
fill 168 224 552 168 232 552 minecraft:obsidian
fill 172 224 526 172 224 528 minecraft:obsidian
fill 172 224 552 172 230 552 minecraft:obsidian
setblock 173 224 524 minecraft:obsidian
setblock 174 224 523 minecraft:obsidian
fill 175 224 531 177 224 531 minecraft:obsidian
fill 177 224 552 177 303 552 minecraft:obsidian
setblock 178 224 523 minecraft:obsidian
setblock 179 224 530 minecraft:obsidian
setblock 180 224 525 minecraft:obsidian
setblock 180 224 529 minecraft:obsidian
fill 183 224 517 183 249 517 minecraft:obsidian
setblock 183 224 519 minecraft:crying_obsidian
setblock 183 224 529 minecraft:amethyst_block
fill 141 225 514 141 307 514 minecraft:obsidian
fill 141 225 518 141 227 518 minecraft:purple_stained_glass
fill 141 225 534 141 227 534 minecraft:purple_stained_glass
fill 141 225 550 141 227 550 minecraft:purple_stained_glass
fill 145 225 510 145 227 510 minecraft:purple_stained_glass
fill 150 225 542 150 227 542 minecraft:amethyst_block
fill 155 225 552 155 227 552 minecraft:purple_stained_glass
fill 161 225 510 161 227 510 minecraft:purple_stained_glass
fill 165 225 552 165 293 552 minecraft:obsidian
setblock 166 225 552 minecraft:white_concrete
fill 167 225 552 167 239 552 minecraft:obsidian
fill 171 225 552 171 227 552 minecraft:purple_stained_glass
fill 176 225 526 176 225 528 minecraft:amethyst_block
fill 177 225 510 177 227 510 minecraft:purple_stained_glass
fill 177 225 526 177 226 527 minecraft:amethyst_block
fill 178 225 552 180 257 552 minecraft:obsidian
setblock 181 225 552 minecraft:amethyst_block
fill 183 225 519 183 276 519 minecraft:obsidian
fill 183 225 520 183 227 520 minecraft:purple_stained_glass
fill 183 225 529 183 241 529 minecraft:obsidian
fill 183 225 536 183 227 536 minecraft:purple_stained_glass
setblock 144 226 513 minecraft:light[level=12]
setblock 144 226 521 minecraft:light[level=12]
setblock 144 226 529 minecraft:light[level=12]
setblock 144 226 537 minecraft:light[level=12]
setblock 144 226 545 minecraft:light[level=12]
setblock 152 226 513 minecraft:light[level=12]
setblock 152 226 521 minecraft:light[level=12]
setblock 152 226 529 minecraft:light[level=12]
setblock 152 226 537 minecraft:light[level=12]
setblock 152 226 545 minecraft:light[level=12]
setblock 160 226 513 minecraft:light[level=12]
setblock 160 226 521 minecraft:light[level=12]
setblock 160 226 529 minecraft:light[level=12]
setblock 160 226 537 minecraft:light[level=12]
setblock 160 226 545 minecraft:light[level=12]
fill 166 226 552 166 307 552 minecraft:obsidian
setblock 168 226 513 minecraft:light[level=12]
setblock 168 226 521 minecraft:light[level=12]
setblock 168 226 529 minecraft:light[level=12]
setblock 168 226 537 minecraft:light[level=12]
setblock 168 226 545 minecraft:light[level=12]
setblock 176 226 513 minecraft:light[level=12]
setblock 176 226 521 minecraft:light[level=12]
fill 176 226 526 176 226 527 minecraft:amethyst_block
setblock 176 226 529 minecraft:light[level=12]
setblock 176 226 537 minecraft:light[level=12]
setblock 176 226 545 minecraft:light[level=12]
fill 181 226 552 181 231 552 minecraft:obsidian
fill 176 227 527 177 227 527 minecraft:amethyst_block
setblock 183 227 531 minecraft:white_concrete
fill 141 228 518 141 242 518 minecraft:obsidian
fill 141 228 534 141 242 534 minecraft:obsidian
fill 141 228 550 141 233 550 minecraft:obsidian
fill 145 228 510 145 242 510 minecraft:obsidian
fill 155 228 552 155 242 552 minecraft:obsidian
fill 161 228 510 161 242 510 minecraft:obsidian
fill 171 228 552 171 237 552 minecraft:obsidian
setblock 176 228 527 minecraft:amethyst_block
fill 177 228 510 177 242 510 minecraft:obsidian
fill 183 228 520 183 242 520 minecraft:obsidian
fill 183 228 531 183 296 531 minecraft:obsidian
fill 183 228 536 183 242 536 minecraft:obsidian
setblock 141 229 529 minecraft:crying_obsidian
setblock 141 229 544 minecraft:crying_obsidian
fill 141 229 545 141 307 545 minecraft:obsidian
setblock 143 229 552 minecraft:white_concrete
fill 144 229 552 148 230 552 minecraft:obsidian
fill 178 229 510 181 233 510 minecraft:obsidian
setblock 182 229 510 minecraft:crying_obsidian
fill 183 229 511 183 262 512 minecraft:obsidian
setblock 183 229 513 minecraft:crying_obsidian
fill 141 230 520 141 273 520 minecraft:obsidian
setblock 141 230 521 minecraft:amethyst_block
fill 141 230 522 141 230 523 minecraft:obsidian
fill 141 230 529 141 245 529 minecraft:obsidian
fill 141 230 544 141 290 544 minecraft:obsidian
fill 143 230 552 143 267 552 minecraft:obsidian
fill 174 230 552 174 258 552 minecraft:obsidian
setblock 175 230 552 minecraft:amethyst_block
fill 182 230 510 182 307 510 minecraft:obsidian
fill 183 230 513 183 273 513 minecraft:obsidian
setblock 183 230 550 minecraft:white_concrete
fill 141 231 521 141 237 522 minecraft:obsidian
setblock 141 231 523 minecraft:white_concrete
setblock 141 231 547 minecraft:crying_obsidian
setblock 141 231 549 minecraft:white_concrete
fill 144 231 552 144 307 552 minecraft:obsidian
setblock 145 231 552 minecraft:crying_obsidian
fill 146 231 552 148 234 552 minecraft:obsidian
setblock 170 231 552 minecraft:crying_obsidian
setblock 172 231 552 minecraft:crying_obsidian
fill 175 231 552 175 235 552 minecraft:obsidian
fill 183 231 522 183 239 525 minecraft:obsidian
setblock 183 231 526 minecraft:crying_obsidian
fill 183 231 527 183 273 527 minecraft:obsidian
fill 183 231 550 183 268 550 minecraft:obsidian
fill 141 232 523 141 266 523 minecraft:obsidian
fill 141 232 547 141 234 547 minecraft:obsidian
fill 141 232 549 141 287 549 minecraft:obsidian
fill 145 232 552 145 268 552 minecraft:obsidian
fill 170 232 552 170 307 552 minecraft:obsidian
fill 172 232 552 172 280 552 minecraft:obsidian
setblock 181 232 552 minecraft:white_concrete
fill 183 232 526 183 252 526 minecraft:obsidian
setblock 183 232 543 minecraft:amethyst_block
fill 183 232 546 183 244 546 minecraft:obsidian
setblock 183 232 547 minecraft:crying_obsidian
fill 183 232 548 183 307 548 minecraft:obsidian
setblock 168 233 552 minecraft:amethyst_block
fill 181 233 552 181 235 552 minecraft:obsidian
fill 183 233 543 183 307 543 minecraft:obsidian
fill 183 233 547 183 300 547 minecraft:obsidian
fill 141 234 516 141 241 516 minecraft:obsidian
setblock 141 234 517 minecraft:crying_obsidian
setblock 141 234 550 minecraft:white_concrete
setblock 144 234 513 minecraft:light[level=12]
setblock 144 234 521 minecraft:light[level=12]
setblock 144 234 529 minecraft:light[level=12]
setblock 144 234 537 minecraft:light[level=12]
setblock 144 234 545 minecraft:light[level=12]
setblock 152 234 513 minecraft:light[level=12]
setblock 152 234 521 minecraft:light[level=12]
setblock 152 234 529 minecraft:light[level=12]
setblock 152 234 537 minecraft:light[level=12]
setblock 152 234 545 minecraft:light[level=12]
setblock 160 234 513 minecraft:light[level=12]
setblock 160 234 521 minecraft:light[level=12]
setblock 160 234 529 minecraft:light[level=12]
setblock 160 234 537 minecraft:light[level=12]
setblock 160 234 545 minecraft:light[level=12]
setblock 168 234 513 minecraft:light[level=12]
setblock 168 234 521 minecraft:light[level=12]
setblock 168 234 529 minecraft:light[level=12]
setblock 168 234 537 minecraft:light[level=12]
setblock 168 234 545 minecraft:light[level=12]
fill 168 234 552 168 307 552 minecraft:obsidian
setblock 176 234 513 minecraft:light[level=12]
setblock 176 234 521 minecraft:light[level=12]
setblock 176 234 529 minecraft:light[level=12]
setblock 176 234 537 minecraft:light[level=12]
setblock 176 234 545 minecraft:light[level=12]
fill 178 234 510 179 245 510 minecraft:obsidian
setblock 180 234 510 minecraft:crying_obsidian
fill 181 234 510 181 307 510 minecraft:obsidian
fill 141 235 517 141 285 517 minecraft:obsidian
setblock 141 235 524 minecraft:white_concrete
setblock 141 235 547 minecraft:crying_obsidian
fill 141 235 550 141 242 550 minecraft:obsidian
fill 146 235 552 147 235 552 minecraft:obsidian
setblock 148 235 552 minecraft:amethyst_block
fill 156 235 521 157 235 539 minecraft:crying_obsidian
fill 158 235 521 174 235 522 minecraft:crying_obsidian
fill 158 235 523 162 235 537 minecraft:magenta_stained_glass
fill 158 235 538 174 235 539 minecraft:crying_obsidian
fill 163 235 523 163 235 529 minecraft:magenta_stained_glass
fill 163 235 531 163 235 537 minecraft:magenta_stained_glass
fill 164 235 523 164 235 528 minecraft:magenta_stained_glass
fill 164 235 532 164 235 537 minecraft:magenta_stained_glass
fill 165 235 523 172 235 527 minecraft:magenta_stained_glass
fill 165 235 533 172 235 537 minecraft:magenta_stained_glass
fill 166 235 528 172 235 528 minecraft:magenta_stained_glass
fill 166 235 532 172 235 532 minecraft:magenta_stained_glass
fill 167 235 529 172 235 529 minecraft:magenta_stained_glass
fill 167 235 531 172 235 531 minecraft:magenta_stained_glass
fill 168 235 530 172 235 530 minecraft:magenta_stained_glass
fill 173 235 523 174 235 537 minecraft:crying_obsidian
fill 180 235 510 180 259 510 minecraft:obsidian
setblock 183 235 514 minecraft:crying_obsidian
fill 141 236 524 155 236 524 minecraft:obsidian
fill 141 236 535 155 236 539 minecraft:obsidian
fill 141 236 540 141 236 541 minecraft:white_concrete
fill 141 236 547 182 236 547 minecraft:obsidian
fill 142 236 511 155 236 523 minecraft:obsidian
fill 142 236 525 155 236 534 minecraft:obsidian
fill 142 236 540 182 236 546 minecraft:obsidian
fill 142 236 548 182 236 551 minecraft:obsidian
setblock 146 236 552 minecraft:amethyst_block
fill 147 236 552 148 252 552 minecraft:obsidian
fill 156 236 511 182 236 520 minecraft:obsidian
fill 156 236 521 156 236 522 minecraft:crying_obsidian
setblock 156 236 523 minecraft:amethyst_block
fill 156 236 524 156 236 526 minecraft:crying_obsidian
setblock 156 236 527 minecraft:amethyst_block
fill 156 236 528 156 236 530 minecraft:crying_obsidian
setblock 156 236 531 minecraft:amethyst_block
fill 156 236 532 156 236 534 minecraft:crying_obsidian
setblock 156 236 535 minecraft:amethyst_block
fill 156 236 536 156 236 538 minecraft:crying_obsidian
setblock 156 236 539 minecraft:amethyst_block
fill 157 236 521 157 240 521 minecraft:crying_obsidian
setblock 157 236 522 minecraft:amethyst_block
fill 157 236 523 157 236 525 minecraft:crying_obsidian
setblock 157 236 526 minecraft:amethyst_block
fill 157 236 527 157 236 529 minecraft:crying_obsidian
setblock 157 236 530 minecraft:amethyst_block
fill 157 236 531 157 236 533 minecraft:crying_obsidian
setblock 157 236 534 minecraft:amethyst_block
fill 157 236 535 157 236 537 minecraft:crying_obsidian
setblock 157 236 538 minecraft:amethyst_block
fill 157 236 539 159 236 539 minecraft:crying_obsidian
setblock 158 236 521 minecraft:amethyst_block
fill 158 236 522 160 236 522 minecraft:crying_obsidian
fill 158 236 523 161 236 537 minecraft:magenta_stained_glass
fill 158 236 538 160 236 538 minecraft:crying_obsidian
fill 159 236 521 161 236 521 minecraft:crying_obsidian
setblock 160 236 539 minecraft:amethyst_block
setblock 161 236 522 minecraft:amethyst_block
setblock 161 236 538 minecraft:amethyst_block
fill 161 236 539 163 236 539 minecraft:crying_obsidian
setblock 162 236 521 minecraft:amethyst_block
fill 162 236 522 164 236 522 minecraft:crying_obsidian
fill 162 236 523 162 236 528 minecraft:magenta_stained_glass
fill 162 236 529 162 236 531 minecraft:crying_obsidian
fill 162 236 532 162 236 537 minecraft:magenta_stained_glass
fill 162 236 538 164 236 538 minecraft:crying_obsidian
fill 163 236 521 165 236 521 minecraft:crying_obsidian
fill 163 236 523 163 236 527 minecraft:magenta_stained_glass
fill 163 236 528 163 236 529 minecraft:crying_obsidian
fill 163 236 531 163 236 532 minecraft:crying_obsidian
fill 163 236 533 163 236 537 minecraft:magenta_stained_glass
fill 164 236 523 172 236 526 minecraft:magenta_stained_glass
fill 164 236 527 164 236 528 minecraft:crying_obsidian
fill 164 236 532 164 236 533 minecraft:crying_obsidian
fill 164 236 534 172 236 537 minecraft:magenta_stained_glass
setblock 164 236 539 minecraft:amethyst_block
setblock 165 236 522 minecraft:amethyst_block
fill 165 236 527 166 236 527 minecraft:crying_obsidian
fill 165 236 533 166 236 533 minecraft:crying_obsidian
setblock 165 236 538 minecraft:amethyst_block
fill 165 236 539 167 236 539 minecraft:crying_obsidian
setblock 166 236 521 minecraft:amethyst_block
fill 166 236 522 168 236 522 minecraft:crying_obsidian
fill 166 236 528 167 236 528 minecraft:crying_obsidian
fill 166 236 532 167 236 532 minecraft:crying_obsidian
fill 166 236 538 168 236 538 minecraft:crying_obsidian
fill 167 236 521 169 236 521 minecraft:crying_obsidian
fill 167 236 527 172 236 527 minecraft:magenta_stained_glass
fill 167 236 529 168 236 529 minecraft:crying_obsidian
fill 167 236 531 168 236 531 minecraft:crying_obsidian
fill 167 236 533 172 236 533 minecraft:magenta_stained_glass
fill 168 236 528 172 236 528 minecraft:magenta_stained_glass
setblock 168 236 530 minecraft:crying_obsidian
fill 168 236 532 172 236 532 minecraft:magenta_stained_glass
setblock 168 236 539 minecraft:amethyst_block
setblock 169 236 522 minecraft:amethyst_block
fill 169 236 529 172 236 531 minecraft:magenta_stained_glass
setblock 169 236 538 minecraft:amethyst_block
fill 169 236 539 171 236 539 minecraft:crying_obsidian
setblock 170 236 521 minecraft:amethyst_block
fill 170 236 522 172 236 522 minecraft:crying_obsidian
fill 170 236 538 172 236 538 minecraft:crying_obsidian
fill 171 236 521 173 236 521 minecraft:crying_obsidian
setblock 172 236 539 minecraft:amethyst_block
setblock 173 236 522 minecraft:amethyst_block
fill 173 236 523 173 236 525 minecraft:crying_obsidian
setblock 173 236 526 minecraft:amethyst_block
fill 173 236 527 173 236 529 minecraft:crying_obsidian
setblock 173 236 530 minecraft:amethyst_block
fill 173 236 531 173 236 533 minecraft:crying_obsidian
setblock 173 236 534 minecraft:amethyst_block
fill 173 236 535 173 236 537 minecraft:crying_obsidian
setblock 173 236 538 minecraft:amethyst_block
fill 173 236 539 174 236 539 minecraft:crying_obsidian
setblock 174 236 521 minecraft:amethyst_block
fill 174 236 522 174 236 524 minecraft:crying_obsidian
setblock 174 236 525 minecraft:amethyst_block
fill 174 236 526 174 236 528 minecraft:crying_obsidian
setblock 174 236 529 minecraft:amethyst_block
fill 174 236 530 174 236 532 minecraft:crying_obsidian
setblock 174 236 533 minecraft:amethyst_block
fill 174 236 534 174 236 536 minecraft:crying_obsidian
setblock 174 236 537 minecraft:amethyst_block
fill 174 236 538 174 240 538 minecraft:crying_obsidian
fill 175 236 521 182 236 539 minecraft:obsidian
setblock 175 236 552 minecraft:white_concrete
setblock 181 236 552 minecraft:white_concrete
fill 183 236 514 183 307 514 minecraft:obsidian
fill 141 237 524 141 267 524 minecraft:obsidian
fill 141 237 535 141 240 541 minecraft:obsidian
fill 141 237 547 141 238 547 minecraft:obsidian
fill 146 237 552 146 250 552 minecraft:obsidian
fill 156 237 522 158 240 522 minecraft:crying_obsidian
fill 156 237 538 158 240 538 minecraft:crying_obsidian
fill 157 237 523 157 240 523 minecraft:crying_obsidian
fill 157 237 537 157 240 537 minecraft:crying_obsidian
fill 157 237 539 157 240 539 minecraft:crying_obsidian
fill 172 237 522 174 240 522 minecraft:crying_obsidian
fill 172 237 538 173 240 538 minecraft:crying_obsidian
fill 173 237 521 173 240 521 minecraft:crying_obsidian
fill 173 237 523 173 240 523 minecraft:crying_obsidian
fill 173 237 537 173 240 537 minecraft:crying_obsidian
fill 173 237 539 173 240 539 minecraft:crying_obsidian
fill 175 237 552 175 307 552 minecraft:obsidian
fill 181 237 552 181 307 552 minecraft:obsidian
setblock 141 238 521 minecraft:white_concrete
fill 141 238 522 141 244 522 minecraft:obsidian
setblock 171 238 552 minecraft:white_concrete
fill 183 238 544 183 280 544 minecraft:obsidian
setblock 183 238 545 minecraft:crying_obsidian
fill 141 239 521 141 252 521 minecraft:obsidian
setblock 141 239 547 minecraft:white_concrete
fill 151 239 552 151 253 552 minecraft:obsidian
setblock 152 239 552 minecraft:amethyst_block
fill 158 239 552 160 241 552 minecraft:obsidian
setblock 161 239 552 minecraft:amethyst_block
fill 162 239 552 162 284 552 minecraft:obsidian
fill 171 239 552 171 242 552 minecraft:obsidian
fill 183 239 532 183 272 532 minecraft:obsidian
setblock 183 239 533 minecraft:white_concrete
fill 183 239 534 183 299 535 minecraft:obsidian
fill 183 239 538 183 254 538 minecraft:obsidian
setblock 183 239 539 minecraft:amethyst_block
fill 183 239 545 183 300 545 minecraft:obsidian
setblock 141 240 547 minecraft:obsidian
fill 144 240 529 145 240 533 minecraft:obsidian
fill 145 240 525 145 240 528 minecraft:obsidian
fill 145 240 534 145 240 537 minecraft:obsidian
fill 146 240 523 146 240 525 minecraft:obsidian
fill 146 240 537 146 240 539 minecraft:obsidian
fill 147 240 521 147 240 523 minecraft:obsidian
fill 147 240 539 147 240 541 minecraft:obsidian
fill 148 240 520 148 240 521 minecraft:obsidian
fill 148 240 541 148 240 542 minecraft:obsidian
fill 149 240 519 149 240 520 minecraft:obsidian
fill 149 240 542 149 240 543 minecraft:obsidian
fill 150 240 518 150 240 519 minecraft:obsidian
fill 150 240 543 150 240 544 minecraft:obsidian
fill 151 240 517 151 240 518 minecraft:obsidian
fill 151 240 544 151 240 545 minecraft:obsidian
fill 152 240 516 152 240 517 minecraft:obsidian
fill 152 240 545 152 240 546 minecraft:obsidian
fill 152 240 552 152 250 552 minecraft:obsidian
fill 153 240 516 154 240 516 minecraft:obsidian
fill 153 240 546 154 240 546 minecraft:obsidian
fill 154 240 515 156 240 515 minecraft:obsidian
fill 154 240 547 156 240 547 minecraft:obsidian
fill 156 240 514 168 240 514 minecraft:obsidian
fill 156 240 548 168 240 548 minecraft:obsidian
fill 160 240 513 164 240 513 minecraft:obsidian
fill 160 240 549 164 240 549 minecraft:obsidian
fill 161 240 552 161 278 552 minecraft:obsidian
fill 162 240 510 163 292 510 minecraft:obsidian
setblock 164 240 510 minecraft:amethyst_block
setblock 167 240 552 minecraft:crying_obsidian
setblock 168 240 510 minecraft:amethyst_block
fill 168 240 515 170 240 515 minecraft:obsidian
fill 168 240 547 170 240 547 minecraft:obsidian
fill 169 240 510 170 241 510 minecraft:obsidian
fill 170 240 516 172 240 516 minecraft:obsidian
fill 170 240 546 172 240 546 minecraft:obsidian
fill 172 240 517 173 240 517 minecraft:obsidian
fill 172 240 545 173 240 545 minecraft:obsidian
fill 173 240 518 174 240 518 minecraft:obsidian
fill 173 240 544 174 240 544 minecraft:obsidian
fill 174 240 519 175 240 519 minecraft:obsidian
fill 174 240 543 175 240 543 minecraft:obsidian
fill 175 240 520 176 240 520 minecraft:obsidian
fill 175 240 542 176 240 542 minecraft:obsidian
fill 176 240 521 177 240 521 minecraft:obsidian
fill 176 240 541 177 240 541 minecraft:obsidian
fill 177 240 522 177 240 523 minecraft:obsidian
fill 177 240 539 177 240 540 minecraft:obsidian
fill 178 240 523 178 240 525 minecraft:obsidian
fill 178 240 537 178 240 539 minecraft:obsidian
fill 179 240 525 179 240 537 minecraft:obsidian
fill 180 240 529 180 240 533 minecraft:obsidian
fill 183 240 522 183 257 524 minecraft:obsidian
setblock 183 240 525 minecraft:amethyst_block
setblock 183 240 533 minecraft:crying_obsidian
fill 183 240 539 183 246 539 minecraft:obsidian
fill 141 241 535 141 252 538 minecraft:obsidian
setblock 141 241 539 minecraft:crying_obsidian
fill 141 241 540 141 257 541 minecraft:obsidian
setblock 141 241 547 minecraft:crying_obsidian
setblock 144 241 527 minecraft:crying_obsidian
fill 145 241 524 145 241 526 minecraft:crying_obsidian
fill 146 241 522 146 241 523 minecraft:crying_obsidian
setblock 147 241 521 minecraft:crying_obsidian
fill 148 241 519 148 241 520 minecraft:crying_obsidian
fill 149 241 518 149 241 519 minecraft:crying_obsidian
fill 150 241 517 150 241 518 minecraft:crying_obsidian
setblock 151 241 517 minecraft:crying_obsidian
setblock 152 241 516 minecraft:crying_obsidian
fill 153 241 515 154 241 515 minecraft:crying_obsidian
fill 155 241 514 157 241 514 minecraft:crying_obsidian
fill 158 241 513 166 241 513 minecraft:crying_obsidian
fill 164 241 510 164 248 510 minecraft:obsidian
fill 167 241 514 169 241 514 minecraft:crying_obsidian
fill 167 241 552 167 271 552 minecraft:obsidian
fill 168 241 510 168 280 510 minecraft:obsidian
fill 170 241 515 171 241 515 minecraft:crying_obsidian
setblock 172 241 516 minecraft:crying_obsidian
fill 173 241 517 174 241 517 minecraft:crying_obsidian
fill 174 241 518 175 241 518 minecraft:crying_obsidian
fill 175 241 519 176 241 519 minecraft:crying_obsidian
setblock 176 241 520 minecraft:crying_obsidian
setblock 177 241 521 minecraft:crying_obsidian
fill 178 241 522 178 241 523 minecraft:crying_obsidian
fill 179 241 524 179 241 526 minecraft:crying_obsidian
fill 180 241 527 180 241 531 minecraft:crying_obsidian
fill 183 241 525 183 307 525 minecraft:obsidian
fill 183 241 533 183 264 533 minecraft:obsidian
setblock 141 242 516 minecraft:white_concrete
fill 141 242 539 141 307 539 minecraft:obsidian
fill 141 242 547 141 278 547 minecraft:obsidian
setblock 144 242 513 minecraft:light[level=12]
setblock 144 242 521 minecraft:light[level=12]
setblock 144 242 529 minecraft:light[level=12]
setblock 144 242 537 minecraft:light[level=12]
setblock 144 242 545 minecraft:light[level=12]
fill 146 242 510 147 253 510 minecraft:obsidian
setblock 148 242 510 minecraft:white_concrete
setblock 152 242 513 minecraft:light[level=12]
setblock 152 242 521 minecraft:light[level=12]
setblock 152 242 529 minecraft:light[level=12]
setblock 152 242 537 minecraft:light[level=12]
setblock 152 242 545 minecraft:light[level=12]
fill 158 242 552 158 307 552 minecraft:obsidian
setblock 159 242 552 minecraft:amethyst_block
setblock 160 242 513 minecraft:light[level=12]
setblock 160 242 521 minecraft:light[level=12]
setblock 160 242 529 minecraft:light[level=12]
setblock 160 242 537 minecraft:light[level=12]
setblock 160 242 545 minecraft:light[level=12]
fill 160 242 552 160 248 552 minecraft:obsidian
setblock 168 242 513 minecraft:light[level=12]
setblock 168 242 521 minecraft:light[level=12]
setblock 168 242 529 minecraft:light[level=12]
setblock 168 242 537 minecraft:light[level=12]
setblock 168 242 545 minecraft:light[level=12]
fill 169 242 510 169 272 510 minecraft:obsidian
setblock 170 242 510 minecraft:amethyst_block
setblock 176 242 513 minecraft:light[level=12]
setblock 176 242 521 minecraft:light[level=12]
setblock 176 242 529 minecraft:light[level=12]
setblock 176 242 537 minecraft:light[level=12]
setblock 176 242 545 minecraft:light[level=12]
setblock 183 242 529 minecraft:white_concrete
fill 141 243 516 141 266 516 minecraft:obsidian
fill 141 243 518 141 245 518 minecraft:purple_stained_glass
fill 141 243 534 141 245 534 minecraft:purple_stained_glass
fill 141 243 550 141 245 550 minecraft:purple_stained_glass
fill 145 243 510 145 245 510 minecraft:purple_stained_glass
fill 148 243 510 148 282 510 minecraft:obsidian
fill 155 243 552 155 245 552 minecraft:purple_stained_glass
fill 159 243 552 159 253 552 minecraft:obsidian
fill 161 243 510 161 245 510 minecraft:purple_stained_glass
setblock 167 243 510 minecraft:crying_obsidian
fill 170 243 510 170 265 510 minecraft:obsidian
fill 171 243 552 171 245 552 minecraft:purple_stained_glass
fill 177 243 510 177 245 510 minecraft:purple_stained_glass
fill 183 243 520 183 245 520 minecraft:purple_stained_glass
fill 183 243 529 183 248 529 minecraft:obsidian
fill 183 243 536 183 245 536 minecraft:purple_stained_glass
setblock 141 244 530 minecraft:crying_obsidian
fill 141 244 531 141 246 533 minecraft:obsidian
fill 154 244 510 155 246 510 minecraft:obsidian
setblock 156 244 510 minecraft:amethyst_block
setblock 156 244 552 minecraft:amethyst_block
fill 167 244 510 167 307 510 minecraft:obsidian
setblock 183 244 528 minecraft:amethyst_block
fill 141 245 510 141 307 510 minecraft:obsidian
setblock 141 245 511 minecraft:crying_obsidian
setblock 141 245 522 minecraft:crying_obsidian
fill 141 245 530 141 280 530 minecraft:obsidian
fill 156 245 510 156 265 510 minecraft:obsidian
fill 156 245 552 156 248 552 minecraft:obsidian
fill 167 245 537 167 246 538 minecraft:obsidian
setblock 171 245 510 minecraft:amethyst_block
fill 183 245 528 183 307 528 minecraft:obsidian
setblock 183 245 546 minecraft:white_concrete
fill 141 246 511 141 307 511 minecraft:obsidian
fill 141 246 518 141 251 518 minecraft:obsidian
fill 141 246 522 141 300 522 minecraft:obsidian
setblock 141 246 529 minecraft:amethyst_block
fill 141 246 534 141 251 534 minecraft:obsidian
fill 141 246 550 141 251 550 minecraft:obsidian
setblock 142 246 510 minecraft:amethyst_block
fill 144 246 529 145 247 533 minecraft:obsidian
fill 145 246 510 145 251 510 minecraft:obsidian
fill 145 246 525 145 247 528 minecraft:obsidian
fill 145 246 534 145 247 537 minecraft:obsidian
fill 146 246 523 146 247 525 minecraft:obsidian
fill 146 246 537 146 247 539 minecraft:obsidian
fill 147 246 521 147 247 523 minecraft:obsidian
fill 147 246 539 147 247 541 minecraft:obsidian
fill 148 246 520 148 247 521 minecraft:obsidian
fill 148 246 541 148 247 542 minecraft:obsidian
fill 149 246 519 149 247 520 minecraft:obsidian
fill 149 246 542 149 247 543 minecraft:obsidian
fill 150 246 518 150 247 519 minecraft:obsidian
fill 150 246 543 150 247 544 minecraft:obsidian
fill 151 246 517 151 247 518 minecraft:obsidian
fill 151 246 544 151 247 545 minecraft:obsidian
fill 152 246 516 152 247 517 minecraft:obsidian
fill 152 246 545 152 247 546 minecraft:obsidian
fill 153 246 516 154 247 516 minecraft:obsidian
fill 153 246 546 154 247 546 minecraft:obsidian
fill 154 246 515 156 247 515 minecraft:obsidian
fill 154 246 547 156 247 547 minecraft:obsidian
fill 155 246 552 155 251 552 minecraft:obsidian
fill 156 246 514 168 247 514 minecraft:obsidian
fill 156 246 548 168 247 548 minecraft:obsidian
fill 160 246 513 164 247 513 minecraft:obsidian
fill 160 246 549 164 247 549 minecraft:obsidian
fill 161 246 510 161 251 510 minecraft:obsidian
fill 168 246 515 170 247 515 minecraft:obsidian
fill 168 246 547 170 247 547 minecraft:obsidian
fill 170 246 516 172 247 516 minecraft:obsidian
fill 170 246 546 172 247 546 minecraft:obsidian
fill 171 246 510 171 274 510 minecraft:obsidian
fill 171 246 552 171 247 552 minecraft:obsidian
fill 172 246 517 173 247 517 minecraft:obsidian
fill 172 246 545 173 247 545 minecraft:obsidian
fill 173 246 518 174 247 518 minecraft:obsidian
fill 173 246 544 174 247 544 minecraft:obsidian
fill 174 246 519 175 247 519 minecraft:obsidian
fill 174 246 543 175 247 543 minecraft:obsidian
fill 175 246 520 176 247 520 minecraft:obsidian
fill 175 246 542 176 247 542 minecraft:obsidian
fill 176 246 521 177 247 521 minecraft:obsidian
fill 176 246 541 177 247 541 minecraft:obsidian
fill 177 246 510 178 251 510 minecraft:obsidian
fill 177 246 522 177 247 523 minecraft:obsidian
fill 177 246 539 177 247 540 minecraft:obsidian
fill 178 246 523 178 247 525 minecraft:obsidian
fill 178 246 537 178 247 539 minecraft:obsidian
setblock 179 246 510 minecraft:white_concrete
fill 179 246 525 179 247 537 minecraft:obsidian
fill 180 246 529 180 247 533 minecraft:obsidian
setblock 183 246 518 minecraft:white_concrete
fill 183 246 520 183 251 520 minecraft:obsidian
fill 183 246 536 183 251 536 minecraft:obsidian
fill 183 246 546 183 307 546 minecraft:obsidian
fill 141 247 529 141 254 529 minecraft:obsidian
fill 141 247 531 141 251 532 minecraft:obsidian
setblock 141 247 533 minecraft:amethyst_block
fill 142 247 510 142 258 510 minecraft:obsidian
fill 154 247 510 154 274 510 minecraft:obsidian
setblock 155 247 510 minecraft:white_concrete
fill 166 247 550 168 248 550 minecraft:amethyst_block
fill 167 247 549 167 249 549 minecraft:amethyst_block
fill 167 247 551 167 248 551 minecraft:amethyst_block
fill 179 247 510 179 307 510 minecraft:obsidian
fill 183 247 518 183 306 518 minecraft:obsidian
setblock 183 247 539 minecraft:white_concrete
fill 141 248 533 141 307 533 minecraft:obsidian
fill 155 248 510 155 307 510 minecraft:obsidian
setblock 166 248 548 minecraft:amethyst_block
setblock 166 248 549 minecraft:crying_obsidian
fill 167 248 547 167 249 547 minecraft:amethyst_block
fill 167 248 548 169 248 548 minecraft:crying_obsidian
setblock 168 248 549 minecraft:amethyst_block
fill 170 248 547 171 248 547 minecraft:crying_obsidian
setblock 171 248 552 minecraft:white_concrete
setblock 172 248 546 minecraft:crying_obsidian
fill 173 248 545 174 248 545 minecraft:crying_obsidian
fill 174 248 544 175 248 544 minecraft:crying_obsidian
fill 175 248 543 176 248 543 minecraft:crying_obsidian
setblock 176 248 542 minecraft:crying_obsidian
fill 183 248 539 183 264 539 minecraft:obsidian
setblock 156 249 552 minecraft:amethyst_block
setblock 160 249 552 minecraft:white_concrete
setblock 164 249 510 minecraft:amethyst_block
setblock 167 249 546 minecraft:amethyst_block
setblock 167 249 548 minecraft:amethyst_block
fill 171 249 552 171 251 552 minecraft:obsidian
setblock 183 249 529 minecraft:amethyst_block
setblock 144 250 513 minecraft:light[level=12]
setblock 144 250 521 minecraft:light[level=12]
setblock 144 250 529 minecraft:light[level=12]
setblock 144 250 537 minecraft:light[level=12]
setblock 144 250 545 minecraft:light[level=12]
setblock 152 250 513 minecraft:light[level=12]
setblock 152 250 521 minecraft:light[level=12]
setblock 152 250 529 minecraft:light[level=12]
setblock 152 250 537 minecraft:light[level=12]
setblock 152 250 545 minecraft:light[level=12]
fill 156 250 552 156 307 552 minecraft:obsidian
setblock 160 250 513 minecraft:light[level=12]
setblock 160 250 521 minecraft:light[level=12]
setblock 160 250 529 minecraft:light[level=12]
setblock 160 250 537 minecraft:light[level=12]
setblock 160 250 545 minecraft:light[level=12]
fill 160 250 552 160 307 552 minecraft:obsidian
fill 164 250 510 164 265 510 minecraft:obsidian
setblock 168 250 513 minecraft:light[level=12]
setblock 168 250 521 minecraft:light[level=12]
setblock 168 250 529 minecraft:light[level=12]
setblock 168 250 537 minecraft:light[level=12]
setblock 168 250 545 minecraft:light[level=12]
setblock 176 250 513 minecraft:light[level=12]
setblock 176 250 521 minecraft:light[level=12]
setblock 176 250 529 minecraft:light[level=12]
setblock 176 250 537 minecraft:light[level=12]
setblock 176 250 545 minecraft:light[level=12]
setblock 183 250 517 minecraft:crying_obsidian
fill 183 250 529 183 300 529 minecraft:obsidian
setblock 146 251 552 minecraft:crying_obsidian
setblock 152 251 552 minecraft:amethyst_block
fill 183 251 517 183 261 517 minecraft:obsidian
setblock 183 251 541 minecraft:white_concrete
fill 141 252 518 141 254 518 minecraft:purple_stained_glass
setblock 141 252 531 minecraft:white_concrete
fill 141 252 532 141 265 532 minecraft:obsidian
fill 141 252 534 141 254 534 minecraft:purple_stained_glass
fill 141 252 550 141 254 550 minecraft:purple_stained_glass
fill 145 252 510 145 254 510 minecraft:purple_stained_glass
fill 146 252 552 146 307 552 minecraft:obsidian
fill 152 252 552 152 271 552 minecraft:obsidian
fill 155 252 552 155 254 552 minecraft:purple_stained_glass
fill 161 252 510 161 254 510 minecraft:purple_stained_glass
fill 171 252 552 171 254 552 minecraft:purple_stained_glass
fill 174 252 534 175 253 534 minecraft:crying_obsidian
fill 177 252 510 177 254 510 minecraft:purple_stained_glass
fill 178 252 510 178 287 510 minecraft:obsidian
fill 183 252 520 183 254 520 minecraft:purple_stained_glass
fill 183 252 536 183 254 536 minecraft:purple_stained_glass
fill 183 252 541 183 307 541 minecraft:obsidian
setblock 141 253 521 minecraft:crying_obsidian
fill 141 253 531 141 307 531 minecraft:obsidian
fill 141 253 535 141 262 536 minecraft:obsidian
setblock 141 253 537 minecraft:white_concrete
fill 141 253 538 141 307 538 minecraft:obsidian
fill 147 253 552 147 257 552 minecraft:obsidian
setblock 148 253 552 minecraft:crying_obsidian
setblock 176 253 552 minecraft:amethyst_block
setblock 183 253 526 minecraft:white_concrete
fill 141 254 521 141 299 521 minecraft:obsidian
fill 141 254 537 141 307 537 minecraft:obsidian
fill 142 254 545 145 255 547 minecraft:amethyst_block
setblock 146 254 510 minecraft:amethyst_block
setblock 146 254 546 minecraft:amethyst_block
fill 147 254 510 147 307 510 minecraft:obsidian
fill 148 254 552 148 257 552 minecraft:obsidian
setblock 151 254 552 minecraft:amethyst_block
setblock 159 254 552 minecraft:crying_obsidian
fill 176 254 552 176 258 552 minecraft:obsidian
fill 183 254 526 183 279 526 minecraft:obsidian
fill 141 255 518 141 257 518 minecraft:obsidian
setblock 141 255 529 minecraft:crying_obsidian
fill 141 255 534 141 260 534 minecraft:obsidian
fill 141 255 550 141 260 550 minecraft:obsidian
fill 142 255 544 143 256 544 minecraft:amethyst_block
fill 142 255 548 143 256 548 minecraft:amethyst_block
fill 145 255 510 146 260 510 minecraft:obsidian
fill 151 255 552 151 304 552 minecraft:obsidian
fill 155 255 552 155 260 552 minecraft:obsidian
fill 159 255 552 159 267 552 minecraft:obsidian
fill 161 255 510 161 260 510 minecraft:obsidian
fill 171 255 552 171 260 552 minecraft:obsidian
fill 174 255 538 174 256 538 minecraft:amethyst_block
fill 177 255 510 177 260 510 minecraft:obsidian
fill 183 255 520 183 260 520 minecraft:obsidian
fill 183 255 536 183 260 536 minecraft:obsidian
setblock 183 255 538 minecraft:crying_obsidian
fill 141 256 529 141 275 529 minecraft:obsidian
fill 142 256 545 144 256 547 minecraft:amethyst_block
setblock 183 256 516 minecraft:amethyst_block
fill 183 256 538 183 266 538 minecraft:obsidian
setblock 183 256 540 minecraft:crying_obsidian
fill 142 257 545 143 257 547 minecraft:amethyst_block
setblock 150 257 510 minecraft:amethyst_block
fill 151 257 510 152 276 510 minecraft:obsidian
fill 174 257 538 175 264 538 minecraft:obsidian
fill 183 257 516 183 281 516 minecraft:obsidian
fill 183 257 540 183 307 540 minecraft:obsidian
setblock 141 258 518 minecraft:white_concrete
setblock 141 258 540 minecraft:amethyst_block
fill 141 258 541 141 286 541 minecraft:obsidian
setblock 144 258 513 minecraft:light[level=12]
setblock 144 258 521 minecraft:light[level=12]
setblock 144 258 529 minecraft:light[level=12]
setblock 144 258 537 minecraft:light[level=12]
setblock 144 258 545 minecraft:light[level=12]
fill 147 258 552 148 258 552 minecraft:white_concrete
fill 150 258 510 150 292 510 minecraft:obsidian
setblock 152 258 513 minecraft:light[level=12]
setblock 152 258 521 minecraft:light[level=12]
setblock 152 258 529 minecraft:light[level=12]
setblock 152 258 537 minecraft:light[level=12]
setblock 152 258 545 minecraft:light[level=12]
setblock 160 258 513 minecraft:light[level=12]
setblock 160 258 521 minecraft:light[level=12]
setblock 160 258 529 minecraft:light[level=12]
setblock 160 258 537 minecraft:light[level=12]
setblock 160 258 545 minecraft:light[level=12]
setblock 168 258 513 minecraft:light[level=12]
setblock 168 258 521 minecraft:light[level=12]
setblock 168 258 529 minecraft:light[level=12]
setblock 168 258 537 minecraft:light[level=12]
setblock 168 258 545 minecraft:light[level=12]
setblock 173 258 552 minecraft:crying_obsidian
fill 174 258 539 175 264 539 minecraft:obsidian
setblock 176 258 513 minecraft:light[level=12]
setblock 176 258 521 minecraft:light[level=12]
setblock 176 258 529 minecraft:light[level=12]
setblock 176 258 537 minecraft:light[level=12]
setblock 176 258 545 minecraft:light[level=12]
fill 178 258 552 179 274 552 minecraft:obsidian
setblock 180 258 552 minecraft:white_concrete
setblock 183 258 522 minecraft:crying_obsidian
fill 183 258 523 183 259 524 minecraft:obsidian
fill 141 259 518 141 260 518 minecraft:obsidian
fill 141 259 540 141 278 540 minecraft:obsidian
setblock 142 259 510 minecraft:amethyst_block
fill 147 259 552 147 307 552 minecraft:obsidian
setblock 148 259 552 minecraft:amethyst_block
setblock 157 259 510 minecraft:white_concrete
fill 173 259 538 173 264 538 minecraft:obsidian
setblock 173 259 552 minecraft:obsidian
fill 174 259 537 175 264 537 minecraft:obsidian
setblock 174 259 552 minecraft:amethyst_block
setblock 176 259 552 minecraft:white_concrete
fill 180 259 552 180 263 552 minecraft:obsidian
fill 183 259 522 183 307 522 minecraft:obsidian
fill 141 260 525 141 307 525 minecraft:obsidian
setblock 141 260 526 minecraft:crying_obsidian
fill 141 260 527 141 279 527 minecraft:obsidian
setblock 141 260 528 minecraft:amethyst_block
fill 142 260 510 142 307 510 minecraft:obsidian
fill 148 260 552 148 288 552 minecraft:obsidian
fill 154 260 538 154 261 539 minecraft:obsidian
fill 157 260 510 157 275 510 minecraft:obsidian
fill 173 260 537 173 264 537 minecraft:obsidian
fill 173 260 539 173 264 539 minecraft:obsidian
setblock 173 260 552 minecraft:amethyst_block
fill 174 260 540 175 264 540 minecraft:obsidian
fill 174 260 552 174 285 552 minecraft:obsidian
fill 176 260 537 176 264 539 minecraft:obsidian
fill 176 260 552 176 285 552 minecraft:obsidian
setblock 180 260 510 minecraft:crying_obsidian
setblock 183 260 523 minecraft:white_concrete
fill 183 260 524 183 296 524 minecraft:obsidian
fill 141 261 518 141 263 518 minecraft:purple_stained_glass
fill 141 261 526 141 307 526 minecraft:obsidian
fill 141 261 528 141 285 528 minecraft:obsidian
fill 141 261 534 141 263 534 minecraft:purple_stained_glass
fill 141 261 550 141 263 550 minecraft:purple_stained_glass
fill 145 261 510 145 263 510 minecraft:purple_stained_glass
fill 146 261 510 146 301 510 minecraft:obsidian
fill 155 261 552 155 263 552 minecraft:purple_stained_glass
fill 161 261 510 161 263 510 minecraft:purple_stained_glass
setblock 166 261 510 minecraft:white_concrete
fill 166 261 518 166 262 518 minecraft:crying_obsidian
fill 171 261 552 171 263 552 minecraft:purple_stained_glass
fill 172 261 538 172 264 538 minecraft:obsidian
fill 173 261 540 173 264 540 minecraft:obsidian
fill 173 261 552 173 307 552 minecraft:obsidian
fill 174 261 536 175 264 536 minecraft:obsidian
fill 176 261 540 176 264 540 minecraft:obsidian
fill 177 261 510 177 263 510 minecraft:purple_stained_glass
fill 180 261 510 180 272 510 minecraft:obsidian
fill 183 261 520 183 263 520 minecraft:purple_stained_glass
fill 183 261 523 183 307 523 minecraft:obsidian
fill 183 261 536 183 263 536 minecraft:purple_stained_glass
fill 166 262 510 166 277 510 minecraft:obsidian
fill 172 262 537 172 264 537 minecraft:obsidian
fill 172 262 539 172 264 539 minecraft:obsidian
fill 173 262 536 173 264 536 minecraft:obsidian
fill 174 262 541 175 264 541 minecraft:obsidian
fill 176 262 536 176 264 536 minecraft:obsidian
fill 177 262 537 177 264 539 minecraft:obsidian
setblock 183 262 517 minecraft:amethyst_block
fill 141 263 535 141 278 535 minecraft:obsidian
setblock 141 263 536 minecraft:crying_obsidian
setblock 143 263 510 minecraft:amethyst_block
fill 144 263 510 144 278 510 minecraft:obsidian
fill 172 263 536 172 264 536 minecraft:obsidian
fill 172 263 540 172 264 540 minecraft:obsidian
fill 173 263 541 173 264 541 minecraft:obsidian
fill 174 263 535 175 264 535 minecraft:obsidian
fill 176 263 541 176 264 541 minecraft:obsidian
fill 177 263 536 177 264 536 minecraft:obsidian
fill 177 263 540 177 264 540 minecraft:obsidian
setblock 183 263 511 minecraft:crying_obsidian
fill 183 263 512 183 307 512 minecraft:obsidian
fill 183 263 517 183 275 517 minecraft:obsidian
fill 141 264 518 141 269 518 minecraft:obsidian
fill 141 264 534 141 269 534 minecraft:obsidian
fill 141 264 536 141 307 536 minecraft:obsidian
fill 141 264 550 141 269 550 minecraft:obsidian
fill 143 264 510 143 289 510 minecraft:obsidian
fill 145 264 510 145 269 510 minecraft:obsidian
fill 155 264 552 155 269 552 minecraft:obsidian
fill 161 264 510 161 269 510 minecraft:obsidian
setblock 165 264 510 minecraft:crying_obsidian
fill 171 264 537 171 264 539 minecraft:obsidian
fill 171 264 552 171 269 552 minecraft:obsidian
setblock 172 264 541 minecraft:obsidian
setblock 173 264 535 minecraft:obsidian
setblock 176 264 535 minecraft:obsidian
fill 177 264 510 177 269 510 minecraft:obsidian
setblock 177 264 541 minecraft:obsidian
fill 178 264 537 178 264 539 minecraft:obsidian
setblock 180 264 552 minecraft:white_concrete
fill 183 264 511 183 266 511 minecraft:obsidian
fill 183 264 520 183 269 520 minecraft:obsidian
fill 183 264 536 183 269 536 minecraft:obsidian
fill 165 265 510 165 291 510 minecraft:obsidian
setblock 169 265 552 minecraft:white_concrete
fill 174 265 537 175 265 539 minecraft:amethyst_block
fill 180 265 552 180 307 552 minecraft:obsidian
setblock 183 265 533 minecraft:amethyst_block
setblock 183 265 539 minecraft:white_concrete
setblock 141 266 532 minecraft:white_concrete
setblock 144 266 513 minecraft:light[level=12]
setblock 144 266 521 minecraft:light[level=12]
setblock 144 266 529 minecraft:light[level=12]
setblock 144 266 537 minecraft:light[level=12]
setblock 144 266 545 minecraft:light[level=12]
setblock 152 266 513 minecraft:light[level=12]
setblock 152 266 521 minecraft:light[level=12]
setblock 152 266 529 minecraft:light[level=12]
setblock 152 266 537 minecraft:light[level=12]
setblock 152 266 545 minecraft:light[level=12]
setblock 156 266 510 minecraft:white_concrete
setblock 160 266 513 minecraft:light[level=12]
setblock 160 266 521 minecraft:light[level=12]
setblock 160 266 529 minecraft:light[level=12]
setblock 160 266 537 minecraft:light[level=12]
setblock 160 266 545 minecraft:light[level=12]
setblock 164 266 510 minecraft:amethyst_block
setblock 168 266 513 minecraft:light[level=12]
setblock 168 266 521 minecraft:light[level=12]
setblock 168 266 529 minecraft:light[level=12]
setblock 168 266 537 minecraft:light[level=12]
setblock 168 266 545 minecraft:light[level=12]
fill 169 266 552 169 267 552 minecraft:obsidian
setblock 170 266 510 minecraft:amethyst_block
fill 174 266 538 175 266 539 minecraft:amethyst_block
setblock 176 266 513 minecraft:light[level=12]
setblock 176 266 521 minecraft:light[level=12]
setblock 176 266 529 minecraft:light[level=12]
setblock 176 266 537 minecraft:light[level=12]
setblock 176 266 545 minecraft:light[level=12]
setblock 183 266 533 minecraft:obsidian
fill 183 266 539 183 303 539 minecraft:obsidian
setblock 141 267 516 minecraft:amethyst_block
setblock 141 267 523 minecraft:amethyst_block
fill 141 267 532 141 307 532 minecraft:obsidian
setblock 153 267 510 minecraft:crying_obsidian
fill 156 267 510 156 307 510 minecraft:obsidian
fill 164 267 510 164 307 510 minecraft:obsidian
setblock 170 267 510 minecraft:crying_obsidian
fill 174 267 538 175 267 538 minecraft:amethyst_block
setblock 183 267 511 minecraft:amethyst_block
setblock 183 267 533 minecraft:white_concrete
setblock 183 267 538 minecraft:amethyst_block
fill 141 268 516 141 281 516 minecraft:obsidian
fill 141 268 523 141 277 523 minecraft:obsidian
setblock 141 268 524 minecraft:amethyst_block
setblock 143 268 552 minecraft:amethyst_block
fill 153 268 510 153 307 510 minecraft:obsidian
setblock 159 268 552 minecraft:white_concrete
setblock 169 268 552 minecraft:amethyst_block
fill 170 268 510 170 280 510 minecraft:obsidian
setblock 174 268 538 minecraft:amethyst_block
fill 183 268 511 183 296 511 minecraft:obsidian
fill 183 268 533 183 285 533 minecraft:obsidian
fill 183 268 538 183 277 538 minecraft:obsidian
setblock 141 269 524 minecraft:obsidian
fill 143 269 552 143 307 552 minecraft:obsidian
setblock 145 269 552 minecraft:crying_obsidian
setblock 158 269 510 minecraft:amethyst_block
fill 159 269 510 159 307 510 minecraft:obsidian
fill 159 269 552 159 290 552 minecraft:obsidian
setblock 160 269 510 minecraft:crying_obsidian
fill 169 269 552 169 303 552 minecraft:obsidian
fill 174 269 525 174 270 525 minecraft:crying_obsidian
setblock 183 269 550 minecraft:white_concrete
fill 141 270 518 141 272 518 minecraft:purple_stained_glass
setblock 141 270 524 minecraft:white_concrete
fill 141 270 534 141 272 534 minecraft:purple_stained_glass
fill 141 270 550 141 272 550 minecraft:purple_stained_glass
fill 145 270 510 145 272 510 minecraft:purple_stained_glass
fill 145 270 552 145 307 552 minecraft:obsidian
fill 155 270 552 155 272 552 minecraft:purple_stained_glass
fill 158 270 510 158 291 510 minecraft:obsidian
fill 160 270 510 160 276 510 minecraft:obsidian
fill 161 270 510 161 272 510 minecraft:purple_stained_glass
fill 171 270 552 171 272 552 minecraft:purple_stained_glass
fill 177 270 510 177 272 510 minecraft:purple_stained_glass
fill 183 270 520 183 272 520 minecraft:purple_stained_glass
fill 183 270 536 183 272 536 minecraft:purple_stained_glass
fill 183 270 550 183 307 550 minecraft:obsidian
fill 141 271 524 141 307 524 minecraft:obsidian
setblock 174 271 510 minecraft:white_concrete
setblock 152 272 552 minecraft:white_concrete
setblock 167 272 552 minecraft:amethyst_block
setblock 174 272 510 minecraft:obsidian
fill 141 273 518 141 287 518 minecraft:obsidian
fill 141 273 534 141 287 534 minecraft:obsidian
fill 141 273 550 141 287 550 minecraft:obsidian
fill 145 273 510 145 287 510 minecraft:obsidian
fill 152 273 552 152 307 552 minecraft:obsidian
fill 155 273 552 155 287 552 minecraft:obsidian
fill 161 273 510 161 282 510 minecraft:obsidian
fill 167 273 552 167 292 552 minecraft:obsidian
setblock 169 273 510 minecraft:crying_obsidian
fill 171 273 552 171 287 552 minecraft:obsidian
setblock 174 273 510 minecraft:crying_obsidian
fill 177 273 510 177 287 510 minecraft:obsidian
setblock 180 273 510 minecraft:crying_obsidian
fill 183 273 520 183 287 520 minecraft:obsidian
setblock 183 273 532 minecraft:amethyst_block
fill 183 273 536 183 287 536 minecraft:obsidian
setblock 141 274 512 minecraft:crying_obsidian
setblock 141 274 520 minecraft:amethyst_block
setblock 144 274 513 minecraft:light[level=12]
setblock 144 274 521 minecraft:light[level=12]
setblock 144 274 529 minecraft:light[level=12]
setblock 144 274 537 minecraft:light[level=12]
setblock 144 274 545 minecraft:light[level=12]
setblock 152 274 513 minecraft:light[level=12]
setblock 152 274 521 minecraft:light[level=12]
setblock 152 274 529 minecraft:light[level=12]
setblock 152 274 537 minecraft:light[level=12]
setblock 152 274 545 minecraft:light[level=12]
setblock 160 274 513 minecraft:light[level=12]
setblock 160 274 521 minecraft:light[level=12]
setblock 160 274 529 minecraft:light[level=12]
setblock 160 274 537 minecraft:light[level=12]
setblock 160 274 545 minecraft:light[level=12]
setblock 168 274 513 minecraft:light[level=12]
setblock 168 274 521 minecraft:light[level=12]
setblock 168 274 529 minecraft:light[level=12]
setblock 168 274 537 minecraft:light[level=12]
setblock 168 274 545 minecraft:light[level=12]
fill 169 274 510 169 307 510 minecraft:obsidian
fill 174 274 510 174 307 510 minecraft:obsidian
setblock 176 274 513 minecraft:light[level=12]
setblock 176 274 521 minecraft:light[level=12]
setblock 176 274 529 minecraft:light[level=12]
setblock 176 274 537 minecraft:light[level=12]
setblock 176 274 545 minecraft:light[level=12]
fill 180 274 510 180 298 510 minecraft:obsidian
setblock 183 274 513 minecraft:crying_obsidian
setblock 183 274 527 minecraft:amethyst_block
fill 183 274 532 183 307 532 minecraft:obsidian
fill 141 275 512 141 307 512 minecraft:obsidian
fill 141 275 520 141 307 520 minecraft:obsidian
setblock 154 275 510 minecraft:crying_obsidian
setblock 171 275 510 minecraft:crying_obsidian
fill 178 275 552 178 307 552 minecraft:obsidian
setblock 179 275 552 minecraft:crying_obsidian
fill 183 275 513 183 307 513 minecraft:obsidian
fill 183 275 527 183 291 527 minecraft:obsidian
setblock 183 275 530 minecraft:amethyst_block
setblock 141 276 529 minecraft:white_concrete
fill 154 276 510 154 287 510 minecraft:obsidian
setblock 157 276 510 minecraft:white_concrete
fill 171 276 510 171 307 510 minecraft:obsidian
fill 179 276 552 179 307 552 minecraft:obsidian
setblock 183 276 517 minecraft:white_concrete
fill 183 276 530 183 307 530 minecraft:obsidian
fill 141 277 529 141 302 529 minecraft:obsidian
setblock 151 277 510 minecraft:obsidian
setblock 152 277 510 minecraft:crying_obsidian
fill 153 277 552 153 278 552 minecraft:crying_obsidian
fill 157 277 510 157 307 510 minecraft:obsidian
setblock 160 277 510 minecraft:white_concrete
fill 183 277 517 183 300 517 minecraft:obsidian
setblock 183 277 519 minecraft:amethyst_block
setblock 141 278 523 minecraft:amethyst_block
setblock 151 278 510 minecraft:white_concrete
fill 152 278 510 152 307 510 minecraft:obsidian
fill 160 278 510 160 307 510 minecraft:obsidian
setblock 166 278 510 minecraft:white_concrete
setblock 183 278 519 minecraft:crying_obsidian
setblock 183 278 538 minecraft:amethyst_block
setblock 141 279 523 minecraft:crying_obsidian
setblock 141 279 535 minecraft:amethyst_block
setblock 141 279 540 minecraft:white_concrete
setblock 141 279 547 minecraft:amethyst_block
setblock 144 279 510 minecraft:white_concrete
fill 150 279 515 151 279 541 minecraft:obsidian
fill 151 279 510 151 307 510 minecraft:obsidian
fill 152 279 515 176 279 516 minecraft:obsidian
fill 152 279 517 160 279 539 minecraft:purple_stained_glass
fill 152 279 540 176 279 541 minecraft:obsidian
fill 153 279 552 153 307 552 minecraft:obsidian
fill 161 279 517 161 279 527 minecraft:purple_stained_glass
fill 161 279 529 161 279 539 minecraft:purple_stained_glass
setblock 161 279 552 minecraft:white_concrete
fill 162 279 517 162 279 526 minecraft:purple_stained_glass
fill 162 279 530 162 279 539 minecraft:purple_stained_glass
fill 163 279 517 174 279 525 minecraft:purple_stained_glass
fill 163 279 531 174 279 539 minecraft:purple_stained_glass
fill 164 279 526 174 279 526 minecraft:purple_stained_glass
fill 164 279 530 174 279 530 minecraft:purple_stained_glass
fill 165 279 527 174 279 527 minecraft:purple_stained_glass
fill 165 279 529 174 279 529 minecraft:purple_stained_glass
fill 166 279 510 166 307 510 minecraft:obsidian
fill 166 279 528 174 279 528 minecraft:purple_stained_glass
fill 175 279 517 176 279 539 minecraft:obsidian
fill 183 279 519 183 307 519 minecraft:obsidian
fill 183 279 538 183 307 538 minecraft:obsidian
fill 141 280 523 151 280 523 minecraft:obsidian
setblock 141 280 527 minecraft:white_concrete
fill 141 280 535 151 280 535 minecraft:obsidian
fill 141 280 540 150 280 540 minecraft:obsidian
fill 141 280 547 182 280 547 minecraft:obsidian
fill 142 280 511 149 280 522 minecraft:obsidian
fill 142 280 524 149 280 534 minecraft:obsidian
fill 142 280 536 149 280 539 minecraft:obsidian
fill 142 280 541 149 280 546 minecraft:obsidian
fill 142 280 548 182 280 551 minecraft:obsidian
fill 144 280 510 144 307 510 minecraft:obsidian
fill 150 280 511 150 280 516 minecraft:obsidian
setblock 150 280 517 minecraft:crying_obsidian
fill 150 280 518 150 280 520 minecraft:obsidian
setblock 150 280 521 minecraft:crying_obsidian
fill 150 280 522 151 280 522 minecraft:obsidian
setblock 150 280 524 minecraft:obsidian
setblock 150 280 525 minecraft:crying_obsidian
schedule function dropper:buildpart/123_2 1t
