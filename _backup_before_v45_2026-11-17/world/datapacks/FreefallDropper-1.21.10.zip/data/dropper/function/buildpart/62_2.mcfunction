fill 118 86 275 119 87 275 minecraft:white_concrete
fill 118 86 317 119 87 317 minecraft:white_concrete
fill 120 86 275 121 87 275 minecraft:red_concrete
fill 120 86 317 121 87 317 minecraft:red_concrete
fill 122 86 275 123 87 275 minecraft:white_concrete
fill 122 86 317 123 87 317 minecraft:white_concrete
fill 124 86 275 125 87 275 minecraft:red_concrete
fill 124 86 317 125 87 317 minecraft:red_concrete
fill 126 86 275 127 87 275 minecraft:white_concrete
fill 126 86 317 127 87 317 minecraft:white_concrete
fill 128 86 275 129 87 275 minecraft:red_concrete
fill 128 86 317 129 87 317 minecraft:red_concrete
fill 130 86 275 131 87 275 minecraft:white_concrete
fill 130 86 317 131 87 317 minecraft:white_concrete
fill 132 86 275 133 87 275 minecraft:red_concrete
fill 132 86 317 133 87 317 minecraft:red_concrete
fill 134 86 275 135 87 275 minecraft:white_concrete
fill 134 86 317 135 87 317 minecraft:white_concrete
fill 136 86 276 136 87 276 minecraft:white_concrete
fill 136 86 277 136 87 278 minecraft:red_concrete
fill 136 86 279 136 87 280 minecraft:white_concrete
fill 136 86 281 136 87 282 minecraft:red_concrete
fill 136 86 283 136 87 284 minecraft:white_concrete
fill 136 86 285 136 87 286 minecraft:red_concrete
fill 136 86 287 136 87 288 minecraft:white_concrete
fill 136 86 289 136 87 290 minecraft:red_concrete
fill 136 86 291 136 87 292 minecraft:white_concrete
fill 136 86 293 136 87 294 minecraft:red_concrete
fill 136 86 295 136 87 296 minecraft:white_concrete
fill 136 86 297 136 87 298 minecraft:red_concrete
fill 136 86 299 136 87 300 minecraft:white_concrete
fill 136 86 301 136 87 302 minecraft:red_concrete
fill 136 86 303 136 87 304 minecraft:white_concrete
fill 136 86 305 136 87 306 minecraft:red_concrete
fill 136 86 307 136 87 308 minecraft:white_concrete
fill 136 86 309 136 87 310 minecraft:red_concrete
fill 136 86 311 136 87 312 minecraft:white_concrete
fill 136 86 313 136 87 314 minecraft:red_concrete
fill 136 86 315 136 87 316 minecraft:white_concrete
fill 136 86 317 136 87 317 minecraft:red_concrete
setblock 97 87 278 minecraft:light[level=12]
setblock 97 87 285 minecraft:light[level=12]
setblock 97 87 292 minecraft:light[level=12]
setblock 97 87 299 minecraft:light[level=12]
setblock 97 87 306 minecraft:light[level=12]
setblock 97 87 313 minecraft:light[level=12]
setblock 104 87 278 minecraft:light[level=12]
setblock 104 87 285 minecraft:light[level=12]
setblock 104 87 292 minecraft:light[level=12]
setblock 104 87 299 minecraft:light[level=12]
setblock 104 87 306 minecraft:light[level=12]
setblock 104 87 313 minecraft:light[level=12]
setblock 111 87 278 minecraft:light[level=12]
setblock 111 87 285 minecraft:light[level=12]
setblock 111 87 292 minecraft:light[level=12]
setblock 111 87 299 minecraft:light[level=12]
setblock 111 87 306 minecraft:light[level=12]
setblock 111 87 313 minecraft:light[level=12]
setblock 118 87 278 minecraft:light[level=12]
setblock 118 87 285 minecraft:light[level=12]
setblock 118 87 292 minecraft:light[level=12]
setblock 118 87 299 minecraft:light[level=12]
setblock 118 87 306 minecraft:light[level=12]
setblock 118 87 313 minecraft:light[level=12]
setblock 125 87 278 minecraft:light[level=12]
setblock 125 87 285 minecraft:light[level=12]
setblock 125 87 292 minecraft:light[level=12]
setblock 125 87 299 minecraft:light[level=12]
setblock 125 87 306 minecraft:light[level=12]
setblock 125 87 313 minecraft:light[level=12]
setblock 130 87 306 minecraft:red_terracotta
setblock 130 87 308 minecraft:red_terracotta
fill 131 87 285 131 87 287 minecraft:red_terracotta
setblock 132 87 278 minecraft:light[level=12]
fill 132 87 285 133 87 285 minecraft:red_terracotta
fill 132 87 287 133 87 287 minecraft:red_terracotta
setblock 132 87 292 minecraft:light[level=12]
setblock 132 87 299 minecraft:light[level=12]
setblock 132 87 306 minecraft:red_terracotta
setblock 132 87 308 minecraft:red_terracotta
setblock 132 87 313 minecraft:light[level=12]
setblock 133 87 286 minecraft:red_terracotta
fill 94 88 275 94 89 276 minecraft:red_concrete
fill 94 88 277 94 89 278 minecraft:white_concrete
fill 94 88 279 94 89 279 minecraft:red_concrete
fill 94 88 280 94 93 280 minecraft:shroomlight
fill 94 88 281 94 89 282 minecraft:white_concrete
fill 94 88 283 94 89 284 minecraft:red_concrete
fill 94 88 285 94 89 286 minecraft:white_concrete
fill 94 88 287 94 89 287 minecraft:red_concrete
fill 94 88 288 94 93 288 minecraft:shroomlight
fill 94 88 289 94 89 290 minecraft:white_concrete
fill 94 88 291 94 89 292 minecraft:red_concrete
fill 94 88 293 94 89 294 minecraft:white_concrete
fill 94 88 295 94 89 295 minecraft:red_concrete
fill 94 88 296 94 93 296 minecraft:shroomlight
fill 94 88 297 94 89 298 minecraft:white_concrete
fill 94 88 299 94 89 300 minecraft:red_concrete
fill 94 88 301 94 89 302 minecraft:white_concrete
fill 94 88 303 94 89 303 minecraft:red_concrete
fill 94 88 304 94 93 304 minecraft:shroomlight
fill 94 88 305 94 89 306 minecraft:white_concrete
fill 94 88 307 94 89 308 minecraft:red_concrete
fill 94 88 309 94 89 310 minecraft:white_concrete
fill 94 88 311 94 89 311 minecraft:red_concrete
fill 94 88 312 94 93 312 minecraft:shroomlight
fill 94 88 313 94 89 314 minecraft:white_concrete
fill 94 88 315 94 89 316 minecraft:red_concrete
fill 95 88 275 95 89 275 minecraft:red_concrete
fill 95 88 317 95 89 317 minecraft:red_concrete
fill 96 88 275 97 89 275 minecraft:white_concrete
fill 96 88 317 96 89 317 minecraft:white_concrete
fill 97 88 317 97 93 317 minecraft:shroomlight
fill 98 88 275 99 89 275 minecraft:red_concrete
fill 98 88 317 99 89 317 minecraft:red_concrete
fill 100 88 275 100 89 275 minecraft:white_concrete
fill 100 88 317 101 89 317 minecraft:white_concrete
fill 101 88 275 101 93 275 minecraft:shroomlight
fill 102 88 275 103 89 275 minecraft:red_concrete
fill 102 88 317 103 89 317 minecraft:red_concrete
fill 104 88 275 105 89 275 minecraft:white_concrete
fill 104 88 317 104 89 317 minecraft:white_concrete
fill 105 88 317 105 93 317 minecraft:shroomlight
fill 106 88 275 107 89 275 minecraft:red_concrete
fill 106 88 317 107 89 317 minecraft:red_concrete
fill 108 88 275 108 89 275 minecraft:white_concrete
fill 108 88 317 109 89 317 minecraft:white_concrete
fill 109 88 275 109 93 275 minecraft:shroomlight
fill 110 88 275 111 89 275 minecraft:red_concrete
fill 110 88 317 111 89 317 minecraft:red_concrete
fill 112 88 275 113 89 275 minecraft:white_concrete
fill 112 88 317 112 89 317 minecraft:white_concrete
fill 113 88 317 113 93 317 minecraft:shroomlight
fill 114 88 275 115 89 275 minecraft:red_concrete
fill 114 88 317 115 89 317 minecraft:red_concrete
fill 116 88 275 116 89 275 minecraft:white_concrete
fill 116 88 317 117 89 317 minecraft:white_concrete
fill 117 88 275 117 93 275 minecraft:shroomlight
fill 118 88 275 119 89 275 minecraft:red_concrete
fill 118 88 317 119 89 317 minecraft:red_concrete
fill 120 88 275 121 89 275 minecraft:white_concrete
fill 120 88 317 120 89 317 minecraft:white_concrete
fill 121 88 317 121 93 317 minecraft:shroomlight
fill 122 88 275 123 89 275 minecraft:red_concrete
fill 122 88 317 123 89 317 minecraft:red_concrete
fill 124 88 275 124 89 275 minecraft:white_concrete
fill 124 88 317 125 89 317 minecraft:white_concrete
fill 125 88 275 125 93 275 minecraft:shroomlight
fill 126 88 275 127 89 275 minecraft:red_concrete
fill 126 88 317 127 89 317 minecraft:red_concrete
fill 128 88 275 129 89 275 minecraft:white_concrete
fill 128 88 317 128 89 317 minecraft:white_concrete
fill 129 88 317 129 93 317 minecraft:shroomlight
fill 130 88 275 131 89 275 minecraft:red_concrete
fill 130 88 317 131 89 317 minecraft:red_concrete
fill 132 88 275 132 89 275 minecraft:white_concrete
fill 132 88 317 133 89 317 minecraft:white_concrete
fill 133 88 275 133 93 275 minecraft:shroomlight
fill 134 88 275 135 89 275 minecraft:red_concrete
fill 134 88 317 135 89 317 minecraft:red_concrete
fill 136 88 276 136 89 276 minecraft:red_concrete
fill 136 88 277 136 89 278 minecraft:white_concrete
fill 136 88 279 136 89 279 minecraft:red_concrete
fill 136 88 280 136 93 280 minecraft:shroomlight
fill 136 88 281 136 89 282 minecraft:white_concrete
fill 136 88 283 136 89 284 minecraft:red_concrete
fill 136 88 285 136 89 286 minecraft:white_concrete
fill 136 88 287 136 89 287 minecraft:red_concrete
fill 136 88 288 136 93 288 minecraft:shroomlight
fill 136 88 289 136 89 290 minecraft:white_concrete
fill 136 88 291 136 89 292 minecraft:red_concrete
fill 136 88 293 136 89 294 minecraft:white_concrete
fill 136 88 295 136 89 295 minecraft:red_concrete
fill 136 88 296 136 93 296 minecraft:shroomlight
fill 136 88 297 136 89 298 minecraft:white_concrete
fill 136 88 299 136 89 300 minecraft:red_concrete
fill 136 88 301 136 89 302 minecraft:white_concrete
fill 136 88 303 136 89 303 minecraft:red_concrete
fill 136 88 304 136 93 304 minecraft:shroomlight
fill 136 88 305 136 89 306 minecraft:white_concrete
fill 136 88 307 136 89 308 minecraft:red_concrete
fill 136 88 309 136 89 310 minecraft:white_concrete
fill 136 88 311 136 89 311 minecraft:red_concrete
fill 136 88 312 136 93 312 minecraft:shroomlight
fill 136 88 313 136 89 314 minecraft:white_concrete
fill 136 88 315 136 89 316 minecraft:red_concrete
fill 136 88 317 136 89 317 minecraft:white_concrete
fill 128 89 311 128 89 313 minecraft:brown_terracotta
setblock 129 89 310 minecraft:brown_terracotta
fill 129 89 314 131 89 314 minecraft:brown_terracotta
setblock 131 89 310 minecraft:brown_terracotta
fill 132 89 311 132 89 313 minecraft:brown_terracotta
fill 94 90 275 94 91 276 minecraft:white_concrete
fill 94 90 277 94 91 278 minecraft:red_concrete
fill 94 90 279 94 91 279 minecraft:white_concrete
fill 94 90 281 94 91 282 minecraft:red_concrete
fill 94 90 283 94 91 284 minecraft:white_concrete
fill 94 90 285 94 91 286 minecraft:red_concrete
fill 94 90 287 94 91 287 minecraft:white_concrete
fill 94 90 289 94 91 290 minecraft:red_concrete
fill 94 90 291 94 91 292 minecraft:white_concrete
fill 94 90 293 94 91 294 minecraft:red_concrete
fill 94 90 295 94 91 295 minecraft:white_concrete
fill 94 90 297 94 91 298 minecraft:red_concrete
fill 94 90 299 94 91 300 minecraft:white_concrete
fill 94 90 301 94 91 302 minecraft:red_concrete
fill 94 90 303 94 91 303 minecraft:white_concrete
fill 94 90 305 94 91 306 minecraft:red_concrete
fill 94 90 307 94 91 308 minecraft:white_concrete
fill 94 90 309 94 91 310 minecraft:red_concrete
fill 94 90 311 94 91 311 minecraft:white_concrete
fill 94 90 313 94 91 314 minecraft:red_concrete
fill 94 90 315 94 91 316 minecraft:white_concrete
fill 95 90 275 95 91 275 minecraft:white_concrete
fill 95 90 317 95 91 317 minecraft:white_concrete
fill 96 90 275 97 91 275 minecraft:red_concrete
fill 96 90 317 96 91 317 minecraft:red_concrete
fill 98 90 275 99 91 275 minecraft:white_concrete
fill 98 90 317 99 91 317 minecraft:white_concrete
fill 100 90 275 100 91 275 minecraft:red_concrete
fill 100 90 317 101 91 317 minecraft:red_concrete
fill 102 90 275 103 91 275 minecraft:white_concrete
fill 102 90 317 103 91 317 minecraft:white_concrete
fill 104 90 275 105 91 275 minecraft:red_concrete
fill 104 90 317 104 91 317 minecraft:red_concrete
fill 106 90 275 107 91 275 minecraft:white_concrete
fill 106 90 317 107 91 317 minecraft:white_concrete
fill 108 90 275 108 91 275 minecraft:red_concrete
fill 108 90 317 109 91 317 minecraft:red_concrete
fill 110 90 275 111 91 275 minecraft:white_concrete
fill 110 90 317 111 91 317 minecraft:white_concrete
fill 112 90 275 113 91 275 minecraft:red_concrete
fill 112 90 317 112 91 317 minecraft:red_concrete
fill 114 90 275 115 91 275 minecraft:white_concrete
fill 114 90 317 115 91 317 minecraft:white_concrete
fill 116 90 275 116 91 275 minecraft:red_concrete
fill 116 90 317 117 91 317 minecraft:red_concrete
fill 118 90 275 119 91 275 minecraft:white_concrete
fill 118 90 317 119 91 317 minecraft:white_concrete
fill 120 90 275 121 91 275 minecraft:red_concrete
fill 120 90 317 120 91 317 minecraft:red_concrete
fill 122 90 275 123 91 275 minecraft:white_concrete
fill 122 90 317 123 91 317 minecraft:white_concrete
fill 124 90 275 124 91 275 minecraft:red_concrete
fill 124 90 317 125 91 317 minecraft:red_concrete
fill 126 90 275 127 91 275 minecraft:white_concrete
fill 126 90 317 127 91 317 minecraft:white_concrete
fill 128 90 275 129 91 275 minecraft:red_concrete
fill 128 90 317 128 91 317 minecraft:red_concrete
fill 130 90 275 131 91 275 minecraft:white_concrete
fill 130 90 317 131 91 317 minecraft:white_concrete
fill 132 90 275 132 91 275 minecraft:red_concrete
fill 132 90 317 133 91 317 minecraft:red_concrete
fill 134 90 275 135 91 275 minecraft:white_concrete
fill 134 90 317 135 91 317 minecraft:white_concrete
fill 136 90 276 136 91 276 minecraft:white_concrete
fill 136 90 277 136 91 278 minecraft:red_concrete
fill 136 90 279 136 91 279 minecraft:white_concrete
fill 136 90 281 136 91 282 minecraft:red_concrete
fill 136 90 283 136 91 284 minecraft:white_concrete
fill 136 90 285 136 91 286 minecraft:red_concrete
fill 136 90 287 136 91 287 minecraft:white_concrete
fill 136 90 289 136 91 290 minecraft:red_concrete
fill 136 90 291 136 91 292 minecraft:white_concrete
fill 136 90 293 136 91 294 minecraft:red_concrete
fill 136 90 295 136 91 295 minecraft:white_concrete
fill 136 90 297 136 91 298 minecraft:red_concrete
fill 136 90 299 136 91 300 minecraft:white_concrete
fill 136 90 301 136 91 302 minecraft:red_concrete
fill 136 90 303 136 91 303 minecraft:white_concrete
fill 136 90 305 136 91 306 minecraft:red_concrete
fill 136 90 307 136 91 308 minecraft:white_concrete
fill 136 90 309 136 91 310 minecraft:red_concrete
fill 136 90 311 136 91 311 minecraft:white_concrete
fill 136 90 313 136 91 314 minecraft:red_concrete
fill 136 90 315 136 91 316 minecraft:white_concrete
fill 136 90 317 136 91 317 minecraft:red_concrete
fill 95 91 300 101 91 300 minecraft:brown_terracotta
fill 97 91 298 101 92 299 minecraft:brown_terracotta
fill 97 91 301 101 92 302 minecraft:brown_terracotta
fill 94 92 275 94 93 276 minecraft:red_concrete
fill 94 92 277 94 93 278 minecraft:white_concrete
fill 94 92 279 94 93 279 minecraft:red_concrete
fill 94 92 281 94 93 282 minecraft:white_concrete
fill 94 92 283 94 93 284 minecraft:red_concrete
fill 94 92 285 94 93 286 minecraft:white_concrete
fill 94 92 287 94 93 287 minecraft:red_concrete
fill 94 92 289 94 93 290 minecraft:white_concrete
fill 94 92 291 94 93 292 minecraft:red_concrete
fill 94 92 293 94 93 294 minecraft:white_concrete
fill 94 92 295 94 93 295 minecraft:red_concrete
fill 94 92 297 94 93 298 minecraft:white_concrete
fill 94 92 299 94 93 300 minecraft:red_concrete
fill 94 92 301 94 93 302 minecraft:white_concrete
fill 94 92 303 94 93 303 minecraft:red_concrete
fill 94 92 305 94 93 306 minecraft:white_concrete
fill 94 92 307 94 93 308 minecraft:red_concrete
fill 94 92 309 94 93 310 minecraft:white_concrete
fill 94 92 311 94 93 311 minecraft:red_concrete
fill 94 92 313 94 93 314 minecraft:white_concrete
fill 94 92 315 94 93 316 minecraft:red_concrete
fill 95 92 275 95 93 275 minecraft:red_concrete
fill 95 92 317 95 93 317 minecraft:red_concrete
fill 96 92 275 97 93 275 minecraft:white_concrete
fill 96 92 317 96 93 317 minecraft:white_concrete
fill 97 92 300 101 92 300 minecraft:brown_terracotta
fill 98 92 275 99 93 275 minecraft:red_concrete
fill 98 92 317 99 93 317 minecraft:red_concrete
fill 100 92 275 100 93 275 minecraft:white_concrete
fill 100 92 317 101 93 317 minecraft:white_concrete
fill 102 92 275 103 93 275 minecraft:red_concrete
fill 102 92 317 103 93 317 minecraft:red_concrete
fill 104 92 275 105 93 275 minecraft:white_concrete
fill 104 92 317 104 93 317 minecraft:white_concrete
fill 106 92 275 107 93 275 minecraft:red_concrete
fill 106 92 317 107 93 317 minecraft:red_concrete
fill 108 92 275 108 93 275 minecraft:white_concrete
fill 108 92 317 109 93 317 minecraft:white_concrete
fill 110 92 275 111 93 275 minecraft:red_concrete
fill 110 92 317 111 93 317 minecraft:red_concrete
fill 112 92 275 113 93 275 minecraft:white_concrete
fill 112 92 317 112 93 317 minecraft:white_concrete
fill 114 92 275 115 93 275 minecraft:red_concrete
fill 114 92 317 115 93 317 minecraft:red_concrete
fill 116 92 275 116 93 275 minecraft:white_concrete
fill 116 92 317 117 93 317 minecraft:white_concrete
fill 118 92 275 119 93 275 minecraft:red_concrete
fill 118 92 317 119 93 317 minecraft:red_concrete
fill 120 92 275 121 93 275 minecraft:white_concrete
fill 120 92 317 120 93 317 minecraft:white_concrete
fill 122 92 275 123 93 275 minecraft:red_concrete
fill 122 92 317 123 93 317 minecraft:red_concrete
fill 124 92 275 124 93 275 minecraft:white_concrete
fill 124 92 317 125 93 317 minecraft:white_concrete
fill 126 92 275 127 93 275 minecraft:red_concrete
fill 126 92 317 127 93 317 minecraft:red_concrete
fill 128 92 275 129 93 275 minecraft:white_concrete
fill 128 92 317 128 93 317 minecraft:white_concrete
fill 130 92 275 131 93 275 minecraft:red_concrete
setblock 130 92 306 minecraft:red_terracotta
setblock 130 92 308 minecraft:red_terracotta
fill 130 92 317 131 93 317 minecraft:red_concrete
fill 131 92 285 131 92 287 minecraft:red_terracotta
fill 132 92 275 132 93 275 minecraft:white_concrete
fill 132 92 285 133 92 285 minecraft:red_terracotta
fill 132 92 287 133 92 287 minecraft:red_terracotta
setblock 132 92 306 minecraft:red_terracotta
setblock 132 92 308 minecraft:red_terracotta
fill 132 92 317 133 93 317 minecraft:white_concrete
setblock 133 92 286 minecraft:red_terracotta
fill 134 92 275 135 93 275 minecraft:red_concrete
fill 134 92 317 135 93 317 minecraft:red_concrete
fill 136 92 276 136 93 276 minecraft:red_concrete
fill 136 92 277 136 93 278 minecraft:white_concrete
fill 136 92 279 136 93 279 minecraft:red_concrete
fill 136 92 281 136 93 282 minecraft:white_concrete
fill 136 92 283 136 93 284 minecraft:red_concrete
fill 136 92 285 136 93 286 minecraft:white_concrete
fill 136 92 287 136 93 287 minecraft:red_concrete
fill 136 92 289 136 93 290 minecraft:white_concrete
fill 136 92 291 136 93 292 minecraft:red_concrete
fill 136 92 293 136 93 294 minecraft:white_concrete
fill 136 92 295 136 93 295 minecraft:red_concrete
fill 136 92 297 136 93 298 minecraft:white_concrete
fill 136 92 299 136 93 300 minecraft:red_concrete
fill 136 92 301 136 93 302 minecraft:white_concrete
fill 136 92 303 136 93 303 minecraft:red_concrete
fill 136 92 305 136 93 306 minecraft:white_concrete
fill 136 92 307 136 93 308 minecraft:red_concrete
fill 136 92 309 136 93 310 minecraft:white_concrete
fill 136 92 311 136 93 311 minecraft:red_concrete
fill 136 92 313 136 93 314 minecraft:white_concrete
fill 136 92 315 136 93 316 minecraft:red_concrete
fill 136 92 317 136 93 317 minecraft:white_concrete
setblock 97 93 278 minecraft:light[level=15]
setblock 97 93 285 minecraft:light[level=12]
setblock 97 93 286 minecraft:light[level=15]
setblock 97 93 292 minecraft:light[level=12]
setblock 97 93 294 minecraft:light[level=15]
setblock 97 93 299 minecraft:light[level=12]
setblock 97 93 302 minecraft:light[level=15]
setblock 97 93 306 minecraft:light[level=12]
setblock 97 93 310 minecraft:light[level=15]
setblock 97 93 313 minecraft:light[level=12]
fill 99 93 300 99 96 300 minecraft:red_terracotta
setblock 104 93 278 minecraft:light[level=12]
setblock 104 93 285 minecraft:light[level=12]
setblock 104 93 292 minecraft:light[level=12]
setblock 104 93 299 minecraft:light[level=12]
setblock 104 93 306 minecraft:light[level=12]
setblock 104 93 313 minecraft:light[level=12]
setblock 105 93 278 minecraft:light[level=15]
setblock 105 93 286 minecraft:light[level=15]
setblock 105 93 294 minecraft:light[level=15]
setblock 105 93 302 minecraft:light[level=15]
setblock 105 93 310 minecraft:light[level=15]
setblock 111 93 278 minecraft:light[level=12]
setblock 111 93 285 minecraft:light[level=12]
setblock 111 93 292 minecraft:light[level=12]
setblock 111 93 299 minecraft:light[level=12]
setblock 111 93 306 minecraft:light[level=12]
setblock 111 93 313 minecraft:light[level=12]
setblock 113 93 278 minecraft:light[level=15]
setblock 113 93 286 minecraft:light[level=15]
setblock 113 93 294 minecraft:light[level=15]
setblock 113 93 302 minecraft:light[level=15]
setblock 113 93 310 minecraft:light[level=15]
setblock 118 93 278 minecraft:light[level=12]
setblock 118 93 285 minecraft:light[level=12]
setblock 118 93 292 minecraft:light[level=12]
setblock 118 93 299 minecraft:light[level=12]
setblock 118 93 306 minecraft:light[level=12]
setblock 118 93 313 minecraft:light[level=12]
setblock 121 93 278 minecraft:light[level=15]
setblock 121 93 286 minecraft:light[level=15]
setblock 121 93 294 minecraft:light[level=15]
setblock 121 93 302 minecraft:light[level=15]
setblock 121 93 310 minecraft:light[level=15]
setblock 125 93 278 minecraft:light[level=12]
setblock 125 93 285 minecraft:light[level=12]
setblock 125 93 292 minecraft:light[level=12]
setblock 125 93 299 minecraft:light[level=12]
setblock 125 93 306 minecraft:light[level=12]
setblock 125 93 313 minecraft:light[level=12]
setblock 129 93 278 minecraft:light[level=15]
setblock 129 93 286 minecraft:light[level=15]
setblock 129 93 294 minecraft:light[level=15]
setblock 129 93 302 minecraft:light[level=15]
setblock 129 93 310 minecraft:light[level=15]
setblock 132 93 278 minecraft:light[level=12]
setblock 132 93 285 minecraft:light[level=12]
setblock 132 93 292 minecraft:light[level=12]
setblock 132 93 299 minecraft:light[level=12]
setblock 132 93 306 minecraft:light[level=12]
setblock 132 93 313 minecraft:light[level=12]
fill 94 94 275 94 95 276 minecraft:white_concrete
fill 94 94 277 94 95 278 minecraft:red_concrete
fill 94 94 279 94 95 280 minecraft:white_concrete
fill 94 94 281 94 95 282 minecraft:red_concrete
fill 94 94 283 94 95 284 minecraft:white_concrete
fill 94 94 285 94 95 286 minecraft:red_concrete
fill 94 94 287 94 95 288 minecraft:white_concrete
fill 94 94 289 94 95 290 minecraft:red_concrete
fill 94 94 291 94 95 292 minecraft:white_concrete
fill 94 94 293 94 95 294 minecraft:red_concrete
fill 94 94 295 94 95 296 minecraft:white_concrete
fill 94 94 297 94 95 298 minecraft:red_concrete
fill 94 94 299 94 95 300 minecraft:white_concrete
fill 94 94 301 94 95 302 minecraft:red_concrete
fill 94 94 303 94 95 304 minecraft:white_concrete
fill 94 94 305 94 95 306 minecraft:red_concrete
fill 94 94 307 94 95 308 minecraft:white_concrete
fill 94 94 309 94 95 310 minecraft:red_concrete
fill 94 94 311 94 95 312 minecraft:white_concrete
fill 94 94 313 94 95 314 minecraft:red_concrete
fill 94 94 315 94 95 316 minecraft:white_concrete
fill 95 94 275 95 95 275 minecraft:white_concrete
fill 95 94 317 95 95 317 minecraft:white_concrete
fill 96 94 275 97 95 275 minecraft:red_concrete
fill 96 94 317 97 95 317 minecraft:red_concrete
fill 98 94 275 99 95 275 minecraft:white_concrete
fill 98 94 317 99 95 317 minecraft:white_concrete
fill 100 94 275 101 95 275 minecraft:red_concrete
fill 100 94 317 101 95 317 minecraft:red_concrete
fill 102 94 275 103 95 275 minecraft:white_concrete
fill 102 94 317 103 95 317 minecraft:white_concrete
fill 104 94 275 105 95 275 minecraft:red_concrete
fill 104 94 317 105 95 317 minecraft:red_concrete
fill 106 94 275 107 95 275 minecraft:white_concrete
fill 106 94 317 107 95 317 minecraft:white_concrete
fill 108 94 275 109 95 275 minecraft:red_concrete
fill 108 94 317 109 95 317 minecraft:red_concrete
fill 110 94 275 111 95 275 minecraft:white_concrete
fill 110 94 317 111 95 317 minecraft:white_concrete
fill 112 94 275 113 95 275 minecraft:red_concrete
fill 112 94 317 113 95 317 minecraft:red_concrete
fill 114 94 275 115 95 275 minecraft:white_concrete
fill 114 94 317 115 95 317 minecraft:white_concrete
fill 116 94 275 117 95 275 minecraft:red_concrete
fill 116 94 317 117 95 317 minecraft:red_concrete
fill 118 94 275 119 95 275 minecraft:white_concrete
fill 118 94 317 119 95 317 minecraft:white_concrete
fill 120 94 275 121 95 275 minecraft:red_concrete
fill 120 94 317 121 95 317 minecraft:red_concrete
fill 122 94 275 123 95 275 minecraft:white_concrete
fill 122 94 317 123 95 317 minecraft:white_concrete
fill 124 94 275 125 95 275 minecraft:red_concrete
fill 124 94 317 125 95 317 minecraft:red_concrete
fill 126 94 275 127 95 275 minecraft:white_concrete
fill 126 94 317 127 95 317 minecraft:white_concrete
fill 128 94 275 129 95 275 minecraft:red_concrete
fill 128 94 317 129 95 317 minecraft:red_concrete
fill 130 94 275 131 95 275 minecraft:white_concrete
fill 130 94 317 131 95 317 minecraft:white_concrete
fill 132 94 275 133 95 275 minecraft:red_concrete
fill 132 94 317 133 95 317 minecraft:red_concrete
fill 134 94 275 135 95 275 minecraft:white_concrete
fill 134 94 317 135 95 317 minecraft:white_concrete
fill 136 94 276 136 95 276 minecraft:white_concrete
fill 136 94 277 136 95 278 minecraft:red_concrete
fill 136 94 279 136 95 280 minecraft:white_concrete
fill 136 94 281 136 95 282 minecraft:red_concrete
fill 136 94 283 136 95 284 minecraft:white_concrete
fill 136 94 285 136 95 286 minecraft:red_concrete
fill 136 94 287 136 95 288 minecraft:white_concrete
fill 136 94 289 136 95 290 minecraft:red_concrete
fill 136 94 291 136 95 292 minecraft:white_concrete
fill 136 94 293 136 95 294 minecraft:red_concrete
fill 136 94 295 136 95 296 minecraft:white_concrete
fill 136 94 297 136 95 298 minecraft:red_concrete
fill 136 94 299 136 95 300 minecraft:white_concrete
fill 136 94 301 136 95 302 minecraft:red_concrete
fill 136 94 303 136 95 304 minecraft:white_concrete
fill 136 94 305 136 95 306 minecraft:red_concrete
fill 136 94 307 136 95 308 minecraft:white_concrete
fill 136 94 309 136 95 310 minecraft:red_concrete
fill 136 94 311 136 95 312 minecraft:white_concrete
fill 136 94 313 136 95 314 minecraft:red_concrete
fill 136 94 315 136 95 316 minecraft:white_concrete
fill 136 94 317 136 95 317 minecraft:red_concrete
fill 94 96 275 94 97 276 minecraft:red_concrete
fill 94 96 277 94 97 278 minecraft:white_concrete
fill 94 96 279 94 97 280 minecraft:red_concrete
fill 94 96 281 94 97 282 minecraft:white_concrete
fill 94 96 283 94 97 284 minecraft:red_concrete
fill 94 96 285 94 97 286 minecraft:white_concrete
fill 94 96 287 94 97 288 minecraft:red_concrete
fill 94 96 289 94 97 290 minecraft:white_concrete
fill 94 96 291 94 97 292 minecraft:red_concrete
fill 94 96 293 94 97 294 minecraft:white_concrete
fill 94 96 295 94 97 296 minecraft:red_concrete
fill 94 96 297 94 97 298 minecraft:white_concrete
fill 94 96 299 94 97 300 minecraft:red_concrete
fill 94 96 301 94 97 302 minecraft:white_concrete
fill 94 96 303 94 97 304 minecraft:red_concrete
fill 94 96 305 94 97 306 minecraft:white_concrete
fill 94 96 307 94 97 308 minecraft:red_concrete
fill 94 96 309 94 97 310 minecraft:white_concrete
fill 94 96 311 94 97 312 minecraft:red_concrete
fill 94 96 313 94 97 314 minecraft:white_concrete
fill 94 96 315 94 97 316 minecraft:red_concrete
fill 95 96 275 95 97 275 minecraft:red_concrete
fill 95 96 317 95 97 317 minecraft:red_concrete
fill 96 96 275 97 97 275 minecraft:white_concrete
fill 96 96 317 97 97 317 minecraft:white_concrete
fill 98 96 275 99 97 275 minecraft:red_concrete
fill 98 96 317 99 97 317 minecraft:red_concrete
fill 100 96 275 101 97 275 minecraft:white_concrete
fill 100 96 317 101 97 317 minecraft:white_concrete
fill 102 96 275 103 97 275 minecraft:red_concrete
fill 102 96 317 103 97 317 minecraft:red_concrete
fill 104 96 275 105 97 275 minecraft:white_concrete
fill 104 96 317 105 97 317 minecraft:white_concrete
fill 106 96 275 107 97 275 minecraft:red_concrete
fill 106 96 317 107 97 317 minecraft:red_concrete
fill 108 96 275 109 97 275 minecraft:white_concrete
fill 108 96 317 109 97 317 minecraft:white_concrete
fill 110 96 275 111 97 275 minecraft:red_concrete
fill 110 96 317 111 97 317 minecraft:red_concrete
fill 112 96 275 113 97 275 minecraft:white_concrete
fill 112 96 317 113 97 317 minecraft:white_concrete
fill 114 96 275 115 97 275 minecraft:red_concrete
fill 114 96 317 115 97 317 minecraft:red_concrete
fill 116 96 275 117 97 275 minecraft:white_concrete
fill 116 96 317 117 97 317 minecraft:white_concrete
fill 118 96 275 119 97 275 minecraft:red_concrete
fill 118 96 317 119 97 317 minecraft:red_concrete
fill 120 96 275 121 97 275 minecraft:white_concrete
fill 120 96 317 121 97 317 minecraft:white_concrete
fill 122 96 275 123 97 275 minecraft:red_concrete
fill 122 96 317 123 97 317 minecraft:red_concrete
fill 124 96 275 125 97 275 minecraft:white_concrete
fill 124 96 317 125 97 317 minecraft:white_concrete
fill 126 96 275 127 97 275 minecraft:red_concrete
fill 126 96 317 127 97 317 minecraft:red_concrete
fill 128 96 275 129 97 275 minecraft:white_concrete
fill 128 96 317 129 97 317 minecraft:white_concrete
fill 130 96 275 131 97 275 minecraft:red_concrete
fill 130 96 317 131 97 317 minecraft:red_concrete
fill 132 96 275 133 97 275 minecraft:white_concrete
fill 132 96 317 133 97 317 minecraft:white_concrete
fill 134 96 275 135 97 275 minecraft:red_concrete
fill 134 96 317 135 97 317 minecraft:red_concrete
fill 136 96 276 136 97 276 minecraft:red_concrete
fill 136 96 277 136 97 278 minecraft:white_concrete
fill 136 96 279 136 97 280 minecraft:red_concrete
fill 136 96 281 136 97 282 minecraft:white_concrete
fill 136 96 283 136 97 284 minecraft:red_concrete
fill 136 96 285 136 97 286 minecraft:white_concrete
fill 136 96 287 136 97 288 minecraft:red_concrete
fill 136 96 289 136 97 290 minecraft:white_concrete
fill 136 96 291 136 97 292 minecraft:red_concrete
fill 136 96 293 136 97 294 minecraft:white_concrete
fill 136 96 295 136 97 296 minecraft:red_concrete
fill 136 96 297 136 97 298 minecraft:white_concrete
fill 136 96 299 136 97 300 minecraft:red_concrete
fill 136 96 301 136 97 302 minecraft:white_concrete
fill 136 96 303 136 97 304 minecraft:red_concrete
fill 136 96 305 136 97 306 minecraft:white_concrete
fill 136 96 307 136 97 308 minecraft:red_concrete
fill 136 96 309 136 97 310 minecraft:white_concrete
fill 136 96 311 136 97 312 minecraft:red_concrete
fill 136 96 313 136 97 314 minecraft:white_concrete
fill 136 96 315 136 97 316 minecraft:red_concrete
fill 136 96 317 136 97 317 minecraft:white_concrete
fill 97 97 300 101 100 300 minecraft:yellow_concrete
fill 98 97 299 100 100 299 minecraft:yellow_concrete
fill 98 97 301 100 100 301 minecraft:yellow_concrete
fill 99 97 298 99 100 298 minecraft:yellow_concrete
fill 99 97 302 99 100 302 minecraft:yellow_concrete
fill 128 97 311 128 97 313 minecraft:brown_terracotta
setblock 129 97 310 minecraft:brown_terracotta
fill 129 97 314 131 97 314 minecraft:brown_terracotta
setblock 130 97 306 minecraft:red_terracotta
setblock 130 97 308 minecraft:red_terracotta
fill 131 97 285 131 97 287 minecraft:red_terracotta
setblock 131 97 310 minecraft:brown_terracotta
fill 132 97 285 133 97 285 minecraft:red_terracotta
fill 132 97 287 133 97 287 minecraft:red_terracotta
setblock 132 97 306 minecraft:red_terracotta
setblock 132 97 308 minecraft:red_terracotta
fill 132 97 311 132 97 313 minecraft:brown_terracotta
setblock 133 97 286 minecraft:red_terracotta
fill 94 98 275 94 99 276 minecraft:white_concrete
fill 94 98 277 94 99 278 minecraft:red_concrete
fill 94 98 279 94 99 280 minecraft:white_concrete
fill 94 98 281 94 99 282 minecraft:red_concrete
fill 94 98 283 94 99 284 minecraft:white_concrete
fill 94 98 285 94 99 286 minecraft:red_concrete
fill 94 98 287 94 99 288 minecraft:white_concrete
fill 94 98 289 94 99 290 minecraft:red_concrete
fill 94 98 291 94 99 292 minecraft:white_concrete
fill 94 98 293 94 99 294 minecraft:red_concrete
fill 94 98 295 94 99 296 minecraft:white_concrete
fill 94 98 297 94 99 298 minecraft:red_concrete
fill 94 98 299 94 99 300 minecraft:white_concrete
fill 94 98 301 94 99 302 minecraft:red_concrete
fill 94 98 303 94 99 304 minecraft:white_concrete
fill 94 98 305 94 99 306 minecraft:red_concrete
fill 94 98 307 94 99 308 minecraft:white_concrete
fill 94 98 309 94 99 310 minecraft:red_concrete
fill 94 98 311 94 99 312 minecraft:white_concrete
fill 94 98 313 94 99 314 minecraft:red_concrete
fill 94 98 315 94 99 316 minecraft:white_concrete
fill 95 98 275 95 99 275 minecraft:white_concrete
fill 95 98 276 95 99 281 minecraft:red_terracotta
fill 95 98 284 96 98 289 minecraft:red_terracotta
fill 95 98 292 96 98 297 minecraft:red_terracotta
fill 95 98 300 96 98 305 minecraft:red_terracotta
fill 95 98 308 96 98 313 minecraft:red_terracotta
fill 95 98 316 100 99 316 minecraft:red_terracotta
fill 95 98 317 95 99 317 minecraft:white_concrete
fill 96 98 275 97 99 275 minecraft:red_concrete
fill 96 98 277 96 98 283 minecraft:red_terracotta
fill 96 98 290 96 98 291 minecraft:red_terracotta
fill 96 98 298 96 98 299 minecraft:red_terracotta
fill 96 98 306 96 98 307 minecraft:red_terracotta
fill 96 98 314 96 98 315 minecraft:red_terracotta
fill 96 98 317 97 99 317 minecraft:red_concrete
fill 97 98 277 134 98 277 minecraft:red_terracotta
fill 97 98 299 97 99 299 minecraft:yellow_concrete
fill 97 98 301 97 99 301 minecraft:yellow_concrete
fill 97 98 315 135 98 315 minecraft:red_terracotta
fill 98 98 275 99 99 275 minecraft:white_concrete
fill 98 98 276 103 99 276 minecraft:red_terracotta
fill 98 98 298 98 99 298 minecraft:yellow_concrete
fill 98 98 302 98 99 302 minecraft:yellow_concrete
fill 98 98 317 99 99 317 minecraft:white_concrete
fill 100 98 275 101 99 275 minecraft:red_concrete
fill 100 98 298 100 99 298 minecraft:yellow_concrete
fill 100 98 302 100 99 302 minecraft:yellow_concrete
fill 100 98 317 101 99 317 minecraft:red_concrete
fill 101 98 299 101 99 299 minecraft:yellow_concrete
fill 101 98 301 101 99 301 minecraft:yellow_concrete
fill 102 98 275 103 99 275 minecraft:white_concrete
fill 102 98 317 103 99 317 minecraft:white_concrete
fill 103 98 316 108 99 316 minecraft:red_terracotta
fill 104 98 275 105 99 275 minecraft:red_concrete
fill 104 98 317 105 99 317 minecraft:red_concrete
fill 106 98 275 107 99 275 minecraft:white_concrete
fill 106 98 276 111 99 276 minecraft:red_terracotta
fill 106 98 317 107 99 317 minecraft:white_concrete
fill 108 98 275 109 99 275 minecraft:red_concrete
fill 108 98 317 109 99 317 minecraft:red_concrete
fill 110 98 275 111 99 275 minecraft:white_concrete
fill 110 98 317 111 99 317 minecraft:white_concrete
fill 111 98 316 116 99 316 minecraft:red_terracotta
fill 112 98 275 113 99 275 minecraft:red_concrete
fill 112 98 317 113 99 317 minecraft:red_concrete
fill 114 98 275 115 99 275 minecraft:white_concrete
fill 114 98 276 119 99 276 minecraft:red_terracotta
fill 114 98 317 115 99 317 minecraft:white_concrete
fill 116 98 275 117 99 275 minecraft:red_concrete
fill 116 98 317 117 99 317 minecraft:red_concrete
fill 118 98 275 119 99 275 minecraft:white_concrete
fill 118 98 317 119 99 317 minecraft:white_concrete
fill 119 98 316 124 99 316 minecraft:red_terracotta
fill 120 98 275 121 99 275 minecraft:red_concrete
fill 120 98 317 121 99 317 minecraft:red_concrete
fill 122 98 275 123 99 275 minecraft:white_concrete
fill 122 98 276 127 99 276 minecraft:red_terracotta
fill 122 98 317 123 99 317 minecraft:white_concrete
fill 124 98 275 125 99 275 minecraft:red_concrete
fill 124 98 317 125 99 317 minecraft:red_concrete
fill 126 98 275 127 99 275 minecraft:white_concrete
fill 126 98 317 127 99 317 minecraft:white_concrete
fill 127 98 316 132 99 316 minecraft:red_terracotta
fill 128 98 275 129 99 275 minecraft:red_concrete
fill 128 98 317 129 99 317 minecraft:red_concrete
fill 130 98 275 131 99 275 minecraft:white_concrete
fill 130 98 276 135 99 276 minecraft:red_terracotta
fill 130 98 317 131 99 317 minecraft:white_concrete
fill 132 98 275 133 99 275 minecraft:red_concrete
fill 132 98 317 133 99 317 minecraft:red_concrete
fill 134 98 275 135 99 275 minecraft:white_concrete
fill 134 98 278 134 98 314 minecraft:red_terracotta
fill 134 98 317 135 99 317 minecraft:white_concrete
fill 135 98 279 135 99 284 minecraft:red_terracotta
fill 135 98 287 135 99 292 minecraft:red_terracotta
fill 135 98 295 135 99 300 minecraft:red_terracotta
fill 135 98 303 135 99 308 minecraft:red_terracotta
fill 135 98 311 135 99 314 minecraft:red_terracotta
fill 135 98 316 135 99 316 minecraft:red_terracotta
fill 136 98 276 136 99 276 minecraft:white_concrete
fill 136 98 277 136 99 278 minecraft:red_concrete
fill 136 98 279 136 99 280 minecraft:white_concrete
fill 136 98 281 136 99 282 minecraft:red_concrete
fill 136 98 283 136 99 284 minecraft:white_concrete
fill 136 98 285 136 99 286 minecraft:red_concrete
fill 136 98 287 136 99 288 minecraft:white_concrete
fill 136 98 289 136 99 290 minecraft:red_concrete
fill 136 98 291 136 99 292 minecraft:white_concrete
fill 136 98 293 136 99 294 minecraft:red_concrete
fill 136 98 295 136 99 296 minecraft:white_concrete
fill 136 98 297 136 99 298 minecraft:red_concrete
fill 136 98 299 136 99 300 minecraft:white_concrete
fill 136 98 301 136 99 302 minecraft:red_concrete
fill 136 98 303 136 99 304 minecraft:white_concrete
fill 136 98 305 136 99 306 minecraft:red_concrete
fill 136 98 307 136 99 308 minecraft:white_concrete
fill 136 98 309 136 99 310 minecraft:red_concrete
fill 136 98 311 136 99 312 minecraft:white_concrete
fill 136 98 313 136 99 314 minecraft:red_concrete
fill 136 98 315 136 99 316 minecraft:white_concrete
fill 136 98 317 136 99 317 minecraft:red_concrete
fill 95 99 284 95 99 289 minecraft:red_terracotta
fill 95 99 292 95 99 297 minecraft:red_terracotta
fill 95 99 300 95 99 305 minecraft:red_terracotta
fill 95 99 308 95 99 313 minecraft:red_terracotta
setblock 97 99 278 minecraft:light[level=12]
setblock 97 99 285 minecraft:light[level=12]
setblock 97 99 292 minecraft:light[level=12]
setblock 97 99 306 minecraft:light[level=12]
setblock 97 99 313 minecraft:light[level=12]
setblock 104 99 278 minecraft:light[level=12]
setblock 104 99 285 minecraft:light[level=12]
setblock 104 99 292 minecraft:light[level=12]
setblock 104 99 299 minecraft:light[level=12]
setblock 104 99 306 minecraft:light[level=12]
setblock 104 99 313 minecraft:light[level=12]
setblock 111 99 278 minecraft:light[level=12]
setblock 111 99 285 minecraft:light[level=12]
setblock 111 99 292 minecraft:light[level=12]
setblock 111 99 299 minecraft:light[level=12]
setblock 111 99 306 minecraft:light[level=12]
setblock 111 99 313 minecraft:light[level=12]
setblock 118 99 278 minecraft:light[level=12]
setblock 118 99 285 minecraft:light[level=12]
setblock 118 99 292 minecraft:light[level=12]
setblock 118 99 299 minecraft:light[level=12]
setblock 118 99 306 minecraft:light[level=12]
setblock 118 99 313 minecraft:light[level=12]
setblock 125 99 278 minecraft:light[level=12]
setblock 125 99 285 minecraft:light[level=12]
setblock 125 99 292 minecraft:light[level=12]
setblock 125 99 299 minecraft:light[level=12]
setblock 125 99 306 minecraft:light[level=12]
setblock 125 99 313 minecraft:light[level=12]
setblock 132 99 278 minecraft:light[level=12]
setblock 132 99 285 minecraft:light[level=12]
setblock 132 99 292 minecraft:light[level=12]
setblock 132 99 299 minecraft:light[level=12]
setblock 132 99 306 minecraft:light[level=12]
setblock 132 99 313 minecraft:light[level=12]
setblock 135 99 315 minecraft:red_terracotta
fill 94 100 275 94 101 276 minecraft:red_concrete
fill 94 100 277 94 101 278 minecraft:white_concrete
fill 94 100 279 94 101 280 minecraft:red_concrete
fill 94 100 281 94 101 282 minecraft:white_concrete
fill 94 100 283 94 101 284 minecraft:red_concrete
fill 94 100 285 94 101 286 minecraft:white_concrete
fill 94 100 287 94 101 288 minecraft:red_concrete
fill 94 100 289 94 101 290 minecraft:white_concrete
fill 94 100 291 94 101 292 minecraft:red_concrete
fill 94 100 293 94 101 294 minecraft:white_concrete
fill 94 100 295 94 101 296 minecraft:red_concrete
fill 94 100 297 94 101 298 minecraft:white_concrete
fill 94 100 299 94 101 300 minecraft:red_concrete
fill 94 100 301 94 101 302 minecraft:white_concrete
fill 94 100 303 94 101 304 minecraft:red_concrete
fill 94 100 305 94 101 306 minecraft:white_concrete
fill 94 100 307 94 101 308 minecraft:red_concrete
fill 94 100 309 94 101 310 minecraft:white_concrete
fill 94 100 311 94 101 312 minecraft:red_concrete
fill 94 100 313 94 101 314 minecraft:white_concrete
fill 94 100 315 94 101 316 minecraft:red_concrete
fill 95 100 275 95 101 275 minecraft:red_concrete
fill 95 100 317 95 101 317 minecraft:red_concrete
fill 96 100 275 97 101 275 minecraft:white_concrete
fill 96 100 317 97 101 317 minecraft:white_concrete
fill 98 100 275 99 101 275 minecraft:red_concrete
fill 98 100 317 99 101 317 minecraft:red_concrete
fill 100 100 275 101 101 275 minecraft:white_concrete
fill 100 100 317 101 101 317 minecraft:white_concrete
fill 102 100 275 103 101 275 minecraft:red_concrete
fill 102 100 317 103 101 317 minecraft:red_concrete
fill 104 100 275 105 101 275 minecraft:white_concrete
fill 104 100 317 105 101 317 minecraft:white_concrete
fill 106 100 275 107 101 275 minecraft:red_concrete
fill 106 100 317 107 101 317 minecraft:red_concrete
fill 108 100 275 109 101 275 minecraft:white_concrete
fill 108 100 317 109 101 317 minecraft:white_concrete
fill 110 100 275 111 101 275 minecraft:red_concrete
fill 110 100 317 111 101 317 minecraft:red_concrete
fill 112 100 275 113 101 275 minecraft:white_concrete
fill 112 100 317 113 101 317 minecraft:white_concrete
fill 113 100 285 113 101 285 minecraft:red_concrete
fill 114 100 275 115 101 275 minecraft:red_concrete
fill 114 100 317 115 101 317 minecraft:red_concrete
fill 116 100 275 117 101 275 minecraft:white_concrete
fill 116 100 317 117 101 317 minecraft:white_concrete
fill 118 100 275 119 101 275 minecraft:red_concrete
fill 118 100 317 119 101 317 minecraft:red_concrete
fill 120 100 275 121 101 275 minecraft:white_concrete
fill 120 100 317 121 101 317 minecraft:white_concrete
fill 122 100 275 123 101 275 minecraft:red_concrete
fill 122 100 317 123 101 317 minecraft:red_concrete
fill 124 100 275 125 101 275 minecraft:white_concrete
fill 124 100 290 124 101 290 minecraft:green_concrete
fill 124 100 317 125 101 317 minecraft:white_concrete
fill 126 100 275 127 101 275 minecraft:red_concrete
fill 126 100 317 127 101 317 minecraft:red_concrete
fill 128 100 275 129 101 275 minecraft:white_concrete
fill 128 100 317 129 101 317 minecraft:white_concrete
fill 130 100 275 131 101 275 minecraft:red_concrete
fill 130 100 317 131 101 317 minecraft:red_concrete
fill 132 100 275 133 101 275 minecraft:white_concrete
fill 132 100 317 133 101 317 minecraft:white_concrete
fill 134 100 275 135 101 275 minecraft:red_concrete
fill 134 100 317 135 101 317 minecraft:red_concrete
fill 136 100 276 136 101 276 minecraft:red_concrete
fill 136 100 277 136 101 278 minecraft:white_concrete
fill 136 100 279 136 101 280 minecraft:red_concrete
fill 136 100 281 136 101 282 minecraft:white_concrete
fill 136 100 283 136 101 284 minecraft:red_concrete
fill 136 100 285 136 101 286 minecraft:white_concrete
fill 136 100 287 136 101 288 minecraft:red_concrete
fill 136 100 289 136 101 290 minecraft:white_concrete
fill 136 100 291 136 101 292 minecraft:red_concrete
fill 136 100 293 136 101 294 minecraft:white_concrete
fill 136 100 295 136 101 296 minecraft:red_concrete
fill 136 100 297 136 101 298 minecraft:white_concrete
fill 136 100 299 136 101 300 minecraft:red_concrete
fill 136 100 301 136 101 302 minecraft:white_concrete
fill 136 100 303 136 101 304 minecraft:red_concrete
fill 136 100 305 136 101 306 minecraft:white_concrete
fill 136 100 307 136 101 308 minecraft:red_concrete
fill 136 100 309 136 101 310 minecraft:white_concrete
fill 136 100 311 136 101 312 minecraft:red_concrete
fill 136 100 313 136 101 314 minecraft:white_concrete
fill 136 100 315 136 101 316 minecraft:red_concrete
fill 136 100 317 136 101 317 minecraft:white_concrete
setblock 97 101 278 minecraft:light[level=15]
setblock 97 101 286 minecraft:light[level=15]
setblock 97 101 294 minecraft:light[level=15]
setblock 97 101 302 minecraft:light[level=15]
setblock 97 101 310 minecraft:light[level=15]
setblock 99 101 300 minecraft:yellow_concrete
setblock 105 101 278 minecraft:light[level=15]
setblock 105 101 286 minecraft:light[level=15]
setblock 105 101 294 minecraft:light[level=15]
setblock 105 101 302 minecraft:light[level=15]
setblock 105 101 310 minecraft:light[level=15]
setblock 113 101 278 minecraft:light[level=15]
setblock 113 101 286 minecraft:light[level=15]
setblock 113 101 294 minecraft:light[level=15]
setblock 113 101 302 minecraft:light[level=15]
setblock 113 101 310 minecraft:light[level=15]
setblock 121 101 278 minecraft:light[level=15]
setblock 121 101 286 minecraft:light[level=15]
setblock 121 101 294 minecraft:light[level=15]
setblock 121 101 302 minecraft:light[level=15]
setblock 121 101 310 minecraft:light[level=15]
fill 128 101 311 128 102 313 minecraft:yellow_concrete
setblock 129 101 278 minecraft:light[level=15]
setblock 129 101 286 minecraft:light[level=15]
setblock 129 101 294 minecraft:light[level=15]
setblock 129 101 302 minecraft:light[level=15]
fill 129 101 310 129 102 310 minecraft:yellow_concrete
fill 130 101 314 130 102 314 minecraft:yellow_concrete
fill 131 101 310 131 102 310 minecraft:yellow_concrete
fill 132 101 311 132 102 313 minecraft:yellow_concrete
fill 94 102 275 94 103 276 minecraft:white_concrete
fill 94 102 277 94 103 278 minecraft:red_concrete
fill 94 102 279 94 103 279 minecraft:white_concrete
setblock 94 102 280 minecraft:shroomlight
fill 94 102 281 94 103 282 minecraft:red_concrete
fill 94 102 283 94 103 284 minecraft:white_concrete
fill 94 102 285 94 103 286 minecraft:red_concrete
fill 94 102 287 94 103 287 minecraft:white_concrete
setblock 94 102 288 minecraft:shroomlight
fill 94 102 289 94 103 290 minecraft:red_concrete
fill 94 102 291 94 103 292 minecraft:white_concrete
fill 94 102 293 94 103 294 minecraft:red_concrete
fill 94 102 295 94 103 295 minecraft:white_concrete
setblock 94 102 296 minecraft:shroomlight
fill 94 102 297 94 103 298 minecraft:red_concrete
fill 94 102 299 94 103 300 minecraft:white_concrete
fill 94 102 301 94 103 302 minecraft:red_concrete
fill 94 102 303 94 103 303 minecraft:white_concrete
setblock 94 102 304 minecraft:shroomlight
fill 94 102 305 94 103 306 minecraft:red_concrete
fill 94 102 307 94 103 308 minecraft:white_concrete
fill 94 102 309 94 103 310 minecraft:red_concrete
fill 94 102 311 94 103 311 minecraft:white_concrete
setblock 94 102 312 minecraft:shroomlight
fill 94 102 313 94 103 314 minecraft:red_concrete
fill 94 102 315 94 103 316 minecraft:white_concrete
fill 95 102 275 95 103 275 minecraft:white_concrete
fill 95 102 317 95 103 317 minecraft:white_concrete
fill 96 102 275 97 103 275 minecraft:red_concrete
fill 96 102 317 96 103 317 minecraft:red_concrete
setblock 97 102 317 minecraft:shroomlight
fill 98 102 275 99 103 275 minecraft:white_concrete
fill 98 102 317 99 103 317 minecraft:white_concrete
fill 100 102 275 100 103 275 minecraft:red_concrete
fill 100 102 317 101 103 317 minecraft:red_concrete
setblock 101 102 275 minecraft:shroomlight
fill 102 102 275 103 103 275 minecraft:white_concrete
fill 102 102 317 103 103 317 minecraft:white_concrete
fill 104 102 275 105 103 275 minecraft:red_concrete
fill 104 102 317 104 103 317 minecraft:red_concrete
setblock 105 102 317 minecraft:shroomlight
fill 106 102 275 107 103 275 minecraft:white_concrete
fill 106 102 317 107 103 317 minecraft:white_concrete
fill 108 102 275 108 103 275 minecraft:red_concrete
fill 108 102 317 109 103 317 minecraft:red_concrete
setblock 109 102 275 minecraft:shroomlight
fill 110 102 275 111 103 275 minecraft:white_concrete
fill 110 102 317 111 103 317 minecraft:white_concrete
fill 112 102 275 113 103 275 minecraft:red_concrete
fill 112 102 317 112 103 317 minecraft:red_concrete
setblock 113 102 317 minecraft:shroomlight
fill 114 102 275 115 103 275 minecraft:white_concrete
fill 114 102 317 115 103 317 minecraft:white_concrete
fill 116 102 275 116 103 275 minecraft:red_concrete
fill 116 102 317 117 103 317 minecraft:red_concrete
setblock 117 102 275 minecraft:shroomlight
fill 118 102 275 119 103 275 minecraft:white_concrete
fill 118 102 317 119 103 317 minecraft:white_concrete
fill 120 102 275 121 103 275 minecraft:red_concrete
fill 120 102 317 120 103 317 minecraft:red_concrete
setblock 121 102 317 minecraft:shroomlight
fill 122 102 275 123 103 275 minecraft:white_concrete
fill 122 102 317 123 103 317 minecraft:white_concrete
fill 124 102 275 124 103 275 minecraft:red_concrete
fill 124 102 317 125 103 317 minecraft:red_concrete
setblock 125 102 275 minecraft:shroomlight
fill 126 102 275 127 103 275 minecraft:white_concrete
fill 126 102 317 127 103 317 minecraft:white_concrete
fill 128 102 275 129 103 275 minecraft:red_concrete
fill 128 102 317 128 103 317 minecraft:red_concrete
setblock 129 102 317 minecraft:shroomlight
fill 130 102 275 131 103 275 minecraft:white_concrete
fill 130 102 317 131 103 317 minecraft:white_concrete
fill 132 102 275 132 103 275 minecraft:red_concrete
fill 132 102 317 133 103 317 minecraft:red_concrete
setblock 133 102 275 minecraft:shroomlight
fill 134 102 275 135 103 275 minecraft:white_concrete
fill 134 102 317 135 103 317 minecraft:white_concrete
fill 136 102 276 136 103 276 minecraft:white_concrete
fill 136 102 277 136 103 278 minecraft:red_concrete
fill 136 102 279 136 103 279 minecraft:white_concrete
setblock 136 102 280 minecraft:shroomlight
fill 136 102 281 136 103 282 minecraft:red_concrete
fill 136 102 283 136 103 284 minecraft:white_concrete
fill 136 102 285 136 103 286 minecraft:red_concrete
fill 136 102 287 136 103 287 minecraft:white_concrete
setblock 136 102 288 minecraft:shroomlight
fill 136 102 289 136 103 290 minecraft:red_concrete
fill 136 102 291 136 103 292 minecraft:white_concrete
fill 136 102 293 136 103 294 minecraft:red_concrete
fill 136 102 295 136 103 295 minecraft:white_concrete
setblock 136 102 296 minecraft:shroomlight
fill 136 102 297 136 103 298 minecraft:red_concrete
fill 136 102 299 136 103 300 minecraft:white_concrete
fill 136 102 301 136 103 302 minecraft:red_concrete
fill 136 102 303 136 103 303 minecraft:white_concrete
setblock 136 102 304 minecraft:shroomlight
fill 136 102 305 136 103 306 minecraft:red_concrete
fill 136 102 307 136 103 308 minecraft:white_concrete
fill 136 102 309 136 103 310 minecraft:red_concrete
fill 136 102 311 136 103 311 minecraft:white_concrete
setblock 136 102 312 minecraft:shroomlight
fill 136 102 313 136 103 314 minecraft:red_concrete
fill 136 102 315 136 103 316 minecraft:white_concrete
fill 136 102 317 136 103 317 minecraft:red_concrete
setblock 94 103 280 minecraft:white_concrete
setblock 94 103 288 minecraft:white_concrete
setblock 94 103 296 minecraft:white_concrete
setblock 94 103 304 minecraft:white_concrete
setblock 94 103 312 minecraft:white_concrete
setblock 97 103 317 minecraft:red_concrete
setblock 101 103 275 minecraft:red_concrete
setblock 105 103 317 minecraft:red_concrete
setblock 109 103 275 minecraft:red_concrete
setblock 110 103 311 minecraft:iron_block
setblock 111 103 310 minecraft:iron_block
fill 111 103 311 113 103 311 minecraft:black_concrete
setblock 111 103 312 minecraft:iron_block
setblock 112 103 309 minecraft:iron_block
setblock 112 103 310 minecraft:black_concrete
setblock 112 103 312 minecraft:black_concrete
setblock 112 103 313 minecraft:iron_block
setblock 113 103 310 minecraft:iron_block
setblock 113 103 312 minecraft:iron_block
setblock 113 103 317 minecraft:red_concrete
setblock 114 103 311 minecraft:iron_block
setblock 117 103 275 minecraft:red_concrete
setblock 121 103 317 minecraft:red_concrete
setblock 125 103 275 minecraft:red_concrete
setblock 129 103 317 minecraft:red_concrete
setblock 133 103 275 minecraft:red_concrete
setblock 136 103 280 minecraft:white_concrete
setblock 136 103 288 minecraft:white_concrete
setblock 136 103 296 minecraft:white_concrete
setblock 136 103 304 minecraft:white_concrete
setblock 136 103 312 minecraft:white_concrete
fill 94 104 275 94 105 276 minecraft:red_concrete
fill 94 104 277 94 105 278 minecraft:white_concrete
fill 94 104 279 94 105 280 minecraft:red_concrete
fill 94 104 281 94 105 282 minecraft:white_concrete
fill 94 104 283 94 105 284 minecraft:red_concrete
fill 94 104 285 94 105 286 minecraft:white_concrete
fill 94 104 287 94 105 288 minecraft:red_concrete
fill 94 104 289 94 105 290 minecraft:white_concrete
fill 94 104 291 94 105 292 minecraft:red_concrete
fill 94 104 293 94 105 294 minecraft:white_concrete
fill 94 104 295 94 105 296 minecraft:red_concrete
fill 94 104 297 94 105 298 minecraft:white_concrete
fill 94 104 299 94 105 300 minecraft:red_concrete
fill 94 104 301 94 105 302 minecraft:white_concrete
fill 94 104 303 94 105 304 minecraft:red_concrete
fill 94 104 305 94 105 306 minecraft:white_concrete
fill 94 104 307 94 105 308 minecraft:red_concrete
fill 94 104 309 94 105 310 minecraft:white_concrete
fill 94 104 311 94 105 312 minecraft:red_concrete
fill 94 104 313 94 105 314 minecraft:white_concrete
fill 94 104 315 94 105 316 minecraft:red_concrete
fill 95 104 275 95 105 275 minecraft:red_concrete
fill 95 104 317 95 105 317 minecraft:red_concrete
fill 96 104 275 97 105 275 minecraft:white_concrete
fill 96 104 317 97 105 317 minecraft:white_concrete
fill 98 104 275 99 105 275 minecraft:red_concrete
fill 98 104 317 99 105 317 minecraft:red_concrete
fill 100 104 275 101 105 275 minecraft:white_concrete
fill 100 104 317 101 105 317 minecraft:white_concrete
fill 102 104 275 103 105 275 minecraft:red_concrete
fill 102 104 317 103 105 317 minecraft:red_concrete
fill 104 104 275 105 105 275 minecraft:white_concrete
fill 104 104 317 105 105 317 minecraft:white_concrete
fill 106 104 275 107 105 275 minecraft:red_concrete
fill 106 104 317 107 105 317 minecraft:red_concrete
fill 108 104 275 109 105 275 minecraft:white_concrete
fill 108 104 317 109 105 317 minecraft:white_concrete
fill 110 104 275 111 105 275 minecraft:red_concrete
fill 110 104 317 111 105 317 minecraft:red_concrete
fill 112 104 275 113 105 275 minecraft:white_concrete
fill 112 104 317 113 105 317 minecraft:white_concrete
fill 114 104 275 115 105 275 minecraft:red_concrete
fill 114 104 317 115 105 317 minecraft:red_concrete
fill 116 104 275 117 105 275 minecraft:white_concrete
fill 116 104 317 117 105 317 minecraft:white_concrete
fill 118 104 275 119 105 275 minecraft:red_concrete
fill 118 104 317 119 105 317 minecraft:red_concrete
fill 120 104 275 121 105 275 minecraft:white_concrete
fill 120 104 317 121 105 317 minecraft:white_concrete
fill 122 104 275 123 105 275 minecraft:red_concrete
fill 122 104 317 123 105 317 minecraft:red_concrete
fill 124 104 275 125 105 275 minecraft:white_concrete
fill 124 104 317 125 105 317 minecraft:white_concrete
fill 126 104 275 127 105 275 minecraft:red_concrete
fill 126 104 317 127 105 317 minecraft:red_concrete
fill 128 104 275 129 105 275 minecraft:white_concrete
fill 128 104 317 129 105 317 minecraft:white_concrete
fill 130 104 275 131 105 275 minecraft:red_concrete
fill 130 104 317 131 105 317 minecraft:red_concrete
fill 132 104 275 133 105 275 minecraft:white_concrete
fill 132 104 317 133 105 317 minecraft:white_concrete
fill 134 104 275 135 105 275 minecraft:red_concrete
fill 134 104 317 135 105 317 minecraft:red_concrete
fill 136 104 276 136 105 276 minecraft:red_concrete
fill 136 104 277 136 105 278 minecraft:white_concrete
fill 136 104 279 136 105 280 minecraft:red_concrete
fill 136 104 281 136 105 282 minecraft:white_concrete
fill 136 104 283 136 105 284 minecraft:red_concrete
fill 136 104 285 136 105 286 minecraft:white_concrete
fill 136 104 287 136 105 288 minecraft:red_concrete
fill 136 104 289 136 105 290 minecraft:white_concrete
fill 136 104 291 136 105 292 minecraft:red_concrete
fill 136 104 293 136 105 294 minecraft:white_concrete
fill 136 104 295 136 105 296 minecraft:red_concrete
fill 136 104 297 136 105 298 minecraft:white_concrete
fill 136 104 299 136 105 300 minecraft:red_concrete
fill 136 104 301 136 105 302 minecraft:white_concrete
fill 136 104 303 136 105 304 minecraft:red_concrete
fill 136 104 305 136 105 306 minecraft:white_concrete
fill 136 104 307 136 105 308 minecraft:red_concrete
fill 136 104 309 136 105 310 minecraft:white_concrete
fill 136 104 311 136 105 312 minecraft:red_concrete
fill 136 104 313 136 105 314 minecraft:white_concrete
fill 136 104 315 136 105 316 minecraft:red_concrete
fill 136 104 317 136 105 317 minecraft:white_concrete
setblock 97 105 278 minecraft:light[level=12]
setblock 97 105 285 minecraft:light[level=12]
setblock 97 105 292 minecraft:light[level=12]
setblock 97 105 299 minecraft:light[level=12]
setblock 97 105 306 minecraft:light[level=12]
setblock 97 105 313 minecraft:light[level=12]
setblock 104 105 278 minecraft:light[level=12]
setblock 104 105 285 minecraft:light[level=12]
setblock 104 105 292 minecraft:light[level=12]
setblock 104 105 299 minecraft:light[level=12]
setblock 104 105 306 minecraft:light[level=12]
setblock 104 105 313 minecraft:light[level=12]
setblock 111 105 278 minecraft:light[level=12]
setblock 111 105 285 minecraft:light[level=12]
setblock 111 105 292 minecraft:light[level=12]
setblock 111 105 299 minecraft:light[level=12]
setblock 111 105 306 minecraft:light[level=12]
setblock 111 105 313 minecraft:light[level=12]
setblock 118 105 278 minecraft:light[level=12]
setblock 118 105 285 minecraft:light[level=12]
setblock 118 105 292 minecraft:light[level=12]
setblock 118 105 299 minecraft:light[level=12]
setblock 118 105 306 minecraft:light[level=12]
setblock 118 105 313 minecraft:light[level=12]
setblock 125 105 278 minecraft:light[level=12]
setblock 125 105 285 minecraft:light[level=12]
setblock 125 105 292 minecraft:light[level=12]
setblock 125 105 299 minecraft:light[level=12]
setblock 125 105 306 minecraft:light[level=12]
setblock 125 105 313 minecraft:light[level=12]
setblock 132 105 278 minecraft:light[level=12]
setblock 132 105 285 minecraft:light[level=12]
setblock 132 105 292 minecraft:light[level=12]
setblock 132 105 299 minecraft:light[level=12]
setblock 132 105 306 minecraft:light[level=12]
setblock 132 105 313 minecraft:light[level=12]
fill 94 106 275 94 107 276 minecraft:white_concrete
fill 94 106 277 94 107 278 minecraft:red_concrete
fill 94 106 279 94 107 280 minecraft:white_concrete
fill 94 106 281 94 107 282 minecraft:red_concrete
fill 94 106 283 94 107 284 minecraft:white_concrete
fill 94 106 285 94 107 286 minecraft:red_concrete
fill 94 106 287 94 107 288 minecraft:white_concrete
fill 94 106 289 94 107 290 minecraft:red_concrete
fill 94 106 291 94 107 292 minecraft:white_concrete
fill 94 106 293 94 107 294 minecraft:red_concrete
fill 94 106 295 94 107 296 minecraft:white_concrete
fill 94 106 297 94 107 298 minecraft:red_concrete
fill 94 106 299 94 107 300 minecraft:white_concrete
fill 94 106 301 94 107 302 minecraft:red_concrete
fill 94 106 303 94 107 304 minecraft:white_concrete
fill 94 106 305 94 107 306 minecraft:red_concrete
fill 94 106 307 94 107 308 minecraft:white_concrete
fill 94 106 309 94 107 310 minecraft:red_concrete
fill 94 106 311 94 107 312 minecraft:white_concrete
fill 94 106 313 94 107 314 minecraft:red_concrete
fill 94 106 315 94 107 316 minecraft:white_concrete
fill 95 106 275 95 107 275 minecraft:white_concrete
fill 95 106 317 95 107 317 minecraft:white_concrete
fill 96 106 275 97 107 275 minecraft:red_concrete
fill 96 106 317 97 107 317 minecraft:red_concrete
fill 98 106 275 99 107 275 minecraft:white_concrete
fill 98 106 317 99 107 317 minecraft:white_concrete
fill 100 106 275 101 107 275 minecraft:red_concrete
fill 100 106 317 101 107 317 minecraft:red_concrete
fill 102 106 275 103 107 275 minecraft:white_concrete
fill 102 106 317 103 107 317 minecraft:white_concrete
fill 104 106 275 105 107 275 minecraft:red_concrete
fill 104 106 317 105 107 317 minecraft:red_concrete
fill 106 106 275 107 107 275 minecraft:white_concrete
fill 106 106 317 107 107 317 minecraft:white_concrete
fill 108 106 275 109 107 275 minecraft:red_concrete
fill 108 106 317 109 107 317 minecraft:red_concrete
fill 110 106 275 111 107 275 minecraft:white_concrete
fill 110 106 317 111 107 317 minecraft:white_concrete
fill 112 106 275 113 107 275 minecraft:red_concrete
fill 112 106 317 113 107 317 minecraft:red_concrete
fill 114 106 275 115 107 275 minecraft:white_concrete
fill 114 106 317 115 107 317 minecraft:white_concrete
fill 116 106 275 117 107 275 minecraft:red_concrete
fill 116 106 317 117 107 317 minecraft:red_concrete
fill 118 106 275 119 107 275 minecraft:white_concrete
fill 118 106 317 119 107 317 minecraft:white_concrete
fill 120 106 275 121 107 275 minecraft:red_concrete
fill 120 106 317 121 107 317 minecraft:red_concrete
fill 122 106 275 123 107 275 minecraft:white_concrete
fill 122 106 317 123 107 317 minecraft:white_concrete
fill 124 106 275 125 107 275 minecraft:red_concrete
fill 124 106 317 125 107 317 minecraft:red_concrete
fill 126 106 275 127 107 275 minecraft:white_concrete
fill 126 106 317 127 107 317 minecraft:white_concrete
fill 128 106 275 129 107 275 minecraft:red_concrete
fill 128 106 317 129 107 317 minecraft:red_concrete
fill 130 106 275 131 107 275 minecraft:white_concrete
fill 130 106 317 131 107 317 minecraft:white_concrete
fill 132 106 275 133 107 275 minecraft:red_concrete
fill 132 106 317 133 107 317 minecraft:red_concrete
fill 134 106 275 135 107 275 minecraft:white_concrete
fill 134 106 317 135 107 317 minecraft:white_concrete
fill 136 106 276 136 107 276 minecraft:white_concrete
fill 136 106 277 136 107 278 minecraft:red_concrete
fill 136 106 279 136 107 280 minecraft:white_concrete
fill 136 106 281 136 107 282 minecraft:red_concrete
fill 136 106 283 136 107 284 minecraft:white_concrete
fill 136 106 285 136 107 286 minecraft:red_concrete
fill 136 106 287 136 107 288 minecraft:white_concrete
fill 136 106 289 136 107 290 minecraft:red_concrete
fill 136 106 291 136 107 292 minecraft:white_concrete
fill 136 106 293 136 107 294 minecraft:red_concrete
fill 136 106 295 136 107 296 minecraft:white_concrete
fill 136 106 297 136 107 298 minecraft:red_concrete
fill 136 106 299 136 107 300 minecraft:white_concrete
fill 136 106 301 136 107 302 minecraft:red_concrete
fill 136 106 303 136 107 304 minecraft:white_concrete
fill 136 106 305 136 107 306 minecraft:red_concrete
fill 136 106 307 136 107 308 minecraft:white_concrete
fill 136 106 309 136 107 310 minecraft:red_concrete
fill 136 106 311 136 107 312 minecraft:white_concrete
fill 136 106 313 136 107 314 minecraft:red_concrete
fill 136 106 315 136 107 316 minecraft:white_concrete
fill 136 106 317 136 107 317 minecraft:red_concrete
fill 94 108 275 94 109 276 minecraft:red_concrete
fill 94 108 277 94 109 278 minecraft:white_concrete
fill 94 108 279 94 109 280 minecraft:red_concrete
fill 94 108 281 94 109 282 minecraft:white_concrete
fill 94 108 283 94 109 284 minecraft:red_concrete
fill 94 108 285 94 109 286 minecraft:white_concrete
fill 94 108 287 94 109 288 minecraft:red_concrete
fill 94 108 289 94 109 290 minecraft:white_concrete
fill 94 108 291 94 109 292 minecraft:red_concrete
fill 94 108 293 94 109 294 minecraft:white_concrete
fill 94 108 295 94 109 296 minecraft:red_concrete
fill 94 108 297 94 109 298 minecraft:white_concrete
fill 94 108 299 94 109 300 minecraft:red_concrete
fill 94 108 301 94 109 302 minecraft:white_concrete
fill 94 108 303 94 109 304 minecraft:red_concrete
fill 94 108 305 94 109 306 minecraft:white_concrete
fill 94 108 307 94 109 308 minecraft:red_concrete
fill 94 108 309 94 109 310 minecraft:white_concrete
fill 94 108 311 94 109 312 minecraft:red_concrete
fill 94 108 313 94 109 314 minecraft:white_concrete
fill 94 108 315 94 109 316 minecraft:red_concrete
fill 95 108 275 95 109 275 minecraft:red_concrete
fill 95 108 284 113 108 308 minecraft:red_terracotta
fill 95 108 317 95 109 317 minecraft:red_concrete
fill 96 108 275 97 109 275 minecraft:white_concrete
fill 96 108 283 134 108 283 minecraft:red_terracotta
fill 96 108 309 134 108 309 minecraft:red_terracotta
fill 96 108 317 97 109 317 minecraft:white_concrete
fill 97 108 281 133 108 282 minecraft:red_terracotta
fill 97 108 310 133 108 311 minecraft:red_terracotta
fill 98 108 275 99 109 275 minecraft:red_concrete
fill 98 108 280 132 108 280 minecraft:red_terracotta
fill 98 108 312 132 108 312 minecraft:red_terracotta
fill 98 108 317 99 109 317 minecraft:red_concrete
fill 99 108 279 131 108 279 minecraft:red_terracotta
fill 99 108 313 131 108 313 minecraft:red_terracotta
fill 100 108 275 101 109 275 minecraft:white_concrete
fill 100 108 278 130 108 278 minecraft:red_terracotta
fill 100 108 314 130 108 314 minecraft:red_terracotta
fill 100 108 317 101 109 317 minecraft:white_concrete
fill 102 108 275 103 109 275 minecraft:red_concrete
fill 102 108 277 128 108 277 minecraft:red_terracotta
fill 102 108 315 128 108 315 minecraft:red_terracotta
fill 102 108 317 103 109 317 minecraft:red_concrete
fill 103 108 276 127 108 276 minecraft:red_terracotta
fill 103 108 316 127 108 316 minecraft:red_terracotta
fill 104 108 275 105 109 275 minecraft:white_concrete
fill 104 108 317 105 109 317 minecraft:white_concrete
fill 106 108 275 107 109 275 minecraft:red_concrete
fill 106 108 317 107 109 317 minecraft:red_concrete
fill 108 108 275 109 109 275 minecraft:white_concrete
fill 108 108 317 109 109 317 minecraft:white_concrete
fill 110 108 275 111 109 275 minecraft:red_concrete
fill 110 108 317 111 109 317 minecraft:red_concrete
fill 112 108 275 113 109 275 minecraft:white_concrete
fill 112 108 317 113 109 317 minecraft:white_concrete
fill 114 108 275 115 109 275 minecraft:red_concrete
fill 114 108 284 114 108 292 minecraft:red_terracotta
setblock 114 108 293 minecraft:shroomlight
fill 114 108 295 114 108 296 minecraft:shroomlight
fill 114 108 297 114 108 308 minecraft:red_terracotta
fill 114 108 317 115 109 317 minecraft:red_concrete
fill 115 108 284 115 108 291 minecraft:red_terracotta
fill 115 108 297 116 108 297 minecraft:shroomlight
fill 115 108 298 135 108 308 minecraft:red_terracotta
fill 116 108 275 117 109 275 minecraft:white_concrete
fill 116 108 284 135 108 290 minecraft:red_terracotta
setblock 116 108 291 minecraft:shroomlight
fill 116 108 317 117 109 317 minecraft:white_concrete
fill 118 108 275 119 109 275 minecraft:red_concrete
setblock 118 108 291 minecraft:shroomlight
setblock 118 108 297 minecraft:shroomlight
fill 118 108 317 119 109 317 minecraft:red_concrete
fill 119 108 291 135 108 291 minecraft:red_terracotta
fill 119 108 297 135 108 297 minecraft:red_terracotta
fill 120 108 275 121 109 275 minecraft:white_concrete
fill 120 108 292 135 108 292 minecraft:red_terracotta
setblock 120 108 293 minecraft:shroomlight
setblock 120 108 295 minecraft:shroomlight
fill 120 108 296 135 108 296 minecraft:red_terracotta
fill 120 108 317 121 109 317 minecraft:white_concrete
fill 121 108 293 135 108 295 minecraft:red_terracotta
fill 122 108 275 123 109 275 minecraft:red_concrete
fill 122 108 317 123 109 317 minecraft:red_concrete
fill 124 108 275 125 109 275 minecraft:white_concrete
fill 124 108 317 125 109 317 minecraft:white_concrete
fill 126 108 275 127 109 275 minecraft:red_concrete
fill 126 108 317 127 109 317 minecraft:red_concrete
fill 128 108 275 129 109 275 minecraft:white_concrete
fill 128 108 317 129 109 317 minecraft:white_concrete
fill 130 108 275 131 109 275 minecraft:red_concrete
fill 130 108 317 131 109 317 minecraft:red_concrete
fill 132 108 275 133 109 275 minecraft:white_concrete
fill 132 108 317 133 109 317 minecraft:white_concrete
fill 134 108 275 135 109 275 minecraft:red_concrete
fill 134 108 317 135 109 317 minecraft:red_concrete
fill 136 108 276 136 109 276 minecraft:red_concrete
fill 136 108 277 136 109 278 minecraft:white_concrete
fill 136 108 279 136 109 280 minecraft:red_concrete
fill 136 108 281 136 109 282 minecraft:white_concrete
fill 136 108 283 136 109 284 minecraft:red_concrete
fill 136 108 285 136 109 286 minecraft:white_concrete
fill 136 108 287 136 109 288 minecraft:red_concrete
fill 136 108 289 136 109 290 minecraft:white_concrete
fill 136 108 291 136 109 292 minecraft:red_concrete
fill 136 108 293 136 109 294 minecraft:white_concrete
fill 136 108 295 136 109 296 minecraft:red_concrete
fill 136 108 297 136 109 298 minecraft:white_concrete
fill 136 108 299 136 109 300 minecraft:red_concrete
fill 136 108 301 136 109 302 minecraft:white_concrete
fill 136 108 303 136 109 304 minecraft:red_concrete
fill 136 108 305 136 109 306 minecraft:white_concrete
fill 136 108 307 136 109 308 minecraft:red_concrete
fill 136 108 309 136 109 310 minecraft:white_concrete
fill 136 108 311 136 109 312 minecraft:red_concrete
fill 136 108 313 136 109 314 minecraft:white_concrete
fill 136 108 315 136 109 316 minecraft:red_concrete
fill 136 108 317 136 109 317 minecraft:white_concrete
fill 95 109 276 95 109 284 minecraft:bricks
fill 95 109 285 95 109 307 minecraft:red_terracotta
fill 95 109 308 95 109 316 minecraft:bricks
fill 96 109 276 96 109 282 minecraft:bricks
fill 96 109 283 96 109 284 minecraft:red_terracotta
fill 96 109 285 112 109 307 minecraft:bricks
fill 96 109 308 96 109 309 minecraft:red_terracotta
fill 96 109 310 96 109 316 minecraft:bricks
fill 97 109 276 97 109 281 minecraft:bricks
setblock 97 109 282 minecraft:red_terracotta
fill 97 109 283 133 109 284 minecraft:bricks
fill 97 109 308 133 109 309 minecraft:bricks
setblock 97 109 310 minecraft:red_terracotta
fill 97 109 311 97 109 316 minecraft:bricks
fill 98 109 276 98 109 280 minecraft:bricks
setblock 98 109 281 minecraft:red_terracotta
fill 98 109 282 132 109 282 minecraft:bricks
fill 98 109 310 132 109 310 minecraft:bricks
setblock 98 109 311 minecraft:red_terracotta
fill 98 109 312 98 109 316 minecraft:bricks
fill 99 109 276 99 109 279 minecraft:bricks
setblock 99 109 280 minecraft:red_terracotta
fill 99 109 281 131 109 281 minecraft:bricks
fill 99 109 311 131 109 311 minecraft:bricks
setblock 99 109 312 minecraft:red_terracotta
fill 99 109 313 99 109 316 minecraft:bricks
fill 100 109 276 100 109 278 minecraft:bricks
setblock 100 109 279 minecraft:red_terracotta
fill 100 109 280 130 109 280 minecraft:bricks
fill 100 109 312 130 109 312 minecraft:bricks
setblock 100 109 313 minecraft:red_terracotta
fill 100 109 314 100 109 316 minecraft:bricks
fill 101 109 276 101 109 277 minecraft:bricks
setblock 101 109 278 minecraft:red_terracotta
fill 101 109 279 129 109 279 minecraft:bricks
fill 101 109 313 129 109 313 minecraft:bricks
setblock 101 109 314 minecraft:red_terracotta
fill 101 109 315 101 109 316 minecraft:bricks
fill 102 109 276 103 109 276 minecraft:bricks
fill 102 109 277 103 109 277 minecraft:red_terracotta
fill 102 109 278 128 109 278 minecraft:bricks
fill 102 109 314 128 109 314 minecraft:bricks
fill 102 109 315 103 109 315 minecraft:red_terracotta
fill 102 109 316 103 109 316 minecraft:bricks
fill 104 109 276 126 109 276 minecraft:red_terracotta
fill 104 109 277 126 109 277 minecraft:bricks
fill 104 109 315 126 109 315 minecraft:bricks
fill 104 109 316 126 109 316 minecraft:red_terracotta
fill 113 109 285 113 109 292 minecraft:bricks
fill 113 109 293 113 109 295 minecraft:ochre_froglight
fill 113 109 296 113 110 296 minecraft:magma_block
fill 113 109 297 113 109 307 minecraft:bricks
fill 114 109 285 115 109 290 minecraft:bricks
fill 114 109 291 114 109 293 minecraft:ochre_froglight
fill 114 109 295 114 109 297 minecraft:ochre_froglight
fill 114 109 298 114 109 307 minecraft:bricks
fill 115 109 291 116 109 291 minecraft:ochre_froglight
fill 115 109 297 116 109 297 minecraft:ochre_froglight
fill 115 109 298 115 110 298 minecraft:magma_block
fill 115 109 299 134 109 307 minecraft:bricks
fill 116 109 285 134 109 289 minecraft:bricks
fill 116 109 290 118 109 290 minecraft:ochre_froglight
fill 116 109 298 118 109 298 minecraft:ochre_froglight
fill 118 109 291 120 109 291 minecraft:ochre_froglight
fill 118 109 297 120 109 297 minecraft:ochre_froglight
fill 119 109 290 134 109 290 minecraft:bricks
fill 119 109 298 134 109 298 minecraft:bricks
fill 120 109 292 120 109 293 minecraft:ochre_froglight
fill 120 109 295 120 109 296 minecraft:ochre_froglight
fill 121 109 291 134 109 292 minecraft:bricks
fill 121 109 293 121 109 295 minecraft:ochre_froglight
fill 121 109 296 134 109 297 minecraft:bricks
fill 122 109 293 134 110 295 minecraft:bricks
fill 127 109 276 135 109 276 minecraft:bricks
fill 127 109 277 128 109 277 minecraft:red_terracotta
fill 127 109 315 128 109 315 minecraft:red_terracotta
fill 127 109 316 135 109 316 minecraft:bricks
fill 129 109 277 135 109 277 minecraft:bricks
setblock 129 109 278 minecraft:red_terracotta
setblock 129 109 314 minecraft:red_terracotta
fill 129 109 315 135 109 315 minecraft:bricks
fill 130 109 278 135 109 278 minecraft:bricks
setblock 130 109 279 minecraft:red_terracotta
setblock 130 109 313 minecraft:red_terracotta
fill 130 109 314 135 109 314 minecraft:bricks
fill 131 109 279 135 109 279 minecraft:bricks
setblock 131 109 280 minecraft:red_terracotta
setblock 131 109 312 minecraft:red_terracotta
fill 131 109 313 135 109 313 minecraft:bricks
fill 132 109 280 135 109 280 minecraft:bricks
setblock 132 109 281 minecraft:red_terracotta
setblock 132 109 311 minecraft:red_terracotta
fill 132 109 312 135 109 312 minecraft:bricks
fill 133 109 281 135 109 281 minecraft:bricks
setblock 133 109 282 minecraft:red_terracotta
setblock 133 109 310 minecraft:red_terracotta
fill 133 109 311 135 109 311 minecraft:bricks
fill 134 109 282 135 109 282 minecraft:bricks
fill 134 109 283 134 109 284 minecraft:red_terracotta
fill 134 109 308 134 109 309 minecraft:red_terracotta
fill 134 109 310 135 109 310 minecraft:bricks
fill 135 109 283 135 109 284 minecraft:bricks
fill 135 109 285 135 109 307 minecraft:red_terracotta
fill 135 109 308 135 109 309 minecraft:bricks
fill 94 110 275 94 111 276 minecraft:white_concrete
fill 94 110 277 94 111 278 minecraft:red_concrete
fill 94 110 279 94 111 280 minecraft:white_concrete
fill 94 110 281 94 111 282 minecraft:red_concrete
fill 94 110 283 94 111 284 minecraft:white_concrete
fill 94 110 285 94 111 286 minecraft:red_concrete
fill 94 110 287 94 111 288 minecraft:white_concrete
fill 94 110 289 94 111 290 minecraft:red_concrete
fill 94 110 291 94 111 292 minecraft:white_concrete
fill 94 110 293 94 111 294 minecraft:red_concrete
fill 94 110 295 94 111 296 minecraft:white_concrete
fill 94 110 297 94 111 298 minecraft:red_concrete
fill 94 110 299 94 111 300 minecraft:white_concrete
fill 94 110 301 94 111 302 minecraft:red_concrete
fill 94 110 303 94 111 304 minecraft:white_concrete
fill 94 110 305 94 111 306 minecraft:red_concrete
fill 94 110 307 94 111 308 minecraft:white_concrete
fill 94 110 309 94 111 310 minecraft:red_concrete
fill 94 110 311 94 111 312 minecraft:white_concrete
fill 94 110 313 94 111 314 minecraft:red_concrete
fill 94 110 315 94 111 316 minecraft:white_concrete
fill 95 110 275 95 111 275 minecraft:white_concrete
fill 95 110 286 95 110 306 minecraft:red_terracotta
fill 95 110 317 95 111 317 minecraft:white_concrete
fill 96 110 275 97 111 275 minecraft:red_concrete
fill 96 110 284 96 110 285 minecraft:red_terracotta
fill 96 110 286 111 110 306 minecraft:bricks
fill 96 110 307 96 110 308 minecraft:red_terracotta
fill 96 110 317 97 111 317 minecraft:red_concrete
setblock 97 110 283 minecraft:red_terracotta
fill 97 110 284 133 110 285 minecraft:bricks
fill 97 110 307 133 110 308 minecraft:bricks
setblock 97 110 309 minecraft:red_terracotta
fill 98 110 275 99 111 275 minecraft:white_concrete
fill 98 110 282 98 111 282 minecraft:red_terracotta
fill 98 110 283 132 110 283 minecraft:bricks
fill 98 110 309 132 110 309 minecraft:bricks
fill 98 110 310 98 111 310 minecraft:red_terracotta
fill 98 110 317 99 111 317 minecraft:white_concrete
fill 99 110 281 99 111 281 minecraft:red_terracotta
fill 99 110 282 131 111 282 minecraft:bricks
fill 99 110 310 131 111 310 minecraft:bricks
fill 99 110 311 99 111 311 minecraft:red_terracotta
fill 100 110 275 101 111 275 minecraft:red_concrete
fill 100 110 280 100 111 280 minecraft:red_terracotta
fill 100 110 281 130 111 281 minecraft:bricks
fill 100 110 311 130 111 311 minecraft:bricks
fill 100 110 312 100 111 312 minecraft:red_terracotta
fill 100 110 317 101 111 317 minecraft:red_concrete
fill 101 110 279 101 111 279 minecraft:red_terracotta
fill 101 110 280 129 111 280 minecraft:bricks
fill 101 110 312 129 111 312 minecraft:bricks
fill 101 110 313 101 111 313 minecraft:red_terracotta
fill 102 110 275 103 111 275 minecraft:white_concrete
setblock 102 110 278 minecraft:red_terracotta
fill 102 110 279 128 110 279 minecraft:bricks
fill 102 110 313 128 110 313 minecraft:bricks
setblock 102 110 314 minecraft:red_terracotta
fill 102 110 317 103 111 317 minecraft:white_concrete
fill 103 110 277 104 110 277 minecraft:red_terracotta
fill 103 110 278 127 110 278 minecraft:bricks
fill 103 110 314 127 110 314 minecraft:bricks
fill 103 110 315 104 110 315 minecraft:red_terracotta
fill 104 110 275 105 111 275 minecraft:red_concrete
fill 104 110 317 105 111 317 minecraft:red_concrete
fill 105 110 276 125 110 276 minecraft:red_terracotta
fill 105 110 277 125 110 277 minecraft:bricks
fill 105 110 315 125 110 315 minecraft:bricks
fill 105 110 316 125 110 316 minecraft:red_terracotta
fill 106 110 275 107 111 275 minecraft:white_concrete
fill 106 110 317 107 111 317 minecraft:white_concrete
fill 108 110 275 109 111 275 minecraft:red_concrete
fill 108 110 317 109 111 317 minecraft:red_concrete
fill 110 110 275 111 111 275 minecraft:white_concrete
fill 110 110 317 111 111 317 minecraft:white_concrete
fill 112 110 275 113 111 275 minecraft:red_concrete
fill 112 110 286 112 110 292 minecraft:bricks
fill 112 110 293 112 110 295 minecraft:magma_block
fill 112 110 296 112 110 306 minecraft:bricks
fill 112 110 317 113 111 317 minecraft:red_concrete
fill 113 110 286 113 110 291 minecraft:bricks
setblock 113 110 292 minecraft:magma_block
setblock 113 110 297 minecraft:magma_block
fill 113 110 298 113 110 306 minecraft:bricks
fill 114 110 275 115 111 275 minecraft:white_concrete
fill 114 110 286 114 110 290 minecraft:bricks
setblock 114 110 291 minecraft:magma_block
setblock 114 110 298 minecraft:magma_block
fill 114 110 299 115 110 306 minecraft:bricks
fill 114 110 317 115 111 317 minecraft:white_concrete
fill 115 110 286 134 110 289 minecraft:bricks
fill 115 110 290 119 110 290 minecraft:magma_block
fill 116 110 275 117 111 275 minecraft:red_concrete
fill 116 110 299 118 110 299 minecraft:magma_block
fill 116 110 300 134 110 306 minecraft:bricks
fill 116 110 317 117 111 317 minecraft:red_concrete
fill 118 110 275 119 111 275 minecraft:white_concrete
fill 118 110 317 119 111 317 minecraft:white_concrete
setblock 119 110 298 minecraft:magma_block
fill 119 110 299 134 110 299 minecraft:bricks
fill 120 110 275 121 111 275 minecraft:red_concrete
fill 120 110 290 134 111 290 minecraft:bricks
setblock 120 110 291 minecraft:magma_block
setblock 120 110 297 minecraft:magma_block
fill 120 110 298 134 110 298 minecraft:bricks
fill 120 110 317 121 111 317 minecraft:red_concrete
fill 121 110 291 134 111 291 minecraft:bricks
fill 121 110 292 121 110 296 minecraft:magma_block
fill 121 110 297 134 110 297 minecraft:bricks
fill 122 110 275 123 111 275 minecraft:white_concrete
fill 122 110 292 134 111 292 minecraft:bricks
fill 122 110 296 134 110 296 minecraft:bricks
fill 122 110 317 123 111 317 minecraft:white_concrete
fill 124 110 275 125 111 275 minecraft:red_concrete
fill 124 110 317 125 111 317 minecraft:red_concrete
fill 126 110 275 127 111 275 minecraft:white_concrete
fill 126 110 277 127 110 277 minecraft:red_terracotta
fill 126 110 315 127 110 315 minecraft:red_terracotta
fill 126 110 317 127 111 317 minecraft:white_concrete
fill 128 110 275 129 111 275 minecraft:red_concrete
setblock 128 110 278 minecraft:red_terracotta
setblock 128 110 314 minecraft:red_terracotta
fill 128 110 317 129 111 317 minecraft:red_concrete
fill 129 110 279 129 111 279 minecraft:red_terracotta
fill 129 110 313 129 111 313 minecraft:red_terracotta
fill 130 110 275 131 111 275 minecraft:white_concrete
fill 130 110 280 130 111 280 minecraft:red_terracotta
fill 130 110 312 130 111 312 minecraft:red_terracotta
fill 130 110 317 131 111 317 minecraft:white_concrete
fill 131 110 281 131 111 281 minecraft:red_terracotta
fill 131 110 311 131 111 311 minecraft:red_terracotta
fill 132 110 275 133 111 275 minecraft:red_concrete
fill 132 110 282 132 111 282 minecraft:red_terracotta
fill 132 110 310 132 111 310 minecraft:red_terracotta
fill 132 110 317 133 111 317 minecraft:red_concrete
setblock 133 110 283 minecraft:red_terracotta
setblock 133 110 309 minecraft:red_terracotta
fill 134 110 275 135 111 275 minecraft:white_concrete
fill 134 110 284 134 110 285 minecraft:red_terracotta
fill 134 110 307 134 110 308 minecraft:red_terracotta
fill 134 110 317 135 111 317 minecraft:white_concrete
fill 135 110 286 135 110 306 minecraft:red_terracotta
fill 136 110 276 136 111 276 minecraft:white_concrete
fill 136 110 277 136 111 278 minecraft:red_concrete
fill 136 110 279 136 111 280 minecraft:white_concrete
fill 136 110 281 136 111 282 minecraft:red_concrete
fill 136 110 283 136 111 284 minecraft:white_concrete
fill 136 110 285 136 111 286 minecraft:red_concrete
fill 136 110 287 136 111 288 minecraft:white_concrete
fill 136 110 289 136 111 290 minecraft:red_concrete
fill 136 110 291 136 111 292 minecraft:white_concrete
fill 136 110 293 136 111 294 minecraft:red_concrete
fill 136 110 295 136 111 296 minecraft:white_concrete
fill 136 110 297 136 111 298 minecraft:red_concrete
fill 136 110 299 136 111 300 minecraft:white_concrete
fill 136 110 301 136 111 302 minecraft:red_concrete
fill 136 110 303 136 111 304 minecraft:white_concrete
fill 136 110 305 136 111 306 minecraft:red_concrete
fill 136 110 307 136 111 308 minecraft:white_concrete
fill 136 110 309 136 111 310 minecraft:red_concrete
fill 136 110 311 136 111 312 minecraft:white_concrete
fill 136 110 313 136 111 314 minecraft:red_concrete
fill 136 110 315 136 111 316 minecraft:white_concrete
fill 136 110 317 136 111 317 minecraft:red_concrete
fill 95 111 287 95 111 305 minecraft:red_terracotta
fill 96 111 285 96 111 286 minecraft:red_terracotta
fill 96 111 287 110 111 305 minecraft:bricks
fill 96 111 306 96 111 307 minecraft:red_terracotta
setblock 97 111 278 minecraft:light[level=12]
fill 97 111 284 97 112 284 minecraft:red_terracotta
fill 97 111 285 133 111 286 minecraft:bricks
fill 97 111 306 133 111 307 minecraft:bricks
fill 97 111 308 97 112 308 minecraft:red_terracotta
setblock 97 111 313 minecraft:light[level=12]
fill 98 111 283 98 112 283 minecraft:red_terracotta
fill 98 111 284 132 112 284 minecraft:bricks
fill 98 111 308 132 112 308 minecraft:bricks
fill 98 111 309 98 112 309 minecraft:red_terracotta
fill 99 111 283 131 112 283 minecraft:bricks
fill 99 111 309 131 112 309 minecraft:bricks
fill 102 111 279 102 112 279 minecraft:red_terracotta
fill 102 111 313 102 112 313 minecraft:red_terracotta
fill 103 111 278 103 112 278 minecraft:red_terracotta
fill 103 111 279 127 112 279 minecraft:bricks
fill 103 111 313 127 112 313 minecraft:bricks
fill 103 111 314 103 112 314 minecraft:red_terracotta
fill 104 111 277 105 111 277 minecraft:red_terracotta
fill 104 111 278 126 111 278 minecraft:bricks
fill 104 111 314 126 111 314 minecraft:bricks
fill 104 111 315 105 111 315 minecraft:red_terracotta
fill 106 111 276 124 111 276 minecraft:red_terracotta
fill 106 111 277 124 111 277 minecraft:bricks
fill 106 111 315 124 111 315 minecraft:bricks
fill 106 111 316 124 111 316 minecraft:red_terracotta
fill 111 111 287 111 111 293 minecraft:bricks
fill 111 111 294 111 111 295 minecraft:shroomlight
fill 111 111 296 111 111 305 minecraft:bricks
fill 112 111 287 112 111 291 minecraft:bricks
fill 112 111 292 112 111 293 minecraft:shroomlight
fill 112 111 296 112 111 297 minecraft:shroomlight
fill 112 111 298 112 111 305 minecraft:bricks
fill 113 111 287 113 111 290 minecraft:bricks
setblock 113 111 291 minecraft:shroomlight
setblock 113 111 298 minecraft:shroomlight
fill 113 111 299 113 111 305 minecraft:bricks
fill 114 111 287 114 111 289 minecraft:bricks
setblock 114 111 290 minecraft:shroomlight
fill 114 111 299 115 111 299 minecraft:shroomlight
fill 114 111 300 115 111 305 minecraft:bricks
fill 115 111 287 134 111 288 minecraft:bricks
fill 115 111 289 118 111 289 minecraft:shroomlight
fill 116 111 300 117 111 300 minecraft:shroomlight
fill 116 111 301 134 111 305 minecraft:bricks
fill 118 111 299 119 111 299 minecraft:shroomlight
fill 118 111 300 134 111 300 minecraft:bricks
fill 119 111 289 134 111 289 minecraft:bricks
setblock 119 111 290 minecraft:shroomlight
setblock 120 111 291 minecraft:shroomlight
setblock 120 111 298 minecraft:shroomlight
fill 120 111 299 134 111 299 minecraft:bricks
setblock 121 111 292 minecraft:shroomlight
setblock 121 111 297 minecraft:shroomlight
fill 121 111 298 134 111 298 minecraft:bricks
fill 122 111 293 122 111 296 minecraft:shroomlight
fill 122 111 297 134 111 297 minecraft:bricks
fill 123 111 293 134 112 296 minecraft:bricks
fill 125 111 277 126 111 277 minecraft:red_terracotta
fill 125 111 315 126 111 315 minecraft:red_terracotta
fill 127 111 278 127 112 278 minecraft:red_terracotta
fill 127 111 314 127 112 314 minecraft:red_terracotta
fill 128 111 279 128 112 279 minecraft:red_terracotta
fill 128 111 313 128 112 313 minecraft:red_terracotta
setblock 132 111 278 minecraft:light[level=12]
fill 132 111 283 132 112 283 minecraft:red_terracotta
fill 132 111 309 132 112 309 minecraft:red_terracotta
setblock 132 111 313 minecraft:light[level=12]
fill 133 111 284 133 112 284 minecraft:red_terracotta
fill 133 111 308 133 112 308 minecraft:red_terracotta
fill 134 111 285 134 111 286 minecraft:red_terracotta
fill 134 111 306 134 111 307 minecraft:red_terracotta
fill 135 111 287 135 111 305 minecraft:red_terracotta
fill 94 112 275 94 113 276 minecraft:red_concrete
fill 94 112 277 94 113 278 minecraft:white_concrete
fill 94 112 279 94 113 280 minecraft:red_concrete
fill 94 112 281 94 113 282 minecraft:white_concrete
fill 94 112 283 94 113 284 minecraft:red_concrete
fill 94 112 285 94 113 286 minecraft:white_concrete
fill 94 112 287 94 113 288 minecraft:red_concrete
fill 94 112 289 94 113 290 minecraft:white_concrete
fill 94 112 291 94 113 292 minecraft:red_concrete
fill 94 112 293 94 113 294 minecraft:white_concrete
fill 94 112 295 94 113 296 minecraft:red_concrete
fill 94 112 297 94 113 298 minecraft:white_concrete
fill 94 112 299 94 113 300 minecraft:red_concrete
fill 94 112 301 94 113 302 minecraft:white_concrete
fill 94 112 303 94 113 304 minecraft:red_concrete
fill 94 112 305 94 113 306 minecraft:white_concrete
fill 94 112 307 94 113 308 minecraft:red_concrete
fill 94 112 309 94 113 310 minecraft:white_concrete
fill 94 112 311 94 113 312 minecraft:red_concrete
fill 94 112 313 94 113 314 minecraft:white_concrete
fill 94 112 315 94 113 316 minecraft:red_concrete
fill 95 112 275 95 113 275 minecraft:red_concrete
fill 95 112 288 95 113 304 minecraft:red_terracotta
fill 95 112 317 95 113 317 minecraft:red_concrete
fill 96 112 275 97 113 275 minecraft:white_concrete
fill 96 112 286 96 112 287 minecraft:red_terracotta
fill 96 112 288 110 112 304 minecraft:bricks
fill 96 112 305 96 112 306 minecraft:red_terracotta
fill 96 112 317 97 113 317 minecraft:white_concrete
fill 97 112 285 97 113 285 minecraft:red_terracotta
fill 97 112 286 133 112 287 minecraft:bricks
fill 97 112 305 133 112 306 minecraft:bricks
fill 97 112 307 97 113 307 minecraft:red_terracotta
fill 98 112 275 99 113 275 minecraft:red_concrete
fill 98 112 285 132 113 285 minecraft:bricks
fill 98 112 307 132 113 307 minecraft:bricks
fill 98 112 317 99 113 317 minecraft:red_concrete
setblock 99 112 282 minecraft:red_terracotta
fill 99 112 310 99 200 310 minecraft:red_terracotta
fill 100 112 275 101 113 275 minecraft:white_concrete
setblock 100 112 281 minecraft:red_terracotta
fill 100 112 282 130 112 282 minecraft:bricks
fill 100 112 310 130 112 310 minecraft:bricks
fill 100 112 311 100 200 311 minecraft:red_terracotta
fill 100 112 317 101 113 317 minecraft:white_concrete
setblock 101 112 280 minecraft:red_terracotta
fill 101 112 281 129 112 281 minecraft:bricks
fill 101 112 311 129 112 311 minecraft:bricks
setblock 101 112 312 minecraft:red_terracotta
fill 102 112 275 103 113 275 minecraft:red_concrete
fill 102 112 280 128 112 280 minecraft:bricks
fill 102 112 312 128 112 312 minecraft:bricks
fill 102 112 317 103 113 317 minecraft:red_concrete
fill 104 112 275 105 113 275 minecraft:white_concrete
fill 104 112 278 104 113 278 minecraft:red_terracotta
fill 104 112 314 104 113 314 minecraft:red_terracotta
fill 104 112 317 105 113 317 minecraft:white_concrete
fill 105 112 277 106 112 277 minecraft:red_terracotta
fill 105 112 278 125 112 278 minecraft:bricks
fill 105 112 314 125 112 314 minecraft:bricks
fill 105 112 315 106 112 315 minecraft:red_terracotta
fill 106 112 275 107 113 275 minecraft:red_concrete
fill 106 112 317 107 113 317 minecraft:red_concrete
fill 107 112 276 123 113 276 minecraft:red_terracotta
fill 107 112 277 123 112 277 minecraft:bricks
fill 107 112 315 123 112 315 minecraft:bricks
fill 107 112 316 123 113 316 minecraft:red_terracotta
fill 108 112 275 109 113 275 minecraft:white_concrete
fill 108 112 317 109 113 317 minecraft:white_concrete
fill 110 112 275 111 113 275 minecraft:red_concrete
fill 110 112 317 111 113 317 minecraft:red_concrete
fill 111 112 288 111 112 291 minecraft:bricks
fill 111 112 292 111 112 297 minecraft:magma_block
fill 111 112 298 111 112 304 minecraft:bricks
fill 112 112 275 113 113 275 minecraft:white_concrete
fill 112 112 288 112 112 290 minecraft:bricks
setblock 112 112 291 minecraft:magma_block
setblock 112 112 298 minecraft:magma_block
fill 112 112 299 112 112 304 minecraft:bricks
fill 112 112 317 113 113 317 minecraft:white_concrete
fill 113 112 288 113 112 289 minecraft:bricks
setblock 113 112 290 minecraft:magma_block
setblock 113 112 299 minecraft:magma_block
fill 113 112 300 113 112 304 minecraft:bricks
fill 114 112 275 115 113 275 minecraft:red_concrete
fill 114 112 288 134 112 288 minecraft:bricks
fill 114 112 289 119 112 289 minecraft:magma_block
fill 114 112 300 119 112 300 minecraft:magma_block
fill 114 112 301 134 112 304 minecraft:bricks
fill 114 112 317 115 113 317 minecraft:red_concrete
fill 116 112 275 117 113 275 minecraft:white_concrete
fill 116 112 317 117 113 317 minecraft:white_concrete
fill 118 112 275 119 113 275 minecraft:red_concrete
fill 118 112 317 119 113 317 minecraft:red_concrete
fill 120 112 275 121 113 275 minecraft:white_concrete
fill 120 112 289 134 112 289 minecraft:bricks
fill 120 112 290 120 113 290 minecraft:magma_block
setblock 120 112 299 minecraft:magma_block
fill 120 112 300 134 112 300 minecraft:bricks
fill 120 112 317 121 113 317 minecraft:white_concrete
fill 121 112 290 134 113 290 minecraft:bricks
fill 121 112 291 121 113 291 minecraft:magma_block
setblock 121 112 298 minecraft:magma_block
fill 121 112 299 134 112 299 minecraft:bricks
fill 122 112 275 123 113 275 minecraft:red_concrete
fill 122 112 291 134 113 291 minecraft:bricks
fill 122 112 292 122 112 297 minecraft:magma_block
fill 122 112 298 134 112 298 minecraft:bricks
fill 122 112 317 123 113 317 minecraft:red_concrete
fill 123 112 292 134 114 292 minecraft:bricks
fill 123 112 297 134 113 297 minecraft:bricks
fill 124 112 275 125 113 275 minecraft:white_concrete
fill 124 112 277 125 112 277 minecraft:red_terracotta
fill 124 112 315 125 112 315 minecraft:red_terracotta
fill 124 112 317 125 113 317 minecraft:white_concrete
fill 126 112 275 127 113 275 minecraft:red_concrete
fill 126 112 278 126 113 278 minecraft:red_terracotta
fill 126 112 314 126 113 314 minecraft:red_terracotta
fill 126 112 317 127 113 317 minecraft:red_concrete
fill 128 112 275 129 113 275 minecraft:white_concrete
fill 128 112 317 129 113 317 minecraft:white_concrete
setblock 129 112 280 minecraft:red_terracotta
setblock 129 112 312 minecraft:red_terracotta
fill 130 112 275 131 113 275 minecraft:red_concrete
setblock 130 112 281 minecraft:red_terracotta
setblock 130 112 311 minecraft:red_terracotta
fill 130 112 317 131 113 317 minecraft:red_concrete
setblock 131 112 282 minecraft:red_terracotta
setblock 131 112 310 minecraft:red_terracotta
fill 132 112 275 133 113 275 minecraft:white_concrete
fill 132 112 317 133 113 317 minecraft:white_concrete
fill 133 112 285 133 113 285 minecraft:red_terracotta
fill 133 112 307 133 113 307 minecraft:red_terracotta
fill 134 112 275 135 113 275 minecraft:red_concrete
fill 134 112 286 134 112 287 minecraft:red_terracotta
fill 134 112 305 134 112 306 minecraft:red_terracotta
fill 134 112 317 135 113 317 minecraft:red_concrete
fill 135 112 288 135 113 304 minecraft:red_terracotta
fill 136 112 276 136 113 276 minecraft:red_concrete
fill 136 112 277 136 113 278 minecraft:white_concrete
fill 136 112 279 136 113 280 minecraft:red_concrete
fill 136 112 281 136 113 282 minecraft:white_concrete
fill 136 112 283 136 113 284 minecraft:red_concrete
fill 136 112 285 136 113 286 minecraft:white_concrete
fill 136 112 287 136 113 288 minecraft:red_concrete
fill 136 112 289 136 113 290 minecraft:white_concrete
fill 136 112 291 136 113 292 minecraft:red_concrete
fill 136 112 293 136 113 294 minecraft:white_concrete
fill 136 112 295 136 113 296 minecraft:red_concrete
fill 136 112 297 136 113 298 minecraft:white_concrete
fill 136 112 299 136 113 300 minecraft:red_concrete
fill 136 112 301 136 113 302 minecraft:white_concrete
fill 136 112 303 136 113 304 minecraft:red_concrete
fill 136 112 305 136 113 306 minecraft:white_concrete
fill 136 112 307 136 113 308 minecraft:red_concrete
fill 136 112 309 136 113 310 minecraft:white_concrete
fill 136 112 311 136 113 312 minecraft:red_concrete
fill 136 112 313 136 113 314 minecraft:white_concrete
fill 136 112 315 136 113 316 minecraft:red_concrete
fill 136 112 317 136 113 317 minecraft:white_concrete
fill 95 113 276 95 113 287 minecraft:red_terracotta
fill 95 113 305 95 113 316 minecraft:red_terracotta
fill 96 113 276 106 113 276 minecraft:red_terracotta
fill 96 113 287 96 113 289 minecraft:red_terracotta
fill 96 113 290 109 113 302 minecraft:bricks
fill 96 113 303 96 113 305 minecraft:red_terracotta
fill 96 113 316 106 113 316 minecraft:red_terracotta
setblock 97 113 286 minecraft:red_terracotta
fill 97 113 287 112 113 289 minecraft:bricks
fill 97 113 303 133 113 305 minecraft:bricks
setblock 97 113 306 minecraft:red_terracotta
setblock 97 113 310 minecraft:brown_terracotta
fill 97 113 311 99 200 312 minecraft:red_terracotta
setblock 97 113 313 minecraft:brown_terracotta
setblock 98 113 284 minecraft:red_terracotta
fill 98 113 286 132 113 286 minecraft:bricks
fill 98 113 306 132 113 306 minecraft:bricks
setblock 98 113 308 minecraft:red_terracotta
fill 98 113 310 98 200 310 minecraft:red_terracotta
fill 98 113 313 99 200 313 minecraft:red_terracotta
fill 98 113 314 99 113 314 minecraft:brown_terracotta
setblock 99 113 283 minecraft:red_terracotta
fill 99 113 284 131 113 284 minecraft:bricks
fill 99 113 308 131 113 308 minecraft:bricks
setblock 99 113 309 minecraft:red_terracotta
fill 100 113 282 100 114 282 minecraft:red_terracotta
fill 100 113 283 130 113 283 minecraft:bricks
fill 100 113 309 130 113 309 minecraft:bricks
fill 100 113 310 100 114 310 minecraft:red_terracotta
fill 100 113 312 100 200 312 minecraft:red_terracotta
setblock 100 113 313 minecraft:iron_block
fill 101 113 281 101 114 281 minecraft:red_terracotta
fill 101 113 282 129 114 282 minecraft:bricks
fill 101 113 310 129 114 310 minecraft:bricks
fill 101 113 311 101 114 311 minecraft:red_terracotta
setblock 101 113 312 minecraft:iron_block
fill 101 113 313 102 113 313 minecraft:black_concrete
setblock 101 113 314 minecraft:iron_block
setblock 102 113 280 minecraft:red_terracotta
fill 102 113 281 128 113 281 minecraft:bricks
fill 102 113 311 128 113 311 minecraft:bricks
setblock 102 113 312 minecraft:red_terracotta
setblock 102 113 314 minecraft:black_concrete
setblock 102 113 315 minecraft:iron_block
setblock 103 113 279 minecraft:red_terracotta
fill 103 113 280 127 113 280 minecraft:bricks
fill 103 113 312 127 113 312 minecraft:bricks
setblock 103 113 313 minecraft:red_terracotta
setblock 103 113 314 minecraft:iron_block
fill 104 113 279 126 113 279 minecraft:bricks
fill 104 113 313 126 113 313 minecraft:bricks
setblock 105 113 278 minecraft:red_terracotta
setblock 105 113 314 minecraft:red_terracotta
fill 106 113 277 108 113 277 minecraft:red_terracotta
fill 106 113 278 124 113 278 minecraft:bricks
fill 106 113 314 124 113 314 minecraft:bricks
fill 106 113 315 108 113 315 minecraft:red_terracotta
fill 109 113 277 121 113 277 minecraft:bricks
fill 109 113 315 121 113 315 minecraft:bricks
fill 110 113 290 110 113 292 minecraft:bricks
fill 110 113 293 110 113 297 minecraft:magma_block
fill 110 113 298 110 113 302 minecraft:bricks
setblock 111 113 290 minecraft:bricks
fill 111 113 291 111 113 292 minecraft:magma_block
setblock 111 113 298 minecraft:magma_block
fill 111 113 299 111 113 302 minecraft:bricks
setblock 112 113 290 minecraft:magma_block
setblock 112 113 299 minecraft:magma_block
fill 112 113 300 112 113 302 minecraft:bricks
fill 113 113 287 114 113 288 minecraft:bricks
fill 113 113 289 114 113 289 minecraft:magma_block
setblock 113 113 300 minecraft:magma_block
fill 113 113 301 113 113 302 minecraft:bricks
fill 114 113 301 118 113 301 minecraft:magma_block
fill 114 113 302 134 113 302 minecraft:bricks
fill 115 113 287 133 113 287 minecraft:bricks
fill 115 113 288 117 113 288 minecraft:magma_block
fill 118 113 288 133 113 288 minecraft:bricks
fill 118 113 289 119 113 289 minecraft:magma_block
fill 119 113 300 120 113 300 minecraft:magma_block
fill 119 113 301 134 113 301 minecraft:bricks
fill 120 113 289 133 113 289 minecraft:bricks
setblock 121 113 299 minecraft:magma_block
fill 121 113 300 134 113 300 minecraft:bricks
fill 122 113 277 124 113 277 minecraft:red_terracotta
fill 122 113 292 122 113 293 minecraft:magma_block
fill 122 113 297 122 113 298 minecraft:magma_block
fill 122 113 299 134 113 299 minecraft:bricks
fill 122 113 315 124 113 315 minecraft:red_terracotta
fill 123 113 293 134 113 293 minecraft:bricks
fill 123 113 294 123 113 296 minecraft:magma_block
fill 123 113 298 134 114 298 minecraft:bricks
fill 124 113 276 135 113 276 minecraft:red_terracotta
fill 124 113 294 134 114 296 minecraft:bricks
fill 124 113 316 135 113 316 minecraft:red_terracotta
setblock 125 113 278 minecraft:red_terracotta
setblock 125 113 314 minecraft:red_terracotta
setblock 127 113 279 minecraft:red_terracotta
setblock 127 113 313 minecraft:red_terracotta
setblock 128 113 280 minecraft:red_terracotta
setblock 128 113 312 minecraft:red_terracotta
fill 129 113 281 129 114 281 minecraft:red_terracotta
fill 129 113 311 129 114 311 minecraft:red_terracotta
fill 130 113 282 130 115 282 minecraft:red_terracotta
fill 130 113 310 130 114 310 minecraft:red_terracotta
setblock 131 113 283 minecraft:red_terracotta
setblock 131 113 309 minecraft:red_terracotta
fill 132 113 283 132 200 283 minecraft:iron_block
setblock 132 113 284 minecraft:red_terracotta
setblock 132 113 308 minecraft:red_terracotta
setblock 133 113 286 minecraft:red_terracotta
setblock 133 113 306 minecraft:red_terracotta
fill 134 113 287 134 113 289 minecraft:red_terracotta
fill 134 113 303 134 113 305 minecraft:red_terracotta
fill 135 113 277 135 113 287 minecraft:red_terracotta
fill 135 113 305 135 113 315 minecraft:red_terracotta
fill 94 114 275 94 115 276 minecraft:white_concrete
fill 94 114 277 94 115 278 minecraft:red_concrete
fill 94 114 279 94 115 280 minecraft:white_concrete
fill 94 114 281 94 115 282 minecraft:red_concrete
fill 94 114 283 94 115 284 minecraft:white_concrete
fill 94 114 285 94 115 286 minecraft:red_concrete
fill 94 114 287 94 115 288 minecraft:white_concrete
fill 94 114 289 94 115 290 minecraft:red_concrete
fill 94 114 291 94 115 292 minecraft:white_concrete
fill 94 114 293 94 115 294 minecraft:red_concrete
fill 94 114 295 94 115 296 minecraft:white_concrete
fill 94 114 297 94 115 298 minecraft:red_concrete
fill 94 114 299 94 115 300 minecraft:white_concrete
fill 94 114 301 94 115 302 minecraft:red_concrete
fill 94 114 303 94 115 304 minecraft:white_concrete
fill 94 114 305 94 115 306 minecraft:red_concrete
fill 94 114 307 94 115 308 minecraft:white_concrete
fill 94 114 309 94 115 310 minecraft:red_concrete
fill 94 114 311 94 115 312 minecraft:white_concrete
fill 94 114 313 94 115 314 minecraft:red_concrete
fill 94 114 315 94 115 316 minecraft:white_concrete
fill 95 114 275 95 115 275 minecraft:white_concrete
fill 95 114 282 95 200 283 minecraft:red_terracotta
fill 95 114 290 95 114 300 minecraft:red_terracotta
fill 95 114 306 95 200 307 minecraft:red_terracotta
fill 95 114 314 95 200 315 minecraft:red_terracotta
fill 95 114 317 95 115 317 minecraft:white_concrete
fill 96 114 275 97 115 275 minecraft:red_concrete
fill 96 114 276 97 200 276 minecraft:red_terracotta
fill 96 114 289 96 114 291 minecraft:red_terracotta
fill 96 114 292 108 114 300 minecraft:bricks
fill 96 114 301 96 114 303 minecraft:red_terracotta
fill 96 114 317 97 115 317 minecraft:red_concrete
fill 97 114 287 97 114 288 minecraft:red_terracotta
fill 97 114 289 109 114 291 minecraft:bricks
fill 97 114 301 112 114 303 minecraft:bricks
fill 97 114 304 97 114 305 minecraft:red_terracotta
fill 98 114 275 99 115 275 minecraft:white_concrete
fill 98 114 285 98 114 286 minecraft:red_terracotta
fill 98 114 287 113 114 288 minecraft:bricks
fill 98 114 304 132 114 305 minecraft:bricks
fill 98 114 306 98 114 307 minecraft:red_terracotta
fill 98 114 317 99 115 317 minecraft:white_concrete
setblock 99 114 284 minecraft:red_terracotta
fill 99 114 285 131 114 286 minecraft:bricks
fill 99 114 306 131 114 307 minecraft:bricks
setblock 99 114 308 minecraft:red_terracotta
fill 100 114 275 101 115 275 minecraft:red_concrete
fill 100 114 283 100 115 283 minecraft:red_terracotta
fill 100 114 284 130 114 284 minecraft:bricks
fill 100 114 308 130 114 308 minecraft:bricks
fill 100 114 309 100 115 309 minecraft:red_terracotta
fill 100 114 317 101 115 317 minecraft:red_concrete
fill 101 114 283 129 115 283 minecraft:bricks
fill 101 114 309 129 115 309 minecraft:bricks
fill 101 114 316 102 200 316 minecraft:red_terracotta
fill 102 114 275 103 115 275 minecraft:white_concrete
fill 102 114 281 102 115 281 minecraft:red_terracotta
fill 102 114 311 102 115 311 minecraft:red_terracotta
fill 102 114 317 103 115 317 minecraft:white_concrete
setblock 103 114 280 minecraft:red_terracotta
fill 103 114 281 127 114 281 minecraft:bricks
fill 103 114 311 127 114 311 minecraft:bricks
setblock 103 114 312 minecraft:red_terracotta
fill 104 114 275 105 115 275 minecraft:red_concrete
fill 104 114 276 105 200 276 minecraft:red_terracotta
fill 104 114 279 105 114 279 minecraft:red_terracotta
fill 104 114 280 126 114 280 minecraft:bricks
fill 104 114 312 126 114 312 minecraft:bricks
fill 104 114 313 105 114 313 minecraft:red_terracotta
fill 104 114 317 105 115 317 minecraft:red_concrete
fill 106 114 275 107 115 275 minecraft:white_concrete
fill 106 114 278 107 114 278 minecraft:red_terracotta
fill 106 114 279 124 114 279 minecraft:bricks
fill 106 114 313 124 114 313 minecraft:bricks
fill 106 114 314 107 114 314 minecraft:red_terracotta
fill 106 114 317 107 115 317 minecraft:white_concrete
fill 108 114 275 109 115 275 minecraft:red_concrete
fill 108 114 277 110 114 277 minecraft:red_terracotta
fill 108 114 278 122 114 278 minecraft:bricks
fill 108 114 314 122 114 314 minecraft:bricks
fill 108 114 315 110 114 315 minecraft:red_terracotta
fill 108 114 317 109 115 317 minecraft:red_concrete
setblock 109 114 292 minecraft:bricks
fill 109 114 293 109 114 296 minecraft:shroomlight
fill 109 114 297 109 114 300 minecraft:bricks
fill 109 114 316 119 114 316 minecraft:red_terracotta
fill 110 114 275 111 115 275 minecraft:white_concrete
fill 110 114 289 110 114 290 minecraft:bricks
fill 110 114 291 110 114 292 minecraft:shroomlight
fill 110 114 297 110 114 298 minecraft:shroomlight
fill 110 114 299 110 114 300 minecraft:bricks
fill 110 114 317 111 115 317 minecraft:white_concrete
fill 111 114 276 121 114 276 minecraft:red_terracotta
fill 111 114 277 119 114 277 minecraft:bricks
setblock 111 114 289 minecraft:bricks
setblock 111 114 290 minecraft:shroomlight
fill 111 114 299 111 114 300 minecraft:shroomlight
fill 111 114 315 119 114 315 minecraft:bricks
fill 112 114 275 113 115 275 minecraft:red_concrete
fill 112 114 289 113 114 289 minecraft:shroomlight
setblock 112 114 300 minecraft:shroomlight
fill 112 114 317 113 115 317 minecraft:red_concrete
fill 113 114 301 114 114 301 minecraft:shroomlight
fill 113 114 302 114 114 303 minecraft:bricks
fill 114 114 275 115 115 275 minecraft:white_concrete
fill 114 114 287 132 114 287 minecraft:bricks
fill 114 114 288 118 114 288 minecraft:shroomlight
fill 114 114 317 115 115 317 minecraft:white_concrete
fill 115 114 302 118 114 302 minecraft:shroomlight
fill 115 114 303 133 114 303 minecraft:bricks
fill 116 114 275 117 115 275 minecraft:red_concrete
fill 116 114 317 117 115 317 minecraft:red_concrete
fill 118 114 275 119 115 275 minecraft:white_concrete
fill 118 114 317 119 115 317 minecraft:white_concrete
fill 119 114 288 132 114 288 minecraft:bricks
fill 119 114 289 120 114 289 minecraft:shroomlight
fill 119 114 301 120 114 301 minecraft:shroomlight
fill 119 114 302 133 114 302 minecraft:bricks
fill 120 114 275 121 115 275 minecraft:red_concrete
fill 120 114 277 122 114 277 minecraft:red_terracotta
fill 120 114 315 122 114 315 minecraft:red_terracotta
fill 120 114 317 121 115 317 minecraft:red_concrete
fill 121 114 289 133 114 289 minecraft:bricks
setblock 121 114 290 minecraft:shroomlight
setblock 121 114 300 minecraft:shroomlight
fill 121 114 301 133 114 301 minecraft:bricks
fill 122 114 275 123 115 275 minecraft:white_concrete
fill 122 114 290 133 114 290 minecraft:bricks
fill 122 114 291 122 114 292 minecraft:shroomlight
fill 122 114 298 122 114 299 minecraft:shroomlight
fill 122 114 300 134 114 300 minecraft:bricks
fill 122 114 317 123 115 317 minecraft:white_concrete
fill 123 114 278 124 114 278 minecraft:red_terracotta
fill 123 114 291 133 115 291 minecraft:bricks
fill 123 114 293 123 114 297 minecraft:shroomlight
fill 123 114 299 134 114 299 minecraft:bricks
fill 123 114 314 124 114 314 minecraft:red_terracotta
fill 124 114 275 125 115 275 minecraft:red_concrete
fill 124 114 293 134 114 293 minecraft:bricks
fill 124 114 297 134 114 297 minecraft:bricks
fill 124 114 317 125 115 317 minecraft:red_concrete
fill 125 114 279 126 114 279 minecraft:red_terracotta
fill 125 114 313 126 114 313 minecraft:red_terracotta
fill 125 114 316 126 200 316 minecraft:red_terracotta
fill 126 114 275 127 115 275 minecraft:white_concrete
fill 126 114 317 127 115 317 minecraft:white_concrete
setblock 127 114 280 minecraft:red_terracotta
setblock 127 114 312 minecraft:red_terracotta
fill 128 114 275 129 115 275 minecraft:red_concrete
fill 128 114 276 129 200 276 minecraft:red_terracotta
fill 128 114 281 128 115 281 minecraft:red_terracotta
fill 128 114 311 128 115 311 minecraft:red_terracotta
fill 128 114 317 129 115 317 minecraft:red_concrete
fill 130 114 275 131 115 275 minecraft:white_concrete
fill 130 114 283 130 115 283 minecraft:red_terracotta
fill 130 114 309 130 115 309 minecraft:red_terracotta
fill 130 114 317 131 115 317 minecraft:white_concrete
fill 131 114 283 131 200 283 minecraft:iron_block
setblock 131 114 284 minecraft:red_terracotta
setblock 131 114 308 minecraft:red_terracotta
fill 132 114 275 133 115 275 minecraft:red_concrete
fill 132 114 284 132 160 284 minecraft:iron_block
fill 132 114 285 132 114 286 minecraft:red_terracotta
fill 132 114 306 132 114 307 minecraft:red_terracotta
fill 132 114 317 133 115 317 minecraft:red_concrete
fill 133 114 287 133 114 288 minecraft:red_terracotta
fill 133 114 304 133 114 305 minecraft:red_terracotta
fill 133 114 316 134 200 316 minecraft:red_terracotta
fill 134 114 275 135 115 275 minecraft:white_concrete
fill 134 114 289 134 114 291 minecraft:red_terracotta
fill 134 114 301 134 114 303 minecraft:red_terracotta
fill 134 114 317 135 115 317 minecraft:white_concrete
fill 135 114 277 135 200 278 minecraft:red_terracotta
fill 135 114 285 135 200 286 minecraft:red_terracotta
fill 135 114 292 135 114 302 minecraft:red_terracotta
fill 135 114 309 135 200 310 minecraft:red_terracotta
fill 136 114 276 136 115 276 minecraft:white_concrete
fill 136 114 277 136 115 278 minecraft:red_concrete
fill 136 114 279 136 115 280 minecraft:white_concrete
fill 136 114 281 136 115 282 minecraft:red_concrete
fill 136 114 283 136 115 284 minecraft:white_concrete
fill 136 114 285 136 115 286 minecraft:red_concrete
fill 136 114 287 136 115 288 minecraft:white_concrete
fill 136 114 289 136 115 290 minecraft:red_concrete
fill 136 114 291 136 115 292 minecraft:white_concrete
fill 136 114 293 136 115 294 minecraft:red_concrete
fill 136 114 295 136 115 296 minecraft:white_concrete
fill 136 114 297 136 115 298 minecraft:red_concrete
fill 136 114 299 136 115 300 minecraft:white_concrete
fill 136 114 301 136 115 302 minecraft:red_concrete
fill 136 114 303 136 115 304 minecraft:white_concrete
fill 136 114 305 136 115 306 minecraft:red_concrete
fill 136 114 307 136 115 308 minecraft:white_concrete
fill 136 114 309 136 115 310 minecraft:red_concrete
fill 136 114 311 136 115 312 minecraft:white_concrete
fill 136 114 313 136 115 314 minecraft:red_concrete
fill 136 114 315 136 115 316 minecraft:white_concrete
fill 136 114 317 136 115 317 minecraft:red_concrete
fill 95 115 290 96 115 291 minecraft:red_terracotta
fill 95 115 298 96 116 299 minecraft:red_terracotta
fill 96 115 292 96 115 297 minecraft:red_terracotta
fill 96 115 300 96 115 302 minecraft:red_terracotta
fill 97 115 288 97 115 289 minecraft:red_terracotta
fill 97 115 290 107 115 302 minecraft:bricks
fill 97 115 303 97 115 304 minecraft:red_terracotta
fill 98 115 286 98 115 287 minecraft:red_terracotta
fill 98 115 288 110 115 289 minecraft:bricks
fill 98 115 303 114 115 304 minecraft:bricks
fill 98 115 305 98 115 306 minecraft:red_terracotta
setblock 99 115 285 minecraft:red_terracotta
fill 99 115 286 114 115 287 minecraft:bricks
fill 99 115 305 131 115 306 minecraft:bricks
setblock 99 115 307 minecraft:red_terracotta
fill 100 115 284 100 116 284 minecraft:red_terracotta
fill 100 115 285 130 115 285 minecraft:bricks
fill 100 115 307 130 115 307 minecraft:bricks
fill 100 115 308 100 116 308 minecraft:red_terracotta
setblock 101 115 282 minecraft:red_terracotta
fill 101 115 284 129 116 284 minecraft:bricks
fill 101 115 308 129 116 308 minecraft:bricks
setblock 101 115 310 minecraft:red_terracotta
fill 102 115 282 128 115 282 minecraft:bricks
fill 102 115 310 128 115 310 minecraft:bricks
fill 103 115 281 103 116 281 minecraft:red_terracotta
fill 103 115 311 103 116 311 minecraft:red_terracotta
setblock 104 115 280 minecraft:red_terracotta
fill 104 115 281 126 115 281 minecraft:bricks
fill 104 115 311 126 115 311 minecraft:bricks
setblock 104 115 312 minecraft:red_terracotta
fill 105 115 279 106 115 279 minecraft:red_terracotta
fill 105 115 280 125 115 280 minecraft:bricks
fill 105 115 312 125 115 312 minecraft:bricks
fill 105 115 313 106 115 313 minecraft:red_terracotta
fill 107 115 278 108 115 278 minecraft:red_terracotta
fill 107 115 279 123 115 279 minecraft:bricks
fill 107 115 313 123 115 313 minecraft:bricks
fill 107 115 314 108 115 314 minecraft:red_terracotta
fill 108 115 290 108 115 293 minecraft:bricks
fill 108 115 294 108 116 296 minecraft:magma_block
fill 108 115 297 108 115 302 minecraft:bricks
fill 109 115 277 121 115 277 minecraft:red_terracotta
fill 109 115 278 121 115 278 minecraft:bricks
fill 109 115 290 109 115 291 minecraft:bricks
fill 109 115 292 109 115 293 minecraft:magma_block
fill 109 115 297 109 115 298 minecraft:magma_block
fill 109 115 299 109 115 302 minecraft:bricks
fill 109 115 314 121 115 314 minecraft:bricks
fill 109 115 315 110 115 316 minecraft:red_terracotta
fill 110 115 290 110 115 291 minecraft:magma_block
fill 110 115 299 110 115 300 minecraft:magma_block
fill 110 115 301 110 115 302 minecraft:bricks
fill 111 115 288 112 115 288 minecraft:bricks
fill 111 115 289 112 115 289 minecraft:magma_block
fill 111 115 301 112 115 301 minecraft:magma_block
fill 111 115 302 112 115 302 minecraft:bricks
fill 111 115 315 121 115 315 minecraft:red_terracotta
fill 112 115 276 113 200 276 minecraft:red_terracotta
fill 113 115 288 114 115 288 minecraft:magma_block
fill 113 115 302 114 115 302 minecraft:magma_block
fill 115 115 286 131 115 286 minecraft:bricks
fill 115 115 287 117 116 287 minecraft:magma_block
fill 115 115 303 117 116 303 minecraft:magma_block
fill 115 115 304 132 115 304 minecraft:bricks
fill 117 115 316 118 200 316 minecraft:red_terracotta
fill 118 115 287 131 115 287 minecraft:bricks
fill 118 115 288 119 115 288 minecraft:magma_block
fill 118 115 302 119 115 302 minecraft:magma_block
fill 118 115 303 132 115 303 minecraft:bricks
fill 120 115 276 121 200 276 minecraft:red_terracotta
fill 120 115 288 132 115 288 minecraft:bricks
fill 120 115 289 121 115 289 minecraft:magma_block
fill 120 115 301 121 115 301 minecraft:magma_block
fill 120 115 302 133 115 302 minecraft:bricks
fill 122 115 278 123 115 278 minecraft:red_terracotta
fill 122 115 289 132 116 289 minecraft:bricks
fill 122 115 290 122 115 291 minecraft:magma_block
fill 122 115 299 122 115 300 minecraft:magma_block
fill 122 115 301 133 115 301 minecraft:bricks
fill 122 115 314 123 115 314 minecraft:red_terracotta
fill 123 115 290 133 115 290 minecraft:bricks
fill 123 115 292 123 115 293 minecraft:magma_block
fill 123 115 297 123 115 298 minecraft:magma_block
fill 123 115 299 133 115 300 minecraft:bricks
fill 124 115 279 125 115 279 minecraft:red_terracotta
fill 124 115 292 133 115 293 minecraft:bricks
fill 124 115 294 124 116 296 minecraft:magma_block
fill 124 115 297 133 115 298 minecraft:bricks
fill 124 115 313 125 115 313 minecraft:red_terracotta
fill 125 115 294 133 116 296 minecraft:bricks
setblock 126 115 280 minecraft:red_terracotta
setblock 126 115 312 minecraft:red_terracotta
fill 127 115 281 127 116 281 minecraft:red_terracotta
fill 127 115 311 127 116 311 minecraft:red_terracotta
setblock 129 115 282 minecraft:red_terracotta
setblock 129 115 310 minecraft:red_terracotta
fill 130 115 284 130 116 284 minecraft:red_terracotta
fill 130 115 308 130 116 308 minecraft:red_terracotta
fill 131 115 282 132 115 282 minecraft:red_terracotta
fill 131 115 284 131 200 284 minecraft:iron_block
setblock 131 115 285 minecraft:red_terracotta
setblock 131 115 307 minecraft:red_terracotta
fill 132 115 285 132 200 285 minecraft:iron_block
fill 132 115 286 132 115 287 minecraft:red_terracotta
fill 132 115 305 132 115 306 minecraft:red_terracotta
fill 133 115 283 133 115 285 minecraft:red_terracotta
fill 133 115 288 133 115 289 minecraft:red_terracotta
fill 133 115 303 133 115 304 minecraft:red_terracotta
fill 134 115 290 134 115 302 minecraft:red_terracotta
fill 135 115 293 135 200 294 minecraft:red_terracotta
fill 135 115 301 135 200 302 minecraft:red_terracotta
fill 94 116 275 94 117 276 minecraft:red_concrete
fill 94 116 277 94 117 278 minecraft:white_concrete
fill 94 116 279 94 117 279 minecraft:red_concrete
fill 94 116 280 94 121 280 minecraft:shroomlight
fill 94 116 281 94 117 282 minecraft:white_concrete
fill 94 116 283 94 117 284 minecraft:red_concrete
fill 94 116 285 94 117 286 minecraft:white_concrete
fill 94 116 287 94 117 287 minecraft:red_concrete
fill 94 116 288 94 123 288 minecraft:shroomlight
fill 94 116 289 94 117 290 minecraft:white_concrete
fill 94 116 291 94 117 292 minecraft:red_concrete
fill 94 116 293 94 117 294 minecraft:white_concrete
fill 94 116 295 94 117 295 minecraft:red_concrete
fill 94 116 296 94 121 296 minecraft:shroomlight
fill 94 116 297 94 117 298 minecraft:white_concrete
fill 94 116 299 94 117 300 minecraft:red_concrete
fill 94 116 301 94 117 302 minecraft:white_concrete
fill 94 116 303 94 117 303 minecraft:red_concrete
fill 94 116 304 94 121 304 minecraft:shroomlight
fill 94 116 305 94 117 306 minecraft:white_concrete
fill 94 116 307 94 117 308 minecraft:red_concrete
fill 94 116 309 94 117 310 minecraft:white_concrete
fill 94 116 311 94 117 311 minecraft:red_concrete
fill 94 116 312 94 121 312 minecraft:shroomlight
fill 94 116 313 94 117 314 minecraft:white_concrete
fill 94 116 315 94 117 316 minecraft:red_concrete
fill 95 116 275 95 117 275 minecraft:red_concrete
fill 95 116 290 95 174 291 minecraft:red_terracotta
fill 95 116 317 95 117 317 minecraft:red_concrete
fill 96 116 275 97 117 275 minecraft:white_concrete
fill 96 116 293 96 116 297 minecraft:red_terracotta
fill 96 116 317 96 117 317 minecraft:white_concrete
fill 97 116 289 97 116 292 minecraft:red_terracotta
fill 97 116 293 107 116 299 minecraft:bricks
fill 97 116 300 97 116 303 minecraft:red_terracotta
fill 97 116 317 97 121 317 minecraft:shroomlight
fill 98 116 275 99 117 275 minecraft:red_concrete
fill 98 116 287 98 116 288 minecraft:red_terracotta
fill 98 116 289 107 116 292 minecraft:bricks
fill 98 116 300 108 116 303 minecraft:bricks
fill 98 116 304 98 116 305 minecraft:red_terracotta
fill 98 116 317 99 117 317 minecraft:red_concrete
setblock 99 116 286 minecraft:red_terracotta
fill 99 116 287 111 116 288 minecraft:bricks
fill 99 116 304 131 116 305 minecraft:bricks
setblock 99 116 306 minecraft:red_terracotta
fill 100 116 275 100 117 275 minecraft:white_concrete
fill 100 116 285 100 117 285 minecraft:red_terracotta
fill 100 116 286 130 116 286 minecraft:bricks
fill 100 116 306 130 116 306 minecraft:bricks
fill 100 116 307 100 117 307 minecraft:red_terracotta
fill 100 116 317 101 117 317 minecraft:white_concrete
fill 101 116 275 101 121 275 minecraft:shroomlight
setblock 101 116 283 minecraft:red_terracotta
fill 101 116 285 129 117 285 minecraft:bricks
fill 101 116 307 129 117 307 minecraft:bricks
setblock 101 116 309 minecraft:red_terracotta
fill 102 116 275 103 117 275 minecraft:red_concrete
setblock 102 116 282 minecraft:red_terracotta
fill 102 116 283 128 116 283 minecraft:bricks
fill 102 116 309 128 116 309 minecraft:bricks
setblock 102 116 310 minecraft:red_terracotta
fill 102 116 317 103 117 317 minecraft:red_concrete
fill 103 116 282 127 116 282 minecraft:bricks
fill 103 116 310 127 116 310 minecraft:bricks
fill 104 116 275 105 117 275 minecraft:white_concrete
fill 104 116 281 104 117 281 minecraft:red_terracotta
fill 104 116 311 104 117 311 minecraft:red_terracotta
fill 104 116 317 104 117 317 minecraft:white_concrete
setblock 105 116 280 minecraft:red_terracotta
fill 105 116 281 125 116 281 minecraft:bricks
fill 105 116 311 125 116 311 minecraft:bricks
setblock 105 116 312 minecraft:red_terracotta
fill 105 116 317 105 121 317 minecraft:shroomlight
fill 106 116 275 107 117 275 minecraft:red_concrete
fill 106 116 279 107 116 279 minecraft:red_terracotta
fill 106 116 280 124 116 280 minecraft:bricks
fill 106 116 312 124 116 312 minecraft:bricks
fill 106 116 313 107 116 313 minecraft:red_terracotta
fill 106 116 317 107 117 317 minecraft:red_concrete
fill 108 116 275 108 117 275 minecraft:white_concrete
fill 108 116 278 111 116 278 minecraft:red_terracotta
fill 108 116 279 122 116 279 minecraft:bricks
fill 108 116 289 108 116 291 minecraft:bricks
fill 108 116 292 108 116 293 minecraft:magma_block
fill 108 116 297 108 116 298 minecraft:magma_block
setblock 108 116 299 minecraft:bricks
fill 108 116 313 122 116 313 minecraft:bricks
fill 108 116 314 111 116 314 minecraft:red_terracotta
fill 108 116 317 109 117 317 minecraft:white_concrete
fill 109 116 275 109 121 275 minecraft:shroomlight
fill 109 116 289 109 116 290 minecraft:bricks
setblock 109 116 291 minecraft:magma_block
fill 109 116 299 109 116 300 minecraft:magma_block
fill 109 116 301 109 116 303 minecraft:bricks
fill 109 116 316 110 200 316 minecraft:red_terracotta
fill 110 116 275 111 117 275 minecraft:red_concrete
setblock 110 116 289 minecraft:bricks
setblock 110 116 290 minecraft:magma_block
setblock 110 116 301 minecraft:magma_block
fill 110 116 302 110 116 303 minecraft:bricks
fill 110 116 317 111 117 317 minecraft:red_concrete
setblock 111 116 289 minecraft:magma_block
fill 111 116 302 112 116 302 minecraft:magma_block
fill 111 116 303 112 116 303 minecraft:bricks
fill 112 116 275 113 117 275 minecraft:white_concrete
fill 112 116 277 118 116 277 minecraft:red_terracotta
fill 112 116 278 118 116 278 minecraft:bricks
setblock 112 116 287 minecraft:bricks
setblock 112 116 288 minecraft:magma_block
fill 112 116 314 118 116 314 minecraft:bricks
fill 112 116 315 118 116 315 minecraft:red_terracotta
fill 112 116 317 112 117 317 minecraft:white_concrete
fill 113 116 287 114 116 287 minecraft:magma_block
fill 113 116 303 114 116 303 minecraft:magma_block
fill 113 116 317 113 121 317 minecraft:shroomlight
fill 114 116 275 115 117 275 minecraft:red_concrete
fill 114 116 317 115 117 317 minecraft:red_concrete
fill 116 116 275 116 117 275 minecraft:white_concrete
fill 116 116 317 117 117 317 minecraft:white_concrete
fill 117 116 275 117 121 275 minecraft:shroomlight
fill 118 116 275 119 117 275 minecraft:red_concrete
setblock 118 116 287 minecraft:magma_block
fill 118 116 303 119 116 303 minecraft:magma_block
fill 118 116 317 119 117 317 minecraft:red_concrete
fill 119 116 278 122 116 278 minecraft:red_terracotta
fill 119 116 287 131 116 287 minecraft:bricks
fill 119 116 288 120 116 288 minecraft:magma_block
fill 119 116 314 122 116 314 minecraft:red_terracotta
fill 120 116 275 121 117 275 minecraft:white_concrete
setblock 120 116 302 minecraft:magma_block
fill 120 116 303 132 116 303 minecraft:bricks
fill 120 116 317 120 117 317 minecraft:white_concrete
fill 121 116 288 131 116 288 minecraft:bricks
setblock 121 116 289 minecraft:magma_block
setblock 121 116 301 minecraft:magma_block
fill 121 116 302 132 116 302 minecraft:bricks
fill 121 116 317 121 121 317 minecraft:shroomlight
fill 122 116 275 123 117 275 minecraft:red_concrete
setblock 122 116 290 minecraft:magma_block
setblock 122 116 300 minecraft:magma_block
fill 122 116 301 132 116 301 minecraft:bricks
fill 122 116 317 123 117 317 minecraft:red_concrete
fill 123 116 279 124 116 279 minecraft:red_terracotta
fill 123 116 290 132 116 290 minecraft:bricks
fill 123 116 291 123 116 292 minecraft:magma_block
setblock 123 116 299 minecraft:magma_block
fill 123 116 300 132 116 300 minecraft:bricks
fill 123 116 313 124 116 313 minecraft:red_terracotta
fill 124 116 275 124 117 275 minecraft:white_concrete
fill 124 116 291 132 116 292 minecraft:bricks
setblock 124 116 293 minecraft:magma_block
fill 124 116 297 124 116 298 minecraft:magma_block
fill 124 116 299 133 116 299 minecraft:bricks
fill 124 116 317 125 117 317 minecraft:white_concrete
fill 125 116 275 125 121 275 minecraft:shroomlight
setblock 125 116 280 minecraft:red_terracotta
fill 125 116 293 133 116 293 minecraft:bricks
fill 125 116 297 133 116 298 minecraft:bricks
setblock 125 116 312 minecraft:red_terracotta
fill 126 116 275 127 117 275 minecraft:red_concrete
fill 126 116 281 126 117 281 minecraft:red_terracotta
fill 126 116 311 126 117 311 minecraft:red_terracotta
fill 126 116 317 127 117 317 minecraft:red_concrete
fill 128 116 275 129 117 275 minecraft:white_concrete
setblock 128 116 282 minecraft:red_terracotta
setblock 128 116 310 minecraft:red_terracotta
fill 128 116 317 128 117 317 minecraft:white_concrete
setblock 129 116 283 minecraft:red_terracotta
setblock 129 116 309 minecraft:red_terracotta
fill 129 116 317 129 121 317 minecraft:shroomlight
fill 130 116 275 131 117 275 minecraft:red_concrete
fill 130 116 283 130 200 283 minecraft:iron_block
fill 130 116 285 130 117 285 minecraft:red_terracotta
fill 130 116 307 130 117 307 minecraft:red_terracotta
fill 130 116 317 131 117 317 minecraft:red_concrete
fill 131 116 285 131 200 285 minecraft:iron_block
setblock 131 116 286 minecraft:red_terracotta
setblock 131 116 306 minecraft:red_terracotta
fill 132 116 275 132 117 275 minecraft:white_concrete
fill 132 116 287 132 116 288 minecraft:red_terracotta
fill 132 116 304 132 116 305 minecraft:red_terracotta
fill 132 116 317 133 117 317 minecraft:white_concrete
fill 133 116 275 133 121 275 minecraft:shroomlight
fill 133 116 289 133 116 292 minecraft:red_terracotta
fill 133 116 300 133 116 303 minecraft:red_terracotta
fill 134 116 275 135 117 275 minecraft:red_concrete
fill 134 116 293 134 116 299 minecraft:red_terracotta
fill 134 116 317 135 117 317 minecraft:red_concrete
fill 136 116 276 136 117 276 minecraft:red_concrete
fill 136 116 277 136 117 278 minecraft:white_concrete
fill 136 116 279 136 117 279 minecraft:red_concrete
fill 136 116 280 136 121 280 minecraft:shroomlight
fill 136 116 281 136 117 282 minecraft:white_concrete
fill 136 116 283 136 117 284 minecraft:red_concrete
fill 136 116 285 136 117 286 minecraft:white_concrete
fill 136 116 287 136 117 287 minecraft:red_concrete
fill 136 116 288 136 121 288 minecraft:shroomlight
fill 136 116 289 136 117 290 minecraft:white_concrete
fill 136 116 291 136 117 292 minecraft:red_concrete
fill 136 116 293 136 117 294 minecraft:white_concrete
fill 136 116 295 136 117 295 minecraft:red_concrete
fill 136 116 296 136 121 296 minecraft:shroomlight
fill 136 116 297 136 117 298 minecraft:white_concrete
fill 136 116 299 136 117 300 minecraft:red_concrete
fill 136 116 301 136 117 302 minecraft:white_concrete
schedule function dropper:buildpart/62_3 1t
