fill 369 179 573 370 181 573 minecraft:green_terracotta
setblock 370 179 561 minecraft:oak_log
fill 370 179 562 371 182 562 minecraft:green_terracotta
setblock 370 179 566 minecraft:oak_log
fill 370 179 567 370 182 567 minecraft:green_terracotta
setblock 370 179 571 minecraft:oak_log
fill 370 179 572 370 182 572 minecraft:green_terracotta
setblock 370 179 587 minecraft:green_terracotta
setblock 370 179 589 minecraft:green_terracotta
setblock 370 179 591 minecraft:oak_leaves[persistent=true]
fill 370 179 599 371 242 599 minecraft:green_terracotta
fill 371 179 559 371 179 560 minecraft:brown_terracotta
fill 371 179 561 371 242 561 minecraft:green_terracotta
fill 371 179 563 371 242 563 minecraft:green_terracotta
fill 371 179 565 371 239 566 minecraft:green_terracotta
setblock 371 179 567 minecraft:brown_terracotta
fill 371 179 568 371 242 568 minecraft:green_terracotta
setblock 371 179 570 minecraft:brown_terracotta
setblock 371 179 573 minecraft:brown_terracotta
setblock 371 179 575 minecraft:brown_terracotta
fill 371 179 576 371 242 576 minecraft:green_terracotta
fill 371 179 584 371 240 584 minecraft:green_terracotta
setblock 371 179 589 minecraft:brown_terracotta
fill 329 180 557 329 239 558 minecraft:green_terracotta
fill 329 180 569 329 240 569 minecraft:green_terracotta
fill 329 180 578 329 242 578 minecraft:green_terracotta
fill 329 180 592 329 240 592 minecraft:green_terracotta
fill 329 180 599 329 239 599 minecraft:green_terracotta
setblock 330 180 560 minecraft:oak_log
setblock 330 180 561 minecraft:green_terracotta
setblock 330 180 565 minecraft:oak_log
fill 330 180 566 330 183 566 minecraft:green_terracotta
setblock 330 180 570 minecraft:oak_log
fill 330 180 571 330 183 571 minecraft:green_terracotta
setblock 330 180 590 minecraft:oak_log
fill 330 180 591 330 183 591 minecraft:green_terracotta
setblock 330 180 594 minecraft:green_terracotta
setblock 330 180 596 minecraft:oak_leaves[persistent=true]
fill 340 180 599 340 239 599 minecraft:green_terracotta
fill 341 180 597 341 181 597 minecraft:green_terracotta
setblock 342 180 598 minecraft:oak_log
setblock 343 180 597 minecraft:oak_log
fill 343 180 598 343 183 598 minecraft:green_terracotta
fill 344 180 597 344 183 597 minecraft:green_terracotta
setblock 347 180 598 minecraft:oak_log
fill 349 180 599 349 242 599 minecraft:green_terracotta
fill 353 180 557 353 242 557 minecraft:green_terracotta
setblock 353 180 558 minecraft:oak_leaves[persistent=true]
fill 360 180 599 360 242 599 minecraft:green_terracotta
setblock 367 180 568 minecraft:oak_log
setblock 368 180 567 minecraft:oak_log
fill 368 180 568 368 183 568 minecraft:green_terracotta
fill 368 180 599 369 242 599 minecraft:green_terracotta
setblock 369 180 566 minecraft:oak_log
fill 369 180 567 369 183 567 minecraft:green_terracotta
setblock 369 180 571 minecraft:oak_log
fill 369 180 572 369 183 572 minecraft:green_terracotta
setblock 370 180 560 minecraft:oak_leaves[persistent=true]
fill 370 180 561 370 181 561 minecraft:green_terracotta
setblock 370 180 565 minecraft:oak_log
fill 370 180 566 370 183 566 minecraft:green_terracotta
setblock 370 180 570 minecraft:oak_log
fill 370 180 571 371 183 571 minecraft:green_terracotta
setblock 370 180 585 minecraft:oak_leaves[persistent=true]
fill 371 180 559 371 238 560 minecraft:green_terracotta
fill 371 180 567 371 242 567 minecraft:green_terracotta
fill 371 180 569 371 238 570 minecraft:green_terracotta
fill 371 180 573 371 242 573 minecraft:green_terracotta
fill 371 180 575 371 240 575 minecraft:green_terracotta
fill 371 180 589 371 242 589 minecraft:green_terracotta
fill 371 180 593 371 242 593 minecraft:green_terracotta
setblock 330 181 558 minecraft:oak_leaves[persistent=true]
setblock 330 181 564 minecraft:oak_log
fill 330 181 565 330 183 565 minecraft:green_terracotta
setblock 330 181 569 minecraft:oak_log
fill 330 181 570 330 184 570 minecraft:green_terracotta
setblock 330 181 577 minecraft:oak_leaves[persistent=true]
setblock 330 181 589 minecraft:oak_log
fill 330 181 590 330 184 590 minecraft:green_terracotta
setblock 330 181 594 minecraft:oak_log
fill 330 181 595 330 184 595 minecraft:green_terracotta
setblock 334 181 598 minecraft:oak_leaves[persistent=true]
fill 337 181 598 338 183 598 minecraft:green_terracotta
fill 340 181 597 340 182 597 minecraft:green_terracotta
setblock 341 181 598 minecraft:oak_log
setblock 342 181 596 minecraft:green_terracotta
setblock 342 181 597 minecraft:oak_log
fill 342 181 598 342 184 598 minecraft:green_terracotta
setblock 343 181 596 minecraft:oak_log
fill 343 181 597 343 184 597 minecraft:green_terracotta
fill 344 181 596 344 184 596 minecraft:green_terracotta
setblock 346 181 598 minecraft:oak_log
setblock 347 181 558 minecraft:oak_leaves[persistent=true]
fill 347 181 598 347 184 598 minecraft:green_terracotta
setblock 353 181 598 minecraft:oak_leaves[persistent=true]
fill 355 181 590 356 182 590 minecraft:oak_leaves[persistent=true]
setblock 365 181 558 minecraft:green_terracotta
setblock 366 181 558 minecraft:oak_leaves[persistent=true]
setblock 368 181 566 minecraft:oak_log
fill 368 181 567 368 184 567 minecraft:green_terracotta
setblock 368 181 571 minecraft:oak_log
setblock 369 181 565 minecraft:oak_log
fill 369 181 566 369 184 566 minecraft:green_terracotta
setblock 369 181 569 minecraft:green_terracotta
setblock 369 181 570 minecraft:oak_log
fill 369 181 571 369 184 571 minecraft:green_terracotta
setblock 370 181 564 minecraft:oak_log
fill 370 181 565 370 184 565 minecraft:green_terracotta
setblock 370 181 569 minecraft:oak_log
fill 370 181 570 370 184 570 minecraft:green_terracotta
setblock 370 181 574 minecraft:oak_log
setblock 370 181 579 minecraft:oak_leaves[persistent=true]
fill 371 181 564 371 239 564 minecraft:green_terracotta
fill 371 181 574 371 238 574 minecraft:green_terracotta
setblock 330 182 564 minecraft:green_terracotta
setblock 330 182 568 minecraft:oak_log
fill 330 182 569 330 185 569 minecraft:green_terracotta
setblock 330 182 583 minecraft:oak_leaves[persistent=true]
setblock 330 182 593 minecraft:oak_log
fill 330 182 594 330 185 594 minecraft:green_terracotta
fill 330 182 596 330 182 597 minecraft:green_terracotta
fill 336 182 598 336 185 598 minecraft:green_terracotta
fill 338 182 597 339 183 597 minecraft:green_terracotta
fill 340 182 596 341 182 596 minecraft:green_terracotta
setblock 340 182 598 minecraft:oak_log
setblock 341 182 558 minecraft:oak_leaves[persistent=true]
setblock 341 182 597 minecraft:oak_log
fill 341 182 598 341 185 598 minecraft:green_terracotta
setblock 342 182 596 minecraft:oak_log
fill 342 182 597 342 185 597 minecraft:green_terracotta
fill 343 182 596 343 185 596 minecraft:green_terracotta
fill 345 182 588 346 183 588 minecraft:glowstone
fill 345 182 596 345 183 596 minecraft:green_terracotta
setblock 345 182 598 minecraft:oak_log
setblock 346 182 597 minecraft:oak_log
fill 346 182 598 346 185 598 minecraft:green_terracotta
setblock 359 182 598 minecraft:oak_leaves[persistent=true]
setblock 360 182 558 minecraft:oak_leaves[persistent=true]
fill 363 182 558 364 182 558 minecraft:green_terracotta
setblock 365 182 558 minecraft:oak_log
fill 366 182 558 366 185 558 minecraft:green_terracotta
setblock 368 182 566 minecraft:green_terracotta
setblock 368 182 570 minecraft:oak_log
fill 368 182 571 368 184 572 minecraft:green_terracotta
setblock 369 182 564 minecraft:oak_log
fill 369 182 565 369 184 565 minecraft:green_terracotta
setblock 369 182 569 minecraft:oak_log
fill 369 182 570 369 185 570 minecraft:green_terracotta
setblock 369 182 573 minecraft:green_terracotta
setblock 370 182 563 minecraft:oak_log
fill 370 182 564 370 185 564 minecraft:green_terracotta
setblock 370 182 568 minecraft:oak_log
fill 370 182 569 370 185 569 minecraft:green_terracotta
setblock 370 182 573 minecraft:oak_log
fill 370 182 574 370 185 574 minecraft:green_terracotta
setblock 370 182 592 minecraft:oak_leaves[persistent=true]
setblock 330 183 567 minecraft:oak_log
fill 330 183 568 330 186 568 minecraft:green_terracotta
fill 330 183 589 330 185 589 minecraft:green_terracotta
setblock 330 183 592 minecraft:oak_log
fill 330 183 593 330 186 593 minecraft:green_terracotta
setblock 330 183 596 minecraft:green_terracotta
setblock 330 183 597 minecraft:oak_log
fill 330 183 598 333 183 598 minecraft:green_terracotta
setblock 334 183 598 minecraft:oak_log
setblock 335 183 558 minecraft:oak_leaves[persistent=true]
fill 335 183 598 335 186 598 minecraft:green_terracotta
fill 336 183 597 337 185 597 minecraft:green_terracotta
fill 338 183 596 340 183 596 minecraft:green_terracotta
setblock 339 183 558 minecraft:oak_log
setblock 339 183 598 minecraft:oak_log
fill 340 183 558 343 183 558 minecraft:green_terracotta
setblock 340 183 597 minecraft:oak_log
fill 340 183 598 340 186 598 minecraft:green_terracotta
setblock 341 183 595 minecraft:green_terracotta
setblock 341 183 596 minecraft:oak_log
fill 341 183 597 341 186 597 minecraft:green_terracotta
setblock 342 183 595 minecraft:oak_log
fill 342 183 596 342 186 596 minecraft:green_terracotta
fill 343 183 595 343 186 595 minecraft:green_terracotta
setblock 344 183 598 minecraft:oak_log
setblock 345 183 597 minecraft:oak_log
fill 345 183 598 345 186 598 minecraft:green_terracotta
fill 346 183 597 346 186 597 minecraft:green_terracotta
setblock 348 183 598 minecraft:green_terracotta
setblock 354 183 558 minecraft:oak_leaves[persistent=true]
fill 361 183 598 363 183 598 minecraft:green_terracotta
fill 362 183 558 363 183 558 minecraft:green_terracotta
setblock 364 183 558 minecraft:oak_log
setblock 364 183 598 minecraft:oak_log
fill 365 183 558 365 186 558 minecraft:green_terracotta
fill 365 183 598 365 186 598 minecraft:green_terracotta
fill 367 183 558 367 184 558 minecraft:green_terracotta
setblock 368 183 569 minecraft:oak_log
fill 368 183 570 368 186 570 minecraft:green_terracotta
setblock 369 183 568 minecraft:oak_log
fill 369 183 569 369 186 569 minecraft:green_terracotta
setblock 369 183 573 minecraft:oak_log
setblock 370 183 562 minecraft:oak_log
fill 370 183 563 370 186 563 minecraft:green_terracotta
setblock 370 183 567 minecraft:oak_log
fill 370 183 568 370 186 568 minecraft:green_terracotta
setblock 370 183 572 minecraft:oak_log
fill 370 183 573 370 186 573 minecraft:green_terracotta
fill 370 183 575 370 184 575 minecraft:green_terracotta
setblock 370 183 586 minecraft:oak_leaves[persistent=true]
fill 371 183 562 371 242 562 minecraft:green_terracotta
setblock 330 184 566 minecraft:oak_log
fill 330 184 567 330 185 567 minecraft:green_terracotta
setblock 330 184 571 minecraft:oak_log
fill 330 184 572 330 187 572 minecraft:green_terracotta
setblock 330 184 576 minecraft:oak_leaves[persistent=true]
setblock 330 184 591 minecraft:oak_log
fill 330 184 592 330 187 592 minecraft:green_terracotta
setblock 330 184 596 minecraft:oak_log
fill 330 184 597 330 186 598 minecraft:green_terracotta
fill 331 184 593 331 184 594 minecraft:green_terracotta
setblock 331 184 595 minecraft:oak_log
fill 331 184 598 332 184 598 minecraft:green_terracotta
setblock 332 184 560 minecraft:light[level=14]
setblock 332 184 568 minecraft:light[level=14]
setblock 332 184 576 minecraft:light[level=14]
setblock 332 184 584 minecraft:light[level=14]
setblock 332 184 592 minecraft:light[level=14]
setblock 333 184 598 minecraft:oak_log
setblock 334 184 597 minecraft:oak_log
fill 334 184 598 334 187 598 minecraft:green_terracotta
fill 335 184 597 335 187 597 minecraft:green_terracotta
fill 336 184 596 339 184 596 minecraft:green_terracotta
setblock 337 184 558 minecraft:green_terracotta
setblock 337 184 598 minecraft:green_terracotta
setblock 338 184 558 minecraft:oak_log
setblock 338 184 597 minecraft:green_terracotta
setblock 338 184 598 minecraft:oak_log
fill 339 184 558 342 184 558 minecraft:green_terracotta
fill 339 184 595 340 184 595 minecraft:green_terracotta
setblock 339 184 597 minecraft:oak_log
fill 339 184 598 339 187 598 minecraft:green_terracotta
setblock 340 184 560 minecraft:light[level=14]
setblock 340 184 568 minecraft:light[level=14]
setblock 340 184 576 minecraft:light[level=14]
setblock 340 184 584 minecraft:light[level=14]
setblock 340 184 592 minecraft:light[level=14]
setblock 340 184 596 minecraft:oak_log
fill 340 184 597 340 187 597 minecraft:green_terracotta
setblock 341 184 595 minecraft:oak_log
fill 341 184 596 341 187 596 minecraft:green_terracotta
fill 342 184 595 342 187 595 minecraft:green_terracotta
setblock 343 184 558 minecraft:oak_log
setblock 343 184 598 minecraft:oak_log
fill 344 184 595 344 185 595 minecraft:green_terracotta
setblock 344 184 597 minecraft:oak_log
fill 344 184 598 344 187 598 minecraft:green_terracotta
setblock 345 184 596 minecraft:oak_log
fill 345 184 597 345 187 597 minecraft:green_terracotta
fill 346 184 596 346 187 596 minecraft:green_terracotta
fill 347 184 597 347 185 597 minecraft:green_terracotta
setblock 348 184 558 minecraft:oak_leaves[persistent=true]
setblock 348 184 560 minecraft:light[level=14]
setblock 348 184 568 minecraft:light[level=14]
setblock 348 184 576 minecraft:light[level=14]
setblock 348 184 584 minecraft:light[level=14]
setblock 348 184 592 minecraft:light[level=14]
setblock 348 184 598 minecraft:oak_log
setblock 352 184 598 minecraft:oak_leaves[persistent=true]
setblock 356 184 560 minecraft:light[level=14]
setblock 356 184 568 minecraft:light[level=14]
setblock 356 184 576 minecraft:light[level=14]
setblock 356 184 584 minecraft:light[level=14]
setblock 356 184 592 minecraft:light[level=14]
fill 359 184 598 362 184 598 minecraft:green_terracotta
fill 360 184 558 362 184 558 minecraft:green_terracotta
setblock 363 184 558 minecraft:oak_log
setblock 363 184 597 minecraft:green_terracotta
setblock 363 184 598 minecraft:oak_log
fill 364 184 558 364 187 558 minecraft:green_terracotta
setblock 364 184 560 minecraft:light[level=14]
setblock 364 184 568 minecraft:light[level=14]
setblock 364 184 576 minecraft:light[level=14]
setblock 364 184 584 minecraft:light[level=14]
setblock 364 184 592 minecraft:light[level=14]
fill 364 184 598 364 187 598 minecraft:green_terracotta
fill 366 184 598 367 184 598 minecraft:green_terracotta
setblock 368 184 558 minecraft:oak_log
setblock 368 184 568 minecraft:oak_log
fill 368 184 569 368 185 569 minecraft:green_terracotta
setblock 369 184 567 minecraft:oak_log
fill 369 184 568 369 187 568 minecraft:green_terracotta
setblock 369 184 572 minecraft:oak_log
fill 369 184 573 369 186 574 minecraft:green_terracotta
setblock 370 184 561 minecraft:oak_leaves[persistent=true]
fill 370 184 562 370 187 562 minecraft:green_terracotta
setblock 370 184 566 minecraft:oak_log
fill 370 184 567 370 187 567 minecraft:green_terracotta
setblock 370 184 571 minecraft:oak_log
fill 370 184 572 370 187 572 minecraft:green_terracotta
setblock 370 184 580 minecraft:oak_leaves[persistent=true]
fill 370 184 592 370 184 595 minecraft:green_terracotta
fill 371 184 571 371 240 571 minecraft:green_terracotta
fill 330 185 558 330 186 558 minecraft:green_terracotta
setblock 330 185 570 minecraft:oak_log
fill 330 185 571 330 187 571 minecraft:green_terracotta
fill 330 185 573 330 186 573 minecraft:green_terracotta
setblock 330 185 582 minecraft:oak_leaves[persistent=true]
setblock 330 185 590 minecraft:oak_log
fill 330 185 591 330 188 591 minecraft:green_terracotta
setblock 330 185 595 minecraft:oak_log
fill 330 185 596 331 187 596 minecraft:green_terracotta
fill 331 185 592 331 185 593 minecraft:green_terracotta
setblock 331 185 594 minecraft:oak_log
fill 331 185 595 331 188 595 minecraft:green_terracotta
fill 331 185 597 331 185 598 minecraft:green_terracotta
setblock 332 185 597 minecraft:green_terracotta
setblock 332 185 598 minecraft:oak_log
setblock 333 185 597 minecraft:oak_log
fill 333 185 598 333 188 598 minecraft:green_terracotta
fill 334 185 597 334 188 597 minecraft:green_terracotta
fill 335 185 558 336 185 558 minecraft:green_terracotta
fill 335 185 596 338 185 596 minecraft:green_terracotta
setblock 337 185 558 minecraft:oak_log
fill 337 185 595 339 185 595 minecraft:green_terracotta
setblock 337 185 598 minecraft:oak_log
fill 338 185 558 341 185 558 minecraft:green_terracotta
setblock 338 185 597 minecraft:oak_log
fill 338 185 598 338 188 598 minecraft:green_terracotta
setblock 339 185 596 minecraft:oak_log
fill 339 185 597 339 188 597 minecraft:green_terracotta
setblock 340 185 594 minecraft:green_terracotta
setblock 340 185 595 minecraft:oak_log
fill 340 185 596 340 188 596 minecraft:green_terracotta
setblock 341 185 594 minecraft:oak_log
fill 341 185 595 341 188 595 minecraft:green_terracotta
setblock 342 185 558 minecraft:oak_log
fill 342 185 594 342 187 594 minecraft:green_terracotta
setblock 342 185 598 minecraft:oak_log
fill 343 185 558 344 187 558 minecraft:green_terracotta
setblock 343 185 597 minecraft:oak_log
fill 343 185 598 343 188 598 minecraft:green_terracotta
setblock 344 185 596 minecraft:oak_log
fill 344 185 597 344 188 597 minecraft:green_terracotta
fill 345 185 578 346 185 579 minecraft:oak_leaves[persistent=true]
fill 345 185 596 345 188 596 minecraft:green_terracotta
fill 346 185 576 347 185 577 minecraft:oak_leaves[persistent=true]
fill 346 185 580 348 185 580 minecraft:oak_leaves[persistent=true]
fill 347 185 575 352 185 575 minecraft:oak_leaves[persistent=true]
fill 347 185 579 347 187 579 minecraft:oak_leaves[persistent=true]
fill 347 185 581 352 185 581 minecraft:oak_leaves[persistent=true]
setblock 347 185 598 minecraft:oak_log
fill 348 185 574 350 185 574 minecraft:oak_leaves[persistent=true]
fill 348 185 576 348 187 576 minecraft:oak_leaves[persistent=true]
fill 348 185 582 350 185 582 minecraft:oak_leaves[persistent=true]
fill 348 185 598 348 188 598 minecraft:green_terracotta
fill 351 185 580 351 187 580 minecraft:oak_leaves[persistent=true]
setblock 357 185 598 minecraft:oak_log
fill 358 185 598 361 185 598 minecraft:green_terracotta
fill 359 185 558 361 185 558 minecraft:green_terracotta
fill 359 185 597 362 185 597 minecraft:green_terracotta
fill 361 185 569 362 185 574 minecraft:oak_leaves[persistent=true]
setblock 362 185 558 minecraft:oak_log
fill 362 185 559 364 186 559 minecraft:green_terracotta
fill 362 185 568 367 185 568 minecraft:oak_leaves[persistent=true]
fill 362 185 575 367 185 575 minecraft:oak_leaves[persistent=true]
setblock 362 185 598 minecraft:oak_log
fill 363 185 558 363 188 558 minecraft:green_terracotta
fill 363 185 569 367 186 569 minecraft:oak_leaves[persistent=true]
fill 363 185 574 368 185 574 minecraft:oak_leaves[persistent=true]
setblock 363 185 597 minecraft:oak_log
fill 363 185 598 363 188 598 minecraft:green_terracotta
fill 364 185 567 365 185 567 minecraft:oak_leaves[persistent=true]
fill 364 185 597 365 187 597 minecraft:green_terracotta
setblock 366 185 598 minecraft:green_terracotta
setblock 367 185 558 minecraft:oak_log
fill 367 185 570 367 187 573 minecraft:oak_leaves[persistent=true]
setblock 367 185 598 minecraft:oak_log
fill 368 185 558 370 186 558 minecraft:green_terracotta
setblock 368 185 568 minecraft:green_terracotta
setblock 368 185 571 minecraft:green_terracotta
setblock 368 185 572 minecraft:oak_log
fill 368 185 573 368 186 573 minecraft:oak_leaves[persistent=true]
fill 368 185 598 370 186 598 minecraft:green_terracotta
setblock 369 185 566 minecraft:oak_log
fill 369 185 567 369 186 567 minecraft:green_terracotta
setblock 369 185 571 minecraft:oak_log
fill 369 185 572 369 188 572 minecraft:green_terracotta
setblock 370 185 565 minecraft:oak_log
fill 370 185 566 370 188 566 minecraft:green_terracotta
setblock 370 185 570 minecraft:oak_log
fill 370 185 571 370 188 571 minecraft:green_terracotta
setblock 370 185 575 minecraft:oak_log
fill 370 185 576 370 188 576 minecraft:green_terracotta
fill 370 185 592 370 185 594 minecraft:green_terracotta
setblock 370 185 595 minecraft:oak_log
fill 370 185 596 370 187 597 minecraft:green_terracotta
setblock 330 186 563 minecraft:oak_leaves[persistent=true]
setblock 330 186 569 minecraft:oak_log
fill 330 186 570 330 187 570 minecraft:green_terracotta
setblock 330 186 588 minecraft:oak_leaves[persistent=true]
setblock 330 186 589 minecraft:oak_log
fill 330 186 590 330 188 590 minecraft:green_terracotta
setblock 330 186 594 minecraft:oak_log
fill 330 186 595 330 188 595 minecraft:green_terracotta
setblock 331 186 558 minecraft:oak_log
fill 331 186 591 331 186 592 minecraft:green_terracotta
setblock 331 186 593 minecraft:oak_log
fill 331 186 594 331 188 594 minecraft:green_terracotta
setblock 331 186 597 minecraft:green_terracotta
setblock 331 186 598 minecraft:oak_log
fill 332 186 558 335 186 558 minecraft:green_terracotta
setblock 332 186 597 minecraft:oak_log
fill 332 186 598 332 188 598 minecraft:green_terracotta
setblock 333 186 596 minecraft:oak_log
fill 333 186 597 333 188 597 minecraft:green_terracotta
fill 334 186 596 337 186 596 minecraft:green_terracotta
setblock 336 186 558 minecraft:oak_log
fill 336 186 595 338 186 595 minecraft:green_terracotta
setblock 336 186 597 minecraft:green_terracotta
setblock 336 186 598 minecraft:oak_log
fill 337 186 558 340 186 558 minecraft:green_terracotta
setblock 337 186 597 minecraft:oak_log
fill 337 186 598 337 188 598 minecraft:green_terracotta
setblock 338 186 596 minecraft:oak_log
fill 338 186 597 338 188 597 minecraft:green_terracotta
setblock 339 186 594 minecraft:green_terracotta
setblock 339 186 595 minecraft:oak_log
fill 339 186 596 339 188 596 minecraft:green_terracotta
setblock 340 186 594 minecraft:oak_log
fill 340 186 595 340 188 595 minecraft:green_terracotta
setblock 341 186 558 minecraft:oak_log
fill 341 186 594 341 188 594 minecraft:green_terracotta
setblock 341 186 598 minecraft:oak_log
fill 342 186 558 342 188 558 minecraft:green_terracotta
setblock 342 186 597 minecraft:oak_log
fill 342 186 598 342 188 598 minecraft:green_terracotta
setblock 343 186 596 minecraft:oak_log
fill 343 186 597 343 188 597 minecraft:green_terracotta
setblock 344 186 595 minecraft:oak_log
fill 344 186 596 344 188 596 minecraft:green_terracotta
fill 346 186 577 346 186 579 minecraft:oak_leaves[persistent=true]
setblock 346 186 598 minecraft:oak_log
fill 347 186 576 347 186 577 minecraft:oak_leaves[persistent=true]
fill 347 186 580 348 187 580 minecraft:oak_leaves[persistent=true]
setblock 347 186 597 minecraft:oak_log
fill 347 186 598 347 188 598 minecraft:green_terracotta
fill 348 186 575 351 186 575 minecraft:oak_leaves[persistent=true]
fill 348 186 581 351 186 581 minecraft:oak_leaves[persistent=true]
fill 349 186 598 349 187 598 minecraft:green_terracotta
setblock 355 186 558 minecraft:oak_leaves[persistent=true]
setblock 355 186 598 minecraft:green_terracotta
setblock 356 186 598 minecraft:oak_log
fill 357 186 558 360 186 558 minecraft:green_terracotta
setblock 357 186 597 minecraft:oak_log
fill 357 186 598 360 186 598 minecraft:green_terracotta
fill 358 186 597 361 186 597 minecraft:green_terracotta
setblock 360 186 559 minecraft:oak_log
setblock 361 186 558 minecraft:oak_log
fill 361 186 559 361 188 559 minecraft:green_terracotta
fill 361 186 571 362 186 572 minecraft:oak_leaves[persistent=true]
setblock 361 186 598 minecraft:oak_log
fill 362 186 558 362 188 558 minecraft:green_terracotta
fill 362 186 569 362 186 570 minecraft:oak_leaves[persistent=true]
fill 362 186 573 362 186 574 minecraft:oak_leaves[persistent=true]
setblock 362 186 597 minecraft:oak_log
fill 362 186 598 362 188 598 minecraft:green_terracotta
fill 363 186 568 366 186 568 minecraft:oak_leaves[persistent=true]
fill 363 186 574 367 186 574 minecraft:oak_leaves[persistent=true]
fill 363 186 597 363 188 597 minecraft:green_terracotta
fill 364 186 575 365 186 575 minecraft:oak_leaves[persistent=true]
setblock 365 186 559 minecraft:oak_log
setblock 366 186 558 minecraft:oak_log
setblock 366 186 597 minecraft:green_terracotta
setblock 366 186 598 minecraft:oak_log
fill 367 186 558 367 188 558 minecraft:green_terracotta
fill 367 186 598 367 188 598 minecraft:green_terracotta
setblock 368 186 571 minecraft:oak_log
setblock 368 186 572 minecraft:green_terracotta
setblock 369 186 570 minecraft:oak_log
fill 369 186 571 369 188 571 minecraft:green_terracotta
setblock 370 186 559 minecraft:oak_log
fill 370 186 560 370 188 561 minecraft:green_terracotta
setblock 370 186 564 minecraft:oak_log
fill 370 186 565 370 188 565 minecraft:green_terracotta
setblock 370 186 569 minecraft:oak_log
fill 370 186 570 370 188 570 minecraft:green_terracotta
setblock 370 186 574 minecraft:oak_log
fill 370 186 575 370 188 575 minecraft:green_terracotta
setblock 370 186 587 minecraft:oak_leaves[persistent=true]
fill 370 186 592 370 186 593 minecraft:green_terracotta
setblock 370 186 594 minecraft:oak_log
fill 370 186 595 370 188 595 minecraft:green_terracotta
setblock 330 187 558 minecraft:oak_log
fill 330 187 559 330 188 559 minecraft:green_terracotta
setblock 330 187 569 minecraft:oak_leaves[persistent=true]
setblock 330 187 573 minecraft:oak_log
fill 330 187 574 330 188 574 minecraft:green_terracotta
fill 330 187 575 330 188 575 minecraft:oak_leaves[persistent=true]
setblock 330 187 593 minecraft:oak_log
fill 330 187 594 330 188 594 minecraft:green_terracotta
setblock 330 187 597 minecraft:green_terracotta
setblock 330 187 598 minecraft:oak_log
fill 331 187 558 334 187 558 minecraft:green_terracotta
setblock 331 187 591 minecraft:green_terracotta
setblock 331 187 592 minecraft:oak_log
fill 331 187 593 331 188 593 minecraft:green_terracotta
setblock 331 187 597 minecraft:oak_log
fill 331 187 598 331 188 598 minecraft:green_terracotta
fill 332 187 594 332 187 595 minecraft:green_terracotta
setblock 332 187 596 minecraft:oak_log
fill 332 187 597 332 188 597 minecraft:green_terracotta
fill 333 187 596 336 187 596 minecraft:green_terracotta
setblock 335 187 558 minecraft:oak_log
fill 335 187 595 337 187 595 minecraft:green_terracotta
setblock 335 187 598 minecraft:oak_log
fill 336 187 558 339 187 558 minecraft:green_terracotta
setblock 336 187 597 minecraft:oak_log
fill 336 187 598 336 188 598 minecraft:green_terracotta
setblock 337 187 596 minecraft:oak_log
fill 337 187 597 337 188 597 minecraft:green_terracotta
setblock 338 187 594 minecraft:green_terracotta
setblock 338 187 595 minecraft:oak_log
fill 338 187 596 338 188 596 minecraft:green_terracotta
setblock 339 187 559 minecraft:oak_log
setblock 339 187 594 minecraft:oak_log
fill 339 187 595 339 188 595 minecraft:green_terracotta
setblock 340 187 558 minecraft:oak_log
fill 340 187 559 340 188 559 minecraft:green_terracotta
fill 340 187 594 340 188 594 minecraft:green_terracotta
setblock 340 187 598 minecraft:oak_log
fill 341 187 558 341 188 558 minecraft:green_terracotta
setblock 341 187 597 minecraft:oak_log
fill 341 187 598 341 188 598 minecraft:green_terracotta
setblock 342 187 596 minecraft:oak_log
fill 342 187 597 342 188 597 minecraft:green_terracotta
setblock 343 187 595 minecraft:oak_log
fill 343 187 596 343 188 596 minecraft:green_terracotta
setblock 344 187 595 minecraft:green_terracotta
setblock 345 187 598 minecraft:oak_log
setblock 346 187 597 minecraft:oak_log
fill 346 187 598 346 188 598 minecraft:green_terracotta
setblock 347 187 577 minecraft:oak_leaves[persistent=true]
fill 347 187 597 347 188 597 minecraft:green_terracotta
setblock 349 187 558 minecraft:oak_leaves[persistent=true]
setblock 349 187 581 minecraft:oak_leaves[persistent=true]
setblock 350 187 598 minecraft:oak_log
setblock 351 187 598 minecraft:oak_leaves[persistent=true]
fill 353 187 598 354 187 598 minecraft:green_terracotta
setblock 355 187 598 minecraft:oak_log
fill 356 187 558 359 187 558 minecraft:green_terracotta
setblock 356 187 597 minecraft:oak_log
fill 356 187 598 359 187 598 minecraft:green_terracotta
fill 357 187 597 360 187 597 minecraft:green_terracotta
setblock 359 187 559 minecraft:oak_log
fill 359 187 596 361 187 596 minecraft:green_terracotta
setblock 360 187 558 minecraft:oak_log
fill 360 187 559 360 188 559 minecraft:green_terracotta
setblock 360 187 598 minecraft:oak_log
fill 361 187 558 361 188 558 minecraft:green_terracotta
setblock 361 187 597 minecraft:oak_log
fill 361 187 598 361 188 598 minecraft:green_terracotta
fill 362 187 559 363 187 559 minecraft:green_terracotta
fill 362 187 570 362 187 572 minecraft:oak_leaves[persistent=true]
setblock 362 187 596 minecraft:oak_log
fill 362 187 597 362 188 597 minecraft:green_terracotta
fill 363 187 569 366 187 569 minecraft:oak_leaves[persistent=true]
setblock 364 187 559 minecraft:oak_log
fill 364 187 574 366 187 574 minecraft:oak_leaves[persistent=true]
setblock 365 187 558 minecraft:oak_log
fill 365 187 559 366 188 559 minecraft:green_terracotta
setblock 365 187 598 minecraft:oak_log
fill 366 187 558 366 188 558 minecraft:green_terracotta
setblock 366 187 597 minecraft:oak_log
fill 366 187 598 366 188 598 minecraft:green_terracotta
fill 367 187 597 367 188 597 minecraft:green_terracotta
fill 368 187 558 369 187 558 minecraft:green_terracotta
fill 368 187 598 369 187 598 minecraft:green_terracotta
setblock 369 187 569 minecraft:oak_log
fill 369 187 570 369 188 570 minecraft:green_terracotta
setblock 369 187 573 minecraft:green_terracotta
setblock 369 187 574 minecraft:oak_log
setblock 369 187 575 minecraft:green_terracotta
setblock 370 187 558 minecraft:oak_log
fill 370 187 559 370 188 559 minecraft:green_terracotta
setblock 370 187 563 minecraft:oak_log
setblock 370 187 564 minecraft:green_terracotta
setblock 370 187 568 minecraft:oak_log
fill 370 187 569 370 188 569 minecraft:green_terracotta
setblock 370 187 573 minecraft:oak_log
fill 370 187 574 370 188 574 minecraft:green_terracotta
setblock 370 187 581 minecraft:oak_leaves[persistent=true]
setblock 370 187 592 minecraft:green_terracotta
setblock 370 187 593 minecraft:oak_log
fill 370 187 594 370 188 594 minecraft:green_terracotta
setblock 370 187 598 minecraft:oak_log
fill 330 188 558 333 188 558 minecraft:green_terracotta
setblock 330 188 572 minecraft:oak_log
setblock 330 188 573 minecraft:green_terracotta
setblock 330 188 581 minecraft:oak_leaves[persistent=true]
setblock 330 188 592 minecraft:oak_log
setblock 330 188 593 minecraft:green_terracotta
setblock 330 188 596 minecraft:green_terracotta
setblock 330 188 597 minecraft:oak_log
setblock 330 188 598 minecraft:green_terracotta
setblock 331 188 592 minecraft:green_terracotta
setblock 331 188 596 minecraft:oak_log
setblock 331 188 597 minecraft:green_terracotta
setblock 332 188 594 minecraft:green_terracotta
setblock 332 188 595 minecraft:oak_log
fill 332 188 596 335 188 596 minecraft:green_terracotta
setblock 334 188 558 minecraft:oak_log
fill 334 188 595 336 188 595 minecraft:green_terracotta
setblock 334 188 598 minecraft:oak_log
fill 335 188 558 338 188 558 minecraft:green_terracotta
setblock 335 188 597 minecraft:oak_log
setblock 335 188 598 minecraft:green_terracotta
setblock 336 188 596 minecraft:oak_log
setblock 336 188 597 minecraft:green_terracotta
setblock 337 188 559 minecraft:green_terracotta
setblock 337 188 595 minecraft:oak_log
setblock 337 188 596 minecraft:green_terracotta
setblock 338 188 559 minecraft:oak_log
setblock 338 188 594 minecraft:oak_log
setblock 338 188 595 minecraft:green_terracotta
setblock 339 188 558 minecraft:oak_log
setblock 339 188 559 minecraft:green_terracotta
setblock 339 188 594 minecraft:green_terracotta
setblock 339 188 598 minecraft:oak_log
setblock 340 188 558 minecraft:green_terracotta
setblock 340 188 597 minecraft:oak_log
setblock 340 188 598 minecraft:green_terracotta
setblock 341 188 596 minecraft:oak_log
setblock 341 188 597 minecraft:green_terracotta
setblock 342 188 595 minecraft:oak_log
setblock 342 188 596 minecraft:green_terracotta
setblock 343 188 558 minecraft:green_terracotta
setblock 343 188 595 minecraft:green_terracotta
setblock 344 188 558 minecraft:oak_log
setblock 344 188 598 minecraft:oak_log
setblock 345 188 597 minecraft:oak_log
setblock 345 188 598 minecraft:green_terracotta
setblock 346 188 597 minecraft:green_terracotta
setblock 349 188 598 minecraft:oak_log
fill 350 188 598 353 188 598 minecraft:green_terracotta
setblock 354 188 598 minecraft:oak_log
fill 355 188 558 358 188 558 minecraft:green_terracotta
setblock 355 188 597 minecraft:oak_log
fill 355 188 598 358 188 598 minecraft:green_terracotta
fill 356 188 597 359 188 597 minecraft:green_terracotta
setblock 358 188 559 minecraft:oak_log
setblock 359 188 558 minecraft:oak_log
setblock 359 188 559 minecraft:green_terracotta
fill 359 188 596 360 188 596 minecraft:green_terracotta
setblock 359 188 598 minecraft:oak_log
setblock 360 188 558 minecraft:green_terracotta
setblock 360 188 597 minecraft:oak_log
setblock 360 188 598 minecraft:green_terracotta
setblock 361 188 596 minecraft:oak_log
setblock 361 188 597 minecraft:green_terracotta
setblock 362 188 559 minecraft:green_terracotta
setblock 362 188 596 minecraft:green_terracotta
setblock 363 188 559 minecraft:oak_log
setblock 364 188 558 minecraft:oak_log
setblock 364 188 559 minecraft:green_terracotta
setblock 364 188 597 minecraft:green_terracotta
setblock 364 188 598 minecraft:oak_log
setblock 365 188 558 minecraft:green_terracotta
setblock 365 188 597 minecraft:oak_log
setblock 365 188 598 minecraft:green_terracotta
setblock 366 188 597 minecraft:green_terracotta
setblock 368 188 558 minecraft:green_terracotta
fill 368 188 597 368 188 598 minecraft:green_terracotta
setblock 369 188 558 minecraft:oak_log
setblock 369 188 573 minecraft:oak_log
setblock 369 188 574 minecraft:green_terracotta
setblock 369 188 598 minecraft:oak_log
setblock 370 188 558 minecraft:green_terracotta
setblock 370 188 562 minecraft:oak_log
setblock 370 188 567 minecraft:oak_log
setblock 370 188 568 minecraft:green_terracotta
setblock 370 188 572 minecraft:oak_log
setblock 370 188 573 minecraft:green_terracotta
setblock 370 188 577 minecraft:oak_log
setblock 370 188 592 minecraft:oak_log
setblock 370 188 593 minecraft:green_terracotta
setblock 370 188 596 minecraft:green_terracotta
setblock 370 188 597 minecraft:oak_log
setblock 370 188 598 minecraft:green_terracotta
fill 339 189 577 345 206 579 minecraft:jungle_log
fill 340 189 576 344 207 576 minecraft:jungle_log
fill 340 189 580 344 207 580 minecraft:jungle_log
fill 341 189 575 343 207 575 minecraft:jungle_log
fill 341 189 581 343 207 581 minecraft:jungle_log
setblock 332 192 560 minecraft:light[level=14]
setblock 332 192 568 minecraft:light[level=14]
setblock 332 192 576 minecraft:light[level=14]
setblock 332 192 584 minecraft:light[level=14]
setblock 332 192 592 minecraft:light[level=14]
setblock 340 192 560 minecraft:light[level=14]
setblock 340 192 568 minecraft:light[level=14]
setblock 340 192 584 minecraft:light[level=14]
setblock 340 192 592 minecraft:light[level=14]
setblock 348 192 560 minecraft:light[level=14]
setblock 348 192 568 minecraft:light[level=14]
setblock 348 192 576 minecraft:light[level=14]
setblock 348 192 584 minecraft:light[level=14]
setblock 348 192 592 minecraft:light[level=14]
setblock 356 192 560 minecraft:light[level=14]
setblock 356 192 568 minecraft:light[level=14]
setblock 356 192 576 minecraft:light[level=14]
setblock 356 192 584 minecraft:light[level=14]
setblock 356 192 592 minecraft:light[level=14]
setblock 364 192 560 minecraft:light[level=14]
setblock 364 192 568 minecraft:light[level=14]
setblock 364 192 576 minecraft:light[level=14]
setblock 364 192 584 minecraft:light[level=14]
setblock 364 192 592 minecraft:light[level=14]
fill 345 193 576 347 193 576 minecraft:dark_oak_log
fill 345 193 580 347 193 580 minecraft:dark_oak_log
fill 346 193 574 348 193 575 minecraft:dark_oak_log
fill 346 193 577 347 193 579 minecraft:dark_oak_log
fill 346 193 581 347 193 582 minecraft:dark_oak_log
fill 347 193 572 348 194 573 minecraft:dark_oak_log
fill 347 193 583 350 193 584 minecraft:dark_oak_log
fill 348 193 580 350 193 582 minecraft:redstone_block
fill 349 193 571 357 193 572 minecraft:dark_oak_log
fill 349 193 573 351 193 575 minecraft:redstone_block
fill 349 193 585 357 193 585 minecraft:dark_oak_log
fill 351 193 570 355 197 570 minecraft:dark_oak_log
fill 351 193 584 359 193 584 minecraft:dark_oak_log
fill 351 193 586 355 197 586 minecraft:dark_oak_log
fill 355 193 573 357 193 575 minecraft:redstone_block
fill 356 193 580 358 193 582 minecraft:redstone_block
fill 356 193 583 359 193 583 minecraft:dark_oak_log
fill 358 193 572 359 193 575 minecraft:dark_oak_log
fill 359 193 576 360 193 582 minecraft:dark_oak_log
fill 360 193 574 360 197 575 minecraft:dark_oak_log
fill 361 193 576 361 197 580 minecraft:dark_oak_log
fill 345 194 574 346 196 576 minecraft:dark_oak_log
fill 345 194 580 346 196 582 minecraft:dark_oak_log
fill 346 194 572 346 196 573 minecraft:dark_oak_log
fill 346 194 577 346 197 577 minecraft:dark_oak_log
fill 346 194 578 351 194 578 minecraft:stripped_oak_log
fill 346 194 579 346 197 579 minecraft:dark_oak_log
fill 346 194 583 348 194 584 minecraft:dark_oak_log
fill 347 194 571 352 196 571 minecraft:dark_oak_log
fill 347 194 574 347 197 574 minecraft:dark_oak_log
fill 347 194 575 348 194 577 minecraft:stripped_oak_log
fill 347 194 579 347 194 581 minecraft:stripped_oak_log
setblock 347 194 582 minecraft:dark_oak_log
fill 347 194 585 352 196 585 minecraft:dark_oak_log
setblock 348 194 574 minecraft:stripped_oak_log
fill 348 194 579 351 194 579 minecraft:stripped_oak_log
fill 349 194 570 350 196 570 minecraft:dark_oak_log
setblock 349 194 572 minecraft:dark_oak_log
fill 349 194 576 351 194 577 minecraft:stripped_oak_log
fill 349 194 583 357 194 583 minecraft:stripped_oak_log
fill 349 194 584 349 197 584 minecraft:dark_oak_log
fill 349 194 586 350 196 586 minecraft:dark_oak_log
fill 350 194 572 356 194 572 minecraft:stripped_oak_log
fill 350 194 584 356 195 584 minecraft:stripped_oak_log
fill 351 194 569 355 196 569 minecraft:dark_oak_log
fill 351 194 580 355 194 582 minecraft:stripped_oak_log
fill 351 194 587 355 196 587 minecraft:dark_oak_log
fill 352 194 573 354 194 576 minecraft:stripped_oak_log
fill 353 194 571 353 195 571 minecraft:stripped_oak_log
fill 353 194 585 353 195 585 minecraft:stripped_oak_log
fill 354 194 571 359 196 571 minecraft:dark_oak_log
fill 354 194 585 359 196 585 minecraft:dark_oak_log
fill 355 194 576 359 194 579 minecraft:stripped_oak_log
fill 356 194 570 357 196 570 minecraft:dark_oak_log
fill 356 194 586 357 196 586 minecraft:dark_oak_log
fill 357 194 572 360 194 572 minecraft:dark_oak_log
fill 357 194 584 360 196 584 minecraft:dark_oak_log
fill 358 194 573 360 194 573 minecraft:dark_oak_log
fill 358 194 574 358 194 575 minecraft:stripped_oak_log
fill 358 194 583 360 194 583 minecraft:dark_oak_log
fill 359 194 574 359 197 574 minecraft:dark_oak_log
fill 359 194 575 359 195 575 minecraft:stripped_oak_log
fill 359 194 580 359 194 581 minecraft:stripped_oak_log
fill 359 194 582 361 194 582 minecraft:dark_oak_log
fill 360 194 576 360 197 577 minecraft:dark_oak_log
fill 360 194 578 360 195 578 minecraft:stripped_oak_log
fill 360 194 579 360 197 581 minecraft:dark_oak_log
fill 361 194 574 361 196 575 minecraft:dark_oak_log
fill 361 194 581 361 196 581 minecraft:dark_oak_log
fill 362 194 576 362 196 580 minecraft:dark_oak_log
fill 330 195 558 338 195 598 minecraft:oak_log
fill 339 195 558 339 195 576 minecraft:oak_log
fill 339 195 580 339 195 598 minecraft:oak_log
fill 340 195 558 340 195 575 minecraft:oak_log
fill 340 195 581 340 195 598 minecraft:oak_log
fill 341 195 558 344 195 574 minecraft:oak_log
fill 341 195 582 344 195 598 minecraft:oak_log
setblock 344 195 575 minecraft:dark_oak_log
setblock 344 195 581 minecraft:dark_oak_log
fill 345 195 558 345 195 572 minecraft:oak_log
setblock 345 195 573 minecraft:dark_oak_log
fill 345 195 583 346 195 583 minecraft:dark_oak_log
fill 345 195 584 345 195 598 minecraft:oak_log
fill 346 195 558 346 195 571 minecraft:oak_log
fill 346 195 578 350 195 578 minecraft:stripped_oak_log
fill 346 195 584 348 196 584 minecraft:dark_oak_log
fill 346 195 585 346 195 598 minecraft:oak_log
fill 347 195 558 347 195 570 minecraft:oak_log
fill 347 195 572 347 197 573 minecraft:dark_oak_log
fill 347 195 575 347 195 577 minecraft:stripped_oak_log
fill 347 195 579 347 195 583 minecraft:ochre_froglight
fill 347 195 586 347 195 598 minecraft:oak_log
fill 348 195 558 349 195 569 minecraft:oak_log
setblock 348 195 570 minecraft:dark_oak_log
fill 348 195 572 348 195 576 minecraft:ochre_froglight
fill 348 195 577 350 195 577 minecraft:stripped_oak_log
fill 348 195 579 351 195 579 minecraft:ochre_froglight
fill 348 195 580 350 195 582 minecraft:oak_log
fill 348 195 583 351 195 583 minecraft:ochre_froglight
setblock 348 195 586 minecraft:dark_oak_log
fill 348 195 587 349 195 598 minecraft:oak_log
fill 349 195 572 352 195 572 minecraft:ochre_froglight
fill 349 195 573 351 195 575 minecraft:oak_log
fill 349 195 576 358 195 576 minecraft:ochre_froglight
fill 350 195 558 370 195 568 minecraft:oak_log
setblock 350 195 569 minecraft:dark_oak_log
setblock 350 195 587 minecraft:dark_oak_log
fill 350 195 588 370 195 598 minecraft:oak_log
fill 351 195 577 351 195 578 minecraft:ochre_froglight
fill 351 195 580 351 195 582 minecraft:ochre_froglight
fill 352 195 573 352 195 575 minecraft:ochre_froglight
fill 352 195 580 355 195 580 minecraft:ochre_froglight
fill 352 195 581 354 195 583 minecraft:stripped_oak_log
fill 353 195 572 353 195 575 minecraft:stripped_oak_log
fill 354 195 572 354 195 575 minecraft:ochre_froglight
fill 355 195 572 358 195 572 minecraft:ochre_froglight
fill 355 195 573 357 195 575 minecraft:oak_log
fill 355 195 577 355 195 579 minecraft:ochre_froglight
fill 355 195 581 355 195 583 minecraft:ochre_froglight
setblock 356 195 569 minecraft:dark_oak_log
fill 356 195 577 359 195 578 minecraft:stripped_oak_log
fill 356 195 579 359 195 579 minecraft:ochre_froglight
fill 356 195 580 358 195 582 minecraft:oak_log
fill 356 195 583 359 195 583 minecraft:ochre_froglight
setblock 356 195 587 minecraft:dark_oak_log
fill 357 195 569 370 195 569 minecraft:oak_log
fill 357 195 587 370 195 587 minecraft:oak_log
setblock 358 195 570 minecraft:dark_oak_log
fill 358 195 573 358 195 575 minecraft:ochre_froglight
setblock 358 195 586 minecraft:dark_oak_log
fill 359 195 570 370 195 570 minecraft:oak_log
fill 359 195 572 360 196 573 minecraft:dark_oak_log
setblock 359 195 576 minecraft:stripped_oak_log
fill 359 195 580 359 195 582 minecraft:ochre_froglight
fill 359 195 586 370 195 586 minecraft:oak_log
fill 360 195 571 370 195 571 minecraft:oak_log
fill 360 195 582 361 195 583 minecraft:dark_oak_log
fill 360 195 585 370 195 585 minecraft:oak_log
fill 361 195 572 370 195 572 minecraft:oak_log
setblock 361 195 573 minecraft:dark_oak_log
fill 361 195 584 370 195 584 minecraft:oak_log
fill 362 195 573 370 195 574 minecraft:oak_log
setblock 362 195 575 minecraft:dark_oak_log
setblock 362 195 581 minecraft:dark_oak_log
fill 362 195 582 370 195 583 minecraft:oak_log
fill 363 195 575 370 195 581 minecraft:oak_log
fill 346 196 578 348 196 578 minecraft:dark_oak_log
fill 346 196 583 360 196 583 minecraft:dark_oak_log
fill 347 196 575 348 196 577 minecraft:dark_oak_log
fill 347 196 579 348 196 582 minecraft:dark_oak_log
fill 348 196 572 350 196 574 minecraft:dark_oak_log
setblock 349 196 575 minecraft:dark_oak_log
fill 349 196 581 349 196 582 minecraft:dark_oak_log
setblock 350 196 582 minecraft:dark_oak_log
fill 350 196 584 356 197 584 minecraft:dark_oak_log
fill 351 196 572 358 196 573 minecraft:dark_oak_log
fill 353 196 571 353 197 571 minecraft:dark_oak_log
fill 353 196 585 353 197 585 minecraft:dark_oak_log
fill 356 196 574 358 196 574 minecraft:dark_oak_log
fill 356 196 582 361 196 582 minecraft:dark_oak_log
fill 357 196 575 359 196 575 minecraft:dark_oak_log
fill 357 196 581 359 196 581 minecraft:dark_oak_log
fill 358 196 576 359 196 580 minecraft:dark_oak_log
fill 360 196 578 360 197 578 minecraft:dark_oak_log
fill 345 197 576 347 197 576 minecraft:dark_oak_log
fill 345 197 580 347 197 580 minecraft:dark_oak_log
fill 346 197 574 346 197 575 minecraft:dark_oak_log
fill 346 197 578 347 197 578 minecraft:dark_oak_log
fill 346 197 581 348 197 582 minecraft:dark_oak_log
fill 347 197 575 348 197 575 minecraft:dark_oak_log
setblock 347 197 577 minecraft:dark_oak_log
setblock 347 197 579 minecraft:dark_oak_log
fill 347 197 583 348 197 584 minecraft:dark_oak_log
fill 348 197 572 349 197 574 minecraft:dark_oak_log
fill 349 197 571 352 197 571 minecraft:dark_oak_log
fill 349 197 582 349 197 583 minecraft:dark_oak_log
fill 349 197 585 352 197 585 minecraft:dark_oak_log
fill 350 197 572 350 197 573 minecraft:dark_oak_log
setblock 350 197 583 minecraft:dark_oak_log
fill 351 197 572 359 197 572 minecraft:dark_oak_log
fill 354 197 571 357 197 571 minecraft:dark_oak_log
fill 354 197 585 357 197 585 minecraft:dark_oak_log
fill 356 197 573 359 197 573 minecraft:dark_oak_log
fill 356 197 583 359 197 583 minecraft:dark_oak_log
fill 357 197 574 358 197 574 minecraft:dark_oak_log
fill 357 197 582 360 197 582 minecraft:dark_oak_log
fill 357 197 584 359 197 584 minecraft:dark_oak_log
fill 358 197 575 359 197 575 minecraft:dark_oak_log
fill 358 197 581 359 197 581 minecraft:dark_oak_log
fill 359 197 576 359 197 580 minecraft:dark_oak_log
fill 330 199 558 330 199 560 minecraft:green_terracotta
setblock 330 199 561 minecraft:oak_log
fill 330 199 562 330 199 565 minecraft:green_terracotta
setblock 330 199 575 minecraft:green_terracotta
setblock 330 199 576 minecraft:oak_log
fill 330 199 577 330 199 580 minecraft:green_terracotta
setblock 330 199 581 minecraft:oak_log
fill 330 199 582 330 199 585 minecraft:green_terracotta
setblock 330 199 586 minecraft:oak_log
fill 330 199 587 330 199 590 minecraft:green_terracotta
setblock 330 199 591 minecraft:oak_log
fill 330 199 592 330 199 595 minecraft:green_terracotta
setblock 330 199 596 minecraft:oak_log
fill 330 199 597 332 199 598 minecraft:green_terracotta
fill 331 199 558 331 199 559 minecraft:green_terracotta
setblock 331 199 560 minecraft:oak_log
fill 331 199 561 331 200 563 minecraft:green_terracotta
fill 331 199 577 331 199 579 minecraft:green_terracotta
setblock 331 199 580 minecraft:oak_log
fill 331 199 581 331 199 584 minecraft:green_terracotta
setblock 331 199 585 minecraft:oak_log
fill 331 199 586 331 199 589 minecraft:green_terracotta
setblock 331 199 590 minecraft:oak_log
fill 331 199 591 331 199 594 minecraft:green_terracotta
setblock 331 199 595 minecraft:oak_log
fill 331 199 596 331 202 596 minecraft:green_terracotta
setblock 332 199 558 minecraft:green_terracotta
setblock 332 199 559 minecraft:oak_log
fill 332 199 560 334 200 560 minecraft:green_terracotta
fill 332 199 564 332 201 564 minecraft:oak_leaves[persistent=true]
setblock 332 199 578 minecraft:green_terracotta
setblock 332 199 579 minecraft:oak_log
fill 332 199 580 332 199 583 minecraft:green_terracotta
setblock 332 199 584 minecraft:oak_log
fill 332 199 585 332 199 588 minecraft:green_terracotta
setblock 332 199 589 minecraft:oak_log
setblock 333 199 558 minecraft:oak_log
fill 333 199 559 336 199 559 minecraft:green_terracotta
fill 333 199 580 333 199 582 minecraft:green_terracotta
setblock 333 199 583 minecraft:oak_log
fill 333 199 584 333 200 586 minecraft:green_terracotta
fill 333 199 596 333 199 597 minecraft:green_terracotta
setblock 333 199 598 minecraft:oak_log
fill 334 199 558 337 199 558 minecraft:green_terracotta
setblock 334 199 597 minecraft:oak_log
fill 334 199 598 337 199 598 minecraft:green_terracotta
fill 335 199 597 337 199 597 minecraft:green_terracotta
setblock 337 199 559 minecraft:oak_log
fill 337 199 564 337 200 564 minecraft:iron_block
setblock 338 199 558 minecraft:oak_log
setblock 338 199 559 minecraft:green_terracotta
setblock 338 199 598 minecraft:oak_log
fill 339 199 558 340 200 558 minecraft:green_terracotta
fill 339 199 598 339 200 598 minecraft:green_terracotta
setblock 347 199 558 minecraft:green_terracotta
setblock 348 199 558 minecraft:oak_log
fill 349 199 558 351 199 559 minecraft:green_terracotta
setblock 350 199 560 minecraft:green_terracotta
fill 350 199 598 352 199 598 minecraft:green_terracotta
setblock 351 199 560 minecraft:oak_log
setblock 352 199 558 minecraft:green_terracotta
setblock 352 199 559 minecraft:oak_log
fill 352 199 560 354 199 561 minecraft:green_terracotta
setblock 353 199 558 minecraft:oak_log
fill 353 199 559 356 199 559 minecraft:green_terracotta
setblock 353 199 598 minecraft:oak_log
fill 354 199 558 357 199 558 minecraft:green_terracotta
fill 354 199 598 357 199 598 minecraft:green_terracotta
setblock 355 199 560 minecraft:green_terracotta
setblock 355 199 561 minecraft:oak_log
setblock 356 199 560 minecraft:oak_log
fill 356 199 561 358 200 561 minecraft:green_terracotta
setblock 357 199 559 minecraft:oak_log
fill 357 199 560 360 199 560 minecraft:green_terracotta
setblock 358 199 558 minecraft:oak_log
fill 358 199 559 361 199 559 minecraft:green_terracotta
setblock 358 199 598 minecraft:oak_log
fill 359 199 558 362 199 558 minecraft:green_terracotta
fill 359 199 595 359 206 595 minecraft:iron_block
fill 359 199 598 362 199 598 minecraft:green_terracotta
setblock 361 199 560 minecraft:oak_log
setblock 362 199 559 minecraft:oak_log
fill 362 199 560 362 202 560 minecraft:green_terracotta
setblock 363 199 558 minecraft:oak_log
fill 363 199 559 366 199 559 minecraft:green_terracotta
fill 363 199 572 363 213 572 minecraft:iron_block
setblock 363 199 598 minecraft:oak_log
fill 364 199 558 367 199 558 minecraft:green_terracotta
fill 364 199 598 367 199 598 minecraft:green_terracotta
setblock 367 199 559 minecraft:oak_log
fill 367 199 560 370 199 560 minecraft:green_terracotta
setblock 368 199 558 minecraft:oak_log
fill 368 199 559 370 200 559 minecraft:green_terracotta
fill 368 199 561 369 199 561 minecraft:green_terracotta
setblock 368 199 598 minecraft:oak_log
fill 369 199 558 370 201 558 minecraft:green_terracotta
setblock 369 199 562 minecraft:oak_log
fill 369 199 563 370 200 564 minecraft:green_terracotta
setblock 369 199 597 minecraft:oak_log
fill 369 199 598 370 201 598 minecraft:green_terracotta
setblock 370 199 561 minecraft:oak_log
fill 370 199 562 370 202 562 minecraft:green_terracotta
setblock 370 199 565 minecraft:green_terracotta
setblock 370 199 566 minecraft:oak_log
fill 370 199 567 370 202 567 minecraft:green_terracotta
setblock 370 199 572 minecraft:oak_leaves[persistent=true]
fill 370 199 577 370 199 580 minecraft:green_terracotta
setblock 370 199 581 minecraft:oak_log
fill 370 199 582 370 199 585 minecraft:green_terracotta
setblock 370 199 586 minecraft:oak_log
fill 370 199 587 370 199 590 minecraft:green_terracotta
setblock 370 199 591 minecraft:oak_log
fill 370 199 592 370 199 595 minecraft:green_terracotta
setblock 370 199 596 minecraft:oak_log
fill 370 199 597 370 202 597 minecraft:green_terracotta
fill 330 200 558 330 200 559 minecraft:green_terracotta
setblock 330 200 560 minecraft:oak_log
fill 330 200 561 330 200 564 minecraft:green_terracotta
setblock 330 200 565 minecraft:oak_log
fill 330 200 566 330 202 567 minecraft:green_terracotta
setblock 330 200 575 minecraft:oak_log
fill 330 200 576 330 200 579 minecraft:green_terracotta
setblock 330 200 580 minecraft:oak_log
fill 330 200 581 330 200 584 minecraft:green_terracotta
setblock 330 200 585 minecraft:oak_log
fill 330 200 586 330 200 589 minecraft:green_terracotta
setblock 330 200 590 minecraft:oak_log
fill 330 200 591 330 200 594 minecraft:green_terracotta
setblock 330 200 595 minecraft:oak_log
fill 330 200 596 330 201 598 minecraft:green_terracotta
setblock 331 200 558 minecraft:green_terracotta
setblock 331 200 559 minecraft:oak_log
fill 331 200 560 331 203 560 minecraft:green_terracotta
setblock 331 200 564 minecraft:oak_log
fill 331 200 565 331 203 565 minecraft:green_terracotta
fill 331 200 576 331 200 578 minecraft:green_terracotta
setblock 331 200 579 minecraft:oak_log
fill 331 200 580 331 200 583 minecraft:green_terracotta
setblock 331 200 584 minecraft:oak_log
fill 331 200 585 331 200 588 minecraft:green_terracotta
setblock 331 200 589 minecraft:oak_log
fill 331 200 590 331 200 593 minecraft:green_terracotta
setblock 331 200 594 minecraft:oak_log
fill 331 200 595 331 203 595 minecraft:green_terracotta
fill 331 200 597 331 200 598 minecraft:green_terracotta
setblock 332 200 558 minecraft:oak_log
fill 332 200 559 335 200 559 minecraft:green_terracotta
fill 332 200 561 332 200 562 minecraft:green_terracotta
setblock 332 200 568 minecraft:light[level=14]
setblock 332 200 576 minecraft:light[level=14]
setblock 332 200 578 minecraft:oak_log
fill 332 200 579 332 200 582 minecraft:green_terracotta
setblock 332 200 583 minecraft:oak_log
fill 332 200 584 332 200 587 minecraft:green_terracotta
setblock 332 200 588 minecraft:oak_log
fill 332 200 589 332 200 592 minecraft:green_terracotta
fill 332 200 596 332 200 597 minecraft:green_terracotta
setblock 332 200 598 minecraft:oak_log
fill 333 200 558 336 200 558 minecraft:green_terracotta
fill 333 200 580 333 200 581 minecraft:green_terracotta
setblock 333 200 582 minecraft:oak_log
fill 333 200 583 333 203 583 minecraft:green_terracotta
setblock 333 200 587 minecraft:oak_log
fill 333 200 588 333 203 588 minecraft:green_terracotta
setblock 333 200 597 minecraft:oak_log
fill 333 200 598 336 200 598 minecraft:green_terracotta
fill 334 200 597 336 201 597 minecraft:green_terracotta
fill 336 200 559 336 200 563 minecraft:oak_log
setblock 337 200 558 minecraft:oak_log
fill 337 200 559 337 201 559 minecraft:green_terracotta
fill 337 200 560 339 222 563 minecraft:oak_log
setblock 337 200 598 minecraft:oak_log
fill 338 200 558 338 202 558 minecraft:green_terracotta
fill 338 200 598 338 201 598 minecraft:green_terracotta
setblock 340 200 560 minecraft:light[level=14]
fill 340 200 561 340 225 562 minecraft:oak_log
setblock 340 200 568 minecraft:light[level=14]
setblock 340 200 584 minecraft:light[level=14]
setblock 340 200 592 minecraft:light[level=14]
setblock 341 200 598 minecraft:oak_leaves[persistent=true]
setblock 346 200 558 minecraft:green_terracotta
setblock 347 200 558 minecraft:oak_log
fill 348 200 558 350 200 559 minecraft:green_terracotta
setblock 348 200 560 minecraft:light[level=14]
setblock 348 200 568 minecraft:light[level=14]
setblock 348 200 576 minecraft:light[level=14]
setblock 348 200 584 minecraft:light[level=14]
setblock 348 200 592 minecraft:light[level=14]
setblock 349 200 560 minecraft:green_terracotta
setblock 350 200 560 minecraft:oak_log
fill 350 200 598 351 200 598 minecraft:green_terracotta
setblock 351 200 558 minecraft:green_terracotta
setblock 351 200 559 minecraft:oak_log
fill 351 200 560 353 200 561 minecraft:green_terracotta
setblock 352 200 558 minecraft:oak_log
fill 352 200 559 355 200 559 minecraft:green_terracotta
setblock 352 200 598 minecraft:oak_log
fill 353 200 558 356 200 558 minecraft:green_terracotta
fill 353 200 598 356 200 598 minecraft:green_terracotta
setblock 354 200 560 minecraft:green_terracotta
setblock 354 200 561 minecraft:oak_log
setblock 355 200 560 minecraft:oak_log
fill 355 200 561 355 203 561 minecraft:green_terracotta
setblock 356 200 559 minecraft:oak_log
fill 356 200 560 359 200 560 minecraft:green_terracotta
setblock 356 200 568 minecraft:light[level=14]
setblock 356 200 576 minecraft:light[level=14]
setblock 356 200 584 minecraft:light[level=14]
setblock 356 200 592 minecraft:light[level=14]
setblock 357 200 558 minecraft:oak_log
fill 357 200 559 360 200 559 minecraft:green_terracotta
setblock 357 200 598 minecraft:oak_log
fill 358 200 558 361 200 558 minecraft:green_terracotta
fill 358 200 598 361 200 598 minecraft:green_terracotta
setblock 360 200 560 minecraft:oak_log
setblock 361 200 559 minecraft:oak_log
fill 361 200 560 361 202 560 minecraft:green_terracotta
setblock 362 200 558 minecraft:oak_log
fill 362 200 559 365 200 559 minecraft:green_terracotta
setblock 362 200 598 minecraft:oak_log
fill 363 200 558 366 200 558 minecraft:green_terracotta
fill 363 200 560 364 200 560 minecraft:green_terracotta
fill 363 200 598 366 200 598 minecraft:green_terracotta
setblock 364 200 568 minecraft:light[level=14]
setblock 364 200 576 minecraft:light[level=14]
setblock 364 200 584 minecraft:light[level=14]
setblock 364 200 592 minecraft:light[level=14]
setblock 365 200 560 minecraft:oak_log
setblock 366 200 559 minecraft:oak_log
fill 366 200 560 369 200 560 minecraft:green_terracotta
setblock 367 200 558 minecraft:oak_log
fill 367 200 559 367 203 559 minecraft:green_terracotta
setblock 367 200 598 minecraft:oak_log
fill 368 200 558 368 203 558 minecraft:green_terracotta
setblock 368 200 561 minecraft:green_terracotta
setblock 368 200 562 minecraft:oak_log
fill 368 200 563 368 203 563 minecraft:green_terracotta
setblock 368 200 597 minecraft:oak_log
fill 368 200 598 368 203 598 minecraft:green_terracotta
setblock 369 200 561 minecraft:oak_log
fill 369 200 562 369 203 562 minecraft:green_terracotta
setblock 369 200 565 minecraft:green_terracotta
setblock 369 200 566 minecraft:oak_log
setblock 369 200 581 minecraft:oak_log
fill 369 200 582 369 200 585 minecraft:green_terracotta
setblock 369 200 586 minecraft:oak_log
fill 369 200 587 370 202 587 minecraft:green_terracotta
setblock 369 200 596 minecraft:oak_log
fill 369 200 597 369 203 597 minecraft:green_terracotta
setblock 370 200 560 minecraft:oak_log
fill 370 200 561 370 203 561 minecraft:green_terracotta
setblock 370 200 565 minecraft:oak_log
fill 370 200 566 370 203 566 minecraft:green_terracotta
fill 370 200 568 370 201 568 minecraft:green_terracotta
fill 370 200 576 370 200 579 minecraft:green_terracotta
setblock 370 200 580 minecraft:oak_log
fill 370 200 581 370 200 584 minecraft:green_terracotta
setblock 370 200 585 minecraft:oak_log
fill 370 200 586 370 203 586 minecraft:green_terracotta
fill 370 200 588 370 200 589 minecraft:green_terracotta
setblock 370 200 590 minecraft:oak_log
fill 370 200 591 370 200 594 minecraft:green_terracotta
setblock 370 200 595 minecraft:oak_log
fill 370 200 596 370 203 596 minecraft:green_terracotta
setblock 330 201 558 minecraft:green_terracotta
setblock 330 201 559 minecraft:oak_log
fill 330 201 560 330 201 563 minecraft:green_terracotta
setblock 330 201 564 minecraft:oak_log
fill 330 201 565 330 204 565 minecraft:green_terracotta
setblock 330 201 568 minecraft:green_terracotta
setblock 330 201 569 minecraft:oak_log
setblock 330 201 571 minecraft:oak_leaves[persistent=true]
setblock 330 201 574 minecraft:oak_log
fill 330 201 575 330 201 578 minecraft:green_terracotta
setblock 330 201 579 minecraft:oak_log
fill 330 201 580 330 201 583 minecraft:green_terracotta
setblock 330 201 584 minecraft:oak_log
fill 330 201 585 330 201 588 minecraft:green_terracotta
setblock 330 201 589 minecraft:oak_log
fill 330 201 590 330 201 593 minecraft:green_terracotta
setblock 330 201 594 minecraft:oak_log
fill 330 201 595 330 204 595 minecraft:green_terracotta
setblock 331 201 558 minecraft:oak_log
fill 331 201 559 334 201 559 minecraft:green_terracotta
fill 331 201 561 331 201 562 minecraft:green_terracotta
setblock 331 201 563 minecraft:oak_log
fill 331 201 564 331 204 564 minecraft:green_terracotta
fill 331 201 566 331 202 566 minecraft:green_terracotta
fill 331 201 576 331 201 577 minecraft:green_terracotta
setblock 331 201 578 minecraft:oak_log
fill 331 201 579 331 201 582 minecraft:green_terracotta
setblock 331 201 583 minecraft:oak_log
fill 331 201 584 331 201 587 minecraft:green_terracotta
setblock 331 201 588 minecraft:oak_log
fill 331 201 589 331 201 592 minecraft:green_terracotta
setblock 331 201 593 minecraft:oak_log
fill 331 201 594 331 204 594 minecraft:green_terracotta
setblock 331 201 597 minecraft:green_terracotta
setblock 331 201 598 minecraft:oak_log
fill 332 201 558 335 201 558 minecraft:green_terracotta
fill 332 201 560 332 201 561 minecraft:green_terracotta
setblock 332 201 562 minecraft:oak_log
fill 332 201 563 332 203 563 minecraft:green_terracotta
fill 332 201 578 332 201 581 minecraft:green_terracotta
setblock 332 201 582 minecraft:oak_log
fill 332 201 583 332 201 586 minecraft:green_terracotta
setblock 332 201 587 minecraft:oak_log
fill 332 201 588 332 201 591 minecraft:green_terracotta
setblock 332 201 592 minecraft:oak_log
fill 332 201 593 332 204 593 minecraft:green_terracotta
setblock 332 201 597 minecraft:oak_log
fill 332 201 598 335 201 598 minecraft:green_terracotta
setblock 333 201 560 minecraft:green_terracotta
setblock 333 201 580 minecraft:green_terracotta
setblock 333 201 581 minecraft:oak_log
fill 333 201 582 333 204 582 minecraft:green_terracotta
fill 333 201 584 333 201 585 minecraft:green_terracotta
setblock 333 201 586 minecraft:oak_log
fill 333 201 587 333 204 587 minecraft:green_terracotta
fill 333 201 589 333 202 589 minecraft:green_terracotta
fill 333 201 597 333 203 597 minecraft:green_terracotta
setblock 334 201 560 minecraft:oak_log
fill 334 201 583 334 201 584 minecraft:green_terracotta
setblock 334 201 585 minecraft:oak_log
setblock 335 201 559 minecraft:oak_log
fill 335 201 560 335 202 563 minecraft:dark_oak_log
setblock 336 201 558 minecraft:oak_log
fill 336 201 559 336 202 559 minecraft:green_terracotta
fill 336 201 560 336 225 563 minecraft:oak_log
fill 336 201 564 339 202 564 minecraft:dark_oak_log
setblock 336 201 598 minecraft:oak_log
fill 337 201 558 337 203 558 minecraft:green_terracotta
fill 337 201 598 337 202 598 minecraft:green_terracotta
fill 338 201 559 339 202 559 minecraft:dark_oak_log
setblock 339 201 558 minecraft:green_terracotta
fill 340 201 560 340 202 560 minecraft:dark_oak_log
fill 340 201 563 340 202 563 minecraft:dark_oak_log
fill 341 201 561 341 202 562 minecraft:dark_oak_log
fill 344 201 569 344 202 570 minecraft:glowstone
setblock 345 201 558 minecraft:green_terracotta
setblock 346 201 558 minecraft:oak_log
fill 347 201 558 349 201 559 minecraft:green_terracotta
setblock 347 201 598 minecraft:oak_leaves[persistent=true]
setblock 349 201 560 minecraft:oak_log
setblock 350 201 558 minecraft:green_terracotta
setblock 350 201 559 minecraft:oak_log
fill 350 201 560 352 201 561 minecraft:green_terracotta
setblock 350 201 598 minecraft:green_terracotta
setblock 351 201 558 minecraft:oak_log
fill 351 201 559 354 201 559 minecraft:green_terracotta
setblock 351 201 598 minecraft:oak_log
fill 352 201 558 355 201 558 minecraft:green_terracotta
fill 352 201 598 355 201 598 minecraft:green_terracotta
setblock 353 201 560 minecraft:green_terracotta
setblock 353 201 561 minecraft:oak_log
fill 353 201 562 354 202 562 minecraft:green_terracotta
setblock 354 201 560 minecraft:oak_log
fill 354 201 561 354 204 561 minecraft:green_terracotta
setblock 355 201 559 minecraft:oak_log
fill 355 201 560 358 201 560 minecraft:green_terracotta
setblock 356 201 558 minecraft:oak_log
fill 356 201 559 359 201 559 minecraft:green_terracotta
fill 356 201 561 357 201 561 minecraft:green_terracotta
setblock 356 201 598 minecraft:oak_log
fill 357 201 558 360 201 558 minecraft:green_terracotta
fill 357 201 598 360 201 598 minecraft:green_terracotta
setblock 358 201 561 minecraft:oak_log
setblock 359 201 560 minecraft:oak_log
setblock 360 201 559 minecraft:oak_log
fill 360 201 560 360 203 560 minecraft:green_terracotta
setblock 361 201 558 minecraft:oak_log
fill 361 201 559 364 201 559 minecraft:green_terracotta
fill 362 201 558 365 201 558 minecraft:green_terracotta
setblock 363 201 560 minecraft:green_terracotta
fill 363 201 598 365 201 598 minecraft:green_terracotta
setblock 364 201 560 minecraft:oak_log
setblock 365 201 559 minecraft:oak_log
fill 365 201 560 368 201 560 minecraft:green_terracotta
setblock 366 201 558 minecraft:oak_log
fill 366 201 559 366 204 559 minecraft:green_terracotta
setblock 366 201 598 minecraft:oak_log
fill 367 201 558 367 204 558 minecraft:green_terracotta
fill 367 201 598 367 204 598 minecraft:green_terracotta
fill 368 201 559 369 201 559 minecraft:green_terracotta
setblock 368 201 561 minecraft:oak_log
fill 368 201 562 368 204 562 minecraft:green_terracotta
fill 368 201 564 369 201 564 minecraft:green_terracotta
fill 368 201 597 368 204 597 minecraft:green_terracotta
setblock 369 201 560 minecraft:oak_log
fill 369 201 561 369 204 561 minecraft:green_terracotta
fill 369 201 563 370 201 563 minecraft:green_terracotta
setblock 369 201 565 minecraft:oak_log
fill 369 201 566 369 203 567 minecraft:green_terracotta
setblock 369 201 580 minecraft:oak_log
fill 369 201 581 369 201 584 minecraft:green_terracotta
setblock 369 201 585 minecraft:oak_log
fill 369 201 586 369 204 586 minecraft:green_terracotta
fill 369 201 588 369 201 589 minecraft:green_terracotta
setblock 369 201 590 minecraft:oak_log
fill 369 201 591 370 203 591 minecraft:green_terracotta
setblock 369 201 594 minecraft:green_terracotta
setblock 369 201 595 minecraft:oak_log
fill 369 201 596 369 204 596 minecraft:green_terracotta
setblock 370 201 559 minecraft:oak_log
fill 370 201 560 370 204 560 minecraft:green_terracotta
setblock 370 201 564 minecraft:oak_log
fill 370 201 565 370 204 565 minecraft:green_terracotta
setblock 370 201 569 minecraft:oak_log
fill 370 201 570 370 204 570 minecraft:green_terracotta
fill 370 201 576 370 201 578 minecraft:green_terracotta
setblock 370 201 579 minecraft:oak_log
fill 370 201 580 370 201 583 minecraft:green_terracotta
setblock 370 201 584 minecraft:oak_log
fill 370 201 585 370 204 585 minecraft:green_terracotta
setblock 370 201 588 minecraft:green_terracotta
setblock 370 201 589 minecraft:oak_log
fill 370 201 590 370 204 590 minecraft:green_terracotta
fill 370 201 592 370 201 593 minecraft:green_terracotta
setblock 370 201 594 minecraft:oak_log
fill 370 201 595 370 204 595 minecraft:green_terracotta
setblock 330 202 558 minecraft:oak_log
fill 330 202 559 330 202 562 minecraft:green_terracotta
setblock 330 202 563 minecraft:oak_log
fill 330 202 564 330 205 564 minecraft:green_terracotta
setblock 330 202 568 minecraft:oak_log
fill 330 202 569 330 202 572 minecraft:green_terracotta
setblock 330 202 573 minecraft:oak_log
fill 330 202 574 330 202 577 minecraft:green_terracotta
setblock 330 202 578 minecraft:oak_log
fill 330 202 579 330 202 582 minecraft:green_terracotta
setblock 330 202 583 minecraft:oak_log
fill 330 202 584 330 202 587 minecraft:green_terracotta
setblock 330 202 588 minecraft:oak_log
fill 330 202 589 330 202 592 minecraft:green_terracotta
setblock 330 202 593 minecraft:oak_log
fill 330 202 594 330 205 594 minecraft:green_terracotta
fill 330 202 596 330 202 597 minecraft:green_terracotta
setblock 330 202 598 minecraft:oak_log
fill 331 202 558 333 202 559 minecraft:green_terracotta
setblock 331 202 561 minecraft:green_terracotta
setblock 331 202 562 minecraft:oak_log
fill 331 202 563 331 205 563 minecraft:green_terracotta
setblock 331 202 567 minecraft:oak_log
fill 331 202 568 331 205 568 minecraft:green_terracotta
setblock 331 202 576 minecraft:green_terracotta
setblock 331 202 577 minecraft:oak_log
fill 331 202 578 331 202 581 minecraft:green_terracotta
setblock 331 202 582 minecraft:oak_log
fill 331 202 583 331 202 586 minecraft:green_terracotta
setblock 331 202 587 minecraft:oak_log
fill 331 202 588 331 202 591 minecraft:green_terracotta
setblock 331 202 592 minecraft:oak_log
fill 331 202 593 331 205 593 minecraft:green_terracotta
setblock 331 202 597 minecraft:oak_log
fill 331 202 598 334 202 598 minecraft:green_terracotta
setblock 332 202 560 minecraft:green_terracotta
setblock 332 202 561 minecraft:oak_log
fill 332 202 562 332 203 562 minecraft:green_terracotta
fill 332 202 564 332 203 564 minecraft:green_terracotta
fill 332 202 578 332 202 580 minecraft:green_terracotta
setblock 332 202 581 minecraft:oak_log
fill 332 202 582 332 202 585 minecraft:green_terracotta
setblock 332 202 586 minecraft:oak_log
fill 332 202 587 332 202 590 minecraft:green_terracotta
setblock 332 202 591 minecraft:oak_log
fill 332 202 592 332 205 592 minecraft:green_terracotta
setblock 332 202 594 minecraft:green_terracotta
fill 332 202 597 332 204 597 minecraft:green_terracotta
setblock 333 202 560 minecraft:oak_log
setblock 333 202 580 minecraft:oak_log
fill 333 202 581 333 204 581 minecraft:green_terracotta
setblock 333 202 584 minecraft:green_terracotta
setblock 333 202 585 minecraft:oak_log
fill 333 202 586 334 202 586 minecraft:green_terracotta
setblock 333 202 590 minecraft:oak_log
setblock 334 202 558 minecraft:green_terracotta
setblock 334 202 559 minecraft:oak_log
fill 334 202 560 334 202 563 minecraft:dark_oak_log
setblock 334 202 583 minecraft:green_terracotta
setblock 334 202 584 minecraft:oak_log
fill 334 202 585 334 203 585 minecraft:green_terracotta
fill 334 202 597 335 202 597 minecraft:green_terracotta
setblock 335 202 558 minecraft:oak_log
fill 335 202 559 335 203 559 minecraft:green_terracotta
setblock 335 202 564 minecraft:dark_oak_log
setblock 335 202 598 minecraft:oak_log
fill 336 202 558 336 203 558 minecraft:green_terracotta
fill 336 202 565 340 202 565 minecraft:dark_oak_log
fill 336 202 598 336 203 598 minecraft:green_terracotta
setblock 337 202 559 minecraft:dark_oak_log
fill 339 202 558 340 202 558 minecraft:dark_oak_log
fill 340 202 559 341 202 559 minecraft:dark_oak_log
fill 340 202 564 341 202 564 minecraft:dark_oak_log
setblock 341 202 560 minecraft:dark_oak_log
setblock 341 202 563 minecraft:dark_oak_log
fill 342 202 561 342 202 562 minecraft:dark_oak_log
setblock 345 202 558 minecraft:oak_log
fill 346 202 558 349 202 558 minecraft:green_terracotta
fill 347 202 559 348 202 559 minecraft:green_terracotta
setblock 348 202 560 minecraft:oak_log
setblock 349 202 559 minecraft:oak_log
fill 349 202 560 352 202 560 minecraft:green_terracotta
setblock 349 202 598 minecraft:green_terracotta
setblock 350 202 558 minecraft:oak_log
fill 350 202 559 353 202 559 minecraft:green_terracotta
fill 350 202 561 351 202 561 minecraft:green_terracotta
setblock 350 202 598 minecraft:oak_log
fill 351 202 558 354 202 558 minecraft:green_terracotta
fill 351 202 598 354 202 598 minecraft:green_terracotta
setblock 352 202 561 minecraft:oak_log
fill 352 202 562 352 203 562 minecraft:green_terracotta
setblock 353 202 560 minecraft:oak_log
fill 353 202 561 353 205 561 minecraft:green_terracotta
setblock 354 202 559 minecraft:oak_log
fill 354 202 560 357 202 560 minecraft:green_terracotta
setblock 355 202 558 minecraft:oak_log
fill 355 202 559 358 202 559 minecraft:green_terracotta
setblock 355 202 598 minecraft:oak_log
fill 356 202 558 359 202 558 minecraft:green_terracotta
setblock 356 202 561 minecraft:green_terracotta
fill 356 202 598 359 202 598 minecraft:green_terracotta
setblock 357 202 561 minecraft:oak_log
setblock 358 202 560 minecraft:oak_log
setblock 358 202 561 minecraft:green_terracotta
setblock 359 202 559 minecraft:oak_log
fill 359 202 560 359 203 560 minecraft:green_terracotta
setblock 360 202 558 minecraft:oak_log
fill 360 202 559 363 202 559 minecraft:green_terracotta
fill 361 202 558 364 202 558 minecraft:green_terracotta
fill 361 202 562 364 236 564 minecraft:oak_log
setblock 363 202 560 minecraft:oak_log
setblock 364 202 559 minecraft:oak_log
fill 364 202 560 367 202 560 minecraft:green_terracotta
setblock 364 202 598 minecraft:green_terracotta
setblock 365 202 558 minecraft:oak_log
fill 365 202 559 365 205 559 minecraft:green_terracotta
setblock 365 202 598 minecraft:oak_log
fill 366 202 558 366 205 558 minecraft:green_terracotta
fill 366 202 598 366 205 598 minecraft:green_terracotta
setblock 368 202 559 minecraft:green_terracotta
setblock 368 202 560 minecraft:oak_log
fill 368 202 561 368 205 561 minecraft:green_terracotta
setblock 368 202 564 minecraft:green_terracotta
setblock 368 202 565 minecraft:oak_log
setblock 369 202 558 minecraft:green_terracotta
setblock 369 202 559 minecraft:oak_log
fill 369 202 560 369 205 560 minecraft:green_terracotta
setblock 369 202 563 minecraft:green_terracotta
setblock 369 202 564 minecraft:oak_log
fill 369 202 565 369 205 565 minecraft:green_terracotta
fill 369 202 580 369 202 583 minecraft:green_terracotta
setblock 369 202 584 minecraft:oak_log
fill 369 202 585 369 205 585 minecraft:green_terracotta
setblock 369 202 588 minecraft:green_terracotta
setblock 369 202 589 minecraft:oak_log
fill 369 202 590 369 205 590 minecraft:green_terracotta
fill 369 202 592 369 202 593 minecraft:green_terracotta
setblock 369 202 594 minecraft:oak_log
fill 369 202 595 369 205 595 minecraft:green_terracotta
setblock 369 202 598 minecraft:green_terracotta
setblock 370 202 558 minecraft:oak_log
fill 370 202 559 370 205 559 minecraft:green_terracotta
setblock 370 202 563 minecraft:oak_log
fill 370 202 564 370 205 564 minecraft:green_terracotta
setblock 370 202 568 minecraft:oak_log
fill 370 202 569 370 205 569 minecraft:green_terracotta
fill 370 202 571 370 203 571 minecraft:green_terracotta
fill 370 202 576 370 202 577 minecraft:green_terracotta
setblock 370 202 578 minecraft:oak_log
fill 370 202 579 370 202 582 minecraft:green_terracotta
setblock 370 202 583 minecraft:oak_log
fill 370 202 584 370 205 584 minecraft:green_terracotta
setblock 370 202 588 minecraft:oak_log
fill 370 202 589 370 205 589 minecraft:green_terracotta
setblock 370 202 592 minecraft:green_terracotta
setblock 370 202 593 minecraft:oak_log
fill 370 202 594 370 205 594 minecraft:green_terracotta
setblock 370 202 598 minecraft:oak_log
fill 330 203 558 330 203 561 minecraft:green_terracotta
setblock 330 203 562 minecraft:oak_log
fill 330 203 563 330 206 563 minecraft:green_terracotta
setblock 330 203 566 minecraft:green_terracotta
setblock 330 203 567 minecraft:oak_log
fill 330 203 568 330 203 571 minecraft:green_terracotta
setblock 330 203 572 minecraft:oak_log
fill 330 203 573 330 203 576 minecraft:green_terracotta
setblock 330 203 577 minecraft:oak_log
fill 330 203 578 330 203 581 minecraft:green_terracotta
setblock 330 203 582 minecraft:oak_log
fill 330 203 583 330 203 586 minecraft:green_terracotta
setblock 330 203 587 minecraft:oak_log
fill 330 203 588 330 203 591 minecraft:green_terracotta
setblock 330 203 592 minecraft:oak_log
fill 330 203 593 330 206 593 minecraft:green_terracotta
setblock 330 203 596 minecraft:green_terracotta
setblock 330 203 597 minecraft:oak_log
fill 330 203 598 333 203 598 minecraft:green_terracotta
fill 331 203 558 332 203 559 minecraft:green_terracotta
setblock 331 203 561 minecraft:oak_log
fill 331 203 562 331 206 562 minecraft:green_terracotta
setblock 331 203 566 minecraft:oak_log
fill 331 203 567 331 206 567 minecraft:green_terracotta
fill 331 203 569 331 204 569 minecraft:green_terracotta
setblock 331 203 576 minecraft:oak_log
fill 331 203 577 331 203 580 minecraft:green_terracotta
setblock 331 203 581 minecraft:oak_log
fill 331 203 582 331 203 585 minecraft:green_terracotta
setblock 331 203 586 minecraft:oak_log
fill 331 203 587 331 203 590 minecraft:green_terracotta
setblock 331 203 591 minecraft:oak_log
fill 331 203 592 331 206 592 minecraft:green_terracotta
setblock 331 203 596 minecraft:oak_log
fill 331 203 597 331 205 597 minecraft:green_terracotta
setblock 332 203 561 minecraft:green_terracotta
fill 332 203 578 332 203 579 minecraft:green_terracotta
setblock 332 203 580 minecraft:oak_log
fill 332 203 581 332 203 584 minecraft:green_terracotta
setblock 332 203 585 minecraft:oak_log
fill 332 203 586 332 203 589 minecraft:green_terracotta
setblock 332 203 590 minecraft:oak_log
fill 332 203 591 332 206 591 minecraft:green_terracotta
setblock 333 203 558 minecraft:green_terracotta
setblock 333 203 559 minecraft:oak_log
setblock 333 203 580 minecraft:green_terracotta
setblock 333 203 584 minecraft:oak_log
fill 333 203 585 333 205 586 minecraft:green_terracotta
setblock 333 203 589 minecraft:oak_log
fill 333 203 590 333 204 590 minecraft:green_terracotta
setblock 334 203 558 minecraft:oak_log
setblock 334 203 559 minecraft:green_terracotta
setblock 334 203 584 minecraft:green_terracotta
setblock 334 203 597 minecraft:green_terracotta
setblock 334 203 598 minecraft:oak_log
fill 335 203 558 335 204 558 minecraft:green_terracotta
fill 335 203 598 335 204 598 minecraft:green_terracotta
fill 337 203 564 337 210 564 minecraft:iron_block
setblock 340 203 598 minecraft:oak_leaves[persistent=true]
setblock 341 203 558 minecraft:oak_leaves[persistent=true]
fill 345 203 558 348 203 558 minecraft:green_terracotta
setblock 347 203 559 minecraft:green_terracotta
setblock 348 203 559 minecraft:oak_log
fill 348 203 560 351 203 560 minecraft:green_terracotta
setblock 349 203 558 minecraft:oak_log
fill 349 203 559 352 203 559 minecraft:green_terracotta
fill 349 203 561 350 203 561 minecraft:green_terracotta
fill 350 203 558 353 203 558 minecraft:green_terracotta
fill 350 203 598 353 203 598 minecraft:green_terracotta
setblock 351 203 561 minecraft:oak_log
setblock 352 203 560 minecraft:oak_log
fill 352 203 561 352 205 561 minecraft:green_terracotta
setblock 353 203 559 minecraft:oak_log
fill 353 203 560 356 203 560 minecraft:green_terracotta
setblock 353 203 562 minecraft:green_terracotta
setblock 354 203 558 minecraft:oak_log
fill 354 203 559 357 203 559 minecraft:green_terracotta
setblock 354 203 598 minecraft:oak_log
fill 355 203 558 358 203 558 minecraft:green_terracotta
fill 355 203 598 357 203 598 minecraft:green_terracotta
setblock 356 203 561 minecraft:oak_log
setblock 357 203 560 minecraft:oak_log
setblock 357 203 561 minecraft:green_terracotta
setblock 358 203 559 minecraft:oak_log
fill 358 203 560 358 204 560 minecraft:green_terracotta
setblock 359 203 558 minecraft:oak_log
fill 359 203 559 362 203 559 minecraft:green_terracotta
setblock 359 203 598 minecraft:oak_leaves[persistent=true]
fill 360 203 558 363 203 558 minecraft:green_terracotta
fill 360 203 563 360 204 563 minecraft:dark_oak_log
fill 361 203 561 364 204 561 minecraft:dark_oak_log
fill 361 203 565 364 204 565 minecraft:dark_oak_log
setblock 363 203 559 minecraft:oak_log
setblock 364 203 558 minecraft:oak_log
fill 364 203 559 364 205 559 minecraft:green_terracotta
setblock 364 203 598 minecraft:oak_log
fill 365 203 558 365 206 558 minecraft:green_terracotta
fill 365 203 560 366 203 560 minecraft:green_terracotta
fill 365 203 562 365 204 564 minecraft:dark_oak_log
fill 365 203 598 365 206 598 minecraft:green_terracotta
setblock 367 203 560 minecraft:oak_log
fill 367 203 597 367 205 597 minecraft:green_terracotta
setblock 368 203 559 minecraft:oak_log
fill 368 203 560 368 205 560 minecraft:green_terracotta
setblock 368 203 564 minecraft:oak_log
fill 368 203 565 368 205 565 minecraft:green_terracotta
fill 368 203 585 368 204 587 minecraft:green_terracotta
setblock 369 203 558 minecraft:oak_log
fill 369 203 559 369 206 559 minecraft:green_terracotta
setblock 369 203 563 minecraft:oak_log
fill 369 203 564 369 206 564 minecraft:green_terracotta
setblock 369 203 568 minecraft:oak_log
fill 369 203 580 369 203 582 minecraft:green_terracotta
setblock 369 203 583 minecraft:oak_log
fill 369 203 584 369 206 584 minecraft:green_terracotta
setblock 369 203 587 minecraft:green_terracotta
setblock 369 203 588 minecraft:oak_log
fill 369 203 589 369 206 589 minecraft:green_terracotta
setblock 369 203 592 minecraft:green_terracotta
setblock 369 203 593 minecraft:oak_log
fill 369 203 594 369 206 594 minecraft:green_terracotta
setblock 369 203 598 minecraft:oak_log
fill 370 203 558 370 206 558 minecraft:green_terracotta
setblock 370 203 562 minecraft:oak_log
fill 370 203 563 370 206 563 minecraft:green_terracotta
setblock 370 203 567 minecraft:oak_log
fill 370 203 568 370 206 568 minecraft:green_terracotta
setblock 370 203 573 minecraft:oak_leaves[persistent=true]
setblock 370 203 576 minecraft:green_terracotta
setblock 370 203 577 minecraft:oak_log
fill 370 203 578 370 203 581 minecraft:green_terracotta
setblock 370 203 582 minecraft:oak_log
fill 370 203 583 370 206 583 minecraft:green_terracotta
setblock 370 203 587 minecraft:oak_log
fill 370 203 588 370 206 588 minecraft:green_terracotta
setblock 370 203 592 minecraft:oak_log
fill 370 203 593 370 206 593 minecraft:green_terracotta
setblock 370 203 597 minecraft:oak_log
fill 370 203 598 370 206 598 minecraft:green_terracotta
fill 330 204 558 330 204 560 minecraft:green_terracotta
setblock 330 204 561 minecraft:oak_log
fill 330 204 562 330 207 562 minecraft:green_terracotta
setblock 330 204 566 minecraft:oak_log
fill 330 204 567 330 204 570 minecraft:green_terracotta
setblock 330 204 571 minecraft:oak_log
fill 330 204 572 330 204 575 minecraft:green_terracotta
setblock 330 204 576 minecraft:oak_log
fill 330 204 577 330 204 580 minecraft:green_terracotta
setblock 330 204 581 minecraft:oak_log
fill 330 204 582 330 204 585 minecraft:green_terracotta
setblock 330 204 586 minecraft:oak_log
fill 330 204 587 330 204 590 minecraft:green_terracotta
setblock 330 204 591 minecraft:oak_log
fill 330 204 592 330 207 592 minecraft:green_terracotta
setblock 330 204 596 minecraft:oak_log
fill 330 204 597 330 206 598 minecraft:green_terracotta
fill 331 204 558 331 204 559 minecraft:green_terracotta
setblock 331 204 560 minecraft:oak_log
fill 331 204 561 331 205 561 minecraft:green_terracotta
setblock 331 204 565 minecraft:oak_log
fill 331 204 566 331 207 566 minecraft:green_terracotta
fill 331 204 576 331 204 579 minecraft:green_terracotta
setblock 331 204 580 minecraft:oak_log
fill 331 204 581 331 204 584 minecraft:green_terracotta
setblock 331 204 585 minecraft:oak_log
fill 331 204 586 331 204 589 minecraft:green_terracotta
setblock 331 204 590 minecraft:oak_log
fill 331 204 591 331 207 591 minecraft:green_terracotta
setblock 331 204 595 minecraft:oak_log
fill 331 204 596 331 205 596 minecraft:green_terracotta
fill 331 204 598 332 204 598 minecraft:green_terracotta
setblock 332 204 558 minecraft:green_terracotta
setblock 332 204 559 minecraft:oak_log
fill 332 204 564 332 216 564 minecraft:oak_leaves[persistent=true]
setblock 332 204 579 minecraft:oak_log
fill 332 204 580 332 204 583 minecraft:green_terracotta
setblock 332 204 584 minecraft:oak_log
fill 332 204 585 332 204 588 minecraft:green_terracotta
setblock 332 204 589 minecraft:oak_log
fill 332 204 590 332 207 590 minecraft:green_terracotta
setblock 333 204 558 minecraft:oak_log
setblock 333 204 559 minecraft:green_terracotta
setblock 333 204 583 minecraft:oak_log
fill 333 204 584 333 205 584 minecraft:green_terracotta
setblock 333 204 588 minecraft:oak_log
fill 333 204 589 333 205 589 minecraft:green_terracotta
setblock 333 204 598 minecraft:oak_log
setblock 334 204 558 minecraft:green_terracotta
fill 334 204 598 334 205 598 minecraft:green_terracotta
fill 340 204 573 340 205 573 minecraft:glowstone
fill 346 204 558 347 204 558 minecraft:green_terracotta
setblock 346 204 598 minecraft:oak_leaves[persistent=true]
setblock 347 204 559 minecraft:oak_log
setblock 348 204 558 minecraft:oak_log
fill 348 204 559 350 204 560 minecraft:green_terracotta
fill 349 204 558 352 204 558 minecraft:green_terracotta
setblock 350 204 561 minecraft:oak_log
fill 350 204 598 352 204 598 minecraft:green_terracotta
setblock 351 204 559 minecraft:green_terracotta
setblock 351 204 560 minecraft:oak_log
fill 351 204 561 351 205 561 minecraft:green_terracotta
setblock 352 204 559 minecraft:oak_log
fill 352 204 560 355 204 560 minecraft:green_terracotta
setblock 353 204 558 minecraft:oak_log
fill 353 204 559 356 204 559 minecraft:green_terracotta
setblock 353 204 598 minecraft:oak_log
fill 354 204 558 357 204 558 minecraft:green_terracotta
fill 354 204 598 355 204 598 minecraft:green_terracotta
setblock 355 204 561 minecraft:oak_log
setblock 356 204 560 minecraft:oak_log
setblock 357 204 559 minecraft:oak_log
setblock 357 204 560 minecraft:green_terracotta
setblock 358 204 558 minecraft:oak_log
fill 358 204 559 361 204 559 minecraft:green_terracotta
fill 359 204 558 362 204 558 minecraft:green_terracotta
fill 360 204 561 360 204 562 minecraft:dark_oak_log
fill 360 204 564 360 204 565 minecraft:dark_oak_log
fill 361 204 560 364 204 560 minecraft:dark_oak_log
fill 361 204 566 364 204 566 minecraft:dark_oak_log
setblock 362 204 559 minecraft:oak_log
setblock 363 204 558 minecraft:oak_log
setblock 363 204 559 minecraft:green_terracotta
fill 364 204 558 364 207 558 minecraft:green_terracotta
setblock 364 204 598 minecraft:green_terracotta
setblock 365 204 561 minecraft:dark_oak_log
setblock 365 204 565 minecraft:dark_oak_log
setblock 366 204 560 minecraft:oak_log
fill 366 204 562 366 204 564 minecraft:dark_oak_log
setblock 367 204 559 minecraft:oak_log
setblock 367 204 560 minecraft:green_terracotta
setblock 368 204 558 minecraft:oak_log
fill 368 204 559 368 207 559 minecraft:green_terracotta
setblock 368 204 563 minecraft:oak_log
fill 368 204 564 368 206 564 minecraft:green_terracotta
setblock 368 204 588 minecraft:oak_log
fill 368 204 589 368 206 590 minecraft:green_terracotta
setblock 368 204 598 minecraft:oak_log
fill 369 204 558 369 207 558 minecraft:green_terracotta
setblock 369 204 562 minecraft:oak_log
fill 369 204 563 369 207 563 minecraft:green_terracotta
setblock 369 204 566 minecraft:green_terracotta
setblock 369 204 567 minecraft:oak_log
fill 369 204 568 369 207 568 minecraft:green_terracotta
setblock 369 204 581 minecraft:green_terracotta
setblock 369 204 582 minecraft:oak_log
fill 369 204 583 369 207 583 minecraft:green_terracotta
setblock 369 204 587 minecraft:oak_log
fill 369 204 588 369 207 588 minecraft:green_terracotta
setblock 369 204 591 minecraft:green_terracotta
setblock 369 204 592 minecraft:oak_log
fill 369 204 593 369 207 593 minecraft:green_terracotta
setblock 369 204 597 minecraft:oak_log
fill 369 204 598 369 207 598 minecraft:green_terracotta
setblock 370 204 561 minecraft:oak_log
fill 370 204 562 370 207 562 minecraft:green_terracotta
setblock 370 204 566 minecraft:oak_log
fill 370 204 567 370 207 567 minecraft:green_terracotta
setblock 370 204 571 minecraft:oak_log
fill 370 204 572 370 207 572 minecraft:green_terracotta
fill 370 204 577 370 204 580 minecraft:green_terracotta
setblock 370 204 581 minecraft:oak_log
fill 370 204 582 370 207 582 minecraft:green_terracotta
setblock 370 204 586 minecraft:oak_log
fill 370 204 587 370 207 587 minecraft:green_terracotta
setblock 370 204 591 minecraft:oak_log
fill 370 204 592 370 207 592 minecraft:green_terracotta
setblock 370 204 596 minecraft:oak_log
fill 370 204 597 370 207 597 minecraft:green_terracotta
fill 330 205 558 330 205 559 minecraft:green_terracotta
setblock 330 205 560 minecraft:oak_log
fill 330 205 561 330 208 561 minecraft:green_terracotta
setblock 330 205 565 minecraft:oak_log
fill 330 205 566 330 205 569 minecraft:green_terracotta
setblock 330 205 570 minecraft:oak_log
fill 330 205 571 330 205 574 minecraft:green_terracotta
setblock 330 205 575 minecraft:oak_log
fill 330 205 576 330 205 579 minecraft:green_terracotta
setblock 330 205 580 minecraft:oak_log
fill 330 205 581 330 205 584 minecraft:green_terracotta
setblock 330 205 585 minecraft:oak_log
fill 330 205 586 330 205 589 minecraft:green_terracotta
setblock 330 205 590 minecraft:oak_log
fill 330 205 591 330 208 591 minecraft:green_terracotta
setblock 330 205 595 minecraft:oak_log
fill 330 205 596 330 208 596 minecraft:green_terracotta
setblock 331 205 558 minecraft:green_terracotta
setblock 331 205 560 minecraft:green_terracotta
setblock 331 205 564 minecraft:oak_log
fill 331 205 565 331 207 565 minecraft:green_terracotta
setblock 331 205 569 minecraft:oak_log
fill 331 205 570 331 208 570 minecraft:green_terracotta
fill 331 205 577 331 205 578 minecraft:green_terracotta
setblock 331 205 579 minecraft:oak_log
fill 331 205 580 331 205 583 minecraft:green_terracotta
setblock 331 205 584 minecraft:oak_log
fill 331 205 585 331 205 588 minecraft:green_terracotta
setblock 331 205 589 minecraft:oak_log
fill 331 205 590 331 208 590 minecraft:green_terracotta
setblock 331 205 594 minecraft:oak_log
fill 331 205 595 331 207 595 minecraft:green_terracotta
setblock 331 205 598 minecraft:green_terracotta
setblock 332 205 558 minecraft:oak_log
fill 332 205 580 332 205 582 minecraft:green_terracotta
setblock 332 205 583 minecraft:oak_log
fill 332 205 584 332 205 587 minecraft:green_terracotta
setblock 332 205 588 minecraft:oak_log
fill 332 205 589 332 208 589 minecraft:green_terracotta
setblock 332 205 598 minecraft:oak_log
setblock 333 205 558 minecraft:green_terracotta
fill 333 205 571 336 236 574 minecraft:oak_log
setblock 333 205 583 minecraft:green_terracotta
setblock 333 205 587 minecraft:oak_log
fill 333 205 588 333 206 588 minecraft:green_terracotta
setblock 333 205 598 minecraft:green_terracotta
fill 334 205 570 336 236 570 minecraft:oak_log
fill 337 205 571 337 236 573 minecraft:oak_log
setblock 346 205 558 minecraft:green_terracotta
setblock 347 205 558 minecraft:oak_log
fill 347 205 559 350 205 559 minecraft:green_terracotta
fill 348 205 558 351 205 558 minecraft:green_terracotta
fill 348 205 560 349 205 560 minecraft:green_terracotta
setblock 350 205 560 minecraft:oak_log
setblock 350 205 561 minecraft:green_terracotta
setblock 351 205 559 minecraft:oak_log
fill 351 205 560 354 205 560 minecraft:green_terracotta
setblock 351 205 598 minecraft:green_terracotta
setblock 352 205 558 minecraft:oak_log
fill 352 205 559 355 205 559 minecraft:green_terracotta
setblock 352 205 598 minecraft:oak_log
fill 353 205 558 356 205 558 minecraft:green_terracotta
setblock 355 205 560 minecraft:oak_log
setblock 356 205 559 minecraft:oak_log
setblock 356 205 560 minecraft:green_terracotta
setblock 357 205 558 minecraft:oak_log
fill 357 205 559 358 205 559 minecraft:green_terracotta
fill 358 205 558 361 205 558 minecraft:green_terracotta
setblock 362 205 558 minecraft:oak_log
fill 363 205 558 363 206 558 minecraft:green_terracotta
setblock 366 205 559 minecraft:oak_log
setblock 367 205 558 minecraft:oak_log
fill 367 205 559 367 207 559 minecraft:green_terracotta
setblock 367 205 598 minecraft:oak_log
fill 368 205 558 368 208 558 minecraft:green_terracotta
setblock 368 205 562 minecraft:oak_log
fill 368 205 563 368 206 563 minecraft:green_terracotta
fill 368 205 585 368 205 586 minecraft:green_terracotta
setblock 368 205 587 minecraft:oak_log
fill 368 205 588 368 208 588 minecraft:green_terracotta
setblock 368 205 591 minecraft:green_terracotta
setblock 368 205 597 minecraft:oak_log
fill 368 205 598 368 208 598 minecraft:green_terracotta
setblock 369 205 561 minecraft:oak_log
fill 369 205 562 369 208 562 minecraft:green_terracotta
setblock 369 205 566 minecraft:oak_log
fill 369 205 567 369 208 567 minecraft:green_terracotta
setblock 369 205 581 minecraft:oak_log
fill 369 205 582 369 206 582 minecraft:green_terracotta
setblock 369 205 586 minecraft:oak_log
fill 369 205 587 369 208 587 minecraft:green_terracotta
setblock 369 205 591 minecraft:oak_log
fill 369 205 592 369 208 592 minecraft:green_terracotta
setblock 369 205 596 minecraft:oak_log
fill 369 205 597 369 208 597 minecraft:green_terracotta
setblock 370 205 560 minecraft:oak_log
fill 370 205 561 370 208 561 minecraft:green_terracotta
setblock 370 205 565 minecraft:oak_log
fill 370 205 566 370 208 566 minecraft:green_terracotta
setblock 370 205 570 minecraft:oak_log
fill 370 205 571 370 208 571 minecraft:green_terracotta
fill 370 205 578 370 205 579 minecraft:green_terracotta
setblock 370 205 580 minecraft:oak_log
fill 370 205 581 370 208 581 minecraft:green_terracotta
setblock 370 205 585 minecraft:oak_log
fill 370 205 586 370 208 586 minecraft:green_terracotta
setblock 370 205 590 minecraft:oak_log
fill 370 205 591 370 208 591 minecraft:green_terracotta
setblock 370 205 595 minecraft:oak_log
fill 370 205 596 370 208 596 minecraft:green_terracotta
setblock 330 206 558 minecraft:green_terracotta
setblock 330 206 559 minecraft:oak_log
fill 330 206 560 330 207 560 minecraft:green_terracotta
setblock 330 206 564 minecraft:oak_log
fill 330 206 565 330 206 568 minecraft:green_terracotta
setblock 330 206 569 minecraft:oak_log
fill 330 206 570 330 206 573 minecraft:green_terracotta
setblock 330 206 574 minecraft:oak_log
fill 330 206 575 330 206 578 minecraft:green_terracotta
setblock 330 206 579 minecraft:oak_log
fill 330 206 580 330 206 583 minecraft:green_terracotta
setblock 330 206 584 minecraft:oak_log
fill 330 206 585 330 206 588 minecraft:green_terracotta
setblock 330 206 589 minecraft:oak_log
fill 330 206 590 330 209 590 minecraft:green_terracotta
setblock 330 206 594 minecraft:oak_log
fill 330 206 595 330 209 595 minecraft:green_terracotta
setblock 331 206 558 minecraft:oak_log
setblock 331 206 563 minecraft:oak_log
fill 331 206 564 331 207 564 minecraft:green_terracotta
setblock 331 206 568 minecraft:oak_log
fill 331 206 569 331 209 569 minecraft:green_terracotta
setblock 331 206 578 minecraft:oak_log
fill 331 206 579 331 206 582 minecraft:green_terracotta
setblock 331 206 583 minecraft:oak_log
fill 331 206 584 331 206 587 minecraft:green_terracotta
setblock 331 206 588 minecraft:oak_log
fill 331 206 589 331 209 589 minecraft:green_terracotta
setblock 331 206 593 minecraft:oak_log
fill 331 206 594 331 209 594 minecraft:green_terracotta
setblock 331 206 598 minecraft:oak_log
fill 332 206 570 332 207 574 minecraft:dark_oak_log
setblock 332 206 581 minecraft:green_terracotta
setblock 332 206 582 minecraft:oak_log
fill 332 206 583 332 206 586 minecraft:green_terracotta
setblock 332 206 587 minecraft:oak_log
fill 332 206 588 332 209 588 minecraft:green_terracotta
setblock 332 206 592 minecraft:oak_log
setblock 332 206 598 minecraft:green_terracotta
fill 333 206 569 333 207 570 minecraft:dark_oak_log
fill 333 206 575 336 207 575 minecraft:dark_oak_log
setblock 333 206 585 minecraft:green_terracotta
setblock 333 206 586 minecraft:oak_log
setblock 333 206 587 minecraft:green_terracotta
setblock 333 206 598 minecraft:oak_leaves[persistent=true]
fill 334 206 569 336 207 569 minecraft:dark_oak_log
fill 337 206 570 337 207 570 minecraft:dark_oak_log
fill 337 206 574 337 207 574 minecraft:dark_oak_log
fill 338 206 571 338 207 573 minecraft:dark_oak_log
fill 339 206 598 339 207 598 minecraft:oak_leaves[persistent=true]
fill 340 206 573 340 208 573 minecraft:dark_oak_log
setblock 342 206 558 minecraft:oak_leaves[persistent=true]
setblock 346 206 558 minecraft:oak_log
fill 347 206 558 350 206 558 minecraft:green_terracotta
fill 348 206 559 349 206 559 minecraft:green_terracotta
setblock 349 206 560 minecraft:oak_log
setblock 350 206 559 minecraft:oak_log
fill 350 206 560 353 206 560 minecraft:green_terracotta
setblock 351 206 558 minecraft:oak_log
fill 351 206 559 354 206 559 minecraft:green_terracotta
fill 352 206 558 355 206 558 minecraft:green_terracotta
setblock 355 206 559 minecraft:oak_log
setblock 356 206 558 minecraft:oak_log
setblock 356 206 559 minecraft:green_terracotta
fill 357 206 558 359 206 558 minecraft:green_terracotta
setblock 358 206 598 minecraft:oak_leaves[persistent=true]
setblock 361 206 558 minecraft:oak_log
setblock 362 206 558 minecraft:green_terracotta
setblock 366 206 558 minecraft:oak_log
setblock 366 206 559 minecraft:green_terracotta
setblock 366 206 598 minecraft:oak_log
fill 367 206 558 367 209 558 minecraft:green_terracotta
fill 367 206 598 367 209 598 minecraft:green_terracotta
setblock 368 206 585 minecraft:green_terracotta
setblock 368 206 586 minecraft:oak_log
fill 368 206 587 368 209 587 minecraft:green_terracotta
setblock 368 206 591 minecraft:oak_log
fill 368 206 592 368 209 592 minecraft:green_terracotta
fill 368 206 597 368 209 597 minecraft:green_terracotta
setblock 369 206 560 minecraft:oak_log
fill 369 206 561 369 207 561 minecraft:green_terracotta
setblock 369 206 565 minecraft:oak_log
fill 369 206 566 369 209 566 minecraft:green_terracotta
setblock 369 206 569 minecraft:green_terracotta
setblock 369 206 585 minecraft:oak_log
fill 369 206 586 369 209 586 minecraft:green_terracotta
setblock 369 206 590 minecraft:oak_log
fill 369 206 591 369 209 591 minecraft:green_terracotta
setblock 369 206 595 minecraft:oak_log
fill 369 206 596 369 209 596 minecraft:green_terracotta
setblock 370 206 559 minecraft:oak_log
fill 370 206 560 370 209 560 minecraft:green_terracotta
setblock 370 206 564 minecraft:oak_log
fill 370 206 565 370 209 565 minecraft:green_terracotta
setblock 370 206 569 minecraft:oak_log
fill 370 206 570 370 209 570 minecraft:green_terracotta
setblock 370 206 574 minecraft:oak_leaves[persistent=true]
setblock 370 206 579 minecraft:oak_log
fill 370 206 580 370 208 580 minecraft:green_terracotta
setblock 370 206 584 minecraft:oak_log
fill 370 206 585 370 209 585 minecraft:green_terracotta
setblock 370 206 589 minecraft:oak_log
fill 370 206 590 370 209 590 minecraft:green_terracotta
setblock 370 206 594 minecraft:oak_log
fill 370 206 595 370 209 595 minecraft:green_terracotta
setblock 330 207 563 minecraft:oak_log
fill 330 207 564 330 207 567 minecraft:green_terracotta
setblock 330 207 568 minecraft:oak_log
fill 330 207 569 330 207 572 minecraft:green_terracotta
setblock 330 207 573 minecraft:oak_log
fill 330 207 574 330 207 577 minecraft:green_terracotta
setblock 330 207 578 minecraft:oak_log
fill 330 207 579 330 207 582 minecraft:green_terracotta
setblock 330 207 583 minecraft:oak_log
fill 330 207 584 330 207 587 minecraft:green_terracotta
setblock 330 207 588 minecraft:oak_log
fill 330 207 589 330 210 589 minecraft:green_terracotta
setblock 330 207 593 minecraft:oak_log
fill 330 207 594 330 210 594 minecraft:green_terracotta
setblock 330 207 597 minecraft:green_terracotta
setblock 330 207 598 minecraft:oak_log
setblock 331 207 567 minecraft:oak_log
fill 331 207 568 331 210 568 minecraft:green_terracotta
fill 331 207 571 331 207 574 minecraft:dark_oak_log
fill 331 207 579 331 207 581 minecraft:green_terracotta
setblock 331 207 582 minecraft:oak_log
fill 331 207 583 331 207 586 minecraft:green_terracotta
setblock 331 207 587 minecraft:oak_log
fill 331 207 588 331 210 588 minecraft:green_terracotta
setblock 331 207 592 minecraft:oak_log
fill 331 207 593 331 210 593 minecraft:green_terracotta
setblock 331 207 598 minecraft:green_terracotta
setblock 332 207 569 minecraft:dark_oak_log
setblock 332 207 575 minecraft:dark_oak_log
fill 332 207 582 332 207 585 minecraft:green_terracotta
setblock 332 207 586 minecraft:oak_log
fill 332 207 587 332 210 587 minecraft:green_terracotta
setblock 332 207 591 minecraft:oak_log
setblock 332 207 592 minecraft:green_terracotta
fill 333 207 568 336 207 568 minecraft:dark_oak_log
fill 333 207 576 337 207 576 minecraft:dark_oak_log
fill 333 207 578 333 208 578 minecraft:jungle_log
setblock 336 207 558 minecraft:oak_leaves[persistent=true]
fill 337 207 569 338 207 569 minecraft:dark_oak_log
fill 337 207 575 338 207 575 minecraft:dark_oak_log
fill 337 207 577 338 208 579 minecraft:oak_log
setblock 338 207 570 minecraft:dark_oak_log
fill 338 207 574 340 207 574 minecraft:dark_oak_log
fill 339 207 571 339 207 573 minecraft:dark_oak_log
fill 339 207 577 343 207 579 minecraft:jungle_log
fill 344 207 577 349 207 579 minecraft:jungle_leaves[persistent=true]
fill 345 207 575 349 212 576 minecraft:jungle_leaves[persistent=true]
fill 345 207 580 349 212 581 minecraft:jungle_leaves[persistent=true]
setblock 345 207 598 minecraft:oak_leaves[persistent=true]
fill 346 207 574 354 209 574 minecraft:jungle_leaves[persistent=true]
fill 346 207 582 354 209 582 minecraft:jungle_leaves[persistent=true]
fill 347 207 558 349 207 558 minecraft:green_terracotta
setblock 348 207 559 minecraft:green_terracotta
fill 348 207 573 352 214 573 minecraft:jungle_leaves[persistent=true]
fill 348 207 583 352 214 583 minecraft:jungle_leaves[persistent=true]
setblock 349 207 559 minecraft:oak_log
setblock 350 207 558 minecraft:oak_log
fill 350 207 559 353 207 559 minecraft:green_terracotta
fill 350 207 575 350 211 575 minecraft:jungle_leaves[persistent=true]
fill 350 207 581 350 211 581 minecraft:jungle_leaves[persistent=true]
fill 351 207 558 354 207 558 minecraft:green_terracotta
setblock 354 207 559 minecraft:oak_log
setblock 355 207 558 minecraft:oak_log
setblock 356 207 558 minecraft:green_terracotta
setblock 364 207 598 minecraft:oak_leaves[persistent=true]
setblock 365 207 558 minecraft:oak_log
setblock 365 207 598 minecraft:oak_log
fill 366 207 558 366 210 558 minecraft:green_terracotta
fill 366 207 598 366 210 598 minecraft:green_terracotta
fill 367 207 597 367 210 597 minecraft:green_terracotta
fill 368 207 586 368 210 586 minecraft:green_terracotta
setblock 368 207 589 minecraft:green_terracotta
setblock 368 207 590 minecraft:oak_log
fill 368 207 591 368 210 591 minecraft:green_terracotta
fill 368 207 593 368 208 593 minecraft:green_terracotta
setblock 369 207 559 minecraft:oak_log
setblock 369 207 560 minecraft:green_terracotta
setblock 369 207 564 minecraft:oak_log
fill 369 207 565 369 210 565 minecraft:green_terracotta
setblock 369 207 569 minecraft:oak_log
setblock 369 207 584 minecraft:oak_log
fill 369 207 585 369 210 585 minecraft:green_terracotta
setblock 369 207 589 minecraft:oak_log
fill 369 207 590 369 210 590 minecraft:green_terracotta
setblock 369 207 594 minecraft:oak_log
fill 369 207 595 369 210 595 minecraft:green_terracotta
setblock 370 207 558 minecraft:oak_log
fill 370 207 559 370 209 559 minecraft:green_terracotta
setblock 370 207 563 minecraft:oak_log
fill 370 207 564 370 210 564 minecraft:green_terracotta
setblock 370 207 568 minecraft:oak_log
fill 370 207 569 370 210 569 minecraft:green_terracotta
setblock 370 207 583 minecraft:oak_log
fill 370 207 584 370 210 584 minecraft:green_terracotta
setblock 370 207 588 minecraft:oak_log
fill 370 207 589 370 210 589 minecraft:green_terracotta
setblock 370 207 593 minecraft:oak_log
fill 370 207 594 370 210 594 minecraft:green_terracotta
setblock 370 207 598 minecraft:oak_log
setblock 330 208 562 minecraft:oak_log
fill 330 208 563 330 208 566 minecraft:green_terracotta
setblock 330 208 567 minecraft:oak_log
fill 330 208 568 330 208 571 minecraft:green_terracotta
setblock 330 208 572 minecraft:oak_log
fill 330 208 573 330 208 576 minecraft:green_terracotta
setblock 330 208 577 minecraft:oak_log
fill 330 208 578 330 208 581 minecraft:green_terracotta
setblock 330 208 582 minecraft:oak_log
fill 330 208 583 330 208 586 minecraft:green_terracotta
setblock 330 208 587 minecraft:oak_log
fill 330 208 588 330 211 588 minecraft:green_terracotta
setblock 330 208 592 minecraft:oak_log
fill 330 208 593 330 211 593 minecraft:green_terracotta
setblock 330 208 597 minecraft:oak_log
fill 330 208 598 330 209 598 minecraft:green_terracotta
setblock 331 208 566 minecraft:oak_log
fill 331 208 567 331 210 567 minecraft:green_terracotta
fill 331 208 579 331 211 579 minecraft:iron_block
setblock 331 208 580 minecraft:green_terracotta
setblock 331 208 581 minecraft:oak_log
fill 331 208 582 331 208 585 minecraft:green_terracotta
setblock 331 208 586 minecraft:oak_log
fill 331 208 587 331 211 587 minecraft:green_terracotta
setblock 331 208 591 minecraft:oak_log
fill 331 208 592 331 211 592 minecraft:green_terracotta
setblock 332 208 560 minecraft:light[level=14]
setblock 332 208 568 minecraft:light[level=14]
setblock 332 208 576 minecraft:light[level=14]
setblock 332 208 584 minecraft:green_terracotta
setblock 332 208 585 minecraft:oak_log
fill 332 208 586 332 209 586 minecraft:green_terracotta
setblock 332 208 590 minecraft:oak_log
fill 332 208 591 332 209 591 minecraft:green_terracotta
setblock 332 208 592 minecraft:light[level=14]
fill 334 208 578 336 208 578 minecraft:jungle_log
fill 338 208 571 338 208 572 minecraft:jungle_log
fill 338 208 576 338 209 576 minecraft:dark_oak_log
fill 338 208 580 339 208 580 minecraft:dark_oak_log
fill 338 208 584 338 208 585 minecraft:jungle_log
fill 339 208 572 339 208 573 minecraft:jungle_log
fill 339 208 574 340 208 574 minecraft:dark_oak_log
fill 339 208 577 339 208 579 minecraft:jungle_log
fill 339 208 583 339 208 584 minecraft:jungle_log
setblock 340 208 560 minecraft:light[level=14]
setblock 340 208 568 minecraft:light[level=14]
setblock 340 208 576 minecraft:jungle_log
fill 340 208 577 347 208 579 minecraft:jungle_leaves[persistent=true]
setblock 340 208 580 minecraft:jungle_log
setblock 340 208 584 minecraft:light[level=14]
setblock 340 208 592 minecraft:light[level=14]
fill 341 208 575 344 208 576 minecraft:jungle_leaves[persistent=true]
fill 341 208 580 344 208 581 minecraft:jungle_leaves[persistent=true]
fill 342 208 573 344 208 574 minecraft:jungle_leaves[persistent=true]
fill 342 208 582 344 208 583 minecraft:jungle_leaves[persistent=true]
fill 343 208 572 344 213 572 minecraft:jungle_leaves[persistent=true]
fill 343 208 584 344 213 584 minecraft:jungle_leaves[persistent=true]
fill 345 208 571 345 213 571 minecraft:jungle_leaves[persistent=true]
fill 345 208 572 345 208 573 minecraft:jungle_log
fill 345 208 574 345 217 574 minecraft:jungle_leaves[persistent=true]
fill 345 208 582 345 217 582 minecraft:jungle_leaves[persistent=true]
fill 345 208 583 345 208 584 minecraft:jungle_log
fill 345 208 585 345 213 585 minecraft:jungle_leaves[persistent=true]
fill 346 208 571 346 208 572 minecraft:jungle_log
fill 346 208 573 347 213 573 minecraft:jungle_leaves[persistent=true]
fill 346 208 583 347 213 583 minecraft:jungle_leaves[persistent=true]
fill 346 208 584 346 208 585 minecraft:jungle_log
fill 347 208 558 348 208 558 minecraft:green_terracotta
fill 347 208 570 353 213 572 minecraft:jungle_leaves[persistent=true]
fill 347 208 584 353 213 586 minecraft:jungle_leaves[persistent=true]
setblock 348 208 560 minecraft:light[level=14]
setblock 348 208 568 minecraft:light[level=14]
fill 348 208 577 349 210 577 minecraft:jungle_leaves[persistent=true]
fill 348 208 578 350 208 578 minecraft:jungle_log
fill 348 208 579 349 210 579 minecraft:jungle_leaves[persistent=true]
setblock 348 208 592 minecraft:light[level=14]
setblock 349 208 558 minecraft:oak_log
fill 349 208 559 351 208 559 minecraft:green_terracotta
fill 350 208 558 353 208 558 minecraft:green_terracotta
setblock 351 208 598 minecraft:oak_leaves[persistent=true]
fill 353 208 573 358 213 573 minecraft:jungle_leaves[persistent=true]
fill 353 208 583 358 213 583 minecraft:jungle_leaves[persistent=true]
setblock 354 208 558 minecraft:oak_log
fill 354 208 571 355 213 572 minecraft:jungle_leaves[persistent=true]
fill 354 208 584 355 213 585 minecraft:jungle_leaves[persistent=true]
fill 355 208 574 358 212 574 minecraft:jungle_leaves[persistent=true]
fill 355 208 582 358 212 582 minecraft:jungle_leaves[persistent=true]
setblock 356 208 560 minecraft:light[level=14]
setblock 356 208 568 minecraft:light[level=14]
fill 356 208 572 357 213 572 minecraft:jungle_leaves[persistent=true]
fill 356 208 575 359 211 575 minecraft:jungle_leaves[persistent=true]
fill 356 208 581 359 211 581 minecraft:jungle_leaves[persistent=true]
fill 356 208 584 357 213 584 minecraft:jungle_leaves[persistent=true]
setblock 356 208 592 minecraft:light[level=14]
fill 357 208 576 359 209 580 minecraft:jungle_leaves[persistent=true]
fill 360 208 577 360 213 579 minecraft:jungle_leaves[persistent=true]
setblock 364 208 558 minecraft:oak_log
setblock 364 208 560 minecraft:light[level=14]
setblock 364 208 568 minecraft:light[level=14]
setblock 364 208 576 minecraft:light[level=14]
setblock 364 208 584 minecraft:light[level=14]
setblock 364 208 592 minecraft:light[level=14]
setblock 364 208 598 minecraft:oak_log
fill 365 208 558 365 211 558 minecraft:green_terracotta
fill 365 208 598 365 211 598 minecraft:green_terracotta
setblock 368 208 589 minecraft:oak_log
fill 368 208 590 368 211 590 minecraft:green_terracotta
setblock 368 208 594 minecraft:oak_log
setblock 369 208 558 minecraft:oak_log
setblock 369 208 563 minecraft:oak_log
fill 369 208 564 369 209 564 minecraft:green_terracotta
setblock 369 208 568 minecraft:oak_log
fill 369 208 569 369 211 569 minecraft:green_terracotta
setblock 369 208 583 minecraft:oak_log
fill 369 208 584 369 211 584 minecraft:green_terracotta
setblock 369 208 588 minecraft:oak_log
fill 369 208 589 369 211 589 minecraft:green_terracotta
setblock 369 208 593 minecraft:oak_log
fill 369 208 594 369 211 594 minecraft:green_terracotta
setblock 369 208 598 minecraft:oak_log
fill 370 208 558 370 209 558 minecraft:green_terracotta
setblock 370 208 562 minecraft:oak_log
fill 370 208 563 370 211 563 minecraft:green_terracotta
setblock 370 208 567 minecraft:oak_log
fill 370 208 568 370 211 568 minecraft:green_terracotta
setblock 370 208 572 minecraft:oak_log
setblock 370 208 582 minecraft:oak_log
fill 370 208 583 370 211 583 minecraft:green_terracotta
setblock 370 208 587 minecraft:oak_log
fill 370 208 588 370 211 588 minecraft:green_terracotta
setblock 370 208 592 minecraft:oak_log
fill 370 208 593 370 211 593 minecraft:green_terracotta
setblock 370 208 597 minecraft:oak_log
fill 370 208 598 370 211 598 minecraft:green_terracotta
fill 330 209 563 330 209 565 minecraft:green_terracotta
setblock 330 209 566 minecraft:oak_log
fill 330 209 567 330 209 570 minecraft:green_terracotta
setblock 330 209 571 minecraft:oak_log
fill 330 209 572 330 209 575 minecraft:green_terracotta
setblock 330 209 576 minecraft:oak_log
fill 330 209 577 330 209 580 minecraft:green_terracotta
setblock 330 209 581 minecraft:oak_log
fill 330 209 582 330 209 585 minecraft:green_terracotta
setblock 330 209 586 minecraft:oak_log
fill 330 209 587 330 212 587 minecraft:green_terracotta
setblock 330 209 591 minecraft:oak_log
fill 330 209 592 330 212 592 minecraft:green_terracotta
setblock 330 209 596 minecraft:oak_log
fill 330 209 597 330 212 597 minecraft:green_terracotta
setblock 331 209 570 minecraft:oak_log
fill 331 209 571 331 212 571 minecraft:green_terracotta
fill 331 209 581 331 209 584 minecraft:green_terracotta
setblock 331 209 585 minecraft:oak_log
fill 331 209 586 331 212 586 minecraft:green_terracotta
setblock 331 209 590 minecraft:oak_log
fill 331 209 591 331 212 591 minecraft:green_terracotta
setblock 332 209 585 minecraft:green_terracotta
setblock 332 209 589 minecraft:oak_log
fill 332 209 590 332 210 590 minecraft:green_terracotta
setblock 332 209 598 minecraft:oak_leaves[persistent=true]
setblock 336 209 577 minecraft:dark_oak_log
fill 336 209 578 339 209 578 minecraft:jungle_log
setblock 336 209 579 minecraft:dark_oak_log
setblock 337 209 576 minecraft:dark_oak_log
fill 337 209 577 338 209 577 minecraft:oak_log
fill 337 209 579 338 209 579 minecraft:oak_log
fill 337 209 580 338 209 580 minecraft:dark_oak_log
fill 338 209 573 338 213 573 minecraft:dark_oak_log
fill 339 209 572 340 209 572 minecraft:dark_oak_log
setblock 339 209 573 minecraft:jungle_log
fill 339 209 574 339 212 577 minecraft:jungle_leaves[persistent=true]
fill 339 209 579 339 212 582 minecraft:jungle_leaves[persistent=true]
setblock 339 209 583 minecraft:jungle_log
fill 340 209 573 344 212 573 minecraft:jungle_leaves[persistent=true]
fill 340 209 574 340 209 575 minecraft:jungle_log
fill 340 209 576 344 209 580 minecraft:jungle_leaves[persistent=true]
fill 340 209 581 340 209 582 minecraft:jungle_log
fill 340 209 583 344 212 583 minecraft:jungle_leaves[persistent=true]
fill 341 209 572 342 212 572 minecraft:jungle_leaves[persistent=true]
fill 341 209 574 343 212 575 minecraft:jungle_leaves[persistent=true]
fill 341 209 581 343 212 582 minecraft:jungle_leaves[persistent=true]
fill 341 209 584 342 212 584 minecraft:jungle_leaves[persistent=true]
fill 342 209 571 344 212 571 minecraft:jungle_leaves[persistent=true]
fill 342 209 585 344 212 585 minecraft:jungle_leaves[persistent=true]
setblock 343 209 558 minecraft:oak_leaves[persistent=true]
fill 343 209 570 346 212 570 minecraft:jungle_leaves[persistent=true]
fill 343 209 586 346 212 586 minecraft:jungle_leaves[persistent=true]
fill 344 209 574 344 209 575 minecraft:jungle_log
fill 344 209 581 344 209 582 minecraft:jungle_log
fill 345 209 569 355 212 569 minecraft:jungle_leaves[persistent=true]
fill 345 209 572 346 213 572 minecraft:jungle_leaves[persistent=true]
setblock 345 209 573 minecraft:jungle_log
fill 345 209 577 347 217 577 minecraft:jungle_leaves[persistent=true]
fill 345 209 578 348 209 578 minecraft:jungle_log
fill 345 209 579 347 217 579 minecraft:jungle_leaves[persistent=true]
setblock 345 209 583 minecraft:jungle_log
fill 345 209 584 346 213 584 minecraft:jungle_leaves[persistent=true]
fill 345 209 587 355 212 587 minecraft:jungle_leaves[persistent=true]
fill 346 209 571 346 213 571 minecraft:jungle_leaves[persistent=true]
fill 346 209 585 346 213 585 minecraft:jungle_leaves[persistent=true]
setblock 347 209 558 minecraft:green_terracotta
setblock 348 209 558 minecraft:oak_log
fill 348 209 568 352 212 568 minecraft:jungle_leaves[persistent=true]
fill 348 209 588 352 212 588 minecraft:jungle_leaves[persistent=true]
fill 349 209 558 352 209 558 minecraft:green_terracotta
setblock 349 209 578 minecraft:jungle_leaves[persistent=true]
setblock 353 209 558 minecraft:oak_log
fill 354 209 570 357 212 570 minecraft:jungle_leaves[persistent=true]
fill 354 209 586 357 212 586 minecraft:jungle_leaves[persistent=true]
fill 356 209 571 358 212 571 minecraft:jungle_leaves[persistent=true]
fill 356 209 585 358 212 585 minecraft:jungle_leaves[persistent=true]
setblock 357 209 598 minecraft:oak_leaves[persistent=true]
fill 358 209 572 359 212 572 minecraft:jungle_leaves[persistent=true]
fill 358 209 584 359 212 584 minecraft:jungle_leaves[persistent=true]
fill 359 209 573 360 212 574 minecraft:jungle_leaves[persistent=true]
fill 359 209 582 360 212 583 minecraft:jungle_leaves[persistent=true]
fill 360 209 575 361 212 576 minecraft:jungle_leaves[persistent=true]
fill 360 209 580 361 212 581 minecraft:jungle_leaves[persistent=true]
fill 361 209 574 361 212 574 minecraft:jungle_leaves[persistent=true]
fill 361 209 577 361 212 579 minecraft:jungle_leaves[persistent=true]
fill 361 209 582 361 212 582 minecraft:jungle_leaves[persistent=true]
fill 362 209 578 362 212 578 minecraft:jungle_leaves[persistent=true]
fill 364 209 598 364 212 598 minecraft:green_terracotta
fill 366 209 597 366 211 597 minecraft:green_terracotta
setblock 368 209 558 minecraft:oak_log
setblock 368 209 588 minecraft:oak_log
fill 368 209 589 368 212 589 minecraft:green_terracotta
setblock 368 209 593 minecraft:oak_log
fill 368 209 594 368 212 594 minecraft:green_terracotta
setblock 368 209 598 minecraft:oak_log
fill 369 209 558 369 212 558 minecraft:green_terracotta
setblock 369 209 567 minecraft:oak_log
fill 369 209 568 369 212 568 minecraft:green_terracotta
setblock 369 209 587 minecraft:oak_log
fill 369 209 588 369 212 588 minecraft:green_terracotta
setblock 369 209 592 minecraft:oak_log
fill 369 209 593 369 212 593 minecraft:green_terracotta
setblock 369 209 597 minecraft:oak_log
fill 369 209 598 369 212 598 minecraft:green_terracotta
setblock 370 209 561 minecraft:oak_log
fill 370 209 562 370 210 562 minecraft:green_terracotta
setblock 370 209 566 minecraft:oak_log
fill 370 209 567 370 212 567 minecraft:green_terracotta
setblock 370 209 571 minecraft:oak_log
fill 370 209 572 370 212 572 minecraft:green_terracotta
setblock 370 209 575 minecraft:oak_leaves[persistent=true]
setblock 370 209 581 minecraft:oak_log
fill 370 209 582 370 212 582 minecraft:green_terracotta
setblock 370 209 586 minecraft:oak_log
fill 370 209 587 370 212 587 minecraft:green_terracotta
setblock 370 209 591 minecraft:oak_log
fill 370 209 592 370 212 592 minecraft:green_terracotta
setblock 370 209 596 minecraft:oak_log
fill 370 209 597 370 212 597 minecraft:green_terracotta
setblock 330 210 562 minecraft:oak_leaves[persistent=true]
setblock 330 210 564 minecraft:green_terracotta
setblock 330 210 565 minecraft:oak_log
fill 330 210 566 330 210 569 minecraft:green_terracotta
setblock 330 210 570 minecraft:oak_log
fill 330 210 571 330 210 574 minecraft:green_terracotta
setblock 330 210 575 minecraft:oak_log
fill 330 210 576 330 210 579 minecraft:green_terracotta
setblock 330 210 580 minecraft:oak_log
fill 330 210 581 330 210 584 minecraft:green_terracotta
setblock 330 210 585 minecraft:oak_log
fill 330 210 586 330 213 586 minecraft:green_terracotta
setblock 330 210 590 minecraft:oak_log
fill 330 210 591 330 213 591 minecraft:green_terracotta
setblock 330 210 595 minecraft:oak_log
fill 330 210 596 330 213 596 minecraft:green_terracotta
setblock 331 210 569 minecraft:oak_log
fill 331 210 570 331 213 570 minecraft:green_terracotta
fill 331 210 572 331 211 572 minecraft:green_terracotta
fill 331 210 582 331 210 583 minecraft:green_terracotta
setblock 331 210 584 minecraft:oak_log
fill 331 210 585 331 213 585 minecraft:green_terracotta
setblock 331 210 589 minecraft:oak_log
fill 331 210 590 331 213 590 minecraft:green_terracotta
setblock 331 210 594 minecraft:oak_log
setblock 332 210 588 minecraft:oak_log
fill 332 210 589 332 211 589 minecraft:green_terracotta
setblock 337 210 558 minecraft:oak_leaves[persistent=true]
fill 337 210 577 337 213 579 minecraft:oak_log
fill 338 210 574 338 211 582 minecraft:jungle_leaves[persistent=true]
setblock 338 210 598 minecraft:oak_leaves[persistent=true]
fill 339 210 572 339 213 572 minecraft:dark_oak_log
fill 339 210 573 339 211 573 minecraft:jungle_leaves[persistent=true]
fill 339 210 578 345 210 578 minecraft:jungle_log
fill 339 210 583 339 211 583 minecraft:jungle_leaves[persistent=true]
fill 340 210 572 340 211 572 minecraft:jungle_leaves[persistent=true]
fill 340 210 574 340 212 577 minecraft:jungle_leaves[persistent=true]
fill 340 210 579 340 212 582 minecraft:jungle_leaves[persistent=true]
fill 340 210 584 340 211 584 minecraft:jungle_leaves[persistent=true]
fill 341 210 571 341 211 571 minecraft:jungle_leaves[persistent=true]
fill 341 210 576 341 210 577 minecraft:jungle_log
fill 341 210 579 341 210 580 minecraft:jungle_log
fill 341 210 585 341 211 585 minecraft:jungle_leaves[persistent=true]
fill 342 210 570 342 211 570 minecraft:jungle_leaves[persistent=true]
fill 342 210 576 342 218 576 minecraft:jungle_leaves[persistent=true]
fill 342 210 577 343 210 577 minecraft:jungle_log
fill 342 210 579 343 210 579 minecraft:jungle_log
fill 342 210 580 342 218 580 minecraft:jungle_leaves[persistent=true]
fill 342 210 586 342 211 586 minecraft:jungle_leaves[persistent=true]
fill 343 210 569 344 211 569 minecraft:jungle_leaves[persistent=true]
setblock 343 210 576 minecraft:jungle_log
setblock 343 210 580 minecraft:jungle_log
fill 343 210 587 344 211 587 minecraft:jungle_leaves[persistent=true]
fill 344 210 574 344 217 577 minecraft:jungle_leaves[persistent=true]
fill 344 210 579 344 217 582 minecraft:jungle_leaves[persistent=true]
fill 345 210 568 347 211 568 minecraft:jungle_leaves[persistent=true]
fill 345 210 573 345 217 573 minecraft:jungle_leaves[persistent=true]
fill 345 210 583 345 217 583 minecraft:jungle_leaves[persistent=true]
fill 345 210 588 347 211 588 minecraft:jungle_leaves[persistent=true]
setblock 346 210 558 minecraft:green_terracotta
fill 346 210 574 352 210 574 minecraft:jungle_leaves[persistent=true]
fill 346 210 578 348 217 578 minecraft:jungle_leaves[persistent=true]
fill 346 210 582 352 210 582 minecraft:jungle_leaves[persistent=true]
setblock 347 210 558 minecraft:oak_log
fill 348 210 558 351 210 558 minecraft:green_terracotta
setblock 352 210 558 minecraft:oak_log
fill 353 210 568 355 211 568 minecraft:jungle_leaves[persistent=true]
fill 353 210 588 355 211 588 minecraft:jungle_leaves[persistent=true]
setblock 354 210 574 minecraft:jungle_leaves[persistent=true]
setblock 354 210 582 minecraft:jungle_leaves[persistent=true]
fill 356 210 569 357 211 569 minecraft:jungle_leaves[persistent=true]
fill 356 210 587 357 211 587 minecraft:jungle_leaves[persistent=true]
fill 357 210 576 359 210 577 minecraft:jungle_leaves[persistent=true]
fill 357 210 579 359 210 580 minecraft:jungle_leaves[persistent=true]
fill 358 210 570 358 211 570 minecraft:jungle_leaves[persistent=true]
fill 358 210 578 359 213 578 minecraft:jungle_leaves[persistent=true]
fill 358 210 586 358 211 586 minecraft:jungle_leaves[persistent=true]
fill 359 210 571 359 211 571 minecraft:jungle_leaves[persistent=true]
fill 359 210 585 359 211 585 minecraft:jungle_leaves[persistent=true]
fill 360 210 572 360 211 572 minecraft:jungle_leaves[persistent=true]
fill 360 210 584 360 211 584 minecraft:jungle_leaves[persistent=true]
fill 361 210 573 361 211 573 minecraft:jungle_leaves[persistent=true]
fill 361 210 583 361 211 583 minecraft:jungle_leaves[persistent=true]
setblock 362 210 558 minecraft:oak_leaves[persistent=true]
fill 362 210 574 362 211 577 minecraft:jungle_leaves[persistent=true]
fill 362 210 579 362 211 582 minecraft:jungle_leaves[persistent=true]
fill 363 210 598 363 213 598 minecraft:green_terracotta
fill 365 210 597 365 212 597 minecraft:green_terracotta
setblock 367 210 558 minecraft:oak_log
setblock 367 210 598 minecraft:oak_log
fill 368 210 558 368 213 558 minecraft:green_terracotta
setblock 368 210 587 minecraft:oak_log
fill 368 210 588 368 213 588 minecraft:green_terracotta
setblock 368 210 592 minecraft:oak_log
fill 368 210 593 368 213 593 minecraft:green_terracotta
fill 368 210 595 368 211 595 minecraft:green_terracotta
setblock 368 210 597 minecraft:oak_log
fill 368 210 598 368 213 598 minecraft:green_terracotta
setblock 369 210 566 minecraft:oak_log
fill 369 210 567 369 213 567 minecraft:green_terracotta
setblock 369 210 586 minecraft:oak_log
fill 369 210 587 369 213 587 minecraft:green_terracotta
setblock 369 210 591 minecraft:oak_log
fill 369 210 592 369 213 592 minecraft:green_terracotta
setblock 369 210 596 minecraft:oak_log
fill 369 210 597 369 213 597 minecraft:green_terracotta
setblock 370 210 561 minecraft:green_terracotta
setblock 370 210 565 minecraft:oak_log
fill 370 210 566 370 213 566 minecraft:green_terracotta
setblock 370 210 570 minecraft:oak_log
fill 370 210 571 370 213 571 minecraft:green_terracotta
fill 370 210 573 370 211 573 minecraft:green_terracotta
fill 370 210 581 370 213 581 minecraft:green_terracotta
setblock 370 210 585 minecraft:oak_log
fill 370 210 586 370 213 586 minecraft:green_terracotta
setblock 370 210 590 minecraft:oak_log
fill 370 210 591 370 213 591 minecraft:green_terracotta
setblock 370 210 595 minecraft:oak_log
fill 370 210 596 370 213 596 minecraft:green_terracotta
setblock 330 211 564 minecraft:oak_log
fill 330 211 565 330 211 568 minecraft:green_terracotta
setblock 330 211 569 minecraft:oak_log
fill 330 211 570 330 211 573 minecraft:green_terracotta
setblock 330 211 574 minecraft:oak_log
fill 330 211 575 330 211 578 minecraft:green_terracotta
setblock 330 211 579 minecraft:oak_log
fill 330 211 580 330 211 583 minecraft:green_terracotta
setblock 330 211 584 minecraft:oak_log
fill 330 211 585 330 214 585 minecraft:green_terracotta
setblock 330 211 589 minecraft:oak_log
fill 330 211 590 330 214 590 minecraft:green_terracotta
setblock 330 211 594 minecraft:oak_log
fill 330 211 595 330 214 595 minecraft:green_terracotta
setblock 330 211 598 minecraft:green_terracotta
setblock 331 211 558 minecraft:oak_leaves[persistent=true]
setblock 331 211 568 minecraft:oak_log
fill 331 211 569 331 214 569 minecraft:green_terracotta
setblock 331 211 573 minecraft:oak_log
fill 331 211 574 331 214 574 minecraft:green_terracotta
setblock 331 211 583 minecraft:oak_log
fill 331 211 584 331 213 584 minecraft:green_terracotta
setblock 331 211 588 minecraft:oak_log
fill 331 211 589 331 214 589 minecraft:green_terracotta
setblock 331 211 593 minecraft:oak_log
fill 331 211 594 331 214 594 minecraft:green_terracotta
fill 338 211 572 338 213 572 minecraft:dark_oak_log
fill 339 211 571 340 213 571 minecraft:dark_oak_log
fill 339 211 578 341 218 578 minecraft:jungle_leaves[persistent=true]
fill 341 211 576 341 218 577 minecraft:jungle_leaves[persistent=true]
fill 341 211 579 341 218 580 minecraft:jungle_leaves[persistent=true]
fill 342 211 577 343 218 577 minecraft:jungle_leaves[persistent=true]
setblock 342 211 578 minecraft:jungle_log
fill 342 211 579 343 218 579 minecraft:jungle_leaves[persistent=true]
fill 343 211 576 343 218 576 minecraft:jungle_leaves[persistent=true]
fill 343 211 578 345 218 578 minecraft:jungle_leaves[persistent=true]
fill 343 211 580 343 218 580 minecraft:jungle_leaves[persistent=true]
setblock 344 211 598 minecraft:oak_leaves[persistent=true]
setblock 346 211 558 minecraft:oak_log
fill 346 211 574 351 212 574 minecraft:jungle_leaves[persistent=true]
fill 346 211 582 351 212 582 minecraft:jungle_leaves[persistent=true]
fill 347 211 558 350 211 558 minecraft:green_terracotta
fill 348 211 577 348 216 577 minecraft:jungle_leaves[persistent=true]
fill 348 211 579 348 216 579 minecraft:jungle_leaves[persistent=true]
fill 349 211 598 349 212 598 minecraft:green_terracotta
setblock 351 211 558 minecraft:oak_log
fill 352 211 558 352 214 558 minecraft:green_terracotta
setblock 356 211 558 minecraft:oak_leaves[persistent=true]
fill 357 211 576 359 212 576 minecraft:jungle_leaves[persistent=true]
fill 357 211 580 359 212 580 minecraft:jungle_leaves[persistent=true]
fill 358 211 577 359 213 577 minecraft:jungle_leaves[persistent=true]
fill 358 211 579 359 213 579 minecraft:jungle_leaves[persistent=true]
fill 362 211 598 362 214 598 minecraft:green_terracotta
fill 364 211 558 364 212 558 minecraft:green_terracotta
fill 364 211 597 364 213 597 minecraft:green_terracotta
setblock 366 211 558 minecraft:oak_log
fill 366 211 596 367 211 596 minecraft:green_terracotta
setblock 366 211 598 minecraft:oak_log
fill 367 211 558 367 214 558 minecraft:green_terracotta
fill 367 211 590 367 211 591 minecraft:green_terracotta
setblock 367 211 592 minecraft:oak_log
fill 367 211 593 367 214 593 minecraft:green_terracotta
setblock 367 211 597 minecraft:oak_log
schedule function dropper:buildpart/139_6 1t
