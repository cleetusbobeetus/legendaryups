setblock 450 127 417 minecraft:glowstone
setblock 450 127 419 minecraft:glowstone
setblock 450 127 421 minecraft:glowstone
setblock 451 127 418 minecraft:glowstone
setblock 451 127 420 minecraft:glowstone
setblock 451 127 422 minecraft:glowstone
setblock 452 127 417 minecraft:glowstone
setblock 452 127 419 minecraft:glowstone
setblock 452 127 421 minecraft:glowstone
fill 453 127 417 453 137 417 minecraft:iron_block
setblock 453 127 418 minecraft:glowstone
setblock 453 127 420 minecraft:glowstone
setblock 453 127 422 minecraft:glowstone
setblock 454 127 417 minecraft:glowstone
setblock 454 127 419 minecraft:glowstone
setblock 454 127 421 minecraft:glowstone
fill 455 127 417 455 137 417 minecraft:iron_block
setblock 455 127 418 minecraft:glowstone
setblock 455 127 420 minecraft:glowstone
setblock 455 127 422 minecraft:glowstone
setblock 456 127 417 minecraft:glowstone
setblock 456 127 419 minecraft:glowstone
setblock 456 127 421 minecraft:glowstone
fill 457 127 417 457 137 417 minecraft:iron_block
setblock 457 127 418 minecraft:glowstone
setblock 457 127 420 minecraft:glowstone
setblock 457 127 422 minecraft:glowstone
setblock 458 127 417 minecraft:glowstone
setblock 458 127 419 minecraft:glowstone
setblock 458 127 421 minecraft:glowstone
setblock 459 127 418 minecraft:glowstone
setblock 459 127 420 minecraft:glowstone
setblock 459 127 422 minecraft:glowstone
fill 449 128 418 449 129 418 minecraft:iron_block
fill 449 128 420 449 129 420 minecraft:iron_block
fill 449 128 422 449 129 422 minecraft:iron_block
fill 450 128 417 450 129 417 minecraft:iron_block
fill 450 128 419 450 129 419 minecraft:iron_block
fill 450 128 421 450 129 421 minecraft:iron_block
fill 451 128 418 451 129 418 minecraft:iron_block
fill 451 128 420 451 129 420 minecraft:iron_block
fill 451 128 422 451 129 422 minecraft:iron_block
fill 452 128 417 452 129 417 minecraft:iron_block
fill 452 128 419 452 129 419 minecraft:iron_block
fill 452 128 421 452 129 421 minecraft:iron_block
fill 453 128 418 453 129 418 minecraft:iron_block
fill 453 128 420 453 129 420 minecraft:iron_block
fill 453 128 422 453 129 422 minecraft:iron_block
fill 454 128 417 454 129 417 minecraft:iron_block
fill 454 128 419 454 129 419 minecraft:iron_block
fill 454 128 421 454 129 421 minecraft:iron_block
fill 455 128 418 455 129 418 minecraft:iron_block
fill 455 128 420 455 129 420 minecraft:iron_block
fill 455 128 422 455 129 422 minecraft:iron_block
fill 456 128 417 456 129 417 minecraft:iron_block
fill 456 128 419 456 129 419 minecraft:iron_block
fill 456 128 421 456 129 421 minecraft:iron_block
fill 457 128 418 457 129 418 minecraft:iron_block
fill 457 128 420 457 129 420 minecraft:iron_block
fill 457 128 422 457 129 422 minecraft:iron_block
fill 458 128 417 458 129 417 minecraft:iron_block
fill 458 128 419 458 129 419 minecraft:iron_block
fill 458 128 421 458 129 421 minecraft:iron_block
fill 459 128 418 459 129 418 minecraft:iron_block
fill 459 128 420 459 129 420 minecraft:iron_block
fill 459 128 422 459 129 422 minecraft:iron_block
setblock 426 129 419 minecraft:light[level=12]
setblock 426 129 427 minecraft:light[level=12]
setblock 426 129 435 minecraft:light[level=12]
setblock 426 129 443 minecraft:light[level=12]
setblock 426 129 451 minecraft:light[level=12]
setblock 434 129 419 minecraft:light[level=12]
setblock 434 129 427 minecraft:light[level=12]
setblock 434 129 435 minecraft:light[level=12]
setblock 434 129 443 minecraft:light[level=12]
setblock 434 129 451 minecraft:light[level=12]
setblock 442 129 419 minecraft:light[level=12]
setblock 442 129 427 minecraft:light[level=12]
setblock 442 129 435 minecraft:light[level=12]
setblock 442 129 451 minecraft:light[level=12]
setblock 450 129 427 minecraft:light[level=12]
setblock 450 129 435 minecraft:light[level=12]
setblock 450 129 443 minecraft:light[level=12]
setblock 450 129 451 minecraft:light[level=12]
setblock 458 129 427 minecraft:light[level=12]
setblock 458 129 435 minecraft:light[level=12]
setblock 458 129 443 minecraft:light[level=12]
setblock 458 129 451 minecraft:light[level=12]
setblock 449 130 418 minecraft:glowstone
setblock 449 130 420 minecraft:glowstone
setblock 449 130 422 minecraft:glowstone
setblock 450 130 417 minecraft:glowstone
setblock 450 130 419 minecraft:glowstone
setblock 450 130 421 minecraft:glowstone
setblock 451 130 418 minecraft:glowstone
setblock 451 130 420 minecraft:glowstone
setblock 451 130 422 minecraft:glowstone
setblock 452 130 417 minecraft:glowstone
setblock 452 130 419 minecraft:glowstone
setblock 452 130 421 minecraft:glowstone
setblock 453 130 418 minecraft:glowstone
setblock 453 130 420 minecraft:glowstone
setblock 453 130 422 minecraft:glowstone
setblock 454 130 417 minecraft:glowstone
setblock 454 130 419 minecraft:glowstone
setblock 454 130 421 minecraft:glowstone
setblock 455 130 418 minecraft:glowstone
setblock 455 130 420 minecraft:glowstone
setblock 455 130 422 minecraft:glowstone
setblock 456 130 417 minecraft:glowstone
setblock 456 130 419 minecraft:glowstone
setblock 456 130 421 minecraft:glowstone
setblock 457 130 418 minecraft:glowstone
setblock 457 130 420 minecraft:glowstone
setblock 457 130 422 minecraft:glowstone
setblock 458 130 417 minecraft:glowstone
setblock 458 130 419 minecraft:glowstone
setblock 458 130 421 minecraft:glowstone
setblock 459 130 418 minecraft:glowstone
setblock 459 130 420 minecraft:glowstone
setblock 459 130 422 minecraft:glowstone
fill 449 131 418 449 132 418 minecraft:iron_block
fill 449 131 420 449 132 420 minecraft:iron_block
fill 449 131 422 449 132 422 minecraft:iron_block
fill 450 131 417 450 132 417 minecraft:iron_block
fill 450 131 419 450 132 419 minecraft:iron_block
fill 450 131 421 450 132 421 minecraft:iron_block
fill 451 131 418 451 132 418 minecraft:iron_block
fill 451 131 420 451 132 420 minecraft:iron_block
fill 451 131 422 451 132 422 minecraft:iron_block
fill 452 131 417 452 132 417 minecraft:iron_block
fill 452 131 419 452 132 419 minecraft:iron_block
fill 452 131 421 452 132 421 minecraft:iron_block
fill 453 131 418 453 132 418 minecraft:iron_block
fill 453 131 420 453 132 420 minecraft:iron_block
fill 453 131 422 453 132 422 minecraft:iron_block
fill 454 131 417 454 132 417 minecraft:iron_block
fill 454 131 419 454 132 419 minecraft:iron_block
fill 454 131 421 454 132 421 minecraft:iron_block
fill 455 131 418 455 132 418 minecraft:iron_block
fill 455 131 420 455 132 420 minecraft:iron_block
fill 455 131 422 455 132 422 minecraft:iron_block
fill 456 131 417 456 132 417 minecraft:iron_block
fill 456 131 419 456 132 419 minecraft:iron_block
fill 456 131 421 456 132 421 minecraft:iron_block
fill 457 131 418 457 132 418 minecraft:iron_block
fill 457 131 420 457 132 420 minecraft:iron_block
fill 457 131 422 457 132 422 minecraft:iron_block
fill 458 131 417 458 132 417 minecraft:iron_block
fill 458 131 419 458 132 419 minecraft:iron_block
fill 458 131 421 458 132 421 minecraft:iron_block
fill 459 131 418 459 132 418 minecraft:iron_block
fill 459 131 420 459 132 420 minecraft:iron_block
fill 459 131 422 459 132 422 minecraft:iron_block
fill 423 132 422 423 145 422 minecraft:cracked_stone_bricks
fill 423 132 423 423 132 424 minecraft:glowstone
fill 423 132 425 423 145 425 minecraft:cracked_stone_bricks
fill 423 132 434 423 145 434 minecraft:cracked_stone_bricks
fill 423 132 435 423 132 436 minecraft:glowstone
fill 423 132 437 423 145 437 minecraft:cracked_stone_bricks
fill 423 132 446 423 145 446 minecraft:cracked_stone_bricks
fill 423 132 447 423 132 448 minecraft:glowstone
fill 423 132 449 423 145 449 minecraft:cracked_stone_bricks
fill 423 132 458 423 145 458 minecraft:cracked_stone_bricks
fill 424 132 458 425 132 458 minecraft:glowstone
fill 426 132 458 426 145 458 minecraft:cracked_stone_bricks
fill 430 132 416 430 145 416 minecraft:cracked_stone_bricks
fill 431 132 416 432 132 416 minecraft:glowstone
fill 433 132 416 433 145 416 minecraft:cracked_stone_bricks
fill 435 132 458 435 145 458 minecraft:cracked_stone_bricks
fill 436 132 458 437 132 458 minecraft:glowstone
fill 438 132 458 438 145 458 minecraft:cracked_stone_bricks
fill 442 132 416 442 145 416 minecraft:cracked_stone_bricks
fill 443 132 416 444 132 416 minecraft:glowstone
fill 445 132 416 445 145 416 minecraft:cracked_stone_bricks
fill 447 132 458 447 145 458 minecraft:cracked_stone_bricks
fill 448 132 458 449 132 458 minecraft:glowstone
fill 450 132 458 450 145 458 minecraft:cracked_stone_bricks
fill 454 132 416 454 145 416 minecraft:cracked_stone_bricks
fill 455 132 416 456 132 416 minecraft:glowstone
fill 457 132 416 457 145 416 minecraft:cracked_stone_bricks
fill 459 132 458 459 145 458 minecraft:cracked_stone_bricks
fill 460 132 458 461 132 458 minecraft:glowstone
fill 462 132 458 462 145 458 minecraft:cracked_stone_bricks
fill 465 132 417 465 145 417 minecraft:cracked_stone_bricks
fill 465 132 418 465 132 419 minecraft:glowstone
fill 465 132 420 465 145 420 minecraft:cracked_stone_bricks
fill 465 132 429 465 145 429 minecraft:cracked_stone_bricks
fill 465 132 430 465 132 431 minecraft:glowstone
fill 465 132 432 465 145 432 minecraft:cracked_stone_bricks
fill 465 132 441 465 145 441 minecraft:cracked_stone_bricks
fill 465 132 442 465 132 443 minecraft:glowstone
fill 465 132 444 465 145 444 minecraft:cracked_stone_bricks
fill 465 132 453 465 145 453 minecraft:cracked_stone_bricks
fill 465 132 454 465 132 455 minecraft:glowstone
fill 465 132 456 465 145 456 minecraft:cracked_stone_bricks
fill 423 133 423 423 145 424 minecraft:cracked_stone_bricks
fill 423 133 435 423 145 436 minecraft:cracked_stone_bricks
fill 423 133 447 423 145 448 minecraft:cracked_stone_bricks
fill 424 133 458 425 145 458 minecraft:cracked_stone_bricks
fill 431 133 416 432 145 416 minecraft:cracked_stone_bricks
fill 436 133 458 437 145 458 minecraft:cracked_stone_bricks
fill 443 133 416 444 145 416 minecraft:cracked_stone_bricks
fill 448 133 458 449 145 458 minecraft:cracked_stone_bricks
setblock 449 133 418 minecraft:glowstone
setblock 449 133 420 minecraft:glowstone
setblock 449 133 422 minecraft:glowstone
setblock 450 133 417 minecraft:glowstone
setblock 450 133 419 minecraft:glowstone
setblock 450 133 421 minecraft:glowstone
setblock 451 133 418 minecraft:glowstone
setblock 451 133 420 minecraft:glowstone
setblock 451 133 422 minecraft:glowstone
setblock 452 133 417 minecraft:glowstone
setblock 452 133 419 minecraft:glowstone
setblock 452 133 421 minecraft:glowstone
setblock 453 133 418 minecraft:glowstone
setblock 453 133 420 minecraft:glowstone
setblock 453 133 422 minecraft:glowstone
setblock 454 133 417 minecraft:glowstone
setblock 454 133 419 minecraft:glowstone
setblock 454 133 421 minecraft:glowstone
fill 455 133 416 456 145 416 minecraft:cracked_stone_bricks
setblock 455 133 418 minecraft:glowstone
setblock 455 133 420 minecraft:glowstone
setblock 455 133 422 minecraft:glowstone
setblock 456 133 417 minecraft:glowstone
setblock 456 133 419 minecraft:glowstone
setblock 456 133 421 minecraft:glowstone
setblock 457 133 418 minecraft:glowstone
setblock 457 133 420 minecraft:glowstone
setblock 457 133 422 minecraft:glowstone
setblock 458 133 417 minecraft:glowstone
setblock 458 133 419 minecraft:glowstone
setblock 458 133 421 minecraft:glowstone
setblock 459 133 418 minecraft:glowstone
setblock 459 133 420 minecraft:glowstone
setblock 459 133 422 minecraft:glowstone
fill 460 133 458 461 145 458 minecraft:cracked_stone_bricks
fill 465 133 418 465 145 419 minecraft:cracked_stone_bricks
fill 465 133 430 465 145 431 minecraft:cracked_stone_bricks
fill 465 133 442 465 145 443 minecraft:cracked_stone_bricks
fill 465 133 454 465 145 455 minecraft:cracked_stone_bricks
fill 448 134 454 448 135 456 minecraft:iron_bars
fill 449 134 418 449 135 418 minecraft:iron_block
fill 449 134 420 449 135 420 minecraft:iron_block
fill 449 134 422 449 135 422 minecraft:iron_block
fill 450 134 417 450 135 417 minecraft:iron_block
fill 450 134 419 450 135 419 minecraft:iron_block
fill 450 134 421 450 135 421 minecraft:iron_block
fill 451 134 418 451 135 418 minecraft:iron_block
fill 451 134 420 451 135 420 minecraft:iron_block
fill 451 134 422 451 135 422 minecraft:iron_block
fill 452 134 417 452 135 417 minecraft:iron_block
fill 452 134 419 452 135 419 minecraft:iron_block
fill 452 134 421 452 135 421 minecraft:iron_block
fill 453 134 418 453 135 418 minecraft:iron_block
fill 453 134 420 453 135 420 minecraft:iron_block
fill 453 134 422 453 135 422 minecraft:iron_block
fill 454 134 417 454 135 417 minecraft:iron_block
fill 454 134 419 454 135 419 minecraft:iron_block
fill 454 134 421 454 135 421 minecraft:iron_block
fill 455 134 418 455 135 418 minecraft:iron_block
fill 455 134 420 455 135 420 minecraft:iron_block
fill 455 134 422 455 135 422 minecraft:iron_block
fill 456 134 417 456 135 417 minecraft:iron_block
fill 456 134 419 456 135 419 minecraft:iron_block
fill 456 134 421 456 135 421 minecraft:iron_block
fill 457 134 418 457 135 418 minecraft:iron_block
fill 457 134 420 457 135 420 minecraft:iron_block
fill 457 134 422 457 135 422 minecraft:iron_block
fill 458 134 417 458 135 417 minecraft:iron_block
fill 458 134 419 458 135 419 minecraft:iron_block
fill 458 134 421 458 135 421 minecraft:iron_block
fill 459 134 418 459 135 418 minecraft:iron_block
fill 459 134 420 459 135 420 minecraft:iron_block
fill 459 134 422 459 135 422 minecraft:iron_block
fill 427 135 438 427 142 438 minecraft:iron_bars
setblock 449 136 418 minecraft:glowstone
setblock 449 136 420 minecraft:glowstone
setblock 449 136 422 minecraft:glowstone
setblock 450 136 417 minecraft:glowstone
setblock 450 136 419 minecraft:glowstone
setblock 450 136 421 minecraft:glowstone
setblock 451 136 418 minecraft:glowstone
setblock 451 136 420 minecraft:glowstone
setblock 451 136 422 minecraft:glowstone
setblock 452 136 417 minecraft:glowstone
setblock 452 136 419 minecraft:glowstone
setblock 452 136 421 minecraft:glowstone
setblock 453 136 418 minecraft:glowstone
setblock 453 136 420 minecraft:glowstone
setblock 453 136 422 minecraft:glowstone
setblock 454 136 417 minecraft:glowstone
setblock 454 136 419 minecraft:glowstone
setblock 454 136 421 minecraft:glowstone
setblock 455 136 418 minecraft:glowstone
setblock 455 136 420 minecraft:glowstone
setblock 455 136 422 minecraft:glowstone
setblock 456 136 417 minecraft:glowstone
setblock 456 136 419 minecraft:glowstone
setblock 456 136 421 minecraft:glowstone
setblock 457 136 418 minecraft:glowstone
setblock 457 136 420 minecraft:glowstone
setblock 457 136 422 minecraft:glowstone
setblock 458 136 417 minecraft:glowstone
setblock 458 136 419 minecraft:glowstone
setblock 458 136 421 minecraft:glowstone
setblock 459 136 418 minecraft:glowstone
setblock 459 136 420 minecraft:glowstone
setblock 459 136 422 minecraft:glowstone
setblock 426 137 419 minecraft:light[level=12]
setblock 426 137 427 minecraft:light[level=12]
setblock 426 137 435 minecraft:light[level=12]
setblock 426 137 443 minecraft:light[level=12]
setblock 426 137 451 minecraft:light[level=12]
setblock 434 137 419 minecraft:light[level=12]
setblock 434 137 427 minecraft:light[level=12]
setblock 434 137 435 minecraft:light[level=12]
setblock 434 137 443 minecraft:light[level=12]
setblock 434 137 451 minecraft:light[level=12]
setblock 442 137 419 minecraft:light[level=12]
setblock 442 137 427 minecraft:light[level=12]
setblock 442 137 435 minecraft:light[level=12]
setblock 442 137 451 minecraft:light[level=12]
setblock 449 137 418 minecraft:iron_block
setblock 449 137 420 minecraft:iron_block
setblock 449 137 422 minecraft:iron_block
fill 450 137 417 450 171 417 minecraft:iron_block
setblock 450 137 419 minecraft:iron_block
setblock 450 137 421 minecraft:iron_block
setblock 450 137 427 minecraft:light[level=12]
setblock 450 137 435 minecraft:light[level=12]
setblock 450 137 443 minecraft:light[level=12]
setblock 450 137 451 minecraft:light[level=12]
setblock 451 137 418 minecraft:iron_block
setblock 451 137 420 minecraft:iron_block
setblock 451 137 422 minecraft:iron_block
fill 451 137 454 464 137 454 minecraft:iron_block
setblock 452 137 417 minecraft:iron_block
setblock 452 137 419 minecraft:iron_block
setblock 452 137 421 minecraft:iron_block
setblock 453 137 418 minecraft:iron_block
setblock 453 137 420 minecraft:iron_block
setblock 453 137 422 minecraft:iron_block
setblock 454 137 417 minecraft:iron_block
setblock 454 137 419 minecraft:iron_block
setblock 454 137 421 minecraft:iron_block
setblock 455 137 418 minecraft:iron_block
setblock 455 137 420 minecraft:iron_block
setblock 455 137 422 minecraft:iron_block
setblock 456 137 417 minecraft:iron_block
setblock 456 137 419 minecraft:iron_block
setblock 456 137 421 minecraft:iron_block
setblock 457 137 418 minecraft:iron_block
setblock 457 137 420 minecraft:iron_block
setblock 457 137 422 minecraft:iron_block
setblock 458 137 417 minecraft:iron_block
setblock 458 137 419 minecraft:iron_block
setblock 458 137 421 minecraft:iron_block
setblock 458 137 427 minecraft:light[level=12]
setblock 458 137 435 minecraft:light[level=12]
setblock 458 137 443 minecraft:light[level=12]
setblock 458 137 451 minecraft:light[level=12]
setblock 459 137 418 minecraft:iron_block
setblock 459 137 420 minecraft:iron_block
setblock 459 137 422 minecraft:iron_block
fill 459 137 449 463 137 449 minecraft:iron_block
fill 424 138 419 424 139 419 minecraft:iron_block
fill 424 138 424 463 138 424 minecraft:iron_block
fill 424 138 434 427 139 434 minecraft:iron_block
fill 424 138 444 426 139 444 minecraft:iron_block
fill 424 138 449 462 138 449 minecraft:iron_block
fill 424 138 454 452 138 454 minecraft:iron_block
fill 425 138 429 427 139 429 minecraft:iron_block
fill 425 138 439 425 145 439 minecraft:iron_block
fill 460 138 417 462 171 417 minecraft:iron_block
fill 424 139 424 435 139 424 minecraft:iron_block
fill 424 139 449 425 139 449 minecraft:iron_block
setblock 424 139 454 minecraft:iron_block
fill 425 139 419 452 139 419 minecraft:iron_block
fill 426 139 439 463 139 439 minecraft:iron_block
fill 427 139 444 439 139 444 minecraft:iron_block
fill 428 139 429 464 139 429 minecraft:iron_block
fill 428 139 434 464 139 434 minecraft:iron_block
fill 431 139 446 431 139 456 minecraft:iron_bars
fill 444 139 444 464 139 444 minecraft:iron_block
fill 456 139 451 456 139 456 minecraft:iron_bars
fill 425 140 426 425 145 428 minecraft:iron_block
fill 425 140 438 425 145 438 minecraft:iron_block
fill 425 140 440 425 145 440 minecraft:iron_block
fill 425 140 450 425 145 452 minecraft:iron_block
fill 426 140 418 426 141 428 minecraft:iron_bars
fill 431 140 417 431 140 448 minecraft:iron_bars
fill 431 140 456 433 145 456 minecraft:iron_block
fill 435 140 418 437 145 418 minecraft:iron_block
fill 436 140 419 436 141 419 minecraft:iron_bars
fill 441 140 417 441 141 421 minecraft:iron_bars
fill 443 140 456 445 145 456 minecraft:iron_block
fill 446 140 417 446 140 457 minecraft:iron_bars
fill 447 140 418 449 145 418 minecraft:iron_block
fill 450 140 419 464 140 419 minecraft:iron_block
fill 451 140 417 451 141 418 minecraft:iron_bars
fill 451 140 420 451 141 456 minecraft:iron_bars
fill 455 140 456 457 145 456 minecraft:iron_block
fill 456 140 417 456 141 418 minecraft:iron_bars
fill 456 140 420 456 140 453 minecraft:iron_bars
fill 459 140 418 461 145 418 minecraft:iron_block
fill 461 140 420 461 141 430 minecraft:iron_bars
fill 463 140 426 463 145 428 minecraft:iron_block
fill 463 140 438 463 145 440 minecraft:iron_block
fill 463 140 450 463 145 452 minecraft:iron_block
fill 426 141 429 426 141 456 minecraft:iron_bars
fill 431 141 417 431 141 418 minecraft:iron_bars
fill 436 141 420 436 141 457 minecraft:iron_bars
fill 441 141 422 441 141 439 minecraft:iron_bars
fill 441 141 446 441 141 457 minecraft:iron_bars
fill 446 141 417 446 141 419 minecraft:iron_bars
setblock 451 141 419 minecraft:iron_bars
setblock 461 141 419 minecraft:iron_bars
fill 461 141 431 461 141 456 minecraft:iron_bars
fill 424 145 420 424 145 425 minecraft:cobblestone
fill 424 145 432 424 145 437 minecraft:cobblestone
fill 424 145 444 424 145 449 minecraft:cobblestone
fill 424 145 456 424 145 457 minecraft:cobblestone
fill 425 145 457 428 145 457 minecraft:cobblestone
setblock 426 145 419 minecraft:light[level=12]
setblock 426 145 427 minecraft:light[level=12]
setblock 426 145 435 minecraft:light[level=12]
setblock 426 145 443 minecraft:light[level=12]
setblock 426 145 451 minecraft:light[level=12]
fill 428 145 417 433 145 417 minecraft:cobblestone
setblock 434 145 419 minecraft:light[level=12]
setblock 434 145 427 minecraft:light[level=12]
setblock 434 145 435 minecraft:light[level=12]
setblock 434 145 443 minecraft:light[level=12]
setblock 434 145 451 minecraft:light[level=12]
fill 435 145 457 440 145 457 minecraft:cobblestone
fill 440 145 417 445 145 417 minecraft:cobblestone
setblock 442 145 419 minecraft:light[level=12]
setblock 442 145 427 minecraft:light[level=12]
setblock 442 145 435 minecraft:light[level=12]
setblock 442 145 451 minecraft:light[level=12]
fill 447 145 457 452 145 457 minecraft:cobblestone
setblock 450 145 419 minecraft:light[level=12]
setblock 450 145 427 minecraft:light[level=12]
setblock 450 145 435 minecraft:light[level=12]
setblock 450 145 443 minecraft:light[level=12]
setblock 450 145 451 minecraft:light[level=12]
fill 452 145 417 457 145 417 minecraft:cobblestone
setblock 458 145 419 minecraft:light[level=12]
setblock 458 145 427 minecraft:light[level=12]
setblock 458 145 435 minecraft:light[level=12]
setblock 458 145 443 minecraft:light[level=12]
setblock 458 145 451 minecraft:light[level=12]
fill 459 145 457 464 145 457 minecraft:cobblestone
fill 464 145 417 464 145 422 minecraft:cobblestone
fill 464 145 429 464 145 434 minecraft:cobblestone
fill 464 145 441 464 145 446 minecraft:cobblestone
fill 464 145 453 464 145 456 minecraft:cobblestone
fill 423 146 422 423 151 425 minecraft:glowstone
fill 423 146 434 423 151 437 minecraft:glowstone
fill 423 146 446 423 151 449 minecraft:glowstone
fill 423 146 458 426 151 458 minecraft:glowstone
fill 430 146 416 433 151 416 minecraft:glowstone
fill 435 146 458 438 151 458 minecraft:glowstone
fill 442 146 416 445 151 416 minecraft:glowstone
fill 447 146 458 450 151 458 minecraft:glowstone
fill 454 146 416 457 151 416 minecraft:glowstone
fill 459 146 458 462 151 458 minecraft:glowstone
fill 465 146 417 465 151 420 minecraft:glowstone
fill 465 146 429 465 151 432 minecraft:glowstone
fill 465 146 441 465 151 444 minecraft:glowstone
fill 465 146 453 465 151 456 minecraft:glowstone
fill 458 149 417 458 150 419 minecraft:iron_bars
fill 423 152 422 423 165 422 minecraft:cracked_stone_bricks
fill 423 152 423 423 152 424 minecraft:glowstone
fill 423 152 425 423 165 425 minecraft:cracked_stone_bricks
fill 423 152 434 423 165 434 minecraft:cracked_stone_bricks
fill 423 152 435 423 152 436 minecraft:glowstone
fill 423 152 437 423 165 437 minecraft:cracked_stone_bricks
fill 423 152 446 423 165 446 minecraft:cracked_stone_bricks
fill 423 152 447 423 152 448 minecraft:glowstone
fill 423 152 449 423 165 449 minecraft:cracked_stone_bricks
fill 423 152 458 423 165 458 minecraft:cracked_stone_bricks
fill 424 152 458 425 152 458 minecraft:glowstone
fill 426 152 458 426 165 458 minecraft:cracked_stone_bricks
fill 429 152 438 429 159 438 minecraft:iron_bars
fill 430 152 416 430 165 416 minecraft:cracked_stone_bricks
fill 431 152 416 432 152 416 minecraft:glowstone
fill 433 152 416 433 165 416 minecraft:cracked_stone_bricks
fill 435 152 458 435 165 458 minecraft:cracked_stone_bricks
fill 436 152 458 437 152 458 minecraft:glowstone
fill 438 152 458 438 165 458 minecraft:cracked_stone_bricks
fill 442 152 416 442 165 416 minecraft:cracked_stone_bricks
fill 443 152 416 444 152 416 minecraft:glowstone
fill 445 152 416 445 165 416 minecraft:cracked_stone_bricks
fill 447 152 458 447 165 458 minecraft:cracked_stone_bricks
fill 448 152 458 449 152 458 minecraft:glowstone
fill 450 152 458 450 165 458 minecraft:cracked_stone_bricks
fill 454 152 416 454 165 416 minecraft:cracked_stone_bricks
fill 455 152 416 456 152 416 minecraft:glowstone
fill 457 152 416 457 165 416 minecraft:cracked_stone_bricks
fill 459 152 458 459 165 458 minecraft:cracked_stone_bricks
fill 460 152 458 461 152 458 minecraft:glowstone
fill 462 152 458 462 165 458 minecraft:cracked_stone_bricks
fill 465 152 417 465 165 417 minecraft:cracked_stone_bricks
fill 465 152 418 465 152 419 minecraft:glowstone
fill 465 152 420 465 165 420 minecraft:cracked_stone_bricks
fill 465 152 429 465 165 429 minecraft:cracked_stone_bricks
fill 465 152 430 465 152 431 minecraft:glowstone
fill 465 152 432 465 165 432 minecraft:cracked_stone_bricks
fill 465 152 441 465 165 441 minecraft:cracked_stone_bricks
fill 465 152 442 465 152 443 minecraft:glowstone
fill 465 152 444 465 165 444 minecraft:cracked_stone_bricks
fill 465 152 453 465 165 453 minecraft:cracked_stone_bricks
fill 465 152 454 465 152 455 minecraft:glowstone
fill 465 152 456 465 165 456 minecraft:cracked_stone_bricks
fill 423 153 423 423 165 424 minecraft:cracked_stone_bricks
fill 423 153 435 423 165 436 minecraft:cracked_stone_bricks
fill 423 153 447 423 165 448 minecraft:cracked_stone_bricks
fill 424 153 458 425 165 458 minecraft:cracked_stone_bricks
setblock 426 153 419 minecraft:light[level=12]
setblock 426 153 427 minecraft:light[level=12]
setblock 426 153 435 minecraft:light[level=12]
setblock 426 153 443 minecraft:light[level=12]
setblock 426 153 451 minecraft:light[level=12]
fill 431 153 416 432 165 416 minecraft:cracked_stone_bricks
setblock 434 153 419 minecraft:light[level=12]
setblock 434 153 427 minecraft:light[level=12]
setblock 434 153 435 minecraft:light[level=12]
setblock 434 153 443 minecraft:light[level=12]
setblock 434 153 451 minecraft:light[level=12]
fill 436 153 458 437 165 458 minecraft:cracked_stone_bricks
setblock 442 153 419 minecraft:light[level=12]
setblock 442 153 427 minecraft:light[level=12]
setblock 442 153 435 minecraft:light[level=12]
setblock 442 153 451 minecraft:light[level=12]
fill 443 153 416 444 165 416 minecraft:cracked_stone_bricks
fill 448 153 458 449 165 458 minecraft:cracked_stone_bricks
setblock 450 153 419 minecraft:light[level=12]
setblock 450 153 427 minecraft:light[level=12]
setblock 450 153 435 minecraft:light[level=12]
setblock 450 153 443 minecraft:light[level=12]
setblock 450 153 451 minecraft:light[level=12]
fill 455 153 416 456 165 416 minecraft:cracked_stone_bricks
setblock 458 153 419 minecraft:light[level=12]
setblock 458 153 427 minecraft:light[level=12]
setblock 458 153 435 minecraft:light[level=12]
setblock 458 153 443 minecraft:light[level=12]
setblock 458 153 451 minecraft:light[level=12]
fill 460 153 458 461 165 458 minecraft:cracked_stone_bricks
fill 465 153 418 465 165 419 minecraft:cracked_stone_bricks
fill 465 153 430 465 165 431 minecraft:cracked_stone_bricks
fill 465 153 442 465 165 443 minecraft:cracked_stone_bricks
fill 465 153 454 465 165 455 minecraft:cracked_stone_bricks
fill 443 156 450 443 167 450 minecraft:iron_bars
fill 459 157 439 459 166 439 minecraft:iron_bars
fill 424 158 422 425 159 422 minecraft:iron_block
fill 424 158 432 429 159 432 minecraft:iron_block
fill 424 158 437 463 158 437 minecraft:iron_block
fill 424 158 442 438 158 442 minecraft:iron_block
fill 424 158 447 424 159 447 minecraft:iron_block
fill 425 158 427 426 159 427 minecraft:iron_block
fill 425 158 452 463 158 452 minecraft:iron_block
fill 445 158 442 464 158 442 minecraft:iron_block
fill 424 159 437 429 159 437 minecraft:iron_block
fill 424 159 442 426 159 442 minecraft:iron_block
fill 425 159 447 451 159 447 minecraft:iron_block
fill 425 159 452 432 159 452 minecraft:iron_block
fill 426 159 422 456 159 422 minecraft:iron_block
fill 427 159 427 463 159 427 minecraft:iron_block
fill 430 159 432 464 159 432 minecraft:iron_block
fill 425 160 426 425 165 428 minecraft:iron_block
fill 425 160 438 425 165 440 minecraft:iron_block
fill 425 160 450 425 165 452 minecraft:iron_block
fill 429 160 417 429 161 418 minecraft:iron_bars
fill 431 160 456 433 165 456 minecraft:iron_block
fill 434 160 417 434 161 418 minecraft:iron_bars
fill 435 160 418 437 165 418 minecraft:iron_block
fill 439 160 417 439 161 421 minecraft:iron_bars
fill 443 160 456 445 165 456 minecraft:iron_block
fill 444 160 417 444 161 418 minecraft:iron_bars
fill 447 160 418 449 165 418 minecraft:iron_block
fill 449 160 419 449 160 456 minecraft:iron_bars
fill 450 160 447 464 160 447 minecraft:iron_block
fill 454 160 417 454 161 420 minecraft:iron_bars
fill 454 160 422 464 160 422 minecraft:iron_block
fill 455 160 456 457 165 456 minecraft:iron_block
fill 459 160 417 459 161 417 minecraft:iron_bars
fill 459 160 418 461 165 418 minecraft:iron_block
fill 459 160 419 459 161 421 minecraft:iron_bars
fill 459 160 423 459 161 438 minecraft:iron_bars
fill 459 160 440 459 161 446 minecraft:iron_bars
fill 459 160 448 459 161 456 minecraft:iron_bars
fill 463 160 426 463 165 428 minecraft:iron_block
fill 463 160 438 463 165 440 minecraft:iron_block
fill 463 160 450 463 165 452 minecraft:iron_block
setblock 426 161 419 minecraft:light[level=12]
setblock 426 161 427 minecraft:light[level=12]
setblock 426 161 435 minecraft:light[level=12]
setblock 426 161 443 minecraft:light[level=12]
setblock 426 161 451 minecraft:light[level=12]
fill 429 161 419 429 161 456 minecraft:iron_bars
fill 434 161 419 434 161 454 minecraft:iron_bars
fill 439 161 422 439 161 440 minecraft:iron_bars
fill 439 161 445 439 161 457 minecraft:iron_bars
setblock 442 161 419 minecraft:light[level=12]
setblock 442 161 427 minecraft:light[level=12]
setblock 442 161 435 minecraft:light[level=12]
setblock 442 161 443 minecraft:light[level=12]
setblock 442 161 451 minecraft:light[level=12]
fill 444 161 419 444 161 453 minecraft:iron_bars
setblock 449 161 419 minecraft:iron_bars
setblock 450 161 419 minecraft:light[level=12]
setblock 450 161 427 minecraft:light[level=12]
setblock 450 161 435 minecraft:light[level=12]
setblock 450 161 443 minecraft:light[level=12]
setblock 450 161 451 minecraft:light[level=12]
fill 454 161 421 454 161 456 minecraft:iron_bars
setblock 458 161 419 minecraft:light[level=12]
setblock 458 161 427 minecraft:light[level=12]
setblock 458 161 435 minecraft:light[level=12]
setblock 458 161 443 minecraft:light[level=12]
setblock 458 161 451 minecraft:light[level=12]
setblock 459 161 422 minecraft:iron_bars
setblock 459 161 447 minecraft:iron_bars
fill 434 162 452 434 162 456 minecraft:iron_bars
fill 444 162 450 444 162 455 minecraft:iron_bars
fill 424 165 420 424 165 425 minecraft:cobblestone
fill 424 165 432 424 165 437 minecraft:cobblestone
fill 424 165 444 424 165 449 minecraft:cobblestone
fill 424 165 456 424 165 457 minecraft:cobblestone
fill 425 165 457 428 165 457 minecraft:cobblestone
fill 428 165 417 433 165 417 minecraft:cobblestone
fill 435 165 457 440 165 457 minecraft:cobblestone
fill 440 165 417 445 165 417 minecraft:cobblestone
fill 447 165 457 452 165 457 minecraft:cobblestone
fill 452 165 417 457 165 417 minecraft:cobblestone
fill 459 165 457 464 165 457 minecraft:cobblestone
fill 464 165 417 464 165 422 minecraft:cobblestone
fill 464 165 429 464 165 434 minecraft:cobblestone
fill 464 165 441 464 165 446 minecraft:cobblestone
fill 464 165 453 464 165 456 minecraft:cobblestone
fill 423 166 422 423 171 425 minecraft:glowstone
fill 423 166 434 423 171 437 minecraft:glowstone
fill 423 166 446 423 171 449 minecraft:glowstone
fill 423 166 458 426 171 458 minecraft:glowstone
fill 430 166 416 433 171 416 minecraft:glowstone
fill 435 166 458 438 171 458 minecraft:glowstone
fill 442 166 416 445 171 416 minecraft:glowstone
fill 447 166 458 450 171 458 minecraft:glowstone
fill 454 166 416 457 171 416 minecraft:glowstone
fill 459 166 458 462 171 458 minecraft:glowstone
fill 465 166 417 465 171 420 minecraft:glowstone
fill 465 166 429 465 171 432 minecraft:glowstone
fill 465 166 441 465 171 444 minecraft:glowstone
fill 465 166 453 465 171 456 minecraft:glowstone
setblock 426 169 419 minecraft:light[level=12]
setblock 426 169 427 minecraft:light[level=12]
setblock 426 169 435 minecraft:light[level=12]
setblock 426 169 443 minecraft:light[level=12]
setblock 426 169 451 minecraft:light[level=12]
setblock 434 169 419 minecraft:light[level=12]
setblock 434 169 427 minecraft:light[level=12]
setblock 434 169 435 minecraft:light[level=12]
setblock 434 169 443 minecraft:light[level=12]
setblock 434 169 451 minecraft:light[level=12]
setblock 442 169 419 minecraft:light[level=12]
setblock 442 169 427 minecraft:light[level=12]
setblock 442 169 435 minecraft:light[level=12]
setblock 442 169 443 minecraft:light[level=12]
setblock 442 169 451 minecraft:light[level=12]
setblock 450 169 419 minecraft:light[level=12]
setblock 450 169 427 minecraft:light[level=12]
setblock 450 169 435 minecraft:light[level=12]
setblock 450 169 443 minecraft:light[level=12]
setblock 450 169 451 minecraft:light[level=12]
setblock 458 169 419 minecraft:light[level=12]
setblock 458 169 427 minecraft:light[level=12]
setblock 458 169 435 minecraft:light[level=12]
setblock 458 169 443 minecraft:light[level=12]
setblock 458 169 451 minecraft:light[level=12]
fill 423 172 422 423 185 425 minecraft:cracked_stone_bricks
fill 423 172 434 423 185 437 minecraft:cracked_stone_bricks
fill 423 172 446 423 185 449 minecraft:cracked_stone_bricks
fill 423 172 458 426 185 458 minecraft:cracked_stone_bricks
fill 430 172 416 433 185 416 minecraft:cracked_stone_bricks
fill 435 172 458 438 185 458 minecraft:cracked_stone_bricks
fill 442 172 416 445 185 416 minecraft:cracked_stone_bricks
fill 447 172 458 450 185 458 minecraft:cracked_stone_bricks
fill 454 172 416 457 185 416 minecraft:cracked_stone_bricks
fill 459 172 458 462 185 458 minecraft:cracked_stone_bricks
fill 465 172 417 465 185 420 minecraft:cracked_stone_bricks
fill 465 172 429 465 185 432 minecraft:cracked_stone_bricks
fill 465 172 441 465 185 444 minecraft:cracked_stone_bricks
fill 465 172 453 465 185 456 minecraft:cracked_stone_bricks
setblock 426 177 419 minecraft:light[level=12]
setblock 426 177 427 minecraft:light[level=12]
setblock 426 177 435 minecraft:light[level=12]
setblock 426 177 443 minecraft:light[level=12]
setblock 426 177 451 minecraft:light[level=12]
setblock 434 177 419 minecraft:light[level=12]
setblock 434 177 427 minecraft:light[level=12]
setblock 434 177 435 minecraft:light[level=12]
fill 434 177 441 434 179 443 minecraft:iron_block
setblock 434 177 451 minecraft:light[level=12]
fill 435 177 439 435 179 441 minecraft:iron_block
fill 435 177 442 438 177 442 minecraft:cobblestone
fill 435 177 443 435 179 445 minecraft:iron_block
fill 436 177 437 436 179 438 minecraft:iron_block
fill 436 177 439 439 177 441 minecraft:cobblestone
fill 436 177 443 439 177 445 minecraft:cobblestone
fill 436 177 446 436 179 447 minecraft:iron_block
fill 437 177 437 437 179 437 minecraft:iron_block
fill 437 177 438 445 178 438 minecraft:cobblestone
fill 437 177 446 445 178 446 minecraft:cobblestone
fill 437 177 447 437 179 447 minecraft:iron_block
fill 438 177 436 440 179 436 minecraft:iron_block
fill 438 177 437 444 178 437 minecraft:cobblestone
fill 438 177 447 444 178 447 minecraft:cobblestone
fill 438 177 448 440 179 448 minecraft:iron_block
fill 440 177 435 442 179 435 minecraft:iron_block
fill 440 177 439 440 177 440 minecraft:cobblestone
fill 440 177 444 440 177 445 minecraft:cobblestone
fill 440 177 449 442 179 449 minecraft:iron_block
fill 441 177 436 441 178 436 minecraft:cobblestone
fill 441 177 439 446 177 439 minecraft:cobblestone
fill 441 177 445 446 177 445 minecraft:cobblestone
fill 441 177 448 441 178 448 minecraft:cobblestone
setblock 442 177 419 minecraft:light[level=12]
setblock 442 177 427 minecraft:light[level=12]
fill 442 177 436 444 179 436 minecraft:iron_block
fill 442 177 440 446 177 440 minecraft:cobblestone
fill 442 177 444 446 177 444 minecraft:cobblestone
fill 442 177 448 444 179 448 minecraft:iron_block
setblock 442 177 451 minecraft:light[level=12]
fill 443 177 441 446 177 441 minecraft:cobblestone
fill 443 177 443 446 177 443 minecraft:cobblestone
fill 444 177 442 447 177 442 minecraft:cobblestone
fill 445 177 437 446 179 437 minecraft:iron_block
fill 445 177 447 446 179 447 minecraft:iron_block
fill 446 177 438 446 179 438 minecraft:iron_block
fill 446 177 446 446 179 446 minecraft:iron_block
fill 447 177 439 447 179 441 minecraft:iron_block
fill 447 177 443 447 179 445 minecraft:iron_block
fill 448 177 441 448 179 443 minecraft:iron_block
setblock 450 177 419 minecraft:light[level=12]
setblock 450 177 427 minecraft:light[level=12]
setblock 450 177 435 minecraft:light[level=12]
setblock 450 177 443 minecraft:light[level=12]
setblock 450 177 451 minecraft:light[level=12]
setblock 458 177 419 minecraft:light[level=12]
setblock 458 177 427 minecraft:light[level=12]
setblock 458 177 435 minecraft:light[level=12]
setblock 458 177 443 minecraft:light[level=12]
setblock 458 177 451 minecraft:light[level=12]
fill 424 178 417 433 178 457 minecraft:cracked_stone_bricks
fill 434 178 417 434 178 439 minecraft:cracked_stone_bricks
setblock 434 178 440 minecraft:iron_block
setblock 434 178 444 minecraft:iron_block
fill 434 178 445 434 178 457 minecraft:cracked_stone_bricks
fill 435 178 417 435 178 437 minecraft:cracked_stone_bricks
setblock 435 178 438 minecraft:iron_block
fill 435 178 442 437 178 442 minecraft:cobblestone
setblock 435 178 446 minecraft:iron_block
fill 435 178 447 435 178 457 minecraft:cracked_stone_bricks
fill 436 178 417 436 178 436 minecraft:cracked_stone_bricks
fill 436 178 439 437 178 441 minecraft:cobblestone
fill 436 178 443 437 178 445 minecraft:cobblestone
fill 436 178 448 436 178 457 minecraft:cracked_stone_bricks
fill 437 178 417 438 178 435 minecraft:cracked_stone_bricks
setblock 437 178 436 minecraft:iron_block
setblock 437 178 448 minecraft:iron_block
fill 437 178 449 438 178 457 minecraft:cracked_stone_bricks
fill 438 178 439 438 178 440 minecraft:cobblestone
fill 438 178 441 438 178 443 minecraft:glowstone
fill 438 178 444 438 178 445 minecraft:cobblestone
fill 439 178 417 464 178 434 minecraft:cracked_stone_bricks
setblock 439 178 435 minecraft:iron_block
setblock 439 178 439 minecraft:cobblestone
fill 439 178 440 439 178 441 minecraft:glowstone
fill 439 178 443 439 178 444 minecraft:glowstone
setblock 439 178 445 minecraft:cobblestone
setblock 439 178 449 minecraft:iron_block
fill 439 178 450 464 178 457 minecraft:cracked_stone_bricks
fill 440 178 439 440 178 440 minecraft:glowstone
fill 440 178 444 440 178 445 minecraft:glowstone
fill 441 178 439 442 178 439 minecraft:glowstone
fill 441 178 445 442 178 445 minecraft:glowstone
fill 442 178 440 443 178 440 minecraft:glowstone
fill 442 178 444 443 178 444 minecraft:glowstone
setblock 443 178 435 minecraft:iron_block
fill 443 178 439 446 178 439 minecraft:cobblestone
fill 443 178 441 444 178 441 minecraft:glowstone
fill 443 178 443 444 178 443 minecraft:glowstone
fill 443 178 445 446 178 445 minecraft:cobblestone
setblock 443 178 449 minecraft:iron_block
fill 444 178 435 464 178 435 minecraft:cracked_stone_bricks
fill 444 178 440 446 178 440 minecraft:cobblestone
setblock 444 178 442 minecraft:glowstone
fill 444 178 444 446 178 444 minecraft:cobblestone
fill 444 178 449 464 178 449 minecraft:cracked_stone_bricks
setblock 445 178 436 minecraft:iron_block
fill 445 178 441 446 178 443 minecraft:cobblestone
setblock 445 178 448 minecraft:iron_block
fill 446 178 436 464 178 436 minecraft:cracked_stone_bricks
fill 446 178 448 464 178 448 minecraft:cracked_stone_bricks
fill 447 178 437 464 178 437 minecraft:cracked_stone_bricks
setblock 447 178 438 minecraft:iron_block
setblock 447 178 442 minecraft:cobblestone
setblock 447 178 446 minecraft:iron_block
fill 447 178 447 464 178 447 minecraft:cracked_stone_bricks
fill 448 178 438 464 178 439 minecraft:cracked_stone_bricks
setblock 448 178 440 minecraft:iron_block
setblock 448 178 444 minecraft:iron_block
fill 448 178 445 464 178 446 minecraft:cracked_stone_bricks
fill 449 178 440 464 178 444 minecraft:cracked_stone_bricks
fill 435 179 442 436 179 442 minecraft:iron_block
fill 436 179 439 436 179 441 minecraft:iron_block
fill 436 179 443 436 179 445 minecraft:iron_block
fill 437 179 438 437 179 439 minecraft:iron_block
fill 437 179 445 437 179 446 minecraft:iron_block
fill 438 179 437 438 179 438 minecraft:iron_block
fill 438 179 446 438 179 447 minecraft:iron_block
fill 439 179 437 444 179 437 minecraft:iron_block
fill 439 179 447 444 179 447 minecraft:iron_block
setblock 441 179 436 minecraft:iron_block
setblock 441 179 448 minecraft:iron_block
fill 444 179 438 445 179 438 minecraft:iron_block
fill 444 179 446 445 179 446 minecraft:iron_block
fill 445 179 439 446 179 439 minecraft:iron_block
fill 445 179 445 446 179 445 minecraft:iron_block
fill 446 179 440 446 179 444 minecraft:iron_block
setblock 447 179 442 minecraft:iron_block
fill 424 182 417 426 228 417 minecraft:iron_block
fill 424 182 424 427 183 436 minecraft:iron_block
fill 424 182 439 424 228 441 minecraft:iron_block
fill 424 182 451 424 228 453 minecraft:iron_block
fill 425 182 438 425 183 440 minecraft:iron_block
fill 425 182 450 425 185 452 minecraft:iron_block
fill 428 182 424 433 183 430 minecraft:iron_block
fill 430 182 439 430 185 445 minecraft:iron_block
fill 430 182 457 432 197 457 minecraft:iron_block
fill 431 182 437 431 185 438 minecraft:iron_block
fill 431 182 446 431 185 447 minecraft:iron_block
fill 431 182 456 433 185 456 minecraft:iron_block
fill 432 182 435 432 185 436 minecraft:iron_block
fill 432 182 448 432 185 449 minecraft:iron_block
fill 433 182 434 433 182 435 minecraft:iron_block
fill 433 182 449 433 182 450 minecraft:iron_block
fill 434 182 433 434 185 434 minecraft:iron_block
fill 434 182 450 434 185 451 minecraft:iron_block
fill 435 182 418 437 185 418 minecraft:iron_block
fill 435 182 433 435 185 433 minecraft:iron_block
fill 435 182 451 435 185 451 minecraft:iron_block
fill 436 182 417 438 228 417 minecraft:iron_block
fill 436 182 432 437 185 432 minecraft:iron_block
fill 436 182 452 437 185 452 minecraft:iron_block
fill 438 182 431 444 185 431 minecraft:iron_block
fill 438 182 453 444 185 453 minecraft:iron_block
fill 442 182 457 444 228 457 minecraft:iron_block
fill 443 182 456 445 185 456 minecraft:iron_block
fill 445 182 432 446 185 432 minecraft:iron_block
fill 445 182 452 446 185 452 minecraft:iron_block
fill 447 182 418 449 185 418 minecraft:iron_block
fill 447 182 433 448 185 433 minecraft:iron_block
fill 447 182 451 448 185 451 minecraft:iron_block
fill 448 182 417 450 228 417 minecraft:iron_block
fill 448 182 434 449 182 434 minecraft:iron_block
fill 448 182 450 449 182 450 minecraft:iron_block
fill 449 182 435 450 185 435 minecraft:iron_block
fill 449 182 449 450 185 449 minecraft:iron_block
fill 450 182 436 450 185 436 minecraft:iron_block
fill 450 182 448 450 185 448 minecraft:iron_block
fill 451 182 437 451 185 438 minecraft:iron_block
fill 451 182 446 451 185 447 minecraft:iron_block
fill 452 182 439 452 185 445 minecraft:iron_block
fill 454 182 457 456 228 457 minecraft:iron_block
fill 455 182 456 457 185 456 minecraft:iron_block
fill 459 182 418 461 185 418 minecraft:iron_block
fill 460 182 417 462 228 417 minecraft:iron_block
fill 463 182 426 463 185 428 minecraft:iron_block
fill 463 182 438 463 185 440 minecraft:iron_block
fill 463 182 450 463 185 452 minecraft:iron_block
fill 464 182 425 464 228 427 minecraft:iron_block
fill 464 182 437 464 228 439 minecraft:iron_block
fill 464 182 449 464 228 451 minecraft:iron_block
fill 429 183 439 429 183 445 minecraft:iron_block
fill 430 183 437 430 184 438 minecraft:iron_block
fill 430 183 446 430 184 447 minecraft:iron_block
fill 431 183 435 431 184 436 minecraft:iron_block
fill 431 183 439 431 184 445 minecraft:iron_block
fill 431 183 448 431 184 449 minecraft:iron_block
fill 432 183 434 432 184 434 minecraft:iron_block
fill 432 183 437 432 184 439 minecraft:iron_block
fill 432 183 445 432 184 447 minecraft:iron_block
fill 432 183 450 432 184 450 minecraft:iron_block
fill 433 183 433 433 184 433 minecraft:iron_block
fill 433 183 434 433 184 434 minecraft:light_gray_concrete
fill 433 183 435 433 184 436 minecraft:iron_block
fill 433 183 448 433 184 449 minecraft:iron_block
fill 433 183 450 433 184 450 minecraft:light_gray_concrete
fill 433 183 451 433 184 451 minecraft:iron_block
fill 434 183 432 435 184 432 minecraft:iron_block
fill 434 183 435 434 184 435 minecraft:light_gray_concrete
fill 434 183 449 434 184 449 minecraft:light_gray_concrete
fill 434 183 452 435 184 452 minecraft:iron_block
fill 435 183 434 435 184 434 minecraft:iron_block
fill 435 183 436 435 184 436 minecraft:light_gray_concrete
fill 435 183 448 435 184 448 minecraft:light_gray_concrete
fill 435 183 450 435 184 450 minecraft:iron_block
fill 436 183 431 437 184 431 minecraft:iron_block
fill 436 183 433 438 184 433 minecraft:iron_block
fill 436 183 437 436 184 437 minecraft:light_gray_concrete
fill 436 183 447 436 184 447 minecraft:light_gray_concrete
fill 436 183 451 438 184 451 minecraft:iron_block
fill 436 183 453 437 184 453 minecraft:iron_block
fill 437 183 438 437 184 438 minecraft:light_gray_concrete
fill 437 183 440 437 184 444 minecraft:white_concrete
fill 437 183 446 437 184 446 minecraft:light_gray_concrete
fill 438 183 430 444 184 430 minecraft:iron_block
fill 438 183 432 444 184 432 minecraft:iron_block
fill 438 183 439 438 184 440 minecraft:white_concrete
fill 438 183 444 438 184 445 minecraft:white_concrete
fill 438 183 452 444 184 452 minecraft:iron_block
fill 438 183 454 444 184 454 minecraft:iron_block
fill 439 183 438 439 184 439 minecraft:white_concrete
fill 439 183 445 439 184 446 minecraft:white_concrete
fill 440 183 438 443 184 438 minecraft:white_concrete
fill 440 183 446 443 184 446 minecraft:white_concrete
fill 443 183 439 444 184 439 minecraft:white_concrete
fill 443 183 445 444 184 445 minecraft:white_concrete
fill 444 183 433 446 184 433 minecraft:iron_block
fill 444 183 440 445 184 440 minecraft:white_concrete
fill 444 183 444 445 184 444 minecraft:white_concrete
fill 444 183 451 446 184 451 minecraft:iron_block
fill 445 183 431 446 184 431 minecraft:iron_block
fill 445 183 438 445 184 438 minecraft:light_gray_concrete
fill 445 183 441 445 184 443 minecraft:white_concrete
fill 445 183 446 445 184 446 minecraft:light_gray_concrete
fill 445 183 453 446 184 453 minecraft:iron_block
fill 446 183 437 446 184 437 minecraft:light_gray_concrete
fill 446 183 447 446 184 447 minecraft:light_gray_concrete
fill 447 183 432 448 184 432 minecraft:iron_block
fill 447 183 434 448 184 434 minecraft:iron_block
fill 447 183 436 447 184 436 minecraft:light_gray_concrete
fill 447 183 448 447 184 448 minecraft:light_gray_concrete
fill 447 183 450 448 184 450 minecraft:iron_block
fill 447 183 452 448 184 452 minecraft:iron_block
fill 448 183 435 448 184 435 minecraft:light_gray_concrete
fill 448 183 449 448 184 449 minecraft:light_gray_concrete
fill 449 183 433 449 184 433 minecraft:iron_block
fill 449 183 434 449 184 434 minecraft:light_gray_concrete
fill 449 183 436 449 184 436 minecraft:iron_block
fill 449 183 448 449 184 448 minecraft:iron_block
fill 449 183 450 449 184 450 minecraft:light_gray_concrete
fill 449 183 451 449 184 451 minecraft:iron_block
fill 450 183 434 450 184 434 minecraft:iron_block
fill 450 183 437 450 184 439 minecraft:iron_block
fill 450 183 445 450 184 447 minecraft:iron_block
fill 450 183 450 450 184 450 minecraft:iron_block
fill 451 183 435 451 184 436 minecraft:iron_block
fill 451 183 439 451 184 445 minecraft:iron_block
fill 451 183 448 451 184 449 minecraft:iron_block
fill 452 183 437 452 184 438 minecraft:iron_block
fill 452 183 446 452 184 447 minecraft:iron_block
fill 453 183 439 453 183 445 minecraft:iron_block
setblock 424 184 424 minecraft:iron_block
setblock 424 184 425 minecraft:glowstone
fill 424 184 426 424 195 426 minecraft:iron_block
setblock 424 184 427 minecraft:glowstone
fill 424 184 428 424 228 428 minecraft:iron_block
setblock 424 184 429 minecraft:glowstone
fill 424 184 430 424 195 430 minecraft:iron_block
setblock 424 184 431 minecraft:glowstone
setblock 424 184 432 minecraft:iron_block
setblock 424 184 433 minecraft:glowstone
setblock 424 184 434 minecraft:iron_block
setblock 424 184 435 minecraft:glowstone
setblock 424 184 436 minecraft:iron_block
setblock 425 184 424 minecraft:glowstone
fill 425 184 425 425 195 425 minecraft:iron_block
setblock 425 184 426 minecraft:glowstone
fill 425 184 427 425 195 427 minecraft:iron_block
setblock 425 184 428 minecraft:glowstone
fill 425 184 429 425 195 429 minecraft:iron_block
setblock 425 184 430 minecraft:glowstone
fill 425 184 431 425 195 431 minecraft:iron_block
setblock 425 184 432 minecraft:glowstone
fill 425 184 433 425 195 433 minecraft:iron_block
setblock 425 184 434 minecraft:glowstone
fill 425 184 435 425 195 435 minecraft:iron_block
setblock 425 184 436 minecraft:glowstone
fill 425 184 438 425 185 438 minecraft:iron_block
fill 425 184 439 429 184 445 minecraft:blue_stained_glass
fill 426 184 424 426 195 424 minecraft:iron_block
setblock 426 184 425 minecraft:glowstone
fill 426 184 426 426 195 426 minecraft:iron_block
setblock 426 184 427 minecraft:glowstone
fill 426 184 428 426 195 428 minecraft:iron_block
setblock 426 184 429 minecraft:glowstone
fill 426 184 430 426 195 430 minecraft:iron_block
setblock 426 184 431 minecraft:glowstone
fill 426 184 432 426 195 432 minecraft:iron_block
setblock 426 184 433 minecraft:glowstone
fill 426 184 434 426 195 434 minecraft:iron_block
setblock 426 184 435 minecraft:glowstone
fill 426 184 436 426 195 436 minecraft:iron_block
setblock 427 184 424 minecraft:glowstone
fill 427 184 425 427 195 425 minecraft:iron_block
setblock 427 184 426 minecraft:glowstone
fill 427 184 427 427 195 427 minecraft:iron_block
setblock 427 184 428 minecraft:glowstone
fill 427 184 429 427 195 429 minecraft:iron_block
setblock 427 184 430 minecraft:glowstone
fill 427 184 431 427 195 431 minecraft:iron_block
setblock 427 184 432 minecraft:glowstone
fill 427 184 433 427 195 433 minecraft:iron_block
setblock 427 184 434 minecraft:glowstone
fill 427 184 435 427 195 435 minecraft:iron_block
setblock 427 184 436 minecraft:glowstone
fill 428 184 424 428 193 424 minecraft:iron_block
setblock 428 184 425 minecraft:glowstone
fill 428 184 426 428 193 426 minecraft:iron_block
setblock 428 184 427 minecraft:glowstone
fill 428 184 428 428 193 428 minecraft:iron_block
setblock 428 184 429 minecraft:glowstone
fill 428 184 430 428 193 430 minecraft:iron_block
setblock 429 184 424 minecraft:glowstone
fill 429 184 425 429 193 425 minecraft:iron_block
setblock 429 184 426 minecraft:glowstone
fill 429 184 427 429 193 427 minecraft:iron_block
setblock 429 184 428 minecraft:glowstone
fill 429 184 429 429 193 429 minecraft:iron_block
setblock 429 184 430 minecraft:glowstone
fill 430 184 424 430 193 424 minecraft:iron_block
setblock 430 184 425 minecraft:glowstone
fill 430 184 426 430 193 426 minecraft:iron_block
setblock 430 184 427 minecraft:glowstone
fill 430 184 428 430 193 428 minecraft:iron_block
setblock 430 184 429 minecraft:glowstone
fill 430 184 430 430 193 430 minecraft:iron_block
setblock 431 184 424 minecraft:glowstone
fill 431 184 425 431 193 425 minecraft:iron_block
setblock 431 184 426 minecraft:glowstone
fill 431 184 427 431 193 427 minecraft:iron_block
setblock 431 184 428 minecraft:glowstone
fill 431 184 429 431 193 429 minecraft:iron_block
setblock 431 184 430 minecraft:glowstone
fill 432 184 424 432 193 424 minecraft:iron_block
setblock 432 184 425 minecraft:glowstone
fill 432 184 426 432 193 426 minecraft:iron_block
setblock 432 184 427 minecraft:glowstone
fill 432 184 428 432 193 428 minecraft:iron_block
setblock 432 184 429 minecraft:glowstone
fill 432 184 430 432 193 430 minecraft:iron_block
setblock 433 184 424 minecraft:glowstone
fill 433 184 425 433 193 425 minecraft:iron_block
setblock 433 184 426 minecraft:glowstone
fill 433 184 427 433 193 427 minecraft:iron_block
setblock 433 184 428 minecraft:glowstone
fill 433 184 429 433 193 429 minecraft:iron_block
setblock 433 184 430 minecraft:glowstone
fill 453 184 439 457 184 445 minecraft:blue_stained_glass
fill 424 185 420 424 185 425 minecraft:cobblestone
fill 424 185 427 424 186 427 minecraft:iron_block
fill 424 185 429 424 186 429 minecraft:iron_block
fill 424 185 431 424 186 431 minecraft:iron_block
fill 424 185 432 424 185 437 minecraft:cobblestone
fill 424 185 444 424 185 449 minecraft:cobblestone
fill 424 185 456 424 185 457 minecraft:cobblestone
fill 425 185 424 425 186 424 minecraft:iron_block
fill 425 185 426 425 186 426 minecraft:iron_block
fill 425 185 428 425 186 428 minecraft:iron_block
fill 425 185 430 425 186 430 minecraft:iron_block
fill 425 185 432 425 186 432 minecraft:iron_block
fill 425 185 434 425 186 434 minecraft:iron_block
fill 425 185 436 425 186 436 minecraft:iron_block
fill 425 185 439 425 185 440 minecraft:iron_block
fill 425 185 457 428 185 457 minecraft:cobblestone
setblock 426 185 419 minecraft:light[level=12]
fill 426 185 425 426 186 425 minecraft:iron_block
fill 426 185 427 426 186 427 minecraft:iron_block
fill 426 185 429 426 186 429 minecraft:iron_block
fill 426 185 431 426 186 431 minecraft:iron_block
fill 426 185 433 426 186 433 minecraft:iron_block
fill 426 185 435 426 186 435 minecraft:iron_block
setblock 426 185 443 minecraft:light[level=12]
setblock 426 185 451 minecraft:light[level=12]
fill 427 185 424 427 186 424 minecraft:iron_block
fill 427 185 426 427 186 426 minecraft:iron_block
fill 427 185 428 427 186 428 minecraft:iron_block
fill 427 185 430 427 186 430 minecraft:iron_block
fill 427 185 432 427 186 432 minecraft:iron_block
fill 427 185 434 427 186 434 minecraft:iron_block
fill 427 185 436 427 186 436 minecraft:iron_block
fill 428 185 417 433 185 417 minecraft:cobblestone
fill 428 185 425 428 186 425 minecraft:iron_block
fill 428 185 427 428 186 427 minecraft:iron_block
fill 428 185 429 428 186 429 minecraft:iron_block
fill 429 185 424 429 186 424 minecraft:iron_block
fill 429 185 426 429 186 426 minecraft:iron_block
fill 429 185 428 429 186 428 minecraft:iron_block
fill 429 185 430 429 186 430 minecraft:iron_block
fill 430 185 425 430 186 425 minecraft:iron_block
fill 430 185 427 430 186 427 minecraft:iron_block
fill 430 185 429 430 186 429 minecraft:iron_block
fill 431 185 424 431 186 424 minecraft:iron_block
fill 431 185 426 431 186 426 minecraft:iron_block
fill 431 185 428 431 186 428 minecraft:iron_block
fill 431 185 430 431 186 430 minecraft:iron_block
fill 432 185 425 432 186 425 minecraft:iron_block
fill 432 185 427 432 186 427 minecraft:iron_block
fill 432 185 429 432 186 429 minecraft:iron_block
fill 433 185 424 433 186 424 minecraft:iron_block
fill 433 185 426 433 186 426 minecraft:iron_block
fill 433 185 428 433 186 428 minecraft:iron_block
fill 433 185 430 433 186 430 minecraft:iron_block
fill 433 185 434 433 185 435 minecraft:iron_block
fill 433 185 449 433 185 450 minecraft:iron_block
setblock 434 185 419 minecraft:light[level=12]
setblock 434 185 427 minecraft:light[level=12]
setblock 434 185 435 minecraft:light[level=12]
setblock 434 185 443 minecraft:light[level=12]
fill 435 185 457 440 185 457 minecraft:cobblestone
fill 440 185 417 445 185 417 minecraft:cobblestone
setblock 442 185 419 minecraft:light[level=12]
setblock 442 185 427 minecraft:light[level=12]
setblock 442 185 435 minecraft:light[level=12]
setblock 442 185 443 minecraft:light[level=12]
setblock 442 185 451 minecraft:light[level=12]
fill 447 185 457 452 185 457 minecraft:cobblestone
fill 448 185 434 449 185 434 minecraft:iron_block
fill 448 185 450 449 185 450 minecraft:iron_block
setblock 450 185 419 minecraft:light[level=12]
setblock 450 185 427 minecraft:light[level=12]
setblock 450 185 443 minecraft:light[level=12]
setblock 450 185 451 minecraft:light[level=12]
fill 452 185 417 457 185 417 minecraft:cobblestone
setblock 458 185 419 minecraft:light[level=12]
setblock 458 185 427 minecraft:light[level=12]
setblock 458 185 435 minecraft:light[level=12]
setblock 458 185 443 minecraft:light[level=12]
setblock 458 185 451 minecraft:light[level=12]
fill 459 185 457 464 185 457 minecraft:cobblestone
fill 464 185 417 464 185 422 minecraft:cobblestone
fill 464 185 429 464 185 434 minecraft:cobblestone
fill 464 185 441 464 185 446 minecraft:cobblestone
fill 464 185 453 464 185 456 minecraft:cobblestone
fill 423 186 422 423 191 425 minecraft:glowstone
fill 423 186 434 423 191 437 minecraft:glowstone
fill 423 186 446 423 191 449 minecraft:glowstone
fill 423 186 458 426 191 458 minecraft:glowstone
fill 424 186 424 424 186 425 minecraft:iron_block
fill 424 186 432 424 186 436 minecraft:iron_block
fill 430 186 416 433 191 416 minecraft:glowstone
fill 435 186 458 438 191 458 minecraft:glowstone
fill 442 186 416 445 191 416 minecraft:glowstone
fill 447 186 458 450 191 458 minecraft:glowstone
fill 454 186 416 457 191 416 minecraft:glowstone
fill 459 186 458 462 191 458 minecraft:glowstone
fill 465 186 417 465 191 420 minecraft:glowstone
fill 465 186 429 465 191 432 minecraft:glowstone
fill 465 186 441 465 191 444 minecraft:glowstone
fill 465 186 453 465 191 456 minecraft:glowstone
fill 424 187 424 424 195 424 minecraft:iron_block
setblock 424 187 425 minecraft:glowstone
setblock 424 187 427 minecraft:glowstone
setblock 424 187 429 minecraft:glowstone
setblock 424 187 431 minecraft:glowstone
fill 424 187 432 424 195 432 minecraft:iron_block
setblock 424 187 433 minecraft:glowstone
fill 424 187 434 424 195 434 minecraft:iron_block
setblock 424 187 435 minecraft:glowstone
fill 424 187 436 424 195 436 minecraft:iron_block
setblock 425 187 424 minecraft:glowstone
setblock 425 187 426 minecraft:glowstone
setblock 425 187 428 minecraft:glowstone
setblock 425 187 430 minecraft:glowstone
setblock 425 187 432 minecraft:glowstone
setblock 425 187 434 minecraft:glowstone
setblock 425 187 436 minecraft:glowstone
setblock 426 187 425 minecraft:glowstone
setblock 426 187 427 minecraft:glowstone
setblock 426 187 429 minecraft:glowstone
setblock 426 187 431 minecraft:glowstone
setblock 426 187 433 minecraft:glowstone
setblock 426 187 435 minecraft:glowstone
setblock 427 187 424 minecraft:glowstone
setblock 427 187 426 minecraft:glowstone
setblock 427 187 428 minecraft:glowstone
setblock 427 187 430 minecraft:glowstone
setblock 427 187 432 minecraft:glowstone
setblock 427 187 434 minecraft:glowstone
setblock 427 187 436 minecraft:glowstone
setblock 428 187 425 minecraft:glowstone
setblock 428 187 427 minecraft:glowstone
setblock 428 187 429 minecraft:glowstone
setblock 429 187 424 minecraft:glowstone
setblock 429 187 426 minecraft:glowstone
setblock 429 187 428 minecraft:glowstone
setblock 429 187 430 minecraft:glowstone
setblock 430 187 425 minecraft:glowstone
setblock 430 187 427 minecraft:glowstone
setblock 430 187 429 minecraft:glowstone
setblock 431 187 424 minecraft:glowstone
setblock 431 187 426 minecraft:glowstone
setblock 431 187 428 minecraft:glowstone
setblock 431 187 430 minecraft:glowstone
setblock 432 187 425 minecraft:glowstone
setblock 432 187 427 minecraft:glowstone
setblock 432 187 429 minecraft:glowstone
setblock 433 187 424 minecraft:glowstone
setblock 433 187 426 minecraft:glowstone
setblock 433 187 428 minecraft:glowstone
setblock 433 187 430 minecraft:glowstone
fill 424 188 425 424 189 425 minecraft:iron_block
fill 424 188 427 424 189 427 minecraft:iron_block
fill 424 188 429 424 189 429 minecraft:iron_block
fill 424 188 431 424 189 431 minecraft:iron_block
fill 424 188 433 424 189 433 minecraft:iron_block
fill 424 188 435 424 189 435 minecraft:iron_block
fill 425 188 424 425 189 424 minecraft:iron_block
fill 425 188 426 425 189 426 minecraft:iron_block
fill 425 188 428 425 189 428 minecraft:iron_block
fill 425 188 430 425 189 430 minecraft:iron_block
fill 425 188 432 425 189 432 minecraft:iron_block
fill 425 188 434 425 189 434 minecraft:iron_block
fill 425 188 436 425 189 436 minecraft:iron_block
fill 426 188 425 426 189 425 minecraft:iron_block
fill 426 188 427 426 189 427 minecraft:iron_block
fill 426 188 429 426 189 429 minecraft:iron_block
fill 426 188 431 426 189 431 minecraft:iron_block
fill 426 188 433 426 189 433 minecraft:iron_block
fill 426 188 435 426 189 435 minecraft:iron_block
fill 427 188 424 427 189 424 minecraft:iron_block
fill 427 188 426 427 189 426 minecraft:iron_block
fill 427 188 428 427 189 428 minecraft:iron_block
fill 427 188 430 427 189 430 minecraft:iron_block
fill 427 188 432 427 189 432 minecraft:iron_block
fill 427 188 434 427 189 434 minecraft:iron_block
fill 427 188 436 427 189 436 minecraft:iron_block
fill 428 188 425 428 189 425 minecraft:iron_block
fill 428 188 427 428 189 427 minecraft:iron_block
fill 428 188 429 428 189 429 minecraft:iron_block
fill 429 188 424 429 189 424 minecraft:iron_block
fill 429 188 426 429 189 426 minecraft:iron_block
fill 429 188 428 429 189 428 minecraft:iron_block
fill 429 188 430 429 189 430 minecraft:iron_block
fill 430 188 425 430 189 425 minecraft:iron_block
fill 430 188 427 430 189 427 minecraft:iron_block
fill 430 188 429 430 189 429 minecraft:iron_block
fill 431 188 424 431 189 424 minecraft:iron_block
fill 431 188 426 431 189 426 minecraft:iron_block
fill 431 188 428 431 189 428 minecraft:iron_block
fill 431 188 430 431 189 430 minecraft:iron_block
fill 432 188 425 432 189 425 minecraft:iron_block
fill 432 188 427 432 189 427 minecraft:iron_block
fill 432 188 429 432 189 429 minecraft:iron_block
fill 433 188 424 433 189 424 minecraft:iron_block
fill 433 188 426 433 189 426 minecraft:iron_block
fill 433 188 428 433 189 428 minecraft:iron_block
fill 433 188 430 433 189 430 minecraft:iron_block
setblock 424 190 425 minecraft:glowstone
setblock 424 190 427 minecraft:glowstone
setblock 424 190 429 minecraft:glowstone
setblock 424 190 431 minecraft:glowstone
setblock 424 190 433 minecraft:glowstone
setblock 424 190 435 minecraft:glowstone
setblock 425 190 424 minecraft:glowstone
setblock 425 190 426 minecraft:glowstone
setblock 425 190 428 minecraft:glowstone
setblock 425 190 430 minecraft:glowstone
setblock 425 190 432 minecraft:glowstone
setblock 425 190 434 minecraft:glowstone
setblock 425 190 436 minecraft:glowstone
setblock 426 190 425 minecraft:glowstone
setblock 426 190 427 minecraft:glowstone
setblock 426 190 429 minecraft:glowstone
setblock 426 190 431 minecraft:glowstone
setblock 426 190 433 minecraft:glowstone
setblock 426 190 435 minecraft:glowstone
setblock 427 190 424 minecraft:glowstone
setblock 427 190 426 minecraft:glowstone
setblock 427 190 428 minecraft:glowstone
setblock 427 190 430 minecraft:glowstone
setblock 427 190 432 minecraft:glowstone
setblock 427 190 434 minecraft:glowstone
setblock 427 190 436 minecraft:glowstone
setblock 428 190 425 minecraft:glowstone
setblock 428 190 427 minecraft:glowstone
setblock 428 190 429 minecraft:glowstone
setblock 429 190 424 minecraft:glowstone
setblock 429 190 426 minecraft:glowstone
setblock 429 190 428 minecraft:glowstone
setblock 429 190 430 minecraft:glowstone
setblock 430 190 425 minecraft:glowstone
setblock 430 190 427 minecraft:glowstone
setblock 430 190 429 minecraft:glowstone
setblock 431 190 424 minecraft:glowstone
setblock 431 190 426 minecraft:glowstone
setblock 431 190 428 minecraft:glowstone
setblock 431 190 430 minecraft:glowstone
setblock 432 190 425 minecraft:glowstone
setblock 432 190 427 minecraft:glowstone
setblock 432 190 429 minecraft:glowstone
setblock 433 190 424 minecraft:glowstone
setblock 433 190 426 minecraft:glowstone
setblock 433 190 428 minecraft:glowstone
setblock 433 190 430 minecraft:glowstone
fill 424 191 425 424 192 425 minecraft:iron_block
fill 424 191 427 424 192 427 minecraft:iron_block
fill 424 191 429 424 192 429 minecraft:iron_block
fill 424 191 431 424 192 431 minecraft:iron_block
fill 424 191 433 424 192 433 minecraft:iron_block
fill 424 191 435 424 192 435 minecraft:iron_block
fill 425 191 424 425 192 424 minecraft:iron_block
fill 425 191 426 425 192 426 minecraft:iron_block
fill 425 191 428 425 192 428 minecraft:iron_block
fill 425 191 430 425 192 430 minecraft:iron_block
fill 425 191 432 425 192 432 minecraft:iron_block
fill 425 191 434 425 192 434 minecraft:iron_block
fill 425 191 436 425 192 436 minecraft:iron_block
fill 425 191 440 426 192 440 minecraft:iron_bars
fill 426 191 425 426 192 425 minecraft:iron_block
fill 426 191 427 426 192 427 minecraft:iron_block
fill 426 191 429 426 192 429 minecraft:iron_block
fill 426 191 431 426 192 431 minecraft:iron_block
fill 426 191 433 426 192 433 minecraft:iron_block
fill 426 191 435 426 192 435 minecraft:iron_block
fill 427 191 424 427 192 424 minecraft:iron_block
fill 427 191 426 427 192 426 minecraft:iron_block
fill 427 191 428 427 192 428 minecraft:iron_block
fill 427 191 430 427 192 430 minecraft:iron_block
fill 427 191 432 427 192 432 minecraft:iron_block
fill 427 191 434 427 192 434 minecraft:iron_block
fill 427 191 436 427 192 436 minecraft:iron_block
fill 428 191 425 428 193 425 minecraft:iron_block
fill 428 191 427 428 193 427 minecraft:iron_block
fill 428 191 429 428 193 429 minecraft:iron_block
fill 429 191 424 429 193 424 minecraft:iron_block
fill 429 191 426 429 193 426 minecraft:iron_block
fill 429 191 428 429 193 428 minecraft:iron_block
fill 429 191 430 429 193 430 minecraft:iron_block
fill 430 191 425 430 193 425 minecraft:iron_block
fill 430 191 427 430 193 427 minecraft:iron_block
fill 430 191 429 430 193 429 minecraft:iron_block
fill 431 191 424 431 193 424 minecraft:iron_block
fill 431 191 426 431 193 426 minecraft:iron_block
fill 431 191 428 431 193 428 minecraft:iron_block
fill 431 191 430 431 193 430 minecraft:iron_block
fill 432 191 425 432 193 425 minecraft:iron_block
fill 432 191 427 432 193 427 minecraft:iron_block
fill 432 191 429 432 193 429 minecraft:iron_block
fill 433 191 424 433 193 424 minecraft:iron_block
fill 433 191 426 433 193 426 minecraft:iron_block
fill 433 191 428 433 193 428 minecraft:iron_block
fill 433 191 430 433 193 430 minecraft:iron_block
fill 423 192 422 423 205 422 minecraft:cracked_stone_bricks
fill 423 192 423 423 192 424 minecraft:glowstone
fill 423 192 425 423 205 425 minecraft:cracked_stone_bricks
fill 423 192 434 423 205 434 minecraft:cracked_stone_bricks
fill 423 192 435 423 192 436 minecraft:glowstone
fill 423 192 437 423 205 437 minecraft:cracked_stone_bricks
fill 423 192 446 423 205 446 minecraft:cracked_stone_bricks
fill 423 192 447 423 192 448 minecraft:glowstone
fill 423 192 449 423 205 449 minecraft:cracked_stone_bricks
fill 423 192 458 423 205 458 minecraft:cracked_stone_bricks
fill 424 192 458 425 192 458 minecraft:glowstone
fill 426 192 458 426 205 458 minecraft:cracked_stone_bricks
fill 430 192 416 430 205 416 minecraft:cracked_stone_bricks
fill 431 192 416 432 192 416 minecraft:glowstone
fill 431 192 452 431 195 452 minecraft:iron_bars
fill 433 192 416 433 205 416 minecraft:cracked_stone_bricks
fill 435 192 458 435 205 458 minecraft:cracked_stone_bricks
fill 436 192 458 437 192 458 minecraft:glowstone
fill 438 192 458 438 205 458 minecraft:cracked_stone_bricks
fill 442 192 416 442 205 416 minecraft:cracked_stone_bricks
fill 443 192 416 444 192 416 minecraft:glowstone
fill 445 192 416 445 205 416 minecraft:cracked_stone_bricks
fill 447 192 458 447 205 458 minecraft:cracked_stone_bricks
fill 448 192 458 449 192 458 minecraft:glowstone
fill 450 192 458 450 205 458 minecraft:cracked_stone_bricks
fill 454 192 416 454 199 416 minecraft:cracked_stone_bricks
fill 455 192 416 456 192 416 minecraft:glowstone
fill 457 192 416 457 205 416 minecraft:cracked_stone_bricks
fill 459 192 458 459 205 458 minecraft:cracked_stone_bricks
fill 460 192 458 461 192 458 minecraft:glowstone
fill 462 192 458 462 205 458 minecraft:cracked_stone_bricks
fill 465 192 417 465 205 417 minecraft:cracked_stone_bricks
fill 465 192 418 465 192 419 minecraft:glowstone
fill 465 192 420 465 205 420 minecraft:cracked_stone_bricks
fill 465 192 429 465 205 429 minecraft:cracked_stone_bricks
fill 465 192 430 465 192 431 minecraft:glowstone
fill 465 192 432 465 205 432 minecraft:cracked_stone_bricks
fill 465 192 441 465 205 441 minecraft:cracked_stone_bricks
fill 465 192 442 465 192 443 minecraft:glowstone
fill 465 192 444 465 205 444 minecraft:cracked_stone_bricks
fill 465 192 453 465 205 453 minecraft:cracked_stone_bricks
fill 465 192 454 465 192 455 minecraft:glowstone
fill 465 192 456 465 205 456 minecraft:cracked_stone_bricks
fill 423 193 423 423 205 424 minecraft:cracked_stone_bricks
fill 423 193 435 423 205 436 minecraft:cracked_stone_bricks
fill 423 193 447 423 205 448 minecraft:cracked_stone_bricks
setblock 424 193 425 minecraft:glowstone
setblock 424 193 427 minecraft:glowstone
setblock 424 193 429 minecraft:glowstone
setblock 424 193 431 minecraft:glowstone
setblock 424 193 433 minecraft:glowstone
setblock 424 193 435 minecraft:glowstone
fill 424 193 458 425 205 458 minecraft:cracked_stone_bricks
setblock 425 193 424 minecraft:glowstone
setblock 425 193 426 minecraft:glowstone
setblock 425 193 428 minecraft:glowstone
setblock 425 193 430 minecraft:glowstone
setblock 425 193 432 minecraft:glowstone
setblock 425 193 434 minecraft:glowstone
setblock 425 193 436 minecraft:glowstone
setblock 426 193 419 minecraft:light[level=12]
setblock 426 193 425 minecraft:glowstone
setblock 426 193 427 minecraft:glowstone
setblock 426 193 429 minecraft:glowstone
setblock 426 193 431 minecraft:glowstone
setblock 426 193 433 minecraft:glowstone
setblock 426 193 435 minecraft:glowstone
setblock 426 193 443 minecraft:light[level=12]
setblock 426 193 451 minecraft:light[level=12]
setblock 427 193 424 minecraft:glowstone
setblock 427 193 426 minecraft:glowstone
setblock 427 193 428 minecraft:glowstone
setblock 427 193 430 minecraft:glowstone
setblock 427 193 432 minecraft:glowstone
setblock 427 193 434 minecraft:glowstone
setblock 427 193 436 minecraft:glowstone
fill 431 193 416 432 205 416 minecraft:cracked_stone_bricks
setblock 434 193 419 minecraft:light[level=12]
setblock 434 193 427 minecraft:light[level=12]
setblock 434 193 435 minecraft:light[level=12]
setblock 434 193 443 minecraft:light[level=12]
setblock 434 193 451 minecraft:light[level=12]
fill 436 193 458 437 205 458 minecraft:cracked_stone_bricks
setblock 442 193 419 minecraft:light[level=12]
setblock 442 193 427 minecraft:light[level=12]
setblock 442 193 435 minecraft:light[level=12]
setblock 442 193 443 minecraft:light[level=12]
setblock 442 193 451 minecraft:light[level=12]
fill 443 193 416 444 205 416 minecraft:cracked_stone_bricks
fill 448 193 458 449 205 458 minecraft:cracked_stone_bricks
setblock 450 193 419 minecraft:light[level=12]
setblock 450 193 427 minecraft:light[level=12]
setblock 450 193 435 minecraft:light[level=12]
setblock 450 193 443 minecraft:light[level=12]
setblock 450 193 451 minecraft:light[level=12]
fill 455 193 416 456 199 416 minecraft:cracked_stone_bricks
setblock 458 193 419 minecraft:light[level=12]
setblock 458 193 427 minecraft:light[level=12]
setblock 458 193 435 minecraft:light[level=12]
setblock 458 193 443 minecraft:light[level=12]
setblock 458 193 451 minecraft:light[level=12]
fill 460 193 458 461 205 458 minecraft:cracked_stone_bricks
fill 465 193 418 465 205 419 minecraft:cracked_stone_bricks
fill 465 193 430 465 205 431 minecraft:cracked_stone_bricks
fill 465 193 442 465 205 443 minecraft:cracked_stone_bricks
fill 465 193 454 465 205 455 minecraft:cracked_stone_bricks
fill 424 194 425 424 195 425 minecraft:iron_block
fill 424 194 427 424 228 427 minecraft:iron_block
fill 424 194 429 424 228 429 minecraft:iron_block
fill 424 194 431 424 195 431 minecraft:iron_block
fill 424 194 433 424 195 433 minecraft:iron_block
fill 424 194 435 424 195 435 minecraft:iron_block
fill 425 194 424 425 195 424 minecraft:iron_block
fill 425 194 426 425 195 426 minecraft:iron_block
fill 425 194 428 425 195 428 minecraft:iron_block
fill 425 194 430 425 195 430 minecraft:iron_block
fill 425 194 432 425 195 432 minecraft:iron_block
fill 425 194 434 425 195 434 minecraft:iron_block
fill 425 194 436 425 195 436 minecraft:iron_block
fill 426 194 425 426 195 425 minecraft:iron_block
fill 426 194 427 426 195 427 minecraft:iron_block
fill 426 194 429 426 195 429 minecraft:iron_block
fill 426 194 431 426 195 431 minecraft:iron_block
fill 426 194 433 426 195 433 minecraft:iron_block
fill 426 194 435 426 195 435 minecraft:iron_block
fill 427 194 424 427 195 424 minecraft:iron_block
fill 427 194 426 427 195 426 minecraft:iron_block
fill 427 194 428 427 195 428 minecraft:iron_block
fill 427 194 430 427 195 430 minecraft:iron_block
fill 427 194 432 427 195 432 minecraft:iron_block
fill 427 194 434 427 195 434 minecraft:iron_block
fill 427 194 436 427 195 436 minecraft:iron_block
fill 454 194 422 454 197 422 minecraft:iron_bars
fill 458 195 417 458 196 419 minecraft:iron_bars
fill 428 196 452 434 196 456 minecraft:cobblestone
fill 428 197 452 434 197 456 minecraft:iron_block
fill 428 198 452 434 198 452 minecraft:gray_concrete
fill 430 198 457 432 201 457 minecraft:glowstone
fill 450 198 418 458 198 422 minecraft:cobblestone
fill 451 198 417 458 198 417 minecraft:cobblestone
setblock 428 199 452 minecraft:iron_block
setblock 431 199 452 minecraft:iron_block
setblock 434 199 452 minecraft:iron_block
fill 450 199 418 458 199 422 minecraft:iron_block
fill 451 199 417 458 199 417 minecraft:iron_block
fill 425 200 426 425 205 428 minecraft:iron_block
fill 425 200 438 425 205 440 minecraft:iron_block
fill 425 200 450 425 205 452 minecraft:iron_block
fill 431 200 456 433 205 456 minecraft:iron_block
fill 435 200 418 437 205 418 minecraft:iron_block
fill 443 200 456 445 205 456 minecraft:iron_block
fill 447 200 418 449 205 418 minecraft:iron_block
fill 450 200 416 452 212 416 minecraft:cracked_stone_bricks
fill 450 200 422 458 200 422 minecraft:gray_concrete
fill 453 200 416 455 203 416 minecraft:glowstone
fill 455 200 456 457 205 456 minecraft:iron_block
fill 456 200 416 456 205 416 minecraft:cracked_stone_bricks
fill 459 200 418 461 205 418 minecraft:iron_block
fill 463 200 426 463 205 428 minecraft:iron_block
fill 463 200 438 463 205 440 minecraft:iron_block
fill 463 200 450 463 205 452 minecraft:iron_block
setblock 426 201 419 minecraft:light[level=12]
setblock 426 201 427 minecraft:light[level=12]
setblock 426 201 435 minecraft:light[level=12]
setblock 426 201 443 minecraft:light[level=12]
setblock 426 201 451 minecraft:light[level=12]
setblock 434 201 419 minecraft:light[level=12]
setblock 434 201 427 minecraft:light[level=12]
setblock 434 201 435 minecraft:light[level=12]
setblock 434 201 443 minecraft:light[level=12]
setblock 434 201 451 minecraft:light[level=12]
fill 438 201 454 438 220 454 minecraft:iron_bars
setblock 442 201 419 minecraft:light[level=12]
setblock 442 201 427 minecraft:light[level=12]
setblock 442 201 435 minecraft:light[level=12]
setblock 442 201 443 minecraft:light[level=12]
setblock 442 201 451 minecraft:light[level=12]
setblock 450 201 419 minecraft:light[level=12]
setblock 450 201 422 minecraft:iron_block
setblock 450 201 427 minecraft:light[level=12]
setblock 450 201 435 minecraft:light[level=12]
setblock 450 201 443 minecraft:light[level=12]
setblock 450 201 451 minecraft:light[level=12]
setblock 454 201 422 minecraft:iron_block
setblock 458 201 419 minecraft:light[level=12]
setblock 458 201 422 minecraft:iron_block
setblock 458 201 427 minecraft:light[level=12]
setblock 458 201 435 minecraft:light[level=12]
setblock 458 201 443 minecraft:light[level=12]
setblock 458 201 451 minecraft:light[level=12]
fill 430 202 457 432 228 457 minecraft:iron_block
fill 453 204 416 455 205 416 minecraft:cracked_stone_bricks
fill 424 205 420 424 205 425 minecraft:cobblestone
fill 424 205 432 424 205 437 minecraft:cobblestone
fill 424 205 444 424 205 449 minecraft:cobblestone
fill 424 205 456 424 205 457 minecraft:cobblestone
fill 425 205 457 428 205 457 minecraft:cobblestone
fill 428 205 417 433 205 417 minecraft:cobblestone
fill 435 205 457 440 205 457 minecraft:cobblestone
fill 440 205 417 445 205 417 minecraft:cobblestone
fill 447 205 457 452 205 457 minecraft:cobblestone
fill 452 205 417 457 205 417 minecraft:cobblestone
fill 459 205 457 464 205 457 minecraft:cobblestone
fill 464 205 417 464 205 422 minecraft:cobblestone
fill 464 205 429 464 205 434 minecraft:cobblestone
fill 464 205 441 464 205 446 minecraft:cobblestone
fill 464 205 453 464 205 456 minecraft:cobblestone
fill 423 206 422 423 211 425 minecraft:glowstone
fill 423 206 434 423 211 437 minecraft:glowstone
fill 423 206 446 423 211 449 minecraft:glowstone
fill 423 206 458 426 211 458 minecraft:glowstone
fill 430 206 416 433 211 416 minecraft:glowstone
fill 435 206 458 438 211 458 minecraft:glowstone
fill 442 206 416 445 211 416 minecraft:glowstone
fill 447 206 458 450 211 458 minecraft:glowstone
fill 453 206 416 453 212 416 minecraft:cracked_stone_bricks
fill 454 206 416 457 211 416 minecraft:glowstone
fill 459 206 458 462 211 458 minecraft:glowstone
fill 465 206 417 465 211 420 minecraft:glowstone
fill 465 206 429 465 211 432 minecraft:glowstone
fill 465 206 441 465 211 444 minecraft:glowstone
fill 465 206 453 465 211 456 minecraft:glowstone
fill 440 207 422 440 222 422 minecraft:iron_bars
fill 423 209 416 423 212 417 minecraft:cracked_stone_bricks
fill 423 209 418 423 210 418 minecraft:stone_bricks
fill 423 209 420 423 213 420 minecraft:cracked_stone_bricks
fill 423 209 421 423 210 421 minecraft:stone_bricks
fill 423 209 439 423 209 442 minecraft:cracked_stone_bricks
setblock 423 209 443 minecraft:stone_bricks
setblock 426 209 419 minecraft:light[level=12]
setblock 426 209 427 minecraft:light[level=12]
setblock 426 209 435 minecraft:light[level=12]
setblock 426 209 443 minecraft:light[level=12]
setblock 426 209 451 minecraft:light[level=12]
fill 427 209 458 427 210 458 minecraft:cracked_stone_bricks
fill 428 209 458 429 209 458 minecraft:stone_bricks
setblock 434 209 419 minecraft:light[level=12]
setblock 434 209 427 minecraft:light[level=12]
setblock 434 209 435 minecraft:light[level=12]
setblock 434 209 443 minecraft:light[level=12]
setblock 434 209 451 minecraft:light[level=12]
fill 436 209 416 436 210 416 minecraft:cracked_stone_bricks
setblock 437 209 416 minecraft:stone_bricks
fill 438 209 416 441 209 416 minecraft:cracked_stone_bricks
fill 439 209 458 440 210 458 minecraft:cracked_stone_bricks
fill 441 209 458 441 210 458 minecraft:stone_bricks
setblock 442 209 419 minecraft:light[level=12]
setblock 442 209 427 minecraft:light[level=12]
setblock 442 209 435 minecraft:light[level=12]
setblock 442 209 443 minecraft:light[level=12]
setblock 442 209 451 minecraft:light[level=12]
fill 442 209 458 443 212 458 minecraft:cracked_stone_bricks
fill 447 209 416 448 212 416 minecraft:cracked_stone_bricks
setblock 449 209 416 minecraft:stone_bricks
setblock 450 209 419 minecraft:light[level=12]
setblock 450 209 427 minecraft:light[level=12]
setblock 450 209 435 minecraft:light[level=12]
setblock 450 209 443 minecraft:light[level=12]
setblock 450 209 451 minecraft:light[level=12]
setblock 451 209 458 minecraft:stone_bricks
fill 452 209 458 454 210 458 minecraft:cracked_stone_bricks
setblock 458 209 419 minecraft:light[level=12]
setblock 458 209 427 minecraft:light[level=12]
setblock 458 209 435 minecraft:light[level=12]
setblock 458 209 443 minecraft:light[level=12]
setblock 458 209 451 minecraft:light[level=12]
fill 463 209 458 464 212 458 minecraft:cracked_stone_bricks
setblock 465 209 445 minecraft:stone_bricks
setblock 465 209 446 minecraft:cracked_stone_bricks
setblock 465 209 447 minecraft:stone_bricks
fill 465 209 448 465 209 449 minecraft:cracked_stone_bricks
setblock 465 209 458 minecraft:stone_bricks
fill 423 210 426 423 213 426 minecraft:cracked_stone_bricks
setblock 423 210 427 minecraft:stone_bricks
fill 423 210 428 423 212 428 minecraft:cracked_stone_bricks
setblock 423 210 429 minecraft:stone_bricks
setblock 423 210 439 minecraft:stone_bricks
fill 423 210 440 423 212 443 minecraft:cracked_stone_bricks
setblock 423 210 450 minecraft:stone_bricks
fill 423 210 451 423 212 452 minecraft:cracked_stone_bricks
fill 428 210 458 429 212 458 minecraft:cracked_stone_bricks
fill 437 210 416 438 212 416 minecraft:cracked_stone_bricks
setblock 439 210 416 minecraft:stone_bricks
setblock 440 210 416 minecraft:cracked_stone_bricks
setblock 441 210 416 minecraft:stone_bricks
fill 449 210 416 449 212 416 minecraft:cracked_stone_bricks
setblock 451 210 458 minecraft:cracked_stone_bricks
setblock 457 210 458 minecraft:stone_bricks
fill 458 210 458 458 212 458 minecraft:cracked_stone_bricks
fill 461 210 416 462 212 416 minecraft:cracked_stone_bricks
setblock 463 210 416 minecraft:stone_bricks
fill 464 210 416 464 212 416 minecraft:cracked_stone_bricks
setblock 465 210 416 minecraft:stone_bricks
setblock 465 210 424 minecraft:stone_bricks
setblock 465 210 425 minecraft:cracked_stone_bricks
fill 465 210 427 465 212 427 minecraft:cracked_stone_bricks
setblock 465 210 428 minecraft:stone_bricks
fill 465 210 445 465 212 445 minecraft:cracked_stone_bricks
fill 465 210 446 465 211 446 minecraft:stone_bricks
fill 465 210 447 465 212 448 minecraft:cracked_stone_bricks
setblock 465 210 449 minecraft:stone_bricks
fill 465 210 458 465 212 458 minecraft:cracked_stone_bricks
fill 423 211 418 423 212 418 minecraft:cracked_stone_bricks
setblock 423 211 419 minecraft:stone_bricks
fill 423 211 421 423 212 421 minecraft:cracked_stone_bricks
fill 423 211 427 423 212 427 minecraft:cracked_stone_bricks
fill 423 211 429 423 213 429 minecraft:cracked_stone_bricks
fill 423 211 439 423 212 439 minecraft:cracked_stone_bricks
fill 423 211 450 423 212 450 minecraft:cracked_stone_bricks
setblock 427 211 458 minecraft:stone_bricks
setblock 431 211 458 minecraft:stone_bricks
fill 432 211 458 433 212 458 minecraft:cracked_stone_bricks
setblock 434 211 458 minecraft:stone_bricks
setblock 436 211 416 minecraft:stone_bricks
fill 439 211 416 439 212 416 minecraft:cracked_stone_bricks
setblock 439 211 458 minecraft:stone_bricks
setblock 440 211 416 minecraft:stone_bricks
fill 440 211 458 441 212 458 minecraft:cracked_stone_bricks
fill 441 211 416 441 213 416 minecraft:cracked_stone_bricks
fill 451 211 458 453 211 458 minecraft:stone_bricks
fill 454 211 458 454 212 458 minecraft:cracked_stone_bricks
fill 457 211 458 457 212 458 minecraft:cracked_stone_bricks
fill 463 211 416 463 212 416 minecraft:cracked_stone_bricks
fill 465 211 416 465 212 416 minecraft:cracked_stone_bricks
fill 465 211 421 465 212 421 minecraft:cracked_stone_bricks
setblock 465 211 422 minecraft:stone_bricks
fill 465 211 423 465 212 424 minecraft:cracked_stone_bricks
setblock 465 211 425 minecraft:stone_bricks
fill 465 211 428 465 212 428 minecraft:cracked_stone_bricks
fill 465 211 449 465 212 449 minecraft:cracked_stone_bricks
setblock 465 211 457 minecraft:stone_bricks
setblock 423 212 419 minecraft:cracked_stone_bricks
setblock 423 212 422 minecraft:cracked_stone_bricks
fill 423 212 423 423 212 424 minecraft:glowstone
setblock 423 212 425 minecraft:cracked_stone_bricks
setblock 423 212 434 minecraft:cracked_stone_bricks
fill 423 212 435 423 212 436 minecraft:glowstone
setblock 423 212 437 minecraft:cracked_stone_bricks
setblock 423 212 446 minecraft:cracked_stone_bricks
fill 423 212 447 423 212 448 minecraft:glowstone
setblock 423 212 449 minecraft:cracked_stone_bricks
setblock 423 212 458 minecraft:cracked_stone_bricks
fill 424 212 458 425 212 458 minecraft:glowstone
fill 426 212 458 427 212 458 minecraft:cracked_stone_bricks
setblock 430 212 416 minecraft:cracked_stone_bricks
fill 431 212 416 432 212 416 minecraft:glowstone
setblock 431 212 458 minecraft:cracked_stone_bricks
setblock 433 212 416 minecraft:cracked_stone_bricks
fill 434 212 458 435 212 458 minecraft:cracked_stone_bricks
setblock 436 212 416 minecraft:cracked_stone_bricks
fill 436 212 458 437 212 458 minecraft:glowstone
fill 438 212 458 439 212 458 minecraft:cracked_stone_bricks
setblock 440 212 416 minecraft:cracked_stone_bricks
setblock 442 212 416 minecraft:cracked_stone_bricks
fill 443 212 416 444 212 416 minecraft:glowstone
setblock 445 212 416 minecraft:cracked_stone_bricks
setblock 447 212 458 minecraft:cracked_stone_bricks
fill 448 212 458 449 212 458 minecraft:glowstone
fill 450 212 458 453 212 458 minecraft:cracked_stone_bricks
setblock 454 212 416 minecraft:cracked_stone_bricks
fill 455 212 416 456 212 416 minecraft:glowstone
setblock 457 212 416 minecraft:cracked_stone_bricks
setblock 459 212 458 minecraft:cracked_stone_bricks
fill 460 212 458 461 212 458 minecraft:glowstone
fill 462 212 458 462 213 458 minecraft:cracked_stone_bricks
setblock 465 212 417 minecraft:cracked_stone_bricks
fill 465 212 418 465 212 419 minecraft:glowstone
setblock 465 212 420 minecraft:cracked_stone_bricks
setblock 465 212 422 minecraft:cracked_stone_bricks
setblock 465 212 425 minecraft:cracked_stone_bricks
setblock 465 212 429 minecraft:cracked_stone_bricks
fill 465 212 430 465 212 431 minecraft:glowstone
setblock 465 212 432 minecraft:cracked_stone_bricks
setblock 465 212 441 minecraft:cracked_stone_bricks
fill 465 212 442 465 212 443 minecraft:glowstone
setblock 465 212 444 minecraft:cracked_stone_bricks
setblock 465 212 446 minecraft:cracked_stone_bricks
fill 465 212 453 465 213 453 minecraft:cracked_stone_bricks
fill 465 212 454 465 212 455 minecraft:glowstone
fill 465 212 456 465 212 457 minecraft:cracked_stone_bricks
fill 423 213 416 423 213 419 minecraft:stone_bricks
fill 423 213 421 423 214 423 minecraft:stone_bricks
fill 423 213 424 423 214 424 minecraft:cracked_stone_bricks
fill 423 213 425 423 225 425 minecraft:stone_bricks
fill 423 213 427 423 307 428 minecraft:stone_bricks
fill 423 213 430 423 214 435 minecraft:stone_bricks
setblock 423 213 436 minecraft:cracked_stone_bricks
fill 423 213 437 423 213 458 minecraft:stone_bricks
fill 424 213 416 437 214 416 minecraft:stone_bricks
fill 424 213 458 447 213 458 minecraft:stone_bricks
setblock 438 213 416 minecraft:cracked_stone_bricks
fill 439 213 416 440 307 416 minecraft:stone_bricks
fill 442 213 416 447 225 416 minecraft:stone_bricks
setblock 448 213 416 minecraft:cracked_stone_bricks
setblock 448 213 458 minecraft:cracked_stone_bricks
fill 449 213 416 459 213 416 minecraft:stone_bricks
fill 449 213 458 461 213 458 minecraft:stone_bricks
setblock 460 213 416 minecraft:cracked_stone_bricks
fill 461 213 416 465 213 416 minecraft:stone_bricks
setblock 463 213 458 minecraft:cracked_stone_bricks
fill 464 213 458 465 214 458 minecraft:stone_bricks
fill 465 213 417 465 213 423 minecraft:stone_bricks
setblock 465 213 424 minecraft:cracked_stone_bricks
fill 465 213 425 465 213 438 minecraft:stone_bricks
setblock 465 213 439 minecraft:cracked_stone_bricks
fill 465 213 440 465 214 442 minecraft:stone_bricks
setblock 465 213 443 minecraft:cracked_stone_bricks
fill 465 213 444 465 213 452 minecraft:stone_bricks
fill 465 213 454 465 225 455 minecraft:stone_bricks
fill 465 213 456 465 214 456 minecraft:cracked_stone_bricks
fill 465 213 457 465 307 457 minecraft:stone_bricks
fill 423 214 416 423 307 418 minecraft:stone_bricks
setblock 423 214 419 minecraft:cracked_stone_bricks
fill 423 214 420 423 307 420 minecraft:stone_bricks
fill 423 214 426 423 307 426 minecraft:stone_bricks
fill 423 214 429 423 307 429 minecraft:stone_bricks
fill 423 214 436 423 214 442 minecraft:stone_bricks
setblock 423 214 443 minecraft:cracked_stone_bricks
fill 423 214 444 423 214 446 minecraft:stone_bricks
setblock 423 214 447 minecraft:cracked_stone_bricks
fill 423 214 448 423 214 458 minecraft:stone_bricks
fill 424 214 458 426 214 458 minecraft:stone_bricks
setblock 427 214 458 minecraft:cracked_stone_bricks
fill 428 214 458 432 307 458 minecraft:stone_bricks
setblock 433 214 458 minecraft:cracked_stone_bricks
fill 434 214 458 440 214 458 minecraft:stone_bricks
fill 438 214 416 438 307 416 minecraft:stone_bricks
fill 441 214 416 441 307 416 minecraft:stone_bricks
setblock 441 214 458 minecraft:cracked_stone_bricks
fill 442 214 458 452 225 458 minecraft:stone_bricks
fill 448 214 416 451 307 416 minecraft:stone_bricks
setblock 452 214 416 minecraft:cracked_stone_bricks
fill 453 214 416 463 214 416 minecraft:stone_bricks
setblock 453 214 458 minecraft:cracked_stone_bricks
fill 454 214 458 463 214 458 minecraft:stone_bricks
setblock 464 214 416 minecraft:cracked_stone_bricks
fill 465 214 416 465 225 421 minecraft:stone_bricks
setblock 465 214 422 minecraft:cracked_stone_bricks
fill 465 214 423 465 214 430 minecraft:stone_bricks
fill 465 214 431 465 214 432 minecraft:cracked_stone_bricks
fill 465 214 433 465 307 437 minecraft:stone_bricks
setblock 465 214 438 minecraft:cracked_stone_bricks
fill 465 214 439 465 307 439 minecraft:stone_bricks
fill 465 214 443 465 214 448 minecraft:stone_bricks
setblock 465 214 449 minecraft:cracked_stone_bricks
fill 465 214 450 465 214 453 minecraft:stone_bricks
fill 423 215 419 423 307 419 minecraft:stone_bricks
fill 423 215 421 423 307 421 minecraft:stone_bricks
setblock 423 215 422 minecraft:cracked_stone_bricks
fill 423 215 423 423 225 424 minecraft:stone_bricks
fill 423 215 430 423 307 433 minecraft:stone_bricks
setblock 423 215 434 minecraft:cracked_stone_bricks
fill 423 215 435 423 225 438 minecraft:stone_bricks
fill 423 215 439 423 215 440 minecraft:cracked_stone_bricks
fill 423 215 441 423 307 444 minecraft:stone_bricks
setblock 423 215 445 minecraft:cracked_stone_bricks
fill 423 215 446 423 225 455 minecraft:stone_bricks
setblock 423 215 456 minecraft:cracked_stone_bricks
fill 423 215 457 423 225 458 minecraft:stone_bricks
fill 424 215 416 428 307 416 minecraft:stone_bricks
setblock 424 215 458 minecraft:cracked_stone_bricks
fill 425 215 458 427 225 458 minecraft:stone_bricks
setblock 429 215 416 minecraft:cracked_stone_bricks
fill 430 215 416 437 225 416 minecraft:stone_bricks
fill 433 215 458 437 225 458 minecraft:stone_bricks
setblock 438 215 458 minecraft:cracked_stone_bricks
fill 439 215 458 441 307 458 minecraft:stone_bricks
fill 452 215 416 456 225 416 minecraft:stone_bricks
fill 453 215 458 457 307 458 minecraft:stone_bricks
setblock 457 215 416 minecraft:cracked_stone_bricks
fill 458 215 416 462 307 416 minecraft:stone_bricks
setblock 458 215 458 minecraft:cracked_stone_bricks
fill 459 215 458 463 225 458 minecraft:stone_bricks
setblock 463 215 416 minecraft:cracked_stone_bricks
fill 464 215 416 464 307 416 minecraft:stone_bricks
fill 464 215 458 465 215 458 minecraft:cracked_stone_bricks
fill 465 215 422 465 307 423 minecraft:stone_bricks
setblock 465 215 424 minecraft:cracked_stone_bricks
fill 465 215 425 465 225 432 minecraft:stone_bricks
fill 465 215 438 465 307 438 minecraft:stone_bricks
setblock 465 215 440 minecraft:cracked_stone_bricks
fill 465 215 441 465 225 441 minecraft:stone_bricks
setblock 465 215 442 minecraft:cracked_stone_bricks
fill 465 215 443 465 225 446 minecraft:stone_bricks
fill 465 215 447 465 215 448 minecraft:cracked_stone_bricks
fill 465 215 449 465 307 450 minecraft:stone_bricks
setblock 465 215 451 minecraft:cracked_stone_bricks
fill 465 215 452 465 225 453 minecraft:stone_bricks
fill 465 215 456 465 225 456 minecraft:stone_bricks
fill 423 216 422 423 225 422 minecraft:stone_bricks
fill 423 216 434 423 225 434 minecraft:stone_bricks
fill 423 216 439 423 307 440 minecraft:stone_bricks
fill 423 216 445 423 307 445 minecraft:stone_bricks
fill 423 216 456 423 307 456 minecraft:stone_bricks
fill 424 216 458 424 225 458 minecraft:stone_bricks
fill 429 216 416 429 307 416 minecraft:stone_bricks
fill 438 216 458 438 225 458 minecraft:stone_bricks
fill 457 216 416 457 225 416 minecraft:stone_bricks
fill 458 216 458 458 307 458 minecraft:stone_bricks
fill 463 216 416 463 307 416 minecraft:stone_bricks
fill 464 216 458 465 307 458 minecraft:stone_bricks
fill 465 216 424 465 307 424 minecraft:stone_bricks
fill 465 216 440 465 307 440 minecraft:stone_bricks
fill 465 216 442 465 225 442 minecraft:stone_bricks
fill 465 216 447 465 307 448 minecraft:stone_bricks
fill 465 216 451 465 307 451 minecraft:stone_bricks
setblock 426 217 419 minecraft:light[level=12]
setblock 426 217 427 minecraft:light[level=12]
setblock 426 217 435 minecraft:light[level=12]
setblock 426 217 443 minecraft:light[level=12]
setblock 426 217 451 minecraft:light[level=12]
setblock 434 217 419 minecraft:light[level=12]
setblock 434 217 427 minecraft:light[level=12]
setblock 434 217 435 minecraft:light[level=12]
setblock 434 217 443 minecraft:light[level=12]
setblock 434 217 451 minecraft:light[level=12]
setblock 442 217 419 minecraft:light[level=12]
setblock 442 217 427 minecraft:light[level=12]
setblock 442 217 435 minecraft:light[level=12]
setblock 442 217 443 minecraft:light[level=12]
setblock 442 217 451 minecraft:light[level=12]
setblock 450 217 419 minecraft:light[level=12]
setblock 450 217 427 minecraft:light[level=12]
setblock 450 217 435 minecraft:light[level=12]
setblock 450 217 443 minecraft:light[level=12]
setblock 450 217 451 minecraft:light[level=12]
setblock 458 217 419 minecraft:light[level=12]
setblock 458 217 427 minecraft:light[level=12]
setblock 458 217 435 minecraft:light[level=12]
setblock 458 217 443 minecraft:light[level=12]
setblock 458 217 451 minecraft:light[level=12]
fill 425 220 426 425 225 428 minecraft:iron_block
fill 425 220 438 425 225 440 minecraft:iron_block
fill 425 220 450 425 225 452 minecraft:iron_block
fill 431 220 456 433 225 456 minecraft:iron_block
fill 435 220 418 437 225 418 minecraft:iron_block
fill 443 220 456 445 225 456 minecraft:iron_block
fill 447 220 418 449 225 418 minecraft:iron_block
fill 455 220 456 457 225 456 minecraft:iron_block
fill 459 220 418 461 225 418 minecraft:iron_block
fill 463 220 426 463 225 428 minecraft:iron_block
fill 463 220 438 463 225 440 minecraft:iron_block
fill 463 220 450 463 225 452 minecraft:iron_block
fill 424 221 433 426 222 433 minecraft:iron_bars
fill 424 225 420 424 225 425 minecraft:cobblestone
fill 424 225 432 424 225 437 minecraft:cobblestone
fill 424 225 444 424 225 449 minecraft:cobblestone
fill 424 225 456 424 225 457 minecraft:cobblestone
fill 425 225 457 428 225 457 minecraft:cobblestone
setblock 426 225 419 minecraft:light[level=12]
setblock 426 225 427 minecraft:light[level=12]
setblock 426 225 435 minecraft:light[level=12]
setblock 426 225 443 minecraft:light[level=12]
setblock 426 225 451 minecraft:light[level=12]
fill 428 225 417 433 225 417 minecraft:cobblestone
setblock 434 225 419 minecraft:light[level=12]
setblock 434 225 427 minecraft:light[level=12]
setblock 434 225 435 minecraft:light[level=12]
setblock 434 225 443 minecraft:light[level=12]
setblock 434 225 451 minecraft:light[level=12]
fill 435 225 457 440 225 457 minecraft:cobblestone
fill 439 225 422 439 228 422 minecraft:iron_bars
fill 440 225 417 445 225 417 minecraft:cobblestone
setblock 442 225 419 minecraft:light[level=12]
setblock 442 225 427 minecraft:light[level=12]
setblock 442 225 435 minecraft:light[level=12]
setblock 442 225 443 minecraft:light[level=12]
setblock 442 225 451 minecraft:light[level=12]
fill 447 225 457 452 225 457 minecraft:cobblestone
setblock 450 225 419 minecraft:light[level=12]
setblock 450 225 427 minecraft:light[level=12]
setblock 450 225 435 minecraft:light[level=12]
setblock 450 225 443 minecraft:light[level=12]
setblock 450 225 451 minecraft:light[level=12]
fill 452 225 417 457 225 417 minecraft:cobblestone
setblock 458 225 419 minecraft:light[level=12]
setblock 458 225 427 minecraft:light[level=12]
setblock 458 225 435 minecraft:light[level=12]
setblock 458 225 443 minecraft:light[level=12]
setblock 458 225 451 minecraft:light[level=12]
fill 459 225 457 464 225 457 minecraft:cobblestone
fill 464 225 417 464 225 422 minecraft:cobblestone
fill 464 225 429 464 225 434 minecraft:cobblestone
fill 464 225 441 464 225 446 minecraft:cobblestone
fill 464 225 453 464 225 456 minecraft:cobblestone
fill 423 226 422 423 228 425 minecraft:glowstone
fill 423 226 434 423 228 437 minecraft:glowstone
fill 423 226 438 423 307 438 minecraft:stone_bricks
fill 423 226 446 423 228 449 minecraft:glowstone
fill 423 226 450 423 307 455 minecraft:stone_bricks
fill 423 226 457 423 307 457 minecraft:stone_bricks
fill 423 226 458 426 228 458 minecraft:glowstone
fill 427 226 458 427 307 458 minecraft:stone_bricks
fill 430 226 416 433 228 416 minecraft:glowstone
fill 433 226 458 434 307 458 minecraft:stone_bricks
fill 434 226 416 437 307 416 minecraft:stone_bricks
fill 435 226 458 438 228 458 minecraft:glowstone
fill 442 226 416 445 228 416 minecraft:glowstone
fill 442 226 458 446 307 458 minecraft:stone_bricks
fill 446 226 416 447 307 416 minecraft:stone_bricks
fill 447 226 458 450 228 458 minecraft:glowstone
fill 451 226 458 452 307 458 minecraft:stone_bricks
fill 452 226 416 453 307 416 minecraft:stone_bricks
fill 454 226 416 457 228 416 minecraft:glowstone
fill 459 226 458 462 228 458 minecraft:glowstone
fill 463 226 458 463 307 458 minecraft:stone_bricks
fill 465 226 416 465 307 416 minecraft:stone_bricks
fill 465 226 417 465 228 420 minecraft:glowstone
fill 465 226 421 465 307 421 minecraft:stone_bricks
fill 465 226 425 465 307 428 minecraft:stone_bricks
fill 465 226 429 465 228 432 minecraft:glowstone
fill 465 226 441 465 228 444 minecraft:glowstone
fill 465 226 445 465 307 446 minecraft:stone_bricks
fill 465 226 452 465 307 452 minecraft:stone_bricks
fill 465 226 453 465 228 456 minecraft:glowstone
fill 423 229 422 423 245 425 minecraft:stone_bricks
fill 423 229 434 423 245 437 minecraft:stone_bricks
fill 423 229 446 423 245 449 minecraft:stone_bricks
fill 423 229 458 426 245 458 minecraft:stone_bricks
fill 430 229 416 433 245 416 minecraft:stone_bricks
fill 435 229 458 438 245 458 minecraft:stone_bricks
fill 442 229 416 445 245 416 minecraft:stone_bricks
fill 447 229 458 450 245 458 minecraft:stone_bricks
fill 454 229 416 457 245 416 minecraft:stone_bricks
fill 459 229 458 462 245 458 minecraft:stone_bricks
fill 465 229 417 465 245 420 minecraft:stone_bricks
fill 465 229 429 465 245 432 minecraft:stone_bricks
fill 465 229 441 465 245 444 minecraft:stone_bricks
fill 465 229 453 465 245 456 minecraft:stone_bricks
setblock 426 233 419 minecraft:light[level=12]
setblock 426 233 427 minecraft:light[level=12]
setblock 426 233 435 minecraft:light[level=12]
setblock 426 233 443 minecraft:light[level=12]
setblock 426 233 451 minecraft:light[level=12]
setblock 434 233 419 minecraft:light[level=12]
setblock 434 233 427 minecraft:light[level=12]
setblock 434 233 435 minecraft:light[level=12]
setblock 434 233 443 minecraft:light[level=12]
setblock 434 233 451 minecraft:light[level=12]
setblock 442 233 419 minecraft:light[level=12]
setblock 442 233 427 minecraft:light[level=12]
setblock 442 233 435 minecraft:light[level=12]
setblock 442 233 443 minecraft:light[level=12]
setblock 442 233 451 minecraft:light[level=12]
setblock 450 233 419 minecraft:light[level=12]
setblock 450 233 427 minecraft:light[level=12]
setblock 450 233 435 minecraft:light[level=12]
setblock 450 233 443 minecraft:light[level=12]
setblock 450 233 451 minecraft:light[level=12]
setblock 458 233 419 minecraft:light[level=12]
setblock 458 233 427 minecraft:light[level=12]
setblock 458 233 435 minecraft:light[level=12]
setblock 458 233 443 minecraft:light[level=12]
setblock 458 233 451 minecraft:light[level=12]
fill 424 234 417 424 235 427 minecraft:black_concrete
fill 424 234 428 464 235 428 minecraft:stone_bricks
fill 424 234 429 424 235 439 minecraft:black_concrete
fill 424 234 440 440 234 440 minecraft:stone_bricks
fill 424 234 441 424 235 451 minecraft:black_concrete
fill 424 234 452 464 235 452 minecraft:stone_bricks
fill 424 234 453 424 235 457 minecraft:black_concrete
fill 425 234 417 425 235 427 minecraft:iron_block
fill 425 234 429 425 235 439 minecraft:iron_block
fill 425 234 441 425 235 451 minecraft:iron_block
fill 425 234 453 425 235 457 minecraft:iron_block
fill 426 234 417 426 235 427 minecraft:black_concrete
fill 426 234 429 426 235 439 minecraft:black_concrete
fill 426 234 441 426 235 451 minecraft:black_concrete
fill 426 234 453 426 235 457 minecraft:black_concrete
fill 427 234 417 427 235 427 minecraft:iron_block
fill 427 234 429 427 235 439 minecraft:iron_block
fill 427 234 441 427 235 451 minecraft:iron_block
fill 427 234 453 427 235 457 minecraft:iron_block
fill 428 234 417 428 235 427 minecraft:black_concrete
fill 428 234 429 428 235 439 minecraft:black_concrete
fill 428 234 441 428 235 451 minecraft:black_concrete
fill 428 234 453 428 235 457 minecraft:black_concrete
fill 429 234 417 429 235 427 minecraft:iron_block
fill 429 234 429 429 235 439 minecraft:iron_block
fill 429 234 441 429 235 451 minecraft:iron_block
fill 429 234 453 429 235 457 minecraft:iron_block
fill 430 234 417 430 235 427 minecraft:black_concrete
fill 430 234 429 430 235 439 minecraft:black_concrete
fill 430 234 441 430 235 451 minecraft:black_concrete
fill 430 234 453 430 235 457 minecraft:black_concrete
fill 431 234 417 431 235 427 minecraft:iron_block
fill 431 234 429 431 235 439 minecraft:iron_block
fill 431 234 441 431 235 451 minecraft:iron_block
fill 431 234 453 431 235 457 minecraft:iron_block
fill 432 234 417 432 235 427 minecraft:black_concrete
fill 432 234 429 432 235 439 minecraft:black_concrete
fill 432 234 441 432 235 451 minecraft:black_concrete
fill 432 234 453 432 235 457 minecraft:black_concrete
fill 433 234 417 433 235 427 minecraft:iron_block
fill 433 234 429 433 235 439 minecraft:iron_block
fill 433 234 441 433 235 451 minecraft:iron_block
fill 433 234 453 433 235 457 minecraft:iron_block
fill 434 234 417 434 235 427 minecraft:black_concrete
fill 434 234 429 434 235 439 minecraft:black_concrete
fill 434 234 441 434 235 451 minecraft:black_concrete
fill 434 234 453 434 235 457 minecraft:black_concrete
fill 435 234 417 435 235 427 minecraft:iron_block
fill 435 234 429 435 235 439 minecraft:iron_block
fill 435 234 441 435 235 451 minecraft:iron_block
fill 435 234 453 435 235 457 minecraft:iron_block
fill 436 234 417 436 235 427 minecraft:black_concrete
fill 436 234 429 436 235 439 minecraft:black_concrete
fill 436 234 441 436 235 451 minecraft:black_concrete
fill 436 234 453 436 235 457 minecraft:black_concrete
fill 437 234 417 437 235 427 minecraft:iron_block
fill 437 234 429 437 235 439 minecraft:iron_block
fill 437 234 441 437 235 451 minecraft:iron_block
fill 437 234 453 437 235 457 minecraft:iron_block
fill 438 234 417 438 235 427 minecraft:black_concrete
fill 438 234 429 438 235 439 minecraft:black_concrete
fill 438 234 441 438 235 451 minecraft:black_concrete
fill 438 234 453 438 235 457 minecraft:black_concrete
fill 439 234 417 439 235 427 minecraft:iron_block
fill 439 234 429 439 234 439 minecraft:iron_block
fill 439 234 441 439 235 451 minecraft:iron_block
fill 439 234 453 439 235 457 minecraft:iron_block
fill 440 234 417 440 235 427 minecraft:black_concrete
fill 440 234 429 440 234 438 minecraft:black_concrete
fill 440 234 441 440 234 451 minecraft:black_concrete
fill 440 234 453 440 235 457 minecraft:black_concrete
fill 441 234 417 441 235 427 minecraft:iron_block
fill 441 234 429 441 234 437 minecraft:iron_block
fill 441 234 441 441 234 451 minecraft:iron_block
fill 441 234 453 441 235 457 minecraft:iron_block
fill 442 234 417 442 235 427 minecraft:black_concrete
fill 442 234 429 442 234 436 minecraft:black_concrete
fill 442 234 442 442 234 451 minecraft:black_concrete
fill 442 234 453 442 235 457 minecraft:black_concrete
fill 443 234 417 443 235 427 minecraft:iron_block
fill 443 234 429 443 234 437 minecraft:iron_block
fill 443 234 441 443 234 451 minecraft:iron_block
fill 443 234 453 443 235 457 minecraft:iron_block
fill 444 234 417 444 235 427 minecraft:black_concrete
fill 444 234 429 444 234 438 minecraft:black_concrete
fill 444 234 440 464 234 440 minecraft:stone_bricks
fill 444 234 441 444 234 451 minecraft:black_concrete
fill 444 234 453 444 235 457 minecraft:black_concrete
fill 445 234 417 445 235 427 minecraft:iron_block
fill 445 234 429 445 234 439 minecraft:iron_block
fill 445 234 441 445 235 451 minecraft:iron_block
fill 445 234 453 445 235 457 minecraft:iron_block
fill 446 234 417 446 235 427 minecraft:black_concrete
fill 446 234 429 446 235 439 minecraft:black_concrete
fill 446 234 441 446 235 451 minecraft:black_concrete
fill 446 234 453 446 235 457 minecraft:black_concrete
fill 447 234 417 447 235 427 minecraft:iron_block
fill 447 234 429 447 235 439 minecraft:iron_block
fill 447 234 441 447 235 451 minecraft:iron_block
fill 447 234 453 447 235 457 minecraft:iron_block
fill 448 234 417 448 235 427 minecraft:black_concrete
fill 448 234 429 448 235 439 minecraft:black_concrete
fill 448 234 441 448 235 451 minecraft:black_concrete
fill 448 234 453 448 235 457 minecraft:black_concrete
fill 449 234 417 449 235 427 minecraft:iron_block
fill 449 234 429 449 235 439 minecraft:iron_block
fill 449 234 441 449 235 451 minecraft:iron_block
fill 449 234 453 449 235 457 minecraft:iron_block
fill 450 234 417 450 235 427 minecraft:black_concrete
fill 450 234 429 450 235 439 minecraft:black_concrete
fill 450 234 441 450 235 451 minecraft:black_concrete
fill 450 234 453 450 235 457 minecraft:black_concrete
fill 451 234 417 451 235 427 minecraft:iron_block
fill 451 234 429 451 235 439 minecraft:iron_block
fill 451 234 441 451 235 451 minecraft:iron_block
fill 451 234 453 451 235 457 minecraft:iron_block
fill 452 234 417 452 235 427 minecraft:black_concrete
fill 452 234 429 452 235 439 minecraft:black_concrete
fill 452 234 441 452 235 451 minecraft:black_concrete
fill 452 234 453 452 235 457 minecraft:black_concrete
fill 453 234 417 453 235 427 minecraft:iron_block
fill 453 234 429 453 235 439 minecraft:iron_block
fill 453 234 441 453 235 451 minecraft:iron_block
fill 453 234 453 453 235 457 minecraft:iron_block
fill 454 234 417 454 235 427 minecraft:black_concrete
fill 454 234 429 454 235 439 minecraft:black_concrete
fill 454 234 441 454 235 451 minecraft:black_concrete
fill 454 234 453 454 235 457 minecraft:black_concrete
fill 455 234 417 455 235 427 minecraft:iron_block
fill 455 234 429 455 235 439 minecraft:iron_block
fill 455 234 441 455 235 451 minecraft:iron_block
fill 455 234 453 455 235 457 minecraft:iron_block
fill 456 234 417 456 235 427 minecraft:black_concrete
fill 456 234 429 456 235 439 minecraft:black_concrete
fill 456 234 441 456 235 451 minecraft:black_concrete
fill 456 234 453 456 235 457 minecraft:black_concrete
fill 457 234 417 457 235 427 minecraft:iron_block
fill 457 234 429 457 235 439 minecraft:iron_block
fill 457 234 441 457 235 451 minecraft:iron_block
fill 457 234 453 457 235 457 minecraft:iron_block
fill 458 234 417 458 235 427 minecraft:black_concrete
fill 458 234 429 458 235 439 minecraft:black_concrete
fill 458 234 441 458 235 451 minecraft:black_concrete
fill 458 234 453 458 235 457 minecraft:black_concrete
fill 459 234 417 459 235 427 minecraft:iron_block
fill 459 234 429 459 235 439 minecraft:iron_block
fill 459 234 441 459 235 451 minecraft:iron_block
fill 459 234 453 459 235 457 minecraft:iron_block
fill 460 234 417 460 235 427 minecraft:black_concrete
fill 460 234 429 460 235 439 minecraft:black_concrete
fill 460 234 441 460 235 451 minecraft:black_concrete
fill 460 234 453 460 235 457 minecraft:black_concrete
fill 461 234 417 461 235 427 minecraft:iron_block
fill 461 234 429 461 235 439 minecraft:iron_block
fill 461 234 441 461 235 451 minecraft:iron_block
fill 461 234 453 461 235 457 minecraft:iron_block
fill 462 234 417 462 235 427 minecraft:black_concrete
fill 462 234 429 462 235 439 minecraft:black_concrete
fill 462 234 441 462 235 451 minecraft:black_concrete
fill 462 234 453 462 235 457 minecraft:black_concrete
fill 463 234 417 463 235 427 minecraft:iron_block
fill 463 234 429 463 235 439 minecraft:iron_block
fill 463 234 441 463 235 451 minecraft:iron_block
fill 463 234 453 463 235 457 minecraft:iron_block
fill 464 234 417 464 235 427 minecraft:black_concrete
fill 464 234 429 464 235 439 minecraft:black_concrete
fill 464 234 441 464 235 451 minecraft:black_concrete
fill 464 234 453 464 235 457 minecraft:black_concrete
fill 424 235 440 438 235 440 minecraft:stone_bricks
fill 439 235 429 439 235 437 minecraft:iron_block
fill 439 235 438 439 235 440 minecraft:glowstone
fill 440 235 429 440 235 436 minecraft:black_concrete
fill 440 235 437 440 235 438 minecraft:glowstone
fill 440 235 440 440 235 441 minecraft:glowstone
fill 440 235 442 440 235 451 minecraft:black_concrete
fill 441 235 429 441 235 435 minecraft:iron_block
fill 441 235 436 441 235 437 minecraft:glowstone
fill 441 235 441 441 235 442 minecraft:glowstone
fill 441 235 443 441 235 451 minecraft:iron_block
fill 442 235 429 442 235 435 minecraft:black_concrete
fill 442 235 436 443 235 436 minecraft:glowstone
fill 442 235 442 443 235 442 minecraft:glowstone
fill 442 235 443 442 235 451 minecraft:black_concrete
fill 443 235 429 443 235 435 minecraft:iron_block
fill 443 235 437 444 235 437 minecraft:glowstone
fill 443 235 441 444 235 441 minecraft:glowstone
fill 443 235 443 443 235 451 minecraft:iron_block
fill 444 235 429 444 235 436 minecraft:black_concrete
fill 444 235 438 445 235 438 minecraft:glowstone
fill 444 235 440 445 235 440 minecraft:glowstone
fill 444 235 442 444 235 451 minecraft:black_concrete
fill 445 235 429 445 235 437 minecraft:iron_block
setblock 445 235 439 minecraft:glowstone
fill 446 235 440 464 235 440 minecraft:stone_bricks
fill 424 239 417 426 273 417 minecraft:iron_block
fill 424 239 427 424 273 429 minecraft:iron_block
fill 424 239 439 424 273 441 minecraft:iron_block
fill 424 239 451 424 273 453 minecraft:iron_block
fill 430 239 457 432 273 457 minecraft:iron_block
fill 436 239 417 438 273 417 minecraft:iron_block
fill 439 239 422 439 244 422 minecraft:iron_bars
fill 442 239 457 444 273 457 minecraft:iron_block
fill 448 239 417 450 273 417 minecraft:iron_block
fill 454 239 457 462 240 457 minecraft:iron_block
fill 456 239 447 462 240 456 minecraft:iron_block
fill 460 239 417 462 273 417 minecraft:iron_block
fill 460 239 437 464 244 446 minecraft:iron_block
fill 463 239 447 464 262 447 minecraft:iron_block
fill 464 239 425 464 273 427 minecraft:iron_block
fill 464 239 449 464 273 451 minecraft:iron_block
fill 425 240 426 425 245 428 minecraft:iron_block
fill 425 240 438 425 245 440 minecraft:iron_block
fill 425 240 450 425 245 452 minecraft:iron_block
fill 431 240 456 433 245 456 minecraft:iron_block
fill 435 240 418 437 245 418 minecraft:iron_block
fill 443 240 456 445 245 456 minecraft:iron_block
fill 447 240 418 449 245 418 minecraft:iron_block
fill 455 240 456 455 245 456 minecraft:iron_block
fill 459 240 418 461 245 418 minecraft:iron_block
fill 463 240 426 463 245 428 minecraft:iron_block
fill 463 240 450 463 245 452 minecraft:iron_block
setblock 426 241 419 minecraft:light[level=12]
setblock 426 241 427 minecraft:light[level=12]
setblock 426 241 435 minecraft:light[level=12]
setblock 426 241 443 minecraft:light[level=12]
setblock 426 241 451 minecraft:light[level=12]
setblock 434 241 419 minecraft:light[level=12]
setblock 434 241 427 minecraft:light[level=12]
setblock 434 241 435 minecraft:light[level=12]
setblock 434 241 443 minecraft:light[level=12]
setblock 434 241 451 minecraft:light[level=12]
setblock 442 241 419 minecraft:light[level=12]
setblock 442 241 427 minecraft:light[level=12]
setblock 442 241 435 minecraft:light[level=12]
setblock 442 241 443 minecraft:light[level=12]
setblock 442 241 451 minecraft:light[level=12]
setblock 450 241 419 minecraft:light[level=12]
setblock 450 241 427 minecraft:light[level=12]
setblock 450 241 435 minecraft:light[level=12]
setblock 450 241 443 minecraft:light[level=12]
setblock 450 241 451 minecraft:light[level=12]
fill 454 241 457 455 273 457 minecraft:iron_block
setblock 456 241 447 minecraft:glowstone
fill 456 241 448 456 262 448 minecraft:iron_block
setblock 456 241 449 minecraft:glowstone
fill 456 241 450 456 262 450 minecraft:iron_block
setblock 456 241 451 minecraft:glowstone
fill 456 241 452 456 262 452 minecraft:iron_block
setblock 456 241 453 minecraft:glowstone
fill 456 241 454 456 262 454 minecraft:iron_block
setblock 456 241 455 minecraft:glowstone
fill 456 241 456 456 265 456 minecraft:iron_block
setblock 456 241 457 minecraft:glowstone
fill 457 241 447 457 262 447 minecraft:iron_block
setblock 457 241 448 minecraft:glowstone
fill 457 241 449 457 262 449 minecraft:iron_block
setblock 457 241 450 minecraft:glowstone
fill 457 241 451 457 262 451 minecraft:iron_block
setblock 457 241 452 minecraft:glowstone
fill 457 241 453 457 262 453 minecraft:iron_block
setblock 457 241 454 minecraft:glowstone
fill 457 241 455 457 262 455 minecraft:iron_block
setblock 457 241 456 minecraft:glowstone
fill 457 241 457 457 262 457 minecraft:iron_block
setblock 458 241 419 minecraft:light[level=12]
setblock 458 241 427 minecraft:light[level=12]
setblock 458 241 435 minecraft:light[level=12]
setblock 458 241 443 minecraft:light[level=12]
setblock 458 241 447 minecraft:glowstone
fill 458 241 448 458 262 448 minecraft:iron_block
setblock 458 241 449 minecraft:glowstone
fill 458 241 450 458 262 450 minecraft:iron_block
setblock 458 241 451 minecraft:glowstone
fill 458 241 452 458 262 452 minecraft:iron_block
setblock 458 241 453 minecraft:glowstone
fill 458 241 454 458 262 454 minecraft:iron_block
setblock 458 241 455 minecraft:glowstone
fill 458 241 456 458 262 456 minecraft:iron_block
setblock 458 241 457 minecraft:glowstone
fill 459 241 447 459 262 447 minecraft:iron_block
setblock 459 241 448 minecraft:glowstone
fill 459 241 449 459 262 449 minecraft:iron_block
setblock 459 241 450 minecraft:glowstone
fill 459 241 451 459 262 451 minecraft:iron_block
setblock 459 241 452 minecraft:glowstone
fill 459 241 453 459 262 453 minecraft:iron_block
setblock 459 241 454 minecraft:glowstone
fill 459 241 455 459 262 455 minecraft:iron_block
setblock 459 241 456 minecraft:glowstone
fill 459 241 457 459 244 457 minecraft:iron_block
setblock 460 241 447 minecraft:glowstone
fill 460 241 448 460 262 448 minecraft:iron_block
setblock 460 241 449 minecraft:glowstone
fill 460 241 450 460 262 450 minecraft:iron_block
setblock 460 241 451 minecraft:glowstone
fill 460 241 452 460 262 452 minecraft:iron_block
setblock 460 241 453 minecraft:glowstone
fill 460 241 454 460 262 454 minecraft:iron_block
setblock 460 241 455 minecraft:glowstone
fill 460 241 456 460 262 456 minecraft:iron_block
setblock 460 241 457 minecraft:glowstone
fill 461 241 447 461 262 447 minecraft:iron_block
setblock 461 241 448 minecraft:glowstone
fill 461 241 449 461 262 449 minecraft:iron_block
setblock 461 241 450 minecraft:glowstone
fill 461 241 451 461 262 451 minecraft:iron_block
setblock 461 241 452 minecraft:glowstone
fill 461 241 453 461 262 453 minecraft:iron_block
setblock 461 241 454 minecraft:glowstone
fill 461 241 455 461 262 455 minecraft:iron_block
setblock 461 241 456 minecraft:glowstone
fill 461 241 457 461 244 457 minecraft:iron_block
setblock 462 241 447 minecraft:glowstone
fill 462 241 448 462 262 448 minecraft:iron_block
setblock 462 241 449 minecraft:glowstone
fill 462 241 450 462 262 450 minecraft:iron_block
setblock 462 241 451 minecraft:glowstone
fill 462 241 452 462 262 452 minecraft:iron_block
setblock 462 241 453 minecraft:glowstone
fill 462 241 454 462 262 454 minecraft:iron_block
setblock 462 241 455 minecraft:glowstone
fill 462 241 456 462 262 456 minecraft:iron_block
setblock 462 241 457 minecraft:glowstone
fill 456 242 447 456 243 447 minecraft:iron_block
fill 456 242 449 456 243 449 minecraft:iron_block
fill 456 242 451 456 243 451 minecraft:iron_block
fill 456 242 453 456 243 453 minecraft:iron_block
fill 456 242 455 456 243 455 minecraft:iron_block
fill 456 242 457 456 243 457 minecraft:iron_block
fill 457 242 448 457 243 448 minecraft:iron_block
fill 457 242 450 457 243 450 minecraft:iron_block
fill 457 242 452 457 243 452 minecraft:iron_block
fill 457 242 454 457 243 454 minecraft:iron_block
fill 457 242 456 457 243 456 minecraft:iron_block
fill 458 242 447 458 243 447 minecraft:iron_block
fill 458 242 449 458 243 449 minecraft:iron_block
fill 458 242 451 458 243 451 minecraft:iron_block
fill 458 242 453 458 243 453 minecraft:iron_block
fill 458 242 455 458 243 455 minecraft:iron_block
fill 458 242 457 458 243 457 minecraft:iron_block
fill 459 242 448 459 243 448 minecraft:iron_block
fill 459 242 450 459 243 450 minecraft:iron_block
fill 459 242 452 459 243 452 minecraft:iron_block
fill 459 242 454 459 243 454 minecraft:iron_block
fill 459 242 456 459 243 456 minecraft:iron_block
fill 460 242 447 460 243 447 minecraft:iron_block
fill 460 242 449 460 243 449 minecraft:iron_block
fill 460 242 451 460 243 451 minecraft:iron_block
fill 460 242 453 460 243 453 minecraft:iron_block
fill 460 242 455 460 243 455 minecraft:iron_block
fill 460 242 457 460 243 457 minecraft:iron_block
fill 461 242 448 461 243 448 minecraft:iron_block
fill 461 242 450 461 243 450 minecraft:iron_block
fill 461 242 452 461 243 452 minecraft:iron_block
fill 461 242 454 461 243 454 minecraft:iron_block
fill 461 242 456 461 243 456 minecraft:iron_block
fill 462 242 447 462 243 447 minecraft:iron_block
fill 462 242 449 462 243 449 minecraft:iron_block
fill 462 242 451 462 243 451 minecraft:iron_block
fill 462 242 453 462 243 453 minecraft:iron_block
fill 462 242 455 462 243 455 minecraft:iron_block
fill 462 242 457 462 243 457 minecraft:iron_block
setblock 456 244 447 minecraft:glowstone
setblock 456 244 449 minecraft:glowstone
setblock 456 244 451 minecraft:glowstone
setblock 456 244 453 minecraft:glowstone
setblock 456 244 455 minecraft:glowstone
setblock 456 244 457 minecraft:glowstone
setblock 457 244 448 minecraft:glowstone
setblock 457 244 450 minecraft:glowstone
setblock 457 244 452 minecraft:glowstone
setblock 457 244 454 minecraft:glowstone
setblock 457 244 456 minecraft:glowstone
setblock 458 244 447 minecraft:glowstone
setblock 458 244 449 minecraft:glowstone
setblock 458 244 451 minecraft:glowstone
setblock 458 244 453 minecraft:glowstone
setblock 458 244 455 minecraft:glowstone
setblock 458 244 457 minecraft:glowstone
fill 459 244 424 459 254 424 minecraft:iron_bars
setblock 459 244 448 minecraft:glowstone
setblock 459 244 450 minecraft:glowstone
setblock 459 244 452 minecraft:glowstone
setblock 459 244 454 minecraft:glowstone
setblock 459 244 456 minecraft:glowstone
setblock 460 244 447 minecraft:glowstone
setblock 460 244 449 minecraft:glowstone
setblock 460 244 451 minecraft:glowstone
setblock 460 244 453 minecraft:glowstone
setblock 460 244 455 minecraft:glowstone
setblock 460 244 457 minecraft:glowstone
setblock 461 244 448 minecraft:glowstone
setblock 461 244 450 minecraft:glowstone
setblock 461 244 452 minecraft:glowstone
setblock 461 244 454 minecraft:glowstone
setblock 461 244 456 minecraft:glowstone
setblock 462 244 447 minecraft:glowstone
setblock 462 244 449 minecraft:glowstone
setblock 462 244 451 minecraft:glowstone
setblock 462 244 453 minecraft:glowstone
setblock 462 244 455 minecraft:glowstone
setblock 462 244 457 minecraft:glowstone
fill 424 245 420 424 245 425 minecraft:cobblestone
fill 424 245 432 424 245 437 minecraft:cobblestone
fill 424 245 444 424 245 449 minecraft:cobblestone
fill 424 245 456 424 245 457 minecraft:cobblestone
fill 425 245 457 428 245 457 minecraft:cobblestone
fill 428 245 417 433 245 417 minecraft:cobblestone
fill 435 245 457 440 245 457 minecraft:cobblestone
fill 440 245 417 445 245 417 minecraft:cobblestone
fill 447 245 457 452 245 457 minecraft:cobblestone
fill 452 245 417 457 245 417 minecraft:cobblestone
fill 456 245 447 456 246 447 minecraft:iron_block
fill 456 245 449 456 246 449 minecraft:iron_block
fill 456 245 451 456 246 451 minecraft:iron_block
fill 456 245 453 456 246 453 minecraft:iron_block
fill 456 245 455 456 246 455 minecraft:iron_block
fill 456 245 457 456 246 457 minecraft:iron_block
fill 457 245 448 457 246 448 minecraft:iron_block
fill 457 245 450 457 246 450 minecraft:iron_block
fill 457 245 452 457 246 452 minecraft:iron_block
fill 457 245 454 457 246 454 minecraft:iron_block
fill 457 245 456 457 246 456 minecraft:iron_block
fill 458 245 447 458 246 447 minecraft:iron_block
fill 458 245 449 458 246 449 minecraft:iron_block
fill 458 245 451 458 246 451 minecraft:iron_block
fill 458 245 453 458 246 453 minecraft:iron_block
fill 458 245 455 458 246 455 minecraft:iron_block
fill 458 245 457 458 246 457 minecraft:iron_block
fill 459 245 448 459 246 448 minecraft:iron_block
fill 459 245 450 459 246 450 minecraft:iron_block
fill 459 245 452 459 246 452 minecraft:iron_block
fill 459 245 454 459 246 454 minecraft:iron_block
fill 459 245 456 459 246 456 minecraft:iron_block
fill 459 245 457 464 245 457 minecraft:cobblestone
fill 460 245 437 460 246 447 minecraft:iron_block
fill 460 245 449 460 246 449 minecraft:iron_block
fill 460 245 451 460 246 451 minecraft:iron_block
fill 460 245 453 460 246 453 minecraft:iron_block
fill 460 245 455 460 246 455 minecraft:iron_block
fill 461 245 437 463 262 446 minecraft:iron_block
fill 461 245 448 461 246 448 minecraft:iron_block
fill 461 245 450 461 246 450 minecraft:iron_block
fill 461 245 452 461 246 452 minecraft:iron_block
fill 461 245 454 461 246 454 minecraft:iron_block
fill 461 245 456 461 246 456 minecraft:iron_block
fill 462 245 447 462 246 447 minecraft:iron_block
fill 462 245 449 462 246 449 minecraft:iron_block
fill 462 245 451 462 246 451 minecraft:iron_block
fill 462 245 453 462 246 453 minecraft:iron_block
fill 462 245 455 462 246 455 minecraft:iron_block
fill 464 245 417 464 245 422 minecraft:cobblestone
fill 464 245 429 464 245 434 minecraft:cobblestone
fill 464 245 437 464 262 440 minecraft:iron_block
fill 464 245 441 464 245 446 minecraft:cobblestone
fill 464 245 453 464 245 456 minecraft:cobblestone
fill 423 246 422 423 251 425 minecraft:glowstone
fill 423 246 434 423 251 437 minecraft:glowstone
fill 423 246 446 423 251 449 minecraft:glowstone
fill 423 246 458 426 251 458 minecraft:glowstone
fill 430 246 416 433 251 416 minecraft:glowstone
fill 435 246 458 438 251 458 minecraft:glowstone
fill 442 246 416 445 251 416 minecraft:glowstone
fill 447 246 458 450 251 458 minecraft:glowstone
fill 454 246 416 457 251 416 minecraft:glowstone
fill 459 246 457 462 246 457 minecraft:iron_block
fill 459 246 458 462 251 458 minecraft:glowstone
fill 464 246 441 464 262 446 minecraft:iron_block
fill 465 246 417 465 251 420 minecraft:glowstone
fill 465 246 429 465 251 432 minecraft:glowstone
fill 465 246 441 465 251 444 minecraft:glowstone
fill 465 246 453 465 251 456 minecraft:glowstone
setblock 456 247 447 minecraft:glowstone
setblock 456 247 449 minecraft:glowstone
setblock 456 247 451 minecraft:glowstone
setblock 456 247 453 minecraft:glowstone
setblock 456 247 455 minecraft:glowstone
setblock 456 247 457 minecraft:glowstone
setblock 457 247 448 minecraft:glowstone
setblock 457 247 450 minecraft:glowstone
setblock 457 247 452 minecraft:glowstone
setblock 457 247 454 minecraft:glowstone
setblock 457 247 456 minecraft:glowstone
setblock 458 247 447 minecraft:glowstone
setblock 458 247 449 minecraft:glowstone
setblock 458 247 451 minecraft:glowstone
setblock 458 247 453 minecraft:glowstone
schedule function dropper:buildpart/105_2 1t
