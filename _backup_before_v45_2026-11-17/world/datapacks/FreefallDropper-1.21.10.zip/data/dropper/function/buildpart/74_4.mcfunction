fill 127 161 323 130 161 323 minecraft:stone
setblock 127 161 362 minecraft:stripped_spruce_log
fill 127 161 363 130 161 363 minecraft:stone
setblock 128 161 361 minecraft:stripped_spruce_log
fill 128 161 362 128 164 362 minecraft:stone
fill 129 161 360 129 162 360 minecraft:cobbled_deepslate
fill 129 161 361 129 164 361 minecraft:stone
setblock 130 161 324 minecraft:stripped_spruce_log
fill 130 161 325 130 164 325 minecraft:stone
setblock 131 161 323 minecraft:stripped_spruce_log
fill 131 161 324 131 164 324 minecraft:stone
fill 131 161 360 131 162 360 minecraft:stone
setblock 131 161 363 minecraft:stripped_spruce_log
fill 132 161 323 132 164 323 minecraft:stone
setblock 132 161 362 minecraft:stripped_spruce_log
fill 132 161 363 132 164 363 minecraft:stone
setblock 133 161 326 minecraft:stripped_spruce_log
setblock 133 161 340 minecraft:stone
setblock 133 161 341 minecraft:stripped_spruce_log
fill 133 161 342 133 162 342 minecraft:stone
setblock 133 161 356 minecraft:stripped_spruce_log
fill 133 161 357 133 163 357 minecraft:stone
setblock 133 161 361 minecraft:stripped_spruce_log
fill 133 161 362 133 164 362 minecraft:stone
setblock 134 161 325 minecraft:stripped_spruce_log
fill 134 161 326 134 161 329 minecraft:stone
setblock 134 161 334 minecraft:stone
setblock 134 161 335 minecraft:stripped_spruce_log
fill 134 161 336 134 162 336 minecraft:stone
setblock 134 161 340 minecraft:stripped_spruce_log
fill 134 161 341 134 164 341 minecraft:stone
setblock 134 161 345 minecraft:stripped_spruce_log
fill 134 161 346 135 161 348 minecraft:stone
fill 134 161 352 134 161 354 minecraft:stone
setblock 134 161 355 minecraft:stripped_spruce_log
fill 134 161 356 134 164 356 minecraft:stone
setblock 134 161 360 minecraft:stripped_spruce_log
fill 134 161 361 134 164 361 minecraft:stone
setblock 135 161 324 minecraft:stripped_spruce_log
fill 135 161 325 135 161 328 minecraft:stone
setblock 135 161 329 minecraft:stripped_spruce_log
fill 135 161 330 135 161 333 minecraft:stone
setblock 135 161 334 minecraft:stripped_spruce_log
fill 135 161 335 135 163 335 minecraft:stone
setblock 135 161 339 minecraft:stripped_spruce_log
fill 135 161 340 135 164 340 minecraft:stone
setblock 135 161 344 minecraft:stripped_spruce_log
fill 135 161 345 135 164 345 minecraft:stone
setblock 135 161 349 minecraft:stripped_spruce_log
fill 135 161 350 135 161 353 minecraft:stone
setblock 135 161 354 minecraft:stripped_spruce_log
fill 135 161 355 135 164 355 minecraft:stone
setblock 135 161 359 minecraft:stripped_spruce_log
fill 135 161 360 135 164 360 minecraft:stone
setblock 136 161 325 minecraft:raw_iron_block
setblock 95 162 323 minecraft:stripped_spruce_log
fill 95 162 324 95 162 327 minecraft:stone
setblock 95 162 328 minecraft:stripped_spruce_log
setblock 95 162 333 minecraft:stripped_spruce_log
fill 95 162 334 95 162 337 minecraft:stone
setblock 95 162 338 minecraft:stripped_spruce_log
fill 95 162 339 95 162 342 minecraft:stone
setblock 95 162 343 minecraft:stripped_spruce_log
fill 95 162 344 95 162 347 minecraft:stone
setblock 95 162 348 minecraft:stripped_spruce_log
fill 95 162 349 95 162 352 minecraft:stone
setblock 95 162 353 minecraft:stripped_spruce_log
fill 95 162 354 95 162 357 minecraft:stone
setblock 95 162 358 minecraft:stripped_spruce_log
fill 95 162 359 95 165 359 minecraft:stone
fill 95 162 361 95 162 362 minecraft:stone
setblock 95 162 363 minecraft:stripped_spruce_log
fill 96 162 323 96 163 324 minecraft:stone
setblock 96 162 337 minecraft:stripped_spruce_log
fill 96 162 338 96 162 341 minecraft:stone
setblock 96 162 342 minecraft:stripped_spruce_log
fill 96 162 343 96 162 346 minecraft:stone
setblock 96 162 347 minecraft:stripped_spruce_log
fill 96 162 348 96 162 351 minecraft:stone
setblock 96 162 352 minecraft:stripped_spruce_log
fill 96 162 353 96 162 356 minecraft:stone
setblock 96 162 357 minecraft:stripped_spruce_log
fill 96 162 358 96 164 358 minecraft:stone
setblock 96 162 362 minecraft:stripped_spruce_log
fill 96 162 363 96 165 363 minecraft:stone
setblock 97 162 341 minecraft:stripped_spruce_log
fill 97 162 342 97 164 342 minecraft:stone
setblock 97 162 345 minecraft:stone
setblock 97 162 346 minecraft:stripped_spruce_log
fill 97 162 347 97 164 347 minecraft:stone
setblock 97 162 357 minecraft:stone
setblock 97 162 361 minecraft:stripped_spruce_log
fill 97 162 362 97 164 362 minecraft:stone
fill 98 162 327 99 163 327 minecraft:cobbled_deepslate
setblock 98 162 361 minecraft:stone
fill 99 162 361 99 167 361 minecraft:iron_bars
setblock 100 162 323 minecraft:stripped_spruce_log
setblock 100 162 363 minecraft:stripped_spruce_log
setblock 101 162 362 minecraft:stripped_spruce_log
fill 101 162 363 101 164 363 minecraft:stone
setblock 102 162 322 minecraft:gold_block
setblock 105 162 363 minecraft:stripped_spruce_log
fill 106 162 363 109 162 363 minecraft:stone
fill 107 162 323 109 162 323 minecraft:stone
fill 107 162 358 107 163 358 minecraft:cobbled_deepslate
fill 108 162 364 108 186 364 minecraft:deepslate
fill 109 162 327 109 163 327 minecraft:cobbled_deepslate
fill 109 162 362 110 162 362 minecraft:stone
setblock 110 162 323 minecraft:stripped_spruce_log
fill 110 162 324 113 162 324 minecraft:stone
setblock 110 162 363 minecraft:stripped_spruce_log
fill 111 162 323 114 162 323 minecraft:stone
setblock 111 162 362 minecraft:stripped_spruce_log
fill 111 162 363 114 162 363 minecraft:stone
setblock 112 162 325 minecraft:stone
fill 112 162 362 112 165 362 minecraft:stone
setblock 113 162 325 minecraft:stripped_spruce_log
setblock 114 162 324 minecraft:stripped_spruce_log
fill 114 162 325 114 165 325 minecraft:stone
setblock 115 162 323 minecraft:stripped_spruce_log
fill 115 162 324 115 163 324 minecraft:stone
setblock 115 162 363 minecraft:stripped_spruce_log
fill 116 162 323 116 165 323 minecraft:stone
setblock 116 162 362 minecraft:stripped_spruce_log
fill 116 162 363 116 165 363 minecraft:stone
fill 117 162 362 117 163 362 minecraft:stone
setblock 118 162 325 minecraft:stripped_spruce_log
setblock 119 162 324 minecraft:stripped_spruce_log
setblock 120 162 323 minecraft:stripped_spruce_log
fill 120 162 324 123 162 324 minecraft:stone
fill 120 162 358 120 163 358 minecraft:cobbled_deepslate
setblock 120 162 363 minecraft:stripped_spruce_log
fill 121 162 323 124 162 323 minecraft:stone
fill 121 162 363 124 162 363 minecraft:stone
setblock 124 162 324 minecraft:stripped_spruce_log
setblock 125 162 323 minecraft:stripped_spruce_log
fill 125 162 324 128 162 324 minecraft:stone
setblock 125 162 362 minecraft:stone
setblock 125 162 363 minecraft:stripped_spruce_log
fill 126 162 323 129 162 323 minecraft:stone
setblock 126 162 362 minecraft:stripped_spruce_log
fill 126 162 363 129 162 363 minecraft:stone
fill 127 162 360 127 167 360 minecraft:cobbled_deepslate
fill 127 162 362 127 165 362 minecraft:stone
setblock 128 162 361 minecraft:stone
setblock 129 162 324 minecraft:stripped_spruce_log
fill 129 162 325 129 165 325 minecraft:stone
setblock 130 162 323 minecraft:stripped_spruce_log
fill 130 162 324 130 165 324 minecraft:stone
fill 130 162 360 130 163 360 minecraft:cobbled_deepslate
setblock 130 162 363 minecraft:stripped_spruce_log
fill 131 162 323 131 165 323 minecraft:stone
setblock 131 162 362 minecraft:stripped_spruce_log
fill 131 162 363 131 165 363 minecraft:stone
setblock 132 162 361 minecraft:stripped_spruce_log
fill 132 162 362 132 165 362 minecraft:stone
setblock 133 162 324 minecraft:stone
setblock 133 162 325 minecraft:stripped_spruce_log
fill 133 162 326 135 163 326 minecraft:stone
setblock 133 162 341 minecraft:stone
fill 133 162 343 134 162 343 minecraft:stone
setblock 133 162 360 minecraft:stripped_spruce_log
fill 133 162 361 133 165 361 minecraft:stone
setblock 134 162 324 minecraft:stripped_spruce_log
fill 134 162 325 135 164 325 minecraft:stone
fill 134 162 327 134 162 328 minecraft:stone
setblock 134 162 339 minecraft:stripped_spruce_log
fill 134 162 340 134 164 340 minecraft:stone
setblock 134 162 344 minecraft:stripped_spruce_log
fill 134 162 345 134 162 348 minecraft:stone
setblock 134 162 349 minecraft:stripped_spruce_log
fill 134 162 352 134 162 353 minecraft:stone
setblock 134 162 354 minecraft:stripped_spruce_log
fill 134 162 355 134 164 355 minecraft:stone
setblock 134 162 359 minecraft:stripped_spruce_log
fill 134 162 360 134 165 360 minecraft:stone
setblock 135 162 323 minecraft:stripped_spruce_log
fill 135 162 324 135 165 324 minecraft:stone
setblock 135 162 327 minecraft:stone
setblock 135 162 328 minecraft:stripped_spruce_log
fill 135 162 329 135 162 332 minecraft:stone
setblock 135 162 333 minecraft:stripped_spruce_log
fill 135 162 334 135 163 334 minecraft:stone
setblock 135 162 338 minecraft:stripped_spruce_log
fill 135 162 339 135 165 339 minecraft:stone
setblock 135 162 343 minecraft:stripped_spruce_log
fill 135 162 344 135 165 344 minecraft:stone
fill 135 162 346 135 162 347 minecraft:stone
setblock 135 162 348 minecraft:stripped_spruce_log
fill 135 162 349 135 162 352 minecraft:stone
setblock 135 162 353 minecraft:stripped_spruce_log
fill 135 162 354 135 165 354 minecraft:stone
setblock 135 162 358 minecraft:stripped_spruce_log
fill 135 162 359 135 165 359 minecraft:stone
setblock 135 162 363 minecraft:stripped_spruce_log
fill 136 162 325 136 186 325 minecraft:deepslate
setblock 94 163 330 minecraft:gold_block
fill 95 163 323 95 163 326 minecraft:stone
setblock 95 163 327 minecraft:stripped_spruce_log
fill 95 163 335 95 163 336 minecraft:stone
setblock 95 163 337 minecraft:stripped_spruce_log
fill 95 163 338 95 163 341 minecraft:stone
setblock 95 163 342 minecraft:stripped_spruce_log
fill 95 163 343 95 163 346 minecraft:stone
setblock 95 163 347 minecraft:stripped_spruce_log
fill 95 163 348 95 163 351 minecraft:stone
setblock 95 163 352 minecraft:stripped_spruce_log
fill 95 163 353 95 163 356 minecraft:stone
setblock 95 163 357 minecraft:stripped_spruce_log
fill 95 163 358 95 166 358 minecraft:stone
setblock 95 163 361 minecraft:stone
setblock 95 163 362 minecraft:stripped_spruce_log
fill 95 163 363 95 166 363 minecraft:stone
fill 96 163 338 96 163 340 minecraft:stone
setblock 96 163 341 minecraft:stripped_spruce_log
fill 96 163 342 96 163 345 minecraft:stone
setblock 96 163 346 minecraft:stripped_spruce_log
fill 96 163 347 96 163 350 minecraft:stone
setblock 96 163 351 minecraft:stripped_spruce_log
fill 96 163 352 96 163 355 minecraft:stone
setblock 96 163 356 minecraft:stripped_spruce_log
fill 96 163 357 96 164 357 minecraft:stone
setblock 96 163 361 minecraft:stripped_spruce_log
setblock 96 163 362 minecraft:stone
setblock 97 163 325 minecraft:light[level=15]
setblock 97 163 332 minecraft:light[level=12]
setblock 97 163 333 minecraft:light[level=15]
setblock 97 163 339 minecraft:light[level=12]
setblock 97 163 341 minecraft:stone
setblock 97 163 345 minecraft:stripped_spruce_log
fill 97 163 346 97 165 346 minecraft:stone
setblock 97 163 349 minecraft:light[level=15]
setblock 97 163 353 minecraft:light[level=12]
setblock 97 163 357 minecraft:light[level=15]
setblock 97 163 360 minecraft:stripped_spruce_log
setblock 97 163 361 minecraft:stone
fill 98 163 326 99 164 326 minecraft:cobbled_deepslate
setblock 99 163 323 minecraft:stripped_spruce_log
setblock 99 163 363 minecraft:stripped_spruce_log
fill 100 163 363 100 164 363 minecraft:stone
fill 102 163 322 102 171 322 minecraft:deepslate
setblock 104 163 325 minecraft:light[level=12]
setblock 104 163 332 minecraft:light[level=12]
setblock 104 163 339 minecraft:light[level=12]
setblock 104 163 346 minecraft:light[level=12]
setblock 104 163 353 minecraft:light[level=12]
setblock 104 163 360 minecraft:light[level=12]
setblock 104 163 363 minecraft:stripped_spruce_log
setblock 105 163 325 minecraft:light[level=15]
setblock 105 163 333 minecraft:light[level=15]
setblock 105 163 341 minecraft:light[level=15]
setblock 105 163 349 minecraft:light[level=15]
setblock 105 163 357 minecraft:light[level=15]
fill 105 163 363 108 163 363 minecraft:stone
fill 106 163 323 108 163 323 minecraft:stone
fill 107 163 359 107 164 359 minecraft:cobbled_deepslate
setblock 109 163 323 minecraft:stripped_spruce_log
fill 109 163 324 112 163 324 minecraft:stone
fill 109 163 326 109 164 326 minecraft:cobbled_deepslate
setblock 109 163 362 minecraft:stone
setblock 109 163 363 minecraft:stripped_spruce_log
fill 110 163 323 113 163 323 minecraft:stone
setblock 110 163 362 minecraft:stripped_spruce_log
fill 110 163 363 113 163 363 minecraft:stone
setblock 111 163 325 minecraft:light[level=12]
setblock 111 163 332 minecraft:light[level=12]
setblock 111 163 339 minecraft:light[level=12]
setblock 111 163 346 minecraft:light[level=12]
setblock 111 163 353 minecraft:light[level=12]
setblock 111 163 360 minecraft:light[level=12]
fill 111 163 362 111 164 362 minecraft:stone
setblock 112 163 325 minecraft:stripped_spruce_log
setblock 113 163 324 minecraft:stripped_spruce_log
fill 113 163 325 113 166 325 minecraft:stone
setblock 113 163 333 minecraft:light[level=15]
setblock 113 163 341 minecraft:light[level=15]
setblock 113 163 349 minecraft:light[level=15]
setblock 113 163 357 minecraft:light[level=15]
setblock 114 163 323 minecraft:stripped_spruce_log
fill 114 163 324 114 166 324 minecraft:stone
setblock 114 163 363 minecraft:stripped_spruce_log
fill 115 163 323 115 166 323 minecraft:stone
setblock 115 163 362 minecraft:stripped_spruce_log
fill 115 163 363 115 166 363 minecraft:stone
setblock 116 163 325 minecraft:stone
fill 116 163 362 116 164 362 minecraft:stone
setblock 117 163 325 minecraft:stripped_spruce_log
setblock 117 163 364 minecraft:raw_iron_block
setblock 118 163 324 minecraft:stripped_spruce_log
setblock 118 163 325 minecraft:light[level=12]
setblock 118 163 332 minecraft:light[level=12]
setblock 118 163 339 minecraft:light[level=12]
setblock 118 163 346 minecraft:light[level=12]
setblock 118 163 353 minecraft:light[level=12]
setblock 118 163 360 minecraft:light[level=12]
setblock 119 163 323 minecraft:stripped_spruce_log
fill 119 163 324 122 163 324 minecraft:stone
setblock 119 163 363 minecraft:stripped_spruce_log
fill 120 163 323 123 163 323 minecraft:stone
fill 120 163 359 120 164 359 minecraft:cobbled_deepslate
fill 120 163 363 123 163 363 minecraft:stone
setblock 121 163 325 minecraft:light[level=15]
setblock 121 163 333 minecraft:light[level=15]
setblock 121 163 341 minecraft:light[level=15]
setblock 121 163 349 minecraft:light[level=15]
setblock 121 163 357 minecraft:light[level=15]
setblock 123 163 324 minecraft:stripped_spruce_log
setblock 124 163 323 minecraft:stripped_spruce_log
fill 124 163 324 127 163 324 minecraft:stone
setblock 124 163 363 minecraft:stripped_spruce_log
fill 125 163 323 128 163 323 minecraft:stone
setblock 125 163 325 minecraft:light[level=12]
setblock 125 163 332 minecraft:light[level=12]
setblock 125 163 339 minecraft:light[level=12]
setblock 125 163 346 minecraft:light[level=12]
setblock 125 163 353 minecraft:light[level=12]
setblock 125 163 360 minecraft:light[level=12]
setblock 125 163 362 minecraft:stripped_spruce_log
fill 125 163 363 128 163 363 minecraft:stone
fill 126 163 362 126 166 362 minecraft:stone
fill 127 163 349 128 163 349 minecraft:raw_gold_block
setblock 128 163 324 minecraft:stripped_spruce_log
fill 128 163 325 128 166 325 minecraft:stone
setblock 129 163 323 minecraft:stripped_spruce_log
fill 129 163 324 129 166 324 minecraft:stone
setblock 129 163 333 minecraft:light[level=15]
setblock 129 163 341 minecraft:light[level=15]
setblock 129 163 349 minecraft:light[level=15]
setblock 129 163 357 minecraft:light[level=15]
setblock 129 163 363 minecraft:stripped_spruce_log
fill 130 163 323 130 166 323 minecraft:stone
fill 130 163 349 130 165 349 minecraft:raw_gold_block
setblock 130 163 362 minecraft:stripped_spruce_log
fill 130 163 363 130 166 363 minecraft:stone
setblock 131 163 325 minecraft:stone
fill 131 163 360 131 164 360 minecraft:cobbled_deepslate
setblock 131 163 361 minecraft:stripped_spruce_log
fill 131 163 362 131 166 362 minecraft:stone
setblock 132 163 325 minecraft:stripped_spruce_log
setblock 132 163 332 minecraft:light[level=12]
setblock 132 163 339 minecraft:light[level=12]
setblock 132 163 346 minecraft:light[level=12]
setblock 132 163 353 minecraft:light[level=12]
setblock 132 163 360 minecraft:stripped_spruce_log
fill 132 163 361 132 166 361 minecraft:stone
setblock 133 163 324 minecraft:stripped_spruce_log
fill 133 163 325 133 166 325 minecraft:stone
setblock 133 163 359 minecraft:stripped_spruce_log
fill 133 163 360 133 165 360 minecraft:stone
setblock 133 163 364 minecraft:diamond_block
setblock 134 163 323 minecraft:stripped_spruce_log
setblock 134 163 324 minecraft:stone
setblock 134 163 327 minecraft:stone
setblock 134 163 328 minecraft:stripped_spruce_log
setblock 134 163 338 minecraft:stripped_spruce_log
setblock 134 163 339 minecraft:stone
setblock 134 163 343 minecraft:stripped_spruce_log
fill 134 163 344 134 163 347 minecraft:stone
setblock 134 163 348 minecraft:stripped_spruce_log
fill 134 163 349 135 164 350 minecraft:stone
setblock 134 163 353 minecraft:stripped_spruce_log
setblock 134 163 354 minecraft:stone
setblock 134 163 358 minecraft:stripped_spruce_log
fill 134 163 359 134 166 359 minecraft:stone
setblock 134 163 363 minecraft:stripped_spruce_log
fill 134 163 364 135 186 364 minecraft:deepslate
fill 135 163 323 135 166 323 minecraft:stone
setblock 135 163 327 minecraft:stripped_spruce_log
fill 135 163 328 135 163 331 minecraft:stone
setblock 135 163 337 minecraft:stripped_spruce_log
fill 135 163 338 135 164 338 minecraft:stone
setblock 135 163 342 minecraft:stripped_spruce_log
fill 135 163 343 135 166 343 minecraft:stone
setblock 135 163 346 minecraft:stone
setblock 135 163 347 minecraft:stripped_spruce_log
fill 135 163 348 135 166 348 minecraft:stone
setblock 135 163 351 minecraft:stone
setblock 135 163 352 minecraft:stripped_spruce_log
fill 135 163 353 135 166 353 minecraft:stone
setblock 135 163 357 minecraft:stripped_spruce_log
fill 135 163 358 135 166 358 minecraft:stone
setblock 135 163 362 minecraft:stripped_spruce_log
fill 135 163 363 135 166 363 minecraft:stone
fill 94 164 330 94 187 330 minecraft:deepslate
fill 95 164 323 95 164 325 minecraft:stone
setblock 95 164 326 minecraft:stripped_spruce_log
setblock 95 164 327 minecraft:stone
setblock 95 164 336 minecraft:stripped_spruce_log
fill 95 164 337 95 164 340 minecraft:stone
setblock 95 164 341 minecraft:stripped_spruce_log
fill 95 164 342 95 164 345 minecraft:stone
setblock 95 164 346 minecraft:stripped_spruce_log
fill 95 164 347 95 164 350 minecraft:stone
setblock 95 164 351 minecraft:stripped_spruce_log
fill 95 164 352 95 164 355 minecraft:stone
setblock 95 164 356 minecraft:stripped_spruce_log
fill 95 164 357 95 167 357 minecraft:stone
setblock 95 164 361 minecraft:stripped_spruce_log
fill 95 164 362 95 167 362 minecraft:stone
fill 96 164 323 96 165 323 minecraft:stone
fill 96 164 324 96 167 324 minecraft:spruce_log
setblock 96 164 339 minecraft:stone
setblock 96 164 340 minecraft:stripped_spruce_log
fill 96 164 341 96 166 342 minecraft:stone
fill 96 164 343 96 167 343 minecraft:spruce_log
setblock 96 164 344 minecraft:stone
setblock 96 164 345 minecraft:stripped_spruce_log
fill 96 164 346 96 164 349 minecraft:stone
setblock 96 164 350 minecraft:stripped_spruce_log
fill 96 164 351 96 164 353 minecraft:stone
setblock 96 164 356 minecraft:stone
setblock 96 164 360 minecraft:stripped_spruce_log
fill 96 164 361 96 165 361 minecraft:stone
fill 96 164 362 96 167 362 minecraft:spruce_log
setblock 97 164 344 minecraft:stripped_spruce_log
fill 97 164 345 97 165 345 minecraft:stone
setblock 98 164 323 minecraft:stripped_spruce_log
fill 98 164 325 99 165 325 minecraft:cobbled_deepslate
setblock 98 164 363 minecraft:stripped_spruce_log
fill 99 164 363 99 165 363 minecraft:stone
fill 106 164 323 107 164 323 minecraft:stone
fill 106 164 363 107 164 363 minecraft:stone
setblock 107 164 322 minecraft:raw_gold_block
fill 107 164 360 107 165 360 minecraft:cobbled_deepslate
setblock 107 164 364 minecraft:raw_gold_block
fill 108 164 322 108 168 322 minecraft:deepslate
setblock 108 164 323 minecraft:stripped_spruce_log
fill 108 164 324 111 164 324 minecraft:stone
setblock 108 164 363 minecraft:stripped_spruce_log
fill 109 164 323 112 164 323 minecraft:stone
fill 109 164 325 109 165 325 minecraft:cobbled_deepslate
fill 109 164 363 112 164 363 minecraft:stone
setblock 110 164 362 minecraft:stone
setblock 111 164 325 minecraft:stripped_spruce_log
setblock 112 164 324 minecraft:stripped_spruce_log
fill 112 164 325 112 167 325 minecraft:stone
setblock 113 164 323 minecraft:stripped_spruce_log
fill 113 164 324 113 167 324 minecraft:stone
setblock 113 164 363 minecraft:stripped_spruce_log
fill 114 164 323 114 167 323 minecraft:stone
setblock 114 164 362 minecraft:stripped_spruce_log
fill 114 164 363 114 167 363 minecraft:stone
fill 115 164 324 115 167 324 minecraft:spruce_log
fill 115 164 362 115 167 362 minecraft:spruce_log
setblock 116 164 325 minecraft:stripped_spruce_log
setblock 117 164 322 minecraft:gold_block
setblock 117 164 324 minecraft:stripped_spruce_log
setblock 117 164 325 minecraft:stone
fill 117 164 364 117 186 364 minecraft:deepslate
fill 118 164 322 118 186 322 minecraft:deepslate
setblock 118 164 323 minecraft:stripped_spruce_log
fill 118 164 324 121 164 324 minecraft:stone
setblock 118 164 363 minecraft:stripped_spruce_log
fill 119 164 323 122 164 323 minecraft:stone
fill 119 164 363 122 164 363 minecraft:stone
fill 120 164 360 120 165 360 minecraft:cobbled_deepslate
setblock 122 164 324 minecraft:stripped_spruce_log
setblock 123 164 323 minecraft:stripped_spruce_log
fill 123 164 324 126 164 324 minecraft:stone
setblock 123 164 363 minecraft:stripped_spruce_log
fill 124 164 323 127 164 323 minecraft:stone
fill 124 164 363 127 164 363 minecraft:stone
setblock 127 164 324 minecraft:stripped_spruce_log
setblock 128 164 323 minecraft:stripped_spruce_log
fill 128 164 324 128 167 324 minecraft:stone
fill 128 164 349 129 164 349 minecraft:raw_gold_block
setblock 128 164 363 minecraft:stripped_spruce_log
fill 129 164 323 129 167 323 minecraft:stone
setblock 129 164 362 minecraft:stripped_spruce_log
fill 129 164 363 129 167 363 minecraft:stone
fill 130 164 348 133 164 348 minecraft:raw_gold_block
fill 130 164 350 133 164 350 minecraft:raw_gold_block
setblock 130 164 361 minecraft:stripped_spruce_log
fill 130 164 362 130 167 362 minecraft:stone
setblock 131 164 325 minecraft:stripped_spruce_log
fill 131 164 349 133 165 349 minecraft:raw_gold_block
fill 131 164 361 131 167 361 minecraft:stone
setblock 132 164 324 minecraft:stripped_spruce_log
fill 132 164 325 132 167 325 minecraft:stone
fill 132 164 360 132 165 360 minecraft:cobbled_deepslate
setblock 133 164 323 minecraft:stripped_spruce_log
fill 133 164 324 133 167 324 minecraft:stone
fill 133 164 326 134 164 326 minecraft:stone
setblock 133 164 358 minecraft:stripped_spruce_log
fill 133 164 359 133 165 359 minecraft:stone
setblock 133 164 363 minecraft:stripped_spruce_log
fill 133 164 364 133 186 364 minecraft:deepslate
setblock 134 164 322 minecraft:raw_iron_block
fill 134 164 323 134 167 323 minecraft:stone
fill 134 164 324 134 167 324 minecraft:spruce_log
setblock 134 164 327 minecraft:stripped_spruce_log
setblock 134 164 342 minecraft:stripped_spruce_log
fill 134 164 343 134 167 343 minecraft:spruce_log
fill 134 164 344 134 164 346 minecraft:stone
setblock 134 164 347 minecraft:stripped_spruce_log
fill 134 164 348 134 167 348 minecraft:stone
setblock 134 164 357 minecraft:stripped_spruce_log
fill 134 164 358 134 166 358 minecraft:stone
fill 134 164 362 134 167 362 minecraft:spruce_log
fill 134 164 363 134 167 363 minecraft:stone
setblock 135 164 326 minecraft:stripped_spruce_log
fill 135 164 327 135 165 329 minecraft:stone
setblock 135 164 337 minecraft:stone
setblock 135 164 341 minecraft:stripped_spruce_log
fill 135 164 342 135 167 342 minecraft:stone
setblock 135 164 346 minecraft:stripped_spruce_log
fill 135 164 347 135 167 347 minecraft:stone
setblock 135 164 351 minecraft:stripped_spruce_log
fill 135 164 352 135 167 352 minecraft:stone
setblock 135 164 356 minecraft:stripped_spruce_log
fill 135 164 357 135 167 357 minecraft:stone
setblock 135 164 361 minecraft:stripped_spruce_log
fill 135 164 362 135 167 362 minecraft:stone
setblock 136 164 362 minecraft:gold_block
fill 95 165 323 95 165 324 minecraft:stone
setblock 95 165 325 minecraft:stripped_spruce_log
fill 95 165 326 95 167 326 minecraft:stone
fill 95 165 337 95 165 339 minecraft:stone
setblock 95 165 340 minecraft:stripped_spruce_log
fill 95 165 341 95 165 344 minecraft:stone
setblock 95 165 345 minecraft:stripped_spruce_log
fill 95 165 346 95 165 349 minecraft:stone
setblock 95 165 350 minecraft:stripped_spruce_log
fill 95 165 351 95 165 354 minecraft:stone
setblock 95 165 355 minecraft:stripped_spruce_log
fill 95 165 356 95 167 356 minecraft:stone
setblock 95 165 360 minecraft:stripped_spruce_log
fill 95 165 361 95 167 361 minecraft:stone
setblock 96 165 340 minecraft:stone
setblock 96 165 344 minecraft:stripped_spruce_log
fill 96 165 345 96 165 348 minecraft:stone
setblock 96 165 349 minecraft:stripped_spruce_log
fill 96 165 350 96 165 351 minecraft:stone
setblock 96 165 360 minecraft:stone
setblock 97 165 323 minecraft:stripped_spruce_log
setblock 97 165 344 minecraft:stone
setblock 97 165 363 minecraft:stripped_spruce_log
fill 98 165 324 99 166 324 minecraft:cobbled_deepslate
setblock 98 165 363 minecraft:stone
setblock 106 165 323 minecraft:stone
fill 107 165 322 107 174 322 minecraft:deepslate
setblock 107 165 323 minecraft:stripped_spruce_log
fill 107 165 361 107 166 361 minecraft:cobbled_deepslate
setblock 107 165 363 minecraft:stripped_spruce_log
fill 107 165 364 107 175 364 minecraft:deepslate
fill 108 165 323 110 165 324 minecraft:stone
fill 108 165 363 111 165 363 minecraft:stone
setblock 111 165 323 minecraft:stone
setblock 111 165 324 minecraft:stripped_spruce_log
fill 111 165 325 111 168 325 minecraft:stone
setblock 112 165 323 minecraft:stripped_spruce_log
fill 112 165 324 112 168 324 minecraft:stone
setblock 112 165 363 minecraft:stripped_spruce_log
fill 113 165 323 113 168 323 minecraft:stone
fill 113 165 363 113 168 363 minecraft:stone
setblock 115 165 325 minecraft:stripped_spruce_log
setblock 116 165 324 minecraft:stripped_spruce_log
setblock 116 165 325 minecraft:stone
fill 117 165 322 117 182 322 minecraft:deepslate
setblock 117 165 323 minecraft:stripped_spruce_log
fill 117 165 324 120 165 324 minecraft:stone
setblock 117 165 363 minecraft:stripped_spruce_log
fill 118 165 323 121 165 323 minecraft:stone
fill 118 165 363 121 165 363 minecraft:stone
fill 118 165 364 119 186 364 minecraft:deepslate
fill 120 165 361 120 166 361 minecraft:cobbled_deepslate
setblock 120 165 364 minecraft:diamond_block
setblock 121 165 324 minecraft:stripped_spruce_log
fill 121 165 364 121 183 364 minecraft:deepslate
setblock 122 165 323 minecraft:stripped_spruce_log
fill 122 165 324 125 165 324 minecraft:stone
setblock 122 165 363 minecraft:stripped_spruce_log
fill 123 165 323 126 165 323 minecraft:stone
fill 123 165 363 126 165 363 minecraft:stone
setblock 126 165 324 minecraft:stripped_spruce_log
fill 126 165 360 126 167 360 minecraft:cobbled_deepslate
setblock 127 165 323 minecraft:stripped_spruce_log
fill 127 165 324 127 168 324 minecraft:stone
fill 127 165 359 127 167 359 minecraft:cobbled_deepslate
fill 127 165 361 127 167 361 minecraft:cobbled_deepslate
setblock 127 165 363 minecraft:stripped_spruce_log
fill 128 165 323 128 168 323 minecraft:stone
fill 128 165 360 128 167 360 minecraft:cobbled_deepslate
setblock 128 165 362 minecraft:stripped_spruce_log
fill 128 165 363 128 168 363 minecraft:stone
setblock 129 165 349 minecraft:raw_gold_block
setblock 129 165 361 minecraft:stripped_spruce_log
fill 129 165 362 129 168 362 minecraft:stone
setblock 130 165 325 minecraft:stripped_spruce_log
fill 130 165 361 130 166 361 minecraft:stone
setblock 131 165 324 minecraft:stripped_spruce_log
fill 131 165 325 131 168 325 minecraft:stone
fill 131 165 348 133 165 348 minecraft:raw_gold_block
fill 131 165 350 133 165 350 minecraft:raw_gold_block
setblock 132 165 323 minecraft:stripped_spruce_log
fill 132 165 324 132 168 324 minecraft:stone
setblock 132 165 363 minecraft:stripped_spruce_log
fill 133 165 323 133 168 323 minecraft:stone
setblock 133 165 362 minecraft:stripped_spruce_log
fill 133 165 363 133 168 363 minecraft:stone
fill 134 165 322 134 186 322 minecraft:deepslate
setblock 134 165 325 minecraft:stone
setblock 134 165 326 minecraft:stripped_spruce_log
fill 134 165 327 134 166 327 minecraft:stone
setblock 134 165 341 minecraft:stripped_spruce_log
setblock 134 165 342 minecraft:stone
fill 134 165 344 134 165 345 minecraft:stone
setblock 134 165 346 minecraft:stripped_spruce_log
fill 134 165 347 134 168 347 minecraft:stone
fill 134 165 349 134 165 350 minecraft:stone
setblock 134 165 356 minecraft:stripped_spruce_log
setblock 134 165 357 minecraft:stone
setblock 134 165 361 minecraft:stripped_spruce_log
setblock 135 165 325 minecraft:stripped_spruce_log
fill 135 165 326 135 168 326 minecraft:stone
setblock 135 165 340 minecraft:stripped_spruce_log
fill 135 165 341 135 166 341 minecraft:stone
setblock 135 165 345 minecraft:stripped_spruce_log
fill 135 165 346 135 168 346 minecraft:stone
setblock 135 165 349 minecraft:stone
setblock 135 165 350 minecraft:stripped_spruce_log
fill 135 165 351 135 168 351 minecraft:stone
setblock 135 165 355 minecraft:stripped_spruce_log
fill 135 165 356 135 168 356 minecraft:stone
setblock 135 165 360 minecraft:stripped_spruce_log
fill 135 165 361 135 168 361 minecraft:stone
fill 136 165 362 136 186 362 minecraft:deepslate
setblock 136 165 363 minecraft:diamond_block
setblock 95 166 323 minecraft:stone
setblock 95 166 324 minecraft:stripped_spruce_log
fill 95 166 325 95 168 325 minecraft:stone
setblock 95 166 339 minecraft:stripped_spruce_log
fill 95 166 340 95 166 343 minecraft:stone
setblock 95 166 344 minecraft:stripped_spruce_log
fill 95 166 345 95 166 348 minecraft:stone
setblock 95 166 349 minecraft:stripped_spruce_log
fill 95 166 350 95 166 353 minecraft:stone
setblock 95 166 354 minecraft:stripped_spruce_log
fill 95 166 355 95 169 355 minecraft:stone
setblock 95 166 359 minecraft:stripped_spruce_log
fill 95 166 360 95 167 360 minecraft:stone
setblock 96 166 323 minecraft:stripped_spruce_log
fill 96 166 344 96 166 347 minecraft:stone
setblock 96 166 348 minecraft:stripped_spruce_log
fill 96 166 349 96 168 350 minecraft:stone
setblock 96 166 363 minecraft:stripped_spruce_log
setblock 97 166 363 minecraft:stone
fill 98 166 323 99 167 323 minecraft:cobbled_deepslate
setblock 103 166 322 minecraft:gold_block
setblock 106 166 323 minecraft:stripped_spruce_log
fill 107 166 323 110 166 323 minecraft:stone
fill 107 166 362 107 167 362 minecraft:cobbled_deepslate
fill 107 166 363 110 166 363 minecraft:stone
fill 108 166 324 109 166 324 minecraft:stone
setblock 110 166 324 minecraft:stripped_spruce_log
fill 110 166 325 110 169 325 minecraft:stone
setblock 111 166 323 minecraft:stripped_spruce_log
fill 111 166 324 111 169 324 minecraft:stone
setblock 111 166 363 minecraft:stripped_spruce_log
fill 112 166 323 112 169 323 minecraft:stone
fill 112 166 363 112 169 363 minecraft:stone
setblock 114 166 325 minecraft:stripped_spruce_log
fill 115 166 325 115 169 325 minecraft:stone
setblock 116 166 323 minecraft:stripped_spruce_log
fill 116 166 324 119 166 324 minecraft:stone
setblock 116 166 363 minecraft:stripped_spruce_log
fill 117 166 323 120 166 323 minecraft:stone
fill 117 166 363 118 166 363 minecraft:stone
setblock 120 166 324 minecraft:stripped_spruce_log
fill 120 166 362 120 167 362 minecraft:cobbled_deepslate
setblock 120 166 364 minecraft:deepslate
setblock 121 166 323 minecraft:stripped_spruce_log
fill 121 166 324 124 166 324 minecraft:stone
setblock 122 166 322 minecraft:raw_iron_block
fill 122 166 323 125 166 323 minecraft:stone
fill 122 166 363 125 166 363 minecraft:stone
setblock 125 166 324 minecraft:stripped_spruce_log
setblock 126 166 323 minecraft:stripped_spruce_log
fill 126 166 324 126 169 324 minecraft:stone
fill 126 166 359 126 167 359 minecraft:cobbled_deepslate
fill 126 166 361 126 167 361 minecraft:cobbled_deepslate
setblock 126 166 363 minecraft:stripped_spruce_log
fill 127 166 323 127 169 323 minecraft:stone
fill 127 166 325 127 167 325 minecraft:stone
setblock 127 166 362 minecraft:stripped_spruce_log
fill 127 166 363 127 169 363 minecraft:stone
fill 128 166 359 128 167 359 minecraft:cobbled_deepslate
fill 128 166 361 128 167 361 minecraft:cobbled_deepslate
fill 128 166 362 128 169 362 minecraft:stone
setblock 129 166 325 minecraft:stripped_spruce_log
setblock 130 166 324 minecraft:stripped_spruce_log
fill 130 166 325 130 169 325 minecraft:stone
setblock 131 166 322 minecraft:diamond_block
setblock 131 166 323 minecraft:stripped_spruce_log
fill 131 166 324 131 169 324 minecraft:stone
setblock 131 166 363 minecraft:stripped_spruce_log
fill 132 166 323 132 169 323 minecraft:stone
fill 132 166 348 133 166 350 minecraft:raw_gold_block
setblock 132 166 362 minecraft:stripped_spruce_log
fill 132 166 363 132 169 363 minecraft:stone
setblock 133 166 360 minecraft:cobbled_deepslate
setblock 133 166 361 minecraft:stripped_spruce_log
fill 133 166 362 133 169 362 minecraft:stone
setblock 134 166 325 minecraft:stripped_spruce_log
fill 134 166 326 134 169 326 minecraft:stone
setblock 134 166 344 minecraft:stone
setblock 134 166 345 minecraft:stripped_spruce_log
fill 134 166 346 134 169 346 minecraft:stone
setblock 134 166 349 minecraft:stone
setblock 134 166 350 minecraft:stripped_spruce_log
setblock 134 166 360 minecraft:stripped_spruce_log
fill 134 166 361 134 168 361 minecraft:stone
setblock 135 166 324 minecraft:stripped_spruce_log
fill 135 166 325 135 169 325 minecraft:stone
fill 135 166 327 135 166 328 minecraft:stone
setblock 135 166 340 minecraft:stone
setblock 135 166 344 minecraft:stripped_spruce_log
fill 135 166 345 135 169 345 minecraft:stone
setblock 135 166 349 minecraft:stripped_spruce_log
fill 135 166 350 135 169 350 minecraft:stone
setblock 135 166 354 minecraft:stripped_spruce_log
fill 135 166 355 135 169 355 minecraft:stone
setblock 135 166 359 minecraft:stripped_spruce_log
fill 135 166 360 135 169 360 minecraft:stone
setblock 136 166 352 minecraft:raw_iron_block
fill 136 166 363 136 186 363 minecraft:deepslate
setblock 94 167 326 minecraft:raw_gold_block
setblock 95 167 323 minecraft:stripped_spruce_log
fill 95 167 324 95 168 324 minecraft:stone
fill 95 167 340 95 167 342 minecraft:stone
setblock 95 167 343 minecraft:stripped_spruce_log
fill 95 167 344 95 167 347 minecraft:stone
setblock 95 167 348 minecraft:stripped_spruce_log
fill 95 167 349 95 167 352 minecraft:stone
setblock 95 167 353 minecraft:stripped_spruce_log
fill 95 167 354 95 169 354 minecraft:stone
fill 95 167 358 95 168 358 minecraft:stripped_spruce_log
setblock 95 167 359 minecraft:stone
setblock 95 167 363 minecraft:stripped_spruce_log
setblock 96 167 323 minecraft:stone
fill 96 167 342 96 168 342 minecraft:stripped_spruce_log
fill 96 167 344 96 167 346 minecraft:stone
setblock 96 167 347 minecraft:stripped_spruce_log
fill 96 167 348 96 169 348 minecraft:stone
setblock 96 167 363 minecraft:stone
setblock 100 167 328 minecraft:shroomlight
setblock 100 167 334 minecraft:shroomlight
setblock 100 167 340 minecraft:shroomlight
setblock 100 167 346 minecraft:shroomlight
setblock 100 167 352 minecraft:shroomlight
setblock 100 167 358 minecraft:shroomlight
fill 103 167 322 103 172 322 minecraft:deepslate
setblock 105 167 323 minecraft:stripped_spruce_log
fill 106 167 323 109 167 323 minecraft:stone
setblock 106 167 328 minecraft:shroomlight
setblock 106 167 358 minecraft:shroomlight
fill 107 167 324 108 167 324 minecraft:stone
fill 108 167 363 109 167 363 minecraft:stone
setblock 109 167 324 minecraft:stripped_spruce_log
setblock 110 167 323 minecraft:stripped_spruce_log
fill 110 167 324 110 169 324 minecraft:stone
setblock 110 167 363 minecraft:stripped_spruce_log
fill 111 167 323 111 169 323 minecraft:stone
fill 111 167 363 111 169 363 minecraft:stone
setblock 112 167 328 minecraft:shroomlight
setblock 112 167 358 minecraft:shroomlight
setblock 113 167 325 minecraft:stripped_spruce_log
setblock 114 167 324 minecraft:stripped_spruce_log
fill 114 167 325 114 170 325 minecraft:stone
setblock 115 167 322 minecraft:raw_gold_block
setblock 115 167 323 minecraft:stripped_spruce_log
fill 115 167 363 115 168 363 minecraft:stripped_spruce_log
fill 116 167 323 118 167 324 minecraft:stone
setblock 116 167 363 minecraft:stone
setblock 118 167 328 minecraft:shroomlight
setblock 118 167 358 minecraft:shroomlight
setblock 119 167 323 minecraft:stone
setblock 119 167 324 minecraft:stripped_spruce_log
setblock 120 167 323 minecraft:stripped_spruce_log
fill 120 167 324 123 167 324 minecraft:stone
setblock 120 167 364 minecraft:gold_block
fill 121 167 323 124 167 323 minecraft:stone
fill 122 167 322 122 186 322 minecraft:deepslate
fill 123 167 363 124 167 363 minecraft:stone
setblock 124 167 324 minecraft:stripped_spruce_log
setblock 124 167 328 minecraft:shroomlight
setblock 124 167 358 minecraft:shroomlight
setblock 125 167 323 minecraft:stripped_spruce_log
fill 125 167 324 125 169 324 minecraft:stone
setblock 125 167 363 minecraft:stripped_spruce_log
fill 126 167 323 126 169 323 minecraft:stone
fill 126 167 363 126 169 363 minecraft:stone
fill 127 167 362 127 169 362 minecraft:stone
setblock 128 167 325 minecraft:stripped_spruce_log
setblock 129 167 324 minecraft:stripped_spruce_log
fill 129 167 325 129 170 325 minecraft:stone
setblock 130 167 323 minecraft:stripped_spruce_log
fill 130 167 324 130 169 324 minecraft:stone
setblock 130 167 328 minecraft:shroomlight
setblock 130 167 334 minecraft:shroomlight
setblock 130 167 340 minecraft:shroomlight
setblock 130 167 346 minecraft:shroomlight
setblock 130 167 352 minecraft:shroomlight
setblock 130 167 358 minecraft:shroomlight
setblock 130 167 363 minecraft:stripped_spruce_log
fill 131 167 322 131 186 322 minecraft:deepslate
fill 131 167 323 131 169 323 minecraft:stone
setblock 131 167 362 minecraft:stripped_spruce_log
fill 131 167 363 131 169 363 minecraft:stone
fill 132 167 361 132 168 361 minecraft:stripped_spruce_log
fill 132 167 362 132 169 362 minecraft:stone
fill 133 167 325 133 168 325 minecraft:stripped_spruce_log
setblock 133 167 349 minecraft:raw_gold_block
fill 134 167 325 134 169 325 minecraft:stone
fill 134 167 344 134 168 344 minecraft:stripped_spruce_log
fill 134 167 345 134 169 345 minecraft:stone
setblock 134 167 349 minecraft:stripped_spruce_log
fill 134 167 350 134 169 350 minecraft:stone
fill 134 167 359 134 168 359 minecraft:stripped_spruce_log
fill 134 167 360 134 168 360 minecraft:stone
setblock 135 167 323 minecraft:stripped_spruce_log
fill 135 167 324 135 169 324 minecraft:stone
setblock 135 167 327 minecraft:stone
setblock 135 167 328 minecraft:stripped_spruce_log
setblock 135 167 343 minecraft:stripped_spruce_log
fill 135 167 344 135 169 344 minecraft:stone
setblock 135 167 348 minecraft:stripped_spruce_log
fill 135 167 349 135 169 349 minecraft:stone
setblock 135 167 353 minecraft:stripped_spruce_log
fill 135 167 354 135 169 354 minecraft:stone
setblock 135 167 358 minecraft:stripped_spruce_log
fill 135 167 359 135 169 359 minecraft:stone
setblock 135 167 363 minecraft:stripped_spruce_log
fill 136 167 352 136 186 352 minecraft:deepslate
setblock 94 168 326 minecraft:gold_block
setblock 95 168 323 minecraft:stone
fill 95 168 326 100 168 339 minecraft:stripped_spruce_log
fill 95 168 340 95 168 341 minecraft:stone
setblock 95 168 342 minecraft:stripped_spruce_log
fill 95 168 343 95 168 346 minecraft:stone
setblock 95 168 347 minecraft:stripped_spruce_log
fill 95 168 348 95 168 351 minecraft:stone
fill 95 168 352 100 168 352 minecraft:stripped_spruce_log
fill 95 168 353 95 169 353 minecraft:stone
fill 95 168 356 100 168 357 minecraft:stripped_spruce_log
fill 95 168 359 95 168 362 minecraft:stripped_spruce_log
setblock 95 168 363 minecraft:stone
fill 96 168 323 104 168 323 minecraft:stripped_spruce_log
setblock 96 168 324 minecraft:glowstone
fill 96 168 325 108 168 325 minecraft:stripped_spruce_log
fill 96 168 340 100 168 341 minecraft:stripped_spruce_log
setblock 96 168 343 minecraft:glowstone
fill 96 168 344 96 168 345 minecraft:stone
fill 96 168 346 100 168 346 minecraft:stripped_spruce_log
fill 96 168 347 96 169 347 minecraft:stone
fill 96 168 351 100 168 351 minecraft:stripped_spruce_log
fill 96 168 353 100 168 355 minecraft:stripped_spruce_log
fill 96 168 358 131 168 361 minecraft:stripped_spruce_log
setblock 96 168 362 minecraft:glowstone
fill 96 168 363 107 168 363 minecraft:stripped_spruce_log
fill 97 168 324 106 168 324 minecraft:stripped_spruce_log
fill 97 168 342 100 168 345 minecraft:stripped_spruce_log
fill 97 168 347 100 168 350 minecraft:stripped_spruce_log
fill 97 168 362 114 168 362 minecraft:stripped_spruce_log
fill 101 168 326 133 168 328 minecraft:stripped_spruce_log
fill 105 168 323 108 168 323 minecraft:stone
setblock 107 168 324 minecraft:stone
setblock 108 168 324 minecraft:stripped_spruce_log
setblock 108 168 363 minecraft:stone
setblock 109 168 323 minecraft:stripped_spruce_log
fill 109 168 324 109 169 325 minecraft:stone
setblock 109 168 363 minecraft:stripped_spruce_log
fill 110 168 323 110 169 323 minecraft:stone
fill 110 168 363 110 169 363 minecraft:stone
setblock 112 168 325 minecraft:stripped_spruce_log
setblock 113 168 324 minecraft:stripped_spruce_log
fill 113 168 325 113 171 325 minecraft:stone
setblock 114 168 323 minecraft:stripped_spruce_log
fill 114 168 324 114 169 324 minecraft:stone
setblock 114 168 363 minecraft:stripped_spruce_log
fill 115 168 322 115 186 322 minecraft:deepslate
fill 115 168 323 118 168 323 minecraft:stone
setblock 115 168 324 minecraft:glowstone
setblock 115 168 362 minecraft:glowstone
fill 116 168 324 117 168 324 minecraft:stone
fill 116 168 325 125 168 325 minecraft:stripped_spruce_log
fill 116 168 362 122 168 363 minecraft:stripped_spruce_log
setblock 118 168 324 minecraft:stripped_spruce_log
setblock 119 168 323 minecraft:stripped_spruce_log
fill 119 168 324 122 168 324 minecraft:stone
fill 120 168 323 123 168 323 minecraft:stone
fill 120 168 364 120 183 364 minecraft:deepslate
setblock 123 168 324 minecraft:stripped_spruce_log
fill 123 168 362 126 168 362 minecraft:stripped_spruce_log
setblock 123 168 363 minecraft:stone
setblock 124 168 323 minecraft:stripped_spruce_log
fill 124 168 324 124 169 324 minecraft:stone
setblock 124 168 363 minecraft:stripped_spruce_log
fill 125 168 323 125 169 323 minecraft:stone
fill 125 168 363 125 169 363 minecraft:stone
setblock 126 168 325 minecraft:stone
setblock 127 168 325 minecraft:stripped_spruce_log
setblock 128 168 324 minecraft:stripped_spruce_log
fill 128 168 325 128 171 325 minecraft:stone
setblock 129 168 323 minecraft:stripped_spruce_log
fill 129 168 324 129 169 324 minecraft:stone
setblock 129 168 363 minecraft:stripped_spruce_log
fill 130 168 323 130 169 323 minecraft:stone
fill 130 168 329 133 168 357 minecraft:stripped_spruce_log
setblock 130 168 362 minecraft:stripped_spruce_log
fill 130 168 363 130 169 363 minecraft:stone
fill 131 168 362 131 169 362 minecraft:stone
setblock 132 168 325 minecraft:stripped_spruce_log
fill 132 168 358 133 168 360 minecraft:stripped_spruce_log
setblock 133 168 324 minecraft:stripped_spruce_log
setblock 133 168 361 minecraft:stripped_spruce_log
setblock 134 168 323 minecraft:stripped_spruce_log
setblock 134 168 324 minecraft:glowstone
fill 134 168 327 134 168 342 minecraft:stripped_spruce_log
setblock 134 168 343 minecraft:glowstone
setblock 134 168 348 minecraft:stripped_spruce_log
fill 134 168 349 134 169 349 minecraft:stone
fill 134 168 351 134 169 351 minecraft:stone
fill 134 168 352 134 168 358 minecraft:stripped_spruce_log
setblock 134 168 362 minecraft:glowstone
setblock 134 168 363 minecraft:stripped_spruce_log
fill 135 168 323 135 169 323 minecraft:stone
setblock 135 168 327 minecraft:stripped_spruce_log
fill 135 168 328 135 169 328 minecraft:stone
fill 135 168 329 135 168 342 minecraft:stripped_spruce_log
fill 135 168 343 135 169 343 minecraft:stone
setblock 135 168 347 minecraft:stripped_spruce_log
fill 135 168 348 135 169 348 minecraft:stone
setblock 135 168 352 minecraft:stripped_spruce_log
fill 135 168 353 135 169 353 minecraft:stone
setblock 135 168 357 minecraft:stripped_spruce_log
fill 135 168 358 135 169 358 minecraft:stone
setblock 135 168 362 minecraft:stripped_spruce_log
fill 135 168 363 135 169 363 minecraft:stone
setblock 136 168 329 minecraft:diamond_block
fill 94 169 326 94 186 326 minecraft:deepslate
setblock 95 169 341 minecraft:stripped_spruce_log
fill 95 169 342 95 169 345 minecraft:stone
setblock 95 169 346 minecraft:stripped_spruce_log
fill 95 169 347 95 169 350 minecraft:stone
setblock 95 169 351 minecraft:stripped_spruce_log
setblock 95 169 352 minecraft:stone
fill 96 169 324 96 170 324 minecraft:spruce_log
fill 96 169 343 96 170 343 minecraft:spruce_log
setblock 96 169 344 minecraft:stone
setblock 96 169 345 minecraft:stripped_spruce_log
setblock 96 169 346 minecraft:stone
setblock 96 169 349 minecraft:stone
setblock 96 169 350 minecraft:stripped_spruce_log
setblock 96 169 351 minecraft:stone
fill 96 169 362 96 170 362 minecraft:spruce_log
setblock 97 169 325 minecraft:light[level=12]
setblock 97 169 332 minecraft:light[level=12]
setblock 97 169 339 minecraft:light[level=12]
setblock 97 169 346 minecraft:light[level=12]
setblock 97 169 353 minecraft:light[level=12]
setblock 97 169 360 minecraft:light[level=12]
fill 99 169 361 99 171 361 minecraft:iron_bars
fill 100 169 328 100 169 358 minecraft:stripped_dark_oak_log
fill 101 169 328 130 169 328 minecraft:stripped_dark_oak_log
fill 101 169 358 130 169 358 minecraft:stripped_dark_oak_log
fill 104 169 323 107 169 323 minecraft:stone
setblock 104 169 325 minecraft:light[level=12]
setblock 104 169 332 minecraft:light[level=12]
setblock 104 169 339 minecraft:light[level=12]
setblock 104 169 346 minecraft:light[level=12]
setblock 104 169 353 minecraft:light[level=12]
setblock 104 169 360 minecraft:light[level=12]
setblock 106 169 324 minecraft:stone
setblock 107 169 324 minecraft:stripped_spruce_log
setblock 108 169 322 minecraft:raw_gold_block
setblock 108 169 323 minecraft:stripped_spruce_log
fill 108 169 324 108 169 325 minecraft:stone
setblock 108 169 363 minecraft:stripped_spruce_log
setblock 109 169 323 minecraft:stone
setblock 109 169 363 minecraft:stone
setblock 111 169 325 minecraft:stripped_spruce_log
fill 111 169 326 113 169 327 minecraft:raw_gold_block
setblock 111 169 332 minecraft:light[level=12]
setblock 111 169 339 minecraft:light[level=12]
setblock 111 169 346 minecraft:light[level=12]
setblock 111 169 353 minecraft:light[level=12]
setblock 111 169 360 minecraft:light[level=12]
setblock 112 169 324 minecraft:stripped_spruce_log
fill 112 169 325 112 172 325 minecraft:stone
fill 112 169 329 112 170 329 minecraft:raw_gold_block
setblock 113 169 323 minecraft:stripped_spruce_log
setblock 113 169 324 minecraft:stone
setblock 113 169 363 minecraft:stripped_spruce_log
fill 114 169 323 117 169 323 minecraft:stone
fill 115 169 324 115 170 324 minecraft:spruce_log
fill 115 169 362 115 170 362 minecraft:spruce_log
setblock 116 169 324 minecraft:stone
setblock 117 169 324 minecraft:stripped_spruce_log
setblock 118 169 323 minecraft:stripped_spruce_log
fill 118 169 324 121 169 324 minecraft:stone
setblock 118 169 325 minecraft:light[level=12]
setblock 118 169 332 minecraft:light[level=12]
setblock 118 169 339 minecraft:light[level=12]
setblock 118 169 346 minecraft:light[level=12]
setblock 118 169 353 minecraft:light[level=12]
setblock 118 169 360 minecraft:light[level=12]
fill 119 169 323 122 169 323 minecraft:stone
setblock 122 169 324 minecraft:stripped_spruce_log
setblock 123 169 323 minecraft:stripped_spruce_log
setblock 123 169 324 minecraft:stone
setblock 123 169 363 minecraft:stripped_spruce_log
setblock 124 169 323 minecraft:stone
setblock 124 169 363 minecraft:stone
setblock 125 169 325 minecraft:stone
setblock 125 169 332 minecraft:light[level=12]
setblock 125 169 339 minecraft:light[level=12]
setblock 125 169 346 minecraft:light[level=12]
setblock 125 169 353 minecraft:light[level=12]
setblock 125 169 360 minecraft:light[level=12]
setblock 126 169 325 minecraft:stripped_spruce_log
setblock 126 169 362 minecraft:stone
setblock 127 169 324 minecraft:stripped_spruce_log
fill 127 169 325 127 172 325 minecraft:stone
setblock 128 169 323 minecraft:stripped_spruce_log
setblock 128 169 324 minecraft:stone
setblock 128 169 363 minecraft:stripped_spruce_log
setblock 129 169 323 minecraft:stone
setblock 129 169 362 minecraft:stripped_spruce_log
setblock 129 169 363 minecraft:stone
fill 130 169 329 130 169 357 minecraft:stripped_dark_oak_log
setblock 130 169 362 minecraft:stone
setblock 131 169 325 minecraft:stripped_spruce_log
setblock 132 169 324 minecraft:stripped_spruce_log
fill 132 169 325 132 170 325 minecraft:stone
setblock 132 169 332 minecraft:light[level=12]
setblock 132 169 339 minecraft:light[level=12]
fill 132 169 346 132 188 346 minecraft:iron_bars
setblock 132 169 353 minecraft:light[level=12]
setblock 132 169 360 minecraft:light[level=12]
setblock 133 169 323 minecraft:stripped_spruce_log
setblock 133 169 324 minecraft:stone
setblock 133 169 363 minecraft:stripped_spruce_log
setblock 134 169 323 minecraft:stone
fill 134 169 324 134 170 324 minecraft:spruce_log
fill 134 169 343 134 170 343 minecraft:spruce_log
setblock 134 169 347 minecraft:stripped_spruce_log
setblock 134 169 348 minecraft:stone
setblock 134 169 352 minecraft:stripped_spruce_log
fill 134 169 362 134 170 362 minecraft:spruce_log
setblock 134 169 363 minecraft:stone
setblock 135 169 326 minecraft:stripped_spruce_log
setblock 135 169 327 minecraft:stone
setblock 135 169 346 minecraft:stripped_spruce_log
setblock 135 169 347 minecraft:stone
setblock 135 169 351 minecraft:stripped_spruce_log
setblock 135 169 352 minecraft:stone
setblock 135 169 356 minecraft:stripped_spruce_log
setblock 135 169 357 minecraft:stone
setblock 135 169 361 minecraft:stripped_spruce_log
setblock 135 169 362 minecraft:stone
fill 136 169 329 136 184 329 minecraft:deepslate
fill 95 170 323 95 170 363 minecraft:spruce_planks
fill 96 170 323 135 170 323 minecraft:spruce_planks
fill 96 170 325 96 170 342 minecraft:spruce_planks
fill 96 170 344 96 170 361 minecraft:spruce_planks
fill 96 170 363 135 170 363 minecraft:spruce_planks
fill 97 170 324 114 170 324 minecraft:spruce_planks
fill 97 170 362 114 170 362 minecraft:spruce_planks
fill 107 170 325 109 170 325 minecraft:stone
fill 108 170 322 108 186 322 minecraft:deepslate
setblock 110 170 325 minecraft:stripped_spruce_log
fill 110 170 326 110 173 326 minecraft:stone
fill 111 170 325 111 173 325 minecraft:stone
setblock 111 170 364 minecraft:raw_gold_block
setblock 112 170 330 minecraft:raw_gold_block
setblock 115 170 325 minecraft:stripped_spruce_log
fill 116 170 324 133 170 324 minecraft:spruce_planks
fill 116 170 362 133 170 362 minecraft:spruce_planks
setblock 124 170 325 minecraft:stone
setblock 125 170 325 minecraft:stripped_spruce_log
fill 126 170 325 126 173 325 minecraft:stone
setblock 130 170 325 minecraft:stripped_spruce_log
fill 131 170 325 131 173 325 minecraft:stone
fill 133 170 349 133 172 349 minecraft:stone
fill 134 170 325 135 170 342 minecraft:spruce_planks
fill 134 170 344 135 170 361 minecraft:spruce_planks
setblock 135 170 324 minecraft:spruce_planks
setblock 135 170 343 minecraft:spruce_planks
setblock 135 170 362 minecraft:spruce_planks
setblock 94 171 331 minecraft:raw_iron_block
setblock 94 171 340 minecraft:raw_gold_block
fill 94 171 341 94 176 341 minecraft:deepslate
setblock 94 171 357 minecraft:gold_block
fill 95 171 326 95 171 328 minecraft:stone
fill 95 171 341 95 171 343 minecraft:stone
setblock 95 171 344 minecraft:stripped_spruce_log
fill 95 171 345 95 171 348 minecraft:stone
setblock 95 171 349 minecraft:stripped_spruce_log
fill 95 171 350 95 171 353 minecraft:stone
setblock 95 171 354 minecraft:stripped_spruce_log
fill 95 171 355 95 174 355 minecraft:stone
fill 96 171 344 96 171 347 minecraft:stone
setblock 96 171 348 minecraft:stripped_spruce_log
fill 96 171 349 96 171 352 minecraft:stone
setblock 97 171 325 minecraft:light[level=15]
setblock 97 171 333 minecraft:light[level=15]
setblock 97 171 341 minecraft:light[level=15]
setblock 97 171 349 minecraft:light[level=15]
setblock 97 171 357 minecraft:light[level=15]
fill 103 171 323 105 171 323 minecraft:stone
setblock 104 171 324 minecraft:stone
setblock 105 171 324 minecraft:stripped_spruce_log
setblock 105 171 325 minecraft:light[level=15]
setblock 105 171 333 minecraft:light[level=15]
setblock 105 171 341 minecraft:light[level=15]
setblock 105 171 349 minecraft:light[level=15]
setblock 105 171 357 minecraft:light[level=15]
setblock 106 171 323 minecraft:stripped_spruce_log
fill 106 171 324 108 171 325 minecraft:stone
fill 107 171 323 110 171 323 minecraft:stone
fill 107 171 363 110 171 363 minecraft:stone
setblock 108 171 326 minecraft:stripped_spruce_log
setblock 109 171 324 minecraft:stone
setblock 109 171 325 minecraft:stripped_spruce_log
fill 109 171 326 109 174 326 minecraft:stone
setblock 110 171 324 minecraft:stripped_spruce_log
fill 110 171 325 110 174 325 minecraft:stone
setblock 111 171 323 minecraft:stripped_spruce_log
fill 111 171 324 114 171 324 minecraft:stone
fill 111 171 326 112 171 326 minecraft:stone
setblock 111 171 363 minecraft:stripped_spruce_log
fill 111 171 364 111 186 364 minecraft:deepslate
fill 112 171 323 115 171 323 minecraft:stone
setblock 112 171 363 minecraft:stone
setblock 113 171 333 minecraft:light[level=15]
setblock 113 171 341 minecraft:light[level=15]
setblock 113 171 349 minecraft:light[level=15]
setblock 113 171 357 minecraft:light[level=15]
setblock 114 171 325 minecraft:stripped_spruce_log
setblock 115 171 324 minecraft:stripped_spruce_log
fill 115 171 325 115 173 325 minecraft:stone
setblock 116 171 323 minecraft:stripped_spruce_log
fill 116 171 324 119 171 324 minecraft:stone
fill 117 171 323 120 171 323 minecraft:stone
setblock 120 171 324 minecraft:stripped_spruce_log
setblock 121 171 323 minecraft:stripped_spruce_log
fill 121 171 324 124 171 324 minecraft:stone
setblock 121 171 325 minecraft:light[level=15]
setblock 121 171 333 minecraft:light[level=15]
setblock 121 171 341 minecraft:light[level=15]
setblock 121 171 349 minecraft:light[level=15]
setblock 121 171 357 minecraft:light[level=15]
fill 122 171 323 125 171 323 minecraft:stone
fill 122 171 363 125 171 363 minecraft:stone
setblock 123 171 325 minecraft:stone
setblock 124 171 325 minecraft:stripped_spruce_log
setblock 125 171 324 minecraft:stripped_spruce_log
fill 125 171 325 125 174 325 minecraft:stone
fill 125 171 362 126 171 362 minecraft:stone
setblock 126 171 323 minecraft:stripped_spruce_log
fill 126 171 324 129 171 324 minecraft:stone
setblock 126 171 363 minecraft:stripped_spruce_log
fill 127 171 323 130 171 323 minecraft:stone
setblock 127 171 362 minecraft:stripped_spruce_log
fill 127 171 363 130 171 363 minecraft:stone
fill 128 171 362 131 171 362 minecraft:stone
setblock 129 171 325 minecraft:stripped_spruce_log
setblock 129 171 333 minecraft:light[level=15]
setblock 129 171 341 minecraft:light[level=15]
setblock 129 171 349 minecraft:light[level=15]
setblock 129 171 357 minecraft:light[level=15]
setblock 130 171 324 minecraft:stripped_spruce_log
fill 130 171 325 130 174 325 minecraft:stone
setblock 131 171 323 minecraft:stripped_spruce_log
fill 131 171 324 134 171 324 minecraft:stone
setblock 131 171 363 minecraft:stripped_spruce_log
fill 132 171 323 135 171 323 minecraft:stone
setblock 132 171 362 minecraft:stripped_spruce_log
fill 132 171 363 135 171 363 minecraft:stone
fill 133 171 348 135 171 348 minecraft:stone
setblock 133 171 350 minecraft:stone
setblock 133 171 351 minecraft:stripped_spruce_log
fill 133 171 352 135 172 352 minecraft:stone
fill 133 171 362 133 172 362 minecraft:stone
setblock 134 171 325 minecraft:stripped_spruce_log
fill 134 171 326 135 171 326 minecraft:stone
setblock 134 171 345 minecraft:stripped_spruce_log
fill 134 171 346 135 172 347 minecraft:stone
setblock 134 171 349 minecraft:stone
setblock 134 171 350 minecraft:stripped_spruce_log
fill 134 171 351 135 173 351 minecraft:stone
fill 134 171 353 134 171 354 minecraft:stone
setblock 134 171 355 minecraft:stripped_spruce_log
setblock 135 171 324 minecraft:stripped_spruce_log
fill 135 171 325 135 174 325 minecraft:stone
fill 135 171 327 135 171 328 minecraft:stone
setblock 135 171 329 minecraft:stripped_spruce_log
setblock 135 171 343 minecraft:stone
setblock 135 171 344 minecraft:stripped_spruce_log
fill 135 171 345 135 174 345 minecraft:stone
setblock 135 171 349 minecraft:stripped_spruce_log
fill 135 171 350 135 174 350 minecraft:stone
setblock 135 171 353 minecraft:stone
setblock 135 171 354 minecraft:stripped_spruce_log
fill 135 171 355 135 171 358 minecraft:stone
setblock 135 171 359 minecraft:stripped_spruce_log
fill 135 171 360 135 172 362 minecraft:stone
fill 94 172 331 94 183 331 minecraft:deepslate
fill 94 172 340 94 186 340 minecraft:deepslate
fill 94 172 357 94 179 357 minecraft:deepslate
fill 95 172 326 95 172 327 minecraft:stone
setblock 95 172 328 minecraft:stripped_spruce_log
fill 95 172 329 95 174 330 minecraft:stone
fill 95 172 341 95 172 342 minecraft:stone
setblock 95 172 343 minecraft:stripped_spruce_log
fill 95 172 344 95 172 347 minecraft:stone
setblock 95 172 348 minecraft:stripped_spruce_log
fill 95 172 349 95 172 352 minecraft:stone
setblock 95 172 353 minecraft:stripped_spruce_log
fill 95 172 354 95 175 354 minecraft:stone
fill 95 172 356 95 173 356 minecraft:stone
fill 96 172 344 96 172 346 minecraft:stone
setblock 96 172 347 minecraft:stripped_spruce_log
fill 96 172 348 96 172 351 minecraft:stone
setblock 96 172 352 minecraft:stripped_spruce_log
fill 96 172 353 96 175 353 minecraft:stone
setblock 102 172 322 minecraft:raw_iron_block
fill 102 172 323 104 172 323 minecraft:stone
setblock 104 172 324 minecraft:stripped_spruce_log
setblock 105 172 323 minecraft:stripped_spruce_log
fill 105 172 324 107 172 325 minecraft:stone
fill 106 172 323 109 172 323 minecraft:stone
setblock 106 172 364 minecraft:gold_block
setblock 107 172 326 minecraft:stripped_spruce_log
fill 107 172 363 109 172 363 minecraft:stone
setblock 108 172 324 minecraft:stone
setblock 108 172 325 minecraft:stripped_spruce_log
fill 108 172 326 108 175 326 minecraft:stone
setblock 109 172 324 minecraft:stripped_spruce_log
fill 109 172 325 109 175 325 minecraft:stone
setblock 110 172 323 minecraft:stripped_spruce_log
fill 110 172 324 113 172 324 minecraft:stone
setblock 110 172 363 minecraft:stripped_spruce_log
fill 111 172 323 114 172 323 minecraft:stone
setblock 111 172 326 minecraft:stone
fill 111 172 363 111 174 363 minecraft:stone
setblock 112 172 326 minecraft:stripped_spruce_log
setblock 113 172 325 minecraft:stripped_spruce_log
setblock 114 172 324 minecraft:stripped_spruce_log
fill 114 172 325 114 174 325 minecraft:stone
setblock 115 172 323 minecraft:stripped_spruce_log
fill 115 172 324 118 172 324 minecraft:stone
fill 116 172 323 119 172 323 minecraft:stone
setblock 119 172 324 minecraft:stripped_spruce_log
setblock 120 172 323 minecraft:stripped_spruce_log
fill 120 172 324 123 172 324 minecraft:stone
fill 121 172 323 124 172 323 minecraft:stone
fill 121 172 363 124 172 363 minecraft:stone
setblock 122 172 325 minecraft:stone
setblock 123 172 325 minecraft:stripped_spruce_log
setblock 124 172 324 minecraft:stripped_spruce_log
fill 124 172 325 124 175 325 minecraft:stone
fill 124 172 362 125 172 362 minecraft:stone
setblock 125 172 323 minecraft:stripped_spruce_log
fill 125 172 324 128 172 324 minecraft:stone
setblock 125 172 363 minecraft:stripped_spruce_log
fill 126 172 323 129 172 323 minecraft:stone
setblock 126 172 326 minecraft:stone
setblock 126 172 362 minecraft:stripped_spruce_log
fill 126 172 363 129 172 363 minecraft:stone
setblock 127 172 326 minecraft:stripped_spruce_log
fill 127 172 362 130 172 362 minecraft:stone
setblock 128 172 325 minecraft:stripped_spruce_log
fill 128 172 326 128 173 326 minecraft:stone
setblock 129 172 324 minecraft:stripped_spruce_log
fill 129 172 325 129 175 325 minecraft:stone
setblock 130 172 323 minecraft:stripped_spruce_log
fill 130 172 324 133 172 324 minecraft:stone
setblock 130 172 363 minecraft:stripped_spruce_log
fill 131 172 323 134 172 323 minecraft:stone
setblock 131 172 362 minecraft:stripped_spruce_log
fill 131 172 363 134 172 363 minecraft:stone
fill 132 172 362 132 174 362 minecraft:stone
fill 133 172 348 134 172 348 minecraft:stone
setblock 133 172 350 minecraft:stripped_spruce_log
fill 133 172 351 133 175 351 minecraft:stone
fill 133 172 353 134 172 353 minecraft:stone
setblock 134 172 345 minecraft:stone
setblock 134 172 349 minecraft:stripped_spruce_log
fill 134 172 350 134 175 350 minecraft:stone
setblock 134 172 354 minecraft:stripped_spruce_log
fill 134 172 355 135 173 356 minecraft:stone
setblock 135 172 323 minecraft:stripped_spruce_log
fill 135 172 324 135 173 324 minecraft:stone
fill 135 172 326 135 172 327 minecraft:stone
setblock 135 172 328 minecraft:stripped_spruce_log
fill 135 172 329 135 175 329 minecraft:stone
fill 135 172 344 135 175 344 minecraft:stone
setblock 135 172 348 minecraft:stripped_spruce_log
fill 135 172 349 135 175 349 minecraft:stone
setblock 135 172 353 minecraft:stripped_spruce_log
fill 135 172 354 135 175 354 minecraft:stone
setblock 135 172 357 minecraft:stone
setblock 135 172 358 minecraft:stripped_spruce_log
fill 135 172 359 135 175 359 minecraft:stone
setblock 135 172 363 minecraft:stripped_spruce_log
setblock 136 172 337 minecraft:raw_gold_block
fill 136 172 338 136 178 340 minecraft:deepslate
fill 94 173 333 94 182 333 minecraft:deepslate
setblock 94 173 334 minecraft:gold_block
setblock 94 173 362 minecraft:raw_iron_block
fill 94 173 363 94 182 364 minecraft:deepslate
fill 95 173 322 95 186 322 minecraft:deepslate
setblock 95 173 326 minecraft:stone
setblock 95 173 327 minecraft:stripped_spruce_log
fill 95 173 328 95 176 328 minecraft:stone
setblock 95 173 331 minecraft:stone
setblock 95 173 332 minecraft:stripped_spruce_log
setblock 95 173 341 minecraft:stone
setblock 95 173 342 minecraft:stripped_spruce_log
fill 95 173 343 95 173 346 minecraft:stone
setblock 95 173 347 minecraft:stripped_spruce_log
fill 95 173 348 95 173 351 minecraft:stone
setblock 95 173 352 minecraft:stripped_spruce_log
fill 95 173 353 95 176 353 minecraft:stone
setblock 96 173 322 minecraft:raw_gold_block
setblock 96 173 345 minecraft:stone
setblock 96 173 346 minecraft:stripped_spruce_log
fill 96 173 347 96 173 350 minecraft:stone
setblock 96 173 351 minecraft:stripped_spruce_log
fill 96 173 352 96 176 352 minecraft:stone
fill 99 173 325 99 179 325 minecraft:stripped_spruce_log
fill 102 173 322 102 184 322 minecraft:deepslate
fill 102 173 323 103 173 323 minecraft:stone
setblock 103 173 322 minecraft:diamond_block
setblock 103 173 324 minecraft:stripped_spruce_log
setblock 104 173 323 minecraft:stripped_spruce_log
fill 104 173 324 106 173 325 minecraft:stone
fill 105 173 323 108 173 323 minecraft:stone
setblock 106 173 326 minecraft:stripped_spruce_log
fill 106 173 363 108 173 363 minecraft:stone
fill 106 173 364 106 182 364 minecraft:deepslate
setblock 107 173 324 minecraft:stone
setblock 107 173 325 minecraft:stripped_spruce_log
fill 107 173 326 107 176 326 minecraft:stone
setblock 108 173 324 minecraft:stripped_spruce_log
fill 108 173 325 108 176 325 minecraft:stone
setblock 109 173 323 minecraft:stripped_spruce_log
fill 109 173 324 112 173 324 minecraft:stone
setblock 109 173 363 minecraft:stripped_spruce_log
fill 110 173 323 113 173 323 minecraft:stone
fill 110 173 363 110 175 363 minecraft:stone
setblock 111 173 326 minecraft:stripped_spruce_log
setblock 112 173 325 minecraft:stripped_spruce_log
setblock 112 173 326 minecraft:stone
setblock 113 173 324 minecraft:stripped_spruce_log
fill 113 173 325 113 175 325 minecraft:stone
setblock 114 173 323 minecraft:stripped_spruce_log
fill 114 173 324 117 173 324 minecraft:stone
fill 115 173 323 118 173 323 minecraft:stone
setblock 118 173 324 minecraft:stripped_spruce_log
setblock 119 173 323 minecraft:stripped_spruce_log
fill 119 173 324 122 173 324 minecraft:stone
fill 120 173 323 123 173 323 minecraft:stone
setblock 121 173 325 minecraft:stone
fill 121 173 363 123 173 363 minecraft:stone
setblock 122 173 325 minecraft:stripped_spruce_log
setblock 123 173 324 minecraft:stripped_spruce_log
fill 123 173 325 123 176 325 minecraft:stone
setblock 123 173 364 minecraft:raw_iron_block
setblock 124 173 323 minecraft:stripped_spruce_log
fill 124 173 324 127 173 324 minecraft:stone
setblock 124 173 362 minecraft:stone
setblock 124 173 363 minecraft:stripped_spruce_log
fill 125 173 323 128 173 323 minecraft:stone
setblock 125 173 326 minecraft:stone
setblock 125 173 362 minecraft:stripped_spruce_log
fill 125 173 363 128 173 363 minecraft:stone
setblock 126 173 326 minecraft:stripped_spruce_log
fill 126 173 362 129 173 362 minecraft:stone
setblock 127 173 325 minecraft:stripped_spruce_log
fill 127 173 326 127 174 326 minecraft:stone
fill 127 173 361 129 174 361 minecraft:stone
setblock 128 173 324 minecraft:stripped_spruce_log
fill 128 173 325 128 175 325 minecraft:stone
setblock 129 173 323 minecraft:stripped_spruce_log
fill 129 173 324 132 173 324 minecraft:stone
setblock 129 173 363 minecraft:stripped_spruce_log
fill 130 173 323 133 173 323 minecraft:stone
setblock 130 173 362 minecraft:stripped_spruce_log
fill 130 173 363 133 173 363 minecraft:stone
fill 131 173 362 131 175 362 minecraft:stone
setblock 133 173 348 minecraft:stone
setblock 133 173 349 minecraft:stripped_spruce_log
fill 133 173 350 133 176 350 minecraft:stone
fill 133 173 352 133 173 353 minecraft:stone
setblock 133 173 354 minecraft:stripped_spruce_log
setblock 134 173 323 minecraft:stripped_spruce_log
fill 134 173 346 134 173 347 minecraft:stone
setblock 134 173 348 minecraft:stripped_spruce_log
fill 134 173 349 134 176 349 minecraft:stone
setblock 134 173 352 minecraft:stone
setblock 134 173 353 minecraft:stripped_spruce_log
fill 134 173 354 134 176 354 minecraft:stone
setblock 134 173 357 minecraft:stone
setblock 134 173 363 minecraft:stripped_spruce_log
setblock 135 173 326 minecraft:stone
setblock 135 173 327 minecraft:stripped_spruce_log
fill 135 173 328 135 175 328 minecraft:stone
fill 135 173 330 135 174 330 minecraft:stone
setblock 135 173 346 minecraft:stone
setblock 135 173 347 minecraft:stripped_spruce_log
fill 135 173 348 135 176 348 minecraft:stone
setblock 135 173 352 minecraft:stripped_spruce_log
fill 135 173 353 135 176 353 minecraft:stone
setblock 135 173 357 minecraft:stripped_spruce_log
fill 135 173 358 135 176 358 minecraft:stone
fill 135 173 360 135 173 361 minecraft:stone
setblock 135 173 362 minecraft:stripped_spruce_log
setblock 135 173 363 minecraft:stone
fill 136 173 337 136 186 337 minecraft:deepslate
fill 136 173 341 136 181 341 minecraft:deepslate
setblock 136 173 342 minecraft:diamond_block
fill 94 174 334 94 186 334 minecraft:deepslate
fill 94 174 346 94 181 350 minecraft:deepslate
setblock 94 174 351 minecraft:raw_iron_block
fill 94 174 362 94 187 362 minecraft:deepslate
setblock 95 174 326 minecraft:stripped_spruce_log
fill 95 174 327 95 175 327 minecraft:stone
setblock 95 174 331 minecraft:stripped_spruce_log
fill 95 174 332 95 175 334 minecraft:stone
setblock 95 174 341 minecraft:stripped_spruce_log
fill 95 174 342 95 174 345 minecraft:stone
setblock 95 174 346 minecraft:stripped_spruce_log
fill 95 174 347 95 174 350 minecraft:stone
setblock 95 174 351 minecraft:stripped_spruce_log
fill 95 174 352 95 177 352 minecraft:stone
setblock 95 174 356 minecraft:stripped_spruce_log
fill 96 174 322 96 186 322 minecraft:deepslate
setblock 96 174 345 minecraft:stripped_spruce_log
fill 96 174 346 96 174 349 minecraft:stone
setblock 96 174 350 minecraft:stripped_spruce_log
fill 96 174 351 96 177 351 minecraft:stone
setblock 96 174 354 minecraft:stone
setblock 100 174 322 minecraft:raw_gold_block
fill 101 174 323 102 174 323 minecraft:stone
fill 103 174 322 103 186 322 minecraft:deepslate
setblock 103 174 323 minecraft:stripped_spruce_log
fill 103 174 324 106 174 324 minecraft:stone
fill 104 174 323 107 174 323 minecraft:stone
fill 104 174 325 105 174 325 minecraft:stone
setblock 105 174 326 minecraft:stripped_spruce_log
fill 105 174 363 107 174 363 minecraft:stone
setblock 106 174 325 minecraft:stripped_spruce_log
fill 106 174 326 106 176 326 minecraft:stone
setblock 107 174 324 minecraft:stripped_spruce_log
fill 107 174 325 107 177 325 minecraft:stone
setblock 108 174 323 minecraft:stripped_spruce_log
fill 108 174 324 111 174 324 minecraft:stone
setblock 108 174 363 minecraft:stripped_spruce_log
fill 109 174 323 112 174 323 minecraft:stone
fill 109 174 363 109 176 363 minecraft:stone
setblock 110 174 326 minecraft:stripped_spruce_log
setblock 111 174 325 minecraft:stripped_spruce_log
setblock 111 174 326 minecraft:stone
setblock 112 174 324 minecraft:stripped_spruce_log
fill 112 174 325 112 175 325 minecraft:stone
setblock 113 174 323 minecraft:stripped_spruce_log
fill 113 174 324 116 174 324 minecraft:stone
fill 114 174 323 117 174 323 minecraft:stone
setblock 117 174 324 minecraft:stripped_spruce_log
setblock 118 174 323 minecraft:stripped_spruce_log
fill 118 174 324 121 174 324 minecraft:stone
fill 119 174 323 122 174 323 minecraft:stone
fill 120 174 363 122 174 363 minecraft:stone
setblock 121 174 325 minecraft:stripped_spruce_log
setblock 122 174 324 minecraft:stripped_spruce_log
fill 122 174 325 122 176 325 minecraft:stone
setblock 123 174 323 minecraft:stripped_spruce_log
fill 123 174 324 126 174 324 minecraft:stone
setblock 123 174 362 minecraft:stone
setblock 123 174 363 minecraft:stripped_spruce_log
fill 123 174 364 123 186 364 minecraft:deepslate
fill 124 174 323 127 174 323 minecraft:stone
setblock 124 174 362 minecraft:stripped_spruce_log
fill 124 174 363 127 174 363 minecraft:stone
setblock 125 174 326 minecraft:stripped_spruce_log
fill 125 174 362 128 174 362 minecraft:stone
setblock 126 174 325 minecraft:stripped_spruce_log
setblock 126 174 326 minecraft:stone
fill 126 174 361 126 177 361 minecraft:stone
setblock 127 174 324 minecraft:stripped_spruce_log
fill 127 174 325 127 176 325 minecraft:stone
setblock 128 174 323 minecraft:stripped_spruce_log
fill 128 174 324 131 174 324 minecraft:stone
setblock 128 174 363 minecraft:stripped_spruce_log
fill 129 174 323 132 174 323 minecraft:stone
setblock 129 174 362 minecraft:stripped_spruce_log
fill 129 174 363 132 174 363 minecraft:stone
fill 130 174 362 130 177 362 minecraft:stone
fill 132 174 322 132 186 322 minecraft:deepslate
setblock 132 174 324 minecraft:stripped_spruce_log
setblock 133 174 322 minecraft:raw_gold_block
setblock 133 174 323 minecraft:stripped_spruce_log
setblock 133 174 348 minecraft:stripped_spruce_log
fill 133 174 349 133 176 349 minecraft:stone
setblock 133 174 352 minecraft:stone
setblock 133 174 353 minecraft:stripped_spruce_log
fill 133 174 354 133 176 355 minecraft:stone
setblock 133 174 363 minecraft:stripped_spruce_log
setblock 134 174 323 minecraft:stone
setblock 134 174 346 minecraft:stone
setblock 134 174 347 minecraft:stripped_spruce_log
fill 134 174 348 134 177 348 minecraft:stone
setblock 134 174 351 minecraft:stone
setblock 134 174 352 minecraft:stripped_spruce_log
fill 134 174 353 134 177 353 minecraft:stone
fill 134 174 355 134 174 356 minecraft:stone
setblock 134 174 357 minecraft:stripped_spruce_log
setblock 134 174 363 minecraft:stone
setblock 135 174 326 minecraft:stripped_spruce_log
fill 135 174 327 135 175 327 minecraft:stone
setblock 135 174 331 minecraft:stripped_spruce_log
setblock 135 174 346 minecraft:stripped_spruce_log
fill 135 174 347 135 177 347 minecraft:stone
setblock 135 174 351 minecraft:stripped_spruce_log
fill 135 174 352 135 177 352 minecraft:stone
setblock 135 174 355 minecraft:stone
setblock 135 174 356 minecraft:stripped_spruce_log
fill 135 174 357 135 177 357 minecraft:stone
setblock 135 174 360 minecraft:stone
fill 136 174 342 136 184 342 minecraft:deepslate
setblock 136 174 354 minecraft:raw_gold_block
fill 94 175 351 94 183 351 minecraft:deepslate
setblock 94 175 354 minecraft:raw_iron_block
setblock 95 175 329 minecraft:stone
setblock 95 175 330 minecraft:stripped_spruce_log
fill 95 175 331 95 178 331 minecraft:stone
setblock 95 175 335 minecraft:stripped_spruce_log
fill 95 175 336 95 178 336 minecraft:stone
fill 95 175 342 95 175 344 minecraft:stone
setblock 95 175 345 minecraft:stripped_spruce_log
fill 95 175 346 95 175 349 minecraft:stone
setblock 95 175 350 minecraft:stripped_spruce_log
fill 95 175 351 95 178 351 minecraft:stone
setblock 95 175 355 minecraft:stripped_spruce_log
fill 95 175 356 95 177 357 minecraft:stone
fill 96 175 346 96 175 348 minecraft:stone
setblock 96 175 349 minecraft:stripped_spruce_log
fill 96 175 350 96 178 350 minecraft:stone
setblock 96 175 354 minecraft:stripped_spruce_log
setblock 97 175 325 minecraft:light[level=12]
setblock 97 175 332 minecraft:light[level=12]
setblock 97 175 339 minecraft:light[level=12]
setblock 97 175 346 minecraft:light[level=12]
setblock 97 175 353 minecraft:light[level=12]
setblock 97 175 360 minecraft:light[level=12]
fill 100 175 322 100 178 322 minecraft:deepslate
setblock 101 175 323 minecraft:stone
setblock 102 175 323 minecraft:stripped_spruce_log
fill 102 175 324 105 175 324 minecraft:stone
fill 103 175 323 106 175 323 minecraft:stone
setblock 104 175 325 minecraft:stone
setblock 104 175 332 minecraft:light[level=12]
setblock 104 175 339 minecraft:light[level=12]
setblock 104 175 346 minecraft:light[level=12]
setblock 104 175 353 minecraft:light[level=12]
setblock 104 175 360 minecraft:light[level=12]
setblock 104 175 364 minecraft:raw_iron_block
setblock 105 175 325 minecraft:stripped_spruce_log
fill 105 175 326 105 176 326 minecraft:stone
fill 105 175 363 106 175 363 minecraft:stone
setblock 106 175 324 minecraft:stripped_spruce_log
fill 106 175 325 106 178 325 minecraft:stone
setblock 107 175 322 minecraft:gold_block
setblock 107 175 323 minecraft:stripped_spruce_log
fill 107 175 324 110 175 324 minecraft:stone
setblock 107 175 363 minecraft:stripped_spruce_log
fill 108 175 323 111 175 323 minecraft:stone
fill 108 175 363 108 176 363 minecraft:stone
setblock 109 175 326 minecraft:stripped_spruce_log
setblock 110 175 325 minecraft:stripped_spruce_log
setblock 110 175 326 minecraft:stone
setblock 111 175 322 minecraft:raw_gold_block
setblock 111 175 324 minecraft:stripped_spruce_log
fill 111 175 325 111 176 325 minecraft:stone
setblock 111 175 332 minecraft:light[level=12]
setblock 111 175 339 minecraft:light[level=12]
setblock 111 175 346 minecraft:light[level=12]
setblock 111 175 353 minecraft:light[level=12]
setblock 111 175 360 minecraft:light[level=12]
setblock 112 175 323 minecraft:stripped_spruce_log
fill 112 175 324 115 175 324 minecraft:stone
fill 113 175 323 116 175 323 minecraft:stone
setblock 116 175 324 minecraft:stripped_spruce_log
setblock 117 175 323 minecraft:stripped_spruce_log
fill 117 175 324 120 175 324 minecraft:stone
fill 118 175 323 121 175 323 minecraft:stone
setblock 118 175 325 minecraft:light[level=12]
setblock 118 175 332 minecraft:light[level=12]
setblock 118 175 339 minecraft:light[level=12]
setblock 118 175 346 minecraft:light[level=12]
setblock 118 175 353 minecraft:light[level=12]
setblock 118 175 360 minecraft:light[level=12]
fill 120 175 363 121 175 363 minecraft:stone
setblock 121 175 324 minecraft:stripped_spruce_log
setblock 121 175 325 minecraft:stone
setblock 122 175 323 minecraft:stripped_spruce_log
fill 122 175 324 125 175 324 minecraft:stone
setblock 122 175 362 minecraft:stone
setblock 122 175 363 minecraft:stripped_spruce_log
fill 123 175 323 126 175 323 minecraft:stone
setblock 123 175 362 minecraft:stripped_spruce_log
fill 123 175 363 126 175 363 minecraft:stone
fill 124 175 362 127 175 362 minecraft:stone
setblock 125 175 325 minecraft:stripped_spruce_log
setblock 125 175 332 minecraft:light[level=12]
setblock 125 175 339 minecraft:light[level=12]
setblock 125 175 346 minecraft:light[level=12]
setblock 125 175 353 minecraft:light[level=12]
setblock 125 175 360 minecraft:light[level=12]
fill 125 175 361 125 178 361 minecraft:stone
setblock 126 175 324 minecraft:stripped_spruce_log
fill 126 175 325 126 176 325 minecraft:stone
setblock 127 175 323 minecraft:stripped_spruce_log
fill 127 175 324 130 175 324 minecraft:stone
fill 127 175 361 128 175 361 minecraft:stone
setblock 127 175 363 minecraft:stripped_spruce_log
fill 128 175 323 131 175 323 minecraft:stone
setblock 128 175 362 minecraft:stripped_spruce_log
fill 128 175 363 131 175 363 minecraft:stone
fill 129 175 362 129 178 362 minecraft:stone
setblock 131 175 324 minecraft:stripped_spruce_log
setblock 132 175 323 minecraft:stripped_spruce_log
setblock 132 175 325 minecraft:light[level=12]
setblock 132 175 332 minecraft:light[level=12]
setblock 132 175 339 minecraft:light[level=12]
setblock 132 175 353 minecraft:light[level=12]
setblock 132 175 360 minecraft:light[level=12]
setblock 132 175 363 minecraft:stripped_spruce_log
fill 133 175 322 133 186 322 minecraft:deepslate
setblock 133 175 352 minecraft:stripped_spruce_log
fill 133 175 353 133 178 353 minecraft:stone
fill 133 175 363 133 176 363 minecraft:stone
fill 134 175 347 134 176 347 minecraft:stone
setblock 134 175 351 minecraft:stripped_spruce_log
fill 134 175 352 134 178 352 minecraft:stone
setblock 134 175 355 minecraft:stone
setblock 134 175 356 minecraft:stripped_spruce_log
fill 134 175 357 134 178 357 minecraft:stone
setblock 135 175 330 minecraft:stripped_spruce_log
fill 135 175 331 135 176 331 minecraft:stone
setblock 135 175 345 minecraft:stripped_spruce_log
fill 135 175 346 135 177 346 minecraft:stone
setblock 135 175 350 minecraft:stripped_spruce_log
fill 135 175 351 135 178 351 minecraft:stone
setblock 135 175 355 minecraft:stripped_spruce_log
fill 135 175 356 135 178 356 minecraft:stone
setblock 135 175 360 minecraft:stripped_spruce_log
setblock 136 175 349 minecraft:gold_block
fill 136 175 354 136 187 354 minecraft:deepslate
fill 94 176 354 94 186 354 minecraft:deepslate
setblock 95 176 329 minecraft:stripped_spruce_log
fill 95 176 330 95 179 330 minecraft:stone
fill 95 176 332 95 176 333 minecraft:stone
setblock 95 176 334 minecraft:stripped_spruce_log
fill 95 176 335 95 179 335 minecraft:stone
fill 95 176 337 95 177 337 minecraft:stone
setblock 95 176 343 minecraft:stone
setblock 95 176 344 minecraft:stripped_spruce_log
fill 95 176 345 95 176 348 minecraft:stone
setblock 95 176 349 minecraft:stripped_spruce_log
fill 95 176 350 95 179 350 minecraft:stone
setblock 95 176 354 minecraft:stripped_spruce_log
fill 95 176 355 95 179 355 minecraft:stone
setblock 96 176 347 minecraft:stone
setblock 96 176 348 minecraft:stripped_spruce_log
fill 96 176 349 96 177 349 minecraft:stone
setblock 96 176 353 minecraft:stripped_spruce_log
fill 96 176 354 96 177 354 minecraft:stone
setblock 101 176 323 minecraft:stripped_spruce_log
fill 102 176 323 104 176 324 minecraft:stone
setblock 104 176 325 minecraft:stripped_spruce_log
fill 104 176 364 104 186 364 minecraft:deepslate
setblock 105 176 323 minecraft:stone
setblock 105 176 324 minecraft:stripped_spruce_log
fill 105 176 325 105 177 325 minecraft:stone
setblock 105 176 363 minecraft:stone
setblock 106 176 323 minecraft:stripped_spruce_log
fill 106 176 324 109 176 324 minecraft:stone
setblock 106 176 363 minecraft:stripped_spruce_log
fill 107 176 322 107 186 322 minecraft:deepslate
fill 107 176 323 110 176 323 minecraft:stone
fill 107 176 363 107 177 363 minecraft:stone
setblock 107 176 364 minecraft:gold_block
setblock 108 176 326 minecraft:stripped_spruce_log
setblock 109 176 325 minecraft:stripped_spruce_log
setblock 109 176 326 minecraft:stone
setblock 110 176 324 minecraft:stripped_spruce_log
setblock 110 176 325 minecraft:stone
fill 111 176 322 111 186 322 minecraft:deepslate
setblock 111 176 323 minecraft:stripped_spruce_log
fill 111 176 324 114 176 324 minecraft:stone
fill 112 176 323 115 176 323 minecraft:stone
setblock 116 176 323 minecraft:stripped_spruce_log
fill 117 176 323 120 176 323 minecraft:stone
fill 118 176 324 119 176 324 minecraft:stone
fill 119 176 363 120 176 363 minecraft:stone
setblock 120 176 324 minecraft:stripped_spruce_log
setblock 121 176 323 minecraft:stripped_spruce_log
fill 121 176 324 124 176 324 minecraft:stone
setblock 121 176 363 minecraft:stripped_spruce_log
fill 122 176 323 125 176 323 minecraft:stone
setblock 122 176 362 minecraft:stripped_spruce_log
fill 122 176 363 125 176 363 minecraft:stone
fill 123 176 362 126 176 362 minecraft:stone
setblock 124 176 325 minecraft:stripped_spruce_log
setblock 125 176 324 minecraft:stripped_spruce_log
fill 125 176 325 125 177 325 minecraft:stone
setblock 126 176 323 minecraft:stripped_spruce_log
fill 126 176 324 129 176 324 minecraft:stone
setblock 126 176 363 minecraft:stripped_spruce_log
fill 127 176 323 130 176 323 minecraft:stone
setblock 127 176 361 minecraft:stone
setblock 127 176 362 minecraft:stripped_spruce_log
fill 127 176 363 130 176 363 minecraft:stone
setblock 128 176 361 minecraft:stripped_spruce_log
fill 128 176 362 128 179 362 minecraft:stone
setblock 130 176 324 minecraft:stripped_spruce_log
setblock 131 176 323 minecraft:stripped_spruce_log
setblock 131 176 363 minecraft:stripped_spruce_log
fill 132 176 363 132 177 363 minecraft:stone
setblock 133 176 351 minecraft:stripped_spruce_log
fill 133 176 352 133 177 352 minecraft:stone
setblock 134 176 350 minecraft:stripped_spruce_log
fill 134 176 351 134 179 351 minecraft:stone
setblock 134 176 355 minecraft:stripped_spruce_log
fill 134 176 356 134 179 356 minecraft:stone
setblock 135 176 329 minecraft:stripped_spruce_log
setblock 135 176 330 minecraft:stone
setblock 135 176 345 minecraft:stone
setblock 135 176 349 minecraft:stripped_spruce_log
fill 135 176 350 135 179 350 minecraft:stone
setblock 135 176 354 minecraft:stripped_spruce_log
fill 135 176 355 135 179 355 minecraft:stone
setblock 135 176 359 minecraft:stripped_spruce_log
fill 136 176 349 136 183 349 minecraft:deepslate
fill 136 176 358 136 186 358 minecraft:deepslate
setblock 136 176 359 minecraft:diamond_block
setblock 94 177 341 minecraft:gold_block
setblock 95 177 328 minecraft:stripped_spruce_log
fill 95 177 329 95 178 329 minecraft:stone
setblock 95 177 332 minecraft:stone
setblock 95 177 333 minecraft:stripped_spruce_log
fill 95 177 334 95 180 334 minecraft:stone
setblock 95 177 338 minecraft:stripped_spruce_log
fill 95 177 344 95 177 347 minecraft:stone
setblock 95 177 348 minecraft:stripped_spruce_log
fill 95 177 349 95 179 349 minecraft:stone
setblock 95 177 353 minecraft:stripped_spruce_log
fill 95 177 354 95 180 354 minecraft:stone
setblock 96 177 332 minecraft:stripped_spruce_log
fill 96 177 333 96 180 333 minecraft:stone
setblock 96 177 348 minecraft:stone
setblock 96 177 352 minecraft:stripped_spruce_log
fill 96 177 353 96 178 353 minecraft:stone
fill 101 177 323 104 177 323 minecraft:stone
setblock 103 177 324 minecraft:stone
setblock 104 177 324 minecraft:stripped_spruce_log
setblock 104 177 325 minecraft:stone
setblock 105 177 323 minecraft:stripped_spruce_log
fill 105 177 324 108 177 324 minecraft:stone
setblock 105 177 363 minecraft:stripped_spruce_log
fill 106 177 323 109 177 323 minecraft:stone
setblock 106 177 363 minecraft:stone
fill 107 177 364 107 186 364 minecraft:deepslate
setblock 108 177 325 minecraft:stripped_spruce_log
setblock 109 177 324 minecraft:stripped_spruce_log
setblock 109 177 325 minecraft:stone
setblock 110 177 323 minecraft:stripped_spruce_log
fill 110 177 324 111 177 324 minecraft:stone
fill 111 177 323 114 177 323 minecraft:stone
setblock 112 177 364 minecraft:gold_block
setblock 115 177 323 minecraft:stripped_spruce_log
fill 116 177 323 119 177 323 minecraft:stone
setblock 119 177 324 minecraft:stripped_spruce_log
setblock 119 177 363 minecraft:stone
setblock 120 177 323 minecraft:stripped_spruce_log
fill 120 177 324 123 177 324 minecraft:stone
setblock 120 177 363 minecraft:stripped_spruce_log
fill 121 177 323 124 177 323 minecraft:stone
fill 121 177 363 124 177 363 minecraft:stone
fill 122 177 362 125 177 362 minecraft:stone
setblock 123 177 325 minecraft:stripped_spruce_log
setblock 124 177 324 minecraft:stripped_spruce_log
setblock 124 177 325 minecraft:stone
fill 124 177 361 124 179 361 minecraft:stone
setblock 125 177 323 minecraft:stripped_spruce_log
fill 125 177 324 128 177 324 minecraft:stone
setblock 125 177 363 minecraft:stripped_spruce_log
fill 126 177 323 129 177 323 minecraft:stone
setblock 126 177 362 minecraft:stripped_spruce_log
fill 126 177 363 129 177 363 minecraft:stone
setblock 127 177 361 minecraft:stripped_spruce_log
fill 127 177 362 127 180 362 minecraft:stone
setblock 130 177 323 minecraft:stripped_spruce_log
setblock 130 177 363 minecraft:stripped_spruce_log
fill 131 177 363 131 178 363 minecraft:stone
setblock 132 177 364 minecraft:gold_block
setblock 133 177 351 minecraft:stone
setblock 133 177 354 minecraft:stone
setblock 133 177 355 minecraft:stripped_spruce_log
setblock 134 177 349 minecraft:stripped_spruce_log
fill 134 177 350 134 178 350 minecraft:stone
setblock 134 177 354 minecraft:stripped_spruce_log
fill 134 177 355 134 180 355 minecraft:stone
setblock 135 177 348 minecraft:stripped_spruce_log
fill 135 177 349 135 180 349 minecraft:stone
setblock 135 177 353 minecraft:stripped_spruce_log
fill 135 177 354 135 180 354 minecraft:stone
setblock 135 177 358 minecraft:stripped_spruce_log
fill 135 177 359 135 180 359 minecraft:stone
fill 136 177 359 136 185 359 minecraft:deepslate
fill 94 178 341 94 186 341 minecraft:deepslate
setblock 95 178 332 minecraft:stripped_spruce_log
fill 95 178 333 95 181 333 minecraft:stone
setblock 95 178 337 minecraft:stripped_spruce_log
fill 95 178 338 95 181 338 minecraft:stone
setblock 95 178 346 minecraft:stone
setblock 95 178 347 minecraft:stripped_spruce_log
fill 95 178 348 95 179 348 minecraft:stone
setblock 95 178 352 minecraft:stripped_spruce_log
fill 95 178 353 95 181 353 minecraft:stone
setblock 95 178 356 minecraft:stone
setblock 96 178 332 minecraft:stone
fill 96 178 334 96 179 334 minecraft:stone
setblock 96 178 351 minecraft:stripped_spruce_log
setblock 96 178 352 minecraft:stone
fill 98 178 325 98 179 325 minecraft:stripped_spruce_log
fill 99 178 324 99 179 324 minecraft:stripped_spruce_log
fill 99 178 326 99 179 326 minecraft:stripped_spruce_log
fill 100 178 325 100 179 325 minecraft:stripped_spruce_log
fill 102 178 323 103 178 323 minecraft:stone
setblock 103 178 324 minecraft:stripped_spruce_log
setblock 104 178 323 minecraft:stripped_spruce_log
fill 104 178 324 107 178 324 minecraft:stone
fill 105 178 323 108 178 323 minecraft:stone
setblock 108 178 324 minecraft:stripped_spruce_log
setblock 109 178 323 minecraft:stripped_spruce_log
setblock 109 178 324 minecraft:stone
fill 110 178 323 112 178 323 minecraft:stone
fill 112 178 364 112 186 364 minecraft:deepslate
fill 117 178 323 118 178 323 minecraft:stone
setblock 119 178 323 minecraft:stripped_spruce_log
setblock 119 178 363 minecraft:stripped_spruce_log
fill 120 178 323 123 178 323 minecraft:stone
fill 120 178 363 123 178 363 minecraft:stone
fill 121 178 324 122 178 324 minecraft:stone
fill 121 178 362 124 178 362 minecraft:stone
setblock 123 178 324 minecraft:stripped_spruce_log
setblock 124 178 323 minecraft:stripped_spruce_log
fill 124 178 324 126 178 324 minecraft:stone
setblock 124 178 363 minecraft:stripped_spruce_log
fill 125 178 323 128 178 323 minecraft:stone
setblock 125 178 362 minecraft:stripped_spruce_log
fill 125 178 363 128 178 363 minecraft:stone
setblock 126 178 361 minecraft:stripped_spruce_log
fill 126 178 362 126 181 362 minecraft:stone
setblock 127 178 361 minecraft:stone
setblock 129 178 323 minecraft:stripped_spruce_log
setblock 129 178 363 minecraft:stripped_spruce_log
fill 130 178 363 130 179 363 minecraft:stone
fill 132 178 364 132 186 364 minecraft:deepslate
setblock 133 178 354 minecraft:stripped_spruce_log
setblock 134 178 349 minecraft:stone
setblock 134 178 353 minecraft:stripped_spruce_log
fill 134 178 354 134 181 354 minecraft:stone
setblock 135 178 347 minecraft:stripped_spruce_log
fill 135 178 348 135 179 348 minecraft:stone
setblock 135 178 352 minecraft:stripped_spruce_log
fill 135 178 353 135 181 353 minecraft:stone
setblock 135 178 357 minecraft:stripped_spruce_log
fill 135 178 358 135 181 358 minecraft:stone
setblock 94 179 339 minecraft:raw_gold_block
setblock 95 179 331 minecraft:stripped_spruce_log
fill 95 179 332 95 182 332 minecraft:stone
setblock 95 179 336 minecraft:stripped_spruce_log
fill 95 179 337 95 182 337 minecraft:stone
setblock 95 179 351 minecraft:stripped_spruce_log
fill 95 179 352 95 181 352 minecraft:stone
setblock 95 179 356 minecraft:stripped_spruce_log
setblock 96 179 335 minecraft:stripped_spruce_log
setblock 97 179 325 minecraft:light[level=15]
setblock 97 179 333 minecraft:light[level=15]
setblock 97 179 341 minecraft:light[level=15]
setblock 97 179 349 minecraft:light[level=15]
setblock 97 179 357 minecraft:light[level=15]
setblock 100 179 322 minecraft:raw_gold_block
setblock 102 179 323 minecraft:stone
setblock 103 179 323 minecraft:stripped_spruce_log
fill 104 179 323 106 179 324 minecraft:stone
setblock 105 179 325 minecraft:light[level=15]
setblock 105 179 333 minecraft:light[level=15]
setblock 105 179 341 minecraft:light[level=15]
setblock 105 179 349 minecraft:light[level=15]
setblock 105 179 357 minecraft:light[level=15]
setblock 107 179 323 minecraft:stone
setblock 107 179 324 minecraft:stripped_spruce_log
setblock 108 179 323 minecraft:stripped_spruce_log
fill 109 179 323 110 179 323 minecraft:stone
setblock 113 179 325 minecraft:light[level=15]
setblock 113 179 333 minecraft:light[level=15]
setblock 113 179 341 minecraft:light[level=15]
setblock 113 179 349 minecraft:light[level=15]
setblock 113 179 357 minecraft:light[level=15]
setblock 118 179 323 minecraft:stripped_spruce_log
fill 119 179 323 122 179 323 minecraft:stone
fill 119 179 363 122 179 363 minecraft:stone
setblock 121 179 325 minecraft:light[level=15]
setblock 121 179 333 minecraft:light[level=15]
setblock 121 179 341 minecraft:light[level=15]
setblock 121 179 349 minecraft:light[level=15]
setblock 121 179 357 minecraft:light[level=15]
fill 121 179 362 123 179 362 minecraft:stone
setblock 122 179 324 minecraft:stripped_spruce_log
setblock 123 179 323 minecraft:stripped_spruce_log
fill 123 179 324 124 179 324 minecraft:stone
fill 123 179 361 123 180 361 minecraft:stone
setblock 123 179 363 minecraft:stripped_spruce_log
fill 124 179 323 127 179 323 minecraft:stone
setblock 124 179 362 minecraft:stripped_spruce_log
fill 124 179 363 127 179 363 minecraft:stone
setblock 125 179 361 minecraft:stripped_spruce_log
fill 125 179 362 125 182 362 minecraft:stone
setblock 126 179 361 minecraft:stone
setblock 128 179 363 minecraft:stripped_spruce_log
setblock 129 179 325 minecraft:light[level=15]
setblock 129 179 333 minecraft:light[level=15]
setblock 129 179 341 minecraft:light[level=15]
setblock 129 179 349 minecraft:light[level=15]
setblock 129 179 357 minecraft:light[level=15]
fill 129 179 363 129 180 363 minecraft:stone
setblock 131 179 364 minecraft:raw_gold_block
setblock 134 179 352 minecraft:stripped_spruce_log
fill 134 179 353 134 180 353 minecraft:stone
setblock 135 179 351 minecraft:stripped_spruce_log
fill 135 179 352 135 182 352 minecraft:stone
setblock 135 179 356 minecraft:stripped_spruce_log
fill 135 179 357 135 182 357 minecraft:stone
setblock 136 179 338 minecraft:diamond_block
fill 136 179 339 136 186 340 minecraft:deepslate
fill 94 180 339 94 183 339 minecraft:deepslate
setblock 94 180 357 minecraft:raw_gold_block
fill 95 180 331 95 183 331 minecraft:stone
setblock 95 180 335 minecraft:stripped_spruce_log
fill 95 180 336 96 182 336 minecraft:stone
setblock 95 180 339 minecraft:stone
setblock 95 180 350 minecraft:stripped_spruce_log
setblock 95 180 351 minecraft:stone
setblock 95 180 355 minecraft:stripped_spruce_log
setblock 95 180 356 minecraft:stone
fill 96 180 324 96 183 324 minecraft:spruce_log
setblock 96 180 334 minecraft:stripped_spruce_log
fill 96 180 335 96 183 335 minecraft:stone
fill 96 180 343 96 183 343 minecraft:spruce_log
fill 96 180 348 96 185 348 minecraft:stripped_spruce_log
fill 96 180 362 96 183 362 minecraft:spruce_log
fill 100 180 322 100 186 322 minecraft:deepslate
setblock 102 180 323 minecraft:stripped_spruce_log
fill 103 180 323 106 180 323 minecraft:stone
setblock 103 180 364 minecraft:raw_gold_block
fill 104 180 358 104 181 363 minecraft:stripped_spruce_log
fill 105 180 351 105 181 362 minecraft:stripped_spruce_log
fill 106 180 345 106 181 352 minecraft:stripped_spruce_log
setblock 107 180 323 minecraft:stripped_spruce_log
setblock 108 180 323 minecraft:stone
fill 115 180 324 115 183 324 minecraft:spruce_log
fill 115 180 362 115 183 362 minecraft:spruce_log
fill 118 180 363 121 180 363 minecraft:stone
fill 119 180 323 121 180 323 minecraft:stone
fill 120 180 362 122 180 362 minecraft:stone
setblock 122 180 323 minecraft:stripped_spruce_log
setblock 122 180 363 minecraft:stripped_spruce_log
fill 123 180 323 126 180 323 minecraft:stone
setblock 123 180 362 minecraft:stripped_spruce_log
fill 123 180 363 126 180 363 minecraft:stone
setblock 124 180 361 minecraft:stripped_spruce_log
fill 124 180 362 124 183 362 minecraft:stone
fill 125 180 361 125 183 361 minecraft:stone
setblock 127 180 363 minecraft:stripped_spruce_log
fill 128 180 363 128 183 363 minecraft:stone
fill 131 180 364 131 182 364 minecraft:deepslate
fill 132 180 360 132 189 360 minecraft:stripped_spruce_log
fill 134 180 324 134 183 324 minecraft:spruce_log
fill 134 180 343 134 183 343 minecraft:spruce_log
setblock 134 180 352 minecraft:stone
setblock 134 180 356 minecraft:stripped_spruce_log
fill 134 180 362 134 183 362 minecraft:spruce_log
setblock 135 180 350 minecraft:stripped_spruce_log
fill 135 180 351 135 183 351 minecraft:stone
setblock 135 180 355 minecraft:stripped_spruce_log
fill 135 180 356 135 183 356 minecraft:stone
fill 136 180 338 136 187 338 minecraft:deepslate
fill 94 181 357 94 186 357 minecraft:deepslate
setblock 95 181 334 minecraft:stripped_spruce_log
fill 95 181 335 95 184 335 minecraft:stone
setblock 95 181 339 minecraft:stripped_spruce_log
fill 95 181 340 95 184 340 minecraft:stone
setblock 95 181 354 minecraft:stripped_spruce_log
fill 95 181 355 95 184 355 minecraft:stone
setblock 96 181 333 minecraft:stripped_spruce_log
fill 96 181 334 96 184 334 minecraft:stone
setblock 96 181 337 minecraft:stone
fill 96 181 340 97 182 340 minecraft:iron_bars
setblock 97 181 325 minecraft:light[level=12]
setblock 97 181 332 minecraft:light[level=12]
setblock 97 181 339 minecraft:light[level=12]
setblock 97 181 346 minecraft:light[level=12]
setblock 97 181 353 minecraft:light[level=12]
setblock 97 181 360 minecraft:light[level=12]
setblock 99 181 364 minecraft:raw_gold_block
fill 102 181 323 105 181 323 minecraft:stone
fill 103 181 364 103 182 364 minecraft:deepslate
setblock 104 181 325 minecraft:light[level=12]
setblock 104 181 332 minecraft:light[level=12]
setblock 104 181 339 minecraft:light[level=12]
setblock 104 181 346 minecraft:light[level=12]
setblock 104 181 353 minecraft:light[level=12]
setblock 104 181 357 minecraft:stripped_spruce_log
fill 105 181 347 105 181 350 minecraft:stripped_spruce_log
setblock 106 181 323 minecraft:stripped_spruce_log
fill 106 181 339 107 181 344 minecraft:stripped_spruce_log
fill 106 181 353 106 181 355 minecraft:stripped_spruce_log
fill 106 181 362 106 185 362 minecraft:raw_gold_block
setblock 107 181 323 minecraft:stone
fill 107 181 331 108 181 338 minecraft:stripped_spruce_log
fill 107 181 345 107 181 346 minecraft:stripped_spruce_log
fill 108 181 323 108 182 330 minecraft:stripped_spruce_log
fill 109 181 323 109 181 329 minecraft:stripped_spruce_log
setblock 111 181 325 minecraft:light[level=12]
setblock 111 181 332 minecraft:light[level=12]
setblock 111 181 339 minecraft:light[level=12]
setblock 111 181 346 minecraft:light[level=12]
setblock 111 181 353 minecraft:light[level=12]
setblock 111 181 360 minecraft:light[level=12]
setblock 118 181 325 minecraft:light[level=12]
setblock 118 181 332 minecraft:light[level=12]
setblock 118 181 339 minecraft:light[level=12]
setblock 118 181 346 minecraft:light[level=12]
setblock 118 181 353 minecraft:light[level=12]
setblock 118 181 360 minecraft:light[level=12]
fill 118 181 363 120 181 363 minecraft:stone
fill 119 181 323 120 181 323 minecraft:stone
fill 120 181 362 121 181 362 minecraft:stone
setblock 121 181 323 minecraft:stripped_spruce_log
setblock 121 181 363 minecraft:stripped_spruce_log
fill 122 181 323 125 181 323 minecraft:stone
setblock 122 181 361 minecraft:stone
setblock 122 181 362 minecraft:stripped_spruce_log
fill 122 181 363 125 181 363 minecraft:stone
setblock 123 181 322 minecraft:raw_iron_block
setblock 123 181 361 minecraft:stripped_spruce_log
fill 123 181 362 123 184 362 minecraft:stone
fill 124 181 361 124 184 361 minecraft:stone
setblock 125 181 325 minecraft:light[level=12]
setblock 125 181 332 minecraft:light[level=12]
setblock 125 181 339 minecraft:light[level=12]
setblock 125 181 346 minecraft:light[level=12]
setblock 125 181 353 minecraft:light[level=12]
setblock 125 181 360 minecraft:light[level=12]
setblock 126 181 363 minecraft:stripped_spruce_log
setblock 127 181 362 minecraft:stripped_spruce_log
fill 127 181 363 127 184 363 minecraft:stone
setblock 132 181 325 minecraft:light[level=12]
setblock 132 181 332 minecraft:light[level=12]
setblock 132 181 339 minecraft:light[level=12]
setblock 132 181 353 minecraft:light[level=12]
setblock 134 181 355 minecraft:stripped_spruce_log
fill 135 181 350 135 182 350 minecraft:stone
setblock 135 181 354 minecraft:stripped_spruce_log
fill 135 181 355 135 184 355 minecraft:stone
setblock 135 181 359 minecraft:stripped_spruce_log
setblock 136 181 331 minecraft:gold_block
setblock 94 182 346 minecraft:diamond_block
fill 94 182 347 94 183 350 minecraft:deepslate
setblock 95 182 333 minecraft:stripped_spruce_log
fill 95 182 334 95 185 334 minecraft:stone
setblock 95 182 338 minecraft:stripped_spruce_log
fill 95 182 339 95 185 339 minecraft:stone
fill 95 182 341 95 183 341 minecraft:stone
setblock 95 182 354 minecraft:stone
fill 96 182 333 96 185 333 minecraft:stone
setblock 96 182 337 minecraft:stripped_spruce_log
fill 96 182 338 96 185 338 minecraft:stone
fill 99 182 364 99 186 364 minecraft:deepslate
fill 102 182 323 104 182 323 minecraft:stone
fill 104 182 360 104 182 363 minecraft:stripped_dark_oak_log
setblock 105 182 323 minecraft:stripped_spruce_log
fill 105 182 352 105 182 360 minecraft:stripped_dark_oak_log
fill 105 182 361 105 182 363 minecraft:raw_gold_block
fill 106 182 323 106 185 323 minecraft:stone
fill 106 182 344 106 182 351 minecraft:stripped_dark_oak_log
fill 106 182 358 106 183 361 minecraft:raw_gold_block
fill 106 182 363 107 183 363 minecraft:raw_gold_block
fill 107 182 333 107 182 340 minecraft:stripped_spruce_log
setblock 107 182 341 minecraft:stripped_dark_oak_log
fill 107 182 359 107 183 362 minecraft:raw_gold_block
fill 108 182 331 108 182 334 minecraft:stripped_spruce_log
fill 108 182 362 108 185 362 minecraft:raw_gold_block
fill 109 182 323 109 182 327 minecraft:stripped_spruce_log
fill 117 182 363 119 182 363 minecraft:stone
setblock 119 182 322 minecraft:diamond_block
setblock 119 182 323 minecraft:stone
fill 119 182 362 120 182 362 minecraft:stone
setblock 120 182 323 minecraft:stripped_spruce_log
setblock 120 182 363 minecraft:stripped_spruce_log
fill 121 182 323 124 182 323 minecraft:stone
setblock 121 182 361 minecraft:stone
setblock 121 182 362 minecraft:stripped_spruce_log
fill 121 182 363 124 182 363 minecraft:stone
setblock 122 182 361 minecraft:stripped_spruce_log
fill 122 182 362 122 185 362 minecraft:stone
fill 123 182 322 123 186 322 minecraft:deepslate
fill 123 182 361 123 185 361 minecraft:stone
setblock 125 182 363 minecraft:stripped_spruce_log
setblock 126 182 362 minecraft:stripped_spruce_log
fill 126 182 363 126 185 363 minecraft:stone
fill 127 182 362 127 185 362 minecraft:stone
setblock 135 182 353 minecraft:stripped_spruce_log
fill 135 182 354 135 185 354 minecraft:stone
setblock 135 182 358 minecraft:stripped_spruce_log
fill 135 182 359 135 185 359 minecraft:stone
fill 136 182 331 136 187 331 minecraft:deepslate
setblock 136 182 341 minecraft:diamond_block
setblock 94 183 322 minecraft:andesite
fill 94 183 323 94 186 323 minecraft:deepslate
setblock 94 183 333 minecraft:andesite
fill 94 183 346 94 184 346 minecraft:deepslate
setblock 94 183 352 minecraft:gold_block
setblock 94 183 360 minecraft:andesite
setblock 94 183 363 minecraft:gold_block
fill 94 183 364 94 184 364 minecraft:andesite
setblock 95 183 332 minecraft:stripped_spruce_log
fill 95 183 333 95 185 333 minecraft:stone
setblock 95 183 336 minecraft:stone
setblock 95 183 337 minecraft:stripped_spruce_log
fill 95 183 338 95 185 338 minecraft:stone
setblock 95 183 342 minecraft:stripped_spruce_log
setblock 95 183 356 minecraft:stone
fill 95 183 364 95 184 364 minecraft:deepslate
fill 96 183 332 96 185 332 minecraft:stone
setblock 96 183 336 minecraft:stripped_spruce_log
fill 96 183 337 97 185 337 minecraft:stone
fill 96 183 339 96 183 340 minecraft:stone
fill 96 183 364 96 184 364 minecraft:andesite
setblock 97 183 334 minecraft:stone
setblock 97 183 335 minecraft:stripped_spruce_log
fill 97 183 336 97 186 336 minecraft:stone
setblock 97 183 364 minecraft:deepslate
setblock 101 183 322 minecraft:andesite
fill 101 183 323 103 183 323 minecraft:stone
fill 101 183 364 101 186 364 minecraft:deepslate
fill 102 183 363 103 183 363 minecraft:stone
fill 102 183 364 103 183 364 minecraft:andesite
setblock 104 183 322 minecraft:andesite
setblock 104 183 323 minecraft:stripped_spruce_log
fill 104 183 361 105 184 362 minecraft:raw_gold_block
setblock 104 183 363 minecraft:stripped_spruce_log
fill 105 183 323 105 185 323 minecraft:stone
fill 105 183 359 105 183 360 minecraft:raw_gold_block
fill 105 183 363 105 185 363 minecraft:stone
fill 106 183 322 106 184 322 minecraft:andesite
setblock 106 183 364 minecraft:andesite
fill 107 183 336 107 183 339 minecraft:stripped_dark_oak_log
fill 108 183 326 108 183 333 minecraft:stripped_dark_oak_log
fill 108 183 361 108 184 361 minecraft:raw_gold_block
fill 108 183 363 108 184 363 minecraft:raw_gold_block
fill 109 183 323 109 183 325 minecraft:stripped_dark_oak_log
setblock 114 183 364 minecraft:andesite
fill 116 183 363 118 183 363 minecraft:stone
setblock 117 183 322 minecraft:gold_block
setblock 118 183 323 minecraft:stone
fill 118 183 362 119 183 362 minecraft:stone
fill 119 183 322 119 186 322 minecraft:deepslate
setblock 119 183 323 minecraft:stripped_spruce_log
fill 119 183 361 120 183 361 minecraft:stone
setblock 119 183 363 minecraft:stripped_spruce_log
fill 120 183 323 123 183 323 minecraft:stone
setblock 120 183 362 minecraft:stripped_spruce_log
fill 120 183 363 123 183 363 minecraft:stone
setblock 121 183 361 minecraft:stripped_spruce_log
fill 121 183 362 121 185 362 minecraft:stone
fill 122 183 361 122 186 361 minecraft:stone
setblock 122 183 364 minecraft:andesite
setblock 124 183 323 minecraft:stripped_spruce_log
setblock 124 183 363 minecraft:stripped_spruce_log
setblock 125 183 322 minecraft:andesite
setblock 125 183 362 minecraft:stripped_spruce_log
fill 125 183 363 125 185 363 minecraft:stone
fill 126 183 362 126 185 362 minecraft:stone
setblock 127 183 322 minecraft:andesite
setblock 131 183 364 minecraft:andesite
fill 135 183 334 135 183 336 minecraft:stone
setblock 135 183 337 minecraft:stripped_spruce_log
fill 135 183 338 135 185 339 minecraft:stone
setblock 135 183 352 minecraft:stripped_spruce_log
fill 135 183 353 135 185 353 minecraft:stone
setblock 135 183 357 minecraft:stripped_spruce_log
fill 135 183 358 135 185 358 minecraft:stone
fill 135 183 360 135 184 360 minecraft:stone
fill 136 183 322 136 184 322 minecraft:andesite
fill 136 183 341 136 184 341 minecraft:deepslate
setblock 136 183 350 minecraft:andesite
setblock 136 183 360 minecraft:andesite
setblock 94 184 322 minecraft:deepslate
setblock 94 184 331 minecraft:andesite
setblock 94 184 333 minecraft:deepslate
setblock 94 184 339 minecraft:diamond_block
fill 94 184 347 94 186 347 minecraft:deepslate
setblock 94 184 348 minecraft:andesite
fill 94 184 349 94 186 350 minecraft:deepslate
setblock 94 184 351 minecraft:andesite
fill 94 184 352 94 186 352 minecraft:deepslate
fill 94 184 360 94 186 360 minecraft:deepslate
fill 94 184 363 94 186 363 minecraft:deepslate
setblock 95 184 331 minecraft:stripped_spruce_log
fill 95 184 332 95 185 332 minecraft:stone
setblock 95 184 336 minecraft:stripped_spruce_log
fill 95 184 337 95 185 337 minecraft:stone
setblock 95 184 341 minecraft:stripped_spruce_log
fill 95 184 342 95 185 343 minecraft:stone
setblock 95 184 356 minecraft:stripped_spruce_log
fill 95 184 357 95 185 358 minecraft:stone
setblock 96 184 324 minecraft:glowstone
setblock 96 184 335 minecraft:stripped_spruce_log
fill 96 184 336 96 185 336 minecraft:stone
setblock 96 184 339 minecraft:stone
setblock 96 184 340 minecraft:stripped_spruce_log
fill 96 184 341 96 185 341 minecraft:stone
setblock 96 184 343 minecraft:glowstone
setblock 96 184 362 minecraft:glowstone
setblock 97 184 333 minecraft:stone
setblock 97 184 334 minecraft:stripped_spruce_log
fill 97 184 335 97 187 335 minecraft:stone
setblock 97 184 338 minecraft:stone
setblock 97 184 339 minecraft:stripped_spruce_log
setblock 97 184 364 minecraft:andesite
fill 99 184 323 102 184 323 minecraft:stone
fill 100 184 363 102 184 363 minecraft:stone
fill 101 184 322 101 186 322 minecraft:deepslate
fill 102 184 364 103 186 364 minecraft:deepslate
setblock 103 184 323 minecraft:stripped_spruce_log
setblock 103 184 363 minecraft:stripped_spruce_log
fill 104 184 322 104 186 322 minecraft:deepslate
fill 104 184 323 104 185 323 minecraft:stone
fill 104 184 324 106 185 324 minecraft:raw_gold_block
fill 104 184 363 104 185 363 minecraft:stone
fill 105 184 325 105 186 325 minecraft:raw_gold_block
fill 105 184 360 107 184 360 minecraft:raw_gold_block
setblock 105 184 364 minecraft:raw_iron_block
setblock 106 184 359 minecraft:raw_gold_block
fill 106 184 361 107 185 361 minecraft:raw_gold_block
fill 106 184 363 106 185 363 minecraft:stone
fill 106 184 364 106 186 364 minecraft:deepslate
setblock 107 184 323 minecraft:stone
fill 107 184 362 107 184 363 minecraft:raw_gold_block
setblock 114 184 322 minecraft:andesite
fill 114 184 363 117 184 363 minecraft:stone
fill 114 184 364 114 186 364 minecraft:deepslate
setblock 115 184 324 minecraft:glowstone
setblock 115 184 362 minecraft:glowstone
fill 115 184 364 116 184 364 minecraft:andesite
fill 116 184 362 118 184 362 minecraft:stone
fill 117 184 322 117 186 322 minecraft:deepslate
setblock 117 184 323 minecraft:stone
setblock 118 184 323 minecraft:stripped_spruce_log
fill 118 184 361 119 184 361 minecraft:stone
setblock 118 184 363 minecraft:stripped_spruce_log
fill 119 184 323 122 184 323 minecraft:stone
setblock 119 184 362 minecraft:stripped_spruce_log
fill 119 184 363 122 184 363 minecraft:stone
setblock 120 184 360 minecraft:stone
setblock 120 184 361 minecraft:stripped_spruce_log
fill 120 184 362 120 185 362 minecraft:stone
fill 120 184 364 121 184 364 minecraft:andesite
setblock 121 184 360 minecraft:stripped_spruce_log
fill 121 184 361 121 187 361 minecraft:stone
fill 122 184 360 123 186 360 minecraft:stone
setblock 122 184 364 minecraft:deepslate
setblock 123 184 323 minecraft:stripped_spruce_log
setblock 123 184 363 minecraft:stripped_spruce_log
fill 124 184 323 124 185 323 minecraft:stone
setblock 124 184 362 minecraft:stripped_spruce_log
fill 124 184 363 124 185 363 minecraft:stone
fill 125 184 322 125 186 322 minecraft:deepslate
setblock 125 184 361 minecraft:stripped_spruce_log
fill 125 184 362 125 185 362 minecraft:stone
setblock 127 184 322 minecraft:deepslate
setblock 128 184 363 minecraft:stripped_spruce_log
fill 131 184 364 131 186 364 minecraft:deepslate
setblock 134 184 324 minecraft:glowstone
setblock 134 184 343 minecraft:glowstone
setblock 134 184 362 minecraft:glowstone
setblock 135 184 322 minecraft:andesite
fill 135 184 334 135 184 335 minecraft:stone
setblock 135 184 336 minecraft:stripped_spruce_log
fill 135 184 337 135 185 337 minecraft:stone
setblock 135 184 340 minecraft:stone
setblock 135 184 341 minecraft:stripped_spruce_log
fill 135 184 342 135 185 342 minecraft:stone
setblock 135 184 350 minecraft:stone
setblock 135 184 351 minecraft:stripped_spruce_log
fill 135 184 352 135 185 352 minecraft:stone
setblock 135 184 356 minecraft:stripped_spruce_log
fill 135 184 357 135 185 357 minecraft:stone
setblock 135 184 361 minecraft:stripped_spruce_log
setblock 136 184 323 minecraft:andesite
fill 136 184 328 136 185 328 minecraft:andesite
setblock 136 184 343 minecraft:andesite
setblock 136 184 349 minecraft:gold_block
setblock 136 184 350 minecraft:deepslate
fill 136 184 356 136 186 356 minecraft:deepslate
setblock 136 184 357 minecraft:andesite
fill 136 184 360 136 186 360 minecraft:deepslate
setblock 94 185 322 minecraft:andesite
setblock 94 185 324 minecraft:andesite
fill 94 185 331 94 186 331 minecraft:deepslate
setblock 94 185 333 minecraft:andesite
setblock 94 185 335 minecraft:andesite
fill 94 185 339 94 186 339 minecraft:deepslate
setblock 94 185 346 minecraft:andesite
fill 94 185 348 94 186 348 minecraft:deepslate
fill 94 185 351 94 186 351 minecraft:deepslate
fill 94 185 364 94 186 364 minecraft:deepslate
setblock 95 185 330 minecraft:stripped_spruce_log
fill 95 185 331 96 185 331 minecraft:stone
setblock 95 185 335 minecraft:stripped_spruce_log
setblock 95 185 336 minecraft:stone
setblock 95 185 340 minecraft:stripped_spruce_log
setblock 95 185 341 minecraft:stone
setblock 95 185 344 minecraft:stone
setblock 95 185 345 minecraft:stripped_spruce_log
setblock 95 185 348 minecraft:stripped_spruce_log
setblock 95 185 354 minecraft:stone
setblock 95 185 355 minecraft:stripped_spruce_log
setblock 95 185 356 minecraft:stone
setblock 95 185 359 minecraft:stone
setblock 95 185 360 minecraft:stripped_spruce_log
setblock 95 185 364 minecraft:andesite
fill 96 185 324 96 186 324 minecraft:spruce_log
setblock 96 185 334 minecraft:stripped_spruce_log
setblock 96 185 335 minecraft:stone
setblock 96 185 339 minecraft:stripped_spruce_log
fill 96 185 340 97 185 340 minecraft:stone
setblock 96 185 342 minecraft:stone
fill 96 185 343 96 186 343 minecraft:spruce_log
setblock 96 185 347 minecraft:stripped_spruce_log
setblock 96 185 349 minecraft:stripped_spruce_log
fill 96 185 362 96 186 362 minecraft:spruce_log
fill 96 185 364 97 186 364 minecraft:deepslate
setblock 97 185 322 minecraft:diamond_block
setblock 97 185 333 minecraft:stripped_spruce_log
fill 97 185 334 97 188 334 minecraft:stone
setblock 97 185 338 minecraft:stripped_spruce_log
fill 97 185 339 97 188 339 minecraft:stone
fill 97 185 341 97 186 341 minecraft:stone
fill 97 185 348 97 190 348 minecraft:stripped_spruce_log
fill 98 185 323 101 185 323 minecraft:stone
fill 98 185 335 98 185 336 minecraft:stone
setblock 98 185 337 minecraft:stripped_spruce_log
fill 98 185 338 98 188 338 minecraft:stone
fill 98 185 363 101 185 363 minecraft:stone
fill 100 185 362 102 185 362 minecraft:stone
setblock 102 185 322 minecraft:andesite
setblock 102 185 323 minecraft:stripped_spruce_log
fill 102 185 324 103 185 324 minecraft:stone
setblock 102 185 363 minecraft:stripped_spruce_log
setblock 103 185 323 minecraft:stone
setblock 103 185 362 minecraft:stripped_spruce_log
setblock 103 185 363 minecraft:stone
fill 104 185 325 104 186 325 minecraft:raw_gold_block
fill 104 185 362 105 185 362 minecraft:raw_gold_block
fill 105 185 326 105 187 326 minecraft:raw_gold_block
setblock 105 185 361 minecraft:raw_gold_block
fill 105 185 364 105 186 364 minecraft:deepslate
fill 106 185 322 106 186 322 minecraft:deepslate
fill 106 185 325 106 186 325 minecraft:raw_gold_block
setblock 106 185 360 minecraft:raw_gold_block
setblock 107 185 323 minecraft:stripped_spruce_log
setblock 107 185 362 minecraft:raw_gold_block
setblock 107 185 363 minecraft:stripped_spruce_log
setblock 108 185 323 minecraft:stone
setblock 108 185 363 minecraft:stone
setblock 109 185 322 minecraft:diamond_block
setblock 111 185 363 minecraft:stone
setblock 112 185 363 minecraft:stripped_spruce_log
fill 113 185 363 116 185 363 minecraft:stone
fill 114 185 322 114 186 322 minecraft:deepslate
setblock 114 185 362 minecraft:stone
fill 115 185 323 116 185 323 minecraft:stone
fill 115 185 324 115 186 324 minecraft:spruce_log
fill 115 185 362 115 186 362 minecraft:spruce_log
fill 115 185 364 116 186 364 minecraft:deepslate
setblock 116 185 322 minecraft:andesite
fill 116 185 362 117 185 362 minecraft:stone
setblock 117 185 323 minecraft:stripped_spruce_log
fill 117 185 361 118 185 361 minecraft:stone
setblock 117 185 363 minecraft:stripped_spruce_log
fill 118 185 323 121 185 323 minecraft:stone
setblock 118 185 362 minecraft:stripped_spruce_log
fill 118 185 363 121 185 363 minecraft:stone
setblock 119 185 360 minecraft:stone
setblock 119 185 361 minecraft:stripped_spruce_log
setblock 119 185 362 minecraft:stone
setblock 120 185 360 minecraft:stripped_spruce_log
fill 120 185 361 120 188 361 minecraft:stone
fill 120 185 364 121 186 364 minecraft:deepslate
fill 121 185 360 121 188 360 minecraft:stone
setblock 122 185 323 minecraft:stripped_spruce_log
setblock 122 185 363 minecraft:stripped_spruce_log
setblock 122 185 364 minecraft:andesite
setblock 123 185 323 minecraft:stone
setblock 123 185 362 minecraft:stripped_spruce_log
setblock 123 185 363 minecraft:stone
setblock 124 185 360 minecraft:stone
setblock 124 185 361 minecraft:stripped_spruce_log
setblock 124 185 362 minecraft:stone
fill 125 185 361 126 187 361 minecraft:stone
fill 126 185 322 128 185 322 minecraft:andesite
setblock 127 185 363 minecraft:stripped_spruce_log
fill 128 185 363 129 185 363 minecraft:stone
fill 131 185 360 131 189 360 minecraft:stripped_spruce_log
fill 132 185 359 132 189 359 minecraft:stripped_spruce_log
fill 132 185 361 132 189 361 minecraft:stripped_spruce_log
fill 133 185 360 133 189 360 minecraft:stripped_spruce_log
fill 134 185 324 134 186 324 minecraft:spruce_log
fill 134 185 343 134 186 343 minecraft:spruce_log
setblock 134 185 356 minecraft:stripped_spruce_log
fill 134 185 357 134 185 358 minecraft:stone
fill 134 185 362 134 186 362 minecraft:spruce_log
fill 135 185 322 136 186 322 minecraft:deepslate
fill 135 185 333 135 185 334 minecraft:stone
setblock 135 185 335 minecraft:stripped_spruce_log
setblock 135 185 336 minecraft:stone
setblock 135 185 340 minecraft:stripped_spruce_log
setblock 135 185 341 minecraft:stone
fill 135 185 343 135 185 344 minecraft:stone
setblock 135 185 345 minecraft:stripped_spruce_log
setblock 135 185 346 minecraft:stone
setblock 135 185 349 minecraft:stone
setblock 135 185 350 minecraft:stripped_spruce_log
setblock 135 185 351 minecraft:stone
setblock 135 185 355 minecraft:stripped_spruce_log
setblock 135 185 356 minecraft:stone
setblock 135 185 360 minecraft:stripped_spruce_log
fill 135 185 361 135 185 362 minecraft:stone
fill 136 185 323 136 187 323 minecraft:deepslate
fill 136 185 329 136 185 330 minecraft:andesite
fill 136 185 341 136 185 342 minecraft:andesite
fill 136 185 343 136 186 343 minecraft:deepslate
setblock 136 185 349 minecraft:andesite
setblock 136 185 350 minecraft:raw_iron_block
fill 136 185 357 136 186 357 minecraft:deepslate
setblock 94 186 322 minecraft:deepslate
setblock 94 186 324 minecraft:deepslate
setblock 94 186 333 minecraft:deepslate
fill 94 186 335 94 187 335 minecraft:deepslate
setblock 94 186 346 minecraft:deepslate
fill 95 186 323 95 186 363 minecraft:spruce_planks
setblock 95 186 364 minecraft:deepslate
fill 96 186 323 135 186 323 minecraft:spruce_planks
fill 96 186 325 96 186 342 minecraft:spruce_planks
fill 96 186 344 96 186 361 minecraft:spruce_planks
fill 96 186 363 135 186 363 minecraft:spruce_planks
setblock 97 186 322 minecraft:deepslate
fill 97 186 324 114 186 324 minecraft:spruce_planks
setblock 97 186 332 minecraft:stripped_spruce_log
fill 97 186 333 97 189 333 minecraft:stone
setblock 97 186 337 minecraft:stripped_spruce_log
fill 97 186 338 97 189 338 minecraft:stone
fill 97 186 340 98 186 340 minecraft:stone
setblock 97 186 342 minecraft:stripped_spruce_log
fill 97 186 362 114 186 362 minecraft:spruce_planks
fill 98 186 334 98 186 335 minecraft:stone
setblock 98 186 336 minecraft:stripped_spruce_log
fill 98 186 337 98 189 337 minecraft:stone
fill 98 186 339 98 187 339 minecraft:stone
setblock 102 186 322 minecraft:deepslate
setblock 104 186 326 minecraft:raw_gold_block
fill 105 186 327 105 187 328 minecraft:raw_gold_block
setblock 106 186 326 minecraft:raw_gold_block
setblock 109 186 322 minecraft:deepslate
fill 115 186 361 117 186 361 minecraft:stone
setblock 116 186 322 minecraft:deepslate
fill 116 186 324 133 186 324 minecraft:spruce_planks
fill 116 186 362 133 186 362 minecraft:spruce_planks
fill 117 186 360 118 186 360 minecraft:stone
setblock 118 186 361 minecraft:stripped_spruce_log
setblock 119 186 360 minecraft:stripped_spruce_log
schedule function dropper:buildpart/74_5 1t
