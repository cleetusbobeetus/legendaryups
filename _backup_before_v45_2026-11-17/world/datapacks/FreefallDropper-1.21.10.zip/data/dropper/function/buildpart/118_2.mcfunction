setblock 471 62 469 minecraft:terracotta
fill 471 62 470 471 64 471 minecraft:red_terracotta
fill 471 62 477 471 63 477 minecraft:red_terracotta
setblock 471 62 479 minecraft:terracotta
fill 471 62 480 471 65 480 minecraft:red_terracotta
setblock 471 62 484 minecraft:terracotta
fill 471 62 485 471 62 488 minecraft:red_terracotta
setblock 471 62 489 minecraft:terracotta
fill 471 62 490 471 65 490 minecraft:red_terracotta
setblock 471 62 494 minecraft:terracotta
fill 471 62 495 471 65 495 minecraft:red_terracotta
setblock 471 62 499 minecraft:terracotta
fill 471 62 500 471 65 500 minecraft:red_terracotta
setblock 471 62 504 minecraft:terracotta
fill 472 62 464 472 65 464 minecraft:red_terracotta
setblock 472 62 468 minecraft:terracotta
setblock 472 62 483 minecraft:terracotta
fill 472 62 484 472 65 484 minecraft:red_terracotta
setblock 472 62 487 minecraft:red_terracotta
setblock 472 62 488 minecraft:terracotta
fill 472 62 489 472 65 489 minecraft:red_terracotta
setblock 472 62 493 minecraft:terracotta
fill 472 62 494 472 65 494 minecraft:red_terracotta
setblock 472 62 498 minecraft:terracotta
fill 472 62 499 472 65 499 minecraft:red_terracotta
setblock 472 62 503 minecraft:terracotta
fill 472 62 504 472 65 504 minecraft:red_terracotta
setblock 473 62 482 minecraft:terracotta
fill 473 62 483 473 65 483 minecraft:red_terracotta
setblock 473 62 487 minecraft:terracotta
fill 473 62 488 474 64 488 minecraft:red_terracotta
setblock 473 62 492 minecraft:terracotta
fill 473 62 493 473 65 493 minecraft:red_terracotta
setblock 473 62 502 minecraft:terracotta
fill 473 62 503 473 65 503 minecraft:red_terracotta
fill 474 62 484 474 62 485 minecraft:red_terracotta
setblock 474 62 486 minecraft:terracotta
fill 474 62 487 474 65 487 minecraft:red_terracotta
fill 474 62 489 474 63 489 minecraft:red_terracotta
fill 474 62 502 474 63 502 minecraft:red_terracotta
setblock 475 62 465 minecraft:terracotta
setblock 476 62 464 minecraft:terracotta
fill 476 62 465 476 64 465 minecraft:red_terracotta
setblock 476 62 504 minecraft:terracotta
fill 477 62 464 477 65 464 minecraft:red_terracotta
setblock 477 62 503 minecraft:terracotta
fill 477 62 504 477 65 504 minecraft:red_terracotta
setblock 485 62 464 minecraft:red_terracotta
setblock 486 62 464 minecraft:terracotta
fill 487 62 464 487 64 465 minecraft:red_terracotta
fill 487 62 504 487 65 504 minecraft:red_terracotta
fill 488 62 465 489 62 465 minecraft:red_terracotta
setblock 489 62 466 minecraft:terracotta
setblock 490 62 465 minecraft:terracotta
fill 490 62 466 490 65 466 minecraft:red_terracotta
setblock 491 62 464 minecraft:terracotta
fill 491 62 465 491 65 465 minecraft:red_terracotta
setblock 491 62 503 minecraft:red_terracotta
setblock 491 62 504 minecraft:terracotta
fill 492 62 464 492 65 464 minecraft:red_terracotta
setblock 492 62 503 minecraft:terracotta
fill 492 62 504 492 65 504 minecraft:red_terracotta
setblock 493 62 467 minecraft:terracotta
fill 493 62 503 493 65 503 minecraft:red_terracotta
setblock 494 62 466 minecraft:terracotta
fill 494 62 467 494 65 467 minecraft:red_terracotta
setblock 495 62 465 minecraft:terracotta
fill 495 62 466 495 65 466 minecraft:red_terracotta
setblock 496 62 464 minecraft:terracotta
fill 496 62 465 496 65 465 minecraft:red_terracotta
setblock 496 62 504 minecraft:terracotta
fill 497 62 464 497 65 464 minecraft:red_terracotta
fill 497 62 504 497 65 504 minecraft:red_terracotta
setblock 499 62 466 minecraft:terracotta
setblock 500 62 465 minecraft:terracotta
setblock 501 62 464 minecraft:terracotta
fill 501 62 465 504 62 465 minecraft:red_terracotta
setblock 501 62 504 minecraft:terracotta
fill 502 62 464 502 65 464 minecraft:red_terracotta
fill 502 62 504 502 65 504 minecraft:red_terracotta
setblock 505 62 465 minecraft:terracotta
setblock 506 62 464 minecraft:terracotta
fill 506 62 465 506 65 465 minecraft:red_terracotta
fill 506 62 479 506 63 479 minecraft:orange_concrete
setblock 506 62 504 minecraft:terracotta
fill 507 62 464 507 65 464 minecraft:red_terracotta
fill 507 62 466 508 62 466 minecraft:red_terracotta
setblock 507 62 503 minecraft:terracotta
fill 507 62 504 507 65 504 minecraft:red_terracotta
fill 508 62 503 508 65 503 minecraft:red_terracotta
setblock 509 62 466 minecraft:terracotta
fill 509 62 467 509 65 467 minecraft:red_terracotta
fill 509 62 502 509 65 502 minecraft:red_terracotta
setblock 510 62 465 minecraft:terracotta
fill 510 62 466 510 65 466 minecraft:red_terracotta
setblock 510 62 470 minecraft:terracotta
fill 510 62 483 510 62 484 minecraft:red_terracotta
setblock 510 62 485 minecraft:terracotta
fill 510 62 486 510 62 489 minecraft:red_terracotta
setblock 510 62 490 minecraft:terracotta
fill 510 62 498 510 63 498 minecraft:red_terracotta
setblock 510 62 500 minecraft:terracotta
fill 510 62 501 510 65 501 minecraft:red_terracotta
setblock 511 62 464 minecraft:terracotta
fill 511 62 465 511 65 465 minecraft:red_terracotta
setblock 511 62 468 minecraft:red_terracotta
setblock 511 62 469 minecraft:terracotta
fill 511 62 470 511 65 470 minecraft:red_terracotta
fill 511 62 472 511 62 473 minecraft:red_terracotta
setblock 511 62 478 minecraft:red_terracotta
setblock 511 62 479 minecraft:terracotta
fill 511 62 480 511 65 480 minecraft:red_terracotta
setblock 511 62 484 minecraft:terracotta
fill 511 62 485 511 62 488 minecraft:red_terracotta
setblock 511 62 489 minecraft:terracotta
fill 511 62 490 511 62 493 minecraft:red_terracotta
setblock 511 62 494 minecraft:terracotta
fill 511 62 495 511 65 495 minecraft:red_terracotta
setblock 511 62 499 minecraft:terracotta
fill 511 62 500 511 65 500 minecraft:red_terracotta
setblock 511 62 504 minecraft:terracotta
fill 471 63 464 471 66 464 minecraft:red_terracotta
setblock 471 63 467 minecraft:red_terracotta
setblock 471 63 468 minecraft:terracotta
fill 471 63 469 472 65 469 minecraft:red_terracotta
setblock 471 63 472 minecraft:red_terracotta
setblock 471 63 473 minecraft:terracotta
fill 471 63 476 471 64 476 minecraft:red_terracotta
setblock 471 63 478 minecraft:terracotta
fill 471 63 479 471 66 479 minecraft:red_terracotta
setblock 471 63 483 minecraft:terracotta
fill 471 63 484 471 63 487 minecraft:red_terracotta
setblock 471 63 488 minecraft:terracotta
fill 471 63 489 471 66 489 minecraft:red_terracotta
setblock 471 63 492 minecraft:red_terracotta
setblock 471 63 493 minecraft:terracotta
fill 471 63 494 471 66 494 minecraft:red_terracotta
setblock 471 63 498 minecraft:terracotta
fill 471 63 499 471 66 499 minecraft:red_terracotta
setblock 471 63 503 minecraft:terracotta
fill 471 63 504 471 66 504 minecraft:red_terracotta
setblock 472 63 467 minecraft:terracotta
fill 472 63 468 472 66 468 minecraft:red_terracotta
setblock 472 63 482 minecraft:terracotta
fill 472 63 483 472 66 483 minecraft:red_terracotta
setblock 472 63 487 minecraft:terracotta
fill 472 63 488 472 66 488 minecraft:red_terracotta
setblock 472 63 492 minecraft:terracotta
fill 472 63 493 472 66 493 minecraft:red_terracotta
setblock 472 63 497 minecraft:terracotta
fill 472 63 498 472 66 498 minecraft:red_terracotta
setblock 472 63 502 minecraft:terracotta
fill 472 63 503 472 66 503 minecraft:red_terracotta
fill 473 63 482 473 65 482 minecraft:red_terracotta
setblock 473 63 486 minecraft:terracotta
fill 473 63 487 473 66 487 minecraft:red_terracotta
setblock 473 63 491 minecraft:terracotta
fill 473 63 492 473 66 492 minecraft:red_terracotta
fill 473 63 494 473 63 495 minecraft:red_terracotta
setblock 473 63 501 minecraft:terracotta
fill 473 63 502 473 64 502 minecraft:red_terracotta
setblock 474 63 465 minecraft:terracotta
setblock 474 63 484 minecraft:red_terracotta
setblock 474 63 485 minecraft:terracotta
fill 474 63 486 474 66 486 minecraft:red_terracotta
setblock 474 63 490 minecraft:terracotta
setblock 475 63 464 minecraft:terracotta
fill 475 63 465 475 66 465 minecraft:red_terracotta
setblock 475 63 504 minecraft:terracotta
fill 476 63 464 476 66 464 minecraft:red_terracotta
setblock 476 63 503 minecraft:terracotta
fill 476 63 504 476 66 504 minecraft:red_terracotta
fill 483 63 464 484 63 464 minecraft:red_terracotta
setblock 485 63 464 minecraft:terracotta
fill 486 63 464 486 65 465 minecraft:red_terracotta
fill 486 63 504 486 66 504 minecraft:red_terracotta
setblock 488 63 465 minecraft:red_terracotta
setblock 488 63 466 minecraft:terracotta
setblock 489 63 465 minecraft:terracotta
fill 489 63 466 489 66 466 minecraft:red_terracotta
setblock 490 63 464 minecraft:terracotta
fill 490 63 465 490 66 465 minecraft:red_terracotta
setblock 490 63 503 minecraft:red_terracotta
setblock 490 63 504 minecraft:terracotta
fill 491 63 464 491 66 464 minecraft:red_terracotta
setblock 491 63 467 minecraft:red_terracotta
setblock 491 63 503 minecraft:terracotta
fill 491 63 504 491 66 504 minecraft:red_terracotta
setblock 492 63 467 minecraft:terracotta
fill 492 63 503 492 65 503 minecraft:red_terracotta
setblock 493 63 465 minecraft:red_terracotta
setblock 493 63 466 minecraft:terracotta
fill 493 63 467 493 66 467 minecraft:red_terracotta
setblock 494 63 465 minecraft:terracotta
fill 494 63 466 494 66 466 minecraft:red_terracotta
setblock 495 63 464 minecraft:terracotta
fill 495 63 465 495 66 465 minecraft:red_terracotta
fill 495 63 467 495 64 467 minecraft:red_terracotta
setblock 495 63 504 minecraft:terracotta
fill 496 63 464 496 66 464 minecraft:red_terracotta
fill 496 63 504 496 66 504 minecraft:red_terracotta
setblock 498 63 466 minecraft:terracotta
setblock 499 63 465 minecraft:terracotta
fill 499 63 466 500 65 466 minecraft:red_terracotta
setblock 500 63 464 minecraft:terracotta
fill 500 63 465 503 63 465 minecraft:red_terracotta
setblock 500 63 504 minecraft:terracotta
fill 501 63 464 501 66 464 minecraft:red_terracotta
fill 501 63 504 501 66 504 minecraft:red_terracotta
setblock 504 63 465 minecraft:terracotta
fill 504 63 466 507 63 466 minecraft:red_terracotta
setblock 505 63 464 minecraft:terracotta
fill 505 63 465 505 66 465 minecraft:red_terracotta
setblock 505 63 503 minecraft:red_terracotta
setblock 505 63 504 minecraft:terracotta
fill 506 63 464 506 66 464 minecraft:red_terracotta
setblock 506 63 503 minecraft:terracotta
fill 506 63 504 506 66 504 minecraft:red_terracotta
fill 507 63 503 507 66 503 minecraft:red_terracotta
setblock 508 63 466 minecraft:terracotta
fill 508 63 502 508 66 502 minecraft:red_terracotta
setblock 509 63 465 minecraft:terracotta
fill 509 63 466 509 66 466 minecraft:red_terracotta
fill 509 63 468 510 63 468 minecraft:red_terracotta
setblock 510 63 464 minecraft:terracotta
fill 510 63 465 510 66 465 minecraft:red_terracotta
fill 510 63 467 510 64 467 minecraft:red_terracotta
setblock 510 63 469 minecraft:terracotta
fill 510 63 470 510 65 471 minecraft:red_terracotta
fill 510 63 482 510 63 483 minecraft:red_terracotta
setblock 510 63 484 minecraft:terracotta
fill 510 63 485 510 63 488 minecraft:red_terracotta
setblock 510 63 489 minecraft:terracotta
fill 510 63 490 510 63 493 minecraft:red_terracotta
setblock 510 63 494 minecraft:terracotta
fill 510 63 495 510 64 497 minecraft:red_terracotta
setblock 510 63 499 minecraft:terracotta
fill 510 63 500 510 66 500 minecraft:red_terracotta
setblock 510 63 504 minecraft:terracotta
fill 511 63 464 511 66 464 minecraft:red_terracotta
setblock 511 63 468 minecraft:terracotta
fill 511 63 469 511 66 469 minecraft:red_terracotta
setblock 511 63 472 minecraft:red_terracotta
setblock 511 63 473 minecraft:terracotta
fill 511 63 474 511 66 474 minecraft:red_terracotta
setblock 511 63 478 minecraft:terracotta
fill 511 63 479 511 66 479 minecraft:red_terracotta
setblock 511 63 483 minecraft:terracotta
fill 511 63 484 511 63 487 minecraft:red_terracotta
setblock 511 63 488 minecraft:terracotta
fill 511 63 489 511 63 492 minecraft:red_terracotta
setblock 511 63 493 minecraft:terracotta
fill 511 63 494 511 66 494 minecraft:red_terracotta
setblock 511 63 498 minecraft:terracotta
fill 511 63 499 511 66 499 minecraft:red_terracotta
setblock 511 63 503 minecraft:terracotta
fill 511 63 504 511 66 504 minecraft:red_terracotta
setblock 471 64 467 minecraft:terracotta
fill 471 64 468 471 67 468 minecraft:red_terracotta
setblock 471 64 472 minecraft:terracotta
fill 471 64 473 471 65 475 minecraft:red_terracotta
setblock 471 64 477 minecraft:terracotta
fill 471 64 478 471 67 478 minecraft:red_terracotta
setblock 471 64 482 minecraft:terracotta
fill 471 64 483 471 64 486 minecraft:red_terracotta
setblock 471 64 487 minecraft:terracotta
fill 471 64 488 471 67 488 minecraft:red_terracotta
setblock 471 64 492 minecraft:terracotta
fill 471 64 493 471 67 493 minecraft:red_terracotta
setblock 471 64 497 minecraft:terracotta
fill 471 64 498 471 67 498 minecraft:red_terracotta
setblock 471 64 502 minecraft:terracotta
fill 471 64 503 471 67 503 minecraft:red_terracotta
setblock 472 64 466 minecraft:terracotta
fill 472 64 467 472 67 467 minecraft:red_terracotta
setblock 472 64 470 minecraft:red_terracotta
setblock 472 64 479 minecraft:red_terracotta
setblock 472 64 481 minecraft:terracotta
fill 472 64 482 472 67 482 minecraft:red_terracotta
setblock 472 64 486 minecraft:terracotta
fill 472 64 487 472 67 487 minecraft:red_terracotta
setblock 472 64 490 minecraft:red_terracotta
setblock 472 64 491 minecraft:terracotta
fill 472 64 492 472 67 492 minecraft:red_terracotta
setblock 472 64 496 minecraft:terracotta
fill 472 64 497 472 67 497 minecraft:red_terracotta
setblock 472 64 501 minecraft:terracotta
fill 472 64 502 472 67 502 minecraft:red_terracotta
setblock 473 64 465 minecraft:terracotta
setblock 473 64 466 minecraft:red_terracotta
setblock 473 64 485 minecraft:terracotta
fill 473 64 486 473 67 486 minecraft:red_terracotta
setblock 473 64 490 minecraft:terracotta
fill 473 64 491 474 66 491 minecraft:red_terracotta
setblock 473 64 494 minecraft:red_terracotta
setblock 473 64 495 minecraft:terracotta
fill 473 64 496 473 66 496 minecraft:red_terracotta
setblock 474 64 464 minecraft:terracotta
fill 474 64 465 474 66 465 minecraft:red_terracotta
setblock 474 64 484 minecraft:terracotta
fill 474 64 485 474 65 485 minecraft:red_terracotta
setblock 474 64 489 minecraft:terracotta
fill 474 64 490 474 67 490 minecraft:red_terracotta
setblock 474 64 504 minecraft:terracotta
fill 475 64 464 475 67 464 minecraft:red_terracotta
setblock 475 64 503 minecraft:terracotta
fill 475 64 504 475 67 504 minecraft:red_terracotta
setblock 476 64 503 minecraft:red_terracotta
setblock 478 64 464 minecraft:red_terracotta
setblock 479 64 464 minecraft:terracotta
fill 480 64 464 483 64 464 minecraft:red_terracotta
setblock 484 64 464 minecraft:terracotta
fill 485 64 464 485 66 465 minecraft:red_terracotta
setblock 487 64 466 minecraft:terracotta
setblock 488 64 465 minecraft:terracotta
fill 488 64 466 488 67 466 minecraft:red_terracotta
setblock 489 64 464 minecraft:terracotta
fill 489 64 465 489 67 465 minecraft:red_terracotta
fill 489 64 467 490 64 467 minecraft:red_terracotta
setblock 489 64 504 minecraft:terracotta
fill 490 64 464 490 67 464 minecraft:red_terracotta
setblock 490 64 503 minecraft:terracotta
fill 490 64 504 490 67 504 minecraft:red_terracotta
setblock 491 64 466 minecraft:red_terracotta
setblock 491 64 467 minecraft:terracotta
fill 491 64 503 491 65 503 minecraft:red_terracotta
setblock 492 64 466 minecraft:terracotta
fill 492 64 467 492 67 467 minecraft:red_terracotta
setblock 493 64 465 minecraft:terracotta
fill 493 64 466 493 67 466 minecraft:red_terracotta
setblock 494 64 464 minecraft:terracotta
fill 494 64 465 494 67 465 minecraft:red_terracotta
setblock 494 64 504 minecraft:terracotta
fill 495 64 464 495 67 464 minecraft:red_terracotta
fill 495 64 504 495 67 504 minecraft:red_terracotta
setblock 496 64 467 minecraft:terracotta
setblock 497 64 466 minecraft:terracotta
setblock 498 64 465 minecraft:terracotta
fill 498 64 466 498 67 466 minecraft:red_terracotta
setblock 499 64 464 minecraft:terracotta
fill 499 64 465 502 64 465 minecraft:red_terracotta
setblock 499 64 504 minecraft:terracotta
fill 500 64 464 500 67 464 minecraft:red_terracotta
fill 500 64 504 500 67 504 minecraft:red_terracotta
setblock 501 64 466 minecraft:red_terracotta
setblock 502 64 466 minecraft:terracotta
setblock 503 64 465 minecraft:terracotta
fill 503 64 466 506 64 466 minecraft:red_terracotta
setblock 504 64 464 minecraft:terracotta
fill 504 64 465 504 67 465 minecraft:red_terracotta
setblock 504 64 504 minecraft:terracotta
fill 505 64 464 505 67 464 minecraft:red_terracotta
setblock 505 64 503 minecraft:terracotta
fill 505 64 504 505 67 504 minecraft:red_terracotta
fill 506 64 503 506 67 503 minecraft:red_terracotta
setblock 507 64 466 minecraft:terracotta
setblock 508 64 465 minecraft:terracotta
fill 508 64 466 508 67 466 minecraft:red_terracotta
setblock 509 64 464 minecraft:terracotta
fill 509 64 465 509 67 465 minecraft:red_terracotta
setblock 509 64 468 minecraft:red_terracotta
setblock 509 64 469 minecraft:terracotta
fill 509 64 486 509 64 488 minecraft:red_terracotta
setblock 509 64 489 minecraft:terracotta
fill 509 64 490 511 65 490 minecraft:red_terracotta
fill 509 64 501 509 66 501 minecraft:red_terracotta
setblock 509 64 504 minecraft:terracotta
fill 510 64 464 510 67 464 minecraft:red_terracotta
setblock 510 64 468 minecraft:terracotta
fill 510 64 469 510 67 469 minecraft:red_terracotta
setblock 510 64 472 minecraft:red_terracotta
setblock 510 64 482 minecraft:red_terracotta
setblock 510 64 483 minecraft:terracotta
fill 510 64 484 510 64 487 minecraft:red_terracotta
setblock 510 64 488 minecraft:terracotta
fill 510 64 489 511 66 489 minecraft:red_terracotta
fill 510 64 491 510 64 492 minecraft:red_terracotta
setblock 510 64 493 minecraft:terracotta
fill 510 64 494 510 67 494 minecraft:red_terracotta
setblock 510 64 498 minecraft:terracotta
fill 510 64 499 510 67 499 minecraft:red_terracotta
setblock 510 64 503 minecraft:terracotta
fill 510 64 504 510 67 504 minecraft:red_terracotta
setblock 511 64 467 minecraft:terracotta
fill 511 64 468 511 67 468 minecraft:red_terracotta
setblock 511 64 472 minecraft:terracotta
fill 511 64 473 511 67 473 minecraft:red_terracotta
fill 511 64 475 511 64 476 minecraft:red_terracotta
setblock 511 64 477 minecraft:terracotta
fill 511 64 478 511 66 478 minecraft:red_terracotta
setblock 511 64 482 minecraft:terracotta
fill 511 64 483 511 64 486 minecraft:red_terracotta
setblock 511 64 487 minecraft:terracotta
fill 511 64 488 511 67 488 minecraft:red_terracotta
setblock 511 64 491 minecraft:red_terracotta
setblock 511 64 492 minecraft:terracotta
fill 511 64 493 511 67 493 minecraft:red_terracotta
setblock 511 64 497 minecraft:terracotta
fill 511 64 498 511 67 498 minecraft:red_terracotta
setblock 511 64 502 minecraft:terracotta
fill 511 64 503 511 67 503 minecraft:red_terracotta
setblock 471 65 466 minecraft:terracotta
fill 471 65 467 471 68 467 minecraft:red_terracotta
setblock 471 65 470 minecraft:red_terracotta
setblock 471 65 471 minecraft:terracotta
fill 471 65 472 471 68 472 minecraft:red_terracotta
setblock 471 65 476 minecraft:terracotta
fill 471 65 477 471 68 477 minecraft:red_terracotta
setblock 471 65 481 minecraft:terracotta
fill 471 65 482 471 65 485 minecraft:red_terracotta
setblock 471 65 486 minecraft:terracotta
fill 471 65 487 471 68 487 minecraft:red_terracotta
setblock 471 65 491 minecraft:terracotta
fill 471 65 492 471 68 492 minecraft:red_terracotta
setblock 471 65 496 minecraft:terracotta
fill 471 65 497 471 68 497 minecraft:red_terracotta
setblock 471 65 501 minecraft:terracotta
fill 471 65 502 471 68 502 minecraft:red_terracotta
setblock 472 65 465 minecraft:terracotta
fill 472 65 466 472 68 466 minecraft:red_terracotta
setblock 472 65 470 minecraft:terracotta
fill 472 65 471 472 68 471 minecraft:red_terracotta
setblock 472 65 480 minecraft:terracotta
fill 472 65 481 472 67 481 minecraft:red_terracotta
setblock 472 65 485 minecraft:terracotta
fill 472 65 486 472 68 486 minecraft:red_terracotta
setblock 472 65 490 minecraft:terracotta
fill 472 65 491 472 68 491 minecraft:red_terracotta
setblock 472 65 495 minecraft:terracotta
fill 472 65 496 472 68 496 minecraft:red_terracotta
setblock 472 65 500 minecraft:terracotta
fill 472 65 501 472 67 501 minecraft:red_terracotta
setblock 473 65 464 minecraft:terracotta
fill 473 65 465 473 67 465 minecraft:red_terracotta
setblock 473 65 484 minecraft:terracotta
fill 473 65 485 473 68 485 minecraft:red_terracotta
setblock 473 65 488 minecraft:red_terracotta
setblock 473 65 489 minecraft:terracotta
fill 473 65 490 473 68 490 minecraft:red_terracotta
setblock 473 65 494 minecraft:terracotta
fill 473 65 495 473 68 495 minecraft:red_terracotta
setblock 473 65 504 minecraft:terracotta
fill 474 65 464 474 68 464 minecraft:red_terracotta
setblock 474 65 488 minecraft:terracotta
fill 474 65 489 474 67 489 minecraft:red_terracotta
setblock 474 65 492 minecraft:red_terracotta
setblock 474 65 503 minecraft:terracotta
fill 474 65 504 474 67 504 minecraft:red_terracotta
setblock 475 65 503 minecraft:red_terracotta
setblock 478 65 464 minecraft:terracotta
setblock 479 65 464 minecraft:red_terracotta
fill 480 65 464 480 77 464 minecraft:magma_block
fill 481 65 464 482 65 464 minecraft:red_terracotta
setblock 483 65 464 minecraft:terracotta
fill 484 65 464 484 67 465 minecraft:red_terracotta
setblock 486 65 466 minecraft:terracotta
setblock 487 65 464 minecraft:red_terracotta
setblock 487 65 465 minecraft:terracotta
fill 487 65 466 487 68 466 minecraft:red_terracotta
fill 487 65 473 487 66 473 minecraft:orange_concrete
setblock 488 65 464 minecraft:terracotta
fill 488 65 465 488 68 465 minecraft:red_terracotta
fill 488 65 467 489 65 467 minecraft:red_terracotta
setblock 488 65 504 minecraft:terracotta
fill 489 65 464 489 68 464 minecraft:red_terracotta
fill 489 65 504 489 68 504 minecraft:red_terracotta
setblock 490 65 467 minecraft:terracotta
setblock 491 65 466 minecraft:terracotta
fill 491 65 467 491 68 467 minecraft:red_terracotta
setblock 492 65 465 minecraft:terracotta
fill 492 65 466 492 68 466 minecraft:red_terracotta
setblock 493 65 464 minecraft:terracotta
fill 493 65 465 493 68 465 minecraft:red_terracotta
setblock 493 65 504 minecraft:terracotta
fill 494 65 464 494 68 464 minecraft:red_terracotta
fill 494 65 504 494 68 504 minecraft:red_terracotta
setblock 495 65 467 minecraft:terracotta
setblock 496 65 466 minecraft:terracotta
fill 496 65 467 496 66 467 minecraft:red_terracotta
setblock 497 65 465 minecraft:terracotta
fill 497 65 466 497 67 466 minecraft:red_terracotta
setblock 498 65 464 minecraft:terracotta
fill 498 65 465 501 65 465 minecraft:red_terracotta
setblock 498 65 504 minecraft:terracotta
fill 499 65 464 499 68 464 minecraft:red_terracotta
fill 499 65 504 499 66 504 minecraft:red_terracotta
setblock 501 65 466 minecraft:terracotta
setblock 502 65 465 minecraft:terracotta
fill 502 65 466 505 65 466 minecraft:red_terracotta
setblock 503 65 464 minecraft:terracotta
fill 503 65 465 503 68 465 minecraft:red_terracotta
setblock 503 65 504 minecraft:terracotta
fill 504 65 464 504 68 464 minecraft:red_terracotta
fill 504 65 504 504 68 504 minecraft:red_terracotta
fill 505 65 503 505 68 503 minecraft:red_terracotta
setblock 506 65 466 minecraft:terracotta
setblock 507 65 465 minecraft:terracotta
fill 507 65 466 507 67 467 minecraft:red_terracotta
setblock 508 65 464 minecraft:terracotta
fill 508 65 465 508 68 465 minecraft:red_terracotta
fill 508 65 467 508 66 467 minecraft:red_terracotta
setblock 508 65 504 minecraft:terracotta
fill 509 65 464 509 68 464 minecraft:red_terracotta
setblock 509 65 468 minecraft:terracotta
fill 509 65 469 509 67 470 minecraft:red_terracotta
fill 509 65 486 509 65 487 minecraft:red_terracotta
setblock 509 65 488 minecraft:terracotta
fill 509 65 489 509 68 489 minecraft:red_terracotta
fill 509 65 491 509 65 492 minecraft:red_terracotta
setblock 509 65 493 minecraft:terracotta
setblock 509 65 503 minecraft:terracotta
fill 509 65 504 509 68 504 minecraft:red_terracotta
setblock 510 65 467 minecraft:terracotta
fill 510 65 468 510 68 468 minecraft:red_terracotta
setblock 510 65 472 minecraft:terracotta
setblock 510 65 482 minecraft:terracotta
fill 510 65 483 510 65 486 minecraft:red_terracotta
setblock 510 65 487 minecraft:terracotta
fill 510 65 488 510 68 488 minecraft:red_terracotta
setblock 510 65 491 minecraft:red_terracotta
setblock 510 65 492 minecraft:terracotta
fill 510 65 493 510 68 493 minecraft:red_terracotta
fill 510 65 495 510 65 496 minecraft:red_terracotta
setblock 510 65 497 minecraft:terracotta
fill 510 65 498 510 68 498 minecraft:red_terracotta
setblock 510 65 502 minecraft:terracotta
fill 510 65 503 510 68 503 minecraft:red_terracotta
setblock 511 65 466 minecraft:terracotta
fill 511 65 467 511 68 467 minecraft:red_terracotta
setblock 511 65 471 minecraft:terracotta
fill 511 65 472 511 68 472 minecraft:red_terracotta
setblock 511 65 475 minecraft:red_terracotta
setblock 511 65 476 minecraft:terracotta
fill 511 65 477 511 66 477 minecraft:red_terracotta
setblock 511 65 481 minecraft:terracotta
fill 511 65 482 511 65 485 minecraft:red_terracotta
setblock 511 65 486 minecraft:terracotta
fill 511 65 487 511 68 487 minecraft:red_terracotta
setblock 511 65 491 minecraft:terracotta
fill 511 65 492 511 68 492 minecraft:red_terracotta
setblock 511 65 496 minecraft:terracotta
fill 511 65 497 511 68 497 minecraft:red_terracotta
setblock 511 65 501 minecraft:terracotta
fill 511 65 502 511 68 502 minecraft:red_terracotta
setblock 471 66 465 minecraft:terracotta
fill 471 66 466 471 69 466 minecraft:red_terracotta
setblock 471 66 469 minecraft:red_terracotta
setblock 471 66 470 minecraft:terracotta
fill 471 66 471 471 69 471 minecraft:red_terracotta
fill 471 66 473 471 66 474 minecraft:red_terracotta
setblock 471 66 475 minecraft:terracotta
fill 471 66 476 471 69 476 minecraft:red_terracotta
setblock 471 66 480 minecraft:terracotta
fill 471 66 481 471 66 484 minecraft:red_terracotta
setblock 471 66 485 minecraft:terracotta
fill 471 66 486 471 69 486 minecraft:red_terracotta
setblock 471 66 490 minecraft:terracotta
fill 471 66 491 471 69 491 minecraft:red_terracotta
setblock 471 66 495 minecraft:terracotta
fill 471 66 496 471 69 496 minecraft:red_terracotta
setblock 471 66 500 minecraft:terracotta
fill 471 66 501 471 69 501 minecraft:red_terracotta
setblock 472 66 464 minecraft:terracotta
fill 472 66 465 472 68 465 minecraft:red_terracotta
setblock 472 66 469 minecraft:terracotta
fill 472 66 470 472 69 470 minecraft:red_terracotta
fill 472 66 472 472 67 472 minecraft:red_terracotta
setblock 472 66 480 minecraft:red_terracotta
setblock 472 66 484 minecraft:terracotta
fill 472 66 485 472 69 485 minecraft:red_terracotta
setblock 472 66 489 minecraft:terracotta
fill 472 66 490 472 69 490 minecraft:red_terracotta
setblock 472 66 494 minecraft:terracotta
fill 472 66 495 472 69 495 minecraft:red_terracotta
setblock 472 66 499 minecraft:terracotta
fill 472 66 500 472 67 500 minecraft:red_terracotta
setblock 472 66 504 minecraft:terracotta
fill 473 66 464 473 68 464 minecraft:red_terracotta
setblock 473 66 483 minecraft:terracotta
fill 473 66 484 473 67 484 minecraft:red_terracotta
setblock 473 66 488 minecraft:terracotta
fill 473 66 489 473 69 489 minecraft:red_terracotta
setblock 473 66 493 minecraft:terracotta
fill 473 66 494 473 69 494 minecraft:red_terracotta
setblock 473 66 503 minecraft:terracotta
fill 473 66 504 473 68 504 minecraft:red_terracotta
setblock 474 66 487 minecraft:terracotta
fill 474 66 488 474 67 488 minecraft:red_terracotta
setblock 474 66 492 minecraft:terracotta
setblock 477 66 464 minecraft:terracotta
fill 481 66 464 481 76 464 minecraft:shroomlight
setblock 482 66 464 minecraft:terracotta
fill 483 66 464 483 69 464 minecraft:red_terracotta
setblock 486 66 464 minecraft:red_terracotta
setblock 486 66 465 minecraft:terracotta
fill 486 66 466 486 69 466 minecraft:red_terracotta
setblock 487 66 464 minecraft:terracotta
fill 487 66 465 487 69 465 minecraft:red_terracotta
setblock 487 66 504 minecraft:terracotta
fill 488 66 464 488 69 464 minecraft:red_terracotta
setblock 488 66 467 minecraft:red_terracotta
fill 488 66 504 488 69 504 minecraft:red_terracotta
setblock 489 66 467 minecraft:terracotta
setblock 490 66 466 minecraft:terracotta
fill 490 66 467 490 69 467 minecraft:red_terracotta
setblock 491 66 465 minecraft:terracotta
fill 491 66 466 491 69 466 minecraft:red_terracotta
setblock 492 66 464 minecraft:terracotta
fill 492 66 465 492 69 465 minecraft:red_terracotta
setblock 492 66 504 minecraft:terracotta
fill 493 66 464 493 69 464 minecraft:red_terracotta
fill 493 66 504 493 68 504 minecraft:red_terracotta
setblock 494 66 467 minecraft:terracotta
setblock 495 66 466 minecraft:terracotta
fill 495 66 467 495 67 467 minecraft:red_terracotta
setblock 496 66 465 minecraft:terracotta
fill 496 66 466 496 68 466 minecraft:red_terracotta
setblock 497 66 464 minecraft:terracotta
fill 497 66 465 500 66 465 minecraft:red_terracotta
setblock 497 66 504 minecraft:terracotta
fill 498 66 464 498 69 464 minecraft:red_terracotta
setblock 498 66 504 minecraft:red_terracotta
setblock 499 66 466 minecraft:red_terracotta
setblock 500 66 466 minecraft:terracotta
setblock 501 66 465 minecraft:terracotta
fill 501 66 466 504 66 466 minecraft:red_terracotta
setblock 502 66 464 minecraft:terracotta
fill 502 66 465 502 69 465 minecraft:red_terracotta
setblock 502 66 504 minecraft:terracotta
fill 503 66 464 503 69 464 minecraft:red_terracotta
fill 503 66 504 503 69 504 minecraft:red_terracotta
setblock 505 66 466 minecraft:terracotta
setblock 506 66 465 minecraft:terracotta
fill 506 66 466 506 69 466 minecraft:red_terracotta
setblock 507 66 464 minecraft:terracotta
fill 507 66 465 507 69 465 minecraft:red_terracotta
setblock 507 66 504 minecraft:terracotta
fill 508 66 464 508 69 464 minecraft:red_terracotta
setblock 508 66 468 minecraft:terracotta
setblock 508 66 503 minecraft:terracotta
fill 508 66 504 508 69 504 minecraft:red_terracotta
setblock 509 66 467 minecraft:terracotta
fill 509 66 468 509 69 468 minecraft:red_terracotta
setblock 509 66 486 minecraft:red_terracotta
setblock 509 66 487 minecraft:terracotta
fill 509 66 488 509 69 488 minecraft:red_terracotta
fill 509 66 490 509 66 491 minecraft:red_terracotta
setblock 509 66 492 minecraft:terracotta
fill 509 66 493 509 67 495 minecraft:red_terracotta
setblock 509 66 502 minecraft:terracotta
fill 509 66 503 509 69 503 minecraft:red_terracotta
setblock 510 66 466 minecraft:terracotta
fill 510 66 467 510 69 467 minecraft:red_terracotta
setblock 510 66 470 minecraft:red_terracotta
setblock 510 66 471 minecraft:terracotta
fill 510 66 472 510 68 473 minecraft:red_terracotta
fill 510 66 483 510 66 485 minecraft:red_terracotta
setblock 510 66 486 minecraft:terracotta
fill 510 66 487 510 69 487 minecraft:red_terracotta
setblock 510 66 490 minecraft:red_terracotta
setblock 510 66 491 minecraft:terracotta
fill 510 66 492 510 69 492 minecraft:red_terracotta
setblock 510 66 495 minecraft:red_terracotta
setblock 510 66 496 minecraft:terracotta
fill 510 66 497 510 69 497 minecraft:red_terracotta
setblock 510 66 501 minecraft:terracotta
fill 510 66 502 510 69 502 minecraft:red_terracotta
setblock 511 66 465 minecraft:terracotta
fill 511 66 466 511 69 466 minecraft:red_terracotta
setblock 511 66 470 minecraft:terracotta
fill 511 66 471 511 69 471 minecraft:red_terracotta
setblock 511 66 475 minecraft:terracotta
fill 511 66 476 511 67 476 minecraft:red_terracotta
setblock 511 66 480 minecraft:terracotta
fill 511 66 481 511 66 484 minecraft:red_terracotta
setblock 511 66 485 minecraft:terracotta
fill 511 66 486 511 69 486 minecraft:red_terracotta
setblock 511 66 490 minecraft:terracotta
fill 511 66 491 511 69 491 minecraft:red_terracotta
setblock 511 66 495 minecraft:terracotta
fill 511 66 496 511 69 496 minecraft:red_terracotta
setblock 511 66 500 minecraft:terracotta
fill 511 66 501 511 69 501 minecraft:red_terracotta
setblock 471 67 464 minecraft:terracotta
fill 471 67 465 471 70 465 minecraft:red_terracotta
setblock 471 67 469 minecraft:terracotta
fill 471 67 470 471 70 470 minecraft:red_terracotta
setblock 471 67 473 minecraft:red_terracotta
setblock 471 67 474 minecraft:terracotta
fill 471 67 475 471 70 475 minecraft:red_terracotta
setblock 471 67 479 minecraft:terracotta
fill 471 67 480 471 67 483 minecraft:red_terracotta
setblock 471 67 484 minecraft:terracotta
fill 471 67 485 471 70 485 minecraft:red_terracotta
setblock 471 67 489 minecraft:terracotta
fill 471 67 490 471 70 490 minecraft:red_terracotta
setblock 471 67 494 minecraft:terracotta
fill 471 67 495 471 70 495 minecraft:red_terracotta
setblock 471 67 499 minecraft:terracotta
fill 471 67 500 471 70 500 minecraft:red_terracotta
setblock 471 67 504 minecraft:terracotta
fill 472 67 464 472 69 464 minecraft:red_terracotta
setblock 472 67 468 minecraft:terracotta
fill 472 67 469 472 69 469 minecraft:red_terracotta
setblock 472 67 483 minecraft:terracotta
fill 472 67 484 472 69 484 minecraft:red_terracotta
setblock 472 67 488 minecraft:terracotta
fill 472 67 489 472 70 489 minecraft:red_terracotta
setblock 472 67 493 minecraft:terracotta
fill 472 67 494 472 70 494 minecraft:red_terracotta
setblock 472 67 498 minecraft:terracotta
fill 472 67 499 472 68 499 minecraft:red_terracotta
setblock 472 67 503 minecraft:terracotta
fill 472 67 504 472 69 504 minecraft:red_terracotta
setblock 473 67 487 minecraft:terracotta
fill 473 67 488 473 70 488 minecraft:red_terracotta
setblock 473 67 491 minecraft:red_terracotta
setblock 473 67 492 minecraft:terracotta
fill 473 67 493 473 70 493 minecraft:red_terracotta
setblock 474 67 487 minecraft:red_terracotta
setblock 474 67 491 minecraft:terracotta
setblock 476 67 464 minecraft:terracotta
setblock 482 67 464 minecraft:red_terracotta
setblock 485 67 464 minecraft:red_terracotta
setblock 485 67 465 minecraft:terracotta
setblock 485 67 466 minecraft:red_terracotta
setblock 486 67 464 minecraft:terracotta
fill 486 67 465 486 70 465 minecraft:red_terracotta
setblock 486 67 504 minecraft:terracotta
fill 487 67 464 487 70 464 minecraft:red_terracotta
setblock 487 67 467 minecraft:red_terracotta
fill 487 67 504 487 68 504 minecraft:red_terracotta
setblock 488 67 467 minecraft:terracotta
setblock 489 67 466 minecraft:terracotta
fill 489 67 467 489 70 467 minecraft:red_terracotta
setblock 490 67 465 minecraft:terracotta
fill 490 67 466 490 70 466 minecraft:red_terracotta
setblock 491 67 464 minecraft:terracotta
fill 491 67 465 491 70 465 minecraft:red_terracotta
setblock 491 67 504 minecraft:terracotta
fill 492 67 464 492 70 464 minecraft:red_terracotta
fill 492 67 504 492 68 504 minecraft:red_terracotta
setblock 493 67 467 minecraft:terracotta
setblock 494 67 466 minecraft:terracotta
setblock 494 67 467 minecraft:red_terracotta
setblock 495 67 465 minecraft:terracotta
fill 495 67 466 495 68 466 minecraft:red_terracotta
setblock 496 67 464 minecraft:terracotta
fill 496 67 465 499 67 465 minecraft:red_terracotta
setblock 496 67 504 minecraft:terracotta
fill 497 67 464 497 70 464 minecraft:red_terracotta
setblock 497 67 504 minecraft:red_terracotta
setblock 499 67 466 minecraft:terracotta
setblock 500 67 465 minecraft:terracotta
setblock 501 67 464 minecraft:terracotta
fill 501 67 465 501 67 466 minecraft:red_terracotta
setblock 501 67 504 minecraft:terracotta
fill 502 67 464 502 70 464 minecraft:red_terracotta
fill 502 67 466 503 67 466 minecraft:red_terracotta
fill 502 67 504 502 69 504 minecraft:red_terracotta
setblock 504 67 466 minecraft:terracotta
setblock 505 67 465 minecraft:terracotta
fill 505 67 466 505 69 466 minecraft:red_terracotta
setblock 506 67 464 minecraft:terracotta
fill 506 67 465 506 70 465 minecraft:red_terracotta
setblock 506 67 504 minecraft:terracotta
fill 507 67 464 507 70 464 minecraft:red_terracotta
setblock 507 67 503 minecraft:terracotta
fill 507 67 504 507 70 504 minecraft:red_terracotta
setblock 508 67 467 minecraft:terracotta
setblock 508 67 502 minecraft:terracotta
fill 508 67 503 508 70 503 minecraft:red_terracotta
setblock 509 67 466 minecraft:terracotta
fill 509 67 467 509 69 467 minecraft:red_terracotta
setblock 509 67 471 minecraft:terracotta
setblock 509 67 486 minecraft:terracotta
fill 509 67 487 509 68 487 minecraft:red_terracotta
setblock 509 67 490 minecraft:red_terracotta
setblock 509 67 491 minecraft:terracotta
fill 509 67 492 509 70 492 minecraft:red_terracotta
setblock 509 67 496 minecraft:terracotta
fill 509 67 497 509 70 497 minecraft:red_terracotta
setblock 509 67 501 minecraft:terracotta
setblock 509 67 502 minecraft:red_terracotta
setblock 510 67 465 minecraft:terracotta
fill 510 67 466 510 70 466 minecraft:red_terracotta
setblock 510 67 470 minecraft:terracotta
fill 510 67 471 510 70 471 minecraft:red_terracotta
fill 510 67 483 510 67 484 minecraft:red_terracotta
setblock 510 67 485 minecraft:terracotta
fill 510 67 486 510 70 486 minecraft:red_terracotta
setblock 510 67 489 minecraft:red_terracotta
setblock 510 67 490 minecraft:terracotta
fill 510 67 491 510 70 491 minecraft:red_terracotta
setblock 510 67 495 minecraft:terracotta
fill 510 67 496 510 70 496 minecraft:red_terracotta
setblock 510 67 500 minecraft:terracotta
fill 510 67 501 510 70 501 minecraft:red_terracotta
setblock 511 67 464 minecraft:terracotta
fill 511 67 465 511 70 465 minecraft:red_terracotta
setblock 511 67 469 minecraft:terracotta
fill 511 67 470 511 70 470 minecraft:red_terracotta
setblock 511 67 474 minecraft:terracotta
fill 511 67 475 511 69 475 minecraft:red_terracotta
fill 511 67 480 511 67 483 minecraft:red_terracotta
setblock 511 67 484 minecraft:terracotta
fill 511 67 485 511 70 485 minecraft:red_terracotta
setblock 511 67 489 minecraft:terracotta
fill 511 67 490 511 70 490 minecraft:red_terracotta
setblock 511 67 494 minecraft:terracotta
fill 511 67 495 511 70 495 minecraft:red_terracotta
setblock 511 67 499 minecraft:terracotta
fill 511 67 500 511 70 500 minecraft:red_terracotta
setblock 511 67 504 minecraft:terracotta
fill 471 68 464 471 69 464 minecraft:red_terracotta
setblock 471 68 468 minecraft:terracotta
fill 471 68 469 471 71 469 minecraft:red_terracotta
setblock 471 68 473 minecraft:terracotta
fill 471 68 474 471 71 474 minecraft:red_terracotta
setblock 471 68 478 minecraft:terracotta
fill 471 68 479 471 68 482 minecraft:red_terracotta
setblock 471 68 483 minecraft:terracotta
fill 471 68 484 471 71 484 minecraft:red_terracotta
setblock 471 68 488 minecraft:terracotta
fill 471 68 489 471 71 489 minecraft:red_terracotta
setblock 471 68 493 minecraft:terracotta
fill 471 68 494 471 71 494 minecraft:red_terracotta
setblock 471 68 498 minecraft:terracotta
fill 471 68 499 471 71 499 minecraft:red_terracotta
setblock 471 68 503 minecraft:terracotta
fill 471 68 504 471 69 504 minecraft:red_terracotta
setblock 472 68 467 minecraft:terracotta
fill 472 68 468 472 69 468 minecraft:red_terracotta
setblock 472 68 482 minecraft:terracotta
fill 472 68 483 472 69 483 minecraft:red_terracotta
setblock 472 68 487 minecraft:terracotta
fill 472 68 488 472 71 488 minecraft:red_terracotta
setblock 472 68 492 minecraft:terracotta
fill 472 68 493 472 71 493 minecraft:red_terracotta
setblock 472 68 497 minecraft:terracotta
fill 472 68 498 472 69 498 minecraft:red_terracotta
setblock 473 68 486 minecraft:terracotta
fill 473 68 487 473 69 487 minecraft:red_terracotta
setblock 473 68 491 minecraft:terracotta
fill 473 68 492 473 70 492 minecraft:red_terracotta
fill 482 68 464 482 75 464 minecraft:magma_block
setblock 484 68 464 minecraft:red_terracotta
setblock 484 68 465 minecraft:terracotta
setblock 485 68 464 minecraft:terracotta
fill 485 68 465 485 71 465 minecraft:red_terracotta
fill 486 68 464 486 71 464 minecraft:red_terracotta
setblock 487 68 467 minecraft:terracotta
setblock 488 68 466 minecraft:terracotta
fill 488 68 467 488 69 467 minecraft:red_terracotta
setblock 489 68 465 minecraft:terracotta
fill 489 68 466 489 71 466 minecraft:red_terracotta
setblock 490 68 464 minecraft:terracotta
fill 490 68 465 490 71 465 minecraft:red_terracotta
setblock 490 68 504 minecraft:terracotta
fill 491 68 464 491 71 464 minecraft:red_terracotta
fill 491 68 504 491 69 504 minecraft:red_terracotta
setblock 492 68 467 minecraft:terracotta
setblock 493 68 466 minecraft:terracotta
setblock 493 68 467 minecraft:red_terracotta
setblock 494 68 465 minecraft:terracotta
fill 494 68 466 494 69 466 minecraft:red_terracotta
setblock 495 68 464 minecraft:terracotta
fill 495 68 465 498 68 465 minecraft:red_terracotta
fill 496 68 464 496 71 464 minecraft:red_terracotta
setblock 499 68 465 minecraft:terracotta
setblock 500 68 464 minecraft:terracotta
fill 500 68 465 501 69 465 minecraft:red_terracotta
fill 501 68 464 501 71 464 minecraft:red_terracotta
setblock 503 68 466 minecraft:terracotta
setblock 504 68 465 minecraft:terracotta
fill 504 68 466 504 69 466 minecraft:red_terracotta
setblock 505 68 464 minecraft:terracotta
fill 505 68 465 505 71 465 minecraft:red_terracotta
setblock 505 68 504 minecraft:terracotta
fill 506 68 464 506 71 464 minecraft:red_terracotta
setblock 506 68 503 minecraft:terracotta
fill 506 68 504 506 71 504 minecraft:red_terracotta
setblock 507 68 466 minecraft:red_terracotta
fill 507 68 503 507 71 503 minecraft:red_terracotta
setblock 508 68 466 minecraft:terracotta
setblock 509 68 465 minecraft:terracotta
fill 509 68 466 509 69 466 minecraft:red_terracotta
setblock 509 68 469 minecraft:red_terracotta
setblock 509 68 470 minecraft:terracotta
setblock 509 68 490 minecraft:terracotta
fill 509 68 491 509 71 491 minecraft:red_terracotta
fill 509 68 493 509 68 494 minecraft:red_terracotta
setblock 509 68 495 minecraft:terracotta
fill 509 68 496 509 71 496 minecraft:red_terracotta
setblock 510 68 464 minecraft:terracotta
fill 510 68 465 510 70 465 minecraft:red_terracotta
setblock 510 68 469 minecraft:terracotta
fill 510 68 470 510 71 470 minecraft:red_terracotta
setblock 510 68 484 minecraft:terracotta
fill 510 68 485 510 69 485 minecraft:red_terracotta
setblock 510 68 489 minecraft:terracotta
fill 510 68 490 510 71 490 minecraft:red_terracotta
setblock 510 68 494 minecraft:terracotta
fill 510 68 495 510 71 495 minecraft:red_terracotta
setblock 510 68 499 minecraft:terracotta
fill 510 68 500 510 71 500 minecraft:red_terracotta
setblock 510 68 504 minecraft:terracotta
fill 511 68 464 511 71 464 minecraft:red_terracotta
setblock 511 68 468 minecraft:terracotta
fill 511 68 469 511 71 469 minecraft:red_terracotta
setblock 511 68 473 minecraft:terracotta
fill 511 68 474 511 71 474 minecraft:red_terracotta
setblock 511 68 482 minecraft:red_terracotta
setblock 511 68 483 minecraft:terracotta
fill 511 68 484 511 70 484 minecraft:red_terracotta
setblock 511 68 488 minecraft:terracotta
fill 511 68 489 511 71 489 minecraft:red_terracotta
setblock 511 68 493 minecraft:terracotta
fill 511 68 494 511 71 494 minecraft:red_terracotta
setblock 511 68 498 minecraft:terracotta
fill 511 68 499 511 71 499 minecraft:red_terracotta
setblock 511 68 503 minecraft:terracotta
fill 511 68 504 511 71 504 minecraft:red_terracotta
setblock 471 69 467 minecraft:terracotta
fill 471 69 468 471 72 468 minecraft:red_terracotta
setblock 471 69 472 minecraft:terracotta
fill 471 69 473 471 72 473 minecraft:red_terracotta
setblock 471 69 477 minecraft:terracotta
fill 471 69 478 471 69 481 minecraft:red_terracotta
setblock 471 69 482 minecraft:terracotta
fill 471 69 483 471 72 483 minecraft:red_terracotta
setblock 471 69 487 minecraft:terracotta
fill 471 69 488 471 72 488 minecraft:red_terracotta
setblock 471 69 492 minecraft:terracotta
fill 471 69 493 471 72 493 minecraft:red_terracotta
setblock 471 69 497 minecraft:terracotta
fill 471 69 498 471 72 498 minecraft:red_terracotta
setblock 471 69 502 minecraft:terracotta
setblock 471 69 503 minecraft:red_terracotta
setblock 472 69 486 minecraft:terracotta
fill 472 69 487 472 72 487 minecraft:red_terracotta
setblock 472 69 491 minecraft:terracotta
fill 472 69 492 472 72 492 minecraft:red_terracotta
setblock 472 69 496 minecraft:terracotta
fill 472 69 497 472 70 497 minecraft:red_terracotta
setblock 473 69 466 minecraft:light[level=14]
setblock 473 69 474 minecraft:light[level=14]
setblock 473 69 482 minecraft:light[level=14]
setblock 473 69 490 minecraft:terracotta
fill 473 69 491 473 71 491 minecraft:red_terracotta
setblock 473 69 498 minecraft:light[level=14]
setblock 481 69 466 minecraft:light[level=14]
setblock 481 69 474 minecraft:light[level=14]
setblock 481 69 482 minecraft:light[level=14]
setblock 481 69 490 minecraft:light[level=14]
setblock 484 69 464 minecraft:terracotta
setblock 484 69 465 minecraft:red_terracotta
fill 485 69 464 485 72 464 minecraft:red_terracotta
setblock 487 69 466 minecraft:terracotta
setblock 488 69 465 minecraft:terracotta
fill 488 69 466 488 71 466 minecraft:red_terracotta
setblock 489 69 464 minecraft:terracotta
fill 489 69 465 489 72 465 minecraft:red_terracotta
setblock 489 69 490 minecraft:light[level=14]
setblock 489 69 498 minecraft:light[level=14]
setblock 489 69 504 minecraft:terracotta
fill 490 69 464 490 72 464 minecraft:red_terracotta
setblock 490 69 504 minecraft:red_terracotta
setblock 491 69 467 minecraft:terracotta
setblock 492 69 466 minecraft:terracotta
setblock 492 69 467 minecraft:red_terracotta
setblock 493 69 465 minecraft:terracotta
setblock 493 69 466 minecraft:red_terracotta
setblock 494 69 464 minecraft:terracotta
fill 494 69 465 497 69 465 minecraft:red_terracotta
fill 495 69 464 495 71 464 minecraft:red_terracotta
setblock 497 69 466 minecraft:light[level=14]
setblock 497 69 474 minecraft:light[level=14]
setblock 497 69 482 minecraft:light[level=14]
setblock 497 69 490 minecraft:light[level=14]
setblock 498 69 465 minecraft:terracotta
setblock 499 69 464 minecraft:terracotta
setblock 499 69 465 minecraft:red_terracotta
fill 500 69 464 500 71 464 minecraft:red_terracotta
setblock 503 69 465 minecraft:terracotta
setblock 504 69 464 minecraft:terracotta
fill 504 69 465 504 72 465 minecraft:red_terracotta
setblock 504 69 504 minecraft:terracotta
fill 505 69 464 505 72 464 minecraft:red_terracotta
setblock 505 69 474 minecraft:light[level=14]
setblock 505 69 482 minecraft:light[level=14]
setblock 505 69 490 minecraft:light[level=14]
setblock 505 69 498 minecraft:light[level=14]
setblock 505 69 503 minecraft:terracotta
fill 505 69 504 505 72 504 minecraft:red_terracotta
fill 506 69 503 506 72 503 minecraft:red_terracotta
setblock 507 69 466 minecraft:terracotta
setblock 508 69 465 minecraft:terracotta
fill 508 69 466 508 70 466 minecraft:red_terracotta
setblock 509 69 464 minecraft:terracotta
fill 509 69 465 509 71 465 minecraft:red_terracotta
setblock 509 69 469 minecraft:terracotta
setblock 509 69 470 minecraft:red_terracotta
setblock 509 69 489 minecraft:terracotta
fill 509 69 490 509 72 490 minecraft:red_terracotta
setblock 509 69 493 minecraft:red_terracotta
setblock 509 69 494 minecraft:terracotta
fill 509 69 495 509 72 495 minecraft:red_terracotta
setblock 509 69 504 minecraft:terracotta
fill 510 69 464 510 72 464 minecraft:red_terracotta
setblock 510 69 468 minecraft:terracotta
fill 510 69 469 510 71 469 minecraft:red_terracotta
setblock 510 69 472 minecraft:red_terracotta
setblock 510 69 488 minecraft:terracotta
fill 510 69 489 510 72 489 minecraft:red_terracotta
setblock 510 69 493 minecraft:terracotta
fill 510 69 494 510 72 494 minecraft:red_terracotta
setblock 510 69 498 minecraft:terracotta
fill 510 69 499 510 72 499 minecraft:red_terracotta
setblock 510 69 503 minecraft:terracotta
fill 510 69 504 510 72 504 minecraft:red_terracotta
setblock 511 69 467 minecraft:terracotta
fill 511 69 468 511 72 468 minecraft:red_terracotta
setblock 511 69 472 minecraft:terracotta
fill 511 69 473 511 72 473 minecraft:red_terracotta
setblock 511 69 483 minecraft:red_terracotta
setblock 511 69 487 minecraft:terracotta
fill 511 69 488 511 72 488 minecraft:red_terracotta
setblock 511 69 492 minecraft:terracotta
fill 511 69 493 511 72 493 minecraft:red_terracotta
setblock 511 69 497 minecraft:terracotta
fill 511 69 498 511 72 498 minecraft:red_terracotta
setblock 511 69 502 minecraft:terracotta
fill 511 69 503 511 72 503 minecraft:red_terracotta
setblock 471 70 466 minecraft:terracotta
fill 471 70 467 471 71 467 minecraft:red_terracotta
setblock 471 70 471 minecraft:terracotta
fill 471 70 472 471 73 472 minecraft:red_terracotta
setblock 471 70 476 minecraft:terracotta
setblock 471 70 477 minecraft:red_terracotta
setblock 471 70 481 minecraft:terracotta
fill 471 70 482 471 71 482 minecraft:red_terracotta
setblock 471 70 486 minecraft:terracotta
fill 471 70 487 471 73 487 minecraft:red_terracotta
setblock 471 70 491 minecraft:terracotta
fill 471 70 492 471 73 492 minecraft:red_terracotta
setblock 471 70 496 minecraft:terracotta
fill 471 70 497 471 73 497 minecraft:red_terracotta
setblock 471 70 501 minecraft:terracotta
setblock 472 70 485 minecraft:terracotta
fill 472 70 486 472 71 486 minecraft:red_terracotta
setblock 472 70 490 minecraft:terracotta
fill 472 70 491 472 73 491 minecraft:red_terracotta
setblock 472 70 495 minecraft:terracotta
fill 472 70 496 472 73 496 minecraft:red_terracotta
setblock 473 70 489 minecraft:terracotta
setblock 473 70 490 minecraft:red_terracotta
fill 484 70 464 484 73 464 minecraft:red_terracotta
setblock 486 70 466 minecraft:terracotta
setblock 487 70 465 minecraft:terracotta
fill 487 70 466 487 71 466 minecraft:red_terracotta
setblock 488 70 464 minecraft:terracotta
fill 488 70 465 488 73 465 minecraft:red_terracotta
fill 489 70 464 489 73 464 minecraft:red_terracotta
setblock 491 70 466 minecraft:terracotta
setblock 492 70 465 minecraft:terracotta
setblock 492 70 466 minecraft:red_terracotta
setblock 493 70 464 minecraft:terracotta
fill 493 70 465 495 70 465 minecraft:red_terracotta
fill 494 70 464 494 72 464 minecraft:red_terracotta
setblock 498 70 464 minecraft:terracotta
setblock 499 70 464 minecraft:red_terracotta
setblock 502 70 465 minecraft:terracotta
setblock 503 70 464 minecraft:terracotta
fill 503 70 465 503 71 465 minecraft:red_terracotta
setblock 503 70 504 minecraft:terracotta
fill 504 70 464 504 73 464 minecraft:red_terracotta
fill 504 70 504 504 73 504 minecraft:red_terracotta
setblock 506 70 466 minecraft:terracotta
setblock 507 70 465 minecraft:terracotta
setblock 507 70 466 minecraft:red_terracotta
setblock 508 70 464 minecraft:terracotta
fill 508 70 465 508 71 465 minecraft:red_terracotta
setblock 508 70 504 minecraft:terracotta
fill 509 70 464 509 73 464 minecraft:red_terracotta
setblock 509 70 468 minecraft:terracotta
setblock 509 70 489 minecraft:red_terracotta
setblock 509 70 493 minecraft:terracotta
fill 509 70 494 509 73 494 minecraft:red_terracotta
setblock 509 70 503 minecraft:terracotta
fill 509 70 504 509 73 504 minecraft:red_terracotta
setblock 510 70 467 minecraft:terracotta
fill 510 70 468 510 71 468 minecraft:red_terracotta
setblock 510 70 472 minecraft:terracotta
setblock 510 70 487 minecraft:terracotta
fill 510 70 488 510 72 488 minecraft:red_terracotta
setblock 510 70 492 minecraft:terracotta
fill 510 70 493 510 73 493 minecraft:red_terracotta
setblock 510 70 497 minecraft:terracotta
fill 510 70 498 510 73 498 minecraft:red_terracotta
setblock 510 70 502 minecraft:terracotta
setblock 510 70 503 minecraft:red_terracotta
setblock 511 70 466 minecraft:terracotta
fill 511 70 467 511 72 467 minecraft:red_terracotta
setblock 511 70 471 minecraft:terracotta
fill 511 70 472 511 73 472 minecraft:red_terracotta
setblock 511 70 486 minecraft:terracotta
fill 511 70 487 511 73 487 minecraft:red_terracotta
setblock 511 70 491 minecraft:terracotta
fill 511 70 492 511 73 492 minecraft:red_terracotta
setblock 511 70 496 minecraft:terracotta
fill 511 70 497 511 73 497 minecraft:red_terracotta
setblock 511 70 501 minecraft:terracotta
fill 511 70 502 511 73 502 minecraft:red_terracotta
setblock 471 71 470 minecraft:terracotta
fill 471 71 471 471 74 471 minecraft:red_terracotta
setblock 471 71 475 minecraft:terracotta
fill 471 71 476 471 74 476 minecraft:red_terracotta
setblock 471 71 485 minecraft:terracotta
fill 471 71 486 471 74 486 minecraft:red_terracotta
setblock 471 71 490 minecraft:terracotta
fill 471 71 491 471 74 491 minecraft:red_terracotta
setblock 471 71 495 minecraft:terracotta
fill 471 71 496 471 74 496 minecraft:red_terracotta
setblock 471 71 500 minecraft:terracotta
setblock 472 71 489 minecraft:terracotta
fill 472 71 490 472 74 490 minecraft:red_terracotta
setblock 472 71 494 minecraft:terracotta
fill 472 71 495 472 74 495 minecraft:red_terracotta
setblock 486 71 465 minecraft:terracotta
setblock 487 71 464 minecraft:terracotta
fill 487 71 465 487 74 465 minecraft:red_terracotta
fill 488 71 464 488 74 464 minecraft:red_terracotta
setblock 490 71 466 minecraft:terracotta
setblock 491 71 465 minecraft:terracotta
setblock 492 71 464 minecraft:terracotta
fill 492 71 465 493 71 465 minecraft:red_terracotta
fill 493 71 464 493 72 464 minecraft:red_terracotta
setblock 502 71 464 minecraft:terracotta
fill 503 71 464 503 74 464 minecraft:red_terracotta
fill 503 71 504 503 74 504 minecraft:red_terracotta
setblock 506 71 465 minecraft:terracotta
setblock 507 71 464 minecraft:terracotta
fill 507 71 465 507 72 465 minecraft:red_terracotta
setblock 507 71 504 minecraft:terracotta
fill 508 71 464 508 74 464 minecraft:red_terracotta
setblock 508 71 503 minecraft:terracotta
fill 508 71 504 508 74 504 minecraft:red_terracotta
setblock 509 71 492 minecraft:terracotta
fill 509 71 493 509 74 493 minecraft:red_terracotta
setblock 509 71 497 minecraft:terracotta
setblock 509 71 503 minecraft:red_terracotta
setblock 510 71 466 minecraft:terracotta
setblock 510 71 467 minecraft:red_terracotta
setblock 510 71 471 minecraft:terracotta
setblock 510 71 487 minecraft:red_terracotta
setblock 510 71 491 minecraft:terracotta
fill 510 71 492 510 74 492 minecraft:red_terracotta
setblock 510 71 496 minecraft:terracotta
fill 510 71 497 510 74 497 minecraft:red_terracotta
setblock 510 71 501 minecraft:terracotta
setblock 511 71 465 minecraft:terracotta
fill 511 71 466 511 72 466 minecraft:red_terracotta
setblock 511 71 470 minecraft:terracotta
fill 511 71 471 511 74 471 minecraft:red_terracotta
setblock 511 71 485 minecraft:terracotta
fill 511 71 486 511 72 486 minecraft:red_terracotta
setblock 511 71 490 minecraft:terracotta
fill 511 71 491 511 74 491 minecraft:red_terracotta
setblock 511 71 495 minecraft:terracotta
fill 511 71 496 511 74 496 minecraft:red_terracotta
setblock 511 71 500 minecraft:terracotta
fill 511 71 501 511 74 501 minecraft:red_terracotta
setblock 471 72 469 minecraft:terracotta
fill 471 72 470 471 75 470 minecraft:red_terracotta
setblock 471 72 474 minecraft:terracotta
fill 471 72 475 471 75 475 minecraft:red_terracotta
fill 471 72 477 471 73 477 minecraft:red_terracotta
setblock 471 72 484 minecraft:terracotta
fill 471 72 485 471 75 485 minecraft:red_terracotta
setblock 471 72 489 minecraft:terracotta
fill 471 72 490 471 75 490 minecraft:red_terracotta
setblock 471 72 494 minecraft:terracotta
fill 471 72 495 471 75 495 minecraft:red_terracotta
setblock 471 72 499 minecraft:terracotta
setblock 472 72 488 minecraft:terracotta
fill 472 72 489 472 73 489 minecraft:red_terracotta
setblock 472 72 493 minecraft:terracotta
fill 472 72 494 472 75 494 minecraft:red_terracotta
setblock 485 72 465 minecraft:terracotta
setblock 486 72 464 minecraft:terracotta
fill 486 72 465 486 75 465 minecraft:red_terracotta
fill 487 72 464 487 75 464 minecraft:red_terracotta
setblock 490 72 465 minecraft:terracotta
setblock 491 72 464 minecraft:terracotta
setblock 491 72 465 minecraft:red_terracotta
fill 492 72 464 492 73 464 minecraft:red_terracotta
setblock 501 72 464 minecraft:terracotta
fill 502 72 464 502 75 464 minecraft:red_terracotta
setblock 505 72 465 minecraft:terracotta
setblock 506 72 464 minecraft:terracotta
setblock 506 72 465 minecraft:red_terracotta
setblock 506 72 504 minecraft:terracotta
fill 507 72 464 507 75 464 minecraft:red_terracotta
setblock 507 72 503 minecraft:terracotta
fill 507 72 504 507 75 504 minecraft:red_terracotta
fill 508 72 503 508 75 503 minecraft:red_terracotta
setblock 509 72 491 minecraft:terracotta
fill 509 72 492 509 75 492 minecraft:red_terracotta
setblock 509 72 496 minecraft:terracotta
fill 509 72 497 509 74 498 minecraft:red_terracotta
setblock 510 72 490 minecraft:terracotta
fill 510 72 491 510 75 491 minecraft:red_terracotta
setblock 510 72 495 minecraft:terracotta
fill 510 72 496 510 75 496 minecraft:red_terracotta
setblock 510 72 500 minecraft:terracotta
setblock 511 72 469 minecraft:terracotta
fill 511 72 470 511 74 470 minecraft:red_terracotta
setblock 511 72 474 minecraft:terracotta
setblock 511 72 489 minecraft:terracotta
fill 511 72 490 511 75 490 minecraft:red_terracotta
setblock 511 72 494 minecraft:terracotta
fill 511 72 495 511 75 495 minecraft:red_terracotta
setblock 511 72 499 minecraft:terracotta
fill 511 72 500 511 75 500 minecraft:red_terracotta
setblock 511 72 504 minecraft:terracotta
setblock 471 73 473 minecraft:terracotta
fill 471 73 474 471 76 474 minecraft:red_terracotta
setblock 471 73 484 minecraft:red_terracotta
setblock 471 73 488 minecraft:terracotta
fill 471 73 489 471 76 489 minecraft:red_terracotta
setblock 471 73 493 minecraft:terracotta
fill 471 73 494 471 76 494 minecraft:red_terracotta
setblock 471 73 498 minecraft:terracotta
fill 471 73 499 471 76 499 minecraft:red_terracotta
setblock 472 73 492 minecraft:terracotta
fill 472 73 493 472 76 493 minecraft:red_terracotta
setblock 485 73 464 minecraft:terracotta
fill 486 73 464 486 76 464 minecraft:red_terracotta
setblock 489 73 465 minecraft:terracotta
setblock 490 73 464 minecraft:terracotta
setblock 490 73 465 minecraft:red_terracotta
fill 491 73 464 491 76 464 minecraft:red_terracotta
fill 501 73 464 501 76 464 minecraft:red_terracotta
fill 502 73 504 502 75 504 minecraft:red_terracotta
setblock 505 73 464 minecraft:terracotta
setblock 505 73 503 minecraft:red_terracotta
setblock 505 73 504 minecraft:terracotta
fill 506 73 464 506 76 464 minecraft:red_terracotta
setblock 506 73 503 minecraft:terracotta
fill 506 73 504 506 76 504 minecraft:red_terracotta
fill 507 73 503 507 76 503 minecraft:red_terracotta
fill 509 73 491 509 75 491 minecraft:red_terracotta
setblock 509 73 495 minecraft:terracotta
fill 509 73 496 509 76 496 minecraft:red_terracotta
setblock 510 73 489 minecraft:terracotta
fill 510 73 490 510 76 490 minecraft:red_terracotta
setblock 510 73 494 minecraft:terracotta
fill 510 73 495 510 76 495 minecraft:red_terracotta
setblock 510 73 499 minecraft:terracotta
fill 510 73 500 510 76 500 minecraft:red_terracotta
setblock 510 73 504 minecraft:terracotta
setblock 511 73 469 minecraft:red_terracotta
setblock 511 73 473 minecraft:terracotta
fill 511 73 474 511 76 474 minecraft:red_terracotta
setblock 511 73 488 minecraft:terracotta
fill 511 73 489 511 76 489 minecraft:red_terracotta
setblock 511 73 493 minecraft:terracotta
fill 511 73 494 511 76 494 minecraft:red_terracotta
setblock 511 73 498 minecraft:terracotta
fill 511 73 499 511 76 499 minecraft:red_terracotta
setblock 511 73 503 minecraft:terracotta
setblock 471 74 472 minecraft:terracotta
fill 471 74 473 471 77 473 minecraft:red_terracotta
setblock 471 74 477 minecraft:terracotta
fill 471 74 478 471 76 479 minecraft:red_terracotta
setblock 471 74 487 minecraft:terracotta
fill 471 74 488 471 77 488 minecraft:red_terracotta
setblock 471 74 492 minecraft:terracotta
fill 471 74 493 471 77 493 minecraft:red_terracotta
setblock 471 74 497 minecraft:terracotta
fill 471 74 498 471 77 498 minecraft:red_terracotta
setblock 472 74 491 minecraft:terracotta
fill 472 74 492 472 76 492 minecraft:red_terracotta
setblock 472 74 496 minecraft:terracotta
setblock 483 74 464 minecraft:red_terracotta
setblock 484 74 464 minecraft:terracotta
fill 485 74 464 485 76 465 minecraft:red_terracotta
setblock 488 74 465 minecraft:terracotta
setblock 489 74 464 minecraft:terracotta
setblock 489 74 465 minecraft:red_terracotta
fill 490 74 464 490 77 464 minecraft:red_terracotta
fill 501 74 504 501 76 504 minecraft:red_terracotta
setblock 504 74 464 minecraft:terracotta
setblock 504 74 503 minecraft:red_terracotta
setblock 504 74 504 minecraft:terracotta
fill 505 74 464 505 77 464 minecraft:red_terracotta
setblock 505 74 503 minecraft:terracotta
fill 505 74 504 505 77 504 minecraft:red_terracotta
fill 506 74 503 506 77 503 minecraft:red_terracotta
setblock 508 74 494 minecraft:red_terracotta
setblock 508 74 495 minecraft:terracotta
setblock 509 74 494 minecraft:terracotta
fill 509 74 495 509 77 495 minecraft:red_terracotta
setblock 509 74 499 minecraft:terracotta
setblock 509 74 504 minecraft:terracotta
fill 510 74 489 510 75 489 minecraft:red_terracotta
setblock 510 74 493 minecraft:terracotta
fill 510 74 494 510 77 494 minecraft:red_terracotta
setblock 510 74 498 minecraft:terracotta
fill 510 74 499 510 77 499 minecraft:red_terracotta
fill 510 74 501 510 75 501 minecraft:red_terracotta
fill 510 74 504 510 77 504 minecraft:red_terracotta
setblock 511 74 472 minecraft:terracotta
fill 511 74 473 511 77 473 minecraft:red_terracotta
setblock 511 74 487 minecraft:terracotta
fill 511 74 488 511 77 488 minecraft:red_terracotta
setblock 511 74 492 minecraft:terracotta
fill 511 74 493 511 77 493 minecraft:red_terracotta
setblock 511 74 497 minecraft:terracotta
fill 511 74 498 511 77 498 minecraft:red_terracotta
setblock 511 74 502 minecraft:terracotta
fill 511 74 503 511 77 503 minecraft:red_terracotta
setblock 471 75 471 minecraft:terracotta
fill 471 75 472 471 78 472 minecraft:red_terracotta
setblock 471 75 476 minecraft:terracotta
fill 471 75 477 471 78 477 minecraft:red_terracotta
setblock 471 75 480 minecraft:red_terracotta
setblock 471 75 481 minecraft:terracotta
setblock 471 75 486 minecraft:terracotta
fill 471 75 487 471 78 487 minecraft:red_terracotta
setblock 471 75 491 minecraft:terracotta
fill 471 75 492 471 78 492 minecraft:red_terracotta
setblock 471 75 496 minecraft:terracotta
fill 471 75 497 471 78 497 minecraft:red_terracotta
setblock 471 75 500 minecraft:red_terracotta
setblock 472 75 491 minecraft:red_terracotta
setblock 472 75 495 minecraft:terracotta
fill 472 75 496 472 78 496 minecraft:red_terracotta
setblock 483 75 464 minecraft:terracotta
fill 484 75 464 484 78 464 minecraft:red_terracotta
setblock 487 75 465 minecraft:terracotta
setblock 488 75 464 minecraft:terracotta
fill 488 75 465 488 78 465 minecraft:red_terracotta
fill 489 75 464 489 78 464 minecraft:red_terracotta
fill 500 75 464 500 77 464 minecraft:red_terracotta
fill 500 75 504 500 77 504 minecraft:red_terracotta
fill 502 75 503 503 75 503 minecraft:red_terracotta
setblock 503 75 464 minecraft:terracotta
setblock 503 75 504 minecraft:terracotta
fill 504 75 464 504 78 464 minecraft:red_terracotta
setblock 504 75 503 minecraft:terracotta
fill 504 75 504 504 78 504 minecraft:red_terracotta
fill 505 75 503 505 78 503 minecraft:red_terracotta
setblock 508 75 494 minecraft:terracotta
fill 508 75 495 508 76 497 minecraft:red_terracotta
setblock 508 75 504 minecraft:terracotta
setblock 509 75 493 minecraft:terracotta
fill 509 75 494 509 78 494 minecraft:red_terracotta
setblock 509 75 497 minecraft:red_terracotta
setblock 509 75 498 minecraft:terracotta
fill 509 75 499 509 78 499 minecraft:red_terracotta
fill 509 75 504 509 78 504 minecraft:red_terracotta
setblock 510 75 492 minecraft:terracotta
fill 510 75 493 510 78 493 minecraft:red_terracotta
setblock 510 75 497 minecraft:terracotta
fill 510 75 498 510 78 498 minecraft:red_terracotta
setblock 511 75 471 minecraft:terracotta
fill 511 75 472 511 77 472 minecraft:red_terracotta
setblock 511 75 475 minecraft:red_terracotta
setblock 511 75 491 minecraft:terracotta
fill 511 75 492 511 78 492 minecraft:red_terracotta
setblock 511 75 496 minecraft:terracotta
fill 511 75 497 511 78 497 minecraft:red_terracotta
setblock 511 75 501 minecraft:terracotta
fill 511 75 502 511 78 502 minecraft:red_terracotta
fill 470 76 463 470 79 467 minecraft:blackstone
setblock 470 76 468 minecraft:brown_terracotta
fill 470 76 469 470 79 469 minecraft:blackstone
fill 470 76 470 470 77 470 minecraft:brown_terracotta
fill 470 76 471 470 79 473 minecraft:blackstone
setblock 470 76 474 minecraft:brown_terracotta
fill 470 76 475 470 76 479 minecraft:blackstone
setblock 470 76 480 minecraft:brown_terracotta
fill 470 76 481 470 77 485 minecraft:blackstone
setblock 470 76 486 minecraft:brown_terracotta
fill 470 76 487 470 76 491 minecraft:blackstone
setblock 470 76 492 minecraft:brown_terracotta
fill 470 76 493 470 76 505 minecraft:blackstone
fill 471 76 463 472 76 463 minecraft:brown_terracotta
fill 471 76 471 471 79 471 minecraft:red_terracotta
setblock 471 76 475 minecraft:terracotta
fill 471 76 476 471 79 476 minecraft:red_terracotta
setblock 471 76 480 minecraft:terracotta
fill 471 76 481 471 76 484 minecraft:red_terracotta
setblock 471 76 485 minecraft:terracotta
fill 471 76 486 471 79 486 minecraft:red_terracotta
setblock 471 76 490 minecraft:terracotta
fill 471 76 491 471 79 491 minecraft:red_terracotta
setblock 471 76 495 minecraft:terracotta
fill 471 76 496 471 79 496 minecraft:red_terracotta
setblock 471 76 500 minecraft:terracotta
fill 471 76 505 473 79 505 minecraft:blackstone
fill 472 76 475 472 79 475 minecraft:red_terracotta
setblock 472 76 494 minecraft:terracotta
fill 472 76 495 472 78 495 minecraft:red_terracotta
fill 473 76 463 485 76 463 minecraft:blackstone
setblock 474 76 505 minecraft:brown_terracotta
fill 475 76 505 486 76 505 minecraft:blackstone
setblock 482 76 464 minecraft:terracotta
fill 483 76 464 483 79 464 minecraft:red_terracotta
fill 484 76 465 484 77 465 minecraft:red_terracotta
fill 485 76 504 486 76 504 minecraft:red_terracotta
setblock 486 76 463 minecraft:brown_terracotta
setblock 486 76 465 minecraft:terracotta
fill 487 76 463 491 76 463 minecraft:blackstone
setblock 487 76 464 minecraft:terracotta
fill 487 76 465 487 79 465 minecraft:red_terracotta
setblock 487 76 504 minecraft:terracotta
setblock 487 76 505 minecraft:brown_terracotta
fill 488 76 464 488 79 464 minecraft:red_terracotta
fill 488 76 505 488 79 505 minecraft:blackstone
fill 489 76 505 490 76 505 minecraft:brown_terracotta
fill 491 76 505 512 76 505 minecraft:blackstone
setblock 492 76 463 minecraft:brown_terracotta
fill 493 76 463 494 79 463 minecraft:blackstone
setblock 495 76 463 minecraft:brown_terracotta
fill 496 76 463 503 77 463 minecraft:blackstone
fill 498 76 504 499 78 504 minecraft:red_terracotta
fill 499 76 464 499 78 464 minecraft:red_terracotta
fill 501 76 503 502 76 503 minecraft:red_terracotta
setblock 502 76 464 minecraft:terracotta
setblock 502 76 504 minecraft:terracotta
fill 503 76 464 503 79 464 minecraft:red_terracotta
setblock 503 76 502 minecraft:red_terracotta
setblock 503 76 503 minecraft:terracotta
fill 503 76 504 503 79 504 minecraft:red_terracotta
setblock 504 76 463 minecraft:brown_terracotta
setblock 504 76 502 minecraft:terracotta
fill 504 76 503 504 79 503 minecraft:red_terracotta
fill 505 76 463 512 79 463 minecraft:blackstone
fill 505 76 502 507 77 502 minecraft:red_terracotta
setblock 507 76 464 minecraft:terracotta
setblock 507 76 504 minecraft:terracotta
fill 508 76 494 508 78 494 minecraft:red_terracotta
setblock 508 76 498 minecraft:terracotta
setblock 508 76 503 minecraft:terracotta
fill 508 76 504 508 79 504 minecraft:red_terracotta
setblock 509 76 492 minecraft:terracotta
fill 509 76 493 509 79 493 minecraft:red_terracotta
setblock 509 76 497 minecraft:terracotta
fill 509 76 498 509 79 498 minecraft:red_terracotta
fill 509 76 500 509 77 500 minecraft:red_terracotta
fill 509 76 503 509 79 503 minecraft:red_terracotta
setblock 510 76 491 minecraft:terracotta
fill 510 76 492 510 79 492 minecraft:red_terracotta
setblock 510 76 496 minecraft:terracotta
fill 510 76 497 510 79 497 minecraft:red_terracotta
setblock 510 76 501 minecraft:terracotta
fill 510 76 502 510 79 502 minecraft:red_terracotta
setblock 511 76 475 minecraft:terracotta
fill 511 76 476 511 78 477 minecraft:red_terracotta
setblock 511 76 490 minecraft:terracotta
fill 511 76 491 511 79 491 minecraft:red_terracotta
setblock 511 76 495 minecraft:terracotta
fill 511 76 496 511 79 496 minecraft:red_terracotta
setblock 511 76 500 minecraft:terracotta
fill 511 76 501 511 79 501 minecraft:red_terracotta
setblock 512 76 464 minecraft:brown_terracotta
fill 512 76 465 512 76 471 minecraft:blackstone
setblock 512 76 472 minecraft:brown_terracotta
fill 512 76 473 512 76 499 minecraft:blackstone
setblock 512 76 500 minecraft:brown_terracotta
fill 512 76 501 512 76 504 minecraft:blackstone
fill 470 77 468 470 79 468 minecraft:blackstone
fill 470 77 474 470 79 474 minecraft:blackstone
setblock 470 77 475 minecraft:brown_terracotta
fill 470 77 476 470 79 480 minecraft:blackstone
fill 470 77 486 470 77 490 minecraft:blackstone
setblock 470 77 491 minecraft:brown_terracotta
fill 470 77 492 470 77 499 minecraft:blackstone
fill 470 77 500 470 77 502 minecraft:brown_terracotta
fill 470 77 503 470 77 505 minecraft:blackstone
fill 471 77 463 476 77 463 minecraft:blackstone
setblock 471 77 474 minecraft:terracotta
fill 471 77 475 471 80 475 minecraft:red_terracotta
setblock 471 77 478 minecraft:red_terracotta
setblock 471 77 479 minecraft:terracotta
fill 471 77 480 471 77 483 minecraft:red_terracotta
setblock 471 77 484 minecraft:terracotta
fill 471 77 485 471 80 485 minecraft:red_terracotta
setblock 471 77 489 minecraft:terracotta
fill 471 77 490 471 80 490 minecraft:red_terracotta
setblock 471 77 494 minecraft:terracotta
fill 471 77 495 471 80 495 minecraft:red_terracotta
setblock 471 77 499 minecraft:terracotta
fill 471 77 500 471 80 500 minecraft:red_terracotta
fill 472 77 474 472 80 474 minecraft:red_terracotta
fill 472 77 476 472 77 477 minecraft:red_terracotta
setblock 472 77 478 minecraft:terracotta
setblock 472 77 493 minecraft:terracotta
fill 472 77 494 472 78 494 minecraft:red_terracotta
setblock 472 77 497 minecraft:red_terracotta
setblock 473 77 466 minecraft:light[level=14]
setblock 473 77 474 minecraft:light[level=14]
setblock 473 77 482 minecraft:light[level=14]
setblock 473 77 490 minecraft:light[level=14]
setblock 473 77 498 minecraft:light[level=14]
fill 474 77 505 483 77 505 minecraft:blackstone
setblock 477 77 463 minecraft:brown_terracotta
fill 478 77 463 488 77 463 minecraft:blackstone
setblock 481 77 464 minecraft:terracotta
setblock 481 77 466 minecraft:light[level=14]
setblock 481 77 474 minecraft:light[level=14]
setblock 481 77 482 minecraft:light[level=14]
setblock 481 77 490 minecraft:light[level=14]
fill 482 77 464 482 80 464 minecraft:red_terracotta
fill 482 77 504 485 77 504 minecraft:red_terracotta
fill 483 77 465 483 78 465 minecraft:red_terracotta
fill 484 77 505 485 77 505 minecraft:brown_terracotta
setblock 485 77 464 minecraft:red_terracotta
setblock 485 77 465 minecraft:terracotta
setblock 486 77 464 minecraft:terracotta
fill 486 77 465 486 80 465 minecraft:red_terracotta
setblock 486 77 504 minecraft:terracotta
fill 486 77 505 487 79 505 minecraft:blackstone
fill 487 77 464 487 80 464 minecraft:red_terracotta
fill 487 77 504 489 78 504 minecraft:red_terracotta
setblock 489 77 463 minecraft:brown_terracotta
setblock 489 77 466 minecraft:light[level=14]
setblock 489 77 490 minecraft:light[level=14]
setblock 489 77 498 minecraft:light[level=14]
fill 489 77 505 496 79 505 minecraft:blackstone
fill 490 77 463 492 79 463 minecraft:blackstone
setblock 491 77 464 minecraft:terracotta
fill 495 77 463 495 79 463 minecraft:blackstone
setblock 497 77 466 minecraft:light[level=14]
setblock 497 77 474 minecraft:light[level=14]
setblock 497 77 482 minecraft:light[level=14]
setblock 497 77 490 minecraft:light[level=14]
fill 497 77 504 497 80 504 minecraft:red_terracotta
setblock 497 77 505 minecraft:brown_terracotta
fill 498 77 464 498 79 464 minecraft:red_terracotta
fill 498 77 505 499 79 505 minecraft:blackstone
fill 499 77 503 501 77 503 minecraft:red_terracotta
setblock 500 77 505 minecraft:brown_terracotta
setblock 501 77 464 minecraft:terracotta
fill 501 77 502 502 77 502 minecraft:red_terracotta
setblock 501 77 504 minecraft:terracotta
fill 501 77 505 504 79 505 minecraft:blackstone
fill 502 77 464 502 80 464 minecraft:red_terracotta
setblock 502 77 503 minecraft:terracotta
fill 502 77 504 502 80 504 minecraft:red_terracotta
setblock 503 77 501 minecraft:red_terracotta
setblock 503 77 502 minecraft:terracotta
fill 503 77 503 503 80 503 minecraft:red_terracotta
setblock 504 77 463 minecraft:blackstone
setblock 504 77 501 minecraft:terracotta
fill 504 77 502 504 80 502 minecraft:red_terracotta
setblock 505 77 466 minecraft:light[level=14]
setblock 505 77 474 minecraft:light[level=14]
setblock 505 77 482 minecraft:light[level=14]
setblock 505 77 490 minecraft:light[level=14]
setblock 505 77 498 minecraft:light[level=14]
fill 505 77 501 506 79 501 minecraft:red_terracotta
setblock 505 77 505 minecraft:brown_terracotta
setblock 506 77 464 minecraft:terracotta
setblock 506 77 504 minecraft:terracotta
fill 506 77 505 506 79 505 minecraft:blackstone
fill 507 77 464 507 79 464 minecraft:red_terracotta
setblock 507 77 503 minecraft:terracotta
fill 507 77 504 507 80 504 minecraft:red_terracotta
setblock 507 77 505 minecraft:brown_terracotta
fill 508 77 495 508 77 496 minecraft:red_terracotta
setblock 508 77 497 minecraft:terracotta
fill 508 77 498 508 79 499 minecraft:red_terracotta
setblock 508 77 502 minecraft:terracotta
fill 508 77 503 508 80 503 minecraft:red_terracotta
fill 508 77 505 512 77 505 minecraft:blackstone
fill 509 77 492 509 78 492 minecraft:red_terracotta
setblock 509 77 496 minecraft:terracotta
fill 509 77 497 509 80 497 minecraft:red_terracotta
setblock 509 77 501 minecraft:terracotta
setblock 510 77 490 minecraft:terracotta
fill 510 77 491 510 79 491 minecraft:red_terracotta
setblock 510 77 495 minecraft:terracotta
fill 510 77 496 510 80 496 minecraft:red_terracotta
setblock 510 77 500 minecraft:terracotta
fill 510 77 501 510 80 501 minecraft:red_terracotta
setblock 511 77 474 minecraft:terracotta
fill 511 77 475 511 80 475 minecraft:red_terracotta
setblock 511 77 478 minecraft:red_terracotta
setblock 511 77 479 minecraft:terracotta
setblock 511 77 489 minecraft:terracotta
fill 511 77 490 511 80 490 minecraft:red_terracotta
setblock 511 77 494 minecraft:terracotta
fill 511 77 495 511 80 495 minecraft:red_terracotta
setblock 511 77 499 minecraft:terracotta
fill 511 77 500 511 80 500 minecraft:red_terracotta
fill 512 77 464 512 79 468 minecraft:blackstone
setblock 512 77 469 minecraft:brown_terracotta
fill 512 77 470 512 79 470 minecraft:blackstone
setblock 512 77 471 minecraft:brown_terracotta
fill 512 77 472 512 79 473 minecraft:blackstone
setblock 512 77 474 minecraft:brown_terracotta
fill 512 77 475 512 77 490 minecraft:blackstone
setblock 512 77 491 minecraft:brown_terracotta
fill 512 77 492 512 79 494 minecraft:blackstone
setblock 512 77 495 minecraft:brown_terracotta
fill 512 77 496 512 77 500 minecraft:blackstone
fill 512 77 501 512 78 501 minecraft:brown_terracotta
fill 512 77 502 512 79 504 minecraft:blackstone
fill 470 78 470 470 79 470 minecraft:blackstone
fill 470 78 475 470 79 475 minecraft:blackstone
setblock 470 78 481 minecraft:brown_terracotta
fill 470 78 482 470 79 486 minecraft:blackstone
setblock 470 78 487 minecraft:brown_terracotta
fill 470 78 488 470 79 493 minecraft:blackstone
setblock 470 78 494 minecraft:brown_terracotta
fill 470 78 495 470 79 499 minecraft:blackstone
setblock 470 78 500 minecraft:brown_terracotta
fill 470 78 501 470 79 503 minecraft:blackstone
setblock 470 78 504 minecraft:brown_terracotta
fill 470 78 505 470 80 505 minecraft:blackstone
fill 471 78 463 471 79 463 minecraft:blackstone
setblock 471 78 473 minecraft:terracotta
fill 471 78 474 471 81 474 minecraft:red_terracotta
setblock 471 78 478 minecraft:terracotta
fill 471 78 479 471 78 482 minecraft:red_terracotta
setblock 471 78 483 minecraft:terracotta
fill 471 78 484 471 81 484 minecraft:red_terracotta
setblock 471 78 488 minecraft:terracotta
fill 471 78 489 471 80 489 minecraft:red_terracotta
setblock 471 78 493 minecraft:terracotta
fill 471 78 494 471 81 494 minecraft:red_terracotta
setblock 471 78 498 minecraft:terracotta
fill 471 78 499 471 81 499 minecraft:red_terracotta
fill 471 78 501 471 79 501 minecraft:red_terracotta
setblock 472 78 463 minecraft:brown_terracotta
setblock 472 78 476 minecraft:red_terracotta
setblock 472 78 477 minecraft:terracotta
fill 472 78 478 472 79 480 minecraft:red_terracotta
setblock 472 78 497 minecraft:terracotta
fill 473 78 463 475 79 463 minecraft:blackstone
fill 474 78 505 477 79 505 minecraft:blackstone
setblock 476 78 463 minecraft:brown_terracotta
fill 477 78 463 486 79 463 minecraft:blackstone
setblock 478 78 505 minecraft:brown_terracotta
fill 479 78 505 485 79 505 minecraft:blackstone
setblock 480 78 464 minecraft:terracotta
fill 481 78 464 481 81 464 minecraft:red_terracotta
fill 481 78 504 484 78 504 minecraft:red_terracotta
fill 482 78 465 482 79 465 minecraft:red_terracotta
fill 483 78 503 485 78 503 minecraft:red_terracotta
setblock 484 78 465 minecraft:terracotta
setblock 485 78 464 minecraft:terracotta
fill 485 78 465 485 81 465 minecraft:red_terracotta
setblock 485 78 504 minecraft:terracotta
fill 486 78 464 486 81 464 minecraft:red_terracotta
setblock 486 78 503 minecraft:terracotta
fill 486 78 504 486 81 504 minecraft:red_terracotta
setblock 487 78 463 minecraft:brown_terracotta
fill 488 78 463 489 79 463 minecraft:blackstone
setblock 490 78 464 minecraft:terracotta
setblock 490 78 504 minecraft:terracotta
fill 491 78 464 492 80 464 minecraft:red_terracotta
fill 491 78 504 491 81 504 minecraft:red_terracotta
setblock 494 78 504 minecraft:red_terracotta
setblock 495 78 504 minecraft:terracotta
fill 496 78 463 498 79 463 minecraft:blackstone
fill 496 78 464 497 80 464 minecraft:red_terracotta
fill 496 78 504 496 81 504 minecraft:red_terracotta
fill 497 78 503 500 78 503 minecraft:red_terracotta
fill 497 78 505 497 79 505 minecraft:blackstone
setblock 499 78 463 minecraft:brown_terracotta
fill 499 78 502 501 78 502 minecraft:red_terracotta
fill 500 78 463 501 79 463 minecraft:blackstone
setblock 500 78 464 minecraft:terracotta
setblock 500 78 504 minecraft:terracotta
fill 500 78 505 500 79 505 minecraft:blackstone
fill 501 78 464 501 81 464 minecraft:red_terracotta
fill 501 78 501 502 78 501 minecraft:red_terracotta
setblock 501 78 503 minecraft:terracotta
fill 501 78 504 501 81 504 minecraft:red_terracotta
setblock 502 78 463 minecraft:brown_terracotta
fill 502 78 465 503 78 465 minecraft:red_terracotta
setblock 502 78 502 minecraft:terracotta
fill 502 78 503 502 81 503 minecraft:red_terracotta
fill 503 78 463 503 79 463 minecraft:blackstone
setblock 503 78 501 minecraft:terracotta
fill 503 78 502 503 81 502 minecraft:red_terracotta
setblock 504 78 463 minecraft:brown_terracotta
fill 504 78 501 504 81 501 minecraft:red_terracotta
setblock 505 78 464 minecraft:terracotta
fill 505 78 502 506 78 502 minecraft:red_terracotta
setblock 505 78 504 minecraft:terracotta
fill 505 78 505 505 80 505 minecraft:blackstone
fill 506 78 464 506 81 464 minecraft:red_terracotta
setblock 506 78 503 minecraft:terracotta
fill 506 78 504 506 81 504 minecraft:red_terracotta
setblock 507 78 501 minecraft:red_terracotta
setblock 507 78 502 minecraft:terracotta
fill 507 78 503 507 81 503 minecraft:red_terracotta
fill 507 78 505 509 79 505 minecraft:blackstone
setblock 508 78 495 minecraft:red_terracotta
setblock 508 78 496 minecraft:terracotta
fill 508 78 497 508 80 497 minecraft:red_terracotta
setblock 508 78 500 minecraft:red_terracotta
fill 508 78 502 508 81 502 minecraft:red_terracotta
setblock 509 78 495 minecraft:terracotta
fill 509 78 496 509 81 496 minecraft:red_terracotta
setblock 509 78 500 minecraft:terracotta
fill 509 78 501 509 81 501 minecraft:red_terracotta
setblock 510 78 490 minecraft:red_terracotta
setblock 510 78 494 minecraft:terracotta
fill 510 78 495 510 81 495 minecraft:red_terracotta
setblock 510 78 499 minecraft:terracotta
fill 510 78 500 510 81 500 minecraft:red_terracotta
setblock 510 78 504 minecraft:terracotta
setblock 510 78 505 minecraft:brown_terracotta
setblock 511 78 473 minecraft:terracotta
fill 511 78 474 511 80 474 minecraft:red_terracotta
setblock 511 78 478 minecraft:terracotta
fill 511 78 479 511 79 481 minecraft:red_terracotta
setblock 511 78 488 minecraft:terracotta
fill 511 78 489 511 81 489 minecraft:red_terracotta
setblock 511 78 493 minecraft:terracotta
fill 511 78 494 511 81 494 minecraft:red_terracotta
setblock 511 78 498 minecraft:terracotta
fill 511 78 499 511 81 499 minecraft:red_terracotta
setblock 511 78 503 minecraft:terracotta
fill 511 78 504 511 81 504 minecraft:red_terracotta
fill 511 78 505 512 79 505 minecraft:blackstone
fill 512 78 469 512 79 469 minecraft:blackstone
fill 512 78 471 512 80 471 minecraft:blackstone
fill 512 78 474 512 79 476 minecraft:blackstone
setblock 512 78 477 minecraft:brown_terracotta
fill 512 78 478 512 79 483 minecraft:blackstone
setblock 512 78 484 minecraft:brown_terracotta
fill 512 78 485 512 79 488 minecraft:blackstone
fill 512 78 489 512 78 490 minecraft:brown_terracotta
fill 512 78 491 512 79 491 minecraft:blackstone
fill 512 78 495 512 79 497 minecraft:blackstone
setblock 512 78 498 minecraft:brown_terracotta
fill 512 78 499 512 79 500 minecraft:blackstone
setblock 470 79 481 minecraft:blackstone
setblock 470 79 487 minecraft:blackstone
setblock 470 79 494 minecraft:blackstone
setblock 470 79 500 minecraft:blackstone
setblock 470 79 504 minecraft:blackstone
setblock 471 79 472 minecraft:terracotta
fill 471 79 473 471 82 473 minecraft:red_terracotta
setblock 471 79 477 minecraft:terracotta
fill 471 79 478 471 79 481 minecraft:red_terracotta
setblock 471 79 482 minecraft:terracotta
fill 471 79 483 471 82 483 minecraft:red_terracotta
setblock 471 79 487 minecraft:terracotta
fill 471 79 488 471 80 488 minecraft:red_terracotta
setblock 471 79 492 minecraft:terracotta
fill 471 79 493 471 81 493 minecraft:red_terracotta
setblock 471 79 497 minecraft:terracotta
fill 471 79 498 471 82 498 minecraft:red_terracotta
setblock 472 79 463 minecraft:blackstone
setblock 472 79 476 minecraft:terracotta
fill 472 79 477 472 82 477 minecraft:red_terracotta
setblock 472 79 481 minecraft:terracotta
setblock 472 79 496 minecraft:terracotta
setblock 476 79 463 minecraft:blackstone
setblock 478 79 505 minecraft:blackstone
setblock 479 79 464 minecraft:terracotta
setblock 479 79 504 minecraft:terracotta
fill 480 79 464 480 82 464 minecraft:red_terracotta
fill 480 79 504 483 79 504 minecraft:red_terracotta
fill 481 79 465 481 80 465 minecraft:red_terracotta
fill 481 79 503 484 79 503 minecraft:red_terracotta
setblock 483 79 465 minecraft:terracotta
setblock 484 79 464 minecraft:terracotta
fill 484 79 465 484 82 465 minecraft:red_terracotta
setblock 484 79 504 minecraft:terracotta
fill 485 79 464 485 82 464 minecraft:red_terracotta
setblock 485 79 503 minecraft:terracotta
fill 485 79 504 485 82 504 minecraft:red_terracotta
fill 486 79 503 488 80 503 minecraft:red_terracotta
setblock 487 79 463 minecraft:blackstone
fill 487 79 504 488 79 504 minecraft:red_terracotta
setblock 488 79 465 minecraft:terracotta
setblock 489 79 464 minecraft:terracotta
setblock 489 79 504 minecraft:terracotta
fill 490 79 464 490 82 464 minecraft:red_terracotta
fill 490 79 504 490 82 504 minecraft:red_terracotta
fill 492 79 504 493 79 504 minecraft:red_terracotta
setblock 493 79 464 minecraft:red_terracotta
setblock 494 79 464 minecraft:terracotta
setblock 494 79 504 minecraft:terracotta
fill 495 79 464 495 82 464 minecraft:red_terracotta
fill 495 79 504 495 82 504 minecraft:red_terracotta
fill 496 79 503 499 79 503 minecraft:red_terracotta
fill 498 79 502 500 79 502 minecraft:red_terracotta
setblock 498 79 504 minecraft:red_terracotta
setblock 499 79 463 minecraft:blackstone
setblock 499 79 464 minecraft:terracotta
setblock 499 79 504 minecraft:terracotta
fill 500 79 464 500 82 464 minecraft:red_terracotta
fill 500 79 501 501 79 501 minecraft:red_terracotta
setblock 500 79 503 minecraft:terracotta
fill 500 79 504 500 82 504 minecraft:red_terracotta
fill 501 79 465 502 79 465 minecraft:red_terracotta
setblock 501 79 502 minecraft:terracotta
fill 501 79 503 501 82 503 minecraft:red_terracotta
setblock 502 79 463 minecraft:blackstone
setblock 502 79 500 minecraft:red_terracotta
setblock 502 79 501 minecraft:terracotta
fill 502 79 502 502 82 502 minecraft:red_terracotta
setblock 503 79 465 minecraft:terracotta
setblock 503 79 500 minecraft:terracotta
fill 503 79 501 503 82 501 minecraft:red_terracotta
setblock 504 79 463 minecraft:blackstone
setblock 504 79 464 minecraft:terracotta
fill 504 79 500 505 80 500 minecraft:red_terracotta
setblock 504 79 504 minecraft:terracotta
fill 505 79 464 505 82 464 minecraft:red_terracotta
setblock 505 79 502 minecraft:red_terracotta
setblock 505 79 503 minecraft:terracotta
fill 505 79 504 505 82 504 minecraft:red_terracotta
setblock 506 79 502 minecraft:terracotta
fill 506 79 503 506 82 503 minecraft:red_terracotta
setblock 507 79 501 minecraft:terracotta
fill 507 79 502 507 82 502 minecraft:red_terracotta
setblock 508 79 495 minecraft:terracotta
fill 508 79 496 508 80 496 minecraft:red_terracotta
setblock 508 79 500 minecraft:terracotta
setblock 509 79 494 minecraft:terracotta
fill 509 79 495 509 81 495 minecraft:red_terracotta
setblock 509 79 499 minecraft:terracotta
fill 509 79 500 509 82 500 minecraft:red_terracotta
setblock 509 79 504 minecraft:terracotta
setblock 510 79 493 minecraft:terracotta
fill 510 79 494 510 81 494 minecraft:red_terracotta
setblock 510 79 498 minecraft:terracotta
fill 510 79 499 510 82 499 minecraft:red_terracotta
setblock 510 79 503 minecraft:terracotta
fill 510 79 504 510 82 504 minecraft:red_terracotta
setblock 510 79 505 minecraft:blackstone
setblock 511 79 473 minecraft:red_terracotta
setblock 511 79 476 minecraft:red_terracotta
setblock 511 79 477 minecraft:terracotta
fill 511 79 478 511 82 478 minecraft:red_terracotta
setblock 511 79 482 minecraft:terracotta
fill 511 79 483 511 82 483 minecraft:red_terracotta
setblock 511 79 487 minecraft:terracotta
fill 511 79 488 511 80 488 minecraft:red_terracotta
setblock 511 79 492 minecraft:terracotta
fill 511 79 493 511 82 493 minecraft:red_terracotta
setblock 511 79 497 minecraft:terracotta
fill 511 79 498 511 82 498 minecraft:red_terracotta
setblock 511 79 502 minecraft:terracotta
fill 511 79 503 511 82 503 minecraft:red_terracotta
setblock 512 79 477 minecraft:blackstone
setblock 512 79 484 minecraft:blackstone
fill 512 79 489 512 79 490 minecraft:blackstone
setblock 512 79 498 minecraft:blackstone
setblock 512 79 501 minecraft:blackstone
fill 470 80 463 470 80 470 minecraft:brown_terracotta
setblock 470 80 471 minecraft:blackstone
fill 470 80 472 470 80 494 minecraft:brown_terracotta
setblock 470 80 495 minecraft:blackstone
fill 470 80 496 470 151 501 minecraft:brown_terracotta
setblock 470 80 502 minecraft:blackstone
fill 470 80 503 470 151 504 minecraft:brown_terracotta
fill 471 80 463 473 81 463 minecraft:brown_terracotta
fill 471 80 472 471 81 472 minecraft:red_terracotta
setblock 471 80 476 minecraft:terracotta
fill 471 80 477 471 80 480 minecraft:red_terracotta
setblock 471 80 481 minecraft:terracotta
fill 471 80 482 472 82 482 minecraft:red_terracotta
setblock 471 80 486 minecraft:terracotta
setblock 471 80 487 minecraft:red_terracotta
setblock 471 80 491 minecraft:terracotta
setblock 471 80 492 minecraft:red_terracotta
setblock 471 80 496 minecraft:terracotta
fill 471 80 497 471 82 497 minecraft:red_terracotta
setblock 471 80 501 minecraft:terracotta
fill 471 80 505 471 81 505 minecraft:blackstone
setblock 472 80 475 minecraft:terracotta
fill 472 80 476 472 83 476 minecraft:red_terracotta
fill 472 80 478 472 80 479 minecraft:red_terracotta
setblock 472 80 480 minecraft:terracotta
fill 472 80 481 472 83 481 minecraft:red_terracotta
fill 472 80 505 498 80 505 minecraft:brown_terracotta
fill 473 80 477 473 80 478 minecraft:red_terracotta
setblock 474 80 463 minecraft:blackstone
fill 475 80 463 478 80 463 minecraft:brown_terracotta
setblock 478 80 464 minecraft:terracotta
setblock 478 80 504 minecraft:terracotta
setblock 479 80 463 minecraft:blackstone
fill 479 80 464 479 83 464 minecraft:red_terracotta
fill 479 80 504 482 80 504 minecraft:red_terracotta
fill 480 80 463 505 80 463 minecraft:brown_terracotta
fill 480 80 465 480 81 465 minecraft:red_terracotta
fill 480 80 503 483 80 503 minecraft:red_terracotta
setblock 482 80 465 minecraft:terracotta
setblock 483 80 464 minecraft:terracotta
fill 483 80 465 483 83 465 minecraft:red_terracotta
setblock 483 80 504 minecraft:terracotta
fill 484 80 464 484 83 464 minecraft:red_terracotta
setblock 484 80 503 minecraft:terracotta
fill 484 80 504 484 83 504 minecraft:red_terracotta
fill 485 80 503 485 83 503 minecraft:red_terracotta
setblock 487 80 465 minecraft:terracotta
setblock 487 80 504 minecraft:red_terracotta
setblock 488 80 464 minecraft:terracotta
setblock 488 80 465 minecraft:red_terracotta
setblock 488 80 504 minecraft:terracotta
fill 489 80 464 489 83 464 minecraft:red_terracotta
setblock 489 80 503 minecraft:terracotta
fill 489 80 504 489 83 504 minecraft:red_terracotta
setblock 492 80 504 minecraft:red_terracotta
setblock 493 80 464 minecraft:terracotta
setblock 493 80 504 minecraft:terracotta
fill 494 80 464 494 83 464 minecraft:red_terracotta
setblock 494 80 503 minecraft:terracotta
fill 494 80 504 494 83 504 minecraft:red_terracotta
fill 495 80 503 498 80 503 minecraft:red_terracotta
fill 497 80 502 499 80 502 minecraft:red_terracotta
setblock 498 80 464 minecraft:terracotta
setblock 498 80 504 minecraft:terracotta
fill 499 80 464 499 83 464 minecraft:red_terracotta
fill 499 80 501 500 80 501 minecraft:red_terracotta
setblock 499 80 503 minecraft:terracotta
fill 499 80 504 499 83 504 minecraft:red_terracotta
setblock 499 80 505 minecraft:blackstone
fill 500 80 465 501 80 465 minecraft:red_terracotta
setblock 500 80 502 minecraft:terracotta
fill 500 80 503 500 83 503 minecraft:red_terracotta
fill 500 80 505 502 81 505 minecraft:brown_terracotta
setblock 501 80 500 minecraft:red_terracotta
setblock 501 80 501 minecraft:terracotta
fill 501 80 502 501 83 502 minecraft:red_terracotta
setblock 502 80 465 minecraft:terracotta
setblock 502 80 500 minecraft:terracotta
fill 502 80 501 502 83 501 minecraft:red_terracotta
setblock 503 80 464 minecraft:terracotta
setblock 503 80 465 minecraft:red_terracotta
fill 503 80 500 503 82 500 minecraft:red_terracotta
setblock 503 80 504 minecraft:terracotta
fill 503 80 505 504 80 505 minecraft:blackstone
fill 504 80 464 504 83 464 minecraft:red_terracotta
setblock 504 80 503 minecraft:terracotta
fill 504 80 504 504 83 504 minecraft:red_terracotta
setblock 505 80 501 minecraft:red_terracotta
setblock 505 80 502 minecraft:terracotta
fill 505 80 503 505 83 503 minecraft:red_terracotta
setblock 506 80 463 minecraft:blackstone
setblock 506 80 501 minecraft:terracotta
fill 506 80 502 506 83 502 minecraft:red_terracotta
fill 506 80 505 512 151 505 minecraft:brown_terracotta
fill 507 80 463 510 80 463 minecraft:brown_terracotta
setblock 507 80 501 minecraft:red_terracotta
setblock 508 80 498 minecraft:red_terracotta
setblock 508 80 499 minecraft:terracotta
setblock 508 80 504 minecraft:terracotta
setblock 509 80 494 minecraft:red_terracotta
setblock 509 80 498 minecraft:terracotta
fill 509 80 499 509 82 499 minecraft:red_terracotta
setblock 509 80 503 minecraft:terracotta
fill 509 80 504 509 83 504 minecraft:red_terracotta
fill 510 80 478 510 80 479 minecraft:red_terracotta
setblock 510 80 492 minecraft:terracotta
fill 510 80 493 510 81 493 minecraft:red_terracotta
setblock 510 80 497 minecraft:terracotta
fill 510 80 498 510 83 498 minecraft:red_terracotta
setblock 510 80 502 minecraft:terracotta
setblock 510 80 503 minecraft:red_terracotta
fill 511 80 463 512 80 463 minecraft:blackstone
setblock 511 80 476 minecraft:terracotta
fill 511 80 477 511 83 477 minecraft:red_terracotta
fill 511 80 479 511 80 480 minecraft:red_terracotta
setblock 511 80 481 minecraft:terracotta
fill 511 80 482 511 83 482 minecraft:red_terracotta
fill 511 80 484 511 80 485 minecraft:red_terracotta
setblock 511 80 491 minecraft:terracotta
fill 511 80 492 511 82 492 minecraft:red_terracotta
setblock 511 80 496 minecraft:terracotta
fill 511 80 497 511 83 497 minecraft:red_terracotta
setblock 511 80 501 minecraft:terracotta
fill 511 80 502 511 83 502 minecraft:red_terracotta
fill 512 80 464 512 80 467 minecraft:brown_terracotta
setblock 512 80 468 minecraft:blackstone
fill 512 80 469 512 80 470 minecraft:brown_terracotta
fill 512 80 472 512 80 478 minecraft:brown_terracotta
setblock 512 80 479 minecraft:blackstone
fill 512 80 480 512 80 489 minecraft:brown_terracotta
setblock 512 80 490 minecraft:blackstone
fill 512 80 491 512 80 504 minecraft:brown_terracotta
setblock 470 81 463 minecraft:blackstone
fill 470 81 464 470 152 467 minecraft:brown_terracotta
setblock 470 81 468 minecraft:blackstone
fill 470 81 469 470 81 483 minecraft:brown_terracotta
setblock 470 81 484 minecraft:blackstone
fill 470 81 485 470 81 495 minecraft:brown_terracotta
fill 470 81 502 470 152 502 minecraft:brown_terracotta
fill 470 81 505 470 156 505 minecraft:brown_terracotta
setblock 471 81 475 minecraft:terracotta
fill 471 81 476 471 81 479 minecraft:red_terracotta
setblock 471 81 480 minecraft:terracotta
fill 471 81 481 471 84 481 minecraft:red_terracotta
setblock 471 81 485 minecraft:terracotta
fill 471 81 486 471 83 486 minecraft:red_terracotta
setblock 471 81 495 minecraft:terracotta
fill 471 81 496 471 82 496 minecraft:red_terracotta
setblock 471 81 500 minecraft:terracotta
fill 471 81 501 471 82 501 minecraft:red_terracotta
setblock 472 81 474 minecraft:terracotta
fill 472 81 475 472 82 475 minecraft:red_terracotta
setblock 472 81 478 minecraft:red_terracotta
setblock 472 81 479 minecraft:terracotta
fill 472 81 480 472 84 480 minecraft:red_terracotta
setblock 472 81 483 minecraft:red_terracotta
fill 472 81 505 472 151 505 minecraft:brown_terracotta
setblock 473 81 477 minecraft:red_terracotta
setblock 473 81 478 minecraft:terracotta
fill 473 81 479 473 83 479 minecraft:red_terracotta
setblock 473 81 505 minecraft:blackstone
fill 474 81 463 477 81 463 minecraft:brown_terracotta
fill 474 81 505 478 152 505 minecraft:brown_terracotta
setblock 477 81 464 minecraft:terracotta
setblock 477 81 504 minecraft:terracotta
setblock 478 81 463 minecraft:blackstone
fill 478 81 464 478 84 464 minecraft:red_terracotta
fill 478 81 504 481 81 504 minecraft:red_terracotta
fill 479 81 463 482 153 463 minecraft:brown_terracotta
fill 479 81 503 482 81 503 minecraft:red_terracotta
setblock 479 81 505 minecraft:blackstone
fill 480 81 505 483 152 505 minecraft:brown_terracotta
setblock 481 81 465 minecraft:terracotta
setblock 482 81 464 minecraft:terracotta
fill 482 81 465 482 84 465 minecraft:red_terracotta
fill 482 81 502 483 81 502 minecraft:red_terracotta
setblock 482 81 504 minecraft:terracotta
setblock 483 81 463 minecraft:blackstone
fill 483 81 464 483 84 464 minecraft:red_terracotta
fill 483 81 498 483 82 499 minecraft:magma_block
setblock 483 81 503 minecraft:terracotta
fill 483 81 504 483 84 504 minecraft:red_terracotta
fill 484 81 463 507 81 463 minecraft:brown_terracotta
setblock 484 81 502 minecraft:terracotta
fill 484 81 503 484 84 503 minecraft:red_terracotta
setblock 484 81 505 minecraft:blackstone
fill 485 81 505 492 151 505 minecraft:brown_terracotta
setblock 486 81 465 minecraft:terracotta
fill 486 81 503 487 81 503 minecraft:red_terracotta
setblock 487 81 464 minecraft:terracotta
setblock 487 81 465 minecraft:red_terracotta
setblock 487 81 504 minecraft:terracotta
fill 488 81 464 488 84 464 minecraft:red_terracotta
setblock 488 81 503 minecraft:terracotta
fill 488 81 504 488 84 504 minecraft:red_terracotta
fill 489 81 503 490 83 503 minecraft:red_terracotta
setblock 491 81 464 minecraft:red_terracotta
setblock 492 81 464 minecraft:terracotta
setblock 492 81 503 minecraft:red_terracotta
setblock 492 81 504 minecraft:terracotta
fill 493 81 464 493 84 464 minecraft:red_terracotta
setblock 493 81 503 minecraft:terracotta
fill 493 81 504 493 84 504 minecraft:red_terracotta
fill 493 81 505 495 81 505 minecraft:blackstone
fill 494 81 503 497 81 503 minecraft:red_terracotta
setblock 496 81 464 minecraft:red_terracotta
fill 496 81 502 498 81 502 minecraft:red_terracotta
fill 496 81 505 499 152 505 minecraft:brown_terracotta
setblock 497 81 464 minecraft:terracotta
setblock 497 81 504 minecraft:terracotta
fill 498 81 464 498 84 464 minecraft:red_terracotta
fill 498 81 501 499 81 501 minecraft:red_terracotta
setblock 498 81 503 minecraft:terracotta
fill 498 81 504 498 84 504 minecraft:red_terracotta
fill 499 81 465 500 81 465 minecraft:red_terracotta
setblock 499 81 502 minecraft:terracotta
fill 499 81 503 499 84 503 minecraft:red_terracotta
setblock 500 81 500 minecraft:red_terracotta
setblock 500 81 501 minecraft:terracotta
fill 500 81 502 500 84 502 minecraft:red_terracotta
setblock 501 81 465 minecraft:terracotta
setblock 501 81 500 minecraft:terracotta
fill 501 81 501 501 84 501 minecraft:red_terracotta
setblock 502 81 464 minecraft:terracotta
setblock 502 81 465 minecraft:red_terracotta
fill 502 81 500 502 82 500 minecraft:red_terracotta
setblock 502 81 504 minecraft:terracotta
fill 503 81 464 503 84 464 minecraft:red_terracotta
fill 503 81 498 504 82 499 minecraft:orange_concrete
setblock 503 81 503 minecraft:terracotta
fill 503 81 504 503 84 504 minecraft:red_terracotta
fill 503 81 505 505 151 505 minecraft:brown_terracotta
setblock 504 81 500 minecraft:red_terracotta
setblock 504 81 502 minecraft:terracotta
fill 504 81 503 504 84 503 minecraft:red_terracotta
setblock 505 81 501 minecraft:terracotta
fill 505 81 502 505 84 502 minecraft:red_terracotta
fill 506 81 501 506 82 501 minecraft:red_terracotta
setblock 507 81 504 minecraft:terracotta
setblock 508 81 463 minecraft:blackstone
setblock 508 81 503 minecraft:terracotta
fill 508 81 504 508 84 504 minecraft:red_terracotta
fill 509 81 463 512 155 463 minecraft:brown_terracotta
setblock 509 81 497 minecraft:terracotta
fill 509 81 498 509 82 498 minecraft:red_terracotta
fill 509 81 503 509 82 503 minecraft:red_terracotta
fill 510 81 479 511 81 479 minecraft:red_terracotta
setblock 510 81 496 minecraft:terracotta
fill 510 81 497 510 83 497 minecraft:red_terracotta
setblock 510 81 501 minecraft:terracotta
fill 510 81 502 510 82 502 minecraft:red_terracotta
setblock 511 81 475 minecraft:terracotta
fill 511 81 476 511 83 476 minecraft:red_terracotta
setblock 511 81 480 minecraft:terracotta
fill 511 81 481 511 84 481 minecraft:red_terracotta
setblock 511 81 484 minecraft:red_terracotta
setblock 511 81 485 minecraft:terracotta
fill 511 81 486 511 84 486 minecraft:red_terracotta
setblock 511 81 490 minecraft:terracotta
fill 511 81 491 511 82 491 minecraft:red_terracotta
setblock 511 81 495 minecraft:terracotta
fill 511 81 496 511 84 496 minecraft:red_terracotta
setblock 511 81 500 minecraft:terracotta
fill 511 81 501 511 84 501 minecraft:red_terracotta
fill 512 81 464 512 82 464 minecraft:blackstone
fill 512 81 465 512 81 468 minecraft:brown_terracotta
setblock 512 81 469 minecraft:blackstone
fill 512 81 470 512 152 474 minecraft:brown_terracotta
fill 512 81 475 512 81 476 minecraft:blackstone
fill 512 81 477 512 81 484 minecraft:brown_terracotta
setblock 512 81 485 minecraft:blackstone
fill 512 81 486 512 151 491 minecraft:brown_terracotta
setblock 512 81 492 minecraft:blackstone
fill 512 81 493 512 81 504 minecraft:brown_terracotta
fill 470 82 463 470 155 463 minecraft:brown_terracotta
fill 470 82 468 470 155 472 minecraft:brown_terracotta
setblock 470 82 473 minecraft:blackstone
fill 470 82 474 470 151 482 minecraft:brown_terracotta
setblock 470 82 483 minecraft:blackstone
fill 470 82 484 470 151 490 minecraft:brown_terracotta
setblock 470 82 491 minecraft:blackstone
fill 470 82 492 470 152 495 minecraft:brown_terracotta
setblock 471 82 463 minecraft:blackstone
setblock 471 82 474 minecraft:terracotta
fill 471 82 475 471 82 478 minecraft:red_terracotta
setblock 471 82 479 minecraft:terracotta
fill 471 82 480 471 85 480 minecraft:red_terracotta
setblock 471 82 484 minecraft:terracotta
fill 471 82 485 471 85 485 minecraft:red_terracotta
setblock 471 82 499 minecraft:terracotta
setblock 471 82 500 minecraft:red_terracotta
fill 471 82 505 471 155 505 minecraft:brown_terracotta
fill 472 82 463 474 155 463 minecraft:brown_terracotta
setblock 472 82 478 minecraft:terracotta
fill 472 82 479 472 85 479 minecraft:red_terracotta
setblock 472 82 483 minecraft:terracotta
setblock 473 82 478 minecraft:red_terracotta
fill 473 82 480 473 83 480 minecraft:red_terracotta
fill 473 82 505 473 155 505 minecraft:brown_terracotta
setblock 475 82 463 minecraft:blackstone
fill 476 82 463 478 151 463 minecraft:brown_terracotta
setblock 476 82 504 minecraft:terracotta
fill 477 82 464 477 85 464 minecraft:red_terracotta
fill 477 82 504 480 82 504 minecraft:red_terracotta
fill 478 82 503 481 82 503 minecraft:red_terracotta
setblock 479 82 465 minecraft:red_terracotta
fill 479 82 505 479 155 505 minecraft:brown_terracotta
setblock 480 82 465 minecraft:terracotta
setblock 481 82 464 minecraft:terracotta
fill 481 82 465 481 85 465 minecraft:red_terracotta
fill 481 82 502 482 82 502 minecraft:red_terracotta
setblock 481 82 504 minecraft:terracotta
fill 482 82 464 482 85 464 minecraft:red_terracotta
setblock 482 82 503 minecraft:terracotta
fill 482 82 504 482 85 504 minecraft:red_terracotta
fill 483 82 463 487 152 463 minecraft:brown_terracotta
setblock 483 82 502 minecraft:terracotta
fill 483 82 503 483 85 503 minecraft:red_terracotta
setblock 484 82 502 minecraft:red_terracotta
fill 484 82 505 484 156 505 minecraft:brown_terracotta
setblock 485 82 465 minecraft:terracotta
setblock 486 82 464 minecraft:terracotta
fill 486 82 465 486 83 465 minecraft:red_terracotta
setblock 486 82 503 minecraft:red_terracotta
setblock 486 82 504 minecraft:terracotta
fill 487 82 464 487 85 464 minecraft:red_terracotta
setblock 487 82 503 minecraft:terracotta
fill 487 82 504 487 85 504 minecraft:red_terracotta
setblock 488 82 463 minecraft:blackstone
fill 488 82 503 488 83 503 minecraft:red_terracotta
fill 489 82 463 497 152 463 minecraft:brown_terracotta
setblock 491 82 464 minecraft:terracotta
setblock 491 82 503 minecraft:red_terracotta
setblock 491 82 504 minecraft:terracotta
fill 492 82 464 492 85 464 minecraft:red_terracotta
setblock 492 82 503 minecraft:terracotta
fill 492 82 504 492 85 504 minecraft:red_terracotta
fill 493 82 503 496 82 503 minecraft:red_terracotta
fill 493 82 505 493 151 505 minecraft:brown_terracotta
fill 494 82 505 495 82 505 minecraft:blackstone
fill 495 82 502 497 82 502 minecraft:red_terracotta
setblock 496 82 464 minecraft:terracotta
setblock 496 82 504 minecraft:terracotta
fill 497 82 464 497 85 464 minecraft:red_terracotta
fill 497 82 501 498 82 501 minecraft:red_terracotta
setblock 497 82 503 minecraft:terracotta
fill 497 82 504 497 85 504 minecraft:red_terracotta
setblock 498 82 463 minecraft:blackstone
setblock 498 82 502 minecraft:terracotta
fill 498 82 503 498 85 503 minecraft:red_terracotta
fill 499 82 463 505 151 463 minecraft:brown_terracotta
setblock 499 82 465 minecraft:red_terracotta
setblock 499 82 501 minecraft:terracotta
fill 499 82 502 499 85 502 minecraft:red_terracotta
setblock 500 82 465 minecraft:terracotta
setblock 500 82 500 minecraft:terracotta
fill 500 82 501 500 85 501 minecraft:red_terracotta
fill 500 82 505 501 155 505 minecraft:brown_terracotta
setblock 501 82 464 minecraft:terracotta
setblock 501 82 465 minecraft:red_terracotta
setblock 501 82 500 minecraft:red_terracotta
setblock 501 82 504 minecraft:terracotta
fill 502 82 464 502 85 464 minecraft:red_terracotta
setblock 502 82 503 minecraft:terracotta
fill 502 82 504 502 85 504 minecraft:red_terracotta
setblock 502 82 505 minecraft:blackstone
setblock 503 82 502 minecraft:terracotta
fill 503 82 503 503 85 503 minecraft:red_terracotta
setblock 504 82 501 minecraft:terracotta
fill 504 82 502 504 85 502 minecraft:red_terracotta
fill 505 82 501 505 83 501 minecraft:red_terracotta
setblock 506 82 463 minecraft:blackstone
setblock 506 82 504 minecraft:terracotta
fill 507 82 463 508 151 463 minecraft:brown_terracotta
setblock 507 82 503 minecraft:terracotta
fill 507 82 504 507 85 504 minecraft:red_terracotta
fill 508 82 503 508 83 503 minecraft:red_terracotta
setblock 510 82 495 minecraft:terracotta
setblock 510 82 496 minecraft:red_terracotta
setblock 510 82 500 minecraft:terracotta
fill 510 82 501 510 83 501 minecraft:red_terracotta
setblock 511 82 475 minecraft:red_terracotta
setblock 511 82 479 minecraft:terracotta
fill 511 82 480 511 85 480 minecraft:red_terracotta
setblock 511 82 484 minecraft:terracotta
fill 511 82 485 511 85 485 minecraft:red_terracotta
setblock 511 82 494 minecraft:terracotta
fill 511 82 495 511 83 495 minecraft:red_terracotta
setblock 511 82 499 minecraft:terracotta
fill 511 82 500 511 85 500 minecraft:red_terracotta
setblock 511 82 504 minecraft:terracotta
fill 512 82 465 512 155 466 minecraft:brown_terracotta
setblock 512 82 467 minecraft:blackstone
fill 512 82 468 512 155 469 minecraft:brown_terracotta
fill 512 82 475 512 151 481 minecraft:brown_terracotta
setblock 512 82 482 minecraft:blackstone
fill 512 82 483 512 151 485 minecraft:brown_terracotta
fill 512 82 492 512 152 495 minecraft:brown_terracotta
fill 512 82 496 512 82 497 minecraft:blackstone
fill 512 82 498 512 151 499 minecraft:brown_terracotta
setblock 512 82 500 minecraft:blackstone
fill 512 82 501 512 153 504 minecraft:brown_terracotta
fill 470 83 473 470 155 473 minecraft:brown_terracotta
fill 470 83 483 470 155 483 minecraft:brown_terracotta
fill 470 83 491 470 155 491 minecraft:brown_terracotta
fill 471 83 463 471 156 463 minecraft:brown_terracotta
fill 471 83 474 471 83 477 minecraft:red_terracotta
setblock 471 83 478 minecraft:terracotta
fill 471 83 479 471 86 479 minecraft:red_terracotta
setblock 471 83 482 minecraft:red_terracotta
setblock 471 83 483 minecraft:terracotta
fill 471 83 484 471 86 484 minecraft:red_terracotta
setblock 472 83 477 minecraft:terracotta
fill 472 83 478 472 86 478 minecraft:red_terracotta
setblock 472 83 482 minecraft:terracotta
fill 472 83 483 472 86 483 minecraft:red_terracotta
fill 475 83 463 475 155 463 minecraft:brown_terracotta
fill 476 83 464 476 86 464 minecraft:red_terracotta
fill 476 83 504 479 83 504 minecraft:red_terracotta
fill 478 83 503 480 83 503 minecraft:red_terracotta
setblock 479 83 465 minecraft:terracotta
setblock 480 83 464 minecraft:terracotta
fill 480 83 465 480 86 465 minecraft:red_terracotta
setblock 480 83 504 minecraft:terracotta
fill 481 83 464 481 86 464 minecraft:red_terracotta
setblock 481 83 502 minecraft:red_terracotta
setblock 481 83 503 minecraft:terracotta
fill 481 83 504 481 86 504 minecraft:red_terracotta
setblock 482 83 502 minecraft:terracotta
fill 482 83 503 482 86 503 minecraft:red_terracotta
setblock 483 83 502 minecraft:red_terracotta
setblock 484 83 465 minecraft:terracotta
setblock 485 83 464 minecraft:terracotta
fill 485 83 465 485 85 465 minecraft:red_terracotta
setblock 485 83 504 minecraft:terracotta
fill 486 83 464 486 86 464 minecraft:red_terracotta
setblock 486 83 503 minecraft:terracotta
fill 486 83 504 486 86 504 minecraft:red_terracotta
fill 487 83 503 487 84 503 minecraft:red_terracotta
fill 488 83 463 488 155 463 minecraft:brown_terracotta
setblock 490 83 464 minecraft:terracotta
setblock 490 83 504 minecraft:terracotta
fill 491 83 464 491 86 464 minecraft:red_terracotta
setblock 491 83 503 minecraft:terracotta
fill 491 83 504 491 86 504 minecraft:red_terracotta
fill 492 83 503 495 83 503 minecraft:red_terracotta
fill 494 83 505 495 152 505 minecraft:brown_terracotta
setblock 495 83 464 minecraft:terracotta
fill 495 83 502 496 83 502 minecraft:red_terracotta
setblock 495 83 504 minecraft:terracotta
fill 496 83 464 496 86 464 minecraft:red_terracotta
setblock 496 83 503 minecraft:terracotta
fill 496 83 504 496 86 504 minecraft:red_terracotta
setblock 497 83 501 minecraft:red_terracotta
setblock 497 83 502 minecraft:terracotta
fill 497 83 503 497 86 503 minecraft:red_terracotta
fill 498 83 463 498 155 463 minecraft:brown_terracotta
setblock 498 83 501 minecraft:terracotta
fill 498 83 502 498 86 502 minecraft:red_terracotta
setblock 499 83 465 minecraft:terracotta
fill 499 83 501 499 86 501 minecraft:red_terracotta
setblock 500 83 464 minecraft:terracotta
setblock 500 83 465 minecraft:red_terracotta
setblock 500 83 504 minecraft:terracotta
fill 501 83 464 501 86 464 minecraft:red_terracotta
setblock 501 83 503 minecraft:terracotta
fill 501 83 504 501 86 504 minecraft:red_terracotta
setblock 502 83 502 minecraft:terracotta
fill 502 83 503 502 86 503 minecraft:red_terracotta
fill 502 83 505 502 152 505 minecraft:brown_terracotta
setblock 503 83 501 minecraft:terracotta
fill 503 83 502 503 86 502 minecraft:red_terracotta
fill 504 83 501 504 84 501 minecraft:red_terracotta
setblock 505 83 464 minecraft:terracotta
setblock 505 83 504 minecraft:terracotta
fill 506 83 463 506 155 463 minecraft:brown_terracotta
setblock 506 83 503 minecraft:terracotta
fill 506 83 504 506 86 504 minecraft:red_terracotta
setblock 507 83 502 minecraft:terracotta
fill 507 83 503 507 84 503 minecraft:red_terracotta
setblock 510 83 499 minecraft:terracotta
setblock 510 83 500 minecraft:red_terracotta
setblock 510 83 504 minecraft:terracotta
setblock 511 83 478 minecraft:terracotta
fill 511 83 479 511 86 479 minecraft:red_terracotta
setblock 511 83 483 minecraft:terracotta
fill 511 83 484 511 86 484 minecraft:red_terracotta
setblock 511 83 493 minecraft:terracotta
setblock 511 83 494 minecraft:red_terracotta
setblock 511 83 498 minecraft:terracotta
fill 511 83 499 511 85 499 minecraft:red_terracotta
setblock 511 83 503 minecraft:terracotta
fill 512 83 464 512 157 464 minecraft:brown_terracotta
fill 512 83 467 512 152 467 minecraft:brown_terracotta
fill 512 83 482 512 153 482 minecraft:brown_terracotta
fill 512 83 496 512 155 497 minecraft:brown_terracotta
fill 512 83 500 512 155 500 minecraft:brown_terracotta
fill 471 84 474 471 84 476 minecraft:red_terracotta
setblock 471 84 477 minecraft:terracotta
fill 471 84 478 471 87 478 minecraft:red_terracotta
setblock 471 84 482 minecraft:terracotta
fill 471 84 483 471 87 483 minecraft:red_terracotta
setblock 472 84 476 minecraft:terracotta
fill 472 84 477 472 85 477 minecraft:red_terracotta
setblock 472 84 481 minecraft:terracotta
fill 472 84 482 472 87 482 minecraft:red_terracotta
fill 475 84 504 478 84 504 minecraft:red_terracotta
fill 477 84 503 479 84 503 minecraft:red_terracotta
setblock 478 84 465 minecraft:terracotta
setblock 479 84 464 minecraft:terracotta
fill 479 84 465 479 87 465 minecraft:red_terracotta
setblock 479 84 504 minecraft:terracotta
fill 480 84 464 480 87 464 minecraft:red_terracotta
setblock 480 84 503 minecraft:terracotta
fill 480 84 504 480 87 504 minecraft:red_terracotta
fill 481 84 503 481 87 503 minecraft:red_terracotta
setblock 483 84 465 minecraft:terracotta
setblock 484 84 464 minecraft:terracotta
fill 484 84 465 484 87 465 minecraft:red_terracotta
setblock 484 84 504 minecraft:terracotta
fill 485 84 464 485 87 464 minecraft:red_terracotta
setblock 485 84 503 minecraft:terracotta
fill 485 84 504 485 87 504 minecraft:red_terracotta
fill 486 84 503 486 85 503 minecraft:red_terracotta
setblock 489 84 464 minecraft:terracotta
setblock 489 84 504 minecraft:terracotta
fill 490 84 464 490 87 464 minecraft:red_terracotta
fill 490 84 504 490 87 504 minecraft:red_terracotta
fill 491 84 503 494 84 503 minecraft:red_terracotta
setblock 494 84 464 minecraft:terracotta
setblock 494 84 504 minecraft:terracotta
fill 495 84 464 495 87 464 minecraft:red_terracotta
setblock 495 84 502 minecraft:red_terracotta
setblock 495 84 503 minecraft:terracotta
fill 495 84 504 495 87 504 minecraft:red_terracotta
setblock 496 84 502 minecraft:terracotta
fill 496 84 503 496 87 503 minecraft:red_terracotta
setblock 497 84 501 minecraft:terracotta
fill 497 84 502 497 87 502 minecraft:red_terracotta
fill 498 84 501 498 87 501 minecraft:red_terracotta
setblock 499 84 464 minecraft:terracotta
setblock 499 84 504 minecraft:terracotta
fill 500 84 464 500 87 464 minecraft:red_terracotta
setblock 500 84 503 minecraft:terracotta
fill 500 84 504 500 87 504 minecraft:red_terracotta
setblock 501 84 502 minecraft:terracotta
fill 501 84 503 501 87 503 minecraft:red_terracotta
setblock 502 84 501 minecraft:terracotta
fill 502 84 502 502 87 502 minecraft:red_terracotta
setblock 503 84 501 minecraft:red_terracotta
setblock 504 84 464 minecraft:terracotta
setblock 504 84 504 minecraft:terracotta
setblock 505 84 503 minecraft:terracotta
fill 505 84 504 505 87 504 minecraft:red_terracotta
setblock 506 84 502 minecraft:terracotta
fill 506 84 503 506 86 503 minecraft:red_terracotta
setblock 509 84 504 minecraft:terracotta
setblock 511 84 477 minecraft:terracotta
fill 511 84 478 511 87 478 minecraft:red_terracotta
setblock 511 84 482 minecraft:terracotta
fill 511 84 483 511 87 483 minecraft:red_terracotta
setblock 511 84 497 minecraft:terracotta
fill 511 84 498 511 85 498 minecraft:red_terracotta
setblock 511 84 502 minecraft:terracotta
setblock 511 84 503 minecraft:red_terracotta
setblock 471 85 475 minecraft:red_terracotta
setblock 471 85 476 minecraft:terracotta
fill 471 85 477 471 88 477 minecraft:red_terracotta
setblock 471 85 481 minecraft:terracotta
fill 471 85 482 471 88 482 minecraft:red_terracotta
setblock 471 85 486 minecraft:terracotta
setblock 472 85 480 minecraft:terracotta
fill 472 85 481 472 88 481 minecraft:red_terracotta
setblock 473 85 466 minecraft:light[level=14]
setblock 473 85 474 minecraft:light[level=14]
setblock 473 85 482 minecraft:light[level=14]
setblock 473 85 490 minecraft:light[level=14]
setblock 473 85 498 minecraft:light[level=14]
fill 475 85 464 475 87 464 minecraft:red_terracotta
fill 475 85 497 477 85 500 minecraft:orange_concrete
fill 475 85 504 477 85 504 minecraft:red_terracotta
fill 476 85 495 478 85 496 minecraft:orange_concrete
fill 476 85 501 483 85 501 minecraft:orange_concrete
setblock 477 85 465 minecraft:terracotta
fill 477 85 502 482 85 502 minecraft:orange_concrete
fill 477 85 503 478 85 503 minecraft:red_terracotta
setblock 478 85 464 minecraft:terracotta
fill 478 85 465 478 88 465 minecraft:red_terracotta
fill 478 85 494 482 85 494 minecraft:orange_concrete
setblock 478 85 504 minecraft:terracotta
fill 479 85 464 479 88 464 minecraft:red_terracotta
fill 479 85 495 483 85 495 minecraft:orange_concrete
setblock 479 85 503 minecraft:terracotta
fill 479 85 504 479 88 504 minecraft:red_terracotta
fill 480 85 503 480 88 503 minecraft:red_terracotta
setblock 481 85 466 minecraft:light[level=14]
setblock 481 85 474 minecraft:light[level=14]
setblock 481 85 482 minecraft:light[level=14]
setblock 481 85 490 minecraft:light[level=14]
fill 481 85 496 484 85 496 minecraft:orange_concrete
setblock 482 85 465 minecraft:terracotta
fill 482 85 497 484 85 497 minecraft:orange_concrete
fill 482 85 500 484 85 500 minecraft:orange_concrete
setblock 483 85 464 minecraft:terracotta
fill 483 85 465 483 88 465 minecraft:red_terracotta
fill 483 85 498 484 85 499 minecraft:orange_concrete
setblock 483 85 504 minecraft:terracotta
fill 484 85 464 484 88 464 minecraft:red_terracotta
setblock 484 85 503 minecraft:terracotta
fill 484 85 504 484 88 504 minecraft:red_terracotta
fill 485 85 478 485 85 480 minecraft:orange_concrete
fill 485 85 503 485 86 503 minecraft:red_terracotta
fill 486 85 473 487 85 473 minecraft:orange_concrete
fill 486 85 477 486 85 479 minecraft:orange_concrete
fill 487 85 471 488 85 472 minecraft:orange_concrete
fill 487 85 474 488 85 477 minecraft:orange_concrete
setblock 488 85 464 minecraft:terracotta
fill 488 85 470 492 85 470 minecraft:orange_concrete
setblock 488 85 504 minecraft:terracotta
fill 489 85 464 489 88 464 minecraft:red_terracotta
setblock 489 85 466 minecraft:light[level=14]
fill 489 85 471 489 87 471 minecraft:orange_concrete
fill 489 85 475 489 86 477 minecraft:orange_concrete
setblock 489 85 482 minecraft:light[level=14]
setblock 489 85 490 minecraft:light[level=14]
setblock 489 85 498 minecraft:light[level=14]
fill 489 85 504 489 88 504 minecraft:red_terracotta
setblock 490 85 469 minecraft:orange_concrete
fill 490 85 476 490 85 480 minecraft:orange_concrete
fill 491 85 471 493 85 471 minecraft:orange_concrete
fill 491 85 475 492 85 476 minecraft:orange_concrete
fill 491 85 478 491 85 481 minecraft:orange_concrete
fill 491 85 494 493 85 497 minecraft:orange_concrete
fill 491 85 503 493 85 503 minecraft:red_terracotta
fill 492 85 472 493 86 472 minecraft:orange_concrete
fill 492 85 474 493 86 474 minecraft:orange_concrete
fill 492 85 492 494 85 493 minecraft:orange_concrete
fill 492 85 498 494 85 499 minecraft:orange_concrete
schedule function dropper:buildpart/118_3 1t
