fill 277 226 355 277 228 355 minecraft:green_terracotta
setblock 277 226 360 minecraft:green_terracotta
setblock 277 226 361 minecraft:moss_block
setblock 235 227 322 minecraft:moss_block
fill 235 227 323 235 228 323 minecraft:green_terracotta
fill 235 227 327 235 228 327 minecraft:green_terracotta
setblock 235 227 328 minecraft:moss_block
fill 235 227 329 235 228 329 minecraft:green_terracotta
fill 235 227 331 235 227 332 minecraft:moss_block
fill 235 227 333 235 228 333 minecraft:green_terracotta
fill 235 227 340 237 227 340 minecraft:moss_block
setblock 235 227 345 minecraft:moss_block
setblock 235 227 346 minecraft:shroomlight
fill 235 227 350 235 228 350 minecraft:green_terracotta
fill 235 227 357 235 228 357 minecraft:green_terracotta
fill 236 227 328 236 228 328 minecraft:red_mushroom_block
fill 236 227 335 236 227 337 minecraft:moss_block
setblock 236 227 338 minecraft:mushroom_stem
fill 236 227 339 237 229 339 minecraft:moss_block
fill 236 227 341 236 227 342 minecraft:moss_block
setblock 236 227 343 minecraft:mushroom_stem
fill 236 227 344 236 230 344 minecraft:moss_block
fill 236 227 346 236 228 346 minecraft:moss_block
setblock 236 227 347 minecraft:red_mushroom_block
setblock 237 227 337 minecraft:mushroom_stem
fill 237 227 338 237 230 338 minecraft:moss_block
setblock 237 227 341 minecraft:moss_block
setblock 237 227 342 minecraft:mushroom_stem
fill 237 227 343 237 230 343 minecraft:moss_block
fill 239 227 322 239 228 322 minecraft:green_terracotta
fill 239 227 323 240 227 323 minecraft:moss_block
setblock 240 227 363 minecraft:moss_block
setblock 241 227 323 minecraft:mushroom_stem
setblock 241 227 363 minecraft:mushroom_stem
setblock 241 227 364 minecraft:moss_block
fill 242 227 323 244 227 324 minecraft:moss_block
fill 242 227 363 245 227 363 minecraft:moss_block
fill 243 227 322 244 228 322 minecraft:green_terracotta
fill 243 227 362 246 227 362 minecraft:moss_block
fill 243 227 364 244 228 364 minecraft:green_terracotta
fill 245 227 322 245 227 323 minecraft:moss_block
setblock 245 227 324 minecraft:mushroom_stem
fill 245 227 325 248 227 325 minecraft:moss_block
setblock 246 227 323 minecraft:mushroom_stem
fill 246 227 324 249 227 324 minecraft:moss_block
setblock 246 227 363 minecraft:mushroom_stem
fill 247 227 323 250 227 323 minecraft:moss_block
setblock 247 227 361 minecraft:moss_block
setblock 247 227 362 minecraft:mushroom_stem
fill 247 227 363 250 227 363 minecraft:moss_block
fill 248 227 362 251 227 362 minecraft:moss_block
fill 248 227 364 248 228 364 minecraft:green_terracotta
setblock 250 227 322 minecraft:moss_block
setblock 250 227 324 minecraft:mushroom_stem
fill 250 227 364 250 228 364 minecraft:green_terracotta
fill 251 227 322 251 228 322 minecraft:green_terracotta
setblock 251 227 323 minecraft:mushroom_stem
fill 251 227 324 251 230 324 minecraft:moss_block
setblock 251 227 363 minecraft:mushroom_stem
fill 252 227 322 252 227 323 minecraft:moss_block
setblock 252 227 362 minecraft:mushroom_stem
fill 252 227 363 255 227 363 minecraft:moss_block
fill 253 227 322 253 228 322 minecraft:green_terracotta
fill 253 227 323 253 228 324 minecraft:moss_block
fill 253 227 362 253 230 362 minecraft:moss_block
fill 254 227 323 255 227 323 minecraft:moss_block
fill 254 227 327 254 232 328 minecraft:dirt
fill 255 227 325 255 232 325 minecraft:dirt
fill 255 227 329 255 232 329 minecraft:dirt
fill 255 227 362 256 227 362 minecraft:moss_block
setblock 256 227 323 minecraft:mushroom_stem
setblock 256 227 363 minecraft:mushroom_stem
setblock 256 227 364 minecraft:moss_block
fill 257 227 323 260 227 323 minecraft:moss_block
fill 257 227 330 257 232 330 minecraft:dirt
setblock 257 227 362 minecraft:mushroom_stem
fill 257 227 363 260 227 363 minecraft:moss_block
fill 257 227 364 258 228 364 minecraft:green_terracotta
fill 258 227 362 261 227 362 minecraft:moss_block
fill 259 227 329 259 232 329 minecraft:dirt
setblock 259 227 364 minecraft:moss_block
fill 260 227 322 260 228 322 minecraft:green_terracotta
fill 260 227 361 262 227 361 minecraft:moss_block
setblock 261 227 323 minecraft:mushroom_stem
setblock 261 227 363 minecraft:mushroom_stem
fill 262 227 322 262 227 324 minecraft:moss_block
fill 262 227 338 262 228 338 minecraft:dirt
fill 262 227 341 262 228 341 minecraft:dirt
setblock 262 227 362 minecraft:mushroom_stem
fill 262 227 363 265 227 363 minecraft:moss_block
fill 263 227 322 264 228 322 minecraft:green_terracotta
fill 263 227 323 264 227 324 minecraft:moss_block
setblock 263 227 360 minecraft:moss_block
setblock 263 227 361 minecraft:mushroom_stem
fill 263 227 362 266 227 362 minecraft:moss_block
fill 263 227 364 263 228 364 minecraft:green_terracotta
setblock 264 227 360 minecraft:mushroom_stem
fill 264 227 361 267 227 361 minecraft:moss_block
setblock 265 227 323 minecraft:moss_block
setblock 265 227 324 minecraft:mushroom_stem
fill 265 227 338 265 228 338 minecraft:dirt
fill 265 227 341 265 228 341 minecraft:dirt
fill 265 227 360 268 227 360 minecraft:moss_block
setblock 266 227 323 minecraft:mushroom_stem
fill 266 227 324 267 229 324 minecraft:moss_block
fill 266 227 339 266 228 340 minecraft:dirt
setblock 266 227 363 minecraft:mushroom_stem
fill 267 227 323 267 230 323 minecraft:moss_block
setblock 267 227 362 minecraft:mushroom_stem
fill 267 227 363 270 227 363 minecraft:moss_block
setblock 268 227 322 minecraft:moss_block
setblock 268 227 361 minecraft:mushroom_stem
fill 268 227 362 271 227 362 minecraft:moss_block
fill 268 227 364 268 229 364 minecraft:green_terracotta
fill 269 227 361 269 230 361 minecraft:moss_block
setblock 271 227 323 minecraft:mushroom_stem
setblock 271 227 363 minecraft:mushroom_stem
setblock 272 227 322 minecraft:moss_block
setblock 272 227 362 minecraft:mushroom_stem
fill 272 227 363 272 230 363 minecraft:moss_block
fill 273 227 362 273 228 362 minecraft:moss_block
fill 275 227 341 275 227 343 minecraft:moss_block
setblock 276 227 337 minecraft:moss_block
setblock 276 227 338 minecraft:mushroom_stem
fill 276 227 339 276 227 342 minecraft:moss_block
setblock 276 227 343 minecraft:mushroom_stem
fill 276 227 344 276 230 344 minecraft:moss_block
setblock 276 227 347 minecraft:moss_block
setblock 276 227 358 minecraft:mushroom_stem
fill 276 227 359 276 229 359 minecraft:moss_block
setblock 276 227 363 minecraft:mushroom_stem
fill 277 227 331 277 228 332 minecraft:green_terracotta
fill 277 227 342 277 228 342 minecraft:green_terracotta
setblock 277 227 343 minecraft:moss_block
fill 277 227 344 277 228 345 minecraft:green_terracotta
setblock 277 227 349 minecraft:moss_block
fill 277 227 350 277 228 350 minecraft:green_terracotta
setblock 277 227 351 minecraft:moss_block
setblock 277 227 360 minecraft:moss_block
fill 277 227 361 277 228 361 minecraft:green_terracotta
fill 235 228 322 236 228 322 minecraft:green_terracotta
setblock 235 228 328 minecraft:green_terracotta
fill 235 228 331 235 228 332 minecraft:green_terracotta
setblock 235 228 340 minecraft:green_terracotta
fill 235 228 345 235 228 346 minecraft:green_terracotta
setblock 235 228 352 minecraft:green_terracotta
setblock 236 228 334 minecraft:red_mushroom_block
fill 236 228 335 236 228 336 minecraft:moss_block
setblock 236 228 337 minecraft:mushroom_stem
fill 236 228 338 236 231 338 minecraft:moss_block
fill 236 228 340 236 228 341 minecraft:moss_block
setblock 236 228 342 minecraft:mushroom_stem
fill 236 228 343 236 231 343 minecraft:moss_block
setblock 236 228 347 minecraft:mushroom_stem
setblock 236 228 353 minecraft:red_mushroom_block
setblock 236 228 364 minecraft:green_terracotta
fill 237 228 337 237 231 337 minecraft:moss_block
setblock 237 228 340 minecraft:moss_block
setblock 237 228 341 minecraft:mushroom_stem
fill 237 228 342 237 231 342 minecraft:moss_block
fill 237 228 344 237 229 344 minecraft:moss_block
fill 238 228 323 239 228 323 minecraft:moss_block
fill 238 228 341 238 231 341 minecraft:moss_block
setblock 239 228 363 minecraft:moss_block
setblock 240 228 323 minecraft:mushroom_stem
fill 240 228 324 243 228 324 minecraft:moss_block
setblock 240 228 363 minecraft:mushroom_stem
fill 241 228 323 244 228 323 minecraft:moss_block
setblock 241 228 362 minecraft:mushroom_stem
fill 241 228 363 244 228 363 minecraft:moss_block
setblock 241 228 364 minecraft:green_terracotta
fill 242 228 362 245 228 362 minecraft:moss_block
setblock 243 228 325 minecraft:mushroom_stem
setblock 244 228 324 minecraft:mushroom_stem
fill 244 228 325 247 228 325 minecraft:moss_block
setblock 245 228 322 minecraft:green_terracotta
setblock 245 228 323 minecraft:mushroom_stem
fill 245 228 324 248 228 324 minecraft:moss_block
fill 245 228 361 246 228 361 minecraft:moss_block
setblock 245 228 363 minecraft:mushroom_stem
fill 246 228 323 249 228 323 minecraft:moss_block
setblock 246 228 362 minecraft:mushroom_stem
fill 246 228 363 249 228 363 minecraft:moss_block
setblock 247 228 361 minecraft:mushroom_stem
fill 247 228 362 250 228 362 minecraft:moss_block
setblock 248 228 325 minecraft:mushroom_stem
fill 248 228 361 248 230 361 minecraft:moss_block
setblock 249 228 324 minecraft:mushroom_stem
fill 249 228 325 249 231 325 minecraft:moss_block
fill 250 228 322 250 229 322 minecraft:green_terracotta
setblock 250 228 323 minecraft:mushroom_stem
fill 250 228 324 250 231 324 minecraft:moss_block
setblock 250 228 363 minecraft:mushroom_stem
fill 251 228 323 252 230 323 minecraft:moss_block
setblock 251 228 362 minecraft:mushroom_stem
fill 251 228 363 254 228 363 minecraft:moss_block
setblock 252 228 322 minecraft:green_terracotta
fill 252 228 362 252 231 362 minecraft:moss_block
setblock 254 228 323 minecraft:moss_block
setblock 254 228 324 minecraft:mushroom_stem
fill 254 228 326 254 232 326 minecraft:dirt
fill 254 228 329 254 232 329 minecraft:dirt
setblock 255 228 323 minecraft:mushroom_stem
fill 255 228 330 256 232 330 minecraft:dirt
setblock 255 228 362 minecraft:moss_block
setblock 255 228 363 minecraft:mushroom_stem
fill 256 228 323 259 228 323 minecraft:moss_block
fill 256 228 324 258 228 324 minecraft:dirt
setblock 256 228 362 minecraft:mushroom_stem
fill 256 228 363 259 228 363 minecraft:moss_block
setblock 256 228 364 minecraft:green_terracotta
fill 257 228 362 260 228 362 minecraft:moss_block
fill 258 228 330 258 232 330 minecraft:dirt
setblock 259 228 324 minecraft:mushroom_stem
fill 259 228 325 259 231 325 minecraft:dirt
fill 259 228 361 261 228 361 minecraft:moss_block
setblock 259 228 364 minecraft:green_terracotta
setblock 260 228 323 minecraft:mushroom_stem
fill 260 228 324 263 228 324 minecraft:moss_block
fill 260 228 326 260 232 328 minecraft:dirt
setblock 260 228 363 minecraft:mushroom_stem
fill 261 228 323 264 228 323 minecraft:moss_block
fill 261 228 338 261 228 341 minecraft:dirt
setblock 261 228 362 minecraft:mushroom_stem
fill 261 228 363 264 228 363 minecraft:moss_block
setblock 262 228 322 minecraft:green_terracotta
fill 262 228 337 265 228 337 minecraft:dirt
fill 262 228 342 265 228 342 minecraft:dirt
setblock 262 228 361 minecraft:mushroom_stem
fill 262 228 362 265 228 362 minecraft:moss_block
setblock 263 228 360 minecraft:mushroom_stem
fill 263 228 361 266 228 361 minecraft:moss_block
setblock 264 228 324 minecraft:mushroom_stem
fill 264 228 360 267 228 360 minecraft:moss_block
setblock 265 228 323 minecraft:mushroom_stem
fill 265 228 324 265 231 324 minecraft:moss_block
setblock 265 228 363 minecraft:mushroom_stem
fill 266 228 323 266 231 323 minecraft:moss_block
setblock 266 228 338 minecraft:dirt
setblock 266 228 341 minecraft:dirt
setblock 266 228 362 minecraft:mushroom_stem
fill 266 228 363 269 228 363 minecraft:moss_block
setblock 267 228 361 minecraft:mushroom_stem
fill 267 228 362 270 228 362 minecraft:moss_block
setblock 268 228 322 minecraft:green_terracotta
fill 268 228 323 268 228 324 minecraft:moss_block
setblock 268 228 360 minecraft:mushroom_stem
fill 268 228 361 268 231 361 minecraft:moss_block
setblock 269 228 323 minecraft:moss_block
setblock 270 228 323 minecraft:mushroom_stem
setblock 270 228 363 minecraft:mushroom_stem
fill 271 228 323 271 231 323 minecraft:moss_block
setblock 271 228 362 minecraft:mushroom_stem
fill 271 228 363 271 231 363 minecraft:moss_block
setblock 272 228 322 minecraft:green_terracotta
fill 272 228 362 272 230 362 minecraft:moss_block
fill 273 228 363 274 228 363 minecraft:moss_block
fill 275 228 340 275 228 342 minecraft:moss_block
setblock 275 228 343 minecraft:mushroom_stem
fill 275 228 344 275 230 345 minecraft:moss_block
setblock 275 228 363 minecraft:mushroom_stem
setblock 276 228 333 minecraft:red_mushroom_block
setblock 276 228 337 minecraft:mushroom_stem
fill 276 228 338 276 228 341 minecraft:moss_block
setblock 276 228 342 minecraft:mushroom_stem
fill 276 228 343 276 231 343 minecraft:moss_block
setblock 276 228 347 minecraft:mushroom_stem
fill 276 228 348 276 231 348 minecraft:moss_block
setblock 276 228 352 minecraft:red_mushroom_block
fill 276 228 360 276 228 361 minecraft:moss_block
setblock 276 228 362 minecraft:mushroom_stem
fill 276 228 363 276 231 363 minecraft:moss_block
setblock 277 228 343 minecraft:green_terracotta
setblock 277 228 349 minecraft:green_terracotta
setblock 277 228 351 minecraft:green_terracotta
fill 277 228 360 277 229 360 minecraft:green_terracotta
fill 235 229 322 235 229 326 minecraft:moss_block
setblock 235 229 327 minecraft:red_mushroom_block
fill 235 229 328 235 229 336 minecraft:moss_block
setblock 235 229 338 minecraft:moss_block
fill 235 229 340 235 229 361 minecraft:moss_block
fill 235 229 363 235 308 363 minecraft:moss_block
fill 236 229 322 236 230 324 minecraft:moss_block
fill 236 229 334 236 229 335 minecraft:moss_block
setblock 236 229 336 minecraft:mushroom_stem
fill 236 229 337 236 232 337 minecraft:moss_block
setblock 236 229 340 minecraft:moss_block
setblock 236 229 341 minecraft:mushroom_stem
fill 236 229 342 236 232 342 minecraft:moss_block
setblock 236 229 346 minecraft:mushroom_stem
fill 236 229 347 236 231 348 minecraft:moss_block
setblock 236 229 359 minecraft:red_mushroom_block
fill 236 229 364 237 279 364 minecraft:moss_block
fill 237 229 322 238 229 323 minecraft:moss_block
setblock 237 229 340 minecraft:mushroom_stem
fill 237 229 341 237 232 341 minecraft:moss_block
setblock 237 229 345 minecraft:mushroom_stem
fill 237 229 363 238 229 363 minecraft:moss_block
setblock 238 229 325 minecraft:light[level=15]
setblock 238 229 333 minecraft:light[level=15]
setblock 238 229 339 minecraft:mushroom_stem
fill 238 229 340 238 232 340 minecraft:moss_block
fill 238 229 342 238 229 343 minecraft:moss_block
setblock 238 229 349 minecraft:light[level=15]
setblock 238 229 357 minecraft:light[level=15]
fill 239 229 322 245 236 322 minecraft:moss_block
setblock 239 229 323 minecraft:mushroom_stem
fill 239 229 324 242 229 324 minecraft:moss_block
setblock 239 229 363 minecraft:mushroom_stem
fill 239 229 364 265 229 364 minecraft:moss_block
fill 240 229 323 243 229 323 minecraft:moss_block
fill 240 229 363 243 229 363 minecraft:moss_block
setblock 241 229 325 minecraft:moss_block
fill 241 229 362 244 229 362 minecraft:moss_block
setblock 242 229 325 minecraft:mushroom_stem
setblock 243 229 324 minecraft:mushroom_stem
fill 243 229 325 246 229 325 minecraft:moss_block
setblock 244 229 323 minecraft:mushroom_stem
fill 244 229 324 247 229 324 minecraft:moss_block
fill 244 229 361 245 229 361 minecraft:moss_block
setblock 244 229 363 minecraft:mushroom_stem
fill 245 229 323 248 229 323 minecraft:moss_block
setblock 245 229 362 minecraft:mushroom_stem
fill 245 229 363 248 229 363 minecraft:moss_block
setblock 246 229 333 minecraft:light[level=15]
setblock 246 229 349 minecraft:light[level=15]
setblock 246 229 357 minecraft:light[level=15]
setblock 246 229 361 minecraft:mushroom_stem
fill 246 229 362 249 229 362 minecraft:moss_block
fill 247 229 322 249 308 322 minecraft:moss_block
setblock 247 229 325 minecraft:mushroom_stem
fill 247 229 361 247 231 361 minecraft:moss_block
setblock 248 229 324 minecraft:mushroom_stem
fill 248 229 325 248 232 325 minecraft:moss_block
setblock 249 229 323 minecraft:mushroom_stem
fill 249 229 324 249 232 324 minecraft:moss_block
setblock 249 229 363 minecraft:mushroom_stem
fill 250 229 323 250 232 323 minecraft:moss_block
fill 250 229 325 250 230 325 minecraft:moss_block
setblock 250 229 362 minecraft:mushroom_stem
fill 250 229 363 253 229 363 minecraft:moss_block
fill 251 229 322 264 229 322 minecraft:moss_block
fill 251 229 362 251 232 362 minecraft:moss_block
setblock 253 229 323 minecraft:moss_block
setblock 253 229 324 minecraft:mushroom_stem
fill 253 229 327 253 232 328 minecraft:dirt
setblock 254 229 323 minecraft:mushroom_stem
fill 254 229 324 257 229 324 minecraft:moss_block
fill 254 229 325 254 232 325 minecraft:dirt
setblock 254 229 333 minecraft:light[level=15]
setblock 254 229 341 minecraft:light[level=15]
setblock 254 229 349 minecraft:light[level=15]
setblock 254 229 357 minecraft:light[level=15]
setblock 254 229 363 minecraft:mushroom_stem
fill 255 229 323 258 229 323 minecraft:moss_block
setblock 255 229 362 minecraft:mushroom_stem
fill 255 229 363 258 229 363 minecraft:moss_block
fill 256 229 362 259 229 362 minecraft:moss_block
fill 257 229 331 257 232 331 minecraft:dirt
setblock 258 229 324 minecraft:mushroom_stem
fill 258 229 361 260 229 361 minecraft:moss_block
setblock 259 229 323 minecraft:mushroom_stem
fill 259 229 324 262 229 324 minecraft:moss_block
fill 259 229 330 259 232 330 minecraft:dirt
setblock 259 229 363 minecraft:mushroom_stem
fill 260 229 323 263 229 323 minecraft:moss_block
fill 260 229 325 260 230 325 minecraft:dirt
fill 260 229 329 260 232 329 minecraft:dirt
setblock 260 229 362 minecraft:mushroom_stem
fill 260 229 363 263 229 363 minecraft:moss_block
setblock 261 229 361 minecraft:mushroom_stem
fill 261 229 362 264 229 362 minecraft:moss_block
setblock 262 229 325 minecraft:light[level=15]
setblock 262 229 333 minecraft:light[level=15]
setblock 262 229 341 minecraft:light[level=15]
setblock 262 229 349 minecraft:light[level=15]
setblock 262 229 357 minecraft:light[level=15]
setblock 262 229 360 minecraft:mushroom_stem
fill 262 229 361 265 229 361 minecraft:moss_block
setblock 263 229 324 minecraft:mushroom_stem
fill 263 229 360 266 229 360 minecraft:moss_block
setblock 264 229 323 minecraft:mushroom_stem
fill 264 229 324 264 232 324 minecraft:moss_block
setblock 264 229 363 minecraft:mushroom_stem
fill 265 229 323 265 232 323 minecraft:moss_block
setblock 265 229 362 minecraft:mushroom_stem
fill 265 229 363 268 229 363 minecraft:moss_block
fill 266 229 322 277 229 322 minecraft:moss_block
setblock 266 229 361 minecraft:mushroom_stem
fill 266 229 362 269 229 362 minecraft:moss_block
setblock 266 229 364 minecraft:green_terracotta
setblock 267 229 360 minecraft:mushroom_stem
fill 267 229 361 267 232 361 minecraft:moss_block
setblock 268 229 323 minecraft:moss_block
setblock 268 229 324 minecraft:mushroom_stem
setblock 269 229 323 minecraft:mushroom_stem
fill 269 229 324 269 231 324 minecraft:moss_block
setblock 269 229 363 minecraft:mushroom_stem
fill 269 229 364 269 230 364 minecraft:green_terracotta
fill 270 229 323 270 232 323 minecraft:moss_block
setblock 270 229 325 minecraft:light[level=15]
setblock 270 229 333 minecraft:light[level=15]
setblock 270 229 341 minecraft:light[level=15]
setblock 270 229 349 minecraft:light[level=15]
setblock 270 229 357 minecraft:light[level=15]
setblock 270 229 361 minecraft:moss_block
setblock 270 229 362 minecraft:mushroom_stem
fill 270 229 363 270 232 364 minecraft:moss_block
fill 271 229 362 271 231 362 minecraft:moss_block
fill 271 229 364 277 229 364 minecraft:moss_block
fill 272 229 323 272 230 323 minecraft:moss_block
setblock 273 229 363 minecraft:moss_block
setblock 274 229 363 minecraft:mushroom_stem
fill 275 229 339 275 229 341 minecraft:moss_block
setblock 275 229 342 minecraft:mushroom_stem
fill 275 229 343 275 232 343 minecraft:moss_block
setblock 275 229 346 minecraft:moss_block
setblock 275 229 347 minecraft:mushroom_stem
fill 275 229 363 275 232 363 minecraft:moss_block
setblock 276 229 327 minecraft:red_mushroom_block
fill 276 229 337 276 229 340 minecraft:moss_block
setblock 276 229 341 minecraft:mushroom_stem
fill 276 229 342 277 232 342 minecraft:moss_block
fill 276 229 345 277 229 345 minecraft:moss_block
setblock 276 229 346 minecraft:mushroom_stem
fill 276 229 347 277 232 347 minecraft:moss_block
fill 276 229 349 277 229 350 minecraft:moss_block
setblock 276 229 360 minecraft:moss_block
setblock 276 229 361 minecraft:mushroom_stem
fill 276 229 362 277 230 362 minecraft:moss_block
fill 277 229 323 277 229 330 minecraft:moss_block
setblock 277 229 331 minecraft:green_terracotta
fill 277 229 332 277 229 336 minecraft:moss_block
fill 277 229 337 277 230 337 minecraft:green_terracotta
fill 277 229 338 277 268 341 minecraft:moss_block
fill 277 229 343 277 256 344 minecraft:moss_block
fill 277 229 346 277 308 346 minecraft:moss_block
fill 277 229 348 277 308 348 minecraft:moss_block
fill 277 229 351 277 308 351 minecraft:moss_block
fill 277 229 353 277 230 359 minecraft:moss_block
fill 277 229 361 277 308 361 minecraft:moss_block
fill 277 229 363 277 246 363 minecraft:moss_block
fill 235 230 322 235 308 323 minecraft:moss_block
setblock 235 230 324 minecraft:green_terracotta
fill 235 230 325 235 230 327 minecraft:moss_block
fill 235 230 328 235 230 329 minecraft:green_terracotta
fill 235 230 330 235 230 332 minecraft:moss_block
setblock 235 230 333 minecraft:green_terracotta
fill 235 230 334 235 255 337 minecraft:moss_block
setblock 235 230 338 minecraft:shroomlight
fill 235 230 339 235 244 343 minecraft:moss_block
setblock 235 230 344 minecraft:green_terracotta
fill 235 230 345 235 230 362 minecraft:moss_block
fill 235 230 364 235 308 364 minecraft:moss_block
setblock 236 230 325 minecraft:mushroom_stem
fill 236 230 326 236 231 328 minecraft:moss_block
fill 236 230 333 236 230 334 minecraft:moss_block
setblock 236 230 335 minecraft:mushroom_stem
fill 236 230 336 237 232 336 minecraft:moss_block
setblock 236 230 339 minecraft:moss_block
setblock 236 230 340 minecraft:mushroom_stem
fill 236 230 341 236 233 341 minecraft:moss_block
setblock 236 230 345 minecraft:mushroom_stem
fill 236 230 346 237 232 346 minecraft:moss_block
fill 236 230 363 237 230 363 minecraft:moss_block
fill 237 230 322 237 230 323 minecraft:moss_block
setblock 237 230 324 minecraft:mushroom_stem
fill 237 230 332 237 233 332 minecraft:dirt
setblock 237 230 339 minecraft:mushroom_stem
fill 237 230 340 237 233 340 minecraft:moss_block
setblock 237 230 344 minecraft:mushroom_stem
fill 237 230 345 237 233 345 minecraft:moss_block
fill 238 230 322 238 305 322 minecraft:moss_block
setblock 238 230 323 minecraft:mushroom_stem
fill 238 230 324 241 230 324 minecraft:moss_block
fill 238 230 339 238 232 339 minecraft:moss_block
setblock 238 230 342 minecraft:moss_block
setblock 238 230 343 minecraft:mushroom_stem
fill 238 230 344 238 233 344 minecraft:moss_block
setblock 238 230 363 minecraft:mushroom_stem
fill 239 230 323 242 230 323 minecraft:moss_block
fill 239 230 363 239 233 364 minecraft:moss_block
setblock 240 230 325 minecraft:moss_block
fill 240 230 362 242 230 363 minecraft:moss_block
setblock 240 230 364 minecraft:green_terracotta
setblock 241 230 325 minecraft:mushroom_stem
fill 241 230 364 260 230 364 minecraft:moss_block
setblock 242 230 324 minecraft:mushroom_stem
fill 242 230 325 245 230 325 minecraft:moss_block
setblock 243 230 323 minecraft:mushroom_stem
fill 243 230 324 246 230 324 minecraft:moss_block
fill 243 230 326 244 230 326 minecraft:moss_block
setblock 243 230 362 minecraft:moss_block
setblock 243 230 363 minecraft:mushroom_stem
fill 244 230 323 247 230 323 minecraft:moss_block
setblock 244 230 361 minecraft:moss_block
setblock 244 230 362 minecraft:mushroom_stem
fill 244 230 363 247 230 363 minecraft:moss_block
setblock 245 230 326 minecraft:mushroom_stem
setblock 245 230 361 minecraft:mushroom_stem
fill 245 230 362 248 230 362 minecraft:moss_block
fill 246 230 322 246 308 322 minecraft:moss_block
setblock 246 230 325 minecraft:mushroom_stem
fill 246 230 326 247 232 326 minecraft:moss_block
fill 246 230 361 246 231 361 minecraft:moss_block
setblock 247 230 324 minecraft:mushroom_stem
fill 247 230 325 247 233 325 minecraft:moss_block
setblock 248 230 323 minecraft:mushroom_stem
fill 248 230 324 248 233 324 minecraft:moss_block
setblock 248 230 363 minecraft:mushroom_stem
fill 249 230 323 249 233 323 minecraft:moss_block
setblock 249 230 362 minecraft:mushroom_stem
fill 249 230 363 252 230 363 minecraft:moss_block
fill 250 230 322 250 308 322 minecraft:moss_block
fill 250 230 362 250 233 362 minecraft:moss_block
setblock 251 230 322 minecraft:green_terracotta
setblock 251 230 325 minecraft:mushroom_stem
fill 252 230 322 262 230 322 minecraft:moss_block
setblock 252 230 324 minecraft:mushroom_stem
setblock 253 230 323 minecraft:mushroom_stem
fill 253 230 324 256 230 324 minecraft:moss_block
fill 253 230 325 253 232 326 minecraft:dirt
fill 253 230 329 253 232 329 minecraft:dirt
setblock 253 230 363 minecraft:mushroom_stem
fill 254 230 323 257 230 323 minecraft:moss_block
fill 254 230 330 254 232 330 minecraft:dirt
setblock 254 230 362 minecraft:mushroom_stem
fill 254 230 363 257 230 363 minecraft:moss_block
fill 255 230 331 256 232 331 minecraft:dirt
fill 255 230 362 258 230 362 minecraft:moss_block
setblock 257 230 324 minecraft:mushroom_stem
setblock 258 230 323 minecraft:mushroom_stem
fill 258 230 324 261 230 324 minecraft:moss_block
fill 258 230 331 258 232 331 minecraft:dirt
fill 258 230 361 259 230 361 minecraft:moss_block
setblock 258 230 363 minecraft:mushroom_stem
fill 259 230 323 262 230 323 minecraft:moss_block
setblock 259 230 362 minecraft:mushroom_stem
fill 259 230 363 262 230 363 minecraft:moss_block
fill 260 230 330 260 232 330 minecraft:dirt
setblock 260 230 361 minecraft:mushroom_stem
fill 260 230 362 263 230 362 minecraft:moss_block
fill 261 230 326 261 232 328 minecraft:dirt
fill 261 230 361 264 230 361 minecraft:moss_block
setblock 261 230 364 minecraft:shroomlight
setblock 262 230 324 minecraft:mushroom_stem
fill 262 230 325 265 230 325 minecraft:moss_block
fill 262 230 360 265 230 360 minecraft:moss_block
fill 262 230 364 268 230 364 minecraft:moss_block
setblock 263 230 322 minecraft:green_terracotta
setblock 263 230 323 minecraft:mushroom_stem
fill 263 230 324 263 233 324 minecraft:moss_block
setblock 263 230 363 minecraft:mushroom_stem
fill 264 230 322 264 233 323 minecraft:moss_block
setblock 264 230 362 minecraft:mushroom_stem
fill 264 230 363 267 230 363 minecraft:moss_block
setblock 265 230 361 minecraft:mushroom_stem
fill 265 230 362 268 230 362 minecraft:moss_block
fill 266 230 322 268 239 322 minecraft:moss_block
setblock 266 230 324 minecraft:moss_block
fill 266 230 357 266 249 357 minecraft:red_mushroom_block
setblock 266 230 360 minecraft:mushroom_stem
fill 266 230 361 266 233 361 minecraft:moss_block
setblock 267 230 324 minecraft:mushroom_stem
setblock 267 230 360 minecraft:moss_block
setblock 268 230 323 minecraft:mushroom_stem
fill 268 230 324 268 233 324 minecraft:moss_block
setblock 268 230 363 minecraft:mushroom_stem
setblock 269 230 322 minecraft:green_terracotta
fill 269 230 323 269 233 323 minecraft:moss_block
setblock 269 230 362 minecraft:mushroom_stem
fill 269 230 363 269 233 363 minecraft:moss_block
fill 270 230 322 271 239 322 minecraft:moss_block
fill 270 230 362 270 232 362 minecraft:moss_block
fill 271 230 364 272 308 364 minecraft:moss_block
setblock 272 230 322 minecraft:green_terracotta
fill 273 230 322 276 252 322 minecraft:moss_block
setblock 273 230 363 minecraft:mushroom_stem
setblock 273 230 364 minecraft:green_terracotta
setblock 274 230 323 minecraft:red_mushroom_block
fill 274 230 363 274 232 364 minecraft:moss_block
fill 275 230 339 275 230 340 minecraft:moss_block
setblock 275 230 341 minecraft:mushroom_stem
fill 275 230 342 275 233 342 minecraft:moss_block
setblock 275 230 346 minecraft:mushroom_stem
fill 275 230 347 275 232 348 minecraft:moss_block
fill 275 230 364 277 230 364 minecraft:moss_block
fill 276 230 337 276 230 339 minecraft:moss_block
setblock 276 230 340 minecraft:mushroom_stem
fill 276 230 341 276 233 341 minecraft:moss_block
setblock 276 230 345 minecraft:mushroom_stem
fill 276 230 346 276 233 346 minecraft:moss_block
fill 276 230 349 277 230 349 minecraft:moss_block
setblock 276 230 350 minecraft:mushroom_stem
fill 276 230 351 276 233 351 minecraft:moss_block
setblock 276 230 360 minecraft:mushroom_stem
fill 276 230 361 276 231 361 minecraft:moss_block
fill 277 230 322 277 230 323 minecraft:green_terracotta
fill 277 230 324 277 230 327 minecraft:moss_block
fill 277 230 328 277 230 329 minecraft:green_terracotta
fill 277 230 330 277 230 333 minecraft:moss_block
setblock 277 230 334 minecraft:green_terracotta
fill 277 230 335 277 242 336 minecraft:moss_block
fill 277 230 345 277 300 345 minecraft:moss_block
fill 277 230 350 277 308 350 minecraft:moss_block
fill 277 230 352 277 301 352 minecraft:moss_block
fill 277 230 360 277 263 360 minecraft:moss_block
fill 235 231 324 235 268 326 minecraft:moss_block
setblock 235 231 327 minecraft:green_terracotta
fill 235 231 328 235 308 329 minecraft:moss_block
setblock 235 231 330 minecraft:green_terracotta
fill 235 231 331 236 231 333 minecraft:moss_block
fill 235 231 338 235 308 338 minecraft:moss_block
fill 235 231 344 235 308 344 minecraft:moss_block
setblock 235 231 345 minecraft:green_terracotta
fill 235 231 346 235 236 361 minecraft:moss_block
setblock 235 231 362 minecraft:green_terracotta
fill 236 231 322 236 231 323 minecraft:moss_block
setblock 236 231 324 minecraft:mushroom_stem
fill 236 231 325 237 233 325 minecraft:moss_block
setblock 236 231 329 minecraft:mushroom_stem
fill 236 231 330 236 234 330 minecraft:moss_block
setblock 236 231 334 minecraft:mushroom_stem
fill 236 231 335 236 234 335 minecraft:moss_block
setblock 236 231 339 minecraft:mushroom_stem
fill 236 231 340 236 234 340 minecraft:moss_block
setblock 236 231 344 minecraft:mushroom_stem
fill 236 231 345 236 234 345 minecraft:moss_block
setblock 236 231 349 minecraft:mushroom_stem
setblock 236 231 352 minecraft:red_mushroom_block
setblock 236 231 363 minecraft:moss_block
setblock 237 231 322 minecraft:green_terracotta
setblock 237 231 323 minecraft:mushroom_stem
fill 237 231 324 240 231 324 minecraft:moss_block
fill 237 231 326 237 231 327 minecraft:moss_block
setblock 237 231 338 minecraft:mushroom_stem
fill 237 231 339 237 234 339 minecraft:moss_block
setblock 237 231 343 minecraft:mushroom_stem
fill 237 231 344 237 234 344 minecraft:moss_block
setblock 237 231 347 minecraft:moss_block
setblock 237 231 363 minecraft:mushroom_stem
fill 238 231 323 241 231 323 minecraft:moss_block
setblock 238 231 325 minecraft:light[level=12]
setblock 238 231 332 minecraft:light[level=12]
setblock 238 231 342 minecraft:mushroom_stem
fill 238 231 343 238 234 343 minecraft:moss_block
fill 238 231 345 238 232 345 minecraft:moss_block
setblock 238 231 346 minecraft:light[level=12]
setblock 238 231 353 minecraft:light[level=12]
setblock 238 231 360 minecraft:light[level=12]
fill 238 231 363 238 234 364 minecraft:moss_block
setblock 239 231 325 minecraft:moss_block
setblock 240 231 325 minecraft:mushroom_stem
fill 240 231 362 241 231 364 minecraft:moss_block
setblock 241 231 324 minecraft:mushroom_stem
fill 241 231 325 243 231 326 minecraft:moss_block
setblock 242 231 323 minecraft:mushroom_stem
fill 242 231 324 245 231 324 minecraft:moss_block
setblock 242 231 362 minecraft:moss_block
setblock 242 231 363 minecraft:mushroom_stem
fill 242 231 364 248 244 364 minecraft:moss_block
fill 243 231 323 246 231 323 minecraft:moss_block
setblock 243 231 362 minecraft:mushroom_stem
fill 243 231 363 246 231 363 minecraft:moss_block
setblock 244 231 325 minecraft:moss_block
fill 244 231 326 244 231 328 minecraft:mushroom_stem
setblock 244 231 361 minecraft:mushroom_stem
fill 244 231 362 247 231 362 minecraft:moss_block
setblock 245 231 325 minecraft:mushroom_stem
fill 245 231 326 245 234 326 minecraft:moss_block
fill 245 231 327 246 269 328 minecraft:mushroom_stem
setblock 245 231 332 minecraft:light[level=12]
setblock 245 231 339 minecraft:light[level=12]
setblock 245 231 360 minecraft:light[level=12]
setblock 245 231 361 minecraft:moss_block
setblock 246 231 324 minecraft:mushroom_stem
fill 246 231 325 246 234 325 minecraft:moss_block
setblock 247 231 323 minecraft:mushroom_stem
fill 247 231 324 247 234 324 minecraft:moss_block
setblock 247 231 363 minecraft:mushroom_stem
fill 248 231 323 248 234 323 minecraft:moss_block
setblock 248 231 362 minecraft:mushroom_stem
fill 248 231 363 251 231 363 minecraft:moss_block
fill 249 231 362 249 233 362 minecraft:moss_block
setblock 249 231 364 minecraft:green_terracotta
setblock 250 231 325 minecraft:mushroom_stem
fill 250 231 364 259 237 364 minecraft:moss_block
fill 251 231 322 251 231 323 minecraft:moss_block
setblock 251 231 324 minecraft:mushroom_stem
fill 251 231 325 251 232 325 minecraft:moss_block
fill 252 231 322 256 238 322 minecraft:moss_block
setblock 252 231 323 minecraft:mushroom_stem
fill 252 231 324 255 231 324 minecraft:moss_block
setblock 252 231 325 minecraft:light[level=12]
fill 252 231 326 252 232 328 minecraft:dirt
setblock 252 231 332 minecraft:light[level=12]
setblock 252 231 353 minecraft:light[level=12]
setblock 252 231 360 minecraft:light[level=12]
setblock 252 231 363 minecraft:mushroom_stem
fill 253 231 323 256 231 323 minecraft:moss_block
fill 253 231 330 253 232 330 minecraft:dirt
setblock 253 231 362 minecraft:mushroom_stem
fill 253 231 363 256 231 363 minecraft:moss_block
fill 254 231 331 254 232 331 minecraft:dirt
fill 254 231 362 257 231 362 minecraft:moss_block
setblock 256 231 324 minecraft:mushroom_stem
setblock 257 231 322 minecraft:green_terracotta
setblock 257 231 323 minecraft:mushroom_stem
fill 257 231 324 260 231 324 minecraft:moss_block
fill 257 231 332 257 232 332 minecraft:dirt
setblock 257 231 363 minecraft:mushroom_stem
fill 258 231 322 259 233 323 minecraft:moss_block
setblock 258 231 361 minecraft:moss_block
setblock 258 231 362 minecraft:mushroom_stem
fill 258 231 363 261 231 363 minecraft:moss_block
fill 259 231 331 259 232 331 minecraft:dirt
setblock 259 231 332 minecraft:light[level=12]
setblock 259 231 339 minecraft:light[level=12]
setblock 259 231 360 minecraft:light[level=12]
setblock 259 231 361 minecraft:mushroom_stem
fill 259 231 362 262 231 362 minecraft:moss_block
setblock 260 231 322 minecraft:green_terracotta
fill 260 231 323 261 231 323 minecraft:moss_block
setblock 260 231 325 minecraft:mushroom_stem
fill 260 231 361 263 231 361 minecraft:moss_block
setblock 260 231 364 minecraft:green_terracotta
fill 261 231 322 263 235 322 minecraft:moss_block
setblock 261 231 324 minecraft:mushroom_stem
fill 261 231 325 264 231 325 minecraft:moss_block
fill 261 231 329 261 232 329 minecraft:dirt
fill 261 231 364 261 234 364 minecraft:moss_block
setblock 262 231 323 minecraft:mushroom_stem
fill 262 231 324 262 234 324 minecraft:moss_block
fill 262 231 360 264 231 360 minecraft:moss_block
setblock 262 231 363 minecraft:mushroom_stem
setblock 262 231 364 minecraft:green_terracotta
fill 263 231 323 263 234 323 minecraft:moss_block
setblock 263 231 362 minecraft:mushroom_stem
fill 263 231 363 266 231 364 minecraft:moss_block
setblock 264 231 361 minecraft:mushroom_stem
fill 264 231 362 267 231 362 minecraft:moss_block
setblock 265 231 325 minecraft:mushroom_stem
setblock 265 231 360 minecraft:mushroom_stem
fill 265 231 361 265 233 361 minecraft:moss_block
setblock 266 231 324 minecraft:mushroom_stem
setblock 266 231 325 minecraft:light[level=12]
setblock 266 231 332 minecraft:light[level=12]
setblock 266 231 339 minecraft:light[level=12]
setblock 266 231 346 minecraft:light[level=12]
setblock 266 231 353 minecraft:light[level=12]
setblock 266 231 360 minecraft:moss_block
setblock 267 231 323 minecraft:mushroom_stem
fill 267 231 324 267 234 324 minecraft:moss_block
setblock 267 231 363 minecraft:mushroom_stem
setblock 267 231 364 minecraft:green_terracotta
fill 268 231 323 268 234 323 minecraft:moss_block
setblock 268 231 362 minecraft:mushroom_stem
fill 268 231 363 268 234 364 minecraft:moss_block
fill 269 231 322 269 308 322 minecraft:moss_block
setblock 269 231 361 minecraft:mushroom_stem
fill 269 231 362 269 233 362 minecraft:moss_block
fill 269 231 364 269 308 364 minecraft:moss_block
fill 272 231 322 272 301 322 minecraft:moss_block
setblock 272 231 323 minecraft:mushroom_stem
setblock 272 231 363 minecraft:mushroom_stem
fill 273 231 323 273 232 323 minecraft:moss_block
setblock 273 231 325 minecraft:light[level=12]
setblock 273 231 332 minecraft:light[level=12]
setblock 273 231 339 minecraft:light[level=12]
setblock 273 231 346 minecraft:light[level=12]
setblock 273 231 353 minecraft:light[level=12]
setblock 273 231 360 minecraft:light[level=12]
fill 273 231 363 273 232 364 minecraft:moss_block
fill 274 231 343 274 231 345 minecraft:moss_block
fill 275 231 323 277 231 323 minecraft:moss_block
setblock 275 231 339 minecraft:moss_block
setblock 275 231 340 minecraft:mushroom_stem
fill 275 231 341 275 234 341 minecraft:moss_block
setblock 275 231 344 minecraft:moss_block
setblock 275 231 345 minecraft:mushroom_stem
fill 275 231 346 275 234 346 minecraft:moss_block
setblock 275 231 349 minecraft:moss_block
setblock 275 231 364 minecraft:green_terracotta
setblock 276 231 324 minecraft:mushroom_stem
setblock 276 231 334 minecraft:red_mushroom_block
fill 276 231 336 276 231 338 minecraft:moss_block
setblock 276 231 339 minecraft:mushroom_stem
fill 276 231 340 276 234 340 minecraft:moss_block
setblock 276 231 344 minecraft:mushroom_stem
fill 276 231 345 276 234 345 minecraft:moss_block
setblock 276 231 349 minecraft:mushroom_stem
fill 276 231 350 276 234 350 minecraft:moss_block
fill 276 231 352 276 232 352 minecraft:moss_block
fill 276 231 359 277 231 359 minecraft:red_mushroom_block
fill 276 231 362 276 232 362 minecraft:moss_block
fill 276 231 364 276 308 364 minecraft:moss_block
fill 277 231 322 277 308 322 minecraft:moss_block
fill 277 231 324 277 266 326 minecraft:moss_block
setblock 277 231 327 minecraft:green_terracotta
fill 277 231 328 277 273 328 minecraft:moss_block
setblock 277 231 329 minecraft:green_terracotta
fill 277 231 330 277 237 331 minecraft:moss_block
setblock 277 231 332 minecraft:green_terracotta
fill 277 231 333 277 292 334 minecraft:moss_block
fill 277 231 337 277 308 337 minecraft:moss_block
fill 277 231 349 277 243 349 minecraft:moss_block
setblock 277 231 353 minecraft:green_terracotta
fill 277 231 354 277 271 358 minecraft:moss_block
setblock 277 231 362 minecraft:red_mushroom_block
setblock 277 231 364 minecraft:green_terracotta
fill 235 232 327 236 232 327 minecraft:moss_block
fill 235 232 330 235 253 333 minecraft:moss_block
fill 235 232 345 235 308 345 minecraft:moss_block
fill 235 232 362 235 281 362 minecraft:moss_block
fill 236 232 322 237 308 322 minecraft:moss_block
setblock 236 232 323 minecraft:mushroom_stem
fill 236 232 324 239 232 324 minecraft:moss_block
fill 236 232 326 237 232 326 minecraft:moss_block
setblock 236 232 328 minecraft:mushroom_stem
fill 236 232 329 237 234 329 minecraft:moss_block
fill 236 232 331 236 232 332 minecraft:moss_block
setblock 236 232 333 minecraft:mushroom_stem
fill 236 232 334 236 235 334 minecraft:moss_block
setblock 236 232 338 minecraft:mushroom_stem
fill 236 232 339 236 235 339 minecraft:moss_block
setblock 236 232 343 minecraft:mushroom_stem
fill 236 232 344 236 235 344 minecraft:moss_block
setblock 236 232 347 minecraft:moss_block
setblock 236 232 348 minecraft:mushroom_stem
fill 236 232 349 236 234 350 minecraft:moss_block
setblock 236 232 358 minecraft:red_mushroom_block
setblock 236 232 363 minecraft:mushroom_stem
fill 237 232 323 240 232 323 minecraft:moss_block
setblock 237 232 327 minecraft:mushroom_stem
fill 237 232 328 237 235 328 minecraft:moss_block
setblock 237 232 337 minecraft:mushroom_stem
fill 237 232 338 237 234 338 minecraft:moss_block
setblock 237 232 342 minecraft:mushroom_stem
fill 237 232 343 237 235 343 minecraft:moss_block
setblock 237 232 347 minecraft:mushroom_stem
fill 237 232 348 237 235 348 minecraft:moss_block
fill 237 232 363 237 235 363 minecraft:moss_block
setblock 238 232 325 minecraft:moss_block
setblock 238 232 326 minecraft:mushroom_stem
fill 238 232 327 238 235 327 minecraft:moss_block
setblock 238 232 341 minecraft:mushroom_stem
fill 238 232 342 238 234 342 minecraft:moss_block
setblock 238 232 346 minecraft:mushroom_stem
setblock 239 232 325 minecraft:mushroom_stem
setblock 240 232 324 minecraft:mushroom_stem
fill 240 232 325 242 232 326 minecraft:moss_block
fill 240 232 362 240 232 364 minecraft:moss_block
setblock 241 232 323 minecraft:mushroom_stem
fill 241 232 324 244 232 324 minecraft:moss_block
setblock 241 232 362 minecraft:moss_block
setblock 241 232 363 minecraft:mushroom_stem
fill 241 232 364 241 308 364 minecraft:moss_block
fill 242 232 323 245 232 323 minecraft:moss_block
setblock 242 232 362 minecraft:mushroom_stem
fill 242 232 363 245 232 363 minecraft:moss_block
setblock 243 232 325 minecraft:moss_block
setblock 243 232 326 minecraft:mushroom_stem
fill 243 232 327 243 233 327 minecraft:dirt
fill 243 232 362 246 232 362 minecraft:moss_block
setblock 244 232 325 minecraft:mushroom_stem
fill 244 232 326 244 235 326 minecraft:moss_block
fill 244 232 327 244 269 328 minecraft:mushroom_stem
setblock 245 232 324 minecraft:mushroom_stem
fill 245 232 325 245 235 325 minecraft:moss_block
fill 245 232 329 245 233 329 minecraft:dirt
setblock 246 232 323 minecraft:mushroom_stem
fill 246 232 324 246 235 324 minecraft:moss_block
setblock 246 232 363 minecraft:mushroom_stem
fill 247 232 323 247 235 323 minecraft:moss_block
fill 247 232 327 247 233 327 minecraft:dirt
setblock 247 232 362 minecraft:mushroom_stem
fill 247 232 363 250 232 363 minecraft:moss_block
fill 248 232 362 248 234 362 minecraft:moss_block
setblock 249 232 325 minecraft:mushroom_stem
fill 249 232 364 249 308 364 minecraft:moss_block
setblock 250 232 324 minecraft:mushroom_stem
fill 250 232 325 250 233 325 minecraft:moss_block
fill 251 232 322 251 278 322 minecraft:moss_block
setblock 251 232 323 minecraft:mushroom_stem
fill 251 232 324 254 232 324 minecraft:moss_block
setblock 251 232 363 minecraft:mushroom_stem
fill 252 232 323 255 232 323 minecraft:moss_block
setblock 252 232 325 minecraft:dirt
setblock 252 232 329 minecraft:dirt
setblock 252 232 362 minecraft:mushroom_stem
fill 252 232 363 255 232 363 minecraft:moss_block
fill 253 232 362 256 232 362 minecraft:moss_block
setblock 255 232 324 minecraft:mushroom_stem
fill 255 232 332 256 232 332 minecraft:dirt
setblock 256 232 323 minecraft:mushroom_stem
fill 256 232 324 259 232 324 minecraft:moss_block
setblock 256 232 363 minecraft:mushroom_stem
fill 257 232 322 257 235 323 minecraft:moss_block
setblock 257 232 362 minecraft:mushroom_stem
fill 257 232 363 260 232 363 minecraft:moss_block
fill 258 232 332 259 232 332 minecraft:dirt
setblock 258 232 361 minecraft:mushroom_stem
fill 258 232 362 261 232 362 minecraft:moss_block
setblock 259 232 325 minecraft:mushroom_stem
fill 259 232 361 262 232 361 minecraft:moss_block
fill 260 232 322 260 232 323 minecraft:moss_block
setblock 260 232 324 minecraft:mushroom_stem
fill 260 232 325 263 232 325 minecraft:moss_block
setblock 260 232 331 minecraft:dirt
fill 260 232 364 260 254 364 minecraft:moss_block
setblock 261 232 323 minecraft:mushroom_stem
fill 261 232 324 261 235 324 minecraft:moss_block
setblock 261 232 330 minecraft:dirt
setblock 261 232 363 minecraft:mushroom_stem
fill 262 232 323 262 235 323 minecraft:moss_block
fill 262 232 326 262 232 328 minecraft:dirt
fill 262 232 360 263 232 360 minecraft:moss_block
setblock 262 232 362 minecraft:mushroom_stem
fill 262 232 363 265 232 364 minecraft:moss_block
setblock 263 232 361 minecraft:mushroom_stem
fill 263 232 362 266 232 362 minecraft:moss_block
setblock 264 232 325 minecraft:mushroom_stem
setblock 264 232 360 minecraft:mushroom_stem
fill 264 232 361 264 234 361 minecraft:moss_block
fill 265 232 322 265 308 322 minecraft:moss_block
setblock 265 232 324 minecraft:mushroom_stem
fill 265 232 325 265 233 325 minecraft:moss_block
setblock 266 232 323 minecraft:mushroom_stem
fill 266 232 324 266 235 324 minecraft:moss_block
setblock 266 232 363 minecraft:mushroom_stem
fill 266 232 364 267 271 364 minecraft:moss_block
fill 267 232 323 267 235 323 minecraft:moss_block
setblock 267 232 362 minecraft:mushroom_stem
fill 267 232 363 267 235 363 minecraft:moss_block
fill 268 232 362 268 233 362 minecraft:moss_block
setblock 271 232 323 minecraft:mushroom_stem
setblock 271 232 363 minecraft:mushroom_stem
setblock 272 232 323 minecraft:moss_block
fill 272 232 363 272 233 363 minecraft:moss_block
fill 274 232 323 275 232 323 minecraft:moss_block
fill 274 232 343 274 232 344 minecraft:moss_block
setblock 274 232 345 minecraft:mushroom_stem
fill 274 232 346 274 233 346 minecraft:moss_block
fill 275 232 340 275 233 340 minecraft:moss_block
setblock 275 232 344 minecraft:mushroom_stem
fill 275 232 345 275 235 345 minecraft:moss_block
setblock 275 232 349 minecraft:mushroom_stem
fill 275 232 364 275 279 364 minecraft:moss_block
setblock 276 232 323 minecraft:mushroom_stem
fill 276 232 324 276 233 326 minecraft:moss_block
setblock 276 232 328 minecraft:red_mushroom_block
fill 276 232 336 276 232 337 minecraft:moss_block
setblock 276 232 338 minecraft:mushroom_stem
fill 276 232 339 276 235 339 minecraft:moss_block
setblock 276 232 343 minecraft:mushroom_stem
fill 276 232 344 276 235 344 minecraft:moss_block
setblock 276 232 348 minecraft:mushroom_stem
fill 276 232 349 276 235 349 minecraft:moss_block
setblock 276 232 353 minecraft:red_mushroom_block
setblock 276 232 363 minecraft:mushroom_stem
fill 277 232 323 277 238 323 minecraft:moss_block
fill 277 232 327 277 308 327 minecraft:moss_block
fill 277 232 329 277 308 329 minecraft:moss_block
fill 277 232 332 277 259 332 minecraft:moss_block
fill 277 232 353 277 308 353 minecraft:moss_block
fill 277 232 359 277 308 359 minecraft:moss_block
fill 277 232 362 277 234 362 minecraft:moss_block
fill 277 232 364 277 308 364 minecraft:moss_block
fill 235 233 327 235 308 327 minecraft:moss_block
fill 236 233 323 238 233 324 minecraft:moss_block
setblock 236 233 326 minecraft:moss_block
setblock 236 233 327 minecraft:mushroom_stem
fill 236 233 328 236 236 328 minecraft:moss_block
setblock 236 233 331 minecraft:moss_block
setblock 236 233 332 minecraft:mushroom_stem
fill 236 233 333 236 236 333 minecraft:moss_block
setblock 236 233 336 minecraft:moss_block
setblock 236 233 337 minecraft:mushroom_stem
fill 236 233 338 236 236 338 minecraft:moss_block
setblock 236 233 342 minecraft:mushroom_stem
fill 236 233 343 236 236 343 minecraft:moss_block
setblock 236 233 346 minecraft:moss_block
setblock 236 233 347 minecraft:mushroom_stem
fill 236 233 348 236 236 348 minecraft:moss_block
setblock 236 233 363 minecraft:moss_block
setblock 237 233 326 minecraft:mushroom_stem
fill 237 233 327 237 236 327 minecraft:moss_block
setblock 237 233 330 minecraft:moss_block
setblock 237 233 331 minecraft:mushroom_stem
fill 237 233 333 237 234 333 minecraft:dirt
setblock 237 233 337 minecraft:moss_block
setblock 237 233 341 minecraft:mushroom_stem
fill 237 233 342 237 236 342 minecraft:moss_block
setblock 237 233 346 minecraft:mushroom_stem
fill 237 233 347 237 236 347 minecraft:moss_block
setblock 238 233 325 minecraft:mushroom_stem
fill 238 233 326 238 236 326 minecraft:moss_block
fill 238 233 328 238 234 328 minecraft:moss_block
fill 238 233 332 238 237 332 minecraft:dirt
setblock 238 233 340 minecraft:mushroom_stem
setblock 238 233 341 minecraft:moss_block
setblock 238 233 345 minecraft:mushroom_stem
fill 238 233 346 238 234 346 minecraft:moss_block
setblock 239 233 323 minecraft:moss_block
setblock 239 233 324 minecraft:mushroom_stem
fill 239 233 325 242 233 325 minecraft:moss_block
setblock 240 233 323 minecraft:mushroom_stem
fill 240 233 324 243 233 324 minecraft:moss_block
fill 240 233 326 241 233 326 minecraft:moss_block
setblock 240 233 362 minecraft:moss_block
setblock 240 233 363 minecraft:mushroom_stem
fill 240 233 364 240 241 364 minecraft:moss_block
fill 241 233 323 244 233 323 minecraft:moss_block
setblock 241 233 362 minecraft:mushroom_stem
fill 241 233 363 244 233 363 minecraft:moss_block
setblock 242 233 326 minecraft:mushroom_stem
fill 242 233 362 245 233 362 minecraft:moss_block
setblock 243 233 325 minecraft:mushroom_stem
fill 243 233 326 243 236 326 minecraft:moss_block
setblock 243 233 328 minecraft:dirt
setblock 244 233 324 minecraft:mushroom_stem
fill 244 233 325 244 236 325 minecraft:moss_block
setblock 244 233 329 minecraft:dirt
fill 244 233 345 245 233 345 minecraft:stone_bricks
fill 244 233 347 244 233 348 minecraft:stone_bricks
setblock 245 233 323 minecraft:mushroom_stem
fill 245 233 324 245 236 324 minecraft:moss_block
fill 245 233 346 245 233 347 minecraft:stone_bricks
setblock 245 233 363 minecraft:mushroom_stem
fill 246 233 323 246 236 323 minecraft:moss_block
setblock 246 233 326 minecraft:moss_block
setblock 246 233 329 minecraft:dirt
setblock 246 233 362 minecraft:mushroom_stem
fill 246 233 363 249 233 363 minecraft:moss_block
setblock 247 233 326 minecraft:mushroom_stem
setblock 247 233 328 minecraft:dirt
fill 247 233 362 247 234 362 minecraft:moss_block
setblock 248 233 325 minecraft:mushroom_stem
setblock 249 233 324 minecraft:mushroom_stem
fill 249 233 325 249 234 325 minecraft:moss_block
fill 249 233 340 250 233 340 minecraft:stone_bricks
setblock 249 233 353 minecraft:stone_bricks
setblock 250 233 323 minecraft:mushroom_stem
fill 250 233 324 253 233 324 minecraft:moss_block
setblock 250 233 339 minecraft:stone_bricks
setblock 250 233 363 minecraft:mushroom_stem
fill 251 233 323 254 233 323 minecraft:moss_block
fill 251 233 354 252 233 355 minecraft:stone_bricks
setblock 251 233 362 minecraft:mushroom_stem
fill 251 233 363 254 233 363 minecraft:moss_block
fill 252 233 362 255 233 362 minecraft:moss_block
fill 253 233 339 254 233 340 minecraft:stone_bricks
setblock 254 233 324 minecraft:mushroom_stem
setblock 255 233 323 minecraft:mushroom_stem
fill 255 233 324 258 233 324 minecraft:moss_block
setblock 255 233 363 minecraft:mushroom_stem
fill 256 233 323 256 236 323 minecraft:moss_block
setblock 256 233 362 minecraft:mushroom_stem
fill 256 233 363 259 233 363 minecraft:moss_block
fill 257 233 327 257 236 327 minecraft:mushroom_stem
fill 257 233 362 260 233 362 minecraft:moss_block
setblock 258 233 325 minecraft:mushroom_stem
fill 258 233 361 261 233 361 minecraft:moss_block
setblock 259 233 324 minecraft:mushroom_stem
fill 259 233 325 262 233 325 minecraft:moss_block
setblock 259 233 345 minecraft:stone_bricks
fill 259 233 347 260 233 348 minecraft:stone_bricks
fill 260 233 322 260 308 322 minecraft:moss_block
setblock 260 233 323 minecraft:mushroom_stem
fill 260 233 324 260 236 324 minecraft:moss_block
setblock 260 233 349 minecraft:stone_bricks
setblock 260 233 363 minecraft:mushroom_stem
fill 261 233 323 261 236 323 minecraft:moss_block
setblock 261 233 362 minecraft:mushroom_stem
fill 261 233 363 264 233 363 minecraft:moss_block
setblock 262 233 361 minecraft:mushroom_stem
fill 262 233 362 265 233 362 minecraft:moss_block
fill 262 233 364 265 253 364 minecraft:moss_block
setblock 263 233 325 minecraft:mushroom_stem
fill 263 233 361 263 234 361 minecraft:moss_block
setblock 264 233 324 minecraft:mushroom_stem
fill 264 233 325 264 234 325 minecraft:moss_block
setblock 265 233 323 minecraft:mushroom_stem
fill 265 233 324 265 235 324 minecraft:moss_block
setblock 265 233 363 minecraft:mushroom_stem
fill 266 233 323 266 236 323 minecraft:moss_block
setblock 266 233 362 minecraft:mushroom_stem
fill 266 233 363 266 236 363 minecraft:moss_block
fill 267 233 362 267 234 362 minecraft:moss_block
setblock 270 233 323 minecraft:mushroom_stem
setblock 270 233 363 minecraft:mushroom_stem
fill 270 233 364 270 308 364 minecraft:moss_block
setblock 271 233 323 minecraft:moss_block
setblock 271 233 363 minecraft:moss_block
fill 273 233 364 274 308 364 minecraft:moss_block
setblock 274 233 344 minecraft:mushroom_stem
setblock 274 233 345 minecraft:moss_block
setblock 275 233 323 minecraft:mushroom_stem
setblock 275 233 343 minecraft:mushroom_stem
fill 275 233 344 275 236 344 minecraft:moss_block
setblock 275 233 347 minecraft:moss_block
setblock 275 233 348 minecraft:mushroom_stem
fill 275 233 349 275 235 350 minecraft:moss_block
fill 276 233 323 276 236 323 minecraft:moss_block
setblock 276 233 327 minecraft:mushroom_stem
fill 276 233 328 276 236 328 minecraft:moss_block
setblock 276 233 337 minecraft:mushroom_stem
fill 276 233 338 276 236 338 minecraft:moss_block
setblock 276 233 342 minecraft:mushroom_stem
fill 276 233 343 276 236 343 minecraft:moss_block
setblock 276 233 347 minecraft:mushroom_stem
fill 276 233 348 276 236 348 minecraft:moss_block
setblock 276 233 352 minecraft:mushroom_stem
fill 277 233 342 277 308 342 minecraft:moss_block
fill 277 233 347 277 308 347 minecraft:moss_block
fill 236 234 323 236 234 325 minecraft:moss_block
setblock 236 234 326 minecraft:mushroom_stem
fill 236 234 327 236 237 327 minecraft:moss_block
setblock 236 234 331 minecraft:mushroom_stem
fill 236 234 332 237 236 332 minecraft:moss_block
setblock 236 234 336 minecraft:mushroom_stem
fill 236 234 337 236 237 337 minecraft:moss_block
setblock 236 234 341 minecraft:mushroom_stem
fill 236 234 342 236 237 342 minecraft:moss_block
setblock 236 234 346 minecraft:mushroom_stem
fill 236 234 347 236 237 347 minecraft:moss_block
fill 237 234 323 237 234 324 minecraft:moss_block
setblock 237 234 325 minecraft:mushroom_stem
fill 237 234 326 237 237 326 minecraft:moss_block
setblock 237 234 330 minecraft:mushroom_stem
fill 237 234 331 237 237 331 minecraft:moss_block
setblock 237 234 340 minecraft:mushroom_stem
fill 237 234 341 237 235 341 minecraft:moss_block
setblock 237 234 345 minecraft:mushroom_stem
fill 237 234 346 237 237 346 minecraft:moss_block
setblock 238 234 323 minecraft:moss_block
setblock 238 234 324 minecraft:mushroom_stem
fill 238 234 325 241 234 325 minecraft:moss_block
setblock 238 234 329 minecraft:mushroom_stem
setblock 238 234 344 minecraft:mushroom_stem
setblock 238 234 345 minecraft:moss_block
setblock 239 234 323 minecraft:mushroom_stem
fill 239 234 324 242 234 324 minecraft:moss_block
fill 239 234 326 239 234 327 minecraft:moss_block
setblock 239 234 363 minecraft:mushroom_stem
fill 239 234 364 239 308 364 minecraft:moss_block
fill 240 234 323 243 234 323 minecraft:moss_block
setblock 240 234 326 minecraft:moss_block
setblock 240 234 362 minecraft:mushroom_stem
fill 240 234 363 243 234 363 minecraft:moss_block
setblock 241 234 326 minecraft:mushroom_stem
fill 241 234 362 244 234 362 minecraft:moss_block
setblock 242 234 325 minecraft:mushroom_stem
fill 242 234 326 242 237 326 minecraft:moss_block
setblock 243 234 324 minecraft:mushroom_stem
fill 243 234 325 243 237 325 minecraft:moss_block
setblock 244 234 323 minecraft:mushroom_stem
fill 244 234 324 244 237 324 minecraft:moss_block
setblock 244 234 363 minecraft:mushroom_stem
fill 245 234 323 245 237 323 minecraft:moss_block
setblock 245 234 362 minecraft:mushroom_stem
fill 245 234 363 248 234 363 minecraft:moss_block
fill 246 234 326 246 269 326 minecraft:mushroom_stem
setblock 246 234 362 minecraft:moss_block
setblock 247 234 325 minecraft:mushroom_stem
setblock 248 234 324 minecraft:mushroom_stem
fill 248 234 325 248 235 325 minecraft:moss_block
setblock 249 234 323 minecraft:mushroom_stem
fill 249 234 324 252 234 324 minecraft:moss_block
setblock 249 234 363 minecraft:mushroom_stem
fill 250 234 323 253 234 323 minecraft:moss_block
fill 250 234 363 253 234 363 minecraft:moss_block
setblock 253 234 324 minecraft:mushroom_stem
setblock 254 234 323 minecraft:mushroom_stem
fill 254 234 324 257 234 324 minecraft:moss_block
setblock 254 234 363 minecraft:mushroom_stem
fill 255 234 323 255 237 323 minecraft:moss_block
setblock 255 234 362 minecraft:mushroom_stem
fill 255 234 363 258 234 363 minecraft:moss_block
fill 256 234 362 259 234 362 minecraft:moss_block
fill 258 234 322 258 234 323 minecraft:moss_block
setblock 258 234 324 minecraft:mushroom_stem
fill 258 234 325 261 234 325 minecraft:moss_block
fill 259 234 322 259 308 322 minecraft:moss_block
setblock 259 234 323 minecraft:mushroom_stem
fill 259 234 324 259 237 324 minecraft:moss_block
fill 259 234 361 260 234 361 minecraft:moss_block
setblock 259 234 363 minecraft:mushroom_stem
fill 260 234 323 260 237 323 minecraft:moss_block
setblock 260 234 362 minecraft:mushroom_stem
fill 260 234 363 263 234 363 minecraft:moss_block
setblock 261 234 361 minecraft:mushroom_stem
fill 261 234 362 264 234 362 minecraft:moss_block
setblock 262 234 325 minecraft:mushroom_stem
fill 262 234 361 262 235 361 minecraft:moss_block
setblock 263 234 324 minecraft:mushroom_stem
setblock 263 234 325 minecraft:moss_block
fill 264 234 322 264 249 322 minecraft:moss_block
setblock 264 234 323 minecraft:mushroom_stem
fill 264 234 324 264 236 324 minecraft:moss_block
setblock 264 234 363 minecraft:mushroom_stem
fill 265 234 323 265 237 323 minecraft:moss_block
setblock 265 234 362 minecraft:mushroom_stem
fill 265 234 363 265 237 363 minecraft:moss_block
fill 266 234 362 266 235 362 minecraft:moss_block
setblock 269 234 323 minecraft:mushroom_stem
setblock 269 234 363 minecraft:mushroom_stem
setblock 270 234 323 minecraft:moss_block
setblock 270 234 363 minecraft:moss_block
setblock 275 234 323 minecraft:moss_block
setblock 275 234 342 minecraft:mushroom_stem
fill 275 234 343 275 237 343 minecraft:moss_block
setblock 275 234 347 minecraft:mushroom_stem
fill 275 234 348 275 237 348 minecraft:moss_block
fill 276 234 324 276 234 325 minecraft:moss_block
setblock 276 234 326 minecraft:mushroom_stem
fill 276 234 327 276 237 327 minecraft:moss_block
fill 276 234 329 276 235 329 minecraft:moss_block
fill 276 234 335 276 235 335 minecraft:red_mushroom_block
fill 276 234 337 276 237 337 minecraft:moss_block
setblock 276 234 341 minecraft:mushroom_stem
fill 276 234 342 276 237 342 minecraft:moss_block
setblock 276 234 346 minecraft:mushroom_stem
fill 276 234 347 276 237 347 minecraft:moss_block
setblock 276 234 351 minecraft:mushroom_stem
fill 276 234 352 276 237 352 minecraft:moss_block
setblock 276 234 360 minecraft:red_mushroom_block
fill 236 235 323 236 235 324 minecraft:moss_block
setblock 236 235 325 minecraft:mushroom_stem
fill 236 235 326 236 238 326 minecraft:moss_block
setblock 236 235 329 minecraft:moss_block
setblock 236 235 330 minecraft:mushroom_stem
fill 236 235 331 236 238 331 minecraft:moss_block
setblock 236 235 335 minecraft:mushroom_stem
fill 236 235 336 236 238 336 minecraft:moss_block
setblock 236 235 340 minecraft:mushroom_stem
fill 236 235 341 236 238 341 minecraft:moss_block
setblock 236 235 345 minecraft:mushroom_stem
fill 236 235 346 236 238 346 minecraft:moss_block
setblock 236 235 349 minecraft:moss_block
setblock 236 235 350 minecraft:mushroom_stem
setblock 236 235 351 minecraft:red_mushroom_block
setblock 237 235 323 minecraft:moss_block
setblock 237 235 324 minecraft:mushroom_stem
fill 237 235 325 240 235 325 minecraft:moss_block
setblock 237 235 329 minecraft:mushroom_stem
fill 237 235 330 238 237 330 minecraft:moss_block
setblock 237 235 333 minecraft:moss_block
setblock 237 235 340 minecraft:moss_block
setblock 237 235 344 minecraft:mushroom_stem
fill 237 235 345 237 238 345 minecraft:moss_block
setblock 238 235 323 minecraft:mushroom_stem
fill 238 235 324 241 235 324 minecraft:moss_block
setblock 238 235 328 minecraft:mushroom_stem
fill 238 235 329 238 238 329 minecraft:moss_block
setblock 238 235 331 minecraft:dirt
fill 238 235 333 238 237 333 minecraft:dirt
setblock 238 235 363 minecraft:mushroom_stem
fill 238 235 364 238 245 364 minecraft:moss_block
fill 239 235 323 242 235 323 minecraft:moss_block
setblock 239 235 326 minecraft:moss_block
setblock 239 235 327 minecraft:mushroom_stem
fill 239 235 363 242 235 363 minecraft:moss_block
setblock 240 235 326 minecraft:mushroom_stem
setblock 241 235 325 minecraft:mushroom_stem
fill 241 235 326 241 238 326 minecraft:moss_block
fill 241 235 362 243 235 362 minecraft:moss_block
setblock 242 235 324 minecraft:mushroom_stem
fill 242 235 325 242 238 325 minecraft:moss_block
setblock 243 235 323 minecraft:mushroom_stem
fill 243 235 324 243 238 324 minecraft:moss_block
setblock 243 235 363 minecraft:mushroom_stem
fill 244 235 323 244 238 323 minecraft:moss_block
setblock 244 235 362 minecraft:mushroom_stem
fill 244 235 363 247 235 363 minecraft:moss_block
fill 245 235 326 245 269 326 minecraft:mushroom_stem
setblock 245 235 362 minecraft:moss_block
setblock 246 235 325 minecraft:mushroom_stem
setblock 247 235 324 minecraft:mushroom_stem
fill 247 235 325 247 236 325 minecraft:moss_block
setblock 248 235 323 minecraft:mushroom_stem
fill 248 235 324 251 235 324 minecraft:moss_block
setblock 248 235 363 minecraft:mushroom_stem
fill 249 235 323 252 235 323 minecraft:moss_block
fill 249 235 363 252 235 363 minecraft:moss_block
setblock 252 235 324 minecraft:mushroom_stem
setblock 253 235 323 minecraft:mushroom_stem
fill 253 235 324 256 235 324 minecraft:moss_block
setblock 253 235 363 minecraft:mushroom_stem
fill 254 235 323 254 238 323 minecraft:moss_block
fill 254 235 363 257 235 363 minecraft:moss_block
fill 256 235 362 258 235 362 minecraft:moss_block
setblock 257 235 324 minecraft:mushroom_stem
fill 258 235 322 258 279 322 minecraft:moss_block
setblock 258 235 323 minecraft:mushroom_stem
fill 258 235 324 258 238 324 minecraft:moss_block
setblock 258 235 363 minecraft:mushroom_stem
fill 259 235 323 259 238 323 minecraft:moss_block
fill 259 235 325 260 235 325 minecraft:moss_block
setblock 259 235 362 minecraft:mushroom_stem
fill 259 235 363 262 235 363 minecraft:moss_block
setblock 260 235 361 minecraft:mushroom_stem
fill 260 235 362 263 235 362 minecraft:moss_block
setblock 261 235 325 minecraft:mushroom_stem
setblock 261 235 361 minecraft:moss_block
setblock 261 235 364 minecraft:red_mushroom_block
setblock 262 235 324 minecraft:mushroom_stem
setblock 262 235 325 minecraft:moss_block
setblock 263 235 323 minecraft:mushroom_stem
fill 263 235 324 263 237 324 minecraft:moss_block
setblock 263 235 363 minecraft:mushroom_stem
fill 264 235 323 264 238 323 minecraft:moss_block
setblock 264 235 362 minecraft:mushroom_stem
fill 264 235 363 264 238 363 minecraft:moss_block
setblock 265 235 362 minecraft:moss_block
setblock 268 235 323 minecraft:mushroom_stem
setblock 268 235 363 minecraft:mushroom_stem
fill 268 235 364 268 263 364 minecraft:moss_block
fill 274 235 363 274 236 363 minecraft:red_mushroom_block
fill 275 235 342 275 236 342 minecraft:moss_block
setblock 275 235 346 minecraft:mushroom_stem
fill 275 235 347 275 238 347 minecraft:moss_block
setblock 276 235 324 minecraft:moss_block
setblock 276 235 325 minecraft:mushroom_stem
fill 276 235 326 276 238 326 minecraft:moss_block
setblock 276 235 330 minecraft:mushroom_stem
fill 276 235 331 276 238 331 minecraft:moss_block
setblock 276 235 340 minecraft:mushroom_stem
fill 276 235 341 276 238 341 minecraft:moss_block
setblock 276 235 345 minecraft:mushroom_stem
fill 276 235 346 276 238 346 minecraft:moss_block
setblock 276 235 350 minecraft:mushroom_stem
fill 276 235 351 276 238 351 minecraft:moss_block
fill 276 235 353 276 236 353 minecraft:moss_block
setblock 276 235 354 minecraft:red_mushroom_block
setblock 277 235 362 minecraft:red_mushroom_block
setblock 236 236 323 minecraft:moss_block
setblock 236 236 324 minecraft:mushroom_stem
fill 236 236 325 239 236 325 minecraft:moss_block
setblock 236 236 329 minecraft:mushroom_stem
fill 236 236 330 236 239 330 minecraft:moss_block
setblock 236 236 334 minecraft:mushroom_stem
fill 236 236 335 236 239 335 minecraft:moss_block
setblock 236 236 339 minecraft:mushroom_stem
fill 236 236 340 236 239 340 minecraft:moss_block
setblock 236 236 344 minecraft:mushroom_stem
fill 236 236 345 236 239 345 minecraft:moss_block
setblock 236 236 349 minecraft:mushroom_stem
fill 236 236 350 236 238 351 minecraft:moss_block
setblock 236 236 357 minecraft:red_mushroom_block
fill 236 236 363 236 237 363 minecraft:red_mushroom_block
setblock 237 236 323 minecraft:mushroom_stem
fill 237 236 324 240 236 324 minecraft:moss_block
setblock 237 236 328 minecraft:mushroom_stem
fill 237 236 329 237 239 329 minecraft:moss_block
setblock 237 236 333 minecraft:mushroom_stem
setblock 237 236 343 minecraft:mushroom_stem
fill 237 236 344 237 237 344 minecraft:moss_block
setblock 237 236 348 minecraft:mushroom_stem
fill 237 236 349 237 239 349 minecraft:moss_block
fill 238 236 323 241 236 323 minecraft:moss_block
setblock 238 236 327 minecraft:mushroom_stem
fill 238 236 328 239 238 328 minecraft:moss_block
setblock 238 236 331 minecraft:moss_block
fill 238 236 363 241 236 363 minecraft:moss_block
setblock 239 236 326 minecraft:mushroom_stem
fill 239 236 327 239 239 327 minecraft:moss_block
setblock 240 236 325 minecraft:mushroom_stem
fill 240 236 326 240 239 326 minecraft:moss_block
setblock 241 236 324 minecraft:mushroom_stem
fill 241 236 325 241 239 325 minecraft:moss_block
setblock 242 236 323 minecraft:mushroom_stem
fill 242 236 324 242 239 324 minecraft:moss_block
setblock 242 236 363 minecraft:mushroom_stem
fill 243 236 323 243 239 323 minecraft:moss_block
fill 243 236 363 246 236 363 minecraft:moss_block
fill 244 236 326 244 269 326 minecraft:mushroom_stem
fill 244 236 341 248 236 342 minecraft:dark_oak_planks
fill 244 236 352 248 236 353 minecraft:dark_oak_planks
setblock 245 236 325 minecraft:mushroom_stem
fill 245 236 340 248 236 340 minecraft:dark_oak_planks
fill 245 236 343 248 236 343 minecraft:dark_oak_planks
fill 245 236 351 248 236 351 minecraft:dark_oak_planks
fill 245 236 354 248 236 354 minecraft:dark_oak_planks
setblock 246 236 324 minecraft:mushroom_stem
fill 246 236 325 246 237 325 minecraft:moss_block
fill 246 236 339 247 236 339 minecraft:dark_oak_planks
fill 246 236 355 247 236 355 minecraft:dark_oak_planks
setblock 247 236 323 minecraft:mushroom_stem
fill 247 236 324 250 236 324 minecraft:moss_block
setblock 247 236 363 minecraft:mushroom_stem
fill 248 236 323 251 236 323 minecraft:moss_block
fill 248 236 363 251 236 363 minecraft:moss_block
setblock 251 236 324 minecraft:mushroom_stem
setblock 252 236 323 minecraft:mushroom_stem
fill 252 236 324 255 236 324 minecraft:moss_block
setblock 252 236 363 minecraft:mushroom_stem
fill 253 236 323 253 239 323 minecraft:moss_block
fill 253 236 363 256 236 363 minecraft:moss_block
fill 255 236 327 256 238 327 minecraft:red_mushroom_block
setblock 256 236 324 minecraft:mushroom_stem
fill 256 236 326 258 238 326 minecraft:red_mushroom_block
fill 256 236 328 258 238 328 minecraft:red_mushroom_block
fill 256 236 340 259 236 343 minecraft:dark_oak_planks
fill 256 236 351 259 236 354 minecraft:dark_oak_planks
fill 257 236 322 257 308 322 minecraft:moss_block
setblock 257 236 323 minecraft:mushroom_stem
fill 257 236 324 257 239 324 minecraft:moss_block
fill 257 236 329 257 238 329 minecraft:red_mushroom_block
fill 257 236 339 258 236 339 minecraft:dark_oak_planks
fill 257 236 355 258 236 355 minecraft:dark_oak_planks
setblock 257 236 362 minecraft:moss_block
setblock 257 236 363 minecraft:mushroom_stem
fill 258 236 323 258 239 323 minecraft:moss_block
fill 258 236 327 258 238 327 minecraft:red_mushroom_block
setblock 258 236 362 minecraft:mushroom_stem
fill 258 236 363 261 236 363 minecraft:moss_block
fill 259 236 362 262 236 362 minecraft:moss_block
fill 260 236 341 260 236 342 minecraft:dark_oak_planks
fill 260 236 352 260 236 353 minecraft:dark_oak_planks
fill 261 236 322 262 308 322 minecraft:moss_block
setblock 261 236 324 minecraft:mushroom_stem
fill 261 236 364 261 258 364 minecraft:moss_block
setblock 262 236 323 minecraft:mushroom_stem
fill 262 236 324 262 237 324 minecraft:moss_block
setblock 262 236 363 minecraft:mushroom_stem
setblock 263 236 322 minecraft:shroomlight
fill 263 236 323 263 239 323 minecraft:moss_block
setblock 263 236 362 minecraft:mushroom_stem
fill 263 236 363 263 239 363 minecraft:moss_block
setblock 264 236 362 minecraft:moss_block
setblock 275 236 345 minecraft:mushroom_stem
fill 275 236 346 275 239 346 minecraft:moss_block
setblock 275 236 349 minecraft:moss_block
setblock 275 236 350 minecraft:mushroom_stem
setblock 276 236 324 minecraft:mushroom_stem
fill 276 236 325 276 239 325 minecraft:moss_block
setblock 276 236 329 minecraft:mushroom_stem
fill 276 236 330 276 239 330 minecraft:moss_block
fill 276 236 332 276 237 332 minecraft:moss_block
setblock 276 236 339 minecraft:mushroom_stem
fill 276 236 340 276 239 340 minecraft:moss_block
setblock 276 236 344 minecraft:mushroom_stem
fill 276 236 345 276 239 345 minecraft:moss_block
setblock 276 236 349 minecraft:mushroom_stem
fill 276 236 350 276 239 350 minecraft:moss_block
fill 277 236 362 277 308 362 minecraft:moss_block
fill 235 237 346 235 249 359 minecraft:moss_block
setblock 235 237 360 minecraft:shroomlight
fill 235 237 361 235 243 361 minecraft:moss_block
setblock 236 237 323 minecraft:mushroom_stem
fill 236 237 324 238 237 325 minecraft:moss_block
setblock 236 237 328 minecraft:mushroom_stem
fill 236 237 329 236 240 329 minecraft:moss_block
setblock 236 237 332 minecraft:moss_block
setblock 236 237 333 minecraft:mushroom_stem
fill 236 237 334 237 239 334 minecraft:moss_block
setblock 236 237 338 minecraft:mushroom_stem
fill 236 237 339 236 240 339 minecraft:moss_block
setblock 236 237 343 minecraft:mushroom_stem
fill 236 237 344 236 240 344 minecraft:moss_block
setblock 236 237 348 minecraft:mushroom_stem
fill 236 237 349 236 240 349 minecraft:moss_block
fill 237 237 323 240 237 323 minecraft:moss_block
setblock 237 237 327 minecraft:mushroom_stem
fill 237 237 328 237 240 328 minecraft:moss_block
setblock 237 237 332 minecraft:mushroom_stem
fill 237 237 333 237 240 333 minecraft:moss_block
setblock 237 237 347 minecraft:mushroom_stem
fill 237 237 348 237 240 348 minecraft:moss_block
setblock 238 237 326 minecraft:mushroom_stem
fill 238 237 327 238 240 327 minecraft:moss_block
setblock 238 237 331 minecraft:mushroom_stem
setblock 238 237 339 minecraft:light[level=12]
setblock 238 237 341 minecraft:light[level=15]
setblock 238 237 346 minecraft:light[level=12]
setblock 238 237 349 minecraft:light[level=15]
setblock 238 237 353 minecraft:light[level=12]
setblock 238 237 357 minecraft:light[level=15]
setblock 238 237 360 minecraft:light[level=12]
fill 238 237 363 240 237 363 minecraft:moss_block
fill 239 237 322 240 298 322 minecraft:moss_block
setblock 239 237 324 minecraft:moss_block
setblock 239 237 325 minecraft:mushroom_stem
fill 239 237 326 239 240 326 minecraft:moss_block
setblock 239 237 332 minecraft:dirt
setblock 240 237 324 minecraft:mushroom_stem
fill 240 237 325 240 240 325 minecraft:moss_block
setblock 241 237 322 minecraft:shroomlight
setblock 241 237 323 minecraft:mushroom_stem
fill 241 237 324 241 240 324 minecraft:moss_block
setblock 241 237 363 minecraft:mushroom_stem
fill 242 237 322 242 240 323 minecraft:moss_block
fill 242 237 360 242 253 360 minecraft:red_mushroom_block
fill 242 237 363 245 237 363 minecraft:moss_block
fill 243 237 322 245 252 322 minecraft:moss_block
setblock 243 237 326 minecraft:mushroom_stem
setblock 244 237 325 minecraft:mushroom_stem
setblock 245 237 324 minecraft:mushroom_stem
fill 245 237 325 245 238 325 minecraft:moss_block
setblock 245 237 332 minecraft:light[level=12]
setblock 245 237 339 minecraft:light[level=12]
fill 245 237 340 247 237 342 minecraft:dark_oak_planks
setblock 245 237 346 minecraft:light[level=12]
fill 245 237 352 247 237 354 minecraft:dark_oak_planks
setblock 245 237 360 minecraft:light[level=12]
setblock 246 237 323 minecraft:mushroom_stem
fill 246 237 324 249 237 324 minecraft:moss_block
setblock 246 237 333 minecraft:light[level=15]
fill 246 237 343 247 237 343 minecraft:dark_oak_planks
setblock 246 237 349 minecraft:light[level=15]
fill 246 237 351 247 237 351 minecraft:dark_oak_planks
setblock 246 237 357 minecraft:light[level=15]
setblock 246 237 363 minecraft:mushroom_stem
fill 247 237 323 250 237 323 minecraft:moss_block
setblock 247 237 363 minecraft:moss_block
fill 248 237 341 248 237 342 minecraft:dark_oak_planks
fill 248 237 352 248 237 353 minecraft:dark_oak_planks
setblock 251 237 323 minecraft:mushroom_stem
fill 252 237 323 252 240 323 minecraft:moss_block
setblock 252 237 325 minecraft:light[level=12]
setblock 252 237 332 minecraft:light[level=12]
setblock 252 237 339 minecraft:light[level=12]
setblock 252 237 353 minecraft:light[level=12]
setblock 252 237 360 minecraft:light[level=12]
fill 253 237 363 255 237 363 minecraft:moss_block
setblock 254 237 325 minecraft:light[level=15]
setblock 254 237 333 minecraft:light[level=15]
setblock 254 237 341 minecraft:light[level=15]
setblock 254 237 349 minecraft:light[level=15]
setblock 254 237 357 minecraft:light[level=15]
setblock 255 237 324 minecraft:mushroom_stem
setblock 255 237 326 minecraft:red_mushroom_block
setblock 255 237 328 minecraft:red_mushroom_block
setblock 256 237 323 minecraft:mushroom_stem
fill 256 237 324 256 238 324 minecraft:moss_block
fill 256 237 325 257 237 325 minecraft:red_mushroom_block
setblock 256 237 329 minecraft:red_mushroom_block
fill 256 237 341 259 237 342 minecraft:dark_oak_planks
fill 256 237 352 259 237 353 minecraft:dark_oak_planks
setblock 256 237 363 minecraft:mushroom_stem
fill 257 237 323 257 240 323 minecraft:moss_block
fill 257 237 327 257 238 327 minecraft:red_mushroom_block
fill 257 237 340 259 237 340 minecraft:dark_oak_planks
fill 257 237 343 258 237 343 minecraft:dark_oak_planks
fill 257 237 351 258 237 351 minecraft:dark_oak_planks
fill 257 237 354 259 237 354 minecraft:dark_oak_planks
setblock 257 237 362 minecraft:mushroom_stem
fill 257 237 363 260 237 363 minecraft:moss_block
setblock 258 237 329 minecraft:red_mushroom_block
fill 258 237 362 261 237 362 minecraft:moss_block
setblock 259 237 325 minecraft:light[level=12]
fill 259 237 327 259 237 328 minecraft:red_mushroom_block
setblock 259 237 332 minecraft:light[level=12]
setblock 259 237 339 minecraft:light[level=12]
setblock 259 237 346 minecraft:light[level=12]
setblock 259 237 360 minecraft:light[level=12]
setblock 260 237 324 minecraft:mushroom_stem
setblock 261 237 323 minecraft:mushroom_stem
fill 261 237 324 261 238 324 minecraft:moss_block
setblock 261 237 363 minecraft:mushroom_stem
fill 262 237 323 262 240 323 minecraft:moss_block
setblock 262 237 325 minecraft:light[level=15]
setblock 262 237 333 minecraft:light[level=15]
setblock 262 237 341 minecraft:light[level=15]
setblock 262 237 349 minecraft:light[level=15]
setblock 262 237 357 minecraft:light[level=15]
setblock 262 237 362 minecraft:mushroom_stem
fill 262 237 363 262 240 363 minecraft:moss_block
setblock 263 237 322 minecraft:red_mushroom_block
setblock 266 237 325 minecraft:light[level=12]
setblock 266 237 332 minecraft:light[level=12]
setblock 266 237 339 minecraft:light[level=12]
setblock 266 237 346 minecraft:light[level=12]
setblock 266 237 353 minecraft:light[level=12]
setblock 266 237 360 minecraft:light[level=12]
setblock 270 237 323 minecraft:red_mushroom_block
setblock 270 237 325 minecraft:light[level=15]
setblock 270 237 333 minecraft:light[level=15]
setblock 270 237 341 minecraft:light[level=15]
setblock 270 237 349 minecraft:light[level=15]
setblock 270 237 357 minecraft:light[level=15]
setblock 273 237 325 minecraft:light[level=12]
setblock 273 237 332 minecraft:light[level=12]
setblock 273 237 339 minecraft:light[level=12]
setblock 273 237 346 minecraft:light[level=12]
setblock 273 237 353 minecraft:light[level=12]
setblock 273 237 360 minecraft:light[level=12]
setblock 275 237 344 minecraft:mushroom_stem
fill 275 237 345 275 240 345 minecraft:moss_block
setblock 275 237 349 minecraft:mushroom_stem
fill 275 237 350 275 240 350 minecraft:moss_block
setblock 276 237 323 minecraft:mushroom_stem
fill 276 237 324 276 240 324 minecraft:moss_block
setblock 276 237 328 minecraft:mushroom_stem
fill 276 237 329 276 240 329 minecraft:moss_block
setblock 276 237 333 minecraft:mushroom_stem
fill 276 237 334 276 239 335 minecraft:moss_block
setblock 276 237 338 minecraft:mushroom_stem
fill 276 237 339 276 240 339 minecraft:moss_block
setblock 276 237 343 minecraft:mushroom_stem
fill 276 237 344 276 240 344 minecraft:moss_block
setblock 276 237 348 minecraft:mushroom_stem
fill 276 237 349 276 240 349 minecraft:moss_block
setblock 276 237 353 minecraft:mushroom_stem
setblock 276 237 361 minecraft:red_mushroom_block
fill 235 238 360 235 308 360 minecraft:moss_block
fill 236 238 323 237 238 325 minecraft:moss_block
setblock 236 238 327 minecraft:mushroom_stem
fill 236 238 328 236 241 328 minecraft:moss_block
setblock 236 238 332 minecraft:mushroom_stem
fill 236 238 333 236 241 333 minecraft:moss_block
setblock 236 238 337 minecraft:mushroom_stem
fill 236 238 338 236 241 338 minecraft:moss_block
setblock 236 238 342 minecraft:mushroom_stem
fill 236 238 343 236 241 343 minecraft:moss_block
setblock 236 238 347 minecraft:mushroom_stem
fill 236 238 348 236 241 348 minecraft:moss_block
setblock 236 238 352 minecraft:mushroom_stem
setblock 237 238 326 minecraft:mushroom_stem
fill 237 238 327 237 241 327 minecraft:moss_block
setblock 237 238 330 minecraft:moss_block
setblock 237 238 331 minecraft:mushroom_stem
fill 237 238 332 238 240 332 minecraft:moss_block
setblock 237 238 346 minecraft:mushroom_stem
fill 237 238 347 237 241 347 minecraft:moss_block
fill 238 238 323 238 238 324 minecraft:moss_block
setblock 238 238 325 minecraft:mushroom_stem
fill 238 238 326 238 241 326 minecraft:moss_block
setblock 238 238 330 minecraft:mushroom_stem
fill 238 238 331 238 241 331 minecraft:moss_block
setblock 239 238 323 minecraft:moss_block
setblock 239 238 324 minecraft:mushroom_stem
fill 239 238 325 239 241 325 minecraft:moss_block
setblock 239 238 329 minecraft:mushroom_stem
setblock 239 238 363 minecraft:moss_block
setblock 240 238 323 minecraft:mushroom_stem
fill 240 238 324 240 241 324 minecraft:moss_block
setblock 240 238 363 minecraft:mushroom_stem
fill 241 238 322 241 241 323 minecraft:moss_block
fill 241 238 363 244 238 363 minecraft:moss_block
setblock 242 238 326 minecraft:mushroom_stem
setblock 243 238 325 minecraft:mushroom_stem
setblock 244 238 324 minecraft:mushroom_stem
fill 244 238 325 244 239 325 minecraft:moss_block
setblock 245 238 323 minecraft:mushroom_stem
fill 245 238 324 247 238 324 minecraft:moss_block
fill 245 238 341 247 238 342 minecraft:dark_oak_planks
fill 245 238 352 247 238 353 minecraft:dark_oak_planks
setblock 245 238 363 minecraft:mushroom_stem
fill 246 238 323 249 238 323 minecraft:moss_block
fill 246 238 340 247 238 340 minecraft:dark_oak_planks
fill 246 238 354 247 238 354 minecraft:dark_oak_planks
setblock 248 238 363 minecraft:red_mushroom_block
setblock 250 238 323 minecraft:mushroom_stem
fill 250 238 364 251 308 364 minecraft:moss_block
fill 251 238 323 251 239 323 minecraft:moss_block
setblock 252 238 364 minecraft:shroomlight
fill 253 238 364 259 242 364 minecraft:moss_block
setblock 254 238 363 minecraft:moss_block
setblock 255 238 323 minecraft:mushroom_stem
setblock 255 238 363 minecraft:mushroom_stem
fill 256 238 323 256 241 323 minecraft:moss_block
fill 256 238 363 259 238 363 minecraft:moss_block
fill 257 238 340 258 238 342 minecraft:dark_oak_planks
fill 257 238 352 258 238 354 minecraft:dark_oak_planks
fill 258 238 362 260 238 362 minecraft:moss_block
setblock 259 238 324 minecraft:mushroom_stem
fill 259 238 341 259 238 342 minecraft:dark_oak_planks
fill 259 238 352 259 238 353 minecraft:dark_oak_planks
setblock 260 238 323 minecraft:mushroom_stem
fill 260 238 324 260 239 324 minecraft:moss_block
setblock 260 238 363 minecraft:mushroom_stem
fill 261 238 323 261 241 323 minecraft:moss_block
setblock 261 238 362 minecraft:mushroom_stem
fill 261 238 363 261 241 363 minecraft:moss_block
fill 263 238 322 263 308 322 minecraft:moss_block
setblock 267 238 363 minecraft:red_mushroom_block
fill 275 238 344 275 241 344 minecraft:moss_block
setblock 275 238 348 minecraft:mushroom_stem
fill 275 238 349 275 241 349 minecraft:moss_block
fill 275 238 351 275 239 351 minecraft:moss_block
fill 276 238 323 276 241 323 minecraft:moss_block
setblock 276 238 327 minecraft:mushroom_stem
fill 276 238 328 276 241 328 minecraft:moss_block
setblock 276 238 332 minecraft:mushroom_stem
fill 276 238 333 276 241 333 minecraft:moss_block
setblock 276 238 336 minecraft:moss_block
setblock 276 238 337 minecraft:mushroom_stem
fill 276 238 338 276 241 338 minecraft:moss_block
setblock 276 238 342 minecraft:mushroom_stem
fill 276 238 343 276 241 343 minecraft:moss_block
setblock 276 238 347 minecraft:mushroom_stem
fill 276 238 348 276 241 348 minecraft:moss_block
setblock 276 238 352 minecraft:mushroom_stem
fill 276 238 353 276 240 354 minecraft:moss_block
setblock 276 238 355 minecraft:red_mushroom_block
fill 277 238 330 277 308 330 minecraft:moss_block
setblock 277 238 331 minecraft:shroomlight
fill 236 239 323 236 239 325 minecraft:moss_block
setblock 236 239 326 minecraft:mushroom_stem
fill 236 239 327 236 242 327 minecraft:moss_block
setblock 236 239 331 minecraft:mushroom_stem
fill 236 239 332 236 242 332 minecraft:moss_block
setblock 236 239 336 minecraft:mushroom_stem
fill 236 239 337 236 242 337 minecraft:moss_block
setblock 236 239 341 minecraft:mushroom_stem
fill 236 239 342 236 242 342 minecraft:moss_block
setblock 236 239 346 minecraft:mushroom_stem
fill 236 239 347 236 242 347 minecraft:moss_block
setblock 236 239 350 minecraft:moss_block
setblock 236 239 351 minecraft:mushroom_stem
fill 236 239 352 236 241 353 minecraft:moss_block
setblock 236 239 356 minecraft:red_mushroom_block
fill 237 239 323 237 239 324 minecraft:moss_block
setblock 237 239 325 minecraft:mushroom_stem
fill 237 239 326 237 242 326 minecraft:moss_block
setblock 237 239 330 minecraft:mushroom_stem
fill 237 239 331 237 242 331 minecraft:moss_block
setblock 237 239 335 minecraft:mushroom_stem
setblock 237 239 346 minecraft:moss_block
setblock 237 239 350 minecraft:mushroom_stem
setblock 238 239 323 minecraft:moss_block
setblock 238 239 324 minecraft:mushroom_stem
fill 238 239 325 238 242 325 minecraft:moss_block
setblock 238 239 328 minecraft:moss_block
setblock 238 239 329 minecraft:mushroom_stem
fill 238 239 330 239 241 330 minecraft:moss_block
setblock 238 239 333 minecraft:moss_block
setblock 239 239 323 minecraft:mushroom_stem
fill 239 239 324 239 242 324 minecraft:moss_block
setblock 239 239 328 minecraft:mushroom_stem
fill 239 239 329 239 242 329 minecraft:moss_block
setblock 239 239 363 minecraft:mushroom_stem
fill 240 239 323 240 242 323 minecraft:moss_block
fill 240 239 363 243 239 363 minecraft:moss_block
setblock 241 239 326 minecraft:mushroom_stem
setblock 242 239 325 minecraft:mushroom_stem
setblock 243 239 324 minecraft:mushroom_stem
fill 243 239 325 243 240 325 minecraft:moss_block
setblock 244 239 323 minecraft:mushroom_stem
fill 244 239 324 246 239 324 minecraft:moss_block
fill 245 239 323 248 239 323 minecraft:moss_block
fill 246 239 341 247 239 342 minecraft:dark_oak_planks
fill 246 239 352 247 239 353 minecraft:dark_oak_planks
setblock 249 239 323 minecraft:mushroom_stem
setblock 250 239 323 minecraft:moss_block
fill 252 239 322 255 308 322 minecraft:moss_block
setblock 252 239 359 minecraft:shroomlight
fill 252 239 364 252 308 364 minecraft:moss_block
setblock 254 239 323 minecraft:mushroom_stem
setblock 254 239 363 minecraft:mushroom_stem
fill 255 239 323 255 242 323 minecraft:moss_block
fill 255 239 363 258 239 363 minecraft:moss_block
setblock 256 239 322 minecraft:shroomlight
fill 257 239 341 258 239 342 minecraft:dark_oak_planks
fill 257 239 352 258 239 353 minecraft:dark_oak_planks
setblock 258 239 324 minecraft:mushroom_stem
fill 258 239 362 259 239 362 minecraft:moss_block
setblock 259 239 323 minecraft:mushroom_stem
fill 259 239 324 259 240 324 minecraft:moss_block
setblock 259 239 363 minecraft:mushroom_stem
fill 260 239 323 260 242 323 minecraft:moss_block
fill 260 239 363 260 242 363 minecraft:moss_block
setblock 273 239 363 minecraft:red_mushroom_block
fill 275 239 328 275 239 331 minecraft:moss_block
setblock 275 239 347 minecraft:mushroom_stem
fill 275 239 348 275 242 348 minecraft:moss_block
setblock 276 239 326 minecraft:mushroom_stem
fill 276 239 327 276 242 327 minecraft:moss_block
setblock 276 239 331 minecraft:mushroom_stem
fill 276 239 332 276 242 332 minecraft:moss_block
setblock 276 239 336 minecraft:mushroom_stem
fill 276 239 337 276 242 337 minecraft:moss_block
setblock 276 239 341 minecraft:mushroom_stem
fill 276 239 342 276 242 342 minecraft:moss_block
setblock 276 239 346 minecraft:mushroom_stem
fill 276 239 347 276 242 347 minecraft:moss_block
setblock 276 239 351 minecraft:mushroom_stem
fill 276 239 352 276 242 352 minecraft:moss_block
setblock 277 239 323 minecraft:red_mushroom_block
fill 277 239 331 277 308 331 minecraft:moss_block
fill 236 240 323 236 240 324 minecraft:moss_block
setblock 236 240 325 minecraft:mushroom_stem
fill 236 240 326 236 243 326 minecraft:moss_block
setblock 236 240 330 minecraft:mushroom_stem
fill 236 240 331 236 243 331 minecraft:moss_block
setblock 236 240 334 minecraft:moss_block
setblock 236 240 335 minecraft:mushroom_stem
fill 236 240 336 237 242 336 minecraft:moss_block
setblock 236 240 340 minecraft:mushroom_stem
fill 236 240 341 236 243 341 minecraft:moss_block
setblock 236 240 345 minecraft:mushroom_stem
fill 236 240 346 236 243 346 minecraft:moss_block
setblock 236 240 350 minecraft:mushroom_stem
fill 236 240 351 237 242 351 minecraft:moss_block
setblock 236 240 354 minecraft:moss_block
setblock 236 240 362 minecraft:red_mushroom_block
setblock 237 240 323 minecraft:moss_block
setblock 237 240 324 minecraft:mushroom_stem
fill 237 240 325 237 243 325 minecraft:moss_block
setblock 237 240 329 minecraft:mushroom_stem
fill 237 240 330 237 243 330 minecraft:moss_block
setblock 237 240 334 minecraft:mushroom_stem
fill 237 240 335 237 243 335 minecraft:moss_block
setblock 237 240 349 minecraft:mushroom_stem
fill 237 240 350 237 243 350 minecraft:moss_block
setblock 238 240 323 minecraft:mushroom_stem
fill 238 240 324 238 243 324 minecraft:moss_block
setblock 238 240 328 minecraft:mushroom_stem
fill 238 240 329 238 243 329 minecraft:moss_block
setblock 238 240 333 minecraft:mushroom_stem
setblock 238 240 363 minecraft:mushroom_stem
fill 239 240 323 239 243 323 minecraft:moss_block
setblock 239 240 327 minecraft:mushroom_stem
fill 239 240 328 239 243 328 minecraft:moss_block
setblock 239 240 331 minecraft:moss_block
fill 239 240 363 242 240 363 minecraft:moss_block
setblock 240 240 326 minecraft:mushroom_stem
setblock 241 240 325 minecraft:mushroom_stem
setblock 242 240 324 minecraft:mushroom_stem
fill 242 240 325 242 242 325 minecraft:moss_block
setblock 243 240 323 minecraft:mushroom_stem
fill 243 240 324 245 240 324 minecraft:moss_block
setblock 243 240 363 minecraft:mushroom_stem
fill 244 240 323 247 240 323 minecraft:moss_block
setblock 246 240 341 minecraft:dark_oak_planks
setblock 246 240 353 minecraft:dark_oak_planks
setblock 248 240 323 minecraft:mushroom_stem
fill 252 240 359 252 244 359 minecraft:mushroom_stem
setblock 253 240 323 minecraft:mushroom_stem
setblock 253 240 363 minecraft:mushroom_stem
fill 254 240 323 254 243 323 minecraft:moss_block
fill 254 240 363 257 240 363 minecraft:moss_block
fill 256 240 322 256 263 322 minecraft:moss_block
setblock 257 240 324 minecraft:mushroom_stem
setblock 258 240 323 minecraft:mushroom_stem
setblock 258 240 324 minecraft:moss_block
setblock 258 240 341 minecraft:dark_oak_planks
setblock 258 240 353 minecraft:dark_oak_planks
setblock 258 240 362 minecraft:moss_block
setblock 258 240 363 minecraft:mushroom_stem
fill 259 240 323 259 243 323 minecraft:moss_block
fill 259 240 363 259 243 363 minecraft:moss_block
fill 266 240 322 267 279 322 minecraft:moss_block
setblock 268 240 322 minecraft:red_mushroom_block
fill 270 240 322 270 298 322 minecraft:moss_block
setblock 271 240 322 minecraft:shroomlight
fill 271 240 346 271 241 346 minecraft:shroomlight
fill 275 240 327 275 240 330 minecraft:moss_block
setblock 275 240 331 minecraft:mushroom_stem
fill 275 240 332 275 241 334 minecraft:moss_block
setblock 275 240 346 minecraft:mushroom_stem
fill 275 240 347 275 243 347 minecraft:moss_block
setblock 275 240 351 minecraft:mushroom_stem
fill 275 240 352 275 243 352 minecraft:moss_block
setblock 276 240 325 minecraft:mushroom_stem
fill 276 240 326 276 243 326 minecraft:moss_block
setblock 276 240 330 minecraft:mushroom_stem
fill 276 240 331 276 243 331 minecraft:moss_block
setblock 276 240 334 minecraft:moss_block
setblock 276 240 335 minecraft:mushroom_stem
fill 276 240 336 276 243 336 minecraft:moss_block
setblock 276 240 340 minecraft:mushroom_stem
fill 276 240 341 276 243 341 minecraft:moss_block
setblock 276 240 345 minecraft:mushroom_stem
fill 276 240 346 276 243 346 minecraft:moss_block
setblock 276 240 350 minecraft:mushroom_stem
fill 276 240 351 276 243 351 minecraft:moss_block
setblock 276 240 355 minecraft:mushroom_stem
fill 277 240 323 277 308 323 minecraft:moss_block
setblock 236 241 323 minecraft:moss_block
setblock 236 241 324 minecraft:mushroom_stem
fill 236 241 325 236 244 325 minecraft:moss_block
setblock 236 241 329 minecraft:mushroom_stem
fill 236 241 330 236 244 330 minecraft:moss_block
setblock 236 241 334 minecraft:mushroom_stem
fill 236 241 335 236 244 335 minecraft:moss_block
setblock 236 241 339 minecraft:mushroom_stem
fill 236 241 340 236 244 340 minecraft:moss_block
setblock 236 241 344 minecraft:mushroom_stem
fill 236 241 345 236 244 345 minecraft:moss_block
setblock 236 241 349 minecraft:mushroom_stem
fill 236 241 350 236 244 350 minecraft:moss_block
setblock 236 241 354 minecraft:mushroom_stem
fill 236 241 355 236 243 356 minecraft:moss_block
setblock 237 241 323 minecraft:mushroom_stem
fill 237 241 324 237 244 324 minecraft:moss_block
setblock 237 241 328 minecraft:mushroom_stem
fill 237 241 329 237 244 329 minecraft:moss_block
setblock 237 241 332 minecraft:moss_block
setblock 237 241 333 minecraft:mushroom_stem
fill 237 241 334 238 243 334 minecraft:moss_block
setblock 237 241 337 minecraft:moss_block
setblock 237 241 348 minecraft:mushroom_stem
fill 237 241 349 237 244 349 minecraft:moss_block
setblock 237 241 352 minecraft:moss_block
setblock 237 241 353 minecraft:mushroom_stem
setblock 237 241 363 minecraft:mushroom_stem
fill 238 241 323 238 244 323 minecraft:moss_block
setblock 238 241 327 minecraft:mushroom_stem
fill 238 241 328 238 244 328 minecraft:moss_block
setblock 238 241 332 minecraft:mushroom_stem
fill 238 241 333 238 244 333 minecraft:moss_block
fill 238 241 363 241 241 363 minecraft:moss_block
setblock 239 241 326 minecraft:mushroom_stem
fill 239 241 327 239 244 327 minecraft:moss_block
setblock 239 241 331 minecraft:mushroom_stem
setblock 240 241 325 minecraft:mushroom_stem
fill 240 241 326 240 242 326 minecraft:moss_block
setblock 241 241 324 minecraft:mushroom_stem
fill 241 241 325 241 244 325 minecraft:moss_block
fill 242 241 322 242 246 322 minecraft:moss_block
setblock 242 241 323 minecraft:mushroom_stem
fill 242 241 324 244 242 324 minecraft:moss_block
setblock 242 241 363 minecraft:mushroom_stem
fill 243 241 323 246 241 323 minecraft:moss_block
setblock 247 241 323 minecraft:mushroom_stem
fill 249 241 358 249 251 358 minecraft:dirt
setblock 252 241 323 minecraft:mushroom_stem
fill 253 241 323 253 244 323 minecraft:moss_block
fill 253 241 363 256 241 363 minecraft:moss_block
setblock 257 241 323 minecraft:mushroom_stem
setblock 257 241 362 minecraft:moss_block
setblock 257 241 363 minecraft:mushroom_stem
fill 258 241 323 258 244 323 minecraft:moss_block
setblock 258 241 362 minecraft:mushroom_stem
fill 258 241 363 258 244 363 minecraft:moss_block
fill 259 241 362 259 244 362 minecraft:moss_block
setblock 262 241 363 minecraft:mushroom_stem
setblock 266 241 363 minecraft:red_mushroom_block
fill 268 241 322 268 308 322 minecraft:moss_block
fill 271 241 322 271 308 322 minecraft:moss_block
setblock 271 241 323 minecraft:red_mushroom_block
fill 275 241 326 275 241 329 minecraft:moss_block
setblock 275 241 330 minecraft:mushroom_stem
fill 275 241 331 275 244 331 minecraft:moss_block
setblock 275 241 335 minecraft:mushroom_stem
fill 275 241 336 275 243 337 minecraft:moss_block
fill 275 241 343 275 242 343 minecraft:moss_block
setblock 275 241 345 minecraft:mushroom_stem
fill 275 241 346 275 244 346 minecraft:moss_block
setblock 275 241 350 minecraft:mushroom_stem
fill 275 241 351 275 244 351 minecraft:moss_block
fill 275 241 353 276 241 353 minecraft:moss_block
setblock 276 241 324 minecraft:mushroom_stem
fill 276 241 325 276 244 325 minecraft:moss_block
setblock 276 241 329 minecraft:mushroom_stem
fill 276 241 330 276 244 330 minecraft:moss_block
setblock 276 241 334 minecraft:mushroom_stem
fill 276 241 335 276 244 335 minecraft:moss_block
setblock 276 241 339 minecraft:mushroom_stem
fill 276 241 340 276 244 340 minecraft:moss_block
setblock 276 241 344 minecraft:mushroom_stem
fill 276 241 345 276 244 345 minecraft:moss_block
setblock 276 241 349 minecraft:mushroom_stem
fill 276 241 350 276 244 350 minecraft:moss_block
setblock 276 241 354 minecraft:mushroom_stem
fill 276 241 355 276 243 356 minecraft:moss_block
setblock 276 241 362 minecraft:red_mushroom_block
setblock 236 242 323 minecraft:mushroom_stem
fill 236 242 324 236 245 324 minecraft:moss_block
setblock 236 242 328 minecraft:mushroom_stem
fill 236 242 329 236 245 329 minecraft:moss_block
setblock 236 242 333 minecraft:mushroom_stem
fill 236 242 334 236 245 334 minecraft:moss_block
setblock 236 242 338 minecraft:mushroom_stem
fill 236 242 339 236 245 339 minecraft:moss_block
setblock 236 242 343 minecraft:mushroom_stem
fill 236 242 344 236 245 344 minecraft:moss_block
setblock 236 242 348 minecraft:mushroom_stem
fill 236 242 349 236 245 349 minecraft:moss_block
setblock 236 242 352 minecraft:moss_block
setblock 236 242 353 minecraft:mushroom_stem
fill 236 242 354 237 244 354 minecraft:moss_block
setblock 236 242 357 minecraft:moss_block
setblock 236 242 358 minecraft:mushroom_stem
fill 236 242 359 236 245 359 minecraft:moss_block
setblock 236 242 363 minecraft:mushroom_stem
fill 237 242 323 237 245 323 minecraft:moss_block
setblock 237 242 327 minecraft:mushroom_stem
fill 237 242 328 237 245 328 minecraft:moss_block
setblock 237 242 332 minecraft:mushroom_stem
fill 237 242 333 237 245 333 minecraft:moss_block
setblock 237 242 337 minecraft:mushroom_stem
fill 237 242 338 237 245 338 minecraft:moss_block
setblock 237 242 347 minecraft:mushroom_stem
fill 237 242 348 237 245 348 minecraft:moss_block
setblock 237 242 352 minecraft:mushroom_stem
fill 237 242 353 237 245 353 minecraft:moss_block
fill 237 242 355 237 243 355 minecraft:moss_block
fill 237 242 363 240 242 363 minecraft:moss_block
setblock 238 242 326 minecraft:mushroom_stem
fill 238 242 327 238 245 327 minecraft:moss_block
setblock 238 242 330 minecraft:moss_block
setblock 238 242 331 minecraft:mushroom_stem
fill 238 242 332 239 244 332 minecraft:moss_block
setblock 238 242 335 minecraft:moss_block
setblock 239 242 325 minecraft:mushroom_stem
fill 239 242 326 239 243 326 minecraft:moss_block
setblock 239 242 330 minecraft:mushroom_stem
fill 239 242 331 239 245 331 minecraft:moss_block
setblock 240 242 324 minecraft:mushroom_stem
fill 240 242 325 240 245 325 minecraft:moss_block
setblock 240 242 364 minecraft:red_mushroom_block
fill 241 242 322 241 308 322 minecraft:moss_block
setblock 241 242 323 minecraft:mushroom_stem
fill 241 242 324 241 245 324 minecraft:moss_block
setblock 241 242 363 minecraft:mushroom_stem
fill 242 242 323 245 242 323 minecraft:moss_block
fill 242 242 363 243 244 363 minecraft:moss_block
setblock 246 242 323 minecraft:mushroom_stem
setblock 247 242 363 minecraft:red_mushroom_block
fill 252 242 323 252 245 323 minecraft:moss_block
fill 252 242 363 255 242 363 minecraft:moss_block
fill 255 242 362 256 242 362 minecraft:moss_block
setblock 256 242 323 minecraft:mushroom_stem
setblock 256 242 363 minecraft:mushroom_stem
fill 257 242 323 257 245 323 minecraft:moss_block
setblock 257 242 362 minecraft:mushroom_stem
fill 257 242 363 257 245 363 minecraft:moss_block
fill 258 242 362 258 245 362 minecraft:moss_block
setblock 261 242 363 minecraft:mushroom_stem
setblock 265 242 323 minecraft:red_mushroom_block
fill 271 242 346 271 252 346 minecraft:dirt
setblock 272 242 363 minecraft:red_mushroom_block
setblock 274 242 329 minecraft:moss_block
setblock 274 242 330 minecraft:mushroom_stem
fill 274 242 331 274 242 334 minecraft:moss_block
setblock 274 242 349 minecraft:moss_block
setblock 274 242 350 minecraft:mushroom_stem
setblock 275 242 323 minecraft:moss_block
fill 275 242 325 275 242 328 minecraft:moss_block
setblock 275 242 329 minecraft:mushroom_stem
fill 275 242 330 275 245 330 minecraft:moss_block
fill 275 242 332 275 242 333 minecraft:moss_block
setblock 275 242 334 minecraft:mushroom_stem
fill 275 242 335 275 245 335 minecraft:moss_block
setblock 275 242 338 minecraft:moss_block
setblock 275 242 339 minecraft:mushroom_stem
fill 275 242 340 275 243 342 minecraft:moss_block
setblock 275 242 344 minecraft:mushroom_stem
fill 275 242 345 275 245 345 minecraft:moss_block
setblock 275 242 349 minecraft:mushroom_stem
fill 275 242 350 275 245 350 minecraft:moss_block
setblock 275 242 353 minecraft:moss_block
setblock 275 242 354 minecraft:mushroom_stem
fill 275 242 355 275 245 355 minecraft:moss_block
setblock 276 242 323 minecraft:mushroom_stem
fill 276 242 324 276 245 324 minecraft:moss_block
setblock 276 242 328 minecraft:mushroom_stem
fill 276 242 329 276 245 329 minecraft:moss_block
setblock 276 242 333 minecraft:mushroom_stem
fill 276 242 334 276 245 334 minecraft:moss_block
setblock 276 242 338 minecraft:mushroom_stem
fill 276 242 339 276 245 339 minecraft:moss_block
setblock 276 242 343 minecraft:mushroom_stem
fill 276 242 344 276 245 344 minecraft:moss_block
setblock 276 242 348 minecraft:mushroom_stem
fill 276 242 349 276 245 349 minecraft:moss_block
setblock 276 242 353 minecraft:mushroom_stem
fill 276 242 354 276 245 354 minecraft:moss_block
setblock 276 242 357 minecraft:moss_block
setblock 276 242 358 minecraft:mushroom_stem
fill 236 243 323 236 246 323 minecraft:moss_block
setblock 236 243 327 minecraft:mushroom_stem
fill 236 243 328 236 246 328 minecraft:moss_block
setblock 236 243 332 minecraft:mushroom_stem
fill 236 243 333 236 246 333 minecraft:moss_block
setblock 236 243 336 minecraft:moss_block
setblock 236 243 337 minecraft:mushroom_stem
fill 236 243 338 236 246 338 minecraft:moss_block
setblock 236 243 342 minecraft:mushroom_stem
fill 236 243 343 236 246 343 minecraft:moss_block
setblock 236 243 347 minecraft:mushroom_stem
fill 236 243 348 236 246 348 minecraft:moss_block
setblock 236 243 351 minecraft:moss_block
setblock 236 243 352 minecraft:mushroom_stem
fill 236 243 353 236 246 353 minecraft:moss_block
setblock 236 243 357 minecraft:mushroom_stem
fill 236 243 358 237 245 358 minecraft:moss_block
fill 236 243 360 236 243 361 minecraft:moss_block
setblock 236 243 362 minecraft:mushroom_stem
fill 236 243 363 239 243 363 minecraft:moss_block
setblock 237 243 326 minecraft:mushroom_stem
fill 237 243 327 237 246 327 minecraft:moss_block
setblock 237 243 331 minecraft:mushroom_stem
fill 237 243 332 237 246 332 minecraft:moss_block
setblock 237 243 336 minecraft:mushroom_stem
fill 237 243 337 237 246 337 minecraft:moss_block
fill 237 243 339 237 244 339 minecraft:moss_block
setblock 237 243 347 minecraft:moss_block
setblock 237 243 351 minecraft:mushroom_stem
fill 237 243 352 237 246 352 minecraft:moss_block
setblock 237 243 356 minecraft:mushroom_stem
fill 237 243 357 237 246 357 minecraft:moss_block
setblock 238 243 325 minecraft:mushroom_stem
fill 238 243 326 238 246 326 minecraft:moss_block
setblock 238 243 330 minecraft:mushroom_stem
fill 238 243 331 238 246 331 minecraft:moss_block
setblock 238 243 335 minecraft:mushroom_stem
fill 238 243 336 238 246 336 minecraft:moss_block
setblock 238 243 339 minecraft:light[level=12]
fill 238 243 344 238 253 344 minecraft:iron_block
setblock 238 243 346 minecraft:light[level=12]
setblock 238 243 353 minecraft:light[level=12]
setblock 238 243 360 minecraft:light[level=12]
setblock 239 243 324 minecraft:mushroom_stem
fill 239 243 325 239 246 325 minecraft:moss_block
setblock 239 243 329 minecraft:mushroom_stem
fill 239 243 330 239 246 330 minecraft:moss_block
setblock 239 243 333 minecraft:moss_block
setblock 240 243 323 minecraft:mushroom_stem
fill 240 243 324 240 246 324 minecraft:moss_block
setblock 240 243 363 minecraft:mushroom_stem
fill 240 243 364 240 308 364 minecraft:moss_block
fill 241 243 323 244 243 323 minecraft:moss_block
fill 241 243 363 241 246 363 minecraft:moss_block
fill 242 243 324 243 243 324 minecraft:moss_block
setblock 245 243 323 minecraft:mushroom_stem
setblock 245 243 325 minecraft:light[level=12]
setblock 245 243 332 minecraft:light[level=12]
setblock 245 243 339 minecraft:light[level=12]
setblock 245 243 346 minecraft:light[level=12]
setblock 245 243 353 minecraft:light[level=12]
setblock 245 243 360 minecraft:light[level=12]
setblock 246 243 323 minecraft:moss_block
setblock 250 243 363 minecraft:mushroom_stem
fill 251 243 323 251 246 323 minecraft:moss_block
fill 251 243 363 254 243 363 minecraft:moss_block
setblock 252 243 325 minecraft:light[level=12]
setblock 252 243 332 minecraft:light[level=12]
setblock 252 243 339 minecraft:light[level=12]
setblock 252 243 353 minecraft:light[level=12]
setblock 252 243 360 minecraft:light[level=12]
fill 253 243 364 256 264 364 minecraft:moss_block
fill 254 243 362 255 243 362 minecraft:moss_block
setblock 255 243 323 minecraft:mushroom_stem
setblock 255 243 363 minecraft:mushroom_stem
fill 256 243 323 256 246 323 minecraft:moss_block
setblock 256 243 362 minecraft:mushroom_stem
fill 256 243 363 256 246 363 minecraft:moss_block
fill 257 243 362 257 246 362 minecraft:moss_block
setblock 257 243 364 minecraft:red_mushroom_block
fill 258 243 364 259 308 364 minecraft:moss_block
setblock 259 243 325 minecraft:light[level=12]
setblock 259 243 332 minecraft:light[level=12]
setblock 259 243 339 minecraft:light[level=12]
setblock 259 243 346 minecraft:light[level=12]
setblock 259 243 353 minecraft:light[level=12]
setblock 259 243 360 minecraft:light[level=12]
setblock 260 243 323 minecraft:mushroom_stem
setblock 260 243 363 minecraft:mushroom_stem
fill 261 243 363 261 246 363 minecraft:moss_block
setblock 266 243 325 minecraft:light[level=12]
setblock 266 243 332 minecraft:light[level=12]
setblock 266 243 339 minecraft:light[level=12]
setblock 266 243 346 minecraft:light[level=12]
setblock 266 243 353 minecraft:light[level=12]
setblock 266 243 360 minecraft:light[level=12]
fill 271 243 345 271 252 345 minecraft:dirt
fill 272 243 346 272 252 346 minecraft:dirt
setblock 273 243 325 minecraft:light[level=12]
setblock 273 243 332 minecraft:light[level=12]
setblock 273 243 339 minecraft:light[level=12]
setblock 273 243 346 minecraft:light[level=12]
setblock 273 243 353 minecraft:light[level=12]
setblock 273 243 360 minecraft:light[level=12]
setblock 274 243 323 minecraft:moss_block
setblock 274 243 328 minecraft:moss_block
setblock 274 243 329 minecraft:mushroom_stem
fill 274 243 330 274 243 333 minecraft:moss_block
setblock 274 243 334 minecraft:mushroom_stem
fill 274 243 335 274 245 336 minecraft:moss_block
setblock 274 243 348 minecraft:moss_block
setblock 274 243 349 minecraft:mushroom_stem
fill 274 243 350 274 244 352 minecraft:moss_block
setblock 275 243 323 minecraft:mushroom_stem
fill 275 243 325 275 243 327 minecraft:moss_block
setblock 275 243 328 minecraft:mushroom_stem
fill 275 243 329 275 246 329 minecraft:moss_block
setblock 275 243 332 minecraft:moss_block
setblock 275 243 333 minecraft:mushroom_stem
fill 275 243 334 275 246 334 minecraft:moss_block
setblock 275 243 338 minecraft:mushroom_stem
fill 275 243 339 275 246 339 minecraft:moss_block
setblock 275 243 343 minecraft:mushroom_stem
fill 275 243 344 275 246 344 minecraft:moss_block
setblock 275 243 348 minecraft:mushroom_stem
fill 275 243 349 275 246 349 minecraft:moss_block
setblock 275 243 353 minecraft:mushroom_stem
fill 275 243 354 275 246 354 minecraft:moss_block
fill 275 243 356 275 244 356 minecraft:moss_block
fill 276 243 323 276 246 323 minecraft:moss_block
setblock 276 243 327 minecraft:mushroom_stem
fill 276 243 328 276 246 328 minecraft:moss_block
setblock 276 243 332 minecraft:mushroom_stem
fill 276 243 333 276 246 333 minecraft:moss_block
setblock 276 243 337 minecraft:mushroom_stem
fill 276 243 338 276 246 338 minecraft:moss_block
setblock 276 243 342 minecraft:mushroom_stem
fill 276 243 343 276 246 343 minecraft:moss_block
setblock 276 243 347 minecraft:mushroom_stem
fill 276 243 348 276 246 348 minecraft:moss_block
setblock 276 243 352 minecraft:mushroom_stem
fill 276 243 353 276 246 353 minecraft:moss_block
setblock 276 243 357 minecraft:mushroom_stem
fill 276 243 358 276 245 359 minecraft:moss_block
setblock 277 243 335 minecraft:shroomlight
fill 277 243 336 277 308 336 minecraft:moss_block
setblock 235 244 361 minecraft:shroomlight
setblock 236 244 326 minecraft:mushroom_stem
fill 236 244 327 236 247 327 minecraft:moss_block
setblock 236 244 331 minecraft:mushroom_stem
fill 236 244 332 236 247 332 minecraft:moss_block
setblock 236 244 336 minecraft:mushroom_stem
fill 236 244 337 236 247 337 minecraft:moss_block
setblock 236 244 341 minecraft:mushroom_stem
fill 236 244 342 236 247 342 minecraft:moss_block
setblock 236 244 346 minecraft:mushroom_stem
fill 236 244 347 236 247 347 minecraft:moss_block
setblock 236 244 351 minecraft:mushroom_stem
fill 236 244 352 236 247 352 minecraft:moss_block
setblock 236 244 355 minecraft:moss_block
setblock 236 244 356 minecraft:mushroom_stem
fill 236 244 357 236 247 357 minecraft:moss_block
setblock 236 244 360 minecraft:moss_block
setblock 236 244 361 minecraft:mushroom_stem
fill 236 244 362 236 246 363 minecraft:moss_block
setblock 237 244 325 minecraft:mushroom_stem
fill 237 244 326 237 247 326 minecraft:moss_block
setblock 237 244 330 minecraft:mushroom_stem
fill 237 244 331 237 247 331 minecraft:moss_block
setblock 237 244 334 minecraft:moss_block
setblock 237 244 335 minecraft:mushroom_stem
fill 237 244 336 237 247 336 minecraft:moss_block
setblock 237 244 340 minecraft:mushroom_stem
setblock 237 244 350 minecraft:mushroom_stem
fill 237 244 351 237 247 351 minecraft:moss_block
setblock 237 244 355 minecraft:mushroom_stem
fill 237 244 356 237 247 356 minecraft:moss_block
setblock 237 244 359 minecraft:moss_block
setblock 237 244 360 minecraft:mushroom_stem
fill 237 244 361 237 247 361 minecraft:moss_block
fill 237 244 363 238 244 363 minecraft:moss_block
setblock 238 244 324 minecraft:mushroom_stem
fill 238 244 325 238 246 325 minecraft:moss_block
setblock 238 244 329 minecraft:mushroom_stem
fill 238 244 330 238 247 330 minecraft:moss_block
setblock 238 244 334 minecraft:mushroom_stem
fill 238 244 335 238 247 335 minecraft:moss_block
setblock 238 244 353 minecraft:moss_block
setblock 238 244 354 minecraft:mushroom_stem
fill 238 244 355 238 247 355 minecraft:moss_block
fill 238 244 362 238 245 362 minecraft:moss_block
setblock 239 244 323 minecraft:mushroom_stem
fill 239 244 324 239 247 324 minecraft:moss_block
setblock 239 244 328 minecraft:mushroom_stem
fill 239 244 329 239 246 329 minecraft:moss_block
setblock 239 244 333 minecraft:mushroom_stem
setblock 239 244 363 minecraft:mushroom_stem
fill 240 244 323 243 244 323 minecraft:moss_block
fill 240 244 363 240 247 363 minecraft:moss_block
setblock 242 244 324 minecraft:moss_block
setblock 243 244 324 minecraft:mushroom_stem
setblock 244 244 323 minecraft:mushroom_stem
setblock 244 244 363 minecraft:mushroom_stem
fill 245 244 323 245 245 323 minecraft:moss_block
setblock 247 244 323 minecraft:red_mushroom_block
setblock 249 244 363 minecraft:mushroom_stem
fill 250 244 363 253 244 363 minecraft:moss_block
fill 252 244 362 254 244 362 minecraft:moss_block
setblock 254 244 323 minecraft:mushroom_stem
setblock 254 244 363 minecraft:mushroom_stem
fill 255 244 323 255 247 323 minecraft:moss_block
setblock 255 244 361 minecraft:moss_block
setblock 255 244 362 minecraft:mushroom_stem
fill 255 244 363 255 247 363 minecraft:moss_block
setblock 256 244 361 minecraft:mushroom_stem
fill 256 244 362 256 247 362 minecraft:moss_block
fill 257 244 361 257 247 361 minecraft:moss_block
fill 257 244 364 257 263 364 minecraft:moss_block
setblock 259 244 323 minecraft:mushroom_stem
setblock 259 244 363 minecraft:mushroom_stem
fill 260 244 363 260 247 363 minecraft:moss_block
fill 270 244 345 270 252 346 minecraft:dirt
fill 271 244 347 272 252 347 minecraft:dirt
setblock 272 244 323 minecraft:red_mushroom_block
fill 272 244 345 272 252 345 minecraft:dirt
fill 273 244 332 273 244 333 minecraft:moss_block
setblock 274 244 323 minecraft:mushroom_stem
setblock 274 244 327 minecraft:moss_block
setblock 274 244 328 minecraft:mushroom_stem
fill 274 244 329 274 244 332 minecraft:moss_block
setblock 274 244 333 minecraft:mushroom_stem
fill 274 244 334 274 247 334 minecraft:moss_block
setblock 274 244 337 minecraft:moss_block
setblock 274 244 338 minecraft:mushroom_stem
setblock 274 244 348 minecraft:mushroom_stem
fill 274 244 349 274 246 349 minecraft:moss_block
setblock 274 244 353 minecraft:mushroom_stem
fill 274 244 354 274 247 354 minecraft:moss_block
fill 275 244 323 275 244 326 minecraft:moss_block
setblock 275 244 327 minecraft:mushroom_stem
fill 275 244 328 275 247 328 minecraft:moss_block
setblock 275 244 332 minecraft:mushroom_stem
fill 275 244 333 275 247 333 minecraft:moss_block
setblock 275 244 336 minecraft:moss_block
setblock 275 244 337 minecraft:mushroom_stem
fill 275 244 338 275 247 338 minecraft:moss_block
fill 275 244 340 275 244 341 minecraft:moss_block
setblock 275 244 342 minecraft:mushroom_stem
fill 275 244 343 275 247 343 minecraft:moss_block
setblock 275 244 347 minecraft:mushroom_stem
fill 275 244 348 275 247 348 minecraft:moss_block
setblock 275 244 352 minecraft:mushroom_stem
fill 275 244 353 275 247 353 minecraft:moss_block
setblock 275 244 357 minecraft:mushroom_stem
setblock 276 244 326 minecraft:mushroom_stem
fill 276 244 327 276 247 327 minecraft:moss_block
setblock 276 244 331 minecraft:mushroom_stem
fill 276 244 332 276 247 332 minecraft:moss_block
setblock 276 244 336 minecraft:mushroom_stem
fill 276 244 337 276 247 337 minecraft:moss_block
setblock 276 244 341 minecraft:mushroom_stem
fill 276 244 342 276 247 342 minecraft:moss_block
setblock 276 244 346 minecraft:mushroom_stem
fill 276 244 347 276 247 347 minecraft:moss_block
setblock 276 244 351 minecraft:mushroom_stem
fill 276 244 352 276 247 352 minecraft:moss_block
setblock 276 244 355 minecraft:moss_block
setblock 276 244 356 minecraft:mushroom_stem
fill 276 244 357 276 247 357 minecraft:moss_block
setblock 276 244 360 minecraft:moss_block
setblock 276 244 361 minecraft:mushroom_stem
fill 277 244 335 277 257 335 minecraft:moss_block
setblock 277 244 349 minecraft:red_mushroom_block
setblock 235 245 339 minecraft:shroomlight
fill 235 245 340 235 267 343 minecraft:moss_block
fill 235 245 361 236 248 361 minecraft:moss_block
setblock 236 245 325 minecraft:mushroom_stem
fill 236 245 326 236 248 326 minecraft:moss_block
setblock 236 245 330 minecraft:mushroom_stem
fill 236 245 331 236 248 331 minecraft:moss_block
setblock 236 245 335 minecraft:mushroom_stem
fill 236 245 336 236 248 336 minecraft:moss_block
setblock 236 245 340 minecraft:mushroom_stem
fill 236 245 341 236 248 341 minecraft:moss_block
setblock 236 245 345 minecraft:mushroom_stem
fill 236 245 346 236 247 346 minecraft:moss_block
setblock 236 245 350 minecraft:mushroom_stem
fill 236 245 351 236 248 351 minecraft:moss_block
setblock 236 245 354 minecraft:moss_block
setblock 236 245 355 minecraft:mushroom_stem
fill 236 245 356 236 248 356 minecraft:moss_block
setblock 236 245 360 minecraft:mushroom_stem
setblock 237 245 324 minecraft:mushroom_stem
fill 237 245 325 237 248 325 minecraft:moss_block
setblock 237 245 329 minecraft:mushroom_stem
fill 237 245 330 237 248 330 minecraft:moss_block
setblock 237 245 334 minecraft:mushroom_stem
fill 237 245 335 237 248 335 minecraft:moss_block
setblock 237 245 339 minecraft:mushroom_stem
fill 237 245 340 237 248 340 minecraft:moss_block
setblock 237 245 349 minecraft:mushroom_stem
fill 237 245 350 237 247 350 minecraft:moss_block
setblock 237 245 354 minecraft:mushroom_stem
fill 237 245 355 237 248 355 minecraft:moss_block
setblock 237 245 359 minecraft:mushroom_stem
fill 237 245 360 237 248 360 minecraft:moss_block
fill 237 245 362 237 245 363 minecraft:moss_block
setblock 238 245 323 minecraft:mushroom_stem
fill 238 245 324 238 248 324 minecraft:moss_block
setblock 238 245 328 minecraft:mushroom_stem
fill 238 245 329 238 248 329 minecraft:moss_block
setblock 238 245 332 minecraft:moss_block
setblock 238 245 333 minecraft:mushroom_stem
fill 238 245 334 239 245 334 minecraft:moss_block
setblock 238 245 337 minecraft:moss_block
setblock 238 245 341 minecraft:light[level=15]
setblock 238 245 349 minecraft:light[level=15]
setblock 238 245 353 minecraft:mushroom_stem
fill 238 245 354 238 247 354 minecraft:moss_block
fill 238 245 356 238 245 357 minecraft:moss_block
setblock 238 245 363 minecraft:mushroom_stem
fill 239 245 323 242 245 323 minecraft:moss_block
setblock 239 245 328 minecraft:moss_block
setblock 239 245 332 minecraft:mushroom_stem
fill 239 245 333 239 246 333 minecraft:moss_block
fill 239 245 335 242 246 335 minecraft:dirt
setblock 239 245 362 minecraft:mushroom_stem
fill 239 245 363 239 248 363 minecraft:moss_block
fill 240 245 331 242 246 334 minecraft:dirt
fill 240 245 362 240 248 362 minecraft:moss_block
setblock 242 245 324 minecraft:mushroom_stem
setblock 242 245 363 minecraft:moss_block
setblock 242 245 364 minecraft:shroomlight
setblock 243 245 323 minecraft:mushroom_stem
setblock 243 245 363 minecraft:mushroom_stem
fill 243 245 364 248 283 364 minecraft:moss_block
fill 244 245 323 244 246 323 minecraft:moss_block
fill 244 245 363 247 245 363 minecraft:moss_block
setblock 246 245 325 minecraft:light[level=15]
setblock 246 245 333 minecraft:light[level=15]
setblock 246 245 341 minecraft:light[level=15]
setblock 246 245 349 minecraft:light[level=15]
setblock 246 245 357 minecraft:light[level=15]
setblock 248 245 363 minecraft:mushroom_stem
fill 249 245 363 252 245 363 minecraft:moss_block
fill 250 245 323 250 247 323 minecraft:moss_block
fill 250 245 358 254 245 360 minecraft:red_mushroom_block
fill 251 245 357 253 245 357 minecraft:red_mushroom_block
fill 251 245 361 253 245 361 minecraft:red_mushroom_block
fill 251 245 362 253 245 362 minecraft:moss_block
setblock 253 245 323 minecraft:mushroom_stem
setblock 253 245 363 minecraft:mushroom_stem
fill 254 245 323 254 248 323 minecraft:moss_block
setblock 254 245 325 minecraft:light[level=15]
setblock 254 245 333 minecraft:light[level=15]
setblock 254 245 341 minecraft:light[level=15]
setblock 254 245 349 minecraft:light[level=15]
setblock 254 245 357 minecraft:light[level=15]
setblock 254 245 361 minecraft:moss_block
setblock 254 245 362 minecraft:mushroom_stem
fill 254 245 363 254 248 363 minecraft:moss_block
setblock 255 245 361 minecraft:mushroom_stem
fill 255 245 362 255 248 362 minecraft:moss_block
fill 256 245 361 256 248 361 minecraft:moss_block
setblock 258 245 323 minecraft:mushroom_stem
fill 258 245 361 258 246 361 minecraft:moss_block
setblock 258 245 363 minecraft:mushroom_stem
setblock 259 245 323 minecraft:moss_block
setblock 259 245 362 minecraft:mushroom_stem
fill 259 245 363 259 248 363 minecraft:moss_block
setblock 262 245 325 minecraft:light[level=15]
setblock 262 245 333 minecraft:light[level=15]
setblock 262 245 341 minecraft:light[level=15]
setblock 262 245 349 minecraft:light[level=15]
setblock 262 245 357 minecraft:light[level=15]
setblock 265 245 363 minecraft:red_mushroom_block
setblock 266 245 323 minecraft:red_mushroom_block
setblock 270 245 325 minecraft:light[level=15]
setblock 270 245 333 minecraft:light[level=15]
setblock 270 245 341 minecraft:light[level=15]
fill 270 245 347 270 252 347 minecraft:dirt
setblock 270 245 349 minecraft:light[level=15]
setblock 270 245 357 minecraft:light[level=15]
fill 271 245 344 271 252 344 minecraft:dirt
fill 271 245 363 271 246 363 minecraft:red_mushroom_block
setblock 273 245 323 minecraft:mushroom_stem
fill 273 245 330 273 245 332 minecraft:moss_block
setblock 273 245 333 minecraft:mushroom_stem
fill 273 245 334 273 246 336 minecraft:moss_block
fill 273 245 346 273 252 346 minecraft:dirt
fill 274 245 323 275 247 323 minecraft:moss_block
setblock 274 245 327 minecraft:mushroom_stem
fill 274 245 328 274 245 331 minecraft:moss_block
setblock 274 245 332 minecraft:mushroom_stem
fill 274 245 333 274 248 333 minecraft:moss_block
setblock 274 245 337 minecraft:mushroom_stem
fill 274 245 338 274 246 340 minecraft:moss_block
setblock 274 245 348 minecraft:moss_block
fill 274 245 350 274 245 351 minecraft:moss_block
setblock 274 245 352 minecraft:mushroom_stem
fill 274 245 353 274 248 353 minecraft:moss_block
fill 274 245 355 274 246 355 minecraft:moss_block
fill 275 245 324 275 245 325 minecraft:moss_block
setblock 275 245 326 minecraft:mushroom_stem
fill 275 245 327 275 248 327 minecraft:moss_block
setblock 275 245 331 minecraft:mushroom_stem
fill 275 245 332 275 248 332 minecraft:moss_block
setblock 275 245 336 minecraft:mushroom_stem
fill 275 245 337 275 248 337 minecraft:moss_block
setblock 275 245 340 minecraft:moss_block
setblock 275 245 341 minecraft:mushroom_stem
fill 275 245 342 275 248 342 minecraft:moss_block
setblock 275 245 346 minecraft:mushroom_stem
fill 275 245 347 275 248 347 minecraft:moss_block
setblock 275 245 351 minecraft:mushroom_stem
fill 275 245 352 275 248 352 minecraft:moss_block
setblock 275 245 356 minecraft:mushroom_stem
fill 275 245 357 275 247 358 minecraft:moss_block
fill 275 245 363 276 246 363 minecraft:moss_block
setblock 276 245 325 minecraft:mushroom_stem
fill 276 245 326 276 248 326 minecraft:moss_block
setblock 276 245 330 minecraft:mushroom_stem
fill 276 245 331 276 248 331 minecraft:moss_block
setblock 276 245 335 minecraft:mushroom_stem
fill 276 245 336 276 248 336 minecraft:moss_block
setblock 276 245 340 minecraft:mushroom_stem
fill 276 245 341 276 248 341 minecraft:moss_block
setblock 276 245 345 minecraft:mushroom_stem
fill 276 245 346 276 248 346 minecraft:moss_block
setblock 276 245 350 minecraft:mushroom_stem
fill 276 245 351 276 248 351 minecraft:moss_block
setblock 276 245 355 minecraft:mushroom_stem
fill 276 245 356 276 248 356 minecraft:moss_block
setblock 276 245 360 minecraft:mushroom_stem
fill 276 245 361 276 247 362 minecraft:moss_block
fill 277 245 349 277 308 349 minecraft:moss_block
schedule function dropper:buildpart/77_8 1t
