fill 51 263 616 51 264 616 minecraft:light_gray_concrete
fill 51 263 618 51 264 618 minecraft:light_gray_concrete
fill 51 263 620 51 264 620 minecraft:light_gray_concrete
fill 51 263 622 51 264 622 minecraft:light_gray_concrete
fill 51 263 624 51 264 624 minecraft:light_gray_concrete
fill 52 263 613 52 264 613 minecraft:light_gray_concrete
fill 52 263 615 52 264 615 minecraft:light_gray_concrete
fill 52 263 617 52 264 617 minecraft:light_gray_concrete
fill 52 263 619 52 264 619 minecraft:light_gray_concrete
fill 52 263 621 52 264 621 minecraft:light_gray_concrete
fill 52 263 623 52 264 623 minecraft:light_gray_concrete
fill 52 263 625 52 264 625 minecraft:light_gray_concrete
fill 53 263 614 53 264 614 minecraft:light_gray_concrete
fill 53 263 616 53 264 616 minecraft:light_gray_concrete
fill 53 263 618 53 264 618 minecraft:light_gray_concrete
fill 53 263 620 53 264 620 minecraft:light_gray_concrete
fill 53 263 622 53 264 622 minecraft:light_gray_concrete
fill 53 263 624 53 264 624 minecraft:light_gray_concrete
fill 54 263 613 54 264 613 minecraft:light_gray_concrete
fill 54 263 615 54 264 615 minecraft:light_gray_concrete
fill 54 263 617 54 264 617 minecraft:light_gray_concrete
fill 54 263 619 54 264 619 minecraft:light_gray_concrete
fill 54 263 621 54 264 621 minecraft:light_gray_concrete
fill 54 263 623 54 264 623 minecraft:light_gray_concrete
fill 54 263 625 54 264 625 minecraft:light_gray_concrete
fill 55 263 614 55 264 614 minecraft:light_gray_concrete
fill 55 263 616 55 264 616 minecraft:light_gray_concrete
fill 55 263 618 55 264 618 minecraft:light_gray_concrete
fill 55 263 620 55 264 620 minecraft:light_gray_concrete
fill 55 263 622 55 264 622 minecraft:light_gray_concrete
fill 55 263 624 55 264 624 minecraft:light_gray_concrete
fill 56 263 613 56 264 613 minecraft:light_gray_concrete
fill 56 263 615 56 264 615 minecraft:light_gray_concrete
fill 56 263 617 56 264 617 minecraft:light_gray_concrete
fill 56 263 619 56 264 619 minecraft:light_gray_concrete
fill 56 263 621 56 264 621 minecraft:light_gray_concrete
fill 56 263 623 56 264 623 minecraft:light_gray_concrete
fill 56 263 625 56 264 625 minecraft:light_gray_concrete
fill 57 263 614 57 264 614 minecraft:light_gray_concrete
fill 57 263 616 57 264 616 minecraft:light_gray_concrete
fill 57 263 618 57 264 618 minecraft:light_gray_concrete
fill 57 263 620 57 264 620 minecraft:light_gray_concrete
fill 57 263 622 57 264 622 minecraft:light_gray_concrete
fill 57 263 624 57 264 624 minecraft:light_gray_concrete
fill 78 263 605 78 264 605 minecraft:light_gray_concrete
fill 78 263 607 78 264 607 minecraft:light_gray_concrete
fill 78 263 609 78 264 609 minecraft:light_gray_concrete
fill 78 263 611 78 264 611 minecraft:light_gray_concrete
fill 78 263 613 78 264 613 minecraft:light_gray_concrete
fill 79 263 606 79 264 606 minecraft:light_gray_concrete
fill 79 263 608 79 264 608 minecraft:light_gray_concrete
fill 79 263 610 79 264 610 minecraft:light_gray_concrete
fill 79 263 612 79 264 612 minecraft:light_gray_concrete
fill 80 263 605 80 264 605 minecraft:light_gray_concrete
fill 80 263 607 80 264 607 minecraft:light_gray_concrete
fill 80 263 609 80 264 609 minecraft:light_gray_concrete
fill 80 263 611 80 264 611 minecraft:light_gray_concrete
fill 80 263 613 80 264 613 minecraft:light_gray_concrete
fill 81 263 606 81 264 606 minecraft:light_gray_concrete
fill 81 263 608 81 264 608 minecraft:light_gray_concrete
fill 81 263 610 81 264 610 minecraft:light_gray_concrete
fill 81 263 612 81 264 612 minecraft:light_gray_concrete
fill 82 263 605 82 264 605 minecraft:light_gray_concrete
fill 82 263 607 82 264 607 minecraft:light_gray_concrete
fill 82 263 609 82 264 609 minecraft:light_gray_concrete
fill 82 263 611 82 264 611 minecraft:light_gray_concrete
fill 82 263 613 82 264 613 minecraft:light_gray_concrete
fill 83 263 606 83 264 606 minecraft:light_gray_concrete
fill 83 263 608 83 264 608 minecraft:light_gray_concrete
fill 83 263 610 83 264 610 minecraft:light_gray_concrete
fill 83 263 612 83 264 612 minecraft:light_gray_concrete
fill 84 263 605 84 264 605 minecraft:light_gray_concrete
fill 84 263 607 84 264 607 minecraft:light_gray_concrete
fill 84 263 609 84 264 609 minecraft:light_gray_concrete
fill 84 263 611 84 264 611 minecraft:light_gray_concrete
fill 84 263 613 84 264 613 minecraft:light_gray_concrete
fill 85 263 606 85 264 606 minecraft:light_gray_concrete
fill 85 263 608 85 264 608 minecraft:light_gray_concrete
fill 85 263 610 85 264 610 minecraft:light_gray_concrete
fill 85 263 612 85 264 612 minecraft:light_gray_concrete
fill 86 263 605 86 264 605 minecraft:light_gray_concrete
fill 86 263 607 86 264 607 minecraft:light_gray_concrete
fill 86 263 609 86 264 609 minecraft:light_gray_concrete
fill 86 263 611 86 264 611 minecraft:light_gray_concrete
fill 86 263 613 86 264 613 minecraft:light_gray_concrete
setblock 48 265 613 minecraft:sea_lantern
setblock 48 265 615 minecraft:sea_lantern
setblock 48 265 617 minecraft:sea_lantern
setblock 48 265 619 minecraft:sea_lantern
setblock 48 265 621 minecraft:sea_lantern
setblock 48 265 623 minecraft:sea_lantern
setblock 48 265 625 minecraft:sea_lantern
setblock 49 265 614 minecraft:sea_lantern
setblock 49 265 616 minecraft:sea_lantern
setblock 49 265 618 minecraft:sea_lantern
setblock 49 265 620 minecraft:sea_lantern
setblock 49 265 622 minecraft:sea_lantern
setblock 49 265 624 minecraft:sea_lantern
setblock 50 265 613 minecraft:sea_lantern
setblock 50 265 615 minecraft:sea_lantern
setblock 50 265 617 minecraft:sea_lantern
setblock 50 265 619 minecraft:sea_lantern
setblock 50 265 621 minecraft:sea_lantern
setblock 50 265 623 minecraft:sea_lantern
setblock 50 265 625 minecraft:sea_lantern
setblock 51 265 614 minecraft:sea_lantern
setblock 51 265 616 minecraft:sea_lantern
setblock 51 265 618 minecraft:sea_lantern
setblock 51 265 620 minecraft:sea_lantern
setblock 51 265 622 minecraft:sea_lantern
setblock 51 265 624 minecraft:sea_lantern
setblock 52 265 613 minecraft:sea_lantern
setblock 52 265 615 minecraft:sea_lantern
setblock 52 265 617 minecraft:sea_lantern
setblock 52 265 619 minecraft:sea_lantern
setblock 52 265 621 minecraft:sea_lantern
setblock 52 265 623 minecraft:sea_lantern
setblock 52 265 625 minecraft:sea_lantern
setblock 53 265 614 minecraft:sea_lantern
setblock 53 265 616 minecraft:sea_lantern
setblock 53 265 618 minecraft:sea_lantern
setblock 53 265 620 minecraft:sea_lantern
setblock 53 265 622 minecraft:sea_lantern
setblock 53 265 624 minecraft:sea_lantern
setblock 54 265 613 minecraft:sea_lantern
setblock 54 265 615 minecraft:sea_lantern
setblock 54 265 617 minecraft:sea_lantern
setblock 54 265 619 minecraft:sea_lantern
setblock 54 265 621 minecraft:sea_lantern
setblock 54 265 623 minecraft:sea_lantern
setblock 54 265 625 minecraft:sea_lantern
setblock 55 265 614 minecraft:sea_lantern
setblock 55 265 616 minecraft:sea_lantern
setblock 55 265 618 minecraft:sea_lantern
setblock 55 265 620 minecraft:sea_lantern
setblock 55 265 622 minecraft:sea_lantern
setblock 55 265 624 minecraft:sea_lantern
setblock 56 265 613 minecraft:sea_lantern
setblock 56 265 615 minecraft:sea_lantern
setblock 56 265 617 minecraft:sea_lantern
setblock 56 265 619 minecraft:sea_lantern
setblock 56 265 621 minecraft:sea_lantern
setblock 56 265 623 minecraft:sea_lantern
setblock 56 265 625 minecraft:sea_lantern
setblock 57 265 614 minecraft:sea_lantern
setblock 57 265 616 minecraft:sea_lantern
setblock 57 265 618 minecraft:sea_lantern
setblock 57 265 620 minecraft:sea_lantern
setblock 57 265 622 minecraft:sea_lantern
setblock 57 265 624 minecraft:sea_lantern
setblock 78 265 605 minecraft:sea_lantern
setblock 78 265 607 minecraft:sea_lantern
setblock 78 265 609 minecraft:sea_lantern
setblock 78 265 611 minecraft:sea_lantern
setblock 78 265 613 minecraft:sea_lantern
setblock 79 265 606 minecraft:sea_lantern
setblock 79 265 608 minecraft:sea_lantern
setblock 79 265 610 minecraft:sea_lantern
setblock 79 265 612 minecraft:sea_lantern
setblock 80 265 605 minecraft:sea_lantern
setblock 80 265 607 minecraft:sea_lantern
setblock 80 265 609 minecraft:sea_lantern
setblock 80 265 611 minecraft:sea_lantern
setblock 80 265 613 minecraft:sea_lantern
setblock 81 265 606 minecraft:sea_lantern
setblock 81 265 608 minecraft:sea_lantern
setblock 81 265 610 minecraft:sea_lantern
setblock 81 265 612 minecraft:sea_lantern
setblock 82 265 605 minecraft:sea_lantern
setblock 82 265 607 minecraft:sea_lantern
setblock 82 265 609 minecraft:sea_lantern
setblock 82 265 611 minecraft:sea_lantern
setblock 82 265 613 minecraft:sea_lantern
setblock 83 265 606 minecraft:sea_lantern
setblock 83 265 608 minecraft:sea_lantern
setblock 83 265 610 minecraft:sea_lantern
setblock 83 265 612 minecraft:sea_lantern
setblock 84 265 605 minecraft:sea_lantern
setblock 84 265 607 minecraft:sea_lantern
setblock 84 265 609 minecraft:sea_lantern
setblock 84 265 611 minecraft:sea_lantern
setblock 84 265 613 minecraft:sea_lantern
setblock 85 265 606 minecraft:sea_lantern
setblock 85 265 608 minecraft:sea_lantern
setblock 85 265 610 minecraft:sea_lantern
setblock 85 265 612 minecraft:sea_lantern
setblock 86 265 605 minecraft:sea_lantern
setblock 86 265 607 minecraft:sea_lantern
setblock 86 265 609 minecraft:sea_lantern
setblock 86 265 611 minecraft:sea_lantern
setblock 86 265 613 minecraft:sea_lantern
fill 48 266 605 48 267 610 minecraft:light_gray_concrete
fill 48 266 613 48 267 613 minecraft:light_gray_concrete
fill 48 266 615 48 267 615 minecraft:light_gray_concrete
fill 48 266 617 48 267 617 minecraft:light_gray_concrete
fill 48 266 619 48 267 619 minecraft:light_gray_concrete
fill 48 266 621 48 267 621 minecraft:light_gray_concrete
fill 48 266 623 48 267 623 minecraft:light_gray_concrete
fill 48 266 625 48 267 626 minecraft:light_gray_concrete
fill 48 266 629 49 266 634 minecraft:light_gray_concrete
fill 48 266 637 49 266 642 minecraft:light_gray_concrete
fill 48 266 645 53 267 645 minecraft:light_gray_concrete
fill 49 266 606 49 266 612 minecraft:light_gray_concrete
fill 49 266 614 49 267 614 minecraft:light_gray_concrete
fill 49 266 616 49 267 616 minecraft:light_gray_concrete
fill 49 266 618 49 267 618 minecraft:light_gray_concrete
fill 49 266 620 49 267 620 minecraft:light_gray_concrete
fill 49 266 622 49 267 622 minecraft:light_gray_concrete
fill 49 266 624 49 267 624 minecraft:light_gray_concrete
fill 49 266 626 49 266 628 minecraft:light_gray_concrete
fill 49 266 635 49 266 636 minecraft:light_gray_concrete
fill 49 266 643 49 266 644 minecraft:light_gray_concrete
fill 50 266 606 77 266 606 minecraft:light_gray_concrete
fill 50 266 613 50 267 613 minecraft:light_gray_concrete
fill 50 266 615 50 267 615 minecraft:light_gray_concrete
fill 50 266 617 50 267 617 minecraft:light_gray_concrete
fill 50 266 619 50 267 619 minecraft:light_gray_concrete
fill 50 266 621 50 267 621 minecraft:light_gray_concrete
fill 50 266 623 50 267 623 minecraft:light_gray_concrete
fill 50 266 625 50 267 625 minecraft:light_gray_concrete
fill 50 266 644 88 266 644 minecraft:light_gray_concrete
fill 51 266 605 56 267 605 minecraft:light_gray_concrete
fill 51 266 614 51 267 614 minecraft:light_gray_concrete
fill 51 266 616 51 267 616 minecraft:light_gray_concrete
fill 51 266 618 51 267 618 minecraft:light_gray_concrete
fill 51 266 620 51 267 620 minecraft:light_gray_concrete
fill 51 266 622 51 267 622 minecraft:light_gray_concrete
fill 51 266 624 51 267 624 minecraft:light_gray_concrete
fill 52 266 613 52 267 613 minecraft:light_gray_concrete
fill 52 266 615 52 267 615 minecraft:light_gray_concrete
fill 52 266 617 52 267 617 minecraft:light_gray_concrete
fill 52 266 619 52 267 619 minecraft:light_gray_concrete
fill 52 266 621 52 267 621 minecraft:light_gray_concrete
fill 52 266 623 52 267 623 minecraft:light_gray_concrete
fill 52 266 625 52 267 625 minecraft:light_gray_concrete
fill 53 266 614 53 267 614 minecraft:light_gray_concrete
fill 53 266 616 53 267 616 minecraft:light_gray_concrete
fill 53 266 618 53 267 618 minecraft:light_gray_concrete
fill 53 266 620 53 267 620 minecraft:light_gray_concrete
fill 53 266 622 53 267 622 minecraft:light_gray_concrete
fill 53 266 624 53 267 624 minecraft:light_gray_concrete
fill 54 266 613 54 267 613 minecraft:light_gray_concrete
fill 54 266 615 54 267 615 minecraft:light_gray_concrete
fill 54 266 617 54 267 617 minecraft:light_gray_concrete
fill 54 266 619 54 267 619 minecraft:light_gray_concrete
fill 54 266 621 54 267 621 minecraft:light_gray_concrete
fill 54 266 623 54 267 623 minecraft:light_gray_concrete
fill 54 266 625 54 267 625 minecraft:light_gray_concrete
fill 55 266 614 55 267 614 minecraft:light_gray_concrete
fill 55 266 616 55 267 616 minecraft:light_gray_concrete
fill 55 266 618 55 267 618 minecraft:light_gray_concrete
fill 55 266 620 55 267 620 minecraft:light_gray_concrete
fill 55 266 622 55 267 622 minecraft:light_gray_concrete
fill 55 266 624 55 267 624 minecraft:light_gray_concrete
fill 56 266 613 56 267 613 minecraft:light_gray_concrete
fill 56 266 615 56 267 615 minecraft:light_gray_concrete
fill 56 266 617 56 267 617 minecraft:light_gray_concrete
fill 56 266 619 56 267 619 minecraft:light_gray_concrete
fill 56 266 621 56 267 621 minecraft:light_gray_concrete
fill 56 266 623 56 267 623 minecraft:light_gray_concrete
fill 56 266 625 56 267 625 minecraft:light_gray_concrete
fill 56 266 639 56 267 639 minecraft:magenta_concrete
fill 56 266 645 61 267 645 minecraft:light_gray_concrete
fill 57 266 614 57 267 614 minecraft:light_gray_concrete
fill 57 266 616 57 267 616 minecraft:light_gray_concrete
fill 57 266 618 57 267 618 minecraft:light_gray_concrete
fill 57 266 620 57 267 620 minecraft:light_gray_concrete
fill 57 266 622 57 267 622 minecraft:light_gray_concrete
fill 57 266 624 57 267 624 minecraft:light_gray_concrete
fill 59 266 605 64 267 605 minecraft:light_gray_concrete
fill 64 266 645 69 267 645 minecraft:light_gray_concrete
fill 67 266 605 72 267 605 minecraft:light_gray_concrete
fill 72 266 645 77 267 645 minecraft:light_gray_concrete
fill 75 266 605 78 267 605 minecraft:light_gray_concrete
setblock 78 266 607 minecraft:light_gray_concrete
setblock 78 266 609 minecraft:light_gray_concrete
setblock 78 266 611 minecraft:light_gray_concrete
setblock 78 266 613 minecraft:light_gray_concrete
setblock 79 266 606 minecraft:light_gray_concrete
setblock 79 266 608 minecraft:light_gray_concrete
setblock 79 266 610 minecraft:light_gray_concrete
setblock 79 266 612 minecraft:light_gray_concrete
fill 80 266 605 80 267 605 minecraft:light_gray_concrete
setblock 80 266 607 minecraft:light_gray_concrete
setblock 80 266 609 minecraft:light_gray_concrete
setblock 80 266 611 minecraft:light_gray_concrete
setblock 80 266 613 minecraft:light_gray_concrete
fill 80 266 645 85 267 645 minecraft:light_gray_concrete
setblock 81 266 606 minecraft:light_gray_concrete
setblock 81 266 608 minecraft:light_gray_concrete
setblock 81 266 610 minecraft:light_gray_concrete
setblock 81 266 612 minecraft:light_gray_concrete
fill 82 266 605 82 273 605 minecraft:light_gray_concrete
setblock 82 266 607 minecraft:light_gray_concrete
setblock 82 266 609 minecraft:light_gray_concrete
setblock 82 266 611 minecraft:light_gray_concrete
setblock 82 266 613 minecraft:light_gray_concrete
setblock 83 266 606 minecraft:light_gray_concrete
setblock 83 266 608 minecraft:light_gray_concrete
setblock 83 266 610 minecraft:light_gray_concrete
setblock 83 266 612 minecraft:light_gray_concrete
fill 84 266 605 84 267 605 minecraft:light_gray_concrete
setblock 84 266 607 minecraft:light_gray_concrete
setblock 84 266 609 minecraft:light_gray_concrete
setblock 84 266 611 minecraft:light_gray_concrete
setblock 84 266 613 minecraft:light_gray_concrete
setblock 85 266 606 minecraft:light_gray_concrete
setblock 85 266 608 minecraft:light_gray_concrete
setblock 85 266 610 minecraft:light_gray_concrete
setblock 85 266 612 minecraft:light_gray_concrete
fill 86 266 605 88 267 605 minecraft:light_gray_concrete
fill 86 266 607 87 266 607 minecraft:light_gray_concrete
fill 86 266 609 88 266 609 minecraft:light_gray_concrete
fill 86 266 611 88 266 611 minecraft:light_gray_concrete
fill 86 266 613 88 266 613 minecraft:light_gray_concrete
setblock 87 266 606 minecraft:light_gray_concrete
fill 87 266 608 88 266 608 minecraft:light_gray_concrete
fill 87 266 610 88 266 610 minecraft:light_gray_concrete
fill 87 266 612 88 266 612 minecraft:light_gray_concrete
fill 87 266 614 87 266 643 minecraft:light_gray_concrete
fill 88 266 616 88 267 621 minecraft:light_gray_concrete
fill 88 266 624 88 267 629 minecraft:light_gray_concrete
fill 88 266 632 88 267 637 minecraft:light_gray_concrete
fill 88 266 640 88 267 643 minecraft:light_gray_concrete
fill 88 266 645 88 267 645 minecraft:light_gray_concrete
fill 48 267 629 48 267 634 minecraft:light_gray_concrete
fill 48 267 637 48 267 642 minecraft:light_gray_concrete
setblock 50 267 607 minecraft:light[level=14]
setblock 50 267 631 minecraft:light[level=14]
setblock 50 267 639 minecraft:light[level=14]
setblock 58 267 607 minecraft:light[level=14]
setblock 58 267 615 minecraft:light[level=14]
setblock 58 267 623 minecraft:light[level=14]
setblock 58 267 631 minecraft:light[level=14]
setblock 58 267 639 minecraft:light[level=14]
setblock 66 267 607 minecraft:light[level=14]
setblock 66 267 615 minecraft:light[level=14]
setblock 66 267 623 minecraft:light[level=14]
setblock 66 267 631 minecraft:light[level=14]
setblock 66 267 639 minecraft:light[level=14]
setblock 74 267 607 minecraft:light[level=14]
setblock 74 267 615 minecraft:light[level=14]
setblock 74 267 623 minecraft:light[level=14]
setblock 74 267 631 minecraft:light[level=14]
setblock 74 267 639 minecraft:light[level=14]
setblock 82 267 607 minecraft:light[level=14]
setblock 82 267 615 minecraft:light[level=14]
setblock 82 267 623 minecraft:light[level=14]
setblock 82 267 631 minecraft:light[level=14]
setblock 82 267 639 minecraft:light[level=14]
fill 88 267 608 88 267 613 minecraft:light_gray_concrete
setblock 88 267 644 minecraft:light_gray_concrete
setblock 48 268 613 minecraft:sea_lantern
setblock 48 268 615 minecraft:sea_lantern
setblock 48 268 617 minecraft:sea_lantern
setblock 48 268 619 minecraft:sea_lantern
setblock 48 268 621 minecraft:sea_lantern
setblock 48 268 623 minecraft:sea_lantern
setblock 48 268 625 minecraft:sea_lantern
setblock 49 268 614 minecraft:sea_lantern
setblock 49 268 616 minecraft:sea_lantern
setblock 49 268 618 minecraft:sea_lantern
setblock 49 268 620 minecraft:sea_lantern
setblock 49 268 622 minecraft:sea_lantern
setblock 49 268 624 minecraft:sea_lantern
setblock 50 268 613 minecraft:sea_lantern
setblock 50 268 615 minecraft:sea_lantern
setblock 50 268 617 minecraft:sea_lantern
setblock 50 268 619 minecraft:sea_lantern
setblock 50 268 621 minecraft:sea_lantern
setblock 50 268 623 minecraft:sea_lantern
setblock 50 268 625 minecraft:sea_lantern
setblock 51 268 614 minecraft:sea_lantern
setblock 51 268 616 minecraft:sea_lantern
setblock 51 268 618 minecraft:sea_lantern
setblock 51 268 620 minecraft:sea_lantern
setblock 51 268 622 minecraft:sea_lantern
setblock 51 268 624 minecraft:sea_lantern
setblock 52 268 613 minecraft:sea_lantern
setblock 52 268 615 minecraft:sea_lantern
setblock 52 268 617 minecraft:sea_lantern
setblock 52 268 619 minecraft:sea_lantern
setblock 52 268 621 minecraft:sea_lantern
setblock 52 268 623 minecraft:sea_lantern
setblock 52 268 625 minecraft:sea_lantern
setblock 53 268 614 minecraft:sea_lantern
setblock 53 268 616 minecraft:sea_lantern
setblock 53 268 618 minecraft:sea_lantern
setblock 53 268 620 minecraft:sea_lantern
setblock 53 268 622 minecraft:sea_lantern
setblock 53 268 624 minecraft:sea_lantern
setblock 54 268 613 minecraft:sea_lantern
setblock 54 268 615 minecraft:sea_lantern
setblock 54 268 617 minecraft:sea_lantern
setblock 54 268 619 minecraft:sea_lantern
setblock 54 268 621 minecraft:sea_lantern
setblock 54 268 623 minecraft:sea_lantern
setblock 54 268 625 minecraft:sea_lantern
setblock 55 268 614 minecraft:sea_lantern
setblock 55 268 616 minecraft:sea_lantern
setblock 55 268 618 minecraft:sea_lantern
setblock 55 268 620 minecraft:sea_lantern
setblock 55 268 622 minecraft:sea_lantern
setblock 55 268 624 minecraft:sea_lantern
setblock 56 268 613 minecraft:sea_lantern
setblock 56 268 615 minecraft:sea_lantern
setblock 56 268 617 minecraft:sea_lantern
setblock 56 268 619 minecraft:sea_lantern
setblock 56 268 621 minecraft:sea_lantern
setblock 56 268 623 minecraft:sea_lantern
setblock 56 268 625 minecraft:sea_lantern
setblock 57 268 614 minecraft:sea_lantern
setblock 57 268 616 minecraft:sea_lantern
setblock 57 268 618 minecraft:sea_lantern
setblock 57 268 620 minecraft:sea_lantern
setblock 57 268 622 minecraft:sea_lantern
setblock 57 268 624 minecraft:sea_lantern
fill 48 269 613 48 270 613 minecraft:light_gray_concrete
fill 48 269 615 48 270 615 minecraft:light_gray_concrete
fill 48 269 617 48 270 617 minecraft:light_gray_concrete
fill 48 269 619 48 270 619 minecraft:light_gray_concrete
fill 48 269 621 48 270 621 minecraft:light_gray_concrete
fill 48 269 623 48 270 623 minecraft:light_gray_concrete
fill 48 269 625 48 270 625 minecraft:light_gray_concrete
fill 49 269 614 49 270 614 minecraft:light_gray_concrete
fill 49 269 616 49 270 616 minecraft:light_gray_concrete
fill 49 269 618 49 270 618 minecraft:light_gray_concrete
fill 49 269 620 49 270 620 minecraft:light_gray_concrete
fill 49 269 622 49 270 622 minecraft:light_gray_concrete
fill 49 269 624 49 270 624 minecraft:light_gray_concrete
fill 50 269 613 50 270 613 minecraft:light_gray_concrete
fill 50 269 615 50 270 615 minecraft:light_gray_concrete
fill 50 269 617 50 270 617 minecraft:light_gray_concrete
fill 50 269 619 50 270 619 minecraft:light_gray_concrete
fill 50 269 621 50 270 621 minecraft:light_gray_concrete
fill 50 269 623 50 270 623 minecraft:light_gray_concrete
fill 50 269 625 50 270 625 minecraft:light_gray_concrete
fill 51 269 614 51 270 614 minecraft:light_gray_concrete
fill 51 269 616 51 270 616 minecraft:light_gray_concrete
fill 51 269 618 51 270 618 minecraft:light_gray_concrete
fill 51 269 620 51 270 620 minecraft:light_gray_concrete
fill 51 269 622 51 270 622 minecraft:light_gray_concrete
fill 51 269 624 51 270 624 minecraft:light_gray_concrete
fill 52 269 613 52 270 613 minecraft:light_gray_concrete
fill 52 269 615 52 270 615 minecraft:light_gray_concrete
fill 52 269 617 52 270 617 minecraft:light_gray_concrete
fill 52 269 619 52 270 619 minecraft:light_gray_concrete
fill 52 269 621 52 270 621 minecraft:light_gray_concrete
fill 52 269 623 52 270 623 minecraft:light_gray_concrete
fill 52 269 625 52 270 625 minecraft:light_gray_concrete
fill 53 269 614 53 270 614 minecraft:light_gray_concrete
fill 53 269 616 53 270 616 minecraft:light_gray_concrete
fill 53 269 618 53 270 618 minecraft:light_gray_concrete
fill 53 269 620 53 270 620 minecraft:light_gray_concrete
fill 53 269 622 53 270 622 minecraft:light_gray_concrete
fill 53 269 624 53 270 624 minecraft:light_gray_concrete
fill 54 269 613 54 270 613 minecraft:light_gray_concrete
fill 54 269 615 54 270 615 minecraft:light_gray_concrete
fill 54 269 617 54 270 617 minecraft:light_gray_concrete
fill 54 269 619 54 270 619 minecraft:light_gray_concrete
fill 54 269 621 54 270 621 minecraft:light_gray_concrete
fill 54 269 623 54 270 623 minecraft:light_gray_concrete
fill 54 269 625 54 270 625 minecraft:light_gray_concrete
fill 55 269 614 55 270 614 minecraft:light_gray_concrete
fill 55 269 616 55 270 616 minecraft:light_gray_concrete
fill 55 269 618 55 270 618 minecraft:light_gray_concrete
fill 55 269 620 55 270 620 minecraft:light_gray_concrete
fill 55 269 622 55 270 622 minecraft:light_gray_concrete
fill 55 269 624 55 270 624 minecraft:light_gray_concrete
fill 56 269 613 56 270 613 minecraft:light_gray_concrete
fill 56 269 615 56 270 615 minecraft:light_gray_concrete
fill 56 269 617 56 270 617 minecraft:light_gray_concrete
fill 56 269 619 56 270 619 minecraft:light_gray_concrete
fill 56 269 621 56 270 621 minecraft:light_gray_concrete
fill 56 269 623 56 270 623 minecraft:light_gray_concrete
fill 56 269 625 56 270 625 minecraft:light_gray_concrete
fill 57 269 614 57 270 614 minecraft:light_gray_concrete
fill 57 269 616 57 270 616 minecraft:light_gray_concrete
fill 57 269 618 57 270 618 minecraft:light_gray_concrete
fill 57 269 620 57 270 620 minecraft:light_gray_concrete
fill 57 269 622 57 270 622 minecraft:light_gray_concrete
fill 57 269 624 57 270 624 minecraft:light_gray_concrete
fill 47 270 609 47 273 609 minecraft:sea_lantern
fill 47 270 617 47 273 617 minecraft:sea_lantern
fill 47 270 625 47 273 625 minecraft:sea_lantern
fill 47 270 633 47 273 633 minecraft:sea_lantern
fill 47 270 641 47 273 641 minecraft:sea_lantern
fill 50 270 646 50 273 646 minecraft:sea_lantern
fill 54 270 604 54 273 604 minecraft:sea_lantern
fill 58 270 646 58 273 646 minecraft:sea_lantern
fill 62 270 604 62 273 604 minecraft:sea_lantern
fill 66 270 646 66 273 646 minecraft:sea_lantern
fill 70 270 604 70 273 604 minecraft:sea_lantern
fill 70 270 614 72 271 614 minecraft:magenta_concrete
fill 71 270 613 71 271 613 minecraft:magenta_concrete
fill 71 270 615 71 271 615 minecraft:magenta_concrete
fill 74 270 646 74 273 646 minecraft:sea_lantern
fill 78 270 604 78 273 604 minecraft:sea_lantern
fill 82 270 646 82 273 646 minecraft:sea_lantern
fill 86 270 604 86 273 604 minecraft:sea_lantern
fill 89 270 609 89 273 609 minecraft:sea_lantern
fill 89 270 617 89 273 617 minecraft:sea_lantern
fill 89 270 625 89 273 625 minecraft:sea_lantern
fill 89 270 633 89 273 633 minecraft:sea_lantern
fill 89 270 641 89 273 641 minecraft:sea_lantern
setblock 48 271 613 minecraft:sea_lantern
setblock 48 271 615 minecraft:sea_lantern
setblock 48 271 617 minecraft:sea_lantern
setblock 48 271 619 minecraft:sea_lantern
setblock 48 271 621 minecraft:sea_lantern
setblock 48 271 623 minecraft:sea_lantern
setblock 48 271 625 minecraft:sea_lantern
setblock 49 271 614 minecraft:sea_lantern
setblock 49 271 616 minecraft:sea_lantern
setblock 49 271 618 minecraft:sea_lantern
setblock 49 271 620 minecraft:sea_lantern
setblock 49 271 622 minecraft:sea_lantern
setblock 49 271 624 minecraft:sea_lantern
setblock 50 271 613 minecraft:sea_lantern
setblock 50 271 615 minecraft:sea_lantern
setblock 50 271 617 minecraft:sea_lantern
setblock 50 271 619 minecraft:sea_lantern
setblock 50 271 621 minecraft:sea_lantern
setblock 50 271 623 minecraft:sea_lantern
setblock 50 271 625 minecraft:sea_lantern
setblock 51 271 614 minecraft:sea_lantern
setblock 51 271 616 minecraft:sea_lantern
setblock 51 271 618 minecraft:sea_lantern
setblock 51 271 620 minecraft:sea_lantern
setblock 51 271 622 minecraft:sea_lantern
setblock 51 271 624 minecraft:sea_lantern
setblock 52 271 613 minecraft:sea_lantern
setblock 52 271 615 minecraft:sea_lantern
setblock 52 271 617 minecraft:sea_lantern
setblock 52 271 619 minecraft:sea_lantern
setblock 52 271 621 minecraft:sea_lantern
setblock 52 271 623 minecraft:sea_lantern
setblock 52 271 625 minecraft:sea_lantern
setblock 53 271 614 minecraft:sea_lantern
setblock 53 271 616 minecraft:sea_lantern
setblock 53 271 618 minecraft:sea_lantern
setblock 53 271 620 minecraft:sea_lantern
setblock 53 271 622 minecraft:sea_lantern
setblock 53 271 624 minecraft:sea_lantern
setblock 54 271 613 minecraft:sea_lantern
setblock 54 271 615 minecraft:sea_lantern
setblock 54 271 617 minecraft:sea_lantern
setblock 54 271 619 minecraft:sea_lantern
setblock 54 271 621 minecraft:sea_lantern
setblock 54 271 623 minecraft:sea_lantern
setblock 54 271 625 minecraft:sea_lantern
setblock 55 271 614 minecraft:sea_lantern
setblock 55 271 616 minecraft:sea_lantern
setblock 55 271 618 minecraft:sea_lantern
setblock 55 271 620 minecraft:sea_lantern
setblock 55 271 622 minecraft:sea_lantern
setblock 55 271 624 minecraft:sea_lantern
setblock 56 271 613 minecraft:sea_lantern
setblock 56 271 615 minecraft:sea_lantern
setblock 56 271 617 minecraft:sea_lantern
setblock 56 271 619 minecraft:sea_lantern
setblock 56 271 621 minecraft:sea_lantern
setblock 56 271 623 minecraft:sea_lantern
setblock 56 271 625 minecraft:sea_lantern
setblock 57 271 614 minecraft:sea_lantern
setblock 57 271 616 minecraft:sea_lantern
setblock 57 271 618 minecraft:sea_lantern
setblock 57 271 620 minecraft:sea_lantern
setblock 57 271 622 minecraft:sea_lantern
setblock 57 271 624 minecraft:sea_lantern
fill 48 272 613 48 273 613 minecraft:light_gray_concrete
fill 48 272 615 48 273 615 minecraft:light_gray_concrete
fill 48 272 617 48 273 617 minecraft:light_gray_concrete
fill 48 272 619 48 273 619 minecraft:light_gray_concrete
fill 48 272 621 48 273 621 minecraft:light_gray_concrete
fill 48 272 623 48 273 623 minecraft:light_gray_concrete
fill 48 272 625 48 273 625 minecraft:light_gray_concrete
fill 49 272 614 49 273 614 minecraft:light_gray_concrete
fill 49 272 616 49 273 616 minecraft:light_gray_concrete
fill 49 272 618 49 273 618 minecraft:light_gray_concrete
fill 49 272 620 49 273 620 minecraft:light_gray_concrete
fill 49 272 622 49 273 622 minecraft:light_gray_concrete
fill 49 272 624 49 273 624 minecraft:light_gray_concrete
fill 50 272 613 50 273 613 minecraft:light_gray_concrete
fill 50 272 615 50 273 615 minecraft:light_gray_concrete
fill 50 272 617 50 273 617 minecraft:light_gray_concrete
fill 50 272 619 50 273 619 minecraft:light_gray_concrete
fill 50 272 621 50 273 621 minecraft:light_gray_concrete
fill 50 272 623 50 273 623 minecraft:light_gray_concrete
fill 50 272 625 50 273 625 minecraft:light_gray_concrete
fill 51 272 614 51 273 614 minecraft:light_gray_concrete
fill 51 272 616 51 273 616 minecraft:light_gray_concrete
fill 51 272 618 51 273 618 minecraft:light_gray_concrete
fill 51 272 620 51 273 620 minecraft:light_gray_concrete
fill 51 272 622 51 273 622 minecraft:light_gray_concrete
fill 51 272 624 51 273 624 minecraft:light_gray_concrete
fill 52 272 613 52 273 613 minecraft:light_gray_concrete
fill 52 272 615 52 273 615 minecraft:light_gray_concrete
fill 52 272 617 52 273 617 minecraft:light_gray_concrete
fill 52 272 619 52 273 619 minecraft:light_gray_concrete
fill 52 272 621 52 273 621 minecraft:light_gray_concrete
fill 52 272 623 52 273 623 minecraft:light_gray_concrete
fill 52 272 625 52 273 625 minecraft:light_gray_concrete
fill 53 272 614 53 273 614 minecraft:light_gray_concrete
fill 53 272 616 53 273 616 minecraft:light_gray_concrete
fill 53 272 618 53 273 618 minecraft:light_gray_concrete
fill 53 272 620 53 273 620 minecraft:light_gray_concrete
fill 53 272 622 53 273 622 minecraft:light_gray_concrete
fill 53 272 624 53 273 624 minecraft:light_gray_concrete
fill 54 272 613 54 273 613 minecraft:light_gray_concrete
fill 54 272 615 54 273 615 minecraft:light_gray_concrete
fill 54 272 617 54 273 617 minecraft:light_gray_concrete
fill 54 272 619 54 273 619 minecraft:light_gray_concrete
fill 54 272 621 54 273 621 minecraft:light_gray_concrete
fill 54 272 623 54 273 623 minecraft:light_gray_concrete
fill 54 272 625 54 273 625 minecraft:light_gray_concrete
fill 55 272 614 55 273 614 minecraft:light_gray_concrete
fill 55 272 616 55 273 616 minecraft:light_gray_concrete
fill 55 272 618 55 273 618 minecraft:light_gray_concrete
fill 55 272 620 55 273 620 minecraft:light_gray_concrete
fill 55 272 622 55 273 622 minecraft:light_gray_concrete
fill 55 272 624 55 273 624 minecraft:light_gray_concrete
fill 56 272 613 56 273 613 minecraft:light_gray_concrete
fill 56 272 615 56 273 615 minecraft:light_gray_concrete
fill 56 272 617 56 273 617 minecraft:light_gray_concrete
fill 56 272 619 56 273 619 minecraft:light_gray_concrete
fill 56 272 621 56 273 621 minecraft:light_gray_concrete
fill 56 272 623 56 273 623 minecraft:light_gray_concrete
fill 56 272 625 56 273 625 minecraft:light_gray_concrete
fill 57 272 614 57 273 614 minecraft:light_gray_concrete
fill 57 272 616 57 273 616 minecraft:light_gray_concrete
fill 57 272 618 57 273 618 minecraft:light_gray_concrete
fill 57 272 620 57 273 620 minecraft:light_gray_concrete
fill 57 272 622 57 273 622 minecraft:light_gray_concrete
fill 57 272 624 57 273 624 minecraft:light_gray_concrete
fill 47 274 609 47 283 609 minecraft:gray_concrete
fill 47 274 617 47 283 617 minecraft:gray_concrete
fill 47 274 625 47 283 625 minecraft:gray_concrete
fill 47 274 633 47 283 633 minecraft:gray_concrete
fill 47 274 641 47 283 641 minecraft:gray_concrete
fill 50 274 646 50 283 646 minecraft:gray_concrete
fill 54 274 604 54 283 604 minecraft:gray_concrete
fill 58 274 646 58 283 646 minecraft:gray_concrete
fill 62 274 604 62 283 604 minecraft:gray_concrete
fill 66 274 646 66 283 646 minecraft:gray_concrete
fill 70 274 604 70 283 604 minecraft:gray_concrete
fill 74 274 646 74 283 646 minecraft:gray_concrete
fill 78 274 604 78 283 604 minecraft:gray_concrete
fill 82 274 646 82 283 646 minecraft:gray_concrete
fill 86 274 604 86 283 604 minecraft:gray_concrete
fill 89 274 609 89 283 609 minecraft:gray_concrete
fill 89 274 617 89 283 617 minecraft:gray_concrete
fill 89 274 625 89 283 625 minecraft:gray_concrete
fill 89 274 633 89 283 633 minecraft:gray_concrete
fill 89 274 641 89 283 641 minecraft:gray_concrete
setblock 50 275 607 minecraft:light[level=14]
setblock 50 275 615 minecraft:light[level=14]
setblock 50 275 623 minecraft:light[level=14]
setblock 50 275 631 minecraft:light[level=14]
setblock 50 275 639 minecraft:light[level=14]
setblock 58 275 607 minecraft:light[level=14]
setblock 58 275 615 minecraft:light[level=14]
setblock 58 275 623 minecraft:light[level=14]
setblock 58 275 631 minecraft:light[level=14]
setblock 58 275 639 minecraft:light[level=14]
setblock 66 275 607 minecraft:light[level=14]
setblock 66 275 615 minecraft:light[level=14]
setblock 66 275 623 minecraft:light[level=14]
setblock 66 275 631 minecraft:light[level=14]
setblock 66 275 639 minecraft:light[level=14]
setblock 74 275 607 minecraft:light[level=14]
setblock 74 275 615 minecraft:light[level=14]
setblock 74 275 623 minecraft:light[level=14]
setblock 74 275 631 minecraft:light[level=14]
setblock 74 275 639 minecraft:light[level=14]
setblock 82 275 607 minecraft:light[level=14]
setblock 82 275 615 minecraft:light[level=14]
setblock 82 275 623 minecraft:light[level=14]
setblock 82 275 631 minecraft:light[level=14]
setblock 82 275 639 minecraft:light[level=14]
fill 66 278 626 68 278 628 minecraft:redstone_block
fill 69 278 617 71 278 619 minecraft:redstone_block
fill 73 278 625 75 278 627 minecraft:redstone_block
fill 48 279 605 48 280 615 minecraft:light_blue_concrete
fill 48 279 616 52 280 617 minecraft:white_concrete
fill 48 279 618 48 280 627 minecraft:light_blue_concrete
fill 48 279 628 52 280 629 minecraft:white_concrete
fill 48 279 630 48 280 640 minecraft:light_blue_concrete
fill 48 279 641 52 280 642 minecraft:white_concrete
fill 48 279 643 48 280 645 minecraft:light_blue_concrete
fill 49 279 605 52 280 605 minecraft:white_concrete
fill 49 279 606 49 280 614 minecraft:light_blue_concrete
fill 49 279 615 52 280 615 minecraft:white_concrete
fill 49 279 618 49 280 626 minecraft:light_blue_concrete
fill 49 279 627 52 280 627 minecraft:white_concrete
fill 49 279 630 52 280 630 minecraft:white_concrete
fill 49 279 631 55 280 639 minecraft:light_blue_concrete
fill 49 279 640 52 280 640 minecraft:white_concrete
fill 49 279 643 52 280 643 minecraft:white_concrete
fill 49 279 644 88 280 645 minecraft:light_blue_concrete
fill 50 279 606 55 280 613 minecraft:light_blue_concrete
fill 50 279 614 50 280 614 minecraft:white_concrete
fill 50 279 618 51 280 618 minecraft:white_concrete
fill 50 279 619 55 280 626 minecraft:light_blue_concrete
fill 51 279 614 65 280 614 minecraft:light_blue_concrete
fill 52 279 618 64 280 618 minecraft:light_blue_concrete
fill 53 279 605 64 280 605 minecraft:light_blue_concrete
fill 53 279 615 63 280 615 minecraft:light_blue_concrete
fill 53 279 616 53 280 616 minecraft:white_concrete
fill 53 279 617 63 280 617 minecraft:light_blue_concrete
fill 53 279 627 63 280 628 minecraft:light_blue_concrete
fill 53 279 629 53 280 629 minecraft:white_concrete
fill 53 279 630 63 280 630 minecraft:light_blue_concrete
fill 53 279 640 63 280 640 minecraft:light_blue_concrete
fill 53 279 641 53 280 641 minecraft:white_concrete
fill 53 279 642 63 280 643 minecraft:light_blue_concrete
fill 54 279 616 63 280 616 minecraft:light_blue_concrete
fill 54 279 629 63 280 629 minecraft:light_blue_concrete
fill 54 279 641 63 280 641 minecraft:light_blue_concrete
fill 56 279 606 56 280 608 minecraft:light_blue_concrete
fill 56 279 609 60 280 611 minecraft:white_concrete
fill 56 279 612 88 280 613 minecraft:light_blue_concrete
fill 56 279 619 56 280 621 minecraft:light_blue_concrete
fill 56 279 622 60 280 623 minecraft:white_concrete
fill 56 279 624 56 280 626 minecraft:light_blue_concrete
fill 56 279 631 56 280 633 minecraft:light_blue_concrete
fill 56 279 634 60 280 636 minecraft:white_concrete
fill 56 279 637 57 280 639 minecraft:light_blue_concrete
fill 57 279 606 88 280 607 minecraft:light_blue_concrete
fill 57 279 608 59 280 608 minecraft:white_concrete
fill 57 279 619 68 279 620 minecraft:light_blue_concrete
fill 57 279 621 60 280 621 minecraft:white_concrete
fill 57 279 624 60 280 624 minecraft:white_concrete
fill 57 279 625 65 279 626 minecraft:light_blue_concrete
fill 57 279 631 88 280 632 minecraft:light_blue_concrete
fill 57 279 633 59 280 633 minecraft:white_concrete
fill 58 279 637 58 280 637 minecraft:white_concrete
fill 58 279 638 88 280 639 minecraft:light_blue_concrete
fill 59 279 637 73 280 637 minecraft:light_blue_concrete
fill 60 279 608 72 280 608 minecraft:light_blue_concrete
fill 60 279 633 72 280 633 minecraft:light_blue_concrete
fill 61 279 609 71 280 611 minecraft:light_blue_concrete
fill 61 279 621 68 279 624 minecraft:light_blue_concrete
fill 61 279 634 71 280 636 minecraft:light_blue_concrete
fill 64 279 615 68 279 617 minecraft:white_concrete
fill 64 279 627 64 280 627 minecraft:light_blue_concrete
fill 64 279 628 65 279 630 minecraft:white_concrete
fill 64 279 640 68 280 642 minecraft:white_concrete
fill 64 279 643 64 280 643 minecraft:light_blue_concrete
fill 65 279 605 68 280 605 minecraft:white_concrete
fill 65 279 618 67 280 618 minecraft:white_concrete
setblock 65 279 627 minecraft:white_concrete
fill 65 279 643 67 280 643 minecraft:white_concrete
fill 66 279 614 66 280 614 minecraft:white_concrete
fill 66 279 625 72 279 625 minecraft:light_blue_concrete
fill 66 279 629 68 279 630 minecraft:white_concrete
fill 67 279 614 81 280 614 minecraft:light_blue_concrete
setblock 68 279 618 minecraft:light_blue_concrete
fill 68 279 643 80 280 643 minecraft:light_blue_concrete
fill 69 279 605 79 280 605 minecraft:light_blue_concrete
fill 69 279 615 79 279 616 minecraft:light_blue_concrete
fill 69 279 620 71 279 621 minecraft:light_blue_concrete
fill 69 279 626 72 279 630 minecraft:light_blue_concrete
fill 69 279 640 79 280 642 minecraft:light_blue_concrete
fill 72 279 609 76 280 611 minecraft:white_concrete
fill 72 279 617 79 279 620 minecraft:light_blue_concrete
fill 72 279 621 76 279 623 minecraft:white_concrete
setblock 72 279 624 minecraft:light_blue_concrete
fill 72 279 634 76 280 636 minecraft:white_concrete
fill 73 279 608 75 280 608 minecraft:white_concrete
fill 73 279 624 75 279 624 minecraft:white_concrete
fill 73 279 628 79 279 630 minecraft:light_blue_concrete
fill 73 279 633 75 280 633 minecraft:white_concrete
fill 74 279 637 74 280 637 minecraft:white_concrete
fill 75 279 637 88 280 637 minecraft:light_blue_concrete
fill 76 279 608 88 280 608 minecraft:light_blue_concrete
fill 76 279 624 79 279 627 minecraft:light_blue_concrete
fill 76 279 633 88 280 633 minecraft:light_blue_concrete
fill 77 279 609 87 280 611 minecraft:light_blue_concrete
fill 77 279 621 87 280 623 minecraft:light_blue_concrete
fill 77 279 634 87 280 636 minecraft:light_blue_concrete
fill 80 279 605 83 280 605 minecraft:white_concrete
fill 80 279 615 84 280 617 minecraft:white_concrete
fill 80 279 618 80 280 620 minecraft:light_blue_concrete
fill 80 279 624 87 280 626 minecraft:light_blue_concrete
fill 80 279 627 83 280 630 minecraft:white_concrete
fill 80 279 640 84 280 642 minecraft:white_concrete
fill 81 279 618 83 280 618 minecraft:white_concrete
fill 81 279 619 88 280 620 minecraft:light_blue_concrete
fill 81 279 643 83 280 643 minecraft:white_concrete
fill 82 279 614 82 280 614 minecraft:white_concrete
fill 83 279 614 88 280 614 minecraft:light_blue_concrete
fill 84 279 605 88 280 605 minecraft:light_blue_concrete
fill 84 279 618 88 280 618 minecraft:light_blue_concrete
fill 84 279 627 88 280 627 minecraft:light_blue_concrete
fill 84 279 628 84 280 630 minecraft:white_concrete
fill 84 279 643 88 280 643 minecraft:light_blue_concrete
fill 85 279 615 88 280 617 minecraft:light_blue_concrete
fill 85 279 628 88 280 630 minecraft:light_blue_concrete
fill 85 279 640 88 280 642 minecraft:light_blue_concrete
fill 88 279 609 88 280 611 minecraft:white_concrete
fill 88 279 621 88 280 624 minecraft:white_concrete
fill 88 279 625 88 280 626 minecraft:light_blue_concrete
fill 88 279 634 88 280 636 minecraft:white_concrete
fill 57 280 619 67 280 620 minecraft:light_blue_concrete
fill 57 280 625 64 280 626 minecraft:light_blue_concrete
fill 61 280 621 67 280 624 minecraft:light_blue_concrete
fill 64 280 615 67 280 617 minecraft:white_concrete
fill 64 280 628 64 280 630 minecraft:white_concrete
fill 65 280 625 65 280 629 minecraft:sea_lantern
fill 65 280 630 68 280 630 minecraft:white_concrete
fill 66 280 625 72 280 625 minecraft:sea_lantern
fill 66 280 626 68 280 628 minecraft:light_blue_concrete
fill 66 280 629 69 280 629 minecraft:sea_lantern
setblock 68 280 615 minecraft:white_concrete
fill 68 280 616 68 280 624 minecraft:sea_lantern
fill 69 280 615 79 280 615 minecraft:light_blue_concrete
fill 69 280 616 72 280 616 minecraft:sea_lantern
fill 69 280 617 71 280 619 minecraft:light_blue_concrete
fill 69 280 620 72 280 621 minecraft:sea_lantern
fill 69 280 626 69 280 628 minecraft:sea_lantern
fill 69 280 630 79 280 630 minecraft:light_blue_concrete
fill 70 280 626 71 280 629 minecraft:light_blue_concrete
fill 72 280 617 72 280 619 minecraft:sea_lantern
fill 72 280 622 72 280 624 minecraft:sea_lantern
fill 72 280 626 72 280 628 minecraft:sea_lantern
fill 72 280 629 79 280 629 minecraft:light_blue_concrete
fill 73 280 616 79 280 620 minecraft:light_blue_concrete
fill 73 280 621 76 280 623 minecraft:white_concrete
fill 73 280 624 76 280 624 minecraft:sea_lantern
fill 73 280 625 75 280 627 minecraft:light_blue_concrete
fill 73 280 628 76 280 628 minecraft:sea_lantern
fill 76 280 625 76 280 627 minecraft:sea_lantern
fill 77 280 624 79 280 628 minecraft:light_blue_concrete
setblock 50 283 607 minecraft:light[level=14]
setblock 50 283 615 minecraft:light[level=14]
setblock 50 283 623 minecraft:light[level=14]
setblock 50 283 631 minecraft:light[level=14]
setblock 50 283 639 minecraft:light[level=14]
setblock 58 283 607 minecraft:light[level=14]
setblock 58 283 615 minecraft:light[level=14]
setblock 58 283 623 minecraft:light[level=14]
setblock 58 283 631 minecraft:light[level=14]
setblock 58 283 639 minecraft:light[level=14]
setblock 66 283 607 minecraft:light[level=14]
setblock 66 283 615 minecraft:light[level=14]
setblock 66 283 623 minecraft:light[level=14]
setblock 66 283 631 minecraft:light[level=14]
setblock 66 283 639 minecraft:light[level=14]
setblock 74 283 607 minecraft:light[level=14]
setblock 74 283 615 minecraft:light[level=14]
setblock 74 283 623 minecraft:light[level=14]
setblock 74 283 631 minecraft:light[level=14]
setblock 74 283 639 minecraft:light[level=14]
setblock 82 283 607 minecraft:light[level=14]
setblock 82 283 615 minecraft:light[level=14]
setblock 82 283 623 minecraft:light[level=14]
setblock 82 283 631 minecraft:light[level=14]
setblock 82 283 639 minecraft:light[level=14]
fill 47 284 609 47 289 609 minecraft:sea_lantern
fill 47 284 617 47 289 617 minecraft:sea_lantern
fill 47 284 625 47 289 625 minecraft:sea_lantern
fill 47 284 633 47 289 633 minecraft:sea_lantern
fill 47 284 641 47 289 641 minecraft:sea_lantern
fill 48 284 611 48 300 612 minecraft:light_gray_concrete
fill 48 284 619 48 300 620 minecraft:light_gray_concrete
fill 48 284 627 48 300 628 minecraft:light_gray_concrete
fill 48 284 635 48 300 636 minecraft:light_gray_concrete
fill 48 284 643 48 300 644 minecraft:light_gray_concrete
fill 49 284 605 50 300 605 minecraft:light_gray_concrete
fill 50 284 646 50 289 646 minecraft:sea_lantern
fill 54 284 604 54 289 604 minecraft:sea_lantern
fill 54 284 605 66 285 610 minecraft:light_gray_concrete
fill 54 284 645 55 300 645 minecraft:light_gray_concrete
fill 58 284 646 58 289 646 minecraft:sea_lantern
fill 62 284 604 62 289 604 minecraft:sea_lantern
fill 62 284 640 62 288 641 minecraft:magenta_concrete
fill 62 284 645 63 291 645 minecraft:light_gray_concrete
fill 65 284 638 66 284 639 minecraft:gray_concrete
fill 66 284 646 66 289 646 minecraft:sea_lantern
fill 70 284 604 70 289 604 minecraft:sea_lantern
fill 70 284 645 71 300 645 minecraft:light_gray_concrete
fill 73 284 605 74 300 605 minecraft:light_gray_concrete
fill 74 284 646 74 289 646 minecraft:sea_lantern
fill 77 284 638 85 285 645 minecraft:light_gray_concrete
fill 78 284 604 78 289 604 minecraft:sea_lantern
fill 79 284 607 88 285 615 minecraft:light_gray_concrete
fill 81 284 605 82 300 605 minecraft:light_gray_concrete
fill 82 284 646 82 289 646 minecraft:sea_lantern
fill 86 284 604 86 289 604 minecraft:sea_lantern
fill 86 284 645 87 300 645 minecraft:light_gray_concrete
fill 88 284 606 88 300 606 minecraft:light_gray_concrete
fill 88 284 622 88 300 623 minecraft:light_gray_concrete
fill 88 284 630 88 300 631 minecraft:light_gray_concrete
fill 88 284 638 88 300 639 minecraft:light_gray_concrete
fill 89 284 609 89 289 609 minecraft:sea_lantern
fill 89 284 617 89 289 617 minecraft:sea_lantern
fill 89 284 625 89 289 625 minecraft:sea_lantern
fill 89 284 633 89 289 633 minecraft:sea_lantern
fill 89 284 641 89 289 641 minecraft:sea_lantern
fill 61 285 640 61 288 641 minecraft:magenta_concrete
fill 62 285 642 62 288 642 minecraft:magenta_concrete
fill 63 285 640 63 288 641 minecraft:magenta_concrete
setblock 54 286 605 minecraft:sea_lantern
fill 54 286 606 54 300 606 minecraft:light_gray_concrete
setblock 54 286 607 minecraft:sea_lantern
fill 54 286 608 54 300 608 minecraft:light_gray_concrete
setblock 54 286 609 minecraft:sea_lantern
fill 54 286 610 54 300 610 minecraft:light_gray_concrete
fill 55 286 605 55 300 605 minecraft:light_gray_concrete
setblock 55 286 606 minecraft:sea_lantern
fill 55 286 607 55 300 607 minecraft:light_gray_concrete
setblock 55 286 608 minecraft:sea_lantern
fill 55 286 609 55 300 609 minecraft:light_gray_concrete
setblock 55 286 610 minecraft:sea_lantern
setblock 56 286 605 minecraft:sea_lantern
fill 56 286 606 56 300 606 minecraft:light_gray_concrete
setblock 56 286 607 minecraft:sea_lantern
fill 56 286 608 56 300 608 minecraft:light_gray_concrete
setblock 56 286 609 minecraft:sea_lantern
fill 56 286 610 56 300 610 minecraft:light_gray_concrete
fill 57 286 605 57 300 605 minecraft:light_gray_concrete
setblock 57 286 606 minecraft:sea_lantern
fill 57 286 607 57 300 607 minecraft:light_gray_concrete
setblock 57 286 608 minecraft:sea_lantern
fill 57 286 609 57 300 609 minecraft:light_gray_concrete
setblock 57 286 610 minecraft:sea_lantern
setblock 58 286 605 minecraft:sea_lantern
fill 58 286 606 58 300 606 minecraft:light_gray_concrete
setblock 58 286 607 minecraft:sea_lantern
fill 58 286 608 58 300 608 minecraft:light_gray_concrete
setblock 58 286 609 minecraft:sea_lantern
fill 58 286 610 58 300 610 minecraft:light_gray_concrete
fill 59 286 605 59 300 605 minecraft:light_gray_concrete
setblock 59 286 606 minecraft:sea_lantern
fill 59 286 607 59 300 607 minecraft:light_gray_concrete
setblock 59 286 608 minecraft:sea_lantern
fill 59 286 609 59 300 609 minecraft:light_gray_concrete
setblock 59 286 610 minecraft:sea_lantern
setblock 60 286 605 minecraft:sea_lantern
fill 60 286 606 60 300 606 minecraft:light_gray_concrete
setblock 60 286 607 minecraft:sea_lantern
fill 60 286 608 60 300 608 minecraft:light_gray_concrete
setblock 60 286 609 minecraft:sea_lantern
fill 60 286 610 60 300 610 minecraft:light_gray_concrete
fill 60 286 641 60 288 641 minecraft:magenta_concrete
fill 61 286 605 61 300 605 minecraft:light_gray_concrete
setblock 61 286 606 minecraft:sea_lantern
fill 61 286 607 61 300 607 minecraft:light_gray_concrete
setblock 61 286 608 minecraft:sea_lantern
fill 61 286 609 61 300 609 minecraft:light_gray_concrete
setblock 61 286 610 minecraft:sea_lantern
fill 61 286 639 63 288 639 minecraft:magenta_concrete
fill 61 286 642 61 288 642 minecraft:magenta_concrete
setblock 62 286 605 minecraft:sea_lantern
fill 62 286 606 62 300 606 minecraft:light_gray_concrete
setblock 62 286 607 minecraft:sea_lantern
fill 62 286 608 62 300 608 minecraft:light_gray_concrete
setblock 62 286 609 minecraft:sea_lantern
fill 62 286 610 62 300 610 minecraft:light_gray_concrete
fill 63 286 605 63 300 605 minecraft:light_gray_concrete
setblock 63 286 606 minecraft:sea_lantern
fill 63 286 607 63 300 607 minecraft:light_gray_concrete
setblock 63 286 608 minecraft:sea_lantern
fill 63 286 609 63 300 609 minecraft:light_gray_concrete
setblock 63 286 610 minecraft:sea_lantern
fill 63 286 642 63 288 642 minecraft:magenta_concrete
setblock 64 286 605 minecraft:sea_lantern
fill 64 286 606 64 300 606 minecraft:light_gray_concrete
setblock 64 286 607 minecraft:sea_lantern
fill 64 286 608 64 300 608 minecraft:light_gray_concrete
setblock 64 286 609 minecraft:sea_lantern
fill 64 286 610 64 300 610 minecraft:light_gray_concrete
fill 64 286 641 64 288 641 minecraft:magenta_concrete
fill 65 286 605 65 300 605 minecraft:light_gray_concrete
setblock 65 286 606 minecraft:sea_lantern
fill 65 286 607 65 300 607 minecraft:light_gray_concrete
setblock 65 286 608 minecraft:sea_lantern
fill 65 286 609 65 300 609 minecraft:light_gray_concrete
setblock 65 286 610 minecraft:sea_lantern
setblock 66 286 605 minecraft:sea_lantern
fill 66 286 606 66 300 606 minecraft:light_gray_concrete
setblock 66 286 607 minecraft:sea_lantern
fill 66 286 608 66 300 608 minecraft:light_gray_concrete
setblock 66 286 609 minecraft:sea_lantern
fill 66 286 610 66 300 610 minecraft:light_gray_concrete
setblock 77 286 638 minecraft:sea_lantern
fill 77 286 639 77 300 639 minecraft:light_gray_concrete
setblock 77 286 640 minecraft:sea_lantern
fill 77 286 641 77 300 641 minecraft:light_gray_concrete
setblock 77 286 642 minecraft:sea_lantern
fill 77 286 643 77 300 643 minecraft:light_gray_concrete
setblock 77 286 644 minecraft:sea_lantern
fill 77 286 645 77 300 645 minecraft:light_gray_concrete
fill 78 286 638 78 300 638 minecraft:light_gray_concrete
setblock 78 286 639 minecraft:sea_lantern
fill 78 286 640 78 300 640 minecraft:light_gray_concrete
setblock 78 286 641 minecraft:sea_lantern
fill 78 286 642 78 300 642 minecraft:light_gray_concrete
setblock 78 286 643 minecraft:sea_lantern
fill 78 286 644 78 300 644 minecraft:light_gray_concrete
setblock 78 286 645 minecraft:sea_lantern
fill 79 286 607 79 295 607 minecraft:light_gray_concrete
setblock 79 286 608 minecraft:sea_lantern
fill 79 286 609 79 295 609 minecraft:light_gray_concrete
setblock 79 286 610 minecraft:sea_lantern
fill 79 286 611 79 295 611 minecraft:light_gray_concrete
setblock 79 286 612 minecraft:sea_lantern
fill 79 286 613 79 295 613 minecraft:light_gray_concrete
setblock 79 286 614 minecraft:sea_lantern
fill 79 286 615 79 295 615 minecraft:light_gray_concrete
setblock 79 286 638 minecraft:sea_lantern
fill 79 286 639 79 300 639 minecraft:light_gray_concrete
setblock 79 286 640 minecraft:sea_lantern
fill 79 286 641 79 300 641 minecraft:light_gray_concrete
setblock 79 286 642 minecraft:sea_lantern
fill 79 286 643 79 300 643 minecraft:light_gray_concrete
setblock 79 286 644 minecraft:sea_lantern
fill 79 286 645 79 300 645 minecraft:light_gray_concrete
setblock 80 286 607 minecraft:sea_lantern
fill 80 286 608 80 295 608 minecraft:light_gray_concrete
setblock 80 286 609 minecraft:sea_lantern
fill 80 286 610 80 295 610 minecraft:light_gray_concrete
setblock 80 286 611 minecraft:sea_lantern
fill 80 286 612 80 295 612 minecraft:light_gray_concrete
setblock 80 286 613 minecraft:sea_lantern
fill 80 286 614 80 295 614 minecraft:light_gray_concrete
setblock 80 286 615 minecraft:sea_lantern
fill 80 286 638 80 300 638 minecraft:light_gray_concrete
setblock 80 286 639 minecraft:sea_lantern
fill 80 286 640 80 300 640 minecraft:light_gray_concrete
setblock 80 286 641 minecraft:sea_lantern
fill 80 286 642 80 300 642 minecraft:light_gray_concrete
setblock 80 286 643 minecraft:sea_lantern
fill 80 286 644 80 300 644 minecraft:light_gray_concrete
setblock 80 286 645 minecraft:sea_lantern
fill 81 286 607 81 295 607 minecraft:light_gray_concrete
setblock 81 286 608 minecraft:sea_lantern
fill 81 286 609 81 295 609 minecraft:light_gray_concrete
setblock 81 286 610 minecraft:sea_lantern
fill 81 286 611 81 295 611 minecraft:light_gray_concrete
setblock 81 286 612 minecraft:sea_lantern
fill 81 286 613 81 295 613 minecraft:light_gray_concrete
setblock 81 286 614 minecraft:sea_lantern
fill 81 286 615 81 295 615 minecraft:light_gray_concrete
setblock 81 286 638 minecraft:sea_lantern
fill 81 286 639 81 300 639 minecraft:light_gray_concrete
setblock 81 286 640 minecraft:sea_lantern
fill 81 286 641 81 300 641 minecraft:light_gray_concrete
setblock 81 286 642 minecraft:sea_lantern
fill 81 286 643 81 300 643 minecraft:light_gray_concrete
setblock 81 286 644 minecraft:sea_lantern
fill 81 286 645 81 300 645 minecraft:light_gray_concrete
setblock 82 286 607 minecraft:sea_lantern
fill 82 286 608 82 295 608 minecraft:light_gray_concrete
setblock 82 286 609 minecraft:sea_lantern
fill 82 286 610 82 295 610 minecraft:light_gray_concrete
setblock 82 286 611 minecraft:sea_lantern
fill 82 286 612 82 295 612 minecraft:light_gray_concrete
setblock 82 286 613 minecraft:sea_lantern
fill 82 286 614 82 295 614 minecraft:light_gray_concrete
setblock 82 286 615 minecraft:sea_lantern
fill 82 286 638 82 300 638 minecraft:light_gray_concrete
setblock 82 286 639 minecraft:sea_lantern
fill 82 286 640 82 300 640 minecraft:light_gray_concrete
setblock 82 286 641 minecraft:sea_lantern
fill 82 286 642 82 300 642 minecraft:light_gray_concrete
setblock 82 286 643 minecraft:sea_lantern
fill 82 286 644 82 300 644 minecraft:light_gray_concrete
setblock 82 286 645 minecraft:sea_lantern
fill 83 286 607 83 295 607 minecraft:light_gray_concrete
setblock 83 286 608 minecraft:sea_lantern
fill 83 286 609 83 295 609 minecraft:light_gray_concrete
setblock 83 286 610 minecraft:sea_lantern
fill 83 286 611 83 295 611 minecraft:light_gray_concrete
setblock 83 286 612 minecraft:sea_lantern
fill 83 286 613 83 295 613 minecraft:light_gray_concrete
setblock 83 286 614 minecraft:sea_lantern
fill 83 286 615 83 295 615 minecraft:light_gray_concrete
setblock 83 286 638 minecraft:sea_lantern
fill 83 286 639 83 300 639 minecraft:light_gray_concrete
setblock 83 286 640 minecraft:sea_lantern
fill 83 286 641 83 300 641 minecraft:light_gray_concrete
setblock 83 286 642 minecraft:sea_lantern
fill 83 286 643 83 300 643 minecraft:light_gray_concrete
setblock 83 286 644 minecraft:sea_lantern
fill 83 286 645 83 300 645 minecraft:light_gray_concrete
setblock 84 286 607 minecraft:sea_lantern
fill 84 286 608 84 295 608 minecraft:light_gray_concrete
setblock 84 286 609 minecraft:sea_lantern
fill 84 286 610 84 295 610 minecraft:light_gray_concrete
setblock 84 286 611 minecraft:sea_lantern
fill 84 286 612 84 295 612 minecraft:light_gray_concrete
setblock 84 286 613 minecraft:sea_lantern
fill 84 286 614 84 295 614 minecraft:light_gray_concrete
setblock 84 286 615 minecraft:sea_lantern
fill 84 286 638 84 300 638 minecraft:light_gray_concrete
setblock 84 286 639 minecraft:sea_lantern
fill 84 286 640 84 300 640 minecraft:light_gray_concrete
setblock 84 286 641 minecraft:sea_lantern
fill 84 286 642 84 300 642 minecraft:light_gray_concrete
setblock 84 286 643 minecraft:sea_lantern
fill 84 286 644 84 300 644 minecraft:light_gray_concrete
setblock 84 286 645 minecraft:sea_lantern
fill 85 286 607 85 295 607 minecraft:light_gray_concrete
setblock 85 286 608 minecraft:sea_lantern
fill 85 286 609 85 295 609 minecraft:light_gray_concrete
setblock 85 286 610 minecraft:sea_lantern
fill 85 286 611 85 295 611 minecraft:light_gray_concrete
setblock 85 286 612 minecraft:sea_lantern
fill 85 286 613 85 295 613 minecraft:light_gray_concrete
setblock 85 286 614 minecraft:sea_lantern
fill 85 286 615 85 295 615 minecraft:light_gray_concrete
setblock 85 286 638 minecraft:sea_lantern
fill 85 286 639 85 300 639 minecraft:light_gray_concrete
setblock 85 286 640 minecraft:sea_lantern
fill 85 286 641 85 300 641 minecraft:light_gray_concrete
setblock 85 286 642 minecraft:sea_lantern
fill 85 286 643 85 300 643 minecraft:light_gray_concrete
setblock 85 286 644 minecraft:sea_lantern
fill 85 286 645 85 300 645 minecraft:light_gray_concrete
setblock 86 286 607 minecraft:sea_lantern
fill 86 286 608 86 295 608 minecraft:light_gray_concrete
setblock 86 286 609 minecraft:sea_lantern
fill 86 286 610 86 295 610 minecraft:light_gray_concrete
setblock 86 286 611 minecraft:sea_lantern
fill 86 286 612 86 295 612 minecraft:light_gray_concrete
setblock 86 286 613 minecraft:sea_lantern
fill 86 286 614 86 295 614 minecraft:light_gray_concrete
setblock 86 286 615 minecraft:sea_lantern
fill 87 286 607 87 295 607 minecraft:light_gray_concrete
setblock 87 286 608 minecraft:sea_lantern
fill 87 286 609 87 295 609 minecraft:light_gray_concrete
setblock 87 286 610 minecraft:sea_lantern
fill 87 286 611 87 295 611 minecraft:light_gray_concrete
setblock 87 286 612 minecraft:sea_lantern
fill 87 286 613 87 295 613 minecraft:light_gray_concrete
setblock 87 286 614 minecraft:sea_lantern
fill 87 286 615 87 295 615 minecraft:light_gray_concrete
setblock 88 286 607 minecraft:sea_lantern
fill 88 286 608 88 295 608 minecraft:light_gray_concrete
setblock 88 286 609 minecraft:sea_lantern
fill 88 286 610 88 295 610 minecraft:light_gray_concrete
setblock 88 286 611 minecraft:sea_lantern
fill 88 286 612 88 295 612 minecraft:light_gray_concrete
setblock 88 286 613 minecraft:sea_lantern
fill 88 286 614 88 300 614 minecraft:light_gray_concrete
setblock 88 286 615 minecraft:sea_lantern
fill 54 287 605 54 288 605 minecraft:light_gray_concrete
fill 54 287 607 54 288 607 minecraft:light_gray_concrete
fill 54 287 609 54 288 609 minecraft:light_gray_concrete
fill 55 287 606 55 288 606 minecraft:light_gray_concrete
fill 55 287 608 55 288 608 minecraft:light_gray_concrete
fill 55 287 610 55 288 610 minecraft:light_gray_concrete
fill 56 287 605 56 288 605 minecraft:light_gray_concrete
fill 56 287 607 56 288 607 minecraft:light_gray_concrete
fill 56 287 609 56 288 609 minecraft:light_gray_concrete
fill 57 287 606 57 288 606 minecraft:light_gray_concrete
fill 57 287 608 57 288 608 minecraft:light_gray_concrete
fill 57 287 610 57 288 610 minecraft:light_gray_concrete
fill 58 287 605 58 288 605 minecraft:light_gray_concrete
fill 58 287 607 58 288 607 minecraft:light_gray_concrete
fill 58 287 609 58 288 609 minecraft:light_gray_concrete
fill 59 287 606 59 288 606 minecraft:light_gray_concrete
fill 59 287 608 59 288 608 minecraft:light_gray_concrete
fill 59 287 610 59 288 610 minecraft:light_gray_concrete
fill 60 287 605 60 288 605 minecraft:light_gray_concrete
fill 60 287 607 60 288 607 minecraft:light_gray_concrete
fill 60 287 609 60 288 609 minecraft:light_gray_concrete
fill 60 287 640 60 288 640 minecraft:magenta_concrete
fill 60 287 642 60 288 642 minecraft:magenta_concrete
fill 61 287 606 61 288 606 minecraft:light_gray_concrete
fill 61 287 608 61 288 608 minecraft:light_gray_concrete
fill 61 287 610 61 288 610 minecraft:light_gray_concrete
fill 61 287 643 63 288 643 minecraft:magenta_concrete
fill 62 287 605 62 288 605 minecraft:light_gray_concrete
fill 62 287 607 62 288 607 minecraft:light_gray_concrete
fill 62 287 609 62 288 609 minecraft:light_gray_concrete
fill 63 287 606 63 288 606 minecraft:light_gray_concrete
fill 63 287 608 63 288 608 minecraft:light_gray_concrete
fill 63 287 610 63 288 610 minecraft:light_gray_concrete
fill 64 287 605 64 288 605 minecraft:light_gray_concrete
fill 64 287 607 64 288 607 minecraft:light_gray_concrete
fill 64 287 609 64 288 609 minecraft:light_gray_concrete
fill 64 287 640 64 288 640 minecraft:magenta_concrete
fill 64 287 642 64 288 642 minecraft:magenta_concrete
fill 65 287 606 65 288 606 minecraft:light_gray_concrete
fill 65 287 608 65 288 608 minecraft:light_gray_concrete
fill 65 287 610 65 288 610 minecraft:light_gray_concrete
fill 66 287 605 66 288 605 minecraft:light_gray_concrete
fill 66 287 607 66 288 607 minecraft:light_gray_concrete
fill 66 287 609 66 288 609 minecraft:light_gray_concrete
fill 77 287 638 77 288 638 minecraft:light_gray_concrete
fill 77 287 640 77 288 640 minecraft:light_gray_concrete
fill 77 287 642 77 288 642 minecraft:light_gray_concrete
fill 77 287 644 77 288 644 minecraft:light_gray_concrete
fill 78 287 639 78 288 639 minecraft:light_gray_concrete
fill 78 287 641 78 288 641 minecraft:light_gray_concrete
fill 78 287 643 78 288 643 minecraft:light_gray_concrete
fill 78 287 645 78 288 645 minecraft:light_gray_concrete
fill 79 287 608 79 288 608 minecraft:light_gray_concrete
fill 79 287 610 79 288 610 minecraft:light_gray_concrete
fill 79 287 612 79 288 612 minecraft:light_gray_concrete
fill 79 287 614 79 288 614 minecraft:light_gray_concrete
fill 79 287 638 79 288 638 minecraft:light_gray_concrete
fill 79 287 640 79 288 640 minecraft:light_gray_concrete
fill 79 287 642 79 288 642 minecraft:light_gray_concrete
fill 79 287 644 79 288 644 minecraft:light_gray_concrete
fill 80 287 607 80 288 607 minecraft:light_gray_concrete
fill 80 287 609 80 288 609 minecraft:light_gray_concrete
fill 80 287 611 80 288 611 minecraft:light_gray_concrete
fill 80 287 613 80 288 613 minecraft:light_gray_concrete
fill 80 287 615 80 288 615 minecraft:light_gray_concrete
fill 80 287 639 80 288 639 minecraft:light_gray_concrete
fill 80 287 641 80 288 641 minecraft:light_gray_concrete
fill 80 287 643 80 288 643 minecraft:light_gray_concrete
fill 80 287 645 80 288 645 minecraft:light_gray_concrete
fill 81 287 608 81 288 608 minecraft:light_gray_concrete
fill 81 287 610 81 288 610 minecraft:light_gray_concrete
fill 81 287 612 81 288 612 minecraft:light_gray_concrete
fill 81 287 614 81 288 614 minecraft:light_gray_concrete
fill 81 287 638 81 288 638 minecraft:light_gray_concrete
fill 81 287 640 81 288 640 minecraft:light_gray_concrete
fill 81 287 642 81 288 642 minecraft:light_gray_concrete
fill 81 287 644 81 288 644 minecraft:light_gray_concrete
fill 82 287 607 82 288 607 minecraft:light_gray_concrete
fill 82 287 609 82 288 609 minecraft:light_gray_concrete
fill 82 287 611 82 288 611 minecraft:light_gray_concrete
fill 82 287 613 82 288 613 minecraft:light_gray_concrete
fill 82 287 615 82 288 615 minecraft:light_gray_concrete
fill 82 287 639 82 288 639 minecraft:light_gray_concrete
fill 82 287 641 82 288 641 minecraft:light_gray_concrete
fill 82 287 643 82 288 643 minecraft:light_gray_concrete
fill 82 287 645 82 288 645 minecraft:light_gray_concrete
fill 83 287 608 83 288 608 minecraft:light_gray_concrete
fill 83 287 610 83 288 610 minecraft:light_gray_concrete
fill 83 287 612 83 288 612 minecraft:light_gray_concrete
fill 83 287 614 83 288 614 minecraft:light_gray_concrete
fill 83 287 638 83 288 638 minecraft:light_gray_concrete
fill 83 287 640 83 288 640 minecraft:light_gray_concrete
fill 83 287 642 83 288 642 minecraft:light_gray_concrete
fill 83 287 644 83 288 644 minecraft:light_gray_concrete
fill 84 287 607 84 288 607 minecraft:light_gray_concrete
fill 84 287 609 84 288 609 minecraft:light_gray_concrete
fill 84 287 611 84 288 611 minecraft:light_gray_concrete
fill 84 287 613 84 288 613 minecraft:light_gray_concrete
fill 84 287 615 84 288 615 minecraft:light_gray_concrete
fill 84 287 639 84 288 639 minecraft:light_gray_concrete
fill 84 287 641 84 288 641 minecraft:light_gray_concrete
fill 84 287 643 84 288 643 minecraft:light_gray_concrete
fill 84 287 645 84 288 645 minecraft:light_gray_concrete
fill 85 287 608 85 288 608 minecraft:light_gray_concrete
fill 85 287 610 85 288 610 minecraft:light_gray_concrete
fill 85 287 612 85 288 612 minecraft:light_gray_concrete
fill 85 287 614 85 288 614 minecraft:light_gray_concrete
fill 85 287 638 85 288 638 minecraft:light_gray_concrete
fill 85 287 640 85 288 640 minecraft:light_gray_concrete
fill 85 287 642 85 288 642 minecraft:light_gray_concrete
fill 85 287 644 85 288 644 minecraft:light_gray_concrete
fill 86 287 607 86 288 607 minecraft:light_gray_concrete
fill 86 287 609 86 288 609 minecraft:light_gray_concrete
fill 86 287 611 86 288 611 minecraft:light_gray_concrete
fill 86 287 613 86 288 613 minecraft:light_gray_concrete
fill 86 287 615 86 288 615 minecraft:light_gray_concrete
fill 87 287 608 87 288 608 minecraft:light_gray_concrete
fill 87 287 610 87 288 610 minecraft:light_gray_concrete
fill 87 287 612 87 288 612 minecraft:light_gray_concrete
fill 87 287 614 87 288 614 minecraft:light_gray_concrete
fill 88 287 607 88 288 607 minecraft:light_gray_concrete
fill 88 287 609 88 288 609 minecraft:light_gray_concrete
fill 88 287 611 88 288 611 minecraft:light_gray_concrete
fill 88 287 613 88 288 613 minecraft:light_gray_concrete
fill 88 287 615 88 288 615 minecraft:light_gray_concrete
fill 59 288 640 59 288 641 minecraft:magenta_concrete
setblock 60 288 639 minecraft:magenta_concrete
setblock 60 288 643 minecraft:magenta_concrete
fill 61 288 638 63 288 638 minecraft:magenta_concrete
setblock 64 288 639 minecraft:magenta_concrete
setblock 64 288 643 minecraft:magenta_concrete
fill 65 288 640 65 288 641 minecraft:magenta_concrete
fill 71 288 638 72 289 639 minecraft:glass
setblock 54 289 605 minecraft:sea_lantern
setblock 54 289 607 minecraft:sea_lantern
setblock 54 289 609 minecraft:sea_lantern
setblock 55 289 606 minecraft:sea_lantern
setblock 55 289 608 minecraft:sea_lantern
setblock 55 289 610 minecraft:sea_lantern
setblock 56 289 605 minecraft:sea_lantern
setblock 56 289 607 minecraft:sea_lantern
setblock 56 289 609 minecraft:sea_lantern
fill 56 289 637 61 291 645 minecraft:light_gray_concrete
setblock 57 289 606 minecraft:sea_lantern
setblock 57 289 608 minecraft:sea_lantern
setblock 57 289 610 minecraft:sea_lantern
setblock 58 289 605 minecraft:sea_lantern
setblock 58 289 607 minecraft:sea_lantern
setblock 58 289 609 minecraft:sea_lantern
setblock 59 289 606 minecraft:sea_lantern
setblock 59 289 608 minecraft:sea_lantern
setblock 59 289 610 minecraft:sea_lantern
setblock 60 289 605 minecraft:sea_lantern
setblock 60 289 607 minecraft:sea_lantern
setblock 60 289 609 minecraft:sea_lantern
setblock 61 289 606 minecraft:sea_lantern
setblock 61 289 608 minecraft:sea_lantern
setblock 61 289 610 minecraft:sea_lantern
setblock 62 289 605 minecraft:sea_lantern
setblock 62 289 607 minecraft:sea_lantern
setblock 62 289 609 minecraft:sea_lantern
fill 62 289 637 68 291 644 minecraft:light_gray_concrete
setblock 63 289 606 minecraft:sea_lantern
setblock 63 289 608 minecraft:sea_lantern
setblock 63 289 610 minecraft:sea_lantern
setblock 64 289 605 minecraft:sea_lantern
setblock 64 289 607 minecraft:sea_lantern
setblock 64 289 609 minecraft:sea_lantern
fill 64 289 645 68 291 645 minecraft:light_gray_concrete
setblock 65 289 606 minecraft:sea_lantern
setblock 65 289 608 minecraft:sea_lantern
setblock 65 289 610 minecraft:sea_lantern
setblock 66 289 605 minecraft:sea_lantern
setblock 66 289 607 minecraft:sea_lantern
setblock 66 289 609 minecraft:sea_lantern
fill 68 289 610 69 290 610 minecraft:gray_concrete
setblock 77 289 638 minecraft:sea_lantern
setblock 77 289 640 minecraft:sea_lantern
setblock 77 289 642 minecraft:sea_lantern
setblock 77 289 644 minecraft:sea_lantern
setblock 78 289 639 minecraft:sea_lantern
setblock 78 289 641 minecraft:sea_lantern
setblock 78 289 643 minecraft:sea_lantern
setblock 78 289 645 minecraft:sea_lantern
setblock 79 289 608 minecraft:sea_lantern
setblock 79 289 610 minecraft:sea_lantern
setblock 79 289 612 minecraft:sea_lantern
setblock 79 289 614 minecraft:sea_lantern
setblock 79 289 638 minecraft:sea_lantern
setblock 79 289 640 minecraft:sea_lantern
setblock 79 289 642 minecraft:sea_lantern
setblock 79 289 644 minecraft:sea_lantern
setblock 80 289 607 minecraft:sea_lantern
setblock 80 289 609 minecraft:sea_lantern
setblock 80 289 611 minecraft:sea_lantern
setblock 80 289 613 minecraft:sea_lantern
setblock 80 289 615 minecraft:sea_lantern
setblock 80 289 639 minecraft:sea_lantern
setblock 80 289 641 minecraft:sea_lantern
setblock 80 289 643 minecraft:sea_lantern
setblock 80 289 645 minecraft:sea_lantern
setblock 81 289 608 minecraft:sea_lantern
setblock 81 289 610 minecraft:sea_lantern
setblock 81 289 612 minecraft:sea_lantern
setblock 81 289 614 minecraft:sea_lantern
setblock 81 289 638 minecraft:sea_lantern
setblock 81 289 640 minecraft:sea_lantern
setblock 81 289 642 minecraft:sea_lantern
setblock 81 289 644 minecraft:sea_lantern
setblock 82 289 607 minecraft:sea_lantern
setblock 82 289 609 minecraft:sea_lantern
setblock 82 289 611 minecraft:sea_lantern
setblock 82 289 613 minecraft:sea_lantern
setblock 82 289 615 minecraft:sea_lantern
setblock 82 289 639 minecraft:sea_lantern
setblock 82 289 641 minecraft:sea_lantern
setblock 82 289 643 minecraft:sea_lantern
setblock 82 289 645 minecraft:sea_lantern
setblock 83 289 608 minecraft:sea_lantern
setblock 83 289 610 minecraft:sea_lantern
setblock 83 289 612 minecraft:sea_lantern
setblock 83 289 614 minecraft:sea_lantern
setblock 83 289 638 minecraft:sea_lantern
setblock 83 289 640 minecraft:sea_lantern
setblock 83 289 642 minecraft:sea_lantern
setblock 83 289 644 minecraft:sea_lantern
setblock 84 289 607 minecraft:sea_lantern
setblock 84 289 609 minecraft:sea_lantern
setblock 84 289 611 minecraft:sea_lantern
setblock 84 289 613 minecraft:sea_lantern
setblock 84 289 615 minecraft:sea_lantern
setblock 84 289 639 minecraft:sea_lantern
setblock 84 289 641 minecraft:sea_lantern
setblock 84 289 643 minecraft:sea_lantern
setblock 84 289 645 minecraft:sea_lantern
setblock 85 289 608 minecraft:sea_lantern
setblock 85 289 610 minecraft:sea_lantern
setblock 85 289 612 minecraft:sea_lantern
setblock 85 289 614 minecraft:sea_lantern
setblock 85 289 638 minecraft:sea_lantern
setblock 85 289 640 minecraft:sea_lantern
setblock 85 289 642 minecraft:sea_lantern
setblock 85 289 644 minecraft:sea_lantern
setblock 86 289 607 minecraft:sea_lantern
setblock 86 289 609 minecraft:sea_lantern
setblock 86 289 611 minecraft:sea_lantern
setblock 86 289 613 minecraft:sea_lantern
setblock 86 289 615 minecraft:sea_lantern
setblock 87 289 608 minecraft:sea_lantern
setblock 87 289 610 minecraft:sea_lantern
setblock 87 289 612 minecraft:sea_lantern
setblock 87 289 614 minecraft:sea_lantern
setblock 88 289 607 minecraft:sea_lantern
setblock 88 289 609 minecraft:sea_lantern
setblock 88 289 611 minecraft:sea_lantern
setblock 88 289 613 minecraft:sea_lantern
setblock 88 289 615 minecraft:sea_lantern
fill 47 290 609 47 297 609 minecraft:gray_concrete
fill 47 290 617 47 297 617 minecraft:gray_concrete
fill 47 290 625 47 297 625 minecraft:gray_concrete
fill 47 290 633 47 297 633 minecraft:gray_concrete
fill 47 290 641 47 297 641 minecraft:gray_concrete
fill 50 290 646 50 297 646 minecraft:gray_concrete
fill 54 290 604 54 297 604 minecraft:gray_concrete
fill 54 290 605 54 291 605 minecraft:light_gray_concrete
fill 54 290 607 54 291 607 minecraft:light_gray_concrete
fill 54 290 609 54 291 609 minecraft:light_gray_concrete
fill 55 290 606 55 291 606 minecraft:light_gray_concrete
fill 55 290 608 55 291 608 minecraft:light_gray_concrete
fill 55 290 610 55 291 610 minecraft:light_gray_concrete
fill 56 290 605 56 291 605 minecraft:light_gray_concrete
fill 56 290 607 56 291 607 minecraft:light_gray_concrete
fill 56 290 609 56 291 609 minecraft:light_gray_concrete
fill 57 290 606 57 291 606 minecraft:light_gray_concrete
fill 57 290 608 57 291 608 minecraft:light_gray_concrete
fill 57 290 610 57 291 610 minecraft:light_gray_concrete
fill 58 290 605 58 291 605 minecraft:light_gray_concrete
fill 58 290 607 58 291 607 minecraft:light_gray_concrete
fill 58 290 609 58 291 609 minecraft:light_gray_concrete
fill 58 290 646 58 297 646 minecraft:gray_concrete
fill 59 290 606 59 291 606 minecraft:light_gray_concrete
fill 59 290 608 59 291 608 minecraft:light_gray_concrete
fill 59 290 610 59 291 610 minecraft:light_gray_concrete
fill 60 290 605 60 291 605 minecraft:light_gray_concrete
fill 60 290 607 60 291 607 minecraft:light_gray_concrete
fill 60 290 609 60 291 609 minecraft:light_gray_concrete
fill 61 290 606 61 291 606 minecraft:light_gray_concrete
fill 61 290 608 61 291 608 minecraft:light_gray_concrete
fill 61 290 610 61 291 610 minecraft:light_gray_concrete
fill 62 290 604 62 297 604 minecraft:gray_concrete
fill 62 290 605 62 291 605 minecraft:light_gray_concrete
fill 62 290 607 62 291 607 minecraft:light_gray_concrete
fill 62 290 609 62 291 609 minecraft:light_gray_concrete
fill 63 290 606 63 291 606 minecraft:light_gray_concrete
fill 63 290 608 63 291 608 minecraft:light_gray_concrete
fill 63 290 610 63 291 610 minecraft:light_gray_concrete
fill 64 290 605 64 291 605 minecraft:light_gray_concrete
fill 64 290 607 64 291 607 minecraft:light_gray_concrete
fill 64 290 609 64 291 609 minecraft:light_gray_concrete
fill 65 290 606 65 291 606 minecraft:light_gray_concrete
fill 65 290 608 65 291 608 minecraft:light_gray_concrete
fill 65 290 610 65 291 610 minecraft:light_gray_concrete
fill 66 290 605 66 291 605 minecraft:light_gray_concrete
fill 66 290 607 66 291 607 minecraft:light_gray_concrete
fill 66 290 609 66 291 609 minecraft:light_gray_concrete
fill 66 290 646 66 297 646 minecraft:gray_concrete
fill 70 290 604 70 297 604 minecraft:gray_concrete
fill 74 290 646 74 297 646 minecraft:gray_concrete
fill 77 290 638 77 291 638 minecraft:light_gray_concrete
fill 77 290 640 77 291 640 minecraft:light_gray_concrete
fill 77 290 642 77 291 642 minecraft:light_gray_concrete
fill 77 290 644 77 291 644 minecraft:light_gray_concrete
fill 78 290 604 78 297 604 minecraft:gray_concrete
fill 78 290 639 78 291 639 minecraft:light_gray_concrete
fill 78 290 641 78 291 641 minecraft:light_gray_concrete
fill 78 290 643 78 291 643 minecraft:light_gray_concrete
fill 78 290 645 78 291 645 minecraft:light_gray_concrete
fill 79 290 608 79 291 608 minecraft:light_gray_concrete
fill 79 290 610 79 291 610 minecraft:light_gray_concrete
fill 79 290 612 79 291 612 minecraft:light_gray_concrete
fill 79 290 614 79 291 614 minecraft:light_gray_concrete
fill 79 290 638 79 291 638 minecraft:light_gray_concrete
fill 79 290 640 79 291 640 minecraft:light_gray_concrete
fill 79 290 642 79 291 642 minecraft:light_gray_concrete
fill 79 290 644 79 291 644 minecraft:light_gray_concrete
fill 80 290 607 80 291 607 minecraft:light_gray_concrete
fill 80 290 609 80 291 609 minecraft:light_gray_concrete
fill 80 290 611 80 291 611 minecraft:light_gray_concrete
fill 80 290 613 80 291 613 minecraft:light_gray_concrete
fill 80 290 615 80 291 615 minecraft:light_gray_concrete
fill 80 290 639 80 291 639 minecraft:light_gray_concrete
fill 80 290 641 80 291 641 minecraft:light_gray_concrete
fill 80 290 643 80 291 643 minecraft:light_gray_concrete
fill 80 290 645 80 291 645 minecraft:light_gray_concrete
fill 81 290 608 81 291 608 minecraft:light_gray_concrete
fill 81 290 610 81 291 610 minecraft:light_gray_concrete
fill 81 290 612 81 291 612 minecraft:light_gray_concrete
fill 81 290 614 81 291 614 minecraft:light_gray_concrete
fill 81 290 638 81 291 638 minecraft:light_gray_concrete
fill 81 290 640 81 291 640 minecraft:light_gray_concrete
fill 81 290 642 81 291 642 minecraft:light_gray_concrete
fill 81 290 644 81 291 644 minecraft:light_gray_concrete
fill 82 290 607 82 291 607 minecraft:light_gray_concrete
fill 82 290 609 82 291 609 minecraft:light_gray_concrete
fill 82 290 611 82 291 611 minecraft:light_gray_concrete
fill 82 290 613 82 291 613 minecraft:light_gray_concrete
fill 82 290 615 82 291 615 minecraft:light_gray_concrete
fill 82 290 639 82 291 639 minecraft:light_gray_concrete
fill 82 290 641 82 291 641 minecraft:light_gray_concrete
fill 82 290 643 82 291 643 minecraft:light_gray_concrete
fill 82 290 645 82 291 645 minecraft:light_gray_concrete
fill 82 290 646 82 297 646 minecraft:gray_concrete
fill 83 290 608 83 291 608 minecraft:light_gray_concrete
fill 83 290 610 83 291 610 minecraft:light_gray_concrete
fill 83 290 612 83 291 612 minecraft:light_gray_concrete
fill 83 290 614 83 291 614 minecraft:light_gray_concrete
fill 83 290 638 83 291 638 minecraft:light_gray_concrete
fill 83 290 640 83 291 640 minecraft:light_gray_concrete
fill 83 290 642 83 291 642 minecraft:light_gray_concrete
fill 83 290 644 83 291 644 minecraft:light_gray_concrete
fill 84 290 607 84 291 607 minecraft:light_gray_concrete
fill 84 290 609 84 291 609 minecraft:light_gray_concrete
fill 84 290 611 84 291 611 minecraft:light_gray_concrete
fill 84 290 613 84 291 613 minecraft:light_gray_concrete
fill 84 290 615 84 291 615 minecraft:light_gray_concrete
fill 84 290 639 84 291 639 minecraft:light_gray_concrete
fill 84 290 641 84 291 641 minecraft:light_gray_concrete
fill 84 290 643 84 291 643 minecraft:light_gray_concrete
fill 84 290 645 84 291 645 minecraft:light_gray_concrete
fill 85 290 608 85 291 608 minecraft:light_gray_concrete
fill 85 290 610 85 291 610 minecraft:light_gray_concrete
fill 85 290 612 85 291 612 minecraft:light_gray_concrete
fill 85 290 614 85 291 614 minecraft:light_gray_concrete
fill 85 290 638 85 291 638 minecraft:light_gray_concrete
fill 85 290 640 85 291 640 minecraft:light_gray_concrete
fill 85 290 642 85 291 642 minecraft:light_gray_concrete
fill 85 290 644 85 291 644 minecraft:light_gray_concrete
fill 86 290 604 86 297 604 minecraft:gray_concrete
fill 86 290 607 86 291 607 minecraft:light_gray_concrete
fill 86 290 609 86 291 609 minecraft:light_gray_concrete
fill 86 290 611 86 291 611 minecraft:light_gray_concrete
fill 86 290 613 86 291 613 minecraft:light_gray_concrete
fill 86 290 615 86 291 615 minecraft:light_gray_concrete
fill 87 290 608 87 291 608 minecraft:light_gray_concrete
fill 87 290 610 87 291 610 minecraft:light_gray_concrete
fill 87 290 612 87 291 612 minecraft:light_gray_concrete
fill 87 290 614 87 291 614 minecraft:light_gray_concrete
fill 88 290 607 88 291 607 minecraft:light_gray_concrete
fill 88 290 609 88 291 609 minecraft:light_gray_concrete
fill 88 290 611 88 291 611 minecraft:light_gray_concrete
fill 88 290 613 88 291 613 minecraft:light_gray_concrete
fill 88 290 615 88 291 615 minecraft:light_gray_concrete
fill 89 290 609 89 297 609 minecraft:gray_concrete
fill 89 290 617 89 297 617 minecraft:gray_concrete
fill 89 290 625 89 297 625 minecraft:gray_concrete
fill 89 290 633 89 297 633 minecraft:gray_concrete
fill 89 290 641 89 297 641 minecraft:gray_concrete
setblock 50 291 607 minecraft:light[level=14]
setblock 50 291 615 minecraft:light[level=14]
setblock 50 291 623 minecraft:light[level=14]
setblock 50 291 631 minecraft:light[level=14]
setblock 50 291 639 minecraft:light[level=14]
setblock 58 291 615 minecraft:light[level=14]
setblock 58 291 623 minecraft:light[level=14]
setblock 58 291 631 minecraft:light[level=14]
setblock 66 291 615 minecraft:light[level=14]
setblock 66 291 623 minecraft:light[level=14]
setblock 66 291 631 minecraft:light[level=14]
setblock 74 291 607 minecraft:light[level=14]
setblock 74 291 615 minecraft:light[level=14]
setblock 74 291 623 minecraft:light[level=14]
setblock 74 291 631 minecraft:light[level=14]
setblock 74 291 639 minecraft:light[level=14]
setblock 82 291 623 minecraft:light[level=14]
setblock 82 291 631 minecraft:light[level=14]
setblock 54 292 605 minecraft:sea_lantern
setblock 54 292 607 minecraft:sea_lantern
setblock 54 292 609 minecraft:sea_lantern
setblock 55 292 606 minecraft:sea_lantern
setblock 55 292 608 minecraft:sea_lantern
setblock 55 292 610 minecraft:sea_lantern
setblock 56 292 605 minecraft:sea_lantern
setblock 56 292 607 minecraft:sea_lantern
setblock 56 292 609 minecraft:sea_lantern
setblock 56 292 637 minecraft:sea_lantern
fill 56 292 638 56 300 638 minecraft:light_gray_concrete
setblock 56 292 639 minecraft:sea_lantern
fill 56 292 640 56 300 640 minecraft:light_gray_concrete
setblock 56 292 641 minecraft:sea_lantern
fill 56 292 642 56 300 642 minecraft:light_gray_concrete
setblock 56 292 643 minecraft:sea_lantern
fill 56 292 644 56 300 644 minecraft:light_gray_concrete
setblock 56 292 645 minecraft:sea_lantern
setblock 57 292 606 minecraft:sea_lantern
setblock 57 292 608 minecraft:sea_lantern
setblock 57 292 610 minecraft:sea_lantern
fill 57 292 637 57 300 637 minecraft:light_gray_concrete
setblock 57 292 638 minecraft:sea_lantern
fill 57 292 639 57 300 639 minecraft:light_gray_concrete
setblock 57 292 640 minecraft:sea_lantern
fill 57 292 641 57 300 641 minecraft:light_gray_concrete
setblock 57 292 642 minecraft:sea_lantern
fill 57 292 643 57 300 643 minecraft:light_gray_concrete
setblock 57 292 644 minecraft:sea_lantern
fill 57 292 645 57 300 645 minecraft:light_gray_concrete
setblock 58 292 605 minecraft:sea_lantern
setblock 58 292 607 minecraft:sea_lantern
setblock 58 292 609 minecraft:sea_lantern
setblock 58 292 637 minecraft:sea_lantern
fill 58 292 638 58 300 638 minecraft:light_gray_concrete
setblock 58 292 639 minecraft:sea_lantern
fill 58 292 640 58 300 640 minecraft:light_gray_concrete
setblock 58 292 641 minecraft:sea_lantern
fill 58 292 642 58 300 642 minecraft:light_gray_concrete
setblock 58 292 643 minecraft:sea_lantern
fill 58 292 644 58 300 644 minecraft:light_gray_concrete
setblock 58 292 645 minecraft:sea_lantern
setblock 59 292 606 minecraft:sea_lantern
setblock 59 292 608 minecraft:sea_lantern
setblock 59 292 610 minecraft:sea_lantern
fill 59 292 637 59 300 637 minecraft:light_gray_concrete
setblock 59 292 638 minecraft:sea_lantern
fill 59 292 639 59 300 639 minecraft:light_gray_concrete
setblock 59 292 640 minecraft:sea_lantern
fill 59 292 641 59 300 641 minecraft:light_gray_concrete
setblock 59 292 642 minecraft:sea_lantern
fill 59 292 643 59 300 643 minecraft:light_gray_concrete
setblock 59 292 644 minecraft:sea_lantern
fill 59 292 645 59 300 645 minecraft:light_gray_concrete
setblock 60 292 605 minecraft:sea_lantern
setblock 60 292 607 minecraft:sea_lantern
setblock 60 292 609 minecraft:sea_lantern
setblock 60 292 637 minecraft:sea_lantern
fill 60 292 638 60 300 638 minecraft:light_gray_concrete
setblock 60 292 639 minecraft:sea_lantern
fill 60 292 640 60 300 640 minecraft:light_gray_concrete
setblock 60 292 641 minecraft:sea_lantern
fill 60 292 642 60 300 642 minecraft:light_gray_concrete
setblock 60 292 643 minecraft:sea_lantern
fill 60 292 644 60 300 644 minecraft:light_gray_concrete
setblock 60 292 645 minecraft:sea_lantern
setblock 61 292 606 minecraft:sea_lantern
setblock 61 292 608 minecraft:sea_lantern
setblock 61 292 610 minecraft:sea_lantern
fill 61 292 637 61 300 637 minecraft:light_gray_concrete
setblock 61 292 638 minecraft:sea_lantern
fill 61 292 639 61 300 639 minecraft:light_gray_concrete
setblock 61 292 640 minecraft:sea_lantern
fill 61 292 641 61 300 641 minecraft:light_gray_concrete
setblock 61 292 642 minecraft:sea_lantern
fill 61 292 643 61 300 643 minecraft:light_gray_concrete
setblock 61 292 644 minecraft:sea_lantern
fill 61 292 645 61 300 645 minecraft:light_gray_concrete
setblock 62 292 605 minecraft:sea_lantern
setblock 62 292 607 minecraft:sea_lantern
setblock 62 292 609 minecraft:sea_lantern
setblock 62 292 637 minecraft:sea_lantern
fill 62 292 638 62 300 638 minecraft:light_gray_concrete
setblock 62 292 639 minecraft:sea_lantern
fill 62 292 640 62 300 640 minecraft:light_gray_concrete
setblock 62 292 641 minecraft:sea_lantern
fill 62 292 642 62 300 642 minecraft:light_gray_concrete
setblock 62 292 643 minecraft:sea_lantern
fill 62 292 644 62 300 644 minecraft:light_gray_concrete
setblock 62 292 645 minecraft:sea_lantern
setblock 63 292 606 minecraft:sea_lantern
setblock 63 292 608 minecraft:sea_lantern
setblock 63 292 610 minecraft:sea_lantern
fill 63 292 637 63 300 637 minecraft:light_gray_concrete
setblock 63 292 638 minecraft:sea_lantern
fill 63 292 639 63 300 639 minecraft:light_gray_concrete
setblock 63 292 640 minecraft:sea_lantern
fill 63 292 641 63 300 641 minecraft:light_gray_concrete
setblock 63 292 642 minecraft:sea_lantern
fill 63 292 643 63 300 643 minecraft:light_gray_concrete
setblock 63 292 644 minecraft:sea_lantern
fill 63 292 645 63 300 645 minecraft:light_gray_concrete
setblock 64 292 605 minecraft:sea_lantern
setblock 64 292 607 minecraft:sea_lantern
setblock 64 292 609 minecraft:sea_lantern
setblock 64 292 637 minecraft:sea_lantern
fill 64 292 638 64 300 638 minecraft:light_gray_concrete
setblock 64 292 639 minecraft:sea_lantern
fill 64 292 640 64 300 640 minecraft:light_gray_concrete
setblock 64 292 641 minecraft:sea_lantern
fill 64 292 642 64 300 642 minecraft:light_gray_concrete
setblock 64 292 643 minecraft:sea_lantern
fill 64 292 644 64 300 644 minecraft:light_gray_concrete
setblock 64 292 645 minecraft:sea_lantern
setblock 65 292 606 minecraft:sea_lantern
setblock 65 292 608 minecraft:sea_lantern
setblock 65 292 610 minecraft:sea_lantern
fill 65 292 637 65 300 637 minecraft:light_gray_concrete
setblock 65 292 638 minecraft:sea_lantern
fill 65 292 639 65 300 639 minecraft:light_gray_concrete
setblock 65 292 640 minecraft:sea_lantern
fill 65 292 641 65 300 641 minecraft:light_gray_concrete
setblock 65 292 642 minecraft:sea_lantern
fill 65 292 643 65 300 643 minecraft:light_gray_concrete
setblock 65 292 644 minecraft:sea_lantern
fill 65 292 645 65 300 645 minecraft:light_gray_concrete
setblock 66 292 605 minecraft:sea_lantern
setblock 66 292 607 minecraft:sea_lantern
setblock 66 292 609 minecraft:sea_lantern
setblock 66 292 637 minecraft:sea_lantern
fill 66 292 638 66 300 638 minecraft:light_gray_concrete
setblock 66 292 639 minecraft:sea_lantern
fill 66 292 640 66 300 640 minecraft:light_gray_concrete
setblock 66 292 641 minecraft:sea_lantern
fill 66 292 642 66 300 642 minecraft:light_gray_concrete
setblock 66 292 643 minecraft:sea_lantern
fill 66 292 644 66 300 644 minecraft:light_gray_concrete
setblock 66 292 645 minecraft:sea_lantern
fill 67 292 637 67 300 637 minecraft:light_gray_concrete
setblock 67 292 638 minecraft:sea_lantern
fill 67 292 639 67 300 639 minecraft:light_gray_concrete
setblock 67 292 640 minecraft:sea_lantern
fill 67 292 641 67 300 641 minecraft:light_gray_concrete
setblock 67 292 642 minecraft:sea_lantern
fill 67 292 643 67 300 643 minecraft:light_gray_concrete
setblock 67 292 644 minecraft:sea_lantern
fill 67 292 645 67 300 645 minecraft:light_gray_concrete
setblock 68 292 637 minecraft:sea_lantern
fill 68 292 638 68 300 638 minecraft:light_gray_concrete
setblock 68 292 639 minecraft:sea_lantern
fill 68 292 640 68 300 640 minecraft:light_gray_concrete
setblock 68 292 641 minecraft:sea_lantern
fill 68 292 642 68 300 642 minecraft:light_gray_concrete
setblock 68 292 643 minecraft:sea_lantern
fill 68 292 644 68 300 644 minecraft:light_gray_concrete
setblock 68 292 645 minecraft:sea_lantern
fill 71 292 611 72 293 611 minecraft:magenta_concrete
setblock 77 292 638 minecraft:sea_lantern
setblock 77 292 640 minecraft:sea_lantern
setblock 77 292 642 minecraft:sea_lantern
setblock 77 292 644 minecraft:sea_lantern
setblock 78 292 639 minecraft:sea_lantern
setblock 78 292 641 minecraft:sea_lantern
setblock 78 292 643 minecraft:sea_lantern
setblock 78 292 645 minecraft:sea_lantern
setblock 79 292 608 minecraft:sea_lantern
setblock 79 292 610 minecraft:sea_lantern
setblock 79 292 612 minecraft:sea_lantern
setblock 79 292 614 minecraft:sea_lantern
setblock 79 292 638 minecraft:sea_lantern
setblock 79 292 640 minecraft:sea_lantern
setblock 79 292 642 minecraft:sea_lantern
setblock 79 292 644 minecraft:sea_lantern
setblock 80 292 607 minecraft:sea_lantern
setblock 80 292 609 minecraft:sea_lantern
setblock 80 292 611 minecraft:sea_lantern
setblock 80 292 613 minecraft:sea_lantern
setblock 80 292 615 minecraft:sea_lantern
setblock 80 292 639 minecraft:sea_lantern
setblock 80 292 641 minecraft:sea_lantern
setblock 80 292 643 minecraft:sea_lantern
setblock 80 292 645 minecraft:sea_lantern
setblock 81 292 608 minecraft:sea_lantern
setblock 81 292 610 minecraft:sea_lantern
setblock 81 292 612 minecraft:sea_lantern
setblock 81 292 614 minecraft:sea_lantern
setblock 81 292 638 minecraft:sea_lantern
setblock 81 292 640 minecraft:sea_lantern
setblock 81 292 642 minecraft:sea_lantern
setblock 81 292 644 minecraft:sea_lantern
setblock 82 292 607 minecraft:sea_lantern
setblock 82 292 609 minecraft:sea_lantern
setblock 82 292 611 minecraft:sea_lantern
setblock 82 292 613 minecraft:sea_lantern
setblock 82 292 615 minecraft:sea_lantern
setblock 82 292 639 minecraft:sea_lantern
setblock 82 292 641 minecraft:sea_lantern
setblock 82 292 643 minecraft:sea_lantern
setblock 82 292 645 minecraft:sea_lantern
setblock 83 292 608 minecraft:sea_lantern
setblock 83 292 610 minecraft:sea_lantern
setblock 83 292 612 minecraft:sea_lantern
setblock 83 292 614 minecraft:sea_lantern
setblock 83 292 638 minecraft:sea_lantern
setblock 83 292 640 minecraft:sea_lantern
setblock 83 292 642 minecraft:sea_lantern
setblock 83 292 644 minecraft:sea_lantern
setblock 84 292 607 minecraft:sea_lantern
setblock 84 292 609 minecraft:sea_lantern
setblock 84 292 611 minecraft:sea_lantern
setblock 84 292 613 minecraft:sea_lantern
setblock 84 292 615 minecraft:sea_lantern
setblock 84 292 639 minecraft:sea_lantern
setblock 84 292 641 minecraft:sea_lantern
setblock 84 292 643 minecraft:sea_lantern
setblock 84 292 645 minecraft:sea_lantern
setblock 85 292 608 minecraft:sea_lantern
setblock 85 292 610 minecraft:sea_lantern
setblock 85 292 612 minecraft:sea_lantern
setblock 85 292 614 minecraft:sea_lantern
setblock 85 292 638 minecraft:sea_lantern
setblock 85 292 640 minecraft:sea_lantern
setblock 85 292 642 minecraft:sea_lantern
setblock 85 292 644 minecraft:sea_lantern
setblock 86 292 607 minecraft:sea_lantern
setblock 86 292 609 minecraft:sea_lantern
setblock 86 292 611 minecraft:sea_lantern
setblock 86 292 613 minecraft:sea_lantern
setblock 86 292 615 minecraft:sea_lantern
setblock 87 292 608 minecraft:sea_lantern
setblock 87 292 610 minecraft:sea_lantern
setblock 87 292 612 minecraft:sea_lantern
setblock 87 292 614 minecraft:sea_lantern
setblock 88 292 607 minecraft:sea_lantern
setblock 88 292 609 minecraft:sea_lantern
setblock 88 292 611 minecraft:sea_lantern
setblock 88 292 613 minecraft:sea_lantern
setblock 88 292 615 minecraft:sea_lantern
fill 54 293 605 54 294 605 minecraft:light_gray_concrete
fill 54 293 607 54 294 607 minecraft:light_gray_concrete
fill 54 293 609 54 294 609 minecraft:light_gray_concrete
fill 55 293 606 55 294 606 minecraft:light_gray_concrete
fill 55 293 608 55 294 608 minecraft:light_gray_concrete
fill 55 293 610 55 294 610 minecraft:light_gray_concrete
fill 56 293 605 56 294 605 minecraft:light_gray_concrete
fill 56 293 607 56 294 607 minecraft:light_gray_concrete
fill 56 293 609 56 294 609 minecraft:light_gray_concrete
fill 56 293 637 56 294 637 minecraft:light_gray_concrete
fill 56 293 639 56 294 639 minecraft:light_gray_concrete
fill 56 293 641 56 294 641 minecraft:light_gray_concrete
fill 56 293 643 56 294 643 minecraft:light_gray_concrete
fill 56 293 645 56 294 645 minecraft:light_gray_concrete
fill 57 293 606 57 294 606 minecraft:light_gray_concrete
fill 57 293 608 57 294 608 minecraft:light_gray_concrete
fill 57 293 610 57 294 610 minecraft:light_gray_concrete
fill 57 293 638 57 294 638 minecraft:light_gray_concrete
fill 57 293 640 57 294 640 minecraft:light_gray_concrete
fill 57 293 642 57 294 642 minecraft:light_gray_concrete
fill 57 293 644 57 294 644 minecraft:light_gray_concrete
fill 58 293 605 58 294 605 minecraft:light_gray_concrete
fill 58 293 607 58 294 607 minecraft:light_gray_concrete
fill 58 293 609 58 294 609 minecraft:light_gray_concrete
fill 58 293 637 58 294 637 minecraft:light_gray_concrete
fill 58 293 639 58 294 639 minecraft:light_gray_concrete
fill 58 293 641 58 294 641 minecraft:light_gray_concrete
fill 58 293 643 58 294 643 minecraft:light_gray_concrete
fill 58 293 645 58 294 645 minecraft:light_gray_concrete
fill 59 293 606 59 294 606 minecraft:light_gray_concrete
fill 59 293 608 59 294 608 minecraft:light_gray_concrete
fill 59 293 610 59 294 610 minecraft:light_gray_concrete
fill 59 293 638 59 294 638 minecraft:light_gray_concrete
fill 59 293 640 59 294 640 minecraft:light_gray_concrete
fill 59 293 642 59 294 642 minecraft:light_gray_concrete
fill 59 293 644 59 294 644 minecraft:light_gray_concrete
fill 60 293 605 60 294 605 minecraft:light_gray_concrete
fill 60 293 607 60 294 607 minecraft:light_gray_concrete
fill 60 293 609 60 294 609 minecraft:light_gray_concrete
fill 60 293 637 60 294 637 minecraft:light_gray_concrete
fill 60 293 639 60 294 639 minecraft:light_gray_concrete
fill 60 293 641 60 294 641 minecraft:light_gray_concrete
fill 60 293 643 60 294 643 minecraft:light_gray_concrete
fill 60 293 645 60 294 645 minecraft:light_gray_concrete
fill 61 293 606 61 294 606 minecraft:light_gray_concrete
fill 61 293 608 61 294 608 minecraft:light_gray_concrete
fill 61 293 610 61 294 610 minecraft:light_gray_concrete
fill 61 293 638 61 294 638 minecraft:light_gray_concrete
fill 61 293 640 61 294 640 minecraft:light_gray_concrete
fill 61 293 642 61 294 642 minecraft:light_gray_concrete
fill 61 293 644 61 294 644 minecraft:light_gray_concrete
fill 62 293 605 62 294 605 minecraft:light_gray_concrete
fill 62 293 607 62 294 607 minecraft:light_gray_concrete
fill 62 293 609 62 294 609 minecraft:light_gray_concrete
fill 62 293 637 62 294 637 minecraft:light_gray_concrete
fill 62 293 639 62 294 639 minecraft:light_gray_concrete
fill 62 293 641 62 294 641 minecraft:light_gray_concrete
fill 62 293 643 62 294 643 minecraft:light_gray_concrete
fill 62 293 645 62 294 645 minecraft:light_gray_concrete
fill 63 293 606 63 294 606 minecraft:light_gray_concrete
fill 63 293 608 63 294 608 minecraft:light_gray_concrete
fill 63 293 610 63 294 610 minecraft:light_gray_concrete
fill 63 293 638 63 294 638 minecraft:light_gray_concrete
fill 63 293 640 63 294 640 minecraft:light_gray_concrete
fill 63 293 642 63 294 642 minecraft:light_gray_concrete
fill 63 293 644 63 294 644 minecraft:light_gray_concrete
fill 64 293 605 64 294 605 minecraft:light_gray_concrete
fill 64 293 607 64 294 607 minecraft:light_gray_concrete
fill 64 293 609 64 294 609 minecraft:light_gray_concrete
fill 64 293 637 64 294 637 minecraft:light_gray_concrete
fill 64 293 639 64 294 639 minecraft:light_gray_concrete
fill 64 293 641 64 294 641 minecraft:light_gray_concrete
fill 64 293 643 64 294 643 minecraft:light_gray_concrete
fill 64 293 645 64 294 645 minecraft:light_gray_concrete
fill 65 293 606 65 294 606 minecraft:light_gray_concrete
fill 65 293 608 65 294 608 minecraft:light_gray_concrete
fill 65 293 610 65 294 610 minecraft:light_gray_concrete
fill 65 293 638 65 294 638 minecraft:light_gray_concrete
fill 65 293 640 65 294 640 minecraft:light_gray_concrete
fill 65 293 642 65 294 642 minecraft:light_gray_concrete
fill 65 293 644 65 294 644 minecraft:light_gray_concrete
fill 66 293 605 66 294 605 minecraft:light_gray_concrete
fill 66 293 607 66 294 607 minecraft:light_gray_concrete
fill 66 293 609 66 294 609 minecraft:light_gray_concrete
fill 66 293 637 66 294 637 minecraft:light_gray_concrete
fill 66 293 639 66 294 639 minecraft:light_gray_concrete
fill 66 293 641 66 294 641 minecraft:light_gray_concrete
fill 66 293 643 66 294 643 minecraft:light_gray_concrete
fill 66 293 645 66 294 645 minecraft:light_gray_concrete
fill 67 293 638 67 294 638 minecraft:light_gray_concrete
fill 67 293 640 67 294 640 minecraft:light_gray_concrete
fill 67 293 642 67 294 642 minecraft:light_gray_concrete
fill 67 293 644 67 294 644 minecraft:light_gray_concrete
fill 68 293 637 68 294 637 minecraft:light_gray_concrete
fill 68 293 639 68 294 639 minecraft:light_gray_concrete
fill 68 293 641 68 294 641 minecraft:light_gray_concrete
fill 68 293 643 68 294 643 minecraft:light_gray_concrete
fill 68 293 645 68 294 645 minecraft:light_gray_concrete
fill 77 293 638 77 294 638 minecraft:light_gray_concrete
fill 77 293 640 77 294 640 minecraft:light_gray_concrete
fill 77 293 642 77 294 642 minecraft:light_gray_concrete
fill 77 293 644 77 294 644 minecraft:light_gray_concrete
fill 78 293 639 78 294 639 minecraft:light_gray_concrete
fill 78 293 641 78 294 641 minecraft:light_gray_concrete
fill 78 293 643 78 294 643 minecraft:light_gray_concrete
fill 78 293 645 78 294 645 minecraft:light_gray_concrete
fill 79 293 608 79 295 608 minecraft:light_gray_concrete
fill 79 293 610 79 295 610 minecraft:light_gray_concrete
fill 79 293 612 79 295 612 minecraft:light_gray_concrete
fill 79 293 614 79 295 614 minecraft:light_gray_concrete
fill 79 293 638 79 294 638 minecraft:light_gray_concrete
fill 79 293 640 79 294 640 minecraft:light_gray_concrete
fill 79 293 642 79 294 642 minecraft:light_gray_concrete
fill 79 293 644 79 294 644 minecraft:light_gray_concrete
fill 80 293 607 80 295 607 minecraft:light_gray_concrete
fill 80 293 609 80 295 609 minecraft:light_gray_concrete
fill 80 293 611 80 295 611 minecraft:light_gray_concrete
fill 80 293 613 80 295 613 minecraft:light_gray_concrete
fill 80 293 615 80 295 615 minecraft:light_gray_concrete
fill 80 293 639 80 294 639 minecraft:light_gray_concrete
fill 80 293 641 80 294 641 minecraft:light_gray_concrete
fill 80 293 643 80 294 643 minecraft:light_gray_concrete
fill 80 293 645 80 294 645 minecraft:light_gray_concrete
fill 81 293 608 81 295 608 minecraft:light_gray_concrete
fill 81 293 610 81 295 610 minecraft:light_gray_concrete
fill 81 293 612 81 295 612 minecraft:light_gray_concrete
fill 81 293 614 81 295 614 minecraft:light_gray_concrete
fill 81 293 638 81 294 638 minecraft:light_gray_concrete
fill 81 293 640 81 294 640 minecraft:light_gray_concrete
fill 81 293 642 81 294 642 minecraft:light_gray_concrete
fill 81 293 644 81 294 644 minecraft:light_gray_concrete
fill 82 293 607 82 295 607 minecraft:light_gray_concrete
fill 82 293 609 82 295 609 minecraft:light_gray_concrete
fill 82 293 611 82 295 611 minecraft:light_gray_concrete
fill 82 293 613 82 295 613 minecraft:light_gray_concrete
fill 82 293 615 82 295 615 minecraft:light_gray_concrete
fill 82 293 639 82 294 639 minecraft:light_gray_concrete
fill 82 293 641 82 294 641 minecraft:light_gray_concrete
fill 82 293 643 82 294 643 minecraft:light_gray_concrete
fill 82 293 645 82 294 645 minecraft:light_gray_concrete
fill 83 293 608 83 295 608 minecraft:light_gray_concrete
fill 83 293 610 83 295 610 minecraft:light_gray_concrete
fill 83 293 612 83 295 612 minecraft:light_gray_concrete
fill 83 293 614 83 295 614 minecraft:light_gray_concrete
fill 83 293 638 83 294 638 minecraft:light_gray_concrete
fill 83 293 640 83 294 640 minecraft:light_gray_concrete
fill 83 293 642 83 294 642 minecraft:light_gray_concrete
fill 83 293 644 83 294 644 minecraft:light_gray_concrete
fill 84 293 607 84 295 607 minecraft:light_gray_concrete
fill 84 293 609 84 295 609 minecraft:light_gray_concrete
fill 84 293 611 84 295 611 minecraft:light_gray_concrete
fill 84 293 613 84 295 613 minecraft:light_gray_concrete
fill 84 293 615 84 295 615 minecraft:light_gray_concrete
fill 84 293 639 84 294 639 minecraft:light_gray_concrete
fill 84 293 641 84 294 641 minecraft:light_gray_concrete
fill 84 293 643 84 294 643 minecraft:light_gray_concrete
fill 84 293 645 84 294 645 minecraft:light_gray_concrete
fill 85 293 608 85 295 608 minecraft:light_gray_concrete
fill 85 293 610 85 295 610 minecraft:light_gray_concrete
fill 85 293 612 85 295 612 minecraft:light_gray_concrete
fill 85 293 614 85 295 614 minecraft:light_gray_concrete
fill 85 293 638 85 294 638 minecraft:light_gray_concrete
fill 85 293 640 85 294 640 minecraft:light_gray_concrete
fill 85 293 642 85 294 642 minecraft:light_gray_concrete
fill 85 293 644 85 294 644 minecraft:light_gray_concrete
fill 86 293 607 86 295 607 minecraft:light_gray_concrete
fill 86 293 609 86 295 609 minecraft:light_gray_concrete
fill 86 293 611 86 295 611 minecraft:light_gray_concrete
fill 86 293 613 86 295 613 minecraft:light_gray_concrete
fill 86 293 615 86 295 615 minecraft:light_gray_concrete
fill 87 293 608 87 295 608 minecraft:light_gray_concrete
fill 87 293 610 87 295 610 minecraft:light_gray_concrete
fill 87 293 612 87 295 612 minecraft:light_gray_concrete
fill 87 293 614 87 295 614 minecraft:light_gray_concrete
fill 88 293 607 88 300 607 minecraft:light_gray_concrete
fill 88 293 609 88 295 609 minecraft:light_gray_concrete
fill 88 293 611 88 295 611 minecraft:light_gray_concrete
fill 88 293 613 88 295 613 minecraft:light_gray_concrete
fill 88 293 615 88 300 615 minecraft:light_gray_concrete
fill 48 294 605 48 295 610 minecraft:light_gray_concrete
fill 48 294 613 49 294 618 minecraft:light_gray_concrete
fill 48 294 621 49 294 626 minecraft:light_gray_concrete
fill 48 294 629 49 294 634 minecraft:light_gray_concrete
fill 48 294 637 49 294 642 minecraft:light_gray_concrete
fill 48 294 645 53 295 645 minecraft:light_gray_concrete
fill 49 294 606 49 294 612 minecraft:light_gray_concrete
fill 49 294 619 49 294 620 minecraft:light_gray_concrete
fill 49 294 627 49 294 628 minecraft:light_gray_concrete
fill 49 294 635 49 294 636 minecraft:light_gray_concrete
fill 49 294 643 49 294 644 minecraft:light_gray_concrete
fill 50 294 606 53 294 606 minecraft:light_gray_concrete
fill 50 294 644 55 294 644 minecraft:light_gray_concrete
fill 51 294 605 53 295 605 minecraft:light_gray_concrete
fill 67 294 605 72 294 606 minecraft:light_gray_concrete
fill 69 294 644 69 294 645 minecraft:light_gray_concrete
fill 70 294 644 76 294 644 minecraft:light_gray_concrete
fill 72 294 645 76 295 645 minecraft:light_gray_concrete
fill 73 294 606 87 294 606 minecraft:light_gray_concrete
fill 75 294 605 80 295 605 minecraft:light_gray_concrete
fill 83 294 605 88 295 605 minecraft:light_gray_concrete
fill 86 294 644 88 294 644 minecraft:light_gray_concrete
fill 87 294 616 87 294 643 minecraft:light_gray_concrete
fill 88 294 616 88 295 621 minecraft:light_gray_concrete
fill 88 294 624 88 295 629 minecraft:light_gray_concrete
fill 88 294 632 88 295 637 minecraft:light_gray_concrete
fill 88 294 640 88 295 643 minecraft:light_gray_concrete
fill 88 294 645 88 295 645 minecraft:light_gray_concrete
fill 48 295 613 48 295 618 minecraft:light_gray_concrete
fill 48 295 621 48 295 626 minecraft:light_gray_concrete
fill 48 295 629 48 295 634 minecraft:light_gray_concrete
fill 48 295 637 48 295 642 minecraft:light_gray_concrete
setblock 54 295 605 minecraft:sea_lantern
setblock 54 295 607 minecraft:sea_lantern
setblock 54 295 609 minecraft:sea_lantern
setblock 55 295 606 minecraft:sea_lantern
setblock 55 295 608 minecraft:sea_lantern
setblock 55 295 610 minecraft:sea_lantern
setblock 56 295 605 minecraft:sea_lantern
setblock 56 295 607 minecraft:sea_lantern
setblock 56 295 609 minecraft:sea_lantern
setblock 56 295 637 minecraft:sea_lantern
setblock 56 295 639 minecraft:sea_lantern
setblock 56 295 641 minecraft:sea_lantern
setblock 56 295 643 minecraft:sea_lantern
setblock 56 295 645 minecraft:sea_lantern
setblock 57 295 606 minecraft:sea_lantern
setblock 57 295 608 minecraft:sea_lantern
setblock 57 295 610 minecraft:sea_lantern
setblock 57 295 638 minecraft:sea_lantern
setblock 57 295 640 minecraft:sea_lantern
setblock 57 295 642 minecraft:sea_lantern
setblock 57 295 644 minecraft:sea_lantern
setblock 58 295 605 minecraft:sea_lantern
setblock 58 295 607 minecraft:sea_lantern
setblock 58 295 609 minecraft:sea_lantern
setblock 58 295 637 minecraft:sea_lantern
setblock 58 295 639 minecraft:sea_lantern
setblock 58 295 641 minecraft:sea_lantern
setblock 58 295 643 minecraft:sea_lantern
setblock 58 295 645 minecraft:sea_lantern
setblock 59 295 606 minecraft:sea_lantern
setblock 59 295 608 minecraft:sea_lantern
setblock 59 295 610 minecraft:sea_lantern
setblock 59 295 638 minecraft:sea_lantern
setblock 59 295 640 minecraft:sea_lantern
setblock 59 295 642 minecraft:sea_lantern
setblock 59 295 644 minecraft:sea_lantern
setblock 60 295 605 minecraft:sea_lantern
setblock 60 295 607 minecraft:sea_lantern
setblock 60 295 609 minecraft:sea_lantern
setblock 60 295 637 minecraft:sea_lantern
setblock 60 295 639 minecraft:sea_lantern
setblock 60 295 641 minecraft:sea_lantern
setblock 60 295 643 minecraft:sea_lantern
setblock 60 295 645 minecraft:sea_lantern
setblock 61 295 606 minecraft:sea_lantern
setblock 61 295 608 minecraft:sea_lantern
setblock 61 295 610 minecraft:sea_lantern
setblock 61 295 638 minecraft:sea_lantern
setblock 61 295 640 minecraft:sea_lantern
setblock 61 295 642 minecraft:sea_lantern
setblock 61 295 644 minecraft:sea_lantern
setblock 62 295 605 minecraft:sea_lantern
setblock 62 295 607 minecraft:sea_lantern
setblock 62 295 609 minecraft:sea_lantern
setblock 62 295 637 minecraft:sea_lantern
setblock 62 295 639 minecraft:sea_lantern
setblock 62 295 641 minecraft:sea_lantern
setblock 62 295 643 minecraft:sea_lantern
setblock 62 295 645 minecraft:sea_lantern
setblock 63 295 606 minecraft:sea_lantern
setblock 63 295 608 minecraft:sea_lantern
setblock 63 295 610 minecraft:sea_lantern
setblock 63 295 638 minecraft:sea_lantern
setblock 63 295 640 minecraft:sea_lantern
setblock 63 295 642 minecraft:sea_lantern
setblock 63 295 644 minecraft:sea_lantern
setblock 64 295 605 minecraft:sea_lantern
setblock 64 295 607 minecraft:sea_lantern
setblock 64 295 609 minecraft:sea_lantern
setblock 64 295 637 minecraft:sea_lantern
setblock 64 295 639 minecraft:sea_lantern
setblock 64 295 641 minecraft:sea_lantern
setblock 64 295 643 minecraft:sea_lantern
setblock 64 295 645 minecraft:sea_lantern
setblock 65 295 606 minecraft:sea_lantern
setblock 65 295 608 minecraft:sea_lantern
setblock 65 295 610 minecraft:sea_lantern
setblock 65 295 638 minecraft:sea_lantern
setblock 65 295 640 minecraft:sea_lantern
setblock 65 295 642 minecraft:sea_lantern
setblock 65 295 644 minecraft:sea_lantern
setblock 66 295 605 minecraft:sea_lantern
setblock 66 295 607 minecraft:sea_lantern
setblock 66 295 609 minecraft:sea_lantern
setblock 66 295 637 minecraft:sea_lantern
setblock 66 295 639 minecraft:sea_lantern
setblock 66 295 641 minecraft:sea_lantern
setblock 66 295 643 minecraft:sea_lantern
setblock 66 295 645 minecraft:sea_lantern
fill 67 295 605 72 295 605 minecraft:light_gray_concrete
setblock 67 295 638 minecraft:sea_lantern
setblock 67 295 640 minecraft:sea_lantern
setblock 67 295 642 minecraft:sea_lantern
setblock 67 295 644 minecraft:sea_lantern
setblock 68 295 637 minecraft:sea_lantern
setblock 68 295 639 minecraft:sea_lantern
setblock 68 295 641 minecraft:sea_lantern
setblock 68 295 643 minecraft:sea_lantern
setblock 68 295 645 minecraft:sea_lantern
setblock 69 295 645 minecraft:light_gray_concrete
setblock 77 295 638 minecraft:sea_lantern
setblock 77 295 640 minecraft:sea_lantern
setblock 77 295 642 minecraft:sea_lantern
setblock 77 295 644 minecraft:sea_lantern
setblock 78 295 639 minecraft:sea_lantern
setblock 78 295 641 minecraft:sea_lantern
setblock 78 295 643 minecraft:sea_lantern
setblock 78 295 645 minecraft:sea_lantern
setblock 79 295 638 minecraft:sea_lantern
setblock 79 295 640 minecraft:sea_lantern
setblock 79 295 642 minecraft:sea_lantern
setblock 79 295 644 minecraft:sea_lantern
setblock 80 295 639 minecraft:sea_lantern
setblock 80 295 641 minecraft:sea_lantern
setblock 80 295 643 minecraft:sea_lantern
setblock 80 295 645 minecraft:sea_lantern
setblock 81 295 638 minecraft:sea_lantern
setblock 81 295 640 minecraft:sea_lantern
setblock 81 295 642 minecraft:sea_lantern
setblock 81 295 644 minecraft:sea_lantern
setblock 82 295 639 minecraft:sea_lantern
setblock 82 295 641 minecraft:sea_lantern
setblock 82 295 643 minecraft:sea_lantern
setblock 82 295 645 minecraft:sea_lantern
setblock 83 295 638 minecraft:sea_lantern
setblock 83 295 640 minecraft:sea_lantern
setblock 83 295 642 minecraft:sea_lantern
setblock 83 295 644 minecraft:sea_lantern
setblock 84 295 639 minecraft:sea_lantern
setblock 84 295 641 minecraft:sea_lantern
setblock 84 295 643 minecraft:sea_lantern
setblock 84 295 645 minecraft:sea_lantern
setblock 85 295 638 minecraft:sea_lantern
setblock 85 295 640 minecraft:sea_lantern
setblock 85 295 642 minecraft:sea_lantern
setblock 85 295 644 minecraft:sea_lantern
setblock 88 295 644 minecraft:light_gray_concrete
fill 54 296 605 54 297 605 minecraft:light_gray_concrete
fill 54 296 607 54 297 607 minecraft:light_gray_concrete
fill 54 296 609 54 297 609 minecraft:light_gray_concrete
fill 55 296 606 55 297 606 minecraft:light_gray_concrete
fill 55 296 608 55 297 608 minecraft:light_gray_concrete
fill 55 296 610 55 297 610 minecraft:light_gray_concrete
fill 56 296 605 56 297 605 minecraft:light_gray_concrete
fill 56 296 607 56 297 607 minecraft:light_gray_concrete
fill 56 296 609 56 297 609 minecraft:light_gray_concrete
fill 56 296 637 56 297 637 minecraft:light_gray_concrete
fill 56 296 639 56 297 639 minecraft:light_gray_concrete
fill 56 296 641 56 297 641 minecraft:light_gray_concrete
fill 56 296 643 56 297 643 minecraft:light_gray_concrete
fill 56 296 645 56 297 645 minecraft:light_gray_concrete
fill 57 296 606 57 297 606 minecraft:light_gray_concrete
fill 57 296 608 57 297 608 minecraft:light_gray_concrete
fill 57 296 610 57 297 610 minecraft:light_gray_concrete
fill 57 296 638 57 297 638 minecraft:light_gray_concrete
fill 57 296 640 57 297 640 minecraft:light_gray_concrete
fill 57 296 642 57 297 642 minecraft:light_gray_concrete
fill 57 296 644 57 297 644 minecraft:light_gray_concrete
fill 58 296 605 58 297 605 minecraft:light_gray_concrete
fill 58 296 607 58 297 607 minecraft:light_gray_concrete
fill 58 296 609 58 297 609 minecraft:light_gray_concrete
fill 58 296 637 58 297 637 minecraft:light_gray_concrete
fill 58 296 639 58 297 639 minecraft:light_gray_concrete
fill 58 296 641 58 297 641 minecraft:light_gray_concrete
fill 58 296 643 58 297 643 minecraft:light_gray_concrete
fill 58 296 645 58 297 645 minecraft:light_gray_concrete
fill 59 296 606 59 297 606 minecraft:light_gray_concrete
fill 59 296 608 59 297 608 minecraft:light_gray_concrete
fill 59 296 610 59 297 610 minecraft:light_gray_concrete
fill 59 296 638 59 297 638 minecraft:light_gray_concrete
fill 59 296 640 59 297 640 minecraft:light_gray_concrete
fill 59 296 642 59 297 642 minecraft:light_gray_concrete
fill 59 296 644 59 297 644 minecraft:light_gray_concrete
fill 60 296 605 60 297 605 minecraft:light_gray_concrete
fill 60 296 607 60 297 607 minecraft:light_gray_concrete
fill 60 296 609 60 297 609 minecraft:light_gray_concrete
fill 60 296 637 60 297 637 minecraft:light_gray_concrete
fill 60 296 639 60 297 639 minecraft:light_gray_concrete
fill 60 296 641 60 297 641 minecraft:light_gray_concrete
fill 60 296 643 60 297 643 minecraft:light_gray_concrete
fill 60 296 645 60 297 645 minecraft:light_gray_concrete
fill 61 296 606 61 297 606 minecraft:light_gray_concrete
fill 61 296 608 61 297 608 minecraft:light_gray_concrete
fill 61 296 610 61 297 610 minecraft:light_gray_concrete
fill 61 296 638 61 297 638 minecraft:light_gray_concrete
fill 61 296 640 61 297 640 minecraft:light_gray_concrete
fill 61 296 642 61 297 642 minecraft:light_gray_concrete
fill 61 296 644 61 297 644 minecraft:light_gray_concrete
fill 62 296 605 62 297 605 minecraft:light_gray_concrete
fill 62 296 607 62 297 607 minecraft:light_gray_concrete
fill 62 296 609 62 297 609 minecraft:light_gray_concrete
fill 62 296 637 62 297 637 minecraft:light_gray_concrete
fill 62 296 639 62 297 639 minecraft:light_gray_concrete
fill 62 296 641 62 297 641 minecraft:light_gray_concrete
fill 62 296 643 62 297 643 minecraft:light_gray_concrete
fill 62 296 645 62 297 645 minecraft:light_gray_concrete
fill 63 296 606 63 297 606 minecraft:light_gray_concrete
fill 63 296 608 63 297 608 minecraft:light_gray_concrete
fill 63 296 610 63 297 610 minecraft:light_gray_concrete
fill 63 296 638 63 297 638 minecraft:light_gray_concrete
fill 63 296 640 63 297 640 minecraft:light_gray_concrete
fill 63 296 642 63 297 642 minecraft:light_gray_concrete
fill 63 296 644 63 297 644 minecraft:light_gray_concrete
fill 64 296 605 64 297 605 minecraft:light_gray_concrete
fill 64 296 607 64 297 607 minecraft:light_gray_concrete
fill 64 296 609 64 297 609 minecraft:light_gray_concrete
fill 64 296 637 64 297 637 minecraft:light_gray_concrete
fill 64 296 639 64 297 639 minecraft:light_gray_concrete
fill 64 296 641 64 297 641 minecraft:light_gray_concrete
fill 64 296 643 64 297 643 minecraft:light_gray_concrete
fill 64 296 645 64 297 645 minecraft:light_gray_concrete
fill 65 296 606 65 297 606 minecraft:light_gray_concrete
fill 65 296 608 65 297 608 minecraft:light_gray_concrete
fill 65 296 610 65 297 610 minecraft:light_gray_concrete
fill 65 296 638 65 297 638 minecraft:light_gray_concrete
fill 65 296 640 65 297 640 minecraft:light_gray_concrete
fill 65 296 642 65 297 642 minecraft:light_gray_concrete
fill 65 296 644 65 297 644 minecraft:light_gray_concrete
fill 66 296 605 66 297 605 minecraft:light_gray_concrete
fill 66 296 607 66 297 607 minecraft:light_gray_concrete
fill 66 296 609 66 297 609 minecraft:light_gray_concrete
fill 66 296 637 66 297 637 minecraft:light_gray_concrete
fill 66 296 639 66 297 639 minecraft:light_gray_concrete
fill 66 296 641 66 297 641 minecraft:light_gray_concrete
fill 66 296 643 66 297 643 minecraft:light_gray_concrete
fill 66 296 645 66 297 645 minecraft:light_gray_concrete
fill 67 296 638 67 297 638 minecraft:light_gray_concrete
fill 67 296 640 67 297 640 minecraft:light_gray_concrete
fill 67 296 642 67 297 642 minecraft:light_gray_concrete
fill 67 296 644 67 297 644 minecraft:light_gray_concrete
fill 68 296 637 68 297 637 minecraft:light_gray_concrete
fill 68 296 639 68 297 639 minecraft:light_gray_concrete
fill 68 296 641 68 297 641 minecraft:light_gray_concrete
fill 68 296 643 68 297 643 minecraft:light_gray_concrete
fill 68 296 645 68 297 645 minecraft:light_gray_concrete
fill 77 296 638 77 297 638 minecraft:light_gray_concrete
fill 77 296 640 77 297 640 minecraft:light_gray_concrete
fill 77 296 642 77 297 642 minecraft:light_gray_concrete
fill 77 296 644 77 297 644 minecraft:light_gray_concrete
fill 78 296 639 78 297 639 minecraft:light_gray_concrete
fill 78 296 641 78 297 641 minecraft:light_gray_concrete
fill 78 296 643 78 297 643 minecraft:light_gray_concrete
fill 78 296 645 78 297 645 minecraft:light_gray_concrete
fill 79 296 638 79 297 638 minecraft:light_gray_concrete
fill 79 296 640 79 297 640 minecraft:light_gray_concrete
fill 79 296 642 79 297 642 minecraft:light_gray_concrete
fill 79 296 644 79 297 644 minecraft:light_gray_concrete
fill 80 296 639 80 297 639 minecraft:light_gray_concrete
fill 80 296 641 80 297 641 minecraft:light_gray_concrete
fill 80 296 643 80 297 643 minecraft:light_gray_concrete
fill 80 296 645 80 297 645 minecraft:light_gray_concrete
fill 81 296 638 81 297 638 minecraft:light_gray_concrete
fill 81 296 640 81 297 640 minecraft:light_gray_concrete
fill 81 296 642 81 297 642 minecraft:light_gray_concrete
fill 81 296 644 81 297 644 minecraft:light_gray_concrete
fill 82 296 639 82 297 639 minecraft:light_gray_concrete
fill 82 296 641 82 297 641 minecraft:light_gray_concrete
fill 82 296 643 82 297 643 minecraft:light_gray_concrete
fill 82 296 645 82 297 645 minecraft:light_gray_concrete
fill 83 296 638 83 297 638 minecraft:light_gray_concrete
fill 83 296 640 83 297 640 minecraft:light_gray_concrete
fill 83 296 642 83 297 642 minecraft:light_gray_concrete
fill 83 296 644 83 297 644 minecraft:light_gray_concrete
fill 84 296 639 84 297 639 minecraft:light_gray_concrete
fill 84 296 641 84 297 641 minecraft:light_gray_concrete
fill 84 296 643 84 297 643 minecraft:light_gray_concrete
fill 84 296 645 84 297 645 minecraft:light_gray_concrete
fill 85 296 638 85 297 638 minecraft:light_gray_concrete
fill 85 296 640 85 297 640 minecraft:light_gray_concrete
fill 85 296 642 85 297 642 minecraft:light_gray_concrete
fill 85 296 644 85 297 644 minecraft:light_gray_concrete
fill 54 297 634 56 298 634 minecraft:gray_concrete
fill 55 297 633 56 298 633 minecraft:gray_concrete
fill 80 297 615 80 298 615 minecraft:magenta_concrete
fill 47 298 609 47 300 609 minecraft:sea_lantern
fill 47 298 617 47 300 617 minecraft:sea_lantern
fill 47 298 625 47 300 625 minecraft:sea_lantern
fill 47 298 633 47 300 633 minecraft:sea_lantern
fill 47 298 641 47 300 641 minecraft:sea_lantern
fill 50 298 646 50 300 646 minecraft:sea_lantern
fill 54 298 604 54 298 605 minecraft:sea_lantern
setblock 54 298 607 minecraft:sea_lantern
setblock 54 298 609 minecraft:sea_lantern
setblock 55 298 606 minecraft:sea_lantern
setblock 55 298 608 minecraft:sea_lantern
setblock 55 298 610 minecraft:sea_lantern
setblock 56 298 605 minecraft:sea_lantern
setblock 56 298 607 minecraft:sea_lantern
setblock 56 298 609 minecraft:sea_lantern
fill 56 298 635 57 299 635 minecraft:magenta_concrete
setblock 56 298 637 minecraft:sea_lantern
setblock 56 298 639 minecraft:sea_lantern
setblock 56 298 641 minecraft:sea_lantern
setblock 56 298 643 minecraft:sea_lantern
setblock 56 298 645 minecraft:sea_lantern
setblock 57 298 606 minecraft:sea_lantern
setblock 57 298 608 minecraft:sea_lantern
setblock 57 298 610 minecraft:sea_lantern
fill 57 298 634 57 299 634 minecraft:magenta_concrete
setblock 57 298 638 minecraft:sea_lantern
setblock 57 298 640 minecraft:sea_lantern
setblock 57 298 642 minecraft:sea_lantern
setblock 57 298 644 minecraft:sea_lantern
setblock 58 298 605 minecraft:sea_lantern
setblock 58 298 607 minecraft:sea_lantern
setblock 58 298 609 minecraft:sea_lantern
setblock 58 298 637 minecraft:sea_lantern
setblock 58 298 639 minecraft:sea_lantern
setblock 58 298 641 minecraft:sea_lantern
setblock 58 298 643 minecraft:sea_lantern
fill 58 298 645 58 298 646 minecraft:sea_lantern
setblock 59 298 606 minecraft:sea_lantern
setblock 59 298 608 minecraft:sea_lantern
setblock 59 298 610 minecraft:sea_lantern
setblock 59 298 638 minecraft:sea_lantern
setblock 59 298 640 minecraft:sea_lantern
setblock 59 298 642 minecraft:sea_lantern
setblock 59 298 644 minecraft:sea_lantern
setblock 60 298 605 minecraft:sea_lantern
setblock 60 298 607 minecraft:sea_lantern
setblock 60 298 609 minecraft:sea_lantern
setblock 60 298 637 minecraft:sea_lantern
setblock 60 298 639 minecraft:sea_lantern
setblock 60 298 641 minecraft:sea_lantern
setblock 60 298 643 minecraft:sea_lantern
setblock 60 298 645 minecraft:sea_lantern
setblock 61 298 606 minecraft:sea_lantern
setblock 61 298 608 minecraft:sea_lantern
setblock 61 298 610 minecraft:sea_lantern
setblock 61 298 638 minecraft:sea_lantern
setblock 61 298 640 minecraft:sea_lantern
setblock 61 298 642 minecraft:sea_lantern
setblock 61 298 644 minecraft:sea_lantern
fill 62 298 604 62 298 605 minecraft:sea_lantern
setblock 62 298 607 minecraft:sea_lantern
setblock 62 298 609 minecraft:sea_lantern
setblock 62 298 637 minecraft:sea_lantern
setblock 62 298 639 minecraft:sea_lantern
setblock 62 298 641 minecraft:sea_lantern
setblock 62 298 643 minecraft:sea_lantern
setblock 62 298 645 minecraft:sea_lantern
setblock 63 298 606 minecraft:sea_lantern
setblock 63 298 608 minecraft:sea_lantern
setblock 63 298 610 minecraft:sea_lantern
setblock 63 298 638 minecraft:sea_lantern
setblock 63 298 640 minecraft:sea_lantern
setblock 63 298 642 minecraft:sea_lantern
setblock 63 298 644 minecraft:sea_lantern
setblock 64 298 605 minecraft:sea_lantern
setblock 64 298 607 minecraft:sea_lantern
setblock 64 298 609 minecraft:sea_lantern
setblock 64 298 637 minecraft:sea_lantern
setblock 64 298 639 minecraft:sea_lantern
setblock 64 298 641 minecraft:sea_lantern
setblock 64 298 643 minecraft:sea_lantern
setblock 64 298 645 minecraft:sea_lantern
setblock 65 298 606 minecraft:sea_lantern
setblock 65 298 608 minecraft:sea_lantern
setblock 65 298 610 minecraft:sea_lantern
setblock 65 298 638 minecraft:sea_lantern
setblock 65 298 640 minecraft:sea_lantern
setblock 65 298 642 minecraft:sea_lantern
setblock 65 298 644 minecraft:sea_lantern
setblock 66 298 605 minecraft:sea_lantern
setblock 66 298 607 minecraft:sea_lantern
setblock 66 298 609 minecraft:sea_lantern
setblock 66 298 637 minecraft:sea_lantern
setblock 66 298 639 minecraft:sea_lantern
setblock 66 298 641 minecraft:sea_lantern
setblock 66 298 643 minecraft:sea_lantern
fill 66 298 645 66 298 646 minecraft:sea_lantern
setblock 67 298 638 minecraft:sea_lantern
setblock 67 298 640 minecraft:sea_lantern
setblock 67 298 642 minecraft:sea_lantern
setblock 67 298 644 minecraft:sea_lantern
setblock 68 298 637 minecraft:sea_lantern
setblock 68 298 639 minecraft:sea_lantern
setblock 68 298 641 minecraft:sea_lantern
setblock 68 298 643 minecraft:sea_lantern
setblock 68 298 645 minecraft:sea_lantern
fill 70 298 604 70 300 604 minecraft:sea_lantern
fill 74 298 646 74 300 646 minecraft:sea_lantern
setblock 77 298 638 minecraft:sea_lantern
setblock 77 298 640 minecraft:sea_lantern
setblock 77 298 642 minecraft:sea_lantern
setblock 77 298 644 minecraft:sea_lantern
fill 78 298 604 78 300 604 minecraft:sea_lantern
setblock 78 298 639 minecraft:sea_lantern
setblock 78 298 641 minecraft:sea_lantern
setblock 78 298 643 minecraft:sea_lantern
setblock 78 298 645 minecraft:sea_lantern
setblock 79 298 638 minecraft:sea_lantern
setblock 79 298 640 minecraft:sea_lantern
setblock 79 298 642 minecraft:sea_lantern
setblock 79 298 644 minecraft:sea_lantern
setblock 80 298 639 minecraft:sea_lantern
setblock 80 298 641 minecraft:sea_lantern
setblock 80 298 643 minecraft:sea_lantern
setblock 80 298 645 minecraft:sea_lantern
setblock 81 298 638 minecraft:sea_lantern
setblock 81 298 640 minecraft:sea_lantern
setblock 81 298 642 minecraft:sea_lantern
setblock 81 298 644 minecraft:sea_lantern
setblock 82 298 639 minecraft:sea_lantern
setblock 82 298 641 minecraft:sea_lantern
setblock 82 298 643 minecraft:sea_lantern
fill 82 298 645 82 298 646 minecraft:sea_lantern
setblock 83 298 638 minecraft:sea_lantern
setblock 83 298 640 minecraft:sea_lantern
setblock 83 298 642 minecraft:sea_lantern
setblock 83 298 644 minecraft:sea_lantern
setblock 84 298 639 minecraft:sea_lantern
setblock 84 298 641 minecraft:sea_lantern
setblock 84 298 643 minecraft:sea_lantern
setblock 84 298 645 minecraft:sea_lantern
setblock 85 298 638 minecraft:sea_lantern
setblock 85 298 640 minecraft:sea_lantern
setblock 85 298 642 minecraft:sea_lantern
setblock 85 298 644 minecraft:sea_lantern
fill 86 298 604 86 300 604 minecraft:sea_lantern
fill 89 298 609 89 300 609 minecraft:sea_lantern
fill 89 298 617 89 300 617 minecraft:sea_lantern
fill 89 298 625 89 300 625 minecraft:sea_lantern
fill 89 298 633 89 300 633 minecraft:sea_lantern
fill 89 298 641 89 300 641 minecraft:sea_lantern
setblock 50 299 607 minecraft:light[level=14]
setblock 50 299 615 minecraft:light[level=14]
setblock 50 299 623 minecraft:light[level=14]
setblock 50 299 631 minecraft:light[level=14]
setblock 50 299 639 minecraft:light[level=14]
fill 54 299 604 54 300 604 minecraft:sea_lantern
fill 54 299 605 54 300 605 minecraft:light_gray_concrete
fill 54 299 607 54 300 607 minecraft:light_gray_concrete
fill 54 299 609 54 300 609 minecraft:light_gray_concrete
fill 55 299 606 55 300 606 minecraft:light_gray_concrete
fill 55 299 608 55 300 608 minecraft:light_gray_concrete
fill 55 299 610 55 300 610 minecraft:light_gray_concrete
fill 56 299 605 56 300 605 minecraft:light_gray_concrete
fill 56 299 607 56 300 607 minecraft:light_gray_concrete
fill 56 299 609 56 300 609 minecraft:light_gray_concrete
fill 56 299 633 56 299 634 minecraft:magenta_concrete
fill 56 299 637 56 300 637 minecraft:light_gray_concrete
fill 56 299 639 56 300 639 minecraft:light_gray_concrete
fill 56 299 641 56 300 641 minecraft:light_gray_concrete
fill 56 299 643 56 300 643 minecraft:light_gray_concrete
fill 56 299 645 56 300 645 minecraft:light_gray_concrete
fill 57 299 606 57 300 606 minecraft:light_gray_concrete
fill 57 299 608 57 300 608 minecraft:light_gray_concrete
fill 57 299 610 57 300 610 minecraft:light_gray_concrete
fill 57 299 638 57 300 638 minecraft:light_gray_concrete
fill 57 299 640 57 300 640 minecraft:light_gray_concrete
fill 57 299 642 57 300 642 minecraft:light_gray_concrete
fill 57 299 644 57 300 644 minecraft:light_gray_concrete
fill 58 299 605 58 300 605 minecraft:light_gray_concrete
fill 58 299 607 58 300 607 minecraft:light_gray_concrete
fill 58 299 609 58 300 609 minecraft:light_gray_concrete
setblock 58 299 615 minecraft:light[level=14]
setblock 58 299 623 minecraft:light[level=14]
setblock 58 299 631 minecraft:light[level=14]
fill 58 299 637 58 300 637 minecraft:light_gray_concrete
fill 58 299 639 58 300 639 minecraft:light_gray_concrete
fill 58 299 641 58 300 641 minecraft:light_gray_concrete
fill 58 299 643 58 300 643 minecraft:light_gray_concrete
fill 58 299 645 58 300 645 minecraft:light_gray_concrete
fill 58 299 646 58 300 646 minecraft:sea_lantern
fill 59 299 606 59 300 606 minecraft:light_gray_concrete
fill 59 299 608 59 300 608 minecraft:light_gray_concrete
fill 59 299 610 59 300 610 minecraft:light_gray_concrete
fill 59 299 638 59 300 638 minecraft:light_gray_concrete
fill 59 299 640 59 300 640 minecraft:light_gray_concrete
fill 59 299 642 59 300 642 minecraft:light_gray_concrete
fill 59 299 644 59 300 644 minecraft:light_gray_concrete
fill 60 299 605 60 300 605 minecraft:light_gray_concrete
fill 60 299 607 60 300 607 minecraft:light_gray_concrete
fill 60 299 609 60 300 609 minecraft:light_gray_concrete
fill 60 299 637 60 300 637 minecraft:light_gray_concrete
fill 60 299 639 60 300 639 minecraft:light_gray_concrete
fill 60 299 641 60 300 641 minecraft:light_gray_concrete
fill 60 299 643 60 300 643 minecraft:light_gray_concrete
fill 60 299 645 60 300 645 minecraft:light_gray_concrete
fill 61 299 606 61 300 606 minecraft:light_gray_concrete
fill 61 299 608 61 300 608 minecraft:light_gray_concrete
fill 61 299 610 61 300 610 minecraft:light_gray_concrete
fill 61 299 638 61 300 638 minecraft:light_gray_concrete
fill 61 299 640 61 300 640 minecraft:light_gray_concrete
fill 61 299 642 61 300 642 minecraft:light_gray_concrete
fill 61 299 644 61 300 644 minecraft:light_gray_concrete
fill 62 299 604 62 300 604 minecraft:sea_lantern
schedule function dropper:buildpart/145_5 1t
