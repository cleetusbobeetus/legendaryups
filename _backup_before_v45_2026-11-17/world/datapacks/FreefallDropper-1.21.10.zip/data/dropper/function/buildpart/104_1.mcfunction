fill 399 162 434 399 163 434 minecraft:bone_block
fill 399 162 442 399 163 442 minecraft:bone_block
fill 402 162 423 402 163 423 minecraft:polished_blackstone
fill 402 162 434 402 163 434 minecraft:bone_block
fill 402 162 442 402 163 442 minecraft:bone_block
fill 405 162 434 405 163 434 minecraft:bone_block
fill 405 162 442 405 163 442 minecraft:bone_block
fill 410 162 434 410 163 434 minecraft:polished_blackstone
fill 410 162 449 410 163 449 minecraft:polished_blackstone
setblock 411 162 441 minecraft:bone_block
fill 411 162 450 411 163 450 minecraft:polished_blackstone
fill 382 163 420 382 164 420 minecraft:polished_blackstone
fill 382 163 436 382 164 436 minecraft:polished_blackstone
fill 382 163 438 382 164 438 minecraft:polished_blackstone
fill 385 163 438 396 164 438 minecraft:bone_block
fill 387 163 435 387 163 436 minecraft:bone_block
fill 387 163 440 387 163 441 minecraft:bone_block
fill 390 163 435 390 163 436 minecraft:bone_block
fill 390 163 440 390 163 441 minecraft:bone_block
fill 393 163 435 393 163 436 minecraft:bone_block
fill 393 163 440 393 163 441 minecraft:bone_block
fill 396 163 435 396 163 436 minecraft:bone_block
fill 396 163 440 396 163 441 minecraft:bone_block
fill 399 163 435 399 163 436 minecraft:bone_block
fill 399 163 438 405 164 438 minecraft:bone_block
fill 399 163 440 399 163 441 minecraft:bone_block
fill 402 163 422 402 164 422 minecraft:polished_blackstone
fill 402 163 435 402 163 436 minecraft:bone_block
fill 402 163 440 402 163 441 minecraft:bone_block
fill 405 163 435 405 163 436 minecraft:bone_block
fill 405 163 440 405 163 441 minecraft:bone_block
fill 411 163 434 411 164 434 minecraft:polished_blackstone
fill 411 163 451 411 164 451 minecraft:polished_blackstone
setblock 379 164 419 minecraft:light[level=12]
setblock 379 164 427 minecraft:light[level=12]
setblock 379 164 435 minecraft:light[level=12]
setblock 379 164 443 minecraft:light[level=12]
setblock 379 164 451 minecraft:light[level=12]
fill 381 164 420 381 165 420 minecraft:polished_blackstone
fill 381 164 436 381 165 436 minecraft:polished_blackstone
fill 381 164 438 381 165 438 minecraft:polished_blackstone
setblock 387 164 419 minecraft:light[level=12]
setblock 387 164 427 minecraft:light[level=12]
setblock 387 164 435 minecraft:light[level=12]
setblock 387 164 443 minecraft:light[level=12]
setblock 387 164 451 minecraft:light[level=12]
setblock 395 164 419 minecraft:light[level=12]
setblock 395 164 427 minecraft:light[level=12]
setblock 395 164 435 minecraft:light[level=12]
setblock 395 164 443 minecraft:light[level=12]
setblock 395 164 451 minecraft:light[level=12]
fill 402 164 421 402 165 421 minecraft:polished_blackstone
setblock 403 164 419 minecraft:light[level=12]
setblock 403 164 427 minecraft:light[level=12]
setblock 403 164 435 minecraft:light[level=12]
setblock 403 164 443 minecraft:light[level=12]
setblock 403 164 451 minecraft:light[level=12]
setblock 406 164 438 minecraft:bone_block
fill 408 164 435 409 164 436 minecraft:bone_block
fill 408 164 441 409 164 441 minecraft:bone_block
fill 410 164 436 411 164 436 minecraft:bone_block
setblock 411 164 419 minecraft:light[level=12]
setblock 411 164 427 minecraft:light[level=12]
setblock 411 164 435 minecraft:light[level=12]
setblock 411 164 443 minecraft:light[level=12]
fill 411 164 452 411 165 452 minecraft:polished_blackstone
fill 412 164 434 412 165 434 minecraft:polished_blackstone
setblock 412 164 438 minecraft:bone_block
fill 412 164 449 412 165 449 minecraft:polished_blackstone
fill 377 165 420 377 165 425 minecraft:polished_blackstone
fill 377 165 432 377 165 437 minecraft:polished_blackstone
fill 377 165 444 377 165 449 minecraft:polished_blackstone
fill 377 165 456 377 165 457 minecraft:polished_blackstone
fill 378 165 457 381 165 457 minecraft:polished_blackstone
fill 380 165 420 380 166 420 minecraft:polished_blackstone
fill 380 165 436 380 166 436 minecraft:polished_blackstone
fill 380 165 438 380 166 438 minecraft:polished_blackstone
fill 381 165 417 386 165 417 minecraft:polished_blackstone
fill 388 165 457 393 165 457 minecraft:polished_blackstone
fill 393 165 417 398 165 417 minecraft:polished_blackstone
fill 400 165 457 405 165 457 minecraft:polished_blackstone
fill 402 165 420 402 166 420 minecraft:polished_blackstone
fill 405 165 417 410 165 417 minecraft:polished_blackstone
fill 408 165 436 409 165 438 minecraft:bone_block
fill 409 165 439 410 165 440 minecraft:bone_block
fill 410 165 437 410 165 438 minecraft:bone_block
fill 411 165 453 411 166 453 minecraft:polished_blackstone
fill 412 165 457 417 165 457 minecraft:polished_blackstone
fill 413 165 434 413 166 434 minecraft:polished_blackstone
fill 413 165 449 413 166 449 minecraft:polished_blackstone
fill 417 165 417 417 165 422 minecraft:polished_blackstone
fill 417 165 429 417 165 434 minecraft:polished_blackstone
fill 417 165 441 417 165 446 minecraft:polished_blackstone
fill 417 165 453 417 165 456 minecraft:polished_blackstone
fill 376 166 422 376 171 425 minecraft:shroomlight
fill 376 166 434 376 171 437 minecraft:shroomlight
fill 376 166 446 376 171 449 minecraft:shroomlight
fill 376 166 458 379 171 458 minecraft:shroomlight
fill 379 166 420 379 167 420 minecraft:polished_blackstone
fill 379 166 436 379 167 436 minecraft:polished_blackstone
fill 379 166 438 379 167 438 minecraft:polished_blackstone
fill 383 166 416 386 171 416 minecraft:shroomlight
fill 388 166 458 391 171 458 minecraft:shroomlight
fill 395 166 416 398 171 416 minecraft:shroomlight
fill 400 166 458 403 171 458 minecraft:shroomlight
fill 402 166 419 402 167 419 minecraft:polished_blackstone
fill 407 166 416 410 171 416 minecraft:shroomlight
fill 411 166 454 411 167 454 minecraft:polished_blackstone
fill 412 166 458 415 171 458 minecraft:shroomlight
fill 414 166 434 414 167 434 minecraft:polished_blackstone
fill 414 166 449 414 167 449 minecraft:polished_blackstone
fill 418 166 417 418 171 420 minecraft:shroomlight
fill 418 166 429 418 171 432 minecraft:shroomlight
fill 418 166 441 418 171 444 minecraft:shroomlight
fill 418 166 453 418 171 456 minecraft:shroomlight
fill 378 167 420 378 168 420 minecraft:polished_blackstone
fill 378 167 436 378 168 436 minecraft:polished_blackstone
fill 378 167 438 378 168 438 minecraft:polished_blackstone
fill 402 167 418 402 168 418 minecraft:polished_blackstone
fill 411 167 455 411 168 455 minecraft:polished_blackstone
fill 415 167 434 415 168 434 minecraft:polished_blackstone
fill 415 167 449 415 168 449 minecraft:polished_blackstone
fill 377 168 420 377 169 420 minecraft:polished_blackstone
fill 377 168 436 377 169 436 minecraft:polished_blackstone
fill 377 168 438 377 169 438 minecraft:polished_blackstone
fill 411 168 456 411 169 456 minecraft:polished_blackstone
fill 416 168 434 416 169 434 minecraft:polished_blackstone
fill 416 168 449 416 169 449 minecraft:polished_blackstone
setblock 384 169 426 minecraft:shroomlight
setblock 384 169 432 minecraft:shroomlight
setblock 384 169 438 minecraft:shroomlight
setblock 384 169 444 minecraft:shroomlight
setblock 384 169 450 minecraft:shroomlight
setblock 386 169 424 minecraft:shroomlight
setblock 390 169 450 minecraft:shroomlight
setblock 392 169 424 minecraft:shroomlight
setblock 396 169 450 minecraft:shroomlight
setblock 398 169 424 minecraft:shroomlight
setblock 402 169 450 minecraft:shroomlight
setblock 404 169 424 minecraft:shroomlight
setblock 408 169 450 minecraft:shroomlight
setblock 410 169 424 minecraft:shroomlight
setblock 410 169 430 minecraft:shroomlight
setblock 410 169 436 minecraft:shroomlight
setblock 410 169 442 minecraft:shroomlight
setblock 410 169 448 minecraft:shroomlight
fill 377 170 418 384 170 426 minecraft:bone_block
fill 377 170 430 384 170 438 minecraft:bone_block
fill 377 170 442 384 170 450 minecraft:bone_block
fill 377 170 454 382 170 457 minecraft:bone_block
fill 378 170 427 384 170 429 minecraft:bone_block
fill 378 170 439 384 170 441 minecraft:bone_block
fill 378 170 451 416 170 453 minecraft:bone_block
fill 380 170 417 388 170 417 minecraft:bone_block
fill 383 170 454 417 170 456 minecraft:bone_block
fill 385 170 418 417 170 424 minecraft:bone_block
fill 385 170 450 416 170 450 minecraft:bone_block
fill 386 170 457 394 170 457 minecraft:bone_block
fill 392 170 417 400 170 417 minecraft:bone_block
fill 398 170 457 406 170 457 minecraft:bone_block
fill 404 170 417 412 170 417 minecraft:bone_block
fill 410 170 425 416 170 449 minecraft:bone_block
fill 410 170 457 417 170 457 minecraft:bone_block
fill 416 170 417 417 170 417 minecraft:bone_block
fill 417 170 428 417 170 436 minecraft:bone_block
fill 417 170 440 417 170 448 minecraft:bone_block
fill 417 170 452 417 170 453 minecraft:bone_block
fill 384 171 424 384 171 450 minecraft:white_concrete
fill 385 171 424 410 171 424 minecraft:white_concrete
fill 385 171 450 410 171 450 minecraft:white_concrete
fill 410 171 425 410 171 449 minecraft:white_concrete
fill 376 172 422 376 185 422 minecraft:deepslate_tiles
fill 376 172 423 376 172 424 minecraft:shroomlight
fill 376 172 425 376 185 425 minecraft:deepslate_tiles
fill 376 172 434 376 185 434 minecraft:deepslate_tiles
fill 376 172 435 376 172 436 minecraft:shroomlight
fill 376 172 437 376 185 437 minecraft:deepslate_tiles
fill 376 172 446 376 185 446 minecraft:deepslate_tiles
fill 376 172 447 376 172 448 minecraft:shroomlight
fill 376 172 449 376 185 449 minecraft:deepslate_tiles
fill 376 172 458 376 185 458 minecraft:deepslate_tiles
fill 377 172 458 378 172 458 minecraft:shroomlight
setblock 379 172 419 minecraft:light[level=12]
setblock 379 172 427 minecraft:light[level=12]
setblock 379 172 435 minecraft:light[level=12]
setblock 379 172 443 minecraft:light[level=12]
setblock 379 172 451 minecraft:light[level=12]
fill 379 172 458 379 185 458 minecraft:deepslate_tiles
fill 383 172 416 383 185 416 minecraft:deepslate_tiles
fill 384 172 416 385 172 416 minecraft:shroomlight
fill 386 172 416 386 185 416 minecraft:deepslate_tiles
setblock 387 172 419 minecraft:light[level=12]
setblock 387 172 427 minecraft:light[level=12]
setblock 387 172 435 minecraft:light[level=12]
setblock 387 172 443 minecraft:light[level=12]
setblock 387 172 451 minecraft:light[level=12]
fill 388 172 458 388 185 458 minecraft:deepslate_tiles
fill 389 172 458 390 172 458 minecraft:shroomlight
fill 391 172 458 391 185 458 minecraft:deepslate_tiles
fill 395 172 416 395 185 416 minecraft:deepslate_tiles
setblock 395 172 419 minecraft:light[level=12]
setblock 395 172 427 minecraft:light[level=12]
setblock 395 172 435 minecraft:light[level=12]
setblock 395 172 443 minecraft:light[level=12]
setblock 395 172 451 minecraft:light[level=12]
fill 396 172 416 397 172 416 minecraft:shroomlight
fill 398 172 416 398 185 416 minecraft:deepslate_tiles
fill 400 172 458 400 185 458 minecraft:deepslate_tiles
fill 401 172 458 402 172 458 minecraft:shroomlight
setblock 403 172 419 minecraft:light[level=12]
setblock 403 172 427 minecraft:light[level=12]
setblock 403 172 435 minecraft:light[level=12]
setblock 403 172 443 minecraft:light[level=12]
setblock 403 172 451 minecraft:light[level=12]
fill 403 172 458 403 185 458 minecraft:deepslate_tiles
fill 407 172 416 407 185 416 minecraft:deepslate_tiles
fill 408 172 416 409 172 416 minecraft:shroomlight
fill 410 172 416 410 185 416 minecraft:deepslate_tiles
setblock 411 172 419 minecraft:light[level=12]
setblock 411 172 427 minecraft:light[level=12]
setblock 411 172 435 minecraft:light[level=12]
setblock 411 172 443 minecraft:light[level=12]
setblock 411 172 451 minecraft:light[level=12]
fill 412 172 458 412 185 458 minecraft:deepslate_tiles
fill 413 172 458 414 172 458 minecraft:shroomlight
fill 415 172 458 415 185 458 minecraft:deepslate_tiles
fill 418 172 417 418 185 417 minecraft:deepslate_tiles
fill 418 172 418 418 172 419 minecraft:shroomlight
fill 418 172 420 418 185 420 minecraft:deepslate_tiles
fill 418 172 429 418 185 429 minecraft:deepslate_tiles
fill 418 172 430 418 172 431 minecraft:shroomlight
fill 418 172 432 418 185 432 minecraft:deepslate_tiles
fill 418 172 441 418 185 441 minecraft:deepslate_tiles
fill 418 172 442 418 172 443 minecraft:shroomlight
fill 418 172 444 418 185 444 minecraft:deepslate_tiles
fill 418 172 453 418 185 453 minecraft:deepslate_tiles
fill 418 172 454 418 172 455 minecraft:shroomlight
fill 418 172 456 418 185 456 minecraft:deepslate_tiles
fill 376 173 423 376 185 424 minecraft:deepslate_tiles
fill 376 173 435 376 185 436 minecraft:deepslate_tiles
fill 376 173 447 376 185 448 minecraft:deepslate_tiles
fill 377 173 458 378 185 458 minecraft:deepslate_tiles
fill 384 173 416 385 185 416 minecraft:deepslate_tiles
fill 389 173 458 390 185 458 minecraft:deepslate_tiles
fill 396 173 416 397 185 416 minecraft:deepslate_tiles
fill 401 173 458 402 185 458 minecraft:deepslate_tiles
fill 408 173 416 409 185 416 minecraft:deepslate_tiles
fill 413 173 458 414 185 458 minecraft:deepslate_tiles
fill 418 173 418 418 185 419 minecraft:deepslate_tiles
fill 418 173 430 418 185 431 minecraft:deepslate_tiles
fill 418 173 442 418 185 443 minecraft:deepslate_tiles
fill 418 173 454 418 185 455 minecraft:deepslate_tiles
fill 407 178 417 409 179 417 minecraft:bone_block
fill 407 178 456 409 179 456 minecraft:bone_block
fill 407 179 418 409 180 418 minecraft:bone_block
fill 407 179 455 409 180 455 minecraft:bone_block
fill 408 179 419 408 182 419 minecraft:bone_block
fill 408 179 454 408 182 454 minecraft:bone_block
fill 378 180 426 378 185 428 minecraft:bone_block
fill 378 180 438 378 185 440 minecraft:bone_block
fill 378 180 450 378 185 452 minecraft:bone_block
setblock 379 180 419 minecraft:light[level=12]
setblock 379 180 427 minecraft:light[level=12]
setblock 379 180 435 minecraft:light[level=12]
setblock 379 180 443 minecraft:light[level=12]
setblock 379 180 451 minecraft:light[level=12]
fill 384 180 456 386 185 456 minecraft:bone_block
setblock 387 180 419 minecraft:light[level=12]
setblock 387 180 427 minecraft:light[level=12]
setblock 387 180 435 minecraft:light[level=12]
setblock 387 180 443 minecraft:light[level=12]
setblock 387 180 451 minecraft:light[level=12]
fill 388 180 418 390 185 418 minecraft:bone_block
setblock 395 180 419 minecraft:light[level=12]
setblock 395 180 427 minecraft:light[level=12]
setblock 395 180 435 minecraft:light[level=12]
setblock 395 180 443 minecraft:light[level=12]
setblock 395 180 451 minecraft:light[level=12]
fill 396 180 456 398 185 456 minecraft:bone_block
fill 400 180 418 402 185 418 minecraft:bone_block
setblock 403 180 419 minecraft:light[level=12]
setblock 403 180 427 minecraft:light[level=12]
setblock 403 180 435 minecraft:light[level=12]
setblock 403 180 443 minecraft:light[level=12]
setblock 403 180 451 minecraft:light[level=12]
fill 407 180 419 407 181 419 minecraft:bone_block
fill 407 180 454 407 181 454 minecraft:bone_block
setblock 408 180 417 minecraft:bone_block
fill 408 180 420 408 182 420 minecraft:bone_block
fill 408 180 453 408 182 453 minecraft:bone_block
fill 408 180 456 410 185 456 minecraft:bone_block
fill 409 180 419 409 181 419 minecraft:bone_block
fill 409 180 454 409 181 454 minecraft:bone_block
setblock 411 180 419 minecraft:light[level=12]
setblock 411 180 427 minecraft:light[level=12]
setblock 411 180 435 minecraft:light[level=12]
setblock 411 180 443 minecraft:light[level=12]
setblock 411 180 451 minecraft:light[level=12]
fill 412 180 418 414 185 418 minecraft:bone_block
fill 416 180 426 416 185 428 minecraft:bone_block
fill 416 180 438 416 185 440 minecraft:bone_block
fill 416 180 450 416 185 452 minecraft:bone_block
fill 407 181 420 407 182 421 minecraft:bone_block
fill 407 181 452 407 182 453 minecraft:bone_block
setblock 408 181 417 minecraft:white_concrete
setblock 408 181 418 minecraft:bone_block
fill 408 181 421 409 182 421 minecraft:bone_block
fill 408 181 452 409 182 452 minecraft:bone_block
setblock 408 181 455 minecraft:bone_block
fill 409 181 420 409 182 420 minecraft:bone_block
fill 409 181 453 409 182 453 minecraft:bone_block
fill 407 182 422 409 183 422 minecraft:bone_block
fill 407 182 451 409 183 451 minecraft:bone_block
setblock 408 182 418 minecraft:white_concrete
fill 408 182 423 408 184 423 minecraft:bone_block
fill 408 182 450 408 184 450 minecraft:bone_block
setblock 408 182 455 minecraft:white_concrete
fill 407 183 423 407 184 423 minecraft:bone_block
fill 407 183 450 407 184 450 minecraft:bone_block
setblock 408 183 420 minecraft:white_concrete
setblock 408 183 421 minecraft:bone_block
fill 408 183 424 408 185 424 minecraft:bone_block
fill 408 183 449 408 185 449 minecraft:bone_block
setblock 408 183 452 minecraft:bone_block
setblock 408 183 453 minecraft:white_concrete
fill 409 183 423 409 184 423 minecraft:bone_block
fill 409 183 450 409 184 450 minecraft:bone_block
fill 407 184 424 407 184 425 minecraft:bone_block
fill 407 184 448 407 184 449 minecraft:bone_block
setblock 408 184 421 minecraft:white_concrete
setblock 408 184 422 minecraft:bone_block
fill 408 184 425 408 186 426 minecraft:bone_block
fill 408 184 447 408 186 448 minecraft:bone_block
setblock 408 184 451 minecraft:bone_block
setblock 408 184 452 minecraft:white_concrete
fill 409 184 424 409 184 425 minecraft:bone_block
fill 409 184 448 409 184 449 minecraft:bone_block
fill 377 185 420 377 185 425 minecraft:polished_blackstone
fill 377 185 432 377 185 437 minecraft:polished_blackstone
fill 377 185 444 377 185 449 minecraft:polished_blackstone
fill 377 185 456 377 185 457 minecraft:polished_blackstone
fill 378 185 457 381 185 457 minecraft:polished_blackstone
fill 381 185 417 386 185 417 minecraft:polished_blackstone
fill 388 185 457 393 185 457 minecraft:polished_blackstone
fill 393 185 417 398 185 417 minecraft:polished_blackstone
fill 400 185 457 405 185 457 minecraft:polished_blackstone
fill 405 185 417 410 185 417 minecraft:polished_blackstone
fill 407 185 425 407 185 427 minecraft:bone_block
fill 407 185 446 407 185 448 minecraft:bone_block
setblock 408 185 423 minecraft:white_concrete
fill 408 185 427 408 187 428 minecraft:bone_block
fill 408 185 445 408 187 446 minecraft:bone_block
setblock 408 185 450 minecraft:white_concrete
fill 409 185 425 409 185 427 minecraft:bone_block
fill 409 185 446 409 185 448 minecraft:bone_block
fill 412 185 457 417 185 457 minecraft:polished_blackstone
fill 417 185 417 417 185 422 minecraft:polished_blackstone
fill 417 185 429 417 185 434 minecraft:polished_blackstone
fill 417 185 441 417 185 446 minecraft:polished_blackstone
fill 417 185 453 417 185 456 minecraft:polished_blackstone
fill 376 186 422 376 191 425 minecraft:shroomlight
fill 376 186 434 376 191 437 minecraft:shroomlight
fill 376 186 446 376 191 449 minecraft:shroomlight
fill 376 186 458 379 191 458 minecraft:shroomlight
fill 383 186 416 386 191 416 minecraft:shroomlight
fill 388 186 458 391 191 458 minecraft:shroomlight
fill 395 186 416 398 191 416 minecraft:shroomlight
fill 400 186 458 403 191 458 minecraft:shroomlight
fill 407 186 416 410 191 416 minecraft:shroomlight
fill 407 186 426 407 186 429 minecraft:bone_block
fill 407 186 444 407 186 447 minecraft:bone_block
setblock 408 186 424 minecraft:white_concrete
fill 408 186 429 408 188 430 minecraft:bone_block
fill 408 186 443 408 188 444 minecraft:bone_block
setblock 408 186 449 minecraft:white_concrete
fill 409 186 426 409 186 429 minecraft:bone_block
fill 409 186 444 409 186 447 minecraft:bone_block
fill 412 186 458 415 191 458 minecraft:shroomlight
fill 418 186 417 418 191 420 minecraft:shroomlight
fill 418 186 429 418 191 432 minecraft:shroomlight
fill 418 186 441 418 191 444 minecraft:shroomlight
fill 418 186 453 418 191 456 minecraft:shroomlight
fill 407 187 428 407 187 432 minecraft:bone_block
fill 407 187 441 407 187 445 minecraft:bone_block
setblock 408 187 426 minecraft:white_concrete
fill 408 187 431 408 188 434 minecraft:bone_block
fill 408 187 439 408 188 442 minecraft:bone_block
setblock 408 187 447 minecraft:white_concrete
fill 409 187 428 409 187 432 minecraft:bone_block
fill 409 187 441 409 187 445 minecraft:bone_block
setblock 379 188 419 minecraft:light[level=12]
setblock 379 188 427 minecraft:light[level=12]
setblock 379 188 435 minecraft:light[level=12]
setblock 379 188 443 minecraft:light[level=12]
setblock 379 188 451 minecraft:light[level=12]
setblock 387 188 419 minecraft:light[level=12]
setblock 387 188 427 minecraft:light[level=12]
setblock 387 188 435 minecraft:light[level=12]
setblock 387 188 443 minecraft:light[level=12]
setblock 387 188 451 minecraft:light[level=12]
setblock 395 188 419 minecraft:light[level=12]
setblock 395 188 427 minecraft:light[level=12]
setblock 395 188 435 minecraft:light[level=12]
setblock 395 188 443 minecraft:light[level=12]
setblock 395 188 451 minecraft:light[level=12]
setblock 403 188 419 minecraft:light[level=12]
setblock 403 188 427 minecraft:light[level=12]
setblock 403 188 435 minecraft:light[level=12]
setblock 403 188 443 minecraft:light[level=12]
setblock 403 188 451 minecraft:light[level=12]
fill 407 188 431 407 188 442 minecraft:bone_block
fill 408 188 427 408 188 428 minecraft:white_concrete
fill 408 188 435 409 189 438 minecraft:bone_block
fill 408 188 445 408 188 446 minecraft:white_concrete
fill 409 188 431 409 188 434 minecraft:bone_block
fill 409 188 439 409 188 442 minecraft:bone_block
setblock 411 188 419 minecraft:light[level=12]
setblock 411 188 427 minecraft:light[level=12]
setblock 411 188 435 minecraft:light[level=12]
setblock 411 188 443 minecraft:light[level=12]
setblock 411 188 451 minecraft:light[level=12]
fill 407 189 434 407 189 439 minecraft:bone_block
fill 408 189 429 408 189 431 minecraft:white_concrete
fill 408 189 432 408 189 434 minecraft:bone_block
fill 408 189 439 408 189 441 minecraft:bone_block
fill 408 189 442 408 189 444 minecraft:white_concrete
setblock 409 189 434 minecraft:bone_block
setblock 409 189 439 minecraft:bone_block
fill 408 190 433 408 190 440 minecraft:white_concrete
fill 376 192 422 376 197 422 minecraft:deepslate_tiles
fill 376 192 423 376 192 424 minecraft:shroomlight
fill 376 192 425 376 197 425 minecraft:deepslate_tiles
fill 376 192 434 376 194 434 minecraft:deepslate_tiles
fill 376 192 435 376 192 436 minecraft:shroomlight
fill 376 192 437 376 194 437 minecraft:deepslate_tiles
fill 376 192 446 376 197 446 minecraft:deepslate_tiles
fill 376 192 447 376 192 448 minecraft:shroomlight
fill 376 192 449 376 197 449 minecraft:deepslate_tiles
fill 376 192 458 376 197 458 minecraft:deepslate_tiles
fill 377 192 458 378 192 458 minecraft:shroomlight
fill 379 192 458 379 197 458 minecraft:deepslate_tiles
fill 383 192 416 383 195 416 minecraft:deepslate_tiles
fill 384 192 416 385 192 416 minecraft:shroomlight
fill 386 192 416 386 197 416 minecraft:deepslate_tiles
fill 388 192 458 388 197 458 minecraft:deepslate_tiles
fill 389 192 458 390 192 458 minecraft:shroomlight
fill 391 192 458 391 197 458 minecraft:deepslate_tiles
fill 395 192 416 395 197 416 minecraft:deepslate_tiles
fill 396 192 416 397 192 416 minecraft:shroomlight
fill 398 192 416 398 197 416 minecraft:deepslate_tiles
fill 400 192 458 400 193 458 minecraft:deepslate_tiles
fill 401 192 458 402 192 458 minecraft:shroomlight
fill 403 192 458 403 194 458 minecraft:deepslate_tiles
fill 407 192 416 407 194 416 minecraft:deepslate_tiles
fill 408 192 416 409 192 416 minecraft:shroomlight
fill 410 192 416 410 197 416 minecraft:deepslate_tiles
fill 410 192 440 414 193 444 minecraft:polished_blackstone
fill 412 192 458 412 197 458 minecraft:deepslate_tiles
fill 413 192 458 414 192 458 minecraft:shroomlight
fill 415 192 442 416 192 442 minecraft:polished_blackstone
fill 415 192 458 415 195 458 minecraft:deepslate_tiles
fill 418 192 417 418 197 417 minecraft:deepslate_tiles
fill 418 192 418 418 192 419 minecraft:shroomlight
fill 418 192 420 418 195 420 minecraft:deepslate_tiles
fill 418 192 429 418 197 429 minecraft:deepslate_tiles
fill 418 192 430 418 192 431 minecraft:shroomlight
fill 418 192 432 418 194 432 minecraft:deepslate_tiles
fill 418 192 441 418 197 441 minecraft:deepslate_tiles
fill 418 192 442 418 192 443 minecraft:shroomlight
fill 418 192 444 418 197 444 minecraft:deepslate_tiles
fill 418 192 453 418 197 453 minecraft:deepslate_tiles
fill 418 192 454 418 192 455 minecraft:shroomlight
fill 418 192 456 418 193 456 minecraft:deepslate_tiles
fill 376 193 423 376 194 424 minecraft:deepslate_tiles
fill 376 193 435 376 194 436 minecraft:deepslate_tiles
fill 376 193 447 376 197 448 minecraft:deepslate_tiles
fill 377 193 458 378 197 458 minecraft:deepslate_tiles
fill 384 193 416 385 197 416 minecraft:deepslate_tiles
fill 389 193 458 390 197 458 minecraft:deepslate_tiles
fill 396 193 416 397 195 416 minecraft:deepslate_tiles
fill 401 193 458 402 194 458 minecraft:deepslate_tiles
fill 408 193 416 409 197 416 minecraft:deepslate_tiles
fill 413 193 458 414 195 458 minecraft:deepslate_tiles
fill 418 193 418 418 195 419 minecraft:deepslate_tiles
fill 418 193 430 418 193 431 minecraft:deepslate_tiles
fill 418 193 442 418 195 443 minecraft:deepslate_tiles
fill 418 193 454 418 197 455 minecraft:deepslate_tiles
fill 376 194 419 376 195 419 minecraft:polished_blackstone
fill 376 194 420 376 194 421 minecraft:deepslate_tiles
fill 376 194 426 376 194 431 minecraft:deepslate_tiles
setblock 376 194 432 minecraft:polished_blackstone
fill 376 194 433 376 197 433 minecraft:deepslate_tiles
fill 376 194 440 376 194 442 minecraft:deepslate_tiles
setblock 376 194 443 minecraft:polished_blackstone
fill 376 194 444 376 195 445 minecraft:deepslate_tiles
fill 376 194 456 376 194 457 minecraft:polished_blackstone
fill 378 194 416 378 197 416 minecraft:deepslate_tiles
setblock 379 194 416 minecraft:polished_blackstone
fill 380 194 416 380 195 416 minecraft:deepslate_tiles
setblock 387 194 416 minecraft:deepslate_tiles
setblock 388 194 416 minecraft:polished_blackstone
fill 395 194 458 397 195 458 minecraft:deepslate_tiles
setblock 398 194 458 minecraft:polished_blackstone
setblock 400 194 458 minecraft:polished_blackstone
fill 404 194 458 404 197 458 minecraft:deepslate_tiles
setblock 405 194 416 minecraft:polished_blackstone
setblock 405 194 458 minecraft:polished_blackstone
fill 406 194 416 406 197 416 minecraft:deepslate_tiles
fill 406 194 458 406 197 458 minecraft:deepslate_tiles
fill 408 194 441 410 195 441 minecraft:bone_block
fill 408 194 443 410 195 443 minecraft:bone_block
fill 409 194 442 409 195 442 minecraft:bone_block
fill 411 194 416 411 197 416 minecraft:deepslate_tiles
fill 412 194 416 412 195 416 minecraft:polished_blackstone
fill 414 194 416 415 197 416 minecraft:deepslate_tiles
fill 416 194 416 417 194 416 minecraft:polished_blackstone
fill 418 194 416 418 197 416 minecraft:deepslate_tiles
setblock 418 194 430 minecraft:polished_blackstone
fill 418 194 431 418 197 431 minecraft:deepslate_tiles
setblock 418 194 456 minecraft:polished_blackstone
setblock 376 195 416 minecraft:polished_blackstone
setblock 376 195 420 minecraft:polished_blackstone
fill 376 195 421 376 197 421 minecraft:deepslate_tiles
fill 376 195 423 376 195 424 minecraft:polished_blackstone
fill 376 195 426 376 197 429 minecraft:deepslate_tiles
setblock 376 195 430 minecraft:polished_blackstone
fill 376 195 431 376 197 432 minecraft:deepslate_tiles
setblock 376 195 434 minecraft:polished_blackstone
fill 376 195 435 376 197 435 minecraft:deepslate_tiles
fill 376 195 436 376 195 437 minecraft:polished_blackstone
setblock 376 195 439 minecraft:polished_blackstone
fill 376 195 440 376 195 441 minecraft:deepslate_tiles
setblock 376 195 442 minecraft:polished_blackstone
fill 376 195 443 376 197 443 minecraft:deepslate_tiles
fill 376 195 450 376 197 450 minecraft:deepslate_tiles
setblock 376 195 451 minecraft:polished_blackstone
fill 376 195 452 376 195 457 minecraft:deepslate_tiles
setblock 379 195 416 minecraft:deepslate_tiles
fill 381 195 458 383 195 458 minecraft:polished_blackstone
fill 384 195 458 387 195 458 minecraft:deepslate_tiles
setblock 387 195 416 minecraft:polished_blackstone
fill 388 195 416 388 197 416 minecraft:deepslate_tiles
fill 398 195 458 398 198 458 minecraft:deepslate_tiles
fill 400 195 458 400 197 458 minecraft:deepslate_tiles
fill 401 195 458 403 195 458 minecraft:polished_blackstone
setblock 405 195 416 minecraft:deepslate_tiles
fill 405 195 458 405 197 458 minecraft:deepslate_tiles
setblock 407 195 416 minecraft:polished_blackstone
fill 410 195 442 411 196 442 minecraft:bone_block
setblock 416 195 416 minecraft:polished_blackstone
setblock 416 195 458 minecraft:polished_blackstone
fill 417 195 416 417 197 416 minecraft:deepslate_tiles
setblock 418 195 430 minecraft:deepslate_tiles
setblock 418 195 432 minecraft:polished_blackstone
fill 418 195 445 418 196 445 minecraft:polished_blackstone
fill 418 195 446 418 197 446 minecraft:deepslate_tiles
fill 418 195 456 418 197 456 minecraft:deepslate_tiles
setblock 418 195 458 minecraft:polished_blackstone
fill 376 196 416 376 198 416 minecraft:deepslate_tiles
fill 376 196 419 376 197 420 minecraft:deepslate_tiles
setblock 376 196 423 minecraft:polished_blackstone
fill 376 196 424 376 197 424 minecraft:deepslate_tiles
fill 376 196 430 376 197 430 minecraft:deepslate_tiles
fill 376 196 434 376 197 434 minecraft:deepslate_tiles
fill 376 196 436 376 197 436 minecraft:deepslate_tiles
setblock 376 196 437 minecraft:polished_blackstone
fill 376 196 439 376 197 439 minecraft:deepslate_tiles
setblock 376 196 440 minecraft:polished_blackstone
fill 376 196 441 376 197 442 minecraft:deepslate_tiles
fill 376 196 444 376 197 444 minecraft:deepslate_tiles
setblock 376 196 445 minecraft:polished_blackstone
fill 376 196 451 376 197 455 minecraft:deepslate_tiles
setblock 376 196 456 minecraft:polished_blackstone
fill 376 196 457 376 197 457 minecraft:deepslate_tiles
setblock 377 196 416 minecraft:polished_blackstone
fill 379 196 416 380 196 416 minecraft:polished_blackstone
setblock 379 196 419 minecraft:light[level=12]
setblock 379 196 427 minecraft:light[level=12]
setblock 379 196 435 minecraft:light[level=12]
setblock 379 196 443 minecraft:light[level=12]
setblock 379 196 451 minecraft:light[level=12]
fill 381 196 458 385 197 458 minecraft:deepslate_tiles
setblock 383 196 416 minecraft:polished_blackstone
fill 386 196 458 387 196 458 minecraft:polished_blackstone
fill 387 196 416 387 197 416 minecraft:deepslate_tiles
setblock 387 196 419 minecraft:light[level=12]
setblock 387 196 427 minecraft:light[level=12]
setblock 387 196 435 minecraft:light[level=12]
setblock 387 196 443 minecraft:light[level=12]
setblock 387 196 451 minecraft:light[level=12]
setblock 395 196 419 minecraft:light[level=12]
setblock 395 196 427 minecraft:light[level=12]
setblock 395 196 435 minecraft:light[level=12]
setblock 395 196 443 minecraft:light[level=12]
setblock 395 196 451 minecraft:light[level=12]
fill 395 196 458 396 197 458 minecraft:deepslate_tiles
fill 396 196 416 396 197 416 minecraft:deepslate_tiles
setblock 397 196 416 minecraft:polished_blackstone
setblock 397 196 458 minecraft:polished_blackstone
setblock 399 196 416 minecraft:polished_blackstone
fill 400 196 416 400 197 416 minecraft:deepslate_tiles
fill 401 196 458 401 197 458 minecraft:deepslate_tiles
setblock 402 196 458 minecraft:polished_blackstone
setblock 403 196 419 minecraft:light[level=12]
setblock 403 196 427 minecraft:light[level=12]
setblock 403 196 435 minecraft:light[level=12]
setblock 403 196 443 minecraft:light[level=12]
setblock 403 196 451 minecraft:light[level=12]
fill 403 196 458 403 197 458 minecraft:deepslate_tiles
setblock 405 196 416 minecraft:polished_blackstone
fill 407 196 416 407 197 416 minecraft:deepslate_tiles
fill 410 196 458 411 196 458 minecraft:polished_blackstone
setblock 411 196 419 minecraft:light[level=12]
setblock 411 196 427 minecraft:light[level=12]
setblock 411 196 435 minecraft:light[level=12]
setblock 411 196 443 minecraft:light[level=12]
setblock 411 196 451 minecraft:light[level=12]
fill 412 196 416 412 197 416 minecraft:deepslate_tiles
fill 412 196 442 412 197 442 minecraft:bone_block
fill 413 196 458 415 196 458 minecraft:polished_blackstone
fill 416 196 416 416 197 416 minecraft:deepslate_tiles
fill 416 196 458 416 197 458 minecraft:deepslate_tiles
fill 418 196 418 418 197 418 minecraft:deepslate_tiles
fill 418 196 419 418 196 420 minecraft:polished_blackstone
setblock 418 196 430 minecraft:polished_blackstone
fill 418 196 432 418 197 432 minecraft:deepslate_tiles
fill 418 196 442 418 196 443 minecraft:polished_blackstone
fill 418 196 458 418 197 458 minecraft:deepslate_tiles
setblock 376 197 423 minecraft:deepslate_tiles
setblock 376 197 437 minecraft:deepslate_tiles
setblock 376 197 440 minecraft:deepslate_tiles
setblock 376 197 445 minecraft:deepslate_tiles
fill 376 197 456 376 198 456 minecraft:deepslate_tiles
setblock 377 197 416 minecraft:deepslate_tiles
fill 379 197 416 380 197 416 minecraft:deepslate_tiles
setblock 383 197 416 minecraft:deepslate_tiles
fill 386 197 458 387 197 458 minecraft:deepslate_tiles
setblock 397 197 416 minecraft:deepslate_tiles
setblock 397 197 458 minecraft:deepslate_tiles
fill 399 197 416 399 198 416 minecraft:deepslate_tiles
setblock 402 197 458 minecraft:deepslate_tiles
setblock 405 197 416 minecraft:deepslate_tiles
fill 410 197 458 411 197 458 minecraft:deepslate_tiles
fill 413 197 442 414 198 442 minecraft:bone_block
fill 413 197 458 415 197 458 minecraft:deepslate_tiles
fill 418 197 419 418 197 420 minecraft:deepslate_tiles
setblock 418 197 430 minecraft:deepslate_tiles
fill 418 197 442 418 197 443 minecraft:deepslate_tiles
setblock 418 197 445 minecraft:deepslate_tiles
fill 376 198 417 376 198 446 minecraft:polished_blackstone
setblock 376 198 447 minecraft:deepslate_tiles
fill 376 198 448 376 198 455 minecraft:polished_blackstone
fill 376 198 457 376 205 458 minecraft:polished_blackstone
fill 377 198 416 380 307 416 minecraft:polished_blackstone
fill 377 198 458 386 198 458 minecraft:polished_blackstone
setblock 381 198 416 minecraft:deepslate_tiles
fill 382 198 416 383 199 416 minecraft:polished_blackstone
setblock 384 198 416 minecraft:deepslate_tiles
fill 385 198 416 398 198 416 minecraft:polished_blackstone
setblock 387 198 458 minecraft:deepslate_tiles
fill 388 198 458 395 205 458 minecraft:polished_blackstone
setblock 396 198 458 minecraft:deepslate_tiles
fill 397 198 458 397 307 458 minecraft:polished_blackstone
fill 400 198 416 402 307 416 minecraft:polished_blackstone
fill 400 198 458 406 205 458 minecraft:polished_blackstone
setblock 403 198 416 minecraft:deepslate_tiles
fill 404 198 416 418 199 416 minecraft:polished_blackstone
fill 408 198 458 412 205 458 minecraft:polished_blackstone
setblock 413 198 458 minecraft:deepslate_tiles
fill 414 198 441 416 199 441 minecraft:bone_block
fill 414 198 443 416 199 443 minecraft:bone_block
fill 414 198 458 418 205 458 minecraft:polished_blackstone
fill 415 198 442 415 199 442 minecraft:bone_block
fill 418 198 417 418 198 420 minecraft:polished_blackstone
setblock 418 198 421 minecraft:deepslate_tiles
fill 418 198 422 418 307 423 minecraft:polished_blackstone
fill 418 198 425 418 198 438 minecraft:polished_blackstone
setblock 418 198 439 minecraft:deepslate_tiles
fill 418 198 440 418 198 453 minecraft:polished_blackstone
setblock 418 198 454 minecraft:deepslate_tiles
fill 418 198 455 418 198 457 minecraft:polished_blackstone
fill 376 199 416 376 199 423 minecraft:polished_blackstone
setblock 376 199 424 minecraft:deepslate_tiles
fill 376 199 425 376 199 429 minecraft:polished_blackstone
setblock 376 199 430 minecraft:deepslate_tiles
fill 376 199 431 376 199 437 minecraft:polished_blackstone
setblock 376 199 438 minecraft:deepslate_tiles
fill 376 199 439 376 199 449 minecraft:polished_blackstone
setblock 376 199 450 minecraft:deepslate_tiles
fill 376 199 451 376 199 456 minecraft:polished_blackstone
setblock 377 199 458 minecraft:deepslate_tiles
fill 378 199 458 387 199 458 minecraft:polished_blackstone
fill 381 199 416 381 307 416 minecraft:polished_blackstone
fill 384 199 416 393 199 416 minecraft:polished_blackstone
setblock 394 199 416 minecraft:deepslate_tiles
fill 395 199 416 396 205 416 minecraft:polished_blackstone
fill 396 199 458 396 307 458 minecraft:polished_blackstone
fill 397 199 416 398 199 416 minecraft:deepslate_tiles
fill 398 199 458 398 307 458 minecraft:polished_blackstone
fill 399 199 416 399 307 416 minecraft:polished_blackstone
fill 403 199 416 403 307 416 minecraft:polished_blackstone
fill 407 199 458 407 307 458 minecraft:polished_blackstone
fill 413 199 458 413 205 458 minecraft:polished_blackstone
fill 418 199 417 418 199 418 minecraft:polished_blackstone
setblock 418 199 419 minecraft:deepslate_tiles
fill 418 199 420 418 199 421 minecraft:polished_blackstone
fill 418 199 425 418 205 432 minecraft:polished_blackstone
setblock 418 199 433 minecraft:deepslate_tiles
fill 418 199 434 418 205 441 minecraft:polished_blackstone
fill 418 199 442 418 200 442 minecraft:deepslate_tiles
fill 418 199 443 418 205 448 minecraft:polished_blackstone
setblock 418 199 449 minecraft:deepslate_tiles
fill 418 199 450 418 199 454 minecraft:polished_blackstone
setblock 418 199 455 minecraft:deepslate_tiles
fill 418 199 456 418 205 457 minecraft:polished_blackstone
fill 376 200 416 376 307 420 minecraft:polished_blackstone
setblock 376 200 421 minecraft:deepslate_tiles
fill 376 200 422 376 205 422 minecraft:polished_blackstone
setblock 376 200 423 minecraft:deepslate_tiles
fill 376 200 424 376 205 424 minecraft:polished_blackstone
setblock 376 200 425 minecraft:deepslate_tiles
fill 376 200 426 376 205 435 minecraft:polished_blackstone
setblock 376 200 436 minecraft:deepslate_tiles
fill 376 200 437 376 205 443 minecraft:polished_blackstone
setblock 376 200 444 minecraft:deepslate_tiles
fill 376 200 445 376 307 445 minecraft:polished_blackstone
setblock 376 200 446 minecraft:deepslate_tiles
fill 376 200 447 376 205 451 minecraft:polished_blackstone
setblock 376 200 452 minecraft:deepslate_tiles
fill 376 200 453 376 307 455 minecraft:polished_blackstone
setblock 376 200 456 minecraft:deepslate_tiles
fill 377 200 458 384 205 458 minecraft:polished_blackstone
fill 378 200 426 378 205 428 minecraft:bone_block
fill 378 200 438 378 205 440 minecraft:bone_block
fill 378 200 450 378 205 452 minecraft:bone_block
setblock 382 200 416 minecraft:deepslate_tiles
fill 383 200 416 387 205 416 minecraft:polished_blackstone
fill 384 200 456 386 205 456 minecraft:bone_block
setblock 385 200 458 minecraft:deepslate_tiles
fill 386 200 458 387 307 458 minecraft:polished_blackstone
setblock 388 200 416 minecraft:deepslate_tiles
fill 388 200 418 390 205 418 minecraft:bone_block
fill 389 200 416 394 307 416 minecraft:polished_blackstone
fill 396 200 456 398 205 456 minecraft:bone_block
setblock 397 200 416 minecraft:deepslate_tiles
fill 398 200 416 398 205 416 minecraft:polished_blackstone
fill 399 200 458 399 307 458 minecraft:polished_blackstone
fill 400 200 418 402 205 418 minecraft:bone_block
fill 404 200 416 417 205 416 minecraft:polished_blackstone
fill 408 200 456 410 205 456 minecraft:bone_block
fill 412 200 418 414 205 418 minecraft:bone_block
fill 416 200 426 416 205 428 minecraft:bone_block
fill 416 200 438 416 205 440 minecraft:bone_block
fill 416 200 450 416 205 452 minecraft:bone_block
setblock 418 200 416 minecraft:deepslate_tiles
fill 418 200 417 418 205 417 minecraft:polished_blackstone
setblock 418 200 418 minecraft:deepslate_tiles
fill 418 200 419 418 205 420 minecraft:polished_blackstone
setblock 418 200 421 minecraft:deepslate_tiles
fill 418 200 424 418 307 424 minecraft:polished_blackstone
fill 418 200 433 418 307 433 minecraft:polished_blackstone
fill 418 200 449 418 205 453 minecraft:polished_blackstone
setblock 418 200 454 minecraft:deepslate_tiles
fill 418 200 455 418 205 455 minecraft:polished_blackstone
fill 376 201 421 376 307 421 minecraft:polished_blackstone
fill 376 201 423 376 205 423 minecraft:polished_blackstone
fill 376 201 425 376 205 425 minecraft:polished_blackstone
fill 376 201 436 376 205 436 minecraft:polished_blackstone
fill 376 201 444 376 307 444 minecraft:polished_blackstone
fill 376 201 446 376 205 446 minecraft:polished_blackstone
fill 376 201 452 376 307 452 minecraft:polished_blackstone
fill 376 201 456 376 307 456 minecraft:polished_blackstone
fill 382 201 416 382 307 416 minecraft:polished_blackstone
fill 385 201 458 385 307 458 minecraft:polished_blackstone
fill 388 201 416 388 307 416 minecraft:polished_blackstone
fill 397 201 416 397 205 416 minecraft:polished_blackstone
fill 418 201 416 418 307 416 minecraft:polished_blackstone
fill 418 201 418 418 205 418 minecraft:polished_blackstone
fill 418 201 421 418 307 421 minecraft:polished_blackstone
fill 418 201 442 418 205 442 minecraft:polished_blackstone
fill 418 201 454 418 205 454 minecraft:polished_blackstone
setblock 379 204 419 minecraft:light[level=12]
setblock 379 204 427 minecraft:light[level=12]
setblock 379 204 435 minecraft:light[level=12]
setblock 379 204 443 minecraft:light[level=12]
setblock 379 204 451 minecraft:light[level=12]
setblock 387 204 419 minecraft:light[level=12]
setblock 387 204 427 minecraft:light[level=12]
setblock 387 204 435 minecraft:light[level=12]
setblock 387 204 443 minecraft:light[level=12]
setblock 387 204 451 minecraft:light[level=12]
setblock 395 204 419 minecraft:light[level=12]
setblock 395 204 427 minecraft:light[level=12]
setblock 395 204 435 minecraft:light[level=12]
setblock 395 204 443 minecraft:light[level=12]
setblock 395 204 451 minecraft:light[level=12]
setblock 403 204 419 minecraft:light[level=12]
setblock 403 204 427 minecraft:light[level=12]
setblock 403 204 435 minecraft:light[level=12]
setblock 403 204 443 minecraft:light[level=12]
setblock 403 204 451 minecraft:light[level=12]
setblock 411 204 419 minecraft:light[level=12]
setblock 411 204 427 minecraft:light[level=12]
setblock 411 204 435 minecraft:light[level=12]
setblock 411 204 443 minecraft:light[level=12]
setblock 411 204 451 minecraft:light[level=12]
fill 377 205 420 377 205 425 minecraft:polished_blackstone
fill 377 205 432 377 205 437 minecraft:polished_blackstone
fill 377 205 444 377 205 449 minecraft:polished_blackstone
fill 377 205 456 377 205 457 minecraft:polished_blackstone
fill 378 205 457 381 205 457 minecraft:polished_blackstone
fill 381 205 417 386 205 417 minecraft:polished_blackstone
fill 388 205 457 393 205 457 minecraft:polished_blackstone
fill 393 205 417 398 205 417 minecraft:polished_blackstone
fill 400 205 457 405 205 457 minecraft:polished_blackstone
fill 405 205 417 410 205 417 minecraft:polished_blackstone
fill 412 205 457 417 205 457 minecraft:polished_blackstone
fill 417 205 417 417 205 422 minecraft:polished_blackstone
fill 417 205 429 417 205 434 minecraft:polished_blackstone
fill 417 205 441 417 205 446 minecraft:polished_blackstone
fill 417 205 453 417 205 456 minecraft:polished_blackstone
fill 376 206 422 376 211 425 minecraft:shroomlight
fill 376 206 426 376 307 433 minecraft:polished_blackstone
fill 376 206 434 376 211 437 minecraft:shroomlight
fill 376 206 438 376 307 443 minecraft:polished_blackstone
fill 376 206 446 376 211 449 minecraft:shroomlight
fill 376 206 450 376 307 451 minecraft:polished_blackstone
fill 376 206 457 376 307 457 minecraft:polished_blackstone
fill 376 206 458 379 211 458 minecraft:shroomlight
fill 377 206 448 383 206 448 minecraft:polished_blackstone
fill 379 206 446 383 207 447 minecraft:polished_blackstone
fill 379 206 449 383 207 450 minecraft:polished_blackstone
fill 380 206 458 384 307 458 minecraft:polished_blackstone
fill 383 206 416 386 211 416 minecraft:shroomlight
fill 387 206 416 387 307 416 minecraft:polished_blackstone
fill 388 206 458 391 211 458 minecraft:shroomlight
fill 392 206 458 395 307 458 minecraft:polished_blackstone
fill 395 206 416 398 211 416 minecraft:shroomlight
fill 400 206 458 403 211 458 minecraft:shroomlight
fill 404 206 416 406 307 416 minecraft:polished_blackstone
fill 404 206 458 406 307 458 minecraft:polished_blackstone
fill 407 206 416 410 211 416 minecraft:shroomlight
fill 408 206 458 411 307 458 minecraft:polished_blackstone
fill 411 206 416 417 307 416 minecraft:polished_blackstone
fill 412 206 458 415 211 458 minecraft:shroomlight
fill 416 206 458 418 307 458 minecraft:polished_blackstone
fill 418 206 417 418 211 420 minecraft:shroomlight
fill 418 206 425 418 307 428 minecraft:polished_blackstone
fill 418 206 429 418 211 432 minecraft:shroomlight
fill 418 206 434 418 307 440 minecraft:polished_blackstone
fill 418 206 441 418 211 444 minecraft:shroomlight
fill 418 206 445 418 307 452 minecraft:polished_blackstone
fill 418 206 453 418 211 456 minecraft:shroomlight
fill 418 206 457 418 307 457 minecraft:polished_blackstone
fill 379 207 448 383 207 448 minecraft:polished_blackstone
fill 380 208 448 382 214 448 minecraft:white_concrete
fill 381 208 447 381 214 447 minecraft:white_concrete
fill 381 208 449 381 214 449 minecraft:white_concrete
fill 376 212 422 376 228 422 minecraft:polished_blackstone
fill 376 212 423 376 212 424 minecraft:shroomlight
fill 376 212 425 376 228 425 minecraft:polished_blackstone
fill 376 212 434 376 228 434 minecraft:polished_blackstone
fill 376 212 435 376 212 436 minecraft:shroomlight
fill 376 212 437 376 228 437 minecraft:polished_blackstone
fill 376 212 446 376 228 446 minecraft:polished_blackstone
fill 376 212 447 376 212 448 minecraft:shroomlight
fill 376 212 449 376 228 449 minecraft:polished_blackstone
fill 376 212 458 376 228 458 minecraft:polished_blackstone
fill 377 212 458 378 212 458 minecraft:shroomlight
setblock 379 212 419 minecraft:light[level=12]
setblock 379 212 427 minecraft:light[level=12]
setblock 379 212 435 minecraft:light[level=12]
setblock 379 212 443 minecraft:light[level=12]
setblock 379 212 451 minecraft:light[level=12]
fill 379 212 458 379 228 458 minecraft:polished_blackstone
fill 383 212 416 383 228 416 minecraft:polished_blackstone
fill 384 212 416 385 212 416 minecraft:shroomlight
fill 386 212 416 386 228 416 minecraft:polished_blackstone
setblock 387 212 419 minecraft:light[level=12]
setblock 387 212 427 minecraft:light[level=12]
setblock 387 212 435 minecraft:light[level=12]
setblock 387 212 443 minecraft:light[level=12]
setblock 387 212 451 minecraft:light[level=12]
fill 388 212 458 388 228 458 minecraft:polished_blackstone
fill 389 212 458 390 212 458 minecraft:shroomlight
fill 391 212 458 391 228 458 minecraft:polished_blackstone
fill 395 212 416 395 228 416 minecraft:polished_blackstone
setblock 395 212 419 minecraft:light[level=12]
setblock 395 212 427 minecraft:light[level=12]
setblock 395 212 435 minecraft:light[level=12]
setblock 395 212 443 minecraft:light[level=12]
setblock 395 212 451 minecraft:light[level=12]
fill 396 212 416 397 212 416 minecraft:shroomlight
fill 398 212 416 398 228 416 minecraft:polished_blackstone
fill 400 212 458 400 228 458 minecraft:polished_blackstone
fill 401 212 458 402 212 458 minecraft:shroomlight
setblock 403 212 419 minecraft:light[level=12]
setblock 403 212 427 minecraft:light[level=12]
setblock 403 212 435 minecraft:light[level=12]
setblock 403 212 443 minecraft:light[level=12]
setblock 403 212 451 minecraft:light[level=12]
fill 403 212 458 403 228 458 minecraft:polished_blackstone
fill 407 212 416 407 228 416 minecraft:polished_blackstone
fill 408 212 416 409 212 416 minecraft:shroomlight
fill 410 212 416 410 228 416 minecraft:polished_blackstone
setblock 411 212 419 minecraft:light[level=12]
setblock 411 212 427 minecraft:light[level=12]
setblock 411 212 435 minecraft:light[level=12]
setblock 411 212 443 minecraft:light[level=12]
setblock 411 212 451 minecraft:light[level=12]
fill 412 212 458 412 228 458 minecraft:polished_blackstone
fill 413 212 458 414 212 458 minecraft:shroomlight
fill 415 212 458 415 228 458 minecraft:polished_blackstone
fill 418 212 417 418 228 417 minecraft:polished_blackstone
fill 418 212 418 418 212 419 minecraft:shroomlight
fill 418 212 420 418 228 420 minecraft:polished_blackstone
fill 418 212 429 418 228 429 minecraft:polished_blackstone
fill 418 212 430 418 212 431 minecraft:shroomlight
fill 418 212 432 418 228 432 minecraft:polished_blackstone
fill 418 212 441 418 228 441 minecraft:polished_blackstone
fill 418 212 442 418 212 443 minecraft:shroomlight
fill 418 212 444 418 228 444 minecraft:polished_blackstone
fill 418 212 453 418 228 453 minecraft:polished_blackstone
fill 418 212 454 418 212 455 minecraft:shroomlight
fill 418 212 456 418 228 456 minecraft:polished_blackstone
fill 376 213 423 376 228 424 minecraft:polished_blackstone
fill 376 213 435 376 228 436 minecraft:polished_blackstone
fill 376 213 447 376 228 448 minecraft:polished_blackstone
fill 377 213 458 378 228 458 minecraft:polished_blackstone
fill 384 213 416 385 228 416 minecraft:polished_blackstone
fill 389 213 458 390 228 458 minecraft:polished_blackstone
fill 396 213 416 397 228 416 minecraft:polished_blackstone
fill 401 213 458 402 228 458 minecraft:polished_blackstone
fill 408 213 416 409 228 416 minecraft:polished_blackstone
fill 413 213 458 414 228 458 minecraft:polished_blackstone
fill 418 213 418 418 228 419 minecraft:polished_blackstone
fill 418 213 430 418 228 431 minecraft:polished_blackstone
fill 418 213 442 418 228 443 minecraft:polished_blackstone
fill 418 213 454 418 228 455 minecraft:polished_blackstone
setblock 381 218 448 minecraft:shroomlight
setblock 379 220 419 minecraft:light[level=12]
setblock 379 220 427 minecraft:light[level=12]
setblock 379 220 435 minecraft:light[level=12]
setblock 379 220 443 minecraft:light[level=12]
setblock 379 220 451 minecraft:light[level=12]
setblock 387 220 419 minecraft:light[level=12]
setblock 387 220 427 minecraft:light[level=12]
setblock 387 220 435 minecraft:light[level=12]
setblock 387 220 443 minecraft:light[level=12]
setblock 387 220 451 minecraft:light[level=12]
setblock 395 220 419 minecraft:light[level=12]
setblock 395 220 427 minecraft:light[level=12]
setblock 395 220 435 minecraft:light[level=12]
setblock 395 220 443 minecraft:light[level=12]
setblock 395 220 451 minecraft:light[level=12]
setblock 403 220 419 minecraft:light[level=12]
setblock 403 220 427 minecraft:light[level=12]
setblock 403 220 435 minecraft:light[level=12]
setblock 403 220 443 minecraft:light[level=12]
setblock 403 220 451 minecraft:light[level=12]
setblock 411 220 419 minecraft:light[level=12]
setblock 411 220 427 minecraft:light[level=12]
setblock 411 220 435 minecraft:light[level=12]
setblock 411 220 443 minecraft:light[level=12]
setblock 411 220 451 minecraft:light[level=12]
fill 381 224 435 396 224 439 minecraft:bone_block
fill 397 224 419 397 224 436 minecraft:bone_block
fill 397 224 438 397 224 455 minecraft:bone_block
fill 398 224 419 398 224 435 minecraft:bone_block
fill 398 224 439 398 224 455 minecraft:bone_block
fill 399 224 419 401 224 434 minecraft:bone_block
fill 399 224 440 401 224 455 minecraft:bone_block
fill 400 224 435 417 224 435 minecraft:bone_block
fill 400 224 439 417 224 439 minecraft:bone_block
fill 401 224 436 417 224 436 minecraft:bone_block
fill 401 224 438 417 224 438 minecraft:bone_block
fill 402 224 437 417 224 437 minecraft:bone_block
fill 377 225 417 380 225 457 minecraft:deepslate_tiles
fill 381 225 417 396 225 434 minecraft:deepslate_tiles
fill 381 225 435 396 225 435 minecraft:polished_blackstone
fill 381 225 436 395 225 438 minecraft:bone_block
fill 381 225 439 396 225 439 minecraft:polished_blackstone
fill 381 225 440 396 225 457 minecraft:deepslate_tiles
fill 396 225 436 396 225 438 minecraft:shroomlight
fill 397 225 417 417 225 418 minecraft:deepslate_tiles
fill 397 225 419 397 225 434 minecraft:polished_blackstone
fill 397 225 435 397 225 436 minecraft:shroomlight
fill 397 225 438 397 225 439 minecraft:shroomlight
fill 397 225 440 397 225 455 minecraft:polished_blackstone
fill 397 225 456 417 225 457 minecraft:deepslate_tiles
fill 398 225 419 400 225 433 minecraft:bone_block
fill 398 225 434 398 225 435 minecraft:shroomlight
fill 398 225 439 398 225 440 minecraft:shroomlight
fill 398 225 441 400 225 455 minecraft:bone_block
fill 399 225 434 400 225 434 minecraft:shroomlight
fill 399 225 440 400 225 440 minecraft:shroomlight
fill 400 225 435 401 225 435 minecraft:shroomlight
fill 400 225 439 401 225 439 minecraft:shroomlight
fill 401 225 419 401 225 434 minecraft:polished_blackstone
fill 401 225 436 402 225 436 minecraft:shroomlight
fill 401 225 438 402 225 438 minecraft:shroomlight
fill 401 225 440 401 225 455 minecraft:polished_blackstone
fill 402 225 419 417 225 434 minecraft:deepslate_tiles
fill 402 225 435 417 225 435 minecraft:polished_blackstone
setblock 402 225 437 minecraft:shroomlight
fill 402 225 439 417 225 439 minecraft:polished_blackstone
fill 402 225 440 417 225 455 minecraft:deepslate_tiles
fill 403 225 436 417 225 438 minecraft:bone_block
setblock 379 228 419 minecraft:light[level=12]
setblock 379 228 427 minecraft:light[level=12]
setblock 379 228 435 minecraft:light[level=12]
setblock 379 228 443 minecraft:light[level=12]
setblock 379 228 451 minecraft:light[level=12]
setblock 387 228 419 minecraft:light[level=12]
setblock 387 228 427 minecraft:light[level=12]
setblock 387 228 435 minecraft:light[level=12]
setblock 387 228 443 minecraft:light[level=12]
setblock 387 228 451 minecraft:light[level=12]
setblock 395 228 419 minecraft:light[level=12]
setblock 395 228 427 minecraft:light[level=12]
setblock 395 228 435 minecraft:light[level=12]
setblock 395 228 443 minecraft:light[level=12]
setblock 395 228 451 minecraft:light[level=12]
setblock 403 228 419 minecraft:light[level=12]
setblock 403 228 427 minecraft:light[level=12]
setblock 403 228 435 minecraft:light[level=12]
setblock 403 228 443 minecraft:light[level=12]
setblock 403 228 451 minecraft:light[level=12]
setblock 411 228 419 minecraft:light[level=12]
setblock 411 228 427 minecraft:light[level=12]
setblock 411 228 435 minecraft:light[level=12]
setblock 411 228 443 minecraft:light[level=12]
setblock 411 228 451 minecraft:light[level=12]
fill 376 229 422 376 231 425 minecraft:shroomlight
fill 376 229 434 376 231 437 minecraft:shroomlight
fill 376 229 446 376 231 449 minecraft:shroomlight
fill 376 229 458 379 231 458 minecraft:shroomlight
fill 377 229 417 379 273 417 minecraft:bone_block
fill 377 229 427 377 273 429 minecraft:bone_block
fill 377 229 439 377 273 441 minecraft:bone_block
fill 377 229 451 377 273 453 minecraft:bone_block
fill 378 229 421 378 229 422 minecraft:polished_blackstone
fill 378 229 453 378 229 455 minecraft:polished_blackstone
fill 379 229 420 382 229 420 minecraft:polished_blackstone
fill 379 229 421 381 273 423 minecraft:bone_block
fill 379 229 424 381 229 424 minecraft:polished_blackstone
fill 379 229 452 382 229 452 minecraft:polished_blackstone
fill 379 229 453 381 273 455 minecraft:bone_block
fill 379 229 456 381 229 456 minecraft:polished_blackstone
setblock 382 229 421 minecraft:polished_blackstone
fill 382 229 422 382 273 422 minecraft:bone_block
setblock 382 229 423 minecraft:polished_blackstone
setblock 382 229 453 minecraft:polished_blackstone
fill 382 229 454 382 273 454 minecraft:bone_block
setblock 382 229 455 minecraft:polished_blackstone
fill 383 229 416 386 231 416 minecraft:shroomlight
setblock 383 229 422 minecraft:polished_blackstone
fill 383 229 457 385 273 457 minecraft:bone_block
fill 388 229 458 391 231 458 minecraft:shroomlight
fill 389 229 417 391 273 417 minecraft:bone_block
fill 395 229 416 398 231 416 minecraft:shroomlight
fill 395 229 457 397 273 457 minecraft:bone_block
fill 400 229 458 403 231 458 minecraft:shroomlight
fill 401 229 417 403 273 417 minecraft:bone_block
fill 407 229 416 410 231 416 minecraft:shroomlight
fill 407 229 457 409 273 457 minecraft:bone_block
fill 412 229 458 415 231 458 minecraft:shroomlight
fill 413 229 417 415 273 417 minecraft:bone_block
fill 417 229 425 417 273 427 minecraft:bone_block
fill 417 229 437 417 273 439 minecraft:bone_block
fill 417 229 449 417 273 451 minecraft:bone_block
fill 418 229 417 418 231 420 minecraft:shroomlight
fill 418 229 429 418 231 432 minecraft:shroomlight
fill 418 229 441 418 231 444 minecraft:shroomlight
fill 418 229 453 418 231 456 minecraft:shroomlight
fill 376 232 422 376 245 422 minecraft:polished_blackstone
fill 376 232 423 376 232 424 minecraft:shroomlight
fill 376 232 425 376 245 425 minecraft:polished_blackstone
fill 376 232 434 376 245 434 minecraft:polished_blackstone
fill 376 232 435 376 232 436 minecraft:shroomlight
fill 376 232 437 376 245 437 minecraft:polished_blackstone
fill 376 232 446 376 245 446 minecraft:polished_blackstone
fill 376 232 447 376 232 448 minecraft:shroomlight
fill 376 232 449 376 245 449 minecraft:polished_blackstone
fill 376 232 458 376 245 458 minecraft:polished_blackstone
fill 377 232 458 378 232 458 minecraft:shroomlight
fill 379 232 458 379 245 458 minecraft:polished_blackstone
fill 383 232 416 383 245 416 minecraft:polished_blackstone
fill 384 232 416 385 232 416 minecraft:shroomlight
fill 386 232 416 386 245 416 minecraft:polished_blackstone
fill 388 232 458 388 245 458 minecraft:polished_blackstone
fill 389 232 458 390 232 458 minecraft:shroomlight
fill 391 232 458 391 245 458 minecraft:polished_blackstone
fill 395 232 416 395 245 416 minecraft:polished_blackstone
fill 396 232 416 397 232 416 minecraft:shroomlight
fill 398 232 416 398 245 416 minecraft:polished_blackstone
fill 400 232 458 400 245 458 minecraft:polished_blackstone
fill 401 232 458 402 232 458 minecraft:shroomlight
fill 403 232 458 403 245 458 minecraft:polished_blackstone
fill 407 232 416 407 245 416 minecraft:polished_blackstone
fill 408 232 416 409 232 416 minecraft:shroomlight
fill 410 232 416 410 245 416 minecraft:polished_blackstone
fill 412 232 458 412 245 458 minecraft:polished_blackstone
fill 413 232 458 414 232 458 minecraft:shroomlight
fill 415 232 458 415 245 458 minecraft:polished_blackstone
fill 418 232 417 418 245 417 minecraft:polished_blackstone
fill 418 232 418 418 232 419 minecraft:shroomlight
fill 418 232 420 418 245 420 minecraft:polished_blackstone
fill 418 232 429 418 245 429 minecraft:polished_blackstone
fill 418 232 430 418 232 431 minecraft:shroomlight
fill 418 232 432 418 245 432 minecraft:polished_blackstone
fill 418 232 441 418 245 441 minecraft:polished_blackstone
fill 418 232 442 418 232 443 minecraft:shroomlight
fill 418 232 444 418 245 444 minecraft:polished_blackstone
fill 418 232 453 418 245 453 minecraft:polished_blackstone
fill 418 232 454 418 232 455 minecraft:shroomlight
fill 418 232 456 418 245 456 minecraft:polished_blackstone
fill 376 233 423 376 245 424 minecraft:polished_blackstone
fill 376 233 435 376 245 436 minecraft:polished_blackstone
fill 376 233 447 376 245 448 minecraft:polished_blackstone
fill 377 233 458 378 245 458 minecraft:polished_blackstone
fill 384 233 416 385 245 416 minecraft:polished_blackstone
fill 389 233 458 390 245 458 minecraft:polished_blackstone
fill 396 233 416 397 245 416 minecraft:polished_blackstone
fill 401 233 458 402 245 458 minecraft:polished_blackstone
fill 408 233 416 409 245 416 minecraft:polished_blackstone
fill 413 233 458 414 245 458 minecraft:polished_blackstone
fill 418 233 418 418 245 419 minecraft:polished_blackstone
fill 418 233 430 418 245 431 minecraft:polished_blackstone
fill 418 233 442 418 245 443 minecraft:polished_blackstone
fill 418 233 454 418 245 455 minecraft:polished_blackstone
setblock 379 236 419 minecraft:light[level=12]
setblock 379 236 427 minecraft:light[level=12]
setblock 379 236 435 minecraft:light[level=12]
setblock 379 236 443 minecraft:light[level=12]
setblock 379 236 451 minecraft:light[level=12]
setblock 387 236 419 minecraft:light[level=12]
setblock 387 236 427 minecraft:light[level=12]
setblock 387 236 435 minecraft:light[level=12]
setblock 387 236 443 minecraft:light[level=12]
setblock 387 236 451 minecraft:light[level=12]
setblock 395 236 419 minecraft:light[level=12]
setblock 395 236 427 minecraft:light[level=12]
setblock 395 236 435 minecraft:light[level=12]
setblock 395 236 443 minecraft:light[level=12]
setblock 395 236 451 minecraft:light[level=12]
fill 396 236 418 396 248 418 minecraft:black_wool
setblock 403 236 419 minecraft:light[level=12]
setblock 403 236 427 minecraft:light[level=12]
setblock 403 236 435 minecraft:light[level=12]
setblock 403 236 443 minecraft:light[level=12]
setblock 403 236 451 minecraft:light[level=12]
setblock 411 236 419 minecraft:light[level=12]
setblock 411 236 427 minecraft:light[level=12]
setblock 411 236 435 minecraft:light[level=12]
setblock 411 236 443 minecraft:light[level=12]
setblock 411 236 451 minecraft:light[level=12]
fill 378 237 421 378 237 422 minecraft:polished_blackstone
fill 378 237 453 378 237 455 minecraft:polished_blackstone
fill 379 237 420 382 237 420 minecraft:polished_blackstone
fill 379 237 424 381 237 424 minecraft:polished_blackstone
fill 379 237 452 382 237 452 minecraft:polished_blackstone
fill 379 237 456 381 237 456 minecraft:polished_blackstone
setblock 382 237 421 minecraft:polished_blackstone
setblock 382 237 423 minecraft:polished_blackstone
setblock 382 237 453 minecraft:polished_blackstone
setblock 382 237 455 minecraft:polished_blackstone
setblock 383 237 422 minecraft:polished_blackstone
fill 394 237 418 395 248 418 minecraft:black_wool
fill 397 237 418 398 248 418 minecraft:black_wool
fill 378 240 426 378 245 428 minecraft:bone_block
fill 378 240 438 378 245 440 minecraft:bone_block
fill 378 240 450 378 245 452 minecraft:bone_block
fill 384 240 456 386 245 456 minecraft:bone_block
fill 388 240 418 390 245 418 minecraft:bone_block
fill 396 240 456 398 245 456 minecraft:bone_block
fill 400 240 418 402 245 418 minecraft:bone_block
fill 408 240 456 410 245 456 minecraft:bone_block
fill 412 240 418 414 245 418 minecraft:bone_block
fill 416 240 426 416 245 428 minecraft:bone_block
fill 416 240 438 416 245 440 minecraft:bone_block
fill 416 240 450 416 245 452 minecraft:bone_block
setblock 379 244 419 minecraft:light[level=12]
setblock 379 244 427 minecraft:light[level=12]
setblock 379 244 435 minecraft:light[level=12]
setblock 379 244 443 minecraft:light[level=12]
setblock 379 244 451 minecraft:light[level=12]
setblock 387 244 419 minecraft:light[level=12]
setblock 387 244 427 minecraft:light[level=12]
setblock 387 244 435 minecraft:light[level=12]
setblock 387 244 443 minecraft:light[level=12]
setblock 387 244 451 minecraft:light[level=12]
setblock 395 244 419 minecraft:light[level=12]
setblock 395 244 427 minecraft:light[level=12]
setblock 395 244 435 minecraft:light[level=12]
setblock 395 244 443 minecraft:light[level=12]
setblock 395 244 451 minecraft:light[level=12]
setblock 403 244 419 minecraft:light[level=12]
setblock 403 244 427 minecraft:light[level=12]
setblock 403 244 435 minecraft:light[level=12]
setblock 403 244 443 minecraft:light[level=12]
setblock 403 244 451 minecraft:light[level=12]
setblock 411 244 419 minecraft:light[level=12]
setblock 411 244 427 minecraft:light[level=12]
setblock 411 244 435 minecraft:light[level=12]
setblock 411 244 443 minecraft:light[level=12]
setblock 411 244 451 minecraft:light[level=12]
fill 377 245 420 377 245 425 minecraft:polished_blackstone
fill 377 245 432 377 245 437 minecraft:polished_blackstone
fill 377 245 444 377 245 449 minecraft:polished_blackstone
fill 377 245 456 377 245 457 minecraft:polished_blackstone
fill 378 245 421 378 245 422 minecraft:polished_blackstone
fill 378 245 453 378 245 455 minecraft:polished_blackstone
fill 378 245 457 381 245 457 minecraft:polished_blackstone
fill 379 245 420 382 245 420 minecraft:polished_blackstone
fill 379 245 424 381 245 424 minecraft:polished_blackstone
fill 379 245 452 382 245 452 minecraft:polished_blackstone
fill 379 245 456 381 245 456 minecraft:polished_blackstone
fill 381 245 417 386 245 417 minecraft:polished_blackstone
setblock 382 245 421 minecraft:polished_blackstone
setblock 382 245 423 minecraft:polished_blackstone
setblock 382 245 453 minecraft:polished_blackstone
setblock 382 245 455 minecraft:polished_blackstone
setblock 383 245 422 minecraft:polished_blackstone
fill 388 245 457 393 245 457 minecraft:polished_blackstone
fill 393 245 417 398 245 417 minecraft:polished_blackstone
fill 400 245 457 405 245 457 minecraft:polished_blackstone
fill 405 245 417 410 245 417 minecraft:polished_blackstone
fill 412 245 457 417 245 457 minecraft:polished_blackstone
fill 417 245 417 417 245 422 minecraft:polished_blackstone
fill 417 245 429 417 245 434 minecraft:polished_blackstone
fill 417 245 441 417 245 446 minecraft:polished_blackstone
fill 417 245 453 417 245 456 minecraft:polished_blackstone
fill 376 246 422 376 251 425 minecraft:shroomlight
fill 376 246 434 376 251 437 minecraft:shroomlight
fill 376 246 446 376 251 449 minecraft:shroomlight
fill 376 246 458 379 251 458 minecraft:shroomlight
fill 383 246 416 386 251 416 minecraft:shroomlight
fill 388 246 458 391 251 458 minecraft:shroomlight
fill 395 246 416 398 251 416 minecraft:shroomlight
fill 400 246 458 403 251 458 minecraft:shroomlight
fill 407 246 416 410 251 416 minecraft:shroomlight
fill 412 246 458 415 251 458 minecraft:shroomlight
fill 418 246 417 418 251 420 minecraft:shroomlight
fill 418 246 429 418 251 432 minecraft:shroomlight
fill 418 246 441 418 251 444 minecraft:shroomlight
fill 418 246 453 418 251 456 minecraft:shroomlight
fill 387 247 455 387 257 455 minecraft:black_wool
fill 385 248 455 386 257 455 minecraft:black_wool
fill 388 248 455 389 257 455 minecraft:black_wool
fill 393 249 418 399 250 418 minecraft:iron_bars
fill 377 250 426 383 250 426 minecraft:polished_blackstone
fill 379 250 424 383 251 425 minecraft:polished_blackstone
fill 379 250 427 383 251 428 minecraft:polished_blackstone
fill 379 251 426 383 251 426 minecraft:polished_blackstone
fill 376 252 422 376 265 422 minecraft:polished_blackstone
fill 376 252 423 376 252 424 minecraft:shroomlight
fill 376 252 425 376 265 425 minecraft:polished_blackstone
fill 376 252 434 376 265 434 minecraft:polished_blackstone
fill 376 252 435 376 252 436 minecraft:shroomlight
fill 376 252 437 376 265 437 minecraft:polished_blackstone
fill 376 252 446 376 265 446 minecraft:polished_blackstone
fill 376 252 447 376 252 448 minecraft:shroomlight
fill 376 252 449 376 265 449 minecraft:polished_blackstone
fill 376 252 458 376 265 458 minecraft:polished_blackstone
fill 377 252 435 377 253 437 minecraft:bone_block
fill 377 252 458 378 252 458 minecraft:shroomlight
setblock 379 252 419 minecraft:light[level=12]
setblock 379 252 427 minecraft:light[level=12]
setblock 379 252 435 minecraft:light[level=12]
setblock 379 252 443 minecraft:light[level=12]
setblock 379 252 451 minecraft:light[level=12]
fill 379 252 458 379 265 458 minecraft:polished_blackstone
fill 380 252 426 382 258 426 minecraft:white_concrete
fill 381 252 425 381 258 425 minecraft:white_concrete
fill 381 252 427 381 258 427 minecraft:white_concrete
fill 383 252 416 383 265 416 minecraft:polished_blackstone
fill 384 252 416 385 252 416 minecraft:shroomlight
fill 386 252 416 386 265 416 minecraft:polished_blackstone
setblock 387 252 419 minecraft:light[level=12]
setblock 387 252 427 minecraft:light[level=12]
setblock 387 252 435 minecraft:light[level=12]
setblock 387 252 443 minecraft:light[level=12]
setblock 387 252 451 minecraft:light[level=12]
fill 388 252 458 388 265 458 minecraft:polished_blackstone
fill 389 252 458 390 252 458 minecraft:shroomlight
fill 391 252 458 391 265 458 minecraft:polished_blackstone
fill 395 252 416 395 265 416 minecraft:polished_blackstone
setblock 395 252 419 minecraft:light[level=12]
setblock 395 252 427 minecraft:light[level=12]
setblock 395 252 435 minecraft:light[level=12]
setblock 395 252 443 minecraft:light[level=12]
setblock 395 252 451 minecraft:light[level=12]
fill 396 252 416 397 252 416 minecraft:shroomlight
fill 398 252 416 398 265 416 minecraft:polished_blackstone
fill 400 252 458 400 265 458 minecraft:polished_blackstone
fill 401 252 458 402 252 458 minecraft:shroomlight
setblock 403 252 419 minecraft:light[level=12]
setblock 403 252 427 minecraft:light[level=12]
setblock 403 252 435 minecraft:light[level=12]
setblock 403 252 443 minecraft:light[level=12]
setblock 403 252 451 minecraft:light[level=12]
fill 403 252 458 403 265 458 minecraft:polished_blackstone
fill 407 252 416 407 265 416 minecraft:polished_blackstone
fill 408 252 416 409 252 416 minecraft:shroomlight
fill 410 252 416 410 265 416 minecraft:polished_blackstone
setblock 411 252 419 minecraft:light[level=12]
setblock 411 252 427 minecraft:light[level=12]
setblock 411 252 435 minecraft:light[level=12]
setblock 411 252 443 minecraft:light[level=12]
setblock 411 252 451 minecraft:light[level=12]
fill 412 252 458 412 265 458 minecraft:polished_blackstone
fill 413 252 458 414 252 458 minecraft:shroomlight
fill 415 252 458 415 265 458 minecraft:polished_blackstone
fill 416 252 435 416 253 437 minecraft:bone_block
fill 417 252 435 417 253 436 minecraft:bone_block
fill 418 252 417 418 265 417 minecraft:polished_blackstone
fill 418 252 418 418 252 419 minecraft:shroomlight
fill 418 252 420 418 265 420 minecraft:polished_blackstone
fill 418 252 429 418 265 429 minecraft:polished_blackstone
fill 418 252 430 418 252 431 minecraft:shroomlight
fill 418 252 432 418 265 432 minecraft:polished_blackstone
fill 418 252 441 418 265 441 minecraft:polished_blackstone
fill 418 252 442 418 252 443 minecraft:shroomlight
fill 418 252 444 418 265 444 minecraft:polished_blackstone
fill 418 252 453 418 265 453 minecraft:polished_blackstone
fill 418 252 454 418 252 455 minecraft:shroomlight
fill 418 252 456 418 265 456 minecraft:polished_blackstone
fill 376 253 423 376 265 424 minecraft:polished_blackstone
fill 376 253 435 376 265 436 minecraft:polished_blackstone
fill 376 253 447 376 265 448 minecraft:polished_blackstone
fill 377 253 458 378 265 458 minecraft:polished_blackstone
fill 378 253 421 378 253 422 minecraft:polished_blackstone
fill 378 253 435 378 254 437 minecraft:bone_block
fill 378 253 453 378 253 455 minecraft:polished_blackstone
fill 379 253 420 382 253 420 minecraft:polished_blackstone
fill 379 253 424 381 253 424 minecraft:polished_blackstone
fill 379 253 436 379 256 436 minecraft:bone_block
fill 379 253 452 382 253 452 minecraft:polished_blackstone
fill 379 253 456 381 253 456 minecraft:polished_blackstone
setblock 382 253 421 minecraft:polished_blackstone
setblock 382 253 423 minecraft:polished_blackstone
setblock 382 253 453 minecraft:polished_blackstone
setblock 382 253 455 minecraft:polished_blackstone
setblock 383 253 422 minecraft:polished_blackstone
fill 384 253 416 385 265 416 minecraft:polished_blackstone
fill 389 253 458 390 265 458 minecraft:polished_blackstone
fill 396 253 416 397 265 416 minecraft:polished_blackstone
fill 401 253 458 402 265 458 minecraft:polished_blackstone
fill 408 253 416 409 265 416 minecraft:polished_blackstone
fill 413 253 458 414 265 458 minecraft:polished_blackstone
fill 414 253 436 415 255 436 minecraft:bone_block
fill 415 253 435 415 254 435 minecraft:bone_block
fill 415 253 437 415 254 437 minecraft:bone_block
fill 418 253 418 418 265 419 minecraft:polished_blackstone
fill 418 253 430 418 265 431 minecraft:polished_blackstone
fill 418 253 442 418 265 443 minecraft:polished_blackstone
fill 418 253 454 418 265 455 minecraft:polished_blackstone
setblock 377 254 436 minecraft:bone_block
fill 379 254 435 379 255 435 minecraft:bone_block
fill 379 254 437 379 255 437 minecraft:bone_block
fill 380 254 436 380 256 436 minecraft:bone_block
fill 413 254 436 413 256 436 minecraft:bone_block
fill 414 254 435 414 255 435 minecraft:bone_block
fill 414 254 437 414 255 437 minecraft:bone_block
setblock 416 254 436 minecraft:bone_block
setblock 417 254 436 minecraft:white_concrete
setblock 377 255 436 minecraft:white_concrete
setblock 378 255 436 minecraft:bone_block
fill 380 255 435 381 256 435 minecraft:bone_block
fill 380 255 437 381 256 437 minecraft:bone_block
fill 381 255 436 381 257 436 minecraft:bone_block
fill 412 255 435 412 256 437 minecraft:bone_block
fill 413 255 435 413 256 435 minecraft:bone_block
fill 413 255 437 413 256 437 minecraft:bone_block
setblock 416 255 436 minecraft:white_concrete
setblock 378 256 436 minecraft:white_concrete
fill 382 256 435 382 257 437 minecraft:bone_block
fill 383 256 436 383 258 436 minecraft:bone_block
fill 410 256 436 411 258 436 minecraft:bone_block
fill 411 256 435 411 257 435 minecraft:bone_block
fill 411 256 437 411 257 437 minecraft:bone_block
setblock 414 256 436 minecraft:bone_block
setblock 415 256 436 minecraft:white_concrete
setblock 380 257 436 minecraft:white_concrete
fill 383 257 435 383 258 435 minecraft:bone_block
fill 383 257 437 383 258 437 minecraft:bone_block
fill 384 257 436 384 259 436 minecraft:bone_block
fill 409 257 436 409 259 436 minecraft:bone_block
fill 410 257 435 410 258 435 minecraft:bone_block
fill 410 257 437 410 258 437 minecraft:bone_block
setblock 412 257 436 minecraft:bone_block
setblock 413 257 436 minecraft:white_concrete
setblock 381 258 436 minecraft:white_concrete
setblock 382 258 436 minecraft:bone_block
fill 384 258 435 385 258 435 minecraft:bone_block
fill 384 258 437 385 258 437 minecraft:bone_block
fill 384 258 455 390 259 455 minecraft:iron_bars
fill 385 258 436 386 260 436 minecraft:bone_block
fill 407 258 436 408 260 436 minecraft:bone_block
fill 408 258 435 409 258 435 minecraft:bone_block
fill 408 258 437 409 258 437 minecraft:bone_block
setblock 412 258 436 minecraft:white_concrete
setblock 383 259 436 minecraft:white_concrete
fill 385 259 435 387 259 435 minecraft:bone_block
fill 385 259 437 387 259 437 minecraft:bone_block
fill 387 259 436 388 261 436 minecraft:bone_block
fill 405 259 436 406 261 436 minecraft:bone_block
fill 406 259 435 408 259 435 minecraft:bone_block
fill 406 259 437 408 259 437 minecraft:bone_block
setblock 410 259 436 minecraft:white_concrete
fill 378 260 426 378 265 428 minecraft:bone_block
fill 378 260 438 378 265 440 minecraft:bone_block
fill 378 260 450 378 265 452 minecraft:bone_block
setblock 379 260 419 minecraft:light[level=12]
setblock 379 260 427 minecraft:light[level=12]
setblock 379 260 435 minecraft:light[level=12]
setblock 379 260 443 minecraft:light[level=12]
setblock 379 260 451 minecraft:light[level=12]
setblock 384 260 436 minecraft:white_concrete
fill 384 260 456 386 265 456 minecraft:bone_block
fill 386 260 435 389 260 435 minecraft:bone_block
fill 386 260 437 389 260 437 minecraft:bone_block
setblock 387 260 419 minecraft:light[level=12]
setblock 387 260 427 minecraft:light[level=12]
setblock 387 260 443 minecraft:light[level=12]
setblock 387 260 451 minecraft:light[level=12]
fill 388 260 418 390 265 418 minecraft:bone_block
fill 389 260 436 390 262 436 minecraft:bone_block
setblock 395 260 419 minecraft:light[level=12]
setblock 395 260 427 minecraft:light[level=12]
setblock 395 260 435 minecraft:light[level=12]
setblock 395 260 443 minecraft:light[level=12]
setblock 395 260 451 minecraft:light[level=12]
fill 396 260 456 398 265 456 minecraft:bone_block
fill 400 260 418 402 265 418 minecraft:bone_block
setblock 403 260 419 minecraft:light[level=12]
setblock 403 260 427 minecraft:light[level=12]
setblock 403 260 435 minecraft:light[level=12]
fill 403 260 436 404 262 436 minecraft:bone_block
setblock 403 260 443 minecraft:light[level=12]
setblock 403 260 451 minecraft:light[level=12]
fill 404 260 435 407 260 435 minecraft:bone_block
fill 404 260 437 407 260 437 minecraft:bone_block
fill 408 260 456 410 265 456 minecraft:bone_block
setblock 409 260 436 minecraft:white_concrete
setblock 411 260 419 minecraft:light[level=12]
setblock 411 260 427 minecraft:light[level=12]
setblock 411 260 435 minecraft:light[level=12]
setblock 411 260 443 minecraft:light[level=12]
setblock 411 260 451 minecraft:light[level=12]
fill 412 260 418 414 265 418 minecraft:bone_block
fill 416 260 426 416 265 428 minecraft:bone_block
fill 416 260 438 416 265 440 minecraft:bone_block
fill 416 260 450 416 265 452 minecraft:bone_block
fill 378 261 421 378 261 422 minecraft:polished_blackstone
fill 378 261 453 378 261 455 minecraft:polished_blackstone
fill 379 261 420 382 261 420 minecraft:polished_blackstone
fill 379 261 424 381 261 424 minecraft:polished_blackstone
fill 379 261 452 382 261 452 minecraft:polished_blackstone
fill 379 261 456 381 261 456 minecraft:polished_blackstone
setblock 382 261 421 minecraft:polished_blackstone
setblock 382 261 423 minecraft:polished_blackstone
setblock 382 261 453 minecraft:polished_blackstone
setblock 382 261 455 minecraft:polished_blackstone
setblock 383 261 422 minecraft:polished_blackstone
setblock 386 261 436 minecraft:white_concrete
fill 388 261 435 392 261 435 minecraft:bone_block
fill 388 261 437 392 261 437 minecraft:bone_block
fill 391 261 436 394 262 436 minecraft:bone_block
fill 400 261 436 402 262 436 minecraft:bone_block
fill 401 261 435 405 261 435 minecraft:bone_block
fill 401 261 437 405 261 437 minecraft:bone_block
setblock 407 261 436 minecraft:white_concrete
setblock 381 262 426 minecraft:shroomlight
fill 387 262 436 388 262 436 minecraft:white_concrete
fill 391 262 435 402 262 435 minecraft:bone_block
fill 391 262 437 394 262 437 minecraft:bone_block
fill 395 262 436 396 263 436 minecraft:bone_block
fill 399 262 436 399 263 436 minecraft:bone_block
fill 401 262 437 402 262 437 minecraft:bone_block
fill 405 262 436 406 262 436 minecraft:white_concrete
fill 389 263 436 391 263 436 minecraft:white_concrete
fill 392 263 436 394 263 436 minecraft:bone_block
fill 394 263 435 399 263 435 minecraft:bone_block
setblock 394 263 437 minecraft:bone_block
fill 400 263 436 401 263 436 minecraft:bone_block
fill 402 263 436 404 263 436 minecraft:white_concrete
fill 393 264 436 396 264 436 minecraft:white_concrete
fill 399 264 436 400 264 436 minecraft:white_concrete
fill 377 265 420 377 265 425 minecraft:polished_blackstone
fill 377 265 432 377 265 437 minecraft:polished_blackstone
fill 377 265 444 377 265 449 minecraft:polished_blackstone
fill 377 265 456 377 265 457 minecraft:polished_blackstone
fill 378 265 457 381 265 457 minecraft:polished_blackstone
fill 381 265 417 386 265 417 minecraft:polished_blackstone
fill 388 265 457 393 265 457 minecraft:polished_blackstone
fill 393 265 417 398 265 417 minecraft:polished_blackstone
fill 400 265 457 405 265 457 minecraft:polished_blackstone
fill 405 265 417 410 265 417 minecraft:polished_blackstone
fill 412 265 457 417 265 457 minecraft:polished_blackstone
fill 417 265 417 417 265 422 minecraft:polished_blackstone
fill 417 265 429 417 265 434 minecraft:polished_blackstone
fill 417 265 441 417 265 446 minecraft:polished_blackstone
fill 417 265 453 417 265 456 minecraft:polished_blackstone
fill 376 266 422 376 271 425 minecraft:shroomlight
fill 376 266 434 376 271 437 minecraft:shroomlight
fill 376 266 446 376 271 449 minecraft:shroomlight
fill 376 266 458 379 271 458 minecraft:shroomlight
fill 383 266 416 386 271 416 minecraft:shroomlight
fill 388 266 458 391 271 458 minecraft:shroomlight
fill 395 266 416 398 271 416 minecraft:shroomlight
fill 400 266 458 403 271 458 minecraft:shroomlight
fill 407 266 416 410 271 416 minecraft:shroomlight
fill 412 266 458 415 271 458 minecraft:shroomlight
fill 418 266 417 418 271 420 minecraft:shroomlight
fill 418 266 429 418 271 432 minecraft:shroomlight
fill 418 266 441 418 271 444 minecraft:shroomlight
fill 418 266 453 418 271 456 minecraft:shroomlight
setblock 379 268 419 minecraft:light[level=12]
setblock 379 268 427 minecraft:light[level=12]
setblock 379 268 435 minecraft:light[level=12]
setblock 379 268 443 minecraft:light[level=12]
setblock 379 268 451 minecraft:light[level=12]
setblock 387 268 419 minecraft:light[level=12]
setblock 387 268 427 minecraft:light[level=12]
setblock 387 268 435 minecraft:light[level=12]
setblock 387 268 443 minecraft:light[level=12]
setblock 387 268 451 minecraft:light[level=12]
setblock 395 268 419 minecraft:light[level=12]
setblock 395 268 427 minecraft:light[level=12]
setblock 395 268 435 minecraft:light[level=12]
setblock 395 268 443 minecraft:light[level=12]
setblock 395 268 451 minecraft:light[level=12]
setblock 403 268 419 minecraft:light[level=12]
setblock 403 268 427 minecraft:light[level=12]
setblock 403 268 435 minecraft:light[level=12]
setblock 403 268 443 minecraft:light[level=12]
setblock 403 268 451 minecraft:light[level=12]
setblock 411 268 419 minecraft:light[level=12]
setblock 411 268 427 minecraft:light[level=12]
setblock 411 268 435 minecraft:light[level=12]
setblock 411 268 443 minecraft:light[level=12]
setblock 411 268 451 minecraft:light[level=12]
fill 377 269 431 383 269 431 minecraft:polished_blackstone
fill 378 269 421 378 269 422 minecraft:polished_blackstone
fill 378 269 453 378 269 455 minecraft:polished_blackstone
fill 379 269 420 382 269 420 minecraft:polished_blackstone
fill 379 269 424 381 269 424 minecraft:polished_blackstone
fill 379 269 429 383 270 430 minecraft:polished_blackstone
fill 379 269 432 383 270 433 minecraft:polished_blackstone
fill 379 269 452 382 269 452 minecraft:polished_blackstone
fill 379 269 456 381 269 456 minecraft:polished_blackstone
setblock 382 269 421 minecraft:polished_blackstone
setblock 382 269 423 minecraft:polished_blackstone
setblock 382 269 453 minecraft:polished_blackstone
setblock 382 269 455 minecraft:polished_blackstone
setblock 383 269 422 minecraft:polished_blackstone
fill 379 270 431 383 270 431 minecraft:polished_blackstone
fill 377 271 430 379 272 430 minecraft:bone_block
fill 377 271 432 379 272 432 minecraft:bone_block
fill 378 271 431 378 272 431 minecraft:bone_block
fill 376 272 422 376 285 422 minecraft:polished_blackstone
fill 376 272 423 376 272 424 minecraft:shroomlight
fill 376 272 425 376 285 425 minecraft:polished_blackstone
fill 376 272 434 376 285 434 minecraft:polished_blackstone
fill 376 272 435 376 272 436 minecraft:shroomlight
fill 376 272 437 376 285 437 minecraft:polished_blackstone
fill 376 272 446 376 285 446 minecraft:polished_blackstone
fill 376 272 447 376 272 448 minecraft:shroomlight
fill 376 272 449 376 285 449 minecraft:polished_blackstone
fill 376 272 458 376 285 458 minecraft:polished_blackstone
fill 377 272 458 378 272 458 minecraft:shroomlight
fill 378 272 454 378 273 454 minecraft:white_concrete
fill 379 272 420 381 273 420 minecraft:white_concrete
fill 379 272 431 380 273 431 minecraft:bone_block
fill 379 272 452 381 273 452 minecraft:white_concrete
fill 379 272 458 379 285 458 minecraft:polished_blackstone
fill 380 272 424 381 273 424 minecraft:white_concrete
fill 380 272 456 381 273 456 minecraft:white_concrete
fill 382 272 421 382 273 421 minecraft:white_concrete
fill 382 272 423 382 273 423 minecraft:white_concrete
fill 382 272 453 382 273 453 minecraft:white_concrete
fill 382 272 455 382 273 455 minecraft:white_concrete
fill 383 272 416 383 285 416 minecraft:polished_blackstone
fill 384 272 416 385 272 416 minecraft:shroomlight
fill 386 272 416 386 285 416 minecraft:polished_blackstone
fill 388 272 458 388 285 458 minecraft:polished_blackstone
fill 389 272 458 390 272 458 minecraft:shroomlight
fill 391 272 458 391 285 458 minecraft:polished_blackstone
fill 395 272 416 395 285 416 minecraft:polished_blackstone
fill 396 272 416 397 272 416 minecraft:shroomlight
fill 398 272 416 398 285 416 minecraft:polished_blackstone
fill 400 272 458 400 285 458 minecraft:polished_blackstone
fill 401 272 458 402 272 458 minecraft:shroomlight
fill 403 272 458 403 285 458 minecraft:polished_blackstone
fill 407 272 416 407 285 416 minecraft:polished_blackstone
fill 408 272 416 409 272 416 minecraft:shroomlight
fill 410 272 416 410 285 416 minecraft:polished_blackstone
fill 412 272 458 412 285 458 minecraft:polished_blackstone
fill 413 272 458 414 272 458 minecraft:shroomlight
fill 415 272 458 415 285 458 minecraft:polished_blackstone
fill 418 272 417 418 285 417 minecraft:polished_blackstone
fill 418 272 418 418 272 419 minecraft:shroomlight
fill 418 272 420 418 285 420 minecraft:polished_blackstone
fill 418 272 429 418 285 429 minecraft:polished_blackstone
fill 418 272 430 418 272 431 minecraft:shroomlight
fill 418 272 432 418 285 432 minecraft:polished_blackstone
fill 418 272 441 418 285 441 minecraft:polished_blackstone
fill 418 272 442 418 272 443 minecraft:shroomlight
fill 418 272 444 418 285 444 minecraft:polished_blackstone
fill 418 272 453 418 285 453 minecraft:polished_blackstone
fill 418 272 454 418 272 455 minecraft:shroomlight
fill 418 272 456 418 285 456 minecraft:polished_blackstone
fill 376 273 423 376 285 424 minecraft:polished_blackstone
fill 376 273 435 376 285 436 minecraft:polished_blackstone
fill 376 273 447 376 285 448 minecraft:polished_blackstone
fill 377 273 458 378 285 458 minecraft:polished_blackstone
setblock 381 273 431 minecraft:bone_block
fill 384 273 416 385 285 416 minecraft:polished_blackstone
fill 389 273 458 390 285 458 minecraft:polished_blackstone
fill 396 273 416 397 285 416 minecraft:polished_blackstone
fill 401 273 458 402 285 458 minecraft:polished_blackstone
fill 408 273 416 409 285 416 minecraft:polished_blackstone
fill 413 273 458 414 285 458 minecraft:polished_blackstone
fill 418 273 418 418 285 419 minecraft:polished_blackstone
fill 418 273 430 418 285 431 minecraft:polished_blackstone
fill 418 273 442 418 285 443 minecraft:polished_blackstone
fill 418 273 454 418 285 455 minecraft:polished_blackstone
setblock 379 276 419 minecraft:light[level=12]
setblock 379 276 427 minecraft:light[level=12]
setblock 379 276 435 minecraft:light[level=12]
setblock 379 276 443 minecraft:light[level=12]
setblock 379 276 451 minecraft:light[level=12]
setblock 387 276 419 minecraft:light[level=12]
setblock 387 276 427 minecraft:light[level=12]
setblock 387 276 435 minecraft:light[level=12]
setblock 387 276 443 minecraft:light[level=12]
setblock 387 276 451 minecraft:light[level=12]
setblock 395 276 419 minecraft:light[level=12]
setblock 395 276 427 minecraft:light[level=12]
setblock 395 276 435 minecraft:light[level=12]
setblock 395 276 443 minecraft:light[level=12]
setblock 395 276 451 minecraft:light[level=12]
setblock 403 276 419 minecraft:light[level=12]
setblock 403 276 427 minecraft:light[level=12]
setblock 403 276 435 minecraft:light[level=12]
setblock 403 276 443 minecraft:light[level=12]
setblock 403 276 451 minecraft:light[level=12]
setblock 411 276 419 minecraft:light[level=12]
setblock 411 276 427 minecraft:light[level=12]
setblock 411 276 435 minecraft:light[level=12]
setblock 411 276 443 minecraft:light[level=12]
setblock 411 276 451 minecraft:light[level=12]
fill 382 279 439 394 279 439 minecraft:red_stained_glass
fill 385 279 432 387 280 432 minecraft:red_stained_glass
fill 385 279 438 394 279 438 minecraft:red_stained_glass
fill 385 279 440 394 279 440 minecraft:red_stained_glass
fill 385 279 446 387 280 446 minecraft:red_stained_glass
fill 386 279 433 389 280 433 minecraft:red_stained_glass
fill 386 279 445 389 280 445 minecraft:red_stained_glass
fill 387 279 434 391 279 434 minecraft:red_stained_glass
fill 387 279 444 391 279 444 minecraft:red_stained_glass
fill 388 279 435 406 279 435 minecraft:red_stained_glass
fill 388 279 443 406 279 443 minecraft:red_stained_glass
fill 389 279 436 405 279 436 minecraft:red_stained_glass
fill 389 279 442 405 279 442 minecraft:red_stained_glass
fill 390 279 427 390 280 429 minecraft:red_stained_glass
fill 390 279 449 390 280 451 minecraft:red_stained_glass
fill 391 279 428 391 280 431 minecraft:red_stained_glass
fill 391 279 437 395 279 437 minecraft:red_stained_glass
fill 391 279 441 395 279 441 minecraft:red_stained_glass
fill 391 279 447 391 280 450 minecraft:red_stained_glass
fill 392 279 429 392 279 433 minecraft:red_stained_glass
fill 392 279 445 392 279 449 minecraft:red_stained_glass
fill 393 279 430 393 279 434 minecraft:red_stained_glass
fill 393 279 444 393 279 448 minecraft:red_stained_glass
fill 394 279 431 394 279 434 minecraft:red_stained_glass
fill 394 279 444 394 279 447 minecraft:red_stained_glass
fill 395 279 433 401 279 434 minecraft:red_stained_glass
fill 395 279 444 401 279 445 minecraft:red_stained_glass
fill 396 279 427 398 279 432 minecraft:red_stained_glass
fill 396 279 446 398 279 451 minecraft:red_stained_glass
fill 397 279 424 397 280 426 minecraft:red_stained_glass
fill 397 279 452 397 280 454 minecraft:red_stained_glass
fill 399 279 437 403 279 437 minecraft:red_stained_glass
fill 399 279 441 403 279 441 minecraft:red_stained_glass
fill 400 279 431 402 279 432 minecraft:red_stained_glass
fill 400 279 438 409 279 440 minecraft:red_stained_glass
fill 400 279 446 402 279 447 minecraft:red_stained_glass
fill 401 279 430 403 280 430 minecraft:red_stained_glass
fill 401 279 448 403 280 448 minecraft:red_stained_glass
fill 402 279 429 404 280 429 minecraft:red_stained_glass
fill 402 279 433 402 280 433 minecraft:red_stained_glass
fill 402 279 445 402 280 445 minecraft:red_stained_glass
fill 402 279 449 404 280 449 minecraft:red_stained_glass
fill 403 279 428 404 280 428 minecraft:red_stained_glass
fill 403 279 431 403 280 431 minecraft:red_stained_glass
fill 403 279 434 407 279 434 minecraft:red_stained_glass
fill 403 279 444 407 279 444 minecraft:red_stained_glass
fill 403 279 447 403 280 447 minecraft:red_stained_glass
fill 403 279 450 404 280 450 minecraft:red_stained_glass
fill 404 279 427 404 280 427 minecraft:red_stained_glass
fill 404 279 451 404 280 451 minecraft:red_stained_glass
fill 405 279 433 408 280 433 minecraft:red_stained_glass
fill 405 279 445 408 280 445 minecraft:red_stained_glass
fill 407 279 432 409 280 432 minecraft:red_stained_glass
fill 407 279 446 409 280 446 minecraft:red_stained_glass
fill 410 279 439 412 280 439 minecraft:red_stained_glass
fill 377 280 417 381 280 457 minecraft:polished_blackstone
fill 382 280 417 384 280 438 minecraft:polished_blackstone
fill 382 280 439 386 280 439 minecraft:red_stained_glass
fill 382 280 440 384 280 457 minecraft:polished_blackstone
fill 385 280 417 389 280 431 minecraft:polished_blackstone
fill 385 280 433 385 280 437 minecraft:polished_blackstone
fill 385 280 438 389 280 438 minecraft:red_stained_glass
fill 385 280 440 389 280 440 minecraft:red_stained_glass
fill 385 280 441 385 280 445 minecraft:polished_blackstone
fill 385 280 447 389 280 457 minecraft:polished_blackstone
fill 386 280 434 386 280 437 minecraft:polished_blackstone
fill 386 280 441 386 280 444 minecraft:polished_blackstone
fill 387 280 434 388 280 434 minecraft:red_stained_glass
fill 387 280 435 387 280 437 minecraft:polished_blackstone
fill 387 280 439 392 280 439 minecraft:purple_stained_glass
fill 387 280 441 387 280 443 minecraft:polished_blackstone
fill 387 280 444 388 280 444 minecraft:red_stained_glass
fill 388 280 432 391 280 432 minecraft:polished_blackstone
setblock 388 280 435 minecraft:red_stained_glass
fill 388 280 436 388 280 437 minecraft:polished_blackstone
fill 388 280 441 388 280 442 minecraft:polished_blackstone
setblock 388 280 443 minecraft:red_stained_glass
fill 388 280 446 391 280 446 minecraft:polished_blackstone
fill 389 280 434 389 280 435 minecraft:purple_stained_glass
setblock 389 280 436 minecraft:red_stained_glass
fill 389 280 437 390 280 437 minecraft:polished_blackstone
fill 389 280 441 390 280 441 minecraft:polished_blackstone
setblock 389 280 442 minecraft:red_stained_glass
fill 389 280 443 389 280 444 minecraft:purple_stained_glass
fill 390 280 417 396 280 426 minecraft:polished_blackstone
fill 390 280 430 390 280 431 minecraft:polished_blackstone
fill 390 280 433 391 280 433 minecraft:polished_blackstone
fill 390 280 434 391 280 434 minecraft:red_stained_glass
fill 390 280 435 392 280 436 minecraft:purple_stained_glass
fill 390 280 438 393 280 438 minecraft:purple_stained_glass
fill 390 280 440 393 280 440 minecraft:purple_stained_glass
fill 390 280 442 392 280 443 minecraft:purple_stained_glass
fill 390 280 444 391 280 444 minecraft:red_stained_glass
fill 390 280 445 391 280 445 minecraft:polished_blackstone
fill 390 280 447 390 280 448 minecraft:polished_blackstone
fill 390 280 452 396 280 457 minecraft:polished_blackstone
fill 391 280 427 395 280 427 minecraft:polished_blackstone
setblock 391 280 437 minecraft:red_stained_glass
setblock 391 280 441 minecraft:red_stained_glass
fill 391 280 451 395 280 451 minecraft:polished_blackstone
fill 392 280 428 395 280 428 minecraft:polished_blackstone
fill 392 280 429 392 280 430 minecraft:red_stained_glass
fill 392 280 431 393 280 431 minecraft:purple_stained_glass
fill 392 280 432 392 280 433 minecraft:red_stained_glass
setblock 392 280 434 minecraft:polished_blackstone
fill 392 280 437 393 280 437 minecraft:purple_stained_glass
fill 392 280 441 393 280 441 minecraft:purple_stained_glass
setblock 392 280 444 minecraft:polished_blackstone
fill 392 280 445 392 280 446 minecraft:red_stained_glass
fill 392 280 447 393 280 447 minecraft:purple_stained_glass
fill 392 280 448 392 280 449 minecraft:red_stained_glass
fill 392 280 450 395 280 450 minecraft:polished_blackstone
fill 393 280 429 395 280 429 minecraft:polished_blackstone
setblock 393 280 430 minecraft:red_stained_glass
fill 393 280 432 394 280 434 minecraft:purple_stained_glass
setblock 393 280 435 minecraft:red_stained_glass
fill 393 280 436 394 280 436 minecraft:purple_stained_glass
setblock 393 280 439 minecraft:bone_block
fill 393 280 442 394 280 442 minecraft:purple_stained_glass
setblock 393 280 443 minecraft:red_stained_glass
fill 393 280 444 394 280 446 minecraft:purple_stained_glass
setblock 393 280 448 minecraft:red_stained_glass
fill 393 280 449 395 280 449 minecraft:polished_blackstone
fill 394 280 430 395 280 430 minecraft:polished_blackstone
setblock 394 280 431 minecraft:red_stained_glass
fill 394 280 435 396 280 435 minecraft:purple_stained_glass
fill 394 280 437 394 280 441 minecraft:shroomlight
fill 394 280 443 396 280 443 minecraft:purple_stained_glass
setblock 394 280 447 minecraft:red_stained_glass
fill 394 280 448 395 280 448 minecraft:polished_blackstone
fill 395 280 431 395 280 432 minecraft:polished_blackstone
setblock 395 280 433 minecraft:red_stained_glass
fill 395 280 434 401 280 434 minecraft:purple_stained_glass
fill 395 280 436 395 280 437 minecraft:shroomlight
fill 395 280 441 395 280 442 minecraft:shroomlight
fill 395 280 444 401 280 444 minecraft:purple_stained_glass
setblock 395 280 445 minecraft:red_stained_glass
fill 395 280 446 395 280 447 minecraft:polished_blackstone
fill 396 280 427 396 280 431 minecraft:red_stained_glass
fill 396 280 432 398 280 433 minecraft:purple_stained_glass
fill 396 280 436 399 280 436 minecraft:shroomlight
fill 396 280 442 399 280 442 minecraft:shroomlight
fill 396 280 445 398 280 446 minecraft:purple_stained_glass
fill 396 280 447 396 280 451 minecraft:red_stained_glass
fill 397 280 417 417 280 423 minecraft:polished_blackstone
fill 397 280 427 398 280 428 minecraft:red_stained_glass
fill 397 280 429 397 280 431 minecraft:purple_stained_glass
setblock 397 280 435 minecraft:bone_block
setblock 397 280 443 minecraft:bone_block
fill 397 280 447 397 280 449 minecraft:purple_stained_glass
fill 397 280 450 398 280 451 minecraft:red_stained_glass
fill 397 280 455 417 280 457 minecraft:polished_blackstone
fill 398 280 424 417 280 426 minecraft:polished_blackstone
fill 398 280 429 398 280 431 minecraft:red_stained_glass
fill 398 280 435 400 280 435 minecraft:purple_stained_glass
fill 398 280 443 400 280 443 minecraft:purple_stained_glass
fill 398 280 447 398 280 449 minecraft:red_stained_glass
fill 398 280 452 417 280 454 minecraft:polished_blackstone
fill 399 280 427 399 280 432 minecraft:polished_blackstone
setblock 399 280 433 minecraft:red_stained_glass
fill 399 280 437 400 280 437 minecraft:shroomlight
fill 399 280 441 400 280 441 minecraft:shroomlight
setblock 399 280 445 minecraft:red_stained_glass
fill 399 280 446 399 280 451 minecraft:polished_blackstone
fill 400 280 427 400 280 430 minecraft:polished_blackstone
setblock 400 280 431 minecraft:red_stained_glass
fill 400 280 432 401 280 433 minecraft:purple_stained_glass
fill 400 280 436 404 280 436 minecraft:purple_stained_glass
fill 400 280 438 400 280 440 minecraft:shroomlight
fill 400 280 442 404 280 442 minecraft:purple_stained_glass
fill 400 280 445 401 280 446 minecraft:purple_stained_glass
setblock 400 280 447 minecraft:red_stained_glass
fill 400 280 448 400 280 451 minecraft:polished_blackstone
fill 401 280 427 401 280 429 minecraft:polished_blackstone
fill 401 280 431 402 280 431 minecraft:purple_stained_glass
setblock 401 280 435 minecraft:red_stained_glass
fill 401 280 437 402 280 438 minecraft:purple_stained_glass
setblock 401 280 439 minecraft:bone_block
fill 401 280 440 402 280 441 minecraft:purple_stained_glass
setblock 401 280 443 minecraft:red_stained_glass
fill 401 280 447 402 280 447 minecraft:purple_stained_glass
fill 401 280 449 401 280 451 minecraft:polished_blackstone
fill 402 280 427 402 280 428 minecraft:polished_blackstone
setblock 402 280 432 minecraft:red_stained_glass
setblock 402 280 434 minecraft:polished_blackstone
fill 402 280 435 405 280 435 minecraft:purple_stained_glass
fill 402 280 439 407 280 439 minecraft:purple_stained_glass
fill 402 280 443 405 280 443 minecraft:purple_stained_glass
setblock 402 280 444 minecraft:polished_blackstone
setblock 402 280 446 minecraft:red_stained_glass
fill 402 280 450 402 280 451 minecraft:polished_blackstone
setblock 403 280 427 minecraft:polished_blackstone
fill 403 280 432 404 280 433 minecraft:polished_blackstone
fill 403 280 434 404 280 434 minecraft:red_stained_glass
setblock 403 280 437 minecraft:red_stained_glass
fill 403 280 438 404 280 438 minecraft:purple_stained_glass
fill 403 280 440 404 280 440 minecraft:purple_stained_glass
setblock 403 280 441 minecraft:red_stained_glass
fill 403 280 444 404 280 444 minecraft:red_stained_glass
fill 403 280 445 404 280 446 minecraft:polished_blackstone
setblock 403 280 451 minecraft:polished_blackstone
fill 404 280 430 417 280 431 minecraft:polished_blackstone
fill 404 280 437 417 280 437 minecraft:polished_blackstone
fill 404 280 441 417 280 441 minecraft:polished_blackstone
fill 404 280 447 417 280 448 minecraft:polished_blackstone
fill 405 280 427 417 280 429 minecraft:polished_blackstone
fill 405 280 432 406 280 432 minecraft:polished_blackstone
setblock 405 280 434 minecraft:purple_stained_glass
setblock 405 280 436 minecraft:red_stained_glass
fill 405 280 438 409 280 438 minecraft:red_stained_glass
fill 405 280 440 409 280 440 minecraft:red_stained_glass
setblock 405 280 442 minecraft:red_stained_glass
setblock 405 280 444 minecraft:purple_stained_glass
fill 405 280 446 406 280 446 minecraft:polished_blackstone
fill 405 280 449 417 280 451 minecraft:polished_blackstone
fill 406 280 434 406 280 435 minecraft:red_stained_glass
fill 406 280 436 417 280 436 minecraft:polished_blackstone
fill 406 280 442 417 280 442 minecraft:polished_blackstone
fill 406 280 443 406 280 444 minecraft:red_stained_glass
setblock 407 280 434 minecraft:red_stained_glass
fill 407 280 435 417 280 435 minecraft:polished_blackstone
fill 407 280 443 417 280 443 minecraft:polished_blackstone
setblock 407 280 444 minecraft:red_stained_glass
fill 408 280 434 417 280 434 minecraft:polished_blackstone
fill 408 280 439 409 280 439 minecraft:red_stained_glass
fill 408 280 444 417 280 444 minecraft:polished_blackstone
fill 409 280 433 417 280 433 minecraft:polished_blackstone
fill 409 280 445 417 280 445 minecraft:polished_blackstone
fill 410 280 432 417 280 432 minecraft:polished_blackstone
fill 410 280 438 417 280 438 minecraft:polished_blackstone
fill 410 280 440 417 280 440 minecraft:polished_blackstone
fill 410 280 446 417 280 446 minecraft:polished_blackstone
fill 413 280 439 417 280 439 minecraft:polished_blackstone
fill 377 284 417 379 300 417 minecraft:bone_block
fill 377 284 427 377 300 429 minecraft:bone_block
fill 377 284 439 377 300 441 minecraft:bone_block
fill 377 284 451 377 300 453 minecraft:bone_block
fill 378 284 426 378 285 428 minecraft:bone_block
fill 378 284 438 378 285 440 minecraft:bone_block
fill 378 284 450 378 285 452 minecraft:bone_block
setblock 379 284 419 minecraft:light[level=12]
setblock 379 284 427 minecraft:light[level=12]
setblock 379 284 435 minecraft:light[level=12]
setblock 379 284 443 minecraft:light[level=12]
setblock 379 284 451 minecraft:light[level=12]
fill 383 284 457 385 300 457 minecraft:bone_block
fill 384 284 456 386 285 456 minecraft:bone_block
setblock 387 284 419 minecraft:light[level=12]
setblock 387 284 427 minecraft:light[level=12]
setblock 387 284 435 minecraft:light[level=12]
setblock 387 284 443 minecraft:light[level=12]
setblock 387 284 451 minecraft:light[level=12]
fill 388 284 418 390 285 418 minecraft:bone_block
fill 389 284 417 391 300 417 minecraft:bone_block
setblock 395 284 419 minecraft:light[level=12]
setblock 395 284 427 minecraft:light[level=12]
setblock 395 284 435 minecraft:light[level=12]
setblock 395 284 443 minecraft:light[level=12]
setblock 395 284 451 minecraft:light[level=12]
fill 395 284 457 397 300 457 minecraft:bone_block
fill 396 284 456 398 285 456 minecraft:bone_block
fill 400 284 418 402 285 418 minecraft:bone_block
fill 401 284 417 403 300 417 minecraft:bone_block
setblock 403 284 419 minecraft:light[level=12]
setblock 403 284 427 minecraft:light[level=12]
setblock 403 284 435 minecraft:light[level=12]
setblock 403 284 443 minecraft:light[level=12]
setblock 403 284 451 minecraft:light[level=12]
fill 407 284 457 409 300 457 minecraft:bone_block
fill 408 284 456 410 285 456 minecraft:bone_block
setblock 411 284 419 minecraft:light[level=12]
setblock 411 284 427 minecraft:light[level=12]
setblock 411 284 435 minecraft:light[level=12]
setblock 411 284 443 minecraft:light[level=12]
setblock 411 284 451 minecraft:light[level=12]
fill 412 284 418 414 285 418 minecraft:bone_block
fill 413 284 417 415 300 417 minecraft:bone_block
fill 416 284 426 416 285 428 minecraft:bone_block
fill 416 284 438 416 285 440 minecraft:bone_block
fill 416 284 450 416 285 452 minecraft:bone_block
fill 417 284 425 417 300 427 minecraft:bone_block
fill 417 284 437 417 300 439 minecraft:bone_block
fill 417 284 449 417 300 451 minecraft:bone_block
fill 377 285 420 377 285 425 minecraft:polished_blackstone
fill 377 285 432 377 285 437 minecraft:polished_blackstone
fill 377 285 444 377 285 449 minecraft:polished_blackstone
fill 377 285 456 377 285 457 minecraft:polished_blackstone
fill 378 285 457 381 285 457 minecraft:polished_blackstone
fill 381 285 417 386 285 417 minecraft:polished_blackstone
fill 388 285 457 393 285 457 minecraft:polished_blackstone
fill 393 285 417 398 285 417 minecraft:polished_blackstone
fill 396 285 450 400 286 454 minecraft:polished_blackstone
setblock 398 285 455 minecraft:polished_blackstone
fill 400 285 457 405 285 457 minecraft:polished_blackstone
fill 405 285 417 410 285 417 minecraft:polished_blackstone
fill 412 285 457 417 285 457 minecraft:polished_blackstone
fill 417 285 417 417 285 422 minecraft:polished_blackstone
fill 417 285 429 417 285 434 minecraft:polished_blackstone
fill 417 285 441 417 285 446 minecraft:polished_blackstone
fill 417 285 453 417 285 456 minecraft:polished_blackstone
fill 376 286 422 376 291 425 minecraft:shroomlight
fill 376 286 434 376 291 437 minecraft:shroomlight
fill 376 286 446 376 291 449 minecraft:shroomlight
fill 376 286 458 379 291 458 minecraft:shroomlight
fill 383 286 416 386 291 416 minecraft:shroomlight
fill 388 286 458 391 291 458 minecraft:shroomlight
fill 395 286 416 398 291 416 minecraft:shroomlight
fill 400 286 458 403 291 458 minecraft:shroomlight
fill 407 286 416 410 291 416 minecraft:shroomlight
fill 412 286 458 415 291 458 minecraft:shroomlight
fill 418 286 417 418 291 420 minecraft:shroomlight
fill 418 286 429 418 291 432 minecraft:shroomlight
fill 418 286 441 418 291 444 minecraft:shroomlight
fill 418 286 453 418 291 456 minecraft:shroomlight
fill 394 287 451 396 288 451 minecraft:bone_block
fill 394 287 453 396 288 453 minecraft:bone_block
fill 395 287 452 395 288 452 minecraft:bone_block
fill 396 288 452 397 289 452 minecraft:bone_block
fill 398 289 452 398 290 452 minecraft:bone_block
fill 399 290 452 400 291 452 minecraft:bone_block
fill 400 291 451 402 292 451 minecraft:bone_block
fill 400 291 453 402 292 453 minecraft:bone_block
fill 401 291 452 401 292 452 minecraft:bone_block
fill 376 292 422 376 307 422 minecraft:polished_blackstone
fill 376 292 423 376 292 424 minecraft:shroomlight
fill 376 292 425 376 307 425 minecraft:polished_blackstone
fill 376 292 434 376 307 434 minecraft:polished_blackstone
fill 376 292 435 376 292 436 minecraft:shroomlight
fill 376 292 437 376 307 437 minecraft:polished_blackstone
fill 376 292 446 376 307 446 minecraft:polished_blackstone
fill 376 292 447 376 292 448 minecraft:shroomlight
fill 376 292 449 376 307 449 minecraft:polished_blackstone
fill 376 292 458 376 307 458 minecraft:polished_blackstone
fill 377 292 458 378 292 458 minecraft:shroomlight
setblock 379 292 419 minecraft:light[level=12]
setblock 379 292 427 minecraft:light[level=12]
setblock 379 292 435 minecraft:light[level=12]
setblock 379 292 443 minecraft:light[level=12]
setblock 379 292 451 minecraft:light[level=12]
fill 379 292 458 379 307 458 minecraft:polished_blackstone
fill 383 292 416 383 307 416 minecraft:polished_blackstone
fill 384 292 416 385 292 416 minecraft:shroomlight
fill 386 292 416 386 307 416 minecraft:polished_blackstone
setblock 387 292 419 minecraft:light[level=12]
setblock 387 292 427 minecraft:light[level=12]
setblock 387 292 435 minecraft:light[level=12]
setblock 387 292 443 minecraft:light[level=12]
setblock 387 292 451 minecraft:light[level=12]
fill 388 292 458 388 307 458 minecraft:polished_blackstone
fill 389 292 458 390 292 458 minecraft:shroomlight
fill 391 292 458 391 307 458 minecraft:polished_blackstone
fill 395 292 416 395 307 416 minecraft:polished_blackstone
setblock 395 292 419 minecraft:light[level=12]
setblock 395 292 427 minecraft:light[level=12]
setblock 395 292 435 minecraft:light[level=12]
setblock 395 292 443 minecraft:light[level=12]
setblock 395 292 451 minecraft:light[level=12]
fill 396 292 416 397 292 416 minecraft:shroomlight
fill 398 292 416 398 307 416 minecraft:polished_blackstone
fill 400 292 458 400 307 458 minecraft:polished_blackstone
fill 401 292 458 402 292 458 minecraft:shroomlight
setblock 403 292 419 minecraft:light[level=12]
setblock 403 292 427 minecraft:light[level=12]
setblock 403 292 435 minecraft:light[level=12]
setblock 403 292 443 minecraft:light[level=12]
setblock 403 292 451 minecraft:light[level=12]
fill 403 292 458 403 307 458 minecraft:polished_blackstone
fill 407 292 416 407 307 416 minecraft:polished_blackstone
fill 408 292 416 409 292 416 minecraft:shroomlight
fill 410 292 416 410 307 416 minecraft:polished_blackstone
setblock 411 292 419 minecraft:light[level=12]
setblock 411 292 427 minecraft:light[level=12]
setblock 411 292 435 minecraft:light[level=12]
setblock 411 292 443 minecraft:light[level=12]
setblock 411 292 451 minecraft:light[level=12]
fill 412 292 458 412 307 458 minecraft:polished_blackstone
fill 413 292 458 414 292 458 minecraft:shroomlight
fill 415 292 458 415 307 458 minecraft:polished_blackstone
fill 418 292 417 418 307 417 minecraft:polished_blackstone
fill 418 292 418 418 292 419 minecraft:shroomlight
fill 418 292 420 418 307 420 minecraft:polished_blackstone
fill 418 292 429 418 307 429 minecraft:polished_blackstone
fill 418 292 430 418 292 431 minecraft:shroomlight
fill 418 292 432 418 307 432 minecraft:polished_blackstone
fill 418 292 441 418 307 441 minecraft:polished_blackstone
fill 418 292 442 418 292 443 minecraft:shroomlight
fill 418 292 444 418 307 444 minecraft:polished_blackstone
fill 418 292 453 418 307 453 minecraft:polished_blackstone
fill 418 292 454 418 292 455 minecraft:shroomlight
fill 418 292 456 418 307 456 minecraft:polished_blackstone
fill 376 293 423 376 307 424 minecraft:polished_blackstone
fill 376 293 435 376 307 436 minecraft:polished_blackstone
fill 376 293 447 376 307 448 minecraft:polished_blackstone
fill 377 293 458 378 307 458 minecraft:polished_blackstone
fill 384 293 416 385 307 416 minecraft:polished_blackstone
fill 389 293 458 390 307 458 minecraft:polished_blackstone
fill 396 293 416 397 307 416 minecraft:polished_blackstone
fill 401 293 458 402 307 458 minecraft:polished_blackstone
fill 408 293 416 409 307 416 minecraft:polished_blackstone
fill 413 293 458 414 307 458 minecraft:polished_blackstone
fill 418 293 418 418 307 419 minecraft:polished_blackstone
fill 418 293 430 418 307 431 minecraft:polished_blackstone
fill 418 293 442 418 307 443 minecraft:polished_blackstone
fill 418 293 454 418 307 455 minecraft:polished_blackstone
fill 377 299 444 377 300 446 minecraft:bone_block
fill 416 299 444 417 300 446 minecraft:bone_block
fill 378 300 426 378 300 428 minecraft:bone_block
fill 378 300 438 378 300 440 minecraft:bone_block
fill 378 300 444 378 300 446 minecraft:bone_block
fill 378 300 450 378 300 452 minecraft:bone_block
setblock 379 300 419 minecraft:light[level=12]
setblock 379 300 427 minecraft:light[level=12]
setblock 379 300 435 minecraft:light[level=12]
setblock 379 300 443 minecraft:light[level=12]
setblock 379 300 445 minecraft:bone_block
setblock 379 300 451 minecraft:light[level=12]
fill 384 300 456 386 300 456 minecraft:bone_block
setblock 387 300 419 minecraft:light[level=12]
setblock 387 300 427 minecraft:light[level=12]
setblock 387 300 435 minecraft:light[level=12]
setblock 387 300 443 minecraft:light[level=12]
setblock 387 300 451 minecraft:light[level=12]
fill 388 300 418 390 300 418 minecraft:bone_block
setblock 395 300 419 minecraft:light[level=12]
setblock 395 300 427 minecraft:light[level=12]
setblock 395 300 435 minecraft:light[level=12]
setblock 395 300 443 minecraft:light[level=12]
setblock 395 300 451 minecraft:light[level=12]
fill 396 300 456 398 300 456 minecraft:bone_block
fill 400 300 418 402 300 418 minecraft:bone_block
setblock 403 300 419 minecraft:light[level=12]
setblock 403 300 427 minecraft:light[level=12]
setblock 403 300 435 minecraft:light[level=12]
setblock 403 300 443 minecraft:light[level=12]
setblock 403 300 451 minecraft:light[level=12]
fill 408 300 456 410 300 456 minecraft:bone_block
setblock 411 300 419 minecraft:light[level=12]
setblock 411 300 427 minecraft:light[level=12]
setblock 411 300 435 minecraft:light[level=12]
setblock 411 300 443 minecraft:light[level=12]
setblock 411 300 451 minecraft:light[level=12]
fill 412 300 418 414 300 418 minecraft:bone_block
fill 414 300 445 415 300 445 minecraft:bone_block
setblock 415 300 444 minecraft:bone_block
setblock 415 300 446 minecraft:bone_block
fill 416 300 426 416 300 428 minecraft:bone_block
fill 416 300 438 416 300 440 minecraft:bone_block
fill 416 300 450 416 300 452 minecraft:bone_block
