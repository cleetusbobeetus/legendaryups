fill 89 262 492 89 269 492 minecraft:white_concrete
fill 89 262 500 89 269 500 minecraft:white_concrete
fill 83 263 486 83 263 491 minecraft:black_concrete
fill 83 263 500 88 263 500 minecraft:quartz_block
fill 84 263 492 84 263 499 minecraft:quartz_block
fill 84 263 501 88 264 502 minecraft:quartz_block
fill 85 263 493 85 263 499 minecraft:quartz_block
fill 85 263 503 88 264 503 minecraft:quartz_block
fill 86 263 493 86 263 495 minecraft:quartz_block
fill 86 263 497 86 263 499 minecraft:quartz_block
fill 87 263 494 88 263 495 minecraft:quartz_block
fill 87 263 498 87 263 499 minecraft:quartz_block
setblock 88 263 499 minecraft:quartz_block
fill 88 263 504 88 264 504 minecraft:quartz_block
fill 77 264 500 83 264 501 minecraft:quartz_block
fill 78 264 502 83 264 503 minecraft:quartz_block
fill 80 264 504 85 264 504 minecraft:quartz_block
fill 83 264 489 83 264 496 minecraft:black_concrete
fill 84 264 498 84 264 500 minecraft:quartz_block
setblock 84 264 503 minecraft:quartz_block
fill 85 264 499 85 264 500 minecraft:quartz_block
setblock 86 264 500 minecraft:quartz_block
setblock 50 265 466 minecraft:light[level=14]
setblock 50 265 474 minecraft:light[level=14]
setblock 50 265 482 minecraft:light[level=14]
setblock 50 265 490 minecraft:light[level=14]
setblock 50 265 498 minecraft:light[level=14]
setblock 58 265 466 minecraft:light[level=14]
setblock 58 265 474 minecraft:light[level=14]
setblock 58 265 482 minecraft:light[level=14]
setblock 58 265 490 minecraft:light[level=14]
setblock 58 265 498 minecraft:light[level=14]
setblock 66 265 466 minecraft:light[level=14]
setblock 66 265 474 minecraft:light[level=14]
setblock 66 265 482 minecraft:light[level=14]
setblock 66 265 490 minecraft:light[level=14]
setblock 66 265 498 minecraft:light[level=14]
fill 72 265 500 79 265 500 minecraft:quartz_block
fill 73 265 501 77 265 504 minecraft:quartz_block
setblock 74 265 466 minecraft:light[level=14]
setblock 74 265 474 minecraft:light[level=14]
setblock 74 265 482 minecraft:light[level=14]
setblock 74 265 490 minecraft:light[level=14]
setblock 74 265 498 minecraft:light[level=14]
fill 78 265 501 80 265 503 minecraft:quartz_block
fill 79 265 499 83 265 499 minecraft:black_concrete
fill 80 265 504 82 267 504 minecraft:quartz_block
fill 81 265 502 81 265 503 minecraft:quartz_block
setblock 82 265 466 minecraft:light[level=14]
setblock 82 265 474 minecraft:light[level=14]
setblock 82 265 482 minecraft:light[level=14]
setblock 82 265 490 minecraft:light[level=14]
setblock 82 265 498 minecraft:light[level=14]
fill 83 265 494 83 265 498 minecraft:black_concrete
fill 48 266 464 48 267 469 minecraft:quartz_block
fill 48 266 472 49 266 477 minecraft:quartz_block
fill 48 266 480 49 266 485 minecraft:quartz_block
fill 48 266 488 49 266 493 minecraft:quartz_block
fill 48 266 496 49 266 501 minecraft:quartz_block
fill 48 266 504 53 267 504 minecraft:quartz_block
fill 49 266 465 49 266 471 minecraft:quartz_block
fill 49 266 478 49 266 479 minecraft:quartz_block
fill 49 266 486 49 266 487 minecraft:quartz_block
fill 49 266 494 49 266 495 minecraft:quartz_block
fill 49 266 502 49 266 503 minecraft:quartz_block
fill 50 266 465 87 266 465 minecraft:quartz_block
fill 50 266 503 88 266 503 minecraft:quartz_block
fill 51 266 464 56 267 464 minecraft:quartz_block
fill 56 266 504 61 267 504 minecraft:quartz_block
fill 59 266 464 64 267 464 minecraft:quartz_block
fill 64 266 504 69 267 504 minecraft:quartz_block
fill 67 266 464 72 267 464 minecraft:quartz_block
fill 68 266 500 74 266 502 minecraft:quartz_block
fill 72 266 504 77 267 504 minecraft:quartz_block
fill 75 266 464 80 267 464 minecraft:quartz_block
fill 75 266 499 82 266 499 minecraft:black_concrete
setblock 75 266 502 minecraft:quartz_block
fill 83 266 464 88 267 464 minecraft:quartz_block
fill 83 266 504 85 267 504 minecraft:quartz_block
fill 87 266 466 87 266 502 minecraft:quartz_block
fill 88 266 467 88 267 472 minecraft:quartz_block
fill 88 266 475 88 267 480 minecraft:quartz_block
fill 88 266 483 88 267 488 minecraft:quartz_block
fill 88 266 491 88 267 496 minecraft:quartz_block
fill 88 266 499 88 267 502 minecraft:quartz_block
fill 88 266 504 88 267 504 minecraft:quartz_block
fill 48 267 472 48 267 477 minecraft:quartz_block
fill 48 267 480 48 267 485 minecraft:quartz_block
fill 48 267 488 48 267 493 minecraft:quartz_block
fill 48 267 496 48 267 501 minecraft:quartz_block
fill 64 267 501 70 267 503 minecraft:quartz_block
fill 65 267 500 70 267 500 minecraft:quartz_block
fill 71 267 499 76 267 499 minecraft:black_concrete
setblock 88 267 503 minecraft:quartz_block
fill 48 268 472 50 269 472 minecraft:iron_block
fill 58 268 504 61 268 504 minecraft:quartz_block
fill 59 268 502 66 268 503 minecraft:quartz_block
fill 60 268 500 66 268 501 minecraft:quartz_block
fill 64 268 504 66 268 504 minecraft:quartz_block
fill 67 268 499 72 268 499 minecraft:black_concrete
fill 51 269 504 53 270 504 minecraft:quartz_block
fill 52 269 503 61 269 503 minecraft:quartz_block
fill 53 269 501 61 269 502 minecraft:quartz_block
fill 54 269 500 62 269 500 minecraft:quartz_block
fill 56 269 504 60 269 504 minecraft:quartz_block
setblock 62 269 501 minecraft:quartz_block
fill 63 269 499 68 269 499 minecraft:black_concrete
fill 47 270 468 47 273 468 minecraft:sea_lantern
fill 47 270 476 47 273 476 minecraft:sea_lantern
fill 47 270 484 47 273 484 minecraft:sea_lantern
fill 47 270 492 47 273 492 minecraft:sea_lantern
fill 47 270 500 47 273 500 minecraft:sea_lantern
fill 48 270 498 52 270 501 minecraft:quartz_block
fill 48 270 504 50 270 504 minecraft:quartz_block
fill 49 270 502 55 270 503 minecraft:quartz_block
fill 50 270 497 52 271 497 minecraft:quartz_block
fill 50 270 505 50 273 505 minecraft:sea_lantern
fill 51 270 496 52 271 496 minecraft:quartz_block
fill 53 270 500 56 270 501 minecraft:quartz_block
fill 54 270 463 54 273 463 minecraft:sea_lantern
setblock 56 270 502 minecraft:quartz_block
setblock 57 270 500 minecraft:quartz_block
fill 58 270 505 58 273 505 minecraft:sea_lantern
fill 59 270 499 65 270 499 minecraft:black_concrete
fill 62 270 463 62 273 463 minecraft:sea_lantern
fill 66 270 505 66 273 505 minecraft:sea_lantern
fill 70 270 463 70 273 463 minecraft:sea_lantern
fill 74 270 505 74 273 505 minecraft:sea_lantern
fill 78 270 463 78 273 463 minecraft:sea_lantern
fill 82 270 505 82 273 505 minecraft:sea_lantern
fill 86 270 463 86 273 463 minecraft:sea_lantern
fill 89 270 468 89 273 468 minecraft:sea_lantern
fill 89 270 476 89 273 476 minecraft:sea_lantern
fill 89 270 484 89 273 484 minecraft:sea_lantern
fill 89 270 492 89 273 492 minecraft:sea_lantern
fill 89 270 500 89 273 500 minecraft:sea_lantern
fill 48 271 492 52 271 493 minecraft:quartz_block
fill 48 271 496 49 271 501 minecraft:quartz_block
fill 49 271 494 52 271 495 minecraft:quartz_block
fill 50 271 491 52 272 491 minecraft:quartz_block
setblock 50 271 496 minecraft:quartz_block
fill 50 271 498 50 271 500 minecraft:quartz_block
fill 51 271 498 51 271 499 minecraft:quartz_block
setblock 52 271 498 minecraft:quartz_block
fill 53 271 498 53 272 499 minecraft:black_concrete
fill 54 271 499 61 271 499 minecraft:black_concrete
fill 48 272 488 49 272 493 minecraft:quartz_block
fill 49 272 487 52 273 487 minecraft:quartz_block
fill 49 272 494 50 272 494 minecraft:quartz_block
fill 50 272 488 52 272 490 minecraft:quartz_block
fill 50 272 492 51 272 493 minecraft:quartz_block
fill 52 272 486 52 273 486 minecraft:quartz_block
setblock 52 272 492 minecraft:quartz_block
fill 53 272 493 53 272 497 minecraft:black_concrete
fill 54 272 499 55 272 499 minecraft:black_concrete
fill 48 273 482 51 273 485 minecraft:quartz_block
fill 48 273 488 49 273 489 minecraft:quartz_block
fill 49 273 486 51 273 486 minecraft:quartz_block
setblock 50 273 466 minecraft:light[level=14]
setblock 50 273 474 minecraft:light[level=14]
fill 50 273 488 52 273 488 minecraft:quartz_block
setblock 50 273 490 minecraft:light[level=14]
setblock 50 273 498 minecraft:light[level=14]
fill 52 273 483 52 273 485 minecraft:quartz_block
fill 53 273 489 53 273 495 minecraft:black_concrete
setblock 58 273 466 minecraft:light[level=14]
setblock 58 273 474 minecraft:light[level=14]
setblock 58 273 482 minecraft:light[level=14]
setblock 58 273 490 minecraft:light[level=14]
setblock 58 273 498 minecraft:light[level=14]
setblock 66 273 466 minecraft:light[level=14]
setblock 66 273 474 minecraft:light[level=14]
setblock 66 273 482 minecraft:light[level=14]
setblock 66 273 490 minecraft:light[level=14]
setblock 66 273 498 minecraft:light[level=14]
setblock 74 273 466 minecraft:light[level=14]
setblock 74 273 474 minecraft:light[level=14]
setblock 74 273 482 minecraft:light[level=14]
setblock 74 273 490 minecraft:light[level=14]
setblock 74 273 498 minecraft:light[level=14]
setblock 82 273 466 minecraft:light[level=14]
setblock 82 273 474 minecraft:light[level=14]
setblock 82 273 482 minecraft:light[level=14]
setblock 82 273 490 minecraft:light[level=14]
setblock 82 273 498 minecraft:light[level=14]
fill 47 274 468 47 283 468 minecraft:white_concrete
fill 47 274 476 47 283 476 minecraft:white_concrete
fill 47 274 484 47 283 484 minecraft:white_concrete
fill 47 274 492 47 283 492 minecraft:white_concrete
fill 47 274 500 47 283 500 minecraft:white_concrete
fill 50 274 505 50 283 505 minecraft:white_concrete
fill 54 274 463 54 283 463 minecraft:white_concrete
fill 58 274 505 58 283 505 minecraft:white_concrete
fill 62 274 463 62 283 463 minecraft:white_concrete
fill 66 274 505 66 283 505 minecraft:white_concrete
fill 70 274 463 70 283 463 minecraft:white_concrete
fill 74 274 505 74 283 505 minecraft:white_concrete
fill 78 274 463 78 283 463 minecraft:white_concrete
fill 82 274 505 82 283 505 minecraft:white_concrete
fill 86 274 463 86 283 463 minecraft:white_concrete
fill 89 274 468 89 283 468 minecraft:white_concrete
fill 89 274 476 89 283 476 minecraft:white_concrete
fill 89 274 484 89 283 484 minecraft:white_concrete
fill 89 274 492 89 283 492 minecraft:white_concrete
fill 89 274 500 89 283 500 minecraft:white_concrete
fill 48 279 464 48 280 464 minecraft:quartz_block
fill 48 279 465 48 280 467 minecraft:white_concrete
fill 48 279 468 48 280 470 minecraft:quartz_block
fill 48 279 471 48 280 473 minecraft:white_concrete
fill 48 279 474 48 280 476 minecraft:quartz_block
fill 48 279 477 48 280 479 minecraft:white_concrete
fill 48 279 480 48 280 482 minecraft:quartz_block
fill 48 279 483 48 280 485 minecraft:white_concrete
fill 48 279 486 48 280 488 minecraft:quartz_block
fill 48 279 489 48 280 491 minecraft:white_concrete
fill 48 279 492 48 280 494 minecraft:quartz_block
fill 48 279 495 48 280 497 minecraft:white_concrete
fill 48 279 498 48 280 500 minecraft:quartz_block
fill 48 279 501 48 280 503 minecraft:white_concrete
fill 48 279 504 48 280 504 minecraft:quartz_block
fill 49 279 464 51 280 464 minecraft:white_concrete
fill 49 279 465 51 280 467 minecraft:quartz_block
fill 49 279 468 51 280 470 minecraft:white_concrete
fill 49 279 471 51 280 473 minecraft:quartz_block
fill 49 279 474 51 280 476 minecraft:white_concrete
fill 49 279 477 51 280 479 minecraft:quartz_block
fill 49 279 480 51 280 482 minecraft:white_concrete
fill 49 279 483 51 280 485 minecraft:quartz_block
fill 49 279 486 51 280 488 minecraft:white_concrete
fill 49 279 489 51 280 491 minecraft:quartz_block
fill 49 279 492 51 280 494 minecraft:white_concrete
fill 49 279 495 51 280 497 minecraft:quartz_block
fill 49 279 498 51 280 500 minecraft:white_concrete
fill 49 279 501 51 280 503 minecraft:quartz_block
fill 49 279 504 51 280 504 minecraft:white_concrete
fill 52 279 464 54 280 464 minecraft:quartz_block
fill 52 279 465 54 280 467 minecraft:white_concrete
fill 52 279 468 54 280 470 minecraft:quartz_block
fill 52 279 471 54 280 473 minecraft:white_concrete
fill 52 279 474 54 280 476 minecraft:quartz_block
fill 52 279 477 54 280 479 minecraft:white_concrete
fill 52 279 480 54 280 482 minecraft:quartz_block
fill 52 279 483 54 280 485 minecraft:white_concrete
fill 52 279 486 54 280 488 minecraft:quartz_block
fill 52 279 489 54 280 491 minecraft:white_concrete
fill 52 279 492 54 280 494 minecraft:quartz_block
fill 52 279 495 54 280 497 minecraft:white_concrete
fill 52 279 498 54 280 500 minecraft:quartz_block
fill 52 279 501 54 280 503 minecraft:white_concrete
fill 52 279 504 54 280 504 minecraft:quartz_block
fill 55 279 464 57 280 464 minecraft:white_concrete
fill 55 279 465 57 280 467 minecraft:quartz_block
fill 55 279 468 57 280 470 minecraft:white_concrete
fill 55 279 471 57 280 473 minecraft:quartz_block
fill 55 279 474 57 280 476 minecraft:white_concrete
fill 55 279 477 57 280 479 minecraft:quartz_block
fill 55 279 480 57 280 482 minecraft:white_concrete
fill 55 279 483 57 280 485 minecraft:quartz_block
fill 55 279 486 57 280 488 minecraft:white_concrete
fill 55 279 489 57 280 491 minecraft:quartz_block
fill 55 279 492 57 280 494 minecraft:white_concrete
fill 55 279 495 57 280 497 minecraft:quartz_block
fill 55 279 498 57 280 500 minecraft:white_concrete
fill 55 279 501 57 280 503 minecraft:quartz_block
fill 55 279 504 57 280 504 minecraft:white_concrete
fill 58 279 464 60 280 464 minecraft:quartz_block
fill 58 279 465 60 280 467 minecraft:white_concrete
fill 58 279 468 60 280 470 minecraft:quartz_block
fill 58 279 471 60 280 473 minecraft:white_concrete
fill 58 279 474 60 280 476 minecraft:quartz_block
fill 58 279 477 60 280 479 minecraft:white_concrete
fill 58 279 480 60 280 482 minecraft:quartz_block
fill 58 279 483 60 280 485 minecraft:white_concrete
fill 58 279 486 60 280 488 minecraft:quartz_block
fill 58 279 489 60 280 491 minecraft:white_concrete
fill 58 279 492 60 280 494 minecraft:quartz_block
fill 58 279 495 60 280 497 minecraft:white_concrete
fill 58 279 498 60 280 500 minecraft:quartz_block
fill 58 279 501 60 280 503 minecraft:white_concrete
fill 58 279 504 60 280 504 minecraft:quartz_block
fill 61 279 464 63 280 464 minecraft:white_concrete
fill 61 279 465 63 280 467 minecraft:quartz_block
fill 61 279 468 63 280 470 minecraft:white_concrete
fill 61 279 471 63 280 473 minecraft:quartz_block
fill 61 279 474 63 280 476 minecraft:white_concrete
fill 61 279 477 63 280 479 minecraft:quartz_block
fill 61 279 480 63 280 482 minecraft:white_concrete
fill 61 279 483 63 280 485 minecraft:quartz_block
fill 61 279 486 63 280 488 minecraft:white_concrete
fill 61 279 489 63 280 491 minecraft:quartz_block
fill 61 279 492 63 280 494 minecraft:white_concrete
fill 61 279 495 63 280 497 minecraft:quartz_block
fill 61 279 498 63 280 500 minecraft:white_concrete
fill 61 279 501 63 280 503 minecraft:quartz_block
fill 61 279 504 63 280 504 minecraft:white_concrete
fill 64 279 464 66 280 464 minecraft:quartz_block
fill 64 279 465 66 280 467 minecraft:white_concrete
fill 64 279 468 66 280 470 minecraft:quartz_block
fill 64 279 471 66 280 473 minecraft:white_concrete
fill 64 279 474 66 280 476 minecraft:quartz_block
fill 64 279 477 66 280 479 minecraft:white_concrete
fill 64 279 480 66 280 482 minecraft:quartz_block
fill 64 279 483 66 280 485 minecraft:white_concrete
fill 64 279 486 66 280 488 minecraft:quartz_block
fill 64 279 489 66 280 491 minecraft:white_concrete
fill 64 279 492 66 280 494 minecraft:quartz_block
fill 64 279 495 66 280 497 minecraft:white_concrete
fill 64 279 498 66 280 500 minecraft:quartz_block
fill 64 279 501 66 280 503 minecraft:white_concrete
fill 64 279 504 66 280 504 minecraft:quartz_block
fill 67 279 464 69 280 464 minecraft:white_concrete
fill 67 279 465 69 280 467 minecraft:quartz_block
fill 67 279 468 69 280 470 minecraft:white_concrete
fill 67 279 471 69 280 473 minecraft:quartz_block
fill 67 279 474 69 280 476 minecraft:white_concrete
fill 67 279 477 69 280 479 minecraft:quartz_block
fill 67 279 480 67 279 482 minecraft:white_concrete
fill 67 279 483 67 279 485 minecraft:quartz_block
fill 67 279 486 69 279 488 minecraft:white_concrete
fill 67 279 489 69 280 491 minecraft:quartz_block
fill 67 279 492 69 280 494 minecraft:white_concrete
fill 67 279 495 69 280 497 minecraft:quartz_block
fill 67 279 498 69 280 500 minecraft:white_concrete
fill 67 279 501 69 280 503 minecraft:quartz_block
fill 67 279 504 69 280 504 minecraft:white_concrete
fill 68 279 480 68 279 481 minecraft:white_concrete
setblock 68 279 485 minecraft:quartz_block
setblock 69 279 480 minecraft:white_concrete
fill 70 279 464 72 280 464 minecraft:quartz_block
fill 70 279 465 72 280 467 minecraft:white_concrete
fill 70 279 468 72 280 470 minecraft:quartz_block
fill 70 279 471 72 280 473 minecraft:white_concrete
fill 70 279 474 72 280 476 minecraft:quartz_block
fill 70 279 477 72 280 479 minecraft:white_concrete
fill 70 279 480 72 279 480 minecraft:quartz_block
fill 70 279 486 72 279 488 minecraft:quartz_block
fill 70 279 489 72 280 491 minecraft:white_concrete
fill 70 279 492 72 280 494 minecraft:quartz_block
fill 70 279 495 72 280 497 minecraft:white_concrete
fill 70 279 498 72 280 500 minecraft:quartz_block
fill 70 279 501 72 280 503 minecraft:white_concrete
fill 70 279 504 72 280 504 minecraft:quartz_block
setblock 72 279 481 minecraft:quartz_block
setblock 72 279 485 minecraft:white_concrete
fill 73 279 464 75 280 464 minecraft:white_concrete
fill 73 279 465 75 280 467 minecraft:quartz_block
fill 73 279 468 75 280 470 minecraft:white_concrete
fill 73 279 471 75 280 473 minecraft:quartz_block
fill 73 279 474 75 280 476 minecraft:white_concrete
fill 73 279 477 75 280 479 minecraft:quartz_block
fill 73 279 480 75 279 482 minecraft:white_concrete
fill 73 279 483 75 279 485 minecraft:quartz_block
fill 73 279 486 75 280 488 minecraft:white_concrete
fill 73 279 489 75 280 491 minecraft:quartz_block
fill 73 279 492 75 280 494 minecraft:white_concrete
fill 73 279 495 75 280 497 minecraft:quartz_block
fill 73 279 498 75 280 500 minecraft:white_concrete
fill 73 279 501 75 280 503 minecraft:quartz_block
fill 73 279 504 75 280 504 minecraft:white_concrete
fill 76 279 464 78 280 464 minecraft:quartz_block
fill 76 279 465 78 280 467 minecraft:white_concrete
fill 76 279 468 78 280 470 minecraft:quartz_block
fill 76 279 471 78 280 473 minecraft:white_concrete
fill 76 279 474 78 280 476 minecraft:quartz_block
fill 76 279 477 78 280 479 minecraft:white_concrete
fill 76 279 480 78 280 482 minecraft:quartz_block
fill 76 279 483 78 280 485 minecraft:white_concrete
fill 76 279 486 78 280 488 minecraft:quartz_block
fill 76 279 489 78 280 491 minecraft:white_concrete
fill 76 279 492 78 280 494 minecraft:quartz_block
fill 76 279 495 78 280 497 minecraft:white_concrete
fill 76 279 498 78 280 500 minecraft:quartz_block
fill 76 279 501 78 280 503 minecraft:white_concrete
fill 76 279 504 78 280 504 minecraft:quartz_block
fill 79 279 464 81 280 464 minecraft:white_concrete
fill 79 279 465 81 280 467 minecraft:quartz_block
fill 79 279 468 81 280 470 minecraft:white_concrete
fill 79 279 471 81 280 473 minecraft:quartz_block
fill 79 279 474 81 280 476 minecraft:white_concrete
fill 79 279 477 81 280 479 minecraft:quartz_block
fill 79 279 480 81 280 482 minecraft:white_concrete
fill 79 279 483 81 280 485 minecraft:quartz_block
fill 79 279 486 81 280 488 minecraft:white_concrete
fill 79 279 489 81 280 491 minecraft:quartz_block
fill 79 279 492 81 280 494 minecraft:white_concrete
fill 79 279 495 81 280 497 minecraft:quartz_block
fill 79 279 498 81 280 500 minecraft:white_concrete
fill 79 279 501 81 280 503 minecraft:quartz_block
fill 79 279 504 81 280 504 minecraft:white_concrete
fill 82 279 464 84 280 464 minecraft:quartz_block
fill 82 279 465 84 280 467 minecraft:white_concrete
fill 82 279 468 84 280 470 minecraft:quartz_block
fill 82 279 471 84 280 473 minecraft:white_concrete
fill 82 279 474 84 280 476 minecraft:quartz_block
fill 82 279 477 84 280 479 minecraft:white_concrete
fill 82 279 480 84 280 482 minecraft:quartz_block
fill 82 279 483 84 280 485 minecraft:white_concrete
fill 82 279 486 84 280 488 minecraft:quartz_block
fill 82 279 489 84 280 491 minecraft:white_concrete
fill 82 279 492 84 280 494 minecraft:quartz_block
fill 82 279 495 84 280 497 minecraft:white_concrete
fill 82 279 498 84 280 500 minecraft:quartz_block
fill 82 279 501 84 280 503 minecraft:white_concrete
fill 82 279 504 84 280 504 minecraft:quartz_block
fill 85 279 464 87 280 464 minecraft:white_concrete
fill 85 279 465 87 280 467 minecraft:quartz_block
fill 85 279 468 87 280 470 minecraft:white_concrete
fill 85 279 471 87 280 473 minecraft:quartz_block
fill 85 279 474 87 280 476 minecraft:white_concrete
fill 85 279 477 87 280 479 minecraft:quartz_block
fill 85 279 480 87 280 482 minecraft:white_concrete
fill 85 279 483 87 280 485 minecraft:quartz_block
fill 85 279 486 87 280 488 minecraft:white_concrete
fill 85 279 489 87 280 491 minecraft:quartz_block
fill 85 279 492 87 280 494 minecraft:white_concrete
fill 85 279 495 87 280 497 minecraft:quartz_block
fill 85 279 498 87 280 500 minecraft:white_concrete
fill 85 279 501 87 280 503 minecraft:quartz_block
fill 85 279 504 87 280 504 minecraft:white_concrete
fill 88 279 464 88 280 464 minecraft:quartz_block
fill 88 279 465 88 280 467 minecraft:white_concrete
fill 88 279 468 88 280 470 minecraft:quartz_block
fill 88 279 471 88 280 473 minecraft:white_concrete
fill 88 279 474 88 280 476 minecraft:quartz_block
fill 88 279 477 88 280 479 minecraft:white_concrete
fill 88 279 480 88 280 482 minecraft:quartz_block
fill 88 279 483 88 280 485 minecraft:white_concrete
fill 88 279 486 88 280 488 minecraft:quartz_block
fill 88 279 489 88 280 491 minecraft:white_concrete
fill 88 279 492 88 280 494 minecraft:quartz_block
fill 88 279 495 88 280 497 minecraft:white_concrete
fill 88 279 498 88 280 500 minecraft:quartz_block
fill 88 279 501 88 280 503 minecraft:white_concrete
fill 88 279 504 88 280 504 minecraft:quartz_block
setblock 67 280 480 minecraft:white_concrete
fill 67 280 481 67 280 485 minecraft:sea_lantern
fill 67 280 486 67 280 488 minecraft:white_concrete
fill 68 280 480 68 280 481 minecraft:sea_lantern
fill 68 280 485 68 280 486 minecraft:sea_lantern
fill 68 280 487 69 280 488 minecraft:white_concrete
fill 69 280 480 72 280 480 minecraft:sea_lantern
fill 69 280 486 72 280 486 minecraft:sea_lantern
fill 70 280 487 72 280 488 minecraft:quartz_block
fill 72 280 481 73 280 481 minecraft:sea_lantern
fill 72 280 485 73 280 485 minecraft:sea_lantern
fill 73 280 480 75 280 480 minecraft:white_concrete
fill 73 280 482 73 280 484 minecraft:sea_lantern
fill 74 280 481 75 280 482 minecraft:white_concrete
fill 74 280 483 75 280 485 minecraft:quartz_block
setblock 50 281 466 minecraft:light[level=14]
setblock 50 281 474 minecraft:light[level=14]
setblock 50 281 482 minecraft:light[level=14]
setblock 50 281 490 minecraft:light[level=14]
setblock 50 281 498 minecraft:light[level=14]
setblock 58 281 466 minecraft:light[level=14]
setblock 58 281 474 minecraft:light[level=14]
setblock 58 281 482 minecraft:light[level=14]
setblock 58 281 490 minecraft:light[level=14]
setblock 58 281 498 minecraft:light[level=14]
setblock 66 281 466 minecraft:light[level=14]
setblock 66 281 474 minecraft:light[level=14]
setblock 66 281 482 minecraft:light[level=14]
setblock 66 281 490 minecraft:light[level=14]
setblock 66 281 498 minecraft:light[level=14]
setblock 74 281 466 minecraft:light[level=14]
setblock 74 281 474 minecraft:light[level=14]
setblock 74 281 482 minecraft:light[level=14]
setblock 74 281 490 minecraft:light[level=14]
setblock 74 281 498 minecraft:light[level=14]
setblock 82 281 466 minecraft:light[level=14]
setblock 82 281 474 minecraft:light[level=14]
setblock 82 281 482 minecraft:light[level=14]
setblock 82 281 490 minecraft:light[level=14]
setblock 82 281 498 minecraft:light[level=14]
fill 47 284 468 47 289 468 minecraft:sea_lantern
fill 47 284 476 47 289 476 minecraft:sea_lantern
fill 47 284 484 47 289 484 minecraft:sea_lantern
fill 47 284 492 47 289 492 minecraft:sea_lantern
fill 47 284 500 47 289 500 minecraft:sea_lantern
fill 48 284 470 48 300 471 minecraft:quartz_block
fill 48 284 478 48 300 479 minecraft:quartz_block
fill 48 284 486 48 300 487 minecraft:quartz_block
fill 48 284 494 48 300 495 minecraft:quartz_block
fill 48 284 502 48 300 503 minecraft:quartz_block
fill 49 284 464 50 300 464 minecraft:quartz_block
fill 50 284 505 50 289 505 minecraft:sea_lantern
fill 54 284 463 54 289 463 minecraft:sea_lantern
fill 54 284 504 55 300 504 minecraft:quartz_block
fill 57 284 464 58 300 464 minecraft:quartz_block
fill 58 284 505 58 289 505 minecraft:sea_lantern
fill 62 284 463 62 289 463 minecraft:sea_lantern
fill 62 284 504 63 300 504 minecraft:quartz_block
fill 65 284 464 66 300 464 minecraft:quartz_block
fill 66 284 505 66 289 505 minecraft:sea_lantern
fill 70 284 463 70 289 463 minecraft:sea_lantern
fill 70 284 504 71 300 504 minecraft:quartz_block
fill 73 284 464 74 300 464 minecraft:quartz_block
fill 74 284 505 74 289 505 minecraft:sea_lantern
fill 78 284 463 78 289 463 minecraft:sea_lantern
fill 78 284 504 79 300 504 minecraft:quartz_block
fill 81 284 464 82 300 464 minecraft:quartz_block
fill 82 284 505 82 289 505 minecraft:sea_lantern
fill 83 284 473 83 284 479 minecraft:black_concrete
fill 84 284 480 88 284 485 minecraft:quartz_block
fill 85 284 486 88 285 486 minecraft:quartz_block
fill 86 284 463 86 289 463 minecraft:sea_lantern
fill 86 284 504 87 300 504 minecraft:quartz_block
fill 87 284 479 88 284 479 minecraft:quartz_block
fill 88 284 465 88 300 466 minecraft:quartz_block
fill 88 284 473 88 300 474 minecraft:quartz_block
fill 88 284 489 88 300 490 minecraft:quartz_block
fill 88 284 497 88 300 498 minecraft:quartz_block
fill 89 284 468 89 289 468 minecraft:sea_lantern
fill 89 284 476 89 289 476 minecraft:sea_lantern
fill 89 284 484 89 289 484 minecraft:sea_lantern
fill 89 284 492 89 289 492 minecraft:sea_lantern
fill 89 284 500 89 289 500 minecraft:sea_lantern
fill 83 285 478 83 285 483 minecraft:black_concrete
fill 84 285 484 84 285 490 minecraft:quartz_block
fill 85 285 484 88 285 485 minecraft:quartz_block
fill 85 285 487 87 285 490 minecraft:quartz_block
fill 87 285 491 88 286 491 minecraft:quartz_block
fill 88 285 481 88 300 482 minecraft:quartz_block
fill 88 285 487 88 285 488 minecraft:quartz_block
fill 83 286 482 83 286 487 minecraft:black_concrete
fill 84 286 488 86 286 495 minecraft:quartz_block
fill 86 286 496 88 287 496 minecraft:quartz_block
fill 87 286 489 87 286 490 minecraft:quartz_block
fill 87 286 492 88 286 495 minecraft:quartz_block
fill 87 286 497 87 287 497 minecraft:quartz_block
fill 83 287 486 83 287 491 minecraft:black_concrete
fill 83 287 500 88 287 500 minecraft:quartz_block
fill 84 287 492 84 287 499 minecraft:quartz_block
fill 84 287 501 88 288 502 minecraft:quartz_block
fill 85 287 493 85 287 499 minecraft:quartz_block
fill 85 287 503 88 288 503 minecraft:quartz_block
fill 86 287 493 86 287 495 minecraft:quartz_block
fill 86 287 497 86 287 499 minecraft:quartz_block
fill 87 287 494 88 287 495 minecraft:quartz_block
fill 87 287 498 87 287 499 minecraft:quartz_block
setblock 88 287 499 minecraft:quartz_block
fill 88 287 504 88 288 504 minecraft:quartz_block
fill 77 288 500 83 288 501 minecraft:quartz_block
fill 78 288 502 83 288 503 minecraft:quartz_block
fill 80 288 504 85 288 504 minecraft:quartz_block
fill 83 288 489 83 288 496 minecraft:black_concrete
fill 84 288 498 84 288 500 minecraft:quartz_block
setblock 84 288 503 minecraft:quartz_block
fill 85 288 499 85 288 500 minecraft:quartz_block
setblock 86 288 500 minecraft:quartz_block
setblock 50 289 466 minecraft:light[level=14]
setblock 50 289 474 minecraft:light[level=14]
setblock 50 289 482 minecraft:light[level=14]
setblock 50 289 490 minecraft:light[level=14]
setblock 50 289 498 minecraft:light[level=14]
setblock 58 289 466 minecraft:light[level=14]
setblock 58 289 474 minecraft:light[level=14]
setblock 58 289 482 minecraft:light[level=14]
setblock 58 289 490 minecraft:light[level=14]
setblock 58 289 498 minecraft:light[level=14]
setblock 66 289 466 minecraft:light[level=14]
setblock 66 289 474 minecraft:light[level=14]
setblock 66 289 482 minecraft:light[level=14]
setblock 66 289 490 minecraft:light[level=14]
setblock 66 289 498 minecraft:light[level=14]
fill 72 289 500 79 289 500 minecraft:quartz_block
fill 73 289 501 77 289 504 minecraft:quartz_block
setblock 74 289 466 minecraft:light[level=14]
setblock 74 289 474 minecraft:light[level=14]
setblock 74 289 482 minecraft:light[level=14]
setblock 74 289 490 minecraft:light[level=14]
setblock 74 289 498 minecraft:light[level=14]
fill 78 289 501 80 289 503 minecraft:quartz_block
fill 79 289 499 83 289 499 minecraft:black_concrete
fill 80 289 504 82 289 504 minecraft:quartz_block
fill 81 289 502 81 289 503 minecraft:quartz_block
setblock 82 289 466 minecraft:light[level=14]
setblock 82 289 474 minecraft:light[level=14]
setblock 82 289 482 minecraft:light[level=14]
setblock 82 289 490 minecraft:light[level=14]
setblock 82 289 498 minecraft:light[level=14]
fill 83 289 494 83 289 498 minecraft:black_concrete
fill 47 290 468 47 297 468 minecraft:white_concrete
fill 47 290 476 47 297 476 minecraft:white_concrete
fill 47 290 484 47 297 484 minecraft:white_concrete
fill 47 290 492 47 297 492 minecraft:white_concrete
fill 47 290 500 47 297 500 minecraft:white_concrete
fill 50 290 505 50 297 505 minecraft:white_concrete
fill 54 290 463 54 297 463 minecraft:white_concrete
fill 58 290 505 58 297 505 minecraft:white_concrete
fill 62 290 463 62 297 463 minecraft:white_concrete
fill 66 290 505 66 297 505 minecraft:white_concrete
fill 68 290 500 69 291 504 minecraft:quartz_block
fill 70 290 463 70 297 463 minecraft:white_concrete
fill 70 290 500 74 290 503 minecraft:quartz_block
fill 72 290 504 76 290 504 minecraft:quartz_block
fill 74 290 505 74 297 505 minecraft:white_concrete
fill 75 290 499 82 290 499 minecraft:black_concrete
fill 75 290 502 75 290 503 minecraft:quartz_block
fill 78 290 463 78 297 463 minecraft:white_concrete
fill 82 290 505 82 297 505 minecraft:white_concrete
fill 86 290 463 86 297 463 minecraft:white_concrete
fill 89 290 468 89 297 468 minecraft:white_concrete
fill 89 290 476 89 297 476 minecraft:white_concrete
fill 89 290 484 89 297 484 minecraft:white_concrete
fill 89 290 492 89 297 492 minecraft:white_concrete
fill 89 290 500 89 297 500 minecraft:white_concrete
fill 64 291 501 67 291 504 minecraft:quartz_block
fill 65 291 500 67 291 500 minecraft:quartz_block
fill 70 291 500 70 291 503 minecraft:quartz_block
fill 71 291 499 76 291 499 minecraft:black_concrete
fill 58 292 504 61 292 504 minecraft:quartz_block
fill 59 292 502 66 292 503 minecraft:quartz_block
fill 60 292 500 66 292 501 minecraft:quartz_block
fill 64 292 504 66 292 504 minecraft:quartz_block
fill 67 292 499 72 292 499 minecraft:black_concrete
fill 51 293 504 53 295 504 minecraft:quartz_block
fill 52 293 503 61 294 503 minecraft:quartz_block
fill 53 293 501 61 293 502 minecraft:quartz_block
fill 54 293 500 62 293 500 minecraft:quartz_block
fill 56 293 504 60 295 504 minecraft:quartz_block
setblock 62 293 501 minecraft:quartz_block
fill 63 293 499 68 293 499 minecraft:black_concrete
fill 48 294 464 48 295 469 minecraft:quartz_block
fill 48 294 472 49 294 477 minecraft:quartz_block
fill 48 294 480 49 294 485 minecraft:quartz_block
fill 48 294 488 49 294 493 minecraft:quartz_block
fill 48 294 496 49 295 501 minecraft:quartz_block
fill 48 294 504 50 295 504 minecraft:quartz_block
fill 49 294 465 49 294 471 minecraft:quartz_block
fill 49 294 478 49 294 479 minecraft:quartz_block
fill 49 294 486 49 294 487 minecraft:quartz_block
fill 49 294 494 49 295 495 minecraft:quartz_block
fill 49 294 502 51 294 503 minecraft:quartz_block
fill 50 294 465 87 294 465 minecraft:quartz_block
fill 50 294 497 52 294 501 minecraft:quartz_block
fill 51 294 464 56 295 464 minecraft:quartz_block
fill 51 294 496 52 295 496 minecraft:quartz_block
fill 52 294 502 56 294 502 minecraft:quartz_block
fill 53 294 500 56 294 501 minecraft:quartz_block
setblock 57 294 500 minecraft:quartz_block
fill 59 294 464 64 295 464 minecraft:quartz_block
fill 59 294 499 65 294 499 minecraft:black_concrete
fill 61 294 504 61 295 504 minecraft:quartz_block
fill 62 294 503 88 294 503 minecraft:quartz_block
fill 64 294 504 69 295 504 minecraft:quartz_block
fill 67 294 464 72 295 464 minecraft:quartz_block
fill 72 294 504 77 295 504 minecraft:quartz_block
fill 75 294 464 80 295 464 minecraft:quartz_block
fill 80 294 504 85 295 504 minecraft:quartz_block
fill 83 294 464 88 295 464 minecraft:quartz_block
fill 87 294 466 87 294 502 minecraft:quartz_block
fill 88 294 467 88 295 472 minecraft:quartz_block
fill 88 294 475 88 295 480 minecraft:quartz_block
fill 88 294 483 88 295 488 minecraft:quartz_block
fill 88 294 491 88 295 496 minecraft:quartz_block
fill 88 294 499 88 295 502 minecraft:quartz_block
fill 88 294 504 88 295 504 minecraft:quartz_block
fill 48 295 472 48 295 477 minecraft:quartz_block
fill 48 295 480 48 295 485 minecraft:quartz_block
fill 48 295 488 48 296 493 minecraft:quartz_block
fill 49 295 492 52 295 493 minecraft:quartz_block
fill 50 295 491 52 296 491 minecraft:quartz_block
fill 50 295 494 50 295 500 minecraft:quartz_block
fill 51 295 494 52 295 495 minecraft:quartz_block
fill 51 295 497 51 295 499 minecraft:quartz_block
fill 52 295 497 52 295 498 minecraft:quartz_block
fill 53 295 498 53 296 499 minecraft:black_concrete
fill 54 295 499 61 295 499 minecraft:black_concrete
setblock 88 295 503 minecraft:quartz_block
fill 49 296 487 49 296 494 minecraft:quartz_block
fill 50 296 487 52 296 490 minecraft:quartz_block
fill 50 296 492 50 296 494 minecraft:quartz_block
fill 51 296 492 51 296 493 minecraft:quartz_block
fill 52 296 486 52 297 486 minecraft:quartz_block
setblock 52 296 492 minecraft:quartz_block
fill 53 296 493 53 296 497 minecraft:black_concrete
fill 54 296 499 55 296 499 minecraft:black_concrete
fill 48 297 482 51 297 485 minecraft:quartz_block
fill 48 297 488 49 297 489 minecraft:quartz_block
fill 49 297 486 51 297 487 minecraft:quartz_block
setblock 50 297 466 minecraft:light[level=14]
setblock 50 297 474 minecraft:light[level=14]
fill 50 297 488 52 297 488 minecraft:quartz_block
setblock 50 297 490 minecraft:light[level=14]
setblock 50 297 498 minecraft:light[level=14]
fill 52 297 483 52 297 485 minecraft:quartz_block
setblock 52 297 487 minecraft:quartz_block
fill 53 297 489 53 297 495 minecraft:black_concrete
setblock 58 297 466 minecraft:light[level=14]
setblock 58 297 474 minecraft:light[level=14]
setblock 58 297 482 minecraft:light[level=14]
setblock 58 297 490 minecraft:light[level=14]
setblock 58 297 498 minecraft:light[level=14]
setblock 66 297 466 minecraft:light[level=14]
setblock 66 297 474 minecraft:light[level=14]
setblock 66 297 482 minecraft:light[level=14]
setblock 66 297 490 minecraft:light[level=14]
setblock 66 297 498 minecraft:light[level=14]
setblock 74 297 466 minecraft:light[level=14]
setblock 74 297 474 minecraft:light[level=14]
setblock 74 297 482 minecraft:light[level=14]
setblock 74 297 490 minecraft:light[level=14]
setblock 74 297 498 minecraft:light[level=14]
setblock 82 297 466 minecraft:light[level=14]
setblock 82 297 474 minecraft:light[level=14]
setblock 82 297 482 minecraft:light[level=14]
setblock 82 297 490 minecraft:light[level=14]
setblock 82 297 498 minecraft:light[level=14]
fill 47 298 468 47 300 468 minecraft:sea_lantern
fill 47 298 476 47 300 476 minecraft:sea_lantern
fill 47 298 484 47 300 484 minecraft:sea_lantern
fill 47 298 492 47 300 492 minecraft:sea_lantern
fill 47 298 500 47 300 500 minecraft:sea_lantern
fill 48 298 477 49 299 477 minecraft:quartz_block
fill 48 298 480 52 298 484 minecraft:quartz_block
fill 49 298 478 52 299 479 minecraft:quartz_block
fill 50 298 505 50 300 505 minecraft:sea_lantern
fill 53 298 485 53 298 490 minecraft:black_concrete
fill 54 298 463 54 300 463 minecraft:sea_lantern
fill 58 298 505 58 300 505 minecraft:sea_lantern
fill 62 298 463 62 300 463 minecraft:sea_lantern
fill 66 298 505 66 300 505 minecraft:sea_lantern
fill 70 298 463 70 300 463 minecraft:sea_lantern
fill 74 298 505 74 300 505 minecraft:sea_lantern
fill 78 298 463 78 300 463 minecraft:sea_lantern
fill 82 298 505 82 300 505 minecraft:sea_lantern
fill 86 298 463 86 300 463 minecraft:sea_lantern
fill 89 298 468 89 300 468 minecraft:sea_lantern
fill 89 298 476 89 300 476 minecraft:sea_lantern
fill 89 298 484 89 300 484 minecraft:sea_lantern
fill 89 298 492 89 300 492 minecraft:sea_lantern
fill 89 298 500 89 300 500 minecraft:sea_lantern
fill 48 299 472 50 299 476 minecraft:quartz_block
fill 49 299 471 49 300 471 minecraft:quartz_block
fill 50 299 477 52 299 477 minecraft:quartz_block
fill 50 299 480 52 299 480 minecraft:quartz_block
fill 51 299 473 52 299 476 minecraft:quartz_block
fill 53 299 481 53 299 486 minecraft:black_concrete
fill 48 300 464 48 300 469 minecraft:quartz_block
fill 48 300 472 52 300 474 minecraft:quartz_block
fill 49 300 465 51 300 470 minecraft:quartz_block
fill 50 300 471 52 300 471 minecraft:quartz_block
fill 50 300 475 52 300 475 minecraft:quartz_block
fill 52 300 466 52 300 470 minecraft:quartz_block
setblock 52 300 476 minecraft:quartz_block
setblock 53 300 468 minecraft:quartz_block
fill 53 300 477 53 300 482 minecraft:black_concrete
fill 47 301 468 47 307 468 minecraft:white_concrete
fill 47 301 476 47 307 476 minecraft:white_concrete
fill 47 301 484 47 307 484 minecraft:white_concrete
fill 47 301 492 47 307 492 minecraft:white_concrete
fill 47 301 500 47 307 500 minecraft:white_concrete
fill 50 301 505 50 307 505 minecraft:white_concrete
fill 54 301 463 54 307 463 minecraft:white_concrete
fill 58 301 505 58 307 505 minecraft:white_concrete
fill 62 301 463 62 307 463 minecraft:white_concrete
fill 66 301 505 66 307 505 minecraft:white_concrete
fill 70 301 463 70 307 463 minecraft:white_concrete
fill 74 301 505 74 307 505 minecraft:white_concrete
fill 78 301 463 78 307 463 minecraft:white_concrete
fill 82 301 505 82 307 505 minecraft:white_concrete
fill 86 301 463 86 307 463 minecraft:white_concrete
fill 89 301 468 89 307 468 minecraft:white_concrete
fill 89 301 476 89 307 476 minecraft:white_concrete
fill 89 301 484 89 307 484 minecraft:white_concrete
fill 89 301 492 89 307 492 minecraft:white_concrete
fill 89 301 500 89 307 500 minecraft:white_concrete
