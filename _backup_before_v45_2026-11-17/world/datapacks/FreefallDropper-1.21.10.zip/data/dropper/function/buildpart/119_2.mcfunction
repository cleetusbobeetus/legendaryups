fill 549 211 465 555 212 465 minecraft:white_wool
setblock 554 211 464 minecraft:gold_block
setblock 554 211 504 minecraft:gold_block
setblock 558 211 467 minecraft:gold_block
setblock 558 211 474 minecraft:gold_block
setblock 558 211 481 minecraft:gold_block
setblock 558 211 488 minecraft:gold_block
setblock 558 211 495 minecraft:gold_block
setblock 558 211 502 minecraft:gold_block
setblock 518 212 464 minecraft:gold_block
setblock 518 212 471 minecraft:gold_block
setblock 518 212 478 minecraft:gold_block
setblock 518 212 485 minecraft:gold_block
setblock 518 212 492 minecraft:gold_block
setblock 518 212 499 minecraft:gold_block
fill 520 212 498 520 232 498 minecraft:white_wool
setblock 520 212 504 minecraft:gold_block
setblock 525 212 464 minecraft:gold_block
fill 527 212 499 535 212 503 minecraft:dark_oak_planks
setblock 527 212 504 minecraft:gold_block
setblock 532 212 464 minecraft:gold_block
setblock 534 212 504 minecraft:gold_block
setblock 539 212 464 minecraft:gold_block
setblock 541 212 504 minecraft:gold_block
setblock 546 212 464 minecraft:gold_block
setblock 548 212 504 minecraft:gold_block
setblock 553 212 464 minecraft:gold_block
setblock 555 212 504 minecraft:gold_block
setblock 558 212 466 minecraft:gold_block
setblock 558 212 473 minecraft:gold_block
setblock 558 212 480 minecraft:gold_block
setblock 558 212 487 minecraft:gold_block
setblock 558 212 494 minecraft:gold_block
setblock 558 212 501 minecraft:gold_block
setblock 518 213 465 minecraft:gold_block
setblock 518 213 472 minecraft:gold_block
setblock 518 213 479 minecraft:gold_block
setblock 518 213 486 minecraft:gold_block
setblock 518 213 493 minecraft:gold_block
setblock 518 213 500 minecraft:gold_block
setblock 521 213 504 minecraft:gold_block
setblock 524 213 464 minecraft:gold_block
fill 527 213 499 535 213 503 minecraft:gold_block
setblock 528 213 504 minecraft:gold_block
setblock 531 213 464 minecraft:gold_block
setblock 535 213 504 minecraft:gold_block
setblock 538 213 464 minecraft:gold_block
setblock 542 213 504 minecraft:gold_block
setblock 545 213 464 minecraft:gold_block
setblock 549 213 504 minecraft:gold_block
setblock 552 213 464 minecraft:gold_block
setblock 556 213 504 minecraft:gold_block
setblock 558 213 465 minecraft:gold_block
setblock 558 213 472 minecraft:gold_block
setblock 558 213 479 minecraft:gold_block
setblock 558 213 486 minecraft:gold_block
setblock 558 213 493 minecraft:gold_block
setblock 558 213 500 minecraft:gold_block
setblock 518 214 466 minecraft:gold_block
setblock 518 214 473 minecraft:gold_block
setblock 518 214 480 minecraft:gold_block
setblock 518 214 487 minecraft:gold_block
setblock 518 214 494 minecraft:gold_block
setblock 518 214 501 minecraft:gold_block
setblock 520 214 466 minecraft:light[level=12]
setblock 520 214 474 minecraft:light[level=12]
setblock 520 214 482 minecraft:light[level=12]
setblock 520 214 490 minecraft:light[level=12]
setblock 522 214 504 minecraft:gold_block
setblock 523 214 464 minecraft:gold_block
fill 527 214 499 535 214 499 minecraft:red_wool
setblock 528 214 466 minecraft:light[level=12]
setblock 528 214 474 minecraft:light[level=12]
setblock 528 214 482 minecraft:light[level=12]
setblock 528 214 490 minecraft:light[level=12]
setblock 528 214 498 minecraft:light[level=12]
setblock 529 214 504 minecraft:gold_block
setblock 530 214 464 minecraft:gold_block
fill 530 214 504 532 217 504 minecraft:ochre_froglight
setblock 536 214 466 minecraft:light[level=12]
setblock 536 214 474 minecraft:light[level=12]
setblock 536 214 482 minecraft:light[level=12]
setblock 536 214 490 minecraft:light[level=12]
setblock 536 214 498 minecraft:light[level=12]
setblock 536 214 504 minecraft:gold_block
setblock 537 214 464 minecraft:gold_block
setblock 543 214 504 minecraft:gold_block
setblock 544 214 464 minecraft:gold_block
setblock 544 214 466 minecraft:light[level=12]
setblock 544 214 474 minecraft:light[level=12]
setblock 544 214 482 minecraft:light[level=12]
setblock 544 214 490 minecraft:light[level=12]
setblock 544 214 498 minecraft:light[level=12]
setblock 550 214 504 minecraft:gold_block
setblock 551 214 464 minecraft:gold_block
setblock 552 214 466 minecraft:light[level=12]
setblock 552 214 474 minecraft:light[level=12]
setblock 552 214 482 minecraft:light[level=12]
setblock 552 214 490 minecraft:light[level=12]
setblock 552 214 498 minecraft:light[level=12]
setblock 557 214 504 minecraft:gold_block
setblock 558 214 464 minecraft:gold_block
setblock 558 214 471 minecraft:gold_block
setblock 558 214 478 minecraft:gold_block
setblock 558 214 485 minecraft:gold_block
setblock 558 214 492 minecraft:gold_block
setblock 558 214 499 minecraft:gold_block
setblock 518 215 467 minecraft:gold_block
setblock 518 215 474 minecraft:gold_block
setblock 518 215 481 minecraft:gold_block
setblock 518 215 488 minecraft:gold_block
setblock 518 215 495 minecraft:gold_block
setblock 518 215 502 minecraft:gold_block
setblock 522 215 464 minecraft:gold_block
setblock 523 215 504 minecraft:gold_block
setblock 527 215 499 minecraft:gold_block
setblock 529 215 464 minecraft:gold_block
fill 531 215 465 537 216 465 minecraft:white_wool
setblock 531 215 499 minecraft:gold_block
setblock 535 215 499 minecraft:gold_block
setblock 536 215 464 minecraft:gold_block
setblock 537 215 504 minecraft:gold_block
fill 540 215 464 540 215 469 minecraft:dark_oak_planks
fill 541 215 465 548 215 469 minecraft:dark_oak_planks
setblock 542 215 464 minecraft:dark_oak_planks
fill 543 215 464 543 216 464 minecraft:gold_block
fill 544 215 464 547 215 464 minecraft:dark_oak_planks
setblock 544 215 504 minecraft:gold_block
setblock 550 215 464 minecraft:gold_block
setblock 551 215 504 minecraft:gold_block
setblock 557 215 464 minecraft:gold_block
setblock 558 215 470 minecraft:gold_block
setblock 558 215 477 minecraft:gold_block
setblock 558 215 484 minecraft:gold_block
setblock 558 215 491 minecraft:gold_block
setblock 558 215 498 minecraft:gold_block
setblock 558 215 504 minecraft:gold_block
setblock 518 216 468 minecraft:gold_block
setblock 518 216 475 minecraft:gold_block
setblock 518 216 482 minecraft:gold_block
setblock 518 216 489 minecraft:gold_block
setblock 518 216 496 minecraft:gold_block
setblock 518 216 503 minecraft:gold_block
setblock 521 216 464 minecraft:gold_block
setblock 524 216 504 minecraft:gold_block
setblock 528 216 464 minecraft:gold_block
setblock 535 216 464 minecraft:gold_block
setblock 538 216 504 minecraft:gold_block
fill 540 216 464 540 216 469 minecraft:gold_block
fill 541 216 465 548 216 469 minecraft:gold_block
setblock 542 216 464 minecraft:gold_block
fill 544 216 464 547 216 464 minecraft:gold_block
setblock 545 216 504 minecraft:gold_block
setblock 549 216 464 minecraft:gold_block
setblock 552 216 504 minecraft:gold_block
setblock 556 216 464 minecraft:gold_block
setblock 558 216 469 minecraft:gold_block
setblock 558 216 476 minecraft:gold_block
setblock 558 216 483 minecraft:gold_block
setblock 558 216 490 minecraft:gold_block
setblock 558 216 497 minecraft:gold_block
fill 540 217 463 542 222 463 minecraft:red_terracotta
fill 540 217 469 548 217 469 minecraft:red_wool
fill 543 217 463 545 220 463 minecraft:ochre_froglight
setblock 518 218 470 minecraft:gold_block
setblock 518 218 477 minecraft:gold_block
setblock 518 218 484 minecraft:gold_block
setblock 518 218 491 minecraft:gold_block
setblock 518 218 498 minecraft:gold_block
setblock 519 218 464 minecraft:gold_block
setblock 519 218 504 minecraft:gold_block
setblock 526 218 464 minecraft:gold_block
setblock 526 218 504 minecraft:gold_block
fill 532 218 504 533 218 504 minecraft:gold_block
setblock 533 218 464 minecraft:gold_block
setblock 540 218 464 minecraft:gold_block
setblock 540 218 469 minecraft:gold_block
setblock 540 218 504 minecraft:gold_block
setblock 544 218 469 minecraft:gold_block
setblock 547 218 464 minecraft:gold_block
setblock 547 218 504 minecraft:gold_block
setblock 548 218 469 minecraft:gold_block
setblock 554 218 464 minecraft:gold_block
setblock 554 218 504 minecraft:gold_block
setblock 558 218 467 minecraft:gold_block
setblock 558 218 474 minecraft:gold_block
setblock 558 218 481 minecraft:gold_block
setblock 558 218 488 minecraft:gold_block
setblock 558 218 495 minecraft:gold_block
setblock 558 218 502 minecraft:gold_block
fill 517 219 479 517 219 481 minecraft:red_terracotta
setblock 517 219 482 minecraft:red_wool
fill 517 219 484 517 222 484 minecraft:red_terracotta
setblock 517 219 485 minecraft:red_wool
fill 517 219 486 517 220 488 minecraft:red_terracotta
fill 517 219 493 517 222 493 minecraft:red_terracotta
setblock 517 219 494 minecraft:red_wool
fill 517 219 495 517 222 497 minecraft:red_terracotta
setblock 517 219 498 minecraft:red_wool
fill 518 219 464 518 220 464 minecraft:gold_block
fill 518 219 471 518 220 471 minecraft:gold_block
fill 518 219 478 518 220 478 minecraft:gold_block
fill 518 219 485 518 220 485 minecraft:gold_block
fill 518 219 492 518 220 492 minecraft:gold_block
fill 518 219 499 518 220 499 minecraft:gold_block
fill 520 219 504 520 220 504 minecraft:gold_block
setblock 521 219 463 minecraft:red_wool
fill 522 219 463 522 222 463 minecraft:red_terracotta
fill 523 219 505 523 222 505 minecraft:red_terracotta
setblock 524 219 505 minecraft:red_wool
fill 525 219 464 525 220 464 minecraft:gold_block
fill 525 219 505 527 220 505 minecraft:red_terracotta
fill 527 219 504 527 220 504 minecraft:gold_block
setblock 528 219 505 minecraft:red_wool
fill 532 219 464 532 220 464 minecraft:gold_block
fill 532 219 504 532 235 504 minecraft:gold_block
fill 534 219 504 534 220 504 minecraft:gold_block
fill 538 219 505 539 222 505 minecraft:red_terracotta
fill 539 219 464 539 220 464 minecraft:gold_block
setblock 540 219 505 minecraft:red_wool
fill 541 219 504 541 220 504 minecraft:gold_block
setblock 542 219 505 minecraft:red_terracotta
setblock 543 219 505 minecraft:red_wool
fill 544 219 505 544 220 505 minecraft:red_terracotta
setblock 545 219 505 minecraft:red_wool
setblock 546 219 463 minecraft:red_wool
fill 546 219 464 546 220 464 minecraft:gold_block
fill 547 219 463 548 222 463 minecraft:red_terracotta
fill 548 219 504 548 220 504 minecraft:gold_block
fill 551 219 463 555 222 463 minecraft:red_terracotta
fill 553 219 464 553 220 464 minecraft:gold_block
fill 555 219 504 555 220 504 minecraft:gold_block
setblock 556 219 463 minecraft:red_wool
fill 558 219 466 558 220 466 minecraft:gold_block
fill 558 219 473 558 220 473 minecraft:gold_block
fill 558 219 480 558 220 480 minecraft:gold_block
fill 558 219 487 558 220 487 minecraft:gold_block
fill 558 219 494 558 220 494 minecraft:gold_block
fill 558 219 501 558 220 501 minecraft:gold_block
setblock 559 219 464 minecraft:red_wool
fill 559 219 465 559 219 468 minecraft:red_terracotta
fill 559 219 472 559 220 472 minecraft:red_wool
fill 559 219 473 559 220 477 minecraft:red_terracotta
setblock 559 219 478 minecraft:red_wool
fill 559 219 479 559 220 481 minecraft:red_terracotta
fill 559 219 483 559 222 486 minecraft:red_terracotta
fill 559 219 487 559 220 487 minecraft:red_wool
fill 559 219 488 559 220 491 minecraft:red_terracotta
fill 559 219 493 559 220 493 minecraft:red_terracotta
setblock 559 219 494 minecraft:red_wool
fill 559 219 495 559 219 502 minecraft:red_terracotta
fill 559 219 503 559 220 503 minecraft:red_wool
fill 559 219 504 559 222 504 minecraft:red_terracotta
fill 517 220 471 517 222 471 minecraft:red_terracotta
setblock 517 220 472 minecraft:red_wool
fill 517 220 473 517 222 473 minecraft:red_terracotta
fill 517 220 474 517 220 475 minecraft:red_wool
setblock 517 220 479 minecraft:red_terracotta
setblock 517 220 480 minecraft:red_wool
fill 517 220 481 517 222 482 minecraft:red_terracotta
setblock 517 220 483 minecraft:red_wool
fill 517 220 485 517 222 485 minecraft:red_terracotta
fill 517 220 494 517 222 494 minecraft:red_terracotta
fill 517 220 498 517 222 498 minecraft:red_terracotta
fill 518 220 465 518 220 468 minecraft:gold_block
setblock 518 220 470 minecraft:gold_block
fill 518 220 472 518 220 475 minecraft:gold_block
setblock 518 220 477 minecraft:gold_block
fill 518 220 479 518 220 482 minecraft:gold_block
setblock 518 220 484 minecraft:gold_block
fill 518 220 486 518 220 489 minecraft:gold_block
setblock 518 220 491 minecraft:gold_block
fill 518 220 493 518 220 496 minecraft:gold_block
setblock 518 220 498 minecraft:gold_block
fill 518 220 500 518 220 503 minecraft:gold_block
setblock 519 220 464 minecraft:gold_block
setblock 519 220 504 minecraft:gold_block
setblock 521 220 463 minecraft:red_terracotta
fill 521 220 464 524 220 464 minecraft:gold_block
fill 521 220 504 524 220 504 minecraft:gold_block
fill 521 220 505 521 222 505 minecraft:red_terracotta
setblock 522 220 505 minecraft:red_wool
fill 524 220 505 524 223 505 minecraft:red_terracotta
setblock 526 220 464 minecraft:gold_block
setblock 526 220 504 minecraft:gold_block
fill 528 220 464 531 220 464 minecraft:gold_block
fill 528 220 504 531 220 504 minecraft:gold_block
setblock 528 220 505 minecraft:red_terracotta
setblock 533 220 464 minecraft:gold_block
fill 533 220 465 533 228 465 minecraft:red_wool
setblock 533 220 504 minecraft:gold_block
setblock 534 220 505 minecraft:red_wool
fill 535 220 464 538 220 464 minecraft:gold_block
fill 535 220 504 538 220 504 minecraft:gold_block
setblock 536 220 463 minecraft:red_wool
fill 537 220 463 538 222 463 minecraft:red_terracotta
setblock 540 220 464 minecraft:gold_block
setblock 540 220 504 minecraft:gold_block
fill 540 220 505 540 222 505 minecraft:red_terracotta
fill 541 220 505 542 220 505 minecraft:red_wool
fill 542 220 464 545 220 464 minecraft:gold_block
fill 542 220 504 545 220 504 minecraft:gold_block
fill 543 220 505 543 222 505 minecraft:red_terracotta
setblock 545 220 505 minecraft:red_terracotta
fill 546 220 463 546 222 463 minecraft:red_terracotta
setblock 547 220 464 minecraft:gold_block
setblock 547 220 504 minecraft:gold_block
fill 549 220 464 552 220 464 minecraft:gold_block
fill 549 220 504 552 220 504 minecraft:gold_block
setblock 554 220 464 minecraft:gold_block
setblock 554 220 504 minecraft:gold_block
fill 556 220 463 557 222 463 minecraft:red_terracotta
fill 556 220 464 558 220 464 minecraft:gold_block
fill 556 220 504 558 220 504 minecraft:gold_block
fill 558 220 463 559 220 463 minecraft:red_wool
setblock 558 220 465 minecraft:gold_block
setblock 558 220 467 minecraft:gold_block
fill 558 220 469 558 220 472 minecraft:gold_block
setblock 558 220 474 minecraft:gold_block
fill 558 220 476 558 220 479 minecraft:gold_block
setblock 558 220 481 minecraft:gold_block
fill 558 220 483 558 220 486 minecraft:gold_block
setblock 558 220 488 minecraft:gold_block
fill 558 220 490 558 220 493 minecraft:gold_block
setblock 558 220 495 minecraft:gold_block
fill 558 220 497 558 220 500 minecraft:gold_block
setblock 558 220 502 minecraft:gold_block
fill 559 220 464 559 222 465 minecraft:red_terracotta
fill 559 220 466 559 221 466 minecraft:red_wool
fill 559 220 467 559 222 468 minecraft:red_terracotta
setblock 559 220 471 minecraft:red_wool
fill 559 220 478 559 222 478 minecraft:red_terracotta
setblock 559 220 492 minecraft:red_wool
fill 559 220 494 559 222 501 minecraft:red_terracotta
setblock 559 220 502 minecraft:red_wool
fill 517 221 472 517 222 472 minecraft:red_terracotta
fill 517 221 474 517 222 475 minecraft:red_terracotta
setblock 517 221 479 minecraft:red_wool
fill 517 221 480 517 222 480 minecraft:red_terracotta
fill 517 221 483 517 222 483 minecraft:red_terracotta
setblock 517 221 486 minecraft:red_wool
fill 517 221 487 517 222 488 minecraft:red_terracotta
setblock 517 221 499 minecraft:red_wool
fill 517 221 503 517 222 504 minecraft:red_terracotta
setblock 517 221 505 minecraft:red_wool
setblock 518 221 466 minecraft:gold_block
setblock 518 221 473 minecraft:gold_block
setblock 518 221 480 minecraft:gold_block
setblock 518 221 487 minecraft:gold_block
setblock 518 221 494 minecraft:gold_block
setblock 518 221 501 minecraft:gold_block
fill 518 221 505 518 222 505 minecraft:red_terracotta
setblock 519 221 505 minecraft:red_wool
setblock 521 221 463 minecraft:red_wool
setblock 522 221 504 minecraft:gold_block
fill 522 221 505 522 223 505 minecraft:red_terracotta
setblock 523 221 464 minecraft:gold_block
setblock 525 221 505 minecraft:red_wool
fill 526 221 463 532 222 463 minecraft:red_terracotta
fill 526 221 505 527 222 505 minecraft:red_terracotta
setblock 528 221 505 minecraft:red_wool
setblock 529 221 504 minecraft:gold_block
setblock 530 221 464 minecraft:gold_block
fill 531 221 465 532 228 465 minecraft:red_wool
setblock 533 221 463 minecraft:red_wool
fill 534 221 463 534 222 463 minecraft:red_terracotta
fill 534 221 465 535 228 465 minecraft:red_wool
fill 534 221 505 534 222 505 minecraft:red_terracotta
setblock 535 221 463 minecraft:red_wool
fill 536 221 463 536 222 463 minecraft:red_terracotta
setblock 536 221 504 minecraft:gold_block
setblock 537 221 464 minecraft:gold_block
fill 541 221 505 542 222 505 minecraft:red_terracotta
fill 543 221 463 545 222 463 minecraft:red_terracotta
setblock 543 221 504 minecraft:gold_block
setblock 544 221 464 minecraft:gold_block
fill 544 221 505 545 221 505 minecraft:red_wool
setblock 550 221 504 minecraft:gold_block
setblock 551 221 464 minecraft:gold_block
setblock 557 221 504 minecraft:gold_block
fill 558 221 463 559 222 463 minecraft:red_terracotta
setblock 558 221 464 minecraft:gold_block
setblock 558 221 471 minecraft:gold_block
setblock 558 221 478 minecraft:gold_block
setblock 558 221 485 minecraft:gold_block
setblock 558 221 492 minecraft:gold_block
setblock 558 221 499 minecraft:gold_block
fill 559 221 471 559 222 476 minecraft:red_terracotta
setblock 559 221 477 minecraft:red_wool
setblock 559 221 479 minecraft:red_wool
fill 559 221 480 559 222 481 minecraft:red_terracotta
fill 559 221 487 559 222 488 minecraft:red_terracotta
setblock 559 221 489 minecraft:red_wool
fill 559 221 490 559 222 492 minecraft:red_terracotta
setblock 559 221 493 minecraft:red_wool
fill 559 221 502 559 222 503 minecraft:red_terracotta
setblock 517 222 479 minecraft:red_terracotta
setblock 517 222 486 minecraft:red_terracotta
setblock 517 222 499 minecraft:red_terracotta
setblock 517 222 505 minecraft:red_terracotta
setblock 518 222 467 minecraft:gold_block
setblock 518 222 474 minecraft:gold_block
setblock 518 222 481 minecraft:gold_block
setblock 518 222 488 minecraft:gold_block
setblock 518 222 495 minecraft:gold_block
setblock 518 222 502 minecraft:gold_block
setblock 519 222 505 minecraft:red_terracotta
setblock 520 222 466 minecraft:light[level=12]
setblock 520 222 474 minecraft:light[level=12]
setblock 520 222 482 minecraft:light[level=12]
setblock 520 222 490 minecraft:light[level=12]
setblock 521 222 463 minecraft:red_terracotta
setblock 522 222 464 minecraft:gold_block
setblock 523 222 504 minecraft:gold_block
fill 525 222 505 525 223 505 minecraft:red_terracotta
setblock 528 222 466 minecraft:light[level=12]
setblock 528 222 474 minecraft:light[level=12]
setblock 528 222 482 minecraft:light[level=12]
setblock 528 222 490 minecraft:light[level=12]
setblock 528 222 498 minecraft:light[level=12]
setblock 528 222 505 minecraft:red_terracotta
setblock 529 222 464 minecraft:gold_block
setblock 530 222 504 minecraft:gold_block
setblock 533 222 463 minecraft:red_terracotta
fill 535 222 463 535 223 463 minecraft:red_terracotta
setblock 536 222 464 minecraft:gold_block
setblock 536 222 466 minecraft:light[level=12]
setblock 536 222 474 minecraft:light[level=12]
setblock 536 222 482 minecraft:light[level=12]
setblock 536 222 490 minecraft:light[level=12]
setblock 536 222 498 minecraft:light[level=12]
setblock 537 222 504 minecraft:gold_block
setblock 543 222 464 minecraft:gold_block
setblock 544 222 466 minecraft:light[level=12]
setblock 544 222 474 minecraft:light[level=12]
setblock 544 222 482 minecraft:light[level=12]
setblock 544 222 490 minecraft:light[level=12]
setblock 544 222 498 minecraft:light[level=12]
setblock 544 222 504 minecraft:gold_block
fill 544 222 505 545 222 505 minecraft:red_terracotta
setblock 550 222 464 minecraft:gold_block
setblock 551 222 504 minecraft:gold_block
setblock 552 222 466 minecraft:light[level=12]
setblock 552 222 474 minecraft:light[level=12]
setblock 552 222 482 minecraft:light[level=12]
setblock 552 222 490 minecraft:light[level=12]
setblock 552 222 498 minecraft:light[level=12]
setblock 557 222 464 minecraft:gold_block
setblock 558 222 470 minecraft:gold_block
setblock 558 222 477 minecraft:gold_block
setblock 558 222 484 minecraft:gold_block
setblock 558 222 491 minecraft:gold_block
setblock 558 222 498 minecraft:gold_block
setblock 558 222 504 minecraft:gold_block
setblock 559 222 466 minecraft:red_terracotta
setblock 559 222 477 minecraft:red_terracotta
setblock 559 222 479 minecraft:red_terracotta
setblock 559 222 489 minecraft:red_terracotta
setblock 559 222 493 minecraft:red_terracotta
fill 517 223 463 517 307 466 minecraft:red_wool
setblock 517 223 467 minecraft:red_terracotta
fill 517 223 468 517 223 505 minecraft:red_wool
fill 518 223 463 518 307 463 minecraft:red_wool
setblock 518 223 468 minecraft:gold_block
setblock 518 223 475 minecraft:gold_block
setblock 518 223 482 minecraft:gold_block
setblock 518 223 489 minecraft:gold_block
setblock 518 223 496 minecraft:gold_block
setblock 518 223 503 minecraft:gold_block
fill 518 223 505 521 223 505 minecraft:red_wool
fill 520 223 463 528 223 463 minecraft:red_wool
setblock 521 223 464 minecraft:gold_block
fill 523 223 505 523 307 505 minecraft:red_wool
setblock 524 223 504 minecraft:gold_block
fill 526 223 505 530 223 505 minecraft:red_wool
setblock 528 223 464 minecraft:gold_block
setblock 529 223 463 minecraft:red_terracotta
fill 530 223 463 534 223 463 minecraft:red_wool
setblock 531 223 504 minecraft:gold_block
setblock 531 223 505 minecraft:red_terracotta
fill 532 223 505 545 223 505 minecraft:red_wool
setblock 535 223 464 minecraft:gold_block
fill 536 223 463 557 223 463 minecraft:red_wool
setblock 538 223 504 minecraft:gold_block
setblock 542 223 464 minecraft:gold_block
setblock 545 223 504 minecraft:gold_block
fill 546 223 505 546 224 505 minecraft:red_terracotta
fill 547 223 505 548 307 505 minecraft:red_wool
setblock 549 223 464 minecraft:gold_block
setblock 549 223 505 minecraft:red_terracotta
fill 550 223 505 559 223 505 minecraft:red_wool
setblock 552 223 504 minecraft:gold_block
setblock 556 223 464 minecraft:gold_block
setblock 558 223 463 minecraft:red_terracotta
setblock 558 223 469 minecraft:gold_block
setblock 558 223 476 minecraft:gold_block
setblock 558 223 483 minecraft:gold_block
setblock 558 223 490 minecraft:gold_block
setblock 558 223 497 minecraft:gold_block
fill 559 223 463 559 223 466 minecraft:red_wool
setblock 559 223 467 minecraft:red_terracotta
fill 559 223 468 559 224 471 minecraft:red_wool
setblock 559 223 472 minecraft:red_terracotta
fill 559 223 473 559 223 493 minecraft:red_wool
fill 559 223 494 559 224 494 minecraft:red_terracotta
fill 559 223 495 559 223 500 minecraft:red_wool
setblock 559 223 501 minecraft:red_terracotta
fill 559 223 502 559 224 504 minecraft:red_wool
fill 517 224 467 517 307 467 minecraft:red_wool
setblock 517 224 468 minecraft:red_terracotta
fill 517 224 469 517 224 483 minecraft:red_wool
setblock 517 224 484 minecraft:red_terracotta
fill 517 224 485 517 307 488 minecraft:red_wool
setblock 517 224 489 minecraft:red_terracotta
fill 517 224 490 517 224 505 minecraft:red_wool
fill 518 224 505 519 307 505 minecraft:red_wool
fill 519 224 463 519 307 463 minecraft:red_wool
setblock 520 224 463 minecraft:red_terracotta
setblock 520 224 505 minecraft:red_terracotta
fill 521 224 463 522 307 463 minecraft:red_wool
fill 521 224 505 522 307 505 minecraft:red_wool
setblock 523 224 463 minecraft:red_terracotta
fill 524 224 463 529 307 463 minecraft:red_wool
fill 524 224 505 525 307 505 minecraft:red_wool
setblock 526 224 505 minecraft:red_terracotta
fill 527 224 505 534 224 505 minecraft:red_wool
setblock 530 224 463 minecraft:red_terracotta
fill 531 224 463 537 307 463 minecraft:red_wool
setblock 535 224 505 minecraft:red_terracotta
fill 536 224 505 542 224 505 minecraft:red_wool
setblock 538 224 463 minecraft:red_terracotta
fill 539 224 463 541 307 463 minecraft:red_wool
setblock 542 224 463 minecraft:red_terracotta
fill 543 224 463 556 224 463 minecraft:red_wool
setblock 543 224 505 minecraft:red_terracotta
fill 544 224 505 545 307 505 minecraft:red_wool
fill 549 224 505 553 307 505 minecraft:red_wool
setblock 554 224 505 minecraft:red_terracotta
fill 555 224 505 556 307 505 minecraft:red_wool
setblock 557 224 463 minecraft:red_terracotta
fill 557 224 505 557 225 505 minecraft:red_terracotta
fill 558 224 463 558 307 463 minecraft:red_wool
fill 558 224 505 559 224 505 minecraft:red_wool
setblock 559 224 463 minecraft:red_terracotta
fill 559 224 464 559 307 467 minecraft:red_wool
fill 559 224 472 559 307 472 minecraft:red_wool
setblock 559 224 473 minecraft:red_terracotta
fill 559 224 474 559 307 476 minecraft:red_wool
setblock 559 224 477 minecraft:red_terracotta
fill 559 224 478 559 224 488 minecraft:red_wool
setblock 559 224 489 minecraft:red_terracotta
fill 559 224 490 559 307 493 minecraft:red_wool
fill 559 224 495 559 224 499 minecraft:red_wool
setblock 559 224 500 minecraft:red_terracotta
fill 559 224 501 559 307 501 minecraft:red_wool
fill 517 225 468 517 307 468 minecraft:red_wool
setblock 517 225 469 minecraft:red_terracotta
fill 517 225 470 517 307 473 minecraft:red_wool
setblock 517 225 474 minecraft:red_terracotta
fill 517 225 475 517 307 476 minecraft:red_wool
setblock 517 225 477 minecraft:red_terracotta
fill 517 225 478 517 307 484 minecraft:red_wool
fill 517 225 489 517 253 493 minecraft:red_wool
setblock 517 225 494 minecraft:red_terracotta
fill 517 225 495 517 307 501 minecraft:red_wool
setblock 517 225 502 minecraft:red_terracotta
fill 517 225 503 517 307 505 minecraft:red_wool
setblock 518 225 470 minecraft:gold_block
setblock 518 225 477 minecraft:gold_block
setblock 518 225 484 minecraft:gold_block
setblock 518 225 491 minecraft:gold_block
setblock 518 225 498 minecraft:gold_block
setblock 519 225 464 minecraft:gold_block
setblock 519 225 504 minecraft:gold_block
fill 520 225 463 520 307 463 minecraft:red_wool
fill 520 225 505 520 307 505 minecraft:red_wool
fill 523 225 463 523 307 463 minecraft:red_wool
setblock 526 225 464 minecraft:gold_block
setblock 526 225 504 minecraft:gold_block
fill 526 225 505 528 307 505 minecraft:red_wool
setblock 529 225 505 minecraft:red_terracotta
fill 530 225 463 530 307 463 minecraft:red_wool
fill 530 225 505 541 307 505 minecraft:red_wool
setblock 533 225 464 minecraft:gold_block
setblock 533 225 504 minecraft:gold_block
fill 538 225 463 538 307 463 minecraft:red_wool
setblock 540 225 464 minecraft:gold_block
setblock 540 225 504 minecraft:gold_block
fill 542 225 463 555 307 463 minecraft:red_wool
setblock 542 225 505 minecraft:red_terracotta
fill 543 225 505 543 307 505 minecraft:red_wool
fill 546 225 505 546 307 505 minecraft:red_wool
setblock 547 225 464 minecraft:gold_block
setblock 547 225 504 minecraft:gold_block
setblock 554 225 464 minecraft:gold_block
setblock 554 225 504 minecraft:gold_block
fill 554 225 505 554 307 505 minecraft:red_wool
setblock 556 225 463 minecraft:red_terracotta
fill 557 225 463 557 307 463 minecraft:red_wool
setblock 558 225 467 minecraft:gold_block
setblock 558 225 474 minecraft:gold_block
setblock 558 225 481 minecraft:gold_block
setblock 558 225 488 minecraft:gold_block
setblock 558 225 495 minecraft:gold_block
setblock 558 225 502 minecraft:gold_block
fill 558 225 505 558 307 505 minecraft:red_wool
fill 559 225 463 559 307 463 minecraft:red_wool
fill 559 225 468 559 307 468 minecraft:red_wool
setblock 559 225 469 minecraft:red_terracotta
fill 559 225 470 559 307 471 minecraft:red_wool
fill 559 225 473 559 307 473 minecraft:red_wool
fill 559 225 477 559 307 480 minecraft:red_wool
setblock 559 225 481 minecraft:red_terracotta
fill 559 225 482 559 307 489 minecraft:red_wool
fill 559 225 494 559 307 498 minecraft:red_wool
setblock 559 225 499 minecraft:red_terracotta
fill 559 225 500 559 307 500 minecraft:red_wool
setblock 559 225 502 minecraft:red_terracotta
fill 559 225 503 559 307 504 minecraft:red_wool
setblock 559 225 505 minecraft:red_terracotta
fill 517 226 469 517 307 469 minecraft:red_wool
fill 517 226 474 517 307 474 minecraft:red_wool
fill 517 226 477 517 307 477 minecraft:red_wool
fill 517 226 494 517 307 494 minecraft:red_wool
fill 517 226 502 517 307 502 minecraft:red_wool
setblock 518 226 464 minecraft:gold_block
setblock 518 226 471 minecraft:gold_block
setblock 518 226 478 minecraft:gold_block
setblock 518 226 485 minecraft:gold_block
setblock 518 226 492 minecraft:gold_block
setblock 518 226 499 minecraft:gold_block
setblock 520 226 504 minecraft:gold_block
setblock 525 226 464 minecraft:gold_block
setblock 527 226 504 minecraft:gold_block
fill 529 226 505 529 307 505 minecraft:red_wool
setblock 532 226 464 minecraft:gold_block
setblock 534 226 504 minecraft:gold_block
setblock 539 226 464 minecraft:gold_block
setblock 541 226 504 minecraft:gold_block
fill 542 226 505 542 307 505 minecraft:red_wool
setblock 546 226 464 minecraft:gold_block
setblock 548 226 504 minecraft:gold_block
setblock 553 226 464 minecraft:gold_block
setblock 555 226 504 minecraft:gold_block
fill 556 226 463 556 307 463 minecraft:red_wool
fill 557 226 505 557 307 505 minecraft:red_wool
setblock 558 226 466 minecraft:gold_block
setblock 558 226 473 minecraft:gold_block
setblock 558 226 480 minecraft:gold_block
setblock 558 226 487 minecraft:gold_block
setblock 558 226 494 minecraft:gold_block
setblock 558 226 501 minecraft:gold_block
fill 559 226 469 559 307 469 minecraft:red_wool
fill 559 226 481 559 307 481 minecraft:red_wool
fill 559 226 499 559 307 499 minecraft:red_wool
fill 559 226 502 559 307 502 minecraft:red_wool
fill 559 226 505 559 307 505 minecraft:red_wool
setblock 518 227 465 minecraft:gold_block
setblock 518 227 472 minecraft:gold_block
setblock 518 227 479 minecraft:gold_block
setblock 518 227 486 minecraft:gold_block
setblock 518 227 493 minecraft:gold_block
setblock 518 227 500 minecraft:gold_block
setblock 521 227 504 minecraft:gold_block
setblock 524 227 464 minecraft:gold_block
setblock 528 227 504 minecraft:gold_block
setblock 531 227 464 minecraft:gold_block
setblock 535 227 504 minecraft:gold_block
setblock 538 227 464 minecraft:gold_block
setblock 542 227 504 minecraft:gold_block
setblock 545 227 464 minecraft:gold_block
setblock 549 227 504 minecraft:gold_block
setblock 552 227 464 minecraft:gold_block
setblock 556 227 504 minecraft:gold_block
setblock 558 227 465 minecraft:gold_block
setblock 558 227 472 minecraft:gold_block
setblock 558 227 479 minecraft:gold_block
setblock 558 227 486 minecraft:gold_block
setblock 558 227 493 minecraft:gold_block
setblock 558 227 500 minecraft:gold_block
setblock 518 228 466 minecraft:gold_block
setblock 518 228 473 minecraft:gold_block
setblock 518 228 480 minecraft:gold_block
setblock 518 228 487 minecraft:gold_block
setblock 518 228 494 minecraft:gold_block
setblock 518 228 501 minecraft:gold_block
setblock 522 228 504 minecraft:gold_block
setblock 523 228 464 minecraft:gold_block
setblock 529 228 504 minecraft:gold_block
setblock 530 228 464 minecraft:gold_block
setblock 536 228 504 minecraft:gold_block
setblock 537 228 464 minecraft:gold_block
setblock 543 228 504 minecraft:gold_block
setblock 544 228 464 minecraft:gold_block
setblock 550 228 504 minecraft:gold_block
setblock 551 228 464 minecraft:gold_block
setblock 557 228 504 minecraft:gold_block
setblock 558 228 464 minecraft:gold_block
setblock 558 228 471 minecraft:gold_block
setblock 558 228 478 minecraft:gold_block
setblock 558 228 485 minecraft:gold_block
setblock 558 228 492 minecraft:gold_block
setblock 558 228 499 minecraft:gold_block
fill 518 229 467 518 230 467 minecraft:gold_block
fill 518 229 474 518 230 474 minecraft:gold_block
fill 518 229 481 518 230 481 minecraft:gold_block
fill 518 229 488 518 230 488 minecraft:gold_block
fill 518 229 495 518 230 495 minecraft:gold_block
fill 518 229 502 518 230 502 minecraft:gold_block
fill 522 229 464 522 230 464 minecraft:gold_block
fill 523 229 504 523 230 504 minecraft:gold_block
fill 529 229 464 529 230 464 minecraft:gold_block
fill 530 229 465 536 230 465 minecraft:white_wool
fill 530 229 504 530 230 504 minecraft:gold_block
fill 536 229 464 536 230 464 minecraft:gold_block
fill 537 229 504 537 230 504 minecraft:gold_block
fill 543 229 464 543 230 464 minecraft:gold_block
fill 544 229 504 544 230 504 minecraft:gold_block
fill 550 229 464 550 230 464 minecraft:gold_block
fill 551 229 504 551 230 504 minecraft:gold_block
fill 557 229 464 557 230 464 minecraft:gold_block
fill 558 229 470 558 230 470 minecraft:gold_block
fill 558 229 477 558 230 477 minecraft:gold_block
fill 558 229 484 558 230 484 minecraft:gold_block
fill 558 229 491 558 230 491 minecraft:gold_block
fill 558 229 498 558 230 498 minecraft:gold_block
fill 558 229 504 558 230 504 minecraft:gold_block
fill 518 230 464 518 230 466 minecraft:gold_block
setblock 518 230 468 minecraft:gold_block
fill 518 230 470 518 230 473 minecraft:gold_block
setblock 518 230 475 minecraft:gold_block
fill 518 230 477 518 230 480 minecraft:gold_block
setblock 518 230 482 minecraft:gold_block
fill 518 230 484 518 230 487 minecraft:gold_block
setblock 518 230 489 minecraft:gold_block
fill 518 230 491 518 230 494 minecraft:gold_block
setblock 518 230 496 minecraft:gold_block
fill 518 230 498 518 230 501 minecraft:gold_block
setblock 518 230 503 minecraft:gold_block
setblock 519 230 464 minecraft:gold_block
fill 519 230 504 522 230 504 minecraft:gold_block
setblock 520 230 466 minecraft:light[level=12]
setblock 520 230 474 minecraft:light[level=12]
setblock 520 230 482 minecraft:light[level=12]
setblock 520 230 490 minecraft:light[level=12]
setblock 521 230 464 minecraft:gold_block
fill 523 230 464 526 230 464 minecraft:gold_block
setblock 524 230 504 minecraft:gold_block
fill 526 230 504 529 230 504 minecraft:gold_block
setblock 528 230 464 minecraft:gold_block
setblock 528 230 466 minecraft:light[level=12]
setblock 528 230 474 minecraft:light[level=12]
setblock 528 230 482 minecraft:light[level=12]
setblock 528 230 490 minecraft:light[level=12]
setblock 528 230 498 minecraft:light[level=12]
fill 530 230 464 533 230 464 minecraft:gold_block
setblock 531 230 504 minecraft:gold_block
fill 533 230 504 536 230 504 minecraft:gold_block
setblock 535 230 464 minecraft:gold_block
setblock 536 230 466 minecraft:light[level=12]
setblock 536 230 474 minecraft:light[level=12]
setblock 536 230 482 minecraft:light[level=12]
setblock 536 230 490 minecraft:light[level=12]
setblock 536 230 498 minecraft:light[level=12]
fill 537 230 464 540 230 464 minecraft:gold_block
setblock 538 230 504 minecraft:gold_block
fill 540 230 504 543 230 504 minecraft:gold_block
setblock 542 230 464 minecraft:gold_block
fill 544 230 464 547 230 464 minecraft:gold_block
setblock 544 230 466 minecraft:light[level=12]
setblock 544 230 474 minecraft:light[level=12]
setblock 544 230 482 minecraft:light[level=12]
setblock 544 230 490 minecraft:light[level=12]
setblock 544 230 498 minecraft:light[level=12]
setblock 545 230 504 minecraft:gold_block
fill 547 230 504 550 230 504 minecraft:gold_block
setblock 549 230 464 minecraft:gold_block
fill 551 230 464 554 230 464 minecraft:gold_block
setblock 552 230 466 minecraft:light[level=12]
setblock 552 230 474 minecraft:light[level=12]
setblock 552 230 482 minecraft:light[level=12]
setblock 552 230 490 minecraft:light[level=12]
setblock 552 230 498 minecraft:light[level=12]
setblock 552 230 504 minecraft:gold_block
fill 554 230 504 557 230 504 minecraft:gold_block
setblock 556 230 464 minecraft:gold_block
fill 558 230 464 558 230 467 minecraft:gold_block
setblock 558 230 469 minecraft:gold_block
fill 558 230 471 558 230 474 minecraft:gold_block
setblock 558 230 476 minecraft:gold_block
fill 558 230 478 558 230 481 minecraft:gold_block
setblock 558 230 483 minecraft:gold_block
fill 558 230 485 558 230 488 minecraft:gold_block
setblock 558 230 490 minecraft:gold_block
fill 558 230 492 558 230 495 minecraft:gold_block
setblock 558 230 497 minecraft:gold_block
fill 558 230 499 558 230 502 minecraft:gold_block
setblock 518 232 470 minecraft:gold_block
setblock 518 232 477 minecraft:gold_block
setblock 518 232 484 minecraft:gold_block
setblock 518 232 491 minecraft:gold_block
setblock 518 232 498 minecraft:gold_block
setblock 519 232 464 minecraft:gold_block
setblock 519 232 504 minecraft:gold_block
setblock 526 232 464 minecraft:gold_block
setblock 526 232 504 minecraft:gold_block
setblock 533 232 464 minecraft:gold_block
setblock 533 232 504 minecraft:gold_block
setblock 540 232 464 minecraft:gold_block
setblock 540 232 504 minecraft:gold_block
setblock 547 232 464 minecraft:gold_block
setblock 547 232 504 minecraft:gold_block
setblock 554 232 464 minecraft:gold_block
setblock 554 232 504 minecraft:gold_block
setblock 558 232 467 minecraft:gold_block
setblock 558 232 474 minecraft:gold_block
setblock 558 232 481 minecraft:gold_block
setblock 558 232 488 minecraft:gold_block
setblock 558 232 495 minecraft:gold_block
setblock 558 232 502 minecraft:gold_block
setblock 518 233 464 minecraft:gold_block
setblock 518 233 471 minecraft:gold_block
setblock 518 233 478 minecraft:gold_block
setblock 518 233 485 minecraft:gold_block
setblock 518 233 492 minecraft:gold_block
setblock 518 233 499 minecraft:gold_block
setblock 520 233 504 minecraft:gold_block
setblock 525 233 464 minecraft:gold_block
setblock 527 233 504 minecraft:gold_block
setblock 532 233 464 minecraft:gold_block
setblock 534 233 504 minecraft:gold_block
setblock 539 233 464 minecraft:gold_block
setblock 541 233 504 minecraft:gold_block
setblock 546 233 464 minecraft:gold_block
setblock 548 233 504 minecraft:gold_block
setblock 553 233 464 minecraft:gold_block
setblock 555 233 504 minecraft:gold_block
setblock 558 233 466 minecraft:gold_block
setblock 558 233 473 minecraft:gold_block
setblock 558 233 480 minecraft:gold_block
setblock 558 233 487 minecraft:gold_block
setblock 558 233 494 minecraft:gold_block
setblock 558 233 501 minecraft:gold_block
setblock 518 234 465 minecraft:gold_block
setblock 518 234 472 minecraft:gold_block
setblock 518 234 479 minecraft:gold_block
setblock 518 234 486 minecraft:gold_block
setblock 518 234 493 minecraft:gold_block
setblock 518 234 500 minecraft:gold_block
setblock 521 234 504 minecraft:gold_block
setblock 524 234 464 minecraft:gold_block
setblock 528 234 504 minecraft:gold_block
setblock 531 234 464 minecraft:gold_block
setblock 535 234 504 minecraft:gold_block
setblock 538 234 464 minecraft:gold_block
setblock 542 234 504 minecraft:gold_block
setblock 545 234 464 minecraft:gold_block
setblock 549 234 504 minecraft:gold_block
setblock 552 234 464 minecraft:gold_block
setblock 556 234 504 minecraft:gold_block
setblock 558 234 465 minecraft:gold_block
setblock 558 234 472 minecraft:gold_block
setblock 558 234 479 minecraft:gold_block
setblock 558 234 486 minecraft:gold_block
setblock 558 234 493 minecraft:gold_block
setblock 558 234 500 minecraft:gold_block
setblock 518 235 466 minecraft:gold_block
setblock 518 235 473 minecraft:gold_block
setblock 518 235 480 minecraft:gold_block
setblock 518 235 487 minecraft:gold_block
setblock 518 235 494 minecraft:gold_block
setblock 518 235 501 minecraft:gold_block
setblock 522 235 504 minecraft:gold_block
setblock 523 235 464 minecraft:gold_block
setblock 529 235 504 minecraft:gold_block
setblock 530 235 464 minecraft:gold_block
setblock 536 235 504 minecraft:gold_block
setblock 537 235 464 minecraft:gold_block
setblock 543 235 504 minecraft:gold_block
setblock 544 235 464 minecraft:gold_block
setblock 550 235 504 minecraft:gold_block
setblock 551 235 464 minecraft:gold_block
setblock 557 235 504 minecraft:gold_block
setblock 558 235 464 minecraft:gold_block
setblock 558 235 471 minecraft:gold_block
setblock 558 235 478 minecraft:gold_block
setblock 558 235 485 minecraft:gold_block
setblock 558 235 492 minecraft:gold_block
setblock 558 235 499 minecraft:gold_block
setblock 520 238 466 minecraft:light[level=12]
setblock 520 238 474 minecraft:light[level=12]
setblock 520 238 482 minecraft:light[level=12]
setblock 520 238 490 minecraft:light[level=12]
setblock 520 238 498 minecraft:light[level=12]
setblock 528 238 466 minecraft:light[level=12]
setblock 528 238 474 minecraft:light[level=12]
setblock 528 238 482 minecraft:light[level=12]
setblock 528 238 490 minecraft:light[level=12]
setblock 528 238 498 minecraft:light[level=12]
setblock 536 238 466 minecraft:light[level=12]
setblock 536 238 474 minecraft:light[level=12]
setblock 536 238 482 minecraft:light[level=12]
setblock 536 238 490 minecraft:light[level=12]
setblock 536 238 498 minecraft:light[level=12]
setblock 544 238 466 minecraft:light[level=12]
setblock 544 238 474 minecraft:light[level=12]
setblock 544 238 482 minecraft:light[level=12]
setblock 544 238 490 minecraft:light[level=12]
setblock 544 238 498 minecraft:light[level=12]
setblock 552 238 466 minecraft:light[level=12]
setblock 552 238 474 minecraft:light[level=12]
setblock 552 238 482 minecraft:light[level=12]
setblock 552 238 490 minecraft:light[level=12]
setblock 552 238 498 minecraft:light[level=12]
fill 518 241 464 520 242 474 minecraft:black_concrete
fill 518 241 475 558 242 475 minecraft:gold_block
fill 518 241 476 520 242 486 minecraft:black_concrete
fill 518 241 487 535 241 487 minecraft:gold_block
fill 518 241 488 520 242 498 minecraft:black_concrete
fill 518 241 499 558 242 499 minecraft:gold_block
fill 518 241 500 520 242 504 minecraft:black_concrete
fill 521 241 464 521 242 474 minecraft:white_wool
fill 521 241 476 521 242 486 minecraft:white_wool
fill 521 241 488 521 242 498 minecraft:white_wool
fill 521 241 500 521 242 504 minecraft:white_wool
fill 522 241 464 524 242 474 minecraft:black_concrete
fill 522 241 476 524 242 486 minecraft:black_concrete
fill 522 241 488 524 242 498 minecraft:black_concrete
fill 522 241 500 524 242 504 minecraft:black_concrete
fill 525 241 464 525 242 474 minecraft:white_wool
fill 525 241 476 525 242 486 minecraft:white_wool
fill 525 241 488 525 242 498 minecraft:white_wool
fill 525 241 500 525 242 504 minecraft:white_wool
fill 526 241 464 528 242 474 minecraft:black_concrete
fill 526 241 476 528 242 486 minecraft:black_concrete
fill 526 241 488 528 242 498 minecraft:black_concrete
fill 526 241 500 528 242 504 minecraft:black_concrete
fill 529 241 464 529 242 474 minecraft:white_wool
fill 529 241 476 529 242 486 minecraft:white_wool
fill 529 241 488 529 242 498 minecraft:white_wool
fill 529 241 500 529 242 504 minecraft:white_wool
fill 530 241 464 532 242 474 minecraft:black_concrete
fill 530 241 476 532 242 486 minecraft:black_concrete
fill 530 241 488 532 242 498 minecraft:black_concrete
fill 530 241 500 532 242 504 minecraft:black_concrete
fill 533 241 464 533 242 474 minecraft:white_wool
fill 533 241 476 533 242 486 minecraft:white_wool
fill 533 241 488 533 242 498 minecraft:white_wool
fill 533 241 500 533 242 504 minecraft:white_wool
fill 534 241 464 536 242 474 minecraft:black_concrete
fill 534 241 476 536 241 486 minecraft:black_concrete
fill 534 241 488 536 241 498 minecraft:black_concrete
fill 534 241 500 536 242 504 minecraft:black_concrete
fill 537 241 464 537 242 474 minecraft:white_wool
fill 537 241 476 537 241 485 minecraft:white_wool
fill 537 241 489 537 241 498 minecraft:white_wool
fill 537 241 500 537 242 504 minecraft:white_wool
fill 538 241 464 540 242 474 minecraft:black_concrete
fill 538 241 476 540 241 484 minecraft:black_concrete
fill 538 241 490 540 241 498 minecraft:black_concrete
fill 538 241 500 540 242 504 minecraft:black_concrete
fill 539 241 485 540 241 485 minecraft:black_concrete
fill 539 241 489 540 241 489 minecraft:black_concrete
setblock 540 241 486 minecraft:black_concrete
setblock 540 241 488 minecraft:black_concrete
fill 541 241 464 541 242 474 minecraft:white_wool
fill 541 241 476 541 241 486 minecraft:white_wool
fill 541 241 487 558 241 487 minecraft:gold_block
fill 541 241 488 541 241 498 minecraft:white_wool
fill 541 241 500 541 242 504 minecraft:white_wool
fill 542 241 464 544 242 474 minecraft:black_concrete
fill 542 241 476 544 242 486 minecraft:black_concrete
fill 542 241 488 544 242 498 minecraft:black_concrete
fill 542 241 500 544 242 504 minecraft:black_concrete
fill 545 241 464 545 242 474 minecraft:white_wool
fill 545 241 476 545 242 486 minecraft:white_wool
fill 545 241 488 545 242 498 minecraft:white_wool
fill 545 241 500 545 242 504 minecraft:white_wool
fill 546 241 464 548 242 474 minecraft:black_concrete
fill 546 241 476 548 242 486 minecraft:black_concrete
fill 546 241 488 548 242 498 minecraft:black_concrete
fill 546 241 500 548 242 504 minecraft:black_concrete
fill 549 241 464 549 242 474 minecraft:white_wool
fill 549 241 476 549 242 486 minecraft:white_wool
fill 549 241 488 549 242 498 minecraft:white_wool
fill 549 241 500 549 242 504 minecraft:white_wool
fill 550 241 464 552 242 474 minecraft:black_concrete
fill 550 241 476 552 242 486 minecraft:black_concrete
fill 550 241 488 552 242 498 minecraft:black_concrete
fill 550 241 500 552 242 504 minecraft:black_concrete
fill 553 241 464 553 242 474 minecraft:white_wool
fill 553 241 476 553 242 486 minecraft:white_wool
fill 553 241 488 553 242 498 minecraft:white_wool
fill 553 241 500 553 242 504 minecraft:white_wool
fill 554 241 464 556 242 474 minecraft:black_concrete
fill 554 241 476 556 242 486 minecraft:black_concrete
fill 554 241 488 556 242 498 minecraft:black_concrete
fill 554 241 500 556 242 504 minecraft:black_concrete
fill 557 241 464 557 242 474 minecraft:white_wool
fill 557 241 476 557 242 486 minecraft:white_wool
fill 557 241 488 557 242 498 minecraft:white_wool
fill 557 241 500 557 242 504 minecraft:white_wool
fill 558 241 464 558 242 474 minecraft:black_concrete
fill 558 241 476 558 242 486 minecraft:black_concrete
fill 558 241 488 558 242 498 minecraft:black_concrete
fill 558 241 500 558 242 504 minecraft:black_concrete
fill 518 242 487 534 242 487 minecraft:gold_block
fill 534 242 476 534 242 486 minecraft:black_concrete
fill 534 242 488 534 242 498 minecraft:black_concrete
fill 535 242 476 535 242 485 minecraft:black_concrete
fill 535 242 486 535 242 488 minecraft:ochre_froglight
fill 535 242 489 535 242 498 minecraft:black_concrete
fill 536 242 476 536 242 484 minecraft:black_concrete
fill 536 242 485 536 242 486 minecraft:ochre_froglight
fill 536 242 488 536 242 489 minecraft:ochre_froglight
fill 536 242 490 536 242 498 minecraft:black_concrete
fill 537 242 476 537 242 483 minecraft:white_wool
fill 537 242 484 537 242 485 minecraft:ochre_froglight
fill 537 242 489 537 242 490 minecraft:ochre_froglight
fill 537 242 491 537 242 498 minecraft:white_wool
fill 538 242 476 540 242 483 minecraft:black_concrete
fill 538 242 484 539 242 484 minecraft:ochre_froglight
fill 538 242 490 539 242 490 minecraft:ochre_froglight
fill 538 242 491 540 242 498 minecraft:black_concrete
fill 539 242 485 540 242 485 minecraft:ochre_froglight
fill 539 242 489 540 242 489 minecraft:ochre_froglight
setblock 540 242 484 minecraft:black_concrete
fill 540 242 486 541 242 486 minecraft:ochre_froglight
fill 540 242 488 541 242 488 minecraft:ochre_froglight
setblock 540 242 490 minecraft:black_concrete
fill 541 242 476 541 242 485 minecraft:white_wool
setblock 541 242 487 minecraft:ochre_froglight
fill 541 242 489 541 242 498 minecraft:white_wool
fill 542 242 487 558 242 487 minecraft:gold_block
fill 518 246 469 518 246 470 minecraft:gold_block
fill 518 246 476 518 246 477 minecraft:gold_block
fill 518 246 483 518 246 484 minecraft:gold_block
fill 518 246 490 518 246 491 minecraft:gold_block
fill 518 246 497 518 246 498 minecraft:gold_block
fill 518 246 504 519 246 504 minecraft:gold_block
fill 519 246 464 520 246 464 minecraft:gold_block
setblock 520 246 466 minecraft:light[level=12]
setblock 520 246 474 minecraft:light[level=12]
setblock 520 246 482 minecraft:light[level=12]
setblock 520 246 490 minecraft:light[level=12]
setblock 520 246 498 minecraft:light[level=12]
fill 525 246 504 526 246 504 minecraft:gold_block
fill 526 246 464 527 246 464 minecraft:gold_block
setblock 528 246 466 minecraft:light[level=12]
setblock 528 246 474 minecraft:light[level=12]
setblock 528 246 482 minecraft:light[level=12]
setblock 528 246 490 minecraft:light[level=12]
setblock 528 246 498 minecraft:light[level=12]
fill 532 246 500 532 265 500 minecraft:white_wool
fill 532 246 504 533 246 504 minecraft:gold_block
fill 533 246 464 534 246 464 minecraft:gold_block
setblock 536 246 466 minecraft:light[level=12]
setblock 536 246 474 minecraft:light[level=12]
setblock 536 246 482 minecraft:light[level=12]
setblock 536 246 490 minecraft:light[level=12]
setblock 536 246 498 minecraft:light[level=12]
fill 539 246 469 539 262 469 minecraft:white_wool
fill 539 246 504 540 246 504 minecraft:gold_block
fill 540 246 464 541 246 464 minecraft:gold_block
setblock 544 246 466 minecraft:light[level=12]
setblock 544 246 474 minecraft:light[level=12]
setblock 544 246 482 minecraft:light[level=12]
setblock 544 246 490 minecraft:light[level=12]
setblock 544 246 498 minecraft:light[level=12]
fill 546 246 504 547 246 504 minecraft:gold_block
fill 547 246 464 548 246 464 minecraft:gold_block
setblock 552 246 466 minecraft:light[level=12]
setblock 552 246 474 minecraft:light[level=12]
setblock 552 246 482 minecraft:light[level=12]
setblock 552 246 490 minecraft:light[level=12]
fill 552 246 493 552 251 493 minecraft:white_wool
setblock 552 246 498 minecraft:light[level=12]
fill 553 246 504 554 246 504 minecraft:gold_block
fill 554 246 464 555 246 464 minecraft:gold_block
fill 558 246 467 558 246 468 minecraft:gold_block
fill 558 246 474 558 246 475 minecraft:gold_block
fill 558 246 481 558 246 482 minecraft:gold_block
fill 558 246 488 558 246 489 minecraft:gold_block
fill 558 246 495 558 246 496 minecraft:gold_block
fill 558 246 502 558 246 503 minecraft:gold_block
setblock 518 247 464 minecraft:gold_block
fill 518 247 469 518 273 469 minecraft:gold_block
setblock 518 247 471 minecraft:gold_block
fill 518 247 476 518 273 476 minecraft:gold_block
setblock 518 247 478 minecraft:gold_block
fill 518 247 483 518 273 483 minecraft:gold_block
setblock 518 247 485 minecraft:gold_block
fill 518 247 490 518 273 490 minecraft:gold_block
setblock 518 247 492 minecraft:gold_block
fill 518 247 497 518 273 497 minecraft:gold_block
setblock 518 247 499 minecraft:gold_block
fill 518 247 504 518 273 504 minecraft:gold_block
fill 520 247 464 520 273 464 minecraft:gold_block
setblock 520 247 504 minecraft:gold_block
setblock 525 247 464 minecraft:gold_block
fill 525 247 504 525 273 504 minecraft:gold_block
fill 527 247 464 527 273 464 minecraft:gold_block
setblock 527 247 504 minecraft:gold_block
setblock 532 247 464 minecraft:gold_block
fill 532 247 504 532 273 504 minecraft:gold_block
fill 534 247 464 534 273 464 minecraft:gold_block
setblock 534 247 504 minecraft:gold_block
setblock 539 247 464 minecraft:gold_block
fill 539 247 504 539 273 504 minecraft:gold_block
fill 541 247 464 541 273 464 minecraft:gold_block
setblock 541 247 504 minecraft:gold_block
setblock 546 247 464 minecraft:gold_block
fill 546 247 504 546 273 504 minecraft:gold_block
fill 548 247 464 548 273 464 minecraft:gold_block
setblock 548 247 504 minecraft:gold_block
setblock 553 247 464 minecraft:gold_block
fill 553 247 504 553 273 504 minecraft:gold_block
fill 555 247 464 555 273 464 minecraft:gold_block
setblock 555 247 504 minecraft:gold_block
setblock 558 247 466 minecraft:gold_block
fill 558 247 468 558 273 468 minecraft:gold_block
setblock 558 247 473 minecraft:gold_block
fill 558 247 475 558 273 475 minecraft:gold_block
setblock 558 247 480 minecraft:gold_block
fill 558 247 482 558 273 482 minecraft:gold_block
setblock 558 247 487 minecraft:gold_block
fill 558 247 489 558 273 489 minecraft:gold_block
setblock 558 247 494 minecraft:gold_block
fill 558 247 496 558 273 496 minecraft:gold_block
setblock 558 247 501 minecraft:gold_block
fill 558 247 503 558 273 503 minecraft:gold_block
setblock 518 248 465 minecraft:gold_block
setblock 518 248 472 minecraft:gold_block
setblock 518 248 479 minecraft:gold_block
setblock 518 248 486 minecraft:gold_block
setblock 518 248 493 minecraft:gold_block
setblock 518 248 500 minecraft:gold_block
fill 521 248 492 521 251 492 minecraft:white_wool
setblock 521 248 504 minecraft:gold_block
setblock 524 248 464 minecraft:gold_block
setblock 528 248 504 minecraft:gold_block
setblock 531 248 464 minecraft:gold_block
setblock 535 248 504 minecraft:gold_block
setblock 538 248 464 minecraft:gold_block
setblock 542 248 504 minecraft:gold_block
setblock 545 248 464 minecraft:gold_block
setblock 549 248 504 minecraft:gold_block
setblock 552 248 464 minecraft:gold_block
setblock 556 248 504 minecraft:gold_block
setblock 558 248 465 minecraft:gold_block
setblock 558 248 472 minecraft:gold_block
setblock 558 248 479 minecraft:gold_block
setblock 558 248 486 minecraft:gold_block
setblock 558 248 493 minecraft:gold_block
setblock 558 248 500 minecraft:gold_block
fill 518 249 466 518 250 466 minecraft:gold_block
fill 518 249 473 518 250 473 minecraft:gold_block
fill 518 249 480 518 250 480 minecraft:gold_block
fill 518 249 487 518 250 487 minecraft:gold_block
fill 518 249 494 518 250 494 minecraft:gold_block
fill 518 249 501 518 250 501 minecraft:gold_block
fill 522 249 504 522 250 504 minecraft:gold_block
fill 523 249 464 523 250 464 minecraft:gold_block
fill 529 249 504 529 250 504 minecraft:gold_block
fill 530 249 464 530 250 464 minecraft:gold_block
fill 536 249 504 536 250 504 minecraft:gold_block
fill 537 249 464 537 250 464 minecraft:gold_block
fill 543 249 504 543 250 504 minecraft:gold_block
fill 544 249 464 544 250 464 minecraft:gold_block
fill 550 249 504 550 250 504 minecraft:gold_block
fill 551 249 464 551 250 464 minecraft:gold_block
fill 554 249 490 554 269 490 minecraft:white_wool
fill 557 249 504 557 250 504 minecraft:gold_block
fill 558 249 464 558 250 464 minecraft:gold_block
fill 558 249 471 558 250 471 minecraft:gold_block
fill 558 249 478 558 250 478 minecraft:gold_block
fill 558 249 485 558 250 485 minecraft:gold_block
fill 558 249 492 558 250 492 minecraft:gold_block
fill 558 249 499 558 250 499 minecraft:gold_block
fill 518 250 464 518 250 465 minecraft:gold_block
fill 518 250 467 518 250 468 minecraft:gold_block
fill 518 250 470 518 250 472 minecraft:gold_block
fill 518 250 474 518 250 475 minecraft:gold_block
fill 518 250 477 518 250 479 minecraft:gold_block
fill 518 250 481 518 250 482 minecraft:gold_block
fill 518 250 484 518 250 486 minecraft:gold_block
fill 518 250 488 518 250 489 minecraft:gold_block
fill 518 250 491 518 250 493 minecraft:gold_block
fill 518 250 495 518 250 496 minecraft:gold_block
fill 518 250 498 518 250 500 minecraft:gold_block
fill 518 250 502 518 250 503 minecraft:gold_block
setblock 519 250 464 minecraft:gold_block
fill 519 250 504 521 250 504 minecraft:gold_block
fill 521 250 464 522 250 464 minecraft:gold_block
fill 523 250 504 524 250 504 minecraft:gold_block
fill 524 250 464 526 250 464 minecraft:gold_block
fill 526 250 504 528 250 504 minecraft:gold_block
fill 528 250 464 529 250 464 minecraft:gold_block
fill 530 250 504 531 250 504 minecraft:gold_block
fill 531 250 464 533 250 464 minecraft:gold_block
fill 533 250 504 535 250 504 minecraft:gold_block
fill 535 250 464 536 250 464 minecraft:gold_block
fill 537 250 504 538 250 504 minecraft:gold_block
fill 538 250 464 540 250 464 minecraft:gold_block
fill 540 250 504 542 250 504 minecraft:gold_block
fill 542 250 464 543 250 464 minecraft:gold_block
fill 544 250 504 545 250 504 minecraft:gold_block
fill 545 250 464 547 250 464 minecraft:gold_block
fill 547 250 504 549 250 504 minecraft:gold_block
fill 549 250 464 550 250 464 minecraft:gold_block
fill 551 250 504 552 250 504 minecraft:gold_block
fill 552 250 464 554 250 464 minecraft:gold_block
fill 554 250 504 556 250 504 minecraft:gold_block
fill 556 250 464 557 250 464 minecraft:gold_block
fill 558 250 465 558 250 467 minecraft:gold_block
fill 558 250 469 558 250 470 minecraft:gold_block
fill 558 250 472 558 250 474 minecraft:gold_block
fill 558 250 476 558 250 477 minecraft:gold_block
fill 558 250 479 558 250 481 minecraft:gold_block
fill 558 250 483 558 250 484 minecraft:gold_block
fill 558 250 486 558 250 488 minecraft:gold_block
fill 558 250 490 558 250 491 minecraft:gold_block
fill 558 250 493 558 250 495 minecraft:gold_block
fill 558 250 497 558 250 498 minecraft:gold_block
fill 558 250 500 558 250 502 minecraft:gold_block
setblock 558 250 504 minecraft:gold_block
setblock 518 251 468 minecraft:gold_block
setblock 518 251 475 minecraft:gold_block
setblock 518 251 482 minecraft:gold_block
setblock 518 251 489 minecraft:gold_block
setblock 518 251 496 minecraft:gold_block
setblock 518 251 503 minecraft:gold_block
setblock 521 251 464 minecraft:gold_block
setblock 524 251 504 minecraft:gold_block
setblock 528 251 464 minecraft:gold_block
setblock 531 251 504 minecraft:gold_block
setblock 535 251 464 minecraft:gold_block
setblock 538 251 504 minecraft:gold_block
setblock 542 251 464 minecraft:gold_block
setblock 545 251 504 minecraft:gold_block
setblock 549 251 464 minecraft:gold_block
setblock 552 251 504 minecraft:gold_block
setblock 556 251 464 minecraft:gold_block
setblock 558 251 469 minecraft:gold_block
setblock 558 251 476 minecraft:gold_block
setblock 558 251 483 minecraft:gold_block
setblock 558 251 490 minecraft:gold_block
setblock 558 251 497 minecraft:gold_block
fill 518 252 488 521 252 489 minecraft:dark_oak_planks
fill 518 252 491 521 252 496 minecraft:dark_oak_planks
fill 519 252 490 521 252 490 minecraft:dark_oak_planks
fill 556 252 488 556 267 488 minecraft:white_wool
setblock 518 253 470 minecraft:gold_block
setblock 518 253 477 minecraft:gold_block
setblock 518 253 484 minecraft:gold_block
fill 518 253 488 521 253 489 minecraft:gold_block
fill 518 253 491 521 253 496 minecraft:gold_block
setblock 518 253 498 minecraft:gold_block
setblock 519 253 464 minecraft:gold_block
fill 519 253 490 521 253 490 minecraft:gold_block
setblock 519 253 504 minecraft:gold_block
setblock 526 253 464 minecraft:gold_block
setblock 526 253 504 minecraft:gold_block
setblock 533 253 464 minecraft:gold_block
setblock 533 253 504 minecraft:gold_block
setblock 540 253 464 minecraft:gold_block
setblock 540 253 504 minecraft:gold_block
setblock 547 253 464 minecraft:gold_block
setblock 547 253 504 minecraft:gold_block
setblock 554 253 464 minecraft:gold_block
setblock 554 253 504 minecraft:gold_block
setblock 558 253 467 minecraft:gold_block
setblock 558 253 474 minecraft:gold_block
setblock 558 253 481 minecraft:gold_block
setblock 558 253 488 minecraft:gold_block
setblock 558 253 495 minecraft:gold_block
setblock 558 253 502 minecraft:gold_block
fill 517 254 489 517 307 490 minecraft:red_wool
fill 517 254 491 517 257 493 minecraft:ochre_froglight
setblock 518 254 464 minecraft:gold_block
setblock 518 254 471 minecraft:gold_block
setblock 518 254 478 minecraft:gold_block
setblock 518 254 485 minecraft:gold_block
setblock 518 254 492 minecraft:gold_block
setblock 518 254 499 minecraft:gold_block
setblock 520 254 466 minecraft:light[level=12]
setblock 520 254 474 minecraft:light[level=12]
setblock 520 254 482 minecraft:light[level=12]
setblock 520 254 490 minecraft:light[level=12]
setblock 520 254 498 minecraft:light[level=12]
setblock 520 254 504 minecraft:gold_block
fill 521 254 488 521 254 496 minecraft:red_wool
setblock 525 254 464 minecraft:gold_block
setblock 527 254 504 minecraft:gold_block
setblock 528 254 466 minecraft:light[level=12]
setblock 528 254 474 minecraft:light[level=12]
setblock 528 254 482 minecraft:light[level=12]
setblock 528 254 490 minecraft:light[level=12]
setblock 528 254 498 minecraft:light[level=12]
setblock 532 254 464 minecraft:gold_block
setblock 534 254 504 minecraft:gold_block
setblock 536 254 466 minecraft:light[level=12]
setblock 536 254 474 minecraft:light[level=12]
setblock 536 254 482 minecraft:light[level=12]
setblock 536 254 490 minecraft:light[level=12]
setblock 536 254 498 minecraft:light[level=12]
setblock 539 254 464 minecraft:gold_block
setblock 541 254 504 minecraft:gold_block
setblock 544 254 466 minecraft:light[level=12]
setblock 544 254 474 minecraft:light[level=12]
setblock 544 254 482 minecraft:light[level=12]
setblock 544 254 490 minecraft:light[level=12]
setblock 544 254 498 minecraft:light[level=12]
fill 544 254 501 544 255 503 minecraft:white_wool
setblock 546 254 464 minecraft:gold_block
setblock 548 254 504 minecraft:gold_block
setblock 552 254 466 minecraft:light[level=12]
setblock 552 254 474 minecraft:light[level=12]
setblock 552 254 482 minecraft:light[level=12]
setblock 552 254 490 minecraft:light[level=12]
setblock 552 254 498 minecraft:light[level=12]
setblock 553 254 464 minecraft:gold_block
setblock 555 254 504 minecraft:gold_block
setblock 558 254 466 minecraft:gold_block
setblock 558 254 473 minecraft:gold_block
setblock 558 254 480 minecraft:gold_block
setblock 558 254 487 minecraft:gold_block
setblock 558 254 494 minecraft:gold_block
setblock 558 254 501 minecraft:gold_block
setblock 518 255 465 minecraft:gold_block
setblock 518 255 472 minecraft:gold_block
setblock 518 255 479 minecraft:gold_block
setblock 518 255 486 minecraft:gold_block
setblock 518 255 493 minecraft:gold_block
setblock 518 255 500 minecraft:gold_block
setblock 521 255 488 minecraft:gold_block
setblock 521 255 492 minecraft:gold_block
setblock 521 255 496 minecraft:gold_block
setblock 521 255 504 minecraft:gold_block
setblock 524 255 464 minecraft:gold_block
setblock 528 255 504 minecraft:gold_block
setblock 531 255 464 minecraft:gold_block
setblock 535 255 504 minecraft:gold_block
setblock 538 255 464 minecraft:gold_block
setblock 542 255 504 minecraft:gold_block
setblock 545 255 464 minecraft:gold_block
setblock 549 255 504 minecraft:gold_block
setblock 552 255 464 minecraft:gold_block
setblock 556 255 504 minecraft:gold_block
setblock 558 255 465 minecraft:gold_block
setblock 558 255 472 minecraft:gold_block
setblock 558 255 479 minecraft:gold_block
setblock 558 255 486 minecraft:gold_block
setblock 558 255 493 minecraft:gold_block
setblock 558 255 500 minecraft:gold_block
setblock 518 256 466 minecraft:gold_block
setblock 518 256 473 minecraft:gold_block
setblock 518 256 480 minecraft:gold_block
setblock 518 256 487 minecraft:gold_block
setblock 518 256 494 minecraft:gold_block
setblock 518 256 501 minecraft:gold_block
setblock 522 256 504 minecraft:gold_block
setblock 523 256 464 minecraft:gold_block
setblock 529 256 504 minecraft:gold_block
setblock 530 256 464 minecraft:gold_block
setblock 536 256 504 minecraft:gold_block
setblock 537 256 464 minecraft:gold_block
setblock 543 256 504 minecraft:gold_block
setblock 544 256 464 minecraft:gold_block
setblock 550 256 504 minecraft:gold_block
setblock 551 256 464 minecraft:gold_block
setblock 557 256 504 minecraft:gold_block
setblock 558 256 464 minecraft:gold_block
setblock 558 256 471 minecraft:gold_block
setblock 558 256 478 minecraft:gold_block
setblock 558 256 485 minecraft:gold_block
setblock 558 256 492 minecraft:gold_block
setblock 558 256 499 minecraft:gold_block
setblock 518 257 467 minecraft:gold_block
setblock 518 257 474 minecraft:gold_block
setblock 518 257 481 minecraft:gold_block
setblock 518 257 488 minecraft:gold_block
setblock 518 257 495 minecraft:gold_block
setblock 518 257 502 minecraft:gold_block
setblock 522 257 464 minecraft:gold_block
setblock 523 257 504 minecraft:gold_block
setblock 529 257 464 minecraft:gold_block
setblock 530 257 504 minecraft:gold_block
setblock 536 257 464 minecraft:gold_block
setblock 537 257 504 minecraft:gold_block
setblock 543 257 464 minecraft:gold_block
setblock 544 257 504 minecraft:gold_block
setblock 550 257 464 minecraft:gold_block
setblock 551 257 504 minecraft:gold_block
setblock 557 257 464 minecraft:gold_block
setblock 558 257 470 minecraft:gold_block
setblock 558 257 477 minecraft:gold_block
setblock 558 257 484 minecraft:gold_block
setblock 558 257 491 minecraft:gold_block
setblock 558 257 498 minecraft:gold_block
setblock 558 257 504 minecraft:gold_block
fill 517 258 491 517 307 493 minecraft:red_wool
setblock 518 258 468 minecraft:gold_block
setblock 518 258 475 minecraft:gold_block
setblock 518 258 482 minecraft:gold_block
setblock 518 258 489 minecraft:gold_block
setblock 518 258 496 minecraft:gold_block
setblock 518 258 503 minecraft:gold_block
setblock 521 258 464 minecraft:gold_block
setblock 524 258 504 minecraft:gold_block
setblock 528 258 464 minecraft:gold_block
setblock 531 258 504 minecraft:gold_block
setblock 535 258 464 minecraft:gold_block
setblock 538 258 504 minecraft:gold_block
setblock 542 258 464 minecraft:gold_block
setblock 545 258 504 minecraft:gold_block
setblock 549 258 464 minecraft:gold_block
setblock 552 258 504 minecraft:gold_block
setblock 556 258 464 minecraft:gold_block
setblock 558 258 469 minecraft:gold_block
setblock 558 258 476 minecraft:gold_block
setblock 558 258 483 minecraft:gold_block
setblock 558 258 490 minecraft:gold_block
setblock 558 258 497 minecraft:gold_block
fill 518 260 464 518 260 468 minecraft:gold_block
fill 518 260 470 518 260 475 minecraft:gold_block
fill 518 260 477 518 260 482 minecraft:gold_block
fill 518 260 484 518 260 489 minecraft:gold_block
fill 518 260 491 518 260 496 minecraft:gold_block
fill 518 260 498 518 260 503 minecraft:gold_block
setblock 519 260 464 minecraft:gold_block
fill 519 260 504 524 260 504 minecraft:gold_block
fill 521 260 464 526 260 464 minecraft:gold_block
fill 526 260 504 531 260 504 minecraft:gold_block
fill 528 260 464 533 260 464 minecraft:gold_block
fill 533 260 504 538 260 504 minecraft:gold_block
fill 535 260 464 540 260 464 minecraft:gold_block
fill 540 260 504 545 260 504 minecraft:gold_block
fill 542 260 464 547 260 464 minecraft:gold_block
fill 547 260 504 552 260 504 minecraft:gold_block
fill 549 260 464 554 260 464 minecraft:gold_block
fill 554 260 504 558 260 504 minecraft:gold_block
fill 556 260 464 558 260 464 minecraft:gold_block
fill 558 260 465 558 260 467 minecraft:gold_block
fill 558 260 469 558 260 474 minecraft:gold_block
fill 558 260 476 558 260 481 minecraft:gold_block
fill 558 260 483 558 260 488 minecraft:gold_block
fill 558 260 490 558 260 495 minecraft:gold_block
fill 558 260 497 558 260 502 minecraft:gold_block
setblock 518 261 464 minecraft:gold_block
setblock 518 261 471 minecraft:gold_block
setblock 518 261 478 minecraft:gold_block
setblock 518 261 485 minecraft:gold_block
setblock 518 261 492 minecraft:gold_block
setblock 518 261 499 minecraft:gold_block
setblock 520 261 504 minecraft:gold_block
setblock 525 261 464 minecraft:gold_block
fill 525 261 498 525 273 498 minecraft:white_wool
setblock 527 261 504 minecraft:gold_block
setblock 532 261 464 minecraft:gold_block
setblock 534 261 504 minecraft:gold_block
setblock 539 261 464 minecraft:gold_block
setblock 541 261 504 minecraft:gold_block
setblock 546 261 464 minecraft:gold_block
setblock 548 261 504 minecraft:gold_block
setblock 553 261 464 minecraft:gold_block
setblock 555 261 504 minecraft:gold_block
setblock 558 261 466 minecraft:gold_block
setblock 558 261 473 minecraft:gold_block
setblock 558 261 480 minecraft:gold_block
setblock 558 261 487 minecraft:gold_block
setblock 558 261 494 minecraft:gold_block
setblock 558 261 501 minecraft:gold_block
setblock 518 262 465 minecraft:gold_block
setblock 518 262 472 minecraft:gold_block
setblock 518 262 479 minecraft:gold_block
setblock 518 262 486 minecraft:gold_block
setblock 518 262 493 minecraft:gold_block
setblock 518 262 500 minecraft:gold_block
setblock 520 262 466 minecraft:light[level=12]
setblock 520 262 474 minecraft:light[level=12]
setblock 520 262 482 minecraft:light[level=12]
setblock 520 262 490 minecraft:light[level=12]
setblock 520 262 498 minecraft:light[level=12]
setblock 521 262 504 minecraft:gold_block
setblock 524 262 464 minecraft:gold_block
setblock 528 262 466 minecraft:light[level=12]
setblock 528 262 474 minecraft:light[level=12]
setblock 528 262 482 minecraft:light[level=12]
setblock 528 262 490 minecraft:light[level=12]
setblock 528 262 498 minecraft:light[level=12]
setblock 528 262 504 minecraft:gold_block
setblock 531 262 464 minecraft:gold_block
setblock 535 262 504 minecraft:gold_block
setblock 536 262 466 minecraft:light[level=12]
setblock 536 262 474 minecraft:light[level=12]
setblock 536 262 482 minecraft:light[level=12]
setblock 536 262 490 minecraft:light[level=12]
setblock 536 262 498 minecraft:light[level=12]
setblock 538 262 464 minecraft:gold_block
setblock 542 262 504 minecraft:gold_block
setblock 544 262 466 minecraft:light[level=12]
setblock 544 262 474 minecraft:light[level=12]
setblock 544 262 482 minecraft:light[level=12]
setblock 544 262 490 minecraft:light[level=12]
setblock 544 262 498 minecraft:light[level=12]
setblock 545 262 464 minecraft:gold_block
setblock 549 262 504 minecraft:gold_block
setblock 552 262 464 minecraft:gold_block
setblock 552 262 466 minecraft:light[level=12]
setblock 552 262 474 minecraft:light[level=12]
setblock 552 262 482 minecraft:light[level=12]
setblock 552 262 490 minecraft:light[level=12]
setblock 552 262 498 minecraft:light[level=12]
setblock 556 262 504 minecraft:gold_block
setblock 558 262 465 minecraft:gold_block
setblock 558 262 472 minecraft:gold_block
setblock 558 262 479 minecraft:gold_block
setblock 558 262 486 minecraft:gold_block
setblock 558 262 493 minecraft:gold_block
setblock 558 262 500 minecraft:gold_block
setblock 518 263 466 minecraft:gold_block
setblock 518 263 473 minecraft:gold_block
setblock 518 263 480 minecraft:gold_block
setblock 518 263 487 minecraft:gold_block
setblock 518 263 494 minecraft:gold_block
setblock 518 263 501 minecraft:gold_block
setblock 522 263 504 minecraft:gold_block
setblock 523 263 464 minecraft:gold_block
setblock 529 263 504 minecraft:gold_block
setblock 530 263 464 minecraft:gold_block
setblock 536 263 504 minecraft:gold_block
setblock 537 263 464 minecraft:gold_block
setblock 543 263 504 minecraft:gold_block
setblock 544 263 464 minecraft:gold_block
setblock 550 263 504 minecraft:gold_block
setblock 551 263 464 minecraft:gold_block
setblock 557 263 504 minecraft:gold_block
setblock 558 263 464 minecraft:gold_block
setblock 558 263 471 minecraft:gold_block
setblock 558 263 478 minecraft:gold_block
setblock 558 263 485 minecraft:gold_block
setblock 558 263 492 minecraft:gold_block
setblock 558 263 499 minecraft:gold_block
setblock 518 264 467 minecraft:gold_block
setblock 518 264 474 minecraft:gold_block
setblock 518 264 481 minecraft:gold_block
setblock 518 264 488 minecraft:gold_block
setblock 518 264 495 minecraft:gold_block
setblock 518 264 502 minecraft:gold_block
setblock 522 264 464 minecraft:gold_block
setblock 523 264 504 minecraft:gold_block
setblock 529 264 464 minecraft:gold_block
setblock 530 264 504 minecraft:gold_block
setblock 536 264 464 minecraft:gold_block
setblock 537 264 504 minecraft:gold_block
setblock 543 264 464 minecraft:gold_block
setblock 544 264 504 minecraft:gold_block
setblock 550 264 464 minecraft:gold_block
setblock 551 264 504 minecraft:gold_block
setblock 557 264 464 minecraft:gold_block
setblock 558 264 470 minecraft:gold_block
setblock 558 264 477 minecraft:gold_block
setblock 558 264 484 minecraft:gold_block
setblock 558 264 491 minecraft:gold_block
setblock 558 264 498 minecraft:gold_block
setblock 558 264 504 minecraft:gold_block
setblock 518 265 468 minecraft:gold_block
setblock 518 265 475 minecraft:gold_block
setblock 518 265 482 minecraft:gold_block
setblock 518 265 489 minecraft:gold_block
setblock 518 265 496 minecraft:gold_block
setblock 518 265 503 minecraft:gold_block
setblock 521 265 464 minecraft:gold_block
setblock 524 265 504 minecraft:gold_block
setblock 528 265 464 minecraft:gold_block
setblock 531 265 504 minecraft:gold_block
setblock 535 265 464 minecraft:gold_block
setblock 538 265 504 minecraft:gold_block
setblock 542 265 464 minecraft:gold_block
setblock 545 265 504 minecraft:gold_block
setblock 549 265 464 minecraft:gold_block
setblock 552 265 504 minecraft:gold_block
setblock 556 265 464 minecraft:gold_block
setblock 558 265 469 minecraft:gold_block
setblock 558 265 476 minecraft:gold_block
setblock 558 265 483 minecraft:gold_block
setblock 558 265 490 minecraft:gold_block
setblock 558 265 497 minecraft:gold_block
setblock 518 267 470 minecraft:gold_block
setblock 518 267 477 minecraft:gold_block
setblock 518 267 484 minecraft:gold_block
setblock 518 267 491 minecraft:gold_block
setblock 518 267 498 minecraft:gold_block
setblock 519 267 464 minecraft:gold_block
setblock 519 267 504 minecraft:gold_block
setblock 526 267 464 minecraft:gold_block
setblock 526 267 504 minecraft:gold_block
setblock 533 267 464 minecraft:gold_block
setblock 533 267 504 minecraft:gold_block
setblock 540 267 464 minecraft:gold_block
setblock 540 267 504 minecraft:gold_block
setblock 547 267 464 minecraft:gold_block
setblock 547 267 504 minecraft:gold_block
setblock 554 267 464 minecraft:gold_block
setblock 554 267 504 minecraft:gold_block
setblock 558 267 467 minecraft:gold_block
setblock 558 267 474 minecraft:gold_block
setblock 558 267 481 minecraft:gold_block
setblock 558 267 488 minecraft:gold_block
setblock 558 267 495 minecraft:gold_block
setblock 558 267 502 minecraft:gold_block
setblock 518 268 464 minecraft:gold_block
setblock 518 268 471 minecraft:gold_block
setblock 518 268 478 minecraft:gold_block
setblock 518 268 485 minecraft:gold_block
setblock 518 268 492 minecraft:gold_block
setblock 518 268 499 minecraft:gold_block
setblock 520 268 504 minecraft:gold_block
setblock 525 268 464 minecraft:gold_block
setblock 527 268 504 minecraft:gold_block
setblock 532 268 464 minecraft:gold_block
setblock 534 268 504 minecraft:gold_block
setblock 539 268 464 minecraft:gold_block
setblock 541 268 504 minecraft:gold_block
setblock 546 268 464 minecraft:gold_block
setblock 548 268 504 minecraft:gold_block
setblock 553 268 464 minecraft:gold_block
setblock 555 268 504 minecraft:gold_block
setblock 558 268 466 minecraft:gold_block
setblock 558 268 473 minecraft:gold_block
setblock 558 268 480 minecraft:gold_block
setblock 558 268 487 minecraft:gold_block
setblock 558 268 494 minecraft:gold_block
setblock 558 268 501 minecraft:gold_block
fill 518 269 465 518 270 465 minecraft:gold_block
fill 518 269 472 518 270 472 minecraft:gold_block
fill 518 269 479 518 270 479 minecraft:gold_block
fill 518 269 486 518 270 486 minecraft:gold_block
fill 518 269 493 518 270 493 minecraft:gold_block
fill 518 269 500 518 270 500 minecraft:gold_block
fill 521 269 504 521 270 504 minecraft:gold_block
fill 524 269 464 524 270 464 minecraft:gold_block
fill 528 269 504 528 270 504 minecraft:gold_block
fill 531 269 464 531 270 464 minecraft:gold_block
fill 535 269 504 535 270 504 minecraft:gold_block
fill 538 269 464 538 270 464 minecraft:gold_block
fill 542 269 504 542 270 504 minecraft:gold_block
fill 545 269 464 545 270 464 minecraft:gold_block
fill 549 269 504 549 270 504 minecraft:gold_block
fill 552 269 464 552 270 464 minecraft:gold_block
fill 556 269 504 556 270 504 minecraft:gold_block
fill 558 269 465 558 270 465 minecraft:gold_block
fill 558 269 472 558 270 472 minecraft:gold_block
fill 558 269 479 558 270 479 minecraft:gold_block
fill 558 269 486 558 270 486 minecraft:gold_block
fill 558 269 493 558 270 493 minecraft:gold_block
fill 558 269 500 558 270 500 minecraft:gold_block
fill 518 270 464 519 270 464 minecraft:gold_block
fill 518 270 466 518 270 468 minecraft:gold_block
fill 518 270 470 518 270 471 minecraft:gold_block
fill 518 270 473 518 270 475 minecraft:gold_block
fill 518 270 477 518 270 478 minecraft:gold_block
fill 518 270 480 518 270 482 minecraft:gold_block
fill 518 270 484 518 270 485 minecraft:gold_block
fill 518 270 487 518 270 489 minecraft:gold_block
fill 518 270 491 518 270 492 minecraft:gold_block
fill 518 270 494 518 270 496 minecraft:gold_block
fill 518 270 498 518 270 499 minecraft:gold_block
fill 518 270 501 518 270 503 minecraft:gold_block
fill 519 270 504 520 270 504 minecraft:gold_block
setblock 520 270 466 minecraft:light[level=12]
setblock 520 270 474 minecraft:light[level=12]
setblock 520 270 482 minecraft:light[level=12]
setblock 520 270 490 minecraft:light[level=12]
setblock 520 270 498 minecraft:light[level=12]
fill 521 270 464 523 270 464 minecraft:gold_block
fill 522 270 504 524 270 504 minecraft:gold_block
fill 525 270 464 526 270 464 minecraft:gold_block
fill 526 270 504 527 270 504 minecraft:gold_block
fill 528 270 464 530 270 464 minecraft:gold_block
setblock 528 270 466 minecraft:light[level=12]
setblock 528 270 474 minecraft:light[level=12]
setblock 528 270 482 minecraft:light[level=12]
setblock 528 270 490 minecraft:light[level=12]
setblock 528 270 498 minecraft:light[level=12]
fill 529 270 504 531 270 504 minecraft:gold_block
fill 532 270 464 533 270 464 minecraft:gold_block
fill 533 270 504 534 270 504 minecraft:gold_block
fill 535 270 464 537 270 464 minecraft:gold_block
setblock 536 270 466 minecraft:light[level=12]
setblock 536 270 474 minecraft:light[level=12]
setblock 536 270 482 minecraft:light[level=12]
setblock 536 270 490 minecraft:light[level=12]
setblock 536 270 498 minecraft:light[level=12]
fill 536 270 504 538 270 504 minecraft:gold_block
fill 539 270 464 540 270 464 minecraft:gold_block
fill 540 270 504 541 270 504 minecraft:gold_block
fill 542 270 464 544 270 464 minecraft:gold_block
fill 543 270 504 545 270 504 minecraft:gold_block
setblock 544 270 466 minecraft:light[level=12]
setblock 544 270 474 minecraft:light[level=12]
setblock 544 270 482 minecraft:light[level=12]
setblock 544 270 490 minecraft:light[level=12]
setblock 544 270 498 minecraft:light[level=12]
fill 546 270 464 547 270 464 minecraft:gold_block
fill 547 270 504 548 270 504 minecraft:gold_block
fill 549 270 464 551 270 464 minecraft:gold_block
fill 550 270 504 552 270 504 minecraft:gold_block
setblock 552 270 466 minecraft:light[level=12]
setblock 552 270 474 minecraft:light[level=12]
setblock 552 270 482 minecraft:light[level=12]
setblock 552 270 490 minecraft:light[level=12]
setblock 552 270 498 minecraft:light[level=12]
fill 553 270 464 554 270 464 minecraft:gold_block
fill 554 270 504 555 270 504 minecraft:gold_block
fill 556 270 464 558 270 464 minecraft:gold_block
fill 557 270 504 558 270 504 minecraft:gold_block
fill 558 270 466 558 270 467 minecraft:gold_block
fill 558 270 469 558 270 471 minecraft:gold_block
fill 558 270 473 558 270 474 minecraft:gold_block
fill 558 270 476 558 270 478 minecraft:gold_block
fill 558 270 480 558 270 481 minecraft:gold_block
fill 558 270 483 558 270 485 minecraft:gold_block
fill 558 270 487 558 270 488 minecraft:gold_block
fill 558 270 490 558 270 492 minecraft:gold_block
fill 558 270 494 558 270 495 minecraft:gold_block
fill 558 270 497 558 270 499 minecraft:gold_block
fill 558 270 501 558 270 502 minecraft:gold_block
setblock 518 271 467 minecraft:gold_block
setblock 518 271 474 minecraft:gold_block
setblock 518 271 481 minecraft:gold_block
setblock 518 271 488 minecraft:gold_block
setblock 518 271 495 minecraft:gold_block
setblock 518 271 502 minecraft:gold_block
setblock 522 271 464 minecraft:gold_block
setblock 523 271 504 minecraft:gold_block
setblock 529 271 464 minecraft:gold_block
setblock 530 271 504 minecraft:gold_block
setblock 536 271 464 minecraft:gold_block
setblock 537 271 504 minecraft:gold_block
setblock 543 271 464 minecraft:gold_block
setblock 544 271 504 minecraft:gold_block
setblock 550 271 464 minecraft:gold_block
setblock 551 271 504 minecraft:gold_block
setblock 557 271 464 minecraft:gold_block
setblock 558 271 470 minecraft:gold_block
setblock 558 271 477 minecraft:gold_block
setblock 558 271 484 minecraft:gold_block
setblock 558 271 491 minecraft:gold_block
setblock 558 271 498 minecraft:gold_block
setblock 558 271 504 minecraft:gold_block
setblock 518 272 468 minecraft:gold_block
setblock 518 272 475 minecraft:gold_block
setblock 518 272 482 minecraft:gold_block
setblock 518 272 489 minecraft:gold_block
setblock 518 272 496 minecraft:gold_block
setblock 518 272 503 minecraft:gold_block
setblock 521 272 464 minecraft:gold_block
setblock 524 272 504 minecraft:gold_block
setblock 528 272 464 minecraft:gold_block
setblock 531 272 504 minecraft:gold_block
setblock 535 272 464 minecraft:gold_block
setblock 538 272 504 minecraft:gold_block
setblock 542 272 464 minecraft:gold_block
setblock 545 272 504 minecraft:gold_block
setblock 549 272 464 minecraft:gold_block
setblock 552 272 504 minecraft:gold_block
fill 553 272 476 553 273 476 minecraft:white_wool
setblock 556 272 464 minecraft:gold_block
setblock 558 272 469 minecraft:gold_block
setblock 558 272 476 minecraft:gold_block
setblock 558 272 483 minecraft:gold_block
setblock 558 272 490 minecraft:gold_block
setblock 558 272 497 minecraft:gold_block
setblock 520 278 466 minecraft:light[level=12]
setblock 520 278 474 minecraft:light[level=12]
setblock 520 278 482 minecraft:light[level=12]
setblock 520 278 490 minecraft:light[level=12]
setblock 520 278 498 minecraft:light[level=12]
setblock 528 278 466 minecraft:light[level=12]
setblock 528 278 474 minecraft:light[level=12]
setblock 528 278 482 minecraft:light[level=12]
setblock 528 278 490 minecraft:light[level=12]
setblock 528 278 498 minecraft:light[level=12]
setblock 536 278 466 minecraft:light[level=12]
setblock 536 278 474 minecraft:light[level=12]
setblock 536 278 482 minecraft:light[level=12]
setblock 536 278 490 minecraft:light[level=12]
setblock 536 278 498 minecraft:light[level=12]
setblock 544 278 466 minecraft:light[level=12]
setblock 544 278 474 minecraft:light[level=12]
setblock 544 278 482 minecraft:light[level=12]
setblock 544 278 490 minecraft:light[level=12]
setblock 544 278 498 minecraft:light[level=12]
setblock 552 278 466 minecraft:light[level=12]
setblock 552 278 474 minecraft:light[level=12]
setblock 552 278 482 minecraft:light[level=12]
setblock 552 278 490 minecraft:light[level=12]
setblock 552 278 498 minecraft:light[level=12]
fill 518 279 464 522 280 504 minecraft:red_wool
fill 523 279 464 523 280 504 minecraft:gold_block
fill 524 279 464 528 280 504 minecraft:red_wool
fill 529 279 464 529 280 504 minecraft:gold_block
fill 530 279 464 534 280 504 minecraft:red_wool
fill 535 279 464 535 280 504 minecraft:gold_block
fill 536 279 464 537 279 504 minecraft:red_wool
fill 538 279 464 538 279 484 minecraft:red_wool
fill 538 279 486 538 279 504 minecraft:red_wool
fill 539 279 464 539 279 483 minecraft:red_wool
fill 539 279 487 539 279 504 minecraft:red_wool
fill 540 279 464 540 279 482 minecraft:red_wool
fill 540 279 488 540 279 504 minecraft:red_wool
fill 541 279 464 541 279 483 minecraft:gold_block
fill 541 279 487 541 279 504 minecraft:gold_block
fill 542 279 464 546 279 484 minecraft:red_wool
fill 542 279 486 546 279 504 minecraft:red_wool
fill 543 279 485 546 279 485 minecraft:red_wool
fill 547 279 464 547 280 504 minecraft:gold_block
fill 548 279 464 552 280 504 minecraft:red_wool
fill 553 279 464 553 280 504 minecraft:gold_block
fill 554 279 464 558 280 504 minecraft:red_wool
fill 536 280 464 536 280 504 minecraft:red_wool
fill 537 280 464 537 280 483 minecraft:red_wool
fill 537 280 484 537 280 486 minecraft:ochre_froglight
fill 537 280 487 537 280 504 minecraft:red_wool
fill 538 280 464 538 280 482 minecraft:red_wool
fill 538 280 483 538 280 484 minecraft:ochre_froglight
fill 538 280 486 538 280 487 minecraft:ochre_froglight
fill 538 280 488 538 280 504 minecraft:red_wool
fill 539 280 464 540 280 481 minecraft:red_wool
fill 539 280 482 539 280 483 minecraft:ochre_froglight
fill 539 280 487 539 280 488 minecraft:ochre_froglight
fill 539 280 489 540 280 504 minecraft:red_wool
fill 540 280 482 541 280 482 minecraft:ochre_froglight
fill 540 280 488 541 280 488 minecraft:ochre_froglight
fill 541 280 464 541 280 481 minecraft:gold_block
fill 541 280 483 542 280 483 minecraft:ochre_froglight
fill 541 280 487 542 280 487 minecraft:ochre_froglight
fill 541 280 489 541 280 504 minecraft:gold_block
fill 542 280 464 546 280 482 minecraft:red_wool
fill 542 280 484 543 280 484 minecraft:ochre_froglight
fill 542 280 486 543 280 486 minecraft:ochre_froglight
fill 542 280 488 546 280 504 minecraft:red_wool
fill 543 280 483 546 280 483 minecraft:red_wool
setblock 543 280 485 minecraft:ochre_froglight
fill 543 280 487 546 280 487 minecraft:red_wool
fill 544 280 484 546 280 486 minecraft:red_wool
setblock 518 284 466 minecraft:gold_block
fill 518 284 469 518 300 469 minecraft:gold_block
setblock 518 284 473 minecraft:gold_block
fill 518 284 476 518 300 476 minecraft:gold_block
setblock 518 284 480 minecraft:gold_block
fill 518 284 483 518 300 483 minecraft:gold_block
setblock 518 284 487 minecraft:gold_block
fill 518 284 490 518 300 490 minecraft:gold_block
setblock 518 284 494 minecraft:gold_block
fill 518 284 497 518 300 497 minecraft:gold_block
setblock 518 284 501 minecraft:gold_block
fill 518 284 504 518 300 504 minecraft:gold_block
fill 520 284 464 520 300 464 minecraft:gold_block
setblock 522 284 504 minecraft:gold_block
setblock 523 284 464 minecraft:gold_block
fill 525 284 498 525 286 498 minecraft:white_wool
fill 525 284 504 525 300 504 minecraft:gold_block
fill 527 284 464 527 300 464 minecraft:gold_block
setblock 529 284 504 minecraft:gold_block
setblock 530 284 464 minecraft:gold_block
fill 532 284 504 532 300 504 minecraft:gold_block
fill 534 284 464 534 300 464 minecraft:gold_block
setblock 536 284 504 minecraft:gold_block
setblock 537 284 464 minecraft:gold_block
fill 539 284 504 539 300 504 minecraft:gold_block
fill 541 284 464 541 300 464 minecraft:gold_block
setblock 543 284 504 minecraft:gold_block
setblock 544 284 464 minecraft:gold_block
fill 546 284 504 546 300 504 minecraft:gold_block
fill 548 284 464 548 300 464 minecraft:gold_block
setblock 550 284 504 minecraft:gold_block
setblock 551 284 464 minecraft:gold_block
fill 553 284 476 553 292 476 minecraft:white_wool
fill 553 284 504 553 300 504 minecraft:gold_block
fill 555 284 464 555 300 464 minecraft:gold_block
setblock 557 284 504 minecraft:gold_block
setblock 558 284 464 minecraft:gold_block
fill 558 284 468 558 300 468 minecraft:gold_block
setblock 558 284 471 minecraft:gold_block
fill 558 284 475 558 300 475 minecraft:gold_block
setblock 558 284 478 minecraft:gold_block
fill 558 284 482 558 300 482 minecraft:gold_block
setblock 558 284 485 minecraft:gold_block
fill 558 284 489 558 300 489 minecraft:gold_block
setblock 558 284 492 minecraft:gold_block
fill 558 284 496 558 300 496 minecraft:gold_block
setblock 558 284 499 minecraft:gold_block
fill 558 284 503 558 300 503 minecraft:gold_block
setblock 518 285 467 minecraft:gold_block
setblock 518 285 474 minecraft:gold_block
setblock 518 285 481 minecraft:gold_block
setblock 518 285 488 minecraft:gold_block
setblock 518 285 495 minecraft:gold_block
setblock 518 285 502 minecraft:gold_block
setblock 522 285 464 minecraft:gold_block
setblock 523 285 504 minecraft:gold_block
setblock 529 285 464 minecraft:gold_block
setblock 530 285 504 minecraft:gold_block
setblock 536 285 464 minecraft:gold_block
setblock 537 285 504 minecraft:gold_block
setblock 543 285 464 minecraft:gold_block
setblock 544 285 504 minecraft:gold_block
setblock 550 285 464 minecraft:gold_block
setblock 551 285 504 minecraft:gold_block
setblock 557 285 464 minecraft:gold_block
setblock 558 285 470 minecraft:gold_block
setblock 558 285 477 minecraft:gold_block
setblock 558 285 484 minecraft:gold_block
setblock 558 285 491 minecraft:gold_block
setblock 558 285 498 minecraft:gold_block
setblock 558 285 504 minecraft:gold_block
setblock 518 286 468 minecraft:gold_block
setblock 518 286 475 minecraft:gold_block
setblock 518 286 482 minecraft:gold_block
fill 518 286 487 520 287 487 minecraft:white_wool
setblock 518 286 489 minecraft:gold_block
setblock 518 286 496 minecraft:gold_block
setblock 518 286 503 minecraft:gold_block
setblock 520 286 466 minecraft:light[level=12]
setblock 520 286 474 minecraft:light[level=12]
setblock 520 286 482 minecraft:light[level=12]
setblock 520 286 490 minecraft:light[level=12]
setblock 520 286 498 minecraft:light[level=12]
setblock 521 286 464 minecraft:gold_block
setblock 524 286 504 minecraft:gold_block
setblock 528 286 464 minecraft:gold_block
setblock 528 286 466 minecraft:light[level=12]
setblock 528 286 474 minecraft:light[level=12]
setblock 528 286 482 minecraft:light[level=12]
setblock 528 286 490 minecraft:light[level=12]
setblock 528 286 498 minecraft:light[level=12]
setblock 531 286 504 minecraft:gold_block
setblock 535 286 464 minecraft:gold_block
setblock 536 286 466 minecraft:light[level=12]
setblock 536 286 474 minecraft:light[level=12]
setblock 536 286 482 minecraft:light[level=12]
setblock 536 286 490 minecraft:light[level=12]
setblock 536 286 498 minecraft:light[level=12]
setblock 538 286 504 minecraft:gold_block
setblock 542 286 464 minecraft:gold_block
setblock 544 286 466 minecraft:light[level=12]
setblock 544 286 474 minecraft:light[level=12]
setblock 544 286 482 minecraft:light[level=12]
setblock 544 286 490 minecraft:light[level=12]
setblock 544 286 498 minecraft:light[level=12]
setblock 545 286 504 minecraft:gold_block
setblock 549 286 464 minecraft:gold_block
setblock 552 286 466 minecraft:light[level=12]
setblock 552 286 474 minecraft:light[level=12]
setblock 552 286 482 minecraft:light[level=12]
setblock 552 286 490 minecraft:light[level=12]
setblock 552 286 498 minecraft:light[level=12]
setblock 552 286 504 minecraft:gold_block
setblock 556 286 464 minecraft:gold_block
setblock 558 286 469 minecraft:gold_block
setblock 558 286 476 minecraft:gold_block
setblock 558 286 483 minecraft:gold_block
setblock 558 286 490 minecraft:gold_block
setblock 558 286 497 minecraft:gold_block
setblock 518 288 470 minecraft:gold_block
setblock 518 288 477 minecraft:gold_block
setblock 518 288 484 minecraft:gold_block
setblock 518 288 491 minecraft:gold_block
setblock 518 288 498 minecraft:gold_block
setblock 519 288 464 minecraft:gold_block
setblock 519 288 504 minecraft:gold_block
setblock 526 288 464 minecraft:gold_block
setblock 526 288 504 minecraft:gold_block
setblock 533 288 464 minecraft:gold_block
setblock 533 288 504 minecraft:gold_block
setblock 540 288 464 minecraft:gold_block
setblock 540 288 504 minecraft:gold_block
setblock 547 288 464 minecraft:gold_block
setblock 547 288 504 minecraft:gold_block
setblock 554 288 464 minecraft:gold_block
setblock 554 288 504 minecraft:gold_block
setblock 558 288 467 minecraft:gold_block
setblock 558 288 474 minecraft:gold_block
setblock 558 288 481 minecraft:gold_block
setblock 558 288 488 minecraft:gold_block
setblock 558 288 495 minecraft:gold_block
setblock 558 288 502 minecraft:gold_block
fill 518 289 464 518 290 464 minecraft:gold_block
fill 518 289 471 518 290 471 minecraft:gold_block
fill 518 289 478 518 290 478 minecraft:gold_block
fill 518 289 485 518 290 485 minecraft:gold_block
fill 518 289 492 518 290 492 minecraft:gold_block
fill 518 289 499 518 290 499 minecraft:gold_block
fill 520 289 504 520 290 504 minecraft:gold_block
fill 525 289 464 525 290 464 minecraft:gold_block
fill 527 289 504 527 290 504 minecraft:gold_block
fill 532 289 464 532 290 464 minecraft:gold_block
fill 534 289 504 534 290 504 minecraft:gold_block
fill 539 289 464 539 290 464 minecraft:gold_block
fill 541 289 504 541 290 504 minecraft:gold_block
fill 546 289 464 546 290 464 minecraft:gold_block
fill 548 289 504 548 290 504 minecraft:gold_block
fill 553 289 464 553 290 464 minecraft:gold_block
fill 555 289 504 555 290 504 minecraft:gold_block
fill 558 289 466 558 290 466 minecraft:gold_block
fill 558 289 473 558 290 473 minecraft:gold_block
fill 558 289 480 558 290 480 minecraft:gold_block
fill 558 289 487 558 290 487 minecraft:gold_block
fill 558 289 494 558 290 494 minecraft:gold_block
fill 558 289 501 558 290 501 minecraft:gold_block
fill 518 290 465 518 290 468 minecraft:gold_block
setblock 518 290 470 minecraft:gold_block
fill 518 290 472 518 290 475 minecraft:gold_block
setblock 518 290 477 minecraft:gold_block
fill 518 290 479 518 290 482 minecraft:gold_block
setblock 518 290 484 minecraft:gold_block
fill 518 290 486 518 290 489 minecraft:gold_block
setblock 518 290 491 minecraft:gold_block
fill 518 290 493 518 290 496 minecraft:gold_block
setblock 518 290 498 minecraft:gold_block
fill 518 290 500 518 290 503 minecraft:gold_block
setblock 519 290 464 minecraft:gold_block
setblock 519 290 504 minecraft:gold_block
fill 521 290 464 524 290 464 minecraft:gold_block
fill 521 290 504 524 290 504 minecraft:gold_block
setblock 526 290 464 minecraft:gold_block
setblock 526 290 504 minecraft:gold_block
fill 528 290 464 531 290 464 minecraft:gold_block
fill 528 290 504 531 290 504 minecraft:gold_block
setblock 533 290 464 minecraft:gold_block
setblock 533 290 504 minecraft:gold_block
fill 535 290 464 538 290 464 minecraft:gold_block
fill 535 290 504 538 290 504 minecraft:gold_block
setblock 540 290 464 minecraft:gold_block
setblock 540 290 504 minecraft:gold_block
fill 542 290 464 545 290 464 minecraft:gold_block
fill 542 290 504 545 290 504 minecraft:gold_block
setblock 547 290 464 minecraft:gold_block
setblock 547 290 504 minecraft:gold_block
fill 549 290 464 552 290 464 minecraft:gold_block
fill 549 290 504 552 290 504 minecraft:gold_block
setblock 554 290 464 minecraft:gold_block
setblock 554 290 504 minecraft:gold_block
fill 556 290 464 558 290 464 minecraft:gold_block
fill 556 290 504 558 290 504 minecraft:gold_block
setblock 558 290 465 minecraft:gold_block
setblock 558 290 467 minecraft:gold_block
fill 558 290 469 558 290 472 minecraft:gold_block
setblock 558 290 474 minecraft:gold_block
fill 558 290 476 558 290 479 minecraft:gold_block
setblock 558 290 481 minecraft:gold_block
fill 558 290 483 558 290 486 minecraft:gold_block
setblock 558 290 488 minecraft:gold_block
fill 558 290 490 558 290 493 minecraft:gold_block
setblock 558 290 495 minecraft:gold_block
fill 558 290 497 558 290 500 minecraft:gold_block
setblock 558 290 502 minecraft:gold_block
setblock 518 291 466 minecraft:gold_block
setblock 518 291 473 minecraft:gold_block
setblock 518 291 480 minecraft:gold_block
setblock 518 291 487 minecraft:gold_block
setblock 518 291 494 minecraft:gold_block
setblock 518 291 501 minecraft:gold_block
setblock 522 291 504 minecraft:gold_block
setblock 523 291 464 minecraft:gold_block
setblock 529 291 504 minecraft:gold_block
setblock 530 291 464 minecraft:gold_block
setblock 536 291 504 minecraft:gold_block
setblock 537 291 464 minecraft:gold_block
setblock 543 291 504 minecraft:gold_block
setblock 544 291 464 minecraft:gold_block
setblock 550 291 504 minecraft:gold_block
setblock 551 291 464 minecraft:gold_block
setblock 557 291 504 minecraft:gold_block
setblock 558 291 464 minecraft:gold_block
setblock 558 291 471 minecraft:gold_block
setblock 558 291 478 minecraft:gold_block
setblock 558 291 485 minecraft:gold_block
setblock 558 291 492 minecraft:gold_block
setblock 558 291 499 minecraft:gold_block
setblock 518 292 467 minecraft:gold_block
setblock 518 292 474 minecraft:gold_block
setblock 518 292 481 minecraft:gold_block
setblock 518 292 488 minecraft:gold_block
setblock 518 292 495 minecraft:gold_block
setblock 518 292 502 minecraft:gold_block
setblock 522 292 464 minecraft:gold_block
setblock 523 292 504 minecraft:gold_block
setblock 529 292 464 minecraft:gold_block
setblock 530 292 504 minecraft:gold_block
setblock 536 292 464 minecraft:gold_block
setblock 537 292 504 minecraft:gold_block
setblock 543 292 464 minecraft:gold_block
setblock 544 292 504 minecraft:gold_block
setblock 550 292 464 minecraft:gold_block
setblock 551 292 504 minecraft:gold_block
setblock 557 292 464 minecraft:gold_block
setblock 558 292 470 minecraft:gold_block
setblock 558 292 477 minecraft:gold_block
setblock 558 292 484 minecraft:gold_block
setblock 558 292 491 minecraft:gold_block
setblock 558 292 498 minecraft:gold_block
setblock 558 292 504 minecraft:gold_block
setblock 518 293 468 minecraft:gold_block
setblock 518 293 475 minecraft:gold_block
setblock 518 293 482 minecraft:gold_block
setblock 518 293 489 minecraft:gold_block
setblock 518 293 496 minecraft:gold_block
setblock 518 293 503 minecraft:gold_block
setblock 521 293 464 minecraft:gold_block
setblock 524 293 504 minecraft:gold_block
setblock 528 293 464 minecraft:gold_block
setblock 531 293 504 minecraft:gold_block
setblock 535 293 464 minecraft:gold_block
setblock 538 293 504 minecraft:gold_block
setblock 542 293 464 minecraft:gold_block
setblock 545 293 504 minecraft:gold_block
setblock 549 293 464 minecraft:gold_block
setblock 552 293 504 minecraft:gold_block
setblock 556 293 464 minecraft:gold_block
setblock 558 293 469 minecraft:gold_block
setblock 558 293 476 minecraft:gold_block
setblock 558 293 483 minecraft:gold_block
setblock 558 293 490 minecraft:gold_block
setblock 558 293 497 minecraft:gold_block
setblock 520 294 466 minecraft:light[level=12]
setblock 520 294 474 minecraft:light[level=12]
setblock 520 294 482 minecraft:light[level=12]
setblock 520 294 490 minecraft:light[level=12]
setblock 520 294 498 minecraft:light[level=12]
setblock 528 294 466 minecraft:light[level=12]
setblock 528 294 474 minecraft:light[level=12]
setblock 528 294 482 minecraft:light[level=12]
setblock 528 294 490 minecraft:light[level=12]
setblock 528 294 498 minecraft:light[level=12]
setblock 536 294 466 minecraft:light[level=12]
setblock 536 294 474 minecraft:light[level=12]
setblock 536 294 482 minecraft:light[level=12]
setblock 536 294 490 minecraft:light[level=12]
setblock 536 294 498 minecraft:light[level=12]
setblock 544 294 466 minecraft:light[level=12]
setblock 544 294 474 minecraft:light[level=12]
setblock 544 294 482 minecraft:light[level=12]
setblock 544 294 490 minecraft:light[level=12]
setblock 544 294 498 minecraft:light[level=12]
setblock 552 294 466 minecraft:light[level=12]
setblock 552 294 474 minecraft:light[level=12]
setblock 552 294 482 minecraft:light[level=12]
setblock 552 294 490 minecraft:light[level=12]
setblock 552 294 498 minecraft:light[level=12]
setblock 518 295 470 minecraft:gold_block
setblock 518 295 477 minecraft:gold_block
setblock 518 295 484 minecraft:gold_block
setblock 518 295 491 minecraft:gold_block
setblock 518 295 498 minecraft:gold_block
setblock 519 295 464 minecraft:gold_block
setblock 519 295 504 minecraft:gold_block
setblock 526 295 464 minecraft:gold_block
setblock 526 295 504 minecraft:gold_block
setblock 533 295 464 minecraft:gold_block
setblock 533 295 504 minecraft:gold_block
setblock 540 295 464 minecraft:gold_block
setblock 540 295 504 minecraft:gold_block
setblock 547 295 464 minecraft:gold_block
setblock 547 295 504 minecraft:gold_block
setblock 554 295 464 minecraft:gold_block
setblock 554 295 504 minecraft:gold_block
setblock 558 295 467 minecraft:gold_block
setblock 558 295 474 minecraft:gold_block
setblock 558 295 481 minecraft:gold_block
setblock 558 295 488 minecraft:gold_block
setblock 558 295 495 minecraft:gold_block
setblock 558 295 502 minecraft:gold_block
setblock 518 296 464 minecraft:gold_block
setblock 518 296 471 minecraft:gold_block
setblock 518 296 478 minecraft:gold_block
setblock 518 296 485 minecraft:gold_block
setblock 518 296 492 minecraft:gold_block
setblock 518 296 499 minecraft:gold_block
setblock 520 296 504 minecraft:gold_block
setblock 525 296 464 minecraft:gold_block
setblock 527 296 504 minecraft:gold_block
setblock 532 296 464 minecraft:gold_block
setblock 534 296 504 minecraft:gold_block
setblock 539 296 464 minecraft:gold_block
setblock 541 296 504 minecraft:gold_block
setblock 546 296 464 minecraft:gold_block
setblock 548 296 504 minecraft:gold_block
setblock 553 296 464 minecraft:gold_block
setblock 555 296 504 minecraft:gold_block
setblock 558 296 466 minecraft:gold_block
setblock 558 296 473 minecraft:gold_block
setblock 558 296 480 minecraft:gold_block
setblock 558 296 487 minecraft:gold_block
setblock 558 296 494 minecraft:gold_block
setblock 558 296 501 minecraft:gold_block
setblock 518 297 465 minecraft:gold_block
setblock 518 297 472 minecraft:gold_block
setblock 518 297 479 minecraft:gold_block
setblock 518 297 486 minecraft:gold_block
setblock 518 297 493 minecraft:gold_block
setblock 518 297 500 minecraft:gold_block
setblock 521 297 504 minecraft:gold_block
setblock 524 297 464 minecraft:gold_block
setblock 528 297 504 minecraft:gold_block
setblock 531 297 464 minecraft:gold_block
setblock 535 297 504 minecraft:gold_block
setblock 538 297 464 minecraft:gold_block
setblock 542 297 504 minecraft:gold_block
setblock 545 297 464 minecraft:gold_block
setblock 549 297 504 minecraft:gold_block
setblock 552 297 464 minecraft:gold_block
fill 554 297 501 554 298 503 minecraft:white_wool
setblock 556 297 504 minecraft:gold_block
setblock 558 297 465 minecraft:gold_block
setblock 558 297 472 minecraft:gold_block
setblock 558 297 479 minecraft:gold_block
setblock 558 297 486 minecraft:gold_block
setblock 558 297 493 minecraft:gold_block
setblock 558 297 500 minecraft:gold_block
setblock 518 298 466 minecraft:gold_block
setblock 518 298 473 minecraft:gold_block
setblock 518 298 480 minecraft:gold_block
setblock 518 298 487 minecraft:gold_block
setblock 518 298 494 minecraft:gold_block
setblock 518 298 501 minecraft:gold_block
setblock 522 298 504 minecraft:gold_block
setblock 523 298 464 minecraft:gold_block
setblock 529 298 504 minecraft:gold_block
setblock 530 298 464 minecraft:gold_block
setblock 536 298 504 minecraft:gold_block
setblock 537 298 464 minecraft:gold_block
setblock 543 298 504 minecraft:gold_block
setblock 544 298 464 minecraft:gold_block
setblock 550 298 504 minecraft:gold_block
setblock 551 298 464 minecraft:gold_block
setblock 557 298 504 minecraft:gold_block
setblock 558 298 464 minecraft:gold_block
setblock 558 298 471 minecraft:gold_block
setblock 558 298 478 minecraft:gold_block
setblock 558 298 485 minecraft:gold_block
setblock 558 298 492 minecraft:gold_block
setblock 558 298 499 minecraft:gold_block
fill 518 299 467 518 300 467 minecraft:gold_block
fill 518 299 474 518 300 474 minecraft:gold_block
fill 518 299 481 518 300 481 minecraft:gold_block
fill 518 299 488 518 300 488 minecraft:gold_block
fill 518 299 495 518 300 495 minecraft:gold_block
fill 518 299 502 518 300 502 minecraft:gold_block
fill 522 299 464 522 300 464 minecraft:gold_block
fill 523 299 504 523 300 504 minecraft:gold_block
fill 529 299 464 529 300 464 minecraft:gold_block
fill 530 299 504 530 300 504 minecraft:gold_block
fill 536 299 464 536 300 464 minecraft:gold_block
fill 537 299 504 537 300 504 minecraft:gold_block
fill 543 299 464 543 300 464 minecraft:gold_block
fill 544 299 504 544 300 504 minecraft:gold_block
fill 550 299 464 550 300 464 minecraft:gold_block
fill 551 299 504 551 300 504 minecraft:gold_block
fill 557 299 464 557 300 464 minecraft:gold_block
fill 558 299 470 558 300 470 minecraft:gold_block
fill 558 299 477 558 300 477 minecraft:gold_block
fill 558 299 484 558 300 484 minecraft:gold_block
fill 558 299 491 558 300 491 minecraft:gold_block
fill 558 299 498 558 300 498 minecraft:gold_block
fill 558 299 504 558 300 504 minecraft:gold_block
fill 518 300 464 518 300 466 minecraft:gold_block
setblock 518 300 468 minecraft:gold_block
fill 518 300 470 518 300 473 minecraft:gold_block
setblock 518 300 475 minecraft:gold_block
fill 518 300 477 518 300 480 minecraft:gold_block
setblock 518 300 482 minecraft:gold_block
fill 518 300 484 518 300 487 minecraft:gold_block
setblock 518 300 489 minecraft:gold_block
fill 518 300 491 518 300 494 minecraft:gold_block
setblock 518 300 496 minecraft:gold_block
fill 518 300 498 518 300 501 minecraft:gold_block
setblock 518 300 503 minecraft:gold_block
setblock 519 300 464 minecraft:gold_block
fill 519 300 504 522 300 504 minecraft:gold_block
setblock 521 300 464 minecraft:gold_block
fill 523 300 464 526 300 464 minecraft:gold_block
setblock 524 300 504 minecraft:gold_block
fill 526 300 504 529 300 504 minecraft:gold_block
setblock 528 300 464 minecraft:gold_block
fill 530 300 464 533 300 464 minecraft:gold_block
setblock 531 300 504 minecraft:gold_block
fill 533 300 504 536 300 504 minecraft:gold_block
setblock 535 300 464 minecraft:gold_block
fill 537 300 464 540 300 464 minecraft:gold_block
setblock 538 300 504 minecraft:gold_block
fill 540 300 504 543 300 504 minecraft:gold_block
setblock 542 300 464 minecraft:gold_block
fill 544 300 464 547 300 464 minecraft:gold_block
setblock 545 300 504 minecraft:gold_block
fill 547 300 504 550 300 504 minecraft:gold_block
setblock 549 300 464 minecraft:gold_block
fill 551 300 464 554 300 464 minecraft:gold_block
setblock 552 300 504 minecraft:gold_block
fill 554 300 504 557 300 504 minecraft:gold_block
setblock 556 300 464 minecraft:gold_block
fill 558 300 464 558 300 467 minecraft:gold_block
setblock 558 300 469 minecraft:gold_block
fill 558 300 471 558 300 474 minecraft:gold_block
setblock 558 300 476 minecraft:gold_block
fill 558 300 478 558 300 481 minecraft:gold_block
setblock 558 300 483 minecraft:gold_block
fill 558 300 485 558 300 488 minecraft:gold_block
setblock 558 300 490 minecraft:gold_block
fill 558 300 492 558 300 495 minecraft:gold_block
setblock 558 300 497 minecraft:gold_block
fill 558 300 499 558 300 502 minecraft:gold_block
setblock 520 302 466 minecraft:light[level=12]
setblock 520 302 474 minecraft:light[level=12]
setblock 520 302 482 minecraft:light[level=12]
setblock 520 302 490 minecraft:light[level=12]
setblock 520 302 498 minecraft:light[level=12]
setblock 528 302 466 minecraft:light[level=12]
setblock 528 302 474 minecraft:light[level=12]
setblock 528 302 482 minecraft:light[level=12]
setblock 528 302 490 minecraft:light[level=12]
setblock 528 302 498 minecraft:light[level=12]
setblock 536 302 466 minecraft:light[level=12]
setblock 536 302 474 minecraft:light[level=12]
setblock 536 302 482 minecraft:light[level=12]
setblock 536 302 490 minecraft:light[level=12]
setblock 536 302 498 minecraft:light[level=12]
setblock 544 302 466 minecraft:light[level=12]
setblock 544 302 474 minecraft:light[level=12]
setblock 544 302 482 minecraft:light[level=12]
setblock 544 302 490 minecraft:light[level=12]
setblock 544 302 498 minecraft:light[level=12]
setblock 552 302 466 minecraft:light[level=12]
setblock 552 302 474 minecraft:light[level=12]
setblock 552 302 482 minecraft:light[level=12]
setblock 552 302 490 minecraft:light[level=12]
setblock 552 302 498 minecraft:light[level=12]
