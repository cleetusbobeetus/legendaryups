fill 235 265 562 235 268 562 minecraft:red_concrete
fill 235 265 573 235 268 573 minecraft:red_concrete
fill 235 265 577 235 267 577 minecraft:red_concrete
setblock 235 265 578 minecraft:yellow_concrete
setblock 235 265 589 minecraft:yellow_concrete
setblock 235 265 593 minecraft:yellow_concrete
fill 235 265 594 235 268 594 minecraft:red_concrete
fill 238 265 557 239 265 557 minecraft:yellow_concrete
setblock 246 265 599 minecraft:yellow_concrete
setblock 249 265 599 minecraft:yellow_concrete
fill 250 265 599 250 268 599 minecraft:red_concrete
fill 255 265 557 255 268 557 minecraft:red_concrete
setblock 257 265 599 minecraft:yellow_concrete
setblock 259 265 557 minecraft:yellow_concrete
fill 261 265 599 261 268 599 minecraft:red_concrete
fill 266 265 557 266 268 557 minecraft:red_concrete
setblock 267 265 557 minecraft:yellow_concrete
setblock 270 265 557 minecraft:yellow_concrete
fill 277 265 566 277 268 567 minecraft:red_concrete
setblock 277 265 571 minecraft:yellow_concrete
setblock 277 265 582 minecraft:yellow_concrete
fill 277 265 587 277 268 587 minecraft:red_concrete
fill 277 265 598 277 268 598 minecraft:red_concrete
setblock 277 265 599 minecraft:yellow_concrete
fill 235 266 558 235 271 558 minecraft:red_concrete
fill 235 266 559 235 266 560 minecraft:yellow_concrete
fill 235 266 561 235 271 561 minecraft:red_concrete
fill 235 266 567 235 267 568 minecraft:yellow_concrete
fill 235 266 569 235 271 570 minecraft:red_concrete
fill 235 266 578 235 267 578 minecraft:red_concrete
fill 235 266 579 235 266 580 minecraft:yellow_concrete
fill 235 266 581 235 271 582 minecraft:red_concrete
fill 235 266 587 235 267 588 minecraft:yellow_concrete
fill 235 266 589 235 271 590 minecraft:red_concrete
setblock 235 266 591 minecraft:yellow_concrete
fill 235 266 593 235 268 593 minecraft:red_concrete
fill 235 266 599 236 267 599 minecraft:yellow_concrete
setblock 237 266 557 minecraft:yellow_concrete
fill 237 266 599 238 271 599 minecraft:red_concrete
fill 238 266 557 239 271 557 minecraft:red_concrete
fill 240 266 557 240 267 557 minecraft:yellow_concrete
fill 241 266 576 242 267 577 minecraft:red_concrete
fill 244 266 599 244 267 599 minecraft:yellow_concrete
fill 246 266 557 247 271 557 minecraft:red_concrete
fill 246 266 599 246 271 599 minecraft:red_concrete
fill 247 266 599 248 266 599 minecraft:yellow_concrete
fill 248 266 557 249 266 557 minecraft:yellow_concrete
fill 249 266 599 249 271 599 minecraft:red_concrete
fill 255 266 599 256 267 599 minecraft:yellow_concrete
fill 257 266 599 258 271 599 minecraft:red_concrete
fill 258 266 557 259 271 557 minecraft:red_concrete
fill 260 266 557 261 267 557 minecraft:yellow_concrete
fill 267 266 557 267 271 557 minecraft:red_concrete
fill 267 266 599 268 266 599 minecraft:yellow_concrete
fill 268 266 557 269 266 557 minecraft:yellow_concrete
fill 269 266 599 270 271 599 minecraft:red_concrete
fill 270 266 557 270 271 557 minecraft:red_concrete
fill 272 266 557 272 267 557 minecraft:yellow_concrete
fill 276 266 599 276 267 599 minecraft:yellow_concrete
fill 277 266 558 277 271 559 minecraft:red_concrete
fill 277 266 560 277 267 561 minecraft:yellow_concrete
setblock 277 266 569 minecraft:yellow_concrete
fill 277 266 570 277 271 571 minecraft:red_concrete
fill 277 266 572 277 267 573 minecraft:yellow_concrete
fill 277 266 578 277 271 579 minecraft:red_concrete
fill 277 266 580 277 266 581 minecraft:yellow_concrete
fill 277 266 582 277 271 582 minecraft:red_concrete
fill 277 266 590 277 271 591 minecraft:red_concrete
fill 277 266 592 277 267 593 minecraft:yellow_concrete
fill 277 266 599 277 271 599 minecraft:red_concrete
fill 235 267 559 235 269 560 minecraft:red_concrete
fill 235 267 575 235 267 576 minecraft:yellow_concrete
setblock 235 267 579 minecraft:yellow_concrete
fill 235 267 580 235 270 580 minecraft:red_concrete
fill 235 267 591 235 270 591 minecraft:red_concrete
fill 235 267 595 235 269 595 minecraft:red_concrete
setblock 235 267 596 minecraft:yellow_concrete
fill 237 267 557 237 270 557 minecraft:red_concrete
setblock 241 267 557 minecraft:yellow_concrete
setblock 243 267 599 minecraft:yellow_concrete
fill 247 267 599 248 270 599 minecraft:red_concrete
fill 248 267 557 248 270 557 minecraft:red_concrete
setblock 249 267 557 minecraft:yellow_concrete
setblock 252 267 557 minecraft:yellow_concrete
setblock 264 267 599 minecraft:yellow_concrete
setblock 267 267 599 minecraft:yellow_concrete
fill 268 267 557 269 270 557 minecraft:red_concrete
fill 268 267 599 268 270 599 minecraft:red_concrete
setblock 273 267 557 minecraft:yellow_concrete
setblock 275 267 599 minecraft:yellow_concrete
setblock 277 267 564 minecraft:yellow_concrete
fill 277 267 569 277 270 569 minecraft:red_concrete
fill 277 267 580 277 270 580 minecraft:red_concrete
setblock 277 267 581 minecraft:yellow_concrete
fill 277 267 584 277 267 585 minecraft:yellow_concrete
setblock 235 268 557 minecraft:yellow_concrete
fill 235 268 565 235 269 566 minecraft:yellow_concrete
fill 235 268 567 235 285 568 minecraft:red_concrete
fill 235 268 574 235 269 574 minecraft:yellow_concrete
fill 235 268 575 235 269 576 minecraft:red_concrete
fill 235 268 577 235 268 578 minecraft:yellow_concrete
fill 235 268 579 235 285 579 minecraft:red_concrete
fill 235 268 585 235 269 586 minecraft:yellow_concrete
fill 235 268 587 235 286 588 minecraft:red_concrete
fill 235 268 596 235 289 596 minecraft:red_concrete
fill 235 268 597 235 268 598 minecraft:yellow_concrete
fill 235 268 599 236 285 599 minecraft:red_concrete
fill 236 268 561 236 269 561 minecraft:magma_block
fill 240 268 557 241 286 557 minecraft:red_concrete
fill 241 268 599 242 269 599 minecraft:yellow_concrete
fill 242 268 557 243 269 557 minecraft:yellow_concrete
fill 243 268 599 244 286 599 minecraft:red_concrete
setblock 245 268 599 minecraft:yellow_concrete
fill 249 268 557 249 285 557 minecraft:red_concrete
fill 250 268 557 251 268 557 minecraft:yellow_concrete
fill 252 268 557 252 289 557 minecraft:red_concrete
fill 253 268 599 254 269 599 minecraft:yellow_concrete
fill 254 268 557 254 269 557 minecraft:yellow_concrete
fill 255 268 599 256 285 599 minecraft:red_concrete
fill 260 268 557 261 285 557 minecraft:red_concrete
fill 262 268 557 263 269 557 minecraft:yellow_concrete
fill 262 268 599 262 269 599 minecraft:yellow_concrete
fill 264 268 599 264 289 599 minecraft:red_concrete
fill 265 268 599 266 268 599 minecraft:yellow_concrete
fill 267 268 599 267 285 599 minecraft:red_concrete
setblock 271 268 557 minecraft:yellow_concrete
fill 272 268 557 273 286 557 minecraft:red_concrete
fill 273 268 599 274 269 599 minecraft:yellow_concrete
fill 274 268 557 275 269 557 minecraft:yellow_concrete
fill 275 268 599 276 286 599 minecraft:red_concrete
fill 277 268 560 277 285 561 minecraft:red_concrete
fill 277 268 562 277 268 563 minecraft:yellow_concrete
fill 277 268 564 277 289 564 minecraft:red_concrete
fill 277 268 572 277 286 573 minecraft:red_concrete
fill 277 268 574 277 269 575 minecraft:yellow_concrete
fill 277 268 581 277 285 581 minecraft:red_concrete
setblock 277 268 583 minecraft:yellow_concrete
fill 277 268 584 277 289 585 minecraft:red_concrete
fill 277 268 586 277 269 586 minecraft:yellow_concrete
fill 277 268 592 277 285 593 minecraft:red_concrete
fill 277 268 594 277 268 595 minecraft:yellow_concrete
fill 235 269 557 235 271 557 minecraft:red_concrete
setblock 235 269 562 minecraft:yellow_concrete
setblock 235 269 573 minecraft:yellow_concrete
fill 235 269 577 235 271 578 minecraft:red_concrete
fill 235 269 593 235 269 594 minecraft:yellow_concrete
setblock 235 269 597 minecraft:yellow_concrete
fill 235 269 598 235 272 598 minecraft:red_concrete
fill 236 269 559 236 269 560 minecraft:magma_block
fill 236 269 562 236 269 563 minecraft:magma_block
fill 237 269 560 238 272 562 minecraft:magma_block
fill 239 269 561 239 272 561 minecraft:magma_block
fill 245 269 599 245 272 599 minecraft:red_concrete
fill 250 269 557 251 272 557 minecraft:red_concrete
setblock 250 269 599 minecraft:yellow_concrete
setblock 255 269 557 minecraft:yellow_concrete
setblock 261 269 599 minecraft:yellow_concrete
fill 265 269 599 266 272 599 minecraft:red_concrete
setblock 266 269 557 minecraft:yellow_concrete
fill 271 269 557 271 272 557 minecraft:red_concrete
fill 277 269 562 277 272 562 minecraft:red_concrete
setblock 277 269 563 minecraft:yellow_concrete
fill 277 269 566 277 269 567 minecraft:yellow_concrete
fill 277 269 583 277 272 583 minecraft:red_concrete
setblock 277 269 587 minecraft:yellow_concrete
fill 277 269 594 277 272 594 minecraft:red_concrete
setblock 277 269 595 minecraft:yellow_concrete
setblock 277 269 598 minecraft:yellow_concrete
setblock 235 270 559 minecraft:red_concrete
fill 235 270 560 235 271 560 minecraft:yellow_concrete
fill 235 270 562 235 283 562 minecraft:red_concrete
fill 235 270 563 235 270 564 minecraft:yellow_concrete
fill 235 270 565 235 272 566 minecraft:red_concrete
fill 235 270 571 235 271 572 minecraft:yellow_concrete
fill 235 270 573 235 283 574 minecraft:red_concrete
setblock 235 270 575 minecraft:yellow_concrete
fill 235 270 576 235 289 576 minecraft:red_concrete
fill 235 270 583 235 271 584 minecraft:yellow_concrete
fill 235 270 585 235 283 586 minecraft:red_concrete
fill 235 270 592 235 271 592 minecraft:yellow_concrete
fill 235 270 593 235 283 594 minecraft:red_concrete
setblock 235 270 595 minecraft:yellow_concrete
fill 235 270 597 235 287 597 minecraft:red_concrete
fill 236 270 557 236 271 557 minecraft:yellow_concrete
fill 236 270 558 238 270 558 minecraft:orange_concrete
fill 236 270 559 237 271 559 minecraft:magma_block
fill 236 270 560 236 270 562 minecraft:orange_concrete
fill 236 270 563 237 271 563 minecraft:magma_block
fill 236 270 564 236 270 566 minecraft:orange_concrete
fill 236 270 568 236 270 570 minecraft:orange_concrete
fill 236 270 572 236 270 574 minecraft:orange_concrete
fill 236 270 576 236 270 578 minecraft:orange_concrete
fill 236 270 580 236 270 582 minecraft:orange_concrete
fill 236 270 584 236 270 586 minecraft:orange_concrete
fill 236 270 588 236 270 590 minecraft:orange_concrete
fill 236 270 592 236 270 594 minecraft:orange_concrete
fill 236 270 596 236 270 598 minecraft:orange_concrete
fill 238 270 598 240 270 598 minecraft:orange_concrete
fill 239 270 560 240 271 560 minecraft:magma_block
fill 239 270 562 240 271 562 minecraft:magma_block
fill 239 270 599 240 271 599 minecraft:yellow_concrete
fill 240 270 558 242 270 558 minecraft:orange_concrete
fill 240 270 561 242 270 561 minecraft:magma_block
fill 241 270 599 242 283 599 minecraft:red_concrete
fill 242 270 557 243 283 557 minecraft:red_concrete
fill 242 270 598 244 270 598 minecraft:orange_concrete
fill 244 270 557 245 271 557 minecraft:yellow_concrete
fill 244 270 558 246 270 558 minecraft:orange_concrete
fill 246 270 598 248 270 598 minecraft:orange_concrete
fill 248 270 558 250 270 558 minecraft:orange_concrete
fill 250 270 598 252 270 598 minecraft:orange_concrete
fill 250 270 599 250 283 599 minecraft:red_concrete
fill 251 270 599 252 270 599 minecraft:yellow_concrete
fill 252 270 558 254 270 558 minecraft:orange_concrete
setblock 253 270 557 minecraft:yellow_concrete
fill 253 270 599 254 287 599 minecraft:red_concrete
fill 254 270 557 255 283 557 minecraft:red_concrete
fill 254 270 598 256 270 598 minecraft:orange_concrete
fill 256 270 557 257 271 557 minecraft:yellow_concrete
fill 256 270 558 258 270 558 minecraft:orange_concrete
fill 258 270 598 260 270 598 minecraft:orange_concrete
fill 259 270 599 260 271 599 minecraft:yellow_concrete
fill 260 270 558 262 270 558 minecraft:orange_concrete
fill 261 270 599 262 283 599 minecraft:red_concrete
fill 262 270 557 263 287 557 minecraft:red_concrete
fill 262 270 598 264 270 598 minecraft:orange_concrete
setblock 263 270 599 minecraft:yellow_concrete
fill 264 270 557 265 270 557 minecraft:yellow_concrete
fill 264 270 558 266 270 558 minecraft:orange_concrete
fill 266 270 557 266 283 557 minecraft:red_concrete
fill 266 270 598 268 270 598 minecraft:orange_concrete
fill 268 270 558 270 270 558 minecraft:orange_concrete
fill 270 270 598 272 270 598 minecraft:orange_concrete
fill 271 270 599 272 271 599 minecraft:yellow_concrete
fill 272 270 558 274 270 558 minecraft:orange_concrete
fill 273 270 599 274 283 599 minecraft:red_concrete
fill 274 270 557 275 283 557 minecraft:red_concrete
fill 274 270 598 276 270 598 minecraft:orange_concrete
fill 276 270 557 277 271 557 minecraft:yellow_concrete
fill 276 270 558 276 270 560 minecraft:orange_concrete
fill 276 270 562 276 270 564 minecraft:orange_concrete
fill 276 270 566 276 270 568 minecraft:orange_concrete
fill 276 270 570 276 270 572 minecraft:orange_concrete
fill 276 270 574 276 270 576 minecraft:orange_concrete
fill 276 270 578 276 270 580 minecraft:orange_concrete
fill 276 270 582 276 270 584 minecraft:orange_concrete
fill 276 270 586 276 270 588 minecraft:orange_concrete
fill 276 270 590 276 270 592 minecraft:orange_concrete
fill 276 270 594 276 270 596 minecraft:orange_concrete
fill 277 270 563 277 287 563 minecraft:red_concrete
setblock 277 270 565 minecraft:yellow_concrete
fill 277 270 566 277 283 567 minecraft:red_concrete
fill 277 270 568 277 271 568 minecraft:yellow_concrete
fill 277 270 574 277 283 575 minecraft:red_concrete
fill 277 270 576 277 270 577 minecraft:yellow_concrete
fill 277 270 586 277 283 587 minecraft:red_concrete
fill 277 270 588 277 271 589 minecraft:yellow_concrete
fill 277 270 595 277 287 595 minecraft:red_concrete
fill 277 270 596 277 270 597 minecraft:yellow_concrete
fill 277 270 598 277 283 598 minecraft:red_concrete
setblock 235 271 559 minecraft:yellow_concrete
setblock 235 271 563 minecraft:yellow_concrete
fill 235 271 564 235 289 564 minecraft:red_concrete
fill 235 271 575 235 289 575 minecraft:red_concrete
setblock 235 271 580 minecraft:yellow_concrete
setblock 235 271 591 minecraft:yellow_concrete
fill 235 271 595 235 289 595 minecraft:red_concrete
fill 236 271 560 236 272 562 minecraft:magma_block
setblock 237 271 557 minecraft:yellow_concrete
setblock 238 271 568 minecraft:light[level=14]
setblock 238 271 576 minecraft:light[level=14]
setblock 238 271 584 minecraft:light[level=14]
setblock 238 271 592 minecraft:light[level=14]
fill 240 271 561 241 271 561 minecraft:magma_block
setblock 246 271 560 minecraft:light[level=14]
setblock 246 271 568 minecraft:light[level=14]
setblock 246 271 576 minecraft:light[level=14]
setblock 246 271 584 minecraft:light[level=14]
setblock 246 271 592 minecraft:light[level=14]
fill 247 271 599 248 271 599 minecraft:yellow_concrete
setblock 248 271 557 minecraft:yellow_concrete
setblock 251 271 599 minecraft:yellow_concrete
fill 252 271 599 252 289 599 minecraft:red_concrete
fill 253 271 557 253 289 557 minecraft:red_concrete
setblock 254 271 560 minecraft:light[level=14]
setblock 254 271 568 minecraft:light[level=14]
setblock 254 271 576 minecraft:light[level=14]
setblock 254 271 584 minecraft:light[level=14]
setblock 254 271 592 minecraft:light[level=14]
setblock 262 271 560 minecraft:light[level=14]
setblock 262 271 568 minecraft:light[level=14]
setblock 262 271 576 minecraft:light[level=14]
setblock 262 271 584 minecraft:light[level=14]
setblock 262 271 592 minecraft:light[level=14]
fill 263 271 599 263 289 599 minecraft:red_concrete
fill 264 271 557 264 289 557 minecraft:red_concrete
setblock 265 271 557 minecraft:yellow_concrete
fill 268 271 557 269 271 557 minecraft:yellow_concrete
setblock 268 271 599 minecraft:yellow_concrete
setblock 270 271 560 minecraft:light[level=14]
setblock 270 271 568 minecraft:light[level=14]
setblock 270 271 576 minecraft:light[level=14]
setblock 270 271 584 minecraft:light[level=14]
setblock 270 271 592 minecraft:light[level=14]
fill 277 271 565 277 289 565 minecraft:red_concrete
setblock 277 271 569 minecraft:yellow_concrete
fill 277 271 576 277 289 576 minecraft:red_concrete
setblock 277 271 577 minecraft:yellow_concrete
setblock 277 271 580 minecraft:yellow_concrete
fill 277 271 596 277 289 597 minecraft:red_concrete
fill 235 272 557 235 273 558 minecraft:yellow_concrete
fill 235 272 559 235 285 560 minecraft:red_concrete
setblock 235 272 561 minecraft:yellow_concrete
fill 235 272 563 235 289 563 minecraft:red_concrete
fill 235 272 569 235 273 570 minecraft:yellow_concrete
fill 235 272 571 235 285 572 minecraft:red_concrete
setblock 235 272 577 minecraft:red_concrete
fill 235 272 578 235 273 578 minecraft:yellow_concrete
fill 235 272 580 235 285 580 minecraft:red_concrete
fill 235 272 581 235 272 582 minecraft:yellow_concrete
fill 235 272 583 235 289 584 minecraft:red_concrete
fill 235 272 589 235 273 590 minecraft:yellow_concrete
fill 235 272 591 235 285 592 minecraft:red_concrete
fill 236 272 557 237 285 557 minecraft:red_concrete
setblock 236 272 559 minecraft:magma_block
setblock 236 272 563 minecraft:magma_block
fill 237 272 599 238 272 599 minecraft:yellow_concrete
fill 238 272 557 239 273 557 minecraft:yellow_concrete
fill 239 272 599 240 285 599 minecraft:red_concrete
fill 244 272 557 245 289 557 minecraft:red_concrete
fill 246 272 557 247 272 557 minecraft:yellow_concrete
fill 246 272 599 246 273 599 minecraft:yellow_concrete
fill 247 272 599 248 285 599 minecraft:red_concrete
fill 248 272 557 248 285 557 minecraft:red_concrete
setblock 249 272 599 minecraft:yellow_concrete
fill 251 272 599 251 289 599 minecraft:red_concrete
fill 256 272 557 257 285 557 minecraft:red_concrete
fill 257 272 599 258 273 599 minecraft:yellow_concrete
fill 258 272 557 259 273 557 minecraft:yellow_concrete
fill 259 272 599 260 285 599 minecraft:red_concrete
fill 265 272 557 265 289 557 minecraft:red_concrete
setblock 267 272 557 minecraft:yellow_concrete
fill 268 272 557 269 285 557 minecraft:red_concrete
fill 268 272 599 268 285 599 minecraft:red_concrete
fill 269 272 599 270 272 599 minecraft:yellow_concrete
fill 270 272 557 270 273 557 minecraft:yellow_concrete
fill 271 272 599 272 289 599 minecraft:red_concrete
fill 276 272 557 277 285 557 minecraft:red_concrete
fill 277 272 558 277 272 559 minecraft:yellow_concrete
fill 277 272 568 277 285 569 minecraft:red_concrete
fill 277 272 570 277 273 571 minecraft:yellow_concrete
fill 277 272 577 277 289 577 minecraft:red_concrete
fill 277 272 578 277 272 579 minecraft:yellow_concrete
fill 277 272 580 277 285 580 minecraft:red_concrete
fill 277 272 582 277 273 582 minecraft:yellow_concrete
fill 277 272 588 277 285 589 minecraft:red_concrete
fill 277 272 590 277 273 591 minecraft:yellow_concrete
fill 277 272 599 277 273 599 minecraft:yellow_concrete
fill 235 273 561 235 283 561 minecraft:red_concrete
fill 235 273 565 235 287 565 minecraft:red_concrete
setblock 235 273 566 minecraft:yellow_concrete
setblock 235 273 577 minecraft:yellow_concrete
setblock 235 273 581 minecraft:yellow_concrete
fill 235 273 582 235 283 582 minecraft:red_concrete
setblock 235 273 598 minecraft:yellow_concrete
setblock 236 273 561 minecraft:magma_block
setblock 237 273 599 minecraft:yellow_concrete
fill 238 273 599 238 283 599 minecraft:red_concrete
setblock 245 273 599 minecraft:yellow_concrete
fill 246 273 557 246 283 557 minecraft:red_concrete
setblock 247 273 557 minecraft:yellow_concrete
fill 249 273 599 249 283 599 minecraft:red_concrete
fill 250 273 557 251 273 557 minecraft:yellow_concrete
fill 265 273 599 266 273 599 minecraft:yellow_concrete
fill 267 273 557 267 283 557 minecraft:red_concrete
setblock 269 273 599 minecraft:yellow_concrete
fill 270 273 599 270 283 599 minecraft:red_concrete
setblock 271 273 557 minecraft:yellow_concrete
fill 277 273 558 277 283 558 minecraft:red_concrete
setblock 277 273 559 minecraft:yellow_concrete
setblock 277 273 562 minecraft:yellow_concrete
fill 277 273 578 277 283 579 minecraft:red_concrete
setblock 277 273 583 minecraft:yellow_concrete
setblock 277 273 594 minecraft:yellow_concrete
fill 235 274 557 235 287 558 minecraft:red_concrete
fill 235 274 566 235 287 566 minecraft:red_concrete
fill 235 274 569 235 284 570 minecraft:red_concrete
fill 235 274 577 235 287 578 minecraft:red_concrete
fill 235 274 581 235 283 581 minecraft:red_concrete
fill 235 274 589 235 284 590 minecraft:red_concrete
fill 235 274 598 235 287 598 minecraft:red_concrete
fill 237 274 599 237 284 599 minecraft:red_concrete
fill 238 274 557 239 284 557 minecraft:red_concrete
fill 245 274 599 246 287 599 minecraft:red_concrete
fill 247 274 557 247 284 557 minecraft:red_concrete
fill 250 274 557 251 287 557 minecraft:red_concrete
fill 257 274 599 258 284 599 minecraft:red_concrete
fill 258 274 557 259 284 557 minecraft:red_concrete
fill 265 274 599 266 287 599 minecraft:red_concrete
fill 269 274 599 269 284 599 minecraft:red_concrete
fill 270 274 557 271 287 557 minecraft:red_concrete
fill 277 274 559 277 284 559 minecraft:red_concrete
fill 277 274 562 277 287 562 minecraft:red_concrete
fill 277 274 570 277 284 571 minecraft:red_concrete
fill 277 274 582 277 287 583 minecraft:red_concrete
fill 277 274 590 277 284 591 minecraft:red_concrete
fill 277 274 594 277 287 594 minecraft:red_concrete
fill 277 274 599 277 287 599 minecraft:red_concrete
setblock 238 279 560 minecraft:light[level=14]
setblock 238 279 568 minecraft:light[level=14]
setblock 238 279 576 minecraft:light[level=14]
setblock 238 279 584 minecraft:light[level=14]
setblock 238 279 592 minecraft:light[level=14]
fill 242 279 574 249 280 574 minecraft:orange_concrete
fill 242 279 586 249 280 586 minecraft:orange_concrete
fill 243 279 575 261 279 576 minecraft:orange_concrete
fill 243 279 584 261 279 585 minecraft:orange_concrete
fill 244 279 577 261 279 577 minecraft:orange_concrete
fill 244 279 583 261 279 583 minecraft:orange_concrete
fill 245 279 578 254 279 578 minecraft:orange_concrete
fill 245 279 582 254 279 582 minecraft:orange_concrete
setblock 246 279 560 minecraft:light[level=14]
setblock 246 279 568 minecraft:light[level=14]
setblock 246 279 592 minecraft:light[level=14]
fill 247 279 579 253 279 579 minecraft:orange_concrete
fill 247 279 581 253 279 581 minecraft:orange_concrete
fill 249 279 580 252 279 580 minecraft:orange_concrete
fill 251 279 567 253 279 574 minecraft:orange_concrete
fill 251 279 586 253 279 593 minecraft:orange_concrete
fill 252 279 566 252 280 566 minecraft:orange_concrete
fill 252 279 594 252 280 594 minecraft:orange_concrete
setblock 254 279 560 minecraft:light[level=14]
fill 254 279 568 254 279 574 minecraft:orange_concrete
fill 254 279 586 254 279 592 minecraft:orange_concrete
fill 255 279 570 255 279 574 minecraft:orange_concrete
fill 255 279 586 255 279 590 minecraft:orange_concrete
fill 256 279 572 256 280 574 minecraft:orange_concrete
fill 256 279 578 266 279 578 minecraft:orange_concrete
fill 256 279 582 266 279 582 minecraft:orange_concrete
fill 256 279 586 256 280 588 minecraft:orange_concrete
fill 257 279 573 263 279 574 minecraft:orange_concrete
fill 257 279 579 268 279 579 minecraft:orange_concrete
fill 257 279 581 268 279 581 minecraft:orange_concrete
fill 257 279 586 263 279 587 minecraft:orange_concrete
fill 258 279 572 263 279 572 minecraft:orange_concrete
fill 258 279 580 270 279 580 minecraft:orange_concrete
fill 258 279 588 263 279 588 minecraft:orange_concrete
fill 259 279 571 264 280 571 minecraft:orange_concrete
fill 259 279 589 264 280 589 minecraft:orange_concrete
fill 261 279 570 264 280 570 minecraft:orange_concrete
fill 261 279 590 264 280 590 minecraft:orange_concrete
setblock 262 279 560 minecraft:light[level=14]
setblock 262 279 568 minecraft:light[level=14]
fill 262 279 569 264 280 569 minecraft:orange_concrete
fill 262 279 575 262 280 575 minecraft:orange_concrete
setblock 262 279 576 minecraft:light[level=14]
setblock 262 279 584 minecraft:light[level=14]
fill 262 279 585 262 280 585 minecraft:orange_concrete
fill 262 279 591 264 280 591 minecraft:orange_concrete
setblock 262 279 592 minecraft:light[level=14]
setblock 270 279 560 minecraft:light[level=14]
setblock 270 279 568 minecraft:light[level=14]
setblock 270 279 576 minecraft:light[level=14]
setblock 270 279 584 minecraft:light[level=14]
setblock 270 279 592 minecraft:light[level=14]
fill 236 280 558 241 280 598 minecraft:red_concrete
fill 242 280 558 250 280 573 minecraft:red_concrete
fill 242 280 575 242 280 585 minecraft:red_concrete
fill 242 280 587 250 280 598 minecraft:red_concrete
fill 243 280 575 245 280 576 minecraft:orange_concrete
fill 243 280 577 243 280 583 minecraft:red_concrete
fill 243 280 584 245 280 585 minecraft:orange_concrete
fill 244 280 577 246 280 577 minecraft:orange_concrete
fill 244 280 578 244 280 582 minecraft:red_concrete
fill 244 280 583 246 280 583 minecraft:orange_concrete
fill 245 280 578 247 280 578 minecraft:orange_concrete
fill 245 280 579 246 280 581 minecraft:red_concrete
fill 245 280 582 247 280 582 minecraft:orange_concrete
fill 246 280 575 251 280 575 minecraft:orange_concrete
fill 246 280 576 254 280 576 minecraft:yellow_concrete
fill 246 280 584 254 280 584 minecraft:yellow_concrete
fill 246 280 585 251 280 585 minecraft:orange_concrete
fill 247 280 577 252 280 577 minecraft:yellow_concrete
fill 247 280 579 248 280 579 minecraft:orange_concrete
fill 247 280 580 248 280 580 minecraft:red_concrete
fill 247 280 581 248 280 581 minecraft:orange_concrete
fill 247 280 583 252 280 583 minecraft:yellow_concrete
fill 248 280 578 251 280 578 minecraft:yellow_concrete
fill 248 280 582 251 280 582 minecraft:yellow_concrete
fill 249 280 579 251 280 579 minecraft:yellow_concrete
fill 249 280 580 250 280 580 minecraft:orange_concrete
fill 249 280 581 251 280 581 minecraft:yellow_concrete
setblock 250 280 574 minecraft:red_concrete
setblock 250 280 586 minecraft:red_concrete
fill 251 280 558 251 280 566 minecraft:red_concrete
fill 251 280 567 251 280 574 minecraft:orange_concrete
setblock 251 280 580 minecraft:red_concrete
fill 251 280 586 251 280 593 minecraft:orange_concrete
fill 251 280 594 251 280 598 minecraft:red_concrete
fill 252 280 558 276 280 565 minecraft:red_concrete
fill 252 280 567 252 280 571 minecraft:orange_concrete
fill 252 280 572 254 280 575 minecraft:yellow_concrete
setblock 252 280 578 minecraft:red_concrete
fill 252 280 579 252 280 581 minecraft:shroomlight
setblock 252 280 582 minecraft:red_concrete
fill 252 280 585 254 280 588 minecraft:yellow_concrete
fill 252 280 589 252 280 593 minecraft:orange_concrete
fill 252 280 595 276 280 598 minecraft:red_concrete
fill 253 280 566 276 280 566 minecraft:red_concrete
fill 253 280 567 253 280 570 minecraft:orange_concrete
setblock 253 280 571 minecraft:yellow_concrete
setblock 253 280 577 minecraft:red_concrete
fill 253 280 578 253 280 579 minecraft:shroomlight
fill 253 280 581 253 280 582 minecraft:shroomlight
setblock 253 280 583 minecraft:red_concrete
setblock 253 280 589 minecraft:yellow_concrete
fill 253 280 590 253 280 593 minecraft:orange_concrete
fill 253 280 594 276 280 594 minecraft:red_concrete
fill 254 280 567 276 280 567 minecraft:red_concrete
fill 254 280 568 254 280 571 minecraft:orange_concrete
fill 254 280 577 254 280 578 minecraft:shroomlight
fill 254 280 582 254 280 583 minecraft:shroomlight
fill 254 280 589 254 280 592 minecraft:orange_concrete
fill 254 280 593 276 280 593 minecraft:red_concrete
fill 255 280 568 261 280 569 minecraft:red_concrete
fill 255 280 570 255 280 572 minecraft:orange_concrete
fill 255 280 573 255 280 575 minecraft:yellow_concrete
setblock 255 280 576 minecraft:red_concrete
fill 255 280 577 256 280 577 minecraft:shroomlight
fill 255 280 583 256 280 583 minecraft:shroomlight
setblock 255 280 584 minecraft:red_concrete
fill 255 280 585 255 280 587 minecraft:yellow_concrete
fill 255 280 588 255 280 590 minecraft:orange_concrete
fill 255 280 591 261 280 592 minecraft:red_concrete
fill 256 280 570 258 280 571 minecraft:red_concrete
setblock 256 280 575 minecraft:orange_concrete
fill 256 280 576 260 280 576 minecraft:yellow_concrete
fill 256 280 578 257 280 578 minecraft:shroomlight
fill 256 280 582 257 280 582 minecraft:shroomlight
fill 256 280 584 260 280 584 minecraft:yellow_concrete
setblock 256 280 585 minecraft:orange_concrete
fill 256 280 589 258 280 590 minecraft:red_concrete
setblock 257 280 572 minecraft:red_concrete
fill 257 280 573 257 280 574 minecraft:orange_concrete
fill 257 280 575 261 280 575 minecraft:yellow_concrete
setblock 257 280 577 minecraft:red_concrete
fill 257 280 579 258 280 579 minecraft:shroomlight
fill 257 280 581 258 280 581 minecraft:shroomlight
setblock 257 280 583 minecraft:red_concrete
fill 257 280 585 261 280 585 minecraft:yellow_concrete
fill 257 280 586 257 280 587 minecraft:orange_concrete
setblock 257 280 588 minecraft:red_concrete
fill 258 280 572 258 280 573 minecraft:orange_concrete
fill 258 280 574 261 280 574 minecraft:yellow_concrete
fill 258 280 577 260 280 577 minecraft:yellow_concrete
setblock 258 280 578 minecraft:red_concrete
setblock 258 280 580 minecraft:shroomlight
setblock 258 280 582 minecraft:red_concrete
fill 258 280 583 260 280 583 minecraft:yellow_concrete
fill 258 280 586 261 280 586 minecraft:yellow_concrete
fill 258 280 587 258 280 588 minecraft:orange_concrete
fill 259 280 570 260 280 570 minecraft:red_concrete
fill 259 280 572 260 280 572 minecraft:orange_concrete
fill 259 280 573 261 280 573 minecraft:yellow_concrete
fill 259 280 578 261 280 579 minecraft:yellow_concrete
setblock 259 280 580 minecraft:red_concrete
fill 259 280 581 261 280 582 minecraft:yellow_concrete
fill 259 280 587 261 280 587 minecraft:yellow_concrete
fill 259 280 588 260 280 588 minecraft:orange_concrete
fill 259 280 590 260 280 590 minecraft:red_concrete
fill 260 280 580 265 280 580 minecraft:yellow_concrete
setblock 261 280 572 minecraft:yellow_concrete
fill 261 280 576 261 280 577 minecraft:orange_concrete
fill 261 280 583 261 280 584 minecraft:orange_concrete
setblock 261 280 588 minecraft:yellow_concrete
fill 262 280 568 276 280 568 minecraft:red_concrete
fill 262 280 572 263 280 574 minecraft:orange_concrete
fill 262 280 576 276 280 577 minecraft:red_concrete
fill 262 280 578 266 280 578 minecraft:orange_concrete
fill 262 280 579 264 280 579 minecraft:yellow_concrete
fill 262 280 581 264 280 581 minecraft:yellow_concrete
fill 262 280 582 266 280 582 minecraft:orange_concrete
fill 262 280 583 276 280 584 minecraft:red_concrete
fill 262 280 586 263 280 588 minecraft:orange_concrete
fill 262 280 592 276 280 592 minecraft:red_concrete
fill 263 280 575 276 280 575 minecraft:red_concrete
fill 263 280 585 276 280 585 minecraft:red_concrete
fill 264 280 572 276 280 574 minecraft:red_concrete
fill 264 280 586 276 280 588 minecraft:red_concrete
fill 265 280 569 276 280 571 minecraft:red_concrete
fill 265 280 579 268 280 579 minecraft:orange_concrete
fill 265 280 581 268 280 581 minecraft:orange_concrete
fill 265 280 589 276 280 591 minecraft:red_concrete
fill 266 280 580 270 280 580 minecraft:orange_concrete
fill 267 280 578 276 280 578 minecraft:red_concrete
fill 267 280 582 276 280 582 minecraft:red_concrete
fill 269 280 579 276 280 579 minecraft:red_concrete
fill 269 280 581 276 280 581 minecraft:red_concrete
fill 271 280 580 276 280 580 minecraft:red_concrete
fill 235 284 561 235 285 562 minecraft:yellow_concrete
fill 235 284 573 235 284 574 minecraft:yellow_concrete
fill 235 284 581 235 285 582 minecraft:yellow_concrete
setblock 235 284 585 minecraft:yellow_concrete
fill 235 284 586 235 287 586 minecraft:red_concrete
fill 235 284 593 235 285 594 minecraft:yellow_concrete
fill 238 284 599 238 285 599 minecraft:yellow_concrete
fill 241 284 599 242 284 599 minecraft:yellow_concrete
fill 242 284 557 242 287 557 minecraft:red_concrete
setblock 243 284 557 minecraft:yellow_concrete
fill 246 284 557 246 285 557 minecraft:yellow_concrete
fill 249 284 599 250 285 599 minecraft:yellow_concrete
fill 254 284 557 255 284 557 minecraft:yellow_concrete
fill 261 284 599 262 284 599 minecraft:yellow_concrete
fill 266 284 557 267 285 557 minecraft:yellow_concrete
fill 270 284 599 270 285 599 minecraft:yellow_concrete
setblock 273 284 599 minecraft:yellow_concrete
fill 274 284 557 275 284 557 minecraft:yellow_concrete
fill 274 284 599 274 287 599 minecraft:red_concrete
fill 277 284 558 277 285 558 minecraft:yellow_concrete
fill 277 284 566 277 285 567 minecraft:yellow_concrete
fill 277 284 574 277 287 574 minecraft:red_concrete
setblock 277 284 575 minecraft:yellow_concrete
fill 277 284 578 277 285 579 minecraft:yellow_concrete
fill 277 284 586 277 284 587 minecraft:yellow_concrete
fill 277 284 598 277 285 598 minecraft:yellow_concrete
fill 235 285 569 235 285 570 minecraft:yellow_concrete
setblock 235 285 573 minecraft:yellow_concrete
fill 235 285 574 235 288 574 minecraft:red_concrete
fill 235 285 585 235 288 585 minecraft:red_concrete
fill 235 285 589 235 287 589 minecraft:red_concrete
setblock 235 285 590 minecraft:yellow_concrete
setblock 237 285 599 minecraft:yellow_concrete
setblock 238 285 557 minecraft:yellow_concrete
fill 239 285 557 239 287 557 minecraft:red_concrete
fill 241 285 599 242 288 599 minecraft:red_concrete
fill 243 285 557 243 288 557 minecraft:red_concrete
setblock 247 285 557 minecraft:yellow_concrete
fill 254 285 557 254 288 557 minecraft:red_concrete
setblock 255 285 557 minecraft:yellow_concrete
fill 257 285 599 257 287 599 minecraft:red_concrete
setblock 258 285 557 minecraft:yellow_concrete
setblock 258 285 599 minecraft:yellow_concrete
fill 259 285 557 259 287 557 minecraft:red_concrete
setblock 261 285 599 minecraft:yellow_concrete
fill 262 285 599 262 288 599 minecraft:red_concrete
setblock 269 285 599 minecraft:yellow_concrete
fill 273 285 599 273 288 599 minecraft:red_concrete
fill 274 285 557 275 288 557 minecraft:red_concrete
setblock 277 285 559 minecraft:yellow_concrete
setblock 277 285 570 minecraft:yellow_concrete
fill 277 285 571 277 287 571 minecraft:red_concrete
fill 277 285 575 277 288 575 minecraft:red_concrete
fill 277 285 586 277 288 586 minecraft:red_concrete
setblock 277 285 587 minecraft:yellow_concrete
fill 277 285 590 277 285 591 minecraft:yellow_concrete
fill 235 286 559 235 287 560 minecraft:yellow_concrete
fill 235 286 561 235 291 562 minecraft:red_concrete
setblock 235 286 567 minecraft:red_concrete
fill 235 286 568 235 287 568 minecraft:yellow_concrete
fill 235 286 569 235 291 570 minecraft:red_concrete
setblock 235 286 571 minecraft:yellow_concrete
fill 235 286 572 235 289 573 minecraft:red_concrete
fill 235 286 579 235 287 580 minecraft:yellow_concrete
fill 235 286 581 235 291 582 minecraft:red_concrete
fill 235 286 590 235 291 590 minecraft:red_concrete
fill 235 286 591 235 286 592 minecraft:yellow_concrete
fill 235 286 593 235 291 594 minecraft:red_concrete
fill 235 286 599 236 287 599 minecraft:yellow_concrete
fill 236 286 557 237 286 557 minecraft:yellow_concrete
fill 237 286 599 238 291 599 minecraft:red_concrete
fill 238 286 557 238 287 557 minecraft:red_concrete
setblock 239 286 599 minecraft:yellow_concrete
fill 240 286 599 240 289 599 minecraft:red_concrete
fill 246 286 557 247 291 557 minecraft:red_concrete
fill 247 286 599 248 287 599 minecraft:yellow_concrete
fill 248 286 557 249 287 557 minecraft:yellow_concrete
fill 249 286 599 250 291 599 minecraft:red_concrete
fill 255 286 557 255 291 557 minecraft:red_concrete
setblock 255 286 599 minecraft:red_concrete
fill 256 286 557 257 286 557 minecraft:yellow_concrete
fill 256 286 599 256 287 599 minecraft:yellow_concrete
fill 258 286 557 258 291 557 minecraft:red_concrete
fill 258 286 599 258 291 599 minecraft:red_concrete
fill 259 286 599 260 286 599 minecraft:yellow_concrete
fill 260 286 557 260 287 557 minecraft:yellow_concrete
setblock 261 286 557 minecraft:red_concrete
fill 261 286 599 261 291 599 minecraft:red_concrete
fill 266 286 557 267 291 557 minecraft:red_concrete
fill 267 286 599 268 287 599 minecraft:yellow_concrete
fill 268 286 557 269 287 557 minecraft:yellow_concrete
fill 269 286 599 270 291 599 minecraft:red_concrete
fill 276 286 557 276 289 557 minecraft:red_concrete
setblock 277 286 557 minecraft:yellow_concrete
fill 277 286 558 277 291 559 minecraft:red_concrete
fill 277 286 560 277 287 561 minecraft:yellow_concrete
fill 277 286 566 277 291 567 minecraft:red_concrete
fill 277 286 568 277 286 569 minecraft:yellow_concrete
fill 277 286 570 277 291 570 minecraft:red_concrete
fill 277 286 578 277 291 579 minecraft:red_concrete
fill 277 286 580 277 287 581 minecraft:yellow_concrete
fill 277 286 587 277 289 588 minecraft:red_concrete
setblock 277 286 589 minecraft:yellow_concrete
fill 277 286 590 277 291 591 minecraft:red_concrete
fill 277 286 592 277 287 592 minecraft:yellow_concrete
setblock 277 286 593 minecraft:red_concrete
fill 277 286 598 277 291 598 minecraft:red_concrete
setblock 235 287 567 minecraft:yellow_concrete
fill 235 287 571 235 290 571 minecraft:red_concrete
fill 235 287 587 235 287 588 minecraft:yellow_concrete
setblock 235 287 591 minecraft:yellow_concrete
fill 235 287 592 235 290 592 minecraft:red_concrete
fill 236 287 557 236 290 557 minecraft:red_concrete
setblock 237 287 557 minecraft:yellow_concrete
setblock 238 287 560 minecraft:light[level=14]
setblock 238 287 568 minecraft:light[level=14]
setblock 238 287 576 minecraft:light[level=14]
setblock 238 287 584 minecraft:light[level=14]
setblock 238 287 592 minecraft:light[level=14]
fill 239 287 599 239 290 599 minecraft:red_concrete
fill 240 287 557 241 287 557 minecraft:yellow_concrete
fill 243 287 599 243 289 599 minecraft:red_concrete
setblock 244 287 599 minecraft:yellow_concrete
setblock 246 287 560 minecraft:light[level=14]
setblock 246 287 568 minecraft:light[level=14]
setblock 246 287 576 minecraft:light[level=14]
setblock 246 287 584 minecraft:light[level=14]
setblock 246 287 592 minecraft:light[level=14]
fill 249 287 567 250 288 568 minecraft:yellow_concrete
setblock 254 287 560 minecraft:light[level=14]
setblock 254 287 568 minecraft:light[level=14]
setblock 254 287 576 minecraft:light[level=14]
setblock 254 287 584 minecraft:light[level=14]
setblock 254 287 592 minecraft:light[level=14]
setblock 255 287 599 minecraft:yellow_concrete
fill 256 287 557 257 290 557 minecraft:red_concrete
fill 259 287 599 260 290 599 minecraft:red_concrete
setblock 261 287 557 minecraft:yellow_concrete
setblock 262 287 560 minecraft:light[level=14]
setblock 262 287 568 minecraft:light[level=14]
setblock 262 287 576 minecraft:light[level=14]
setblock 262 287 584 minecraft:light[level=14]
setblock 262 287 592 minecraft:light[level=14]
setblock 270 287 560 minecraft:light[level=14]
setblock 270 287 568 minecraft:light[level=14]
setblock 270 287 576 minecraft:light[level=14]
setblock 270 287 584 minecraft:light[level=14]
setblock 270 287 592 minecraft:light[level=14]
setblock 272 287 557 minecraft:yellow_concrete
fill 273 287 557 273 289 557 minecraft:red_concrete
fill 275 287 599 275 289 599 minecraft:red_concrete
setblock 276 287 599 minecraft:yellow_concrete
fill 277 287 557 277 290 557 minecraft:red_concrete
fill 277 287 568 277 290 568 minecraft:red_concrete
setblock 277 287 569 minecraft:yellow_concrete
fill 277 287 572 277 287 573 minecraft:yellow_concrete
fill 277 287 589 277 290 589 minecraft:red_concrete
setblock 277 287 593 minecraft:yellow_concrete
fill 235 288 557 235 288 558 minecraft:yellow_concrete
fill 235 288 559 235 290 560 minecraft:red_concrete
fill 235 288 565 235 289 566 minecraft:yellow_concrete
fill 235 288 567 235 293 568 minecraft:red_concrete
fill 235 288 577 235 288 578 minecraft:yellow_concrete
fill 235 288 579 235 293 580 minecraft:red_concrete
fill 235 288 586 235 289 586 minecraft:yellow_concrete
fill 235 288 587 235 293 588 minecraft:red_concrete
setblock 235 288 589 minecraft:yellow_concrete
fill 235 288 591 235 293 591 minecraft:red_concrete
fill 235 288 597 235 289 598 minecraft:yellow_concrete
fill 235 288 599 236 293 599 minecraft:red_concrete
fill 236 288 558 238 288 558 minecraft:orange_concrete
fill 236 288 560 236 288 562 minecraft:orange_concrete
fill 236 288 564 236 288 566 minecraft:orange_concrete
fill 236 288 568 236 288 570 minecraft:orange_concrete
fill 236 288 572 236 288 574 minecraft:orange_concrete
fill 236 288 576 236 288 578 minecraft:orange_concrete
fill 236 288 580 236 288 582 minecraft:orange_concrete
fill 236 288 584 236 288 586 minecraft:orange_concrete
fill 236 288 588 236 288 590 minecraft:orange_concrete
fill 236 288 592 236 288 594 minecraft:orange_concrete
fill 236 288 596 236 288 598 minecraft:orange_concrete
fill 237 288 557 237 293 557 minecraft:red_concrete
fill 238 288 557 239 288 557 minecraft:yellow_concrete
fill 238 288 598 240 288 598 minecraft:orange_concrete
fill 240 288 557 241 289 557 minecraft:red_concrete
fill 240 288 558 242 288 558 minecraft:orange_concrete
fill 242 288 557 242 289 557 minecraft:yellow_concrete
fill 242 288 598 244 288 598 minecraft:orange_concrete
fill 244 288 558 246 288 558 minecraft:orange_concrete
fill 244 288 599 244 293 599 minecraft:red_concrete
fill 245 288 599 246 288 599 minecraft:yellow_concrete
fill 246 288 598 248 288 598 minecraft:orange_concrete
fill 247 288 599 248 293 599 minecraft:red_concrete
fill 248 288 557 249 293 557 minecraft:red_concrete
fill 248 288 558 250 288 558 minecraft:orange_concrete
fill 250 288 557 251 289 557 minecraft:yellow_concrete
fill 250 288 598 252 288 598 minecraft:orange_concrete
fill 252 288 558 254 288 558 minecraft:orange_concrete
fill 253 288 599 254 289 599 minecraft:yellow_concrete
fill 254 288 598 256 288 598 minecraft:orange_concrete
fill 255 288 599 256 293 599 minecraft:red_concrete
fill 256 288 558 258 288 558 minecraft:orange_concrete
setblock 257 288 599 minecraft:yellow_concrete
fill 258 288 598 260 288 598 minecraft:orange_concrete
setblock 259 288 557 minecraft:yellow_concrete
fill 260 288 557 261 293 557 minecraft:red_concrete
fill 260 288 558 262 288 558 minecraft:orange_concrete
fill 262 288 557 263 289 557 minecraft:yellow_concrete
fill 262 288 598 264 288 598 minecraft:orange_concrete
fill 264 288 558 266 288 558 minecraft:orange_concrete
fill 265 288 599 266 289 599 minecraft:yellow_concrete
fill 266 288 598 268 288 598 minecraft:orange_concrete
fill 267 288 599 268 293 599 minecraft:red_concrete
fill 268 288 557 269 293 557 minecraft:red_concrete
fill 268 288 558 270 288 558 minecraft:orange_concrete
fill 270 288 557 271 288 557 minecraft:yellow_concrete
fill 270 288 598 272 288 598 minecraft:orange_concrete
fill 272 288 557 272 293 557 minecraft:red_concrete
fill 272 288 558 274 288 558 minecraft:orange_concrete
fill 274 288 598 276 288 598 minecraft:orange_concrete
fill 274 288 599 274 289 599 minecraft:yellow_concrete
fill 276 288 558 276 288 560 minecraft:orange_concrete
fill 276 288 562 276 288 564 minecraft:orange_concrete
fill 276 288 566 276 288 568 minecraft:orange_concrete
fill 276 288 570 276 288 572 minecraft:orange_concrete
fill 276 288 574 276 288 576 minecraft:orange_concrete
fill 276 288 578 276 288 580 minecraft:orange_concrete
fill 276 288 582 276 288 584 minecraft:orange_concrete
fill 276 288 586 276 288 588 minecraft:orange_concrete
fill 276 288 590 276 288 592 minecraft:orange_concrete
fill 276 288 594 276 288 596 minecraft:orange_concrete
fill 276 288 599 276 293 599 minecraft:red_concrete
fill 277 288 560 277 293 561 minecraft:red_concrete
fill 277 288 562 277 289 563 minecraft:yellow_concrete
fill 277 288 569 277 293 569 minecraft:red_concrete
setblock 277 288 571 minecraft:yellow_concrete
fill 277 288 572 277 293 573 minecraft:red_concrete
fill 277 288 574 277 289 574 minecraft:yellow_concrete
fill 277 288 580 277 293 581 minecraft:red_concrete
fill 277 288 582 277 288 583 minecraft:yellow_concrete
fill 277 288 592 277 293 593 minecraft:red_concrete
fill 277 288 594 277 289 595 minecraft:yellow_concrete
setblock 277 288 599 minecraft:yellow_concrete
setblock 235 289 557 minecraft:yellow_concrete
fill 235 289 558 235 292 558 minecraft:red_concrete
setblock 235 289 574 minecraft:yellow_concrete
setblock 235 289 577 minecraft:yellow_concrete
fill 235 289 578 235 292 578 minecraft:red_concrete
setblock 235 289 585 minecraft:yellow_concrete
fill 235 289 589 235 292 589 minecraft:red_concrete
fill 238 289 557 239 291 557 minecraft:red_concrete
fill 241 289 599 242 289 599 minecraft:yellow_concrete
setblock 243 289 557 minecraft:yellow_concrete
setblock 245 289 599 minecraft:yellow_concrete
fill 246 289 599 246 292 599 minecraft:red_concrete
setblock 254 289 557 minecraft:yellow_concrete
fill 257 289 599 257 292 599 minecraft:red_concrete
fill 259 289 557 259 292 557 minecraft:red_concrete
setblock 262 289 599 minecraft:yellow_concrete
fill 270 289 557 270 292 557 minecraft:red_concrete
setblock 271 289 557 minecraft:yellow_concrete
setblock 273 289 599 minecraft:yellow_concrete
fill 274 289 557 275 289 557 minecraft:yellow_concrete
fill 277 289 571 277 292 571 minecraft:red_concrete
setblock 277 289 575 minecraft:yellow_concrete
fill 277 289 582 277 292 582 minecraft:red_concrete
setblock 277 289 583 minecraft:yellow_concrete
setblock 277 289 586 minecraft:yellow_concrete
fill 277 289 599 277 292 599 minecraft:red_concrete
fill 235 290 557 235 292 557 minecraft:red_concrete
fill 235 290 563 235 291 564 minecraft:yellow_concrete
fill 235 290 565 235 295 566 minecraft:red_concrete
fill 235 290 572 235 291 572 minecraft:yellow_concrete
fill 235 290 573 235 291 574 minecraft:red_concrete
fill 235 290 575 235 290 576 minecraft:yellow_concrete
fill 235 290 577 235 295 577 minecraft:red_concrete
fill 235 290 583 235 291 584 minecraft:yellow_concrete
fill 235 290 585 235 295 586 minecraft:red_concrete
fill 235 290 595 235 290 596 minecraft:yellow_concrete
fill 235 290 597 235 295 598 minecraft:red_concrete
fill 240 290 557 240 293 557 minecraft:red_concrete
fill 240 290 599 240 291 599 minecraft:yellow_concrete
setblock 241 290 557 minecraft:yellow_concrete
fill 241 290 599 242 295 599 minecraft:red_concrete
fill 242 290 557 243 295 557 minecraft:red_concrete
setblock 243 290 599 minecraft:yellow_concrete
fill 244 290 557 245 291 557 minecraft:yellow_concrete
fill 245 290 599 245 295 599 minecraft:red_concrete
fill 250 290 557 251 292 557 minecraft:red_concrete
fill 251 290 599 252 291 599 minecraft:yellow_concrete
fill 252 290 557 253 290 557 minecraft:yellow_concrete
fill 253 290 599 254 295 599 minecraft:red_concrete
fill 254 290 557 254 295 557 minecraft:red_concrete
fill 262 290 557 263 295 557 minecraft:red_concrete
fill 262 290 599 262 295 599 minecraft:red_concrete
fill 263 290 599 264 290 599 minecraft:yellow_concrete
fill 264 290 557 265 291 557 minecraft:yellow_concrete
fill 265 290 599 266 295 599 minecraft:red_concrete
fill 271 290 557 271 295 557 minecraft:red_concrete
fill 271 290 599 272 291 599 minecraft:yellow_concrete
setblock 273 290 557 minecraft:yellow_concrete
fill 273 290 599 274 295 599 minecraft:red_concrete
fill 274 290 557 275 295 557 minecraft:red_concrete
setblock 275 290 599 minecraft:yellow_concrete
fill 276 290 557 276 291 557 minecraft:yellow_concrete
fill 277 290 562 277 295 563 minecraft:red_concrete
fill 277 290 564 277 290 565 minecraft:yellow_concrete
fill 277 290 574 277 295 575 minecraft:red_concrete
fill 277 290 576 277 291 577 minecraft:yellow_concrete
fill 277 290 583 277 295 583 minecraft:red_concrete
fill 277 290 584 277 290 585 minecraft:yellow_concrete
fill 277 290 586 277 291 587 minecraft:red_concrete
fill 277 290 588 277 291 588 minecraft:yellow_concrete
fill 277 290 594 277 295 595 minecraft:red_concrete
fill 277 290 596 277 291 597 minecraft:yellow_concrete
fill 235 291 559 235 293 559 minecraft:red_concrete
setblock 235 291 560 minecraft:yellow_concrete
setblock 235 291 571 minecraft:yellow_concrete
fill 235 291 575 235 294 576 minecraft:red_concrete
setblock 235 291 592 minecraft:yellow_concrete
setblock 235 291 595 minecraft:yellow_concrete
fill 235 291 596 235 294 596 minecraft:red_concrete
setblock 236 291 557 minecraft:yellow_concrete
setblock 239 291 599 minecraft:yellow_concrete
fill 241 291 557 241 293 557 minecraft:red_concrete
fill 243 291 599 243 294 599 minecraft:red_concrete
fill 245 291 571 245 292 571 minecraft:yellow_concrete
fill 252 291 557 252 294 557 minecraft:red_concrete
setblock 253 291 557 minecraft:yellow_concrete
fill 255 291 592 255 292 592 minecraft:red_concrete
fill 256 291 557 257 291 557 minecraft:yellow_concrete
fill 259 291 599 260 291 599 minecraft:yellow_concrete
setblock 263 291 599 minecraft:yellow_concrete
fill 264 291 599 264 294 599 minecraft:red_concrete
fill 273 291 557 273 294 557 minecraft:red_concrete
fill 275 291 599 275 294 599 minecraft:red_concrete
setblock 277 291 557 minecraft:yellow_concrete
fill 277 291 564 277 294 564 minecraft:red_concrete
setblock 277 291 565 minecraft:yellow_concrete
setblock 277 291 568 minecraft:yellow_concrete
fill 277 291 584 277 294 585 minecraft:red_concrete
setblock 277 291 589 minecraft:yellow_concrete
fill 235 292 560 235 297 560 minecraft:red_concrete
fill 235 292 561 235 292 562 minecraft:yellow_concrete
fill 235 292 563 235 297 564 minecraft:red_concrete
fill 235 292 569 235 293 570 minecraft:yellow_concrete
fill 235 292 571 235 297 572 minecraft:red_concrete
setblock 235 292 573 minecraft:yellow_concrete
fill 235 292 574 235 295 574 minecraft:red_concrete
fill 235 292 581 235 293 582 minecraft:yellow_concrete
fill 235 292 583 235 297 584 minecraft:red_concrete
fill 235 292 590 235 293 590 minecraft:yellow_concrete
fill 235 292 592 235 297 592 minecraft:red_concrete
fill 235 292 593 235 292 594 minecraft:yellow_concrete
fill 235 292 595 235 297 595 minecraft:red_concrete
fill 236 292 557 236 297 557 minecraft:red_concrete
fill 237 292 599 238 293 599 minecraft:yellow_concrete
fill 238 292 557 238 293 557 minecraft:yellow_concrete
setblock 239 292 557 minecraft:red_concrete
fill 239 292 599 240 297 599 minecraft:red_concrete
fill 244 292 557 245 297 557 minecraft:red_concrete
fill 246 292 557 247 293 557 minecraft:yellow_concrete
fill 249 292 599 250 292 599 minecraft:yellow_concrete
fill 251 292 599 252 297 599 minecraft:red_concrete
fill 253 292 557 253 294 557 minecraft:red_concrete
setblock 255 292 557 minecraft:yellow_concrete
fill 256 292 557 257 297 557 minecraft:red_concrete
fill 258 292 557 258 293 557 minecraft:yellow_concrete
fill 258 292 599 258 293 599 minecraft:yellow_concrete
fill 259 292 599 260 297 599 minecraft:red_concrete
setblock 261 292 599 minecraft:yellow_concrete
fill 263 292 599 263 297 599 minecraft:red_concrete
fill 264 292 557 265 297 557 minecraft:red_concrete
fill 266 292 557 267 292 557 minecraft:yellow_concrete
fill 269 292 599 270 293 599 minecraft:yellow_concrete
fill 271 292 599 272 297 599 minecraft:red_concrete
fill 276 292 557 277 297 557 minecraft:red_concrete
fill 277 292 558 277 293 559 minecraft:yellow_concrete
fill 277 292 565 277 297 565 minecraft:red_concrete
fill 277 292 566 277 292 567 minecraft:yellow_concrete
fill 277 292 568 277 297 568 minecraft:red_concrete
fill 277 292 570 277 293 570 minecraft:yellow_concrete
fill 277 292 576 277 297 577 minecraft:red_concrete
fill 277 292 578 277 293 579 minecraft:yellow_concrete
fill 277 292 586 277 295 586 minecraft:red_concrete
setblock 277 292 587 minecraft:yellow_concrete
fill 277 292 588 277 297 589 minecraft:red_concrete
fill 277 292 590 277 293 591 minecraft:yellow_concrete
fill 277 292 596 277 297 597 minecraft:red_concrete
setblock 277 292 598 minecraft:yellow_concrete
fill 235 293 557 235 293 558 minecraft:yellow_concrete
setblock 235 293 561 minecraft:yellow_concrete
fill 235 293 562 235 296 562 minecraft:red_concrete
fill 235 293 573 235 296 573 minecraft:red_concrete
setblock 235 293 578 minecraft:yellow_concrete
setblock 235 293 589 minecraft:yellow_concrete
fill 235 293 593 235 296 594 minecraft:red_concrete
setblock 239 293 557 minecraft:yellow_concrete
setblock 246 293 599 minecraft:yellow_concrete
setblock 249 293 599 minecraft:yellow_concrete
setblock 250 293 557 minecraft:yellow_concrete
fill 250 293 599 250 296 599 minecraft:red_concrete
fill 251 293 557 251 295 557 minecraft:red_concrete
fill 255 293 557 255 296 557 minecraft:red_concrete
fill 256 293 565 257 294 565 minecraft:yellow_concrete
setblock 257 293 599 minecraft:yellow_concrete
setblock 259 293 557 minecraft:yellow_concrete
fill 261 293 599 261 296 599 minecraft:red_concrete
fill 266 293 557 266 296 557 minecraft:red_concrete
setblock 267 293 557 minecraft:yellow_concrete
setblock 270 293 557 minecraft:yellow_concrete
fill 277 293 566 277 296 567 minecraft:red_concrete
setblock 277 293 571 minecraft:yellow_concrete
setblock 277 293 582 minecraft:yellow_concrete
fill 277 293 587 277 296 587 minecraft:red_concrete
fill 277 293 598 277 296 598 minecraft:red_concrete
setblock 277 293 599 minecraft:yellow_concrete
fill 235 294 557 235 299 558 minecraft:red_concrete
setblock 235 294 559 minecraft:yellow_concrete
fill 235 294 561 235 299 561 minecraft:red_concrete
fill 235 294 567 235 295 568 minecraft:yellow_concrete
fill 235 294 569 235 299 570 minecraft:red_concrete
fill 235 294 578 235 299 578 minecraft:red_concrete
fill 235 294 579 235 294 580 minecraft:yellow_concrete
fill 235 294 581 235 299 582 minecraft:red_concrete
fill 235 294 587 235 295 588 minecraft:yellow_concrete
fill 235 294 589 235 299 590 minecraft:red_concrete
setblock 235 294 591 minecraft:yellow_concrete
fill 235 294 599 236 295 599 minecraft:yellow_concrete
fill 236 294 558 238 294 558 minecraft:orange_concrete
fill 236 294 560 236 294 562 minecraft:orange_concrete
fill 236 294 564 236 294 566 minecraft:orange_concrete
fill 236 294 568 236 294 570 minecraft:orange_concrete
fill 236 294 572 236 294 574 minecraft:orange_concrete
fill 236 294 576 236 294 578 minecraft:orange_concrete
fill 236 294 580 236 294 582 minecraft:orange_concrete
fill 236 294 584 236 294 586 minecraft:orange_concrete
fill 236 294 588 236 294 590 minecraft:orange_concrete
fill 236 294 592 236 294 594 minecraft:orange_concrete
fill 236 294 596 236 294 598 minecraft:orange_concrete
setblock 237 294 557 minecraft:yellow_concrete
fill 237 294 599 238 299 599 minecraft:red_concrete
fill 238 294 557 239 299 557 minecraft:red_concrete
fill 238 294 598 240 294 598 minecraft:orange_concrete
fill 240 294 557 241 295 557 minecraft:yellow_concrete
fill 240 294 558 242 294 558 minecraft:orange_concrete
fill 242 294 598 244 294 598 minecraft:orange_concrete
fill 244 294 558 246 294 558 minecraft:orange_concrete
fill 244 294 599 244 295 599 minecraft:yellow_concrete
fill 246 294 557 247 299 557 minecraft:red_concrete
fill 246 294 598 248 294 598 minecraft:orange_concrete
fill 246 294 599 246 299 599 minecraft:red_concrete
fill 247 294 599 248 294 599 minecraft:yellow_concrete
fill 248 294 557 249 294 557 minecraft:yellow_concrete
fill 248 294 558 250 294 558 minecraft:orange_concrete
fill 249 294 599 249 299 599 minecraft:red_concrete
fill 250 294 557 250 295 557 minecraft:red_concrete
fill 250 294 598 252 294 598 minecraft:orange_concrete
fill 252 294 558 254 294 558 minecraft:orange_concrete
fill 254 294 598 256 294 598 minecraft:orange_concrete
fill 255 294 599 256 295 599 minecraft:yellow_concrete
fill 256 294 558 258 294 558 minecraft:orange_concrete
fill 257 294 599 258 299 599 minecraft:red_concrete
fill 258 294 557 259 299 557 minecraft:red_concrete
fill 258 294 598 260 294 598 minecraft:orange_concrete
fill 260 294 557 261 295 557 minecraft:yellow_concrete
fill 260 294 558 262 294 558 minecraft:orange_concrete
fill 262 294 598 264 294 598 minecraft:orange_concrete
fill 264 294 558 266 294 558 minecraft:orange_concrete
fill 266 294 598 268 294 598 minecraft:orange_concrete
fill 267 294 557 267 299 557 minecraft:red_concrete
fill 267 294 599 268 294 599 minecraft:yellow_concrete
fill 268 294 557 269 294 557 minecraft:yellow_concrete
fill 268 294 558 270 294 558 minecraft:orange_concrete
fill 269 294 599 270 299 599 minecraft:red_concrete
fill 270 294 557 270 299 557 minecraft:red_concrete
fill 270 294 598 272 294 598 minecraft:orange_concrete
fill 272 294 557 272 295 557 minecraft:yellow_concrete
fill 272 294 558 274 294 558 minecraft:orange_concrete
fill 274 294 598 276 294 598 minecraft:orange_concrete
fill 276 294 558 276 294 560 minecraft:orange_concrete
fill 276 294 562 276 294 564 minecraft:orange_concrete
fill 276 294 566 276 294 568 minecraft:orange_concrete
fill 276 294 570 276 294 572 minecraft:orange_concrete
fill 276 294 574 276 294 576 minecraft:orange_concrete
fill 276 294 578 276 294 580 minecraft:orange_concrete
fill 276 294 582 276 294 584 minecraft:orange_concrete
fill 276 294 586 276 294 588 minecraft:orange_concrete
fill 276 294 590 276 294 592 minecraft:orange_concrete
fill 276 294 594 276 294 596 minecraft:orange_concrete
fill 276 294 599 276 295 599 minecraft:yellow_concrete
fill 277 294 558 277 299 559 minecraft:red_concrete
fill 277 294 560 277 295 561 minecraft:yellow_concrete
setblock 277 294 569 minecraft:yellow_concrete
fill 277 294 570 277 299 571 minecraft:red_concrete
fill 277 294 572 277 295 573 minecraft:yellow_concrete
fill 277 294 578 277 299 579 minecraft:red_concrete
fill 277 294 580 277 294 581 minecraft:yellow_concrete
fill 277 294 582 277 299 582 minecraft:red_concrete
fill 277 294 590 277 299 591 minecraft:red_concrete
fill 277 294 592 277 295 593 minecraft:yellow_concrete
fill 277 294 599 277 299 599 minecraft:red_concrete
fill 235 295 559 235 298 559 minecraft:red_concrete
fill 235 295 575 235 295 576 minecraft:yellow_concrete
setblock 235 295 579 minecraft:yellow_concrete
fill 235 295 580 235 298 580 minecraft:red_concrete
fill 235 295 591 235 298 591 minecraft:red_concrete
setblock 235 295 596 minecraft:yellow_concrete
fill 237 295 557 237 298 557 minecraft:red_concrete
setblock 238 295 560 minecraft:light[level=14]
setblock 238 295 568 minecraft:light[level=14]
setblock 238 295 576 minecraft:light[level=14]
setblock 238 295 584 minecraft:light[level=14]
setblock 238 295 592 minecraft:light[level=14]
setblock 243 295 599 minecraft:yellow_concrete
setblock 246 295 560 minecraft:light[level=14]
setblock 246 295 568 minecraft:light[level=14]
setblock 246 295 576 minecraft:light[level=14]
setblock 246 295 584 minecraft:light[level=14]
setblock 246 295 592 minecraft:light[level=14]
fill 247 295 599 248 298 599 minecraft:red_concrete
fill 248 295 557 248 298 557 minecraft:red_concrete
setblock 249 295 557 minecraft:yellow_concrete
fill 252 295 557 253 295 557 minecraft:yellow_concrete
setblock 254 295 560 minecraft:light[level=14]
setblock 254 295 568 minecraft:light[level=14]
setblock 254 295 576 minecraft:light[level=14]
setblock 254 295 584 minecraft:light[level=14]
setblock 254 295 592 minecraft:light[level=14]
setblock 262 295 560 minecraft:light[level=14]
setblock 262 295 568 minecraft:light[level=14]
setblock 262 295 576 minecraft:light[level=14]
setblock 262 295 584 minecraft:light[level=14]
setblock 262 295 592 minecraft:light[level=14]
setblock 264 295 599 minecraft:yellow_concrete
setblock 267 295 599 minecraft:yellow_concrete
fill 268 295 557 269 298 557 minecraft:red_concrete
fill 268 295 599 268 298 599 minecraft:red_concrete
setblock 270 295 560 minecraft:light[level=14]
setblock 270 295 568 minecraft:light[level=14]
setblock 270 295 576 minecraft:light[level=14]
setblock 270 295 584 minecraft:light[level=14]
setblock 270 295 592 minecraft:light[level=14]
setblock 273 295 557 minecraft:yellow_concrete
setblock 275 295 599 minecraft:yellow_concrete
setblock 277 295 564 minecraft:yellow_concrete
fill 277 295 569 277 298 569 minecraft:red_concrete
fill 277 295 580 277 298 580 minecraft:red_concrete
setblock 277 295 581 minecraft:yellow_concrete
fill 277 295 584 277 295 585 minecraft:yellow_concrete
fill 235 296 565 235 296 566 minecraft:yellow_concrete
fill 235 296 567 235 307 568 minecraft:red_concrete
fill 235 296 574 235 297 574 minecraft:yellow_concrete
fill 235 296 575 235 307 576 minecraft:red_concrete
setblock 235 296 577 minecraft:yellow_concrete
fill 235 296 579 235 307 579 minecraft:red_concrete
fill 235 296 585 235 297 586 minecraft:yellow_concrete
fill 235 296 587 235 307 588 minecraft:red_concrete
fill 235 296 596 235 307 596 minecraft:red_concrete
fill 235 296 597 235 296 598 minecraft:yellow_concrete
fill 235 296 599 236 307 599 minecraft:red_concrete
fill 240 296 557 241 307 557 minecraft:red_concrete
fill 241 296 599 242 297 599 minecraft:yellow_concrete
fill 242 296 557 243 297 557 minecraft:yellow_concrete
fill 243 296 599 244 307 599 minecraft:red_concrete
setblock 245 296 599 minecraft:yellow_concrete
fill 249 296 557 249 307 557 minecraft:red_concrete
fill 250 296 557 251 296 557 minecraft:yellow_concrete
fill 252 296 557 253 297 557 minecraft:red_concrete
fill 253 296 599 254 297 599 minecraft:yellow_concrete
fill 254 296 557 254 297 557 minecraft:yellow_concrete
fill 255 296 599 256 307 599 minecraft:red_concrete
fill 260 296 557 261 307 557 minecraft:red_concrete
fill 262 296 557 263 297 557 minecraft:yellow_concrete
fill 262 296 599 262 297 599 minecraft:yellow_concrete
fill 264 296 599 264 307 599 minecraft:red_concrete
fill 265 296 599 266 296 599 minecraft:yellow_concrete
fill 267 296 599 267 307 599 minecraft:red_concrete
setblock 271 296 557 minecraft:yellow_concrete
fill 272 296 557 273 307 557 minecraft:red_concrete
fill 273 296 599 274 297 599 minecraft:yellow_concrete
fill 274 296 557 275 297 557 minecraft:yellow_concrete
fill 275 296 599 276 307 599 minecraft:red_concrete
fill 277 296 560 277 307 561 minecraft:red_concrete
fill 277 296 562 277 296 563 minecraft:yellow_concrete
fill 277 296 564 277 307 564 minecraft:red_concrete
fill 277 296 572 277 307 573 minecraft:red_concrete
fill 277 296 574 277 297 575 minecraft:yellow_concrete
fill 277 296 581 277 307 581 minecraft:red_concrete
setblock 277 296 583 minecraft:yellow_concrete
fill 277 296 584 277 307 585 minecraft:red_concrete
fill 277 296 586 277 297 586 minecraft:yellow_concrete
fill 277 296 592 277 307 593 minecraft:red_concrete
fill 277 296 594 277 296 595 minecraft:yellow_concrete
setblock 235 297 562 minecraft:yellow_concrete
setblock 235 297 565 minecraft:yellow_concrete
fill 235 297 566 235 307 566 minecraft:red_concrete
setblock 235 297 573 minecraft:yellow_concrete
fill 235 297 577 235 307 577 minecraft:red_concrete
fill 235 297 593 235 297 594 minecraft:yellow_concrete
setblock 235 297 597 minecraft:yellow_concrete
fill 235 297 598 235 307 598 minecraft:red_concrete
fill 245 297 599 245 307 599 minecraft:red_concrete
fill 250 297 557 251 299 557 minecraft:red_concrete
setblock 250 297 599 minecraft:yellow_concrete
setblock 255 297 557 minecraft:yellow_concrete
setblock 261 297 599 minecraft:yellow_concrete
fill 265 297 599 266 307 599 minecraft:red_concrete
setblock 266 297 557 minecraft:yellow_concrete
fill 271 297 557 271 307 557 minecraft:red_concrete
fill 277 297 562 277 307 562 minecraft:red_concrete
setblock 277 297 563 minecraft:yellow_concrete
fill 277 297 566 277 297 567 minecraft:yellow_concrete
fill 277 297 583 277 307 583 minecraft:red_concrete
setblock 277 297 587 minecraft:yellow_concrete
fill 277 297 594 277 307 594 minecraft:red_concrete
setblock 277 297 595 minecraft:yellow_concrete
setblock 277 297 598 minecraft:yellow_concrete
fill 235 298 560 235 299 560 minecraft:yellow_concrete
fill 235 298 562 235 307 562 minecraft:red_concrete
fill 235 298 563 235 298 564 minecraft:yellow_concrete
fill 235 298 565 235 307 565 minecraft:red_concrete
fill 235 298 571 235 299 572 minecraft:yellow_concrete
fill 235 298 573 235 307 574 minecraft:red_concrete
fill 235 298 583 235 298 584 minecraft:yellow_concrete
fill 235 298 585 235 307 586 minecraft:red_concrete
fill 235 298 592 235 299 592 minecraft:yellow_concrete
fill 235 298 593 235 307 594 minecraft:red_concrete
setblock 235 298 595 minecraft:yellow_concrete
fill 235 298 597 235 307 597 minecraft:red_concrete
fill 236 298 557 236 299 557 minecraft:yellow_concrete
fill 239 298 599 240 299 599 minecraft:yellow_concrete
fill 241 298 599 242 307 599 minecraft:red_concrete
fill 242 298 557 243 307 557 minecraft:red_concrete
fill 244 298 557 245 299 557 minecraft:yellow_concrete
fill 250 298 599 250 307 599 minecraft:red_concrete
fill 251 298 599 252 298 599 minecraft:yellow_concrete
fill 252 298 557 252 307 557 minecraft:red_concrete
setblock 253 298 557 minecraft:yellow_concrete
fill 253 298 599 254 307 599 minecraft:red_concrete
fill 254 298 557 255 307 557 minecraft:red_concrete
fill 256 298 557 257 299 557 minecraft:yellow_concrete
fill 259 298 599 260 299 599 minecraft:yellow_concrete
fill 261 298 599 262 307 599 minecraft:red_concrete
fill 262 298 557 263 307 557 minecraft:red_concrete
fill 263 298 586 263 299 586 minecraft:red_concrete
setblock 263 298 599 minecraft:yellow_concrete
fill 264 298 557 265 298 557 minecraft:yellow_concrete
fill 266 298 557 266 307 557 minecraft:red_concrete
fill 271 298 599 272 299 599 minecraft:yellow_concrete
fill 273 298 599 274 307 599 minecraft:red_concrete
fill 274 298 557 275 307 557 minecraft:red_concrete
fill 276 298 557 277 299 557 minecraft:yellow_concrete
fill 277 298 563 277 307 563 minecraft:red_concrete
setblock 277 298 565 minecraft:yellow_concrete
fill 277 298 566 277 307 567 minecraft:red_concrete
fill 277 298 568 277 299 568 minecraft:yellow_concrete
fill 277 298 574 277 307 575 minecraft:red_concrete
fill 277 298 576 277 298 577 minecraft:yellow_concrete
fill 277 298 586 277 307 587 minecraft:red_concrete
fill 277 298 588 277 299 589 minecraft:yellow_concrete
fill 277 298 595 277 307 595 minecraft:red_concrete
fill 277 298 596 277 298 597 minecraft:yellow_concrete
fill 277 298 598 277 307 598 minecraft:red_concrete
setblock 235 299 559 minecraft:yellow_concrete
fill 235 299 563 235 307 564 minecraft:red_concrete
setblock 235 299 580 minecraft:yellow_concrete
setblock 235 299 583 minecraft:yellow_concrete
fill 235 299 584 235 307 584 minecraft:red_concrete
setblock 235 299 591 minecraft:yellow_concrete
fill 235 299 595 235 307 595 minecraft:red_concrete
setblock 237 299 557 minecraft:yellow_concrete
fill 247 299 599 248 299 599 minecraft:yellow_concrete
setblock 248 299 557 minecraft:yellow_concrete
setblock 251 299 599 minecraft:yellow_concrete
fill 252 299 599 252 307 599 minecraft:red_concrete
fill 253 299 557 253 307 557 minecraft:red_concrete
fill 263 299 599 263 307 599 minecraft:red_concrete
fill 264 299 557 264 307 557 minecraft:red_concrete
setblock 265 299 557 minecraft:yellow_concrete
fill 268 299 557 269 299 557 minecraft:yellow_concrete
setblock 268 299 599 minecraft:yellow_concrete
fill 277 299 565 277 307 565 minecraft:red_concrete
setblock 277 299 569 minecraft:yellow_concrete
fill 277 299 576 277 307 576 minecraft:red_concrete
setblock 277 299 577 minecraft:yellow_concrete
setblock 277 299 580 minecraft:yellow_concrete
fill 277 299 596 277 307 597 minecraft:red_concrete
fill 235 300 557 235 300 558 minecraft:yellow_concrete
fill 235 300 559 235 307 560 minecraft:red_concrete
setblock 235 300 561 minecraft:yellow_concrete
fill 235 300 569 235 300 570 minecraft:yellow_concrete
fill 235 300 571 235 307 572 minecraft:red_concrete
setblock 235 300 578 minecraft:yellow_concrete
fill 235 300 580 235 307 580 minecraft:red_concrete
fill 235 300 581 235 300 582 minecraft:yellow_concrete
fill 235 300 583 235 307 583 minecraft:red_concrete
fill 235 300 589 235 300 590 minecraft:yellow_concrete
fill 235 300 591 235 307 592 minecraft:red_concrete
fill 236 300 557 237 307 557 minecraft:red_concrete
fill 236 300 558 238 300 558 minecraft:orange_concrete
fill 236 300 560 236 300 562 minecraft:orange_concrete
fill 236 300 564 236 300 566 minecraft:orange_concrete
fill 236 300 568 236 300 570 minecraft:orange_concrete
fill 236 300 572 236 300 574 minecraft:orange_concrete
fill 236 300 576 236 300 578 minecraft:orange_concrete
fill 236 300 580 236 300 582 minecraft:orange_concrete
fill 236 300 584 236 300 586 minecraft:orange_concrete
fill 236 300 588 236 300 590 minecraft:orange_concrete
fill 236 300 592 236 300 594 minecraft:orange_concrete
fill 236 300 596 236 300 598 minecraft:orange_concrete
fill 237 300 599 238 300 599 minecraft:yellow_concrete
fill 238 300 557 239 300 557 minecraft:yellow_concrete
fill 238 300 598 240 300 598 minecraft:orange_concrete
fill 239 300 599 240 307 599 minecraft:red_concrete
fill 240 300 558 242 300 558 minecraft:orange_concrete
fill 242 300 598 244 300 598 minecraft:orange_concrete
fill 244 300 557 245 307 557 minecraft:red_concrete
fill 244 300 558 246 300 558 minecraft:orange_concrete
fill 246 300 557 247 300 557 minecraft:yellow_concrete
fill 246 300 598 248 300 598 minecraft:orange_concrete
setblock 246 300 599 minecraft:yellow_concrete
fill 247 300 599 248 307 599 minecraft:red_concrete
fill 248 300 557 248 307 557 minecraft:red_concrete
fill 248 300 558 250 300 558 minecraft:orange_concrete
setblock 249 300 599 minecraft:yellow_concrete
setblock 250 300 557 minecraft:yellow_concrete
fill 250 300 598 252 300 598 minecraft:orange_concrete
fill 251 300 557 251 307 557 minecraft:red_concrete
fill 251 300 599 251 307 599 minecraft:red_concrete
fill 252 300 558 254 300 558 minecraft:orange_concrete
fill 254 300 598 256 300 598 minecraft:orange_concrete
fill 256 300 557 257 307 557 minecraft:red_concrete
fill 256 300 558 258 300 558 minecraft:orange_concrete
fill 257 300 599 258 300 599 minecraft:yellow_concrete
fill 258 300 557 259 300 557 minecraft:yellow_concrete
fill 258 300 598 260 300 598 minecraft:orange_concrete
fill 259 300 599 260 307 599 minecraft:red_concrete
fill 260 300 558 262 300 558 minecraft:orange_concrete
fill 262 300 598 264 300 598 minecraft:orange_concrete
fill 264 300 558 266 300 558 minecraft:orange_concrete
fill 265 300 557 265 307 557 minecraft:red_concrete
fill 266 300 598 268 300 598 minecraft:orange_concrete
setblock 267 300 557 minecraft:yellow_concrete
fill 268 300 557 269 307 557 minecraft:red_concrete
fill 268 300 558 270 300 558 minecraft:orange_concrete
fill 268 300 599 268 307 599 minecraft:red_concrete
fill 269 300 599 270 300 599 minecraft:yellow_concrete
setblock 270 300 557 minecraft:yellow_concrete
fill 270 300 598 272 300 598 minecraft:orange_concrete
fill 271 300 599 272 307 599 minecraft:red_concrete
fill 272 300 558 274 300 558 minecraft:orange_concrete
fill 274 300 598 276 300 598 minecraft:orange_concrete
fill 276 300 557 277 307 557 minecraft:red_concrete
fill 276 300 558 276 300 560 minecraft:orange_concrete
fill 276 300 562 276 300 564 minecraft:orange_concrete
fill 276 300 566 276 300 568 minecraft:orange_concrete
fill 276 300 570 276 300 572 minecraft:orange_concrete
fill 276 300 574 276 300 576 minecraft:orange_concrete
fill 276 300 578 276 300 580 minecraft:orange_concrete
fill 276 300 582 276 300 584 minecraft:orange_concrete
fill 276 300 586 276 300 588 minecraft:orange_concrete
fill 276 300 590 276 300 592 minecraft:orange_concrete
fill 276 300 594 276 300 596 minecraft:orange_concrete
fill 277 300 558 277 300 559 minecraft:yellow_concrete
fill 277 300 568 277 307 569 minecraft:red_concrete
fill 277 300 570 277 300 571 minecraft:yellow_concrete
fill 277 300 577 277 307 577 minecraft:red_concrete
fill 277 300 578 277 300 579 minecraft:yellow_concrete
fill 277 300 580 277 307 580 minecraft:red_concrete
setblock 277 300 582 minecraft:yellow_concrete
fill 277 300 588 277 307 589 minecraft:red_concrete
fill 277 300 590 277 300 591 minecraft:yellow_concrete
setblock 277 300 599 minecraft:yellow_concrete
fill 235 301 557 235 307 558 minecraft:red_concrete
fill 235 301 561 235 307 561 minecraft:red_concrete
fill 235 301 569 235 307 570 minecraft:red_concrete
fill 235 301 578 235 307 578 minecraft:red_concrete
fill 235 301 581 235 307 582 minecraft:red_concrete
fill 235 301 589 235 307 590 minecraft:red_concrete
fill 237 301 599 238 307 599 minecraft:red_concrete
fill 238 301 557 239 307 557 minecraft:red_concrete
fill 246 301 557 247 307 557 minecraft:red_concrete
fill 246 301 599 246 307 599 minecraft:red_concrete
fill 249 301 599 249 307 599 minecraft:red_concrete
fill 250 301 557 250 307 557 minecraft:red_concrete
fill 257 301 599 258 307 599 minecraft:red_concrete
fill 258 301 557 259 307 557 minecraft:red_concrete
fill 267 301 557 267 307 557 minecraft:red_concrete
fill 269 301 599 270 307 599 minecraft:red_concrete
fill 270 301 557 270 307 557 minecraft:red_concrete
fill 277 301 558 277 307 559 minecraft:red_concrete
fill 277 301 570 277 307 571 minecraft:red_concrete
fill 277 301 578 277 307 579 minecraft:red_concrete
fill 277 301 582 277 307 582 minecraft:red_concrete
fill 277 301 590 277 307 591 minecraft:red_concrete
fill 277 301 599 277 307 599 minecraft:red_concrete
setblock 238 303 560 minecraft:light[level=14]
setblock 238 303 568 minecraft:light[level=14]
setblock 238 303 576 minecraft:light[level=14]
setblock 238 303 584 minecraft:light[level=14]
setblock 238 303 592 minecraft:light[level=14]
setblock 246 303 560 minecraft:light[level=14]
setblock 246 303 568 minecraft:light[level=14]
setblock 246 303 576 minecraft:light[level=14]
setblock 246 303 584 minecraft:light[level=14]
setblock 246 303 592 minecraft:light[level=14]
setblock 254 303 560 minecraft:light[level=14]
setblock 254 303 568 minecraft:light[level=14]
setblock 254 303 576 minecraft:light[level=14]
setblock 254 303 584 minecraft:light[level=14]
setblock 254 303 592 minecraft:light[level=14]
setblock 262 303 560 minecraft:light[level=14]
setblock 262 303 568 minecraft:light[level=14]
setblock 262 303 576 minecraft:light[level=14]
setblock 262 303 584 minecraft:light[level=14]
setblock 262 303 592 minecraft:light[level=14]
setblock 270 303 560 minecraft:light[level=14]
setblock 270 303 568 minecraft:light[level=14]
setblock 270 303 576 minecraft:light[level=14]
setblock 270 303 584 minecraft:light[level=14]
setblock 270 303 592 minecraft:light[level=14]
