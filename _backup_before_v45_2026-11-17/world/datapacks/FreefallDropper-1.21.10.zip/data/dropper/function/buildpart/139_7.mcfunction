setblock 359 234 558 minecraft:green_terracotta
setblock 359 234 598 minecraft:green_terracotta
fill 360 234 562 360 234 564 minecraft:oak_leaves[persistent=true]
fill 361 234 561 364 234 561 minecraft:oak_leaves[persistent=true]
fill 361 234 565 364 234 565 minecraft:oak_leaves[persistent=true]
fill 362 234 560 363 234 560 minecraft:oak_leaves[persistent=true]
fill 362 234 566 363 234 566 minecraft:oak_leaves[persistent=true]
setblock 363 234 558 minecraft:oak_leaves[persistent=true]
fill 369 234 563 369 235 563 minecraft:green_terracotta
setblock 369 234 567 minecraft:oak_log
fill 369 234 568 369 236 568 minecraft:green_terracotta
setblock 369 234 582 minecraft:oak_log
fill 369 234 583 369 236 583 minecraft:green_terracotta
setblock 369 234 587 minecraft:oak_log
fill 369 234 588 369 236 589 minecraft:green_terracotta
setblock 370 234 561 minecraft:oak_log
fill 370 234 562 370 236 562 minecraft:green_terracotta
setblock 370 234 566 minecraft:oak_log
fill 370 234 567 370 236 567 minecraft:green_terracotta
setblock 370 234 570 minecraft:green_terracotta
setblock 370 234 571 minecraft:oak_log
fill 370 234 572 370 236 572 minecraft:green_terracotta
setblock 370 234 576 minecraft:oak_log
fill 370 234 577 370 236 577 minecraft:green_terracotta
setblock 370 234 581 minecraft:oak_log
fill 370 234 582 370 236 582 minecraft:green_terracotta
setblock 370 234 586 minecraft:oak_log
fill 370 234 587 370 236 587 minecraft:green_terracotta
setblock 370 234 591 minecraft:oak_log
setblock 370 234 595 minecraft:oak_leaves[persistent=true]
fill 330 235 558 330 235 559 minecraft:green_terracotta
setblock 330 235 560 minecraft:oak_log
fill 330 235 561 330 235 564 minecraft:green_terracotta
setblock 330 235 565 minecraft:oak_log
fill 330 235 566 330 236 566 minecraft:green_terracotta
setblock 330 235 570 minecraft:oak_log
fill 330 235 571 330 236 571 minecraft:green_terracotta
setblock 330 235 575 minecraft:oak_log
fill 330 235 576 330 236 576 minecraft:green_terracotta
setblock 330 235 580 minecraft:oak_log
fill 330 235 581 330 236 581 minecraft:green_terracotta
setblock 330 235 585 minecraft:oak_log
fill 330 235 586 330 236 586 minecraft:green_terracotta
setblock 330 235 590 minecraft:oak_log
setblock 331 235 559 minecraft:oak_log
fill 331 235 560 331 236 560 minecraft:green_terracotta
setblock 331 235 564 minecraft:oak_log
fill 331 235 565 331 236 565 minecraft:green_terracotta
setblock 331 235 569 minecraft:oak_log
fill 331 235 570 331 236 570 minecraft:green_terracotta
setblock 331 235 584 minecraft:oak_log
fill 331 235 585 331 236 585 minecraft:green_terracotta
setblock 332 235 558 minecraft:oak_log
fill 332 235 559 332 236 559 minecraft:green_terracotta
setblock 332 235 563 minecraft:oak_log
fill 332 235 564 332 236 564 minecraft:green_terracotta
setblock 332 235 567 minecraft:green_terracotta
setblock 332 235 568 minecraft:oak_log
fill 332 235 569 332 236 569 minecraft:green_terracotta
setblock 332 235 574 minecraft:oak_leaves[persistent=true]
fill 333 235 558 333 236 558 minecraft:green_terracotta
setblock 333 235 562 minecraft:oak_log
fill 333 235 563 333 236 563 minecraft:green_terracotta
setblock 333 235 567 minecraft:oak_log
fill 333 235 568 333 236 568 minecraft:green_terracotta
setblock 333 235 570 minecraft:oak_leaves[persistent=true]
fill 333 235 575 336 235 575 minecraft:oak_leaves[persistent=true]
fill 333 235 598 336 235 598 minecraft:green_terracotta
setblock 334 235 561 minecraft:oak_log
fill 334 235 569 336 235 569 minecraft:oak_leaves[persistent=true]
setblock 335 235 560 minecraft:oak_log
setblock 335 235 561 minecraft:green_terracotta
setblock 335 235 562 minecraft:oak_leaves[persistent=true]
setblock 336 235 559 minecraft:oak_log
fill 336 235 560 336 236 560 minecraft:green_terracotta
setblock 337 235 558 minecraft:oak_log
fill 337 235 559 337 236 559 minecraft:green_terracotta
fill 337 235 561 338 236 561 minecraft:oak_log
fill 337 235 564 339 235 564 minecraft:oak_leaves[persistent=true]
setblock 337 235 570 minecraft:oak_leaves[persistent=true]
setblock 337 235 574 minecraft:oak_leaves[persistent=true]
setblock 337 235 598 minecraft:oak_log
fill 338 235 558 338 236 558 minecraft:green_terracotta
setblock 338 235 572 minecraft:oak_leaves[persistent=true]
setblock 338 235 580 minecraft:oak_leaves[persistent=true]
setblock 338 235 598 minecraft:green_terracotta
setblock 340 235 560 minecraft:oak_leaves[persistent=true]
setblock 340 235 563 minecraft:oak_leaves[persistent=true]
setblock 340 235 578 minecraft:oak_leaves[persistent=true]
setblock 341 235 559 minecraft:oak_log
setblock 342 235 558 minecraft:oak_log
setblock 343 235 558 minecraft:green_terracotta
setblock 343 235 598 minecraft:oak_leaves[persistent=true]
setblock 347 235 558 minecraft:oak_log
setblock 348 235 558 minecraft:green_terracotta
fill 348 235 598 348 236 598 minecraft:green_terracotta
setblock 351 235 559 minecraft:oak_log
setblock 352 235 558 minecraft:oak_log
setblock 352 235 559 minecraft:green_terracotta
setblock 352 235 598 minecraft:oak_log
fill 353 235 558 353 236 558 minecraft:green_terracotta
setblock 353 235 597 minecraft:oak_log
fill 353 235 598 353 236 598 minecraft:green_terracotta
fill 354 235 597 354 236 597 minecraft:green_terracotta
setblock 357 235 558 minecraft:oak_log
setblock 357 235 598 minecraft:oak_log
setblock 358 235 598 minecraft:green_terracotta
fill 362 235 561 364 235 561 minecraft:oak_leaves[persistent=true]
fill 362 235 565 364 235 565 minecraft:oak_leaves[persistent=true]
setblock 362 235 598 minecraft:oak_leaves[persistent=true]
fill 365 235 563 365 235 564 minecraft:oak_leaves[persistent=true]
fill 368 235 598 368 236 598 minecraft:oak_leaves[persistent=true]
fill 369 235 564 369 235 565 minecraft:green_terracotta
setblock 369 235 566 minecraft:oak_log
fill 369 235 567 369 236 567 minecraft:green_terracotta
fill 369 235 569 369 236 569 minecraft:green_terracotta
setblock 369 235 581 minecraft:oak_log
fill 369 235 582 369 236 582 minecraft:green_terracotta
setblock 369 235 586 minecraft:oak_log
fill 369 235 587 369 236 587 minecraft:green_terracotta
setblock 370 235 560 minecraft:oak_log
fill 370 235 561 370 236 561 minecraft:green_terracotta
setblock 370 235 565 minecraft:oak_log
fill 370 235 566 370 236 566 minecraft:green_terracotta
setblock 370 235 570 minecraft:oak_log
fill 370 235 571 370 236 571 minecraft:green_terracotta
setblock 370 235 575 minecraft:oak_log
fill 370 235 576 370 236 576 minecraft:green_terracotta
setblock 370 235 580 minecraft:oak_log
fill 370 235 581 370 236 581 minecraft:green_terracotta
setblock 370 235 585 minecraft:oak_log
fill 370 235 586 370 236 586 minecraft:green_terracotta
setblock 370 235 590 minecraft:oak_log
fill 370 235 591 370 236 591 minecraft:green_terracotta
setblock 330 236 558 minecraft:green_terracotta
setblock 330 236 559 minecraft:oak_log
fill 330 236 560 330 236 563 minecraft:green_terracotta
setblock 330 236 564 minecraft:oak_log
setblock 330 236 565 minecraft:green_terracotta
setblock 330 236 569 minecraft:oak_log
setblock 330 236 570 minecraft:green_terracotta
setblock 330 236 574 minecraft:oak_log
setblock 330 236 575 minecraft:green_terracotta
setblock 330 236 579 minecraft:oak_log
setblock 330 236 580 minecraft:green_terracotta
setblock 330 236 584 minecraft:oak_log
setblock 330 236 585 minecraft:green_terracotta
setblock 330 236 589 minecraft:oak_log
fill 330 236 590 330 236 591 minecraft:green_terracotta
setblock 330 236 592 minecraft:oak_leaves[persistent=true]
setblock 330 236 598 minecraft:oak_leaves[persistent=true]
setblock 331 236 558 minecraft:oak_log
setblock 331 236 559 minecraft:green_terracotta
setblock 331 236 563 minecraft:oak_log
setblock 331 236 564 minecraft:green_terracotta
setblock 331 236 568 minecraft:oak_log
setblock 331 236 569 minecraft:green_terracotta
setblock 331 236 573 minecraft:oak_log
setblock 331 236 584 minecraft:green_terracotta
setblock 331 236 588 minecraft:oak_log
setblock 332 236 558 minecraft:green_terracotta
setblock 332 236 562 minecraft:oak_log
setblock 332 236 563 minecraft:green_terracotta
setblock 332 236 567 minecraft:oak_log
setblock 332 236 568 minecraft:green_terracotta
setblock 333 236 562 minecraft:green_terracotta
setblock 333 236 566 minecraft:oak_log
setblock 333 236 567 minecraft:green_terracotta
setblock 334 236 560 minecraft:oak_log
fill 334 236 598 335 236 598 minecraft:green_terracotta
setblock 335 236 559 minecraft:oak_log
setblock 335 236 560 minecraft:green_terracotta
setblock 336 236 558 minecraft:oak_log
setblock 336 236 559 minecraft:green_terracotta
setblock 336 236 561 minecraft:oak_log
setblock 336 236 598 minecraft:oak_log
setblock 337 236 558 minecraft:green_terracotta
setblock 337 236 598 minecraft:green_terracotta
fill 338 236 560 339 236 560 minecraft:oak_log
setblock 341 236 558 minecraft:oak_log
setblock 351 236 558 minecraft:oak_log
setblock 351 236 598 minecraft:oak_log
setblock 352 236 558 minecraft:green_terracotta
setblock 352 236 597 minecraft:oak_log
setblock 352 236 598 minecraft:green_terracotta
setblock 353 236 597 minecraft:green_terracotta
setblock 356 236 558 minecraft:oak_log
setblock 356 236 598 minecraft:oak_log
setblock 357 236 598 minecraft:green_terracotta
setblock 369 236 564 minecraft:green_terracotta
setblock 369 236 565 minecraft:oak_log
setblock 369 236 566 minecraft:green_terracotta
setblock 369 236 570 minecraft:oak_log
setblock 369 236 581 minecraft:green_terracotta
setblock 369 236 585 minecraft:oak_log
setblock 369 236 586 minecraft:green_terracotta
setblock 370 236 558 minecraft:oak_leaves[persistent=true]
setblock 370 236 560 minecraft:green_terracotta
setblock 370 236 564 minecraft:oak_log
setblock 370 236 565 minecraft:green_terracotta
setblock 370 236 569 minecraft:oak_log
setblock 370 236 570 minecraft:green_terracotta
setblock 370 236 574 minecraft:oak_log
setblock 370 236 575 minecraft:green_terracotta
setblock 370 236 579 minecraft:oak_log
setblock 370 236 580 minecraft:green_terracotta
setblock 370 236 584 minecraft:oak_log
setblock 370 236 585 minecraft:green_terracotta
setblock 370 236 589 minecraft:oak_log
setblock 370 236 590 minecraft:green_terracotta
setblock 370 236 592 minecraft:green_terracotta
fill 329 239 559 329 242 562 minecraft:green_terracotta
setblock 329 239 563 minecraft:light_blue_concrete
fill 329 239 564 329 239 567 minecraft:green_terracotta
setblock 329 239 568 minecraft:light_blue_concrete
fill 329 239 570 329 243 570 minecraft:green_terracotta
setblock 329 239 571 minecraft:light_blue_concrete
fill 329 239 572 329 239 573 minecraft:green_terracotta
fill 329 239 586 329 241 586 minecraft:light_blue_concrete
fill 329 239 587 329 240 587 minecraft:green_terracotta
setblock 329 239 588 minecraft:light_blue_concrete
setblock 346 239 557 minecraft:green_terracotta
setblock 347 239 557 minecraft:light_blue_concrete
fill 348 239 557 349 239 557 minecraft:green_terracotta
fill 354 239 557 355 239 557 minecraft:green_terracotta
setblock 356 239 557 minecraft:light_blue_concrete
fill 357 239 557 357 242 557 minecraft:green_terracotta
setblock 358 239 557 minecraft:light_blue_concrete
fill 359 239 557 360 240 557 minecraft:green_terracotta
setblock 361 239 557 minecraft:light_blue_concrete
setblock 361 239 599 minecraft:light_blue_concrete
fill 362 239 557 367 242 557 minecraft:green_terracotta
fill 362 239 599 363 242 599 minecraft:green_terracotta
fill 370 239 557 370 242 557 minecraft:green_terracotta
setblock 371 239 557 minecraft:light_blue_concrete
fill 371 239 559 371 240 559 minecraft:light_blue_concrete
fill 371 239 560 371 242 560 minecraft:green_terracotta
setblock 371 239 569 minecraft:light_blue_concrete
fill 371 239 570 371 242 570 minecraft:green_terracotta
fill 371 239 574 371 240 574 minecraft:light_blue_concrete
fill 371 239 581 371 242 581 minecraft:green_terracotta
setblock 371 239 582 minecraft:light_blue_concrete
fill 329 240 557 333 242 557 minecraft:green_terracotta
setblock 329 240 558 minecraft:light_blue_concrete
fill 329 240 563 329 240 564 minecraft:green_terracotta
setblock 329 240 565 minecraft:light_blue_concrete
fill 329 240 566 329 242 568 minecraft:green_terracotta
fill 329 240 571 329 242 571 minecraft:green_terracotta
setblock 329 240 572 minecraft:light_blue_concrete
fill 329 240 573 329 242 573 minecraft:green_terracotta
fill 329 240 579 329 240 584 minecraft:green_terracotta
setblock 329 240 585 minecraft:light_blue_concrete
fill 329 240 588 329 242 588 minecraft:green_terracotta
setblock 329 240 599 minecraft:light_blue_concrete
setblock 332 240 560 minecraft:light[level=14]
setblock 332 240 568 minecraft:light[level=14]
setblock 332 240 576 minecraft:light[level=14]
setblock 332 240 584 minecraft:light[level=14]
setblock 332 240 592 minecraft:light[level=14]
setblock 334 240 557 minecraft:light_blue_concrete
fill 335 240 557 335 242 557 minecraft:green_terracotta
setblock 336 240 557 minecraft:light_blue_concrete
fill 338 240 557 338 241 557 minecraft:light_blue_concrete
setblock 339 240 557 minecraft:green_terracotta
setblock 340 240 560 minecraft:light[level=14]
setblock 340 240 568 minecraft:light[level=14]
setblock 340 240 576 minecraft:light[level=14]
setblock 340 240 584 minecraft:light[level=14]
setblock 340 240 592 minecraft:light[level=14]
fill 340 240 599 340 241 599 minecraft:light_blue_concrete
fill 341 240 599 344 240 599 minecraft:green_terracotta
setblock 345 240 599 minecraft:light_blue_concrete
setblock 346 240 557 minecraft:light_blue_concrete
fill 346 240 599 348 242 599 minecraft:green_terracotta
fill 347 240 557 348 242 557 minecraft:green_terracotta
setblock 348 240 560 minecraft:light[level=14]
setblock 348 240 568 minecraft:light[level=14]
setblock 348 240 576 minecraft:light[level=14]
setblock 348 240 584 minecraft:light[level=14]
setblock 348 240 592 minecraft:light[level=14]
setblock 349 240 557 minecraft:light_blue_concrete
fill 350 240 557 350 242 557 minecraft:green_terracotta
setblock 350 240 599 minecraft:light_blue_concrete
setblock 351 240 557 minecraft:light_blue_concrete
fill 351 240 599 359 240 599 minecraft:green_terracotta
fill 352 240 557 352 242 557 minecraft:green_terracotta
fill 354 240 557 354 242 557 minecraft:green_terracotta
setblock 355 240 557 minecraft:light_blue_concrete
fill 356 240 557 356 242 557 minecraft:green_terracotta
setblock 356 240 560 minecraft:light[level=14]
setblock 356 240 568 minecraft:light[level=14]
setblock 356 240 576 minecraft:light[level=14]
setblock 356 240 584 minecraft:light[level=14]
setblock 356 240 592 minecraft:light[level=14]
fill 358 240 557 358 242 557 minecraft:green_terracotta
fill 361 240 557 361 242 557 minecraft:green_terracotta
fill 361 240 599 361 242 599 minecraft:green_terracotta
setblock 364 240 560 minecraft:light[level=14]
setblock 364 240 568 minecraft:light[level=14]
setblock 364 240 576 minecraft:light[level=14]
setblock 364 240 584 minecraft:light[level=14]
setblock 364 240 592 minecraft:light[level=14]
setblock 371 240 557 minecraft:green_terracotta
fill 371 240 564 371 240 565 minecraft:light_blue_concrete
fill 371 240 566 371 243 566 minecraft:green_terracotta
fill 371 240 569 371 242 569 minecraft:green_terracotta
fill 371 240 582 371 242 582 minecraft:green_terracotta
fill 371 240 594 371 242 595 minecraft:green_terracotta
fill 371 240 596 371 241 596 minecraft:light_blue_concrete
fill 371 240 597 371 242 597 minecraft:green_terracotta
setblock 371 240 598 minecraft:light_blue_concrete
fill 329 241 558 329 242 558 minecraft:green_terracotta
fill 329 241 563 329 242 563 minecraft:green_terracotta
setblock 329 241 564 minecraft:light_blue_concrete
fill 329 241 565 329 242 565 minecraft:green_terracotta
setblock 329 241 569 minecraft:light_blue_concrete
fill 329 241 572 329 242 572 minecraft:green_terracotta
setblock 329 241 574 minecraft:light_blue_concrete
fill 329 241 575 329 242 575 minecraft:green_terracotta
fill 329 241 576 329 241 577 minecraft:light_blue_concrete
fill 329 241 579 329 242 583 minecraft:green_terracotta
setblock 329 241 584 minecraft:light_blue_concrete
fill 329 241 585 329 242 585 minecraft:green_terracotta
setblock 329 241 587 minecraft:light_blue_concrete
fill 329 241 592 329 241 593 minecraft:light_blue_concrete
fill 329 241 594 329 242 595 minecraft:green_terracotta
setblock 329 241 596 minecraft:light_blue_concrete
fill 329 241 597 329 242 597 minecraft:green_terracotta
setblock 329 241 598 minecraft:light_blue_concrete
fill 329 241 599 329 242 599 minecraft:green_terracotta
fill 333 241 599 337 242 599 minecraft:green_terracotta
fill 334 241 557 334 242 557 minecraft:green_terracotta
fill 336 241 557 336 242 557 minecraft:green_terracotta
setblock 338 241 599 minecraft:light_blue_concrete
setblock 339 241 557 minecraft:light_blue_concrete
fill 339 241 599 339 242 599 minecraft:green_terracotta
fill 341 241 599 341 243 599 minecraft:green_terracotta
setblock 342 241 599 minecraft:light_blue_concrete
fill 343 241 599 343 243 599 minecraft:green_terracotta
fill 344 241 557 344 242 557 minecraft:green_terracotta
setblock 344 241 599 minecraft:light_blue_concrete
setblock 345 241 557 minecraft:light_blue_concrete
fill 345 241 599 345 242 599 minecraft:green_terracotta
fill 346 241 557 346 242 557 minecraft:green_terracotta
fill 346 241 574 348 241 576 minecraft:redstone_block
fill 347 241 581 349 241 583 minecraft:redstone_block
fill 349 241 557 349 243 557 minecraft:green_terracotta
fill 350 241 599 355 242 599 minecraft:green_terracotta
fill 351 241 557 351 242 557 minecraft:green_terracotta
fill 353 241 573 355 241 575 minecraft:redstone_block
fill 354 241 580 356 241 582 minecraft:redstone_block
fill 355 241 557 355 242 557 minecraft:green_terracotta
setblock 356 241 599 minecraft:light_blue_concrete
fill 357 241 599 359 242 599 minecraft:green_terracotta
setblock 359 241 557 minecraft:light_blue_concrete
fill 360 241 557 360 242 557 minecraft:green_terracotta
setblock 369 241 557 minecraft:light_blue_concrete
setblock 371 241 557 minecraft:light_blue_concrete
fill 371 241 559 371 242 559 minecraft:green_terracotta
fill 371 241 564 371 242 565 minecraft:green_terracotta
setblock 371 241 571 minecraft:light_blue_concrete
fill 371 241 574 371 245 574 minecraft:green_terracotta
setblock 371 241 575 minecraft:light_blue_concrete
setblock 371 241 584 minecraft:light_blue_concrete
fill 371 241 590 371 242 590 minecraft:green_terracotta
setblock 371 241 591 minecraft:light_blue_concrete
fill 371 241 592 371 242 592 minecraft:green_terracotta
fill 371 241 598 371 242 598 minecraft:green_terracotta
setblock 329 242 564 minecraft:green_terracotta
setblock 329 242 569 minecraft:green_terracotta
setblock 329 242 574 minecraft:green_terracotta
fill 329 242 576 329 242 577 minecraft:green_terracotta
setblock 329 242 584 minecraft:green_terracotta
fill 329 242 586 329 242 587 minecraft:green_terracotta
fill 329 242 592 329 242 593 minecraft:green_terracotta
setblock 329 242 596 minecraft:green_terracotta
setblock 329 242 598 minecraft:green_terracotta
fill 332 242 575 345 242 581 minecraft:oak_log
fill 338 242 557 339 242 557 minecraft:green_terracotta
setblock 338 242 599 minecraft:green_terracotta
setblock 340 242 599 minecraft:green_terracotta
setblock 342 242 599 minecraft:green_terracotta
setblock 344 242 599 minecraft:green_terracotta
setblock 345 242 557 minecraft:green_terracotta
fill 346 242 577 346 242 581 minecraft:oak_log
fill 347 242 577 349 242 580 minecraft:oak_log
fill 348 242 559 352 242 573 minecraft:oak_log
fill 348 242 584 354 242 597 minecraft:oak_log
fill 349 242 574 352 242 576 minecraft:oak_log
fill 350 242 580 353 242 583 minecraft:oak_log
fill 353 242 559 354 242 572 minecraft:oak_log
fill 353 242 576 370 242 579 minecraft:oak_log
setblock 354 242 583 minecraft:oak_log
fill 356 242 575 370 242 575 minecraft:oak_log
fill 356 242 599 356 243 599 minecraft:green_terracotta
fill 357 242 580 370 242 581 minecraft:oak_log
setblock 359 242 557 minecraft:green_terracotta
setblock 369 242 557 minecraft:green_terracotta
setblock 371 242 557 minecraft:green_terracotta
setblock 371 242 571 minecraft:green_terracotta
setblock 371 242 575 minecraft:green_terracotta
setblock 371 242 584 minecraft:green_terracotta
setblock 371 242 591 minecraft:green_terracotta
setblock 371 242 596 minecraft:green_terracotta
fill 329 243 557 329 244 565 minecraft:light_blue_concrete
setblock 329 243 566 minecraft:green_terracotta
fill 329 243 567 329 307 569 minecraft:light_blue_concrete
fill 329 243 571 329 243 585 minecraft:light_blue_concrete
setblock 329 243 586 minecraft:green_terracotta
fill 329 243 587 329 243 594 minecraft:light_blue_concrete
setblock 329 243 595 minecraft:green_terracotta
fill 329 243 596 329 307 599 minecraft:light_blue_concrete
fill 330 243 557 337 244 557 minecraft:light_blue_concrete
fill 330 243 558 331 243 598 minecraft:jungle_leaves[persistent=true]
fill 330 243 599 332 307 599 minecraft:light_blue_concrete
fill 332 243 558 344 243 574 minecraft:jungle_leaves[persistent=true]
fill 332 243 575 344 243 575 minecraft:moss_block
fill 332 243 576 344 243 580 minecraft:oak_log
fill 332 243 581 345 243 581 minecraft:moss_block
fill 332 243 582 345 243 598 minecraft:jungle_leaves[persistent=true]
setblock 333 243 599 minecraft:green_terracotta
fill 334 243 599 340 243 599 minecraft:light_blue_concrete
setblock 338 243 557 minecraft:green_terracotta
fill 339 243 557 342 243 557 minecraft:light_blue_concrete
fill 342 243 599 342 307 599 minecraft:light_blue_concrete
setblock 343 243 557 minecraft:green_terracotta
fill 344 243 557 348 307 557 minecraft:light_blue_concrete
fill 344 243 599 355 243 599 minecraft:light_blue_concrete
fill 345 243 558 347 243 572 minecraft:jungle_leaves[persistent=true]
fill 345 243 573 345 243 577 minecraft:ochre_froglight
fill 345 243 578 345 243 580 minecraft:oak_log
fill 346 243 573 349 243 573 minecraft:ochre_froglight
fill 346 243 574 348 243 576 minecraft:jungle_leaves[persistent=true]
fill 346 243 577 349 243 577 minecraft:ochre_froglight
fill 346 243 578 347 243 579 minecraft:oak_log
fill 346 243 580 346 243 584 minecraft:ochre_froglight
fill 346 243 585 347 243 598 minecraft:jungle_leaves[persistent=true]
fill 347 243 580 353 243 580 minecraft:ochre_froglight
fill 347 243 581 349 243 583 minecraft:jungle_leaves[persistent=true]
fill 347 243 584 350 243 584 minecraft:ochre_froglight
fill 348 243 558 370 243 558 minecraft:jungle_leaves[persistent=true]
fill 348 243 559 348 243 572 minecraft:moss_block
fill 348 243 578 348 243 579 minecraft:moss_block
fill 348 243 585 348 243 597 minecraft:moss_block
fill 348 243 598 370 243 598 minecraft:jungle_leaves[persistent=true]
fill 349 243 559 351 243 572 minecraft:oak_log
fill 349 243 574 349 243 576 minecraft:ochre_froglight
fill 349 243 578 349 243 579 minecraft:ochre_froglight
fill 349 243 585 353 243 597 minecraft:oak_log
fill 350 243 557 363 243 557 minecraft:light_blue_concrete
fill 350 243 573 351 243 574 minecraft:oak_log
fill 350 243 575 351 243 575 minecraft:moss_block
fill 350 243 576 356 243 576 minecraft:ochre_froglight
fill 350 243 581 350 243 583 minecraft:ochre_froglight
fill 351 243 581 352 243 581 minecraft:moss_block
fill 351 243 582 352 243 584 minecraft:oak_log
fill 352 243 559 353 243 571 minecraft:oak_log
fill 352 243 572 352 243 575 minecraft:ochre_froglight
fill 353 243 572 356 243 572 minecraft:ochre_froglight
fill 353 243 573 355 243 575 minecraft:jungle_leaves[persistent=true]
fill 353 243 577 353 243 579 minecraft:ochre_froglight
fill 353 243 581 353 243 583 minecraft:ochre_froglight
setblock 353 243 584 minecraft:oak_log
fill 354 243 559 354 243 571 minecraft:moss_block
fill 354 243 577 354 243 578 minecraft:moss_block
fill 354 243 579 357 243 579 minecraft:ochre_froglight
fill 354 243 580 356 243 582 minecraft:jungle_leaves[persistent=true]
fill 354 243 583 357 243 583 minecraft:ochre_froglight
fill 354 243 584 354 243 597 minecraft:moss_block
fill 355 243 559 370 243 571 minecraft:jungle_leaves[persistent=true]
fill 355 243 577 370 243 578 minecraft:oak_log
fill 355 243 584 370 243 597 minecraft:jungle_leaves[persistent=true]
fill 356 243 573 356 243 575 minecraft:ochre_froglight
fill 357 243 572 370 243 574 minecraft:jungle_leaves[persistent=true]
fill 357 243 575 370 243 575 minecraft:moss_block
fill 357 243 576 370 243 576 minecraft:oak_log
fill 357 243 580 357 243 582 minecraft:ochre_froglight
fill 357 243 599 358 307 599 minecraft:light_blue_concrete
fill 358 243 579 370 243 580 minecraft:oak_log
fill 358 243 581 370 243 581 minecraft:moss_block
fill 358 243 582 370 243 583 minecraft:jungle_leaves[persistent=true]
setblock 359 243 599 minecraft:green_terracotta
fill 360 243 599 361 243 599 minecraft:light_blue_concrete
setblock 362 243 599 minecraft:green_terracotta
fill 363 243 599 371 243 599 minecraft:light_blue_concrete
setblock 364 243 557 minecraft:green_terracotta
fill 365 243 557 371 307 557 minecraft:light_blue_concrete
fill 371 243 558 371 243 564 minecraft:light_blue_concrete
setblock 371 243 565 minecraft:green_terracotta
fill 371 243 567 371 243 573 minecraft:light_blue_concrete
fill 371 243 575 371 307 577 minecraft:light_blue_concrete
fill 371 243 579 371 243 598 minecraft:light_blue_concrete
fill 329 244 566 329 307 566 minecraft:light_blue_concrete
fill 329 244 570 329 307 573 minecraft:light_blue_concrete
setblock 329 244 574 minecraft:green_terracotta
fill 329 244 575 329 307 579 minecraft:light_blue_concrete
fill 329 244 580 329 244 581 minecraft:green_terracotta
fill 329 244 582 329 307 584 minecraft:light_blue_concrete
setblock 329 244 585 minecraft:green_terracotta
fill 329 244 586 329 307 590 minecraft:light_blue_concrete
setblock 329 244 591 minecraft:green_terracotta
fill 329 244 592 329 244 595 minecraft:light_blue_concrete
fill 333 244 599 335 307 599 minecraft:light_blue_concrete
setblock 336 244 599 minecraft:green_terracotta
fill 337 244 599 337 307 599 minecraft:light_blue_concrete
fill 338 244 557 338 307 557 minecraft:light_blue_concrete
fill 338 244 599 338 245 599 minecraft:green_terracotta
setblock 339 244 557 minecraft:green_terracotta
fill 339 244 599 341 307 599 minecraft:light_blue_concrete
fill 340 244 557 343 307 557 minecraft:light_blue_concrete
fill 343 244 599 347 307 599 minecraft:light_blue_concrete
setblock 348 244 599 minecraft:green_terracotta
fill 349 244 557 361 244 557 minecraft:light_blue_concrete
fill 349 244 599 356 244 599 minecraft:light_blue_concrete
setblock 359 244 599 minecraft:light_blue_concrete
fill 360 244 599 361 244 599 minecraft:green_terracotta
setblock 362 244 557 minecraft:green_terracotta
fill 362 244 599 364 307 599 minecraft:light_blue_concrete
fill 363 244 557 364 307 557 minecraft:light_blue_concrete
fill 365 244 599 366 244 599 minecraft:green_terracotta
fill 367 244 599 371 307 599 minecraft:light_blue_concrete
fill 371 244 558 371 307 558 minecraft:light_blue_concrete
setblock 371 244 559 minecraft:green_terracotta
fill 371 244 560 371 244 571 minecraft:light_blue_concrete
setblock 371 244 572 minecraft:green_terracotta
fill 371 244 573 371 307 573 minecraft:light_blue_concrete
fill 371 244 578 371 244 582 minecraft:light_blue_concrete
fill 371 244 583 371 245 583 minecraft:green_terracotta
fill 371 244 584 371 307 586 minecraft:light_blue_concrete
setblock 371 244 587 minecraft:green_terracotta
fill 371 244 588 371 307 588 minecraft:light_blue_concrete
setblock 371 244 589 minecraft:green_terracotta
fill 371 244 590 371 244 598 minecraft:light_blue_concrete
fill 329 245 557 329 307 559 minecraft:light_blue_concrete
setblock 329 245 560 minecraft:green_terracotta
fill 329 245 561 329 307 565 minecraft:light_blue_concrete
fill 329 245 574 329 307 574 minecraft:light_blue_concrete
setblock 329 245 580 minecraft:green_terracotta
fill 329 245 581 329 307 581 minecraft:light_blue_concrete
fill 329 245 585 329 307 585 minecraft:light_blue_concrete
fill 329 245 591 329 307 593 minecraft:light_blue_concrete
setblock 329 245 594 minecraft:green_terracotta
fill 329 245 595 329 307 595 minecraft:light_blue_concrete
fill 330 245 557 335 307 557 minecraft:light_blue_concrete
setblock 336 245 557 minecraft:green_terracotta
fill 336 245 599 336 307 599 minecraft:light_blue_concrete
fill 337 245 557 337 307 557 minecraft:light_blue_concrete
fill 339 245 557 339 307 557 minecraft:light_blue_concrete
fill 348 245 599 352 307 599 minecraft:light_blue_concrete
fill 349 245 557 352 307 557 minecraft:light_blue_concrete
setblock 353 245 557 minecraft:green_terracotta
setblock 353 245 599 minecraft:green_terracotta
fill 354 245 557 362 307 557 minecraft:light_blue_concrete
fill 354 245 599 355 307 599 minecraft:light_blue_concrete
setblock 356 245 599 minecraft:green_terracotta
fill 359 245 599 360 245 599 minecraft:green_terracotta
fill 361 245 599 361 307 599 minecraft:light_blue_concrete
fill 365 245 599 366 307 599 minecraft:light_blue_concrete
fill 371 245 559 371 307 566 minecraft:light_blue_concrete
setblock 371 245 567 minecraft:green_terracotta
fill 371 245 568 371 307 572 minecraft:light_blue_concrete
setblock 371 245 578 minecraft:green_terracotta
fill 371 245 579 371 307 582 minecraft:light_blue_concrete
fill 371 245 587 371 307 587 minecraft:light_blue_concrete
fill 371 245 589 371 307 590 minecraft:light_blue_concrete
setblock 371 245 591 minecraft:green_terracotta
fill 371 245 592 371 307 598 minecraft:light_blue_concrete
fill 329 246 560 329 307 560 minecraft:light_blue_concrete
fill 329 246 580 329 307 580 minecraft:light_blue_concrete
fill 329 246 594 329 307 594 minecraft:light_blue_concrete
fill 336 246 557 336 307 557 minecraft:light_blue_concrete
fill 338 246 599 338 307 599 minecraft:light_blue_concrete
fill 353 246 557 353 307 557 minecraft:light_blue_concrete
fill 353 246 599 353 307 599 minecraft:light_blue_concrete
fill 356 246 599 356 307 599 minecraft:light_blue_concrete
fill 359 246 599 360 307 599 minecraft:light_blue_concrete
fill 371 246 567 371 307 567 minecraft:light_blue_concrete
fill 371 246 574 371 307 574 minecraft:light_blue_concrete
fill 371 246 578 371 307 578 minecraft:light_blue_concrete
fill 371 246 583 371 307 583 minecraft:light_blue_concrete
fill 371 246 591 371 307 591 minecraft:light_blue_concrete
setblock 330 247 558 minecraft:oak_log
fill 330 247 559 330 247 562 minecraft:green_terracotta
setblock 330 247 563 minecraft:oak_log
fill 330 247 564 330 247 567 minecraft:green_terracotta
setblock 330 247 568 minecraft:oak_log
fill 330 247 569 330 247 572 minecraft:green_terracotta
setblock 330 247 573 minecraft:oak_log
fill 330 247 574 330 247 577 minecraft:green_terracotta
setblock 330 247 578 minecraft:oak_log
fill 330 247 579 330 248 581 minecraft:green_terracotta
setblock 330 247 587 minecraft:green_terracotta
setblock 330 247 588 minecraft:oak_log
fill 330 247 589 330 247 592 minecraft:green_terracotta
setblock 330 247 593 minecraft:oak_log
fill 330 247 594 330 247 597 minecraft:green_terracotta
setblock 330 247 598 minecraft:oak_log
fill 331 247 558 331 247 561 minecraft:green_terracotta
setblock 331 247 562 minecraft:oak_log
fill 331 247 563 331 247 566 minecraft:green_terracotta
setblock 331 247 567 minecraft:oak_log
fill 331 247 568 331 247 571 minecraft:green_terracotta
setblock 331 247 572 minecraft:oak_log
fill 331 247 573 331 247 576 minecraft:green_terracotta
setblock 331 247 577 minecraft:oak_log
fill 331 247 590 331 247 591 minecraft:green_terracotta
setblock 331 247 592 minecraft:oak_log
fill 331 247 593 331 247 596 minecraft:green_terracotta
setblock 331 247 597 minecraft:oak_log
fill 331 247 598 334 247 598 minecraft:green_terracotta
fill 332 247 558 333 247 559 minecraft:green_terracotta
setblock 332 247 571 minecraft:oak_log
setblock 332 247 572 minecraft:green_terracotta
fill 332 247 593 332 247 595 minecraft:green_terracotta
setblock 332 247 596 minecraft:oak_log
fill 332 247 597 335 247 597 minecraft:green_terracotta
fill 333 247 596 335 247 596 minecraft:green_terracotta
setblock 334 247 558 minecraft:green_terracotta
setblock 334 247 559 minecraft:oak_log
setblock 335 247 558 minecraft:oak_log
fill 335 247 564 335 251 564 minecraft:iron_block
setblock 335 247 598 minecraft:oak_log
fill 336 247 558 339 247 558 minecraft:green_terracotta
setblock 336 247 597 minecraft:oak_log
fill 336 247 598 339 247 598 minecraft:green_terracotta
fill 337 247 597 340 247 597 minecraft:green_terracotta
fill 339 247 596 341 247 596 minecraft:green_terracotta
setblock 340 247 558 minecraft:oak_log
setblock 340 247 598 minecraft:oak_log
fill 341 247 558 344 247 558 minecraft:green_terracotta
setblock 341 247 597 minecraft:oak_log
fill 341 247 598 344 247 598 minecraft:green_terracotta
setblock 342 247 596 minecraft:oak_log
fill 342 247 597 345 247 597 minecraft:green_terracotta
setblock 343 247 595 minecraft:oak_log
fill 343 247 596 346 247 596 minecraft:green_terracotta
fill 344 247 595 347 247 595 minecraft:green_terracotta
setblock 345 247 558 minecraft:oak_log
setblock 345 247 598 minecraft:oak_log
fill 346 247 558 349 247 558 minecraft:green_terracotta
fill 346 247 594 348 247 594 minecraft:green_terracotta
setblock 346 247 597 minecraft:oak_log
fill 346 247 598 349 247 598 minecraft:green_terracotta
setblock 347 247 596 minecraft:oak_log
fill 347 247 597 350 247 597 minecraft:green_terracotta
setblock 348 247 595 minecraft:oak_log
fill 348 247 596 351 247 596 minecraft:green_terracotta
setblock 349 247 594 minecraft:oak_log
fill 349 247 595 351 247 595 minecraft:green_terracotta
setblock 350 247 558 minecraft:oak_log
setblock 350 247 598 minecraft:oak_log
fill 351 247 558 352 247 558 minecraft:green_terracotta
setblock 351 247 597 minecraft:oak_log
fill 351 247 598 354 247 598 minecraft:green_terracotta
setblock 352 247 596 minecraft:oak_log
fill 352 247 597 355 247 597 minecraft:green_terracotta
setblock 353 247 596 minecraft:green_terracotta
setblock 355 247 598 minecraft:oak_log
fill 356 247 593 358 250 594 minecraft:dark_oak_log
fill 356 247 598 357 247 598 minecraft:green_terracotta
fill 357 247 592 358 250 592 minecraft:dark_oak_log
fill 361 247 598 364 247 598 minecraft:green_terracotta
fill 363 247 558 364 247 558 minecraft:green_terracotta
fill 364 247 597 365 247 597 minecraft:green_terracotta
setblock 365 247 558 minecraft:oak_log
setblock 365 247 598 minecraft:oak_log
fill 366 247 558 368 247 559 minecraft:green_terracotta
setblock 366 247 572 minecraft:oak_log
fill 366 247 573 368 247 574 minecraft:green_terracotta
setblock 366 247 597 minecraft:oak_log
fill 366 247 598 369 247 598 minecraft:green_terracotta
fill 367 247 568 367 247 570 minecraft:green_terracotta
setblock 367 247 571 minecraft:oak_log
fill 367 247 572 370 247 572 minecraft:green_terracotta
setblock 367 247 575 minecraft:green_terracotta
setblock 367 247 576 minecraft:oak_log
fill 367 247 577 370 247 577 minecraft:green_terracotta
setblock 367 247 596 minecraft:oak_log
fill 367 247 597 370 247 597 minecraft:green_terracotta
setblock 368 247 565 minecraft:oak_log
fill 368 247 566 368 247 569 minecraft:green_terracotta
setblock 368 247 570 minecraft:oak_log
fill 368 247 571 370 248 571 minecraft:green_terracotta
setblock 368 247 575 minecraft:oak_log
fill 368 247 576 370 248 576 minecraft:green_terracotta
fill 368 247 578 368 247 579 minecraft:green_terracotta
fill 368 247 593 368 247 594 minecraft:green_terracotta
setblock 368 247 595 minecraft:oak_log
fill 368 247 596 370 248 596 minecraft:green_terracotta
setblock 369 247 558 minecraft:green_terracotta
setblock 369 247 559 minecraft:oak_log
fill 369 247 560 369 247 563 minecraft:green_terracotta
setblock 369 247 564 minecraft:oak_log
fill 369 247 565 369 247 568 minecraft:green_terracotta
setblock 369 247 569 minecraft:oak_log
fill 369 247 570 370 249 570 minecraft:green_terracotta
setblock 369 247 573 minecraft:green_terracotta
setblock 369 247 574 minecraft:oak_log
fill 369 247 575 370 249 575 minecraft:green_terracotta
setblock 369 247 578 minecraft:green_terracotta
setblock 369 247 579 minecraft:oak_log
fill 369 247 580 370 247 582 minecraft:green_terracotta
setblock 369 247 589 minecraft:oak_log
fill 369 247 590 369 247 593 minecraft:green_terracotta
setblock 369 247 594 minecraft:oak_log
fill 369 247 595 370 249 595 minecraft:green_terracotta
setblock 370 247 558 minecraft:oak_log
fill 370 247 559 370 247 562 minecraft:green_terracotta
setblock 370 247 563 minecraft:oak_log
fill 370 247 564 370 247 567 minecraft:green_terracotta
setblock 370 247 568 minecraft:oak_log
fill 370 247 569 370 250 569 minecraft:green_terracotta
setblock 370 247 573 minecraft:oak_log
fill 370 247 574 370 250 574 minecraft:green_terracotta
setblock 370 247 578 minecraft:oak_log
fill 370 247 579 370 250 579 minecraft:green_terracotta
setblock 370 247 583 minecraft:oak_log
fill 370 247 584 370 247 587 minecraft:green_terracotta
setblock 370 247 588 minecraft:oak_log
fill 370 247 589 370 247 592 minecraft:green_terracotta
setblock 370 247 593 minecraft:oak_log
fill 370 247 594 370 250 594 minecraft:green_terracotta
setblock 370 247 598 minecraft:oak_log
fill 330 248 558 330 248 561 minecraft:green_terracotta
setblock 330 248 562 minecraft:oak_log
fill 330 248 563 330 248 566 minecraft:green_terracotta
setblock 330 248 567 minecraft:oak_log
fill 330 248 568 330 248 571 minecraft:green_terracotta
setblock 330 248 572 minecraft:oak_log
fill 330 248 573 330 248 576 minecraft:green_terracotta
setblock 330 248 577 minecraft:oak_log
fill 330 248 578 330 251 578 minecraft:green_terracotta
setblock 330 248 582 minecraft:oak_leaves[persistent=true]
fill 330 248 588 330 248 591 minecraft:green_terracotta
setblock 330 248 592 minecraft:oak_log
fill 330 248 593 330 248 596 minecraft:green_terracotta
setblock 330 248 597 minecraft:oak_log
fill 330 248 598 333 248 598 minecraft:green_terracotta
fill 331 248 558 331 248 560 minecraft:green_terracotta
setblock 331 248 561 minecraft:oak_log
fill 331 248 562 331 248 565 minecraft:green_terracotta
setblock 331 248 566 minecraft:oak_log
fill 331 248 567 331 248 570 minecraft:green_terracotta
setblock 331 248 571 minecraft:oak_log
fill 331 248 572 331 248 575 minecraft:green_terracotta
setblock 331 248 576 minecraft:oak_log
setblock 331 248 577 minecraft:green_terracotta
setblock 331 248 591 minecraft:oak_log
fill 331 248 592 331 248 595 minecraft:green_terracotta
setblock 331 248 596 minecraft:oak_log
fill 331 248 597 334 248 597 minecraft:green_terracotta
fill 332 248 558 332 248 559 minecraft:green_terracotta
setblock 332 248 560 minecraft:light[level=14]
setblock 332 248 568 minecraft:light[level=14]
setblock 332 248 576 minecraft:light[level=14]
setblock 332 248 584 minecraft:light[level=14]
setblock 332 248 592 minecraft:light[level=14]
setblock 332 248 594 minecraft:green_terracotta
setblock 332 248 595 minecraft:oak_log
fill 332 248 596 334 248 596 minecraft:green_terracotta
setblock 333 248 558 minecraft:green_terracotta
setblock 333 248 559 minecraft:oak_log
setblock 334 248 558 minecraft:oak_log
setblock 334 248 598 minecraft:oak_log
fill 335 248 558 338 248 558 minecraft:green_terracotta
setblock 335 248 597 minecraft:oak_log
fill 335 248 598 338 248 598 minecraft:green_terracotta
fill 336 248 597 339 248 597 minecraft:green_terracotta
setblock 339 248 558 minecraft:oak_log
fill 339 248 596 340 248 596 minecraft:green_terracotta
setblock 339 248 598 minecraft:oak_log
fill 340 248 558 343 248 558 minecraft:green_terracotta
setblock 340 248 560 minecraft:light[level=14]
setblock 340 248 568 minecraft:light[level=14]
setblock 340 248 576 minecraft:light[level=14]
setblock 340 248 584 minecraft:light[level=14]
setblock 340 248 592 minecraft:light[level=14]
setblock 340 248 597 minecraft:oak_log
fill 340 248 598 343 248 598 minecraft:green_terracotta
setblock 341 248 596 minecraft:oak_log
fill 341 248 597 344 248 597 minecraft:green_terracotta
fill 342 248 596 345 248 596 minecraft:green_terracotta
fill 343 248 595 346 248 595 minecraft:green_terracotta
setblock 344 248 558 minecraft:oak_log
setblock 344 248 598 minecraft:oak_log
fill 345 248 558 348 248 558 minecraft:green_terracotta
setblock 345 248 597 minecraft:oak_log
fill 345 248 598 348 248 598 minecraft:green_terracotta
setblock 346 248 596 minecraft:oak_log
fill 346 248 597 349 248 597 minecraft:green_terracotta
setblock 347 248 595 minecraft:oak_log
fill 347 248 596 350 248 596 minecraft:green_terracotta
setblock 348 248 560 minecraft:light[level=14]
setblock 348 248 568 minecraft:light[level=14]
setblock 348 248 576 minecraft:light[level=14]
setblock 348 248 584 minecraft:light[level=14]
setblock 348 248 592 minecraft:light[level=14]
fill 348 248 595 350 248 595 minecraft:green_terracotta
setblock 349 248 558 minecraft:oak_log
setblock 349 248 598 minecraft:oak_log
fill 350 248 558 351 249 558 minecraft:green_terracotta
setblock 350 248 597 minecraft:oak_log
fill 350 248 598 353 248 598 minecraft:green_terracotta
setblock 351 248 596 minecraft:oak_log
fill 351 248 597 354 248 597 minecraft:green_terracotta
setblock 352 248 596 minecraft:green_terracotta
setblock 354 248 598 minecraft:oak_log
fill 355 248 598 356 248 598 minecraft:green_terracotta
setblock 356 248 560 minecraft:light[level=14]
setblock 356 248 568 minecraft:light[level=14]
setblock 356 248 576 minecraft:light[level=14]
setblock 356 248 584 minecraft:light[level=14]
fill 356 248 592 356 250 592 minecraft:dark_oak_log
fill 356 248 595 358 250 595 minecraft:dark_oak_log
setblock 358 248 598 minecraft:oak_leaves[persistent=true]
fill 359 248 593 359 250 594 minecraft:dark_oak_log
setblock 361 248 558 minecraft:oak_leaves[persistent=true]
fill 361 248 598 363 248 598 minecraft:green_terracotta
setblock 363 248 558 minecraft:green_terracotta
setblock 364 248 558 minecraft:oak_log
setblock 364 248 560 minecraft:light[level=14]
setblock 364 248 568 minecraft:light[level=14]
setblock 364 248 576 minecraft:light[level=14]
setblock 364 248 584 minecraft:light[level=14]
setblock 364 248 592 minecraft:light[level=14]
setblock 364 248 597 minecraft:green_terracotta
setblock 364 248 598 minecraft:oak_log
fill 365 248 558 367 248 559 minecraft:green_terracotta
setblock 365 248 597 minecraft:oak_log
fill 365 248 598 368 248 598 minecraft:green_terracotta
fill 366 248 573 368 248 573 minecraft:green_terracotta
fill 366 248 597 369 248 597 minecraft:green_terracotta
setblock 367 248 569 minecraft:green_terracotta
setblock 367 248 570 minecraft:oak_log
fill 367 248 571 367 249 572 minecraft:green_terracotta
setblock 367 248 574 minecraft:green_terracotta
setblock 367 248 575 minecraft:oak_log
fill 367 248 576 367 250 577 minecraft:green_terracotta
setblock 367 248 596 minecraft:green_terracotta
setblock 368 248 558 minecraft:green_terracotta
setblock 368 248 559 minecraft:oak_log
fill 368 248 565 368 248 568 minecraft:green_terracotta
setblock 368 248 569 minecraft:oak_log
fill 368 248 570 368 250 570 minecraft:green_terracotta
fill 368 248 572 369 248 572 minecraft:green_terracotta
setblock 368 248 574 minecraft:oak_log
fill 368 248 575 368 251 575 minecraft:green_terracotta
fill 368 248 577 368 248 578 minecraft:green_terracotta
setblock 368 248 579 minecraft:oak_log
setblock 368 248 595 minecraft:green_terracotta
setblock 369 248 558 minecraft:oak_log
fill 369 248 559 369 248 562 minecraft:green_terracotta
setblock 369 248 563 minecraft:oak_log
fill 369 248 564 369 248 567 minecraft:green_terracotta
setblock 369 248 568 minecraft:oak_log
fill 369 248 569 369 251 569 minecraft:green_terracotta
setblock 369 248 573 minecraft:oak_log
fill 369 248 574 369 251 574 minecraft:green_terracotta
setblock 369 248 577 minecraft:green_terracotta
setblock 369 248 578 minecraft:oak_log
fill 369 248 579 369 249 581 minecraft:green_terracotta
fill 369 248 591 369 248 592 minecraft:green_terracotta
setblock 369 248 593 minecraft:oak_log
fill 369 248 594 369 249 594 minecraft:green_terracotta
setblock 369 248 598 minecraft:oak_log
fill 370 248 558 370 248 561 minecraft:green_terracotta
setblock 370 248 562 minecraft:oak_log
fill 370 248 563 370 248 566 minecraft:green_terracotta
setblock 370 248 567 minecraft:oak_log
fill 370 248 568 370 251 568 minecraft:green_terracotta
setblock 370 248 572 minecraft:oak_log
fill 370 248 573 370 251 573 minecraft:green_terracotta
setblock 370 248 577 minecraft:oak_log
fill 370 248 578 370 251 578 minecraft:green_terracotta
fill 370 248 580 370 248 581 minecraft:green_terracotta
setblock 370 248 582 minecraft:oak_log
fill 370 248 583 370 248 584 minecraft:green_terracotta
fill 370 248 588 370 248 591 minecraft:green_terracotta
setblock 370 248 592 minecraft:oak_log
fill 370 248 593 370 250 593 minecraft:green_terracotta
setblock 370 248 597 minecraft:oak_log
fill 370 248 598 370 251 598 minecraft:green_terracotta
fill 330 249 558 330 249 560 minecraft:green_terracotta
setblock 330 249 561 minecraft:oak_log
fill 330 249 562 330 249 565 minecraft:green_terracotta
setblock 330 249 566 minecraft:oak_log
fill 330 249 567 330 249 570 minecraft:green_terracotta
setblock 330 249 571 minecraft:oak_log
fill 330 249 572 330 249 575 minecraft:green_terracotta
setblock 330 249 576 minecraft:oak_log
fill 330 249 577 330 252 577 minecraft:green_terracotta
fill 330 249 579 330 249 580 minecraft:green_terracotta
setblock 330 249 588 minecraft:oak_leaves[persistent=true]
setblock 330 249 590 minecraft:green_terracotta
setblock 330 249 591 minecraft:oak_log
fill 330 249 592 330 249 595 minecraft:green_terracotta
setblock 330 249 596 minecraft:oak_log
fill 330 249 597 332 249 598 minecraft:green_terracotta
fill 331 249 558 331 249 559 minecraft:green_terracotta
setblock 331 249 560 minecraft:oak_log
setblock 331 249 561 minecraft:green_terracotta
setblock 331 249 570 minecraft:oak_log
fill 331 249 571 331 249 574 minecraft:green_terracotta
setblock 331 249 575 minecraft:oak_log
setblock 331 249 576 minecraft:green_terracotta
fill 331 249 592 331 249 594 minecraft:green_terracotta
setblock 331 249 595 minecraft:oak_log
fill 331 249 596 332 249 596 minecraft:green_terracotta
setblock 332 249 558 minecraft:green_terracotta
setblock 332 249 559 minecraft:oak_log
setblock 333 249 558 minecraft:oak_log
setblock 333 249 559 minecraft:green_terracotta
setblock 333 249 597 minecraft:green_terracotta
setblock 333 249 598 minecraft:oak_log
fill 334 249 558 337 249 558 minecraft:green_terracotta
setblock 334 249 597 minecraft:oak_log
fill 334 249 598 337 249 598 minecraft:green_terracotta
fill 335 249 597 338 249 597 minecraft:green_terracotta
setblock 338 249 558 minecraft:oak_log
setblock 338 249 598 minecraft:oak_log
fill 339 249 558 342 249 558 minecraft:green_terracotta
setblock 339 249 596 minecraft:green_terracotta
setblock 339 249 597 minecraft:oak_log
fill 339 249 598 342 249 598 minecraft:green_terracotta
setblock 340 249 596 minecraft:oak_log
fill 340 249 597 343 249 597 minecraft:green_terracotta
fill 341 249 596 344 249 596 minecraft:green_terracotta
setblock 343 249 558 minecraft:oak_log
fill 343 249 595 345 249 595 minecraft:green_terracotta
setblock 343 249 598 minecraft:oak_log
fill 344 249 558 347 249 558 minecraft:green_terracotta
setblock 344 249 597 minecraft:oak_log
fill 344 249 598 347 249 598 minecraft:green_terracotta
setblock 345 249 596 minecraft:oak_log
fill 345 249 597 348 249 597 minecraft:green_terracotta
setblock 346 249 595 minecraft:oak_log
fill 346 249 596 349 249 596 minecraft:green_terracotta
fill 347 249 595 349 249 595 minecraft:green_terracotta
setblock 348 249 558 minecraft:oak_log
setblock 348 249 598 minecraft:oak_log
fill 349 249 558 349 252 558 minecraft:green_terracotta
setblock 349 249 597 minecraft:oak_log
fill 349 249 598 352 249 598 minecraft:green_terracotta
setblock 350 249 596 minecraft:oak_log
fill 350 249 597 353 249 597 minecraft:green_terracotta
setblock 351 249 596 minecraft:green_terracotta
setblock 353 249 598 minecraft:oak_log
fill 354 249 598 355 249 598 minecraft:green_terracotta
setblock 355 249 558 minecraft:oak_leaves[persistent=true]
fill 355 249 592 355 250 594 minecraft:dark_oak_log
fill 356 249 591 358 250 591 minecraft:dark_oak_log
fill 359 249 592 359 250 592 minecraft:dark_oak_log
fill 359 249 595 359 250 595 minecraft:dark_oak_log
fill 361 249 598 362 249 598 minecraft:green_terracotta
setblock 362 249 558 minecraft:green_terracotta
setblock 363 249 558 minecraft:oak_log
setblock 363 249 598 minecraft:oak_log
fill 364 249 558 367 249 558 minecraft:green_terracotta
setblock 364 249 597 minecraft:oak_log
fill 364 249 598 367 249 598 minecraft:green_terracotta
fill 365 249 559 366 249 559 minecraft:green_terracotta
fill 365 249 597 368 249 597 minecraft:green_terracotta
setblock 367 249 559 minecraft:oak_log
setblock 367 249 570 minecraft:green_terracotta
setblock 367 249 573 minecraft:green_terracotta
setblock 367 249 574 minecraft:oak_log
fill 367 249 575 367 251 575 minecraft:green_terracotta
setblock 368 249 558 minecraft:oak_log
fill 368 249 559 370 250 559 minecraft:green_terracotta
setblock 368 249 567 minecraft:green_terracotta
setblock 368 249 568 minecraft:oak_log
fill 368 249 569 368 250 569 minecraft:green_terracotta
fill 368 249 571 368 249 572 minecraft:green_terracotta
setblock 368 249 573 minecraft:oak_log
fill 368 249 574 368 252 574 minecraft:green_terracotta
fill 368 249 576 368 249 577 minecraft:green_terracotta
setblock 368 249 578 minecraft:oak_log
fill 368 249 579 368 250 579 minecraft:green_terracotta
setblock 368 249 598 minecraft:oak_log
fill 369 249 558 370 251 558 minecraft:green_terracotta
fill 369 249 560 369 249 561 minecraft:green_terracotta
setblock 369 249 562 minecraft:oak_log
fill 369 249 563 369 249 566 minecraft:green_terracotta
setblock 369 249 567 minecraft:oak_log
fill 369 249 568 369 251 568 minecraft:green_terracotta
setblock 369 249 571 minecraft:green_terracotta
setblock 369 249 572 minecraft:oak_log
fill 369 249 573 369 252 573 minecraft:green_terracotta
setblock 369 249 576 minecraft:green_terracotta
setblock 369 249 577 minecraft:oak_log
fill 369 249 578 369 252 578 minecraft:green_terracotta
setblock 369 249 593 minecraft:green_terracotta
setblock 369 249 596 minecraft:green_terracotta
setblock 369 249 597 minecraft:oak_log
fill 369 249 598 369 252 598 minecraft:green_terracotta
setblock 370 249 560 minecraft:green_terracotta
setblock 370 249 561 minecraft:oak_log
fill 370 249 562 370 249 565 minecraft:green_terracotta
setblock 370 249 566 minecraft:oak_log
fill 370 249 567 370 252 567 minecraft:green_terracotta
setblock 370 249 571 minecraft:oak_log
fill 370 249 572 370 252 572 minecraft:green_terracotta
setblock 370 249 576 minecraft:oak_log
fill 370 249 577 370 252 577 minecraft:green_terracotta
setblock 370 249 580 minecraft:green_terracotta
setblock 370 249 581 minecraft:oak_log
fill 370 249 582 370 250 582 minecraft:green_terracotta
setblock 370 249 587 minecraft:oak_leaves[persistent=true]
setblock 370 249 590 minecraft:green_terracotta
setblock 370 249 591 minecraft:oak_log
fill 370 249 592 370 250 592 minecraft:green_terracotta
setblock 370 249 596 minecraft:oak_log
fill 370 249 597 370 252 597 minecraft:green_terracotta
fill 330 250 558 330 250 559 minecraft:green_terracotta
setblock 330 250 560 minecraft:oak_log
fill 330 250 561 330 250 564 minecraft:green_terracotta
setblock 330 250 565 minecraft:oak_log
fill 330 250 566 330 250 569 minecraft:green_terracotta
setblock 330 250 570 minecraft:oak_log
fill 330 250 571 330 250 574 minecraft:green_terracotta
setblock 330 250 575 minecraft:oak_log
fill 330 250 576 330 252 576 minecraft:green_terracotta
setblock 330 250 579 minecraft:green_terracotta
fill 330 250 591 330 250 594 minecraft:green_terracotta
setblock 330 250 595 minecraft:oak_log
fill 330 250 596 331 250 598 minecraft:green_terracotta
setblock 331 250 558 minecraft:green_terracotta
setblock 331 250 559 minecraft:oak_log
setblock 331 250 560 minecraft:green_terracotta
setblock 331 250 594 minecraft:oak_log
fill 331 250 595 331 251 595 minecraft:green_terracotta
setblock 332 250 558 minecraft:oak_log
setblock 332 250 559 minecraft:green_terracotta
fill 332 250 564 334 273 566 minecraft:oak_log
setblock 332 250 597 minecraft:green_terracotta
setblock 332 250 598 minecraft:oak_log
fill 333 250 558 336 250 558 minecraft:green_terracotta
setblock 333 250 597 minecraft:oak_log
fill 333 250 598 336 250 598 minecraft:green_terracotta
fill 334 250 597 337 250 597 minecraft:green_terracotta
setblock 337 250 558 minecraft:oak_log
setblock 337 250 598 minecraft:oak_log
fill 338 250 558 341 250 558 minecraft:green_terracotta
setblock 338 250 597 minecraft:oak_log
fill 338 250 598 341 250 598 minecraft:green_terracotta
fill 339 250 597 342 250 597 minecraft:green_terracotta
fill 340 250 596 343 250 596 minecraft:green_terracotta
setblock 342 250 558 minecraft:oak_log
setblock 342 250 598 minecraft:oak_log
fill 343 250 558 346 250 558 minecraft:green_terracotta
fill 343 250 595 344 250 595 minecraft:green_terracotta
setblock 343 250 597 minecraft:oak_log
fill 343 250 598 346 250 598 minecraft:green_terracotta
setblock 344 250 596 minecraft:oak_log
fill 344 250 597 347 250 597 minecraft:green_terracotta
setblock 345 250 595 minecraft:oak_log
fill 345 250 596 348 250 596 minecraft:green_terracotta
fill 346 250 595 347 250 595 minecraft:green_terracotta
setblock 347 250 558 minecraft:oak_log
setblock 347 250 598 minecraft:oak_log
fill 348 250 558 348 253 558 minecraft:green_terracotta
setblock 348 250 597 minecraft:oak_log
fill 348 250 598 351 250 598 minecraft:green_terracotta
fill 349 250 583 352 273 584 minecraft:oak_log
setblock 349 250 596 minecraft:oak_log
fill 349 250 597 352 250 597 minecraft:green_terracotta
fill 350 250 558 350 251 558 minecraft:green_terracotta
fill 350 250 582 351 256 582 minecraft:oak_log
setblock 350 250 596 minecraft:green_terracotta
setblock 352 250 598 minecraft:oak_log
fill 353 250 598 354 250 598 minecraft:green_terracotta
setblock 355 250 595 minecraft:dark_oak_log
fill 356 250 596 358 250 596 minecraft:dark_oak_log
setblock 359 250 591 minecraft:dark_oak_log
fill 360 250 593 360 250 594 minecraft:dark_oak_log
setblock 361 250 598 minecraft:green_terracotta
setblock 362 250 558 minecraft:oak_log
setblock 362 250 598 minecraft:oak_log
fill 363 250 558 366 250 558 minecraft:green_terracotta
fill 363 250 598 366 250 598 minecraft:green_terracotta
fill 364 250 559 365 250 559 minecraft:green_terracotta
fill 364 250 597 367 250 597 minecraft:green_terracotta
setblock 366 250 559 minecraft:oak_log
setblock 367 250 558 minecraft:oak_log
fill 367 250 559 367 253 559 minecraft:green_terracotta
setblock 367 250 572 minecraft:green_terracotta
setblock 367 250 573 minecraft:oak_log
fill 367 250 574 367 251 574 minecraft:green_terracotta
setblock 367 250 598 minecraft:oak_log
fill 368 250 558 368 253 558 minecraft:green_terracotta
setblock 368 250 571 minecraft:green_terracotta
setblock 368 250 572 minecraft:oak_log
fill 368 250 573 368 252 573 minecraft:green_terracotta
setblock 368 250 576 minecraft:green_terracotta
setblock 368 250 577 minecraft:oak_log
fill 368 250 578 368 251 578 minecraft:green_terracotta
setblock 368 250 597 minecraft:oak_log
fill 368 250 598 368 253 598 minecraft:green_terracotta
setblock 369 250 560 minecraft:green_terracotta
setblock 369 250 561 minecraft:oak_log
fill 369 250 562 369 250 565 minecraft:green_terracotta
setblock 369 250 566 minecraft:oak_log
fill 369 250 567 369 251 567 minecraft:green_terracotta
setblock 369 250 570 minecraft:green_terracotta
setblock 369 250 571 minecraft:oak_log
fill 369 250 572 369 253 572 minecraft:green_terracotta
setblock 369 250 575 minecraft:green_terracotta
setblock 369 250 576 minecraft:oak_log
fill 369 250 577 369 253 577 minecraft:green_terracotta
fill 369 250 579 369 250 580 minecraft:green_terracotta
setblock 369 250 595 minecraft:green_terracotta
setblock 369 250 596 minecraft:oak_log
fill 369 250 597 369 251 597 minecraft:green_terracotta
setblock 370 250 560 minecraft:oak_log
fill 370 250 561 370 250 564 minecraft:green_terracotta
setblock 370 250 565 minecraft:oak_log
fill 370 250 566 370 253 566 minecraft:green_terracotta
setblock 370 250 570 minecraft:oak_log
fill 370 250 571 370 253 571 minecraft:green_terracotta
setblock 370 250 575 minecraft:oak_log
fill 370 250 576 370 253 576 minecraft:green_terracotta
setblock 370 250 580 minecraft:oak_log
fill 370 250 581 370 252 581 minecraft:green_terracotta
setblock 370 250 595 minecraft:oak_log
fill 370 250 596 370 253 596 minecraft:green_terracotta
setblock 330 251 558 minecraft:green_terracotta
setblock 330 251 559 minecraft:oak_log
fill 330 251 560 330 251 563 minecraft:green_terracotta
setblock 330 251 564 minecraft:oak_log
fill 330 251 570 330 251 573 minecraft:green_terracotta
setblock 330 251 574 minecraft:oak_log
fill 330 251 575 330 252 575 minecraft:green_terracotta
setblock 330 251 579 minecraft:oak_log
setblock 330 251 581 minecraft:oak_leaves[persistent=true]
fill 330 251 592 330 251 593 minecraft:green_terracotta
setblock 330 251 594 minecraft:oak_log
fill 330 251 595 330 251 598 minecraft:green_terracotta
setblock 331 251 558 minecraft:oak_log
fill 331 251 559 331 254 559 minecraft:green_terracotta
fill 331 251 564 331 252 566 minecraft:dark_oak_log
fill 331 251 596 331 251 597 minecraft:green_terracotta
setblock 331 251 598 minecraft:oak_log
fill 332 251 558 335 251 558 minecraft:green_terracotta
fill 332 251 563 333 252 563 minecraft:dark_oak_log
fill 332 251 567 334 252 567 minecraft:dark_oak_log
setblock 332 251 597 minecraft:oak_log
fill 332 251 598 335 251 598 minecraft:green_terracotta
fill 333 251 597 336 251 597 minecraft:green_terracotta
fill 335 251 565 335 252 566 minecraft:dark_oak_log
setblock 336 251 558 minecraft:oak_log
setblock 336 251 598 minecraft:oak_log
fill 337 251 558 340 251 558 minecraft:green_terracotta
setblock 337 251 597 minecraft:oak_log
fill 337 251 598 340 251 598 minecraft:green_terracotta
fill 338 251 597 341 251 597 minecraft:green_terracotta
fill 340 251 596 342 251 596 minecraft:green_terracotta
setblock 341 251 558 minecraft:oak_log
setblock 341 251 598 minecraft:oak_log
fill 342 251 558 345 251 558 minecraft:green_terracotta
setblock 342 251 597 minecraft:oak_log
fill 342 251 598 345 251 598 minecraft:green_terracotta
setblock 343 251 596 minecraft:oak_log
fill 343 251 597 346 251 597 minecraft:green_terracotta
fill 344 251 596 347 251 596 minecraft:green_terracotta
setblock 346 251 558 minecraft:oak_log
setblock 346 251 598 minecraft:oak_log
fill 347 251 558 347 254 558 minecraft:green_terracotta
setblock 347 251 597 minecraft:oak_log
fill 347 251 598 350 251 598 minecraft:green_terracotta
fill 348 251 583 348 252 583 minecraft:dark_oak_log
setblock 348 251 596 minecraft:oak_log
fill 348 251 597 351 251 597 minecraft:green_terracotta
fill 349 251 582 349 252 582 minecraft:dark_oak_log
fill 349 251 585 352 252 585 minecraft:dark_oak_log
setblock 349 251 596 minecraft:green_terracotta
setblock 351 251 598 minecraft:oak_log
fill 352 251 582 352 252 582 minecraft:dark_oak_log
fill 352 251 598 353 251 598 minecraft:green_terracotta
fill 357 251 593 357 252 593 minecraft:oak_log
setblock 357 251 598 minecraft:oak_leaves[persistent=true]
setblock 361 251 558 minecraft:oak_log
setblock 361 251 598 minecraft:oak_log
fill 362 251 558 365 251 558 minecraft:green_terracotta
fill 362 251 598 365 251 598 minecraft:green_terracotta
setblock 364 251 559 minecraft:green_terracotta
fill 364 251 597 366 251 597 minecraft:green_terracotta
setblock 365 251 559 minecraft:oak_log
setblock 366 251 558 minecraft:oak_log
fill 366 251 559 366 254 559 minecraft:green_terracotta
setblock 366 251 598 minecraft:oak_log
fill 367 251 558 367 254 558 minecraft:green_terracotta
setblock 367 251 597 minecraft:oak_log
fill 367 251 598 367 254 598 minecraft:green_terracotta
fill 368 251 559 369 251 559 minecraft:green_terracotta
setblock 368 251 571 minecraft:oak_log
setblock 368 251 572 minecraft:green_terracotta
setblock 368 251 576 minecraft:oak_log
fill 368 251 577 368 252 577 minecraft:green_terracotta
fill 368 251 597 368 252 597 minecraft:green_terracotta
setblock 369 251 560 minecraft:oak_log
fill 369 251 561 370 251 563 minecraft:green_terracotta
setblock 369 251 570 minecraft:oak_log
fill 369 251 571 369 252 571 minecraft:green_terracotta
setblock 369 251 575 minecraft:oak_log
fill 369 251 576 369 254 576 minecraft:green_terracotta
setblock 369 251 579 minecraft:green_terracotta
setblock 369 251 580 minecraft:oak_log
setblock 369 251 596 minecraft:green_terracotta
setblock 370 251 559 minecraft:oak_log
fill 370 251 560 370 254 560 minecraft:green_terracotta
setblock 370 251 564 minecraft:oak_log
fill 370 251 565 370 254 565 minecraft:green_terracotta
setblock 370 251 569 minecraft:oak_log
fill 370 251 570 370 253 570 minecraft:green_terracotta
setblock 370 251 574 minecraft:oak_log
fill 370 251 575 370 254 575 minecraft:green_terracotta
setblock 370 251 579 minecraft:oak_log
fill 370 251 580 370 254 580 minecraft:green_terracotta
setblock 370 251 594 minecraft:oak_log
fill 370 251 595 370 252 595 minecraft:green_terracotta
setblock 330 252 558 minecraft:oak_log
fill 330 252 559 330 252 562 minecraft:green_terracotta
setblock 330 252 563 minecraft:oak_log
fill 330 252 564 330 252 566 minecraft:dark_oak_log
setblock 330 252 574 minecraft:green_terracotta
setblock 330 252 578 minecraft:oak_log
setblock 330 252 587 minecraft:oak_leaves[persistent=true]
setblock 330 252 593 minecraft:oak_log
fill 330 252 594 330 252 597 minecraft:green_terracotta
setblock 330 252 598 minecraft:oak_log
fill 331 252 558 334 252 558 minecraft:green_terracotta
setblock 331 252 563 minecraft:dark_oak_log
setblock 331 252 567 minecraft:dark_oak_log
setblock 331 252 596 minecraft:green_terracotta
setblock 331 252 597 minecraft:oak_log
fill 331 252 598 334 252 598 minecraft:green_terracotta
fill 332 252 568 333 252 568 minecraft:dark_oak_log
fill 332 252 597 335 252 597 minecraft:green_terracotta
fill 334 252 563 335 252 563 minecraft:dark_oak_log
setblock 335 252 558 minecraft:oak_log
setblock 335 252 564 minecraft:dark_oak_log
setblock 335 252 567 minecraft:dark_oak_log
setblock 335 252 598 minecraft:oak_log
fill 336 252 558 339 252 558 minecraft:green_terracotta
setblock 336 252 597 minecraft:oak_log
fill 336 252 598 339 252 598 minecraft:green_terracotta
fill 337 252 597 340 252 597 minecraft:green_terracotta
setblock 340 252 558 minecraft:oak_log
setblock 340 252 598 minecraft:oak_log
fill 341 252 558 344 252 558 minecraft:green_terracotta
setblock 341 252 596 minecraft:green_terracotta
setblock 341 252 597 minecraft:oak_log
fill 341 252 598 344 252 598 minecraft:green_terracotta
setblock 342 252 596 minecraft:oak_log
fill 342 252 597 345 252 597 minecraft:green_terracotta
fill 343 252 596 346 252 596 minecraft:green_terracotta
setblock 345 252 558 minecraft:oak_log
setblock 345 252 598 minecraft:oak_log
fill 346 252 558 346 255 558 minecraft:green_terracotta
setblock 346 252 597 minecraft:oak_log
fill 346 252 598 349 252 598 minecraft:green_terracotta
setblock 347 252 596 minecraft:oak_log
fill 347 252 597 350 252 597 minecraft:green_terracotta
setblock 348 252 582 minecraft:dark_oak_log
fill 348 252 584 348 252 585 minecraft:dark_oak_log
setblock 348 252 596 minecraft:green_terracotta
setblock 349 252 581 minecraft:dark_oak_log
fill 349 252 586 352 252 586 minecraft:dark_oak_log
setblock 350 252 598 minecraft:oak_log
fill 351 252 598 352 252 598 minecraft:green_terracotta
fill 353 252 582 353 252 585 minecraft:dark_oak_log
fill 357 252 591 360 273 592 minecraft:oak_log
fill 358 252 590 359 273 590 minecraft:oak_log
fill 358 252 593 359 273 593 minecraft:oak_log
setblock 360 252 558 minecraft:oak_log
fill 361 252 558 364 252 558 minecraft:green_terracotta
fill 361 252 598 364 252 598 minecraft:green_terracotta
setblock 363 252 559 minecraft:green_terracotta
setblock 364 252 559 minecraft:oak_log
fill 364 252 597 365 252 597 minecraft:green_terracotta
setblock 365 252 558 minecraft:oak_log
fill 365 252 559 365 255 559 minecraft:green_terracotta
setblock 365 252 598 minecraft:oak_log
fill 366 252 558 366 255 558 minecraft:green_terracotta
setblock 366 252 597 minecraft:oak_log
fill 366 252 598 366 255 598 minecraft:green_terracotta
fill 367 252 597 367 253 597 minecraft:green_terracotta
setblock 368 252 559 minecraft:green_terracotta
setblock 368 252 575 minecraft:oak_log
setblock 368 252 576 minecraft:green_terracotta
setblock 369 252 558 minecraft:green_terracotta
setblock 369 252 559 minecraft:oak_log
fill 369 252 560 369 253 562 minecraft:green_terracotta
setblock 369 252 570 minecraft:green_terracotta
setblock 369 252 574 minecraft:oak_log
fill 369 252 575 369 254 575 minecraft:green_terracotta
setblock 369 252 579 minecraft:oak_log
setblock 370 252 558 minecraft:oak_log
fill 370 252 559 370 255 559 minecraft:green_terracotta
fill 370 252 561 370 252 562 minecraft:green_terracotta
setblock 370 252 563 minecraft:oak_log
fill 370 252 564 370 255 564 minecraft:green_terracotta
setblock 370 252 568 minecraft:oak_log
fill 370 252 569 370 253 569 minecraft:green_terracotta
setblock 370 252 573 minecraft:oak_log
fill 370 252 574 370 255 574 minecraft:green_terracotta
setblock 370 252 578 minecraft:oak_log
fill 370 252 579 370 255 579 minecraft:green_terracotta
setblock 370 252 594 minecraft:oak_leaves[persistent=true]
setblock 370 252 598 minecraft:oak_log
fill 330 253 558 330 253 561 minecraft:green_terracotta
setblock 330 253 562 minecraft:oak_log
setblock 330 253 568 minecraft:oak_leaves[persistent=true]
setblock 330 253 593 minecraft:oak_leaves[persistent=true]
fill 330 253 594 330 253 596 minecraft:green_terracotta
setblock 330 253 597 minecraft:oak_log
fill 330 253 598 333 253 598 minecraft:green_terracotta
fill 331 253 558 333 253 558 minecraft:green_terracotta
fill 331 253 597 332 253 597 minecraft:green_terracotta
setblock 334 253 558 minecraft:oak_log
setblock 334 253 598 minecraft:oak_log
fill 335 253 558 338 253 558 minecraft:green_terracotta
fill 335 253 564 335 254 564 minecraft:iron_block
fill 335 253 598 338 253 598 minecraft:green_terracotta
fill 336 253 597 339 253 597 minecraft:green_terracotta
setblock 339 253 558 minecraft:oak_log
setblock 339 253 598 minecraft:oak_log
fill 340 253 558 343 253 558 minecraft:green_terracotta
setblock 340 253 597 minecraft:oak_log
fill 340 253 598 343 253 598 minecraft:green_terracotta
setblock 341 253 596 minecraft:oak_log
fill 341 253 597 344 253 597 minecraft:green_terracotta
fill 342 253 596 345 253 596 minecraft:green_terracotta
setblock 343 253 559 minecraft:oak_log
setblock 344 253 558 minecraft:oak_log
fill 344 253 559 344 256 559 minecraft:green_terracotta
setblock 344 253 598 minecraft:oak_log
fill 345 253 558 345 256 558 minecraft:green_terracotta
setblock 345 253 597 minecraft:oak_log
fill 345 253 598 348 253 598 minecraft:green_terracotta
setblock 346 253 596 minecraft:oak_log
fill 346 253 597 349 253 597 minecraft:green_terracotta
setblock 349 253 558 minecraft:oak_log
setblock 349 253 598 minecraft:oak_log
fill 350 253 558 350 254 558 minecraft:oak_leaves[persistent=true]
fill 350 253 598 351 253 598 minecraft:green_terracotta
setblock 356 253 558 minecraft:oak_leaves[persistent=true]
fill 356 253 591 356 254 592 minecraft:dark_oak_log
fill 357 253 590 357 254 590 minecraft:dark_oak_log
fill 357 253 593 357 254 593 minecraft:dark_oak_log
fill 358 253 594 359 254 594 minecraft:dark_oak_log
setblock 359 253 558 minecraft:oak_log
fill 360 253 558 363 253 558 minecraft:green_terracotta
fill 360 253 590 360 254 590 minecraft:dark_oak_log
fill 360 253 593 360 254 593 minecraft:dark_oak_log
fill 360 253 598 363 253 598 minecraft:green_terracotta
setblock 362 253 559 minecraft:green_terracotta
setblock 363 253 559 minecraft:oak_log
setblock 364 253 558 minecraft:oak_log
fill 364 253 559 364 256 559 minecraft:green_terracotta
setblock 364 253 598 minecraft:oak_log
fill 365 253 558 365 256 558 minecraft:green_terracotta
setblock 365 253 597 minecraft:oak_log
fill 365 253 598 365 256 598 minecraft:green_terracotta
setblock 366 253 560 minecraft:green_terracotta
fill 366 253 597 366 254 597 minecraft:green_terracotta
setblock 367 253 560 minecraft:oak_log
setblock 368 253 559 minecraft:oak_log
setblock 369 253 558 minecraft:oak_log
fill 369 253 559 369 256 559 minecraft:green_terracotta
setblock 369 253 573 minecraft:oak_log
setblock 369 253 574 minecraft:green_terracotta
setblock 369 253 578 minecraft:oak_log
setblock 369 253 579 minecraft:green_terracotta
setblock 369 253 598 minecraft:oak_log
fill 370 253 558 370 256 558 minecraft:green_terracotta
setblock 370 253 561 minecraft:green_terracotta
setblock 370 253 562 minecraft:oak_log
fill 370 253 563 370 256 563 minecraft:green_terracotta
setblock 370 253 572 minecraft:oak_log
fill 370 253 573 370 254 573 minecraft:green_terracotta
setblock 370 253 577 minecraft:oak_log
fill 370 253 578 370 256 578 minecraft:green_terracotta
setblock 370 253 588 minecraft:oak_leaves[persistent=true]
setblock 370 253 597 minecraft:oak_log
fill 370 253 598 370 256 598 minecraft:green_terracotta
fill 330 254 558 330 254 560 minecraft:green_terracotta
setblock 330 254 561 minecraft:oak_log
fill 330 254 562 330 257 562 minecraft:green_terracotta
setblock 330 254 574 minecraft:oak_leaves[persistent=true]
fill 330 254 594 330 254 595 minecraft:green_terracotta
setblock 330 254 596 minecraft:oak_log
fill 330 254 597 331 254 598 minecraft:green_terracotta
fill 331 254 558 332 254 558 minecraft:green_terracotta
setblock 332 254 598 minecraft:green_terracotta
setblock 333 254 558 minecraft:oak_log
setblock 333 254 598 minecraft:oak_log
fill 334 254 558 337 254 558 minecraft:green_terracotta
fill 334 254 598 337 254 598 minecraft:green_terracotta
fill 336 254 597 338 254 597 minecraft:green_terracotta
setblock 338 254 558 minecraft:oak_log
setblock 338 254 598 minecraft:oak_log
fill 339 254 558 342 254 558 minecraft:green_terracotta
setblock 339 254 597 minecraft:oak_log
fill 339 254 598 342 254 598 minecraft:green_terracotta
fill 340 254 597 343 254 597 minecraft:green_terracotta
setblock 341 254 559 minecraft:green_terracotta
fill 341 254 596 344 254 596 minecraft:green_terracotta
setblock 342 254 559 minecraft:oak_log
setblock 343 254 558 minecraft:oak_log
fill 343 254 559 343 257 559 minecraft:green_terracotta
setblock 343 254 598 minecraft:oak_log
fill 344 254 558 344 257 558 minecraft:green_terracotta
setblock 344 254 597 minecraft:oak_log
fill 344 254 598 347 254 598 minecraft:green_terracotta
fill 345 254 559 345 255 559 minecraft:green_terracotta
setblock 345 254 596 minecraft:oak_log
fill 345 254 597 348 254 597 minecraft:green_terracotta
setblock 348 254 558 minecraft:oak_log
setblock 348 254 598 minecraft:oak_log
fill 349 254 558 349 257 558 minecraft:green_terracotta
fill 349 254 598 350 255 598 minecraft:green_terracotta
setblock 356 254 590 minecraft:dark_oak_log
fill 356 254 593 356 254 594 minecraft:dark_oak_log
fill 357 254 589 360 254 589 minecraft:dark_oak_log
setblock 357 254 594 minecraft:dark_oak_log
fill 357 254 595 358 256 595 minecraft:oak_leaves[persistent=true]
fill 359 254 558 362 254 558 minecraft:green_terracotta
setblock 360 254 594 minecraft:dark_oak_log
fill 360 254 598 362 254 598 minecraft:green_terracotta
setblock 361 254 559 minecraft:green_terracotta
fill 361 254 590 361 254 593 minecraft:dark_oak_log
setblock 362 254 559 minecraft:oak_log
setblock 363 254 558 minecraft:oak_log
fill 363 254 559 363 257 559 minecraft:green_terracotta
setblock 363 254 598 minecraft:oak_log
fill 364 254 558 364 257 558 minecraft:green_terracotta
fill 364 254 560 365 254 560 minecraft:green_terracotta
fill 364 254 598 364 257 598 minecraft:green_terracotta
setblock 365 254 597 minecraft:green_terracotta
setblock 366 254 560 minecraft:oak_log
setblock 367 254 559 minecraft:oak_log
fill 367 254 560 369 255 560 minecraft:green_terracotta
setblock 368 254 558 minecraft:oak_log
fill 368 254 559 368 257 559 minecraft:green_terracotta
setblock 368 254 598 minecraft:oak_log
fill 369 254 558 369 257 558 minecraft:green_terracotta
setblock 369 254 561 minecraft:green_terracotta
setblock 369 254 562 minecraft:oak_log
fill 369 254 563 369 257 563 minecraft:green_terracotta
setblock 369 254 577 minecraft:oak_log
setblock 369 254 578 minecraft:green_terracotta
fill 369 254 598 369 257 598 minecraft:green_terracotta
setblock 370 254 561 minecraft:oak_log
fill 370 254 562 370 257 562 minecraft:green_terracotta
setblock 370 254 572 minecraft:green_terracotta
setblock 370 254 576 minecraft:oak_log
fill 370 254 577 370 257 577 minecraft:green_terracotta
setblock 370 254 582 minecraft:oak_leaves[persistent=true]
fill 370 254 597 370 257 597 minecraft:green_terracotta
fill 330 255 558 330 255 559 minecraft:green_terracotta
setblock 330 255 560 minecraft:oak_log
fill 330 255 561 330 258 561 minecraft:green_terracotta
fill 330 255 563 330 256 563 minecraft:green_terracotta
setblock 330 255 580 minecraft:oak_leaves[persistent=true]
setblock 330 255 595 minecraft:oak_log
fill 330 255 596 330 256 598 minecraft:green_terracotta
setblock 331 255 558 minecraft:green_terracotta
setblock 331 255 559 minecraft:oak_log
setblock 331 255 598 minecraft:green_terracotta
setblock 332 255 558 minecraft:oak_log
setblock 332 255 598 minecraft:oak_log
fill 333 255 558 336 255 558 minecraft:green_terracotta
fill 333 255 598 336 255 598 minecraft:green_terracotta
fill 336 255 589 337 273 591 minecraft:oak_log
fill 336 255 597 337 255 597 minecraft:green_terracotta
setblock 337 255 558 minecraft:oak_log
setblock 337 255 598 minecraft:oak_log
fill 338 255 558 341 255 558 minecraft:green_terracotta
fill 338 255 590 338 273 591 minecraft:oak_log
setblock 338 255 597 minecraft:oak_log
fill 338 255 598 341 255 598 minecraft:green_terracotta
fill 339 255 559 340 255 559 minecraft:green_terracotta
fill 339 255 597 342 255 597 minecraft:green_terracotta
setblock 341 255 559 minecraft:oak_log
fill 341 255 596 343 255 596 minecraft:green_terracotta
setblock 342 255 558 minecraft:oak_log
fill 342 255 559 342 258 559 minecraft:green_terracotta
setblock 342 255 598 minecraft:oak_log
fill 343 255 558 343 258 558 minecraft:green_terracotta
setblock 343 255 597 minecraft:oak_log
fill 343 255 598 346 255 598 minecraft:green_terracotta
setblock 344 255 596 minecraft:oak_log
fill 344 255 597 347 255 597 minecraft:green_terracotta
setblock 347 255 558 minecraft:oak_log
setblock 347 255 598 minecraft:oak_log
fill 348 255 558 348 258 558 minecraft:green_terracotta
fill 348 255 598 348 258 598 minecraft:green_terracotta
fill 353 255 582 355 261 585 minecraft:oak_log
fill 354 255 586 354 273 586 minecraft:oak_log
fill 355 255 593 357 255 594 minecraft:oak_leaves[persistent=true]
fill 356 255 583 356 273 585 minecraft:oak_log
fill 356 255 592 356 256 592 minecraft:oak_leaves[persistent=true]
setblock 356 255 595 minecraft:oak_leaves[persistent=true]
setblock 356 255 598 minecraft:oak_leaves[persistent=true]
setblock 357 255 558 minecraft:oak_log
fill 358 255 558 361 255 558 minecraft:green_terracotta
fill 358 255 594 359 256 594 minecraft:oak_leaves[persistent=true]
fill 359 255 598 361 255 598 minecraft:green_terracotta
setblock 360 255 559 minecraft:green_terracotta
setblock 361 255 559 minecraft:oak_log
setblock 362 255 558 minecraft:oak_log
fill 362 255 559 362 257 560 minecraft:green_terracotta
setblock 362 255 598 minecraft:oak_log
fill 363 255 558 363 258 558 minecraft:green_terracotta
fill 363 255 560 364 255 560 minecraft:green_terracotta
fill 363 255 598 363 258 598 minecraft:green_terracotta
setblock 365 255 560 minecraft:oak_log
setblock 366 255 559 minecraft:oak_log
fill 366 255 560 366 258 560 minecraft:green_terracotta
setblock 367 255 558 minecraft:oak_log
fill 367 255 559 367 258 559 minecraft:green_terracotta
setblock 367 255 598 minecraft:oak_log
fill 368 255 558 368 258 558 minecraft:green_terracotta
setblock 368 255 561 minecraft:green_terracotta
fill 368 255 598 368 258 598 minecraft:green_terracotta
setblock 369 255 561 minecraft:oak_log
fill 369 255 562 369 258 562 minecraft:green_terracotta
setblock 370 255 560 minecraft:oak_log
fill 370 255 561 370 258 561 minecraft:green_terracotta
setblock 370 255 565 minecraft:oak_log
setblock 370 255 570 minecraft:oak_leaves[persistent=true]
setblock 370 255 575 minecraft:oak_log
fill 370 255 576 370 256 576 minecraft:green_terracotta
setblock 370 255 580 minecraft:oak_log
setblock 370 255 595 minecraft:oak_leaves[persistent=true]
setblock 330 256 558 minecraft:green_terracotta
setblock 330 256 559 minecraft:oak_log
fill 330 256 560 331 258 560 minecraft:green_terracotta
setblock 330 256 567 minecraft:oak_leaves[persistent=true]
setblock 330 256 586 minecraft:oak_leaves[persistent=true]
fill 330 256 592 330 257 592 minecraft:oak_leaves[persistent=true]
fill 330 256 595 330 259 595 minecraft:green_terracotta
setblock 331 256 558 minecraft:oak_log
fill 331 256 559 332 258 559 minecraft:green_terracotta
setblock 331 256 598 minecraft:oak_log
fill 332 256 558 335 256 558 minecraft:green_terracotta
setblock 332 256 560 minecraft:light[level=14]
setblock 332 256 568 minecraft:light[level=14]
setblock 332 256 576 minecraft:light[level=14]
setblock 332 256 584 minecraft:light[level=14]
setblock 332 256 592 minecraft:light[level=14]
fill 332 256 598 335 256 598 minecraft:green_terracotta
fill 335 256 589 335 257 591 minecraft:dark_oak_log
fill 335 256 597 336 256 597 minecraft:green_terracotta
setblock 336 256 558 minecraft:oak_log
fill 336 256 592 338 257 592 minecraft:dark_oak_log
setblock 336 256 598 minecraft:oak_log
fill 337 256 558 339 256 559 minecraft:green_terracotta
setblock 337 256 597 minecraft:oak_log
fill 337 256 598 340 256 598 minecraft:green_terracotta
fill 338 256 589 338 257 589 minecraft:dark_oak_log
fill 338 256 597 341 256 597 minecraft:green_terracotta
setblock 340 256 558 minecraft:green_terracotta
setblock 340 256 559 minecraft:oak_log
setblock 340 256 560 minecraft:light[level=14]
setblock 340 256 568 minecraft:light[level=14]
setblock 340 256 576 minecraft:light[level=14]
setblock 340 256 584 minecraft:light[level=14]
setblock 340 256 592 minecraft:light[level=14]
fill 340 256 596 342 256 596 minecraft:green_terracotta
setblock 341 256 558 minecraft:oak_log
fill 341 256 559 341 259 559 minecraft:green_terracotta
setblock 341 256 598 minecraft:oak_log
fill 342 256 558 342 259 558 minecraft:green_terracotta
setblock 342 256 597 minecraft:oak_log
fill 342 256 598 345 256 598 minecraft:green_terracotta
setblock 343 256 596 minecraft:oak_log
fill 343 256 597 346 256 597 minecraft:green_terracotta
setblock 344 256 596 minecraft:green_terracotta
setblock 345 256 559 minecraft:oak_log
setblock 346 256 558 minecraft:oak_log
fill 346 256 559 346 259 559 minecraft:green_terracotta
setblock 346 256 598 minecraft:oak_log
fill 347 256 558 347 259 558 minecraft:green_terracotta
setblock 347 256 597 minecraft:oak_log
fill 347 256 598 347 259 598 minecraft:green_terracotta
setblock 348 256 560 minecraft:light[level=14]
setblock 348 256 568 minecraft:light[level=14]
setblock 348 256 576 minecraft:light[level=14]
setblock 348 256 584 minecraft:light[level=14]
setblock 348 256 592 minecraft:light[level=14]
fill 349 256 598 349 257 598 minecraft:green_terracotta
fill 352 256 585 352 257 586 minecraft:dark_oak_log
fill 353 256 586 353 257 586 minecraft:dark_oak_log
fill 354 256 581 355 257 581 minecraft:dark_oak_log
fill 354 256 587 354 257 587 minecraft:dark_oak_log
fill 355 256 586 356 257 586 minecraft:dark_oak_log
setblock 356 256 558 minecraft:oak_log
setblock 356 256 560 minecraft:light[level=14]
setblock 356 256 568 minecraft:light[level=14]
setblock 356 256 576 minecraft:light[level=14]
fill 356 256 582 356 257 582 minecraft:dark_oak_log
fill 356 256 593 357 256 594 minecraft:oak_leaves[persistent=true]
fill 357 256 558 360 256 558 minecraft:green_terracotta
fill 357 256 583 357 257 585 minecraft:dark_oak_log
fill 358 256 559 359 256 559 minecraft:green_terracotta
fill 359 256 598 360 256 598 minecraft:green_terracotta
setblock 360 256 559 minecraft:oak_log
setblock 361 256 558 minecraft:oak_log
fill 361 256 559 361 258 560 minecraft:green_terracotta
setblock 361 256 598 minecraft:oak_log
fill 362 256 558 362 259 558 minecraft:green_terracotta
fill 362 256 598 362 259 598 minecraft:green_terracotta
setblock 363 256 560 minecraft:green_terracotta
setblock 364 256 560 minecraft:oak_log
setblock 364 256 568 minecraft:light[level=14]
setblock 364 256 576 minecraft:light[level=14]
setblock 364 256 584 minecraft:light[level=14]
setblock 364 256 592 minecraft:light[level=14]
setblock 365 256 559 minecraft:oak_log
fill 365 256 560 365 259 560 minecraft:green_terracotta
setblock 366 256 558 minecraft:oak_log
fill 366 256 559 366 259 559 minecraft:green_terracotta
setblock 366 256 598 minecraft:oak_log
fill 367 256 558 367 259 558 minecraft:green_terracotta
fill 367 256 560 368 256 560 minecraft:green_terracotta
fill 367 256 598 367 259 598 minecraft:green_terracotta
setblock 368 256 561 minecraft:oak_log
fill 368 256 562 368 259 562 minecraft:green_terracotta
setblock 369 256 560 minecraft:oak_log
fill 369 256 561 369 259 561 minecraft:green_terracotta
setblock 369 256 564 minecraft:green_terracotta
setblock 370 256 559 minecraft:oak_log
fill 370 256 560 370 259 560 minecraft:green_terracotta
setblock 370 256 564 minecraft:oak_log
fill 370 256 565 370 258 566 minecraft:green_terracotta
setblock 370 256 579 minecraft:oak_log
fill 370 256 580 370 258 581 minecraft:green_terracotta
setblock 370 256 589 minecraft:oak_leaves[persistent=true]
setblock 330 257 558 minecraft:oak_log
fill 330 257 559 330 260 559 minecraft:green_terracotta
setblock 330 257 563 minecraft:oak_log
setblock 330 257 573 minecraft:oak_leaves[persistent=true]
fill 330 257 596 330 257 597 minecraft:green_terracotta
setblock 330 257 598 minecraft:oak_log
fill 331 257 558 334 257 558 minecraft:green_terracotta
fill 331 257 598 334 257 598 minecraft:green_terracotta
setblock 333 257 559 minecraft:green_terracotta
setblock 334 257 559 minecraft:oak_log
fill 334 257 590 334 257 591 minecraft:dark_oak_log
setblock 335 257 558 minecraft:oak_log
fill 335 257 559 338 257 559 minecraft:green_terracotta
setblock 335 257 592 minecraft:dark_oak_log
setblock 335 257 597 minecraft:green_terracotta
setblock 335 257 598 minecraft:oak_log
fill 336 257 558 339 257 558 minecraft:green_terracotta
fill 336 257 588 338 257 588 minecraft:dark_oak_log
fill 336 257 593 337 257 593 minecraft:dark_oak_log
setblock 336 257 597 minecraft:oak_log
fill 336 257 598 339 257 598 minecraft:green_terracotta
fill 337 257 597 340 257 597 minecraft:green_terracotta
setblock 339 257 559 minecraft:oak_log
fill 339 257 589 339 257 592 minecraft:dark_oak_log
setblock 340 257 558 minecraft:oak_log
fill 340 257 559 340 260 559 minecraft:green_terracotta
fill 340 257 596 341 257 596 minecraft:green_terracotta
setblock 340 257 598 minecraft:oak_log
fill 341 257 558 341 260 558 minecraft:green_terracotta
setblock 341 257 597 minecraft:oak_log
fill 341 257 598 344 257 598 minecraft:green_terracotta
setblock 342 257 596 minecraft:oak_log
fill 342 257 597 345 257 597 minecraft:green_terracotta
setblock 343 257 596 minecraft:green_terracotta
setblock 344 257 559 minecraft:oak_log
setblock 345 257 558 minecraft:oak_log
fill 345 257 559 345 260 559 minecraft:green_terracotta
setblock 345 257 598 minecraft:oak_log
fill 346 257 558 346 260 558 minecraft:green_terracotta
setblock 346 257 597 minecraft:oak_log
fill 346 257 598 346 260 598 minecraft:green_terracotta
fill 350 257 582 350 273 582 minecraft:oak_log
setblock 351 257 558 minecraft:oak_leaves[persistent=true]
fill 351 257 585 351 257 586 minecraft:dark_oak_log
fill 352 257 587 353 257 587 minecraft:dark_oak_log
setblock 355 257 558 minecraft:oak_log
setblock 355 257 580 minecraft:dark_oak_log
fill 355 257 587 356 257 587 minecraft:dark_oak_log
fill 356 257 558 359 257 558 minecraft:green_terracotta
fill 356 257 581 357 257 581 minecraft:dark_oak_log
fill 357 257 559 358 257 559 minecraft:green_terracotta
setblock 357 257 582 minecraft:dark_oak_log
setblock 357 257 586 minecraft:dark_oak_log
fill 358 257 583 358 257 585 minecraft:dark_oak_log
fill 358 257 598 359 257 598 minecraft:green_terracotta
setblock 359 257 559 minecraft:oak_log
fill 359 257 560 360 259 560 minecraft:green_terracotta
setblock 360 257 558 minecraft:oak_log
fill 360 257 559 360 260 559 minecraft:green_terracotta
setblock 360 257 598 minecraft:oak_log
fill 361 257 558 361 260 558 minecraft:green_terracotta
fill 361 257 598 361 260 598 minecraft:green_terracotta
setblock 362 257 561 minecraft:oak_log
setblock 363 257 560 minecraft:oak_log
fill 363 257 561 366 257 561 minecraft:green_terracotta
fill 363 257 597 364 257 597 minecraft:green_terracotta
setblock 364 257 559 minecraft:oak_log
fill 364 257 560 364 260 560 minecraft:green_terracotta
setblock 365 257 558 minecraft:oak_log
fill 365 257 559 365 260 559 minecraft:green_terracotta
setblock 365 257 598 minecraft:oak_log
fill 366 257 558 366 260 558 minecraft:green_terracotta
fill 366 257 598 366 260 598 minecraft:green_terracotta
setblock 367 257 560 minecraft:green_terracotta
setblock 368 257 560 minecraft:oak_log
fill 368 257 561 368 260 561 minecraft:green_terracotta
fill 368 257 563 368 258 563 minecraft:green_terracotta
setblock 369 257 559 minecraft:oak_log
fill 369 257 560 369 260 560 minecraft:green_terracotta
setblock 369 257 564 minecraft:oak_log
fill 369 257 565 369 260 565 minecraft:green_terracotta
setblock 370 257 558 minecraft:oak_log
fill 370 257 559 370 260 559 minecraft:green_terracotta
setblock 370 257 563 minecraft:oak_log
fill 370 257 564 370 260 564 minecraft:green_terracotta
setblock 370 257 578 minecraft:oak_log
fill 370 257 579 370 258 579 minecraft:green_terracotta
setblock 370 257 583 minecraft:oak_leaves[persistent=true]
setblock 370 257 598 minecraft:oak_log
fill 330 258 558 333 258 558 minecraft:green_terracotta
setblock 330 258 562 minecraft:oak_log
fill 330 258 563 330 260 564 minecraft:green_terracotta
setblock 330 258 579 minecraft:oak_leaves[persistent=true]
fill 330 258 580 330 258 581 minecraft:green_terracotta
setblock 330 258 582 minecraft:oak_log
fill 330 258 583 330 260 584 minecraft:green_terracotta
setblock 330 258 596 minecraft:green_terracotta
setblock 330 258 597 minecraft:oak_log
fill 330 258 598 333 258 598 minecraft:green_terracotta
setblock 331 258 561 minecraft:oak_log
setblock 333 258 559 minecraft:oak_log
setblock 334 258 558 minecraft:oak_log
fill 334 258 559 337 258 559 minecraft:green_terracotta
setblock 334 258 597 minecraft:green_terracotta
setblock 334 258 598 minecraft:oak_log
fill 335 258 558 338 258 558 minecraft:green_terracotta
setblock 335 258 597 minecraft:oak_log
fill 335 258 598 338 258 598 minecraft:green_terracotta
fill 336 258 597 339 258 597 minecraft:green_terracotta
setblock 338 258 559 minecraft:oak_log
setblock 339 258 558 minecraft:oak_log
fill 339 258 559 339 261 559 minecraft:green_terracotta
fill 339 258 596 340 258 596 minecraft:green_terracotta
setblock 339 258 598 minecraft:oak_log
fill 340 258 558 340 261 558 minecraft:green_terracotta
fill 340 258 560 341 258 560 minecraft:green_terracotta
setblock 340 258 597 minecraft:oak_log
fill 340 258 598 343 258 598 minecraft:green_terracotta
setblock 341 258 596 minecraft:oak_log
fill 341 258 597 344 258 597 minecraft:green_terracotta
setblock 342 258 560 minecraft:oak_log
fill 342 258 596 342 259 596 minecraft:green_terracotta
setblock 343 258 559 minecraft:oak_log
fill 343 258 560 343 259 560 minecraft:green_terracotta
setblock 344 258 558 minecraft:oak_log
fill 344 258 559 344 261 559 minecraft:green_terracotta
setblock 344 258 598 minecraft:oak_log
fill 345 258 558 345 261 558 minecraft:green_terracotta
setblock 345 258 597 minecraft:oak_log
fill 345 258 598 345 261 598 minecraft:green_terracotta
setblock 346 258 597 minecraft:green_terracotta
setblock 349 258 558 minecraft:oak_log
setblock 354 258 558 minecraft:oak_log
fill 355 258 558 358 258 558 minecraft:green_terracotta
setblock 355 258 598 minecraft:oak_leaves[persistent=true]
fill 356 258 559 357 258 559 minecraft:green_terracotta
setblock 358 258 559 minecraft:oak_log
fill 358 258 560 358 261 560 minecraft:green_terracotta
setblock 358 258 598 minecraft:green_terracotta
setblock 359 258 558 minecraft:oak_log
fill 359 258 559 359 261 559 minecraft:green_terracotta
setblock 359 258 598 minecraft:oak_log
fill 360 258 558 360 261 558 minecraft:green_terracotta
setblock 360 258 561 minecraft:green_terracotta
fill 360 258 598 360 261 598 minecraft:green_terracotta
setblock 361 258 561 minecraft:oak_log
setblock 362 258 559 minecraft:green_terracotta
setblock 362 258 560 minecraft:oak_log
fill 362 258 561 365 258 561 minecraft:green_terracotta
setblock 363 258 559 minecraft:oak_log
fill 363 258 560 363 261 560 minecraft:green_terracotta
setblock 363 258 597 minecraft:green_terracotta
setblock 364 258 558 minecraft:oak_log
fill 364 258 559 364 261 559 minecraft:green_terracotta
setblock 364 258 598 minecraft:oak_log
fill 365 258 558 365 261 558 minecraft:green_terracotta
fill 365 258 598 365 261 598 minecraft:green_terracotta
setblock 366 258 561 minecraft:oak_log
setblock 367 258 560 minecraft:oak_log
fill 367 258 561 367 260 561 minecraft:green_terracotta
setblock 368 258 559 minecraft:oak_log
fill 368 258 560 368 261 560 minecraft:green_terracotta
setblock 369 258 558 minecraft:oak_log
fill 369 258 559 369 261 559 minecraft:green_terracotta
setblock 369 258 563 minecraft:oak_log
fill 369 258 564 369 261 564 minecraft:green_terracotta
setblock 369 258 598 minecraft:oak_log
fill 370 258 558 370 261 558 minecraft:green_terracotta
setblock 370 258 562 minecraft:oak_log
fill 370 258 563 370 261 563 minecraft:green_terracotta
setblock 370 258 567 minecraft:oak_log
setblock 370 258 577 minecraft:oak_leaves[persistent=true]
setblock 370 258 578 minecraft:green_terracotta
setblock 370 258 582 minecraft:oak_log
setblock 370 258 596 minecraft:oak_leaves[persistent=true]
setblock 370 258 597 minecraft:oak_log
fill 370 258 598 370 261 598 minecraft:green_terracotta
fill 330 259 558 332 259 558 minecraft:green_terracotta
setblock 330 259 560 minecraft:green_terracotta
setblock 330 259 561 minecraft:oak_log
fill 330 259 562 330 262 562 minecraft:green_terracotta
setblock 330 259 566 minecraft:oak_leaves[persistent=true]
setblock 330 259 580 minecraft:green_terracotta
setblock 330 259 581 minecraft:oak_log
fill 330 259 582 330 262 582 minecraft:green_terracotta
setblock 330 259 585 minecraft:green_terracotta
setblock 330 259 586 minecraft:oak_log
fill 330 259 587 330 262 587 minecraft:green_terracotta
setblock 330 259 596 minecraft:oak_log
fill 330 259 597 330 261 598 minecraft:green_terracotta
setblock 331 259 559 minecraft:green_terracotta
setblock 331 259 560 minecraft:oak_log
fill 331 259 561 331 261 561 minecraft:green_terracotta
fill 331 259 598 332 259 598 minecraft:green_terracotta
setblock 332 259 559 minecraft:oak_log
setblock 333 259 558 minecraft:oak_log
fill 333 259 559 336 259 559 minecraft:green_terracotta
setblock 333 259 598 minecraft:oak_log
fill 334 259 558 337 259 558 minecraft:green_terracotta
setblock 334 259 597 minecraft:oak_log
fill 334 259 598 337 259 598 minecraft:green_terracotta
fill 335 259 597 338 259 597 minecraft:green_terracotta
setblock 337 259 559 minecraft:oak_log
setblock 338 259 558 minecraft:oak_log
fill 338 259 559 338 261 560 minecraft:green_terracotta
setblock 338 259 598 minecraft:oak_log
fill 339 259 558 339 262 558 minecraft:green_terracotta
fill 339 259 560 340 259 560 minecraft:green_terracotta
setblock 339 259 596 minecraft:green_terracotta
setblock 339 259 597 minecraft:oak_log
fill 339 259 598 342 259 598 minecraft:green_terracotta
setblock 340 259 596 minecraft:oak_log
fill 340 259 597 343 259 597 minecraft:green_terracotta
setblock 341 259 560 minecraft:oak_log
setblock 341 259 596 minecraft:green_terracotta
setblock 342 259 559 minecraft:oak_log
fill 342 259 560 342 261 560 minecraft:green_terracotta
setblock 343 259 558 minecraft:oak_log
fill 343 259 559 343 262 559 minecraft:green_terracotta
setblock 343 259 598 minecraft:oak_log
fill 344 259 558 344 262 558 minecraft:green_terracotta
setblock 344 259 597 minecraft:oak_log
fill 344 259 598 344 262 598 minecraft:green_terracotta
setblock 345 259 597 minecraft:green_terracotta
setblock 348 259 558 minecraft:oak_log
setblock 349 259 558 minecraft:green_terracotta
setblock 353 259 558 minecraft:oak_log
fill 354 259 558 357 259 558 minecraft:green_terracotta
fill 355 259 559 356 259 559 minecraft:green_terracotta
setblock 357 259 559 minecraft:oak_log
fill 357 259 560 357 262 560 minecraft:green_terracotta
setblock 357 259 598 minecraft:green_terracotta
setblock 358 259 558 minecraft:oak_log
fill 358 259 559 358 262 559 minecraft:green_terracotta
setblock 358 259 598 minecraft:oak_log
fill 359 259 558 359 262 558 minecraft:green_terracotta
setblock 359 259 561 minecraft:green_terracotta
fill 359 259 598 359 262 598 minecraft:green_terracotta
setblock 360 259 561 minecraft:oak_log
setblock 361 259 559 minecraft:green_terracotta
setblock 361 259 560 minecraft:oak_log
fill 361 259 561 364 259 561 minecraft:green_terracotta
setblock 362 259 559 minecraft:oak_log
fill 362 259 560 362 262 560 minecraft:green_terracotta
setblock 363 259 558 minecraft:oak_log
fill 363 259 559 363 262 559 minecraft:green_terracotta
setblock 363 259 598 minecraft:oak_log
fill 364 259 558 364 262 558 minecraft:green_terracotta
fill 364 259 598 364 262 598 minecraft:green_terracotta
setblock 365 259 561 minecraft:oak_log
setblock 366 259 560 minecraft:oak_log
fill 366 259 561 366 261 561 minecraft:green_terracotta
setblock 367 259 559 minecraft:oak_log
fill 367 259 560 367 262 560 minecraft:green_terracotta
setblock 368 259 558 minecraft:oak_log
fill 368 259 559 368 262 559 minecraft:green_terracotta
setblock 368 259 563 minecraft:oak_log
fill 368 259 564 368 262 564 minecraft:green_terracotta
setblock 368 259 598 minecraft:oak_log
fill 369 259 558 369 262 558 minecraft:green_terracotta
setblock 369 259 562 minecraft:oak_log
fill 369 259 563 369 262 563 minecraft:green_terracotta
setblock 369 259 566 minecraft:green_terracotta
fill 369 259 598 369 261 598 minecraft:green_terracotta
setblock 370 259 561 minecraft:oak_log
fill 370 259 562 370 262 562 minecraft:green_terracotta
setblock 370 259 565 minecraft:green_terracotta
setblock 370 259 566 minecraft:oak_log
fill 370 259 567 370 262 567 minecraft:green_terracotta
setblock 370 259 571 minecraft:oak_leaves[persistent=true]
setblock 370 259 580 minecraft:green_terracotta
setblock 370 259 581 minecraft:oak_log
fill 370 259 582 370 260 583 minecraft:green_terracotta
setblock 370 259 590 minecraft:oak_leaves[persistent=true]
fill 330 260 558 331 260 558 minecraft:green_terracotta
setblock 330 260 560 minecraft:oak_log
fill 330 260 561 330 263 561 minecraft:green_terracotta
setblock 330 260 565 minecraft:oak_log
setblock 330 260 572 minecraft:oak_leaves[persistent=true]
setblock 330 260 580 minecraft:oak_log
fill 330 260 581 330 262 581 minecraft:green_terracotta
setblock 330 260 585 minecraft:oak_log
fill 330 260 586 330 263 586 minecraft:green_terracotta
fill 330 260 588 330 260 589 minecraft:green_terracotta
setblock 330 260 591 minecraft:oak_leaves[persistent=true]
setblock 330 260 595 minecraft:oak_log
fill 330 260 596 330 261 596 minecraft:green_terracotta
setblock 331 260 559 minecraft:oak_log
fill 331 260 560 331 261 560 minecraft:green_terracotta
fill 331 260 562 331 261 562 minecraft:green_terracotta
setblock 331 260 598 minecraft:green_terracotta
setblock 332 260 558 minecraft:oak_log
fill 332 260 559 335 260 559 minecraft:green_terracotta
setblock 332 260 598 minecraft:oak_log
fill 333 260 558 336 260 558 minecraft:green_terracotta
fill 333 260 598 336 260 598 minecraft:green_terracotta
fill 334 260 597 337 260 597 minecraft:green_terracotta
setblock 336 260 559 minecraft:oak_log
setblock 337 260 558 minecraft:oak_log
fill 337 260 559 337 261 560 minecraft:green_terracotta
setblock 337 260 598 minecraft:oak_log
fill 338 260 558 338 263 558 minecraft:green_terracotta
setblock 338 260 597 minecraft:oak_log
fill 338 260 598 341 260 598 minecraft:green_terracotta
setblock 339 260 560 minecraft:green_terracotta
setblock 339 260 596 minecraft:oak_log
fill 339 260 597 342 260 597 minecraft:green_terracotta
setblock 340 260 560 minecraft:oak_log
setblock 340 260 596 minecraft:green_terracotta
setblock 341 260 559 minecraft:oak_log
fill 341 260 560 341 261 560 minecraft:green_terracotta
setblock 342 260 558 minecraft:oak_log
fill 342 260 559 342 262 559 minecraft:green_terracotta
setblock 342 260 598 minecraft:oak_log
fill 343 260 558 343 263 558 minecraft:green_terracotta
setblock 343 260 597 minecraft:oak_log
fill 343 260 598 343 263 598 minecraft:green_terracotta
setblock 344 260 597 minecraft:green_terracotta
setblock 347 260 558 minecraft:oak_log
setblock 348 260 558 minecraft:green_terracotta
setblock 348 260 598 minecraft:oak_leaves[persistent=true]
setblock 352 260 558 minecraft:oak_leaves[persistent=true]
fill 353 260 558 356 260 558 minecraft:green_terracotta
setblock 355 260 559 minecraft:green_terracotta
setblock 356 260 559 minecraft:oak_log
fill 356 260 560 356 263 560 minecraft:green_terracotta
setblock 357 260 558 minecraft:oak_log
fill 357 260 559 357 263 559 minecraft:green_terracotta
setblock 357 260 598 minecraft:oak_log
fill 358 260 558 358 263 558 minecraft:green_terracotta
setblock 358 260 561 minecraft:green_terracotta
fill 358 260 598 358 263 598 minecraft:green_terracotta
setblock 359 260 560 minecraft:green_terracotta
setblock 359 260 561 minecraft:oak_log
setblock 360 260 560 minecraft:oak_log
fill 360 260 561 363 260 561 minecraft:green_terracotta
setblock 361 260 559 minecraft:oak_log
fill 361 260 560 361 263 560 minecraft:green_terracotta
fill 361 260 562 362 260 562 minecraft:green_terracotta
setblock 362 260 558 minecraft:oak_log
fill 362 260 559 362 263 559 minecraft:green_terracotta
setblock 362 260 598 minecraft:oak_log
fill 363 260 558 363 263 558 minecraft:green_terracotta
setblock 363 260 562 minecraft:oak_log
fill 363 260 598 363 263 598 minecraft:green_terracotta
setblock 364 260 561 minecraft:oak_log
setblock 365 260 560 minecraft:oak_log
fill 365 260 561 365 262 561 minecraft:green_terracotta
setblock 366 260 559 minecraft:oak_log
fill 366 260 560 366 263 560 minecraft:green_terracotta
setblock 367 260 558 minecraft:oak_log
fill 367 260 559 367 263 559 minecraft:green_terracotta
setblock 367 260 562 minecraft:green_terracotta
setblock 367 260 598 minecraft:oak_log
fill 368 260 558 368 263 558 minecraft:green_terracotta
setblock 368 260 562 minecraft:oak_log
fill 368 260 563 368 262 563 minecraft:green_terracotta
fill 368 260 598 368 261 598 minecraft:green_terracotta
setblock 369 260 561 minecraft:oak_log
fill 369 260 562 369 263 562 minecraft:green_terracotta
setblock 369 260 566 minecraft:oak_log
setblock 370 260 560 minecraft:oak_log
fill 370 260 561 370 263 561 minecraft:green_terracotta
setblock 370 260 565 minecraft:oak_log
fill 370 260 566 370 263 566 minecraft:green_terracotta
fill 370 260 568 370 261 568 minecraft:green_terracotta
setblock 370 260 581 minecraft:green_terracotta
setblock 370 260 584 minecraft:green_terracotta
setblock 330 261 558 minecraft:green_terracotta
setblock 330 261 559 minecraft:oak_log
fill 330 261 560 330 264 560 minecraft:green_terracotta
setblock 330 261 563 minecraft:green_terracotta
setblock 330 261 564 minecraft:oak_log
fill 330 261 565 330 263 565 minecraft:green_terracotta
setblock 330 261 578 minecraft:oak_leaves[persistent=true]
setblock 330 261 583 minecraft:green_terracotta
setblock 330 261 584 minecraft:oak_log
fill 330 261 585 331 263 585 minecraft:green_terracotta
setblock 330 261 588 minecraft:green_terracotta
setblock 330 261 589 minecraft:oak_log
fill 330 261 590 330 264 590 minecraft:green_terracotta
setblock 331 261 558 minecraft:oak_log
fill 331 261 559 334 261 559 minecraft:green_terracotta
setblock 331 261 598 minecraft:oak_log
fill 332 261 558 335 261 558 minecraft:green_terracotta
fill 332 261 598 335 261 598 minecraft:green_terracotta
fill 334 261 597 336 261 597 minecraft:green_terracotta
setblock 335 261 559 minecraft:oak_log
setblock 336 261 558 minecraft:oak_log
fill 336 261 559 336 263 559 minecraft:green_terracotta
setblock 336 261 598 minecraft:oak_log
fill 337 261 558 337 264 558 minecraft:green_terracotta
setblock 337 261 597 minecraft:oak_log
fill 337 261 598 340 261 598 minecraft:green_terracotta
fill 338 261 597 341 261 597 minecraft:green_terracotta
setblock 339 261 560 minecraft:oak_log
setblock 340 261 559 minecraft:oak_log
setblock 340 261 560 minecraft:green_terracotta
setblock 341 261 558 minecraft:oak_log
fill 341 261 559 341 263 559 minecraft:green_terracotta
setblock 341 261 598 minecraft:oak_log
fill 342 261 558 342 263 558 minecraft:green_terracotta
setblock 342 261 597 minecraft:oak_log
fill 342 261 598 342 263 598 minecraft:green_terracotta
setblock 343 261 597 minecraft:green_terracotta
setblock 346 261 558 minecraft:oak_log
setblock 347 261 558 minecraft:green_terracotta
fill 353 261 558 355 261 558 minecraft:green_terracotta
setblock 354 261 559 minecraft:green_terracotta
setblock 354 261 598 minecraft:oak_leaves[persistent=true]
setblock 355 261 559 minecraft:oak_log
setblock 356 261 558 minecraft:oak_log
fill 356 261 559 356 264 559 minecraft:green_terracotta
fill 357 261 558 357 264 558 minecraft:green_terracotta
fill 357 261 598 357 262 598 minecraft:green_terracotta
setblock 358 261 561 minecraft:oak_log
setblock 359 261 560 minecraft:oak_log
fill 359 261 561 362 261 561 minecraft:green_terracotta
setblock 360 261 559 minecraft:oak_log
fill 360 261 560 360 264 560 minecraft:green_terracotta
fill 360 261 562 361 261 562 minecraft:green_terracotta
setblock 361 261 558 minecraft:oak_log
fill 361 261 559 361 264 559 minecraft:green_terracotta
setblock 361 261 598 minecraft:oak_log
fill 362 261 558 362 264 558 minecraft:green_terracotta
setblock 362 261 562 minecraft:oak_log
fill 362 261 598 362 263 598 minecraft:green_terracotta
setblock 363 261 561 minecraft:oak_log
setblock 363 261 562 minecraft:green_terracotta
setblock 364 261 560 minecraft:oak_log
fill 364 261 561 364 262 561 minecraft:green_terracotta
setblock 365 261 559 minecraft:oak_log
fill 365 261 560 365 263 560 minecraft:green_terracotta
setblock 366 261 558 minecraft:oak_log
fill 366 261 559 366 264 559 minecraft:green_terracotta
setblock 366 261 598 minecraft:oak_log
fill 367 261 558 367 264 558 minecraft:green_terracotta
setblock 367 261 598 minecraft:green_terracotta
setblock 368 261 561 minecraft:oak_log
fill 368 261 562 368 262 562 minecraft:green_terracotta
setblock 369 261 560 minecraft:oak_log
fill 369 261 561 369 264 561 minecraft:green_terracotta
setblock 369 261 565 minecraft:oak_log
fill 369 261 566 369 263 566 minecraft:green_terracotta
setblock 370 261 559 minecraft:oak_log
fill 370 261 560 370 264 560 minecraft:green_terracotta
setblock 370 261 564 minecraft:oak_log
fill 370 261 565 370 264 565 minecraft:green_terracotta
setblock 370 261 578 minecraft:oak_leaves[persistent=true]
setblock 370 261 583 minecraft:green_terracotta
setblock 370 261 584 minecraft:oak_log
setblock 330 262 558 minecraft:oak_log
fill 330 262 559 330 263 559 minecraft:green_terracotta
setblock 330 262 563 minecraft:oak_log
fill 330 262 564 330 264 564 minecraft:green_terracotta
setblock 330 262 583 minecraft:oak_log
fill 330 262 584 331 263 584 minecraft:green_terracotta
setblock 330 262 588 minecraft:oak_log
fill 330 262 589 330 265 589 minecraft:green_terracotta
fill 330 262 591 330 262 592 minecraft:green_terracotta
setblock 330 262 597 minecraft:green_terracotta
setblock 330 262 598 minecraft:oak_log
fill 331 262 558 334 262 558 minecraft:green_terracotta
setblock 331 262 586 minecraft:green_terracotta
setblock 331 262 587 minecraft:oak_log
fill 331 262 598 334 262 598 minecraft:green_terracotta
setblock 333 262 559 minecraft:green_terracotta
setblock 334 262 559 minecraft:oak_log
setblock 335 262 558 minecraft:oak_log
fill 335 262 559 335 263 559 minecraft:green_terracotta
setblock 335 262 597 minecraft:green_terracotta
setblock 335 262 598 minecraft:oak_log
fill 336 262 558 336 265 558 minecraft:green_terracotta
setblock 336 262 597 minecraft:oak_log
fill 336 262 598 339 262 598 minecraft:green_terracotta
fill 337 262 559 338 262 559 minecraft:green_terracotta
fill 337 262 597 340 262 597 minecraft:green_terracotta
setblock 339 262 559 minecraft:oak_log
setblock 339 262 560 minecraft:green_terracotta
setblock 340 262 558 minecraft:oak_log
fill 340 262 559 340 263 559 minecraft:green_terracotta
setblock 340 262 598 minecraft:oak_log
fill 341 262 558 341 264 558 minecraft:green_terracotta
setblock 341 262 597 minecraft:oak_log
fill 341 262 598 341 264 598 minecraft:green_terracotta
setblock 342 262 597 minecraft:green_terracotta
setblock 345 262 558 minecraft:oak_log
fill 353 262 558 354 262 558 minecraft:green_terracotta
fill 353 262 583 355 269 585 minecraft:oak_log
fill 354 262 582 355 273 582 minecraft:oak_log
setblock 355 262 558 minecraft:oak_log
fill 355 262 559 355 265 559 minecraft:green_terracotta
fill 356 262 558 356 265 558 minecraft:green_terracotta
setblock 357 262 561 minecraft:oak_log
setblock 358 262 560 minecraft:oak_log
fill 358 262 561 361 262 561 minecraft:green_terracotta
setblock 359 262 559 minecraft:oak_log
fill 359 262 560 359 265 560 minecraft:green_terracotta
setblock 360 262 558 minecraft:oak_log
fill 360 262 559 360 265 559 minecraft:green_terracotta
setblock 360 262 562 minecraft:green_terracotta
setblock 360 262 598 minecraft:oak_log
fill 361 262 558 361 265 558 minecraft:green_terracotta
setblock 361 262 562 minecraft:oak_log
fill 361 262 598 361 264 598 minecraft:green_terracotta
setblock 362 262 561 minecraft:oak_log
setblock 363 262 560 minecraft:oak_log
fill 363 262 561 363 263 561 minecraft:green_terracotta
setblock 364 262 559 minecraft:oak_log
fill 364 262 560 364 264 560 minecraft:green_terracotta
setblock 365 262 558 minecraft:oak_log
fill 365 262 559 365 264 559 minecraft:green_terracotta
setblock 365 262 598 minecraft:oak_log
fill 366 262 558 366 265 558 minecraft:green_terracotta
setblock 366 262 598 minecraft:green_terracotta
setblock 368 262 560 minecraft:oak_log
setblock 368 262 561 minecraft:green_terracotta
setblock 369 262 559 minecraft:oak_log
fill 369 262 560 369 264 560 minecraft:green_terracotta
setblock 369 262 564 minecraft:oak_log
fill 369 262 565 369 264 565 minecraft:green_terracotta
setblock 370 262 558 minecraft:oak_log
fill 370 262 559 370 265 559 minecraft:green_terracotta
setblock 370 262 563 minecraft:oak_log
fill 370 262 564 370 265 564 minecraft:green_terracotta
setblock 370 262 568 minecraft:oak_log
setblock 370 262 572 minecraft:oak_leaves[persistent=true]
setblock 370 262 597 minecraft:oak_leaves[persistent=true]
fill 330 263 558 333 263 558 minecraft:green_terracotta
setblock 330 263 562 minecraft:oak_log
fill 330 263 563 330 264 563 minecraft:green_terracotta
setblock 330 263 582 minecraft:oak_log
fill 330 263 583 330 265 583 minecraft:green_terracotta
setblock 330 263 587 minecraft:oak_log
fill 330 263 588 331 265 588 minecraft:green_terracotta
setblock 330 263 591 minecraft:green_terracotta
setblock 330 263 592 minecraft:oak_log
fill 330 263 598 333 263 598 minecraft:green_terracotta
setblock 331 263 586 minecraft:oak_log
fill 331 263 587 331 266 587 minecraft:green_terracotta
setblock 334 263 558 minecraft:oak_log
setblock 334 263 598 minecraft:oak_log
fill 335 263 558 335 265 558 minecraft:green_terracotta
fill 335 263 598 338 263 598 minecraft:green_terracotta
fill 336 263 597 339 263 597 minecraft:green_terracotta
setblock 337 263 559 minecraft:green_terracotta
setblock 338 263 559 minecraft:oak_log
setblock 339 263 558 minecraft:oak_log
setblock 339 263 559 minecraft:green_terracotta
setblock 339 263 598 minecraft:oak_log
fill 340 263 558 340 264 558 minecraft:green_terracotta
setblock 340 263 597 minecraft:oak_log
fill 340 263 598 340 265 598 minecraft:green_terracotta
fill 347 263 568 348 264 568 minecraft:oak_leaves[persistent=true]
fill 353 263 558 353 264 558 minecraft:oak_leaves[persistent=true]
setblock 354 263 558 minecraft:oak_log
fill 355 263 558 355 266 558 minecraft:green_terracotta
setblock 357 263 560 minecraft:oak_log
setblock 358 263 559 minecraft:oak_log
fill 358 263 560 358 264 561 minecraft:green_terracotta
setblock 359 263 558 minecraft:oak_log
fill 359 263 559 359 266 559 minecraft:green_terracotta
fill 359 263 561 360 263 561 minecraft:green_terracotta
setblock 359 263 598 minecraft:oak_log
fill 360 263 558 360 266 558 minecraft:green_terracotta
fill 360 263 598 360 264 598 minecraft:green_terracotta
setblock 361 263 561 minecraft:oak_log
setblock 362 263 560 minecraft:oak_log
fill 362 263 561 362 264 561 minecraft:green_terracotta
setblock 363 263 559 minecraft:oak_log
fill 363 263 560 363 264 560 minecraft:green_terracotta
setblock 364 263 558 minecraft:oak_log
fill 364 263 559 364 265 559 minecraft:green_terracotta
setblock 364 263 598 minecraft:oak_log
fill 365 263 558 365 266 558 minecraft:green_terracotta
setblock 366 263 598 minecraft:oak_leaves[persistent=true]
setblock 368 263 559 minecraft:oak_log
setblock 369 263 558 minecraft:oak_log
setblock 369 263 559 minecraft:green_terracotta
setblock 369 263 563 minecraft:oak_log
fill 369 263 564 369 264 564 minecraft:green_terracotta
fill 370 263 558 370 265 558 minecraft:green_terracotta
setblock 370 263 562 minecraft:oak_log
fill 370 263 563 370 266 563 minecraft:green_terracotta
setblock 370 263 567 minecraft:oak_log
setblock 370 263 568 minecraft:green_terracotta
setblock 370 263 591 minecraft:oak_leaves[persistent=true]
setblock 330 264 561 minecraft:oak_log
setblock 330 264 562 minecraft:green_terracotta
setblock 330 264 571 minecraft:oak_leaves[persistent=true]
fill 330 264 584 330 264 585 minecraft:green_terracotta
setblock 330 264 586 minecraft:oak_log
fill 330 264 587 330 267 587 minecraft:green_terracotta
setblock 330 264 591 minecraft:oak_log
fill 330 264 592 330 267 592 minecraft:green_terracotta
setblock 330 264 596 minecraft:oak_leaves[persistent=true]
setblock 331 264 585 minecraft:oak_log
fill 331 264 586 331 267 586 minecraft:green_terracotta
setblock 331 264 589 minecraft:green_terracotta
setblock 332 264 560 minecraft:light[level=14]
setblock 332 264 568 minecraft:light[level=14]
setblock 332 264 576 minecraft:light[level=14]
setblock 332 264 584 minecraft:light[level=14]
setblock 332 264 592 minecraft:light[level=14]
setblock 332 264 598 minecraft:green_terracotta
setblock 333 264 558 minecraft:oak_log
setblock 333 264 598 minecraft:oak_log
setblock 334 264 558 minecraft:green_terracotta
fill 334 264 598 337 264 598 minecraft:green_terracotta
fill 337 264 597 338 264 597 minecraft:green_terracotta
setblock 338 264 558 minecraft:oak_log
setblock 338 264 559 minecraft:green_terracotta
setblock 338 264 598 minecraft:oak_log
fill 339 264 558 339 265 558 minecraft:green_terracotta
fill 339 264 598 339 266 598 minecraft:green_terracotta
setblock 340 264 560 minecraft:light[level=14]
setblock 340 264 568 minecraft:light[level=14]
setblock 340 264 576 minecraft:light[level=14]
setblock 340 264 584 minecraft:light[level=14]
setblock 340 264 592 minecraft:light[level=14]
setblock 347 264 558 minecraft:oak_leaves[persistent=true]
setblock 347 264 598 minecraft:oak_leaves[persistent=true]
setblock 348 264 560 minecraft:light[level=14]
setblock 348 264 576 minecraft:light[level=14]
setblock 348 264 584 minecraft:light[level=14]
setblock 348 264 592 minecraft:light[level=14]
fill 354 264 558 354 265 558 minecraft:green_terracotta
setblock 356 264 560 minecraft:oak_log
setblock 356 264 568 minecraft:light[level=14]
setblock 356 264 576 minecraft:light[level=14]
setblock 356 264 592 minecraft:light[level=14]
setblock 357 264 559 minecraft:oak_log
fill 357 264 560 357 265 560 minecraft:green_terracotta
setblock 358 264 558 minecraft:oak_log
fill 358 264 559 358 267 559 minecraft:green_terracotta
fill 359 264 558 359 267 558 minecraft:green_terracotta
setblock 359 264 561 minecraft:green_terracotta
setblock 359 264 598 minecraft:green_terracotta
setblock 360 264 561 minecraft:oak_log
setblock 361 264 560 minecraft:oak_log
setblock 361 264 561 minecraft:green_terracotta
setblock 362 264 559 minecraft:oak_log
fill 362 264 560 362 265 560 minecraft:green_terracotta
setblock 363 264 558 minecraft:oak_log
fill 363 264 559 363 265 559 minecraft:green_terracotta
fill 364 264 558 364 266 558 minecraft:green_terracotta
setblock 364 264 568 minecraft:light[level=14]
setblock 364 264 576 minecraft:light[level=14]
setblock 364 264 584 minecraft:light[level=14]
setblock 364 264 592 minecraft:light[level=14]
setblock 367 264 559 minecraft:oak_log
setblock 368 264 558 minecraft:oak_log
fill 369 264 558 369 265 558 minecraft:green_terracotta
setblock 369 264 562 minecraft:oak_log
fill 369 264 563 369 265 563 minecraft:green_terracotta
setblock 370 264 561 minecraft:oak_log
fill 370 264 562 370 267 562 minecraft:green_terracotta
setblock 370 264 566 minecraft:oak_log
fill 370 264 567 370 267 567 minecraft:green_terracotta
fill 370 264 579 370 265 579 minecraft:oak_leaves[persistent=true]
setblock 370 264 585 minecraft:oak_leaves[persistent=true]
setblock 330 265 558 minecraft:oak_leaves[persistent=true]
setblock 330 265 577 minecraft:oak_leaves[persistent=true]
setblock 330 265 584 minecraft:green_terracotta
setblock 330 265 585 minecraft:oak_log
fill 330 265 586 330 268 586 minecraft:green_terracotta
setblock 330 265 590 minecraft:oak_log
fill 330 265 591 330 268 591 minecraft:green_terracotta
fill 330 265 593 330 266 593 minecraft:green_terracotta
fill 331 265 585 331 268 585 minecraft:green_terracotta
setblock 331 265 589 minecraft:oak_log
fill 331 265 590 331 268 590 minecraft:green_terracotta
fill 333 265 598 336 265 598 minecraft:green_terracotta
setblock 337 265 558 minecraft:oak_log
setblock 337 265 598 minecraft:oak_log
setblock 338 265 558 minecraft:green_terracotta
fill 338 265 598 338 267 598 minecraft:green_terracotta
setblock 341 265 558 minecraft:oak_leaves[persistent=true]
setblock 353 265 598 minecraft:oak_leaves[persistent=true]
setblock 356 265 559 minecraft:oak_log
setblock 357 265 558 minecraft:oak_log
fill 357 265 559 357 268 559 minecraft:green_terracotta
fill 358 265 558 358 268 558 minecraft:green_terracotta
fill 358 265 560 358 266 560 minecraft:green_terracotta
fill 359 265 598 359 266 598 minecraft:oak_leaves[persistent=true]
setblock 360 265 560 minecraft:oak_log
setblock 361 265 559 minecraft:oak_log
setblock 361 265 560 minecraft:green_terracotta
setblock 362 265 558 minecraft:oak_log
fill 362 265 559 362 266 559 minecraft:green_terracotta
fill 363 265 558 363 267 558 minecraft:green_terracotta
setblock 367 265 558 minecraft:oak_log
setblock 368 265 558 minecraft:green_terracotta
setblock 370 265 560 minecraft:oak_log
fill 370 265 561 370 267 561 minecraft:green_terracotta
setblock 370 265 565 minecraft:oak_log
fill 370 265 566 370 268 566 minecraft:green_terracotta
setblock 370 265 573 minecraft:oak_leaves[persistent=true]
setblock 330 266 564 minecraft:oak_leaves[persistent=true]
setblock 330 266 583 minecraft:oak_leaves[persistent=true]
setblock 330 266 584 minecraft:oak_log
fill 330 266 585 330 269 585 minecraft:green_terracotta
setblock 330 266 588 minecraft:green_terracotta
setblock 330 266 589 minecraft:oak_log
fill 330 266 590 330 269 590 minecraft:green_terracotta
setblock 331 266 588 minecraft:oak_log
fill 331 266 589 331 269 589 minecraft:green_terracotta
fill 331 266 591 331 267 591 minecraft:green_terracotta
fill 333 266 598 335 266 598 minecraft:green_terracotta
setblock 335 266 558 minecraft:oak_leaves[persistent=true]
setblock 336 266 598 minecraft:oak_log
fill 337 266 598 337 269 598 minecraft:green_terracotta
setblock 340 266 598 minecraft:oak_leaves[persistent=true]
setblock 356 266 558 minecraft:oak_log
fill 356 266 559 356 267 559 minecraft:green_terracotta
fill 357 266 558 357 269 558 minecraft:green_terracotta
setblock 359 266 560 minecraft:oak_log
setblock 360 266 559 minecraft:oak_log
setblock 360 266 560 minecraft:green_terracotta
setblock 361 266 558 minecraft:oak_log
setblock 361 266 559 minecraft:green_terracotta
fill 362 266 558 362 268 558 minecraft:green_terracotta
setblock 365 266 598 minecraft:oak_leaves[persistent=true]
setblock 370 266 560 minecraft:green_terracotta
setblock 370 266 564 minecraft:oak_log
fill 370 266 565 370 269 565 minecraft:green_terracotta
setblock 370 266 592 minecraft:oak_leaves[persistent=true]
setblock 330 267 570 minecraft:oak_leaves[persistent=true]
fill 330 267 584 330 270 584 minecraft:green_terracotta
setblock 330 267 588 minecraft:oak_log
fill 330 267 589 330 270 589 minecraft:green_terracotta
setblock 330 267 593 minecraft:oak_log
fill 330 267 594 330 270 594 minecraft:green_terracotta
setblock 330 267 595 minecraft:oak_leaves[persistent=true]
setblock 331 267 587 minecraft:oak_log
fill 331 267 588 332 269 588 minecraft:green_terracotta
setblock 331 267 592 minecraft:oak_log
fill 332 267 587 332 270 587 minecraft:green_terracotta
fill 332 267 589 332 267 590 minecraft:green_terracotta
fill 333 267 598 334 267 598 minecraft:green_terracotta
setblock 335 267 598 minecraft:oak_log
fill 336 267 598 336 270 598 minecraft:green_terracotta
setblock 346 267 598 minecraft:oak_leaves[persistent=true]
setblock 354 267 558 minecraft:oak_leaves[persistent=true]
setblock 355 267 558 minecraft:oak_log
fill 356 267 558 356 270 558 minecraft:green_terracotta
setblock 359 267 559 minecraft:oak_log
setblock 360 267 558 minecraft:oak_log
setblock 360 267 559 minecraft:green_terracotta
fill 361 267 558 361 270 558 minecraft:green_terracotta
setblock 370 267 563 minecraft:oak_log
fill 370 267 564 370 270 564 minecraft:green_terracotta
setblock 370 267 586 minecraft:oak_leaves[persistent=true]
setblock 370 267 588 minecraft:oak_log
fill 370 267 589 370 268 591 minecraft:green_terracotta
setblock 330 268 576 minecraft:oak_leaves[persistent=true]
setblock 330 268 587 minecraft:oak_log
fill 330 268 588 330 271 588 minecraft:green_terracotta
setblock 330 268 592 minecraft:oak_log
fill 330 268 593 331 270 593 minecraft:green_terracotta
fill 330 268 595 330 269 595 minecraft:green_terracotta
setblock 331 268 586 minecraft:oak_log
fill 331 268 587 331 271 587 minecraft:green_terracotta
setblock 331 268 591 minecraft:oak_log
fill 331 268 592 331 271 592 minecraft:green_terracotta
setblock 332 268 589 minecraft:green_terracotta
setblock 332 268 590 minecraft:oak_log
fill 332 268 591 332 271 591 minecraft:green_terracotta
setblock 333 268 598 minecraft:green_terracotta
setblock 334 268 598 minecraft:oak_log
fill 335 268 598 335 271 598 minecraft:green_terracotta
setblock 348 268 558 minecraft:oak_leaves[persistent=true]
setblock 352 268 598 minecraft:oak_leaves[persistent=true]
setblock 354 268 558 minecraft:oak_log
fill 355 268 558 355 271 558 minecraft:green_terracotta
setblock 358 268 559 minecraft:oak_log
setblock 359 268 558 minecraft:oak_log
setblock 359 268 559 minecraft:green_terracotta
fill 360 268 558 360 271 558 minecraft:green_terracotta
setblock 367 268 558 minecraft:oak_leaves[persistent=true]
setblock 370 268 562 minecraft:oak_log
fill 370 268 563 370 271 563 minecraft:green_terracotta
setblock 370 268 567 minecraft:oak_log
fill 370 268 568 370 271 568 minecraft:green_terracotta
setblock 370 268 580 minecraft:oak_leaves[persistent=true]
setblock 370 268 587 minecraft:oak_log
fill 370 268 588 370 271 588 minecraft:green_terracotta
setblock 370 268 592 minecraft:oak_log
fill 370 268 593 370 271 593 minecraft:green_terracotta
setblock 330 269 563 minecraft:oak_leaves[persistent=true]
setblock 330 269 582 minecraft:oak_leaves[persistent=true]
setblock 330 269 586 minecraft:oak_log
fill 330 269 587 330 272 587 minecraft:green_terracotta
setblock 330 269 591 minecraft:oak_log
fill 330 269 592 330 272 592 minecraft:green_terracotta
setblock 330 269 596 minecraft:oak_log
fill 330 269 597 330 272 597 minecraft:green_terracotta
setblock 331 269 585 minecraft:oak_log
fill 331 269 586 332 271 586 minecraft:green_terracotta
setblock 331 269 590 minecraft:oak_log
fill 331 269 591 331 272 591 minecraft:green_terracotta
setblock 331 269 594 minecraft:green_terracotta
setblock 331 269 595 minecraft:oak_log
fill 331 269 598 332 269 598 minecraft:green_terracotta
setblock 332 269 589 minecraft:oak_log
fill 332 269 590 332 272 590 minecraft:green_terracotta
fill 332 269 592 332 269 593 minecraft:green_terracotta
fill 333 269 589 333 272 589 minecraft:green_terracotta
setblock 333 269 598 minecraft:oak_log
fill 334 269 598 334 272 598 minecraft:green_terracotta
setblock 339 269 598 minecraft:oak_leaves[persistent=true]
setblock 342 269 558 minecraft:oak_leaves[persistent=true]
fill 354 269 558 354 272 558 minecraft:green_terracotta
setblock 356 269 559 minecraft:green_terracotta
setblock 357 269 559 minecraft:oak_log
setblock 358 269 558 minecraft:oak_log
fill 358 269 559 358 272 559 minecraft:green_terracotta
setblock 358 269 598 minecraft:oak_leaves[persistent=true]
fill 359 269 558 359 272 558 minecraft:green_terracotta
fill 370 269 562 370 272 562 minecraft:green_terracotta
setblock 370 269 566 minecraft:oak_log
fill 370 269 567 370 272 567 minecraft:green_terracotta
fill 370 269 569 370 270 569 minecraft:green_terracotta
setblock 370 269 574 minecraft:oak_leaves[persistent=true]
fill 370 269 587 370 272 587 minecraft:green_terracotta
fill 370 269 589 370 269 590 minecraft:green_terracotta
setblock 370 269 591 minecraft:oak_log
fill 370 269 592 370 272 592 minecraft:green_terracotta
fill 370 269 594 370 269 595 minecraft:green_terracotta
setblock 370 269 596 minecraft:oak_log
fill 330 270 564 331 270 565 minecraft:oak_leaves[persistent=true]
fill 330 270 566 330 270 569 minecraft:green_terracotta
setblock 330 270 570 minecraft:oak_log
fill 330 270 583 330 271 583 minecraft:green_terracotta
setblock 330 270 585 minecraft:oak_log
fill 330 270 586 330 273 586 minecraft:green_terracotta
setblock 330 270 590 minecraft:oak_log
fill 330 270 591 330 273 591 minecraft:green_terracotta
setblock 330 270 595 minecraft:oak_log
fill 330 270 596 331 272 596 minecraft:green_terracotta
fill 330 270 598 331 270 598 minecraft:green_terracotta
fill 331 270 563 335 270 563 minecraft:oak_leaves[persistent=true]
fill 331 270 566 331 271 567 minecraft:oak_leaves[persistent=true]
setblock 331 270 584 minecraft:oak_log
fill 331 270 585 331 273 585 minecraft:green_terracotta
setblock 331 270 588 minecraft:green_terracotta
setblock 331 270 589 minecraft:oak_log
fill 331 270 590 331 273 590 minecraft:green_terracotta
setblock 331 270 594 minecraft:oak_log
fill 331 270 595 331 273 595 minecraft:green_terracotta
fill 332 270 567 334 270 568 minecraft:oak_leaves[persistent=true]
setblock 332 270 588 minecraft:oak_log
fill 332 270 589 332 273 589 minecraft:green_terracotta
setblock 332 270 592 minecraft:green_terracotta
setblock 332 270 593 minecraft:oak_log
fill 332 270 594 332 273 594 minecraft:green_terracotta
setblock 332 270 598 minecraft:oak_log
setblock 333 270 562 minecraft:oak_leaves[persistent=true]
fill 333 270 588 333 273 588 minecraft:green_terracotta
fill 333 270 590 333 270 591 minecraft:green_terracotta
schedule function dropper:buildpart/139_8 1t
