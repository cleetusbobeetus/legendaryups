fill 399 122 463 399 129 463 minecraft:magenta_concrete
setblock 403 122 466 minecraft:light[level=14]
setblock 403 122 474 minecraft:light[level=14]
setblock 403 122 482 minecraft:light[level=14]
setblock 403 122 490 minecraft:light[level=14]
setblock 403 122 498 minecraft:light[level=14]
fill 403 122 505 403 129 505 minecraft:magenta_concrete
fill 407 122 463 407 129 463 minecraft:magenta_concrete
setblock 411 122 466 minecraft:light[level=14]
setblock 411 122 474 minecraft:light[level=14]
setblock 411 122 482 minecraft:light[level=14]
setblock 411 122 490 minecraft:light[level=14]
setblock 411 122 498 minecraft:light[level=14]
fill 411 122 505 411 129 505 minecraft:magenta_concrete
fill 415 122 463 415 129 463 minecraft:magenta_concrete
fill 418 122 468 418 129 468 minecraft:magenta_concrete
fill 418 122 476 418 129 476 minecraft:magenta_concrete
fill 418 122 484 418 129 484 minecraft:magenta_concrete
fill 418 122 492 418 129 492 minecraft:magenta_concrete
fill 418 122 500 418 129 500 minecraft:magenta_concrete
fill 397 123 486 399 125 488 minecraft:cyan_concrete
fill 377 126 464 377 127 469 minecraft:black_concrete
fill 377 126 472 378 126 477 minecraft:black_concrete
fill 377 126 480 378 126 485 minecraft:black_concrete
fill 377 126 488 378 126 493 minecraft:black_concrete
fill 377 126 496 378 126 501 minecraft:black_concrete
fill 377 126 504 382 127 504 minecraft:black_concrete
fill 378 126 465 378 126 471 minecraft:black_concrete
fill 378 126 478 378 126 479 minecraft:black_concrete
fill 378 126 486 378 126 487 minecraft:black_concrete
fill 378 126 494 378 126 495 minecraft:black_concrete
fill 378 126 502 378 126 503 minecraft:black_concrete
fill 379 126 465 416 126 465 minecraft:black_concrete
fill 379 126 503 417 126 503 minecraft:black_concrete
fill 380 126 464 385 127 464 minecraft:black_concrete
fill 385 126 504 390 127 504 minecraft:black_concrete
fill 388 126 464 393 127 464 minecraft:black_concrete
fill 393 126 504 398 127 504 minecraft:black_concrete
fill 396 126 464 401 127 464 minecraft:black_concrete
fill 401 126 504 406 127 504 minecraft:black_concrete
fill 404 126 464 409 127 464 minecraft:black_concrete
fill 409 126 504 414 127 504 minecraft:black_concrete
fill 412 126 464 417 127 464 minecraft:black_concrete
fill 416 126 466 416 126 502 minecraft:black_concrete
fill 417 126 467 417 127 472 minecraft:black_concrete
fill 417 126 475 417 127 480 minecraft:black_concrete
fill 417 126 483 417 127 488 minecraft:black_concrete
fill 417 126 491 417 127 496 minecraft:black_concrete
fill 417 126 499 417 127 502 minecraft:black_concrete
fill 417 126 504 417 127 504 minecraft:black_concrete
fill 377 127 472 377 127 477 minecraft:black_concrete
fill 377 127 480 377 127 485 minecraft:black_concrete
fill 377 127 488 377 127 493 minecraft:black_concrete
fill 377 127 496 377 127 501 minecraft:black_concrete
setblock 417 127 503 minecraft:black_concrete
fill 377 128 475 382 129 475 minecraft:black_concrete
fill 379 129 474 396 129 474 minecraft:black_concrete
fill 383 129 475 390 129 475 minecraft:black_concrete
fill 398 129 477 399 130 478 minecraft:black_concrete
fill 376 130 468 376 135 468 minecraft:sea_lantern
fill 376 130 476 376 135 476 minecraft:sea_lantern
fill 376 130 484 376 135 484 minecraft:sea_lantern
fill 376 130 492 376 135 492 minecraft:sea_lantern
fill 376 130 500 376 135 500 minecraft:sea_lantern
fill 377 130 475 383 130 475 minecraft:magenta_concrete
setblock 379 130 466 minecraft:light[level=14]
setblock 379 130 474 minecraft:light[level=14]
setblock 379 130 482 minecraft:light[level=14]
setblock 379 130 490 minecraft:light[level=14]
setblock 379 130 498 minecraft:light[level=14]
fill 379 130 505 379 135 505 minecraft:sea_lantern
fill 383 130 463 383 135 463 minecraft:sea_lantern
fill 385 130 475 391 130 475 minecraft:black_concrete
fill 386 130 474 404 130 474 minecraft:black_concrete
setblock 387 130 466 minecraft:light[level=14]
setblock 387 130 482 minecraft:light[level=14]
setblock 387 130 490 minecraft:light[level=14]
setblock 387 130 498 minecraft:light[level=14]
fill 387 130 505 387 135 505 minecraft:sea_lantern
fill 391 130 463 391 135 463 minecraft:sea_lantern
fill 394 130 473 409 130 473 minecraft:black_concrete
setblock 395 130 466 minecraft:light[level=14]
setblock 395 130 490 minecraft:light[level=14]
setblock 395 130 498 minecraft:light[level=14]
fill 395 130 505 395 135 505 minecraft:sea_lantern
fill 399 130 463 399 135 463 minecraft:sea_lantern
setblock 403 130 466 minecraft:light[level=14]
setblock 403 130 482 minecraft:light[level=14]
setblock 403 130 490 minecraft:light[level=14]
setblock 403 130 498 minecraft:light[level=14]
fill 403 130 505 403 135 505 minecraft:sea_lantern
fill 407 130 463 407 135 463 minecraft:sea_lantern
setblock 411 130 466 minecraft:light[level=14]
setblock 411 130 474 minecraft:light[level=14]
setblock 411 130 482 minecraft:light[level=14]
setblock 411 130 490 minecraft:light[level=14]
setblock 411 130 498 minecraft:light[level=14]
fill 411 130 505 411 135 505 minecraft:sea_lantern
fill 415 130 463 415 135 463 minecraft:sea_lantern
fill 418 130 468 418 135 468 minecraft:sea_lantern
fill 418 130 476 418 135 476 minecraft:sea_lantern
fill 418 130 484 418 135 484 minecraft:sea_lantern
fill 418 130 492 418 135 492 minecraft:sea_lantern
fill 418 130 500 418 135 500 minecraft:sea_lantern
fill 387 131 474 397 131 474 minecraft:magenta_concrete
fill 390 131 478 393 134 481 minecraft:magenta_concrete
fill 398 131 474 407 131 474 minecraft:black_concrete
fill 399 131 473 416 131 473 minecraft:black_concrete
fill 408 131 472 417 131 472 minecraft:black_concrete
fill 401 132 473 409 132 473 minecraft:magenta_concrete
fill 410 132 473 416 132 473 minecraft:black_concrete
fill 413 132 472 417 132 472 minecraft:black_concrete
fill 412 133 473 414 133 473 minecraft:magenta_concrete
fill 415 133 472 416 133 472 minecraft:magenta_concrete
fill 376 136 468 376 143 468 minecraft:magenta_concrete
fill 376 136 476 376 143 476 minecraft:magenta_concrete
fill 376 136 484 376 143 484 minecraft:magenta_concrete
fill 376 136 492 376 143 492 minecraft:magenta_concrete
fill 376 136 500 376 143 500 minecraft:magenta_concrete
fill 379 136 505 379 143 505 minecraft:magenta_concrete
fill 383 136 463 383 143 463 minecraft:magenta_concrete
fill 387 136 505 387 143 505 minecraft:magenta_concrete
fill 391 136 463 391 143 463 minecraft:magenta_concrete
fill 395 136 505 395 143 505 minecraft:magenta_concrete
fill 399 136 463 399 143 463 minecraft:magenta_concrete
fill 403 136 505 403 143 505 minecraft:magenta_concrete
fill 407 136 463 407 143 463 minecraft:magenta_concrete
fill 411 136 505 411 143 505 minecraft:magenta_concrete
fill 415 136 463 415 143 463 minecraft:magenta_concrete
fill 418 136 468 418 143 468 minecraft:magenta_concrete
fill 418 136 476 418 143 476 minecraft:magenta_concrete
fill 418 136 484 418 143 484 minecraft:magenta_concrete
fill 418 136 492 418 143 492 minecraft:magenta_concrete
fill 418 136 500 418 143 500 minecraft:magenta_concrete
setblock 379 138 466 minecraft:light[level=14]
setblock 379 138 474 minecraft:light[level=14]
setblock 379 138 482 minecraft:light[level=14]
setblock 379 138 490 minecraft:light[level=14]
setblock 379 138 498 minecraft:light[level=14]
setblock 387 138 466 minecraft:light[level=14]
setblock 387 138 474 minecraft:light[level=14]
setblock 387 138 482 minecraft:light[level=14]
setblock 387 138 490 minecraft:light[level=14]
setblock 387 138 498 minecraft:light[level=14]
setblock 395 138 466 minecraft:light[level=14]
setblock 395 138 474 minecraft:light[level=14]
setblock 395 138 490 minecraft:light[level=14]
setblock 395 138 498 minecraft:light[level=14]
setblock 403 138 466 minecraft:light[level=14]
setblock 403 138 474 minecraft:light[level=14]
setblock 403 138 482 minecraft:light[level=14]
setblock 403 138 490 minecraft:light[level=14]
setblock 403 138 498 minecraft:light[level=14]
setblock 411 138 466 minecraft:light[level=14]
setblock 411 138 474 minecraft:light[level=14]
setblock 411 138 482 minecraft:light[level=14]
setblock 411 138 490 minecraft:light[level=14]
setblock 411 138 498 minecraft:light[level=14]
fill 377 140 464 377 141 469 minecraft:black_concrete
fill 377 140 472 378 140 477 minecraft:black_concrete
fill 377 140 480 378 140 485 minecraft:black_concrete
fill 377 140 488 378 140 493 minecraft:black_concrete
fill 377 140 496 378 140 501 minecraft:black_concrete
fill 377 140 504 382 141 504 minecraft:black_concrete
fill 378 140 465 378 140 471 minecraft:black_concrete
fill 378 140 478 378 140 479 minecraft:black_concrete
fill 378 140 486 378 140 487 minecraft:black_concrete
fill 378 140 494 378 140 495 minecraft:black_concrete
fill 378 140 502 378 140 503 minecraft:black_concrete
fill 379 140 465 416 140 465 minecraft:black_concrete
fill 379 140 503 417 140 503 minecraft:black_concrete
fill 380 140 464 385 141 464 minecraft:black_concrete
fill 385 140 488 388 143 491 minecraft:white_concrete
fill 385 140 504 390 141 504 minecraft:black_concrete
fill 388 140 464 393 141 464 minecraft:black_concrete
fill 388 140 467 388 145 467 minecraft:magenta_concrete
fill 393 140 504 398 141 504 minecraft:black_concrete
fill 396 140 464 401 141 464 minecraft:black_concrete
fill 401 140 504 406 141 504 minecraft:black_concrete
fill 404 140 464 409 141 464 minecraft:black_concrete
fill 409 140 504 414 141 504 minecraft:black_concrete
fill 412 140 464 417 141 464 minecraft:black_concrete
fill 416 140 466 416 140 502 minecraft:black_concrete
fill 417 140 467 417 141 472 minecraft:black_concrete
fill 417 140 475 417 141 480 minecraft:black_concrete
fill 417 140 483 417 141 488 minecraft:black_concrete
fill 417 140 491 417 141 496 minecraft:black_concrete
fill 417 140 499 417 141 502 minecraft:black_concrete
fill 417 140 504 417 141 504 minecraft:black_concrete
fill 377 141 472 377 141 477 minecraft:black_concrete
fill 377 141 480 377 141 485 minecraft:black_concrete
fill 377 141 488 377 141 493 minecraft:black_concrete
fill 377 141 496 377 141 501 minecraft:black_concrete
setblock 417 141 503 minecraft:black_concrete
fill 387 142 467 387 145 467 minecraft:magenta_concrete
fill 388 142 466 388 145 466 minecraft:magenta_concrete
fill 389 142 467 389 145 467 minecraft:magenta_concrete
fill 381 143 491 381 148 491 minecraft:magenta_concrete
fill 387 143 466 387 145 466 minecraft:magenta_concrete
fill 387 143 468 389 145 468 minecraft:magenta_concrete
fill 389 143 466 389 145 466 minecraft:magenta_concrete
fill 376 144 468 376 149 468 minecraft:sea_lantern
fill 376 144 476 376 149 476 minecraft:sea_lantern
fill 376 144 484 376 149 484 minecraft:sea_lantern
fill 376 144 492 376 149 492 minecraft:sea_lantern
fill 376 144 500 376 149 500 minecraft:sea_lantern
fill 379 144 505 379 149 505 minecraft:sea_lantern
fill 382 144 491 382 148 491 minecraft:magenta_concrete
fill 383 144 463 383 149 463 minecraft:sea_lantern
fill 386 144 467 386 145 467 minecraft:magenta_concrete
fill 387 144 465 389 145 465 minecraft:magenta_concrete
fill 387 144 505 387 149 505 minecraft:sea_lantern
fill 390 144 467 390 145 467 minecraft:magenta_concrete
fill 391 144 463 391 149 463 minecraft:sea_lantern
fill 395 144 505 395 149 505 minecraft:sea_lantern
fill 399 144 463 399 149 463 minecraft:sea_lantern
fill 403 144 505 403 149 505 minecraft:sea_lantern
fill 407 144 463 407 149 463 minecraft:sea_lantern
fill 411 144 505 411 149 505 minecraft:sea_lantern
fill 415 144 463 415 149 463 minecraft:sea_lantern
fill 418 144 468 418 149 468 minecraft:sea_lantern
fill 418 144 476 418 149 476 minecraft:sea_lantern
fill 418 144 484 418 149 484 minecraft:sea_lantern
fill 418 144 492 418 149 492 minecraft:sea_lantern
fill 418 144 500 418 149 500 minecraft:sea_lantern
fill 380 145 491 380 148 491 minecraft:magenta_concrete
fill 381 145 490 382 148 490 minecraft:magenta_concrete
fill 381 145 492 382 148 492 minecraft:magenta_concrete
setblock 386 145 466 minecraft:magenta_concrete
setblock 386 145 468 minecraft:magenta_concrete
fill 387 145 469 389 145 469 minecraft:magenta_concrete
setblock 390 145 466 minecraft:magenta_concrete
setblock 390 145 468 minecraft:magenta_concrete
setblock 379 146 466 minecraft:light[level=14]
setblock 379 146 474 minecraft:light[level=14]
setblock 379 146 482 minecraft:light[level=14]
setblock 379 146 490 minecraft:light[level=14]
setblock 379 146 498 minecraft:light[level=14]
fill 380 146 490 380 148 490 minecraft:magenta_concrete
fill 380 146 492 380 148 492 minecraft:magenta_concrete
fill 381 146 489 382 148 489 minecraft:magenta_concrete
fill 381 146 493 382 148 493 minecraft:magenta_concrete
fill 383 146 490 383 148 492 minecraft:magenta_concrete
fill 385 146 464 385 163 470 minecraft:black_concrete
fill 386 146 465 391 163 470 minecraft:black_concrete
setblock 387 146 474 minecraft:light[level=14]
setblock 387 146 482 minecraft:light[level=14]
setblock 387 146 490 minecraft:light[level=14]
setblock 387 146 498 minecraft:light[level=14]
fill 388 146 464 391 163 464 minecraft:black_concrete
setblock 395 146 466 minecraft:light[level=14]
setblock 395 146 474 minecraft:light[level=14]
setblock 395 146 490 minecraft:light[level=14]
setblock 395 146 498 minecraft:light[level=14]
setblock 403 146 466 minecraft:light[level=14]
setblock 403 146 474 minecraft:light[level=14]
setblock 403 146 482 minecraft:light[level=14]
setblock 403 146 490 minecraft:light[level=14]
setblock 403 146 498 minecraft:light[level=14]
setblock 411 146 466 minecraft:light[level=14]
setblock 411 146 474 minecraft:light[level=14]
setblock 411 146 482 minecraft:light[level=14]
setblock 411 146 490 minecraft:light[level=14]
setblock 411 146 498 minecraft:light[level=14]
fill 379 147 490 379 148 492 minecraft:magenta_concrete
fill 380 147 489 380 148 489 minecraft:magenta_concrete
fill 380 147 493 380 148 493 minecraft:magenta_concrete
fill 383 147 489 383 148 489 minecraft:magenta_concrete
fill 383 147 493 383 148 493 minecraft:magenta_concrete
fill 384 147 491 384 148 491 minecraft:magenta_concrete
fill 409 147 495 417 148 495 minecraft:black_concrete
fill 415 147 496 417 148 496 minecraft:black_concrete
setblock 378 148 491 minecraft:magenta_concrete
setblock 379 148 489 minecraft:magenta_concrete
setblock 379 148 493 minecraft:magenta_concrete
fill 380 148 488 382 148 488 minecraft:magenta_concrete
fill 380 148 494 382 148 494 minecraft:magenta_concrete
setblock 384 148 490 minecraft:magenta_concrete
setblock 384 148 492 minecraft:magenta_concrete
fill 389 148 493 401 148 493 minecraft:black_concrete
fill 395 148 494 411 148 494 minecraft:black_concrete
fill 403 148 495 408 148 495 minecraft:black_concrete
fill 409 148 468 411 150 470 minecraft:white_concrete
fill 413 148 496 414 148 496 minecraft:black_concrete
fill 377 149 488 386 163 493 minecraft:black_concrete
fill 378 149 487 386 163 487 minecraft:black_concrete
fill 378 149 494 386 163 495 minecraft:black_concrete
fill 385 149 484 385 150 486 minecraft:black_concrete
fill 385 149 496 386 150 504 minecraft:black_concrete
fill 387 149 492 391 149 493 minecraft:black_concrete
fill 392 149 493 399 149 493 minecraft:black_concrete
fill 393 149 494 405 149 494 minecraft:black_concrete
fill 408 149 495 416 149 495 minecraft:magenta_concrete
fill 376 150 468 376 157 468 minecraft:magenta_concrete
fill 376 150 476 376 154 476 minecraft:magenta_concrete
fill 376 150 484 376 157 484 minecraft:magenta_concrete
fill 376 150 492 376 157 492 minecraft:magenta_concrete
fill 376 150 500 376 157 500 minecraft:magenta_concrete
fill 379 150 505 379 157 505 minecraft:magenta_concrete
fill 383 150 463 383 157 463 minecraft:magenta_concrete
fill 384 150 464 384 150 486 minecraft:black_concrete
fill 385 150 471 385 151 483 minecraft:black_concrete
fill 387 150 505 387 153 505 minecraft:magenta_concrete
fill 388 150 493 397 150 493 minecraft:magenta_concrete
fill 391 150 463 391 157 463 minecraft:magenta_concrete
fill 395 150 505 395 157 505 minecraft:magenta_concrete
fill 397 150 494 404 150 494 minecraft:magenta_concrete
fill 399 150 463 399 157 463 minecraft:magenta_concrete
fill 403 150 505 403 153 505 minecraft:magenta_concrete
fill 407 150 463 407 157 463 minecraft:magenta_concrete
fill 411 150 505 411 153 505 minecraft:magenta_concrete
fill 415 150 463 415 157 463 minecraft:magenta_concrete
fill 418 150 468 418 157 468 minecraft:magenta_concrete
fill 418 150 476 418 155 476 minecraft:magenta_concrete
fill 418 150 484 418 154 484 minecraft:magenta_concrete
fill 418 150 492 418 155 492 minecraft:magenta_concrete
fill 418 150 500 418 157 500 minecraft:magenta_concrete
fill 384 151 464 384 151 474 minecraft:black_concrete
fill 385 151 484 385 151 486 minecraft:magenta_concrete
fill 385 151 496 385 151 503 minecraft:magenta_concrete
fill 386 151 502 386 151 503 minecraft:magenta_concrete
fill 384 152 464 384 152 470 minecraft:magenta_concrete
fill 385 152 474 385 152 479 minecraft:magenta_concrete
fill 376 154 477 376 157 480 minecraft:magenta_concrete
fill 376 154 481 378 154 481 minecraft:black_concrete
fill 376 154 482 376 157 483 minecraft:magenta_concrete
fill 376 154 488 376 155 488 minecraft:magenta_concrete
setblock 376 154 489 minecraft:black_concrete
fill 376 154 501 378 154 501 minecraft:black_concrete
fill 377 154 464 377 155 469 minecraft:black_concrete
fill 377 154 472 378 154 477 minecraft:black_concrete
fill 377 154 480 378 154 480 minecraft:black_concrete
fill 377 154 482 378 154 485 minecraft:black_concrete
fill 377 154 496 378 154 500 minecraft:black_concrete
fill 377 154 504 382 155 504 minecraft:black_concrete
fill 378 154 465 378 154 471 minecraft:black_concrete
fill 378 154 478 378 154 479 minecraft:black_concrete
setblock 378 154 486 minecraft:black_concrete
fill 378 154 502 378 154 503 minecraft:black_concrete
fill 379 154 465 384 154 465 minecraft:black_concrete
setblock 379 154 466 minecraft:light[level=14]
setblock 379 154 474 minecraft:light[level=14]
setblock 379 154 482 minecraft:light[level=14]
setblock 379 154 498 minecraft:light[level=14]
fill 379 154 503 417 154 503 minecraft:black_concrete
fill 380 154 464 384 155 464 minecraft:black_concrete
fill 380 154 505 380 156 505 minecraft:black_concrete
fill 381 154 505 382 154 505 minecraft:magenta_concrete
fill 384 154 463 384 157 463 minecraft:magenta_concrete
fill 385 154 463 386 154 463 minecraft:black_concrete
fill 385 154 504 390 155 504 minecraft:black_concrete
fill 387 154 463 387 157 463 minecraft:magenta_concrete
setblock 387 154 474 minecraft:light[level=14]
setblock 387 154 482 minecraft:light[level=14]
setblock 387 154 490 minecraft:light[level=14]
setblock 387 154 498 minecraft:light[level=14]
setblock 387 154 505 minecraft:black_concrete
fill 388 154 463 388 155 463 minecraft:black_concrete
fill 390 154 505 390 155 505 minecraft:black_concrete
fill 392 154 464 393 154 465 minecraft:black_concrete
fill 393 154 504 398 155 504 minecraft:black_concrete
fill 394 154 465 416 154 465 minecraft:black_concrete
setblock 395 154 466 minecraft:light[level=14]
setblock 395 154 474 minecraft:light[level=14]
setblock 395 154 490 minecraft:light[level=14]
setblock 395 154 498 minecraft:light[level=14]
fill 396 154 464 401 155 464 minecraft:black_concrete
setblock 400 154 463 minecraft:black_concrete
fill 401 154 463 406 154 463 minecraft:magenta_concrete
fill 401 154 504 406 155 504 minecraft:black_concrete
setblock 403 154 466 minecraft:light[level=14]
setblock 403 154 474 minecraft:light[level=14]
setblock 403 154 482 minecraft:light[level=14]
setblock 403 154 490 minecraft:light[level=14]
setblock 403 154 498 minecraft:light[level=14]
setblock 403 154 505 minecraft:black_concrete
fill 404 154 464 409 155 464 minecraft:black_concrete
fill 408 154 463 408 157 463 minecraft:magenta_concrete
setblock 409 154 463 minecraft:black_concrete
fill 409 154 504 414 155 504 minecraft:black_concrete
fill 410 154 463 413 157 463 minecraft:magenta_concrete
setblock 411 154 466 minecraft:light[level=14]
setblock 411 154 474 minecraft:light[level=14]
setblock 411 154 482 minecraft:light[level=14]
setblock 411 154 490 minecraft:light[level=14]
setblock 411 154 498 minecraft:light[level=14]
setblock 411 154 505 minecraft:black_concrete
fill 412 154 464 418 154 464 minecraft:black_concrete
fill 416 154 466 416 154 502 minecraft:black_concrete
fill 417 154 467 417 155 472 minecraft:black_concrete
fill 417 154 475 417 155 480 minecraft:black_concrete
fill 417 154 483 417 155 488 minecraft:black_concrete
fill 417 154 491 417 155 496 minecraft:black_concrete
fill 417 154 499 417 155 502 minecraft:black_concrete
fill 417 154 504 417 155 504 minecraft:black_concrete
setblock 418 154 463 minecraft:magenta_concrete
fill 418 154 465 418 157 465 minecraft:magenta_concrete
setblock 418 154 473 minecraft:magenta_concrete
setblock 418 154 474 minecraft:black_concrete
fill 418 154 475 418 159 475 minecraft:magenta_concrete
fill 418 154 477 418 157 479 minecraft:magenta_concrete
setblock 418 154 480 minecraft:black_concrete
fill 418 154 481 418 155 483 minecraft:magenta_concrete
fill 418 154 497 418 157 497 minecraft:magenta_concrete
setblock 418 154 498 minecraft:black_concrete
fill 418 154 499 418 155 499 minecraft:magenta_concrete
setblock 376 155 463 minecraft:black_concrete
fill 376 155 464 376 157 464 minecraft:magenta_concrete
fill 376 155 469 376 157 469 minecraft:magenta_concrete
setblock 376 155 470 minecraft:black_concrete
fill 376 155 471 376 157 472 minecraft:magenta_concrete
fill 376 155 476 377 155 476 minecraft:black_concrete
fill 376 155 481 376 157 481 minecraft:magenta_concrete
fill 376 155 489 376 157 489 minecraft:magenta_concrete
setblock 376 155 495 minecraft:black_concrete
fill 376 155 496 376 155 498 minecraft:magenta_concrete
fill 376 155 499 377 155 499 minecraft:black_concrete
fill 376 155 501 376 157 502 minecraft:magenta_concrete
setblock 376 155 503 minecraft:black_concrete
setblock 376 155 504 minecraft:magenta_concrete
setblock 376 155 505 minecraft:black_concrete
fill 377 155 472 377 155 475 minecraft:black_concrete
setblock 377 155 477 minecraft:black_concrete
fill 377 155 480 377 155 485 minecraft:black_concrete
fill 377 155 496 377 155 498 minecraft:black_concrete
fill 377 155 500 377 155 501 minecraft:black_concrete
fill 377 155 505 378 157 505 minecraft:magenta_concrete
setblock 379 155 463 minecraft:black_concrete
fill 381 155 505 381 156 505 minecraft:black_concrete
setblock 382 155 463 minecraft:black_concrete
fill 382 155 505 382 157 505 minecraft:magenta_concrete
fill 385 155 463 386 157 463 minecraft:magenta_concrete
fill 387 155 505 387 157 505 minecraft:magenta_concrete
fill 391 155 505 391 158 505 minecraft:magenta_concrete
fill 392 155 463 392 155 464 minecraft:black_concrete
setblock 392 155 505 minecraft:black_concrete
fill 393 155 463 393 157 463 minecraft:magenta_concrete
setblock 393 155 464 minecraft:black_concrete
fill 393 155 505 394 157 505 minecraft:magenta_concrete
fill 395 155 463 396 157 463 minecraft:magenta_concrete
fill 396 155 505 397 155 505 minecraft:black_concrete
setblock 397 155 463 minecraft:black_concrete
fill 398 155 505 409 155 505 minecraft:magenta_concrete
fill 400 155 463 405 155 463 minecraft:magenta_concrete
setblock 406 155 463 minecraft:black_concrete
fill 409 155 463 409 158 463 minecraft:magenta_concrete
setblock 410 155 505 minecraft:black_concrete
fill 411 155 505 414 155 505 minecraft:magenta_concrete
fill 412 155 464 417 155 464 minecraft:black_concrete
setblock 414 155 463 minecraft:black_concrete
setblock 415 155 505 minecraft:black_concrete
fill 416 155 505 418 155 505 minecraft:magenta_concrete
setblock 417 155 503 minecraft:black_concrete
setblock 418 155 463 minecraft:black_concrete
fill 418 155 464 418 157 464 minecraft:magenta_concrete
setblock 418 155 473 minecraft:black_concrete
setblock 418 155 474 minecraft:magenta_concrete
fill 418 155 480 418 157 480 minecraft:magenta_concrete
setblock 418 155 484 minecraft:black_concrete
fill 418 155 498 418 157 498 minecraft:magenta_concrete
fill 376 156 463 376 157 463 minecraft:magenta_concrete
fill 376 156 470 376 157 470 minecraft:magenta_concrete
fill 376 156 475 376 156 476 minecraft:black_concrete
setblock 376 156 488 minecraft:black_concrete
fill 376 156 495 376 157 497 minecraft:magenta_concrete
setblock 376 156 498 minecraft:black_concrete
fill 376 156 499 376 157 499 minecraft:magenta_concrete
fill 376 156 503 376 157 503 minecraft:magenta_concrete
setblock 376 156 504 minecraft:black_concrete
fill 376 156 505 376 157 505 minecraft:magenta_concrete
fill 379 156 463 379 157 463 minecraft:magenta_concrete
fill 382 156 463 382 157 463 minecraft:magenta_concrete
fill 388 156 463 388 157 463 minecraft:magenta_concrete
setblock 389 156 463 minecraft:black_concrete
fill 390 156 505 390 158 505 minecraft:magenta_concrete
fill 392 156 463 392 157 463 minecraft:magenta_concrete
fill 392 156 505 392 157 505 minecraft:magenta_concrete
fill 396 156 505 401 157 505 minecraft:magenta_concrete
fill 397 156 463 397 158 463 minecraft:magenta_concrete
fill 400 156 463 404 157 463 minecraft:magenta_concrete
setblock 402 156 505 minecraft:black_concrete
fill 403 156 505 410 157 505 minecraft:magenta_concrete
setblock 405 156 463 minecraft:black_concrete
fill 406 156 463 406 157 463 minecraft:magenta_concrete
setblock 411 156 505 minecraft:black_concrete
fill 412 156 505 415 157 505 minecraft:magenta_concrete
fill 414 156 463 414 157 463 minecraft:magenta_concrete
setblock 416 156 505 minecraft:black_concrete
fill 417 156 505 418 157 505 minecraft:magenta_concrete
fill 418 156 463 418 157 463 minecraft:magenta_concrete
fill 418 156 473 418 157 473 minecraft:magenta_concrete
setblock 418 156 474 minecraft:black_concrete
setblock 418 156 476 minecraft:black_concrete
fill 418 156 481 418 157 482 minecraft:magenta_concrete
setblock 418 156 483 minecraft:black_concrete
fill 418 156 484 418 157 484 minecraft:magenta_concrete
setblock 418 156 486 minecraft:black_concrete
setblock 418 156 490 minecraft:black_concrete
fill 418 156 491 418 157 491 minecraft:magenta_concrete
setblock 418 156 492 minecraft:black_concrete
fill 418 156 493 418 157 494 minecraft:magenta_concrete
setblock 418 156 495 minecraft:black_concrete
setblock 418 156 499 minecraft:black_concrete
fill 418 156 501 418 157 501 minecraft:magenta_concrete
setblock 418 156 502 minecraft:black_concrete
fill 418 156 503 418 157 504 minecraft:magenta_concrete
fill 376 157 475 376 157 476 minecraft:magenta_concrete
setblock 376 157 488 minecraft:magenta_concrete
setblock 376 157 498 minecraft:magenta_concrete
fill 376 157 504 376 158 504 minecraft:magenta_concrete
fill 380 157 505 381 157 505 minecraft:magenta_concrete
setblock 389 157 463 minecraft:magenta_concrete
fill 402 157 505 402 158 505 minecraft:magenta_concrete
setblock 405 157 463 minecraft:magenta_concrete
setblock 411 157 505 minecraft:magenta_concrete
setblock 416 157 505 minecraft:magenta_concrete
setblock 418 157 474 minecraft:magenta_concrete
setblock 418 157 476 minecraft:magenta_concrete
setblock 418 157 483 minecraft:magenta_concrete
setblock 418 157 486 minecraft:magenta_concrete
setblock 418 157 490 minecraft:magenta_concrete
setblock 418 157 492 minecraft:magenta_concrete
setblock 418 157 495 minecraft:magenta_concrete
setblock 418 157 499 minecraft:magenta_concrete
setblock 418 157 502 minecraft:magenta_concrete
fill 376 158 463 376 159 467 minecraft:black_concrete
fill 376 158 468 376 163 468 minecraft:sea_lantern
fill 376 158 469 376 158 475 minecraft:black_concrete
fill 376 158 476 376 163 476 minecraft:sea_lantern
fill 376 158 477 376 159 483 minecraft:black_concrete
fill 376 158 484 376 163 484 minecraft:sea_lantern
fill 376 158 485 376 158 491 minecraft:black_concrete
fill 376 158 492 376 163 492 minecraft:sea_lantern
fill 376 158 493 376 159 495 minecraft:black_concrete
setblock 376 158 496 minecraft:magenta_concrete
fill 376 158 497 376 158 499 minecraft:black_concrete
fill 376 158 500 376 163 500 minecraft:sea_lantern
fill 376 158 501 376 158 503 minecraft:black_concrete
fill 376 158 505 378 229 505 minecraft:black_concrete
fill 377 158 463 382 228 463 minecraft:black_concrete
fill 379 158 505 379 163 505 minecraft:sea_lantern
fill 380 158 505 384 158 505 minecraft:black_concrete
fill 383 158 463 383 163 463 minecraft:sea_lantern
fill 384 158 463 390 158 463 minecraft:black_concrete
setblock 385 158 505 minecraft:magenta_concrete
fill 386 158 505 386 232 505 minecraft:black_concrete
fill 387 158 505 387 163 505 minecraft:sea_lantern
fill 388 158 505 389 159 505 minecraft:black_concrete
fill 391 158 463 391 163 463 minecraft:sea_lantern
fill 392 158 463 395 229 463 minecraft:black_concrete
fill 392 158 505 394 158 505 minecraft:black_concrete
fill 395 158 505 395 163 505 minecraft:sea_lantern
setblock 396 158 463 minecraft:magenta_concrete
fill 396 158 505 399 229 505 minecraft:black_concrete
fill 398 158 463 398 233 463 minecraft:black_concrete
fill 399 158 463 399 163 463 minecraft:sea_lantern
fill 400 158 463 406 158 463 minecraft:black_concrete
setblock 400 158 505 minecraft:magenta_concrete
fill 401 158 505 401 228 505 minecraft:black_concrete
fill 403 158 505 403 163 505 minecraft:sea_lantern
fill 404 158 505 410 158 505 minecraft:black_concrete
fill 407 158 463 407 163 463 minecraft:sea_lantern
fill 408 158 463 408 232 463 minecraft:black_concrete
fill 410 158 463 414 232 463 minecraft:black_concrete
fill 411 158 505 411 163 505 minecraft:sea_lantern
fill 412 158 505 418 158 505 minecraft:black_concrete
fill 415 158 463 415 163 463 minecraft:sea_lantern
fill 416 158 463 418 229 463 minecraft:black_concrete
fill 418 158 464 418 228 467 minecraft:black_concrete
fill 418 158 468 418 163 468 minecraft:sea_lantern
fill 418 158 469 418 158 474 minecraft:black_concrete
fill 418 158 476 418 163 476 minecraft:sea_lantern
fill 418 158 477 418 158 483 minecraft:black_concrete
fill 418 158 484 418 163 484 minecraft:sea_lantern
fill 418 158 485 418 158 491 minecraft:black_concrete
fill 418 158 492 418 163 492 minecraft:sea_lantern
fill 418 158 493 418 158 499 minecraft:black_concrete
fill 418 158 500 418 163 500 minecraft:sea_lantern
fill 418 158 501 418 159 504 minecraft:black_concrete
fill 376 159 469 376 232 469 minecraft:black_concrete
fill 376 159 470 376 159 471 minecraft:magenta_concrete
fill 376 159 472 376 229 475 minecraft:black_concrete
setblock 376 159 485 minecraft:magenta_concrete
fill 376 159 486 376 228 491 minecraft:black_concrete
fill 376 159 496 376 228 498 minecraft:black_concrete
setblock 376 159 499 minecraft:magenta_concrete
setblock 376 159 501 minecraft:magenta_concrete
fill 376 159 502 376 159 504 minecraft:black_concrete
fill 380 159 505 381 232 505 minecraft:black_concrete
setblock 382 159 505 minecraft:magenta_concrete
fill 383 159 505 385 159 505 minecraft:black_concrete
fill 384 159 463 384 232 463 minecraft:black_concrete
setblock 385 159 463 minecraft:magenta_concrete
fill 386 159 463 390 228 463 minecraft:black_concrete
fill 390 159 505 393 230 505 minecraft:black_concrete
setblock 394 159 505 minecraft:magenta_concrete
fill 396 159 463 397 159 463 minecraft:black_concrete
fill 400 159 463 405 159 463 minecraft:black_concrete
fill 400 159 505 400 232 505 minecraft:black_concrete
setblock 402 159 505 minecraft:black_concrete
fill 404 159 475 405 160 476 minecraft:gold_block
fill 404 159 505 406 228 505 minecraft:black_concrete
setblock 406 159 463 minecraft:magenta_concrete
setblock 407 159 505 minecraft:magenta_concrete
fill 408 159 505 410 228 505 minecraft:black_concrete
fill 409 159 463 409 232 463 minecraft:black_concrete
fill 412 159 505 415 228 505 minecraft:black_concrete
setblock 416 159 505 minecraft:magenta_concrete
fill 417 159 505 418 228 505 minecraft:black_concrete
fill 418 159 469 418 232 470 minecraft:black_concrete
setblock 418 159 471 minecraft:magenta_concrete
fill 418 159 472 418 230 474 minecraft:black_concrete
fill 418 159 477 418 232 479 minecraft:black_concrete
fill 418 159 480 418 159 481 minecraft:magenta_concrete
fill 418 159 482 418 232 483 minecraft:black_concrete
setblock 418 159 485 minecraft:magenta_concrete
fill 418 159 486 418 232 491 minecraft:black_concrete
fill 418 159 493 418 228 495 minecraft:black_concrete
setblock 418 159 496 minecraft:magenta_concrete
setblock 418 159 497 minecraft:black_concrete
setblock 418 159 498 minecraft:magenta_concrete
setblock 418 159 499 minecraft:black_concrete
fill 376 160 463 376 230 463 minecraft:black_concrete
setblock 376 160 464 minecraft:magenta_concrete
fill 376 160 465 376 228 467 minecraft:black_concrete
fill 376 160 470 376 233 471 minecraft:black_concrete
fill 376 160 477 376 228 480 minecraft:black_concrete
setblock 376 160 481 minecraft:magenta_concrete
fill 376 160 482 376 232 483 minecraft:black_concrete
fill 376 160 485 376 232 485 minecraft:black_concrete
fill 376 160 493 376 232 494 minecraft:black_concrete
setblock 376 160 495 minecraft:magenta_concrete
fill 376 160 499 376 232 499 minecraft:black_concrete
fill 376 160 501 376 232 502 minecraft:black_concrete
setblock 376 160 503 minecraft:magenta_concrete
fill 376 160 504 376 230 504 minecraft:black_concrete
fill 382 160 505 382 232 505 minecraft:black_concrete
setblock 383 160 505 minecraft:magenta_concrete
fill 384 160 505 385 232 505 minecraft:black_concrete
fill 385 160 463 385 232 463 minecraft:black_concrete
fill 388 160 505 388 232 505 minecraft:black_concrete
setblock 389 160 505 minecraft:magenta_concrete
fill 394 160 505 394 233 505 minecraft:black_concrete
fill 396 160 463 396 228 463 minecraft:black_concrete
setblock 397 160 463 minecraft:magenta_concrete
fill 400 160 463 401 232 463 minecraft:black_concrete
setblock 402 160 463 minecraft:magenta_concrete
setblock 402 160 505 minecraft:magenta_concrete
fill 403 160 463 404 232 463 minecraft:black_concrete
setblock 405 160 463 minecraft:magenta_concrete
fill 406 160 463 406 233 463 minecraft:black_concrete
fill 407 160 505 407 232 505 minecraft:black_concrete
fill 416 160 505 416 232 505 minecraft:black_concrete
fill 418 160 471 418 232 471 minecraft:black_concrete
fill 418 160 475 418 232 475 minecraft:black_concrete
fill 418 160 480 418 232 481 minecraft:black_concrete
fill 418 160 485 418 232 485 minecraft:black_concrete
fill 418 160 496 418 232 496 minecraft:black_concrete
setblock 418 160 497 minecraft:magenta_concrete
fill 418 160 498 418 232 498 minecraft:black_concrete
setblock 418 160 499 minecraft:magenta_concrete
fill 418 160 501 418 232 502 minecraft:black_concrete
setblock 418 160 503 minecraft:magenta_concrete
fill 418 160 504 418 232 504 minecraft:black_concrete
fill 376 161 464 376 230 464 minecraft:black_concrete
fill 376 161 481 376 232 481 minecraft:black_concrete
fill 376 161 495 376 232 495 minecraft:black_concrete
fill 376 161 503 376 233 503 minecraft:black_concrete
fill 383 161 505 383 232 505 minecraft:black_concrete
fill 389 161 505 389 233 505 minecraft:black_concrete
fill 397 161 463 397 229 463 minecraft:black_concrete
fill 402 161 463 402 232 463 minecraft:black_concrete
fill 402 161 505 402 229 505 minecraft:black_concrete
fill 405 161 463 405 229 463 minecraft:black_concrete
fill 418 161 497 418 228 497 minecraft:black_concrete
fill 418 161 499 418 228 499 minecraft:black_concrete
fill 418 161 503 418 232 503 minecraft:black_concrete
setblock 379 162 466 minecraft:light[level=14]
setblock 379 162 474 minecraft:light[level=14]
setblock 379 162 482 minecraft:light[level=14]
setblock 379 162 498 minecraft:light[level=14]
setblock 387 162 474 minecraft:light[level=14]
setblock 387 162 482 minecraft:light[level=14]
setblock 387 162 490 minecraft:light[level=14]
setblock 387 162 498 minecraft:light[level=14]
setblock 395 162 466 minecraft:light[level=14]
setblock 395 162 474 minecraft:light[level=14]
setblock 395 162 490 minecraft:light[level=14]
setblock 395 162 498 minecraft:light[level=14]
setblock 403 162 466 minecraft:light[level=14]
setblock 403 162 474 minecraft:light[level=14]
setblock 403 162 482 minecraft:light[level=14]
setblock 403 162 490 minecraft:light[level=14]
setblock 403 162 498 minecraft:light[level=14]
setblock 411 162 466 minecraft:light[level=14]
setblock 411 162 474 minecraft:light[level=14]
setblock 411 162 482 minecraft:light[level=14]
setblock 411 162 490 minecraft:light[level=14]
setblock 411 162 498 minecraft:light[level=14]
fill 376 164 468 376 173 468 minecraft:black_concrete
fill 376 164 476 376 173 476 minecraft:black_concrete
fill 376 164 484 376 173 484 minecraft:black_concrete
fill 376 164 492 376 173 492 minecraft:black_concrete
fill 376 164 500 376 173 500 minecraft:black_concrete
fill 379 164 505 379 173 505 minecraft:black_concrete
fill 383 164 463 383 173 463 minecraft:black_concrete
fill 387 164 505 387 173 505 minecraft:black_concrete
fill 391 164 463 391 173 463 minecraft:black_concrete
fill 395 164 505 395 173 505 minecraft:black_concrete
fill 399 164 463 399 173 463 minecraft:black_concrete
fill 403 164 505 403 173 505 minecraft:black_concrete
fill 407 164 463 407 173 463 minecraft:black_concrete
fill 411 164 505 411 173 505 minecraft:black_concrete
fill 415 164 463 415 173 463 minecraft:black_concrete
fill 418 164 468 418 173 468 minecraft:black_concrete
fill 418 164 476 418 173 476 minecraft:black_concrete
fill 418 164 484 418 173 484 minecraft:black_concrete
fill 418 164 492 418 173 492 minecraft:black_concrete
fill 418 164 500 418 173 500 minecraft:black_concrete
fill 390 168 481 392 168 483 minecraft:redstone_block
fill 399 168 478 401 168 480 minecraft:redstone_block
fill 399 168 484 401 168 486 minecraft:redstone_block
fill 377 169 464 377 169 465 minecraft:white_concrete
fill 377 169 466 377 169 467 minecraft:black_concrete
fill 377 169 468 377 169 469 minecraft:white_concrete
fill 377 169 470 377 169 471 minecraft:black_concrete
fill 377 169 472 377 169 473 minecraft:white_concrete
fill 377 169 474 377 169 475 minecraft:black_concrete
fill 377 169 476 377 169 477 minecraft:white_concrete
fill 377 169 478 377 169 479 minecraft:black_concrete
fill 377 169 480 377 169 481 minecraft:white_concrete
fill 377 169 482 377 169 483 minecraft:black_concrete
fill 377 169 484 377 169 485 minecraft:white_concrete
fill 377 169 486 377 169 487 minecraft:black_concrete
fill 377 169 488 377 169 489 minecraft:white_concrete
fill 377 169 490 377 169 491 minecraft:black_concrete
fill 377 169 492 377 169 493 minecraft:white_concrete
fill 377 169 494 377 169 495 minecraft:black_concrete
fill 377 169 496 377 169 497 minecraft:white_concrete
fill 377 169 498 377 169 499 minecraft:black_concrete
fill 377 169 500 377 169 501 minecraft:white_concrete
fill 377 169 502 377 169 503 minecraft:black_concrete
setblock 377 169 504 minecraft:white_concrete
fill 378 169 464 379 169 465 minecraft:black_concrete
fill 378 169 466 379 169 467 minecraft:white_concrete
fill 378 169 468 379 169 469 minecraft:black_concrete
fill 378 169 470 379 169 471 minecraft:white_concrete
fill 378 169 472 379 169 473 minecraft:black_concrete
fill 378 169 474 379 169 475 minecraft:white_concrete
fill 378 169 476 379 169 477 minecraft:black_concrete
fill 378 169 478 379 169 479 minecraft:white_concrete
fill 378 169 480 379 169 481 minecraft:black_concrete
fill 378 169 482 379 169 483 minecraft:white_concrete
fill 378 169 484 379 169 485 minecraft:black_concrete
fill 378 169 486 379 169 487 minecraft:white_concrete
fill 378 169 488 379 169 489 minecraft:black_concrete
fill 378 169 490 379 169 491 minecraft:white_concrete
fill 378 169 492 379 169 493 minecraft:black_concrete
fill 378 169 494 379 169 495 minecraft:white_concrete
fill 378 169 496 379 169 497 minecraft:black_concrete
fill 378 169 498 379 169 499 minecraft:white_concrete
fill 378 169 500 379 169 501 minecraft:black_concrete
fill 378 169 502 379 169 503 minecraft:white_concrete
fill 378 169 504 379 169 504 minecraft:black_concrete
fill 380 169 464 381 169 465 minecraft:white_concrete
fill 380 169 466 381 169 467 minecraft:black_concrete
fill 380 169 468 381 169 469 minecraft:white_concrete
fill 380 169 470 381 169 471 minecraft:black_concrete
fill 380 169 472 381 169 473 minecraft:white_concrete
fill 380 169 474 381 169 475 minecraft:black_concrete
fill 380 169 476 381 169 477 minecraft:white_concrete
fill 380 169 478 381 169 479 minecraft:black_concrete
fill 380 169 480 381 169 481 minecraft:white_concrete
fill 380 169 482 381 169 483 minecraft:black_concrete
fill 380 169 484 381 169 485 minecraft:white_concrete
fill 380 169 486 381 169 487 minecraft:black_concrete
fill 380 169 488 381 169 489 minecraft:white_concrete
fill 380 169 490 381 169 491 minecraft:black_concrete
fill 380 169 492 381 169 493 minecraft:white_concrete
fill 380 169 494 381 169 495 minecraft:black_concrete
fill 380 169 496 381 169 497 minecraft:white_concrete
fill 380 169 498 381 169 499 minecraft:black_concrete
fill 380 169 500 381 169 501 minecraft:white_concrete
fill 380 169 502 381 169 503 minecraft:black_concrete
fill 380 169 504 381 169 504 minecraft:white_concrete
fill 382 169 464 383 169 465 minecraft:black_concrete
fill 382 169 466 383 169 467 minecraft:white_concrete
fill 382 169 468 383 169 469 minecraft:black_concrete
fill 382 169 470 383 169 471 minecraft:white_concrete
fill 382 169 472 383 169 473 minecraft:black_concrete
fill 382 169 474 383 169 475 minecraft:white_concrete
fill 382 169 476 383 169 477 minecraft:black_concrete
fill 382 169 478 383 169 479 minecraft:white_concrete
fill 382 169 480 383 169 481 minecraft:black_concrete
fill 382 169 482 383 169 483 minecraft:white_concrete
fill 382 169 484 383 169 485 minecraft:black_concrete
fill 382 169 486 383 169 487 minecraft:white_concrete
fill 382 169 488 383 169 489 minecraft:black_concrete
fill 382 169 490 383 169 491 minecraft:white_concrete
fill 382 169 492 383 169 493 minecraft:black_concrete
fill 382 169 494 383 169 495 minecraft:white_concrete
fill 382 169 496 383 169 497 minecraft:black_concrete
fill 382 169 498 383 169 499 minecraft:white_concrete
fill 382 169 500 383 169 501 minecraft:black_concrete
fill 382 169 502 383 169 503 minecraft:white_concrete
fill 382 169 504 383 169 504 minecraft:black_concrete
fill 384 169 464 385 169 465 minecraft:white_concrete
fill 384 169 466 385 169 467 minecraft:black_concrete
fill 384 169 468 385 169 469 minecraft:white_concrete
fill 384 169 470 385 169 471 minecraft:black_concrete
fill 384 169 472 385 169 473 minecraft:white_concrete
fill 384 169 474 385 169 475 minecraft:black_concrete
fill 384 169 476 385 169 477 minecraft:white_concrete
fill 384 169 478 385 169 479 minecraft:black_concrete
fill 384 169 480 385 169 481 minecraft:white_concrete
fill 384 169 482 385 169 483 minecraft:black_concrete
fill 384 169 484 385 169 485 minecraft:white_concrete
fill 384 169 486 385 169 487 minecraft:black_concrete
fill 384 169 488 385 169 489 minecraft:white_concrete
fill 384 169 490 385 169 491 minecraft:black_concrete
fill 384 169 492 385 169 493 minecraft:white_concrete
fill 384 169 494 385 169 495 minecraft:black_concrete
fill 384 169 496 385 169 497 minecraft:white_concrete
fill 384 169 498 385 169 499 minecraft:black_concrete
fill 384 169 500 385 169 501 minecraft:white_concrete
fill 384 169 502 385 169 503 minecraft:black_concrete
fill 384 169 504 385 169 504 minecraft:white_concrete
fill 386 169 464 387 169 465 minecraft:black_concrete
fill 386 169 466 387 169 467 minecraft:white_concrete
fill 386 169 468 387 169 469 minecraft:black_concrete
fill 386 169 470 387 169 471 minecraft:white_concrete
fill 386 169 472 387 169 473 minecraft:black_concrete
fill 386 169 474 387 169 475 minecraft:white_concrete
fill 386 169 476 387 169 477 minecraft:black_concrete
fill 386 169 478 387 169 479 minecraft:white_concrete
fill 386 169 480 387 169 481 minecraft:black_concrete
fill 386 169 482 387 169 483 minecraft:white_concrete
fill 386 169 484 387 169 485 minecraft:black_concrete
fill 386 169 486 387 169 487 minecraft:white_concrete
fill 386 169 488 387 169 489 minecraft:black_concrete
fill 386 169 490 387 169 491 minecraft:white_concrete
fill 386 169 492 387 169 493 minecraft:black_concrete
fill 386 169 494 387 169 495 minecraft:white_concrete
fill 386 169 496 387 169 497 minecraft:black_concrete
fill 386 169 498 387 169 499 minecraft:white_concrete
fill 386 169 500 387 169 501 minecraft:black_concrete
fill 386 169 502 387 169 503 minecraft:white_concrete
fill 386 169 504 387 169 504 minecraft:black_concrete
fill 388 169 464 389 169 465 minecraft:white_concrete
fill 388 169 466 389 169 467 minecraft:black_concrete
fill 388 169 468 389 169 469 minecraft:white_concrete
fill 388 169 470 389 169 471 minecraft:black_concrete
fill 388 169 472 389 169 473 minecraft:white_concrete
fill 388 169 474 389 169 475 minecraft:black_concrete
fill 388 169 476 389 169 477 minecraft:white_concrete
fill 388 169 478 389 169 479 minecraft:black_concrete
fill 388 169 480 389 169 481 minecraft:white_concrete
fill 388 169 482 389 169 483 minecraft:black_concrete
fill 388 169 484 389 169 485 minecraft:white_concrete
fill 388 169 486 389 169 487 minecraft:black_concrete
fill 388 169 488 389 169 489 minecraft:white_concrete
fill 388 169 490 389 169 491 minecraft:black_concrete
fill 388 169 492 389 169 493 minecraft:white_concrete
fill 388 169 494 389 169 495 minecraft:black_concrete
fill 388 169 496 389 169 497 minecraft:white_concrete
fill 388 169 498 389 169 499 minecraft:black_concrete
fill 388 169 500 389 169 501 minecraft:white_concrete
fill 388 169 502 389 169 503 minecraft:black_concrete
fill 388 169 504 389 169 504 minecraft:white_concrete
fill 390 169 464 391 169 465 minecraft:black_concrete
fill 390 169 466 391 169 467 minecraft:white_concrete
fill 390 169 468 391 169 469 minecraft:black_concrete
fill 390 169 470 391 169 471 minecraft:white_concrete
fill 390 169 472 391 169 473 minecraft:black_concrete
fill 390 169 474 391 169 475 minecraft:white_concrete
fill 390 169 476 391 169 477 minecraft:black_concrete
fill 390 169 478 391 169 479 minecraft:white_concrete
fill 390 169 480 391 169 480 minecraft:black_concrete
fill 390 169 484 391 169 485 minecraft:black_concrete
fill 390 169 486 391 169 487 minecraft:white_concrete
fill 390 169 488 391 169 489 minecraft:black_concrete
fill 390 169 490 391 169 491 minecraft:white_concrete
fill 390 169 492 391 169 493 minecraft:black_concrete
fill 390 169 494 391 169 495 minecraft:white_concrete
fill 390 169 496 391 169 497 minecraft:black_concrete
fill 390 169 498 391 169 499 minecraft:white_concrete
fill 390 169 500 391 169 501 minecraft:black_concrete
fill 390 169 502 391 169 503 minecraft:white_concrete
fill 390 169 504 391 169 504 minecraft:black_concrete
fill 392 169 464 393 169 465 minecraft:white_concrete
fill 392 169 466 393 169 467 minecraft:black_concrete
fill 392 169 468 393 169 469 minecraft:white_concrete
fill 392 169 470 393 169 471 minecraft:black_concrete
fill 392 169 472 393 169 473 minecraft:white_concrete
fill 392 169 474 393 169 475 minecraft:black_concrete
fill 392 169 476 393 169 477 minecraft:white_concrete
fill 392 169 478 393 169 479 minecraft:black_concrete
fill 392 169 480 393 169 480 minecraft:white_concrete
fill 392 169 484 393 169 485 minecraft:white_concrete
fill 392 169 486 393 169 487 minecraft:black_concrete
fill 392 169 488 393 169 489 minecraft:white_concrete
fill 392 169 490 393 169 491 minecraft:black_concrete
fill 392 169 492 393 169 493 minecraft:white_concrete
fill 392 169 494 393 169 495 minecraft:black_concrete
fill 392 169 496 393 169 497 minecraft:white_concrete
fill 392 169 498 393 169 499 minecraft:black_concrete
fill 392 169 500 393 169 501 minecraft:white_concrete
fill 392 169 502 393 169 503 minecraft:black_concrete
fill 392 169 504 393 169 504 minecraft:white_concrete
setblock 393 169 481 minecraft:white_concrete
fill 393 169 482 393 169 483 minecraft:black_concrete
fill 394 169 464 395 169 465 minecraft:black_concrete
fill 394 169 466 395 169 467 minecraft:white_concrete
fill 394 169 468 395 169 469 minecraft:black_concrete
fill 394 169 470 395 169 471 minecraft:white_concrete
fill 394 169 472 395 169 473 minecraft:black_concrete
fill 394 169 474 395 169 475 minecraft:white_concrete
fill 394 169 476 395 169 477 minecraft:black_concrete
fill 394 169 478 395 169 479 minecraft:white_concrete
fill 394 169 480 394 169 481 minecraft:black_concrete
fill 394 169 482 394 169 483 minecraft:white_concrete
fill 394 169 484 395 169 485 minecraft:black_concrete
fill 394 169 486 395 169 487 minecraft:white_concrete
fill 394 169 488 395 169 489 minecraft:black_concrete
fill 394 169 490 395 169 491 minecraft:white_concrete
fill 394 169 492 395 169 493 minecraft:black_concrete
fill 394 169 494 395 169 495 minecraft:white_concrete
fill 394 169 496 395 169 497 minecraft:black_concrete
fill 394 169 498 395 169 499 minecraft:white_concrete
fill 394 169 500 395 169 501 minecraft:black_concrete
fill 394 169 502 395 169 503 minecraft:white_concrete
fill 394 169 504 395 169 504 minecraft:black_concrete
setblock 395 169 480 minecraft:black_concrete
fill 396 169 464 397 169 465 minecraft:white_concrete
fill 396 169 466 397 169 467 minecraft:black_concrete
fill 396 169 468 397 169 469 minecraft:white_concrete
fill 396 169 470 397 169 471 minecraft:black_concrete
fill 396 169 472 397 169 473 minecraft:white_concrete
fill 396 169 474 397 169 475 minecraft:black_concrete
fill 396 169 476 397 169 477 minecraft:white_concrete
fill 396 169 478 397 169 479 minecraft:black_concrete
fill 396 169 480 397 169 480 minecraft:white_concrete
fill 396 169 484 397 169 485 minecraft:white_concrete
fill 396 169 486 397 169 487 minecraft:black_concrete
fill 396 169 488 397 169 489 minecraft:white_concrete
fill 396 169 490 397 169 491 minecraft:black_concrete
fill 396 169 492 397 169 493 minecraft:white_concrete
fill 396 169 494 397 169 495 minecraft:black_concrete
fill 396 169 496 397 169 497 minecraft:white_concrete
fill 396 169 498 397 169 499 minecraft:black_concrete
fill 396 169 500 397 169 501 minecraft:white_concrete
fill 396 169 502 397 169 503 minecraft:black_concrete
fill 396 169 504 397 169 504 minecraft:white_concrete
fill 398 169 464 399 169 465 minecraft:black_concrete
fill 398 169 466 399 169 467 minecraft:white_concrete
fill 398 169 468 399 169 469 minecraft:black_concrete
fill 398 169 470 399 169 471 minecraft:white_concrete
fill 398 169 472 399 169 473 minecraft:black_concrete
fill 398 169 474 399 169 475 minecraft:white_concrete
fill 398 169 476 399 169 477 minecraft:black_concrete
fill 398 169 478 398 169 479 minecraft:white_concrete
fill 398 169 480 398 169 481 minecraft:black_concrete
fill 398 169 482 399 169 483 minecraft:white_concrete
fill 398 169 484 398 169 485 minecraft:black_concrete
fill 398 169 486 398 169 487 minecraft:white_concrete
fill 398 169 488 399 169 489 minecraft:black_concrete
fill 398 169 490 399 169 491 minecraft:white_concrete
fill 398 169 492 399 169 493 minecraft:black_concrete
fill 398 169 494 399 169 495 minecraft:white_concrete
fill 398 169 496 399 169 497 minecraft:black_concrete
fill 398 169 498 399 169 499 minecraft:white_concrete
fill 398 169 500 399 169 501 minecraft:black_concrete
fill 398 169 502 399 169 503 minecraft:white_concrete
fill 398 169 504 399 169 504 minecraft:black_concrete
setblock 399 169 481 minecraft:black_concrete
setblock 399 169 487 minecraft:white_concrete
fill 400 169 464 401 169 465 minecraft:white_concrete
fill 400 169 466 401 169 467 minecraft:black_concrete
fill 400 169 468 401 169 469 minecraft:white_concrete
fill 400 169 470 401 169 471 minecraft:black_concrete
fill 400 169 472 401 169 473 minecraft:white_concrete
fill 400 169 474 401 169 475 minecraft:black_concrete
fill 400 169 476 401 169 477 minecraft:white_concrete
fill 400 169 481 401 169 481 minecraft:white_concrete
fill 400 169 482 401 169 483 minecraft:black_concrete
fill 400 169 487 401 169 487 minecraft:black_concrete
fill 400 169 488 401 169 489 minecraft:white_concrete
fill 400 169 490 401 169 491 minecraft:black_concrete
fill 400 169 492 401 169 493 minecraft:white_concrete
fill 400 169 494 401 169 495 minecraft:black_concrete
fill 400 169 496 401 169 497 minecraft:white_concrete
fill 400 169 498 401 169 499 minecraft:black_concrete
fill 400 169 500 401 169 501 minecraft:white_concrete
fill 400 169 502 401 169 503 minecraft:black_concrete
fill 400 169 504 401 169 504 minecraft:white_concrete
fill 402 169 464 403 169 465 minecraft:black_concrete
fill 402 169 466 403 169 467 minecraft:white_concrete
fill 402 169 468 403 169 469 minecraft:black_concrete
fill 402 169 470 403 169 471 minecraft:white_concrete
fill 402 169 472 403 169 473 minecraft:black_concrete
fill 402 169 474 403 169 475 minecraft:white_concrete
fill 402 169 476 403 169 477 minecraft:black_concrete
fill 402 169 478 403 169 479 minecraft:white_concrete
fill 402 169 480 403 169 481 minecraft:black_concrete
fill 402 169 482 403 169 483 minecraft:white_concrete
fill 402 169 484 403 169 485 minecraft:black_concrete
fill 402 169 486 403 169 487 minecraft:white_concrete
fill 402 169 488 403 169 489 minecraft:black_concrete
fill 402 169 490 403 169 491 minecraft:white_concrete
fill 402 169 492 403 169 493 minecraft:black_concrete
fill 402 169 494 403 169 495 minecraft:white_concrete
fill 402 169 496 403 169 497 minecraft:black_concrete
fill 402 169 498 403 169 499 minecraft:white_concrete
fill 402 169 500 403 169 501 minecraft:black_concrete
fill 402 169 502 403 169 503 minecraft:white_concrete
fill 402 169 504 403 169 504 minecraft:black_concrete
fill 404 169 464 405 169 465 minecraft:white_concrete
fill 404 169 466 405 169 467 minecraft:black_concrete
fill 404 169 468 405 169 469 minecraft:white_concrete
fill 404 169 470 405 169 471 minecraft:black_concrete
fill 404 169 472 405 169 473 minecraft:white_concrete
fill 404 169 474 405 169 475 minecraft:black_concrete
fill 404 169 476 405 169 477 minecraft:white_concrete
fill 404 169 478 405 169 479 minecraft:black_concrete
fill 404 169 480 405 169 481 minecraft:white_concrete
fill 404 169 482 405 169 483 minecraft:black_concrete
fill 404 169 484 405 169 485 minecraft:white_concrete
fill 404 169 486 405 169 487 minecraft:black_concrete
fill 404 169 488 405 169 489 minecraft:white_concrete
fill 404 169 490 405 169 491 minecraft:black_concrete
fill 404 169 492 405 169 493 minecraft:white_concrete
fill 404 169 494 405 169 495 minecraft:black_concrete
fill 404 169 496 405 169 497 minecraft:white_concrete
fill 404 169 498 405 169 499 minecraft:black_concrete
fill 404 169 500 405 169 501 minecraft:white_concrete
fill 404 169 502 405 169 503 minecraft:black_concrete
fill 404 169 504 405 169 504 minecraft:white_concrete
fill 406 169 464 407 169 465 minecraft:black_concrete
fill 406 169 466 407 169 467 minecraft:white_concrete
fill 406 169 468 407 169 469 minecraft:black_concrete
fill 406 169 470 407 169 471 minecraft:white_concrete
fill 406 169 472 407 169 473 minecraft:black_concrete
fill 406 169 474 407 169 475 minecraft:white_concrete
fill 406 169 476 407 169 477 minecraft:black_concrete
fill 406 169 478 407 169 479 minecraft:white_concrete
fill 406 169 480 407 169 481 minecraft:black_concrete
fill 406 169 482 407 169 483 minecraft:white_concrete
fill 406 169 484 407 169 485 minecraft:black_concrete
fill 406 169 486 407 169 487 minecraft:white_concrete
fill 406 169 488 407 169 489 minecraft:black_concrete
fill 406 169 490 407 169 491 minecraft:white_concrete
fill 406 169 492 407 169 493 minecraft:black_concrete
fill 406 169 494 407 169 495 minecraft:white_concrete
fill 406 169 496 407 169 497 minecraft:black_concrete
fill 406 169 498 407 169 499 minecraft:white_concrete
fill 406 169 500 407 169 501 minecraft:black_concrete
fill 406 169 502 407 169 503 minecraft:white_concrete
fill 406 169 504 407 169 504 minecraft:black_concrete
fill 408 169 464 409 169 465 minecraft:white_concrete
fill 408 169 466 409 169 467 minecraft:black_concrete
fill 408 169 468 409 169 469 minecraft:white_concrete
fill 408 169 470 409 169 471 minecraft:black_concrete
fill 408 169 472 409 169 473 minecraft:white_concrete
fill 408 169 474 409 169 475 minecraft:black_concrete
fill 408 169 476 409 169 477 minecraft:white_concrete
fill 408 169 478 409 169 479 minecraft:black_concrete
fill 408 169 480 409 169 481 minecraft:white_concrete
fill 408 169 482 409 169 483 minecraft:black_concrete
fill 408 169 484 409 169 485 minecraft:white_concrete
fill 408 169 486 409 169 487 minecraft:black_concrete
fill 408 169 488 409 169 489 minecraft:white_concrete
fill 408 169 490 409 169 491 minecraft:black_concrete
fill 408 169 492 409 169 493 minecraft:white_concrete
fill 408 169 494 409 169 495 minecraft:black_concrete
fill 408 169 496 409 169 497 minecraft:white_concrete
fill 408 169 498 409 169 499 minecraft:black_concrete
fill 408 169 500 409 169 501 minecraft:white_concrete
fill 408 169 502 409 169 503 minecraft:black_concrete
fill 408 169 504 409 169 504 minecraft:white_concrete
fill 410 169 464 411 169 465 minecraft:black_concrete
fill 410 169 466 411 169 467 minecraft:white_concrete
fill 410 169 468 411 169 469 minecraft:black_concrete
fill 410 169 470 411 169 471 minecraft:white_concrete
fill 410 169 472 411 169 473 minecraft:black_concrete
fill 410 169 474 411 169 475 minecraft:white_concrete
fill 410 169 476 411 169 477 minecraft:black_concrete
fill 410 169 478 411 169 479 minecraft:white_concrete
fill 410 169 480 411 169 481 minecraft:black_concrete
fill 410 169 482 411 169 483 minecraft:white_concrete
fill 410 169 484 411 169 485 minecraft:black_concrete
fill 410 169 486 411 169 487 minecraft:white_concrete
fill 410 169 488 411 169 489 minecraft:black_concrete
fill 410 169 490 411 169 491 minecraft:white_concrete
fill 410 169 492 411 169 493 minecraft:black_concrete
fill 410 169 494 411 169 495 minecraft:white_concrete
fill 410 169 496 411 169 497 minecraft:black_concrete
fill 410 169 498 411 169 499 minecraft:white_concrete
fill 410 169 500 411 169 501 minecraft:black_concrete
fill 410 169 502 411 169 503 minecraft:white_concrete
fill 410 169 504 411 169 504 minecraft:black_concrete
fill 412 169 464 413 169 465 minecraft:white_concrete
fill 412 169 466 413 169 467 minecraft:black_concrete
fill 412 169 468 413 169 469 minecraft:white_concrete
fill 412 169 470 413 169 471 minecraft:black_concrete
fill 412 169 472 413 169 473 minecraft:white_concrete
fill 412 169 474 413 169 475 minecraft:black_concrete
fill 412 169 476 413 169 477 minecraft:white_concrete
fill 412 169 478 413 169 479 minecraft:black_concrete
fill 412 169 480 413 169 481 minecraft:white_concrete
fill 412 169 482 413 169 483 minecraft:black_concrete
fill 412 169 484 413 169 485 minecraft:white_concrete
fill 412 169 486 413 169 487 minecraft:black_concrete
fill 412 169 488 413 169 489 minecraft:white_concrete
fill 412 169 490 413 169 491 minecraft:black_concrete
fill 412 169 492 413 169 493 minecraft:white_concrete
fill 412 169 494 413 169 495 minecraft:black_concrete
fill 412 169 496 413 169 497 minecraft:white_concrete
fill 412 169 498 413 169 499 minecraft:black_concrete
fill 412 169 500 413 169 501 minecraft:white_concrete
fill 412 169 502 413 169 503 minecraft:black_concrete
fill 412 169 504 413 169 504 minecraft:white_concrete
fill 414 169 464 415 169 465 minecraft:black_concrete
fill 414 169 466 415 169 467 minecraft:white_concrete
fill 414 169 468 415 169 469 minecraft:black_concrete
fill 414 169 470 415 169 471 minecraft:white_concrete
fill 414 169 472 415 169 473 minecraft:black_concrete
fill 414 169 474 415 169 475 minecraft:white_concrete
fill 414 169 476 415 169 477 minecraft:black_concrete
fill 414 169 478 415 169 479 minecraft:white_concrete
fill 414 169 480 415 169 481 minecraft:black_concrete
fill 414 169 482 415 169 483 minecraft:white_concrete
fill 414 169 484 415 169 485 minecraft:black_concrete
fill 414 169 486 415 169 487 minecraft:white_concrete
fill 414 169 488 415 169 489 minecraft:black_concrete
fill 414 169 490 415 169 491 minecraft:white_concrete
fill 414 169 492 415 169 493 minecraft:black_concrete
fill 414 169 494 415 169 495 minecraft:white_concrete
fill 414 169 496 415 169 497 minecraft:black_concrete
fill 414 169 498 415 169 499 minecraft:white_concrete
fill 414 169 500 415 169 501 minecraft:black_concrete
fill 414 169 502 415 169 503 minecraft:white_concrete
fill 414 169 504 415 169 504 minecraft:black_concrete
fill 416 169 464 417 169 465 minecraft:white_concrete
fill 416 169 466 417 169 467 minecraft:black_concrete
fill 416 169 468 417 169 469 minecraft:white_concrete
fill 416 169 470 417 169 471 minecraft:black_concrete
fill 416 169 472 417 169 473 minecraft:white_concrete
fill 416 169 474 417 169 475 minecraft:black_concrete
fill 416 169 476 417 169 477 minecraft:white_concrete
fill 416 169 478 417 169 479 minecraft:black_concrete
fill 416 169 480 417 169 481 minecraft:white_concrete
fill 416 169 482 417 169 483 minecraft:black_concrete
fill 416 169 484 417 169 485 minecraft:white_concrete
fill 416 169 486 417 169 487 minecraft:black_concrete
fill 416 169 488 417 169 489 minecraft:white_concrete
fill 416 169 490 417 169 491 minecraft:black_concrete
fill 416 169 492 417 169 493 minecraft:white_concrete
fill 416 169 494 417 169 495 minecraft:black_concrete
fill 416 169 496 417 169 497 minecraft:white_concrete
fill 416 169 498 417 169 499 minecraft:black_concrete
fill 416 169 500 417 169 501 minecraft:white_concrete
fill 416 169 502 417 169 503 minecraft:black_concrete
fill 416 169 504 417 169 504 minecraft:white_concrete
fill 377 170 464 417 170 464 minecraft:magenta_concrete
setblock 377 170 465 minecraft:white_concrete
fill 377 170 466 417 170 466 minecraft:magenta_concrete
setblock 377 170 467 minecraft:black_concrete
fill 377 170 468 417 170 468 minecraft:magenta_concrete
setblock 377 170 469 minecraft:white_concrete
fill 377 170 470 417 170 470 minecraft:magenta_concrete
setblock 377 170 471 minecraft:black_concrete
fill 377 170 472 417 170 472 minecraft:magenta_concrete
setblock 377 170 473 minecraft:white_concrete
fill 377 170 474 417 170 474 minecraft:magenta_concrete
setblock 377 170 475 minecraft:black_concrete
fill 377 170 476 417 170 476 minecraft:magenta_concrete
setblock 377 170 477 minecraft:white_concrete
fill 377 170 478 397 170 478 minecraft:magenta_concrete
setblock 377 170 479 minecraft:black_concrete
fill 377 170 480 388 170 480 minecraft:magenta_concrete
setblock 377 170 481 minecraft:white_concrete
fill 377 170 482 388 170 482 minecraft:magenta_concrete
setblock 377 170 483 minecraft:black_concrete
fill 377 170 484 388 170 484 minecraft:magenta_concrete
setblock 377 170 485 minecraft:white_concrete
fill 377 170 486 397 170 486 minecraft:magenta_concrete
setblock 377 170 487 minecraft:black_concrete
fill 377 170 488 417 170 488 minecraft:magenta_concrete
setblock 377 170 489 minecraft:white_concrete
fill 377 170 490 417 170 490 minecraft:magenta_concrete
setblock 377 170 491 minecraft:black_concrete
fill 377 170 492 417 170 492 minecraft:magenta_concrete
setblock 377 170 493 minecraft:white_concrete
fill 377 170 494 417 170 494 minecraft:magenta_concrete
setblock 377 170 495 minecraft:black_concrete
fill 377 170 496 417 170 496 minecraft:magenta_concrete
setblock 377 170 497 minecraft:white_concrete
fill 377 170 498 417 170 498 minecraft:magenta_concrete
setblock 377 170 499 minecraft:black_concrete
fill 377 170 500 417 170 500 minecraft:magenta_concrete
setblock 377 170 501 minecraft:white_concrete
fill 377 170 502 417 170 502 minecraft:magenta_concrete
setblock 377 170 503 minecraft:black_concrete
fill 377 170 504 417 170 504 minecraft:magenta_concrete
setblock 378 170 465 minecraft:magenta_concrete
setblock 378 170 467 minecraft:magenta_concrete
setblock 378 170 469 minecraft:magenta_concrete
setblock 378 170 471 minecraft:magenta_concrete
setblock 378 170 473 minecraft:magenta_concrete
setblock 378 170 475 minecraft:magenta_concrete
setblock 378 170 477 minecraft:magenta_concrete
setblock 378 170 479 minecraft:magenta_concrete
setblock 378 170 481 minecraft:magenta_concrete
setblock 378 170 483 minecraft:magenta_concrete
setblock 378 170 485 minecraft:magenta_concrete
setblock 378 170 487 minecraft:magenta_concrete
setblock 378 170 489 minecraft:magenta_concrete
setblock 378 170 491 minecraft:magenta_concrete
setblock 378 170 493 minecraft:magenta_concrete
setblock 378 170 495 minecraft:magenta_concrete
setblock 378 170 497 minecraft:magenta_concrete
setblock 378 170 499 minecraft:magenta_concrete
setblock 378 170 501 minecraft:magenta_concrete
setblock 378 170 503 minecraft:magenta_concrete
setblock 379 170 465 minecraft:black_concrete
setblock 379 170 467 minecraft:white_concrete
setblock 379 170 469 minecraft:black_concrete
setblock 379 170 471 minecraft:white_concrete
setblock 379 170 473 minecraft:black_concrete
setblock 379 170 475 minecraft:white_concrete
setblock 379 170 477 minecraft:black_concrete
setblock 379 170 479 minecraft:white_concrete
setblock 379 170 481 minecraft:black_concrete
setblock 379 170 483 minecraft:white_concrete
setblock 379 170 485 minecraft:black_concrete
setblock 379 170 487 minecraft:white_concrete
setblock 379 170 489 minecraft:black_concrete
setblock 379 170 491 minecraft:white_concrete
setblock 379 170 493 minecraft:black_concrete
setblock 379 170 495 minecraft:white_concrete
setblock 379 170 497 minecraft:black_concrete
setblock 379 170 499 minecraft:white_concrete
setblock 379 170 501 minecraft:black_concrete
setblock 379 170 503 minecraft:white_concrete
setblock 380 170 465 minecraft:magenta_concrete
setblock 380 170 467 minecraft:magenta_concrete
setblock 380 170 469 minecraft:magenta_concrete
setblock 380 170 471 minecraft:magenta_concrete
setblock 380 170 473 minecraft:magenta_concrete
setblock 380 170 475 minecraft:magenta_concrete
setblock 380 170 477 minecraft:magenta_concrete
setblock 380 170 479 minecraft:magenta_concrete
setblock 380 170 481 minecraft:magenta_concrete
setblock 380 170 483 minecraft:magenta_concrete
setblock 380 170 485 minecraft:magenta_concrete
setblock 380 170 487 minecraft:magenta_concrete
setblock 380 170 489 minecraft:magenta_concrete
setblock 380 170 491 minecraft:magenta_concrete
setblock 380 170 493 minecraft:magenta_concrete
setblock 380 170 495 minecraft:magenta_concrete
setblock 380 170 497 minecraft:magenta_concrete
setblock 380 170 499 minecraft:magenta_concrete
setblock 380 170 501 minecraft:magenta_concrete
setblock 380 170 503 minecraft:magenta_concrete
setblock 381 170 465 minecraft:white_concrete
setblock 381 170 467 minecraft:black_concrete
setblock 381 170 469 minecraft:white_concrete
setblock 381 170 471 minecraft:black_concrete
setblock 381 170 473 minecraft:white_concrete
setblock 381 170 475 minecraft:black_concrete
setblock 381 170 477 minecraft:white_concrete
setblock 381 170 479 minecraft:black_concrete
setblock 381 170 481 minecraft:white_concrete
setblock 381 170 483 minecraft:black_concrete
setblock 381 170 485 minecraft:white_concrete
setblock 381 170 487 minecraft:black_concrete
setblock 381 170 489 minecraft:white_concrete
setblock 381 170 491 minecraft:black_concrete
setblock 381 170 493 minecraft:white_concrete
setblock 381 170 495 minecraft:black_concrete
setblock 381 170 497 minecraft:white_concrete
setblock 381 170 499 minecraft:black_concrete
setblock 381 170 501 minecraft:white_concrete
setblock 381 170 503 minecraft:black_concrete
setblock 382 170 465 minecraft:magenta_concrete
setblock 382 170 467 minecraft:magenta_concrete
setblock 382 170 469 minecraft:magenta_concrete
setblock 382 170 471 minecraft:magenta_concrete
setblock 382 170 473 minecraft:magenta_concrete
setblock 382 170 475 minecraft:magenta_concrete
setblock 382 170 477 minecraft:magenta_concrete
setblock 382 170 479 minecraft:magenta_concrete
setblock 382 170 481 minecraft:magenta_concrete
setblock 382 170 483 minecraft:magenta_concrete
setblock 382 170 485 minecraft:magenta_concrete
setblock 382 170 487 minecraft:magenta_concrete
setblock 382 170 489 minecraft:magenta_concrete
setblock 382 170 491 minecraft:magenta_concrete
setblock 382 170 493 minecraft:magenta_concrete
setblock 382 170 495 minecraft:magenta_concrete
setblock 382 170 497 minecraft:magenta_concrete
setblock 382 170 499 minecraft:magenta_concrete
setblock 382 170 501 minecraft:magenta_concrete
setblock 382 170 503 minecraft:magenta_concrete
setblock 383 170 465 minecraft:black_concrete
setblock 383 170 467 minecraft:white_concrete
setblock 383 170 469 minecraft:black_concrete
setblock 383 170 471 minecraft:white_concrete
setblock 383 170 473 minecraft:black_concrete
setblock 383 170 475 minecraft:white_concrete
setblock 383 170 477 minecraft:black_concrete
setblock 383 170 479 minecraft:white_concrete
setblock 383 170 481 minecraft:black_concrete
setblock 383 170 483 minecraft:white_concrete
setblock 383 170 485 minecraft:black_concrete
setblock 383 170 487 minecraft:white_concrete
setblock 383 170 489 minecraft:black_concrete
setblock 383 170 491 minecraft:white_concrete
setblock 383 170 493 minecraft:black_concrete
setblock 383 170 495 minecraft:white_concrete
setblock 383 170 497 minecraft:black_concrete
setblock 383 170 499 minecraft:white_concrete
setblock 383 170 501 minecraft:black_concrete
setblock 383 170 503 minecraft:white_concrete
setblock 384 170 465 minecraft:magenta_concrete
setblock 384 170 467 minecraft:magenta_concrete
setblock 384 170 469 minecraft:magenta_concrete
setblock 384 170 471 minecraft:magenta_concrete
setblock 384 170 473 minecraft:magenta_concrete
setblock 384 170 475 minecraft:magenta_concrete
setblock 384 170 477 minecraft:magenta_concrete
setblock 384 170 479 minecraft:magenta_concrete
setblock 384 170 481 minecraft:magenta_concrete
setblock 384 170 483 minecraft:magenta_concrete
setblock 384 170 485 minecraft:magenta_concrete
setblock 384 170 487 minecraft:magenta_concrete
setblock 384 170 489 minecraft:magenta_concrete
setblock 384 170 491 minecraft:magenta_concrete
setblock 384 170 493 minecraft:magenta_concrete
setblock 384 170 495 minecraft:magenta_concrete
setblock 384 170 497 minecraft:magenta_concrete
setblock 384 170 499 minecraft:magenta_concrete
setblock 384 170 501 minecraft:magenta_concrete
setblock 384 170 503 minecraft:magenta_concrete
setblock 385 170 465 minecraft:white_concrete
setblock 385 170 467 minecraft:black_concrete
setblock 385 170 469 minecraft:white_concrete
setblock 385 170 471 minecraft:black_concrete
setblock 385 170 473 minecraft:white_concrete
setblock 385 170 475 minecraft:black_concrete
setblock 385 170 477 minecraft:white_concrete
setblock 385 170 479 minecraft:black_concrete
setblock 385 170 481 minecraft:white_concrete
setblock 385 170 483 minecraft:black_concrete
setblock 385 170 485 minecraft:white_concrete
setblock 385 170 487 minecraft:black_concrete
setblock 385 170 489 minecraft:white_concrete
setblock 385 170 491 minecraft:black_concrete
setblock 385 170 493 minecraft:white_concrete
setblock 385 170 495 minecraft:black_concrete
setblock 385 170 497 minecraft:white_concrete
setblock 385 170 499 minecraft:black_concrete
setblock 385 170 501 minecraft:white_concrete
setblock 385 170 503 minecraft:black_concrete
setblock 386 170 465 minecraft:magenta_concrete
setblock 386 170 467 minecraft:magenta_concrete
setblock 386 170 469 minecraft:magenta_concrete
setblock 386 170 471 minecraft:magenta_concrete
setblock 386 170 473 minecraft:magenta_concrete
setblock 386 170 475 minecraft:magenta_concrete
setblock 386 170 477 minecraft:magenta_concrete
setblock 386 170 479 minecraft:magenta_concrete
setblock 386 170 481 minecraft:magenta_concrete
setblock 386 170 483 minecraft:magenta_concrete
setblock 386 170 485 minecraft:magenta_concrete
setblock 386 170 487 minecraft:magenta_concrete
setblock 386 170 489 minecraft:magenta_concrete
setblock 386 170 491 minecraft:magenta_concrete
setblock 386 170 493 minecraft:magenta_concrete
setblock 386 170 495 minecraft:magenta_concrete
setblock 386 170 497 minecraft:magenta_concrete
setblock 386 170 499 minecraft:magenta_concrete
setblock 386 170 501 minecraft:magenta_concrete
setblock 386 170 503 minecraft:magenta_concrete
setblock 387 170 465 minecraft:black_concrete
setblock 387 170 467 minecraft:white_concrete
setblock 387 170 469 minecraft:black_concrete
setblock 387 170 471 minecraft:white_concrete
setblock 387 170 473 minecraft:black_concrete
setblock 387 170 475 minecraft:white_concrete
setblock 387 170 477 minecraft:black_concrete
setblock 387 170 479 minecraft:white_concrete
setblock 387 170 481 minecraft:black_concrete
setblock 387 170 483 minecraft:white_concrete
setblock 387 170 485 minecraft:black_concrete
setblock 387 170 487 minecraft:white_concrete
setblock 387 170 489 minecraft:black_concrete
setblock 387 170 491 minecraft:white_concrete
setblock 387 170 493 minecraft:black_concrete
setblock 387 170 495 minecraft:white_concrete
setblock 387 170 497 minecraft:black_concrete
setblock 387 170 499 minecraft:white_concrete
setblock 387 170 501 minecraft:black_concrete
setblock 387 170 503 minecraft:white_concrete
setblock 388 170 465 minecraft:magenta_concrete
setblock 388 170 467 minecraft:magenta_concrete
setblock 388 170 469 minecraft:magenta_concrete
setblock 388 170 471 minecraft:magenta_concrete
setblock 388 170 473 minecraft:magenta_concrete
setblock 388 170 475 minecraft:magenta_concrete
setblock 388 170 477 minecraft:magenta_concrete
setblock 388 170 479 minecraft:magenta_concrete
setblock 388 170 481 minecraft:magenta_concrete
setblock 388 170 483 minecraft:magenta_concrete
setblock 388 170 485 minecraft:magenta_concrete
setblock 388 170 487 minecraft:magenta_concrete
setblock 388 170 489 minecraft:magenta_concrete
setblock 388 170 491 minecraft:magenta_concrete
setblock 388 170 493 minecraft:magenta_concrete
setblock 388 170 495 minecraft:magenta_concrete
setblock 388 170 497 minecraft:magenta_concrete
setblock 388 170 499 minecraft:magenta_concrete
setblock 388 170 501 minecraft:magenta_concrete
setblock 388 170 503 minecraft:magenta_concrete
setblock 389 170 465 minecraft:white_concrete
setblock 389 170 467 minecraft:black_concrete
setblock 389 170 469 minecraft:white_concrete
setblock 389 170 471 minecraft:black_concrete
setblock 389 170 473 minecraft:white_concrete
setblock 389 170 475 minecraft:black_concrete
setblock 389 170 477 minecraft:white_concrete
setblock 389 170 479 minecraft:black_concrete
fill 389 170 480 389 170 484 minecraft:sea_lantern
setblock 389 170 485 minecraft:white_concrete
setblock 389 170 487 minecraft:black_concrete
setblock 389 170 489 minecraft:white_concrete
setblock 389 170 491 minecraft:black_concrete
setblock 389 170 493 minecraft:white_concrete
setblock 389 170 495 minecraft:black_concrete
setblock 389 170 497 minecraft:white_concrete
setblock 389 170 499 minecraft:black_concrete
setblock 389 170 501 minecraft:white_concrete
setblock 389 170 503 minecraft:black_concrete
setblock 390 170 465 minecraft:magenta_concrete
setblock 390 170 467 minecraft:magenta_concrete
setblock 390 170 469 minecraft:magenta_concrete
setblock 390 170 471 minecraft:magenta_concrete
setblock 390 170 473 minecraft:magenta_concrete
setblock 390 170 475 minecraft:magenta_concrete
setblock 390 170 477 minecraft:magenta_concrete
setblock 390 170 479 minecraft:magenta_concrete
fill 390 170 480 398 170 480 minecraft:sea_lantern
fill 390 170 481 392 170 483 minecraft:white_concrete
fill 390 170 484 398 170 484 minecraft:sea_lantern
setblock 390 170 485 minecraft:magenta_concrete
setblock 390 170 487 minecraft:magenta_concrete
setblock 390 170 489 minecraft:magenta_concrete
setblock 390 170 491 minecraft:magenta_concrete
setblock 390 170 493 minecraft:magenta_concrete
setblock 390 170 495 minecraft:magenta_concrete
setblock 390 170 497 minecraft:magenta_concrete
setblock 390 170 499 minecraft:magenta_concrete
setblock 390 170 501 minecraft:magenta_concrete
setblock 390 170 503 minecraft:magenta_concrete
setblock 391 170 465 minecraft:black_concrete
setblock 391 170 467 minecraft:white_concrete
setblock 391 170 469 minecraft:black_concrete
setblock 391 170 471 minecraft:white_concrete
setblock 391 170 473 minecraft:black_concrete
setblock 391 170 475 minecraft:white_concrete
setblock 391 170 477 minecraft:black_concrete
setblock 391 170 479 minecraft:white_concrete
setblock 391 170 485 minecraft:black_concrete
setblock 391 170 487 minecraft:white_concrete
setblock 391 170 489 minecraft:black_concrete
setblock 391 170 491 minecraft:white_concrete
setblock 391 170 493 minecraft:black_concrete
setblock 391 170 495 minecraft:white_concrete
setblock 391 170 497 minecraft:black_concrete
setblock 391 170 499 minecraft:white_concrete
setblock 391 170 501 minecraft:black_concrete
setblock 391 170 503 minecraft:white_concrete
setblock 392 170 465 minecraft:magenta_concrete
setblock 392 170 467 minecraft:magenta_concrete
setblock 392 170 469 minecraft:magenta_concrete
setblock 392 170 471 minecraft:magenta_concrete
setblock 392 170 473 minecraft:magenta_concrete
setblock 392 170 475 minecraft:magenta_concrete
setblock 392 170 477 minecraft:magenta_concrete
setblock 392 170 479 minecraft:magenta_concrete
setblock 392 170 485 minecraft:magenta_concrete
setblock 392 170 487 minecraft:magenta_concrete
setblock 392 170 489 minecraft:magenta_concrete
setblock 392 170 491 minecraft:magenta_concrete
setblock 392 170 493 minecraft:magenta_concrete
setblock 392 170 495 minecraft:magenta_concrete
setblock 392 170 497 minecraft:magenta_concrete
setblock 392 170 499 minecraft:magenta_concrete
setblock 392 170 501 minecraft:magenta_concrete
setblock 392 170 503 minecraft:magenta_concrete
setblock 393 170 465 minecraft:white_concrete
setblock 393 170 467 minecraft:black_concrete
setblock 393 170 469 minecraft:white_concrete
setblock 393 170 471 minecraft:black_concrete
setblock 393 170 473 minecraft:white_concrete
setblock 393 170 475 minecraft:black_concrete
setblock 393 170 477 minecraft:white_concrete
setblock 393 170 479 minecraft:black_concrete
fill 393 170 481 394 170 483 minecraft:sea_lantern
setblock 393 170 485 minecraft:white_concrete
setblock 393 170 487 minecraft:black_concrete
setblock 393 170 489 minecraft:white_concrete
setblock 393 170 491 minecraft:black_concrete
setblock 393 170 493 minecraft:white_concrete
setblock 393 170 495 minecraft:black_concrete
setblock 393 170 497 minecraft:white_concrete
setblock 393 170 499 minecraft:black_concrete
setblock 393 170 501 minecraft:white_concrete
setblock 393 170 503 minecraft:black_concrete
setblock 394 170 465 minecraft:magenta_concrete
setblock 394 170 467 minecraft:magenta_concrete
setblock 394 170 469 minecraft:magenta_concrete
setblock 394 170 471 minecraft:magenta_concrete
setblock 394 170 473 minecraft:magenta_concrete
setblock 394 170 475 minecraft:magenta_concrete
setblock 394 170 477 minecraft:magenta_concrete
setblock 394 170 479 minecraft:magenta_concrete
setblock 394 170 485 minecraft:magenta_concrete
setblock 394 170 487 minecraft:magenta_concrete
setblock 394 170 489 minecraft:magenta_concrete
setblock 394 170 491 minecraft:magenta_concrete
setblock 394 170 493 minecraft:magenta_concrete
setblock 394 170 495 minecraft:magenta_concrete
setblock 394 170 497 minecraft:magenta_concrete
setblock 394 170 499 minecraft:magenta_concrete
setblock 394 170 501 minecraft:magenta_concrete
setblock 394 170 503 minecraft:magenta_concrete
setblock 395 170 465 minecraft:black_concrete
setblock 395 170 467 minecraft:white_concrete
setblock 395 170 469 minecraft:black_concrete
setblock 395 170 471 minecraft:white_concrete
setblock 395 170 473 minecraft:black_concrete
setblock 395 170 475 minecraft:white_concrete
setblock 395 170 477 minecraft:black_concrete
setblock 395 170 479 minecraft:white_concrete
setblock 395 170 485 minecraft:black_concrete
setblock 395 170 487 minecraft:white_concrete
setblock 395 170 489 minecraft:black_concrete
setblock 395 170 491 minecraft:white_concrete
setblock 395 170 493 minecraft:black_concrete
setblock 395 170 495 minecraft:white_concrete
setblock 395 170 497 minecraft:black_concrete
setblock 395 170 499 minecraft:white_concrete
setblock 395 170 501 minecraft:black_concrete
setblock 395 170 503 minecraft:white_concrete
setblock 396 170 465 minecraft:magenta_concrete
setblock 396 170 467 minecraft:magenta_concrete
setblock 396 170 469 minecraft:magenta_concrete
setblock 396 170 471 minecraft:magenta_concrete
setblock 396 170 473 minecraft:magenta_concrete
setblock 396 170 475 minecraft:magenta_concrete
setblock 396 170 477 minecraft:magenta_concrete
setblock 396 170 479 minecraft:magenta_concrete
setblock 396 170 485 minecraft:magenta_concrete
setblock 396 170 487 minecraft:magenta_concrete
setblock 396 170 489 minecraft:magenta_concrete
setblock 396 170 491 minecraft:magenta_concrete
setblock 396 170 493 minecraft:magenta_concrete
setblock 396 170 495 minecraft:magenta_concrete
setblock 396 170 497 minecraft:magenta_concrete
setblock 396 170 499 minecraft:magenta_concrete
setblock 396 170 501 minecraft:magenta_concrete
setblock 396 170 503 minecraft:magenta_concrete
setblock 397 170 465 minecraft:white_concrete
setblock 397 170 467 minecraft:black_concrete
setblock 397 170 469 minecraft:white_concrete
setblock 397 170 471 minecraft:black_concrete
setblock 397 170 473 minecraft:white_concrete
setblock 397 170 475 minecraft:black_concrete
setblock 397 170 477 minecraft:white_concrete
setblock 397 170 479 minecraft:black_concrete
setblock 397 170 485 minecraft:white_concrete
setblock 397 170 487 minecraft:black_concrete
setblock 397 170 489 minecraft:white_concrete
setblock 397 170 491 minecraft:black_concrete
setblock 397 170 493 minecraft:white_concrete
setblock 397 170 495 minecraft:black_concrete
setblock 397 170 497 minecraft:white_concrete
setblock 397 170 499 minecraft:black_concrete
setblock 397 170 501 minecraft:white_concrete
setblock 397 170 503 minecraft:black_concrete
setblock 398 170 465 minecraft:magenta_concrete
setblock 398 170 467 minecraft:magenta_concrete
setblock 398 170 469 minecraft:magenta_concrete
setblock 398 170 471 minecraft:magenta_concrete
setblock 398 170 473 minecraft:magenta_concrete
setblock 398 170 475 minecraft:magenta_concrete
fill 398 170 477 398 170 479 minecraft:sea_lantern
fill 398 170 481 398 170 483 minecraft:sea_lantern
fill 398 170 485 398 170 487 minecraft:sea_lantern
setblock 398 170 489 minecraft:magenta_concrete
setblock 398 170 491 minecraft:magenta_concrete
setblock 398 170 493 minecraft:magenta_concrete
setblock 398 170 495 minecraft:magenta_concrete
setblock 398 170 497 minecraft:magenta_concrete
setblock 398 170 499 minecraft:magenta_concrete
setblock 398 170 501 minecraft:magenta_concrete
setblock 398 170 503 minecraft:magenta_concrete
setblock 399 170 465 minecraft:black_concrete
setblock 399 170 467 minecraft:white_concrete
setblock 399 170 469 minecraft:black_concrete
setblock 399 170 471 minecraft:white_concrete
setblock 399 170 473 minecraft:black_concrete
setblock 399 170 475 minecraft:white_concrete
fill 399 170 477 402 170 477 minecraft:sea_lantern
fill 399 170 478 401 170 480 minecraft:white_concrete
fill 399 170 481 402 170 481 minecraft:sea_lantern
fill 399 170 482 417 170 482 minecraft:magenta_concrete
fill 399 170 483 402 170 483 minecraft:sea_lantern
fill 399 170 484 401 170 486 minecraft:white_concrete
fill 399 170 487 402 170 487 minecraft:sea_lantern
setblock 399 170 489 minecraft:black_concrete
setblock 399 170 491 minecraft:white_concrete
setblock 399 170 493 minecraft:black_concrete
setblock 399 170 495 minecraft:white_concrete
setblock 399 170 497 minecraft:black_concrete
setblock 399 170 499 minecraft:white_concrete
setblock 399 170 501 minecraft:black_concrete
setblock 399 170 503 minecraft:white_concrete
setblock 400 170 465 minecraft:magenta_concrete
setblock 400 170 467 minecraft:magenta_concrete
setblock 400 170 469 minecraft:magenta_concrete
setblock 400 170 471 minecraft:magenta_concrete
setblock 400 170 473 minecraft:magenta_concrete
setblock 400 170 475 minecraft:magenta_concrete
setblock 400 170 489 minecraft:magenta_concrete
setblock 400 170 491 minecraft:magenta_concrete
setblock 400 170 493 minecraft:magenta_concrete
setblock 400 170 495 minecraft:magenta_concrete
setblock 400 170 497 minecraft:magenta_concrete
setblock 400 170 499 minecraft:magenta_concrete
setblock 400 170 501 minecraft:magenta_concrete
setblock 400 170 503 minecraft:magenta_concrete
setblock 401 170 465 minecraft:white_concrete
setblock 401 170 467 minecraft:black_concrete
setblock 401 170 469 minecraft:white_concrete
setblock 401 170 471 minecraft:black_concrete
setblock 401 170 473 minecraft:white_concrete
setblock 401 170 475 minecraft:black_concrete
setblock 401 170 489 minecraft:white_concrete
setblock 401 170 491 minecraft:black_concrete
setblock 401 170 493 minecraft:white_concrete
setblock 401 170 495 minecraft:black_concrete
setblock 401 170 497 minecraft:white_concrete
setblock 401 170 499 minecraft:black_concrete
setblock 401 170 501 minecraft:white_concrete
setblock 401 170 503 minecraft:black_concrete
setblock 402 170 465 minecraft:magenta_concrete
setblock 402 170 467 minecraft:magenta_concrete
setblock 402 170 469 minecraft:magenta_concrete
setblock 402 170 471 minecraft:magenta_concrete
setblock 402 170 473 minecraft:magenta_concrete
setblock 402 170 475 minecraft:magenta_concrete
fill 402 170 478 402 170 480 minecraft:sea_lantern
fill 402 170 484 402 170 486 minecraft:sea_lantern
setblock 402 170 489 minecraft:magenta_concrete
setblock 402 170 491 minecraft:magenta_concrete
setblock 402 170 493 minecraft:magenta_concrete
setblock 402 170 495 minecraft:magenta_concrete
setblock 402 170 497 minecraft:magenta_concrete
setblock 402 170 499 minecraft:magenta_concrete
setblock 402 170 501 minecraft:magenta_concrete
setblock 402 170 503 minecraft:magenta_concrete
setblock 403 170 465 minecraft:black_concrete
setblock 403 170 467 minecraft:white_concrete
setblock 403 170 469 minecraft:black_concrete
setblock 403 170 471 minecraft:white_concrete
setblock 403 170 473 minecraft:black_concrete
setblock 403 170 475 minecraft:white_concrete
setblock 403 170 477 minecraft:black_concrete
fill 403 170 478 417 170 478 minecraft:magenta_concrete
setblock 403 170 479 minecraft:white_concrete
fill 403 170 480 417 170 480 minecraft:magenta_concrete
setblock 403 170 481 minecraft:black_concrete
setblock 403 170 483 minecraft:white_concrete
fill 403 170 484 417 170 484 minecraft:magenta_concrete
setblock 403 170 485 minecraft:black_concrete
fill 403 170 486 417 170 486 minecraft:magenta_concrete
setblock 403 170 487 minecraft:white_concrete
setblock 403 170 489 minecraft:black_concrete
setblock 403 170 491 minecraft:white_concrete
setblock 403 170 493 minecraft:black_concrete
setblock 403 170 495 minecraft:white_concrete
setblock 403 170 497 minecraft:black_concrete
setblock 403 170 499 minecraft:white_concrete
setblock 403 170 501 minecraft:black_concrete
setblock 403 170 503 minecraft:white_concrete
setblock 404 170 465 minecraft:magenta_concrete
setblock 404 170 467 minecraft:magenta_concrete
setblock 404 170 469 minecraft:magenta_concrete
setblock 404 170 471 minecraft:magenta_concrete
setblock 404 170 473 minecraft:magenta_concrete
setblock 404 170 475 minecraft:magenta_concrete
setblock 404 170 477 minecraft:magenta_concrete
setblock 404 170 479 minecraft:magenta_concrete
setblock 404 170 481 minecraft:magenta_concrete
setblock 404 170 483 minecraft:magenta_concrete
setblock 404 170 485 minecraft:magenta_concrete
setblock 404 170 487 minecraft:magenta_concrete
setblock 404 170 489 minecraft:magenta_concrete
setblock 404 170 491 minecraft:magenta_concrete
setblock 404 170 493 minecraft:magenta_concrete
setblock 404 170 495 minecraft:magenta_concrete
setblock 404 170 497 minecraft:magenta_concrete
setblock 404 170 499 minecraft:magenta_concrete
setblock 404 170 501 minecraft:magenta_concrete
setblock 404 170 503 minecraft:magenta_concrete
setblock 405 170 465 minecraft:white_concrete
setblock 405 170 467 minecraft:black_concrete
setblock 405 170 469 minecraft:white_concrete
setblock 405 170 471 minecraft:black_concrete
setblock 405 170 473 minecraft:white_concrete
setblock 405 170 475 minecraft:black_concrete
setblock 405 170 477 minecraft:white_concrete
setblock 405 170 479 minecraft:black_concrete
setblock 405 170 481 minecraft:white_concrete
setblock 405 170 483 minecraft:black_concrete
setblock 405 170 485 minecraft:white_concrete
setblock 405 170 487 minecraft:black_concrete
setblock 405 170 489 minecraft:white_concrete
setblock 405 170 491 minecraft:black_concrete
setblock 405 170 493 minecraft:white_concrete
setblock 405 170 495 minecraft:black_concrete
setblock 405 170 497 minecraft:white_concrete
setblock 405 170 499 minecraft:black_concrete
setblock 405 170 501 minecraft:white_concrete
setblock 405 170 503 minecraft:black_concrete
setblock 406 170 465 minecraft:magenta_concrete
setblock 406 170 467 minecraft:magenta_concrete
setblock 406 170 469 minecraft:magenta_concrete
setblock 406 170 471 minecraft:magenta_concrete
setblock 406 170 473 minecraft:magenta_concrete
setblock 406 170 475 minecraft:magenta_concrete
setblock 406 170 477 minecraft:magenta_concrete
setblock 406 170 479 minecraft:magenta_concrete
setblock 406 170 481 minecraft:magenta_concrete
setblock 406 170 483 minecraft:magenta_concrete
setblock 406 170 485 minecraft:magenta_concrete
setblock 406 170 487 minecraft:magenta_concrete
setblock 406 170 489 minecraft:magenta_concrete
setblock 406 170 491 minecraft:magenta_concrete
setblock 406 170 493 minecraft:magenta_concrete
setblock 406 170 495 minecraft:magenta_concrete
setblock 406 170 497 minecraft:magenta_concrete
setblock 406 170 499 minecraft:magenta_concrete
setblock 406 170 501 minecraft:magenta_concrete
setblock 406 170 503 minecraft:magenta_concrete
setblock 407 170 465 minecraft:black_concrete
setblock 407 170 467 minecraft:white_concrete
setblock 407 170 469 minecraft:black_concrete
setblock 407 170 471 minecraft:white_concrete
setblock 407 170 473 minecraft:black_concrete
setblock 407 170 475 minecraft:white_concrete
setblock 407 170 477 minecraft:black_concrete
setblock 407 170 479 minecraft:white_concrete
setblock 407 170 481 minecraft:black_concrete
setblock 407 170 483 minecraft:white_concrete
setblock 407 170 485 minecraft:black_concrete
setblock 407 170 487 minecraft:white_concrete
setblock 407 170 489 minecraft:black_concrete
setblock 407 170 491 minecraft:white_concrete
setblock 407 170 493 minecraft:black_concrete
setblock 407 170 495 minecraft:white_concrete
setblock 407 170 497 minecraft:black_concrete
setblock 407 170 499 minecraft:white_concrete
setblock 407 170 501 minecraft:black_concrete
setblock 407 170 503 minecraft:white_concrete
setblock 408 170 465 minecraft:magenta_concrete
setblock 408 170 467 minecraft:magenta_concrete
setblock 408 170 469 minecraft:magenta_concrete
setblock 408 170 471 minecraft:magenta_concrete
setblock 408 170 473 minecraft:magenta_concrete
setblock 408 170 475 minecraft:magenta_concrete
setblock 408 170 477 minecraft:magenta_concrete
setblock 408 170 479 minecraft:magenta_concrete
setblock 408 170 481 minecraft:magenta_concrete
setblock 408 170 483 minecraft:magenta_concrete
setblock 408 170 485 minecraft:magenta_concrete
setblock 408 170 487 minecraft:magenta_concrete
setblock 408 170 489 minecraft:magenta_concrete
setblock 408 170 491 minecraft:magenta_concrete
setblock 408 170 493 minecraft:magenta_concrete
setblock 408 170 495 minecraft:magenta_concrete
setblock 408 170 497 minecraft:magenta_concrete
setblock 408 170 499 minecraft:magenta_concrete
setblock 408 170 501 minecraft:magenta_concrete
setblock 408 170 503 minecraft:magenta_concrete
setblock 409 170 465 minecraft:white_concrete
setblock 409 170 467 minecraft:black_concrete
setblock 409 170 469 minecraft:white_concrete
setblock 409 170 471 minecraft:black_concrete
setblock 409 170 473 minecraft:white_concrete
setblock 409 170 475 minecraft:black_concrete
setblock 409 170 477 minecraft:white_concrete
setblock 409 170 479 minecraft:black_concrete
setblock 409 170 481 minecraft:white_concrete
setblock 409 170 483 minecraft:black_concrete
setblock 409 170 485 minecraft:white_concrete
setblock 409 170 487 minecraft:black_concrete
setblock 409 170 489 minecraft:white_concrete
setblock 409 170 491 minecraft:black_concrete
setblock 409 170 493 minecraft:white_concrete
setblock 409 170 495 minecraft:black_concrete
setblock 409 170 497 minecraft:white_concrete
setblock 409 170 499 minecraft:black_concrete
setblock 409 170 501 minecraft:white_concrete
setblock 409 170 503 minecraft:black_concrete
setblock 410 170 465 minecraft:magenta_concrete
setblock 410 170 467 minecraft:magenta_concrete
setblock 410 170 469 minecraft:magenta_concrete
setblock 410 170 471 minecraft:magenta_concrete
setblock 410 170 473 minecraft:magenta_concrete
setblock 410 170 475 minecraft:magenta_concrete
setblock 410 170 477 minecraft:magenta_concrete
setblock 410 170 479 minecraft:magenta_concrete
setblock 410 170 481 minecraft:magenta_concrete
setblock 410 170 483 minecraft:magenta_concrete
setblock 410 170 485 minecraft:magenta_concrete
setblock 410 170 487 minecraft:magenta_concrete
setblock 410 170 489 minecraft:magenta_concrete
setblock 410 170 491 minecraft:magenta_concrete
setblock 410 170 493 minecraft:magenta_concrete
setblock 410 170 495 minecraft:magenta_concrete
setblock 410 170 497 minecraft:magenta_concrete
setblock 410 170 499 minecraft:magenta_concrete
setblock 410 170 501 minecraft:magenta_concrete
setblock 410 170 503 minecraft:magenta_concrete
setblock 411 170 465 minecraft:black_concrete
setblock 411 170 467 minecraft:white_concrete
setblock 411 170 469 minecraft:black_concrete
setblock 411 170 471 minecraft:white_concrete
setblock 411 170 473 minecraft:black_concrete
setblock 411 170 475 minecraft:white_concrete
setblock 411 170 477 minecraft:black_concrete
setblock 411 170 479 minecraft:white_concrete
setblock 411 170 481 minecraft:black_concrete
setblock 411 170 483 minecraft:white_concrete
setblock 411 170 485 minecraft:black_concrete
setblock 411 170 487 minecraft:white_concrete
setblock 411 170 489 minecraft:black_concrete
setblock 411 170 491 minecraft:white_concrete
setblock 411 170 493 minecraft:black_concrete
setblock 411 170 495 minecraft:white_concrete
setblock 411 170 497 minecraft:black_concrete
setblock 411 170 499 minecraft:white_concrete
setblock 411 170 501 minecraft:black_concrete
setblock 411 170 503 minecraft:white_concrete
setblock 412 170 465 minecraft:magenta_concrete
setblock 412 170 467 minecraft:magenta_concrete
setblock 412 170 469 minecraft:magenta_concrete
setblock 412 170 471 minecraft:magenta_concrete
setblock 412 170 473 minecraft:magenta_concrete
setblock 412 170 475 minecraft:magenta_concrete
setblock 412 170 477 minecraft:magenta_concrete
setblock 412 170 479 minecraft:magenta_concrete
setblock 412 170 481 minecraft:magenta_concrete
setblock 412 170 483 minecraft:magenta_concrete
setblock 412 170 485 minecraft:magenta_concrete
setblock 412 170 487 minecraft:magenta_concrete
setblock 412 170 489 minecraft:magenta_concrete
setblock 412 170 491 minecraft:magenta_concrete
setblock 412 170 493 minecraft:magenta_concrete
setblock 412 170 495 minecraft:magenta_concrete
setblock 412 170 497 minecraft:magenta_concrete
setblock 412 170 499 minecraft:magenta_concrete
setblock 412 170 501 minecraft:magenta_concrete
setblock 412 170 503 minecraft:magenta_concrete
setblock 413 170 465 minecraft:white_concrete
setblock 413 170 467 minecraft:black_concrete
setblock 413 170 469 minecraft:white_concrete
setblock 413 170 471 minecraft:black_concrete
setblock 413 170 473 minecraft:white_concrete
setblock 413 170 475 minecraft:black_concrete
setblock 413 170 477 minecraft:white_concrete
setblock 413 170 479 minecraft:black_concrete
setblock 413 170 481 minecraft:white_concrete
setblock 413 170 483 minecraft:black_concrete
setblock 413 170 485 minecraft:white_concrete
setblock 413 170 487 minecraft:black_concrete
setblock 413 170 489 minecraft:white_concrete
setblock 413 170 491 minecraft:black_concrete
setblock 413 170 493 minecraft:white_concrete
setblock 413 170 495 minecraft:black_concrete
setblock 413 170 497 minecraft:white_concrete
setblock 413 170 499 minecraft:black_concrete
setblock 413 170 501 minecraft:white_concrete
setblock 413 170 503 minecraft:black_concrete
setblock 414 170 465 minecraft:magenta_concrete
setblock 414 170 467 minecraft:magenta_concrete
setblock 414 170 469 minecraft:magenta_concrete
setblock 414 170 471 minecraft:magenta_concrete
setblock 414 170 473 minecraft:magenta_concrete
setblock 414 170 475 minecraft:magenta_concrete
setblock 414 170 477 minecraft:magenta_concrete
setblock 414 170 479 minecraft:magenta_concrete
setblock 414 170 481 minecraft:magenta_concrete
setblock 414 170 483 minecraft:magenta_concrete
setblock 414 170 485 minecraft:magenta_concrete
setblock 414 170 487 minecraft:magenta_concrete
setblock 414 170 489 minecraft:magenta_concrete
setblock 414 170 491 minecraft:magenta_concrete
setblock 414 170 493 minecraft:magenta_concrete
setblock 414 170 495 minecraft:magenta_concrete
setblock 414 170 497 minecraft:magenta_concrete
setblock 414 170 499 minecraft:magenta_concrete
setblock 414 170 501 minecraft:magenta_concrete
setblock 414 170 503 minecraft:magenta_concrete
setblock 415 170 465 minecraft:black_concrete
setblock 415 170 467 minecraft:white_concrete
setblock 415 170 469 minecraft:black_concrete
setblock 415 170 471 minecraft:white_concrete
setblock 415 170 473 minecraft:black_concrete
setblock 415 170 475 minecraft:white_concrete
setblock 415 170 477 minecraft:black_concrete
setblock 415 170 479 minecraft:white_concrete
setblock 415 170 481 minecraft:black_concrete
setblock 415 170 483 minecraft:white_concrete
setblock 415 170 485 minecraft:black_concrete
setblock 415 170 487 minecraft:white_concrete
setblock 415 170 489 minecraft:black_concrete
setblock 415 170 491 minecraft:white_concrete
setblock 415 170 493 minecraft:black_concrete
setblock 415 170 495 minecraft:white_concrete
setblock 415 170 497 minecraft:black_concrete
setblock 415 170 499 minecraft:white_concrete
setblock 415 170 501 minecraft:black_concrete
setblock 415 170 503 minecraft:white_concrete
setblock 416 170 465 minecraft:magenta_concrete
setblock 416 170 467 minecraft:magenta_concrete
setblock 416 170 469 minecraft:magenta_concrete
setblock 416 170 471 minecraft:magenta_concrete
setblock 416 170 473 minecraft:magenta_concrete
setblock 416 170 475 minecraft:magenta_concrete
setblock 416 170 477 minecraft:magenta_concrete
setblock 416 170 479 minecraft:magenta_concrete
setblock 416 170 481 minecraft:magenta_concrete
setblock 416 170 483 minecraft:magenta_concrete
setblock 416 170 485 minecraft:magenta_concrete
setblock 416 170 487 minecraft:magenta_concrete
setblock 416 170 489 minecraft:magenta_concrete
setblock 416 170 491 minecraft:magenta_concrete
setblock 416 170 493 minecraft:magenta_concrete
setblock 416 170 495 minecraft:magenta_concrete
setblock 416 170 497 minecraft:magenta_concrete
setblock 416 170 499 minecraft:magenta_concrete
setblock 416 170 501 minecraft:magenta_concrete
setblock 416 170 503 minecraft:magenta_concrete
setblock 417 170 465 minecraft:white_concrete
setblock 417 170 467 minecraft:black_concrete
setblock 417 170 469 minecraft:white_concrete
setblock 417 170 471 minecraft:black_concrete
setblock 417 170 473 minecraft:white_concrete
setblock 417 170 475 minecraft:black_concrete
setblock 417 170 477 minecraft:white_concrete
setblock 417 170 479 minecraft:black_concrete
setblock 417 170 481 minecraft:white_concrete
setblock 417 170 483 minecraft:black_concrete
setblock 417 170 485 minecraft:white_concrete
setblock 417 170 487 minecraft:black_concrete
setblock 417 170 489 minecraft:white_concrete
setblock 417 170 491 minecraft:black_concrete
setblock 417 170 493 minecraft:white_concrete
setblock 417 170 495 minecraft:black_concrete
setblock 417 170 497 minecraft:white_concrete
setblock 417 170 499 minecraft:black_concrete
setblock 417 170 501 minecraft:white_concrete
setblock 417 170 503 minecraft:black_concrete
fill 382 171 482 384 185 482 minecraft:pink_concrete
fill 383 171 481 383 185 481 minecraft:pink_concrete
fill 383 171 483 383 185 483 minecraft:pink_concrete
fill 386 171 472 387 185 473 minecraft:light_blue_concrete
fill 386 171 491 387 185 492 minecraft:light_blue_concrete
fill 395 171 469 397 185 469 minecraft:pink_concrete
fill 395 171 495 397 185 495 minecraft:pink_concrete
fill 396 171 468 396 185 468 minecraft:pink_concrete
fill 396 171 470 396 185 470 minecraft:pink_concrete
fill 396 171 494 396 185 494 minecraft:pink_concrete
fill 396 171 496 396 185 496 minecraft:pink_concrete
fill 405 171 472 406 185 473 minecraft:light_blue_concrete
fill 405 171 491 406 185 492 minecraft:light_blue_concrete
fill 408 171 482 410 185 482 minecraft:pink_concrete
fill 409 171 481 409 185 481 minecraft:pink_concrete
fill 409 171 483 409 185 483 minecraft:pink_concrete
fill 390 172 481 391 173 483 minecraft:magenta_concrete
fill 391 172 479 391 173 480 minecraft:magenta_concrete
fill 391 172 484 391 173 485 minecraft:magenta_concrete
fill 392 172 478 392 173 479 minecraft:magenta_concrete
fill 392 172 485 392 173 486 minecraft:magenta_concrete
fill 393 172 477 393 173 478 minecraft:magenta_concrete
fill 393 172 486 393 173 487 minecraft:magenta_concrete
fill 394 172 477 399 173 477 minecraft:magenta_concrete
fill 394 172 487 399 173 487 minecraft:magenta_concrete
fill 395 172 476 397 173 476 minecraft:magenta_concrete
fill 395 172 488 397 173 488 minecraft:magenta_concrete
fill 399 172 478 400 173 478 minecraft:magenta_concrete
fill 399 172 486 400 173 486 minecraft:magenta_concrete
fill 400 172 479 401 173 479 minecraft:magenta_concrete
fill 400 172 485 401 173 485 minecraft:magenta_concrete
fill 401 172 480 401 173 484 minecraft:magenta_concrete
fill 402 172 481 402 173 483 minecraft:magenta_concrete
fill 376 174 468 376 177 468 minecraft:sea_lantern
fill 376 174 476 376 177 476 minecraft:sea_lantern
fill 376 174 484 376 177 484 minecraft:sea_lantern
fill 376 174 492 376 177 492 minecraft:sea_lantern
fill 376 174 500 376 177 500 minecraft:sea_lantern
fill 377 174 470 377 225 471 minecraft:black_concrete
fill 377 174 478 377 225 479 minecraft:black_concrete
fill 377 174 486 377 225 487 minecraft:black_concrete
fill 377 174 494 377 225 495 minecraft:black_concrete
fill 377 174 502 377 225 503 minecraft:black_concrete
fill 378 174 464 379 225 464 minecraft:black_concrete
fill 379 174 505 379 177 505 minecraft:sea_lantern
fill 383 174 463 383 177 463 minecraft:sea_lantern
fill 383 174 504 384 225 504 minecraft:black_concrete
fill 386 174 464 387 225 464 minecraft:black_concrete
fill 387 174 505 387 177 505 minecraft:sea_lantern
fill 390 174 464 394 185 469 minecraft:black_concrete
fill 391 174 463 391 177 463 minecraft:sea_lantern
fill 391 174 504 392 225 504 minecraft:black_concrete
fill 395 174 464 395 185 468 minecraft:black_concrete
fill 395 174 505 395 177 505 minecraft:sea_lantern
fill 396 174 464 400 197 467 minecraft:black_concrete
fill 397 174 468 400 197 468 minecraft:black_concrete
fill 398 174 469 400 197 469 minecraft:black_concrete
fill 399 174 463 399 177 463 minecraft:sea_lantern
fill 399 174 504 400 225 504 minecraft:black_concrete
fill 402 174 464 403 225 464 minecraft:black_concrete
fill 403 174 505 403 177 505 minecraft:sea_lantern
fill 407 174 463 407 177 463 minecraft:sea_lantern
fill 407 174 498 413 174 504 minecraft:black_concrete
fill 410 174 464 411 225 464 minecraft:black_concrete
fill 411 174 505 411 177 505 minecraft:sea_lantern
fill 415 174 463 415 177 463 minecraft:sea_lantern
fill 415 174 504 416 225 504 minecraft:black_concrete
fill 417 174 465 417 225 466 minecraft:black_concrete
fill 417 174 473 417 225 474 minecraft:black_concrete
fill 417 174 481 417 225 482 minecraft:black_concrete
fill 417 174 489 417 225 490 minecraft:black_concrete
fill 417 174 497 417 225 498 minecraft:black_concrete
fill 418 174 468 418 177 468 minecraft:sea_lantern
fill 418 174 476 418 177 476 minecraft:sea_lantern
fill 418 174 484 418 177 484 minecraft:sea_lantern
fill 418 174 492 418 177 492 minecraft:sea_lantern
fill 418 174 500 418 177 500 minecraft:sea_lantern
fill 386 175 475 387 176 476 minecraft:magenta_concrete
setblock 407 175 498 minecraft:sea_lantern
fill 407 175 499 407 200 499 minecraft:black_concrete
setblock 407 175 500 minecraft:sea_lantern
fill 407 175 501 407 200 501 minecraft:black_concrete
setblock 407 175 502 minecraft:sea_lantern
fill 407 175 503 407 200 503 minecraft:black_concrete
setblock 407 175 504 minecraft:sea_lantern
fill 408 175 498 408 200 498 minecraft:black_concrete
setblock 408 175 499 minecraft:sea_lantern
fill 408 175 500 408 200 500 minecraft:black_concrete
setblock 408 175 501 minecraft:sea_lantern
fill 408 175 502 408 200 502 minecraft:black_concrete
setblock 408 175 503 minecraft:sea_lantern
fill 408 175 504 408 225 504 minecraft:black_concrete
setblock 409 175 498 minecraft:sea_lantern
fill 409 175 499 409 200 499 minecraft:black_concrete
setblock 409 175 500 minecraft:sea_lantern
fill 409 175 501 409 200 501 minecraft:black_concrete
setblock 409 175 502 minecraft:sea_lantern
fill 409 175 503 409 200 503 minecraft:black_concrete
setblock 409 175 504 minecraft:sea_lantern
fill 410 175 498 410 200 498 minecraft:black_concrete
setblock 410 175 499 minecraft:sea_lantern
fill 410 175 500 410 200 500 minecraft:black_concrete
setblock 410 175 501 minecraft:sea_lantern
fill 410 175 502 410 200 502 minecraft:black_concrete
setblock 410 175 503 minecraft:sea_lantern
fill 410 175 504 410 200 504 minecraft:black_concrete
setblock 411 175 498 minecraft:sea_lantern
fill 411 175 499 411 200 499 minecraft:black_concrete
setblock 411 175 500 minecraft:sea_lantern
fill 411 175 501 411 200 501 minecraft:black_concrete
setblock 411 175 502 minecraft:sea_lantern
fill 411 175 503 411 200 503 minecraft:black_concrete
setblock 411 175 504 minecraft:sea_lantern
fill 412 175 498 412 200 498 minecraft:black_concrete
setblock 412 175 499 minecraft:sea_lantern
fill 412 175 500 412 200 500 minecraft:black_concrete
setblock 412 175 501 minecraft:sea_lantern
fill 412 175 502 412 200 502 minecraft:black_concrete
setblock 412 175 503 minecraft:sea_lantern
fill 412 175 504 412 200 504 minecraft:black_concrete
setblock 413 175 498 minecraft:sea_lantern
fill 413 175 499 413 200 499 minecraft:black_concrete
setblock 413 175 500 minecraft:sea_lantern
fill 413 175 501 413 200 501 minecraft:black_concrete
setblock 413 175 502 minecraft:sea_lantern
fill 413 175 503 413 200 503 minecraft:black_concrete
setblock 413 175 504 minecraft:sea_lantern
fill 388 176 481 389 177 483 minecraft:cyan_concrete
fill 389 176 478 389 177 480 minecraft:cyan_concrete
fill 389 176 484 389 177 486 minecraft:cyan_concrete
fill 390 176 477 390 177 478 minecraft:cyan_concrete
fill 390 176 486 390 177 487 minecraft:cyan_concrete
fill 391 176 476 391 177 477 minecraft:cyan_concrete
fill 391 176 487 391 177 488 minecraft:cyan_concrete
fill 392 176 475 392 177 476 minecraft:cyan_concrete
fill 392 176 488 392 177 489 minecraft:cyan_concrete
fill 393 176 475 400 177 475 minecraft:cyan_concrete
fill 393 176 489 400 177 489 minecraft:cyan_concrete
fill 395 176 474 397 177 474 minecraft:cyan_concrete
fill 395 176 490 397 177 490 minecraft:cyan_concrete
fill 400 176 476 401 177 476 minecraft:cyan_concrete
fill 400 176 488 401 177 488 minecraft:cyan_concrete
fill 401 176 477 402 177 477 minecraft:cyan_concrete
fill 401 176 487 402 177 487 minecraft:cyan_concrete
fill 402 176 478 403 177 478 minecraft:cyan_concrete
fill 402 176 486 403 177 486 minecraft:cyan_concrete
fill 403 176 479 403 177 485 minecraft:cyan_concrete
fill 404 176 481 404 177 483 minecraft:cyan_concrete
fill 407 176 498 407 177 498 minecraft:black_concrete
fill 407 176 500 407 177 500 minecraft:black_concrete
fill 407 176 502 407 177 502 minecraft:black_concrete
fill 407 176 504 407 177 504 minecraft:black_concrete
fill 408 176 499 408 177 499 minecraft:black_concrete
fill 408 176 501 408 177 501 minecraft:black_concrete
fill 408 176 503 408 177 503 minecraft:black_concrete
fill 409 176 498 409 177 498 minecraft:black_concrete
fill 409 176 500 409 177 500 minecraft:black_concrete
fill 409 176 502 409 177 502 minecraft:black_concrete
fill 409 176 504 409 177 504 minecraft:black_concrete
fill 410 176 499 410 177 499 minecraft:black_concrete
fill 410 176 501 410 177 501 minecraft:black_concrete
fill 410 176 503 410 177 503 minecraft:black_concrete
fill 411 176 498 411 177 498 minecraft:black_concrete
fill 411 176 500 411 177 500 minecraft:black_concrete
fill 411 176 502 411 177 502 minecraft:black_concrete
fill 411 176 504 411 177 504 minecraft:black_concrete
fill 412 176 499 412 177 499 minecraft:black_concrete
fill 412 176 501 412 177 501 minecraft:black_concrete
fill 412 176 503 412 177 503 minecraft:black_concrete
fill 413 176 498 413 177 498 minecraft:black_concrete
fill 413 176 500 413 177 500 minecraft:black_concrete
fill 413 176 502 413 177 502 minecraft:black_concrete
fill 413 176 504 413 177 504 minecraft:black_concrete
fill 376 178 468 376 185 468 minecraft:black_concrete
fill 376 178 476 376 185 476 minecraft:black_concrete
fill 376 178 484 376 185 484 minecraft:black_concrete
fill 376 178 492 376 185 492 minecraft:black_concrete
fill 376 178 500 376 185 500 minecraft:black_concrete
setblock 379 178 466 minecraft:light[level=14]
setblock 379 178 474 minecraft:light[level=14]
setblock 379 178 482 minecraft:light[level=14]
setblock 379 178 490 minecraft:light[level=14]
setblock 379 178 498 minecraft:light[level=14]
fill 379 178 505 379 185 505 minecraft:black_concrete
fill 383 178 463 383 185 463 minecraft:black_concrete
setblock 387 178 466 minecraft:light[level=14]
setblock 387 178 474 minecraft:light[level=14]
setblock 387 178 482 minecraft:light[level=14]
setblock 387 178 490 minecraft:light[level=14]
setblock 387 178 498 minecraft:light[level=14]
fill 387 178 505 387 185 505 minecraft:black_concrete
fill 391 178 463 391 185 463 minecraft:black_concrete
setblock 395 178 474 minecraft:light[level=14]
setblock 395 178 490 minecraft:light[level=14]
setblock 395 178 498 minecraft:light[level=14]
fill 395 178 505 395 185 505 minecraft:black_concrete
fill 399 178 463 399 185 463 minecraft:black_concrete
setblock 403 178 466 minecraft:light[level=14]
setblock 403 178 474 minecraft:light[level=14]
setblock 403 178 482 minecraft:light[level=14]
setblock 403 178 490 minecraft:light[level=14]
setblock 403 178 498 minecraft:light[level=14]
fill 403 178 505 403 185 505 minecraft:black_concrete
fill 407 178 463 407 185 463 minecraft:black_concrete
setblock 407 178 498 minecraft:sea_lantern
setblock 407 178 500 minecraft:sea_lantern
setblock 407 178 502 minecraft:sea_lantern
setblock 407 178 504 minecraft:sea_lantern
setblock 408 178 499 minecraft:sea_lantern
setblock 408 178 501 minecraft:sea_lantern
setblock 408 178 503 minecraft:sea_lantern
setblock 409 178 498 minecraft:sea_lantern
setblock 409 178 500 minecraft:sea_lantern
setblock 409 178 502 minecraft:sea_lantern
setblock 409 178 504 minecraft:sea_lantern
setblock 410 178 499 minecraft:sea_lantern
setblock 410 178 501 minecraft:sea_lantern
setblock 410 178 503 minecraft:sea_lantern
setblock 411 178 466 minecraft:light[level=14]
setblock 411 178 474 minecraft:light[level=14]
setblock 411 178 482 minecraft:light[level=14]
setblock 411 178 490 minecraft:light[level=14]
setblock 411 178 498 minecraft:sea_lantern
setblock 411 178 500 minecraft:sea_lantern
setblock 411 178 502 minecraft:sea_lantern
setblock 411 178 504 minecraft:sea_lantern
fill 411 178 505 411 185 505 minecraft:black_concrete
setblock 412 178 499 minecraft:sea_lantern
setblock 412 178 501 minecraft:sea_lantern
setblock 412 178 503 minecraft:sea_lantern
setblock 413 178 498 minecraft:sea_lantern
setblock 413 178 500 minecraft:sea_lantern
setblock 413 178 502 minecraft:sea_lantern
setblock 413 178 504 minecraft:sea_lantern
fill 415 178 463 415 185 463 minecraft:black_concrete
fill 418 178 468 418 185 468 minecraft:black_concrete
fill 418 178 476 418 185 476 minecraft:black_concrete
fill 418 178 484 418 185 484 minecraft:black_concrete
fill 418 178 492 418 185 492 minecraft:black_concrete
fill 418 178 500 418 185 500 minecraft:black_concrete
fill 407 179 498 407 180 498 minecraft:black_concrete
fill 407 179 500 407 180 500 minecraft:black_concrete
fill 407 179 502 407 180 502 minecraft:black_concrete
fill 407 179 504 407 180 504 minecraft:black_concrete
fill 408 179 499 408 180 499 minecraft:black_concrete
fill 408 179 501 408 180 501 minecraft:black_concrete
fill 408 179 503 408 180 503 minecraft:black_concrete
fill 409 179 498 409 180 498 minecraft:black_concrete
fill 409 179 500 409 180 500 minecraft:black_concrete
fill 409 179 502 409 180 502 minecraft:black_concrete
fill 409 179 504 409 180 504 minecraft:black_concrete
fill 410 179 499 410 180 499 minecraft:black_concrete
fill 410 179 501 410 180 501 minecraft:black_concrete
fill 410 179 503 410 180 503 minecraft:black_concrete
fill 411 179 498 411 180 498 minecraft:black_concrete
fill 411 179 500 411 180 500 minecraft:black_concrete
fill 411 179 502 411 180 502 minecraft:black_concrete
fill 411 179 504 411 180 504 minecraft:black_concrete
fill 412 179 499 412 180 499 minecraft:black_concrete
fill 412 179 501 412 180 501 minecraft:black_concrete
fill 412 179 503 412 180 503 minecraft:black_concrete
fill 413 179 498 413 180 498 minecraft:black_concrete
fill 413 179 500 413 180 500 minecraft:black_concrete
fill 413 179 502 413 180 502 minecraft:black_concrete
fill 413 179 504 413 180 504 minecraft:black_concrete
fill 386 180 481 387 181 483 minecraft:lime_concrete
fill 387 180 478 387 181 480 minecraft:lime_concrete
fill 387 180 484 387 181 486 minecraft:lime_concrete
fill 388 180 476 388 181 478 minecraft:lime_concrete
fill 388 180 486 388 181 488 minecraft:lime_concrete
fill 389 180 475 389 181 476 minecraft:lime_concrete
fill 389 180 488 389 181 489 minecraft:lime_concrete
fill 390 180 474 390 181 475 minecraft:lime_concrete
fill 390 180 489 390 181 490 minecraft:lime_concrete
fill 391 180 474 392 181 474 minecraft:lime_concrete
fill 391 180 490 392 181 490 minecraft:lime_concrete
fill 392 180 473 400 181 473 minecraft:lime_concrete
fill 392 180 491 400 181 491 minecraft:lime_concrete
fill 395 180 472 397 181 472 minecraft:lime_concrete
fill 395 180 492 397 181 492 minecraft:lime_concrete
fill 400 180 474 402 181 474 minecraft:lime_concrete
fill 400 180 490 402 181 490 minecraft:lime_concrete
fill 402 180 475 403 181 475 minecraft:lime_concrete
fill 402 180 489 403 181 489 minecraft:lime_concrete
fill 403 180 476 404 181 476 minecraft:lime_concrete
fill 403 180 488 404 181 488 minecraft:lime_concrete
fill 404 180 477 404 181 478 minecraft:lime_concrete
fill 404 180 486 404 181 487 minecraft:lime_concrete
fill 405 180 478 405 181 486 minecraft:lime_concrete
fill 406 180 481 406 181 483 minecraft:lime_concrete
setblock 407 181 498 minecraft:sea_lantern
setblock 407 181 500 minecraft:sea_lantern
setblock 407 181 502 minecraft:sea_lantern
setblock 407 181 504 minecraft:sea_lantern
setblock 408 181 499 minecraft:sea_lantern
setblock 408 181 501 minecraft:sea_lantern
setblock 408 181 503 minecraft:sea_lantern
setblock 409 181 498 minecraft:sea_lantern
setblock 409 181 500 minecraft:sea_lantern
setblock 409 181 502 minecraft:sea_lantern
setblock 409 181 504 minecraft:sea_lantern
setblock 410 181 499 minecraft:sea_lantern
setblock 410 181 501 minecraft:sea_lantern
setblock 410 181 503 minecraft:sea_lantern
setblock 411 181 498 minecraft:sea_lantern
setblock 411 181 500 minecraft:sea_lantern
setblock 411 181 502 minecraft:sea_lantern
setblock 411 181 504 minecraft:sea_lantern
setblock 412 181 499 minecraft:sea_lantern
setblock 412 181 501 minecraft:sea_lantern
setblock 412 181 503 minecraft:sea_lantern
setblock 413 181 498 minecraft:sea_lantern
setblock 413 181 500 minecraft:sea_lantern
setblock 413 181 502 minecraft:sea_lantern
setblock 413 181 504 minecraft:sea_lantern
fill 377 182 464 377 183 469 minecraft:black_concrete
fill 377 182 472 378 182 477 minecraft:black_concrete
fill 377 182 480 378 182 485 minecraft:black_concrete
fill 377 182 488 378 182 493 minecraft:black_concrete
fill 377 182 496 378 182 501 minecraft:black_concrete
fill 377 182 504 382 183 504 minecraft:black_concrete
fill 378 182 465 378 182 471 minecraft:black_concrete
fill 378 182 478 378 182 479 minecraft:black_concrete
fill 378 182 486 378 182 487 minecraft:black_concrete
fill 378 182 494 378 182 495 minecraft:black_concrete
fill 378 182 502 378 182 503 minecraft:black_concrete
fill 379 182 465 389 182 465 minecraft:black_concrete
fill 379 182 503 406 182 503 minecraft:black_concrete
fill 380 182 464 385 183 464 minecraft:black_concrete
fill 385 182 504 390 183 504 minecraft:black_concrete
fill 388 182 464 389 183 464 minecraft:black_concrete
fill 393 182 504 398 183 504 minecraft:black_concrete
fill 401 182 464 401 182 465 minecraft:black_concrete
fill 401 182 504 407 183 504 minecraft:black_concrete
fill 402 182 465 416 182 465 minecraft:black_concrete
fill 404 182 464 409 183 464 minecraft:black_concrete
fill 407 182 498 407 183 498 minecraft:black_concrete
fill 407 182 500 407 183 500 minecraft:black_concrete
fill 407 182 502 407 183 502 minecraft:black_concrete
fill 408 182 499 408 183 499 minecraft:black_concrete
fill 408 182 501 408 183 501 minecraft:black_concrete
fill 408 182 503 408 183 503 minecraft:black_concrete
fill 409 182 498 409 183 498 minecraft:black_concrete
fill 409 182 500 409 183 500 minecraft:black_concrete
fill 409 182 502 409 183 502 minecraft:black_concrete
fill 409 182 504 409 183 504 minecraft:black_concrete
fill 410 182 499 410 183 499 minecraft:black_concrete
fill 410 182 501 410 183 501 minecraft:black_concrete
fill 410 182 503 410 183 503 minecraft:black_concrete
fill 411 182 498 411 183 498 minecraft:black_concrete
fill 411 182 500 411 183 500 minecraft:black_concrete
fill 411 182 502 411 183 502 minecraft:black_concrete
fill 411 182 504 411 183 504 minecraft:black_concrete
fill 412 182 464 417 183 464 minecraft:black_concrete
fill 412 182 499 412 183 499 minecraft:black_concrete
fill 412 182 501 412 183 501 minecraft:black_concrete
fill 412 182 503 412 183 503 minecraft:black_concrete
fill 413 182 498 413 183 498 minecraft:black_concrete
fill 413 182 500 413 183 500 minecraft:black_concrete
fill 413 182 502 413 183 502 minecraft:black_concrete
fill 413 182 504 414 183 504 minecraft:black_concrete
fill 414 182 503 417 182 503 minecraft:black_concrete
fill 416 182 466 416 182 502 minecraft:black_concrete
fill 417 182 467 417 183 472 minecraft:black_concrete
fill 417 182 475 417 183 480 minecraft:black_concrete
fill 417 182 483 417 183 488 minecraft:black_concrete
fill 417 182 491 417 183 496 minecraft:black_concrete
fill 417 182 499 417 183 502 minecraft:black_concrete
fill 417 182 504 417 183 504 minecraft:black_concrete
fill 377 183 472 377 183 477 minecraft:black_concrete
fill 377 183 480 377 183 485 minecraft:black_concrete
fill 377 183 488 377 183 493 minecraft:black_concrete
fill 377 183 496 377 183 501 minecraft:black_concrete
setblock 401 183 464 minecraft:black_concrete
setblock 417 183 503 minecraft:black_concrete
setblock 407 184 498 minecraft:sea_lantern
setblock 407 184 500 minecraft:sea_lantern
setblock 407 184 502 minecraft:sea_lantern
setblock 407 184 504 minecraft:sea_lantern
setblock 408 184 499 minecraft:sea_lantern
setblock 408 184 501 minecraft:sea_lantern
setblock 408 184 503 minecraft:sea_lantern
setblock 409 184 498 minecraft:sea_lantern
setblock 409 184 500 minecraft:sea_lantern
setblock 409 184 502 minecraft:sea_lantern
setblock 409 184 504 minecraft:sea_lantern
setblock 410 184 499 minecraft:sea_lantern
setblock 410 184 501 minecraft:sea_lantern
setblock 410 184 503 minecraft:sea_lantern
setblock 411 184 498 minecraft:sea_lantern
setblock 411 184 500 minecraft:sea_lantern
setblock 411 184 502 minecraft:sea_lantern
setblock 411 184 504 minecraft:sea_lantern
setblock 412 184 499 minecraft:sea_lantern
setblock 412 184 501 minecraft:sea_lantern
setblock 412 184 503 minecraft:sea_lantern
setblock 413 184 498 minecraft:sea_lantern
setblock 413 184 500 minecraft:sea_lantern
setblock 413 184 502 minecraft:sea_lantern
setblock 413 184 504 minecraft:sea_lantern
fill 407 185 498 407 186 498 minecraft:black_concrete
fill 407 185 500 407 186 500 minecraft:black_concrete
fill 407 185 502 407 186 502 minecraft:black_concrete
fill 407 185 504 407 186 504 minecraft:black_concrete
fill 408 185 499 408 186 499 minecraft:black_concrete
fill 408 185 501 408 186 501 minecraft:black_concrete
fill 408 185 503 408 186 503 minecraft:black_concrete
fill 409 185 498 409 186 498 minecraft:black_concrete
fill 409 185 500 409 186 500 minecraft:black_concrete
fill 409 185 502 409 186 502 minecraft:black_concrete
fill 409 185 504 409 186 504 minecraft:black_concrete
fill 410 185 499 410 186 499 minecraft:black_concrete
fill 410 185 501 410 186 501 minecraft:black_concrete
fill 410 185 503 410 186 503 minecraft:black_concrete
fill 411 185 498 411 186 498 minecraft:black_concrete
fill 411 185 500 411 186 500 minecraft:black_concrete
fill 411 185 502 411 186 502 minecraft:black_concrete
fill 411 185 504 411 186 504 minecraft:black_concrete
fill 412 185 499 412 186 499 minecraft:black_concrete
fill 412 185 501 412 186 501 minecraft:black_concrete
fill 412 185 503 412 186 503 minecraft:black_concrete
fill 413 185 498 413 186 498 minecraft:black_concrete
fill 413 185 500 413 186 500 minecraft:black_concrete
fill 413 185 502 413 186 502 minecraft:black_concrete
fill 413 185 504 413 186 504 minecraft:black_concrete
fill 376 186 468 376 191 468 minecraft:sea_lantern
fill 376 186 476 376 191 476 minecraft:sea_lantern
fill 376 186 484 376 191 484 minecraft:sea_lantern
fill 376 186 492 376 191 492 minecraft:sea_lantern
fill 376 186 500 376 191 500 minecraft:sea_lantern
setblock 379 186 466 minecraft:light[level=14]
setblock 379 186 474 minecraft:light[level=14]
setblock 379 186 482 minecraft:light[level=14]
setblock 379 186 490 minecraft:light[level=14]
setblock 379 186 498 minecraft:light[level=14]
fill 379 186 505 379 191 505 minecraft:sea_lantern
fill 382 186 482 384 186 482 minecraft:glowstone
fill 383 186 463 383 191 463 minecraft:sea_lantern
setblock 383 186 481 minecraft:glowstone
setblock 383 186 483 minecraft:glowstone
fill 386 186 472 387 186 473 minecraft:glowstone
fill 386 186 491 387 186 492 minecraft:glowstone
setblock 387 186 466 minecraft:light[level=14]
setblock 387 186 474 minecraft:glowstone
setblock 387 186 482 minecraft:light[level=14]
setblock 387 186 490 minecraft:glowstone
setblock 387 186 498 minecraft:light[level=14]
fill 387 186 505 387 191 505 minecraft:sea_lantern
setblock 388 186 473 minecraft:glowstone
setblock 388 186 491 minecraft:glowstone
fill 390 186 464 393 197 469 minecraft:black_concrete
fill 391 186 463 391 191 463 minecraft:sea_lantern
fill 394 186 464 395 197 465 minecraft:black_concrete
fill 394 186 466 395 187 467 minecraft:magenta_concrete
fill 394 186 468 394 197 469 minecraft:black_concrete
fill 395 186 468 395 197 468 minecraft:black_concrete
fill 395 186 469 397 186 469 minecraft:glowstone
setblock 395 186 474 minecraft:light[level=14]
setblock 395 186 490 minecraft:light[level=14]
fill 395 186 495 397 186 495 minecraft:glowstone
setblock 395 186 498 minecraft:light[level=14]
fill 395 186 505 395 191 505 minecraft:sea_lantern
setblock 396 186 468 minecraft:glowstone
setblock 396 186 470 minecraft:glowstone
setblock 396 186 494 minecraft:glowstone
setblock 396 186 496 minecraft:glowstone
fill 399 186 463 399 191 463 minecraft:sea_lantern
setblock 403 186 466 minecraft:light[level=14]
setblock 403 186 474 minecraft:light[level=14]
setblock 403 186 482 minecraft:light[level=14]
setblock 403 186 490 minecraft:light[level=14]
setblock 403 186 498 minecraft:light[level=14]
fill 403 186 505 403 191 505 minecraft:sea_lantern
fill 404 186 473 406 186 473 minecraft:glowstone
fill 404 186 491 406 186 491 minecraft:glowstone
fill 405 186 472 406 186 472 minecraft:glowstone
setblock 405 186 474 minecraft:glowstone
setblock 405 186 490 minecraft:glowstone
fill 405 186 492 406 186 492 minecraft:glowstone
fill 407 186 463 407 191 463 minecraft:sea_lantern
fill 408 186 482 410 186 482 minecraft:glowstone
setblock 409 186 481 minecraft:glowstone
setblock 409 186 483 minecraft:glowstone
setblock 411 186 466 minecraft:light[level=14]
setblock 411 186 474 minecraft:light[level=14]
setblock 411 186 482 minecraft:light[level=14]
setblock 411 186 490 minecraft:light[level=14]
fill 411 186 505 411 191 505 minecraft:sea_lantern
fill 415 186 463 415 191 463 minecraft:sea_lantern
fill 418 186 468 418 191 468 minecraft:sea_lantern
fill 418 186 476 418 191 476 minecraft:sea_lantern
fill 418 186 484 418 191 484 minecraft:sea_lantern
fill 418 186 492 418 191 492 minecraft:sea_lantern
fill 418 186 500 418 191 500 minecraft:sea_lantern
fill 395 187 469 397 197 469 minecraft:black_concrete
fill 396 187 468 396 197 468 minecraft:black_concrete
setblock 407 187 498 minecraft:sea_lantern
setblock 407 187 500 minecraft:sea_lantern
setblock 407 187 502 minecraft:sea_lantern
setblock 407 187 504 minecraft:sea_lantern
setblock 408 187 499 minecraft:sea_lantern
setblock 408 187 501 minecraft:sea_lantern
setblock 408 187 503 minecraft:sea_lantern
setblock 409 187 498 minecraft:sea_lantern
setblock 409 187 500 minecraft:sea_lantern
setblock 409 187 502 minecraft:sea_lantern
setblock 409 187 504 minecraft:sea_lantern
setblock 410 187 499 minecraft:sea_lantern
setblock 410 187 501 minecraft:sea_lantern
setblock 410 187 503 minecraft:sea_lantern
setblock 411 187 498 minecraft:sea_lantern
setblock 411 187 500 minecraft:sea_lantern
setblock 411 187 502 minecraft:sea_lantern
setblock 411 187 504 minecraft:sea_lantern
setblock 412 187 499 minecraft:sea_lantern
setblock 412 187 501 minecraft:sea_lantern
setblock 412 187 503 minecraft:sea_lantern
setblock 413 187 498 minecraft:sea_lantern
setblock 413 187 500 minecraft:sea_lantern
setblock 413 187 502 minecraft:sea_lantern
setblock 413 187 504 minecraft:sea_lantern
fill 394 188 466 395 197 467 minecraft:black_concrete
fill 407 188 498 407 189 498 minecraft:black_concrete
schedule function dropper:buildpart/116_2 1t
