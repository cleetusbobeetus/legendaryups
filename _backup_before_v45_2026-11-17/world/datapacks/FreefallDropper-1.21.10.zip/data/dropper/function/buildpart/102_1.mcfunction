setblock 324 209 422 minecraft:dark_oak_planks
fill 324 209 426 324 211 426 minecraft:spruce_planks
fill 324 209 452 324 211 452 minecraft:spruce_planks
setblock 324 209 457 minecraft:dark_oak_planks
fill 282 210 416 282 211 416 minecraft:spruce_planks
setblock 282 210 417 minecraft:dark_oak_planks
fill 282 210 418 282 211 419 minecraft:spruce_planks
setblock 282 210 426 minecraft:dark_oak_planks
fill 282 210 427 282 211 429 minecraft:spruce_planks
fill 282 210 438 282 211 438 minecraft:spruce_planks
fill 282 210 445 282 212 445 minecraft:spruce_planks
fill 282 210 454 282 211 454 minecraft:spruce_planks
setblock 285 210 425 minecraft:waxed_cut_copper
setblock 285 210 427 minecraft:waxed_cut_copper
fill 287 210 416 287 211 416 minecraft:spruce_planks
setblock 287 210 425 minecraft:waxed_cut_copper
setblock 287 210 427 minecraft:waxed_cut_copper
fill 287 210 458 288 211 458 minecraft:spruce_planks
fill 299 210 416 299 211 416 minecraft:spruce_planks
setblock 300 210 416 minecraft:dark_oak_planks
fill 309 210 416 309 211 416 minecraft:spruce_planks
fill 311 210 416 311 211 416 minecraft:spruce_planks
fill 317 210 416 317 211 416 minecraft:spruce_planks
setblock 318 210 416 minecraft:dark_oak_planks
fill 319 210 416 319 211 416 minecraft:spruce_planks
fill 324 210 421 324 211 422 minecraft:spruce_planks
setblock 324 210 438 minecraft:dark_oak_planks
fill 324 210 457 324 211 457 minecraft:spruce_planks
setblock 282 211 417 minecraft:spruce_planks
setblock 282 211 426 minecraft:spruce_planks
setblock 282 211 432 minecraft:spruce_planks
setblock 298 211 416 minecraft:spruce_planks
setblock 300 211 416 minecraft:spruce_planks
fill 315 211 448 315 212 452 minecraft:waxed_copper_block
fill 316 211 434 320 212 438 minecraft:dark_oak_planks
fill 316 211 447 316 212 448 minecraft:waxed_copper_block
fill 316 211 450 320 212 450 minecraft:waxed_cut_copper
fill 316 211 452 316 212 453 minecraft:waxed_copper_block
fill 317 211 447 320 212 447 minecraft:waxed_copper_block
fill 317 211 453 320 212 453 minecraft:waxed_copper_block
setblock 318 211 416 minecraft:spruce_planks
fill 318 211 448 318 212 449 minecraft:waxed_cut_copper
fill 318 211 451 318 212 452 minecraft:waxed_cut_copper
fill 320 211 448 321 212 448 minecraft:waxed_copper_block
fill 320 211 452 321 212 452 minecraft:waxed_copper_block
fill 321 211 436 322 211 436 minecraft:dark_oak_planks
fill 321 211 449 321 212 451 minecraft:waxed_copper_block
setblock 324 211 438 minecraft:spruce_planks
fill 282 212 416 282 225 422 minecraft:dark_oak_planks
fill 282 212 423 282 212 424 minecraft:ochre_froglight
fill 282 212 425 282 213 434 minecraft:dark_oak_planks
fill 282 212 435 282 212 436 minecraft:ochre_froglight
fill 282 212 437 282 212 444 minecraft:dark_oak_planks
fill 282 212 446 282 213 446 minecraft:dark_oak_planks
fill 282 212 447 282 212 448 minecraft:ochre_froglight
fill 282 212 449 282 225 449 minecraft:dark_oak_planks
setblock 282 212 450 minecraft:spruce_planks
fill 282 212 451 282 225 458 minecraft:dark_oak_planks
fill 283 212 458 284 212 458 minecraft:ochre_froglight
fill 284 212 416 289 212 416 minecraft:dark_oak_planks
fill 285 212 458 294 212 458 minecraft:dark_oak_planks
fill 290 212 416 291 212 416 minecraft:ochre_froglight
fill 292 212 416 295 212 416 minecraft:dark_oak_planks
fill 295 212 458 296 212 458 minecraft:ochre_froglight
setblock 296 212 416 minecraft:spruce_planks
fill 297 212 416 300 212 416 minecraft:dark_oak_planks
fill 297 212 458 306 213 458 minecraft:dark_oak_planks
setblock 301 212 416 minecraft:spruce_planks
fill 302 212 416 303 212 416 minecraft:ochre_froglight
fill 304 212 416 305 213 416 minecraft:dark_oak_planks
setblock 306 212 416 minecraft:spruce_planks
fill 307 212 416 313 212 416 minecraft:dark_oak_planks
fill 307 212 458 308 212 458 minecraft:ochre_froglight
fill 309 212 458 318 212 458 minecraft:dark_oak_planks
fill 314 212 416 315 212 416 minecraft:ochre_froglight
fill 316 212 416 324 212 416 minecraft:dark_oak_planks
fill 319 212 458 320 212 458 minecraft:ochre_froglight
fill 321 212 458 323 213 458 minecraft:dark_oak_planks
fill 324 212 417 324 225 417 minecraft:dark_oak_planks
fill 324 212 418 324 212 419 minecraft:ochre_froglight
setblock 324 212 420 minecraft:spruce_planks
fill 324 212 421 324 212 429 minecraft:dark_oak_planks
fill 324 212 430 324 212 431 minecraft:ochre_froglight
fill 324 212 432 324 213 438 minecraft:dark_oak_planks
fill 324 212 439 324 213 439 minecraft:spruce_planks
fill 324 212 440 324 225 441 minecraft:dark_oak_planks
fill 324 212 442 324 212 443 minecraft:ochre_froglight
fill 324 212 444 324 213 450 minecraft:dark_oak_planks
setblock 324 212 451 minecraft:spruce_planks
fill 324 212 452 324 213 452 minecraft:dark_oak_planks
setblock 324 212 453 minecraft:spruce_planks
fill 324 212 454 324 212 455 minecraft:ochre_froglight
fill 324 212 456 324 225 457 minecraft:dark_oak_planks
fill 282 213 423 282 225 424 minecraft:dark_oak_planks
fill 282 213 435 282 225 435 minecraft:dark_oak_planks
setblock 282 213 436 minecraft:spruce_planks
fill 282 213 437 282 225 437 minecraft:dark_oak_planks
setblock 282 213 438 minecraft:spruce_planks
fill 282 213 439 282 307 442 minecraft:dark_oak_planks
setblock 282 213 443 minecraft:spruce_planks
fill 282 213 444 282 307 445 minecraft:dark_oak_planks
fill 282 213 447 282 213 448 minecraft:dark_oak_planks
fill 282 213 450 282 307 450 minecraft:dark_oak_planks
fill 283 213 416 285 307 416 minecraft:dark_oak_planks
fill 283 213 458 286 225 458 minecraft:dark_oak_planks
setblock 286 213 416 minecraft:spruce_planks
fill 287 213 416 291 225 416 minecraft:dark_oak_planks
setblock 287 213 458 minecraft:spruce_planks
fill 288 213 458 296 213 458 minecraft:dark_oak_planks
setblock 292 213 416 minecraft:spruce_planks
fill 293 213 416 296 213 416 minecraft:dark_oak_planks
setblock 297 213 416 minecraft:spruce_planks
fill 298 213 416 303 213 416 minecraft:dark_oak_planks
fill 306 213 416 306 307 416 minecraft:dark_oak_planks
setblock 307 213 416 minecraft:spruce_planks
fill 307 213 458 311 213 458 minecraft:dark_oak_planks
fill 308 213 416 321 213 416 minecraft:dark_oak_planks
setblock 312 213 458 minecraft:spruce_planks
fill 313 213 458 319 213 458 minecraft:dark_oak_planks
setblock 320 213 458 minecraft:spruce_planks
setblock 322 213 416 minecraft:spruce_planks
fill 323 213 416 323 307 416 minecraft:dark_oak_planks
setblock 324 213 416 minecraft:spruce_planks
fill 324 213 418 324 225 427 minecraft:dark_oak_planks
fill 324 213 428 324 214 428 minecraft:spruce_planks
fill 324 213 429 324 225 429 minecraft:dark_oak_planks
fill 324 213 430 324 214 430 minecraft:spruce_planks
fill 324 213 431 324 225 431 minecraft:dark_oak_planks
fill 324 213 442 324 225 443 minecraft:dark_oak_planks
fill 324 213 451 324 307 451 minecraft:dark_oak_planks
fill 324 213 453 324 225 455 minecraft:dark_oak_planks
fill 282 214 425 282 225 426 minecraft:dark_oak_planks
setblock 282 214 427 minecraft:spruce_planks
fill 282 214 428 282 307 429 minecraft:dark_oak_planks
setblock 282 214 430 minecraft:spruce_planks
fill 282 214 431 282 225 434 minecraft:dark_oak_planks
fill 282 214 436 282 225 436 minecraft:dark_oak_planks
fill 282 214 438 282 307 438 minecraft:dark_oak_planks
fill 282 214 443 282 307 443 minecraft:dark_oak_planks
setblock 282 214 446 minecraft:spruce_planks
fill 282 214 447 282 225 447 minecraft:dark_oak_planks
setblock 282 214 448 minecraft:spruce_planks
setblock 285 214 419 minecraft:light[level=14]
setblock 285 214 427 minecraft:light[level=14]
setblock 285 214 435 minecraft:light[level=14]
setblock 285 214 443 minecraft:light[level=14]
setblock 285 214 451 minecraft:light[level=14]
fill 286 214 416 286 307 416 minecraft:dark_oak_planks
fill 287 214 458 290 307 458 minecraft:dark_oak_planks
setblock 291 214 458 minecraft:spruce_planks
fill 292 214 416 292 225 416 minecraft:dark_oak_planks
fill 292 214 458 294 225 458 minecraft:dark_oak_planks
setblock 293 214 416 minecraft:spruce_planks
setblock 293 214 419 minecraft:light[level=14]
setblock 293 214 427 minecraft:light[level=14]
setblock 293 214 435 minecraft:light[level=14]
setblock 293 214 443 minecraft:light[level=14]
setblock 293 214 451 minecraft:light[level=14]
fill 294 214 416 297 307 416 minecraft:dark_oak_planks
fill 295 214 458 296 214 458 minecraft:spruce_planks
fill 297 214 458 302 225 458 minecraft:dark_oak_planks
fill 298 214 416 299 214 416 minecraft:spruce_planks
fill 300 214 416 301 225 416 minecraft:dark_oak_planks
setblock 301 214 419 minecraft:light[level=14]
setblock 301 214 427 minecraft:light[level=14]
setblock 301 214 435 minecraft:light[level=14]
setblock 301 214 443 minecraft:light[level=14]
setblock 301 214 451 minecraft:light[level=14]
setblock 302 214 416 minecraft:spruce_planks
fill 303 214 416 303 225 416 minecraft:dark_oak_planks
setblock 303 214 458 minecraft:spruce_planks
setblock 304 214 416 minecraft:spruce_planks
fill 304 214 458 308 225 458 minecraft:dark_oak_planks
fill 305 214 416 305 307 416 minecraft:dark_oak_planks
fill 307 214 416 310 307 416 minecraft:dark_oak_planks
setblock 309 214 419 minecraft:light[level=14]
setblock 309 214 427 minecraft:light[level=14]
setblock 309 214 435 minecraft:light[level=14]
setblock 309 214 443 minecraft:light[level=14]
setblock 309 214 451 minecraft:light[level=14]
setblock 309 214 458 minecraft:spruce_planks
fill 310 214 458 310 307 458 minecraft:dark_oak_planks
setblock 311 214 416 minecraft:spruce_planks
setblock 311 214 458 minecraft:spruce_planks
fill 312 214 416 322 225 416 minecraft:dark_oak_planks
fill 312 214 458 318 225 458 minecraft:dark_oak_planks
setblock 317 214 419 minecraft:light[level=14]
setblock 317 214 427 minecraft:light[level=14]
setblock 317 214 435 minecraft:light[level=14]
setblock 317 214 443 minecraft:light[level=14]
setblock 317 214 451 minecraft:light[level=14]
setblock 319 214 458 minecraft:spruce_planks
fill 320 214 458 322 225 458 minecraft:dark_oak_planks
fill 321 214 449 321 228 449 minecraft:waxed_copper_block
setblock 323 214 458 minecraft:spruce_planks
fill 324 214 416 324 307 416 minecraft:dark_oak_planks
fill 324 214 432 324 225 432 minecraft:dark_oak_planks
setblock 324 214 433 minecraft:spruce_planks
fill 324 214 434 324 307 439 minecraft:dark_oak_planks
fill 324 214 444 324 225 448 minecraft:dark_oak_planks
setblock 324 214 449 minecraft:spruce_planks
fill 324 214 450 324 307 450 minecraft:dark_oak_planks
setblock 324 214 452 minecraft:spruce_planks
fill 324 214 458 324 307 458 minecraft:dark_oak_planks
fill 282 215 427 282 307 427 minecraft:dark_oak_planks
fill 282 215 430 282 307 430 minecraft:dark_oak_planks
fill 282 215 446 282 225 446 minecraft:dark_oak_planks
fill 282 215 448 282 225 448 minecraft:dark_oak_planks
fill 291 215 458 291 307 458 minecraft:dark_oak_planks
fill 293 215 416 293 307 416 minecraft:dark_oak_planks
fill 295 215 458 296 225 458 minecraft:dark_oak_planks
fill 298 215 416 299 307 416 minecraft:dark_oak_planks
fill 302 215 416 302 225 416 minecraft:dark_oak_planks
fill 303 215 458 303 307 458 minecraft:dark_oak_planks
fill 304 215 416 304 225 416 minecraft:dark_oak_planks
fill 309 215 458 309 225 458 minecraft:dark_oak_planks
fill 311 215 416 311 307 416 minecraft:dark_oak_planks
fill 311 215 458 311 307 458 minecraft:dark_oak_planks
fill 319 215 458 319 225 458 minecraft:dark_oak_planks
fill 323 215 458 323 307 458 minecraft:dark_oak_planks
fill 324 215 428 324 307 428 minecraft:dark_oak_planks
fill 324 215 430 324 225 430 minecraft:dark_oak_planks
fill 324 215 433 324 307 433 minecraft:dark_oak_planks
fill 324 215 449 324 307 449 minecraft:dark_oak_planks
fill 324 215 452 324 307 452 minecraft:dark_oak_planks
fill 315 216 434 315 217 438 minecraft:waxed_copper_block
fill 316 216 433 316 217 434 minecraft:waxed_copper_block
fill 316 216 436 320 217 436 minecraft:waxed_cut_copper
fill 316 216 438 316 217 439 minecraft:waxed_copper_block
fill 317 216 433 320 217 433 minecraft:waxed_copper_block
fill 317 216 439 320 217 439 minecraft:waxed_copper_block
fill 318 216 434 318 217 435 minecraft:waxed_cut_copper
fill 318 216 437 318 217 438 minecraft:waxed_cut_copper
fill 320 216 434 321 217 434 minecraft:waxed_copper_block
fill 320 216 438 321 217 438 minecraft:waxed_copper_block
fill 321 216 435 321 217 437 minecraft:waxed_copper_block
setblock 285 217 425 minecraft:waxed_cut_copper
setblock 285 217 427 minecraft:waxed_cut_copper
setblock 287 217 425 minecraft:waxed_cut_copper
setblock 287 217 427 minecraft:waxed_cut_copper
fill 284 220 426 284 225 428 minecraft:waxed_cut_copper
fill 284 220 438 284 225 440 minecraft:waxed_cut_copper
fill 284 220 450 284 225 452 minecraft:waxed_cut_copper
fill 290 220 456 292 225 456 minecraft:waxed_cut_copper
fill 294 220 418 296 225 418 minecraft:waxed_cut_copper
fill 302 220 456 304 225 456 minecraft:waxed_cut_copper
fill 306 220 418 308 225 418 minecraft:waxed_cut_copper
fill 314 220 456 316 225 456 minecraft:waxed_cut_copper
fill 318 220 418 320 225 418 minecraft:waxed_cut_copper
fill 322 220 426 322 225 428 minecraft:waxed_cut_copper
fill 322 220 438 322 225 440 minecraft:waxed_cut_copper
fill 322 220 450 322 225 452 minecraft:waxed_cut_copper
fill 283 222 426 283 223 426 minecraft:waxed_copper_block
setblock 285 222 419 minecraft:light[level=14]
setblock 285 222 427 minecraft:light[level=14]
setblock 285 222 435 minecraft:light[level=14]
setblock 285 222 443 minecraft:light[level=14]
setblock 285 222 451 minecraft:light[level=14]
setblock 293 222 419 minecraft:light[level=14]
setblock 293 222 427 minecraft:light[level=14]
setblock 293 222 435 minecraft:light[level=14]
setblock 293 222 443 minecraft:light[level=14]
setblock 293 222 451 minecraft:light[level=14]
setblock 301 222 419 minecraft:light[level=14]
setblock 301 222 427 minecraft:light[level=14]
setblock 301 222 435 minecraft:light[level=14]
setblock 301 222 443 minecraft:light[level=14]
setblock 301 222 451 minecraft:light[level=14]
setblock 309 222 419 minecraft:light[level=14]
setblock 309 222 427 minecraft:light[level=14]
setblock 309 222 435 minecraft:light[level=14]
setblock 309 222 443 minecraft:light[level=14]
setblock 309 222 451 minecraft:light[level=14]
setblock 317 222 419 minecraft:light[level=14]
setblock 317 222 427 minecraft:light[level=14]
setblock 317 222 435 minecraft:light[level=14]
setblock 317 222 443 minecraft:light[level=14]
setblock 317 222 451 minecraft:light[level=14]
setblock 288 223 426 minecraft:ochre_froglight
setblock 285 224 425 minecraft:waxed_cut_copper
setblock 285 224 427 minecraft:waxed_cut_copper
setblock 287 224 425 minecraft:waxed_cut_copper
setblock 287 224 427 minecraft:waxed_cut_copper
fill 283 225 420 283 225 425 minecraft:dark_oak_planks
fill 283 225 432 283 225 438 minecraft:dark_oak_planks
fill 283 225 444 283 225 449 minecraft:dark_oak_planks
fill 283 225 456 283 225 457 minecraft:dark_oak_planks
fill 284 225 457 287 225 457 minecraft:dark_oak_planks
fill 285 225 436 289 226 440 minecraft:dark_oak_planks
fill 287 225 417 292 225 417 minecraft:dark_oak_planks
fill 294 225 457 299 225 457 minecraft:dark_oak_planks
fill 299 225 417 304 225 417 minecraft:dark_oak_planks
fill 306 225 457 311 225 457 minecraft:dark_oak_planks
fill 311 225 417 316 225 417 minecraft:dark_oak_planks
fill 318 225 457 323 225 457 minecraft:dark_oak_planks
fill 323 225 417 323 225 422 minecraft:dark_oak_planks
fill 323 225 429 323 225 434 minecraft:dark_oak_planks
fill 323 225 441 323 225 446 minecraft:dark_oak_planks
fill 323 225 453 323 225 456 minecraft:dark_oak_planks
fill 282 226 416 282 307 421 minecraft:dark_oak_planks
fill 282 226 422 282 228 425 minecraft:ochre_froglight
fill 282 226 426 282 307 426 minecraft:dark_oak_planks
fill 282 226 431 282 307 433 minecraft:dark_oak_planks
fill 282 226 434 282 228 437 minecraft:ochre_froglight
fill 282 226 446 282 228 449 minecraft:ochre_froglight
fill 282 226 451 282 307 457 minecraft:dark_oak_planks
fill 282 226 458 285 228 458 minecraft:ochre_froglight
fill 286 226 458 286 307 458 minecraft:dark_oak_planks
fill 287 226 416 288 307 416 minecraft:dark_oak_planks
fill 289 226 416 292 228 416 minecraft:ochre_froglight
fill 292 226 458 293 307 458 minecraft:dark_oak_planks
fill 294 226 458 297 228 458 minecraft:ochre_froglight
fill 298 226 458 302 307 458 minecraft:dark_oak_planks
fill 300 226 416 300 307 416 minecraft:dark_oak_planks
fill 301 226 416 304 228 416 minecraft:ochre_froglight
fill 304 226 458 305 307 458 minecraft:dark_oak_planks
fill 306 226 458 309 228 458 minecraft:ochre_froglight
fill 312 226 416 312 307 416 minecraft:dark_oak_planks
fill 312 226 458 317 307 458 minecraft:dark_oak_planks
fill 313 226 416 316 228 416 minecraft:ochre_froglight
fill 317 226 416 322 307 416 minecraft:dark_oak_planks
fill 318 226 458 321 228 458 minecraft:ochre_froglight
fill 322 226 458 322 307 458 minecraft:dark_oak_planks
fill 324 226 417 324 228 420 minecraft:ochre_froglight
fill 324 226 421 324 307 427 minecraft:dark_oak_planks
fill 324 226 429 324 228 432 minecraft:ochre_froglight
fill 324 226 440 324 307 440 minecraft:dark_oak_planks
fill 324 226 441 324 228 444 minecraft:ochre_froglight
fill 324 226 445 324 307 448 minecraft:dark_oak_planks
fill 324 226 453 324 228 456 minecraft:ochre_froglight
fill 324 226 457 324 307 457 minecraft:dark_oak_planks
fill 282 229 422 282 245 425 minecraft:dark_oak_planks
fill 282 229 434 282 245 437 minecraft:dark_oak_planks
fill 282 229 446 282 245 449 minecraft:dark_oak_planks
fill 282 229 458 285 245 458 minecraft:dark_oak_planks
fill 289 229 416 292 245 416 minecraft:dark_oak_planks
fill 294 229 458 297 245 458 minecraft:dark_oak_planks
fill 301 229 416 304 245 416 minecraft:dark_oak_planks
fill 306 229 458 309 245 458 minecraft:dark_oak_planks
fill 313 229 416 316 245 416 minecraft:dark_oak_planks
fill 318 229 458 321 245 458 minecraft:dark_oak_planks
fill 324 229 417 324 245 420 minecraft:dark_oak_planks
fill 324 229 429 324 245 432 minecraft:dark_oak_planks
fill 324 229 441 324 245 444 minecraft:dark_oak_planks
fill 324 229 453 324 245 456 minecraft:dark_oak_planks
setblock 285 230 419 minecraft:light[level=14]
setblock 285 230 427 minecraft:light[level=14]
setblock 285 230 435 minecraft:light[level=14]
setblock 285 230 443 minecraft:light[level=14]
setblock 285 230 451 minecraft:light[level=14]
setblock 293 230 419 minecraft:light[level=14]
setblock 293 230 427 minecraft:light[level=14]
setblock 293 230 435 minecraft:light[level=14]
setblock 293 230 443 minecraft:light[level=14]
setblock 293 230 451 minecraft:light[level=14]
setblock 301 230 419 minecraft:light[level=14]
setblock 301 230 427 minecraft:light[level=14]
setblock 301 230 435 minecraft:light[level=14]
setblock 301 230 443 minecraft:light[level=14]
setblock 301 230 451 minecraft:light[level=14]
setblock 309 230 419 minecraft:light[level=14]
setblock 309 230 427 minecraft:light[level=14]
setblock 309 230 435 minecraft:light[level=14]
setblock 309 230 443 minecraft:light[level=14]
setblock 309 230 451 minecraft:light[level=14]
setblock 317 230 419 minecraft:light[level=14]
setblock 317 230 427 minecraft:light[level=14]
setblock 317 230 435 minecraft:light[level=14]
setblock 317 230 443 minecraft:light[level=14]
setblock 317 230 451 minecraft:light[level=14]
fill 291 234 438 301 234 438 minecraft:waxed_copper_block
fill 292 234 433 313 234 434 minecraft:waxed_copper_block
fill 292 234 437 302 234 437 minecraft:waxed_copper_block
fill 292 234 440 303 234 441 minecraft:waxed_copper_block
fill 293 234 444 313 234 444 minecraft:waxed_copper_block
fill 294 234 430 295 235 430 minecraft:waxed_copper_block
fill 294 234 435 303 234 436 minecraft:waxed_copper_block
fill 294 234 439 302 234 439 minecraft:waxed_copper_block
fill 294 234 442 316 234 442 minecraft:waxed_copper_block
fill 294 234 445 294 235 445 minecraft:waxed_copper_block
fill 295 234 431 312 234 432 minecraft:waxed_copper_block
fill 295 234 443 316 234 443 minecraft:waxed_copper_block
fill 296 234 445 313 235 445 minecraft:waxed_copper_block
fill 296 234 447 296 235 448 minecraft:waxed_copper_block
fill 297 234 428 298 235 428 minecraft:waxed_copper_block
fill 297 234 430 311 234 430 minecraft:waxed_copper_block
fill 297 234 446 310 235 447 minecraft:waxed_copper_block
fill 298 234 427 298 235 427 minecraft:waxed_copper_block
fill 298 234 429 312 235 429 minecraft:waxed_copper_block
fill 299 234 448 300 235 450 minecraft:waxed_copper_block
fill 300 234 428 309 235 428 minecraft:waxed_copper_block
fill 301 234 426 302 235 427 minecraft:waxed_copper_block
fill 301 234 448 308 235 448 minecraft:waxed_copper_block
fill 303 234 449 304 235 450 minecraft:waxed_copper_block
fill 304 234 425 304 235 427 minecraft:waxed_copper_block
fill 304 234 435 316 234 435 minecraft:waxed_copper_block
fill 304 234 441 314 234 441 minecraft:waxed_copper_block
fill 304 234 451 304 235 451 minecraft:waxed_copper_block
fill 305 234 426 305 235 427 minecraft:waxed_copper_block
fill 305 234 436 316 234 436 minecraft:waxed_copper_block
fill 305 234 440 314 234 440 minecraft:waxed_copper_block
fill 306 234 437 314 234 437 minecraft:waxed_copper_block
fill 306 234 439 316 234 439 minecraft:waxed_copper_block
fill 306 234 449 307 235 450 minecraft:waxed_copper_block
fill 307 234 438 317 234 438 minecraft:waxed_copper_block
fill 308 234 426 309 235 427 minecraft:waxed_copper_block
fill 310 234 448 310 235 449 minecraft:waxed_copper_block
fill 311 234 446 311 235 446 minecraft:waxed_copper_block
fill 311 234 448 311 235 448 minecraft:waxed_copper_block
fill 312 234 428 312 235 428 minecraft:waxed_copper_block
fill 313 234 432 315 235 432 minecraft:waxed_copper_block
fill 313 234 446 314 235 446 minecraft:waxed_copper_block
fill 314 234 431 314 235 431 minecraft:waxed_copper_block
fill 314 234 434 314 235 434 minecraft:waxed_copper_block
fill 283 235 417 290 235 457 minecraft:spruce_planks
fill 291 235 417 291 235 437 minecraft:spruce_planks
fill 291 235 438 300 235 438 minecraft:waxed_copper_block
fill 291 235 439 291 235 457 minecraft:spruce_planks
fill 292 235 417 293 235 432 minecraft:spruce_planks
fill 292 235 433 301 235 434 minecraft:waxed_copper_block
fill 292 235 435 293 235 436 minecraft:spruce_planks
fill 292 235 437 300 235 437 minecraft:waxed_copper_block
fill 292 235 439 293 235 439 minecraft:spruce_planks
fill 292 235 440 295 235 441 minecraft:waxed_copper_block
fill 292 235 442 292 235 457 minecraft:spruce_planks
fill 293 235 442 293 235 443 minecraft:spruce_planks
fill 293 235 444 297 235 444 minecraft:waxed_copper_block
fill 293 235 445 293 235 457 minecraft:spruce_planks
fill 294 235 417 296 235 429 minecraft:spruce_planks
fill 294 235 431 294 235 432 minecraft:spruce_planks
fill 294 235 435 301 235 436 minecraft:waxed_copper_block
fill 294 235 439 295 235 439 minecraft:waxed_copper_block
fill 294 235 442 296 235 442 minecraft:waxed_copper_block
setblock 294 235 443 minecraft:spruce_planks
fill 294 235 446 295 235 457 minecraft:spruce_planks
fill 295 235 431 299 235 432 minecraft:waxed_copper_block
fill 295 235 443 297 235 443 minecraft:waxed_copper_block
setblock 295 235 445 minecraft:spruce_planks
setblock 296 235 430 minecraft:spruce_planks
fill 296 235 439 300 235 440 minecraft:gold_block
setblock 296 235 441 minecraft:waxed_copper_block
setblock 296 235 446 minecraft:spruce_planks
fill 296 235 449 298 235 457 minecraft:spruce_planks
fill 297 235 417 297 235 427 minecraft:spruce_planks
setblock 297 235 429 minecraft:spruce_planks
fill 297 235 430 301 235 430 minecraft:waxed_copper_block
fill 297 235 441 301 235 442 minecraft:gold_block
fill 297 235 448 298 235 448 minecraft:spruce_planks
fill 298 235 417 300 235 426 minecraft:spruce_planks
fill 298 235 443 300 235 444 minecraft:gold_block
fill 299 235 427 299 235 428 minecraft:spruce_planks
fill 299 235 451 303 235 457 minecraft:spruce_planks
setblock 300 235 427 minecraft:spruce_planks
fill 300 235 431 308 235 431 minecraft:gold_block
setblock 300 235 432 minecraft:waxed_copper_block
fill 301 235 417 303 235 425 minecraft:spruce_planks
fill 301 235 432 307 235 432 minecraft:gold_block
fill 301 235 437 301 235 439 minecraft:ochre_froglight
setblock 301 235 440 minecraft:gold_block
setblock 301 235 443 minecraft:gold_block
fill 301 235 444 307 235 444 minecraft:waxed_copper_block
fill 301 235 449 302 235 450 minecraft:spruce_planks
fill 302 235 430 306 235 430 minecraft:gold_block
fill 302 235 433 306 235 434 minecraft:gold_block
setblock 302 235 435 minecraft:waxed_copper_block
fill 302 235 436 302 235 437 minecraft:ochre_froglight
fill 302 235 439 302 235 440 minecraft:ochre_froglight
setblock 302 235 441 minecraft:gold_block
fill 302 235 442 306 235 443 minecraft:waxed_copper_block
fill 303 235 426 303 235 427 minecraft:spruce_planks
fill 303 235 435 303 235 436 minecraft:ochre_froglight
fill 303 235 440 303 235 441 minecraft:ochre_froglight
fill 304 235 417 323 235 424 minecraft:spruce_planks
fill 304 235 435 305 235 435 minecraft:ochre_froglight
fill 304 235 441 305 235 441 minecraft:ochre_froglight
fill 304 235 452 323 235 457 minecraft:spruce_planks
fill 305 235 425 323 235 425 minecraft:spruce_planks
fill 305 235 436 306 235 436 minecraft:ochre_froglight
fill 305 235 440 306 235 440 minecraft:ochre_froglight
fill 305 235 449 305 235 451 minecraft:spruce_planks
fill 306 235 426 307 235 427 minecraft:spruce_planks
fill 306 235 435 316 235 435 minecraft:waxed_copper_block
fill 306 235 437 307 235 437 minecraft:ochre_froglight
fill 306 235 439 307 235 439 minecraft:ochre_froglight
fill 306 235 441 311 235 441 minecraft:gold_block
fill 306 235 451 323 235 451 minecraft:spruce_planks
fill 307 235 430 311 235 430 minecraft:waxed_copper_block
fill 307 235 433 313 235 434 minecraft:waxed_copper_block
fill 307 235 436 316 235 436 minecraft:waxed_copper_block
setblock 307 235 438 minecraft:ochre_froglight
fill 307 235 440 312 235 440 minecraft:gold_block
fill 307 235 442 310 235 443 minecraft:gold_block
fill 308 235 432 312 235 432 minecraft:waxed_copper_block
fill 308 235 437 314 235 437 minecraft:waxed_copper_block
fill 308 235 438 312 235 439 minecraft:gold_block
fill 308 235 444 310 235 444 minecraft:gold_block
fill 308 235 449 309 235 450 minecraft:spruce_planks
fill 309 235 431 312 235 431 minecraft:waxed_copper_block
setblock 309 235 448 minecraft:spruce_planks
fill 310 235 426 311 235 428 minecraft:spruce_planks
fill 310 235 450 323 235 450 minecraft:spruce_planks
setblock 311 235 442 minecraft:gold_block
fill 311 235 443 313 235 444 minecraft:waxed_copper_block
fill 311 235 447 323 235 447 minecraft:spruce_planks
fill 311 235 449 323 235 449 minecraft:spruce_planks
fill 312 235 426 323 235 427 minecraft:spruce_planks
fill 312 235 430 323 235 430 minecraft:spruce_planks
fill 312 235 441 314 235 442 minecraft:waxed_copper_block
setblock 312 235 446 minecraft:spruce_planks
fill 312 235 448 323 235 448 minecraft:spruce_planks
fill 313 235 428 323 235 429 minecraft:spruce_planks
setblock 313 235 431 minecraft:spruce_planks
fill 313 235 438 314 235 440 minecraft:waxed_copper_block
fill 314 235 433 323 235 433 minecraft:spruce_planks
fill 314 235 443 316 235 443 minecraft:waxed_copper_block
fill 314 235 444 323 235 445 minecraft:spruce_planks
fill 315 235 431 323 235 431 minecraft:spruce_planks
fill 315 235 434 323 235 434 minecraft:spruce_planks
fill 315 235 437 323 235 437 minecraft:spruce_planks
fill 315 235 438 316 235 439 minecraft:waxed_copper_block
fill 315 235 440 323 235 441 minecraft:spruce_planks
fill 315 235 442 316 235 442 minecraft:waxed_copper_block
fill 315 235 446 323 235 446 minecraft:spruce_planks
fill 316 235 432 323 235 432 minecraft:spruce_planks
fill 317 235 435 323 235 436 minecraft:spruce_planks
setblock 317 235 438 minecraft:waxed_copper_block
fill 317 235 439 323 235 439 minecraft:spruce_planks
fill 317 235 442 323 235 443 minecraft:spruce_planks
fill 318 235 438 323 235 438 minecraft:spruce_planks
setblock 285 238 419 minecraft:light[level=14]
setblock 285 238 427 minecraft:light[level=14]
setblock 285 238 435 minecraft:light[level=14]
setblock 285 238 443 minecraft:light[level=14]
setblock 285 238 451 minecraft:light[level=14]
setblock 293 238 419 minecraft:light[level=14]
setblock 293 238 427 minecraft:light[level=14]
setblock 293 238 435 minecraft:light[level=14]
setblock 293 238 443 minecraft:light[level=14]
setblock 293 238 451 minecraft:light[level=14]
setblock 301 238 419 minecraft:light[level=14]
setblock 301 238 427 minecraft:light[level=14]
setblock 301 238 435 minecraft:light[level=14]
setblock 301 238 443 minecraft:light[level=14]
setblock 301 238 451 minecraft:light[level=14]
setblock 309 238 419 minecraft:light[level=14]
setblock 309 238 427 minecraft:light[level=14]
setblock 309 238 435 minecraft:light[level=14]
setblock 309 238 443 minecraft:light[level=14]
setblock 309 238 451 minecraft:light[level=14]
setblock 317 238 419 minecraft:light[level=14]
setblock 317 238 427 minecraft:light[level=14]
setblock 317 238 435 minecraft:light[level=14]
setblock 317 238 443 minecraft:light[level=14]
setblock 317 238 451 minecraft:light[level=14]
fill 283 239 417 285 273 417 minecraft:waxed_cut_copper
fill 283 239 427 283 273 429 minecraft:waxed_cut_copper
fill 283 239 439 283 273 441 minecraft:waxed_cut_copper
fill 283 239 451 283 273 453 minecraft:waxed_cut_copper
fill 286 239 431 286 273 431 minecraft:waxed_copper_block
fill 289 239 457 291 273 457 minecraft:waxed_cut_copper
fill 295 239 417 297 273 417 minecraft:waxed_cut_copper
fill 301 239 457 303 273 457 minecraft:waxed_cut_copper
fill 307 239 417 309 273 417 minecraft:waxed_cut_copper
fill 313 239 457 315 273 457 minecraft:waxed_cut_copper
fill 319 239 417 321 273 417 minecraft:waxed_cut_copper
fill 323 239 425 323 273 427 minecraft:waxed_cut_copper
fill 323 239 437 323 273 439 minecraft:waxed_cut_copper
fill 323 239 449 323 273 451 minecraft:waxed_cut_copper
fill 284 240 426 284 245 428 minecraft:waxed_cut_copper
fill 284 240 438 284 245 440 minecraft:waxed_cut_copper
fill 284 240 450 284 245 452 minecraft:waxed_cut_copper
fill 290 240 456 292 245 456 minecraft:waxed_cut_copper
fill 294 240 418 296 245 418 minecraft:waxed_cut_copper
fill 302 240 456 304 245 456 minecraft:waxed_cut_copper
fill 306 240 418 308 245 418 minecraft:waxed_cut_copper
fill 314 240 456 316 245 456 minecraft:waxed_cut_copper
fill 318 240 418 320 245 418 minecraft:waxed_cut_copper
fill 322 240 426 322 245 428 minecraft:waxed_cut_copper
fill 322 240 438 322 245 440 minecraft:waxed_cut_copper
fill 322 240 450 322 245 452 minecraft:waxed_cut_copper
fill 285 241 430 285 241 432 minecraft:waxed_cut_copper
fill 286 241 430 287 241 430 minecraft:waxed_cut_copper
fill 286 241 432 287 241 432 minecraft:waxed_cut_copper
setblock 287 241 431 minecraft:waxed_cut_copper
fill 283 245 420 283 245 425 minecraft:dark_oak_planks
fill 283 245 432 283 245 437 minecraft:dark_oak_planks
fill 283 245 444 283 245 449 minecraft:dark_oak_planks
fill 283 245 456 283 245 457 minecraft:dark_oak_planks
fill 284 245 457 287 245 457 minecraft:dark_oak_planks
fill 287 245 417 292 245 417 minecraft:dark_oak_planks
fill 294 245 457 299 245 457 minecraft:dark_oak_planks
fill 299 245 417 304 245 417 minecraft:dark_oak_planks
fill 306 245 457 311 245 457 minecraft:dark_oak_planks
fill 311 245 417 316 245 417 minecraft:dark_oak_planks
fill 318 245 457 323 245 457 minecraft:dark_oak_planks
fill 323 245 417 323 245 422 minecraft:dark_oak_planks
fill 323 245 429 323 245 434 minecraft:dark_oak_planks
fill 323 245 441 323 245 446 minecraft:dark_oak_planks
fill 323 245 453 323 245 456 minecraft:dark_oak_planks
fill 282 246 422 282 251 425 minecraft:ochre_froglight
fill 282 246 434 282 251 437 minecraft:ochre_froglight
fill 282 246 446 282 251 449 minecraft:ochre_froglight
fill 282 246 458 285 251 458 minecraft:ochre_froglight
setblock 285 246 419 minecraft:light[level=14]
setblock 285 246 427 minecraft:light[level=14]
setblock 285 246 435 minecraft:light[level=14]
setblock 285 246 443 minecraft:light[level=14]
setblock 285 246 451 minecraft:light[level=14]
fill 289 246 416 292 251 416 minecraft:ochre_froglight
setblock 293 246 419 minecraft:light[level=14]
setblock 293 246 427 minecraft:light[level=14]
setblock 293 246 435 minecraft:light[level=14]
setblock 293 246 443 minecraft:light[level=14]
setblock 293 246 451 minecraft:light[level=14]
fill 294 246 458 297 251 458 minecraft:ochre_froglight
fill 301 246 416 304 251 416 minecraft:ochre_froglight
setblock 301 246 419 minecraft:light[level=14]
setblock 301 246 427 minecraft:light[level=14]
setblock 301 246 435 minecraft:light[level=14]
setblock 301 246 443 minecraft:light[level=14]
setblock 301 246 451 minecraft:light[level=14]
fill 306 246 458 309 251 458 minecraft:ochre_froglight
setblock 309 246 419 minecraft:light[level=14]
setblock 309 246 427 minecraft:light[level=14]
setblock 309 246 435 minecraft:light[level=14]
setblock 309 246 443 minecraft:light[level=14]
setblock 309 246 451 minecraft:light[level=14]
fill 313 246 416 316 251 416 minecraft:ochre_froglight
setblock 317 246 419 minecraft:light[level=14]
setblock 317 246 427 minecraft:light[level=14]
setblock 317 246 435 minecraft:light[level=14]
setblock 317 246 443 minecraft:light[level=14]
setblock 317 246 451 minecraft:light[level=14]
fill 318 246 458 321 251 458 minecraft:ochre_froglight
fill 324 246 417 324 251 420 minecraft:ochre_froglight
fill 324 246 429 324 251 432 minecraft:ochre_froglight
fill 324 246 441 324 251 444 minecraft:ochre_froglight
fill 324 246 453 324 251 456 minecraft:ochre_froglight
fill 285 249 430 285 249 432 minecraft:waxed_cut_copper
fill 286 249 430 287 249 430 minecraft:waxed_cut_copper
fill 286 249 432 287 249 432 minecraft:waxed_cut_copper
setblock 287 249 431 minecraft:waxed_cut_copper
fill 282 252 422 282 265 422 minecraft:dark_oak_planks
fill 282 252 423 282 252 424 minecraft:ochre_froglight
fill 282 252 425 282 265 425 minecraft:dark_oak_planks
fill 282 252 434 282 265 434 minecraft:dark_oak_planks
fill 282 252 435 282 252 436 minecraft:ochre_froglight
fill 282 252 437 282 265 437 minecraft:dark_oak_planks
fill 282 252 446 282 265 446 minecraft:dark_oak_planks
fill 282 252 447 282 252 448 minecraft:ochre_froglight
fill 282 252 449 282 265 449 minecraft:dark_oak_planks
fill 282 252 458 282 265 458 minecraft:dark_oak_planks
fill 283 252 458 284 252 458 minecraft:ochre_froglight
fill 285 252 458 285 265 458 minecraft:dark_oak_planks
fill 289 252 416 289 265 416 minecraft:dark_oak_planks
fill 290 252 416 291 252 416 minecraft:ochre_froglight
fill 292 252 416 292 265 416 minecraft:dark_oak_planks
fill 294 252 458 294 265 458 minecraft:dark_oak_planks
fill 295 252 458 296 252 458 minecraft:ochre_froglight
fill 297 252 458 297 265 458 minecraft:dark_oak_planks
fill 301 252 416 301 265 416 minecraft:dark_oak_planks
fill 302 252 416 303 252 416 minecraft:ochre_froglight
fill 304 252 416 304 265 416 minecraft:dark_oak_planks
fill 306 252 458 306 265 458 minecraft:dark_oak_planks
fill 307 252 458 308 252 458 minecraft:ochre_froglight
fill 309 252 458 309 265 458 minecraft:dark_oak_planks
fill 313 252 416 313 265 416 minecraft:dark_oak_planks
fill 314 252 416 315 252 416 minecraft:ochre_froglight
fill 316 252 416 316 265 416 minecraft:dark_oak_planks
fill 318 252 458 318 265 458 minecraft:dark_oak_planks
fill 319 252 458 320 252 458 minecraft:ochre_froglight
fill 321 252 458 321 265 458 minecraft:dark_oak_planks
fill 324 252 417 324 265 417 minecraft:dark_oak_planks
fill 324 252 418 324 252 419 minecraft:ochre_froglight
fill 324 252 420 324 265 420 minecraft:dark_oak_planks
fill 324 252 429 324 265 429 minecraft:dark_oak_planks
fill 324 252 430 324 252 431 minecraft:ochre_froglight
fill 324 252 432 324 265 432 minecraft:dark_oak_planks
fill 324 252 441 324 265 441 minecraft:dark_oak_planks
fill 324 252 442 324 252 443 minecraft:ochre_froglight
fill 324 252 444 324 265 444 minecraft:dark_oak_planks
fill 324 252 453 324 265 453 minecraft:dark_oak_planks
fill 324 252 454 324 252 455 minecraft:ochre_froglight
fill 324 252 456 324 265 456 minecraft:dark_oak_planks
fill 282 253 423 282 265 424 minecraft:dark_oak_planks
fill 282 253 435 282 265 436 minecraft:dark_oak_planks
fill 282 253 447 282 265 448 minecraft:dark_oak_planks
fill 283 253 458 284 265 458 minecraft:dark_oak_planks
fill 290 253 416 291 265 416 minecraft:dark_oak_planks
fill 295 253 458 296 265 458 minecraft:dark_oak_planks
fill 302 253 416 303 265 416 minecraft:dark_oak_planks
fill 307 253 458 308 265 458 minecraft:dark_oak_planks
fill 314 253 416 315 265 416 minecraft:dark_oak_planks
fill 319 253 458 320 265 458 minecraft:dark_oak_planks
fill 324 253 418 324 265 419 minecraft:dark_oak_planks
fill 324 253 430 324 265 431 minecraft:dark_oak_planks
fill 324 253 442 324 265 443 minecraft:dark_oak_planks
fill 324 253 454 324 265 455 minecraft:dark_oak_planks
setblock 285 254 419 minecraft:light[level=14]
setblock 285 254 427 minecraft:light[level=14]
setblock 285 254 435 minecraft:light[level=14]
setblock 285 254 443 minecraft:light[level=14]
setblock 285 254 451 minecraft:light[level=14]
setblock 293 254 419 minecraft:light[level=14]
setblock 293 254 427 minecraft:light[level=14]
setblock 293 254 435 minecraft:light[level=14]
setblock 293 254 443 minecraft:light[level=14]
setblock 293 254 451 minecraft:light[level=14]
setblock 301 254 419 minecraft:light[level=14]
setblock 301 254 427 minecraft:light[level=14]
setblock 301 254 435 minecraft:light[level=14]
setblock 301 254 443 minecraft:light[level=14]
setblock 301 254 451 minecraft:light[level=14]
setblock 309 254 419 minecraft:light[level=14]
setblock 309 254 427 minecraft:light[level=14]
setblock 309 254 435 minecraft:light[level=14]
setblock 309 254 443 minecraft:light[level=14]
setblock 309 254 451 minecraft:light[level=14]
setblock 317 254 419 minecraft:light[level=14]
setblock 317 254 427 minecraft:light[level=14]
setblock 317 254 435 minecraft:light[level=14]
setblock 317 254 443 minecraft:light[level=14]
setblock 317 254 451 minecraft:light[level=14]
fill 319 254 444 319 261 444 minecraft:waxed_copper_block
fill 320 254 419 322 255 419 minecraft:waxed_copper_block
fill 286 256 453 286 267 453 minecraft:waxed_copper_block
fill 285 257 430 285 257 432 minecraft:waxed_cut_copper
fill 286 257 430 287 257 430 minecraft:waxed_cut_copper
fill 286 257 432 287 257 432 minecraft:waxed_cut_copper
setblock 287 257 431 minecraft:waxed_cut_copper
fill 284 260 426 284 265 428 minecraft:waxed_cut_copper
fill 284 260 438 284 265 440 minecraft:waxed_cut_copper
fill 284 260 450 284 265 452 minecraft:waxed_cut_copper
fill 290 260 456 292 265 456 minecraft:waxed_cut_copper
fill 294 260 418 296 265 418 minecraft:waxed_cut_copper
fill 302 260 456 304 265 456 minecraft:waxed_cut_copper
fill 306 260 418 308 265 418 minecraft:waxed_cut_copper
fill 314 260 456 316 265 456 minecraft:waxed_cut_copper
fill 318 260 418 320 265 418 minecraft:waxed_cut_copper
fill 322 260 426 322 265 428 minecraft:waxed_cut_copper
fill 322 260 438 322 265 440 minecraft:waxed_cut_copper
fill 322 260 450 322 265 452 minecraft:waxed_cut_copper
setblock 285 262 419 minecraft:light[level=14]
setblock 285 262 427 minecraft:light[level=14]
setblock 285 262 435 minecraft:light[level=14]
setblock 285 262 443 minecraft:light[level=14]
setblock 285 262 451 minecraft:light[level=14]
setblock 293 262 419 minecraft:light[level=14]
setblock 293 262 427 minecraft:light[level=14]
setblock 293 262 435 minecraft:light[level=14]
setblock 293 262 443 minecraft:light[level=14]
setblock 293 262 451 minecraft:light[level=14]
fill 299 262 422 299 270 422 minecraft:waxed_copper_block
setblock 301 262 419 minecraft:light[level=14]
setblock 301 262 427 minecraft:light[level=14]
setblock 301 262 435 minecraft:light[level=14]
setblock 301 262 443 minecraft:light[level=14]
setblock 301 262 451 minecraft:light[level=14]
setblock 309 262 419 minecraft:light[level=14]
setblock 309 262 427 minecraft:light[level=14]
setblock 309 262 435 minecraft:light[level=14]
setblock 309 262 443 minecraft:light[level=14]
setblock 309 262 451 minecraft:light[level=14]
setblock 317 262 419 minecraft:light[level=14]
setblock 317 262 427 minecraft:light[level=14]
setblock 317 262 435 minecraft:light[level=14]
setblock 317 262 443 minecraft:light[level=14]
setblock 317 262 451 minecraft:light[level=14]
fill 283 265 420 283 265 425 minecraft:dark_oak_planks
fill 283 265 432 283 265 437 minecraft:dark_oak_planks
fill 283 265 444 283 265 449 minecraft:dark_oak_planks
fill 283 265 456 283 265 457 minecraft:dark_oak_planks
fill 284 265 457 287 265 457 minecraft:dark_oak_planks
fill 285 265 430 285 265 432 minecraft:waxed_cut_copper
fill 286 265 430 287 265 430 minecraft:waxed_cut_copper
fill 286 265 432 287 265 432 minecraft:waxed_cut_copper
fill 287 265 417 292 265 417 minecraft:dark_oak_planks
setblock 287 265 431 minecraft:waxed_cut_copper
fill 294 265 457 299 265 457 minecraft:dark_oak_planks
fill 299 265 417 304 265 417 minecraft:dark_oak_planks
fill 306 265 457 311 265 457 minecraft:dark_oak_planks
fill 311 265 417 316 265 417 minecraft:dark_oak_planks
fill 318 265 457 323 265 457 minecraft:dark_oak_planks
fill 323 265 417 323 265 422 minecraft:dark_oak_planks
fill 323 265 429 323 265 434 minecraft:dark_oak_planks
fill 323 265 441 323 265 446 minecraft:dark_oak_planks
fill 323 265 453 323 265 456 minecraft:dark_oak_planks
fill 282 266 422 282 271 425 minecraft:ochre_froglight
fill 282 266 434 282 271 437 minecraft:ochre_froglight
fill 282 266 446 282 271 449 minecraft:ochre_froglight
fill 282 266 458 285 271 458 minecraft:ochre_froglight
fill 289 266 416 292 271 416 minecraft:ochre_froglight
fill 294 266 458 297 271 458 minecraft:ochre_froglight
fill 301 266 416 304 271 416 minecraft:ochre_froglight
fill 306 266 458 309 271 458 minecraft:ochre_froglight
fill 313 266 416 316 271 416 minecraft:ochre_froglight
fill 318 266 458 321 271 458 minecraft:ochre_froglight
fill 324 266 417 324 271 420 minecraft:ochre_froglight
fill 324 266 429 324 271 432 minecraft:ochre_froglight
fill 324 266 441 324 271 444 minecraft:ochre_froglight
fill 324 266 453 324 271 456 minecraft:ochre_froglight
setblock 285 270 419 minecraft:light[level=14]
setblock 285 270 427 minecraft:light[level=14]
setblock 285 270 435 minecraft:light[level=14]
setblock 285 270 443 minecraft:light[level=14]
setblock 285 270 451 minecraft:light[level=14]
setblock 293 270 419 minecraft:light[level=14]
setblock 293 270 427 minecraft:light[level=14]
setblock 293 270 435 minecraft:light[level=14]
setblock 293 270 443 minecraft:light[level=14]
setblock 293 270 451 minecraft:light[level=14]
setblock 301 270 419 minecraft:light[level=14]
setblock 301 270 427 minecraft:light[level=14]
setblock 301 270 435 minecraft:light[level=14]
setblock 301 270 443 minecraft:light[level=14]
setblock 301 270 451 minecraft:light[level=14]
setblock 309 270 419 minecraft:light[level=14]
setblock 309 270 427 minecraft:light[level=14]
setblock 309 270 435 minecraft:light[level=14]
setblock 309 270 443 minecraft:light[level=14]
setblock 309 270 451 minecraft:light[level=14]
setblock 317 270 419 minecraft:light[level=14]
setblock 317 270 427 minecraft:light[level=14]
setblock 317 270 435 minecraft:light[level=14]
setblock 317 270 443 minecraft:light[level=14]
setblock 317 270 451 minecraft:light[level=14]
fill 282 272 422 282 285 422 minecraft:dark_oak_planks
fill 282 272 423 282 272 424 minecraft:ochre_froglight
fill 282 272 425 282 285 425 minecraft:dark_oak_planks
fill 282 272 434 282 285 434 minecraft:dark_oak_planks
fill 282 272 435 282 272 436 minecraft:ochre_froglight
fill 282 272 437 282 285 437 minecraft:dark_oak_planks
fill 282 272 446 282 285 446 minecraft:dark_oak_planks
fill 282 272 447 282 272 448 minecraft:ochre_froglight
fill 282 272 449 282 285 449 minecraft:dark_oak_planks
fill 282 272 458 282 285 458 minecraft:dark_oak_planks
fill 283 272 431 285 273 431 minecraft:waxed_copper_block
fill 283 272 458 284 272 458 minecraft:ochre_froglight
fill 285 272 458 285 285 458 minecraft:dark_oak_planks
fill 289 272 416 289 285 416 minecraft:dark_oak_planks
fill 290 272 416 291 272 416 minecraft:ochre_froglight
fill 292 272 416 292 285 416 minecraft:dark_oak_planks
fill 294 272 458 294 285 458 minecraft:dark_oak_planks
fill 295 272 458 296 272 458 minecraft:ochre_froglight
fill 297 272 458 297 285 458 minecraft:dark_oak_planks
fill 301 272 416 301 285 416 minecraft:dark_oak_planks
fill 302 272 416 303 272 416 minecraft:ochre_froglight
fill 304 272 416 304 285 416 minecraft:dark_oak_planks
fill 306 272 458 306 285 458 minecraft:dark_oak_planks
fill 307 272 458 308 272 458 minecraft:ochre_froglight
fill 309 272 458 309 285 458 minecraft:dark_oak_planks
fill 313 272 416 313 285 416 minecraft:dark_oak_planks
fill 314 272 416 315 272 416 minecraft:ochre_froglight
fill 316 272 416 316 285 416 minecraft:dark_oak_planks
fill 318 272 458 318 285 458 minecraft:dark_oak_planks
fill 319 272 458 320 272 458 minecraft:ochre_froglight
fill 321 272 458 321 285 458 minecraft:dark_oak_planks
fill 324 272 417 324 285 417 minecraft:dark_oak_planks
fill 324 272 418 324 272 419 minecraft:ochre_froglight
fill 324 272 420 324 285 420 minecraft:dark_oak_planks
fill 324 272 429 324 285 429 minecraft:dark_oak_planks
fill 324 272 430 324 272 431 minecraft:ochre_froglight
fill 324 272 432 324 285 432 minecraft:dark_oak_planks
fill 324 272 441 324 285 441 minecraft:dark_oak_planks
fill 324 272 442 324 272 443 minecraft:ochre_froglight
fill 324 272 444 324 285 444 minecraft:dark_oak_planks
fill 324 272 453 324 285 453 minecraft:dark_oak_planks
fill 324 272 454 324 272 455 minecraft:ochre_froglight
fill 324 272 456 324 285 456 minecraft:dark_oak_planks
fill 282 273 423 282 285 424 minecraft:dark_oak_planks
fill 282 273 435 282 285 436 minecraft:dark_oak_planks
fill 282 273 447 282 285 448 minecraft:dark_oak_planks
fill 283 273 458 284 285 458 minecraft:dark_oak_planks
setblock 287 273 431 minecraft:ochre_froglight
fill 290 273 416 291 285 416 minecraft:dark_oak_planks
fill 295 273 458 296 285 458 minecraft:dark_oak_planks
fill 302 273 416 303 285 416 minecraft:dark_oak_planks
fill 307 273 458 308 285 458 minecraft:dark_oak_planks
fill 314 273 416 315 285 416 minecraft:dark_oak_planks
fill 319 273 458 320 285 458 minecraft:dark_oak_planks
fill 324 273 418 324 285 419 minecraft:dark_oak_planks
fill 324 273 430 324 285 431 minecraft:dark_oak_planks
fill 324 273 442 324 285 443 minecraft:dark_oak_planks
fill 324 273 454 324 285 455 minecraft:dark_oak_planks
setblock 285 278 419 minecraft:light[level=14]
setblock 285 278 427 minecraft:light[level=14]
setblock 285 278 435 minecraft:light[level=14]
setblock 285 278 443 minecraft:light[level=14]
setblock 285 278 451 minecraft:light[level=14]
setblock 293 278 419 minecraft:light[level=14]
setblock 293 278 427 minecraft:light[level=14]
setblock 293 278 435 minecraft:light[level=14]
setblock 293 278 443 minecraft:light[level=14]
setblock 293 278 451 minecraft:light[level=14]
setblock 301 278 419 minecraft:light[level=14]
setblock 301 278 427 minecraft:light[level=14]
setblock 301 278 443 minecraft:light[level=14]
setblock 301 278 451 minecraft:light[level=14]
setblock 309 278 419 minecraft:light[level=14]
setblock 309 278 427 minecraft:light[level=14]
setblock 309 278 435 minecraft:light[level=14]
setblock 309 278 443 minecraft:light[level=14]
setblock 309 278 451 minecraft:light[level=14]
setblock 317 278 419 minecraft:light[level=14]
setblock 317 278 427 minecraft:light[level=14]
setblock 317 278 435 minecraft:light[level=14]
setblock 317 278 443 minecraft:light[level=14]
setblock 317 278 451 minecraft:light[level=14]
fill 289 279 435 290 280 435 minecraft:gold_block
fill 290 279 430 290 280 434 minecraft:gold_block
fill 290 279 436 290 280 440 minecraft:gold_block
fill 291 279 428 291 280 430 minecraft:gold_block
fill 291 279 431 300 279 439 minecraft:white_terracotta
fill 291 279 440 291 280 442 minecraft:gold_block
fill 292 279 427 292 280 428 minecraft:gold_block
fill 292 279 429 314 279 430 minecraft:white_terracotta
fill 292 279 440 314 279 441 minecraft:white_terracotta
fill 292 279 442 292 280 443 minecraft:gold_block
fill 293 279 426 293 280 427 minecraft:gold_block
fill 293 279 428 313 280 428 minecraft:white_terracotta
fill 293 279 442 313 279 442 minecraft:white_terracotta
fill 293 279 443 293 280 444 minecraft:gold_block
fill 294 279 425 294 280 426 minecraft:gold_block
fill 294 279 427 312 280 427 minecraft:white_terracotta
fill 294 279 443 312 279 443 minecraft:white_terracotta
fill 294 279 444 294 280 445 minecraft:gold_block
fill 295 279 424 295 280 425 minecraft:gold_block
fill 295 279 426 311 280 426 minecraft:white_terracotta
fill 295 279 444 311 280 444 minecraft:white_terracotta
fill 295 279 445 295 280 446 minecraft:gold_block
fill 296 279 423 296 280 424 minecraft:gold_block
fill 296 279 425 310 279 425 minecraft:white_terracotta
fill 296 279 445 310 279 445 minecraft:white_terracotta
fill 296 279 446 296 280 447 minecraft:gold_block
fill 297 279 423 298 280 423 minecraft:gold_block
fill 297 279 424 309 279 424 minecraft:white_terracotta
fill 297 279 446 309 279 446 minecraft:white_terracotta
fill 297 279 447 298 280 447 minecraft:gold_block
fill 298 279 422 308 280 422 minecraft:gold_block
fill 298 279 448 308 280 448 minecraft:gold_block
fill 299 279 423 307 279 423 minecraft:white_terracotta
fill 299 279 447 307 279 447 minecraft:white_terracotta
fill 301 279 431 301 279 433 minecraft:white_terracotta
fill 301 279 437 301 279 439 minecraft:white_terracotta
fill 302 279 431 315 279 432 minecraft:white_terracotta
fill 302 279 438 315 279 439 minecraft:white_terracotta
fill 303 279 421 303 280 421 minecraft:gold_block
fill 303 279 449 303 280 449 minecraft:gold_block
fill 305 279 433 315 279 433 minecraft:white_terracotta
fill 305 279 437 315 279 437 minecraft:white_terracotta
fill 306 279 434 315 279 436 minecraft:white_terracotta
fill 308 279 423 310 280 423 minecraft:gold_block
fill 308 279 447 310 280 447 minecraft:gold_block
fill 310 279 424 311 280 424 minecraft:gold_block
fill 310 279 446 311 280 446 minecraft:gold_block
fill 311 279 425 312 280 425 minecraft:gold_block
fill 311 279 445 312 280 445 minecraft:gold_block
fill 312 279 426 313 280 426 minecraft:gold_block
fill 312 279 444 313 280 444 minecraft:gold_block
fill 313 279 427 314 280 427 minecraft:gold_block
fill 313 279 443 314 280 443 minecraft:gold_block
fill 314 279 428 315 280 428 minecraft:gold_block
fill 314 279 442 315 280 442 minecraft:gold_block
fill 315 279 429 315 280 430 minecraft:gold_block
fill 315 279 440 315 280 441 minecraft:gold_block
fill 316 279 430 316 280 440 minecraft:gold_block
fill 317 279 435 317 280 435 minecraft:gold_block
fill 283 280 417 288 280 457 minecraft:dark_oak_planks
fill 289 280 417 289 280 434 minecraft:dark_oak_planks
fill 289 280 436 289 280 457 minecraft:dark_oak_planks
fill 290 280 417 290 280 429 minecraft:dark_oak_planks
fill 290 280 441 290 280 457 minecraft:dark_oak_planks
fill 291 280 417 291 280 427 minecraft:dark_oak_planks
fill 291 280 431 299 280 434 minecraft:white_terracotta
fill 291 280 435 292 280 435 minecraft:black_concrete
fill 291 280 436 298 280 439 minecraft:white_terracotta
fill 291 280 443 291 280 457 minecraft:dark_oak_planks
fill 292 280 417 292 280 426 minecraft:dark_oak_planks
fill 292 280 429 293 280 429 minecraft:black_concrete
fill 292 280 430 314 280 430 minecraft:white_terracotta
fill 292 280 440 297 280 440 minecraft:white_terracotta
fill 292 280 441 293 280 441 minecraft:black_concrete
fill 292 280 444 292 280 457 minecraft:dark_oak_planks
fill 293 280 417 293 280 425 minecraft:dark_oak_planks
fill 293 280 435 299 280 435 minecraft:white_terracotta
fill 293 280 442 295 280 442 minecraft:white_terracotta
fill 293 280 445 293 280 457 minecraft:dark_oak_planks
fill 294 280 417 294 280 424 minecraft:dark_oak_planks
fill 294 280 429 312 280 429 minecraft:white_terracotta
fill 294 280 441 296 280 441 minecraft:white_terracotta
fill 294 280 443 295 280 443 minecraft:white_terracotta
fill 294 280 446 294 280 457 minecraft:dark_oak_planks
fill 295 280 417 295 280 423 minecraft:dark_oak_planks
fill 295 280 447 295 280 457 minecraft:dark_oak_planks
fill 296 280 417 297 280 422 minecraft:dark_oak_planks
setblock 296 280 425 minecraft:white_terracotta
fill 296 280 442 296 280 443 minecraft:waxed_cut_copper
setblock 296 280 445 minecraft:white_terracotta
fill 296 280 448 297 280 457 minecraft:dark_oak_planks
fill 297 280 424 297 280 425 minecraft:black_concrete
fill 297 280 441 297 280 442 minecraft:waxed_cut_copper
fill 297 280 443 312 280 443 minecraft:white_terracotta
fill 297 280 445 297 280 446 minecraft:black_concrete
fill 298 280 417 302 280 421 minecraft:dark_oak_planks
fill 298 280 424 302 280 425 minecraft:white_terracotta
fill 298 280 440 298 280 441 minecraft:waxed_cut_copper
fill 298 280 442 313 280 442 minecraft:white_terracotta
fill 298 280 445 302 280 446 minecraft:white_terracotta
fill 298 280 449 302 280 457 minecraft:dark_oak_planks
fill 299 280 423 302 280 423 minecraft:white_terracotta
fill 299 280 436 299 280 438 minecraft:white_terracotta
fill 299 280 439 299 280 440 minecraft:waxed_cut_copper
fill 299 280 441 312 280 441 minecraft:white_terracotta
fill 299 280 447 302 280 447 minecraft:white_terracotta
fill 300 280 431 300 280 432 minecraft:white_terracotta
fill 300 280 433 300 280 437 minecraft:ochre_froglight
fill 300 280 438 300 280 439 minecraft:waxed_cut_copper
fill 300 280 440 308 280 440 minecraft:white_terracotta
fill 301 280 431 315 280 431 minecraft:white_terracotta
fill 301 280 432 301 280 433 minecraft:ochre_froglight
fill 301 280 437 301 280 438 minecraft:ochre_froglight
fill 301 280 439 306 280 439 minecraft:white_terracotta
fill 302 280 432 305 280 432 minecraft:ochre_froglight
fill 302 280 438 305 280 438 minecraft:ochre_froglight
fill 303 280 417 323 280 420 minecraft:dark_oak_planks
fill 303 280 423 303 280 424 minecraft:black_concrete
fill 303 280 425 308 280 425 minecraft:white_terracotta
fill 303 280 445 308 280 445 minecraft:white_terracotta
fill 303 280 446 303 280 447 minecraft:black_concrete
fill 303 280 450 323 280 457 minecraft:dark_oak_planks
fill 304 280 421 323 280 421 minecraft:dark_oak_planks
fill 304 280 423 307 280 424 minecraft:white_terracotta
fill 304 280 446 307 280 447 minecraft:white_terracotta
fill 304 280 449 323 280 449 minecraft:dark_oak_planks
fill 305 280 433 306 280 433 minecraft:ochre_froglight
fill 305 280 437 306 280 437 minecraft:ochre_froglight
fill 306 280 432 315 280 432 minecraft:white_terracotta
fill 306 280 434 306 280 436 minecraft:ochre_froglight
fill 306 280 438 307 280 438 minecraft:waxed_cut_copper
fill 307 280 433 313 280 437 minecraft:white_terracotta
fill 307 280 439 308 280 439 minecraft:waxed_cut_copper
setblock 308 280 424 minecraft:white_terracotta
fill 308 280 438 315 280 438 minecraft:white_terracotta
setblock 308 280 446 minecraft:white_terracotta
fill 309 280 422 323 280 422 minecraft:dark_oak_planks
fill 309 280 424 309 280 425 minecraft:black_concrete
fill 309 280 439 315 280 439 minecraft:white_terracotta
setblock 309 280 440 minecraft:waxed_cut_copper
fill 309 280 445 309 280 446 minecraft:black_concrete
fill 309 280 448 323 280 448 minecraft:dark_oak_planks
setblock 310 280 425 minecraft:white_terracotta
fill 310 280 440 314 280 440 minecraft:white_terracotta
setblock 310 280 445 minecraft:white_terracotta
fill 311 280 423 323 280 423 minecraft:dark_oak_planks
fill 311 280 447 323 280 447 minecraft:dark_oak_planks
fill 312 280 424 323 280 424 minecraft:dark_oak_planks
fill 312 280 446 323 280 446 minecraft:dark_oak_planks
fill 313 280 425 323 280 425 minecraft:dark_oak_planks
fill 313 280 429 314 280 429 minecraft:black_concrete
fill 313 280 441 314 280 441 minecraft:black_concrete
fill 313 280 445 323 280 445 minecraft:dark_oak_planks
fill 314 280 426 323 280 426 minecraft:dark_oak_planks
fill 314 280 433 315 280 434 minecraft:white_terracotta
fill 314 280 435 315 280 435 minecraft:black_concrete
fill 314 280 436 315 280 437 minecraft:white_terracotta
fill 314 280 444 323 280 444 minecraft:dark_oak_planks
fill 315 280 427 323 280 427 minecraft:dark_oak_planks
fill 315 280 443 323 280 443 minecraft:dark_oak_planks
fill 316 280 428 323 280 429 minecraft:dark_oak_planks
fill 316 280 441 323 280 442 minecraft:dark_oak_planks
fill 317 280 430 323 280 434 minecraft:dark_oak_planks
fill 317 280 436 323 280 440 minecraft:dark_oak_planks
fill 318 280 435 323 280 435 minecraft:dark_oak_planks
fill 283 284 417 285 300 417 minecraft:waxed_cut_copper
fill 283 284 427 283 300 429 minecraft:waxed_cut_copper
fill 283 284 439 283 300 441 minecraft:waxed_cut_copper
fill 283 284 451 283 300 453 minecraft:waxed_cut_copper
fill 284 284 426 284 285 428 minecraft:waxed_cut_copper
fill 284 284 438 284 285 440 minecraft:waxed_cut_copper
fill 284 284 450 284 285 452 minecraft:waxed_cut_copper
fill 289 284 457 291 300 457 minecraft:waxed_cut_copper
fill 290 284 454 290 300 454 minecraft:waxed_copper_block
fill 290 284 456 292 285 456 minecraft:waxed_cut_copper
fill 294 284 418 296 285 418 minecraft:waxed_cut_copper
fill 295 284 417 297 300 417 minecraft:waxed_cut_copper
fill 301 284 457 303 300 457 minecraft:waxed_cut_copper
fill 302 284 456 304 285 456 minecraft:waxed_cut_copper
fill 306 284 418 308 285 418 minecraft:waxed_cut_copper
fill 307 284 417 309 300 417 minecraft:waxed_cut_copper
fill 313 284 457 315 300 457 minecraft:waxed_cut_copper
fill 314 284 456 316 285 456 minecraft:waxed_cut_copper
fill 318 284 418 320 285 418 minecraft:waxed_cut_copper
fill 319 284 417 321 300 417 minecraft:waxed_cut_copper
fill 322 284 426 322 285 428 minecraft:waxed_cut_copper
fill 322 284 438 322 285 440 minecraft:waxed_cut_copper
fill 322 284 450 322 285 452 minecraft:waxed_cut_copper
fill 323 284 425 323 300 427 minecraft:waxed_cut_copper
fill 323 284 437 323 300 439 minecraft:waxed_cut_copper
fill 323 284 449 323 300 451 minecraft:waxed_cut_copper
fill 283 285 420 283 285 425 minecraft:dark_oak_planks
fill 283 285 432 283 285 437 minecraft:dark_oak_planks
fill 283 285 444 283 285 449 minecraft:dark_oak_planks
fill 283 285 456 283 285 457 minecraft:dark_oak_planks
fill 284 285 457 287 285 457 minecraft:dark_oak_planks
fill 287 285 417 292 285 417 minecraft:dark_oak_planks
setblock 290 285 455 minecraft:waxed_copper_block
fill 294 285 457 299 285 457 minecraft:dark_oak_planks
fill 299 285 417 304 285 417 minecraft:dark_oak_planks
fill 306 285 457 311 285 457 minecraft:dark_oak_planks
fill 311 285 417 316 285 417 minecraft:dark_oak_planks
fill 318 285 457 323 285 457 minecraft:dark_oak_planks
fill 323 285 417 323 285 422 minecraft:dark_oak_planks
fill 323 285 429 323 285 434 minecraft:dark_oak_planks
fill 323 285 441 323 285 446 minecraft:dark_oak_planks
fill 323 285 453 323 285 456 minecraft:dark_oak_planks
fill 282 286 422 282 291 425 minecraft:ochre_froglight
fill 282 286 434 282 291 437 minecraft:ochre_froglight
fill 282 286 446 282 291 449 minecraft:ochre_froglight
fill 282 286 458 285 291 458 minecraft:ochre_froglight
setblock 285 286 419 minecraft:light[level=14]
setblock 285 286 427 minecraft:light[level=14]
setblock 285 286 435 minecraft:light[level=14]
setblock 285 286 443 minecraft:light[level=14]
setblock 285 286 451 minecraft:light[level=14]
fill 289 286 416 292 291 416 minecraft:ochre_froglight
fill 289 286 453 289 286 455 minecraft:waxed_cut_copper
fill 290 286 453 291 286 453 minecraft:waxed_cut_copper
fill 290 286 455 291 286 455 minecraft:waxed_cut_copper
setblock 290 286 456 minecraft:waxed_copper_block
setblock 291 286 454 minecraft:waxed_cut_copper
setblock 293 286 419 minecraft:light[level=14]
setblock 293 286 427 minecraft:light[level=14]
setblock 293 286 435 minecraft:light[level=14]
setblock 293 286 443 minecraft:light[level=14]
setblock 293 286 451 minecraft:light[level=14]
fill 294 286 458 297 291 458 minecraft:ochre_froglight
fill 301 286 416 304 291 416 minecraft:ochre_froglight
setblock 301 286 419 minecraft:light[level=14]
setblock 301 286 427 minecraft:light[level=14]
setblock 301 286 435 minecraft:light[level=14]
setblock 301 286 443 minecraft:light[level=14]
setblock 301 286 451 minecraft:light[level=14]
fill 306 286 458 309 291 458 minecraft:ochre_froglight
setblock 309 286 419 minecraft:light[level=14]
setblock 309 286 427 minecraft:light[level=14]
setblock 309 286 435 minecraft:light[level=14]
setblock 309 286 443 minecraft:light[level=14]
setblock 309 286 451 minecraft:light[level=14]
fill 313 286 416 316 291 416 minecraft:ochre_froglight
setblock 317 286 419 minecraft:light[level=14]
setblock 317 286 427 minecraft:light[level=14]
setblock 317 286 435 minecraft:light[level=14]
setblock 317 286 443 minecraft:light[level=14]
setblock 317 286 451 minecraft:light[level=14]
fill 318 286 458 321 291 458 minecraft:ochre_froglight
fill 324 286 417 324 291 420 minecraft:ochre_froglight
fill 324 286 429 324 291 432 minecraft:ochre_froglight
fill 324 286 441 324 291 444 minecraft:ochre_froglight
fill 324 286 453 324 291 456 minecraft:ochre_froglight
fill 282 292 422 282 307 422 minecraft:dark_oak_planks
fill 282 292 423 282 292 424 minecraft:ochre_froglight
fill 282 292 425 282 307 425 minecraft:dark_oak_planks
fill 282 292 434 282 307 434 minecraft:dark_oak_planks
fill 282 292 435 282 292 436 minecraft:ochre_froglight
fill 282 292 437 282 307 437 minecraft:dark_oak_planks
fill 282 292 446 282 307 446 minecraft:dark_oak_planks
fill 282 292 447 282 292 448 minecraft:ochre_froglight
fill 282 292 449 282 307 449 minecraft:dark_oak_planks
fill 282 292 458 282 307 458 minecraft:dark_oak_planks
fill 283 292 458 284 292 458 minecraft:ochre_froglight
fill 285 292 458 285 307 458 minecraft:dark_oak_planks
fill 289 292 416 289 307 416 minecraft:dark_oak_planks
fill 289 292 453 289 292 455 minecraft:waxed_cut_copper
fill 290 292 416 291 292 416 minecraft:ochre_froglight
fill 290 292 453 291 292 453 minecraft:waxed_cut_copper
fill 290 292 455 291 292 455 minecraft:waxed_cut_copper
setblock 291 292 454 minecraft:waxed_cut_copper
fill 292 292 416 292 307 416 minecraft:dark_oak_planks
fill 294 292 458 294 307 458 minecraft:dark_oak_planks
fill 295 292 458 296 292 458 minecraft:ochre_froglight
fill 297 292 458 297 307 458 minecraft:dark_oak_planks
fill 301 292 416 301 307 416 minecraft:dark_oak_planks
fill 302 292 416 303 292 416 minecraft:ochre_froglight
fill 304 292 416 304 307 416 minecraft:dark_oak_planks
fill 306 292 458 306 307 458 minecraft:dark_oak_planks
fill 307 292 458 308 292 458 minecraft:ochre_froglight
fill 309 292 458 309 307 458 minecraft:dark_oak_planks
fill 313 292 416 313 307 416 minecraft:dark_oak_planks
fill 314 292 416 315 292 416 minecraft:ochre_froglight
fill 316 292 416 316 307 416 minecraft:dark_oak_planks
fill 318 292 458 318 307 458 minecraft:dark_oak_planks
fill 319 292 458 320 292 458 minecraft:ochre_froglight
fill 321 292 458 321 307 458 minecraft:dark_oak_planks
fill 324 292 417 324 307 417 minecraft:dark_oak_planks
fill 324 292 418 324 292 419 minecraft:ochre_froglight
fill 324 292 420 324 307 420 minecraft:dark_oak_planks
fill 324 292 429 324 307 429 minecraft:dark_oak_planks
fill 324 292 430 324 292 431 minecraft:ochre_froglight
fill 324 292 432 324 307 432 minecraft:dark_oak_planks
fill 324 292 441 324 307 441 minecraft:dark_oak_planks
fill 324 292 442 324 292 443 minecraft:ochre_froglight
fill 324 292 444 324 307 444 minecraft:dark_oak_planks
fill 324 292 453 324 307 453 minecraft:dark_oak_planks
fill 324 292 454 324 292 455 minecraft:ochre_froglight
fill 324 292 456 324 307 456 minecraft:dark_oak_planks
fill 282 293 423 282 307 424 minecraft:dark_oak_planks
fill 282 293 435 282 307 436 minecraft:dark_oak_planks
fill 282 293 447 282 307 448 minecraft:dark_oak_planks
fill 283 293 458 284 307 458 minecraft:dark_oak_planks
fill 290 293 416 291 307 416 minecraft:dark_oak_planks
fill 295 293 458 296 307 458 minecraft:dark_oak_planks
fill 302 293 416 303 307 416 minecraft:dark_oak_planks
fill 307 293 458 308 307 458 minecraft:dark_oak_planks
fill 314 293 416 315 307 416 minecraft:dark_oak_planks
fill 319 293 458 320 307 458 minecraft:dark_oak_planks
fill 324 293 418 324 307 419 minecraft:dark_oak_planks
fill 324 293 430 324 307 431 minecraft:dark_oak_planks
fill 324 293 442 324 307 443 minecraft:dark_oak_planks
fill 324 293 454 324 307 455 minecraft:dark_oak_planks
setblock 285 294 419 minecraft:light[level=14]
setblock 285 294 427 minecraft:light[level=14]
setblock 285 294 435 minecraft:light[level=14]
setblock 285 294 443 minecraft:light[level=14]
setblock 285 294 451 minecraft:light[level=14]
setblock 293 294 419 minecraft:light[level=14]
setblock 293 294 427 minecraft:light[level=14]
setblock 293 294 435 minecraft:light[level=14]
setblock 293 294 443 minecraft:light[level=14]
setblock 293 294 451 minecraft:light[level=14]
setblock 301 294 419 minecraft:light[level=14]
setblock 301 294 427 minecraft:light[level=14]
setblock 301 294 435 minecraft:light[level=14]
setblock 301 294 443 minecraft:light[level=14]
setblock 301 294 451 minecraft:light[level=14]
setblock 309 294 419 minecraft:light[level=14]
setblock 309 294 427 minecraft:light[level=14]
setblock 309 294 435 minecraft:light[level=14]
setblock 309 294 443 minecraft:light[level=14]
setblock 309 294 451 minecraft:light[level=14]
setblock 317 294 419 minecraft:light[level=14]
setblock 317 294 427 minecraft:light[level=14]
setblock 317 294 435 minecraft:light[level=14]
setblock 317 294 443 minecraft:light[level=14]
setblock 317 294 451 minecraft:light[level=14]
fill 289 298 453 289 298 455 minecraft:waxed_cut_copper
fill 290 298 453 291 298 453 minecraft:waxed_cut_copper
fill 290 298 455 291 298 455 minecraft:waxed_cut_copper
setblock 291 298 454 minecraft:waxed_cut_copper
fill 299 299 450 303 300 454 minecraft:dark_oak_planks
fill 301 299 455 301 299 456 minecraft:dark_oak_planks
fill 284 300 426 284 300 428 minecraft:waxed_cut_copper
fill 284 300 438 284 300 440 minecraft:waxed_cut_copper
fill 284 300 450 284 300 452 minecraft:waxed_cut_copper
fill 290 300 456 292 300 456 minecraft:waxed_cut_copper
fill 294 300 418 296 300 418 minecraft:waxed_cut_copper
fill 302 300 456 304 300 456 minecraft:waxed_cut_copper
fill 306 300 418 308 300 418 minecraft:waxed_cut_copper
fill 314 300 456 316 300 456 minecraft:waxed_cut_copper
fill 318 300 418 320 300 418 minecraft:waxed_cut_copper
fill 322 300 426 322 300 428 minecraft:waxed_cut_copper
fill 322 300 438 322 300 440 minecraft:waxed_cut_copper
fill 322 300 450 322 300 452 minecraft:waxed_cut_copper
setblock 285 302 419 minecraft:light[level=14]
setblock 285 302 427 minecraft:light[level=14]
setblock 285 302 435 minecraft:light[level=14]
setblock 285 302 443 minecraft:light[level=14]
setblock 285 302 451 minecraft:light[level=14]
setblock 293 302 419 minecraft:light[level=14]
setblock 293 302 427 minecraft:light[level=14]
setblock 293 302 435 minecraft:light[level=14]
setblock 293 302 443 minecraft:light[level=14]
setblock 293 302 451 minecraft:light[level=14]
setblock 301 302 419 minecraft:light[level=14]
setblock 301 302 427 minecraft:light[level=14]
setblock 301 302 435 minecraft:light[level=14]
setblock 301 302 443 minecraft:light[level=14]
setblock 301 302 451 minecraft:light[level=14]
setblock 309 302 419 minecraft:light[level=14]
setblock 309 302 427 minecraft:light[level=14]
setblock 309 302 435 minecraft:light[level=14]
setblock 309 302 443 minecraft:light[level=14]
setblock 309 302 451 minecraft:light[level=14]
setblock 317 302 419 minecraft:light[level=14]
setblock 317 302 427 minecraft:light[level=14]
setblock 317 302 435 minecraft:light[level=14]
setblock 317 302 443 minecraft:light[level=14]
setblock 317 302 451 minecraft:light[level=14]
