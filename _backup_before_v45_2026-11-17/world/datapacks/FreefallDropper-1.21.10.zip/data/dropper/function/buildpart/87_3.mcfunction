setblock 182 195 389 minecraft:white_concrete
setblock 182 195 396 minecraft:white_concrete
setblock 182 195 403 minecraft:white_concrete
fill 183 195 371 183 307 373 minecraft:purple_terracotta
setblock 183 195 374 minecraft:black_concrete
fill 183 195 375 183 307 380 minecraft:purple_terracotta
fill 183 195 391 183 307 392 minecraft:purple_terracotta
fill 183 195 400 183 307 400 minecraft:purple_terracotta
fill 183 195 403 183 307 403 minecraft:purple_terracotta
fill 183 195 404 183 195 405 minecraft:black_concrete
fill 183 195 406 183 307 410 minecraft:purple_terracotta
fill 141 196 369 142 307 369 minecraft:purple_terracotta
fill 141 196 373 141 307 373 minecraft:purple_terracotta
fill 141 196 385 141 307 386 minecraft:purple_terracotta
fill 141 196 393 141 307 393 minecraft:purple_terracotta
fill 141 196 396 141 307 396 minecraft:purple_terracotta
fill 141 196 398 141 307 398 minecraft:purple_terracotta
fill 147 196 369 147 219 369 minecraft:purple_terracotta
fill 152 196 411 153 307 411 minecraft:purple_terracotta
fill 165 196 369 165 307 369 minecraft:purple_terracotta
fill 165 196 411 165 307 411 minecraft:purple_terracotta
fill 181 196 369 181 307 369 minecraft:purple_terracotta
fill 183 196 374 183 307 374 minecraft:purple_terracotta
fill 183 196 381 183 307 381 minecraft:purple_terracotta
fill 183 196 404 183 307 405 minecraft:purple_terracotta
setblock 142 197 376 minecraft:white_concrete
setblock 142 197 383 minecraft:white_concrete
setblock 142 197 390 minecraft:white_concrete
setblock 142 197 397 minecraft:white_concrete
setblock 142 197 404 minecraft:white_concrete
setblock 143 197 370 minecraft:white_concrete
setblock 143 197 410 minecraft:white_concrete
setblock 150 197 370 minecraft:white_concrete
setblock 150 197 410 minecraft:white_concrete
setblock 157 197 370 minecraft:white_concrete
setblock 157 197 410 minecraft:white_concrete
setblock 164 197 370 minecraft:white_concrete
setblock 164 197 410 minecraft:white_concrete
setblock 171 197 370 minecraft:white_concrete
setblock 171 197 410 minecraft:white_concrete
setblock 178 197 370 minecraft:white_concrete
setblock 178 197 410 minecraft:white_concrete
setblock 182 197 373 minecraft:white_concrete
setblock 182 197 380 minecraft:white_concrete
setblock 182 197 387 minecraft:white_concrete
setblock 182 197 394 minecraft:white_concrete
setblock 182 197 401 minecraft:white_concrete
setblock 182 197 408 minecraft:white_concrete
setblock 142 198 370 minecraft:white_concrete
setblock 142 198 377 minecraft:white_concrete
setblock 142 198 384 minecraft:white_concrete
setblock 142 198 391 minecraft:white_concrete
setblock 142 198 398 minecraft:white_concrete
setblock 142 198 405 minecraft:white_concrete
setblock 144 198 410 minecraft:white_concrete
setblock 149 198 370 minecraft:white_concrete
setblock 151 198 410 minecraft:white_concrete
setblock 156 198 370 minecraft:white_concrete
setblock 158 198 410 minecraft:white_concrete
setblock 163 198 370 minecraft:white_concrete
setblock 165 198 410 minecraft:white_concrete
setblock 170 198 370 minecraft:white_concrete
setblock 172 198 410 minecraft:white_concrete
setblock 177 198 370 minecraft:white_concrete
setblock 179 198 410 minecraft:white_concrete
setblock 182 198 372 minecraft:white_concrete
setblock 182 198 379 minecraft:white_concrete
setblock 182 198 386 minecraft:white_concrete
setblock 182 198 393 minecraft:white_concrete
setblock 182 198 400 minecraft:white_concrete
setblock 182 198 407 minecraft:white_concrete
fill 142 199 371 142 200 371 minecraft:white_concrete
fill 142 199 378 142 200 378 minecraft:white_concrete
fill 142 199 385 142 200 385 minecraft:white_concrete
fill 142 199 392 142 200 392 minecraft:white_concrete
fill 142 199 399 142 200 399 minecraft:white_concrete
fill 142 199 406 142 200 406 minecraft:white_concrete
fill 145 199 410 145 200 410 minecraft:white_concrete
fill 148 199 370 148 200 370 minecraft:white_concrete
fill 152 199 410 152 200 410 minecraft:white_concrete
fill 155 199 370 155 200 370 minecraft:white_concrete
fill 159 199 410 159 200 410 minecraft:white_concrete
fill 162 199 370 162 200 370 minecraft:white_concrete
fill 166 199 410 166 200 410 minecraft:white_concrete
fill 169 199 370 169 200 370 minecraft:white_concrete
fill 173 199 410 173 200 410 minecraft:white_concrete
fill 176 199 370 176 200 370 minecraft:white_concrete
fill 180 199 410 180 200 410 minecraft:white_concrete
fill 182 199 371 182 200 371 minecraft:white_concrete
fill 182 199 378 182 200 378 minecraft:white_concrete
fill 182 199 385 182 200 385 minecraft:white_concrete
fill 182 199 392 182 200 392 minecraft:white_concrete
fill 182 199 399 182 200 399 minecraft:white_concrete
fill 182 199 406 182 200 406 minecraft:white_concrete
fill 142 200 370 143 200 370 minecraft:white_concrete
fill 142 200 372 142 200 374 minecraft:white_concrete
fill 142 200 376 142 200 377 minecraft:white_concrete
fill 142 200 379 142 200 381 minecraft:white_concrete
fill 142 200 383 142 200 384 minecraft:white_concrete
fill 142 200 386 142 200 388 minecraft:white_concrete
fill 142 200 390 142 200 391 minecraft:white_concrete
fill 142 200 393 142 200 395 minecraft:white_concrete
fill 142 200 397 142 200 398 minecraft:white_concrete
fill 142 200 400 142 200 402 minecraft:white_concrete
fill 142 200 404 142 200 405 minecraft:white_concrete
fill 142 200 407 142 200 409 minecraft:white_concrete
fill 143 200 410 144 200 410 minecraft:white_concrete
fill 145 200 370 147 200 370 minecraft:white_concrete
fill 146 200 410 148 200 410 minecraft:white_concrete
fill 149 200 370 150 200 370 minecraft:white_concrete
fill 150 200 410 151 200 410 minecraft:white_concrete
fill 152 200 370 154 200 370 minecraft:white_concrete
fill 153 200 410 155 200 410 minecraft:white_concrete
fill 156 200 370 157 200 370 minecraft:white_concrete
fill 157 200 410 158 200 410 minecraft:white_concrete
fill 159 200 370 161 200 370 minecraft:white_concrete
fill 160 200 410 162 200 410 minecraft:white_concrete
fill 163 200 370 164 200 370 minecraft:white_concrete
fill 164 200 410 165 200 410 minecraft:white_concrete
fill 166 200 370 168 200 370 minecraft:white_concrete
fill 167 200 410 169 200 410 minecraft:white_concrete
fill 170 200 370 171 200 370 minecraft:white_concrete
fill 171 200 410 172 200 410 minecraft:white_concrete
fill 173 200 370 175 200 370 minecraft:white_concrete
fill 174 200 410 176 200 410 minecraft:white_concrete
fill 177 200 370 178 200 370 minecraft:white_concrete
fill 178 200 410 179 200 410 minecraft:white_concrete
fill 180 200 370 182 200 370 minecraft:white_concrete
fill 181 200 410 182 200 410 minecraft:white_concrete
fill 182 200 372 182 200 373 minecraft:white_concrete
fill 182 200 375 182 200 377 minecraft:white_concrete
fill 182 200 379 182 200 380 minecraft:white_concrete
fill 182 200 382 182 200 384 minecraft:white_concrete
fill 182 200 386 182 200 387 minecraft:white_concrete
fill 182 200 389 182 200 391 minecraft:white_concrete
fill 182 200 393 182 200 394 minecraft:white_concrete
fill 182 200 396 182 200 398 minecraft:white_concrete
fill 182 200 400 182 200 401 minecraft:white_concrete
fill 182 200 403 182 200 405 minecraft:white_concrete
fill 182 200 407 182 200 408 minecraft:white_concrete
setblock 142 201 373 minecraft:white_concrete
setblock 142 201 380 minecraft:white_concrete
setblock 142 201 387 minecraft:white_concrete
setblock 142 201 394 minecraft:white_concrete
setblock 142 201 401 minecraft:white_concrete
setblock 142 201 408 minecraft:white_concrete
setblock 146 201 370 minecraft:white_concrete
setblock 147 201 410 minecraft:white_concrete
setblock 153 201 370 minecraft:white_concrete
setblock 154 201 410 minecraft:white_concrete
setblock 160 201 370 minecraft:white_concrete
setblock 161 201 410 minecraft:white_concrete
setblock 167 201 370 minecraft:white_concrete
setblock 168 201 410 minecraft:white_concrete
setblock 174 201 370 minecraft:white_concrete
setblock 175 201 410 minecraft:white_concrete
setblock 181 201 370 minecraft:white_concrete
setblock 182 201 376 minecraft:white_concrete
setblock 182 201 383 minecraft:white_concrete
setblock 182 201 390 minecraft:white_concrete
setblock 182 201 397 minecraft:white_concrete
setblock 182 201 404 minecraft:white_concrete
setblock 182 201 410 minecraft:white_concrete
setblock 142 202 374 minecraft:white_concrete
setblock 142 202 381 minecraft:white_concrete
setblock 142 202 388 minecraft:white_concrete
setblock 142 202 395 minecraft:white_concrete
setblock 142 202 402 minecraft:white_concrete
setblock 142 202 409 minecraft:white_concrete
setblock 145 202 370 minecraft:white_concrete
setblock 148 202 410 minecraft:white_concrete
setblock 152 202 370 minecraft:white_concrete
setblock 155 202 410 minecraft:white_concrete
setblock 159 202 370 minecraft:white_concrete
setblock 162 202 410 minecraft:white_concrete
setblock 166 202 370 minecraft:white_concrete
setblock 169 202 410 minecraft:white_concrete
setblock 173 202 370 minecraft:white_concrete
setblock 176 202 410 minecraft:white_concrete
setblock 180 202 370 minecraft:white_concrete
setblock 182 202 375 minecraft:white_concrete
setblock 182 202 382 minecraft:white_concrete
setblock 182 202 389 minecraft:white_concrete
setblock 182 202 396 minecraft:white_concrete
setblock 182 202 403 minecraft:white_concrete
setblock 144 203 372 minecraft:light[level=14]
setblock 144 203 380 minecraft:light[level=14]
setblock 144 203 388 minecraft:light[level=14]
setblock 144 203 396 minecraft:light[level=14]
setblock 144 203 404 minecraft:light[level=14]
setblock 152 203 372 minecraft:light[level=14]
setblock 152 203 380 minecraft:light[level=14]
setblock 152 203 388 minecraft:light[level=14]
setblock 152 203 396 minecraft:light[level=14]
setblock 152 203 404 minecraft:light[level=14]
setblock 160 203 372 minecraft:light[level=14]
setblock 160 203 380 minecraft:light[level=14]
setblock 160 203 388 minecraft:light[level=14]
setblock 160 203 396 minecraft:light[level=14]
setblock 160 203 404 minecraft:light[level=14]
setblock 168 203 372 minecraft:light[level=14]
setblock 168 203 380 minecraft:light[level=14]
setblock 168 203 388 minecraft:light[level=14]
setblock 168 203 396 minecraft:light[level=14]
setblock 168 203 404 minecraft:light[level=14]
setblock 176 203 372 minecraft:light[level=14]
setblock 176 203 380 minecraft:light[level=14]
setblock 176 203 388 minecraft:light[level=14]
setblock 176 203 396 minecraft:light[level=14]
setblock 176 203 404 minecraft:light[level=14]
setblock 142 204 376 minecraft:white_concrete
setblock 142 204 383 minecraft:white_concrete
setblock 142 204 390 minecraft:white_concrete
setblock 142 204 397 minecraft:white_concrete
setblock 142 204 404 minecraft:white_concrete
setblock 143 204 370 minecraft:white_concrete
setblock 143 204 410 minecraft:white_concrete
setblock 150 204 370 minecraft:white_concrete
setblock 150 204 410 minecraft:white_concrete
setblock 157 204 370 minecraft:white_concrete
setblock 157 204 410 minecraft:white_concrete
setblock 164 204 370 minecraft:white_concrete
setblock 164 204 410 minecraft:white_concrete
setblock 171 204 370 minecraft:white_concrete
setblock 171 204 410 minecraft:white_concrete
setblock 178 204 370 minecraft:white_concrete
setblock 178 204 410 minecraft:white_concrete
setblock 182 204 373 minecraft:white_concrete
setblock 182 204 380 minecraft:white_concrete
setblock 182 204 387 minecraft:white_concrete
setblock 182 204 394 minecraft:white_concrete
setblock 182 204 401 minecraft:white_concrete
setblock 182 204 408 minecraft:white_concrete
setblock 142 205 370 minecraft:white_concrete
setblock 142 205 377 minecraft:white_concrete
setblock 142 205 384 minecraft:white_concrete
setblock 142 205 391 minecraft:white_concrete
setblock 142 205 398 minecraft:white_concrete
setblock 142 205 405 minecraft:white_concrete
setblock 144 205 410 minecraft:white_concrete
setblock 149 205 370 minecraft:white_concrete
setblock 151 205 410 minecraft:white_concrete
fill 154 205 408 160 206 408 minecraft:gray_concrete
setblock 156 205 370 minecraft:white_concrete
setblock 158 205 410 minecraft:white_concrete
setblock 163 205 370 minecraft:white_concrete
setblock 165 205 410 minecraft:white_concrete
setblock 170 205 370 minecraft:white_concrete
setblock 172 205 410 minecraft:white_concrete
setblock 177 205 370 minecraft:white_concrete
setblock 179 205 410 minecraft:white_concrete
setblock 182 205 372 minecraft:white_concrete
setblock 182 205 379 minecraft:white_concrete
setblock 182 205 386 minecraft:white_concrete
setblock 182 205 393 minecraft:white_concrete
setblock 182 205 400 minecraft:white_concrete
setblock 182 205 407 minecraft:white_concrete
setblock 142 206 371 minecraft:white_concrete
setblock 142 206 378 minecraft:white_concrete
setblock 142 206 385 minecraft:white_concrete
setblock 142 206 392 minecraft:white_concrete
setblock 142 206 399 minecraft:white_concrete
setblock 142 206 406 minecraft:white_concrete
setblock 145 206 410 minecraft:white_concrete
setblock 148 206 370 minecraft:white_concrete
setblock 152 206 410 minecraft:white_concrete
setblock 155 206 370 minecraft:white_concrete
setblock 159 206 410 minecraft:white_concrete
setblock 162 206 370 minecraft:white_concrete
setblock 166 206 410 minecraft:white_concrete
setblock 169 206 370 minecraft:white_concrete
setblock 173 206 410 minecraft:white_concrete
setblock 176 206 370 minecraft:white_concrete
setblock 180 206 410 minecraft:white_concrete
setblock 182 206 371 minecraft:white_concrete
setblock 182 206 378 minecraft:white_concrete
setblock 182 206 385 minecraft:white_concrete
setblock 182 206 392 minecraft:white_concrete
setblock 182 206 399 minecraft:white_concrete
setblock 182 206 406 minecraft:white_concrete
setblock 142 207 372 minecraft:white_concrete
setblock 142 207 379 minecraft:white_concrete
setblock 142 207 386 minecraft:white_concrete
setblock 142 207 393 minecraft:white_concrete
setblock 142 207 400 minecraft:white_concrete
setblock 142 207 407 minecraft:white_concrete
setblock 146 207 410 minecraft:white_concrete
setblock 147 207 370 minecraft:white_concrete
setblock 153 207 410 minecraft:white_concrete
setblock 154 207 370 minecraft:white_concrete
setblock 160 207 410 minecraft:white_concrete
setblock 161 207 370 minecraft:white_concrete
setblock 167 207 410 minecraft:white_concrete
setblock 168 207 370 minecraft:white_concrete
setblock 174 207 410 minecraft:white_concrete
setblock 175 207 370 minecraft:white_concrete
setblock 181 207 410 minecraft:white_concrete
setblock 182 207 370 minecraft:white_concrete
setblock 182 207 377 minecraft:white_concrete
setblock 182 207 384 minecraft:white_concrete
setblock 182 207 391 minecraft:white_concrete
setblock 182 207 398 minecraft:white_concrete
setblock 182 207 405 minecraft:white_concrete
setblock 142 208 373 minecraft:white_concrete
setblock 142 208 380 minecraft:white_concrete
setblock 142 208 387 minecraft:white_concrete
setblock 142 208 394 minecraft:white_concrete
setblock 142 208 401 minecraft:white_concrete
setblock 142 208 408 minecraft:white_concrete
setblock 146 208 370 minecraft:white_concrete
setblock 147 208 410 minecraft:white_concrete
setblock 153 208 370 minecraft:white_concrete
setblock 154 208 410 minecraft:white_concrete
setblock 160 208 370 minecraft:white_concrete
setblock 161 208 410 minecraft:white_concrete
setblock 167 208 370 minecraft:white_concrete
setblock 168 208 410 minecraft:white_concrete
setblock 174 208 370 minecraft:white_concrete
setblock 175 208 410 minecraft:white_concrete
setblock 181 208 370 minecraft:white_concrete
setblock 182 208 376 minecraft:white_concrete
setblock 182 208 383 minecraft:white_concrete
setblock 182 208 390 minecraft:white_concrete
setblock 182 208 397 minecraft:white_concrete
setblock 182 208 404 minecraft:white_concrete
setblock 182 208 410 minecraft:white_concrete
setblock 144 211 372 minecraft:light[level=14]
setblock 144 211 380 minecraft:light[level=14]
setblock 144 211 388 minecraft:light[level=14]
setblock 144 211 396 minecraft:light[level=14]
setblock 144 211 404 minecraft:light[level=14]
setblock 152 211 372 minecraft:light[level=14]
setblock 152 211 380 minecraft:light[level=14]
setblock 152 211 388 minecraft:light[level=14]
setblock 152 211 396 minecraft:light[level=14]
setblock 152 211 404 minecraft:light[level=14]
setblock 160 211 372 minecraft:light[level=14]
setblock 160 211 380 minecraft:light[level=14]
setblock 160 211 388 minecraft:light[level=14]
setblock 160 211 396 minecraft:light[level=14]
setblock 160 211 404 minecraft:light[level=14]
setblock 168 211 372 minecraft:light[level=14]
setblock 168 211 380 minecraft:light[level=14]
setblock 168 211 388 minecraft:light[level=14]
setblock 168 211 396 minecraft:light[level=14]
setblock 168 211 404 minecraft:light[level=14]
setblock 176 211 372 minecraft:light[level=14]
setblock 176 211 380 minecraft:light[level=14]
setblock 176 211 388 minecraft:light[level=14]
setblock 176 211 396 minecraft:light[level=14]
setblock 176 211 404 minecraft:light[level=14]
fill 147 214 390 157 214 390 minecraft:white_concrete
fill 148 214 385 157 214 389 minecraft:white_concrete
fill 148 214 391 157 214 395 minecraft:white_concrete
fill 149 214 384 171 214 384 minecraft:white_concrete
fill 149 214 396 171 214 396 minecraft:white_concrete
fill 150 214 382 170 214 383 minecraft:white_concrete
fill 150 214 397 170 214 398 minecraft:white_concrete
fill 151 214 381 169 214 381 minecraft:white_concrete
fill 151 214 399 169 214 399 minecraft:white_concrete
fill 152 214 380 168 214 380 minecraft:white_concrete
fill 152 214 400 168 214 400 minecraft:white_concrete
fill 154 214 379 166 214 379 minecraft:white_concrete
fill 154 214 401 166 214 401 minecraft:white_concrete
fill 155 214 378 165 214 378 minecraft:white_concrete
fill 155 214 402 165 214 402 minecraft:white_concrete
fill 158 214 385 158 214 388 minecraft:white_concrete
fill 158 214 392 158 214 395 minecraft:white_concrete
fill 159 214 385 172 214 387 minecraft:white_concrete
fill 159 214 393 172 214 395 minecraft:white_concrete
setblock 160 214 377 minecraft:white_concrete
setblock 160 214 403 minecraft:white_concrete
fill 162 214 388 172 214 388 minecraft:white_concrete
fill 162 214 392 172 214 392 minecraft:white_concrete
fill 163 214 389 172 214 391 minecraft:white_concrete
setblock 173 214 390 minecraft:white_concrete
fill 142 215 370 146 215 410 minecraft:black_concrete
fill 147 215 370 147 215 389 minecraft:black_concrete
fill 147 215 390 148 215 390 minecraft:gold_block
fill 147 215 391 147 215 410 minecraft:black_concrete
fill 148 215 370 148 215 384 minecraft:black_concrete
fill 148 215 385 148 215 389 minecraft:gold_block
fill 148 215 391 148 215 395 minecraft:gold_block
fill 148 215 396 148 215 410 minecraft:black_concrete
fill 149 215 370 149 215 383 minecraft:black_concrete
fill 149 215 384 149 215 385 minecraft:gold_block
fill 149 215 386 151 215 386 minecraft:white_concrete
fill 149 215 387 150 215 387 minecraft:red_concrete
fill 149 215 388 150 215 392 minecraft:white_concrete
fill 149 215 393 150 215 393 minecraft:red_concrete
fill 149 215 394 151 215 394 minecraft:white_concrete
fill 149 215 395 149 215 396 minecraft:gold_block
fill 149 215 397 149 215 410 minecraft:black_concrete
fill 150 215 370 150 215 381 minecraft:black_concrete
fill 150 215 382 150 215 383 minecraft:gold_block
fill 150 215 384 152 215 385 minecraft:white_concrete
fill 150 215 395 152 215 396 minecraft:white_concrete
fill 150 215 397 150 215 398 minecraft:gold_block
fill 150 215 399 150 215 410 minecraft:black_concrete
fill 151 215 370 151 215 380 minecraft:black_concrete
fill 151 215 381 151 215 382 minecraft:gold_block
fill 151 215 383 152 215 383 minecraft:white_concrete
fill 151 215 387 156 215 387 minecraft:white_concrete
fill 151 215 388 151 215 392 minecraft:red_concrete
fill 151 215 393 156 215 393 minecraft:white_concrete
fill 151 215 397 152 215 397 minecraft:white_concrete
fill 151 215 398 151 215 399 minecraft:gold_block
fill 151 215 400 151 215 410 minecraft:black_concrete
fill 152 215 370 153 215 379 minecraft:black_concrete
fill 152 215 380 152 215 381 minecraft:gold_block
setblock 152 215 382 minecraft:red_concrete
setblock 152 215 386 minecraft:red_concrete
fill 152 215 388 153 215 388 minecraft:red_concrete
fill 152 215 389 155 215 391 minecraft:white_concrete
fill 152 215 392 153 215 392 minecraft:red_concrete
setblock 152 215 394 minecraft:red_concrete
setblock 152 215 398 minecraft:red_concrete
fill 152 215 399 152 215 400 minecraft:gold_block
fill 152 215 401 153 215 410 minecraft:black_concrete
setblock 153 215 380 minecraft:gold_block
fill 153 215 381 155 215 382 minecraft:white_concrete
fill 153 215 383 153 215 385 minecraft:red_concrete
fill 153 215 386 155 215 386 minecraft:white_concrete
fill 153 215 394 155 215 394 minecraft:white_concrete
fill 153 215 395 153 215 397 minecraft:red_concrete
fill 153 215 398 155 215 399 minecraft:white_concrete
setblock 153 215 400 minecraft:gold_block
fill 154 215 370 154 215 378 minecraft:black_concrete
fill 154 215 379 155 215 379 minecraft:gold_block
fill 154 215 380 156 215 380 minecraft:white_concrete
fill 154 215 383 154 215 384 minecraft:red_concrete
setblock 154 215 385 minecraft:white_concrete
fill 154 215 388 156 215 388 minecraft:white_concrete
fill 154 215 392 156 215 392 minecraft:white_concrete
setblock 154 215 395 minecraft:white_concrete
fill 154 215 396 154 215 397 minecraft:red_concrete
fill 154 215 400 156 215 400 minecraft:white_concrete
fill 154 215 401 155 215 401 minecraft:gold_block
fill 154 215 402 154 215 410 minecraft:black_concrete
fill 155 215 370 159 215 377 minecraft:black_concrete
fill 155 215 378 165 215 378 minecraft:gold_block
setblock 155 215 383 minecraft:red_concrete
fill 155 215 384 165 215 384 minecraft:white_concrete
setblock 155 215 385 minecraft:red_concrete
setblock 155 215 395 minecraft:red_concrete
fill 155 215 396 165 215 396 minecraft:white_concrete
setblock 155 215 397 minecraft:red_concrete
fill 155 215 402 165 215 402 minecraft:gold_block
fill 155 215 403 159 215 410 minecraft:black_concrete
setblock 156 215 379 minecraft:white_concrete
fill 156 215 381 157 215 381 minecraft:white_concrete
setblock 156 215 382 minecraft:red_concrete
fill 156 215 383 157 215 383 minecraft:white_concrete
fill 156 215 385 164 215 385 minecraft:white_concrete
setblock 156 215 386 minecraft:red_concrete
setblock 156 215 389 minecraft:red_concrete
setblock 156 215 390 minecraft:white_concrete
setblock 156 215 391 minecraft:red_concrete
setblock 156 215 394 minecraft:red_concrete
fill 156 215 395 164 215 395 minecraft:white_concrete
fill 156 215 397 157 215 397 minecraft:white_concrete
setblock 156 215 398 minecraft:red_concrete
fill 156 215 399 157 215 399 minecraft:white_concrete
setblock 156 215 401 minecraft:white_concrete
fill 157 215 379 157 215 380 minecraft:red_concrete
setblock 157 215 382 minecraft:white_concrete
fill 157 215 386 158 215 386 minecraft:white_concrete
setblock 157 215 387 minecraft:red_concrete
fill 157 215 388 157 215 392 minecraft:jack_o_lantern
setblock 157 215 393 minecraft:red_concrete
fill 157 215 394 158 215 394 minecraft:white_concrete
setblock 157 215 398 minecraft:white_concrete
fill 157 215 400 157 215 401 minecraft:red_concrete
fill 158 215 379 162 215 380 minecraft:white_concrete
fill 158 215 381 158 215 383 minecraft:red_concrete
fill 158 215 387 158 215 388 minecraft:jack_o_lantern
fill 158 215 392 158 215 393 minecraft:jack_o_lantern
fill 158 215 397 158 215 399 minecraft:red_concrete
fill 158 215 400 162 215 401 minecraft:white_concrete
fill 159 215 381 162 215 381 minecraft:red_concrete
fill 159 215 382 161 215 383 minecraft:white_concrete
setblock 159 215 386 minecraft:red_concrete
fill 159 215 387 162 215 387 minecraft:jack_o_lantern
fill 159 215 393 162 215 393 minecraft:jack_o_lantern
setblock 159 215 394 minecraft:red_concrete
fill 159 215 397 161 215 398 minecraft:white_concrete
fill 159 215 399 162 215 399 minecraft:red_concrete
fill 160 215 370 182 215 376 minecraft:black_concrete
setblock 160 215 377 minecraft:gold_block
setblock 160 215 386 minecraft:white_concrete
setblock 160 215 394 minecraft:white_concrete
setblock 160 215 403 minecraft:gold_block
fill 160 215 404 182 215 410 minecraft:black_concrete
fill 161 215 377 182 215 377 minecraft:black_concrete
setblock 161 215 386 minecraft:red_concrete
setblock 161 215 394 minecraft:red_concrete
fill 161 215 403 182 215 403 minecraft:black_concrete
fill 162 215 382 162 215 383 minecraft:red_concrete
fill 162 215 386 163 215 386 minecraft:white_concrete
fill 162 215 388 163 215 388 minecraft:jack_o_lantern
fill 162 215 392 163 215 392 minecraft:jack_o_lantern
fill 162 215 394 163 215 394 minecraft:white_concrete
fill 162 215 397 162 215 398 minecraft:red_concrete
fill 163 215 379 163 215 380 minecraft:red_concrete
fill 163 215 381 163 215 383 minecraft:white_concrete
setblock 163 215 387 minecraft:red_concrete
fill 163 215 389 163 215 391 minecraft:jack_o_lantern
setblock 163 215 393 minecraft:red_concrete
fill 163 215 397 163 215 399 minecraft:white_concrete
fill 163 215 400 163 215 401 minecraft:red_concrete
fill 164 215 379 164 215 381 minecraft:white_concrete
setblock 164 215 382 minecraft:red_concrete
setblock 164 215 383 minecraft:white_concrete
setblock 164 215 386 minecraft:red_concrete
fill 164 215 387 166 215 388 minecraft:white_concrete
setblock 164 215 389 minecraft:red_concrete
fill 164 215 390 168 215 390 minecraft:white_concrete
setblock 164 215 391 minecraft:red_concrete
fill 164 215 392 166 215 393 minecraft:white_concrete
setblock 164 215 394 minecraft:red_concrete
setblock 164 215 397 minecraft:white_concrete
setblock 164 215 398 minecraft:red_concrete
fill 164 215 399 164 215 401 minecraft:white_concrete
fill 165 215 379 166 215 379 minecraft:gold_block
fill 165 215 380 166 215 382 minecraft:white_concrete
fill 165 215 383 167 215 383 minecraft:red_concrete
setblock 165 215 385 minecraft:red_concrete
fill 165 215 386 167 215 386 minecraft:white_concrete
fill 165 215 389 168 215 389 minecraft:white_concrete
fill 165 215 391 168 215 391 minecraft:white_concrete
fill 165 215 394 167 215 394 minecraft:white_concrete
setblock 165 215 395 minecraft:red_concrete
fill 165 215 397 167 215 397 minecraft:red_concrete
fill 165 215 398 166 215 400 minecraft:white_concrete
fill 165 215 401 166 215 401 minecraft:gold_block
fill 166 215 378 182 215 378 minecraft:black_concrete
fill 166 215 384 167 215 384 minecraft:red_concrete
setblock 166 215 385 minecraft:white_concrete
setblock 166 215 395 minecraft:white_concrete
fill 166 215 396 167 215 396 minecraft:red_concrete
fill 166 215 402 182 215 402 minecraft:black_concrete
fill 167 215 379 182 215 379 minecraft:black_concrete
fill 167 215 380 168 215 380 minecraft:gold_block
fill 167 215 381 167 215 382 minecraft:white_concrete
setblock 167 215 385 minecraft:red_concrete
fill 167 215 387 169 215 387 minecraft:white_concrete
fill 167 215 388 169 215 388 minecraft:red_concrete
fill 167 215 392 169 215 392 minecraft:red_concrete
fill 167 215 393 169 215 393 minecraft:white_concrete
setblock 167 215 395 minecraft:red_concrete
fill 167 215 398 167 215 399 minecraft:white_concrete
fill 167 215 400 168 215 400 minecraft:gold_block
fill 167 215 401 182 215 401 minecraft:black_concrete
fill 168 215 381 169 215 381 minecraft:gold_block
setblock 168 215 382 minecraft:red_concrete
fill 168 215 383 169 215 385 minecraft:white_concrete
setblock 168 215 386 minecraft:red_concrete
setblock 168 215 394 minecraft:red_concrete
fill 168 215 395 169 215 397 minecraft:white_concrete
setblock 168 215 398 minecraft:red_concrete
fill 168 215 399 169 215 399 minecraft:gold_block
fill 169 215 380 182 215 380 minecraft:black_concrete
fill 169 215 382 170 215 382 minecraft:gold_block
fill 169 215 386 171 215 386 minecraft:white_concrete
fill 169 215 389 169 215 391 minecraft:red_concrete
fill 169 215 394 171 215 394 minecraft:white_concrete
fill 169 215 398 170 215 398 minecraft:gold_block
fill 169 215 400 182 215 400 minecraft:black_concrete
fill 170 215 381 182 215 381 minecraft:black_concrete
setblock 170 215 383 minecraft:gold_block
fill 170 215 384 170 215 385 minecraft:white_concrete
fill 170 215 387 171 215 387 minecraft:red_concrete
fill 170 215 388 171 215 392 minecraft:white_concrete
fill 170 215 393 171 215 393 minecraft:red_concrete
fill 170 215 395 170 215 396 minecraft:white_concrete
setblock 170 215 397 minecraft:gold_block
fill 170 215 399 182 215 399 minecraft:black_concrete
fill 171 215 382 182 215 383 minecraft:black_concrete
fill 171 215 384 171 215 385 minecraft:gold_block
fill 171 215 395 171 215 396 minecraft:gold_block
fill 171 215 397 182 215 398 minecraft:black_concrete
fill 172 215 384 182 215 384 minecraft:black_concrete
fill 172 215 385 172 215 395 minecraft:gold_block
fill 172 215 396 182 215 396 minecraft:black_concrete
fill 173 215 385 182 215 389 minecraft:black_concrete
setblock 173 215 390 minecraft:gold_block
fill 173 215 391 182 215 395 minecraft:black_concrete
fill 174 215 390 182 215 390 minecraft:black_concrete
fill 142 219 370 149 219 377 minecraft:white_concrete
fill 142 219 382 142 267 382 minecraft:white_concrete
fill 142 219 384 142 220 384 minecraft:white_concrete
fill 142 219 386 151 219 396 minecraft:white_concrete
fill 142 219 398 142 220 398 minecraft:white_concrete
fill 142 219 403 142 267 403 minecraft:white_concrete
fill 142 219 405 142 220 405 minecraft:white_concrete
fill 142 219 410 142 267 410 minecraft:white_concrete
setblock 144 219 380 minecraft:light[level=14]
setblock 144 219 404 minecraft:light[level=14]
fill 144 219 410 144 220 410 minecraft:white_concrete
fill 149 219 410 149 267 410 minecraft:white_concrete
fill 151 219 370 151 267 370 minecraft:white_concrete
fill 151 219 410 151 220 410 minecraft:white_concrete
setblock 152 219 372 minecraft:light[level=14]
setblock 152 219 380 minecraft:light[level=14]
setblock 152 219 388 minecraft:light[level=14]
setblock 152 219 396 minecraft:light[level=14]
setblock 152 219 404 minecraft:light[level=14]
fill 156 219 370 156 220 370 minecraft:white_concrete
fill 156 219 410 156 267 410 minecraft:white_concrete
fill 158 219 370 158 267 370 minecraft:white_concrete
fill 158 219 410 158 220 410 minecraft:white_concrete
setblock 160 219 372 minecraft:light[level=14]
setblock 160 219 380 minecraft:light[level=14]
setblock 160 219 388 minecraft:light[level=14]
setblock 160 219 396 minecraft:light[level=14]
setblock 160 219 404 minecraft:light[level=14]
fill 163 219 370 163 220 370 minecraft:white_concrete
fill 163 219 410 163 267 410 minecraft:white_concrete
fill 165 219 370 165 267 370 minecraft:white_concrete
fill 165 219 410 165 220 410 minecraft:white_concrete
setblock 168 219 372 minecraft:light[level=14]
setblock 168 219 380 minecraft:light[level=14]
setblock 168 219 388 minecraft:light[level=14]
setblock 168 219 396 minecraft:light[level=14]
setblock 168 219 404 minecraft:light[level=14]
fill 169 219 403 181 219 410 minecraft:white_concrete
fill 170 219 370 170 220 370 minecraft:white_concrete
fill 172 219 370 172 267 370 minecraft:white_concrete
fill 173 219 373 182 239 383 minecraft:white_concrete
setblock 176 219 372 minecraft:light[level=14]
setblock 176 219 388 minecraft:light[level=14]
setblock 176 219 396 minecraft:light[level=14]
fill 177 219 370 177 220 370 minecraft:white_concrete
fill 179 219 370 179 267 370 minecraft:white_concrete
fill 182 219 372 182 220 372 minecraft:white_concrete
fill 182 219 386 182 220 386 minecraft:white_concrete
fill 182 219 388 182 267 388 minecraft:white_concrete
fill 182 219 393 182 220 393 minecraft:white_concrete
fill 182 219 395 182 267 395 minecraft:white_concrete
fill 182 219 400 182 220 400 minecraft:white_concrete
fill 182 219 402 182 267 402 minecraft:white_concrete
fill 182 219 407 182 220 407 minecraft:white_concrete
fill 182 219 409 182 267 409 minecraft:white_concrete
setblock 142 220 370 minecraft:jack_o_lantern
fill 142 220 371 142 234 371 minecraft:white_concrete
setblock 142 220 372 minecraft:jack_o_lantern
fill 142 220 373 142 234 373 minecraft:white_concrete
setblock 142 220 374 minecraft:jack_o_lantern
fill 142 220 375 142 267 375 minecraft:white_concrete
setblock 142 220 376 minecraft:jack_o_lantern
fill 142 220 377 142 220 381 minecraft:white_concrete
setblock 142 220 383 minecraft:white_concrete
setblock 142 220 385 minecraft:white_concrete
setblock 142 220 386 minecraft:jack_o_lantern
fill 142 220 387 142 240 387 minecraft:white_concrete
setblock 142 220 388 minecraft:jack_o_lantern
fill 142 220 389 142 267 389 minecraft:white_concrete
setblock 142 220 390 minecraft:jack_o_lantern
fill 142 220 391 142 240 391 minecraft:white_concrete
setblock 142 220 392 minecraft:jack_o_lantern
fill 142 220 393 142 240 393 minecraft:white_concrete
setblock 142 220 394 minecraft:jack_o_lantern
fill 142 220 395 142 240 395 minecraft:white_concrete
setblock 142 220 396 minecraft:jack_o_lantern
setblock 142 220 397 minecraft:white_concrete
fill 142 220 399 142 220 402 minecraft:white_concrete
setblock 142 220 404 minecraft:white_concrete
fill 142 220 406 142 220 409 minecraft:white_concrete
setblock 143 220 369 minecraft:jack_o_lantern
fill 143 220 370 143 234 370 minecraft:white_concrete
setblock 143 220 371 minecraft:jack_o_lantern
fill 143 220 372 143 234 372 minecraft:white_concrete
setblock 143 220 373 minecraft:jack_o_lantern
fill 143 220 374 143 234 374 minecraft:white_concrete
setblock 143 220 375 minecraft:jack_o_lantern
fill 143 220 376 143 234 376 minecraft:white_concrete
setblock 143 220 377 minecraft:jack_o_lantern
fill 143 220 386 143 240 386 minecraft:white_concrete
setblock 143 220 387 minecraft:jack_o_lantern
fill 143 220 388 143 240 388 minecraft:white_concrete
setblock 143 220 389 minecraft:jack_o_lantern
fill 143 220 390 143 240 390 minecraft:white_concrete
setblock 143 220 391 minecraft:jack_o_lantern
fill 143 220 392 143 240 392 minecraft:white_concrete
setblock 143 220 393 minecraft:jack_o_lantern
fill 143 220 394 143 240 394 minecraft:white_concrete
setblock 143 220 395 minecraft:jack_o_lantern
fill 143 220 396 143 240 396 minecraft:white_concrete
setblock 143 220 410 minecraft:white_concrete
fill 144 220 369 144 307 369 minecraft:purple_terracotta
setblock 144 220 370 minecraft:jack_o_lantern
fill 144 220 371 144 234 371 minecraft:white_concrete
setblock 144 220 372 minecraft:jack_o_lantern
fill 144 220 373 144 234 373 minecraft:white_concrete
setblock 144 220 374 minecraft:jack_o_lantern
fill 144 220 375 144 234 375 minecraft:white_concrete
setblock 144 220 376 minecraft:jack_o_lantern
fill 144 220 377 144 234 377 minecraft:white_concrete
setblock 144 220 386 minecraft:jack_o_lantern
fill 144 220 387 144 240 387 minecraft:white_concrete
setblock 144 220 388 minecraft:jack_o_lantern
fill 144 220 389 144 240 389 minecraft:white_concrete
setblock 144 220 390 minecraft:jack_o_lantern
fill 144 220 391 144 240 391 minecraft:white_concrete
setblock 144 220 392 minecraft:jack_o_lantern
fill 144 220 393 144 240 393 minecraft:white_concrete
setblock 144 220 394 minecraft:jack_o_lantern
fill 144 220 395 144 240 395 minecraft:white_concrete
setblock 144 220 396 minecraft:jack_o_lantern
setblock 145 220 369 minecraft:jack_o_lantern
fill 145 220 370 145 234 370 minecraft:white_concrete
setblock 145 220 371 minecraft:jack_o_lantern
fill 145 220 372 145 234 372 minecraft:white_concrete
setblock 145 220 373 minecraft:jack_o_lantern
fill 145 220 374 145 234 374 minecraft:white_concrete
setblock 145 220 375 minecraft:jack_o_lantern
fill 145 220 376 145 234 376 minecraft:white_concrete
setblock 145 220 377 minecraft:jack_o_lantern
fill 145 220 386 145 240 386 minecraft:white_concrete
setblock 145 220 387 minecraft:jack_o_lantern
fill 145 220 388 145 240 388 minecraft:white_concrete
setblock 145 220 389 minecraft:jack_o_lantern
fill 145 220 390 145 240 390 minecraft:white_concrete
setblock 145 220 391 minecraft:jack_o_lantern
fill 145 220 392 145 240 392 minecraft:white_concrete
setblock 145 220 393 minecraft:jack_o_lantern
fill 145 220 394 145 240 394 minecraft:white_concrete
setblock 145 220 395 minecraft:jack_o_lantern
fill 145 220 396 145 240 396 minecraft:white_concrete
fill 145 220 410 148 220 410 minecraft:white_concrete
setblock 146 220 370 minecraft:jack_o_lantern
fill 146 220 371 146 234 371 minecraft:white_concrete
setblock 146 220 372 minecraft:jack_o_lantern
fill 146 220 373 146 234 373 minecraft:white_concrete
setblock 146 220 374 minecraft:jack_o_lantern
fill 146 220 375 146 234 375 minecraft:white_concrete
setblock 146 220 376 minecraft:jack_o_lantern
fill 146 220 377 146 234 377 minecraft:white_concrete
setblock 146 220 386 minecraft:jack_o_lantern
fill 146 220 387 146 240 387 minecraft:white_concrete
setblock 146 220 388 minecraft:jack_o_lantern
fill 146 220 389 146 240 389 minecraft:white_concrete
setblock 146 220 390 minecraft:jack_o_lantern
fill 146 220 391 146 240 391 minecraft:white_concrete
setblock 146 220 392 minecraft:jack_o_lantern
fill 146 220 393 146 240 393 minecraft:white_concrete
setblock 146 220 394 minecraft:jack_o_lantern
fill 146 220 395 146 240 395 minecraft:white_concrete
setblock 146 220 396 minecraft:jack_o_lantern
setblock 147 220 369 minecraft:jack_o_lantern
fill 147 220 370 147 235 370 minecraft:white_concrete
setblock 147 220 371 minecraft:jack_o_lantern
fill 147 220 372 147 234 372 minecraft:white_concrete
setblock 147 220 373 minecraft:jack_o_lantern
fill 147 220 374 147 234 374 minecraft:white_concrete
setblock 147 220 375 minecraft:jack_o_lantern
fill 147 220 376 147 234 376 minecraft:white_concrete
setblock 147 220 377 minecraft:jack_o_lantern
fill 147 220 386 147 240 386 minecraft:white_concrete
setblock 147 220 387 minecraft:jack_o_lantern
fill 147 220 388 147 240 388 minecraft:white_concrete
setblock 147 220 389 minecraft:jack_o_lantern
fill 147 220 390 147 240 390 minecraft:white_concrete
setblock 147 220 391 minecraft:jack_o_lantern
fill 147 220 392 147 240 392 minecraft:white_concrete
setblock 147 220 393 minecraft:jack_o_lantern
fill 147 220 394 147 240 394 minecraft:white_concrete
setblock 147 220 395 minecraft:jack_o_lantern
fill 147 220 396 147 240 396 minecraft:white_concrete
setblock 148 220 370 minecraft:jack_o_lantern
fill 148 220 371 148 234 371 minecraft:white_concrete
setblock 148 220 372 minecraft:jack_o_lantern
fill 148 220 373 148 234 373 minecraft:white_concrete
setblock 148 220 374 minecraft:jack_o_lantern
fill 148 220 375 148 234 375 minecraft:white_concrete
setblock 148 220 376 minecraft:jack_o_lantern
fill 148 220 377 148 234 377 minecraft:white_concrete
setblock 148 220 386 minecraft:jack_o_lantern
fill 148 220 387 148 240 387 minecraft:white_concrete
setblock 148 220 388 minecraft:jack_o_lantern
fill 148 220 389 148 240 389 minecraft:white_concrete
setblock 148 220 390 minecraft:jack_o_lantern
fill 148 220 391 148 240 391 minecraft:white_concrete
setblock 148 220 392 minecraft:jack_o_lantern
fill 148 220 393 148 240 393 minecraft:white_concrete
setblock 148 220 394 minecraft:jack_o_lantern
fill 148 220 395 148 240 395 minecraft:white_concrete
setblock 148 220 396 minecraft:jack_o_lantern
setblock 149 220 369 minecraft:jack_o_lantern
fill 149 220 370 150 220 370 minecraft:white_concrete
setblock 149 220 371 minecraft:jack_o_lantern
fill 149 220 372 149 234 372 minecraft:white_concrete
setblock 149 220 373 minecraft:jack_o_lantern
fill 149 220 374 149 234 374 minecraft:white_concrete
setblock 149 220 375 minecraft:jack_o_lantern
fill 149 220 376 149 234 376 minecraft:white_concrete
setblock 149 220 377 minecraft:jack_o_lantern
fill 149 220 386 149 240 386 minecraft:white_concrete
setblock 149 220 387 minecraft:jack_o_lantern
fill 149 220 388 149 240 388 minecraft:white_concrete
setblock 149 220 389 minecraft:jack_o_lantern
fill 149 220 390 149 240 390 minecraft:white_concrete
setblock 149 220 391 minecraft:jack_o_lantern
fill 149 220 392 149 240 392 minecraft:white_concrete
setblock 149 220 393 minecraft:jack_o_lantern
fill 149 220 394 149 240 394 minecraft:white_concrete
setblock 149 220 395 minecraft:jack_o_lantern
fill 149 220 396 149 240 396 minecraft:white_concrete
setblock 150 220 386 minecraft:jack_o_lantern
fill 150 220 387 150 240 387 minecraft:white_concrete
setblock 150 220 388 minecraft:jack_o_lantern
fill 150 220 389 150 240 389 minecraft:white_concrete
setblock 150 220 390 minecraft:jack_o_lantern
fill 150 220 391 150 240 391 minecraft:white_concrete
setblock 150 220 392 minecraft:jack_o_lantern
fill 150 220 393 150 240 393 minecraft:white_concrete
setblock 150 220 394 minecraft:jack_o_lantern
fill 150 220 395 150 240 395 minecraft:white_concrete
setblock 150 220 396 minecraft:jack_o_lantern
setblock 150 220 410 minecraft:white_concrete
fill 151 220 386 151 240 386 minecraft:white_concrete
setblock 151 220 387 minecraft:jack_o_lantern
fill 151 220 388 151 240 388 minecraft:white_concrete
setblock 151 220 389 minecraft:jack_o_lantern
fill 151 220 390 151 240 390 minecraft:white_concrete
setblock 151 220 391 minecraft:jack_o_lantern
fill 151 220 392 151 240 392 minecraft:white_concrete
setblock 151 220 393 minecraft:jack_o_lantern
fill 151 220 394 151 240 394 minecraft:white_concrete
setblock 151 220 395 minecraft:jack_o_lantern
fill 151 220 396 151 240 396 minecraft:white_concrete
fill 152 220 370 155 220 370 minecraft:white_concrete
fill 152 220 410 155 220 410 minecraft:white_concrete
setblock 157 220 370 minecraft:white_concrete
setblock 157 220 410 minecraft:white_concrete
fill 159 220 370 162 220 370 minecraft:white_concrete
fill 159 220 410 162 220 410 minecraft:white_concrete
setblock 164 220 370 minecraft:white_concrete
setblock 164 220 410 minecraft:white_concrete
fill 166 220 370 169 220 370 minecraft:white_concrete
fill 166 220 410 169 220 410 minecraft:white_concrete
setblock 169 220 403 minecraft:jack_o_lantern
fill 169 220 404 169 239 404 minecraft:white_concrete
setblock 169 220 405 minecraft:jack_o_lantern
fill 169 220 406 169 239 406 minecraft:white_concrete
setblock 169 220 407 minecraft:jack_o_lantern
fill 169 220 408 169 239 408 minecraft:white_concrete
setblock 169 220 409 minecraft:jack_o_lantern
fill 170 220 403 170 239 403 minecraft:white_concrete
setblock 170 220 404 minecraft:jack_o_lantern
fill 170 220 405 170 239 405 minecraft:white_concrete
setblock 170 220 406 minecraft:jack_o_lantern
fill 170 220 407 170 239 407 minecraft:white_concrete
setblock 170 220 408 minecraft:jack_o_lantern
fill 170 220 409 170 239 409 minecraft:white_concrete
setblock 170 220 410 minecraft:jack_o_lantern
setblock 171 220 370 minecraft:white_concrete
setblock 171 220 403 minecraft:jack_o_lantern
fill 171 220 404 171 239 404 minecraft:white_concrete
setblock 171 220 405 minecraft:jack_o_lantern
fill 171 220 406 171 239 406 minecraft:white_concrete
setblock 171 220 407 minecraft:jack_o_lantern
fill 171 220 408 171 239 408 minecraft:white_concrete
setblock 171 220 409 minecraft:jack_o_lantern
fill 171 220 410 171 240 410 minecraft:white_concrete
fill 172 220 403 172 239 403 minecraft:white_concrete
setblock 172 220 404 minecraft:jack_o_lantern
fill 172 220 405 172 239 405 minecraft:white_concrete
setblock 172 220 406 minecraft:jack_o_lantern
fill 172 220 407 172 239 407 minecraft:white_concrete
setblock 172 220 408 minecraft:jack_o_lantern
fill 172 220 409 172 239 409 minecraft:white_concrete
setblock 172 220 410 minecraft:jack_o_lantern
fill 173 220 370 176 220 370 minecraft:white_concrete
setblock 173 220 403 minecraft:jack_o_lantern
fill 173 220 404 173 239 404 minecraft:white_concrete
setblock 173 220 405 minecraft:jack_o_lantern
fill 173 220 406 173 239 406 minecraft:white_concrete
setblock 173 220 407 minecraft:jack_o_lantern
fill 173 220 408 173 239 408 minecraft:white_concrete
setblock 173 220 409 minecraft:jack_o_lantern
fill 173 220 410 173 241 410 minecraft:white_concrete
fill 174 220 403 174 239 403 minecraft:white_concrete
setblock 174 220 404 minecraft:jack_o_lantern
fill 174 220 405 174 239 405 minecraft:white_concrete
setblock 174 220 406 minecraft:jack_o_lantern
fill 174 220 407 174 239 407 minecraft:white_concrete
setblock 174 220 408 minecraft:jack_o_lantern
fill 174 220 409 174 239 409 minecraft:white_concrete
setblock 174 220 410 minecraft:jack_o_lantern
setblock 175 220 403 minecraft:jack_o_lantern
fill 175 220 404 175 239 404 minecraft:white_concrete
setblock 175 220 405 minecraft:jack_o_lantern
fill 175 220 406 175 239 406 minecraft:white_concrete
setblock 175 220 407 minecraft:jack_o_lantern
fill 175 220 408 175 239 408 minecraft:white_concrete
setblock 175 220 409 minecraft:jack_o_lantern
fill 175 220 410 175 240 410 minecraft:white_concrete
fill 176 220 403 176 239 403 minecraft:white_concrete
setblock 176 220 404 minecraft:jack_o_lantern
fill 176 220 405 176 239 405 minecraft:white_concrete
setblock 176 220 406 minecraft:jack_o_lantern
fill 176 220 407 176 239 407 minecraft:white_concrete
setblock 176 220 408 minecraft:jack_o_lantern
fill 176 220 409 176 239 409 minecraft:white_concrete
setblock 176 220 410 minecraft:jack_o_lantern
setblock 177 220 403 minecraft:jack_o_lantern
fill 177 220 404 177 239 404 minecraft:white_concrete
setblock 177 220 405 minecraft:jack_o_lantern
fill 177 220 406 177 239 406 minecraft:white_concrete
setblock 177 220 407 minecraft:jack_o_lantern
fill 177 220 408 177 239 408 minecraft:white_concrete
setblock 177 220 409 minecraft:jack_o_lantern
fill 177 220 410 177 267 410 minecraft:white_concrete
setblock 178 220 370 minecraft:white_concrete
fill 178 220 403 178 239 403 minecraft:white_concrete
setblock 178 220 404 minecraft:jack_o_lantern
fill 178 220 405 178 239 405 minecraft:white_concrete
setblock 178 220 406 minecraft:jack_o_lantern
fill 178 220 407 178 239 407 minecraft:white_concrete
setblock 178 220 408 minecraft:jack_o_lantern
fill 178 220 409 178 239 409 minecraft:white_concrete
setblock 178 220 410 minecraft:jack_o_lantern
setblock 179 220 403 minecraft:jack_o_lantern
fill 179 220 404 179 239 404 minecraft:white_concrete
setblock 179 220 405 minecraft:jack_o_lantern
fill 179 220 406 179 239 406 minecraft:white_concrete
setblock 179 220 407 minecraft:jack_o_lantern
fill 179 220 408 179 239 408 minecraft:white_concrete
setblock 179 220 409 minecraft:jack_o_lantern
fill 179 220 410 179 240 410 minecraft:white_concrete
fill 180 220 370 182 220 370 minecraft:white_concrete
fill 180 220 403 180 239 403 minecraft:white_concrete
setblock 180 220 404 minecraft:jack_o_lantern
fill 180 220 405 180 239 405 minecraft:white_concrete
setblock 180 220 406 minecraft:jack_o_lantern
fill 180 220 407 180 239 407 minecraft:white_concrete
setblock 180 220 408 minecraft:jack_o_lantern
fill 180 220 409 180 239 409 minecraft:white_concrete
setblock 180 220 410 minecraft:jack_o_lantern
setblock 181 220 403 minecraft:jack_o_lantern
fill 181 220 404 182 220 404 minecraft:white_concrete
setblock 181 220 405 minecraft:jack_o_lantern
fill 181 220 406 182 220 406 minecraft:white_concrete
setblock 181 220 407 minecraft:jack_o_lantern
fill 181 220 408 182 220 408 minecraft:white_concrete
setblock 181 220 409 minecraft:jack_o_lantern
fill 181 220 410 182 220 410 minecraft:white_concrete
setblock 182 220 371 minecraft:white_concrete
fill 182 220 384 182 220 385 minecraft:white_concrete
setblock 182 220 387 minecraft:white_concrete
fill 182 220 389 182 220 392 minecraft:white_concrete
setblock 182 220 394 minecraft:white_concrete
fill 182 220 396 182 220 399 minecraft:white_concrete
setblock 182 220 401 minecraft:white_concrete
setblock 182 220 403 minecraft:white_concrete
fill 182 220 405 182 221 405 minecraft:white_concrete
fill 142 221 370 142 222 370 minecraft:white_concrete
fill 142 221 372 142 222 372 minecraft:white_concrete
fill 142 221 374 142 222 374 minecraft:white_concrete
fill 142 221 376 142 222 377 minecraft:white_concrete
setblock 142 221 379 minecraft:white_concrete
fill 142 221 386 142 222 386 minecraft:white_concrete
fill 142 221 388 142 222 388 minecraft:white_concrete
fill 142 221 390 142 222 390 minecraft:white_concrete
fill 142 221 392 142 222 392 minecraft:white_concrete
fill 142 221 394 142 222 394 minecraft:white_concrete
fill 142 221 396 142 222 396 minecraft:white_concrete
setblock 142 221 400 minecraft:white_concrete
setblock 142 221 407 minecraft:white_concrete
fill 143 221 369 143 222 369 minecraft:purple_terracotta
fill 143 221 371 143 222 371 minecraft:white_concrete
fill 143 221 373 143 222 373 minecraft:white_concrete
fill 143 221 375 143 222 375 minecraft:white_concrete
fill 143 221 377 143 222 377 minecraft:white_concrete
fill 143 221 387 143 222 387 minecraft:white_concrete
fill 143 221 389 143 222 389 minecraft:white_concrete
fill 143 221 391 143 222 391 minecraft:white_concrete
fill 143 221 393 143 222 393 minecraft:white_concrete
fill 143 221 395 143 222 395 minecraft:white_concrete
fill 144 221 370 144 222 370 minecraft:white_concrete
fill 144 221 372 144 222 372 minecraft:white_concrete
fill 144 221 374 144 222 374 minecraft:white_concrete
fill 144 221 376 144 222 376 minecraft:white_concrete
fill 144 221 386 144 222 386 minecraft:white_concrete
fill 144 221 388 144 222 388 minecraft:white_concrete
fill 144 221 390 144 222 390 minecraft:white_concrete
fill 144 221 392 144 222 392 minecraft:white_concrete
fill 144 221 394 144 222 394 minecraft:white_concrete
fill 144 221 396 144 222 396 minecraft:white_concrete
fill 145 221 369 145 222 369 minecraft:purple_terracotta
fill 145 221 371 145 222 371 minecraft:white_concrete
fill 145 221 373 145 222 373 minecraft:white_concrete
fill 145 221 375 145 222 375 minecraft:white_concrete
fill 145 221 377 145 222 377 minecraft:white_concrete
fill 145 221 387 145 222 387 minecraft:white_concrete
fill 145 221 389 145 222 389 minecraft:white_concrete
fill 145 221 391 145 222 391 minecraft:white_concrete
fill 145 221 393 145 222 393 minecraft:white_concrete
fill 145 221 395 145 222 395 minecraft:white_concrete
fill 146 221 370 146 222 370 minecraft:white_concrete
fill 146 221 372 146 222 372 minecraft:white_concrete
fill 146 221 374 146 222 374 minecraft:white_concrete
fill 146 221 376 146 222 376 minecraft:white_concrete
fill 146 221 386 146 222 386 minecraft:white_concrete
fill 146 221 388 146 222 388 minecraft:white_concrete
fill 146 221 390 146 222 390 minecraft:white_concrete
fill 146 221 392 146 222 392 minecraft:white_concrete
fill 146 221 394 146 222 394 minecraft:white_concrete
fill 146 221 396 146 222 396 minecraft:white_concrete
setblock 146 221 410 minecraft:white_concrete
fill 147 221 369 147 222 369 minecraft:purple_terracotta
fill 147 221 371 147 222 371 minecraft:white_concrete
fill 147 221 373 147 222 373 minecraft:white_concrete
fill 147 221 375 147 222 375 minecraft:white_concrete
fill 147 221 377 147 222 377 minecraft:white_concrete
fill 147 221 387 147 222 387 minecraft:white_concrete
fill 147 221 389 147 222 389 minecraft:white_concrete
fill 147 221 391 147 222 391 minecraft:white_concrete
fill 147 221 393 147 222 393 minecraft:white_concrete
fill 147 221 395 147 222 395 minecraft:white_concrete
fill 148 221 370 149 222 370 minecraft:white_concrete
fill 148 221 372 148 222 372 minecraft:white_concrete
fill 148 221 374 148 222 374 minecraft:white_concrete
fill 148 221 376 148 222 376 minecraft:white_concrete
fill 148 221 386 148 222 386 minecraft:white_concrete
fill 148 221 388 148 222 388 minecraft:white_concrete
fill 148 221 390 148 222 390 minecraft:white_concrete
fill 148 221 392 148 222 392 minecraft:white_concrete
fill 148 221 394 148 222 394 minecraft:white_concrete
fill 148 221 396 148 222 396 minecraft:white_concrete
fill 149 221 369 149 222 369 minecraft:purple_terracotta
fill 149 221 371 149 222 371 minecraft:white_concrete
fill 149 221 373 149 222 373 minecraft:white_concrete
fill 149 221 375 149 222 375 minecraft:white_concrete
fill 149 221 377 149 222 377 minecraft:white_concrete
fill 149 221 387 149 222 387 minecraft:white_concrete
fill 149 221 389 149 222 389 minecraft:white_concrete
fill 149 221 391 149 222 391 minecraft:white_concrete
fill 149 221 393 149 222 393 minecraft:white_concrete
fill 149 221 395 149 222 395 minecraft:white_concrete
fill 150 221 386 150 222 386 minecraft:white_concrete
fill 150 221 388 150 222 388 minecraft:white_concrete
fill 150 221 390 150 222 390 minecraft:white_concrete
fill 150 221 392 150 222 392 minecraft:white_concrete
fill 150 221 394 150 222 394 minecraft:white_concrete
fill 150 221 396 150 222 396 minecraft:white_concrete
fill 151 221 387 151 222 387 minecraft:white_concrete
fill 151 221 389 151 222 389 minecraft:white_concrete
fill 151 221 391 151 222 391 minecraft:white_concrete
fill 151 221 393 151 222 393 minecraft:white_concrete
fill 151 221 395 151 222 395 minecraft:white_concrete
setblock 153 221 410 minecraft:white_concrete
setblock 154 221 370 minecraft:white_concrete
setblock 160 221 410 minecraft:white_concrete
setblock 161 221 370 minecraft:white_concrete
setblock 167 221 410 minecraft:white_concrete
setblock 168 221 370 minecraft:white_concrete
fill 169 221 403 169 222 403 minecraft:white_concrete
fill 169 221 405 169 222 405 minecraft:white_concrete
fill 169 221 407 169 222 407 minecraft:white_concrete
fill 169 221 409 169 222 410 minecraft:white_concrete
fill 170 221 404 170 222 404 minecraft:white_concrete
fill 170 221 406 170 222 406 minecraft:white_concrete
fill 170 221 408 170 222 408 minecraft:white_concrete
fill 170 221 410 170 222 410 minecraft:white_concrete
fill 171 221 403 171 222 403 minecraft:white_concrete
fill 171 221 405 171 222 405 minecraft:white_concrete
fill 171 221 407 171 222 407 minecraft:white_concrete
fill 171 221 409 171 222 409 minecraft:white_concrete
fill 172 221 404 172 222 404 minecraft:white_concrete
fill 172 221 406 172 222 406 minecraft:white_concrete
fill 172 221 408 172 222 408 minecraft:white_concrete
fill 172 221 410 172 222 410 minecraft:white_concrete
fill 173 221 403 173 222 403 minecraft:white_concrete
fill 173 221 405 173 222 405 minecraft:white_concrete
fill 173 221 407 173 222 407 minecraft:white_concrete
fill 173 221 409 173 222 409 minecraft:white_concrete
fill 174 221 404 174 222 404 minecraft:white_concrete
fill 174 221 406 174 222 406 minecraft:white_concrete
fill 174 221 408 174 222 408 minecraft:white_concrete
fill 174 221 410 174 222 410 minecraft:white_concrete
setblock 175 221 370 minecraft:white_concrete
fill 175 221 403 175 222 403 minecraft:white_concrete
fill 175 221 405 175 222 405 minecraft:white_concrete
fill 175 221 407 175 222 407 minecraft:white_concrete
fill 175 221 409 175 222 409 minecraft:white_concrete
fill 176 221 404 176 222 404 minecraft:white_concrete
fill 176 221 406 176 222 406 minecraft:white_concrete
fill 176 221 408 176 222 408 minecraft:white_concrete
fill 176 221 410 176 222 410 minecraft:white_concrete
fill 177 221 403 177 222 403 minecraft:white_concrete
fill 177 221 405 177 222 405 minecraft:white_concrete
fill 177 221 407 177 222 407 minecraft:white_concrete
fill 177 221 409 177 222 409 minecraft:white_concrete
fill 178 221 404 178 222 404 minecraft:white_concrete
fill 178 221 406 178 222 406 minecraft:white_concrete
fill 178 221 408 178 222 408 minecraft:white_concrete
fill 178 221 410 178 222 410 minecraft:white_concrete
fill 179 221 403 179 222 403 minecraft:white_concrete
fill 179 221 405 179 222 405 minecraft:white_concrete
fill 179 221 407 179 222 407 minecraft:white_concrete
fill 179 221 409 179 222 409 minecraft:white_concrete
fill 180 221 404 181 222 404 minecraft:white_concrete
fill 180 221 406 181 222 406 minecraft:white_concrete
fill 180 221 408 181 222 408 minecraft:white_concrete
fill 180 221 410 181 222 410 minecraft:white_concrete
fill 181 221 403 181 222 403 minecraft:white_concrete
fill 181 221 405 181 222 405 minecraft:white_concrete
fill 181 221 407 181 222 407 minecraft:white_concrete
fill 181 221 409 181 222 409 minecraft:white_concrete
setblock 182 221 370 minecraft:white_concrete
setblock 182 221 384 minecraft:white_concrete
setblock 182 221 391 minecraft:white_concrete
setblock 182 221 398 minecraft:white_concrete
setblock 142 222 380 minecraft:white_concrete
setblock 142 222 401 minecraft:white_concrete
setblock 142 222 408 minecraft:white_concrete
setblock 147 222 410 minecraft:white_concrete
setblock 153 222 370 minecraft:white_concrete
setblock 154 222 410 minecraft:white_concrete
setblock 160 222 370 minecraft:white_concrete
setblock 161 222 410 minecraft:white_concrete
setblock 167 222 370 minecraft:white_concrete
setblock 168 222 410 minecraft:white_concrete
setblock 174 222 370 minecraft:white_concrete
setblock 181 222 370 minecraft:white_concrete
setblock 182 222 390 minecraft:white_concrete
setblock 182 222 397 minecraft:white_concrete
setblock 182 222 404 minecraft:white_concrete
setblock 182 222 410 minecraft:white_concrete
setblock 142 223 370 minecraft:jack_o_lantern
setblock 142 223 372 minecraft:jack_o_lantern
setblock 142 223 374 minecraft:jack_o_lantern
setblock 142 223 376 minecraft:jack_o_lantern
fill 142 223 377 142 234 377 minecraft:white_concrete
setblock 142 223 381 minecraft:white_concrete
setblock 142 223 386 minecraft:jack_o_lantern
setblock 142 223 388 minecraft:jack_o_lantern
setblock 142 223 390 minecraft:jack_o_lantern
setblock 142 223 392 minecraft:jack_o_lantern
setblock 142 223 394 minecraft:jack_o_lantern
setblock 142 223 396 minecraft:jack_o_lantern
setblock 142 223 402 minecraft:white_concrete
setblock 142 223 409 minecraft:white_concrete
setblock 143 223 369 minecraft:jack_o_lantern
setblock 143 223 371 minecraft:jack_o_lantern
setblock 143 223 373 minecraft:jack_o_lantern
setblock 143 223 375 minecraft:jack_o_lantern
setblock 143 223 377 minecraft:jack_o_lantern
setblock 143 223 387 minecraft:jack_o_lantern
setblock 143 223 389 minecraft:jack_o_lantern
setblock 143 223 391 minecraft:jack_o_lantern
setblock 143 223 393 minecraft:jack_o_lantern
setblock 143 223 395 minecraft:jack_o_lantern
setblock 144 223 370 minecraft:jack_o_lantern
setblock 144 223 372 minecraft:jack_o_lantern
setblock 144 223 374 minecraft:jack_o_lantern
setblock 144 223 376 minecraft:jack_o_lantern
setblock 144 223 386 minecraft:jack_o_lantern
setblock 144 223 388 minecraft:jack_o_lantern
setblock 144 223 390 minecraft:jack_o_lantern
setblock 144 223 392 minecraft:jack_o_lantern
setblock 144 223 394 minecraft:jack_o_lantern
setblock 144 223 396 minecraft:jack_o_lantern
setblock 145 223 369 minecraft:jack_o_lantern
setblock 145 223 371 minecraft:jack_o_lantern
setblock 145 223 373 minecraft:jack_o_lantern
setblock 145 223 375 minecraft:jack_o_lantern
setblock 145 223 377 minecraft:jack_o_lantern
setblock 145 223 387 minecraft:jack_o_lantern
setblock 145 223 389 minecraft:jack_o_lantern
setblock 145 223 391 minecraft:jack_o_lantern
setblock 145 223 393 minecraft:jack_o_lantern
setblock 145 223 395 minecraft:jack_o_lantern
setblock 146 223 370 minecraft:jack_o_lantern
setblock 146 223 372 minecraft:jack_o_lantern
setblock 146 223 374 minecraft:jack_o_lantern
setblock 146 223 376 minecraft:jack_o_lantern
setblock 146 223 386 minecraft:jack_o_lantern
setblock 146 223 388 minecraft:jack_o_lantern
setblock 146 223 390 minecraft:jack_o_lantern
setblock 146 223 392 minecraft:jack_o_lantern
setblock 146 223 394 minecraft:jack_o_lantern
setblock 146 223 396 minecraft:jack_o_lantern
setblock 147 223 369 minecraft:jack_o_lantern
setblock 147 223 371 minecraft:jack_o_lantern
setblock 147 223 373 minecraft:jack_o_lantern
setblock 147 223 375 minecraft:jack_o_lantern
setblock 147 223 377 minecraft:jack_o_lantern
setblock 147 223 387 minecraft:jack_o_lantern
setblock 147 223 389 minecraft:jack_o_lantern
setblock 147 223 391 minecraft:jack_o_lantern
setblock 147 223 393 minecraft:jack_o_lantern
setblock 147 223 395 minecraft:jack_o_lantern
setblock 148 223 370 minecraft:jack_o_lantern
setblock 148 223 372 minecraft:jack_o_lantern
setblock 148 223 374 minecraft:jack_o_lantern
setblock 148 223 376 minecraft:jack_o_lantern
setblock 148 223 386 minecraft:jack_o_lantern
setblock 148 223 388 minecraft:jack_o_lantern
setblock 148 223 390 minecraft:jack_o_lantern
setblock 148 223 392 minecraft:jack_o_lantern
setblock 148 223 394 minecraft:jack_o_lantern
setblock 148 223 396 minecraft:jack_o_lantern
setblock 148 223 410 minecraft:white_concrete
setblock 149 223 369 minecraft:jack_o_lantern
fill 149 223 370 149 234 370 minecraft:white_concrete
setblock 149 223 371 minecraft:jack_o_lantern
setblock 149 223 373 minecraft:jack_o_lantern
setblock 149 223 375 minecraft:jack_o_lantern
setblock 149 223 377 minecraft:jack_o_lantern
setblock 149 223 387 minecraft:jack_o_lantern
setblock 149 223 389 minecraft:jack_o_lantern
setblock 149 223 391 minecraft:jack_o_lantern
setblock 149 223 393 minecraft:jack_o_lantern
setblock 149 223 395 minecraft:jack_o_lantern
setblock 150 223 386 minecraft:jack_o_lantern
setblock 150 223 388 minecraft:jack_o_lantern
setblock 150 223 390 minecraft:jack_o_lantern
setblock 150 223 392 minecraft:jack_o_lantern
setblock 150 223 394 minecraft:jack_o_lantern
setblock 150 223 396 minecraft:jack_o_lantern
setblock 151 223 387 minecraft:jack_o_lantern
setblock 151 223 389 minecraft:jack_o_lantern
setblock 151 223 391 minecraft:jack_o_lantern
setblock 151 223 393 minecraft:jack_o_lantern
setblock 151 223 395 minecraft:jack_o_lantern
setblock 152 223 370 minecraft:white_concrete
setblock 155 223 410 minecraft:white_concrete
setblock 159 223 370 minecraft:white_concrete
setblock 162 223 410 minecraft:white_concrete
setblock 166 223 370 minecraft:white_concrete
setblock 169 223 403 minecraft:jack_o_lantern
setblock 169 223 405 minecraft:jack_o_lantern
setblock 169 223 407 minecraft:jack_o_lantern
setblock 169 223 409 minecraft:jack_o_lantern
fill 169 223 410 169 240 410 minecraft:white_concrete
setblock 170 223 404 minecraft:jack_o_lantern
setblock 170 223 406 minecraft:jack_o_lantern
setblock 170 223 408 minecraft:jack_o_lantern
setblock 170 223 410 minecraft:jack_o_lantern
setblock 171 223 403 minecraft:jack_o_lantern
setblock 171 223 405 minecraft:jack_o_lantern
setblock 171 223 407 minecraft:jack_o_lantern
setblock 171 223 409 minecraft:jack_o_lantern
setblock 172 223 404 minecraft:jack_o_lantern
setblock 172 223 406 minecraft:jack_o_lantern
setblock 172 223 408 minecraft:jack_o_lantern
setblock 172 223 410 minecraft:jack_o_lantern
setblock 173 223 370 minecraft:white_concrete
setblock 173 223 403 minecraft:jack_o_lantern
setblock 173 223 405 minecraft:jack_o_lantern
setblock 173 223 407 minecraft:jack_o_lantern
setblock 173 223 409 minecraft:jack_o_lantern
setblock 174 223 404 minecraft:jack_o_lantern
setblock 174 223 406 minecraft:jack_o_lantern
setblock 174 223 408 minecraft:jack_o_lantern
setblock 174 223 410 minecraft:jack_o_lantern
setblock 175 223 403 minecraft:jack_o_lantern
setblock 175 223 405 minecraft:jack_o_lantern
setblock 175 223 407 minecraft:jack_o_lantern
setblock 175 223 409 minecraft:jack_o_lantern
setblock 176 223 404 minecraft:jack_o_lantern
setblock 176 223 406 minecraft:jack_o_lantern
setblock 176 223 408 minecraft:jack_o_lantern
setblock 176 223 410 minecraft:jack_o_lantern
setblock 177 223 403 minecraft:jack_o_lantern
setblock 177 223 405 minecraft:jack_o_lantern
setblock 177 223 407 minecraft:jack_o_lantern
setblock 177 223 409 minecraft:jack_o_lantern
setblock 178 223 404 minecraft:jack_o_lantern
setblock 178 223 406 minecraft:jack_o_lantern
setblock 178 223 408 minecraft:jack_o_lantern
setblock 178 223 410 minecraft:jack_o_lantern
setblock 179 223 403 minecraft:jack_o_lantern
setblock 179 223 405 minecraft:jack_o_lantern
setblock 179 223 407 minecraft:jack_o_lantern
setblock 179 223 409 minecraft:jack_o_lantern
setblock 180 223 370 minecraft:white_concrete
setblock 180 223 404 minecraft:jack_o_lantern
setblock 180 223 406 minecraft:jack_o_lantern
setblock 180 223 408 minecraft:jack_o_lantern
setblock 180 223 410 minecraft:jack_o_lantern
setblock 181 223 403 minecraft:jack_o_lantern
fill 181 223 404 181 239 404 minecraft:white_concrete
setblock 181 223 405 minecraft:jack_o_lantern
fill 181 223 406 181 239 406 minecraft:white_concrete
setblock 181 223 407 minecraft:jack_o_lantern
fill 181 223 408 181 239 408 minecraft:white_concrete
setblock 181 223 409 minecraft:jack_o_lantern
fill 181 223 410 181 240 410 minecraft:white_concrete
setblock 182 223 389 minecraft:white_concrete
setblock 182 223 396 minecraft:white_concrete
setblock 182 223 403 minecraft:white_concrete
fill 142 224 370 142 225 370 minecraft:white_concrete
fill 142 224 372 142 225 372 minecraft:white_concrete
fill 142 224 374 142 225 374 minecraft:white_concrete
fill 142 224 376 142 225 376 minecraft:white_concrete
fill 142 224 386 142 225 386 minecraft:white_concrete
fill 142 224 388 142 225 388 minecraft:white_concrete
fill 142 224 390 142 225 390 minecraft:white_concrete
fill 142 224 392 142 225 392 minecraft:white_concrete
fill 142 224 394 142 225 394 minecraft:white_concrete
fill 142 224 396 142 225 396 minecraft:white_concrete
fill 143 224 369 143 225 369 minecraft:purple_terracotta
fill 143 224 371 143 225 371 minecraft:white_concrete
fill 143 224 373 143 225 373 minecraft:white_concrete
fill 143 224 375 143 225 375 minecraft:white_concrete
fill 143 224 377 143 225 377 minecraft:white_concrete
fill 143 224 387 143 225 387 minecraft:white_concrete
fill 143 224 389 143 225 389 minecraft:white_concrete
fill 143 224 391 143 225 391 minecraft:white_concrete
fill 143 224 393 143 225 393 minecraft:white_concrete
fill 143 224 395 143 225 395 minecraft:white_concrete
fill 144 224 370 144 225 370 minecraft:white_concrete
fill 144 224 372 144 225 372 minecraft:white_concrete
fill 144 224 374 144 225 374 minecraft:white_concrete
fill 144 224 376 144 225 376 minecraft:white_concrete
fill 144 224 386 144 225 386 minecraft:white_concrete
fill 144 224 388 144 225 388 minecraft:white_concrete
fill 144 224 390 144 225 390 minecraft:white_concrete
fill 144 224 392 144 225 392 minecraft:white_concrete
fill 144 224 394 144 225 394 minecraft:white_concrete
fill 144 224 396 144 225 396 minecraft:white_concrete
fill 145 224 369 145 225 369 minecraft:purple_terracotta
fill 145 224 371 145 225 371 minecraft:white_concrete
fill 145 224 373 145 225 373 minecraft:white_concrete
fill 145 224 375 145 225 375 minecraft:white_concrete
fill 145 224 377 145 225 377 minecraft:white_concrete
fill 145 224 387 145 225 387 minecraft:white_concrete
fill 145 224 389 145 225 389 minecraft:white_concrete
fill 145 224 391 145 225 391 minecraft:white_concrete
fill 145 224 393 145 225 393 minecraft:white_concrete
fill 145 224 395 145 225 395 minecraft:white_concrete
fill 146 224 370 146 225 370 minecraft:white_concrete
fill 146 224 372 146 225 372 minecraft:white_concrete
fill 146 224 374 146 225 374 minecraft:white_concrete
fill 146 224 376 146 225 376 minecraft:white_concrete
fill 146 224 386 146 225 386 minecraft:white_concrete
fill 146 224 388 146 225 388 minecraft:white_concrete
fill 146 224 390 146 225 390 minecraft:white_concrete
fill 146 224 392 146 225 392 minecraft:white_concrete
fill 146 224 394 146 225 394 minecraft:white_concrete
fill 146 224 396 146 225 396 minecraft:white_concrete
fill 147 224 369 147 225 369 minecraft:purple_terracotta
fill 147 224 371 147 225 371 minecraft:white_concrete
fill 147 224 373 147 225 373 minecraft:white_concrete
fill 147 224 375 147 225 375 minecraft:white_concrete
fill 147 224 377 147 225 377 minecraft:white_concrete
fill 147 224 387 147 225 387 minecraft:white_concrete
fill 147 224 389 147 225 389 minecraft:white_concrete
fill 147 224 391 147 225 391 minecraft:white_concrete
fill 147 224 393 147 225 393 minecraft:white_concrete
fill 147 224 395 147 225 395 minecraft:white_concrete
fill 148 224 370 148 225 370 minecraft:white_concrete
fill 148 224 372 148 225 372 minecraft:white_concrete
fill 148 224 374 148 225 374 minecraft:white_concrete
fill 148 224 376 148 225 376 minecraft:white_concrete
fill 148 224 386 148 225 386 minecraft:white_concrete
fill 148 224 388 148 225 388 minecraft:white_concrete
fill 148 224 390 148 225 390 minecraft:white_concrete
fill 148 224 392 148 225 392 minecraft:white_concrete
fill 148 224 394 148 225 394 minecraft:white_concrete
fill 148 224 396 148 225 396 minecraft:white_concrete
fill 149 224 369 149 225 369 minecraft:purple_terracotta
fill 149 224 371 149 225 371 minecraft:white_concrete
fill 149 224 373 149 225 373 minecraft:white_concrete
fill 149 224 375 149 225 375 minecraft:white_concrete
fill 149 224 377 149 225 377 minecraft:white_concrete
fill 149 224 387 149 225 387 minecraft:white_concrete
fill 149 224 389 149 225 389 minecraft:white_concrete
fill 149 224 391 149 225 391 minecraft:white_concrete
fill 149 224 393 149 225 393 minecraft:white_concrete
fill 149 224 395 149 225 395 minecraft:white_concrete
fill 150 224 386 150 225 386 minecraft:white_concrete
fill 150 224 388 150 225 388 minecraft:white_concrete
fill 150 224 390 150 225 390 minecraft:white_concrete
fill 150 224 392 150 225 392 minecraft:white_concrete
fill 150 224 394 150 225 394 minecraft:white_concrete
fill 150 224 396 150 225 396 minecraft:white_concrete
fill 151 224 387 151 225 387 minecraft:white_concrete
fill 151 224 389 151 225 389 minecraft:white_concrete
fill 151 224 391 151 225 391 minecraft:white_concrete
fill 151 224 393 151 225 393 minecraft:white_concrete
fill 151 224 395 151 225 395 minecraft:white_concrete
fill 169 224 403 169 225 403 minecraft:white_concrete
fill 169 224 405 169 225 405 minecraft:white_concrete
fill 169 224 407 169 225 407 minecraft:white_concrete
fill 169 224 409 169 225 409 minecraft:white_concrete
fill 170 224 404 170 225 404 minecraft:white_concrete
fill 170 224 406 170 225 406 minecraft:white_concrete
fill 170 224 408 170 225 408 minecraft:white_concrete
fill 170 224 410 170 225 410 minecraft:white_concrete
fill 171 224 403 171 225 403 minecraft:white_concrete
fill 171 224 405 171 225 405 minecraft:white_concrete
fill 171 224 407 171 225 407 minecraft:white_concrete
fill 171 224 409 171 225 409 minecraft:white_concrete
fill 172 224 404 172 225 404 minecraft:white_concrete
fill 172 224 406 172 225 406 minecraft:white_concrete
fill 172 224 408 172 225 408 minecraft:white_concrete
fill 172 224 410 172 225 410 minecraft:white_concrete
fill 173 224 403 173 225 403 minecraft:white_concrete
fill 173 224 405 173 225 405 minecraft:white_concrete
fill 173 224 407 173 225 407 minecraft:white_concrete
fill 173 224 409 173 225 409 minecraft:white_concrete
fill 174 224 404 174 225 404 minecraft:white_concrete
fill 174 224 406 174 225 406 minecraft:white_concrete
fill 174 224 408 174 225 408 minecraft:white_concrete
fill 174 224 410 174 225 410 minecraft:white_concrete
fill 175 224 403 175 225 403 minecraft:white_concrete
fill 175 224 405 175 225 405 minecraft:white_concrete
fill 175 224 407 175 225 407 minecraft:white_concrete
fill 175 224 409 175 225 409 minecraft:white_concrete
fill 176 224 404 176 225 404 minecraft:white_concrete
fill 176 224 406 176 225 406 minecraft:white_concrete
fill 176 224 408 176 225 408 minecraft:white_concrete
fill 176 224 410 176 225 410 minecraft:white_concrete
fill 177 224 403 177 225 403 minecraft:white_concrete
fill 177 224 405 177 225 405 minecraft:white_concrete
fill 177 224 407 177 225 407 minecraft:white_concrete
fill 177 224 409 177 225 409 minecraft:white_concrete
fill 178 224 404 178 225 404 minecraft:white_concrete
fill 178 224 406 178 225 406 minecraft:white_concrete
fill 178 224 408 178 225 408 minecraft:white_concrete
fill 178 224 410 178 225 410 minecraft:white_concrete
fill 179 224 403 179 225 403 minecraft:white_concrete
fill 179 224 405 179 225 405 minecraft:white_concrete
fill 179 224 407 179 225 407 minecraft:white_concrete
fill 179 224 409 179 225 409 minecraft:white_concrete
fill 180 224 404 180 225 404 minecraft:white_concrete
fill 180 224 406 180 225 406 minecraft:white_concrete
fill 180 224 408 180 225 408 minecraft:white_concrete
fill 180 224 410 180 225 410 minecraft:white_concrete
fill 181 224 403 181 225 403 minecraft:white_concrete
fill 181 224 405 181 225 405 minecraft:white_concrete
fill 181 224 407 181 225 407 minecraft:white_concrete
fill 181 224 409 181 225 409 minecraft:white_concrete
setblock 142 225 383 minecraft:white_concrete
setblock 142 225 397 minecraft:white_concrete
setblock 142 225 404 minecraft:white_concrete
setblock 143 225 410 minecraft:white_concrete
setblock 150 225 370 minecraft:white_concrete
setblock 150 225 410 minecraft:white_concrete
setblock 157 225 370 minecraft:white_concrete
setblock 157 225 410 minecraft:white_concrete
setblock 164 225 370 minecraft:white_concrete
setblock 164 225 410 minecraft:white_concrete
setblock 171 225 370 minecraft:white_concrete
setblock 178 225 370 minecraft:white_concrete
setblock 182 225 387 minecraft:white_concrete
setblock 182 225 394 minecraft:white_concrete
setblock 182 225 401 minecraft:white_concrete
setblock 182 225 408 minecraft:white_concrete
setblock 142 226 370 minecraft:jack_o_lantern
setblock 142 226 372 minecraft:jack_o_lantern
setblock 142 226 374 minecraft:jack_o_lantern
setblock 142 226 376 minecraft:jack_o_lantern
setblock 142 226 384 minecraft:white_concrete
setblock 142 226 386 minecraft:jack_o_lantern
setblock 142 226 388 minecraft:jack_o_lantern
setblock 142 226 390 minecraft:jack_o_lantern
setblock 142 226 392 minecraft:jack_o_lantern
setblock 142 226 394 minecraft:jack_o_lantern
setblock 142 226 396 minecraft:jack_o_lantern
setblock 142 226 398 minecraft:white_concrete
setblock 142 226 405 minecraft:white_concrete
setblock 143 226 369 minecraft:jack_o_lantern
setblock 143 226 371 minecraft:jack_o_lantern
setblock 143 226 373 minecraft:jack_o_lantern
setblock 143 226 375 minecraft:jack_o_lantern
setblock 143 226 377 minecraft:jack_o_lantern
setblock 143 226 387 minecraft:jack_o_lantern
setblock 143 226 389 minecraft:jack_o_lantern
setblock 143 226 391 minecraft:jack_o_lantern
setblock 143 226 393 minecraft:jack_o_lantern
setblock 143 226 395 minecraft:jack_o_lantern
setblock 144 226 370 minecraft:jack_o_lantern
setblock 144 226 372 minecraft:jack_o_lantern
setblock 144 226 374 minecraft:jack_o_lantern
setblock 144 226 376 minecraft:jack_o_lantern
setblock 144 226 386 minecraft:jack_o_lantern
setblock 144 226 388 minecraft:jack_o_lantern
setblock 144 226 390 minecraft:jack_o_lantern
setblock 144 226 392 minecraft:jack_o_lantern
setblock 144 226 394 minecraft:jack_o_lantern
setblock 144 226 396 minecraft:jack_o_lantern
setblock 144 226 410 minecraft:white_concrete
setblock 145 226 369 minecraft:jack_o_lantern
setblock 145 226 371 minecraft:jack_o_lantern
setblock 145 226 373 minecraft:jack_o_lantern
setblock 145 226 375 minecraft:jack_o_lantern
setblock 145 226 377 minecraft:jack_o_lantern
setblock 145 226 387 minecraft:jack_o_lantern
setblock 145 226 389 minecraft:jack_o_lantern
setblock 145 226 391 minecraft:jack_o_lantern
setblock 145 226 393 minecraft:jack_o_lantern
setblock 145 226 395 minecraft:jack_o_lantern
setblock 146 226 370 minecraft:jack_o_lantern
setblock 146 226 372 minecraft:jack_o_lantern
setblock 146 226 374 minecraft:jack_o_lantern
setblock 146 226 376 minecraft:jack_o_lantern
setblock 146 226 386 minecraft:jack_o_lantern
setblock 146 226 388 minecraft:jack_o_lantern
setblock 146 226 390 minecraft:jack_o_lantern
setblock 146 226 392 minecraft:jack_o_lantern
setblock 146 226 394 minecraft:jack_o_lantern
setblock 146 226 396 minecraft:jack_o_lantern
setblock 147 226 369 minecraft:jack_o_lantern
setblock 147 226 371 minecraft:jack_o_lantern
setblock 147 226 373 minecraft:jack_o_lantern
setblock 147 226 375 minecraft:jack_o_lantern
setblock 147 226 377 minecraft:jack_o_lantern
setblock 147 226 387 minecraft:jack_o_lantern
setblock 147 226 389 minecraft:jack_o_lantern
setblock 147 226 391 minecraft:jack_o_lantern
setblock 147 226 393 minecraft:jack_o_lantern
setblock 147 226 395 minecraft:jack_o_lantern
setblock 148 226 370 minecraft:jack_o_lantern
setblock 148 226 372 minecraft:jack_o_lantern
setblock 148 226 374 minecraft:jack_o_lantern
setblock 148 226 376 minecraft:jack_o_lantern
setblock 148 226 386 minecraft:jack_o_lantern
setblock 148 226 388 minecraft:jack_o_lantern
setblock 148 226 390 minecraft:jack_o_lantern
setblock 148 226 392 minecraft:jack_o_lantern
setblock 148 226 394 minecraft:jack_o_lantern
setblock 148 226 396 minecraft:jack_o_lantern
setblock 149 226 369 minecraft:jack_o_lantern
setblock 149 226 371 minecraft:jack_o_lantern
setblock 149 226 373 minecraft:jack_o_lantern
setblock 149 226 375 minecraft:jack_o_lantern
setblock 149 226 377 minecraft:jack_o_lantern
setblock 149 226 387 minecraft:jack_o_lantern
setblock 149 226 389 minecraft:jack_o_lantern
setblock 149 226 391 minecraft:jack_o_lantern
setblock 149 226 393 minecraft:jack_o_lantern
setblock 149 226 395 minecraft:jack_o_lantern
setblock 150 226 386 minecraft:jack_o_lantern
setblock 150 226 388 minecraft:jack_o_lantern
setblock 150 226 390 minecraft:jack_o_lantern
setblock 150 226 392 minecraft:jack_o_lantern
setblock 150 226 394 minecraft:jack_o_lantern
setblock 150 226 396 minecraft:jack_o_lantern
setblock 151 226 387 minecraft:jack_o_lantern
setblock 151 226 389 minecraft:jack_o_lantern
setblock 151 226 391 minecraft:jack_o_lantern
setblock 151 226 393 minecraft:jack_o_lantern
setblock 151 226 395 minecraft:jack_o_lantern
setblock 151 226 410 minecraft:white_concrete
setblock 156 226 370 minecraft:white_concrete
setblock 158 226 410 minecraft:white_concrete
setblock 163 226 370 minecraft:white_concrete
setblock 165 226 410 minecraft:white_concrete
setblock 169 226 403 minecraft:jack_o_lantern
setblock 169 226 405 minecraft:jack_o_lantern
setblock 169 226 407 minecraft:jack_o_lantern
setblock 169 226 409 minecraft:jack_o_lantern
setblock 170 226 370 minecraft:white_concrete
setblock 170 226 404 minecraft:jack_o_lantern
setblock 170 226 406 minecraft:jack_o_lantern
setblock 170 226 408 minecraft:jack_o_lantern
setblock 170 226 410 minecraft:jack_o_lantern
setblock 171 226 403 minecraft:jack_o_lantern
setblock 171 226 405 minecraft:jack_o_lantern
setblock 171 226 407 minecraft:jack_o_lantern
setblock 171 226 409 minecraft:jack_o_lantern
setblock 172 226 404 minecraft:jack_o_lantern
setblock 172 226 406 minecraft:jack_o_lantern
setblock 172 226 408 minecraft:jack_o_lantern
setblock 172 226 410 minecraft:jack_o_lantern
setblock 173 226 403 minecraft:jack_o_lantern
setblock 173 226 405 minecraft:jack_o_lantern
setblock 173 226 407 minecraft:jack_o_lantern
setblock 173 226 409 minecraft:jack_o_lantern
setblock 174 226 404 minecraft:jack_o_lantern
setblock 174 226 406 minecraft:jack_o_lantern
setblock 174 226 408 minecraft:jack_o_lantern
setblock 174 226 410 minecraft:jack_o_lantern
setblock 175 226 403 minecraft:jack_o_lantern
setblock 175 226 405 minecraft:jack_o_lantern
setblock 175 226 407 minecraft:jack_o_lantern
setblock 175 226 409 minecraft:jack_o_lantern
setblock 176 226 404 minecraft:jack_o_lantern
setblock 176 226 406 minecraft:jack_o_lantern
setblock 176 226 408 minecraft:jack_o_lantern
setblock 176 226 410 minecraft:jack_o_lantern
setblock 177 226 370 minecraft:white_concrete
setblock 177 226 403 minecraft:jack_o_lantern
setblock 177 226 405 minecraft:jack_o_lantern
setblock 177 226 407 minecraft:jack_o_lantern
setblock 177 226 409 minecraft:jack_o_lantern
setblock 178 226 404 minecraft:jack_o_lantern
setblock 178 226 406 minecraft:jack_o_lantern
setblock 178 226 408 minecraft:jack_o_lantern
setblock 178 226 410 minecraft:jack_o_lantern
setblock 179 226 403 minecraft:jack_o_lantern
setblock 179 226 405 minecraft:jack_o_lantern
setblock 179 226 407 minecraft:jack_o_lantern
setblock 179 226 409 minecraft:jack_o_lantern
setblock 180 226 404 minecraft:jack_o_lantern
setblock 180 226 406 minecraft:jack_o_lantern
setblock 180 226 408 minecraft:jack_o_lantern
setblock 180 226 410 minecraft:jack_o_lantern
setblock 181 226 403 minecraft:jack_o_lantern
setblock 181 226 405 minecraft:jack_o_lantern
setblock 181 226 407 minecraft:jack_o_lantern
setblock 181 226 409 minecraft:jack_o_lantern
setblock 182 226 372 minecraft:white_concrete
setblock 182 226 386 minecraft:white_concrete
setblock 182 226 393 minecraft:white_concrete
setblock 182 226 400 minecraft:white_concrete
setblock 182 226 407 minecraft:white_concrete
fill 142 227 370 142 228 370 minecraft:white_concrete
fill 142 227 372 142 228 372 minecraft:white_concrete
fill 142 227 374 142 228 374 minecraft:white_concrete
fill 142 227 376 142 228 376 minecraft:white_concrete
setblock 142 227 378 minecraft:white_concrete
fill 142 227 385 142 227 386 minecraft:white_concrete
fill 142 227 388 142 228 388 minecraft:white_concrete
fill 142 227 390 142 228 390 minecraft:white_concrete
fill 142 227 392 142 228 392 minecraft:white_concrete
fill 142 227 394 142 228 394 minecraft:white_concrete
fill 142 227 396 142 228 396 minecraft:white_concrete
setblock 142 227 399 minecraft:white_concrete
setblock 142 227 406 minecraft:white_concrete
fill 143 227 369 143 228 369 minecraft:purple_terracotta
fill 143 227 371 143 228 371 minecraft:white_concrete
fill 143 227 373 143 228 373 minecraft:white_concrete
fill 143 227 375 143 228 375 minecraft:white_concrete
fill 143 227 377 143 228 377 minecraft:white_concrete
fill 143 227 387 143 228 387 minecraft:white_concrete
fill 143 227 389 143 228 389 minecraft:white_concrete
fill 143 227 391 143 228 391 minecraft:white_concrete
fill 143 227 393 143 228 393 minecraft:white_concrete
fill 143 227 395 143 228 395 minecraft:white_concrete
fill 144 227 370 144 228 370 minecraft:white_concrete
fill 144 227 372 144 228 372 minecraft:white_concrete
fill 144 227 374 144 228 374 minecraft:white_concrete
fill 144 227 376 144 228 376 minecraft:white_concrete
setblock 144 227 380 minecraft:light[level=14]
fill 144 227 386 144 228 386 minecraft:white_concrete
fill 144 227 388 144 228 388 minecraft:white_concrete
fill 144 227 390 144 228 390 minecraft:white_concrete
fill 144 227 392 144 228 392 minecraft:white_concrete
fill 144 227 394 144 228 394 minecraft:white_concrete
fill 144 227 396 144 228 396 minecraft:white_concrete
setblock 144 227 404 minecraft:light[level=14]
fill 145 227 369 145 228 369 minecraft:purple_terracotta
fill 145 227 371 145 228 371 minecraft:white_concrete
fill 145 227 373 145 228 373 minecraft:white_concrete
fill 145 227 375 145 228 375 minecraft:white_concrete
fill 145 227 377 145 228 377 minecraft:white_concrete
fill 145 227 387 145 228 387 minecraft:white_concrete
fill 145 227 389 145 228 389 minecraft:white_concrete
fill 145 227 391 145 228 391 minecraft:white_concrete
fill 145 227 393 145 228 393 minecraft:white_concrete
fill 145 227 395 145 228 395 minecraft:white_concrete
setblock 145 227 410 minecraft:white_concrete
fill 146 227 370 146 228 370 minecraft:white_concrete
fill 146 227 372 146 228 372 minecraft:white_concrete
fill 146 227 374 146 228 374 minecraft:white_concrete
fill 146 227 376 146 228 376 minecraft:white_concrete
fill 146 227 386 146 228 386 minecraft:white_concrete
fill 146 227 388 146 228 388 minecraft:white_concrete
fill 146 227 390 146 228 390 minecraft:white_concrete
fill 146 227 392 146 228 392 minecraft:white_concrete
fill 146 227 394 146 228 394 minecraft:white_concrete
fill 146 227 396 146 228 396 minecraft:white_concrete
fill 147 227 369 147 228 369 minecraft:purple_terracotta
fill 147 227 371 147 228 371 minecraft:white_concrete
fill 147 227 373 147 228 373 minecraft:white_concrete
fill 147 227 375 147 228 375 minecraft:white_concrete
fill 147 227 377 147 228 377 minecraft:white_concrete
fill 147 227 387 147 228 387 minecraft:white_concrete
fill 147 227 389 147 228 389 minecraft:white_concrete
fill 147 227 391 147 228 391 minecraft:white_concrete
fill 147 227 393 147 228 393 minecraft:white_concrete
fill 147 227 395 147 228 395 minecraft:white_concrete
fill 148 227 370 148 228 370 minecraft:white_concrete
fill 148 227 372 148 228 372 minecraft:white_concrete
fill 148 227 374 148 228 374 minecraft:white_concrete
fill 148 227 376 148 228 376 minecraft:white_concrete
fill 148 227 386 148 228 386 minecraft:white_concrete
fill 148 227 388 148 228 388 minecraft:white_concrete
fill 148 227 390 148 228 390 minecraft:white_concrete
fill 148 227 392 148 228 392 minecraft:white_concrete
fill 148 227 394 148 228 394 minecraft:white_concrete
fill 148 227 396 148 228 396 minecraft:white_concrete
fill 149 227 369 149 228 369 minecraft:purple_terracotta
fill 149 227 371 149 228 371 minecraft:white_concrete
fill 149 227 373 149 228 373 minecraft:white_concrete
fill 149 227 375 149 228 375 minecraft:white_concrete
fill 149 227 377 149 228 377 minecraft:white_concrete
fill 149 227 387 149 228 387 minecraft:white_concrete
fill 149 227 389 149 228 389 minecraft:white_concrete
fill 149 227 391 149 228 391 minecraft:white_concrete
fill 149 227 393 149 228 393 minecraft:white_concrete
fill 149 227 395 149 228 395 minecraft:white_concrete
fill 150 227 386 150 228 386 minecraft:white_concrete
fill 150 227 388 150 228 388 minecraft:white_concrete
fill 150 227 390 150 228 390 minecraft:white_concrete
fill 150 227 392 150 228 392 minecraft:white_concrete
fill 150 227 394 150 228 394 minecraft:white_concrete
fill 150 227 396 150 228 396 minecraft:white_concrete
fill 151 227 387 151 228 387 minecraft:white_concrete
fill 151 227 389 151 228 389 minecraft:white_concrete
fill 151 227 391 151 228 391 minecraft:white_concrete
fill 151 227 393 151 228 393 minecraft:white_concrete
fill 151 227 395 151 228 395 minecraft:white_concrete
setblock 152 227 372 minecraft:light[level=14]
setblock 152 227 380 minecraft:light[level=14]
setblock 152 227 388 minecraft:light[level=14]
setblock 152 227 396 minecraft:light[level=14]
setblock 152 227 404 minecraft:light[level=14]
setblock 152 227 410 minecraft:white_concrete
setblock 155 227 370 minecraft:white_concrete
setblock 159 227 410 minecraft:white_concrete
setblock 160 227 372 minecraft:light[level=14]
setblock 160 227 380 minecraft:light[level=14]
setblock 160 227 388 minecraft:light[level=14]
setblock 160 227 396 minecraft:light[level=14]
setblock 160 227 404 minecraft:light[level=14]
setblock 162 227 370 minecraft:white_concrete
setblock 166 227 410 minecraft:white_concrete
setblock 168 227 372 minecraft:light[level=14]
setblock 168 227 380 minecraft:light[level=14]
setblock 168 227 388 minecraft:light[level=14]
setblock 168 227 396 minecraft:light[level=14]
setblock 168 227 404 minecraft:light[level=14]
setblock 169 227 370 minecraft:white_concrete
fill 169 227 403 169 228 403 minecraft:white_concrete
fill 169 227 405 169 228 405 minecraft:white_concrete
fill 169 227 407 169 228 407 minecraft:white_concrete
fill 169 227 409 169 228 409 minecraft:white_concrete
fill 170 227 404 170 228 404 minecraft:white_concrete
fill 170 227 406 170 228 406 minecraft:white_concrete
fill 170 227 408 170 228 408 minecraft:white_concrete
fill 170 227 410 170 228 410 minecraft:white_concrete
fill 171 227 403 171 228 403 minecraft:white_concrete
fill 171 227 405 171 228 405 minecraft:white_concrete
fill 171 227 407 171 228 407 minecraft:white_concrete
fill 171 227 409 171 228 409 minecraft:white_concrete
fill 172 227 404 172 228 404 minecraft:white_concrete
fill 172 227 406 172 228 406 minecraft:white_concrete
fill 172 227 408 172 228 408 minecraft:white_concrete
fill 172 227 410 172 228 410 minecraft:white_concrete
fill 173 227 403 173 228 403 minecraft:white_concrete
fill 173 227 405 173 228 405 minecraft:white_concrete
fill 173 227 407 173 228 407 minecraft:white_concrete
fill 173 227 409 173 228 409 minecraft:white_concrete
fill 174 227 404 174 228 404 minecraft:white_concrete
fill 174 227 406 174 228 406 minecraft:white_concrete
fill 174 227 408 174 228 408 minecraft:white_concrete
fill 174 227 410 174 228 410 minecraft:white_concrete
fill 175 227 403 175 228 403 minecraft:white_concrete
fill 175 227 405 175 228 405 minecraft:white_concrete
fill 175 227 407 175 228 407 minecraft:white_concrete
fill 175 227 409 175 228 409 minecraft:white_concrete
setblock 176 227 370 minecraft:white_concrete
setblock 176 227 372 minecraft:light[level=14]
setblock 176 227 388 minecraft:light[level=14]
setblock 176 227 396 minecraft:light[level=14]
fill 176 227 404 176 228 404 minecraft:white_concrete
fill 176 227 406 176 228 406 minecraft:white_concrete
fill 176 227 408 176 228 408 minecraft:white_concrete
fill 176 227 410 176 228 410 minecraft:white_concrete
fill 177 227 403 177 228 403 minecraft:white_concrete
fill 177 227 405 177 228 405 minecraft:white_concrete
fill 177 227 407 177 228 407 minecraft:white_concrete
fill 177 227 409 177 228 409 minecraft:white_concrete
fill 178 227 404 178 228 404 minecraft:white_concrete
fill 178 227 406 178 228 406 minecraft:white_concrete
fill 178 227 408 178 228 408 minecraft:white_concrete
fill 178 227 410 178 228 410 minecraft:white_concrete
fill 179 227 403 179 228 403 minecraft:white_concrete
fill 179 227 405 179 228 405 minecraft:white_concrete
fill 179 227 407 179 228 407 minecraft:white_concrete
fill 179 227 409 179 228 409 minecraft:white_concrete
fill 180 227 404 180 228 404 minecraft:white_concrete
fill 180 227 406 180 228 406 minecraft:white_concrete
fill 180 227 408 180 228 408 minecraft:white_concrete
fill 180 227 410 180 228 410 minecraft:white_concrete
fill 181 227 403 181 228 403 minecraft:white_concrete
fill 181 227 405 181 228 405 minecraft:white_concrete
fill 181 227 407 181 228 407 minecraft:white_concrete
fill 181 227 409 181 228 409 minecraft:white_concrete
setblock 182 227 371 minecraft:white_concrete
setblock 182 227 385 minecraft:white_concrete
setblock 182 227 392 minecraft:white_concrete
setblock 182 227 399 minecraft:white_concrete
setblock 182 227 406 minecraft:white_concrete
setblock 142 228 379 minecraft:white_concrete
setblock 142 228 386 minecraft:white_concrete
setblock 142 228 400 minecraft:white_concrete
setblock 142 228 407 minecraft:white_concrete
setblock 146 228 410 minecraft:white_concrete
setblock 153 228 410 minecraft:white_concrete
setblock 154 228 370 minecraft:white_concrete
setblock 160 228 410 minecraft:white_concrete
setblock 161 228 370 minecraft:white_concrete
setblock 167 228 410 minecraft:white_concrete
setblock 168 228 370 minecraft:white_concrete
setblock 175 228 370 minecraft:white_concrete
setblock 182 228 370 minecraft:white_concrete
setblock 182 228 384 minecraft:white_concrete
setblock 182 228 391 minecraft:white_concrete
setblock 182 228 398 minecraft:white_concrete
setblock 182 228 405 minecraft:white_concrete
setblock 142 229 370 minecraft:jack_o_lantern
setblock 142 229 372 minecraft:jack_o_lantern
setblock 142 229 374 minecraft:jack_o_lantern
setblock 142 229 376 minecraft:jack_o_lantern
fill 142 229 380 142 230 380 minecraft:white_concrete
setblock 142 229 386 minecraft:jack_o_lantern
setblock 142 229 388 minecraft:jack_o_lantern
setblock 142 229 390 minecraft:jack_o_lantern
setblock 142 229 392 minecraft:jack_o_lantern
setblock 142 229 394 minecraft:jack_o_lantern
setblock 142 229 396 minecraft:jack_o_lantern
fill 142 229 401 142 230 401 minecraft:white_concrete
fill 142 229 408 142 230 408 minecraft:white_concrete
setblock 143 229 369 minecraft:jack_o_lantern
setblock 143 229 371 minecraft:jack_o_lantern
setblock 143 229 373 minecraft:jack_o_lantern
setblock 143 229 375 minecraft:jack_o_lantern
setblock 143 229 377 minecraft:jack_o_lantern
setblock 143 229 387 minecraft:jack_o_lantern
setblock 143 229 389 minecraft:jack_o_lantern
setblock 143 229 391 minecraft:jack_o_lantern
setblock 143 229 393 minecraft:jack_o_lantern
setblock 143 229 395 minecraft:jack_o_lantern
setblock 144 229 370 minecraft:jack_o_lantern
setblock 144 229 372 minecraft:jack_o_lantern
setblock 144 229 374 minecraft:jack_o_lantern
setblock 144 229 376 minecraft:jack_o_lantern
setblock 144 229 386 minecraft:jack_o_lantern
setblock 144 229 388 minecraft:jack_o_lantern
setblock 144 229 390 minecraft:jack_o_lantern
setblock 144 229 392 minecraft:jack_o_lantern
setblock 144 229 394 minecraft:jack_o_lantern
setblock 144 229 396 minecraft:jack_o_lantern
setblock 145 229 369 minecraft:jack_o_lantern
setblock 145 229 371 minecraft:jack_o_lantern
setblock 145 229 373 minecraft:jack_o_lantern
setblock 145 229 375 minecraft:jack_o_lantern
setblock 145 229 377 minecraft:jack_o_lantern
setblock 145 229 387 minecraft:jack_o_lantern
setblock 145 229 389 minecraft:jack_o_lantern
setblock 145 229 391 minecraft:jack_o_lantern
setblock 145 229 393 minecraft:jack_o_lantern
setblock 145 229 395 minecraft:jack_o_lantern
setblock 146 229 370 minecraft:jack_o_lantern
setblock 146 229 372 minecraft:jack_o_lantern
setblock 146 229 374 minecraft:jack_o_lantern
setblock 146 229 376 minecraft:jack_o_lantern
setblock 146 229 386 minecraft:jack_o_lantern
setblock 146 229 388 minecraft:jack_o_lantern
setblock 146 229 390 minecraft:jack_o_lantern
setblock 146 229 392 minecraft:jack_o_lantern
setblock 146 229 394 minecraft:jack_o_lantern
setblock 146 229 396 minecraft:jack_o_lantern
setblock 147 229 369 minecraft:jack_o_lantern
setblock 147 229 371 minecraft:jack_o_lantern
setblock 147 229 373 minecraft:jack_o_lantern
setblock 147 229 375 minecraft:jack_o_lantern
setblock 147 229 377 minecraft:jack_o_lantern
setblock 147 229 387 minecraft:jack_o_lantern
setblock 147 229 389 minecraft:jack_o_lantern
setblock 147 229 391 minecraft:jack_o_lantern
setblock 147 229 393 minecraft:jack_o_lantern
setblock 147 229 395 minecraft:jack_o_lantern
fill 147 229 410 147 230 410 minecraft:white_concrete
setblock 148 229 370 minecraft:jack_o_lantern
setblock 148 229 372 minecraft:jack_o_lantern
setblock 148 229 374 minecraft:jack_o_lantern
setblock 148 229 376 minecraft:jack_o_lantern
setblock 148 229 386 minecraft:jack_o_lantern
setblock 148 229 388 minecraft:jack_o_lantern
setblock 148 229 390 minecraft:jack_o_lantern
setblock 148 229 392 minecraft:jack_o_lantern
setblock 148 229 394 minecraft:jack_o_lantern
setblock 148 229 396 minecraft:jack_o_lantern
setblock 149 229 369 minecraft:jack_o_lantern
setblock 149 229 371 minecraft:jack_o_lantern
setblock 149 229 373 minecraft:jack_o_lantern
setblock 149 229 375 minecraft:jack_o_lantern
setblock 149 229 377 minecraft:jack_o_lantern
setblock 149 229 387 minecraft:jack_o_lantern
setblock 149 229 389 minecraft:jack_o_lantern
setblock 149 229 391 minecraft:jack_o_lantern
setblock 149 229 393 minecraft:jack_o_lantern
setblock 149 229 395 minecraft:jack_o_lantern
setblock 150 229 386 minecraft:jack_o_lantern
setblock 150 229 388 minecraft:jack_o_lantern
setblock 150 229 390 minecraft:jack_o_lantern
setblock 150 229 392 minecraft:jack_o_lantern
setblock 150 229 394 minecraft:jack_o_lantern
setblock 150 229 396 minecraft:jack_o_lantern
setblock 151 229 387 minecraft:jack_o_lantern
setblock 151 229 389 minecraft:jack_o_lantern
setblock 151 229 391 minecraft:jack_o_lantern
setblock 151 229 393 minecraft:jack_o_lantern
setblock 151 229 395 minecraft:jack_o_lantern
fill 153 229 370 153 230 370 minecraft:white_concrete
fill 154 229 410 154 230 410 minecraft:white_concrete
fill 160 229 370 160 230 370 minecraft:white_concrete
fill 161 229 410 161 230 410 minecraft:white_concrete
fill 167 229 370 167 230 370 minecraft:white_concrete
fill 168 229 410 168 230 410 minecraft:white_concrete
setblock 169 229 403 minecraft:jack_o_lantern
setblock 169 229 405 minecraft:jack_o_lantern
setblock 169 229 407 minecraft:jack_o_lantern
setblock 169 229 409 minecraft:jack_o_lantern
setblock 170 229 404 minecraft:jack_o_lantern
setblock 170 229 406 minecraft:jack_o_lantern
setblock 170 229 408 minecraft:jack_o_lantern
setblock 170 229 410 minecraft:jack_o_lantern
setblock 171 229 403 minecraft:jack_o_lantern
setblock 171 229 405 minecraft:jack_o_lantern
setblock 171 229 407 minecraft:jack_o_lantern
setblock 171 229 409 minecraft:jack_o_lantern
setblock 172 229 404 minecraft:jack_o_lantern
setblock 172 229 406 minecraft:jack_o_lantern
setblock 172 229 408 minecraft:jack_o_lantern
setblock 172 229 410 minecraft:jack_o_lantern
setblock 173 229 403 minecraft:jack_o_lantern
setblock 173 229 405 minecraft:jack_o_lantern
setblock 173 229 407 minecraft:jack_o_lantern
setblock 173 229 409 minecraft:jack_o_lantern
fill 174 229 370 174 230 370 minecraft:white_concrete
setblock 174 229 404 minecraft:jack_o_lantern
setblock 174 229 406 minecraft:jack_o_lantern
setblock 174 229 408 minecraft:jack_o_lantern
setblock 174 229 410 minecraft:jack_o_lantern
setblock 175 229 403 minecraft:jack_o_lantern
setblock 175 229 405 minecraft:jack_o_lantern
setblock 175 229 407 minecraft:jack_o_lantern
setblock 175 229 409 minecraft:jack_o_lantern
setblock 176 229 404 minecraft:jack_o_lantern
setblock 176 229 406 minecraft:jack_o_lantern
setblock 176 229 408 minecraft:jack_o_lantern
setblock 176 229 410 minecraft:jack_o_lantern
setblock 177 229 403 minecraft:jack_o_lantern
setblock 177 229 405 minecraft:jack_o_lantern
setblock 177 229 407 minecraft:jack_o_lantern
setblock 177 229 409 minecraft:jack_o_lantern
setblock 178 229 404 minecraft:jack_o_lantern
setblock 178 229 406 minecraft:jack_o_lantern
setblock 178 229 408 minecraft:jack_o_lantern
setblock 178 229 410 minecraft:jack_o_lantern
setblock 179 229 403 minecraft:jack_o_lantern
setblock 179 229 405 minecraft:jack_o_lantern
setblock 179 229 407 minecraft:jack_o_lantern
setblock 179 229 409 minecraft:jack_o_lantern
setblock 180 229 404 minecraft:jack_o_lantern
setblock 180 229 406 minecraft:jack_o_lantern
setblock 180 229 408 minecraft:jack_o_lantern
setblock 180 229 410 minecraft:jack_o_lantern
fill 181 229 370 181 230 370 minecraft:white_concrete
setblock 181 229 403 minecraft:jack_o_lantern
setblock 181 229 405 minecraft:jack_o_lantern
setblock 181 229 407 minecraft:jack_o_lantern
setblock 181 229 409 minecraft:jack_o_lantern
fill 182 229 390 182 230 390 minecraft:white_concrete
fill 182 229 397 182 230 397 minecraft:white_concrete
fill 182 229 404 182 230 404 minecraft:white_concrete
fill 182 229 410 182 230 410 minecraft:white_concrete
fill 142 230 370 142 231 370 minecraft:white_concrete
fill 142 230 372 142 231 372 minecraft:white_concrete
fill 142 230 374 142 231 374 minecraft:white_concrete
fill 142 230 376 142 231 376 minecraft:white_concrete
fill 142 230 378 142 230 379 minecraft:white_concrete
setblock 142 230 381 minecraft:white_concrete
fill 142 230 383 142 230 386 minecraft:white_concrete
fill 142 230 388 142 231 388 minecraft:white_concrete
fill 142 230 390 142 231 390 minecraft:white_concrete
fill 142 230 392 142 231 392 minecraft:white_concrete
fill 142 230 394 142 231 394 minecraft:white_concrete
fill 142 230 396 142 230 400 minecraft:white_concrete
setblock 142 230 402 minecraft:white_concrete
fill 142 230 404 142 230 407 minecraft:white_concrete
setblock 142 230 409 minecraft:white_concrete
fill 143 230 369 143 231 369 minecraft:purple_terracotta
fill 143 230 371 143 231 371 minecraft:white_concrete
fill 143 230 373 143 231 373 minecraft:white_concrete
fill 143 230 375 143 231 375 minecraft:white_concrete
fill 143 230 377 143 231 377 minecraft:white_concrete
fill 143 230 387 143 231 387 minecraft:white_concrete
fill 143 230 389 143 231 389 minecraft:white_concrete
fill 143 230 391 143 231 391 minecraft:white_concrete
fill 143 230 393 143 231 393 minecraft:white_concrete
fill 143 230 395 143 231 395 minecraft:white_concrete
fill 143 230 410 146 230 410 minecraft:white_concrete
fill 144 230 370 144 231 370 minecraft:white_concrete
fill 144 230 372 144 231 372 minecraft:white_concrete
fill 144 230 374 144 231 374 minecraft:white_concrete
fill 144 230 376 144 231 376 minecraft:white_concrete
fill 144 230 386 144 231 386 minecraft:white_concrete
fill 144 230 388 144 231 388 minecraft:white_concrete
fill 144 230 390 144 231 390 minecraft:white_concrete
fill 144 230 392 144 231 392 minecraft:white_concrete
fill 144 230 394 144 231 394 minecraft:white_concrete
fill 144 230 396 144 231 396 minecraft:white_concrete
fill 145 230 369 145 231 369 minecraft:purple_terracotta
fill 145 230 371 145 231 371 minecraft:white_concrete
fill 145 230 373 145 231 373 minecraft:white_concrete
fill 145 230 375 145 231 375 minecraft:white_concrete
fill 145 230 377 145 231 377 minecraft:white_concrete
fill 145 230 387 145 231 387 minecraft:white_concrete
fill 145 230 389 145 231 389 minecraft:white_concrete
fill 145 230 391 145 231 391 minecraft:white_concrete
fill 145 230 393 145 231 393 minecraft:white_concrete
fill 145 230 395 145 231 395 minecraft:white_concrete
fill 146 230 370 146 231 370 minecraft:white_concrete
fill 146 230 372 146 231 372 minecraft:white_concrete
fill 146 230 374 146 231 374 minecraft:white_concrete
fill 146 230 376 146 231 376 minecraft:white_concrete
fill 146 230 386 146 231 386 minecraft:white_concrete
fill 146 230 388 146 231 388 minecraft:white_concrete
fill 146 230 390 146 231 390 minecraft:white_concrete
fill 146 230 392 146 231 392 minecraft:white_concrete
fill 146 230 394 146 231 394 minecraft:white_concrete
fill 146 230 396 146 231 396 minecraft:white_concrete
fill 147 230 369 147 231 369 minecraft:purple_terracotta
fill 147 230 371 147 231 371 minecraft:white_concrete
fill 147 230 373 147 231 373 minecraft:white_concrete
fill 147 230 375 147 231 375 minecraft:white_concrete
fill 147 230 377 147 231 377 minecraft:white_concrete
fill 147 230 387 147 231 387 minecraft:white_concrete
fill 147 230 389 147 231 389 minecraft:white_concrete
fill 147 230 391 147 231 391 minecraft:white_concrete
fill 147 230 393 147 231 393 minecraft:white_concrete
fill 147 230 395 147 231 395 minecraft:white_concrete
fill 148 230 370 148 231 370 minecraft:white_concrete
fill 148 230 372 148 231 372 minecraft:white_concrete
fill 148 230 374 148 231 374 minecraft:white_concrete
fill 148 230 376 148 231 376 minecraft:white_concrete
fill 148 230 386 148 231 386 minecraft:white_concrete
fill 148 230 388 148 231 388 minecraft:white_concrete
fill 148 230 390 148 231 390 minecraft:white_concrete
fill 148 230 392 148 231 392 minecraft:white_concrete
fill 148 230 394 148 231 394 minecraft:white_concrete
fill 148 230 396 148 231 396 minecraft:white_concrete
setblock 148 230 410 minecraft:white_concrete
fill 149 230 369 149 231 369 minecraft:purple_terracotta
fill 149 230 371 149 231 371 minecraft:white_concrete
fill 149 230 373 149 231 373 minecraft:white_concrete
fill 149 230 375 149 231 375 minecraft:white_concrete
fill 149 230 377 149 231 377 minecraft:white_concrete
fill 149 230 387 149 231 387 minecraft:white_concrete
fill 149 230 389 149 231 389 minecraft:white_concrete
fill 149 230 391 149 231 391 minecraft:white_concrete
fill 149 230 393 149 231 393 minecraft:white_concrete
fill 149 230 395 149 231 395 minecraft:white_concrete
setblock 150 230 370 minecraft:white_concrete
fill 150 230 386 150 231 386 minecraft:white_concrete
fill 150 230 388 150 231 388 minecraft:white_concrete
fill 150 230 390 150 231 390 minecraft:white_concrete
fill 150 230 392 150 231 392 minecraft:white_concrete
fill 150 230 394 150 231 394 minecraft:white_concrete
fill 150 230 396 150 231 396 minecraft:white_concrete
fill 150 230 410 153 230 410 minecraft:white_concrete
fill 151 230 387 151 231 387 minecraft:white_concrete
fill 151 230 389 151 231 389 minecraft:white_concrete
fill 151 230 391 151 231 391 minecraft:white_concrete
fill 151 230 393 151 231 393 minecraft:white_concrete
fill 151 230 395 151 231 395 minecraft:white_concrete
setblock 152 230 370 minecraft:white_concrete
fill 154 230 370 157 230 370 minecraft:white_concrete
setblock 155 230 410 minecraft:white_concrete
fill 157 230 410 160 230 410 minecraft:white_concrete
setblock 159 230 370 minecraft:white_concrete
fill 161 230 370 164 230 370 minecraft:white_concrete
setblock 162 230 410 minecraft:white_concrete
fill 164 230 410 167 230 410 minecraft:white_concrete
setblock 166 230 370 minecraft:white_concrete
fill 168 230 370 171 230 370 minecraft:white_concrete
fill 169 230 403 169 231 403 minecraft:white_concrete
fill 169 230 405 169 231 405 minecraft:white_concrete
fill 169 230 407 169 231 407 minecraft:white_concrete
fill 169 230 409 169 231 409 minecraft:white_concrete
fill 170 230 404 170 231 404 minecraft:white_concrete
fill 170 230 406 170 231 406 minecraft:white_concrete
fill 170 230 408 170 231 408 minecraft:white_concrete
fill 170 230 410 170 231 410 minecraft:white_concrete
fill 171 230 403 171 231 403 minecraft:white_concrete
fill 171 230 405 171 231 405 minecraft:white_concrete
fill 171 230 407 171 231 407 minecraft:white_concrete
fill 171 230 409 171 231 409 minecraft:white_concrete
fill 172 230 404 172 231 404 minecraft:white_concrete
fill 172 230 406 172 231 406 minecraft:white_concrete
fill 172 230 408 172 231 408 minecraft:white_concrete
fill 172 230 410 172 231 410 minecraft:white_concrete
setblock 173 230 370 minecraft:white_concrete
fill 173 230 403 173 231 403 minecraft:white_concrete
fill 173 230 405 173 231 405 minecraft:white_concrete
fill 173 230 407 173 231 407 minecraft:white_concrete
fill 173 230 409 173 231 409 minecraft:white_concrete
fill 174 230 404 174 231 404 minecraft:white_concrete
fill 174 230 406 174 231 406 minecraft:white_concrete
fill 174 230 408 174 231 408 minecraft:white_concrete
fill 174 230 410 174 231 410 minecraft:white_concrete
fill 175 230 370 178 230 370 minecraft:white_concrete
fill 175 230 403 175 231 403 minecraft:white_concrete
fill 175 230 405 175 231 405 minecraft:white_concrete
fill 175 230 407 175 231 407 minecraft:white_concrete
fill 175 230 409 175 231 409 minecraft:white_concrete
fill 176 230 404 176 231 404 minecraft:white_concrete
fill 176 230 406 176 231 406 minecraft:white_concrete
fill 176 230 408 176 231 408 minecraft:white_concrete
fill 176 230 410 176 231 410 minecraft:white_concrete
fill 177 230 403 177 231 403 minecraft:white_concrete
fill 177 230 405 177 231 405 minecraft:white_concrete
fill 177 230 407 177 231 407 minecraft:white_concrete
fill 177 230 409 177 231 409 minecraft:white_concrete
fill 178 230 404 178 231 404 minecraft:white_concrete
fill 178 230 406 178 231 406 minecraft:white_concrete
fill 178 230 408 178 231 408 minecraft:white_concrete
fill 178 230 410 178 231 410 minecraft:white_concrete
fill 179 230 403 179 231 403 minecraft:white_concrete
fill 179 230 405 179 231 405 minecraft:white_concrete
fill 179 230 407 179 231 407 minecraft:white_concrete
fill 179 230 409 179 231 409 minecraft:white_concrete
setblock 180 230 370 minecraft:white_concrete
fill 180 230 404 180 231 404 minecraft:white_concrete
fill 180 230 406 180 231 406 minecraft:white_concrete
fill 180 230 408 180 231 408 minecraft:white_concrete
fill 180 230 410 180 231 410 minecraft:white_concrete
fill 181 230 403 182 230 403 minecraft:white_concrete
fill 181 230 405 182 230 405 minecraft:white_concrete
fill 181 230 407 182 230 407 minecraft:white_concrete
fill 181 230 409 181 231 409 minecraft:white_concrete
fill 182 230 370 182 230 372 minecraft:white_concrete
fill 182 230 384 182 230 387 minecraft:white_concrete
setblock 182 230 389 minecraft:white_concrete
fill 182 230 391 182 230 394 minecraft:white_concrete
setblock 182 230 396 minecraft:white_concrete
fill 182 230 398 182 230 401 minecraft:white_concrete
setblock 182 230 406 minecraft:white_concrete
setblock 182 230 408 minecraft:white_concrete
setblock 142 231 386 minecraft:white_concrete
setblock 142 231 396 minecraft:white_concrete
setblock 181 231 403 minecraft:white_concrete
setblock 181 231 405 minecraft:white_concrete
setblock 181 231 407 minecraft:white_concrete
setblock 142 232 370 minecraft:jack_o_lantern
setblock 142 232 372 minecraft:jack_o_lantern
setblock 142 232 374 minecraft:jack_o_lantern
setblock 142 232 376 minecraft:jack_o_lantern
setblock 142 232 383 minecraft:white_concrete
setblock 142 232 386 minecraft:jack_o_lantern
setblock 142 232 388 minecraft:jack_o_lantern
setblock 142 232 390 minecraft:jack_o_lantern
setblock 142 232 392 minecraft:jack_o_lantern
setblock 142 232 394 minecraft:jack_o_lantern
setblock 142 232 396 minecraft:jack_o_lantern
setblock 142 232 397 minecraft:white_concrete
setblock 142 232 404 minecraft:white_concrete
setblock 143 232 369 minecraft:jack_o_lantern
setblock 143 232 371 minecraft:jack_o_lantern
setblock 143 232 373 minecraft:jack_o_lantern
setblock 143 232 375 minecraft:jack_o_lantern
setblock 143 232 377 minecraft:jack_o_lantern
setblock 143 232 387 minecraft:jack_o_lantern
setblock 143 232 389 minecraft:jack_o_lantern
setblock 143 232 391 minecraft:jack_o_lantern
setblock 143 232 393 minecraft:jack_o_lantern
setblock 143 232 395 minecraft:jack_o_lantern
setblock 143 232 410 minecraft:white_concrete
setblock 144 232 370 minecraft:jack_o_lantern
setblock 144 232 372 minecraft:jack_o_lantern
setblock 144 232 374 minecraft:jack_o_lantern
setblock 144 232 376 minecraft:jack_o_lantern
setblock 144 232 386 minecraft:jack_o_lantern
setblock 144 232 388 minecraft:jack_o_lantern
setblock 144 232 390 minecraft:jack_o_lantern
setblock 144 232 392 minecraft:jack_o_lantern
setblock 144 232 394 minecraft:jack_o_lantern
setblock 144 232 396 minecraft:jack_o_lantern
setblock 145 232 369 minecraft:jack_o_lantern
setblock 145 232 371 minecraft:jack_o_lantern
setblock 145 232 373 minecraft:jack_o_lantern
setblock 145 232 375 minecraft:jack_o_lantern
setblock 145 232 377 minecraft:jack_o_lantern
setblock 145 232 387 minecraft:jack_o_lantern
setblock 145 232 389 minecraft:jack_o_lantern
setblock 145 232 391 minecraft:jack_o_lantern
setblock 145 232 393 minecraft:jack_o_lantern
setblock 145 232 395 minecraft:jack_o_lantern
setblock 146 232 370 minecraft:jack_o_lantern
setblock 146 232 372 minecraft:jack_o_lantern
setblock 146 232 374 minecraft:jack_o_lantern
setblock 146 232 376 minecraft:jack_o_lantern
setblock 146 232 386 minecraft:jack_o_lantern
setblock 146 232 388 minecraft:jack_o_lantern
setblock 146 232 390 minecraft:jack_o_lantern
setblock 146 232 392 minecraft:jack_o_lantern
setblock 146 232 394 minecraft:jack_o_lantern
setblock 146 232 396 minecraft:jack_o_lantern
setblock 147 232 369 minecraft:jack_o_lantern
setblock 147 232 371 minecraft:jack_o_lantern
setblock 147 232 373 minecraft:jack_o_lantern
setblock 147 232 375 minecraft:jack_o_lantern
setblock 147 232 377 minecraft:jack_o_lantern
setblock 147 232 387 minecraft:jack_o_lantern
setblock 147 232 389 minecraft:jack_o_lantern
setblock 147 232 391 minecraft:jack_o_lantern
setblock 147 232 393 minecraft:jack_o_lantern
setblock 147 232 395 minecraft:jack_o_lantern
setblock 148 232 370 minecraft:jack_o_lantern
setblock 148 232 372 minecraft:jack_o_lantern
setblock 148 232 374 minecraft:jack_o_lantern
setblock 148 232 376 minecraft:jack_o_lantern
setblock 148 232 386 minecraft:jack_o_lantern
setblock 148 232 388 minecraft:jack_o_lantern
setblock 148 232 390 minecraft:jack_o_lantern
setblock 148 232 392 minecraft:jack_o_lantern
setblock 148 232 394 minecraft:jack_o_lantern
setblock 148 232 396 minecraft:jack_o_lantern
setblock 149 232 369 minecraft:jack_o_lantern
setblock 149 232 371 minecraft:jack_o_lantern
setblock 149 232 373 minecraft:jack_o_lantern
setblock 149 232 375 minecraft:jack_o_lantern
setblock 149 232 377 minecraft:jack_o_lantern
setblock 149 232 387 minecraft:jack_o_lantern
setblock 149 232 389 minecraft:jack_o_lantern
setblock 149 232 391 minecraft:jack_o_lantern
setblock 149 232 393 minecraft:jack_o_lantern
setblock 149 232 395 minecraft:jack_o_lantern
setblock 150 232 370 minecraft:white_concrete
setblock 150 232 386 minecraft:jack_o_lantern
setblock 150 232 388 minecraft:jack_o_lantern
setblock 150 232 390 minecraft:jack_o_lantern
setblock 150 232 392 minecraft:jack_o_lantern
setblock 150 232 394 minecraft:jack_o_lantern
setblock 150 232 396 minecraft:jack_o_lantern
setblock 150 232 410 minecraft:white_concrete
setblock 151 232 387 minecraft:jack_o_lantern
setblock 151 232 389 minecraft:jack_o_lantern
setblock 151 232 391 minecraft:jack_o_lantern
setblock 151 232 393 minecraft:jack_o_lantern
setblock 151 232 395 minecraft:jack_o_lantern
setblock 157 232 370 minecraft:white_concrete
setblock 157 232 410 minecraft:white_concrete
setblock 164 232 370 minecraft:white_concrete
setblock 164 232 410 minecraft:white_concrete
setblock 169 232 403 minecraft:jack_o_lantern
setblock 169 232 405 minecraft:jack_o_lantern
setblock 169 232 407 minecraft:jack_o_lantern
setblock 169 232 409 minecraft:jack_o_lantern
setblock 170 232 404 minecraft:jack_o_lantern
setblock 170 232 406 minecraft:jack_o_lantern
setblock 170 232 408 minecraft:jack_o_lantern
setblock 170 232 410 minecraft:jack_o_lantern
setblock 171 232 370 minecraft:white_concrete
setblock 171 232 403 minecraft:jack_o_lantern
setblock 171 232 405 minecraft:jack_o_lantern
setblock 171 232 407 minecraft:jack_o_lantern
setblock 171 232 409 minecraft:jack_o_lantern
setblock 172 232 404 minecraft:jack_o_lantern
setblock 172 232 406 minecraft:jack_o_lantern
setblock 172 232 408 minecraft:jack_o_lantern
setblock 172 232 410 minecraft:jack_o_lantern
setblock 173 232 403 minecraft:jack_o_lantern
setblock 173 232 405 minecraft:jack_o_lantern
setblock 173 232 407 minecraft:jack_o_lantern
setblock 173 232 409 minecraft:jack_o_lantern
setblock 174 232 404 minecraft:jack_o_lantern
setblock 174 232 406 minecraft:jack_o_lantern
setblock 174 232 408 minecraft:jack_o_lantern
setblock 174 232 410 minecraft:jack_o_lantern
setblock 175 232 403 minecraft:jack_o_lantern
setblock 175 232 405 minecraft:jack_o_lantern
setblock 175 232 407 minecraft:jack_o_lantern
setblock 175 232 409 minecraft:jack_o_lantern
setblock 176 232 404 minecraft:jack_o_lantern
setblock 176 232 406 minecraft:jack_o_lantern
setblock 176 232 408 minecraft:jack_o_lantern
setblock 176 232 410 minecraft:jack_o_lantern
setblock 177 232 403 minecraft:jack_o_lantern
setblock 177 232 405 minecraft:jack_o_lantern
setblock 177 232 407 minecraft:jack_o_lantern
setblock 177 232 409 minecraft:jack_o_lantern
setblock 178 232 370 minecraft:white_concrete
setblock 178 232 404 minecraft:jack_o_lantern
setblock 178 232 406 minecraft:jack_o_lantern
setblock 178 232 408 minecraft:jack_o_lantern
setblock 178 232 410 minecraft:jack_o_lantern
setblock 179 232 403 minecraft:jack_o_lantern
setblock 179 232 405 minecraft:jack_o_lantern
setblock 179 232 407 minecraft:jack_o_lantern
setblock 179 232 409 minecraft:jack_o_lantern
setblock 180 232 404 minecraft:jack_o_lantern
setblock 180 232 406 minecraft:jack_o_lantern
setblock 180 232 408 minecraft:jack_o_lantern
setblock 180 232 410 minecraft:jack_o_lantern
setblock 181 232 403 minecraft:jack_o_lantern
setblock 181 232 405 minecraft:jack_o_lantern
setblock 181 232 407 minecraft:jack_o_lantern
setblock 181 232 409 minecraft:jack_o_lantern
setblock 182 232 387 minecraft:white_concrete
setblock 182 232 394 minecraft:white_concrete
setblock 182 232 401 minecraft:white_concrete
setblock 182 232 408 minecraft:white_concrete
fill 142 233 370 142 234 370 minecraft:white_concrete
fill 142 233 372 142 235 372 minecraft:white_concrete
fill 142 233 374 142 234 374 minecraft:white_concrete
fill 142 233 376 142 234 376 minecraft:white_concrete
setblock 142 233 384 minecraft:white_concrete
fill 142 233 386 142 234 386 minecraft:white_concrete
fill 142 233 388 142 234 388 minecraft:white_concrete
fill 142 233 390 142 234 390 minecraft:white_concrete
fill 142 233 392 142 234 392 minecraft:white_concrete
fill 142 233 394 142 234 394 minecraft:white_concrete
fill 142 233 396 142 234 396 minecraft:white_concrete
setblock 142 233 398 minecraft:white_concrete
setblock 142 233 405 minecraft:white_concrete
fill 143 233 369 143 307 369 minecraft:purple_terracotta
fill 143 233 371 143 234 371 minecraft:white_concrete
fill 143 233 373 143 234 373 minecraft:white_concrete
fill 143 233 375 143 234 375 minecraft:white_concrete
fill 143 233 377 143 234 377 minecraft:white_concrete
fill 143 233 387 143 234 387 minecraft:white_concrete
fill 143 233 389 143 234 389 minecraft:white_concrete
fill 143 233 391 143 234 391 minecraft:white_concrete
fill 143 233 393 143 234 393 minecraft:white_concrete
fill 143 233 395 143 234 395 minecraft:white_concrete
fill 144 233 370 144 267 370 minecraft:white_concrete
fill 144 233 372 144 234 372 minecraft:white_concrete
fill 144 233 374 144 234 374 minecraft:white_concrete
fill 144 233 376 144 234 376 minecraft:white_concrete
fill 144 233 386 144 234 386 minecraft:white_concrete
fill 144 233 388 144 234 388 minecraft:white_concrete
fill 144 233 390 144 234 390 minecraft:white_concrete
fill 144 233 392 144 234 392 minecraft:white_concrete
fill 144 233 394 144 234 394 minecraft:white_concrete
fill 144 233 396 144 234 396 minecraft:white_concrete
setblock 144 233 410 minecraft:white_concrete
fill 145 233 369 145 307 369 minecraft:purple_terracotta
fill 145 233 371 145 234 371 minecraft:white_concrete
fill 145 233 373 145 234 373 minecraft:white_concrete
fill 145 233 375 145 234 375 minecraft:white_concrete
fill 145 233 377 145 234 377 minecraft:white_concrete
fill 145 233 387 145 234 387 minecraft:white_concrete
fill 145 233 389 145 234 389 minecraft:white_concrete
fill 145 233 391 145 234 391 minecraft:white_concrete
fill 145 233 393 145 234 393 minecraft:white_concrete
fill 145 233 395 145 234 395 minecraft:white_concrete
fill 146 233 370 146 234 370 minecraft:white_concrete
fill 146 233 372 146 234 372 minecraft:white_concrete
fill 146 233 374 146 234 374 minecraft:white_concrete
fill 146 233 376 146 234 376 minecraft:white_concrete
fill 146 233 386 146 234 386 minecraft:white_concrete
fill 146 233 388 146 234 388 minecraft:white_concrete
fill 146 233 390 146 234 390 minecraft:white_concrete
fill 146 233 392 146 234 392 minecraft:white_concrete
fill 146 233 394 146 234 394 minecraft:white_concrete
fill 146 233 396 146 234 396 minecraft:white_concrete
fill 147 233 369 147 307 369 minecraft:purple_terracotta
fill 147 233 371 147 234 371 minecraft:white_concrete
fill 147 233 373 147 234 373 minecraft:white_concrete
fill 147 233 375 147 234 375 minecraft:white_concrete
fill 147 233 377 147 234 377 minecraft:white_concrete
fill 147 233 387 147 234 387 minecraft:white_concrete
fill 147 233 389 147 234 389 minecraft:white_concrete
fill 147 233 391 147 234 391 minecraft:white_concrete
fill 147 233 393 147 234 393 minecraft:white_concrete
fill 147 233 395 147 234 395 minecraft:white_concrete
fill 148 233 370 148 234 370 minecraft:white_concrete
fill 148 233 372 148 234 372 minecraft:white_concrete
fill 148 233 374 148 234 374 minecraft:white_concrete
fill 148 233 376 148 234 376 minecraft:white_concrete
fill 148 233 386 148 234 386 minecraft:white_concrete
fill 148 233 388 148 234 388 minecraft:white_concrete
fill 148 233 390 148 234 390 minecraft:white_concrete
fill 148 233 392 148 234 392 minecraft:white_concrete
fill 148 233 394 148 234 394 minecraft:white_concrete
fill 148 233 396 148 234 396 minecraft:white_concrete
fill 149 233 369 149 307 369 minecraft:purple_terracotta
fill 149 233 371 149 234 371 minecraft:white_concrete
fill 149 233 373 149 234 373 minecraft:white_concrete
fill 149 233 375 149 234 375 minecraft:white_concrete
fill 149 233 377 149 234 377 minecraft:white_concrete
fill 149 233 387 149 234 387 minecraft:white_concrete
fill 149 233 389 149 234 389 minecraft:white_concrete
fill 149 233 391 149 234 391 minecraft:white_concrete
fill 149 233 393 149 234 393 minecraft:white_concrete
fill 149 233 395 149 234 395 minecraft:white_concrete
fill 150 233 386 150 234 386 minecraft:white_concrete
fill 150 233 388 150 234 388 minecraft:white_concrete
fill 150 233 390 150 234 390 minecraft:white_concrete
fill 150 233 392 150 234 392 minecraft:white_concrete
fill 150 233 394 150 234 394 minecraft:white_concrete
fill 150 233 396 150 234 396 minecraft:white_concrete
fill 151 233 387 151 234 387 minecraft:white_concrete
fill 151 233 389 151 234 389 minecraft:white_concrete
fill 151 233 391 151 234 391 minecraft:white_concrete
fill 151 233 393 151 234 393 minecraft:white_concrete
fill 151 233 395 151 234 395 minecraft:white_concrete
setblock 151 233 410 minecraft:white_concrete
setblock 156 233 370 minecraft:white_concrete
setblock 158 233 410 minecraft:white_concrete
setblock 163 233 370 minecraft:white_concrete
setblock 165 233 410 minecraft:white_concrete
fill 169 233 403 169 234 403 minecraft:white_concrete
fill 169 233 405 169 234 405 minecraft:white_concrete
fill 169 233 407 169 234 407 minecraft:white_concrete
fill 169 233 409 169 234 409 minecraft:white_concrete
setblock 170 233 370 minecraft:white_concrete
fill 170 233 404 170 234 404 minecraft:white_concrete
fill 170 233 406 170 234 406 minecraft:white_concrete
fill 170 233 408 170 234 408 minecraft:white_concrete
fill 170 233 410 170 234 410 minecraft:white_concrete
fill 171 233 403 171 234 403 minecraft:white_concrete
fill 171 233 405 171 234 405 minecraft:white_concrete
fill 171 233 407 171 234 407 minecraft:white_concrete
fill 171 233 409 171 234 409 minecraft:white_concrete
fill 172 233 404 172 234 404 minecraft:white_concrete
fill 172 233 406 172 234 406 minecraft:white_concrete
fill 172 233 408 172 234 408 minecraft:white_concrete
fill 172 233 410 172 234 410 minecraft:white_concrete
fill 173 233 403 173 234 403 minecraft:white_concrete
fill 173 233 405 173 234 405 minecraft:white_concrete
fill 173 233 407 173 234 407 minecraft:white_concrete
fill 173 233 409 173 234 409 minecraft:white_concrete
fill 174 233 404 174 234 404 minecraft:white_concrete
fill 174 233 406 174 234 406 minecraft:white_concrete
fill 174 233 408 174 234 408 minecraft:white_concrete
fill 174 233 410 174 234 410 minecraft:white_concrete
fill 175 233 403 175 234 403 minecraft:white_concrete
fill 175 233 405 175 234 405 minecraft:white_concrete
fill 175 233 407 175 234 407 minecraft:white_concrete
fill 175 233 409 175 234 409 minecraft:white_concrete
fill 176 233 404 176 234 404 minecraft:white_concrete
fill 176 233 406 176 234 406 minecraft:white_concrete
fill 176 233 408 176 234 408 minecraft:white_concrete
fill 176 233 410 176 234 410 minecraft:white_concrete
setblock 177 233 370 minecraft:white_concrete
fill 177 233 403 177 234 403 minecraft:white_concrete
fill 177 233 405 177 234 405 minecraft:white_concrete
fill 177 233 407 177 234 407 minecraft:white_concrete
fill 177 233 409 177 234 409 minecraft:white_concrete
fill 178 233 404 178 234 404 minecraft:white_concrete
fill 178 233 406 178 234 406 minecraft:white_concrete
fill 178 233 408 178 234 408 minecraft:white_concrete
fill 178 233 410 178 234 410 minecraft:white_concrete
fill 179 233 403 179 234 403 minecraft:white_concrete
fill 179 233 405 179 234 405 minecraft:white_concrete
fill 179 233 407 179 234 407 minecraft:white_concrete
fill 179 233 409 179 234 409 minecraft:white_concrete
fill 180 233 404 180 234 404 minecraft:white_concrete
fill 180 233 406 180 234 406 minecraft:white_concrete
fill 180 233 408 180 234 408 minecraft:white_concrete
fill 180 233 410 180 234 410 minecraft:white_concrete
fill 181 233 403 181 234 403 minecraft:white_concrete
fill 181 233 405 181 234 405 minecraft:white_concrete
fill 181 233 407 182 233 407 minecraft:white_concrete
fill 181 233 409 181 234 409 minecraft:white_concrete
setblock 182 233 372 minecraft:white_concrete
setblock 182 233 386 minecraft:white_concrete
setblock 182 233 393 minecraft:white_concrete
setblock 182 233 400 minecraft:white_concrete
setblock 142 234 378 minecraft:white_concrete
setblock 142 234 385 minecraft:white_concrete
setblock 142 234 399 minecraft:white_concrete
setblock 142 234 406 minecraft:white_concrete
setblock 145 234 410 minecraft:white_concrete
setblock 152 234 410 minecraft:white_concrete
setblock 155 234 370 minecraft:white_concrete
setblock 159 234 410 minecraft:white_concrete
setblock 162 234 370 minecraft:white_concrete
setblock 166 234 410 minecraft:white_concrete
setblock 169 234 370 minecraft:white_concrete
setblock 176 234 370 minecraft:white_concrete
setblock 181 234 407 minecraft:white_concrete
setblock 182 234 371 minecraft:white_concrete
setblock 182 234 385 minecraft:white_concrete
setblock 182 234 392 minecraft:white_concrete
setblock 182 234 399 minecraft:white_concrete
setblock 182 234 406 minecraft:white_concrete
setblock 142 235 379 minecraft:white_concrete
setblock 142 235 386 minecraft:jack_o_lantern
setblock 142 235 388 minecraft:jack_o_lantern
setblock 142 235 390 minecraft:jack_o_lantern
setblock 142 235 392 minecraft:jack_o_lantern
setblock 142 235 394 minecraft:jack_o_lantern
setblock 142 235 396 minecraft:jack_o_lantern
setblock 142 235 400 minecraft:white_concrete
setblock 142 235 407 minecraft:white_concrete
fill 143 235 370 143 235 376 minecraft:red_concrete
setblock 143 235 387 minecraft:jack_o_lantern
setblock 143 235 389 minecraft:jack_o_lantern
setblock 143 235 391 minecraft:jack_o_lantern
setblock 143 235 393 minecraft:jack_o_lantern
setblock 143 235 395 minecraft:jack_o_lantern
fill 144 235 371 148 235 376 minecraft:red_concrete
setblock 144 235 380 minecraft:light[level=14]
setblock 144 235 386 minecraft:jack_o_lantern
setblock 144 235 388 minecraft:jack_o_lantern
schedule function dropper:buildpart/87_4 1t
