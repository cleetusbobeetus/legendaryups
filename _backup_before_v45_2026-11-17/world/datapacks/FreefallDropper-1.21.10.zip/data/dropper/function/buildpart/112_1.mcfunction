setblock 194 73 469 minecraft:pearlescent_froglight
setblock 195 73 464 minecraft:pearlescent_froglight
setblock 195 73 466 minecraft:pearlescent_froglight
setblock 195 73 468 minecraft:pearlescent_froglight
setblock 195 73 470 minecraft:pearlescent_froglight
setblock 196 73 465 minecraft:pearlescent_froglight
setblock 196 73 467 minecraft:pearlescent_froglight
setblock 196 73 469 minecraft:pearlescent_froglight
setblock 197 73 464 minecraft:pearlescent_froglight
setblock 197 73 466 minecraft:pearlescent_froglight
setblock 197 73 468 minecraft:pearlescent_froglight
setblock 197 73 470 minecraft:pearlescent_froglight
setblock 198 73 465 minecraft:pearlescent_froglight
setblock 198 73 467 minecraft:pearlescent_froglight
setblock 198 73 469 minecraft:pearlescent_froglight
setblock 199 73 464 minecraft:pearlescent_froglight
setblock 199 73 466 minecraft:pearlescent_froglight
setblock 199 73 468 minecraft:pearlescent_froglight
setblock 199 73 470 minecraft:pearlescent_froglight
setblock 200 73 465 minecraft:pearlescent_froglight
setblock 200 73 467 minecraft:pearlescent_froglight
setblock 200 73 469 minecraft:pearlescent_froglight
setblock 201 73 464 minecraft:pearlescent_froglight
fill 201 73 465 201 84 465 minecraft:light_gray_concrete
setblock 201 73 466 minecraft:pearlescent_froglight
setblock 201 73 468 minecraft:pearlescent_froglight
setblock 201 73 470 minecraft:pearlescent_froglight
setblock 207 73 464 minecraft:pearlescent_froglight
fill 207 73 465 207 84 465 minecraft:light_gray_concrete
setblock 207 73 466 minecraft:pearlescent_froglight
setblock 207 73 468 minecraft:pearlescent_froglight
setblock 207 73 470 minecraft:pearlescent_froglight
setblock 208 73 465 minecraft:pearlescent_froglight
setblock 208 73 467 minecraft:pearlescent_froglight
setblock 208 73 469 minecraft:pearlescent_froglight
setblock 209 73 464 minecraft:pearlescent_froglight
setblock 209 73 466 minecraft:pearlescent_froglight
setblock 209 73 468 minecraft:pearlescent_froglight
setblock 209 73 470 minecraft:pearlescent_froglight
setblock 210 73 465 minecraft:pearlescent_froglight
setblock 210 73 467 minecraft:pearlescent_froglight
setblock 210 73 469 minecraft:pearlescent_froglight
setblock 211 73 464 minecraft:pearlescent_froglight
setblock 211 73 466 minecraft:pearlescent_froglight
setblock 211 73 468 minecraft:pearlescent_froglight
setblock 211 73 470 minecraft:pearlescent_froglight
setblock 212 73 465 minecraft:pearlescent_froglight
setblock 212 73 467 minecraft:pearlescent_froglight
setblock 212 73 469 minecraft:pearlescent_froglight
setblock 213 73 464 minecraft:pearlescent_froglight
setblock 213 73 466 minecraft:pearlescent_froglight
setblock 213 73 468 minecraft:pearlescent_froglight
setblock 213 73 470 minecraft:pearlescent_froglight
setblock 214 73 465 minecraft:pearlescent_froglight
setblock 214 73 467 minecraft:pearlescent_froglight
setblock 214 73 469 minecraft:pearlescent_froglight
setblock 215 73 464 minecraft:pearlescent_froglight
fill 215 73 465 215 84 465 minecraft:light_gray_concrete
setblock 215 73 466 minecraft:pearlescent_froglight
setblock 215 73 468 minecraft:pearlescent_froglight
setblock 215 73 470 minecraft:pearlescent_froglight
fill 188 74 468 188 79 468 minecraft:pearlescent_froglight
fill 188 74 476 188 79 476 minecraft:pearlescent_froglight
fill 188 74 484 188 79 484 minecraft:pearlescent_froglight
fill 188 74 492 188 79 492 minecraft:pearlescent_froglight
fill 188 74 500 188 79 500 minecraft:pearlescent_froglight
fill 191 74 505 191 79 505 minecraft:pearlescent_froglight
fill 193 74 464 193 75 464 minecraft:light_gray_concrete
fill 193 74 466 193 75 466 minecraft:light_gray_concrete
fill 193 74 468 193 75 468 minecraft:light_gray_concrete
fill 193 74 470 193 75 470 minecraft:light_gray_concrete
fill 194 74 465 194 75 465 minecraft:light_gray_concrete
fill 194 74 467 194 75 467 minecraft:light_gray_concrete
fill 194 74 469 194 75 469 minecraft:light_gray_concrete
fill 195 74 463 195 79 463 minecraft:pearlescent_froglight
fill 195 74 464 195 75 464 minecraft:light_gray_concrete
fill 195 74 466 195 75 466 minecraft:light_gray_concrete
fill 195 74 468 195 75 468 minecraft:light_gray_concrete
fill 195 74 470 195 75 470 minecraft:light_gray_concrete
fill 196 74 465 196 75 465 minecraft:light_gray_concrete
fill 196 74 467 196 75 467 minecraft:light_gray_concrete
fill 196 74 469 196 75 469 minecraft:light_gray_concrete
fill 197 74 464 197 75 464 minecraft:light_gray_concrete
fill 197 74 466 197 75 466 minecraft:light_gray_concrete
fill 197 74 468 197 75 468 minecraft:light_gray_concrete
fill 197 74 470 197 75 470 minecraft:light_gray_concrete
fill 198 74 465 198 75 465 minecraft:light_gray_concrete
fill 198 74 467 198 75 467 minecraft:light_gray_concrete
fill 198 74 469 198 75 469 minecraft:light_gray_concrete
fill 199 74 464 199 75 464 minecraft:light_gray_concrete
fill 199 74 466 199 75 466 minecraft:light_gray_concrete
fill 199 74 468 199 75 468 minecraft:light_gray_concrete
fill 199 74 470 199 75 470 minecraft:light_gray_concrete
fill 199 74 505 199 79 505 minecraft:pearlescent_froglight
fill 200 74 465 200 75 465 minecraft:light_gray_concrete
fill 200 74 467 200 75 467 minecraft:light_gray_concrete
fill 200 74 469 200 75 469 minecraft:light_gray_concrete
fill 201 74 464 201 75 464 minecraft:light_gray_concrete
fill 201 74 466 201 75 466 minecraft:light_gray_concrete
fill 201 74 468 201 75 468 minecraft:light_gray_concrete
fill 201 74 470 201 75 470 minecraft:light_gray_concrete
fill 203 74 463 203 79 463 minecraft:pearlescent_froglight
fill 207 74 464 207 75 464 minecraft:light_gray_concrete
fill 207 74 466 207 75 466 minecraft:light_gray_concrete
fill 207 74 468 207 75 468 minecraft:light_gray_concrete
fill 207 74 470 207 75 470 minecraft:light_gray_concrete
fill 207 74 505 207 79 505 minecraft:pearlescent_froglight
fill 208 74 465 208 75 465 minecraft:light_gray_concrete
fill 208 74 467 208 75 467 minecraft:light_gray_concrete
fill 208 74 469 208 75 469 minecraft:light_gray_concrete
fill 209 74 464 209 75 464 minecraft:light_gray_concrete
fill 209 74 466 209 75 466 minecraft:light_gray_concrete
fill 209 74 468 209 75 468 minecraft:light_gray_concrete
fill 209 74 470 209 75 470 minecraft:light_gray_concrete
fill 210 74 465 210 75 465 minecraft:light_gray_concrete
fill 210 74 467 210 75 467 minecraft:light_gray_concrete
fill 210 74 469 210 75 469 minecraft:light_gray_concrete
fill 211 74 463 211 79 463 minecraft:pearlescent_froglight
fill 211 74 464 211 75 464 minecraft:light_gray_concrete
fill 211 74 466 211 75 466 minecraft:light_gray_concrete
fill 211 74 468 211 75 468 minecraft:light_gray_concrete
fill 211 74 470 211 75 470 minecraft:light_gray_concrete
fill 212 74 465 212 75 465 minecraft:light_gray_concrete
fill 212 74 467 212 75 467 minecraft:light_gray_concrete
fill 212 74 469 212 75 469 minecraft:light_gray_concrete
fill 213 74 464 213 75 464 minecraft:light_gray_concrete
fill 213 74 466 213 75 466 minecraft:light_gray_concrete
fill 213 74 468 213 75 468 minecraft:light_gray_concrete
fill 213 74 470 213 75 470 minecraft:light_gray_concrete
fill 214 74 465 214 75 465 minecraft:light_gray_concrete
fill 214 74 467 214 75 467 minecraft:light_gray_concrete
fill 214 74 469 214 75 469 minecraft:light_gray_concrete
fill 215 74 464 215 75 464 minecraft:light_gray_concrete
fill 215 74 466 215 75 466 minecraft:light_gray_concrete
fill 215 74 468 215 75 468 minecraft:light_gray_concrete
fill 215 74 470 215 75 470 minecraft:light_gray_concrete
fill 215 74 505 215 79 505 minecraft:pearlescent_froglight
fill 219 74 463 219 79 463 minecraft:pearlescent_froglight
fill 223 74 505 223 79 505 minecraft:pearlescent_froglight
fill 227 74 463 227 79 463 minecraft:pearlescent_froglight
fill 230 74 468 230 79 468 minecraft:pearlescent_froglight
fill 230 74 476 230 79 476 minecraft:pearlescent_froglight
fill 230 74 484 230 79 484 minecraft:pearlescent_froglight
fill 230 74 492 230 79 492 minecraft:pearlescent_froglight
fill 230 74 500 230 79 500 minecraft:pearlescent_froglight
setblock 193 76 464 minecraft:pearlescent_froglight
setblock 193 76 466 minecraft:pearlescent_froglight
setblock 193 76 468 minecraft:pearlescent_froglight
setblock 193 76 470 minecraft:pearlescent_froglight
setblock 194 76 465 minecraft:pearlescent_froglight
setblock 194 76 467 minecraft:pearlescent_froglight
setblock 194 76 469 minecraft:pearlescent_froglight
setblock 195 76 464 minecraft:pearlescent_froglight
setblock 195 76 466 minecraft:pearlescent_froglight
setblock 195 76 468 minecraft:pearlescent_froglight
setblock 195 76 470 minecraft:pearlescent_froglight
setblock 196 76 465 minecraft:pearlescent_froglight
setblock 196 76 467 minecraft:pearlescent_froglight
setblock 196 76 469 minecraft:pearlescent_froglight
setblock 197 76 464 minecraft:pearlescent_froglight
setblock 197 76 466 minecraft:pearlescent_froglight
setblock 197 76 468 minecraft:pearlescent_froglight
setblock 197 76 470 minecraft:pearlescent_froglight
setblock 198 76 465 minecraft:pearlescent_froglight
setblock 198 76 467 minecraft:pearlescent_froglight
setblock 198 76 469 minecraft:pearlescent_froglight
setblock 199 76 464 minecraft:pearlescent_froglight
setblock 199 76 466 minecraft:pearlescent_froglight
setblock 199 76 468 minecraft:pearlescent_froglight
setblock 199 76 470 minecraft:pearlescent_froglight
setblock 200 76 465 minecraft:pearlescent_froglight
setblock 200 76 467 minecraft:pearlescent_froglight
setblock 200 76 469 minecraft:pearlescent_froglight
setblock 201 76 464 minecraft:pearlescent_froglight
setblock 201 76 466 minecraft:pearlescent_froglight
setblock 201 76 468 minecraft:pearlescent_froglight
setblock 201 76 470 minecraft:pearlescent_froglight
setblock 207 76 464 minecraft:pearlescent_froglight
setblock 207 76 466 minecraft:pearlescent_froglight
setblock 207 76 468 minecraft:pearlescent_froglight
setblock 207 76 470 minecraft:pearlescent_froglight
setblock 208 76 465 minecraft:pearlescent_froglight
setblock 208 76 467 minecraft:pearlescent_froglight
setblock 208 76 469 minecraft:pearlescent_froglight
setblock 209 76 464 minecraft:pearlescent_froglight
setblock 209 76 466 minecraft:pearlescent_froglight
setblock 209 76 468 minecraft:pearlescent_froglight
setblock 209 76 470 minecraft:pearlescent_froglight
setblock 210 76 465 minecraft:pearlescent_froglight
setblock 210 76 467 minecraft:pearlescent_froglight
setblock 210 76 469 minecraft:pearlescent_froglight
setblock 211 76 464 minecraft:pearlescent_froglight
setblock 211 76 466 minecraft:pearlescent_froglight
setblock 211 76 468 minecraft:pearlescent_froglight
setblock 211 76 470 minecraft:pearlescent_froglight
setblock 212 76 465 minecraft:pearlescent_froglight
setblock 212 76 467 minecraft:pearlescent_froglight
setblock 212 76 469 minecraft:pearlescent_froglight
setblock 213 76 464 minecraft:pearlescent_froglight
setblock 213 76 466 minecraft:pearlescent_froglight
setblock 213 76 468 minecraft:pearlescent_froglight
setblock 213 76 470 minecraft:pearlescent_froglight
setblock 214 76 465 minecraft:pearlescent_froglight
setblock 214 76 467 minecraft:pearlescent_froglight
setblock 214 76 469 minecraft:pearlescent_froglight
setblock 215 76 464 minecraft:pearlescent_froglight
setblock 215 76 466 minecraft:pearlescent_froglight
setblock 215 76 468 minecraft:pearlescent_froglight
setblock 215 76 470 minecraft:pearlescent_froglight
setblock 191 77 466 minecraft:light[level=11]
setblock 191 77 474 minecraft:light[level=11]
setblock 191 77 482 minecraft:light[level=11]
setblock 191 77 490 minecraft:light[level=11]
setblock 191 77 498 minecraft:light[level=11]
fill 193 77 464 193 78 464 minecraft:light_gray_concrete
fill 193 77 466 193 78 466 minecraft:light_gray_concrete
fill 193 77 468 193 78 468 minecraft:light_gray_concrete
fill 193 77 470 193 78 470 minecraft:light_gray_concrete
fill 194 77 465 194 78 465 minecraft:light_gray_concrete
fill 194 77 467 194 78 467 minecraft:light_gray_concrete
fill 194 77 469 194 78 469 minecraft:light_gray_concrete
fill 195 77 464 195 78 464 minecraft:light_gray_concrete
fill 195 77 466 195 78 466 minecraft:light_gray_concrete
fill 195 77 468 195 78 468 minecraft:light_gray_concrete
fill 195 77 470 195 78 470 minecraft:light_gray_concrete
fill 196 77 465 196 78 465 minecraft:light_gray_concrete
fill 196 77 467 196 78 467 minecraft:light_gray_concrete
fill 196 77 469 196 78 469 minecraft:light_gray_concrete
fill 197 77 464 197 78 464 minecraft:light_gray_concrete
fill 197 77 466 197 78 466 minecraft:light_gray_concrete
fill 197 77 468 197 78 468 minecraft:light_gray_concrete
fill 197 77 470 197 78 470 minecraft:light_gray_concrete
fill 198 77 465 198 78 465 minecraft:light_gray_concrete
fill 198 77 467 198 78 467 minecraft:light_gray_concrete
fill 198 77 469 198 78 469 minecraft:light_gray_concrete
fill 199 77 464 199 78 464 minecraft:light_gray_concrete
fill 199 77 466 199 78 466 minecraft:light_gray_concrete
fill 199 77 468 199 78 468 minecraft:light_gray_concrete
fill 199 77 470 199 78 470 minecraft:light_gray_concrete
setblock 199 77 474 minecraft:light[level=11]
setblock 199 77 482 minecraft:light[level=11]
setblock 199 77 490 minecraft:light[level=11]
setblock 199 77 498 minecraft:light[level=11]
fill 200 77 465 200 78 465 minecraft:light_gray_concrete
fill 200 77 467 200 78 467 minecraft:light_gray_concrete
fill 200 77 469 200 78 469 minecraft:light_gray_concrete
fill 201 77 464 201 78 464 minecraft:light_gray_concrete
fill 201 77 466 201 78 466 minecraft:light_gray_concrete
fill 201 77 468 201 78 468 minecraft:light_gray_concrete
fill 201 77 470 201 78 470 minecraft:light_gray_concrete
fill 207 77 464 207 78 464 minecraft:light_gray_concrete
fill 207 77 466 207 78 466 minecraft:light_gray_concrete
fill 207 77 468 207 78 468 minecraft:light_gray_concrete
fill 207 77 470 207 78 470 minecraft:light_gray_concrete
setblock 207 77 474 minecraft:light[level=11]
setblock 207 77 482 minecraft:light[level=11]
setblock 207 77 490 minecraft:light[level=11]
setblock 207 77 498 minecraft:light[level=11]
fill 208 77 465 208 78 465 minecraft:light_gray_concrete
fill 208 77 467 208 78 467 minecraft:light_gray_concrete
fill 208 77 469 208 78 469 minecraft:light_gray_concrete
fill 209 77 464 209 78 464 minecraft:light_gray_concrete
fill 209 77 466 209 78 466 minecraft:light_gray_concrete
fill 209 77 468 209 78 468 minecraft:light_gray_concrete
fill 209 77 470 209 78 470 minecraft:light_gray_concrete
fill 210 77 465 210 78 465 minecraft:light_gray_concrete
fill 210 77 467 210 78 467 minecraft:light_gray_concrete
fill 210 77 469 210 78 469 minecraft:light_gray_concrete
fill 211 77 464 211 78 464 minecraft:light_gray_concrete
fill 211 77 466 211 78 466 minecraft:light_gray_concrete
fill 211 77 468 211 78 468 minecraft:light_gray_concrete
fill 211 77 470 211 78 470 minecraft:light_gray_concrete
fill 212 77 465 212 78 465 minecraft:light_gray_concrete
fill 212 77 467 212 78 467 minecraft:light_gray_concrete
fill 212 77 469 212 78 469 minecraft:light_gray_concrete
fill 213 77 464 213 78 464 minecraft:light_gray_concrete
fill 213 77 466 213 78 466 minecraft:light_gray_concrete
fill 213 77 468 213 78 468 minecraft:light_gray_concrete
fill 213 77 470 213 78 470 minecraft:light_gray_concrete
fill 214 77 465 214 78 465 minecraft:light_gray_concrete
fill 214 77 467 214 78 467 minecraft:light_gray_concrete
fill 214 77 469 214 78 469 minecraft:light_gray_concrete
fill 215 77 464 215 78 464 minecraft:light_gray_concrete
fill 215 77 466 215 78 466 minecraft:light_gray_concrete
fill 215 77 468 215 78 468 minecraft:light_gray_concrete
fill 215 77 470 215 78 470 minecraft:light_gray_concrete
setblock 215 77 474 minecraft:light[level=11]
setblock 215 77 482 minecraft:light[level=11]
setblock 215 77 490 minecraft:light[level=11]
setblock 215 77 498 minecraft:light[level=11]
setblock 223 77 466 minecraft:light[level=11]
setblock 223 77 474 minecraft:light[level=11]
setblock 223 77 482 minecraft:light[level=11]
setblock 223 77 490 minecraft:light[level=11]
setblock 223 77 498 minecraft:light[level=11]
fill 225 78 477 225 85 477 minecraft:iron_block
setblock 225 78 489 minecraft:light_gray_concrete
setblock 225 78 491 minecraft:light_gray_concrete
setblock 227 78 489 minecraft:light_gray_concrete
setblock 227 78 491 minecraft:light_gray_concrete
setblock 193 79 464 minecraft:pearlescent_froglight
setblock 193 79 466 minecraft:pearlescent_froglight
setblock 193 79 468 minecraft:pearlescent_froglight
setblock 193 79 470 minecraft:pearlescent_froglight
setblock 194 79 465 minecraft:pearlescent_froglight
setblock 194 79 467 minecraft:pearlescent_froglight
setblock 194 79 469 minecraft:pearlescent_froglight
setblock 195 79 464 minecraft:pearlescent_froglight
setblock 195 79 466 minecraft:pearlescent_froglight
setblock 195 79 468 minecraft:pearlescent_froglight
setblock 195 79 470 minecraft:pearlescent_froglight
setblock 196 79 465 minecraft:pearlescent_froglight
setblock 196 79 467 minecraft:pearlescent_froglight
setblock 196 79 469 minecraft:pearlescent_froglight
setblock 197 79 464 minecraft:pearlescent_froglight
setblock 197 79 466 minecraft:pearlescent_froglight
setblock 197 79 468 minecraft:pearlescent_froglight
setblock 197 79 470 minecraft:pearlescent_froglight
setblock 198 79 465 minecraft:pearlescent_froglight
setblock 198 79 467 minecraft:pearlescent_froglight
setblock 198 79 469 minecraft:pearlescent_froglight
setblock 199 79 464 minecraft:pearlescent_froglight
setblock 199 79 466 minecraft:pearlescent_froglight
setblock 199 79 468 minecraft:pearlescent_froglight
setblock 199 79 470 minecraft:pearlescent_froglight
setblock 200 79 465 minecraft:pearlescent_froglight
setblock 200 79 467 minecraft:pearlescent_froglight
setblock 200 79 469 minecraft:pearlescent_froglight
setblock 201 79 464 minecraft:pearlescent_froglight
setblock 201 79 466 minecraft:pearlescent_froglight
setblock 201 79 468 minecraft:pearlescent_froglight
setblock 201 79 470 minecraft:pearlescent_froglight
setblock 207 79 464 minecraft:pearlescent_froglight
setblock 207 79 466 minecraft:pearlescent_froglight
setblock 207 79 468 minecraft:pearlescent_froglight
setblock 207 79 470 minecraft:pearlescent_froglight
setblock 208 79 465 minecraft:pearlescent_froglight
setblock 208 79 467 minecraft:pearlescent_froglight
setblock 208 79 469 minecraft:pearlescent_froglight
setblock 209 79 464 minecraft:pearlescent_froglight
setblock 209 79 466 minecraft:pearlescent_froglight
setblock 209 79 468 minecraft:pearlescent_froglight
setblock 209 79 470 minecraft:pearlescent_froglight
setblock 210 79 465 minecraft:pearlescent_froglight
setblock 210 79 467 minecraft:pearlescent_froglight
setblock 210 79 469 minecraft:pearlescent_froglight
setblock 211 79 464 minecraft:pearlescent_froglight
setblock 211 79 466 minecraft:pearlescent_froglight
setblock 211 79 468 minecraft:pearlescent_froglight
setblock 211 79 470 minecraft:pearlescent_froglight
setblock 212 79 465 minecraft:pearlescent_froglight
setblock 212 79 467 minecraft:pearlescent_froglight
setblock 212 79 469 minecraft:pearlescent_froglight
setblock 213 79 464 minecraft:pearlescent_froglight
setblock 213 79 466 minecraft:pearlescent_froglight
setblock 213 79 468 minecraft:pearlescent_froglight
setblock 213 79 470 minecraft:pearlescent_froglight
setblock 214 79 465 minecraft:pearlescent_froglight
setblock 214 79 467 minecraft:pearlescent_froglight
setblock 214 79 469 minecraft:pearlescent_froglight
setblock 215 79 464 minecraft:pearlescent_froglight
setblock 215 79 466 minecraft:pearlescent_froglight
setblock 215 79 468 minecraft:pearlescent_froglight
setblock 215 79 470 minecraft:pearlescent_froglight
fill 188 80 463 188 81 464 minecraft:cyan_terracotta
fill 188 80 465 188 80 466 minecraft:light_gray_terracotta
fill 188 80 467 188 81 470 minecraft:cyan_terracotta
setblock 188 80 471 minecraft:light_gray_terracotta
fill 188 80 472 188 80 480 minecraft:cyan_terracotta
setblock 188 80 481 minecraft:light_gray_terracotta
fill 188 80 482 188 83 483 minecraft:cyan_terracotta
fill 188 80 484 188 80 485 minecraft:light_gray_terracotta
fill 188 80 486 188 80 494 minecraft:cyan_terracotta
setblock 188 80 495 minecraft:light_gray_terracotta
fill 188 80 496 188 80 501 minecraft:cyan_terracotta
setblock 188 80 502 minecraft:light_gray_terracotta
fill 188 80 503 188 83 505 minecraft:cyan_terracotta
fill 189 80 463 190 83 463 minecraft:cyan_terracotta
setblock 191 80 463 minecraft:light_gray_terracotta
fill 191 80 505 191 83 505 minecraft:cyan_terracotta
fill 192 80 463 193 80 463 minecraft:cyan_terracotta
setblock 192 80 505 minecraft:light_gray_terracotta
fill 193 80 464 193 81 464 minecraft:light_gray_concrete
fill 193 80 466 193 81 466 minecraft:light_gray_concrete
fill 193 80 468 193 81 468 minecraft:light_gray_concrete
fill 193 80 470 193 81 470 minecraft:light_gray_concrete
fill 193 80 505 199 80 505 minecraft:cyan_terracotta
setblock 194 80 463 minecraft:light_gray_terracotta
fill 194 80 465 194 81 465 minecraft:light_gray_concrete
fill 194 80 467 194 81 467 minecraft:light_gray_concrete
fill 194 80 469 194 81 469 minecraft:light_gray_concrete
setblock 195 80 463 minecraft:cyan_terracotta
fill 195 80 464 195 81 464 minecraft:light_gray_concrete
fill 195 80 466 195 81 466 minecraft:light_gray_concrete
fill 195 80 468 195 81 468 minecraft:light_gray_concrete
fill 195 80 470 195 81 470 minecraft:light_gray_concrete
fill 196 80 465 196 81 465 minecraft:light_gray_concrete
fill 196 80 467 196 81 467 minecraft:light_gray_concrete
fill 196 80 469 196 81 469 minecraft:light_gray_concrete
fill 197 80 464 197 81 464 minecraft:light_gray_concrete
fill 197 80 466 197 81 466 minecraft:light_gray_concrete
fill 197 80 468 197 81 468 minecraft:light_gray_concrete
fill 197 80 470 197 81 470 minecraft:light_gray_concrete
fill 198 80 465 198 81 465 minecraft:light_gray_concrete
fill 198 80 467 198 81 467 minecraft:light_gray_concrete
fill 198 80 469 198 81 469 minecraft:light_gray_concrete
fill 199 80 464 199 81 464 minecraft:light_gray_concrete
fill 199 80 466 199 81 466 minecraft:light_gray_concrete
fill 199 80 468 199 81 468 minecraft:light_gray_concrete
fill 199 80 470 199 81 470 minecraft:light_gray_concrete
fill 200 80 465 200 81 465 minecraft:light_gray_concrete
fill 200 80 467 200 81 467 minecraft:light_gray_concrete
fill 200 80 469 200 81 469 minecraft:light_gray_concrete
fill 201 80 464 201 81 464 minecraft:light_gray_concrete
fill 201 80 466 201 81 466 minecraft:light_gray_concrete
fill 201 80 468 201 81 468 minecraft:light_gray_concrete
fill 201 80 470 201 81 470 minecraft:light_gray_concrete
fill 203 80 463 209 80 463 minecraft:cyan_terracotta
fill 205 80 469 205 91 469 minecraft:iron_block
fill 207 80 464 207 81 464 minecraft:light_gray_concrete
fill 207 80 466 207 81 466 minecraft:light_gray_concrete
fill 207 80 468 207 81 468 minecraft:light_gray_concrete
fill 207 80 470 207 81 470 minecraft:light_gray_concrete
fill 207 80 505 209 80 505 minecraft:cyan_terracotta
fill 208 80 465 208 81 465 minecraft:light_gray_concrete
fill 208 80 467 208 81 467 minecraft:light_gray_concrete
fill 208 80 469 208 81 469 minecraft:light_gray_concrete
fill 209 80 464 209 81 464 minecraft:light_gray_concrete
fill 209 80 466 209 81 466 minecraft:light_gray_concrete
fill 209 80 468 209 81 468 minecraft:light_gray_concrete
fill 209 80 470 209 81 470 minecraft:light_gray_concrete
setblock 210 80 463 minecraft:light_gray_terracotta
fill 210 80 465 210 81 465 minecraft:light_gray_concrete
fill 210 80 467 210 81 467 minecraft:light_gray_concrete
fill 210 80 469 210 81 469 minecraft:light_gray_concrete
setblock 210 80 505 minecraft:light_gray_terracotta
fill 211 80 463 211 83 463 minecraft:cyan_terracotta
fill 211 80 464 211 81 464 minecraft:light_gray_concrete
fill 211 80 466 211 81 466 minecraft:light_gray_concrete
fill 211 80 468 211 81 468 minecraft:light_gray_concrete
fill 211 80 470 211 81 470 minecraft:light_gray_concrete
fill 211 80 505 216 80 505 minecraft:cyan_terracotta
fill 212 80 465 212 81 465 minecraft:light_gray_concrete
fill 212 80 467 212 81 467 minecraft:light_gray_concrete
fill 212 80 469 212 81 469 minecraft:light_gray_concrete
fill 213 80 464 213 81 464 minecraft:light_gray_concrete
fill 213 80 466 213 81 466 minecraft:light_gray_concrete
fill 213 80 468 213 81 468 minecraft:light_gray_concrete
fill 213 80 470 213 81 470 minecraft:light_gray_concrete
fill 214 80 465 214 81 465 minecraft:light_gray_concrete
fill 214 80 467 214 81 467 minecraft:light_gray_concrete
fill 214 80 469 214 81 469 minecraft:light_gray_concrete
fill 215 80 464 215 81 464 minecraft:light_gray_concrete
fill 215 80 466 215 81 466 minecraft:light_gray_concrete
fill 215 80 468 215 81 468 minecraft:light_gray_concrete
fill 215 80 470 215 81 470 minecraft:light_gray_concrete
fill 217 80 505 218 80 505 minecraft:light_gray_terracotta
fill 219 80 463 223 81 463 minecraft:cyan_terracotta
fill 219 80 505 223 81 505 minecraft:cyan_terracotta
fill 224 80 463 224 81 463 minecraft:light_gray_terracotta
fill 225 80 463 225 83 463 minecraft:cyan_terracotta
setblock 226 80 463 minecraft:light_gray_terracotta
fill 227 80 463 227 81 463 minecraft:cyan_terracotta
fill 230 80 468 230 83 474 minecraft:cyan_terracotta
setblock 230 80 475 minecraft:light_gray_terracotta
fill 230 80 476 230 83 476 minecraft:cyan_terracotta
fill 230 80 484 230 84 484 minecraft:cyan_terracotta
fill 230 80 492 230 83 493 minecraft:cyan_terracotta
fill 230 80 494 230 80 495 minecraft:light_gray_terracotta
fill 230 80 496 230 80 499 minecraft:cyan_terracotta
setblock 230 80 500 minecraft:light_gray_terracotta
fill 188 81 465 188 81 466 minecraft:cyan_terracotta
fill 188 81 471 188 83 477 minecraft:cyan_terracotta
fill 188 81 478 188 81 479 minecraft:light_gray_terracotta
fill 188 81 480 188 83 481 minecraft:cyan_terracotta
fill 188 81 484 188 83 485 minecraft:cyan_terracotta
setblock 188 81 486 minecraft:light_gray_terracotta
fill 188 81 487 188 83 487 minecraft:cyan_terracotta
setblock 188 81 488 minecraft:light_gray_terracotta
fill 188 81 489 188 83 489 minecraft:cyan_terracotta
setblock 188 81 490 minecraft:light_gray_terracotta
fill 188 81 491 188 83 491 minecraft:cyan_terracotta
setblock 188 81 492 minecraft:light_gray_terracotta
fill 188 81 493 188 83 496 minecraft:cyan_terracotta
fill 188 81 497 188 81 500 minecraft:light_gray_terracotta
fill 188 81 501 188 83 502 minecraft:cyan_terracotta
fill 191 81 463 192 83 463 minecraft:cyan_terracotta
fill 192 81 505 192 83 505 minecraft:cyan_terracotta
setblock 193 81 463 minecraft:light_gray_terracotta
fill 193 81 505 194 81 505 minecraft:light_gray_terracotta
fill 194 81 463 194 83 463 minecraft:cyan_terracotta
setblock 195 81 463 minecraft:light_gray_terracotta
fill 195 81 505 200 83 505 minecraft:cyan_terracotta
fill 196 81 463 200 83 463 minecraft:cyan_terracotta
setblock 201 81 463 minecraft:light_gray_terracotta
fill 201 81 505 201 82 505 minecraft:light_gray_terracotta
fill 202 81 463 208 81 463 minecraft:cyan_terracotta
fill 202 81 505 202 83 505 minecraft:cyan_terracotta
fill 203 81 505 203 82 505 minecraft:light_gray_terracotta
fill 204 81 505 207 83 505 minecraft:cyan_terracotta
setblock 208 81 505 minecraft:light_gray_terracotta
setblock 209 81 463 minecraft:light_gray_terracotta
fill 209 81 505 214 83 505 minecraft:cyan_terracotta
fill 210 81 463 210 84 463 minecraft:cyan_terracotta
setblock 215 81 505 minecraft:light_gray_terracotta
fill 216 81 505 218 83 505 minecraft:cyan_terracotta
fill 224 81 505 224 82 505 minecraft:light_gray_terracotta
fill 225 81 505 230 83 505 minecraft:cyan_terracotta
fill 226 81 463 226 83 463 minecraft:cyan_terracotta
fill 230 81 464 230 82 464 minecraft:light_gray_terracotta
fill 230 81 465 230 83 465 minecraft:cyan_terracotta
fill 230 81 466 230 82 466 minecraft:light_gray_terracotta
setblock 230 81 467 minecraft:cyan_terracotta
fill 230 81 475 230 84 475 minecraft:cyan_terracotta
fill 230 81 494 230 83 498 minecraft:cyan_terracotta
setblock 230 81 499 minecraft:light_gray_terracotta
fill 230 81 500 230 83 500 minecraft:cyan_terracotta
setblock 188 82 463 minecraft:light_gray_terracotta
fill 188 82 464 188 83 465 minecraft:cyan_terracotta
setblock 188 82 466 minecraft:light_gray_terracotta
fill 188 82 467 188 83 468 minecraft:cyan_terracotta
setblock 188 82 469 minecraft:light_gray_terracotta
fill 188 82 470 188 83 470 minecraft:cyan_terracotta
fill 188 82 478 188 83 479 minecraft:cyan_terracotta
fill 188 82 486 188 83 486 minecraft:cyan_terracotta
fill 188 82 488 188 83 488 minecraft:cyan_terracotta
fill 188 82 490 188 83 490 minecraft:cyan_terracotta
fill 188 82 492 188 83 492 minecraft:cyan_terracotta
fill 188 82 497 188 83 500 minecraft:cyan_terracotta
fill 193 82 463 193 83 463 minecraft:cyan_terracotta
setblock 193 82 464 minecraft:pearlescent_froglight
setblock 193 82 466 minecraft:pearlescent_froglight
setblock 193 82 468 minecraft:pearlescent_froglight
setblock 193 82 470 minecraft:pearlescent_froglight
fill 193 82 505 194 83 505 minecraft:cyan_terracotta
setblock 194 82 465 minecraft:pearlescent_froglight
setblock 194 82 467 minecraft:pearlescent_froglight
setblock 194 82 469 minecraft:pearlescent_froglight
fill 195 82 463 195 83 463 minecraft:cyan_terracotta
setblock 195 82 464 minecraft:pearlescent_froglight
setblock 195 82 466 minecraft:pearlescent_froglight
setblock 195 82 468 minecraft:pearlescent_froglight
setblock 195 82 470 minecraft:pearlescent_froglight
setblock 196 82 465 minecraft:pearlescent_froglight
setblock 196 82 467 minecraft:pearlescent_froglight
setblock 196 82 469 minecraft:pearlescent_froglight
setblock 197 82 464 minecraft:pearlescent_froglight
setblock 197 82 466 minecraft:pearlescent_froglight
setblock 197 82 468 minecraft:pearlescent_froglight
setblock 197 82 470 minecraft:pearlescent_froglight
setblock 198 82 465 minecraft:pearlescent_froglight
setblock 198 82 467 minecraft:pearlescent_froglight
setblock 198 82 469 minecraft:pearlescent_froglight
setblock 199 82 464 minecraft:pearlescent_froglight
setblock 199 82 466 minecraft:pearlescent_froglight
setblock 199 82 468 minecraft:pearlescent_froglight
setblock 199 82 470 minecraft:pearlescent_froglight
setblock 200 82 465 minecraft:pearlescent_froglight
setblock 200 82 467 minecraft:pearlescent_froglight
setblock 200 82 469 minecraft:pearlescent_froglight
fill 201 82 463 204 83 463 minecraft:cyan_terracotta
setblock 201 82 464 minecraft:pearlescent_froglight
setblock 201 82 466 minecraft:pearlescent_froglight
setblock 201 82 468 minecraft:pearlescent_froglight
setblock 201 82 470 minecraft:pearlescent_froglight
setblock 205 82 463 minecraft:light_gray_terracotta
fill 206 82 463 209 83 463 minecraft:cyan_terracotta
setblock 207 82 464 minecraft:pearlescent_froglight
setblock 207 82 466 minecraft:pearlescent_froglight
setblock 207 82 468 minecraft:pearlescent_froglight
setblock 207 82 470 minecraft:pearlescent_froglight
setblock 208 82 465 minecraft:pearlescent_froglight
setblock 208 82 467 minecraft:pearlescent_froglight
setblock 208 82 469 minecraft:pearlescent_froglight
fill 208 82 505 208 83 505 minecraft:cyan_terracotta
setblock 209 82 464 minecraft:pearlescent_froglight
setblock 209 82 466 minecraft:pearlescent_froglight
setblock 209 82 468 minecraft:pearlescent_froglight
setblock 209 82 470 minecraft:pearlescent_froglight
setblock 210 82 465 minecraft:pearlescent_froglight
setblock 210 82 467 minecraft:pearlescent_froglight
setblock 210 82 469 minecraft:pearlescent_froglight
setblock 211 82 464 minecraft:pearlescent_froglight
setblock 211 82 466 minecraft:pearlescent_froglight
setblock 211 82 468 minecraft:pearlescent_froglight
setblock 211 82 470 minecraft:pearlescent_froglight
fill 212 82 463 212 83 463 minecraft:cyan_terracotta
setblock 212 82 465 minecraft:pearlescent_froglight
setblock 212 82 467 minecraft:pearlescent_froglight
setblock 212 82 469 minecraft:pearlescent_froglight
setblock 213 82 463 minecraft:light_gray_terracotta
setblock 213 82 464 minecraft:pearlescent_froglight
setblock 213 82 466 minecraft:pearlescent_froglight
setblock 213 82 468 minecraft:pearlescent_froglight
setblock 213 82 470 minecraft:pearlescent_froglight
fill 214 82 463 215 83 463 minecraft:cyan_terracotta
setblock 214 82 465 minecraft:pearlescent_froglight
setblock 214 82 467 minecraft:pearlescent_froglight
setblock 214 82 469 minecraft:pearlescent_froglight
setblock 215 82 464 minecraft:pearlescent_froglight
setblock 215 82 466 minecraft:pearlescent_froglight
setblock 215 82 468 minecraft:pearlescent_froglight
setblock 215 82 470 minecraft:pearlescent_froglight
fill 215 82 505 215 83 505 minecraft:cyan_terracotta
setblock 216 82 463 minecraft:light_gray_terracotta
fill 217 82 463 220 83 463 minecraft:cyan_terracotta
fill 219 82 505 220 83 505 minecraft:cyan_terracotta
setblock 221 82 463 minecraft:light_gray_terracotta
setblock 221 82 505 minecraft:light_gray_terracotta
fill 222 82 463 224 83 463 minecraft:cyan_terracotta
fill 222 82 505 222 83 505 minecraft:cyan_terracotta
setblock 223 82 505 minecraft:light_gray_terracotta
setblock 227 82 463 minecraft:light_gray_terracotta
setblock 230 82 467 minecraft:light_gray_terracotta
fill 230 82 499 230 83 499 minecraft:cyan_terracotta
fill 188 83 463 188 85 463 minecraft:cyan_terracotta
setblock 188 83 466 minecraft:cyan_terracotta
fill 188 83 469 188 84 469 minecraft:cyan_terracotta
fill 193 83 464 193 85 464 minecraft:light_gray_concrete
setblock 193 83 466 minecraft:light_gray_concrete
setblock 193 83 468 minecraft:light_gray_concrete
setblock 193 83 470 minecraft:light_gray_concrete
fill 194 83 465 194 84 465 minecraft:light_gray_concrete
setblock 194 83 467 minecraft:light_gray_concrete
setblock 194 83 469 minecraft:light_gray_concrete
fill 195 83 464 195 85 464 minecraft:light_gray_concrete
fill 195 83 466 195 84 466 minecraft:light_gray_concrete
fill 195 83 468 195 84 468 minecraft:light_gray_concrete
setblock 195 83 470 minecraft:light_gray_concrete
fill 196 83 465 196 84 465 minecraft:light_gray_concrete
setblock 196 83 467 minecraft:light_gray_concrete
setblock 196 83 469 minecraft:light_gray_concrete
fill 197 83 464 197 85 464 minecraft:light_gray_concrete
fill 197 83 466 197 84 466 minecraft:light_gray_concrete
fill 197 83 468 197 84 468 minecraft:light_gray_concrete
setblock 197 83 470 minecraft:light_gray_concrete
fill 198 83 465 198 84 465 minecraft:light_gray_concrete
setblock 198 83 467 minecraft:light_gray_concrete
setblock 198 83 469 minecraft:light_gray_concrete
fill 199 83 464 199 131 464 minecraft:light_gray_concrete
setblock 199 83 466 minecraft:light_gray_concrete
setblock 199 83 468 minecraft:light_gray_concrete
setblock 199 83 470 minecraft:light_gray_concrete
fill 200 83 465 200 84 465 minecraft:light_gray_concrete
setblock 200 83 467 minecraft:light_gray_concrete
setblock 200 83 469 minecraft:light_gray_concrete
fill 201 83 464 201 85 464 minecraft:light_gray_concrete
setblock 201 83 466 minecraft:light_gray_concrete
setblock 201 83 468 minecraft:light_gray_concrete
setblock 201 83 470 minecraft:light_gray_concrete
setblock 201 83 505 minecraft:cyan_terracotta
setblock 203 83 505 minecraft:cyan_terracotta
setblock 205 83 463 minecraft:cyan_terracotta
fill 207 83 464 207 131 464 minecraft:light_gray_concrete
setblock 207 83 466 minecraft:light_gray_concrete
setblock 207 83 468 minecraft:light_gray_concrete
setblock 207 83 470 minecraft:light_gray_concrete
fill 208 83 465 208 84 465 minecraft:light_gray_concrete
setblock 208 83 467 minecraft:light_gray_concrete
setblock 208 83 469 minecraft:light_gray_concrete
fill 209 83 464 209 85 464 minecraft:light_gray_concrete
setblock 209 83 466 minecraft:light_gray_concrete
setblock 209 83 468 minecraft:light_gray_concrete
setblock 209 83 470 minecraft:light_gray_concrete
fill 210 83 465 210 84 465 minecraft:light_gray_concrete
setblock 210 83 467 minecraft:light_gray_concrete
setblock 210 83 469 minecraft:light_gray_concrete
fill 211 83 464 211 85 464 minecraft:light_gray_concrete
setblock 211 83 466 minecraft:light_gray_concrete
setblock 211 83 468 minecraft:light_gray_concrete
setblock 211 83 470 minecraft:light_gray_concrete
fill 212 83 465 212 84 465 minecraft:light_gray_concrete
setblock 212 83 467 minecraft:light_gray_concrete
setblock 212 83 469 minecraft:light_gray_concrete
fill 213 83 463 213 84 463 minecraft:cyan_terracotta
fill 213 83 464 213 85 464 minecraft:light_gray_concrete
setblock 213 83 466 minecraft:light_gray_concrete
setblock 213 83 468 minecraft:light_gray_concrete
setblock 213 83 470 minecraft:light_gray_concrete
fill 214 83 465 214 84 465 minecraft:light_gray_concrete
setblock 214 83 467 minecraft:light_gray_concrete
setblock 214 83 469 minecraft:light_gray_concrete
fill 215 83 464 215 131 464 minecraft:light_gray_concrete
setblock 215 83 466 minecraft:light_gray_concrete
setblock 215 83 468 minecraft:light_gray_concrete
setblock 215 83 470 minecraft:light_gray_concrete
setblock 216 83 463 minecraft:cyan_terracotta
setblock 221 83 463 minecraft:cyan_terracotta
setblock 221 83 505 minecraft:cyan_terracotta
fill 223 83 505 224 83 505 minecraft:cyan_terracotta
fill 227 83 463 227 84 463 minecraft:cyan_terracotta
setblock 230 83 464 minecraft:cyan_terracotta
fill 230 83 466 230 83 467 minecraft:cyan_terracotta
fill 188 84 464 188 85 468 minecraft:light_gray_terracotta
fill 188 84 470 188 192 470 minecraft:light_gray_terracotta
fill 188 84 471 188 84 472 minecraft:cyan_terracotta
fill 188 84 473 188 84 475 minecraft:light_gray_terracotta
setblock 188 84 476 minecraft:cyan_terracotta
fill 188 84 477 188 85 481 minecraft:light_gray_terracotta
setblock 188 84 482 minecraft:cyan_terracotta
fill 188 84 483 188 85 498 minecraft:light_gray_terracotta
setblock 188 84 499 minecraft:cyan_terracotta
fill 188 84 500 188 87 501 minecraft:light_gray_terracotta
setblock 188 84 502 minecraft:cyan_terracotta
fill 188 84 503 188 85 505 minecraft:light_gray_terracotta
fill 189 84 463 205 84 463 minecraft:light_gray_terracotta
fill 189 84 464 189 85 469 minecraft:light_gray_concrete
fill 189 84 472 190 84 477 minecraft:light_gray_concrete
fill 189 84 480 190 84 485 minecraft:light_gray_concrete
fill 189 84 488 190 84 493 minecraft:light_gray_concrete
fill 189 84 496 190 84 501 minecraft:light_gray_concrete
fill 189 84 504 194 85 504 minecraft:light_gray_concrete
fill 189 84 505 219 84 505 minecraft:light_gray_terracotta
fill 190 84 465 190 84 471 minecraft:light_gray_concrete
fill 190 84 478 190 84 479 minecraft:light_gray_concrete
fill 190 84 486 190 84 487 minecraft:light_gray_concrete
fill 190 84 494 190 84 495 minecraft:light_gray_concrete
fill 190 84 502 190 84 503 minecraft:light_gray_concrete
fill 191 84 465 192 84 465 minecraft:light_gray_concrete
fill 191 84 503 229 84 503 minecraft:light_gray_concrete
fill 192 84 464 192 85 464 minecraft:light_gray_concrete
fill 195 84 467 197 131 467 minecraft:iron_block
fill 196 84 466 196 131 466 minecraft:iron_block
fill 196 84 468 196 131 468 minecraft:iron_block
fill 197 84 504 202 85 504 minecraft:light_gray_concrete
fill 202 84 464 205 84 465 minecraft:light_gray_concrete
fill 205 84 504 210 85 504 minecraft:light_gray_concrete
setblock 206 84 463 minecraft:cyan_terracotta
setblock 206 84 465 minecraft:light_gray_concrete
fill 207 84 463 209 195 463 minecraft:light_gray_terracotta
fill 211 84 463 212 87 463 minecraft:light_gray_terracotta
fill 211 84 467 211 131 467 minecraft:iron_block
fill 213 84 504 218 85 504 minecraft:light_gray_concrete
fill 214 84 463 226 84 463 minecraft:light_gray_terracotta
fill 216 84 464 221 84 465 minecraft:light_gray_concrete
setblock 220 84 505 minecraft:cyan_terracotta
fill 221 84 504 226 85 504 minecraft:light_gray_concrete
fill 221 84 505 226 85 505 minecraft:light_gray_terracotta
fill 222 84 465 228 84 465 minecraft:light_gray_concrete
fill 224 84 464 229 85 464 minecraft:light_gray_concrete
setblock 227 84 505 minecraft:cyan_terracotta
fill 228 84 463 229 191 463 minecraft:light_gray_terracotta
fill 228 84 466 228 84 502 minecraft:light_gray_concrete
fill 228 84 505 230 192 505 minecraft:light_gray_terracotta
fill 229 84 467 229 85 472 minecraft:light_gray_concrete
fill 229 84 475 229 85 480 minecraft:light_gray_concrete
fill 229 84 483 229 85 488 minecraft:light_gray_concrete
fill 229 84 491 229 85 496 minecraft:light_gray_concrete
fill 229 84 499 229 85 502 minecraft:light_gray_concrete
fill 229 84 504 229 85 504 minecraft:light_gray_concrete
setblock 230 84 463 minecraft:cyan_terracotta
fill 230 84 464 230 87 474 minecraft:light_gray_terracotta
fill 230 84 476 230 84 483 minecraft:light_gray_terracotta
fill 230 84 485 230 84 495 minecraft:light_gray_terracotta
setblock 230 84 496 minecraft:cyan_terracotta
fill 230 84 497 230 84 504 minecraft:light_gray_terracotta
fill 188 85 469 188 195 469 minecraft:light_gray_terracotta
fill 188 85 471 188 192 471 minecraft:light_gray_terracotta
setblock 188 85 472 minecraft:cyan_terracotta
fill 188 85 473 188 192 473 minecraft:light_gray_terracotta
fill 188 85 474 188 85 475 minecraft:cyan_terracotta
fill 188 85 476 188 87 476 minecraft:light_gray_terracotta
fill 188 85 482 188 193 482 minecraft:light_gray_terracotta
fill 188 85 499 188 191 499 minecraft:light_gray_terracotta
fill 188 85 502 188 195 502 minecraft:light_gray_terracotta
fill 189 85 463 195 85 463 minecraft:light_gray_terracotta
fill 189 85 472 189 85 477 minecraft:light_gray_concrete
fill 189 85 480 189 85 485 minecraft:light_gray_concrete
fill 189 85 488 189 85 493 minecraft:light_gray_concrete
fill 189 85 496 189 85 501 minecraft:light_gray_concrete
fill 189 85 505 200 85 505 minecraft:light_gray_terracotta
setblock 191 85 466 minecraft:light[level=11]
setblock 191 85 474 minecraft:light[level=11]
setblock 191 85 482 minecraft:light[level=11]
setblock 191 85 490 minecraft:light[level=11]
setblock 191 85 498 minecraft:light[level=11]
setblock 196 85 463 minecraft:cyan_terracotta
fill 197 85 463 203 85 463 minecraft:light_gray_terracotta
setblock 199 85 466 minecraft:light[level=11]
setblock 199 85 474 minecraft:light[level=11]
setblock 199 85 482 minecraft:light[level=11]
setblock 199 85 490 minecraft:light[level=11]
setblock 199 85 498 minecraft:light[level=11]
setblock 201 85 505 minecraft:cyan_terracotta
fill 202 85 464 205 85 464 minecraft:light_gray_concrete
fill 202 85 505 213 85 505 minecraft:light_gray_terracotta
setblock 204 85 463 minecraft:cyan_terracotta
fill 205 85 463 206 191 463 minecraft:light_gray_terracotta
setblock 207 85 466 minecraft:light[level=11]
setblock 207 85 474 minecraft:light[level=11]
setblock 207 85 482 minecraft:light[level=11]
setblock 207 85 490 minecraft:light[level=11]
setblock 207 85 498 minecraft:light[level=11]
fill 210 85 463 210 196 463 minecraft:light_gray_terracotta
fill 213 85 463 213 195 463 minecraft:light_gray_terracotta
setblock 214 85 463 minecraft:cyan_terracotta
setblock 214 85 505 minecraft:cyan_terracotta
fill 215 85 463 227 85 463 minecraft:light_gray_terracotta
setblock 215 85 466 minecraft:light[level=11]
setblock 215 85 474 minecraft:light[level=11]
setblock 215 85 482 minecraft:light[level=11]
setblock 215 85 490 minecraft:light[level=11]
setblock 215 85 498 minecraft:light[level=11]
fill 215 85 505 220 85 505 minecraft:light_gray_terracotta
fill 216 85 464 221 85 464 minecraft:light_gray_concrete
setblock 223 85 466 minecraft:light[level=11]
setblock 223 85 474 minecraft:light[level=11]
setblock 223 85 482 minecraft:light[level=11]
setblock 223 85 490 minecraft:light[level=11]
setblock 223 85 498 minecraft:light[level=11]
fill 227 85 505 227 195 505 minecraft:light_gray_terracotta
setblock 229 85 503 minecraft:light_gray_concrete
setblock 230 85 463 minecraft:light_gray_terracotta
fill 230 85 475 230 87 478 minecraft:light_gray_terracotta
setblock 230 85 479 minecraft:cyan_terracotta
fill 230 85 480 230 87 493 minecraft:light_gray_terracotta
setblock 230 85 494 minecraft:cyan_terracotta
fill 230 85 495 230 87 502 minecraft:light_gray_terracotta
setblock 230 85 503 minecraft:cyan_terracotta
fill 230 85 504 230 195 504 minecraft:light_gray_terracotta
fill 188 86 463 188 192 466 minecraft:light_gray_terracotta
setblock 188 86 467 minecraft:cyan_terracotta
fill 188 86 468 188 87 468 minecraft:light_gray_terracotta
fill 188 86 472 188 195 472 minecraft:light_gray_terracotta
fill 188 86 474 188 191 475 minecraft:light_gray_terracotta
setblock 188 86 477 minecraft:cyan_terracotta
fill 188 86 478 188 193 481 minecraft:light_gray_terracotta
setblock 188 86 483 minecraft:cyan_terracotta
fill 188 86 484 188 87 496 minecraft:light_gray_terracotta
setblock 188 86 497 minecraft:cyan_terracotta
fill 188 86 498 188 195 498 minecraft:light_gray_terracotta
setblock 188 86 503 minecraft:cyan_terracotta
fill 188 86 504 188 196 504 minecraft:light_gray_terracotta
setblock 188 86 505 minecraft:cyan_terracotta
fill 189 86 463 190 86 463 minecraft:cyan_terracotta
fill 189 86 505 193 87 505 minecraft:light_gray_terracotta
fill 191 86 463 192 195 463 minecraft:light_gray_terracotta
setblock 193 86 463 minecraft:cyan_terracotta
fill 194 86 463 199 87 463 minecraft:light_gray_terracotta
setblock 194 86 505 minecraft:cyan_terracotta
fill 195 86 505 198 191 505 minecraft:light_gray_terracotta
setblock 199 86 505 minecraft:cyan_terracotta
setblock 200 86 463 minecraft:cyan_terracotta
fill 200 86 505 203 192 505 minecraft:light_gray_terracotta
fill 201 86 463 204 87 463 minecraft:light_gray_terracotta
setblock 204 86 505 minecraft:cyan_terracotta
fill 205 86 505 216 87 505 minecraft:light_gray_terracotta
fill 214 86 463 222 87 463 minecraft:light_gray_terracotta
setblock 217 86 505 minecraft:cyan_terracotta
fill 218 86 505 219 195 505 minecraft:light_gray_terracotta
setblock 220 86 505 minecraft:cyan_terracotta
fill 221 86 505 221 193 505 minecraft:light_gray_terracotta
setblock 222 86 505 minecraft:cyan_terracotta
setblock 223 86 463 minecraft:cyan_terracotta
fill 223 86 505 226 87 505 minecraft:light_gray_terracotta
fill 224 86 463 226 191 463 minecraft:light_gray_terracotta
setblock 225 86 489 minecraft:light_gray_concrete
setblock 225 86 491 minecraft:light_gray_concrete
setblock 227 86 463 minecraft:cyan_terracotta
setblock 227 86 489 minecraft:light_gray_concrete
setblock 227 86 491 minecraft:light_gray_concrete
setblock 230 86 463 minecraft:cyan_terracotta
fill 230 86 479 230 192 479 minecraft:light_gray_terracotta
fill 230 86 494 230 191 494 minecraft:light_gray_terracotta
fill 230 86 503 230 195 503 minecraft:light_gray_terracotta
fill 188 87 467 188 192 467 minecraft:light_gray_terracotta
fill 188 87 477 188 192 477 minecraft:light_gray_terracotta
fill 188 87 483 188 193 483 minecraft:light_gray_terracotta
fill 188 87 497 188 193 497 minecraft:light_gray_terracotta
fill 188 87 503 188 195 503 minecraft:light_gray_terracotta
fill 188 87 505 188 195 505 minecraft:light_gray_terracotta
fill 189 87 463 190 195 463 minecraft:light_gray_terracotta
fill 193 87 463 193 193 463 minecraft:light_gray_terracotta
fill 194 87 505 194 192 505 minecraft:light_gray_terracotta
setblock 199 87 505 minecraft:light_gray_terracotta
fill 200 87 463 200 192 463 minecraft:light_gray_terracotta
fill 204 87 505 204 195 505 minecraft:light_gray_terracotta
fill 217 87 505 217 195 505 minecraft:light_gray_terracotta
fill 220 87 505 220 195 505 minecraft:light_gray_terracotta
fill 222 87 505 222 195 505 minecraft:light_gray_terracotta
fill 223 87 463 223 195 463 minecraft:light_gray_terracotta
setblock 227 87 463 minecraft:light_gray_terracotta
fill 230 87 463 230 192 463 minecraft:light_gray_terracotta
fill 188 88 468 188 93 468 minecraft:pearlescent_froglight
fill 188 88 476 188 93 476 minecraft:pearlescent_froglight
fill 188 88 484 188 93 484 minecraft:pearlescent_froglight
fill 188 88 485 188 193 491 minecraft:light_gray_terracotta
fill 188 88 492 188 93 492 minecraft:pearlescent_froglight
fill 188 88 493 188 191 496 minecraft:light_gray_terracotta
fill 188 88 500 188 93 500 minecraft:pearlescent_froglight
fill 188 88 501 188 195 501 minecraft:light_gray_terracotta
fill 189 88 505 190 193 505 minecraft:light_gray_terracotta
fill 191 88 505 191 93 505 minecraft:pearlescent_froglight
fill 192 88 505 193 195 505 minecraft:light_gray_terracotta
fill 194 88 463 194 195 463 minecraft:light_gray_terracotta
fill 195 88 463 195 93 463 minecraft:pearlescent_froglight
fill 196 88 463 199 191 463 minecraft:light_gray_terracotta
fill 199 88 505 199 93 505 minecraft:pearlescent_froglight
fill 201 88 463 202 193 463 minecraft:light_gray_terracotta
fill 203 88 463 203 93 463 minecraft:pearlescent_froglight
fill 204 88 463 204 192 463 minecraft:light_gray_terracotta
fill 205 88 505 206 192 505 minecraft:light_gray_terracotta
fill 207 88 505 207 93 505 minecraft:pearlescent_froglight
fill 208 88 505 214 192 505 minecraft:light_gray_terracotta
fill 210 88 466 210 88 468 minecraft:light_gray_concrete
fill 211 88 463 211 93 463 minecraft:pearlescent_froglight
fill 211 88 466 212 88 466 minecraft:light_gray_concrete
fill 211 88 468 212 88 468 minecraft:light_gray_concrete
fill 212 88 463 212 193 463 minecraft:light_gray_terracotta
setblock 212 88 467 minecraft:light_gray_concrete
fill 214 88 463 218 192 463 minecraft:light_gray_terracotta
fill 215 88 505 215 93 505 minecraft:pearlescent_froglight
fill 216 88 505 216 191 505 minecraft:light_gray_terracotta
fill 219 88 463 219 93 463 minecraft:pearlescent_froglight
fill 220 88 463 222 192 463 minecraft:light_gray_terracotta
fill 223 88 505 223 93 505 minecraft:pearlescent_froglight
fill 224 88 505 226 195 505 minecraft:light_gray_terracotta
fill 227 88 463 227 93 463 minecraft:pearlescent_froglight
fill 230 88 464 230 193 467 minecraft:light_gray_terracotta
fill 230 88 468 230 93 468 minecraft:pearlescent_froglight
fill 230 88 469 230 150 475 minecraft:light_gray_terracotta
fill 230 88 476 230 93 476 minecraft:pearlescent_froglight
fill 230 88 477 230 195 478 minecraft:light_gray_terracotta
fill 230 88 480 230 192 483 minecraft:light_gray_terracotta
fill 230 88 484 230 93 484 minecraft:pearlescent_froglight
fill 230 88 485 230 191 491 minecraft:light_gray_terracotta
fill 230 88 492 230 93 492 minecraft:pearlescent_froglight
fill 230 88 493 230 195 493 minecraft:light_gray_terracotta
fill 230 88 495 230 192 499 minecraft:light_gray_terracotta
fill 230 88 500 230 93 500 minecraft:pearlescent_froglight
fill 230 88 501 230 150 502 minecraft:light_gray_terracotta
setblock 195 91 466 minecraft:light_gray_concrete
setblock 195 91 468 minecraft:light_gray_concrete
setblock 197 91 466 minecraft:light_gray_concrete
setblock 197 91 468 minecraft:light_gray_concrete
fill 226 91 481 226 92 482 minecraft:red_concrete
setblock 191 93 466 minecraft:light[level=11]
setblock 191 93 474 minecraft:light[level=11]
setblock 191 93 482 minecraft:light[level=11]
setblock 191 93 490 minecraft:light[level=11]
setblock 191 93 498 minecraft:light[level=11]
setblock 199 93 466 minecraft:light[level=11]
setblock 199 93 474 minecraft:light[level=11]
setblock 199 93 482 minecraft:light[level=11]
setblock 199 93 490 minecraft:light[level=11]
setblock 199 93 498 minecraft:light[level=11]
setblock 207 93 466 minecraft:light[level=11]
setblock 207 93 474 minecraft:light[level=11]
setblock 207 93 482 minecraft:light[level=11]
setblock 207 93 490 minecraft:light[level=11]
setblock 207 93 498 minecraft:light[level=11]
setblock 215 93 466 minecraft:light[level=11]
setblock 215 93 474 minecraft:light[level=11]
setblock 215 93 482 minecraft:light[level=11]
setblock 215 93 490 minecraft:light[level=11]
setblock 215 93 498 minecraft:light[level=11]
setblock 223 93 466 minecraft:light[level=11]
setblock 223 93 474 minecraft:light[level=11]
setblock 223 93 482 minecraft:light[level=11]
setblock 223 93 490 minecraft:light[level=11]
setblock 223 93 498 minecraft:light[level=11]
fill 228 93 490 228 94 490 minecraft:iron_block
fill 188 94 468 188 101 468 minecraft:light_gray_terracotta
fill 188 94 476 188 101 476 minecraft:light_gray_terracotta
fill 188 94 484 188 101 484 minecraft:light_gray_terracotta
fill 188 94 492 188 101 492 minecraft:light_gray_terracotta
fill 188 94 500 188 101 500 minecraft:light_gray_terracotta
fill 191 94 505 191 101 505 minecraft:light_gray_terracotta
fill 195 94 463 195 101 463 minecraft:light_gray_terracotta
fill 199 94 505 199 101 505 minecraft:light_gray_terracotta
fill 203 94 463 203 101 463 minecraft:light_gray_terracotta
fill 207 94 505 207 101 505 minecraft:light_gray_terracotta
fill 210 94 466 210 94 468 minecraft:light_gray_concrete
fill 211 94 463 211 101 463 minecraft:light_gray_terracotta
fill 211 94 466 212 94 466 minecraft:light_gray_concrete
fill 211 94 468 212 94 468 minecraft:light_gray_concrete
setblock 212 94 467 minecraft:light_gray_concrete
fill 215 94 505 215 101 505 minecraft:light_gray_terracotta
fill 219 94 463 219 101 463 minecraft:light_gray_terracotta
fill 223 94 505 223 101 505 minecraft:light_gray_terracotta
setblock 224 94 490 minecraft:pearlescent_froglight
setblock 225 94 489 minecraft:light_gray_concrete
setblock 225 94 491 minecraft:light_gray_concrete
fill 227 94 463 227 101 463 minecraft:light_gray_terracotta
fill 227 94 478 227 106 478 minecraft:light_blue_wool
setblock 227 94 489 minecraft:light_gray_concrete
setblock 227 94 491 minecraft:light_gray_concrete
fill 230 94 468 230 101 468 minecraft:light_gray_terracotta
fill 230 94 476 230 101 476 minecraft:light_gray_terracotta
fill 230 94 484 230 101 484 minecraft:light_gray_terracotta
fill 230 94 492 230 101 492 minecraft:light_gray_terracotta
fill 230 94 500 230 101 500 minecraft:light_gray_terracotta
fill 227 95 476 227 106 477 minecraft:light_blue_wool
fill 227 95 479 227 106 480 minecraft:light_blue_wool
fill 223 96 495 223 110 495 minecraft:iron_block
fill 189 98 464 189 99 469 minecraft:light_gray_concrete
fill 189 98 472 190 98 477 minecraft:light_gray_concrete
fill 189 98 480 190 98 485 minecraft:light_gray_concrete
fill 189 98 488 190 98 493 minecraft:light_gray_concrete
fill 189 98 496 190 98 501 minecraft:light_gray_concrete
fill 189 98 504 194 99 504 minecraft:light_gray_concrete
fill 190 98 465 190 98 471 minecraft:light_gray_concrete
fill 190 98 478 190 98 479 minecraft:light_gray_concrete
fill 190 98 486 190 98 487 minecraft:light_gray_concrete
fill 190 98 494 190 98 495 minecraft:light_gray_concrete
fill 190 98 502 190 98 503 minecraft:light_gray_concrete
fill 191 98 465 228 98 465 minecraft:light_gray_concrete
fill 191 98 503 229 98 503 minecraft:light_gray_concrete
fill 192 98 464 197 99 464 minecraft:light_gray_concrete
setblock 195 98 466 minecraft:light_gray_concrete
setblock 195 98 468 minecraft:light_gray_concrete
setblock 197 98 466 minecraft:light_gray_concrete
setblock 197 98 468 minecraft:light_gray_concrete
fill 197 98 504 202 99 504 minecraft:light_gray_concrete
fill 200 98 464 205 99 464 minecraft:light_gray_concrete
fill 205 98 504 210 99 504 minecraft:light_gray_concrete
fill 208 98 464 213 99 464 minecraft:light_gray_concrete
fill 213 98 504 218 99 504 minecraft:light_gray_concrete
fill 216 98 464 221 99 464 minecraft:light_gray_concrete
fill 221 98 504 226 99 504 minecraft:light_gray_concrete
fill 224 98 464 229 99 464 minecraft:light_gray_concrete
fill 228 98 466 228 98 502 minecraft:light_gray_concrete
fill 229 98 467 229 99 472 minecraft:light_gray_concrete
fill 229 98 475 229 99 480 minecraft:light_gray_concrete
fill 229 98 483 229 99 488 minecraft:light_gray_concrete
fill 229 98 491 229 99 496 minecraft:light_gray_concrete
fill 229 98 499 229 99 502 minecraft:light_gray_concrete
fill 229 98 504 229 99 504 minecraft:light_gray_concrete
fill 189 99 472 189 99 477 minecraft:light_gray_concrete
fill 189 99 480 189 99 485 minecraft:light_gray_concrete
fill 189 99 488 189 99 493 minecraft:light_gray_concrete
fill 189 99 496 189 99 501 minecraft:light_gray_concrete
setblock 229 99 503 minecraft:light_gray_concrete
fill 210 100 466 210 100 468 minecraft:light_gray_concrete
fill 211 100 466 212 100 466 minecraft:light_gray_concrete
fill 211 100 468 212 100 468 minecraft:light_gray_concrete
setblock 212 100 467 minecraft:light_gray_concrete
setblock 191 101 466 minecraft:light[level=11]
setblock 191 101 474 minecraft:light[level=11]
setblock 191 101 482 minecraft:light[level=11]
setblock 191 101 490 minecraft:light[level=11]
setblock 191 101 498 minecraft:light[level=11]
setblock 199 101 466 minecraft:light[level=11]
setblock 199 101 474 minecraft:light[level=11]
setblock 199 101 482 minecraft:light[level=11]
setblock 199 101 490 minecraft:light[level=11]
setblock 199 101 498 minecraft:light[level=11]
setblock 207 101 466 minecraft:light[level=11]
setblock 207 101 474 minecraft:light[level=11]
setblock 207 101 482 minecraft:light[level=11]
setblock 207 101 490 minecraft:light[level=11]
setblock 207 101 498 minecraft:light[level=11]
setblock 215 101 466 minecraft:light[level=11]
setblock 215 101 474 minecraft:light[level=11]
setblock 215 101 482 minecraft:light[level=11]
setblock 215 101 490 minecraft:light[level=11]
setblock 215 101 498 minecraft:light[level=11]
setblock 223 101 466 minecraft:light[level=11]
setblock 223 101 474 minecraft:light[level=11]
setblock 223 101 482 minecraft:light[level=11]
setblock 223 101 490 minecraft:light[level=11]
setblock 223 101 498 minecraft:light[level=11]
fill 188 102 468 188 107 468 minecraft:pearlescent_froglight
fill 188 102 476 188 107 476 minecraft:pearlescent_froglight
fill 188 102 484 188 107 484 minecraft:pearlescent_froglight
fill 188 102 492 188 107 492 minecraft:pearlescent_froglight
fill 188 102 500 188 107 500 minecraft:pearlescent_froglight
fill 191 102 505 191 107 505 minecraft:pearlescent_froglight
fill 195 102 463 195 107 463 minecraft:pearlescent_froglight
fill 199 102 505 199 107 505 minecraft:pearlescent_froglight
fill 203 102 463 203 107 463 minecraft:pearlescent_froglight
fill 207 102 505 207 107 505 minecraft:pearlescent_froglight
fill 211 102 463 211 107 463 minecraft:pearlescent_froglight
fill 215 102 505 215 107 505 minecraft:pearlescent_froglight
fill 219 102 463 219 107 463 minecraft:pearlescent_froglight
fill 223 102 505 223 107 505 minecraft:pearlescent_froglight
setblock 225 102 489 minecraft:light_gray_concrete
setblock 225 102 491 minecraft:light_gray_concrete
fill 227 102 463 227 107 463 minecraft:pearlescent_froglight
setblock 227 102 489 minecraft:light_gray_concrete
setblock 227 102 491 minecraft:light_gray_concrete
fill 230 102 468 230 107 468 minecraft:pearlescent_froglight
fill 230 102 476 230 107 476 minecraft:pearlescent_froglight
fill 230 102 484 230 107 484 minecraft:pearlescent_froglight
fill 230 102 492 230 107 492 minecraft:pearlescent_froglight
fill 230 102 500 230 107 500 minecraft:pearlescent_froglight
setblock 195 105 466 minecraft:light_gray_concrete
setblock 195 105 468 minecraft:light_gray_concrete
setblock 197 105 466 minecraft:light_gray_concrete
setblock 197 105 468 minecraft:light_gray_concrete
fill 220 105 480 222 106 480 minecraft:white_wool
fill 221 105 479 222 106 479 minecraft:white_wool
fill 210 106 466 210 106 468 minecraft:light_gray_concrete
fill 211 106 466 212 106 466 minecraft:light_gray_concrete
fill 211 106 468 212 106 468 minecraft:light_gray_concrete
setblock 212 106 467 minecraft:light_gray_concrete
fill 227 107 475 227 108 481 minecraft:iron_block
fill 188 108 468 188 115 468 minecraft:light_gray_terracotta
fill 188 108 476 188 115 476 minecraft:light_gray_terracotta
fill 188 108 484 188 115 484 minecraft:light_gray_terracotta
fill 188 108 492 188 115 492 minecraft:light_gray_terracotta
fill 188 108 500 188 115 500 minecraft:light_gray_terracotta
fill 191 108 505 191 115 505 minecraft:light_gray_terracotta
fill 195 108 463 195 115 463 minecraft:light_gray_terracotta
fill 199 108 505 199 115 505 minecraft:light_gray_terracotta
fill 203 108 463 203 115 463 minecraft:light_gray_terracotta
fill 207 108 505 207 115 505 minecraft:light_gray_terracotta
fill 211 108 463 211 115 463 minecraft:light_gray_terracotta
fill 215 108 505 215 115 505 minecraft:light_gray_terracotta
fill 219 108 463 219 115 463 minecraft:light_gray_terracotta
fill 223 108 505 223 115 505 minecraft:light_gray_terracotta
fill 227 108 463 227 115 463 minecraft:light_gray_terracotta
fill 230 108 468 230 115 468 minecraft:light_gray_terracotta
fill 230 108 476 230 115 476 minecraft:light_gray_terracotta
fill 230 108 484 230 115 484 minecraft:light_gray_terracotta
fill 230 108 492 230 115 492 minecraft:light_gray_terracotta
fill 230 108 500 230 115 500 minecraft:light_gray_terracotta
setblock 191 109 466 minecraft:light[level=11]
setblock 191 109 474 minecraft:light[level=11]
setblock 191 109 482 minecraft:light[level=11]
setblock 191 109 490 minecraft:light[level=11]
setblock 191 109 498 minecraft:light[level=11]
setblock 199 109 466 minecraft:light[level=11]
setblock 199 109 474 minecraft:light[level=11]
setblock 199 109 482 minecraft:light[level=11]
setblock 199 109 490 minecraft:light[level=11]
setblock 199 109 498 minecraft:light[level=11]
setblock 207 109 466 minecraft:light[level=11]
setblock 207 109 474 minecraft:light[level=11]
setblock 207 109 482 minecraft:light[level=11]
setblock 207 109 490 minecraft:light[level=11]
setblock 207 109 498 minecraft:light[level=11]
setblock 215 109 466 minecraft:light[level=11]
setblock 215 109 474 minecraft:light[level=11]
setblock 215 109 482 minecraft:light[level=11]
setblock 215 109 490 minecraft:light[level=11]
setblock 215 109 498 minecraft:light[level=11]
setblock 223 109 466 minecraft:light[level=11]
setblock 223 109 474 minecraft:light[level=11]
setblock 223 109 482 minecraft:light[level=11]
setblock 223 109 490 minecraft:light[level=11]
setblock 223 109 498 minecraft:light[level=11]
setblock 225 110 489 minecraft:light_gray_concrete
setblock 225 110 491 minecraft:light_gray_concrete
setblock 227 110 489 minecraft:light_gray_concrete
setblock 227 110 491 minecraft:light_gray_concrete
fill 189 112 464 189 113 469 minecraft:light_gray_concrete
fill 189 112 472 190 112 477 minecraft:light_gray_concrete
fill 189 112 480 190 112 485 minecraft:light_gray_concrete
fill 189 112 488 190 112 493 minecraft:light_gray_concrete
fill 189 112 496 190 112 501 minecraft:light_gray_concrete
fill 189 112 504 194 113 504 minecraft:light_gray_concrete
fill 190 112 465 190 112 471 minecraft:light_gray_concrete
fill 190 112 478 190 112 479 minecraft:light_gray_concrete
fill 190 112 486 190 112 487 minecraft:light_gray_concrete
fill 190 112 494 190 112 495 minecraft:light_gray_concrete
fill 190 112 502 190 112 503 minecraft:light_gray_concrete
fill 191 112 465 228 112 465 minecraft:light_gray_concrete
fill 191 112 503 229 112 503 minecraft:light_gray_concrete
fill 192 112 464 197 113 464 minecraft:light_gray_concrete
setblock 195 112 466 minecraft:light_gray_concrete
setblock 195 112 468 minecraft:light_gray_concrete
setblock 197 112 466 minecraft:light_gray_concrete
setblock 197 112 468 minecraft:light_gray_concrete
fill 197 112 504 202 113 504 minecraft:light_gray_concrete
fill 200 112 464 205 113 464 minecraft:light_gray_concrete
fill 205 112 504 210 113 504 minecraft:light_gray_concrete
fill 208 112 464 213 113 464 minecraft:light_gray_concrete
fill 210 112 466 210 112 468 minecraft:light_gray_concrete
fill 211 112 466 212 112 466 minecraft:light_gray_concrete
fill 211 112 468 212 112 468 minecraft:light_gray_concrete
setblock 212 112 467 minecraft:light_gray_concrete
fill 213 112 504 218 113 504 minecraft:light_gray_concrete
fill 216 112 464 221 113 464 minecraft:light_gray_concrete
fill 221 112 504 226 113 504 minecraft:light_gray_concrete
fill 224 112 464 229 113 464 minecraft:light_gray_concrete
fill 228 112 466 228 112 502 minecraft:light_gray_concrete
fill 229 112 467 229 113 472 minecraft:light_gray_concrete
fill 229 112 475 229 113 480 minecraft:light_gray_concrete
fill 229 112 483 229 113 488 minecraft:light_gray_concrete
fill 229 112 491 229 113 496 minecraft:light_gray_concrete
fill 229 112 499 229 113 502 minecraft:light_gray_concrete
fill 229 112 504 229 113 504 minecraft:light_gray_concrete
fill 189 113 472 189 113 477 minecraft:light_gray_concrete
fill 189 113 480 189 113 485 minecraft:light_gray_concrete
fill 189 113 488 189 113 493 minecraft:light_gray_concrete
fill 189 113 496 189 113 501 minecraft:light_gray_concrete
setblock 229 113 503 minecraft:light_gray_concrete
fill 188 116 468 188 121 468 minecraft:pearlescent_froglight
fill 188 116 476 188 121 476 minecraft:pearlescent_froglight
fill 188 116 484 188 121 484 minecraft:pearlescent_froglight
fill 188 116 492 188 121 492 minecraft:pearlescent_froglight
fill 188 116 500 188 121 500 minecraft:pearlescent_froglight
fill 191 116 505 191 121 505 minecraft:pearlescent_froglight
fill 195 116 463 195 121 463 minecraft:pearlescent_froglight
fill 199 116 505 199 121 505 minecraft:pearlescent_froglight
fill 203 116 463 203 121 463 minecraft:pearlescent_froglight
fill 207 116 505 207 121 505 minecraft:pearlescent_froglight
fill 211 116 463 211 121 463 minecraft:pearlescent_froglight
fill 215 116 505 215 121 505 minecraft:pearlescent_froglight
fill 219 116 463 219 121 463 minecraft:pearlescent_froglight
fill 223 116 505 223 121 505 minecraft:pearlescent_froglight
fill 227 116 463 227 121 463 minecraft:pearlescent_froglight
fill 230 116 468 230 121 468 minecraft:pearlescent_froglight
fill 230 116 476 230 121 476 minecraft:pearlescent_froglight
fill 230 116 484 230 121 484 minecraft:pearlescent_froglight
fill 230 116 492 230 121 492 minecraft:pearlescent_froglight
fill 230 116 500 230 121 500 minecraft:pearlescent_froglight
setblock 191 117 466 minecraft:light[level=11]
setblock 191 117 474 minecraft:light[level=11]
setblock 191 117 482 minecraft:light[level=11]
setblock 191 117 490 minecraft:light[level=11]
setblock 191 117 498 minecraft:light[level=11]
setblock 199 117 466 minecraft:light[level=11]
setblock 199 117 474 minecraft:light[level=11]
setblock 199 117 482 minecraft:light[level=11]
setblock 199 117 490 minecraft:light[level=11]
setblock 199 117 498 minecraft:light[level=11]
setblock 207 117 466 minecraft:light[level=11]
setblock 207 117 474 minecraft:light[level=11]
setblock 207 117 482 minecraft:light[level=11]
setblock 207 117 490 minecraft:light[level=11]
setblock 207 117 498 minecraft:light[level=11]
setblock 215 117 466 minecraft:light[level=11]
setblock 215 117 474 minecraft:light[level=11]
setblock 215 117 482 minecraft:light[level=11]
setblock 215 117 490 minecraft:light[level=11]
setblock 215 117 498 minecraft:light[level=11]
setblock 223 117 466 minecraft:light[level=11]
setblock 223 117 474 minecraft:light[level=11]
setblock 223 117 482 minecraft:light[level=11]
setblock 223 117 490 minecraft:light[level=11]
setblock 223 117 498 minecraft:light[level=11]
fill 210 118 466 210 118 468 minecraft:light_gray_concrete
fill 211 118 466 212 118 466 minecraft:light_gray_concrete
fill 211 118 468 212 118 468 minecraft:light_gray_concrete
setblock 212 118 467 minecraft:light_gray_concrete
setblock 225 118 489 minecraft:light_gray_concrete
setblock 225 118 491 minecraft:light_gray_concrete
setblock 227 118 489 minecraft:light_gray_concrete
setblock 227 118 491 minecraft:light_gray_concrete
setblock 195 119 466 minecraft:light_gray_concrete
setblock 195 119 468 minecraft:light_gray_concrete
setblock 197 119 466 minecraft:light_gray_concrete
setblock 197 119 468 minecraft:light_gray_concrete
fill 211 119 464 211 120 466 minecraft:iron_block
setblock 211 120 468 minecraft:pearlescent_froglight
fill 188 122 468 188 129 468 minecraft:light_gray_terracotta
fill 188 122 476 188 129 476 minecraft:light_gray_terracotta
fill 188 122 484 188 129 484 minecraft:light_gray_terracotta
fill 188 122 492 188 129 492 minecraft:light_gray_terracotta
fill 188 122 500 188 129 500 minecraft:light_gray_terracotta
fill 191 122 505 191 129 505 minecraft:light_gray_terracotta
fill 195 122 463 195 129 463 minecraft:light_gray_terracotta
fill 199 122 505 199 129 505 minecraft:light_gray_terracotta
fill 203 122 463 203 129 463 minecraft:light_gray_terracotta
fill 207 122 505 207 129 505 minecraft:light_gray_terracotta
fill 211 122 463 211 129 463 minecraft:light_gray_terracotta
fill 215 122 505 215 129 505 minecraft:light_gray_terracotta
fill 219 122 463 219 129 463 minecraft:light_gray_terracotta
fill 223 122 505 223 129 505 minecraft:light_gray_terracotta
fill 227 122 463 227 129 463 minecraft:light_gray_terracotta
fill 230 122 468 230 129 468 minecraft:light_gray_terracotta
fill 230 122 476 230 129 476 minecraft:light_gray_terracotta
fill 230 122 484 230 129 484 minecraft:light_gray_terracotta
fill 230 122 492 230 129 492 minecraft:light_gray_terracotta
fill 230 122 500 230 129 500 minecraft:light_gray_terracotta
fill 210 124 466 210 124 468 minecraft:light_gray_concrete
fill 211 124 466 212 124 466 minecraft:light_gray_concrete
fill 211 124 468 212 124 468 minecraft:light_gray_concrete
setblock 212 124 467 minecraft:light_gray_concrete
setblock 191 125 466 minecraft:light[level=11]
setblock 191 125 474 minecraft:light[level=11]
setblock 191 125 482 minecraft:light[level=11]
setblock 191 125 490 minecraft:light[level=11]
setblock 191 125 498 minecraft:light[level=11]
setblock 199 125 466 minecraft:light[level=11]
setblock 199 125 474 minecraft:light[level=11]
setblock 199 125 482 minecraft:light[level=11]
setblock 199 125 490 minecraft:light[level=11]
setblock 199 125 498 minecraft:light[level=11]
setblock 207 125 466 minecraft:light[level=11]
setblock 207 125 474 minecraft:light[level=11]
setblock 207 125 482 minecraft:light[level=11]
setblock 207 125 490 minecraft:light[level=11]
setblock 207 125 498 minecraft:light[level=11]
setblock 215 125 466 minecraft:light[level=11]
setblock 215 125 474 minecraft:light[level=11]
setblock 215 125 482 minecraft:light[level=11]
setblock 215 125 490 minecraft:light[level=11]
setblock 215 125 498 minecraft:light[level=11]
setblock 223 125 466 minecraft:light[level=11]
setblock 223 125 474 minecraft:light[level=11]
setblock 223 125 482 minecraft:light[level=11]
setblock 223 125 490 minecraft:light[level=11]
setblock 223 125 498 minecraft:light[level=11]
fill 189 126 464 189 127 469 minecraft:light_gray_concrete
fill 189 126 472 190 126 477 minecraft:light_gray_concrete
fill 189 126 480 190 126 485 minecraft:light_gray_concrete
fill 189 126 488 190 126 493 minecraft:light_gray_concrete
fill 189 126 496 190 126 501 minecraft:light_gray_concrete
fill 189 126 504 194 127 504 minecraft:light_gray_concrete
fill 190 126 465 190 126 471 minecraft:light_gray_concrete
fill 190 126 478 190 126 479 minecraft:light_gray_concrete
fill 190 126 486 190 126 487 minecraft:light_gray_concrete
fill 190 126 494 190 126 495 minecraft:light_gray_concrete
fill 190 126 502 190 126 503 minecraft:light_gray_concrete
fill 191 126 465 228 126 465 minecraft:light_gray_concrete
fill 191 126 503 229 126 503 minecraft:light_gray_concrete
fill 192 126 464 197 127 464 minecraft:light_gray_concrete
setblock 195 126 466 minecraft:light_gray_concrete
setblock 195 126 468 minecraft:light_gray_concrete
setblock 197 126 466 minecraft:light_gray_concrete
setblock 197 126 468 minecraft:light_gray_concrete
fill 197 126 504 202 127 504 minecraft:light_gray_concrete
fill 200 126 464 205 127 464 minecraft:light_gray_concrete
fill 205 126 504 210 127 504 minecraft:light_gray_concrete
fill 208 126 464 213 127 464 minecraft:light_gray_concrete
fill 213 126 504 218 127 504 minecraft:light_gray_concrete
fill 216 126 464 221 127 464 minecraft:light_gray_concrete
fill 221 126 504 226 127 504 minecraft:light_gray_concrete
fill 224 126 464 229 127 464 minecraft:light_gray_concrete
setblock 225 126 489 minecraft:light_gray_concrete
setblock 225 126 491 minecraft:light_gray_concrete
fill 227 126 489 228 126 489 minecraft:light_gray_concrete
fill 227 126 491 229 126 491 minecraft:light_gray_concrete
fill 228 126 466 228 126 488 minecraft:light_gray_concrete
setblock 228 126 490 minecraft:light_gray_concrete
fill 228 126 492 228 126 502 minecraft:light_gray_concrete
fill 229 126 467 229 127 472 minecraft:light_gray_concrete
fill 229 126 475 229 127 480 minecraft:light_gray_concrete
fill 229 126 483 229 127 488 minecraft:light_gray_concrete
fill 229 126 492 229 127 496 minecraft:light_gray_concrete
fill 229 126 499 229 127 502 minecraft:light_gray_concrete
fill 229 126 504 229 127 504 minecraft:light_gray_concrete
fill 189 127 472 189 127 477 minecraft:light_gray_concrete
fill 189 127 480 189 127 485 minecraft:light_gray_concrete
fill 189 127 488 189 127 493 minecraft:light_gray_concrete
fill 189 127 496 189 127 501 minecraft:light_gray_concrete
setblock 229 127 491 minecraft:light_gray_concrete
setblock 229 127 503 minecraft:light_gray_concrete
fill 188 130 468 188 131 468 minecraft:pearlescent_froglight
fill 188 130 476 188 131 476 minecraft:pearlescent_froglight
fill 188 130 484 188 131 484 minecraft:pearlescent_froglight
fill 188 130 492 188 131 492 minecraft:pearlescent_froglight
fill 188 130 500 188 131 500 minecraft:pearlescent_froglight
fill 191 130 505 191 131 505 minecraft:pearlescent_froglight
fill 195 130 463 195 131 463 minecraft:pearlescent_froglight
fill 199 130 505 199 131 505 minecraft:pearlescent_froglight
fill 203 130 463 203 131 463 minecraft:pearlescent_froglight
fill 207 130 505 207 131 505 minecraft:pearlescent_froglight
fill 210 130 466 210 130 468 minecraft:light_gray_concrete
fill 211 130 463 211 131 463 minecraft:pearlescent_froglight
fill 211 130 466 212 130 466 minecraft:light_gray_concrete
fill 211 130 468 212 130 468 minecraft:light_gray_concrete
setblock 212 130 467 minecraft:light_gray_concrete
fill 215 130 505 215 131 505 minecraft:pearlescent_froglight
fill 219 130 463 219 131 463 minecraft:pearlescent_froglight
fill 223 130 505 223 131 505 minecraft:pearlescent_froglight
fill 227 130 463 227 131 463 minecraft:pearlescent_froglight
fill 230 130 468 230 131 468 minecraft:pearlescent_froglight
fill 230 130 476 230 131 476 minecraft:pearlescent_froglight
fill 230 130 484 230 131 484 minecraft:pearlescent_froglight
fill 230 130 492 230 131 492 minecraft:pearlescent_froglight
fill 230 130 500 230 131 500 minecraft:pearlescent_froglight
fill 188 132 468 188 143 468 minecraft:light_gray_terracotta
fill 188 132 476 188 143 476 minecraft:light_gray_terracotta
fill 188 132 484 188 143 484 minecraft:light_gray_terracotta
fill 188 132 492 188 143 492 minecraft:light_gray_terracotta
fill 188 132 500 188 143 500 minecraft:light_gray_terracotta
fill 191 132 505 191 143 505 minecraft:light_gray_terracotta
fill 195 132 463 195 143 463 minecraft:light_gray_terracotta
fill 199 132 505 199 143 505 minecraft:light_gray_terracotta
fill 203 132 463 203 143 463 minecraft:light_gray_terracotta
fill 207 132 505 207 143 505 minecraft:light_gray_terracotta
fill 211 132 463 211 143 463 minecraft:light_gray_terracotta
fill 215 132 505 215 143 505 minecraft:light_gray_terracotta
fill 219 132 463 219 143 463 minecraft:light_gray_terracotta
fill 223 132 505 223 143 505 minecraft:light_gray_terracotta
fill 227 132 463 227 143 463 minecraft:light_gray_terracotta
fill 230 132 468 230 143 468 minecraft:light_gray_terracotta
fill 230 132 476 230 143 476 minecraft:light_gray_terracotta
fill 230 132 484 230 143 484 minecraft:light_gray_terracotta
fill 230 132 492 230 143 492 minecraft:light_gray_terracotta
fill 230 132 500 230 143 500 minecraft:light_gray_terracotta
setblock 191 133 466 minecraft:light[level=11]
setblock 191 133 474 minecraft:light[level=11]
setblock 191 133 482 minecraft:light[level=11]
setblock 191 133 490 minecraft:light[level=11]
setblock 191 133 498 minecraft:light[level=11]
setblock 199 133 466 minecraft:light[level=11]
setblock 199 133 474 minecraft:light[level=11]
setblock 199 133 482 minecraft:light[level=11]
setblock 199 133 490 minecraft:light[level=11]
setblock 199 133 498 minecraft:light[level=11]
setblock 207 133 466 minecraft:light[level=11]
setblock 207 133 474 minecraft:light[level=11]
setblock 207 133 482 minecraft:light[level=11]
setblock 207 133 490 minecraft:light[level=11]
setblock 207 133 498 minecraft:light[level=11]
setblock 215 133 466 minecraft:light[level=11]
setblock 215 133 474 minecraft:light[level=11]
setblock 215 133 482 minecraft:light[level=11]
setblock 215 133 490 minecraft:light[level=11]
setblock 215 133 498 minecraft:light[level=11]
setblock 223 133 466 minecraft:light[level=11]
setblock 223 133 474 minecraft:light[level=11]
setblock 223 133 482 minecraft:light[level=11]
setblock 223 133 490 minecraft:light[level=11]
setblock 223 133 498 minecraft:light[level=11]
fill 213 136 483 215 136 485 minecraft:redstone_block
fill 213 136 491 215 136 493 minecraft:redstone_block
fill 221 136 487 223 136 489 minecraft:redstone_block
fill 189 137 464 191 138 504 minecraft:light_gray_concrete
fill 192 137 464 192 138 504 minecraft:iron_block
fill 193 137 464 195 138 504 minecraft:light_gray_concrete
fill 196 137 464 196 138 504 minecraft:iron_block
fill 197 137 464 199 138 504 minecraft:light_gray_concrete
fill 200 137 464 200 138 504 minecraft:iron_block
fill 201 137 464 203 138 504 minecraft:light_gray_concrete
fill 204 137 464 204 138 504 minecraft:iron_block
fill 205 137 464 207 138 504 minecraft:light_gray_concrete
fill 208 137 464 208 138 504 minecraft:iron_block
fill 209 137 464 211 138 504 minecraft:light_gray_concrete
fill 212 137 464 212 137 504 minecraft:iron_block
fill 213 137 464 215 137 482 minecraft:light_gray_concrete
fill 213 137 486 215 137 490 minecraft:light_gray_concrete
fill 213 137 494 215 137 504 minecraft:light_gray_concrete
fill 216 137 464 216 137 486 minecraft:iron_block
fill 216 137 490 216 137 504 minecraft:iron_block
fill 217 137 464 219 137 486 minecraft:light_gray_concrete
fill 217 137 490 219 137 504 minecraft:light_gray_concrete
fill 219 137 487 219 137 489 minecraft:light_gray_concrete
fill 220 137 464 220 137 504 minecraft:iron_block
fill 221 137 464 223 137 486 minecraft:light_gray_concrete
fill 221 137 490 223 137 504 minecraft:light_gray_concrete
fill 224 137 464 224 137 504 minecraft:iron_block
fill 225 137 464 227 138 504 minecraft:light_gray_concrete
fill 228 137 464 228 138 504 minecraft:iron_block
fill 229 137 464 229 138 504 minecraft:light_gray_concrete
fill 212 138 464 212 138 481 minecraft:iron_block
fill 212 138 482 212 138 486 minecraft:pearlescent_froglight
fill 212 138 487 212 138 489 minecraft:iron_block
fill 212 138 490 212 138 494 minecraft:pearlescent_froglight
fill 212 138 495 212 138 504 minecraft:iron_block
fill 213 138 464 215 138 481 minecraft:light_gray_concrete
fill 213 138 482 216 138 482 minecraft:pearlescent_froglight
fill 213 138 483 215 138 485 minecraft:iron_block
fill 213 138 486 214 138 486 minecraft:pearlescent_froglight
fill 213 138 487 213 138 489 minecraft:light_gray_concrete
fill 213 138 490 214 138 490 minecraft:pearlescent_froglight
fill 213 138 491 215 138 493 minecraft:iron_block
fill 213 138 494 216 138 494 minecraft:pearlescent_froglight
fill 213 138 495 215 138 504 minecraft:light_gray_concrete
fill 214 138 487 214 138 489 minecraft:red_nether_bricks
setblock 215 138 486 minecraft:red_nether_bricks
fill 215 138 487 215 138 489 minecraft:shroomlight
setblock 215 138 490 minecraft:red_nether_bricks
fill 216 138 464 216 138 481 minecraft:iron_block
fill 216 138 483 216 138 485 minecraft:pearlescent_froglight
fill 216 138 486 218 138 486 minecraft:shroomlight
fill 216 138 490 218 138 490 minecraft:shroomlight
fill 216 138 491 216 138 493 minecraft:pearlescent_froglight
fill 216 138 495 216 138 504 minecraft:iron_block
fill 217 138 464 219 138 485 minecraft:light_gray_concrete
fill 217 138 491 219 138 504 minecraft:light_gray_concrete
setblock 219 138 486 minecraft:red_nether_bricks
fill 219 138 487 219 138 489 minecraft:shroomlight
setblock 219 138 490 minecraft:red_nether_bricks
fill 220 138 464 220 138 485 minecraft:iron_block
fill 220 138 486 224 138 486 minecraft:pearlescent_froglight
fill 220 138 487 220 138 489 minecraft:red_nether_bricks
fill 220 138 490 224 138 490 minecraft:pearlescent_froglight
fill 220 138 491 220 138 504 minecraft:iron_block
fill 221 138 464 223 138 485 minecraft:light_gray_concrete
fill 221 138 487 223 138 489 minecraft:iron_block
fill 221 138 491 223 138 504 minecraft:light_gray_concrete
fill 224 138 464 224 138 485 minecraft:iron_block
fill 224 138 487 224 138 489 minecraft:pearlescent_froglight
fill 224 138 491 224 138 504 minecraft:iron_block
fill 211 139 488 213 139 488 minecraft:red_nether_bricks
fill 212 139 486 214 139 487 minecraft:red_nether_bricks
fill 212 139 489 214 139 490 minecraft:red_nether_bricks
fill 213 139 485 216 139 485 minecraft:red_nether_bricks
fill 213 139 491 216 139 491 minecraft:red_nether_bricks
fill 214 139 484 220 139 484 minecraft:red_nether_bricks
fill 214 139 488 215 139 488 minecraft:quartz_block
fill 214 139 492 220 139 492 minecraft:red_nether_bricks
fill 215 139 486 215 140 487 minecraft:quartz_block
fill 215 139 489 215 140 490 minecraft:quartz_block
fill 216 139 486 219 139 486 minecraft:quartz_block
fill 216 139 490 219 139 490 minecraft:quartz_block
fill 217 139 485 217 140 485 minecraft:quartz_block
fill 217 139 491 217 140 491 minecraft:quartz_block
fill 218 139 485 221 139 485 minecraft:red_nether_bricks
fill 218 139 491 221 139 491 minecraft:red_nether_bricks
fill 219 139 487 219 139 489 minecraft:quartz_block
fill 220 139 486 222 139 487 minecraft:red_nether_bricks
fill 220 139 488 220 140 488 minecraft:quartz_block
fill 220 139 489 222 139 490 minecraft:red_nether_bricks
fill 221 139 488 223 139 488 minecraft:red_nether_bricks
fill 206 140 487 212 146 489 minecraft:nether_bricks
fill 207 140 486 211 146 486 minecraft:nether_bricks
fill 207 140 490 211 146 490 minecraft:nether_bricks
fill 211 140 485 214 140 485 minecraft:red_nether_bricks
fill 211 140 491 214 140 491 minecraft:red_nether_bricks
fill 212 140 484 216 145 484 minecraft:red_nether_bricks
fill 212 140 486 213 140 486 minecraft:red_nether_bricks
fill 212 140 490 213 140 490 minecraft:red_nether_bricks
fill 212 140 492 216 145 492 minecraft:red_nether_bricks
fill 213 140 483 221 147 483 minecraft:red_nether_bricks
setblock 213 140 487 minecraft:red_nether_bricks
fill 213 140 488 214 140 488 minecraft:quartz_block
setblock 213 140 489 minecraft:red_nether_bricks
fill 213 140 493 221 147 493 minecraft:red_nether_bricks
fill 214 140 486 214 140 487 minecraft:quartz_block
fill 214 140 489 214 140 490 minecraft:quartz_block
fill 215 140 485 216 140 485 minecraft:quartz_block
fill 215 140 491 216 140 491 minecraft:quartz_block
fill 216 140 482 218 149 482 minecraft:red_nether_bricks
setblock 216 140 486 minecraft:quartz_block
setblock 216 140 490 minecraft:quartz_block
fill 216 140 494 218 149 494 minecraft:red_nether_bricks
setblock 217 140 484 minecraft:quartz_block
setblock 217 140 492 minecraft:quartz_block
fill 218 140 484 222 145 484 minecraft:red_nether_bricks
fill 218 140 485 219 140 486 minecraft:quartz_block
fill 218 140 490 219 140 491 minecraft:quartz_block
fill 218 140 492 222 145 492 minecraft:red_nether_bricks
fill 219 140 487 220 140 487 minecraft:quartz_block
fill 219 140 489 220 140 489 minecraft:quartz_block
fill 220 140 485 223 146 485 minecraft:red_nether_bricks
setblock 220 140 486 minecraft:quartz_block
setblock 220 140 490 minecraft:quartz_block
fill 220 140 491 223 146 491 minecraft:red_nether_bricks
fill 221 140 486 224 145 487 minecraft:red_nether_bricks
setblock 221 140 488 minecraft:quartz_block
fill 221 140 489 224 145 490 minecraft:red_nether_bricks
fill 222 140 488 224 148 488 minecraft:red_nether_bricks
setblock 191 141 466 minecraft:light[level=11]
setblock 191 141 474 minecraft:light[level=11]
setblock 191 141 482 minecraft:light[level=11]
setblock 191 141 490 minecraft:light[level=11]
setblock 191 141 498 minecraft:light[level=11]
setblock 199 141 466 minecraft:light[level=11]
setblock 199 141 474 minecraft:light[level=11]
setblock 199 141 482 minecraft:light[level=11]
setblock 199 141 490 minecraft:light[level=11]
setblock 199 141 498 minecraft:light[level=11]
fill 204 141 488 205 145 488 minecraft:nether_bricks
fill 205 141 486 205 143 487 minecraft:nether_bricks
fill 205 141 489 205 143 490 minecraft:nether_bricks
fill 206 141 485 206 145 486 minecraft:nether_bricks
fill 206 141 490 206 145 491 minecraft:nether_bricks
setblock 207 141 466 minecraft:light[level=11]
setblock 207 141 474 minecraft:light[level=11]
setblock 207 141 482 minecraft:light[level=11]
fill 207 141 485 212 145 485 minecraft:nether_bricks
fill 207 141 491 212 145 491 minecraft:nether_bricks
setblock 207 141 498 minecraft:light[level=11]
setblock 211 141 484 minecraft:red_nether_bricks
setblock 211 141 492 minecraft:red_nether_bricks
fill 212 141 483 212 149 483 minecraft:red_nether_bricks
fill 212 141 486 213 145 486 minecraft:nether_bricks
fill 212 141 490 213 145 490 minecraft:nether_bricks
fill 212 141 493 212 149 493 minecraft:red_nether_bricks
fill 213 141 482 215 148 482 minecraft:red_nether_bricks
fill 213 141 485 219 141 485 minecraft:red_nether_bricks
fill 213 141 487 213 145 489 minecraft:nether_bricks
fill 213 141 491 219 141 491 minecraft:red_nether_bricks
fill 213 141 494 215 148 494 minecraft:red_nether_bricks
fill 214 141 486 214 141 487 minecraft:red_nether_bricks
fill 214 141 488 214 142 488 minecraft:nether_bricks
fill 214 141 489 214 141 490 minecraft:red_nether_bricks
setblock 215 141 466 minecraft:light[level=11]
setblock 215 141 474 minecraft:light[level=11]
setblock 215 141 486 minecraft:red_nether_bricks
setblock 215 141 490 minecraft:red_nether_bricks
setblock 215 141 498 minecraft:light[level=11]
fill 217 141 484 217 145 484 minecraft:red_nether_bricks
fill 217 141 492 217 145 492 minecraft:red_nether_bricks
fill 219 141 482 221 148 482 minecraft:red_nether_bricks
fill 219 141 486 220 141 486 minecraft:red_nether_bricks
fill 219 141 490 220 141 490 minecraft:red_nether_bricks
fill 219 141 494 221 148 494 minecraft:red_nether_bricks
fill 220 141 487 220 142 489 minecraft:red_nether_bricks
fill 221 141 488 221 145 488 minecraft:red_nether_bricks
fill 222 141 483 222 149 483 minecraft:red_nether_bricks
fill 222 141 493 222 149 493 minecraft:red_nether_bricks
setblock 223 141 466 minecraft:light[level=11]
setblock 223 141 474 minecraft:light[level=11]
setblock 223 141 482 minecraft:light[level=11]
fill 223 141 484 223 149 484 minecraft:red_nether_bricks
fill 223 141 492 223 149 492 minecraft:red_nether_bricks
setblock 223 141 498 minecraft:light[level=11]
fill 224 141 485 224 149 485 minecraft:red_nether_bricks
fill 224 141 491 224 149 491 minecraft:red_nether_bricks
fill 225 141 486 225 148 490 minecraft:red_nether_bricks
fill 189 142 470 189 225 471 minecraft:light_gray_concrete
fill 189 142 478 189 225 479 minecraft:light_gray_concrete
fill 189 142 486 189 225 487 minecraft:light_gray_concrete
fill 189 142 494 189 144 503 minecraft:light_gray_concrete
fill 190 142 464 191 225 464 minecraft:light_gray_concrete
fill 190 142 494 195 144 502 minecraft:light_gray_concrete
fill 195 142 504 196 225 504 minecraft:light_gray_concrete
fill 198 142 464 199 225 464 minecraft:light_gray_concrete
fill 203 142 504 204 225 504 minecraft:light_gray_concrete
fill 204 142 486 204 144 487 minecraft:nether_bricks
fill 204 142 489 204 144 490 minecraft:nether_bricks
fill 205 142 485 205 144 485 minecraft:nether_bricks
fill 205 142 491 205 144 491 minecraft:nether_bricks
fill 206 142 464 207 225 464 minecraft:light_gray_concrete
fill 207 142 484 211 144 484 minecraft:nether_bricks
fill 207 142 492 211 144 492 minecraft:nether_bricks
fill 211 142 483 211 148 483 minecraft:red_nether_bricks
fill 211 142 493 211 148 493 minecraft:red_nether_bricks
fill 211 142 504 212 225 504 minecraft:light_gray_concrete
fill 212 142 482 212 147 482 minecraft:red_nether_bricks
fill 212 142 494 212 147 494 minecraft:red_nether_bricks
fill 213 142 485 213 144 485 minecraft:nether_bricks
fill 213 142 491 213 144 491 minecraft:nether_bricks
fill 214 142 464 215 225 464 minecraft:light_gray_concrete
fill 214 142 481 220 146 481 minecraft:red_nether_bricks
fill 214 142 485 219 142 485 minecraft:red_nether_bricks
fill 214 142 486 214 142 487 minecraft:nether_bricks
fill 214 142 489 214 142 490 minecraft:nether_bricks
fill 214 142 491 219 142 491 minecraft:red_nether_bricks
fill 214 142 495 220 146 495 minecraft:red_nether_bricks
fill 219 142 504 220 225 504 minecraft:light_gray_concrete
fill 220 142 486 220 144 486 minecraft:red_nether_bricks
fill 220 142 490 220 144 490 minecraft:red_nether_bricks
fill 222 142 464 223 225 464 minecraft:light_gray_concrete
fill 222 142 482 222 147 482 minecraft:red_nether_bricks
fill 222 142 494 222 147 494 minecraft:red_nether_bricks
fill 223 142 483 223 148 483 minecraft:red_nether_bricks
fill 223 142 493 223 148 493 minecraft:red_nether_bricks
fill 224 142 470 229 144 478 minecraft:light_gray_concrete
fill 224 142 484 224 148 484 minecraft:red_nether_bricks
fill 224 142 492 224 148 492 minecraft:red_nether_bricks
fill 225 142 485 225 148 485 minecraft:red_nether_bricks
fill 225 142 491 225 148 491 minecraft:red_nether_bricks
fill 226 142 487 226 147 489 minecraft:red_nether_bricks
fill 227 142 504 228 225 504 minecraft:light_gray_concrete
fill 229 142 465 229 225 466 minecraft:light_gray_concrete
fill 229 142 481 229 225 482 minecraft:light_gray_concrete
fill 229 142 489 229 225 490 minecraft:light_gray_concrete
fill 229 142 497 229 225 498 minecraft:light_gray_concrete
fill 210 143 483 210 147 483 minecraft:red_nether_bricks
fill 210 143 493 210 147 493 minecraft:red_nether_bricks
fill 211 143 482 211 146 482 minecraft:red_nether_bricks
fill 211 143 494 211 146 494 minecraft:red_nether_bricks
fill 213 143 481 213 146 481 minecraft:red_nether_bricks
fill 213 143 495 213 146 495 minecraft:red_nether_bricks
fill 214 143 485 215 144 485 minecraft:red_nether_bricks
fill 214 143 486 214 144 486 minecraft:nether_bricks
fill 214 143 490 214 144 490 minecraft:nether_bricks
fill 214 143 491 215 144 491 minecraft:red_nether_bricks
fill 219 143 485 219 144 485 minecraft:red_nether_bricks
fill 219 143 491 219 144 491 minecraft:red_nether_bricks
fill 221 143 481 221 146 481 minecraft:red_nether_bricks
fill 221 143 495 221 146 495 minecraft:red_nether_bricks
fill 223 143 482 223 146 482 minecraft:red_nether_bricks
fill 223 143 494 223 146 494 minecraft:red_nether_bricks
fill 224 143 483 224 147 483 minecraft:red_nether_bricks
fill 224 143 493 224 147 493 minecraft:red_nether_bricks
fill 225 143 484 225 147 484 minecraft:red_nether_bricks
fill 225 143 492 225 147 492 minecraft:red_nether_bricks
fill 226 143 486 226 147 486 minecraft:red_nether_bricks
fill 226 143 490 226 147 490 minecraft:red_nether_bricks
fill 188 144 468 188 149 468 minecraft:pearlescent_froglight
fill 188 144 476 188 149 476 minecraft:pearlescent_froglight
fill 188 144 484 188 149 484 minecraft:pearlescent_froglight
fill 188 144 492 188 149 492 minecraft:pearlescent_froglight
fill 188 144 500 188 149 500 minecraft:pearlescent_froglight
fill 191 144 505 191 149 505 minecraft:pearlescent_froglight
fill 195 144 463 195 149 463 minecraft:pearlescent_froglight
fill 199 144 505 199 149 505 minecraft:pearlescent_froglight
fill 203 144 463 203 149 463 minecraft:pearlescent_froglight
fill 205 144 486 205 145 486 minecraft:black_concrete
fill 205 144 487 205 145 487 minecraft:nether_bricks
fill 205 144 489 205 145 489 minecraft:nether_bricks
fill 205 144 490 205 145 490 minecraft:black_concrete
fill 207 144 505 207 149 505 minecraft:pearlescent_froglight
fill 211 144 463 211 149 463 minecraft:pearlescent_froglight
fill 215 144 505 215 149 505 minecraft:pearlescent_froglight
fill 219 144 463 219 149 463 minecraft:pearlescent_froglight
fill 223 144 505 223 149 505 minecraft:pearlescent_froglight
fill 226 144 485 226 146 485 minecraft:red_nether_bricks
fill 226 144 491 226 146 491 minecraft:red_nether_bricks
fill 227 144 463 227 149 463 minecraft:pearlescent_froglight
fill 230 144 468 230 149 468 minecraft:pearlescent_froglight
fill 230 144 476 230 149 476 minecraft:pearlescent_froglight
fill 230 144 484 230 149 484 minecraft:pearlescent_froglight
fill 230 144 492 230 149 492 minecraft:pearlescent_froglight
fill 230 144 500 230 149 500 minecraft:pearlescent_froglight
setblock 189 145 494 minecraft:pearlescent_froglight
fill 189 145 495 189 225 495 minecraft:light_gray_concrete
setblock 189 145 496 minecraft:pearlescent_froglight
fill 189 145 497 189 158 497 minecraft:light_gray_concrete
setblock 189 145 498 minecraft:pearlescent_froglight
fill 189 145 499 189 158 499 minecraft:light_gray_concrete
setblock 189 145 500 minecraft:pearlescent_froglight
fill 189 145 501 189 158 501 minecraft:light_gray_concrete
setblock 189 145 502 minecraft:pearlescent_froglight
fill 189 145 503 189 225 503 minecraft:light_gray_concrete
fill 190 145 494 190 158 494 minecraft:light_gray_concrete
setblock 190 145 495 minecraft:pearlescent_froglight
fill 190 145 496 190 158 496 minecraft:light_gray_concrete
setblock 190 145 497 minecraft:pearlescent_froglight
fill 190 145 498 190 158 498 minecraft:light_gray_concrete
setblock 190 145 499 minecraft:pearlescent_froglight
fill 190 145 500 190 158 500 minecraft:light_gray_concrete
setblock 190 145 501 minecraft:pearlescent_froglight
fill 190 145 502 190 158 502 minecraft:light_gray_concrete
setblock 191 145 494 minecraft:pearlescent_froglight
fill 191 145 495 191 158 495 minecraft:light_gray_concrete
setblock 191 145 496 minecraft:pearlescent_froglight
fill 191 145 497 191 158 497 minecraft:light_gray_concrete
setblock 191 145 498 minecraft:pearlescent_froglight
fill 191 145 499 191 158 499 minecraft:light_gray_concrete
setblock 191 145 500 minecraft:pearlescent_froglight
fill 191 145 501 191 158 501 minecraft:light_gray_concrete
setblock 191 145 502 minecraft:pearlescent_froglight
fill 192 145 494 192 158 494 minecraft:light_gray_concrete
setblock 192 145 495 minecraft:pearlescent_froglight
fill 192 145 496 192 158 496 minecraft:light_gray_concrete
setblock 192 145 497 minecraft:pearlescent_froglight
fill 192 145 498 192 158 498 minecraft:light_gray_concrete
setblock 192 145 499 minecraft:pearlescent_froglight
fill 192 145 500 192 158 500 minecraft:light_gray_concrete
setblock 192 145 501 minecraft:pearlescent_froglight
fill 192 145 502 192 158 502 minecraft:light_gray_concrete
setblock 193 145 494 minecraft:pearlescent_froglight
fill 193 145 495 193 158 495 minecraft:light_gray_concrete
setblock 193 145 496 minecraft:pearlescent_froglight
fill 193 145 497 193 158 497 minecraft:light_gray_concrete
setblock 193 145 498 minecraft:pearlescent_froglight
fill 193 145 499 193 158 499 minecraft:light_gray_concrete
setblock 193 145 500 minecraft:pearlescent_froglight
fill 193 145 501 193 158 501 minecraft:light_gray_concrete
setblock 193 145 502 minecraft:pearlescent_froglight
fill 194 145 494 194 158 494 minecraft:light_gray_concrete
setblock 194 145 495 minecraft:pearlescent_froglight
fill 194 145 496 194 158 496 minecraft:light_gray_concrete
setblock 194 145 497 minecraft:pearlescent_froglight
fill 194 145 498 194 158 498 minecraft:light_gray_concrete
setblock 194 145 499 minecraft:pearlescent_froglight
fill 194 145 500 194 158 500 minecraft:light_gray_concrete
setblock 194 145 501 minecraft:pearlescent_froglight
fill 194 145 502 194 158 502 minecraft:light_gray_concrete
setblock 195 145 494 minecraft:pearlescent_froglight
fill 195 145 495 195 158 495 minecraft:light_gray_concrete
setblock 195 145 496 minecraft:pearlescent_froglight
fill 195 145 497 195 158 497 minecraft:light_gray_concrete
setblock 195 145 498 minecraft:pearlescent_froglight
fill 195 145 499 195 158 499 minecraft:light_gray_concrete
setblock 195 145 500 minecraft:pearlescent_froglight
fill 195 145 501 195 158 501 minecraft:light_gray_concrete
setblock 195 145 502 minecraft:pearlescent_froglight
setblock 204 145 487 minecraft:nether_bricks
setblock 204 145 489 minecraft:nether_bricks
fill 209 145 484 211 147 484 minecraft:red_nether_bricks
fill 209 145 492 211 147 492 minecraft:red_nether_bricks
fill 213 145 485 214 146 485 minecraft:red_nether_bricks
fill 213 145 491 214 146 491 minecraft:red_nether_bricks
fill 224 145 470 224 155 470 minecraft:light_gray_concrete
setblock 224 145 471 minecraft:pearlescent_froglight
fill 224 145 472 224 155 472 minecraft:light_gray_concrete
setblock 224 145 473 minecraft:pearlescent_froglight
fill 224 145 474 224 155 474 minecraft:light_gray_concrete
setblock 224 145 475 minecraft:pearlescent_froglight
fill 224 145 476 224 151 476 minecraft:light_gray_concrete
setblock 224 145 477 minecraft:pearlescent_froglight
fill 224 145 478 224 148 478 minecraft:light_gray_concrete
setblock 225 145 470 minecraft:pearlescent_froglight
fill 225 145 471 225 155 471 minecraft:light_gray_concrete
setblock 225 145 472 minecraft:pearlescent_froglight
fill 225 145 473 225 155 473 minecraft:light_gray_concrete
setblock 225 145 474 minecraft:pearlescent_froglight
fill 225 145 475 225 152 475 minecraft:light_gray_concrete
setblock 225 145 476 minecraft:pearlescent_froglight
fill 225 145 477 225 155 477 minecraft:light_gray_concrete
setblock 225 145 478 minecraft:pearlescent_froglight
fill 226 145 470 226 155 470 minecraft:light_gray_concrete
setblock 226 145 471 minecraft:pearlescent_froglight
fill 226 145 472 226 155 472 minecraft:light_gray_concrete
setblock 226 145 473 minecraft:pearlescent_froglight
fill 226 145 474 226 155 474 minecraft:light_gray_concrete
setblock 226 145 475 minecraft:pearlescent_froglight
fill 226 145 476 226 150 476 minecraft:light_gray_concrete
setblock 226 145 477 minecraft:pearlescent_froglight
fill 226 145 478 226 155 478 minecraft:light_gray_concrete
setblock 227 145 470 minecraft:pearlescent_froglight
fill 227 145 471 227 155 471 minecraft:light_gray_concrete
setblock 227 145 472 minecraft:pearlescent_froglight
fill 227 145 473 227 155 473 minecraft:light_gray_concrete
setblock 227 145 474 minecraft:pearlescent_froglight
fill 227 145 475 227 151 475 minecraft:light_gray_concrete
setblock 227 145 476 minecraft:pearlescent_froglight
fill 227 145 477 227 149 477 minecraft:light_gray_concrete
setblock 227 145 478 minecraft:pearlescent_froglight
fill 228 145 470 228 155 470 minecraft:light_gray_concrete
setblock 228 145 471 minecraft:pearlescent_froglight
fill 228 145 472 228 155 472 minecraft:light_gray_concrete
setblock 228 145 473 minecraft:pearlescent_froglight
fill 228 145 474 228 151 474 minecraft:light_gray_concrete
setblock 228 145 475 minecraft:pearlescent_froglight
fill 228 145 476 228 155 476 minecraft:light_gray_concrete
setblock 228 145 477 minecraft:pearlescent_froglight
fill 228 145 478 228 155 478 minecraft:light_gray_concrete
setblock 229 145 470 minecraft:pearlescent_froglight
fill 229 145 471 229 155 471 minecraft:light_gray_concrete
setblock 229 145 472 minecraft:pearlescent_froglight
fill 229 145 473 229 225 473 minecraft:light_gray_concrete
setblock 229 145 474 minecraft:pearlescent_froglight
fill 229 145 475 229 155 475 minecraft:light_gray_concrete
setblock 229 145 476 minecraft:pearlescent_froglight
fill 229 145 477 229 155 477 minecraft:light_gray_concrete
setblock 229 145 478 minecraft:pearlescent_froglight
fill 189 146 494 189 147 494 minecraft:light_gray_concrete
fill 189 146 496 189 147 496 minecraft:light_gray_concrete
fill 189 146 498 189 147 498 minecraft:light_gray_concrete
fill 189 146 500 189 147 500 minecraft:light_gray_concrete
fill 189 146 502 189 147 502 minecraft:light_gray_concrete
fill 190 146 495 190 147 495 minecraft:light_gray_concrete
fill 190 146 497 190 147 497 minecraft:light_gray_concrete
fill 190 146 499 190 147 499 minecraft:light_gray_concrete
fill 190 146 501 190 147 501 minecraft:light_gray_concrete
fill 191 146 494 191 147 494 minecraft:light_gray_concrete
fill 191 146 496 191 147 496 minecraft:light_gray_concrete
fill 191 146 498 191 147 498 minecraft:light_gray_concrete
fill 191 146 500 191 147 500 minecraft:light_gray_concrete
fill 191 146 502 191 147 502 minecraft:light_gray_concrete
fill 192 146 495 192 147 495 minecraft:light_gray_concrete
fill 192 146 497 192 147 497 minecraft:light_gray_concrete
fill 192 146 499 192 147 499 minecraft:light_gray_concrete
fill 192 146 501 192 147 501 minecraft:light_gray_concrete
fill 193 146 494 193 147 494 minecraft:light_gray_concrete
fill 193 146 496 193 147 496 minecraft:light_gray_concrete
fill 193 146 498 193 147 498 minecraft:light_gray_concrete
fill 193 146 500 193 147 500 minecraft:light_gray_concrete
fill 193 146 502 193 147 502 minecraft:light_gray_concrete
fill 194 146 495 194 147 495 minecraft:light_gray_concrete
fill 194 146 497 194 147 497 minecraft:light_gray_concrete
fill 194 146 499 194 147 499 minecraft:light_gray_concrete
fill 194 146 501 194 147 501 minecraft:light_gray_concrete
fill 195 146 494 195 147 494 minecraft:light_gray_concrete
fill 195 146 496 195 147 496 minecraft:light_gray_concrete
fill 195 146 498 195 147 498 minecraft:light_gray_concrete
fill 195 146 500 195 147 500 minecraft:light_gray_concrete
fill 195 146 502 195 147 502 minecraft:light_gray_concrete
setblock 205 146 488 minecraft:nether_bricks
setblock 206 146 486 minecraft:nether_bricks
setblock 206 146 490 minecraft:nether_bricks
fill 208 146 485 210 146 485 minecraft:nether_bricks
fill 208 146 491 210 146 491 minecraft:nether_bricks
fill 211 146 485 212 149 485 minecraft:red_nether_bricks
fill 211 146 491 212 149 491 minecraft:red_nether_bricks
fill 212 146 484 215 147 484 minecraft:red_nether_bricks
setblock 212 146 486 minecraft:nether_bricks
setblock 212 146 490 minecraft:nether_bricks
fill 212 146 492 215 147 492 minecraft:red_nether_bricks
fill 213 146 486 213 147 486 minecraft:red_nether_bricks
fill 213 146 490 213 147 490 minecraft:red_nether_bricks
fill 219 146 484 222 147 484 minecraft:red_nether_bricks
fill 219 146 492 222 147 492 minecraft:red_nether_bricks
fill 221 146 486 224 147 486 minecraft:red_nether_bricks
fill 221 146 490 224 147 490 minecraft:red_nether_bricks
fill 222 146 487 224 149 487 minecraft:red_nether_bricks
fill 222 146 489 224 149 489 minecraft:red_nether_bricks
fill 224 146 471 224 147 471 minecraft:light_gray_concrete
fill 224 146 473 224 147 473 minecraft:light_gray_concrete
fill 224 146 475 224 147 475 minecraft:light_gray_concrete
fill 224 146 477 224 147 477 minecraft:light_gray_concrete
fill 225 146 470 225 147 470 minecraft:light_gray_concrete
fill 225 146 472 225 147 472 minecraft:light_gray_concrete
fill 225 146 474 225 147 474 minecraft:light_gray_concrete
fill 225 146 476 225 147 476 minecraft:light_gray_concrete
fill 225 146 478 225 147 478 minecraft:light_gray_concrete
fill 226 146 471 226 147 471 minecraft:light_gray_concrete
fill 226 146 473 226 147 473 minecraft:light_gray_concrete
fill 226 146 475 226 147 475 minecraft:light_gray_concrete
fill 226 146 477 226 147 477 minecraft:light_gray_concrete
fill 227 146 470 227 147 470 minecraft:light_gray_concrete
fill 227 146 472 227 147 472 minecraft:light_gray_concrete
fill 227 146 474 227 147 474 minecraft:light_gray_concrete
fill 227 146 476 227 147 476 minecraft:light_gray_concrete
fill 227 146 478 227 147 478 minecraft:light_gray_concrete
fill 228 146 471 228 147 471 minecraft:light_gray_concrete
fill 228 146 473 228 147 473 minecraft:light_gray_concrete
fill 228 146 475 228 147 475 minecraft:light_gray_concrete
fill 228 146 477 228 147 477 minecraft:light_gray_concrete
fill 229 146 470 229 147 470 minecraft:light_gray_concrete
fill 229 146 472 229 147 472 minecraft:light_gray_concrete
fill 229 146 474 229 147 474 minecraft:light_gray_concrete
fill 229 146 476 229 147 476 minecraft:light_gray_concrete
fill 229 146 478 229 147 478 minecraft:light_gray_concrete
fill 208 147 486 212 147 487 minecraft:red_nether_bricks
fill 208 147 488 210 147 488 minecraft:nether_bricks
fill 208 147 489 212 147 490 minecraft:red_nether_bricks
fill 209 147 485 210 148 485 minecraft:red_nether_bricks
fill 209 147 491 210 148 491 minecraft:red_nether_bricks
fill 211 147 488 212 148 488 minecraft:red_nether_bricks
fill 213 147 485 213 148 485 minecraft:red_nether_bricks
fill 213 147 491 213 148 491 minecraft:red_nether_bricks
fill 214 147 481 218 147 481 minecraft:red_nether_bricks
fill 214 147 495 218 147 495 minecraft:red_nether_bricks
setblock 219 147 481 minecraft:black_concrete
setblock 219 147 495 minecraft:black_concrete
setblock 220 147 481 minecraft:red_nether_bricks
setblock 220 147 495 minecraft:red_nether_bricks
fill 221 147 485 223 148 485 minecraft:red_nether_bricks
fill 221 147 491 223 148 491 minecraft:red_nether_bricks
setblock 189 148 494 minecraft:pearlescent_froglight
setblock 189 148 496 minecraft:pearlescent_froglight
setblock 189 148 498 minecraft:pearlescent_froglight
setblock 189 148 500 minecraft:pearlescent_froglight
setblock 189 148 502 minecraft:pearlescent_froglight
setblock 190 148 495 minecraft:pearlescent_froglight
setblock 190 148 497 minecraft:pearlescent_froglight
setblock 190 148 499 minecraft:pearlescent_froglight
setblock 190 148 501 minecraft:pearlescent_froglight
setblock 191 148 494 minecraft:pearlescent_froglight
setblock 191 148 496 minecraft:pearlescent_froglight
setblock 191 148 498 minecraft:pearlescent_froglight
setblock 191 148 500 minecraft:pearlescent_froglight
setblock 191 148 502 minecraft:pearlescent_froglight
setblock 192 148 495 minecraft:pearlescent_froglight
setblock 192 148 497 minecraft:pearlescent_froglight
setblock 192 148 499 minecraft:pearlescent_froglight
setblock 192 148 501 minecraft:pearlescent_froglight
setblock 193 148 494 minecraft:pearlescent_froglight
setblock 193 148 496 minecraft:pearlescent_froglight
setblock 193 148 498 minecraft:pearlescent_froglight
setblock 193 148 500 minecraft:pearlescent_froglight
setblock 193 148 502 minecraft:pearlescent_froglight
setblock 194 148 495 minecraft:pearlescent_froglight
setblock 194 148 497 minecraft:pearlescent_froglight
setblock 194 148 499 minecraft:pearlescent_froglight
setblock 194 148 501 minecraft:pearlescent_froglight
setblock 195 148 494 minecraft:pearlescent_froglight
setblock 195 148 496 minecraft:pearlescent_froglight
setblock 195 148 498 minecraft:pearlescent_froglight
setblock 195 148 500 minecraft:pearlescent_froglight
setblock 195 148 502 minecraft:pearlescent_froglight
fill 209 148 486 210 148 490 minecraft:red_nether_bricks
fill 210 148 484 213 148 484 minecraft:red_nether_bricks
fill 210 148 492 213 148 492 minecraft:red_nether_bricks
fill 211 148 486 212 149 487 minecraft:red_nether_bricks
fill 211 148 489 212 149 490 minecraft:red_nether_bricks
setblock 213 148 483 minecraft:red_nether_bricks
setblock 213 148 493 minecraft:red_nether_bricks
fill 214 148 483 214 148 484 minecraft:shroomlight
fill 214 148 492 214 148 493 minecraft:shroomlight
fill 215 148 483 221 148 483 minecraft:red_nether_bricks
fill 215 148 493 221 148 493 minecraft:red_nether_bricks
fill 216 148 481 218 148 481 minecraft:red_nether_bricks
fill 216 148 495 218 148 495 minecraft:red_nether_bricks
fill 219 148 480 222 148 480 minecraft:black_concrete
fill 219 148 496 222 148 496 minecraft:black_concrete
fill 220 148 484 222 148 484 minecraft:red_nether_bricks
fill 220 148 492 222 148 492 minecraft:red_nether_bricks
fill 222 148 486 224 149 486 minecraft:red_nether_bricks
fill 222 148 490 224 149 490 minecraft:red_nether_bricks
setblock 224 148 471 minecraft:pearlescent_froglight
setblock 224 148 473 minecraft:pearlescent_froglight
setblock 224 148 475 minecraft:pearlescent_froglight
setblock 224 148 477 minecraft:pearlescent_froglight
setblock 225 148 470 minecraft:pearlescent_froglight
setblock 225 148 472 minecraft:pearlescent_froglight
setblock 225 148 474 minecraft:pearlescent_froglight
setblock 225 148 476 minecraft:pearlescent_froglight
setblock 225 148 478 minecraft:pearlescent_froglight
setblock 226 148 471 minecraft:pearlescent_froglight
setblock 226 148 473 minecraft:pearlescent_froglight
setblock 226 148 475 minecraft:pearlescent_froglight
setblock 226 148 477 minecraft:pearlescent_froglight
setblock 227 148 470 minecraft:pearlescent_froglight
setblock 227 148 472 minecraft:pearlescent_froglight
setblock 227 148 474 minecraft:pearlescent_froglight
setblock 227 148 476 minecraft:pearlescent_froglight
setblock 227 148 478 minecraft:pearlescent_froglight
setblock 228 148 471 minecraft:pearlescent_froglight
setblock 228 148 473 minecraft:pearlescent_froglight
setblock 228 148 475 minecraft:pearlescent_froglight
setblock 228 148 477 minecraft:pearlescent_froglight
setblock 229 148 470 minecraft:pearlescent_froglight
setblock 229 148 472 minecraft:pearlescent_froglight
setblock 229 148 474 minecraft:pearlescent_froglight
setblock 229 148 476 minecraft:pearlescent_froglight
setblock 229 148 478 minecraft:pearlescent_froglight
fill 189 149 494 189 150 494 minecraft:light_gray_concrete
fill 189 149 496 189 150 496 minecraft:light_gray_concrete
fill 189 149 498 189 150 498 minecraft:light_gray_concrete
fill 189 149 500 189 150 500 minecraft:light_gray_concrete
fill 189 149 502 189 150 502 minecraft:light_gray_concrete
fill 190 149 495 190 150 495 minecraft:light_gray_concrete
fill 190 149 497 190 150 497 minecraft:light_gray_concrete
fill 190 149 499 190 150 499 minecraft:light_gray_concrete
fill 190 149 501 190 150 501 minecraft:light_gray_concrete
setblock 191 149 466 minecraft:light[level=11]
setblock 191 149 474 minecraft:light[level=11]
setblock 191 149 482 minecraft:light[level=11]
setblock 191 149 490 minecraft:light[level=11]
fill 191 149 494 191 150 494 minecraft:light_gray_concrete
fill 191 149 496 191 150 496 minecraft:light_gray_concrete
fill 191 149 498 191 150 498 minecraft:light_gray_concrete
fill 191 149 500 191 150 500 minecraft:light_gray_concrete
fill 191 149 502 191 150 502 minecraft:light_gray_concrete
fill 192 149 495 192 150 495 minecraft:light_gray_concrete
fill 192 149 497 192 150 497 minecraft:light_gray_concrete
fill 192 149 499 192 150 499 minecraft:light_gray_concrete
fill 192 149 501 192 150 501 minecraft:light_gray_concrete
fill 193 149 494 193 150 494 minecraft:light_gray_concrete
fill 193 149 496 193 150 496 minecraft:light_gray_concrete
fill 193 149 498 193 150 498 minecraft:light_gray_concrete
fill 193 149 500 193 150 500 minecraft:light_gray_concrete
fill 193 149 502 193 150 502 minecraft:light_gray_concrete
fill 194 149 495 194 150 495 minecraft:light_gray_concrete
fill 194 149 497 194 150 497 minecraft:light_gray_concrete
fill 194 149 499 194 150 499 minecraft:light_gray_concrete
fill 194 149 501 194 150 501 minecraft:light_gray_concrete
fill 195 149 494 195 150 494 minecraft:light_gray_concrete
fill 195 149 496 195 150 496 minecraft:light_gray_concrete
fill 195 149 498 195 150 498 minecraft:light_gray_concrete
fill 195 149 500 195 150 500 minecraft:light_gray_concrete
fill 195 149 502 195 150 502 minecraft:light_gray_concrete
setblock 199 149 466 minecraft:light[level=11]
setblock 199 149 474 minecraft:light[level=11]
setblock 199 149 482 minecraft:light[level=11]
setblock 199 149 490 minecraft:light[level=11]
setblock 199 149 498 minecraft:light[level=11]
setblock 207 149 466 minecraft:light[level=11]
setblock 207 149 474 minecraft:light[level=11]
setblock 207 149 482 minecraft:light[level=11]
setblock 207 149 490 minecraft:light[level=11]
setblock 207 149 498 minecraft:light[level=11]
fill 209 149 488 211 149 488 minecraft:red_nether_bricks
fill 210 149 485 210 149 487 minecraft:red_nether_bricks
fill 210 149 489 210 149 491 minecraft:red_nether_bricks
fill 211 149 484 212 149 484 minecraft:red_nether_bricks
fill 211 149 492 212 149 492 minecraft:red_nether_bricks
fill 213 149 483 213 149 484 minecraft:shroomlight
fill 213 149 492 213 149 493 minecraft:shroomlight
fill 214 149 483 215 149 483 minecraft:shroomlight
fill 214 149 493 215 149 493 minecraft:shroomlight
setblock 215 149 466 minecraft:light[level=11]
setblock 215 149 474 minecraft:light[level=11]
setblock 215 149 482 minecraft:red_nether_bricks
setblock 215 149 494 minecraft:red_nether_bricks
setblock 215 149 498 minecraft:light[level=11]
setblock 216 149 483 minecraft:red_nether_bricks
setblock 216 149 493 minecraft:red_nether_bricks
fill 218 149 483 221 149 483 minecraft:red_nether_bricks
fill 218 149 493 221 149 493 minecraft:red_nether_bricks
setblock 219 149 480 minecraft:black_concrete
setblock 219 149 482 minecraft:red_nether_bricks
setblock 219 149 494 minecraft:red_nether_bricks
setblock 219 149 496 minecraft:black_concrete
fill 220 149 479 224 149 479 minecraft:black_concrete
fill 220 149 497 224 149 497 minecraft:black_concrete
fill 221 149 484 222 149 484 minecraft:red_nether_bricks
fill 221 149 492 222 149 492 minecraft:red_nether_bricks
fill 222 149 485 223 149 485 minecraft:red_nether_bricks
fill 222 149 491 223 149 491 minecraft:red_nether_bricks
setblock 223 149 466 minecraft:light[level=11]
setblock 223 149 474 minecraft:light[level=11]
fill 223 149 478 225 149 478 minecraft:black_concrete
setblock 223 149 482 minecraft:light[level=11]
fill 223 149 488 225 149 488 minecraft:red_nether_bricks
fill 223 149 498 225 149 498 minecraft:black_concrete
fill 224 149 471 224 150 471 minecraft:light_gray_concrete
fill 224 149 473 224 150 473 minecraft:light_gray_concrete
fill 224 149 475 224 150 475 minecraft:light_gray_concrete
setblock 224 149 477 minecraft:light_gray_concrete
fill 225 149 470 225 150 470 minecraft:light_gray_concrete
fill 225 149 472 225 150 472 minecraft:light_gray_concrete
fill 225 149 474 225 150 474 minecraft:light_gray_concrete
fill 225 149 476 225 150 476 minecraft:light_gray_concrete
fill 226 149 471 226 150 471 minecraft:light_gray_concrete
fill 226 149 473 226 150 473 minecraft:light_gray_concrete
fill 226 149 475 226 150 475 minecraft:light_gray_concrete
fill 226 149 477 226 150 477 minecraft:light_gray_concrete
fill 227 149 470 227 150 470 minecraft:light_gray_concrete
fill 227 149 472 227 150 472 minecraft:light_gray_concrete
fill 227 149 474 227 150 474 minecraft:light_gray_concrete
fill 227 149 476 227 150 476 minecraft:light_gray_concrete
fill 227 149 478 227 150 478 minecraft:light_gray_concrete
fill 228 149 471 228 150 471 minecraft:light_gray_concrete
fill 228 149 473 228 150 473 minecraft:light_gray_concrete
fill 228 149 475 228 150 475 minecraft:light_gray_concrete
fill 228 149 477 228 150 477 minecraft:light_gray_concrete
fill 229 149 470 229 150 470 minecraft:light_gray_concrete
fill 229 149 472 229 150 472 minecraft:light_gray_concrete
fill 229 149 474 229 150 474 minecraft:light_gray_concrete
fill 229 149 476 229 150 476 minecraft:light_gray_concrete
fill 229 149 478 229 150 478 minecraft:light_gray_concrete
fill 188 150 468 188 157 468 minecraft:light_gray_terracotta
fill 188 150 476 188 157 476 minecraft:light_gray_terracotta
fill 188 150 484 188 157 484 minecraft:light_gray_terracotta
fill 188 150 492 188 157 492 minecraft:light_gray_terracotta
fill 188 150 500 188 157 500 minecraft:light_gray_terracotta
fill 191 150 505 191 157 505 minecraft:light_gray_terracotta
fill 195 150 463 195 157 463 minecraft:light_gray_terracotta
fill 199 150 505 199 157 505 minecraft:light_gray_terracotta
fill 203 150 463 203 157 463 minecraft:light_gray_terracotta
fill 207 150 505 207 157 505 minecraft:light_gray_terracotta
fill 211 150 463 211 157 463 minecraft:light_gray_terracotta
fill 211 150 486 211 150 490 minecraft:red_nether_bricks
fill 212 150 485 212 150 486 minecraft:red_nether_bricks
fill 212 150 490 212 150 491 minecraft:red_nether_bricks
setblock 213 150 484 minecraft:red_nether_bricks
setblock 213 150 492 minecraft:red_nether_bricks
setblock 215 150 483 minecraft:red_nether_bricks
setblock 215 150 493 minecraft:red_nether_bricks
fill 215 150 505 215 157 505 minecraft:light_gray_terracotta
fill 219 150 463 219 157 463 minecraft:light_gray_terracotta
setblock 219 150 479 minecraft:black_concrete
setblock 219 150 483 minecraft:red_nether_bricks
setblock 219 150 493 minecraft:red_nether_bricks
setblock 219 150 497 minecraft:black_concrete
setblock 220 150 478 minecraft:black_concrete
fill 220 150 483 220 151 483 minecraft:blackstone
fill 220 150 493 220 151 493 minecraft:blackstone
setblock 220 150 498 minecraft:black_concrete
fill 221 150 484 221 151 484 minecraft:blackstone
fill 221 150 492 221 151 492 minecraft:blackstone
fill 222 150 478 223 150 478 minecraft:black_concrete
fill 222 150 485 222 150 486 minecraft:red_nether_bricks
fill 222 150 490 222 150 491 minecraft:red_nether_bricks
fill 222 150 498 223 150 498 minecraft:black_concrete
fill 223 150 486 223 150 490 minecraft:red_nether_bricks
fill 223 150 505 223 157 505 minecraft:light_gray_terracotta
setblock 224 150 477 minecraft:black_concrete
fill 224 150 478 225 150 478 minecraft:light_gray_concrete
setblock 224 150 499 minecraft:black_concrete
fill 227 150 463 227 157 463 minecraft:light_gray_terracotta
setblock 227 150 477 minecraft:black_concrete
setblock 227 150 499 minecraft:black_concrete
fill 230 150 468 230 157 468 minecraft:light_gray_terracotta
setblock 230 150 476 minecraft:light_gray_terracotta
fill 230 150 484 230 157 484 minecraft:light_gray_terracotta
fill 230 150 492 230 157 492 minecraft:light_gray_terracotta
setblock 230 150 500 minecraft:light_gray_terracotta
setblock 189 151 494 minecraft:pearlescent_froglight
setblock 189 151 496 minecraft:pearlescent_froglight
setblock 189 151 498 minecraft:pearlescent_froglight
setblock 189 151 500 minecraft:pearlescent_froglight
setblock 189 151 502 minecraft:pearlescent_froglight
setblock 190 151 495 minecraft:pearlescent_froglight
setblock 190 151 497 minecraft:pearlescent_froglight
setblock 190 151 499 minecraft:pearlescent_froglight
setblock 190 151 501 minecraft:pearlescent_froglight
setblock 191 151 494 minecraft:pearlescent_froglight
setblock 191 151 496 minecraft:pearlescent_froglight
setblock 191 151 498 minecraft:pearlescent_froglight
setblock 191 151 500 minecraft:pearlescent_froglight
setblock 191 151 502 minecraft:pearlescent_froglight
setblock 192 151 495 minecraft:pearlescent_froglight
setblock 192 151 497 minecraft:pearlescent_froglight
setblock 192 151 499 minecraft:pearlescent_froglight
setblock 192 151 501 minecraft:pearlescent_froglight
setblock 193 151 494 minecraft:pearlescent_froglight
setblock 193 151 496 minecraft:pearlescent_froglight
setblock 193 151 498 minecraft:pearlescent_froglight
setblock 193 151 500 minecraft:pearlescent_froglight
setblock 193 151 502 minecraft:pearlescent_froglight
setblock 194 151 495 minecraft:pearlescent_froglight
setblock 194 151 497 minecraft:pearlescent_froglight
setblock 194 151 499 minecraft:pearlescent_froglight
setblock 194 151 501 minecraft:pearlescent_froglight
setblock 195 151 494 minecraft:pearlescent_froglight
setblock 195 151 496 minecraft:pearlescent_froglight
setblock 195 151 498 minecraft:pearlescent_froglight
setblock 195 151 500 minecraft:pearlescent_froglight
setblock 195 151 502 minecraft:pearlescent_froglight
fill 219 151 478 219 152 478 minecraft:black_concrete
fill 219 151 498 219 152 498 minecraft:black_concrete
fill 221 151 477 221 152 477 minecraft:black_concrete
fill 221 151 483 221 153 483 minecraft:blackstone
fill 221 151 493 221 153 493 minecraft:blackstone
fill 221 151 499 221 152 499 minecraft:black_concrete
setblock 223 151 477 minecraft:black_concrete
setblock 223 151 499 minecraft:black_concrete
setblock 224 151 471 minecraft:pearlescent_froglight
setblock 224 151 473 minecraft:pearlescent_froglight
setblock 224 151 475 minecraft:pearlescent_froglight
setblock 224 151 477 minecraft:pearlescent_froglight
fill 224 151 478 224 155 478 minecraft:light_gray_concrete
setblock 225 151 470 minecraft:pearlescent_froglight
setblock 225 151 472 minecraft:pearlescent_froglight
setblock 225 151 474 minecraft:pearlescent_froglight
fill 225 151 476 226 151 476 minecraft:black_concrete
setblock 225 151 478 minecraft:pearlescent_froglight
fill 225 151 500 226 151 500 minecraft:black_concrete
setblock 226 151 471 minecraft:pearlescent_froglight
setblock 226 151 473 minecraft:pearlescent_froglight
setblock 226 151 475 minecraft:pearlescent_froglight
setblock 226 151 477 minecraft:pearlescent_froglight
setblock 227 151 470 minecraft:pearlescent_froglight
setblock 227 151 472 minecraft:pearlescent_froglight
setblock 227 151 474 minecraft:pearlescent_froglight
setblock 227 151 476 minecraft:pearlescent_froglight
fill 227 151 477 227 155 477 minecraft:light_gray_concrete
setblock 227 151 478 minecraft:pearlescent_froglight
setblock 228 151 471 minecraft:pearlescent_froglight
setblock 228 151 473 minecraft:pearlescent_froglight
setblock 228 151 475 minecraft:pearlescent_froglight
setblock 228 151 477 minecraft:pearlescent_froglight
setblock 229 151 470 minecraft:pearlescent_froglight
setblock 229 151 472 minecraft:pearlescent_froglight
setblock 229 151 474 minecraft:pearlescent_froglight
fill 229 151 476 230 151 476 minecraft:black_concrete
setblock 229 151 478 minecraft:pearlescent_froglight
fill 229 151 500 230 151 500 minecraft:black_concrete
fill 230 151 469 230 192 474 minecraft:light_gray_terracotta
setblock 230 151 475 minecraft:black_concrete
setblock 230 151 501 minecraft:black_concrete
fill 230 151 502 230 195 502 minecraft:light_gray_terracotta
fill 189 152 494 189 153 494 minecraft:light_gray_concrete
fill 189 152 496 189 153 496 minecraft:light_gray_concrete
fill 189 152 498 189 153 498 minecraft:light_gray_concrete
fill 189 152 500 189 153 500 minecraft:light_gray_concrete
fill 189 152 502 189 153 502 minecraft:light_gray_concrete
fill 190 152 495 190 153 495 minecraft:light_gray_concrete
fill 190 152 497 190 153 497 minecraft:light_gray_concrete
fill 190 152 499 190 153 499 minecraft:light_gray_concrete
fill 190 152 501 190 153 501 minecraft:light_gray_concrete
fill 191 152 494 191 153 494 minecraft:light_gray_concrete
fill 191 152 496 191 153 496 minecraft:light_gray_concrete
fill 191 152 498 191 153 498 minecraft:light_gray_concrete
fill 191 152 500 191 153 500 minecraft:light_gray_concrete
fill 191 152 502 191 153 502 minecraft:light_gray_concrete
fill 192 152 495 192 153 495 minecraft:light_gray_concrete
fill 192 152 497 192 153 497 minecraft:light_gray_concrete
fill 192 152 499 192 153 499 minecraft:light_gray_concrete
fill 192 152 501 192 153 501 minecraft:light_gray_concrete
fill 193 152 494 193 153 494 minecraft:light_gray_concrete
fill 193 152 496 193 153 496 minecraft:light_gray_concrete
fill 193 152 498 193 153 498 minecraft:light_gray_concrete
fill 193 152 500 193 153 500 minecraft:light_gray_concrete
fill 193 152 502 193 153 502 minecraft:light_gray_concrete
fill 194 152 495 194 153 495 minecraft:light_gray_concrete
fill 194 152 497 194 153 497 minecraft:light_gray_concrete
fill 194 152 499 194 153 499 minecraft:light_gray_concrete
fill 194 152 501 194 153 501 minecraft:light_gray_concrete
fill 195 152 494 195 153 494 minecraft:light_gray_concrete
fill 195 152 496 195 153 496 minecraft:light_gray_concrete
fill 195 152 498 195 153 498 minecraft:light_gray_concrete
fill 195 152 500 195 153 500 minecraft:light_gray_concrete
fill 195 152 502 195 153 502 minecraft:light_gray_concrete
fill 218 152 468 218 153 468 minecraft:white_wool
fill 219 152 477 219 153 477 minecraft:black_concrete
fill 219 152 499 219 153 499 minecraft:black_concrete
fill 221 152 476 221 153 476 minecraft:black_concrete
fill 221 152 482 222 153 482 minecraft:blackstone
fill 221 152 494 222 153 494 minecraft:blackstone
fill 221 152 500 221 153 500 minecraft:black_concrete
fill 222 152 483 222 154 483 minecraft:blackstone
fill 222 152 493 222 154 493 minecraft:blackstone
fill 224 152 471 224 153 471 minecraft:light_gray_concrete
fill 224 152 473 224 153 473 minecraft:light_gray_concrete
fill 224 152 475 224 153 475 minecraft:light_gray_concrete
fill 224 152 476 224 153 476 minecraft:black_concrete
fill 224 152 477 224 153 477 minecraft:light_gray_concrete
fill 224 152 500 224 153 500 minecraft:black_concrete
fill 225 152 470 225 153 470 minecraft:light_gray_concrete
fill 225 152 472 225 153 472 minecraft:light_gray_concrete
fill 225 152 474 225 153 474 minecraft:light_gray_concrete
fill 225 152 476 227 153 476 minecraft:light_gray_concrete
fill 225 152 478 225 153 478 minecraft:light_gray_concrete
fill 226 152 471 226 153 471 minecraft:light_gray_concrete
fill 226 152 473 226 153 473 minecraft:light_gray_concrete
fill 226 152 475 226 153 475 minecraft:light_gray_concrete
fill 226 152 477 226 153 477 minecraft:light_gray_concrete
fill 227 152 470 227 153 470 minecraft:light_gray_concrete
fill 227 152 472 227 153 472 minecraft:light_gray_concrete
fill 227 152 474 227 153 474 minecraft:light_gray_concrete
setblock 227 152 475 minecraft:black_concrete
fill 227 152 478 227 153 478 minecraft:light_gray_concrete
setblock 227 152 501 minecraft:black_concrete
fill 228 152 471 228 153 471 minecraft:light_gray_concrete
fill 228 152 473 228 153 473 minecraft:light_gray_concrete
fill 228 152 474 228 153 474 minecraft:black_concrete
fill 228 152 475 228 153 475 minecraft:light_gray_concrete
fill 228 152 477 228 153 477 minecraft:light_gray_concrete
fill 228 152 502 228 153 502 minecraft:black_concrete
fill 229 152 470 229 153 470 minecraft:light_gray_concrete
fill 229 152 472 229 153 472 minecraft:light_gray_concrete
fill 229 152 474 229 153 474 minecraft:light_gray_concrete
fill 229 152 476 229 153 476 minecraft:light_gray_concrete
fill 229 152 478 229 153 478 minecraft:light_gray_concrete
fill 230 152 475 230 157 476 minecraft:light_gray_terracotta
fill 230 152 500 230 157 501 minecraft:light_gray_terracotta
fill 223 153 482 223 155 482 minecraft:blackstone
fill 223 153 494 223 155 494 minecraft:blackstone
fill 225 153 475 225 154 475 minecraft:black_concrete
fill 225 153 501 225 154 501 minecraft:black_concrete
fill 227 153 475 227 155 475 minecraft:light_gray_concrete
fill 189 154 464 189 155 469 minecraft:light_gray_concrete
fill 189 154 472 190 154 477 minecraft:light_gray_concrete
fill 189 154 480 190 154 485 minecraft:light_gray_concrete
fill 189 154 488 190 154 493 minecraft:light_gray_concrete
setblock 189 154 494 minecraft:pearlescent_froglight
setblock 189 154 496 minecraft:pearlescent_froglight
setblock 189 154 498 minecraft:pearlescent_froglight
setblock 189 154 500 minecraft:pearlescent_froglight
setblock 189 154 502 minecraft:pearlescent_froglight
fill 189 154 504 194 155 504 minecraft:light_gray_concrete
fill 190 154 465 190 154 471 minecraft:light_gray_concrete
fill 190 154 478 190 154 479 minecraft:light_gray_concrete
fill 190 154 486 190 154 487 minecraft:light_gray_concrete
setblock 190 154 495 minecraft:pearlescent_froglight
setblock 190 154 497 minecraft:pearlescent_froglight
setblock 190 154 499 minecraft:pearlescent_froglight
setblock 190 154 501 minecraft:pearlescent_froglight
fill 190 154 503 229 154 503 minecraft:light_gray_concrete
fill 191 154 465 228 154 465 minecraft:light_gray_concrete
setblock 191 154 494 minecraft:pearlescent_froglight
setblock 191 154 496 minecraft:pearlescent_froglight
setblock 191 154 498 minecraft:pearlescent_froglight
setblock 191 154 500 minecraft:pearlescent_froglight
setblock 191 154 502 minecraft:pearlescent_froglight
fill 192 154 464 197 155 464 minecraft:light_gray_concrete
setblock 192 154 495 minecraft:pearlescent_froglight
setblock 192 154 497 minecraft:pearlescent_froglight
setblock 192 154 499 minecraft:pearlescent_froglight
setblock 192 154 501 minecraft:pearlescent_froglight
setblock 193 154 494 minecraft:pearlescent_froglight
setblock 193 154 496 minecraft:pearlescent_froglight
setblock 193 154 498 minecraft:pearlescent_froglight
setblock 193 154 500 minecraft:pearlescent_froglight
setblock 193 154 502 minecraft:pearlescent_froglight
setblock 194 154 495 minecraft:pearlescent_froglight
setblock 194 154 497 minecraft:pearlescent_froglight
setblock 194 154 499 minecraft:pearlescent_froglight
setblock 194 154 501 minecraft:pearlescent_froglight
setblock 195 154 494 minecraft:pearlescent_froglight
setblock 195 154 496 minecraft:pearlescent_froglight
setblock 195 154 498 minecraft:pearlescent_froglight
setblock 195 154 500 minecraft:pearlescent_froglight
setblock 195 154 502 minecraft:pearlescent_froglight
fill 197 154 504 202 155 504 minecraft:light_gray_concrete
fill 200 154 464 205 155 464 minecraft:light_gray_concrete
fill 205 154 504 210 155 504 minecraft:light_gray_concrete
fill 208 154 464 213 155 464 minecraft:light_gray_concrete
fill 213 154 504 218 155 504 minecraft:light_gray_concrete
fill 216 154 464 221 155 464 minecraft:light_gray_concrete
setblock 219 154 476 minecraft:black_concrete
setblock 219 154 500 minecraft:black_concrete
fill 221 154 504 226 155 504 minecraft:light_gray_concrete
fill 222 154 474 222 154 475 minecraft:black_concrete
fill 222 154 481 222 154 482 minecraft:blackstone
fill 222 154 494 222 154 495 minecraft:blackstone
fill 222 154 501 222 154 502 minecraft:black_concrete
fill 223 154 481 223 156 481 minecraft:blackstone
fill 223 154 495 223 156 495 minecraft:blackstone
fill 224 154 464 229 155 464 minecraft:light_gray_concrete
setblock 224 154 471 minecraft:pearlescent_froglight
setblock 224 154 473 minecraft:pearlescent_froglight
setblock 224 154 475 minecraft:pearlescent_froglight
fill 224 154 476 224 155 476 minecraft:light_gray_concrete
setblock 224 154 477 minecraft:pearlescent_froglight
setblock 225 154 470 minecraft:pearlescent_froglight
setblock 225 154 472 minecraft:pearlescent_froglight
setblock 225 154 474 minecraft:pearlescent_froglight
setblock 225 154 476 minecraft:pearlescent_froglight
setblock 225 154 478 minecraft:pearlescent_froglight
setblock 226 154 471 minecraft:pearlescent_froglight
setblock 226 154 473 minecraft:pearlescent_froglight
setblock 226 154 475 minecraft:pearlescent_froglight
fill 226 154 476 226 155 476 minecraft:light_gray_concrete
setblock 226 154 477 minecraft:pearlescent_froglight
setblock 227 154 470 minecraft:pearlescent_froglight
setblock 227 154 472 minecraft:pearlescent_froglight
setblock 227 154 474 minecraft:pearlescent_froglight
setblock 227 154 476 minecraft:pearlescent_froglight
setblock 227 154 478 minecraft:pearlescent_froglight
fill 228 154 466 228 154 469 minecraft:light_gray_concrete
setblock 228 154 471 minecraft:pearlescent_froglight
setblock 228 154 473 minecraft:pearlescent_froglight
fill 228 154 474 228 155 474 minecraft:light_gray_concrete
setblock 228 154 475 minecraft:pearlescent_froglight
setblock 228 154 477 minecraft:pearlescent_froglight
fill 228 154 479 228 154 502 minecraft:light_gray_concrete
fill 229 154 467 229 155 469 minecraft:light_gray_concrete
setblock 229 154 470 minecraft:pearlescent_froglight
setblock 229 154 472 minecraft:pearlescent_froglight
setblock 229 154 474 minecraft:pearlescent_froglight
setblock 229 154 476 minecraft:pearlescent_froglight
setblock 229 154 478 minecraft:pearlescent_froglight
fill 229 154 479 229 155 480 minecraft:light_gray_concrete
fill 229 154 483 229 155 488 minecraft:light_gray_concrete
fill 229 154 491 229 155 496 minecraft:light_gray_concrete
fill 229 154 499 229 155 502 minecraft:light_gray_concrete
fill 229 154 504 229 155 504 minecraft:light_gray_concrete
fill 189 155 472 189 155 477 minecraft:light_gray_concrete
fill 189 155 480 189 155 485 minecraft:light_gray_concrete
fill 189 155 488 189 155 494 minecraft:light_gray_concrete
fill 189 155 496 189 156 496 minecraft:light_gray_concrete
fill 189 155 498 189 156 498 minecraft:light_gray_concrete
fill 189 155 500 189 156 500 minecraft:light_gray_concrete
fill 189 155 502 189 156 502 minecraft:light_gray_concrete
fill 190 155 495 190 156 495 minecraft:light_gray_concrete
fill 190 155 497 190 156 497 minecraft:light_gray_concrete
fill 190 155 499 190 156 499 minecraft:light_gray_concrete
fill 190 155 501 190 156 501 minecraft:light_gray_concrete
fill 191 155 494 191 156 494 minecraft:light_gray_concrete
fill 191 155 496 191 156 496 minecraft:light_gray_concrete
fill 191 155 498 191 156 498 minecraft:light_gray_concrete
fill 191 155 500 191 156 500 minecraft:light_gray_concrete
fill 191 155 502 191 156 502 minecraft:light_gray_concrete
fill 192 155 495 192 156 495 minecraft:light_gray_concrete
fill 192 155 497 192 156 497 minecraft:light_gray_concrete
fill 192 155 499 192 156 499 minecraft:light_gray_concrete
fill 192 155 501 192 156 501 minecraft:light_gray_concrete
fill 193 155 494 193 156 494 minecraft:light_gray_concrete
fill 193 155 496 193 156 496 minecraft:light_gray_concrete
fill 193 155 498 193 156 498 minecraft:light_gray_concrete
fill 193 155 500 193 156 500 minecraft:light_gray_concrete
fill 193 155 502 193 156 502 minecraft:light_gray_concrete
fill 194 155 495 194 156 495 minecraft:light_gray_concrete
fill 194 155 497 194 156 497 minecraft:light_gray_concrete
fill 194 155 499 194 156 499 minecraft:light_gray_concrete
fill 194 155 501 194 156 501 minecraft:light_gray_concrete
fill 195 155 494 195 156 494 minecraft:light_gray_concrete
fill 195 155 496 195 156 496 minecraft:light_gray_concrete
fill 195 155 498 195 156 498 minecraft:light_gray_concrete
fill 195 155 500 195 156 500 minecraft:light_gray_concrete
fill 195 155 502 195 156 502 minecraft:light_gray_concrete
fill 219 155 475 219 156 475 minecraft:black_concrete
fill 219 155 501 219 156 501 minecraft:black_concrete
setblock 222 155 474 minecraft:black_concrete
setblock 222 155 482 minecraft:blackstone
setblock 222 155 494 minecraft:blackstone
setblock 222 155 502 minecraft:black_concrete
setblock 224 155 471 minecraft:light_gray_concrete
setblock 224 155 473 minecraft:light_gray_concrete
fill 224 155 475 226 155 475 minecraft:light_gray_concrete
setblock 224 155 477 minecraft:light_gray_concrete
fill 224 155 481 224 156 482 minecraft:blackstone
fill 224 155 494 224 156 495 minecraft:blackstone
setblock 225 155 470 minecraft:light_gray_concrete
setblock 225 155 472 minecraft:light_gray_concrete
setblock 225 155 474 minecraft:light_gray_concrete
setblock 225 155 476 minecraft:light_gray_concrete
setblock 225 155 478 minecraft:light_gray_concrete
setblock 226 155 471 minecraft:light_gray_concrete
setblock 226 155 473 minecraft:light_gray_concrete
setblock 226 155 477 minecraft:light_gray_concrete
setblock 227 155 470 minecraft:light_gray_concrete
setblock 227 155 472 minecraft:light_gray_concrete
setblock 227 155 474 minecraft:light_gray_concrete
setblock 227 155 476 minecraft:light_gray_concrete
setblock 227 155 478 minecraft:light_gray_concrete
setblock 228 155 471 minecraft:light_gray_concrete
setblock 228 155 473 minecraft:light_gray_concrete
setblock 228 155 475 minecraft:light_gray_concrete
setblock 228 155 477 minecraft:light_gray_concrete
setblock 229 155 470 minecraft:light_gray_concrete
setblock 229 155 472 minecraft:light_gray_concrete
fill 229 155 474 229 225 474 minecraft:light_gray_concrete
setblock 229 155 476 minecraft:light_gray_concrete
setblock 229 155 478 minecraft:light_gray_concrete
setblock 229 155 503 minecraft:light_gray_concrete
setblock 189 156 494 minecraft:light_gray_concrete
fill 224 156 480 225 157 480 minecraft:blackstone
fill 224 156 496 225 157 496 minecraft:blackstone
fill 225 156 481 225 157 481 minecraft:blackstone
fill 225 156 495 225 157 495 minecraft:blackstone
setblock 189 157 494 minecraft:pearlescent_froglight
setblock 189 157 496 minecraft:pearlescent_froglight
setblock 189 157 498 minecraft:pearlescent_froglight
setblock 189 157 500 minecraft:pearlescent_froglight
setblock 189 157 502 minecraft:pearlescent_froglight
setblock 190 157 495 minecraft:pearlescent_froglight
setblock 190 157 497 minecraft:pearlescent_froglight
setblock 190 157 499 minecraft:pearlescent_froglight
setblock 190 157 501 minecraft:pearlescent_froglight
setblock 191 157 466 minecraft:light[level=11]
setblock 191 157 474 minecraft:light[level=11]
setblock 191 157 482 minecraft:light[level=11]
setblock 191 157 490 minecraft:light[level=11]
setblock 191 157 494 minecraft:pearlescent_froglight
setblock 191 157 496 minecraft:pearlescent_froglight
setblock 191 157 498 minecraft:pearlescent_froglight
setblock 191 157 500 minecraft:pearlescent_froglight
setblock 191 157 502 minecraft:pearlescent_froglight
setblock 192 157 495 minecraft:pearlescent_froglight
setblock 192 157 497 minecraft:pearlescent_froglight
setblock 192 157 499 minecraft:pearlescent_froglight
setblock 192 157 501 minecraft:pearlescent_froglight
setblock 193 157 494 minecraft:pearlescent_froglight
setblock 193 157 496 minecraft:pearlescent_froglight
setblock 193 157 498 minecraft:pearlescent_froglight
setblock 193 157 500 minecraft:pearlescent_froglight
setblock 193 157 502 minecraft:pearlescent_froglight
setblock 194 157 495 minecraft:pearlescent_froglight
setblock 194 157 497 minecraft:pearlescent_froglight
setblock 194 157 499 minecraft:pearlescent_froglight
schedule function dropper:buildpart/112_2 1t
