fill 287 176 343 287 177 343 minecraft:polished_andesite
fill 287 176 345 287 177 345 minecraft:polished_andesite
fill 287 176 347 287 177 347 minecraft:polished_andesite
fill 287 176 349 287 177 349 minecraft:polished_andesite
fill 287 176 351 287 177 351 minecraft:polished_andesite
fill 287 176 353 287 177 353 minecraft:polished_andesite
fill 288 176 332 288 177 332 minecraft:polished_andesite
fill 288 176 334 288 177 334 minecraft:polished_andesite
fill 288 176 336 288 177 336 minecraft:polished_andesite
fill 288 176 338 288 177 338 minecraft:polished_andesite
fill 288 176 342 288 177 342 minecraft:polished_andesite
fill 288 176 344 288 177 344 minecraft:polished_andesite
fill 288 176 346 288 177 346 minecraft:polished_andesite
fill 288 176 348 288 177 348 minecraft:polished_andesite
fill 288 176 350 288 177 350 minecraft:polished_andesite
fill 288 176 352 288 177 352 minecraft:polished_andesite
fill 288 176 354 288 177 354 minecraft:polished_andesite
fill 288 176 356 288 177 356 minecraft:polished_andesite
fill 288 176 358 288 177 358 minecraft:polished_andesite
fill 288 176 360 288 177 360 minecraft:polished_andesite
fill 288 176 362 288 177 362 minecraft:polished_andesite
fill 289 176 331 289 177 331 minecraft:polished_andesite
fill 289 176 333 289 177 333 minecraft:polished_andesite
fill 289 176 335 289 177 335 minecraft:polished_andesite
fill 289 176 337 289 177 337 minecraft:polished_andesite
fill 289 176 339 289 177 339 minecraft:polished_andesite
fill 289 176 357 289 177 357 minecraft:polished_andesite
fill 289 176 359 289 177 359 minecraft:polished_andesite
fill 289 176 361 289 177 361 minecraft:polished_andesite
fill 289 176 363 289 177 363 minecraft:polished_andesite
fill 290 176 332 290 177 332 minecraft:polished_andesite
fill 290 176 334 290 177 334 minecraft:polished_andesite
fill 290 176 336 290 177 336 minecraft:polished_andesite
fill 290 176 338 290 177 338 minecraft:polished_andesite
fill 290 176 356 290 177 356 minecraft:polished_andesite
fill 290 176 358 290 177 358 minecraft:polished_andesite
fill 290 176 360 290 177 360 minecraft:polished_andesite
fill 290 176 362 290 177 362 minecraft:polished_andesite
fill 291 176 357 291 177 357 minecraft:polished_andesite
fill 291 176 359 291 177 359 minecraft:polished_andesite
fill 291 176 361 291 177 361 minecraft:polished_andesite
fill 291 176 363 291 177 363 minecraft:polished_andesite
fill 292 176 356 292 177 356 minecraft:polished_andesite
fill 292 176 358 292 177 358 minecraft:polished_andesite
fill 292 176 360 292 177 360 minecraft:polished_andesite
fill 292 176 362 292 177 362 minecraft:polished_andesite
fill 293 176 357 293 177 357 minecraft:polished_andesite
fill 293 176 359 293 177 359 minecraft:polished_andesite
fill 293 176 361 293 177 361 minecraft:polished_andesite
fill 293 176 363 293 177 363 minecraft:polished_andesite
fill 294 176 356 294 177 356 minecraft:polished_andesite
fill 294 176 358 294 177 358 minecraft:polished_andesite
fill 294 176 360 294 177 360 minecraft:polished_andesite
fill 294 176 362 294 177 362 minecraft:polished_andesite
fill 295 176 357 295 177 357 minecraft:polished_andesite
fill 295 176 359 295 177 359 minecraft:polished_andesite
fill 295 176 361 295 177 361 minecraft:polished_andesite
fill 295 176 363 295 177 363 minecraft:polished_andesite
fill 296 176 356 296 177 356 minecraft:polished_andesite
fill 296 176 358 296 177 358 minecraft:polished_andesite
fill 296 176 360 296 177 360 minecraft:polished_andesite
fill 296 176 362 296 177 362 minecraft:polished_andesite
setblock 285 177 325 minecraft:light[level=12]
setblock 285 177 360 minecraft:light[level=12]
setblock 292 177 325 minecraft:light[level=12]
setblock 292 177 332 minecraft:light[level=12]
setblock 292 177 339 minecraft:light[level=12]
setblock 292 177 346 minecraft:light[level=12]
setblock 292 177 353 minecraft:light[level=12]
setblock 299 177 325 minecraft:light[level=12]
setblock 299 177 332 minecraft:light[level=12]
setblock 299 177 339 minecraft:light[level=12]
setblock 299 177 346 minecraft:light[level=12]
setblock 299 177 353 minecraft:light[level=12]
setblock 299 177 360 minecraft:light[level=12]
setblock 306 177 332 minecraft:light[level=12]
setblock 306 177 339 minecraft:light[level=12]
setblock 306 177 346 minecraft:light[level=12]
setblock 306 177 353 minecraft:light[level=12]
setblock 306 177 360 minecraft:light[level=12]
setblock 313 177 325 minecraft:light[level=12]
setblock 313 177 332 minecraft:light[level=12]
setblock 313 177 339 minecraft:light[level=12]
setblock 313 177 346 minecraft:light[level=12]
setblock 313 177 353 minecraft:light[level=12]
setblock 313 177 360 minecraft:light[level=12]
setblock 320 177 325 minecraft:light[level=12]
setblock 320 177 332 minecraft:light[level=12]
setblock 320 177 339 minecraft:light[level=12]
setblock 320 177 346 minecraft:light[level=12]
setblock 320 177 353 minecraft:light[level=12]
setblock 320 177 360 minecraft:light[level=12]
setblock 283 178 331 minecraft:shroomlight
setblock 283 178 333 minecraft:shroomlight
setblock 283 178 335 minecraft:shroomlight
setblock 283 178 337 minecraft:shroomlight
setblock 283 178 339 minecraft:shroomlight
setblock 283 178 343 minecraft:shroomlight
setblock 283 178 345 minecraft:shroomlight
setblock 283 178 347 minecraft:shroomlight
setblock 283 178 349 minecraft:shroomlight
setblock 283 178 351 minecraft:shroomlight
setblock 283 178 353 minecraft:shroomlight
setblock 284 178 332 minecraft:shroomlight
setblock 284 178 334 minecraft:shroomlight
setblock 284 178 336 minecraft:shroomlight
setblock 284 178 338 minecraft:shroomlight
setblock 284 178 342 minecraft:shroomlight
setblock 284 178 344 minecraft:shroomlight
setblock 284 178 346 minecraft:shroomlight
setblock 284 178 348 minecraft:shroomlight
setblock 284 178 350 minecraft:shroomlight
setblock 284 178 352 minecraft:shroomlight
setblock 284 178 354 minecraft:shroomlight
setblock 285 178 331 minecraft:shroomlight
setblock 285 178 333 minecraft:shroomlight
setblock 285 178 335 minecraft:shroomlight
setblock 285 178 337 minecraft:shroomlight
setblock 285 178 339 minecraft:shroomlight
setblock 285 178 343 minecraft:shroomlight
setblock 285 178 345 minecraft:shroomlight
setblock 285 178 347 minecraft:shroomlight
setblock 285 178 349 minecraft:shroomlight
setblock 285 178 351 minecraft:shroomlight
setblock 285 178 353 minecraft:shroomlight
setblock 286 178 332 minecraft:shroomlight
setblock 286 178 334 minecraft:shroomlight
setblock 286 178 336 minecraft:shroomlight
setblock 286 178 338 minecraft:shroomlight
setblock 286 178 342 minecraft:shroomlight
setblock 286 178 344 minecraft:shroomlight
setblock 286 178 346 minecraft:shroomlight
setblock 286 178 348 minecraft:shroomlight
setblock 286 178 350 minecraft:shroomlight
setblock 286 178 352 minecraft:shroomlight
setblock 286 178 354 minecraft:shroomlight
setblock 287 178 331 minecraft:shroomlight
setblock 287 178 333 minecraft:shroomlight
setblock 287 178 335 minecraft:shroomlight
setblock 287 178 337 minecraft:shroomlight
setblock 287 178 339 minecraft:shroomlight
setblock 287 178 343 minecraft:shroomlight
setblock 287 178 345 minecraft:shroomlight
setblock 287 178 347 minecraft:shroomlight
setblock 287 178 349 minecraft:shroomlight
setblock 287 178 351 minecraft:shroomlight
setblock 287 178 353 minecraft:shroomlight
setblock 288 178 332 minecraft:shroomlight
setblock 288 178 334 minecraft:shroomlight
setblock 288 178 336 minecraft:shroomlight
setblock 288 178 338 minecraft:shroomlight
setblock 288 178 342 minecraft:shroomlight
setblock 288 178 344 minecraft:shroomlight
setblock 288 178 346 minecraft:shroomlight
setblock 288 178 348 minecraft:shroomlight
setblock 288 178 350 minecraft:shroomlight
setblock 288 178 352 minecraft:shroomlight
setblock 288 178 354 minecraft:shroomlight
setblock 288 178 356 minecraft:shroomlight
setblock 288 178 358 minecraft:shroomlight
setblock 288 178 360 minecraft:shroomlight
setblock 288 178 362 minecraft:shroomlight
setblock 289 178 331 minecraft:shroomlight
setblock 289 178 333 minecraft:shroomlight
setblock 289 178 335 minecraft:shroomlight
setblock 289 178 337 minecraft:shroomlight
setblock 289 178 339 minecraft:shroomlight
setblock 289 178 357 minecraft:shroomlight
setblock 289 178 359 minecraft:shroomlight
setblock 289 178 361 minecraft:shroomlight
setblock 289 178 363 minecraft:shroomlight
setblock 290 178 332 minecraft:shroomlight
setblock 290 178 334 minecraft:shroomlight
setblock 290 178 336 minecraft:shroomlight
setblock 290 178 338 minecraft:shroomlight
setblock 290 178 356 minecraft:shroomlight
setblock 290 178 358 minecraft:shroomlight
setblock 290 178 360 minecraft:shroomlight
setblock 290 178 362 minecraft:shroomlight
setblock 291 178 357 minecraft:shroomlight
setblock 291 178 359 minecraft:shroomlight
setblock 291 178 361 minecraft:shroomlight
setblock 291 178 363 minecraft:shroomlight
setblock 292 178 356 minecraft:shroomlight
setblock 292 178 358 minecraft:shroomlight
setblock 292 178 360 minecraft:shroomlight
setblock 292 178 362 minecraft:shroomlight
setblock 293 178 357 minecraft:shroomlight
setblock 293 178 359 minecraft:shroomlight
setblock 293 178 361 minecraft:shroomlight
setblock 293 178 363 minecraft:shroomlight
setblock 294 178 356 minecraft:shroomlight
setblock 294 178 358 minecraft:shroomlight
setblock 294 178 360 minecraft:shroomlight
setblock 294 178 362 minecraft:shroomlight
setblock 295 178 357 minecraft:shroomlight
setblock 295 178 359 minecraft:shroomlight
setblock 295 178 361 minecraft:shroomlight
setblock 295 178 363 minecraft:shroomlight
setblock 296 178 356 minecraft:shroomlight
setblock 296 178 358 minecraft:shroomlight
setblock 296 178 360 minecraft:shroomlight
setblock 296 178 362 minecraft:shroomlight
fill 297 178 357 298 181 357 minecraft:cobblestone
fill 283 179 331 283 180 331 minecraft:polished_andesite
fill 283 179 333 283 180 333 minecraft:polished_andesite
fill 283 179 335 283 180 335 minecraft:polished_andesite
fill 283 179 337 283 180 337 minecraft:polished_andesite
fill 283 179 339 283 180 339 minecraft:polished_andesite
fill 283 179 343 283 180 343 minecraft:polished_andesite
fill 283 179 345 283 180 345 minecraft:polished_andesite
fill 283 179 347 283 180 347 minecraft:polished_andesite
fill 283 179 349 283 180 349 minecraft:polished_andesite
setblock 283 179 351 minecraft:polished_andesite
setblock 283 179 353 minecraft:polished_andesite
fill 284 179 332 284 180 332 minecraft:polished_andesite
fill 284 179 334 284 180 334 minecraft:polished_andesite
fill 284 179 336 284 180 336 minecraft:polished_andesite
fill 284 179 338 284 180 338 minecraft:polished_andesite
fill 284 179 342 284 180 342 minecraft:polished_andesite
fill 284 179 344 284 180 344 minecraft:polished_andesite
fill 284 179 346 284 180 346 minecraft:polished_andesite
fill 284 179 348 284 180 348 minecraft:polished_andesite
fill 284 179 350 284 180 350 minecraft:polished_andesite
fill 284 179 352 284 180 352 minecraft:polished_andesite
fill 284 179 354 284 180 354 minecraft:polished_andesite
fill 285 179 331 285 180 331 minecraft:polished_andesite
fill 285 179 333 285 180 333 minecraft:polished_andesite
fill 285 179 335 285 180 335 minecraft:polished_andesite
fill 285 179 337 285 180 337 minecraft:polished_andesite
fill 285 179 339 285 180 339 minecraft:polished_andesite
fill 285 179 343 285 180 343 minecraft:polished_andesite
fill 285 179 345 285 180 345 minecraft:polished_andesite
fill 285 179 347 285 180 347 minecraft:polished_andesite
fill 285 179 349 285 180 349 minecraft:polished_andesite
fill 285 179 351 285 180 351 minecraft:polished_andesite
fill 285 179 353 285 180 353 minecraft:polished_andesite
fill 286 179 332 286 180 332 minecraft:polished_andesite
fill 286 179 334 286 180 334 minecraft:polished_andesite
fill 286 179 336 286 180 336 minecraft:polished_andesite
fill 286 179 338 286 180 338 minecraft:polished_andesite
fill 286 179 342 286 180 342 minecraft:polished_andesite
fill 286 179 344 286 180 344 minecraft:polished_andesite
fill 286 179 346 286 180 346 minecraft:polished_andesite
fill 286 179 348 286 180 348 minecraft:polished_andesite
fill 286 179 350 286 180 350 minecraft:polished_andesite
fill 286 179 352 286 180 352 minecraft:polished_andesite
fill 286 179 354 286 180 354 minecraft:polished_andesite
fill 287 179 331 287 180 331 minecraft:polished_andesite
fill 287 179 333 287 180 333 minecraft:polished_andesite
fill 287 179 335 287 180 335 minecraft:polished_andesite
fill 287 179 337 287 180 337 minecraft:polished_andesite
fill 287 179 339 287 180 339 minecraft:polished_andesite
fill 287 179 343 287 180 343 minecraft:polished_andesite
fill 287 179 345 287 180 345 minecraft:polished_andesite
fill 287 179 347 287 180 347 minecraft:polished_andesite
fill 287 179 349 287 180 349 minecraft:polished_andesite
fill 287 179 351 287 180 351 minecraft:polished_andesite
fill 287 179 353 287 180 353 minecraft:polished_andesite
fill 288 179 332 288 180 332 minecraft:polished_andesite
fill 288 179 334 288 180 334 minecraft:polished_andesite
fill 288 179 336 288 180 336 minecraft:polished_andesite
fill 288 179 338 288 180 338 minecraft:polished_andesite
fill 288 179 342 288 180 342 minecraft:polished_andesite
fill 288 179 344 288 180 344 minecraft:polished_andesite
fill 288 179 346 288 180 346 minecraft:polished_andesite
fill 288 179 348 288 180 348 minecraft:polished_andesite
fill 288 179 350 288 180 350 minecraft:polished_andesite
fill 288 179 352 288 180 352 minecraft:polished_andesite
fill 288 179 354 288 180 354 minecraft:polished_andesite
fill 288 179 356 288 180 356 minecraft:polished_andesite
fill 288 179 358 288 180 358 minecraft:polished_andesite
fill 288 179 360 288 180 360 minecraft:polished_andesite
fill 288 179 362 288 180 362 minecraft:polished_andesite
fill 289 179 331 289 180 331 minecraft:polished_andesite
fill 289 179 333 289 180 333 minecraft:polished_andesite
fill 289 179 335 289 180 335 minecraft:polished_andesite
fill 289 179 337 289 180 337 minecraft:polished_andesite
fill 289 179 339 289 180 339 minecraft:polished_andesite
fill 289 179 357 289 180 357 minecraft:polished_andesite
fill 289 179 359 289 180 359 minecraft:polished_andesite
fill 289 179 361 289 180 361 minecraft:polished_andesite
fill 289 179 363 289 180 363 minecraft:polished_andesite
fill 290 179 332 290 180 332 minecraft:polished_andesite
fill 290 179 334 290 180 334 minecraft:polished_andesite
fill 290 179 336 290 180 336 minecraft:polished_andesite
fill 290 179 338 290 180 338 minecraft:polished_andesite
fill 290 179 356 290 180 356 minecraft:polished_andesite
fill 290 179 358 290 180 358 minecraft:polished_andesite
fill 290 179 360 290 180 360 minecraft:polished_andesite
fill 290 179 362 290 180 362 minecraft:polished_andesite
fill 291 179 357 291 180 357 minecraft:polished_andesite
fill 291 179 359 291 180 359 minecraft:polished_andesite
fill 291 179 361 291 180 361 minecraft:polished_andesite
fill 291 179 363 291 180 363 minecraft:polished_andesite
fill 292 179 356 292 180 356 minecraft:polished_andesite
fill 292 179 358 292 180 358 minecraft:polished_andesite
fill 292 179 360 292 180 360 minecraft:polished_andesite
fill 292 179 362 292 180 362 minecraft:polished_andesite
fill 293 179 357 293 180 357 minecraft:polished_andesite
fill 293 179 359 293 180 359 minecraft:polished_andesite
fill 293 179 361 293 180 361 minecraft:polished_andesite
fill 293 179 363 293 180 363 minecraft:polished_andesite
fill 294 179 356 294 180 356 minecraft:polished_andesite
fill 294 179 358 294 180 358 minecraft:polished_andesite
fill 294 179 360 294 180 360 minecraft:polished_andesite
fill 294 179 362 294 180 362 minecraft:polished_andesite
fill 295 179 357 295 180 357 minecraft:polished_andesite
fill 295 179 359 295 180 359 minecraft:polished_andesite
fill 295 179 361 295 180 361 minecraft:polished_andesite
setblock 295 179 363 minecraft:polished_andesite
fill 296 179 356 296 180 358 minecraft:cobblestone
fill 296 179 360 296 180 360 minecraft:polished_andesite
fill 296 179 362 296 180 362 minecraft:polished_andesite
fill 297 179 356 298 180 356 minecraft:cobblestone
fill 297 179 358 298 180 358 minecraft:cobblestone
fill 283 180 351 283 180 353 minecraft:yellow_wool
fill 284 180 356 284 185 358 minecraft:polished_andesite
fill 293 180 323 295 182 323 minecraft:red_wool
fill 294 180 324 296 185 324 minecraft:polished_andesite
fill 295 180 363 297 180 363 minecraft:blue_wool
fill 296 180 323 297 225 323 minecraft:polished_andesite
fill 302 180 362 304 185 362 minecraft:polished_andesite
fill 314 180 362 316 185 362 minecraft:polished_andesite
fill 318 180 324 320 185 324 minecraft:polished_andesite
fill 322 180 332 322 185 334 minecraft:polished_andesite
fill 322 180 344 322 185 346 minecraft:polished_andesite
fill 322 180 356 322 185 358 minecraft:polished_andesite
fill 323 180 349 323 182 351 minecraft:red_wool
setblock 283 181 331 minecraft:shroomlight
setblock 283 181 333 minecraft:shroomlight
setblock 283 181 335 minecraft:shroomlight
setblock 283 181 337 minecraft:shroomlight
setblock 283 181 339 minecraft:shroomlight
setblock 283 181 343 minecraft:shroomlight
setblock 283 181 345 minecraft:shroomlight
setblock 283 181 347 minecraft:shroomlight
setblock 283 181 349 minecraft:shroomlight
setblock 283 181 351 minecraft:shroomlight
fill 283 181 352 283 182 352 minecraft:yellow_wool
setblock 283 181 353 minecraft:shroomlight
setblock 284 181 332 minecraft:shroomlight
setblock 284 181 334 minecraft:shroomlight
setblock 284 181 336 minecraft:shroomlight
setblock 284 181 338 minecraft:shroomlight
setblock 284 181 342 minecraft:shroomlight
setblock 284 181 344 minecraft:shroomlight
setblock 284 181 346 minecraft:shroomlight
setblock 284 181 348 minecraft:shroomlight
setblock 284 181 350 minecraft:shroomlight
setblock 284 181 352 minecraft:shroomlight
setblock 284 181 354 minecraft:shroomlight
setblock 285 181 331 minecraft:shroomlight
setblock 285 181 333 minecraft:shroomlight
setblock 285 181 335 minecraft:shroomlight
setblock 285 181 337 minecraft:shroomlight
setblock 285 181 339 minecraft:shroomlight
setblock 285 181 343 minecraft:shroomlight
setblock 285 181 345 minecraft:shroomlight
setblock 285 181 347 minecraft:shroomlight
setblock 285 181 349 minecraft:shroomlight
setblock 285 181 351 minecraft:shroomlight
setblock 285 181 353 minecraft:shroomlight
setblock 286 181 332 minecraft:shroomlight
setblock 286 181 334 minecraft:shroomlight
setblock 286 181 336 minecraft:shroomlight
setblock 286 181 338 minecraft:shroomlight
setblock 286 181 342 minecraft:shroomlight
setblock 286 181 344 minecraft:shroomlight
setblock 286 181 346 minecraft:shroomlight
setblock 286 181 348 minecraft:shroomlight
setblock 286 181 350 minecraft:shroomlight
setblock 286 181 352 minecraft:shroomlight
setblock 286 181 354 minecraft:shroomlight
setblock 287 181 331 minecraft:shroomlight
setblock 287 181 333 minecraft:shroomlight
setblock 287 181 335 minecraft:shroomlight
setblock 287 181 337 minecraft:shroomlight
setblock 287 181 339 minecraft:shroomlight
setblock 287 181 343 minecraft:shroomlight
setblock 287 181 345 minecraft:shroomlight
setblock 287 181 347 minecraft:shroomlight
setblock 287 181 349 minecraft:shroomlight
setblock 287 181 351 minecraft:shroomlight
setblock 287 181 353 minecraft:shroomlight
setblock 288 181 332 minecraft:shroomlight
setblock 288 181 334 minecraft:shroomlight
setblock 288 181 336 minecraft:shroomlight
setblock 288 181 338 minecraft:shroomlight
setblock 288 181 342 minecraft:shroomlight
setblock 288 181 344 minecraft:shroomlight
setblock 288 181 346 minecraft:shroomlight
setblock 288 181 348 minecraft:shroomlight
setblock 288 181 350 minecraft:shroomlight
setblock 288 181 352 minecraft:shroomlight
setblock 288 181 354 minecraft:shroomlight
setblock 288 181 356 minecraft:shroomlight
setblock 288 181 358 minecraft:shroomlight
setblock 288 181 360 minecraft:shroomlight
setblock 288 181 362 minecraft:shroomlight
setblock 289 181 331 minecraft:shroomlight
setblock 289 181 333 minecraft:shroomlight
setblock 289 181 335 minecraft:shroomlight
setblock 289 181 337 minecraft:shroomlight
setblock 289 181 339 minecraft:shroomlight
setblock 289 181 357 minecraft:shroomlight
setblock 289 181 359 minecraft:shroomlight
setblock 289 181 361 minecraft:shroomlight
setblock 289 181 363 minecraft:shroomlight
setblock 290 181 332 minecraft:shroomlight
setblock 290 181 334 minecraft:shroomlight
setblock 290 181 336 minecraft:shroomlight
setblock 290 181 338 minecraft:shroomlight
setblock 290 181 356 minecraft:shroomlight
setblock 290 181 358 minecraft:shroomlight
setblock 290 181 360 minecraft:shroomlight
setblock 290 181 362 minecraft:shroomlight
setblock 291 181 357 minecraft:shroomlight
setblock 291 181 359 minecraft:shroomlight
setblock 291 181 361 minecraft:shroomlight
setblock 291 181 363 minecraft:shroomlight
setblock 292 181 356 minecraft:shroomlight
setblock 292 181 358 minecraft:shroomlight
setblock 292 181 360 minecraft:shroomlight
setblock 292 181 362 minecraft:shroomlight
setblock 293 181 357 minecraft:shroomlight
setblock 293 181 359 minecraft:shroomlight
setblock 293 181 361 minecraft:shroomlight
setblock 293 181 363 minecraft:shroomlight
setblock 294 181 356 minecraft:shroomlight
setblock 294 181 358 minecraft:shroomlight
setblock 294 181 360 minecraft:shroomlight
setblock 294 181 362 minecraft:shroomlight
setblock 295 181 357 minecraft:shroomlight
setblock 295 181 359 minecraft:shroomlight
setblock 295 181 361 minecraft:shroomlight
setblock 295 181 363 minecraft:shroomlight
setblock 296 181 356 minecraft:shroomlight
fill 296 181 357 296 193 357 minecraft:polished_andesite
setblock 296 181 358 minecraft:shroomlight
setblock 296 181 360 minecraft:shroomlight
setblock 296 181 362 minecraft:shroomlight
fill 296 181 363 297 182 363 minecraft:blue_wool
setblock 297 181 356 minecraft:cobblestone
fill 283 182 331 283 183 331 minecraft:polished_andesite
fill 283 182 333 283 183 333 minecraft:polished_andesite
fill 283 182 335 283 183 335 minecraft:polished_andesite
fill 283 182 337 283 183 337 minecraft:polished_andesite
fill 283 182 339 283 183 339 minecraft:polished_andesite
fill 283 182 343 283 183 343 minecraft:polished_andesite
fill 283 182 345 283 183 345 minecraft:polished_andesite
fill 283 182 347 283 183 347 minecraft:polished_andesite
fill 283 182 349 283 183 349 minecraft:polished_andesite
fill 283 182 351 283 183 351 minecraft:yellow_wool
fill 283 182 353 283 183 353 minecraft:yellow_wool
fill 284 182 332 284 183 332 minecraft:polished_andesite
fill 284 182 334 284 183 334 minecraft:polished_andesite
fill 284 182 336 284 183 336 minecraft:polished_andesite
fill 284 182 338 284 183 338 minecraft:polished_andesite
fill 284 182 342 284 183 342 minecraft:polished_andesite
fill 284 182 344 284 183 344 minecraft:polished_andesite
fill 284 182 346 284 183 346 minecraft:polished_andesite
fill 284 182 348 284 183 348 minecraft:polished_andesite
fill 284 182 350 284 183 350 minecraft:polished_andesite
fill 284 182 352 284 183 352 minecraft:polished_andesite
fill 284 182 354 284 183 354 minecraft:polished_andesite
fill 285 182 331 285 183 331 minecraft:polished_andesite
fill 285 182 333 285 183 333 minecraft:polished_andesite
fill 285 182 335 285 183 335 minecraft:polished_andesite
fill 285 182 337 285 183 337 minecraft:polished_andesite
fill 285 182 339 285 183 339 minecraft:polished_andesite
fill 285 182 343 285 183 343 minecraft:polished_andesite
fill 285 182 345 285 183 345 minecraft:polished_andesite
fill 285 182 347 285 183 347 minecraft:polished_andesite
fill 285 182 349 285 183 349 minecraft:polished_andesite
fill 285 182 351 285 183 351 minecraft:polished_andesite
fill 285 182 353 285 183 353 minecraft:polished_andesite
fill 286 182 332 286 183 332 minecraft:polished_andesite
fill 286 182 334 286 183 334 minecraft:polished_andesite
fill 286 182 336 286 183 336 minecraft:polished_andesite
fill 286 182 338 286 183 338 minecraft:polished_andesite
fill 286 182 342 286 183 342 minecraft:polished_andesite
fill 286 182 344 286 183 344 minecraft:polished_andesite
fill 286 182 346 286 183 346 minecraft:polished_andesite
fill 286 182 348 286 183 348 minecraft:polished_andesite
fill 286 182 350 286 183 350 minecraft:polished_andesite
fill 286 182 352 286 183 352 minecraft:polished_andesite
fill 286 182 354 286 183 354 minecraft:polished_andesite
fill 287 182 331 287 183 331 minecraft:polished_andesite
fill 287 182 333 287 183 333 minecraft:polished_andesite
fill 287 182 335 287 183 335 minecraft:polished_andesite
fill 287 182 337 287 183 337 minecraft:polished_andesite
fill 287 182 339 287 183 339 minecraft:polished_andesite
fill 287 182 343 287 183 343 minecraft:polished_andesite
fill 287 182 345 287 183 345 minecraft:polished_andesite
fill 287 182 347 287 183 347 minecraft:polished_andesite
fill 287 182 349 287 183 349 minecraft:polished_andesite
fill 287 182 351 287 183 351 minecraft:polished_andesite
fill 287 182 353 287 183 353 minecraft:polished_andesite
fill 288 182 332 288 183 332 minecraft:polished_andesite
fill 288 182 334 288 183 334 minecraft:polished_andesite
fill 288 182 336 288 183 336 minecraft:polished_andesite
fill 288 182 338 288 183 338 minecraft:polished_andesite
fill 288 182 342 288 183 342 minecraft:polished_andesite
fill 288 182 344 288 183 344 minecraft:polished_andesite
fill 288 182 346 288 183 346 minecraft:polished_andesite
fill 288 182 348 288 183 348 minecraft:polished_andesite
fill 288 182 350 288 183 350 minecraft:polished_andesite
fill 288 182 352 288 183 352 minecraft:polished_andesite
fill 288 182 354 288 183 354 minecraft:polished_andesite
fill 288 182 356 288 183 356 minecraft:polished_andesite
fill 288 182 358 288 183 358 minecraft:polished_andesite
fill 288 182 360 288 183 360 minecraft:polished_andesite
fill 288 182 362 288 183 362 minecraft:polished_andesite
fill 289 182 331 289 183 331 minecraft:polished_andesite
fill 289 182 333 289 183 333 minecraft:polished_andesite
fill 289 182 335 289 183 335 minecraft:polished_andesite
fill 289 182 337 289 183 337 minecraft:polished_andesite
fill 289 182 339 289 183 339 minecraft:polished_andesite
fill 289 182 357 289 183 357 minecraft:polished_andesite
fill 289 182 359 289 183 359 minecraft:polished_andesite
fill 289 182 361 289 183 361 minecraft:polished_andesite
fill 289 182 363 289 183 363 minecraft:polished_andesite
fill 290 182 332 290 183 332 minecraft:polished_andesite
fill 290 182 334 290 183 334 minecraft:polished_andesite
fill 290 182 336 290 183 336 minecraft:polished_andesite
fill 290 182 338 290 183 338 minecraft:polished_andesite
fill 290 182 356 290 183 356 minecraft:polished_andesite
fill 290 182 358 290 183 358 minecraft:polished_andesite
fill 290 182 360 290 183 360 minecraft:polished_andesite
fill 290 182 362 290 183 362 minecraft:polished_andesite
fill 291 182 357 291 183 357 minecraft:polished_andesite
fill 291 182 359 291 183 359 minecraft:polished_andesite
fill 291 182 361 291 183 361 minecraft:polished_andesite
fill 291 182 363 291 183 363 minecraft:polished_andesite
fill 292 182 356 292 183 356 minecraft:polished_andesite
fill 292 182 358 292 183 358 minecraft:polished_andesite
fill 292 182 360 292 183 360 minecraft:polished_andesite
fill 292 182 362 292 183 362 minecraft:polished_andesite
fill 293 182 357 293 183 357 minecraft:polished_andesite
fill 293 182 359 293 183 359 minecraft:polished_andesite
fill 293 182 361 293 183 361 minecraft:polished_andesite
fill 293 182 363 293 183 363 minecraft:polished_andesite
fill 294 182 356 294 183 356 minecraft:polished_andesite
fill 294 182 358 294 183 358 minecraft:polished_andesite
fill 294 182 360 294 183 360 minecraft:polished_andesite
fill 294 182 362 294 183 362 minecraft:polished_andesite
fill 295 182 357 295 183 357 minecraft:polished_andesite
fill 295 182 359 295 183 359 minecraft:polished_andesite
fill 295 182 361 295 183 361 minecraft:polished_andesite
fill 295 182 363 295 183 363 minecraft:blue_wool
fill 296 182 356 296 183 356 minecraft:polished_andesite
fill 296 182 358 296 183 358 minecraft:polished_andesite
fill 296 182 360 296 183 360 minecraft:polished_andesite
fill 296 182 362 296 183 362 minecraft:polished_andesite
fill 283 183 352 283 185 352 minecraft:gold_block
setblock 285 183 325 minecraft:light[level=15]
setblock 285 183 341 minecraft:light[level=15]
setblock 285 183 357 minecraft:light[level=15]
setblock 285 183 360 minecraft:light[level=12]
setblock 292 183 325 minecraft:light[level=12]
setblock 292 183 332 minecraft:light[level=12]
setblock 292 183 339 minecraft:light[level=12]
setblock 292 183 346 minecraft:light[level=12]
setblock 292 183 353 minecraft:light[level=12]
fill 293 183 323 293 188 323 minecraft:red_wool
setblock 293 183 325 minecraft:light[level=15]
setblock 293 183 333 minecraft:light[level=15]
setblock 293 183 341 minecraft:light[level=15]
setblock 293 183 349 minecraft:light[level=15]
fill 294 183 323 294 185 323 minecraft:gold_block
fill 295 183 323 295 188 323 minecraft:red_wool
fill 296 183 363 296 185 363 minecraft:gold_block
fill 297 183 363 297 188 363 minecraft:blue_wool
setblock 299 183 325 minecraft:light[level=12]
setblock 299 183 332 minecraft:light[level=12]
setblock 299 183 339 minecraft:light[level=12]
setblock 299 183 346 minecraft:light[level=12]
setblock 299 183 353 minecraft:light[level=12]
setblock 299 183 360 minecraft:light[level=12]
setblock 301 183 325 minecraft:light[level=15]
setblock 301 183 333 minecraft:light[level=15]
setblock 301 183 349 minecraft:light[level=15]
setblock 301 183 357 minecraft:light[level=15]
setblock 306 183 332 minecraft:light[level=12]
setblock 306 183 339 minecraft:light[level=12]
setblock 306 183 346 minecraft:light[level=12]
setblock 306 183 353 minecraft:light[level=12]
setblock 306 183 360 minecraft:light[level=12]
setblock 309 183 333 minecraft:light[level=15]
setblock 309 183 341 minecraft:light[level=15]
setblock 309 183 349 minecraft:light[level=15]
setblock 309 183 357 minecraft:light[level=15]
setblock 313 183 325 minecraft:light[level=12]
setblock 313 183 332 minecraft:light[level=12]
setblock 313 183 339 minecraft:light[level=12]
setblock 313 183 346 minecraft:light[level=12]
setblock 313 183 353 minecraft:light[level=12]
setblock 313 183 360 minecraft:light[level=12]
setblock 317 183 325 minecraft:light[level=15]
setblock 317 183 333 minecraft:light[level=15]
setblock 317 183 341 minecraft:light[level=15]
setblock 317 183 349 minecraft:light[level=15]
setblock 317 183 357 minecraft:light[level=15]
setblock 320 183 325 minecraft:light[level=12]
setblock 320 183 332 minecraft:light[level=12]
setblock 320 183 339 minecraft:light[level=12]
setblock 320 183 346 minecraft:light[level=12]
setblock 320 183 353 minecraft:light[level=12]
setblock 320 183 360 minecraft:light[level=12]
fill 323 183 349 323 188 349 minecraft:red_wool
fill 323 183 350 323 185 350 minecraft:gold_block
fill 323 183 351 323 188 351 minecraft:red_wool
setblock 283 184 331 minecraft:shroomlight
setblock 283 184 333 minecraft:shroomlight
setblock 283 184 335 minecraft:shroomlight
setblock 283 184 337 minecraft:shroomlight
setblock 283 184 339 minecraft:shroomlight
setblock 283 184 343 minecraft:shroomlight
setblock 283 184 345 minecraft:shroomlight
setblock 283 184 347 minecraft:shroomlight
setblock 283 184 349 minecraft:shroomlight
setblock 283 184 351 minecraft:shroomlight
setblock 283 184 353 minecraft:shroomlight
setblock 284 184 332 minecraft:shroomlight
setblock 284 184 334 minecraft:shroomlight
setblock 284 184 336 minecraft:shroomlight
setblock 284 184 338 minecraft:shroomlight
setblock 284 184 342 minecraft:shroomlight
setblock 284 184 344 minecraft:shroomlight
setblock 284 184 346 minecraft:shroomlight
setblock 284 184 348 minecraft:shroomlight
setblock 284 184 350 minecraft:shroomlight
setblock 284 184 352 minecraft:shroomlight
setblock 284 184 354 minecraft:shroomlight
setblock 285 184 331 minecraft:shroomlight
setblock 285 184 333 minecraft:shroomlight
setblock 285 184 335 minecraft:shroomlight
setblock 285 184 337 minecraft:shroomlight
setblock 285 184 339 minecraft:shroomlight
setblock 285 184 343 minecraft:shroomlight
setblock 285 184 345 minecraft:shroomlight
setblock 285 184 347 minecraft:shroomlight
setblock 285 184 349 minecraft:shroomlight
setblock 285 184 351 minecraft:shroomlight
setblock 285 184 353 minecraft:shroomlight
setblock 286 184 332 minecraft:shroomlight
setblock 286 184 334 minecraft:shroomlight
setblock 286 184 336 minecraft:shroomlight
setblock 286 184 338 minecraft:shroomlight
setblock 286 184 342 minecraft:shroomlight
setblock 286 184 344 minecraft:shroomlight
setblock 286 184 346 minecraft:shroomlight
setblock 286 184 348 minecraft:shroomlight
setblock 286 184 350 minecraft:shroomlight
setblock 286 184 352 minecraft:shroomlight
setblock 286 184 354 minecraft:shroomlight
setblock 287 184 331 minecraft:shroomlight
setblock 287 184 333 minecraft:shroomlight
setblock 287 184 335 minecraft:shroomlight
setblock 287 184 337 minecraft:shroomlight
setblock 287 184 339 minecraft:shroomlight
setblock 287 184 343 minecraft:shroomlight
setblock 287 184 345 minecraft:shroomlight
setblock 287 184 347 minecraft:shroomlight
setblock 287 184 349 minecraft:shroomlight
setblock 287 184 351 minecraft:shroomlight
setblock 287 184 353 minecraft:shroomlight
setblock 288 184 332 minecraft:shroomlight
setblock 288 184 334 minecraft:shroomlight
setblock 288 184 336 minecraft:shroomlight
setblock 288 184 338 minecraft:shroomlight
setblock 288 184 342 minecraft:shroomlight
setblock 288 184 344 minecraft:shroomlight
setblock 288 184 346 minecraft:shroomlight
setblock 288 184 348 minecraft:shroomlight
setblock 288 184 350 minecraft:shroomlight
setblock 288 184 352 minecraft:shroomlight
setblock 288 184 354 minecraft:shroomlight
setblock 288 184 356 minecraft:shroomlight
setblock 288 184 358 minecraft:shroomlight
setblock 288 184 360 minecraft:shroomlight
setblock 288 184 362 minecraft:shroomlight
setblock 289 184 331 minecraft:shroomlight
setblock 289 184 333 minecraft:shroomlight
setblock 289 184 335 minecraft:shroomlight
setblock 289 184 337 minecraft:shroomlight
setblock 289 184 339 minecraft:shroomlight
setblock 289 184 357 minecraft:shroomlight
setblock 289 184 359 minecraft:shroomlight
setblock 289 184 361 minecraft:shroomlight
setblock 289 184 363 minecraft:shroomlight
setblock 290 184 332 minecraft:shroomlight
setblock 290 184 334 minecraft:shroomlight
setblock 290 184 336 minecraft:shroomlight
setblock 290 184 338 minecraft:shroomlight
setblock 290 184 356 minecraft:shroomlight
setblock 290 184 358 minecraft:shroomlight
setblock 290 184 360 minecraft:shroomlight
setblock 290 184 362 minecraft:shroomlight
setblock 291 184 357 minecraft:shroomlight
setblock 291 184 359 minecraft:shroomlight
setblock 291 184 361 minecraft:shroomlight
setblock 291 184 363 minecraft:shroomlight
setblock 292 184 356 minecraft:shroomlight
setblock 292 184 358 minecraft:shroomlight
setblock 292 184 360 minecraft:shroomlight
setblock 292 184 362 minecraft:shroomlight
setblock 293 184 357 minecraft:shroomlight
setblock 293 184 359 minecraft:shroomlight
setblock 293 184 361 minecraft:shroomlight
setblock 293 184 363 minecraft:shroomlight
setblock 294 184 356 minecraft:shroomlight
setblock 294 184 358 minecraft:shroomlight
setblock 294 184 360 minecraft:shroomlight
setblock 294 184 362 minecraft:shroomlight
setblock 295 184 357 minecraft:shroomlight
setblock 295 184 359 minecraft:shroomlight
setblock 295 184 361 minecraft:shroomlight
setblock 295 184 363 minecraft:shroomlight
setblock 296 184 356 minecraft:shroomlight
setblock 296 184 358 minecraft:shroomlight
setblock 296 184 360 minecraft:shroomlight
setblock 296 184 362 minecraft:shroomlight
fill 283 185 326 283 185 331 minecraft:cobblestone
fill 283 185 333 283 186 333 minecraft:polished_andesite
fill 283 185 335 283 186 335 minecraft:polished_andesite
fill 283 185 337 283 186 337 minecraft:polished_andesite
fill 283 185 338 283 185 343 minecraft:cobblestone
fill 283 185 345 283 186 345 minecraft:polished_andesite
fill 283 185 347 283 186 347 minecraft:polished_andesite
fill 283 185 349 283 186 349 minecraft:polished_andesite
setblock 283 185 350 minecraft:cobblestone
fill 283 185 351 283 186 351 minecraft:yellow_wool
fill 283 185 353 283 186 353 minecraft:yellow_wool
fill 283 185 354 283 185 355 minecraft:cobblestone
fill 283 185 362 283 185 363 minecraft:cobblestone
fill 284 185 332 284 186 332 minecraft:polished_andesite
fill 284 185 334 284 186 334 minecraft:polished_andesite
fill 284 185 336 284 186 336 minecraft:polished_andesite
fill 284 185 338 284 186 338 minecraft:polished_andesite
fill 284 185 342 284 186 342 minecraft:polished_andesite
fill 284 185 344 284 186 344 minecraft:polished_andesite
fill 284 185 346 284 186 346 minecraft:polished_andesite
fill 284 185 348 284 186 348 minecraft:polished_andesite
fill 284 185 350 284 186 350 minecraft:polished_andesite
fill 284 185 352 284 186 352 minecraft:polished_andesite
fill 284 185 354 284 186 354 minecraft:polished_andesite
fill 284 185 363 287 185 363 minecraft:cobblestone
fill 285 185 331 285 186 331 minecraft:polished_andesite
fill 285 185 333 285 186 333 minecraft:polished_andesite
fill 285 185 335 285 186 335 minecraft:polished_andesite
fill 285 185 337 285 186 337 minecraft:polished_andesite
fill 285 185 339 285 186 339 minecraft:polished_andesite
fill 285 185 343 285 186 343 minecraft:polished_andesite
fill 285 185 345 285 186 345 minecraft:polished_andesite
fill 285 185 347 285 186 347 minecraft:polished_andesite
fill 285 185 349 285 186 349 minecraft:polished_andesite
fill 285 185 351 285 186 351 minecraft:polished_andesite
fill 285 185 353 285 186 353 minecraft:polished_andesite
fill 286 185 332 286 186 332 minecraft:polished_andesite
fill 286 185 334 286 186 334 minecraft:polished_andesite
fill 286 185 336 286 186 336 minecraft:polished_andesite
fill 286 185 338 286 186 338 minecraft:polished_andesite
fill 286 185 342 286 186 342 minecraft:polished_andesite
fill 286 185 344 286 186 344 minecraft:polished_andesite
fill 286 185 346 286 186 346 minecraft:polished_andesite
fill 286 185 348 286 186 348 minecraft:polished_andesite
fill 286 185 350 286 186 350 minecraft:polished_andesite
fill 286 185 352 286 186 352 minecraft:polished_andesite
fill 286 185 354 286 186 354 minecraft:polished_andesite
fill 287 185 323 292 185 323 minecraft:cobblestone
fill 287 185 331 287 186 331 minecraft:polished_andesite
fill 287 185 333 287 186 333 minecraft:polished_andesite
fill 287 185 335 287 186 335 minecraft:polished_andesite
fill 287 185 337 287 186 337 minecraft:polished_andesite
fill 287 185 339 287 186 339 minecraft:polished_andesite
fill 287 185 343 287 186 343 minecraft:polished_andesite
fill 287 185 345 287 186 345 minecraft:polished_andesite
fill 287 185 347 287 186 347 minecraft:polished_andesite
fill 287 185 349 287 186 349 minecraft:polished_andesite
fill 287 185 351 287 186 351 minecraft:polished_andesite
fill 287 185 353 287 186 353 minecraft:polished_andesite
fill 288 185 332 288 186 332 minecraft:polished_andesite
fill 288 185 334 288 186 334 minecraft:polished_andesite
fill 288 185 336 288 186 336 minecraft:polished_andesite
fill 288 185 338 288 186 338 minecraft:polished_andesite
fill 288 185 342 288 186 342 minecraft:polished_andesite
fill 288 185 344 288 186 344 minecraft:polished_andesite
fill 288 185 346 288 186 346 minecraft:polished_andesite
fill 288 185 348 288 186 348 minecraft:polished_andesite
fill 288 185 350 288 186 350 minecraft:polished_andesite
fill 288 185 352 288 186 352 minecraft:polished_andesite
fill 288 185 354 288 186 354 minecraft:polished_andesite
fill 288 185 356 288 186 356 minecraft:polished_andesite
fill 288 185 358 288 186 358 minecraft:polished_andesite
fill 288 185 360 288 186 360 minecraft:polished_andesite
fill 288 185 362 288 186 362 minecraft:polished_andesite
fill 289 185 331 289 186 331 minecraft:polished_andesite
fill 289 185 333 289 186 333 minecraft:polished_andesite
fill 289 185 335 289 186 335 minecraft:polished_andesite
fill 289 185 337 289 186 337 minecraft:polished_andesite
fill 289 185 339 289 186 339 minecraft:polished_andesite
fill 289 185 357 289 186 357 minecraft:polished_andesite
fill 289 185 359 289 186 359 minecraft:polished_andesite
fill 289 185 361 289 186 361 minecraft:polished_andesite
fill 289 185 363 289 186 363 minecraft:polished_andesite
fill 290 185 332 290 186 332 minecraft:polished_andesite
fill 290 185 334 290 186 334 minecraft:polished_andesite
fill 290 185 336 290 186 336 minecraft:polished_andesite
fill 290 185 338 290 186 338 minecraft:polished_andesite
fill 290 185 356 290 186 356 minecraft:polished_andesite
fill 290 185 358 290 186 358 minecraft:polished_andesite
fill 290 185 360 290 186 360 minecraft:polished_andesite
fill 290 185 362 290 186 362 minecraft:polished_andesite
fill 291 185 357 291 186 357 minecraft:polished_andesite
fill 291 185 359 291 186 359 minecraft:polished_andesite
fill 291 185 361 291 186 361 minecraft:polished_andesite
fill 291 185 363 291 186 363 minecraft:polished_andesite
fill 292 185 356 292 186 356 minecraft:polished_andesite
fill 292 185 358 292 186 358 minecraft:polished_andesite
fill 292 185 360 292 186 360 minecraft:polished_andesite
fill 292 185 362 292 186 362 minecraft:polished_andesite
fill 293 185 357 293 186 357 minecraft:polished_andesite
fill 293 185 359 293 186 359 minecraft:polished_andesite
fill 293 185 361 293 186 361 minecraft:polished_andesite
fill 293 185 363 293 186 363 minecraft:polished_andesite
fill 294 185 356 294 186 356 minecraft:polished_andesite
fill 294 185 358 294 186 358 minecraft:polished_andesite
fill 294 185 360 294 186 360 minecraft:polished_andesite
fill 294 185 362 294 186 362 minecraft:polished_andesite
setblock 294 185 363 minecraft:cobblestone
fill 295 185 357 295 186 357 minecraft:polished_andesite
fill 295 185 359 295 186 359 minecraft:polished_andesite
fill 295 185 361 295 186 361 minecraft:polished_andesite
fill 295 185 363 295 186 363 minecraft:blue_wool
fill 296 185 356 296 186 356 minecraft:polished_andesite
fill 296 185 358 296 186 358 minecraft:polished_andesite
fill 296 185 360 296 186 360 minecraft:polished_andesite
fill 296 185 362 296 186 362 minecraft:polished_andesite
fill 298 185 363 299 185 363 minecraft:cobblestone
fill 299 185 323 304 185 323 minecraft:cobblestone
fill 304 185 324 312 188 329 minecraft:polished_andesite
fill 305 185 323 310 188 323 minecraft:polished_andesite
fill 306 185 363 311 185 363 minecraft:cobblestone
fill 311 185 323 316 185 323 minecraft:cobblestone
fill 311 185 355 313 186 355 minecraft:cobblestone
fill 313 185 356 313 187 356 minecraft:cobblestone
fill 318 185 363 323 185 363 minecraft:cobblestone
fill 323 185 323 323 185 328 minecraft:cobblestone
fill 323 185 335 323 185 340 minecraft:cobblestone
fill 323 185 347 323 185 348 minecraft:cobblestone
setblock 323 185 352 minecraft:cobblestone
fill 323 185 359 323 185 362 minecraft:cobblestone
fill 282 186 328 282 191 331 minecraft:shroomlight
fill 282 186 340 282 191 343 minecraft:shroomlight
fill 282 186 344 282 193 346 minecraft:stone_bricks
fill 282 186 352 282 191 355 minecraft:shroomlight
fill 282 186 364 285 191 364 minecraft:shroomlight
setblock 283 186 331 minecraft:polished_andesite
fill 283 186 338 283 186 339 minecraft:polished_andesite
fill 283 186 342 283 186 343 minecraft:polished_andesite
fill 283 186 350 283 195 350 minecraft:polished_andesite
fill 283 186 352 283 188 352 minecraft:yellow_wool
fill 283 186 354 283 195 354 minecraft:polished_andesite
fill 289 186 322 292 191 322 minecraft:shroomlight
fill 294 186 323 294 188 323 minecraft:red_wool
fill 294 186 363 294 193 363 minecraft:polished_andesite
fill 294 186 364 297 191 364 minecraft:shroomlight
fill 296 186 363 296 188 363 minecraft:blue_wool
fill 301 186 322 304 191 322 minecraft:shroomlight
fill 304 186 323 304 188 323 minecraft:polished_andesite
fill 306 186 364 309 191 364 minecraft:shroomlight
fill 311 186 323 312 188 323 minecraft:polished_andesite
fill 312 186 354 313 187 354 minecraft:cobblestone
fill 312 186 356 312 188 356 minecraft:cobblestone
fill 313 186 322 316 191 322 minecraft:shroomlight
fill 314 186 355 314 186 356 minecraft:cobblestone
fill 318 186 364 321 191 364 minecraft:shroomlight
fill 323 186 350 323 188 350 minecraft:red_wool
fill 324 186 323 324 191 326 minecraft:shroomlight
fill 324 186 335 324 191 338 minecraft:shroomlight
fill 324 186 347 324 191 350 minecraft:shroomlight
fill 324 186 359 324 191 362 minecraft:shroomlight
setblock 283 187 331 minecraft:shroomlight
setblock 283 187 333 minecraft:shroomlight
setblock 283 187 335 minecraft:shroomlight
setblock 283 187 337 minecraft:shroomlight
fill 283 187 338 283 188 338 minecraft:polished_andesite
setblock 283 187 339 minecraft:shroomlight
fill 283 187 342 283 195 342 minecraft:polished_andesite
setblock 283 187 343 minecraft:shroomlight
setblock 283 187 345 minecraft:shroomlight
setblock 283 187 347 minecraft:shroomlight
setblock 283 187 349 minecraft:shroomlight
setblock 283 187 351 minecraft:shroomlight
setblock 283 187 353 minecraft:shroomlight
setblock 284 187 332 minecraft:shroomlight
setblock 284 187 334 minecraft:shroomlight
setblock 284 187 336 minecraft:shroomlight
setblock 284 187 338 minecraft:shroomlight
setblock 284 187 342 minecraft:shroomlight
setblock 284 187 344 minecraft:shroomlight
setblock 284 187 346 minecraft:shroomlight
setblock 284 187 348 minecraft:shroomlight
setblock 284 187 350 minecraft:shroomlight
setblock 284 187 352 minecraft:shroomlight
setblock 284 187 354 minecraft:shroomlight
setblock 285 187 331 minecraft:shroomlight
setblock 285 187 333 minecraft:shroomlight
setblock 285 187 335 minecraft:shroomlight
setblock 285 187 337 minecraft:shroomlight
setblock 285 187 339 minecraft:shroomlight
setblock 285 187 343 minecraft:shroomlight
setblock 285 187 345 minecraft:shroomlight
setblock 285 187 347 minecraft:shroomlight
setblock 285 187 349 minecraft:shroomlight
setblock 285 187 351 minecraft:shroomlight
setblock 285 187 353 minecraft:shroomlight
setblock 286 187 332 minecraft:shroomlight
setblock 286 187 334 minecraft:shroomlight
setblock 286 187 336 minecraft:shroomlight
setblock 286 187 338 minecraft:shroomlight
setblock 286 187 342 minecraft:shroomlight
setblock 286 187 344 minecraft:shroomlight
setblock 286 187 346 minecraft:shroomlight
setblock 286 187 348 minecraft:shroomlight
setblock 286 187 350 minecraft:shroomlight
setblock 286 187 352 minecraft:shroomlight
setblock 286 187 354 minecraft:shroomlight
setblock 287 187 331 minecraft:shroomlight
setblock 287 187 333 minecraft:shroomlight
setblock 287 187 335 minecraft:shroomlight
setblock 287 187 337 minecraft:shroomlight
setblock 287 187 339 minecraft:shroomlight
setblock 287 187 343 minecraft:shroomlight
setblock 287 187 345 minecraft:shroomlight
setblock 287 187 347 minecraft:shroomlight
setblock 287 187 349 minecraft:shroomlight
setblock 287 187 351 minecraft:shroomlight
setblock 287 187 353 minecraft:shroomlight
setblock 288 187 332 minecraft:shroomlight
setblock 288 187 334 minecraft:shroomlight
setblock 288 187 336 minecraft:shroomlight
setblock 288 187 338 minecraft:shroomlight
setblock 288 187 342 minecraft:shroomlight
setblock 288 187 344 minecraft:shroomlight
setblock 288 187 346 minecraft:shroomlight
setblock 288 187 348 minecraft:shroomlight
setblock 288 187 350 minecraft:shroomlight
setblock 288 187 352 minecraft:shroomlight
setblock 288 187 354 minecraft:shroomlight
setblock 288 187 356 minecraft:shroomlight
setblock 288 187 358 minecraft:shroomlight
setblock 288 187 360 minecraft:shroomlight
setblock 288 187 362 minecraft:shroomlight
setblock 289 187 331 minecraft:shroomlight
setblock 289 187 333 minecraft:shroomlight
setblock 289 187 335 minecraft:shroomlight
setblock 289 187 337 minecraft:shroomlight
setblock 289 187 339 minecraft:shroomlight
setblock 289 187 357 minecraft:shroomlight
setblock 289 187 359 minecraft:shroomlight
setblock 289 187 361 minecraft:shroomlight
setblock 289 187 363 minecraft:shroomlight
setblock 290 187 332 minecraft:shroomlight
setblock 290 187 334 minecraft:shroomlight
setblock 290 187 336 minecraft:shroomlight
setblock 290 187 338 minecraft:shroomlight
setblock 290 187 356 minecraft:shroomlight
setblock 290 187 358 minecraft:shroomlight
setblock 290 187 360 minecraft:shroomlight
setblock 290 187 362 minecraft:shroomlight
setblock 291 187 357 minecraft:shroomlight
setblock 291 187 359 minecraft:shroomlight
setblock 291 187 361 minecraft:shroomlight
setblock 291 187 363 minecraft:shroomlight
setblock 292 187 356 minecraft:shroomlight
setblock 292 187 358 minecraft:shroomlight
setblock 292 187 360 minecraft:shroomlight
setblock 292 187 362 minecraft:shroomlight
setblock 293 187 357 minecraft:shroomlight
setblock 293 187 359 minecraft:shroomlight
setblock 293 187 361 minecraft:shroomlight
setblock 293 187 363 minecraft:shroomlight
setblock 294 187 356 minecraft:shroomlight
setblock 294 187 358 minecraft:shroomlight
setblock 294 187 360 minecraft:shroomlight
setblock 294 187 362 minecraft:shroomlight
setblock 295 187 357 minecraft:shroomlight
setblock 295 187 359 minecraft:shroomlight
setblock 295 187 361 minecraft:shroomlight
setblock 295 187 363 minecraft:shroomlight
setblock 296 187 356 minecraft:shroomlight
setblock 296 187 358 minecraft:shroomlight
setblock 296 187 360 minecraft:shroomlight
setblock 296 187 362 minecraft:shroomlight
setblock 311 187 356 minecraft:cobblestone
fill 312 187 355 314 187 355 minecraft:cobblestone
setblock 314 187 354 minecraft:cobblestone
setblock 283 188 331 minecraft:polished_andesite
fill 283 188 333 283 225 333 minecraft:polished_andesite
fill 283 188 335 283 225 335 minecraft:polished_andesite
setblock 283 188 337 minecraft:polished_andesite
setblock 283 188 339 minecraft:polished_andesite
fill 283 188 343 283 189 343 minecraft:polished_andesite
fill 283 188 345 283 189 345 minecraft:polished_andesite
fill 283 188 347 283 189 347 minecraft:polished_andesite
fill 283 188 349 283 189 349 minecraft:polished_andesite
setblock 283 188 351 minecraft:yellow_wool
setblock 283 188 353 minecraft:yellow_wool
setblock 284 188 332 minecraft:polished_andesite
setblock 284 188 334 minecraft:polished_andesite
setblock 284 188 336 minecraft:polished_andesite
setblock 284 188 338 minecraft:polished_andesite
fill 284 188 342 284 189 342 minecraft:polished_andesite
fill 284 188 344 284 189 344 minecraft:polished_andesite
fill 284 188 346 284 189 346 minecraft:polished_andesite
fill 284 188 348 284 189 348 minecraft:polished_andesite
fill 284 188 350 284 189 350 minecraft:polished_andesite
fill 284 188 352 284 189 352 minecraft:polished_andesite
fill 284 188 354 284 189 354 minecraft:polished_andesite
setblock 285 188 331 minecraft:polished_andesite
setblock 285 188 333 minecraft:polished_andesite
setblock 285 188 335 minecraft:polished_andesite
setblock 285 188 337 minecraft:polished_andesite
setblock 285 188 339 minecraft:polished_andesite
fill 285 188 343 285 189 343 minecraft:polished_andesite
fill 285 188 345 285 189 345 minecraft:polished_andesite
fill 285 188 347 285 189 347 minecraft:polished_andesite
fill 285 188 349 285 189 349 minecraft:polished_andesite
fill 285 188 351 285 189 351 minecraft:polished_andesite
fill 285 188 353 285 189 353 minecraft:polished_andesite
setblock 286 188 332 minecraft:polished_andesite
setblock 286 188 334 minecraft:polished_andesite
setblock 286 188 336 minecraft:polished_andesite
setblock 286 188 338 minecraft:polished_andesite
fill 286 188 342 286 189 342 minecraft:polished_andesite
fill 286 188 344 286 189 344 minecraft:polished_andesite
fill 286 188 346 286 189 346 minecraft:polished_andesite
fill 286 188 348 286 189 348 minecraft:polished_andesite
fill 286 188 350 286 189 350 minecraft:polished_andesite
fill 286 188 352 286 189 352 minecraft:polished_andesite
fill 286 188 354 286 189 354 minecraft:polished_andesite
setblock 287 188 331 minecraft:polished_andesite
setblock 287 188 333 minecraft:polished_andesite
setblock 287 188 335 minecraft:polished_andesite
setblock 287 188 337 minecraft:polished_andesite
setblock 287 188 339 minecraft:polished_andesite
fill 287 188 343 287 189 343 minecraft:polished_andesite
fill 287 188 345 287 189 345 minecraft:polished_andesite
fill 287 188 347 287 189 347 minecraft:polished_andesite
fill 287 188 349 287 189 349 minecraft:polished_andesite
fill 287 188 351 287 189 351 minecraft:polished_andesite
fill 287 188 353 287 189 353 minecraft:polished_andesite
setblock 288 188 332 minecraft:polished_andesite
setblock 288 188 334 minecraft:polished_andesite
setblock 288 188 336 minecraft:polished_andesite
setblock 288 188 338 minecraft:polished_andesite
fill 288 188 342 288 189 342 minecraft:polished_andesite
fill 288 188 344 288 189 344 minecraft:polished_andesite
fill 288 188 346 288 189 346 minecraft:polished_andesite
fill 288 188 348 288 189 348 minecraft:polished_andesite
fill 288 188 350 288 189 350 minecraft:polished_andesite
fill 288 188 352 288 189 352 minecraft:polished_andesite
fill 288 188 354 288 189 354 minecraft:polished_andesite
fill 288 188 356 288 189 356 minecraft:polished_andesite
fill 288 188 358 288 189 358 minecraft:polished_andesite
fill 288 188 360 288 189 360 minecraft:polished_andesite
fill 288 188 362 288 189 362 minecraft:polished_andesite
setblock 289 188 331 minecraft:polished_andesite
setblock 289 188 333 minecraft:polished_andesite
setblock 289 188 335 minecraft:polished_andesite
setblock 289 188 337 minecraft:polished_andesite
setblock 289 188 339 minecraft:polished_andesite
fill 289 188 357 289 189 357 minecraft:polished_andesite
fill 289 188 359 289 189 359 minecraft:polished_andesite
fill 289 188 361 289 189 361 minecraft:polished_andesite
fill 289 188 363 289 189 363 minecraft:polished_andesite
setblock 290 188 332 minecraft:polished_andesite
setblock 290 188 334 minecraft:polished_andesite
setblock 290 188 336 minecraft:polished_andesite
setblock 290 188 338 minecraft:polished_andesite
fill 290 188 356 290 189 356 minecraft:polished_andesite
fill 290 188 358 290 189 358 minecraft:polished_andesite
fill 290 188 360 290 189 360 minecraft:polished_andesite
fill 290 188 362 290 189 362 minecraft:polished_andesite
fill 291 188 357 291 189 357 minecraft:polished_andesite
fill 291 188 359 291 189 359 minecraft:polished_andesite
fill 291 188 361 291 189 361 minecraft:polished_andesite
fill 291 188 363 291 189 363 minecraft:polished_andesite
fill 292 188 356 292 189 356 minecraft:polished_andesite
fill 292 188 358 292 189 358 minecraft:polished_andesite
fill 292 188 360 292 189 360 minecraft:polished_andesite
fill 292 188 362 292 189 362 minecraft:polished_andesite
fill 293 188 357 293 189 357 minecraft:polished_andesite
fill 293 188 359 293 189 359 minecraft:polished_andesite
fill 293 188 361 293 189 361 minecraft:polished_andesite
fill 293 188 363 293 189 363 minecraft:polished_andesite
fill 294 188 356 294 189 356 minecraft:polished_andesite
fill 294 188 358 294 189 358 minecraft:polished_andesite
fill 294 188 360 294 189 360 minecraft:polished_andesite
fill 294 188 362 294 189 362 minecraft:polished_andesite
fill 295 188 357 295 189 357 minecraft:polished_andesite
fill 295 188 359 295 189 359 minecraft:polished_andesite
fill 295 188 361 295 189 361 minecraft:polished_andesite
setblock 295 188 363 minecraft:blue_wool
fill 296 188 356 296 189 356 minecraft:polished_andesite
fill 296 188 358 296 189 358 minecraft:polished_andesite
fill 296 188 360 296 189 360 minecraft:polished_andesite
fill 296 188 362 296 189 362 minecraft:polished_andesite
fill 312 188 355 313 188 355 minecraft:cobblestone
setblock 313 188 354 minecraft:cobblestone
fill 283 189 351 283 189 353 minecraft:polished_andesite
fill 284 189 332 289 189 338 minecraft:red_wool
setblock 285 189 325 minecraft:light[level=12]
setblock 285 189 339 minecraft:light[level=12]
setblock 285 189 360 minecraft:light[level=12]
setblock 292 189 325 minecraft:light[level=12]
setblock 292 189 332 minecraft:light[level=12]
setblock 292 189 339 minecraft:light[level=12]
setblock 292 189 346 minecraft:light[level=12]
setblock 292 189 353 minecraft:light[level=12]
fill 295 189 323 295 219 323 minecraft:polished_andesite
fill 295 189 363 296 189 363 minecraft:polished_andesite
setblock 299 189 325 minecraft:light[level=12]
setblock 299 189 332 minecraft:light[level=12]
setblock 299 189 339 minecraft:light[level=12]
setblock 299 189 346 minecraft:light[level=12]
setblock 299 189 353 minecraft:light[level=12]
setblock 299 189 360 minecraft:light[level=12]
fill 305 189 324 311 189 328 minecraft:red_wool
setblock 306 189 332 minecraft:light[level=12]
setblock 306 189 339 minecraft:light[level=12]
setblock 306 189 346 minecraft:light[level=12]
setblock 306 189 353 minecraft:light[level=12]
setblock 306 189 360 minecraft:light[level=12]
fill 307 189 323 309 225 323 minecraft:polished_andesite
setblock 313 189 325 minecraft:light[level=12]
setblock 313 189 332 minecraft:light[level=12]
setblock 313 189 339 minecraft:light[level=12]
setblock 313 189 346 minecraft:light[level=12]
setblock 313 189 353 minecraft:light[level=12]
setblock 313 189 360 minecraft:light[level=12]
setblock 320 189 325 minecraft:light[level=12]
setblock 320 189 332 minecraft:light[level=12]
setblock 320 189 339 minecraft:light[level=12]
setblock 320 189 346 minecraft:light[level=12]
setblock 320 189 353 minecraft:light[level=12]
setblock 320 189 360 minecraft:light[level=12]
setblock 283 190 343 minecraft:shroomlight
setblock 283 190 345 minecraft:shroomlight
setblock 283 190 347 minecraft:shroomlight
setblock 283 190 349 minecraft:shroomlight
setblock 283 190 351 minecraft:shroomlight
fill 283 190 352 283 195 352 minecraft:polished_andesite
setblock 283 190 353 minecraft:shroomlight
setblock 284 190 342 minecraft:shroomlight
setblock 284 190 344 minecraft:shroomlight
setblock 284 190 346 minecraft:shroomlight
setblock 284 190 348 minecraft:shroomlight
setblock 284 190 350 minecraft:shroomlight
setblock 284 190 352 minecraft:shroomlight
setblock 284 190 354 minecraft:shroomlight
fill 285 190 333 288 190 337 minecraft:red_wool
setblock 285 190 343 minecraft:shroomlight
setblock 285 190 345 minecraft:shroomlight
setblock 285 190 347 minecraft:shroomlight
setblock 285 190 349 minecraft:shroomlight
setblock 285 190 351 minecraft:shroomlight
setblock 285 190 353 minecraft:shroomlight
setblock 286 190 342 minecraft:shroomlight
setblock 286 190 344 minecraft:shroomlight
setblock 286 190 346 minecraft:shroomlight
setblock 286 190 348 minecraft:shroomlight
setblock 286 190 350 minecraft:shroomlight
setblock 286 190 352 minecraft:shroomlight
setblock 286 190 354 minecraft:shroomlight
setblock 287 190 343 minecraft:shroomlight
setblock 287 190 345 minecraft:shroomlight
setblock 287 190 347 minecraft:shroomlight
setblock 287 190 349 minecraft:shroomlight
setblock 287 190 351 minecraft:shroomlight
setblock 287 190 353 minecraft:shroomlight
setblock 288 190 342 minecraft:shroomlight
setblock 288 190 344 minecraft:shroomlight
setblock 288 190 346 minecraft:shroomlight
setblock 288 190 348 minecraft:shroomlight
setblock 288 190 350 minecraft:shroomlight
setblock 288 190 352 minecraft:shroomlight
setblock 288 190 354 minecraft:shroomlight
setblock 288 190 356 minecraft:shroomlight
setblock 288 190 358 minecraft:shroomlight
setblock 288 190 360 minecraft:shroomlight
setblock 288 190 362 minecraft:shroomlight
setblock 289 190 357 minecraft:shroomlight
setblock 289 190 359 minecraft:shroomlight
setblock 289 190 361 minecraft:shroomlight
setblock 289 190 363 minecraft:shroomlight
setblock 290 190 356 minecraft:shroomlight
setblock 290 190 358 minecraft:shroomlight
setblock 290 190 360 minecraft:shroomlight
setblock 290 190 362 minecraft:shroomlight
setblock 291 190 357 minecraft:shroomlight
setblock 291 190 359 minecraft:shroomlight
setblock 291 190 361 minecraft:shroomlight
setblock 291 190 363 minecraft:shroomlight
setblock 292 190 356 minecraft:shroomlight
setblock 292 190 358 minecraft:shroomlight
setblock 292 190 360 minecraft:shroomlight
setblock 292 190 362 minecraft:shroomlight
setblock 293 190 357 minecraft:shroomlight
setblock 293 190 359 minecraft:shroomlight
setblock 293 190 361 minecraft:shroomlight
setblock 293 190 363 minecraft:shroomlight
setblock 294 190 356 minecraft:shroomlight
setblock 294 190 358 minecraft:shroomlight
setblock 294 190 360 minecraft:shroomlight
setblock 294 190 362 minecraft:shroomlight
setblock 295 190 357 minecraft:shroomlight
setblock 295 190 359 minecraft:shroomlight
setblock 295 190 361 minecraft:shroomlight
setblock 295 190 363 minecraft:shroomlight
setblock 296 190 356 minecraft:shroomlight
setblock 296 190 358 minecraft:shroomlight
setblock 296 190 360 minecraft:shroomlight
setblock 296 190 362 minecraft:shroomlight
fill 296 190 363 296 193 363 minecraft:polished_andesite
fill 306 190 325 310 190 327 minecraft:red_wool
fill 312 190 357 312 193 357 minecraft:iron_bars
fill 283 191 343 283 192 343 minecraft:polished_andesite
fill 283 191 345 283 192 345 minecraft:polished_andesite
fill 283 191 347 283 192 347 minecraft:polished_andesite
fill 283 191 349 283 192 349 minecraft:polished_andesite
fill 283 191 351 283 192 351 minecraft:polished_andesite
fill 283 191 353 283 192 353 minecraft:polished_andesite
fill 284 191 342 284 192 342 minecraft:polished_andesite
fill 284 191 344 284 192 344 minecraft:polished_andesite
fill 284 191 346 284 192 346 minecraft:polished_andesite
fill 284 191 348 284 192 348 minecraft:polished_andesite
fill 284 191 350 284 192 350 minecraft:polished_andesite
fill 284 191 352 284 192 352 minecraft:polished_andesite
fill 284 191 354 284 192 354 minecraft:polished_andesite
setblock 285 191 325 minecraft:light[level=15]
setblock 285 191 333 minecraft:light[level=15]
setblock 285 191 341 minecraft:light[level=15]
fill 285 191 343 285 192 343 minecraft:polished_andesite
fill 285 191 345 285 192 345 minecraft:polished_andesite
fill 285 191 347 285 192 347 minecraft:polished_andesite
fill 285 191 349 285 192 349 minecraft:polished_andesite
fill 285 191 351 285 192 351 minecraft:polished_andesite
fill 285 191 353 285 192 353 minecraft:polished_andesite
setblock 285 191 357 minecraft:light[level=15]
fill 286 191 334 287 191 336 minecraft:red_wool
fill 286 191 342 286 192 342 minecraft:polished_andesite
fill 286 191 344 286 192 344 minecraft:polished_andesite
fill 286 191 346 286 192 346 minecraft:polished_andesite
fill 286 191 348 286 192 348 minecraft:polished_andesite
fill 286 191 350 286 192 350 minecraft:polished_andesite
fill 286 191 352 286 192 352 minecraft:polished_andesite
fill 286 191 354 286 192 354 minecraft:polished_andesite
fill 287 191 343 287 192 343 minecraft:polished_andesite
fill 287 191 345 287 192 345 minecraft:polished_andesite
fill 287 191 347 287 192 347 minecraft:polished_andesite
fill 287 191 349 287 192 349 minecraft:polished_andesite
fill 287 191 351 287 192 351 minecraft:polished_andesite
fill 287 191 353 287 192 353 minecraft:polished_andesite
fill 288 191 342 288 192 342 minecraft:polished_andesite
fill 288 191 344 288 192 344 minecraft:polished_andesite
fill 288 191 346 288 192 346 minecraft:polished_andesite
fill 288 191 348 288 192 348 minecraft:polished_andesite
fill 288 191 350 288 192 350 minecraft:polished_andesite
fill 288 191 352 288 192 352 minecraft:polished_andesite
fill 288 191 354 288 192 354 minecraft:polished_andesite
fill 288 191 356 288 193 356 minecraft:polished_andesite
fill 288 191 358 288 193 358 minecraft:polished_andesite
fill 288 191 360 288 193 360 minecraft:polished_andesite
fill 288 191 362 288 193 362 minecraft:polished_andesite
fill 289 191 357 289 193 357 minecraft:polished_andesite
fill 289 191 359 289 193 359 minecraft:polished_andesite
fill 289 191 361 289 193 361 minecraft:polished_andesite
fill 289 191 363 289 225 363 minecraft:polished_andesite
fill 290 191 356 290 193 356 minecraft:polished_andesite
fill 290 191 358 290 193 358 minecraft:polished_andesite
fill 290 191 360 290 193 360 minecraft:polished_andesite
fill 290 191 362 290 193 362 minecraft:polished_andesite
fill 291 191 357 291 193 357 minecraft:polished_andesite
fill 291 191 359 291 193 359 minecraft:polished_andesite
fill 291 191 361 291 193 361 minecraft:polished_andesite
fill 291 191 363 291 225 363 minecraft:polished_andesite
fill 292 191 356 292 193 356 minecraft:polished_andesite
fill 292 191 358 292 193 358 minecraft:polished_andesite
fill 292 191 360 292 193 360 minecraft:polished_andesite
fill 292 191 362 292 193 362 minecraft:polished_andesite
setblock 293 191 325 minecraft:light[level=15]
setblock 293 191 333 minecraft:light[level=15]
setblock 293 191 341 minecraft:light[level=15]
setblock 293 191 349 minecraft:light[level=15]
fill 293 191 357 293 193 357 minecraft:polished_andesite
fill 293 191 359 293 193 359 minecraft:polished_andesite
fill 293 191 361 293 193 361 minecraft:polished_andesite
fill 293 191 363 293 193 363 minecraft:polished_andesite
fill 294 191 356 294 193 356 minecraft:polished_andesite
fill 294 191 358 294 193 358 minecraft:polished_andesite
fill 294 191 360 294 193 360 minecraft:polished_andesite
fill 294 191 362 294 193 362 minecraft:polished_andesite
fill 295 191 357 295 193 357 minecraft:polished_andesite
fill 295 191 359 295 193 359 minecraft:polished_andesite
fill 295 191 361 295 193 361 minecraft:polished_andesite
fill 295 191 363 295 193 363 minecraft:polished_andesite
fill 296 191 356 296 193 356 minecraft:polished_andesite
fill 296 191 358 296 193 358 minecraft:polished_andesite
fill 296 191 360 296 193 360 minecraft:polished_andesite
fill 296 191 362 296 193 362 minecraft:polished_andesite
setblock 301 191 325 minecraft:light[level=15]
setblock 301 191 333 minecraft:light[level=15]
setblock 301 191 349 minecraft:light[level=15]
setblock 301 191 357 minecraft:light[level=15]
fill 307 191 326 309 191 326 minecraft:red_wool
setblock 309 191 325 minecraft:light[level=15]
setblock 309 191 333 minecraft:light[level=15]
setblock 309 191 341 minecraft:light[level=15]
setblock 309 191 349 minecraft:light[level=15]
setblock 309 191 357 minecraft:light[level=15]
setblock 317 191 325 minecraft:light[level=15]
setblock 317 191 333 minecraft:light[level=15]
setblock 317 191 341 minecraft:light[level=15]
setblock 317 191 349 minecraft:light[level=15]
setblock 317 191 357 minecraft:light[level=15]
fill 318 191 350 318 194 350 minecraft:iron_bars
fill 282 192 328 282 197 328 minecraft:stone_bricks
fill 282 192 329 282 192 330 minecraft:shroomlight
fill 282 192 331 282 196 331 minecraft:stone_bricks
fill 282 192 340 282 196 340 minecraft:stone_bricks
fill 282 192 341 282 192 342 minecraft:shroomlight
fill 282 192 343 282 196 343 minecraft:stone_bricks
fill 282 192 352 282 196 352 minecraft:stone_bricks
fill 282 192 353 282 192 354 minecraft:shroomlight
fill 282 192 355 282 197 355 minecraft:stone_bricks
fill 282 192 364 282 193 364 minecraft:stone_bricks
fill 283 192 364 284 192 364 minecraft:shroomlight
fill 285 192 364 285 197 364 minecraft:stone_bricks
fill 286 192 335 287 192 335 minecraft:red_wool
setblock 289 192 322 minecraft:stone_bricks
fill 290 192 322 291 192 322 minecraft:shroomlight
fill 292 192 322 292 194 322 minecraft:stone_bricks
fill 294 192 364 294 196 364 minecraft:stone_bricks
fill 295 192 364 296 192 364 minecraft:shroomlight
fill 297 192 364 297 196 364 minecraft:stone_bricks
fill 301 192 322 301 196 322 minecraft:stone_bricks
fill 302 192 322 303 192 322 minecraft:shroomlight
fill 304 192 322 304 196 322 minecraft:stone_bricks
fill 306 192 364 306 197 364 minecraft:stone_bricks
fill 307 192 364 308 192 364 minecraft:shroomlight
fill 308 192 325 308 192 327 minecraft:red_wool
fill 309 192 364 309 196 364 minecraft:stone_bricks
fill 313 192 322 313 196 322 minecraft:stone_bricks
fill 314 192 322 315 192 322 minecraft:shroomlight
fill 316 192 322 316 196 322 minecraft:stone_bricks
fill 318 192 364 318 196 364 minecraft:stone_bricks
fill 319 192 364 320 192 364 minecraft:shroomlight
setblock 321 192 364 minecraft:stone_bricks
setblock 324 192 323 minecraft:stone_bricks
fill 324 192 324 324 192 325 minecraft:shroomlight
fill 324 192 326 324 196 326 minecraft:stone_bricks
fill 324 192 335 324 197 335 minecraft:stone_bricks
fill 324 192 336 324 192 337 minecraft:shroomlight
fill 324 192 338 324 196 338 minecraft:stone_bricks
fill 324 192 347 324 194 347 minecraft:stone_bricks
fill 324 192 348 324 192 349 minecraft:shroomlight
fill 324 192 350 324 196 350 minecraft:stone_bricks
fill 324 192 359 324 194 359 minecraft:stone_bricks
fill 324 192 360 324 192 361 minecraft:shroomlight
fill 324 192 362 324 196 362 minecraft:stone_bricks
fill 282 193 322 283 193 322 minecraft:mossy_stone_bricks
fill 282 193 326 282 196 326 minecraft:stone_bricks
fill 282 193 327 282 194 327 minecraft:mossy_stone_bricks
fill 282 193 329 282 196 329 minecraft:stone_bricks
setblock 282 193 330 minecraft:mossy_stone_bricks
fill 282 193 341 282 196 342 minecraft:stone_bricks
fill 282 193 353 282 193 354 minecraft:stone_bricks
setblock 282 193 360 minecraft:mossy_stone_bricks
fill 282 193 361 282 196 363 minecraft:stone_bricks
setblock 283 193 343 minecraft:shroomlight
setblock 283 193 345 minecraft:shroomlight
setblock 283 193 347 minecraft:shroomlight
setblock 283 193 349 minecraft:shroomlight
setblock 283 193 351 minecraft:shroomlight
setblock 283 193 353 minecraft:shroomlight
fill 283 193 364 284 194 364 minecraft:stone_bricks
fill 284 193 322 287 194 322 minecraft:stone_bricks
setblock 284 193 342 minecraft:shroomlight
setblock 284 193 344 minecraft:shroomlight
setblock 284 193 346 minecraft:shroomlight
setblock 284 193 348 minecraft:shroomlight
setblock 284 193 350 minecraft:shroomlight
setblock 284 193 352 minecraft:shroomlight
setblock 284 193 354 minecraft:shroomlight
setblock 285 193 343 minecraft:shroomlight
setblock 285 193 345 minecraft:shroomlight
setblock 285 193 347 minecraft:shroomlight
setblock 285 193 349 minecraft:shroomlight
setblock 285 193 351 minecraft:shroomlight
setblock 285 193 353 minecraft:shroomlight
setblock 286 193 342 minecraft:shroomlight
setblock 286 193 344 minecraft:shroomlight
setblock 286 193 346 minecraft:shroomlight
setblock 286 193 348 minecraft:shroomlight
setblock 286 193 350 minecraft:shroomlight
setblock 286 193 352 minecraft:shroomlight
setblock 286 193 354 minecraft:shroomlight
fill 286 193 364 287 193 364 minecraft:stone_bricks
setblock 287 193 343 minecraft:shroomlight
setblock 287 193 345 minecraft:shroomlight
setblock 287 193 347 minecraft:shroomlight
setblock 287 193 349 minecraft:shroomlight
setblock 287 193 351 minecraft:shroomlight
setblock 287 193 353 minecraft:shroomlight
fill 288 193 322 289 193 322 minecraft:mossy_stone_bricks
setblock 288 193 342 minecraft:shroomlight
setblock 288 193 344 minecraft:shroomlight
setblock 288 193 346 minecraft:shroomlight
setblock 288 193 348 minecraft:shroomlight
setblock 288 193 350 minecraft:shroomlight
setblock 288 193 352 minecraft:shroomlight
setblock 288 193 354 minecraft:shroomlight
setblock 288 193 364 minecraft:mossy_stone_bricks
fill 290 193 322 291 196 322 minecraft:stone_bricks
fill 290 193 364 291 196 364 minecraft:stone_bricks
setblock 292 193 364 minecraft:mossy_stone_bricks
setblock 293 193 322 minecraft:mossy_stone_bricks
fill 293 193 364 293 196 364 minecraft:stone_bricks
fill 294 193 322 299 193 322 minecraft:stone_bricks
fill 295 193 364 296 196 364 minecraft:stone_bricks
fill 302 193 322 303 196 322 minecraft:stone_bricks
setblock 305 193 322 minecraft:mossy_stone_bricks
fill 306 193 322 308 194 322 minecraft:stone_bricks
fill 307 193 364 308 196 364 minecraft:stone_bricks
fill 310 193 364 311 196 364 minecraft:stone_bricks
fill 312 193 364 312 194 364 minecraft:mossy_stone_bricks
fill 313 193 364 315 196 364 minecraft:stone_bricks
fill 314 193 322 315 197 322 minecraft:stone_bricks
fill 319 193 322 319 196 322 minecraft:stone_bricks
fill 319 193 364 320 194 364 minecraft:stone_bricks
setblock 320 193 322 minecraft:mossy_stone_bricks
fill 321 193 322 322 196 322 minecraft:stone_bricks
fill 321 193 360 321 194 362 minecraft:iron_bars
setblock 321 193 364 minecraft:mossy_stone_bricks
fill 324 193 323 324 194 323 minecraft:mossy_stone_bricks
setblock 324 193 324 minecraft:stone_bricks
setblock 324 193 325 minecraft:mossy_stone_bricks
fill 324 193 336 324 196 337 minecraft:stone_bricks
fill 324 193 339 324 197 339 minecraft:stone_bricks
setblock 324 193 340 minecraft:mossy_stone_bricks
fill 324 193 341 324 194 346 minecraft:stone_bricks
fill 324 193 348 324 193 349 minecraft:stone_bricks
setblock 324 193 355 minecraft:mossy_stone_bricks
fill 324 193 356 324 196 358 minecraft:stone_bricks
fill 324 193 360 324 196 361 minecraft:stone_bricks
fill 282 194 322 282 195 322 minecraft:mossy_stone_bricks
setblock 282 194 330 minecraft:stone_bricks
fill 282 194 332 282 196 334 minecraft:stone_bricks
setblock 282 194 335 minecraft:mossy_stone_bricks
fill 282 194 336 282 196 338 minecraft:stone_bricks
fill 282 194 344 282 197 344 minecraft:stone_bricks
setblock 282 194 345 minecraft:mossy_stone_bricks
fill 282 194 346 282 196 346 minecraft:stone_bricks
fill 282 194 353 282 196 353 minecraft:stone_bricks
setblock 282 194 354 minecraft:mossy_stone_bricks
fill 282 194 360 282 196 360 minecraft:stone_bricks
fill 282 194 364 282 195 364 minecraft:mossy_stone_bricks
setblock 283 194 322 minecraft:stone_bricks
fill 283 194 343 283 195 343 minecraft:polished_andesite
fill 283 194 345 283 225 345 minecraft:polished_andesite
fill 283 194 347 283 225 347 minecraft:polished_andesite
fill 283 194 349 283 195 349 minecraft:polished_andesite
fill 283 194 351 283 195 351 minecraft:polished_andesite
fill 283 194 353 283 195 353 minecraft:polished_andesite
fill 284 194 342 284 195 342 minecraft:polished_andesite
fill 284 194 344 284 195 344 minecraft:polished_andesite
fill 284 194 346 284 195 346 minecraft:polished_andesite
fill 284 194 348 284 195 348 minecraft:polished_andesite
fill 284 194 350 284 195 350 minecraft:polished_andesite
fill 284 194 352 284 195 352 minecraft:polished_andesite
fill 284 194 354 284 195 354 minecraft:polished_andesite
fill 285 194 343 285 195 343 minecraft:polished_andesite
fill 285 194 345 285 195 345 minecraft:polished_andesite
fill 285 194 347 285 195 347 minecraft:polished_andesite
fill 285 194 349 285 195 349 minecraft:polished_andesite
fill 285 194 351 285 195 351 minecraft:polished_andesite
fill 285 194 353 285 195 353 minecraft:polished_andesite
fill 286 194 342 286 195 342 minecraft:polished_andesite
fill 286 194 344 286 195 344 minecraft:polished_andesite
fill 286 194 346 286 195 346 minecraft:polished_andesite
fill 286 194 348 286 195 348 minecraft:polished_andesite
fill 286 194 350 286 195 350 minecraft:polished_andesite
fill 286 194 352 286 195 352 minecraft:polished_andesite
fill 286 194 354 286 195 354 minecraft:polished_andesite
fill 286 194 364 286 196 364 minecraft:stone_bricks
fill 287 194 343 287 195 343 minecraft:polished_andesite
fill 287 194 345 287 195 345 minecraft:polished_andesite
fill 287 194 347 287 195 347 minecraft:polished_andesite
fill 287 194 349 287 195 349 minecraft:polished_andesite
fill 287 194 351 287 195 351 minecraft:polished_andesite
fill 287 194 353 287 195 353 minecraft:polished_andesite
setblock 287 194 364 minecraft:mossy_stone_bricks
fill 288 194 322 289 196 322 minecraft:stone_bricks
fill 288 194 342 288 195 342 minecraft:polished_andesite
fill 288 194 344 288 195 344 minecraft:polished_andesite
fill 288 194 346 288 195 346 minecraft:polished_andesite
fill 288 194 348 288 195 348 minecraft:polished_andesite
fill 288 194 350 288 195 350 minecraft:polished_andesite
fill 288 194 352 288 195 352 minecraft:polished_andesite
fill 288 194 354 288 195 354 minecraft:polished_andesite
fill 288 194 364 288 197 364 minecraft:stone_bricks
fill 289 194 357 295 194 362 minecraft:red_wool
fill 292 194 364 292 196 364 minecraft:stone_bricks
fill 293 194 322 295 196 322 minecraft:stone_bricks
setblock 296 194 322 minecraft:mossy_stone_bricks
fill 297 194 322 299 196 322 minecraft:stone_bricks
setblock 298 194 364 minecraft:mossy_stone_bricks
fill 299 194 364 299 196 364 minecraft:stone_bricks
setblock 305 194 322 minecraft:stone_bricks
fill 308 194 357 316 194 362 minecraft:cobblestone
fill 310 194 322 310 195 322 minecraft:mossy_stone_bricks
fill 320 194 322 320 197 322 minecraft:stone_bricks
fill 321 194 364 321 196 364 minecraft:stone_bricks
setblock 324 194 322 minecraft:mossy_stone_bricks
setblock 324 194 324 minecraft:mossy_stone_bricks
setblock 324 194 325 minecraft:stone_bricks
setblock 324 194 328 minecraft:mossy_stone_bricks
fill 324 194 329 324 196 330 minecraft:stone_bricks
fill 324 194 340 324 196 340 minecraft:stone_bricks
setblock 324 194 348 minecraft:mossy_stone_bricks
fill 324 194 349 324 197 349 minecraft:stone_bricks
setblock 324 194 355 minecraft:stone_bricks
fill 324 194 363 324 196 363 minecraft:stone_bricks
setblock 324 194 364 minecraft:mossy_stone_bricks
fill 282 195 327 282 196 327 minecraft:stone_bricks
setblock 282 195 330 minecraft:mossy_stone_bricks
fill 282 195 335 282 196 335 minecraft:stone_bricks
fill 282 195 345 282 196 345 minecraft:stone_bricks
fill 282 195 348 282 196 349 minecraft:stone_bricks
setblock 282 195 350 minecraft:mossy_stone_bricks
fill 282 195 351 282 196 351 minecraft:stone_bricks
fill 282 195 354 282 196 354 minecraft:stone_bricks
setblock 283 195 322 minecraft:mossy_stone_bricks
setblock 283 195 364 minecraft:mossy_stone_bricks
fill 284 195 322 284 196 322 minecraft:stone_bricks
fill 284 195 364 284 196 364 minecraft:stone_bricks
fill 285 195 322 286 195 322 minecraft:mossy_stone_bricks
setblock 285 195 325 minecraft:light[level=12]
setblock 285 195 332 minecraft:light[level=12]
setblock 285 195 339 minecraft:light[level=12]
setblock 285 195 360 minecraft:light[level=12]
fill 287 195 322 287 196 322 minecraft:stone_bricks
fill 287 195 364 287 196 364 minecraft:stone_bricks
fill 290 195 358 294 195 361 minecraft:red_wool
setblock 292 195 322 minecraft:mossy_stone_bricks
setblock 292 195 325 minecraft:light[level=12]
setblock 292 195 332 minecraft:light[level=12]
setblock 292 195 339 minecraft:light[level=12]
setblock 292 195 346 minecraft:light[level=12]
setblock 292 195 353 minecraft:light[level=12]
fill 296 195 322 296 196 322 minecraft:stone_bricks
fill 298 195 364 298 196 364 minecraft:stone_bricks
setblock 299 195 325 minecraft:light[level=12]
setblock 299 195 332 minecraft:light[level=12]
setblock 299 195 339 minecraft:light[level=12]
setblock 299 195 346 minecraft:light[level=12]
setblock 299 195 353 minecraft:light[level=12]
setblock 299 195 360 minecraft:light[level=12]
fill 300 195 364 300 196 364 minecraft:stone_bricks
setblock 301 195 364 minecraft:mossy_stone_bricks
fill 302 195 364 302 196 364 minecraft:stone_bricks
setblock 305 195 322 minecraft:mossy_stone_bricks
fill 306 195 322 307 196 322 minecraft:stone_bricks
setblock 306 195 325 minecraft:light[level=12]
setblock 306 195 332 minecraft:light[level=12]
setblock 306 195 339 minecraft:light[level=12]
setblock 306 195 346 minecraft:light[level=12]
setblock 306 195 353 minecraft:light[level=12]
setblock 306 195 360 minecraft:light[level=12]
setblock 308 195 322 minecraft:mossy_stone_bricks
fill 308 195 357 316 195 362 minecraft:polished_andesite
fill 312 195 364 312 196 364 minecraft:stone_bricks
setblock 313 195 325 minecraft:light[level=12]
setblock 313 195 332 minecraft:light[level=12]
setblock 313 195 339 minecraft:light[level=12]
setblock 313 195 346 minecraft:light[level=12]
setblock 313 195 353 minecraft:light[level=12]
fill 318 195 346 322 195 354 minecraft:cobblestone
setblock 319 195 364 minecraft:mossy_stone_bricks
setblock 320 195 325 minecraft:light[level=12]
setblock 320 195 332 minecraft:light[level=12]
setblock 320 195 339 minecraft:light[level=12]
setblock 320 195 360 minecraft:light[level=12]
fill 320 195 364 320 196 364 minecraft:stone_bricks
fill 324 195 322 324 196 324 minecraft:stone_bricks
setblock 324 195 325 minecraft:mossy_stone_bricks
fill 324 195 328 324 196 328 minecraft:stone_bricks
fill 324 195 341 324 196 343 minecraft:stone_bricks
setblock 324 195 344 minecraft:mossy_stone_bricks
fill 324 195 345 324 196 346 minecraft:stone_bricks
setblock 324 195 347 minecraft:mossy_stone_bricks
fill 324 195 348 324 197 348 minecraft:stone_bricks
setblock 324 195 355 minecraft:mossy_stone_bricks
setblock 324 195 359 minecraft:mossy_stone_bricks
fill 324 195 364 324 196 364 minecraft:stone_bricks
fill 282 196 322 283 196 322 minecraft:stone_bricks
setblock 282 196 330 minecraft:stone_bricks
setblock 282 196 350 minecraft:stone_bricks
fill 282 196 364 283 196 364 minecraft:stone_bricks
fill 284 196 343 287 196 353 minecraft:red_wool
fill 285 196 322 286 196 322 minecraft:stone_bricks
fill 291 196 359 293 196 360 minecraft:red_wool
setblock 292 196 322 minecraft:stone_bricks
setblock 301 196 364 minecraft:stone_bricks
setblock 305 196 322 minecraft:stone_bricks
setblock 308 196 322 minecraft:stone_bricks
fill 308 196 357 316 196 357 minecraft:red_wool
setblock 310 196 322 minecraft:stone_bricks
fill 311 196 363 313 199 363 minecraft:shroomlight
fill 314 196 363 315 209 363 minecraft:polished_andesite
fill 318 196 346 322 196 354 minecraft:polished_andesite
setblock 319 196 364 minecraft:stone_bricks
setblock 324 196 325 minecraft:stone_bricks
setblock 324 196 344 minecraft:stone_bricks
fill 324 196 347 324 197 347 minecraft:stone_bricks
setblock 324 196 355 minecraft:stone_bricks
setblock 324 196 359 minecraft:stone_bricks
fill 282 197 322 313 197 322 minecraft:mossy_stone_bricks
setblock 282 197 323 minecraft:stone_bricks
fill 282 197 324 282 250 327 minecraft:mossy_stone_bricks
fill 282 197 329 282 198 333 minecraft:mossy_stone_bricks
fill 282 197 334 282 198 334 minecraft:stone_bricks
fill 282 197 335 282 197 343 minecraft:mossy_stone_bricks
fill 282 197 345 282 205 354 minecraft:mossy_stone_bricks
fill 282 197 356 282 197 364 minecraft:mossy_stone_bricks
fill 283 197 364 284 198 364 minecraft:mossy_stone_bricks
fill 285 197 344 286 197 352 minecraft:red_wool
fill 286 197 364 287 252 364 minecraft:mossy_stone_bricks
fill 289 197 364 303 197 364 minecraft:mossy_stone_bricks
fill 292 197 359 292 197 360 minecraft:red_wool
fill 305 197 364 305 252 364 minecraft:mossy_stone_bricks
fill 307 197 364 324 197 364 minecraft:mossy_stone_bricks
setblock 308 197 357 minecraft:polished_andesite
setblock 312 197 357 minecraft:polished_andesite
fill 316 197 322 319 205 322 minecraft:mossy_stone_bricks
setblock 316 197 357 minecraft:polished_andesite
fill 318 197 346 318 197 354 minecraft:red_wool
fill 321 197 322 321 252 322 minecraft:mossy_stone_bricks
setblock 322 197 322 minecraft:stone_bricks
fill 323 197 322 324 252 322 minecraft:mossy_stone_bricks
fill 323 197 349 323 200 351 minecraft:shroomlight
fill 324 197 323 324 197 334 minecraft:mossy_stone_bricks
fill 324 197 336 324 198 338 minecraft:mossy_stone_bricks
fill 324 197 340 324 197 346 minecraft:mossy_stone_bricks
fill 324 197 350 324 205 350 minecraft:mossy_stone_bricks
fill 324 197 352 324 197 363 minecraft:mossy_stone_bricks
fill 282 198 322 282 252 323 minecraft:mossy_stone_bricks
fill 282 198 328 282 205 328 minecraft:mossy_stone_bricks
fill 282 198 335 282 205 341 minecraft:mossy_stone_bricks
setblock 282 198 342 minecraft:stone_bricks
fill 282 198 343 282 205 344 minecraft:mossy_stone_bricks
fill 282 198 355 282 205 360 minecraft:mossy_stone_bricks
setblock 282 198 361 minecraft:stone_bricks
fill 282 198 362 282 252 363 minecraft:mossy_stone_bricks
setblock 282 198 364 minecraft:stone_bricks
fill 283 198 322 286 252 322 minecraft:mossy_stone_bricks
fill 285 198 345 286 198 351 minecraft:red_wool
fill 285 198 364 285 205 364 minecraft:mossy_stone_bricks
fill 287 198 322 287 199 322 minecraft:stone_bricks
fill 288 198 322 294 198 322 minecraft:mossy_stone_bricks
fill 288 198 364 290 198 364 minecraft:mossy_stone_bricks
setblock 291 198 364 minecraft:stone_bricks
fill 292 198 364 300 198 364 minecraft:mossy_stone_bricks
fill 294 198 323 294 199 323 minecraft:polished_andesite
fill 294 198 362 296 199 363 minecraft:polished_andesite
setblock 295 198 322 minecraft:stone_bricks
fill 296 198 322 296 252 322 minecraft:mossy_stone_bricks
fill 297 198 322 297 199 322 minecraft:stone_bricks
fill 298 198 322 305 198 322 minecraft:mossy_stone_bricks
fill 301 198 364 303 198 364 minecraft:stone_bricks
fill 304 198 364 304 248 364 minecraft:mossy_stone_bricks
setblock 306 198 322 minecraft:stone_bricks
fill 306 198 364 312 198 364 minecraft:mossy_stone_bricks
fill 307 198 322 310 198 322 minecraft:mossy_stone_bricks
setblock 311 198 322 minecraft:stone_bricks
fill 312 198 322 315 205 322 minecraft:mossy_stone_bricks
setblock 313 198 364 minecraft:stone_bricks
fill 314 198 364 323 198 364 minecraft:mossy_stone_bricks
setblock 318 198 346 minecraft:polished_andesite
setblock 318 198 350 minecraft:polished_andesite
setblock 318 198 354 minecraft:polished_andesite
fill 320 198 322 320 252 322 minecraft:mossy_stone_bricks
fill 320 198 324 322 199 324 minecraft:iron_bars
fill 322 198 322 322 252 322 minecraft:mossy_stone_bricks
fill 324 198 323 324 198 333 minecraft:mossy_stone_bricks
setblock 324 198 334 minecraft:stone_bricks
fill 324 198 335 324 205 335 minecraft:mossy_stone_bricks
fill 324 198 339 324 198 344 minecraft:mossy_stone_bricks
setblock 324 198 345 minecraft:stone_bricks
fill 324 198 346 324 205 349 minecraft:mossy_stone_bricks
fill 324 198 351 324 198 357 minecraft:mossy_stone_bricks
fill 324 198 358 324 198 359 minecraft:stone_bricks
fill 324 198 360 324 205 362 minecraft:mossy_stone_bricks
fill 324 198 363 324 198 364 minecraft:stone_bricks
fill 282 199 329 282 205 332 minecraft:mossy_stone_bricks
setblock 282 199 333 minecraft:stone_bricks
fill 282 199 334 282 250 334 minecraft:mossy_stone_bricks
fill 282 199 342 282 205 342 minecraft:mossy_stone_bricks
fill 282 199 361 282 252 361 minecraft:mossy_stone_bricks
fill 282 199 364 282 205 364 minecraft:mossy_stone_bricks
setblock 283 199 364 minecraft:stone_bricks
fill 284 199 346 287 199 350 minecraft:red_wool
fill 284 199 364 284 205 364 minecraft:mossy_stone_bricks
setblock 285 199 325 minecraft:light[level=15]
setblock 285 199 333 minecraft:light[level=15]
setblock 285 199 341 minecraft:light[level=15]
setblock 285 199 357 minecraft:light[level=15]
fill 288 199 322 291 205 322 minecraft:mossy_stone_bricks
fill 288 199 364 288 248 364 minecraft:mossy_stone_bricks
fill 289 199 364 290 199 364 minecraft:stone_bricks
fill 291 199 364 295 205 364 minecraft:mossy_stone_bricks
setblock 292 199 322 minecraft:stone_bricks
fill 293 199 322 295 252 322 minecraft:mossy_stone_bricks
setblock 293 199 325 minecraft:light[level=15]
setblock 293 199 333 minecraft:light[level=15]
setblock 293 199 341 minecraft:light[level=15]
setblock 293 199 349 minecraft:light[level=15]
setblock 293 199 357 minecraft:light[level=15]
fill 294 199 324 296 205 324 minecraft:polished_andesite
fill 294 199 361 296 200 361 minecraft:polished_andesite
fill 295 199 325 295 202 325 minecraft:polished_andesite
fill 295 199 360 295 202 360 minecraft:polished_andesite
setblock 296 199 364 minecraft:stone_bricks
fill 297 199 364 297 205 364 minecraft:mossy_stone_bricks
fill 298 199 322 299 252 322 minecraft:mossy_stone_bricks
setblock 298 199 364 minecraft:stone_bricks
fill 299 199 364 303 248 364 minecraft:mossy_stone_bricks
setblock 300 199 322 minecraft:stone_bricks
fill 301 199 322 302 205 322 minecraft:mossy_stone_bricks
setblock 301 199 325 minecraft:light[level=15]
setblock 301 199 333 minecraft:light[level=15]
setblock 301 199 349 minecraft:light[level=15]
setblock 301 199 357 minecraft:light[level=15]
setblock 303 199 322 minecraft:stone_bricks
fill 304 199 322 307 205 322 minecraft:mossy_stone_bricks
fill 306 199 364 306 205 364 minecraft:mossy_stone_bricks
setblock 307 199 364 minecraft:stone_bricks
setblock 308 199 322 minecraft:stone_bricks
fill 308 199 364 315 205 364 minecraft:mossy_stone_bricks
fill 309 199 322 311 250 322 minecraft:mossy_stone_bricks
setblock 309 199 325 minecraft:light[level=15]
setblock 309 199 333 minecraft:light[level=15]
setblock 309 199 341 minecraft:light[level=15]
setblock 309 199 349 minecraft:light[level=15]
setblock 309 199 357 minecraft:light[level=15]
setblock 316 199 364 minecraft:stone_bricks
setblock 317 199 325 minecraft:light[level=15]
setblock 317 199 333 minecraft:light[level=15]
setblock 317 199 341 minecraft:light[level=15]
setblock 317 199 349 minecraft:light[level=15]
setblock 317 199 357 minecraft:light[level=15]
fill 317 199 364 324 205 364 minecraft:mossy_stone_bricks
fill 324 199 323 324 205 327 minecraft:mossy_stone_bricks
setblock 324 199 328 minecraft:stone_bricks
fill 324 199 329 324 248 334 minecraft:mossy_stone_bricks
fill 324 199 336 324 205 337 minecraft:mossy_stone_bricks
setblock 324 199 338 minecraft:stone_bricks
fill 324 199 339 324 248 341 minecraft:mossy_stone_bricks
fill 324 199 342 324 199 343 minecraft:stone_bricks
fill 324 199 344 324 253 345 minecraft:mossy_stone_bricks
setblock 324 199 351 minecraft:stone_bricks
fill 324 199 352 324 252 353 minecraft:mossy_stone_bricks
setblock 324 199 354 minecraft:stone_bricks
fill 324 199 355 324 205 359 minecraft:mossy_stone_bricks
fill 324 199 363 324 252 363 minecraft:mossy_stone_bricks
fill 282 200 333 282 250 333 minecraft:mossy_stone_bricks
fill 283 200 364 283 205 364 minecraft:mossy_stone_bricks
fill 284 200 332 284 205 334 minecraft:polished_andesite
fill 284 200 344 284 205 346 minecraft:polished_andesite
fill 284 200 356 284 205 358 minecraft:polished_andesite
fill 287 200 322 287 252 322 minecraft:mossy_stone_bricks
fill 289 200 364 290 248 364 minecraft:mossy_stone_bricks
fill 290 200 362 292 205 362 minecraft:polished_andesite
fill 292 200 322 292 205 322 minecraft:mossy_stone_bricks
fill 294 200 325 294 201 325 minecraft:polished_andesite
fill 294 200 360 294 201 360 minecraft:polished_andesite
fill 295 200 326 295 202 326 minecraft:polished_andesite
fill 295 200 359 295 202 359 minecraft:polished_andesite
setblock 295 200 362 minecraft:polished_andesite
setblock 295 200 363 minecraft:red_wool
fill 296 200 325 296 201 325 minecraft:polished_andesite
fill 296 200 360 296 201 360 minecraft:polished_andesite
fill 296 200 364 296 205 364 minecraft:mossy_stone_bricks
fill 297 200 322 297 252 322 minecraft:mossy_stone_bricks
fill 298 200 364 298 250 364 minecraft:mossy_stone_bricks
fill 300 200 322 300 252 322 minecraft:mossy_stone_bricks
fill 302 200 362 304 205 362 minecraft:polished_andesite
fill 303 200 322 303 205 322 minecraft:mossy_stone_bricks
fill 306 200 324 308 205 324 minecraft:polished_andesite
fill 307 200 364 307 205 364 minecraft:mossy_stone_bricks
fill 308 200 322 308 252 322 minecraft:mossy_stone_bricks
fill 313 200 363 313 209 363 minecraft:polished_andesite
fill 314 200 362 316 205 362 minecraft:polished_andesite
fill 316 200 364 316 252 364 minecraft:mossy_stone_bricks
fill 318 200 324 320 205 324 minecraft:polished_andesite
fill 322 200 332 322 205 334 minecraft:polished_andesite
fill 322 200 344 322 205 346 minecraft:polished_andesite
fill 322 200 356 322 205 358 minecraft:polished_andesite
fill 324 200 328 324 252 328 minecraft:mossy_stone_bricks
fill 324 200 338 324 205 338 minecraft:mossy_stone_bricks
fill 324 200 342 324 252 343 minecraft:mossy_stone_bricks
fill 324 200 351 324 248 351 minecraft:mossy_stone_bricks
fill 324 200 354 324 252 354 minecraft:mossy_stone_bricks
fill 284 201 355 284 209 355 minecraft:red_wool
fill 284 201 359 284 209 359 minecraft:red_wool
setblock 285 201 325 minecraft:light[level=12]
setblock 285 201 332 minecraft:light[level=12]
setblock 285 201 339 minecraft:light[level=12]
setblock 285 201 346 minecraft:light[level=12]
setblock 285 201 353 minecraft:light[level=12]
setblock 285 201 360 minecraft:light[level=12]
setblock 292 201 325 minecraft:light[level=12]
setblock 292 201 332 minecraft:light[level=12]
setblock 292 201 339 minecraft:light[level=12]
setblock 292 201 346 minecraft:light[level=12]
setblock 292 201 353 minecraft:light[level=12]
setblock 292 201 360 minecraft:light[level=12]
fill 294 201 326 294 202 327 minecraft:polished_andesite
fill 294 201 358 294 202 359 minecraft:polished_andesite
fill 295 201 327 296 202 327 minecraft:polished_andesite
fill 295 201 358 296 202 358 minecraft:polished_andesite
setblock 295 201 361 minecraft:polished_andesite
setblock 295 201 362 minecraft:red_wool
fill 296 201 326 296 202 326 minecraft:polished_andesite
fill 296 201 359 296 202 359 minecraft:polished_andesite
setblock 299 201 325 minecraft:light[level=12]
setblock 299 201 332 minecraft:light[level=12]
setblock 299 201 339 minecraft:light[level=12]
setblock 299 201 346 minecraft:light[level=12]
setblock 299 201 353 minecraft:light[level=12]
fill 299 201 360 299 202 362 minecraft:iron_bars
setblock 306 201 325 minecraft:light[level=12]
setblock 306 201 332 minecraft:light[level=12]
setblock 306 201 339 minecraft:light[level=12]
setblock 306 201 346 minecraft:light[level=12]
setblock 306 201 353 minecraft:light[level=12]
setblock 306 201 360 minecraft:light[level=12]
setblock 313 201 325 minecraft:light[level=12]
setblock 313 201 332 minecraft:light[level=12]
setblock 313 201 339 minecraft:light[level=12]
setblock 313 201 346 minecraft:light[level=12]
setblock 313 201 353 minecraft:light[level=12]
setblock 313 201 360 minecraft:light[level=12]
setblock 320 201 325 minecraft:light[level=12]
setblock 320 201 332 minecraft:light[level=12]
setblock 320 201 339 minecraft:light[level=12]
setblock 320 201 346 minecraft:light[level=12]
setblock 320 201 353 minecraft:light[level=12]
setblock 320 201 360 minecraft:light[level=12]
fill 294 202 328 296 203 328 minecraft:polished_andesite
fill 294 202 357 296 203 357 minecraft:polished_andesite
fill 295 202 329 295 204 329 minecraft:polished_andesite
fill 295 202 356 295 204 356 minecraft:polished_andesite
setblock 295 202 361 minecraft:red_wool
fill 294 203 329 294 204 329 minecraft:polished_andesite
fill 294 203 356 294 204 356 minecraft:polished_andesite
setblock 295 203 326 minecraft:red_wool
setblock 295 203 327 minecraft:polished_andesite
fill 295 203 330 295 205 330 minecraft:polished_andesite
fill 295 203 355 295 205 355 minecraft:polished_andesite
setblock 295 203 358 minecraft:polished_andesite
setblock 295 203 359 minecraft:red_wool
fill 296 203 329 296 204 329 minecraft:polished_andesite
fill 296 203 356 296 204 356 minecraft:polished_andesite
fill 298 203 329 299 205 329 minecraft:cobblestone
fill 299 203 330 299 205 330 minecraft:cobblestone
fill 294 204 330 294 204 331 minecraft:polished_andesite
fill 294 204 354 294 204 355 minecraft:polished_andesite
fill 295 204 327 295 204 328 minecraft:red_wool
fill 295 204 331 295 206 332 minecraft:polished_andesite
fill 295 204 353 295 206 354 minecraft:polished_andesite
setblock 295 204 357 minecraft:polished_andesite
setblock 295 204 358 minecraft:red_wool
fill 296 204 330 296 204 331 minecraft:polished_andesite
fill 296 204 354 296 204 355 minecraft:polished_andesite
fill 298 204 328 300 205 328 minecraft:cobblestone
fill 298 204 330 298 205 330 minecraft:cobblestone
fill 300 204 329 300 205 330 minecraft:cobblestone
fill 314 204 357 314 207 357 minecraft:iron_bars
fill 283 205 326 283 205 331 minecraft:cobblestone
fill 283 205 338 283 205 343 minecraft:cobblestone
fill 283 205 350 283 205 355 minecraft:cobblestone
fill 283 205 362 283 205 363 minecraft:cobblestone
fill 284 205 363 287 205 363 minecraft:cobblestone
fill 287 205 323 292 205 323 minecraft:cobblestone
fill 294 205 331 294 205 333 minecraft:polished_andesite
fill 294 205 352 294 205 354 minecraft:polished_andesite
fill 294 205 363 299 205 363 minecraft:cobblestone
setblock 295 205 329 minecraft:red_wool
fill 295 205 333 295 206 334 minecraft:polished_andesite
fill 295 205 351 295 207 352 minecraft:polished_andesite
setblock 295 205 356 minecraft:red_wool
fill 296 205 331 296 205 333 minecraft:polished_andesite
fill 296 205 352 296 205 354 minecraft:polished_andesite
fill 299 205 323 304 205 323 minecraft:cobblestone
setblock 301 205 329 minecraft:cobblestone
fill 306 205 363 311 205 363 minecraft:cobblestone
fill 311 205 323 316 205 323 minecraft:cobblestone
fill 318 205 363 323 205 363 minecraft:cobblestone
fill 323 205 323 323 205 328 minecraft:cobblestone
fill 323 205 335 323 205 340 minecraft:cobblestone
fill 323 205 347 323 205 352 minecraft:cobblestone
fill 323 205 359 323 205 362 minecraft:cobblestone
fill 282 206 328 282 211 331 minecraft:shroomlight
fill 282 206 332 282 249 332 minecraft:mossy_stone_bricks
fill 282 206 335 282 250 339 minecraft:mossy_stone_bricks
fill 282 206 340 282 211 343 minecraft:shroomlight
fill 282 206 344 282 248 351 minecraft:mossy_stone_bricks
fill 282 206 352 282 211 355 minecraft:shroomlight
fill 282 206 356 282 249 360 minecraft:mossy_stone_bricks
fill 282 206 364 285 211 364 minecraft:shroomlight
fill 284 206 356 284 209 358 minecraft:red_wool
fill 288 206 322 288 252 322 minecraft:mossy_stone_bricks
fill 289 206 322 292 211 322 minecraft:shroomlight
fill 291 206 364 293 248 364 minecraft:mossy_stone_bricks
fill 292 206 331 292 208 332 minecraft:cobblestone
fill 293 206 331 293 209 331 minecraft:cobblestone
fill 293 206 333 293 207 333 minecraft:cobblestone
fill 294 206 332 294 206 335 minecraft:polished_andesite
fill 294 206 350 294 206 353 minecraft:polished_andesite
fill 294 206 364 297 211 364 minecraft:shroomlight
setblock 295 206 330 minecraft:red_wool
fill 295 206 335 295 208 336 minecraft:polished_andesite
fill 295 206 349 295 208 350 minecraft:polished_andesite
setblock 295 206 355 minecraft:red_wool
fill 296 206 332 296 206 335 minecraft:polished_andesite
fill 296 206 350 296 206 353 minecraft:polished_andesite
fill 299 206 328 299 206 329 minecraft:cobblestone
fill 301 206 322 304 211 322 minecraft:shroomlight
fill 305 206 322 307 248 322 minecraft:mossy_stone_bricks
fill 306 206 364 309 211 364 minecraft:shroomlight
fill 310 206 364 315 248 364 minecraft:mossy_stone_bricks
fill 312 206 322 312 248 322 minecraft:mossy_stone_bricks
fill 313 206 322 316 211 322 minecraft:shroomlight
fill 317 206 322 319 252 322 minecraft:mossy_stone_bricks
fill 317 206 364 317 249 364 minecraft:mossy_stone_bricks
fill 318 206 364 321 211 364 minecraft:shroomlight
fill 322 206 364 324 248 364 minecraft:mossy_stone_bricks
fill 324 206 323 324 211 326 minecraft:shroomlight
fill 324 206 327 324 249 327 minecraft:mossy_stone_bricks
fill 324 206 335 324 211 338 minecraft:shroomlight
fill 324 206 346 324 248 346 minecraft:mossy_stone_bricks
fill 324 206 347 324 211 350 minecraft:shroomlight
fill 324 206 355 324 249 358 minecraft:mossy_stone_bricks
fill 324 206 359 324 211 362 minecraft:shroomlight
setblock 285 207 325 minecraft:light[level=15]
setblock 285 207 332 minecraft:light[level=12]
setblock 285 207 333 minecraft:light[level=15]
setblock 285 207 339 minecraft:light[level=12]
setblock 285 207 341 minecraft:light[level=15]
setblock 285 207 346 minecraft:light[level=12]
setblock 285 207 349 minecraft:light[level=15]
setblock 285 207 353 minecraft:light[level=12]
setblock 285 207 357 minecraft:light[level=15]
setblock 285 207 360 minecraft:light[level=12]
fill 291 207 331 291 207 332 minecraft:cobblestone
setblock 292 207 325 minecraft:light[level=12]
fill 292 207 330 292 208 330 minecraft:cobblestone
fill 292 207 333 292 208 333 minecraft:cobblestone
setblock 292 207 339 minecraft:light[level=12]
setblock 292 207 346 minecraft:light[level=12]
setblock 292 207 353 minecraft:light[level=12]
setblock 292 207 360 minecraft:light[level=12]
setblock 293 207 325 minecraft:light[level=15]
fill 293 207 332 294 208 332 minecraft:cobblestone
setblock 293 207 341 minecraft:light[level=15]
setblock 293 207 349 minecraft:light[level=15]
setblock 293 207 357 minecraft:light[level=15]
fill 294 207 334 294 207 337 minecraft:polished_andesite
fill 294 207 348 294 207 351 minecraft:polished_andesite
fill 295 207 332 295 207 333 minecraft:red_wool
fill 295 207 334 296 207 334 minecraft:polished_andesite
fill 295 207 337 295 208 341 minecraft:polished_andesite
fill 295 207 344 295 208 348 minecraft:polished_andesite
setblock 295 207 353 minecraft:red_wool
fill 296 207 335 296 207 337 minecraft:polished_andesite
fill 296 207 348 296 207 351 minecraft:polished_andesite
setblock 299 207 325 minecraft:light[level=12]
setblock 299 207 332 minecraft:light[level=12]
setblock 299 207 339 minecraft:light[level=12]
setblock 299 207 346 minecraft:light[level=12]
setblock 299 207 353 minecraft:light[level=12]
setblock 299 207 360 minecraft:light[level=12]
setblock 301 207 325 minecraft:light[level=15]
setblock 301 207 333 minecraft:light[level=15]
setblock 301 207 341 minecraft:light[level=15]
setblock 301 207 349 minecraft:light[level=15]
setblock 301 207 357 minecraft:light[level=15]
setblock 306 207 325 minecraft:light[level=12]
setblock 306 207 332 minecraft:light[level=12]
setblock 306 207 339 minecraft:light[level=12]
setblock 306 207 346 minecraft:light[level=12]
setblock 306 207 353 minecraft:light[level=12]
setblock 306 207 360 minecraft:light[level=12]
setblock 309 207 325 minecraft:light[level=15]
setblock 309 207 333 minecraft:light[level=15]
setblock 309 207 341 minecraft:light[level=15]
setblock 309 207 349 minecraft:light[level=15]
setblock 309 207 357 minecraft:light[level=15]
setblock 313 207 325 minecraft:light[level=12]
setblock 313 207 332 minecraft:light[level=12]
setblock 313 207 339 minecraft:light[level=12]
setblock 313 207 346 minecraft:light[level=12]
setblock 313 207 353 minecraft:light[level=12]
setblock 313 207 360 minecraft:light[level=12]
setblock 317 207 325 minecraft:light[level=15]
setblock 317 207 333 minecraft:light[level=15]
setblock 317 207 341 minecraft:light[level=15]
setblock 317 207 349 minecraft:light[level=15]
setblock 317 207 357 minecraft:light[level=15]
setblock 320 207 325 minecraft:light[level=12]
setblock 320 207 332 minecraft:light[level=12]
setblock 320 207 339 minecraft:light[level=12]
setblock 320 207 346 minecraft:light[level=12]
setblock 320 207 353 minecraft:light[level=12]
setblock 320 207 360 minecraft:light[level=12]
fill 291 208 332 291 208 333 minecraft:cobblestone
setblock 293 208 330 minecraft:cobblestone
fill 294 208 337 294 208 348 minecraft:polished_andesite
fill 295 208 333 295 208 334 minecraft:red_wool
fill 295 208 342 296 209 343 minecraft:polished_andesite
fill 295 208 351 295 208 352 minecraft:red_wool
fill 296 208 337 296 208 341 minecraft:polished_andesite
fill 296 208 344 296 208 348 minecraft:polished_andesite
fill 311 208 357 317 208 362 minecraft:cobblestone
fill 292 209 332 293 209 332 minecraft:cobblestone
fill 294 209 341 294 209 344 minecraft:polished_andesite
fill 295 209 336 295 209 337 minecraft:red_wool
fill 295 209 338 295 209 341 minecraft:polished_andesite
fill 295 209 344 295 209 347 minecraft:polished_andesite
fill 295 209 348 295 209 349 minecraft:red_wool
setblock 296 209 341 minecraft:polished_andesite
setblock 296 209 344 minecraft:polished_andesite
fill 311 209 357 317 209 362 minecraft:polished_andesite
fill 284 210 354 284 211 360 minecraft:iron_bars
fill 295 210 338 295 210 347 minecraft:red_wool
fill 311 210 357 317 210 357 minecraft:red_wool
fill 313 210 363 315 213 363 minecraft:shroomlight
setblock 311 211 357 minecraft:polished_andesite
setblock 314 211 357 minecraft:polished_andesite
setblock 317 211 357 minecraft:polished_andesite
fill 282 212 328 282 245 328 minecraft:mossy_stone_bricks
fill 282 212 329 282 212 330 minecraft:shroomlight
fill 282 212 331 282 245 331 minecraft:mossy_stone_bricks
fill 282 212 340 282 245 340 minecraft:mossy_stone_bricks
fill 282 212 341 282 212 342 minecraft:shroomlight
fill 282 212 343 282 245 343 minecraft:mossy_stone_bricks
fill 282 212 352 282 245 352 minecraft:mossy_stone_bricks
fill 282 212 353 282 212 354 minecraft:shroomlight
fill 282 212 355 282 245 355 minecraft:mossy_stone_bricks
fill 282 212 364 282 245 364 minecraft:mossy_stone_bricks
fill 283 212 364 284 212 364 minecraft:shroomlight
fill 285 212 364 285 245 364 minecraft:mossy_stone_bricks
fill 289 212 322 289 245 322 minecraft:mossy_stone_bricks
fill 290 212 322 291 212 322 minecraft:shroomlight
fill 292 212 322 292 245 322 minecraft:mossy_stone_bricks
fill 294 212 364 294 245 364 minecraft:mossy_stone_bricks
fill 295 212 364 296 212 364 minecraft:shroomlight
fill 297 212 364 297 245 364 minecraft:mossy_stone_bricks
fill 301 212 322 301 245 322 minecraft:mossy_stone_bricks
fill 302 212 322 303 212 322 minecraft:shroomlight
fill 304 212 322 304 245 322 minecraft:mossy_stone_bricks
fill 306 212 364 306 245 364 minecraft:mossy_stone_bricks
fill 307 212 364 308 212 364 minecraft:shroomlight
fill 309 212 364 309 245 364 minecraft:mossy_stone_bricks
fill 313 212 322 313 245 322 minecraft:mossy_stone_bricks
fill 314 212 322 315 212 322 minecraft:shroomlight
fill 316 212 322 316 245 322 minecraft:mossy_stone_bricks
fill 318 212 364 318 245 364 minecraft:mossy_stone_bricks
fill 319 212 364 320 212 364 minecraft:shroomlight
fill 321 212 364 321 245 364 minecraft:mossy_stone_bricks
fill 324 212 323 324 245 323 minecraft:mossy_stone_bricks
fill 324 212 324 324 212 325 minecraft:shroomlight
fill 324 212 326 324 245 326 minecraft:mossy_stone_bricks
fill 324 212 335 324 245 335 minecraft:mossy_stone_bricks
fill 324 212 336 324 212 337 minecraft:shroomlight
fill 324 212 338 324 245 338 minecraft:mossy_stone_bricks
fill 324 212 347 324 245 347 minecraft:mossy_stone_bricks
fill 324 212 348 324 212 349 minecraft:shroomlight
fill 324 212 350 324 245 350 minecraft:mossy_stone_bricks
fill 324 212 359 324 245 359 minecraft:mossy_stone_bricks
fill 324 212 360 324 212 361 minecraft:shroomlight
fill 324 212 362 324 245 362 minecraft:mossy_stone_bricks
fill 282 213 329 282 245 330 minecraft:mossy_stone_bricks
fill 282 213 341 282 245 342 minecraft:mossy_stone_bricks
fill 282 213 353 282 245 354 minecraft:mossy_stone_bricks
fill 283 213 364 284 245 364 minecraft:mossy_stone_bricks
setblock 285 213 325 minecraft:light[level=12]
setblock 285 213 332 minecraft:light[level=12]
setblock 285 213 339 minecraft:light[level=12]
setblock 285 213 346 minecraft:light[level=12]
setblock 285 213 353 minecraft:light[level=12]
setblock 285 213 360 minecraft:light[level=12]
fill 290 213 322 291 245 322 minecraft:mossy_stone_bricks
setblock 292 213 325 minecraft:light[level=12]
setblock 292 213 332 minecraft:light[level=12]
setblock 292 213 339 minecraft:light[level=12]
setblock 292 213 346 minecraft:light[level=12]
setblock 292 213 353 minecraft:light[level=12]
setblock 292 213 360 minecraft:light[level=12]
fill 295 213 364 296 245 364 minecraft:mossy_stone_bricks
setblock 299 213 325 minecraft:light[level=12]
setblock 299 213 332 minecraft:light[level=12]
setblock 299 213 339 minecraft:light[level=12]
setblock 299 213 346 minecraft:light[level=12]
setblock 299 213 353 minecraft:light[level=12]
setblock 299 213 360 minecraft:light[level=12]
fill 302 213 322 303 245 322 minecraft:mossy_stone_bricks
setblock 306 213 325 minecraft:light[level=12]
setblock 306 213 332 minecraft:light[level=12]
setblock 306 213 339 minecraft:light[level=12]
setblock 306 213 346 minecraft:light[level=12]
setblock 306 213 353 minecraft:light[level=12]
setblock 306 213 360 minecraft:light[level=12]
fill 307 213 364 308 245 364 minecraft:mossy_stone_bricks
setblock 313 213 325 minecraft:light[level=12]
setblock 313 213 332 minecraft:light[level=12]
setblock 313 213 339 minecraft:light[level=12]
setblock 313 213 346 minecraft:light[level=12]
setblock 313 213 353 minecraft:light[level=12]
setblock 313 213 360 minecraft:light[level=12]
fill 314 213 322 315 245 322 minecraft:mossy_stone_bricks
fill 319 213 364 320 245 364 minecraft:mossy_stone_bricks
setblock 320 213 325 minecraft:light[level=12]
setblock 320 213 332 minecraft:light[level=12]
setblock 320 213 339 minecraft:light[level=12]
setblock 320 213 346 minecraft:light[level=12]
setblock 320 213 353 minecraft:light[level=12]
setblock 320 213 360 minecraft:light[level=12]
fill 324 213 324 324 245 325 minecraft:mossy_stone_bricks
fill 324 213 336 324 245 337 minecraft:mossy_stone_bricks
fill 324 213 348 324 245 349 minecraft:mossy_stone_bricks
fill 324 213 360 324 245 361 minecraft:mossy_stone_bricks
fill 313 214 363 315 225 363 minecraft:polished_andesite
setblock 285 215 325 minecraft:light[level=15]
setblock 285 215 333 minecraft:light[level=15]
setblock 285 215 341 minecraft:light[level=15]
setblock 285 215 349 minecraft:light[level=15]
setblock 285 215 357 minecraft:light[level=15]
setblock 293 215 325 minecraft:light[level=15]
setblock 293 215 333 minecraft:light[level=15]
setblock 293 215 341 minecraft:light[level=15]
setblock 293 215 349 minecraft:light[level=15]
setblock 293 215 357 minecraft:light[level=15]
setblock 301 215 325 minecraft:light[level=15]
setblock 301 215 333 minecraft:light[level=15]
setblock 301 215 341 minecraft:light[level=15]
setblock 301 215 349 minecraft:light[level=15]
setblock 301 215 357 minecraft:light[level=15]
setblock 309 215 325 minecraft:light[level=15]
setblock 309 215 333 minecraft:light[level=15]
setblock 309 215 341 minecraft:light[level=15]
setblock 309 215 349 minecraft:light[level=15]
setblock 309 215 357 minecraft:light[level=15]
setblock 317 215 325 minecraft:light[level=15]
setblock 317 215 333 minecraft:light[level=15]
setblock 317 215 341 minecraft:light[level=15]
setblock 317 215 349 minecraft:light[level=15]
setblock 317 215 357 minecraft:light[level=15]
fill 283 219 338 285 220 338 minecraft:iron_bars
setblock 285 219 325 minecraft:light[level=12]
setblock 285 219 332 minecraft:light[level=12]
setblock 285 219 339 minecraft:light[level=12]
setblock 285 219 346 minecraft:light[level=12]
setblock 285 219 353 minecraft:light[level=12]
setblock 285 219 360 minecraft:light[level=12]
setblock 292 219 325 minecraft:light[level=12]
setblock 292 219 332 minecraft:light[level=12]
setblock 292 219 339 minecraft:light[level=12]
setblock 292 219 346 minecraft:light[level=12]
setblock 292 219 353 minecraft:light[level=12]
setblock 292 219 360 minecraft:light[level=12]
setblock 299 219 325 minecraft:light[level=12]
setblock 299 219 332 minecraft:light[level=12]
setblock 299 219 339 minecraft:light[level=12]
setblock 299 219 346 minecraft:light[level=12]
setblock 299 219 353 minecraft:light[level=12]
setblock 299 219 360 minecraft:light[level=12]
setblock 306 219 325 minecraft:light[level=12]
setblock 306 219 332 minecraft:light[level=12]
setblock 306 219 339 minecraft:light[level=12]
setblock 306 219 346 minecraft:light[level=12]
setblock 306 219 353 minecraft:light[level=12]
setblock 306 219 360 minecraft:light[level=12]
setblock 313 219 325 minecraft:light[level=12]
setblock 313 219 332 minecraft:light[level=12]
setblock 313 219 339 minecraft:light[level=12]
setblock 313 219 346 minecraft:light[level=12]
setblock 313 219 353 minecraft:light[level=12]
setblock 313 219 360 minecraft:light[level=12]
setblock 320 219 325 minecraft:light[level=12]
setblock 320 219 332 minecraft:light[level=12]
setblock 320 219 339 minecraft:light[level=12]
setblock 320 219 346 minecraft:light[level=12]
setblock 320 219 353 minecraft:light[level=12]
setblock 320 219 360 minecraft:light[level=12]
fill 283 220 351 283 222 353 minecraft:yellow_wool
fill 284 220 332 284 225 334 minecraft:polished_andesite
fill 284 220 344 284 225 346 minecraft:polished_andesite
fill 284 220 356 284 225 358 minecraft:polished_andesite
fill 290 220 362 292 225 362 minecraft:polished_andesite
fill 293 220 323 295 222 323 minecraft:red_wool
fill 294 220 324 296 225 324 minecraft:polished_andesite
fill 295 220 363 297 222 363 minecraft:blue_wool
fill 302 220 362 304 225 362 minecraft:polished_andesite
fill 306 220 324 308 225 324 minecraft:polished_andesite
fill 314 220 362 316 225 362 minecraft:polished_andesite
fill 318 220 324 320 225 324 minecraft:polished_andesite
fill 322 220 332 322 225 334 minecraft:polished_andesite
fill 322 220 344 322 225 346 minecraft:polished_andesite
fill 322 220 356 322 225 358 minecraft:polished_andesite
fill 323 220 349 323 222 351 minecraft:red_wool
fill 283 221 336 285 222 336 minecraft:iron_bars
fill 285 221 333 285 222 333 minecraft:iron_bars
fill 283 223 351 283 228 351 minecraft:yellow_wool
fill 283 223 352 283 225 352 minecraft:gold_block
fill 283 223 353 283 228 353 minecraft:yellow_wool
setblock 285 223 325 minecraft:light[level=15]
setblock 285 223 333 minecraft:light[level=15]
setblock 285 223 341 minecraft:light[level=15]
setblock 285 223 349 minecraft:light[level=15]
setblock 285 223 357 minecraft:light[level=15]
fill 293 223 323 293 228 323 minecraft:red_wool
setblock 293 223 325 minecraft:light[level=15]
setblock 293 223 333 minecraft:light[level=15]
setblock 293 223 341 minecraft:light[level=15]
setblock 293 223 349 minecraft:light[level=15]
setblock 293 223 357 minecraft:light[level=15]
fill 294 223 323 294 225 323 minecraft:gold_block
fill 295 223 323 295 228 323 minecraft:red_wool
fill 295 223 363 295 228 363 minecraft:blue_wool
fill 296 223 363 296 225 363 minecraft:gold_block
fill 297 223 363 297 228 363 minecraft:blue_wool
setblock 301 223 325 minecraft:light[level=15]
setblock 301 223 333 minecraft:light[level=15]
setblock 301 223 341 minecraft:light[level=15]
setblock 301 223 349 minecraft:light[level=15]
setblock 301 223 357 minecraft:light[level=15]
setblock 309 223 325 minecraft:light[level=15]
setblock 309 223 333 minecraft:light[level=15]
setblock 309 223 341 minecraft:light[level=15]
setblock 309 223 349 minecraft:light[level=15]
setblock 309 223 357 minecraft:light[level=15]
setblock 317 223 325 minecraft:light[level=15]
setblock 317 223 333 minecraft:light[level=15]
setblock 317 223 341 minecraft:light[level=15]
setblock 317 223 349 minecraft:light[level=15]
setblock 317 223 357 minecraft:light[level=15]
fill 323 223 349 323 228 349 minecraft:red_wool
fill 323 223 350 323 225 350 minecraft:gold_block
fill 323 223 351 323 228 351 minecraft:red_wool
fill 295 224 325 295 225 339 minecraft:polished_andesite
fill 283 225 326 283 225 331 minecraft:cobblestone
fill 283 225 338 283 225 343 minecraft:cobblestone
setblock 283 225 350 minecraft:cobblestone
fill 283 225 354 283 225 355 minecraft:cobblestone
fill 283 225 362 283 225 363 minecraft:cobblestone
fill 284 225 363 287 225 363 minecraft:cobblestone
setblock 285 225 325 minecraft:light[level=12]
setblock 285 225 332 minecraft:light[level=12]
setblock 285 225 339 minecraft:light[level=12]
setblock 285 225 346 minecraft:light[level=12]
setblock 285 225 353 minecraft:light[level=12]
setblock 285 225 360 minecraft:light[level=12]
fill 287 225 323 292 225 323 minecraft:cobblestone
setblock 292 225 325 minecraft:light[level=12]
setblock 292 225 332 minecraft:light[level=12]
setblock 292 225 339 minecraft:light[level=12]
setblock 292 225 346 minecraft:light[level=12]
setblock 292 225 353 minecraft:light[level=12]
setblock 292 225 360 minecraft:light[level=12]
setblock 294 225 363 minecraft:cobblestone
fill 295 225 340 296 225 362 minecraft:polished_andesite
fill 296 225 325 296 225 339 minecraft:polished_andesite
fill 298 225 363 299 225 363 minecraft:cobblestone
fill 299 225 323 304 225 323 minecraft:cobblestone
setblock 299 225 325 minecraft:light[level=12]
setblock 299 225 332 minecraft:light[level=12]
setblock 299 225 339 minecraft:light[level=12]
setblock 299 225 346 minecraft:light[level=12]
setblock 299 225 353 minecraft:light[level=12]
setblock 299 225 360 minecraft:light[level=12]
setblock 306 225 325 minecraft:light[level=12]
setblock 306 225 332 minecraft:light[level=12]
setblock 306 225 339 minecraft:light[level=12]
setblock 306 225 346 minecraft:light[level=12]
setblock 306 225 353 minecraft:light[level=12]
setblock 306 225 360 minecraft:light[level=12]
fill 306 225 363 311 225 363 minecraft:cobblestone
fill 311 225 323 316 225 323 minecraft:cobblestone
setblock 313 225 325 minecraft:light[level=12]
setblock 313 225 332 minecraft:light[level=12]
setblock 313 225 339 minecraft:light[level=12]
setblock 313 225 346 minecraft:light[level=12]
setblock 313 225 353 minecraft:light[level=12]
setblock 313 225 360 minecraft:light[level=12]
fill 318 225 363 323 225 363 minecraft:cobblestone
setblock 320 225 325 minecraft:light[level=12]
setblock 320 225 332 minecraft:light[level=12]
setblock 320 225 339 minecraft:light[level=12]
setblock 320 225 346 minecraft:light[level=12]
setblock 320 225 353 minecraft:light[level=12]
setblock 320 225 360 minecraft:light[level=12]
fill 323 225 323 323 225 328 minecraft:cobblestone
fill 323 225 335 323 225 340 minecraft:cobblestone
fill 323 225 347 323 225 348 minecraft:cobblestone
setblock 323 225 352 minecraft:cobblestone
fill 323 225 359 323 225 362 minecraft:cobblestone
fill 283 226 352 283 228 352 minecraft:yellow_wool
fill 294 226 323 294 228 323 minecraft:red_wool
fill 296 226 363 296 228 363 minecraft:blue_wool
fill 323 226 350 323 228 350 minecraft:red_wool
fill 283 231 323 323 232 323 minecraft:dark_oak_planks
fill 283 231 324 323 232 324 minecraft:spruce_planks
fill 283 231 325 323 232 325 minecraft:dark_oak_planks
fill 283 231 326 323 232 326 minecraft:spruce_planks
fill 283 231 327 323 232 327 minecraft:dark_oak_planks
fill 283 231 328 323 232 328 minecraft:spruce_planks
fill 283 231 329 323 232 329 minecraft:dark_oak_planks
fill 283 231 330 323 232 330 minecraft:spruce_planks
fill 283 231 331 323 232 331 minecraft:dark_oak_planks
fill 283 231 332 323 232 332 minecraft:spruce_planks
fill 283 231 333 323 232 333 minecraft:dark_oak_planks
fill 283 231 334 323 232 334 minecraft:spruce_planks
fill 283 231 335 323 232 335 minecraft:dark_oak_planks
fill 283 231 336 323 232 336 minecraft:spruce_planks
fill 283 231 337 323 231 337 minecraft:dark_oak_planks
fill 283 231 338 323 231 338 minecraft:spruce_planks
fill 283 231 339 323 231 339 minecraft:dark_oak_planks
fill 283 231 340 323 231 340 minecraft:spruce_planks
fill 283 231 341 299 231 341 minecraft:dark_oak_planks
fill 283 231 342 298 231 342 minecraft:spruce_planks
fill 283 231 343 298 231 343 minecraft:dark_oak_planks
fill 283 231 344 298 231 344 minecraft:spruce_planks
fill 283 231 345 299 231 345 minecraft:dark_oak_planks
fill 283 231 346 323 231 346 minecraft:spruce_planks
fill 283 231 347 323 231 347 minecraft:dark_oak_planks
fill 283 231 348 323 231 348 minecraft:spruce_planks
fill 283 231 349 323 231 349 minecraft:dark_oak_planks
fill 283 231 350 323 232 350 minecraft:spruce_planks
fill 283 231 351 323 232 351 minecraft:dark_oak_planks
fill 283 231 352 323 232 352 minecraft:spruce_planks
fill 283 231 353 323 232 353 minecraft:dark_oak_planks
fill 283 231 354 323 232 354 minecraft:spruce_planks
fill 283 231 355 323 232 355 minecraft:dark_oak_planks
fill 283 231 356 323 232 356 minecraft:spruce_planks
fill 283 231 357 323 232 357 minecraft:dark_oak_planks
fill 283 231 358 323 232 358 minecraft:spruce_planks
fill 283 231 359 323 232 359 minecraft:dark_oak_planks
fill 283 231 360 323 232 360 minecraft:spruce_planks
fill 283 231 361 323 232 361 minecraft:dark_oak_planks
fill 283 231 362 323 232 362 minecraft:spruce_planks
fill 283 231 363 323 232 363 minecraft:dark_oak_planks
fill 303 231 341 323 231 341 minecraft:dark_oak_planks
fill 303 231 345 323 231 345 minecraft:dark_oak_planks
fill 304 231 342 323 231 342 minecraft:spruce_planks
fill 304 231 343 323 231 343 minecraft:dark_oak_planks
fill 304 231 344 323 231 344 minecraft:spruce_planks
fill 283 232 337 298 232 337 minecraft:dark_oak_planks
fill 283 232 338 296 232 338 minecraft:spruce_planks
fill 283 232 339 295 232 339 minecraft:dark_oak_planks
fill 283 232 340 295 232 340 minecraft:spruce_planks
fill 283 232 341 294 232 341 minecraft:dark_oak_planks
fill 283 232 342 294 232 342 minecraft:spruce_planks
fill 283 232 343 294 232 343 minecraft:dark_oak_planks
fill 283 232 344 294 232 344 minecraft:spruce_planks
fill 283 232 345 294 232 345 minecraft:dark_oak_planks
fill 283 232 346 295 232 346 minecraft:spruce_planks
fill 283 232 347 295 232 347 minecraft:dark_oak_planks
fill 283 232 348 296 232 348 minecraft:spruce_planks
fill 283 232 349 298 232 349 minecraft:dark_oak_planks
fill 295 232 341 298 232 345 minecraft:mossy_stone_bricks
fill 296 232 339 306 232 340 minecraft:mossy_stone_bricks
fill 296 232 346 306 232 347 minecraft:mossy_stone_bricks
fill 297 232 338 305 232 338 minecraft:mossy_stone_bricks
fill 297 232 348 305 232 348 minecraft:mossy_stone_bricks
fill 299 232 337 303 232 337 minecraft:mossy_stone_bricks
setblock 299 232 341 minecraft:mossy_stone_bricks
setblock 299 232 345 minecraft:mossy_stone_bricks
fill 299 232 349 303 232 349 minecraft:mossy_stone_bricks
fill 303 232 341 307 232 341 minecraft:mossy_stone_bricks
fill 303 232 345 307 232 345 minecraft:mossy_stone_bricks
fill 304 232 337 323 232 337 minecraft:dark_oak_planks
fill 304 232 342 307 232 344 minecraft:mossy_stone_bricks
fill 304 232 349 323 232 349 minecraft:dark_oak_planks
fill 306 232 338 323 232 338 minecraft:spruce_planks
fill 306 232 348 323 232 348 minecraft:spruce_planks
fill 307 232 339 323 232 339 minecraft:dark_oak_planks
fill 307 232 340 323 232 340 minecraft:spruce_planks
fill 307 232 346 323 232 346 minecraft:spruce_planks
fill 307 232 347 323 232 347 minecraft:dark_oak_planks
fill 308 232 341 323 232 341 minecraft:dark_oak_planks
fill 308 232 342 323 232 342 minecraft:spruce_planks
fill 308 232 343 323 232 343 minecraft:dark_oak_planks
fill 308 232 344 323 232 344 minecraft:spruce_planks
fill 308 232 345 323 232 345 minecraft:dark_oak_planks
fill 292 233 353 292 233 354 minecraft:iron_bars
fill 293 233 341 294 242 345 minecraft:stone_bricks
fill 294 233 336 296 245 339 minecraft:cobblestone
fill 294 233 340 295 242 340 minecraft:stone_bricks
fill 294 233 346 295 243 346 minecraft:stone_bricks
fill 294 233 347 296 245 350 minecraft:cobblestone
fill 297 233 336 297 245 338 minecraft:cobblestone
fill 297 233 348 297 245 350 minecraft:cobblestone
fill 298 233 336 298 242 337 minecraft:stone_bricks
fill 298 233 349 298 242 350 minecraft:stone_bricks
fill 299 233 335 303 242 336 minecraft:stone_bricks
fill 299 233 350 303 242 351 minecraft:stone_bricks
fill 304 233 336 304 242 337 minecraft:stone_bricks
fill 304 233 349 304 243 350 minecraft:stone_bricks
fill 305 233 336 308 245 338 minecraft:cobblestone
fill 305 233 348 308 245 350 minecraft:cobblestone
fill 306 233 339 308 245 339 minecraft:cobblestone
fill 306 233 347 308 245 347 minecraft:cobblestone
fill 307 233 340 308 243 340 minecraft:stone_bricks
fill 307 233 346 308 242 346 minecraft:stone_bricks
fill 308 233 341 309 242 345 minecraft:stone_bricks
fill 310 233 353 310 233 354 minecraft:iron_bars
fill 292 234 351 292 234 352 minecraft:iron_bars
fill 310 234 351 310 234 352 minecraft:iron_bars
setblock 292 235 349 minecraft:iron_bars
setblock 310 235 349 minecraft:iron_bars
fill 283 236 323 285 272 323 minecraft:polished_andesite
fill 283 236 333 283 272 335 minecraft:polished_andesite
fill 283 236 345 283 272 347 minecraft:polished_andesite
fill 283 236 357 283 272 359 minecraft:polished_andesite
fill 285 236 358 285 236 360 minecraft:cobblestone
setblock 286 236 357 minecraft:cobblestone
fill 286 236 358 288 272 360 minecraft:polished_andesite
fill 286 236 361 288 236 361 minecraft:cobblestone
fill 287 236 357 287 272 357 minecraft:polished_andesite
fill 288 236 323 300 242 331 minecraft:polished_andesite
setblock 288 236 357 minecraft:cobblestone
fill 289 236 358 289 236 360 minecraft:cobblestone
fill 289 236 363 291 272 363 minecraft:polished_andesite
fill 301 236 363 303 272 363 minecraft:polished_andesite
fill 307 236 323 309 272 323 minecraft:polished_andesite
fill 310 236 324 314 247 324 minecraft:red_wool
fill 313 236 363 315 272 363 minecraft:polished_andesite
setblock 316 236 327 minecraft:cobblestone
fill 316 236 358 316 236 360 minecraft:cobblestone
setblock 317 236 326 minecraft:cobblestone
fill 317 236 327 320 272 328 minecraft:polished_andesite
setblock 317 236 329 minecraft:cobblestone
fill 317 236 357 320 236 357 minecraft:cobblestone
fill 317 236 358 319 272 360 minecraft:polished_andesite
fill 317 236 361 319 236 361 minecraft:cobblestone
fill 318 236 325 319 236 325 minecraft:cobblestone
fill 318 236 326 319 272 326 minecraft:polished_andesite
fill 318 236 329 319 272 329 minecraft:polished_andesite
fill 319 236 323 321 272 323 minecraft:polished_andesite
setblock 320 236 326 minecraft:cobblestone
setblock 320 236 329 minecraft:cobblestone
setblock 320 236 358 minecraft:cobblestone
fill 320 236 359 320 272 359 minecraft:polished_andesite
setblock 320 236 360 minecraft:cobblestone
fill 321 236 327 321 236 328 minecraft:cobblestone
fill 323 236 331 323 272 333 minecraft:polished_andesite
fill 323 236 343 323 272 345 minecraft:polished_andesite
fill 323 236 355 323 272 357 minecraft:polished_andesite
setblock 285 237 325 minecraft:light[level=12]
setblock 285 237 332 minecraft:light[level=12]
setblock 285 237 339 minecraft:light[level=12]
setblock 285 237 346 minecraft:light[level=12]
setblock 285 237 353 minecraft:light[level=12]
setblock 285 237 360 minecraft:light[level=12]
setblock 292 237 332 minecraft:light[level=12]
setblock 292 237 339 minecraft:light[level=12]
setblock 292 237 346 minecraft:light[level=12]
setblock 292 237 353 minecraft:light[level=12]
setblock 292 237 360 minecraft:light[level=12]
setblock 299 237 332 minecraft:light[level=12]
setblock 299 237 339 minecraft:light[level=12]
setblock 299 237 346 minecraft:light[level=12]
setblock 299 237 353 minecraft:light[level=12]
setblock 299 237 360 minecraft:light[level=12]
setblock 306 237 325 minecraft:light[level=12]
setblock 306 237 332 minecraft:light[level=12]
setblock 306 237 346 minecraft:light[level=12]
setblock 306 237 353 minecraft:light[level=12]
setblock 306 237 360 minecraft:light[level=12]
setblock 313 237 325 minecraft:light[level=12]
setblock 313 237 332 minecraft:light[level=12]
setblock 313 237 339 minecraft:light[level=12]
setblock 313 237 346 minecraft:light[level=12]
setblock 313 237 353 minecraft:light[level=12]
schedule function dropper:buildpart/78_3 1t
