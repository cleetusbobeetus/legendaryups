fill 49 268 587 49 271 587 minecraft:cobbled_deepslate
setblock 49 268 591 minecraft:calcite
fill 49 268 592 49 271 592 minecraft:cobbled_deepslate
setblock 49 268 595 minecraft:cobbled_deepslate
setblock 50 268 560 minecraft:light[level=14]
setblock 50 268 568 minecraft:light[level=14]
setblock 50 268 576 minecraft:light[level=14]
setblock 50 268 584 minecraft:light[level=14]
setblock 50 268 589 minecraft:cobbled_deepslate
setblock 50 268 590 minecraft:calcite
fill 50 268 591 50 271 591 minecraft:cobbled_deepslate
setblock 50 268 592 minecraft:light[level=14]
fill 53 268 598 56 268 598 minecraft:cobbled_deepslate
setblock 57 268 597 minecraft:cobbled_deepslate
setblock 57 268 598 minecraft:calcite
setblock 58 268 560 minecraft:light[level=14]
setblock 58 268 568 minecraft:light[level=14]
setblock 58 268 576 minecraft:light[level=14]
setblock 58 268 584 minecraft:light[level=14]
setblock 58 268 592 minecraft:light[level=14]
setblock 58 268 597 minecraft:calcite
fill 58 268 598 58 271 598 minecraft:cobbled_deepslate
fill 59 268 597 61 269 597 minecraft:cobbled_deepslate
setblock 62 268 598 minecraft:calcite
fill 63 268 598 63 271 598 minecraft:cobbled_deepslate
setblock 66 268 560 minecraft:light[level=14]
setblock 66 268 568 minecraft:light[level=14]
setblock 66 268 576 minecraft:light[level=14]
setblock 66 268 584 minecraft:light[level=14]
setblock 66 268 592 minecraft:light[level=14]
setblock 74 268 560 minecraft:light[level=14]
setblock 74 268 568 minecraft:light[level=14]
setblock 74 268 576 minecraft:light[level=14]
setblock 74 268 584 minecraft:light[level=14]
setblock 74 268 592 minecraft:light[level=14]
fill 75 268 558 75 269 558 minecraft:cobbled_deepslate
setblock 77 268 558 minecraft:calcite
fill 77 268 559 77 271 559 minecraft:cobbled_deepslate
setblock 77 268 598 minecraft:calcite
fill 78 268 558 78 271 558 minecraft:cobbled_deepslate
fill 78 268 560 78 269 560 minecraft:cobbled_deepslate
fill 78 268 598 78 271 598 minecraft:cobbled_deepslate
fill 79 268 597 82 268 597 minecraft:cobbled_deepslate
setblock 80 268 559 minecraft:cobbled_deepslate
setblock 80 268 560 minecraft:calcite
setblock 81 268 559 minecraft:calcite
fill 81 268 560 81 270 560 minecraft:cobbled_deepslate
setblock 82 268 558 minecraft:calcite
fill 82 268 559 82 271 559 minecraft:cobbled_deepslate
setblock 82 268 568 minecraft:light[level=14]
setblock 82 268 576 minecraft:light[level=14]
setblock 82 268 584 minecraft:light[level=14]
setblock 82 268 592 minecraft:light[level=14]
setblock 82 268 598 minecraft:calcite
fill 83 268 558 83 271 558 minecraft:cobbled_deepslate
setblock 83 268 597 minecraft:calcite
fill 83 268 598 83 271 598 minecraft:cobbled_deepslate
fill 84 268 597 85 270 597 minecraft:cobbled_deepslate
setblock 86 268 598 minecraft:cobbled_deepslate
setblock 87 268 558 minecraft:calcite
setblock 87 268 563 minecraft:calcite
fill 87 268 564 87 269 564 minecraft:cobbled_deepslate
setblock 87 268 568 minecraft:calcite
fill 87 268 569 87 269 569 minecraft:cobbled_deepslate
setblock 87 268 588 minecraft:calcite
fill 87 268 589 87 270 589 minecraft:cobbled_deepslate
setblock 87 268 592 minecraft:cobbled_deepslate
setblock 87 268 593 minecraft:calcite
fill 87 268 594 87 270 595 minecraft:cobbled_deepslate
setblock 87 268 598 minecraft:calcite
fill 88 268 558 88 269 558 minecraft:cobbled_deepslate
setblock 88 268 562 minecraft:calcite
fill 88 268 563 88 270 563 minecraft:cobbled_deepslate
setblock 88 268 567 minecraft:calcite
fill 88 268 568 88 271 568 minecraft:cobbled_deepslate
setblock 88 268 572 minecraft:calcite
setblock 88 268 587 minecraft:calcite
fill 88 268 588 88 271 588 minecraft:cobbled_deepslate
setblock 88 268 592 minecraft:calcite
fill 88 268 593 88 271 593 minecraft:cobbled_deepslate
fill 88 268 595 88 268 596 minecraft:cobbled_deepslate
setblock 88 268 597 minecraft:calcite
fill 88 268 598 88 271 598 minecraft:cobbled_deepslate
setblock 48 269 567 minecraft:cobbled_deepslate
setblock 48 269 586 minecraft:calcite
fill 48 269 587 48 272 587 minecraft:cobbled_deepslate
setblock 48 269 591 minecraft:calcite
fill 48 269 592 48 272 592 minecraft:cobbled_deepslate
setblock 48 269 596 minecraft:calcite
fill 48 269 597 48 272 597 minecraft:cobbled_deepslate
setblock 49 269 586 minecraft:cobbled_deepslate
setblock 49 269 590 minecraft:calcite
fill 49 269 591 49 272 591 minecraft:cobbled_deepslate
setblock 49 269 595 minecraft:calcite
fill 49 269 596 49 272 596 minecraft:cobbled_deepslate
setblock 50 269 589 minecraft:calcite
fill 50 269 590 50 271 590 minecraft:cobbled_deepslate
fill 50 269 592 50 270 592 minecraft:cobbled_deepslate
setblock 50 269 598 minecraft:cobbled_deepslate
setblock 51 269 598 minecraft:calcite
fill 52 269 598 55 269 598 minecraft:cobbled_deepslate
fill 55 269 597 56 269 597 minecraft:cobbled_deepslate
setblock 56 269 598 minecraft:calcite
setblock 57 269 597 minecraft:calcite
fill 57 269 598 57 272 598 minecraft:cobbled_deepslate
setblock 58 269 596 minecraft:calcite
fill 58 269 597 58 272 597 minecraft:cobbled_deepslate
fill 59 269 558 60 269 558 minecraft:cobbled_deepslate
setblock 61 269 598 minecraft:calcite
fill 62 269 598 62 272 598 minecraft:cobbled_deepslate
fill 74 269 558 74 270 558 minecraft:cobbled_deepslate
setblock 76 269 558 minecraft:calcite
fill 76 269 559 76 272 559 minecraft:cobbled_deepslate
setblock 76 269 598 minecraft:calcite
fill 77 269 558 77 272 558 minecraft:cobbled_deepslate
setblock 77 269 597 minecraft:calcite
fill 77 269 598 77 272 598 minecraft:cobbled_deepslate
fill 78 269 597 81 269 597 minecraft:cobbled_deepslate
setblock 79 269 560 minecraft:calcite
setblock 80 269 559 minecraft:calcite
fill 80 269 560 80 271 560 minecraft:cobbled_deepslate
fill 80 269 596 82 269 596 minecraft:cobbled_deepslate
setblock 81 269 558 minecraft:calcite
fill 81 269 559 81 272 559 minecraft:cobbled_deepslate
setblock 81 269 598 minecraft:calcite
fill 82 269 558 82 272 558 minecraft:cobbled_deepslate
setblock 82 269 597 minecraft:calcite
fill 82 269 598 82 272 598 minecraft:cobbled_deepslate
fill 83 269 597 83 272 597 minecraft:cobbled_deepslate
setblock 85 269 559 minecraft:calcite
fill 85 269 590 85 273 590 minecraft:deepslate
setblock 86 269 558 minecraft:calcite
fill 86 269 589 86 273 589 minecraft:deepslate
fill 86 269 591 86 273 591 minecraft:deepslate
setblock 86 269 597 minecraft:cobbled_deepslate
setblock 86 269 598 minecraft:calcite
fill 87 269 558 87 270 558 minecraft:cobbled_deepslate
setblock 87 269 567 minecraft:calcite
fill 87 269 568 87 270 568 minecraft:cobbled_deepslate
setblock 87 269 592 minecraft:calcite
fill 87 269 593 87 272 593 minecraft:cobbled_deepslate
setblock 87 269 596 minecraft:cobbled_deepslate
fill 87 269 598 87 272 598 minecraft:cobbled_deepslate
setblock 88 269 561 minecraft:calcite
setblock 88 269 562 minecraft:cobbled_deepslate
setblock 88 269 566 minecraft:calcite
fill 88 269 567 88 271 567 minecraft:cobbled_deepslate
setblock 88 269 570 minecraft:cobbled_deepslate
setblock 88 269 571 minecraft:calcite
fill 88 269 572 88 271 572 minecraft:cobbled_deepslate
setblock 88 269 586 minecraft:calcite
fill 88 269 587 88 270 587 minecraft:cobbled_deepslate
setblock 88 269 591 minecraft:calcite
fill 88 269 592 88 272 592 minecraft:cobbled_deepslate
setblock 88 269 595 minecraft:cobbled_deepslate
setblock 88 269 596 minecraft:calcite
fill 88 269 597 88 272 597 minecraft:cobbled_deepslate
setblock 48 270 570 minecraft:calcite
fill 48 270 571 48 271 571 minecraft:cobbled_deepslate
setblock 48 270 585 minecraft:calcite
fill 48 270 586 48 272 586 minecraft:cobbled_deepslate
setblock 48 270 590 minecraft:calcite
fill 48 270 591 48 273 591 minecraft:cobbled_deepslate
setblock 48 270 594 minecraft:cobbled_deepslate
setblock 48 270 595 minecraft:calcite
fill 48 270 596 48 273 596 minecraft:cobbled_deepslate
setblock 49 270 589 minecraft:calcite
fill 49 270 590 49 273 590 minecraft:cobbled_deepslate
setblock 49 270 594 minecraft:calcite
fill 49 270 595 49 273 595 minecraft:cobbled_deepslate
setblock 50 270 589 minecraft:cobbled_deepslate
setblock 50 270 593 minecraft:calcite
setblock 50 270 598 minecraft:calcite
fill 51 270 598 54 270 598 minecraft:cobbled_deepslate
fill 53 270 597 55 270 597 minecraft:cobbled_deepslate
setblock 55 270 598 minecraft:calcite
setblock 56 270 596 minecraft:cobbled_deepslate
setblock 56 270 597 minecraft:calcite
fill 56 270 598 56 273 598 minecraft:cobbled_deepslate
setblock 57 270 596 minecraft:calcite
fill 57 270 597 57 273 597 minecraft:cobbled_deepslate
fill 58 270 558 59 270 558 minecraft:cobbled_deepslate
fill 58 270 596 59 272 596 minecraft:cobbled_deepslate
fill 59 270 597 60 270 597 minecraft:cobbled_deepslate
setblock 60 270 558 minecraft:calcite
setblock 60 270 598 minecraft:calcite
setblock 61 270 597 minecraft:calcite
fill 61 270 598 61 273 598 minecraft:cobbled_deepslate
setblock 75 270 558 minecraft:calcite
setblock 75 270 598 minecraft:calcite
fill 76 270 558 76 273 558 minecraft:cobbled_deepslate
setblock 76 270 597 minecraft:calcite
fill 76 270 598 76 273 598 minecraft:cobbled_deepslate
fill 77 270 597 80 270 597 minecraft:cobbled_deepslate
setblock 78 270 560 minecraft:calcite
setblock 79 270 559 minecraft:calcite
fill 79 270 560 79 271 560 minecraft:cobbled_deepslate
fill 79 270 596 81 270 596 minecraft:cobbled_deepslate
setblock 80 270 558 minecraft:calcite
fill 80 270 559 80 273 559 minecraft:cobbled_deepslate
setblock 80 270 598 minecraft:calcite
fill 81 270 558 81 273 558 minecraft:cobbled_deepslate
setblock 81 270 597 minecraft:calcite
fill 81 270 598 81 273 598 minecraft:cobbled_deepslate
setblock 82 270 596 minecraft:calcite
fill 82 270 597 82 273 597 minecraft:cobbled_deepslate
fill 83 270 596 83 272 596 minecraft:cobbled_deepslate
setblock 84 270 559 minecraft:calcite
setblock 85 270 558 minecraft:calcite
setblock 85 270 598 minecraft:calcite
fill 86 270 558 86 272 558 minecraft:cobbled_deepslate
setblock 86 270 597 minecraft:calcite
fill 86 270 598 86 273 598 minecraft:cobbled_deepslate
setblock 87 270 591 minecraft:calcite
fill 87 270 592 87 273 592 minecraft:cobbled_deepslate
setblock 87 270 596 minecraft:calcite
fill 87 270 597 87 273 597 minecraft:cobbled_deepslate
setblock 88 270 565 minecraft:calcite
fill 88 270 566 88 271 566 minecraft:cobbled_deepslate
setblock 88 270 570 minecraft:calcite
fill 88 270 571 88 271 571 minecraft:cobbled_deepslate
setblock 88 270 590 minecraft:calcite
fill 88 270 591 88 273 591 minecraft:cobbled_deepslate
setblock 88 270 595 minecraft:calcite
fill 88 270 596 88 273 596 minecraft:cobbled_deepslate
setblock 48 271 585 minecraft:cobbled_deepslate
setblock 48 271 589 minecraft:calcite
fill 48 271 590 48 273 590 minecraft:cobbled_deepslate
setblock 48 271 594 minecraft:calcite
fill 48 271 595 48 273 595 minecraft:cobbled_deepslate
setblock 48 271 598 minecraft:cobbled_deepslate
setblock 49 271 588 minecraft:calcite
fill 49 271 589 49 273 589 minecraft:cobbled_deepslate
setblock 49 271 593 minecraft:calcite
fill 49 271 594 49 273 594 minecraft:cobbled_deepslate
setblock 49 271 598 minecraft:calcite
setblock 50 271 592 minecraft:calcite
fill 50 271 593 50 272 593 minecraft:cobbled_deepslate
fill 50 271 598 53 271 598 minecraft:cobbled_deepslate
fill 52 271 597 54 271 597 minecraft:cobbled_deepslate
setblock 54 271 598 minecraft:calcite
setblock 55 271 596 minecraft:cobbled_deepslate
setblock 55 271 597 minecraft:calcite
fill 55 271 598 55 273 598 minecraft:cobbled_deepslate
setblock 56 271 596 minecraft:calcite
fill 56 271 597 56 273 597 minecraft:cobbled_deepslate
fill 57 271 596 57 273 596 minecraft:cobbled_deepslate
setblock 58 271 558 minecraft:cobbled_deepslate
setblock 59 271 558 minecraft:calcite
setblock 59 271 597 minecraft:cobbled_deepslate
setblock 59 271 598 minecraft:calcite
setblock 60 271 597 minecraft:calcite
fill 60 271 598 60 273 598 minecraft:cobbled_deepslate
fill 61 271 597 61 272 597 minecraft:cobbled_deepslate
setblock 73 271 558 minecraft:cobbled_deepslate
setblock 74 271 558 minecraft:calcite
setblock 74 271 598 minecraft:calcite
fill 75 271 558 75 273 559 minecraft:cobbled_deepslate
setblock 75 271 597 minecraft:calcite
fill 75 271 598 75 273 598 minecraft:cobbled_deepslate
fill 76 271 597 79 271 597 minecraft:cobbled_deepslate
setblock 78 271 559 minecraft:calcite
setblock 78 271 560 minecraft:cobbled_deepslate
fill 78 271 596 80 271 596 minecraft:cobbled_deepslate
setblock 79 271 558 minecraft:calcite
fill 79 271 559 79 273 559 minecraft:cobbled_deepslate
setblock 79 271 598 minecraft:calcite
fill 80 271 558 80 273 558 minecraft:cobbled_deepslate
setblock 80 271 597 minecraft:calcite
fill 80 271 598 80 273 598 minecraft:cobbled_deepslate
setblock 81 271 596 minecraft:calcite
fill 81 271 597 81 273 597 minecraft:cobbled_deepslate
fill 82 271 596 82 273 596 minecraft:cobbled_deepslate
setblock 83 271 559 minecraft:calcite
setblock 84 271 558 minecraft:calcite
setblock 84 271 597 minecraft:cobbled_deepslate
setblock 84 271 598 minecraft:calcite
fill 85 271 558 85 273 558 minecraft:cobbled_deepslate
fill 85 271 589 85 273 589 minecraft:deepslate
fill 85 271 591 85 273 591 minecraft:deepslate
setblock 85 271 597 minecraft:calcite
fill 85 271 598 85 273 598 minecraft:cobbled_deepslate
fill 86 271 597 86 273 597 minecraft:cobbled_deepslate
fill 87 271 589 87 273 589 minecraft:deepslate
setblock 87 271 590 minecraft:calcite
fill 87 271 591 87 272 591 minecraft:cobbled_deepslate
setblock 87 271 594 minecraft:cobbled_deepslate
setblock 87 271 595 minecraft:calcite
fill 87 271 596 87 273 596 minecraft:cobbled_deepslate
setblock 88 271 569 minecraft:calcite
setblock 88 271 570 minecraft:cobbled_deepslate
setblock 88 271 589 minecraft:calcite
fill 88 271 590 88 273 590 minecraft:cobbled_deepslate
setblock 88 271 594 minecraft:calcite
fill 88 271 595 88 273 595 minecraft:cobbled_deepslate
setblock 48 272 588 minecraft:calcite
fill 48 272 589 48 273 589 minecraft:cobbled_deepslate
setblock 48 272 593 minecraft:calcite
fill 48 272 594 48 273 594 minecraft:cobbled_deepslate
setblock 48 272 598 minecraft:calcite
setblock 49 272 588 minecraft:cobbled_deepslate
setblock 49 272 592 minecraft:calcite
fill 49 272 593 49 273 593 minecraft:cobbled_deepslate
fill 49 272 598 52 272 598 minecraft:cobbled_deepslate
setblock 50 272 591 minecraft:calcite
setblock 50 272 592 minecraft:cobbled_deepslate
fill 51 272 597 53 272 597 minecraft:cobbled_deepslate
setblock 53 272 598 minecraft:calcite
setblock 54 272 596 minecraft:cobbled_deepslate
setblock 54 272 597 minecraft:calcite
fill 54 272 598 54 273 598 minecraft:cobbled_deepslate
setblock 55 272 596 minecraft:calcite
fill 55 272 597 55 273 597 minecraft:cobbled_deepslate
fill 56 272 596 56 273 596 minecraft:cobbled_deepslate
setblock 58 272 598 minecraft:calcite
setblock 59 272 597 minecraft:calcite
fill 59 272 598 59 273 598 minecraft:cobbled_deepslate
fill 60 272 597 60 273 597 minecraft:cobbled_deepslate
setblock 73 272 558 minecraft:calcite
setblock 73 272 598 minecraft:calcite
fill 74 272 558 74 273 558 minecraft:cobbled_deepslate
fill 74 272 598 74 273 598 minecraft:cobbled_deepslate
fill 75 272 597 78 272 597 minecraft:cobbled_deepslate
setblock 77 272 559 minecraft:calcite
fill 77 272 596 79 272 596 minecraft:cobbled_deepslate
setblock 78 272 558 minecraft:calcite
fill 78 272 559 78 273 559 minecraft:cobbled_deepslate
setblock 78 272 598 minecraft:calcite
fill 79 272 558 79 273 558 minecraft:cobbled_deepslate
setblock 79 272 597 minecraft:calcite
fill 79 272 598 79 273 598 minecraft:cobbled_deepslate
setblock 80 272 596 minecraft:calcite
fill 80 272 597 80 273 597 minecraft:cobbled_deepslate
fill 81 272 596 81 273 596 minecraft:cobbled_deepslate
setblock 82 272 559 minecraft:calcite
setblock 83 272 558 minecraft:calcite
setblock 83 272 598 minecraft:calcite
fill 84 272 558 84 273 558 minecraft:cobbled_deepslate
setblock 84 272 597 minecraft:calcite
fill 84 272 598 84 273 598 minecraft:cobbled_deepslate
fill 85 272 597 85 273 597 minecraft:cobbled_deepslate
fill 87 272 590 87 273 590 minecraft:deepslate
setblock 87 272 594 minecraft:calcite
fill 87 272 595 87 273 595 minecraft:cobbled_deepslate
setblock 88 272 588 minecraft:calcite
fill 88 272 589 88 273 589 minecraft:cobbled_deepslate
setblock 88 272 593 minecraft:calcite
fill 88 272 594 88 273 594 minecraft:cobbled_deepslate
setblock 88 272 598 minecraft:calcite
setblock 48 273 587 minecraft:calcite
setblock 48 273 588 minecraft:cobbled_deepslate
setblock 48 273 592 minecraft:calcite
setblock 48 273 593 minecraft:cobbled_deepslate
setblock 48 273 597 minecraft:calcite
fill 48 273 598 51 273 598 minecraft:cobbled_deepslate
setblock 49 273 591 minecraft:calcite
setblock 49 273 592 minecraft:cobbled_deepslate
setblock 49 273 596 minecraft:calcite
fill 51 273 597 52 273 597 minecraft:cobbled_deepslate
setblock 52 273 598 minecraft:calcite
setblock 53 273 597 minecraft:calcite
setblock 53 273 598 minecraft:cobbled_deepslate
setblock 54 273 596 minecraft:calcite
setblock 54 273 597 minecraft:cobbled_deepslate
setblock 55 273 596 minecraft:cobbled_deepslate
setblock 57 273 598 minecraft:calcite
setblock 58 273 596 minecraft:cobbled_deepslate
setblock 58 273 597 minecraft:calcite
setblock 58 273 598 minecraft:cobbled_deepslate
setblock 59 273 597 minecraft:cobbled_deepslate
setblock 62 273 598 minecraft:calcite
setblock 72 273 558 minecraft:calcite
setblock 72 273 598 minecraft:calcite
setblock 73 273 558 minecraft:cobbled_deepslate
setblock 73 273 598 minecraft:cobbled_deepslate
fill 74 273 597 77 273 597 minecraft:cobbled_deepslate
setblock 76 273 559 minecraft:calcite
setblock 77 273 558 minecraft:calcite
setblock 77 273 559 minecraft:cobbled_deepslate
fill 77 273 596 78 273 596 minecraft:cobbled_deepslate
setblock 77 273 598 minecraft:calcite
setblock 78 273 558 minecraft:cobbled_deepslate
setblock 78 273 597 minecraft:calcite
setblock 78 273 598 minecraft:cobbled_deepslate
setblock 79 273 596 minecraft:calcite
setblock 79 273 597 minecraft:cobbled_deepslate
setblock 80 273 596 minecraft:cobbled_deepslate
setblock 81 273 559 minecraft:calcite
setblock 82 273 558 minecraft:calcite
setblock 82 273 598 minecraft:calcite
setblock 83 273 558 minecraft:cobbled_deepslate
setblock 83 273 597 minecraft:calcite
setblock 83 273 598 minecraft:cobbled_deepslate
setblock 84 273 597 minecraft:cobbled_deepslate
setblock 87 273 591 minecraft:deepslate
setblock 87 273 593 minecraft:calcite
setblock 87 273 594 minecraft:cobbled_deepslate
setblock 87 273 598 minecraft:calcite
setblock 88 273 592 minecraft:calcite
setblock 88 273 593 minecraft:cobbled_deepslate
setblock 88 273 597 minecraft:calcite
setblock 88 273 598 minecraft:cobbled_deepslate
setblock 50 276 560 minecraft:light[level=14]
setblock 50 276 568 minecraft:light[level=14]
setblock 50 276 576 minecraft:light[level=14]
setblock 50 276 584 minecraft:light[level=14]
setblock 50 276 592 minecraft:light[level=14]
setblock 58 276 560 minecraft:light[level=14]
setblock 58 276 568 minecraft:light[level=14]
setblock 58 276 576 minecraft:light[level=14]
setblock 58 276 584 minecraft:light[level=14]
setblock 58 276 592 minecraft:light[level=14]
setblock 66 276 560 minecraft:light[level=14]
setblock 66 276 568 minecraft:light[level=14]
setblock 66 276 576 minecraft:light[level=14]
setblock 66 276 584 minecraft:light[level=14]
setblock 66 276 592 minecraft:light[level=14]
setblock 74 276 560 minecraft:light[level=14]
setblock 74 276 568 minecraft:light[level=14]
setblock 74 276 576 minecraft:light[level=14]
setblock 74 276 584 minecraft:light[level=14]
setblock 74 276 592 minecraft:light[level=14]
setblock 82 276 560 minecraft:light[level=14]
setblock 82 276 568 minecraft:light[level=14]
setblock 82 276 576 minecraft:light[level=14]
setblock 82 276 584 minecraft:light[level=14]
setblock 82 276 592 minecraft:light[level=14]
fill 51 279 577 68 279 577 minecraft:smooth_basalt
fill 52 279 571 69 279 576 minecraft:smooth_basalt
fill 52 279 578 69 279 583 minecraft:smooth_basalt
fill 53 279 569 89 279 570 minecraft:smooth_basalt
fill 53 279 584 89 279 585 minecraft:smooth_basalt
fill 54 279 567 88 279 568 minecraft:smooth_basalt
fill 54 279 586 88 279 587 minecraft:smooth_basalt
fill 55 279 565 87 279 566 minecraft:smooth_basalt
fill 55 279 588 87 279 589 minecraft:smooth_basalt
fill 56 279 564 86 279 564 minecraft:smooth_basalt
fill 56 279 590 86 279 590 minecraft:smooth_basalt
fill 57 279 563 85 279 563 minecraft:smooth_basalt
fill 57 279 591 85 279 591 minecraft:smooth_basalt
fill 58 279 562 84 279 562 minecraft:smooth_basalt
fill 58 279 592 84 279 592 minecraft:smooth_basalt
fill 59 279 561 83 279 561 minecraft:smooth_basalt
fill 59 279 593 83 279 593 minecraft:smooth_basalt
fill 61 279 560 81 279 560 minecraft:smooth_basalt
fill 61 279 594 81 279 594 minecraft:smooth_basalt
fill 63 279 559 79 279 559 minecraft:smooth_basalt
fill 63 279 595 79 279 595 minecraft:smooth_basalt
fill 65 279 558 77 279 558 minecraft:smooth_basalt
fill 65 279 596 77 279 596 minecraft:smooth_basalt
fill 70 279 571 70 279 575 minecraft:smooth_basalt
fill 70 279 579 70 279 583 minecraft:smooth_basalt
fill 71 279 557 71 286 557 minecraft:smooth_basalt
fill 71 279 571 89 279 574 minecraft:smooth_basalt
fill 71 279 580 89 279 583 minecraft:smooth_basalt
fill 71 279 597 71 286 597 minecraft:smooth_basalt
fill 72 279 575 89 279 575 minecraft:smooth_basalt
fill 72 279 579 89 279 579 minecraft:smooth_basalt
fill 73 279 576 89 279 576 minecraft:smooth_basalt
fill 73 279 578 89 279 578 minecraft:smooth_basalt
fill 74 279 577 89 279 577 minecraft:smooth_basalt
fill 89 279 563 89 307 568 minecraft:deepslate
fill 89 279 586 89 307 586 minecraft:deepslate
fill 48 280 558 50 280 598 minecraft:deepslate
fill 51 280 558 51 280 576 minecraft:deepslate
fill 51 280 577 65 282 577 minecraft:smooth_basalt
fill 51 280 578 51 280 598 minecraft:deepslate
fill 52 280 558 52 280 570 minecraft:deepslate
fill 52 280 571 52 286 576 minecraft:smooth_basalt
fill 52 280 578 53 286 583 minecraft:smooth_basalt
fill 52 280 584 52 280 598 minecraft:deepslate
fill 53 280 558 53 280 568 minecraft:deepslate
fill 53 280 569 53 286 574 minecraft:smooth_basalt
fill 53 280 575 53 286 575 minecraft:calcite
fill 53 280 576 63 282 576 minecraft:smooth_basalt
fill 53 280 584 53 286 584 minecraft:calcite
fill 53 280 585 71 282 585 minecraft:smooth_basalt
fill 53 280 586 53 280 598 minecraft:deepslate
fill 54 280 558 54 280 566 minecraft:deepslate
fill 54 280 567 55 286 573 minecraft:smooth_basalt
fill 54 280 574 55 286 574 minecraft:calcite
fill 54 280 575 66 281 575 minecraft:smooth_basalt
fill 54 280 578 54 286 582 minecraft:smooth_basalt
fill 54 280 583 54 286 583 minecraft:calcite
fill 54 280 584 59 285 584 minecraft:smooth_basalt
fill 54 280 586 58 286 587 minecraft:smooth_basalt
fill 54 280 588 54 280 598 minecraft:deepslate
fill 55 280 558 55 280 564 minecraft:deepslate
fill 55 280 565 66 284 566 minecraft:smooth_basalt
fill 55 280 578 55 286 580 minecraft:smooth_basalt
fill 55 280 581 55 286 581 minecraft:calcite
fill 55 280 582 60 284 583 minecraft:smooth_basalt
fill 55 280 588 57 286 589 minecraft:smooth_basalt
fill 55 280 590 55 280 598 minecraft:deepslate
fill 56 280 558 56 280 563 minecraft:deepslate
fill 56 280 564 65 285 564 minecraft:smooth_basalt
fill 56 280 567 58 286 567 minecraft:calcite
fill 56 280 568 56 285 574 minecraft:smooth_basalt
fill 56 280 578 56 285 579 minecraft:smooth_basalt
fill 56 280 580 56 285 580 minecraft:calcite
fill 56 280 581 61 284 581 minecraft:smooth_basalt
fill 56 280 590 57 286 590 minecraft:smooth_basalt
fill 56 280 591 56 280 598 minecraft:deepslate
fill 57 280 558 57 280 562 minecraft:deepslate
fill 57 280 563 71 285 563 minecraft:smooth_basalt
fill 57 280 568 61 284 572 minecraft:smooth_basalt
fill 57 280 573 58 285 573 minecraft:calcite
fill 57 280 574 66 282 574 minecraft:smooth_basalt
fill 57 280 578 58 284 578 minecraft:smooth_basalt
fill 57 280 579 57 285 579 minecraft:calcite
fill 57 280 580 62 283 580 minecraft:smooth_basalt
fill 57 280 591 57 286 591 minecraft:smooth_basalt
fill 57 280 592 57 280 598 minecraft:deepslate
fill 58 280 558 58 280 561 minecraft:deepslate
fill 58 280 562 61 286 562 minecraft:smooth_basalt
fill 58 280 579 66 281 579 minecraft:smooth_basalt
fill 58 280 588 63 285 588 minecraft:smooth_basalt
fill 58 280 589 58 286 592 minecraft:calcite
fill 58 280 593 58 280 598 minecraft:deepslate
fill 59 280 558 60 280 560 minecraft:deepslate
fill 59 280 561 60 286 561 minecraft:calcite
fill 59 280 567 68 283 567 minecraft:smooth_basalt
fill 59 280 573 64 282 573 minecraft:smooth_basalt
fill 59 280 578 59 284 578 minecraft:calcite
fill 59 280 586 59 285 586 minecraft:calcite
fill 59 280 587 63 284 587 minecraft:smooth_basalt
fill 59 280 589 63 285 593 minecraft:smooth_basalt
fill 59 280 594 60 280 598 minecraft:deepslate
fill 60 280 578 65 282 578 minecraft:smooth_basalt
fill 60 280 584 60 284 584 minecraft:calcite
fill 60 280 586 78 283 586 minecraft:smooth_basalt
fill 61 280 558 62 280 559 minecraft:deepslate
fill 61 280 560 69 286 561 minecraft:smooth_basalt
fill 61 280 582 61 284 582 minecraft:calcite
fill 61 280 583 89 282 584 minecraft:smooth_basalt
fill 61 280 594 64 286 594 minecraft:smooth_basalt
fill 61 280 595 62 280 598 minecraft:deepslate
fill 62 280 562 63 286 562 minecraft:calcite
fill 62 280 568 63 284 568 minecraft:calcite
fill 62 280 569 64 283 572 minecraft:smooth_basalt
fill 62 280 581 62 283 581 minecraft:calcite
fill 62 280 582 69 281 582 minecraft:smooth_basalt
fill 63 280 558 64 280 558 minecraft:deepslate
fill 63 280 559 68 286 559 minecraft:smooth_basalt
fill 63 280 580 63 283 580 minecraft:calcite
fill 63 280 581 67 281 581 minecraft:smooth_basalt
fill 63 280 595 64 286 595 minecraft:smooth_basalt
fill 63 280 596 64 280 598 minecraft:deepslate
fill 64 280 562 83 285 562 minecraft:smooth_basalt
fill 64 280 568 82 283 568 minecraft:smooth_basalt
fill 64 280 576 64 282 576 minecraft:calcite
fill 64 280 580 66 282 580 minecraft:smooth_basalt
fill 64 280 587 64 284 591 minecraft:calcite
fill 64 280 592 70 285 593 minecraft:smooth_basalt
fill 65 280 558 67 286 558 minecraft:smooth_basalt
fill 65 280 569 65 283 569 minecraft:calcite
fill 65 280 570 69 281 572 minecraft:smooth_basalt
fill 65 280 573 65 282 573 minecraft:calcite
fill 65 280 576 65 282 576 minecraft:smooth_basalt
fill 65 280 587 68 283 591 minecraft:smooth_basalt
fill 65 280 594 65 286 595 minecraft:calcite
fill 65 280 596 73 286 596 minecraft:smooth_basalt
fill 65 280 597 70 280 598 minecraft:deepslate
fill 66 280 564 66 285 564 minecraft:calcite
fill 66 280 569 69 282 569 minecraft:smooth_basalt
fill 66 280 573 67 281 573 minecraft:smooth_basalt
fill 66 280 576 67 281 578 minecraft:diamond_block
fill 66 280 594 71 286 595 minecraft:smooth_basalt
fill 67 280 564 77 284 564 minecraft:smooth_basalt
fill 67 280 565 67 284 565 minecraft:calcite
fill 67 280 566 67 284 566 minecraft:smooth_basalt
fill 67 280 574 68 281 575 minecraft:diamond_block
fill 67 280 579 68 281 580 minecraft:diamond_block
fill 68 280 558 68 287 558 minecraft:calcite
fill 68 280 565 72 284 565 minecraft:smooth_basalt
fill 68 280 566 68 284 566 minecraft:calcite
fill 68 280 573 74 281 573 minecraft:diamond_block
fill 68 280 576 68 280 578 minecraft:sea_lantern
fill 68 280 581 74 281 581 minecraft:diamond_block
fill 69 280 558 77 286 558 minecraft:smooth_basalt
fill 69 280 559 69 286 559 minecraft:calcite
fill 69 280 566 72 284 566 minecraft:smooth_basalt
fill 69 280 567 69 283 567 minecraft:calcite
fill 69 280 574 69 281 574 minecraft:diamond_block
fill 69 280 575 69 280 576 minecraft:sea_lantern
fill 69 280 578 69 280 579 minecraft:sea_lantern
fill 69 280 580 69 281 580 minecraft:diamond_block
fill 69 280 587 72 283 587 minecraft:smooth_basalt
fill 69 280 588 69 284 589 minecraft:calcite
fill 69 280 590 69 284 591 minecraft:smooth_basalt
fill 70 280 559 76 286 559 minecraft:smooth_basalt
fill 70 280 560 70 286 560 minecraft:calcite
fill 70 280 561 70 286 561 minecraft:smooth_basalt
fill 70 280 567 77 283 567 minecraft:smooth_basalt
fill 70 280 569 70 282 569 minecraft:calcite
fill 70 280 570 81 282 571 minecraft:smooth_basalt
fill 70 280 572 72 281 572 minecraft:diamond_block
fill 70 280 574 70 280 575 minecraft:sea_lantern
fill 70 280 579 70 280 580 minecraft:sea_lantern
fill 70 280 582 72 281 582 minecraft:diamond_block
fill 70 280 588 73 284 590 minecraft:smooth_basalt
fill 70 280 591 70 285 591 minecraft:calcite
fill 71 280 560 76 286 560 minecraft:smooth_basalt
fill 71 280 561 71 286 561 minecraft:calcite
fill 71 280 569 89 282 569 minecraft:smooth_basalt
fill 71 280 574 72 280 574 minecraft:sea_lantern
fill 71 280 580 72 280 580 minecraft:sea_lantern
fill 71 280 591 78 285 592 minecraft:smooth_basalt
fill 71 280 593 71 286 593 minecraft:calcite
fill 71 280 598 88 280 598 minecraft:deepslate
fill 72 280 561 83 286 561 minecraft:smooth_basalt
fill 72 280 563 72 285 563 minecraft:calcite
fill 72 280 575 73 280 575 minecraft:sea_lantern
fill 72 280 579 73 280 579 minecraft:sea_lantern
fill 72 280 585 72 282 585 minecraft:calcite
fill 72 280 593 81 286 593 minecraft:smooth_basalt
fill 72 280 594 72 286 594 minecraft:calcite
fill 72 280 595 72 286 595 minecraft:smooth_basalt
fill 72 280 597 88 280 597 minecraft:deepslate
fill 73 280 563 77 285 563 minecraft:smooth_basalt
fill 73 280 565 73 284 566 minecraft:calcite
fill 73 280 572 80 281 572 minecraft:smooth_basalt
fill 73 280 574 75 281 574 minecraft:diamond_block
fill 73 280 576 74 280 576 minecraft:sea_lantern
fill 73 280 578 74 280 578 minecraft:sea_lantern
fill 73 280 580 75 281 580 minecraft:diamond_block
fill 73 280 582 89 281 582 minecraft:smooth_basalt
fill 73 280 585 76 282 585 minecraft:smooth_basalt
fill 73 280 587 73 283 587 minecraft:calcite
fill 73 280 594 81 286 594 minecraft:smooth_basalt
fill 73 280 595 73 286 595 minecraft:calcite
fill 74 280 565 77 284 566 minecraft:smooth_basalt
fill 74 280 575 75 281 575 minecraft:diamond_block
setblock 74 280 577 minecraft:sea_lantern
fill 74 280 579 75 281 579 minecraft:diamond_block
fill 74 280 587 83 283 587 minecraft:smooth_basalt
fill 74 280 588 74 284 588 minecraft:calcite
fill 74 280 589 74 284 590 minecraft:smooth_basalt
fill 74 280 595 79 286 595 minecraft:smooth_basalt
fill 74 280 596 74 286 596 minecraft:calcite
fill 75 280 573 79 281 573 minecraft:smooth_basalt
fill 75 280 576 76 281 578 minecraft:diamond_block
fill 75 280 581 76 281 581 minecraft:smooth_basalt
fill 75 280 588 87 284 588 minecraft:smooth_basalt
fill 75 280 589 75 284 589 minecraft:calcite
fill 75 280 590 75 285 590 minecraft:smooth_basalt
fill 75 280 596 77 286 596 minecraft:smooth_basalt
fill 76 280 574 78 281 575 minecraft:smooth_basalt
fill 76 280 579 86 281 580 minecraft:smooth_basalt
fill 76 280 589 87 284 589 minecraft:smooth_basalt
fill 76 280 590 76 285 590 minecraft:calcite
fill 77 280 559 77 286 560 minecraft:calcite
fill 77 280 576 77 282 578 minecraft:smooth_basalt
fill 77 280 581 77 282 581 minecraft:calcite
fill 77 280 585 77 283 585 minecraft:calcite
fill 77 280 590 86 285 590 minecraft:smooth_basalt
fill 78 280 558 88 280 558 minecraft:deepslate
fill 78 280 559 79 286 560 minecraft:smooth_basalt
fill 78 280 563 78 284 567 minecraft:calcite
fill 78 280 576 82 282 577 minecraft:smooth_basalt
fill 78 280 578 78 282 578 minecraft:calcite
fill 78 280 581 83 282 581 minecraft:smooth_basalt
fill 78 280 585 89 283 585 minecraft:smooth_basalt
fill 78 280 596 88 280 596 minecraft:deepslate
fill 79 280 563 83 284 567 minecraft:smooth_basalt
fill 79 280 574 79 283 574 minecraft:calcite
fill 79 280 575 84 282 575 minecraft:smooth_basalt
fill 79 280 578 89 282 578 minecraft:smooth_basalt
fill 79 280 586 80 284 586 minecraft:calcite
fill 79 280 591 85 286 591 minecraft:smooth_basalt
fill 79 280 592 80 286 592 minecraft:calcite
fill 80 280 559 88 280 559 minecraft:deepslate
fill 80 280 560 81 286 560 minecraft:smooth_basalt
fill 80 280 573 80 283 573 minecraft:calcite
fill 80 280 574 85 283 574 minecraft:smooth_basalt
fill 80 280 595 88 280 595 minecraft:deepslate
fill 81 280 572 81 284 572 minecraft:calcite
fill 81 280 573 86 284 573 minecraft:smooth_basalt
fill 81 280 586 88 285 586 minecraft:smooth_basalt
fill 81 280 592 84 286 592 minecraft:smooth_basalt
fill 82 280 560 88 280 560 minecraft:deepslate
fill 82 280 570 82 284 570 minecraft:calcite
fill 82 280 571 87 284 572 minecraft:smooth_basalt
fill 82 280 593 83 286 593 minecraft:calcite
fill 82 280 594 88 280 594 minecraft:deepslate
fill 83 280 568 83 285 568 minecraft:calcite
fill 83 280 570 88 285 570 minecraft:smooth_basalt
fill 83 280 576 83 284 576 minecraft:calcite
fill 83 280 577 89 284 577 minecraft:smooth_basalt
fill 84 280 561 88 280 561 minecraft:deepslate
fill 84 280 562 84 286 565 minecraft:calcite
fill 84 280 566 87 286 568 minecraft:smooth_basalt
fill 84 280 576 89 284 576 minecraft:smooth_basalt
fill 84 280 581 85 285 581 minecraft:calcite
fill 84 280 587 86 286 587 minecraft:calcite
fill 84 280 593 88 280 593 minecraft:deepslate
fill 85 280 562 88 280 562 minecraft:deepslate
fill 85 280 563 85 286 565 minecraft:smooth_basalt
fill 85 280 575 85 285 575 minecraft:calcite
fill 85 280 592 88 280 592 minecraft:deepslate
fill 86 280 563 88 280 563 minecraft:deepslate
fill 86 280 564 86 286 565 minecraft:smooth_basalt
fill 86 280 574 86 285 574 minecraft:calcite
fill 86 280 575 89 285 575 minecraft:smooth_basalt
fill 86 280 581 89 285 581 minecraft:smooth_basalt
fill 86 280 591 88 280 591 minecraft:deepslate
fill 87 280 564 88 280 564 minecraft:deepslate
fill 87 280 565 87 286 565 minecraft:smooth_basalt
fill 87 280 573 87 286 573 minecraft:calcite
fill 87 280 574 89 286 574 minecraft:smooth_basalt
fill 87 280 579 88 286 579 minecraft:smooth_basalt
fill 87 280 580 88 286 580 minecraft:calcite
fill 87 280 587 88 286 587 minecraft:smooth_basalt
fill 87 280 590 88 280 590 minecraft:deepslate
fill 88 280 565 88 280 566 minecraft:deepslate
fill 88 280 567 88 286 568 minecraft:smooth_basalt
fill 88 280 571 88 286 571 minecraft:calcite
fill 88 280 572 89 286 573 minecraft:smooth_basalt
fill 88 280 588 88 280 589 minecraft:deepslate
fill 89 280 570 89 286 570 minecraft:calcite
fill 89 280 571 89 286 571 minecraft:smooth_basalt
fill 89 280 579 89 286 579 minecraft:calcite
fill 89 280 580 89 286 580 minecraft:smooth_basalt
fill 54 282 575 65 282 575 minecraft:smooth_basalt
fill 58 282 579 65 282 579 minecraft:smooth_basalt
fill 62 282 582 68 282 582 minecraft:smooth_basalt
fill 63 282 581 66 282 581 minecraft:smooth_basalt
fill 65 282 570 68 282 572 minecraft:smooth_basalt
setblock 66 282 573 minecraft:smooth_basalt
fill 69 282 570 69 282 571 minecraft:smooth_basalt
fill 74 282 572 80 282 572 minecraft:smooth_basalt
fill 74 282 582 89 282 582 minecraft:smooth_basalt
fill 76 282 573 78 282 574 minecraft:smooth_basalt
fill 76 282 580 76 282 581 minecraft:smooth_basalt
fill 77 282 575 78 282 575 minecraft:smooth_basalt
fill 77 282 579 86 282 580 minecraft:smooth_basalt
fill 79 282 573 79 283 573 minecraft:smooth_basalt
fill 51 283 577 62 283 577 minecraft:smooth_basalt
fill 53 283 576 62 283 576 minecraft:smooth_basalt
fill 53 283 585 68 283 585 minecraft:smooth_basalt
fill 54 283 575 62 283 575 minecraft:smooth_basalt
fill 57 283 574 63 283 574 minecraft:smooth_basalt
fill 58 283 579 62 283 579 minecraft:smooth_basalt
fill 59 283 573 63 283 573 minecraft:smooth_basalt
fill 60 283 578 62 283 578 minecraft:smooth_basalt
fill 61 283 583 65 283 584 minecraft:smooth_basalt
fill 62 283 582 64 283 582 minecraft:smooth_basalt
setblock 63 283 581 minecraft:smooth_basalt
fill 65 283 570 65 283 571 minecraft:smooth_basalt
fill 66 283 569 66 283 570 minecraft:smooth_basalt
setblock 66 283 584 minecraft:smooth_basalt
fill 67 283 569 68 283 569 minecraft:smooth_basalt
fill 74 283 569 89 283 569 minecraft:smooth_basalt
fill 74 283 585 76 283 585 minecraft:smooth_basalt
fill 76 283 570 81 283 570 minecraft:smooth_basalt
fill 76 283 584 89 283 584 minecraft:smooth_basalt
fill 77 283 571 81 283 571 minecraft:smooth_basalt
fill 77 283 583 89 283 583 minecraft:smooth_basalt
fill 78 283 572 80 283 572 minecraft:smooth_basalt
fill 78 283 582 89 283 582 minecraft:smooth_basalt
fill 79 283 580 83 283 581 minecraft:smooth_basalt
fill 80 283 575 82 283 579 minecraft:smooth_basalt
fill 83 283 575 84 284 575 minecraft:smooth_basalt
fill 83 283 578 86 284 579 minecraft:smooth_basalt
fill 84 283 580 86 285 580 minecraft:smooth_basalt
fill 87 283 578 89 286 578 minecraft:smooth_basalt
fill 48 284 558 48 284 560 minecraft:cobbled_deepslate
setblock 48 284 561 minecraft:calcite
fill 48 284 562 48 284 565 minecraft:cobbled_deepslate
setblock 48 284 566 minecraft:calcite
fill 48 284 567 48 284 570 minecraft:cobbled_deepslate
setblock 48 284 571 minecraft:calcite
fill 48 284 572 48 284 575 minecraft:cobbled_deepslate
setblock 48 284 576 minecraft:calcite
fill 48 284 577 48 284 580 minecraft:cobbled_deepslate
setblock 48 284 581 minecraft:calcite
fill 48 284 582 48 284 585 minecraft:cobbled_deepslate
setblock 48 284 586 minecraft:calcite
fill 48 284 587 48 284 590 minecraft:cobbled_deepslate
setblock 48 284 591 minecraft:calcite
fill 48 284 592 48 284 595 minecraft:cobbled_deepslate
setblock 48 284 596 minecraft:calcite
fill 48 284 597 50 284 598 minecraft:cobbled_deepslate
fill 49 284 558 49 284 559 minecraft:cobbled_deepslate
setblock 49 284 560 minecraft:calcite
fill 49 284 561 49 284 564 minecraft:cobbled_deepslate
fill 49 284 571 49 284 574 minecraft:cobbled_deepslate
setblock 49 284 575 minecraft:calcite
fill 49 284 576 49 284 579 minecraft:cobbled_deepslate
setblock 49 284 580 minecraft:calcite
fill 49 284 581 49 284 584 minecraft:cobbled_deepslate
setblock 49 284 585 minecraft:calcite
fill 49 284 586 49 284 589 minecraft:cobbled_deepslate
setblock 49 284 590 minecraft:calcite
fill 49 284 591 49 284 594 minecraft:cobbled_deepslate
setblock 49 284 595 minecraft:calcite
fill 49 284 596 49 286 596 minecraft:cobbled_deepslate
setblock 50 284 558 minecraft:cobbled_deepslate
setblock 50 284 559 minecraft:calcite
fill 50 284 560 53 284 560 minecraft:cobbled_deepslate
setblock 50 284 568 minecraft:light[level=14]
setblock 50 284 573 minecraft:cobbled_deepslate
setblock 50 284 574 minecraft:calcite
fill 50 284 575 50 284 578 minecraft:cobbled_deepslate
setblock 50 284 579 minecraft:calcite
fill 50 284 580 50 284 583 minecraft:cobbled_deepslate
setblock 50 284 584 minecraft:calcite
fill 50 284 585 50 284 588 minecraft:cobbled_deepslate
setblock 50 284 592 minecraft:light[level=14]
setblock 51 284 558 minecraft:calcite
fill 51 284 559 54 284 559 minecraft:cobbled_deepslate
fill 51 284 575 51 285 576 minecraft:cobbled_deepslate
fill 51 284 577 60 284 577 minecraft:smooth_basalt
setblock 51 284 578 minecraft:calcite
fill 51 284 579 51 284 582 minecraft:cobbled_deepslate
setblock 51 284 583 minecraft:calcite
fill 51 284 584 51 286 585 minecraft:cobbled_deepslate
setblock 51 284 597 minecraft:cobbled_deepslate
setblock 51 284 598 minecraft:calcite
fill 52 284 558 55 284 558 minecraft:cobbled_deepslate
setblock 52 284 597 minecraft:calcite
fill 52 284 598 55 284 598 minecraft:cobbled_deepslate
fill 53 284 576 60 284 576 minecraft:smooth_basalt
fill 53 284 585 63 284 585 minecraft:smooth_basalt
fill 53 284 597 54 284 597 minecraft:cobbled_deepslate
setblock 54 284 560 minecraft:calcite
fill 54 284 575 60 284 575 minecraft:smooth_basalt
setblock 55 284 559 minecraft:calcite
fill 55 284 560 55 285 560 minecraft:cobbled_deepslate
setblock 56 284 558 minecraft:calcite
fill 56 284 559 59 284 559 minecraft:cobbled_deepslate
setblock 56 284 598 minecraft:calcite
fill 57 284 558 60 284 558 minecraft:cobbled_deepslate
fill 57 284 574 60 284 574 minecraft:smooth_basalt
fill 57 284 580 60 284 580 minecraft:smooth_basalt
fill 57 284 598 58 284 598 minecraft:cobbled_deepslate
fill 58 284 560 58 287 561 minecraft:light_blue_stained_glass
fill 58 284 579 60 284 579 minecraft:smooth_basalt
fill 59 284 567 67 284 567 minecraft:smooth_basalt
fill 59 284 573 61 284 573 minecraft:smooth_basalt
setblock 60 284 559 minecraft:calcite
setblock 60 284 578 minecraft:smooth_basalt
fill 60 284 586 65 284 586 minecraft:smooth_basalt
setblock 61 284 558 minecraft:calcite
fill 61 284 559 62 286 559 minecraft:cobbled_deepslate
fill 61 284 583 62 284 584 minecraft:smooth_basalt
fill 62 284 558 64 285 558 minecraft:cobbled_deepslate
fill 62 284 569 62 284 571 minecraft:smooth_basalt
setblock 63 284 569 minecraft:smooth_basalt
fill 64 284 568 65 284 568 minecraft:smooth_basalt
fill 64 284 598 65 284 598 minecraft:cobbled_deepslate
fill 65 284 587 67 284 591 minecraft:smooth_basalt
setblock 66 284 568 minecraft:light[level=14]
setblock 66 284 576 minecraft:light[level=14]
setblock 66 284 584 minecraft:light[level=14]
setblock 66 284 598 minecraft:calcite
setblock 67 284 597 minecraft:calcite
fill 67 284 598 70 284 598 minecraft:cobbled_deepslate
fill 68 284 588 68 284 591 minecraft:smooth_basalt
fill 68 284 597 70 285 597 minecraft:cobbled_deepslate
setblock 71 284 598 minecraft:calcite
setblock 72 284 597 minecraft:calcite
fill 72 284 598 75 284 598 minecraft:cobbled_deepslate
fill 73 284 597 76 284 597 minecraft:cobbled_deepslate
setblock 74 284 568 minecraft:light[level=14]
setblock 74 284 576 minecraft:light[level=14]
setblock 74 284 584 minecraft:light[level=14]
fill 75 284 567 77 284 567 minecraft:smooth_basalt
fill 75 284 587 83 284 587 minecraft:smooth_basalt
setblock 76 284 598 minecraft:calcite
fill 77 284 568 82 284 568 minecraft:smooth_basalt
fill 77 284 586 78 284 586 minecraft:smooth_basalt
setblock 77 284 597 minecraft:calcite
fill 77 284 598 80 284 598 minecraft:cobbled_deepslate
fill 78 284 558 80 284 558 minecraft:cobbled_deepslate
fill 78 284 597 81 284 597 minecraft:cobbled_deepslate
fill 79 284 569 89 284 569 minecraft:smooth_basalt
fill 79 284 585 89 284 585 minecraft:smooth_basalt
setblock 80 284 559 minecraft:calcite
fill 80 284 570 81 284 571 minecraft:smooth_basalt
fill 80 284 583 89 284 584 minecraft:smooth_basalt
setblock 81 284 558 minecraft:calcite
fill 81 284 559 84 284 559 minecraft:cobbled_deepslate
fill 81 284 581 83 284 582 minecraft:smooth_basalt
setblock 81 284 598 minecraft:calcite
fill 82 284 558 85 284 558 minecraft:cobbled_deepslate
setblock 82 284 560 minecraft:light[level=14]
fill 82 284 574 82 284 580 minecraft:smooth_basalt
setblock 82 284 597 minecraft:calcite
fill 82 284 598 85 284 598 minecraft:cobbled_deepslate
fill 83 284 574 85 284 574 minecraft:smooth_basalt
setblock 83 284 580 minecraft:smooth_basalt
fill 83 284 597 86 284 597 minecraft:cobbled_deepslate
fill 84 284 582 89 285 582 minecraft:smooth_basalt
setblock 85 284 559 minecraft:calcite
setblock 86 284 558 minecraft:calcite
fill 86 284 559 88 285 559 minecraft:cobbled_deepslate
setblock 86 284 598 minecraft:calcite
fill 87 284 558 88 286 558 minecraft:cobbled_deepslate
fill 87 284 560 87 284 561 minecraft:cobbled_deepslate
fill 87 284 590 87 284 591 minecraft:cobbled_deepslate
setblock 87 284 592 minecraft:calcite
fill 87 284 593 87 284 596 minecraft:cobbled_deepslate
setblock 87 284 597 minecraft:calcite
fill 87 284 598 88 286 598 minecraft:cobbled_deepslate
setblock 88 284 560 minecraft:cobbled_deepslate
setblock 88 284 561 minecraft:calcite
fill 88 284 562 88 284 565 minecraft:cobbled_deepslate
fill 88 284 588 88 284 590 minecraft:cobbled_deepslate
setblock 88 284 591 minecraft:calcite
fill 88 284 592 88 284 595 minecraft:cobbled_deepslate
setblock 88 284 596 minecraft:calcite
fill 88 284 597 88 287 597 minecraft:cobbled_deepslate
fill 48 285 558 48 285 559 minecraft:cobbled_deepslate
setblock 48 285 560 minecraft:calcite
fill 48 285 561 48 285 564 minecraft:cobbled_deepslate
setblock 48 285 565 minecraft:calcite
fill 48 285 566 48 285 569 minecraft:cobbled_deepslate
setblock 48 285 570 minecraft:calcite
fill 48 285 571 48 285 574 minecraft:cobbled_deepslate
setblock 48 285 575 minecraft:calcite
fill 48 285 576 48 285 579 minecraft:cobbled_deepslate
setblock 48 285 580 minecraft:calcite
fill 48 285 581 48 285 584 minecraft:cobbled_deepslate
setblock 48 285 585 minecraft:calcite
fill 48 285 586 48 285 589 minecraft:cobbled_deepslate
setblock 48 285 590 minecraft:calcite
fill 48 285 591 48 285 594 minecraft:cobbled_deepslate
setblock 48 285 595 minecraft:calcite
fill 48 285 596 48 286 598 minecraft:cobbled_deepslate
setblock 49 285 558 minecraft:cobbled_deepslate
setblock 49 285 559 minecraft:calcite
fill 49 285 560 49 285 563 minecraft:cobbled_deepslate
setblock 49 285 564 minecraft:calcite
fill 49 285 565 49 287 566 minecraft:cobbled_deepslate
fill 49 285 570 49 285 573 minecraft:cobbled_deepslate
setblock 49 285 574 minecraft:calcite
fill 49 285 575 49 285 578 minecraft:cobbled_deepslate
setblock 49 285 579 minecraft:calcite
fill 49 285 580 49 285 583 minecraft:cobbled_deepslate
setblock 49 285 584 minecraft:calcite
fill 49 285 585 49 285 588 minecraft:cobbled_deepslate
setblock 49 285 589 minecraft:calcite
fill 49 285 590 49 285 593 minecraft:cobbled_deepslate
setblock 49 285 594 minecraft:calcite
setblock 49 285 595 minecraft:cobbled_deepslate
fill 49 285 597 49 285 598 minecraft:cobbled_deepslate
setblock 50 285 558 minecraft:calcite
fill 50 285 559 50 285 562 minecraft:cobbled_deepslate
setblock 50 285 573 minecraft:calcite
fill 50 285 574 50 285 577 minecraft:cobbled_deepslate
setblock 50 285 578 minecraft:calcite
fill 50 285 579 50 285 582 minecraft:cobbled_deepslate
setblock 50 285 583 minecraft:calcite
fill 50 285 584 50 285 587 minecraft:cobbled_deepslate
setblock 50 285 588 minecraft:calcite
setblock 50 285 597 minecraft:cobbled_deepslate
setblock 50 285 598 minecraft:calcite
fill 51 285 558 52 285 560 minecraft:cobbled_deepslate
fill 51 285 577 57 285 577 minecraft:smooth_basalt
fill 51 285 578 51 285 581 minecraft:cobbled_deepslate
setblock 51 285 582 minecraft:calcite
fill 51 285 583 51 288 583 minecraft:cobbled_deepslate
setblock 51 285 597 minecraft:calcite
fill 51 285 598 54 285 598 minecraft:cobbled_deepslate
fill 52 285 597 53 285 597 minecraft:cobbled_deepslate
fill 53 285 558 53 285 559 minecraft:cobbled_deepslate
setblock 53 285 560 minecraft:calcite
fill 53 285 576 57 285 576 minecraft:smooth_basalt
fill 53 285 585 60 285 585 minecraft:smooth_basalt
setblock 54 285 558 minecraft:cobbled_deepslate
setblock 54 285 559 minecraft:calcite
fill 54 285 560 54 286 560 minecraft:cobbled_deepslate
fill 54 285 575 57 285 575 minecraft:smooth_basalt
setblock 55 285 558 minecraft:calcite
fill 55 285 559 58 285 559 minecraft:cobbled_deepslate
fill 55 285 565 63 285 566 minecraft:smooth_basalt
fill 55 285 582 58 285 583 minecraft:smooth_basalt
fill 55 285 596 55 289 596 minecraft:deepslate
setblock 55 285 598 minecraft:calcite
fill 56 285 558 59 285 558 minecraft:cobbled_deepslate
fill 56 285 581 58 285 581 minecraft:smooth_basalt
fill 56 285 598 57 285 598 minecraft:cobbled_deepslate
fill 57 285 560 57 285 562 minecraft:light_blue_stained_glass
fill 57 285 568 58 285 572 minecraft:smooth_basalt
fill 57 285 574 58 285 574 minecraft:smooth_basalt
setblock 57 285 578 minecraft:smooth_basalt
fill 57 285 580 58 285 580 minecraft:smooth_basalt
setblock 59 285 559 minecraft:calcite
fill 59 285 560 59 287 560 minecraft:light_blue_stained_glass
fill 59 285 567 59 285 571 minecraft:smooth_basalt
setblock 59 285 583 minecraft:smooth_basalt
fill 59 285 587 62 285 587 minecraft:smooth_basalt
setblock 60 285 558 minecraft:calcite
fill 60 285 559 60 286 559 minecraft:cobbled_deepslate
fill 60 285 567 60 285 569 minecraft:smooth_basalt
fill 60 285 586 61 285 586 minecraft:smooth_basalt
fill 61 285 558 61 288 558 minecraft:cobbled_deepslate
fill 61 285 567 61 285 568 minecraft:smooth_basalt
setblock 62 285 567 minecraft:smooth_basalt
fill 64 285 565 65 285 565 minecraft:smooth_basalt
fill 64 285 589 64 285 591 minecraft:calcite
setblock 64 285 598 minecraft:cobbled_deepslate
fill 65 285 589 65 285 591 minecraft:smooth_basalt
setblock 65 285 598 minecraft:calcite
fill 66 285 590 68 285 591 minecraft:smooth_basalt
fill 66 285 598 69 285 598 minecraft:cobbled_deepslate
fill 67 285 564 68 285 564 minecraft:smooth_basalt
fill 67 285 597 67 286 597 minecraft:cobbled_deepslate
setblock 69 285 591 minecraft:smooth_basalt
setblock 70 285 598 minecraft:calcite
fill 71 285 598 74 285 598 minecraft:cobbled_deepslate
fill 72 285 597 75 285 597 minecraft:cobbled_deepslate
fill 74 285 564 77 285 564 minecraft:smooth_basalt
setblock 74 285 590 minecraft:smooth_basalt
setblock 75 285 598 minecraft:calcite
setblock 76 285 597 minecraft:calcite
fill 76 285 598 79 285 598 minecraft:cobbled_deepslate
setblock 77 285 565 minecraft:smooth_basalt
fill 77 285 589 87 285 589 minecraft:smooth_basalt
fill 77 285 597 80 285 597 minecraft:cobbled_deepslate
fill 78 285 558 79 285 558 minecraft:cobbled_deepslate
fill 78 285 563 78 285 565 minecraft:calcite
fill 79 285 563 83 285 566 minecraft:smooth_basalt
fill 79 285 588 87 285 588 minecraft:smooth_basalt
setblock 80 285 558 minecraft:calcite
fill 80 285 559 83 285 559 minecraft:cobbled_deepslate
fill 80 285 567 83 285 567 minecraft:smooth_basalt
fill 80 285 587 83 285 587 minecraft:smooth_basalt
setblock 80 285 598 minecraft:calcite
fill 81 285 558 84 285 558 minecraft:cobbled_deepslate
fill 81 285 568 82 285 568 minecraft:smooth_basalt
setblock 81 285 597 minecraft:calcite
fill 81 285 598 84 285 598 minecraft:cobbled_deepslate
fill 82 285 569 89 285 569 minecraft:smooth_basalt
fill 82 285 585 89 285 585 minecraft:smooth_basalt
fill 82 285 597 85 285 597 minecraft:cobbled_deepslate
fill 83 285 571 87 285 571 minecraft:smooth_basalt
fill 83 285 583 89 285 584 minecraft:smooth_basalt
setblock 84 285 559 minecraft:calcite
fill 84 285 572 85 285 574 minecraft:smooth_basalt
setblock 85 285 558 minecraft:calcite
fill 85 285 559 85 288 559 minecraft:cobbled_deepslate
fill 85 285 576 86 285 579 minecraft:smooth_basalt
setblock 85 285 598 minecraft:calcite
fill 86 285 558 86 288 558 minecraft:cobbled_deepslate
fill 86 285 572 86 285 573 minecraft:smooth_basalt
setblock 86 285 597 minecraft:calcite
fill 86 285 598 86 288 598 minecraft:cobbled_deepslate
setblock 87 285 560 minecraft:cobbled_deepslate
setblock 87 285 561 minecraft:calcite
fill 87 285 562 88 287 562 minecraft:cobbled_deepslate
fill 87 285 572 87 286 572 minecraft:smooth_basalt
fill 87 285 576 89 286 577 minecraft:smooth_basalt
setblock 87 285 590 minecraft:cobbled_deepslate
setblock 87 285 591 minecraft:calcite
fill 87 285 592 87 285 595 minecraft:cobbled_deepslate
setblock 87 285 596 minecraft:calcite
fill 87 285 597 87 288 597 minecraft:cobbled_deepslate
setblock 88 285 560 minecraft:calcite
fill 88 285 561 88 288 561 minecraft:cobbled_deepslate
fill 88 285 563 88 285 564 minecraft:cobbled_deepslate
setblock 88 285 565 minecraft:calcite
fill 88 285 566 88 288 566 minecraft:cobbled_deepslate
fill 88 285 588 88 285 589 minecraft:cobbled_deepslate
setblock 88 285 590 minecraft:calcite
fill 88 285 591 88 285 594 minecraft:cobbled_deepslate
setblock 88 285 595 minecraft:calcite
fill 88 285 596 88 288 596 minecraft:cobbled_deepslate
setblock 48 286 558 minecraft:cobbled_deepslate
setblock 48 286 559 minecraft:calcite
fill 48 286 560 48 286 563 minecraft:cobbled_deepslate
setblock 48 286 564 minecraft:calcite
fill 48 286 565 48 286 568 minecraft:cobbled_deepslate
setblock 48 286 569 minecraft:calcite
fill 48 286 570 48 286 573 minecraft:cobbled_deepslate
setblock 48 286 574 minecraft:calcite
fill 48 286 575 48 286 578 minecraft:cobbled_deepslate
setblock 48 286 579 minecraft:calcite
fill 48 286 580 48 286 583 minecraft:cobbled_deepslate
setblock 48 286 584 minecraft:calcite
fill 48 286 585 48 286 588 minecraft:cobbled_deepslate
setblock 48 286 589 minecraft:calcite
fill 48 286 590 48 286 593 minecraft:cobbled_deepslate
setblock 48 286 594 minecraft:calcite
fill 48 286 595 48 288 595 minecraft:cobbled_deepslate
setblock 49 286 558 minecraft:calcite
fill 49 286 559 49 286 562 minecraft:cobbled_deepslate
setblock 49 286 563 minecraft:calcite
fill 49 286 564 49 289 564 minecraft:cobbled_deepslate
setblock 49 286 567 minecraft:cobbled_deepslate
setblock 49 286 568 minecraft:calcite
fill 49 286 569 49 286 572 minecraft:cobbled_deepslate
setblock 49 286 573 minecraft:calcite
fill 49 286 574 49 286 577 minecraft:cobbled_deepslate
setblock 49 286 578 minecraft:calcite
fill 49 286 579 49 286 582 minecraft:cobbled_deepslate
setblock 49 286 583 minecraft:calcite
fill 49 286 584 49 286 587 minecraft:cobbled_deepslate
setblock 49 286 588 minecraft:calcite
fill 49 286 589 49 287 591 minecraft:cobbled_deepslate
setblock 49 286 597 minecraft:cobbled_deepslate
setblock 49 286 598 minecraft:calcite
fill 50 286 558 50 286 561 minecraft:cobbled_deepslate
setblock 50 286 562 minecraft:calcite
fill 50 286 563 50 288 563 minecraft:cobbled_deepslate
fill 50 286 574 50 286 576 minecraft:cobbled_deepslate
setblock 50 286 577 minecraft:calcite
fill 50 286 578 50 286 581 minecraft:cobbled_deepslate
setblock 50 286 582 minecraft:calcite
fill 50 286 583 50 286 586 minecraft:cobbled_deepslate
setblock 50 286 587 minecraft:calcite
fill 50 286 588 50 287 588 minecraft:cobbled_deepslate
setblock 50 286 597 minecraft:calcite
fill 50 286 598 53 286 598 minecraft:cobbled_deepslate
fill 51 286 558 51 286 560 minecraft:cobbled_deepslate
setblock 51 286 576 minecraft:calcite
fill 51 286 577 55 286 577 minecraft:smooth_basalt
fill 51 286 578 51 286 580 minecraft:cobbled_deepslate
setblock 51 286 581 minecraft:calcite
fill 51 286 582 51 288 582 minecraft:cobbled_deepslate
setblock 51 286 597 minecraft:cobbled_deepslate
fill 52 286 558 52 286 559 minecraft:cobbled_deepslate
setblock 52 286 560 minecraft:calcite
setblock 53 286 558 minecraft:cobbled_deepslate
setblock 53 286 559 minecraft:calcite
setblock 53 286 560 minecraft:cobbled_deepslate
fill 53 286 576 55 286 576 minecraft:smooth_basalt
fill 53 286 585 57 286 585 minecraft:smooth_basalt
setblock 54 286 558 minecraft:calcite
fill 54 286 559 57 286 559 minecraft:cobbled_deepslate
fill 54 286 575 55 286 575 minecraft:smooth_basalt
fill 54 286 584 56 286 584 minecraft:smooth_basalt
setblock 54 286 598 minecraft:calcite
fill 55 286 558 58 286 558 minecraft:cobbled_deepslate
fill 55 286 565 59 286 566 minecraft:smooth_basalt
fill 55 286 582 56 286 583 minecraft:smooth_basalt
setblock 55 286 598 minecraft:cobbled_deepslate
fill 56 286 564 62 286 564 minecraft:smooth_basalt
fill 56 286 568 56 286 572 minecraft:smooth_basalt
fill 57 286 560 57 286 561 minecraft:light_blue_stained_glass
fill 57 286 563 63 286 563 minecraft:smooth_basalt
fill 57 286 568 57 286 569 minecraft:smooth_basalt
setblock 58 286 559 minecraft:calcite
setblock 58 286 568 minecraft:smooth_basalt
fill 58 286 588 59 286 588 minecraft:smooth_basalt
setblock 59 286 558 minecraft:calcite
setblock 59 286 559 minecraft:cobbled_deepslate
fill 59 286 589 60 286 593 minecraft:smooth_basalt
fill 60 286 558 60 289 558 minecraft:cobbled_deepslate
setblock 60 286 565 minecraft:smooth_basalt
fill 61 286 590 62 286 593 minecraft:smooth_basalt
fill 62 286 558 63 286 558 minecraft:cobbled_deepslate
fill 63 286 591 63 286 593 minecraft:smooth_basalt
setblock 64 286 558 minecraft:calcite
fill 64 286 562 66 286 562 minecraft:smooth_basalt
fill 64 286 592 66 286 593 minecraft:smooth_basalt
setblock 64 286 598 minecraft:calcite
fill 65 286 598 68 286 598 minecraft:cobbled_deepslate
fill 67 286 593 70 286 593 minecraft:smooth_basalt
fill 68 286 597 69 286 597 minecraft:cobbled_deepslate
setblock 69 286 598 minecraft:calcite
setblock 70 286 597 minecraft:calcite
fill 70 286 598 73 286 598 minecraft:cobbled_deepslate
fill 72 286 597 74 286 597 minecraft:cobbled_deepslate
setblock 74 286 598 minecraft:calcite
setblock 75 286 597 minecraft:calcite
fill 75 286 598 78 286 598 minecraft:cobbled_deepslate
fill 76 286 562 83 286 562 minecraft:smooth_basalt
fill 76 286 592 78 286 592 minecraft:smooth_basalt
fill 76 286 597 78 286 597 minecraft:cobbled_deepslate
setblock 78 286 558 minecraft:cobbled_deepslate
setblock 79 286 558 minecraft:calcite
fill 79 286 563 83 286 563 minecraft:smooth_basalt
setblock 79 286 598 minecraft:calcite
fill 80 286 558 82 286 559 minecraft:cobbled_deepslate
fill 80 286 564 83 286 564 minecraft:smooth_basalt
fill 80 286 590 86 286 590 minecraft:smooth_basalt
fill 80 286 598 83 286 598 minecraft:cobbled_deepslate
fill 82 286 565 83 286 565 minecraft:smooth_basalt
fill 82 286 589 87 286 589 minecraft:smooth_basalt
setblock 83 286 558 minecraft:cobbled_deepslate
setblock 83 286 559 minecraft:calcite
setblock 83 286 566 minecraft:smooth_basalt
fill 83 286 588 87 286 588 minecraft:smooth_basalt
fill 83 286 597 84 286 597 minecraft:cobbled_deepslate
setblock 84 286 558 minecraft:calcite
fill 84 286 559 84 287 559 minecraft:cobbled_deepslate
fill 84 286 586 88 286 586 minecraft:smooth_basalt
setblock 84 286 598 minecraft:calcite
fill 85 286 558 85 289 558 minecraft:cobbled_deepslate
fill 85 286 569 89 286 569 minecraft:smooth_basalt
fill 85 286 585 89 286 585 minecraft:smooth_basalt
setblock 85 286 597 minecraft:calcite
fill 85 286 598 85 289 598 minecraft:cobbled_deepslate
fill 86 286 559 87 286 559 minecraft:cobbled_deepslate
fill 86 286 570 86 286 572 minecraft:smooth_basalt
setblock 86 286 580 minecraft:cobbled_deepslate
setblock 86 286 581 minecraft:calcite
fill 86 286 582 89 286 584 minecraft:smooth_basalt
fill 86 286 597 86 288 597 minecraft:cobbled_deepslate
setblock 87 286 560 minecraft:calcite
fill 87 286 561 87 289 561 minecraft:cobbled_deepslate
fill 87 286 570 87 286 571 minecraft:smooth_basalt
fill 87 286 575 89 286 575 minecraft:smooth_basalt
fill 87 286 581 89 286 581 minecraft:smooth_basalt
setblock 87 286 590 minecraft:calcite
fill 87 286 591 87 286 594 minecraft:cobbled_deepslate
setblock 87 286 595 minecraft:calcite
fill 87 286 596 87 288 596 minecraft:cobbled_deepslate
setblock 88 286 559 minecraft:calcite
fill 88 286 560 88 289 560 minecraft:cobbled_deepslate
setblock 88 286 563 minecraft:cobbled_deepslate
setblock 88 286 564 minecraft:calcite
fill 88 286 565 88 289 565 minecraft:cobbled_deepslate
setblock 88 286 570 minecraft:smooth_basalt
setblock 88 286 588 minecraft:cobbled_deepslate
setblock 88 286 589 minecraft:calcite
fill 88 286 590 88 286 593 minecraft:cobbled_deepslate
setblock 88 286 594 minecraft:calcite
fill 88 286 595 88 289 595 minecraft:cobbled_deepslate
setblock 48 287 558 minecraft:calcite
fill 48 287 559 48 287 562 minecraft:cobbled_deepslate
setblock 48 287 563 minecraft:calcite
fill 48 287 564 48 287 567 minecraft:cobbled_deepslate
setblock 48 287 568 minecraft:calcite
fill 48 287 569 48 287 572 minecraft:cobbled_deepslate
setblock 48 287 573 minecraft:calcite
fill 48 287 574 48 287 577 minecraft:cobbled_deepslate
setblock 48 287 578 minecraft:calcite
fill 48 287 579 48 287 582 minecraft:cobbled_deepslate
setblock 48 287 583 minecraft:calcite
fill 48 287 584 48 287 587 minecraft:cobbled_deepslate
setblock 48 287 588 minecraft:calcite
fill 48 287 589 48 287 592 minecraft:cobbled_deepslate
setblock 48 287 593 minecraft:calcite
fill 48 287 594 48 288 594 minecraft:cobbled_deepslate
fill 48 287 596 48 287 597 minecraft:cobbled_deepslate
setblock 48 287 598 minecraft:calcite
fill 49 287 558 49 287 561 minecraft:cobbled_deepslate
setblock 49 287 562 minecraft:calcite
fill 49 287 563 49 290 563 minecraft:cobbled_deepslate
setblock 49 287 567 minecraft:calcite
fill 49 287 568 49 287 571 minecraft:cobbled_deepslate
setblock 49 287 572 minecraft:calcite
fill 49 287 573 49 287 576 minecraft:cobbled_deepslate
setblock 49 287 577 minecraft:calcite
fill 49 287 578 49 287 581 minecraft:cobbled_deepslate
setblock 49 287 582 minecraft:calcite
fill 49 287 583 49 287 586 minecraft:cobbled_deepslate
setblock 49 287 587 minecraft:calcite
fill 49 287 588 49 290 588 minecraft:cobbled_deepslate
fill 49 287 598 52 287 598 minecraft:cobbled_deepslate
fill 50 287 558 50 287 560 minecraft:cobbled_deepslate
setblock 50 287 561 minecraft:calcite
fill 50 287 562 50 288 562 minecraft:cobbled_deepslate
fill 50 287 574 50 287 575 minecraft:cobbled_deepslate
setblock 50 287 576 minecraft:calcite
fill 50 287 577 50 287 580 minecraft:cobbled_deepslate
setblock 50 287 581 minecraft:calcite
fill 50 287 582 50 287 585 minecraft:cobbled_deepslate
setblock 50 287 586 minecraft:calcite
fill 50 287 587 50 290 587 minecraft:cobbled_deepslate
fill 51 287 558 51 287 559 minecraft:cobbled_deepslate
setblock 51 287 560 minecraft:calcite
fill 51 287 577 51 287 579 minecraft:cobbled_deepslate
setblock 51 287 580 minecraft:calcite
fill 51 287 581 51 288 581 minecraft:cobbled_deepslate
setblock 51 287 584 minecraft:cobbled_deepslate
setblock 51 287 585 minecraft:calcite
setblock 52 287 558 minecraft:cobbled_deepslate
setblock 52 287 559 minecraft:calcite
setblock 52 287 560 minecraft:cobbled_deepslate
setblock 53 287 558 minecraft:calcite
fill 53 287 559 56 287 559 minecraft:cobbled_deepslate
setblock 53 287 598 minecraft:calcite
fill 54 287 558 57 287 558 minecraft:cobbled_deepslate
fill 54 287 596 54 289 596 minecraft:deepslate
fill 55 287 595 55 289 595 minecraft:deepslate
fill 55 287 597 55 289 597 minecraft:deepslate
fill 56 287 596 56 289 596 minecraft:deepslate
fill 57 287 559 57 287 560 minecraft:light_blue_stained_glass
setblock 58 287 558 minecraft:calcite
fill 58 287 559 60 287 559 minecraft:light_blue_stained_glass
fill 59 287 558 59 288 558 minecraft:cobbled_deepslate
setblock 61 287 559 minecraft:cobbled_deepslate
setblock 62 287 558 minecraft:cobbled_deepslate
setblock 62 287 559 minecraft:calcite
setblock 63 287 558 minecraft:calcite
fill 63 287 559 65 287 560 minecraft:cobbled_deepslate
fill 64 287 558 67 287 558 minecraft:cobbled_deepslate
fill 65 287 598 67 287 598 minecraft:cobbled_deepslate
setblock 66 287 559 minecraft:cobbled_deepslate
setblock 66 287 560 minecraft:calcite
fill 66 287 561 69 287 561 minecraft:cobbled_deepslate
setblock 67 287 559 minecraft:calcite
fill 67 287 560 70 287 560 minecraft:cobbled_deepslate
fill 68 287 559 71 287 559 minecraft:cobbled_deepslate
setblock 68 287 597 minecraft:cobbled_deepslate
setblock 68 287 598 minecraft:calcite
fill 69 287 558 72 287 558 minecraft:cobbled_deepslate
setblock 69 287 597 minecraft:calcite
fill 69 287 598 72 287 598 minecraft:cobbled_deepslate
setblock 70 287 561 minecraft:calcite
fill 70 287 597 73 287 597 minecraft:cobbled_deepslate
fill 71 287 557 71 307 557 minecraft:deepslate
setblock 71 287 560 minecraft:calcite
fill 71 287 561 73 287 561 minecraft:cobbled_deepslate
setblock 72 287 559 minecraft:calcite
fill 72 287 560 75 287 560 minecraft:cobbled_deepslate
setblock 73 287 558 minecraft:calcite
fill 73 287 559 76 287 559 minecraft:cobbled_deepslate
setblock 73 287 598 minecraft:calcite
fill 74 287 558 77 287 558 minecraft:cobbled_deepslate
setblock 74 287 597 minecraft:calcite
fill 74 287 598 77 287 598 minecraft:cobbled_deepslate
fill 75 287 597 76 287 597 minecraft:cobbled_deepslate
setblock 76 287 560 minecraft:calcite
setblock 77 287 559 minecraft:calcite
setblock 78 287 558 minecraft:calcite
fill 78 287 559 79 287 559 minecraft:cobbled_deepslate
setblock 78 287 598 minecraft:calcite
fill 79 287 558 82 287 558 minecraft:cobbled_deepslate
fill 79 287 598 82 287 598 minecraft:cobbled_deepslate
setblock 83 287 558 minecraft:calcite
setblock 83 287 598 minecraft:calcite
fill 84 287 558 84 290 558 minecraft:cobbled_deepslate
fill 84 287 598 84 290 598 minecraft:cobbled_deepslate
setblock 85 287 597 minecraft:cobbled_deepslate
setblock 86 287 559 minecraft:cobbled_deepslate
setblock 86 287 580 minecraft:calcite
fill 86 287 581 86 287 584 minecraft:cobbled_deepslate
setblock 86 287 585 minecraft:calcite
fill 86 287 586 88 287 587 minecraft:cobbled_deepslate
setblock 87 287 558 minecraft:cobbled_deepslate
setblock 87 287 559 minecraft:calcite
fill 87 287 560 87 289 560 minecraft:cobbled_deepslate
setblock 87 287 563 minecraft:cobbled_deepslate
fill 87 287 577 87 287 578 minecraft:cobbled_deepslate
setblock 87 287 579 minecraft:calcite
fill 87 287 580 87 287 583 minecraft:cobbled_deepslate
setblock 87 287 584 minecraft:calcite
fill 87 287 585 88 289 585 minecraft:cobbled_deepslate
setblock 87 287 588 minecraft:cobbled_deepslate
setblock 87 287 589 minecraft:calcite
fill 87 287 590 87 287 593 minecraft:cobbled_deepslate
setblock 87 287 594 minecraft:calcite
fill 87 287 595 87 288 595 minecraft:cobbled_deepslate
setblock 87 287 598 minecraft:cobbled_deepslate
setblock 88 287 558 minecraft:calcite
fill 88 287 559 88 290 559 minecraft:cobbled_deepslate
setblock 88 287 563 minecraft:calcite
fill 88 287 564 88 290 564 minecraft:cobbled_deepslate
setblock 88 287 567 minecraft:cobbled_deepslate
setblock 88 287 573 minecraft:calcite
fill 88 287 574 88 287 577 minecraft:cobbled_deepslate
setblock 88 287 578 minecraft:calcite
fill 88 287 579 88 287 582 minecraft:cobbled_deepslate
setblock 88 287 583 minecraft:calcite
fill 88 287 584 88 290 584 minecraft:cobbled_deepslate
setblock 88 287 588 minecraft:calcite
fill 88 287 589 88 287 592 minecraft:cobbled_deepslate
setblock 88 287 593 minecraft:calcite
fill 88 287 594 88 290 594 minecraft:cobbled_deepslate
setblock 88 287 598 minecraft:calcite
fill 89 287 569 89 307 585 minecraft:deepslate
fill 48 288 558 48 288 561 minecraft:cobbled_deepslate
setblock 48 288 562 minecraft:calcite
fill 48 288 563 48 288 566 minecraft:cobbled_deepslate
setblock 48 288 567 minecraft:calcite
fill 48 288 568 48 288 571 minecraft:cobbled_deepslate
setblock 48 288 572 minecraft:calcite
fill 48 288 573 48 288 576 minecraft:cobbled_deepslate
setblock 48 288 577 minecraft:calcite
fill 48 288 578 48 288 581 minecraft:cobbled_deepslate
setblock 48 288 582 minecraft:calcite
fill 48 288 583 48 288 586 minecraft:cobbled_deepslate
setblock 48 288 587 minecraft:calcite
fill 48 288 588 48 288 591 minecraft:cobbled_deepslate
setblock 48 288 592 minecraft:calcite
fill 48 288 593 48 290 593 minecraft:cobbled_deepslate
setblock 48 288 596 minecraft:cobbled_deepslate
setblock 48 288 597 minecraft:calcite
fill 48 288 598 51 288 598 minecraft:cobbled_deepslate
fill 49 288 558 49 288 560 minecraft:cobbled_deepslate
setblock 49 288 561 minecraft:calcite
fill 49 288 562 49 291 562 minecraft:cobbled_deepslate
setblock 49 288 565 minecraft:cobbled_deepslate
setblock 49 288 566 minecraft:calcite
fill 49 288 567 49 288 570 minecraft:cobbled_deepslate
setblock 49 288 571 minecraft:calcite
fill 49 288 572 49 288 575 minecraft:cobbled_deepslate
setblock 49 288 576 minecraft:calcite
fill 49 288 577 49 288 580 minecraft:cobbled_deepslate
setblock 49 288 581 minecraft:calcite
fill 49 288 582 49 288 585 minecraft:cobbled_deepslate
setblock 49 288 586 minecraft:calcite
fill 49 288 587 49 291 587 minecraft:cobbled_deepslate
fill 49 288 589 49 288 590 minecraft:cobbled_deepslate
fill 50 288 558 50 288 559 minecraft:cobbled_deepslate
setblock 50 288 561 minecraft:cobbled_deepslate
fill 50 288 576 50 288 579 minecraft:cobbled_deepslate
setblock 50 288 580 minecraft:calcite
fill 50 288 581 50 288 584 minecraft:cobbled_deepslate
setblock 50 288 585 minecraft:calcite
fill 50 288 586 50 291 586 minecraft:cobbled_deepslate
setblock 51 288 558 minecraft:cobbled_deepslate
setblock 51 288 559 minecraft:calcite
setblock 51 288 579 minecraft:calcite
setblock 51 288 580 minecraft:cobbled_deepslate
setblock 51 288 584 minecraft:calcite
setblock 52 288 558 minecraft:calcite
fill 52 288 559 54 288 559 minecraft:cobbled_deepslate
fill 53 288 558 56 288 558 minecraft:cobbled_deepslate
fill 54 288 595 54 289 595 minecraft:deepslate
fill 54 288 597 54 289 597 minecraft:deepslate
fill 56 288 595 56 289 595 minecraft:deepslate
fill 56 288 597 56 289 597 minecraft:deepslate
setblock 57 288 558 minecraft:calcite
fill 57 288 559 59 288 559 minecraft:light_blue_stained_glass
setblock 58 288 558 minecraft:cobbled_deepslate
setblock 61 288 559 minecraft:calcite
setblock 62 288 558 minecraft:calcite
fill 62 288 559 65 288 559 minecraft:cobbled_deepslate
fill 63 288 558 66 288 558 minecraft:cobbled_deepslate
setblock 64 288 560 minecraft:cobbled_deepslate
setblock 65 288 560 minecraft:calcite
fill 65 288 598 66 288 598 minecraft:cobbled_deepslate
setblock 66 288 559 minecraft:calcite
fill 66 288 560 68 288 561 minecraft:cobbled_deepslate
setblock 67 288 558 minecraft:calcite
fill 67 288 559 70 288 559 minecraft:cobbled_deepslate
setblock 67 288 598 minecraft:calcite
fill 68 288 558 71 288 558 minecraft:cobbled_deepslate
setblock 68 288 597 minecraft:calcite
fill 68 288 598 71 288 598 minecraft:cobbled_deepslate
setblock 69 288 560 minecraft:cobbled_deepslate
setblock 69 288 561 minecraft:calcite
fill 69 288 597 72 288 597 minecraft:cobbled_deepslate
setblock 70 288 560 minecraft:calcite
fill 70 288 561 72 288 561 minecraft:cobbled_deepslate
setblock 71 288 559 minecraft:calcite
fill 71 288 560 74 288 560 minecraft:cobbled_deepslate
setblock 72 288 558 minecraft:calcite
fill 72 288 559 75 288 559 minecraft:cobbled_deepslate
setblock 72 288 598 minecraft:calcite
fill 73 288 558 76 288 558 minecraft:cobbled_deepslate
fill 73 288 580 76 300 581 minecraft:calcite
setblock 73 288 597 minecraft:calcite
fill 73 288 598 76 288 598 minecraft:cobbled_deepslate
fill 74 288 579 75 300 579 minecraft:calcite
fill 74 288 582 76 300 582 minecraft:calcite
setblock 75 288 560 minecraft:calcite
setblock 76 288 559 minecraft:calcite
setblock 77 288 558 minecraft:calcite
setblock 77 288 559 minecraft:cobbled_deepslate
setblock 77 288 598 minecraft:calcite
fill 78 288 558 81 288 558 minecraft:cobbled_deepslate
fill 78 288 598 81 288 598 minecraft:cobbled_deepslate
setblock 82 288 558 minecraft:calcite
setblock 82 288 598 minecraft:calcite
fill 83 288 558 83 289 558 minecraft:cobbled_deepslate
fill 83 288 598 83 290 598 minecraft:cobbled_deepslate
setblock 86 288 559 minecraft:calcite
fill 86 288 581 86 288 583 minecraft:cobbled_deepslate
setblock 86 288 584 minecraft:calcite
fill 86 288 585 86 288 588 minecraft:cobbled_deepslate
setblock 87 288 558 minecraft:calcite
fill 87 288 559 87 289 559 minecraft:cobbled_deepslate
setblock 87 288 562 minecraft:cobbled_deepslate
setblock 87 288 563 minecraft:calcite
setblock 87 288 577 minecraft:cobbled_deepslate
setblock 87 288 578 minecraft:calcite
fill 87 288 579 87 288 582 minecraft:cobbled_deepslate
setblock 87 288 583 minecraft:calcite
fill 87 288 584 87 291 584 minecraft:cobbled_deepslate
fill 87 288 586 87 288 587 minecraft:cobbled_deepslate
setblock 87 288 588 minecraft:calcite
fill 87 288 589 87 288 592 minecraft:cobbled_deepslate
setblock 87 288 593 minecraft:calcite
setblock 87 288 594 minecraft:cobbled_deepslate
setblock 87 288 598 minecraft:calcite
fill 88 288 558 88 291 558 minecraft:cobbled_deepslate
setblock 88 288 562 minecraft:calcite
fill 88 288 563 88 291 563 minecraft:cobbled_deepslate
setblock 88 288 567 minecraft:calcite
fill 88 288 568 88 291 568 minecraft:cobbled_deepslate
fill 88 288 574 88 288 576 minecraft:cobbled_deepslate
setblock 88 288 577 minecraft:calcite
fill 88 288 578 88 288 581 minecraft:cobbled_deepslate
setblock 88 288 582 minecraft:calcite
fill 88 288 583 88 291 583 minecraft:cobbled_deepslate
setblock 88 288 586 minecraft:cobbled_deepslate
setblock 88 288 587 minecraft:calcite
fill 88 288 588 88 288 591 minecraft:cobbled_deepslate
setblock 88 288 592 minecraft:calcite
fill 88 288 593 88 291 593 minecraft:cobbled_deepslate
setblock 88 288 597 minecraft:calcite
fill 88 288 598 88 291 598 minecraft:cobbled_deepslate
fill 48 289 558 48 289 560 minecraft:cobbled_deepslate
setblock 48 289 561 minecraft:calcite
fill 48 289 562 48 289 565 minecraft:cobbled_deepslate
setblock 48 289 566 minecraft:calcite
fill 48 289 567 48 289 570 minecraft:cobbled_deepslate
setblock 48 289 571 minecraft:calcite
fill 48 289 572 48 289 575 minecraft:cobbled_deepslate
setblock 48 289 576 minecraft:calcite
fill 48 289 577 48 289 580 minecraft:cobbled_deepslate
setblock 48 289 581 minecraft:calcite
fill 48 289 582 48 289 585 minecraft:cobbled_deepslate
setblock 48 289 586 minecraft:calcite
fill 48 289 587 48 289 590 minecraft:cobbled_deepslate
setblock 48 289 591 minecraft:calcite
fill 48 289 592 48 292 592 minecraft:cobbled_deepslate
setblock 48 289 598 minecraft:cobbled_deepslate
fill 49 289 558 49 289 559 minecraft:cobbled_deepslate
setblock 49 289 560 minecraft:calcite
fill 49 289 561 49 292 561 minecraft:cobbled_deepslate
setblock 49 289 565 minecraft:calcite
fill 49 289 566 49 289 569 minecraft:cobbled_deepslate
setblock 49 289 570 minecraft:calcite
fill 49 289 571 49 289 574 minecraft:cobbled_deepslate
setblock 49 289 575 minecraft:calcite
fill 49 289 576 49 289 579 minecraft:cobbled_deepslate
setblock 49 289 580 minecraft:calcite
fill 49 289 581 49 289 584 minecraft:cobbled_deepslate
setblock 49 289 585 minecraft:calcite
fill 49 289 586 49 292 586 minecraft:cobbled_deepslate
setblock 49 289 589 minecraft:cobbled_deepslate
setblock 49 289 590 minecraft:calcite
setblock 50 289 558 minecraft:cobbled_deepslate
setblock 50 289 559 minecraft:calcite
fill 50 289 577 50 289 578 minecraft:cobbled_deepslate
setblock 50 289 579 minecraft:calcite
fill 50 289 580 50 289 583 minecraft:cobbled_deepslate
setblock 50 289 584 minecraft:calcite
fill 50 289 585 50 292 585 minecraft:cobbled_deepslate
setblock 51 289 558 minecraft:calcite
fill 51 289 559 52 289 559 minecraft:cobbled_deepslate
fill 52 289 558 55 289 558 minecraft:cobbled_deepslate
setblock 53 289 596 minecraft:deepslate
setblock 55 289 594 minecraft:deepslate
setblock 55 289 598 minecraft:deepslate
setblock 57 289 596 minecraft:deepslate
setblock 61 289 558 minecraft:calcite
fill 62 289 558 64 289 559 minecraft:cobbled_deepslate
setblock 64 289 560 minecraft:calcite
setblock 65 289 558 minecraft:cobbled_deepslate
setblock 65 289 559 minecraft:calcite
fill 65 289 560 68 289 560 minecraft:cobbled_deepslate
setblock 65 289 598 minecraft:cobbled_deepslate
setblock 66 289 558 minecraft:calcite
fill 66 289 559 69 289 559 minecraft:cobbled_deepslate
fill 66 289 561 67 289 561 minecraft:cobbled_deepslate
setblock 66 289 598 minecraft:calcite
fill 67 289 558 70 289 558 minecraft:cobbled_deepslate
fill 67 289 598 70 289 598 minecraft:cobbled_deepslate
setblock 68 289 561 minecraft:calcite
setblock 69 289 560 minecraft:calcite
fill 69 289 561 71 289 561 minecraft:cobbled_deepslate
setblock 70 289 559 minecraft:calcite
fill 70 289 560 73 289 560 minecraft:cobbled_deepslate
fill 70 289 597 71 289 597 minecraft:cobbled_deepslate
setblock 71 289 558 minecraft:calcite
fill 71 289 559 74 289 559 minecraft:cobbled_deepslate
setblock 71 289 598 minecraft:calcite
fill 72 289 558 75 289 558 minecraft:cobbled_deepslate
fill 72 289 580 72 290 581 minecraft:deepslate
fill 72 289 598 75 289 598 minecraft:cobbled_deepslate
fill 73 289 579 73 290 579 minecraft:deepslate
fill 73 289 582 73 290 582 minecraft:deepslate
setblock 74 289 560 minecraft:calcite
fill 74 289 578 75 290 578 minecraft:deepslate
fill 74 289 583 76 290 583 minecraft:deepslate
setblock 75 289 559 minecraft:calcite
setblock 76 289 558 minecraft:calcite
setblock 76 289 559 minecraft:cobbled_deepslate
fill 76 289 579 76 290 579 minecraft:deepslate
setblock 76 289 598 minecraft:calcite
fill 77 289 558 80 289 558 minecraft:cobbled_deepslate
fill 77 289 580 77 290 582 minecraft:deepslate
setblock 77 289 598 minecraft:cobbled_deepslate
setblock 81 289 558 minecraft:calcite
setblock 82 289 558 minecraft:cobbled_deepslate
setblock 82 289 598 minecraft:cobbled_deepslate
setblock 86 289 558 minecraft:calcite
fill 86 289 581 86 289 582 minecraft:cobbled_deepslate
setblock 86 289 583 minecraft:calcite
fill 86 289 584 86 289 587 minecraft:cobbled_deepslate
setblock 86 289 588 minecraft:calcite
setblock 86 289 598 minecraft:calcite
fill 87 289 558 87 292 558 minecraft:cobbled_deepslate
setblock 87 289 562 minecraft:calcite
fill 87 289 563 87 292 563 minecraft:cobbled_deepslate
fill 87 289 578 87 289 581 minecraft:cobbled_deepslate
setblock 87 289 582 minecraft:calcite
fill 87 289 583 87 292 583 minecraft:cobbled_deepslate
setblock 87 289 586 minecraft:cobbled_deepslate
setblock 87 289 587 minecraft:calcite
fill 87 289 588 87 289 591 minecraft:cobbled_deepslate
setblock 87 289 592 minecraft:calcite
fill 87 289 593 87 292 593 minecraft:cobbled_deepslate
fill 87 289 598 87 292 598 minecraft:cobbled_deepslate
setblock 88 289 561 minecraft:calcite
fill 88 289 562 88 292 562 minecraft:cobbled_deepslate
setblock 88 289 566 minecraft:calcite
fill 88 289 567 88 292 567 minecraft:cobbled_deepslate
fill 88 289 574 88 289 575 minecraft:cobbled_deepslate
setblock 88 289 576 minecraft:calcite
fill 88 289 577 88 289 580 minecraft:cobbled_deepslate
setblock 88 289 581 minecraft:calcite
fill 88 289 582 88 292 582 minecraft:cobbled_deepslate
setblock 88 289 586 minecraft:calcite
fill 88 289 587 88 289 590 minecraft:cobbled_deepslate
setblock 88 289 591 minecraft:calcite
fill 88 289 592 88 292 592 minecraft:cobbled_deepslate
setblock 88 289 596 minecraft:calcite
fill 88 289 597 88 292 597 minecraft:cobbled_deepslate
fill 48 290 558 48 290 559 minecraft:cobbled_deepslate
setblock 48 290 560 minecraft:calcite
fill 48 290 561 48 290 564 minecraft:cobbled_deepslate
setblock 48 290 565 minecraft:calcite
fill 48 290 566 48 290 569 minecraft:cobbled_deepslate
setblock 48 290 570 minecraft:calcite
fill 48 290 571 48 290 574 minecraft:cobbled_deepslate
setblock 48 290 575 minecraft:calcite
fill 48 290 576 48 290 579 minecraft:cobbled_deepslate
setblock 48 290 580 minecraft:calcite
fill 48 290 581 48 290 584 minecraft:cobbled_deepslate
setblock 48 290 585 minecraft:calcite
fill 48 290 586 48 290 589 minecraft:cobbled_deepslate
setblock 48 290 590 minecraft:calcite
fill 48 290 591 48 293 591 minecraft:cobbled_deepslate
setblock 49 290 558 minecraft:cobbled_deepslate
fill 49 290 560 49 291 560 minecraft:cobbled_deepslate
setblock 49 290 564 minecraft:calcite
fill 49 290 565 49 290 568 minecraft:cobbled_deepslate
setblock 49 290 569 minecraft:calcite
fill 49 290 570 49 292 571 minecraft:cobbled_deepslate
setblock 49 290 574 minecraft:calcite
fill 49 290 575 49 290 578 minecraft:cobbled_deepslate
setblock 49 290 579 minecraft:calcite
fill 49 290 580 49 290 583 minecraft:cobbled_deepslate
setblock 49 290 584 minecraft:calcite
fill 49 290 585 49 293 585 minecraft:cobbled_deepslate
setblock 49 290 589 minecraft:calcite
fill 49 290 590 49 293 590 minecraft:cobbled_deepslate
setblock 50 290 558 minecraft:calcite
fill 50 290 579 50 290 582 minecraft:cobbled_deepslate
setblock 50 290 583 minecraft:calcite
fill 50 290 584 50 292 584 minecraft:cobbled_deepslate
fill 51 290 558 52 290 558 minecraft:cobbled_deepslate
fill 61 290 558 64 290 558 minecraft:cobbled_deepslate
fill 62 290 559 63 290 559 minecraft:cobbled_deepslate
setblock 64 290 559 minecraft:calcite
fill 64 290 560 67 290 560 minecraft:cobbled_deepslate
setblock 65 290 558 minecraft:calcite
fill 65 290 559 68 290 559 minecraft:cobbled_deepslate
fill 66 290 558 69 290 558 minecraft:cobbled_deepslate
setblock 66 290 561 minecraft:cobbled_deepslate
fill 66 290 598 69 290 598 minecraft:cobbled_deepslate
setblock 67 290 561 minecraft:calcite
setblock 68 290 560 minecraft:calcite
fill 68 290 561 70 290 561 minecraft:cobbled_deepslate
setblock 69 290 559 minecraft:calcite
fill 69 290 560 72 290 560 minecraft:cobbled_deepslate
setblock 70 290 558 minecraft:calcite
fill 70 290 559 73 290 559 minecraft:cobbled_deepslate
setblock 70 290 598 minecraft:calcite
fill 71 290 558 74 290 558 minecraft:cobbled_deepslate
fill 71 290 598 74 290 598 minecraft:cobbled_deepslate
fill 72 290 582 72 290 583 minecraft:deepslate
setblock 73 290 578 minecraft:deepslate
setblock 73 290 583 minecraft:deepslate
setblock 74 290 559 minecraft:calcite
fill 74 290 584 75 290 584 minecraft:deepslate
setblock 75 290 558 minecraft:calcite
fill 76 290 558 77 290 558 minecraft:cobbled_deepslate
setblock 76 290 578 minecraft:deepslate
setblock 77 290 579 minecraft:deepslate
setblock 77 290 583 minecraft:deepslate
fill 78 290 580 78 290 581 minecraft:deepslate
fill 84 290 595 84 297 595 minecraft:calcite
setblock 85 290 558 minecraft:calcite
setblock 85 290 598 minecraft:calcite
fill 86 290 558 86 292 558 minecraft:cobbled_deepslate
setblock 86 290 581 minecraft:cobbled_deepslate
setblock 86 290 582 minecraft:calcite
fill 86 290 583 86 290 586 minecraft:cobbled_deepslate
setblock 86 290 587 minecraft:calcite
fill 86 290 588 88 290 589 minecraft:cobbled_deepslate
fill 86 290 598 86 293 598 minecraft:cobbled_deepslate
setblock 87 290 561 minecraft:calcite
fill 87 290 562 87 291 562 minecraft:cobbled_deepslate
fill 87 290 578 87 290 580 minecraft:cobbled_deepslate
setblock 87 290 581 minecraft:calcite
fill 87 290 582 87 293 582 minecraft:cobbled_deepslate
setblock 87 290 585 minecraft:cobbled_deepslate
setblock 87 290 586 minecraft:calcite
fill 87 290 587 88 292 587 minecraft:cobbled_deepslate
setblock 87 290 590 minecraft:cobbled_deepslate
setblock 87 290 591 minecraft:calcite
fill 87 290 592 87 293 592 minecraft:cobbled_deepslate
setblock 88 290 560 minecraft:calcite
fill 88 290 561 88 293 561 minecraft:cobbled_deepslate
setblock 88 290 565 minecraft:calcite
fill 88 290 566 88 293 566 minecraft:cobbled_deepslate
setblock 88 290 569 minecraft:cobbled_deepslate
setblock 88 290 575 minecraft:calcite
fill 88 290 576 88 290 579 minecraft:cobbled_deepslate
setblock 88 290 580 minecraft:calcite
fill 88 290 581 88 293 581 minecraft:cobbled_deepslate
setblock 88 290 585 minecraft:calcite
fill 88 290 586 88 293 586 minecraft:cobbled_deepslate
setblock 88 290 590 minecraft:calcite
fill 88 290 591 88 293 591 minecraft:cobbled_deepslate
setblock 88 290 595 minecraft:calcite
fill 88 290 596 88 293 596 minecraft:cobbled_deepslate
setblock 48 291 558 minecraft:cobbled_deepslate
setblock 48 291 559 minecraft:calcite
fill 48 291 560 48 291 563 minecraft:cobbled_deepslate
setblock 48 291 564 minecraft:calcite
fill 48 291 565 48 291 568 minecraft:cobbled_deepslate
setblock 48 291 569 minecraft:calcite
fill 48 291 570 48 291 573 minecraft:cobbled_deepslate
setblock 48 291 574 minecraft:calcite
fill 48 291 575 48 291 578 minecraft:cobbled_deepslate
setblock 48 291 579 minecraft:calcite
fill 48 291 580 48 291 583 minecraft:cobbled_deepslate
setblock 48 291 584 minecraft:calcite
fill 48 291 585 48 291 588 minecraft:cobbled_deepslate
setblock 48 291 589 minecraft:calcite
fill 48 291 590 48 294 590 minecraft:cobbled_deepslate
setblock 49 291 558 minecraft:calcite
setblock 49 291 563 minecraft:calcite
fill 49 291 564 49 291 567 minecraft:cobbled_deepslate
setblock 49 291 568 minecraft:calcite
fill 49 291 569 49 294 569 minecraft:cobbled_deepslate
fill 49 291 575 49 291 577 minecraft:cobbled_deepslate
setblock 49 291 578 minecraft:calcite
fill 49 291 579 49 291 582 minecraft:cobbled_deepslate
setblock 49 291 583 minecraft:calcite
fill 49 291 584 49 294 584 minecraft:cobbled_deepslate
setblock 49 291 588 minecraft:calcite
fill 49 291 589 49 294 589 minecraft:cobbled_deepslate
setblock 50 291 558 minecraft:cobbled_deepslate
fill 50 291 580 50 291 581 minecraft:cobbled_deepslate
setblock 50 291 582 minecraft:calcite
fill 50 291 583 50 292 583 minecraft:cobbled_deepslate
fill 61 291 558 63 291 558 minecraft:cobbled_deepslate
setblock 62 291 559 minecraft:cobbled_deepslate
setblock 63 291 559 minecraft:calcite
setblock 64 291 558 minecraft:calcite
fill 64 291 559 66 291 560 minecraft:cobbled_deepslate
fill 65 291 558 68 291 558 minecraft:cobbled_deepslate
fill 66 291 598 68 291 598 minecraft:cobbled_deepslate
setblock 67 291 559 minecraft:cobbled_deepslate
setblock 67 291 560 minecraft:calcite
fill 67 291 561 68 291 561 minecraft:cobbled_deepslate
setblock 68 291 559 minecraft:calcite
fill 68 291 560 71 291 560 minecraft:cobbled_deepslate
setblock 69 291 558 minecraft:calcite
fill 69 291 559 72 291 559 minecraft:cobbled_deepslate
setblock 69 291 598 minecraft:calcite
fill 70 291 558 73 291 558 minecraft:cobbled_deepslate
fill 70 291 598 73 291 598 minecraft:cobbled_deepslate
setblock 73 291 559 minecraft:calcite
setblock 74 291 558 minecraft:calcite
setblock 75 291 558 minecraft:cobbled_deepslate
setblock 84 291 598 minecraft:calcite
setblock 85 291 558 minecraft:cobbled_deepslate
fill 85 291 598 85 294 598 minecraft:cobbled_deepslate
setblock 86 291 581 minecraft:calcite
fill 86 291 582 86 291 585 minecraft:cobbled_deepslate
setblock 86 291 586 minecraft:calcite
fill 86 291 587 86 291 590 minecraft:cobbled_deepslate
setblock 87 291 564 minecraft:cobbled_deepslate
fill 87 291 578 87 291 579 minecraft:cobbled_deepslate
setblock 87 291 580 minecraft:calcite
fill 87 291 581 87 294 581 minecraft:cobbled_deepslate
setblock 87 291 585 minecraft:calcite
fill 87 291 586 87 294 586 minecraft:cobbled_deepslate
fill 87 291 588 87 291 589 minecraft:cobbled_deepslate
setblock 87 291 590 minecraft:calcite
fill 87 291 591 87 294 591 minecraft:cobbled_deepslate
setblock 88 291 559 minecraft:calcite
fill 88 291 560 88 294 560 minecraft:cobbled_deepslate
setblock 88 291 564 minecraft:calcite
fill 88 291 565 88 294 565 minecraft:cobbled_deepslate
setblock 88 291 569 minecraft:calcite
fill 88 291 570 88 294 570 minecraft:cobbled_deepslate
fill 88 291 575 88 291 578 minecraft:cobbled_deepslate
setblock 88 291 579 minecraft:calcite
fill 88 291 580 88 294 580 minecraft:cobbled_deepslate
setblock 88 291 584 minecraft:calcite
fill 88 291 585 88 294 585 minecraft:cobbled_deepslate
setblock 88 291 588 minecraft:cobbled_deepslate
setblock 88 291 589 minecraft:calcite
fill 88 291 590 88 294 590 minecraft:cobbled_deepslate
setblock 88 291 594 minecraft:calcite
fill 88 291 595 88 294 595 minecraft:cobbled_deepslate
setblock 48 292 558 minecraft:calcite
fill 48 292 559 48 292 562 minecraft:cobbled_deepslate
setblock 48 292 563 minecraft:calcite
fill 48 292 564 48 292 567 minecraft:cobbled_deepslate
setblock 48 292 568 minecraft:calcite
fill 48 292 569 48 292 572 minecraft:cobbled_deepslate
setblock 48 292 573 minecraft:calcite
fill 48 292 574 48 292 577 minecraft:cobbled_deepslate
setblock 48 292 578 minecraft:calcite
fill 48 292 579 48 292 582 minecraft:cobbled_deepslate
setblock 48 292 583 minecraft:calcite
fill 48 292 584 48 292 587 minecraft:cobbled_deepslate
setblock 48 292 588 minecraft:calcite
fill 48 292 589 48 295 589 minecraft:cobbled_deepslate
setblock 48 292 593 minecraft:calcite
setblock 49 292 558 minecraft:cobbled_deepslate
setblock 49 292 562 minecraft:calcite
fill 49 292 563 49 292 566 minecraft:cobbled_deepslate
setblock 49 292 567 minecraft:calcite
fill 49 292 568 49 295 568 minecraft:cobbled_deepslate
setblock 49 292 572 minecraft:calcite
setblock 49 292 576 minecraft:cobbled_deepslate
setblock 49 292 577 minecraft:calcite
fill 49 292 578 49 292 581 minecraft:cobbled_deepslate
setblock 49 292 582 minecraft:calcite
fill 49 292 583 49 295 583 minecraft:cobbled_deepslate
setblock 49 292 587 minecraft:calcite
fill 49 292 588 49 295 588 minecraft:cobbled_deepslate
setblock 50 292 560 minecraft:light[level=14]
setblock 50 292 565 minecraft:cobbled_deepslate
setblock 50 292 568 minecraft:light[level=14]
setblock 50 292 576 minecraft:light[level=14]
setblock 50 292 582 minecraft:cobbled_deepslate
setblock 50 292 586 minecraft:calcite
setblock 50 292 592 minecraft:light[level=14]
setblock 58 292 560 minecraft:light[level=14]
setblock 58 292 568 minecraft:light[level=14]
setblock 58 292 576 minecraft:light[level=14]
setblock 58 292 584 minecraft:light[level=14]
setblock 58 292 592 minecraft:light[level=14]
fill 61 292 558 62 292 558 minecraft:cobbled_deepslate
setblock 62 292 559 minecraft:calcite
setblock 63 292 558 minecraft:calcite
fill 63 292 559 66 292 559 minecraft:cobbled_deepslate
fill 64 292 558 67 292 558 minecraft:cobbled_deepslate
fill 64 292 560 65 292 560 minecraft:cobbled_deepslate
fill 65 292 598 67 292 598 minecraft:cobbled_deepslate
setblock 66 292 560 minecraft:calcite
setblock 66 292 568 minecraft:light[level=14]
setblock 66 292 576 minecraft:light[level=14]
setblock 66 292 584 minecraft:light[level=14]
setblock 66 292 592 minecraft:light[level=14]
setblock 67 292 559 minecraft:calcite
fill 67 292 560 70 292 560 minecraft:cobbled_deepslate
setblock 68 292 558 minecraft:calcite
fill 68 292 559 71 292 559 minecraft:cobbled_deepslate
setblock 68 292 598 minecraft:calcite
fill 69 292 558 72 292 558 minecraft:cobbled_deepslate
fill 69 292 598 72 292 598 minecraft:cobbled_deepslate
setblock 72 292 559 minecraft:calcite
setblock 73 292 558 minecraft:calcite
setblock 74 292 558 minecraft:cobbled_deepslate
setblock 74 292 560 minecraft:light[level=14]
setblock 74 292 568 minecraft:light[level=14]
setblock 74 292 576 minecraft:light[level=14]
setblock 74 292 584 minecraft:light[level=14]
setblock 74 292 592 minecraft:light[level=14]
setblock 82 292 560 minecraft:light[level=14]
setblock 82 292 568 minecraft:light[level=14]
setblock 82 292 576 minecraft:light[level=14]
setblock 82 292 584 minecraft:light[level=14]
setblock 82 292 592 minecraft:light[level=14]
fill 84 292 598 84 295 598 minecraft:cobbled_deepslate
fill 86 292 581 86 292 584 minecraft:cobbled_deepslate
setblock 86 292 585 minecraft:calcite
fill 86 292 586 86 292 589 minecraft:cobbled_deepslate
setblock 86 292 590 minecraft:calcite
fill 86 292 591 86 295 591 minecraft:cobbled_deepslate
setblock 87 292 564 minecraft:calcite
fill 87 292 565 87 294 566 minecraft:cobbled_deepslate
setblock 87 292 579 minecraft:calcite
fill 87 292 580 87 295 580 minecraft:cobbled_deepslate
setblock 87 292 584 minecraft:calcite
fill 87 292 585 87 295 585 minecraft:cobbled_deepslate
setblock 87 292 588 minecraft:cobbled_deepslate
setblock 87 292 589 minecraft:calcite
fill 87 292 590 87 295 590 minecraft:cobbled_deepslate
setblock 88 292 558 minecraft:calcite
fill 88 292 559 88 293 559 minecraft:cobbled_deepslate
setblock 88 292 563 minecraft:calcite
fill 88 292 564 88 295 564 minecraft:cobbled_deepslate
setblock 88 292 568 minecraft:calcite
fill 88 292 569 88 295 569 minecraft:cobbled_deepslate
fill 88 292 571 88 292 572 minecraft:cobbled_deepslate
setblock 88 292 573 minecraft:calcite
fill 88 292 574 88 292 577 minecraft:cobbled_deepslate
setblock 88 292 578 minecraft:calcite
fill 88 292 579 88 295 579 minecraft:cobbled_deepslate
setblock 88 292 583 minecraft:calcite
fill 88 292 584 88 295 584 minecraft:cobbled_deepslate
setblock 88 292 588 minecraft:calcite
fill 88 292 589 88 295 589 minecraft:cobbled_deepslate
setblock 88 292 593 minecraft:calcite
fill 88 292 594 88 295 594 minecraft:cobbled_deepslate
setblock 88 292 598 minecraft:calcite
fill 48 293 559 48 293 561 minecraft:cobbled_deepslate
setblock 48 293 562 minecraft:calcite
fill 48 293 563 48 293 566 minecraft:cobbled_deepslate
setblock 48 293 567 minecraft:calcite
fill 48 293 568 48 293 571 minecraft:cobbled_deepslate
setblock 48 293 572 minecraft:calcite
fill 48 293 573 48 293 576 minecraft:cobbled_deepslate
setblock 48 293 577 minecraft:calcite
fill 48 293 578 48 293 581 minecraft:cobbled_deepslate
setblock 48 293 582 minecraft:calcite
fill 48 293 583 48 293 586 minecraft:cobbled_deepslate
setblock 48 293 587 minecraft:calcite
fill 48 293 588 48 296 588 minecraft:cobbled_deepslate
setblock 48 293 592 minecraft:calcite
fill 48 293 593 48 296 593 minecraft:cobbled_deepslate
setblock 49 293 561 minecraft:calcite
fill 49 293 562 49 293 565 minecraft:cobbled_deepslate
setblock 49 293 566 minecraft:calcite
fill 49 293 567 50 295 567 minecraft:cobbled_deepslate
setblock 49 293 570 minecraft:cobbled_deepslate
setblock 49 293 571 minecraft:calcite
fill 49 293 572 49 294 574 minecraft:cobbled_deepslate
fill 49 293 577 49 293 580 minecraft:cobbled_deepslate
setblock 49 293 581 minecraft:calcite
fill 49 293 582 49 296 582 minecraft:cobbled_deepslate
setblock 49 293 586 minecraft:calcite
fill 49 293 587 49 296 587 minecraft:cobbled_deepslate
setblock 50 293 565 minecraft:calcite
fill 50 293 566 50 296 566 minecraft:cobbled_deepslate
fill 51 293 596 51 298 596 minecraft:calcite
setblock 61 293 558 minecraft:cobbled_deepslate
setblock 62 293 558 minecraft:calcite
fill 62 293 559 65 293 559 minecraft:cobbled_deepslate
fill 63 293 558 66 293 558 minecraft:cobbled_deepslate
setblock 64 293 560 minecraft:cobbled_deepslate
setblock 65 293 560 minecraft:calcite
fill 65 293 598 66 293 598 minecraft:cobbled_deepslate
setblock 66 293 559 minecraft:calcite
fill 66 293 560 69 293 560 minecraft:cobbled_deepslate
setblock 67 293 558 minecraft:calcite
fill 67 293 559 70 293 559 minecraft:cobbled_deepslate
setblock 67 293 598 minecraft:calcite
fill 68 293 558 71 293 558 minecraft:cobbled_deepslate
fill 68 293 598 71 293 598 minecraft:cobbled_deepslate
setblock 71 293 559 minecraft:calcite
setblock 72 293 558 minecraft:calcite
setblock 72 293 598 minecraft:calcite
setblock 73 293 558 minecraft:cobbled_deepslate
fill 83 293 595 83 297 595 minecraft:calcite
fill 83 293 598 83 296 598 minecraft:cobbled_deepslate
fill 84 293 594 84 297 594 minecraft:calcite
fill 84 293 596 84 298 596 minecraft:calcite
setblock 85 293 585 minecraft:calcite
fill 85 293 586 86 293 588 minecraft:cobbled_deepslate
fill 85 293 595 85 297 595 minecraft:calcite
fill 86 293 581 86 293 583 minecraft:cobbled_deepslate
setblock 86 293 584 minecraft:calcite
fill 86 293 585 86 296 585 minecraft:cobbled_deepslate
setblock 86 293 589 minecraft:calcite
fill 86 293 590 86 296 590 minecraft:cobbled_deepslate
fill 86 293 592 86 294 592 minecraft:cobbled_deepslate
setblock 87 293 563 minecraft:calcite
fill 87 293 564 87 296 564 minecraft:cobbled_deepslate
setblock 87 293 567 minecraft:cobbled_deepslate
setblock 87 293 568 minecraft:calcite
setblock 87 293 578 minecraft:calcite
fill 87 293 579 87 296 579 minecraft:cobbled_deepslate
setblock 87 293 583 minecraft:calcite
fill 87 293 584 87 296 584 minecraft:cobbled_deepslate
setblock 87 293 587 minecraft:cobbled_deepslate
setblock 87 293 588 minecraft:calcite
fill 87 293 589 87 296 589 minecraft:cobbled_deepslate
setblock 87 293 593 minecraft:calcite
fill 87 293 594 87 296 594 minecraft:cobbled_deepslate
setblock 87 293 598 minecraft:calcite
setblock 88 293 562 minecraft:calcite
fill 88 293 563 88 296 563 minecraft:cobbled_deepslate
setblock 88 293 567 minecraft:calcite
fill 88 293 568 88 296 568 minecraft:cobbled_deepslate
setblock 88 293 571 minecraft:cobbled_deepslate
setblock 88 293 572 minecraft:calcite
fill 88 293 573 88 293 576 minecraft:cobbled_deepslate
setblock 88 293 577 minecraft:calcite
fill 88 293 578 88 296 578 minecraft:cobbled_deepslate
setblock 88 293 582 minecraft:calcite
fill 88 293 583 88 296 583 minecraft:cobbled_deepslate
setblock 88 293 587 minecraft:calcite
fill 88 293 588 88 296 588 minecraft:cobbled_deepslate
setblock 88 293 592 minecraft:calcite
fill 88 293 593 88 296 593 minecraft:cobbled_deepslate
setblock 88 293 597 minecraft:calcite
fill 88 293 598 88 296 598 minecraft:cobbled_deepslate
fill 48 294 559 48 294 560 minecraft:cobbled_deepslate
setblock 48 294 561 minecraft:calcite
fill 48 294 562 48 294 565 minecraft:cobbled_deepslate
setblock 48 294 566 minecraft:calcite
fill 48 294 567 48 294 570 minecraft:cobbled_deepslate
setblock 48 294 571 minecraft:calcite
fill 48 294 572 48 294 575 minecraft:cobbled_deepslate
setblock 48 294 576 minecraft:calcite
fill 48 294 577 48 294 580 minecraft:cobbled_deepslate
setblock 48 294 581 minecraft:calcite
fill 48 294 582 48 294 585 minecraft:cobbled_deepslate
setblock 48 294 586 minecraft:calcite
fill 48 294 587 48 297 587 minecraft:cobbled_deepslate
setblock 48 294 591 minecraft:calcite
fill 48 294 592 48 297 592 minecraft:cobbled_deepslate
fill 48 294 594 48 295 594 minecraft:cobbled_deepslate
fill 49 294 561 49 294 564 minecraft:cobbled_deepslate
setblock 49 294 565 minecraft:calcite
fill 49 294 566 49 297 566 minecraft:cobbled_deepslate
setblock 49 294 570 minecraft:calcite
fill 49 294 571 49 297 571 minecraft:cobbled_deepslate
setblock 49 294 575 minecraft:calcite
fill 49 294 577 49 294 579 minecraft:cobbled_deepslate
setblock 49 294 580 minecraft:calcite
fill 49 294 581 49 296 581 minecraft:cobbled_deepslate
setblock 49 294 585 minecraft:calcite
fill 49 294 586 49 297 586 minecraft:cobbled_deepslate
setblock 49 294 590 minecraft:calcite
setblock 50 294 564 minecraft:calcite
fill 50 294 565 50 297 565 minecraft:cobbled_deepslate
setblock 50 294 568 minecraft:cobbled_deepslate
setblock 50 294 569 minecraft:calcite
setblock 60 294 558 minecraft:cobbled_deepslate
setblock 61 294 558 minecraft:calcite
fill 62 294 558 64 294 559 minecraft:cobbled_deepslate
setblock 63 294 560 minecraft:cobbled_deepslate
setblock 64 294 560 minecraft:calcite
fill 64 294 598 65 294 598 minecraft:cobbled_deepslate
setblock 65 294 558 minecraft:cobbled_deepslate
setblock 65 294 559 minecraft:calcite
fill 65 294 560 68 294 560 minecraft:cobbled_deepslate
setblock 66 294 558 minecraft:calcite
fill 66 294 559 69 294 559 minecraft:cobbled_deepslate
setblock 66 294 598 minecraft:calcite
fill 67 294 558 70 294 558 minecraft:cobbled_deepslate
fill 67 294 598 70 294 598 minecraft:cobbled_deepslate
setblock 70 294 559 minecraft:calcite
setblock 71 294 558 minecraft:calcite
setblock 71 294 598 minecraft:calcite
fill 72 294 558 72 295 558 minecraft:cobbled_deepslate
fill 72 294 598 72 297 598 minecraft:cobbled_deepslate
fill 82 294 598 82 297 598 minecraft:cobbled_deepslate
setblock 85 294 584 minecraft:calcite
fill 85 294 585 85 294 588 minecraft:cobbled_deepslate
setblock 85 294 589 minecraft:calcite
fill 85 294 590 85 297 590 minecraft:cobbled_deepslate
fill 86 294 581 86 294 582 minecraft:cobbled_deepslate
setblock 86 294 583 minecraft:calcite
fill 86 294 584 86 297 584 minecraft:cobbled_deepslate
fill 86 294 586 86 294 587 minecraft:cobbled_deepslate
setblock 86 294 588 minecraft:calcite
fill 86 294 589 86 297 589 minecraft:cobbled_deepslate
setblock 86 294 598 minecraft:calcite
fill 87 294 563 87 297 563 minecraft:cobbled_deepslate
setblock 87 294 567 minecraft:calcite
fill 87 294 568 87 294 571 minecraft:cobbled_deepslate
fill 87 294 578 87 297 578 minecraft:cobbled_deepslate
setblock 87 294 582 minecraft:calcite
fill 87 294 583 87 297 583 minecraft:cobbled_deepslate
setblock 87 294 587 minecraft:calcite
fill 87 294 588 87 297 588 minecraft:cobbled_deepslate
setblock 87 294 592 minecraft:calcite
fill 87 294 593 87 297 593 minecraft:cobbled_deepslate
fill 87 294 595 87 295 595 minecraft:cobbled_deepslate
fill 87 294 598 87 297 598 minecraft:cobbled_deepslate
setblock 88 294 561 minecraft:calcite
fill 88 294 562 88 297 562 minecraft:cobbled_deepslate
setblock 88 294 566 minecraft:calcite
fill 88 294 567 88 297 567 minecraft:cobbled_deepslate
setblock 88 294 571 minecraft:calcite
fill 88 294 572 88 294 575 minecraft:cobbled_deepslate
setblock 88 294 576 minecraft:calcite
fill 88 294 577 88 297 577 minecraft:cobbled_deepslate
setblock 88 294 581 minecraft:calcite
fill 88 294 582 88 297 582 minecraft:cobbled_deepslate
setblock 88 294 586 minecraft:calcite
fill 88 294 587 88 297 587 minecraft:cobbled_deepslate
setblock 88 294 591 minecraft:calcite
fill 88 294 592 88 297 592 minecraft:cobbled_deepslate
setblock 88 294 596 minecraft:calcite
fill 88 294 597 88 297 597 minecraft:cobbled_deepslate
setblock 48 295 559 minecraft:cobbled_deepslate
setblock 48 295 560 minecraft:calcite
fill 48 295 561 48 295 564 minecraft:cobbled_deepslate
setblock 48 295 565 minecraft:calcite
fill 48 295 566 48 295 569 minecraft:cobbled_deepslate
setblock 48 295 570 minecraft:calcite
fill 48 295 571 48 295 574 minecraft:cobbled_deepslate
setblock 48 295 575 minecraft:calcite
fill 48 295 576 48 295 579 minecraft:cobbled_deepslate
setblock 48 295 580 minecraft:calcite
fill 48 295 581 48 295 584 minecraft:cobbled_deepslate
setblock 48 295 585 minecraft:calcite
fill 48 295 586 48 298 586 minecraft:cobbled_deepslate
setblock 48 295 590 minecraft:calcite
fill 48 295 591 49 297 591 minecraft:cobbled_deepslate
fill 49 295 561 49 295 563 minecraft:cobbled_deepslate
setblock 49 295 564 minecraft:calcite
fill 49 295 565 49 298 565 minecraft:cobbled_deepslate
setblock 49 295 569 minecraft:calcite
fill 49 295 570 50 297 570 minecraft:cobbled_deepslate
fill 49 295 572 49 295 573 minecraft:cobbled_deepslate
setblock 49 295 574 minecraft:calcite
fill 49 295 575 49 295 578 minecraft:cobbled_deepslate
setblock 49 295 579 minecraft:calcite
fill 49 295 580 49 296 580 minecraft:cobbled_deepslate
setblock 49 295 584 minecraft:calcite
fill 49 295 585 49 298 585 minecraft:cobbled_deepslate
setblock 49 295 589 minecraft:calcite
fill 49 295 590 49 298 590 minecraft:cobbled_deepslate
fill 50 295 564 50 296 564 minecraft:cobbled_deepslate
setblock 50 295 568 minecraft:calcite
fill 50 295 569 50 298 569 minecraft:cobbled_deepslate
setblock 59 295 558 minecraft:cobbled_deepslate
setblock 60 295 558 minecraft:calcite
fill 61 295 558 63 295 559 minecraft:cobbled_deepslate
fill 62 295 598 64 295 598 minecraft:cobbled_deepslate
setblock 63 295 560 minecraft:calcite
setblock 64 295 558 minecraft:cobbled_deepslate
setblock 64 295 559 minecraft:calcite
fill 64 295 560 67 295 560 minecraft:cobbled_deepslate
setblock 65 295 558 minecraft:calcite
fill 65 295 559 68 295 559 minecraft:cobbled_deepslate
setblock 65 295 597 minecraft:cobbled_deepslate
setblock 65 295 598 minecraft:calcite
fill 66 295 558 69 295 558 minecraft:cobbled_deepslate
setblock 66 295 597 minecraft:calcite
fill 66 295 598 69 295 598 minecraft:cobbled_deepslate
fill 67 295 597 68 297 597 minecraft:cobbled_deepslate
setblock 68 295 560 minecraft:calcite
setblock 69 295 559 minecraft:calcite
setblock 70 295 558 minecraft:calcite
setblock 70 295 559 minecraft:cobbled_deepslate
setblock 70 295 598 minecraft:calcite
fill 71 295 558 71 298 558 minecraft:cobbled_deepslate
fill 71 295 598 71 298 598 minecraft:cobbled_deepslate
fill 81 295 598 81 298 598 minecraft:cobbled_deepslate
fill 83 295 594 83 297 594 minecraft:calcite
fill 83 295 596 83 297 596 minecraft:calcite
fill 85 295 584 85 295 587 minecraft:cobbled_deepslate
setblock 85 295 588 minecraft:calcite
fill 85 295 589 85 298 589 minecraft:cobbled_deepslate
fill 85 295 591 85 296 591 minecraft:cobbled_deepslate
fill 85 295 594 85 297 594 minecraft:calcite
fill 85 295 596 85 297 596 minecraft:calcite
setblock 85 295 598 minecraft:calcite
setblock 86 295 581 minecraft:cobbled_deepslate
setblock 86 295 582 minecraft:calcite
fill 86 295 583 86 298 583 minecraft:cobbled_deepslate
setblock 86 295 586 minecraft:cobbled_deepslate
setblock 86 295 587 minecraft:calcite
fill 86 295 588 86 298 588 minecraft:cobbled_deepslate
setblock 86 295 592 minecraft:calcite
fill 86 295 593 86 298 593 minecraft:cobbled_deepslate
fill 86 295 598 86 298 598 minecraft:cobbled_deepslate
setblock 87 295 565 minecraft:cobbled_deepslate
setblock 87 295 566 minecraft:calcite
fill 87 295 567 87 295 570 minecraft:cobbled_deepslate
setblock 87 295 571 minecraft:calcite
fill 87 295 572 87 295 575 minecraft:cobbled_deepslate
setblock 87 295 576 minecraft:calcite
fill 87 295 577 87 298 577 minecraft:cobbled_deepslate
setblock 87 295 581 minecraft:calcite
fill 87 295 582 87 298 582 minecraft:cobbled_deepslate
setblock 87 295 586 minecraft:calcite
fill 87 295 587 87 298 587 minecraft:cobbled_deepslate
setblock 87 295 591 minecraft:calcite
fill 87 295 592 87 298 592 minecraft:cobbled_deepslate
setblock 88 295 560 minecraft:calcite
fill 88 295 561 88 298 561 minecraft:cobbled_deepslate
setblock 88 295 565 minecraft:calcite
fill 88 295 566 88 298 566 minecraft:cobbled_deepslate
setblock 88 295 570 minecraft:calcite
fill 88 295 571 88 295 574 minecraft:cobbled_deepslate
setblock 88 295 575 minecraft:calcite
fill 88 295 576 88 298 576 minecraft:cobbled_deepslate
setblock 88 295 580 minecraft:calcite
fill 88 295 581 88 298 581 minecraft:cobbled_deepslate
setblock 88 295 585 minecraft:calcite
fill 88 295 586 88 298 586 minecraft:cobbled_deepslate
setblock 88 295 590 minecraft:calcite
fill 88 295 591 88 298 591 minecraft:cobbled_deepslate
setblock 88 295 595 minecraft:calcite
fill 88 295 596 88 298 596 minecraft:cobbled_deepslate
setblock 48 296 559 minecraft:calcite
fill 48 296 560 48 296 563 minecraft:cobbled_deepslate
setblock 48 296 564 minecraft:calcite
fill 48 296 565 48 296 568 minecraft:cobbled_deepslate
setblock 48 296 569 minecraft:calcite
fill 48 296 570 48 296 573 minecraft:cobbled_deepslate
setblock 48 296 574 minecraft:calcite
fill 48 296 575 48 296 578 minecraft:cobbled_deepslate
setblock 48 296 579 minecraft:calcite
fill 48 296 580 48 296 583 minecraft:cobbled_deepslate
setblock 48 296 584 minecraft:calcite
fill 48 296 585 48 299 585 minecraft:cobbled_deepslate
setblock 48 296 589 minecraft:calcite
fill 48 296 590 48 299 590 minecraft:cobbled_deepslate
setblock 48 296 594 minecraft:calcite
fill 48 296 595 48 299 595 minecraft:cobbled_deepslate
setblock 49 296 562 minecraft:cobbled_deepslate
setblock 49 296 563 minecraft:calcite
fill 49 296 564 49 299 564 minecraft:cobbled_deepslate
setblock 49 296 567 minecraft:cobbled_deepslate
setblock 49 296 568 minecraft:calcite
fill 49 296 569 49 299 569 minecraft:cobbled_deepslate
setblock 49 296 572 minecraft:cobbled_deepslate
setblock 49 296 573 minecraft:calcite
fill 49 296 574 49 296 577 minecraft:cobbled_deepslate
setblock 49 296 583 minecraft:calcite
fill 49 296 584 49 297 584 minecraft:cobbled_deepslate
setblock 49 296 588 minecraft:calcite
fill 49 296 589 49 299 589 minecraft:cobbled_deepslate
setblock 50 296 567 minecraft:calcite
fill 50 296 568 50 299 568 minecraft:cobbled_deepslate
setblock 50 296 571 minecraft:cobbled_deepslate
fill 50 296 587 50 297 589 minecraft:light_blue_stained_glass
fill 51 296 588 51 298 588 minecraft:light_blue_stained_glass
setblock 59 296 558 minecraft:calcite
fill 60 296 558 62 296 559 minecraft:cobbled_deepslate
fill 61 296 598 63 296 598 minecraft:cobbled_deepslate
setblock 62 296 560 minecraft:calcite
setblock 63 296 558 minecraft:cobbled_deepslate
setblock 63 296 559 minecraft:calcite
fill 63 296 560 66 296 560 minecraft:cobbled_deepslate
setblock 64 296 558 minecraft:calcite
fill 64 296 559 67 296 559 minecraft:cobbled_deepslate
setblock 64 296 597 minecraft:cobbled_deepslate
setblock 64 296 598 minecraft:calcite
fill 65 296 558 68 296 558 minecraft:cobbled_deepslate
setblock 65 296 597 minecraft:calcite
fill 65 296 598 68 296 598 minecraft:cobbled_deepslate
fill 66 296 597 66 299 597 minecraft:cobbled_deepslate
setblock 67 296 560 minecraft:calcite
setblock 68 296 559 minecraft:calcite
setblock 69 296 558 minecraft:calcite
fill 69 296 559 69 297 559 minecraft:cobbled_deepslate
setblock 69 296 597 minecraft:cobbled_deepslate
setblock 69 296 598 minecraft:calcite
fill 70 296 558 70 299 558 minecraft:cobbled_deepslate
fill 70 296 598 70 299 598 minecraft:cobbled_deepslate
setblock 73 296 598 minecraft:cobbled_deepslate
setblock 79 296 598 minecraft:calcite
fill 80 296 598 80 299 598 minecraft:cobbled_deepslate
fill 82 296 597 84 296 597 minecraft:cobbled_deepslate
setblock 84 296 558 minecraft:calcite
setblock 84 296 588 minecraft:calcite
setblock 84 296 598 minecraft:calcite
fill 85 296 558 85 298 558 minecraft:cobbled_deepslate
fill 85 296 584 85 296 586 minecraft:cobbled_deepslate
setblock 85 296 587 minecraft:calcite
fill 85 296 588 85 299 588 minecraft:cobbled_deepslate
setblock 85 296 592 minecraft:calcite
setblock 85 296 597 minecraft:calcite
fill 85 296 598 85 299 598 minecraft:cobbled_deepslate
setblock 86 296 566 minecraft:calcite
fill 86 296 567 86 296 570 minecraft:cobbled_deepslate
setblock 86 296 571 minecraft:calcite
setblock 86 296 581 minecraft:calcite
fill 86 296 582 86 299 582 minecraft:cobbled_deepslate
setblock 86 296 586 minecraft:calcite
fill 86 296 587 86 299 587 minecraft:cobbled_deepslate
setblock 86 296 591 minecraft:calcite
fill 86 296 592 86 299 592 minecraft:cobbled_deepslate
fill 86 296 594 86 297 594 minecraft:cobbled_deepslate
fill 86 296 597 86 299 597 minecraft:cobbled_deepslate
setblock 87 296 565 minecraft:calcite
fill 87 296 566 87 296 569 minecraft:cobbled_deepslate
setblock 87 296 570 minecraft:calcite
fill 87 296 571 87 296 574 minecraft:cobbled_deepslate
setblock 87 296 575 minecraft:calcite
fill 87 296 576 87 299 576 minecraft:cobbled_deepslate
setblock 87 296 580 minecraft:calcite
fill 87 296 581 87 299 581 minecraft:cobbled_deepslate
setblock 87 296 585 minecraft:calcite
fill 87 296 586 87 299 586 minecraft:cobbled_deepslate
setblock 87 296 590 minecraft:calcite
fill 87 296 591 87 299 591 minecraft:cobbled_deepslate
setblock 87 296 595 minecraft:calcite
fill 87 296 596 87 299 596 minecraft:cobbled_deepslate
setblock 88 296 560 minecraft:cobbled_deepslate
setblock 88 296 564 minecraft:calcite
fill 88 296 565 88 299 565 minecraft:cobbled_deepslate
setblock 88 296 569 minecraft:calcite
fill 88 296 570 88 296 573 minecraft:cobbled_deepslate
setblock 88 296 574 minecraft:calcite
fill 88 296 575 88 299 575 minecraft:cobbled_deepslate
setblock 88 296 579 minecraft:calcite
fill 88 296 580 88 299 580 minecraft:cobbled_deepslate
setblock 88 296 584 minecraft:calcite
fill 88 296 585 88 299 585 minecraft:cobbled_deepslate
setblock 88 296 589 minecraft:calcite
fill 88 296 590 88 299 590 minecraft:cobbled_deepslate
setblock 88 296 594 minecraft:calcite
fill 88 296 595 88 299 595 minecraft:cobbled_deepslate
fill 48 297 559 48 297 562 minecraft:cobbled_deepslate
setblock 48 297 563 minecraft:calcite
fill 48 297 564 48 297 567 minecraft:cobbled_deepslate
setblock 48 297 568 minecraft:calcite
fill 48 297 569 48 297 572 minecraft:cobbled_deepslate
setblock 48 297 573 minecraft:calcite
fill 48 297 574 48 297 577 minecraft:cobbled_deepslate
setblock 48 297 578 minecraft:calcite
fill 48 297 579 48 297 582 minecraft:cobbled_deepslate
setblock 48 297 583 minecraft:calcite
fill 48 297 584 48 300 584 minecraft:cobbled_deepslate
setblock 48 297 588 minecraft:calcite
fill 48 297 589 48 300 589 minecraft:cobbled_deepslate
setblock 48 297 593 minecraft:calcite
fill 48 297 594 48 300 594 minecraft:cobbled_deepslate
setblock 49 297 562 minecraft:calcite
fill 49 297 563 49 299 563 minecraft:cobbled_deepslate
setblock 49 297 567 minecraft:calcite
fill 49 297 568 49 300 568 minecraft:cobbled_deepslate
setblock 49 297 572 minecraft:calcite
fill 49 297 573 49 297 576 minecraft:cobbled_deepslate
setblock 49 297 577 minecraft:calcite
setblock 49 297 582 minecraft:calcite
setblock 49 297 583 minecraft:cobbled_deepslate
setblock 49 297 587 minecraft:calcite
fill 49 297 588 49 299 588 minecraft:cobbled_deepslate
setblock 49 297 592 minecraft:calcite
setblock 50 297 566 minecraft:calcite
fill 50 297 567 50 300 567 minecraft:cobbled_deepslate
setblock 50 297 571 minecraft:calcite
fill 50 297 572 50 300 572 minecraft:cobbled_deepslate
fill 50 297 596 50 298 596 minecraft:calcite
fill 51 297 587 52 297 587 minecraft:light_blue_stained_glass
fill 51 297 589 52 297 589 minecraft:light_blue_stained_glass
fill 51 297 595 51 298 595 minecraft:calcite
fill 51 297 597 51 298 597 minecraft:calcite
fill 52 297 588 53 298 588 minecraft:light_blue_stained_glass
fill 52 297 596 52 298 596 minecraft:calcite
setblock 58 297 558 minecraft:calcite
fill 59 297 558 62 297 558 minecraft:cobbled_deepslate
fill 60 297 559 61 297 559 minecraft:cobbled_deepslate
fill 60 297 598 62 297 598 minecraft:cobbled_deepslate
setblock 62 297 559 minecraft:calcite
fill 62 297 560 65 297 560 minecraft:cobbled_deepslate
fill 62 297 597 63 297 597 minecraft:cobbled_deepslate
setblock 63 297 558 minecraft:calcite
fill 63 297 559 66 297 559 minecraft:cobbled_deepslate
setblock 63 297 598 minecraft:calcite
fill 64 297 558 67 297 558 minecraft:cobbled_deepslate
setblock 64 297 597 minecraft:calcite
fill 64 297 598 67 297 598 minecraft:cobbled_deepslate
setblock 65 297 596 minecraft:calcite
fill 65 297 597 65 300 597 minecraft:cobbled_deepslate
setblock 66 297 560 minecraft:calcite
fill 66 297 596 67 299 596 minecraft:cobbled_deepslate
setblock 67 297 559 minecraft:calcite
setblock 67 297 560 minecraft:cobbled_deepslate
setblock 68 297 558 minecraft:calcite
fill 68 297 559 68 298 559 minecraft:cobbled_deepslate
setblock 68 297 598 minecraft:calcite
fill 69 297 558 69 300 558 minecraft:cobbled_deepslate
setblock 69 297 597 minecraft:calcite
fill 69 297 598 69 300 598 minecraft:cobbled_deepslate
fill 70 297 597 70 300 597 minecraft:cobbled_deepslate
fill 71 297 580 72 297 581 minecraft:diamond_block
fill 72 297 579 73 298 579 minecraft:diamond_block
fill 72 297 582 73 297 583 minecraft:diamond_block
fill 73 297 578 77 297 578 minecraft:diamond_block
fill 73 297 584 76 297 584 minecraft:diamond_block
setblock 73 297 598 minecraft:calcite
fill 74 297 577 75 297 577 minecraft:diamond_block
fill 74 297 583 77 297 583 minecraft:diamond_block
fill 74 297 598 77 297 598 minecraft:cobbled_deepslate
fill 76 297 579 78 297 579 minecraft:diamond_block
fill 77 297 580 78 297 582 minecraft:diamond_block
setblock 78 297 598 minecraft:calcite
fill 79 297 598 79 300 598 minecraft:cobbled_deepslate
fill 80 297 597 83 297 597 minecraft:cobbled_deepslate
setblock 82 297 595 minecraft:calcite
setblock 83 297 558 minecraft:calcite
setblock 83 297 598 minecraft:calcite
fill 84 297 558 84 299 558 minecraft:cobbled_deepslate
setblock 84 297 587 minecraft:calcite
fill 84 297 588 84 298 590 minecraft:cobbled_deepslate
setblock 84 297 593 minecraft:calcite
setblock 84 297 597 minecraft:calcite
fill 84 297 598 84 300 598 minecraft:cobbled_deepslate
fill 85 297 584 85 297 585 minecraft:cobbled_deepslate
setblock 85 297 586 minecraft:calcite
fill 85 297 587 85 300 587 minecraft:cobbled_deepslate
setblock 85 297 591 minecraft:calcite
fill 85 297 592 85 299 593 minecraft:cobbled_deepslate
fill 85 297 597 85 300 597 minecraft:cobbled_deepslate
fill 86 297 566 86 297 569 minecraft:cobbled_deepslate
setblock 86 297 570 minecraft:calcite
fill 86 297 571 87 297 573 minecraft:cobbled_deepslate
fill 86 297 581 86 299 581 minecraft:cobbled_deepslate
setblock 86 297 585 minecraft:calcite
fill 86 297 586 86 300 586 minecraft:cobbled_deepslate
setblock 86 297 590 minecraft:calcite
fill 86 297 591 86 300 591 minecraft:cobbled_deepslate
setblock 86 297 595 minecraft:calcite
setblock 87 297 564 minecraft:calcite
fill 87 297 565 87 297 568 minecraft:cobbled_deepslate
setblock 87 297 569 minecraft:calcite
fill 87 297 570 88 299 570 minecraft:cobbled_deepslate
setblock 87 297 574 minecraft:calcite
fill 87 297 575 87 300 575 minecraft:cobbled_deepslate
setblock 87 297 579 minecraft:calcite
fill 87 297 580 87 300 580 minecraft:cobbled_deepslate
setblock 87 297 584 minecraft:calcite
fill 87 297 585 87 300 585 minecraft:cobbled_deepslate
setblock 87 297 589 minecraft:calcite
fill 87 297 590 87 300 590 minecraft:cobbled_deepslate
setblock 87 297 594 minecraft:calcite
fill 87 297 595 87 300 595 minecraft:cobbled_deepslate
setblock 88 297 563 minecraft:calcite
fill 88 297 564 88 300 564 minecraft:cobbled_deepslate
setblock 88 297 568 minecraft:calcite
fill 88 297 569 88 300 569 minecraft:cobbled_deepslate
fill 88 297 571 88 297 572 minecraft:cobbled_deepslate
setblock 88 297 573 minecraft:calcite
fill 88 297 574 88 300 574 minecraft:cobbled_deepslate
setblock 88 297 578 minecraft:calcite
fill 88 297 579 88 300 579 minecraft:cobbled_deepslate
setblock 88 297 583 minecraft:calcite
fill 88 297 584 88 300 584 minecraft:cobbled_deepslate
setblock 88 297 588 minecraft:calcite
fill 88 297 589 88 300 589 minecraft:cobbled_deepslate
setblock 88 297 593 minecraft:calcite
fill 88 297 594 88 300 594 minecraft:cobbled_deepslate
setblock 88 297 598 minecraft:calcite
fill 48 298 559 48 298 561 minecraft:cobbled_deepslate
setblock 48 298 562 minecraft:calcite
fill 48 298 563 48 298 566 minecraft:cobbled_deepslate
setblock 48 298 567 minecraft:calcite
fill 48 298 568 48 298 571 minecraft:cobbled_deepslate
setblock 48 298 572 minecraft:calcite
fill 48 298 573 48 298 576 minecraft:cobbled_deepslate
setblock 48 298 577 minecraft:calcite
fill 48 298 578 48 298 581 minecraft:cobbled_deepslate
setblock 48 298 582 minecraft:calcite
fill 48 298 583 48 300 583 minecraft:cobbled_deepslate
setblock 48 298 587 minecraft:calcite
fill 48 298 588 48 300 588 minecraft:cobbled_deepslate
setblock 48 298 591 minecraft:cobbled_deepslate
setblock 48 298 592 minecraft:calcite
fill 48 298 593 48 300 593 minecraft:cobbled_deepslate
setblock 48 298 596 minecraft:cobbled_deepslate
setblock 49 298 562 minecraft:cobbled_deepslate
setblock 49 298 566 minecraft:calcite
fill 49 298 567 49 300 567 minecraft:cobbled_deepslate
setblock 49 298 570 minecraft:cobbled_deepslate
setblock 49 298 571 minecraft:calcite
fill 49 298 572 49 298 575 minecraft:cobbled_deepslate
setblock 49 298 576 minecraft:calcite
setblock 49 298 577 minecraft:cobbled_deepslate
setblock 49 298 586 minecraft:calcite
setblock 49 298 587 minecraft:cobbled_deepslate
setblock 49 298 591 minecraft:calcite
setblock 49 298 592 minecraft:cobbled_deepslate
setblock 50 298 565 minecraft:calcite
fill 50 298 566 50 299 566 minecraft:cobbled_deepslate
setblock 50 298 570 minecraft:calcite
fill 50 298 571 50 300 571 minecraft:cobbled_deepslate
fill 50 298 573 50 299 573 minecraft:cobbled_deepslate
setblock 50 298 588 minecraft:light_blue_stained_glass
setblock 50 298 595 minecraft:calcite
setblock 50 298 597 minecraft:calcite
setblock 52 298 595 minecraft:calcite
setblock 52 298 597 minecraft:calcite
fill 54 298 588 55 298 588 minecraft:light_blue_stained_glass
setblock 57 298 558 minecraft:calcite
fill 58 298 558 61 298 558 minecraft:cobbled_deepslate
fill 59 298 559 60 298 559 minecraft:cobbled_deepslate
fill 59 298 598 61 298 598 minecraft:cobbled_deepslate
setblock 61 298 559 minecraft:calcite
fill 61 298 560 64 298 560 minecraft:cobbled_deepslate
fill 61 298 597 62 298 597 minecraft:cobbled_deepslate
setblock 62 298 558 minecraft:calcite
fill 62 298 559 65 298 559 minecraft:cobbled_deepslate
setblock 62 298 598 minecraft:calcite
fill 63 298 558 66 298 558 minecraft:cobbled_deepslate
setblock 63 298 596 minecraft:cobbled_deepslate
setblock 63 298 597 minecraft:calcite
fill 63 298 598 66 298 598 minecraft:cobbled_deepslate
setblock 64 298 596 minecraft:calcite
fill 64 298 597 64 300 597 minecraft:cobbled_deepslate
setblock 65 298 560 minecraft:calcite
fill 65 298 596 65 300 596 minecraft:cobbled_deepslate
setblock 66 298 559 minecraft:calcite
setblock 66 298 560 minecraft:cobbled_deepslate
setblock 67 298 558 minecraft:calcite
fill 67 298 559 67 300 559 minecraft:cobbled_deepslate
setblock 67 298 597 minecraft:cobbled_deepslate
setblock 67 298 598 minecraft:calcite
fill 68 298 558 68 300 558 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_10 1t
