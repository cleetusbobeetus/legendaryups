setblock 436 84 316 minecraft:gray_concrete
setblock 440 84 276 minecraft:gray_concrete
setblock 442 84 278 minecraft:light[level=15]
setblock 442 84 286 minecraft:light[level=15]
setblock 442 84 294 minecraft:light[level=15]
setblock 442 84 302 minecraft:light[level=15]
setblock 442 84 310 minecraft:light[level=15]
setblock 446 84 316 minecraft:gray_concrete
setblock 450 84 278 minecraft:light[level=15]
setblock 450 84 286 minecraft:light[level=15]
setblock 450 84 294 minecraft:light[level=15]
setblock 450 84 302 minecraft:light[level=15]
setblock 450 84 310 minecraft:light[level=15]
setblock 456 84 316 minecraft:gray_concrete
fill 457 84 284 457 84 308 minecraft:magenta_concrete
setblock 458 84 278 minecraft:light[level=15]
setblock 458 84 286 minecraft:light[level=15]
setblock 458 84 294 minecraft:light[level=15]
setblock 458 84 302 minecraft:light[level=15]
setblock 458 84 310 minecraft:light[level=15]
setblock 460 84 276 minecraft:gray_concrete
fill 462 84 303 462 84 304 minecraft:purple_wool
setblock 462 84 306 minecraft:purple_wool
setblock 464 84 282 minecraft:gray_concrete
setblock 464 84 302 minecraft:gray_concrete
setblock 464 84 312 minecraft:gray_concrete
fill 423 85 281 423 85 284 minecraft:sea_lantern
fill 423 85 291 423 85 294 minecraft:sea_lantern
fill 423 85 301 423 85 304 minecraft:sea_lantern
fill 423 85 311 423 85 314 minecraft:sea_lantern
fill 424 85 305 425 85 305 minecraft:magenta_stained_glass
fill 426 85 275 429 85 275 minecraft:sea_lantern
fill 427 85 317 430 85 317 minecraft:sea_lantern
fill 436 85 275 439 85 275 minecraft:sea_lantern
fill 437 85 317 440 85 317 minecraft:sea_lantern
fill 446 85 275 449 85 275 minecraft:sea_lantern
fill 447 85 317 450 85 317 minecraft:sea_lantern
fill 456 85 275 459 85 275 minecraft:sea_lantern
fill 457 85 317 460 85 317 minecraft:sea_lantern
fill 458 85 280 458 86 281 minecraft:magenta_concrete
fill 459 85 279 461 86 279 minecraft:magenta_concrete
fill 459 85 283 461 86 283 minecraft:magenta_concrete
fill 462 85 280 462 86 282 minecraft:magenta_concrete
fill 462 85 301 462 86 307 minecraft:iron_block
fill 465 85 276 465 85 279 minecraft:sea_lantern
fill 465 85 286 465 85 289 minecraft:sea_lantern
fill 465 85 296 465 85 299 minecraft:sea_lantern
fill 465 85 306 465 85 309 minecraft:sea_lantern
setblock 465 85 316 minecraft:sea_lantern
fill 423 86 281 423 102 284 minecraft:black_concrete
fill 423 86 291 423 102 294 minecraft:black_concrete
fill 423 86 301 423 102 304 minecraft:black_concrete
fill 423 86 311 423 102 314 minecraft:black_concrete
fill 426 86 275 429 102 275 minecraft:black_concrete
fill 427 86 317 430 102 317 minecraft:black_concrete
fill 436 86 275 439 102 275 minecraft:black_concrete
fill 437 86 317 440 102 317 minecraft:black_concrete
fill 446 86 275 449 102 275 minecraft:black_concrete
fill 447 86 317 450 102 317 minecraft:black_concrete
fill 456 86 275 459 102 275 minecraft:black_concrete
fill 457 86 317 460 102 317 minecraft:black_concrete
fill 465 86 276 465 102 279 minecraft:black_concrete
fill 465 86 286 465 102 289 minecraft:black_concrete
fill 465 86 296 465 102 299 minecraft:black_concrete
fill 465 86 306 465 102 309 minecraft:black_concrete
fill 465 86 316 465 102 316 minecraft:black_concrete
setblock 426 88 278 minecraft:light[level=12]
setblock 426 88 285 minecraft:light[level=12]
setblock 426 88 292 minecraft:light[level=12]
setblock 426 88 299 minecraft:light[level=12]
setblock 426 88 306 minecraft:light[level=12]
setblock 426 88 313 minecraft:light[level=12]
setblock 433 88 278 minecraft:light[level=12]
setblock 433 88 285 minecraft:light[level=12]
setblock 433 88 292 minecraft:light[level=12]
setblock 433 88 299 minecraft:light[level=12]
setblock 433 88 306 minecraft:light[level=12]
setblock 433 88 313 minecraft:light[level=12]
setblock 440 88 278 minecraft:light[level=12]
setblock 440 88 285 minecraft:light[level=12]
setblock 440 88 292 minecraft:light[level=12]
setblock 440 88 299 minecraft:light[level=12]
setblock 440 88 306 minecraft:light[level=12]
setblock 440 88 313 minecraft:light[level=12]
setblock 447 88 278 minecraft:light[level=12]
setblock 447 88 285 minecraft:light[level=12]
setblock 447 88 292 minecraft:light[level=12]
setblock 447 88 299 minecraft:light[level=12]
setblock 447 88 306 minecraft:light[level=12]
setblock 447 88 313 minecraft:light[level=12]
setblock 454 88 278 minecraft:light[level=12]
setblock 454 88 285 minecraft:light[level=12]
setblock 454 88 292 minecraft:light[level=12]
setblock 454 88 299 minecraft:light[level=12]
setblock 454 88 306 minecraft:light[level=12]
setblock 454 88 313 minecraft:light[level=12]
setblock 461 88 278 minecraft:light[level=12]
setblock 461 88 285 minecraft:light[level=12]
setblock 461 88 292 minecraft:light[level=12]
setblock 461 88 299 minecraft:light[level=12]
setblock 461 88 306 minecraft:light[level=12]
setblock 461 88 313 minecraft:light[level=12]
fill 424 92 276 425 93 277 minecraft:glass
fill 424 92 278 425 93 278 minecraft:light_gray_concrete
fill 424 92 279 425 93 284 minecraft:glass
fill 424 92 285 425 93 285 minecraft:light_gray_concrete
fill 424 92 286 425 93 291 minecraft:glass
fill 424 92 292 425 93 292 minecraft:light_gray_concrete
fill 424 92 293 425 93 298 minecraft:glass
fill 424 92 299 425 93 299 minecraft:light_gray_concrete
fill 424 92 300 425 93 305 minecraft:glass
fill 424 92 306 425 93 306 minecraft:light_gray_concrete
fill 424 92 307 425 93 312 minecraft:glass
fill 424 92 313 425 93 313 minecraft:light_gray_concrete
fill 424 92 314 425 93 316 minecraft:glass
fill 426 92 276 426 93 277 minecraft:light_gray_concrete
fill 426 92 278 426 93 278 minecraft:pearlescent_froglight
fill 426 92 279 426 93 284 minecraft:light_gray_concrete
fill 426 92 285 426 93 285 minecraft:pearlescent_froglight
fill 426 92 286 426 93 291 minecraft:light_gray_concrete
fill 426 92 292 426 93 292 minecraft:pearlescent_froglight
fill 426 92 293 426 93 298 minecraft:light_gray_concrete
fill 426 92 299 426 93 299 minecraft:pearlescent_froglight
fill 426 92 300 426 93 305 minecraft:light_gray_concrete
fill 426 92 306 426 93 306 minecraft:pearlescent_froglight
fill 426 92 307 426 93 312 minecraft:light_gray_concrete
fill 426 92 313 426 93 313 minecraft:pearlescent_froglight
fill 426 92 314 426 93 316 minecraft:light_gray_concrete
fill 427 92 276 432 93 277 minecraft:glass
fill 427 92 278 432 93 278 minecraft:light_gray_concrete
fill 427 92 279 432 93 284 minecraft:glass
fill 427 92 285 432 93 285 minecraft:light_gray_concrete
fill 427 92 286 432 93 291 minecraft:glass
fill 427 92 292 432 93 292 minecraft:light_gray_concrete
fill 427 92 293 432 93 298 minecraft:glass
fill 427 92 299 432 93 299 minecraft:light_gray_concrete
fill 427 92 300 432 93 305 minecraft:glass
fill 427 92 306 432 93 306 minecraft:light_gray_concrete
fill 427 92 307 432 93 312 minecraft:glass
fill 427 92 313 432 93 313 minecraft:light_gray_concrete
fill 427 92 314 432 93 316 minecraft:glass
fill 433 92 276 433 93 277 minecraft:light_gray_concrete
fill 433 92 278 433 93 278 minecraft:pearlescent_froglight
fill 433 92 279 433 93 284 minecraft:light_gray_concrete
fill 433 92 285 433 93 285 minecraft:pearlescent_froglight
fill 433 92 286 433 93 291 minecraft:light_gray_concrete
fill 433 92 292 433 93 292 minecraft:pearlescent_froglight
fill 433 92 293 433 93 298 minecraft:light_gray_concrete
fill 433 92 299 433 93 299 minecraft:pearlescent_froglight
fill 433 92 300 433 93 305 minecraft:light_gray_concrete
fill 433 92 306 433 93 306 minecraft:pearlescent_froglight
fill 433 92 307 433 93 312 minecraft:light_gray_concrete
fill 433 92 313 433 93 313 minecraft:pearlescent_froglight
fill 433 92 314 433 93 316 minecraft:light_gray_concrete
fill 434 92 276 439 93 277 minecraft:glass
fill 434 92 278 439 93 278 minecraft:light_gray_concrete
fill 434 92 279 439 93 284 minecraft:glass
fill 434 92 285 439 93 285 minecraft:light_gray_concrete
fill 434 92 286 439 93 291 minecraft:glass
fill 434 92 292 439 93 292 minecraft:light_gray_concrete
fill 434 92 293 439 93 298 minecraft:glass
fill 434 92 299 439 93 299 minecraft:light_gray_concrete
fill 434 92 300 439 93 305 minecraft:glass
fill 434 92 306 439 93 306 minecraft:light_gray_concrete
fill 434 92 307 439 93 312 minecraft:glass
fill 434 92 313 439 93 313 minecraft:light_gray_concrete
fill 434 92 314 439 93 316 minecraft:glass
fill 440 92 276 440 93 277 minecraft:light_gray_concrete
fill 440 92 278 440 93 278 minecraft:pearlescent_froglight
fill 440 92 279 440 93 284 minecraft:light_gray_concrete
fill 440 92 285 440 93 285 minecraft:pearlescent_froglight
fill 440 92 286 440 93 291 minecraft:light_gray_concrete
fill 440 92 292 440 93 292 minecraft:pearlescent_froglight
fill 440 92 293 440 93 298 minecraft:light_gray_concrete
fill 440 92 299 440 93 299 minecraft:pearlescent_froglight
fill 440 92 300 440 93 305 minecraft:light_gray_concrete
fill 440 92 306 440 93 306 minecraft:pearlescent_froglight
fill 440 92 307 440 93 312 minecraft:light_gray_concrete
fill 440 92 313 440 93 313 minecraft:pearlescent_froglight
fill 440 92 314 440 93 316 minecraft:light_gray_concrete
fill 441 92 276 446 93 277 minecraft:glass
fill 441 92 278 446 93 278 minecraft:light_gray_concrete
fill 441 92 279 444 92 284 minecraft:glass
fill 441 92 285 442 92 285 minecraft:light_gray_concrete
fill 441 92 286 441 92 291 minecraft:glass
fill 441 92 292 446 93 292 minecraft:light_gray_concrete
fill 441 92 293 446 93 298 minecraft:glass
fill 441 92 299 446 93 299 minecraft:light_gray_concrete
fill 441 92 300 446 93 305 minecraft:glass
fill 441 92 306 446 93 306 minecraft:light_gray_concrete
fill 441 92 307 446 93 312 minecraft:glass
fill 441 92 313 446 93 313 minecraft:light_gray_concrete
fill 441 92 314 446 93 316 minecraft:glass
setblock 442 92 286 minecraft:glass
fill 442 92 288 442 92 291 minecraft:glass
fill 443 92 290 444 92 291 minecraft:glass
fill 445 92 279 446 92 283 minecraft:glass
fill 445 92 291 446 92 291 minecraft:glass
setblock 446 92 284 minecraft:glass
setblock 446 92 290 minecraft:glass
fill 447 92 276 447 93 277 minecraft:light_gray_concrete
fill 447 92 278 447 93 278 minecraft:pearlescent_froglight
fill 447 92 279 447 92 284 minecraft:light_gray_concrete
fill 447 92 290 447 92 291 minecraft:light_gray_concrete
fill 447 92 292 447 93 292 minecraft:pearlescent_froglight
fill 447 92 293 447 93 298 minecraft:light_gray_concrete
fill 447 92 299 447 93 299 minecraft:pearlescent_froglight
fill 447 92 300 447 93 305 minecraft:light_gray_concrete
fill 447 92 306 447 93 306 minecraft:pearlescent_froglight
fill 447 92 307 447 93 312 minecraft:light_gray_concrete
fill 447 92 313 447 93 313 minecraft:pearlescent_froglight
fill 447 92 314 447 93 316 minecraft:light_gray_concrete
fill 448 92 276 453 93 277 minecraft:glass
fill 448 92 278 453 93 278 minecraft:light_gray_concrete
fill 448 92 279 453 92 284 minecraft:glass
fill 448 92 285 453 92 285 minecraft:light_gray_concrete
fill 448 92 286 453 92 286 minecraft:glass
fill 448 92 288 453 92 291 minecraft:glass
fill 448 92 292 453 93 292 minecraft:light_gray_concrete
fill 448 92 293 453 93 298 minecraft:glass
fill 448 92 299 453 93 299 minecraft:light_gray_concrete
fill 448 92 300 453 93 305 minecraft:glass
fill 448 92 306 453 93 306 minecraft:light_gray_concrete
fill 448 92 307 453 93 312 minecraft:glass
fill 448 92 313 453 93 313 minecraft:light_gray_concrete
fill 448 92 314 453 93 316 minecraft:glass
fill 449 92 287 453 92 287 minecraft:glass
fill 454 92 276 454 93 277 minecraft:light_gray_concrete
fill 454 92 278 454 93 278 minecraft:pearlescent_froglight
fill 454 92 279 454 93 284 minecraft:light_gray_concrete
fill 454 92 285 454 93 285 minecraft:pearlescent_froglight
fill 454 92 286 454 93 291 minecraft:light_gray_concrete
fill 454 92 292 454 93 292 minecraft:pearlescent_froglight
fill 454 92 293 454 93 298 minecraft:light_gray_concrete
fill 454 92 299 454 93 299 minecraft:pearlescent_froglight
fill 454 92 300 454 93 305 minecraft:light_gray_concrete
fill 454 92 306 454 93 306 minecraft:pearlescent_froglight
fill 454 92 307 454 93 312 minecraft:light_gray_concrete
fill 454 92 313 454 93 313 minecraft:pearlescent_froglight
fill 454 92 314 454 93 316 minecraft:light_gray_concrete
fill 455 92 276 460 93 277 minecraft:glass
fill 455 92 278 460 93 278 minecraft:light_gray_concrete
fill 455 92 279 460 93 284 minecraft:glass
fill 455 92 285 460 93 285 minecraft:light_gray_concrete
fill 455 92 286 460 93 291 minecraft:glass
fill 455 92 292 460 93 292 minecraft:light_gray_concrete
fill 455 92 293 460 93 298 minecraft:glass
fill 455 92 299 460 93 299 minecraft:light_gray_concrete
fill 455 92 300 460 93 305 minecraft:glass
fill 455 92 306 460 93 306 minecraft:light_gray_concrete
fill 455 92 307 460 93 312 minecraft:glass
fill 455 92 313 460 93 313 minecraft:light_gray_concrete
fill 455 92 314 460 93 316 minecraft:glass
fill 461 92 276 461 93 277 minecraft:light_gray_concrete
fill 461 92 278 461 93 278 minecraft:pearlescent_froglight
fill 461 92 279 461 93 284 minecraft:light_gray_concrete
fill 461 92 285 461 93 285 minecraft:pearlescent_froglight
fill 461 92 286 461 93 291 minecraft:light_gray_concrete
fill 461 92 292 461 93 292 minecraft:pearlescent_froglight
fill 461 92 293 461 93 298 minecraft:light_gray_concrete
fill 461 92 299 461 93 299 minecraft:pearlescent_froglight
fill 461 92 300 461 93 305 minecraft:light_gray_concrete
fill 461 92 306 461 93 306 minecraft:pearlescent_froglight
fill 461 92 307 461 93 312 minecraft:light_gray_concrete
fill 461 92 313 461 93 313 minecraft:pearlescent_froglight
fill 461 92 314 461 93 316 minecraft:light_gray_concrete
fill 462 92 276 464 93 277 minecraft:glass
fill 462 92 278 464 93 278 minecraft:light_gray_concrete
fill 462 92 279 464 93 284 minecraft:glass
fill 462 92 285 464 93 285 minecraft:light_gray_concrete
fill 462 92 286 464 93 291 minecraft:glass
fill 462 92 292 464 93 292 minecraft:light_gray_concrete
fill 462 92 293 464 93 298 minecraft:glass
fill 462 92 299 464 93 299 minecraft:light_gray_concrete
fill 462 92 300 464 93 305 minecraft:glass
fill 462 92 306 464 93 306 minecraft:light_gray_concrete
fill 462 92 307 464 93 312 minecraft:glass
fill 462 92 313 464 93 313 minecraft:light_gray_concrete
fill 462 92 314 464 93 316 minecraft:glass
fill 441 93 279 441 93 284 minecraft:glass
setblock 441 93 285 minecraft:light_gray_concrete
fill 441 93 286 441 93 288 minecraft:verdant_froglight
fill 441 93 289 441 93 291 minecraft:glass
fill 442 93 279 443 93 283 minecraft:glass
fill 442 93 284 442 93 286 minecraft:verdant_froglight
fill 442 93 288 442 93 290 minecraft:verdant_froglight
fill 442 93 291 443 93 291 minecraft:glass
fill 443 93 284 444 93 284 minecraft:verdant_froglight
fill 443 93 290 444 93 290 minecraft:verdant_froglight
fill 444 93 279 446 93 282 minecraft:glass
fill 444 93 283 446 93 283 minecraft:verdant_froglight
fill 444 93 291 446 93 291 minecraft:verdant_froglight
fill 446 93 284 448 93 284 minecraft:verdant_froglight
fill 446 93 290 448 93 290 minecraft:verdant_froglight
fill 447 93 279 447 93 283 minecraft:light_gray_concrete
setblock 447 93 291 minecraft:light_gray_concrete
fill 448 93 279 453 93 283 minecraft:glass
fill 448 93 285 448 93 286 minecraft:verdant_froglight
fill 448 93 288 448 93 289 minecraft:verdant_froglight
fill 448 93 291 453 93 291 minecraft:glass
fill 449 93 284 453 93 284 minecraft:glass
fill 449 93 285 453 93 285 minecraft:light_gray_concrete
fill 449 93 286 449 93 288 minecraft:verdant_froglight
fill 449 93 289 453 93 290 minecraft:glass
fill 450 93 286 453 93 288 minecraft:glass
fill 425 94 295 425 96 295 minecraft:black_concrete
fill 425 94 296 427 94 296 minecraft:gray_concrete
fill 425 94 297 425 96 297 minecraft:black_concrete
setblock 426 94 278 minecraft:light[level=12]
setblock 426 94 285 minecraft:light[level=12]
setblock 426 94 292 minecraft:light[level=12]
setblock 426 94 295 minecraft:gray_concrete
setblock 426 94 297 minecraft:gray_concrete
setblock 426 94 299 minecraft:light[level=12]
setblock 426 94 306 minecraft:light[level=12]
setblock 426 94 313 minecraft:light[level=12]
fill 427 94 295 427 96 295 minecraft:black_concrete
fill 427 94 297 427 96 297 minecraft:black_concrete
setblock 433 94 278 minecraft:light[level=12]
setblock 433 94 285 minecraft:light[level=12]
setblock 433 94 292 minecraft:light[level=12]
setblock 433 94 299 minecraft:light[level=12]
setblock 433 94 306 minecraft:light[level=12]
setblock 433 94 313 minecraft:light[level=12]
setblock 440 94 278 minecraft:light[level=12]
setblock 440 94 285 minecraft:light[level=12]
setblock 440 94 292 minecraft:light[level=12]
setblock 440 94 299 minecraft:light[level=12]
setblock 440 94 306 minecraft:light[level=12]
setblock 440 94 313 minecraft:light[level=12]
setblock 447 94 278 minecraft:light[level=12]
setblock 447 94 292 minecraft:light[level=12]
setblock 447 94 299 minecraft:light[level=12]
setblock 447 94 306 minecraft:light[level=12]
setblock 447 94 313 minecraft:light[level=12]
setblock 454 94 278 minecraft:light[level=12]
setblock 454 94 285 minecraft:light[level=12]
setblock 454 94 292 minecraft:light[level=12]
setblock 454 94 299 minecraft:light[level=12]
setblock 454 94 306 minecraft:light[level=12]
setblock 454 94 313 minecraft:light[level=12]
setblock 461 94 278 minecraft:light[level=12]
setblock 461 94 285 minecraft:light[level=12]
setblock 461 94 292 minecraft:light[level=12]
setblock 461 94 299 minecraft:light[level=12]
setblock 461 94 306 minecraft:light[level=12]
setblock 461 94 313 minecraft:light[level=12]
fill 425 95 296 425 96 296 minecraft:black_concrete
fill 426 95 295 426 96 295 minecraft:black_concrete
setblock 426 95 296 minecraft:gray_concrete
fill 426 95 297 426 96 297 minecraft:black_concrete
fill 427 95 296 427 96 296 minecraft:black_concrete
setblock 426 96 296 minecraft:black_concrete
fill 424 97 277 424 185 277 minecraft:iron_block
fill 424 97 287 424 185 287 minecraft:iron_block
fill 424 97 297 424 185 297 minecraft:iron_block
fill 424 97 307 424 185 307 minecraft:iron_block
fill 425 97 316 425 185 316 minecraft:iron_block
fill 431 97 276 431 185 276 minecraft:iron_block
fill 435 97 316 435 185 316 minecraft:iron_block
fill 441 97 276 441 185 276 minecraft:iron_block
fill 445 97 316 445 185 316 minecraft:iron_block
fill 451 97 276 451 185 276 minecraft:iron_block
fill 455 97 316 455 185 316 minecraft:iron_block
fill 461 97 276 461 185 276 minecraft:iron_block
fill 464 97 283 464 185 283 minecraft:iron_block
fill 464 97 293 464 185 293 minecraft:iron_block
fill 464 97 303 464 185 303 minecraft:iron_block
fill 464 97 313 464 185 313 minecraft:iron_block
fill 461 98 297 463 98 297 minecraft:iron_block
fill 424 99 280 424 99 283 minecraft:gray_concrete
fill 424 99 290 424 99 293 minecraft:gray_concrete
fill 424 99 300 424 99 303 minecraft:gray_concrete
fill 424 99 310 424 99 313 minecraft:gray_concrete
fill 425 99 276 428 99 276 minecraft:gray_concrete
fill 426 99 294 427 100 298 minecraft:gray_concrete
fill 427 99 290 427 100 293 minecraft:gray_concrete
fill 427 99 299 427 100 302 minecraft:gray_concrete
fill 428 99 288 428 100 290 minecraft:gray_concrete
fill 428 99 302 428 100 304 minecraft:gray_concrete
fill 428 99 316 431 99 316 minecraft:gray_concrete
fill 429 99 286 429 100 288 minecraft:gray_concrete
fill 429 99 304 429 100 306 minecraft:gray_concrete
fill 430 99 285 430 100 286 minecraft:gray_concrete
fill 430 99 306 430 100 307 minecraft:gray_concrete
fill 431 99 284 431 100 285 minecraft:gray_concrete
fill 431 99 307 431 100 308 minecraft:gray_concrete
fill 432 99 283 432 100 284 minecraft:gray_concrete
fill 432 99 308 432 100 309 minecraft:gray_concrete
fill 433 99 282 433 100 283 minecraft:gray_concrete
fill 433 99 309 433 100 310 minecraft:gray_concrete
fill 434 99 281 434 100 282 minecraft:gray_concrete
fill 434 99 310 434 100 311 minecraft:gray_concrete
fill 435 99 276 438 99 276 minecraft:gray_concrete
fill 435 99 281 436 100 281 minecraft:gray_concrete
fill 435 99 311 436 100 311 minecraft:gray_concrete
fill 436 99 280 438 100 280 minecraft:gray_concrete
fill 436 99 312 438 100 312 minecraft:gray_concrete
fill 438 99 279 450 100 279 minecraft:gray_concrete
fill 438 99 313 450 100 313 minecraft:gray_concrete
fill 438 99 316 441 99 316 minecraft:gray_concrete
fill 442 99 278 446 100 278 minecraft:gray_concrete
fill 442 99 314 444 99 316 minecraft:black_concrete
fill 445 99 276 448 99 276 minecraft:gray_concrete
fill 445 99 314 446 100 314 minecraft:gray_concrete
fill 448 99 316 451 99 316 minecraft:gray_concrete
fill 450 99 280 452 100 280 minecraft:gray_concrete
fill 450 99 312 452 100 312 minecraft:gray_concrete
fill 452 99 281 454 100 281 minecraft:gray_concrete
fill 452 99 311 454 100 311 minecraft:gray_concrete
fill 454 99 282 455 100 282 minecraft:gray_concrete
fill 454 99 310 455 100 310 minecraft:gray_concrete
fill 455 99 276 458 99 276 minecraft:gray_concrete
fill 455 99 283 456 100 283 minecraft:gray_concrete
fill 455 99 309 456 100 309 minecraft:gray_concrete
fill 456 99 284 457 100 284 minecraft:gray_concrete
fill 456 99 308 457 100 308 minecraft:gray_concrete
fill 457 99 285 458 100 285 minecraft:gray_concrete
fill 457 99 307 458 100 307 minecraft:gray_concrete
fill 458 99 286 459 100 286 minecraft:gray_concrete
fill 458 99 306 459 100 306 minecraft:gray_concrete
fill 458 99 316 461 99 316 minecraft:gray_concrete
fill 459 99 287 459 100 288 minecraft:gray_concrete
fill 459 99 304 459 100 305 minecraft:gray_concrete
fill 460 99 288 460 100 290 minecraft:gray_concrete
fill 460 99 302 460 100 304 minecraft:gray_concrete
fill 461 99 290 461 100 302 minecraft:gray_concrete
fill 462 99 294 462 100 298 minecraft:gray_concrete
setblock 463 99 297 minecraft:iron_block
fill 464 99 277 464 99 280 minecraft:gray_concrete
fill 464 99 287 464 99 290 minecraft:gray_concrete
fill 464 99 297 464 99 300 minecraft:gray_concrete
fill 464 99 307 464 99 310 minecraft:gray_concrete
setblock 426 100 278 minecraft:light[level=15]
setblock 426 100 285 minecraft:light[level=12]
setblock 426 100 286 minecraft:light[level=15]
setblock 426 100 292 minecraft:light[level=12]
setblock 426 100 299 minecraft:light[level=12]
setblock 426 100 302 minecraft:light[level=15]
setblock 426 100 306 minecraft:light[level=12]
setblock 426 100 310 minecraft:light[level=15]
setblock 426 100 313 minecraft:light[level=12]
setblock 433 100 278 minecraft:light[level=12]
setblock 433 100 285 minecraft:light[level=12]
setblock 433 100 292 minecraft:light[level=12]
setblock 433 100 299 minecraft:light[level=12]
setblock 433 100 306 minecraft:light[level=12]
setblock 433 100 313 minecraft:light[level=12]
setblock 434 100 278 minecraft:light[level=15]
setblock 434 100 286 minecraft:light[level=15]
setblock 434 100 294 minecraft:light[level=15]
setblock 434 100 302 minecraft:light[level=15]
setblock 440 100 278 minecraft:light[level=12]
setblock 440 100 285 minecraft:light[level=12]
setblock 440 100 292 minecraft:light[level=12]
setblock 440 100 299 minecraft:light[level=12]
setblock 440 100 306 minecraft:light[level=12]
setblock 442 100 286 minecraft:light[level=15]
setblock 442 100 294 minecraft:light[level=15]
setblock 442 100 302 minecraft:light[level=15]
setblock 442 100 310 minecraft:light[level=15]
fill 442 100 314 442 100 316 minecraft:black_concrete
fill 443 100 314 444 100 314 minecraft:black_concrete
fill 443 100 315 443 102 315 minecraft:gray_concrete
fill 443 100 316 444 100 316 minecraft:black_concrete
setblock 444 100 315 minecraft:black_concrete
setblock 447 100 278 minecraft:light[level=12]
setblock 447 100 285 minecraft:light[level=12]
setblock 447 100 292 minecraft:light[level=12]
setblock 447 100 299 minecraft:light[level=12]
setblock 447 100 306 minecraft:light[level=12]
setblock 450 100 278 minecraft:light[level=15]
setblock 450 100 286 minecraft:light[level=15]
setblock 450 100 294 minecraft:light[level=15]
setblock 450 100 302 minecraft:light[level=15]
setblock 450 100 310 minecraft:light[level=15]
setblock 454 100 278 minecraft:light[level=12]
setblock 454 100 285 minecraft:light[level=12]
setblock 454 100 292 minecraft:light[level=12]
setblock 454 100 299 minecraft:light[level=12]
setblock 454 100 306 minecraft:light[level=12]
setblock 454 100 313 minecraft:light[level=12]
setblock 458 100 278 minecraft:light[level=15]
setblock 458 100 294 minecraft:light[level=15]
setblock 458 100 302 minecraft:light[level=15]
setblock 458 100 310 minecraft:light[level=15]
setblock 461 100 278 minecraft:light[level=12]
setblock 461 100 285 minecraft:light[level=12]
setblock 461 100 306 minecraft:light[level=12]
setblock 461 100 313 minecraft:light[level=12]
fill 426 101 292 426 101 300 minecraft:sea_lantern
fill 427 101 289 427 101 291 minecraft:sea_lantern
fill 427 101 301 427 101 303 minecraft:sea_lantern
fill 428 101 287 428 101 288 minecraft:sea_lantern
fill 428 101 304 428 101 305 minecraft:sea_lantern
setblock 429 101 286 minecraft:sea_lantern
setblock 429 101 306 minecraft:sea_lantern
fill 429 101 314 429 115 314 minecraft:purple_wool
fill 430 101 284 430 101 285 minecraft:sea_lantern
fill 430 101 307 430 101 308 minecraft:sea_lantern
fill 431 101 283 431 101 284 minecraft:sea_lantern
setblock 431 101 308 minecraft:sea_lantern
fill 432 101 282 432 101 283 minecraft:sea_lantern
setblock 433 101 282 minecraft:sea_lantern
setblock 434 101 281 minecraft:sea_lantern
fill 435 101 280 436 101 280 minecraft:sea_lantern
fill 437 101 279 439 101 279 minecraft:sea_lantern
fill 440 101 278 448 101 278 minecraft:sea_lantern
fill 442 101 314 442 103 314 minecraft:black_concrete
setblock 442 101 315 minecraft:gray_concrete
fill 442 101 316 442 103 316 minecraft:black_concrete
setblock 443 101 314 minecraft:gray_concrete
setblock 443 101 316 minecraft:gray_concrete
fill 444 101 314 444 103 314 minecraft:black_concrete
setblock 444 101 315 minecraft:gray_concrete
fill 444 101 316 444 103 316 minecraft:black_concrete
fill 449 101 279 451 101 279 minecraft:sea_lantern
fill 452 101 280 453 101 280 minecraft:sea_lantern
fill 452 101 312 453 101 312 minecraft:sea_lantern
setblock 454 101 281 minecraft:sea_lantern
setblock 454 101 311 minecraft:sea_lantern
fill 455 101 282 456 101 282 minecraft:sea_lantern
fill 455 101 310 456 101 310 minecraft:sea_lantern
fill 456 101 283 457 101 283 minecraft:sea_lantern
fill 456 101 309 457 101 309 minecraft:sea_lantern
fill 457 101 284 458 101 284 minecraft:sea_lantern
fill 457 101 308 458 101 308 minecraft:sea_lantern
setblock 458 101 285 minecraft:sea_lantern
setblock 458 101 307 minecraft:sea_lantern
setblock 459 101 286 minecraft:sea_lantern
setblock 459 101 306 minecraft:sea_lantern
fill 460 101 287 460 101 288 minecraft:sea_lantern
fill 460 101 304 460 101 305 minecraft:sea_lantern
fill 461 101 289 461 101 291 minecraft:sea_lantern
fill 461 101 301 461 101 303 minecraft:sea_lantern
fill 462 101 292 462 101 300 minecraft:sea_lantern
setblock 424 102 278 minecraft:gray_concrete
fill 424 102 282 426 103 282 minecraft:gray_concrete
fill 424 102 288 441 102 288 minecraft:gray_concrete
fill 424 102 294 464 102 294 minecraft:gray_concrete
setblock 424 102 298 minecraft:gray_concrete
fill 424 102 300 464 102 300 minecraft:gray_concrete
fill 424 102 306 464 102 306 minecraft:gray_concrete
setblock 424 102 308 minecraft:gray_concrete
fill 424 102 312 439 103 312 minecraft:gray_concrete
setblock 426 102 316 minecraft:gray_concrete
fill 427 102 314 428 115 314 minecraft:purple_wool
setblock 430 102 276 minecraft:gray_concrete
fill 430 102 314 431 103 314 minecraft:purple_wool
setblock 436 102 316 minecraft:gray_concrete
setblock 440 102 276 minecraft:gray_concrete
fill 442 102 315 442 103 315 minecraft:black_concrete
fill 443 102 314 443 103 314 minecraft:black_concrete
fill 443 102 316 443 103 316 minecraft:black_concrete
fill 444 102 315 444 103 315 minecraft:black_concrete
setblock 446 102 316 minecraft:gray_concrete
fill 449 102 288 464 102 288 minecraft:gray_concrete
setblock 450 102 276 minecraft:gray_concrete
setblock 456 102 316 minecraft:gray_concrete
setblock 460 102 276 minecraft:gray_concrete
setblock 464 102 282 minecraft:gray_concrete
setblock 464 102 292 minecraft:gray_concrete
setblock 464 102 302 minecraft:gray_concrete
fill 464 102 312 464 103 312 minecraft:gray_concrete
fill 423 103 281 423 103 284 minecraft:sea_lantern
fill 423 103 291 423 103 294 minecraft:sea_lantern
fill 423 103 301 423 103 304 minecraft:sea_lantern
fill 423 103 311 423 103 314 minecraft:sea_lantern
fill 424 103 288 436 103 288 minecraft:gray_concrete
fill 424 103 294 434 103 294 minecraft:gray_concrete
fill 424 103 300 432 103 300 minecraft:gray_concrete
fill 424 103 306 430 103 306 minecraft:gray_concrete
fill 426 103 275 429 103 275 minecraft:sea_lantern
fill 427 103 282 460 103 282 minecraft:gray_concrete
fill 427 103 317 430 103 317 minecraft:sea_lantern
fill 436 103 275 439 103 275 minecraft:sea_lantern
fill 437 103 317 440 103 317 minecraft:sea_lantern
fill 440 103 312 453 103 312 minecraft:gray_concrete
setblock 443 103 315 minecraft:black_concrete
fill 446 103 275 449 103 275 minecraft:sea_lantern
fill 447 103 317 450 103 317 minecraft:sea_lantern
fill 448 103 306 448 103 307 minecraft:light_blue_concrete
fill 454 103 308 454 103 315 minecraft:iron_block
fill 455 103 312 463 103 312 minecraft:gray_concrete
fill 456 103 275 459 103 275 minecraft:sea_lantern
fill 457 103 317 460 103 317 minecraft:sea_lantern
fill 461 103 295 463 104 295 minecraft:iron_block
fill 465 103 276 465 103 279 minecraft:sea_lantern
fill 465 103 286 465 103 289 minecraft:sea_lantern
fill 465 103 296 465 103 299 minecraft:sea_lantern
fill 465 103 306 465 103 309 minecraft:sea_lantern
setblock 465 103 316 minecraft:sea_lantern
fill 423 104 281 423 111 284 minecraft:black_concrete
fill 423 104 291 423 111 294 minecraft:black_concrete
fill 423 104 301 423 111 304 minecraft:black_concrete
fill 423 104 311 423 111 314 minecraft:black_concrete
fill 426 104 275 429 111 275 minecraft:black_concrete
fill 427 104 317 430 111 317 minecraft:black_concrete
fill 430 104 276 430 104 316 minecraft:iron_block
fill 431 104 314 431 115 314 minecraft:purple_wool
fill 436 104 275 439 111 275 minecraft:black_concrete
fill 436 104 276 436 105 287 minecraft:iron_block
fill 437 104 317 440 111 317 minecraft:black_concrete
fill 442 104 276 442 105 281 minecraft:iron_block
fill 446 104 275 449 111 275 minecraft:black_concrete
fill 447 104 317 450 111 317 minecraft:black_concrete
fill 448 104 276 448 104 285 minecraft:iron_block
fill 448 104 291 448 104 316 minecraft:iron_block
fill 454 104 276 454 104 281 minecraft:iron_block
fill 454 104 282 464 104 282 minecraft:gray_concrete
fill 454 104 283 454 104 314 minecraft:iron_block
fill 456 104 275 459 111 275 minecraft:black_concrete
fill 457 104 317 460 111 317 minecraft:black_concrete
fill 460 104 276 460 105 281 minecraft:iron_block
fill 460 104 283 460 105 283 minecraft:iron_block
fill 465 104 276 465 111 279 minecraft:black_concrete
fill 465 104 286 465 111 289 minecraft:black_concrete
fill 465 104 296 465 111 299 minecraft:black_concrete
fill 465 104 306 465 111 309 minecraft:black_concrete
fill 465 104 316 465 111 316 minecraft:black_concrete
fill 430 105 276 430 105 286 minecraft:iron_block
fill 430 105 314 430 115 314 minecraft:purple_wool
fill 436 105 288 436 105 316 minecraft:iron_block
fill 442 105 282 442 105 286 minecraft:iron_block
fill 442 105 290 442 105 316 minecraft:iron_block
fill 448 105 276 448 105 284 minecraft:iron_block
fill 454 105 276 454 105 279 minecraft:iron_block
setblock 460 105 282 minecraft:iron_block
fill 460 105 284 460 105 316 minecraft:iron_block
setblock 426 106 278 minecraft:light[level=12]
setblock 426 106 285 minecraft:light[level=12]
setblock 426 106 292 minecraft:light[level=12]
setblock 426 106 299 minecraft:light[level=12]
setblock 426 106 306 minecraft:light[level=12]
setblock 426 106 313 minecraft:light[level=12]
setblock 433 106 278 minecraft:light[level=12]
setblock 433 106 285 minecraft:light[level=12]
setblock 433 106 292 minecraft:light[level=12]
setblock 433 106 299 minecraft:light[level=12]
setblock 433 106 306 minecraft:light[level=12]
setblock 433 106 313 minecraft:light[level=12]
setblock 440 106 278 minecraft:light[level=12]
setblock 440 106 285 minecraft:light[level=12]
setblock 440 106 292 minecraft:light[level=12]
setblock 440 106 299 minecraft:light[level=12]
setblock 440 106 306 minecraft:light[level=12]
setblock 440 106 313 minecraft:light[level=12]
setblock 447 106 278 minecraft:light[level=12]
setblock 447 106 285 minecraft:light[level=12]
setblock 447 106 292 minecraft:light[level=12]
setblock 447 106 299 minecraft:light[level=12]
setblock 447 106 306 minecraft:light[level=12]
setblock 447 106 313 minecraft:light[level=12]
setblock 454 106 278 minecraft:light[level=12]
setblock 454 106 285 minecraft:light[level=12]
setblock 454 106 292 minecraft:light[level=12]
setblock 454 106 299 minecraft:light[level=12]
setblock 454 106 306 minecraft:light[level=12]
setblock 454 106 313 minecraft:light[level=12]
setblock 461 106 278 minecraft:light[level=12]
setblock 461 106 285 minecraft:light[level=12]
setblock 461 106 292 minecraft:light[level=12]
setblock 461 106 299 minecraft:light[level=12]
setblock 461 106 306 minecraft:light[level=12]
setblock 461 106 313 minecraft:light[level=12]
setblock 424 108 278 minecraft:gray_concrete
fill 424 108 280 424 108 283 minecraft:gray_concrete
setblock 424 108 288 minecraft:gray_concrete
fill 424 108 290 424 108 293 minecraft:gray_concrete
setblock 424 108 298 minecraft:gray_concrete
fill 424 108 300 424 108 303 minecraft:gray_concrete
setblock 424 108 308 minecraft:gray_concrete
fill 424 108 310 424 108 313 minecraft:gray_concrete
fill 425 108 276 428 108 276 minecraft:gray_concrete
setblock 426 108 278 minecraft:light[level=15]
setblock 426 108 286 minecraft:light[level=15]
setblock 426 108 294 minecraft:light[level=15]
setblock 426 108 302 minecraft:light[level=15]
setblock 426 108 310 minecraft:light[level=15]
setblock 426 108 316 minecraft:gray_concrete
fill 428 108 316 431 108 316 minecraft:gray_concrete
setblock 430 108 276 minecraft:gray_concrete
setblock 434 108 278 minecraft:light[level=15]
setblock 434 108 286 minecraft:light[level=15]
setblock 434 108 294 minecraft:light[level=15]
setblock 434 108 302 minecraft:light[level=15]
setblock 434 108 310 minecraft:light[level=15]
fill 435 108 276 438 108 276 minecraft:gray_concrete
setblock 436 108 316 minecraft:gray_concrete
fill 438 108 316 441 108 316 minecraft:gray_concrete
setblock 440 108 276 minecraft:gray_concrete
setblock 442 108 278 minecraft:light[level=15]
setblock 442 108 286 minecraft:light[level=15]
setblock 442 108 294 minecraft:light[level=15]
setblock 442 108 302 minecraft:light[level=15]
setblock 442 108 310 minecraft:light[level=15]
fill 445 108 276 448 108 276 minecraft:gray_concrete
setblock 446 108 316 minecraft:gray_concrete
fill 448 108 316 451 108 316 minecraft:gray_concrete
setblock 450 108 276 minecraft:gray_concrete
setblock 450 108 278 minecraft:light[level=15]
setblock 450 108 286 minecraft:light[level=15]
setblock 450 108 294 minecraft:light[level=15]
setblock 450 108 302 minecraft:light[level=15]
setblock 450 108 310 minecraft:light[level=15]
fill 455 108 276 458 108 276 minecraft:gray_concrete
setblock 456 108 316 minecraft:gray_concrete
setblock 458 108 278 minecraft:light[level=15]
setblock 458 108 286 minecraft:light[level=15]
setblock 458 108 294 minecraft:light[level=15]
setblock 458 108 302 minecraft:light[level=15]
setblock 458 108 310 minecraft:light[level=15]
fill 458 108 316 461 108 316 minecraft:gray_concrete
setblock 460 108 276 minecraft:gray_concrete
fill 464 108 277 464 108 280 minecraft:gray_concrete
setblock 464 108 282 minecraft:gray_concrete
fill 464 108 287 464 108 290 minecraft:gray_concrete
setblock 464 108 292 minecraft:gray_concrete
fill 464 108 297 464 108 300 minecraft:gray_concrete
setblock 464 108 302 minecraft:gray_concrete
fill 464 108 307 464 108 310 minecraft:gray_concrete
setblock 464 108 312 minecraft:gray_concrete
fill 423 112 281 423 112 284 minecraft:sea_lantern
fill 423 112 291 423 112 294 minecraft:sea_lantern
fill 423 112 301 423 112 304 minecraft:sea_lantern
fill 423 112 311 423 112 314 minecraft:sea_lantern
fill 426 112 275 429 112 275 minecraft:sea_lantern
setblock 426 112 278 minecraft:light[level=12]
setblock 426 112 285 minecraft:light[level=12]
setblock 426 112 292 minecraft:light[level=12]
setblock 426 112 299 minecraft:light[level=12]
setblock 426 112 306 minecraft:light[level=12]
setblock 426 112 313 minecraft:light[level=12]
fill 427 112 317 430 112 317 minecraft:sea_lantern
setblock 433 112 278 minecraft:light[level=12]
setblock 433 112 285 minecraft:light[level=12]
setblock 433 112 292 minecraft:light[level=12]
setblock 433 112 299 minecraft:light[level=12]
setblock 433 112 306 minecraft:light[level=12]
setblock 433 112 313 minecraft:light[level=12]
fill 436 112 275 439 112 275 minecraft:sea_lantern
fill 437 112 317 440 112 317 minecraft:sea_lantern
setblock 440 112 278 minecraft:light[level=12]
setblock 440 112 285 minecraft:light[level=12]
setblock 440 112 292 minecraft:light[level=12]
setblock 440 112 299 minecraft:light[level=12]
setblock 440 112 306 minecraft:light[level=12]
setblock 440 112 313 minecraft:light[level=12]
fill 446 112 275 449 112 275 minecraft:sea_lantern
setblock 447 112 278 minecraft:light[level=12]
setblock 447 112 285 minecraft:light[level=12]
setblock 447 112 292 minecraft:light[level=12]
setblock 447 112 299 minecraft:light[level=12]
setblock 447 112 306 minecraft:light[level=12]
setblock 447 112 313 minecraft:light[level=12]
fill 447 112 317 450 112 317 minecraft:sea_lantern
setblock 454 112 278 minecraft:light[level=12]
setblock 454 112 285 minecraft:light[level=12]
setblock 454 112 292 minecraft:light[level=12]
setblock 454 112 299 minecraft:light[level=12]
setblock 454 112 306 minecraft:light[level=12]
setblock 454 112 313 minecraft:light[level=12]
fill 456 112 275 459 112 275 minecraft:sea_lantern
fill 457 112 317 460 112 317 minecraft:sea_lantern
setblock 461 112 278 minecraft:light[level=12]
setblock 461 112 285 minecraft:light[level=12]
setblock 461 112 292 minecraft:light[level=12]
setblock 461 112 299 minecraft:light[level=12]
setblock 461 112 306 minecraft:light[level=12]
setblock 461 112 313 minecraft:light[level=12]
fill 465 112 276 465 112 279 minecraft:sea_lantern
fill 465 112 286 465 112 289 minecraft:sea_lantern
fill 465 112 296 465 112 299 minecraft:sea_lantern
fill 465 112 306 465 112 309 minecraft:sea_lantern
setblock 465 112 316 minecraft:sea_lantern
fill 423 113 281 423 120 284 minecraft:black_concrete
fill 423 113 291 423 120 294 minecraft:black_concrete
fill 423 113 301 423 120 304 minecraft:black_concrete
fill 423 113 311 423 120 314 minecraft:black_concrete
fill 426 113 275 429 120 275 minecraft:black_concrete
fill 427 113 317 430 120 317 minecraft:black_concrete
fill 436 113 275 439 120 275 minecraft:black_concrete
fill 437 113 317 440 120 317 minecraft:black_concrete
fill 446 113 275 449 120 275 minecraft:black_concrete
fill 447 113 317 450 120 317 minecraft:black_concrete
fill 456 113 275 459 120 275 minecraft:black_concrete
fill 457 113 317 460 120 317 minecraft:black_concrete
fill 465 113 276 465 120 279 minecraft:black_concrete
fill 465 113 286 465 120 289 minecraft:black_concrete
fill 465 113 296 465 120 299 minecraft:black_concrete
fill 465 113 306 465 120 309 minecraft:black_concrete
fill 465 113 316 465 120 316 minecraft:black_concrete
setblock 424 114 278 minecraft:gray_concrete
setblock 424 114 288 minecraft:gray_concrete
setblock 424 114 298 minecraft:gray_concrete
setblock 424 114 308 minecraft:gray_concrete
setblock 426 114 316 minecraft:gray_concrete
setblock 430 114 276 minecraft:gray_concrete
setblock 436 114 316 minecraft:gray_concrete
setblock 440 114 276 minecraft:gray_concrete
setblock 446 114 316 minecraft:gray_concrete
setblock 450 114 276 minecraft:gray_concrete
setblock 456 114 316 minecraft:gray_concrete
setblock 460 114 276 minecraft:gray_concrete
setblock 464 114 282 minecraft:gray_concrete
setblock 464 114 292 minecraft:gray_concrete
setblock 464 114 302 minecraft:gray_concrete
setblock 464 114 312 minecraft:gray_concrete
fill 437 115 291 438 116 292 minecraft:light_blue_concrete
fill 461 115 280 463 116 280 minecraft:iron_block
setblock 426 116 278 minecraft:light[level=15]
setblock 426 116 286 minecraft:light[level=15]
setblock 426 116 294 minecraft:light[level=15]
setblock 426 116 302 minecraft:light[level=15]
setblock 426 116 310 minecraft:light[level=15]
fill 426 116 314 432 116 314 minecraft:iron_block
setblock 434 116 278 minecraft:light[level=15]
setblock 434 116 286 minecraft:light[level=15]
setblock 434 116 294 minecraft:light[level=15]
setblock 434 116 302 minecraft:light[level=15]
setblock 434 116 310 minecraft:light[level=15]
setblock 442 116 278 minecraft:light[level=15]
setblock 442 116 286 minecraft:light[level=15]
setblock 442 116 294 minecraft:light[level=15]
setblock 442 116 302 minecraft:light[level=15]
setblock 442 116 310 minecraft:light[level=15]
setblock 450 116 278 minecraft:light[level=15]
setblock 450 116 286 minecraft:light[level=15]
setblock 450 116 294 minecraft:light[level=15]
setblock 450 116 302 minecraft:light[level=15]
setblock 450 116 310 minecraft:light[level=15]
setblock 458 116 278 minecraft:light[level=15]
setblock 458 116 286 minecraft:light[level=15]
setblock 458 116 294 minecraft:light[level=15]
setblock 458 116 302 minecraft:light[level=15]
setblock 458 116 310 minecraft:light[level=15]
fill 424 117 280 424 117 283 minecraft:gray_concrete
fill 424 117 290 424 117 293 minecraft:gray_concrete
fill 424 117 300 424 117 303 minecraft:gray_concrete
fill 424 117 310 424 117 313 minecraft:gray_concrete
fill 425 117 276 428 117 276 minecraft:gray_concrete
fill 426 117 314 429 117 314 minecraft:iron_block
fill 428 117 316 431 117 316 minecraft:gray_concrete
fill 430 117 313 432 117 315 minecraft:black_concrete
fill 435 117 276 438 117 276 minecraft:gray_concrete
fill 438 117 316 441 117 316 minecraft:gray_concrete
fill 445 117 276 448 117 276 minecraft:gray_concrete
fill 448 117 316 451 117 316 minecraft:gray_concrete
fill 455 117 276 458 117 276 minecraft:gray_concrete
fill 458 117 316 461 117 316 minecraft:gray_concrete
fill 460 117 313 460 118 315 minecraft:iron_block
fill 464 117 277 464 117 280 minecraft:gray_concrete
fill 464 117 287 464 117 290 minecraft:gray_concrete
fill 464 117 297 464 117 300 minecraft:gray_concrete
fill 464 117 307 464 117 310 minecraft:gray_concrete
fill 424 118 286 426 120 286 minecraft:iron_block
setblock 426 118 278 minecraft:light[level=12]
setblock 426 118 285 minecraft:light[level=12]
setblock 426 118 292 minecraft:light[level=12]
setblock 426 118 299 minecraft:light[level=12]
setblock 426 118 306 minecraft:light[level=12]
setblock 426 118 313 minecraft:light[level=12]
fill 430 118 313 430 118 315 minecraft:black_concrete
fill 431 118 313 432 118 313 minecraft:black_concrete
fill 431 118 314 431 120 314 minecraft:gray_concrete
fill 431 118 315 432 118 315 minecraft:black_concrete
setblock 432 118 314 minecraft:black_concrete
setblock 433 118 278 minecraft:light[level=12]
setblock 433 118 285 minecraft:light[level=12]
setblock 433 118 292 minecraft:light[level=12]
setblock 433 118 299 minecraft:light[level=12]
setblock 433 118 306 minecraft:light[level=12]
setblock 433 118 313 minecraft:light[level=12]
setblock 440 118 278 minecraft:light[level=12]
setblock 440 118 285 minecraft:light[level=12]
setblock 440 118 292 minecraft:light[level=12]
setblock 440 118 299 minecraft:light[level=12]
setblock 440 118 306 minecraft:light[level=12]
setblock 440 118 313 minecraft:light[level=12]
setblock 447 118 278 minecraft:light[level=12]
setblock 447 118 285 minecraft:light[level=12]
setblock 447 118 292 minecraft:light[level=12]
setblock 447 118 299 minecraft:light[level=12]
setblock 447 118 306 minecraft:light[level=12]
setblock 447 118 313 minecraft:light[level=12]
setblock 454 118 278 minecraft:light[level=12]
setblock 454 118 285 minecraft:light[level=12]
setblock 454 118 292 minecraft:light[level=12]
setblock 454 118 299 minecraft:light[level=12]
setblock 454 118 306 minecraft:light[level=12]
setblock 454 118 313 minecraft:light[level=12]
setblock 461 118 278 minecraft:light[level=12]
setblock 461 118 285 minecraft:light[level=12]
setblock 461 118 292 minecraft:light[level=12]
setblock 461 118 299 minecraft:light[level=12]
setblock 461 118 306 minecraft:light[level=12]
setblock 461 118 313 minecraft:light[level=12]
fill 428 119 313 429 119 315 minecraft:black_concrete
fill 430 119 313 430 123 313 minecraft:black_concrete
setblock 430 119 314 minecraft:gray_concrete
fill 430 119 315 430 123 315 minecraft:black_concrete
setblock 431 119 313 minecraft:gray_concrete
setblock 431 119 315 minecraft:gray_concrete
fill 432 119 313 432 121 313 minecraft:black_concrete
setblock 432 119 314 minecraft:gray_concrete
fill 432 119 315 432 121 315 minecraft:black_concrete
setblock 424 120 278 minecraft:gray_concrete
setblock 424 120 288 minecraft:gray_concrete
setblock 424 120 298 minecraft:gray_concrete
setblock 424 120 308 minecraft:gray_concrete
setblock 426 120 316 minecraft:gray_concrete
fill 428 120 313 428 120 315 minecraft:black_concrete
setblock 429 120 313 minecraft:black_concrete
fill 429 120 314 429 122 314 minecraft:gray_concrete
setblock 429 120 315 minecraft:black_concrete
setblock 430 120 276 minecraft:gray_concrete
fill 430 120 314 430 123 314 minecraft:black_concrete
fill 431 120 313 431 121 313 minecraft:black_concrete
fill 431 120 315 431 121 315 minecraft:black_concrete
fill 432 120 314 432 121 314 minecraft:black_concrete
setblock 436 120 316 minecraft:gray_concrete
setblock 440 120 276 minecraft:gray_concrete
setblock 446 120 316 minecraft:gray_concrete
setblock 450 120 276 minecraft:gray_concrete
setblock 456 120 316 minecraft:gray_concrete
setblock 460 120 276 minecraft:gray_concrete
setblock 464 120 282 minecraft:gray_concrete
setblock 464 120 292 minecraft:gray_concrete
setblock 464 120 302 minecraft:gray_concrete
setblock 464 120 312 minecraft:gray_concrete
fill 423 121 281 423 121 284 minecraft:sea_lantern
fill 423 121 291 423 121 294 minecraft:sea_lantern
fill 423 121 301 423 121 304 minecraft:sea_lantern
fill 423 121 311 423 121 314 minecraft:sea_lantern
fill 425 121 298 426 122 298 minecraft:lime_concrete
fill 426 121 275 429 121 275 minecraft:sea_lantern
fill 427 121 276 427 122 278 minecraft:iron_block
fill 427 121 317 430 121 317 minecraft:sea_lantern
fill 428 121 313 428 123 313 minecraft:black_concrete
setblock 428 121 314 minecraft:gray_concrete
fill 428 121 315 428 123 315 minecraft:black_concrete
setblock 429 121 313 minecraft:gray_concrete
setblock 429 121 315 minecraft:gray_concrete
setblock 431 121 314 minecraft:black_concrete
fill 436 121 275 439 121 275 minecraft:sea_lantern
fill 437 121 317 440 121 317 minecraft:sea_lantern
fill 446 121 275 449 121 275 minecraft:sea_lantern
fill 447 121 317 450 121 317 minecraft:sea_lantern
fill 456 121 275 459 121 275 minecraft:sea_lantern
fill 457 121 317 460 121 317 minecraft:sea_lantern
fill 465 121 276 465 121 279 minecraft:sea_lantern
fill 465 121 286 465 121 289 minecraft:sea_lantern
fill 465 121 296 465 121 299 minecraft:sea_lantern
fill 465 121 306 465 121 309 minecraft:sea_lantern
setblock 465 121 316 minecraft:sea_lantern
fill 423 122 281 423 129 284 minecraft:black_concrete
fill 423 122 291 423 129 294 minecraft:black_concrete
fill 423 122 301 423 129 304 minecraft:black_concrete
fill 423 122 311 423 129 314 minecraft:black_concrete
fill 426 122 275 429 129 275 minecraft:black_concrete
fill 427 122 317 430 129 317 minecraft:black_concrete
fill 428 122 314 428 123 314 minecraft:black_concrete
fill 429 122 313 429 123 313 minecraft:black_concrete
fill 429 122 315 429 123 315 minecraft:black_concrete
fill 436 122 275 439 129 275 minecraft:black_concrete
fill 437 122 317 440 129 317 minecraft:black_concrete
fill 446 122 275 449 129 275 minecraft:black_concrete
fill 447 122 317 450 129 317 minecraft:black_concrete
fill 456 122 275 459 129 275 minecraft:black_concrete
fill 457 122 317 460 129 317 minecraft:black_concrete
fill 465 122 276 465 129 279 minecraft:black_concrete
fill 465 122 286 465 129 289 minecraft:black_concrete
fill 465 122 296 465 129 299 minecraft:black_concrete
fill 465 122 306 465 129 309 minecraft:black_concrete
fill 465 122 316 465 129 316 minecraft:black_concrete
setblock 429 123 314 minecraft:black_concrete
setblock 426 124 278 minecraft:light[level=15]
setblock 426 124 285 minecraft:light[level=12]
setblock 426 124 286 minecraft:light[level=15]
setblock 426 124 292 minecraft:light[level=12]
setblock 426 124 294 minecraft:light[level=15]
setblock 426 124 299 minecraft:light[level=12]
setblock 426 124 302 minecraft:light[level=15]
setblock 426 124 306 minecraft:light[level=12]
setblock 426 124 310 minecraft:light[level=15]
setblock 426 124 313 minecraft:light[level=12]
setblock 433 124 278 minecraft:light[level=12]
setblock 433 124 285 minecraft:light[level=12]
setblock 433 124 292 minecraft:light[level=12]
setblock 433 124 299 minecraft:light[level=12]
setblock 433 124 306 minecraft:light[level=12]
setblock 433 124 313 minecraft:light[level=12]
setblock 434 124 278 minecraft:light[level=15]
setblock 434 124 286 minecraft:light[level=15]
setblock 434 124 294 minecraft:light[level=15]
setblock 434 124 302 minecraft:light[level=15]
setblock 434 124 310 minecraft:light[level=15]
setblock 440 124 278 minecraft:light[level=12]
setblock 440 124 285 minecraft:light[level=12]
setblock 440 124 292 minecraft:light[level=12]
setblock 440 124 299 minecraft:light[level=12]
setblock 440 124 306 minecraft:light[level=12]
setblock 440 124 313 minecraft:light[level=12]
setblock 442 124 278 minecraft:light[level=15]
setblock 442 124 286 minecraft:light[level=15]
setblock 442 124 294 minecraft:light[level=15]
setblock 442 124 302 minecraft:light[level=15]
setblock 442 124 310 minecraft:light[level=15]
setblock 447 124 278 minecraft:light[level=12]
setblock 447 124 285 minecraft:light[level=12]
setblock 447 124 292 minecraft:light[level=12]
setblock 447 124 299 minecraft:light[level=12]
setblock 447 124 306 minecraft:light[level=12]
setblock 447 124 313 minecraft:light[level=12]
setblock 450 124 278 minecraft:light[level=15]
setblock 450 124 286 minecraft:light[level=15]
setblock 450 124 294 minecraft:light[level=15]
setblock 450 124 302 minecraft:light[level=15]
setblock 450 124 310 minecraft:light[level=15]
setblock 454 124 278 minecraft:light[level=12]
setblock 454 124 285 minecraft:light[level=12]
setblock 454 124 292 minecraft:light[level=12]
setblock 454 124 299 minecraft:light[level=12]
setblock 454 124 306 minecraft:light[level=12]
setblock 454 124 313 minecraft:light[level=12]
setblock 458 124 278 minecraft:light[level=15]
setblock 458 124 286 minecraft:light[level=15]
setblock 458 124 294 minecraft:light[level=15]
setblock 458 124 302 minecraft:light[level=15]
setblock 458 124 310 minecraft:light[level=15]
setblock 461 124 278 minecraft:light[level=12]
setblock 461 124 285 minecraft:light[level=12]
setblock 461 124 292 minecraft:light[level=12]
setblock 461 124 299 minecraft:light[level=12]
setblock 461 124 306 minecraft:light[level=12]
setblock 461 124 313 minecraft:light[level=12]
setblock 424 126 278 minecraft:gray_concrete
fill 424 126 280 424 126 283 minecraft:gray_concrete
setblock 424 126 288 minecraft:gray_concrete
fill 424 126 290 424 126 293 minecraft:gray_concrete
setblock 424 126 298 minecraft:gray_concrete
fill 424 126 300 424 126 303 minecraft:gray_concrete
setblock 424 126 308 minecraft:gray_concrete
fill 424 126 310 424 126 313 minecraft:gray_concrete
fill 425 126 276 428 126 276 minecraft:gray_concrete
setblock 426 126 316 minecraft:gray_concrete
fill 428 126 316 431 126 316 minecraft:gray_concrete
setblock 430 126 276 minecraft:gray_concrete
fill 435 126 276 438 126 276 minecraft:gray_concrete
setblock 436 126 316 minecraft:gray_concrete
fill 438 126 316 441 126 316 minecraft:gray_concrete
setblock 440 126 276 minecraft:gray_concrete
fill 445 126 276 448 126 276 minecraft:gray_concrete
setblock 446 126 316 minecraft:gray_concrete
fill 448 126 316 451 126 316 minecraft:gray_concrete
setblock 450 126 276 minecraft:gray_concrete
fill 455 126 276 458 126 276 minecraft:gray_concrete
setblock 456 126 316 minecraft:gray_concrete
fill 458 126 316 461 126 316 minecraft:gray_concrete
setblock 460 126 276 minecraft:gray_concrete
fill 464 126 277 464 126 280 minecraft:gray_concrete
setblock 464 126 282 minecraft:gray_concrete
fill 464 126 287 464 126 290 minecraft:gray_concrete
setblock 464 126 292 minecraft:gray_concrete
fill 464 126 297 464 126 300 minecraft:gray_concrete
setblock 464 126 302 minecraft:gray_concrete
fill 464 126 307 464 126 310 minecraft:gray_concrete
setblock 464 126 312 minecraft:gray_concrete
fill 426 128 294 427 129 298 minecraft:gray_concrete
fill 427 128 290 427 129 293 minecraft:gray_concrete
fill 427 128 299 427 129 302 minecraft:gray_concrete
fill 428 128 288 428 129 290 minecraft:gray_concrete
fill 428 128 302 428 129 304 minecraft:gray_concrete
fill 429 128 286 429 129 288 minecraft:gray_concrete
fill 429 128 304 429 129 306 minecraft:gray_concrete
fill 430 128 285 430 129 286 minecraft:gray_concrete
fill 430 128 306 430 129 307 minecraft:gray_concrete
fill 431 128 284 431 129 285 minecraft:gray_concrete
fill 431 128 307 431 129 308 minecraft:gray_concrete
fill 432 128 283 432 129 284 minecraft:gray_concrete
fill 432 128 308 432 129 309 minecraft:gray_concrete
fill 433 128 282 433 129 283 minecraft:gray_concrete
fill 433 128 309 433 129 310 minecraft:gray_concrete
fill 434 128 281 434 129 282 minecraft:gray_concrete
fill 434 128 310 434 129 311 minecraft:gray_concrete
fill 435 128 281 436 129 281 minecraft:gray_concrete
fill 435 128 311 436 129 311 minecraft:gray_concrete
fill 436 128 280 438 129 280 minecraft:gray_concrete
fill 436 128 312 438 129 312 minecraft:gray_concrete
fill 438 128 279 450 129 279 minecraft:gray_concrete
fill 438 128 313 450 129 313 minecraft:gray_concrete
fill 442 128 278 446 129 278 minecraft:gray_concrete
fill 442 128 314 446 129 314 minecraft:gray_concrete
fill 450 128 280 452 129 280 minecraft:gray_concrete
fill 450 128 312 452 129 312 minecraft:gray_concrete
fill 452 128 281 454 129 281 minecraft:gray_concrete
fill 452 128 311 454 129 311 minecraft:gray_concrete
fill 454 128 282 455 129 282 minecraft:gray_concrete
fill 454 128 310 455 129 310 minecraft:gray_concrete
fill 455 128 283 456 129 283 minecraft:gray_concrete
fill 455 128 309 456 129 309 minecraft:gray_concrete
fill 456 128 284 457 129 284 minecraft:gray_concrete
fill 456 128 308 457 129 308 minecraft:gray_concrete
fill 457 128 285 458 129 285 minecraft:gray_concrete
fill 457 128 307 458 129 307 minecraft:gray_concrete
fill 458 128 286 459 129 286 minecraft:gray_concrete
fill 458 128 306 459 129 306 minecraft:gray_concrete
fill 459 128 287 459 129 288 minecraft:gray_concrete
fill 459 128 304 459 129 305 minecraft:gray_concrete
fill 460 128 288 460 129 290 minecraft:gray_concrete
fill 460 128 302 460 129 304 minecraft:gray_concrete
fill 461 128 290 461 129 302 minecraft:gray_concrete
fill 462 128 294 462 129 298 minecraft:gray_concrete
fill 423 130 281 423 130 284 minecraft:sea_lantern
fill 423 130 291 423 130 294 minecraft:sea_lantern
fill 423 130 301 423 130 304 minecraft:sea_lantern
fill 423 130 311 423 130 314 minecraft:sea_lantern
fill 426 130 275 429 130 275 minecraft:sea_lantern
setblock 426 130 278 minecraft:light[level=12]
setblock 426 130 285 minecraft:light[level=12]
fill 426 130 292 426 130 300 minecraft:sea_lantern
setblock 426 130 306 minecraft:light[level=12]
setblock 426 130 313 minecraft:light[level=12]
fill 427 130 289 427 130 291 minecraft:sea_lantern
fill 427 130 301 427 130 303 minecraft:sea_lantern
fill 427 130 317 430 130 317 minecraft:sea_lantern
setblock 428 130 288 minecraft:sea_lantern
fill 428 130 304 428 130 305 minecraft:sea_lantern
setblock 429 130 306 minecraft:sea_lantern
fill 430 130 307 430 130 308 minecraft:sea_lantern
fill 431 130 308 431 130 309 minecraft:sea_lantern
fill 432 130 309 432 130 310 minecraft:sea_lantern
setblock 433 130 278 minecraft:light[level=12]
setblock 433 130 285 minecraft:light[level=12]
setblock 433 130 292 minecraft:light[level=12]
setblock 433 130 299 minecraft:light[level=12]
setblock 433 130 306 minecraft:light[level=12]
setblock 433 130 310 minecraft:sea_lantern
setblock 433 130 313 minecraft:light[level=12]
setblock 434 130 311 minecraft:sea_lantern
fill 435 130 312 436 130 312 minecraft:sea_lantern
fill 436 130 275 439 130 275 minecraft:sea_lantern
fill 437 130 313 439 130 313 minecraft:sea_lantern
fill 437 130 317 440 130 317 minecraft:sea_lantern
setblock 440 130 278 minecraft:light[level=12]
setblock 440 130 285 minecraft:light[level=12]
setblock 440 130 292 minecraft:light[level=12]
setblock 440 130 299 minecraft:light[level=12]
setblock 440 130 306 minecraft:light[level=12]
setblock 440 130 313 minecraft:light[level=12]
fill 440 130 314 448 130 314 minecraft:sea_lantern
fill 446 130 275 449 130 275 minecraft:sea_lantern
setblock 447 130 278 minecraft:light[level=12]
setblock 447 130 285 minecraft:light[level=12]
setblock 447 130 292 minecraft:light[level=12]
setblock 447 130 299 minecraft:light[level=12]
setblock 447 130 306 minecraft:light[level=12]
setblock 447 130 313 minecraft:light[level=12]
fill 447 130 317 450 130 317 minecraft:sea_lantern
fill 449 130 313 451 130 313 minecraft:sea_lantern
fill 452 130 312 453 130 312 minecraft:sea_lantern
setblock 454 130 278 minecraft:light[level=12]
setblock 454 130 285 minecraft:light[level=12]
setblock 454 130 292 minecraft:light[level=12]
setblock 454 130 299 minecraft:light[level=12]
setblock 454 130 306 minecraft:light[level=12]
setblock 454 130 311 minecraft:sea_lantern
setblock 454 130 313 minecraft:light[level=12]
fill 455 130 310 456 130 310 minecraft:sea_lantern
fill 456 130 275 459 130 275 minecraft:sea_lantern
fill 456 130 309 457 130 309 minecraft:sea_lantern
fill 457 130 308 458 130 308 minecraft:sea_lantern
fill 457 130 317 460 130 317 minecraft:sea_lantern
setblock 458 130 307 minecraft:sea_lantern
setblock 459 130 306 minecraft:sea_lantern
fill 460 130 304 460 130 305 minecraft:sea_lantern
setblock 461 130 278 minecraft:light[level=12]
setblock 461 130 285 minecraft:light[level=12]
fill 461 130 289 461 130 291 minecraft:sea_lantern
setblock 461 130 292 minecraft:light[level=12]
setblock 461 130 299 minecraft:light[level=12]
fill 461 130 301 461 130 303 minecraft:sea_lantern
setblock 461 130 306 minecraft:light[level=12]
setblock 461 130 313 minecraft:light[level=12]
fill 462 130 292 462 130 300 minecraft:sea_lantern
fill 465 130 276 465 130 279 minecraft:sea_lantern
fill 465 130 286 465 130 289 minecraft:sea_lantern
fill 465 130 296 465 130 299 minecraft:sea_lantern
fill 465 130 306 465 130 309 minecraft:sea_lantern
setblock 465 130 316 minecraft:sea_lantern
fill 423 131 281 423 138 284 minecraft:black_concrete
fill 423 131 291 423 138 294 minecraft:black_concrete
fill 423 131 301 423 138 304 minecraft:black_concrete
fill 423 131 311 423 138 314 minecraft:black_concrete
fill 426 131 275 429 138 275 minecraft:black_concrete
fill 427 131 317 430 138 317 minecraft:black_concrete
fill 436 131 275 439 138 275 minecraft:black_concrete
fill 437 131 317 440 138 317 minecraft:black_concrete
fill 446 131 275 449 138 275 minecraft:black_concrete
fill 447 131 317 450 138 317 minecraft:black_concrete
fill 456 131 275 459 138 275 minecraft:black_concrete
fill 457 131 317 460 138 317 minecraft:black_concrete
fill 465 131 276 465 138 279 minecraft:black_concrete
fill 465 131 286 465 138 289 minecraft:black_concrete
fill 465 131 296 465 138 299 minecraft:black_concrete
fill 465 131 306 465 138 309 minecraft:black_concrete
fill 465 131 316 465 138 316 minecraft:black_concrete
setblock 424 132 278 minecraft:gray_concrete
setblock 424 132 288 minecraft:gray_concrete
setblock 424 132 298 minecraft:gray_concrete
setblock 424 132 308 minecraft:gray_concrete
setblock 426 132 278 minecraft:light[level=15]
setblock 426 132 286 minecraft:light[level=15]
setblock 426 132 294 minecraft:light[level=15]
setblock 426 132 302 minecraft:light[level=15]
setblock 426 132 310 minecraft:light[level=15]
setblock 426 132 316 minecraft:gray_concrete
setblock 430 132 276 minecraft:gray_concrete
setblock 434 132 278 minecraft:light[level=15]
setblock 434 132 286 minecraft:light[level=15]
setblock 434 132 294 minecraft:light[level=15]
setblock 434 132 302 minecraft:light[level=15]
setblock 434 132 310 minecraft:light[level=15]
setblock 436 132 316 minecraft:gray_concrete
setblock 440 132 276 minecraft:gray_concrete
setblock 442 132 278 minecraft:light[level=15]
setblock 442 132 286 minecraft:light[level=15]
setblock 442 132 294 minecraft:light[level=15]
setblock 442 132 302 minecraft:light[level=15]
setblock 442 132 310 minecraft:light[level=15]
setblock 446 132 316 minecraft:gray_concrete
setblock 450 132 276 minecraft:gray_concrete
setblock 450 132 278 minecraft:light[level=15]
setblock 450 132 286 minecraft:light[level=15]
setblock 450 132 294 minecraft:light[level=15]
setblock 450 132 302 minecraft:light[level=15]
setblock 450 132 310 minecraft:light[level=15]
setblock 456 132 316 minecraft:gray_concrete
setblock 458 132 278 minecraft:light[level=15]
setblock 458 132 286 minecraft:light[level=15]
setblock 458 132 294 minecraft:light[level=15]
setblock 458 132 302 minecraft:light[level=15]
setblock 458 132 310 minecraft:light[level=15]
setblock 460 132 276 minecraft:gray_concrete
setblock 464 132 282 minecraft:gray_concrete
setblock 464 132 292 minecraft:gray_concrete
setblock 464 132 302 minecraft:gray_concrete
setblock 464 132 312 minecraft:gray_concrete
fill 426 133 302 430 148 304 minecraft:magenta_concrete
fill 427 133 301 429 148 301 minecraft:magenta_concrete
fill 427 133 305 429 148 305 minecraft:magenta_concrete
fill 424 134 301 425 134 305 minecraft:magenta_concrete
fill 425 134 300 431 147 300 minecraft:magenta_concrete
fill 425 134 306 431 147 306 minecraft:magenta_concrete
fill 426 134 299 430 147 299 minecraft:magenta_concrete
fill 426 134 301 426 147 301 minecraft:magenta_concrete
fill 426 134 305 426 147 305 minecraft:magenta_concrete
fill 426 134 307 430 147 307 minecraft:magenta_concrete
fill 430 134 301 432 147 301 minecraft:magenta_concrete
fill 430 134 305 432 147 305 minecraft:magenta_concrete
fill 431 134 302 432 147 304 minecraft:magenta_concrete
fill 424 135 280 424 135 283 minecraft:gray_concrete
fill 424 135 290 424 135 293 minecraft:gray_concrete
fill 424 135 299 425 146 299 minecraft:magenta_concrete
fill 424 135 300 424 135 303 minecraft:gray_concrete
fill 424 135 304 424 146 306 minecraft:magenta_concrete
fill 424 135 310 424 135 313 minecraft:gray_concrete
fill 425 135 276 428 135 276 minecraft:gray_concrete
fill 425 135 301 425 147 305 minecraft:magenta_concrete
fill 425 135 307 425 146 307 minecraft:magenta_concrete
fill 426 135 298 430 146 298 minecraft:magenta_concrete
fill 426 135 308 430 146 308 minecraft:magenta_concrete
fill 428 135 316 431 135 316 minecraft:gray_concrete
fill 431 135 299 432 146 299 minecraft:magenta_concrete
fill 431 135 307 432 146 307 minecraft:magenta_concrete
fill 432 135 300 432 146 300 minecraft:magenta_concrete
fill 432 135 306 432 146 306 minecraft:magenta_concrete
fill 433 135 301 433 146 305 minecraft:magenta_concrete
fill 435 135 276 438 135 276 minecraft:gray_concrete
fill 438 135 316 441 135 316 minecraft:gray_concrete
fill 445 135 276 448 135 276 minecraft:gray_concrete
fill 448 135 316 451 135 316 minecraft:gray_concrete
fill 455 135 276 458 135 276 minecraft:gray_concrete
fill 458 135 316 461 135 316 minecraft:gray_concrete
fill 464 135 277 464 135 280 minecraft:gray_concrete
fill 464 135 287 464 135 290 minecraft:gray_concrete
fill 464 135 297 464 135 300 minecraft:gray_concrete
fill 464 135 307 464 135 310 minecraft:gray_concrete
fill 424 136 298 425 137 298 minecraft:magenta_concrete
fill 424 136 300 424 143 303 minecraft:magenta_concrete
fill 424 136 308 425 137 308 minecraft:magenta_concrete
setblock 426 136 278 minecraft:light[level=12]
setblock 426 136 285 minecraft:light[level=12]
setblock 426 136 292 minecraft:light[level=12]
fill 426 136 297 430 145 297 minecraft:magenta_concrete
fill 426 136 309 430 145 309 minecraft:magenta_concrete
setblock 426 136 313 minecraft:light[level=12]
fill 431 136 298 432 145 298 minecraft:magenta_concrete
fill 431 136 308 432 145 308 minecraft:magenta_concrete
setblock 433 136 278 minecraft:light[level=12]
setblock 433 136 285 minecraft:light[level=12]
setblock 433 136 292 minecraft:light[level=12]
fill 433 136 299 433 145 300 minecraft:magenta_concrete
fill 433 136 306 433 145 307 minecraft:magenta_concrete
setblock 433 136 313 minecraft:light[level=12]
fill 434 136 301 434 145 305 minecraft:magenta_concrete
setblock 440 136 278 minecraft:light[level=12]
setblock 440 136 285 minecraft:light[level=12]
setblock 440 136 292 minecraft:light[level=12]
setblock 440 136 299 minecraft:light[level=12]
setblock 440 136 306 minecraft:light[level=12]
setblock 440 136 313 minecraft:light[level=12]
setblock 447 136 278 minecraft:light[level=12]
setblock 447 136 285 minecraft:light[level=12]
setblock 447 136 292 minecraft:light[level=12]
setblock 447 136 299 minecraft:light[level=12]
setblock 447 136 306 minecraft:light[level=12]
setblock 447 136 313 minecraft:light[level=12]
setblock 454 136 278 minecraft:light[level=12]
setblock 454 136 285 minecraft:light[level=12]
setblock 454 136 292 minecraft:light[level=12]
setblock 454 136 299 minecraft:light[level=12]
setblock 454 136 306 minecraft:light[level=12]
setblock 454 136 313 minecraft:light[level=12]
setblock 461 136 278 minecraft:light[level=12]
setblock 461 136 285 minecraft:light[level=12]
setblock 461 136 292 minecraft:light[level=12]
setblock 461 136 299 minecraft:light[level=12]
setblock 461 136 306 minecraft:light[level=12]
setblock 461 136 313 minecraft:light[level=12]
fill 425 137 297 425 144 297 minecraft:magenta_concrete
fill 425 137 309 425 144 309 minecraft:magenta_concrete
fill 427 137 296 429 144 296 minecraft:magenta_concrete
fill 427 137 310 429 144 310 minecraft:magenta_concrete
fill 431 137 297 431 144 297 minecraft:magenta_concrete
fill 431 137 309 431 144 309 minecraft:magenta_concrete
fill 433 137 298 433 144 298 minecraft:magenta_concrete
fill 433 137 308 433 144 308 minecraft:magenta_concrete
fill 434 137 300 434 144 300 minecraft:magenta_concrete
fill 434 137 306 434 144 306 minecraft:magenta_concrete
fill 435 137 302 435 144 304 minecraft:magenta_concrete
setblock 424 138 278 minecraft:gray_concrete
setblock 424 138 288 minecraft:gray_concrete
setblock 424 138 298 minecraft:gray_concrete
setblock 424 138 308 minecraft:gray_concrete
fill 424 138 309 424 143 309 minecraft:magenta_concrete
fill 425 138 298 425 145 298 minecraft:magenta_concrete
fill 425 138 308 425 145 308 minecraft:magenta_concrete
fill 426 138 296 426 143 296 minecraft:magenta_concrete
fill 426 138 310 426 143 310 minecraft:magenta_concrete
setblock 426 138 316 minecraft:gray_concrete
setblock 430 138 276 minecraft:gray_concrete
fill 430 138 296 430 143 296 minecraft:magenta_concrete
fill 430 138 310 430 143 310 minecraft:magenta_concrete
fill 432 138 297 432 143 297 minecraft:magenta_concrete
fill 432 138 309 432 143 309 minecraft:magenta_concrete
fill 434 138 299 434 143 299 minecraft:magenta_concrete
fill 434 138 307 434 143 307 minecraft:magenta_concrete
fill 435 138 301 435 143 301 minecraft:magenta_concrete
fill 435 138 305 435 143 305 minecraft:magenta_concrete
setblock 436 138 316 minecraft:gray_concrete
setblock 440 138 276 minecraft:gray_concrete
setblock 446 138 316 minecraft:gray_concrete
setblock 450 138 276 minecraft:gray_concrete
setblock 456 138 316 minecraft:gray_concrete
setblock 460 138 276 minecraft:gray_concrete
setblock 464 138 282 minecraft:gray_concrete
setblock 464 138 292 minecraft:gray_concrete
setblock 464 138 302 minecraft:gray_concrete
setblock 464 138 312 minecraft:gray_concrete
fill 423 139 281 423 139 284 minecraft:sea_lantern
fill 423 139 291 423 139 294 minecraft:sea_lantern
fill 423 139 301 423 139 304 minecraft:sea_lantern
fill 423 139 311 423 139 314 minecraft:sea_lantern
fill 424 139 298 424 143 298 minecraft:magenta_concrete
fill 424 139 308 424 143 308 minecraft:magenta_concrete
fill 425 139 296 425 142 296 minecraft:magenta_concrete
fill 425 139 310 425 142 310 minecraft:magenta_concrete
fill 426 139 275 429 139 275 minecraft:sea_lantern
fill 427 139 317 430 139 317 minecraft:sea_lantern
fill 431 139 296 431 142 296 minecraft:magenta_concrete
fill 431 139 310 431 142 310 minecraft:magenta_concrete
fill 433 139 297 433 142 297 minecraft:magenta_concrete
fill 433 139 309 433 142 309 minecraft:magenta_concrete
fill 434 139 298 434 142 298 minecraft:magenta_concrete
fill 434 139 308 434 142 308 minecraft:magenta_concrete
fill 435 139 300 435 142 300 minecraft:magenta_concrete
fill 435 139 306 435 142 306 minecraft:magenta_concrete
fill 436 139 275 439 139 275 minecraft:sea_lantern
fill 437 139 317 440 139 317 minecraft:sea_lantern
fill 446 139 275 449 139 275 minecraft:sea_lantern
fill 447 139 317 450 139 317 minecraft:sea_lantern
fill 456 139 275 459 139 275 minecraft:sea_lantern
fill 457 139 317 460 139 317 minecraft:sea_lantern
fill 465 139 276 465 139 279 minecraft:sea_lantern
fill 465 139 286 465 139 289 minecraft:sea_lantern
fill 465 139 296 465 139 299 minecraft:sea_lantern
fill 465 139 306 465 139 309 minecraft:sea_lantern
setblock 465 139 316 minecraft:sea_lantern
fill 423 140 281 423 147 284 minecraft:black_concrete
fill 423 140 291 423 147 294 minecraft:black_concrete
fill 423 140 301 423 147 304 minecraft:black_concrete
fill 423 140 311 423 147 314 minecraft:black_concrete
fill 424 140 293 432 141 293 minecraft:sea_lantern
fill 424 140 313 432 141 313 minecraft:sea_lantern
fill 426 140 275 429 147 275 minecraft:black_concrete
setblock 426 140 278 minecraft:light[level=15]
setblock 426 140 286 minecraft:light[level=15]
setblock 426 140 294 minecraft:light[level=15]
fill 427 140 292 429 141 292 minecraft:sea_lantern
fill 427 140 314 429 141 314 minecraft:sea_lantern
fill 427 140 317 430 147 317 minecraft:black_concrete
fill 433 140 294 434 141 294 minecraft:sea_lantern
fill 433 140 312 434 141 312 minecraft:sea_lantern
setblock 434 140 278 minecraft:light[level=15]
setblock 434 140 286 minecraft:light[level=15]
fill 434 140 295 435 141 295 minecraft:sea_lantern
setblock 434 140 310 minecraft:light[level=15]
fill 434 140 311 435 141 311 minecraft:sea_lantern
fill 435 140 296 436 141 296 minecraft:sea_lantern
fill 435 140 310 436 141 310 minecraft:sea_lantern
fill 436 140 275 439 147 275 minecraft:black_concrete
fill 436 140 297 437 141 297 minecraft:sea_lantern
fill 436 140 309 437 141 309 minecraft:sea_lantern
fill 437 140 298 437 141 298 minecraft:sea_lantern
fill 437 140 308 437 141 308 minecraft:sea_lantern
fill 437 140 317 440 147 317 minecraft:black_concrete
fill 438 140 299 438 141 307 minecraft:sea_lantern
fill 439 140 302 439 141 304 minecraft:sea_lantern
setblock 442 140 278 minecraft:light[level=15]
setblock 442 140 286 minecraft:light[level=15]
setblock 442 140 294 minecraft:light[level=15]
setblock 442 140 302 minecraft:light[level=15]
setblock 442 140 310 minecraft:light[level=15]
fill 446 140 275 449 147 275 minecraft:black_concrete
fill 447 140 317 450 147 317 minecraft:black_concrete
setblock 450 140 278 minecraft:light[level=15]
setblock 450 140 286 minecraft:light[level=15]
setblock 450 140 294 minecraft:light[level=15]
setblock 450 140 302 minecraft:light[level=15]
setblock 450 140 310 minecraft:light[level=15]
fill 456 140 275 459 147 275 minecraft:black_concrete
fill 457 140 317 460 147 317 minecraft:black_concrete
setblock 458 140 278 minecraft:light[level=15]
setblock 458 140 286 minecraft:light[level=15]
setblock 458 140 294 minecraft:light[level=15]
setblock 458 140 302 minecraft:light[level=15]
setblock 458 140 310 minecraft:light[level=15]
fill 465 140 276 465 147 279 minecraft:black_concrete
fill 465 140 286 465 147 289 minecraft:black_concrete
fill 465 140 296 465 147 299 minecraft:black_concrete
fill 465 140 306 465 147 309 minecraft:black_concrete
fill 465 140 316 465 147 316 minecraft:black_concrete
setblock 426 142 278 minecraft:light[level=12]
setblock 426 142 285 minecraft:light[level=12]
setblock 426 142 292 minecraft:light[level=12]
setblock 426 142 313 minecraft:light[level=12]
setblock 433 142 278 minecraft:light[level=12]
setblock 433 142 285 minecraft:light[level=12]
setblock 433 142 292 minecraft:light[level=12]
setblock 433 142 313 minecraft:light[level=12]
setblock 440 142 278 minecraft:light[level=12]
setblock 440 142 285 minecraft:light[level=12]
setblock 440 142 292 minecraft:light[level=12]
setblock 440 142 299 minecraft:light[level=12]
setblock 440 142 306 minecraft:light[level=12]
setblock 440 142 313 minecraft:light[level=12]
setblock 447 142 278 minecraft:light[level=12]
setblock 447 142 285 minecraft:light[level=12]
setblock 447 142 292 minecraft:light[level=12]
setblock 447 142 299 minecraft:light[level=12]
setblock 447 142 306 minecraft:light[level=12]
setblock 447 142 313 minecraft:light[level=12]
setblock 454 142 278 minecraft:light[level=12]
setblock 454 142 285 minecraft:light[level=12]
setblock 454 142 292 minecraft:light[level=12]
setblock 454 142 299 minecraft:light[level=12]
setblock 454 142 306 minecraft:light[level=12]
setblock 454 142 313 minecraft:light[level=12]
fill 457 142 303 463 143 303 minecraft:gray_concrete
setblock 461 142 278 minecraft:light[level=12]
setblock 461 142 285 minecraft:light[level=12]
setblock 461 142 292 minecraft:light[level=12]
setblock 461 142 299 minecraft:light[level=12]
setblock 461 142 306 minecraft:light[level=12]
setblock 461 142 313 minecraft:light[level=12]
fill 462 142 302 464 143 302 minecraft:gray_concrete
fill 445 143 304 456 143 304 minecraft:gray_concrete
fill 446 143 303 456 144 303 minecraft:gray_concrete
fill 457 143 302 461 143 302 minecraft:gray_concrete
setblock 424 144 278 minecraft:gray_concrete
fill 424 144 280 424 144 283 minecraft:gray_concrete
setblock 424 144 288 minecraft:gray_concrete
fill 424 144 290 424 144 293 minecraft:gray_concrete
setblock 424 144 298 minecraft:gray_concrete
fill 424 144 300 424 144 303 minecraft:gray_concrete
setblock 424 144 308 minecraft:gray_concrete
fill 424 144 310 424 144 313 minecraft:gray_concrete
fill 425 144 276 428 144 276 minecraft:gray_concrete
setblock 426 144 316 minecraft:gray_concrete
fill 428 144 316 431 144 316 minecraft:gray_concrete
setblock 430 144 276 minecraft:gray_concrete
fill 435 144 276 438 144 276 minecraft:gray_concrete
fill 435 144 289 436 145 290 minecraft:light_blue_concrete
fill 436 144 304 452 144 304 minecraft:gray_concrete
setblock 436 144 316 minecraft:gray_concrete
fill 437 144 290 437 145 290 minecraft:light_blue_concrete
fill 437 144 309 437 145 309 minecraft:lime_concrete
fill 438 144 316 441 144 316 minecraft:gray_concrete
fill 439 144 303 445 144 303 minecraft:gray_concrete
setblock 440 144 276 minecraft:gray_concrete
fill 445 144 276 448 144 276 minecraft:gray_concrete
setblock 446 144 316 minecraft:gray_concrete
fill 448 144 316 451 144 316 minecraft:gray_concrete
setblock 450 144 276 minecraft:gray_concrete
fill 455 144 276 458 144 276 minecraft:gray_concrete
setblock 456 144 316 minecraft:gray_concrete
fill 457 144 303 463 144 303 minecraft:magenta_concrete
fill 458 144 316 461 144 316 minecraft:gray_concrete
setblock 460 144 276 minecraft:gray_concrete
fill 464 144 277 464 144 280 minecraft:gray_concrete
setblock 464 144 282 minecraft:gray_concrete
fill 464 144 287 464 144 290 minecraft:gray_concrete
setblock 464 144 292 minecraft:gray_concrete
fill 464 144 297 464 144 300 minecraft:gray_concrete
setblock 464 144 302 minecraft:gray_concrete
fill 464 144 307 464 144 310 minecraft:gray_concrete
setblock 464 144 312 minecraft:gray_concrete
setblock 424 145 298 minecraft:magenta_concrete
fill 424 145 300 424 146 303 minecraft:magenta_concrete
setblock 424 145 308 minecraft:magenta_concrete
fill 435 145 304 435 145 305 minecraft:gray_concrete
fill 436 145 304 442 145 304 minecraft:gray_concrete
fill 443 145 304 447 145 304 minecraft:magenta_concrete
fill 447 145 303 456 145 303 minecraft:magenta_concrete
fill 434 146 304 442 146 304 minecraft:magenta_concrete
fill 424 147 301 424 147 305 minecraft:magenta_concrete
fill 423 148 281 423 148 284 minecraft:sea_lantern
fill 423 148 291 423 148 294 minecraft:sea_lantern
fill 423 148 301 423 148 304 minecraft:sea_lantern
fill 423 148 311 423 148 314 minecraft:sea_lantern
fill 426 148 275 429 148 275 minecraft:sea_lantern
setblock 426 148 278 minecraft:light[level=15]
setblock 426 148 285 minecraft:light[level=12]
setblock 426 148 286 minecraft:light[level=15]
setblock 426 148 292 minecraft:light[level=12]
setblock 426 148 294 minecraft:light[level=15]
setblock 426 148 299 minecraft:light[level=12]
setblock 426 148 306 minecraft:light[level=12]
setblock 426 148 310 minecraft:light[level=15]
setblock 426 148 313 minecraft:light[level=12]
fill 427 148 317 430 148 317 minecraft:sea_lantern
setblock 433 148 278 minecraft:light[level=12]
setblock 433 148 285 minecraft:light[level=12]
setblock 433 148 292 minecraft:light[level=12]
setblock 433 148 299 minecraft:light[level=12]
setblock 433 148 306 minecraft:light[level=12]
setblock 433 148 313 minecraft:light[level=12]
setblock 434 148 278 minecraft:light[level=15]
setblock 434 148 286 minecraft:light[level=15]
setblock 434 148 294 minecraft:light[level=15]
setblock 434 148 302 minecraft:light[level=15]
setblock 434 148 310 minecraft:light[level=15]
fill 436 148 275 439 148 275 minecraft:sea_lantern
fill 437 148 317 440 148 317 minecraft:sea_lantern
setblock 440 148 278 minecraft:light[level=12]
setblock 440 148 285 minecraft:light[level=12]
setblock 440 148 292 minecraft:light[level=12]
setblock 440 148 299 minecraft:light[level=12]
setblock 440 148 306 minecraft:light[level=12]
setblock 440 148 313 minecraft:light[level=12]
setblock 442 148 278 minecraft:light[level=15]
setblock 442 148 286 minecraft:light[level=15]
setblock 442 148 294 minecraft:light[level=15]
setblock 442 148 302 minecraft:light[level=15]
setblock 442 148 310 minecraft:light[level=15]
fill 446 148 275 449 148 275 minecraft:sea_lantern
setblock 447 148 278 minecraft:light[level=12]
setblock 447 148 285 minecraft:light[level=12]
setblock 447 148 292 minecraft:light[level=12]
setblock 447 148 299 minecraft:light[level=12]
setblock 447 148 306 minecraft:light[level=12]
setblock 447 148 313 minecraft:light[level=12]
fill 447 148 317 450 148 317 minecraft:sea_lantern
setblock 450 148 278 minecraft:light[level=15]
setblock 450 148 286 minecraft:light[level=15]
setblock 450 148 294 minecraft:light[level=15]
setblock 450 148 302 minecraft:light[level=15]
setblock 450 148 310 minecraft:light[level=15]
setblock 454 148 278 minecraft:light[level=12]
setblock 454 148 285 minecraft:light[level=12]
setblock 454 148 292 minecraft:light[level=12]
setblock 454 148 299 minecraft:light[level=12]
setblock 454 148 306 minecraft:light[level=12]
setblock 454 148 313 minecraft:light[level=12]
fill 456 148 275 459 148 275 minecraft:sea_lantern
fill 457 148 317 460 148 317 minecraft:sea_lantern
setblock 458 148 278 minecraft:light[level=15]
setblock 458 148 286 minecraft:light[level=15]
setblock 458 148 294 minecraft:light[level=15]
setblock 458 148 302 minecraft:light[level=15]
setblock 458 148 310 minecraft:light[level=15]
setblock 461 148 278 minecraft:light[level=12]
setblock 461 148 285 minecraft:light[level=12]
setblock 461 148 292 minecraft:light[level=12]
setblock 461 148 299 minecraft:light[level=12]
setblock 461 148 306 minecraft:light[level=12]
setblock 461 148 313 minecraft:light[level=12]
fill 465 148 276 465 148 279 minecraft:sea_lantern
fill 465 148 286 465 148 289 minecraft:sea_lantern
fill 465 148 296 465 148 299 minecraft:sea_lantern
fill 465 148 306 465 148 309 minecraft:sea_lantern
setblock 465 148 316 minecraft:sea_lantern
fill 423 149 281 423 156 284 minecraft:black_concrete
fill 423 149 291 423 156 294 minecraft:black_concrete
fill 423 149 301 423 156 304 minecraft:black_concrete
fill 423 149 311 423 156 314 minecraft:black_concrete
fill 426 149 275 429 156 275 minecraft:black_concrete
fill 427 149 317 430 156 317 minecraft:black_concrete
fill 436 149 275 439 156 275 minecraft:black_concrete
fill 437 149 317 440 156 317 minecraft:black_concrete
fill 446 149 275 449 156 275 minecraft:black_concrete
fill 447 149 317 450 156 317 minecraft:black_concrete
fill 456 149 275 459 156 275 minecraft:black_concrete
fill 457 149 317 460 156 317 minecraft:black_concrete
fill 465 149 276 465 156 279 minecraft:black_concrete
fill 465 149 286 465 156 289 minecraft:black_concrete
fill 465 149 296 465 156 299 minecraft:black_concrete
fill 465 149 306 465 156 309 minecraft:black_concrete
fill 465 149 316 465 156 316 minecraft:black_concrete
setblock 424 150 278 minecraft:gray_concrete
setblock 424 150 288 minecraft:gray_concrete
setblock 424 150 298 minecraft:gray_concrete
setblock 424 150 308 minecraft:gray_concrete
setblock 426 150 316 minecraft:gray_concrete
setblock 430 150 276 minecraft:gray_concrete
setblock 436 150 316 minecraft:gray_concrete
setblock 440 150 276 minecraft:gray_concrete
setblock 446 150 316 minecraft:gray_concrete
setblock 450 150 276 minecraft:gray_concrete
setblock 456 150 316 minecraft:gray_concrete
setblock 460 150 276 minecraft:gray_concrete
setblock 464 150 282 minecraft:gray_concrete
setblock 464 150 292 minecraft:gray_concrete
setblock 464 150 302 minecraft:gray_concrete
setblock 464 150 312 minecraft:gray_concrete
fill 428 151 306 428 152 306 minecraft:yellow_concrete
fill 461 151 281 463 152 281 minecraft:iron_block
fill 424 153 280 424 153 283 minecraft:gray_concrete
fill 424 153 290 424 153 293 minecraft:gray_concrete
fill 424 153 300 424 153 303 minecraft:gray_concrete
fill 424 153 310 424 153 313 minecraft:gray_concrete
fill 425 153 276 428 153 276 minecraft:gray_concrete
fill 428 153 316 431 153 316 minecraft:gray_concrete
fill 435 153 276 438 153 276 minecraft:gray_concrete
fill 438 153 316 441 153 316 minecraft:gray_concrete
fill 445 153 276 448 153 276 minecraft:gray_concrete
fill 448 153 316 451 153 316 minecraft:gray_concrete
fill 455 153 276 458 153 276 minecraft:gray_concrete
fill 458 153 316 461 153 316 minecraft:gray_concrete
fill 464 153 277 464 153 280 minecraft:gray_concrete
fill 464 153 287 464 153 290 minecraft:gray_concrete
fill 464 153 297 464 153 300 minecraft:gray_concrete
fill 464 153 307 464 153 310 minecraft:gray_concrete
setblock 426 154 278 minecraft:light[level=12]
setblock 426 154 285 minecraft:light[level=12]
setblock 426 154 292 minecraft:light[level=12]
setblock 426 154 299 minecraft:light[level=12]
setblock 426 154 306 minecraft:light[level=12]
setblock 426 154 313 minecraft:light[level=12]
setblock 433 154 278 minecraft:light[level=12]
setblock 433 154 285 minecraft:light[level=12]
setblock 433 154 292 minecraft:light[level=12]
setblock 433 154 299 minecraft:light[level=12]
setblock 433 154 306 minecraft:light[level=12]
setblock 433 154 313 minecraft:light[level=12]
setblock 440 154 278 minecraft:light[level=12]
setblock 440 154 285 minecraft:light[level=12]
setblock 440 154 292 minecraft:light[level=12]
setblock 440 154 299 minecraft:light[level=12]
setblock 440 154 306 minecraft:light[level=12]
setblock 440 154 313 minecraft:light[level=12]
setblock 447 154 278 minecraft:light[level=12]
setblock 447 154 285 minecraft:light[level=12]
setblock 447 154 292 minecraft:light[level=12]
setblock 447 154 299 minecraft:light[level=12]
setblock 447 154 306 minecraft:light[level=12]
setblock 447 154 313 minecraft:light[level=12]
setblock 454 154 278 minecraft:light[level=12]
setblock 454 154 285 minecraft:light[level=12]
setblock 454 154 292 minecraft:light[level=12]
setblock 454 154 299 minecraft:light[level=12]
setblock 454 154 306 minecraft:light[level=12]
setblock 454 154 313 minecraft:light[level=12]
setblock 461 154 278 minecraft:light[level=12]
setblock 461 154 285 minecraft:light[level=12]
setblock 461 154 292 minecraft:light[level=12]
setblock 461 154 299 minecraft:light[level=12]
setblock 461 154 306 minecraft:light[level=12]
setblock 461 154 313 minecraft:light[level=12]
fill 431 155 301 433 156 301 minecraft:light_blue_concrete
fill 432 155 300 432 156 300 minecraft:light_blue_concrete
fill 432 155 302 432 156 302 minecraft:light_blue_concrete
setblock 424 156 278 minecraft:gray_concrete
setblock 424 156 288 minecraft:gray_concrete
setblock 424 156 298 minecraft:gray_concrete
setblock 424 156 308 minecraft:gray_concrete
setblock 426 156 278 minecraft:light[level=15]
setblock 426 156 286 minecraft:light[level=15]
setblock 426 156 294 minecraft:light[level=15]
setblock 426 156 302 minecraft:light[level=15]
setblock 426 156 310 minecraft:light[level=15]
setblock 426 156 316 minecraft:gray_concrete
setblock 430 156 276 minecraft:gray_concrete
setblock 434 156 278 minecraft:light[level=15]
setblock 434 156 286 minecraft:light[level=15]
setblock 434 156 294 minecraft:light[level=15]
setblock 434 156 302 minecraft:light[level=15]
setblock 434 156 310 minecraft:light[level=15]
setblock 436 156 316 minecraft:gray_concrete
setblock 440 156 276 minecraft:gray_concrete
setblock 442 156 278 minecraft:light[level=15]
setblock 442 156 286 minecraft:light[level=15]
setblock 442 156 294 minecraft:light[level=15]
setblock 442 156 302 minecraft:light[level=15]
setblock 442 156 310 minecraft:light[level=15]
setblock 446 156 316 minecraft:gray_concrete
setblock 450 156 276 minecraft:gray_concrete
setblock 450 156 278 minecraft:light[level=15]
setblock 450 156 286 minecraft:light[level=15]
setblock 450 156 294 minecraft:light[level=15]
setblock 450 156 302 minecraft:light[level=15]
setblock 450 156 310 minecraft:light[level=15]
setblock 456 156 316 minecraft:gray_concrete
setblock 458 156 278 minecraft:light[level=15]
setblock 458 156 286 minecraft:light[level=15]
setblock 458 156 294 minecraft:light[level=15]
setblock 458 156 302 minecraft:light[level=15]
setblock 458 156 310 minecraft:light[level=15]
setblock 460 156 276 minecraft:gray_concrete
setblock 464 156 282 minecraft:gray_concrete
setblock 464 156 292 minecraft:gray_concrete
setblock 464 156 302 minecraft:gray_concrete
setblock 464 156 312 minecraft:gray_concrete
fill 423 157 281 423 157 284 minecraft:sea_lantern
fill 423 157 291 423 157 294 minecraft:sea_lantern
fill 423 157 301 423 157 304 minecraft:sea_lantern
fill 423 157 311 423 157 314 minecraft:sea_lantern
fill 426 157 275 429 157 275 minecraft:sea_lantern
fill 427 157 317 430 157 317 minecraft:sea_lantern
fill 436 157 275 439 157 275 minecraft:sea_lantern
fill 437 157 317 440 157 317 minecraft:sea_lantern
fill 446 157 275 449 157 275 minecraft:sea_lantern
fill 447 157 317 450 157 317 minecraft:sea_lantern
fill 456 157 275 459 157 275 minecraft:sea_lantern
fill 457 157 317 460 157 317 minecraft:sea_lantern
fill 462 157 294 462 165 294 minecraft:purple_wool
fill 465 157 276 465 157 279 minecraft:sea_lantern
fill 465 157 286 465 157 289 minecraft:sea_lantern
fill 465 157 296 465 157 299 minecraft:sea_lantern
fill 465 157 306 465 157 309 minecraft:sea_lantern
setblock 465 157 316 minecraft:sea_lantern
fill 423 158 281 423 165 284 minecraft:black_concrete
fill 423 158 291 423 165 294 minecraft:black_concrete
fill 423 158 301 423 165 304 minecraft:black_concrete
fill 423 158 311 423 165 314 minecraft:black_concrete
fill 426 158 275 429 165 275 minecraft:black_concrete
fill 427 158 317 430 165 317 minecraft:black_concrete
fill 436 158 275 439 165 275 minecraft:black_concrete
fill 437 158 317 440 165 317 minecraft:black_concrete
fill 446 158 275 449 165 275 minecraft:black_concrete
fill 447 158 317 450 165 317 minecraft:black_concrete
fill 456 158 275 459 165 275 minecraft:black_concrete
fill 457 158 317 460 165 317 minecraft:black_concrete
fill 462 158 292 462 165 293 minecraft:purple_wool
fill 462 158 295 462 165 296 minecraft:purple_wool
fill 465 158 276 465 165 279 minecraft:black_concrete
fill 465 158 286 465 165 289 minecraft:black_concrete
fill 465 158 296 465 165 299 minecraft:black_concrete
fill 465 158 306 465 165 309 minecraft:black_concrete
fill 465 158 316 465 165 316 minecraft:black_concrete
setblock 426 160 278 minecraft:light[level=12]
setblock 426 160 285 minecraft:light[level=12]
setblock 426 160 292 minecraft:light[level=12]
setblock 426 160 299 minecraft:light[level=12]
setblock 426 160 306 minecraft:light[level=12]
setblock 426 160 313 minecraft:light[level=12]
setblock 433 160 278 minecraft:light[level=12]
setblock 433 160 285 minecraft:light[level=12]
setblock 433 160 292 minecraft:light[level=12]
setblock 433 160 299 minecraft:light[level=12]
setblock 433 160 306 minecraft:light[level=12]
setblock 433 160 313 minecraft:light[level=12]
setblock 440 160 278 minecraft:light[level=12]
setblock 440 160 285 minecraft:light[level=12]
setblock 440 160 292 minecraft:light[level=12]
setblock 440 160 299 minecraft:light[level=12]
setblock 440 160 306 minecraft:light[level=12]
setblock 440 160 313 minecraft:light[level=12]
setblock 447 160 278 minecraft:light[level=12]
setblock 447 160 285 minecraft:light[level=12]
setblock 447 160 292 minecraft:light[level=12]
setblock 447 160 299 minecraft:light[level=12]
setblock 447 160 306 minecraft:light[level=12]
setblock 447 160 313 minecraft:light[level=12]
setblock 454 160 278 minecraft:light[level=12]
setblock 454 160 285 minecraft:light[level=12]
setblock 454 160 292 minecraft:light[level=12]
setblock 454 160 299 minecraft:light[level=12]
setblock 454 160 306 minecraft:light[level=12]
setblock 454 160 313 minecraft:light[level=12]
setblock 461 160 278 minecraft:light[level=12]
setblock 461 160 285 minecraft:light[level=12]
setblock 461 160 292 minecraft:light[level=12]
setblock 461 160 299 minecraft:light[level=12]
setblock 461 160 306 minecraft:light[level=12]
setblock 461 160 313 minecraft:light[level=12]
setblock 424 162 278 minecraft:gray_concrete
fill 424 162 280 424 162 283 minecraft:gray_concrete
setblock 424 162 288 minecraft:gray_concrete
fill 424 162 290 424 162 293 minecraft:gray_concrete
setblock 424 162 298 minecraft:gray_concrete
fill 424 162 300 424 162 303 minecraft:gray_concrete
setblock 424 162 308 minecraft:gray_concrete
fill 424 162 310 424 162 313 minecraft:gray_concrete
fill 425 162 276 428 162 276 minecraft:gray_concrete
setblock 426 162 316 minecraft:gray_concrete
fill 428 162 316 431 162 316 minecraft:gray_concrete
setblock 430 162 276 minecraft:gray_concrete
fill 435 162 276 438 162 276 minecraft:gray_concrete
setblock 436 162 316 minecraft:gray_concrete
fill 438 162 316 441 162 316 minecraft:gray_concrete
setblock 440 162 276 minecraft:gray_concrete
fill 445 162 276 448 162 276 minecraft:gray_concrete
setblock 446 162 316 minecraft:gray_concrete
fill 448 162 316 451 162 316 minecraft:gray_concrete
setblock 450 162 276 minecraft:gray_concrete
fill 455 162 276 458 162 276 minecraft:gray_concrete
setblock 456 162 316 minecraft:gray_concrete
fill 458 162 316 461 162 316 minecraft:gray_concrete
setblock 460 162 276 minecraft:gray_concrete
fill 464 162 277 464 162 280 minecraft:gray_concrete
setblock 464 162 282 minecraft:gray_concrete
fill 464 162 287 464 162 290 minecraft:gray_concrete
setblock 464 162 292 minecraft:gray_concrete
fill 464 162 297 464 162 300 minecraft:gray_concrete
setblock 464 162 302 minecraft:gray_concrete
fill 464 162 307 464 162 310 minecraft:gray_concrete
setblock 464 162 312 minecraft:gray_concrete
fill 452 163 277 454 163 279 minecraft:black_concrete
setblock 426 164 278 minecraft:light[level=15]
setblock 426 164 286 minecraft:light[level=15]
setblock 426 164 294 minecraft:light[level=15]
setblock 426 164 302 minecraft:light[level=15]
setblock 426 164 310 minecraft:light[level=15]
setblock 434 164 278 minecraft:light[level=15]
setblock 434 164 286 minecraft:light[level=15]
setblock 434 164 294 minecraft:light[level=15]
setblock 434 164 302 minecraft:light[level=15]
setblock 434 164 310 minecraft:light[level=15]
setblock 442 164 278 minecraft:light[level=15]
setblock 442 164 286 minecraft:light[level=15]
setblock 442 164 294 minecraft:light[level=15]
setblock 442 164 302 minecraft:light[level=15]
setblock 442 164 310 minecraft:light[level=15]
fill 446 164 307 448 165 307 minecraft:magenta_concrete
fill 447 164 306 447 165 306 minecraft:magenta_concrete
fill 447 164 308 447 165 308 minecraft:magenta_concrete
setblock 450 164 278 minecraft:light[level=15]
setblock 450 164 286 minecraft:light[level=15]
setblock 450 164 294 minecraft:light[level=15]
setblock 450 164 302 minecraft:light[level=15]
setblock 450 164 310 minecraft:light[level=15]
fill 452 164 277 452 164 279 minecraft:black_concrete
fill 453 164 277 454 164 277 minecraft:black_concrete
fill 453 164 278 453 166 278 minecraft:gray_concrete
fill 453 164 279 454 164 279 minecraft:black_concrete
setblock 454 164 278 minecraft:black_concrete
setblock 458 164 278 minecraft:light[level=15]
setblock 458 164 286 minecraft:light[level=15]
setblock 458 164 294 minecraft:light[level=15]
setblock 458 164 302 minecraft:light[level=15]
setblock 458 164 310 minecraft:light[level=15]
fill 452 165 277 452 167 277 minecraft:black_concrete
setblock 452 165 278 minecraft:gray_concrete
fill 452 165 279 452 167 279 minecraft:black_concrete
setblock 453 165 277 minecraft:gray_concrete
setblock 453 165 279 minecraft:gray_concrete
fill 454 165 277 454 167 277 minecraft:black_concrete
setblock 454 165 278 minecraft:gray_concrete
fill 454 165 279 454 167 279 minecraft:black_concrete
fill 423 166 281 423 166 284 minecraft:sea_lantern
fill 423 166 291 423 166 294 minecraft:sea_lantern
fill 423 166 301 423 166 304 minecraft:sea_lantern
fill 423 166 311 423 166 314 minecraft:sea_lantern
fill 426 166 275 429 166 275 minecraft:sea_lantern
setblock 426 166 278 minecraft:light[level=12]
setblock 426 166 285 minecraft:light[level=12]
setblock 426 166 292 minecraft:light[level=12]
setblock 426 166 299 minecraft:light[level=12]
setblock 426 166 306 minecraft:light[level=12]
setblock 426 166 313 minecraft:light[level=12]
fill 427 166 317 430 166 317 minecraft:sea_lantern
setblock 433 166 278 minecraft:light[level=12]
setblock 433 166 285 minecraft:light[level=12]
setblock 433 166 292 minecraft:light[level=12]
setblock 433 166 299 minecraft:light[level=12]
setblock 433 166 306 minecraft:light[level=12]
setblock 433 166 313 minecraft:light[level=12]
fill 436 166 275 439 166 275 minecraft:sea_lantern
fill 437 166 317 440 166 317 minecraft:sea_lantern
setblock 440 166 278 minecraft:light[level=12]
setblock 440 166 285 minecraft:light[level=12]
setblock 440 166 292 minecraft:light[level=12]
setblock 440 166 299 minecraft:light[level=12]
setblock 440 166 306 minecraft:light[level=12]
setblock 440 166 313 minecraft:light[level=12]
fill 446 166 275 449 166 275 minecraft:sea_lantern
setblock 447 166 278 minecraft:light[level=12]
setblock 447 166 285 minecraft:light[level=12]
setblock 447 166 292 minecraft:light[level=12]
setblock 447 166 299 minecraft:light[level=12]
setblock 447 166 306 minecraft:light[level=12]
setblock 447 166 313 minecraft:light[level=12]
fill 447 166 317 450 166 317 minecraft:sea_lantern
fill 452 166 278 452 167 278 minecraft:black_concrete
fill 453 166 277 453 167 277 minecraft:black_concrete
fill 453 166 279 453 167 279 minecraft:black_concrete
fill 454 166 278 454 167 278 minecraft:black_concrete
setblock 454 166 285 minecraft:light[level=12]
setblock 454 166 292 minecraft:light[level=12]
setblock 454 166 299 minecraft:light[level=12]
setblock 454 166 306 minecraft:light[level=12]
setblock 454 166 313 minecraft:light[level=12]
fill 456 166 275 459 166 275 minecraft:sea_lantern
fill 457 166 317 460 166 317 minecraft:sea_lantern
setblock 461 166 278 minecraft:light[level=12]
setblock 461 166 285 minecraft:light[level=12]
setblock 461 166 292 minecraft:light[level=12]
setblock 461 166 299 minecraft:light[level=12]
setblock 461 166 306 minecraft:light[level=12]
setblock 461 166 313 minecraft:light[level=12]
fill 462 166 291 462 167 297 minecraft:iron_block
fill 465 166 276 465 166 279 minecraft:sea_lantern
fill 465 166 286 465 166 289 minecraft:sea_lantern
fill 465 166 296 465 166 299 minecraft:sea_lantern
fill 465 166 306 465 166 309 minecraft:sea_lantern
setblock 465 166 316 minecraft:sea_lantern
fill 423 167 281 423 174 284 minecraft:black_concrete
fill 423 167 291 423 174 294 minecraft:black_concrete
fill 423 167 301 423 174 304 minecraft:black_concrete
fill 423 167 311 423 174 314 minecraft:black_concrete
fill 426 167 275 429 174 275 minecraft:black_concrete
fill 427 167 317 430 174 317 minecraft:black_concrete
fill 436 167 275 439 174 275 minecraft:black_concrete
fill 437 167 317 440 174 317 minecraft:black_concrete
fill 446 167 275 449 174 275 minecraft:black_concrete
fill 447 167 317 450 174 317 minecraft:black_concrete
setblock 453 167 278 minecraft:black_concrete
fill 456 167 275 459 174 275 minecraft:black_concrete
fill 457 167 317 460 174 317 minecraft:black_concrete
fill 465 167 276 465 174 279 minecraft:black_concrete
fill 465 167 286 465 174 289 minecraft:black_concrete
fill 465 167 296 465 174 299 minecraft:black_concrete
fill 465 167 306 465 174 309 minecraft:black_concrete
fill 465 167 316 465 174 316 minecraft:black_concrete
setblock 424 168 278 minecraft:gray_concrete
setblock 424 168 288 minecraft:gray_concrete
setblock 424 168 298 minecraft:gray_concrete
setblock 424 168 308 minecraft:gray_concrete
setblock 426 168 316 minecraft:gray_concrete
setblock 430 168 276 minecraft:gray_concrete
setblock 436 168 316 minecraft:gray_concrete
setblock 440 168 276 minecraft:gray_concrete
setblock 446 168 316 minecraft:gray_concrete
setblock 450 168 276 minecraft:gray_concrete
setblock 456 168 316 minecraft:gray_concrete
setblock 460 168 276 minecraft:gray_concrete
setblock 464 168 282 minecraft:gray_concrete
setblock 464 168 292 minecraft:gray_concrete
setblock 464 168 302 minecraft:gray_concrete
setblock 464 168 312 minecraft:gray_concrete
fill 445 170 307 446 171 308 minecraft:magenta_concrete
fill 424 171 280 424 171 283 minecraft:gray_concrete
fill 424 171 290 424 171 293 minecraft:gray_concrete
fill 424 171 300 424 171 303 minecraft:gray_concrete
fill 424 171 310 424 171 313 minecraft:gray_concrete
fill 425 171 276 428 171 276 minecraft:gray_concrete
fill 428 171 316 431 171 316 minecraft:gray_concrete
fill 435 171 276 438 171 276 minecraft:gray_concrete
fill 438 171 316 441 171 316 minecraft:gray_concrete
fill 445 171 276 448 171 276 minecraft:gray_concrete
fill 448 171 316 451 171 316 minecraft:gray_concrete
fill 455 171 276 458 171 276 minecraft:gray_concrete
fill 458 171 316 461 171 316 minecraft:gray_concrete
fill 464 171 277 464 171 280 minecraft:gray_concrete
fill 464 171 287 464 171 290 minecraft:gray_concrete
fill 464 171 297 464 171 300 minecraft:gray_concrete
fill 464 171 307 464 171 310 minecraft:gray_concrete
setblock 426 172 278 minecraft:light[level=15]
setblock 426 172 285 minecraft:light[level=12]
setblock 426 172 286 minecraft:light[level=15]
setblock 426 172 292 minecraft:light[level=12]
setblock 426 172 294 minecraft:light[level=15]
setblock 426 172 299 minecraft:light[level=12]
setblock 426 172 302 minecraft:light[level=15]
setblock 426 172 306 minecraft:light[level=12]
setblock 426 172 310 minecraft:light[level=15]
setblock 426 172 313 minecraft:light[level=12]
setblock 433 172 278 minecraft:light[level=12]
setblock 433 172 285 minecraft:light[level=12]
setblock 433 172 292 minecraft:light[level=12]
setblock 433 172 299 minecraft:light[level=12]
setblock 433 172 306 minecraft:light[level=12]
setblock 433 172 313 minecraft:light[level=12]
setblock 434 172 278 minecraft:light[level=15]
setblock 434 172 286 minecraft:light[level=15]
setblock 434 172 294 minecraft:light[level=15]
setblock 434 172 302 minecraft:light[level=15]
setblock 434 172 310 minecraft:light[level=15]
setblock 440 172 278 minecraft:light[level=12]
setblock 440 172 285 minecraft:light[level=12]
setblock 440 172 292 minecraft:light[level=12]
setblock 440 172 299 minecraft:light[level=12]
setblock 440 172 306 minecraft:light[level=12]
setblock 440 172 313 minecraft:light[level=12]
setblock 442 172 278 minecraft:light[level=15]
setblock 442 172 286 minecraft:light[level=15]
setblock 442 172 294 minecraft:light[level=15]
setblock 442 172 302 minecraft:light[level=15]
setblock 442 172 310 minecraft:light[level=15]
setblock 447 172 278 minecraft:light[level=12]
setblock 447 172 285 minecraft:light[level=12]
setblock 447 172 292 minecraft:light[level=12]
setblock 447 172 299 minecraft:light[level=12]
setblock 447 172 306 minecraft:light[level=12]
setblock 447 172 313 minecraft:light[level=12]
setblock 450 172 278 minecraft:light[level=15]
setblock 450 172 286 minecraft:light[level=15]
setblock 450 172 294 minecraft:light[level=15]
setblock 450 172 302 minecraft:light[level=15]
setblock 450 172 310 minecraft:light[level=15]
setblock 454 172 278 minecraft:light[level=12]
setblock 454 172 285 minecraft:light[level=12]
setblock 454 172 292 minecraft:light[level=12]
setblock 454 172 299 minecraft:light[level=12]
setblock 454 172 306 minecraft:light[level=12]
setblock 454 172 313 minecraft:light[level=12]
setblock 458 172 278 minecraft:light[level=15]
setblock 458 172 286 minecraft:light[level=15]
setblock 458 172 294 minecraft:light[level=15]
setblock 458 172 302 minecraft:light[level=15]
setblock 458 172 310 minecraft:light[level=15]
setblock 461 172 278 minecraft:light[level=12]
setblock 461 172 285 minecraft:light[level=12]
setblock 461 172 292 minecraft:light[level=12]
setblock 461 172 299 minecraft:light[level=12]
setblock 461 172 306 minecraft:light[level=12]
setblock 461 172 313 minecraft:light[level=12]
setblock 424 174 278 minecraft:gray_concrete
setblock 424 174 288 minecraft:gray_concrete
setblock 424 174 298 minecraft:gray_concrete
setblock 424 174 308 minecraft:gray_concrete
setblock 426 174 316 minecraft:gray_concrete
setblock 430 174 276 minecraft:gray_concrete
setblock 436 174 316 minecraft:gray_concrete
setblock 440 174 276 minecraft:gray_concrete
setblock 446 174 316 minecraft:gray_concrete
setblock 450 174 276 minecraft:gray_concrete
setblock 456 174 316 minecraft:gray_concrete
setblock 460 174 276 minecraft:gray_concrete
setblock 464 174 282 minecraft:gray_concrete
setblock 464 174 292 minecraft:gray_concrete
setblock 464 174 302 minecraft:gray_concrete
setblock 464 174 312 minecraft:gray_concrete
fill 423 175 281 423 175 284 minecraft:sea_lantern
fill 423 175 291 423 175 294 minecraft:sea_lantern
fill 423 175 301 423 175 304 minecraft:sea_lantern
fill 423 175 311 423 175 314 minecraft:sea_lantern
fill 426 175 275 429 175 275 minecraft:sea_lantern
fill 427 175 317 430 175 317 minecraft:sea_lantern
fill 436 175 275 439 175 275 minecraft:sea_lantern
fill 437 175 317 440 175 317 minecraft:sea_lantern
fill 446 175 275 449 175 275 minecraft:sea_lantern
fill 447 175 317 450 175 317 minecraft:sea_lantern
fill 456 175 275 459 175 275 minecraft:sea_lantern
fill 457 175 317 460 175 317 minecraft:sea_lantern
fill 465 175 276 465 175 279 minecraft:sea_lantern
fill 465 175 286 465 175 289 minecraft:sea_lantern
fill 465 175 296 465 175 299 minecraft:sea_lantern
fill 465 175 306 465 175 309 minecraft:sea_lantern
setblock 465 175 316 minecraft:sea_lantern
fill 423 176 281 423 183 284 minecraft:black_concrete
fill 423 176 291 423 183 294 minecraft:black_concrete
fill 423 176 301 423 183 304 minecraft:black_concrete
fill 423 176 311 423 183 314 minecraft:black_concrete
fill 426 176 275 429 183 275 minecraft:black_concrete
fill 427 176 317 430 183 317 minecraft:black_concrete
fill 436 176 275 439 183 275 minecraft:black_concrete
fill 437 176 317 440 183 317 minecraft:black_concrete
fill 446 176 275 449 183 275 minecraft:black_concrete
fill 447 176 317 450 183 317 minecraft:black_concrete
fill 456 176 275 459 183 275 minecraft:black_concrete
fill 457 176 317 460 183 317 minecraft:black_concrete
fill 465 176 276 465 183 279 minecraft:black_concrete
fill 465 176 286 465 183 289 minecraft:black_concrete
fill 465 176 296 465 183 299 minecraft:black_concrete
fill 465 176 306 465 183 309 minecraft:black_concrete
fill 465 176 316 465 183 316 minecraft:black_concrete
setblock 426 178 278 minecraft:light[level=12]
setblock 426 178 285 minecraft:light[level=12]
setblock 426 178 292 minecraft:light[level=12]
setblock 426 178 299 minecraft:light[level=12]
setblock 426 178 306 minecraft:light[level=12]
setblock 426 178 313 minecraft:light[level=12]
setblock 433 178 278 minecraft:light[level=12]
setblock 433 178 285 minecraft:light[level=12]
setblock 433 178 292 minecraft:light[level=12]
setblock 433 178 299 minecraft:light[level=12]
setblock 433 178 306 minecraft:light[level=12]
setblock 433 178 313 minecraft:light[level=12]
setblock 440 178 278 minecraft:light[level=12]
setblock 440 178 285 minecraft:light[level=12]
setblock 440 178 292 minecraft:light[level=12]
setblock 440 178 299 minecraft:light[level=12]
setblock 440 178 306 minecraft:light[level=12]
fill 440 178 313 440 179 315 minecraft:iron_block
setblock 447 178 278 minecraft:light[level=12]
setblock 447 178 285 minecraft:light[level=12]
setblock 447 178 292 minecraft:light[level=12]
setblock 447 178 299 minecraft:light[level=12]
setblock 447 178 306 minecraft:light[level=12]
setblock 447 178 313 minecraft:light[level=12]
setblock 454 178 278 minecraft:light[level=12]
setblock 454 178 285 minecraft:light[level=12]
setblock 454 178 292 minecraft:light[level=12]
setblock 454 178 299 minecraft:light[level=12]
setblock 454 178 306 minecraft:light[level=12]
setblock 454 178 313 minecraft:light[level=12]
setblock 461 178 278 minecraft:light[level=12]
setblock 461 178 285 minecraft:light[level=12]
setblock 461 178 292 minecraft:light[level=12]
setblock 461 178 299 minecraft:light[level=12]
setblock 461 178 306 minecraft:light[level=12]
setblock 461 178 313 minecraft:light[level=12]
setblock 424 180 278 minecraft:gray_concrete
fill 424 180 280 424 180 283 minecraft:gray_concrete
setblock 424 180 288 minecraft:gray_concrete
fill 424 180 290 424 180 293 minecraft:gray_concrete
setblock 424 180 298 minecraft:gray_concrete
fill 424 180 300 424 180 303 minecraft:gray_concrete
setblock 424 180 308 minecraft:gray_concrete
fill 424 180 310 424 180 313 minecraft:gray_concrete
fill 425 180 276 428 180 276 minecraft:gray_concrete
setblock 426 180 278 minecraft:light[level=15]
setblock 426 180 286 minecraft:light[level=15]
setblock 426 180 294 minecraft:light[level=15]
setblock 426 180 302 minecraft:light[level=15]
setblock 426 180 310 minecraft:light[level=15]
setblock 426 180 316 minecraft:gray_concrete
fill 428 180 316 431 180 316 minecraft:gray_concrete
setblock 430 180 276 minecraft:gray_concrete
setblock 434 180 278 minecraft:light[level=15]
setblock 434 180 286 minecraft:light[level=15]
setblock 434 180 294 minecraft:light[level=15]
setblock 434 180 302 minecraft:light[level=15]
setblock 434 180 310 minecraft:light[level=15]
fill 435 180 276 438 180 276 minecraft:gray_concrete
setblock 436 180 316 minecraft:gray_concrete
fill 438 180 316 441 180 316 minecraft:gray_concrete
setblock 440 180 276 minecraft:gray_concrete
setblock 442 180 278 minecraft:light[level=15]
setblock 442 180 286 minecraft:light[level=15]
setblock 442 180 294 minecraft:light[level=15]
setblock 442 180 302 minecraft:light[level=15]
setblock 442 180 310 minecraft:light[level=15]
fill 445 180 276 448 180 276 minecraft:gray_concrete
setblock 446 180 316 minecraft:gray_concrete
fill 448 180 316 451 180 316 minecraft:gray_concrete
setblock 450 180 276 minecraft:gray_concrete
setblock 450 180 278 minecraft:light[level=15]
setblock 450 180 286 minecraft:light[level=15]
setblock 450 180 294 minecraft:light[level=15]
setblock 450 180 302 minecraft:light[level=15]
setblock 450 180 310 minecraft:light[level=15]
fill 455 180 276 458 180 276 minecraft:gray_concrete
setblock 456 180 316 minecraft:gray_concrete
setblock 458 180 278 minecraft:light[level=15]
setblock 458 180 286 minecraft:light[level=15]
setblock 458 180 294 minecraft:light[level=15]
setblock 458 180 302 minecraft:light[level=15]
setblock 458 180 310 minecraft:light[level=15]
fill 458 180 316 461 180 316 minecraft:gray_concrete
setblock 460 180 276 minecraft:gray_concrete
fill 461 180 311 463 181 311 minecraft:iron_block
fill 464 180 277 464 180 280 minecraft:gray_concrete
setblock 464 180 282 minecraft:gray_concrete
fill 464 180 287 464 180 290 minecraft:gray_concrete
setblock 464 180 292 minecraft:gray_concrete
fill 464 180 297 464 180 300 minecraft:gray_concrete
setblock 464 180 302 minecraft:gray_concrete
fill 464 180 307 464 180 310 minecraft:gray_concrete
setblock 464 180 312 minecraft:gray_concrete
fill 423 184 281 423 184 284 minecraft:sea_lantern
fill 423 184 291 423 184 294 minecraft:sea_lantern
fill 423 184 301 423 184 304 minecraft:sea_lantern
fill 423 184 311 423 184 314 minecraft:sea_lantern
fill 426 184 275 429 184 275 minecraft:sea_lantern
setblock 426 184 278 minecraft:light[level=12]
setblock 426 184 285 minecraft:light[level=12]
setblock 426 184 292 minecraft:light[level=12]
setblock 426 184 299 minecraft:light[level=12]
setblock 426 184 306 minecraft:light[level=12]
setblock 426 184 313 minecraft:light[level=12]
fill 427 184 317 430 184 317 minecraft:sea_lantern
setblock 433 184 278 minecraft:light[level=12]
setblock 433 184 285 minecraft:light[level=12]
setblock 433 184 292 minecraft:light[level=12]
setblock 433 184 299 minecraft:light[level=12]
setblock 433 184 306 minecraft:light[level=12]
setblock 433 184 313 minecraft:light[level=12]
fill 436 184 275 439 184 275 minecraft:sea_lantern
fill 437 184 317 440 184 317 minecraft:sea_lantern
setblock 440 184 278 minecraft:light[level=12]
setblock 440 184 285 minecraft:light[level=12]
setblock 440 184 292 minecraft:light[level=12]
setblock 440 184 299 minecraft:light[level=12]
setblock 440 184 306 minecraft:light[level=12]
setblock 440 184 313 minecraft:light[level=12]
fill 446 184 275 449 184 275 minecraft:sea_lantern
setblock 447 184 278 minecraft:light[level=12]
setblock 447 184 285 minecraft:light[level=12]
setblock 447 184 292 minecraft:light[level=12]
setblock 447 184 299 minecraft:light[level=12]
setblock 447 184 306 minecraft:light[level=12]
setblock 447 184 313 minecraft:light[level=12]
fill 447 184 317 450 184 317 minecraft:sea_lantern
setblock 454 184 278 minecraft:light[level=12]
setblock 454 184 285 minecraft:light[level=12]
setblock 454 184 292 minecraft:light[level=12]
setblock 454 184 299 minecraft:light[level=12]
setblock 454 184 306 minecraft:light[level=12]
setblock 454 184 313 minecraft:light[level=12]
fill 456 184 275 459 184 275 minecraft:sea_lantern
fill 457 184 317 460 184 317 minecraft:sea_lantern
setblock 461 184 278 minecraft:light[level=12]
setblock 461 184 285 minecraft:light[level=12]
setblock 461 184 292 minecraft:light[level=12]
setblock 461 184 299 minecraft:light[level=12]
setblock 461 184 306 minecraft:light[level=12]
setblock 461 184 313 minecraft:light[level=12]
fill 465 184 276 465 184 279 minecraft:sea_lantern
fill 465 184 286 465 184 289 minecraft:sea_lantern
fill 465 184 296 465 184 299 minecraft:sea_lantern
fill 465 184 306 465 184 309 minecraft:sea_lantern
setblock 465 184 316 minecraft:sea_lantern
fill 423 185 281 423 201 284 minecraft:black_concrete
fill 423 185 291 423 201 294 minecraft:black_concrete
fill 423 185 301 423 201 304 minecraft:black_concrete
fill 423 185 311 423 201 314 minecraft:black_concrete
fill 426 185 275 429 201 275 minecraft:black_concrete
fill 427 185 317 430 201 317 minecraft:black_concrete
fill 436 185 275 439 201 275 minecraft:black_concrete
fill 437 185 317 440 201 317 minecraft:black_concrete
fill 446 185 275 449 201 275 minecraft:black_concrete
fill 447 185 317 450 201 317 minecraft:black_concrete
fill 456 185 275 459 201 275 minecraft:black_concrete
fill 457 185 317 460 201 317 minecraft:black_concrete
fill 462 185 305 463 185 305 minecraft:red_stained_glass
fill 465 185 276 465 201 279 minecraft:black_concrete
fill 465 185 286 465 201 289 minecraft:black_concrete
fill 465 185 296 465 201 299 minecraft:black_concrete
fill 465 185 306 465 201 309 minecraft:black_concrete
fill 465 185 316 465 201 316 minecraft:black_concrete
setblock 426 188 278 minecraft:light[level=15]
setblock 426 188 286 minecraft:light[level=15]
setblock 426 188 294 minecraft:light[level=15]
setblock 426 188 302 minecraft:light[level=15]
setblock 426 188 310 minecraft:light[level=15]
setblock 434 188 278 minecraft:light[level=15]
setblock 434 188 286 minecraft:light[level=15]
setblock 434 188 294 minecraft:light[level=15]
setblock 434 188 302 minecraft:light[level=15]
setblock 434 188 310 minecraft:light[level=15]
setblock 442 188 278 minecraft:light[level=15]
setblock 442 188 286 minecraft:light[level=15]
setblock 442 188 294 minecraft:light[level=15]
setblock 442 188 302 minecraft:light[level=15]
setblock 442 188 310 minecraft:light[level=15]
setblock 450 188 278 minecraft:light[level=15]
setblock 450 188 286 minecraft:light[level=15]
setblock 450 188 294 minecraft:light[level=15]
setblock 450 188 302 minecraft:light[level=15]
setblock 450 188 310 minecraft:light[level=15]
setblock 458 188 278 minecraft:light[level=15]
setblock 458 188 286 minecraft:light[level=15]
setblock 458 188 294 minecraft:light[level=15]
setblock 458 188 302 minecraft:light[level=15]
setblock 458 188 310 minecraft:light[level=15]
setblock 426 190 278 minecraft:light[level=12]
setblock 426 190 285 minecraft:light[level=12]
setblock 426 190 292 minecraft:light[level=12]
setblock 426 190 299 minecraft:light[level=12]
setblock 426 190 306 minecraft:light[level=12]
setblock 426 190 313 minecraft:light[level=12]
setblock 433 190 278 minecraft:light[level=12]
setblock 433 190 285 minecraft:light[level=12]
setblock 433 190 292 minecraft:light[level=12]
setblock 433 190 299 minecraft:light[level=12]
setblock 433 190 306 minecraft:light[level=12]
setblock 433 190 313 minecraft:light[level=12]
setblock 440 190 278 minecraft:light[level=12]
setblock 440 190 285 minecraft:light[level=12]
setblock 440 190 292 minecraft:light[level=12]
setblock 440 190 299 minecraft:light[level=12]
setblock 440 190 306 minecraft:light[level=12]
setblock 440 190 313 minecraft:light[level=12]
setblock 447 190 278 minecraft:light[level=12]
setblock 447 190 285 minecraft:light[level=12]
setblock 447 190 299 minecraft:light[level=12]
setblock 447 190 306 minecraft:light[level=12]
setblock 447 190 313 minecraft:light[level=12]
setblock 454 190 278 minecraft:light[level=12]
setblock 454 190 285 minecraft:light[level=12]
setblock 454 190 292 minecraft:light[level=12]
setblock 454 190 299 minecraft:light[level=12]
setblock 454 190 306 minecraft:light[level=12]
setblock 454 190 313 minecraft:light[level=12]
setblock 461 190 278 minecraft:light[level=12]
setblock 461 190 285 minecraft:light[level=12]
setblock 461 190 292 minecraft:light[level=12]
setblock 461 190 299 minecraft:light[level=12]
setblock 461 190 306 minecraft:light[level=12]
setblock 461 190 313 minecraft:light[level=12]
fill 462 190 286 463 190 286 minecraft:red_stained_glass
fill 434 191 292 441 191 292 minecraft:black_concrete
fill 435 191 288 442 191 291 minecraft:black_concrete
fill 435 191 293 442 191 296 minecraft:black_concrete
fill 436 191 286 454 191 287 minecraft:black_concrete
fill 436 191 297 454 191 298 minecraft:black_concrete
fill 437 191 285 453 191 285 minecraft:black_concrete
fill 437 191 299 453 191 299 minecraft:black_concrete
fill 438 191 284 452 191 284 minecraft:black_concrete
fill 438 191 300 452 191 300 minecraft:black_concrete
fill 439 191 283 451 191 283 minecraft:black_concrete
fill 439 191 301 451 191 301 minecraft:black_concrete
fill 441 191 282 449 192 282 minecraft:black_concrete
fill 441 191 302 449 192 302 minecraft:black_concrete
fill 443 191 288 444 191 289 minecraft:black_concrete
fill 443 191 295 444 191 296 minecraft:black_concrete
fill 445 191 281 445 192 281 minecraft:black_concrete
fill 445 191 288 455 191 288 minecraft:black_concrete
fill 445 191 296 455 191 296 minecraft:black_concrete
fill 445 191 303 445 192 303 minecraft:black_concrete
fill 446 191 289 455 191 289 minecraft:black_concrete
fill 446 191 295 455 191 295 minecraft:black_concrete
fill 448 191 290 455 191 291 minecraft:black_concrete
fill 448 191 293 455 191 294 minecraft:black_concrete
fill 449 191 292 456 191 292 minecraft:black_concrete
fill 424 192 276 424 192 277 minecraft:gray_concrete
setblock 424 192 278 minecraft:black_concrete
fill 424 192 279 424 192 281 minecraft:gray_concrete
setblock 424 192 282 minecraft:black_concrete
fill 424 192 283 424 192 285 minecraft:gray_concrete
setblock 424 192 286 minecraft:black_concrete
fill 424 192 287 424 192 289 minecraft:gray_concrete
setblock 424 192 290 minecraft:black_concrete
fill 424 192 291 424 192 293 minecraft:gray_concrete
setblock 424 192 294 minecraft:black_concrete
fill 424 192 295 424 192 297 minecraft:gray_concrete
setblock 424 192 298 minecraft:black_concrete
fill 424 192 299 424 192 301 minecraft:gray_concrete
setblock 424 192 302 minecraft:black_concrete
fill 424 192 303 424 192 305 minecraft:gray_concrete
setblock 424 192 306 minecraft:black_concrete
fill 424 192 307 424 192 309 minecraft:gray_concrete
setblock 424 192 310 minecraft:black_concrete
fill 424 192 311 424 192 313 minecraft:gray_concrete
setblock 424 192 314 minecraft:black_concrete
fill 424 192 315 425 192 316 minecraft:gray_concrete
setblock 425 192 276 minecraft:gray_concrete
setblock 425 192 277 minecraft:black_concrete
fill 425 192 278 425 192 280 minecraft:gray_concrete
setblock 425 192 281 minecraft:black_concrete
fill 425 192 282 425 192 284 minecraft:gray_concrete
setblock 425 192 285 minecraft:black_concrete
fill 425 192 286 425 192 288 minecraft:gray_concrete
setblock 425 192 289 minecraft:black_concrete
fill 425 192 290 425 192 292 minecraft:gray_concrete
setblock 425 192 293 minecraft:black_concrete
fill 425 192 294 425 192 296 minecraft:gray_concrete
setblock 425 192 297 minecraft:black_concrete
fill 425 192 298 425 192 300 minecraft:gray_concrete
setblock 425 192 301 minecraft:black_concrete
fill 425 192 302 425 192 304 minecraft:gray_concrete
setblock 425 192 305 minecraft:black_concrete
fill 425 192 306 425 192 308 minecraft:gray_concrete
setblock 425 192 309 minecraft:black_concrete
fill 425 192 310 425 192 312 minecraft:gray_concrete
setblock 425 192 313 minecraft:black_concrete
fill 425 192 314 427 192 314 minecraft:gray_concrete
setblock 426 192 276 minecraft:black_concrete
fill 426 192 277 426 192 279 minecraft:gray_concrete
setblock 426 192 280 minecraft:black_concrete
fill 426 192 281 426 192 283 minecraft:gray_concrete
setblock 426 192 284 minecraft:black_concrete
fill 426 192 285 426 192 287 minecraft:gray_concrete
setblock 426 192 288 minecraft:black_concrete
fill 426 192 289 426 192 291 minecraft:gray_concrete
setblock 426 192 292 minecraft:black_concrete
fill 426 192 293 426 192 295 minecraft:gray_concrete
setblock 426 192 296 minecraft:black_concrete
fill 426 192 297 426 192 299 minecraft:gray_concrete
setblock 426 192 300 minecraft:black_concrete
fill 426 192 301 426 192 303 minecraft:gray_concrete
setblock 426 192 304 minecraft:black_concrete
fill 426 192 305 426 192 307 minecraft:gray_concrete
setblock 426 192 308 minecraft:black_concrete
fill 426 192 309 426 192 311 minecraft:gray_concrete
setblock 426 192 312 minecraft:black_concrete
fill 426 192 313 428 192 313 minecraft:gray_concrete
setblock 426 192 315 minecraft:gray_concrete
setblock 426 192 316 minecraft:black_concrete
fill 427 192 276 427 192 278 minecraft:gray_concrete
setblock 427 192 279 minecraft:black_concrete
fill 427 192 280 427 192 282 minecraft:gray_concrete
setblock 427 192 283 minecraft:black_concrete
fill 427 192 284 427 192 286 minecraft:gray_concrete
setblock 427 192 287 minecraft:black_concrete
fill 427 192 288 427 192 290 minecraft:gray_concrete
setblock 427 192 291 minecraft:black_concrete
fill 427 192 292 427 192 294 minecraft:gray_concrete
setblock 427 192 295 minecraft:black_concrete
fill 427 192 296 427 192 298 minecraft:gray_concrete
setblock 427 192 299 minecraft:black_concrete
fill 427 192 300 427 192 302 minecraft:gray_concrete
setblock 427 192 303 minecraft:black_concrete
fill 427 192 304 427 192 306 minecraft:gray_concrete
setblock 427 192 307 minecraft:black_concrete
fill 427 192 308 427 192 310 minecraft:gray_concrete
setblock 427 192 311 minecraft:black_concrete
fill 427 192 312 429 192 312 minecraft:gray_concrete
setblock 427 192 315 minecraft:black_concrete
fill 427 192 316 429 192 316 minecraft:gray_concrete
fill 428 192 276 428 192 277 minecraft:gray_concrete
setblock 428 192 278 minecraft:black_concrete
fill 428 192 279 428 192 281 minecraft:gray_concrete
setblock 428 192 282 minecraft:black_concrete
fill 428 192 283 428 192 285 minecraft:gray_concrete
setblock 428 192 286 minecraft:black_concrete
fill 428 192 287 428 192 289 minecraft:gray_concrete
setblock 428 192 290 minecraft:black_concrete
fill 428 192 291 428 192 293 minecraft:gray_concrete
setblock 428 192 294 minecraft:black_concrete
fill 428 192 295 428 192 297 minecraft:gray_concrete
setblock 428 192 298 minecraft:black_concrete
fill 428 192 299 428 192 301 minecraft:gray_concrete
setblock 428 192 302 minecraft:black_concrete
fill 428 192 303 428 192 305 minecraft:gray_concrete
setblock 428 192 306 minecraft:black_concrete
fill 428 192 307 428 192 309 minecraft:gray_concrete
setblock 428 192 310 minecraft:black_concrete
fill 428 192 311 430 192 311 minecraft:gray_concrete
setblock 428 192 314 minecraft:black_concrete
fill 428 192 315 430 192 315 minecraft:gray_concrete
setblock 429 192 276 minecraft:gray_concrete
setblock 429 192 277 minecraft:black_concrete
fill 429 192 278 429 192 280 minecraft:gray_concrete
setblock 429 192 281 minecraft:black_concrete
fill 429 192 282 429 192 284 minecraft:gray_concrete
setblock 429 192 285 minecraft:black_concrete
fill 429 192 286 429 192 288 minecraft:gray_concrete
setblock 429 192 289 minecraft:black_concrete
fill 429 192 290 429 192 292 minecraft:gray_concrete
setblock 429 192 293 minecraft:black_concrete
fill 429 192 294 429 192 296 minecraft:gray_concrete
setblock 429 192 297 minecraft:black_concrete
fill 429 192 298 429 192 300 minecraft:gray_concrete
setblock 429 192 301 minecraft:black_concrete
fill 429 192 302 429 192 304 minecraft:gray_concrete
setblock 429 192 305 minecraft:black_concrete
fill 429 192 306 429 192 308 minecraft:gray_concrete
setblock 429 192 309 minecraft:black_concrete
fill 429 192 310 431 192 310 minecraft:gray_concrete
setblock 429 192 313 minecraft:black_concrete
fill 429 192 314 431 192 314 minecraft:gray_concrete
setblock 430 192 276 minecraft:black_concrete
fill 430 192 277 430 192 279 minecraft:gray_concrete
setblock 430 192 280 minecraft:black_concrete
fill 430 192 281 430 192 283 minecraft:gray_concrete
setblock 430 192 284 minecraft:black_concrete
fill 430 192 285 430 192 287 minecraft:gray_concrete
setblock 430 192 288 minecraft:black_concrete
fill 430 192 289 430 192 291 minecraft:gray_concrete
setblock 430 192 292 minecraft:black_concrete
fill 430 192 293 430 192 295 minecraft:gray_concrete
setblock 430 192 296 minecraft:black_concrete
fill 430 192 297 430 192 299 minecraft:gray_concrete
setblock 430 192 300 minecraft:black_concrete
fill 430 192 301 430 192 303 minecraft:gray_concrete
schedule function dropper:buildpart/69_2 1t
