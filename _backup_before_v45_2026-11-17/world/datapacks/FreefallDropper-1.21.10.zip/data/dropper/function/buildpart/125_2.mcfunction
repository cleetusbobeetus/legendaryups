fill 253 178 527 253 178 528 minecraft:magma_block
fill 253 178 538 253 178 539 minecraft:magma_block
setblock 253 178 540 minecraft:basalt
setblock 253 178 542 minecraft:magma_block
fill 254 178 523 254 178 524 minecraft:basalt
setblock 254 178 527 minecraft:basalt
fill 254 178 528 255 178 528 minecraft:magma_block
fill 254 178 538 255 178 538 minecraft:magma_block
setblock 254 178 539 minecraft:basalt
setblock 254 178 542 minecraft:basalt
setblock 255 178 523 minecraft:basalt
fill 255 178 527 256 178 527 minecraft:magma_block
fill 255 178 539 256 178 539 minecraft:magma_block
setblock 256 178 523 minecraft:magma_block
setblock 256 178 526 minecraft:magma_block
setblock 256 178 541 minecraft:magma_block
setblock 257 178 526 minecraft:basalt
fill 257 178 528 259 178 528 minecraft:magma_block
fill 257 178 538 259 178 538 minecraft:magma_block
fill 257 178 541 258 178 541 minecraft:basalt
setblock 259 178 524 minecraft:basalt
setblock 259 178 525 minecraft:magma_block
setblock 259 178 539 minecraft:basalt
setblock 259 178 540 minecraft:magma_block
setblock 260 178 529 minecraft:magma_block
setblock 260 178 537 minecraft:magma_block
setblock 260 178 538 minecraft:basalt
fill 261 178 530 261 178 532 minecraft:magma_block
fill 261 178 534 261 178 536 minecraft:magma_block
setblock 262 178 527 minecraft:magma_block
setblock 262 178 530 minecraft:magma_block
setblock 262 178 531 minecraft:basalt
fill 262 178 532 262 178 534 minecraft:magma_block
setblock 262 178 535 minecraft:basalt
setblock 262 178 536 minecraft:magma_block
setblock 262 178 537 minecraft:basalt
setblock 262 178 539 minecraft:magma_block
setblock 263 178 540 minecraft:basalt
setblock 264 178 538 minecraft:basalt
setblock 265 178 528 minecraft:basalt
setblock 265 178 529 minecraft:magma_block
setblock 265 178 531 minecraft:basalt
setblock 265 178 532 minecraft:magma_block
fill 265 178 533 265 178 534 minecraft:basalt
setblock 265 178 535 minecraft:magma_block
setblock 265 178 536 minecraft:basalt
setblock 265 178 538 minecraft:magma_block
setblock 268 178 530 minecraft:bone_block
fill 269 178 528 269 183 528 minecraft:bone_block
fill 269 178 532 270 178 532 minecraft:bone_block
fill 270 178 527 271 183 527 minecraft:bone_block
fill 270 178 533 271 178 533 minecraft:bone_block
fill 272 178 528 272 181 528 minecraft:bone_block
fill 277 178 519 277 191 519 minecraft:black_concrete
setblock 238 179 513 minecraft:light[level=12]
setblock 238 179 521 minecraft:light[level=12]
setblock 238 179 529 minecraft:light[level=12]
setblock 238 179 537 minecraft:light[level=12]
setblock 238 179 545 minecraft:light[level=12]
fill 240 179 510 240 246 510 minecraft:black_concrete
setblock 246 179 513 minecraft:light[level=12]
setblock 246 179 521 minecraft:light[level=12]
setblock 246 179 529 minecraft:light[level=12]
setblock 246 179 537 minecraft:light[level=12]
setblock 246 179 545 minecraft:light[level=12]
setblock 250 179 552 minecraft:white_concrete
fill 251 179 552 254 180 552 minecraft:black_concrete
setblock 254 179 513 minecraft:light[level=12]
setblock 254 179 521 minecraft:light[level=12]
setblock 254 179 529 minecraft:light[level=12]
setblock 254 179 537 minecraft:light[level=12]
setblock 254 179 545 minecraft:light[level=12]
setblock 262 179 513 minecraft:light[level=12]
setblock 262 179 521 minecraft:light[level=12]
setblock 262 179 529 minecraft:light[level=12]
setblock 262 179 537 minecraft:light[level=12]
setblock 262 179 545 minecraft:light[level=12]
fill 265 179 513 265 180 514 minecraft:bone_block
fill 268 179 528 268 180 529 minecraft:bone_block
fill 269 179 526 269 184 527 minecraft:bone_block
setblock 270 179 513 minecraft:light[level=12]
setblock 270 179 521 minecraft:light[level=12]
fill 270 179 526 271 184 526 minecraft:bone_block
fill 270 179 532 271 179 532 minecraft:bone_block
setblock 270 179 537 minecraft:light[level=12]
setblock 270 179 545 minecraft:light[level=12]
setblock 272 179 510 minecraft:crying_obsidian
fill 272 179 527 272 182 527 minecraft:bone_block
fill 275 179 529 276 180 529 minecraft:bone_block
setblock 235 180 511 minecraft:black_concrete
setblock 235 180 512 minecraft:crying_obsidian
fill 235 180 513 235 188 513 minecraft:black_concrete
fill 235 180 518 235 182 518 minecraft:purple_concrete
setblock 235 180 526 minecraft:white_concrete
setblock 235 180 533 minecraft:crying_obsidian
fill 235 180 534 235 182 534 minecraft:purple_concrete
fill 235 180 550 235 182 550 minecraft:purple_concrete
fill 239 180 510 239 182 510 minecraft:purple_concrete
fill 239 180 511 239 183 511 minecraft:amethyst_block
fill 249 180 552 249 182 552 minecraft:purple_concrete
setblock 250 180 552 minecraft:black_concrete
fill 255 180 510 255 182 510 minecraft:purple_concrete
setblock 264 180 514 minecraft:bone_block
fill 265 180 515 265 181 515 minecraft:bone_block
fill 265 180 552 265 182 552 minecraft:purple_concrete
fill 268 180 526 268 183 527 minecraft:bone_block
fill 269 180 525 270 185 525 minecraft:bone_block
fill 270 180 531 271 180 531 minecraft:bone_block
fill 271 180 510 271 182 510 minecraft:purple_concrete
fill 272 180 510 272 206 510 minecraft:black_concrete
fill 274 180 528 275 181 528 minecraft:bone_block
fill 277 180 520 277 182 520 minecraft:purple_concrete
fill 277 180 536 277 182 536 minecraft:purple_concrete
setblock 277 180 544 minecraft:crying_obsidian
setblock 235 181 511 minecraft:amethyst_block
fill 235 181 512 235 307 512 minecraft:black_concrete
fill 235 181 526 235 209 526 minecraft:black_concrete
fill 235 181 533 235 199 533 minecraft:black_concrete
fill 238 181 511 238 182 512 minecraft:amethyst_block
fill 239 181 512 239 181 514 minecraft:amethyst_block
fill 240 181 511 240 182 512 minecraft:amethyst_block
setblock 250 181 552 minecraft:crying_obsidian
fill 251 181 552 252 235 552 minecraft:black_concrete
setblock 253 181 552 minecraft:white_concrete
fill 254 181 552 254 217 552 minecraft:black_concrete
setblock 258 181 510 minecraft:white_concrete
fill 258 181 552 262 182 552 minecraft:black_concrete
setblock 263 181 552 minecraft:amethyst_block
fill 264 181 552 264 192 552 minecraft:black_concrete
fill 265 181 516 266 181 516 minecraft:bone_block
setblock 266 181 515 minecraft:bone_block
fill 266 181 517 266 182 517 minecraft:bone_block
fill 268 181 525 268 186 525 minecraft:bone_block
fill 268 181 528 268 182 528 minecraft:bone_block
fill 269 181 524 270 186 524 minecraft:bone_block
fill 271 181 525 271 184 525 minecraft:bone_block
fill 272 181 526 272 183 526 minecraft:bone_block
fill 273 181 527 273 181 528 minecraft:bone_block
setblock 274 181 527 minecraft:bone_block
setblock 277 181 544 minecraft:black_concrete
setblock 277 181 551 minecraft:crying_obsidian
fill 235 182 511 235 202 511 minecraft:black_concrete
setblock 238 182 510 minecraft:crying_obsidian
fill 239 182 512 239 182 513 minecraft:amethyst_block
fill 250 182 552 250 209 552 minecraft:black_concrete
fill 253 182 552 253 206 552 minecraft:black_concrete
setblock 254 182 510 minecraft:amethyst_block
setblock 258 182 510 minecraft:black_concrete
fill 263 182 510 263 235 510 minecraft:black_concrete
fill 263 182 552 263 205 552 minecraft:black_concrete
setblock 264 182 510 minecraft:amethyst_block
fill 265 182 510 265 263 510 minecraft:black_concrete
setblock 265 182 517 minecraft:bone_block
setblock 266 182 516 minecraft:bone_block
fill 266 182 518 266 183 518 minecraft:bone_block
fill 267 182 525 267 186 525 minecraft:bone_block
fill 268 182 523 268 187 524 minecraft:bone_block
fill 269 182 523 270 186 523 minecraft:bone_block
setblock 269 182 552 minecraft:amethyst_block
fill 271 182 524 271 184 524 minecraft:bone_block
fill 273 182 526 273 182 527 minecraft:bone_block
setblock 277 182 544 minecraft:crying_obsidian
fill 277 182 551 277 262 551 minecraft:black_concrete
fill 235 183 518 235 188 518 minecraft:black_concrete
fill 235 183 534 235 188 534 minecraft:black_concrete
fill 235 183 550 235 188 550 minecraft:black_concrete
fill 238 183 510 239 188 510 minecraft:black_concrete
fill 249 183 552 249 188 552 minecraft:black_concrete
fill 254 183 510 255 188 510 minecraft:black_concrete
setblock 258 183 510 minecraft:amethyst_block
fill 258 183 552 258 188 552 minecraft:black_concrete
setblock 259 183 552 minecraft:amethyst_block
fill 260 183 552 262 185 552 minecraft:black_concrete
fill 264 183 510 264 204 510 minecraft:black_concrete
fill 265 183 552 265 188 552 minecraft:black_concrete
fill 266 183 519 267 183 519 minecraft:bone_block
setblock 267 183 518 minecraft:bone_block
fill 267 183 520 267 184 520 minecraft:bone_block
fill 267 183 523 267 187 524 minecraft:bone_block
setblock 267 183 526 minecraft:bone_block
fill 268 183 522 269 188 522 minecraft:bone_block
fill 269 183 552 269 307 552 minecraft:black_concrete
setblock 270 183 528 minecraft:bone_block
fill 271 183 510 271 185 510 minecraft:black_concrete
setblock 272 183 525 minecraft:bone_block
fill 277 183 520 277 188 520 minecraft:black_concrete
fill 277 183 536 277 188 536 minecraft:black_concrete
setblock 277 183 544 minecraft:black_concrete
setblock 236 184 510 minecraft:white_concrete
fill 258 184 510 258 259 510 minecraft:black_concrete
fill 259 184 552 259 214 552 minecraft:black_concrete
fill 266 184 523 266 188 523 minecraft:bone_block
setblock 267 184 519 minecraft:bone_block
fill 267 184 521 267 189 522 minecraft:bone_block
fill 268 184 521 268 189 521 minecraft:bone_block
fill 268 184 526 268 185 526 minecraft:bone_block
fill 270 184 522 270 186 522 minecraft:bone_block
setblock 270 184 527 minecraft:bone_block
setblock 277 184 523 minecraft:crying_obsidian
setblock 277 184 544 minecraft:white_concrete
fill 236 185 510 236 261 510 minecraft:black_concrete
fill 266 185 521 266 190 522 minecraft:bone_block
fill 266 185 524 266 186 524 minecraft:bone_block
fill 269 185 521 269 187 521 minecraft:bone_block
fill 269 185 526 270 185 526 minecraft:bone_block
fill 277 185 523 277 307 523 minecraft:black_concrete
fill 277 185 544 277 238 544 minecraft:black_concrete
fill 260 186 552 261 240 552 minecraft:black_concrete
setblock 262 186 552 minecraft:crying_obsidian
fill 265 186 520 265 190 522 minecraft:bone_block
fill 266 186 520 268 189 520 minecraft:bone_block
setblock 269 186 525 minecraft:bone_block
setblock 271 186 510 minecraft:white_concrete
setblock 235 187 551 minecraft:amethyst_block
setblock 238 187 513 minecraft:light[level=12]
setblock 238 187 521 minecraft:light[level=12]
setblock 238 187 529 minecraft:light[level=12]
setblock 238 187 537 minecraft:light[level=12]
setblock 238 187 545 minecraft:light[level=12]
setblock 246 187 513 minecraft:light[level=12]
setblock 246 187 521 minecraft:light[level=12]
setblock 246 187 529 minecraft:light[level=12]
setblock 246 187 537 minecraft:light[level=12]
setblock 246 187 545 minecraft:light[level=12]
setblock 248 187 510 minecraft:amethyst_block
fill 249 187 510 249 307 510 minecraft:black_concrete
setblock 254 187 513 minecraft:light[level=12]
setblock 254 187 521 minecraft:light[level=12]
setblock 254 187 529 minecraft:light[level=12]
setblock 254 187 537 minecraft:light[level=12]
setblock 254 187 545 minecraft:light[level=12]
setblock 262 187 513 minecraft:light[level=12]
setblock 262 187 521 minecraft:light[level=12]
setblock 262 187 529 minecraft:light[level=12]
setblock 262 187 537 minecraft:light[level=12]
setblock 262 187 545 minecraft:light[level=12]
fill 262 187 552 262 200 552 minecraft:black_concrete
fill 264 187 520 264 191 521 minecraft:bone_block
fill 265 187 519 267 190 519 minecraft:bone_block
setblock 265 187 523 minecraft:bone_block
fill 269 187 523 269 187 524 minecraft:bone_block
setblock 270 187 513 minecraft:light[level=12]
setblock 270 187 521 minecraft:light[level=12]
setblock 270 187 529 minecraft:light[level=12]
setblock 270 187 537 minecraft:light[level=12]
setblock 270 187 545 minecraft:light[level=12]
fill 271 187 510 271 188 510 minecraft:black_concrete
setblock 274 187 552 minecraft:amethyst_block
fill 235 188 551 235 246 551 minecraft:black_concrete
fill 248 188 510 248 307 510 minecraft:black_concrete
fill 252 188 512 253 188 512 minecraft:bone_block
setblock 253 188 511 minecraft:bone_block
fill 264 188 519 264 193 519 minecraft:bone_block
fill 265 188 518 266 191 518 minecraft:bone_block
fill 267 188 523 268 188 523 minecraft:bone_block
fill 269 188 518 271 188 518 minecraft:bone_block
setblock 270 188 517 minecraft:bone_block
fill 274 188 552 274 267 552 minecraft:black_concrete
setblock 235 189 513 minecraft:white_concrete
fill 235 189 518 235 191 518 minecraft:purple_concrete
fill 235 189 534 235 191 534 minecraft:purple_concrete
fill 235 189 550 235 191 550 minecraft:purple_concrete
fill 238 189 510 238 208 510 minecraft:black_concrete
fill 239 189 510 239 191 510 minecraft:purple_concrete
fill 249 189 552 249 191 552 minecraft:purple_concrete
fill 253 189 512 254 189 513 minecraft:bone_block
fill 254 189 510 254 307 510 minecraft:black_concrete
fill 255 189 510 255 191 510 minecraft:purple_concrete
fill 255 189 513 255 190 513 minecraft:bone_block
setblock 258 189 552 minecraft:crying_obsidian
fill 263 189 518 263 191 521 minecraft:bone_block
fill 264 189 518 264 194 518 minecraft:bone_block
fill 265 189 552 265 191 552 minecraft:purple_concrete
fill 268 189 517 269 189 518 minecraft:bone_block
setblock 268 189 522 minecraft:bone_block
setblock 270 189 518 minecraft:bone_block
fill 271 189 510 271 191 510 minecraft:purple_concrete
fill 277 189 520 277 191 520 minecraft:purple_concrete
fill 277 189 536 277 191 536 minecraft:purple_concrete
fill 235 190 513 235 199 513 minecraft:black_concrete
setblock 235 190 532 minecraft:white_concrete
setblock 254 190 513 minecraft:bone_block
fill 255 190 514 256 190 514 minecraft:bone_block
setblock 256 190 552 minecraft:crying_obsidian
fill 258 190 552 258 236 552 minecraft:black_concrete
fill 262 190 517 262 193 520 minecraft:bone_block
fill 263 190 517 268 190 517 minecraft:bone_block
fill 266 190 520 267 190 520 minecraft:bone_block
fill 267 190 518 268 190 518 minecraft:bone_block
setblock 267 190 521 minecraft:bone_block
fill 274 190 529 276 193 529 minecraft:amethyst_block
fill 275 190 528 275 193 528 minecraft:amethyst_block
fill 275 190 530 275 193 530 minecraft:amethyst_block
setblock 276 190 510 minecraft:crying_obsidian
fill 235 191 532 235 208 532 minecraft:black_concrete
fill 256 191 514 257 191 515 minecraft:bone_block
setblock 256 191 552 minecraft:black_concrete
fill 258 191 515 258 192 515 minecraft:bone_block
fill 261 191 517 261 195 519 minecraft:bone_block
fill 263 191 517 266 191 517 minecraft:bone_block
fill 265 191 519 266 191 521 minecraft:bone_block
setblock 267 191 518 minecraft:bone_block
fill 273 191 529 273 193 529 minecraft:amethyst_block
fill 274 191 528 274 193 528 minecraft:amethyst_block
fill 274 191 530 274 193 530 minecraft:amethyst_block
fill 276 191 510 276 276 510 minecraft:black_concrete
fill 276 191 528 276 192 528 minecraft:amethyst_block
fill 276 191 530 276 192 530 minecraft:amethyst_block
fill 277 191 532 277 204 533 minecraft:black_concrete
setblock 277 191 534 minecraft:white_concrete
setblock 277 191 541 minecraft:white_concrete
fill 235 192 518 235 197 518 minecraft:black_concrete
fill 235 192 534 235 197 534 minecraft:black_concrete
fill 235 192 550 235 197 550 minecraft:black_concrete
fill 239 192 510 239 197 510 minecraft:black_concrete
fill 249 192 552 249 197 552 minecraft:black_concrete
fill 255 192 510 255 197 510 minecraft:black_concrete
setblock 256 192 552 minecraft:crying_obsidian
setblock 257 192 515 minecraft:bone_block
fill 258 192 516 259 198 516 minecraft:bone_block
fill 260 192 517 260 196 519 minecraft:bone_block
fill 261 192 516 263 194 516 minecraft:bone_block
fill 261 192 520 261 193 520 minecraft:bone_block
fill 263 192 517 263 193 520 minecraft:bone_block
fill 264 192 517 265 192 517 minecraft:bone_block
fill 264 192 520 265 192 520 minecraft:bone_block
fill 265 192 518 265 193 519 minecraft:bone_block
fill 265 192 552 265 197 552 minecraft:black_concrete
fill 271 192 510 271 197 510 minecraft:black_concrete
fill 272 192 529 272 193 529 minecraft:amethyst_block
setblock 273 192 528 minecraft:amethyst_block
setblock 273 192 530 minecraft:amethyst_block
setblock 277 192 519 minecraft:crying_obsidian
fill 277 192 520 277 197 520 minecraft:black_concrete
fill 277 192 534 277 198 534 minecraft:black_concrete
fill 277 192 536 277 197 536 minecraft:black_concrete
fill 277 192 541 277 196 541 minecraft:black_concrete
setblock 235 193 539 minecraft:crying_obsidian
fill 243 193 510 243 196 510 minecraft:black_concrete
setblock 244 193 510 minecraft:amethyst_block
fill 245 193 510 246 251 510 minecraft:black_concrete
fill 256 193 552 256 307 552 minecraft:black_concrete
fill 259 193 517 259 198 518 minecraft:bone_block
fill 260 193 516 260 197 516 minecraft:bone_block
setblock 264 193 517 minecraft:bone_block
setblock 264 193 520 minecraft:bone_block
setblock 264 193 552 minecraft:crying_obsidian
setblock 271 193 529 minecraft:amethyst_block
setblock 277 193 516 minecraft:crying_obsidian
fill 277 193 519 277 227 519 minecraft:black_concrete
setblock 277 193 547 minecraft:amethyst_block
fill 235 194 539 235 262 539 minecraft:black_concrete
setblock 235 194 541 minecraft:crying_obsidian
fill 244 194 510 244 224 510 minecraft:black_concrete
fill 244 194 552 245 211 552 minecraft:black_concrete
setblock 246 194 552 minecraft:amethyst_block
fill 258 194 517 258 199 518 minecraft:bone_block
fill 259 194 515 261 195 515 minecraft:bone_block
fill 259 194 519 259 196 519 minecraft:bone_block
fill 262 194 517 263 194 519 minecraft:bone_block
fill 264 194 552 264 307 552 minecraft:black_concrete
fill 277 194 516 277 208 516 minecraft:black_concrete
fill 277 194 529 277 241 529 minecraft:black_concrete
setblock 277 194 530 minecraft:white_concrete
fill 277 194 547 277 265 547 minecraft:black_concrete
setblock 235 195 536 minecraft:white_concrete
setblock 235 195 537 minecraft:amethyst_block
fill 235 195 538 235 210 538 minecraft:black_concrete
fill 235 195 541 235 224 541 minecraft:black_concrete
setblock 238 195 513 minecraft:light[level=12]
setblock 238 195 521 minecraft:light[level=12]
setblock 238 195 529 minecraft:light[level=12]
setblock 238 195 537 minecraft:light[level=12]
setblock 238 195 545 minecraft:light[level=12]
setblock 246 195 513 minecraft:light[level=12]
setblock 246 195 521 minecraft:light[level=12]
setblock 246 195 529 minecraft:light[level=12]
setblock 246 195 537 minecraft:light[level=12]
setblock 246 195 545 minecraft:light[level=12]
fill 246 195 552 246 299 552 minecraft:black_concrete
setblock 254 195 513 minecraft:light[level=12]
setblock 254 195 521 minecraft:light[level=12]
setblock 254 195 529 minecraft:light[level=12]
setblock 254 195 537 minecraft:light[level=12]
setblock 254 195 545 minecraft:light[level=12]
setblock 256 195 510 minecraft:crying_obsidian
fill 257 195 516 257 200 518 minecraft:bone_block
fill 258 195 515 258 199 515 minecraft:bone_block
fill 261 195 516 262 195 516 minecraft:bone_block
setblock 262 195 513 minecraft:light[level=12]
fill 262 195 517 262 195 519 minecraft:bone_block
setblock 262 195 521 minecraft:light[level=12]
setblock 262 195 529 minecraft:light[level=12]
setblock 262 195 537 minecraft:light[level=12]
setblock 262 195 545 minecraft:light[level=12]
fill 263 195 517 263 195 518 minecraft:bone_block
setblock 270 195 513 minecraft:light[level=12]
setblock 270 195 521 minecraft:light[level=12]
setblock 270 195 529 minecraft:light[level=12]
setblock 270 195 537 minecraft:light[level=12]
setblock 270 195 545 minecraft:light[level=12]
fill 277 195 530 277 307 530 minecraft:black_concrete
setblock 235 196 531 minecraft:amethyst_block
fill 235 196 536 235 218 537 minecraft:black_concrete
fill 235 196 545 235 209 545 minecraft:black_concrete
setblock 235 196 546 minecraft:crying_obsidian
fill 235 196 552 235 307 552 minecraft:black_concrete
setblock 236 196 552 minecraft:crying_obsidian
fill 242 196 517 242 197 518 minecraft:bone_block
fill 256 196 510 256 287 510 minecraft:black_concrete
fill 256 196 516 256 201 518 minecraft:bone_block
fill 257 196 515 257 200 515 minecraft:bone_block
fill 258 196 519 258 197 519 minecraft:bone_block
fill 259 196 515 260 196 515 minecraft:bone_block
fill 260 196 512 260 197 512 minecraft:bone_block
fill 261 196 516 261 196 518 minecraft:bone_block
setblock 262 196 517 minecraft:bone_block
setblock 270 196 552 minecraft:crying_obsidian
fill 235 197 531 235 282 531 minecraft:black_concrete
fill 235 197 542 235 199 542 minecraft:black_concrete
setblock 235 197 543 minecraft:white_concrete
fill 235 197 544 235 217 544 minecraft:black_concrete
fill 235 197 546 235 307 546 minecraft:black_concrete
fill 236 197 552 236 215 552 minecraft:black_concrete
setblock 243 197 510 minecraft:white_concrete
fill 243 197 517 243 198 518 minecraft:bone_block
fill 244 197 517 244 198 517 minecraft:bone_block
fill 255 197 516 255 202 518 minecraft:bone_block
fill 256 197 515 256 201 515 minecraft:bone_block
fill 258 197 513 259 198 513 minecraft:bone_block
fill 259 197 512 259 198 512 minecraft:bone_block
fill 259 197 515 259 198 515 minecraft:bone_block
fill 260 197 517 260 197 518 minecraft:bone_block
setblock 261 197 517 minecraft:bone_block
fill 270 197 552 270 307 552 minecraft:black_concrete
setblock 277 197 541 minecraft:amethyst_block
setblock 235 198 515 minecraft:crying_obsidian
fill 235 198 518 235 200 518 minecraft:purple_concrete
fill 235 198 534 235 200 534 minecraft:purple_concrete
fill 235 198 543 235 244 543 minecraft:black_concrete
fill 235 198 550 235 200 550 minecraft:purple_concrete
fill 239 198 510 239 200 510 minecraft:purple_concrete
fill 243 198 510 243 283 510 minecraft:black_concrete
fill 244 198 518 245 198 518 minecraft:bone_block
fill 245 198 517 245 199 517 minecraft:bone_block
fill 249 198 552 249 200 552 minecraft:purple_concrete
fill 254 198 515 254 202 518 minecraft:bone_block
fill 255 198 510 255 200 510 minecraft:purple_concrete
fill 255 198 515 255 201 515 minecraft:bone_block
fill 257 198 513 257 199 514 minecraft:bone_block
setblock 258 198 514 minecraft:bone_block
setblock 260 198 517 minecraft:bone_block
fill 265 198 552 265 200 552 minecraft:purple_concrete
fill 271 198 510 271 200 510 minecraft:purple_concrete
fill 277 198 520 277 200 520 minecraft:purple_concrete
fill 277 198 536 277 200 536 minecraft:purple_concrete
fill 277 198 541 277 228 541 minecraft:black_concrete
fill 235 199 515 235 251 515 minecraft:black_concrete
fill 245 199 518 246 199 518 minecraft:bone_block
fill 246 199 517 247 200 517 minecraft:bone_block
fill 253 199 515 253 203 518 minecraft:bone_block
fill 256 199 514 256 200 514 minecraft:bone_block
setblock 258 199 513 minecraft:bone_block
setblock 258 199 516 minecraft:bone_block
fill 275 199 552 275 307 552 minecraft:black_concrete
setblock 276 199 552 minecraft:white_concrete
setblock 277 199 534 minecraft:amethyst_block
setblock 277 199 548 minecraft:amethyst_block
fill 277 199 549 277 257 549 minecraft:black_concrete
fill 277 199 552 277 307 552 minecraft:black_concrete
setblock 235 200 513 minecraft:white_concrete
setblock 235 200 533 minecraft:white_concrete
setblock 235 200 542 minecraft:amethyst_block
fill 247 200 518 248 200 518 minecraft:bone_block
fill 248 200 517 249 201 517 minecraft:bone_block
fill 251 200 517 252 205 517 minecraft:bone_block
fill 252 200 516 252 204 516 minecraft:bone_block
fill 252 200 518 252 205 518 minecraft:bone_block
fill 254 200 519 254 201 519 minecraft:bone_block
setblock 255 200 514 minecraft:bone_block
setblock 269 200 510 minecraft:crying_obsidian
fill 276 200 552 276 211 552 minecraft:black_concrete
fill 277 200 534 277 307 534 minecraft:black_concrete
fill 277 200 548 277 236 548 minecraft:black_concrete
fill 235 201 513 235 219 513 minecraft:black_concrete
fill 235 201 518 235 206 518 minecraft:black_concrete
fill 235 201 533 235 206 534 minecraft:black_concrete
fill 235 201 542 235 247 542 minecraft:black_concrete
fill 235 201 550 235 206 550 minecraft:black_concrete
fill 239 201 510 239 206 510 minecraft:black_concrete
setblock 249 201 518 minecraft:bone_block
fill 249 201 552 249 206 552 minecraft:black_concrete
fill 250 201 517 250 207 517 minecraft:bone_block
fill 251 201 516 251 205 516 minecraft:bone_block
fill 251 201 518 251 206 518 minecraft:bone_block
fill 252 201 515 252 203 515 minecraft:bone_block
fill 252 201 519 253 203 519 minecraft:bone_block
fill 255 201 510 255 206 510 minecraft:black_concrete
setblock 257 201 552 minecraft:crying_obsidian
setblock 262 201 552 minecraft:amethyst_block
fill 265 201 552 265 206 552 minecraft:black_concrete
fill 269 201 510 269 248 510 minecraft:black_concrete
fill 271 201 510 271 206 510 minecraft:black_concrete
fill 277 201 520 277 206 520 minecraft:black_concrete
fill 277 201 536 277 206 536 minecraft:black_concrete
fill 249 202 517 249 207 517 minecraft:bone_block
fill 250 202 516 250 205 516 minecraft:bone_block
fill 250 202 518 250 207 519 minecraft:bone_block
setblock 251 202 510 minecraft:crying_obsidian
fill 251 202 515 251 203 515 minecraft:bone_block
fill 251 202 519 251 206 519 minecraft:bone_block
fill 257 202 552 257 251 552 minecraft:black_concrete
fill 262 202 552 262 259 552 minecraft:black_concrete
setblock 235 203 511 minecraft:amethyst_block
setblock 238 203 513 minecraft:light[level=12]
setblock 238 203 521 minecraft:light[level=12]
setblock 238 203 529 minecraft:light[level=12]
setblock 238 203 537 minecraft:light[level=12]
setblock 238 203 545 minecraft:light[level=12]
setblock 246 203 513 minecraft:light[level=12]
setblock 246 203 521 minecraft:light[level=12]
setblock 246 203 529 minecraft:light[level=12]
setblock 246 203 537 minecraft:light[level=12]
setblock 246 203 545 minecraft:light[level=12]
fill 248 203 518 249 208 518 minecraft:bone_block
fill 249 203 519 249 208 519 minecraft:bone_block
fill 251 203 510 251 213 510 minecraft:black_concrete
setblock 254 203 513 minecraft:light[level=12]
fill 254 203 516 254 203 518 minecraft:bone_block
setblock 254 203 521 minecraft:light[level=12]
setblock 254 203 529 minecraft:light[level=12]
setblock 254 203 537 minecraft:light[level=12]
setblock 254 203 545 minecraft:light[level=12]
setblock 262 203 513 minecraft:light[level=12]
setblock 262 203 521 minecraft:light[level=12]
setblock 262 203 529 minecraft:light[level=12]
setblock 262 203 537 minecraft:light[level=12]
setblock 262 203 545 minecraft:light[level=12]
setblock 270 203 513 minecraft:light[level=12]
setblock 270 203 521 minecraft:light[level=12]
setblock 270 203 529 minecraft:light[level=12]
setblock 270 203 537 minecraft:light[level=12]
setblock 270 203 545 minecraft:light[level=12]
fill 235 204 511 235 233 511 minecraft:black_concrete
fill 248 204 517 248 207 517 minecraft:bone_block
fill 248 204 519 248 209 520 minecraft:bone_block
fill 248 204 536 248 205 537 minecraft:amethyst_block
fill 249 204 516 249 206 516 minecraft:bone_block
fill 249 204 520 251 205 520 minecraft:bone_block
fill 252 204 519 252 205 519 minecraft:bone_block
fill 253 204 516 253 204 518 minecraft:bone_block
fill 236 205 528 237 205 528 minecraft:bone_block
setblock 237 205 510 minecraft:amethyst_block
setblock 237 205 529 minecraft:bone_block
fill 247 205 514 248 206 514 minecraft:bone_block
fill 247 205 517 247 208 520 minecraft:bone_block
fill 248 205 513 248 206 513 minecraft:bone_block
setblock 264 205 510 minecraft:crying_obsidian
fill 277 205 532 277 266 532 minecraft:black_concrete
setblock 277 205 533 minecraft:amethyst_block
setblock 235 206 525 minecraft:amethyst_block
setblock 235 206 547 minecraft:amethyst_block
fill 237 206 510 237 220 510 minecraft:black_concrete
fill 237 206 527 238 206 528 minecraft:bone_block
fill 239 206 527 239 207 527 minecraft:bone_block
fill 244 206 518 244 207 519 minecraft:amethyst_block
setblock 245 206 519 minecraft:amethyst_block
fill 246 206 518 246 209 521 minecraft:bone_block
fill 247 206 515 247 207 516 minecraft:bone_block
fill 247 206 521 249 208 521 minecraft:bone_block
setblock 248 206 515 minecraft:bone_block
fill 249 206 520 250 207 520 minecraft:bone_block
setblock 251 206 517 minecraft:bone_block
setblock 263 206 552 minecraft:amethyst_block
fill 264 206 510 264 215 510 minecraft:black_concrete
fill 277 206 533 277 307 533 minecraft:black_concrete
fill 235 207 518 235 209 518 minecraft:purple_concrete
fill 235 207 525 235 307 525 minecraft:black_concrete
fill 235 207 533 235 214 533 minecraft:black_concrete
fill 235 207 534 235 209 534 minecraft:purple_concrete
fill 235 207 547 235 307 547 minecraft:black_concrete
fill 235 207 550 235 209 550 minecraft:purple_concrete
setblock 238 207 527 minecraft:bone_block
fill 239 207 510 239 209 510 minecraft:purple_concrete
fill 239 207 526 240 208 526 minecraft:bone_block
fill 245 207 519 245 210 521 minecraft:bone_block
fill 246 207 516 246 207 517 minecraft:bone_block
fill 246 207 522 247 211 522 minecraft:bone_block
fill 249 207 552 249 209 552 minecraft:purple_concrete
setblock 253 207 552 minecraft:white_concrete
fill 255 207 510 255 209 510 minecraft:purple_concrete
fill 263 207 552 263 218 552 minecraft:black_concrete
fill 265 207 552 265 209 552 minecraft:purple_concrete
fill 271 207 510 271 209 510 minecraft:purple_concrete
setblock 272 207 510 minecraft:white_concrete
fill 277 207 520 277 209 520 minecraft:purple_concrete
fill 277 207 536 277 209 536 minecraft:purple_concrete
fill 240 208 525 241 208 525 minecraft:bone_block
setblock 241 208 526 minecraft:bone_block
fill 244 208 520 244 211 522 minecraft:bone_block
fill 245 208 522 245 213 522 minecraft:bone_block
setblock 246 208 517 minecraft:bone_block
setblock 249 208 520 minecraft:bone_block
fill 253 208 552 253 235 552 minecraft:black_concrete
fill 272 208 510 272 211 510 minecraft:black_concrete
fill 235 209 519 235 250 521 minecraft:black_concrete
setblock 235 209 522 minecraft:white_concrete
setblock 235 209 532 minecraft:crying_obsidian
setblock 238 209 510 minecraft:amethyst_block
fill 241 209 524 242 209 525 minecraft:bone_block
fill 243 209 522 243 213 522 minecraft:bone_block
fill 244 209 523 246 213 523 minecraft:bone_block
fill 247 209 518 247 209 521 minecraft:bone_block
setblock 248 209 518 minecraft:bone_block
fill 248 209 521 248 210 521 minecraft:bone_block
setblock 277 209 516 minecraft:amethyst_block
setblock 277 209 522 minecraft:crying_obsidian
setblock 277 209 538 minecraft:amethyst_block
setblock 235 210 516 minecraft:white_concrete
setblock 235 210 518 minecraft:white_concrete
fill 235 210 522 235 225 522 minecraft:black_concrete
setblock 235 210 526 minecraft:amethyst_block
fill 235 210 532 235 214 532 minecraft:black_concrete
fill 235 210 534 235 224 534 minecraft:black_concrete
setblock 235 210 545 minecraft:crying_obsidian
fill 235 210 550 235 224 550 minecraft:black_concrete
fill 238 210 510 239 224 510 minecraft:black_concrete
fill 242 210 524 245 213 524 minecraft:bone_block
fill 243 210 521 243 212 521 minecraft:bone_block
fill 243 210 523 243 213 523 minecraft:bone_block
fill 246 210 519 247 210 521 minecraft:bone_block
setblock 247 210 523 minecraft:bone_block
setblock 248 210 520 minecraft:bone_block
fill 249 210 552 249 224 552 minecraft:black_concrete
setblock 250 210 552 minecraft:white_concrete
fill 255 210 510 255 224 510 minecraft:black_concrete
fill 265 210 552 265 224 552 minecraft:black_concrete
fill 271 210 510 271 224 510 minecraft:black_concrete
fill 277 210 516 277 307 516 minecraft:black_concrete
setblock 277 210 520 minecraft:amethyst_block
fill 277 210 522 277 240 522 minecraft:black_concrete
fill 277 210 536 277 224 536 minecraft:black_concrete
fill 277 210 538 277 217 538 minecraft:black_concrete
fill 235 211 516 235 307 516 minecraft:black_concrete
fill 235 211 518 235 217 518 minecraft:black_concrete
fill 235 211 526 235 263 526 minecraft:black_concrete
setblock 235 211 538 minecraft:crying_obsidian
fill 235 211 545 235 248 545 minecraft:black_concrete
setblock 238 211 513 minecraft:light[level=12]
setblock 238 211 521 minecraft:light[level=12]
setblock 238 211 529 minecraft:light[level=12]
setblock 238 211 537 minecraft:light[level=12]
setblock 238 211 545 minecraft:light[level=12]
fill 242 211 522 242 213 523 minecraft:bone_block
fill 243 211 525 244 213 525 minecraft:bone_block
fill 245 211 520 247 211 521 minecraft:bone_block
setblock 246 211 513 minecraft:light[level=12]
fill 246 211 524 246 212 524 minecraft:bone_block
setblock 246 211 529 minecraft:light[level=12]
setblock 246 211 537 minecraft:light[level=12]
setblock 246 211 545 minecraft:light[level=12]
fill 250 211 552 250 238 552 minecraft:black_concrete
setblock 254 211 513 minecraft:light[level=12]
setblock 254 211 521 minecraft:light[level=12]
setblock 254 211 529 minecraft:light[level=12]
setblock 254 211 537 minecraft:light[level=12]
setblock 254 211 545 minecraft:light[level=12]
setblock 262 211 513 minecraft:light[level=12]
setblock 262 211 521 minecraft:light[level=12]
setblock 262 211 529 minecraft:light[level=12]
setblock 262 211 537 minecraft:light[level=12]
setblock 262 211 545 minecraft:light[level=12]
setblock 270 211 513 minecraft:light[level=12]
setblock 270 211 521 minecraft:light[level=12]
setblock 270 211 529 minecraft:light[level=12]
setblock 270 211 537 minecraft:light[level=12]
setblock 270 211 545 minecraft:light[level=12]
setblock 277 211 513 minecraft:white_concrete
fill 277 211 520 277 224 520 minecraft:black_concrete
setblock 277 211 546 minecraft:amethyst_block
fill 235 212 538 235 257 538 minecraft:black_concrete
fill 242 212 525 242 213 526 minecraft:bone_block
fill 243 212 526 244 213 526 minecraft:bone_block
fill 244 212 521 244 213 522 minecraft:bone_block
fill 244 212 552 244 277 552 minecraft:black_concrete
fill 245 212 520 245 212 521 minecraft:bone_block
fill 245 212 525 245 213 525 minecraft:bone_block
setblock 245 212 552 minecraft:crying_obsidian
fill 246 212 521 246 212 522 minecraft:bone_block
setblock 272 212 510 minecraft:amethyst_block
setblock 276 212 552 minecraft:white_concrete
fill 277 212 513 277 265 513 minecraft:black_concrete
setblock 277 212 531 minecraft:crying_obsidian
fill 277 212 546 277 223 546 minecraft:black_concrete
setblock 239 213 522 minecraft:bone_block
setblock 239 213 540 minecraft:bone_block
fill 241 213 524 241 213 526 minecraft:bone_block
fill 242 213 527 243 213 527 minecraft:bone_block
setblock 245 213 521 minecraft:bone_block
fill 245 213 552 245 215 552 minecraft:black_concrete
fill 272 213 510 272 307 510 minecraft:black_concrete
fill 276 213 552 276 256 552 minecraft:black_concrete
fill 277 213 531 277 241 531 minecraft:black_concrete
setblock 235 214 527 minecraft:amethyst_block
fill 235 214 528 235 254 529 minecraft:black_concrete
setblock 235 214 530 minecraft:crying_obsidian
setblock 251 214 510 minecraft:crying_obsidian
setblock 277 214 511 minecraft:white_concrete
setblock 235 215 524 minecraft:white_concrete
fill 235 215 527 235 251 527 minecraft:black_concrete
fill 235 215 530 235 244 530 minecraft:black_concrete
setblock 235 215 532 minecraft:white_concrete
setblock 235 215 533 minecraft:amethyst_block
fill 251 215 510 251 218 510 minecraft:black_concrete
setblock 259 215 552 minecraft:white_concrete
setblock 267 215 510 minecraft:crying_obsidian
fill 277 215 511 277 229 511 minecraft:black_concrete
fill 235 216 524 235 291 524 minecraft:black_concrete
fill 235 216 532 235 220 533 minecraft:black_concrete
setblock 236 216 552 minecraft:white_concrete
setblock 245 216 552 minecraft:white_concrete
fill 259 216 552 259 217 552 minecraft:black_concrete
setblock 264 216 510 minecraft:white_concrete
fill 267 216 510 267 300 510 minecraft:black_concrete
fill 236 217 552 236 279 552 minecraft:black_concrete
fill 245 217 552 245 288 552 minecraft:black_concrete
fill 264 217 510 264 257 510 minecraft:black_concrete
setblock 277 217 550 minecraft:crying_obsidian
setblock 235 218 518 minecraft:amethyst_block
setblock 235 218 544 minecraft:amethyst_block
setblock 254 218 552 minecraft:crying_obsidian
setblock 259 218 552 minecraft:amethyst_block
setblock 277 218 538 minecraft:white_concrete
fill 277 218 550 277 307 550 minecraft:black_concrete
fill 235 219 518 235 224 518 minecraft:black_concrete
fill 235 219 536 235 295 536 minecraft:black_concrete
setblock 235 219 537 minecraft:amethyst_block
fill 235 219 544 235 226 544 minecraft:black_concrete
setblock 238 219 513 minecraft:light[level=12]
setblock 238 219 521 minecraft:light[level=12]
setblock 238 219 529 minecraft:light[level=12]
fill 238 219 531 243 220 531 minecraft:black_concrete
setblock 238 219 537 minecraft:light[level=12]
setblock 238 219 545 minecraft:light[level=12]
fill 239 219 526 243 220 530 minecraft:black_concrete
fill 239 219 532 242 220 536 minecraft:black_concrete
fill 240 219 524 240 220 524 minecraft:purple_concrete
fill 240 219 525 256 219 525 minecraft:black_concrete
fill 240 219 537 242 220 538 minecraft:black_concrete
fill 241 219 522 241 220 523 minecraft:purple_concrete
fill 241 219 524 256 220 524 minecraft:black_concrete
fill 241 219 539 242 220 540 minecraft:black_concrete
fill 242 219 521 243 220 522 minecraft:purple_concrete
fill 242 219 523 255 220 523 minecraft:black_concrete
fill 242 219 541 243 220 541 minecraft:black_concrete
fill 243 219 520 258 220 520 minecraft:purple_concrete
fill 243 219 532 246 220 540 minecraft:purple_concrete
fill 243 219 542 243 220 542 minecraft:black_concrete
setblock 243 219 552 minecraft:crying_obsidian
fill 244 219 519 256 220 519 minecraft:purple_concrete
fill 244 219 521 245 220 521 minecraft:purple_concrete
fill 244 219 522 254 220 522 minecraft:black_concrete
fill 244 219 526 244 220 529 minecraft:black_concrete
fill 244 219 530 247 220 531 minecraft:purple_concrete
fill 244 219 541 247 220 542 minecraft:purple_concrete
fill 244 219 543 244 220 543 minecraft:black_concrete
fill 245 219 518 255 220 518 minecraft:purple_concrete
fill 245 219 526 245 220 528 minecraft:black_concrete
fill 245 219 529 251 219 529 minecraft:purple_concrete
fill 245 219 543 249 220 544 minecraft:purple_concrete
setblock 246 219 513 minecraft:light[level=12]
fill 246 219 521 252 220 521 minecraft:black_concrete
fill 246 219 526 247 220 527 minecraft:black_concrete
fill 246 219 528 252 219 528 minecraft:purple_concrete
setblock 246 219 545 minecraft:light[level=12]
fill 247 219 517 252 220 517 minecraft:purple_concrete
fill 247 219 532 250 219 539 minecraft:black_concrete
fill 247 219 540 247 220 540 minecraft:purple_concrete
fill 247 219 545 251 220 545 minecraft:purple_concrete
setblock 247 219 552 minecraft:amethyst_block
fill 248 219 526 257 219 526 minecraft:black_concrete
fill 248 219 527 252 219 527 minecraft:purple_concrete
setblock 248 219 530 minecraft:purple_concrete
fill 248 219 531 250 219 531 minecraft:black_concrete
fill 248 219 540 256 220 541 minecraft:black_concrete
fill 248 219 542 248 220 542 minecraft:purple_concrete
fill 248 219 552 248 307 552 minecraft:black_concrete
fill 249 219 516 259 220 516 minecraft:black_concrete
fill 249 219 530 250 219 530 minecraft:black_concrete
fill 249 219 542 265 220 542 minecraft:black_concrete
fill 249 219 546 254 220 546 minecraft:purple_concrete
fill 250 219 543 264 220 543 minecraft:black_concrete
fill 250 219 544 250 220 544 minecraft:purple_concrete
setblock 251 219 510 minecraft:crying_obsidian
fill 251 219 530 251 219 532 minecraft:amethyst_block
fill 251 219 533 251 219 539 minecraft:black_concrete
fill 251 219 544 263 220 544 minecraft:black_concrete
fill 252 219 529 252 219 530 minecraft:amethyst_block
fill 252 219 532 252 219 533 minecraft:amethyst_block
fill 252 219 534 252 219 536 minecraft:purple_concrete
fill 252 219 537 252 219 539 minecraft:black_concrete
fill 252 219 545 261 220 545 minecraft:black_concrete
fill 253 219 517 261 220 517 minecraft:black_concrete
fill 253 219 521 258 220 521 minecraft:purple_concrete
fill 253 219 527 257 219 527 minecraft:black_concrete
fill 253 219 528 253 219 529 minecraft:amethyst_block
fill 253 219 533 253 219 534 minecraft:amethyst_block
fill 253 219 535 254 219 538 minecraft:purple_concrete
fill 253 219 539 254 220 539 minecraft:black_concrete
setblock 254 219 513 minecraft:light[level=12]
fill 254 219 515 254 220 515 minecraft:black_concrete
fill 254 219 528 255 219 528 minecraft:amethyst_block
fill 254 219 534 255 219 534 minecraft:amethyst_block
fill 254 219 547 254 220 547 minecraft:purple_concrete
fill 254 219 552 254 236 552 minecraft:black_concrete
fill 255 219 522 259 220 522 minecraft:purple_concrete
fill 255 219 529 256 219 529 minecraft:amethyst_block
fill 255 219 533 256 219 533 minecraft:amethyst_block
fill 255 219 535 262 219 535 minecraft:black_concrete
fill 255 219 536 255 219 539 minecraft:purple_concrete
fill 255 219 546 259 220 546 minecraft:black_concrete
fill 256 219 518 263 220 518 minecraft:black_concrete
fill 256 219 523 260 220 523 minecraft:purple_concrete
fill 256 219 528 257 219 528 minecraft:black_concrete
fill 256 219 530 257 219 530 minecraft:amethyst_block
fill 256 219 532 257 219 532 minecraft:amethyst_block
fill 256 219 534 264 219 534 minecraft:black_concrete
fill 256 219 536 261 219 536 minecraft:black_concrete
fill 256 219 537 263 219 539 minecraft:purple_concrete
fill 257 219 519 264 220 519 minecraft:black_concrete
fill 257 219 524 260 220 525 minecraft:purple_concrete
setblock 257 219 529 minecraft:black_concrete
setblock 257 219 531 minecraft:amethyst_block
fill 257 219 533 264 219 533 minecraft:black_concrete
fill 257 219 540 261 220 540 minecraft:purple_concrete
fill 257 219 541 266 220 541 minecraft:black_concrete
fill 258 219 526 259 219 531 minecraft:purple_concrete
fill 258 219 532 265 219 532 minecraft:black_concrete
fill 259 219 520 265 220 521 minecraft:black_concrete
fill 259 219 552 259 239 552 minecraft:black_concrete
fill 260 219 522 266 220 522 minecraft:black_concrete
fill 260 219 526 260 219 529 minecraft:purple_concrete
fill 260 219 530 266 219 531 minecraft:black_concrete
fill 261 219 523 266 220 529 minecraft:black_concrete
setblock 262 219 513 minecraft:light[level=12]
fill 262 219 536 267 220 536 minecraft:purple_concrete
fill 262 219 540 267 220 540 minecraft:black_concrete
setblock 262 219 545 minecraft:light[level=12]
fill 263 219 535 268 220 535 minecraft:purple_concrete
setblock 263 219 552 minecraft:amethyst_block
fill 264 219 537 265 220 538 minecraft:purple_concrete
fill 264 219 539 267 220 539 minecraft:black_concrete
fill 265 219 533 269 220 534 minecraft:purple_concrete
fill 266 219 521 266 220 521 minecraft:black_concrete
fill 266 219 532 269 220 532 minecraft:purple_concrete
fill 266 219 537 266 220 537 minecraft:purple_concrete
fill 266 219 538 268 220 538 minecraft:black_concrete
setblock 266 219 552 minecraft:white_concrete
fill 267 219 522 267 220 523 minecraft:purple_concrete
fill 267 219 524 267 220 527 minecraft:black_concrete
fill 267 219 528 269 220 531 minecraft:purple_concrete
fill 267 219 537 268 220 537 minecraft:black_concrete
fill 267 219 552 268 224 552 minecraft:black_concrete
fill 268 219 524 268 220 527 minecraft:purple_concrete
fill 268 219 536 269 220 536 minecraft:black_concrete
fill 269 219 526 269 220 527 minecraft:purple_concrete
fill 269 219 535 269 220 535 minecraft:black_concrete
setblock 270 219 513 minecraft:light[level=12]
setblock 270 219 521 minecraft:light[level=12]
setblock 270 219 529 minecraft:light[level=12]
fill 270 219 531 270 220 531 minecraft:purple_concrete
setblock 270 219 537 minecraft:light[level=12]
setblock 270 219 545 minecraft:light[level=12]
fill 277 219 538 277 236 538 minecraft:black_concrete
setblock 235 220 513 minecraft:amethyst_block
fill 235 220 537 239 220 537 minecraft:black_concrete
fill 236 220 511 237 220 536 minecraft:black_concrete
fill 236 220 538 239 220 551 minecraft:black_concrete
fill 238 220 511 238 220 530 minecraft:black_concrete
fill 238 220 532 238 220 536 minecraft:black_concrete
fill 239 220 511 239 220 525 minecraft:black_concrete
fill 240 220 511 240 220 523 minecraft:black_concrete
fill 240 220 525 251 220 525 minecraft:black_concrete
fill 240 220 539 240 220 551 minecraft:black_concrete
fill 241 220 511 241 220 521 minecraft:black_concrete
fill 241 220 541 241 220 551 minecraft:black_concrete
fill 242 220 511 242 220 520 minecraft:black_concrete
fill 242 220 542 242 220 551 minecraft:black_concrete
fill 243 220 511 243 220 519 minecraft:black_concrete
fill 243 220 543 243 220 552 minecraft:black_concrete
fill 244 220 511 244 220 518 minecraft:black_concrete
fill 244 220 544 244 220 551 minecraft:black_concrete
fill 245 220 511 246 220 517 minecraft:black_concrete
fill 245 220 529 247 220 529 minecraft:purple_concrete
fill 245 220 545 246 220 551 minecraft:black_concrete
fill 246 220 528 248 220 528 minecraft:purple_concrete
fill 247 220 511 248 220 516 minecraft:black_concrete
fill 247 220 532 247 220 539 minecraft:black_concrete
fill 247 220 546 247 220 552 minecraft:black_concrete
fill 248 220 526 249 220 526 minecraft:black_concrete
setblock 248 220 527 minecraft:purple_concrete
fill 248 220 529 251 220 533 minecraft:mossy_stone_bricks
fill 248 220 534 248 220 539 minecraft:black_concrete
fill 248 220 546 248 220 551 minecraft:black_concrete
fill 249 220 511 253 220 515 minecraft:black_concrete
fill 249 220 527 259 220 528 minecraft:mossy_stone_bricks
fill 249 220 534 259 220 535 minecraft:mossy_stone_bricks
fill 249 220 536 249 220 539 minecraft:black_concrete
fill 249 220 547 253 220 551 minecraft:black_concrete
fill 250 220 526 258 220 526 minecraft:mossy_stone_bricks
fill 250 220 536 258 220 536 minecraft:mossy_stone_bricks
fill 250 220 537 251 220 539 minecraft:black_concrete
fill 251 220 510 251 224 510 minecraft:black_concrete
fill 252 220 525 256 220 525 minecraft:mossy_stone_bricks
fill 252 220 529 252 220 530 minecraft:mossy_stone_bricks
fill 252 220 532 252 220 533 minecraft:mossy_stone_bricks
fill 252 220 537 256 220 537 minecraft:mossy_stone_bricks
fill 252 220 538 252 220 539 minecraft:black_concrete
setblock 253 220 529 minecraft:mossy_stone_bricks
setblock 253 220 533 minecraft:mossy_stone_bricks
fill 253 220 538 263 220 538 minecraft:purple_concrete
fill 254 220 511 276 220 514 minecraft:black_concrete
fill 254 220 548 276 220 551 minecraft:black_concrete
fill 255 220 515 276 220 515 minecraft:black_concrete
fill 255 220 529 260 220 529 minecraft:mossy_stone_bricks
fill 255 220 533 260 220 533 minecraft:mossy_stone_bricks
fill 255 220 539 263 220 539 minecraft:purple_concrete
fill 255 220 547 276 220 547 minecraft:black_concrete
fill 256 220 530 260 220 530 minecraft:mossy_stone_bricks
fill 256 220 532 260 220 532 minecraft:mossy_stone_bricks
fill 257 220 531 260 220 531 minecraft:mossy_stone_bricks
fill 257 220 537 263 220 537 minecraft:purple_concrete
fill 259 220 526 260 220 526 minecraft:purple_concrete
fill 259 220 536 261 220 536 minecraft:black_concrete
fill 260 220 516 276 220 516 minecraft:black_concrete
fill 260 220 527 260 220 528 minecraft:purple_concrete
fill 260 220 534 262 220 535 minecraft:black_concrete
fill 260 220 546 276 220 546 minecraft:black_concrete
fill 261 220 530 264 220 533 minecraft:black_concrete
fill 262 220 517 276 220 517 minecraft:black_concrete
fill 262 220 545 276 220 545 minecraft:black_concrete
fill 263 220 534 264 220 534 minecraft:black_concrete
fill 263 220 552 263 236 552 minecraft:black_concrete
fill 264 220 518 276 220 518 minecraft:black_concrete
fill 264 220 544 276 220 544 minecraft:black_concrete
fill 265 220 519 276 220 519 minecraft:black_concrete
fill 265 220 530 265 220 532 minecraft:black_concrete
fill 265 220 543 276 220 543 minecraft:black_concrete
fill 266 220 520 276 220 520 minecraft:black_concrete
fill 266 220 530 266 220 531 minecraft:black_concrete
fill 266 220 542 276 220 542 minecraft:black_concrete
fill 266 220 552 266 307 552 minecraft:black_concrete
fill 267 220 521 276 220 521 minecraft:black_concrete
fill 267 220 541 276 220 541 minecraft:black_concrete
fill 268 220 522 276 220 523 minecraft:black_concrete
fill 268 220 539 276 220 540 minecraft:black_concrete
fill 269 220 524 276 220 525 minecraft:black_concrete
fill 269 220 537 276 220 538 minecraft:black_concrete
fill 270 220 526 276 220 530 minecraft:black_concrete
fill 270 220 532 276 220 536 minecraft:black_concrete
fill 271 220 531 276 220 531 minecraft:black_concrete
fill 235 221 513 235 246 513 minecraft:black_concrete
fill 235 221 532 235 240 532 minecraft:black_concrete
setblock 235 221 533 minecraft:white_concrete
fill 235 221 537 235 300 537 minecraft:black_concrete
setblock 237 221 510 minecraft:amethyst_block
setblock 239 221 552 minecraft:crying_obsidian
fill 240 221 552 240 245 552 minecraft:black_concrete
fill 243 221 552 243 277 552 minecraft:black_concrete
fill 246 221 529 247 230 533 minecraft:stone_bricks
fill 247 221 524 249 233 527 minecraft:cobblestone
fill 247 221 528 248 230 528 minecraft:stone_bricks
fill 247 221 534 248 231 534 minecraft:stone_bricks
fill 247 221 535 249 233 538 minecraft:cobblestone
fill 247 221 552 247 293 552 minecraft:black_concrete
fill 250 221 524 250 233 526 minecraft:cobblestone
fill 250 221 536 250 233 538 minecraft:cobblestone
fill 251 221 524 251 230 525 minecraft:stone_bricks
fill 251 221 537 251 230 538 minecraft:stone_bricks
fill 252 221 523 256 230 524 minecraft:stone_bricks
fill 252 221 538 256 230 539 minecraft:stone_bricks
fill 257 221 524 257 230 525 minecraft:stone_bricks
fill 257 221 537 257 231 538 minecraft:stone_bricks
fill 258 221 524 261 233 526 minecraft:cobblestone
fill 258 221 536 261 233 538 minecraft:cobblestone
fill 259 221 527 261 233 527 minecraft:cobblestone
fill 259 221 535 261 233 535 minecraft:cobblestone
fill 260 221 528 261 231 528 minecraft:stone_bricks
fill 260 221 534 261 230 534 minecraft:stone_bricks
fill 261 221 529 262 230 533 minecraft:stone_bricks
fill 235 222 533 235 307 533 minecraft:black_concrete
fill 237 222 510 237 258 510 minecraft:black_concrete
fill 239 222 552 239 247 552 minecraft:black_concrete
fill 238 224 534 238 224 535 minecraft:bone_block
fill 239 224 535 244 224 536 minecraft:bone_block
fill 240 224 534 244 224 534 minecraft:bone_block
fill 241 224 533 243 224 533 minecraft:bone_block
fill 241 224 537 244 227 537 minecraft:bone_block
setblock 242 224 532 minecraft:bone_block
fill 242 224 538 244 228 538 minecraft:bone_block
fill 246 224 545 247 224 546 minecraft:bone_block
setblock 247 224 547 minecraft:bone_block
setblock 268 224 510 minecraft:white_concrete
setblock 277 224 537 minecraft:amethyst_block
setblock 277 224 539 minecraft:amethyst_block
setblock 277 224 546 minecraft:amethyst_block
fill 235 225 518 235 227 518 minecraft:purple_concrete
fill 235 225 534 235 227 534 minecraft:purple_concrete
setblock 235 225 541 minecraft:amethyst_block
fill 235 225 550 235 227 550 minecraft:purple_concrete
fill 238 225 510 238 268 510 minecraft:black_concrete
fill 239 225 510 239 227 510 minecraft:purple_concrete
fill 239 225 535 239 225 536 minecraft:bone_block
fill 240 225 536 240 225 537 minecraft:bone_block
fill 241 225 534 243 225 536 minecraft:bone_block
fill 241 225 538 241 227 538 minecraft:bone_block
setblock 242 225 533 minecraft:bone_block
fill 242 225 539 244 229 539 minecraft:bone_block
setblock 244 225 510 minecraft:crying_obsidian
fill 244 225 535 244 226 536 minecraft:bone_block
fill 245 225 537 245 228 538 minecraft:bone_block
fill 246 225 543 246 225 545 minecraft:bone_block
setblock 247 225 545 minecraft:bone_block
fill 249 225 552 249 227 552 minecraft:purple_concrete
setblock 251 225 510 minecraft:white_concrete
fill 255 225 510 255 227 510 minecraft:purple_concrete
fill 259 225 510 260 259 510 minecraft:black_concrete
setblock 261 225 510 minecraft:crying_obsidian
fill 262 225 510 262 307 510 minecraft:black_concrete
fill 265 225 552 265 227 552 minecraft:purple_concrete
fill 267 225 552 267 242 552 minecraft:black_concrete
fill 268 225 510 268 307 510 minecraft:black_concrete
setblock 268 225 552 minecraft:white_concrete
fill 271 225 510 271 227 510 minecraft:purple_concrete
fill 277 225 517 277 233 517 minecraft:black_concrete
setblock 277 225 518 minecraft:amethyst_block
fill 277 225 520 277 227 520 minecraft:purple_concrete
fill 277 225 536 277 227 536 minecraft:purple_concrete
fill 277 225 537 277 256 537 minecraft:black_concrete
fill 277 225 539 277 255 539 minecraft:black_concrete
fill 277 225 546 277 241 546 minecraft:black_concrete
setblock 235 226 522 minecraft:amethyst_block
fill 235 226 541 235 307 541 minecraft:black_concrete
fill 240 226 534 240 227 535 minecraft:obsidian
fill 241 226 533 241 227 534 minecraft:obsidian
fill 241 226 535 243 226 536 minecraft:bone_block
setblock 242 226 534 minecraft:bone_block
fill 243 226 540 245 230 540 minecraft:bone_block
fill 244 226 510 244 242 510 minecraft:black_concrete
setblock 245 226 536 minecraft:bone_block
fill 245 226 539 245 231 539 minecraft:bone_block
fill 245 226 542 246 226 543 minecraft:bone_block
setblock 246 226 544 minecraft:bone_block
fill 251 226 510 251 258 510 minecraft:black_concrete
fill 261 226 510 261 307 510 minecraft:black_concrete
fill 268 226 552 268 251 552 minecraft:black_concrete
fill 277 226 518 277 229 518 minecraft:black_concrete
fill 235 227 522 235 246 522 minecraft:black_concrete
setblock 235 227 544 minecraft:amethyst_block
setblock 238 227 513 minecraft:light[level=12]
setblock 238 227 521 minecraft:light[level=12]
setblock 238 227 529 minecraft:light[level=12]
setblock 238 227 537 minecraft:light[level=12]
setblock 238 227 545 minecraft:light[level=12]
setblock 241 227 535 minecraft:obsidian
setblock 242 227 534 minecraft:obsidian
fill 242 227 536 244 227 536 minecraft:bone_block
fill 242 227 540 242 229 540 minecraft:bone_block
setblock 243 227 535 minecraft:bone_block
fill 243 227 541 245 230 541 minecraft:bone_block
fill 245 227 542 245 233 542 minecraft:bone_block
setblock 246 227 513 minecraft:light[level=12]
setblock 246 227 521 minecraft:light[level=12]
setblock 246 227 537 minecraft:light[level=12]
fill 246 227 538 246 229 540 minecraft:bone_block
setblock 246 227 545 minecraft:light[level=12]
setblock 254 227 513 minecraft:light[level=12]
setblock 254 227 521 minecraft:light[level=12]
setblock 254 227 529 minecraft:light[level=12]
setblock 254 227 537 minecraft:light[level=12]
setblock 254 227 545 minecraft:light[level=12]
setblock 262 227 513 minecraft:light[level=12]
setblock 262 227 521 minecraft:light[level=12]
setblock 262 227 537 minecraft:light[level=12]
setblock 262 227 545 minecraft:light[level=12]
setblock 270 227 513 minecraft:light[level=12]
setblock 270 227 521 minecraft:light[level=12]
setblock 270 227 529 minecraft:light[level=12]
setblock 270 227 537 minecraft:light[level=12]
setblock 270 227 545 minecraft:light[level=12]
fill 235 228 518 235 233 518 minecraft:black_concrete
fill 235 228 534 235 233 534 minecraft:black_concrete
fill 235 228 544 235 307 544 minecraft:black_concrete
fill 235 228 550 235 233 550 minecraft:black_concrete
fill 239 228 510 239 233 510 minecraft:black_concrete
fill 242 228 537 244 228 537 minecraft:bone_block
setblock 243 228 536 minecraft:bone_block
fill 244 228 542 244 232 542 minecraft:bone_block
fill 246 228 541 246 233 542 minecraft:bone_block
fill 249 228 552 249 233 552 minecraft:black_concrete
fill 255 228 510 255 233 510 minecraft:black_concrete
fill 265 228 552 265 233 552 minecraft:black_concrete
fill 271 228 510 271 233 510 minecraft:black_concrete
setblock 277 228 519 minecraft:amethyst_block
fill 277 228 520 277 233 520 minecraft:black_concrete
fill 277 228 536 277 233 536 minecraft:black_concrete
setblock 238 229 552 minecraft:amethyst_block
fill 243 229 537 244 229 538 minecraft:bone_block
fill 245 229 538 245 230 538 minecraft:bone_block
fill 246 229 543 246 234 543 minecraft:bone_block
fill 247 229 540 247 232 542 minecraft:bone_block
setblock 277 229 515 minecraft:crying_obsidian
fill 277 229 519 277 307 519 minecraft:black_concrete
setblock 277 229 541 minecraft:amethyst_block
fill 238 230 552 238 307 552 minecraft:black_concrete
fill 243 230 539 244 230 539 minecraft:bone_block
setblock 244 230 538 minecraft:bone_block
fill 245 230 543 245 233 543 minecraft:bone_block
fill 246 230 539 246 231 540 minecraft:bone_block
setblock 247 230 539 minecraft:bone_block
fill 247 230 543 248 235 543 minecraft:bone_block
fill 248 230 541 248 234 542 minecraft:bone_block
setblock 252 230 510 minecraft:amethyst_block
fill 268 230 542 269 231 542 minecraft:amethyst_block
fill 269 230 543 269 231 543 minecraft:amethyst_block
setblock 277 230 511 minecraft:crying_obsidian
fill 277 230 515 277 296 515 minecraft:black_concrete
setblock 277 230 518 minecraft:crying_obsidian
fill 277 230 541 277 253 541 minecraft:black_concrete
fill 241 231 544 243 231 544 minecraft:bone_block
fill 242 231 545 243 231 545 minecraft:bone_block
fill 244 231 539 244 231 541 minecraft:bone_block
fill 245 231 540 245 232 541 minecraft:bone_block
fill 246 231 529 247 231 529 minecraft:stone_bricks
fill 246 231 531 246 231 532 minecraft:stone_bricks
fill 246 231 544 248 234 544 minecraft:bone_block
fill 247 231 530 247 231 531 minecraft:stone_bricks
fill 249 231 542 249 236 543 minecraft:bone_block
fill 251 231 524 252 231 524 minecraft:stone_bricks
setblock 251 231 537 minecraft:stone_bricks
fill 252 231 510 252 307 510 minecraft:black_concrete
fill 252 231 520 253 232 521 minecraft:amethyst_block
setblock 252 231 523 minecraft:stone_bricks
fill 253 231 538 254 231 539 minecraft:stone_bricks
fill 255 231 523 256 231 524 minecraft:stone_bricks
fill 258 231 549 259 232 549 minecraft:bone_block
fill 259 231 550 260 231 550 minecraft:bone_block
setblock 261 231 529 minecraft:stone_bricks
fill 261 231 531 262 231 532 minecraft:stone_bricks
setblock 262 231 533 minecraft:stone_bricks
fill 277 231 511 277 252 511 minecraft:black_concrete
fill 277 231 518 277 292 518 minecraft:black_concrete
setblock 235 232 535 minecraft:crying_obsidian
setblock 241 232 510 minecraft:white_concrete
fill 243 232 544 244 232 545 minecraft:bone_block
setblock 244 232 541 minecraft:bone_block
fill 245 232 544 245 233 544 minecraft:bone_block
setblock 246 232 540 minecraft:bone_block
fill 248 232 545 248 236 545 minecraft:bone_block
fill 249 232 541 249 234 541 minecraft:bone_block
fill 249 232 544 249 237 544 minecraft:bone_block
setblock 250 232 510 minecraft:crying_obsidian
fill 250 232 543 250 237 543 minecraft:bone_block
fill 257 232 548 257 233 549 minecraft:bone_block
fill 258 232 550 259 232 550 minecraft:bone_block
fill 235 233 535 235 239 535 minecraft:black_concrete
setblock 235 233 540 minecraft:white_concrete
fill 241 233 510 241 273 510 minecraft:black_concrete
fill 244 233 530 244 234 530 minecraft:amethyst_block
fill 244 233 544 244 233 545 minecraft:bone_block
setblock 245 233 541 minecraft:bone_block
fill 245 233 545 247 233 545 minecraft:bone_block
fill 247 233 541 247 234 542 minecraft:bone_block
fill 249 233 545 250 237 545 minecraft:bone_block
fill 250 233 510 250 257 510 minecraft:black_concrete
fill 250 233 542 250 236 542 minecraft:bone_block
fill 250 233 544 251 238 544 minecraft:bone_block
setblock 255 233 552 minecraft:amethyst_block
fill 256 233 548 256 234 548 minecraft:bone_block
setblock 258 233 549 minecraft:bone_block
setblock 235 234 511 minecraft:amethyst_block
fill 235 234 518 235 236 518 minecraft:purple_concrete
fill 235 234 534 235 236 534 minecraft:purple_concrete
fill 235 234 540 235 241 540 minecraft:black_concrete
fill 235 234 550 235 236 550 minecraft:purple_concrete
fill 239 234 510 239 236 510 minecraft:purple_concrete
fill 246 234 525 250 234 526 minecraft:dark_oak_planks
fill 246 234 536 250 234 537 minecraft:dark_oak_planks
setblock 246 234 542 minecraft:bone_block
fill 246 234 545 247 234 545 minecraft:bone_block
fill 247 234 524 250 234 524 minecraft:dark_oak_planks
fill 247 234 527 250 234 527 minecraft:dark_oak_planks
fill 247 234 535 250 234 535 minecraft:dark_oak_planks
fill 247 234 538 250 234 538 minecraft:dark_oak_planks
fill 248 234 523 249 234 523 minecraft:dark_oak_planks
fill 248 234 539 249 234 539 minecraft:dark_oak_planks
fill 249 234 546 250 236 546 minecraft:bone_block
fill 249 234 552 249 236 552 minecraft:purple_concrete
fill 251 234 543 251 238 543 minecraft:bone_block
fill 251 234 545 251 239 545 minecraft:bone_block
fill 252 234 544 252 240 544 minecraft:bone_block
fill 254 234 547 256 234 547 minecraft:bone_block
fill 255 234 510 255 236 510 minecraft:purple_concrete
setblock 255 234 548 minecraft:bone_block
fill 255 234 552 255 246 552 minecraft:black_concrete
fill 258 234 524 261 234 527 minecraft:dark_oak_planks
fill 258 234 535 261 234 538 minecraft:dark_oak_planks
fill 259 234 523 260 234 523 minecraft:dark_oak_planks
fill 259 234 539 260 234 539 minecraft:dark_oak_planks
fill 262 234 525 262 234 526 minecraft:dark_oak_planks
fill 262 234 536 262 234 537 minecraft:dark_oak_planks
fill 265 234 552 265 236 552 minecraft:purple_concrete
fill 271 234 510 271 236 510 minecraft:purple_concrete
setblock 277 234 517 minecraft:crying_obsidian
fill 277 234 520 277 236 520 minecraft:purple_concrete
fill 277 234 536 277 236 536 minecraft:purple_concrete
fill 235 235 511 235 278 511 minecraft:black_concrete
setblock 238 235 513 minecraft:light[level=12]
setblock 238 235 521 minecraft:light[level=12]
setblock 238 235 529 minecraft:light[level=12]
setblock 238 235 537 minecraft:light[level=12]
setblock 238 235 545 minecraft:light[level=12]
setblock 246 235 513 minecraft:light[level=12]
setblock 246 235 521 minecraft:light[level=12]
setblock 246 235 529 minecraft:light[level=12]
setblock 246 235 537 minecraft:light[level=12]
setblock 246 235 545 minecraft:light[level=12]
fill 247 235 524 249 235 526 minecraft:dark_oak_planks
fill 247 235 536 249 235 538 minecraft:dark_oak_planks
fill 247 235 542 248 235 542 minecraft:bone_block
fill 247 235 544 247 235 545 minecraft:bone_block
fill 248 235 527 249 235 527 minecraft:dark_oak_planks
fill 248 235 535 249 235 535 minecraft:dark_oak_planks
fill 248 235 544 248 236 544 minecraft:bone_block
fill 250 235 525 250 235 526 minecraft:dark_oak_planks
fill 250 235 536 250 235 537 minecraft:dark_oak_planks
fill 251 235 542 251 236 542 minecraft:bone_block
fill 251 235 546 254 239 546 minecraft:bone_block
fill 252 235 543 252 239 543 minecraft:bone_block
fill 252 235 545 252 240 545 minecraft:bone_block
setblock 254 235 513 minecraft:light[level=12]
setblock 254 235 521 minecraft:light[level=12]
setblock 254 235 529 minecraft:light[level=12]
setblock 254 235 537 minecraft:light[level=12]
setblock 254 235 545 minecraft:light[level=12]
fill 254 235 547 255 235 547 minecraft:bone_block
fill 256 235 514 257 236 514 minecraft:amethyst_block
fill 257 235 513 257 236 513 minecraft:amethyst_block
fill 257 235 515 257 236 515 minecraft:amethyst_block
fill 258 235 525 261 235 526 minecraft:dark_oak_planks
fill 258 235 536 261 235 537 minecraft:dark_oak_planks
fill 259 235 524 261 235 524 minecraft:dark_oak_planks
fill 259 235 527 260 235 527 minecraft:dark_oak_planks
fill 259 235 535 260 235 535 minecraft:dark_oak_planks
fill 259 235 538 261 235 538 minecraft:dark_oak_planks
setblock 262 235 513 minecraft:light[level=12]
setblock 262 235 521 minecraft:light[level=12]
setblock 262 235 529 minecraft:light[level=12]
setblock 262 235 537 minecraft:light[level=12]
setblock 262 235 545 minecraft:light[level=12]
setblock 270 235 513 minecraft:light[level=12]
setblock 270 235 521 minecraft:light[level=12]
setblock 270 235 529 minecraft:light[level=12]
setblock 270 235 537 minecraft:light[level=12]
setblock 270 235 545 minecraft:light[level=12]
setblock 277 235 514 minecraft:white_concrete
fill 277 235 517 277 257 517 minecraft:black_concrete
fill 247 236 525 249 236 526 minecraft:dark_oak_planks
fill 247 236 536 249 236 537 minecraft:dark_oak_planks
fill 248 236 524 249 236 524 minecraft:dark_oak_planks
fill 248 236 538 249 236 538 minecraft:dark_oak_planks
setblock 248 236 543 minecraft:bone_block
fill 251 236 552 251 254 552 minecraft:black_concrete
setblock 252 236 552 minecraft:crying_obsidian
fill 253 236 544 253 241 545 minecraft:bone_block
setblock 253 236 552 minecraft:white_concrete
fill 254 236 545 254 242 545 minecraft:bone_block
fill 259 236 524 260 236 526 minecraft:dark_oak_planks
fill 259 236 536 260 236 538 minecraft:dark_oak_planks
fill 261 236 525 261 236 526 minecraft:dark_oak_planks
fill 261 236 536 261 236 537 minecraft:dark_oak_planks
setblock 263 236 510 minecraft:crying_obsidian
fill 277 236 514 277 258 514 minecraft:black_concrete
setblock 277 236 542 minecraft:amethyst_block
fill 235 237 518 235 242 518 minecraft:black_concrete
fill 235 237 534 235 242 534 minecraft:black_concrete
fill 235 237 550 235 242 550 minecraft:black_concrete
fill 239 237 510 239 242 510 minecraft:black_concrete
fill 248 237 525 249 237 526 minecraft:dark_oak_planks
fill 248 237 536 249 237 537 minecraft:dark_oak_planks
setblock 249 237 543 minecraft:bone_block
fill 249 237 552 249 242 552 minecraft:black_concrete
fill 250 237 546 250 238 546 minecraft:bone_block
fill 251 237 547 253 237 547 minecraft:bone_block
fill 252 237 552 253 262 552 minecraft:black_concrete
fill 253 237 543 253 239 543 minecraft:bone_block
fill 254 237 544 254 241 544 minecraft:bone_block
setblock 254 237 552 minecraft:crying_obsidian
fill 255 237 510 255 242 510 minecraft:black_concrete
fill 255 237 545 255 243 545 minecraft:bone_block
setblock 258 237 552 minecraft:amethyst_block
fill 259 237 525 260 237 526 minecraft:dark_oak_planks
fill 259 237 536 260 237 537 minecraft:dark_oak_planks
fill 263 237 510 263 250 510 minecraft:black_concrete
setblock 263 237 552 minecraft:amethyst_block
fill 265 237 552 265 242 552 minecraft:black_concrete
fill 271 237 510 271 242 510 minecraft:black_concrete
fill 277 237 520 277 242 520 minecraft:black_concrete
fill 277 237 536 277 242 536 minecraft:black_concrete
setblock 277 237 538 minecraft:crying_obsidian
fill 277 237 542 277 307 542 minecraft:black_concrete
setblock 277 237 548 minecraft:crying_obsidian
setblock 248 238 525 minecraft:dark_oak_planks
setblock 248 238 537 minecraft:dark_oak_planks
setblock 250 238 545 minecraft:bone_block
fill 252 238 547 255 239 547 minecraft:bone_block
fill 254 238 543 254 239 543 minecraft:bone_block
fill 254 238 552 254 257 552 minecraft:black_concrete
fill 255 238 544 255 242 544 minecraft:bone_block
fill 255 238 546 256 243 546 minecraft:bone_block
fill 256 238 545 256 244 545 minecraft:bone_block
fill 258 238 552 258 258 552 minecraft:black_concrete
setblock 260 238 525 minecraft:dark_oak_planks
setblock 260 238 537 minecraft:dark_oak_planks
fill 263 238 552 263 280 552 minecraft:black_concrete
setblock 273 238 510 minecraft:amethyst_block
fill 277 238 538 277 255 538 minecraft:black_concrete
fill 277 238 548 277 269 548 minecraft:black_concrete
setblock 250 239 552 minecraft:crying_obsidian
setblock 251 239 544 minecraft:bone_block
fill 252 239 550 253 240 550 minecraft:bone_block
fill 256 239 544 256 243 544 minecraft:bone_block
fill 256 239 547 256 243 547 minecraft:bone_block
fill 257 239 545 257 245 546 minecraft:bone_block
fill 270 239 544 270 240 545 minecraft:bone_block
setblock 273 239 510 minecraft:black_concrete
setblock 277 239 544 minecraft:amethyst_block
setblock 235 240 535 minecraft:amethyst_block
fill 250 240 552 250 307 552 minecraft:black_concrete
fill 252 240 546 254 240 546 minecraft:bone_block
fill 253 240 547 255 240 547 minecraft:bone_block
fill 253 240 549 254 240 549 minecraft:bone_block
setblock 254 240 550 minecraft:bone_block
fill 257 240 544 257 244 544 minecraft:bone_block
fill 257 240 547 257 244 547 minecraft:bone_block
fill 258 240 545 258 246 546 minecraft:bone_block
setblock 259 240 552 minecraft:amethyst_block
fill 268 240 544 269 240 545 minecraft:bone_block
setblock 273 240 510 minecraft:amethyst_block
setblock 277 240 524 minecraft:amethyst_block
fill 277 240 544 277 267 544 minecraft:black_concrete
setblock 235 241 532 minecraft:white_concrete
fill 235 241 535 235 301 535 minecraft:black_concrete
fill 253 241 546 254 241 546 minecraft:bone_block
fill 254 241 547 255 241 549 minecraft:bone_block
fill 256 241 548 256 243 548 minecraft:bone_block
fill 258 241 544 258 246 544 minecraft:bone_block
fill 258 241 547 258 245 547 minecraft:bone_block
fill 259 241 545 259 246 546 minecraft:bone_block
fill 259 241 552 260 261 552 minecraft:black_concrete
setblock 261 241 552 minecraft:white_concrete
fill 267 241 544 268 241 545 minecraft:bone_block
fill 273 241 510 273 307 510 minecraft:black_concrete
setblock 277 241 512 minecraft:crying_obsidian
setblock 277 241 522 minecraft:white_concrete
fill 277 241 524 277 254 524 minecraft:black_concrete
fill 235 242 532 235 307 532 minecraft:black_concrete
setblock 235 242 540 minecraft:crying_obsidian
setblock 237 242 552 minecraft:amethyst_block
setblock 254 242 546 minecraft:bone_block
fill 255 242 547 255 242 549 minecraft:bone_block
fill 257 242 510 257 243 510 minecraft:white_concrete
fill 259 242 544 259 247 544 minecraft:bone_block
fill 259 242 547 259 245 547 minecraft:bone_block
fill 260 242 545 260 247 546 minecraft:bone_block
fill 261 242 552 261 253 552 minecraft:black_concrete
fill 265 242 544 267 242 545 minecraft:bone_block
fill 277 242 512 277 289 512 minecraft:black_concrete
fill 277 242 522 277 307 522 minecraft:black_concrete
setblock 277 242 529 minecraft:amethyst_block
setblock 277 242 531 minecraft:amethyst_block
setblock 277 242 546 minecraft:amethyst_block
fill 235 243 518 235 245 518 minecraft:purple_concrete
fill 235 243 534 235 245 534 minecraft:purple_concrete
fill 235 243 540 235 307 540 minecraft:black_concrete
fill 235 243 550 235 245 550 minecraft:purple_concrete
fill 237 243 552 237 261 552 minecraft:black_concrete
setblock 238 243 513 minecraft:light[level=12]
setblock 238 243 521 minecraft:light[level=12]
setblock 238 243 529 minecraft:light[level=12]
setblock 238 243 537 minecraft:light[level=12]
setblock 238 243 545 minecraft:light[level=12]
fill 239 243 510 239 245 510 minecraft:purple_concrete
setblock 244 243 510 minecraft:amethyst_block
setblock 246 243 513 minecraft:light[level=12]
setblock 246 243 521 minecraft:light[level=12]
setblock 246 243 529 minecraft:light[level=12]
setblock 246 243 537 minecraft:light[level=12]
setblock 246 243 545 minecraft:light[level=12]
fill 249 243 552 249 245 552 minecraft:purple_concrete
setblock 254 243 513 minecraft:light[level=12]
setblock 254 243 521 minecraft:light[level=12]
setblock 254 243 529 minecraft:light[level=12]
setblock 254 243 537 minecraft:light[level=12]
setblock 254 243 545 minecraft:light[level=12]
fill 255 243 510 255 245 510 minecraft:purple_concrete
setblock 257 243 548 minecraft:bone_block
fill 258 243 543 259 244 543 minecraft:bone_block
fill 260 243 544 261 248 544 minecraft:bone_block
fill 260 243 547 260 246 547 minecraft:bone_block
fill 261 243 540 261 244 540 minecraft:amethyst_block
fill 261 243 545 261 248 546 minecraft:bone_block
setblock 262 243 513 minecraft:light[level=12]
setblock 262 243 521 minecraft:light[level=12]
setblock 262 243 529 minecraft:light[level=12]
setblock 262 243 537 minecraft:light[level=12]
setblock 262 243 545 minecraft:light[level=12]
fill 263 243 545 265 243 545 minecraft:bone_block
fill 264 243 544 265 243 544 minecraft:bone_block
fill 265 243 552 265 245 552 minecraft:purple_concrete
setblock 267 243 552 minecraft:white_concrete
fill 268 243 524 269 244 525 minecraft:white_concrete
setblock 270 243 513 minecraft:light[level=12]
setblock 270 243 521 minecraft:light[level=12]
setblock 270 243 529 minecraft:light[level=12]
setblock 270 243 537 minecraft:light[level=12]
setblock 270 243 545 minecraft:light[level=12]
fill 271 243 510 271 245 510 minecraft:purple_concrete
fill 275 243 513 275 246 513 minecraft:amethyst_block
fill 277 243 520 277 245 520 minecraft:purple_concrete
fill 277 243 529 277 244 529 minecraft:black_concrete
fill 277 243 531 277 264 531 minecraft:black_concrete
fill 277 243 536 277 245 536 minecraft:purple_concrete
fill 277 243 546 277 259 546 minecraft:black_concrete
fill 244 244 510 244 258 510 minecraft:black_concrete
setblock 256 244 546 minecraft:bone_block
fill 257 244 510 257 250 510 minecraft:black_concrete
fill 260 244 543 261 247 543 minecraft:bone_block
fill 262 244 544 263 249 545 minecraft:bone_block
setblock 264 244 545 minecraft:bone_block
fill 267 244 552 267 307 552 minecraft:black_concrete
fill 273 244 513 274 246 513 minecraft:amethyst_block
fill 274 244 512 276 245 512 minecraft:amethyst_block
fill 274 244 514 276 245 514 minecraft:amethyst_block
fill 276 244 513 276 245 513 minecraft:amethyst_block
setblock 235 245 530 minecraft:amethyst_block
setblock 235 245 543 minecraft:crying_obsidian
fill 259 245 543 259 246 543 minecraft:bone_block
fill 261 245 547 261 246 547 minecraft:bone_block
fill 262 245 543 262 250 543 minecraft:bone_block
fill 262 245 546 262 248 546 minecraft:bone_block
fill 272 245 512 272 246 514 minecraft:amethyst_block
setblock 273 245 512 minecraft:amethyst_block
setblock 273 245 514 minecraft:amethyst_block
setblock 277 245 525 minecraft:crying_obsidian
setblock 277 245 529 minecraft:amethyst_block
fill 235 246 518 235 251 518 minecraft:black_concrete
fill 235 246 530 235 272 530 minecraft:black_concrete
fill 235 246 534 235 251 534 minecraft:black_concrete
fill 235 246 543 235 290 543 minecraft:black_concrete
fill 235 246 550 235 251 550 minecraft:black_concrete
fill 239 246 510 239 251 510 minecraft:black_concrete
setblock 240 246 552 minecraft:crying_obsidian
fill 249 246 552 249 251 552 minecraft:black_concrete
fill 255 246 510 255 251 510 minecraft:black_concrete
fill 262 246 542 262 250 542 minecraft:bone_block
fill 263 246 543 264 251 543 minecraft:bone_block
fill 263 246 546 263 248 546 minecraft:bone_block
fill 264 246 544 264 250 545 minecraft:bone_block
fill 265 246 552 265 251 552 minecraft:black_concrete
fill 269 246 513 271 247 513 minecraft:amethyst_block
fill 271 246 510 271 251 510 minecraft:black_concrete
setblock 271 246 512 minecraft:amethyst_block
setblock 271 246 514 minecraft:amethyst_block
setblock 274 246 512 minecraft:amethyst_block
setblock 274 246 514 minecraft:amethyst_block
fill 277 246 520 277 251 520 minecraft:black_concrete
fill 277 246 525 277 277 525 minecraft:black_concrete
fill 277 246 529 277 250 529 minecraft:black_concrete
fill 277 246 536 277 251 536 minecraft:black_concrete
setblock 235 247 513 minecraft:amethyst_block
setblock 235 247 522 minecraft:amethyst_block
setblock 235 247 551 minecraft:amethyst_block
setblock 240 247 510 minecraft:white_concrete
fill 240 247 552 240 307 552 minecraft:black_concrete
setblock 255 247 552 minecraft:crying_obsidian
setblock 259 247 545 minecraft:bone_block
setblock 261 247 542 minecraft:bone_block
fill 263 247 542 264 251 542 minecraft:bone_block
fill 265 247 543 265 252 544 minecraft:bone_block
fill 267 247 535 267 248 537 minecraft:amethyst_block
setblock 268 247 513 minecraft:amethyst_block
fill 268 247 536 268 248 537 minecraft:amethyst_block
fill 235 248 513 235 307 513 minecraft:black_concrete
fill 235 248 522 235 307 522 minecraft:black_concrete
setblock 235 248 542 minecraft:white_concrete
fill 235 248 551 235 274 551 minecraft:black_concrete
setblock 239 248 552 minecraft:white_concrete
fill 240 248 510 240 307 510 minecraft:black_concrete
fill 255 248 552 255 307 552 minecraft:black_concrete
setblock 260 248 545 minecraft:bone_block
fill 261 248 543 261 249 543 minecraft:bone_block
fill 264 248 541 264 252 541 minecraft:bone_block
fill 264 248 548 265 248 549 minecraft:bone_block
fill 265 248 542 266 253 542 minecraft:bone_block
fill 265 248 545 265 250 545 minecraft:bone_block
fill 265 248 547 265 250 547 minecraft:bone_block
fill 266 248 543 266 253 543 minecraft:bone_block
fill 274 248 534 276 248 534 minecraft:bone_block
fill 275 248 533 276 248 533 minecraft:bone_block
setblock 277 248 526 minecraft:white_concrete
fill 235 249 542 235 307 542 minecraft:black_concrete
setblock 235 249 545 minecraft:crying_obsidian
fill 239 249 552 239 256 552 minecraft:black_concrete
fill 243 249 519 244 250 520 minecraft:amethyst_block
fill 250 249 546 250 250 548 minecraft:amethyst_block
fill 251 249 547 251 250 547 minecraft:amethyst_block
fill 261 249 544 261 249 545 minecraft:bone_block
fill 263 249 541 263 250 541 minecraft:bone_block
fill 264 249 547 264 249 548 minecraft:bone_block
fill 265 249 541 266 254 541 minecraft:bone_block
fill 265 249 546 265 250 546 minecraft:bone_block
setblock 265 249 548 minecraft:bone_block
fill 266 249 544 266 252 544 minecraft:bone_block
fill 267 249 542 267 254 542 minecraft:bone_block
setblock 269 249 510 minecraft:white_concrete
fill 273 249 535 274 250 535 minecraft:bone_block
fill 274 249 534 275 249 534 minecraft:bone_block
fill 277 249 526 277 274 526 minecraft:black_concrete
fill 235 250 545 235 307 545 minecraft:black_concrete
fill 262 250 544 263 250 544 minecraft:bone_block
setblock 263 250 545 minecraft:bone_block
fill 265 250 540 267 254 540 minecraft:bone_block
fill 266 250 545 266 250 546 minecraft:bone_block
fill 267 250 541 267 255 541 minecraft:bone_block
fill 267 250 543 267 253 543 minecraft:bone_block
fill 269 250 510 269 307 510 minecraft:black_concrete
fill 272 250 536 273 250 536 minecraft:bone_block
fill 235 251 519 235 284 520 minecraft:black_concrete
setblock 235 251 521 minecraft:white_concrete
setblock 238 251 513 minecraft:light[level=12]
setblock 238 251 521 minecraft:light[level=12]
setblock 238 251 529 minecraft:light[level=12]
setblock 238 251 537 minecraft:light[level=12]
setblock 238 251 545 minecraft:light[level=12]
setblock 246 251 513 minecraft:light[level=12]
setblock 246 251 521 minecraft:light[level=12]
setblock 246 251 529 minecraft:light[level=12]
setblock 246 251 537 minecraft:light[level=12]
setblock 246 251 545 minecraft:light[level=12]
setblock 254 251 513 minecraft:light[level=12]
setblock 254 251 521 minecraft:light[level=12]
setblock 254 251 529 minecraft:light[level=12]
setblock 254 251 537 minecraft:light[level=12]
setblock 254 251 545 minecraft:light[level=12]
setblock 257 251 510 minecraft:white_concrete
setblock 262 251 513 minecraft:light[level=12]
setblock 262 251 521 minecraft:light[level=12]
setblock 262 251 529 minecraft:light[level=12]
setblock 262 251 537 minecraft:light[level=12]
setblock 262 251 545 minecraft:light[level=12]
setblock 263 251 510 minecraft:white_concrete
fill 263 251 544 264 251 544 minecraft:bone_block
fill 266 251 539 267 255 539 minecraft:bone_block
setblock 266 251 545 minecraft:bone_block
fill 268 251 540 268 254 542 minecraft:bone_block
setblock 270 251 513 minecraft:light[level=12]
setblock 270 251 521 minecraft:light[level=12]
setblock 270 251 529 minecraft:light[level=12]
setblock 270 251 537 minecraft:light[level=12]
setblock 270 251 545 minecraft:light[level=12]
fill 271 251 536 272 251 537 minecraft:bone_block
setblock 277 251 529 minecraft:white_concrete
setblock 235 252 515 minecraft:crying_obsidian
fill 235 252 518 235 254 518 minecraft:purple_concrete
fill 235 252 521 235 307 521 minecraft:black_concrete
setblock 235 252 527 minecraft:amethyst_block
fill 235 252 534 235 254 534 minecraft:purple_concrete
fill 235 252 550 235 254 550 minecraft:purple_concrete
fill 239 252 510 239 254 510 minecraft:purple_concrete
fill 245 252 510 245 259 510 minecraft:black_concrete
setblock 246 252 510 minecraft:amethyst_block
fill 249 252 552 249 254 552 minecraft:purple_concrete
fill 255 252 510 255 254 510 minecraft:purple_concrete
fill 257 252 510 257 264 510 minecraft:black_concrete
setblock 257 252 552 minecraft:crying_obsidian
fill 263 252 510 263 285 510 minecraft:black_concrete
fill 264 252 542 264 252 543 minecraft:bone_block
fill 265 252 552 265 254 552 minecraft:purple_concrete
fill 268 252 539 269 257 539 minecraft:bone_block
setblock 268 252 552 minecraft:crying_obsidian
fill 269 252 538 271 252 538 minecraft:bone_block
fill 269 252 540 269 255 541 minecraft:bone_block
fill 270 252 537 271 252 537 minecraft:bone_block
fill 271 252 510 271 254 510 minecraft:purple_concrete
fill 277 252 520 277 254 520 minecraft:purple_concrete
fill 277 252 529 277 301 529 minecraft:black_concrete
fill 277 252 536 277 254 536 minecraft:purple_concrete
fill 235 253 515 235 272 515 minecraft:black_concrete
fill 235 253 527 235 265 527 minecraft:black_concrete
setblock 235 253 549 minecraft:amethyst_block
fill 246 253 510 246 289 510 minecraft:black_concrete
fill 257 253 552 257 304 552 minecraft:black_concrete
setblock 265 253 539 minecraft:bone_block
setblock 265 253 543 minecraft:bone_block
fill 267 253 538 270 257 538 minecraft:bone_block
fill 268 253 552 268 307 552 minecraft:black_concrete
setblock 277 253 511 minecraft:amethyst_block
setblock 277 253 543 minecraft:crying_obsidian
fill 235 254 549 235 266 549 minecraft:black_concrete
setblock 261 254 552 minecraft:crying_obsidian
fill 266 254 538 266 255 538 minecraft:bone_block
setblock 266 254 542 minecraft:bone_block
fill 267 254 537 270 257 537 minecraft:bone_block
fill 270 254 539 270 255 540 minecraft:bone_block
fill 277 254 511 277 267 511 minecraft:black_concrete
setblock 277 254 541 minecraft:white_concrete
fill 277 254 543 277 263 543 minecraft:black_concrete
fill 235 255 518 235 287 518 minecraft:black_concrete
setblock 235 255 528 minecraft:white_concrete
fill 235 255 529 235 307 529 minecraft:black_concrete
fill 235 255 534 235 287 534 minecraft:black_concrete
setblock 235 255 548 minecraft:amethyst_block
fill 235 255 550 235 287 550 minecraft:black_concrete
fill 239 255 510 239 267 510 minecraft:black_concrete
fill 249 255 552 249 271 552 minecraft:black_concrete
setblock 251 255 552 minecraft:amethyst_block
setblock 253 255 510 minecraft:white_concrete
fill 255 255 510 255 287 510 minecraft:black_concrete
fill 261 255 552 261 266 552 minecraft:black_concrete
fill 265 255 552 265 287 552 minecraft:black_concrete
fill 266 255 540 266 255 541 minecraft:bone_block
fill 267 255 540 268 256 540 minecraft:bone_block
fill 268 255 536 270 259 536 minecraft:bone_block
setblock 268 255 541 minecraft:bone_block
fill 271 255 510 271 287 510 minecraft:black_concrete
fill 277 255 520 277 287 520 minecraft:black_concrete
setblock 277 255 524 minecraft:amethyst_block
setblock 277 255 535 minecraft:crying_obsidian
fill 277 255 536 277 283 536 minecraft:black_concrete
fill 277 255 541 277 307 541 minecraft:black_concrete
fill 235 256 528 235 301 528 minecraft:black_concrete
fill 235 256 548 235 307 548 minecraft:black_concrete
fill 251 256 552 251 303 552 minecraft:black_concrete
fill 253 256 510 253 272 510 minecraft:black_concrete
fill 267 256 539 267 257 539 minecraft:bone_block
fill 268 256 535 270 260 535 minecraft:bone_block
setblock 269 256 540 minecraft:bone_block
fill 270 256 539 270 257 539 minecraft:bone_block
fill 271 256 536 271 258 538 minecraft:bone_block
setblock 271 256 552 minecraft:amethyst_block
fill 273 256 521 273 257 522 minecraft:bone_block
fill 273 256 540 273 257 541 minecraft:bone_block
fill 277 256 524 277 307 524 minecraft:black_concrete
fill 277 256 535 277 307 535 minecraft:black_concrete
fill 277 256 538 277 256 539 minecraft:crying_obsidian
setblock 239 257 552 minecraft:white_concrete
fill 269 257 534 271 260 534 minecraft:bone_block
fill 271 257 535 271 260 535 minecraft:bone_block
fill 271 257 552 271 294 552 minecraft:black_concrete
fill 272 257 523 273 258 523 minecraft:bone_block
fill 272 257 539 273 258 539 minecraft:bone_block
setblock 276 257 552 minecraft:crying_obsidian
setblock 277 257 537 minecraft:amethyst_block
fill 277 257 538 277 278 539 minecraft:black_concrete
setblock 235 258 538 minecraft:amethyst_block
fill 239 258 552 239 259 552 minecraft:black_concrete
setblock 250 258 510 minecraft:white_concrete
setblock 254 258 552 minecraft:amethyst_block
setblock 264 258 510 minecraft:white_concrete
fill 268 258 534 268 260 534 minecraft:bone_block
fill 268 258 537 270 258 538 minecraft:bone_block
fill 269 258 533 271 260 533 minecraft:bone_block
setblock 269 258 539 minecraft:bone_block
fill 272 258 524 272 259 525 minecraft:bone_block
fill 272 258 534 272 259 538 minecraft:bone_block
setblock 273 258 524 minecraft:bone_block
setblock 273 258 538 minecraft:bone_block
fill 276 258 552 276 263 552 minecraft:black_concrete
setblock 277 258 517 minecraft:crying_obsidian
fill 277 258 537 277 307 537 minecraft:black_concrete
setblock 277 258 549 minecraft:crying_obsidian
fill 235 259 538 235 307 538 minecraft:black_concrete
setblock 237 259 510 minecraft:white_concrete
setblock 238 259 513 minecraft:light[level=12]
setblock 238 259 521 minecraft:light[level=12]
setblock 238 259 529 minecraft:light[level=12]
setblock 238 259 537 minecraft:light[level=12]
setblock 238 259 545 minecraft:light[level=12]
setblock 244 259 510 minecraft:crying_obsidian
setblock 246 259 513 minecraft:light[level=12]
setblock 246 259 521 minecraft:light[level=12]
setblock 246 259 529 minecraft:light[level=12]
setblock 246 259 537 minecraft:light[level=12]
setblock 246 259 545 minecraft:light[level=12]
fill 250 259 510 250 307 510 minecraft:black_concrete
setblock 251 259 510 minecraft:white_concrete
setblock 254 259 513 minecraft:light[level=12]
setblock 254 259 521 minecraft:light[level=12]
setblock 254 259 529 minecraft:light[level=12]
setblock 254 259 537 minecraft:light[level=12]
setblock 254 259 545 minecraft:light[level=12]
fill 254 259 552 254 307 552 minecraft:black_concrete
setblock 258 259 552 minecraft:white_concrete
setblock 262 259 513 minecraft:light[level=12]
setblock 262 259 521 minecraft:light[level=12]
setblock 262 259 529 minecraft:light[level=12]
setblock 262 259 537 minecraft:light[level=12]
setblock 262 259 545 minecraft:light[level=12]
fill 264 259 510 264 302 510 minecraft:black_concrete
fill 268 259 537 271 259 537 minecraft:bone_block
fill 269 259 532 271 260 532 minecraft:bone_block
fill 269 259 538 270 259 538 minecraft:bone_block
setblock 270 259 513 minecraft:light[level=12]
setblock 270 259 521 minecraft:light[level=12]
setblock 270 259 529 minecraft:light[level=12]
setblock 270 259 545 minecraft:light[level=12]
fill 271 259 536 271 260 536 minecraft:bone_block
fill 272 259 526 272 260 527 minecraft:bone_block
fill 272 259 533 272 260 533 minecraft:bone_block
setblock 273 259 525 minecraft:bone_block
setblock 273 259 537 minecraft:bone_block
setblock 277 259 514 minecraft:white_concrete
fill 277 259 517 277 307 517 minecraft:black_concrete
setblock 277 259 545 minecraft:white_concrete
fill 277 259 549 277 300 549 minecraft:black_concrete
fill 237 260 510 237 266 510 minecraft:black_concrete
setblock 239 260 552 minecraft:crying_obsidian
fill 244 260 510 244 281 510 minecraft:black_concrete
setblock 245 260 510 minecraft:white_concrete
fill 251 260 510 251 268 510 minecraft:black_concrete
setblock 258 260 510 minecraft:crying_obsidian
fill 258 260 552 258 281 552 minecraft:black_concrete
setblock 259 260 510 minecraft:white_concrete
fill 260 260 510 260 307 510 minecraft:black_concrete
setblock 262 260 552 minecraft:amethyst_block
setblock 268 260 533 minecraft:bone_block
fill 269 260 531 271 260 531 minecraft:bone_block
fill 269 260 536 270 260 536 minecraft:bone_block
setblock 270 260 537 minecraft:bone_block
fill 271 260 527 271 260 528 minecraft:bone_block
setblock 272 260 528 minecraft:bone_block
setblock 272 260 532 minecraft:bone_block
fill 272 260 534 272 260 536 minecraft:bone_block
fill 277 260 514 277 307 514 minecraft:black_concrete
fill 277 260 545 277 301 545 minecraft:black_concrete
setblock 277 260 546 minecraft:crying_obsidian
fill 239 261 552 239 285 552 minecraft:black_concrete
fill 245 261 510 245 276 510 minecraft:black_concrete
fill 258 261 510 259 278 510 minecraft:black_concrete
fill 262 261 552 262 305 552 minecraft:black_concrete
fill 277 261 546 277 298 546 minecraft:black_concrete
setblock 236 262 510 minecraft:amethyst_block
setblock 237 262 552 minecraft:amethyst_block
setblock 259 262 552 minecraft:amethyst_block
fill 260 262 552 260 307 552 minecraft:black_concrete
setblock 235 263 539 minecraft:white_concrete
fill 236 263 510 236 284 510 minecraft:black_concrete
fill 237 263 552 237 296 552 minecraft:black_concrete
setblock 252 263 552 minecraft:crying_obsidian
fill 253 263 552 253 307 552 minecraft:black_concrete
fill 259 263 552 259 307 552 minecraft:black_concrete
setblock 277 263 551 minecraft:crying_obsidian
setblock 235 264 526 minecraft:amethyst_block
fill 235 264 539 235 307 539 minecraft:black_concrete
fill 252 264 552 252 307 552 minecraft:black_concrete
setblock 265 264 510 minecraft:amethyst_block
setblock 276 264 552 minecraft:white_concrete
setblock 277 264 543 minecraft:crying_obsidian
fill 277 264 551 277 275 551 minecraft:black_concrete
fill 235 265 526 235 307 526 minecraft:black_concrete
setblock 257 265 510 minecraft:amethyst_block
fill 265 265 510 265 307 510 minecraft:black_concrete
fill 276 265 552 276 297 552 minecraft:black_concrete
setblock 277 265 531 minecraft:amethyst_block
fill 277 265 543 277 274 543 minecraft:black_concrete
setblock 235 266 527 minecraft:white_concrete
fill 236 266 511 252 266 551 minecraft:black_concrete
fill 253 266 511 253 266 532 minecraft:black_concrete
fill 253 266 534 253 266 551 minecraft:black_concrete
fill 254 266 511 254 266 531 minecraft:black_concrete
fill 254 266 535 254 266 551 minecraft:black_concrete
fill 255 266 511 276 266 530 minecraft:black_concrete
fill 255 266 536 276 266 551 minecraft:black_concrete
fill 256 266 531 277 266 531 minecraft:black_concrete
fill 256 266 535 276 266 535 minecraft:black_concrete
fill 257 266 510 257 269 510 minecraft:black_concrete
fill 257 266 532 276 266 532 minecraft:black_concrete
fill 257 266 534 276 266 534 minecraft:black_concrete
fill 258 266 533 276 266 533 minecraft:black_concrete
setblock 277 266 513 minecraft:white_concrete
setblock 277 266 547 minecraft:white_concrete
fill 235 267 527 236 292 527 minecraft:black_concrete
setblock 235 267 549 minecraft:crying_obsidian
fill 236 267 511 236 279 526 minecraft:black_concrete
fill 236 267 528 236 279 551 minecraft:black_concrete
setblock 237 267 510 minecraft:crying_obsidian
fill 237 267 511 276 279 511 minecraft:black_concrete
fill 237 267 512 252 279 550 minecraft:obsidian
fill 237 267 551 276 279 551 minecraft:black_concrete
fill 253 267 512 253 278 532 minecraft:obsidian
fill 253 267 534 253 278 550 minecraft:obsidian
fill 254 267 512 254 278 531 minecraft:obsidian
fill 254 267 535 254 278 550 minecraft:obsidian
fill 255 267 512 275 279 530 minecraft:obsidian
fill 255 267 536 275 279 550 minecraft:obsidian
fill 256 267 531 275 278 531 minecraft:obsidian
fill 256 267 535 275 278 535 minecraft:obsidian
fill 257 267 532 275 278 532 minecraft:obsidian
fill 257 267 534 275 278 534 minecraft:obsidian
fill 258 267 533 275 279 533 minecraft:obsidian
setblock 261 267 552 minecraft:white_concrete
fill 276 267 512 276 280 550 minecraft:black_concrete
fill 277 267 513 277 302 513 minecraft:black_concrete
setblock 277 267 527 minecraft:crying_obsidian
fill 277 267 531 277 307 531 minecraft:black_concrete
setblock 277 267 532 minecraft:crying_obsidian
fill 277 267 547 277 307 547 minecraft:black_concrete
fill 235 268 549 235 307 549 minecraft:black_concrete
fill 237 268 510 237 307 510 minecraft:black_concrete
setblock 239 268 510 minecraft:crying_obsidian
fill 261 268 552 261 277 552 minecraft:black_concrete
setblock 274 268 552 minecraft:amethyst_block
setblock 277 268 511 minecraft:amethyst_block
fill 277 268 527 277 307 527 minecraft:black_concrete
fill 277 268 532 277 307 532 minecraft:black_concrete
setblock 277 268 544 minecraft:amethyst_block
setblock 238 269 510 minecraft:white_concrete
fill 239 269 510 239 272 510 minecraft:black_concrete
setblock 251 269 510 minecraft:amethyst_block
fill 274 269 552 274 288 552 minecraft:black_concrete
fill 277 269 511 277 289 511 minecraft:black_concrete
setblock 277 269 544 minecraft:white_concrete
fill 238 270 510 238 307 510 minecraft:black_concrete
fill 251 270 510 251 284 510 minecraft:black_concrete
setblock 257 270 510 minecraft:crying_obsidian
fill 277 270 544 277 307 544 minecraft:black_concrete
setblock 277 270 548 minecraft:amethyst_block
fill 257 271 510 257 307 510 minecraft:black_concrete
fill 277 271 548 277 307 548 minecraft:black_concrete
setblock 249 272 552 minecraft:amethyst_block
setblock 235 273 515 minecraft:white_concrete
setblock 235 273 530 minecraft:amethyst_block
setblock 239 273 510 minecraft:crying_obsidian
fill 249 273 552 249 287 552 minecraft:black_concrete
setblock 253 273 510 minecraft:crying_obsidian
fill 235 274 515 235 295 515 minecraft:black_concrete
fill 235 274 530 235 307 530 minecraft:black_concrete
fill 239 274 510 239 287 510 minecraft:black_concrete
setblock 241 274 510 minecraft:amethyst_block
fill 253 274 510 253 307 510 minecraft:black_concrete
setblock 235 275 551 minecraft:white_concrete
fill 241 275 510 241 298 510 minecraft:black_concrete
setblock 277 275 526 minecraft:crying_obsidian
setblock 277 275 543 minecraft:crying_obsidian
fill 235 276 551 235 289 551 minecraft:black_concrete
fill 277 276 526 277 302 526 minecraft:black_concrete
setblock 277 276 528 minecraft:crying_obsidian
fill 277 276 543 277 307 543 minecraft:black_concrete
setblock 277 276 551 minecraft:crying_obsidian
setblock 245 277 510 minecraft:white_concrete
setblock 276 277 510 minecraft:amethyst_block
fill 277 277 528 277 307 528 minecraft:black_concrete
fill 277 277 551 277 307 551 minecraft:black_concrete
fill 243 278 552 244 278 552 minecraft:white_concrete
fill 245 278 510 245 307 510 minecraft:black_concrete
setblock 261 278 552 minecraft:white_concrete
fill 276 278 510 276 307 510 minecraft:black_concrete
setblock 277 278 525 minecraft:amethyst_block
setblock 235 279 511 minecraft:amethyst_block
fill 243 279 552 244 307 552 minecraft:black_concrete
fill 253 279 512 253 279 531 minecraft:obsidian
fill 253 279 532 253 280 532 minecraft:crying_obsidian
fill 253 279 534 253 280 534 minecraft:crying_obsidian
fill 253 279 535 253 279 550 minecraft:obsidian
fill 254 279 512 254 279 530 minecraft:obsidian
fill 254 279 531 254 280 531 minecraft:crying_obsidian
fill 254 279 535 254 280 535 minecraft:crying_obsidian
fill 254 279 536 254 279 550 minecraft:obsidian
fill 256 279 531 256 280 531 minecraft:crying_obsidian
fill 256 279 535 256 280 535 minecraft:crying_obsidian
fill 257 279 531 275 279 531 minecraft:obsidian
fill 257 279 532 257 280 532 minecraft:crying_obsidian
fill 257 279 534 257 280 534 minecraft:crying_obsidian
fill 257 279 535 275 279 535 minecraft:obsidian
fill 258 279 510 258 307 510 minecraft:black_concrete
fill 258 279 532 275 279 532 minecraft:obsidian
fill 258 279 534 275 279 534 minecraft:obsidian
setblock 259 279 510 minecraft:crying_obsidian
fill 261 279 552 261 307 552 minecraft:black_concrete
setblock 277 279 525 minecraft:crying_obsidian
setblock 277 279 538 minecraft:white_concrete
fill 277 279 539 277 307 539 minecraft:black_concrete
fill 235 280 511 235 298 511 minecraft:black_concrete
setblock 236 280 511 minecraft:obsidian
fill 236 280 512 236 280 526 minecraft:black_concrete
fill 236 280 528 236 280 550 minecraft:black_concrete
setblock 236 280 551 minecraft:obsidian
setblock 236 280 552 minecraft:amethyst_block
fill 237 280 511 275 280 511 minecraft:black_concrete
fill 237 280 512 251 280 550 minecraft:obsidian
fill 237 280 551 275 280 551 minecraft:black_concrete
fill 252 280 512 252 280 531 minecraft:obsidian
fill 252 280 532 252 280 534 minecraft:crying_obsidian
fill 252 280 535 252 280 550 minecraft:obsidian
fill 253 280 512 253 280 530 minecraft:obsidian
setblock 253 280 531 minecraft:crying_obsidian
setblock 253 280 535 minecraft:crying_obsidian
fill 253 280 536 253 280 550 minecraft:obsidian
fill 254 280 512 275 280 529 minecraft:obsidian
fill 254 280 530 256 280 530 minecraft:crying_obsidian
fill 254 280 536 256 280 536 minecraft:crying_obsidian
fill 254 280 537 275 280 550 minecraft:obsidian
setblock 257 280 530 minecraft:purple_concrete
setblock 257 280 531 minecraft:crying_obsidian
setblock 257 280 535 minecraft:crying_obsidian
fill 257 280 536 275 280 536 minecraft:obsidian
fill 258 280 530 275 280 530 minecraft:obsidian
setblock 258 280 531 minecraft:purple_concrete
fill 258 280 532 258 280 534 minecraft:crying_obsidian
fill 258 280 535 275 280 535 minecraft:obsidian
fill 259 280 510 259 283 510 minecraft:black_concrete
fill 259 280 531 275 280 534 minecraft:obsidian
setblock 276 280 511 minecraft:obsidian
setblock 276 280 551 minecraft:obsidian
fill 277 280 525 277 307 525 minecraft:black_concrete
fill 277 280 538 277 307 538 minecraft:black_concrete
fill 236 281 513 236 282 526 minecraft:black_concrete
fill 236 281 528 236 282 549 minecraft:black_concrete
fill 236 281 552 236 302 552 minecraft:black_concrete
fill 237 281 512 237 282 512 minecraft:black_concrete
fill 237 281 513 250 281 549 minecraft:obsidian
fill 237 281 550 237 282 550 minecraft:black_concrete
fill 238 281 511 274 282 511 minecraft:black_concrete
fill 238 281 512 274 282 512 minecraft:obsidian
fill 238 281 550 274 282 550 minecraft:obsidian
fill 238 281 551 274 282 551 minecraft:black_concrete
fill 251 281 513 251 281 531 minecraft:obsidian
fill 251 281 532 251 281 534 minecraft:purple_concrete
fill 251 281 535 251 281 549 minecraft:obsidian
fill 252 281 513 252 281 529 minecraft:obsidian
fill 252 281 530 252 281 531 minecraft:purple_concrete
setblock 252 281 535 minecraft:purple_concrete
fill 252 281 536 252 281 549 minecraft:obsidian
fill 253 281 513 275 281 528 minecraft:obsidian
fill 253 281 529 253 281 530 minecraft:purple_concrete
setblock 253 281 536 minecraft:purple_concrete
fill 253 281 537 253 281 549 minecraft:obsidian
fill 254 281 529 257 281 529 minecraft:purple_concrete
fill 254 281 537 256 281 537 minecraft:purple_concrete
fill 254 281 538 275 282 549 minecraft:obsidian
setblock 257 281 536 minecraft:purple_concrete
fill 257 281 537 275 281 537 minecraft:obsidian
fill 258 281 529 275 281 529 minecraft:obsidian
setblock 258 281 530 minecraft:purple_concrete
setblock 258 281 535 minecraft:purple_concrete
fill 258 281 536 275 281 536 minecraft:obsidian
fill 259 281 530 275 281 530 minecraft:obsidian
fill 259 281 531 259 281 534 minecraft:purple_concrete
fill 259 281 535 275 281 535 minecraft:obsidian
fill 260 281 531 275 281 534 minecraft:obsidian
setblock 263 281 552 minecraft:crying_obsidian
fill 275 281 512 275 282 512 minecraft:black_concrete
fill 275 281 550 275 282 550 minecraft:black_concrete
fill 276 281 513 276 282 549 minecraft:black_concrete
fill 237 282 513 249 282 549 minecraft:obsidian
setblock 244 282 510 minecraft:white_concrete
setblock 247 282 510 minecraft:amethyst_block
fill 250 282 513 250 282 531 minecraft:obsidian
fill 250 282 532 250 282 533 minecraft:crying_obsidian
fill 250 282 534 250 282 549 minecraft:obsidian
fill 251 282 513 251 282 529 minecraft:obsidian
fill 251 282 530 251 282 531 minecraft:crying_obsidian
fill 251 282 534 251 282 535 minecraft:crying_obsidian
fill 251 282 536 251 282 549 minecraft:obsidian
fill 252 282 513 252 282 528 minecraft:obsidian
setblock 252 282 529 minecraft:crying_obsidian
setblock 252 282 536 minecraft:crying_obsidian
fill 252 282 537 252 282 549 minecraft:obsidian
fill 253 282 513 275 282 527 minecraft:obsidian
fill 253 282 528 257 282 528 minecraft:crying_obsidian
fill 253 282 537 257 282 537 minecraft:crying_obsidian
fill 253 282 538 253 282 549 minecraft:obsidian
fill 258 282 528 275 282 528 minecraft:obsidian
fill 258 282 529 259 282 529 minecraft:crying_obsidian
fill 258 282 536 259 282 536 minecraft:crying_obsidian
fill 258 282 537 275 282 537 minecraft:obsidian
setblock 258 282 552 minecraft:amethyst_block
setblock 259 282 530 minecraft:crying_obsidian
setblock 259 282 535 minecraft:crying_obsidian
fill 260 282 529 275 282 530 minecraft:obsidian
fill 260 282 531 260 282 534 minecraft:crying_obsidian
fill 260 282 535 275 282 536 minecraft:obsidian
fill 261 282 531 275 282 534 minecraft:obsidian
fill 263 282 552 263 307 552 minecraft:black_concrete
setblock 235 283 531 minecraft:amethyst_block
fill 236 283 514 236 283 526 minecraft:black_concrete
fill 236 283 528 236 283 548 minecraft:black_concrete
setblock 237 283 513 minecraft:black_concrete
fill 237 283 514 249 283 548 minecraft:obsidian
setblock 237 283 549 minecraft:black_concrete
setblock 238 283 512 minecraft:black_concrete
fill 238 283 513 274 283 513 minecraft:obsidian
fill 238 283 549 274 283 549 minecraft:obsidian
setblock 238 283 550 minecraft:black_concrete
fill 239 283 511 273 283 511 minecraft:black_concrete
fill 239 283 512 273 283 512 minecraft:obsidian
fill 239 283 550 273 283 550 minecraft:obsidian
fill 239 283 551 273 283 551 minecraft:black_concrete
fill 244 283 510 244 307 510 minecraft:black_concrete
fill 247 283 510 247 307 510 minecraft:black_concrete
fill 250 283 514 250 283 529 minecraft:obsidian
fill 250 283 530 250 283 535 minecraft:purple_concrete
fill 250 283 536 250 283 548 minecraft:obsidian
fill 251 283 514 251 283 528 minecraft:obsidian
setblock 251 283 529 minecraft:purple_concrete
setblock 251 283 536 minecraft:purple_concrete
fill 251 283 537 251 283 548 minecraft:obsidian
fill 252 283 514 252 283 527 minecraft:obsidian
setblock 252 283 528 minecraft:purple_concrete
setblock 252 283 537 minecraft:purple_concrete
fill 252 283 538 252 283 548 minecraft:obsidian
fill 253 283 514 275 283 526 minecraft:obsidian
fill 253 283 527 258 283 527 minecraft:purple_concrete
fill 253 283 538 257 283 538 minecraft:purple_concrete
fill 253 283 539 275 283 548 minecraft:obsidian
setblock 254 283 529 minecraft:light[level=12]
setblock 254 283 537 minecraft:light[level=12]
fill 258 283 528 259 283 528 minecraft:purple_concrete
fill 258 283 537 259 283 537 minecraft:purple_concrete
fill 258 283 538 275 283 538 minecraft:obsidian
fill 258 283 552 258 298 552 minecraft:black_concrete
fill 259 283 527 275 283 527 minecraft:obsidian
fill 260 283 528 275 283 528 minecraft:obsidian
fill 260 283 529 260 283 530 minecraft:purple_concrete
fill 260 283 535 260 283 536 minecraft:purple_concrete
fill 260 283 537 275 283 537 minecraft:obsidian
fill 261 283 529 275 283 530 minecraft:obsidian
fill 261 283 531 261 283 534 minecraft:purple_concrete
fill 261 283 535 275 283 536 minecraft:obsidian
fill 262 283 531 275 283 534 minecraft:obsidian
setblock 274 283 512 minecraft:black_concrete
setblock 274 283 550 minecraft:black_concrete
setblock 275 283 513 minecraft:black_concrete
setblock 275 283 549 minecraft:black_concrete
fill 276 283 514 276 283 548 minecraft:black_concrete
fill 235 284 531 236 292 531 minecraft:black_concrete
fill 236 284 515 236 285 526 minecraft:black_concrete
fill 236 284 528 236 292 530 minecraft:black_concrete
fill 236 284 532 236 285 547 minecraft:black_concrete
fill 237 284 514 237 285 514 minecraft:black_concrete
fill 237 284 515 248 284 547 minecraft:obsidian
fill 237 284 548 237 285 548 minecraft:black_concrete
fill 238 284 513 238 285 513 minecraft:black_concrete
fill 238 284 514 274 285 514 minecraft:obsidian
fill 238 284 548 274 285 548 minecraft:obsidian
fill 238 284 549 238 285 549 minecraft:black_concrete
fill 239 284 512 239 285 512 minecraft:black_concrete
fill 239 284 513 273 285 513 minecraft:obsidian
fill 239 284 549 273 285 549 minecraft:obsidian
fill 239 284 550 239 285 550 minecraft:black_concrete
fill 240 284 511 272 285 511 minecraft:black_concrete
fill 240 284 512 272 285 512 minecraft:obsidian
fill 240 284 550 272 285 550 minecraft:obsidian
fill 240 284 551 272 285 551 minecraft:black_concrete
setblock 243 284 510 minecraft:white_concrete
fill 249 284 515 249 284 529 minecraft:obsidian
fill 249 284 530 249 284 535 minecraft:purple_concrete
fill 249 284 536 249 284 547 minecraft:obsidian
fill 250 284 515 250 284 527 minecraft:obsidian
fill 250 284 528 250 284 529 minecraft:purple_concrete
setblock 250 284 536 minecraft:purple_concrete
fill 250 284 537 250 284 547 minecraft:obsidian
fill 251 284 515 252 284 526 minecraft:obsidian
fill 251 284 527 251 284 528 minecraft:purple_concrete
setblock 251 284 537 minecraft:purple_concrete
fill 251 284 538 251 284 547 minecraft:obsidian
setblock 252 284 527 minecraft:purple_concrete
fill 252 284 538 253 284 538 minecraft:purple_concrete
fill 252 284 539 253 284 547 minecraft:obsidian
fill 253 284 515 275 284 525 minecraft:obsidian
fill 253 284 526 258 284 526 minecraft:purple_concrete
fill 254 284 539 257 284 539 minecraft:purple_concrete
fill 254 284 540 275 284 547 minecraft:obsidian
fill 258 284 538 259 284 538 minecraft:purple_concrete
fill 258 284 539 275 284 539 minecraft:obsidian
setblock 259 284 510 minecraft:white_concrete
fill 259 284 526 275 284 526 minecraft:obsidian
setblock 259 284 527 minecraft:purple_concrete
fill 260 284 527 275 284 527 minecraft:obsidian
setblock 260 284 528 minecraft:purple_concrete
setblock 260 284 537 minecraft:purple_concrete
fill 260 284 538 275 284 538 minecraft:obsidian
fill 261 284 528 275 284 528 minecraft:obsidian
fill 261 284 529 261 284 530 minecraft:purple_concrete
fill 261 284 535 261 284 536 minecraft:purple_concrete
fill 261 284 537 275 284 537 minecraft:obsidian
fill 262 284 529 275 284 530 minecraft:obsidian
fill 262 284 531 262 284 534 minecraft:purple_concrete
fill 262 284 535 275 284 536 minecraft:obsidian
fill 263 284 531 275 284 534 minecraft:obsidian
fill 273 284 512 273 285 512 minecraft:black_concrete
fill 273 284 550 273 285 550 minecraft:black_concrete
fill 274 284 513 274 285 513 minecraft:black_concrete
fill 274 284 549 274 285 549 minecraft:black_concrete
fill 275 284 514 275 285 514 minecraft:black_concrete
fill 275 284 548 275 285 548 minecraft:black_concrete
fill 276 284 515 276 285 547 minecraft:black_concrete
setblock 277 284 536 minecraft:crying_obsidian
fill 235 285 519 235 307 519 minecraft:black_concrete
setblock 235 285 520 minecraft:white_concrete
setblock 236 285 510 minecraft:white_concrete
fill 237 285 515 247 285 547 minecraft:obsidian
fill 243 285 510 243 289 510 minecraft:black_concrete
fill 248 285 515 248 285 529 minecraft:obsidian
fill 248 285 530 248 285 534 minecraft:crying_obsidian
fill 248 285 535 248 285 547 minecraft:obsidian
fill 249 285 515 249 285 527 minecraft:obsidian
fill 249 285 528 249 285 529 minecraft:crying_obsidian
fill 249 285 535 249 285 536 minecraft:crying_obsidian
fill 249 285 537 249 285 547 minecraft:obsidian
fill 250 285 515 250 285 526 minecraft:obsidian
setblock 250 285 527 minecraft:crying_obsidian
setblock 250 285 537 minecraft:crying_obsidian
fill 250 285 538 250 285 547 minecraft:obsidian
setblock 251 285 510 minecraft:amethyst_block
fill 251 285 515 252 285 525 minecraft:obsidian
fill 251 285 526 252 285 526 minecraft:crying_obsidian
setblock 251 285 538 minecraft:crying_obsidian
fill 251 285 539 251 285 547 minecraft:obsidian
fill 252 285 539 253 285 539 minecraft:crying_obsidian
fill 252 285 540 253 285 547 minecraft:obsidian
fill 253 285 515 275 285 524 minecraft:obsidian
fill 253 285 525 258 285 525 minecraft:crying_obsidian
fill 254 285 540 256 285 540 minecraft:crying_obsidian
fill 254 285 541 275 285 547 minecraft:obsidian
fill 257 285 539 259 285 539 minecraft:crying_obsidian
fill 257 285 540 275 285 540 minecraft:obsidian
fill 259 285 510 259 307 510 minecraft:black_concrete
fill 259 285 525 275 285 525 minecraft:obsidian
fill 259 285 526 260 285 526 minecraft:crying_obsidian
fill 260 285 527 261 285 527 minecraft:crying_obsidian
setblock 260 285 538 minecraft:crying_obsidian
fill 260 285 539 275 285 539 minecraft:obsidian
fill 261 285 526 275 285 526 minecraft:obsidian
setblock 261 285 528 minecraft:crying_obsidian
setblock 261 285 537 minecraft:crying_obsidian
fill 261 285 538 275 285 538 minecraft:obsidian
fill 262 285 527 275 285 528 minecraft:obsidian
fill 262 285 529 262 285 530 minecraft:crying_obsidian
fill 262 285 535 262 285 536 minecraft:crying_obsidian
fill 262 285 537 275 285 537 minecraft:obsidian
fill 263 285 529 275 285 530 minecraft:obsidian
fill 263 285 531 263 285 534 minecraft:crying_obsidian
fill 263 285 535 275 285 536 minecraft:obsidian
fill 264 285 531 275 285 534 minecraft:obsidian
fill 277 285 536 277 287 536 minecraft:black_concrete
fill 235 286 520 236 289 520 minecraft:black_concrete
fill 236 286 510 236 307 510 minecraft:black_concrete
fill 236 286 516 236 286 519 minecraft:black_concrete
fill 236 286 521 236 290 526 minecraft:black_concrete
fill 236 286 532 236 286 546 minecraft:black_concrete
setblock 237 286 515 minecraft:black_concrete
fill 237 286 516 246 286 546 minecraft:obsidian
setblock 237 286 547 minecraft:black_concrete
setblock 238 286 514 minecraft:black_concrete
fill 238 286 515 274 286 515 minecraft:obsidian
fill 238 286 547 274 286 547 minecraft:obsidian
setblock 238 286 548 minecraft:black_concrete
setblock 239 286 513 minecraft:black_concrete
fill 239 286 514 273 286 514 minecraft:obsidian
fill 239 286 548 273 286 548 minecraft:obsidian
setblock 239 286 549 minecraft:black_concrete
setblock 239 286 552 minecraft:white_concrete
setblock 240 286 512 minecraft:black_concrete
fill 240 286 513 272 286 513 minecraft:obsidian
fill 240 286 549 272 286 549 minecraft:obsidian
setblock 240 286 550 minecraft:black_concrete
fill 241 286 511 271 286 511 minecraft:black_concrete
fill 241 286 512 271 286 512 minecraft:obsidian
fill 241 286 550 271 286 550 minecraft:obsidian
fill 241 286 551 271 286 551 minecraft:black_concrete
fill 247 286 516 247 286 529 minecraft:obsidian
fill 247 286 530 247 286 534 minecraft:purple_concrete
fill 247 286 535 247 286 546 minecraft:obsidian
fill 248 286 516 248 286 527 minecraft:obsidian
fill 248 286 528 248 286 529 minecraft:purple_concrete
fill 248 286 535 248 286 536 minecraft:purple_concrete
fill 248 286 537 248 286 546 minecraft:obsidian
fill 249 286 516 249 286 526 minecraft:obsidian
setblock 249 286 527 minecraft:purple_concrete
setblock 249 286 537 minecraft:purple_concrete
fill 249 286 538 249 286 546 minecraft:obsidian
fill 250 286 516 250 286 525 minecraft:obsidian
setblock 250 286 526 minecraft:purple_concrete
setblock 250 286 538 minecraft:purple_concrete
fill 250 286 539 250 286 546 minecraft:obsidian
fill 251 286 510 251 307 510 minecraft:black_concrete
fill 251 286 516 252 286 524 minecraft:obsidian
fill 251 286 525 252 286 525 minecraft:purple_concrete
setblock 251 286 539 minecraft:purple_concrete
fill 251 286 540 251 286 546 minecraft:obsidian
fill 252 286 540 259 286 540 minecraft:purple_concrete
fill 252 286 541 275 286 546 minecraft:obsidian
fill 253 286 516 275 286 523 minecraft:obsidian
fill 253 286 524 258 286 524 minecraft:purple_concrete
fill 259 286 524 275 286 524 minecraft:obsidian
fill 259 286 525 260 286 525 minecraft:purple_concrete
setblock 260 286 539 minecraft:purple_concrete
fill 260 286 540 275 286 540 minecraft:obsidian
fill 261 286 525 275 286 525 minecraft:obsidian
setblock 261 286 526 minecraft:purple_concrete
setblock 261 286 538 minecraft:purple_concrete
fill 261 286 539 275 286 539 minecraft:obsidian
fill 262 286 526 275 286 526 minecraft:obsidian
fill 262 286 527 262 286 528 minecraft:purple_concrete
setblock 262 286 537 minecraft:purple_concrete
fill 262 286 538 275 286 538 minecraft:obsidian
setblock 263 286 510 minecraft:crying_obsidian
fill 263 286 527 275 286 527 minecraft:obsidian
fill 263 286 528 263 286 530 minecraft:purple_concrete
fill 263 286 534 263 286 536 minecraft:purple_concrete
fill 263 286 537 275 286 537 minecraft:obsidian
fill 264 286 528 275 286 530 minecraft:obsidian
fill 264 286 531 264 286 533 minecraft:purple_concrete
fill 264 286 534 275 286 536 minecraft:obsidian
fill 265 286 531 275 286 533 minecraft:obsidian
setblock 272 286 512 minecraft:black_concrete
setblock 272 286 550 minecraft:black_concrete
setblock 273 286 513 minecraft:black_concrete
setblock 273 286 549 minecraft:black_concrete
setblock 274 286 514 minecraft:black_concrete
setblock 274 286 548 minecraft:black_concrete
setblock 275 286 515 minecraft:black_concrete
setblock 275 286 547 minecraft:black_concrete
fill 276 286 516 276 286 546 minecraft:black_concrete
fill 236 287 517 236 287 519 minecraft:black_concrete
fill 236 287 532 236 287 545 minecraft:black_concrete
setblock 237 287 516 minecraft:black_concrete
fill 237 287 517 245 287 545 minecraft:obsidian
setblock 237 287 546 minecraft:black_concrete
setblock 238 287 515 minecraft:black_concrete
fill 238 287 516 274 287 516 minecraft:obsidian
fill 238 287 546 274 287 546 minecraft:obsidian
setblock 238 287 547 minecraft:black_concrete
setblock 239 287 514 minecraft:black_concrete
fill 239 287 515 273 287 515 minecraft:obsidian
fill 239 287 547 273 287 547 minecraft:obsidian
setblock 239 287 548 minecraft:black_concrete
fill 239 287 552 239 307 552 minecraft:black_concrete
setblock 240 287 513 minecraft:black_concrete
fill 240 287 514 272 287 514 minecraft:obsidian
fill 240 287 548 272 287 548 minecraft:obsidian
setblock 240 287 549 minecraft:black_concrete
setblock 241 287 512 minecraft:black_concrete
fill 241 287 513 271 287 513 minecraft:obsidian
fill 241 287 549 271 287 549 minecraft:obsidian
setblock 241 287 550 minecraft:black_concrete
fill 242 287 511 270 287 511 minecraft:black_concrete
fill 242 287 512 270 287 512 minecraft:obsidian
fill 242 287 550 270 287 550 minecraft:obsidian
fill 242 287 551 270 287 551 minecraft:black_concrete
fill 246 287 517 246 287 530 minecraft:obsidian
fill 246 287 531 246 287 533 minecraft:purple_concrete
fill 246 287 534 246 287 545 minecraft:obsidian
fill 247 287 517 247 287 527 minecraft:obsidian
fill 247 287 528 247 287 530 minecraft:purple_concrete
fill 247 287 534 247 287 536 minecraft:purple_concrete
fill 247 287 537 247 287 545 minecraft:obsidian
fill 248 287 517 248 287 526 minecraft:obsidian
setblock 248 287 527 minecraft:purple_concrete
setblock 248 287 537 minecraft:purple_concrete
fill 248 287 538 248 287 545 minecraft:obsidian
fill 249 287 517 249 287 525 minecraft:obsidian
setblock 249 287 526 minecraft:purple_concrete
setblock 249 287 538 minecraft:purple_concrete
fill 249 287 539 249 287 545 minecraft:obsidian
fill 250 287 517 250 287 524 minecraft:obsidian
setblock 250 287 525 minecraft:purple_concrete
setblock 250 287 539 minecraft:purple_concrete
fill 250 287 540 250 287 545 minecraft:obsidian
fill 251 287 517 252 287 523 minecraft:obsidian
fill 251 287 524 252 287 524 minecraft:purple_concrete
fill 251 287 540 252 287 540 minecraft:purple_concrete
fill 251 287 541 252 287 545 minecraft:obsidian
fill 253 287 517 275 287 522 minecraft:obsidian
fill 253 287 523 258 287 523 minecraft:purple_concrete
fill 253 287 541 258 287 541 minecraft:purple_concrete
fill 253 287 542 275 287 545 minecraft:obsidian
fill 259 287 523 275 287 523 minecraft:obsidian
fill 259 287 524 260 287 524 minecraft:purple_concrete
fill 259 287 540 260 287 540 minecraft:purple_concrete
fill 259 287 541 275 287 541 minecraft:obsidian
fill 261 287 524 275 287 524 minecraft:obsidian
fill 261 287 525 262 287 525 minecraft:purple_concrete
setblock 261 287 539 minecraft:purple_concrete
fill 261 287 540 275 287 540 minecraft:obsidian
setblock 262 287 526 minecraft:purple_concrete
setblock 262 287 538 minecraft:purple_concrete
fill 262 287 539 275 287 539 minecraft:obsidian
fill 263 287 510 263 307 510 minecraft:black_concrete
fill 263 287 525 275 287 526 minecraft:obsidian
setblock 263 287 527 minecraft:purple_concrete
setblock 263 287 537 minecraft:purple_concrete
fill 263 287 538 275 287 538 minecraft:obsidian
fill 264 287 527 275 287 527 minecraft:obsidian
fill 264 287 528 264 287 530 minecraft:purple_concrete
fill 264 287 534 264 287 536 minecraft:purple_concrete
fill 264 287 537 275 287 537 minecraft:obsidian
fill 265 287 528 275 287 530 minecraft:obsidian
fill 265 287 531 265 287 533 minecraft:purple_concrete
fill 265 287 534 275 287 536 minecraft:obsidian
fill 266 287 531 275 287 533 minecraft:obsidian
setblock 271 287 512 minecraft:black_concrete
setblock 271 287 550 minecraft:black_concrete
setblock 272 287 513 minecraft:black_concrete
setblock 272 287 549 minecraft:black_concrete
setblock 273 287 514 minecraft:black_concrete
setblock 273 287 548 minecraft:black_concrete
setblock 274 287 515 minecraft:black_concrete
setblock 274 287 547 minecraft:black_concrete
setblock 275 287 516 minecraft:black_concrete
setblock 275 287 546 minecraft:black_concrete
fill 276 287 517 276 287 545 minecraft:black_concrete
fill 235 288 518 235 290 518 minecraft:purple_concrete
fill 235 288 534 235 290 534 minecraft:purple_concrete
fill 235 288 550 235 290 550 minecraft:purple_concrete
fill 236 288 518 236 288 519 minecraft:black_concrete
fill 236 288 532 236 288 544 minecraft:black_concrete
setblock 237 288 517 minecraft:black_concrete
fill 237 288 518 245 288 544 minecraft:obsidian
setblock 237 288 545 minecraft:black_concrete
setblock 238 288 516 minecraft:black_concrete
fill 238 288 517 274 288 517 minecraft:obsidian
fill 238 288 545 274 288 545 minecraft:obsidian
setblock 238 288 546 minecraft:black_concrete
fill 239 288 510 239 290 510 minecraft:purple_concrete
setblock 239 288 515 minecraft:black_concrete
fill 239 288 516 273 288 516 minecraft:obsidian
fill 239 288 546 273 288 546 minecraft:obsidian
setblock 239 288 547 minecraft:black_concrete
setblock 240 288 514 minecraft:black_concrete
fill 240 288 515 272 288 515 minecraft:obsidian
fill 240 288 547 272 288 547 minecraft:obsidian
setblock 240 288 548 minecraft:black_concrete
setblock 241 288 513 minecraft:black_concrete
fill 241 288 514 271 288 514 minecraft:obsidian
fill 241 288 548 271 288 548 minecraft:obsidian
setblock 241 288 549 minecraft:black_concrete
setblock 242 288 512 minecraft:black_concrete
fill 242 288 513 270 288 513 minecraft:obsidian
fill 242 288 549 270 288 549 minecraft:obsidian
setblock 242 288 550 minecraft:black_concrete
fill 243 288 511 269 288 511 minecraft:black_concrete
fill 243 288 512 269 288 512 minecraft:obsidian
fill 243 288 550 269 288 550 minecraft:obsidian
fill 243 288 551 269 288 551 minecraft:black_concrete
fill 246 288 518 246 288 527 minecraft:obsidian
fill 246 288 528 246 288 535 minecraft:crying_obsidian
fill 246 288 536 246 288 544 minecraft:obsidian
fill 247 288 518 247 288 526 minecraft:obsidian
setblock 247 288 527 minecraft:crying_obsidian
fill 247 288 536 247 288 537 minecraft:crying_obsidian
fill 247 288 538 247 288 544 minecraft:obsidian
fill 248 288 518 248 288 524 minecraft:obsidian
fill 248 288 525 248 288 526 minecraft:crying_obsidian
setblock 248 288 538 minecraft:crying_obsidian
fill 248 288 539 248 288 544 minecraft:obsidian
fill 249 288 518 250 288 523 minecraft:obsidian
fill 249 288 524 249 288 525 minecraft:crying_obsidian
setblock 249 288 539 minecraft:crying_obsidian
fill 249 288 540 249 288 544 minecraft:obsidian
fill 249 288 552 249 290 552 minecraft:purple_concrete
setblock 250 288 524 minecraft:crying_obsidian
setblock 250 288 540 minecraft:crying_obsidian
fill 250 288 541 250 288 544 minecraft:obsidian
fill 251 288 518 252 288 522 minecraft:obsidian
fill 251 288 523 252 288 523 minecraft:crying_obsidian
fill 251 288 541 253 288 541 minecraft:crying_obsidian
fill 251 288 542 253 288 544 minecraft:obsidian
fill 253 288 518 275 288 521 minecraft:obsidian
fill 253 288 522 259 288 522 minecraft:crying_obsidian
fill 254 288 542 258 288 542 minecraft:crying_obsidian
fill 254 288 543 275 288 544 minecraft:obsidian
fill 255 288 510 255 290 510 minecraft:purple_concrete
setblock 256 288 510 minecraft:amethyst_block
fill 259 288 523 261 288 523 minecraft:crying_obsidian
fill 259 288 541 260 288 541 minecraft:crying_obsidian
fill 259 288 542 275 288 542 minecraft:obsidian
fill 260 288 522 275 288 522 minecraft:obsidian
fill 261 288 524 262 288 524 minecraft:crying_obsidian
setblock 261 288 540 minecraft:crying_obsidian
fill 261 288 541 275 288 541 minecraft:obsidian
fill 262 288 523 275 288 523 minecraft:obsidian
setblock 262 288 539 minecraft:crying_obsidian
fill 262 288 540 275 288 540 minecraft:obsidian
fill 263 288 524 275 288 524 minecraft:obsidian
fill 263 288 525 263 288 526 minecraft:crying_obsidian
setblock 263 288 538 minecraft:crying_obsidian
fill 263 288 539 275 288 539 minecraft:obsidian
fill 264 288 525 275 288 525 minecraft:obsidian
fill 264 288 526 264 288 527 minecraft:crying_obsidian
setblock 264 288 537 minecraft:crying_obsidian
fill 264 288 538 275 288 538 minecraft:obsidian
fill 265 288 526 275 288 527 minecraft:obsidian
fill 265 288 528 265 288 531 minecraft:crying_obsidian
fill 265 288 533 265 288 536 minecraft:crying_obsidian
fill 265 288 537 275 288 537 minecraft:obsidian
fill 265 288 552 265 290 552 minecraft:purple_concrete
fill 266 288 528 275 288 531 minecraft:obsidian
setblock 266 288 532 minecraft:crying_obsidian
fill 266 288 533 275 288 536 minecraft:obsidian
fill 267 288 532 275 289 532 minecraft:obsidian
setblock 270 288 512 minecraft:black_concrete
setblock 270 288 550 minecraft:black_concrete
fill 271 288 510 271 290 510 minecraft:purple_concrete
setblock 271 288 513 minecraft:black_concrete
setblock 271 288 549 minecraft:black_concrete
setblock 272 288 514 minecraft:black_concrete
setblock 272 288 548 minecraft:black_concrete
setblock 273 288 515 minecraft:black_concrete
setblock 273 288 547 minecraft:black_concrete
setblock 274 288 516 minecraft:black_concrete
setblock 274 288 546 minecraft:black_concrete
setblock 275 288 517 minecraft:black_concrete
setblock 275 288 545 minecraft:black_concrete
fill 276 288 518 276 288 544 minecraft:black_concrete
fill 277 288 520 277 290 520 minecraft:purple_concrete
fill 277 288 536 277 290 536 minecraft:purple_concrete
setblock 236 289 519 minecraft:black_concrete
fill 236 289 532 236 289 543 minecraft:black_concrete
setblock 237 289 518 minecraft:black_concrete
fill 237 289 519 244 289 543 minecraft:obsidian
setblock 237 289 544 minecraft:black_concrete
setblock 238 289 517 minecraft:black_concrete
fill 238 289 518 274 289 518 minecraft:obsidian
fill 238 289 544 274 289 544 minecraft:obsidian
setblock 238 289 545 minecraft:black_concrete
setblock 239 289 516 minecraft:black_concrete
fill 239 289 517 273 289 517 minecraft:obsidian
fill 239 289 545 273 289 545 minecraft:obsidian
setblock 239 289 546 minecraft:black_concrete
fill 240 289 515 240 290 515 minecraft:black_concrete
fill 240 289 516 272 289 516 minecraft:obsidian
fill 240 289 546 272 289 546 minecraft:obsidian
fill 240 289 547 240 290 547 minecraft:black_concrete
setblock 241 289 514 minecraft:black_concrete
fill 241 289 515 271 289 515 minecraft:obsidian
fill 241 289 547 271 289 547 minecraft:obsidian
setblock 241 289 548 minecraft:black_concrete
setblock 242 289 513 minecraft:black_concrete
fill 242 289 514 270 289 514 minecraft:obsidian
fill 242 289 548 270 289 548 minecraft:obsidian
setblock 242 289 549 minecraft:black_concrete
setblock 243 289 512 minecraft:black_concrete
fill 243 289 513 269 289 513 minecraft:obsidian
fill 243 289 549 269 289 549 minecraft:obsidian
setblock 243 289 550 minecraft:black_concrete
fill 244 289 511 268 289 511 minecraft:black_concrete
fill 244 289 512 268 289 512 minecraft:obsidian
fill 244 289 550 268 289 550 minecraft:obsidian
fill 244 289 551 268 289 551 minecraft:black_concrete
fill 245 289 519 245 289 528 minecraft:obsidian
fill 245 289 529 245 289 535 minecraft:purple_concrete
fill 245 289 536 245 289 543 minecraft:obsidian
setblock 245 289 552 minecraft:amethyst_block
fill 246 289 519 246 289 526 minecraft:obsidian
fill 246 289 527 246 289 528 minecraft:purple_concrete
fill 246 289 536 246 289 537 minecraft:purple_concrete
fill 246 289 538 246 289 543 minecraft:obsidian
fill 247 289 519 247 289 524 minecraft:obsidian
fill 247 289 525 247 289 526 minecraft:purple_concrete
setblock 247 289 538 minecraft:purple_concrete
fill 247 289 539 247 289 543 minecraft:obsidian
fill 248 289 519 248 289 523 minecraft:obsidian
setblock 248 289 524 minecraft:purple_concrete
setblock 248 289 539 minecraft:purple_concrete
fill 248 289 540 248 289 543 minecraft:obsidian
fill 249 289 519 250 289 522 minecraft:obsidian
fill 249 289 523 250 289 523 minecraft:purple_concrete
setblock 249 289 540 minecraft:purple_concrete
fill 249 289 541 249 289 543 minecraft:obsidian
fill 250 289 541 251 289 541 minecraft:purple_concrete
fill 250 289 542 251 289 543 minecraft:obsidian
fill 251 289 519 252 289 521 minecraft:obsidian
fill 251 289 522 252 289 522 minecraft:purple_concrete
fill 252 289 542 254 289 542 minecraft:purple_concrete
fill 252 289 543 254 289 543 minecraft:obsidian
fill 253 289 519 275 289 520 minecraft:obsidian
fill 253 289 521 259 289 521 minecraft:purple_concrete
fill 255 289 543 256 290 543 minecraft:purple_concrete
fill 256 289 510 256 299 510 minecraft:black_concrete
fill 257 289 542 260 289 542 minecraft:purple_concrete
fill 257 289 543 275 289 543 minecraft:obsidian
fill 260 289 521 275 289 521 minecraft:obsidian
fill 260 289 522 261 289 522 minecraft:purple_concrete
setblock 261 289 541 minecraft:purple_concrete
fill 261 289 542 275 289 542 minecraft:obsidian
fill 262 289 522 275 289 522 minecraft:obsidian
setblock 262 289 523 minecraft:purple_concrete
schedule function dropper:buildpart/125_3 1t
