setblock 163 -24 363 minecraft:dark_prismarine
fill 164 -24 323 164 -21 323 minecraft:blue_terracotta
setblock 164 -24 362 minecraft:dark_prismarine
fill 164 -24 363 167 -24 363 minecraft:blue_terracotta
fill 165 -24 362 165 -22 362 minecraft:blue_terracotta
setblock 166 -24 325 minecraft:dark_prismarine
fill 166 -24 357 166 33 357 minecraft:magenta_terracotta
setblock 167 -24 324 minecraft:dark_prismarine
fill 167 -24 362 167 -23 362 minecraft:blue_terracotta
setblock 168 -24 323 minecraft:dark_prismarine
setblock 168 -24 324 minecraft:blue_terracotta
setblock 168 -24 363 minecraft:dark_prismarine
fill 169 -24 323 169 -23 323 minecraft:blue_terracotta
fill 169 -24 363 169 -23 363 minecraft:blue_terracotta
setblock 173 -24 323 minecraft:purple_concrete
setblock 178 -24 323 minecraft:dark_prismarine
fill 179 -24 323 179 -23 323 minecraft:blue_terracotta
setblock 180 -24 342 minecraft:blue_terracotta
setblock 180 -24 346 minecraft:dark_prismarine
fill 180 -24 347 180 -21 347 minecraft:blue_terracotta
fill 180 -24 352 180 -21 352 minecraft:blue_terracotta
setblock 181 -24 325 minecraft:dark_prismarine
fill 181 -24 326 181 -24 329 minecraft:blue_terracotta
setblock 181 -24 330 minecraft:dark_prismarine
fill 181 -24 331 181 -21 331 minecraft:blue_terracotta
fill 181 -24 333 181 -24 334 minecraft:blue_terracotta
setblock 181 -24 340 minecraft:dark_prismarine
fill 181 -24 341 181 -21 341 minecraft:blue_terracotta
setblock 181 -24 345 minecraft:dark_prismarine
fill 181 -24 346 181 -21 346 minecraft:blue_terracotta
setblock 181 -24 350 minecraft:dark_prismarine
fill 181 -24 351 181 -21 351 minecraft:blue_terracotta
setblock 181 -24 355 minecraft:dark_prismarine
setblock 182 -24 324 minecraft:dark_prismarine
fill 182 -24 325 182 -21 325 minecraft:blue_terracotta
setblock 182 -24 328 minecraft:blue_terracotta
setblock 182 -24 329 minecraft:dark_prismarine
fill 182 -24 330 182 -21 330 minecraft:blue_terracotta
setblock 182 -24 334 minecraft:dark_prismarine
fill 182 -24 335 182 -21 335 minecraft:blue_terracotta
setblock 182 -24 339 minecraft:dark_prismarine
fill 182 -24 340 182 -21 340 minecraft:blue_terracotta
setblock 182 -24 344 minecraft:dark_prismarine
fill 182 -24 345 182 -21 345 minecraft:blue_terracotta
setblock 182 -24 349 minecraft:dark_prismarine
fill 182 -24 350 182 -21 350 minecraft:blue_terracotta
setblock 182 -24 354 minecraft:dark_prismarine
fill 182 -24 355 182 -21 355 minecraft:blue_terracotta
setblock 182 -24 359 minecraft:dark_prismarine
setblock 182 -24 360 minecraft:blue_terracotta
fill 183 -24 324 183 132 324 minecraft:black_concrete
setblock 142 -23 323 minecraft:dark_prismarine
fill 142 -23 324 142 -23 327 minecraft:blue_terracotta
setblock 142 -23 328 minecraft:dark_prismarine
fill 142 -23 329 142 -20 329 minecraft:blue_terracotta
setblock 142 -23 333 minecraft:dark_prismarine
fill 142 -23 334 142 -20 334 minecraft:blue_terracotta
setblock 142 -23 338 minecraft:dark_prismarine
fill 142 -23 339 142 -20 339 minecraft:blue_terracotta
setblock 142 -23 343 minecraft:dark_prismarine
fill 142 -23 344 142 -20 344 minecraft:blue_terracotta
setblock 142 -23 348 minecraft:dark_prismarine
fill 142 -23 349 142 -20 349 minecraft:blue_terracotta
setblock 142 -23 353 minecraft:dark_prismarine
fill 142 -23 354 142 -20 354 minecraft:blue_terracotta
setblock 142 -23 363 minecraft:dark_prismarine
fill 143 -23 323 143 -23 326 minecraft:blue_terracotta
setblock 143 -23 327 minecraft:dark_prismarine
fill 143 -23 328 143 -20 328 minecraft:blue_terracotta
setblock 143 -23 332 minecraft:dark_prismarine
fill 143 -23 333 143 -20 333 minecraft:blue_terracotta
setblock 143 -23 337 minecraft:dark_prismarine
fill 143 -23 338 143 -22 338 minecraft:blue_terracotta
setblock 143 -23 342 minecraft:dark_prismarine
fill 143 -23 343 143 -22 343 minecraft:blue_terracotta
setblock 143 -23 347 minecraft:dark_prismarine
fill 143 -23 348 143 -20 348 minecraft:blue_terracotta
setblock 143 -23 352 minecraft:dark_prismarine
setblock 143 -23 353 minecraft:blue_terracotta
fill 143 -23 363 146 -23 363 minecraft:blue_terracotta
fill 144 -23 323 146 -23 323 minecraft:blue_terracotta
setblock 144 -23 325 minecraft:blue_terracotta
setblock 144 -23 326 minecraft:dark_prismarine
fill 144 -23 327 144 -20 327 minecraft:blue_terracotta
setblock 144 -23 331 minecraft:dark_prismarine
fill 144 -23 332 144 -20 332 minecraft:blue_terracotta
setblock 144 -23 346 minecraft:dark_prismarine
setblock 144 -23 347 minecraft:blue_terracotta
setblock 145 -23 325 minecraft:dark_prismarine
setblock 145 -23 326 minecraft:blue_terracotta
setblock 145 -23 330 minecraft:dark_prismarine
fill 145 -23 337 147 33 337 minecraft:magenta_terracotta
setblock 146 -23 324 minecraft:dark_prismarine
fill 146 -23 325 146 -21 325 minecraft:blue_terracotta
fill 146 -23 338 147 -11 338 minecraft:magenta_terracotta
setblock 147 -23 323 minecraft:dark_prismarine
fill 147 -23 324 147 -21 324 minecraft:blue_terracotta
fill 148 -23 323 151 -23 323 minecraft:blue_terracotta
setblock 151 -23 324 minecraft:dark_prismarine
setblock 152 -23 323 minecraft:dark_prismarine
setblock 152 -23 324 minecraft:blue_terracotta
fill 153 -23 323 156 -23 323 minecraft:blue_terracotta
fill 153 -23 351 153 -16 353 minecraft:magenta_terracotta
setblock 155 -23 324 minecraft:blue_terracotta
setblock 156 -23 324 minecraft:dark_prismarine
setblock 156 -23 363 minecraft:blue_terracotta
setblock 157 -23 323 minecraft:dark_prismarine
setblock 157 -23 363 minecraft:dark_prismarine
fill 158 -23 323 161 -23 323 minecraft:blue_terracotta
fill 158 -23 363 161 -23 363 minecraft:blue_terracotta
setblock 159 -23 362 minecraft:blue_terracotta
setblock 160 -23 324 minecraft:blue_terracotta
setblock 160 -23 325 minecraft:dark_prismarine
setblock 161 -23 324 minecraft:dark_prismarine
fill 161 -23 325 161 -22 325 minecraft:blue_terracotta
setblock 162 -23 323 minecraft:dark_prismarine
fill 162 -23 324 162 -20 324 minecraft:blue_terracotta
setblock 162 -23 363 minecraft:dark_prismarine
fill 163 -23 323 163 -20 323 minecraft:blue_terracotta
setblock 163 -23 362 minecraft:dark_prismarine
fill 163 -23 363 166 -23 363 minecraft:blue_terracotta
fill 164 -23 362 164 -21 362 minecraft:blue_terracotta
setblock 165 -23 325 minecraft:dark_prismarine
setblock 166 -23 324 minecraft:dark_prismarine
setblock 167 -23 323 minecraft:dark_prismarine
setblock 167 -23 324 minecraft:blue_terracotta
setblock 167 -23 363 minecraft:dark_prismarine
setblock 168 -23 323 minecraft:blue_terracotta
fill 168 -23 363 168 -22 363 minecraft:blue_terracotta
fill 173 -23 331 173 -22 331 minecraft:magenta_terracotta
setblock 176 -23 363 minecraft:purple_concrete
setblock 180 -23 345 minecraft:dark_prismarine
fill 180 -23 346 180 -20 346 minecraft:blue_terracotta
setblock 181 -23 324 minecraft:dark_prismarine
fill 181 -23 325 181 -23 328 minecraft:blue_terracotta
setblock 181 -23 329 minecraft:dark_prismarine
fill 181 -23 330 181 -20 330 minecraft:blue_terracotta
setblock 181 -23 333 minecraft:blue_terracotta
setblock 181 -23 334 minecraft:dark_prismarine
fill 181 -23 335 181 -22 337 minecraft:blue_terracotta
setblock 181 -23 339 minecraft:dark_prismarine
fill 181 -23 340 181 -20 340 minecraft:blue_terracotta
setblock 181 -23 344 minecraft:dark_prismarine
fill 181 -23 345 181 -20 345 minecraft:blue_terracotta
setblock 181 -23 349 minecraft:dark_prismarine
fill 181 -23 350 181 -20 350 minecraft:blue_terracotta
setblock 181 -23 354 minecraft:dark_prismarine
fill 181 -23 355 181 -20 355 minecraft:blue_terracotta
setblock 182 -23 323 minecraft:dark_prismarine
fill 182 -23 324 182 -20 324 minecraft:blue_terracotta
setblock 182 -23 328 minecraft:dark_prismarine
fill 182 -23 329 182 -20 329 minecraft:blue_terracotta
setblock 182 -23 333 minecraft:dark_prismarine
fill 182 -23 334 182 -20 334 minecraft:blue_terracotta
setblock 182 -23 338 minecraft:dark_prismarine
fill 182 -23 339 182 -20 339 minecraft:blue_terracotta
setblock 182 -23 343 minecraft:dark_prismarine
fill 182 -23 344 182 -20 344 minecraft:blue_terracotta
setblock 182 -23 348 minecraft:dark_prismarine
fill 182 -23 349 182 -20 349 minecraft:blue_terracotta
setblock 182 -23 353 minecraft:dark_prismarine
fill 182 -23 354 182 -20 354 minecraft:blue_terracotta
setblock 182 -23 358 minecraft:dark_prismarine
setblock 182 -23 363 minecraft:dark_prismarine
fill 142 -22 323 142 -22 326 minecraft:blue_terracotta
setblock 142 -22 327 minecraft:dark_prismarine
fill 142 -22 328 142 -19 328 minecraft:blue_terracotta
setblock 142 -22 332 minecraft:dark_prismarine
fill 142 -22 333 142 -19 333 minecraft:blue_terracotta
setblock 142 -22 337 minecraft:dark_prismarine
fill 142 -22 338 142 -19 338 minecraft:blue_terracotta
setblock 142 -22 342 minecraft:dark_prismarine
fill 142 -22 343 142 -19 343 minecraft:blue_terracotta
setblock 142 -22 347 minecraft:dark_prismarine
fill 142 -22 348 142 -19 348 minecraft:blue_terracotta
setblock 142 -22 352 minecraft:dark_prismarine
fill 142 -22 353 142 -19 353 minecraft:blue_terracotta
setblock 142 -22 359 minecraft:purple_concrete
fill 143 -22 323 143 -22 325 minecraft:blue_terracotta
setblock 143 -22 326 minecraft:dark_prismarine
fill 143 -22 327 143 -19 327 minecraft:blue_terracotta
setblock 143 -22 331 minecraft:dark_prismarine
fill 143 -22 332 143 -19 332 minecraft:blue_terracotta
setblock 143 -22 336 minecraft:dark_prismarine
fill 143 -22 337 143 -19 337 minecraft:blue_terracotta
setblock 143 -22 341 minecraft:dark_prismarine
setblock 143 -22 342 minecraft:blue_terracotta
setblock 143 -22 346 minecraft:dark_prismarine
fill 143 -22 347 143 -21 347 minecraft:blue_terracotta
setblock 143 -22 351 minecraft:dark_prismarine
fill 143 -22 352 143 -20 352 minecraft:blue_terracotta
fill 144 -22 323 145 -22 323 minecraft:blue_terracotta
setblock 144 -22 325 minecraft:dark_prismarine
fill 144 -22 326 144 -19 326 minecraft:blue_terracotta
setblock 144 -22 330 minecraft:dark_prismarine
fill 144 -22 331 144 -19 331 minecraft:blue_terracotta
fill 144 -22 363 144 -21 363 minecraft:purple_concrete
setblock 145 -22 324 minecraft:dark_prismarine
fill 145 -22 325 145 -21 325 minecraft:blue_terracotta
setblock 145 -22 329 minecraft:dark_prismarine
setblock 145 -22 330 minecraft:blue_terracotta
setblock 146 -22 323 minecraft:dark_prismarine
fill 146 -22 324 146 -20 324 minecraft:blue_terracotta
fill 147 -22 323 150 -22 323 minecraft:blue_terracotta
setblock 150 -22 324 minecraft:dark_prismarine
fill 150 -22 350 150 7 350 minecraft:magenta_terracotta
setblock 151 -22 323 minecraft:dark_prismarine
fill 152 -22 323 155 -22 323 minecraft:blue_terracotta
setblock 155 -22 324 minecraft:dark_prismarine
setblock 156 -22 323 minecraft:dark_prismarine
setblock 156 -22 324 minecraft:blue_terracotta
fill 157 -22 323 160 -22 323 minecraft:blue_terracotta
fill 157 -22 363 160 -22 363 minecraft:blue_terracotta
setblock 160 -22 324 minecraft:dark_prismarine
setblock 160 -22 325 minecraft:blue_terracotta
setblock 161 -22 323 minecraft:dark_prismarine
fill 161 -22 324 161 -19 324 minecraft:blue_terracotta
setblock 161 -22 363 minecraft:dark_prismarine
fill 162 -22 323 162 -19 323 minecraft:blue_terracotta
setblock 162 -22 362 minecraft:dark_prismarine
fill 162 -22 363 165 -22 363 minecraft:blue_terracotta
fill 163 -22 362 163 -21 362 minecraft:blue_terracotta
setblock 165 -22 324 minecraft:dark_prismarine
setblock 166 -22 323 minecraft:dark_prismarine
setblock 166 -22 324 minecraft:blue_terracotta
setblock 166 -22 363 minecraft:dark_prismarine
setblock 167 -22 323 minecraft:blue_terracotta
setblock 167 -22 363 minecraft:blue_terracotta
fill 173 -22 336 173 33 336 minecraft:magenta_terracotta
setblock 180 -22 344 minecraft:dark_prismarine
fill 180 -22 345 180 -21 345 minecraft:blue_terracotta
setblock 181 -22 323 minecraft:dark_prismarine
fill 181 -22 325 181 -22 327 minecraft:blue_terracotta
setblock 181 -22 328 minecraft:dark_prismarine
fill 181 -22 329 181 -19 329 minecraft:blue_terracotta
setblock 181 -22 333 minecraft:dark_prismarine
fill 181 -22 334 181 -19 334 minecraft:blue_terracotta
setblock 181 -22 338 minecraft:dark_prismarine
fill 181 -22 339 181 -19 339 minecraft:blue_terracotta
setblock 181 -22 343 minecraft:dark_prismarine
fill 181 -22 344 181 -19 344 minecraft:blue_terracotta
setblock 181 -22 348 minecraft:dark_prismarine
fill 181 -22 349 181 -19 349 minecraft:blue_terracotta
setblock 181 -22 353 minecraft:dark_prismarine
fill 181 -22 354 181 -19 354 minecraft:blue_terracotta
fill 182 -22 323 182 -19 323 minecraft:blue_terracotta
setblock 182 -22 327 minecraft:dark_prismarine
fill 182 -22 328 182 -19 328 minecraft:blue_terracotta
setblock 182 -22 332 minecraft:dark_prismarine
fill 182 -22 333 182 -19 333 minecraft:blue_terracotta
setblock 182 -22 337 minecraft:dark_prismarine
fill 182 -22 338 182 -19 338 minecraft:blue_terracotta
setblock 182 -22 342 minecraft:dark_prismarine
fill 182 -22 343 182 -19 343 minecraft:blue_terracotta
setblock 182 -22 347 minecraft:dark_prismarine
fill 182 -22 348 182 -19 348 minecraft:blue_terracotta
setblock 182 -22 352 minecraft:dark_prismarine
fill 182 -22 353 182 -19 353 minecraft:blue_terracotta
setblock 182 -22 357 minecraft:dark_prismarine
setblock 182 -22 363 minecraft:purple_concrete
fill 183 -22 351 183 -14 355 minecraft:black_concrete
setblock 183 -22 356 minecraft:cyan_concrete
fill 183 -22 357 183 -22 363 minecraft:black_concrete
fill 142 -21 323 142 -21 325 minecraft:blue_terracotta
setblock 142 -21 326 minecraft:dark_prismarine
fill 142 -21 327 142 -18 327 minecraft:blue_terracotta
setblock 142 -21 331 minecraft:dark_prismarine
fill 142 -21 332 142 -18 332 minecraft:blue_terracotta
setblock 142 -21 336 minecraft:dark_prismarine
fill 142 -21 337 142 -18 337 minecraft:blue_terracotta
setblock 142 -21 341 minecraft:dark_prismarine
fill 142 -21 342 142 -18 342 minecraft:blue_terracotta
setblock 142 -21 346 minecraft:dark_prismarine
fill 142 -21 347 142 -18 347 minecraft:blue_terracotta
setblock 142 -21 351 minecraft:dark_prismarine
fill 142 -21 352 142 -18 352 minecraft:blue_terracotta
fill 143 -21 323 143 -21 324 minecraft:blue_terracotta
setblock 143 -21 325 minecraft:dark_prismarine
fill 143 -21 326 143 -18 326 minecraft:blue_terracotta
setblock 143 -21 330 minecraft:dark_prismarine
fill 143 -21 331 143 -18 331 minecraft:blue_terracotta
setblock 143 -21 335 minecraft:dark_prismarine
fill 143 -21 336 143 -18 336 minecraft:blue_terracotta
setblock 143 -21 345 minecraft:dark_prismarine
setblock 143 -21 346 minecraft:blue_terracotta
setblock 143 -21 350 minecraft:dark_prismarine
fill 143 -21 351 143 -19 351 minecraft:blue_terracotta
setblock 144 -21 323 minecraft:blue_terracotta
setblock 144 -21 324 minecraft:dark_prismarine
fill 144 -21 325 144 -20 325 minecraft:blue_terracotta
setblock 144 -21 329 minecraft:dark_prismarine
fill 144 -21 330 144 -18 330 minecraft:blue_terracotta
setblock 145 -21 323 minecraft:dark_prismarine
fill 145 -21 324 145 -19 324 minecraft:blue_terracotta
fill 146 -21 323 149 -21 323 minecraft:blue_terracotta
setblock 150 -21 323 minecraft:dark_prismarine
setblock 150 -21 363 minecraft:purple_concrete
fill 151 -21 323 154 -21 323 minecraft:blue_terracotta
fill 152 -21 350 152 8 350 minecraft:magenta_terracotta
setblock 155 -21 323 minecraft:dark_prismarine
fill 156 -21 323 159 -21 323 minecraft:blue_terracotta
setblock 157 -21 324 minecraft:magenta_terracotta
fill 157 -21 363 159 -21 363 minecraft:blue_terracotta
setblock 158 -21 324 minecraft:blue_terracotta
setblock 159 -21 324 minecraft:dark_prismarine
setblock 160 -21 323 minecraft:dark_prismarine
fill 160 -21 324 160 -18 324 minecraft:blue_terracotta
setblock 160 -21 363 minecraft:dark_prismarine
fill 161 -21 323 161 -18 323 minecraft:blue_terracotta
setblock 161 -21 362 minecraft:dark_prismarine
fill 161 -21 363 164 -21 363 minecraft:blue_terracotta
fill 162 -21 362 162 -18 362 minecraft:blue_terracotta
setblock 164 -21 324 minecraft:dark_prismarine
setblock 165 -21 323 minecraft:dark_prismarine
setblock 165 -21 363 minecraft:dark_prismarine
setblock 166 -21 323 minecraft:blue_terracotta
setblock 166 -21 363 minecraft:blue_terracotta
setblock 169 -21 363 minecraft:purple_concrete
setblock 174 -21 323 minecraft:purple_concrete
setblock 180 -21 323 minecraft:dark_prismarine
setblock 180 -21 348 minecraft:dark_prismarine
setblock 180 -21 353 minecraft:dark_prismarine
fill 181 -21 323 181 -20 323 minecraft:blue_terracotta
fill 181 -21 325 181 -21 326 minecraft:blue_terracotta
setblock 181 -21 327 minecraft:dark_prismarine
fill 181 -21 328 181 -18 328 minecraft:blue_terracotta
setblock 181 -21 332 minecraft:dark_prismarine
fill 181 -21 333 181 -18 333 minecraft:blue_terracotta
fill 181 -21 335 181 -21 336 minecraft:blue_terracotta
setblock 181 -21 337 minecraft:dark_prismarine
fill 181 -21 338 181 -18 338 minecraft:blue_terracotta
setblock 181 -21 342 minecraft:dark_prismarine
fill 181 -21 343 181 -18 343 minecraft:blue_terracotta
setblock 181 -21 347 minecraft:dark_prismarine
fill 181 -21 348 181 -18 348 minecraft:blue_terracotta
setblock 181 -21 352 minecraft:dark_prismarine
fill 181 -21 353 181 -18 353 minecraft:blue_terracotta
setblock 182 -21 326 minecraft:dark_prismarine
fill 182 -21 327 182 -18 327 minecraft:blue_terracotta
setblock 182 -21 331 minecraft:dark_prismarine
fill 182 -21 332 182 -18 332 minecraft:blue_terracotta
setblock 182 -21 336 minecraft:dark_prismarine
fill 182 -21 337 182 -18 337 minecraft:blue_terracotta
setblock 182 -21 341 minecraft:dark_prismarine
fill 182 -21 342 182 -18 342 minecraft:blue_terracotta
setblock 182 -21 346 minecraft:dark_prismarine
fill 182 -21 347 182 -18 347 minecraft:blue_terracotta
setblock 182 -21 351 minecraft:dark_prismarine
fill 182 -21 352 182 -18 352 minecraft:blue_terracotta
setblock 182 -21 356 minecraft:dark_prismarine
fill 182 -21 357 182 -18 357 minecraft:blue_terracotta
setblock 182 -21 359 minecraft:purple_concrete
setblock 183 -21 333 minecraft:light_blue_wool
fill 183 -21 334 183 -9 339 minecraft:black_concrete
fill 183 -21 356 183 -14 357 minecraft:black_concrete
setblock 183 -21 358 minecraft:cyan_concrete
fill 183 -21 359 183 53 363 minecraft:black_concrete
fill 142 -20 323 142 -20 324 minecraft:blue_terracotta
setblock 142 -20 325 minecraft:dark_prismarine
fill 142 -20 326 142 -17 326 minecraft:blue_terracotta
setblock 142 -20 330 minecraft:dark_prismarine
fill 142 -20 331 142 -17 331 minecraft:blue_terracotta
setblock 142 -20 335 minecraft:dark_prismarine
fill 142 -20 336 142 -17 336 minecraft:blue_terracotta
setblock 142 -20 340 minecraft:dark_prismarine
fill 142 -20 341 142 -17 341 minecraft:blue_terracotta
setblock 142 -20 345 minecraft:dark_prismarine
fill 142 -20 346 142 -17 346 minecraft:blue_terracotta
setblock 142 -20 350 minecraft:dark_prismarine
fill 142 -20 351 142 -17 351 minecraft:blue_terracotta
setblock 142 -20 355 minecraft:dark_prismarine
fill 142 -20 356 142 -17 356 minecraft:blue_terracotta
setblock 143 -20 323 minecraft:blue_terracotta
setblock 143 -20 324 minecraft:dark_prismarine
fill 143 -20 325 143 -17 325 minecraft:blue_terracotta
setblock 143 -20 329 minecraft:dark_prismarine
fill 143 -20 330 143 -17 330 minecraft:blue_terracotta
setblock 143 -20 334 minecraft:dark_prismarine
fill 143 -20 335 143 -17 335 minecraft:blue_terracotta
setblock 143 -20 349 minecraft:dark_prismarine
setblock 143 -20 350 minecraft:blue_terracotta
setblock 144 -20 323 minecraft:dark_prismarine
fill 144 -20 324 144 -18 324 minecraft:blue_terracotta
setblock 144 -20 328 minecraft:dark_prismarine
fill 144 -20 329 144 -17 329 minecraft:blue_terracotta
setblock 144 -20 333 minecraft:dark_prismarine
fill 145 -20 323 148 -20 323 minecraft:blue_terracotta
setblock 149 -20 323 minecraft:dark_prismarine
setblock 154 -20 323 minecraft:dark_prismarine
fill 155 -20 323 158 -20 323 minecraft:blue_terracotta
setblock 156 -20 363 minecraft:purple_concrete
setblock 157 -20 324 minecraft:blue_terracotta
fill 157 -20 363 158 -20 363 minecraft:blue_terracotta
setblock 158 -20 324 minecraft:dark_prismarine
setblock 159 -20 323 minecraft:dark_prismarine
fill 159 -20 324 159 -17 324 minecraft:blue_terracotta
setblock 159 -20 363 minecraft:dark_prismarine
fill 160 -20 323 160 -17 323 minecraft:blue_terracotta
setblock 160 -20 362 minecraft:dark_prismarine
fill 160 -20 363 163 -20 363 minecraft:blue_terracotta
fill 161 -20 362 161 -17 362 minecraft:blue_terracotta
setblock 163 -20 324 minecraft:dark_prismarine
setblock 164 -20 323 minecraft:dark_prismarine
setblock 164 -20 363 minecraft:dark_prismarine
setblock 165 -20 323 minecraft:blue_terracotta
fill 165 -20 363 165 -19 363 minecraft:blue_terracotta
setblock 168 -20 323 minecraft:purple_concrete
fill 172 -20 332 174 -12 332 minecraft:magenta_terracotta
fill 175 -20 335 175 7 335 minecraft:magenta_terracotta
setblock 175 -20 363 minecraft:purple_concrete
fill 180 -20 330 180 -20 331 minecraft:blue_terracotta
setblock 180 -20 347 minecraft:dark_prismarine
fill 180 -20 348 180 -17 348 minecraft:blue_terracotta
setblock 180 -20 352 minecraft:dark_prismarine
fill 180 -20 353 180 -17 353 minecraft:blue_terracotta
setblock 181 -20 326 minecraft:dark_prismarine
fill 181 -20 327 181 -17 327 minecraft:blue_terracotta
setblock 181 -20 331 minecraft:dark_prismarine
fill 181 -20 332 181 -17 332 minecraft:blue_terracotta
setblock 181 -20 335 minecraft:blue_terracotta
setblock 181 -20 336 minecraft:dark_prismarine
fill 181 -20 337 181 -17 337 minecraft:blue_terracotta
setblock 181 -20 341 minecraft:dark_prismarine
fill 181 -20 342 181 -17 342 minecraft:blue_terracotta
setblock 181 -20 346 minecraft:dark_prismarine
fill 181 -20 347 181 -17 347 minecraft:blue_terracotta
setblock 181 -20 351 minecraft:dark_prismarine
fill 181 -20 352 181 -17 352 minecraft:blue_terracotta
setblock 182 -20 325 minecraft:dark_prismarine
fill 182 -20 326 182 -17 326 minecraft:blue_terracotta
setblock 182 -20 330 minecraft:dark_prismarine
fill 182 -20 331 182 -17 331 minecraft:blue_terracotta
setblock 182 -20 335 minecraft:dark_prismarine
fill 182 -20 336 182 -17 336 minecraft:blue_terracotta
setblock 182 -20 340 minecraft:dark_prismarine
fill 182 -20 341 182 -17 341 minecraft:blue_terracotta
setblock 182 -20 345 minecraft:dark_prismarine
fill 182 -20 346 182 -17 346 minecraft:blue_terracotta
setblock 182 -20 350 minecraft:dark_prismarine
fill 182 -20 351 182 -17 351 minecraft:blue_terracotta
setblock 182 -20 355 minecraft:dark_prismarine
fill 182 -20 356 182 -17 356 minecraft:blue_terracotta
fill 183 -20 333 183 131 333 minecraft:black_concrete
fill 183 -20 358 183 127 358 minecraft:black_concrete
setblock 142 -19 323 minecraft:blue_terracotta
setblock 142 -19 324 minecraft:dark_prismarine
fill 142 -19 325 142 -16 325 minecraft:blue_terracotta
setblock 142 -19 329 minecraft:dark_prismarine
fill 142 -19 330 142 -16 330 minecraft:blue_terracotta
setblock 142 -19 334 minecraft:dark_prismarine
fill 142 -19 335 142 -16 335 minecraft:blue_terracotta
setblock 142 -19 339 minecraft:dark_prismarine
fill 142 -19 340 142 -16 340 minecraft:blue_terracotta
setblock 142 -19 344 minecraft:dark_prismarine
fill 142 -19 345 142 -17 345 minecraft:blue_terracotta
setblock 142 -19 349 minecraft:dark_prismarine
fill 142 -19 350 142 -16 350 minecraft:blue_terracotta
setblock 142 -19 354 minecraft:dark_prismarine
fill 142 -19 355 142 -16 355 minecraft:blue_terracotta
setblock 142 -19 358 minecraft:purple_concrete
setblock 143 -19 323 minecraft:dark_prismarine
fill 143 -19 324 143 -16 324 minecraft:blue_terracotta
setblock 143 -19 328 minecraft:dark_prismarine
fill 143 -19 329 143 -16 329 minecraft:blue_terracotta
setblock 143 -19 333 minecraft:dark_prismarine
fill 143 -19 334 143 -16 334 minecraft:blue_terracotta
fill 144 -19 323 147 -19 323 minecraft:blue_terracotta
setblock 144 -19 325 minecraft:light[level=13]
setblock 144 -19 327 minecraft:dark_prismarine
fill 144 -19 328 144 -16 328 minecraft:blue_terracotta
setblock 144 -19 332 minecraft:dark_prismarine
fill 144 -19 333 144 -16 333 minecraft:blue_terracotta
setblock 144 -19 339 minecraft:light[level=12]
setblock 144 -19 341 minecraft:light[level=13]
setblock 144 -19 346 minecraft:light[level=12]
setblock 144 -19 349 minecraft:light[level=13]
setblock 144 -19 353 minecraft:light[level=12]
setblock 144 -19 357 minecraft:light[level=13]
setblock 144 -19 360 minecraft:light[level=12]
setblock 151 -19 325 minecraft:light[level=12]
setblock 151 -19 332 minecraft:light[level=12]
setblock 151 -19 339 minecraft:light[level=12]
setblock 151 -19 346 minecraft:light[level=12]
setblock 151 -19 360 minecraft:light[level=12]
setblock 152 -19 325 minecraft:light[level=13]
setblock 152 -19 333 minecraft:light[level=13]
setblock 152 -19 341 minecraft:light[level=13]
setblock 152 -19 349 minecraft:light[level=13]
setblock 152 -19 357 minecraft:light[level=13]
fill 155 -19 323 157 -19 323 minecraft:blue_terracotta
fill 156 -19 363 157 -19 363 minecraft:blue_terracotta
fill 157 -19 329 157 25 329 minecraft:magenta_terracotta
setblock 158 -19 323 minecraft:dark_prismarine
fill 158 -19 324 158 -18 324 minecraft:blue_terracotta
setblock 158 -19 332 minecraft:light[level=12]
setblock 158 -19 339 minecraft:light[level=12]
setblock 158 -19 346 minecraft:light[level=12]
setblock 158 -19 353 minecraft:light[level=12]
setblock 158 -19 360 minecraft:light[level=12]
setblock 158 -19 363 minecraft:dark_prismarine
fill 159 -19 323 159 -16 323 minecraft:blue_terracotta
fill 159 -19 363 162 -19 363 minecraft:blue_terracotta
setblock 160 -19 325 minecraft:light[level=13]
setblock 160 -19 333 minecraft:light[level=13]
setblock 160 -19 349 minecraft:light[level=13]
setblock 160 -19 357 minecraft:light[level=13]
fill 160 -19 362 160 -16 362 minecraft:blue_terracotta
setblock 163 -19 323 minecraft:dark_prismarine
setblock 163 -19 363 minecraft:dark_prismarine
setblock 164 -19 323 minecraft:blue_terracotta
fill 164 -19 363 164 -16 363 minecraft:blue_terracotta
setblock 165 -19 325 minecraft:light[level=12]
setblock 165 -19 332 minecraft:light[level=12]
setblock 165 -19 339 minecraft:light[level=12]
setblock 165 -19 346 minecraft:light[level=12]
setblock 165 -19 353 minecraft:light[level=12]
setblock 168 -19 325 minecraft:light[level=13]
setblock 168 -19 333 minecraft:light[level=13]
setblock 168 -19 341 minecraft:light[level=13]
setblock 168 -19 349 minecraft:light[level=13]
setblock 168 -19 357 minecraft:light[level=13]
setblock 172 -19 325 minecraft:light[level=12]
fill 172 -19 336 172 14 336 minecraft:magenta_terracotta
setblock 172 -19 339 minecraft:light[level=12]
setblock 172 -19 346 minecraft:light[level=12]
setblock 172 -19 353 minecraft:light[level=12]
setblock 172 -19 360 minecraft:light[level=12]
setblock 176 -19 325 minecraft:light[level=13]
setblock 176 -19 333 minecraft:light[level=13]
setblock 176 -19 341 minecraft:light[level=13]
setblock 179 -19 325 minecraft:light[level=12]
setblock 179 -19 332 minecraft:light[level=12]
setblock 179 -19 339 minecraft:light[level=12]
setblock 179 -19 346 minecraft:light[level=12]
setblock 179 -19 353 minecraft:light[level=12]
setblock 179 -19 360 minecraft:light[level=12]
fill 180 -19 329 180 -19 330 minecraft:blue_terracotta
setblock 180 -19 331 minecraft:dark_prismarine
fill 180 -19 332 180 -18 334 minecraft:blue_terracotta
fill 180 -19 347 180 -18 347 minecraft:blue_terracotta
fill 180 -19 352 180 -16 352 minecraft:blue_terracotta
fill 181 -19 326 181 -16 326 minecraft:blue_terracotta
setblock 181 -19 330 minecraft:dark_prismarine
fill 181 -19 331 181 -16 331 minecraft:blue_terracotta
setblock 181 -19 335 minecraft:dark_prismarine
fill 181 -19 336 181 -16 336 minecraft:blue_terracotta
setblock 181 -19 340 minecraft:dark_prismarine
fill 181 -19 341 181 -16 341 minecraft:blue_terracotta
setblock 181 -19 345 minecraft:dark_prismarine
fill 181 -19 346 181 -16 346 minecraft:blue_terracotta
setblock 181 -19 350 minecraft:dark_prismarine
fill 181 -19 351 181 -16 351 minecraft:blue_terracotta
setblock 181 -19 355 minecraft:dark_prismarine
fill 181 -19 356 181 -16 356 minecraft:blue_terracotta
setblock 181 -19 363 minecraft:purple_concrete
setblock 182 -19 324 minecraft:dark_prismarine
fill 182 -19 325 182 -16 325 minecraft:blue_terracotta
setblock 182 -19 329 minecraft:dark_prismarine
fill 182 -19 330 182 -16 330 minecraft:blue_terracotta
setblock 182 -19 334 minecraft:dark_prismarine
fill 182 -19 335 182 -16 335 minecraft:blue_terracotta
setblock 182 -19 339 minecraft:dark_prismarine
fill 182 -19 340 182 -16 340 minecraft:blue_terracotta
setblock 182 -19 344 minecraft:dark_prismarine
fill 182 -19 345 182 -16 345 minecraft:blue_terracotta
setblock 182 -19 349 minecraft:dark_prismarine
fill 182 -19 350 182 -16 350 minecraft:blue_terracotta
setblock 182 -19 354 minecraft:dark_prismarine
fill 182 -19 355 182 -16 355 minecraft:blue_terracotta
setblock 182 -19 358 minecraft:blue_terracotta
fill 142 -18 322 150 -18 322 minecraft:black_concrete
setblock 142 -18 323 minecraft:dark_prismarine
fill 142 -18 324 142 -15 324 minecraft:blue_terracotta
setblock 142 -18 328 minecraft:dark_prismarine
fill 142 -18 329 142 -15 329 minecraft:blue_terracotta
setblock 142 -18 333 minecraft:dark_prismarine
fill 142 -18 334 142 -15 334 minecraft:blue_terracotta
setblock 142 -18 338 minecraft:dark_prismarine
fill 142 -18 339 142 -15 339 minecraft:blue_terracotta
setblock 142 -18 343 minecraft:dark_prismarine
setblock 142 -18 344 minecraft:blue_terracotta
setblock 142 -18 348 minecraft:dark_prismarine
fill 142 -18 349 142 -15 349 minecraft:blue_terracotta
setblock 142 -18 353 minecraft:dark_prismarine
fill 142 -18 354 142 -15 354 minecraft:blue_terracotta
setblock 142 -18 357 minecraft:blue_terracotta
fill 143 -18 323 146 -18 323 minecraft:blue_terracotta
setblock 143 -18 327 minecraft:dark_prismarine
fill 143 -18 328 143 -15 328 minecraft:blue_terracotta
setblock 143 -18 332 minecraft:dark_prismarine
fill 143 -18 333 143 -15 333 minecraft:blue_terracotta
setblock 143 -18 337 minecraft:dark_prismarine
setblock 143 -18 363 minecraft:purple_concrete
fill 144 -18 327 144 -17 327 minecraft:blue_terracotta
setblock 144 -18 331 minecraft:dark_prismarine
fill 144 -18 332 144 -15 332 minecraft:blue_terracotta
fill 144 -18 334 144 -17 334 minecraft:blue_terracotta
fill 144 -18 336 145 18 336 minecraft:magenta_terracotta
fill 146 -18 336 146 -17 336 minecraft:pink_terracotta
fill 147 -18 336 148 -18 336 minecraft:magenta_terracotta
fill 150 -18 352 150 -18 354 minecraft:magenta_terracotta
setblock 151 -18 322 minecraft:cyan_concrete
fill 151 -18 352 151 -17 352 minecraft:pink_terracotta
fill 151 -18 353 152 -15 354 minecraft:magenta_terracotta
fill 152 -18 352 152 4 352 minecraft:magenta_terracotta
fill 154 -18 323 156 -18 323 minecraft:blue_terracotta
fill 155 -18 327 156 -17 327 minecraft:magenta_terracotta
fill 156 -18 326 159 -18 326 minecraft:magenta_terracotta
setblock 156 -18 363 minecraft:blue_terracotta
setblock 157 -18 323 minecraft:dark_prismarine
fill 157 -18 327 158 -17 327 minecraft:pink_terracotta
setblock 157 -18 363 minecraft:dark_prismarine
fill 158 -18 323 158 -15 323 minecraft:blue_terracotta
fill 158 -18 329 158 33 329 minecraft:magenta_terracotta
setblock 158 -18 362 minecraft:dark_prismarine
fill 158 -18 363 161 -18 363 minecraft:blue_terracotta
fill 159 -18 327 159 7 327 minecraft:magenta_terracotta
fill 159 -18 362 159 -15 362 minecraft:blue_terracotta
setblock 162 -18 323 minecraft:dark_prismarine
setblock 162 -18 363 minecraft:dark_prismarine
setblock 163 -18 323 minecraft:blue_terracotta
fill 163 -18 363 163 -15 363 minecraft:blue_terracotta
fill 165 -18 359 165 -15 361 minecraft:magenta_terracotta
fill 166 -18 359 167 -17 359 minecraft:pink_terracotta
fill 166 -18 360 168 -18 361 minecraft:magenta_terracotta
fill 168 -18 359 169 -15 359 minecraft:magenta_terracotta
setblock 168 -18 363 minecraft:purple_concrete
fill 171 -18 334 172 -18 334 minecraft:magenta_terracotta
fill 173 -18 334 173 -17 334 minecraft:pink_terracotta
setblock 174 -18 334 minecraft:magenta_terracotta
fill 174 -18 336 174 7 336 minecraft:magenta_terracotta
fill 176 -18 349 177 -18 351 minecraft:magenta_terracotta
fill 178 -18 349 179 33 349 minecraft:magenta_terracotta
fill 178 -18 350 178 -17 350 minecraft:pink_terracotta
fill 178 -18 351 179 -18 351 minecraft:magenta_terracotta
setblock 179 -18 350 minecraft:magenta_terracotta
setblock 180 -18 329 minecraft:blue_terracotta
setblock 180 -18 330 minecraft:dark_prismarine
fill 180 -18 331 180 -15 331 minecraft:blue_terracotta
setblock 180 -18 335 minecraft:dark_prismarine
fill 180 -18 336 180 -15 336 minecraft:blue_terracotta
setblock 180 -18 354 minecraft:blue_terracotta
setblock 181 -18 323 minecraft:purple_concrete
setblock 181 -18 329 minecraft:dark_prismarine
fill 181 -18 330 181 -15 330 minecraft:blue_terracotta
setblock 181 -18 334 minecraft:dark_prismarine
fill 181 -18 335 181 -15 335 minecraft:blue_terracotta
setblock 181 -18 339 minecraft:dark_prismarine
fill 181 -18 340 181 -15 340 minecraft:blue_terracotta
setblock 181 -18 344 minecraft:dark_prismarine
fill 181 -18 345 181 -15 345 minecraft:blue_terracotta
setblock 181 -18 349 minecraft:dark_prismarine
fill 181 -18 350 181 -15 350 minecraft:blue_terracotta
setblock 181 -18 354 minecraft:dark_prismarine
fill 181 -18 355 181 -15 355 minecraft:blue_terracotta
setblock 182 -18 323 minecraft:dark_prismarine
fill 182 -18 324 182 -15 324 minecraft:blue_terracotta
setblock 182 -18 328 minecraft:dark_prismarine
fill 182 -18 329 182 -15 329 minecraft:blue_terracotta
setblock 182 -18 333 minecraft:dark_prismarine
fill 182 -18 334 182 -15 334 minecraft:blue_terracotta
setblock 182 -18 338 minecraft:dark_prismarine
fill 182 -18 339 182 -15 339 minecraft:blue_terracotta
setblock 182 -18 343 minecraft:dark_prismarine
fill 182 -18 344 182 -15 344 minecraft:blue_terracotta
setblock 182 -18 348 minecraft:dark_prismarine
fill 182 -18 349 182 -15 349 minecraft:blue_terracotta
setblock 182 -18 353 minecraft:dark_prismarine
fill 182 -18 354 182 -15 354 minecraft:blue_terracotta
setblock 182 -18 358 minecraft:dark_prismarine
fill 183 -18 325 183 127 327 minecraft:black_concrete
setblock 183 -18 328 minecraft:light_blue_wool
fill 183 -18 329 183 131 329 minecraft:black_concrete
fill 142 -17 322 147 -4 322 minecraft:black_concrete
fill 142 -17 323 145 -17 323 minecraft:blue_terracotta
setblock 142 -17 327 minecraft:dark_prismarine
fill 142 -17 328 142 -14 328 minecraft:blue_terracotta
setblock 142 -17 332 minecraft:dark_prismarine
fill 142 -17 333 142 -14 333 minecraft:blue_terracotta
setblock 142 -17 337 minecraft:dark_prismarine
fill 142 -17 338 142 -14 338 minecraft:blue_terracotta
setblock 142 -17 342 minecraft:dark_prismarine
setblock 142 -17 347 minecraft:dark_prismarine
fill 142 -17 348 142 -15 348 minecraft:blue_terracotta
setblock 142 -17 352 minecraft:dark_prismarine
fill 142 -17 353 142 -14 353 minecraft:blue_terracotta
setblock 142 -17 357 minecraft:dark_prismarine
fill 142 -17 358 142 -15 359 minecraft:blue_terracotta
setblock 143 -17 326 minecraft:dark_prismarine
fill 143 -17 327 143 -14 327 minecraft:blue_terracotta
setblock 143 -17 331 minecraft:dark_prismarine
fill 143 -17 332 143 -14 332 minecraft:blue_terracotta
setblock 143 -17 336 minecraft:dark_prismarine
fill 143 -17 337 143 -14 337 minecraft:blue_terracotta
setblock 144 -17 330 minecraft:dark_prismarine
fill 144 -17 331 144 -14 331 minecraft:blue_terracotta
fill 145 -17 335 145 33 335 minecraft:magenta_terracotta
setblock 146 -17 323 minecraft:dark_prismarine
fill 146 -17 335 147 -17 335 minecraft:pink_terracotta
setblock 147 -17 336 minecraft:pink_terracotta
setblock 148 -17 322 minecraft:light_blue_wool
fill 148 -17 335 148 33 336 minecraft:magenta_terracotta
fill 149 -17 322 151 -7 322 minecraft:black_concrete
setblock 149 -17 363 minecraft:purple_concrete
setblock 150 -17 323 minecraft:purple_concrete
setblock 150 -17 352 minecraft:pink_terracotta
fill 150 -17 353 150 -10 354 minecraft:magenta_terracotta
setblock 151 -17 351 minecraft:pink_terracotta
fill 152 -17 351 152 10 351 minecraft:magenta_terracotta
fill 154 -17 323 155 -17 323 minecraft:blue_terracotta
setblock 155 -17 363 minecraft:blue_terracotta
setblock 156 -17 323 minecraft:dark_prismarine
fill 156 -17 326 156 0 326 minecraft:magenta_terracotta
setblock 156 -17 363 minecraft:dark_prismarine
fill 157 -17 323 157 -14 323 minecraft:blue_terracotta
fill 157 -17 326 158 -17 326 minecraft:pink_terracotta
setblock 157 -17 362 minecraft:dark_prismarine
fill 157 -17 363 160 -17 363 minecraft:blue_terracotta
fill 158 -17 362 158 -14 362 minecraft:blue_terracotta
fill 159 -17 326 159 24 326 minecraft:magenta_terracotta
setblock 161 -17 323 minecraft:dark_prismarine
setblock 161 -17 363 minecraft:dark_prismarine
fill 162 -17 323 162 -15 323 minecraft:blue_terracotta
setblock 162 -17 362 minecraft:dark_prismarine
fill 162 -17 363 162 -14 363 minecraft:blue_terracotta
fill 166 -17 360 167 -17 360 minecraft:pink_terracotta
fill 166 -17 361 168 -15 361 minecraft:magenta_terracotta
fill 168 -17 360 168 -3 360 minecraft:magenta_terracotta
fill 171 -17 333 171 -12 334 minecraft:magenta_terracotta
fill 172 -17 333 172 -1 333 minecraft:magenta_terracotta
setblock 172 -17 334 minecraft:pink_terracotta
fill 172 -17 335 172 14 335 minecraft:magenta_terracotta
setblock 173 -17 333 minecraft:pink_terracotta
setblock 173 -17 335 minecraft:pink_terracotta
fill 174 -17 333 175 6 333 minecraft:magenta_terracotta
setblock 174 -17 334 minecraft:pink_terracotta
setblock 174 -17 363 minecraft:purple_concrete
setblock 175 -17 323 minecraft:purple_concrete
fill 176 -17 349 176 10 351 minecraft:magenta_terracotta
fill 177 -17 349 177 33 349 minecraft:magenta_terracotta
setblock 177 -17 350 minecraft:pink_terracotta
fill 177 -17 351 177 33 351 minecraft:magenta_terracotta
setblock 178 -17 351 minecraft:pink_terracotta
setblock 179 -17 350 minecraft:pink_terracotta
fill 179 -17 351 179 33 351 minecraft:magenta_terracotta
setblock 180 -17 328 minecraft:blue_terracotta
setblock 180 -17 329 minecraft:dark_prismarine
fill 180 -17 330 180 -14 330 minecraft:blue_terracotta
fill 180 -17 332 180 -17 333 minecraft:blue_terracotta
setblock 180 -17 334 minecraft:dark_prismarine
fill 180 -17 335 180 -14 335 minecraft:blue_terracotta
fill 180 -17 337 180 -17 338 minecraft:blue_terracotta
setblock 180 -17 354 minecraft:dark_prismarine
fill 180 -17 355 180 -14 355 minecraft:blue_terracotta
setblock 181 -17 323 minecraft:dark_prismarine
setblock 181 -17 328 minecraft:dark_prismarine
fill 181 -17 329 181 -14 329 minecraft:blue_terracotta
setblock 181 -17 333 minecraft:dark_prismarine
fill 181 -17 334 181 -14 334 minecraft:blue_terracotta
setblock 181 -17 338 minecraft:dark_prismarine
fill 181 -17 339 181 -14 339 minecraft:blue_terracotta
setblock 181 -17 343 minecraft:dark_prismarine
fill 181 -17 344 181 -14 344 minecraft:blue_terracotta
setblock 181 -17 348 minecraft:dark_prismarine
fill 181 -17 349 181 -14 349 minecraft:blue_terracotta
setblock 181 -17 353 minecraft:dark_prismarine
fill 181 -17 354 181 -14 354 minecraft:blue_terracotta
setblock 181 -17 357 minecraft:blue_terracotta
fill 182 -17 323 182 -14 323 minecraft:blue_terracotta
setblock 182 -17 327 minecraft:dark_prismarine
fill 182 -17 328 182 -14 328 minecraft:blue_terracotta
setblock 182 -17 332 minecraft:dark_prismarine
fill 182 -17 333 182 -14 333 minecraft:blue_terracotta
setblock 182 -17 337 minecraft:dark_prismarine
fill 182 -17 338 182 -14 338 minecraft:blue_terracotta
setblock 182 -17 342 minecraft:dark_prismarine
fill 182 -17 343 182 -14 343 minecraft:blue_terracotta
setblock 182 -17 347 minecraft:dark_prismarine
fill 182 -17 348 182 -14 348 minecraft:blue_terracotta
setblock 182 -17 352 minecraft:dark_prismarine
fill 182 -17 353 182 -14 353 minecraft:blue_terracotta
setblock 182 -17 357 minecraft:dark_prismarine
fill 182 -17 358 182 -15 359 minecraft:blue_terracotta
setblock 182 -17 360 minecraft:purple_concrete
fill 183 -17 328 183 32 328 minecraft:black_concrete
fill 142 -16 323 144 -16 323 minecraft:blue_terracotta
setblock 142 -16 326 minecraft:dark_prismarine
fill 142 -16 327 142 -13 327 minecraft:blue_terracotta
setblock 142 -16 331 minecraft:dark_prismarine
fill 142 -16 332 142 -13 332 minecraft:blue_terracotta
setblock 142 -16 336 minecraft:dark_prismarine
fill 142 -16 337 142 -13 337 minecraft:blue_terracotta
setblock 142 -16 341 minecraft:dark_prismarine
fill 142 -16 342 142 -13 342 minecraft:blue_terracotta
setblock 142 -16 347 minecraft:blue_terracotta
setblock 142 -16 351 minecraft:dark_prismarine
fill 142 -16 352 142 -13 352 minecraft:blue_terracotta
setblock 142 -16 356 minecraft:dark_prismarine
fill 142 -16 357 142 -13 357 minecraft:blue_terracotta
setblock 142 -16 360 minecraft:blue_terracotta
setblock 142 -16 361 minecraft:dark_prismarine
setblock 143 -16 325 minecraft:dark_prismarine
fill 143 -16 326 143 -13 326 minecraft:blue_terracotta
setblock 143 -16 330 minecraft:dark_prismarine
fill 143 -16 331 143 -13 331 minecraft:blue_terracotta
setblock 143 -16 335 minecraft:dark_prismarine
fill 143 -16 336 143 -13 336 minecraft:blue_terracotta
fill 143 -16 338 143 -15 338 minecraft:blue_terracotta
setblock 144 -16 329 minecraft:dark_prismarine
fill 144 -16 330 144 -14 330 minecraft:blue_terracotta
setblock 144 -16 334 minecraft:dark_prismarine
setblock 145 -16 323 minecraft:dark_prismarine
fill 146 -16 323 146 -13 323 minecraft:blue_terracotta
fill 146 -16 335 147 7 336 minecraft:magenta_terracotta
fill 148 -16 322 148 129 322 minecraft:black_concrete
fill 150 -16 352 151 17 352 minecraft:magenta_terracotta
fill 151 -16 351 151 26 351 minecraft:magenta_terracotta
fill 151 -16 364 162 -2 364 minecraft:black_concrete
fill 153 -16 323 154 -16 323 minecraft:blue_terracotta
fill 153 -16 363 154 -16 363 minecraft:blue_terracotta
setblock 155 -16 323 minecraft:dark_prismarine
setblock 155 -16 362 minecraft:blue_terracotta
setblock 155 -16 363 minecraft:dark_prismarine
fill 156 -16 323 156 -13 323 minecraft:blue_terracotta
fill 156 -16 327 158 6 327 minecraft:magenta_terracotta
setblock 156 -16 362 minecraft:dark_prismarine
fill 156 -16 363 159 -16 363 minecraft:blue_terracotta
fill 157 -16 326 158 11 326 minecraft:magenta_terracotta
fill 157 -16 362 157 -13 362 minecraft:blue_terracotta
setblock 158 -16 324 minecraft:blue_terracotta
fill 158 -16 361 161 -16 361 minecraft:blue_terracotta
setblock 160 -16 323 minecraft:dark_prismarine
setblock 160 -16 363 minecraft:dark_prismarine
fill 161 -16 323 161 -13 323 minecraft:blue_terracotta
setblock 161 -16 362 minecraft:dark_prismarine
fill 161 -16 363 161 -13 363 minecraft:blue_terracotta
fill 162 -16 362 163 -14 362 minecraft:blue_terracotta
setblock 163 -16 364 minecraft:light_blue_wool
fill 164 -16 364 167 55 364 minecraft:black_concrete
fill 166 -16 359 167 8 360 minecraft:magenta_terracotta
setblock 169 -16 323 minecraft:purple_concrete
fill 172 -16 334 174 9 334 minecraft:magenta_terracotta
fill 173 -16 333 173 7 333 minecraft:magenta_terracotta
fill 173 -16 335 173 29 335 minecraft:magenta_terracotta
fill 177 -16 350 179 7 350 minecraft:magenta_terracotta
fill 178 -16 351 178 7 351 minecraft:magenta_terracotta
fill 179 -16 331 179 -16 333 minecraft:blue_terracotta
setblock 179 -16 334 minecraft:dark_prismarine
fill 179 -16 335 179 -14 336 minecraft:blue_terracotta
setblock 180 -16 323 minecraft:dark_prismarine
setblock 180 -16 328 minecraft:dark_prismarine
fill 180 -16 329 180 -13 329 minecraft:blue_terracotta
setblock 180 -16 332 minecraft:blue_terracotta
setblock 180 -16 333 minecraft:dark_prismarine
fill 180 -16 334 180 -13 334 minecraft:blue_terracotta
setblock 180 -16 337 minecraft:blue_terracotta
setblock 180 -16 338 minecraft:dark_prismarine
fill 180 -16 339 180 -14 340 minecraft:blue_terracotta
setblock 180 -16 348 minecraft:dark_prismarine
setblock 180 -16 353 minecraft:dark_prismarine
fill 180 -16 354 180 -13 354 minecraft:blue_terracotta
setblock 180 -16 363 minecraft:purple_concrete
fill 181 -16 323 181 -13 323 minecraft:blue_terracotta
setblock 181 -16 327 minecraft:dark_prismarine
fill 181 -16 328 181 -13 328 minecraft:blue_terracotta
setblock 181 -16 332 minecraft:dark_prismarine
fill 181 -16 333 181 -13 333 minecraft:blue_terracotta
setblock 181 -16 337 minecraft:dark_prismarine
fill 181 -16 338 181 -13 338 minecraft:blue_terracotta
setblock 181 -16 342 minecraft:dark_prismarine
fill 181 -16 343 181 -13 343 minecraft:blue_terracotta
setblock 181 -16 347 minecraft:dark_prismarine
fill 181 -16 348 181 -13 348 minecraft:blue_terracotta
setblock 181 -16 352 minecraft:dark_prismarine
fill 181 -16 353 181 -13 353 minecraft:blue_terracotta
setblock 181 -16 357 minecraft:dark_prismarine
fill 181 -16 358 181 -13 358 minecraft:blue_terracotta
setblock 182 -16 326 minecraft:dark_prismarine
fill 182 -16 327 182 -13 327 minecraft:blue_terracotta
setblock 182 -16 331 minecraft:dark_prismarine
fill 182 -16 332 182 -13 332 minecraft:blue_terracotta
setblock 182 -16 336 minecraft:dark_prismarine
fill 182 -16 337 182 -13 337 minecraft:blue_terracotta
setblock 182 -16 341 minecraft:dark_prismarine
fill 182 -16 342 182 -13 342 minecraft:blue_terracotta
setblock 182 -16 346 minecraft:dark_prismarine
fill 182 -16 347 182 -13 347 minecraft:blue_terracotta
setblock 182 -16 351 minecraft:dark_prismarine
fill 182 -16 352 182 -13 352 minecraft:blue_terracotta
setblock 182 -16 356 minecraft:dark_prismarine
fill 182 -16 357 182 -13 357 minecraft:blue_terracotta
setblock 182 -16 360 minecraft:blue_terracotta
fill 183 -16 344 183 118 344 minecraft:black_concrete
setblock 183 -16 345 minecraft:light_blue_wool
fill 183 -16 346 183 91 349 minecraft:black_concrete
fill 142 -15 323 143 -15 323 minecraft:blue_terracotta
setblock 142 -15 325 minecraft:dark_prismarine
fill 142 -15 326 142 -12 326 minecraft:blue_terracotta
setblock 142 -15 330 minecraft:dark_prismarine
fill 142 -15 331 142 -12 331 minecraft:blue_terracotta
setblock 142 -15 335 minecraft:dark_prismarine
fill 142 -15 336 142 -12 336 minecraft:blue_terracotta
setblock 142 -15 340 minecraft:dark_prismarine
fill 142 -15 341 142 -12 341 minecraft:blue_terracotta
setblock 142 -15 350 minecraft:dark_prismarine
fill 142 -15 351 142 -13 351 minecraft:blue_terracotta
setblock 142 -15 355 minecraft:dark_prismarine
fill 142 -15 356 143 -13 356 minecraft:blue_terracotta
setblock 142 -15 360 minecraft:dark_prismarine
fill 142 -15 361 142 -14 363 minecraft:blue_terracotta
setblock 143 -15 324 minecraft:dark_prismarine
fill 143 -15 325 143 -13 325 minecraft:blue_terracotta
setblock 143 -15 329 minecraft:dark_prismarine
fill 143 -15 330 143 -12 330 minecraft:blue_terracotta
setblock 143 -15 334 minecraft:dark_prismarine
fill 143 -15 335 143 -12 335 minecraft:blue_terracotta
setblock 143 -15 354 minecraft:dark_prismarine
fill 143 -15 355 143 -13 355 minecraft:blue_terracotta
setblock 143 -15 363 minecraft:blue_terracotta
setblock 144 -15 323 minecraft:dark_prismarine
fill 144 -15 329 144 -14 329 minecraft:blue_terracotta
setblock 144 -15 333 minecraft:dark_prismarine
fill 144 -15 334 144 -13 334 minecraft:blue_terracotta
fill 145 -15 323 145 -12 323 minecraft:blue_terracotta
fill 152 -15 323 153 -15 323 minecraft:blue_terracotta
fill 152 -15 363 153 -15 363 minecraft:blue_terracotta
fill 153 -15 351 153 -15 352 minecraft:magenta_terracotta
setblock 154 -15 323 minecraft:dark_prismarine
setblock 154 -15 362 minecraft:blue_terracotta
setblock 154 -15 363 minecraft:dark_prismarine
fill 155 -15 323 155 -12 323 minecraft:blue_terracotta
setblock 155 -15 362 minecraft:dark_prismarine
fill 155 -15 363 158 -15 363 minecraft:blue_terracotta
fill 156 -15 324 157 -15 324 minecraft:blue_terracotta
setblock 156 -15 361 minecraft:dark_prismarine
fill 156 -15 362 156 -12 362 minecraft:blue_terracotta
fill 157 -15 361 160 -15 361 minecraft:blue_terracotta
setblock 158 -15 324 minecraft:dark_prismarine
setblock 159 -15 323 minecraft:dark_prismarine
setblock 159 -15 363 minecraft:dark_prismarine
fill 160 -15 323 160 -12 323 minecraft:blue_terracotta
fill 160 -15 327 160 33 327 minecraft:magenta_terracotta
setblock 160 -15 362 minecraft:dark_prismarine
fill 160 -15 363 160 -12 363 minecraft:blue_terracotta
setblock 161 -15 361 minecraft:dark_prismarine
fill 161 -15 362 161 -12 362 minecraft:blue_terracotta
setblock 163 -15 323 minecraft:purple_concrete
fill 163 -15 364 163 131 364 minecraft:black_concrete
setblock 164 -15 363 minecraft:dark_prismarine
setblock 178 -15 323 minecraft:blue_terracotta
setblock 179 -15 323 minecraft:dark_prismarine
fill 179 -15 331 179 -15 332 minecraft:blue_terracotta
setblock 179 -15 333 minecraft:dark_prismarine
fill 179 -15 334 179 -12 334 minecraft:blue_terracotta
setblock 179 -15 337 minecraft:blue_terracotta
setblock 179 -15 338 minecraft:dark_prismarine
fill 180 -15 323 180 -12 323 minecraft:blue_terracotta
fill 180 -15 328 180 -13 328 minecraft:blue_terracotta
setblock 180 -15 332 minecraft:dark_prismarine
fill 180 -15 333 180 -12 333 minecraft:blue_terracotta
setblock 180 -15 337 minecraft:dark_prismarine
fill 180 -15 338 180 -12 338 minecraft:blue_terracotta
setblock 180 -15 341 minecraft:blue_terracotta
setblock 180 -15 352 minecraft:dark_prismarine
fill 180 -15 353 180 -13 353 minecraft:blue_terracotta
setblock 180 -15 356 minecraft:blue_terracotta
setblock 181 -15 326 minecraft:dark_prismarine
fill 181 -15 327 181 -12 327 minecraft:blue_terracotta
setblock 181 -15 331 minecraft:dark_prismarine
fill 181 -15 332 181 -12 332 minecraft:blue_terracotta
setblock 181 -15 336 minecraft:dark_prismarine
fill 181 -15 337 181 -12 337 minecraft:blue_terracotta
setblock 181 -15 341 minecraft:dark_prismarine
fill 181 -15 342 181 -12 342 minecraft:blue_terracotta
setblock 181 -15 346 minecraft:dark_prismarine
fill 181 -15 347 181 -13 347 minecraft:blue_terracotta
setblock 181 -15 351 minecraft:dark_prismarine
fill 181 -15 352 181 -12 352 minecraft:blue_terracotta
setblock 181 -15 356 minecraft:dark_prismarine
fill 181 -15 357 181 -12 357 minecraft:blue_terracotta
setblock 182 -15 325 minecraft:dark_prismarine
fill 182 -15 326 182 -12 326 minecraft:blue_terracotta
setblock 182 -15 330 minecraft:dark_prismarine
fill 182 -15 331 182 -12 331 minecraft:blue_terracotta
setblock 182 -15 335 minecraft:dark_prismarine
fill 182 -15 336 182 -12 336 minecraft:blue_terracotta
setblock 182 -15 340 minecraft:dark_prismarine
fill 182 -15 341 182 -12 341 minecraft:blue_terracotta
setblock 182 -15 345 minecraft:dark_prismarine
fill 182 -15 346 182 -12 346 minecraft:blue_terracotta
setblock 182 -15 350 minecraft:dark_prismarine
fill 182 -15 351 182 -12 351 minecraft:blue_terracotta
setblock 182 -15 355 minecraft:dark_prismarine
fill 182 -15 356 182 -12 356 minecraft:blue_terracotta
setblock 182 -15 360 minecraft:dark_prismarine
fill 182 -15 361 182 -12 361 minecraft:blue_terracotta
fill 183 -15 345 183 129 345 minecraft:black_concrete
setblock 142 -14 323 minecraft:blue_terracotta
setblock 142 -14 324 minecraft:dark_prismarine
fill 142 -14 325 142 -11 325 minecraft:blue_terracotta
setblock 142 -14 329 minecraft:dark_prismarine
fill 142 -14 330 142 -11 330 minecraft:blue_terracotta
setblock 142 -14 334 minecraft:dark_prismarine
fill 142 -14 335 142 -11 335 minecraft:blue_terracotta
setblock 142 -14 339 minecraft:dark_prismarine
fill 142 -14 340 142 -11 340 minecraft:blue_terracotta
setblock 142 -14 344 minecraft:purple_concrete
setblock 142 -14 349 minecraft:dark_prismarine
fill 142 -14 350 142 -13 350 minecraft:blue_terracotta
setblock 142 -14 354 minecraft:dark_prismarine
fill 142 -14 355 142 -11 355 minecraft:blue_terracotta
setblock 142 -14 358 minecraft:blue_terracotta
setblock 142 -14 359 minecraft:dark_prismarine
fill 142 -14 360 142 -11 360 minecraft:blue_terracotta
setblock 143 -14 323 minecraft:dark_prismarine
setblock 143 -14 324 minecraft:blue_terracotta
setblock 143 -14 328 minecraft:dark_prismarine
fill 143 -14 329 143 -11 329 minecraft:blue_terracotta
setblock 143 -14 333 minecraft:dark_prismarine
fill 143 -14 334 143 -11 334 minecraft:blue_terracotta
setblock 143 -14 338 minecraft:dark_prismarine
setblock 143 -14 354 minecraft:blue_terracotta
setblock 143 -14 357 minecraft:blue_terracotta
setblock 143 -14 358 minecraft:dark_prismarine
setblock 143 -14 363 minecraft:dark_prismarine
fill 144 -14 323 144 -11 323 minecraft:blue_terracotta
setblock 144 -14 332 minecraft:dark_prismarine
fill 144 -14 333 144 -13 333 minecraft:blue_terracotta
fill 144 -14 363 144 -11 363 minecraft:blue_terracotta
fill 148 -14 347 149 -13 348 minecraft:dark_prismarine
setblock 148 -14 363 minecraft:purple_concrete
fill 150 -14 323 152 -14 323 minecraft:blue_terracotta
fill 150 -14 363 152 -14 363 minecraft:blue_terracotta
fill 151 -14 353 151 -10 354 minecraft:magenta_terracotta
fill 152 -14 353 152 -4 353 minecraft:magenta_terracotta
fill 152 -14 362 153 -14 362 minecraft:blue_terracotta
setblock 153 -14 323 minecraft:dark_prismarine
fill 153 -14 352 153 -11 352 minecraft:magenta_terracotta
setblock 153 -14 363 minecraft:dark_prismarine
fill 154 -14 323 154 -11 323 minecraft:blue_terracotta
setblock 154 -14 361 minecraft:blue_terracotta
setblock 154 -14 362 minecraft:dark_prismarine
fill 154 -14 363 157 -14 363 minecraft:blue_terracotta
setblock 155 -14 361 minecraft:dark_prismarine
fill 155 -14 362 155 -11 362 minecraft:blue_terracotta
setblock 156 -14 324 minecraft:blue_terracotta
setblock 156 -14 360 minecraft:dark_prismarine
fill 156 -14 361 159 -14 361 minecraft:blue_terracotta
setblock 157 -14 324 minecraft:dark_prismarine
fill 157 -14 360 160 -14 360 minecraft:blue_terracotta
setblock 158 -14 323 minecraft:dark_prismarine
fill 158 -14 324 158 -13 324 minecraft:blue_terracotta
setblock 158 -14 363 minecraft:dark_prismarine
fill 159 -14 323 159 -11 323 minecraft:blue_terracotta
setblock 159 -14 362 minecraft:dark_prismarine
fill 159 -14 363 159 -11 363 minecraft:blue_terracotta
setblock 160 -14 361 minecraft:dark_prismarine
fill 160 -14 362 160 -11 362 minecraft:blue_terracotta
fill 161 -14 361 162 -12 361 minecraft:blue_terracotta
setblock 163 -14 363 minecraft:dark_prismarine
fill 164 -14 363 165 -12 363 minecraft:blue_terracotta
fill 165 -14 359 165 19 360 minecraft:magenta_terracotta
fill 165 -14 361 165 -11 361 minecraft:black_concrete
fill 166 -14 361 167 -7 361 minecraft:magenta_terracotta
setblock 167 -14 363 minecraft:purple_concrete
fill 168 -14 359 168 4 359 minecraft:magenta_terracotta
setblock 176 -14 323 minecraft:purple_concrete
fill 176 -14 363 177 -14 363 minecraft:blue_terracotta
setblock 177 -14 323 minecraft:blue_terracotta
setblock 178 -14 323 minecraft:dark_prismarine
setblock 178 -14 363 minecraft:dark_prismarine
fill 179 -14 323 179 -11 323 minecraft:blue_terracotta
fill 179 -14 330 179 -14 331 minecraft:blue_terracotta
setblock 179 -14 332 minecraft:dark_prismarine
fill 179 -14 333 179 -11 333 minecraft:blue_terracotta
setblock 179 -14 337 minecraft:dark_prismarine
fill 179 -14 338 179 -12 339 minecraft:blue_terracotta
fill 179 -14 363 180 -12 363 minecraft:blue_terracotta
setblock 180 -14 331 minecraft:dark_prismarine
fill 180 -14 332 180 -11 332 minecraft:blue_terracotta
setblock 180 -14 336 minecraft:dark_prismarine
fill 180 -14 337 180 -11 337 minecraft:blue_terracotta
setblock 180 -14 341 minecraft:dark_prismarine
fill 180 -14 342 180 -11 342 minecraft:blue_terracotta
fill 180 -14 352 180 -13 352 minecraft:blue_terracotta
setblock 180 -14 356 minecraft:dark_prismarine
fill 180 -14 357 180 -12 357 minecraft:blue_terracotta
fill 181 -14 326 181 -12 326 minecraft:blue_terracotta
setblock 181 -14 330 minecraft:dark_prismarine
fill 181 -14 331 181 -11 331 minecraft:blue_terracotta
setblock 181 -14 335 minecraft:dark_prismarine
fill 181 -14 336 181 -11 336 minecraft:blue_terracotta
setblock 181 -14 340 minecraft:dark_prismarine
fill 181 -14 341 181 -11 341 minecraft:blue_terracotta
setblock 181 -14 345 minecraft:dark_prismarine
fill 181 -14 346 181 -13 346 minecraft:blue_terracotta
setblock 181 -14 350 minecraft:dark_prismarine
fill 181 -14 351 181 -12 351 minecraft:blue_terracotta
setblock 181 -14 355 minecraft:dark_prismarine
fill 181 -14 356 181 -11 356 minecraft:blue_terracotta
setblock 181 -14 359 minecraft:blue_terracotta
setblock 182 -14 324 minecraft:dark_prismarine
fill 182 -14 325 182 -11 325 minecraft:blue_terracotta
setblock 182 -14 329 minecraft:dark_prismarine
fill 182 -14 330 182 -11 330 minecraft:blue_terracotta
setblock 182 -14 334 minecraft:dark_prismarine
fill 182 -14 335 182 -11 335 minecraft:blue_terracotta
setblock 182 -14 339 minecraft:dark_prismarine
fill 182 -14 340 182 -11 340 minecraft:blue_terracotta
setblock 182 -14 344 minecraft:dark_prismarine
fill 182 -14 345 182 -11 345 minecraft:blue_terracotta
setblock 182 -14 349 minecraft:dark_prismarine
fill 182 -14 350 182 -12 350 minecraft:blue_terracotta
setblock 182 -14 354 minecraft:dark_prismarine
fill 182 -14 355 182 -11 355 minecraft:blue_terracotta
setblock 182 -14 358 minecraft:blue_terracotta
setblock 182 -14 359 minecraft:dark_prismarine
fill 182 -14 360 182 -11 360 minecraft:blue_terracotta
setblock 142 -13 323 minecraft:dark_prismarine
fill 142 -13 324 142 -10 324 minecraft:blue_terracotta
setblock 142 -13 328 minecraft:dark_prismarine
fill 142 -13 329 142 -10 329 minecraft:blue_terracotta
setblock 142 -13 333 minecraft:dark_prismarine
fill 142 -13 334 142 -10 334 minecraft:blue_terracotta
setblock 142 -13 338 minecraft:dark_prismarine
fill 142 -13 339 143 -12 339 minecraft:blue_terracotta
setblock 142 -13 353 minecraft:dark_prismarine
fill 142 -13 354 142 -10 354 minecraft:blue_terracotta
setblock 142 -13 358 minecraft:dark_prismarine
fill 142 -13 359 143 -11 359 minecraft:blue_terracotta
fill 142 -13 361 142 -13 362 minecraft:blue_terracotta
setblock 142 -13 363 minecraft:dark_prismarine
fill 143 -13 323 143 -10 323 minecraft:blue_terracotta
setblock 143 -13 327 minecraft:dark_prismarine
fill 143 -13 328 143 -12 328 minecraft:blue_terracotta
setblock 143 -13 332 minecraft:dark_prismarine
fill 143 -13 333 143 -10 333 minecraft:blue_terracotta
setblock 143 -13 337 minecraft:dark_prismarine
fill 143 -13 338 143 -11 338 minecraft:blue_terracotta
setblock 143 -13 357 minecraft:dark_prismarine
fill 143 -13 358 143 -11 358 minecraft:blue_terracotta
fill 143 -13 363 143 -10 363 minecraft:blue_terracotta
setblock 144 -13 325 minecraft:light[level=12]
setblock 144 -13 331 minecraft:dark_prismarine
setblock 144 -13 332 minecraft:blue_terracotta
setblock 144 -13 339 minecraft:light[level=12]
setblock 144 -13 346 minecraft:light[level=12]
setblock 144 -13 353 minecraft:light[level=12]
setblock 144 -13 360 minecraft:light[level=12]
fill 145 -13 363 146 -13 363 minecraft:blue_terracotta
setblock 147 -13 323 minecraft:dark_prismarine
setblock 147 -13 363 minecraft:dark_prismarine
fill 148 -13 323 151 -13 323 minecraft:blue_terracotta
fill 148 -13 363 151 -13 363 minecraft:blue_terracotta
fill 149 -13 350 149 7 350 minecraft:magenta_terracotta
setblock 151 -13 325 minecraft:light[level=12]
setblock 151 -13 332 minecraft:light[level=12]
setblock 151 -13 339 minecraft:light[level=12]
setblock 151 -13 346 minecraft:light[level=12]
setblock 151 -13 360 minecraft:light[level=12]
fill 151 -13 362 152 -13 362 minecraft:blue_terracotta
setblock 152 -13 323 minecraft:dark_prismarine
setblock 152 -13 363 minecraft:dark_prismarine
fill 153 -13 323 153 -10 323 minecraft:blue_terracotta
setblock 153 -13 361 minecraft:blue_terracotta
setblock 153 -13 362 minecraft:dark_prismarine
fill 153 -13 363 156 -13 363 minecraft:blue_terracotta
setblock 154 -13 361 minecraft:dark_prismarine
fill 154 -13 362 154 -10 362 minecraft:blue_terracotta
setblock 155 -13 324 minecraft:blue_terracotta
setblock 155 -13 360 minecraft:dark_prismarine
fill 155 -13 361 158 -13 361 minecraft:blue_terracotta
setblock 156 -13 324 minecraft:dark_prismarine
fill 156 -13 360 159 -13 360 minecraft:blue_terracotta
setblock 157 -13 323 minecraft:dark_prismarine
fill 157 -13 324 157 -12 324 minecraft:blue_terracotta
setblock 157 -13 363 minecraft:dark_prismarine
fill 158 -13 323 158 -10 323 minecraft:blue_terracotta
setblock 158 -13 332 minecraft:light[level=12]
setblock 158 -13 339 minecraft:light[level=12]
setblock 158 -13 346 minecraft:light[level=12]
setblock 158 -13 353 minecraft:light[level=12]
setblock 158 -13 362 minecraft:dark_prismarine
fill 158 -13 363 158 -10 363 minecraft:blue_terracotta
setblock 159 -13 361 minecraft:dark_prismarine
fill 159 -13 362 159 -10 362 minecraft:blue_terracotta
setblock 160 -13 360 minecraft:dark_prismarine
fill 160 -13 361 160 -10 361 minecraft:blue_terracotta
fill 161 -13 360 161 -12 360 minecraft:blue_terracotta
setblock 162 -13 362 minecraft:blue_terracotta
setblock 162 -13 363 minecraft:dark_prismarine
setblock 163 -13 362 minecraft:dark_prismarine
fill 163 -13 363 163 -10 363 minecraft:blue_terracotta
fill 164 -13 359 164 33 359 minecraft:magenta_terracotta
fill 164 -13 361 164 -11 361 minecraft:black_concrete
setblock 165 -13 325 minecraft:light[level=12]
setblock 165 -13 332 minecraft:light[level=12]
setblock 165 -13 339 minecraft:light[level=12]
setblock 165 -13 346 minecraft:light[level=12]
setblock 165 -13 353 minecraft:light[level=12]
fill 165 -13 357 165 33 357 minecraft:magenta_terracotta
fill 165 -13 362 165 -11 362 minecraft:black_concrete
setblock 170 -13 323 minecraft:purple_concrete
setblock 172 -13 325 minecraft:light[level=12]
setblock 172 -13 339 minecraft:light[level=12]
setblock 172 -13 346 minecraft:light[level=12]
setblock 172 -13 353 minecraft:light[level=12]
setblock 172 -13 360 minecraft:light[level=12]
setblock 173 -13 363 minecraft:purple_concrete
fill 174 -13 363 176 -13 363 minecraft:blue_terracotta
setblock 176 -13 323 minecraft:blue_terracotta
setblock 177 -13 323 minecraft:dark_prismarine
setblock 177 -13 363 minecraft:dark_prismarine
fill 178 -13 323 178 -10 323 minecraft:blue_terracotta
fill 178 -13 334 178 -13 336 minecraft:blue_terracotta
setblock 178 -13 337 minecraft:dark_prismarine
fill 178 -13 363 178 -10 363 minecraft:blue_terracotta
setblock 179 -13 325 minecraft:light[level=12]
setblock 179 -13 330 minecraft:blue_terracotta
setblock 179 -13 331 minecraft:dark_prismarine
fill 179 -13 332 179 -11 332 minecraft:blue_terracotta
setblock 179 -13 335 minecraft:blue_terracotta
setblock 179 -13 336 minecraft:dark_prismarine
fill 179 -13 337 179 -10 337 minecraft:blue_terracotta
setblock 179 -13 340 minecraft:blue_terracotta
setblock 179 -13 346 minecraft:light[level=12]
setblock 179 -13 353 minecraft:light[level=12]
setblock 179 -13 360 minecraft:light[level=12]
setblock 180 -13 330 minecraft:dark_prismarine
fill 180 -13 331 180 -10 331 minecraft:blue_terracotta
setblock 180 -13 335 minecraft:dark_prismarine
fill 180 -13 336 180 -10 336 minecraft:blue_terracotta
setblock 180 -13 339 minecraft:blue_terracotta
setblock 180 -13 340 minecraft:dark_prismarine
fill 180 -13 341 180 -10 341 minecraft:blue_terracotta
setblock 180 -13 355 minecraft:dark_prismarine
fill 180 -13 356 180 -12 356 minecraft:blue_terracotta
setblock 181 -13 329 minecraft:dark_prismarine
fill 181 -13 330 181 -10 330 minecraft:blue_terracotta
setblock 181 -13 334 minecraft:dark_prismarine
fill 181 -13 335 181 -10 335 minecraft:blue_terracotta
setblock 181 -13 339 minecraft:dark_prismarine
fill 181 -13 340 181 -10 340 minecraft:blue_terracotta
setblock 181 -13 344 minecraft:dark_prismarine
setblock 181 -13 345 minecraft:blue_terracotta
setblock 181 -13 349 minecraft:dark_prismarine
setblock 181 -13 350 minecraft:blue_terracotta
setblock 181 -13 354 minecraft:dark_prismarine
fill 181 -13 355 181 -11 355 minecraft:blue_terracotta
setblock 181 -13 359 minecraft:dark_prismarine
fill 181 -13 360 181 -11 360 minecraft:blue_terracotta
setblock 181 -13 363 minecraft:blue_terracotta
setblock 182 -13 323 minecraft:dark_prismarine
fill 182 -13 324 182 -10 324 minecraft:blue_terracotta
setblock 182 -13 328 minecraft:dark_prismarine
fill 182 -13 329 182 -10 329 minecraft:blue_terracotta
setblock 182 -13 333 minecraft:dark_prismarine
fill 182 -13 334 182 -10 334 minecraft:blue_terracotta
setblock 182 -13 338 minecraft:dark_prismarine
fill 182 -13 339 182 -10 339 minecraft:blue_terracotta
setblock 182 -13 343 minecraft:dark_prismarine
fill 182 -13 344 182 -10 344 minecraft:blue_terracotta
setblock 182 -13 348 minecraft:dark_prismarine
fill 182 -13 349 182 -12 349 minecraft:blue_terracotta
setblock 182 -13 353 minecraft:dark_prismarine
fill 182 -13 354 182 -10 354 minecraft:blue_terracotta
setblock 182 -13 358 minecraft:dark_prismarine
fill 182 -13 359 182 -10 359 minecraft:blue_terracotta
setblock 182 -13 362 minecraft:blue_terracotta
fill 183 -13 351 183 70 351 minecraft:black_concrete
setblock 183 -13 352 minecraft:cyan_concrete
fill 183 -13 353 183 43 356 minecraft:black_concrete
setblock 183 -13 357 minecraft:light_blue_wool
fill 142 -12 323 142 -9 323 minecraft:blue_terracotta
setblock 142 -12 327 minecraft:dark_prismarine
fill 142 -12 328 142 -9 328 minecraft:blue_terracotta
setblock 142 -12 332 minecraft:dark_prismarine
fill 142 -12 333 142 -9 333 minecraft:blue_terracotta
setblock 142 -12 337 minecraft:dark_prismarine
fill 142 -12 338 142 -9 338 minecraft:blue_terracotta
setblock 142 -12 342 minecraft:dark_prismarine
setblock 142 -12 352 minecraft:dark_prismarine
fill 142 -12 353 142 -11 353 minecraft:blue_terracotta
setblock 142 -12 356 minecraft:blue_terracotta
setblock 142 -12 357 minecraft:dark_prismarine
fill 142 -12 358 142 -9 358 minecraft:blue_terracotta
setblock 142 -12 361 minecraft:blue_terracotta
setblock 142 -12 362 minecraft:dark_prismarine
fill 142 -12 363 142 -9 363 minecraft:blue_terracotta
setblock 143 -12 327 minecraft:blue_terracotta
setblock 143 -12 331 minecraft:dark_prismarine
fill 143 -12 332 143 -10 332 minecraft:blue_terracotta
setblock 143 -12 336 minecraft:dark_prismarine
fill 143 -12 337 143 -10 337 minecraft:blue_terracotta
setblock 143 -12 356 minecraft:dark_prismarine
fill 143 -12 357 143 -11 357 minecraft:blue_terracotta
setblock 143 -12 360 minecraft:blue_terracotta
setblock 145 -12 363 minecraft:blue_terracotta
setblock 146 -12 323 minecraft:dark_prismarine
setblock 146 -12 363 minecraft:dark_prismarine
fill 147 -12 323 150 -12 323 minecraft:blue_terracotta
fill 147 -12 363 150 -12 363 minecraft:blue_terracotta
fill 149 -12 362 151 -12 362 minecraft:blue_terracotta
setblock 151 -12 323 minecraft:dark_prismarine
setblock 151 -12 363 minecraft:dark_prismarine
fill 152 -12 323 152 -9 323 minecraft:blue_terracotta
setblock 152 -12 361 minecraft:blue_terracotta
setblock 152 -12 362 minecraft:dark_prismarine
fill 152 -12 363 155 -12 363 minecraft:blue_terracotta
setblock 153 -12 360 minecraft:blue_terracotta
setblock 153 -12 361 minecraft:dark_prismarine
fill 153 -12 362 153 -9 362 minecraft:blue_terracotta
setblock 154 -12 324 minecraft:blue_terracotta
setblock 154 -12 360 minecraft:dark_prismarine
fill 154 -12 361 157 -12 361 minecraft:blue_terracotta
setblock 155 -12 324 minecraft:dark_prismarine
fill 155 -12 360 158 -12 360 minecraft:blue_terracotta
setblock 156 -12 323 minecraft:dark_prismarine
fill 156 -12 324 156 -11 324 minecraft:blue_terracotta
fill 156 -12 359 158 -11 359 minecraft:blue_terracotta
setblock 156 -12 363 minecraft:dark_prismarine
fill 157 -12 323 157 -9 323 minecraft:blue_terracotta
setblock 157 -12 362 minecraft:dark_prismarine
fill 157 -12 363 157 -9 363 minecraft:blue_terracotta
setblock 158 -12 361 minecraft:dark_prismarine
fill 158 -12 362 158 -9 362 minecraft:blue_terracotta
setblock 159 -12 360 minecraft:dark_prismarine
fill 159 -12 361 159 -9 361 minecraft:blue_terracotta
fill 160 -12 360 160 -10 360 minecraft:blue_terracotta
setblock 161 -12 323 minecraft:dark_prismarine
setblock 161 -12 363 minecraft:dark_prismarine
setblock 162 -12 362 minecraft:dark_prismarine
fill 162 -12 363 162 -9 363 minecraft:blue_terracotta
fill 163 -12 362 163 -10 362 minecraft:blue_terracotta
setblock 164 -12 323 minecraft:purple_concrete
fill 173 -12 363 175 -12 363 minecraft:blue_terracotta
setblock 175 -12 323 minecraft:blue_terracotta
setblock 176 -12 323 minecraft:dark_prismarine
setblock 176 -12 362 minecraft:blue_terracotta
setblock 176 -12 363 minecraft:dark_prismarine
fill 177 -12 323 177 -9 323 minecraft:blue_terracotta
setblock 177 -12 362 minecraft:dark_prismarine
fill 177 -12 363 177 -9 363 minecraft:blue_terracotta
fill 178 -12 334 178 -12 335 minecraft:blue_terracotta
setblock 178 -12 336 minecraft:dark_prismarine
fill 178 -12 337 178 -11 338 minecraft:blue_terracotta
fill 178 -12 362 179 -10 362 minecraft:blue_terracotta
setblock 179 -12 331 minecraft:blue_terracotta
setblock 179 -12 335 minecraft:dark_prismarine
fill 179 -12 336 179 -9 336 minecraft:blue_terracotta
setblock 179 -12 340 minecraft:dark_prismarine
setblock 180 -12 329 minecraft:dark_prismarine
fill 180 -12 330 180 -11 330 minecraft:blue_terracotta
setblock 180 -12 334 minecraft:dark_prismarine
fill 180 -12 335 180 -9 335 minecraft:blue_terracotta
setblock 180 -12 339 minecraft:dark_prismarine
fill 180 -12 340 180 -9 340 minecraft:blue_terracotta
setblock 180 -12 354 minecraft:dark_prismarine
setblock 180 -12 355 minecraft:blue_terracotta
setblock 181 -12 323 minecraft:dark_prismarine
setblock 181 -12 328 minecraft:dark_prismarine
fill 181 -12 329 181 -10 329 minecraft:blue_terracotta
setblock 181 -12 333 minecraft:dark_prismarine
fill 181 -12 334 181 -9 334 minecraft:blue_terracotta
setblock 181 -12 338 minecraft:dark_prismarine
fill 181 -12 339 181 -9 339 minecraft:blue_terracotta
setblock 181 -12 343 minecraft:dark_prismarine
fill 181 -12 344 181 -11 344 minecraft:blue_terracotta
setblock 181 -12 353 minecraft:dark_prismarine
fill 181 -12 354 181 -11 354 minecraft:blue_terracotta
setblock 181 -12 358 minecraft:dark_prismarine
fill 181 -12 359 181 -11 359 minecraft:blue_terracotta
setblock 181 -12 363 minecraft:dark_prismarine
fill 182 -12 323 182 -10 323 minecraft:blue_terracotta
setblock 182 -12 327 minecraft:dark_prismarine
fill 182 -12 328 182 -9 328 minecraft:blue_terracotta
setblock 182 -12 332 minecraft:dark_prismarine
fill 182 -12 333 182 -9 333 minecraft:blue_terracotta
setblock 182 -12 337 minecraft:dark_prismarine
fill 182 -12 338 182 -9 338 minecraft:blue_terracotta
setblock 182 -12 342 minecraft:dark_prismarine
fill 182 -12 343 182 -9 343 minecraft:blue_terracotta
setblock 182 -12 347 minecraft:dark_prismarine
setblock 182 -12 348 minecraft:blue_terracotta
setblock 182 -12 352 minecraft:dark_prismarine
fill 182 -12 353 182 -11 353 minecraft:blue_terracotta
setblock 182 -12 357 minecraft:dark_prismarine
fill 182 -12 358 182 -9 358 minecraft:blue_terracotta
setblock 182 -12 362 minecraft:dark_prismarine
fill 182 -12 363 182 -11 363 minecraft:blue_terracotta
fill 183 -12 352 183 54 352 minecraft:black_concrete
fill 183 -12 357 183 132 357 minecraft:black_concrete
setblock 142 -11 326 minecraft:dark_prismarine
fill 142 -11 327 142 -9 327 minecraft:blue_terracotta
setblock 142 -11 331 minecraft:dark_prismarine
fill 142 -11 332 142 -8 332 minecraft:blue_terracotta
setblock 142 -11 336 minecraft:dark_prismarine
fill 142 -11 337 142 -8 337 minecraft:blue_terracotta
fill 142 -11 339 142 -10 339 minecraft:blue_terracotta
setblock 142 -11 341 minecraft:dark_prismarine
setblock 142 -11 342 minecraft:blue_terracotta
setblock 142 -11 343 minecraft:purple_concrete
setblock 142 -11 356 minecraft:dark_prismarine
fill 142 -11 357 142 -8 357 minecraft:blue_terracotta
setblock 142 -11 361 minecraft:dark_prismarine
fill 142 -11 362 142 -8 362 minecraft:blue_terracotta
setblock 143 -11 330 minecraft:dark_prismarine
setblock 143 -11 331 minecraft:blue_terracotta
setblock 143 -11 335 minecraft:dark_prismarine
fill 143 -11 336 143 -10 336 minecraft:blue_terracotta
setblock 143 -11 360 minecraft:dark_prismarine
fill 143 -11 361 143 -10 361 minecraft:blue_terracotta
setblock 144 -11 325 minecraft:light[level=13]
setblock 144 -11 333 minecraft:light[level=13]
setblock 144 -11 341 minecraft:light[level=13]
setblock 144 -11 349 minecraft:light[level=13]
setblock 144 -11 357 minecraft:light[level=13]
setblock 145 -11 323 minecraft:dark_prismarine
setblock 145 -11 363 minecraft:dark_prismarine
fill 146 -11 323 149 -11 323 minecraft:blue_terracotta
fill 146 -11 363 149 -11 363 minecraft:blue_terracotta
fill 148 -11 362 150 -11 362 minecraft:blue_terracotta
setblock 150 -11 323 minecraft:dark_prismarine
setblock 150 -11 363 minecraft:dark_prismarine
fill 151 -11 323 151 -8 323 minecraft:blue_terracotta
setblock 151 -11 361 minecraft:blue_terracotta
setblock 151 -11 362 minecraft:dark_prismarine
fill 151 -11 363 154 -11 363 minecraft:blue_terracotta
setblock 152 -11 325 minecraft:light[level=13]
setblock 152 -11 333 minecraft:light[level=13]
setblock 152 -11 341 minecraft:light[level=13]
setblock 152 -11 349 minecraft:light[level=13]
setblock 152 -11 357 minecraft:light[level=13]
setblock 152 -11 361 minecraft:dark_prismarine
fill 152 -11 362 152 -8 362 minecraft:blue_terracotta
setblock 153 -11 360 minecraft:dark_prismarine
fill 153 -11 361 156 -11 361 minecraft:blue_terracotta
setblock 154 -11 324 minecraft:dark_prismarine
fill 154 -11 360 157 -11 360 minecraft:blue_terracotta
setblock 155 -11 323 minecraft:dark_prismarine
setblock 155 -11 324 minecraft:blue_terracotta
fill 155 -11 359 155 -10 359 minecraft:blue_terracotta
setblock 155 -11 363 minecraft:dark_prismarine
fill 156 -11 323 156 -8 323 minecraft:blue_terracotta
setblock 156 -11 362 minecraft:dark_prismarine
fill 156 -11 363 156 -8 363 minecraft:blue_terracotta
fill 157 -11 325 159 -4 325 minecraft:magenta_terracotta
setblock 157 -11 361 minecraft:dark_prismarine
fill 157 -11 362 157 -8 362 minecraft:blue_terracotta
setblock 158 -11 360 minecraft:dark_prismarine
fill 158 -11 361 158 -8 361 minecraft:blue_terracotta
fill 159 -11 360 159 -9 360 minecraft:blue_terracotta
setblock 160 -11 323 minecraft:dark_prismarine
setblock 160 -11 325 minecraft:light[level=13]
setblock 160 -11 333 minecraft:light[level=13]
setblock 160 -11 349 minecraft:light[level=13]
setblock 160 -11 357 minecraft:light[level=13]
setblock 160 -11 363 minecraft:dark_prismarine
setblock 161 -11 361 minecraft:blue_terracotta
setblock 161 -11 362 minecraft:dark_prismarine
fill 161 -11 363 161 -8 363 minecraft:blue_terracotta
setblock 162 -11 361 minecraft:dark_prismarine
fill 162 -11 362 162 -9 362 minecraft:blue_terracotta
setblock 164 -11 360 minecraft:black_concrete
setblock 164 -11 362 minecraft:black_concrete
setblock 164 -11 363 minecraft:blue_terracotta
setblock 165 -11 363 minecraft:dark_prismarine
setblock 166 -11 362 minecraft:black_concrete
setblock 166 -11 363 minecraft:purple_concrete
setblock 168 -11 325 minecraft:light[level=13]
setblock 168 -11 333 minecraft:light[level=13]
setblock 168 -11 341 minecraft:light[level=13]
setblock 168 -11 349 minecraft:light[level=13]
setblock 168 -11 357 minecraft:light[level=13]
fill 171 -11 334 171 -7 334 minecraft:magenta_terracotta
fill 172 -11 363 174 -11 363 minecraft:blue_terracotta
fill 173 -11 332 174 -8 332 minecraft:magenta_terracotta
fill 174 -11 362 175 -11 362 minecraft:blue_terracotta
setblock 175 -11 323 minecraft:dark_prismarine
setblock 175 -11 363 minecraft:dark_prismarine
fill 176 -11 323 176 -8 323 minecraft:blue_terracotta
setblock 176 -11 325 minecraft:light[level=13]
setblock 176 -11 333 minecraft:light[level=13]
setblock 176 -11 341 minecraft:light[level=13]
setblock 176 -11 362 minecraft:dark_prismarine
fill 176 -11 363 176 -8 363 minecraft:blue_terracotta
fill 177 -11 362 177 -8 362 minecraft:blue_terracotta
setblock 178 -11 334 minecraft:blue_terracotta
setblock 178 -11 335 minecraft:dark_prismarine
fill 178 -11 336 178 -10 336 minecraft:blue_terracotta
setblock 179 -11 334 minecraft:dark_prismarine
fill 179 -11 335 179 -9 335 minecraft:blue_terracotta
setblock 179 -11 338 minecraft:blue_terracotta
setblock 179 -11 339 minecraft:dark_prismarine
fill 179 -11 340 179 -10 340 minecraft:blue_terracotta
setblock 179 -11 363 minecraft:blue_terracotta
setblock 180 -11 323 minecraft:dark_prismarine
setblock 180 -11 333 minecraft:dark_prismarine
fill 180 -11 334 180 -8 334 minecraft:blue_terracotta
setblock 180 -11 338 minecraft:dark_prismarine
fill 180 -11 339 180 -8 339 minecraft:blue_terracotta
setblock 180 -11 363 minecraft:dark_prismarine
fill 181 -11 323 181 -8 323 minecraft:blue_terracotta
setblock 181 -11 327 minecraft:dark_prismarine
setblock 181 -11 328 minecraft:blue_terracotta
setblock 181 -11 332 minecraft:dark_prismarine
fill 181 -11 333 181 -8 333 minecraft:blue_terracotta
setblock 181 -11 337 minecraft:dark_prismarine
fill 181 -11 338 181 -8 338 minecraft:blue_terracotta
setblock 181 -11 342 minecraft:dark_prismarine
fill 181 -11 343 181 -10 343 minecraft:blue_terracotta
setblock 181 -11 357 minecraft:dark_prismarine
fill 181 -11 358 181 -10 358 minecraft:blue_terracotta
fill 181 -11 363 181 -9 363 minecraft:blue_terracotta
setblock 182 -11 326 minecraft:dark_prismarine
fill 182 -11 327 182 -9 327 minecraft:blue_terracotta
setblock 182 -11 331 minecraft:dark_prismarine
fill 182 -11 332 182 -8 332 minecraft:blue_terracotta
setblock 182 -11 336 minecraft:dark_prismarine
fill 182 -11 337 182 -8 337 minecraft:blue_terracotta
setblock 182 -11 341 minecraft:dark_prismarine
fill 182 -11 342 182 -8 342 minecraft:blue_terracotta
setblock 182 -11 351 minecraft:dark_prismarine
setblock 182 -11 352 minecraft:blue_terracotta
setblock 182 -11 356 minecraft:dark_prismarine
fill 182 -11 357 182 -9 357 minecraft:blue_terracotta
setblock 182 -11 361 minecraft:dark_prismarine
fill 182 -11 362 182 -9 362 minecraft:blue_terracotta
setblock 142 -10 325 minecraft:dark_prismarine
fill 142 -10 326 142 -9 326 minecraft:blue_terracotta
setblock 142 -10 330 minecraft:dark_prismarine
fill 142 -10 331 142 -9 331 minecraft:blue_terracotta
setblock 142 -10 335 minecraft:dark_prismarine
fill 142 -10 336 142 -7 336 minecraft:blue_terracotta
setblock 142 -10 340 minecraft:dark_prismarine
fill 142 -10 341 142 -9 341 minecraft:blue_terracotta
setblock 142 -10 349 minecraft:purple_concrete
setblock 142 -10 355 minecraft:dark_prismarine
fill 142 -10 356 142 -9 356 minecraft:blue_terracotta
setblock 142 -10 359 minecraft:blue_terracotta
setblock 142 -10 360 minecraft:dark_prismarine
fill 142 -10 361 142 -7 361 minecraft:blue_terracotta
setblock 143 -10 334 minecraft:dark_prismarine
setblock 143 -10 335 minecraft:blue_terracotta
setblock 143 -10 359 minecraft:dark_prismarine
setblock 143 -10 360 minecraft:blue_terracotta
setblock 144 -10 323 minecraft:dark_prismarine
setblock 144 -10 363 minecraft:dark_prismarine
fill 145 -10 323 148 -10 323 minecraft:blue_terracotta
fill 145 -10 363 148 -10 363 minecraft:blue_terracotta
fill 146 -10 338 146 -7 338 minecraft:magenta_terracotta
fill 147 -10 362 149 -10 362 minecraft:blue_terracotta
setblock 149 -10 323 minecraft:dark_prismarine
setblock 149 -10 363 minecraft:dark_prismarine
fill 150 -10 323 150 -7 323 minecraft:blue_terracotta
setblock 150 -10 361 minecraft:blue_terracotta
setblock 150 -10 362 minecraft:dark_prismarine
fill 150 -10 363 153 -10 363 minecraft:blue_terracotta
setblock 151 -10 361 minecraft:dark_prismarine
fill 151 -10 362 151 -7 362 minecraft:blue_terracotta
setblock 152 -10 360 minecraft:dark_prismarine
fill 152 -10 361 155 -10 361 minecraft:blue_terracotta
fill 153 -10 360 156 -10 360 minecraft:blue_terracotta
setblock 154 -10 323 minecraft:dark_prismarine
setblock 154 -10 363 minecraft:dark_prismarine
fill 155 -10 323 155 -7 323 minecraft:blue_terracotta
setblock 155 -10 362 minecraft:dark_prismarine
fill 155 -10 363 155 -7 363 minecraft:blue_terracotta
fill 156 -10 359 157 -10 359 minecraft:blue_terracotta
setblock 156 -10 361 minecraft:dark_prismarine
fill 156 -10 362 156 -7 362 minecraft:blue_terracotta
setblock 157 -10 360 minecraft:dark_prismarine
fill 157 -10 361 157 -7 361 minecraft:blue_terracotta
fill 158 -10 360 158 -8 360 minecraft:blue_terracotta
setblock 159 -10 323 minecraft:dark_prismarine
setblock 159 -10 363 minecraft:dark_prismarine
setblock 160 -10 362 minecraft:dark_prismarine
fill 160 -10 363 160 -7 363 minecraft:blue_terracotta
setblock 161 -10 361 minecraft:dark_prismarine
fill 161 -10 362 161 -7 362 minecraft:blue_terracotta
setblock 164 -10 363 minecraft:dark_prismarine
setblock 171 -10 323 minecraft:purple_concrete
fill 171 -10 363 173 -10 363 minecraft:blue_terracotta
fill 173 -10 362 174 -10 362 minecraft:blue_terracotta
setblock 174 -10 323 minecraft:dark_prismarine
fill 174 -10 339 175 -9 340 minecraft:dark_prismarine
setblock 174 -10 363 minecraft:dark_prismarine
fill 175 -10 323 175 -7 323 minecraft:blue_terracotta
setblock 175 -10 362 minecraft:dark_prismarine
fill 175 -10 363 175 -7 363 minecraft:blue_terracotta
fill 176 -10 362 176 -7 362 minecraft:blue_terracotta
fill 177 -10 348 178 -8 348 minecraft:magenta_terracotta
setblock 178 -10 337 minecraft:blue_terracotta
setblock 179 -10 323 minecraft:dark_prismarine
setblock 179 -10 333 minecraft:dark_prismarine
fill 179 -10 334 179 -9 334 minecraft:blue_terracotta
setblock 179 -10 338 minecraft:dark_prismarine
fill 179 -10 339 179 -9 339 minecraft:blue_terracotta
setblock 179 -10 363 minecraft:dark_prismarine
fill 180 -10 323 180 -7 323 minecraft:blue_terracotta
setblock 180 -10 332 minecraft:dark_prismarine
fill 180 -10 333 180 -9 333 minecraft:blue_terracotta
setblock 180 -10 337 minecraft:dark_prismarine
fill 180 -10 338 180 -7 338 minecraft:blue_terracotta
setblock 180 -10 342 minecraft:dark_prismarine
fill 180 -10 363 180 -7 363 minecraft:blue_terracotta
setblock 181 -10 331 minecraft:dark_prismarine
fill 181 -10 332 181 -8 332 minecraft:blue_terracotta
setblock 181 -10 336 minecraft:dark_prismarine
fill 181 -10 337 181 -7 337 minecraft:blue_terracotta
setblock 181 -10 341 minecraft:dark_prismarine
fill 181 -10 342 181 -8 342 minecraft:blue_terracotta
setblock 181 -10 357 minecraft:blue_terracotta
setblock 182 -10 325 minecraft:dark_prismarine
setblock 182 -10 326 minecraft:blue_terracotta
setblock 182 -10 330 minecraft:dark_prismarine
fill 182 -10 331 182 -7 331 minecraft:blue_terracotta
setblock 182 -10 335 minecraft:dark_prismarine
fill 182 -10 336 182 -7 336 minecraft:blue_terracotta
setblock 182 -10 340 minecraft:dark_prismarine
fill 182 -10 341 182 -7 341 minecraft:blue_terracotta
setblock 182 -10 355 minecraft:dark_prismarine
setblock 182 -10 356 minecraft:blue_terracotta
setblock 182 -10 360 minecraft:dark_prismarine
fill 182 -10 361 182 -9 361 minecraft:blue_terracotta
setblock 142 -9 324 minecraft:dark_prismarine
setblock 142 -9 325 minecraft:blue_terracotta
setblock 142 -9 329 minecraft:dark_prismarine
setblock 142 -9 330 minecraft:blue_terracotta
setblock 142 -9 334 minecraft:dark_prismarine
fill 142 -9 335 142 -7 335 minecraft:blue_terracotta
setblock 142 -9 339 minecraft:dark_prismarine
fill 142 -9 340 142 -8 340 minecraft:blue_terracotta
setblock 142 -9 355 minecraft:purple_concrete
setblock 142 -9 359 minecraft:dark_prismarine
fill 142 -9 360 142 -6 360 minecraft:blue_terracotta
setblock 143 -9 323 minecraft:dark_prismarine
setblock 143 -9 363 minecraft:dark_prismarine
fill 144 -9 323 147 -9 323 minecraft:blue_terracotta
fill 144 -9 363 147 -9 363 minecraft:blue_terracotta
fill 147 -9 362 148 -9 362 minecraft:blue_terracotta
setblock 148 -9 323 minecraft:dark_prismarine
setblock 148 -9 363 minecraft:dark_prismarine
fill 149 -9 323 149 -6 323 minecraft:blue_terracotta
setblock 149 -9 362 minecraft:dark_prismarine
fill 149 -9 363 152 -9 363 minecraft:blue_terracotta
fill 150 -9 353 151 4 353 minecraft:magenta_terracotta
setblock 150 -9 361 minecraft:dark_prismarine
fill 150 -9 362 150 -6 362 minecraft:blue_terracotta
fill 151 -9 361 154 -9 361 minecraft:blue_terracotta
fill 152 -9 360 155 -9 360 minecraft:blue_terracotta
setblock 153 -9 323 minecraft:dark_prismarine
setblock 153 -9 363 minecraft:dark_prismarine
fill 154 -9 323 154 -6 323 minecraft:blue_terracotta
setblock 154 -9 362 minecraft:dark_prismarine
fill 154 -9 363 154 -6 363 minecraft:blue_terracotta
setblock 155 -9 361 minecraft:dark_prismarine
fill 155 -9 362 155 -6 362 minecraft:blue_terracotta
setblock 156 -9 360 minecraft:dark_prismarine
fill 156 -9 361 156 -6 361 minecraft:blue_terracotta
fill 157 -9 360 157 -7 360 minecraft:blue_terracotta
setblock 158 -9 323 minecraft:dark_prismarine
setblock 158 -9 363 minecraft:dark_prismarine
setblock 159 -9 323 minecraft:blue_terracotta
fill 159 -9 329 159 33 329 minecraft:magenta_terracotta
setblock 159 -9 362 minecraft:dark_prismarine
fill 159 -9 363 159 -6 363 minecraft:blue_terracotta
setblock 160 -9 361 minecraft:dark_prismarine
fill 160 -9 362 160 -6 362 minecraft:blue_terracotta
setblock 161 -9 361 minecraft:blue_terracotta
setblock 163 -9 363 minecraft:dark_prismarine
fill 164 -9 358 164 33 358 minecraft:magenta_terracotta
setblock 164 -9 363 minecraft:blue_terracotta
setblock 165 -9 323 minecraft:purple_concrete
fill 169 -9 364 178 -5 364 minecraft:black_concrete
fill 170 -9 363 172 -9 363 minecraft:blue_terracotta
setblock 173 -9 362 minecraft:blue_terracotta
setblock 173 -9 363 minecraft:dark_prismarine
fill 174 -9 323 174 -6 323 minecraft:blue_terracotta
setblock 174 -9 362 minecraft:dark_prismarine
fill 174 -9 363 174 -6 363 minecraft:blue_terracotta
fill 175 -9 336 175 32 336 minecraft:magenta_terracotta
fill 175 -9 362 175 -6 362 minecraft:blue_terracotta
setblock 178 -9 323 minecraft:dark_prismarine
setblock 178 -9 362 minecraft:blue_terracotta
setblock 178 -9 363 minecraft:dark_prismarine
fill 179 -9 323 179 -6 323 minecraft:blue_terracotta
setblock 179 -9 337 minecraft:dark_prismarine
fill 179 -9 338 179 -8 338 minecraft:blue_terracotta
fill 179 -9 363 179 -6 363 minecraft:blue_terracotta
setblock 179 -9 364 minecraft:light_blue_wool
setblock 180 -9 332 minecraft:blue_terracotta
setblock 180 -9 336 minecraft:dark_prismarine
fill 180 -9 337 180 -7 337 minecraft:blue_terracotta
setblock 180 -9 341 minecraft:dark_prismarine
setblock 181 -9 330 minecraft:dark_prismarine
setblock 181 -9 331 minecraft:blue_terracotta
setblock 181 -9 335 minecraft:dark_prismarine
fill 181 -9 336 181 -6 336 minecraft:blue_terracotta
setblock 181 -9 340 minecraft:dark_prismarine
fill 181 -9 341 181 -7 341 minecraft:blue_terracotta
setblock 182 -9 329 minecraft:dark_prismarine
fill 182 -9 330 182 -8 330 minecraft:blue_terracotta
setblock 182 -9 334 minecraft:dark_prismarine
fill 182 -9 335 182 -6 335 minecraft:blue_terracotta
setblock 182 -9 339 minecraft:dark_prismarine
fill 182 -9 340 182 -6 340 minecraft:blue_terracotta
setblock 182 -9 350 minecraft:purple_concrete
setblock 182 -9 359 minecraft:dark_prismarine
fill 182 -9 360 182 -8 360 minecraft:blue_terracotta
setblock 142 -8 323 minecraft:dark_prismarine
setblock 142 -8 324 minecraft:blue_terracotta
setblock 142 -8 333 minecraft:dark_prismarine
setblock 142 -8 334 minecraft:blue_terracotta
setblock 142 -8 338 minecraft:dark_prismarine
setblock 142 -8 339 minecraft:blue_terracotta
setblock 142 -8 342 minecraft:purple_concrete
setblock 142 -8 358 minecraft:dark_prismarine
fill 142 -8 359 142 -6 359 minecraft:blue_terracotta
setblock 142 -8 363 minecraft:dark_prismarine
fill 143 -8 323 144 -8 323 minecraft:blue_terracotta
fill 143 -8 363 146 -8 363 minecraft:blue_terracotta
fill 146 -8 362 147 -8 362 minecraft:blue_terracotta
setblock 147 -8 323 minecraft:dark_prismarine
setblock 147 -8 363 minecraft:dark_prismarine
fill 148 -8 323 148 -5 323 minecraft:blue_terracotta
setblock 148 -8 362 minecraft:dark_prismarine
fill 148 -8 363 151 -8 363 minecraft:blue_terracotta
setblock 149 -8 361 minecraft:dark_prismarine
fill 149 -8 362 149 -5 362 minecraft:blue_terracotta
fill 150 -8 361 153 -8 361 minecraft:blue_terracotta
setblock 152 -8 323 minecraft:dark_prismarine
fill 152 -8 360 154 -8 360 minecraft:blue_terracotta
setblock 152 -8 363 minecraft:dark_prismarine
fill 153 -8 322 157 3 322 minecraft:black_concrete
fill 153 -8 323 153 -5 323 minecraft:blue_terracotta
setblock 153 -8 362 minecraft:dark_prismarine
fill 153 -8 363 153 -5 363 minecraft:blue_terracotta
setblock 154 -8 361 minecraft:dark_prismarine
fill 154 -8 362 154 -5 362 minecraft:blue_terracotta
setblock 155 -8 360 minecraft:dark_prismarine
fill 155 -8 361 155 -5 361 minecraft:blue_terracotta
fill 156 -8 360 156 -6 360 minecraft:blue_terracotta
setblock 157 -8 323 minecraft:dark_prismarine
setblock 157 -8 363 minecraft:dark_prismarine
setblock 158 -8 322 minecraft:cyan_concrete
setblock 158 -8 323 minecraft:blue_terracotta
setblock 158 -8 362 minecraft:dark_prismarine
fill 158 -8 363 158 -5 363 minecraft:blue_terracotta
fill 159 -8 322 167 -7 322 minecraft:black_concrete
setblock 159 -8 323 minecraft:purple_concrete
setblock 159 -8 361 minecraft:dark_prismarine
fill 159 -8 362 159 -5 362 minecraft:blue_terracotta
fill 160 -8 326 160 -7 326 minecraft:magenta_terracotta
setblock 160 -8 361 minecraft:blue_terracotta
setblock 162 -8 363 minecraft:dark_prismarine
setblock 163 -8 363 minecraft:blue_terracotta
setblock 165 -8 363 minecraft:purple_concrete
fill 170 -8 363 171 -8 363 minecraft:blue_terracotta
setblock 172 -8 363 minecraft:dark_prismarine
fill 173 -8 323 173 -5 323 minecraft:blue_terracotta
setblock 173 -8 362 minecraft:dark_prismarine
fill 173 -8 363 173 -5 363 minecraft:blue_terracotta
fill 174 -8 362 174 -5 362 minecraft:blue_terracotta
setblock 177 -8 323 minecraft:dark_prismarine
setblock 177 -8 363 minecraft:dark_prismarine
fill 178 -8 323 178 -5 323 minecraft:blue_terracotta
fill 178 -8 363 178 -5 363 minecraft:blue_terracotta
setblock 179 -8 337 minecraft:blue_terracotta
fill 179 -8 364 179 131 364 minecraft:black_concrete
setblock 180 -8 335 minecraft:dark_prismarine
fill 180 -8 336 180 -7 336 minecraft:blue_terracotta
setblock 180 -8 340 minecraft:dark_prismarine
setblock 181 -8 334 minecraft:dark_prismarine
fill 181 -8 335 181 -7 335 minecraft:blue_terracotta
setblock 181 -8 339 minecraft:dark_prismarine
fill 181 -8 340 181 -6 340 minecraft:blue_terracotta
setblock 182 -8 325 minecraft:purple_concrete
setblock 182 -8 329 minecraft:blue_terracotta
setblock 182 -8 333 minecraft:dark_prismarine
fill 182 -8 334 182 -6 334 minecraft:blue_terracotta
setblock 182 -8 338 minecraft:dark_prismarine
fill 182 -8 339 182 -5 339 minecraft:blue_terracotta
setblock 182 -8 343 minecraft:dark_prismarine
setblock 182 -8 344 minecraft:purple_concrete
setblock 183 -8 334 minecraft:cyan_concrete
fill 183 -8 335 183 16 339 minecraft:black_concrete
fill 142 -7 323 143 -5 323 minecraft:blue_terracotta
setblock 142 -7 337 minecraft:dark_prismarine
setblock 142 -7 338 minecraft:blue_terracotta
setblock 142 -7 348 minecraft:purple_concrete
setblock 142 -7 358 minecraft:blue_terracotta
setblock 142 -7 362 minecraft:dark_prismarine
fill 142 -7 363 145 -7 363 minecraft:blue_terracotta
setblock 144 -7 325 minecraft:light[level=12]
setblock 144 -7 332 minecraft:light[level=12]
setblock 144 -7 339 minecraft:light[level=12]
setblock 144 -7 346 minecraft:light[level=12]
setblock 144 -7 353 minecraft:light[level=12]
setblock 144 -7 360 minecraft:light[level=12]
setblock 146 -7 323 minecraft:dark_prismarine
setblock 146 -7 362 minecraft:blue_terracotta
setblock 146 -7 363 minecraft:dark_prismarine
fill 147 -7 323 147 -4 323 minecraft:blue_terracotta
setblock 147 -7 362 minecraft:dark_prismarine
fill 147 -7 363 150 -7 363 minecraft:blue_terracotta
fill 148 -7 351 148 -7 352 minecraft:magenta_terracotta
fill 148 -7 362 148 -4 362 minecraft:blue_terracotta
fill 149 -7 361 152 -7 361 minecraft:blue_terracotta
setblock 151 -7 323 minecraft:dark_prismarine
setblock 151 -7 325 minecraft:light[level=12]
setblock 151 -7 332 minecraft:light[level=12]
setblock 151 -7 339 minecraft:light[level=12]
setblock 151 -7 346 minecraft:light[level=12]
setblock 151 -7 360 minecraft:light[level=12]
setblock 151 -7 363 minecraft:dark_prismarine
fill 152 -7 323 152 -4 323 minecraft:blue_terracotta
fill 152 -7 360 153 -7 360 minecraft:blue_terracotta
setblock 152 -7 362 minecraft:dark_prismarine
fill 152 -7 363 152 -4 363 minecraft:blue_terracotta
setblock 153 -7 361 minecraft:dark_prismarine
fill 153 -7 362 153 -4 362 minecraft:blue_terracotta
setblock 154 -7 360 minecraft:dark_prismarine
fill 154 -7 361 154 -4 361 minecraft:blue_terracotta
fill 155 -7 360 155 -5 360 minecraft:blue_terracotta
setblock 156 -7 323 minecraft:dark_prismarine
setblock 156 -7 363 minecraft:dark_prismarine
fill 157 -7 323 157 -4 323 minecraft:blue_terracotta
setblock 157 -7 362 minecraft:dark_prismarine
fill 157 -7 363 157 -4 363 minecraft:blue_terracotta
fill 158 -7 322 158 124 322 minecraft:black_concrete
setblock 158 -7 332 minecraft:light[level=12]
setblock 158 -7 339 minecraft:light[level=12]
setblock 158 -7 346 minecraft:light[level=12]
setblock 158 -7 353 minecraft:light[level=12]
setblock 158 -7 360 minecraft:light[level=12]
setblock 158 -7 361 minecraft:dark_prismarine
fill 158 -7 362 158 -4 362 minecraft:blue_terracotta
setblock 159 -7 361 minecraft:blue_terracotta
fill 160 -7 325 161 -6 325 minecraft:dark_prismarine
fill 160 -7 328 160 33 328 minecraft:magenta_terracotta
fill 161 -7 326 161 -6 326 minecraft:dark_prismarine
fill 161 -7 333 162 -6 333 minecraft:dark_prismarine
setblock 161 -7 363 minecraft:dark_prismarine
fill 162 -7 363 162 -6 363 minecraft:blue_terracotta
setblock 165 -7 325 minecraft:light[level=12]
setblock 165 -7 332 minecraft:light[level=12]
setblock 165 -7 339 minecraft:light[level=12]
setblock 165 -7 346 minecraft:light[level=12]
setblock 165 -7 353 minecraft:light[level=12]
setblock 170 -7 363 minecraft:blue_terracotta
setblock 171 -7 363 minecraft:dark_prismarine
setblock 172 -7 325 minecraft:light[level=12]
setblock 172 -7 332 minecraft:light[level=12]
setblock 172 -7 339 minecraft:light[level=12]
setblock 172 -7 346 minecraft:light[level=12]
setblock 172 -7 353 minecraft:light[level=12]
setblock 172 -7 360 minecraft:light[level=12]
fill 172 -7 363 172 -4 363 minecraft:blue_terracotta
setblock 173 -7 332 minecraft:magenta_terracotta
fill 173 -7 362 173 -4 362 minecraft:blue_terracotta
setblock 176 -7 323 minecraft:dark_prismarine
setblock 176 -7 363 minecraft:dark_prismarine
fill 177 -7 323 177 -4 323 minecraft:blue_terracotta
fill 177 -7 363 177 -4 363 minecraft:blue_terracotta
fill 178 -7 348 178 10 348 minecraft:magenta_terracotta
setblock 179 -7 325 minecraft:light[level=12]
setblock 179 -7 332 minecraft:light[level=12]
setblock 179 -7 339 minecraft:light[level=12]
setblock 179 -7 346 minecraft:light[level=12]
setblock 179 -7 353 minecraft:light[level=12]
setblock 179 -7 360 minecraft:light[level=12]
setblock 180 -7 339 minecraft:dark_prismarine
setblock 181 -7 334 minecraft:blue_terracotta
setblock 181 -7 338 minecraft:dark_prismarine
fill 181 -7 339 181 -6 339 minecraft:blue_terracotta
setblock 182 -7 332 minecraft:dark_prismarine
fill 182 -7 333 182 -6 333 minecraft:blue_terracotta
setblock 182 -7 337 minecraft:dark_prismarine
fill 182 -7 338 182 -4 338 minecraft:blue_terracotta
setblock 182 -7 342 minecraft:dark_prismarine
fill 183 -7 334 183 19 334 minecraft:black_concrete
setblock 142 -6 329 minecraft:purple_concrete
setblock 142 -6 354 minecraft:purple_concrete
setblock 142 -6 361 minecraft:dark_prismarine
fill 142 -6 362 142 -4 363 minecraft:blue_terracotta
fill 143 -6 363 144 -6 363 minecraft:blue_terracotta
setblock 144 -6 323 minecraft:blue_terracotta
setblock 145 -6 323 minecraft:dark_prismarine
setblock 145 -6 363 minecraft:dark_prismarine
fill 146 -6 323 146 -3 323 minecraft:blue_terracotta
setblock 146 -6 362 minecraft:dark_prismarine
fill 146 -6 363 149 -6 363 minecraft:blue_terracotta
fill 147 -6 362 147 -3 362 minecraft:blue_terracotta
fill 148 -6 351 148 33 351 minecraft:magenta_terracotta
fill 149 -6 322 149 83 322 minecraft:black_concrete
fill 149 -6 361 151 -6 361 minecraft:blue_terracotta
setblock 150 -6 322 minecraft:light_blue_wool
setblock 150 -6 323 minecraft:dark_prismarine
setblock 150 -6 363 minecraft:dark_prismarine
fill 151 -6 322 151 66 322 minecraft:black_concrete
fill 151 -6 323 151 -3 323 minecraft:blue_terracotta
setblock 151 -6 362 minecraft:dark_prismarine
fill 151 -6 363 151 -3 363 minecraft:blue_terracotta
setblock 152 -6 360 minecraft:blue_terracotta
setblock 152 -6 361 minecraft:dark_prismarine
fill 152 -6 362 152 -3 362 minecraft:blue_terracotta
setblock 153 -6 360 minecraft:dark_prismarine
fill 153 -6 361 153 -3 361 minecraft:blue_terracotta
fill 154 -6 360 154 -4 360 minecraft:blue_terracotta
setblock 155 -6 323 minecraft:dark_prismarine
setblock 155 -6 363 minecraft:dark_prismarine
fill 156 -6 323 156 -3 323 minecraft:blue_terracotta
setblock 156 -6 362 minecraft:dark_prismarine
fill 156 -6 363 156 -3 363 minecraft:blue_terracotta
setblock 157 -6 361 minecraft:dark_prismarine
fill 157 -6 362 157 -3 362 minecraft:blue_terracotta
setblock 158 -6 361 minecraft:blue_terracotta
fill 159 -6 322 166 14 322 minecraft:black_concrete
setblock 160 -6 326 minecraft:dark_prismarine
setblock 160 -6 363 minecraft:dark_prismarine
fill 161 -6 363 161 -3 363 minecraft:blue_terracotta
fill 166 -6 361 166 -4 361 minecraft:magenta_terracotta
setblock 167 -6 322 minecraft:light_blue_wool
setblock 169 -6 363 minecraft:blue_terracotta
setblock 170 -6 363 minecraft:dark_prismarine
fill 171 -6 363 171 -3 363 minecraft:blue_terracotta
fill 172 -6 323 172 -4 323 minecraft:blue_terracotta
setblock 175 -6 323 minecraft:dark_prismarine
setblock 175 -6 363 minecraft:dark_prismarine
fill 176 -6 323 176 -3 323 minecraft:blue_terracotta
fill 176 -6 363 176 -3 363 minecraft:blue_terracotta
setblock 180 -6 323 minecraft:dark_prismarine
setblock 181 -6 337 minecraft:dark_prismarine
setblock 181 -6 338 minecraft:blue_terracotta
setblock 182 -6 332 minecraft:purple_concrete
setblock 182 -6 336 minecraft:dark_prismarine
fill 182 -6 337 182 -4 337 minecraft:blue_terracotta
setblock 182 -6 341 minecraft:dark_prismarine
fill 182 -6 342 182 -3 342 minecraft:blue_terracotta
setblock 182 -6 357 minecraft:purple_concrete
setblock 142 -5 335 minecraft:purple_concrete
setblock 142 -5 360 minecraft:dark_prismarine
fill 142 -5 361 142 -2 361 minecraft:blue_terracotta
setblock 143 -5 363 minecraft:blue_terracotta
setblock 144 -5 323 minecraft:dark_prismarine
setblock 144 -5 363 minecraft:dark_prismarine
fill 145 -5 323 145 -2 323 minecraft:blue_terracotta
setblock 145 -5 362 minecraft:dark_prismarine
fill 145 -5 363 148 -5 363 minecraft:blue_terracotta
fill 146 -5 362 146 -2 362 minecraft:blue_terracotta
fill 148 -5 352 148 31 352 minecraft:magenta_terracotta
fill 148 -5 361 150 -5 361 minecraft:blue_terracotta
setblock 149 -5 323 minecraft:dark_prismarine
setblock 149 -5 363 minecraft:dark_prismarine
fill 150 -5 322 150 131 322 minecraft:black_concrete
fill 150 -5 323 150 -2 323 minecraft:blue_terracotta
fill 150 -5 349 150 33 349 minecraft:magenta_terracotta
setblock 150 -5 362 minecraft:dark_prismarine
fill 150 -5 363 150 -2 363 minecraft:blue_terracotta
setblock 151 -5 361 minecraft:dark_prismarine
fill 151 -5 362 151 -2 362 minecraft:blue_terracotta
setblock 152 -5 360 minecraft:dark_prismarine
fill 152 -5 361 152 -2 361 minecraft:blue_terracotta
fill 153 -5 360 153 -3 360 minecraft:blue_terracotta
setblock 154 -5 323 minecraft:dark_prismarine
setblock 154 -5 363 minecraft:dark_prismarine
fill 155 -5 323 155 -2 323 minecraft:blue_terracotta
setblock 155 -5 362 minecraft:dark_prismarine
fill 155 -5 363 155 -2 363 minecraft:blue_terracotta
setblock 156 -5 361 minecraft:dark_prismarine
fill 156 -5 362 156 -2 362 minecraft:blue_terracotta
fill 157 -5 361 157 -4 361 minecraft:blue_terracotta
setblock 159 -5 363 minecraft:dark_prismarine
fill 160 -5 323 160 -4 323 minecraft:purple_concrete
fill 160 -5 326 160 14 326 minecraft:magenta_terracotta
fill 160 -5 363 160 -2 363 minecraft:blue_terracotta
setblock 166 -5 323 minecraft:purple_concrete
fill 167 -5 322 167 131 322 minecraft:black_concrete
setblock 168 -5 363 minecraft:blue_terracotta
setblock 169 -5 363 minecraft:dark_prismarine
fill 170 -5 363 170 -2 363 minecraft:blue_terracotta
fill 171 -5 323 171 -3 323 minecraft:blue_terracotta
fill 172 -5 362 172 -3 362 minecraft:blue_terracotta
setblock 174 -5 323 minecraft:dark_prismarine
setblock 174 -5 363 minecraft:dark_prismarine
fill 175 -5 323 175 -2 323 minecraft:blue_terracotta
setblock 175 -5 362 minecraft:dark_prismarine
fill 175 -5 363 175 -2 363 minecraft:blue_terracotta
setblock 179 -5 323 minecraft:dark_prismarine
setblock 179 -5 363 minecraft:dark_prismarine
fill 180 -5 323 181 -3 323 minecraft:blue_terracotta
setblock 182 -5 326 minecraft:purple_concrete
setblock 182 -5 335 minecraft:dark_prismarine
fill 182 -5 336 182 -4 336 minecraft:blue_terracotta
setblock 182 -5 340 minecraft:dark_prismarine
fill 182 -5 341 182 -2 341 minecraft:blue_terracotta
setblock 182 -5 351 minecraft:purple_concrete
setblock 142 -4 323 minecraft:blue_terracotta
setblock 142 -4 324 minecraft:dark_prismarine
setblock 142 -4 341 minecraft:purple_concrete
fill 142 -4 360 142 -1 360 minecraft:blue_terracotta
setblock 143 -4 323 minecraft:dark_prismarine
setblock 143 -4 363 minecraft:dark_prismarine
fill 144 -4 323 144 -1 323 minecraft:blue_terracotta
setblock 144 -4 362 minecraft:dark_prismarine
fill 144 -4 363 147 -4 363 minecraft:blue_terracotta
fill 145 -4 362 145 -1 362 minecraft:blue_terracotta
setblock 148 -4 323 minecraft:dark_prismarine
fill 148 -4 361 149 -4 361 minecraft:blue_terracotta
setblock 148 -4 363 minecraft:dark_prismarine
fill 149 -4 323 149 -1 323 minecraft:blue_terracotta
setblock 149 -4 362 minecraft:dark_prismarine
fill 149 -4 363 149 -1 363 minecraft:blue_terracotta
fill 150 -4 324 151 -4 324 minecraft:blue_terracotta
setblock 150 -4 361 minecraft:dark_prismarine
fill 150 -4 362 150 -1 362 minecraft:blue_terracotta
fill 151 -4 349 151 25 349 minecraft:magenta_terracotta
fill 151 -4 361 151 -1 361 minecraft:blue_terracotta
setblock 152 -4 324 minecraft:dark_prismarine
fill 152 -4 360 152 -1 360 minecraft:blue_terracotta
setblock 153 -4 323 minecraft:dark_prismarine
fill 153 -4 324 153 -1 324 minecraft:blue_terracotta
setblock 153 -4 363 minecraft:dark_prismarine
fill 154 -4 323 154 -1 323 minecraft:blue_terracotta
setblock 154 -4 362 minecraft:dark_prismarine
fill 154 -4 363 154 -1 363 minecraft:blue_terracotta
setblock 155 -4 361 minecraft:dark_prismarine
fill 155 -4 362 155 -1 362 minecraft:blue_terracotta
fill 156 -4 361 156 -2 361 minecraft:blue_terracotta
setblock 158 -4 363 minecraft:dark_prismarine
setblock 159 -4 362 minecraft:dark_prismarine
fill 159 -4 363 159 -1 363 minecraft:blue_terracotta
setblock 164 -4 363 minecraft:purple_concrete
setblock 167 -4 363 minecraft:blue_terracotta
setblock 168 -4 363 minecraft:dark_prismarine
fill 169 -4 363 169 -1 363 minecraft:blue_terracotta
fill 169 -4 364 171 45 364 minecraft:black_concrete
fill 170 -4 323 170 -2 323 minecraft:blue_terracotta
fill 171 -4 362 171 -2 362 minecraft:blue_terracotta
setblock 172 -4 364 minecraft:cyan_concrete
setblock 173 -4 323 minecraft:dark_prismarine
fill 173 -4 324 176 -4 324 minecraft:blue_terracotta
setblock 173 -4 363 minecraft:dark_prismarine
fill 173 -4 364 178 -4 364 minecraft:black_concrete
fill 174 -4 323 174 -1 323 minecraft:blue_terracotta
setblock 174 -4 362 minecraft:dark_prismarine
fill 174 -4 363 174 -1 363 minecraft:blue_terracotta
fill 175 -4 362 175 -2 362 minecraft:blue_terracotta
setblock 178 -4 323 minecraft:dark_prismarine
setblock 178 -4 363 minecraft:dark_prismarine
fill 179 -4 323 179 -1 323 minecraft:blue_terracotta
fill 179 -4 363 179 -1 363 minecraft:blue_terracotta
setblock 182 -4 323 minecraft:blue_terracotta
setblock 182 -4 324 minecraft:dark_prismarine
setblock 182 -4 339 minecraft:dark_prismarine
fill 182 -4 340 182 -1 340 minecraft:blue_terracotta
setblock 182 -4 345 minecraft:purple_concrete
setblock 141 -3 342 minecraft:light_blue_wool
fill 142 -3 322 146 39 322 minecraft:black_concrete
setblock 142 -3 323 minecraft:dark_prismarine
fill 142 -3 324 142 -1 325 minecraft:blue_terracotta
setblock 142 -3 328 minecraft:purple_concrete
setblock 142 -3 347 minecraft:purple_concrete
setblock 142 -3 362 minecraft:blue_terracotta
setblock 142 -3 363 minecraft:dark_prismarine
fill 143 -3 323 143 0 323 minecraft:blue_terracotta
setblock 143 -3 362 minecraft:dark_prismarine
fill 143 -3 363 146 -3 363 minecraft:blue_terracotta
setblock 144 -3 325 minecraft:light[level=13]
setblock 144 -3 333 minecraft:light[level=13]
setblock 144 -3 341 minecraft:light[level=13]
setblock 144 -3 349 minecraft:light[level=13]
setblock 144 -3 357 minecraft:light[level=13]
fill 144 -3 362 144 0 362 minecraft:blue_terracotta
setblock 147 -3 322 minecraft:light_blue_wool
setblock 147 -3 323 minecraft:dark_prismarine
fill 147 -3 324 150 -3 324 minecraft:blue_terracotta
fill 147 -3 361 148 -3 361 minecraft:blue_terracotta
setblock 147 -3 363 minecraft:dark_prismarine
fill 148 -3 323 148 0 323 minecraft:blue_terracotta
setblock 148 -3 362 minecraft:dark_prismarine
fill 148 -3 363 148 0 363 minecraft:blue_terracotta
setblock 149 -3 361 minecraft:dark_prismarine
fill 149 -3 362 149 0 362 minecraft:blue_terracotta
fill 150 -3 361 150 0 361 minecraft:blue_terracotta
setblock 151 -3 324 minecraft:dark_prismarine
fill 151 -3 360 151 0 360 minecraft:blue_terracotta
setblock 152 -3 323 minecraft:dark_prismarine
fill 152 -3 324 152 0 324 minecraft:blue_terracotta
setblock 152 -3 325 minecraft:light[level=13]
setblock 152 -3 333 minecraft:light[level=13]
setblock 152 -3 341 minecraft:light[level=13]
setblock 152 -3 349 minecraft:light[level=13]
setblock 152 -3 357 minecraft:light[level=13]
setblock 152 -3 363 minecraft:dark_prismarine
fill 153 -3 323 153 0 323 minecraft:blue_terracotta
setblock 153 -3 362 minecraft:dark_prismarine
fill 153 -3 363 153 0 363 minecraft:blue_terracotta
fill 154 -3 324 154 -2 324 minecraft:blue_terracotta
setblock 154 -3 361 minecraft:dark_prismarine
fill 154 -3 362 154 0 362 minecraft:blue_terracotta
fill 155 -3 361 155 0 361 minecraft:blue_terracotta
setblock 157 -3 323 minecraft:dark_prismarine
fill 157 -3 325 158 -2 325 minecraft:magenta_terracotta
setblock 157 -3 363 minecraft:dark_prismarine
setblock 158 -3 362 minecraft:dark_prismarine
fill 158 -3 363 158 0 363 minecraft:blue_terracotta
setblock 160 -3 325 minecraft:light[level=13]
setblock 160 -3 333 minecraft:light[level=13]
setblock 160 -3 349 minecraft:light[level=13]
setblock 160 -3 357 minecraft:light[level=13]
setblock 166 -3 363 minecraft:blue_terracotta
setblock 167 -3 363 minecraft:dark_prismarine
fill 168 -3 323 169 -1 323 minecraft:blue_terracotta
setblock 168 -3 325 minecraft:light[level=13]
setblock 168 -3 333 minecraft:light[level=13]
setblock 168 -3 341 minecraft:light[level=13]
setblock 168 -3 349 minecraft:light[level=13]
setblock 168 -3 357 minecraft:light[level=13]
fill 168 -3 363 168 0 363 minecraft:blue_terracotta
fill 170 -3 362 170 -1 362 minecraft:blue_terracotta
setblock 171 -3 324 minecraft:dark_prismarine
setblock 172 -3 323 minecraft:dark_prismarine
fill 172 -3 324 175 -3 324 minecraft:blue_terracotta
setblock 172 -3 363 minecraft:dark_prismarine
fill 172 -3 364 172 131 364 minecraft:black_concrete
fill 173 -3 323 173 0 323 minecraft:blue_terracotta
setblock 173 -3 362 minecraft:dark_prismarine
fill 173 -3 363 173 0 363 minecraft:blue_terracotta
setblock 173 -3 364 minecraft:cyan_concrete
fill 174 -3 337 174 33 337 minecraft:magenta_terracotta
fill 174 -3 362 174 0 362 minecraft:blue_terracotta
fill 174 -3 364 178 32 364 minecraft:black_concrete
setblock 176 -3 324 minecraft:dark_prismarine
setblock 176 -3 325 minecraft:light[level=13]
setblock 176 -3 333 minecraft:light[level=13]
setblock 176 -3 341 minecraft:light[level=13]
setblock 177 -3 323 minecraft:dark_prismarine
fill 177 -3 324 177 0 324 minecraft:blue_terracotta
setblock 177 -3 363 minecraft:dark_prismarine
fill 178 -3 323 178 0 323 minecraft:blue_terracotta
fill 178 -3 363 178 0 363 minecraft:blue_terracotta
fill 180 -3 363 180 -2 363 minecraft:blue_terracotta
setblock 182 -3 323 minecraft:dark_prismarine
fill 182 -3 324 182 -1 325 minecraft:blue_terracotta
setblock 182 -3 333 minecraft:purple_concrete
setblock 182 -3 338 minecraft:dark_prismarine
fill 182 -3 339 182 0 339 minecraft:blue_terracotta
setblock 182 -3 358 minecraft:purple_concrete
fill 141 -2 342 141 131 342 minecraft:black_concrete
fill 142 -2 323 142 1 323 minecraft:blue_terracotta
setblock 142 -2 326 minecraft:blue_terracotta
setblock 142 -2 334 minecraft:purple_concrete
setblock 142 -2 353 minecraft:purple_concrete
setblock 142 -2 359 minecraft:purple_concrete
setblock 142 -2 362 minecraft:dark_prismarine
fill 142 -2 363 145 -2 363 minecraft:blue_terracotta
fill 142 -2 364 142 70 364 minecraft:black_concrete
fill 143 -2 362 143 1 362 minecraft:blue_terracotta
setblock 143 -2 364 minecraft:light_blue_wool
fill 144 -2 364 149 88 364 minecraft:black_concrete
setblock 145 -2 324 minecraft:dark_prismarine
setblock 146 -2 323 minecraft:dark_prismarine
fill 146 -2 324 149 -2 324 minecraft:blue_terracotta
fill 146 -2 361 147 -2 361 minecraft:blue_terracotta
setblock 146 -2 363 minecraft:dark_prismarine
fill 147 -2 322 147 87 322 minecraft:black_concrete
fill 147 -2 323 147 1 323 minecraft:blue_terracotta
setblock 147 -2 362 minecraft:dark_prismarine
fill 147 -2 363 147 1 363 minecraft:blue_terracotta
setblock 148 -2 361 minecraft:dark_prismarine
fill 148 -2 362 148 1 362 minecraft:blue_terracotta
fill 149 -2 361 149 1 361 minecraft:blue_terracotta
setblock 150 -2 324 minecraft:dark_prismarine
setblock 151 -2 323 minecraft:dark_prismarine
fill 151 -2 324 151 1 324 minecraft:blue_terracotta
setblock 151 -2 363 minecraft:dark_prismarine
fill 152 -2 323 152 1 323 minecraft:blue_terracotta
setblock 152 -2 362 minecraft:dark_prismarine
fill 152 -2 363 152 1 363 minecraft:blue_terracotta
setblock 153 -2 361 minecraft:dark_prismarine
fill 153 -2 362 153 1 362 minecraft:blue_terracotta
fill 154 -2 361 154 1 361 minecraft:blue_terracotta
setblock 156 -2 323 minecraft:dark_prismarine
setblock 156 -2 363 minecraft:dark_prismarine
fill 157 -2 323 157 1 323 minecraft:blue_terracotta
setblock 157 -2 362 minecraft:dark_prismarine
fill 157 -2 363 157 1 363 minecraft:blue_terracotta
fill 158 -2 362 158 -1 362 minecraft:blue_terracotta
setblock 161 -2 363 minecraft:dark_prismarine
setblock 165 -2 363 minecraft:blue_terracotta
setblock 166 -2 363 minecraft:dark_prismarine
fill 167 -2 323 167 1 323 minecraft:blue_terracotta
fill 167 -2 363 167 1 363 minecraft:blue_terracotta
setblock 169 -2 324 minecraft:blue_terracotta
fill 169 -2 362 169 0 362 minecraft:blue_terracotta
setblock 170 -2 324 minecraft:dark_prismarine
setblock 171 -2 323 minecraft:dark_prismarine
fill 171 -2 324 174 -2 324 minecraft:blue_terracotta
setblock 171 -2 363 minecraft:dark_prismarine
fill 172 -2 323 172 1 323 minecraft:blue_terracotta
setblock 172 -2 362 minecraft:dark_prismarine
fill 172 -2 363 172 1 363 minecraft:blue_terracotta
fill 173 -2 337 173 32 337 minecraft:magenta_terracotta
fill 173 -2 362 173 1 362 minecraft:blue_terracotta
fill 173 -2 364 173 9 364 minecraft:black_concrete
setblock 175 -2 324 minecraft:dark_prismarine
setblock 176 -2 323 minecraft:dark_prismarine
fill 176 -2 324 176 1 324 minecraft:blue_terracotta
setblock 176 -2 363 minecraft:dark_prismarine
fill 177 -2 323 177 1 323 minecraft:blue_terracotta
fill 177 -2 363 177 1 363 minecraft:blue_terracotta
fill 178 -2 324 179 -2 324 minecraft:blue_terracotta
setblock 180 -2 323 minecraft:blue_terracotta
setblock 181 -2 323 minecraft:dark_prismarine
setblock 181 -2 363 minecraft:dark_prismarine
fill 182 -2 323 182 1 323 minecraft:blue_terracotta
setblock 182 -2 326 minecraft:blue_terracotta
setblock 182 -2 327 minecraft:dark_prismarine
setblock 182 -2 338 minecraft:blue_terracotta
setblock 182 -2 342 minecraft:dark_prismarine
setblock 182 -2 352 minecraft:purple_concrete
fill 182 -2 363 182 1 363 minecraft:blue_terracotta
fill 141 -1 330 141 131 331 minecraft:black_concrete
setblock 141 -1 332 minecraft:cyan_concrete
fill 141 -1 333 141 7 341 minecraft:black_concrete
setblock 142 -1 326 minecraft:dark_prismarine
fill 142 -1 327 142 2 327 minecraft:blue_terracotta
setblock 142 -1 340 minecraft:purple_concrete
fill 142 -1 359 142 0 359 minecraft:blue_terracotta
setblock 142 -1 361 minecraft:dark_prismarine
fill 142 -1 362 142 1 363 minecraft:blue_terracotta
setblock 143 -1 324 minecraft:blue_terracotta
fill 143 -1 361 143 2 361 minecraft:blue_terracotta
fill 143 -1 363 144 -1 363 minecraft:blue_terracotta
fill 143 -1 364 143 131 364 minecraft:black_concrete
setblock 144 -1 324 minecraft:dark_prismarine
setblock 144 -1 325 minecraft:light[level=12]
setblock 144 -1 332 minecraft:light[level=12]
setblock 144 -1 339 minecraft:light[level=12]
setblock 144 -1 346 minecraft:light[level=12]
setblock 144 -1 353 minecraft:light[level=12]
setblock 144 -1 360 minecraft:light[level=12]
setblock 145 -1 323 minecraft:dark_prismarine
fill 145 -1 324 148 -1 324 minecraft:blue_terracotta
setblock 145 -1 363 minecraft:dark_prismarine
fill 146 -1 323 146 2 323 minecraft:blue_terracotta
setblock 146 -1 361 minecraft:blue_terracotta
setblock 146 -1 362 minecraft:dark_prismarine
fill 146 -1 363 146 2 363 minecraft:blue_terracotta
setblock 147 -1 361 minecraft:dark_prismarine
fill 147 -1 362 147 2 362 minecraft:blue_terracotta
fill 148 -1 361 148 2 361 minecraft:blue_terracotta
setblock 149 -1 324 minecraft:dark_prismarine
setblock 150 -1 323 minecraft:dark_prismarine
fill 150 -1 324 150 2 324 minecraft:blue_terracotta
fill 150 -1 360 150 1 360 minecraft:blue_terracotta
setblock 150 -1 363 minecraft:dark_prismarine
fill 151 -1 323 151 2 323 minecraft:blue_terracotta
setblock 151 -1 325 minecraft:light[level=12]
setblock 151 -1 332 minecraft:light[level=12]
setblock 151 -1 339 minecraft:light[level=12]
setblock 151 -1 346 minecraft:light[level=12]
setblock 151 -1 362 minecraft:dark_prismarine
fill 151 -1 363 151 2 363 minecraft:blue_terracotta
fill 151 -1 364 160 6 364 minecraft:black_concrete
setblock 152 -1 361 minecraft:dark_prismarine
fill 152 -1 362 152 2 362 minecraft:blue_terracotta
fill 153 -1 361 153 2 361 minecraft:blue_terracotta
setblock 154 -1 324 minecraft:dark_prismarine
setblock 155 -1 323 minecraft:dark_prismarine
fill 155 -1 324 155 2 324 minecraft:blue_terracotta
setblock 155 -1 363 minecraft:dark_prismarine
fill 156 -1 323 156 2 323 minecraft:blue_terracotta
setblock 156 -1 362 minecraft:dark_prismarine
fill 156 -1 363 156 2 363 minecraft:blue_terracotta
fill 157 -1 362 157 1 362 minecraft:blue_terracotta
fill 158 -1 323 158 0 323 minecraft:blue_terracotta
fill 158 -1 325 158 2 325 minecraft:magenta_terracotta
setblock 158 -1 332 minecraft:light[level=12]
setblock 158 -1 339 minecraft:light[level=12]
setblock 158 -1 346 minecraft:light[level=12]
setblock 158 -1 353 minecraft:light[level=12]
setblock 158 -1 360 minecraft:light[level=12]
setblock 160 -1 363 minecraft:dark_prismarine
setblock 161 -1 323 minecraft:purple_concrete
fill 161 -1 363 164 -1 363 minecraft:blue_terracotta
setblock 161 -1 364 minecraft:light_blue_wool
fill 162 -1 364 162 128 364 minecraft:black_concrete
setblock 165 -1 323 minecraft:dark_prismarine
setblock 165 -1 325 minecraft:light[level=12]
setblock 165 -1 332 minecraft:light[level=12]
setblock 165 -1 339 minecraft:light[level=12]
setblock 165 -1 346 minecraft:light[level=12]
setblock 165 -1 353 minecraft:light[level=12]
setblock 165 -1 363 minecraft:dark_prismarine
fill 166 -1 323 166 2 323 minecraft:blue_terracotta
fill 166 -1 363 166 2 363 minecraft:blue_terracotta
setblock 168 -1 324 minecraft:blue_terracotta
fill 168 -1 362 168 1 362 minecraft:blue_terracotta
setblock 169 -1 324 minecraft:dark_prismarine
setblock 170 -1 323 minecraft:dark_prismarine
fill 170 -1 324 173 -1 324 minecraft:blue_terracotta
setblock 170 -1 363 minecraft:dark_prismarine
fill 171 -1 323 171 2 323 minecraft:blue_terracotta
fill 171 -1 325 172 -1 325 minecraft:blue_terracotta
setblock 171 -1 362 minecraft:dark_prismarine
fill 171 -1 363 171 2 363 minecraft:blue_terracotta
setblock 172 -1 332 minecraft:light[level=12]
setblock 172 -1 339 minecraft:light[level=12]
setblock 172 -1 346 minecraft:light[level=12]
setblock 172 -1 353 minecraft:light[level=12]
setblock 172 -1 360 minecraft:light[level=12]
fill 172 -1 362 172 2 362 minecraft:blue_terracotta
setblock 173 -1 325 minecraft:dark_prismarine
setblock 174 -1 324 minecraft:dark_prismarine
fill 174 -1 325 175 1 325 minecraft:blue_terracotta
setblock 175 -1 323 minecraft:dark_prismarine
fill 175 -1 324 175 2 324 minecraft:blue_terracotta
setblock 175 -1 363 minecraft:dark_prismarine
fill 176 -1 323 176 2 323 minecraft:blue_terracotta
fill 176 -1 335 176 33 335 minecraft:magenta_terracotta
fill 176 -1 363 176 2 363 minecraft:blue_terracotta
setblock 178 -1 324 minecraft:blue_terracotta
setblock 179 -1 324 minecraft:dark_prismarine
setblock 179 -1 325 minecraft:light[level=12]
setblock 179 -1 332 minecraft:light[level=12]
setblock 179 -1 339 minecraft:light[level=12]
setblock 179 -1 346 minecraft:light[level=12]
setblock 179 -1 353 minecraft:light[level=12]
setblock 179 -1 360 minecraft:light[level=12]
setblock 180 -1 323 minecraft:dark_prismarine
fill 180 -1 324 181 1 324 minecraft:blue_terracotta
setblock 180 -1 363 minecraft:dark_prismarine
fill 181 -1 323 181 2 323 minecraft:blue_terracotta
fill 181 -1 325 181 0 325 minecraft:blue_terracotta
fill 181 -1 363 181 2 363 minecraft:blue_terracotta
setblock 182 -1 326 minecraft:dark_prismarine
fill 182 -1 327 182 1 328 minecraft:blue_terracotta
setblock 182 -1 341 minecraft:dark_prismarine
fill 182 -1 342 182 1 343 minecraft:blue_terracotta
setblock 182 -1 346 minecraft:purple_concrete
fill 182 -1 362 182 2 362 minecraft:blue_terracotta
fill 141 0 332 141 131 332 minecraft:black_concrete
fill 141 0 349 141 9 350 minecraft:black_concrete
setblock 141 0 351 minecraft:light_blue_wool
fill 141 0 352 141 11 362 minecraft:black_concrete
setblock 142 0 324 minecraft:blue_terracotta
setblock 142 0 325 minecraft:dark_prismarine
fill 142 0 326 142 3 326 minecraft:blue_terracotta
fill 142 0 328 142 1 328 minecraft:blue_terracotta
setblock 142 0 346 minecraft:purple_concrete
setblock 142 0 360 minecraft:dark_prismarine
fill 142 0 361 142 3 361 minecraft:blue_terracotta
setblock 143 0 324 minecraft:dark_prismarine
fill 143 0 325 143 3 325 minecraft:blue_terracotta
setblock 143 0 363 minecraft:blue_terracotta
setblock 144 0 323 minecraft:dark_prismarine
fill 144 0 324 147 0 324 minecraft:blue_terracotta
setblock 144 0 363 minecraft:dark_prismarine
fill 145 0 323 145 3 323 minecraft:blue_terracotta
setblock 145 0 361 minecraft:blue_terracotta
setblock 145 0 362 minecraft:dark_prismarine
fill 145 0 363 145 3 363 minecraft:blue_terracotta
setblock 146 0 361 minecraft:dark_prismarine
fill 146 0 362 146 3 362 minecraft:blue_terracotta
setblock 147 0 325 minecraft:dark_prismarine
fill 147 0 361 147 3 361 minecraft:blue_terracotta
setblock 148 0 324 minecraft:dark_prismarine
fill 148 0 325 151 0 325 minecraft:blue_terracotta
fill 148 0 350 148 33 350 minecraft:magenta_terracotta
setblock 149 0 323 minecraft:dark_prismarine
fill 149 0 324 149 3 324 minecraft:blue_terracotta
fill 149 0 349 149 33 349 minecraft:magenta_terracotta
fill 149 0 360 149 1 360 minecraft:blue_terracotta
setblock 149 0 363 minecraft:dark_prismarine
fill 150 0 323 150 3 323 minecraft:blue_terracotta
setblock 150 0 362 minecraft:dark_prismarine
fill 150 0 363 150 3 363 minecraft:blue_terracotta
setblock 151 0 361 minecraft:dark_prismarine
fill 151 0 362 151 3 362 minecraft:blue_terracotta
fill 152 0 361 152 3 361 minecraft:blue_terracotta
setblock 153 0 324 minecraft:dark_prismarine
setblock 154 0 323 minecraft:dark_prismarine
fill 154 0 324 154 3 324 minecraft:blue_terracotta
setblock 154 0 363 minecraft:dark_prismarine
fill 155 0 323 155 3 323 minecraft:blue_terracotta
setblock 155 0 362 minecraft:dark_prismarine
fill 155 0 363 155 3 363 minecraft:blue_terracotta
fill 156 0 362 156 2 362 minecraft:blue_terracotta
setblock 159 0 363 minecraft:dark_prismarine
fill 160 0 363 163 0 363 minecraft:blue_terracotta
fill 161 0 364 161 132 364 minecraft:black_concrete
setblock 163 0 323 minecraft:blue_terracotta
setblock 164 0 323 minecraft:dark_prismarine
fill 164 0 357 164 32 357 minecraft:magenta_terracotta
setblock 164 0 363 minecraft:dark_prismarine
fill 165 0 323 165 3 323 minecraft:blue_terracotta
fill 165 0 363 165 3 363 minecraft:blue_terracotta
fill 166 0 324 167 0 324 minecraft:blue_terracotta
setblock 168 0 323 minecraft:blue_terracotta
setblock 168 0 324 minecraft:dark_prismarine
setblock 169 0 323 minecraft:dark_prismarine
fill 169 0 324 171 0 325 minecraft:blue_terracotta
setblock 169 0 363 minecraft:dark_prismarine
fill 170 0 323 170 3 323 minecraft:blue_terracotta
setblock 170 0 362 minecraft:dark_prismarine
fill 170 0 363 170 3 363 minecraft:blue_terracotta
fill 171 0 362 171 3 362 minecraft:blue_terracotta
setblock 172 0 324 minecraft:blue_terracotta
setblock 172 0 325 minecraft:dark_prismarine
setblock 173 0 324 minecraft:dark_prismarine
fill 173 0 325 173 3 325 minecraft:blue_terracotta
setblock 174 0 323 minecraft:dark_prismarine
fill 174 0 324 174 3 324 minecraft:blue_terracotta
setblock 174 0 363 minecraft:dark_prismarine
fill 175 0 323 175 3 323 minecraft:blue_terracotta
fill 175 0 363 175 3 363 minecraft:blue_terracotta
setblock 176 0 325 minecraft:blue_terracotta
setblock 178 0 324 minecraft:dark_prismarine
setblock 179 0 323 minecraft:dark_prismarine
fill 179 0 324 179 3 324 minecraft:blue_terracotta
setblock 179 0 363 minecraft:dark_prismarine
fill 180 0 323 180 3 323 minecraft:blue_terracotta
fill 180 0 363 180 3 363 minecraft:blue_terracotta
setblock 181 0 326 minecraft:dark_prismarine
setblock 182 0 324 minecraft:blue_terracotta
setblock 182 0 325 minecraft:dark_prismarine
fill 182 0 326 182 3 326 minecraft:blue_terracotta
setblock 182 0 329 minecraft:blue_terracotta
setblock 182 0 330 minecraft:dark_prismarine
setblock 182 0 340 minecraft:dark_prismarine
fill 182 0 341 182 2 341 minecraft:blue_terracotta
setblock 182 0 344 minecraft:blue_terracotta
setblock 182 0 345 minecraft:dark_prismarine
setblock 182 0 359 minecraft:purple_concrete
fill 141 1 351 141 131 351 minecraft:black_concrete
setblock 142 1 324 minecraft:dark_prismarine
fill 142 1 325 142 4 325 minecraft:blue_terracotta
setblock 142 1 333 minecraft:purple_concrete
setblock 142 1 343 minecraft:blue_terracotta
setblock 142 1 344 minecraft:dark_prismarine
fill 142 1 345 142 2 347 minecraft:blue_terracotta
setblock 142 1 352 minecraft:purple_concrete
setblock 142 1 358 minecraft:blue_terracotta
setblock 142 1 359 minecraft:dark_prismarine
fill 142 1 360 143 3 360 minecraft:blue_terracotta
setblock 143 1 323 minecraft:dark_prismarine
fill 143 1 324 146 1 324 minecraft:blue_terracotta
fill 143 1 326 143 2 326 minecraft:blue_terracotta
setblock 143 1 363 minecraft:dark_prismarine
fill 144 1 323 144 4 323 minecraft:blue_terracotta
setblock 144 1 362 minecraft:dark_prismarine
fill 144 1 363 144 4 363 minecraft:blue_terracotta
setblock 145 1 325 minecraft:blue_terracotta
setblock 145 1 361 minecraft:dark_prismarine
fill 145 1 362 145 4 362 minecraft:blue_terracotta
setblock 146 1 325 minecraft:dark_prismarine
fill 146 1 361 146 4 361 minecraft:blue_terracotta
setblock 147 1 324 minecraft:dark_prismarine
fill 147 1 325 150 1 325 minecraft:blue_terracotta
setblock 148 1 323 minecraft:dark_prismarine
fill 148 1 324 148 4 324 minecraft:blue_terracotta
setblock 148 1 363 minecraft:dark_prismarine
fill 149 1 323 149 4 323 minecraft:blue_terracotta
setblock 149 1 362 minecraft:dark_prismarine
fill 149 1 363 149 4 363 minecraft:blue_terracotta
setblock 150 1 361 minecraft:dark_prismarine
fill 150 1 362 150 4 362 minecraft:blue_terracotta
setblock 151 1 325 minecraft:dark_prismarine
fill 151 1 361 151 4 361 minecraft:blue_terracotta
setblock 152 1 324 minecraft:dark_prismarine
fill 152 1 325 152 2 325 minecraft:blue_terracotta
setblock 153 1 323 minecraft:dark_prismarine
fill 153 1 324 153 4 324 minecraft:blue_terracotta
setblock 153 1 363 minecraft:dark_prismarine
fill 154 1 323 154 4 323 minecraft:blue_terracotta
setblock 154 1 362 minecraft:dark_prismarine
fill 154 1 363 154 4 363 minecraft:blue_terracotta
fill 155 1 362 155 3 362 minecraft:blue_terracotta
setblock 158 1 323 minecraft:dark_prismarine
setblock 158 1 363 minecraft:dark_prismarine
fill 159 1 323 159 2 323 minecraft:blue_terracotta
fill 159 1 363 162 1 363 minecraft:blue_terracotta
setblock 162 1 323 minecraft:blue_terracotta
setblock 163 1 323 minecraft:dark_prismarine
setblock 163 1 363 minecraft:dark_prismarine
fill 164 1 323 164 4 323 minecraft:blue_terracotta
fill 164 1 363 164 4 363 minecraft:blue_terracotta
fill 165 1 324 166 1 324 minecraft:blue_terracotta
fill 166 1 356 166 33 356 minecraft:magenta_terracotta
setblock 167 1 324 minecraft:dark_prismarine
fill 167 1 362 167 2 362 minecraft:blue_terracotta
setblock 168 1 323 minecraft:dark_prismarine
fill 168 1 324 170 1 325 minecraft:blue_terracotta
setblock 168 1 363 minecraft:dark_prismarine
fill 169 1 323 169 4 323 minecraft:blue_terracotta
setblock 169 1 362 minecraft:dark_prismarine
fill 169 1 363 169 4 363 minecraft:blue_terracotta
schedule function dropper:buildpart/75_2 1t
