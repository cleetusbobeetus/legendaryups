fill 289 163 646 289 175 646 minecraft:purple_concrete
fill 302 163 636 302 167 638 minecraft:black_concrete
fill 303 163 635 303 167 635 minecraft:black_concrete
fill 304 163 639 304 167 639 minecraft:black_concrete
fill 305 163 635 305 167 635 minecraft:black_concrete
fill 306 163 636 306 167 638 minecraft:black_concrete
fill 315 163 604 315 172 604 minecraft:purple_concrete
setblock 324 163 612 minecraft:pearlescent_froglight
fill 282 164 611 282 167 611 minecraft:purple_concrete
fill 282 164 630 282 169 630 minecraft:purple_concrete
fill 285 164 604 285 175 604 minecraft:purple_concrete
setblock 292 164 646 minecraft:white_concrete
fill 302 164 635 302 167 635 minecraft:black_concrete
fill 303 164 639 303 167 639 minecraft:black_concrete
fill 304 164 634 304 167 634 minecraft:black_concrete
fill 305 164 639 305 167 639 minecraft:black_concrete
fill 306 164 635 306 167 635 minecraft:black_concrete
fill 324 164 612 324 171 612 minecraft:purple_concrete
fill 282 165 612 282 170 612 minecraft:purple_concrete
fill 282 165 628 282 170 628 minecraft:purple_concrete
fill 282 165 644 282 170 644 minecraft:purple_concrete
fill 286 165 604 286 170 604 minecraft:purple_concrete
fill 292 165 646 292 172 646 minecraft:purple_concrete
fill 296 165 646 296 170 646 minecraft:purple_concrete
fill 300 165 604 300 175 604 minecraft:purple_concrete
setblock 301 165 604 minecraft:white_concrete
fill 301 165 636 301 167 638 minecraft:black_concrete
fill 302 165 604 302 170 604 minecraft:purple_concrete
fill 302 165 639 302 167 639 minecraft:black_concrete
fill 303 165 634 303 167 634 minecraft:black_concrete
fill 304 165 640 304 167 640 minecraft:black_concrete
fill 305 165 634 305 167 634 minecraft:black_concrete
fill 306 165 639 306 167 639 minecraft:black_concrete
fill 307 165 636 307 167 638 minecraft:black_concrete
fill 312 165 646 312 170 646 minecraft:purple_concrete
fill 318 165 604 318 170 604 minecraft:purple_concrete
setblock 324 165 605 minecraft:amethyst_block
fill 324 165 614 324 170 614 minecraft:purple_concrete
setblock 324 165 620 minecraft:pearlescent_froglight
fill 324 165 621 324 175 621 minecraft:purple_concrete
setblock 324 165 628 minecraft:white_concrete
fill 324 165 630 324 170 630 minecraft:purple_concrete
fill 301 166 604 301 175 604 minecraft:purple_concrete
fill 301 166 635 301 167 635 minecraft:black_concrete
fill 301 166 639 301 167 639 minecraft:black_concrete
fill 302 166 634 302 167 634 minecraft:black_concrete
fill 302 166 640 303 167 640 minecraft:black_concrete
fill 304 166 633 304 167 633 minecraft:black_concrete
fill 305 166 640 305 167 640 minecraft:black_concrete
fill 306 166 634 306 167 634 minecraft:black_concrete
fill 307 166 635 307 167 635 minecraft:black_concrete
fill 307 166 639 307 167 639 minecraft:black_concrete
setblock 319 166 646 minecraft:amethyst_block
fill 324 166 605 324 171 605 minecraft:purple_concrete
setblock 324 166 617 minecraft:pearlescent_froglight
fill 324 166 618 324 171 618 minecraft:purple_concrete
fill 324 166 620 324 175 620 minecraft:purple_concrete
fill 324 166 628 324 172 628 minecraft:purple_concrete
fill 300 167 636 300 167 638 minecraft:black_concrete
setblock 301 167 634 minecraft:black_concrete
fill 302 167 633 303 167 633 minecraft:black_concrete
setblock 304 167 641 minecraft:black_concrete
fill 305 167 633 306 167 633 minecraft:black_concrete
setblock 306 167 640 minecraft:black_concrete
setblock 307 167 634 minecraft:black_concrete
fill 308 167 636 308 167 638 minecraft:black_concrete
fill 319 167 646 319 172 646 minecraft:purple_concrete
fill 324 167 617 324 175 617 minecraft:purple_concrete
setblock 282 168 611 minecraft:pearlescent_froglight
fill 290 168 620 291 169 621 minecraft:end_stone
fill 303 168 636 305 168 637 minecraft:amethyst_block
setblock 304 168 638 minecraft:amethyst_block
setblock 306 168 646 minecraft:pearlescent_froglight
setblock 309 168 604 minecraft:amethyst_block
setblock 320 168 604 minecraft:pearlescent_froglight
fill 282 169 611 282 171 611 minecraft:purple_concrete
fill 296 169 617 297 170 618 minecraft:white_concrete
fill 303 169 637 305 169 637 minecraft:amethyst_block
fill 304 169 636 304 170 636 minecraft:amethyst_block
fill 306 169 646 306 175 646 minecraft:purple_concrete
fill 309 169 604 309 172 604 minecraft:purple_concrete
fill 320 169 604 320 175 604 minecraft:purple_concrete
setblock 324 169 622 minecraft:amethyst_block
setblock 282 170 630 minecraft:pearlescent_froglight
setblock 285 170 607 minecraft:light[level=13]
setblock 285 170 615 minecraft:light[level=13]
setblock 285 170 623 minecraft:light[level=13]
setblock 285 170 631 minecraft:light[level=13]
setblock 285 170 639 minecraft:light[level=13]
setblock 293 170 607 minecraft:light[level=13]
setblock 293 170 615 minecraft:light[level=13]
setblock 293 170 623 minecraft:light[level=13]
setblock 293 170 631 minecraft:light[level=13]
setblock 293 170 639 minecraft:light[level=13]
setblock 301 170 607 minecraft:light[level=13]
setblock 301 170 615 minecraft:light[level=13]
setblock 301 170 623 minecraft:light[level=13]
setblock 301 170 631 minecraft:light[level=13]
setblock 301 170 639 minecraft:light[level=13]
fill 304 170 637 304 172 637 minecraft:amethyst_block
setblock 309 170 607 minecraft:light[level=13]
setblock 309 170 615 minecraft:light[level=13]
setblock 309 170 623 minecraft:light[level=13]
setblock 309 170 631 minecraft:light[level=13]
setblock 309 170 639 minecraft:light[level=13]
setblock 317 170 607 minecraft:light[level=13]
setblock 317 170 615 minecraft:light[level=13]
setblock 317 170 623 minecraft:light[level=13]
setblock 317 170 631 minecraft:light[level=13]
setblock 317 170 639 minecraft:light[level=13]
setblock 324 170 622 minecraft:white_concrete
setblock 324 170 629 minecraft:pearlescent_froglight
setblock 324 170 644 minecraft:amethyst_block
fill 282 171 612 282 173 612 minecraft:gold_block
fill 282 171 628 282 173 628 minecraft:gold_block
fill 282 171 630 282 175 630 minecraft:purple_concrete
fill 282 171 644 282 173 644 minecraft:gold_block
fill 286 171 604 286 173 604 minecraft:gold_block
fill 296 171 646 296 173 646 minecraft:gold_block
fill 302 171 604 302 173 604 minecraft:gold_block
fill 312 171 646 312 173 646 minecraft:gold_block
fill 318 171 604 318 173 604 minecraft:gold_block
fill 324 171 614 324 173 614 minecraft:gold_block
fill 324 171 622 324 172 622 minecraft:purple_concrete
fill 324 171 629 324 175 629 minecraft:purple_concrete
fill 324 171 630 324 173 630 minecraft:gold_block
setblock 324 171 637 minecraft:amethyst_block
fill 324 171 644 324 175 644 minecraft:purple_concrete
setblock 282 172 608 minecraft:amethyst_block
setblock 282 172 611 minecraft:light_blue_concrete
fill 282 172 638 282 175 638 minecraft:purple_concrete
setblock 282 172 639 minecraft:white_concrete
fill 282 172 640 282 175 640 minecraft:purple_concrete
setblock 293 172 646 minecraft:white_concrete
setblock 294 172 646 minecraft:light_blue_concrete
setblock 305 172 604 minecraft:light_blue_concrete
fill 306 172 611 306 173 611 minecraft:obsidian
fill 307 172 646 307 175 646 minecraft:purple_concrete
setblock 308 172 646 minecraft:light_blue_concrete
setblock 323 172 604 minecraft:light_blue_concrete
setblock 324 172 605 minecraft:light_blue_concrete
fill 324 172 607 324 173 610 minecraft:purple_concrete
fill 324 172 611 324 172 612 minecraft:light_blue_concrete
setblock 324 172 618 minecraft:light_blue_concrete
setblock 324 172 624 minecraft:white_concrete
setblock 324 172 632 minecraft:light_blue_concrete
fill 324 172 637 324 173 637 minecraft:light_blue_concrete
fill 282 173 604 282 174 604 minecraft:light_blue_concrete
fill 282 173 608 282 175 608 minecraft:purple_concrete
fill 282 173 611 282 175 611 minecraft:purple_concrete
setblock 282 173 618 minecraft:light_blue_concrete
setblock 282 173 631 minecraft:light_blue_concrete
fill 282 173 639 282 175 639 minecraft:purple_concrete
setblock 292 173 646 minecraft:light_blue_concrete
fill 293 173 646 294 175 646 minecraft:purple_concrete
setblock 295 173 604 minecraft:amethyst_block
setblock 295 173 646 minecraft:amethyst_block
setblock 297 173 604 minecraft:light_blue_concrete
setblock 305 173 604 minecraft:pearlescent_froglight
fill 308 173 646 308 175 646 minecraft:purple_concrete
setblock 309 173 604 minecraft:pearlescent_froglight
fill 309 173 629 311 174 629 minecraft:white_concrete
fill 310 173 628 311 174 628 minecraft:white_concrete
fill 310 173 630 310 174 630 minecraft:white_concrete
setblock 310 173 646 minecraft:light_blue_concrete
setblock 311 173 604 minecraft:light_blue_concrete
fill 312 173 604 312 176 604 minecraft:purple_concrete
fill 315 173 604 315 174 604 minecraft:light_blue_concrete
fill 315 173 631 315 174 631 minecraft:white_concrete
fill 318 173 646 319 173 646 minecraft:light_blue_concrete
fill 323 173 604 323 175 604 minecraft:purple_concrete
fill 324 173 605 324 175 605 minecraft:purple_concrete
fill 324 173 611 324 175 612 minecraft:purple_concrete
fill 324 173 618 324 175 618 minecraft:purple_concrete
fill 324 173 622 324 174 622 minecraft:light_blue_concrete
fill 324 173 624 324 175 624 minecraft:purple_concrete
setblock 324 173 627 minecraft:white_concrete
setblock 324 173 628 minecraft:amethyst_block
setblock 324 173 632 minecraft:purple_concrete
setblock 324 173 645 minecraft:light_blue_concrete
fill 282 174 612 282 175 612 minecraft:purple_concrete
fill 282 174 618 282 175 618 minecraft:purple_concrete
fill 282 174 628 282 175 628 minecraft:purple_concrete
fill 282 174 631 282 175 631 minecraft:purple_concrete
setblock 282 174 633 minecraft:light_blue_concrete
setblock 282 174 644 minecraft:pearlescent_froglight
setblock 283 174 604 minecraft:light_blue_concrete
fill 286 174 604 286 175 604 minecraft:purple_concrete
fill 287 174 604 288 174 604 minecraft:light_blue_concrete
fill 292 174 646 292 175 646 minecraft:purple_concrete
fill 295 174 604 295 175 604 minecraft:purple_concrete
fill 295 174 646 296 175 646 minecraft:purple_concrete
fill 297 174 604 297 175 604 minecraft:purple_concrete
setblock 298 174 604 minecraft:light_blue_concrete
setblock 302 174 604 minecraft:light_blue_concrete
fill 305 174 604 305 176 604 minecraft:purple_concrete
fill 309 174 604 309 175 604 minecraft:purple_concrete
fill 310 174 646 310 175 646 minecraft:purple_concrete
fill 311 174 604 311 175 604 minecraft:purple_concrete
fill 312 174 646 312 175 646 minecraft:purple_concrete
setblock 314 174 604 minecraft:white_concrete
setblock 315 174 646 minecraft:light_blue_concrete
fill 316 174 618 316 175 618 minecraft:amethyst_block
setblock 317 174 646 minecraft:light_blue_concrete
fill 318 174 604 318 175 604 minecraft:purple_concrete
fill 318 174 646 319 175 646 minecraft:purple_concrete
setblock 321 174 646 minecraft:light_blue_concrete
fill 324 174 607 324 175 608 minecraft:purple_concrete
setblock 324 174 609 minecraft:light_blue_concrete
fill 324 174 610 324 175 610 minecraft:purple_concrete
fill 324 174 614 324 175 614 minecraft:purple_concrete
setblock 324 174 619 minecraft:light_blue_concrete
fill 324 174 627 324 175 628 minecraft:purple_concrete
fill 324 174 630 324 175 630 minecraft:purple_concrete
setblock 324 174 632 minecraft:light_blue_concrete
setblock 324 174 636 minecraft:light_blue_concrete
fill 324 174 637 324 175 637 minecraft:purple_concrete
fill 324 174 645 324 175 645 minecraft:purple_concrete
fill 282 175 604 283 175 604 minecraft:purple_concrete
setblock 282 175 613 minecraft:pearlescent_froglight
setblock 282 175 626 minecraft:white_concrete
setblock 282 175 627 minecraft:purple_concrete
setblock 282 175 633 minecraft:purple_concrete
setblock 282 175 636 minecraft:white_concrete
setblock 282 175 644 minecraft:purple_concrete
setblock 284 175 604 minecraft:pearlescent_froglight
fill 287 175 604 288 175 604 minecraft:purple_concrete
fill 298 175 604 298 177 604 minecraft:purple_concrete
fill 302 175 604 302 176 604 minecraft:purple_concrete
setblock 303 175 604 minecraft:pearlescent_froglight
fill 307 175 641 307 176 641 minecraft:white_concrete
fill 314 175 604 315 175 604 minecraft:purple_concrete
setblock 315 175 646 minecraft:purple_concrete
setblock 317 175 646 minecraft:purple_concrete
fill 320 175 620 321 176 621 minecraft:obsidian
setblock 321 175 646 minecraft:purple_concrete
setblock 324 175 609 minecraft:purple_concrete
setblock 324 175 619 minecraft:purple_concrete
setblock 324 175 622 minecraft:purple_concrete
setblock 324 175 632 minecraft:purple_concrete
setblock 324 175 636 minecraft:purple_concrete
fill 282 176 604 292 177 604 minecraft:light_blue_concrete
fill 282 176 606 282 176 624 minecraft:light_blue_concrete
fill 282 176 626 282 176 632 minecraft:light_blue_concrete
setblock 282 176 633 minecraft:amethyst_block
fill 282 176 634 282 176 637 minecraft:light_blue_concrete
setblock 282 176 638 minecraft:white_concrete
fill 282 176 639 282 177 646 minecraft:light_blue_concrete
fill 284 176 646 306 176 646 minecraft:light_blue_concrete
fill 294 176 604 297 177 604 minecraft:light_blue_concrete
fill 299 176 604 301 241 604 minecraft:light_blue_concrete
fill 303 176 604 304 177 604 minecraft:light_blue_concrete
fill 306 176 604 311 176 604 minecraft:light_blue_concrete
setblock 307 176 646 minecraft:white_concrete
fill 308 176 646 318 176 646 minecraft:light_blue_concrete
fill 313 176 604 315 186 604 minecraft:light_blue_concrete
fill 317 176 604 324 176 604 minecraft:light_blue_concrete
setblock 319 176 646 minecraft:purple_concrete
fill 320 176 646 322 176 646 minecraft:light_blue_concrete
fill 324 176 605 324 176 610 minecraft:light_blue_concrete
setblock 324 176 611 minecraft:purple_concrete
fill 324 176 612 324 176 632 minecraft:light_blue_concrete
fill 324 176 635 324 176 642 minecraft:light_blue_concrete
fill 324 176 644 324 177 646 minecraft:light_blue_concrete
fill 282 177 605 282 177 606 minecraft:light_blue_concrete
fill 282 177 607 282 177 608 minecraft:purple_concrete
fill 282 177 609 282 177 627 minecraft:light_blue_concrete
setblock 282 177 628 minecraft:purple_concrete
fill 282 177 629 282 177 630 minecraft:light_blue_concrete
setblock 282 177 631 minecraft:purple_concrete
fill 282 177 632 282 177 634 minecraft:light_blue_concrete
setblock 282 177 635 minecraft:pearlescent_froglight
fill 282 177 636 282 239 636 minecraft:light_blue_concrete
setblock 282 177 637 minecraft:white_concrete
setblock 282 177 638 minecraft:light_blue_concrete
fill 283 177 646 286 177 646 minecraft:light_blue_concrete
setblock 287 177 646 minecraft:amethyst_block
fill 288 177 646 295 179 646 minecraft:light_blue_concrete
fill 293 177 604 293 225 604 minecraft:light_blue_concrete
setblock 296 177 646 minecraft:purple_concrete
fill 297 177 646 300 204 646 minecraft:light_blue_concrete
setblock 301 177 646 minecraft:white_concrete
fill 302 177 604 302 197 604 minecraft:light_blue_concrete
fill 302 177 646 305 177 646 minecraft:light_blue_concrete
fill 305 177 604 308 215 604 minecraft:light_blue_concrete
fill 306 177 646 307 177 646 minecraft:purple_concrete
fill 308 177 646 309 193 646 minecraft:light_blue_concrete
fill 309 177 604 310 177 604 minecraft:purple_concrete
setblock 310 177 646 minecraft:purple_concrete
fill 311 177 604 312 177 604 minecraft:light_blue_concrete
fill 311 177 646 320 177 646 minecraft:light_blue_concrete
fill 316 177 628 317 178 628 minecraft:obsidian
fill 317 177 604 318 197 604 minecraft:light_blue_concrete
setblock 319 177 604 minecraft:pearlescent_froglight
fill 320 177 604 321 189 604 minecraft:light_blue_concrete
fill 321 177 646 322 177 646 minecraft:purple_concrete
setblock 322 177 604 minecraft:purple_concrete
fill 323 177 604 324 185 604 minecraft:light_blue_concrete
fill 324 177 605 324 241 605 minecraft:light_blue_concrete
setblock 324 177 606 minecraft:pearlescent_froglight
fill 324 177 607 324 177 621 minecraft:light_blue_concrete
setblock 324 177 622 minecraft:purple_concrete
fill 324 177 623 324 184 631 minecraft:light_blue_concrete
setblock 324 177 632 minecraft:purple_concrete
fill 324 177 633 324 177 637 minecraft:light_blue_concrete
setblock 324 177 638 minecraft:purple_concrete
fill 324 177 639 324 177 643 minecraft:light_blue_concrete
fill 282 178 604 285 203 604 minecraft:light_blue_concrete
fill 282 178 605 282 178 606 minecraft:purple_concrete
fill 282 178 607 282 178 608 minecraft:light_blue_concrete
setblock 282 178 609 minecraft:purple_concrete
fill 282 178 610 282 195 614 minecraft:light_blue_concrete
setblock 282 178 615 minecraft:purple_concrete
fill 282 178 616 282 222 617 minecraft:light_blue_concrete
fill 282 178 618 282 178 620 minecraft:purple_concrete
fill 282 178 621 282 190 628 minecraft:light_blue_concrete
setblock 282 178 629 minecraft:purple_concrete
fill 282 178 630 282 241 631 minecraft:light_blue_concrete
fill 282 178 632 282 178 633 minecraft:purple_concrete
fill 282 178 634 282 218 635 minecraft:light_blue_concrete
fill 282 178 637 282 241 637 minecraft:light_blue_concrete
setblock 282 178 638 minecraft:purple_concrete
fill 282 178 639 282 181 643 minecraft:light_blue_concrete
setblock 282 178 644 minecraft:purple_concrete
fill 282 178 645 282 235 646 minecraft:light_blue_concrete
setblock 283 178 646 minecraft:purple_concrete
fill 284 178 646 287 179 646 minecraft:light_blue_concrete
setblock 285 178 607 minecraft:light[level=13]
setblock 285 178 615 minecraft:light[level=13]
setblock 285 178 623 minecraft:light[level=13]
setblock 285 178 631 minecraft:light[level=13]
setblock 285 178 639 minecraft:light[level=13]
setblock 286 178 604 minecraft:purple_concrete
fill 287 178 604 292 181 604 minecraft:light_blue_concrete
setblock 293 178 607 minecraft:light[level=13]
setblock 293 178 615 minecraft:light[level=13]
setblock 293 178 623 minecraft:light[level=13]
setblock 293 178 631 minecraft:light[level=13]
setblock 293 178 639 minecraft:light[level=13]
setblock 294 178 604 minecraft:purple_concrete
fill 295 178 604 298 205 604 minecraft:light_blue_concrete
setblock 296 178 646 minecraft:light_blue_concrete
setblock 301 178 607 minecraft:light[level=13]
setblock 301 178 615 minecraft:light[level=13]
setblock 301 178 623 minecraft:light[level=13]
setblock 301 178 631 minecraft:light[level=13]
setblock 301 178 639 minecraft:light[level=13]
fill 301 178 646 302 188 646 minecraft:light_blue_concrete
fill 303 178 604 303 237 604 minecraft:light_blue_concrete
setblock 303 178 646 minecraft:purple_concrete
setblock 304 178 604 minecraft:purple_concrete
fill 304 178 646 307 195 646 minecraft:light_blue_concrete
fill 309 178 604 310 199 604 minecraft:light_blue_concrete
setblock 309 178 607 minecraft:light[level=13]
setblock 309 178 615 minecraft:light[level=13]
setblock 309 178 623 minecraft:light[level=13]
setblock 309 178 631 minecraft:light[level=13]
setblock 309 178 639 minecraft:light[level=13]
fill 310 178 646 314 180 646 minecraft:light_blue_concrete
setblock 311 178 604 minecraft:purple_concrete
fill 312 178 604 312 241 604 minecraft:light_blue_concrete
setblock 315 178 646 minecraft:purple_concrete
fill 316 178 604 316 238 604 minecraft:light_blue_concrete
fill 316 178 646 319 184 646 minecraft:light_blue_concrete
setblock 317 178 607 minecraft:light[level=13]
setblock 317 178 615 minecraft:light[level=13]
setblock 317 178 623 minecraft:light[level=13]
setblock 317 178 631 minecraft:light[level=13]
setblock 317 178 639 minecraft:light[level=13]
fill 319 178 604 319 186 604 minecraft:light_blue_concrete
fill 320 178 646 321 178 646 minecraft:purple_concrete
fill 322 178 604 322 213 604 minecraft:light_blue_concrete
fill 322 178 646 324 179 646 minecraft:light_blue_concrete
fill 324 178 606 324 180 610 minecraft:light_blue_concrete
setblock 324 178 611 minecraft:purple_concrete
fill 324 178 612 324 237 613 minecraft:light_blue_concrete
setblock 324 178 614 minecraft:purple_concrete
fill 324 178 615 324 184 618 minecraft:light_blue_concrete
setblock 324 178 619 minecraft:purple_concrete
fill 324 178 620 324 209 622 minecraft:light_blue_concrete
fill 324 178 632 324 187 634 minecraft:light_blue_concrete
setblock 324 178 635 minecraft:purple_concrete
fill 324 178 636 324 182 641 minecraft:light_blue_concrete
setblock 324 178 642 minecraft:purple_concrete
fill 324 178 643 324 184 643 minecraft:light_blue_concrete
setblock 324 178 644 minecraft:purple_concrete
fill 324 178 645 324 238 645 minecraft:light_blue_concrete
fill 282 179 605 282 194 607 minecraft:light_blue_concrete
setblock 282 179 608 minecraft:amethyst_block
fill 282 179 609 282 212 609 minecraft:light_blue_concrete
fill 282 179 615 282 188 615 minecraft:light_blue_concrete
fill 282 179 618 282 188 620 minecraft:light_blue_concrete
fill 282 179 629 282 192 629 minecraft:light_blue_concrete
fill 282 179 632 282 221 633 minecraft:light_blue_concrete
fill 282 179 638 282 241 638 minecraft:light_blue_concrete
fill 282 179 644 282 197 644 minecraft:light_blue_concrete
fill 283 179 646 283 206 646 minecraft:light_blue_concrete
fill 286 179 604 286 182 604 minecraft:light_blue_concrete
fill 294 179 604 294 188 604 minecraft:light_blue_concrete
setblock 296 179 646 minecraft:amethyst_block
fill 303 179 646 303 216 646 minecraft:light_blue_concrete
fill 304 179 604 304 200 604 minecraft:light_blue_concrete
fill 311 179 604 311 235 604 minecraft:light_blue_concrete
fill 315 179 646 315 241 646 minecraft:light_blue_concrete
fill 320 179 646 321 202 646 minecraft:light_blue_concrete
fill 324 179 611 324 220 611 minecraft:light_blue_concrete
fill 324 179 614 324 192 614 minecraft:light_blue_concrete
fill 324 179 619 324 232 619 minecraft:light_blue_concrete
fill 324 179 635 324 206 635 minecraft:light_blue_concrete
fill 324 179 642 324 180 642 minecraft:light_blue_concrete
fill 324 179 644 324 241 644 minecraft:light_blue_concrete
fill 282 180 608 282 241 608 minecraft:light_blue_concrete
fill 284 180 646 284 237 646 minecraft:light_blue_concrete
setblock 285 180 646 minecraft:white_concrete
fill 286 180 646 289 197 646 minecraft:light_blue_concrete
setblock 290 180 646 minecraft:white_concrete
fill 291 180 646 296 186 646 minecraft:light_blue_concrete
setblock 322 180 646 minecraft:amethyst_block
fill 323 180 646 324 238 646 minecraft:light_blue_concrete
fill 285 181 646 285 241 646 minecraft:light_blue_concrete
fill 290 181 646 290 238 646 minecraft:light_blue_concrete
fill 310 181 646 312 183 646 minecraft:light_blue_concrete
setblock 313 181 646 minecraft:pearlescent_froglight
fill 314 181 646 314 187 646 minecraft:light_blue_concrete
fill 322 181 646 322 215 646 minecraft:light_blue_concrete
fill 324 181 606 324 228 606 minecraft:light_blue_concrete
setblock 324 181 607 minecraft:white_concrete
fill 324 181 608 324 191 610 minecraft:light_blue_concrete
setblock 324 181 642 minecraft:amethyst_block
fill 282 182 639 282 241 639 minecraft:light_blue_concrete
setblock 282 182 640 minecraft:white_concrete
fill 282 182 641 282 183 643 minecraft:light_blue_concrete
setblock 287 182 604 minecraft:white_concrete
fill 288 182 604 292 225 604 minecraft:light_blue_concrete
fill 313 182 646 313 241 646 minecraft:light_blue_concrete
fill 324 182 607 324 188 607 minecraft:light_blue_concrete
fill 324 182 642 324 188 642 minecraft:light_blue_concrete
fill 282 183 640 282 241 640 minecraft:light_blue_concrete
setblock 286 183 604 minecraft:white_concrete
fill 287 183 604 287 192 604 minecraft:light_blue_concrete
fill 301 183 626 302 183 626 minecraft:shroomlight
fill 302 183 624 305 183 625 minecraft:shroomlight
fill 302 183 627 302 183 628 minecraft:shroomlight
fill 303 183 628 305 183 628 minecraft:shroomlight
fill 305 183 626 305 183 627 minecraft:shroomlight
setblock 306 183 626 minecraft:shroomlight
fill 324 183 636 324 200 640 minecraft:light_blue_concrete
setblock 324 183 641 minecraft:amethyst_block
fill 282 184 641 282 238 642 minecraft:light_blue_concrete
setblock 282 184 643 minecraft:white_concrete
fill 286 184 604 286 197 604 minecraft:light_blue_concrete
fill 300 184 624 300 184 628 minecraft:shroomlight
fill 301 184 623 301 184 625 minecraft:shroomlight
fill 301 184 626 302 193 626 minecraft:gold_block
fill 301 184 627 301 184 629 minecraft:shroomlight
fill 302 184 622 305 184 623 minecraft:shroomlight
fill 302 184 624 305 193 625 minecraft:gold_block
fill 302 184 627 302 193 628 minecraft:gold_block
fill 302 184 629 305 184 630 minecraft:shroomlight
fill 306 184 623 306 184 625 minecraft:shroomlight
fill 306 184 626 306 193 626 minecraft:gold_block
fill 306 184 627 306 184 629 minecraft:shroomlight
fill 307 184 624 307 184 628 minecraft:shroomlight
fill 310 184 646 311 191 646 minecraft:light_blue_concrete
setblock 312 184 646 minecraft:white_concrete
fill 324 184 641 324 237 641 minecraft:light_blue_concrete
fill 282 185 643 282 202 643 minecraft:light_blue_concrete
fill 299 185 624 299 185 628 minecraft:shroomlight
fill 300 185 622 300 185 623 minecraft:shroomlight
fill 300 185 624 300 193 628 minecraft:gold_block
fill 300 185 629 300 185 630 minecraft:shroomlight
setblock 301 185 622 minecraft:shroomlight
fill 301 185 623 301 194 625 minecraft:gold_block
fill 301 185 627 301 191 629 minecraft:gold_block
setblock 301 185 630 minecraft:shroomlight
fill 302 185 621 305 185 621 minecraft:shroomlight
fill 302 185 622 305 191 623 minecraft:gold_block
fill 302 185 629 305 193 630 minecraft:gold_block
fill 302 185 631 305 185 631 minecraft:shroomlight
fill 306 185 622 307 185 622 minecraft:shroomlight
fill 306 185 623 306 191 625 minecraft:gold_block
fill 306 185 627 306 193 629 minecraft:gold_block
fill 306 185 630 307 185 630 minecraft:shroomlight
setblock 307 185 623 minecraft:shroomlight
fill 307 185 624 307 193 628 minecraft:gold_block
setblock 307 185 629 minecraft:shroomlight
fill 308 185 624 308 185 628 minecraft:shroomlight
fill 312 185 646 312 197 646 minecraft:light_blue_concrete
setblock 316 185 646 minecraft:white_concrete
fill 317 185 646 319 231 646 minecraft:light_blue_concrete
fill 324 185 615 324 194 616 minecraft:light_blue_concrete
setblock 324 185 617 minecraft:white_concrete
fill 324 185 618 324 203 618 minecraft:light_blue_concrete
fill 324 185 623 324 191 626 minecraft:light_blue_concrete
setblock 324 185 627 minecraft:white_concrete
fill 324 185 628 324 197 631 minecraft:light_blue_concrete
setblock 324 185 643 minecraft:amethyst_block
setblock 285 186 607 minecraft:light[level=13]
setblock 285 186 615 minecraft:light[level=13]
setblock 285 186 623 minecraft:light[level=13]
setblock 285 186 631 minecraft:light[level=13]
setblock 285 186 639 minecraft:light[level=13]
setblock 293 186 607 minecraft:light[level=13]
setblock 293 186 615 minecraft:light[level=13]
setblock 293 186 623 minecraft:light[level=13]
setblock 293 186 631 minecraft:light[level=13]
setblock 293 186 639 minecraft:light[level=13]
fill 298 186 624 298 186 628 minecraft:shroomlight
fill 299 186 622 299 186 623 minecraft:shroomlight
fill 299 186 624 299 193 628 minecraft:gold_block
fill 299 186 629 299 186 630 minecraft:shroomlight
setblock 300 186 622 minecraft:shroomlight
fill 300 186 623 300 193 623 minecraft:gold_block
fill 300 186 629 300 191 629 minecraft:gold_block
setblock 300 186 630 minecraft:shroomlight
setblock 301 186 607 minecraft:light[level=13]
setblock 301 186 615 minecraft:light[level=13]
fill 301 186 621 302 186 621 minecraft:shroomlight
fill 301 186 622 301 193 622 minecraft:gold_block
fill 301 186 630 301 191 630 minecraft:gold_block
fill 301 186 631 302 186 631 minecraft:shroomlight
setblock 301 186 639 minecraft:light[level=13]
fill 303 186 620 304 193 620 minecraft:shroomlight
fill 303 186 621 304 191 621 minecraft:gold_block
fill 303 186 631 304 193 631 minecraft:gold_block
fill 303 186 632 304 193 632 minecraft:shroomlight
fill 305 186 621 306 186 621 minecraft:shroomlight
fill 305 186 631 306 186 631 minecraft:shroomlight
fill 306 186 622 306 191 622 minecraft:gold_block
fill 306 186 630 306 191 630 minecraft:gold_block
fill 307 186 622 308 186 622 minecraft:shroomlight
fill 307 186 623 307 193 623 minecraft:gold_block
fill 307 186 629 307 193 629 minecraft:gold_block
fill 307 186 630 308 186 630 minecraft:shroomlight
setblock 308 186 623 minecraft:shroomlight
fill 308 186 624 308 193 628 minecraft:gold_block
setblock 308 186 629 minecraft:shroomlight
setblock 309 186 607 minecraft:light[level=13]
setblock 309 186 615 minecraft:light[level=13]
setblock 309 186 623 minecraft:light[level=13]
fill 309 186 624 309 186 628 minecraft:shroomlight
setblock 309 186 631 minecraft:light[level=13]
setblock 309 186 639 minecraft:light[level=13]
fill 316 186 646 316 187 646 minecraft:light_blue_concrete
setblock 317 186 607 minecraft:light[level=13]
setblock 317 186 615 minecraft:light[level=13]
setblock 317 186 623 minecraft:light[level=13]
setblock 317 186 631 minecraft:light[level=13]
setblock 317 186 639 minecraft:light[level=13]
setblock 323 186 604 minecraft:pearlescent_froglight
fill 324 186 604 324 238 604 minecraft:light_blue_concrete
fill 324 186 617 324 191 617 minecraft:light_blue_concrete
fill 324 186 627 324 241 627 minecraft:light_blue_concrete
fill 324 186 643 324 209 643 minecraft:light_blue_concrete
setblock 291 187 646 minecraft:white_concrete
fill 292 187 646 296 197 646 minecraft:light_blue_concrete
fill 297 187 626 297 192 626 minecraft:shroomlight
fill 298 187 623 298 187 625 minecraft:shroomlight
fill 298 187 626 298 192 626 minecraft:gold_block
fill 298 187 627 298 187 629 minecraft:shroomlight
setblock 299 187 622 minecraft:shroomlight
fill 299 187 623 299 192 623 minecraft:gold_block
fill 299 187 629 299 191 629 minecraft:gold_block
setblock 299 187 630 minecraft:shroomlight
fill 300 187 621 300 188 621 minecraft:shroomlight
fill 300 187 622 300 192 622 minecraft:gold_block
fill 300 187 630 300 191 630 minecraft:gold_block
fill 300 187 631 300 188 631 minecraft:shroomlight
fill 301 187 620 302 192 620 minecraft:shroomlight
fill 301 187 621 302 192 621 minecraft:gold_block
fill 301 187 631 302 191 631 minecraft:gold_block
fill 301 187 632 302 192 632 minecraft:shroomlight
fill 305 187 620 306 192 620 minecraft:shroomlight
fill 305 187 621 306 191 621 minecraft:gold_block
fill 305 187 631 306 191 631 minecraft:gold_block
fill 305 187 632 306 191 632 minecraft:shroomlight
fill 307 187 621 307 188 621 minecraft:shroomlight
fill 307 187 622 307 192 622 minecraft:gold_block
fill 307 187 630 307 191 630 minecraft:gold_block
fill 307 187 631 307 188 631 minecraft:shroomlight
setblock 308 187 622 minecraft:shroomlight
fill 308 187 623 308 192 623 minecraft:gold_block
fill 308 187 629 308 192 629 minecraft:gold_block
setblock 308 187 630 minecraft:shroomlight
fill 309 187 623 309 187 625 minecraft:shroomlight
fill 309 187 626 309 192 626 minecraft:gold_block
fill 309 187 627 309 187 629 minecraft:shroomlight
fill 310 187 626 310 192 626 minecraft:shroomlight
fill 313 187 604 313 222 604 minecraft:light_blue_concrete
setblock 314 187 604 minecraft:amethyst_block
fill 315 187 604 315 237 604 minecraft:light_blue_concrete
setblock 319 187 604 minecraft:amethyst_block
fill 323 187 604 323 189 604 minecraft:light_blue_concrete
fill 291 188 646 291 228 646 minecraft:light_blue_concrete
fill 297 188 624 297 191 625 minecraft:shroomlight
fill 297 188 627 297 191 628 minecraft:shroomlight
fill 298 188 622 298 191 623 minecraft:shroomlight
fill 298 188 624 298 191 625 minecraft:gold_block
fill 298 188 627 298 191 628 minecraft:gold_block
fill 298 188 629 298 191 630 minecraft:shroomlight
fill 299 188 621 299 191 621 minecraft:shroomlight
fill 299 188 622 299 191 622 minecraft:gold_block
fill 299 188 630 299 191 630 minecraft:gold_block
fill 299 188 631 299 191 631 minecraft:shroomlight
fill 308 188 621 308 191 621 minecraft:shroomlight
fill 308 188 622 308 191 622 minecraft:gold_block
fill 308 188 630 308 191 630 minecraft:gold_block
fill 308 188 631 308 191 631 minecraft:shroomlight
fill 309 188 622 309 191 623 minecraft:shroomlight
fill 309 188 624 309 191 625 minecraft:gold_block
fill 309 188 627 309 191 628 minecraft:gold_block
fill 309 188 629 309 191 630 minecraft:shroomlight
fill 310 188 624 310 191 625 minecraft:shroomlight
fill 310 188 627 310 191 628 minecraft:shroomlight
fill 314 188 604 314 216 604 minecraft:light_blue_concrete
setblock 314 188 646 minecraft:amethyst_block
setblock 316 188 646 minecraft:white_concrete
fill 319 188 604 319 241 604 minecraft:light_blue_concrete
fill 324 188 632 324 213 632 minecraft:light_blue_concrete
setblock 324 188 633 minecraft:amethyst_block
fill 324 188 634 324 194 634 minecraft:light_blue_concrete
setblock 282 189 615 minecraft:amethyst_block
fill 282 189 618 282 211 619 minecraft:light_blue_concrete
setblock 282 189 620 minecraft:amethyst_block
setblock 294 189 604 minecraft:white_concrete
fill 300 189 620 300 190 620 minecraft:shroomlight
fill 300 189 621 300 190 621 minecraft:gold_block
fill 300 189 631 300 190 631 minecraft:gold_block
fill 300 189 632 300 190 632 minecraft:shroomlight
setblock 301 189 646 minecraft:pearlescent_froglight
fill 302 189 646 302 230 646 minecraft:light_blue_concrete
fill 307 189 620 307 190 620 minecraft:shroomlight
fill 307 189 621 307 190 621 minecraft:gold_block
fill 307 189 631 307 190 631 minecraft:gold_block
fill 307 189 632 307 190 632 minecraft:shroomlight
fill 314 189 646 314 190 646 minecraft:light_blue_concrete
fill 316 189 646 316 225 646 minecraft:light_blue_concrete
setblock 324 189 607 minecraft:amethyst_block
fill 324 189 633 324 230 633 minecraft:light_blue_concrete
setblock 324 189 642 minecraft:white_concrete
fill 282 190 615 282 228 615 minecraft:light_blue_concrete
fill 282 190 620 282 210 620 minecraft:light_blue_concrete
fill 294 190 604 294 235 604 minecraft:light_blue_concrete
fill 301 190 646 301 241 646 minecraft:light_blue_concrete
fill 320 190 604 320 237 604 minecraft:light_blue_concrete
setblock 321 190 604 minecraft:amethyst_block
setblock 323 190 604 minecraft:white_concrete
fill 324 190 607 324 241 607 minecraft:light_blue_concrete
fill 324 190 642 324 240 642 minecraft:light_blue_concrete
fill 282 191 621 282 192 627 minecraft:light_blue_concrete
setblock 282 191 628 minecraft:amethyst_block
fill 300 191 621 300 192 621 minecraft:shroomlight
setblock 300 191 631 minecraft:shroomlight
fill 307 191 621 307 192 621 minecraft:shroomlight
setblock 307 191 631 minecraft:shroomlight
setblock 314 191 646 minecraft:amethyst_block
fill 321 191 604 321 194 604 minecraft:light_blue_concrete
fill 323 191 604 323 206 604 minecraft:light_blue_concrete
fill 282 192 628 282 197 628 minecraft:light_blue_concrete
fill 298 192 623 298 192 625 minecraft:shroomlight
fill 298 192 627 298 192 629 minecraft:shroomlight
fill 299 192 622 299 193 622 minecraft:shroomlight
fill 299 192 629 301 192 631 minecraft:redstone_block
fill 301 192 627 301 193 628 minecraft:gold_block
fill 302 192 622 303 193 623 minecraft:gold_block
setblock 302 192 631 minecraft:gold_block
fill 303 192 621 303 193 621 minecraft:gold_block
fill 304 192 621 306 192 623 minecraft:redstone_block
setblock 305 192 631 minecraft:gold_block
setblock 305 192 632 minecraft:shroomlight
fill 306 192 624 306 193 625 minecraft:gold_block
fill 306 192 630 308 192 632 minecraft:redstone_block
fill 308 192 622 308 193 622 minecraft:shroomlight
fill 309 192 623 309 192 625 minecraft:shroomlight
fill 309 192 627 309 192 629 minecraft:shroomlight
setblock 310 192 646 minecraft:white_concrete
fill 311 192 646 311 210 646 minecraft:light_blue_concrete
fill 314 192 646 314 204 646 minecraft:light_blue_concrete
fill 324 192 608 324 225 608 minecraft:light_blue_concrete
setblock 324 192 609 minecraft:pearlescent_froglight
fill 324 192 610 324 205 610 minecraft:light_blue_concrete
setblock 324 192 617 minecraft:white_concrete
fill 324 192 623 324 205 623 minecraft:light_blue_concrete
setblock 324 192 624 minecraft:white_concrete
fill 324 192 625 324 238 626 minecraft:light_blue_concrete
fill 282 193 621 282 241 621 minecraft:light_blue_concrete
setblock 282 193 622 minecraft:pearlescent_froglight
fill 282 193 623 282 221 627 minecraft:light_blue_concrete
setblock 282 193 629 minecraft:amethyst_block
setblock 287 193 604 minecraft:pearlescent_froglight
fill 298 193 624 298 193 628 minecraft:shroomlight
setblock 299 193 623 minecraft:shroomlight
fill 300 193 622 300 194 622 minecraft:shroomlight
fill 301 193 621 302 193 621 minecraft:shroomlight
setblock 302 193 631 minecraft:shroomlight
setblock 305 193 631 minecraft:shroomlight
setblock 307 193 622 minecraft:shroomlight
setblock 308 193 623 minecraft:shroomlight
setblock 308 193 629 minecraft:shroomlight
fill 309 193 624 309 193 628 minecraft:shroomlight
fill 310 193 646 310 230 646 minecraft:light_blue_concrete
fill 324 193 609 324 194 609 minecraft:light_blue_concrete
setblock 324 193 614 minecraft:pearlescent_froglight
fill 324 193 617 324 241 617 minecraft:light_blue_concrete
fill 324 193 624 324 217 624 minecraft:light_blue_concrete
fill 282 194 622 282 203 622 minecraft:light_blue_concrete
fill 282 194 629 282 200 629 minecraft:light_blue_concrete
fill 283 194 605 297 194 645 minecraft:obsidian
fill 287 194 604 287 200 604 minecraft:light_blue_concrete
fill 298 194 605 298 194 627 minecraft:obsidian
fill 298 194 628 298 194 632 minecraft:pearlescent_froglight
fill 298 194 633 304 194 645 minecraft:obsidian
fill 299 194 605 299 194 623 minecraft:obsidian
fill 299 194 624 299 194 627 minecraft:shroomlight
fill 299 194 628 302 194 628 minecraft:pearlescent_froglight
fill 299 194 629 301 194 631 minecraft:obsidian
fill 299 194 632 302 194 632 minecraft:pearlescent_froglight
fill 300 194 605 301 194 621 minecraft:obsidian
setblock 300 194 623 minecraft:shroomlight
fill 300 194 624 300 194 627 minecraft:gold_block
setblock 301 194 622 minecraft:shroomlight
fill 301 194 626 301 194 627 minecraft:gold_block
fill 302 194 605 302 194 620 minecraft:obsidian
setblock 302 194 621 minecraft:shroomlight
fill 302 194 622 302 194 624 minecraft:gold_block
fill 302 194 625 302 194 627 minecraft:pearlescent_froglight
fill 302 194 629 302 194 631 minecraft:pearlescent_froglight
fill 303 194 605 323 194 619 minecraft:obsidian
fill 303 194 620 303 194 625 minecraft:pearlescent_froglight
fill 303 194 629 309 194 629 minecraft:pearlescent_froglight
fill 303 194 630 304 194 630 minecraft:gold_block
fill 303 194 631 304 194 631 minecraft:shroomlight
fill 303 194 632 304 194 632 minecraft:obsidian
fill 304 194 620 307 194 620 minecraft:pearlescent_froglight
fill 304 194 621 306 194 623 minecraft:obsidian
fill 304 194 624 306 194 625 minecraft:pearlescent_froglight
fill 305 194 630 305 194 633 minecraft:pearlescent_froglight
fill 305 194 634 323 194 645 minecraft:obsidian
fill 306 194 626 306 194 628 minecraft:pearlescent_froglight
fill 306 194 630 308 194 632 minecraft:obsidian
fill 306 194 633 309 194 633 minecraft:pearlescent_froglight
fill 307 194 621 307 194 624 minecraft:pearlescent_froglight
fill 307 194 625 307 194 628 minecraft:gold_block
fill 308 194 620 323 194 623 minecraft:obsidian
fill 308 194 624 308 194 628 minecraft:shroomlight
fill 308 194 646 308 227 646 minecraft:light_blue_concrete
fill 309 194 624 323 194 628 minecraft:obsidian
fill 309 194 630 309 194 632 minecraft:pearlescent_froglight
setblock 309 194 646 minecraft:white_concrete
fill 310 194 629 323 194 633 minecraft:obsidian
fill 324 194 614 324 197 614 minecraft:light_blue_concrete
fill 282 195 605 282 195 606 minecraft:pearlescent_froglight
fill 282 195 607 282 208 607 minecraft:light_blue_concrete
fill 300 195 624 300 195 628 minecraft:shroomlight
fill 301 195 623 301 195 625 minecraft:shroomlight
fill 301 195 626 302 195 626 minecraft:gold_block
fill 301 195 627 301 195 629 minecraft:shroomlight
fill 302 195 622 305 195 623 minecraft:shroomlight
fill 302 195 624 303 195 625 minecraft:gold_block
fill 302 195 627 302 195 628 minecraft:gold_block
fill 302 195 629 305 195 630 minecraft:shroomlight
fill 304 195 624 305 195 624 minecraft:gold_block
setblock 305 195 625 minecraft:gold_block
fill 306 195 623 306 195 625 minecraft:shroomlight
setblock 306 195 626 minecraft:gold_block
fill 306 195 627 306 195 629 minecraft:shroomlight
fill 307 195 624 307 195 628 minecraft:shroomlight
fill 309 195 646 309 236 646 minecraft:light_blue_concrete
setblock 321 195 604 minecraft:white_concrete
setblock 324 195 609 minecraft:pearlescent_froglight
setblock 324 195 615 minecraft:white_concrete
fill 324 195 616 324 241 616 minecraft:light_blue_concrete
setblock 324 195 634 minecraft:white_concrete
fill 282 196 605 282 213 606 minecraft:light_blue_concrete
fill 282 196 610 282 199 611 minecraft:light_blue_concrete
setblock 282 196 612 minecraft:amethyst_block
fill 282 196 613 282 241 614 minecraft:light_blue_concrete
fill 301 196 626 302 196 626 minecraft:shroomlight
fill 302 196 624 303 196 625 minecraft:shroomlight
fill 302 196 627 302 196 628 minecraft:shroomlight
fill 304 196 624 305 196 624 minecraft:shroomlight
fill 304 196 646 305 225 646 minecraft:light_blue_concrete
setblock 305 196 625 minecraft:shroomlight
setblock 306 196 626 minecraft:shroomlight
setblock 306 196 646 minecraft:amethyst_block
fill 307 196 646 307 241 646 minecraft:light_blue_concrete
fill 321 196 604 321 241 604 minecraft:light_blue_concrete
fill 324 196 609 324 241 609 minecraft:light_blue_concrete
fill 324 196 615 324 206 615 minecraft:light_blue_concrete
fill 324 196 634 324 237 634 minecraft:light_blue_concrete
setblock 282 197 612 minecraft:light_blue_concrete
fill 306 197 646 306 237 646 minecraft:light_blue_concrete
fill 282 198 612 282 200 612 minecraft:gold_block
fill 282 198 628 282 200 628 minecraft:gold_block
fill 282 198 644 282 200 644 minecraft:gold_block
fill 286 198 604 286 200 604 minecraft:gold_block
fill 286 198 646 287 205 646 minecraft:light_blue_concrete
fill 288 198 626 290 198 626 minecraft:gold_block
setblock 288 198 646 minecraft:white_concrete
setblock 289 198 625 minecraft:gold_block
setblock 289 198 627 minecraft:gold_block
fill 289 198 646 289 216 646 minecraft:light_blue_concrete
setblock 292 198 646 minecraft:white_concrete
fill 293 198 646 295 206 646 minecraft:light_blue_concrete
fill 296 198 646 296 200 646 minecraft:gold_block
fill 302 198 604 302 200 604 minecraft:gold_block
fill 312 198 646 312 200 646 minecraft:gold_block
setblock 317 198 604 minecraft:pearlescent_froglight
fill 318 198 604 318 200 604 minecraft:gold_block
fill 324 198 614 324 200 614 minecraft:gold_block
fill 324 198 628 324 228 629 minecraft:light_blue_concrete
fill 324 198 630 324 200 630 minecraft:gold_block
fill 324 198 631 324 203 631 minecraft:light_blue_concrete
fill 288 199 646 288 208 646 minecraft:light_blue_concrete
fill 292 199 646 292 224 646 minecraft:light_blue_concrete
fill 317 199 604 317 219 604 minecraft:light_blue_concrete
fill 282 200 610 282 241 610 minecraft:light_blue_concrete
setblock 282 200 611 minecraft:white_concrete
fill 309 200 604 309 202 604 minecraft:light_blue_concrete
setblock 310 200 604 minecraft:pearlescent_froglight
fill 282 201 611 282 206 612 minecraft:light_blue_concrete
setblock 282 201 628 minecraft:light_blue_concrete
setblock 282 201 629 minecraft:white_concrete
fill 282 201 644 282 206 644 minecraft:light_blue_concrete
fill 286 201 604 286 206 604 minecraft:light_blue_concrete
fill 286 201 623 289 208 624 minecraft:orange_concrete
setblock 287 201 604 minecraft:white_concrete
fill 287 201 622 289 208 622 minecraft:orange_concrete
fill 287 201 625 289 208 625 minecraft:orange_concrete
fill 296 201 646 296 206 646 minecraft:light_blue_concrete
fill 302 201 604 302 206 604 minecraft:light_blue_concrete
setblock 304 201 604 minecraft:pearlescent_froglight
fill 310 201 604 310 228 604 minecraft:light_blue_concrete
fill 312 201 646 312 206 646 minecraft:light_blue_concrete
fill 318 201 604 318 206 604 minecraft:light_blue_concrete
fill 324 201 614 324 206 614 minecraft:light_blue_concrete
fill 324 201 630 324 206 630 minecraft:light_blue_concrete
fill 324 201 636 324 203 636 minecraft:light_blue_concrete
setblock 324 201 637 minecraft:pearlescent_froglight
fill 324 201 638 324 204 640 minecraft:light_blue_concrete
setblock 282 202 628 minecraft:white_concrete
fill 282 202 629 282 229 629 minecraft:light_blue_concrete
setblock 285 202 607 minecraft:light[level=13]
setblock 285 202 615 minecraft:light[level=13]
fill 285 202 623 285 207 625 minecraft:orange_concrete
setblock 285 202 631 minecraft:light[level=13]
setblock 285 202 639 minecraft:light[level=13]
fill 286 202 622 286 207 622 minecraft:orange_concrete
fill 286 202 625 286 207 626 minecraft:orange_concrete
fill 287 202 604 287 204 604 minecraft:light_blue_concrete
fill 287 202 621 289 207 621 minecraft:orange_concrete
fill 287 202 626 290 207 626 minecraft:orange_concrete
fill 290 202 622 290 207 625 minecraft:orange_concrete
fill 291 202 623 291 207 624 minecraft:orange_concrete
setblock 293 202 607 minecraft:light[level=13]
setblock 293 202 615 minecraft:light[level=13]
setblock 293 202 623 minecraft:light[level=13]
setblock 293 202 631 minecraft:light[level=13]
setblock 293 202 639 minecraft:light[level=13]
setblock 301 202 607 minecraft:light[level=13]
setblock 301 202 615 minecraft:light[level=13]
setblock 301 202 623 minecraft:light[level=13]
setblock 301 202 631 minecraft:light[level=13]
setblock 301 202 639 minecraft:light[level=13]
fill 304 202 604 304 241 604 minecraft:light_blue_concrete
setblock 309 202 607 minecraft:light[level=13]
setblock 309 202 615 minecraft:light[level=13]
setblock 309 202 623 minecraft:light[level=13]
setblock 309 202 631 minecraft:light[level=13]
setblock 309 202 639 minecraft:light[level=13]
setblock 317 202 607 minecraft:light[level=13]
setblock 317 202 615 minecraft:light[level=13]
setblock 317 202 623 minecraft:light[level=13]
setblock 317 202 631 minecraft:light[level=13]
setblock 317 202 639 minecraft:light[level=13]
fill 324 202 637 324 222 637 minecraft:light_blue_concrete
setblock 282 203 628 minecraft:pearlescent_froglight
setblock 282 203 643 minecraft:white_concrete
fill 285 203 622 285 206 622 minecraft:orange_concrete
fill 285 203 626 285 206 626 minecraft:orange_concrete
fill 286 203 621 286 206 621 minecraft:orange_concrete
fill 287 203 627 289 206 627 minecraft:orange_concrete
fill 288 203 620 288 206 620 minecraft:orange_concrete
fill 290 203 621 290 206 621 minecraft:orange_concrete
fill 291 203 622 291 206 622 minecraft:orange_concrete
fill 291 203 625 291 206 625 minecraft:orange_concrete
setblock 309 203 604 minecraft:amethyst_block
fill 314 203 644 314 208 644 minecraft:amethyst_block
setblock 320 203 646 minecraft:white_concrete
fill 321 203 646 321 241 646 minecraft:light_blue_concrete
fill 282 204 604 282 238 604 minecraft:light_blue_concrete
setblock 282 204 622 minecraft:amethyst_block
fill 282 204 628 282 206 628 minecraft:light_blue_concrete
fill 282 204 643 282 238 643 minecraft:light_blue_concrete
setblock 283 204 604 minecraft:pearlescent_froglight
fill 284 204 604 285 237 604 minecraft:light_blue_concrete
fill 284 204 623 284 205 624 minecraft:orange_concrete
fill 285 204 621 285 205 621 minecraft:orange_concrete
fill 286 204 627 286 205 627 minecraft:orange_concrete
fill 287 204 620 287 205 620 minecraft:orange_concrete
fill 289 204 620 289 205 620 minecraft:orange_concrete
fill 290 204 627 290 205 627 minecraft:orange_concrete
fill 291 204 626 291 205 626 minecraft:orange_concrete
fill 309 204 604 309 241 604 minecraft:light_blue_concrete
fill 312 204 644 313 207 644 minecraft:amethyst_block
fill 313 204 642 315 207 643 minecraft:amethyst_block
fill 313 204 645 315 207 645 minecraft:amethyst_block
fill 314 204 641 314 207 641 minecraft:amethyst_block
fill 315 204 644 316 207 644 minecraft:amethyst_block
fill 320 204 646 320 242 646 minecraft:light_blue_concrete
setblock 324 204 618 minecraft:amethyst_block
setblock 324 204 631 minecraft:white_concrete
setblock 324 204 636 minecraft:pearlescent_froglight
fill 282 205 622 282 237 622 minecraft:light_blue_concrete
fill 283 205 604 283 241 604 minecraft:light_blue_concrete
setblock 287 205 604 minecraft:pearlescent_froglight
fill 292 205 629 294 206 629 minecraft:obsidian
fill 293 205 628 294 206 628 minecraft:obsidian
fill 297 205 646 298 238 646 minecraft:light_blue_concrete
setblock 299 205 646 minecraft:amethyst_block
fill 300 205 646 300 218 646 minecraft:light_blue_concrete
fill 312 205 642 312 206 643 minecraft:amethyst_block
fill 312 205 645 312 206 645 minecraft:amethyst_block
fill 313 205 640 313 206 641 minecraft:amethyst_block
fill 314 205 637 314 206 640 minecraft:amethyst_block
setblock 314 205 646 minecraft:white_concrete
fill 315 205 640 315 206 641 minecraft:amethyst_block
fill 316 205 642 316 206 643 minecraft:amethyst_block
fill 316 205 645 316 206 645 minecraft:amethyst_block
fill 321 205 638 323 208 640 minecraft:amethyst_block
fill 324 205 618 324 234 618 minecraft:light_blue_concrete
fill 324 205 631 324 239 631 minecraft:light_blue_concrete
fill 324 205 636 324 242 636 minecraft:light_blue_concrete
setblock 324 205 638 minecraft:amethyst_block
fill 324 205 639 324 214 640 minecraft:light_blue_concrete
setblock 286 206 646 minecraft:pearlescent_froglight
fill 287 206 604 287 241 604 minecraft:light_blue_concrete
fill 287 206 646 287 238 646 minecraft:light_blue_concrete
setblock 295 206 604 minecraft:pearlescent_froglight
fill 296 206 604 298 237 604 minecraft:light_blue_concrete
fill 299 206 616 300 207 616 minecraft:white_concrete
fill 299 206 646 299 224 646 minecraft:light_blue_concrete
fill 314 206 646 314 226 646 minecraft:light_blue_concrete
fill 318 206 639 320 208 639 minecraft:amethyst_block
fill 319 206 638 320 208 638 minecraft:amethyst_block
fill 319 206 640 320 208 640 minecraft:amethyst_block
fill 322 206 637 322 207 637 minecraft:amethyst_block
fill 322 206 641 322 207 641 minecraft:amethyst_block
setblock 324 206 610 minecraft:white_concrete
setblock 324 206 623 minecraft:white_concrete
fill 324 206 638 324 239 638 minecraft:light_blue_concrete
fill 282 207 611 282 215 611 minecraft:light_blue_concrete
fill 282 207 612 282 209 612 minecraft:gold_block
fill 282 207 628 282 209 628 minecraft:gold_block
fill 282 207 644 282 209 644 minecraft:gold_block
setblock 283 207 646 minecraft:amethyst_block
fill 286 207 604 286 209 604 minecraft:gold_block
fill 286 207 646 286 210 646 minecraft:light_blue_concrete
fill 293 207 646 293 230 646 minecraft:light_blue_concrete
setblock 294 207 646 minecraft:amethyst_block
fill 295 207 604 295 230 604 minecraft:light_blue_concrete
fill 295 207 646 295 242 646 minecraft:light_blue_concrete
fill 296 207 646 296 209 646 minecraft:gold_block
fill 302 207 604 302 209 604 minecraft:gold_block
fill 312 207 646 312 209 646 minecraft:gold_block
setblock 313 207 641 minecraft:amethyst_block
setblock 314 207 640 minecraft:amethyst_block
fill 315 207 639 317 208 639 minecraft:amethyst_block
setblock 315 207 641 minecraft:amethyst_block
fill 318 207 604 318 209 604 minecraft:gold_block
setblock 318 207 638 minecraft:amethyst_block
setblock 318 207 640 minecraft:amethyst_block
setblock 323 207 604 minecraft:pearlescent_froglight
fill 324 207 610 324 215 610 minecraft:light_blue_concrete
fill 324 207 614 324 209 614 minecraft:gold_block
setblock 324 207 615 minecraft:white_concrete
fill 324 207 623 324 239 623 minecraft:light_blue_concrete
fill 324 207 630 324 209 630 minecraft:gold_block
setblock 324 207 635 minecraft:white_concrete
fill 283 208 646 283 239 646 minecraft:light_blue_concrete
fill 294 208 646 294 239 646 minecraft:light_blue_concrete
fill 312 208 612 313 209 613 minecraft:white_concrete
fill 314 208 613 314 209 613 minecraft:white_concrete
fill 323 208 604 323 237 604 minecraft:light_blue_concrete
fill 324 208 615 324 221 615 minecraft:light_blue_concrete
fill 324 208 635 324 236 635 minecraft:light_blue_concrete
setblock 282 209 607 minecraft:white_concrete
setblock 288 209 646 minecraft:amethyst_block
fill 282 210 607 282 238 607 minecraft:light_blue_concrete
fill 282 210 612 282 215 612 minecraft:light_blue_concrete
fill 282 210 628 282 211 628 minecraft:light_blue_concrete
fill 282 210 644 282 215 644 minecraft:light_blue_concrete
setblock 285 210 607 minecraft:light[level=13]
setblock 285 210 615 minecraft:light[level=13]
setblock 285 210 623 minecraft:light[level=13]
setblock 285 210 631 minecraft:light[level=13]
setblock 285 210 639 minecraft:light[level=13]
fill 286 210 604 286 215 604 minecraft:light_blue_concrete
fill 288 210 646 288 241 646 minecraft:light_blue_concrete
setblock 293 210 607 minecraft:light[level=13]
setblock 293 210 615 minecraft:light[level=13]
setblock 293 210 623 minecraft:light[level=13]
setblock 293 210 631 minecraft:light[level=13]
setblock 293 210 639 minecraft:light[level=13]
fill 296 210 646 296 215 646 minecraft:light_blue_concrete
setblock 301 210 607 minecraft:light[level=13]
setblock 301 210 615 minecraft:light[level=13]
setblock 301 210 623 minecraft:light[level=13]
setblock 301 210 631 minecraft:light[level=13]
setblock 301 210 639 minecraft:light[level=13]
fill 302 210 604 302 215 604 minecraft:light_blue_concrete
fill 308 210 634 314 212 640 minecraft:stone
setblock 309 210 607 minecraft:light[level=13]
setblock 309 210 615 minecraft:light[level=13]
setblock 309 210 623 minecraft:light[level=13]
setblock 309 210 631 minecraft:light[level=13]
fill 312 210 646 312 215 646 minecraft:light_blue_concrete
setblock 317 210 607 minecraft:light[level=13]
setblock 317 210 615 minecraft:light[level=13]
setblock 317 210 623 minecraft:light[level=13]
setblock 317 210 631 minecraft:light[level=13]
setblock 317 210 639 minecraft:light[level=13]
fill 318 210 604 318 215 604 minecraft:light_blue_concrete
fill 324 210 614 324 215 614 minecraft:light_blue_concrete
fill 324 210 620 324 241 620 minecraft:light_blue_concrete
setblock 324 210 621 minecraft:amethyst_block
fill 324 210 622 324 241 622 minecraft:light_blue_concrete
fill 324 210 630 324 212 630 minecraft:light_blue_concrete
setblock 324 210 643 minecraft:white_concrete
setblock 282 211 620 minecraft:white_concrete
setblock 286 211 646 minecraft:pearlescent_froglight
setblock 311 211 646 minecraft:amethyst_block
fill 324 211 621 324 223 621 minecraft:light_blue_concrete
fill 324 211 643 324 241 643 minecraft:light_blue_concrete
fill 282 212 618 282 241 618 minecraft:light_blue_concrete
setblock 282 212 619 minecraft:pearlescent_froglight
fill 282 212 620 282 242 620 minecraft:light_blue_concrete
setblock 282 212 628 minecraft:white_concrete
fill 286 212 646 286 241 646 minecraft:light_blue_concrete
fill 311 212 646 311 241 646 minecraft:light_blue_concrete
setblock 282 213 609 minecraft:pearlescent_froglight
fill 282 213 619 282 223 619 minecraft:light_blue_concrete
fill 282 213 628 282 215 628 minecraft:light_blue_concrete
fill 308 213 634 314 215 640 minecraft:dirt
setblock 324 213 630 minecraft:white_concrete
setblock 282 214 605 minecraft:pearlescent_froglight
fill 282 214 606 282 237 606 minecraft:light_blue_concrete
fill 282 214 609 282 242 609 minecraft:light_blue_concrete
fill 312 214 628 313 215 629 minecraft:white_concrete
setblock 322 214 604 minecraft:pearlescent_froglight
fill 324 214 630 324 215 630 minecraft:light_blue_concrete
setblock 324 214 632 minecraft:white_concrete
fill 282 215 605 282 241 605 minecraft:light_blue_concrete
fill 322 215 604 322 241 604 minecraft:light_blue_concrete
fill 324 215 632 324 241 632 minecraft:light_blue_concrete
setblock 324 215 639 minecraft:amethyst_block
fill 324 215 640 324 241 640 minecraft:light_blue_concrete
setblock 282 216 611 minecraft:pearlescent_froglight
fill 282 216 612 282 218 612 minecraft:gold_block
fill 282 216 628 282 218 628 minecraft:gold_block
fill 282 216 644 282 218 644 minecraft:gold_block
fill 286 216 604 286 218 604 minecraft:gold_block
fill 286 216 625 292 218 631 minecraft:stone
fill 296 216 646 296 218 646 minecraft:gold_block
fill 302 216 604 302 218 604 minecraft:gold_block
fill 305 216 604 306 228 604 minecraft:light_blue_concrete
fill 305 216 641 305 218 641 minecraft:amethyst_block
setblock 307 216 604 minecraft:white_concrete
fill 308 216 604 308 241 604 minecraft:light_blue_concrete
fill 308 216 634 314 216 640 minecraft:moss_block
fill 312 216 646 312 218 646 minecraft:gold_block
fill 318 216 604 318 218 604 minecraft:gold_block
setblock 322 216 646 minecraft:pearlescent_froglight
setblock 324 216 610 minecraft:amethyst_block
fill 324 216 614 324 218 614 minecraft:gold_block
fill 324 216 630 324 218 630 minecraft:gold_block
fill 324 216 639 324 238 639 minecraft:light_blue_concrete
fill 282 217 611 282 242 611 minecraft:light_blue_concrete
setblock 289 217 646 minecraft:white_concrete
setblock 303 217 646 minecraft:white_concrete
fill 307 217 604 307 218 604 minecraft:light_blue_concrete
fill 311 217 637 311 221 637 minecraft:oak_log
setblock 314 217 604 minecraft:white_concrete
fill 317 217 630 317 218 631 minecraft:white_concrete
fill 322 217 646 322 241 646 minecraft:light_blue_concrete
fill 324 217 610 324 241 610 minecraft:light_blue_concrete
setblock 285 218 607 minecraft:light[level=13]
setblock 285 218 615 minecraft:light[level=13]
setblock 285 218 623 minecraft:light[level=13]
setblock 285 218 631 minecraft:light[level=13]
setblock 285 218 639 minecraft:light[level=13]
fill 289 218 646 289 241 646 minecraft:light_blue_concrete
fill 292 218 619 292 219 619 minecraft:gold_block
setblock 293 218 607 minecraft:light[level=13]
setblock 293 218 615 minecraft:light[level=13]
setblock 293 218 623 minecraft:light[level=13]
setblock 293 218 631 minecraft:light[level=13]
setblock 293 218 639 minecraft:light[level=13]
fill 295 218 643 297 221 645 minecraft:amethyst_block
setblock 301 218 607 minecraft:light[level=13]
setblock 301 218 615 minecraft:light[level=13]
setblock 301 218 623 minecraft:light[level=13]
setblock 301 218 631 minecraft:light[level=13]
setblock 301 218 639 minecraft:light[level=13]
fill 303 218 646 303 238 646 minecraft:light_blue_concrete
setblock 309 218 607 minecraft:light[level=13]
setblock 309 218 615 minecraft:light[level=13]
setblock 309 218 623 minecraft:light[level=13]
setblock 309 218 631 minecraft:light[level=13]
setblock 309 218 639 minecraft:light[level=13]
fill 314 218 604 314 241 604 minecraft:light_blue_concrete
setblock 317 218 607 minecraft:light[level=13]
setblock 317 218 615 minecraft:light[level=13]
setblock 317 218 623 minecraft:light[level=13]
setblock 317 218 639 minecraft:light[level=13]
setblock 324 218 624 minecraft:amethyst_block
fill 282 219 612 282 224 612 minecraft:light_blue_concrete
fill 282 219 628 282 224 628 minecraft:light_blue_concrete
fill 282 219 634 282 241 634 minecraft:light_blue_concrete
setblock 282 219 635 minecraft:pearlescent_froglight
fill 282 219 644 282 224 644 minecraft:light_blue_concrete
fill 286 219 604 286 224 604 minecraft:light_blue_concrete
fill 286 219 625 292 221 631 minecraft:dirt
fill 294 219 644 294 220 644 minecraft:amethyst_block
fill 295 219 642 297 221 642 minecraft:amethyst_block
fill 296 219 641 296 221 641 minecraft:amethyst_block
fill 296 219 646 296 224 646 minecraft:light_blue_concrete
fill 298 219 644 298 220 644 minecraft:amethyst_block
setblock 300 219 646 minecraft:pearlescent_froglight
fill 302 219 604 302 222 604 minecraft:light_blue_concrete
fill 304 219 640 305 224 641 minecraft:black_concrete
setblock 307 219 604 minecraft:pearlescent_froglight
fill 312 219 646 312 224 646 minecraft:light_blue_concrete
fill 318 219 604 318 224 604 minecraft:light_blue_concrete
fill 324 219 614 324 224 614 minecraft:light_blue_concrete
fill 324 219 624 324 233 624 minecraft:light_blue_concrete
fill 324 219 630 324 224 630 minecraft:light_blue_concrete
fill 282 220 635 282 222 635 minecraft:light_blue_concrete
fill 295 220 640 295 221 641 minecraft:amethyst_block
fill 296 220 639 296 222 640 minecraft:amethyst_block
fill 297 220 640 297 221 641 minecraft:amethyst_block
fill 300 220 646 300 236 646 minecraft:light_blue_concrete
fill 307 220 604 307 241 604 minecraft:light_blue_concrete
setblock 317 220 604 minecraft:white_concrete
fill 296 221 638 296 222 638 minecraft:amethyst_block
fill 303 221 640 303 224 641 minecraft:black_concrete
fill 304 221 639 305 224 639 minecraft:black_concrete
fill 304 221 642 305 224 642 minecraft:black_concrete
fill 306 221 640 306 224 641 minecraft:black_concrete
fill 311 221 638 311 225 638 minecraft:oak_leaves[persistent=true]
fill 313 221 626 313 222 626 minecraft:obsidian
fill 317 221 604 317 241 604 minecraft:light_blue_concrete
setblock 324 221 611 minecraft:pearlescent_froglight
fill 282 222 623 282 241 624 minecraft:light_blue_concrete
setblock 282 222 625 minecraft:amethyst_block
fill 282 222 626 282 236 627 minecraft:light_blue_concrete
setblock 282 222 632 minecraft:white_concrete
fill 282 222 633 282 241 633 minecraft:light_blue_concrete
fill 286 222 625 292 222 625 minecraft:moss_block
fill 286 222 626 287 227 627 minecraft:orange_concrete
fill 286 222 628 292 222 631 minecraft:moss_block
fill 288 222 626 292 222 627 minecraft:moss_block
fill 303 222 608 309 224 614 minecraft:stone
fill 303 222 639 303 224 639 minecraft:black_concrete
fill 303 222 642 303 224 642 minecraft:black_concrete
fill 306 222 639 306 224 639 minecraft:black_concrete
fill 306 222 642 306 224 642 minecraft:black_concrete
fill 310 222 636 310 224 638 minecraft:oak_leaves[persistent=true]
fill 311 222 636 312 224 637 minecraft:oak_leaves[persistent=true]
fill 311 222 639 311 224 639 minecraft:oak_leaves[persistent=true]
fill 312 222 638 312 224 638 minecraft:oak_leaves[persistent=true]
fill 324 222 611 324 241 611 minecraft:light_blue_concrete
setblock 324 222 615 minecraft:amethyst_block
fill 282 223 616 282 237 616 minecraft:light_blue_concrete
setblock 282 223 617 minecraft:amethyst_block
fill 282 223 625 282 239 625 minecraft:light_blue_concrete
fill 282 223 632 282 241 632 minecraft:light_blue_concrete
setblock 282 223 635 minecraft:pearlescent_froglight
fill 285 223 625 285 226 628 minecraft:orange_concrete
fill 286 223 625 288 226 625 minecraft:orange_concrete
fill 286 223 628 288 226 628 minecraft:orange_concrete
fill 288 223 626 288 226 627 minecraft:orange_concrete
fill 289 223 628 289 227 628 minecraft:oak_log
fill 293 223 622 294 224 623 minecraft:end_stone
setblock 302 223 604 minecraft:white_concrete
fill 302 223 640 302 224 641 minecraft:black_concrete
fill 304 223 638 305 224 638 minecraft:black_concrete
fill 304 223 643 306 224 643 minecraft:black_concrete
fill 307 223 640 307 224 642 minecraft:black_concrete
fill 309 223 637 309 223 638 minecraft:oak_leaves[persistent=true]
setblock 310 223 639 minecraft:oak_leaves[persistent=true]
setblock 311 223 635 minecraft:oak_leaves[persistent=true]
setblock 312 223 639 minecraft:oak_leaves[persistent=true]
setblock 313 223 604 minecraft:amethyst_block
fill 313 223 637 313 223 638 minecraft:oak_leaves[persistent=true]
fill 324 223 615 324 235 615 minecraft:light_blue_concrete
setblock 324 223 637 minecraft:amethyst_block
fill 282 224 617 282 241 617 minecraft:light_blue_concrete
setblock 282 224 619 minecraft:white_concrete
fill 282 224 635 282 233 635 minecraft:light_blue_concrete
fill 284 224 626 284 225 627 minecraft:orange_concrete
fill 286 224 624 287 225 624 minecraft:orange_concrete
fill 286 224 629 287 225 629 minecraft:orange_concrete
fill 289 224 626 289 225 627 minecraft:orange_concrete
setblock 302 224 604 minecraft:light_blue_concrete
setblock 302 224 639 minecraft:black_concrete
setblock 302 224 642 minecraft:black_concrete
setblock 303 224 638 minecraft:black_concrete
setblock 303 224 643 minecraft:black_concrete
setblock 306 224 638 minecraft:black_concrete
setblock 307 224 639 minecraft:black_concrete
fill 313 224 604 313 231 604 minecraft:light_blue_concrete
setblock 324 224 621 minecraft:white_concrete
fill 324 224 637 324 225 637 minecraft:light_blue_concrete
fill 282 225 612 282 227 612 minecraft:gold_block
fill 282 225 619 282 237 619 minecraft:light_blue_concrete
fill 282 225 628 282 227 628 minecraft:gold_block
fill 282 225 644 282 227 644 minecraft:gold_block
fill 286 225 604 286 227 604 minecraft:gold_block
setblock 292 225 646 minecraft:pearlescent_froglight
fill 296 225 646 296 227 646 minecraft:gold_block
setblock 299 225 646 minecraft:amethyst_block
fill 302 225 604 302 227 604 minecraft:gold_block
fill 303 225 608 309 227 614 minecraft:dirt
fill 304 225 640 305 226 641 minecraft:amethyst_block
setblock 311 225 637 minecraft:oak_leaves[persistent=true]
fill 312 225 646 312 227 646 minecraft:gold_block
fill 318 225 604 318 227 604 minecraft:gold_block
fill 324 225 614 324 227 614 minecraft:gold_block
fill 324 225 621 324 241 621 minecraft:light_blue_concrete
fill 324 225 630 324 227 630 minecraft:gold_block
setblock 285 226 607 minecraft:light[level=13]
setblock 285 226 615 minecraft:light[level=13]
setblock 285 226 623 minecraft:light[level=13]
setblock 285 226 631 minecraft:light[level=13]
setblock 285 226 639 minecraft:light[level=13]
fill 288 226 604 288 238 604 minecraft:light_blue_concrete
setblock 289 226 604 minecraft:white_concrete
fill 290 226 604 292 241 604 minecraft:light_blue_concrete
fill 292 226 646 292 238 646 minecraft:light_blue_concrete
setblock 293 226 604 minecraft:pearlescent_froglight
setblock 293 226 607 minecraft:light[level=13]
setblock 293 226 615 minecraft:light[level=13]
setblock 293 226 623 minecraft:light[level=13]
setblock 293 226 631 minecraft:light[level=13]
setblock 293 226 639 minecraft:light[level=13]
fill 299 226 646 299 241 646 minecraft:light_blue_concrete
setblock 301 226 607 minecraft:light[level=13]
setblock 301 226 615 minecraft:light[level=13]
setblock 301 226 623 minecraft:light[level=13]
setblock 301 226 631 minecraft:light[level=13]
setblock 301 226 639 minecraft:light[level=13]
setblock 304 226 646 minecraft:pearlescent_froglight
fill 305 226 646 305 234 646 minecraft:light_blue_concrete
setblock 309 226 607 minecraft:light[level=13]
setblock 309 226 615 minecraft:light[level=13]
setblock 309 226 623 minecraft:light[level=13]
setblock 309 226 631 minecraft:light[level=13]
setblock 309 226 639 minecraft:light[level=13]
setblock 316 226 646 minecraft:white_concrete
setblock 317 226 607 minecraft:light[level=13]
setblock 317 226 615 minecraft:light[level=13]
setblock 317 226 623 minecraft:light[level=13]
setblock 317 226 631 minecraft:light[level=13]
setblock 317 226 639 minecraft:light[level=13]
setblock 324 226 608 minecraft:pearlescent_froglight
setblock 324 226 637 minecraft:amethyst_block
fill 288 227 628 288 231 628 minecraft:oak_leaves[persistent=true]
fill 289 227 604 289 232 604 minecraft:light_blue_concrete
fill 289 227 627 289 231 627 minecraft:oak_leaves[persistent=true]
fill 293 227 604 293 237 604 minecraft:light_blue_concrete
fill 298 227 640 299 228 641 minecraft:white_concrete
fill 304 227 641 305 227 641 minecraft:amethyst_block
fill 304 227 646 304 242 646 minecraft:light_blue_concrete
setblock 305 227 640 minecraft:amethyst_block
setblock 314 227 646 minecraft:white_concrete
fill 316 227 646 316 239 646 minecraft:light_blue_concrete
fill 324 227 608 324 241 608 minecraft:light_blue_concrete
fill 324 227 637 324 241 637 minecraft:light_blue_concrete
fill 282 228 612 282 232 612 minecraft:light_blue_concrete
fill 282 228 628 282 233 628 minecraft:light_blue_concrete
fill 282 228 644 282 231 644 minecraft:light_blue_concrete
fill 286 228 604 286 233 604 minecraft:light_blue_concrete
fill 287 228 627 287 230 628 minecraft:oak_leaves[persistent=true]
fill 288 228 626 288 230 627 minecraft:oak_leaves[persistent=true]
fill 288 228 629 290 230 629 minecraft:oak_leaves[persistent=true]
fill 289 228 626 289 230 626 minecraft:oak_leaves[persistent=true]
fill 289 228 628 290 230 628 minecraft:oak_leaves[persistent=true]
fill 290 228 627 290 230 627 minecraft:oak_leaves[persistent=true]
fill 296 228 646 296 233 646 minecraft:light_blue_concrete
fill 302 228 604 302 233 604 minecraft:light_blue_concrete
fill 303 228 608 309 228 614 minecraft:moss_block
setblock 308 228 646 minecraft:amethyst_block
fill 309 228 633 310 229 634 minecraft:gold_block
fill 312 228 646 312 233 646 minecraft:light_blue_concrete
fill 314 228 646 314 238 646 minecraft:light_blue_concrete
fill 318 228 604 318 233 604 minecraft:light_blue_concrete
fill 324 228 614 324 233 614 minecraft:light_blue_concrete
setblock 324 228 630 minecraft:amethyst_block
setblock 282 229 615 minecraft:white_concrete
setblock 287 229 629 minecraft:oak_leaves[persistent=true]
setblock 290 229 626 minecraft:oak_leaves[persistent=true]
setblock 291 229 646 minecraft:pearlescent_froglight
fill 305 229 604 305 241 604 minecraft:light_blue_concrete
setblock 306 229 604 minecraft:pearlescent_froglight
fill 306 229 611 306 233 611 minecraft:oak_log
fill 308 229 646 308 241 646 minecraft:light_blue_concrete
setblock 310 229 604 minecraft:amethyst_block
setblock 324 229 606 minecraft:white_concrete
fill 324 229 628 324 237 628 minecraft:light_blue_concrete
setblock 324 229 629 minecraft:amethyst_block
fill 324 229 630 324 233 630 minecraft:light_blue_concrete
fill 282 230 615 282 241 615 minecraft:light_blue_concrete
setblock 282 230 629 minecraft:white_concrete
fill 290 230 638 291 231 638 minecraft:gold_block
fill 291 230 646 291 238 646 minecraft:light_blue_concrete
fill 306 230 604 306 240 604 minecraft:light_blue_concrete
fill 310 230 604 310 241 604 minecraft:light_blue_concrete
fill 324 230 606 324 241 606 minecraft:light_blue_concrete
fill 324 230 629 324 241 629 minecraft:light_blue_concrete
fill 282 231 629 282 241 629 minecraft:light_blue_concrete
setblock 289 231 628 minecraft:oak_leaves[persistent=true]
fill 292 231 615 294 232 616 minecraft:amethyst_block
setblock 293 231 646 minecraft:white_concrete
setblock 295 231 604 minecraft:pearlescent_froglight
setblock 302 231 646 minecraft:pearlescent_froglight
setblock 310 231 646 minecraft:white_concrete
setblock 324 231 633 minecraft:white_concrete
setblock 282 232 644 minecraft:white_concrete
fill 293 232 646 293 241 646 minecraft:light_blue_concrete
fill 295 232 604 295 242 604 minecraft:light_blue_concrete
fill 302 232 646 302 238 646 minecraft:light_blue_concrete
fill 310 232 646 310 241 646 minecraft:light_blue_concrete
setblock 313 232 604 minecraft:pearlescent_froglight
fill 317 232 646 318 237 646 minecraft:light_blue_concrete
setblock 319 232 646 minecraft:amethyst_block
fill 324 232 633 324 237 633 minecraft:light_blue_concrete
setblock 282 233 612 minecraft:amethyst_block
setblock 282 233 644 minecraft:light_blue_concrete
setblock 289 233 604 minecraft:white_concrete
fill 306 233 610 306 235 610 minecraft:oak_leaves[persistent=true]
fill 307 233 611 307 235 611 minecraft:oak_leaves[persistent=true]
setblock 313 233 604 minecraft:light_blue_concrete
fill 319 233 646 319 237 646 minecraft:light_blue_concrete
setblock 324 233 619 minecraft:pearlescent_froglight
fill 282 234 612 282 235 612 minecraft:gold_block
fill 282 234 628 282 235 628 minecraft:gold_block
setblock 282 234 635 minecraft:amethyst_block
fill 282 234 644 282 235 644 minecraft:gold_block
setblock 285 234 607 minecraft:light[level=13]
setblock 285 234 615 minecraft:light[level=13]
setblock 285 234 623 minecraft:light[level=13]
setblock 285 234 631 minecraft:light[level=13]
setblock 285 234 639 minecraft:light[level=13]
fill 286 234 604 286 235 604 minecraft:gold_block
fill 289 234 604 289 241 604 minecraft:light_blue_concrete
setblock 293 234 607 minecraft:light[level=13]
setblock 293 234 615 minecraft:light[level=13]
setblock 293 234 623 minecraft:light[level=13]
setblock 293 234 631 minecraft:light[level=13]
setblock 293 234 639 minecraft:light[level=13]
fill 296 234 646 296 235 646 minecraft:gold_block
setblock 301 234 607 minecraft:light[level=13]
setblock 301 234 615 minecraft:light[level=13]
setblock 301 234 623 minecraft:light[level=13]
setblock 301 234 631 minecraft:light[level=13]
setblock 301 234 639 minecraft:light[level=13]
fill 302 234 604 302 235 604 minecraft:gold_block
fill 305 234 610 305 235 612 minecraft:oak_leaves[persistent=true]
fill 306 234 609 306 235 609 minecraft:oak_leaves[persistent=true]
fill 306 234 611 306 235 612 minecraft:oak_leaves[persistent=true]
fill 307 234 610 307 235 610 minecraft:oak_leaves[persistent=true]
fill 307 234 612 307 235 612 minecraft:oak_leaves[persistent=true]
fill 308 234 611 308 235 611 minecraft:oak_leaves[persistent=true]
setblock 309 234 607 minecraft:light[level=13]
setblock 309 234 615 minecraft:light[level=13]
setblock 309 234 623 minecraft:light[level=13]
setblock 309 234 631 minecraft:light[level=13]
setblock 309 234 639 minecraft:light[level=13]
fill 312 234 646 312 235 646 minecraft:gold_block
setblock 313 234 604 minecraft:amethyst_block
setblock 317 234 607 minecraft:light[level=13]
setblock 317 234 615 minecraft:light[level=13]
setblock 317 234 623 minecraft:light[level=13]
setblock 317 234 631 minecraft:light[level=13]
setblock 317 234 639 minecraft:light[level=13]
fill 318 234 604 318 235 604 minecraft:gold_block
fill 324 234 614 324 235 614 minecraft:gold_block
fill 324 234 619 324 241 619 minecraft:light_blue_concrete
setblock 324 234 624 minecraft:amethyst_block
fill 324 234 630 324 235 630 minecraft:gold_block
fill 282 235 635 282 237 635 minecraft:light_blue_concrete
setblock 304 235 611 minecraft:oak_leaves[persistent=true]
setblock 305 235 646 minecraft:amethyst_block
setblock 306 235 613 minecraft:oak_leaves[persistent=true]
setblock 307 235 609 minecraft:oak_leaves[persistent=true]
setblock 308 235 610 minecraft:oak_leaves[persistent=true]
setblock 308 235 612 minecraft:oak_leaves[persistent=true]
fill 313 235 604 313 241 604 minecraft:light_blue_concrete
setblock 324 235 618 minecraft:pearlescent_froglight
fill 324 235 624 324 241 624 minecraft:light_blue_concrete
fill 282 236 612 282 241 612 minecraft:light_blue_concrete
fill 282 236 628 282 238 628 minecraft:light_blue_concrete
fill 282 236 644 282 237 644 minecraft:light_blue_concrete
setblock 282 236 645 minecraft:amethyst_block
fill 282 236 646 282 237 646 minecraft:light_blue_concrete
fill 286 236 604 286 241 604 minecraft:light_blue_concrete
setblock 294 236 604 minecraft:pearlescent_froglight
fill 296 236 646 296 241 646 minecraft:light_blue_concrete
fill 302 236 604 302 241 604 minecraft:light_blue_concrete
fill 305 236 646 305 241 646 minecraft:light_blue_concrete
setblock 311 236 604 minecraft:pearlescent_froglight
fill 312 236 646 312 241 646 minecraft:light_blue_concrete
fill 318 236 604 318 241 604 minecraft:light_blue_concrete
fill 324 236 614 324 241 614 minecraft:light_blue_concrete
setblock 324 236 615 minecraft:pearlescent_froglight
fill 324 236 618 324 239 618 minecraft:light_blue_concrete
fill 324 236 630 324 242 630 minecraft:light_blue_concrete
setblock 282 237 626 minecraft:pearlescent_froglight
fill 282 237 627 282 238 627 minecraft:light_blue_concrete
fill 282 237 645 282 241 645 minecraft:light_blue_concrete
fill 294 237 604 294 241 604 minecraft:light_blue_concrete
setblock 300 237 646 minecraft:white_concrete
setblock 309 237 646 minecraft:white_concrete
fill 311 237 604 311 241 604 minecraft:light_blue_concrete
fill 324 237 615 324 239 615 minecraft:light_blue_concrete
setblock 324 237 635 minecraft:amethyst_block
setblock 282 238 606 minecraft:white_concrete
setblock 282 238 616 minecraft:white_concrete
fill 282 238 619 282 239 619 minecraft:white_concrete
setblock 282 238 622 minecraft:white_concrete
fill 282 238 626 282 239 626 minecraft:white_concrete
setblock 282 238 635 minecraft:white_concrete
setblock 282 238 644 minecraft:white_concrete
setblock 282 238 646 minecraft:white_concrete
setblock 284 238 604 minecraft:amethyst_block
setblock 284 238 646 minecraft:white_concrete
fill 285 238 604 285 241 604 minecraft:light_blue_concrete
setblock 293 238 604 minecraft:white_concrete
fill 296 238 604 296 241 604 minecraft:light_blue_concrete
setblock 297 238 604 minecraft:white_concrete
setblock 298 238 604 minecraft:light_blue_concrete
fill 300 238 646 300 241 646 minecraft:light_blue_concrete
setblock 303 238 604 minecraft:white_concrete
fill 306 238 646 306 239 646 minecraft:white_concrete
fill 309 238 646 309 239 646 minecraft:light_blue_concrete
setblock 315 238 604 minecraft:white_concrete
fill 317 238 646 317 239 646 minecraft:white_concrete
fill 318 238 646 318 241 646 minecraft:light_blue_concrete
setblock 319 238 646 minecraft:white_concrete
setblock 320 238 604 minecraft:pearlescent_froglight
setblock 323 238 604 minecraft:white_concrete
fill 324 238 612 324 241 612 minecraft:light_blue_concrete
setblock 324 238 613 minecraft:white_concrete
setblock 324 238 628 minecraft:white_concrete
fill 324 238 633 324 238 635 minecraft:white_concrete
setblock 324 238 641 minecraft:white_concrete
setblock 282 239 604 minecraft:white_concrete
fill 282 239 606 282 241 606 minecraft:light_blue_concrete
setblock 282 239 607 minecraft:white_concrete
setblock 282 239 616 minecraft:light_blue_concrete
fill 282 239 622 282 241 622 minecraft:light_blue_concrete
setblock 282 239 627 minecraft:white_concrete
setblock 282 239 628 minecraft:amethyst_block
fill 282 239 635 282 241 635 minecraft:light_blue_concrete
setblock 282 239 641 minecraft:white_concrete
fill 282 239 642 282 241 642 minecraft:light_blue_concrete
setblock 282 239 643 minecraft:white_concrete
fill 282 239 644 282 241 644 minecraft:light_blue_concrete
fill 282 239 646 282 243 646 minecraft:light_blue_concrete
fill 284 239 604 284 241 604 minecraft:light_blue_concrete
fill 284 239 646 284 241 646 minecraft:light_blue_concrete
setblock 287 239 646 minecraft:white_concrete
setblock 288 239 604 minecraft:white_concrete
fill 290 239 646 292 239 646 minecraft:white_concrete
fill 293 239 604 293 240 604 minecraft:light_blue_concrete
setblock 297 239 604 minecraft:light_blue_concrete
fill 297 239 646 297 241 646 minecraft:light_blue_concrete
setblock 298 239 604 minecraft:white_concrete
fill 298 239 646 298 240 646 minecraft:white_concrete
fill 302 239 646 303 239 646 minecraft:white_concrete
fill 303 239 604 303 241 604 minecraft:light_blue_concrete
setblock 314 239 646 minecraft:white_concrete
setblock 315 239 604 minecraft:light_blue_concrete
setblock 316 239 604 minecraft:white_concrete
fill 319 239 646 319 241 646 minecraft:light_blue_concrete
fill 320 239 604 320 241 604 minecraft:light_blue_concrete
fill 323 239 604 323 241 604 minecraft:light_blue_concrete
fill 323 239 646 323 241 646 minecraft:light_blue_concrete
setblock 324 239 604 minecraft:white_concrete
fill 324 239 613 324 241 613 minecraft:light_blue_concrete
fill 324 239 625 324 241 625 minecraft:light_blue_concrete
setblock 324 239 626 minecraft:white_concrete
fill 324 239 628 324 241 628 minecraft:light_blue_concrete
fill 324 239 633 324 239 635 minecraft:light_blue_concrete
setblock 324 239 639 minecraft:white_concrete
fill 324 239 641 324 241 641 minecraft:light_blue_concrete
fill 324 239 645 324 239 646 minecraft:white_concrete
fill 282 240 604 282 241 604 minecraft:light_blue_concrete
fill 282 240 607 282 241 607 minecraft:light_blue_concrete
setblock 282 240 616 minecraft:white_concrete
fill 282 240 619 282 241 619 minecraft:light_blue_concrete
setblock 282 240 625 minecraft:white_concrete
fill 282 240 626 282 241 628 minecraft:light_blue_concrete
setblock 282 240 636 minecraft:pearlescent_froglight
fill 282 240 641 282 241 641 minecraft:light_blue_concrete
fill 282 240 643 282 241 643 minecraft:light_blue_concrete
setblock 283 240 646 minecraft:white_concrete
fill 287 240 646 287 241 646 minecraft:light_blue_concrete
fill 288 240 604 288 241 604 minecraft:light_blue_concrete
fill 290 240 646 291 241 646 minecraft:light_blue_concrete
setblock 292 240 646 minecraft:white_concrete
setblock 294 240 646 minecraft:white_concrete
setblock 297 240 604 minecraft:white_concrete
fill 298 240 604 298 241 604 minecraft:light_blue_concrete
fill 302 240 646 302 242 646 minecraft:light_blue_concrete
setblock 303 240 646 minecraft:white_concrete
fill 306 240 646 306 241 646 minecraft:light_blue_concrete
setblock 309 240 646 minecraft:white_concrete
fill 314 240 646 314 241 646 minecraft:light_blue_concrete
setblock 315 240 604 minecraft:white_concrete
fill 316 240 604 316 241 604 minecraft:light_blue_concrete
setblock 316 240 646 minecraft:white_concrete
fill 317 240 646 317 241 646 minecraft:light_blue_concrete
fill 324 240 604 324 241 604 minecraft:light_blue_concrete
setblock 324 240 615 minecraft:white_concrete
setblock 324 240 618 minecraft:white_concrete
setblock 324 240 623 minecraft:white_concrete
fill 324 240 626 324 241 626 minecraft:light_blue_concrete
setblock 324 240 631 minecraft:white_concrete
setblock 324 240 633 minecraft:white_concrete
fill 324 240 634 324 241 635 minecraft:light_blue_concrete
setblock 324 240 638 minecraft:white_concrete
fill 324 240 639 324 241 639 minecraft:light_blue_concrete
fill 324 240 645 324 242 645 minecraft:light_blue_concrete
setblock 324 240 646 minecraft:white_concrete
setblock 282 241 616 minecraft:light_blue_concrete
setblock 282 241 625 minecraft:pearlescent_froglight
setblock 282 241 636 minecraft:light_blue_concrete
fill 283 241 605 283 241 608 minecraft:moss_block
fill 283 241 609 283 241 612 minecraft:stone
fill 283 241 613 283 241 616 minecraft:moss_block
fill 283 241 617 283 241 620 minecraft:stone
fill 283 241 621 283 241 624 minecraft:moss_block
fill 283 241 625 283 241 628 minecraft:stone
fill 283 241 629 283 241 632 minecraft:moss_block
fill 283 241 633 283 241 636 minecraft:stone
fill 283 241 637 283 241 640 minecraft:moss_block
fill 283 241 641 283 241 644 minecraft:stone
setblock 283 241 645 minecraft:moss_block
setblock 283 241 646 minecraft:light_blue_concrete
fill 284 241 605 287 241 608 minecraft:stone
fill 284 241 609 287 241 612 minecraft:moss_block
fill 284 241 613 287 241 616 minecraft:stone
fill 284 241 617 287 241 620 minecraft:moss_block
fill 284 241 621 287 241 624 minecraft:stone
fill 284 241 625 287 241 628 minecraft:moss_block
fill 284 241 629 287 241 632 minecraft:stone
fill 284 241 633 287 241 636 minecraft:moss_block
fill 284 241 637 287 241 640 minecraft:stone
fill 284 241 641 287 241 644 minecraft:moss_block
fill 284 241 645 287 241 645 minecraft:stone
fill 288 241 605 291 241 608 minecraft:moss_block
fill 288 241 609 291 241 612 minecraft:stone
fill 288 241 613 291 241 616 minecraft:moss_block
fill 288 241 617 291 241 620 minecraft:stone
fill 288 241 621 291 241 624 minecraft:moss_block
fill 288 241 625 291 241 628 minecraft:stone
fill 288 241 629 291 241 632 minecraft:moss_block
fill 288 241 633 291 241 636 minecraft:stone
fill 288 241 637 291 241 640 minecraft:moss_block
fill 288 241 641 291 241 644 minecraft:stone
fill 288 241 645 291 241 645 minecraft:moss_block
fill 292 241 605 295 241 608 minecraft:stone
fill 292 241 609 295 241 612 minecraft:moss_block
fill 292 241 613 295 241 616 minecraft:stone
fill 292 241 617 295 241 620 minecraft:moss_block
fill 292 241 621 295 241 624 minecraft:stone
fill 292 241 625 295 241 628 minecraft:moss_block
fill 292 241 629 295 241 632 minecraft:stone
fill 292 241 633 295 241 636 minecraft:moss_block
fill 292 241 637 295 241 640 minecraft:stone
fill 292 241 641 295 241 644 minecraft:moss_block
fill 292 241 645 295 241 645 minecraft:stone
setblock 292 241 646 minecraft:light_blue_concrete
setblock 293 241 604 minecraft:white_concrete
setblock 294 241 646 minecraft:light_blue_concrete
fill 296 241 605 299 241 608 minecraft:moss_block
fill 296 241 609 299 241 612 minecraft:stone
fill 296 241 613 299 241 616 minecraft:moss_block
fill 296 241 617 299 241 620 minecraft:stone
fill 296 241 621 299 241 624 minecraft:moss_block
fill 296 241 625 299 241 628 minecraft:stone
fill 296 241 629 299 241 632 minecraft:moss_block
fill 296 241 633 299 241 636 minecraft:stone
fill 296 241 637 299 241 640 minecraft:moss_block
fill 296 241 641 299 241 644 minecraft:stone
fill 296 241 645 299 241 645 minecraft:moss_block
setblock 297 241 604 minecraft:light_blue_concrete
setblock 298 241 646 minecraft:light_blue_concrete
fill 300 241 605 303 241 608 minecraft:stone
fill 300 241 609 303 241 612 minecraft:moss_block
fill 300 241 613 303 241 616 minecraft:stone
fill 300 241 617 303 241 620 minecraft:moss_block
fill 300 241 621 302 241 624 minecraft:stone
fill 300 241 625 301 241 628 minecraft:moss_block
fill 300 241 629 303 241 632 minecraft:stone
fill 300 241 633 303 241 636 minecraft:moss_block
fill 300 241 637 303 241 640 minecraft:stone
fill 300 241 641 303 241 644 minecraft:moss_block
fill 300 241 645 303 241 645 minecraft:stone
fill 302 241 626 302 241 628 minecraft:moss_block
fill 303 241 621 303 241 623 minecraft:stone
fill 303 241 627 303 241 628 minecraft:moss_block
setblock 303 241 646 minecraft:light_blue_concrete
fill 304 241 605 307 241 608 minecraft:moss_block
fill 304 241 609 307 241 612 minecraft:stone
fill 304 241 613 307 241 616 minecraft:moss_block
fill 304 241 617 307 241 620 minecraft:stone
fill 304 241 621 307 241 622 minecraft:moss_block
fill 304 241 628 307 241 628 minecraft:stone
fill 304 241 629 307 241 632 minecraft:moss_block
fill 304 241 633 307 241 636 minecraft:stone
fill 304 241 637 307 241 640 minecraft:moss_block
fill 304 241 641 307 241 644 minecraft:stone
fill 304 241 645 307 241 645 minecraft:moss_block
fill 305 241 623 307 241 623 minecraft:moss_block
fill 305 241 627 307 241 627 minecraft:stone
setblock 306 241 604 minecraft:pearlescent_froglight
fill 306 241 624 307 241 624 minecraft:moss_block
fill 306 241 626 307 241 626 minecraft:stone
setblock 307 241 625 minecraft:stone
fill 308 241 605 311 241 608 minecraft:stone
fill 308 241 609 311 241 612 minecraft:moss_block
fill 308 241 613 311 241 616 minecraft:stone
fill 308 241 617 311 241 620 minecraft:moss_block
fill 308 241 621 311 241 624 minecraft:stone
fill 308 241 625 311 241 628 minecraft:moss_block
fill 308 241 629 311 241 632 minecraft:stone
fill 308 241 633 311 241 636 minecraft:moss_block
fill 308 241 637 311 241 640 minecraft:stone
fill 308 241 641 311 241 644 minecraft:moss_block
fill 308 241 645 311 241 645 minecraft:stone
setblock 309 241 646 minecraft:light_blue_concrete
fill 312 241 605 315 241 608 minecraft:moss_block
fill 312 241 609 315 241 612 minecraft:stone
fill 312 241 613 315 241 616 minecraft:moss_block
fill 312 241 617 315 241 620 minecraft:stone
fill 312 241 621 315 241 624 minecraft:moss_block
fill 312 241 625 315 241 628 minecraft:stone
fill 312 241 629 315 241 632 minecraft:moss_block
fill 312 241 633 315 241 636 minecraft:stone
fill 312 241 637 315 241 640 minecraft:moss_block
fill 312 241 641 315 241 644 minecraft:stone
fill 312 241 645 315 241 645 minecraft:moss_block
setblock 315 241 604 minecraft:light_blue_concrete
fill 316 241 605 319 241 608 minecraft:stone
fill 316 241 609 319 241 612 minecraft:moss_block
fill 316 241 613 319 241 616 minecraft:stone
fill 316 241 617 319 241 620 minecraft:moss_block
fill 316 241 621 319 241 624 minecraft:stone
fill 316 241 625 319 241 628 minecraft:moss_block
fill 316 241 629 319 241 632 minecraft:stone
fill 316 241 633 319 241 636 minecraft:moss_block
fill 316 241 637 319 241 640 minecraft:stone
fill 316 241 641 319 241 644 minecraft:moss_block
fill 316 241 645 319 241 645 minecraft:stone
setblock 316 241 646 minecraft:light_blue_concrete
fill 320 241 605 323 241 608 minecraft:moss_block
fill 320 241 609 323 241 612 minecraft:stone
fill 320 241 613 323 241 616 minecraft:moss_block
fill 320 241 617 323 241 620 minecraft:stone
fill 320 241 621 323 241 624 minecraft:moss_block
fill 320 241 625 323 241 628 minecraft:stone
fill 320 241 629 323 241 632 minecraft:moss_block
fill 320 241 633 323 241 636 minecraft:stone
fill 320 241 637 323 241 640 minecraft:moss_block
fill 320 241 641 323 241 644 minecraft:stone
fill 320 241 645 323 241 645 minecraft:moss_block
setblock 324 241 615 minecraft:light_blue_concrete
setblock 324 241 618 minecraft:light_blue_concrete
setblock 324 241 623 minecraft:light_blue_concrete
setblock 324 241 631 minecraft:light_blue_concrete
setblock 324 241 633 minecraft:light_blue_concrete
setblock 324 241 638 minecraft:light_blue_concrete
fill 324 241 642 324 307 642 minecraft:white_concrete
fill 324 241 646 324 242 646 minecraft:light_blue_concrete
fill 282 242 604 282 242 608 minecraft:white_concrete
fill 282 242 610 282 307 610 minecraft:white_concrete
fill 282 242 612 282 251 619 minecraft:white_concrete
fill 282 242 621 282 243 634 minecraft:white_concrete
setblock 282 242 635 minecraft:pearlescent_froglight
fill 282 242 636 282 242 645 minecraft:white_concrete
fill 283 242 604 292 242 604 minecraft:white_concrete
fill 283 242 605 323 242 605 minecraft:dirt
fill 283 242 606 283 242 608 minecraft:moss_block
fill 283 242 609 323 242 609 minecraft:dirt
fill 283 242 610 283 242 612 minecraft:stone
fill 283 242 613 323 242 613 minecraft:dirt
fill 283 242 614 283 242 616 minecraft:moss_block
fill 283 242 617 323 242 617 minecraft:dirt
fill 283 242 618 283 242 620 minecraft:stone
fill 283 242 621 323 242 621 minecraft:dirt
fill 283 242 622 283 242 624 minecraft:moss_block
fill 283 242 625 300 242 625 minecraft:dirt
fill 283 242 626 283 242 628 minecraft:stone
fill 283 242 629 323 242 629 minecraft:dirt
fill 283 242 630 283 242 632 minecraft:moss_block
fill 283 242 633 323 242 633 minecraft:dirt
fill 283 242 634 283 242 636 minecraft:stone
fill 283 242 637 323 242 637 minecraft:dirt
fill 283 242 638 283 242 640 minecraft:moss_block
fill 283 242 641 323 242 641 minecraft:dirt
fill 283 242 642 283 242 644 minecraft:stone
fill 283 242 645 323 242 645 minecraft:dirt
fill 283 242 646 285 243 646 minecraft:white_concrete
fill 284 242 606 284 242 608 minecraft:dirt
fill 284 242 610 284 242 612 minecraft:dirt
fill 284 242 614 284 242 616 minecraft:dirt
fill 284 242 618 284 242 620 minecraft:dirt
fill 284 242 622 284 242 624 minecraft:dirt
fill 284 242 626 284 242 628 minecraft:dirt
fill 284 242 630 284 242 632 minecraft:dirt
fill 284 242 634 284 242 636 minecraft:dirt
fill 284 242 638 284 242 640 minecraft:dirt
fill 284 242 642 284 242 644 minecraft:dirt
fill 285 242 606 287 242 608 minecraft:stone
fill 285 242 610 287 242 612 minecraft:moss_block
fill 285 242 614 287 242 616 minecraft:stone
fill 285 242 618 287 242 620 minecraft:moss_block
fill 285 242 622 287 242 624 minecraft:stone
fill 285 242 626 287 242 628 minecraft:moss_block
fill 285 242 630 287 242 632 minecraft:stone
fill 285 242 634 287 242 636 minecraft:moss_block
fill 285 242 638 287 242 640 minecraft:stone
fill 285 242 642 287 242 644 minecraft:moss_block
setblock 286 242 646 minecraft:pearlescent_froglight
fill 287 242 646 294 242 646 minecraft:white_concrete
fill 288 242 606 288 242 608 minecraft:dirt
fill 288 242 610 288 242 612 minecraft:dirt
fill 288 242 614 288 242 616 minecraft:dirt
fill 288 242 618 288 242 620 minecraft:dirt
fill 288 242 622 288 242 624 minecraft:dirt
fill 288 242 626 288 242 628 minecraft:dirt
fill 288 242 630 288 242 632 minecraft:dirt
fill 288 242 634 288 242 636 minecraft:dirt
fill 288 242 638 288 242 640 minecraft:dirt
fill 288 242 642 288 242 644 minecraft:dirt
fill 289 242 606 291 242 608 minecraft:moss_block
fill 289 242 610 291 242 612 minecraft:stone
fill 289 242 614 291 242 616 minecraft:moss_block
fill 289 242 618 291 242 620 minecraft:stone
fill 289 242 622 291 242 624 minecraft:moss_block
fill 289 242 626 291 242 628 minecraft:stone
fill 289 242 630 291 242 632 minecraft:moss_block
fill 289 242 634 291 242 636 minecraft:stone
fill 289 242 638 291 242 640 minecraft:moss_block
fill 289 242 642 291 242 644 minecraft:stone
fill 292 242 606 292 242 608 minecraft:dirt
fill 292 242 610 292 242 612 minecraft:dirt
fill 292 242 614 292 242 616 minecraft:dirt
fill 292 242 618 292 242 620 minecraft:dirt
fill 292 242 622 292 242 624 minecraft:dirt
fill 292 242 626 292 242 628 minecraft:dirt
fill 292 242 630 292 242 632 minecraft:dirt
fill 292 242 634 292 242 636 minecraft:dirt
fill 292 242 638 292 242 640 minecraft:dirt
fill 292 242 642 292 242 644 minecraft:dirt
setblock 293 242 604 minecraft:light_blue_concrete
fill 293 242 606 295 242 608 minecraft:stone
fill 293 242 610 295 242 612 minecraft:moss_block
fill 293 242 614 295 242 616 minecraft:stone
fill 293 242 618 295 242 620 minecraft:moss_block
fill 293 242 622 295 242 624 minecraft:stone
fill 293 242 626 295 242 628 minecraft:moss_block
fill 293 242 630 295 242 632 minecraft:stone
fill 293 242 634 295 242 636 minecraft:moss_block
fill 293 242 638 295 242 640 minecraft:stone
fill 293 242 642 295 242 644 minecraft:moss_block
fill 294 242 604 294 246 604 minecraft:white_concrete
fill 296 242 604 317 242 604 minecraft:white_concrete
fill 296 242 606 296 242 608 minecraft:dirt
fill 296 242 610 296 242 612 minecraft:dirt
fill 296 242 614 296 242 616 minecraft:dirt
fill 296 242 618 296 242 620 minecraft:dirt
fill 296 242 622 296 242 624 minecraft:dirt
fill 296 242 626 296 242 628 minecraft:dirt
fill 296 242 630 296 242 632 minecraft:dirt
fill 296 242 634 296 242 636 minecraft:dirt
fill 296 242 638 296 242 640 minecraft:dirt
fill 296 242 642 296 242 644 minecraft:dirt
fill 296 242 646 301 242 646 minecraft:white_concrete
fill 297 242 606 299 242 608 minecraft:moss_block
fill 297 242 610 299 242 612 minecraft:stone
fill 297 242 614 299 242 616 minecraft:moss_block
fill 297 242 618 299 242 620 minecraft:stone
fill 297 242 622 299 242 624 minecraft:moss_block
fill 297 242 626 299 242 628 minecraft:stone
fill 297 242 630 299 242 632 minecraft:moss_block
fill 297 242 634 299 242 636 minecraft:stone
fill 297 242 638 299 242 640 minecraft:moss_block
fill 297 242 642 299 242 644 minecraft:stone
fill 300 242 606 300 242 608 minecraft:dirt
fill 300 242 610 300 242 612 minecraft:dirt
fill 300 242 614 300 242 616 minecraft:dirt
fill 300 242 618 300 242 620 minecraft:dirt
fill 300 242 622 300 242 624 minecraft:dirt
fill 300 242 626 300 242 628 minecraft:dirt
fill 300 242 630 300 242 632 minecraft:dirt
fill 300 242 634 300 242 636 minecraft:dirt
fill 300 242 638 300 242 640 minecraft:dirt
fill 300 242 642 300 242 644 minecraft:dirt
fill 301 242 606 303 242 608 minecraft:stone
fill 301 242 610 303 242 612 minecraft:moss_block
fill 301 242 614 303 242 616 minecraft:stone
fill 301 242 618 303 242 620 minecraft:moss_block
fill 301 242 622 301 242 623 minecraft:stone
setblock 301 242 624 minecraft:red_nether_bricks
fill 301 242 625 301 244 625 minecraft:quartz_block
setblock 301 242 626 minecraft:red_nether_bricks
fill 301 242 627 301 242 628 minecraft:moss_block
fill 301 242 630 303 242 632 minecraft:stone
fill 301 242 634 303 242 636 minecraft:moss_block
fill 301 242 638 303 242 640 minecraft:stone
fill 301 242 642 303 242 644 minecraft:moss_block
setblock 302 242 622 minecraft:stone
fill 302 242 623 302 242 624 minecraft:shroomlight
fill 302 242 626 302 242 627 minecraft:shroomlight
setblock 302 242 628 minecraft:moss_block
setblock 303 242 622 minecraft:pearlescent_froglight
setblock 303 242 623 minecraft:shroomlight
setblock 303 242 627 minecraft:shroomlight
setblock 303 242 628 minecraft:pearlescent_froglight
fill 303 242 646 303 247 646 minecraft:white_concrete
fill 304 242 606 304 242 608 minecraft:dirt
fill 304 242 610 304 242 612 minecraft:dirt
fill 304 242 614 304 242 616 minecraft:dirt
fill 304 242 618 304 242 620 minecraft:dirt
fill 304 242 622 304 244 622 minecraft:quartz_block
fill 304 242 628 304 244 628 minecraft:quartz_block
fill 304 242 630 304 242 632 minecraft:dirt
fill 304 242 634 304 242 636 minecraft:dirt
fill 304 242 638 304 242 640 minecraft:dirt
fill 304 242 642 304 242 644 minecraft:dirt
fill 305 242 606 307 242 608 minecraft:moss_block
fill 305 242 610 307 242 612 minecraft:stone
fill 305 242 614 307 242 616 minecraft:moss_block
fill 305 242 618 307 242 620 minecraft:stone
setblock 305 242 622 minecraft:pearlescent_froglight
fill 305 242 623 306 242 623 minecraft:shroomlight
fill 305 242 627 306 242 627 minecraft:shroomlight
setblock 305 242 628 minecraft:pearlescent_froglight
fill 305 242 630 307 242 632 minecraft:moss_block
fill 305 242 634 307 242 636 minecraft:stone
fill 305 242 638 307 242 640 minecraft:moss_block
fill 305 242 642 307 242 644 minecraft:stone
fill 305 242 646 319 242 646 minecraft:white_concrete
fill 306 242 622 307 242 622 minecraft:moss_block
setblock 306 242 624 minecraft:shroomlight
setblock 306 242 626 minecraft:shroomlight
fill 306 242 628 307 242 628 minecraft:stone
setblock 307 242 623 minecraft:moss_block
setblock 307 242 624 minecraft:red_nether_bricks
fill 307 242 625 307 244 625 minecraft:quartz_block
setblock 307 242 626 minecraft:red_nether_bricks
setblock 307 242 627 minecraft:stone
fill 308 242 606 308 242 608 minecraft:dirt
fill 308 242 610 308 242 612 minecraft:dirt
fill 308 242 614 308 242 616 minecraft:dirt
fill 308 242 618 308 242 620 minecraft:dirt
fill 308 242 622 308 242 628 minecraft:dirt
fill 308 242 630 308 242 632 minecraft:dirt
fill 308 242 634 308 242 636 minecraft:dirt
fill 308 242 638 308 242 640 minecraft:dirt
fill 308 242 642 308 242 644 minecraft:dirt
fill 309 242 606 311 242 608 minecraft:stone
fill 309 242 610 311 242 612 minecraft:moss_block
fill 309 242 614 311 242 616 minecraft:stone
fill 309 242 618 311 242 620 minecraft:moss_block
fill 309 242 622 311 242 624 minecraft:stone
fill 309 242 625 323 242 625 minecraft:dirt
fill 309 242 626 311 242 628 minecraft:moss_block
fill 309 242 630 311 242 632 minecraft:stone
fill 309 242 634 311 242 636 minecraft:moss_block
fill 309 242 638 311 242 640 minecraft:stone
fill 309 242 642 311 242 644 minecraft:moss_block
fill 312 242 606 312 242 608 minecraft:dirt
fill 312 242 610 312 242 612 minecraft:dirt
fill 312 242 614 312 242 616 minecraft:dirt
fill 312 242 618 312 242 620 minecraft:dirt
fill 312 242 622 312 242 624 minecraft:dirt
fill 312 242 626 312 242 628 minecraft:dirt
fill 312 242 630 312 242 632 minecraft:dirt
fill 312 242 634 312 242 636 minecraft:dirt
fill 312 242 638 312 242 640 minecraft:dirt
fill 312 242 642 312 242 644 minecraft:dirt
fill 313 242 606 315 242 608 minecraft:moss_block
fill 313 242 610 315 242 612 minecraft:stone
fill 313 242 614 315 242 616 minecraft:moss_block
fill 313 242 618 315 242 620 minecraft:stone
fill 313 242 622 315 242 624 minecraft:moss_block
fill 313 242 626 315 242 628 minecraft:stone
fill 313 242 630 315 242 632 minecraft:moss_block
fill 313 242 634 315 242 636 minecraft:stone
fill 313 242 638 315 242 640 minecraft:moss_block
fill 313 242 642 315 242 644 minecraft:stone
fill 316 242 606 316 242 608 minecraft:dirt
fill 316 242 610 316 242 612 minecraft:dirt
fill 316 242 614 316 242 616 minecraft:dirt
fill 316 242 618 316 242 620 minecraft:dirt
fill 316 242 622 316 242 624 minecraft:dirt
fill 316 242 626 316 242 628 minecraft:dirt
fill 316 242 630 316 242 632 minecraft:dirt
fill 316 242 634 316 242 636 minecraft:dirt
fill 316 242 638 316 242 640 minecraft:dirt
fill 316 242 642 316 242 644 minecraft:dirt
fill 317 242 606 319 242 608 minecraft:stone
fill 317 242 610 319 242 612 minecraft:moss_block
fill 317 242 614 319 242 616 minecraft:stone
fill 317 242 618 319 242 620 minecraft:moss_block
fill 317 242 622 319 242 624 minecraft:stone
fill 317 242 626 319 242 628 minecraft:moss_block
fill 317 242 630 319 242 632 minecraft:stone
fill 317 242 634 319 242 636 minecraft:moss_block
fill 317 242 638 319 242 640 minecraft:stone
fill 317 242 642 319 242 644 minecraft:moss_block
setblock 318 242 604 minecraft:amethyst_block
fill 319 242 604 324 242 604 minecraft:white_concrete
fill 320 242 606 320 242 608 minecraft:dirt
fill 320 242 610 320 242 612 minecraft:dirt
fill 320 242 614 320 242 616 minecraft:dirt
fill 320 242 618 320 242 620 minecraft:dirt
fill 320 242 622 320 242 624 minecraft:dirt
fill 320 242 626 320 242 628 minecraft:dirt
fill 320 242 630 320 242 632 minecraft:dirt
fill 320 242 634 320 242 636 minecraft:dirt
fill 320 242 638 320 242 640 minecraft:dirt
fill 320 242 642 320 242 644 minecraft:dirt
fill 321 242 606 323 242 608 minecraft:moss_block
fill 321 242 610 323 242 612 minecraft:stone
fill 321 242 614 323 242 616 minecraft:moss_block
fill 321 242 618 323 242 620 minecraft:stone
fill 321 242 622 323 242 624 minecraft:moss_block
fill 321 242 626 323 242 628 minecraft:stone
fill 321 242 630 323 242 632 minecraft:moss_block
fill 321 242 634 323 242 636 minecraft:stone
fill 321 242 638 323 242 640 minecraft:moss_block
fill 321 242 642 323 242 644 minecraft:stone
fill 321 242 646 323 243 646 minecraft:white_concrete
fill 324 242 605 324 242 629 minecraft:white_concrete
fill 324 242 631 324 268 635 minecraft:white_concrete
fill 324 242 637 324 242 639 minecraft:white_concrete
setblock 324 242 640 minecraft:amethyst_block
fill 324 242 641 324 243 641 minecraft:white_concrete
fill 324 242 643 324 243 644 minecraft:white_concrete
fill 282 243 604 289 247 604 minecraft:white_concrete
setblock 282 243 605 minecraft:pearlescent_froglight
fill 282 243 606 282 253 609 minecraft:white_concrete
fill 282 243 611 282 302 611 minecraft:white_concrete
fill 282 243 620 282 283 620 minecraft:white_concrete
fill 282 243 635 282 252 637 minecraft:white_concrete
setblock 282 243 638 minecraft:light_blue_concrete
fill 282 243 639 282 251 645 minecraft:white_concrete
fill 286 243 646 292 288 646 minecraft:white_concrete
setblock 290 243 604 minecraft:light_blue_concrete
fill 291 243 604 293 300 604 minecraft:white_concrete
setblock 293 243 646 minecraft:light_blue_concrete
fill 294 243 646 300 246 646 minecraft:white_concrete
fill 295 243 604 297 243 604 minecraft:white_concrete
setblock 298 243 604 minecraft:light_blue_concrete
fill 298 243 625 300 243 625 minecraft:red_nether_bricks
fill 299 243 604 304 243 604 minecraft:white_concrete
fill 299 243 623 300 243 624 minecraft:red_nether_bricks
fill 299 243 626 300 243 627 minecraft:red_nether_bricks
fill 300 243 622 301 245 622 minecraft:red_nether_bricks
fill 300 243 628 301 245 628 minecraft:red_nether_bricks
fill 301 243 621 307 243 621 minecraft:red_nether_bricks
fill 301 243 623 301 244 624 minecraft:quartz_block
fill 301 243 626 301 244 627 minecraft:quartz_block
fill 301 243 629 307 243 629 minecraft:red_nether_bricks
setblock 301 243 646 minecraft:light_blue_concrete
fill 302 243 622 303 244 622 minecraft:quartz_block
setblock 302 243 623 minecraft:red_nether_bricks
setblock 302 243 627 minecraft:red_nether_bricks
fill 302 243 628 303 244 628 minecraft:quartz_block
fill 302 243 646 302 263 646 minecraft:white_concrete
fill 304 243 646 306 247 646 minecraft:white_concrete
fill 305 243 604 305 244 604 minecraft:light_blue_concrete
fill 305 243 622 306 244 622 minecraft:quartz_block
fill 305 243 628 306 244 628 minecraft:quartz_block
fill 306 243 604 307 307 604 minecraft:white_concrete
setblock 306 243 623 minecraft:red_nether_bricks
setblock 306 243 627 minecraft:red_nether_bricks
fill 307 243 622 308 248 622 minecraft:red_nether_bricks
fill 307 243 623 307 244 624 minecraft:quartz_block
fill 307 243 626 307 244 627 minecraft:quartz_block
fill 307 243 628 308 248 628 minecraft:red_nether_bricks
setblock 307 243 646 minecraft:light_blue_concrete
fill 308 243 604 309 243 604 minecraft:light_blue_concrete
fill 308 243 623 309 243 627 minecraft:red_nether_bricks
fill 308 243 646 317 243 646 minecraft:white_concrete
fill 310 243 604 323 243 604 minecraft:white_concrete
fill 310 243 625 310 254 625 minecraft:red_nether_bricks
setblock 318 243 646 minecraft:light_blue_concrete
fill 319 243 646 320 245 646 minecraft:white_concrete
fill 324 243 604 324 243 605 minecraft:light_blue_concrete
fill 324 243 606 324 243 613 minecraft:white_concrete
setblock 324 243 614 minecraft:light_blue_concrete
fill 324 243 615 324 243 625 minecraft:white_concrete
setblock 324 243 626 minecraft:light_blue_concrete
fill 324 243 627 324 249 630 minecraft:white_concrete
fill 324 243 636 324 243 638 minecraft:white_concrete
setblock 324 243 639 minecraft:light_blue_concrete
fill 324 243 640 324 281 640 minecraft:white_concrete
fill 324 243 645 324 307 646 minecraft:white_concrete
setblock 282 244 605 minecraft:light_blue_concrete
fill 282 244 621 282 307 621 minecraft:white_concrete
setblock 282 244 622 minecraft:light_blue_concrete
fill 282 244 623 282 281 625 minecraft:white_concrete
setblock 282 244 626 minecraft:amethyst_block
fill 282 244 627 282 307 627 minecraft:white_concrete
setblock 282 244 628 minecraft:light_blue_concrete
fill 282 244 629 282 307 630 minecraft:white_concrete
setblock 282 244 631 minecraft:light_blue_concrete
setblock 282 244 632 minecraft:pearlescent_froglight
setblock 282 244 633 minecraft:light_blue_concrete
fill 282 244 634 282 253 634 minecraft:white_concrete
fill 282 244 638 282 296 638 minecraft:white_concrete
fill 282 244 646 284 265 646 minecraft:white_concrete
setblock 285 244 646 minecraft:light_blue_concrete
fill 290 244 604 290 307 604 minecraft:white_concrete
fill 293 244 624 299 250 626 minecraft:nether_bricks
fill 293 244 646 293 307 646 minecraft:white_concrete
fill 294 244 623 298 250 623 minecraft:nether_bricks
fill 294 244 627 298 250 627 minecraft:nether_bricks
fill 295 244 604 296 307 604 minecraft:white_concrete
setblock 297 244 604 minecraft:light_blue_concrete
fill 298 244 604 298 307 604 minecraft:white_concrete
fill 298 244 622 299 244 622 minecraft:red_nether_bricks
fill 298 244 628 299 244 628 minecraft:red_nether_bricks
setblock 299 244 604 minecraft:light_blue_concrete
fill 299 244 621 301 251 621 minecraft:red_nether_bricks
setblock 299 244 623 minecraft:red_nether_bricks
setblock 299 244 627 minecraft:red_nether_bricks
fill 299 244 629 301 251 629 minecraft:red_nether_bricks
fill 300 244 604 301 244 604 minecraft:white_concrete
fill 300 244 620 308 251 620 minecraft:red_nether_bricks
setblock 300 244 623 minecraft:quartz_block
setblock 300 244 624 minecraft:red_nether_bricks
setblock 300 244 625 minecraft:quartz_block
setblock 300 244 626 minecraft:red_nether_bricks
setblock 300 244 627 minecraft:quartz_block
fill 300 244 630 308 251 630 minecraft:red_nether_bricks
fill 301 244 646 301 307 646 minecraft:white_concrete
setblock 302 244 604 minecraft:light_blue_concrete
setblock 302 244 621 minecraft:quartz_block
setblock 302 244 629 minecraft:quartz_block
fill 303 244 604 304 262 604 minecraft:white_concrete
fill 303 244 619 305 253 619 minecraft:red_nether_bricks
fill 303 244 621 303 248 621 minecraft:red_nether_bricks
fill 303 244 629 303 248 629 minecraft:red_nether_bricks
fill 303 244 631 305 253 631 minecraft:red_nether_bricks
setblock 304 244 621 minecraft:quartz_block
setblock 304 244 629 minecraft:quartz_block
fill 305 244 621 305 248 621 minecraft:red_nether_bricks
fill 305 244 629 305 248 629 minecraft:red_nether_bricks
setblock 306 244 621 minecraft:quartz_block
setblock 306 244 629 minecraft:quartz_block
fill 307 244 621 309 251 621 minecraft:red_nether_bricks
fill 307 244 629 309 251 629 minecraft:red_nether_bricks
fill 307 244 646 316 245 646 minecraft:white_concrete
fill 308 244 604 310 254 604 minecraft:white_concrete
setblock 308 244 623 minecraft:quartz_block
fill 308 244 624 311 248 624 minecraft:red_nether_bricks
setblock 308 244 625 minecraft:quartz_block
fill 308 244 626 311 248 626 minecraft:red_nether_bricks
setblock 308 244 627 minecraft:quartz_block
fill 309 244 622 310 252 623 minecraft:red_nether_bricks
fill 309 244 625 309 251 625 minecraft:red_nether_bricks
fill 309 244 627 310 252 628 minecraft:red_nether_bricks
fill 311 244 604 312 244 604 minecraft:light_blue_concrete
fill 311 244 623 311 253 623 minecraft:red_nether_bricks
fill 311 244 625 311 253 625 minecraft:red_nether_bricks
fill 311 244 627 311 253 627 minecraft:red_nether_bricks
fill 313 244 604 324 251 604 minecraft:white_concrete
setblock 317 244 646 minecraft:light_blue_concrete
fill 318 244 646 318 307 646 minecraft:white_concrete
setblock 321 244 646 minecraft:light_blue_concrete
fill 322 244 646 323 273 646 minecraft:white_concrete
fill 324 244 605 324 245 609 minecraft:white_concrete
setblock 324 244 610 minecraft:light_blue_concrete
fill 324 244 611 324 244 614 minecraft:white_concrete
setblock 324 244 615 minecraft:light_blue_concrete
fill 324 244 616 324 245 626 minecraft:white_concrete
setblock 324 244 636 minecraft:pearlescent_froglight
setblock 324 244 637 minecraft:light_blue_concrete
fill 324 244 638 324 307 639 minecraft:white_concrete
setblock 324 244 641 minecraft:light_blue_concrete
fill 324 244 643 324 307 643 minecraft:white_concrete
setblock 324 244 644 minecraft:light_blue_concrete
fill 282 245 605 282 307 605 minecraft:white_concrete
fill 282 245 622 282 307 622 minecraft:white_concrete
fill 282 245 626 282 307 626 minecraft:white_concrete
fill 282 245 628 282 251 628 minecraft:white_concrete
fill 282 245 631 282 252 633 minecraft:white_concrete
fill 285 245 646 285 307 646 minecraft:white_concrete
fill 291 245 625 292 249 625 minecraft:nether_bricks
fill 292 245 623 292 247 624 minecraft:nether_bricks
fill 292 245 626 292 247 627 minecraft:nether_bricks
fill 293 245 622 293 249 623 minecraft:nether_bricks
fill 293 245 627 293 249 628 minecraft:nether_bricks
fill 294 245 622 299 249 622 minecraft:nether_bricks
fill 294 245 628 299 249 628 minecraft:nether_bricks
fill 297 245 604 297 307 604 minecraft:white_concrete
setblock 298 245 621 minecraft:red_nether_bricks
setblock 298 245 629 minecraft:red_nether_bricks
fill 299 245 604 300 307 604 minecraft:white_concrete
fill 299 245 620 299 253 620 minecraft:red_nether_bricks
fill 299 245 623 300 249 623 minecraft:nether_bricks
fill 299 245 627 300 249 627 minecraft:nether_bricks
fill 299 245 630 299 253 630 minecraft:red_nether_bricks
fill 300 245 619 302 252 619 minecraft:red_nether_bricks
fill 300 245 624 300 247 626 minecraft:nether_bricks
fill 300 245 631 302 252 631 minecraft:red_nether_bricks
setblock 301 245 604 minecraft:amethyst_block
fill 301 245 623 301 245 624 minecraft:red_nether_bricks
fill 301 245 626 301 245 627 minecraft:red_nether_bricks
fill 302 245 604 302 251 604 minecraft:white_concrete
fill 302 245 621 302 246 622 minecraft:red_nether_bricks
fill 302 245 628 302 246 629 minecraft:red_nether_bricks
setblock 303 245 622 minecraft:red_nether_bricks
setblock 303 245 628 minecraft:red_nether_bricks
fill 304 245 621 304 247 621 minecraft:red_nether_bricks
fill 304 245 629 304 247 629 minecraft:red_nether_bricks
fill 305 245 604 305 307 604 minecraft:white_concrete
fill 305 245 622 306 245 622 minecraft:red_nether_bricks
fill 305 245 628 306 245 628 minecraft:red_nether_bricks
fill 306 245 619 308 252 619 minecraft:red_nether_bricks
fill 306 245 621 306 249 621 minecraft:red_nether_bricks
fill 306 245 629 306 249 629 minecraft:red_nether_bricks
fill 306 245 631 308 252 631 minecraft:red_nether_bricks
fill 307 245 623 307 245 624 minecraft:red_nether_bricks
fill 307 245 626 307 245 627 minecraft:red_nether_bricks
fill 308 245 623 308 249 623 minecraft:red_nether_bricks
fill 308 245 625 308 247 625 minecraft:red_nether_bricks
fill 308 245 627 308 249 627 minecraft:red_nether_bricks
fill 309 245 620 309 253 620 minecraft:red_nether_bricks
fill 309 245 630 309 253 630 minecraft:red_nether_bricks
fill 310 245 621 310 253 621 minecraft:red_nether_bricks
fill 310 245 629 310 253 629 minecraft:red_nether_bricks
fill 311 245 604 312 252 604 minecraft:white_concrete
fill 311 245 622 311 253 622 minecraft:red_nether_bricks
fill 311 245 628 311 253 628 minecraft:red_nether_bricks
fill 312 245 623 312 252 627 minecraft:red_nether_bricks
fill 317 245 646 317 307 646 minecraft:white_concrete
fill 321 245 646 321 307 646 minecraft:white_concrete
fill 324 245 610 324 265 612 minecraft:white_concrete
setblock 324 245 613 minecraft:pearlescent_froglight
fill 324 245 614 324 251 615 minecraft:white_concrete
fill 324 245 636 324 292 637 minecraft:white_concrete
fill 324 245 641 324 276 641 minecraft:white_concrete
fill 324 245 644 324 286 644 minecraft:white_concrete
fill 291 246 623 291 248 624 minecraft:nether_bricks
fill 291 246 626 291 248 627 minecraft:nether_bricks
fill 292 246 622 292 248 622 minecraft:nether_bricks
fill 292 246 628 292 248 628 minecraft:nether_bricks
fill 294 246 621 298 248 621 minecraft:nether_bricks
fill 294 246 629 298 248 629 minecraft:nether_bricks
fill 298 246 620 298 252 620 minecraft:red_nether_bricks
fill 298 246 630 298 252 630 minecraft:red_nether_bricks
fill 299 246 619 299 251 619 minecraft:red_nether_bricks
fill 299 246 631 299 251 631 minecraft:red_nether_bricks
fill 300 246 622 300 248 622 minecraft:nether_bricks
fill 300 246 628 300 248 628 minecraft:nether_bricks
fill 301 246 604 301 287 604 minecraft:white_concrete
fill 301 246 618 307 250 618 minecraft:red_nether_bricks
fill 301 246 622 301 248 622 minecraft:red_nether_bricks
setblock 301 246 623 minecraft:nether_bricks
setblock 301 246 627 minecraft:nether_bricks
fill 301 246 628 301 248 628 minecraft:red_nether_bricks
fill 301 246 632 307 250 632 minecraft:red_nether_bricks
setblock 306 246 622 minecraft:red_nether_bricks
setblock 306 246 628 minecraft:red_nether_bricks
setblock 307 246 623 minecraft:red_nether_bricks
setblock 307 246 627 minecraft:red_nether_bricks
fill 307 246 646 312 251 646 minecraft:white_concrete
fill 309 246 619 309 251 619 minecraft:red_nether_bricks
fill 309 246 631 309 251 631 minecraft:red_nether_bricks
fill 310 246 620 310 252 620 minecraft:red_nether_bricks
fill 310 246 630 310 252 630 minecraft:red_nether_bricks
fill 311 246 621 311 252 621 minecraft:red_nether_bricks
fill 311 246 629 311 252 629 minecraft:red_nether_bricks
fill 312 246 622 312 252 622 minecraft:red_nether_bricks
fill 312 246 628 312 252 628 minecraft:red_nether_bricks
fill 313 246 624 313 251 626 minecraft:red_nether_bricks
setblock 313 246 646 minecraft:pearlescent_froglight
fill 314 246 623 321 247 625 minecraft:black_concrete
fill 314 246 646 316 273 646 minecraft:white_concrete
fill 315 246 622 320 247 622 minecraft:black_concrete
fill 315 246 626 320 247 627 minecraft:black_concrete
fill 316 246 621 320 247 621 minecraft:black_concrete
fill 319 246 646 319 292 646 minecraft:white_concrete
setblock 320 246 646 minecraft:pearlescent_froglight
fill 321 246 626 321 247 626 minecraft:black_concrete
setblock 324 246 605 minecraft:amethyst_block
fill 324 246 606 324 269 609 minecraft:white_concrete
fill 324 246 613 324 281 613 minecraft:white_concrete
fill 324 246 616 324 248 625 minecraft:white_concrete
setblock 324 246 626 minecraft:pearlescent_froglight
setblock 294 247 604 minecraft:pearlescent_froglight
fill 294 247 646 295 247 646 minecraft:white_concrete
setblock 296 247 646 minecraft:pearlescent_froglight
fill 297 247 620 297 251 620 minecraft:red_nether_bricks
fill 297 247 630 297 251 630 minecraft:red_nether_bricks
fill 297 247 646 300 307 646 minecraft:white_concrete
fill 298 247 619 298 250 619 minecraft:red_nether_bricks
fill 298 247 631 298 250 631 minecraft:red_nether_bricks
fill 300 247 618 300 250 618 minecraft:red_nether_bricks
fill 300 247 632 300 250 632 minecraft:red_nether_bricks
fill 302 247 621 302 249 621 minecraft:red_nether_bricks
fill 302 247 629 302 249 629 minecraft:red_nether_bricks
fill 308 247 618 308 250 618 minecraft:red_nether_bricks
fill 308 247 632 308 250 632 minecraft:red_nether_bricks
fill 310 247 619 310 250 619 minecraft:red_nether_bricks
fill 310 247 631 310 250 631 minecraft:red_nether_bricks
fill 310 247 640 312 247 644 minecraft:amethyst_block
fill 311 247 620 311 251 620 minecraft:red_nether_bricks
fill 311 247 630 311 251 630 minecraft:red_nether_bricks
fill 311 247 638 311 247 639 minecraft:amethyst_block
fill 311 247 645 311 250 645 minecraft:amethyst_block
fill 312 247 621 312 251 621 minecraft:red_nether_bricks
fill 312 247 629 312 251 629 minecraft:red_nether_bricks
fill 313 247 623 313 251 623 minecraft:red_nether_bricks
fill 313 247 627 313 251 627 minecraft:red_nether_bricks
fill 313 247 646 313 306 646 minecraft:white_concrete
setblock 314 247 622 minecraft:black_concrete
setblock 314 247 626 minecraft:black_concrete
setblock 315 247 621 minecraft:black_concrete
fill 316 247 620 319 247 620 minecraft:black_concrete
fill 316 247 628 319 247 628 minecraft:black_concrete
fill 320 247 646 320 307 646 minecraft:white_concrete
setblock 321 247 622 minecraft:black_concrete
setblock 322 247 624 minecraft:black_concrete
fill 324 247 605 324 307 605 minecraft:white_concrete
fill 324 247 626 324 251 626 minecraft:white_concrete
fill 282 248 604 285 268 604 minecraft:white_concrete
setblock 286 248 604 minecraft:pearlescent_froglight
fill 287 248 604 289 286 604 minecraft:white_concrete
fill 292 248 623 292 249 623 minecraft:black_concrete
fill 292 248 624 292 249 624 minecraft:nether_bricks
fill 292 248 626 292 249 626 minecraft:nether_bricks
fill 292 248 627 292 249 627 minecraft:black_concrete
fill 294 248 604 294 267 604 minecraft:white_concrete
fill 294 248 646 294 307 646 minecraft:white_concrete
setblock 295 248 646 minecraft:amethyst_block
fill 296 248 646 296 251 646 minecraft:white_concrete
setblock 300 248 624 minecraft:nether_bricks
setblock 300 248 626 minecraft:nether_bricks
setblock 303 248 646 minecraft:amethyst_block
fill 304 248 646 305 255 646 minecraft:white_concrete
setblock 306 248 646 minecraft:pearlescent_froglight
fill 310 248 641 310 248 645 minecraft:amethyst_block
fill 311 248 640 311 248 644 minecraft:amethyst_block
fill 312 248 641 312 248 645 minecraft:amethyst_block
fill 313 248 622 313 250 622 minecraft:red_nether_bricks
fill 313 248 628 313 250 628 minecraft:red_nether_bricks
fill 317 248 623 318 248 625 minecraft:amethyst_block
fill 286 249 604 286 251 604 minecraft:white_concrete
setblock 291 249 624 minecraft:nether_bricks
setblock 291 249 626 minecraft:nether_bricks
fill 295 249 646 295 307 646 minecraft:white_concrete
fill 296 249 621 298 251 621 minecraft:red_nether_bricks
fill 296 249 629 298 251 629 minecraft:red_nether_bricks
fill 300 249 622 300 251 622 minecraft:red_nether_bricks
fill 300 249 628 300 251 628 minecraft:red_nether_bricks
fill 303 249 646 303 307 646 minecraft:white_concrete
fill 306 249 646 306 307 646 minecraft:white_concrete
fill 308 249 622 308 251 622 minecraft:red_nether_bricks
fill 308 249 628 308 251 628 minecraft:red_nether_bricks
fill 309 249 624 311 251 624 minecraft:red_nether_bricks
fill 309 249 626 311 251 626 minecraft:red_nether_bricks
fill 310 249 642 310 249 645 minecraft:amethyst_block
fill 311 249 641 311 249 644 minecraft:amethyst_block
fill 312 249 642 312 249 645 minecraft:amethyst_block
fill 317 249 624 318 250 624 minecraft:amethyst_block
setblock 318 249 625 minecraft:amethyst_block
fill 324 249 616 324 277 624 minecraft:white_concrete
setblock 324 249 625 minecraft:pearlescent_froglight
setblock 285 250 607 minecraft:light[level=13]
setblock 285 250 615 minecraft:light[level=13]
setblock 285 250 623 minecraft:light[level=13]
setblock 285 250 631 minecraft:light[level=13]
setblock 285 250 639 minecraft:light[level=13]
setblock 292 250 625 minecraft:nether_bricks
setblock 293 250 607 minecraft:light[level=13]
setblock 293 250 615 minecraft:light[level=13]
setblock 293 250 623 minecraft:nether_bricks
setblock 293 250 627 minecraft:nether_bricks
setblock 293 250 631 minecraft:light[level=13]
setblock 293 250 639 minecraft:light[level=13]
fill 295 250 622 297 250 622 minecraft:nether_bricks
fill 295 250 628 297 250 628 minecraft:nether_bricks
fill 298 250 622 299 253 622 minecraft:red_nether_bricks
fill 298 250 628 299 253 628 minecraft:red_nether_bricks
setblock 299 250 623 minecraft:nether_bricks
setblock 299 250 627 minecraft:nether_bricks
setblock 301 250 607 minecraft:light[level=13]
setblock 301 250 615 minecraft:light[level=13]
setblock 301 250 639 minecraft:light[level=13]
setblock 309 250 607 minecraft:light[level=13]
setblock 309 250 615 minecraft:light[level=13]
setblock 309 250 639 minecraft:light[level=13]
fill 310 250 644 312 250 644 minecraft:amethyst_block
setblock 311 250 643 minecraft:amethyst_block
setblock 317 250 607 minecraft:light[level=13]
setblock 317 250 615 minecraft:light[level=13]
setblock 317 250 623 minecraft:light[level=13]
setblock 317 250 631 minecraft:light[level=13]
setblock 317 250 639 minecraft:light[level=13]
fill 324 250 625 324 307 625 minecraft:white_concrete
fill 324 250 627 324 275 627 minecraft:white_concrete
setblock 324 250 628 minecraft:amethyst_block
fill 324 250 629 324 251 630 minecraft:white_concrete
fill 295 251 623 299 251 624 minecraft:red_nether_bricks
fill 295 251 625 297 251 625 minecraft:nether_bricks
fill 295 251 626 299 251 627 minecraft:red_nether_bricks
fill 296 251 622 297 252 622 minecraft:red_nether_bricks
fill 296 251 628 297 252 628 minecraft:red_nether_bricks
fill 298 251 625 299 251 625 minecraft:red_nether_bricks
fill 301 251 618 305 251 618 minecraft:red_nether_bricks
fill 301 251 632 305 251 632 minecraft:red_nether_bricks
setblock 306 251 618 minecraft:black_concrete
setblock 306 251 632 minecraft:black_concrete
setblock 307 251 618 minecraft:red_nether_bricks
setblock 307 251 632 minecraft:red_nether_bricks
setblock 318 251 624 minecraft:amethyst_block
fill 324 251 628 324 261 628 minecraft:white_concrete
fill 282 252 612 282 254 612 minecraft:gold_block
fill 282 252 613 282 282 619 minecraft:white_concrete
fill 282 252 628 282 254 628 minecraft:gold_block
fill 282 252 639 282 271 642 minecraft:white_concrete
setblock 282 252 643 minecraft:amethyst_block
fill 282 252 644 282 254 644 minecraft:gold_block
fill 282 252 645 282 307 645 minecraft:white_concrete
fill 286 252 604 286 254 604 minecraft:gold_block
fill 296 252 623 298 252 627 minecraft:red_nether_bricks
fill 296 252 646 296 254 646 minecraft:gold_block
fill 297 252 621 300 252 621 minecraft:red_nether_bricks
fill 297 252 629 300 252 629 minecraft:red_nether_bricks
setblock 299 252 623 minecraft:red_nether_bricks
setblock 299 252 627 minecraft:red_nether_bricks
setblock 300 252 620 minecraft:red_nether_bricks
setblock 300 252 630 minecraft:red_nether_bricks
fill 301 252 620 301 253 620 minecraft:shroomlight
fill 301 252 630 301 253 630 minecraft:shroomlight
fill 302 252 604 302 254 604 minecraft:gold_block
setblock 302 252 620 minecraft:red_nether_bricks
setblock 302 252 630 minecraft:red_nether_bricks
fill 303 252 618 305 252 618 minecraft:red_nether_bricks
fill 303 252 632 305 252 632 minecraft:red_nether_bricks
fill 306 252 617 309 252 617 minecraft:black_concrete
fill 306 252 620 308 252 620 minecraft:red_nether_bricks
fill 306 252 630 308 252 630 minecraft:red_nether_bricks
fill 306 252 633 309 252 633 minecraft:black_concrete
fill 307 252 646 311 281 646 minecraft:white_concrete
fill 308 252 621 309 253 621 minecraft:red_nether_bricks
fill 308 252 629 309 253 629 minecraft:red_nether_bricks
fill 310 252 624 311 253 624 minecraft:red_nether_bricks
fill 310 252 626 311 253 626 minecraft:red_nether_bricks
fill 312 252 646 312 254 646 minecraft:gold_block
fill 313 252 604 317 307 604 minecraft:white_concrete
fill 318 252 604 318 254 604 minecraft:gold_block
fill 319 252 604 324 265 604 minecraft:white_concrete
fill 324 252 614 324 254 614 minecraft:gold_block
fill 324 252 615 324 290 615 minecraft:white_concrete
setblock 324 252 626 minecraft:pearlescent_froglight
fill 324 252 629 324 278 629 minecraft:white_concrete
fill 324 252 630 324 254 630 minecraft:gold_block
setblock 282 253 631 minecraft:amethyst_block
fill 282 253 632 282 259 633 minecraft:white_concrete
fill 282 253 635 282 268 636 minecraft:white_concrete
setblock 282 253 637 minecraft:pearlescent_froglight
fill 282 253 643 282 307 643 minecraft:white_concrete
fill 296 253 625 298 253 625 minecraft:red_nether_bricks
fill 297 253 622 297 253 624 minecraft:red_nether_bricks
fill 297 253 626 297 253 628 minecraft:red_nether_bricks
fill 298 253 621 299 253 621 minecraft:red_nether_bricks
fill 298 253 623 298 254 624 minecraft:red_nether_bricks
fill 298 253 626 298 254 627 minecraft:red_nether_bricks
fill 298 253 629 299 253 629 minecraft:red_nether_bricks
fill 300 253 620 300 253 621 minecraft:shroomlight
fill 300 253 629 300 253 630 minecraft:shroomlight
setblock 302 253 619 minecraft:red_nether_bricks
setblock 302 253 631 minecraft:red_nether_bricks
setblock 306 253 617 minecraft:black_concrete
setblock 306 253 619 minecraft:red_nether_bricks
setblock 306 253 631 minecraft:red_nether_bricks
setblock 306 253 633 minecraft:black_concrete
fill 307 253 616 311 253 616 minecraft:black_concrete
fill 307 253 620 308 253 620 minecraft:red_nether_bricks
fill 307 253 630 308 253 630 minecraft:red_nether_bricks
fill 307 253 634 311 253 634 minecraft:black_concrete
fill 309 253 622 310 253 622 minecraft:red_nether_bricks
fill 309 253 628 310 253 628 minecraft:red_nether_bricks
fill 310 253 615 312 253 615 minecraft:black_concrete
fill 310 253 623 310 254 623 minecraft:red_nether_bricks
fill 310 253 627 310 254 627 minecraft:red_nether_bricks
fill 310 253 635 312 253 635 minecraft:black_concrete
fill 311 253 604 311 307 604 minecraft:white_concrete
setblock 312 253 604 minecraft:amethyst_block
setblock 312 253 625 minecraft:red_nether_bricks
fill 324 253 626 324 307 626 minecraft:white_concrete
fill 282 254 606 282 307 606 minecraft:white_concrete
setblock 282 254 607 minecraft:amethyst_block
fill 282 254 608 282 307 609 minecraft:white_concrete
fill 282 254 631 282 307 631 minecraft:white_concrete
setblock 282 254 634 minecraft:amethyst_block
fill 282 254 637 282 307 637 minecraft:white_concrete
setblock 298 254 625 minecraft:red_nether_bricks
setblock 306 254 616 minecraft:black_concrete
setblock 306 254 634 minecraft:black_concrete
setblock 307 254 615 minecraft:black_concrete
setblock 307 254 635 minecraft:black_concrete
fill 309 254 615 310 254 615 minecraft:black_concrete
fill 309 254 635 310 254 635 minecraft:black_concrete
setblock 310 254 624 minecraft:red_nether_bricks
setblock 310 254 626 minecraft:red_nether_bricks
setblock 311 254 614 minecraft:black_concrete
setblock 311 254 636 minecraft:black_concrete
fill 312 254 604 312 307 604 minecraft:white_concrete
setblock 314 254 614 minecraft:black_concrete
setblock 314 254 636 minecraft:black_concrete
fill 282 255 607 282 307 607 minecraft:white_concrete
fill 282 255 612 282 260 612 minecraft:white_concrete
fill 282 255 628 282 260 628 minecraft:white_concrete
fill 282 255 634 282 307 634 minecraft:white_concrete
fill 282 255 644 282 260 644 minecraft:white_concrete
fill 286 255 604 286 260 604 minecraft:white_concrete
fill 296 255 646 296 260 646 minecraft:white_concrete
setblock 302 255 604 minecraft:white_concrete
fill 305 255 614 305 256 614 minecraft:amethyst_block
fill 306 255 615 306 256 615 minecraft:black_concrete
fill 306 255 635 306 256 635 minecraft:black_concrete
fill 308 255 604 309 300 604 minecraft:white_concrete
fill 308 255 614 308 256 614 minecraft:black_concrete
setblock 308 255 620 minecraft:blackstone
setblock 308 255 630 minecraft:blackstone
fill 308 255 636 308 256 636 minecraft:black_concrete
setblock 310 255 604 minecraft:amethyst_block
setblock 310 255 614 minecraft:black_concrete
setblock 310 255 636 minecraft:black_concrete
fill 312 255 613 313 255 613 minecraft:black_concrete
fill 312 255 637 313 255 637 minecraft:black_concrete
fill 312 255 646 312 260 646 minecraft:white_concrete
fill 316 255 613 317 255 613 minecraft:black_concrete
fill 316 255 637 317 255 637 minecraft:black_concrete
fill 317 255 612 318 255 612 minecraft:black_concrete
fill 317 255 638 318 255 638 minecraft:black_concrete
fill 318 255 604 318 260 604 minecraft:white_concrete
fill 324 255 614 324 260 614 minecraft:white_concrete
fill 324 255 630 324 260 630 minecraft:white_concrete
setblock 302 256 604 minecraft:pearlescent_froglight
setblock 304 256 646 minecraft:white_concrete
setblock 305 256 646 minecraft:amethyst_block
fill 306 256 614 306 257 614 minecraft:black_concrete
fill 306 256 636 306 257 636 minecraft:black_concrete
fill 308 256 613 308 257 613 minecraft:black_concrete
fill 308 256 619 309 257 619 minecraft:blackstone
fill 308 256 631 309 257 631 minecraft:blackstone
fill 308 256 637 308 257 637 minecraft:black_concrete
fill 309 256 620 309 258 620 minecraft:blackstone
fill 309 256 630 309 258 630 minecraft:blackstone
fill 310 256 604 310 307 604 minecraft:white_concrete
fill 311 256 613 311 257 613 minecraft:black_concrete
fill 311 256 637 311 257 637 minecraft:black_concrete
setblock 314 256 612 minecraft:black_concrete
fill 314 256 621 315 257 622 minecraft:end_stone
setblock 314 256 638 minecraft:black_concrete
fill 315 256 611 315 257 611 minecraft:black_concrete
fill 315 256 639 315 257 639 minecraft:black_concrete
setblock 318 256 612 minecraft:black_concrete
setblock 318 256 638 minecraft:black_concrete
fill 302 257 604 302 260 604 minecraft:white_concrete
setblock 304 257 646 minecraft:amethyst_block
fill 305 257 614 305 264 614 minecraft:black_concrete
fill 305 257 646 305 293 646 minecraft:white_concrete
fill 310 257 619 310 259 619 minecraft:blackstone
fill 310 257 631 310 259 631 minecraft:blackstone
fill 312 257 612 312 258 612 minecraft:black_concrete
fill 312 257 638 312 258 638 minecraft:black_concrete
setblock 285 258 607 minecraft:light[level=13]
setblock 285 258 615 minecraft:light[level=13]
setblock 285 258 623 minecraft:light[level=13]
setblock 285 258 631 minecraft:light[level=13]
setblock 285 258 639 minecraft:light[level=13]
setblock 293 258 607 minecraft:light[level=13]
setblock 293 258 615 minecraft:light[level=13]
setblock 293 258 623 minecraft:light[level=13]
setblock 293 258 631 minecraft:light[level=13]
setblock 293 258 639 minecraft:light[level=13]
schedule function dropper:buildpart/150_3 1t
