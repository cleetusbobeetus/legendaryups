setblock 299 295 228 minecraft:brown_terracotta
fill 299 295 270 304 296 270 minecraft:gray_concrete
fill 300 295 228 303 297 228 minecraft:gray_concrete
setblock 301 295 231 minecraft:light[level=12]
setblock 301 295 239 minecraft:light[level=12]
setblock 301 295 247 minecraft:light[level=12]
setblock 301 295 255 minecraft:light[level=12]
setblock 301 295 263 minecraft:light[level=12]
setblock 304 295 228 minecraft:orange_terracotta
setblock 305 295 228 minecraft:brown_terracotta
setblock 305 295 270 minecraft:brown_terracotta
fill 306 295 228 312 295 228 minecraft:gray_concrete
setblock 309 295 231 minecraft:light[level=12]
setblock 309 295 247 minecraft:light[level=12]
setblock 309 295 255 minecraft:light[level=12]
setblock 309 295 263 minecraft:light[level=12]
fill 314 295 270 316 297 270 minecraft:gray_concrete
fill 317 295 228 317 301 228 minecraft:gray_concrete
setblock 317 295 231 minecraft:light[level=12]
setblock 317 295 239 minecraft:light[level=12]
setblock 317 295 247 minecraft:light[level=12]
setblock 317 295 255 minecraft:light[level=12]
setblock 317 295 263 minecraft:light[level=12]
setblock 318 295 228 minecraft:brown_terracotta
setblock 319 295 228 minecraft:orange_terracotta
fill 319 295 270 319 300 270 minecraft:gray_concrete
fill 320 295 228 323 296 228 minecraft:gray_concrete
fill 322 295 270 322 296 270 minecraft:gray_concrete
fill 324 295 232 324 295 233 minecraft:gray_concrete
fill 324 295 234 324 295 235 minecraft:brown_terracotta
fill 324 295 236 324 297 239 minecraft:gray_concrete
setblock 324 295 240 minecraft:orange_terracotta
fill 324 295 241 324 296 241 minecraft:gray_concrete
fill 324 295 247 324 297 247 minecraft:gray_concrete
setblock 324 295 248 minecraft:brown_terracotta
fill 324 295 249 324 295 252 minecraft:gray_concrete
setblock 324 295 253 minecraft:orange_terracotta
setblock 324 295 254 minecraft:gray_concrete
fill 324 295 266 324 300 266 minecraft:gray_concrete
setblock 324 295 267 minecraft:gray_terracotta
fill 324 295 268 324 299 270 minecraft:gray_concrete
fill 282 296 236 282 300 236 minecraft:gray_concrete
fill 282 296 241 282 300 241 minecraft:gray_concrete
fill 282 296 246 282 300 246 minecraft:gray_concrete
setblock 282 296 248 minecraft:gray_concrete
fill 282 296 258 282 296 259 minecraft:gray_concrete
fill 282 296 265 282 299 265 minecraft:gray_concrete
fill 282 296 267 282 300 267 minecraft:gray_concrete
fill 283 296 228 283 298 228 minecraft:gray_concrete
fill 283 296 270 284 296 270 minecraft:gray_concrete
fill 284 296 233 286 300 235 minecraft:gray_wool
setblock 287 296 270 minecraft:gray_concrete
setblock 289 296 228 minecraft:gray_concrete
fill 295 296 228 295 297 228 minecraft:gray_concrete
fill 297 296 228 299 297 228 minecraft:gray_concrete
fill 298 296 270 298 300 270 minecraft:gray_concrete
fill 304 296 228 306 298 228 minecraft:gray_concrete
fill 305 296 266 306 296 268 minecraft:light_gray_wool
setblock 305 296 270 minecraft:orange_terracotta
fill 306 296 270 308 300 270 minecraft:gray_concrete
setblock 307 296 228 minecraft:light_gray_terracotta
fill 307 296 266 308 297 267 minecraft:magma_block
fill 307 296 268 308 297 268 minecraft:light_gray_wool
fill 308 296 228 314 298 228 minecraft:gray_concrete
setblock 315 296 228 minecraft:gray_terracotta
fill 316 296 228 316 297 228 minecraft:gray_concrete
fill 318 296 228 319 297 228 minecraft:gray_concrete
fill 324 296 232 324 300 232 minecraft:gray_concrete
setblock 324 296 233 minecraft:light_gray_terracotta
fill 324 296 234 324 296 235 minecraft:gray_concrete
fill 324 296 240 324 301 240 minecraft:gray_concrete
fill 324 296 246 324 297 246 minecraft:gray_concrete
fill 324 296 248 324 300 248 minecraft:gray_concrete
setblock 324 296 249 minecraft:light_gray_terracotta
fill 324 296 250 324 297 253 minecraft:gray_concrete
setblock 324 296 254 minecraft:gray_terracotta
fill 324 296 260 324 300 260 minecraft:gray_concrete
fill 324 296 264 324 298 264 minecraft:gray_concrete
setblock 324 296 265 minecraft:orange_terracotta
fill 324 296 267 324 297 267 minecraft:gray_concrete
fill 282 297 229 282 300 230 minecraft:gray_concrete
setblock 282 297 231 minecraft:light_gray_terracotta
fill 282 297 232 282 300 235 minecraft:gray_concrete
setblock 282 297 248 minecraft:light_gray_terracotta
fill 282 297 249 282 297 252 minecraft:gray_concrete
setblock 282 297 253 minecraft:gray_terracotta
fill 282 297 254 282 298 257 minecraft:gray_concrete
setblock 282 297 258 minecraft:light_gray_concrete
fill 282 297 259 282 298 259 minecraft:gray_concrete
setblock 282 297 260 minecraft:light_gray_concrete
fill 282 297 261 282 298 262 minecraft:gray_concrete
setblock 282 297 263 minecraft:light_gray_concrete
fill 282 297 264 282 300 264 minecraft:gray_concrete
fill 283 297 232 283 298 235 minecraft:gray_wool
fill 283 297 270 284 297 270 minecraft:light_gray_concrete
fill 284 297 232 285 300 232 minecraft:gray_wool
fill 284 297 236 286 299 236 minecraft:gray_wool
fill 284 297 247 285 297 249 minecraft:orange_concrete
setblock 285 297 231 minecraft:light[level=12]
setblock 285 297 238 minecraft:light[level=12]
fill 285 297 245 286 297 246 minecraft:orange_concrete
fill 285 297 250 287 297 251 minecraft:orange_concrete
setblock 285 297 252 minecraft:light[level=12]
setblock 285 297 259 minecraft:light[level=12]
setblock 285 297 266 minecraft:light[level=12]
fill 287 297 234 287 300 235 minecraft:gray_wool
fill 287 297 244 288 297 245 minecraft:orange_concrete
setblock 287 297 270 minecraft:light_gray_concrete
fill 288 297 251 290 297 251 minecraft:orange_concrete
fill 288 297 270 288 298 270 minecraft:gray_concrete
setblock 289 297 228 minecraft:orange_terracotta
fill 289 297 245 290 297 246 minecraft:orange_concrete
fill 289 297 250 291 297 250 minecraft:orange_concrete
setblock 289 297 270 minecraft:light_gray_concrete
fill 290 297 228 293 297 228 minecraft:gray_concrete
fill 290 297 247 291 297 249 minecraft:orange_concrete
setblock 290 297 270 minecraft:orange_terracotta
setblock 291 297 246 minecraft:orange_concrete
fill 291 297 270 297 297 270 minecraft:gray_concrete
setblock 292 297 231 minecraft:light[level=12]
setblock 292 297 238 minecraft:light[level=12]
setblock 292 297 245 minecraft:light[level=12]
setblock 292 297 252 minecraft:light[level=12]
setblock 292 297 259 minecraft:light[level=12]
setblock 292 297 266 minecraft:light[level=12]
setblock 294 297 228 minecraft:light_gray_concrete
setblock 299 297 231 minecraft:light[level=12]
setblock 299 297 238 minecraft:light[level=12]
setblock 299 297 245 minecraft:light[level=12]
setblock 299 297 252 minecraft:light[level=12]
setblock 299 297 259 minecraft:light[level=12]
setblock 299 297 266 minecraft:light[level=12]
fill 299 297 270 302 300 270 minecraft:gray_concrete
setblock 303 297 270 minecraft:orange_terracotta
fill 304 297 270 305 298 270 minecraft:gray_concrete
fill 305 297 267 306 297 268 minecraft:light_gray_wool
fill 306 297 231 308 301 231 minecraft:gray_wool
fill 306 297 238 307 297 241 minecraft:orange_concrete
setblock 306 297 245 minecraft:light[level=12]
setblock 306 297 252 minecraft:light[level=12]
setblock 306 297 259 minecraft:light[level=12]
setblock 306 297 266 minecraft:light[level=12]
fill 307 297 228 307 300 228 minecraft:gray_concrete
fill 307 297 237 314 297 237 minecraft:orange_concrete
fill 307 297 242 309 297 242 minecraft:orange_concrete
fill 308 297 236 313 297 236 minecraft:orange_concrete
fill 308 297 238 308 299 238 minecraft:orange_concrete
fill 308 297 241 308 299 241 minecraft:orange_concrete
fill 308 297 243 313 297 243 minecraft:orange_concrete
fill 309 297 244 311 297 244 minecraft:orange_concrete
setblock 310 297 270 minecraft:light_gray_concrete
fill 311 297 242 314 297 242 minecraft:orange_concrete
setblock 311 297 270 minecraft:gray_concrete
setblock 313 297 231 minecraft:light[level=12]
fill 313 297 238 314 297 241 minecraft:orange_concrete
setblock 313 297 245 minecraft:light[level=12]
setblock 313 297 252 minecraft:light[level=12]
setblock 313 297 259 minecraft:light[level=12]
setblock 313 297 266 minecraft:light[level=12]
fill 315 297 228 315 298 228 minecraft:gray_concrete
setblock 320 297 228 minecraft:light_gray_concrete
setblock 320 297 231 minecraft:light[level=12]
setblock 320 297 238 minecraft:light[level=12]
setblock 320 297 245 minecraft:light[level=12]
setblock 320 297 252 minecraft:light[level=12]
setblock 320 297 259 minecraft:light[level=12]
setblock 320 297 266 minecraft:light[level=12]
fill 321 297 228 322 300 228 minecraft:gray_concrete
setblock 322 297 270 minecraft:light_gray_concrete
setblock 323 297 228 minecraft:light_gray_concrete
fill 324 297 233 324 298 233 minecraft:gray_concrete
fill 324 297 234 324 298 234 minecraft:light_gray_concrete
fill 324 297 235 324 300 235 minecraft:gray_concrete
setblock 324 297 241 minecraft:orange_terracotta
fill 324 297 242 324 298 243 minecraft:gray_concrete
fill 324 297 244 324 299 244 minecraft:light_gray_concrete
fill 324 297 245 324 300 245 minecraft:gray_concrete
fill 324 297 249 324 300 249 minecraft:gray_concrete
fill 324 297 254 324 300 254 minecraft:gray_concrete
fill 324 297 265 324 300 265 minecraft:gray_concrete
fill 282 298 228 282 299 228 minecraft:light_gray_concrete
fill 282 298 231 282 300 231 minecraft:gray_concrete
fill 282 298 248 282 300 248 minecraft:gray_concrete
setblock 282 298 249 minecraft:gray_terracotta
fill 282 298 250 282 299 252 minecraft:gray_concrete
setblock 282 298 253 minecraft:light_gray_concrete
fill 282 298 258 282 300 258 minecraft:gray_concrete
fill 282 298 260 282 300 260 minecraft:gray_concrete
fill 282 298 263 282 300 263 minecraft:gray_concrete
setblock 282 298 266 minecraft:light_gray_concrete
setblock 283 298 236 minecraft:gray_wool
fill 283 298 270 284 299 270 minecraft:gray_concrete
fill 285 298 246 285 298 250 minecraft:orange_concrete
fill 286 298 232 286 300 232 minecraft:gray_wool
fill 286 298 245 286 298 246 minecraft:orange_concrete
fill 286 298 250 287 299 250 minecraft:orange_concrete
fill 287 298 233 287 300 233 minecraft:gray_wool
setblock 287 298 236 minecraft:gray_wool
fill 287 298 245 289 298 245 minecraft:orange_concrete
fill 287 298 251 289 298 251 minecraft:orange_concrete
setblock 287 298 270 minecraft:light_gray_terracotta
fill 288 298 234 288 299 234 minecraft:gray_wool
setblock 289 298 228 minecraft:light_gray_concrete
fill 289 298 246 290 298 246 minecraft:orange_concrete
fill 289 298 250 290 298 250 minecraft:orange_concrete
fill 289 298 270 289 300 270 minecraft:gray_concrete
setblock 290 298 228 minecraft:gray_concrete
fill 290 298 247 290 299 249 minecraft:orange_concrete
setblock 290 298 270 minecraft:light_gray_concrete
setblock 291 298 228 minecraft:light_gray_concrete
fill 291 298 231 293 301 231 minecraft:light_gray_wool
setblock 291 298 248 minecraft:orange_concrete
fill 291 298 270 292 300 270 minecraft:gray_concrete
fill 292 298 228 294 298 228 minecraft:gray_concrete
fill 292 298 230 292 301 230 minecraft:light_gray_wool
fill 292 298 232 293 300 232 minecraft:light_gray_wool
setblock 293 298 270 minecraft:light_gray_terracotta
fill 294 298 270 295 298 270 minecraft:gray_concrete
setblock 295 298 228 minecraft:gray_terracotta
setblock 296 298 270 minecraft:light_gray_concrete
setblock 297 298 228 minecraft:light_gray_concrete
fill 297 298 235 297 299 236 minecraft:blackstone
fill 297 298 270 297 300 270 minecraft:gray_concrete
fill 298 298 228 298 300 228 minecraft:gray_concrete
setblock 299 298 228 minecraft:light_gray_concrete
fill 300 298 228 301 299 228 minecraft:gray_concrete
setblock 302 298 228 minecraft:light_gray_concrete
fill 303 298 228 303 299 228 minecraft:gray_concrete
fill 303 298 270 303 300 270 minecraft:gray_concrete
fill 305 298 231 305 300 232 minecraft:gray_wool
fill 306 298 229 307 301 230 minecraft:gray_wool
fill 306 298 232 308 301 232 minecraft:gray_wool
fill 307 298 238 307 298 241 minecraft:orange_concrete
fill 308 298 230 308 301 230 minecraft:gray_wool
fill 308 298 237 313 298 237 minecraft:orange_concrete
fill 308 298 242 309 298 242 minecraft:orange_concrete
fill 309 298 231 309 301 231 minecraft:gray_wool
fill 309 298 236 311 298 236 minecraft:orange_concrete
fill 309 298 243 312 298 243 minecraft:orange_concrete
fill 310 298 270 310 300 270 minecraft:gray_concrete
fill 311 298 242 313 298 242 minecraft:orange_concrete
setblock 311 298 270 minecraft:light_gray_concrete
fill 313 298 238 313 298 241 minecraft:orange_concrete
fill 314 298 239 314 298 240 minecraft:orange_concrete
setblock 314 298 270 minecraft:gray_concrete
setblock 315 298 270 minecraft:light_gray_concrete
setblock 316 298 228 minecraft:light_gray_terracotta
fill 316 298 270 316 300 270 minecraft:gray_concrete
fill 318 298 228 318 300 228 minecraft:gray_concrete
setblock 319 298 228 minecraft:light_gray_concrete
fill 320 298 228 320 300 228 minecraft:gray_concrete
fill 322 298 270 322 302 270 minecraft:gray_concrete
fill 323 298 228 323 300 228 minecraft:gray_concrete
fill 324 298 236 324 300 237 minecraft:gray_concrete
fill 324 298 238 324 298 239 minecraft:light_gray_concrete
fill 324 298 241 324 300 241 minecraft:gray_concrete
setblock 324 298 246 minecraft:gray_terracotta
setblock 324 298 247 minecraft:light_gray_concrete
fill 324 298 250 324 298 251 minecraft:gray_concrete
setblock 324 298 252 minecraft:light_gray_concrete
fill 324 298 253 324 300 253 minecraft:gray_concrete
fill 324 298 255 324 300 255 minecraft:gray_concrete
setblock 324 298 256 minecraft:orange_terracotta
setblock 324 298 257 minecraft:gray_concrete
setblock 324 298 258 minecraft:light_gray_concrete
fill 324 298 259 324 300 259 minecraft:gray_concrete
fill 324 298 261 324 300 261 minecraft:gray_concrete
setblock 324 298 262 minecraft:light_gray_concrete
fill 324 298 263 324 301 263 minecraft:gray_concrete
setblock 324 298 267 minecraft:light_gray_terracotta
setblock 282 299 237 minecraft:orange_terracotta
fill 282 299 238 282 300 238 minecraft:gray_concrete
setblock 282 299 245 minecraft:light_gray_concrete
setblock 282 299 249 minecraft:light_gray_concrete
fill 282 299 253 282 300 253 minecraft:gray_concrete
setblock 282 299 254 minecraft:light_gray_concrete
fill 282 299 255 282 300 257 minecraft:gray_concrete
setblock 282 299 259 minecraft:light_gray_concrete
fill 282 299 261 282 299 262 minecraft:light_gray_concrete
fill 282 299 266 282 300 266 minecraft:gray_concrete
setblock 283 299 228 minecraft:light_gray_concrete
fill 283 299 233 283 299 235 minecraft:gray_wool
setblock 285 299 231 minecraft:gray_wool
fill 285 299 247 285 299 248 minecraft:orange_concrete
setblock 286 299 246 minecraft:orange_concrete
fill 287 299 232 287 300 232 minecraft:gray_wool
fill 287 299 270 287 300 270 minecraft:gray_concrete
setblock 288 299 233 minecraft:gray_wool
setblock 288 299 270 minecraft:light_gray_concrete
fill 289 299 228 289 300 228 minecraft:gray_concrete
setblock 289 299 246 minecraft:orange_concrete
setblock 289 299 250 minecraft:orange_concrete
setblock 290 299 228 minecraft:orange_terracotta
fill 290 299 231 290 300 231 minecraft:light_gray_wool
fill 290 299 270 290 300 270 minecraft:gray_concrete
fill 291 299 228 291 300 228 minecraft:gray_concrete
fill 291 299 229 291 300 230 minecraft:light_gray_wool
fill 291 299 232 291 301 232 minecraft:light_gray_wool
setblock 292 299 228 minecraft:light_gray_concrete
fill 292 299 229 292 300 229 minecraft:light_gray_wool
fill 293 299 228 295 300 228 minecraft:gray_concrete
fill 293 299 230 293 301 230 minecraft:light_gray_wool
setblock 293 299 270 minecraft:light_gray_concrete
fill 294 299 270 294 300 270 minecraft:gray_concrete
setblock 295 299 270 minecraft:light_gray_concrete
fill 296 299 270 296 300 270 minecraft:gray_concrete
fill 297 299 228 297 300 228 minecraft:gray_concrete
fill 299 299 228 299 302 228 minecraft:gray_concrete
fill 300 299 266 302 303 267 minecraft:gray_wool
fill 301 299 268 301 303 269 minecraft:gray_wool
fill 302 299 228 302 300 228 minecraft:gray_concrete
setblock 304 299 228 minecraft:light_gray_concrete
fill 304 299 270 304 300 270 minecraft:gray_concrete
fill 305 299 228 306 300 228 minecraft:gray_concrete
fill 305 299 229 305 300 230 minecraft:gray_wool
fill 305 299 233 308 299 233 minecraft:gray_wool
setblock 305 299 270 minecraft:light_gray_concrete
fill 308 299 228 308 300 228 minecraft:gray_concrete
fill 308 299 229 308 300 229 minecraft:gray_wool
setblock 309 299 228 minecraft:orange_terracotta
fill 309 299 230 309 300 230 minecraft:gray_wool
fill 309 299 232 309 300 232 minecraft:gray_wool
fill 309 299 237 311 299 237 minecraft:orange_concrete
setblock 309 299 242 minecraft:orange_concrete
fill 310 299 228 313 300 228 minecraft:gray_concrete
fill 311 299 242 312 299 242 minecraft:orange_concrete
fill 311 299 270 312 300 270 minecraft:gray_concrete
fill 313 299 239 313 299 241 minecraft:orange_concrete
fill 313 299 270 314 299 270 minecraft:light_gray_concrete
fill 314 299 228 315 299 228 minecraft:light_gray_concrete
fill 315 299 270 315 300 270 minecraft:gray_concrete
fill 316 299 228 316 300 228 minecraft:gray_concrete
fill 317 299 270 317 300 270 minecraft:gray_concrete
setblock 318 299 270 minecraft:orange_terracotta
fill 319 299 228 319 300 228 minecraft:gray_concrete
setblock 324 299 233 minecraft:light_gray_concrete
fill 324 299 234 324 301 234 minecraft:gray_concrete
fill 324 299 238 324 299 239 minecraft:gray_concrete
fill 324 299 242 324 300 242 minecraft:gray_concrete
setblock 324 299 243 minecraft:light_gray_concrete
fill 324 299 246 324 299 247 minecraft:gray_concrete
setblock 324 299 250 minecraft:light_gray_concrete
fill 324 299 251 324 299 252 minecraft:gray_terracotta
fill 324 299 256 324 300 256 minecraft:gray_concrete
setblock 324 299 257 minecraft:light_gray_concrete
fill 324 299 258 324 300 258 minecraft:gray_concrete
fill 324 299 262 324 300 262 minecraft:gray_concrete
setblock 324 299 264 minecraft:light_gray_concrete
fill 324 299 267 324 300 267 minecraft:gray_concrete
fill 282 300 228 283 300 228 minecraft:gray_concrete
setblock 282 300 237 minecraft:gray_concrete
setblock 282 300 245 minecraft:gray_concrete
setblock 282 300 247 minecraft:light_gray_terracotta
fill 282 300 249 282 300 250 minecraft:gray_concrete
setblock 282 300 251 minecraft:orange_terracotta
setblock 282 300 252 minecraft:gray_concrete
setblock 282 300 254 minecraft:gray_concrete
setblock 282 300 259 minecraft:gray_terracotta
setblock 282 300 261 minecraft:gray_concrete
setblock 282 300 262 minecraft:light_gray_terracotta
setblock 282 300 265 minecraft:light_gray_terracotta
setblock 283 300 234 minecraft:gray_wool
setblock 283 300 270 minecraft:orange_terracotta
fill 284 300 236 285 300 236 minecraft:gray_wool
setblock 284 300 270 minecraft:gray_concrete
fill 288 300 270 288 301 270 minecraft:gray_concrete
setblock 290 300 228 minecraft:gray_concrete
setblock 292 300 228 minecraft:gray_concrete
setblock 293 300 229 minecraft:light_gray_wool
setblock 293 300 270 minecraft:gray_concrete
setblock 295 300 270 minecraft:gray_concrete
fill 299 300 266 299 303 268 minecraft:gray_wool
setblock 300 300 228 minecraft:gray_concrete
fill 300 300 265 302 303 265 minecraft:gray_wool
fill 300 300 268 300 303 269 minecraft:gray_wool
setblock 301 300 228 minecraft:light_gray_terracotta
fill 302 300 268 302 303 269 minecraft:gray_wool
setblock 303 300 228 minecraft:gray_terracotta
fill 303 300 266 303 303 268 minecraft:gray_wool
setblock 304 300 228 minecraft:gray_concrete
setblock 305 300 270 minecraft:gray_concrete
fill 306 300 233 308 300 233 minecraft:gray_wool
setblock 309 300 228 minecraft:gray_concrete
setblock 313 300 270 minecraft:gray_terracotta
fill 314 300 228 315 300 228 minecraft:gray_concrete
setblock 314 300 270 minecraft:gray_concrete
setblock 318 300 270 minecraft:gray_concrete
setblock 324 300 233 minecraft:gray_concrete
setblock 324 300 238 minecraft:gray_concrete
setblock 324 300 239 minecraft:light_gray_terracotta
fill 324 300 243 324 300 244 minecraft:gray_concrete
setblock 324 300 246 minecraft:gray_concrete
setblock 324 300 247 minecraft:light_gray_terracotta
fill 324 300 250 324 300 252 minecraft:gray_concrete
setblock 324 300 257 minecraft:gray_concrete
setblock 324 300 264 minecraft:gray_concrete
setblock 324 300 268 minecraft:light_gray_terracotta
fill 324 300 269 324 300 270 minecraft:gray_concrete
fill 282 301 228 282 308 229 minecraft:light_gray_concrete
setblock 282 301 230 minecraft:gray_concrete
fill 282 301 231 282 301 238 minecraft:light_gray_concrete
fill 282 301 240 282 301 249 minecraft:light_gray_concrete
setblock 282 301 250 minecraft:orange_terracotta
setblock 282 301 251 minecraft:gray_concrete
fill 282 301 252 282 301 270 minecraft:light_gray_concrete
fill 283 301 228 298 301 228 minecraft:light_gray_concrete
fill 283 301 270 287 302 270 minecraft:light_gray_concrete
fill 284 301 233 285 301 235 minecraft:gray_wool
fill 286 301 234 286 301 235 minecraft:gray_wool
fill 289 301 270 299 301 270 minecraft:light_gray_concrete
setblock 291 301 230 minecraft:light_gray_wool
setblock 292 301 232 minecraft:light_gray_wool
fill 299 301 265 299 302 265 minecraft:gray_wool
fill 299 301 269 299 302 269 minecraft:gray_wool
fill 300 301 228 314 301 228 minecraft:light_gray_concrete
fill 300 301 264 300 302 264 minecraft:gray_wool
setblock 300 301 270 minecraft:gray_wool
fill 301 301 270 306 301 270 minecraft:light_gray_concrete
fill 304 301 267 304 302 267 minecraft:gray_wool
setblock 305 301 230 minecraft:gray_wool
fill 307 301 233 308 301 233 minecraft:gray_wool
setblock 307 301 270 minecraft:gray_concrete
fill 308 301 270 313 307 270 minecraft:light_gray_concrete
setblock 314 301 270 minecraft:light_gray_terracotta
setblock 315 301 228 minecraft:gray_concrete
fill 315 301 270 319 301 270 minecraft:light_gray_concrete
fill 316 301 228 316 308 228 minecraft:light_gray_concrete
fill 318 301 228 324 301 228 minecraft:light_gray_concrete
setblock 320 301 270 minecraft:orange_terracotta
setblock 321 301 270 minecraft:gray_concrete
setblock 323 301 270 minecraft:orange_terracotta
fill 324 301 229 324 301 233 minecraft:light_gray_concrete
fill 324 301 235 324 302 239 minecraft:light_gray_concrete
fill 324 301 241 324 301 258 minecraft:light_gray_concrete
setblock 324 301 259 minecraft:gray_terracotta
fill 324 301 260 324 305 262 minecraft:light_gray_concrete
fill 324 301 264 324 301 270 minecraft:light_gray_concrete
fill 282 302 230 282 303 231 minecraft:light_gray_concrete
setblock 282 302 232 minecraft:gray_concrete
fill 282 302 233 282 307 233 minecraft:light_gray_concrete
setblock 282 302 234 minecraft:gray_concrete
fill 282 302 235 282 302 239 minecraft:light_gray_concrete
setblock 282 302 240 minecraft:gray_concrete
fill 282 302 241 282 303 241 minecraft:light_gray_concrete
setblock 282 302 242 minecraft:gray_concrete
fill 282 302 243 282 302 265 minecraft:light_gray_concrete
setblock 282 302 266 minecraft:gray_concrete
fill 282 302 267 282 302 270 minecraft:light_gray_concrete
fill 283 302 228 297 302 228 minecraft:light_gray_concrete
fill 285 302 231 285 303 231 minecraft:light[level=12]
setblock 285 302 239 minecraft:light[level=12]
setblock 285 302 247 minecraft:light[level=12]
setblock 285 302 255 minecraft:light[level=12]
setblock 285 302 263 minecraft:light[level=12]
fill 288 302 270 290 302 270 minecraft:light_gray_concrete
setblock 291 302 270 minecraft:orange_terracotta
fill 292 302 270 293 302 270 minecraft:gray_concrete
setblock 293 302 231 minecraft:light[level=12]
setblock 293 302 239 minecraft:light[level=12]
setblock 293 302 247 minecraft:light[level=12]
setblock 293 302 255 minecraft:light[level=12]
setblock 293 302 263 minecraft:light[level=12]
fill 294 302 270 297 302 270 minecraft:light_gray_concrete
setblock 298 302 228 minecraft:orange_terracotta
setblock 298 302 270 minecraft:light_gray_terracotta
fill 299 302 270 300 308 270 minecraft:light_gray_concrete
fill 300 302 228 306 302 228 minecraft:light_gray_concrete
setblock 301 302 231 minecraft:light[level=12]
setblock 301 302 239 minecraft:light[level=12]
setblock 301 302 247 minecraft:light[level=12]
setblock 301 302 255 minecraft:light[level=12]
setblock 301 302 263 minecraft:light[level=12]
setblock 301 302 270 minecraft:gray_concrete
fill 302 302 270 307 306 270 minecraft:light_gray_concrete
setblock 303 302 269 minecraft:gray_wool
setblock 304 302 268 minecraft:gray_wool
setblock 307 302 228 minecraft:gray_concrete
setblock 307 302 231 minecraft:gray_wool
fill 308 302 228 315 302 228 minecraft:light_gray_concrete
setblock 309 302 231 minecraft:light[level=12]
setblock 309 302 239 minecraft:light[level=12]
setblock 309 302 247 minecraft:light[level=12]
setblock 309 302 255 minecraft:light[level=12]
setblock 309 302 263 minecraft:light[level=12]
fill 314 302 270 314 308 270 minecraft:light_gray_concrete
setblock 315 302 270 minecraft:orange_terracotta
fill 316 302 270 321 303 270 minecraft:light_gray_concrete
fill 317 302 228 319 302 228 minecraft:light_gray_concrete
setblock 317 302 231 minecraft:light[level=12]
setblock 317 302 239 minecraft:light[level=12]
setblock 317 302 247 minecraft:light[level=12]
setblock 317 302 255 minecraft:light[level=12]
setblock 317 302 263 minecraft:light[level=12]
setblock 320 302 228 minecraft:light_gray_terracotta
fill 321 302 228 324 308 228 minecraft:light_gray_concrete
fill 323 302 270 324 305 270 minecraft:light_gray_concrete
fill 324 302 229 324 308 229 minecraft:light_gray_concrete
setblock 324 302 230 minecraft:gray_concrete
fill 324 302 231 324 308 231 minecraft:light_gray_concrete
setblock 324 302 232 minecraft:gray_concrete
fill 324 302 233 324 302 234 minecraft:light_gray_concrete
setblock 324 302 240 minecraft:orange_terracotta
fill 324 302 241 324 308 241 minecraft:light_gray_concrete
setblock 324 302 242 minecraft:gray_concrete
fill 324 302 243 324 303 245 minecraft:light_gray_concrete
setblock 324 302 246 minecraft:gray_terracotta
fill 324 302 247 324 302 259 minecraft:light_gray_concrete
fill 324 302 263 324 308 263 minecraft:light_gray_concrete
setblock 324 302 264 minecraft:gray_concrete
fill 324 302 265 324 308 265 minecraft:light_gray_concrete
setblock 324 302 266 minecraft:gray_concrete
fill 324 302 267 324 305 269 minecraft:light_gray_concrete
fill 282 303 232 282 306 232 minecraft:light_gray_concrete
fill 282 303 234 282 308 234 minecraft:light_gray_concrete
fill 282 303 235 282 303 236 minecraft:gray_concrete
fill 282 303 237 282 305 240 minecraft:light_gray_concrete
fill 282 303 242 282 308 243 minecraft:light_gray_concrete
setblock 282 303 244 minecraft:gray_concrete
fill 282 303 245 282 303 265 minecraft:light_gray_concrete
setblock 282 303 266 minecraft:gray_terracotta
fill 282 303 267 282 308 268 minecraft:light_gray_concrete
fill 282 303 269 282 303 270 minecraft:gray_concrete
fill 283 303 228 283 306 228 minecraft:light_gray_concrete
fill 283 303 270 284 308 270 minecraft:light_gray_concrete
fill 284 303 228 285 303 228 minecraft:gray_concrete
setblock 285 303 238 minecraft:light[level=12]
setblock 285 303 245 minecraft:light[level=12]
setblock 285 303 252 minecraft:light[level=12]
setblock 285 303 259 minecraft:light[level=12]
setblock 285 303 266 minecraft:light[level=12]
setblock 285 303 270 minecraft:gray_concrete
fill 286 303 228 286 308 228 minecraft:light_gray_concrete
fill 286 303 270 289 308 270 minecraft:light_gray_concrete
setblock 287 303 228 minecraft:gray_concrete
fill 288 303 228 300 308 228 minecraft:light_gray_concrete
setblock 290 303 270 minecraft:gray_concrete
fill 291 303 270 291 308 270 minecraft:light_gray_concrete
setblock 292 303 231 minecraft:light[level=12]
setblock 292 303 238 minecraft:light[level=12]
setblock 292 303 245 minecraft:light[level=12]
setblock 292 303 252 minecraft:light[level=12]
setblock 292 303 259 minecraft:light[level=12]
setblock 292 303 266 minecraft:light[level=12]
setblock 292 303 270 minecraft:light_gray_terracotta
fill 293 303 270 294 308 270 minecraft:light_gray_concrete
setblock 295 303 270 minecraft:gray_concrete
fill 296 303 270 298 306 270 minecraft:light_gray_concrete
setblock 299 303 231 minecraft:light[level=12]
setblock 299 303 238 minecraft:light[level=12]
setblock 299 303 245 minecraft:light[level=12]
setblock 299 303 252 minecraft:light[level=12]
setblock 299 303 259 minecraft:light[level=12]
setblock 301 303 228 minecraft:gray_concrete
fill 301 303 270 301 306 270 minecraft:light_gray_concrete
fill 302 303 228 305 308 228 minecraft:light_gray_concrete
setblock 306 303 228 minecraft:gray_concrete
setblock 306 303 231 minecraft:light[level=12]
setblock 306 303 238 minecraft:light[level=12]
setblock 306 303 245 minecraft:light[level=12]
setblock 306 303 252 minecraft:light[level=12]
setblock 306 303 259 minecraft:light[level=12]
setblock 306 303 266 minecraft:light[level=12]
fill 307 303 228 307 308 228 minecraft:light_gray_concrete
setblock 308 303 228 minecraft:gray_concrete
fill 309 303 228 310 304 228 minecraft:light_gray_concrete
setblock 311 303 228 minecraft:gray_concrete
fill 312 303 228 315 306 228 minecraft:light_gray_concrete
setblock 313 303 231 minecraft:light[level=12]
setblock 313 303 238 minecraft:light[level=12]
setblock 313 303 245 minecraft:light[level=12]
setblock 313 303 252 minecraft:light[level=12]
setblock 313 303 259 minecraft:light[level=12]
setblock 313 303 266 minecraft:light[level=12]
fill 315 303 270 315 308 270 minecraft:light_gray_concrete
setblock 317 303 228 minecraft:gray_concrete
fill 318 303 228 320 307 228 minecraft:light_gray_concrete
setblock 320 303 231 minecraft:light[level=12]
setblock 320 303 238 minecraft:light[level=12]
setblock 320 303 245 minecraft:light[level=12]
setblock 320 303 252 minecraft:light[level=12]
setblock 320 303 259 minecraft:light[level=12]
setblock 320 303 266 minecraft:light[level=12]
fill 322 303 270 322 308 270 minecraft:light_gray_concrete
setblock 324 303 230 minecraft:orange_terracotta
fill 324 303 232 324 308 232 minecraft:light_gray_concrete
setblock 324 303 233 minecraft:gray_terracotta
fill 324 303 234 324 308 237 minecraft:light_gray_concrete
fill 324 303 238 324 303 239 minecraft:gray_concrete
fill 324 303 240 324 308 240 minecraft:light_gray_concrete
fill 324 303 242 324 308 242 minecraft:light_gray_concrete
fill 324 303 246 324 308 247 minecraft:light_gray_concrete
setblock 324 303 248 minecraft:orange_terracotta
fill 324 303 249 324 303 257 minecraft:light_gray_concrete
fill 324 303 258 324 303 259 minecraft:light_gray_terracotta
fill 324 303 264 324 308 264 minecraft:light_gray_concrete
setblock 324 303 266 minecraft:light_gray_concrete
fill 282 304 230 282 305 230 minecraft:light_gray_terracotta
fill 282 304 231 282 308 231 minecraft:light_gray_concrete
fill 282 304 235 282 307 236 minecraft:light_gray_concrete
setblock 282 304 241 minecraft:orange_terracotta
fill 282 304 244 282 305 257 minecraft:light_gray_concrete
setblock 282 304 258 minecraft:gray_terracotta
fill 282 304 259 282 305 266 minecraft:light_gray_concrete
fill 282 304 269 282 308 270 minecraft:light_gray_concrete
fill 284 304 228 285 308 228 minecraft:light_gray_concrete
fill 285 304 270 285 308 270 minecraft:light_gray_concrete
fill 287 304 228 287 308 228 minecraft:light_gray_concrete
fill 290 304 270 290 308 270 minecraft:light_gray_concrete
fill 292 304 270 292 308 270 minecraft:light_gray_concrete
setblock 295 304 270 minecraft:light_gray_terracotta
fill 301 304 228 301 308 228 minecraft:light_gray_concrete
fill 306 304 228 306 308 228 minecraft:light_gray_concrete
fill 308 304 228 308 305 228 minecraft:light_gray_concrete
fill 311 304 228 311 308 228 minecraft:light_gray_concrete
fill 316 304 270 316 308 270 minecraft:light_gray_concrete
fill 317 304 228 317 308 228 minecraft:light_gray_concrete
setblock 317 304 270 minecraft:gray_terracotta
fill 318 304 270 319 308 270 minecraft:light_gray_concrete
setblock 320 304 270 minecraft:gray_terracotta
fill 321 304 270 321 305 270 minecraft:light_gray_concrete
fill 324 304 230 324 308 230 minecraft:light_gray_concrete
fill 324 304 233 324 308 233 minecraft:light_gray_concrete
fill 324 304 238 324 308 239 minecraft:light_gray_concrete
fill 324 304 243 324 305 244 minecraft:light_gray_concrete
setblock 324 304 245 minecraft:gray_terracotta
fill 324 304 248 324 304 254 minecraft:light_gray_concrete
setblock 324 304 255 minecraft:orange_terracotta
fill 324 304 256 324 307 259 minecraft:light_gray_concrete
setblock 324 304 266 minecraft:gray_terracotta
fill 282 305 241 282 308 241 minecraft:light_gray_concrete
fill 282 305 258 282 308 258 minecraft:light_gray_concrete
fill 295 305 270 295 308 270 minecraft:light_gray_concrete
setblock 309 305 228 minecraft:gray_terracotta
fill 310 305 228 310 308 228 minecraft:light_gray_concrete
fill 317 305 270 317 308 270 minecraft:light_gray_concrete
fill 320 305 270 320 308 270 minecraft:light_gray_concrete
fill 324 305 245 324 308 245 minecraft:light_gray_concrete
fill 324 305 248 324 307 251 minecraft:light_gray_concrete
setblock 324 305 252 minecraft:light_gray_terracotta
fill 324 305 253 324 308 255 minecraft:light_gray_concrete
setblock 324 305 266 minecraft:light_gray_concrete
fill 282 306 230 282 308 230 minecraft:light_gray_concrete
setblock 282 306 237 minecraft:orange_terracotta
fill 282 306 238 282 308 240 minecraft:light_gray_concrete
fill 282 306 244 282 307 252 minecraft:light_gray_concrete
setblock 282 306 253 minecraft:orange_terracotta
fill 282 306 254 282 307 257 minecraft:light_gray_concrete
fill 282 306 259 282 308 261 minecraft:light_gray_concrete
setblock 282 306 262 minecraft:gray_terracotta
fill 282 306 263 282 308 263 minecraft:light_gray_concrete
setblock 282 306 264 minecraft:light_gray_terracotta
fill 282 306 265 282 308 266 minecraft:light_gray_concrete
setblock 308 306 228 minecraft:gray_terracotta
fill 309 306 228 309 308 228 minecraft:light_gray_concrete
setblock 321 306 270 minecraft:gray_terracotta
setblock 323 306 270 minecraft:gray_terracotta
fill 324 306 243 324 308 243 minecraft:light_gray_concrete
setblock 324 306 244 minecraft:orange_terracotta
fill 324 306 252 324 308 252 minecraft:light_gray_concrete
fill 324 306 260 324 308 261 minecraft:light_gray_concrete
setblock 324 306 262 minecraft:light_gray_terracotta
setblock 324 306 266 minecraft:gray_terracotta
fill 324 306 267 324 308 268 minecraft:light_gray_concrete
setblock 324 306 269 minecraft:light_gray_terracotta
fill 324 306 270 324 308 270 minecraft:light_gray_concrete
setblock 282 307 232 minecraft:orange_terracotta
fill 282 307 237 282 308 237 minecraft:light_gray_concrete
fill 282 307 253 282 308 253 minecraft:light_gray_concrete
fill 282 307 262 282 308 262 minecraft:light_gray_concrete
fill 282 307 264 282 308 264 minecraft:light_gray_concrete
setblock 283 307 228 minecraft:gray_terracotta
fill 296 307 270 296 308 270 minecraft:light_gray_concrete
setblock 297 307 270 minecraft:orange_terracotta
setblock 298 307 270 minecraft:light_gray_concrete
setblock 301 307 270 minecraft:light_gray_terracotta
fill 302 307 270 302 308 270 minecraft:light_gray_concrete
setblock 303 307 270 minecraft:orange_terracotta
fill 304 307 270 304 308 270 minecraft:light_gray_concrete
setblock 305 307 270 minecraft:light_gray_terracotta
fill 306 307 270 307 308 270 minecraft:light_gray_concrete
fill 308 307 228 308 308 228 minecraft:light_gray_concrete
fill 312 307 228 314 308 228 minecraft:light_gray_concrete
setblock 315 307 228 minecraft:gray_terracotta
fill 321 307 270 321 308 270 minecraft:light_gray_concrete
fill 323 307 270 323 308 270 minecraft:light_gray_concrete
fill 324 307 244 324 308 244 minecraft:light_gray_concrete
fill 324 307 262 324 308 262 minecraft:light_gray_concrete
fill 324 307 266 324 308 266 minecraft:light_gray_concrete
fill 324 307 269 324 308 269 minecraft:light_gray_concrete
setblock 282 308 232 minecraft:light_gray_concrete
setblock 282 308 233 minecraft:orange_terracotta
setblock 282 308 235 minecraft:light_gray_concrete
setblock 282 308 236 minecraft:light_gray_terracotta
fill 282 308 244 282 308 247 minecraft:light_gray_concrete
setblock 282 308 248 minecraft:gray_terracotta
fill 282 308 249 282 308 252 minecraft:light_gray_concrete
setblock 282 308 254 minecraft:gray_terracotta
setblock 282 308 255 minecraft:orange_terracotta
fill 282 308 256 282 308 257 minecraft:light_gray_concrete
setblock 283 308 228 minecraft:light_gray_concrete
setblock 297 308 270 minecraft:light_gray_concrete
setblock 298 308 270 minecraft:light_gray_terracotta
setblock 301 308 270 minecraft:light_gray_concrete
setblock 303 308 270 minecraft:light_gray_concrete
setblock 305 308 270 minecraft:light_gray_concrete
fill 308 308 270 311 308 270 minecraft:light_gray_concrete
setblock 312 308 270 minecraft:orange_terracotta
setblock 313 308 270 minecraft:light_gray_concrete
setblock 315 308 228 minecraft:light_gray_concrete
setblock 318 308 228 minecraft:gray_terracotta
fill 319 308 228 320 308 228 minecraft:light_gray_concrete
setblock 324 308 248 minecraft:light_gray_terracotta
setblock 324 308 249 minecraft:light_gray_concrete
setblock 324 308 250 minecraft:gray_terracotta
setblock 324 308 251 minecraft:light_gray_terracotta
setblock 324 308 256 minecraft:light_gray_concrete
setblock 324 308 257 minecraft:light_gray_terracotta
fill 324 308 258 324 308 259 minecraft:light_gray_concrete
