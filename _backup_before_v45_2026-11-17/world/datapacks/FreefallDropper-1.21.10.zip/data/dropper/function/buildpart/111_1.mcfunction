fill 156 108 475 156 112 476 minecraft:purpur_block
fill 164 108 463 164 170 463 minecraft:end_stone_bricks
setblock 165 108 463 minecraft:white_concrete
setblock 177 108 499 minecraft:magenta_stained_glass
setblock 178 108 497 minecraft:magenta_stained_glass
setblock 179 108 499 minecraft:magenta_stained_glass
fill 141 109 471 141 110 471 minecraft:magenta_concrete
fill 141 109 487 141 110 487 minecraft:magenta_concrete
fill 141 109 503 141 110 503 minecraft:magenta_concrete
fill 145 109 463 145 110 463 minecraft:magenta_concrete
fill 152 109 475 152 112 476 minecraft:purpur_block
fill 153 109 477 153 112 477 minecraft:purpur_block
fill 155 109 505 155 110 505 minecraft:magenta_concrete
fill 156 109 474 156 112 474 minecraft:purpur_block
fill 156 109 477 156 112 477 minecraft:purpur_block
fill 161 109 463 161 110 463 minecraft:magenta_concrete
fill 162 109 505 163 130 505 minecraft:end_stone_bricks
setblock 164 109 505 minecraft:pearlescent_froglight
fill 165 109 463 165 123 463 minecraft:end_stone_bricks
fill 165 109 505 165 137 505 minecraft:end_stone_bricks
fill 171 109 505 171 110 505 minecraft:magenta_concrete
fill 177 109 463 177 110 463 minecraft:magenta_concrete
fill 178 109 486 179 110 487 minecraft:obsidian
fill 183 109 473 183 110 473 minecraft:magenta_concrete
fill 183 109 489 183 110 489 minecraft:magenta_concrete
setblock 141 110 491 minecraft:pearlescent_froglight
fill 141 110 492 141 125 493 minecraft:end_stone_bricks
fill 141 110 497 141 153 497 minecraft:end_stone_bricks
setblock 141 110 498 minecraft:white_concrete
fill 152 110 474 152 112 474 minecraft:purpur_block
fill 152 110 477 152 112 477 minecraft:purpur_block
fill 153 110 473 155 112 473 minecraft:purpur_block
fill 153 110 478 155 112 478 minecraft:purpur_block
fill 153 110 489 154 111 490 minecraft:end_stone
fill 157 110 475 157 112 476 minecraft:purpur_block
fill 164 110 505 164 143 505 minecraft:end_stone_bricks
setblock 182 110 463 minecraft:pearlescent_froglight
setblock 183 110 478 minecraft:magenta_stained_glass
fill 141 111 471 141 117 471 minecraft:end_stone_bricks
fill 141 111 487 141 117 487 minecraft:end_stone_bricks
fill 141 111 491 141 192 491 minecraft:end_stone_bricks
fill 141 111 498 141 121 498 minecraft:end_stone_bricks
fill 141 111 503 141 117 503 minecraft:end_stone_bricks
fill 145 111 463 145 117 463 minecraft:end_stone_bricks
fill 151 111 475 151 112 476 minecraft:purpur_block
fill 152 111 473 152 112 473 minecraft:purpur_block
fill 155 111 505 155 117 505 minecraft:end_stone_bricks
fill 156 111 473 156 112 473 minecraft:purpur_block
fill 156 111 478 156 112 478 minecraft:purpur_block
fill 157 111 474 157 112 474 minecraft:purpur_block
fill 157 111 477 157 112 477 minecraft:purpur_block
fill 161 111 463 161 117 463 minecraft:end_stone_bricks
fill 171 111 505 171 117 505 minecraft:end_stone_bricks
fill 177 111 463 177 117 463 minecraft:end_stone_bricks
fill 180 111 501 182 114 501 minecraft:magenta_stained_glass
fill 181 111 500 181 114 500 minecraft:magenta_stained_glass
fill 181 111 502 181 114 502 minecraft:magenta_stained_glass
fill 182 111 463 182 194 463 minecraft:end_stone_bricks
fill 183 111 473 183 117 473 minecraft:end_stone_bricks
fill 183 111 478 183 113 478 minecraft:end_stone_bricks
fill 183 111 489 183 117 489 minecraft:end_stone_bricks
setblock 151 112 474 minecraft:purpur_block
setblock 151 112 477 minecraft:purpur_block
setblock 152 112 478 minecraft:purpur_block
fill 153 112 472 155 112 472 minecraft:purpur_block
fill 153 112 479 155 112 479 minecraft:purpur_block
setblock 157 112 473 minecraft:purpur_block
setblock 157 112 478 minecraft:purpur_block
fill 158 112 475 158 112 476 minecraft:purpur_block
fill 174 112 501 179 112 501 minecraft:magenta_stained_glass
fill 177 112 500 180 112 500 minecraft:magenta_stained_glass
fill 177 112 502 180 112 502 minecraft:magenta_stained_glass
fill 182 112 500 182 113 500 minecraft:magenta_stained_glass
fill 182 112 502 182 113 502 minecraft:magenta_stained_glass
setblock 183 112 470 minecraft:pearlescent_froglight
setblock 144 113 466 minecraft:light[level=14]
setblock 144 113 474 minecraft:light[level=14]
setblock 144 113 482 minecraft:light[level=14]
setblock 144 113 490 minecraft:light[level=14]
setblock 144 113 498 minecraft:light[level=14]
fill 149 113 463 149 123 463 minecraft:end_stone_bricks
setblock 150 113 463 minecraft:pearlescent_froglight
setblock 152 113 466 minecraft:light[level=14]
setblock 152 113 474 minecraft:light[level=14]
setblock 152 113 482 minecraft:light[level=14]
setblock 152 113 490 minecraft:light[level=14]
setblock 152 113 498 minecraft:light[level=14]
fill 153 113 474 153 116 474 minecraft:end_stone_bricks
fill 154 113 477 154 114 477 minecraft:end_stone_bricks
fill 156 113 475 156 116 475 minecraft:end_stone_bricks
setblock 160 113 466 minecraft:light[level=14]
setblock 160 113 474 minecraft:light[level=14]
setblock 160 113 482 minecraft:light[level=14]
setblock 160 113 490 minecraft:light[level=14]
setblock 160 113 498 minecraft:light[level=14]
setblock 168 113 466 minecraft:light[level=14]
setblock 168 113 474 minecraft:light[level=14]
setblock 168 113 482 minecraft:light[level=14]
setblock 168 113 490 minecraft:light[level=14]
setblock 168 113 498 minecraft:light[level=14]
setblock 176 113 466 minecraft:light[level=14]
setblock 176 113 474 minecraft:light[level=14]
setblock 176 113 482 minecraft:light[level=14]
setblock 176 113 490 minecraft:light[level=14]
setblock 176 113 498 minecraft:light[level=14]
fill 176 113 501 179 113 501 minecraft:magenta_stained_glass
fill 178 113 500 180 113 500 minecraft:magenta_stained_glass
fill 178 113 502 180 113 502 minecraft:magenta_stained_glass
fill 178 113 505 179 133 505 minecraft:end_stone_bricks
setblock 180 113 505 minecraft:pearlescent_froglight
fill 181 113 505 181 170 505 minecraft:end_stone_bricks
fill 183 113 470 183 143 470 minecraft:end_stone_bricks
setblock 183 113 500 minecraft:magenta_stained_glass
fill 150 114 463 150 192 463 minecraft:end_stone_bricks
setblock 151 114 463 minecraft:white_concrete
fill 156 114 463 157 143 463 minecraft:end_stone_bricks
setblock 158 114 463 minecraft:white_concrete
setblock 171 114 463 minecraft:white_concrete
fill 180 114 505 180 197 505 minecraft:end_stone_bricks
fill 183 114 474 183 130 474 minecraft:end_stone_bricks
setblock 183 114 475 minecraft:pearlescent_froglight
setblock 183 114 478 minecraft:magenta_stained_glass
fill 183 114 497 183 173 498 minecraft:end_stone_bricks
setblock 183 114 499 minecraft:pearlescent_froglight
fill 183 114 500 183 171 500 minecraft:end_stone_bricks
fill 151 115 463 151 137 463 minecraft:end_stone_bricks
fill 158 115 463 158 134 463 minecraft:end_stone_bricks
fill 167 115 505 167 196 505 minecraft:end_stone_bricks
setblock 168 115 505 minecraft:white_concrete
fill 171 115 463 171 131 463 minecraft:end_stone_bricks
fill 183 115 475 183 153 475 minecraft:end_stone_bricks
fill 183 115 478 183 197 478 minecraft:end_stone_bricks
fill 183 115 499 183 151 499 minecraft:end_stone_bricks
fill 156 116 505 159 121 505 minecraft:end_stone_bricks
setblock 160 116 505 minecraft:pearlescent_froglight
fill 168 116 505 168 148 505 minecraft:end_stone_bricks
setblock 183 116 468 minecraft:pearlescent_froglight
fill 160 117 505 160 192 505 minecraft:end_stone_bricks
setblock 174 117 505 minecraft:magenta_stained_glass
fill 175 117 505 176 128 505 minecraft:end_stone_bricks
fill 183 117 468 183 139 468 minecraft:end_stone_bricks
setblock 183 117 482 minecraft:pearlescent_froglight
fill 183 117 483 183 119 486 minecraft:end_stone_bricks
fill 141 118 471 141 119 471 minecraft:magenta_concrete
fill 141 118 487 141 119 487 minecraft:magenta_concrete
fill 141 118 503 141 119 503 minecraft:magenta_concrete
fill 145 118 463 145 119 463 minecraft:magenta_concrete
fill 146 118 505 152 134 505 minecraft:end_stone_bricks
setblock 153 118 505 minecraft:magenta_stained_glass
fill 154 118 490 155 119 491 minecraft:purpur_block
fill 154 118 505 154 196 505 minecraft:end_stone_bricks
fill 155 118 505 155 119 505 minecraft:magenta_concrete
fill 156 118 491 156 119 491 minecraft:purpur_block
fill 161 118 463 161 119 463 minecraft:magenta_concrete
fill 171 118 505 171 119 505 minecraft:magenta_concrete
fill 174 118 505 174 170 505 minecraft:end_stone_bricks
fill 177 118 463 177 119 463 minecraft:magenta_concrete
fill 183 118 473 183 119 473 minecraft:magenta_concrete
fill 183 118 482 183 159 482 minecraft:end_stone_bricks
fill 183 118 489 183 119 489 minecraft:magenta_concrete
setblock 141 119 470 minecraft:magenta_stained_glass
fill 153 119 505 153 126 505 minecraft:end_stone_bricks
setblock 176 119 463 minecraft:white_concrete
fill 178 119 463 178 189 463 minecraft:end_stone_bricks
setblock 179 119 463 minecraft:pearlescent_froglight
fill 180 119 463 180 188 463 minecraft:end_stone_bricks
fill 141 120 470 141 126 471 minecraft:end_stone_bricks
fill 141 120 487 141 126 487 minecraft:end_stone_bricks
setblock 141 120 495 minecraft:white_concrete
fill 141 120 503 141 126 503 minecraft:end_stone_bricks
fill 142 120 475 142 125 475 minecraft:magenta_stained_glass
fill 145 120 463 145 126 463 minecraft:end_stone_bricks
fill 155 120 505 155 126 505 minecraft:end_stone_bricks
fill 161 120 463 161 126 463 minecraft:end_stone_bricks
fill 171 120 505 171 126 505 minecraft:end_stone_bricks
fill 176 120 463 177 121 463 minecraft:end_stone_bricks
fill 179 120 463 179 158 463 minecraft:end_stone_bricks
setblock 182 120 505 minecraft:white_concrete
fill 183 120 473 183 126 473 minecraft:end_stone_bricks
fill 183 120 483 183 160 485 minecraft:end_stone_bricks
setblock 183 120 486 minecraft:magenta_stained_glass
fill 183 120 489 183 126 489 minecraft:end_stone_bricks
fill 183 120 505 183 197 505 minecraft:end_stone_bricks
fill 141 121 495 141 131 495 minecraft:end_stone_bricks
fill 142 121 473 142 124 474 minecraft:magenta_stained_glass
fill 142 121 476 142 124 477 minecraft:magenta_stained_glass
fill 143 121 474 143 125 476 minecraft:magenta_stained_glass
setblock 144 121 466 minecraft:light[level=14]
setblock 144 121 474 minecraft:light[level=14]
fill 144 121 475 144 125 475 minecraft:magenta_stained_glass
setblock 144 121 482 minecraft:light[level=14]
setblock 144 121 490 minecraft:light[level=14]
setblock 144 121 498 minecraft:light[level=14]
setblock 152 121 466 minecraft:light[level=14]
setblock 152 121 474 minecraft:light[level=14]
setblock 152 121 482 minecraft:light[level=14]
setblock 152 121 490 minecraft:light[level=14]
setblock 152 121 498 minecraft:light[level=14]
setblock 160 121 466 minecraft:light[level=14]
setblock 160 121 474 minecraft:light[level=14]
setblock 160 121 482 minecraft:light[level=14]
setblock 160 121 490 minecraft:light[level=14]
setblock 160 121 498 minecraft:light[level=14]
setblock 166 121 505 minecraft:pearlescent_froglight
setblock 168 121 466 minecraft:light[level=14]
setblock 168 121 474 minecraft:light[level=14]
setblock 168 121 482 minecraft:light[level=14]
setblock 168 121 490 minecraft:light[level=14]
setblock 168 121 498 minecraft:light[level=14]
fill 174 121 489 174 122 491 minecraft:obsidian
fill 175 121 490 175 122 491 minecraft:obsidian
setblock 176 121 466 minecraft:light[level=14]
setblock 176 121 474 minecraft:light[level=14]
setblock 176 121 482 minecraft:light[level=14]
setblock 176 121 490 minecraft:light[level=14]
setblock 176 121 498 minecraft:light[level=14]
fill 182 121 505 182 136 505 minecraft:end_stone_bricks
fill 183 121 486 183 174 486 minecraft:end_stone_bricks
setblock 141 122 498 minecraft:white_concrete
fill 143 122 473 143 124 473 minecraft:magenta_stained_glass
fill 143 122 477 143 124 477 minecraft:magenta_stained_glass
fill 144 122 474 144 125 474 minecraft:magenta_stained_glass
fill 144 122 476 144 125 476 minecraft:magenta_stained_glass
fill 148 122 485 148 123 485 minecraft:magenta_stained_glass
fill 156 122 505 158 126 505 minecraft:end_stone_bricks
setblock 159 122 505 minecraft:pearlescent_froglight
fill 166 122 505 166 148 505 minecraft:end_stone_bricks
fill 176 122 463 176 126 463 minecraft:end_stone_bricks
setblock 177 122 463 minecraft:magenta_stained_glass
fill 183 122 501 183 142 501 minecraft:end_stone_bricks
setblock 183 122 502 minecraft:magenta_stained_glass
fill 183 122 503 183 154 504 minecraft:end_stone_bricks
fill 141 123 498 141 133 498 minecraft:end_stone_bricks
fill 141 123 500 141 154 500 minecraft:end_stone_bricks
setblock 141 123 501 minecraft:magenta_stained_glass
fill 141 123 502 141 133 502 minecraft:end_stone_bricks
fill 145 123 475 145 126 475 minecraft:magenta_stained_glass
fill 159 123 505 159 174 505 minecraft:end_stone_bricks
fill 177 123 463 177 126 463 minecraft:end_stone_bricks
fill 183 123 502 183 135 502 minecraft:end_stone_bricks
fill 141 124 501 141 194 501 minecraft:end_stone_bricks
setblock 144 124 505 minecraft:white_concrete
fill 145 124 474 145 125 474 minecraft:magenta_stained_glass
fill 145 124 476 145 125 476 minecraft:magenta_stained_glass
fill 148 124 485 149 130 485 minecraft:purpur_block
setblock 149 124 463 minecraft:pearlescent_froglight
setblock 165 124 463 minecraft:white_concrete
setblock 141 125 472 minecraft:magenta_stained_glass
fill 144 125 505 144 134 505 minecraft:end_stone_bricks
fill 146 125 475 146 126 475 minecraft:magenta_stained_glass
fill 149 125 463 149 196 463 minecraft:end_stone_bricks
fill 165 125 463 165 196 463 minecraft:end_stone_bricks
fill 168 125 476 168 126 477 minecraft:purpur_block
fill 141 126 472 141 153 472 minecraft:end_stone_bricks
setblock 141 126 492 minecraft:white_concrete
fill 141 126 493 141 165 493 minecraft:end_stone_bricks
fill 148 126 484 149 130 484 minecraft:purpur_block
fill 148 126 486 149 130 486 minecraft:purpur_block
fill 164 126 472 164 127 472 minecraft:magenta_stained_glass
fill 141 127 470 141 194 470 minecraft:end_stone_bricks
fill 141 127 471 141 128 471 minecraft:magenta_concrete
fill 141 127 487 141 128 487 minecraft:magenta_concrete
fill 141 127 492 141 153 492 minecraft:end_stone_bricks
fill 141 127 503 141 128 503 minecraft:magenta_concrete
fill 145 127 463 145 128 463 minecraft:magenta_concrete
fill 147 127 485 147 130 485 minecraft:purpur_block
fill 150 127 485 150 130 485 minecraft:purpur_block
setblock 153 127 505 minecraft:pearlescent_froglight
fill 155 127 505 155 128 505 minecraft:magenta_concrete
fill 156 127 505 157 136 505 minecraft:end_stone_bricks
setblock 158 127 505 minecraft:pearlescent_froglight
fill 161 127 463 161 128 463 minecraft:magenta_concrete
fill 171 127 505 171 128 505 minecraft:magenta_concrete
setblock 176 127 463 minecraft:magenta_stained_glass
fill 177 127 463 177 128 463 minecraft:magenta_concrete
fill 183 127 473 183 128 473 minecraft:magenta_concrete
fill 183 127 489 183 128 489 minecraft:magenta_concrete
setblock 141 128 486 minecraft:pearlescent_froglight
fill 147 128 484 147 130 484 minecraft:purpur_block
fill 147 128 486 147 130 486 minecraft:purpur_block
fill 148 128 483 149 130 483 minecraft:purpur_block
fill 150 128 484 150 130 484 minecraft:purpur_block
fill 150 128 486 150 130 486 minecraft:purpur_block
fill 153 128 505 153 154 505 minecraft:end_stone_bricks
fill 157 128 502 159 131 504 minecraft:magenta_stained_glass
fill 158 128 505 158 156 505 minecraft:end_stone_bricks
fill 164 128 472 164 137 472 minecraft:purpur_block
fill 176 128 463 176 144 463 minecraft:end_stone_bricks
fill 141 129 471 141 135 471 minecraft:end_stone_bricks
fill 141 129 486 141 135 487 minecraft:end_stone_bricks
fill 141 129 503 141 135 503 minecraft:end_stone_bricks
setblock 141 129 504 minecraft:magenta_stained_glass
fill 141 129 505 141 196 505 minecraft:end_stone_bricks
setblock 144 129 466 minecraft:light[level=14]
setblock 144 129 474 minecraft:light[level=14]
setblock 144 129 482 minecraft:light[level=14]
setblock 144 129 490 minecraft:light[level=14]
setblock 144 129 498 minecraft:light[level=14]
fill 145 129 463 145 130 463 minecraft:end_stone_bricks
fill 146 129 485 146 130 485 minecraft:purpur_block
fill 147 129 483 147 130 483 minecraft:purpur_block
fill 147 129 487 149 130 487 minecraft:purpur_block
fill 150 129 483 150 130 483 minecraft:purpur_block
fill 151 129 485 151 130 485 minecraft:purpur_block
setblock 152 129 466 minecraft:light[level=14]
setblock 152 129 474 minecraft:light[level=14]
setblock 152 129 482 minecraft:light[level=14]
setblock 152 129 490 minecraft:light[level=14]
setblock 152 129 498 minecraft:light[level=14]
fill 155 129 505 155 135 505 minecraft:end_stone_bricks
fill 156 129 503 156 130 503 minecraft:magenta_stained_glass
fill 157 129 501 159 131 501 minecraft:magenta_stained_glass
setblock 160 129 466 minecraft:light[level=14]
setblock 160 129 474 minecraft:light[level=14]
setblock 160 129 482 minecraft:light[level=14]
setblock 160 129 490 minecraft:light[level=14]
setblock 160 129 498 minecraft:light[level=14]
fill 160 129 503 160 130 503 minecraft:magenta_stained_glass
fill 161 129 463 161 135 463 minecraft:end_stone_bricks
fill 163 129 472 163 137 472 minecraft:purpur_block
fill 164 129 473 164 137 473 minecraft:purpur_block
fill 165 129 472 165 137 472 minecraft:purpur_block
setblock 168 129 466 minecraft:light[level=14]
setblock 168 129 474 minecraft:light[level=14]
setblock 168 129 482 minecraft:light[level=14]
setblock 168 129 490 minecraft:light[level=14]
setblock 168 129 498 minecraft:light[level=14]
fill 171 129 505 171 135 505 minecraft:end_stone_bricks
setblock 173 129 505 minecraft:pearlescent_froglight
fill 175 129 505 175 135 505 minecraft:end_stone_bricks
setblock 176 129 466 minecraft:light[level=14]
setblock 176 129 474 minecraft:light[level=14]
setblock 176 129 482 minecraft:light[level=14]
setblock 176 129 490 minecraft:light[level=14]
setblock 176 129 498 minecraft:light[level=14]
setblock 176 129 505 minecraft:white_concrete
fill 177 129 463 177 135 463 minecraft:end_stone_bricks
fill 183 129 473 183 135 473 minecraft:end_stone_bricks
fill 183 129 489 183 135 489 minecraft:end_stone_bricks
setblock 141 130 479 minecraft:magenta_stained_glass
fill 141 130 504 141 193 504 minecraft:end_stone_bricks
setblock 146 130 484 minecraft:purpur_block
setblock 146 130 486 minecraft:purpur_block
fill 148 130 482 149 130 482 minecraft:purpur_block
setblock 150 130 487 minecraft:purpur_block
setblock 151 130 484 minecraft:purpur_block
setblock 151 130 486 minecraft:purpur_block
fill 157 130 500 159 131 500 minecraft:magenta_stained_glass
fill 158 130 499 158 132 499 minecraft:magenta_stained_glass
fill 163 130 473 163 137 473 minecraft:purpur_block
fill 164 130 471 164 137 471 minecraft:purpur_block
fill 165 130 473 165 137 473 minecraft:purpur_block
fill 173 130 505 173 197 505 minecraft:end_stone_bricks
fill 176 130 505 176 133 505 minecraft:end_stone_bricks
fill 141 131 479 141 168 479 minecraft:end_stone_bricks
setblock 145 131 463 minecraft:pearlescent_froglight
fill 147 131 485 147 134 485 minecraft:end_stone_bricks
fill 149 131 483 149 134 483 minecraft:end_stone_bricks
fill 149 131 486 149 133 486 minecraft:end_stone_bricks
setblock 157 131 499 minecraft:magenta_stained_glass
fill 158 131 498 158 132 498 minecraft:magenta_stained_glass
setblock 159 131 499 minecraft:magenta_stained_glass
fill 162 131 472 162 137 472 minecraft:purpur_block
setblock 162 131 505 minecraft:pearlescent_froglight
fill 163 131 471 163 137 471 minecraft:purpur_block
fill 163 131 505 163 144 505 minecraft:end_stone_bricks
fill 164 131 474 164 137 474 minecraft:purpur_block
fill 165 131 471 165 137 471 minecraft:purpur_block
fill 166 131 472 166 137 472 minecraft:purpur_block
setblock 183 131 474 minecraft:magenta_stained_glass
fill 141 132 475 141 133 476 minecraft:end_stone_bricks
setblock 141 132 477 minecraft:magenta_stained_glass
setblock 141 132 495 minecraft:pearlescent_froglight
setblock 144 132 463 minecraft:magenta_stained_glass
fill 145 132 463 145 135 463 minecraft:end_stone_bricks
setblock 153 132 463 minecraft:white_concrete
fill 154 132 463 154 183 463 minecraft:end_stone_bricks
setblock 158 132 497 minecraft:magenta_stained_glass
setblock 158 132 500 minecraft:magenta_stained_glass
fill 162 132 471 162 137 471 minecraft:purpur_block
fill 162 132 473 162 137 473 minecraft:purpur_block
fill 162 132 505 162 167 505 minecraft:end_stone_bricks
fill 163 132 470 165 137 470 minecraft:purpur_block
fill 163 132 474 163 137 474 minecraft:purpur_block
fill 165 132 474 165 137 474 minecraft:purpur_block
fill 166 132 471 166 137 471 minecraft:purpur_block
fill 166 132 473 166 137 473 minecraft:purpur_block
setblock 171 132 463 minecraft:pearlescent_froglight
fill 183 132 474 183 166 474 minecraft:end_stone_bricks
fill 141 133 477 141 148 477 minecraft:end_stone_bricks
fill 141 133 495 141 145 495 minecraft:end_stone_bricks
fill 144 133 463 144 196 463 minecraft:end_stone_bricks
fill 147 133 473 149 134 473 minecraft:purpur_block
fill 148 133 474 149 134 474 minecraft:purpur_block
fill 153 133 463 153 136 463 minecraft:end_stone_bricks
fill 160 133 495 161 134 495 minecraft:obsidian
fill 161 133 472 161 137 472 minecraft:purpur_block
setblock 162 133 463 minecraft:pearlescent_froglight
fill 162 133 470 162 137 470 minecraft:purpur_block
fill 162 133 474 162 137 474 minecraft:purpur_block
fill 163 133 475 165 137 475 minecraft:purpur_block
fill 166 133 470 166 137 470 minecraft:purpur_block
fill 166 133 474 166 137 474 minecraft:purpur_block
fill 171 133 463 171 159 463 minecraft:end_stone_bricks
setblock 183 133 465 minecraft:pearlescent_froglight
fill 141 134 464 141 196 464 minecraft:end_stone_bricks
setblock 141 134 465 minecraft:pearlescent_froglight
setblock 141 134 467 minecraft:magenta_stained_glass
setblock 141 134 475 minecraft:pearlescent_froglight
fill 141 134 476 141 196 476 minecraft:end_stone_bricks
setblock 141 134 498 minecraft:pearlescent_froglight
setblock 141 134 502 minecraft:white_concrete
fill 154 134 489 155 135 490 minecraft:obsidian
fill 161 134 471 161 137 471 minecraft:purpur_block
fill 161 134 473 161 137 474 minecraft:purpur_block
fill 162 134 463 162 186 463 minecraft:end_stone_bricks
fill 162 134 475 162 137 475 minecraft:purpur_block
fill 163 134 469 165 137 469 minecraft:purpur_block
fill 166 134 475 166 137 475 minecraft:purpur_block
fill 167 134 471 167 137 474 minecraft:purpur_block
setblock 176 134 505 minecraft:white_concrete
fill 178 134 505 178 198 505 minecraft:end_stone_bricks
setblock 179 134 505 minecraft:pearlescent_froglight
fill 183 134 465 183 156 465 minecraft:end_stone_bricks
setblock 183 134 469 minecraft:pearlescent_froglight
fill 141 135 465 141 181 465 minecraft:end_stone_bricks
fill 141 135 467 141 196 467 minecraft:end_stone_bricks
fill 141 135 475 141 173 475 minecraft:end_stone_bricks
fill 141 135 498 141 190 498 minecraft:end_stone_bricks
fill 141 135 502 141 196 502 minecraft:end_stone_bricks
setblock 144 135 505 minecraft:pearlescent_froglight
fill 146 135 505 146 157 505 minecraft:end_stone_bricks
setblock 147 135 505 minecraft:pearlescent_froglight
fill 148 135 505 152 137 505 minecraft:end_stone_bricks
setblock 155 135 463 minecraft:white_concrete
setblock 158 135 463 minecraft:pearlescent_froglight
fill 161 135 470 161 137 470 minecraft:purpur_block
fill 162 135 469 162 137 469 minecraft:purpur_block
fill 163 135 476 165 137 476 minecraft:purpur_block
fill 166 135 469 166 137 469 minecraft:purpur_block
fill 167 135 470 167 137 470 minecraft:purpur_block
fill 176 135 505 176 140 505 minecraft:end_stone_bricks
fill 179 135 505 179 170 505 minecraft:end_stone_bricks
fill 183 135 469 183 142 469 minecraft:end_stone_bricks
fill 141 136 471 141 137 471 minecraft:magenta_concrete
setblock 141 136 478 minecraft:magenta_stained_glass
fill 141 136 486 141 193 486 minecraft:end_stone_bricks
fill 141 136 487 141 137 487 minecraft:magenta_concrete
fill 141 136 503 141 137 503 minecraft:magenta_concrete
fill 144 136 505 144 196 505 minecraft:end_stone_bricks
fill 145 136 463 145 137 463 minecraft:magenta_concrete
fill 147 136 505 147 177 505 minecraft:end_stone_bricks
fill 155 136 463 155 138 463 minecraft:end_stone_bricks
fill 155 136 505 155 137 505 minecraft:magenta_concrete
fill 158 136 463 158 172 463 minecraft:end_stone_bricks
fill 160 136 471 160 137 474 minecraft:purpur_block
fill 161 136 463 161 137 463 minecraft:magenta_concrete
fill 161 136 469 161 137 469 minecraft:purpur_block
fill 161 136 475 161 137 475 minecraft:purpur_block
fill 162 136 476 162 137 476 minecraft:purpur_block
fill 163 136 468 165 137 468 minecraft:purpur_block
fill 166 136 476 166 137 476 minecraft:purpur_block
fill 167 136 469 167 137 469 minecraft:purpur_block
fill 167 136 475 167 137 475 minecraft:purpur_block
fill 168 136 471 168 137 474 minecraft:purpur_block
fill 171 136 505 171 137 505 minecraft:magenta_concrete
setblock 175 136 505 minecraft:white_concrete
fill 177 136 463 177 137 463 minecraft:magenta_concrete
fill 183 136 473 183 137 473 minecraft:magenta_concrete
fill 183 136 489 183 137 489 minecraft:magenta_concrete
setblock 183 136 502 minecraft:pearlescent_froglight
fill 141 137 478 141 196 478 minecraft:end_stone_bricks
setblock 141 137 480 minecraft:pearlescent_froglight
fill 141 137 481 141 171 481 minecraft:end_stone_bricks
setblock 144 137 466 minecraft:light[level=14]
setblock 144 137 474 minecraft:light[level=14]
setblock 144 137 482 minecraft:light[level=14]
setblock 144 137 490 minecraft:light[level=14]
setblock 144 137 498 minecraft:light[level=14]
setblock 152 137 466 minecraft:light[level=14]
setblock 152 137 474 minecraft:light[level=14]
setblock 152 137 482 minecraft:light[level=14]
setblock 152 137 490 minecraft:light[level=14]
setblock 152 137 498 minecraft:light[level=14]
setblock 153 137 463 minecraft:white_concrete
fill 156 137 505 156 169 505 minecraft:end_stone_bricks
setblock 157 137 505 minecraft:magenta_stained_glass
setblock 160 137 466 minecraft:light[level=14]
setblock 160 137 470 minecraft:purpur_block
setblock 160 137 475 minecraft:purpur_block
setblock 160 137 482 minecraft:light[level=14]
setblock 160 137 490 minecraft:light[level=14]
setblock 160 137 498 minecraft:light[level=14]
setblock 161 137 476 minecraft:purpur_block
setblock 162 137 468 minecraft:purpur_block
fill 163 137 477 165 137 477 minecraft:purpur_block
setblock 166 137 468 minecraft:purpur_block
setblock 167 137 476 minecraft:purpur_block
setblock 168 137 466 minecraft:light[level=14]
setblock 168 137 470 minecraft:purpur_block
setblock 168 137 475 minecraft:purpur_block
setblock 168 137 482 minecraft:light[level=14]
setblock 168 137 490 minecraft:light[level=14]
setblock 168 137 498 minecraft:light[level=14]
fill 175 137 505 175 193 505 minecraft:end_stone_bricks
setblock 176 137 466 minecraft:light[level=14]
setblock 176 137 474 minecraft:light[level=14]
setblock 176 137 482 minecraft:light[level=14]
setblock 176 137 490 minecraft:light[level=14]
setblock 176 137 498 minecraft:light[level=14]
setblock 182 137 505 minecraft:pearlescent_froglight
setblock 183 137 476 minecraft:magenta_stained_glass
fill 183 137 477 183 167 477 minecraft:end_stone_bricks
fill 183 137 502 183 192 502 minecraft:end_stone_bricks
fill 141 138 471 141 144 471 minecraft:end_stone_bricks
fill 141 138 480 141 196 480 minecraft:end_stone_bricks
fill 141 138 487 141 144 487 minecraft:end_stone_bricks
fill 141 138 503 141 144 503 minecraft:end_stone_bricks
fill 145 138 463 145 144 463 minecraft:end_stone_bricks
setblock 148 138 505 minecraft:pearlescent_froglight
fill 149 138 505 152 193 505 minecraft:end_stone_bricks
setblock 151 138 463 minecraft:pearlescent_froglight
fill 153 138 463 153 184 463 minecraft:end_stone_bricks
fill 155 138 505 155 144 505 minecraft:end_stone_bricks
fill 157 138 505 157 165 505 minecraft:end_stone_bricks
fill 160 138 502 160 139 503 minecraft:purpur_block
fill 161 138 463 161 144 463 minecraft:end_stone_bricks
fill 162 138 473 162 140 473 minecraft:end_stone_bricks
fill 164 138 471 164 142 471 minecraft:end_stone_bricks
fill 165 138 473 165 139 473 minecraft:end_stone_bricks
setblock 165 138 505 minecraft:pearlescent_froglight
fill 171 138 505 171 144 505 minecraft:end_stone_bricks
fill 177 138 463 177 144 463 minecraft:end_stone_bricks
fill 182 138 505 182 197 505 minecraft:end_stone_bricks
fill 183 138 473 183 144 473 minecraft:end_stone_bricks
fill 183 138 476 183 192 476 minecraft:end_stone_bricks
fill 183 138 489 183 144 489 minecraft:end_stone_bricks
setblock 183 138 492 minecraft:white_concrete
fill 148 139 505 148 150 505 minecraft:end_stone_bricks
fill 151 139 463 151 194 463 minecraft:end_stone_bricks
setblock 155 139 463 minecraft:white_concrete
fill 165 139 505 165 196 505 minecraft:end_stone_bricks
fill 183 139 492 183 164 492 minecraft:end_stone_bricks
fill 155 140 463 155 197 463 minecraft:end_stone_bricks
setblock 183 140 468 minecraft:pearlescent_froglight
setblock 141 141 496 minecraft:pearlescent_froglight
setblock 173 141 463 minecraft:pearlescent_froglight
setblock 176 141 505 minecraft:pearlescent_froglight
fill 183 141 468 183 158 468 minecraft:end_stone_bricks
setblock 141 142 490 minecraft:magenta_stained_glass
fill 141 142 496 141 193 496 minecraft:end_stone_bricks
fill 173 142 463 173 168 463 minecraft:end_stone_bricks
fill 176 142 505 176 196 505 minecraft:end_stone_bricks
fill 141 143 490 141 194 490 minecraft:end_stone_bricks
fill 168 143 478 170 144 478 minecraft:purpur_block
fill 169 143 477 169 144 477 minecraft:purpur_block
setblock 183 143 469 minecraft:pearlescent_froglight
setblock 183 143 501 minecraft:magenta_stained_glass
setblock 156 144 463 minecraft:magenta_stained_glass
fill 157 144 463 157 173 463 minecraft:end_stone_bricks
setblock 164 144 505 minecraft:magenta_stained_glass
fill 183 144 469 183 192 469 minecraft:end_stone_bricks
setblock 183 144 470 minecraft:magenta_stained_glass
fill 183 144 501 183 192 501 minecraft:end_stone_bricks
setblock 141 145 471 minecraft:magenta_concrete
setblock 141 145 487 minecraft:magenta_concrete
setblock 141 145 503 minecraft:magenta_concrete
setblock 144 145 466 minecraft:light[level=14]
setblock 144 145 474 minecraft:light[level=14]
setblock 144 145 482 minecraft:light[level=14]
setblock 144 145 490 minecraft:light[level=14]
setblock 144 145 498 minecraft:light[level=14]
setblock 145 145 463 minecraft:magenta_concrete
setblock 152 145 466 minecraft:light[level=14]
setblock 152 145 474 minecraft:light[level=14]
setblock 152 145 482 minecraft:light[level=14]
setblock 152 145 490 minecraft:light[level=14]
setblock 152 145 498 minecraft:light[level=14]
setblock 155 145 505 minecraft:magenta_concrete
fill 156 145 463 156 175 463 minecraft:end_stone_bricks
setblock 160 145 466 minecraft:light[level=14]
setblock 160 145 474 minecraft:light[level=14]
setblock 160 145 482 minecraft:light[level=14]
setblock 160 145 490 minecraft:light[level=14]
setblock 160 145 498 minecraft:light[level=14]
setblock 161 145 463 minecraft:magenta_concrete
setblock 163 145 505 minecraft:pearlescent_froglight
fill 164 145 505 164 192 505 minecraft:end_stone_bricks
setblock 168 145 466 minecraft:light[level=14]
setblock 168 145 474 minecraft:light[level=14]
setblock 168 145 482 minecraft:light[level=14]
setblock 168 145 490 minecraft:light[level=14]
setblock 168 145 498 minecraft:light[level=14]
setblock 171 145 505 minecraft:magenta_concrete
setblock 176 145 463 minecraft:magenta_stained_glass
setblock 176 145 466 minecraft:light[level=14]
setblock 176 145 474 minecraft:light[level=14]
setblock 176 145 482 minecraft:light[level=14]
setblock 176 145 490 minecraft:light[level=14]
setblock 176 145 498 minecraft:light[level=14]
setblock 177 145 463 minecraft:magenta_concrete
setblock 183 145 470 minecraft:end_stone_bricks
setblock 183 145 471 minecraft:pearlescent_froglight
setblock 183 145 473 minecraft:magenta_concrete
setblock 183 145 489 minecraft:magenta_concrete
fill 141 146 471 141 161 471 minecraft:end_stone_bricks
fill 141 146 482 141 197 482 minecraft:end_stone_bricks
setblock 141 146 483 minecraft:magenta_stained_glass
fill 141 146 487 141 161 487 minecraft:end_stone_bricks
setblock 141 146 495 minecraft:magenta_stained_glass
fill 141 146 503 141 153 503 minecraft:end_stone_bricks
fill 145 146 463 145 161 463 minecraft:end_stone_bricks
fill 155 146 505 155 161 505 minecraft:end_stone_bricks
fill 161 146 463 161 148 463 minecraft:end_stone_bricks
fill 163 146 505 163 188 505 minecraft:end_stone_bricks
fill 171 146 505 171 159 505 minecraft:end_stone_bricks
fill 176 146 463 177 161 463 minecraft:end_stone_bricks
setblock 183 146 470 minecraft:magenta_stained_glass
fill 183 146 471 183 196 471 minecraft:end_stone_bricks
fill 183 146 473 183 152 473 minecraft:end_stone_bricks
fill 183 146 489 183 161 489 minecraft:end_stone_bricks
fill 141 147 483 141 197 483 minecraft:end_stone_bricks
fill 141 147 495 141 196 495 minecraft:end_stone_bricks
fill 183 147 470 183 178 470 minecraft:end_stone_bricks
setblock 141 148 466 minecraft:magenta_stained_glass
setblock 141 148 469 minecraft:magenta_stained_glass
fill 141 149 466 141 196 466 minecraft:end_stone_bricks
fill 141 149 469 141 196 469 minecraft:end_stone_bricks
setblock 141 149 477 minecraft:magenta_stained_glass
setblock 161 149 463 minecraft:pearlescent_froglight
setblock 166 149 505 minecraft:pearlescent_froglight
setblock 168 149 505 minecraft:white_concrete
fill 141 150 477 141 172 477 minecraft:end_stone_bricks
fill 157 150 484 159 150 486 minecraft:redstone_block
setblock 161 150 463 minecraft:end_stone_bricks
fill 161 150 489 163 150 491 minecraft:redstone_block
fill 162 150 479 164 150 481 minecraft:redstone_block
fill 166 150 505 166 153 505 minecraft:end_stone_bricks
fill 167 150 485 169 150 487 minecraft:redstone_block
fill 168 150 505 168 161 505 minecraft:end_stone_bricks
fill 145 151 484 156 151 486 minecraft:magenta_concrete
setblock 148 151 505 minecraft:white_concrete
fill 160 151 484 161 151 486 minecraft:magenta_concrete
setblock 161 151 463 minecraft:white_concrete
fill 162 151 467 164 151 478 minecraft:magenta_concrete
fill 162 151 482 164 151 483 minecraft:magenta_concrete
fill 162 151 487 164 151 488 minecraft:magenta_concrete
fill 162 151 492 164 151 503 minecraft:magenta_concrete
fill 164 151 489 164 151 491 minecraft:magenta_concrete
fill 165 151 484 166 151 486 minecraft:magenta_concrete
fill 167 151 484 181 151 484 minecraft:magenta_concrete
fill 170 151 485 181 151 486 minecraft:magenta_concrete
fill 142 152 464 144 152 504 minecraft:black_concrete
fill 145 152 464 155 152 483 minecraft:black_concrete
fill 145 152 484 156 152 484 minecraft:pearlescent_froglight
fill 145 152 485 155 152 485 minecraft:magenta_concrete
fill 145 152 486 156 152 486 minecraft:pearlescent_froglight
fill 145 152 487 155 152 504 minecraft:black_concrete
fill 148 152 505 148 196 505 minecraft:end_stone_bricks
setblock 152 152 463 minecraft:pearlescent_froglight
fill 156 152 464 160 152 482 minecraft:black_concrete
fill 156 152 483 165 152 483 minecraft:pearlescent_froglight
setblock 156 152 485 minecraft:pearlescent_froglight
fill 156 152 487 166 152 487 minecraft:pearlescent_froglight
fill 156 152 488 159 152 504 minecraft:black_concrete
fill 157 152 484 159 152 486 minecraft:black_concrete
fill 160 152 484 161 152 486 minecraft:pearlescent_froglight
fill 160 152 488 160 152 492 minecraft:pearlescent_froglight
fill 160 152 493 161 152 504 minecraft:black_concrete
fill 161 152 463 161 161 463 minecraft:end_stone_bricks
fill 161 152 464 161 152 477 minecraft:black_concrete
fill 161 152 478 161 152 482 minecraft:pearlescent_froglight
fill 161 152 488 164 152 488 minecraft:pearlescent_froglight
fill 161 152 489 163 152 491 minecraft:black_concrete
fill 161 152 492 164 152 492 minecraft:pearlescent_froglight
fill 162 152 464 182 152 466 minecraft:black_concrete
fill 162 152 467 162 152 478 minecraft:pearlescent_froglight
fill 162 152 479 164 152 481 minecraft:black_concrete
fill 162 152 482 165 152 482 minecraft:pearlescent_froglight
fill 162 152 493 162 152 503 minecraft:pearlescent_froglight
fill 162 152 504 182 152 504 minecraft:black_concrete
fill 163 152 467 163 152 477 minecraft:magenta_concrete
fill 163 152 478 165 152 478 minecraft:pearlescent_froglight
fill 163 152 493 163 152 503 minecraft:magenta_concrete
fill 164 152 467 164 152 477 minecraft:pearlescent_froglight
fill 164 152 489 164 152 491 minecraft:pearlescent_froglight
fill 164 152 493 164 152 503 minecraft:pearlescent_froglight
fill 165 152 467 182 152 477 minecraft:black_concrete
fill 165 152 479 165 152 481 minecraft:pearlescent_froglight
fill 165 152 484 166 152 486 minecraft:pearlescent_froglight
fill 165 152 488 165 152 503 minecraft:black_concrete
fill 166 152 478 182 152 483 minecraft:black_concrete
fill 166 152 488 170 152 488 minecraft:pearlescent_froglight
fill 166 152 489 182 152 503 minecraft:black_concrete
fill 167 152 484 181 152 484 minecraft:pearlescent_froglight
fill 167 152 485 169 152 487 minecraft:black_concrete
fill 170 152 485 170 152 487 minecraft:pearlescent_froglight
fill 171 152 485 181 152 485 minecraft:magenta_concrete
fill 171 152 486 181 152 486 minecraft:pearlescent_froglight
fill 171 152 487 182 152 488 minecraft:black_concrete
fill 182 152 484 182 152 486 minecraft:black_concrete
setblock 183 152 499 minecraft:magenta_stained_glass
setblock 144 153 466 minecraft:light[level=14]
setblock 144 153 474 minecraft:light[level=14]
setblock 144 153 482 minecraft:light[level=14]
setblock 144 153 490 minecraft:light[level=14]
setblock 144 153 498 minecraft:light[level=14]
fill 151 153 485 151 154 486 minecraft:cobblestone
fill 152 153 463 152 193 463 minecraft:end_stone_bricks
setblock 152 153 466 minecraft:light[level=14]
setblock 152 153 474 minecraft:light[level=14]
setblock 152 153 482 minecraft:light[level=14]
setblock 152 153 490 minecraft:light[level=14]
setblock 152 153 498 minecraft:light[level=14]
fill 153 153 478 153 154 479 minecraft:cobblestone
fill 153 153 493 153 154 494 minecraft:cobblestone
fill 154 153 478 159 153 492 minecraft:dark_oak_planks
setblock 160 153 466 minecraft:light[level=14]
fill 160 153 474 160 154 475 minecraft:cobblestone
fill 160 153 478 172 153 481 minecraft:dark_oak_planks
fill 160 153 490 172 153 492 minecraft:dark_oak_planks
fill 160 153 497 160 154 498 minecraft:cobblestone
fill 167 153 474 167 154 475 minecraft:cobblestone
fill 167 153 497 167 154 498 minecraft:cobblestone
setblock 168 153 466 minecraft:light[level=14]
setblock 168 153 474 minecraft:light[level=14]
fill 168 153 482 172 153 489 minecraft:dark_oak_planks
setblock 168 153 498 minecraft:light[level=14]
fill 174 153 478 174 154 479 minecraft:cobblestone
fill 174 153 493 174 154 494 minecraft:cobblestone
setblock 176 153 466 minecraft:light[level=14]
setblock 176 153 474 minecraft:light[level=14]
setblock 176 153 482 minecraft:light[level=14]
fill 176 153 485 176 154 486 minecraft:cobblestone
setblock 176 153 490 minecraft:light[level=14]
setblock 176 153 498 minecraft:light[level=14]
setblock 183 153 473 minecraft:magenta_stained_glass
setblock 183 153 495 minecraft:pearlescent_froglight
fill 183 153 496 183 164 496 minecraft:end_stone_bricks
fill 183 153 499 183 186 499 minecraft:end_stone_bricks
setblock 141 154 472 minecraft:white_concrete
setblock 141 154 492 minecraft:magenta_stained_glass
setblock 141 154 497 minecraft:magenta_stained_glass
setblock 141 154 503 minecraft:white_concrete
fill 154 154 478 154 154 492 minecraft:dark_oak_planks
fill 155 154 478 172 154 478 minecraft:dark_oak_planks
fill 155 154 492 172 154 492 minecraft:dark_oak_planks
setblock 166 154 505 minecraft:pearlescent_froglight
fill 172 154 479 172 154 491 minecraft:dark_oak_planks
setblock 177 154 505 minecraft:pearlescent_froglight
fill 183 154 473 183 161 473 minecraft:end_stone_bricks
setblock 183 154 475 minecraft:white_concrete
fill 183 154 495 183 196 495 minecraft:end_stone_bricks
fill 141 155 472 141 163 472 minecraft:end_stone_bricks
fill 141 155 492 141 197 492 minecraft:end_stone_bricks
fill 141 155 497 141 187 497 minecraft:end_stone_bricks
setblock 141 155 500 minecraft:pearlescent_froglight
fill 141 155 503 141 157 503 minecraft:end_stone_bricks
setblock 153 155 505 minecraft:pearlescent_froglight
fill 154 155 478 154 160 478 minecraft:dark_oak_planks
setblock 154 155 479 minecraft:ochre_froglight
fill 154 155 480 154 160 481 minecraft:dark_oak_planks
setblock 154 155 482 minecraft:ochre_froglight
fill 154 155 483 154 160 484 minecraft:dark_oak_planks
setblock 154 155 485 minecraft:ochre_froglight
fill 154 155 486 154 160 487 minecraft:dark_oak_planks
setblock 154 155 488 minecraft:ochre_froglight
fill 154 155 489 154 160 490 minecraft:dark_oak_planks
setblock 154 155 491 minecraft:ochre_froglight
fill 154 155 492 155 160 492 minecraft:dark_oak_planks
setblock 155 155 478 minecraft:ochre_froglight
fill 156 155 478 157 160 478 minecraft:dark_oak_planks
setblock 156 155 492 minecraft:ochre_froglight
fill 157 155 492 158 160 492 minecraft:dark_oak_planks
setblock 158 155 478 minecraft:ochre_froglight
fill 159 155 478 160 160 478 minecraft:dark_oak_planks
setblock 159 155 492 minecraft:ochre_froglight
fill 160 155 492 161 160 492 minecraft:dark_oak_planks
setblock 161 155 478 minecraft:ochre_froglight
fill 162 155 478 163 160 478 minecraft:dark_oak_planks
setblock 162 155 492 minecraft:ochre_froglight
fill 163 155 492 164 160 492 minecraft:dark_oak_planks
setblock 164 155 478 minecraft:ochre_froglight
fill 165 155 478 166 160 478 minecraft:dark_oak_planks
setblock 165 155 492 minecraft:ochre_froglight
fill 166 155 492 167 160 492 minecraft:dark_oak_planks
fill 166 155 505 166 192 505 minecraft:end_stone_bricks
setblock 167 155 478 minecraft:ochre_froglight
fill 168 155 478 169 160 478 minecraft:dark_oak_planks
setblock 168 155 492 minecraft:ochre_froglight
fill 169 155 492 170 160 492 minecraft:dark_oak_planks
setblock 170 155 463 minecraft:pearlescent_froglight
setblock 170 155 478 minecraft:ochre_froglight
fill 171 155 478 172 160 478 minecraft:dark_oak_planks
setblock 171 155 492 minecraft:ochre_froglight
setblock 172 155 479 minecraft:ochre_froglight
fill 172 155 480 172 160 481 minecraft:dark_oak_planks
setblock 172 155 482 minecraft:ochre_froglight
fill 172 155 483 172 160 484 minecraft:dark_oak_planks
setblock 172 155 485 minecraft:ochre_froglight
fill 172 155 486 172 160 487 minecraft:dark_oak_planks
setblock 172 155 488 minecraft:ochre_froglight
fill 172 155 489 172 160 490 minecraft:dark_oak_planks
setblock 172 155 491 minecraft:ochre_froglight
fill 172 155 492 172 160 492 minecraft:dark_oak_planks
fill 177 155 505 177 189 505 minecraft:end_stone_bricks
fill 183 155 475 183 180 475 minecraft:end_stone_bricks
fill 183 155 503 183 196 503 minecraft:end_stone_bricks
setblock 183 155 504 minecraft:pearlescent_froglight
fill 141 156 500 141 163 500 minecraft:end_stone_bricks
fill 153 156 505 153 176 505 minecraft:end_stone_bricks
fill 154 156 479 154 158 479 minecraft:dark_oak_planks
fill 154 156 482 154 158 482 minecraft:dark_oak_planks
fill 154 156 485 154 158 485 minecraft:dark_oak_planks
fill 154 156 488 154 158 488 minecraft:dark_oak_planks
fill 154 156 491 154 158 491 minecraft:dark_oak_planks
fill 155 156 478 155 158 478 minecraft:dark_oak_planks
fill 156 156 492 156 158 492 minecraft:dark_oak_planks
fill 158 156 478 158 158 478 minecraft:dark_oak_planks
fill 159 156 492 159 158 492 minecraft:dark_oak_planks
fill 161 156 478 161 158 478 minecraft:dark_oak_planks
fill 162 156 492 162 158 492 minecraft:dark_oak_planks
setblock 163 156 463 minecraft:white_concrete
fill 164 156 478 164 158 478 minecraft:dark_oak_planks
fill 165 156 492 165 158 492 minecraft:dark_oak_planks
fill 167 156 478 167 158 478 minecraft:dark_oak_planks
fill 168 156 492 168 158 492 minecraft:dark_oak_planks
fill 170 156 463 170 194 463 minecraft:end_stone_bricks
fill 170 156 478 170 158 478 minecraft:dark_oak_planks
fill 171 156 492 171 158 492 minecraft:dark_oak_planks
fill 172 156 479 172 158 479 minecraft:dark_oak_planks
fill 172 156 482 172 158 482 minecraft:dark_oak_planks
fill 172 156 485 172 158 485 minecraft:dark_oak_planks
fill 172 156 488 172 158 488 minecraft:dark_oak_planks
fill 172 156 491 172 158 491 minecraft:dark_oak_planks
setblock 172 156 505 minecraft:white_concrete
fill 183 156 504 183 196 504 minecraft:end_stone_bricks
setblock 158 157 505 minecraft:pearlescent_froglight
fill 163 157 463 163 196 463 minecraft:end_stone_bricks
fill 172 157 505 172 196 505 minecraft:end_stone_bricks
setblock 183 157 465 minecraft:magenta_stained_glass
setblock 141 158 499 minecraft:magenta_stained_glass
setblock 141 158 503 minecraft:magenta_stained_glass
setblock 146 158 505 minecraft:white_concrete
fill 158 158 505 158 161 505 minecraft:end_stone_bricks
fill 183 158 465 183 198 465 minecraft:end_stone_bricks
setblock 183 158 494 minecraft:white_concrete
fill 141 159 499 141 178 499 minecraft:end_stone_bricks
fill 141 159 503 141 161 503 minecraft:end_stone_bricks
fill 146 159 505 146 196 505 minecraft:end_stone_bricks
setblock 154 159 479 minecraft:ochre_froglight
setblock 154 159 482 minecraft:ochre_froglight
setblock 154 159 485 minecraft:ochre_froglight
setblock 154 159 488 minecraft:ochre_froglight
setblock 154 159 491 minecraft:ochre_froglight
setblock 155 159 478 minecraft:ochre_froglight
setblock 156 159 492 minecraft:ochre_froglight
setblock 158 159 478 minecraft:ochre_froglight
setblock 159 159 492 minecraft:ochre_froglight
setblock 161 159 478 minecraft:ochre_froglight
setblock 162 159 492 minecraft:ochre_froglight
setblock 164 159 478 minecraft:ochre_froglight
setblock 165 159 492 minecraft:ochre_froglight
setblock 167 159 478 minecraft:ochre_froglight
setblock 168 159 492 minecraft:ochre_froglight
setblock 170 159 478 minecraft:ochre_froglight
setblock 171 159 492 minecraft:ochre_froglight
setblock 172 159 479 minecraft:ochre_froglight
setblock 172 159 482 minecraft:ochre_froglight
setblock 172 159 485 minecraft:ochre_froglight
setblock 172 159 488 minecraft:ochre_froglight
setblock 172 159 491 minecraft:ochre_froglight
setblock 179 159 463 minecraft:white_concrete
setblock 183 159 468 minecraft:magenta_stained_glass
fill 183 159 494 183 196 494 minecraft:end_stone_bricks
fill 154 160 479 172 160 479 minecraft:dark_oak_planks
fill 154 160 482 159 160 482 minecraft:dark_oak_planks
fill 154 160 485 159 160 485 minecraft:dark_oak_planks
fill 154 160 488 159 160 488 minecraft:dark_oak_planks
fill 154 160 491 172 160 491 minecraft:dark_oak_planks
setblock 155 160 478 minecraft:dark_oak_planks
fill 155 160 480 171 160 481 minecraft:dark_oak_planks
fill 155 160 483 159 160 484 minecraft:dark_oak_planks
fill 155 160 486 159 160 487 minecraft:dark_oak_planks
fill 155 160 489 159 160 490 minecraft:dark_oak_planks
setblock 156 160 492 minecraft:dark_oak_planks
setblock 158 160 478 minecraft:dark_oak_planks
setblock 159 160 492 minecraft:dark_oak_planks
fill 160 160 490 171 160 490 minecraft:dark_oak_planks
setblock 161 160 478 minecraft:dark_oak_planks
setblock 162 160 492 minecraft:dark_oak_planks
setblock 164 160 478 minecraft:dark_oak_planks
setblock 165 160 492 minecraft:dark_oak_planks
setblock 167 160 478 minecraft:dark_oak_planks
fill 168 160 482 171 160 489 minecraft:dark_oak_planks
setblock 168 160 492 minecraft:dark_oak_planks
setblock 170 160 478 minecraft:dark_oak_planks
setblock 171 160 463 minecraft:white_concrete
setblock 171 160 492 minecraft:dark_oak_planks
setblock 171 160 505 minecraft:magenta_stained_glass
setblock 172 160 482 minecraft:dark_oak_planks
setblock 172 160 485 minecraft:dark_oak_planks
setblock 172 160 488 minecraft:dark_oak_planks
fill 179 160 463 179 168 463 minecraft:end_stone_bricks
fill 183 160 468 183 196 468 minecraft:end_stone_bricks
setblock 183 160 482 minecraft:magenta_stained_glass
setblock 141 161 473 minecraft:pearlescent_froglight
setblock 141 161 489 minecraft:magenta_stained_glass
setblock 144 161 466 minecraft:light[level=14]
setblock 144 161 474 minecraft:light[level=14]
setblock 144 161 482 minecraft:light[level=14]
setblock 144 161 490 minecraft:light[level=14]
setblock 144 161 498 minecraft:light[level=14]
setblock 152 161 466 minecraft:light[level=14]
setblock 152 161 474 minecraft:light[level=14]
setblock 152 161 482 minecraft:light[level=14]
setblock 152 161 490 minecraft:light[level=14]
setblock 152 161 498 minecraft:light[level=14]
fill 154 161 478 159 161 492 minecraft:deepslate_tiles
setblock 160 161 466 minecraft:light[level=14]
setblock 160 161 474 minecraft:light[level=14]
fill 160 161 478 172 161 481 minecraft:deepslate_tiles
fill 160 161 490 172 161 492 minecraft:deepslate_tiles
setblock 160 161 498 minecraft:light[level=14]
setblock 168 161 466 minecraft:light[level=14]
setblock 168 161 474 minecraft:light[level=14]
fill 168 161 482 172 161 489 minecraft:deepslate_tiles
setblock 168 161 498 minecraft:light[level=14]
setblock 171 161 463 minecraft:end_stone_bricks
setblock 171 161 505 minecraft:end_stone_bricks
setblock 176 161 466 minecraft:light[level=14]
setblock 176 161 474 minecraft:light[level=14]
setblock 176 161 482 minecraft:light[level=14]
setblock 176 161 490 minecraft:light[level=14]
setblock 176 161 498 minecraft:light[level=14]
fill 183 161 482 183 172 483 minecraft:end_stone_bricks
setblock 183 161 484 minecraft:pearlescent_froglight
fill 183 161 485 183 196 485 minecraft:end_stone_bricks
fill 141 162 471 141 164 471 minecraft:magenta_concrete
fill 141 162 473 141 192 473 minecraft:end_stone_bricks
fill 141 162 487 141 164 487 minecraft:magenta_concrete
fill 141 162 489 141 170 489 minecraft:end_stone_bricks
fill 141 162 503 141 164 503 minecraft:magenta_concrete
fill 145 162 463 145 164 463 minecraft:magenta_concrete
fill 155 162 479 159 162 491 minecraft:deepslate_tiles
fill 155 162 505 155 164 505 minecraft:magenta_concrete
setblock 158 162 505 minecraft:white_concrete
fill 160 162 479 171 162 481 minecraft:deepslate_tiles
fill 160 162 490 171 162 491 minecraft:deepslate_tiles
fill 161 162 463 161 164 463 minecraft:magenta_concrete
fill 168 162 482 171 162 489 minecraft:deepslate_tiles
setblock 168 162 505 minecraft:magenta_stained_glass
setblock 171 162 463 minecraft:white_concrete
fill 171 162 505 171 164 505 minecraft:magenta_concrete
setblock 176 162 463 minecraft:magenta_stained_glass
fill 177 162 463 177 164 463 minecraft:magenta_concrete
fill 183 162 473 183 164 473 minecraft:magenta_concrete
fill 183 162 484 183 182 484 minecraft:end_stone_bricks
fill 183 162 489 183 164 489 minecraft:magenta_concrete
fill 156 163 480 159 163 490 minecraft:deepslate_tiles
fill 158 163 505 158 196 505 minecraft:end_stone_bricks
fill 160 163 480 170 163 481 minecraft:deepslate_tiles
fill 160 163 490 170 163 490 minecraft:deepslate_tiles
fill 168 163 482 170 163 489 minecraft:deepslate_tiles
fill 168 163 505 168 196 505 minecraft:end_stone_bricks
fill 171 163 463 171 188 463 minecraft:end_stone_bricks
fill 176 163 463 176 196 463 minecraft:end_stone_bricks
setblock 183 163 479 minecraft:pearlescent_froglight
setblock 141 164 472 minecraft:magenta_stained_glass
setblock 141 164 500 minecraft:white_concrete
fill 157 164 481 159 164 489 minecraft:deepslate_tiles
fill 160 164 481 169 164 481 minecraft:deepslate_tiles
fill 168 164 482 169 164 489 minecraft:deepslate_tiles
fill 183 164 479 183 169 479 minecraft:end_stone_bricks
setblock 183 164 481 minecraft:magenta_stained_glass
fill 141 165 471 141 170 472 minecraft:end_stone_bricks
fill 141 165 487 141 167 487 minecraft:end_stone_bricks
fill 141 165 500 141 185 500 minecraft:end_stone_bricks
fill 141 165 503 141 170 503 minecraft:end_stone_bricks
fill 145 165 463 145 170 463 minecraft:end_stone_bricks
fill 155 165 505 155 170 505 minecraft:end_stone_bricks
fill 158 165 482 159 165 488 minecraft:deepslate_tiles
fill 161 165 463 161 170 463 minecraft:end_stone_bricks
fill 168 165 482 168 165 488 minecraft:deepslate_tiles
fill 171 165 505 171 170 505 minecraft:end_stone_bricks
setblock 175 165 463 minecraft:white_concrete
fill 177 165 463 177 170 463 minecraft:end_stone_bricks
fill 183 165 473 183 170 473 minecraft:end_stone_bricks
fill 183 165 481 183 193 481 minecraft:end_stone_bricks
fill 183 165 489 183 170 489 minecraft:end_stone_bricks
setblock 183 165 492 minecraft:pearlescent_froglight
setblock 183 165 496 minecraft:pearlescent_froglight
setblock 141 166 493 minecraft:magenta_stained_glass
setblock 157 166 505 minecraft:white_concrete
fill 159 166 483 159 166 487 minecraft:deepslate_tiles
fill 165 166 473 165 167 474 minecraft:end_stone
fill 175 166 463 175 174 463 minecraft:end_stone_bricks
setblock 183 166 480 minecraft:pearlescent_froglight
fill 183 166 492 183 196 492 minecraft:end_stone_bricks
fill 183 166 496 183 196 496 minecraft:end_stone_bricks
fill 141 167 493 141 196 493 minecraft:end_stone_bricks
fill 157 167 505 157 196 505 minecraft:end_stone_bricks
setblock 169 167 505 minecraft:pearlescent_froglight
setblock 183 167 474 minecraft:pearlescent_froglight
fill 183 167 480 183 196 480 minecraft:end_stone_bricks
setblock 141 168 487 minecraft:magenta_stained_glass
setblock 162 168 505 minecraft:magenta_stained_glass
fill 169 168 505 169 175 505 minecraft:end_stone_bricks
fill 183 168 474 183 184 474 minecraft:end_stone_bricks
setblock 183 168 477 minecraft:white_concrete
setblock 141 169 479 minecraft:white_concrete
fill 141 169 487 141 170 487 minecraft:end_stone_bricks
setblock 144 169 466 minecraft:light[level=14]
setblock 144 169 474 minecraft:light[level=14]
setblock 144 169 482 minecraft:light[level=14]
setblock 144 169 490 minecraft:light[level=14]
setblock 144 169 498 minecraft:light[level=14]
setblock 152 169 466 minecraft:light[level=14]
setblock 152 169 474 minecraft:light[level=14]
setblock 152 169 482 minecraft:light[level=14]
setblock 152 169 490 minecraft:light[level=14]
setblock 152 169 498 minecraft:light[level=14]
setblock 160 169 466 minecraft:light[level=14]
setblock 160 169 474 minecraft:light[level=14]
setblock 160 169 482 minecraft:light[level=14]
setblock 160 169 490 minecraft:light[level=14]
setblock 160 169 498 minecraft:light[level=14]
fill 162 169 505 162 180 505 minecraft:end_stone_bricks
fill 166 169 500 167 170 501 minecraft:end_stone
setblock 168 169 466 minecraft:light[level=14]
setblock 168 169 474 minecraft:light[level=14]
setblock 168 169 482 minecraft:light[level=14]
setblock 168 169 490 minecraft:light[level=14]
setblock 168 169 498 minecraft:light[level=14]
fill 170 169 484 170 170 486 minecraft:obsidian
fill 171 169 484 171 170 485 minecraft:obsidian
setblock 173 169 463 minecraft:white_concrete
setblock 176 169 466 minecraft:light[level=14]
setblock 176 169 474 minecraft:light[level=14]
setblock 176 169 482 minecraft:light[level=14]
setblock 176 169 490 minecraft:light[level=14]
setblock 176 169 498 minecraft:light[level=14]
setblock 179 169 463 minecraft:pearlescent_froglight
fill 183 169 477 183 196 477 minecraft:end_stone_bricks
fill 141 170 479 141 196 479 minecraft:end_stone_bricks
setblock 156 170 505 minecraft:white_concrete
fill 173 170 463 173 191 463 minecraft:end_stone_bricks
fill 179 170 463 179 196 463 minecraft:end_stone_bricks
setblock 183 170 479 minecraft:white_concrete
fill 141 171 471 141 173 471 minecraft:magenta_concrete
fill 141 171 472 141 173 472 minecraft:end_stone_bricks
fill 141 171 487 141 173 487 minecraft:magenta_concrete
setblock 141 171 489 minecraft:magenta_stained_glass
fill 141 171 503 141 173 503 minecraft:magenta_concrete
fill 145 171 463 145 173 463 minecraft:magenta_concrete
fill 155 171 505 155 173 505 minecraft:magenta_concrete
fill 156 171 505 156 181 505 minecraft:end_stone_bricks
fill 161 171 463 161 173 463 minecraft:magenta_concrete
setblock 164 171 463 minecraft:white_concrete
fill 171 171 505 171 173 505 minecraft:magenta_concrete
setblock 174 171 505 minecraft:magenta_stained_glass
fill 177 171 463 177 173 463 minecraft:magenta_concrete
setblock 179 171 505 minecraft:white_concrete
setblock 181 171 505 minecraft:white_concrete
fill 183 171 473 183 173 473 minecraft:magenta_concrete
fill 183 171 479 183 192 479 minecraft:end_stone_bricks
fill 183 171 489 183 173 489 minecraft:magenta_concrete
setblock 141 172 481 minecraft:pearlescent_froglight
fill 141 172 489 141 192 489 minecraft:end_stone_bricks
setblock 141 172 494 minecraft:white_concrete
fill 164 172 463 164 194 463 minecraft:end_stone_bricks
fill 174 172 505 174 194 505 minecraft:end_stone_bricks
fill 179 172 505 179 188 505 minecraft:end_stone_bricks
fill 181 172 505 181 196 505 minecraft:end_stone_bricks
setblock 183 172 500 minecraft:pearlescent_froglight
setblock 141 173 477 minecraft:white_concrete
fill 141 173 481 141 175 481 minecraft:end_stone_bricks
fill 141 173 494 141 196 494 minecraft:end_stone_bricks
setblock 158 173 463 minecraft:pearlescent_froglight
setblock 183 173 466 minecraft:pearlescent_froglight
setblock 183 173 482 minecraft:magenta_stained_glass
fill 183 173 483 183 188 483 minecraft:end_stone_bricks
fill 183 173 500 183 196 500 minecraft:end_stone_bricks
fill 141 174 471 141 179 471 minecraft:end_stone_bricks
setblock 141 174 472 minecraft:pearlescent_froglight
setblock 141 174 475 minecraft:pearlescent_froglight
fill 141 174 477 141 187 477 minecraft:end_stone_bricks
fill 141 174 487 141 179 487 minecraft:end_stone_bricks
fill 141 174 503 141 179 503 minecraft:end_stone_bricks
fill 145 174 463 145 179 463 minecraft:end_stone_bricks
fill 155 174 505 155 179 505 minecraft:end_stone_bricks
setblock 157 174 463 minecraft:pearlescent_froglight
fill 158 174 463 158 196 463 minecraft:end_stone_bricks
fill 161 174 463 161 179 463 minecraft:end_stone_bricks
fill 171 174 505 171 179 505 minecraft:end_stone_bricks
fill 177 174 463 177 179 463 minecraft:end_stone_bricks
fill 183 174 466 183 193 466 minecraft:end_stone_bricks
fill 183 174 473 183 179 473 minecraft:end_stone_bricks
fill 183 174 482 183 196 482 minecraft:end_stone_bricks
fill 183 174 489 183 179 489 minecraft:end_stone_bricks
setblock 183 174 497 minecraft:pearlescent_froglight
fill 183 174 498 183 196 498 minecraft:end_stone_bricks
setblock 141 175 472 minecraft:end_stone_bricks
fill 141 175 475 141 196 475 minecraft:end_stone_bricks
fill 155 175 470 155 176 470 minecraft:magenta_stained_glass
fill 157 175 463 157 193 463 minecraft:end_stone_bricks
setblock 159 175 505 minecraft:white_concrete
fill 162 175 502 164 178 504 minecraft:magenta_stained_glass
fill 163 175 501 163 178 501 minecraft:magenta_stained_glass
setblock 175 175 463 minecraft:pearlescent_froglight
setblock 183 175 486 minecraft:pearlescent_froglight
fill 183 175 497 183 180 497 minecraft:end_stone_bricks
setblock 141 176 472 minecraft:pearlescent_froglight
setblock 141 176 481 minecraft:pearlescent_froglight
fill 149 176 482 149 177 482 minecraft:purpur_block
setblock 156 176 463 minecraft:pearlescent_froglight
fill 159 176 505 159 196 505 minecraft:end_stone_bricks
fill 161 176 503 161 177 503 minecraft:magenta_stained_glass
fill 162 176 499 162 177 501 minecraft:magenta_stained_glass
fill 163 176 498 163 177 500 minecraft:magenta_stained_glass
fill 164 176 499 164 177 501 minecraft:magenta_stained_glass
fill 165 176 503 165 177 503 minecraft:magenta_stained_glass
setblock 169 176 505 minecraft:magenta_stained_glass
fill 175 176 463 175 196 463 minecraft:end_stone_bricks
fill 183 176 486 183 196 486 minecraft:end_stone_bricks
fill 141 177 472 141 196 472 minecraft:end_stone_bricks
fill 141 177 481 141 185 481 minecraft:end_stone_bricks
setblock 144 177 466 minecraft:light[level=14]
setblock 144 177 474 minecraft:light[level=14]
setblock 144 177 482 minecraft:light[level=14]
setblock 144 177 490 minecraft:light[level=14]
setblock 144 177 498 minecraft:light[level=14]
fill 149 177 472 150 178 473 minecraft:end_stone
fill 150 177 474 150 178 474 minecraft:end_stone
setblock 152 177 466 minecraft:light[level=14]
setblock 152 177 474 minecraft:light[level=14]
setblock 152 177 482 minecraft:light[level=14]
setblock 152 177 490 minecraft:light[level=14]
setblock 152 177 498 minecraft:light[level=14]
setblock 153 177 505 minecraft:pearlescent_froglight
fill 155 177 470 155 185 470 minecraft:purpur_block
fill 156 177 463 156 194 463 minecraft:end_stone_bricks
setblock 160 177 466 minecraft:light[level=14]
setblock 160 177 474 minecraft:light[level=14]
setblock 160 177 482 minecraft:light[level=14]
setblock 160 177 490 minecraft:light[level=14]
setblock 160 177 498 minecraft:light[level=14]
setblock 163 177 497 minecraft:magenta_stained_glass
setblock 168 177 466 minecraft:light[level=14]
setblock 168 177 474 minecraft:light[level=14]
setblock 168 177 482 minecraft:light[level=14]
setblock 168 177 490 minecraft:light[level=14]
setblock 168 177 498 minecraft:light[level=14]
fill 169 177 505 169 194 505 minecraft:end_stone_bricks
setblock 172 177 463 minecraft:pearlescent_froglight
setblock 176 177 466 minecraft:light[level=14]
setblock 176 177 474 minecraft:light[level=14]
setblock 176 177 482 minecraft:light[level=14]
setblock 176 177 490 minecraft:light[level=14]
setblock 176 177 498 minecraft:light[level=14]
setblock 147 178 505 minecraft:white_concrete
fill 153 178 505 153 179 505 minecraft:end_stone_bricks
setblock 163 178 500 minecraft:magenta_stained_glass
fill 172 178 463 172 195 463 minecraft:end_stone_bricks
fill 141 179 499 141 180 499 minecraft:white_concrete
fill 147 179 505 147 184 505 minecraft:end_stone_bricks
fill 154 179 469 154 185 470 minecraft:purpur_block
fill 155 179 469 155 185 469 minecraft:purpur_block
setblock 183 179 467 minecraft:magenta_stained_glass
setblock 183 179 470 minecraft:white_concrete
fill 141 180 471 141 182 471 minecraft:magenta_concrete
fill 141 180 487 141 182 487 minecraft:magenta_concrete
fill 141 180 503 141 182 503 minecraft:magenta_concrete
fill 145 180 463 145 182 463 minecraft:magenta_concrete
setblock 153 180 505 minecraft:pearlescent_froglight
fill 154 180 471 155 185 471 minecraft:purpur_block
fill 155 180 505 155 182 505 minecraft:magenta_concrete
fill 156 180 469 156 185 470 minecraft:purpur_block
fill 161 180 463 161 182 463 minecraft:magenta_concrete
fill 171 180 505 171 182 505 minecraft:magenta_concrete
fill 177 180 463 177 182 463 minecraft:magenta_concrete
fill 183 180 467 183 196 467 minecraft:end_stone_bricks
fill 183 180 470 183 192 470 minecraft:end_stone_bricks
fill 183 180 473 183 182 473 minecraft:magenta_concrete
fill 183 180 489 183 182 489 minecraft:magenta_concrete
fill 141 181 499 141 194 499 minecraft:end_stone_bricks
fill 153 181 469 153 185 471 minecraft:purpur_block
fill 153 181 505 153 196 505 minecraft:end_stone_bricks
fill 154 181 468 155 185 468 minecraft:purpur_block
fill 156 181 471 156 185 471 minecraft:purpur_block
setblock 162 181 505 minecraft:magenta_stained_glass
fill 169 181 467 170 182 467 minecraft:purpur_block
setblock 174 181 463 minecraft:magenta_stained_glass
setblock 183 181 475 minecraft:white_concrete
setblock 183 181 497 minecraft:pearlescent_froglight
setblock 141 182 465 minecraft:magenta_stained_glass
fill 153 182 468 153 185 468 minecraft:purpur_block
fill 154 182 472 156 185 472 minecraft:purpur_block
fill 156 182 468 156 185 468 minecraft:purpur_block
setblock 156 182 505 minecraft:pearlescent_froglight
fill 157 182 469 157 185 471 minecraft:purpur_block
fill 162 182 505 162 196 505 minecraft:end_stone_bricks
fill 174 182 463 174 196 463 minecraft:end_stone_bricks
fill 183 182 475 183 191 475 minecraft:end_stone_bricks
fill 183 182 497 183 193 497 minecraft:end_stone_bricks
fill 141 183 465 141 196 465 minecraft:end_stone_bricks
setblock 141 183 468 minecraft:white_concrete
setblock 141 183 471 minecraft:magenta_stained_glass
fill 141 183 487 141 188 487 minecraft:end_stone_bricks
fill 141 183 503 141 188 503 minecraft:end_stone_bricks
fill 145 183 463 145 188 463 minecraft:end_stone_bricks
fill 152 183 469 152 185 471 minecraft:purpur_block
fill 153 183 472 153 185 472 minecraft:purpur_block
fill 154 183 467 155 185 467 minecraft:purpur_block
fill 155 183 505 156 188 505 minecraft:end_stone_bricks
fill 157 183 468 157 185 468 minecraft:purpur_block
fill 161 183 463 161 187 463 minecraft:end_stone_bricks
fill 171 183 505 171 188 505 minecraft:end_stone_bricks
fill 177 183 463 177 188 463 minecraft:end_stone_bricks
fill 183 183 473 183 188 473 minecraft:end_stone_bricks
setblock 183 183 484 minecraft:magenta_stained_glass
fill 183 183 489 183 188 489 minecraft:end_stone_bricks
fill 141 184 468 141 192 468 minecraft:end_stone_bricks
fill 141 184 471 141 188 471 minecraft:end_stone_bricks
fill 143 184 483 143 185 483 minecraft:obsidian
fill 152 184 468 152 185 468 minecraft:purpur_block
fill 152 184 472 152 185 472 minecraft:purpur_block
fill 153 184 467 153 185 467 minecraft:purpur_block
setblock 154 184 463 minecraft:white_concrete
fill 154 184 473 156 185 473 minecraft:purpur_block
fill 156 184 467 156 185 467 minecraft:purpur_block
fill 157 184 472 157 185 472 minecraft:purpur_block
fill 158 184 469 158 185 471 minecraft:purpur_block
fill 183 184 484 183 193 484 minecraft:end_stone_bricks
setblock 144 185 466 minecraft:light[level=14]
setblock 144 185 474 minecraft:light[level=14]
setblock 144 185 482 minecraft:light[level=14]
setblock 144 185 490 minecraft:light[level=14]
setblock 144 185 498 minecraft:light[level=14]
setblock 147 185 505 minecraft:magenta_stained_glass
fill 151 185 469 151 185 471 minecraft:purpur_block
setblock 152 185 466 minecraft:light[level=14]
setblock 152 185 467 minecraft:purpur_block
setblock 152 185 474 minecraft:light[level=14]
setblock 152 185 482 minecraft:light[level=14]
setblock 152 185 490 minecraft:light[level=14]
setblock 152 185 498 minecraft:light[level=14]
setblock 153 185 463 minecraft:pearlescent_froglight
setblock 153 185 473 minecraft:purpur_block
fill 154 185 463 154 196 463 minecraft:end_stone_bricks
fill 154 185 466 156 185 466 minecraft:purpur_block
setblock 157 185 467 minecraft:purpur_block
setblock 157 185 473 minecraft:purpur_block
setblock 158 185 468 minecraft:purpur_block
setblock 158 185 472 minecraft:purpur_block
setblock 160 185 466 minecraft:light[level=14]
setblock 160 185 474 minecraft:light[level=14]
setblock 160 185 482 minecraft:light[level=14]
setblock 160 185 490 minecraft:light[level=14]
setblock 160 185 498 minecraft:light[level=14]
setblock 168 185 466 minecraft:light[level=14]
setblock 168 185 474 minecraft:light[level=14]
setblock 168 185 482 minecraft:light[level=14]
setblock 168 185 490 minecraft:light[level=14]
setblock 168 185 498 minecraft:light[level=14]
setblock 176 185 466 minecraft:light[level=14]
setblock 176 185 474 minecraft:light[level=14]
setblock 176 185 482 minecraft:light[level=14]
setblock 176 185 490 minecraft:light[level=14]
setblock 176 185 498 minecraft:light[level=14]
setblock 183 185 474 minecraft:white_concrete
setblock 141 186 481 minecraft:magenta_stained_glass
setblock 141 186 500 minecraft:white_concrete
fill 147 186 505 147 196 505 minecraft:end_stone_bricks
fill 153 186 463 153 196 463 minecraft:end_stone_bricks
fill 154 186 468 154 190 468 minecraft:end_stone_bricks
fill 154 186 471 154 187 471 minecraft:end_stone_bricks
fill 156 186 470 156 189 470 minecraft:end_stone_bricks
fill 168 186 464 170 189 465 minecraft:magenta_stained_glass
fill 169 186 466 169 189 466 minecraft:magenta_stained_glass
setblock 170 186 505 minecraft:white_concrete
fill 183 186 474 183 194 474 minecraft:end_stone_bricks
fill 141 187 481 141 196 481 minecraft:end_stone_bricks
fill 141 187 500 141 196 500 minecraft:end_stone_bricks
setblock 162 187 463 minecraft:white_concrete
fill 167 187 464 167 188 465 minecraft:magenta_stained_glass
fill 168 187 466 168 189 466 minecraft:magenta_stained_glass
fill 169 187 467 169 189 467 minecraft:magenta_stained_glass
fill 170 187 466 170 189 466 minecraft:magenta_stained_glass
fill 170 187 505 170 192 505 minecraft:end_stone_bricks
fill 171 187 464 171 188 465 minecraft:magenta_stained_glass
setblock 183 187 499 minecraft:magenta_stained_glass
setblock 141 188 477 minecraft:magenta_stained_glass
setblock 141 188 497 minecraft:pearlescent_froglight
setblock 161 188 463 minecraft:pearlescent_froglight
fill 162 188 463 162 196 463 minecraft:end_stone_bricks
setblock 168 188 467 minecraft:magenta_stained_glass
fill 169 188 468 169 188 469 minecraft:magenta_stained_glass
setblock 170 188 467 minecraft:magenta_stained_glass
fill 183 188 499 183 196 499 minecraft:end_stone_bricks
fill 141 189 471 141 191 471 minecraft:magenta_concrete
fill 141 189 477 141 196 477 minecraft:end_stone_bricks
fill 141 189 487 141 191 487 minecraft:magenta_concrete
fill 141 189 497 141 196 497 minecraft:end_stone_bricks
fill 141 189 503 141 191 503 minecraft:magenta_concrete
fill 145 189 463 145 191 463 minecraft:magenta_concrete
fill 155 189 505 155 191 505 minecraft:magenta_concrete
fill 156 189 505 156 192 505 minecraft:end_stone_bricks
fill 161 189 463 161 191 463 minecraft:magenta_concrete
setblock 163 189 505 minecraft:white_concrete
setblock 169 189 468 minecraft:magenta_stained_glass
setblock 171 189 463 minecraft:pearlescent_froglight
fill 171 189 505 171 191 505 minecraft:magenta_concrete
fill 177 189 463 177 191 463 minecraft:magenta_concrete
setblock 179 189 505 minecraft:magenta_stained_glass
setblock 180 189 463 minecraft:white_concrete
fill 183 189 473 183 191 473 minecraft:magenta_concrete
setblock 183 189 483 minecraft:magenta_stained_glass
fill 183 189 489 183 191 489 minecraft:magenta_concrete
fill 163 190 505 163 196 505 minecraft:end_stone_bricks
fill 171 190 463 171 196 463 minecraft:end_stone_bricks
setblock 177 190 505 minecraft:white_concrete
setblock 178 190 463 minecraft:white_concrete
fill 179 190 505 179 196 505 minecraft:end_stone_bricks
fill 180 190 463 180 194 463 minecraft:end_stone_bricks
fill 183 190 483 183 196 483 minecraft:end_stone_bricks
setblock 141 191 498 minecraft:magenta_stained_glass
fill 177 191 505 177 194 505 minecraft:end_stone_bricks
fill 178 191 463 178 193 463 minecraft:end_stone_bricks
fill 141 192 471 141 196 471 minecraft:end_stone_bricks
fill 141 192 487 141 196 487 minecraft:end_stone_bricks
fill 141 192 498 141 196 498 minecraft:end_stone_bricks
setblock 141 192 503 minecraft:end_stone_bricks
setblock 145 192 463 minecraft:end_stone_bricks
fill 155 192 505 155 196 505 minecraft:end_stone_bricks
fill 161 192 463 161 196 463 minecraft:end_stone_bricks
fill 165 192 469 165 193 469 minecraft:magenta_stained_glass
fill 171 192 505 171 196 505 minecraft:end_stone_bricks
setblock 173 192 463 minecraft:magenta_stained_glass
fill 177 192 463 177 197 463 minecraft:end_stone_bricks
setblock 183 192 473 minecraft:end_stone_bricks
setblock 183 192 475 minecraft:white_concrete
fill 183 192 489 183 196 489 minecraft:end_stone_bricks
fill 141 193 468 141 194 468 minecraft:purpur_block
setblock 141 193 473 minecraft:pearlescent_froglight
setblock 141 193 474 minecraft:purpur_block
setblock 141 193 489 minecraft:white_concrete
setblock 141 193 491 minecraft:purpur_block
setblock 141 193 503 minecraft:purpur_block
setblock 143 193 505 minecraft:purpur_block
setblock 144 193 466 minecraft:light[level=14]
setblock 144 193 474 minecraft:light[level=14]
setblock 144 193 482 minecraft:light[level=14]
setblock 144 193 490 minecraft:light[level=14]
setblock 144 193 498 minecraft:light[level=14]
setblock 145 193 463 minecraft:purpur_block
setblock 145 193 505 minecraft:purpur_block
setblock 150 193 463 minecraft:purpur_block
setblock 152 193 466 minecraft:light[level=14]
setblock 152 193 474 minecraft:light[level=14]
setblock 152 193 482 minecraft:light[level=14]
setblock 152 193 490 minecraft:light[level=14]
setblock 152 193 498 minecraft:light[level=14]
setblock 156 193 505 minecraft:purpur_block
setblock 159 193 463 minecraft:purpur_block
setblock 160 193 466 minecraft:light[level=14]
setblock 160 193 474 minecraft:light[level=14]
setblock 160 193 482 minecraft:light[level=14]
setblock 160 193 490 minecraft:light[level=14]
setblock 160 193 498 minecraft:light[level=14]
fill 160 193 505 161 193 505 minecraft:purpur_block
setblock 164 193 505 minecraft:purpur_block
setblock 166 193 505 minecraft:purpur_block
setblock 168 193 466 minecraft:light[level=14]
setblock 168 193 474 minecraft:light[level=14]
setblock 168 193 482 minecraft:light[level=14]
setblock 168 193 490 minecraft:light[level=14]
setblock 168 193 498 minecraft:light[level=14]
setblock 170 193 505 minecraft:purpur_block
fill 173 193 463 173 196 463 minecraft:end_stone_bricks
setblock 176 193 466 minecraft:light[level=14]
setblock 176 193 474 minecraft:light[level=14]
setblock 176 193 482 minecraft:light[level=14]
setblock 176 193 490 minecraft:light[level=14]
setblock 176 193 498 minecraft:light[level=14]
fill 183 193 469 183 193 470 minecraft:purpur_block
setblock 183 193 473 minecraft:magenta_stained_glass
fill 183 193 475 183 196 475 minecraft:end_stone_bricks
setblock 183 193 476 minecraft:purpur_block
setblock 183 193 479 minecraft:purpur_block
fill 183 193 501 183 193 502 minecraft:white_concrete
fill 141 194 473 141 196 474 minecraft:end_stone_bricks
setblock 141 194 486 minecraft:purpur_block
fill 141 194 489 141 196 489 minecraft:end_stone_bricks
fill 141 194 491 141 196 491 minecraft:end_stone_bricks
fill 141 194 496 141 195 496 minecraft:purpur_block
fill 141 194 503 141 196 503 minecraft:end_stone_bricks
setblock 141 194 504 minecraft:purpur_block
fill 143 194 505 143 196 505 minecraft:end_stone_bricks
fill 145 194 463 145 196 463 minecraft:end_stone_bricks
fill 145 194 505 145 196 505 minecraft:end_stone_bricks
fill 149 194 505 150 194 505 minecraft:end_stone_bricks
fill 150 194 463 150 196 463 minecraft:end_stone_bricks
fill 151 194 505 152 194 505 minecraft:purpur_block
fill 152 194 463 152 195 463 minecraft:purpur_block
fill 155 194 468 156 195 469 minecraft:obsidian
fill 156 194 505 156 196 505 minecraft:end_stone_bricks
setblock 157 194 463 minecraft:purpur_block
fill 159 194 463 159 196 463 minecraft:end_stone_bricks
fill 160 194 505 161 196 505 minecraft:end_stone_bricks
fill 164 194 505 164 196 505 minecraft:end_stone_bricks
fill 165 194 469 165 199 469 minecraft:purpur_block
fill 166 194 505 166 197 505 minecraft:end_stone_bricks
fill 170 194 505 170 196 505 minecraft:end_stone_bricks
setblock 175 194 505 minecraft:purpur_block
setblock 178 194 463 minecraft:purpur_block
setblock 183 194 463 minecraft:purpur_block
setblock 183 194 466 minecraft:purpur_block
fill 183 194 469 183 194 470 minecraft:end_stone_bricks
fill 183 194 473 183 196 473 minecraft:end_stone_bricks
setblock 183 194 476 minecraft:end_stone_bricks
setblock 183 194 479 minecraft:white_concrete
setblock 183 194 481 minecraft:purpur_block
setblock 183 194 484 minecraft:white_concrete
setblock 183 194 497 minecraft:purpur_block
fill 183 194 501 183 196 502 minecraft:end_stone_bricks
fill 141 195 468 141 196 468 minecraft:end_stone_bricks
setblock 141 195 470 minecraft:purpur_block
fill 141 195 486 141 196 486 minecraft:end_stone_bricks
setblock 141 195 490 minecraft:purpur_block
setblock 141 195 499 minecraft:purpur_block
setblock 141 195 501 minecraft:purpur_block
fill 141 195 504 141 196 504 minecraft:end_stone_bricks
setblock 146 195 463 minecraft:purpur_block
setblock 149 195 505 minecraft:purpur_block
fill 150 195 505 152 196 505 minecraft:end_stone_bricks
setblock 151 195 463 minecraft:purpur_block
setblock 156 195 463 minecraft:purpur_block
fill 157 195 463 157 196 463 minecraft:end_stone_bricks
setblock 160 195 463 minecraft:purpur_block
setblock 164 195 463 minecraft:purpur_block
setblock 166 195 463 minecraft:purpur_block
setblock 169 195 505 minecraft:purpur_block
setblock 170 195 463 minecraft:purpur_block
setblock 174 195 505 minecraft:purpur_block
fill 175 195 505 175 196 505 minecraft:end_stone_bricks
setblock 177 195 505 minecraft:purpur_block
fill 178 195 463 178 196 463 minecraft:end_stone_bricks
setblock 180 195 463 minecraft:purpur_block
setblock 182 195 463 minecraft:purpur_block
fill 183 195 463 183 196 463 minecraft:end_stone_bricks
fill 183 195 466 183 196 466 minecraft:end_stone_bricks
setblock 183 195 469 minecraft:purpur_block
fill 183 195 470 183 196 470 minecraft:end_stone_bricks
setblock 183 195 474 minecraft:purpur_block
setblock 183 195 476 minecraft:purpur_block
fill 183 195 479 183 197 479 minecraft:end_stone_bricks
fill 183 195 481 183 196 481 minecraft:end_stone_bricks
fill 183 195 484 183 196 484 minecraft:end_stone_bricks
fill 183 195 497 183 196 497 minecraft:end_stone_bricks
setblock 141 196 470 minecraft:end_stone_bricks
setblock 141 196 490 minecraft:end_stone_bricks
fill 141 196 496 141 198 496 minecraft:end_stone_bricks
setblock 141 196 499 minecraft:end_stone_bricks
setblock 141 196 501 minecraft:end_stone_bricks
fill 145 196 490 145 197 491 minecraft:purpur_block
setblock 146 196 463 minecraft:end_stone_bricks
setblock 149 196 505 minecraft:end_stone_bricks
fill 151 196 463 152 196 463 minecraft:end_stone_bricks
setblock 156 196 463 minecraft:end_stone_bricks
setblock 160 196 463 minecraft:end_stone_bricks
setblock 164 196 463 minecraft:end_stone_bricks
fill 164 196 469 164 199 469 minecraft:purpur_block
fill 165 196 468 165 199 468 minecraft:purpur_block
fill 165 196 470 165 199 470 minecraft:purpur_block
setblock 166 196 463 minecraft:end_stone_bricks
fill 166 196 469 166 199 469 minecraft:purpur_block
setblock 169 196 505 minecraft:end_stone_bricks
setblock 170 196 463 minecraft:end_stone_bricks
setblock 172 196 463 minecraft:magenta_stained_glass
setblock 174 196 505 minecraft:end_stone_bricks
setblock 177 196 505 minecraft:end_stone_bricks
fill 180 196 463 180 198 463 minecraft:end_stone_bricks
setblock 182 196 463 minecraft:end_stone_bricks
setblock 183 196 469 minecraft:end_stone_bricks
setblock 183 196 474 minecraft:end_stone_bricks
setblock 183 196 476 minecraft:end_stone_bricks
fill 141 197 463 141 197 481 minecraft:purpur_block
fill 141 197 484 141 197 491 minecraft:purpur_block
fill 141 197 493 141 215 495 minecraft:purpur_block
fill 141 197 497 141 197 505 minecraft:purpur_block
fill 142 197 463 146 197 463 minecraft:purpur_block
fill 143 197 505 145 198 505 minecraft:purpur_block
setblock 146 197 505 minecraft:pearlescent_froglight
fill 147 197 505 165 197 505 minecraft:purpur_block
fill 148 197 463 151 198 463 minecraft:purpur_block
setblock 152 197 463 minecraft:end_stone_bricks
fill 153 197 463 154 198 463 minecraft:purpur_block
fill 156 197 463 176 197 463 minecraft:purpur_block
fill 164 197 468 164 199 468 minecraft:purpur_block
fill 164 197 470 164 199 470 minecraft:purpur_block
fill 166 197 468 166 199 468 minecraft:purpur_block
fill 166 197 470 166 199 470 minecraft:purpur_block
fill 167 197 505 172 197 505 minecraft:purpur_block
fill 174 197 505 177 197 505 minecraft:purpur_block
fill 178 197 463 179 197 463 minecraft:purpur_block
fill 179 197 505 179 230 505 minecraft:purpur_block
fill 181 197 463 183 197 463 minecraft:purpur_block
fill 181 197 505 181 250 505 minecraft:purpur_block
fill 183 197 464 183 198 464 minecraft:purpur_block
fill 183 197 466 183 197 477 minecraft:purpur_block
fill 183 197 480 183 197 492 minecraft:purpur_block
setblock 183 197 493 minecraft:pearlescent_froglight
fill 183 197 494 183 197 504 minecraft:purpur_block
fill 141 198 463 141 207 465 minecraft:purpur_block
setblock 141 198 466 minecraft:end_stone_bricks
fill 141 198 467 141 202 470 minecraft:purpur_block
fill 141 198 471 141 200 471 minecraft:magenta_concrete
fill 141 198 472 141 198 486 minecraft:purpur_block
fill 141 198 487 141 200 487 minecraft:magenta_concrete
fill 141 198 488 141 276 488 minecraft:purpur_block
setblock 141 198 489 minecraft:end_stone_bricks
fill 141 198 490 141 198 492 minecraft:purpur_block
fill 141 198 497 141 198 502 minecraft:purpur_block
fill 141 198 503 141 200 503 minecraft:magenta_concrete
fill 141 198 504 141 292 505 minecraft:purpur_block
fill 142 198 463 144 198 463 minecraft:purpur_block
fill 142 198 505 142 247 505 minecraft:purpur_block
fill 145 198 463 145 200 463 minecraft:magenta_concrete
fill 146 198 463 147 274 463 minecraft:purpur_block
fill 146 198 505 154 198 505 minecraft:purpur_block
fill 152 198 463 152 220 463 minecraft:purpur_block
fill 155 198 463 160 208 463 minecraft:purpur_block
fill 155 198 505 155 200 505 minecraft:magenta_concrete
fill 156 198 505 170 198 505 minecraft:purpur_block
fill 161 198 463 161 200 463 minecraft:magenta_concrete
fill 162 198 463 176 198 463 minecraft:purpur_block
fill 163 198 469 163 199 469 minecraft:purpur_block
fill 165 198 467 165 199 467 minecraft:purpur_block
fill 165 198 471 166 199 471 minecraft:purpur_block
fill 167 198 469 167 199 470 minecraft:purpur_block
fill 171 198 505 171 200 505 minecraft:magenta_concrete
fill 172 198 505 174 207 505 minecraft:purpur_block
setblock 175 198 505 minecraft:end_stone_bricks
fill 176 198 505 177 202 505 minecraft:purpur_block
fill 177 198 463 177 200 463 minecraft:magenta_concrete
fill 178 198 463 178 209 463 minecraft:purpur_block
setblock 179 198 463 minecraft:end_stone_bricks
fill 180 198 505 180 214 505 minecraft:purpur_block
fill 181 198 463 182 212 463 minecraft:purpur_block
fill 182 198 505 183 198 505 minecraft:purpur_block
fill 183 198 463 183 199 463 minecraft:end_stone_bricks
fill 183 198 466 183 228 469 minecraft:purpur_block
fill 183 198 470 183 198 471 minecraft:end_stone_bricks
fill 183 198 472 183 241 472 minecraft:purpur_block
fill 183 198 473 183 200 473 minecraft:magenta_concrete
fill 183 198 474 183 199 488 minecraft:purpur_block
fill 183 198 489 183 200 489 minecraft:magenta_concrete
fill 183 198 490 183 242 492 minecraft:purpur_block
setblock 183 198 493 minecraft:end_stone_bricks
fill 183 198 494 183 198 499 minecraft:purpur_block
fill 183 198 500 183 198 501 minecraft:end_stone_bricks
fill 183 198 502 183 218 504 minecraft:purpur_block
fill 141 199 466 141 223 466 minecraft:purpur_block
fill 141 199 472 141 207 479 minecraft:purpur_block
setblock 141 199 480 minecraft:pearlescent_froglight
setblock 141 199 481 minecraft:end_stone_bricks
fill 141 199 482 141 202 484 minecraft:purpur_block
setblock 141 199 485 minecraft:end_stone_bricks
fill 141 199 486 141 202 486 minecraft:purpur_block
fill 141 199 489 141 202 490 minecraft:purpur_block
fill 141 199 491 141 199 492 minecraft:end_stone_bricks
fill 141 199 496 141 223 499 minecraft:purpur_block
setblock 141 199 500 minecraft:end_stone_bricks
fill 141 199 501 141 200 502 minecraft:purpur_block
fill 142 199 463 143 199 463 minecraft:end_stone_bricks
setblock 143 199 505 minecraft:end_stone_bricks
setblock 144 199 463 minecraft:purpur_block
fill 144 199 505 145 280 505 minecraft:purpur_block
setblock 146 199 505 minecraft:end_stone_bricks
fill 147 199 505 153 200 505 minecraft:purpur_block
fill 148 199 463 150 212 463 minecraft:purpur_block
setblock 151 199 463 minecraft:end_stone_bricks
fill 153 199 463 153 229 463 minecraft:purpur_block
setblock 154 199 463 minecraft:end_stone_bricks
setblock 154 199 505 minecraft:end_stone_bricks
fill 156 199 505 159 233 505 minecraft:purpur_block
setblock 160 199 505 minecraft:end_stone_bricks
fill 161 199 505 170 210 505 minecraft:purpur_block
fill 162 199 463 169 213 463 minecraft:purpur_block
setblock 163 199 468 minecraft:purpur_block
setblock 163 199 470 minecraft:purpur_block
setblock 164 199 467 minecraft:purpur_block
setblock 164 199 471 minecraft:purpur_block
setblock 166 199 467 minecraft:purpur_block
setblock 167 199 468 minecraft:purpur_block
setblock 170 199 463 minecraft:end_stone_bricks
fill 171 199 463 172 270 463 minecraft:purpur_block
setblock 173 199 463 minecraft:end_stone_bricks
fill 174 199 463 176 201 463 minecraft:purpur_block
fill 175 199 505 175 262 505 minecraft:purpur_block
fill 178 199 505 178 307 505 minecraft:purpur_block
fill 179 199 463 180 204 463 minecraft:purpur_block
setblock 182 199 505 minecraft:end_stone_bricks
setblock 183 199 464 minecraft:end_stone_bricks
setblock 183 199 465 minecraft:purpur_block
fill 183 199 470 183 295 471 minecraft:purpur_block
fill 183 199 493 183 201 496 minecraft:purpur_block
setblock 183 199 497 minecraft:end_stone_bricks
fill 183 199 498 183 214 501 minecraft:purpur_block
fill 183 199 505 183 307 505 minecraft:purpur_block
fill 141 200 480 141 260 481 minecraft:purpur_block
fill 141 200 485 141 307 485 minecraft:purpur_block
fill 141 200 491 141 237 492 minecraft:purpur_block
fill 141 200 500 141 225 500 minecraft:purpur_block
fill 142 200 463 143 206 463 minecraft:purpur_block
fill 143 200 505 143 307 505 minecraft:purpur_block
setblock 144 200 463 minecraft:white_concrete
fill 146 200 505 146 202 505 minecraft:purpur_block
fill 151 200 463 151 297 463 minecraft:purpur_block
fill 154 200 463 154 305 463 minecraft:purpur_block
fill 154 200 505 154 237 505 minecraft:purpur_block
fill 160 200 505 160 307 505 minecraft:purpur_block
fill 164 200 470 164 202 470 minecraft:end_stone_bricks
fill 165 200 467 165 203 467 minecraft:end_stone_bricks
fill 166 200 470 166 201 470 minecraft:end_stone_bricks
fill 170 200 463 170 205 463 minecraft:purpur_block
fill 173 200 463 173 256 463 minecraft:purpur_block
fill 182 200 505 182 307 505 minecraft:purpur_block
fill 183 200 463 183 256 464 minecraft:purpur_block
setblock 183 200 465 minecraft:white_concrete
fill 183 200 474 183 221 475 minecraft:purpur_block
setblock 183 200 476 minecraft:white_concrete
fill 183 200 477 183 202 488 minecraft:purpur_block
fill 183 200 497 183 307 497 minecraft:purpur_block
fill 141 201 471 141 206 471 minecraft:purpur_block
fill 141 201 487 141 206 487 minecraft:purpur_block
fill 141 201 501 141 307 501 minecraft:purpur_block
setblock 141 201 502 minecraft:pearlescent_froglight
fill 141 201 503 141 206 503 minecraft:purpur_block
fill 144 201 463 145 206 463 minecraft:purpur_block
setblock 144 201 466 minecraft:light[level=14]
setblock 144 201 474 minecraft:light[level=14]
setblock 144 201 482 minecraft:light[level=14]
setblock 144 201 490 minecraft:light[level=14]
setblock 144 201 498 minecraft:light[level=14]
fill 147 201 505 147 202 505 minecraft:purpur_block
setblock 148 201 505 minecraft:pearlescent_froglight
fill 149 201 505 153 227 505 minecraft:purpur_block
setblock 152 201 466 minecraft:light[level=14]
setblock 152 201 474 minecraft:light[level=14]
setblock 152 201 482 minecraft:light[level=14]
setblock 152 201 490 minecraft:light[level=14]
setblock 152 201 498 minecraft:light[level=14]
fill 155 201 505 155 206 505 minecraft:purpur_block
setblock 160 201 466 minecraft:light[level=14]
setblock 160 201 474 minecraft:light[level=14]
setblock 160 201 482 minecraft:light[level=14]
setblock 160 201 490 minecraft:light[level=14]
setblock 160 201 498 minecraft:light[level=14]
fill 161 201 463 161 202 463 minecraft:purpur_block
setblock 168 201 466 minecraft:light[level=14]
setblock 168 201 474 minecraft:light[level=14]
setblock 168 201 482 minecraft:light[level=14]
setblock 168 201 490 minecraft:light[level=14]
setblock 168 201 498 minecraft:light[level=14]
fill 171 201 505 171 206 505 minecraft:purpur_block
setblock 176 201 466 minecraft:light[level=14]
setblock 176 201 474 minecraft:light[level=14]
setblock 176 201 482 minecraft:light[level=14]
setblock 176 201 490 minecraft:light[level=14]
setblock 176 201 498 minecraft:light[level=14]
fill 177 201 463 177 206 463 minecraft:purpur_block
fill 183 201 465 183 226 465 minecraft:purpur_block
fill 183 201 473 183 206 473 minecraft:purpur_block
fill 183 201 476 183 307 476 minecraft:purpur_block
fill 183 201 489 183 206 489 minecraft:purpur_block
fill 141 202 502 141 219 502 minecraft:purpur_block
fill 148 202 505 148 307 505 minecraft:purpur_block
fill 163 202 474 164 203 475 minecraft:purpur_block
setblock 174 202 463 minecraft:pearlescent_froglight
fill 175 202 463 176 213 463 minecraft:purpur_block
fill 183 202 493 183 205 493 minecraft:purpur_block
setblock 183 202 494 minecraft:pearlescent_froglight
fill 183 202 495 183 264 496 minecraft:purpur_block
setblock 141 203 467 minecraft:magenta_stained_glass
fill 141 203 468 141 204 470 minecraft:purpur_block
fill 141 203 482 141 206 482 minecraft:purpur_block
setblock 141 203 483 minecraft:pearlescent_froglight
fill 141 203 484 141 307 484 minecraft:purpur_block
setblock 141 203 486 minecraft:pearlescent_froglight
fill 141 203 489 141 249 489 minecraft:purpur_block
setblock 141 203 490 minecraft:magenta_stained_glass
fill 146 203 505 147 203 505 minecraft:white_concrete
setblock 161 203 463 minecraft:white_concrete
fill 174 203 463 174 236 463 minecraft:purpur_block
fill 176 203 505 176 262 505 minecraft:purpur_block
setblock 177 203 505 minecraft:pearlescent_froglight
fill 183 203 477 183 203 479 minecraft:purpur_block
setblock 183 203 480 minecraft:magenta_stained_glass
fill 183 203 481 183 206 488 minecraft:purpur_block
fill 183 203 494 183 251 494 minecraft:purpur_block
fill 141 204 467 141 240 467 minecraft:purpur_block
fill 141 204 483 141 244 483 minecraft:purpur_block
fill 141 204 486 141 207 486 minecraft:purpur_block
fill 141 204 490 141 285 490 minecraft:purpur_block
fill 146 204 505 147 233 505 minecraft:purpur_block
fill 161 204 463 161 206 463 minecraft:purpur_block
fill 177 204 505 177 216 505 minecraft:purpur_block
fill 183 204 477 183 241 477 minecraft:purpur_block
setblock 183 204 478 minecraft:magenta_stained_glass
fill 183 204 479 183 237 480 minecraft:purpur_block
setblock 141 205 468 minecraft:white_concrete
fill 141 205 469 141 208 470 minecraft:purpur_block
fill 179 205 463 179 286 463 minecraft:purpur_block
setblock 180 205 463 minecraft:white_concrete
fill 183 205 478 183 307 478 minecraft:purpur_block
fill 141 206 468 141 262 468 minecraft:purpur_block
setblock 170 206 463 minecraft:white_concrete
fill 180 206 463 180 307 463 minecraft:purpur_block
setblock 183 206 493 minecraft:white_concrete
fill 141 207 471 141 209 471 minecraft:magenta_concrete
setblock 141 207 482 minecraft:white_concrete
fill 141 207 487 141 209 487 minecraft:magenta_concrete
fill 141 207 503 141 209 503 minecraft:magenta_concrete
fill 142 207 463 142 211 463 minecraft:purpur_block
setblock 143 207 463 minecraft:magenta_stained_glass
fill 144 207 463 144 307 463 minecraft:purpur_block
fill 145 207 463 145 209 463 minecraft:magenta_concrete
fill 148 207 489 148 208 490 minecraft:purpur_block
fill 155 207 505 155 209 505 minecraft:magenta_concrete
fill 161 207 463 161 209 463 minecraft:magenta_concrete
fill 170 207 463 170 307 463 minecraft:purpur_block
fill 171 207 505 171 209 505 minecraft:magenta_concrete
fill 177 207 463 177 209 463 minecraft:magenta_concrete
fill 183 207 473 183 209 473 minecraft:magenta_concrete
fill 183 207 481 183 217 482 minecraft:purpur_block
setblock 183 207 483 minecraft:magenta_stained_glass
fill 183 207 484 183 210 488 minecraft:purpur_block
fill 183 207 489 183 209 489 minecraft:magenta_concrete
fill 183 207 493 183 214 493 minecraft:purpur_block
fill 141 208 463 141 223 464 minecraft:purpur_block
setblock 141 208 465 minecraft:pearlescent_froglight
fill 141 208 472 141 220 474 minecraft:purpur_block
setblock 141 208 475 minecraft:magenta_stained_glass
fill 141 208 476 141 208 479 minecraft:purpur_block
fill 141 208 482 141 307 482 minecraft:purpur_block
setblock 141 208 486 minecraft:white_concrete
fill 143 208 463 143 257 463 minecraft:purpur_block
fill 172 208 505 173 221 505 minecraft:purpur_block
setblock 174 208 505 minecraft:white_concrete
fill 183 208 483 183 307 483 minecraft:purpur_block
fill 141 209 465 141 307 465 minecraft:purpur_block
setblock 141 209 469 minecraft:magenta_stained_glass
fill 141 209 470 141 307 470 minecraft:purpur_block
fill 141 209 475 141 258 478 minecraft:purpur_block
setblock 141 209 479 minecraft:pearlescent_froglight
fill 141 209 486 141 237 486 minecraft:purpur_block
setblock 144 209 466 minecraft:light[level=14]
setblock 144 209 474 minecraft:light[level=14]
setblock 144 209 482 minecraft:light[level=14]
setblock 144 209 490 minecraft:light[level=14]
setblock 144 209 498 minecraft:light[level=14]
fill 149 209 486 151 210 486 minecraft:end_stone
fill 150 209 485 150 210 485 minecraft:end_stone
fill 150 209 487 150 210 487 minecraft:end_stone
setblock 152 209 466 minecraft:light[level=14]
setblock 152 209 474 minecraft:light[level=14]
setblock 152 209 482 minecraft:light[level=14]
setblock 152 209 490 minecraft:light[level=14]
setblock 152 209 498 minecraft:light[level=14]
fill 155 209 463 157 210 463 minecraft:purpur_block
setblock 158 209 463 minecraft:white_concrete
fill 159 209 463 159 307 463 minecraft:purpur_block
setblock 160 209 463 minecraft:white_concrete
setblock 160 209 466 minecraft:light[level=14]
setblock 160 209 474 minecraft:light[level=14]
setblock 160 209 482 minecraft:light[level=14]
setblock 160 209 490 minecraft:light[level=14]
setblock 160 209 498 minecraft:light[level=14]
setblock 168 209 466 minecraft:light[level=14]
setblock 168 209 474 minecraft:light[level=14]
setblock 168 209 482 minecraft:light[level=14]
setblock 168 209 490 minecraft:light[level=14]
setblock 168 209 498 minecraft:light[level=14]
fill 174 209 505 174 223 505 minecraft:purpur_block
setblock 176 209 466 minecraft:light[level=14]
setblock 176 209 474 minecraft:light[level=14]
setblock 176 209 482 minecraft:light[level=14]
setblock 176 209 490 minecraft:light[level=14]
setblock 176 209 498 minecraft:light[level=14]
fill 141 210 469 141 221 469 minecraft:purpur_block
fill 141 210 471 141 215 471 minecraft:purpur_block
fill 141 210 479 141 307 479 minecraft:purpur_block
fill 141 210 487 141 215 487 minecraft:purpur_block
fill 141 210 503 141 215 503 minecraft:purpur_block
fill 145 210 463 145 215 463 minecraft:purpur_block
fill 155 210 505 155 215 505 minecraft:purpur_block
fill 158 210 463 158 231 463 minecraft:purpur_block
fill 160 210 463 161 215 463 minecraft:purpur_block
fill 171 210 505 171 215 505 minecraft:purpur_block
fill 177 210 463 177 215 463 minecraft:purpur_block
setblock 178 210 463 minecraft:magenta_stained_glass
fill 183 210 473 183 215 473 minecraft:purpur_block
fill 183 210 489 183 215 489 minecraft:purpur_block
fill 147 211 488 148 212 489 minecraft:end_stone
fill 148 211 490 148 212 490 minecraft:end_stone
fill 155 211 463 156 231 463 minecraft:purpur_block
setblock 157 211 463 minecraft:magenta_stained_glass
fill 161 211 505 162 225 505 minecraft:purpur_block
setblock 163 211 505 minecraft:white_concrete
fill 164 211 505 170 216 505 minecraft:purpur_block
fill 178 211 463 178 240 463 minecraft:purpur_block
fill 183 211 484 183 221 485 minecraft:purpur_block
setblock 183 211 486 minecraft:white_concrete
fill 183 211 487 183 301 488 minecraft:purpur_block
setblock 142 212 463 minecraft:magenta_stained_glass
fill 157 212 463 157 214 463 minecraft:purpur_block
fill 163 212 505 163 222 505 minecraft:purpur_block
fill 183 212 486 183 214 486 minecraft:purpur_block
fill 142 213 463 142 272 463 minecraft:purpur_block
fill 148 213 463 149 227 463 minecraft:purpur_block
setblock 150 213 463 minecraft:magenta_stained_glass
setblock 181 213 463 minecraft:pearlescent_froglight
fill 182 213 463 182 252 463 minecraft:purpur_block
fill 150 214 463 150 254 463 minecraft:purpur_block
fill 155 214 475 156 215 476 minecraft:obsidian
fill 162 214 463 163 256 463 minecraft:purpur_block
setblock 164 214 463 minecraft:magenta_stained_glass
fill 165 214 463 169 216 463 minecraft:purpur_block
fill 175 214 463 175 307 463 minecraft:purpur_block
setblock 176 214 463 minecraft:magenta_stained_glass
fill 181 214 463 181 220 463 minecraft:purpur_block
setblock 157 215 463 minecraft:pearlescent_froglight
fill 164 215 463 164 221 463 minecraft:purpur_block
fill 176 215 463 176 219 463 minecraft:purpur_block
setblock 180 215 505 minecraft:pearlescent_froglight
setblock 183 215 486 minecraft:pearlescent_froglight
setblock 183 215 493 minecraft:magenta_stained_glass
fill 183 215 498 183 246 499 minecraft:purpur_block
setblock 183 215 500 minecraft:magenta_stained_glass
fill 183 215 501 183 247 501 minecraft:purpur_block
fill 141 216 471 141 217 471 minecraft:magenta_concrete
fill 141 216 487 141 217 487 minecraft:magenta_concrete
fill 141 216 493 141 295 494 minecraft:purpur_block
setblock 141 216 495 minecraft:white_concrete
fill 141 216 503 141 217 503 minecraft:magenta_concrete
fill 145 216 463 145 217 463 minecraft:magenta_concrete
fill 155 216 505 155 217 505 minecraft:magenta_concrete
fill 157 216 463 157 220 463 minecraft:purpur_block
fill 160 216 463 160 304 463 minecraft:purpur_block
fill 161 216 463 161 217 463 minecraft:magenta_concrete
fill 171 216 505 171 217 505 minecraft:magenta_concrete
fill 177 216 463 177 217 463 minecraft:magenta_concrete
fill 180 216 505 180 237 505 minecraft:purpur_block
fill 183 216 473 183 217 473 minecraft:magenta_concrete
fill 183 216 486 183 292 486 minecraft:purpur_block
fill 183 216 489 183 217 489 minecraft:magenta_concrete
fill 183 216 493 183 220 493 minecraft:purpur_block
fill 183 216 500 183 231 500 minecraft:purpur_block
fill 141 217 495 141 253 495 minecraft:purpur_block
setblock 144 217 466 minecraft:light[level=14]
setblock 144 217 474 minecraft:light[level=14]
setblock 144 217 482 minecraft:light[level=14]
setblock 144 217 490 minecraft:light[level=14]
setblock 144 217 498 minecraft:light[level=14]
setblock 152 217 466 minecraft:light[level=14]
setblock 152 217 474 minecraft:light[level=14]
setblock 152 217 482 minecraft:light[level=14]
setblock 152 217 490 minecraft:light[level=14]
setblock 152 217 498 minecraft:light[level=14]
setblock 160 217 466 minecraft:light[level=14]
setblock 160 217 474 minecraft:light[level=14]
setblock 160 217 482 minecraft:light[level=14]
setblock 160 217 490 minecraft:light[level=14]
setblock 160 217 498 minecraft:light[level=14]
fill 164 217 505 164 307 505 minecraft:purpur_block
fill 165 217 463 165 221 463 minecraft:purpur_block
setblock 165 217 505 minecraft:magenta_stained_glass
setblock 166 217 463 minecraft:magenta_stained_glass
fill 166 217 505 170 238 505 minecraft:purpur_block
fill 167 217 463 169 227 463 minecraft:purpur_block
setblock 168 217 466 minecraft:light[level=14]
setblock 168 217 474 minecraft:light[level=14]
setblock 168 217 482 minecraft:light[level=14]
setblock 168 217 490 minecraft:light[level=14]
setblock 168 217 498 minecraft:light[level=14]
setblock 176 217 466 minecraft:light[level=14]
setblock 176 217 474 minecraft:light[level=14]
setblock 176 217 482 minecraft:light[level=14]
setblock 176 217 490 minecraft:light[level=14]
setblock 176 217 498 minecraft:light[level=14]
setblock 177 217 505 minecraft:white_concrete
fill 141 218 471 141 222 471 minecraft:purpur_block
fill 141 218 487 141 222 487 minecraft:purpur_block
fill 141 218 503 141 233 503 minecraft:purpur_block
fill 145 218 463 145 219 463 minecraft:purpur_block
fill 155 218 505 155 233 505 minecraft:purpur_block
setblock 161 218 463 minecraft:white_concrete
fill 165 218 505 165 239 505 minecraft:purpur_block
fill 166 218 463 166 248 463 minecraft:purpur_block
fill 171 218 505 171 231 505 minecraft:purpur_block
fill 177 218 463 177 233 463 minecraft:purpur_block
fill 177 218 505 177 257 505 minecraft:purpur_block
fill 183 218 473 183 233 473 minecraft:purpur_block
setblock 183 218 481 minecraft:white_concrete
fill 183 218 482 183 249 482 minecraft:purpur_block
fill 183 218 489 183 233 489 minecraft:purpur_block
fill 161 219 463 161 231 463 minecraft:purpur_block
fill 183 219 481 183 307 481 minecraft:purpur_block
fill 183 219 502 183 255 503 minecraft:purpur_block
setblock 183 219 504 minecraft:magenta_stained_glass
setblock 141 220 502 minecraft:pearlescent_froglight
setblock 145 220 463 minecraft:magenta_stained_glass
setblock 176 220 463 minecraft:pearlescent_froglight
fill 183 220 504 183 307 504 minecraft:purpur_block
fill 141 221 472 141 222 472 minecraft:purpur_block
setblock 141 221 473 minecraft:pearlescent_froglight
fill 141 221 474 141 307 474 minecraft:purpur_block
fill 141 221 502 141 225 502 minecraft:purpur_block
fill 145 221 463 145 233 463 minecraft:purpur_block
setblock 152 221 463 minecraft:pearlescent_froglight
setblock 157 221 463 minecraft:white_concrete
fill 176 221 463 176 284 463 minecraft:purpur_block
setblock 181 221 463 minecraft:pearlescent_froglight
setblock 183 221 493 minecraft:white_concrete
setblock 141 222 469 minecraft:magenta_stained_glass
fill 141 222 473 141 246 473 minecraft:purpur_block
fill 152 222 463 152 307 463 minecraft:purpur_block
fill 157 222 463 157 307 463 minecraft:purpur_block
fill 164 222 463 165 222 463 minecraft:white_concrete
fill 172 222 505 172 263 505 minecraft:purpur_block
setblock 173 222 505 minecraft:magenta_stained_glass
fill 181 222 463 181 307 463 minecraft:purpur_block
setblock 183 222 474 minecraft:pearlescent_froglight
fill 183 222 475 183 307 475 minecraft:purpur_block
setblock 183 222 484 minecraft:white_concrete
fill 183 222 485 183 307 485 minecraft:purpur_block
fill 183 222 493 183 275 493 minecraft:purpur_block
fill 141 223 469 141 275 469 minecraft:purpur_block
fill 141 223 471 141 223 472 minecraft:magenta_stained_glass
setblock 141 223 487 minecraft:magenta_stained_glass
fill 151 223 486 158 223 486 minecraft:end_stone
fill 152 223 482 159 223 485 minecraft:end_stone
fill 152 223 487 159 223 490 minecraft:end_stone
fill 153 223 480 169 223 481 minecraft:end_stone
fill 153 223 491 169 223 492 minecraft:end_stone
fill 154 223 479 168 223 479 minecraft:end_stone
fill 154 223 493 168 223 493 minecraft:end_stone
fill 155 223 478 167 223 478 minecraft:end_stone
fill 155 223 494 167 223 494 minecraft:end_stone
fill 157 223 477 165 223 477 minecraft:end_stone
fill 157 223 495 165 223 495 minecraft:end_stone
fill 160 223 482 160 223 484 minecraft:end_stone
fill 160 223 488 160 223 490 minecraft:end_stone
setblock 161 223 476 minecraft:end_stone
fill 161 223 482 170 223 483 minecraft:end_stone
fill 161 223 489 170 223 490 minecraft:end_stone
setblock 161 223 496 minecraft:end_stone
fill 162 223 484 170 223 484 minecraft:end_stone
fill 162 223 488 170 223 488 minecraft:end_stone
fill 163 223 485 170 223 485 minecraft:end_stone
fill 163 223 487 170 223 487 minecraft:end_stone
setblock 163 223 505 minecraft:white_concrete
fill 164 223 463 165 233 463 minecraft:purpur_block
fill 164 223 486 171 223 486 minecraft:end_stone
fill 173 223 505 173 262 505 minecraft:purpur_block
fill 183 223 474 183 276 474 minecraft:purpur_block
fill 183 223 484 183 264 484 minecraft:purpur_block
fill 141 224 463 141 307 463 minecraft:purpur_block
setblock 141 224 464 minecraft:magenta_stained_glass
setblock 141 224 466 minecraft:pearlescent_froglight
fill 141 224 471 141 233 472 minecraft:purpur_block
fill 141 224 487 141 233 487 minecraft:purpur_block
setblock 141 224 496 minecraft:white_concrete
fill 141 224 497 141 236 499 minecraft:purpur_block
fill 142 224 464 182 224 465 minecraft:black_concrete
setblock 142 224 466 minecraft:magenta_stained_glass
fill 142 224 467 142 224 471 minecraft:black_concrete
setblock 142 224 472 minecraft:magenta_stained_glass
fill 142 224 473 142 224 477 minecraft:black_concrete
setblock 142 224 478 minecraft:magenta_stained_glass
fill 142 224 479 142 224 483 minecraft:black_concrete
setblock 142 224 484 minecraft:magenta_stained_glass
fill 142 224 485 142 224 489 minecraft:black_concrete
setblock 142 224 490 minecraft:magenta_stained_glass
fill 142 224 491 142 224 495 minecraft:black_concrete
setblock 142 224 496 minecraft:magenta_stained_glass
fill 142 224 497 142 224 501 minecraft:black_concrete
setblock 142 224 502 minecraft:magenta_stained_glass
fill 142 224 503 182 224 504 minecraft:black_concrete
fill 143 224 466 143 224 468 minecraft:black_concrete
setblock 143 224 469 minecraft:magenta_stained_glass
fill 143 224 470 143 224 474 minecraft:black_concrete
setblock 143 224 475 minecraft:magenta_stained_glass
fill 143 224 476 143 224 480 minecraft:black_concrete
setblock 143 224 481 minecraft:magenta_stained_glass
fill 143 224 482 143 224 486 minecraft:black_concrete
setblock 143 224 487 minecraft:magenta_stained_glass
fill 143 224 488 143 224 492 minecraft:black_concrete
setblock 143 224 493 minecraft:magenta_stained_glass
fill 143 224 494 143 224 498 minecraft:black_concrete
setblock 143 224 499 minecraft:magenta_stained_glass
fill 143 224 500 143 224 502 minecraft:black_concrete
setblock 144 224 466 minecraft:magenta_stained_glass
fill 144 224 467 144 224 471 minecraft:black_concrete
setblock 144 224 472 minecraft:magenta_stained_glass
fill 144 224 473 144 224 477 minecraft:black_concrete
setblock 144 224 478 minecraft:magenta_stained_glass
fill 144 224 479 144 224 483 minecraft:black_concrete
setblock 144 224 484 minecraft:magenta_stained_glass
fill 144 224 485 144 224 489 minecraft:black_concrete
setblock 144 224 490 minecraft:magenta_stained_glass
fill 144 224 491 144 224 495 minecraft:black_concrete
setblock 144 224 496 minecraft:magenta_stained_glass
fill 144 224 497 144 224 501 minecraft:black_concrete
setblock 144 224 502 minecraft:magenta_stained_glass
fill 145 224 466 145 224 468 minecraft:black_concrete
setblock 145 224 469 minecraft:magenta_stained_glass
fill 145 224 470 145 224 474 minecraft:black_concrete
setblock 145 224 475 minecraft:magenta_stained_glass
fill 145 224 476 145 224 480 minecraft:black_concrete
setblock 145 224 481 minecraft:magenta_stained_glass
fill 145 224 482 145 224 486 minecraft:black_concrete
setblock 145 224 487 minecraft:magenta_stained_glass
fill 145 224 488 145 224 492 minecraft:black_concrete
setblock 145 224 493 minecraft:magenta_stained_glass
fill 145 224 494 145 224 498 minecraft:black_concrete
setblock 145 224 499 minecraft:magenta_stained_glass
fill 145 224 500 145 224 502 minecraft:black_concrete
setblock 146 224 466 minecraft:magenta_stained_glass
fill 146 224 467 146 224 471 minecraft:black_concrete
setblock 146 224 472 minecraft:magenta_stained_glass
fill 146 224 473 146 224 477 minecraft:black_concrete
setblock 146 224 478 minecraft:magenta_stained_glass
fill 146 224 479 146 224 483 minecraft:black_concrete
setblock 146 224 484 minecraft:magenta_stained_glass
fill 146 224 485 146 224 489 minecraft:black_concrete
setblock 146 224 490 minecraft:magenta_stained_glass
fill 146 224 491 146 224 495 minecraft:black_concrete
setblock 146 224 496 minecraft:magenta_stained_glass
fill 146 224 497 146 224 501 minecraft:black_concrete
setblock 146 224 502 minecraft:magenta_stained_glass
fill 147 224 466 147 224 468 minecraft:black_concrete
setblock 147 224 469 minecraft:magenta_stained_glass
fill 147 224 470 147 224 474 minecraft:black_concrete
setblock 147 224 475 minecraft:magenta_stained_glass
fill 147 224 476 147 224 480 minecraft:black_concrete
setblock 147 224 481 minecraft:magenta_stained_glass
fill 147 224 482 147 224 486 minecraft:black_concrete
setblock 147 224 487 minecraft:magenta_stained_glass
fill 147 224 488 147 224 492 minecraft:black_concrete
setblock 147 224 493 minecraft:magenta_stained_glass
fill 147 224 494 147 224 498 minecraft:black_concrete
setblock 147 224 499 minecraft:magenta_stained_glass
fill 147 224 500 147 224 502 minecraft:black_concrete
setblock 148 224 466 minecraft:magenta_stained_glass
fill 148 224 467 148 224 471 minecraft:black_concrete
setblock 148 224 472 minecraft:magenta_stained_glass
fill 148 224 473 148 224 477 minecraft:black_concrete
setblock 148 224 478 minecraft:magenta_stained_glass
fill 148 224 479 148 224 483 minecraft:black_concrete
setblock 148 224 484 minecraft:magenta_stained_glass
fill 148 224 485 148 224 489 minecraft:black_concrete
setblock 148 224 490 minecraft:magenta_stained_glass
fill 148 224 491 148 224 495 minecraft:black_concrete
setblock 148 224 496 minecraft:magenta_stained_glass
fill 148 224 497 148 224 501 minecraft:black_concrete
setblock 148 224 502 minecraft:magenta_stained_glass
fill 149 224 466 149 224 468 minecraft:black_concrete
setblock 149 224 469 minecraft:magenta_stained_glass
fill 149 224 470 149 224 474 minecraft:black_concrete
setblock 149 224 475 minecraft:magenta_stained_glass
fill 149 224 476 149 224 480 minecraft:black_concrete
setblock 149 224 481 minecraft:magenta_stained_glass
fill 149 224 482 149 224 486 minecraft:black_concrete
setblock 149 224 487 minecraft:magenta_stained_glass
fill 149 224 488 149 224 492 minecraft:black_concrete
setblock 149 224 493 minecraft:magenta_stained_glass
fill 149 224 494 149 224 498 minecraft:black_concrete
setblock 149 224 499 minecraft:magenta_stained_glass
fill 149 224 500 149 224 502 minecraft:black_concrete
setblock 150 224 466 minecraft:magenta_stained_glass
fill 150 224 467 150 224 471 minecraft:black_concrete
setblock 150 224 472 minecraft:magenta_stained_glass
fill 150 224 473 150 224 477 minecraft:black_concrete
setblock 150 224 478 minecraft:magenta_stained_glass
fill 150 224 479 150 224 483 minecraft:black_concrete
setblock 150 224 484 minecraft:magenta_stained_glass
fill 150 224 485 150 224 489 minecraft:black_concrete
setblock 150 224 490 minecraft:magenta_stained_glass
fill 150 224 491 150 224 495 minecraft:black_concrete
setblock 150 224 496 minecraft:magenta_stained_glass
fill 150 224 497 150 224 501 minecraft:black_concrete
setblock 150 224 502 minecraft:magenta_stained_glass
fill 151 224 466 151 224 468 minecraft:black_concrete
setblock 151 224 469 minecraft:magenta_stained_glass
fill 151 224 470 151 224 474 minecraft:black_concrete
setblock 151 224 475 minecraft:magenta_stained_glass
fill 151 224 476 151 224 480 minecraft:black_concrete
setblock 151 224 481 minecraft:magenta_stained_glass
fill 151 224 482 151 224 485 minecraft:black_concrete
fill 151 224 486 157 224 486 minecraft:purpur_block
setblock 151 224 487 minecraft:magenta_stained_glass
fill 151 224 488 151 224 492 minecraft:black_concrete
setblock 151 224 493 minecraft:magenta_stained_glass
fill 151 224 494 151 224 498 minecraft:black_concrete
setblock 151 224 499 minecraft:magenta_stained_glass
fill 151 224 500 151 224 502 minecraft:black_concrete
setblock 152 224 466 minecraft:magenta_stained_glass
fill 152 224 467 152 224 471 minecraft:black_concrete
setblock 152 224 472 minecraft:magenta_stained_glass
fill 152 224 473 152 224 477 minecraft:black_concrete
setblock 152 224 478 minecraft:magenta_stained_glass
fill 152 224 479 152 224 481 minecraft:black_concrete
fill 152 224 482 152 224 485 minecraft:purpur_pillar
fill 152 224 487 152 224 490 minecraft:purpur_pillar
fill 152 224 491 152 224 495 minecraft:black_concrete
setblock 152 224 496 minecraft:magenta_stained_glass
fill 152 224 497 152 224 501 minecraft:black_concrete
setblock 152 224 502 minecraft:magenta_stained_glass
fill 153 224 466 153 224 468 minecraft:black_concrete
setblock 153 224 469 minecraft:magenta_stained_glass
fill 153 224 470 153 224 474 minecraft:black_concrete
setblock 153 224 475 minecraft:magenta_stained_glass
fill 153 224 476 153 224 479 minecraft:black_concrete
setblock 153 224 480 minecraft:purpur_block
setblock 153 224 481 minecraft:purpur_pillar
fill 153 224 482 157 224 485 minecraft:purpur_block
fill 153 224 487 157 224 490 minecraft:purpur_block
setblock 153 224 491 minecraft:purpur_pillar
setblock 153 224 492 minecraft:purpur_block
setblock 153 224 493 minecraft:magenta_stained_glass
fill 153 224 494 153 224 498 minecraft:black_concrete
setblock 153 224 499 minecraft:magenta_stained_glass
fill 153 224 500 153 224 502 minecraft:black_concrete
setblock 154 224 466 minecraft:magenta_stained_glass
fill 154 224 467 154 224 471 minecraft:black_concrete
setblock 154 224 472 minecraft:magenta_stained_glass
fill 154 224 473 154 224 477 minecraft:black_concrete
setblock 154 224 478 minecraft:magenta_stained_glass
fill 154 224 479 154 224 480 minecraft:purpur_pillar
fill 154 224 481 168 224 481 minecraft:purpur_block
fill 154 224 491 168 224 491 minecraft:purpur_block
fill 154 224 492 154 224 493 minecraft:purpur_pillar
fill 154 224 494 154 224 495 minecraft:black_concrete
setblock 154 224 496 minecraft:magenta_stained_glass
fill 154 224 497 154 224 501 minecraft:black_concrete
setblock 154 224 502 minecraft:magenta_stained_glass
fill 155 224 466 155 224 468 minecraft:black_concrete
setblock 155 224 469 minecraft:magenta_stained_glass
fill 155 224 470 155 224 474 minecraft:black_concrete
setblock 155 224 475 minecraft:magenta_stained_glass
fill 155 224 476 156 224 477 minecraft:black_concrete
setblock 155 224 478 minecraft:purpur_block
setblock 155 224 479 minecraft:purpur_pillar
fill 155 224 480 167 224 480 minecraft:purpur_block
fill 155 224 492 167 224 492 minecraft:purpur_block
setblock 155 224 493 minecraft:purpur_pillar
setblock 155 224 494 minecraft:purpur_block
fill 155 224 495 155 224 498 minecraft:black_concrete
setblock 155 224 499 minecraft:magenta_stained_glass
fill 155 224 500 155 224 502 minecraft:black_concrete
setblock 156 224 466 minecraft:magenta_stained_glass
fill 156 224 467 156 224 471 minecraft:black_concrete
setblock 156 224 472 minecraft:magenta_stained_glass
fill 156 224 473 156 224 475 minecraft:black_concrete
setblock 156 224 478 minecraft:purpur_pillar
fill 156 224 479 166 224 479 minecraft:purpur_block
fill 156 224 493 166 224 493 minecraft:purpur_block
setblock 156 224 494 minecraft:purpur_pillar
setblock 156 224 495 minecraft:black_concrete
setblock 156 224 496 minecraft:magenta_stained_glass
fill 156 224 497 156 224 501 minecraft:black_concrete
setblock 156 224 502 minecraft:magenta_stained_glass
fill 157 224 466 157 224 468 minecraft:black_concrete
setblock 157 224 469 minecraft:magenta_stained_glass
fill 157 224 470 157 224 474 minecraft:black_concrete
setblock 157 224 475 minecraft:magenta_stained_glass
fill 157 224 476 160 224 476 minecraft:black_concrete
fill 157 224 477 160 224 477 minecraft:purpur_pillar
fill 157 224 478 165 224 478 minecraft:purpur_block
fill 157 224 494 165 224 494 minecraft:purpur_block
fill 157 224 495 160 224 495 minecraft:purpur_pillar
fill 157 224 496 157 224 498 minecraft:black_concrete
setblock 157 224 499 minecraft:magenta_stained_glass
fill 157 224 500 157 224 502 minecraft:black_concrete
setblock 158 224 466 minecraft:magenta_stained_glass
fill 158 224 467 158 224 471 minecraft:black_concrete
setblock 158 224 472 minecraft:magenta_stained_glass
fill 158 224 473 158 224 475 minecraft:black_concrete
fill 158 224 482 158 224 484 minecraft:purpur_block
fill 158 224 485 158 224 487 minecraft:pearlescent_froglight
fill 158 224 488 158 224 490 minecraft:purpur_block
setblock 158 224 496 minecraft:magenta_stained_glass
fill 158 224 497 158 224 501 minecraft:black_concrete
setblock 158 224 502 minecraft:magenta_stained_glass
fill 159 224 466 159 224 468 minecraft:black_concrete
setblock 159 224 469 minecraft:magenta_stained_glass
fill 159 224 470 159 224 474 minecraft:black_concrete
setblock 159 224 475 minecraft:magenta_stained_glass
fill 159 224 482 159 224 483 minecraft:purpur_block
fill 159 224 484 159 224 485 minecraft:pearlescent_froglight
fill 159 224 487 159 224 488 minecraft:pearlescent_froglight
fill 159 224 489 159 224 490 minecraft:purpur_block
fill 159 224 496 159 224 498 minecraft:black_concrete
setblock 159 224 499 minecraft:magenta_stained_glass
fill 159 224 500 159 224 502 minecraft:black_concrete
setblock 160 224 466 minecraft:magenta_stained_glass
fill 160 224 467 160 224 471 minecraft:black_concrete
setblock 160 224 472 minecraft:magenta_stained_glass
fill 160 224 473 160 224 475 minecraft:black_concrete
fill 160 224 482 169 224 482 minecraft:purpur_block
fill 160 224 483 160 224 484 minecraft:pearlescent_froglight
fill 160 224 488 160 224 489 minecraft:pearlescent_froglight
fill 160 224 490 169 224 490 minecraft:purpur_block
setblock 160 224 496 minecraft:magenta_stained_glass
fill 160 224 497 160 224 501 minecraft:black_concrete
setblock 160 224 502 minecraft:magenta_stained_glass
fill 161 224 466 161 224 468 minecraft:black_concrete
setblock 161 224 469 minecraft:magenta_stained_glass
fill 161 224 470 161 224 474 minecraft:black_concrete
setblock 161 224 475 minecraft:magenta_stained_glass
fill 161 224 476 161 224 477 minecraft:purpur_block
fill 161 224 483 162 224 483 minecraft:pearlescent_froglight
fill 161 224 489 162 224 489 minecraft:pearlescent_froglight
fill 161 224 495 161 224 496 minecraft:purpur_block
fill 161 224 497 182 224 498 minecraft:black_concrete
setblock 161 224 499 minecraft:magenta_stained_glass
fill 161 224 500 161 224 502 minecraft:black_concrete
setblock 162 224 466 minecraft:magenta_stained_glass
fill 162 224 467 162 224 471 minecraft:black_concrete
setblock 162 224 472 minecraft:magenta_stained_glass
fill 162 224 473 162 224 476 minecraft:black_concrete
fill 162 224 477 165 224 477 minecraft:purpur_pillar
fill 162 224 484 163 224 484 minecraft:pearlescent_froglight
fill 162 224 488 163 224 488 minecraft:pearlescent_froglight
fill 162 224 495 165 224 495 minecraft:purpur_pillar
setblock 162 224 496 minecraft:magenta_stained_glass
fill 162 224 499 162 224 501 minecraft:black_concrete
setblock 162 224 502 minecraft:magenta_stained_glass
fill 163 224 466 163 224 468 minecraft:black_concrete
setblock 163 224 469 minecraft:magenta_stained_glass
fill 163 224 470 163 224 474 minecraft:black_concrete
setblock 163 224 475 minecraft:magenta_stained_glass
fill 163 224 476 182 224 476 minecraft:black_concrete
fill 163 224 483 169 224 483 minecraft:purpur_block
fill 163 224 485 164 224 485 minecraft:pearlescent_froglight
fill 163 224 487 164 224 487 minecraft:pearlescent_froglight
fill 163 224 489 169 224 489 minecraft:purpur_block
setblock 163 224 496 minecraft:black_concrete
setblock 163 224 499 minecraft:magenta_stained_glass
fill 163 224 500 163 224 502 minecraft:black_concrete
fill 163 224 505 163 265 505 minecraft:purpur_block
setblock 164 224 466 minecraft:magenta_stained_glass
fill 164 224 467 164 224 471 minecraft:black_concrete
setblock 164 224 472 minecraft:magenta_stained_glass
fill 164 224 473 164 224 475 minecraft:black_concrete
fill 164 224 484 169 224 484 minecraft:purpur_block
setblock 164 224 486 minecraft:pearlescent_froglight
fill 164 224 488 169 224 488 minecraft:purpur_block
setblock 164 224 496 minecraft:magenta_stained_glass
fill 164 224 499 164 224 501 minecraft:black_concrete
setblock 164 224 502 minecraft:magenta_stained_glass
fill 165 224 466 165 224 468 minecraft:black_concrete
setblock 165 224 469 minecraft:magenta_stained_glass
fill 165 224 470 165 224 474 minecraft:black_concrete
setblock 165 224 475 minecraft:magenta_stained_glass
fill 165 224 485 169 224 487 minecraft:purpur_block
setblock 165 224 496 minecraft:black_concrete
setblock 165 224 499 minecraft:magenta_stained_glass
fill 165 224 500 165 224 502 minecraft:black_concrete
setblock 166 224 466 minecraft:magenta_stained_glass
fill 166 224 467 166 224 471 minecraft:black_concrete
setblock 166 224 472 minecraft:magenta_stained_glass
fill 166 224 473 166 224 475 minecraft:black_concrete
fill 166 224 477 182 224 477 minecraft:black_concrete
setblock 166 224 478 minecraft:purpur_pillar
setblock 166 224 494 minecraft:purpur_pillar
fill 166 224 495 182 224 495 minecraft:black_concrete
setblock 166 224 496 minecraft:magenta_stained_glass
fill 166 224 499 166 224 501 minecraft:black_concrete
setblock 166 224 502 minecraft:magenta_stained_glass
fill 167 224 466 167 224 468 minecraft:black_concrete
setblock 167 224 469 minecraft:magenta_stained_glass
fill 167 224 470 167 224 474 minecraft:black_concrete
setblock 167 224 475 minecraft:magenta_stained_glass
setblock 167 224 478 minecraft:purpur_block
fill 167 224 479 168 224 479 minecraft:purpur_pillar
fill 167 224 493 168 224 493 minecraft:purpur_pillar
setblock 167 224 494 minecraft:purpur_block
setblock 167 224 496 minecraft:black_concrete
setblock 167 224 499 minecraft:magenta_stained_glass
fill 167 224 500 167 224 502 minecraft:black_concrete
setblock 168 224 466 minecraft:magenta_stained_glass
fill 168 224 467 168 224 471 minecraft:black_concrete
setblock 168 224 472 minecraft:magenta_stained_glass
fill 168 224 473 168 224 475 minecraft:black_concrete
setblock 168 224 478 minecraft:magenta_stained_glass
setblock 168 224 480 minecraft:purpur_pillar
setblock 168 224 492 minecraft:purpur_pillar
fill 168 224 494 182 224 494 minecraft:black_concrete
setblock 168 224 496 minecraft:magenta_stained_glass
fill 168 224 499 168 224 501 minecraft:black_concrete
setblock 168 224 502 minecraft:magenta_stained_glass
fill 169 224 466 169 224 468 minecraft:black_concrete
setblock 169 224 469 minecraft:magenta_stained_glass
fill 169 224 470 169 224 474 minecraft:black_concrete
setblock 169 224 475 minecraft:magenta_stained_glass
fill 169 224 478 169 224 479 minecraft:black_concrete
setblock 169 224 480 minecraft:purpur_block
setblock 169 224 481 minecraft:purpur_pillar
setblock 169 224 491 minecraft:purpur_pillar
setblock 169 224 492 minecraft:purpur_block
setblock 169 224 493 minecraft:magenta_stained_glass
setblock 169 224 496 minecraft:black_concrete
setblock 169 224 499 minecraft:magenta_stained_glass
fill 169 224 500 169 224 502 minecraft:black_concrete
setblock 170 224 466 minecraft:magenta_stained_glass
fill 170 224 467 170 224 471 minecraft:black_concrete
setblock 170 224 472 minecraft:magenta_stained_glass
fill 170 224 473 170 224 475 minecraft:black_concrete
setblock 170 224 478 minecraft:magenta_stained_glass
fill 170 224 479 170 224 481 minecraft:black_concrete
fill 170 224 482 170 224 485 minecraft:purpur_pillar
fill 170 224 486 171 224 486 minecraft:purpur_block
fill 170 224 487 170 224 490 minecraft:purpur_pillar
fill 170 224 491 170 224 493 minecraft:black_concrete
setblock 170 224 496 minecraft:magenta_stained_glass
fill 170 224 499 170 224 501 minecraft:black_concrete
setblock 170 224 502 minecraft:magenta_stained_glass
fill 171 224 466 171 224 468 minecraft:black_concrete
setblock 171 224 469 minecraft:magenta_stained_glass
fill 171 224 470 171 224 474 minecraft:black_concrete
setblock 171 224 475 minecraft:magenta_stained_glass
fill 171 224 478 171 224 480 minecraft:black_concrete
setblock 171 224 481 minecraft:magenta_stained_glass
fill 171 224 482 171 224 485 minecraft:black_concrete
setblock 171 224 487 minecraft:magenta_stained_glass
fill 171 224 488 171 224 492 minecraft:black_concrete
setblock 171 224 493 minecraft:magenta_stained_glass
setblock 171 224 496 minecraft:black_concrete
setblock 171 224 499 minecraft:magenta_stained_glass
fill 171 224 500 171 224 502 minecraft:black_concrete
setblock 172 224 466 minecraft:magenta_stained_glass
fill 172 224 467 172 224 471 minecraft:black_concrete
setblock 172 224 472 minecraft:magenta_stained_glass
fill 172 224 473 172 224 475 minecraft:black_concrete
setblock 172 224 478 minecraft:magenta_stained_glass
fill 172 224 479 172 224 483 minecraft:black_concrete
setblock 172 224 484 minecraft:magenta_stained_glass
fill 172 224 485 172 224 489 minecraft:black_concrete
setblock 172 224 490 minecraft:magenta_stained_glass
fill 172 224 491 172 224 493 minecraft:black_concrete
setblock 172 224 496 minecraft:magenta_stained_glass
fill 172 224 499 172 224 501 minecraft:black_concrete
setblock 172 224 502 minecraft:magenta_stained_glass
fill 173 224 466 173 224 468 minecraft:black_concrete
setblock 173 224 469 minecraft:magenta_stained_glass
fill 173 224 470 173 224 474 minecraft:black_concrete
setblock 173 224 475 minecraft:magenta_stained_glass
fill 173 224 478 173 224 480 minecraft:black_concrete
setblock 173 224 481 minecraft:magenta_stained_glass
fill 173 224 482 173 224 486 minecraft:black_concrete
setblock 173 224 487 minecraft:magenta_stained_glass
fill 173 224 488 173 224 492 minecraft:black_concrete
setblock 173 224 493 minecraft:magenta_stained_glass
setblock 173 224 496 minecraft:black_concrete
setblock 173 224 499 minecraft:magenta_stained_glass
fill 173 224 500 173 224 502 minecraft:black_concrete
setblock 174 224 466 minecraft:magenta_stained_glass
fill 174 224 467 174 224 471 minecraft:black_concrete
setblock 174 224 472 minecraft:magenta_stained_glass
fill 174 224 473 174 224 475 minecraft:black_concrete
setblock 174 224 478 minecraft:magenta_stained_glass
fill 174 224 479 174 224 483 minecraft:black_concrete
setblock 174 224 484 minecraft:magenta_stained_glass
fill 174 224 485 174 224 489 minecraft:black_concrete
setblock 174 224 490 minecraft:magenta_stained_glass
fill 174 224 491 174 224 493 minecraft:black_concrete
setblock 174 224 496 minecraft:magenta_stained_glass
fill 174 224 499 174 224 501 minecraft:black_concrete
setblock 174 224 502 minecraft:magenta_stained_glass
setblock 174 224 505 minecraft:magenta_stained_glass
fill 175 224 466 175 224 468 minecraft:black_concrete
setblock 175 224 469 minecraft:magenta_stained_glass
fill 175 224 470 175 224 474 minecraft:black_concrete
setblock 175 224 475 minecraft:magenta_stained_glass
fill 175 224 478 175 224 480 minecraft:black_concrete
setblock 175 224 481 minecraft:magenta_stained_glass
fill 175 224 482 175 224 486 minecraft:black_concrete
setblock 175 224 487 minecraft:magenta_stained_glass
fill 175 224 488 175 224 492 minecraft:black_concrete
setblock 175 224 493 minecraft:magenta_stained_glass
setblock 175 224 496 minecraft:black_concrete
setblock 175 224 499 minecraft:magenta_stained_glass
fill 175 224 500 175 224 502 minecraft:black_concrete
setblock 176 224 466 minecraft:magenta_stained_glass
fill 176 224 467 176 224 471 minecraft:black_concrete
setblock 176 224 472 minecraft:magenta_stained_glass
fill 176 224 473 176 224 475 minecraft:black_concrete
setblock 176 224 478 minecraft:magenta_stained_glass
fill 176 224 479 176 224 483 minecraft:black_concrete
setblock 176 224 484 minecraft:magenta_stained_glass
fill 176 224 485 176 224 489 minecraft:black_concrete
setblock 176 224 490 minecraft:magenta_stained_glass
fill 176 224 491 176 224 493 minecraft:black_concrete
setblock 176 224 496 minecraft:magenta_stained_glass
fill 176 224 499 176 224 501 minecraft:black_concrete
setblock 176 224 502 minecraft:magenta_stained_glass
fill 177 224 466 177 224 468 minecraft:black_concrete
setblock 177 224 469 minecraft:magenta_stained_glass
fill 177 224 470 177 224 474 minecraft:black_concrete
setblock 177 224 475 minecraft:magenta_stained_glass
fill 177 224 478 177 224 480 minecraft:black_concrete
setblock 177 224 481 minecraft:magenta_stained_glass
fill 177 224 482 177 224 486 minecraft:black_concrete
setblock 177 224 487 minecraft:magenta_stained_glass
fill 177 224 488 177 224 492 minecraft:black_concrete
setblock 177 224 493 minecraft:magenta_stained_glass
setblock 177 224 496 minecraft:black_concrete
setblock 177 224 499 minecraft:magenta_stained_glass
fill 177 224 500 177 224 502 minecraft:black_concrete
setblock 178 224 466 minecraft:magenta_stained_glass
fill 178 224 467 178 224 471 minecraft:black_concrete
setblock 178 224 472 minecraft:magenta_stained_glass
fill 178 224 473 178 224 475 minecraft:black_concrete
setblock 178 224 478 minecraft:magenta_stained_glass
fill 178 224 479 178 224 483 minecraft:black_concrete
setblock 178 224 484 minecraft:magenta_stained_glass
fill 178 224 485 178 224 489 minecraft:black_concrete
setblock 178 224 490 minecraft:magenta_stained_glass
fill 178 224 491 178 224 493 minecraft:black_concrete
setblock 178 224 496 minecraft:magenta_stained_glass
fill 178 224 499 178 224 501 minecraft:black_concrete
setblock 178 224 502 minecraft:magenta_stained_glass
fill 179 224 466 179 224 468 minecraft:black_concrete
setblock 179 224 469 minecraft:magenta_stained_glass
fill 179 224 470 179 224 474 minecraft:black_concrete
setblock 179 224 475 minecraft:magenta_stained_glass
fill 179 224 478 179 224 480 minecraft:black_concrete
setblock 179 224 481 minecraft:magenta_stained_glass
fill 179 224 482 179 224 486 minecraft:black_concrete
setblock 179 224 487 minecraft:magenta_stained_glass
fill 179 224 488 179 224 492 minecraft:black_concrete
setblock 179 224 493 minecraft:magenta_stained_glass
setblock 179 224 496 minecraft:black_concrete
setblock 179 224 499 minecraft:magenta_stained_glass
fill 179 224 500 179 224 502 minecraft:black_concrete
setblock 180 224 466 minecraft:magenta_stained_glass
fill 180 224 467 180 224 471 minecraft:black_concrete
setblock 180 224 472 minecraft:magenta_stained_glass
fill 180 224 473 180 224 475 minecraft:black_concrete
setblock 180 224 478 minecraft:magenta_stained_glass
fill 180 224 479 180 224 483 minecraft:black_concrete
setblock 180 224 484 minecraft:magenta_stained_glass
fill 180 224 485 180 224 489 minecraft:black_concrete
setblock 180 224 490 minecraft:magenta_stained_glass
fill 180 224 491 180 224 493 minecraft:black_concrete
setblock 180 224 496 minecraft:magenta_stained_glass
fill 180 224 499 180 224 501 minecraft:black_concrete
setblock 180 224 502 minecraft:magenta_stained_glass
fill 181 224 466 181 224 468 minecraft:black_concrete
setblock 181 224 469 minecraft:magenta_stained_glass
fill 181 224 470 181 224 474 minecraft:black_concrete
setblock 181 224 475 minecraft:magenta_stained_glass
fill 181 224 478 181 224 480 minecraft:black_concrete
setblock 181 224 481 minecraft:magenta_stained_glass
fill 181 224 482 181 224 486 minecraft:black_concrete
setblock 181 224 487 minecraft:magenta_stained_glass
fill 181 224 488 181 224 492 minecraft:black_concrete
setblock 181 224 493 minecraft:magenta_stained_glass
setblock 181 224 496 minecraft:black_concrete
setblock 181 224 499 minecraft:magenta_stained_glass
fill 181 224 500 181 224 502 minecraft:black_concrete
setblock 182 224 466 minecraft:magenta_stained_glass
fill 182 224 467 182 224 471 minecraft:black_concrete
setblock 182 224 472 minecraft:magenta_stained_glass
fill 182 224 473 182 224 475 minecraft:black_concrete
setblock 182 224 478 minecraft:magenta_stained_glass
fill 182 224 479 182 224 483 minecraft:black_concrete
setblock 182 224 484 minecraft:magenta_stained_glass
fill 182 224 485 182 224 489 minecraft:black_concrete
setblock 182 224 490 minecraft:magenta_stained_glass
fill 182 224 491 182 224 493 minecraft:black_concrete
setblock 182 224 496 minecraft:magenta_stained_glass
fill 182 224 499 182 224 501 minecraft:black_concrete
setblock 182 224 502 minecraft:magenta_stained_glass
fill 141 225 464 141 265 464 minecraft:purpur_block
fill 141 225 466 141 277 466 minecraft:purpur_block
fill 141 225 496 141 273 496 minecraft:purpur_block
setblock 144 225 466 minecraft:light[level=14]
setblock 144 225 474 minecraft:light[level=14]
setblock 144 225 482 minecraft:light[level=14]
setblock 144 225 490 minecraft:light[level=14]
setblock 144 225 498 minecraft:light[level=14]
setblock 152 225 466 minecraft:light[level=14]
setblock 152 225 474 minecraft:light[level=14]
setblock 152 225 482 minecraft:light[level=14]
setblock 152 225 490 minecraft:light[level=14]
schedule function dropper:buildpart/111_2 1t
