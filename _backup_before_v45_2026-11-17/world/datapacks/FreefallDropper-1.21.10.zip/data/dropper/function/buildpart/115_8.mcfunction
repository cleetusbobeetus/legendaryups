fill 355 233 464 358 233 464 minecraft:pink_terracotta
fill 355 233 504 358 233 504 minecraft:pink_terracotta
setblock 357 233 466 minecraft:red_nether_bricks
setblock 358 233 465 minecraft:red_nether_bricks
fill 358 233 466 359 235 466 minecraft:pink_terracotta
setblock 359 233 464 minecraft:red_nether_bricks
fill 359 233 465 362 233 465 minecraft:pink_terracotta
fill 360 233 464 363 233 464 minecraft:pink_terracotta
setblock 363 233 465 minecraft:red_nether_bricks
setblock 364 233 464 minecraft:red_nether_bricks
fill 364 233 465 367 233 465 minecraft:pink_terracotta
fill 365 233 464 368 233 464 minecraft:pink_terracotta
fill 367 233 504 368 233 504 minecraft:pink_terracotta
setblock 368 233 465 minecraft:red_nether_bricks
setblock 369 233 464 minecraft:red_nether_bricks
fill 369 233 465 369 233 468 minecraft:pink_terracotta
setblock 369 233 469 minecraft:red_nether_bricks
fill 369 233 470 370 235 470 minecraft:pink_terracotta
setblock 369 233 504 minecraft:red_nether_bricks
fill 370 233 464 370 233 467 minecraft:pink_terracotta
setblock 370 233 468 minecraft:red_nether_bricks
fill 370 233 469 370 236 469 minecraft:pink_terracotta
fill 370 233 471 370 233 472 minecraft:pink_terracotta
fill 370 233 484 370 233 487 minecraft:pink_terracotta
setblock 370 233 488 minecraft:red_nether_bricks
fill 370 233 489 370 234 491 minecraft:pink_terracotta
fill 370 233 501 370 233 502 minecraft:pink_terracotta
setblock 370 233 503 minecraft:red_nether_bricks
fill 370 233 504 370 236 504 minecraft:pink_terracotta
fill 330 234 464 330 234 466 minecraft:pink_terracotta
setblock 330 234 467 minecraft:red_nether_bricks
fill 330 234 468 330 237 468 minecraft:pink_terracotta
setblock 330 234 471 minecraft:pink_terracotta
setblock 330 234 472 minecraft:red_nether_bricks
setblock 330 234 482 minecraft:red_nether_bricks
fill 330 234 483 330 234 486 minecraft:pink_terracotta
setblock 330 234 487 minecraft:red_nether_bricks
fill 330 234 488 330 234 491 minecraft:pink_terracotta
setblock 330 234 492 minecraft:red_nether_bricks
fill 330 234 493 330 234 496 minecraft:pink_terracotta
setblock 330 234 497 minecraft:red_nether_bricks
fill 330 234 498 330 234 501 minecraft:pink_terracotta
setblock 330 234 502 minecraft:red_nether_bricks
fill 330 234 503 332 234 504 minecraft:pink_terracotta
fill 331 234 464 331 234 465 minecraft:pink_terracotta
setblock 331 234 466 minecraft:red_nether_bricks
fill 331 234 467 331 237 467 minecraft:pink_terracotta
fill 331 234 469 331 235 469 minecraft:pink_terracotta
fill 331 234 484 331 234 485 minecraft:pink_terracotta
setblock 331 234 486 minecraft:red_nether_bricks
fill 331 234 487 331 234 490 minecraft:pink_terracotta
setblock 331 234 491 minecraft:red_nether_bricks
fill 331 234 492 332 236 492 minecraft:pink_terracotta
setblock 331 234 496 minecraft:red_nether_bricks
fill 331 234 497 331 234 500 minecraft:pink_terracotta
setblock 331 234 501 minecraft:red_nether_bricks
fill 331 234 502 331 237 502 minecraft:pink_terracotta
setblock 332 234 464 minecraft:pink_terracotta
setblock 332 234 465 minecraft:red_nether_bricks
fill 332 234 466 333 236 466 minecraft:pink_terracotta
setblock 332 234 485 minecraft:red_nether_bricks
fill 332 234 486 332 234 489 minecraft:pink_terracotta
setblock 332 234 490 minecraft:red_nether_bricks
fill 332 234 491 332 237 491 minecraft:pink_terracotta
fill 332 234 493 332 234 494 minecraft:pink_terracotta
setblock 333 234 464 minecraft:red_nether_bricks
fill 333 234 465 336 234 465 minecraft:pink_terracotta
setblock 333 234 488 minecraft:pink_terracotta
setblock 333 234 489 minecraft:red_nether_bricks
fill 333 234 490 333 237 490 minecraft:pink_terracotta
setblock 333 234 503 minecraft:pink_terracotta
setblock 333 234 504 minecraft:red_nether_bricks
fill 334 234 464 337 234 464 minecraft:pink_terracotta
setblock 334 234 503 minecraft:red_nether_bricks
fill 334 234 504 337 234 504 minecraft:pink_terracotta
fill 335 234 503 336 235 503 minecraft:pink_terracotta
setblock 337 234 465 minecraft:red_nether_bricks
setblock 338 234 464 minecraft:red_nether_bricks
setblock 338 234 504 minecraft:red_nether_bricks
fill 339 234 464 339 235 464 minecraft:pink_terracotta
setblock 339 234 504 minecraft:pink_terracotta
setblock 348 234 464 minecraft:red_nether_bricks
fill 349 234 464 351 234 465 minecraft:pink_terracotta
setblock 351 234 466 minecraft:red_nether_bricks
fill 351 234 504 352 234 504 minecraft:pink_terracotta
setblock 352 234 464 minecraft:pink_terracotta
setblock 352 234 465 minecraft:red_nether_bricks
fill 352 234 466 355 234 466 minecraft:pink_terracotta
setblock 353 234 464 minecraft:red_nether_bricks
fill 353 234 465 356 234 465 minecraft:pink_terracotta
setblock 353 234 504 minecraft:red_nether_bricks
fill 354 234 464 357 234 464 minecraft:pink_terracotta
fill 354 234 504 357 234 504 minecraft:pink_terracotta
setblock 355 234 467 minecraft:red_nether_bricks
setblock 356 234 466 minecraft:red_nether_bricks
setblock 357 234 465 minecraft:red_nether_bricks
fill 357 234 466 357 237 466 minecraft:pink_terracotta
setblock 358 234 464 minecraft:red_nether_bricks
fill 358 234 465 361 234 465 minecraft:pink_terracotta
setblock 358 234 504 minecraft:red_nether_bricks
fill 359 234 464 362 234 464 minecraft:pink_terracotta
setblock 360 234 466 minecraft:pink_terracotta
setblock 362 234 465 minecraft:red_nether_bricks
setblock 363 234 464 minecraft:red_nether_bricks
fill 363 234 465 366 234 465 minecraft:pink_terracotta
fill 364 234 464 367 234 464 minecraft:pink_terracotta
fill 366 234 504 367 234 504 minecraft:pink_terracotta
setblock 367 234 465 minecraft:red_nether_bricks
fill 367 234 466 370 234 466 minecraft:pink_terracotta
setblock 368 234 464 minecraft:red_nether_bricks
fill 368 234 465 370 235 465 minecraft:pink_terracotta
fill 368 234 467 368 234 468 minecraft:pink_terracotta
setblock 368 234 504 minecraft:red_nether_bricks
fill 369 234 464 370 236 464 minecraft:pink_terracotta
setblock 369 234 467 minecraft:pink_terracotta
setblock 369 234 468 minecraft:red_nether_bricks
fill 369 234 469 369 237 469 minecraft:pink_terracotta
fill 369 234 471 370 234 471 minecraft:pink_terracotta
fill 369 234 504 369 237 504 minecraft:pink_terracotta
setblock 370 234 467 minecraft:red_nether_bricks
fill 370 234 468 370 237 468 minecraft:pink_terracotta
setblock 370 234 472 minecraft:red_nether_bricks
fill 370 234 473 370 236 474 minecraft:pink_terracotta
fill 370 234 476 370 235 476 minecraft:white_concrete
setblock 370 234 482 minecraft:white_concrete
fill 370 234 483 370 234 486 minecraft:pink_terracotta
setblock 370 234 487 minecraft:red_nether_bricks
fill 370 234 488 370 237 488 minecraft:pink_terracotta
setblock 370 234 492 minecraft:red_nether_bricks
fill 370 234 493 370 235 495 minecraft:pink_terracotta
fill 370 234 499 370 234 501 minecraft:pink_terracotta
setblock 370 234 502 minecraft:red_nether_bricks
fill 370 234 503 370 237 503 minecraft:pink_terracotta
fill 330 235 464 330 235 465 minecraft:pink_terracotta
setblock 330 235 466 minecraft:red_nether_bricks
fill 330 235 467 330 238 467 minecraft:pink_terracotta
setblock 330 235 471 minecraft:red_nether_bricks
fill 330 235 472 330 237 473 minecraft:pink_terracotta
fill 330 235 482 330 235 485 minecraft:pink_terracotta
setblock 330 235 486 minecraft:red_nether_bricks
fill 330 235 487 330 235 490 minecraft:pink_terracotta
setblock 330 235 491 minecraft:red_nether_bricks
fill 330 235 492 330 235 495 minecraft:pink_terracotta
setblock 330 235 496 minecraft:red_nether_bricks
fill 330 235 497 330 235 500 minecraft:pink_terracotta
setblock 330 235 501 minecraft:red_nether_bricks
fill 330 235 502 330 236 504 minecraft:pink_terracotta
setblock 331 235 464 minecraft:pink_terracotta
setblock 331 235 465 minecraft:red_nether_bricks
fill 331 235 466 331 238 466 minecraft:pink_terracotta
setblock 331 235 470 minecraft:red_nether_bricks
fill 331 235 471 331 238 471 minecraft:pink_terracotta
fill 331 235 483 331 235 484 minecraft:pink_terracotta
setblock 331 235 485 minecraft:red_nether_bricks
fill 331 235 486 331 235 489 minecraft:pink_terracotta
setblock 331 235 490 minecraft:red_nether_bricks
fill 331 235 491 331 238 491 minecraft:pink_terracotta
fill 331 235 493 331 235 494 minecraft:pink_terracotta
setblock 331 235 495 minecraft:red_nether_bricks
fill 331 235 496 331 235 499 minecraft:pink_terracotta
setblock 331 235 500 minecraft:red_nether_bricks
fill 331 235 501 331 238 501 minecraft:pink_terracotta
fill 331 235 503 331 235 504 minecraft:pink_terracotta
setblock 332 235 464 minecraft:red_nether_bricks
fill 332 235 465 335 235 465 minecraft:pink_terracotta
fill 332 235 467 332 235 468 minecraft:pink_terracotta
fill 332 235 485 332 235 488 minecraft:pink_terracotta
setblock 332 235 489 minecraft:red_nether_bricks
fill 332 235 490 332 238 490 minecraft:pink_terracotta
setblock 332 235 493 minecraft:pink_terracotta
setblock 332 235 494 minecraft:red_nether_bricks
fill 332 235 495 332 236 497 minecraft:pink_terracotta
setblock 332 235 503 minecraft:pink_terracotta
setblock 332 235 504 minecraft:red_nether_bricks
fill 333 235 464 336 235 464 minecraft:pink_terracotta
setblock 333 235 487 minecraft:pink_terracotta
setblock 333 235 488 minecraft:red_nether_bricks
fill 333 235 489 333 238 489 minecraft:pink_terracotta
fill 333 235 491 333 235 492 minecraft:pink_terracotta
setblock 333 235 493 minecraft:red_nether_bricks
setblock 333 235 503 minecraft:red_nether_bricks
fill 333 235 504 336 235 504 minecraft:pink_terracotta
setblock 334 235 466 minecraft:pink_terracotta
fill 334 235 503 334 238 503 minecraft:pink_terracotta
setblock 336 235 465 minecraft:red_nether_bricks
setblock 337 235 464 minecraft:red_nether_bricks
setblock 337 235 504 minecraft:red_nether_bricks
fill 338 235 464 338 236 464 minecraft:pink_terracotta
fill 338 235 504 338 236 504 minecraft:pink_terracotta
setblock 343 235 504 minecraft:white_concrete
setblock 347 235 464 minecraft:red_nether_bricks
fill 348 235 464 350 235 465 minecraft:pink_terracotta
setblock 350 235 466 minecraft:red_nether_bricks
fill 350 235 504 351 235 504 minecraft:pink_terracotta
setblock 351 235 464 minecraft:pink_terracotta
setblock 351 235 465 minecraft:red_nether_bricks
fill 351 235 466 354 235 466 minecraft:pink_terracotta
setblock 352 235 464 minecraft:red_nether_bricks
fill 352 235 465 355 235 465 minecraft:pink_terracotta
fill 352 235 467 353 235 467 minecraft:pink_terracotta
setblock 352 235 504 minecraft:red_nether_bricks
fill 353 235 464 356 235 464 minecraft:pink_terracotta
fill 353 235 504 356 235 504 minecraft:pink_terracotta
setblock 354 235 467 minecraft:red_nether_bricks
setblock 355 235 466 minecraft:red_nether_bricks
fill 355 235 467 356 237 467 minecraft:pink_terracotta
setblock 356 235 465 minecraft:red_nether_bricks
fill 356 235 466 356 238 466 minecraft:pink_terracotta
setblock 357 235 464 minecraft:red_nether_bricks
fill 357 235 465 360 235 465 minecraft:pink_terracotta
setblock 357 235 504 minecraft:red_nether_bricks
fill 358 235 464 361 235 464 minecraft:pink_terracotta
setblock 360 235 466 minecraft:red_nether_bricks
setblock 361 235 465 minecraft:red_nether_bricks
setblock 362 235 464 minecraft:red_nether_bricks
fill 362 235 465 365 235 465 minecraft:pink_terracotta
setblock 362 235 504 minecraft:white_concrete
fill 363 235 464 366 235 464 minecraft:pink_terracotta
setblock 366 235 465 minecraft:red_nether_bricks
fill 366 235 466 369 235 466 minecraft:pink_terracotta
setblock 366 235 504 minecraft:pink_terracotta
setblock 367 235 464 minecraft:red_nether_bricks
fill 367 235 465 367 238 465 minecraft:pink_terracotta
setblock 367 235 504 minecraft:red_nether_bricks
fill 368 235 464 368 238 464 minecraft:pink_terracotta
setblock 368 235 467 minecraft:pink_terracotta
setblock 368 235 468 minecraft:red_nether_bricks
fill 368 235 469 368 238 469 minecraft:pink_terracotta
fill 368 235 504 368 238 504 minecraft:pink_terracotta
setblock 369 235 467 minecraft:red_nether_bricks
fill 369 235 468 369 238 468 minecraft:pink_terracotta
setblock 369 235 471 minecraft:pink_terracotta
setblock 369 235 472 minecraft:red_nether_bricks
fill 369 235 488 369 235 491 minecraft:pink_terracotta
fill 369 235 503 369 238 503 minecraft:pink_terracotta
setblock 370 235 466 minecraft:red_nether_bricks
fill 370 235 467 370 238 467 minecraft:pink_terracotta
setblock 370 235 471 minecraft:red_nether_bricks
fill 370 235 472 370 238 472 minecraft:pink_terracotta
setblock 370 235 475 minecraft:pink_terracotta
fill 370 235 483 370 235 485 minecraft:pink_terracotta
setblock 370 235 486 minecraft:red_nether_bricks
fill 370 235 487 370 238 487 minecraft:pink_terracotta
fill 370 235 489 370 235 490 minecraft:pink_terracotta
setblock 370 235 491 minecraft:red_nether_bricks
fill 370 235 492 370 238 492 minecraft:pink_terracotta
setblock 370 235 496 minecraft:red_nether_bricks
fill 370 235 497 370 235 500 minecraft:pink_terracotta
setblock 370 235 501 minecraft:red_nether_bricks
fill 370 235 502 370 238 502 minecraft:pink_terracotta
setblock 330 236 464 minecraft:pink_terracotta
setblock 330 236 465 minecraft:red_nether_bricks
fill 330 236 466 330 239 466 minecraft:pink_terracotta
setblock 330 236 469 minecraft:pink_terracotta
setblock 330 236 470 minecraft:red_nether_bricks
fill 330 236 471 330 239 471 minecraft:pink_terracotta
setblock 330 236 474 minecraft:pink_terracotta
setblock 330 236 475 minecraft:red_nether_bricks
setblock 330 236 479 minecraft:white_concrete
fill 330 236 481 330 236 484 minecraft:pink_terracotta
setblock 330 236 485 minecraft:red_nether_bricks
fill 330 236 486 330 236 489 minecraft:pink_terracotta
setblock 330 236 490 minecraft:red_nether_bricks
fill 330 236 491 330 236 494 minecraft:pink_terracotta
setblock 330 236 495 minecraft:red_nether_bricks
fill 330 236 496 330 236 499 minecraft:pink_terracotta
setblock 330 236 500 minecraft:red_nether_bricks
fill 330 236 501 330 239 501 minecraft:pink_terracotta
setblock 331 236 464 minecraft:red_nether_bricks
fill 331 236 465 334 236 465 minecraft:pink_terracotta
setblock 331 236 469 minecraft:red_nether_bricks
fill 331 236 470 331 239 470 minecraft:pink_terracotta
fill 331 236 472 331 237 472 minecraft:pink_terracotta
setblock 331 236 483 minecraft:pink_terracotta
setblock 331 236 484 minecraft:red_nether_bricks
fill 331 236 485 331 236 488 minecraft:pink_terracotta
setblock 331 236 489 minecraft:red_nether_bricks
fill 331 236 490 331 239 490 minecraft:pink_terracotta
setblock 331 236 493 minecraft:pink_terracotta
setblock 331 236 494 minecraft:red_nether_bricks
fill 331 236 495 331 236 498 minecraft:pink_terracotta
setblock 331 236 499 minecraft:red_nether_bricks
fill 331 236 500 331 239 500 minecraft:pink_terracotta
setblock 331 236 503 minecraft:pink_terracotta
setblock 331 236 504 minecraft:red_nether_bricks
fill 332 236 464 335 236 464 minecraft:pink_terracotta
setblock 332 236 467 minecraft:pink_terracotta
setblock 332 236 468 minecraft:red_nether_bricks
fill 332 236 469 332 239 469 minecraft:pink_terracotta
fill 332 236 485 332 236 487 minecraft:pink_terracotta
setblock 332 236 488 minecraft:red_nether_bricks
fill 332 236 489 332 239 489 minecraft:pink_terracotta
setblock 332 236 493 minecraft:red_nether_bricks
fill 332 236 494 333 238 494 minecraft:pink_terracotta
setblock 332 236 498 minecraft:red_nether_bricks
fill 332 236 499 332 239 499 minecraft:pink_terracotta
setblock 332 236 503 minecraft:red_nether_bricks
fill 332 236 504 335 236 504 minecraft:pink_terracotta
setblock 333 236 487 minecraft:red_nether_bricks
fill 333 236 488 333 239 488 minecraft:pink_terracotta
setblock 333 236 491 minecraft:pink_terracotta
setblock 333 236 492 minecraft:red_nether_bricks
fill 333 236 493 333 239 493 minecraft:pink_terracotta
fill 333 236 503 333 239 503 minecraft:pink_terracotta
setblock 335 236 465 minecraft:red_nether_bricks
fill 335 236 503 335 237 503 minecraft:pink_terracotta
setblock 336 236 464 minecraft:red_nether_bricks
setblock 336 236 465 minecraft:pink_terracotta
setblock 336 236 504 minecraft:red_nether_bricks
fill 337 236 464 337 237 464 minecraft:pink_terracotta
fill 337 236 504 337 237 504 minecraft:pink_terracotta
setblock 346 236 464 minecraft:red_nether_bricks
fill 347 236 464 350 236 464 minecraft:pink_terracotta
fill 348 236 465 349 236 465 minecraft:pink_terracotta
setblock 349 236 466 minecraft:red_nether_bricks
setblock 349 236 504 minecraft:white_concrete
setblock 350 236 465 minecraft:red_nether_bricks
fill 350 236 466 353 236 466 minecraft:pink_terracotta
setblock 350 236 504 minecraft:pink_terracotta
setblock 351 236 464 minecraft:red_nether_bricks
fill 351 236 465 354 236 465 minecraft:pink_terracotta
fill 351 236 467 352 236 467 minecraft:pink_terracotta
setblock 351 236 504 minecraft:red_nether_bricks
fill 352 236 464 355 236 464 minecraft:pink_terracotta
fill 352 236 504 355 236 504 minecraft:pink_terracotta
setblock 353 236 467 minecraft:red_nether_bricks
setblock 354 236 466 minecraft:red_nether_bricks
fill 354 236 467 354 239 467 minecraft:pink_terracotta
setblock 355 236 465 minecraft:red_nether_bricks
fill 355 236 466 355 239 466 minecraft:pink_terracotta
setblock 356 236 464 minecraft:red_nether_bricks
fill 356 236 465 359 236 465 minecraft:pink_terracotta
setblock 356 236 504 minecraft:red_nether_bricks
fill 357 236 464 360 236 464 minecraft:pink_terracotta
setblock 357 236 467 minecraft:pink_terracotta
setblock 357 236 504 minecraft:pink_terracotta
setblock 358 236 466 minecraft:pink_terracotta
setblock 359 236 466 minecraft:red_nether_bricks
setblock 360 236 465 minecraft:red_nether_bricks
fill 360 236 466 360 237 466 minecraft:pink_terracotta
setblock 361 236 464 minecraft:red_nether_bricks
fill 361 236 465 364 236 465 minecraft:pink_terracotta
fill 362 236 464 365 236 464 minecraft:pink_terracotta
setblock 364 236 466 minecraft:red_nether_bricks
setblock 365 236 465 minecraft:red_nether_bricks
fill 365 236 466 368 236 466 minecraft:pink_terracotta
setblock 365 236 504 minecraft:pink_terracotta
setblock 366 236 464 minecraft:red_nether_bricks
fill 366 236 465 366 239 465 minecraft:pink_terracotta
setblock 366 236 504 minecraft:red_nether_bricks
fill 367 236 464 367 239 464 minecraft:pink_terracotta
fill 367 236 504 367 239 504 minecraft:pink_terracotta
fill 368 236 465 369 236 465 minecraft:pink_terracotta
setblock 368 236 467 minecraft:red_nether_bricks
fill 368 236 468 368 239 468 minecraft:pink_terracotta
fill 368 236 470 369 236 470 minecraft:pink_terracotta
fill 368 236 503 368 239 503 minecraft:pink_terracotta
setblock 369 236 466 minecraft:red_nether_bricks
fill 369 236 467 369 239 467 minecraft:pink_terracotta
setblock 369 236 471 minecraft:red_nether_bricks
fill 369 236 472 369 238 473 minecraft:pink_terracotta
fill 369 236 487 369 236 490 minecraft:pink_terracotta
setblock 369 236 491 minecraft:red_nether_bricks
fill 369 236 492 369 236 495 minecraft:pink_terracotta
fill 369 236 502 369 239 502 minecraft:pink_terracotta
setblock 370 236 465 minecraft:red_nether_bricks
fill 370 236 466 370 239 466 minecraft:pink_terracotta
setblock 370 236 470 minecraft:red_nether_bricks
fill 370 236 471 370 239 471 minecraft:pink_terracotta
setblock 370 236 475 minecraft:red_nether_bricks
fill 370 236 476 370 239 476 minecraft:pink_terracotta
fill 370 236 482 370 236 484 minecraft:pink_terracotta
setblock 370 236 485 minecraft:red_nether_bricks
fill 370 236 486 370 239 486 minecraft:pink_terracotta
setblock 370 236 489 minecraft:pink_terracotta
setblock 370 236 490 minecraft:red_nether_bricks
fill 370 236 491 370 239 491 minecraft:pink_terracotta
fill 370 236 493 370 236 494 minecraft:pink_terracotta
setblock 370 236 495 minecraft:red_nether_bricks
fill 370 236 496 370 236 499 minecraft:pink_terracotta
setblock 370 236 500 minecraft:red_nether_bricks
fill 370 236 501 370 239 501 minecraft:pink_terracotta
setblock 330 237 464 minecraft:red_nether_bricks
fill 330 237 465 333 237 465 minecraft:pink_terracotta
setblock 330 237 469 minecraft:red_nether_bricks
fill 330 237 470 330 240 470 minecraft:pink_terracotta
setblock 330 237 474 minecraft:red_nether_bricks
fill 330 237 475 330 237 478 minecraft:pink_terracotta
setblock 330 237 479 minecraft:red_nether_bricks
fill 330 237 480 330 237 483 minecraft:pink_terracotta
setblock 330 237 484 minecraft:red_nether_bricks
fill 330 237 485 330 237 488 minecraft:pink_terracotta
setblock 330 237 489 minecraft:red_nether_bricks
fill 330 237 490 330 237 493 minecraft:pink_terracotta
setblock 330 237 494 minecraft:red_nether_bricks
fill 330 237 495 330 237 498 minecraft:pink_terracotta
setblock 330 237 499 minecraft:red_nether_bricks
fill 330 237 500 330 240 500 minecraft:pink_terracotta
fill 330 237 502 330 237 503 minecraft:pink_terracotta
setblock 330 237 504 minecraft:red_nether_bricks
fill 331 237 464 334 237 464 minecraft:pink_terracotta
setblock 331 237 468 minecraft:red_nether_bricks
fill 331 237 469 331 240 469 minecraft:pink_terracotta
setblock 331 237 473 minecraft:red_nether_bricks
setblock 331 237 483 minecraft:red_nether_bricks
fill 331 237 484 331 237 487 minecraft:pink_terracotta
setblock 331 237 488 minecraft:red_nether_bricks
fill 331 237 489 331 240 489 minecraft:pink_terracotta
setblock 331 237 492 minecraft:pink_terracotta
setblock 331 237 493 minecraft:red_nether_bricks
fill 331 237 494 331 237 497 minecraft:pink_terracotta
setblock 331 237 498 minecraft:red_nether_bricks
fill 331 237 499 331 240 499 minecraft:pink_terracotta
setblock 331 237 503 minecraft:red_nether_bricks
fill 331 237 504 334 237 504 minecraft:pink_terracotta
setblock 332 237 466 minecraft:pink_terracotta
setblock 332 237 467 minecraft:red_nether_bricks
fill 332 237 468 332 239 468 minecraft:pink_terracotta
fill 332 237 470 332 238 470 minecraft:pink_terracotta
fill 332 237 485 332 237 486 minecraft:pink_terracotta
setblock 332 237 487 minecraft:red_nether_bricks
fill 332 237 488 332 240 488 minecraft:pink_terracotta
setblock 332 237 492 minecraft:red_nether_bricks
fill 332 237 493 332 240 493 minecraft:pink_terracotta
fill 332 237 495 332 237 496 minecraft:pink_terracotta
setblock 332 237 497 minecraft:red_nether_bricks
fill 332 237 498 332 240 498 minecraft:pink_terracotta
fill 332 237 500 332 237 501 minecraft:pink_terracotta
fill 332 237 503 332 240 503 minecraft:pink_terracotta
setblock 333 237 466 minecraft:red_nether_bricks
fill 333 237 487 333 238 487 minecraft:pink_terracotta
setblock 333 237 491 minecraft:red_nether_bricks
fill 333 237 492 333 240 492 minecraft:pink_terracotta
setblock 333 237 495 minecraft:pink_terracotta
setblock 333 237 496 minecraft:red_nether_bricks
setblock 334 237 465 minecraft:red_nether_bricks
setblock 335 237 464 minecraft:red_nether_bricks
setblock 335 237 465 minecraft:pink_terracotta
setblock 335 237 504 minecraft:red_nether_bricks
fill 336 237 464 336 238 464 minecraft:pink_terracotta
fill 336 237 504 336 238 504 minecraft:pink_terracotta
setblock 345 237 464 minecraft:white_concrete
fill 346 237 464 349 237 464 minecraft:pink_terracotta
fill 347 237 465 348 237 465 minecraft:pink_terracotta
setblock 349 237 465 minecraft:red_nether_bricks
fill 349 237 466 352 237 466 minecraft:pink_terracotta
setblock 349 237 504 minecraft:pink_terracotta
setblock 350 237 464 minecraft:red_nether_bricks
fill 350 237 465 353 237 465 minecraft:pink_terracotta
fill 350 237 467 351 237 467 minecraft:pink_terracotta
setblock 350 237 504 minecraft:red_nether_bricks
fill 351 237 464 354 237 464 minecraft:pink_terracotta
fill 351 237 504 354 237 504 minecraft:pink_terracotta
setblock 352 237 467 minecraft:red_nether_bricks
setblock 353 237 466 minecraft:red_nether_bricks
fill 353 237 467 353 240 467 minecraft:pink_terracotta
setblock 354 237 465 minecraft:red_nether_bricks
fill 354 237 466 354 240 466 minecraft:pink_terracotta
setblock 355 237 464 minecraft:red_nether_bricks
fill 355 237 465 358 237 465 minecraft:pink_terracotta
setblock 355 237 504 minecraft:red_nether_bricks
fill 356 237 464 359 237 464 minecraft:pink_terracotta
setblock 356 237 504 minecraft:pink_terracotta
setblock 357 237 467 minecraft:red_nether_bricks
setblock 358 237 466 minecraft:red_nether_bricks
setblock 359 237 465 minecraft:red_nether_bricks
fill 359 237 466 359 238 466 minecraft:pink_terracotta
setblock 360 237 464 minecraft:red_nether_bricks
fill 360 237 465 363 237 465 minecraft:pink_terracotta
fill 361 237 464 364 237 464 minecraft:pink_terracotta
setblock 364 237 465 minecraft:red_nether_bricks
fill 364 237 466 367 237 466 minecraft:pink_terracotta
setblock 365 237 464 minecraft:red_nether_bricks
fill 365 237 465 365 240 465 minecraft:pink_terracotta
setblock 365 237 504 minecraft:red_nether_bricks
fill 366 237 464 366 240 464 minecraft:pink_terracotta
fill 366 237 504 366 240 504 minecraft:pink_terracotta
setblock 368 237 465 minecraft:pink_terracotta
setblock 368 237 466 minecraft:red_nether_bricks
fill 368 237 467 368 240 467 minecraft:pink_terracotta
setblock 368 237 470 minecraft:pink_terracotta
setblock 368 237 471 minecraft:red_nether_bricks
fill 368 237 472 368 240 472 minecraft:pink_terracotta
setblock 369 237 464 minecraft:pink_terracotta
setblock 369 237 465 minecraft:red_nether_bricks
fill 369 237 466 369 240 466 minecraft:pink_terracotta
setblock 369 237 470 minecraft:red_nether_bricks
fill 369 237 471 369 240 471 minecraft:pink_terracotta
setblock 369 237 474 minecraft:pink_terracotta
fill 369 237 486 369 237 489 minecraft:pink_terracotta
setblock 369 237 490 minecraft:red_nether_bricks
fill 369 237 491 369 237 494 minecraft:pink_terracotta
setblock 369 237 495 minecraft:red_nether_bricks
fill 369 237 496 369 237 499 minecraft:pink_terracotta
setblock 369 237 500 minecraft:red_nether_bricks
fill 369 237 501 369 240 501 minecraft:pink_terracotta
setblock 370 237 464 minecraft:red_nether_bricks
fill 370 237 465 370 240 465 minecraft:pink_terracotta
setblock 370 237 469 minecraft:red_nether_bricks
fill 370 237 470 370 240 470 minecraft:pink_terracotta
setblock 370 237 473 minecraft:pink_terracotta
setblock 370 237 474 minecraft:red_nether_bricks
fill 370 237 475 370 240 475 minecraft:pink_terracotta
fill 370 237 477 370 237 478 minecraft:pink_terracotta
fill 370 237 482 370 237 483 minecraft:pink_terracotta
setblock 370 237 484 minecraft:red_nether_bricks
fill 370 237 485 370 240 485 minecraft:pink_terracotta
setblock 370 237 489 minecraft:red_nether_bricks
fill 370 237 490 370 240 490 minecraft:pink_terracotta
setblock 370 237 493 minecraft:pink_terracotta
setblock 370 237 494 minecraft:red_nether_bricks
fill 370 237 495 370 237 498 minecraft:pink_terracotta
setblock 370 237 499 minecraft:red_nether_bricks
fill 370 237 500 370 240 500 minecraft:pink_terracotta
setblock 370 237 504 minecraft:red_nether_bricks
fill 330 238 464 332 238 465 minecraft:pink_terracotta
setblock 330 238 468 minecraft:red_nether_bricks
fill 330 238 469 330 241 469 minecraft:pink_terracotta
setblock 330 238 472 minecraft:pink_terracotta
setblock 330 238 473 minecraft:red_nether_bricks
fill 330 238 474 330 238 477 minecraft:pink_terracotta
setblock 330 238 478 minecraft:red_nether_bricks
fill 330 238 479 330 238 482 minecraft:pink_terracotta
setblock 330 238 483 minecraft:red_nether_bricks
fill 330 238 484 330 238 487 minecraft:pink_terracotta
setblock 330 238 488 minecraft:red_nether_bricks
fill 330 238 489 330 238 492 minecraft:pink_terracotta
setblock 330 238 493 minecraft:red_nether_bricks
fill 330 238 494 330 238 497 minecraft:pink_terracotta
setblock 330 238 498 minecraft:red_nether_bricks
fill 330 238 499 330 241 499 minecraft:pink_terracotta
setblock 330 238 502 minecraft:pink_terracotta
setblock 330 238 503 minecraft:red_nether_bricks
fill 330 238 504 333 238 504 minecraft:pink_terracotta
setblock 331 238 467 minecraft:red_nether_bricks
fill 331 238 468 331 241 468 minecraft:pink_terracotta
setblock 331 238 472 minecraft:red_nether_bricks
fill 331 238 473 331 239 475 minecraft:pink_terracotta
fill 331 238 483 331 238 486 minecraft:pink_terracotta
setblock 331 238 487 minecraft:red_nether_bricks
fill 331 238 488 331 241 488 minecraft:pink_terracotta
setblock 331 238 492 minecraft:red_nether_bricks
fill 331 238 493 331 238 496 minecraft:pink_terracotta
setblock 331 238 497 minecraft:red_nether_bricks
fill 331 238 498 331 241 498 minecraft:pink_terracotta
setblock 331 238 502 minecraft:red_nether_bricks
fill 331 238 503 331 241 503 minecraft:pink_terracotta
setblock 332 238 466 minecraft:red_nether_bricks
setblock 332 238 467 minecraft:pink_terracotta
setblock 332 238 471 minecraft:red_nether_bricks
setblock 332 238 485 minecraft:pink_terracotta
setblock 332 238 486 minecraft:red_nether_bricks
fill 332 238 487 332 241 487 minecraft:pink_terracotta
setblock 332 238 491 minecraft:red_nether_bricks
fill 332 238 492 332 241 492 minecraft:pink_terracotta
setblock 332 238 495 minecraft:pink_terracotta
setblock 332 238 496 minecraft:red_nether_bricks
fill 332 238 497 332 241 497 minecraft:pink_terracotta
setblock 332 238 500 minecraft:pink_terracotta
setblock 333 238 464 minecraft:pink_terracotta
setblock 333 238 465 minecraft:red_nether_bricks
setblock 333 238 490 minecraft:red_nether_bricks
fill 333 238 491 333 241 491 minecraft:pink_terracotta
setblock 333 238 495 minecraft:red_nether_bricks
fill 333 238 496 333 240 496 minecraft:pink_terracotta
setblock 334 238 464 minecraft:red_nether_bricks
setblock 334 238 465 minecraft:pink_terracotta
setblock 334 238 504 minecraft:red_nether_bricks
fill 335 238 464 335 239 464 minecraft:pink_terracotta
fill 335 238 504 335 239 504 minecraft:pink_terracotta
setblock 339 238 464 minecraft:white_concrete
setblock 342 238 504 minecraft:white_concrete
fill 346 238 464 348 238 464 minecraft:pink_terracotta
setblock 347 238 465 minecraft:pink_terracotta
setblock 348 238 465 minecraft:red_nether_bricks
fill 348 238 466 351 238 466 minecraft:pink_terracotta
setblock 349 238 464 minecraft:red_nether_bricks
fill 349 238 465 352 238 465 minecraft:pink_terracotta
setblock 349 238 504 minecraft:red_nether_bricks
fill 350 238 464 353 238 464 minecraft:pink_terracotta
setblock 350 238 467 minecraft:pink_terracotta
fill 350 238 504 353 238 504 minecraft:pink_terracotta
setblock 351 238 467 minecraft:red_nether_bricks
setblock 352 238 466 minecraft:red_nether_bricks
fill 352 238 467 352 240 467 minecraft:pink_terracotta
setblock 353 238 465 minecraft:red_nether_bricks
fill 353 238 466 353 241 466 minecraft:pink_terracotta
setblock 354 238 464 minecraft:red_nether_bricks
fill 354 238 465 357 238 465 minecraft:pink_terracotta
setblock 354 238 504 minecraft:red_nether_bricks
fill 355 238 464 358 238 464 minecraft:pink_terracotta
setblock 355 238 467 minecraft:pink_terracotta
setblock 355 238 504 minecraft:pink_terracotta
setblock 356 238 467 minecraft:red_nether_bricks
setblock 357 238 466 minecraft:red_nether_bricks
setblock 358 238 465 minecraft:red_nether_bricks
setblock 358 238 466 minecraft:pink_terracotta
setblock 359 238 464 minecraft:red_nether_bricks
fill 359 238 465 362 238 465 minecraft:pink_terracotta
fill 360 238 464 363 238 464 minecraft:pink_terracotta
setblock 361 238 504 minecraft:white_concrete
setblock 363 238 465 minecraft:red_nether_bricks
setblock 364 238 464 minecraft:red_nether_bricks
fill 364 238 465 364 239 466 minecraft:pink_terracotta
setblock 364 238 504 minecraft:red_nether_bricks
fill 365 238 464 365 241 464 minecraft:pink_terracotta
fill 365 238 466 366 238 466 minecraft:pink_terracotta
fill 365 238 504 365 241 504 minecraft:pink_terracotta
setblock 367 238 466 minecraft:red_nether_bricks
setblock 367 238 468 minecraft:pink_terracotta
fill 367 238 503 367 240 503 minecraft:pink_terracotta
setblock 368 238 465 minecraft:red_nether_bricks
fill 368 238 466 368 241 466 minecraft:pink_terracotta
setblock 368 238 470 minecraft:red_nether_bricks
fill 368 238 471 368 241 471 minecraft:pink_terracotta
fill 368 238 491 369 238 493 minecraft:pink_terracotta
setblock 369 238 464 minecraft:red_nether_bricks
fill 369 238 465 369 241 465 minecraft:pink_terracotta
setblock 369 238 469 minecraft:red_nether_bricks
fill 369 238 470 369 241 470 minecraft:pink_terracotta
setblock 369 238 474 minecraft:red_nether_bricks
fill 369 238 475 369 241 475 minecraft:pink_terracotta
fill 369 238 486 369 238 488 minecraft:pink_terracotta
setblock 369 238 489 minecraft:red_nether_bricks
fill 369 238 490 369 241 490 minecraft:pink_terracotta
setblock 369 238 494 minecraft:red_nether_bricks
fill 369 238 495 369 238 498 minecraft:pink_terracotta
setblock 369 238 499 minecraft:red_nether_bricks
fill 369 238 500 369 241 500 minecraft:pink_terracotta
setblock 369 238 504 minecraft:red_nether_bricks
fill 370 238 464 370 241 464 minecraft:pink_terracotta
setblock 370 238 468 minecraft:red_nether_bricks
fill 370 238 469 370 241 469 minecraft:pink_terracotta
setblock 370 238 473 minecraft:red_nether_bricks
fill 370 238 474 370 241 474 minecraft:pink_terracotta
setblock 370 238 477 minecraft:pink_terracotta
setblock 370 238 478 minecraft:red_nether_bricks
fill 370 238 479 370 241 479 minecraft:pink_terracotta
setblock 370 238 482 minecraft:pink_terracotta
setblock 370 238 483 minecraft:red_nether_bricks
fill 370 238 484 370 240 484 minecraft:pink_terracotta
setblock 370 238 488 minecraft:red_nether_bricks
fill 370 238 489 370 241 489 minecraft:pink_terracotta
setblock 370 238 493 minecraft:red_nether_bricks
fill 370 238 494 370 238 497 minecraft:pink_terracotta
setblock 370 238 498 minecraft:red_nether_bricks
fill 370 238 499 370 241 499 minecraft:pink_terracotta
setblock 370 238 503 minecraft:red_nether_bricks
fill 370 238 504 370 241 504 minecraft:pink_terracotta
fill 330 239 464 331 239 465 minecraft:pink_terracotta
setblock 330 239 467 minecraft:red_nether_bricks
fill 330 239 468 330 242 468 minecraft:pink_terracotta
setblock 330 239 472 minecraft:red_nether_bricks
fill 330 239 473 330 239 476 minecraft:pink_terracotta
setblock 330 239 477 minecraft:red_nether_bricks
fill 330 239 478 330 239 481 minecraft:pink_terracotta
setblock 330 239 482 minecraft:red_nether_bricks
fill 330 239 483 330 239 486 minecraft:pink_terracotta
setblock 330 239 487 minecraft:red_nether_bricks
fill 330 239 488 330 239 491 minecraft:pink_terracotta
setblock 330 239 492 minecraft:red_nether_bricks
fill 330 239 493 330 239 496 minecraft:pink_terracotta
setblock 330 239 497 minecraft:red_nether_bricks
fill 330 239 498 330 242 498 minecraft:pink_terracotta
setblock 330 239 502 minecraft:red_nether_bricks
fill 330 239 503 330 241 504 minecraft:pink_terracotta
setblock 331 239 466 minecraft:red_nether_bricks
fill 331 239 467 331 241 467 minecraft:pink_terracotta
setblock 331 239 471 minecraft:red_nether_bricks
fill 331 239 472 331 242 472 minecraft:pink_terracotta
fill 331 239 483 331 239 485 minecraft:pink_terracotta
setblock 331 239 486 minecraft:red_nether_bricks
fill 331 239 487 331 242 487 minecraft:pink_terracotta
setblock 331 239 491 minecraft:red_nether_bricks
fill 331 239 492 331 239 495 minecraft:pink_terracotta
setblock 331 239 496 minecraft:red_nether_bricks
fill 331 239 497 331 242 497 minecraft:pink_terracotta
setblock 331 239 501 minecraft:red_nether_bricks
fill 331 239 502 331 242 502 minecraft:pink_terracotta
fill 331 239 504 332 239 504 minecraft:pink_terracotta
setblock 332 239 464 minecraft:pink_terracotta
setblock 332 239 465 minecraft:red_nether_bricks
setblock 332 239 466 minecraft:light[level=12]
setblock 332 239 470 minecraft:red_nether_bricks
setblock 332 239 471 minecraft:pink_terracotta
setblock 332 239 474 minecraft:light[level=12]
setblock 332 239 482 minecraft:light[level=12]
setblock 332 239 485 minecraft:red_nether_bricks
fill 332 239 486 332 240 486 minecraft:pink_terracotta
setblock 332 239 490 minecraft:red_nether_bricks
fill 332 239 491 332 242 491 minecraft:pink_terracotta
setblock 332 239 494 minecraft:pink_terracotta
setblock 332 239 495 minecraft:red_nether_bricks
fill 332 239 496 332 242 496 minecraft:pink_terracotta
setblock 332 239 500 minecraft:red_nether_bricks
setblock 333 239 464 minecraft:red_nether_bricks
setblock 333 239 465 minecraft:pink_terracotta
setblock 333 239 489 minecraft:red_nether_bricks
fill 333 239 490 333 241 490 minecraft:pink_terracotta
setblock 333 239 494 minecraft:red_nether_bricks
fill 333 239 495 333 241 495 minecraft:pink_terracotta
setblock 333 239 504 minecraft:red_nether_bricks
fill 334 239 464 334 240 464 minecraft:pink_terracotta
fill 334 239 504 334 240 504 minecraft:pink_terracotta
setblock 340 239 466 minecraft:light[level=12]
setblock 340 239 474 minecraft:light[level=12]
setblock 340 239 482 minecraft:light[level=12]
setblock 340 239 490 minecraft:light[level=12]
setblock 340 239 498 minecraft:light[level=12]
fill 346 239 464 347 239 464 minecraft:pink_terracotta
setblock 347 239 465 minecraft:red_nether_bricks
setblock 348 239 464 minecraft:red_nether_bricks
fill 348 239 465 350 239 466 minecraft:pink_terracotta
setblock 348 239 474 minecraft:light[level=12]
setblock 348 239 482 minecraft:light[level=12]
setblock 348 239 490 minecraft:light[level=12]
setblock 348 239 498 minecraft:light[level=12]
setblock 348 239 504 minecraft:white_concrete
fill 349 239 464 352 239 464 minecraft:pink_terracotta
fill 349 239 504 352 239 504 minecraft:pink_terracotta
setblock 350 239 467 minecraft:red_nether_bricks
setblock 351 239 465 minecraft:pink_terracotta
setblock 351 239 466 minecraft:red_nether_bricks
fill 351 239 467 351 240 467 minecraft:pink_terracotta
setblock 352 239 465 minecraft:red_nether_bricks
fill 352 239 466 352 241 466 minecraft:pink_terracotta
setblock 353 239 464 minecraft:red_nether_bricks
fill 353 239 465 356 239 465 minecraft:pink_terracotta
setblock 353 239 504 minecraft:red_nether_bricks
fill 354 239 464 357 239 464 minecraft:pink_terracotta
setblock 354 239 504 minecraft:pink_terracotta
setblock 355 239 467 minecraft:red_nether_bricks
setblock 356 239 466 minecraft:red_nether_bricks
setblock 356 239 474 minecraft:light[level=12]
setblock 356 239 482 minecraft:light[level=12]
setblock 356 239 490 minecraft:light[level=12]
setblock 356 239 498 minecraft:light[level=12]
setblock 357 239 465 minecraft:red_nether_bricks
setblock 357 239 466 minecraft:pink_terracotta
setblock 358 239 464 minecraft:red_nether_bricks
fill 358 239 465 361 239 465 minecraft:pink_terracotta
fill 359 239 464 362 239 464 minecraft:pink_terracotta
setblock 362 239 465 minecraft:red_nether_bricks
setblock 363 239 464 minecraft:red_nether_bricks
fill 363 239 465 363 240 465 minecraft:pink_terracotta
fill 364 239 464 364 242 464 minecraft:pink_terracotta
setblock 364 239 474 minecraft:light[level=12]
setblock 364 239 482 minecraft:light[level=12]
setblock 364 239 490 minecraft:light[level=12]
setblock 364 239 498 minecraft:light[level=12]
fill 364 239 504 364 242 504 minecraft:pink_terracotta
setblock 365 239 466 minecraft:pink_terracotta
setblock 366 239 466 minecraft:red_nether_bricks
setblock 367 239 465 minecraft:red_nether_bricks
fill 367 239 466 367 241 466 minecraft:pink_terracotta
setblock 368 239 464 minecraft:red_nether_bricks
fill 368 239 465 368 242 465 minecraft:pink_terracotta
setblock 368 239 469 minecraft:red_nether_bricks
fill 368 239 470 368 242 470 minecraft:pink_terracotta
setblock 368 239 473 minecraft:pink_terracotta
fill 368 239 490 368 239 493 minecraft:pink_terracotta
setblock 368 239 494 minecraft:red_nether_bricks
fill 368 239 495 370 239 496 minecraft:pink_terracotta
setblock 368 239 504 minecraft:red_nether_bricks
fill 369 239 464 369 242 464 minecraft:pink_terracotta
setblock 369 239 468 minecraft:red_nether_bricks
fill 369 239 469 369 242 469 minecraft:pink_terracotta
setblock 369 239 472 minecraft:pink_terracotta
setblock 369 239 473 minecraft:red_nether_bricks
fill 369 239 474 369 242 474 minecraft:pink_terracotta
fill 369 239 486 369 239 487 minecraft:pink_terracotta
setblock 369 239 488 minecraft:red_nether_bricks
fill 369 239 489 369 242 489 minecraft:pink_terracotta
fill 369 239 491 369 239 492 minecraft:pink_terracotta
setblock 369 239 493 minecraft:red_nether_bricks
fill 369 239 494 370 241 494 minecraft:pink_terracotta
setblock 369 239 497 minecraft:pink_terracotta
setblock 369 239 498 minecraft:red_nether_bricks
fill 369 239 499 369 242 499 minecraft:pink_terracotta
setblock 369 239 503 minecraft:red_nether_bricks
fill 369 239 504 369 242 504 minecraft:pink_terracotta
setblock 370 239 467 minecraft:red_nether_bricks
fill 370 239 468 370 242 468 minecraft:pink_terracotta
setblock 370 239 472 minecraft:red_nether_bricks
fill 370 239 473 370 242 473 minecraft:pink_terracotta
setblock 370 239 477 minecraft:red_nether_bricks
fill 370 239 478 370 242 478 minecraft:pink_terracotta
setblock 370 239 482 minecraft:red_nether_bricks
fill 370 239 483 370 240 483 minecraft:pink_terracotta
setblock 370 239 487 minecraft:red_nether_bricks
fill 370 239 488 370 242 488 minecraft:pink_terracotta
setblock 370 239 492 minecraft:red_nether_bricks
fill 370 239 493 370 242 493 minecraft:pink_terracotta
setblock 370 239 497 minecraft:red_nether_bricks
fill 370 239 498 370 242 498 minecraft:pink_terracotta
setblock 370 239 502 minecraft:red_nether_bricks
fill 370 239 503 370 242 503 minecraft:pink_terracotta
fill 330 240 464 330 240 465 minecraft:pink_terracotta
setblock 330 240 466 minecraft:red_nether_bricks
fill 330 240 467 330 243 467 minecraft:pink_terracotta
setblock 330 240 471 minecraft:red_nether_bricks
fill 330 240 472 330 240 475 minecraft:pink_terracotta
setblock 330 240 476 minecraft:red_nether_bricks
fill 330 240 477 330 240 480 minecraft:pink_terracotta
setblock 330 240 481 minecraft:red_nether_bricks
fill 330 240 482 330 240 485 minecraft:pink_terracotta
setblock 330 240 486 minecraft:red_nether_bricks
fill 330 240 487 330 240 490 minecraft:pink_terracotta
setblock 330 240 491 minecraft:red_nether_bricks
fill 330 240 492 330 240 495 minecraft:pink_terracotta
setblock 330 240 496 minecraft:red_nether_bricks
fill 330 240 497 330 243 497 minecraft:pink_terracotta
setblock 330 240 501 minecraft:red_nether_bricks
fill 330 240 502 330 243 502 minecraft:pink_terracotta
setblock 331 240 464 minecraft:pink_terracotta
setblock 331 240 465 minecraft:red_nether_bricks
setblock 331 240 466 minecraft:pink_terracotta
setblock 331 240 470 minecraft:red_nether_bricks
fill 331 240 471 331 242 471 minecraft:pink_terracotta
fill 331 240 473 331 240 474 minecraft:pink_terracotta
setblock 331 240 475 minecraft:red_nether_bricks
fill 331 240 476 331 242 476 minecraft:pink_terracotta
setblock 331 240 484 minecraft:pink_terracotta
setblock 331 240 485 minecraft:red_nether_bricks
fill 331 240 486 331 242 486 minecraft:pink_terracotta
setblock 331 240 490 minecraft:red_nether_bricks
fill 331 240 491 331 240 494 minecraft:pink_terracotta
setblock 331 240 495 minecraft:red_nether_bricks
fill 331 240 496 331 243 496 minecraft:pink_terracotta
setblock 331 240 500 minecraft:red_nether_bricks
fill 331 240 501 331 243 501 minecraft:pink_terracotta
setblock 331 240 504 minecraft:pink_terracotta
setblock 332 240 464 minecraft:red_nether_bricks
setblock 332 240 465 minecraft:pink_terracotta
setblock 332 240 489 minecraft:red_nether_bricks
fill 332 240 490 332 243 490 minecraft:pink_terracotta
setblock 332 240 494 minecraft:red_nether_bricks
fill 332 240 495 332 243 495 minecraft:pink_terracotta
setblock 332 240 499 minecraft:red_nether_bricks
setblock 332 240 500 minecraft:pink_terracotta
setblock 332 240 504 minecraft:red_nether_bricks
setblock 333 240 464 minecraft:pink_terracotta
setblock 333 240 489 minecraft:pink_terracotta
setblock 333 240 493 minecraft:red_nether_bricks
fill 333 240 494 333 242 494 minecraft:pink_terracotta
fill 333 240 504 333 241 504 minecraft:pink_terracotta
fill 344 240 500 345 273 501 minecraft:red_nether_bricks
fill 345 240 502 345 250 502 minecraft:red_nether_bricks
setblock 346 240 464 minecraft:pink_terracotta
setblock 347 240 464 minecraft:red_nether_bricks
fill 347 240 465 350 240 465 minecraft:pink_terracotta
fill 348 240 464 351 240 464 minecraft:pink_terracotta
fill 348 240 466 349 240 466 minecraft:pink_terracotta
setblock 350 240 466 minecraft:red_nether_bricks
setblock 350 240 467 minecraft:pink_terracotta
fill 350 240 504 351 240 504 minecraft:pink_terracotta
setblock 351 240 465 minecraft:red_nether_bricks
fill 351 240 466 351 241 466 minecraft:pink_terracotta
setblock 352 240 464 minecraft:red_nether_bricks
fill 352 240 465 355 240 465 minecraft:pink_terracotta
setblock 352 240 504 minecraft:red_nether_bricks
fill 353 240 464 356 240 464 minecraft:pink_terracotta
setblock 354 240 504 minecraft:white_concrete
setblock 355 240 466 minecraft:red_nether_bricks
setblock 356 240 465 minecraft:red_nether_bricks
setblock 357 240 464 minecraft:red_nether_bricks
fill 357 240 465 358 240 465 minecraft:pink_terracotta
fill 358 240 464 361 240 464 minecraft:pink_terracotta
setblock 362 240 464 minecraft:red_nether_bricks
setblock 362 240 465 minecraft:pink_terracotta
fill 362 240 495 364 273 496 minecraft:red_nether_bricks
fill 363 240 464 363 243 464 minecraft:pink_terracotta
fill 363 240 494 363 273 494 minecraft:red_nether_bricks
fill 363 240 497 363 273 497 minecraft:red_nether_bricks
fill 364 240 465 364 241 465 minecraft:pink_terracotta
setblock 365 240 466 minecraft:red_nether_bricks
setblock 366 240 465 minecraft:red_nether_bricks
setblock 366 240 466 minecraft:pink_terracotta
setblock 367 240 464 minecraft:red_nether_bricks
fill 367 240 465 367 243 465 minecraft:pink_terracotta
setblock 367 240 504 minecraft:red_nether_bricks
fill 368 240 464 368 243 464 minecraft:pink_terracotta
setblock 368 240 468 minecraft:red_nether_bricks
fill 368 240 469 368 242 469 minecraft:pink_terracotta
setblock 368 240 473 minecraft:red_nether_bricks
fill 368 240 490 368 240 492 minecraft:pink_terracotta
setblock 368 240 493 minecraft:red_nether_bricks
fill 368 240 494 368 240 497 minecraft:pink_terracotta
setblock 368 240 498 minecraft:red_nether_bricks
setblock 368 240 503 minecraft:red_nether_bricks
fill 368 240 504 368 243 504 minecraft:pink_terracotta
setblock 369 240 467 minecraft:red_nether_bricks
fill 369 240 468 369 243 468 minecraft:pink_terracotta
setblock 369 240 472 minecraft:red_nether_bricks
fill 369 240 473 369 243 473 minecraft:pink_terracotta
setblock 369 240 476 minecraft:pink_terracotta
setblock 369 240 487 minecraft:red_nether_bricks
fill 369 240 488 369 241 488 minecraft:pink_terracotta
setblock 369 240 491 minecraft:pink_terracotta
setblock 369 240 492 minecraft:red_nether_bricks
fill 369 240 493 369 243 493 minecraft:pink_terracotta
fill 369 240 495 369 240 496 minecraft:pink_terracotta
setblock 369 240 497 minecraft:red_nether_bricks
fill 369 240 498 369 243 498 minecraft:pink_terracotta
setblock 369 240 502 minecraft:red_nether_bricks
fill 369 240 503 369 243 503 minecraft:pink_terracotta
setblock 370 240 466 minecraft:red_nether_bricks
fill 370 240 467 370 243 467 minecraft:pink_terracotta
setblock 370 240 471 minecraft:red_nether_bricks
fill 370 240 472 370 243 472 minecraft:pink_terracotta
setblock 370 240 476 minecraft:red_nether_bricks
fill 370 240 477 370 243 477 minecraft:pink_terracotta
setblock 370 240 486 minecraft:red_nether_bricks
fill 370 240 487 370 243 487 minecraft:pink_terracotta
setblock 370 240 491 minecraft:red_nether_bricks
fill 370 240 492 370 243 492 minecraft:pink_terracotta
setblock 370 240 495 minecraft:pink_terracotta
setblock 370 240 496 minecraft:red_nether_bricks
fill 370 240 497 370 243 497 minecraft:pink_terracotta
setblock 370 240 501 minecraft:red_nether_bricks
fill 370 240 502 370 243 502 minecraft:pink_terracotta
setblock 330 241 464 minecraft:pink_terracotta
setblock 330 241 465 minecraft:red_nether_bricks
fill 330 241 466 330 242 466 minecraft:pink_terracotta
setblock 330 241 470 minecraft:red_nether_bricks
fill 330 241 471 330 241 474 minecraft:pink_terracotta
setblock 330 241 475 minecraft:red_nether_bricks
fill 330 241 476 330 241 479 minecraft:pink_terracotta
setblock 330 241 480 minecraft:red_nether_bricks
fill 330 241 481 330 241 484 minecraft:pink_terracotta
setblock 330 241 485 minecraft:red_nether_bricks
fill 330 241 486 330 241 489 minecraft:pink_terracotta
setblock 330 241 490 minecraft:red_nether_bricks
fill 330 241 491 330 241 494 minecraft:pink_terracotta
setblock 330 241 495 minecraft:red_nether_bricks
fill 330 241 496 330 244 496 minecraft:pink_terracotta
setblock 330 241 500 minecraft:red_nether_bricks
fill 330 241 501 330 244 501 minecraft:pink_terracotta
setblock 331 241 464 minecraft:red_nether_bricks
setblock 331 241 469 minecraft:red_nether_bricks
fill 331 241 470 331 242 470 minecraft:pink_terracotta
setblock 331 241 473 minecraft:pink_terracotta
setblock 331 241 474 minecraft:red_nether_bricks
fill 331 241 475 331 243 475 minecraft:pink_terracotta
setblock 331 241 484 minecraft:red_nether_bricks
setblock 331 241 485 minecraft:pink_terracotta
setblock 331 241 489 minecraft:red_nether_bricks
fill 331 241 490 331 241 493 minecraft:pink_terracotta
setblock 331 241 494 minecraft:red_nether_bricks
fill 331 241 495 331 244 495 minecraft:pink_terracotta
setblock 331 241 499 minecraft:red_nether_bricks
fill 331 241 500 331 244 500 minecraft:pink_terracotta
setblock 331 241 504 minecraft:red_nether_bricks
setblock 332 241 464 minecraft:pink_terracotta
setblock 332 241 488 minecraft:red_nether_bricks
fill 332 241 489 332 242 489 minecraft:pink_terracotta
setblock 332 241 493 minecraft:red_nether_bricks
fill 332 241 494 332 244 494 minecraft:pink_terracotta
setblock 332 241 498 minecraft:red_nether_bricks
setblock 332 241 499 minecraft:pink_terracotta
fill 332 241 504 332 242 504 minecraft:pink_terracotta
setblock 333 241 492 minecraft:red_nether_bricks
fill 333 241 493 333 242 493 minecraft:pink_terracotta
setblock 335 241 504 minecraft:white_concrete
setblock 340 241 464 minecraft:white_concrete
fill 343 241 501 343 242 501 minecraft:red_terracotta
fill 344 241 502 344 242 502 minecraft:red_terracotta
setblock 346 241 464 minecraft:red_nether_bricks
fill 346 241 500 346 242 502 minecraft:red_terracotta
fill 347 241 464 349 241 465 minecraft:pink_terracotta
setblock 349 241 466 minecraft:red_nether_bricks
setblock 350 241 464 minecraft:pink_terracotta
setblock 350 241 465 minecraft:red_nether_bricks
setblock 350 241 466 minecraft:pink_terracotta
setblock 351 241 464 minecraft:red_nether_bricks
fill 351 241 465 354 241 465 minecraft:pink_terracotta
fill 352 241 464 355 241 464 minecraft:pink_terracotta
setblock 355 241 465 minecraft:red_nether_bricks
setblock 356 241 464 minecraft:red_nether_bricks
setblock 356 241 465 minecraft:pink_terracotta
fill 357 241 464 360 241 464 minecraft:pink_terracotta
setblock 360 241 504 minecraft:white_concrete
setblock 361 241 464 minecraft:red_nether_bricks
fill 361 241 495 361 242 496 minecraft:red_terracotta
fill 362 241 464 362 242 464 minecraft:pink_terracotta
fill 362 241 494 362 242 494 minecraft:red_terracotta
fill 362 241 497 362 242 497 minecraft:red_terracotta
fill 364 241 494 364 242 494 minecraft:red_terracotta
fill 364 241 497 364 242 497 minecraft:red_terracotta
setblock 365 241 465 minecraft:red_nether_bricks
fill 365 241 495 365 242 496 minecraft:red_terracotta
setblock 366 241 464 minecraft:red_nether_bricks
fill 366 241 465 366 243 465 minecraft:pink_terracotta
setblock 366 241 504 minecraft:red_nether_bricks
fill 367 241 464 367 244 464 minecraft:pink_terracotta
fill 367 241 471 367 244 471 minecraft:white_concrete
setblock 367 241 503 minecraft:red_nether_bricks
fill 367 241 504 367 244 504 minecraft:pink_terracotta
setblock 368 241 467 minecraft:red_nether_bricks
fill 368 241 468 368 242 468 minecraft:pink_terracotta
setblock 368 241 472 minecraft:red_nether_bricks
fill 368 241 473 368 242 473 minecraft:pink_terracotta
setblock 368 241 491 minecraft:pink_terracotta
setblock 368 241 492 minecraft:red_nether_bricks
fill 368 241 493 368 241 496 minecraft:pink_terracotta
setblock 368 241 497 minecraft:red_nether_bricks
fill 368 241 498 368 243 499 minecraft:pink_terracotta
fill 368 241 503 368 244 503 minecraft:pink_terracotta
setblock 369 241 466 minecraft:red_nether_bricks
fill 369 241 467 369 243 467 minecraft:pink_terracotta
setblock 369 241 471 minecraft:red_nether_bricks
fill 369 241 472 369 244 472 minecraft:pink_terracotta
setblock 369 241 476 minecraft:red_nether_bricks
setblock 369 241 491 minecraft:red_nether_bricks
fill 369 241 492 369 244 492 minecraft:pink_terracotta
setblock 369 241 495 minecraft:pink_terracotta
setblock 369 241 496 minecraft:red_nether_bricks
fill 369 241 497 369 244 497 minecraft:pink_terracotta
setblock 369 241 501 minecraft:red_nether_bricks
fill 369 241 502 369 244 502 minecraft:pink_terracotta
setblock 370 241 465 minecraft:red_nether_bricks
fill 370 241 466 370 244 466 minecraft:pink_terracotta
setblock 370 241 470 minecraft:red_nether_bricks
fill 370 241 471 370 244 471 minecraft:pink_terracotta
setblock 370 241 475 minecraft:red_nether_bricks
fill 370 241 476 370 244 476 minecraft:pink_terracotta
setblock 370 241 485 minecraft:red_nether_bricks
fill 370 241 486 370 242 486 minecraft:pink_terracotta
setblock 370 241 490 minecraft:red_nether_bricks
fill 370 241 491 370 244 491 minecraft:pink_terracotta
setblock 370 241 495 minecraft:red_nether_bricks
fill 370 241 496 370 244 496 minecraft:pink_terracotta
setblock 370 241 500 minecraft:red_nether_bricks
fill 370 241 501 370 244 501 minecraft:pink_terracotta
setblock 330 242 464 minecraft:red_nether_bricks
setblock 330 242 465 minecraft:pink_terracotta
setblock 330 242 469 minecraft:red_nether_bricks
fill 330 242 470 330 242 473 minecraft:pink_terracotta
setblock 330 242 474 minecraft:red_nether_bricks
fill 330 242 475 330 242 478 minecraft:pink_terracotta
setblock 330 242 479 minecraft:red_nether_bricks
fill 330 242 480 330 242 483 minecraft:pink_terracotta
setblock 330 242 484 minecraft:red_nether_bricks
fill 330 242 485 330 242 488 minecraft:pink_terracotta
setblock 330 242 489 minecraft:red_nether_bricks
fill 330 242 490 330 242 493 minecraft:pink_terracotta
setblock 330 242 494 minecraft:red_nether_bricks
fill 330 242 495 330 245 495 minecraft:pink_terracotta
setblock 330 242 499 minecraft:red_nether_bricks
fill 330 242 500 330 245 500 minecraft:pink_terracotta
setblock 330 242 503 minecraft:pink_terracotta
setblock 330 242 504 minecraft:red_nether_bricks
setblock 331 242 469 minecraft:pink_terracotta
setblock 331 242 473 minecraft:red_nether_bricks
fill 331 242 474 331 243 474 minecraft:pink_terracotta
fill 331 242 477 331 245 478 minecraft:white_concrete
setblock 331 242 488 minecraft:red_nether_bricks
fill 331 242 489 331 242 492 minecraft:pink_terracotta
setblock 331 242 493 minecraft:red_nether_bricks
fill 331 242 494 331 245 494 minecraft:pink_terracotta
setblock 331 242 498 minecraft:red_nether_bricks
fill 331 242 499 331 245 499 minecraft:pink_terracotta
fill 331 242 504 331 243 504 minecraft:pink_terracotta
fill 332 242 477 332 245 477 minecraft:white_concrete
setblock 332 242 492 minecraft:red_nether_bricks
fill 332 242 493 332 244 493 minecraft:pink_terracotta
setblock 332 242 497 minecraft:red_nether_bricks
fill 332 242 498 332 243 498 minecraft:pink_terracotta
setblock 334 242 464 minecraft:white_concrete
setblock 341 242 504 minecraft:white_concrete
setblock 343 242 500 minecraft:red_terracotta
setblock 343 242 502 minecraft:red_terracotta
fill 344 242 499 345 242 499 minecraft:red_terracotta
fill 344 242 503 345 242 503 minecraft:red_terracotta
fill 347 242 464 349 242 464 minecraft:pink_terracotta
setblock 348 242 465 minecraft:pink_terracotta
setblock 349 242 465 minecraft:red_nether_bricks
setblock 350 242 464 minecraft:red_nether_bricks
fill 350 242 465 353 242 465 minecraft:pink_terracotta
fill 351 242 464 354 242 464 minecraft:pink_terracotta
setblock 355 242 464 minecraft:red_nether_bricks
setblock 356 242 464 minecraft:pink_terracotta
setblock 359 242 464 minecraft:white_concrete
setblock 361 242 494 minecraft:red_terracotta
setblock 361 242 497 minecraft:red_terracotta
fill 362 242 493 364 242 493 minecraft:red_terracotta
fill 362 242 498 364 242 498 minecraft:red_terracotta
setblock 365 242 464 minecraft:red_nether_bricks
setblock 365 242 465 minecraft:pink_terracotta
setblock 365 242 494 minecraft:red_terracotta
setblock 365 242 497 minecraft:red_terracotta
setblock 365 242 504 minecraft:red_nether_bricks
fill 366 242 464 366 245 464 minecraft:pink_terracotta
fill 366 242 504 366 245 504 minecraft:pink_terracotta
fill 367 242 470 367 243 470 minecraft:white_concrete
fill 367 242 472 367 243 472 minecraft:white_concrete
fill 367 242 503 367 245 503 minecraft:pink_terracotta
setblock 368 242 467 minecraft:pink_terracotta
setblock 368 242 471 minecraft:red_nether_bricks
setblock 368 242 472 minecraft:pink_terracotta
setblock 368 242 491 minecraft:red_nether_bricks
fill 368 242 492 368 242 495 minecraft:pink_terracotta
setblock 368 242 496 minecraft:red_nether_bricks
fill 368 242 497 368 245 497 minecraft:pink_terracotta
setblock 368 242 500 minecraft:pink_terracotta
setblock 369 242 465 minecraft:red_nether_bricks
fill 369 242 466 369 243 466 minecraft:pink_terracotta
setblock 369 242 470 minecraft:red_nether_bricks
fill 369 242 471 369 245 471 minecraft:pink_terracotta
setblock 369 242 475 minecraft:red_nether_bricks
fill 369 242 476 369 244 476 minecraft:pink_terracotta
setblock 369 242 490 minecraft:red_nether_bricks
fill 369 242 491 369 245 491 minecraft:pink_terracotta
setblock 369 242 494 minecraft:pink_terracotta
setblock 369 242 495 minecraft:red_nether_bricks
fill 369 242 496 369 245 496 minecraft:pink_terracotta
setblock 369 242 500 minecraft:red_nether_bricks
fill 369 242 501 369 245 501 minecraft:pink_terracotta
setblock 370 242 464 minecraft:red_nether_bricks
fill 370 242 465 370 244 465 minecraft:pink_terracotta
setblock 370 242 469 minecraft:red_nether_bricks
fill 370 242 470 370 245 470 minecraft:pink_terracotta
setblock 370 242 474 minecraft:red_nether_bricks
fill 370 242 475 370 245 475 minecraft:pink_terracotta
setblock 370 242 479 minecraft:red_nether_bricks
setblock 370 242 489 minecraft:red_nether_bricks
fill 370 242 490 370 245 490 minecraft:pink_terracotta
setblock 370 242 494 minecraft:red_nether_bricks
fill 370 242 495 370 245 495 minecraft:pink_terracotta
setblock 370 242 499 minecraft:red_nether_bricks
fill 370 242 500 370 245 500 minecraft:pink_terracotta
setblock 370 242 504 minecraft:red_nether_bricks
setblock 330 243 468 minecraft:red_nether_bricks
fill 330 243 469 330 243 472 minecraft:pink_terracotta
setblock 330 243 473 minecraft:red_nether_bricks
fill 330 243 474 330 243 477 minecraft:pink_terracotta
setblock 330 243 478 minecraft:red_nether_bricks
fill 330 243 479 330 243 482 minecraft:pink_terracotta
setblock 330 243 483 minecraft:red_nether_bricks
fill 330 243 484 330 243 487 minecraft:pink_terracotta
setblock 330 243 488 minecraft:red_nether_bricks
fill 330 243 489 330 243 492 minecraft:pink_terracotta
setblock 330 243 493 minecraft:red_nether_bricks
fill 330 243 494 330 246 494 minecraft:pink_terracotta
setblock 330 243 498 minecraft:red_nether_bricks
fill 330 243 499 330 246 499 minecraft:pink_terracotta
setblock 330 243 503 minecraft:red_nether_bricks
fill 330 243 504 330 246 504 minecraft:pink_terracotta
fill 331 243 471 331 252 471 minecraft:iron_block
setblock 331 243 472 minecraft:red_nether_bricks
setblock 331 243 473 minecraft:pink_terracotta
fill 331 243 476 332 244 476 minecraft:white_concrete
fill 331 243 479 331 244 479 minecraft:white_concrete
setblock 331 243 487 minecraft:red_nether_bricks
fill 331 243 488 331 243 491 minecraft:pink_terracotta
setblock 331 243 492 minecraft:red_nether_bricks
fill 331 243 493 331 246 493 minecraft:pink_terracotta
setblock 331 243 497 minecraft:red_nether_bricks
fill 331 243 498 331 246 498 minecraft:pink_terracotta
fill 332 243 478 332 244 478 minecraft:white_concrete
setblock 332 243 491 minecraft:red_nether_bricks
fill 332 243 492 332 244 492 minecraft:pink_terracotta
setblock 332 243 496 minecraft:red_nether_bricks
fill 332 243 497 332 244 497 minecraft:pink_terracotta
fill 333 243 477 333 244 477 minecraft:red_concrete
fill 337 243 503 337 248 503 minecraft:white_concrete
fill 347 243 464 348 243 464 minecraft:pink_terracotta
setblock 347 243 504 minecraft:white_concrete
setblock 349 243 464 minecraft:red_nether_bricks
fill 350 243 464 350 243 465 minecraft:pink_terracotta
fill 351 243 464 353 243 464 minecraft:pink_terracotta
setblock 354 243 464 minecraft:red_nether_bricks
fill 361 243 464 361 247 464 minecraft:white_concrete
setblock 364 243 464 minecraft:red_nether_bricks
setblock 364 243 504 minecraft:red_nether_bricks
fill 365 243 464 365 246 464 minecraft:pink_terracotta
fill 365 243 504 365 246 504 minecraft:pink_terracotta
setblock 366 243 471 minecraft:black_concrete
fill 366 243 503 366 246 503 minecraft:pink_terracotta
setblock 368 243 465 minecraft:red_nether_bricks
fill 368 243 469 368 243 470 minecraft:white_concrete
setblock 368 243 471 minecraft:pink_terracotta
fill 368 243 472 368 243 473 minecraft:white_concrete
fill 368 243 492 368 243 494 minecraft:pink_terracotta
setblock 368 243 495 minecraft:red_nether_bricks
fill 368 243 496 368 246 496 minecraft:pink_terracotta
setblock 368 243 500 minecraft:red_nether_bricks
setblock 369 243 464 minecraft:red_nether_bricks
setblock 369 243 465 minecraft:pink_terracotta
setblock 369 243 469 minecraft:red_nether_bricks
fill 369 243 470 369 244 470 minecraft:pink_terracotta
setblock 369 243 474 minecraft:red_nether_bricks
fill 369 243 475 369 246 475 minecraft:pink_terracotta
setblock 369 243 489 minecraft:red_nether_bricks
fill 369 243 490 369 244 490 minecraft:pink_terracotta
setblock 369 243 494 minecraft:red_nether_bricks
fill 369 243 495 369 246 495 minecraft:pink_terracotta
setblock 369 243 499 minecraft:red_nether_bricks
fill 369 243 500 369 246 500 minecraft:pink_terracotta
setblock 369 243 504 minecraft:red_nether_bricks
fill 370 243 464 370 245 464 minecraft:pink_terracotta
setblock 370 243 468 minecraft:red_nether_bricks
fill 370 243 469 370 246 469 minecraft:pink_terracotta
setblock 370 243 473 minecraft:red_nether_bricks
fill 370 243 474 370 246 474 minecraft:pink_terracotta
setblock 370 243 478 minecraft:red_nether_bricks
setblock 370 243 488 minecraft:red_nether_bricks
fill 370 243 489 370 246 489 minecraft:pink_terracotta
setblock 370 243 493 minecraft:red_nether_bricks
fill 370 243 494 370 246 494 minecraft:pink_terracotta
setblock 370 243 498 minecraft:red_nether_bricks
fill 370 243 499 370 246 499 minecraft:pink_terracotta
setblock 370 243 503 minecraft:red_nether_bricks
fill 370 243 504 370 246 504 minecraft:pink_terracotta
setblock 330 244 464 minecraft:white_concrete
fill 330 244 469 330 244 471 minecraft:pink_terracotta
setblock 330 244 472 minecraft:red_nether_bricks
fill 330 244 473 330 244 476 minecraft:pink_terracotta
setblock 330 244 477 minecraft:red_nether_bricks
fill 330 244 478 330 244 481 minecraft:pink_terracotta
setblock 330 244 482 minecraft:red_nether_bricks
fill 330 244 483 330 244 486 minecraft:pink_terracotta
setblock 330 244 487 minecraft:red_nether_bricks
fill 330 244 488 330 244 491 minecraft:pink_terracotta
setblock 330 244 492 minecraft:red_nether_bricks
fill 330 244 493 330 247 493 minecraft:pink_terracotta
setblock 330 244 497 minecraft:red_nether_bricks
fill 330 244 498 330 247 498 minecraft:pink_terracotta
setblock 330 244 502 minecraft:red_nether_bricks
fill 330 244 503 330 247 503 minecraft:pink_terracotta
setblock 331 244 475 minecraft:white_concrete
fill 331 244 488 331 244 490 minecraft:pink_terracotta
setblock 331 244 491 minecraft:red_nether_bricks
fill 331 244 492 331 247 492 minecraft:pink_terracotta
setblock 331 244 496 minecraft:red_nether_bricks
fill 331 244 497 331 247 497 minecraft:pink_terracotta
setblock 331 244 501 minecraft:red_nether_bricks
setblock 332 244 495 minecraft:red_nether_bricks
fill 332 244 496 332 245 496 minecraft:pink_terracotta
setblock 334 244 504 minecraft:white_concrete
fill 335 244 503 336 247 503 minecraft:white_concrete
fill 336 244 502 338 247 502 minecraft:white_concrete
fill 336 244 504 338 247 504 minecraft:white_concrete
fill 337 244 501 337 247 501 minecraft:white_concrete
fill 338 244 503 339 247 503 minecraft:white_concrete
setblock 341 244 464 minecraft:white_concrete
setblock 347 244 464 minecraft:pink_terracotta
setblock 348 244 464 minecraft:red_nether_bricks
fill 349 244 464 352 244 464 minecraft:pink_terracotta
setblock 353 244 504 minecraft:white_concrete
fill 359 244 464 360 247 464 minecraft:white_concrete
fill 360 244 465 362 247 465 minecraft:white_concrete
fill 361 244 466 361 247 466 minecraft:white_concrete
fill 362 244 464 362 246 464 minecraft:white_concrete
setblock 363 244 464 minecraft:red_nether_bricks
fill 364 244 464 364 247 464 minecraft:pink_terracotta
fill 364 244 504 364 247 504 minecraft:pink_terracotta
setblock 368 244 464 minecraft:red_nether_bricks
fill 368 244 470 368 244 472 minecraft:white_concrete
setblock 368 244 493 minecraft:pink_terracotta
setblock 368 244 494 minecraft:red_nether_bricks
fill 368 244 495 368 247 495 minecraft:pink_terracotta
setblock 368 244 498 minecraft:pink_terracotta
setblock 368 244 499 minecraft:red_nether_bricks
fill 368 244 500 368 246 501 minecraft:pink_terracotta
setblock 368 244 504 minecraft:red_nether_bricks
fill 369 244 464 369 247 464 minecraft:pink_terracotta
setblock 369 244 468 minecraft:red_nether_bricks
setblock 369 244 469 minecraft:pink_terracotta
setblock 369 244 473 minecraft:red_nether_bricks
fill 369 244 474 369 246 474 minecraft:pink_terracotta
setblock 369 244 493 minecraft:red_nether_bricks
fill 369 244 494 369 247 494 minecraft:pink_terracotta
setblock 369 244 498 minecraft:red_nether_bricks
fill 369 244 499 369 247 499 minecraft:pink_terracotta
setblock 369 244 503 minecraft:red_nether_bricks
fill 369 244 504 369 247 504 minecraft:pink_terracotta
setblock 370 244 467 minecraft:red_nether_bricks
fill 370 244 468 370 245 468 minecraft:pink_terracotta
setblock 370 244 472 minecraft:red_nether_bricks
fill 370 244 473 370 247 473 minecraft:pink_terracotta
setblock 370 244 477 minecraft:red_nether_bricks
fill 370 244 478 370 247 478 minecraft:pink_terracotta
setblock 370 244 479 minecraft:white_concrete
setblock 370 244 485 minecraft:white_concrete
fill 370 244 488 370 245 488 minecraft:pink_terracotta
setblock 370 244 492 minecraft:red_nether_bricks
fill 370 244 493 370 247 493 minecraft:pink_terracotta
setblock 370 244 497 minecraft:red_nether_bricks
fill 370 244 498 370 247 498 minecraft:pink_terracotta
setblock 370 244 502 minecraft:red_nether_bricks
fill 370 244 503 370 247 503 minecraft:pink_terracotta
setblock 330 245 470 minecraft:pink_terracotta
setblock 330 245 471 minecraft:red_nether_bricks
fill 330 245 472 330 245 475 minecraft:pink_terracotta
setblock 330 245 476 minecraft:red_nether_bricks
fill 330 245 477 330 245 480 minecraft:pink_terracotta
setblock 330 245 481 minecraft:red_nether_bricks
fill 330 245 482 330 245 485 minecraft:pink_terracotta
setblock 330 245 486 minecraft:red_nether_bricks
fill 330 245 487 330 245 490 minecraft:pink_terracotta
setblock 330 245 491 minecraft:red_nether_bricks
fill 330 245 492 330 248 492 minecraft:pink_terracotta
setblock 330 245 496 minecraft:red_nether_bricks
fill 330 245 497 330 248 497 minecraft:pink_terracotta
setblock 330 245 501 minecraft:red_nether_bricks
fill 330 245 502 330 248 502 minecraft:pink_terracotta
setblock 331 245 476 minecraft:white_concrete
setblock 331 245 489 minecraft:pink_terracotta
setblock 331 245 490 minecraft:red_nether_bricks
fill 331 245 491 331 247 491 minecraft:pink_terracotta
setblock 331 245 495 minecraft:red_nether_bricks
fill 331 245 496 331 248 496 minecraft:pink_terracotta
setblock 331 245 500 minecraft:red_nether_bricks
setblock 331 245 501 minecraft:pink_terracotta
setblock 332 245 494 minecraft:red_nether_bricks
setblock 332 245 495 minecraft:pink_terracotta
setblock 335 245 464 minecraft:white_concrete
fill 335 245 502 335 246 502 minecraft:white_concrete
fill 335 245 504 335 246 504 minecraft:white_concrete
fill 336 245 501 336 246 501 minecraft:white_concrete
fill 338 245 501 338 246 501 minecraft:white_concrete
fill 339 245 502 339 246 502 minecraft:white_concrete
fill 339 245 504 340 245 504 minecraft:white_concrete
setblock 347 245 464 minecraft:red_nether_bricks
fill 348 245 464 351 245 464 minecraft:pink_terracotta
fill 359 245 465 359 246 465 minecraft:white_concrete
setblock 359 245 504 minecraft:white_concrete
fill 360 245 466 360 246 466 minecraft:white_concrete
fill 361 245 467 361 246 467 minecraft:red_concrete
fill 362 245 466 362 246 466 minecraft:white_concrete
fill 363 245 464 363 248 464 minecraft:pink_terracotta
fill 363 245 465 363 246 465 minecraft:white_concrete
fill 363 245 504 363 248 504 minecraft:pink_terracotta
fill 365 245 503 365 247 503 minecraft:pink_terracotta
setblock 367 245 464 minecraft:red_nether_bricks
setblock 367 245 504 minecraft:red_nether_bricks
fill 368 245 464 368 248 464 minecraft:pink_terracotta
setblock 368 245 493 minecraft:red_nether_bricks
fill 368 245 494 368 248 494 minecraft:pink_terracotta
setblock 368 245 498 minecraft:red_nether_bricks
fill 368 245 499 368 248 499 minecraft:pink_terracotta
setblock 368 245 503 minecraft:red_nether_bricks
fill 368 245 504 368 248 504 minecraft:pink_terracotta
setblock 369 245 472 minecraft:red_nether_bricks
fill 369 245 473 369 246 473 minecraft:pink_terracotta
setblock 369 245 492 minecraft:red_nether_bricks
fill 369 245 493 369 248 493 minecraft:pink_terracotta
setblock 369 245 497 minecraft:red_nether_bricks
fill 369 245 498 369 248 498 minecraft:pink_terracotta
setblock 369 245 502 minecraft:red_nether_bricks
fill 369 245 503 369 248 503 minecraft:pink_terracotta
setblock 370 245 466 minecraft:red_nether_bricks
setblock 370 245 467 minecraft:pink_terracotta
setblock 370 245 471 minecraft:red_nether_bricks
fill 370 245 472 370 248 472 minecraft:pink_terracotta
setblock 370 245 476 minecraft:red_nether_bricks
fill 370 245 477 370 248 477 minecraft:pink_terracotta
fill 370 245 479 370 246 479 minecraft:pink_terracotta
setblock 370 245 491 minecraft:red_nether_bricks
fill 370 245 492 370 248 492 minecraft:pink_terracotta
setblock 370 245 496 minecraft:red_nether_bricks
fill 370 245 497 370 248 497 minecraft:pink_terracotta
setblock 370 245 501 minecraft:red_nether_bricks
fill 370 245 502 370 248 502 minecraft:pink_terracotta
fill 330 246 471 330 246 474 minecraft:pink_terracotta
setblock 330 246 475 minecraft:red_nether_bricks
fill 330 246 476 330 246 479 minecraft:pink_terracotta
setblock 330 246 480 minecraft:red_nether_bricks
fill 330 246 481 330 246 484 minecraft:pink_terracotta
setblock 330 246 485 minecraft:red_nether_bricks
fill 330 246 486 330 246 489 minecraft:pink_terracotta
setblock 330 246 490 minecraft:red_nether_bricks
fill 330 246 491 330 249 491 minecraft:pink_terracotta
setblock 330 246 495 minecraft:red_nether_bricks
fill 330 246 496 330 249 496 minecraft:pink_terracotta
setblock 330 246 500 minecraft:red_nether_bricks
fill 330 246 501 330 249 501 minecraft:pink_terracotta
setblock 331 246 490 minecraft:pink_terracotta
setblock 331 246 494 minecraft:red_nether_bricks
fill 331 246 495 331 249 495 minecraft:pink_terracotta
setblock 331 246 499 minecraft:red_nether_bricks
fill 331 246 500 331 249 500 minecraft:pink_terracotta
setblock 337 246 500 minecraft:black_concrete
setblock 339 246 504 minecraft:white_concrete
setblock 346 246 504 minecraft:white_concrete
fill 347 246 464 350 246 464 minecraft:pink_terracotta
setblock 354 246 464 minecraft:white_concrete
fill 362 246 504 362 249 504 minecraft:pink_terracotta
fill 364 246 503 364 248 503 minecraft:pink_terracotta
setblock 366 246 464 minecraft:red_nether_bricks
fill 366 246 502 367 246 502 minecraft:pink_terracotta
setblock 366 246 504 minecraft:red_nether_bricks
fill 367 246 464 367 249 464 minecraft:pink_terracotta
setblock 367 246 503 minecraft:red_nether_bricks
fill 367 246 504 367 249 504 minecraft:pink_terracotta
setblock 368 246 493 minecraft:pink_terracotta
setblock 368 246 497 minecraft:red_nether_bricks
fill 368 246 498 368 249 498 minecraft:pink_terracotta
setblock 368 246 502 minecraft:red_nether_bricks
fill 368 246 503 368 249 503 minecraft:pink_terracotta
setblock 369 246 491 minecraft:red_nether_bricks
fill 369 246 492 369 249 492 minecraft:pink_terracotta
setblock 369 246 496 minecraft:red_nether_bricks
fill 369 246 497 369 249 497 minecraft:pink_terracotta
setblock 369 246 501 minecraft:red_nether_bricks
fill 369 246 502 369 249 502 minecraft:pink_terracotta
setblock 370 246 467 minecraft:white_concrete
setblock 370 246 470 minecraft:red_nether_bricks
fill 370 246 471 370 247 471 minecraft:pink_terracotta
setblock 370 246 475 minecraft:red_nether_bricks
fill 370 246 476 370 249 476 minecraft:pink_terracotta
setblock 370 246 490 minecraft:red_nether_bricks
fill 370 246 491 370 249 491 minecraft:pink_terracotta
setblock 370 246 495 minecraft:red_nether_bricks
fill 370 246 496 370 249 496 minecraft:pink_terracotta
setblock 370 246 500 minecraft:red_nether_bricks
fill 370 246 501 370 249 501 minecraft:pink_terracotta
fill 330 247 472 330 247 473 minecraft:pink_terracotta
setblock 330 247 474 minecraft:red_nether_bricks
fill 330 247 475 330 247 478 minecraft:pink_terracotta
setblock 330 247 479 minecraft:red_nether_bricks
fill 330 247 480 330 247 483 minecraft:pink_terracotta
setblock 330 247 484 minecraft:red_nether_bricks
fill 330 247 485 330 247 488 minecraft:pink_terracotta
setblock 330 247 489 minecraft:red_nether_bricks
fill 330 247 490 330 250 490 minecraft:pink_terracotta
setblock 330 247 494 minecraft:red_nether_bricks
fill 330 247 495 330 250 495 minecraft:pink_terracotta
setblock 330 247 499 minecraft:red_nether_bricks
fill 330 247 500 330 250 500 minecraft:pink_terracotta
setblock 330 247 504 minecraft:red_nether_bricks
setblock 331 247 477 minecraft:pink_terracotta
setblock 331 247 493 minecraft:red_nether_bricks
fill 331 247 494 331 250 494 minecraft:pink_terracotta
setblock 331 247 498 minecraft:red_nether_bricks
fill 331 247 499 331 250 499 minecraft:pink_terracotta
fill 331 247 501 331 248 501 minecraft:pink_terracotta
setblock 332 247 466 minecraft:light[level=12]
setblock 332 247 474 minecraft:light[level=12]
setblock 332 247 482 minecraft:light[level=12]
setblock 332 247 490 minecraft:light[level=12]
setblock 332 247 498 minecraft:light[level=12]
setblock 333 247 504 minecraft:white_concrete
setblock 340 247 466 minecraft:light[level=12]
setblock 340 247 474 minecraft:light[level=12]
setblock 340 247 482 minecraft:light[level=12]
setblock 340 247 490 minecraft:light[level=12]
setblock 340 247 498 minecraft:light[level=12]
fill 346 247 464 349 247 464 minecraft:pink_terracotta
setblock 348 247 466 minecraft:light[level=12]
setblock 348 247 474 minecraft:light[level=12]
setblock 348 247 482 minecraft:light[level=12]
setblock 348 247 490 minecraft:light[level=12]
setblock 348 247 498 minecraft:light[level=12]
setblock 350 247 464 minecraft:red_nether_bricks
setblock 352 247 504 minecraft:white_concrete
setblock 356 247 466 minecraft:light[level=12]
setblock 356 247 474 minecraft:light[level=12]
setblock 356 247 482 minecraft:light[level=12]
setblock 356 247 490 minecraft:light[level=12]
setblock 356 247 498 minecraft:light[level=12]
fill 361 247 504 361 250 504 minecraft:pink_terracotta
fill 362 247 464 362 249 464 minecraft:pink_terracotta
fill 362 247 503 363 249 503 minecraft:pink_terracotta
setblock 364 247 466 minecraft:light[level=12]
setblock 364 247 474 minecraft:light[level=12]
setblock 364 247 482 minecraft:light[level=12]
setblock 364 247 490 minecraft:light[level=12]
setblock 364 247 498 minecraft:light[level=12]
fill 364 247 502 366 247 502 minecraft:pink_terracotta
setblock 365 247 464 minecraft:red_nether_bricks
setblock 365 247 504 minecraft:red_nether_bricks
fill 366 247 464 366 250 464 minecraft:pink_terracotta
setblock 366 247 503 minecraft:red_nether_bricks
fill 366 247 504 366 250 504 minecraft:pink_terracotta
setblock 367 247 497 minecraft:red_nether_bricks
fill 367 247 498 367 248 500 minecraft:pink_terracotta
setblock 367 247 502 minecraft:red_nether_bricks
fill 367 247 503 367 250 503 minecraft:pink_terracotta
setblock 368 247 496 minecraft:red_nether_bricks
fill 368 247 497 368 250 497 minecraft:pink_terracotta
setblock 368 247 500 minecraft:pink_terracotta
setblock 368 247 501 minecraft:red_nether_bricks
fill 368 247 502 368 250 502 minecraft:pink_terracotta
setblock 369 247 475 minecraft:red_nether_bricks
setblock 369 247 491 minecraft:pink_terracotta
setblock 369 247 495 minecraft:red_nether_bricks
fill 369 247 496 369 250 496 minecraft:pink_terracotta
setblock 369 247 500 minecraft:red_nether_bricks
fill 369 247 501 369 250 501 minecraft:pink_terracotta
setblock 370 247 474 minecraft:red_nether_bricks
fill 370 247 475 370 250 475 minecraft:pink_terracotta
setblock 370 247 479 minecraft:red_nether_bricks
fill 370 247 480 370 250 480 minecraft:pink_terracotta
setblock 370 247 486 minecraft:white_concrete
setblock 370 247 489 minecraft:red_nether_bricks
fill 370 247 490 370 250 490 minecraft:pink_terracotta
setblock 370 247 494 minecraft:red_nether_bricks
fill 370 247 495 370 250 495 minecraft:pink_terracotta
setblock 370 247 499 minecraft:red_nether_bricks
fill 370 247 500 370 250 500 minecraft:pink_terracotta
setblock 370 247 504 minecraft:red_nether_bricks
setblock 330 248 469 minecraft:white_concrete
setblock 330 248 472 minecraft:pink_terracotta
setblock 330 248 473 minecraft:red_nether_bricks
fill 330 248 474 330 248 477 minecraft:pink_terracotta
setblock 330 248 478 minecraft:red_nether_bricks
fill 330 248 479 330 248 482 minecraft:pink_terracotta
setblock 330 248 483 minecraft:red_nether_bricks
fill 330 248 484 330 248 487 minecraft:pink_terracotta
setblock 330 248 488 minecraft:red_nether_bricks
fill 330 248 489 330 251 489 minecraft:pink_terracotta
setblock 330 248 493 minecraft:red_nether_bricks
fill 330 248 494 330 251 494 minecraft:pink_terracotta
setblock 330 248 498 minecraft:red_nether_bricks
fill 330 248 499 330 251 499 minecraft:pink_terracotta
setblock 330 248 503 minecraft:red_nether_bricks
fill 330 248 504 330 251 504 minecraft:pink_terracotta
setblock 331 248 476 minecraft:pink_terracotta
setblock 331 248 477 minecraft:red_nether_bricks
fill 331 248 478 331 249 480 minecraft:pink_terracotta
setblock 331 248 492 minecraft:red_nether_bricks
fill 331 248 493 331 249 493 minecraft:pink_terracotta
setblock 331 248 497 minecraft:red_nether_bricks
fill 331 248 498 331 251 498 minecraft:pink_terracotta
setblock 339 248 504 minecraft:white_concrete
setblock 342 248 464 minecraft:white_concrete
setblock 344 248 464 minecraft:red_nether_bricks
setblock 344 248 504 minecraft:red_nether_bricks
fill 345 248 464 348 248 464 minecraft:pink_terracotta
fill 345 248 504 348 248 504 minecraft:pink_terracotta
setblock 349 248 464 minecraft:red_nether_bricks
setblock 349 248 504 minecraft:red_nether_bricks
fill 350 248 464 351 250 464 minecraft:pink_terracotta
fill 350 248 504 350 251 504 minecraft:pink_terracotta
setblock 358 248 504 minecraft:white_concrete
setblock 359 248 504 minecraft:red_nether_bricks
fill 360 248 464 361 250 464 minecraft:pink_terracotta
fill 360 248 504 360 251 504 minecraft:pink_terracotta
fill 361 248 503 361 251 503 minecraft:pink_terracotta
fill 363 248 502 365 248 502 minecraft:pink_terracotta
setblock 364 248 464 minecraft:red_nether_bricks
setblock 364 248 504 minecraft:red_nether_bricks
fill 365 248 464 365 251 464 minecraft:pink_terracotta
fill 365 248 501 366 248 501 minecraft:pink_terracotta
setblock 365 248 503 minecraft:red_nether_bricks
fill 365 248 504 365 251 504 minecraft:pink_terracotta
setblock 366 248 502 minecraft:red_nether_bricks
fill 366 248 503 366 251 503 minecraft:pink_terracotta
setblock 367 248 496 minecraft:red_nether_bricks
fill 367 248 497 367 251 497 minecraft:pink_terracotta
setblock 367 248 501 minecraft:red_nether_bricks
fill 367 248 502 367 251 502 minecraft:pink_terracotta
setblock 368 248 495 minecraft:red_nether_bricks
fill 368 248 496 368 251 496 minecraft:pink_terracotta
setblock 368 248 500 minecraft:red_nether_bricks
fill 368 248 501 368 251 501 minecraft:pink_terracotta
setblock 369 248 464 minecraft:red_nether_bricks
fill 369 248 476 369 249 477 minecraft:pink_terracotta
setblock 369 248 494 minecraft:red_nether_bricks
fill 369 248 495 369 251 495 minecraft:pink_terracotta
setblock 369 248 499 minecraft:red_nether_bricks
fill 369 248 500 369 251 500 minecraft:pink_terracotta
setblock 369 248 504 minecraft:red_nether_bricks
setblock 370 248 473 minecraft:red_nether_bricks
fill 370 248 474 370 251 474 minecraft:pink_terracotta
setblock 370 248 478 minecraft:red_nether_bricks
fill 370 248 479 370 251 479 minecraft:pink_terracotta
fill 370 248 481 370 249 481 minecraft:pink_terracotta
fill 370 248 489 370 251 489 minecraft:pink_terracotta
setblock 370 248 493 minecraft:red_nether_bricks
fill 370 248 494 370 251 494 minecraft:pink_terracotta
setblock 370 248 498 minecraft:red_nether_bricks
fill 370 248 499 370 251 499 minecraft:pink_terracotta
setblock 370 248 503 minecraft:red_nether_bricks
fill 370 248 504 370 251 504 minecraft:pink_terracotta
fill 330 249 473 330 249 476 minecraft:pink_terracotta
setblock 330 249 477 minecraft:red_nether_bricks
fill 330 249 478 330 249 481 minecraft:pink_terracotta
setblock 330 249 482 minecraft:red_nether_bricks
fill 330 249 483 330 249 486 minecraft:pink_terracotta
setblock 330 249 487 minecraft:red_nether_bricks
fill 330 249 488 330 252 488 minecraft:pink_terracotta
setblock 330 249 492 minecraft:red_nether_bricks
fill 330 249 493 330 252 493 minecraft:pink_terracotta
setblock 330 249 497 minecraft:red_nether_bricks
fill 330 249 498 330 252 498 minecraft:pink_terracotta
setblock 330 249 502 minecraft:red_nether_bricks
fill 330 249 503 330 252 503 minecraft:pink_terracotta
setblock 331 249 476 minecraft:red_nether_bricks
fill 331 249 477 331 252 477 minecraft:pink_terracotta
setblock 331 249 481 minecraft:red_nether_bricks
fill 331 249 482 331 252 482 minecraft:pink_terracotta
setblock 331 249 496 minecraft:red_nether_bricks
fill 331 249 497 331 252 497 minecraft:pink_terracotta
setblock 331 249 501 minecraft:red_nether_bricks
setblock 336 249 464 minecraft:white_concrete
setblock 342 249 504 minecraft:pink_terracotta
setblock 343 249 464 minecraft:red_nether_bricks
setblock 343 249 504 minecraft:red_nether_bricks
fill 344 249 464 347 249 464 minecraft:pink_terracotta
fill 344 249 504 347 249 504 minecraft:pink_terracotta
fill 345 249 503 347 250 503 minecraft:pink_terracotta
setblock 346 249 465 minecraft:pink_terracotta
setblock 347 249 465 minecraft:red_nether_bricks
setblock 348 249 464 minecraft:red_nether_bricks
setblock 348 249 504 minecraft:red_nether_bricks
fill 349 249 464 349 252 464 minecraft:pink_terracotta
fill 349 249 504 349 252 504 minecraft:pink_terracotta
fill 351 249 504 352 249 504 minecraft:pink_terracotta
setblock 352 249 464 minecraft:pink_terracotta
setblock 355 249 464 minecraft:white_concrete
setblock 357 249 504 minecraft:pink_terracotta
setblock 358 249 504 minecraft:red_nether_bricks
fill 359 249 464 359 252 464 minecraft:pink_terracotta
setblock 359 249 503 minecraft:red_nether_bricks
fill 359 249 504 359 252 504 minecraft:pink_terracotta
fill 360 249 503 360 252 503 minecraft:pink_terracotta
fill 361 249 502 364 249 502 minecraft:pink_terracotta
setblock 363 249 464 minecraft:red_nether_bricks
fill 363 249 501 365 249 501 minecraft:pink_terracotta
setblock 363 249 504 minecraft:red_nether_bricks
fill 364 249 464 364 252 464 minecraft:pink_terracotta
setblock 364 249 503 minecraft:red_nether_bricks
fill 364 249 504 364 252 504 minecraft:pink_terracotta
setblock 365 249 502 minecraft:red_nether_bricks
fill 365 249 503 365 252 503 minecraft:pink_terracotta
setblock 366 249 501 minecraft:red_nether_bricks
fill 366 249 502 366 252 502 minecraft:pink_terracotta
fill 367 249 496 367 251 496 minecraft:pink_terracotta
fill 367 249 498 367 249 499 minecraft:pink_terracotta
setblock 367 249 500 minecraft:red_nether_bricks
fill 367 249 501 367 252 501 minecraft:pink_terracotta
setblock 368 249 464 minecraft:red_nether_bricks
setblock 368 249 494 minecraft:red_nether_bricks
fill 368 249 495 368 252 495 minecraft:pink_terracotta
setblock 368 249 499 minecraft:red_nether_bricks
fill 368 249 500 368 252 500 minecraft:pink_terracotta
setblock 368 249 504 minecraft:red_nether_bricks
fill 369 249 464 369 252 464 minecraft:pink_terracotta
setblock 369 249 478 minecraft:red_nether_bricks
fill 369 249 479 369 252 479 minecraft:pink_terracotta
setblock 369 249 493 minecraft:red_nether_bricks
fill 369 249 494 369 252 494 minecraft:pink_terracotta
setblock 369 249 498 minecraft:red_nether_bricks
fill 369 249 499 369 252 499 minecraft:pink_terracotta
setblock 369 249 503 minecraft:red_nether_bricks
fill 369 249 504 369 252 504 minecraft:pink_terracotta
setblock 370 249 473 minecraft:pink_terracotta
setblock 370 249 477 minecraft:red_nether_bricks
fill 370 249 478 370 252 478 minecraft:pink_terracotta
setblock 370 249 482 minecraft:red_nether_bricks
fill 370 249 483 370 252 483 minecraft:pink_terracotta
setblock 370 249 492 minecraft:red_nether_bricks
fill 370 249 493 370 252 493 minecraft:pink_terracotta
setblock 370 249 497 minecraft:red_nether_bricks
fill 370 249 498 370 252 498 minecraft:pink_terracotta
setblock 370 249 502 minecraft:red_nether_bricks
fill 370 249 503 370 252 503 minecraft:pink_terracotta
fill 330 250 473 330 250 475 minecraft:pink_terracotta
setblock 330 250 476 minecraft:red_nether_bricks
fill 330 250 477 330 250 480 minecraft:pink_terracotta
setblock 330 250 481 minecraft:red_nether_bricks
fill 330 250 482 330 250 485 minecraft:pink_terracotta
setblock 330 250 486 minecraft:red_nether_bricks
fill 330 250 487 330 253 487 minecraft:pink_terracotta
setblock 330 250 491 minecraft:red_nether_bricks
fill 330 250 492 330 253 492 minecraft:pink_terracotta
setblock 330 250 496 minecraft:red_nether_bricks
fill 330 250 497 330 253 497 minecraft:pink_terracotta
setblock 330 250 501 minecraft:red_nether_bricks
fill 330 250 502 330 253 502 minecraft:pink_terracotta
fill 331 250 476 331 252 476 minecraft:pink_terracotta
fill 331 250 478 331 250 479 minecraft:pink_terracotta
setblock 331 250 480 minecraft:red_nether_bricks
fill 331 250 481 331 253 481 minecraft:pink_terracotta
fill 331 250 483 331 251 483 minecraft:pink_terracotta
setblock 331 250 495 minecraft:red_nether_bricks
fill 331 250 496 331 251 496 minecraft:pink_terracotta
setblock 331 250 500 minecraft:red_nether_bricks
fill 331 250 501 331 253 501 minecraft:pink_terracotta
setblock 331 250 504 minecraft:pink_terracotta
fill 332 250 481 332 252 481 minecraft:white_concrete
fill 340 250 504 341 250 504 minecraft:pink_terracotta
setblock 341 250 464 minecraft:pink_terracotta
setblock 342 250 464 minecraft:red_nether_bricks
setblock 342 250 504 minecraft:red_nether_bricks
fill 343 250 464 346 250 464 minecraft:pink_terracotta
setblock 343 250 503 minecraft:red_nether_bricks
fill 343 250 504 346 250 504 minecraft:pink_terracotta
fill 344 250 465 345 250 465 minecraft:pink_terracotta
fill 344 250 503 344 253 503 minecraft:pink_terracotta
setblock 346 250 465 minecraft:red_nether_bricks
setblock 347 250 464 minecraft:red_nether_bricks
fill 347 250 465 348 252 465 minecraft:pink_terracotta
setblock 347 250 504 minecraft:red_nether_bricks
fill 348 250 464 348 253 464 minecraft:pink_terracotta
setblock 348 250 503 minecraft:red_nether_bricks
fill 348 250 504 348 253 504 minecraft:pink_terracotta
fill 349 250 503 349 253 503 minecraft:pink_terracotta
setblock 351 250 504 minecraft:pink_terracotta
setblock 352 250 464 minecraft:red_nether_bricks
setblock 352 250 504 minecraft:red_nether_bricks
fill 353 250 464 356 250 464 minecraft:pink_terracotta
fill 353 250 504 356 250 504 minecraft:pink_terracotta
setblock 357 250 464 minecraft:red_nether_bricks
setblock 357 250 503 minecraft:pink_terracotta
setblock 357 250 504 minecraft:red_nether_bricks
fill 358 250 464 358 253 464 minecraft:pink_terracotta
setblock 358 250 503 minecraft:red_nether_bricks
fill 358 250 504 358 253 504 minecraft:pink_terracotta
fill 359 250 503 359 253 503 minecraft:pink_terracotta
fill 360 250 502 363 250 502 minecraft:pink_terracotta
setblock 362 250 464 minecraft:red_nether_bricks
fill 362 250 465 365 250 465 minecraft:pink_terracotta
fill 362 250 501 364 250 501 minecraft:pink_terracotta
setblock 362 250 503 minecraft:pink_terracotta
setblock 362 250 504 minecraft:red_nether_bricks
fill 363 250 464 363 253 464 minecraft:pink_terracotta
setblock 363 250 503 minecraft:red_nether_bricks
fill 363 250 504 363 253 504 minecraft:pink_terracotta
setblock 364 250 502 minecraft:red_nether_bricks
fill 364 250 503 364 253 503 minecraft:pink_terracotta
setblock 365 250 500 minecraft:pink_terracotta
setblock 365 250 501 minecraft:red_nether_bricks
fill 365 250 502 365 253 502 minecraft:pink_terracotta
setblock 366 250 465 minecraft:red_nether_bricks
setblock 366 250 500 minecraft:red_nether_bricks
fill 366 250 501 366 253 501 minecraft:pink_terracotta
setblock 367 250 464 minecraft:red_nether_bricks
setblock 367 250 498 minecraft:pink_terracotta
setblock 367 250 499 minecraft:red_nether_bricks
fill 367 250 500 367 253 500 minecraft:pink_terracotta
setblock 367 250 504 minecraft:red_nether_bricks
fill 368 250 464 368 253 464 minecraft:pink_terracotta
fill 368 250 494 368 251 494 minecraft:pink_terracotta
setblock 368 250 498 minecraft:red_nether_bricks
fill 368 250 499 368 253 499 minecraft:pink_terracotta
setblock 368 250 503 minecraft:red_nether_bricks
fill 368 250 504 368 253 504 minecraft:pink_terracotta
setblock 369 250 476 minecraft:pink_terracotta
setblock 369 250 477 minecraft:red_nether_bricks
fill 369 250 478 369 253 478 minecraft:pink_terracotta
fill 369 250 480 369 250 481 minecraft:pink_terracotta
setblock 369 250 492 minecraft:red_nether_bricks
fill 369 250 493 369 253 493 minecraft:pink_terracotta
setblock 369 250 497 minecraft:red_nether_bricks
fill 369 250 498 369 253 498 minecraft:pink_terracotta
setblock 369 250 502 minecraft:red_nether_bricks
fill 369 250 503 369 253 503 minecraft:pink_terracotta
setblock 370 250 468 minecraft:white_concrete
setblock 370 250 476 minecraft:red_nether_bricks
fill 370 250 477 370 253 477 minecraft:pink_terracotta
setblock 370 250 481 minecraft:red_nether_bricks
fill 370 250 482 370 253 482 minecraft:pink_terracotta
fill 370 250 484 370 250 485 minecraft:pink_terracotta
setblock 370 250 486 minecraft:red_nether_bricks
fill 370 250 487 370 252 488 minecraft:pink_terracotta
setblock 370 250 491 minecraft:red_nether_bricks
fill 370 250 492 370 253 492 minecraft:pink_terracotta
setblock 370 250 496 minecraft:red_nether_bricks
fill 370 250 497 370 253 497 minecraft:pink_terracotta
setblock 370 250 501 minecraft:red_nether_bricks
fill 370 250 502 370 253 502 minecraft:pink_terracotta
fill 330 251 473 330 251 474 minecraft:pink_terracotta
setblock 330 251 475 minecraft:red_nether_bricks
fill 330 251 476 330 251 479 minecraft:pink_terracotta
setblock 330 251 480 minecraft:red_nether_bricks
fill 330 251 481 330 251 484 minecraft:pink_terracotta
setblock 330 251 485 minecraft:red_nether_bricks
fill 330 251 486 330 254 486 minecraft:pink_terracotta
setblock 330 251 490 minecraft:red_nether_bricks
fill 330 251 491 330 254 491 minecraft:pink_terracotta
setblock 330 251 495 minecraft:red_nether_bricks
fill 330 251 496 330 254 496 minecraft:pink_terracotta
setblock 330 251 500 minecraft:red_nether_bricks
fill 330 251 501 330 254 501 minecraft:pink_terracotta
setblock 331 251 478 minecraft:pink_terracotta
setblock 331 251 479 minecraft:red_nether_bricks
fill 331 251 480 331 254 480 minecraft:pink_terracotta
setblock 331 251 484 minecraft:red_nether_bricks
fill 331 251 485 331 254 485 minecraft:pink_terracotta
setblock 331 251 495 minecraft:pink_terracotta
setblock 331 251 499 minecraft:red_nether_bricks
fill 331 251 500 331 253 500 minecraft:pink_terracotta
fill 331 251 502 331 252 502 minecraft:pink_terracotta
setblock 331 251 504 minecraft:red_nether_bricks
fill 332 251 480 332 252 480 minecraft:white_concrete
fill 332 251 482 332 252 482 minecraft:white_concrete
setblock 332 251 504 minecraft:white_concrete
fill 333 251 481 333 252 481 minecraft:red_concrete
fill 338 251 504 340 251 504 minecraft:pink_terracotta
setblock 340 251 464 minecraft:pink_terracotta
setblock 341 251 464 minecraft:red_nether_bricks
setblock 341 251 503 minecraft:pink_terracotta
setblock 341 251 504 minecraft:red_nether_bricks
fill 342 251 464 344 251 465 minecraft:pink_terracotta
fill 342 251 484 342 252 484 minecraft:red_concrete
setblock 342 251 503 minecraft:red_nether_bricks
fill 342 251 504 345 251 504 minecraft:pink_terracotta
fill 343 251 503 343 254 503 minecraft:pink_terracotta
fill 344 251 502 345 253 502 minecraft:pink_terracotta
setblock 345 251 464 minecraft:pink_terracotta
setblock 345 251 465 minecraft:red_nether_bricks
fill 345 251 503 346 251 503 minecraft:pink_terracotta
setblock 346 251 464 minecraft:red_nether_bricks
fill 346 251 465 346 254 465 minecraft:pink_terracotta
setblock 346 251 504 minecraft:red_nether_bricks
fill 347 251 464 347 254 464 minecraft:pink_terracotta
setblock 347 251 503 minecraft:red_nether_bricks
fill 347 251 504 347 254 504 minecraft:pink_terracotta
fill 348 251 503 348 254 503 minecraft:pink_terracotta
setblock 349 251 465 minecraft:pink_terracotta
setblock 350 251 464 minecraft:pink_terracotta
fill 350 251 503 351 251 503 minecraft:pink_terracotta
setblock 351 251 464 minecraft:red_nether_bricks
setblock 351 251 504 minecraft:red_nether_bricks
fill 352 251 464 355 251 464 minecraft:pink_terracotta
fill 352 251 504 355 251 504 minecraft:pink_terracotta
fill 355 251 503 356 251 503 minecraft:pink_terracotta
setblock 356 251 464 minecraft:red_nether_bricks
setblock 356 251 504 minecraft:red_nether_bricks
fill 357 251 464 357 254 464 minecraft:pink_terracotta
setblock 357 251 503 minecraft:red_nether_bricks
fill 357 251 504 357 254 504 minecraft:pink_terracotta
setblock 358 251 502 minecraft:red_nether_bricks
fill 358 251 503 358 254 503 minecraft:pink_terracotta
fill 359 251 502 362 251 502 minecraft:pink_terracotta
setblock 360 251 464 minecraft:pink_terracotta
setblock 360 251 465 minecraft:red_nether_bricks
fill 360 251 501 363 251 501 minecraft:pink_terracotta
setblock 361 251 464 minecraft:red_nether_bricks
fill 361 251 465 364 251 465 minecraft:pink_terracotta
setblock 361 251 504 minecraft:red_nether_bricks
fill 362 251 464 362 254 464 minecraft:pink_terracotta
setblock 362 251 503 minecraft:red_nether_bricks
fill 362 251 504 362 254 504 minecraft:pink_terracotta
fill 363 251 500 364 251 500 minecraft:pink_terracotta
setblock 363 251 502 minecraft:red_nether_bricks
fill 363 251 503 363 254 503 minecraft:pink_terracotta
setblock 364 251 501 minecraft:red_nether_bricks
fill 364 251 502 364 254 502 minecraft:pink_terracotta
setblock 365 251 465 minecraft:red_nether_bricks
setblock 365 251 500 minecraft:red_nether_bricks
fill 365 251 501 365 254 501 minecraft:pink_terracotta
setblock 366 251 464 minecraft:red_nether_bricks
fill 366 251 465 366 254 465 minecraft:pink_terracotta
setblock 366 251 499 minecraft:red_nether_bricks
fill 366 251 500 366 252 500 minecraft:pink_terracotta
setblock 366 251 504 minecraft:red_nether_bricks
fill 367 251 464 367 254 464 minecraft:pink_terracotta
setblock 367 251 498 minecraft:red_nether_bricks
fill 367 251 499 367 254 499 minecraft:pink_terracotta
setblock 367 251 503 minecraft:red_nether_bricks
fill 367 251 504 367 254 504 minecraft:pink_terracotta
setblock 368 251 497 minecraft:red_nether_bricks
fill 368 251 498 368 254 498 minecraft:pink_terracotta
setblock 368 251 502 minecraft:red_nether_bricks
fill 368 251 503 368 254 503 minecraft:pink_terracotta
fill 369 251 477 369 252 477 minecraft:pink_terracotta
setblock 369 251 480 minecraft:pink_terracotta
setblock 369 251 481 minecraft:red_nether_bricks
fill 369 251 482 369 253 483 minecraft:pink_terracotta
fill 369 251 492 369 252 492 minecraft:pink_terracotta
setblock 369 251 496 minecraft:red_nether_bricks
fill 369 251 497 369 254 497 minecraft:pink_terracotta
setblock 369 251 501 minecraft:red_nether_bricks
fill 369 251 502 369 254 502 minecraft:pink_terracotta
setblock 370 251 475 minecraft:red_nether_bricks
fill 370 251 476 370 253 476 minecraft:pink_terracotta
setblock 370 251 480 minecraft:red_nether_bricks
fill 370 251 481 370 254 481 minecraft:pink_terracotta
setblock 370 251 484 minecraft:pink_terracotta
setblock 370 251 485 minecraft:red_nether_bricks
fill 370 251 486 370 254 486 minecraft:pink_terracotta
setblock 370 251 490 minecraft:red_nether_bricks
fill 370 251 491 370 254 491 minecraft:pink_terracotta
setblock 370 251 495 minecraft:red_nether_bricks
fill 370 251 496 370 254 496 minecraft:pink_terracotta
setblock 370 251 500 minecraft:red_nether_bricks
fill 370 251 501 370 254 501 minecraft:pink_terracotta
setblock 330 252 468 minecraft:white_concrete
setblock 330 252 474 minecraft:red_nether_bricks
fill 330 252 475 330 252 478 minecraft:pink_terracotta
setblock 330 252 479 minecraft:red_nether_bricks
fill 330 252 480 330 252 483 minecraft:pink_terracotta
setblock 330 252 484 minecraft:red_nether_bricks
fill 330 252 485 330 255 485 minecraft:pink_terracotta
setblock 330 252 489 minecraft:red_nether_bricks
fill 330 252 490 330 255 490 minecraft:pink_terracotta
setblock 330 252 494 minecraft:red_nether_bricks
fill 330 252 495 330 254 495 minecraft:pink_terracotta
setblock 330 252 499 minecraft:red_nether_bricks
fill 330 252 500 330 255 500 minecraft:pink_terracotta
setblock 330 252 504 minecraft:red_nether_bricks
setblock 331 252 478 minecraft:red_nether_bricks
fill 331 252 479 331 255 479 minecraft:pink_terracotta
setblock 331 252 483 minecraft:red_nether_bricks
fill 331 252 484 331 255 484 minecraft:pink_terracotta
fill 331 252 486 331 253 486 minecraft:pink_terracotta
setblock 331 252 498 minecraft:red_nether_bricks
fill 331 252 499 331 253 499 minecraft:pink_terracotta
fill 331 252 504 332 254 504 minecraft:pink_terracotta
setblock 337 252 464 minecraft:white_concrete
fill 337 252 504 339 252 504 minecraft:pink_terracotta
fill 338 252 464 339 252 464 minecraft:pink_terracotta
fill 339 252 503 340 252 503 minecraft:pink_terracotta
setblock 340 252 464 minecraft:red_nether_bricks
setblock 340 252 504 minecraft:red_nether_bricks
fill 341 252 464 343 252 465 minecraft:pink_terracotta
setblock 341 252 503 minecraft:red_nether_bricks
fill 341 252 504 344 252 504 minecraft:pink_terracotta
setblock 342 252 502 minecraft:red_nether_bricks
fill 342 252 503 342 255 503 minecraft:pink_terracotta
fill 343 252 502 343 255 502 minecraft:pink_terracotta
setblock 344 252 464 minecraft:pink_terracotta
setblock 344 252 465 minecraft:red_nether_bricks
setblock 345 252 464 minecraft:red_nether_bricks
fill 345 252 465 345 255 465 minecraft:pink_terracotta
setblock 345 252 503 minecraft:pink_terracotta
setblock 345 252 504 minecraft:red_nether_bricks
fill 346 252 464 346 255 464 minecraft:pink_terracotta
setblock 346 252 502 minecraft:pink_terracotta
setblock 346 252 503 minecraft:red_nether_bricks
fill 346 252 504 346 255 504 minecraft:pink_terracotta
setblock 347 252 502 minecraft:red_nether_bricks
fill 347 252 503 347 255 503 minecraft:pink_terracotta
setblock 349 252 465 minecraft:red_nether_bricks
setblock 350 252 464 minecraft:red_nether_bricks
fill 350 252 465 350 255 465 minecraft:pink_terracotta
setblock 350 252 503 minecraft:pink_terracotta
setblock 350 252 504 minecraft:red_nether_bricks
fill 351 252 464 354 252 464 minecraft:pink_terracotta
setblock 351 252 503 minecraft:red_nether_bricks
fill 351 252 504 354 252 504 minecraft:pink_terracotta
fill 352 252 503 355 252 503 minecraft:pink_terracotta
setblock 355 252 464 minecraft:red_nether_bricks
setblock 355 252 504 minecraft:red_nether_bricks
fill 356 252 464 356 255 464 minecraft:pink_terracotta
setblock 356 252 503 minecraft:red_nether_bricks
fill 356 252 504 356 255 504 minecraft:pink_terracotta
setblock 357 252 502 minecraft:red_nether_bricks
fill 357 252 503 357 255 503 minecraft:pink_terracotta
setblock 358 252 465 minecraft:pink_terracotta
fill 358 252 502 361 252 502 minecraft:pink_terracotta
setblock 359 252 465 minecraft:red_nether_bricks
setblock 360 252 464 minecraft:red_nether_bricks
fill 360 252 465 363 252 465 minecraft:pink_terracotta
fill 360 252 501 362 252 501 minecraft:pink_terracotta
setblock 360 252 504 minecraft:red_nether_bricks
fill 361 252 464 361 255 464 minecraft:pink_terracotta
setblock 361 252 503 minecraft:red_nether_bricks
fill 361 252 504 361 255 504 minecraft:pink_terracotta
fill 362 252 500 363 252 500 minecraft:pink_terracotta
setblock 362 252 502 minecraft:red_nether_bricks
fill 362 252 503 362 255 503 minecraft:pink_terracotta
setblock 363 252 501 minecraft:red_nether_bricks
fill 363 252 502 363 255 502 minecraft:pink_terracotta
setblock 364 252 465 minecraft:red_nether_bricks
setblock 364 252 500 minecraft:red_nether_bricks
fill 364 252 501 364 255 501 minecraft:pink_terracotta
setblock 365 252 464 minecraft:red_nether_bricks
fill 365 252 465 365 255 465 minecraft:pink_terracotta
fill 365 252 500 365 253 500 minecraft:pink_terracotta
setblock 365 252 504 minecraft:red_nether_bricks
fill 366 252 464 366 255 464 minecraft:pink_terracotta
setblock 366 252 499 minecraft:pink_terracotta
setblock 366 252 503 minecraft:red_nether_bricks
fill 366 252 504 366 255 504 minecraft:pink_terracotta
setblock 367 252 497 minecraft:red_nether_bricks
fill 367 252 498 367 253 498 minecraft:pink_terracotta
setblock 367 252 502 minecraft:red_nether_bricks
fill 367 252 503 367 255 503 minecraft:pink_terracotta
setblock 368 252 496 minecraft:red_nether_bricks
fill 368 252 497 368 254 497 minecraft:pink_terracotta
setblock 368 252 501 minecraft:red_nether_bricks
fill 368 252 502 368 255 502 minecraft:pink_terracotta
setblock 369 252 480 minecraft:red_nether_bricks
fill 369 252 481 369 255 481 minecraft:pink_terracotta
setblock 369 252 484 minecraft:pink_terracotta
setblock 369 252 495 minecraft:red_nether_bricks
fill 369 252 496 369 254 496 minecraft:pink_terracotta
setblock 369 252 500 minecraft:red_nether_bricks
fill 369 252 501 369 255 501 minecraft:pink_terracotta
setblock 370 252 475 minecraft:pink_terracotta
setblock 370 252 479 minecraft:red_nether_bricks
fill 370 252 480 370 255 480 minecraft:pink_terracotta
setblock 370 252 484 minecraft:red_nether_bricks
fill 370 252 485 370 255 485 minecraft:pink_terracotta
setblock 370 252 489 minecraft:red_nether_bricks
fill 370 252 490 370 255 490 minecraft:pink_terracotta
setblock 370 252 494 minecraft:red_nether_bricks
fill 370 252 495 370 255 495 minecraft:pink_terracotta
setblock 370 252 499 minecraft:red_nether_bricks
fill 370 252 500 370 255 500 minecraft:pink_terracotta
setblock 370 252 504 minecraft:red_nether_bricks
fill 330 253 474 330 253 477 minecraft:pink_terracotta
setblock 330 253 478 minecraft:red_nether_bricks
fill 330 253 479 330 253 482 minecraft:pink_terracotta
setblock 330 253 483 minecraft:red_nether_bricks
fill 330 253 484 330 256 484 minecraft:pink_terracotta
setblock 330 253 488 minecraft:red_nether_bricks
fill 330 253 489 330 256 489 minecraft:pink_terracotta
setblock 330 253 493 minecraft:red_nether_bricks
fill 330 253 494 330 254 494 minecraft:pink_terracotta
setblock 330 253 498 minecraft:red_nether_bricks
fill 330 253 499 330 255 499 minecraft:pink_terracotta
setblock 330 253 503 minecraft:red_nether_bricks
fill 330 253 504 330 255 504 minecraft:pink_terracotta
setblock 331 253 464 minecraft:white_concrete
setblock 331 253 477 minecraft:red_nether_bricks
fill 331 253 478 331 255 478 minecraft:pink_terracotta
setblock 331 253 482 minecraft:red_nether_bricks
fill 331 253 483 331 256 483 minecraft:pink_terracotta
setblock 332 253 480 minecraft:pink_terracotta
setblock 332 253 481 minecraft:red_nether_bricks
fill 335 253 504 338 253 504 minecraft:pink_terracotta
fill 337 253 464 338 253 464 minecraft:pink_terracotta
fill 338 253 503 339 253 503 minecraft:pink_terracotta
setblock 339 253 464 minecraft:red_nether_bricks
setblock 339 253 504 minecraft:red_nether_bricks
fill 340 253 464 342 253 465 minecraft:pink_terracotta
setblock 340 253 503 minecraft:red_nether_bricks
fill 340 253 504 343 253 504 minecraft:pink_terracotta
setblock 341 253 502 minecraft:red_nether_bricks
fill 341 253 503 341 256 503 minecraft:pink_terracotta
fill 342 253 502 342 255 502 minecraft:pink_terracotta
setblock 343 253 464 minecraft:pink_terracotta
setblock 343 253 465 minecraft:red_nether_bricks
fill 343 253 466 345 254 466 minecraft:pink_terracotta
setblock 344 253 464 minecraft:red_nether_bricks
fill 344 253 465 344 256 465 minecraft:pink_terracotta
setblock 344 253 504 minecraft:red_nether_bricks
fill 345 253 464 345 256 464 minecraft:pink_terracotta
setblock 345 253 503 minecraft:red_nether_bricks
fill 345 253 504 345 256 504 minecraft:pink_terracotta
setblock 346 253 502 minecraft:red_nether_bricks
fill 346 253 503 346 256 503 minecraft:pink_terracotta
setblock 347 253 465 minecraft:pink_terracotta
setblock 348 253 465 minecraft:red_nether_bricks
setblock 349 253 464 minecraft:red_nether_bricks
fill 349 253 465 349 256 465 minecraft:pink_terracotta
setblock 349 253 504 minecraft:red_nether_bricks
fill 350 253 464 353 253 464 minecraft:pink_terracotta
setblock 350 253 503 minecraft:red_nether_bricks
fill 350 253 504 353 253 504 minecraft:pink_terracotta
fill 351 253 503 354 253 503 minecraft:pink_terracotta
setblock 354 253 464 minecraft:red_nether_bricks
setblock 354 253 504 minecraft:red_nether_bricks
fill 355 253 464 355 256 464 minecraft:pink_terracotta
setblock 355 253 503 minecraft:red_nether_bricks
fill 355 253 504 355 256 504 minecraft:pink_terracotta
setblock 356 253 502 minecraft:red_nether_bricks
fill 356 253 503 356 256 503 minecraft:pink_terracotta
setblock 357 253 465 minecraft:pink_terracotta
fill 357 253 502 360 253 502 minecraft:pink_terracotta
setblock 358 253 465 minecraft:red_nether_bricks
setblock 359 253 464 minecraft:red_nether_bricks
fill 359 253 465 362 253 465 minecraft:pink_terracotta
fill 359 253 501 361 253 501 minecraft:pink_terracotta
setblock 359 253 504 minecraft:red_nether_bricks
fill 360 253 464 360 256 464 minecraft:pink_terracotta
setblock 360 253 503 minecraft:red_nether_bricks
fill 360 253 504 360 256 504 minecraft:pink_terracotta
setblock 361 253 502 minecraft:red_nether_bricks
fill 361 253 503 361 256 503 minecraft:pink_terracotta
setblock 362 253 500 minecraft:pink_terracotta
setblock 362 253 501 minecraft:red_nether_bricks
fill 362 253 502 362 256 502 minecraft:pink_terracotta
setblock 363 253 465 minecraft:red_nether_bricks
setblock 363 253 500 minecraft:red_nether_bricks
fill 363 253 501 363 256 501 minecraft:pink_terracotta
setblock 364 253 464 minecraft:red_nether_bricks
fill 364 253 465 364 256 465 minecraft:pink_terracotta
fill 364 253 500 364 254 500 minecraft:pink_terracotta
setblock 364 253 504 minecraft:red_nether_bricks
fill 365 253 464 365 256 464 minecraft:pink_terracotta
setblock 365 253 503 minecraft:red_nether_bricks
fill 365 253 504 365 256 504 minecraft:pink_terracotta
setblock 366 253 502 minecraft:red_nether_bricks
fill 366 253 503 366 256 503 minecraft:pink_terracotta
setblock 367 253 501 minecraft:red_nether_bricks
fill 367 253 502 367 256 502 minecraft:pink_terracotta
setblock 368 253 496 minecraft:pink_terracotta
setblock 368 253 500 minecraft:red_nether_bricks
fill 368 253 501 368 255 501 minecraft:pink_terracotta
setblock 369 253 464 minecraft:red_nether_bricks
setblock 369 253 479 minecraft:red_nether_bricks
fill 369 253 480 369 254 480 minecraft:pink_terracotta
setblock 369 253 484 minecraft:red_nether_bricks
fill 369 253 485 369 256 485 minecraft:pink_terracotta
setblock 369 253 494 minecraft:red_nether_bricks
fill 369 253 495 369 254 495 minecraft:pink_terracotta
setblock 369 253 499 minecraft:red_nether_bricks
fill 369 253 500 369 256 500 minecraft:pink_terracotta
setblock 369 253 504 minecraft:red_nether_bricks
setblock 370 253 469 minecraft:white_concrete
setblock 370 253 478 minecraft:red_nether_bricks
fill 370 253 479 370 256 479 minecraft:pink_terracotta
setblock 370 253 483 minecraft:red_nether_bricks
fill 370 253 484 370 256 484 minecraft:pink_terracotta
setblock 370 253 487 minecraft:pink_terracotta
setblock 370 253 488 minecraft:red_nether_bricks
fill 370 253 489 370 256 489 minecraft:pink_terracotta
setblock 370 253 493 minecraft:red_nether_bricks
fill 370 253 494 370 255 494 minecraft:pink_terracotta
setblock 370 253 498 minecraft:red_nether_bricks
fill 370 253 499 370 256 499 minecraft:pink_terracotta
setblock 370 253 503 minecraft:red_nether_bricks
fill 370 253 504 370 256 504 minecraft:pink_terracotta
fill 330 254 475 330 254 476 minecraft:pink_terracotta
setblock 330 254 477 minecraft:red_nether_bricks
fill 330 254 478 330 254 481 minecraft:pink_terracotta
setblock 330 254 482 minecraft:red_nether_bricks
fill 330 254 483 330 257 483 minecraft:pink_terracotta
setblock 330 254 487 minecraft:red_nether_bricks
fill 330 254 488 330 257 488 minecraft:pink_terracotta
setblock 330 254 492 minecraft:red_nether_bricks
setblock 330 254 493 minecraft:pink_terracotta
setblock 330 254 497 minecraft:red_nether_bricks
fill 330 254 498 330 255 498 minecraft:pink_terracotta
setblock 330 254 502 minecraft:red_nether_bricks
fill 330 254 503 330 256 503 minecraft:pink_terracotta
setblock 331 254 477 minecraft:pink_terracotta
setblock 331 254 481 minecraft:red_nether_bricks
fill 331 254 482 332 254 482 minecraft:pink_terracotta
setblock 331 254 486 minecraft:red_nether_bricks
setblock 332 254 481 minecraft:pink_terracotta
setblock 333 254 504 minecraft:red_nether_bricks
fill 334 254 504 337 254 504 minecraft:pink_terracotta
fill 336 254 464 337 254 464 minecraft:pink_terracotta
setblock 338 254 464 minecraft:red_nether_bricks
setblock 338 254 503 minecraft:pink_terracotta
setblock 338 254 504 minecraft:red_nether_bricks
fill 339 254 464 341 254 465 minecraft:pink_terracotta
setblock 339 254 503 minecraft:red_nether_bricks
fill 339 254 504 342 254 504 minecraft:pink_terracotta
fill 340 254 503 340 257 503 minecraft:pink_terracotta
setblock 341 254 502 minecraft:pink_terracotta
setblock 342 254 464 minecraft:pink_terracotta
setblock 342 254 465 minecraft:red_nether_bricks
fill 342 254 466 342 257 466 minecraft:pink_terracotta
setblock 343 254 464 minecraft:red_nether_bricks
fill 343 254 465 343 257 465 minecraft:pink_terracotta
setblock 343 254 504 minecraft:red_nether_bricks
fill 344 254 464 344 257 464 minecraft:pink_terracotta
setblock 344 254 502 minecraft:pink_terracotta
setblock 344 254 503 minecraft:red_nether_bricks
fill 344 254 504 344 257 504 minecraft:pink_terracotta
fill 345 254 502 345 273 502 minecraft:red_nether_bricks
fill 345 254 503 345 257 503 minecraft:pink_terracotta
setblock 346 254 466 minecraft:red_nether_bricks
setblock 346 254 502 minecraft:pink_terracotta
setblock 347 254 465 minecraft:red_nether_bricks
setblock 348 254 464 minecraft:red_nether_bricks
fill 348 254 465 348 257 465 minecraft:pink_terracotta
setblock 348 254 504 minecraft:red_nether_bricks
fill 349 254 464 352 254 464 minecraft:pink_terracotta
setblock 349 254 503 minecraft:red_nether_bricks
fill 349 254 504 352 254 504 minecraft:pink_terracotta
fill 350 254 503 353 254 503 minecraft:pink_terracotta
setblock 351 254 465 minecraft:pink_terracotta
setblock 353 254 464 minecraft:red_nether_bricks
setblock 353 254 504 minecraft:red_nether_bricks
fill 354 254 464 354 257 464 minecraft:pink_terracotta
setblock 354 254 503 minecraft:red_nether_bricks
fill 354 254 504 354 257 504 minecraft:pink_terracotta
fill 355 254 465 356 254 465 minecraft:pink_terracotta
fill 355 254 503 355 257 503 minecraft:pink_terracotta
fill 356 254 502 359 254 502 minecraft:pink_terracotta
setblock 357 254 465 minecraft:red_nether_bricks
setblock 358 254 464 minecraft:red_nether_bricks
fill 358 254 465 361 254 465 minecraft:pink_terracotta
setblock 358 254 504 minecraft:red_nether_bricks
fill 359 254 464 359 257 464 minecraft:pink_terracotta
fill 359 254 501 360 254 501 minecraft:pink_terracotta
setblock 359 254 503 minecraft:red_nether_bricks
fill 359 254 504 359 257 504 minecraft:pink_terracotta
setblock 360 254 502 minecraft:red_nether_bricks
fill 360 254 503 360 257 503 minecraft:pink_terracotta
setblock 361 254 501 minecraft:red_nether_bricks
fill 361 254 502 361 257 502 minecraft:pink_terracotta
setblock 362 254 465 minecraft:red_nether_bricks
setblock 362 254 500 minecraft:red_nether_bricks
fill 362 254 501 362 257 501 minecraft:pink_terracotta
setblock 363 254 464 minecraft:red_nether_bricks
fill 363 254 465 363 257 465 minecraft:pink_terracotta
setblock 363 254 500 minecraft:pink_terracotta
setblock 363 254 504 minecraft:red_nether_bricks
fill 364 254 464 364 257 464 minecraft:pink_terracotta
setblock 364 254 503 minecraft:red_nether_bricks
fill 364 254 504 364 257 504 minecraft:pink_terracotta
setblock 365 254 502 minecraft:red_nether_bricks
fill 365 254 503 365 257 503 minecraft:pink_terracotta
setblock 366 254 501 minecraft:red_nether_bricks
fill 366 254 502 366 257 502 minecraft:pink_terracotta
setblock 367 254 500 minecraft:red_nether_bricks
setblock 367 254 501 minecraft:pink_terracotta
setblock 368 254 464 minecraft:red_nether_bricks
setblock 368 254 499 minecraft:red_nether_bricks
fill 368 254 500 368 255 500 minecraft:pink_terracotta
setblock 368 254 504 minecraft:red_nether_bricks
fill 369 254 464 369 255 464 minecraft:pink_terracotta
setblock 369 254 479 minecraft:pink_terracotta
setblock 369 254 482 minecraft:pink_terracotta
setblock 369 254 483 minecraft:red_nether_bricks
fill 369 254 484 369 256 484 minecraft:pink_terracotta
setblock 369 254 498 minecraft:red_nether_bricks
fill 369 254 499 369 256 499 minecraft:pink_terracotta
setblock 369 254 503 minecraft:red_nether_bricks
fill 369 254 504 369 257 504 minecraft:pink_terracotta
setblock 370 254 477 minecraft:red_nether_bricks
fill 370 254 478 370 255 478 minecraft:pink_terracotta
setblock 370 254 482 minecraft:red_nether_bricks
fill 370 254 483 370 257 483 minecraft:pink_terracotta
setblock 370 254 487 minecraft:red_nether_bricks
fill 370 254 488 370 257 488 minecraft:pink_terracotta
setblock 370 254 492 minecraft:red_nether_bricks
fill 370 254 493 370 255 493 minecraft:pink_terracotta
setblock 370 254 497 minecraft:red_nether_bricks
fill 370 254 498 370 257 498 minecraft:pink_terracotta
setblock 370 254 502 minecraft:red_nether_bricks
fill 370 254 503 370 257 503 minecraft:pink_terracotta
setblock 330 255 467 minecraft:white_concrete
setblock 330 255 476 minecraft:red_nether_bricks
fill 330 255 477 330 255 480 minecraft:pink_terracotta
setblock 330 255 481 minecraft:red_nether_bricks
fill 330 255 482 331 257 482 minecraft:pink_terracotta
setblock 330 255 486 minecraft:red_nether_bricks
fill 330 255 487 330 258 487 minecraft:pink_terracotta
setblock 330 255 501 minecraft:red_nether_bricks
fill 330 255 502 330 256 502 minecraft:pink_terracotta
setblock 331 255 480 minecraft:red_nether_bricks
fill 331 255 481 331 258 481 minecraft:pink_terracotta
setblock 331 255 485 minecraft:red_nether_bricks
fill 331 255 486 331 258 486 minecraft:pink_terracotta
setblock 331 255 504 minecraft:pink_terracotta
setblock 332 255 466 minecraft:light[level=12]
setblock 332 255 474 minecraft:light[level=12]
setblock 332 255 482 minecraft:light[level=12]
setblock 332 255 490 minecraft:light[level=12]
setblock 332 255 498 minecraft:light[level=12]
fill 334 255 504 336 255 504 minecraft:pink_terracotta
setblock 336 255 464 minecraft:pink_terracotta
setblock 337 255 464 minecraft:red_nether_bricks
setblock 337 255 504 minecraft:red_nether_bricks
fill 338 255 464 340 255 465 minecraft:pink_terracotta
setblock 338 255 503 minecraft:red_nether_bricks
fill 338 255 504 341 255 504 minecraft:pink_terracotta
fill 339 255 503 339 258 503 minecraft:pink_terracotta
setblock 340 255 466 minecraft:light[level=12]
setblock 340 255 474 minecraft:light[level=12]
setblock 340 255 482 minecraft:light[level=12]
setblock 340 255 490 minecraft:light[level=12]
setblock 340 255 498 minecraft:light[level=12]
setblock 341 255 464 minecraft:pink_terracotta
setblock 341 255 465 minecraft:red_nether_bricks
fill 341 255 466 341 258 466 minecraft:pink_terracotta
setblock 342 255 464 minecraft:red_nether_bricks
fill 342 255 465 342 258 465 minecraft:pink_terracotta
setblock 342 255 504 minecraft:red_nether_bricks
fill 343 255 464 343 258 464 minecraft:pink_terracotta
fill 343 255 466 344 255 466 minecraft:pink_terracotta
setblock 343 255 503 minecraft:red_nether_bricks
fill 343 255 504 343 258 504 minecraft:pink_terracotta
setblock 344 255 502 minecraft:red_nether_bricks
fill 344 255 503 344 258 503 minecraft:pink_terracotta
setblock 345 255 466 minecraft:red_nether_bricks
setblock 346 255 465 minecraft:red_nether_bricks
setblock 347 255 464 minecraft:red_nether_bricks
fill 347 255 465 347 258 465 minecraft:pink_terracotta
setblock 347 255 504 minecraft:red_nether_bricks
fill 348 255 464 351 255 464 minecraft:pink_terracotta
setblock 348 255 466 minecraft:light[level=12]
setblock 348 255 474 minecraft:light[level=12]
setblock 348 255 482 minecraft:light[level=12]
setblock 348 255 490 minecraft:light[level=12]
setblock 348 255 498 minecraft:light[level=12]
setblock 348 255 503 minecraft:red_nether_bricks
fill 348 255 504 351 255 504 minecraft:pink_terracotta
fill 349 255 503 352 255 503 minecraft:pink_terracotta
setblock 351 255 465 minecraft:red_nether_bricks
setblock 352 255 464 minecraft:red_nether_bricks
setblock 352 255 504 minecraft:red_nether_bricks
fill 353 255 464 353 258 464 minecraft:pink_terracotta
setblock 353 255 503 minecraft:red_nether_bricks
fill 353 255 504 353 258 504 minecraft:pink_terracotta
fill 354 255 465 355 255 465 minecraft:pink_terracotta
fill 354 255 503 354 258 503 minecraft:pink_terracotta
setblock 356 255 465 minecraft:red_nether_bricks
setblock 356 255 466 minecraft:light[level=12]
setblock 356 255 474 minecraft:light[level=12]
setblock 356 255 482 minecraft:light[level=12]
setblock 356 255 490 minecraft:light[level=12]
setblock 356 255 498 minecraft:light[level=12]
fill 356 255 502 358 255 502 minecraft:pink_terracotta
setblock 357 255 464 minecraft:red_nether_bricks
fill 357 255 465 360 255 465 minecraft:pink_terracotta
setblock 357 255 504 minecraft:red_nether_bricks
fill 358 255 464 358 258 464 minecraft:pink_terracotta
setblock 358 255 503 minecraft:red_nether_bricks
fill 358 255 504 358 258 504 minecraft:pink_terracotta
setblock 359 255 501 minecraft:pink_terracotta
setblock 359 255 502 minecraft:red_nether_bricks
fill 359 255 503 359 258 503 minecraft:pink_terracotta
setblock 360 255 501 minecraft:red_nether_bricks
fill 360 255 502 360 258 502 minecraft:pink_terracotta
setblock 361 255 465 minecraft:red_nether_bricks
fill 361 255 501 361 257 501 minecraft:pink_terracotta
setblock 362 255 464 minecraft:red_nether_bricks
fill 362 255 465 362 258 465 minecraft:pink_terracotta
setblock 362 255 504 minecraft:red_nether_bricks
fill 363 255 464 363 258 464 minecraft:pink_terracotta
setblock 363 255 503 minecraft:red_nether_bricks
fill 363 255 504 363 258 504 minecraft:pink_terracotta
setblock 364 255 466 minecraft:light[level=12]
setblock 364 255 474 minecraft:light[level=12]
setblock 364 255 482 minecraft:light[level=12]
setblock 364 255 490 minecraft:light[level=12]
setblock 364 255 498 minecraft:light[level=12]
setblock 364 255 502 minecraft:red_nether_bricks
fill 364 255 503 364 258 503 minecraft:pink_terracotta
setblock 365 255 501 minecraft:red_nether_bricks
fill 365 255 502 365 258 502 minecraft:pink_terracotta
setblock 366 255 465 minecraft:red_nether_bricks
setblock 366 255 501 minecraft:pink_terracotta
setblock 367 255 464 minecraft:red_nether_bricks
setblock 367 255 504 minecraft:red_nether_bricks
fill 368 255 464 368 256 464 minecraft:pink_terracotta
setblock 368 255 499 minecraft:pink_terracotta
setblock 368 255 503 minecraft:red_nether_bricks
fill 368 255 504 368 258 504 minecraft:pink_terracotta
setblock 369 255 482 minecraft:red_nether_bricks
fill 369 255 483 369 256 483 minecraft:pink_terracotta
setblock 369 255 497 minecraft:red_nether_bricks
setblock 369 255 498 minecraft:pink_terracotta
setblock 369 255 502 minecraft:red_nether_bricks
fill 369 255 503 369 257 503 minecraft:pink_terracotta
setblock 370 255 476 minecraft:white_concrete
setblock 370 255 481 minecraft:red_nether_bricks
fill 370 255 482 370 258 482 minecraft:pink_terracotta
setblock 370 255 486 minecraft:red_nether_bricks
fill 370 255 487 370 258 487 minecraft:pink_terracotta
setblock 370 255 491 minecraft:red_nether_bricks
setblock 370 255 492 minecraft:pink_terracotta
setblock 370 255 496 minecraft:red_nether_bricks
fill 370 255 497 370 256 497 minecraft:pink_terracotta
setblock 370 255 501 minecraft:red_nether_bricks
fill 370 255 502 370 258 502 minecraft:pink_terracotta
setblock 330 256 473 minecraft:white_concrete
fill 330 256 477 330 256 479 minecraft:pink_terracotta
setblock 330 256 480 minecraft:red_nether_bricks
fill 330 256 481 330 259 481 minecraft:pink_terracotta
setblock 330 256 485 minecraft:red_nether_bricks
fill 330 256 486 330 259 486 minecraft:pink_terracotta
setblock 330 256 492 minecraft:white_concrete
fill 330 256 498 330 257 498 minecraft:white_concrete
setblock 331 256 479 minecraft:red_nether_bricks
fill 331 256 480 331 257 480 minecraft:pink_terracotta
setblock 331 256 484 minecraft:red_nether_bricks
fill 331 256 485 331 259 485 minecraft:pink_terracotta
setblock 332 256 464 minecraft:white_concrete
setblock 335 256 464 minecraft:pink_terracotta
setblock 335 256 504 minecraft:pink_terracotta
setblock 336 256 464 minecraft:red_nether_bricks
setblock 336 256 504 minecraft:red_nether_bricks
fill 337 256 464 340 256 464 minecraft:pink_terracotta
fill 337 256 504 340 256 504 minecraft:pink_terracotta
fill 338 256 465 339 256 465 minecraft:pink_terracotta
fill 338 256 503 338 257 503 minecraft:pink_terracotta
setblock 340 256 465 minecraft:red_nether_bricks
setblock 341 256 464 minecraft:red_nether_bricks
fill 341 256 465 341 259 465 minecraft:pink_terracotta
setblock 341 256 504 minecraft:red_nether_bricks
fill 342 256 464 342 259 464 minecraft:pink_terracotta
setblock 342 256 503 minecraft:red_nether_bricks
fill 342 256 504 342 259 504 minecraft:pink_terracotta
setblock 343 256 466 minecraft:pink_terracotta
fill 343 256 503 343 258 503 minecraft:pink_terracotta
setblock 344 256 466 minecraft:red_nether_bricks
setblock 345 256 465 minecraft:red_nether_bricks
setblock 345 256 466 minecraft:pink_terracotta
setblock 346 256 464 minecraft:red_nether_bricks
fill 346 256 465 346 259 465 minecraft:pink_terracotta
setblock 346 256 504 minecraft:red_nether_bricks
fill 347 256 464 350 256 464 minecraft:pink_terracotta
setblock 347 256 503 minecraft:red_nether_bricks
fill 347 256 504 350 256 504 minecraft:pink_terracotta
fill 348 256 503 349 256 503 minecraft:pink_terracotta
setblock 350 256 465 minecraft:red_nether_bricks
setblock 351 256 464 minecraft:red_nether_bricks
setblock 351 256 503 minecraft:pink_terracotta
setblock 351 256 504 minecraft:red_nether_bricks
fill 352 256 464 352 259 464 minecraft:pink_terracotta
setblock 352 256 503 minecraft:red_nether_bricks
fill 352 256 504 352 259 504 minecraft:pink_terracotta
fill 353 256 465 354 256 465 minecraft:pink_terracotta
fill 353 256 503 353 258 503 minecraft:pink_terracotta
setblock 355 256 465 minecraft:red_nether_bricks
setblock 356 256 464 minecraft:red_nether_bricks
fill 356 256 465 359 256 465 minecraft:pink_terracotta
fill 356 256 502 357 256 502 minecraft:pink_terracotta
setblock 356 256 504 minecraft:red_nether_bricks
fill 357 256 464 357 259 464 minecraft:pink_terracotta
setblock 357 256 503 minecraft:red_nether_bricks
fill 357 256 504 357 259 504 minecraft:pink_terracotta
setblock 358 256 502 minecraft:red_nether_bricks
fill 358 256 503 358 259 503 minecraft:pink_terracotta
setblock 359 256 501 minecraft:red_nether_bricks
fill 359 256 502 359 259 502 minecraft:pink_terracotta
setblock 360 256 465 minecraft:red_nether_bricks
fill 360 256 501 360 257 501 minecraft:pink_terracotta
setblock 361 256 464 minecraft:red_nether_bricks
fill 361 256 465 361 259 465 minecraft:pink_terracotta
setblock 361 256 504 minecraft:red_nether_bricks
fill 362 256 464 362 259 464 minecraft:pink_terracotta
setblock 362 256 503 minecraft:red_nether_bricks
fill 362 256 504 362 259 504 minecraft:pink_terracotta
setblock 363 256 502 minecraft:red_nether_bricks
fill 363 256 503 363 259 503 minecraft:pink_terracotta
setblock 364 256 501 minecraft:red_nether_bricks
fill 364 256 502 364 258 502 minecraft:pink_terracotta
setblock 365 256 465 minecraft:red_nether_bricks
setblock 365 256 501 minecraft:pink_terracotta
setblock 366 256 464 minecraft:red_nether_bricks
setblock 366 256 504 minecraft:red_nether_bricks
fill 367 256 464 367 258 464 minecraft:pink_terracotta
setblock 367 256 503 minecraft:red_nether_bricks
fill 367 256 504 367 259 504 minecraft:pink_terracotta
setblock 368 256 502 minecraft:red_nether_bricks
fill 368 256 503 368 257 503 minecraft:pink_terracotta
setblock 369 256 482 minecraft:pink_terracotta
setblock 369 256 501 minecraft:red_nether_bricks
fill 369 256 502 369 257 502 minecraft:pink_terracotta
setblock 370 256 470 minecraft:white_concrete
setblock 370 256 480 minecraft:red_nether_bricks
fill 370 256 481 370 258 481 minecraft:pink_terracotta
setblock 370 256 485 minecraft:red_nether_bricks
fill 370 256 486 370 259 486 minecraft:pink_terracotta
setblock 370 256 490 minecraft:red_nether_bricks
setblock 370 256 495 minecraft:white_concrete
setblock 370 256 496 minecraft:pink_terracotta
setblock 370 256 500 minecraft:red_nether_bricks
fill 370 256 501 370 258 501 minecraft:pink_terracotta
setblock 330 257 478 minecraft:pink_terracotta
setblock 330 257 479 minecraft:red_nether_bricks
fill 330 257 480 330 260 480 minecraft:pink_terracotta
setblock 330 257 484 minecraft:red_nether_bricks
fill 330 257 485 330 260 485 minecraft:pink_terracotta
setblock 330 257 489 minecraft:red_nether_bricks
setblock 330 257 504 minecraft:white_concrete
setblock 331 257 483 minecraft:red_nether_bricks
fill 331 257 484 331 260 484 minecraft:pink_terracotta
setblock 335 257 464 minecraft:red_nether_bricks
setblock 335 257 504 minecraft:red_nether_bricks
fill 336 257 464 339 257 464 minecraft:pink_terracotta
fill 336 257 504 339 257 504 minecraft:pink_terracotta
fill 337 257 465 338 257 465 minecraft:pink_terracotta
setblock 339 257 465 minecraft:red_nether_bricks
setblock 340 257 464 minecraft:red_nether_bricks
fill 340 257 465 340 259 466 minecraft:pink_terracotta
setblock 340 257 504 minecraft:red_nether_bricks
fill 341 257 464 341 260 464 minecraft:pink_terracotta
setblock 341 257 503 minecraft:red_nether_bricks
fill 341 257 504 341 260 504 minecraft:pink_terracotta
fill 342 257 503 342 259 503 minecraft:pink_terracotta
setblock 343 257 466 minecraft:red_nether_bricks
setblock 344 257 465 minecraft:red_nether_bricks
fill 344 257 466 344 259 466 minecraft:pink_terracotta
setblock 345 257 464 minecraft:red_nether_bricks
fill 345 257 465 345 260 465 minecraft:pink_terracotta
setblock 345 257 504 minecraft:red_nether_bricks
fill 346 257 464 349 257 464 minecraft:pink_terracotta
setblock 346 257 503 minecraft:red_nether_bricks
fill 346 257 504 349 257 504 minecraft:pink_terracotta
setblock 349 257 465 minecraft:red_nether_bricks
setblock 350 257 464 minecraft:red_nether_bricks
setblock 350 257 465 minecraft:pink_terracotta
setblock 350 257 504 minecraft:red_nether_bricks
fill 351 257 464 351 260 464 minecraft:pink_terracotta
fill 351 257 504 351 260 504 minecraft:pink_terracotta
setblock 353 257 465 minecraft:pink_terracotta
setblock 354 257 465 minecraft:red_nether_bricks
setblock 355 257 464 minecraft:red_nether_bricks
fill 355 257 465 358 257 465 minecraft:pink_terracotta
setblock 355 257 504 minecraft:red_nether_bricks
fill 356 257 464 356 260 464 minecraft:pink_terracotta
setblock 356 257 502 minecraft:pink_terracotta
setblock 356 257 503 minecraft:red_nether_bricks
fill 356 257 504 356 260 504 minecraft:pink_terracotta
setblock 357 257 502 minecraft:red_nether_bricks
fill 357 257 503 357 260 503 minecraft:pink_terracotta
fill 358 257 502 358 260 502 minecraft:pink_terracotta
setblock 359 257 465 minecraft:red_nether_bricks
setblock 360 257 464 minecraft:red_nether_bricks
fill 360 257 465 360 260 465 minecraft:pink_terracotta
setblock 360 257 504 minecraft:red_nether_bricks
fill 361 257 464 361 260 464 minecraft:pink_terracotta
setblock 361 257 503 minecraft:red_nether_bricks
schedule function dropper:buildpart/115_9 1t
