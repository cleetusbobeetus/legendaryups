setblock 125 120 646 minecraft:crying_obsidian
fill 126 120 646 126 130 646 minecraft:black_concrete
fill 130 120 604 130 126 604 minecraft:black_concrete
fill 133 120 604 133 206 604 minecraft:black_concrete
fill 136 120 614 136 126 614 minecraft:black_concrete
fill 136 120 617 136 189 617 minecraft:black_concrete
setblock 136 120 618 minecraft:amethyst_block
fill 136 120 630 136 126 630 minecraft:black_concrete
setblock 136 120 636 minecraft:white_concrete
fill 136 120 637 136 140 637 minecraft:black_concrete
fill 94 121 620 94 131 625 minecraft:black_concrete
setblock 94 121 626 minecraft:crying_obsidian
fill 96 121 646 96 206 646 minecraft:black_concrete
setblock 97 121 646 minecraft:crying_obsidian
fill 98 121 646 98 132 646 minecraft:black_concrete
fill 99 121 619 99 124 621 minecraft:obsidian
fill 100 121 617 100 124 617 minecraft:obsidian
fill 100 121 622 100 124 622 minecraft:obsidian
fill 102 121 623 102 124 623 minecraft:obsidian
fill 104 121 617 104 124 617 minecraft:obsidian
fill 104 121 622 104 124 622 minecraft:obsidian
fill 105 121 618 105 124 621 minecraft:obsidian
fill 108 121 604 108 125 604 minecraft:black_concrete
fill 116 121 646 116 147 646 minecraft:black_concrete
setblock 117 121 646 minecraft:white_concrete
fill 118 121 646 119 148 646 minecraft:black_concrete
setblock 121 121 646 minecraft:white_concrete
fill 125 121 646 125 139 646 minecraft:black_concrete
fill 136 121 618 136 201 618 minecraft:black_concrete
fill 136 121 636 136 128 636 minecraft:black_concrete
fill 94 122 626 94 158 626 minecraft:black_concrete
fill 97 122 646 97 159 646 minecraft:black_concrete
fill 99 122 618 99 124 618 minecraft:obsidian
fill 99 122 622 99 124 622 minecraft:obsidian
fill 101 122 616 103 124 616 minecraft:obsidian
fill 101 122 623 101 124 623 minecraft:obsidian
fill 103 122 623 104 124 623 minecraft:obsidian
fill 105 122 622 105 124 622 minecraft:obsidian
fill 117 122 646 117 206 646 minecraft:black_concrete
fill 121 122 646 121 177 646 minecraft:black_concrete
setblock 136 122 619 minecraft:white_concrete
fill 136 122 620 136 206 620 minecraft:black_concrete
setblock 94 123 632 minecraft:black_concrete
fill 94 123 633 94 124 633 minecraft:crying_obsidian
setblock 94 123 634 minecraft:amethyst_block
fill 94 123 635 94 129 635 minecraft:black_concrete
fill 98 123 619 98 124 621 minecraft:obsidian
fill 99 123 617 99 124 617 minecraft:obsidian
fill 100 123 616 100 124 616 minecraft:obsidian
fill 100 123 623 100 124 623 minecraft:obsidian
fill 102 123 624 102 124 624 minecraft:obsidian
fill 104 123 616 104 124 616 minecraft:obsidian
fill 105 123 617 105 124 617 minecraft:obsidian
fill 106 123 618 106 124 621 minecraft:obsidian
fill 136 123 619 136 126 619 minecraft:black_concrete
setblock 94 124 632 minecraft:crying_obsidian
fill 94 124 634 94 147 634 minecraft:black_concrete
setblock 94 124 641 minecraft:amethyst_block
setblock 94 124 645 minecraft:white_concrete
fill 98 124 617 98 124 618 minecraft:obsidian
setblock 98 124 622 minecraft:obsidian
setblock 99 124 616 minecraft:obsidian
setblock 99 124 623 minecraft:obsidian
fill 100 124 624 101 124 624 minecraft:obsidian
fill 101 124 615 103 124 615 minecraft:obsidian
fill 103 124 624 104 124 624 minecraft:obsidian
setblock 105 124 616 minecraft:obsidian
setblock 105 124 623 minecraft:obsidian
setblock 106 124 617 minecraft:obsidian
setblock 106 124 622 minecraft:obsidian
fill 115 124 604 120 137 604 minecraft:black_concrete
setblock 121 124 604 minecraft:amethyst_block
fill 136 124 615 136 134 615 minecraft:black_concrete
setblock 136 124 616 minecraft:white_concrete
setblock 94 125 613 minecraft:crying_obsidian
fill 94 125 614 94 138 619 minecraft:black_concrete
fill 94 125 632 94 159 633 minecraft:black_concrete
fill 94 125 641 94 134 641 minecraft:black_concrete
fill 94 125 645 94 160 645 minecraft:black_concrete
fill 101 125 619 103 125 620 minecraft:amethyst_block
fill 121 125 604 121 160 604 minecraft:black_concrete
setblock 124 125 646 minecraft:amethyst_block
fill 136 125 616 136 199 616 minecraft:black_concrete
fill 94 126 613 94 151 613 minecraft:black_concrete
fill 102 126 619 102 127 620 minecraft:amethyst_block
setblock 103 126 620 minecraft:amethyst_block
setblock 108 126 604 minecraft:amethyst_block
fill 112 126 617 113 127 617 minecraft:end_stone
fill 117 126 644 117 131 644 minecraft:amethyst_block
setblock 124 126 646 minecraft:black_concrete
setblock 126 126 604 minecraft:white_concrete
fill 127 126 623 128 127 624 minecraft:netherrack
fill 129 126 624 129 127 624 minecraft:netherrack
setblock 135 126 604 minecraft:white_concrete
fill 136 126 604 136 206 604 minecraft:black_concrete
fill 94 127 612 94 128 612 minecraft:purple_stained_glass
fill 94 127 628 94 128 628 minecraft:purple_stained_glass
fill 94 127 644 94 128 644 minecraft:purple_stained_glass
setblock 97 127 607 minecraft:light[level=14]
setblock 97 127 615 minecraft:light[level=14]
setblock 97 127 623 minecraft:light[level=14]
setblock 97 127 631 minecraft:light[level=14]
setblock 97 127 639 minecraft:light[level=14]
fill 98 127 604 98 128 604 minecraft:purple_stained_glass
setblock 105 127 607 minecraft:light[level=14]
setblock 105 127 615 minecraft:light[level=14]
setblock 105 127 623 minecraft:light[level=14]
setblock 105 127 631 minecraft:light[level=14]
setblock 105 127 639 minecraft:light[level=14]
fill 108 127 604 108 203 604 minecraft:black_concrete
fill 108 127 646 108 128 646 minecraft:purple_stained_glass
setblock 113 127 607 minecraft:light[level=14]
setblock 113 127 615 minecraft:light[level=14]
setblock 113 127 623 minecraft:light[level=14]
setblock 113 127 631 minecraft:light[level=14]
setblock 113 127 639 minecraft:light[level=14]
fill 114 127 604 114 128 604 minecraft:purple_stained_glass
fill 115 127 644 116 130 644 minecraft:amethyst_block
fill 116 127 641 118 129 643 minecraft:amethyst_block
fill 116 127 645 118 130 645 minecraft:amethyst_block
fill 117 127 640 117 129 640 minecraft:amethyst_block
fill 118 127 644 119 132 644 minecraft:amethyst_block
setblock 121 127 607 minecraft:light[level=14]
setblock 121 127 615 minecraft:light[level=14]
setblock 121 127 623 minecraft:light[level=14]
setblock 121 127 631 minecraft:light[level=14]
setblock 121 127 639 minecraft:light[level=14]
fill 124 127 646 124 128 646 minecraft:purple_stained_glass
fill 126 127 604 126 142 604 minecraft:black_concrete
setblock 129 127 607 minecraft:light[level=14]
setblock 129 127 615 minecraft:light[level=14]
setblock 129 127 623 minecraft:light[level=14]
setblock 129 127 631 minecraft:light[level=14]
setblock 129 127 639 minecraft:light[level=14]
fill 130 127 604 130 128 604 minecraft:purple_stained_glass
fill 135 127 604 135 172 604 minecraft:black_concrete
setblock 136 127 605 minecraft:white_concrete
fill 136 127 614 136 128 614 minecraft:purple_stained_glass
setblock 136 127 619 minecraft:white_concrete
fill 136 127 623 136 149 627 minecraft:black_concrete
setblock 136 127 628 minecraft:amethyst_block
fill 136 127 629 136 189 629 minecraft:black_concrete
fill 136 127 630 136 128 630 minecraft:purple_stained_glass
setblock 99 128 604 minecraft:amethyst_block
setblock 102 128 620 minecraft:amethyst_block
setblock 105 128 646 minecraft:amethyst_block
fill 115 128 642 115 129 643 minecraft:amethyst_block
fill 115 128 645 115 129 645 minecraft:amethyst_block
fill 116 128 638 116 128 640 minecraft:amethyst_block
fill 117 128 636 117 128 639 minecraft:amethyst_block
fill 118 128 638 118 128 640 minecraft:amethyst_block
fill 119 128 642 119 129 643 minecraft:amethyst_block
fill 119 128 645 119 129 645 minecraft:amethyst_block
fill 136 128 605 136 160 605 minecraft:black_concrete
fill 136 128 609 136 140 612 minecraft:black_concrete
setblock 136 128 613 minecraft:crying_obsidian
fill 136 128 619 136 177 619 minecraft:black_concrete
fill 136 128 628 136 204 628 minecraft:black_concrete
fill 94 129 612 94 135 612 minecraft:black_concrete
fill 94 129 628 94 135 628 minecraft:black_concrete
fill 94 129 644 94 135 644 minecraft:black_concrete
fill 98 129 604 99 135 604 minecraft:black_concrete
fill 105 129 646 105 134 646 minecraft:black_concrete
fill 108 129 646 108 135 646 minecraft:black_concrete
fill 114 129 604 114 135 604 minecraft:black_concrete
fill 116 129 639 116 129 640 minecraft:amethyst_block
fill 117 129 638 117 129 639 minecraft:amethyst_block
fill 118 129 639 118 129 640 minecraft:amethyst_block
fill 124 129 646 124 135 646 minecraft:black_concrete
fill 130 129 604 130 135 604 minecraft:black_concrete
fill 136 129 613 136 135 614 minecraft:black_concrete
fill 136 129 630 136 133 630 minecraft:black_concrete
setblock 136 129 636 minecraft:white_concrete
setblock 94 130 635 minecraft:amethyst_block
fill 116 130 642 118 130 643 minecraft:amethyst_block
setblock 117 130 641 minecraft:amethyst_block
setblock 123 130 604 minecraft:white_concrete
fill 132 130 646 132 159 646 minecraft:black_concrete
setblock 133 130 646 minecraft:white_concrete
setblock 136 130 635 minecraft:amethyst_block
fill 136 130 636 136 177 636 minecraft:black_concrete
fill 94 131 635 94 141 635 minecraft:black_concrete
fill 118 131 643 120 133 643 minecraft:amethyst_block
fill 118 131 645 120 132 645 minecraft:amethyst_block
fill 120 131 644 120 132 644 minecraft:amethyst_block
setblock 123 131 604 minecraft:black_concrete
setblock 126 131 646 minecraft:amethyst_block
fill 133 131 646 133 182 646 minecraft:black_concrete
fill 136 131 635 136 153 635 minecraft:black_concrete
fill 94 132 620 94 138 624 minecraft:black_concrete
setblock 94 132 625 minecraft:crying_obsidian
fill 119 132 642 119 134 642 minecraft:amethyst_block
setblock 123 132 604 minecraft:amethyst_block
fill 126 132 646 126 147 646 minecraft:black_concrete
setblock 134 132 604 minecraft:crying_obsidian
fill 94 133 608 94 152 608 minecraft:black_concrete
setblock 94 133 609 minecraft:amethyst_block
fill 94 133 610 94 138 611 minecraft:black_concrete
fill 94 133 625 94 186 625 minecraft:black_concrete
setblock 98 133 646 minecraft:white_concrete
fill 102 133 646 103 163 646 minecraft:black_concrete
setblock 104 133 646 minecraft:crying_obsidian
setblock 110 133 646 minecraft:amethyst_block
fill 116 133 616 116 134 616 minecraft:end_stone
setblock 118 133 642 minecraft:amethyst_block
fill 119 133 641 119 134 641 minecraft:amethyst_block
setblock 119 133 644 minecraft:amethyst_block
setblock 120 133 642 minecraft:amethyst_block
fill 123 133 604 123 205 604 minecraft:black_concrete
fill 134 133 604 134 139 604 minecraft:black_concrete
setblock 94 134 609 minecraft:black_concrete
fill 94 134 637 94 149 639 minecraft:black_concrete
setblock 94 134 640 minecraft:amethyst_block
fill 98 134 646 98 155 646 minecraft:black_concrete
fill 104 134 646 104 153 646 minecraft:black_concrete
fill 110 134 646 110 159 646 minecraft:black_concrete
fill 113 134 642 114 135 643 minecraft:obsidian
setblock 119 134 640 minecraft:amethyst_block
setblock 131 134 604 minecraft:crying_obsidian
setblock 136 134 630 minecraft:crying_obsidian
setblock 94 135 609 minecraft:white_concrete
fill 94 135 640 94 147 640 minecraft:black_concrete
setblock 94 135 641 minecraft:white_concrete
setblock 97 135 607 minecraft:light[level=14]
setblock 97 135 615 minecraft:light[level=14]
setblock 97 135 623 minecraft:light[level=14]
setblock 97 135 631 minecraft:light[level=14]
setblock 97 135 639 minecraft:light[level=14]
setblock 105 135 607 minecraft:light[level=14]
setblock 105 135 615 minecraft:light[level=14]
setblock 105 135 623 minecraft:light[level=14]
setblock 105 135 631 minecraft:light[level=14]
setblock 105 135 639 minecraft:light[level=14]
setblock 105 135 646 minecraft:white_concrete
setblock 113 135 607 minecraft:light[level=14]
setblock 113 135 615 minecraft:light[level=14]
setblock 113 135 623 minecraft:light[level=14]
setblock 113 135 631 minecraft:light[level=14]
setblock 113 135 639 minecraft:light[level=14]
setblock 121 135 607 minecraft:light[level=14]
setblock 121 135 615 minecraft:light[level=14]
setblock 121 135 623 minecraft:light[level=14]
setblock 121 135 631 minecraft:light[level=14]
setblock 121 135 639 minecraft:light[level=14]
setblock 129 135 607 minecraft:light[level=14]
setblock 129 135 615 minecraft:light[level=14]
setblock 129 135 623 minecraft:light[level=14]
setblock 129 135 631 minecraft:light[level=14]
setblock 129 135 639 minecraft:light[level=14]
fill 131 135 604 131 165 604 minecraft:black_concrete
setblock 136 135 615 minecraft:crying_obsidian
setblock 136 135 630 minecraft:black_concrete
fill 94 136 609 94 142 609 minecraft:black_concrete
fill 94 136 612 94 137 612 minecraft:purple_stained_glass
fill 94 136 628 94 137 628 minecraft:purple_stained_glass
fill 94 136 641 94 147 641 minecraft:black_concrete
fill 94 136 644 94 137 644 minecraft:purple_stained_glass
fill 98 136 604 98 137 604 minecraft:purple_stained_glass
fill 99 136 604 99 183 604 minecraft:black_concrete
fill 99 136 646 99 158 646 minecraft:black_concrete
setblock 100 136 646 minecraft:crying_obsidian
fill 105 136 646 105 206 646 minecraft:black_concrete
fill 108 136 646 108 137 646 minecraft:purple_stained_glass
fill 114 136 604 114 137 604 minecraft:purple_stained_glass
fill 124 136 646 124 137 646 minecraft:purple_stained_glass
setblock 128 136 604 minecraft:crying_obsidian
fill 130 136 604 130 137 604 minecraft:purple_stained_glass
fill 136 136 613 136 204 613 minecraft:black_concrete
fill 136 136 614 136 137 614 minecraft:purple_stained_glass
fill 136 136 615 136 171 615 minecraft:black_concrete
fill 136 136 630 136 137 630 minecraft:purple_stained_glass
setblock 95 137 646 minecraft:amethyst_block
fill 100 137 646 100 203 646 minecraft:black_concrete
setblock 110 137 604 minecraft:white_concrete
fill 128 137 604 128 206 604 minecraft:black_concrete
fill 94 138 612 94 144 612 minecraft:black_concrete
fill 94 138 628 94 144 628 minecraft:black_concrete
fill 94 138 644 94 144 644 minecraft:black_concrete
fill 95 138 646 95 206 646 minecraft:black_concrete
fill 98 138 604 98 144 604 minecraft:black_concrete
setblock 102 138 604 minecraft:amethyst_block
fill 108 138 646 108 144 646 minecraft:black_concrete
setblock 110 138 604 minecraft:amethyst_block
fill 114 138 604 119 141 604 minecraft:black_concrete
setblock 120 138 604 minecraft:crying_obsidian
fill 124 138 646 124 144 646 minecraft:black_concrete
fill 130 138 604 130 144 604 minecraft:black_concrete
fill 136 138 614 136 144 614 minecraft:black_concrete
fill 136 138 630 136 144 630 minecraft:black_concrete
setblock 94 139 610 minecraft:crying_obsidian
fill 94 139 611 94 140 611 minecraft:black_concrete
fill 94 139 614 94 142 617 minecraft:black_concrete
setblock 94 139 618 minecraft:white_concrete
fill 94 139 619 94 154 623 minecraft:black_concrete
setblock 94 139 624 minecraft:white_concrete
fill 102 139 604 102 187 604 minecraft:black_concrete
fill 110 139 604 110 163 604 minecraft:black_concrete
fill 120 139 604 120 144 604 minecraft:black_concrete
setblock 128 139 646 minecraft:amethyst_block
fill 129 139 646 131 164 646 minecraft:black_concrete
fill 94 140 610 94 151 610 minecraft:black_concrete
fill 94 140 618 94 176 618 minecraft:black_concrete
fill 94 140 624 94 183 624 minecraft:black_concrete
setblock 94 140 643 minecraft:white_concrete
fill 112 140 633 112 141 633 minecraft:netherrack
setblock 125 140 646 minecraft:crying_obsidian
fill 128 140 646 128 159 646 minecraft:black_concrete
setblock 134 140 604 minecraft:white_concrete
setblock 94 141 611 minecraft:amethyst_block
fill 94 141 643 94 206 643 minecraft:black_concrete
fill 116 141 633 116 142 633 minecraft:end_stone
fill 125 141 646 125 191 646 minecraft:black_concrete
fill 134 141 604 134 143 604 minecraft:black_concrete
fill 136 141 609 136 143 611 minecraft:black_concrete
setblock 136 141 612 minecraft:amethyst_block
setblock 136 141 637 minecraft:white_concrete
fill 94 142 611 94 188 611 minecraft:black_concrete
setblock 94 142 635 minecraft:crying_obsidian
fill 114 142 604 115 144 604 minecraft:black_concrete
setblock 116 142 604 minecraft:amethyst_block
fill 117 142 604 119 155 604 minecraft:black_concrete
fill 136 142 612 136 157 612 minecraft:black_concrete
fill 136 142 637 136 151 637 minecraft:black_concrete
setblock 94 143 609 minecraft:amethyst_block
fill 94 143 614 94 159 615 minecraft:black_concrete
setblock 94 143 616 minecraft:crying_obsidian
fill 94 143 617 94 204 617 minecraft:black_concrete
setblock 94 143 635 minecraft:black_concrete
setblock 97 143 607 minecraft:light[level=14]
setblock 97 143 615 minecraft:light[level=14]
setblock 97 143 623 minecraft:light[level=14]
setblock 97 143 631 minecraft:light[level=14]
setblock 97 143 639 minecraft:light[level=14]
setblock 105 143 607 minecraft:light[level=14]
setblock 105 143 615 minecraft:light[level=14]
setblock 105 143 623 minecraft:light[level=14]
setblock 105 143 631 minecraft:light[level=14]
setblock 105 143 639 minecraft:light[level=14]
setblock 113 143 607 minecraft:light[level=14]
setblock 113 143 615 minecraft:light[level=14]
setblock 113 143 623 minecraft:light[level=14]
setblock 113 143 631 minecraft:light[level=14]
setblock 113 143 639 minecraft:light[level=14]
fill 116 143 604 116 203 604 minecraft:black_concrete
setblock 121 143 607 minecraft:light[level=14]
setblock 121 143 615 minecraft:light[level=14]
setblock 121 143 623 minecraft:light[level=14]
setblock 121 143 631 minecraft:light[level=14]
setblock 121 143 639 minecraft:light[level=14]
setblock 126 143 604 minecraft:white_concrete
setblock 129 143 607 minecraft:light[level=14]
setblock 129 143 615 minecraft:light[level=14]
setblock 129 143 623 minecraft:light[level=14]
setblock 129 143 631 minecraft:light[level=14]
setblock 129 143 639 minecraft:light[level=14]
fill 94 144 609 94 206 609 minecraft:black_concrete
fill 94 144 616 94 203 616 minecraft:black_concrete
setblock 94 144 635 minecraft:white_concrete
fill 126 144 604 126 206 604 minecraft:black_concrete
setblock 134 144 604 minecraft:white_concrete
setblock 136 144 609 minecraft:white_concrete
fill 136 144 610 136 146 611 minecraft:black_concrete
fill 94 145 612 94 146 612 minecraft:purple_stained_glass
fill 94 145 628 94 146 628 minecraft:purple_stained_glass
fill 94 145 635 94 179 635 minecraft:black_concrete
fill 94 145 644 94 146 644 minecraft:purple_stained_glass
fill 98 145 604 98 146 604 minecraft:purple_stained_glass
fill 108 145 646 108 146 646 minecraft:purple_stained_glass
fill 114 145 604 114 146 604 minecraft:purple_stained_glass
fill 115 145 604 115 186 604 minecraft:black_concrete
setblock 120 145 604 minecraft:amethyst_block
fill 124 145 646 124 146 646 minecraft:purple_stained_glass
fill 130 145 604 130 146 604 minecraft:purple_stained_glass
fill 134 145 604 134 206 604 minecraft:black_concrete
fill 136 145 609 136 170 609 minecraft:black_concrete
fill 136 145 614 136 146 614 minecraft:purple_stained_glass
fill 136 145 630 136 146 630 minecraft:purple_stained_glass
setblock 136 145 639 minecraft:crying_obsidian
setblock 94 146 630 minecraft:amethyst_block
fill 120 146 604 120 160 604 minecraft:black_concrete
fill 136 146 639 136 188 639 minecraft:black_concrete
fill 94 147 612 94 153 612 minecraft:black_concrete
fill 94 147 628 94 153 628 minecraft:black_concrete
fill 94 147 630 94 150 630 minecraft:black_concrete
fill 94 147 644 94 153 644 minecraft:black_concrete
fill 98 147 604 98 153 604 minecraft:black_concrete
fill 108 147 646 108 153 646 minecraft:black_concrete
fill 114 147 604 114 153 604 minecraft:black_concrete
setblock 122 147 604 minecraft:crying_obsidian
fill 124 147 646 124 153 646 minecraft:black_concrete
fill 130 147 604 130 153 604 minecraft:black_concrete
setblock 134 147 646 minecraft:crying_obsidian
setblock 136 147 610 minecraft:amethyst_block
fill 136 147 611 136 206 611 minecraft:black_concrete
fill 136 147 614 136 153 614 minecraft:black_concrete
fill 136 147 630 136 153 630 minecraft:black_concrete
setblock 94 148 634 minecraft:white_concrete
setblock 94 148 640 minecraft:white_concrete
setblock 94 148 641 minecraft:crying_obsidian
fill 95 148 604 96 148 604 minecraft:black_concrete
setblock 97 148 604 minecraft:crying_obsidian
setblock 101 148 604 minecraft:amethyst_block
setblock 116 148 646 minecraft:crying_obsidian
fill 122 148 604 122 165 604 minecraft:black_concrete
setblock 126 148 646 minecraft:amethyst_block
fill 134 148 646 134 169 646 minecraft:black_concrete
fill 136 148 610 136 166 610 minecraft:black_concrete
setblock 136 148 621 minecraft:white_concrete
fill 136 148 641 136 149 644 minecraft:black_concrete
setblock 136 148 645 minecraft:crying_obsidian
fill 94 149 634 94 158 634 minecraft:black_concrete
fill 94 149 640 94 175 641 minecraft:black_concrete
fill 95 149 604 95 197 604 minecraft:black_concrete
setblock 96 149 604 minecraft:crying_obsidian
fill 97 149 604 97 206 604 minecraft:black_concrete
fill 101 149 604 101 206 604 minecraft:black_concrete
fill 116 149 646 116 177 646 minecraft:black_concrete
fill 118 149 646 118 206 646 minecraft:black_concrete
setblock 119 149 646 minecraft:amethyst_block
fill 126 149 646 126 206 646 minecraft:black_concrete
fill 136 149 621 136 155 621 minecraft:black_concrete
fill 136 149 645 136 204 645 minecraft:black_concrete
fill 94 150 637 94 203 638 minecraft:black_concrete
setblock 94 150 639 minecraft:white_concrete
fill 96 150 604 96 207 604 minecraft:black_concrete
fill 119 150 646 119 155 646 minecraft:black_concrete
fill 134 150 635 134 153 635 minecraft:amethyst_block
fill 136 150 623 136 152 625 minecraft:black_concrete
setblock 136 150 626 minecraft:amethyst_block
fill 136 150 627 136 203 627 minecraft:black_concrete
fill 136 150 641 136 191 643 minecraft:black_concrete
setblock 136 150 644 minecraft:white_concrete
setblock 94 151 630 minecraft:amethyst_block
fill 94 151 639 94 166 639 minecraft:black_concrete
setblock 97 151 607 minecraft:light[level=14]
setblock 97 151 615 minecraft:light[level=14]
setblock 97 151 623 minecraft:light[level=14]
setblock 97 151 631 minecraft:light[level=14]
setblock 97 151 639 minecraft:light[level=14]
setblock 105 151 607 minecraft:light[level=14]
setblock 105 151 615 minecraft:light[level=14]
setblock 105 151 623 minecraft:light[level=14]
setblock 105 151 631 minecraft:light[level=14]
setblock 105 151 639 minecraft:light[level=14]
setblock 113 151 607 minecraft:light[level=14]
setblock 113 151 615 minecraft:light[level=14]
setblock 113 151 623 minecraft:light[level=14]
setblock 113 151 631 minecraft:light[level=14]
setblock 113 151 639 minecraft:light[level=14]
setblock 121 151 607 minecraft:light[level=14]
setblock 121 151 615 minecraft:light[level=14]
setblock 121 151 623 minecraft:light[level=14]
setblock 121 151 631 minecraft:light[level=14]
setblock 121 151 639 minecraft:light[level=14]
setblock 129 151 607 minecraft:light[level=14]
setblock 129 151 615 minecraft:light[level=14]
setblock 129 151 623 minecraft:light[level=14]
setblock 129 151 631 minecraft:light[level=14]
setblock 129 151 639 minecraft:light[level=14]
fill 131 151 635 133 152 635 minecraft:amethyst_block
fill 133 151 634 135 152 634 minecraft:amethyst_block
fill 133 151 636 135 152 636 minecraft:amethyst_block
fill 135 151 635 135 152 635 minecraft:amethyst_block
setblock 136 151 606 minecraft:white_concrete
fill 136 151 626 136 206 626 minecraft:black_concrete
fill 136 151 644 136 199 644 minecraft:black_concrete
fill 94 152 610 94 153 610 minecraft:amethyst_block
setblock 94 152 613 minecraft:crying_obsidian
fill 94 152 630 94 181 630 minecraft:black_concrete
setblock 111 152 646 minecraft:crying_obsidian
setblock 130 152 635 minecraft:amethyst_block
setblock 132 152 634 minecraft:amethyst_block
setblock 132 152 636 minecraft:amethyst_block
fill 136 152 606 136 172 606 minecraft:black_concrete
setblock 136 152 637 minecraft:white_concrete
setblock 94 153 608 minecraft:crying_obsidian
fill 94 153 613 94 154 613 minecraft:black_concrete
fill 111 153 646 111 198 646 minecraft:black_concrete
setblock 136 153 623 minecraft:white_concrete
fill 136 153 624 136 171 625 minecraft:black_concrete
fill 136 153 637 136 206 637 minecraft:black_concrete
fill 94 154 608 94 163 608 minecraft:black_concrete
fill 94 154 610 94 191 610 minecraft:black_concrete
fill 94 154 612 94 155 612 minecraft:purple_stained_glass
fill 94 154 628 94 155 628 minecraft:purple_stained_glass
fill 94 154 644 94 155 644 minecraft:purple_stained_glass
fill 98 154 604 98 155 604 minecraft:purple_stained_glass
setblock 104 154 646 minecraft:amethyst_block
fill 108 154 646 108 155 646 minecraft:purple_stained_glass
fill 114 154 604 114 155 604 minecraft:purple_stained_glass
fill 124 154 646 124 155 646 minecraft:purple_stained_glass
fill 130 154 604 130 155 604 minecraft:purple_stained_glass
fill 136 154 614 136 155 614 minecraft:purple_stained_glass
fill 136 154 623 136 159 623 minecraft:black_concrete
fill 136 154 630 136 155 630 minecraft:purple_stained_glass
setblock 136 154 635 minecraft:amethyst_block
setblock 94 155 613 minecraft:crying_obsidian
setblock 94 155 619 minecraft:black_concrete
setblock 94 155 620 minecraft:white_concrete
fill 94 155 621 94 182 623 minecraft:black_concrete
fill 104 155 646 104 206 646 minecraft:black_concrete
fill 122 155 646 122 201 646 minecraft:black_concrete
setblock 123 155 646 minecraft:crying_obsidian
fill 136 155 635 136 200 635 minecraft:black_concrete
fill 94 156 612 94 161 613 minecraft:black_concrete
setblock 94 156 619 minecraft:white_concrete
fill 94 156 620 94 157 620 minecraft:black_concrete
fill 94 156 628 94 161 628 minecraft:black_concrete
fill 94 156 644 94 161 644 minecraft:black_concrete
fill 98 156 604 98 159 604 minecraft:black_concrete
setblock 98 156 646 minecraft:amethyst_block
fill 103 156 625 103 158 625 minecraft:amethyst_block
fill 108 156 646 108 161 646 minecraft:black_concrete
fill 114 156 604 114 161 604 minecraft:black_concrete
fill 117 156 604 117 167 604 minecraft:black_concrete
setblock 118 156 604 minecraft:amethyst_block
fill 119 156 604 119 175 604 minecraft:black_concrete
setblock 119 156 646 minecraft:crying_obsidian
fill 123 156 646 124 161 646 minecraft:black_concrete
fill 130 156 604 130 161 604 minecraft:black_concrete
fill 136 156 614 136 161 614 minecraft:black_concrete
setblock 136 156 621 minecraft:crying_obsidian
fill 136 156 630 136 161 630 minecraft:black_concrete
fill 94 157 619 94 193 619 minecraft:black_concrete
fill 98 157 646 98 206 646 minecraft:black_concrete
fill 118 157 604 118 206 604 minecraft:black_concrete
fill 119 157 646 119 200 646 minecraft:black_concrete
fill 136 157 621 136 203 621 minecraft:black_concrete
setblock 94 158 620 minecraft:amethyst_block
setblock 136 158 612 minecraft:amethyst_block
fill 94 159 620 94 189 620 minecraft:black_concrete
setblock 94 159 626 minecraft:white_concrete
setblock 94 159 634 minecraft:amethyst_block
setblock 97 159 607 minecraft:light[level=14]
setblock 97 159 615 minecraft:light[level=14]
setblock 97 159 623 minecraft:light[level=14]
setblock 97 159 631 minecraft:light[level=14]
setblock 97 159 639 minecraft:light[level=14]
setblock 99 159 646 minecraft:crying_obsidian
fill 102 159 625 103 164 626 minecraft:obsidian
setblock 105 159 607 minecraft:light[level=14]
setblock 105 159 615 minecraft:light[level=14]
setblock 105 159 623 minecraft:light[level=14]
setblock 105 159 631 minecraft:light[level=14]
setblock 105 159 639 minecraft:light[level=14]
setblock 113 159 607 minecraft:light[level=14]
setblock 113 159 615 minecraft:light[level=14]
setblock 113 159 623 minecraft:light[level=14]
setblock 113 159 631 minecraft:light[level=14]
setblock 113 159 639 minecraft:light[level=14]
setblock 121 159 607 minecraft:light[level=14]
setblock 121 159 615 minecraft:light[level=14]
setblock 121 159 623 minecraft:light[level=14]
setblock 121 159 631 minecraft:light[level=14]
setblock 121 159 639 minecraft:light[level=14]
setblock 129 159 607 minecraft:light[level=14]
setblock 129 159 615 minecraft:light[level=14]
setblock 129 159 623 minecraft:light[level=14]
setblock 129 159 631 minecraft:light[level=14]
setblock 129 159 639 minecraft:light[level=14]
fill 136 159 612 136 206 612 minecraft:black_concrete
fill 94 160 614 94 173 614 minecraft:black_concrete
setblock 94 160 615 minecraft:white_concrete
fill 94 160 626 94 189 626 minecraft:black_concrete
setblock 94 160 632 minecraft:white_concrete
fill 94 160 633 94 162 634 minecraft:black_concrete
setblock 97 160 646 minecraft:crying_obsidian
setblock 98 160 604 minecraft:white_concrete
fill 99 160 646 99 206 646 minecraft:black_concrete
setblock 110 160 646 minecraft:amethyst_block
setblock 128 160 646 minecraft:crying_obsidian
setblock 132 160 646 minecraft:white_concrete
setblock 136 160 623 minecraft:crying_obsidian
fill 94 161 615 94 206 615 minecraft:black_concrete
fill 94 161 632 94 203 632 minecraft:black_concrete
setblock 94 161 645 minecraft:white_concrete
fill 97 161 646 97 206 646 minecraft:black_concrete
setblock 98 161 604 minecraft:black_concrete
fill 101 161 625 101 164 626 minecraft:obsidian
fill 102 161 624 103 164 624 minecraft:obsidian
fill 102 161 627 103 164 627 minecraft:obsidian
fill 104 161 625 104 164 626 minecraft:obsidian
fill 110 161 646 110 172 646 minecraft:black_concrete
fill 120 161 604 121 161 604 minecraft:crying_obsidian
fill 128 161 646 128 169 646 minecraft:black_concrete
fill 132 161 646 132 203 646 minecraft:black_concrete
setblock 136 161 605 minecraft:crying_obsidian
fill 136 161 623 136 188 623 minecraft:black_concrete
fill 94 162 612 94 164 612 minecraft:purple_stained_glass
fill 94 162 613 94 166 613 minecraft:black_concrete
fill 94 162 628 94 164 628 minecraft:purple_stained_glass
fill 94 162 644 94 164 644 minecraft:purple_stained_glass
fill 94 162 645 94 190 645 minecraft:black_concrete
fill 98 162 604 98 164 604 minecraft:purple_stained_glass
setblock 100 162 604 minecraft:crying_obsidian
fill 101 162 624 101 164 624 minecraft:obsidian
fill 101 162 627 101 164 627 minecraft:obsidian
fill 104 162 624 104 164 624 minecraft:obsidian
fill 104 162 627 104 164 627 minecraft:obsidian
fill 108 162 646 108 164 646 minecraft:purple_stained_glass
fill 114 162 604 114 164 604 minecraft:purple_stained_glass
fill 120 162 604 121 200 604 minecraft:black_concrete
fill 123 162 646 123 173 646 minecraft:black_concrete
fill 124 162 646 124 164 646 minecraft:purple_stained_glass
fill 130 162 604 130 164 604 minecraft:purple_stained_glass
fill 136 162 605 136 206 605 minecraft:black_concrete
fill 136 162 614 136 164 614 minecraft:purple_stained_glass
fill 136 162 630 136 164 630 minecraft:purple_stained_glass
fill 94 163 633 94 171 633 minecraft:black_concrete
setblock 94 163 634 minecraft:crying_obsidian
fill 100 163 604 100 166 604 minecraft:black_concrete
fill 100 163 625 100 164 626 minecraft:obsidian
fill 102 163 623 103 164 623 minecraft:obsidian
fill 102 163 628 103 164 628 minecraft:obsidian
fill 105 163 625 105 164 626 minecraft:obsidian
setblock 94 164 608 minecraft:amethyst_block
fill 94 164 634 94 166 634 minecraft:black_concrete
setblock 100 164 624 minecraft:obsidian
setblock 100 164 627 minecraft:obsidian
setblock 101 164 623 minecraft:obsidian
setblock 101 164 628 minecraft:obsidian
setblock 102 164 646 minecraft:amethyst_block
fill 103 164 646 103 191 646 minecraft:black_concrete
setblock 104 164 623 minecraft:obsidian
setblock 104 164 628 minecraft:obsidian
setblock 105 164 624 minecraft:obsidian
setblock 105 164 627 minecraft:obsidian
setblock 110 164 604 minecraft:white_concrete
fill 94 165 608 94 179 608 minecraft:black_concrete
fill 94 165 612 94 179 612 minecraft:black_concrete
fill 94 165 628 94 179 628 minecraft:black_concrete
setblock 94 165 644 minecraft:black_concrete
fill 98 165 604 98 179 604 minecraft:black_concrete
fill 102 165 625 103 165 626 minecraft:amethyst_block
fill 102 165 646 102 193 646 minecraft:black_concrete
fill 108 165 646 108 171 646 minecraft:black_concrete
fill 110 165 604 110 206 604 minecraft:black_concrete
fill 114 165 604 114 179 604 minecraft:black_concrete
fill 124 165 646 124 179 646 minecraft:black_concrete
setblock 129 165 646 minecraft:white_concrete
fill 130 165 604 130 179 604 minecraft:black_concrete
fill 130 165 646 131 179 646 minecraft:black_concrete
fill 136 165 614 136 179 614 minecraft:black_concrete
fill 136 165 630 136 174 630 minecraft:black_concrete
setblock 94 166 644 minecraft:crying_obsidian
setblock 122 166 604 minecraft:crying_obsidian
fill 129 166 646 129 197 646 minecraft:black_concrete
setblock 131 166 604 minecraft:amethyst_block
setblock 94 167 613 minecraft:crying_obsidian
setblock 94 167 634 minecraft:amethyst_block
setblock 94 167 639 minecraft:white_concrete
fill 94 167 644 94 179 644 minecraft:black_concrete
setblock 97 167 607 minecraft:light[level=14]
setblock 97 167 615 minecraft:light[level=14]
setblock 97 167 623 minecraft:light[level=14]
setblock 97 167 631 minecraft:light[level=14]
setblock 97 167 639 minecraft:light[level=14]
setblock 100 167 604 minecraft:white_concrete
setblock 103 167 604 minecraft:amethyst_block
fill 104 167 604 106 179 604 minecraft:black_concrete
setblock 105 167 607 minecraft:light[level=14]
setblock 105 167 615 minecraft:light[level=14]
setblock 105 167 623 minecraft:light[level=14]
setblock 105 167 631 minecraft:light[level=14]
setblock 105 167 639 minecraft:light[level=14]
setblock 107 167 604 minecraft:amethyst_block
setblock 113 167 607 minecraft:light[level=14]
setblock 113 167 615 minecraft:light[level=14]
setblock 113 167 623 minecraft:light[level=14]
setblock 113 167 631 minecraft:light[level=14]
setblock 113 167 639 minecraft:light[level=14]
setblock 121 167 607 minecraft:light[level=14]
setblock 121 167 615 minecraft:light[level=14]
setblock 121 167 623 minecraft:light[level=14]
setblock 121 167 631 minecraft:light[level=14]
setblock 121 167 639 minecraft:light[level=14]
fill 122 167 604 122 204 604 minecraft:black_concrete
setblock 129 167 607 minecraft:light[level=14]
setblock 129 167 615 minecraft:light[level=14]
setblock 129 167 623 minecraft:light[level=14]
setblock 129 167 631 minecraft:light[level=14]
setblock 129 167 639 minecraft:light[level=14]
fill 131 167 604 131 171 604 minecraft:black_concrete
setblock 136 167 610 minecraft:crying_obsidian
fill 94 168 613 94 204 613 minecraft:black_concrete
setblock 94 168 631 minecraft:white_concrete
fill 94 168 634 94 202 634 minecraft:black_concrete
fill 94 168 639 94 171 639 minecraft:black_concrete
setblock 100 168 604 minecraft:amethyst_block
fill 103 168 604 103 206 604 minecraft:black_concrete
fill 106 168 646 106 206 646 minecraft:black_concrete
fill 107 168 604 107 176 604 minecraft:black_concrete
setblock 107 168 646 minecraft:white_concrete
setblock 117 168 604 minecraft:white_concrete
fill 136 168 610 136 206 610 minecraft:black_concrete
setblock 94 169 606 minecraft:white_concrete
fill 94 169 631 94 206 631 minecraft:black_concrete
fill 100 169 604 100 176 604 minecraft:black_concrete
fill 107 169 646 107 190 646 minecraft:black_concrete
setblock 111 169 604 minecraft:crying_obsidian
fill 112 169 646 113 172 646 minecraft:black_concrete
setblock 114 169 646 minecraft:crying_obsidian
fill 115 169 646 115 193 646 minecraft:black_concrete
fill 117 169 604 117 206 604 minecraft:black_concrete
setblock 136 169 638 minecraft:amethyst_block
setblock 136 169 640 minecraft:crying_obsidian
fill 94 170 606 94 206 606 minecraft:black_concrete
fill 110 170 626 112 170 628 minecraft:redstone_block
fill 111 170 604 111 190 604 minecraft:black_concrete
setblock 114 170 646 minecraft:black_concrete
fill 115 170 621 117 170 623 minecraft:redstone_block
fill 116 170 631 118 170 633 minecraft:redstone_block
fill 120 170 626 122 170 628 minecraft:redstone_block
setblock 128 170 646 minecraft:amethyst_block
setblock 134 170 646 minecraft:crying_obsidian
fill 136 170 638 136 202 638 minecraft:black_concrete
fill 136 170 640 136 206 640 minecraft:black_concrete
fill 108 171 619 109 171 635 minecraft:stone_bricks
fill 110 171 619 124 171 620 minecraft:stone_bricks
fill 110 171 621 114 171 625 minecraft:lime_stained_glass
fill 110 171 629 115 171 633 minecraft:lime_stained_glass
fill 110 171 634 124 171 635 minecraft:stone_bricks
fill 113 171 626 114 171 628 minecraft:lime_stained_glass
setblock 114 171 646 minecraft:amethyst_block
fill 115 171 624 122 171 625 minecraft:lime_stained_glass
fill 116 171 629 122 171 630 minecraft:lime_stained_glass
fill 118 171 621 122 171 623 minecraft:lime_stained_glass
fill 118 171 626 119 171 628 minecraft:lime_stained_glass
fill 119 171 631 122 171 633 minecraft:lime_stained_glass
fill 123 171 621 124 171 633 minecraft:stone_bricks
fill 128 171 646 128 206 646 minecraft:black_concrete
fill 134 171 646 134 202 646 minecraft:black_concrete
setblock 136 171 609 minecraft:white_concrete
setblock 94 172 633 minecraft:amethyst_block
setblock 94 172 639 minecraft:white_concrete
fill 95 172 605 107 172 645 minecraft:moss_block
fill 108 172 605 135 172 618 minecraft:moss_block
fill 108 172 619 108 172 621 minecraft:stone_bricks
setblock 108 172 622 minecraft:glowstone
fill 108 172 623 108 172 625 minecraft:stone_bricks
setblock 108 172 626 minecraft:glowstone
fill 108 172 627 108 172 629 minecraft:stone_bricks
setblock 108 172 630 minecraft:glowstone
fill 108 172 631 108 172 633 minecraft:stone_bricks
setblock 108 172 634 minecraft:glowstone
fill 108 172 635 110 172 635 minecraft:stone_bricks
fill 108 172 636 135 172 645 minecraft:moss_block
setblock 108 172 646 minecraft:crying_obsidian
fill 109 172 619 109 172 620 minecraft:stone_bricks
setblock 109 172 621 minecraft:glowstone
fill 109 172 622 109 172 624 minecraft:stone_bricks
fill 109 172 625 109 172 629 minecraft:crying_obsidian
fill 109 172 630 109 172 632 minecraft:stone_bricks
setblock 109 172 633 minecraft:glowstone
fill 109 172 634 111 172 634 minecraft:stone_bricks
setblock 110 172 619 minecraft:stone_bricks
setblock 110 172 620 minecraft:glowstone
fill 110 172 621 113 172 624 minecraft:lime_stained_glass
fill 110 172 625 114 172 625 minecraft:crying_obsidian
fill 110 172 626 112 172 628 minecraft:moss_block
fill 110 172 629 114 172 629 minecraft:crying_obsidian
fill 110 172 630 114 172 633 minecraft:lime_stained_glass
setblock 111 172 619 minecraft:glowstone
fill 111 172 620 113 172 620 minecraft:stone_bricks
setblock 111 172 635 minecraft:glowstone
fill 112 172 619 114 172 619 minecraft:stone_bricks
setblock 112 172 634 minecraft:glowstone
fill 112 172 635 114 172 635 minecraft:stone_bricks
fill 113 172 626 113 172 628 minecraft:crying_obsidian
fill 113 172 634 114 172 634 minecraft:stone_bricks
fill 114 172 620 114 172 624 minecraft:crying_obsidian
fill 114 172 626 114 172 628 minecraft:sea_lantern
fill 114 172 646 114 206 646 minecraft:black_concrete
setblock 115 172 619 minecraft:glowstone
fill 115 172 620 118 172 620 minecraft:crying_obsidian
fill 115 172 621 117 172 623 minecraft:moss_block
fill 115 172 624 118 172 624 minecraft:crying_obsidian
fill 115 172 625 117 172 625 minecraft:sea_lantern
fill 115 172 629 117 172 629 minecraft:sea_lantern
fill 115 172 630 115 172 634 minecraft:crying_obsidian
setblock 115 172 635 minecraft:glowstone
fill 116 172 619 118 172 619 minecraft:stone_bricks
fill 116 172 630 119 172 630 minecraft:crying_obsidian
fill 116 172 631 118 172 633 minecraft:moss_block
fill 116 172 634 119 172 634 minecraft:crying_obsidian
fill 116 172 635 118 172 635 minecraft:stone_bricks
fill 118 172 621 118 172 623 minecraft:crying_obsidian
fill 118 172 625 123 172 625 minecraft:crying_obsidian
fill 118 172 626 118 172 628 minecraft:sea_lantern
fill 118 172 629 123 172 629 minecraft:crying_obsidian
setblock 119 172 619 minecraft:glowstone
fill 119 172 620 121 172 620 minecraft:stone_bricks
fill 119 172 621 122 172 624 minecraft:lime_stained_glass
fill 119 172 626 119 172 628 minecraft:crying_obsidian
fill 119 172 631 119 172 633 minecraft:crying_obsidian
setblock 119 172 635 minecraft:glowstone
fill 120 172 619 122 172 619 minecraft:stone_bricks
fill 120 172 626 122 172 628 minecraft:moss_block
fill 120 172 630 122 172 633 minecraft:lime_stained_glass
setblock 120 172 634 minecraft:glowstone
fill 120 172 635 122 172 635 minecraft:stone_bricks
fill 121 172 634 123 172 634 minecraft:stone_bricks
setblock 122 172 620 minecraft:glowstone
setblock 123 172 619 minecraft:glowstone
fill 123 172 620 123 172 622 minecraft:stone_bricks
setblock 123 172 623 minecraft:glowstone
fill 123 172 624 124 172 624 minecraft:stone_bricks
fill 123 172 626 123 172 628 minecraft:crying_obsidian
setblock 123 172 630 minecraft:stone_bricks
setblock 123 172 631 minecraft:glowstone
fill 123 172 632 124 172 633 minecraft:stone_bricks
setblock 123 172 635 minecraft:glowstone
fill 124 172 619 124 172 621 minecraft:stone_bricks
setblock 124 172 622 minecraft:glowstone
setblock 124 172 623 minecraft:stone_bricks
setblock 124 172 625 minecraft:stone_bricks
setblock 124 172 626 minecraft:glowstone
fill 124 172 627 124 172 629 minecraft:stone_bricks
setblock 124 172 630 minecraft:glowstone
setblock 124 172 631 minecraft:stone_bricks
setblock 124 172 634 minecraft:glowstone
setblock 124 172 635 minecraft:stone_bricks
fill 125 172 619 135 172 635 minecraft:moss_block
setblock 131 172 604 minecraft:white_concrete
fill 136 172 609 136 206 609 minecraft:black_concrete
setblock 136 172 615 minecraft:amethyst_block
fill 136 172 624 136 175 624 minecraft:black_concrete
setblock 136 172 625 minecraft:amethyst_block
fill 94 173 633 94 202 633 minecraft:black_concrete
fill 94 173 639 94 202 639 minecraft:black_concrete
fill 104 173 615 114 173 639 minecraft:prismarine_bricks
fill 108 173 646 108 176 646 minecraft:black_concrete
setblock 109 173 604 minecraft:amethyst_block
setblock 110 173 646 minecraft:white_concrete
setblock 112 173 646 minecraft:crying_obsidian
fill 113 173 646 113 189 646 minecraft:black_concrete
fill 115 173 615 116 173 625 minecraft:prismarine_bricks
fill 115 173 629 128 173 639 minecraft:prismarine_bricks
fill 117 173 615 128 174 624 minecraft:prismarine_bricks
fill 118 173 625 128 174 625 minecraft:prismarine_bricks
fill 118 173 627 128 173 628 minecraft:prismarine_bricks
fill 119 173 626 128 174 626 minecraft:prismarine_bricks
fill 131 173 604 131 206 604 minecraft:black_concrete
setblock 135 173 604 minecraft:amethyst_block
setblock 136 173 606 minecraft:amethyst_block
fill 136 173 615 136 206 615 minecraft:black_concrete
fill 136 173 625 136 185 625 minecraft:black_concrete
setblock 94 174 614 minecraft:amethyst_block
fill 104 174 615 113 174 639 minecraft:prismarine_bricks
fill 109 174 604 109 175 604 minecraft:black_concrete
fill 110 174 646 110 206 646 minecraft:black_concrete
fill 112 174 646 112 176 646 minecraft:black_concrete
fill 114 174 615 114 174 626 minecraft:prismarine_bricks
fill 114 174 628 114 174 639 minecraft:prismarine_bricks
fill 115 174 615 115 174 625 minecraft:prismarine_bricks
fill 115 174 629 115 174 639 minecraft:prismarine_bricks
fill 116 174 615 116 174 624 minecraft:prismarine_bricks
fill 116 174 630 128 174 639 minecraft:prismarine_bricks
fill 117 174 629 128 174 629 minecraft:prismarine_bricks
fill 118 174 628 128 174 628 minecraft:prismarine_bricks
fill 119 174 627 128 174 627 minecraft:prismarine_bricks
setblock 123 174 646 minecraft:white_concrete
setblock 124 174 604 minecraft:amethyst_block
fill 135 174 604 135 206 604 minecraft:black_concrete
fill 136 174 606 136 206 606 minecraft:black_concrete
setblock 94 175 605 minecraft:white_concrete
fill 94 175 614 94 192 614 minecraft:black_concrete
setblock 97 175 607 minecraft:light[level=14]
setblock 97 175 615 minecraft:light[level=14]
setblock 97 175 623 minecraft:light[level=14]
setblock 97 175 631 minecraft:light[level=14]
setblock 97 175 639 minecraft:light[level=14]
setblock 105 175 607 minecraft:light[level=14]
setblock 105 175 615 minecraft:light[level=14]
fill 105 175 616 105 176 616 minecraft:sea_lantern
setblock 105 175 623 minecraft:light[level=14]
setblock 105 175 631 minecraft:light[level=14]
fill 105 175 638 105 176 638 minecraft:sea_lantern
setblock 105 175 639 minecraft:light[level=14]
fill 106 175 617 113 176 637 minecraft:dark_prismarine
setblock 113 175 607 minecraft:light[level=14]
setblock 113 175 615 minecraft:light[level=14]
setblock 113 175 639 minecraft:light[level=14]
fill 114 175 617 114 176 625 minecraft:dark_prismarine
fill 114 175 629 114 176 637 minecraft:dark_prismarine
fill 115 175 617 126 176 624 minecraft:dark_prismarine
fill 115 175 630 126 176 637 minecraft:dark_prismarine
fill 118 175 629 126 176 629 minecraft:dark_prismarine
fill 119 175 625 126 176 628 minecraft:dark_prismarine
setblock 121 175 607 minecraft:light[level=14]
setblock 121 175 615 minecraft:light[level=14]
setblock 121 175 639 minecraft:light[level=14]
fill 123 175 646 123 182 646 minecraft:black_concrete
fill 124 175 604 124 203 604 minecraft:black_concrete
fill 127 175 616 127 176 616 minecraft:sea_lantern
fill 127 175 638 127 176 638 minecraft:sea_lantern
setblock 129 175 607 minecraft:light[level=14]
setblock 129 175 615 minecraft:light[level=14]
setblock 129 175 623 minecraft:light[level=14]
setblock 129 175 631 minecraft:light[level=14]
setblock 129 175 639 minecraft:light[level=14]
setblock 136 175 630 minecraft:amethyst_block
fill 94 176 605 94 202 605 minecraft:black_concrete
fill 94 176 640 94 204 640 minecraft:black_concrete
setblock 94 176 641 minecraft:white_concrete
setblock 109 176 604 minecraft:crying_obsidian
setblock 119 176 604 minecraft:amethyst_block
setblock 136 176 624 minecraft:amethyst_block
fill 136 176 630 136 179 630 minecraft:black_concrete
setblock 94 177 618 minecraft:white_concrete
fill 94 177 641 94 180 641 minecraft:black_concrete
setblock 100 177 604 minecraft:amethyst_block
setblock 107 177 604 minecraft:crying_obsidian
fill 108 177 619 113 178 635 minecraft:prismarine_bricks
setblock 108 177 646 minecraft:white_concrete
fill 109 177 604 109 206 604 minecraft:black_concrete
setblock 112 177 646 minecraft:white_concrete
fill 114 177 619 114 178 625 minecraft:prismarine_bricks
fill 114 177 629 114 178 635 minecraft:prismarine_bricks
fill 115 177 619 124 178 624 minecraft:prismarine_bricks
fill 115 177 630 124 178 635 minecraft:prismarine_bricks
fill 118 177 629 124 178 629 minecraft:prismarine_bricks
fill 119 177 604 119 204 604 minecraft:black_concrete
fill 119 177 625 124 178 628 minecraft:prismarine_bricks
fill 136 177 624 136 206 624 minecraft:black_concrete
fill 94 178 618 94 198 618 minecraft:black_concrete
fill 100 178 604 100 196 604 minecraft:black_concrete
fill 107 178 604 107 202 604 minecraft:black_concrete
fill 108 178 646 108 179 646 minecraft:black_concrete
fill 112 178 646 112 180 646 minecraft:black_concrete
setblock 116 178 646 minecraft:crying_obsidian
setblock 121 178 646 minecraft:crying_obsidian
setblock 135 178 646 minecraft:white_concrete
setblock 136 178 619 minecraft:amethyst_block
setblock 136 178 636 minecraft:amethyst_block
fill 136 178 646 136 202 646 minecraft:black_concrete
fill 110 179 621 113 179 633 minecraft:dark_prismarine
fill 114 179 621 122 179 624 minecraft:dark_prismarine
fill 114 179 630 122 179 633 minecraft:dark_prismarine
fill 116 179 646 116 188 646 minecraft:black_concrete
fill 119 179 625 122 179 629 minecraft:dark_prismarine
fill 121 179 646 121 207 646 minecraft:black_concrete
fill 135 179 646 135 195 646 minecraft:black_concrete
fill 136 179 619 136 206 619 minecraft:black_concrete
fill 136 179 636 136 196 636 minecraft:black_concrete
setblock 94 180 608 minecraft:amethyst_block
fill 94 180 612 94 182 612 minecraft:purple_stained_glass
fill 94 180 628 94 182 628 minecraft:purple_stained_glass
setblock 94 180 629 minecraft:white_concrete
setblock 94 180 635 minecraft:amethyst_block
fill 94 180 644 94 182 644 minecraft:purple_stained_glass
fill 98 180 604 98 182 604 minecraft:purple_stained_glass
setblock 104 180 604 minecraft:white_concrete
fill 105 180 604 106 203 604 minecraft:black_concrete
fill 108 180 646 108 182 646 minecraft:purple_stained_glass
fill 110 180 621 112 180 633 minecraft:dark_prismarine
fill 113 180 621 113 180 626 minecraft:dark_prismarine
fill 113 180 628 113 180 633 minecraft:dark_prismarine
fill 114 180 604 114 182 604 minecraft:purple_stained_glass
fill 114 180 621 115 180 624 minecraft:dark_prismarine
fill 114 180 630 115 180 633 minecraft:dark_prismarine
fill 116 180 621 122 180 623 minecraft:dark_prismarine
fill 116 180 631 122 180 633 minecraft:dark_prismarine
fill 117 180 624 122 180 624 minecraft:dark_prismarine
fill 117 180 630 122 180 630 minecraft:dark_prismarine
fill 119 180 625 122 180 626 minecraft:dark_prismarine
fill 119 180 628 122 180 629 minecraft:dark_prismarine
fill 120 180 627 122 180 627 minecraft:dark_prismarine
fill 124 180 646 124 182 646 minecraft:purple_stained_glass
fill 130 180 604 130 182 604 minecraft:purple_stained_glass
setblock 130 180 646 minecraft:white_concrete
fill 131 180 646 131 206 646 minecraft:black_concrete
fill 136 180 614 136 182 614 minecraft:purple_stained_glass
fill 136 180 630 136 182 630 minecraft:purple_stained_glass
fill 94 181 608 94 206 608 minecraft:black_concrete
fill 94 181 629 94 202 629 minecraft:black_concrete
fill 94 181 635 94 206 635 minecraft:black_concrete
setblock 94 181 641 minecraft:amethyst_block
fill 104 181 604 104 198 604 minecraft:black_concrete
fill 112 181 623 112 182 631 minecraft:prismarine_bricks
setblock 112 181 646 minecraft:amethyst_block
fill 113 181 623 113 182 625 minecraft:prismarine_bricks
fill 113 181 629 113 182 631 minecraft:prismarine_bricks
fill 114 181 623 114 182 624 minecraft:prismarine_bricks
fill 114 181 630 114 182 631 minecraft:prismarine_bricks
fill 115 181 623 120 182 623 minecraft:prismarine_bricks
fill 115 181 631 120 182 631 minecraft:prismarine_bricks
fill 118 181 624 120 182 624 minecraft:prismarine_bricks
fill 118 181 630 120 182 630 minecraft:prismarine_bricks
fill 119 181 625 120 182 625 minecraft:prismarine_bricks
fill 119 181 629 120 182 629 minecraft:prismarine_bricks
fill 120 181 626 120 182 628 minecraft:prismarine_bricks
fill 130 181 646 130 206 646 minecraft:black_concrete
setblock 94 182 630 minecraft:amethyst_block
fill 94 182 641 94 203 641 minecraft:black_concrete
fill 95 182 618 95 185 618 minecraft:amethyst_block
fill 112 182 646 112 206 646 minecraft:black_concrete
fill 94 183 612 94 188 612 minecraft:black_concrete
fill 94 183 621 94 206 621 minecraft:black_concrete
setblock 94 183 622 minecraft:crying_obsidian
fill 94 183 623 94 206 623 minecraft:black_concrete
fill 94 183 628 94 188 628 minecraft:black_concrete
fill 94 183 630 94 204 630 minecraft:black_concrete
fill 94 183 644 94 188 644 minecraft:black_concrete
fill 95 183 617 96 184 617 minecraft:amethyst_block
fill 95 183 619 96 184 619 minecraft:amethyst_block
fill 96 183 618 97 185 618 minecraft:amethyst_block
setblock 97 183 607 minecraft:light[level=14]
setblock 97 183 615 minecraft:light[level=14]
setblock 97 183 623 minecraft:light[level=14]
setblock 97 183 631 minecraft:light[level=14]
setblock 97 183 639 minecraft:light[level=14]
fill 98 183 604 98 188 604 minecraft:black_concrete
setblock 105 183 607 minecraft:light[level=14]
setblock 105 183 615 minecraft:light[level=14]
setblock 105 183 623 minecraft:light[level=14]
setblock 105 183 631 minecraft:light[level=14]
setblock 105 183 639 minecraft:light[level=14]
fill 108 183 646 108 186 646 minecraft:black_concrete
setblock 113 183 607 minecraft:light[level=14]
setblock 113 183 615 minecraft:light[level=14]
setblock 113 183 623 minecraft:light[level=14]
setblock 113 183 631 minecraft:light[level=14]
setblock 113 183 639 minecraft:light[level=14]
fill 114 183 604 114 188 604 minecraft:black_concrete
setblock 121 183 607 minecraft:light[level=14]
setblock 121 183 615 minecraft:light[level=14]
setblock 121 183 623 minecraft:light[level=14]
setblock 121 183 631 minecraft:light[level=14]
setblock 121 183 639 minecraft:light[level=14]
setblock 123 183 646 minecraft:white_concrete
fill 124 183 646 124 188 646 minecraft:black_concrete
setblock 129 183 607 minecraft:light[level=14]
setblock 129 183 615 minecraft:light[level=14]
setblock 129 183 623 minecraft:light[level=14]
setblock 129 183 631 minecraft:light[level=14]
setblock 129 183 639 minecraft:light[level=14]
fill 130 183 604 130 188 604 minecraft:black_concrete
setblock 133 183 646 minecraft:amethyst_block
fill 136 183 614 136 188 614 minecraft:black_concrete
fill 136 183 630 136 188 630 minecraft:black_concrete
fill 94 184 622 94 206 622 minecraft:black_concrete
setblock 94 184 624 minecraft:crying_obsidian
setblock 97 184 617 minecraft:amethyst_block
setblock 97 184 619 minecraft:amethyst_block
fill 98 184 618 98 185 618 minecraft:amethyst_block
setblock 99 184 604 minecraft:amethyst_block
fill 123 184 646 123 202 646 minecraft:black_concrete
fill 133 184 646 133 203 646 minecraft:black_concrete
fill 94 185 624 94 206 624 minecraft:black_concrete
setblock 94 185 642 minecraft:crying_obsidian
setblock 98 185 617 minecraft:amethyst_block
setblock 98 185 619 minecraft:amethyst_block
fill 99 185 604 99 204 604 minecraft:black_concrete
fill 99 185 618 100 186 618 minecraft:amethyst_block
fill 94 186 642 94 206 642 minecraft:black_concrete
setblock 101 186 618 minecraft:amethyst_block
setblock 136 186 625 minecraft:white_concrete
setblock 94 187 625 minecraft:crying_obsidian
setblock 108 187 646 minecraft:crying_obsidian
setblock 115 187 604 minecraft:crying_obsidian
fill 136 187 625 136 203 625 minecraft:black_concrete
fill 94 188 625 94 206 625 minecraft:black_concrete
setblock 102 188 604 minecraft:white_concrete
setblock 108 188 646 minecraft:black_concrete
fill 115 188 604 115 206 604 minecraft:black_concrete
setblock 94 189 607 minecraft:white_concrete
setblock 94 189 611 minecraft:amethyst_block
fill 94 189 612 94 191 612 minecraft:purple_stained_glass
fill 94 189 628 94 191 628 minecraft:purple_stained_glass
fill 94 189 644 94 191 644 minecraft:purple_stained_glass
fill 98 189 604 98 191 604 minecraft:purple_stained_glass
fill 102 189 604 102 200 604 minecraft:black_concrete
fill 108 189 646 108 191 646 minecraft:purple_stained_glass
fill 114 189 604 114 191 604 minecraft:purple_stained_glass
setblock 116 189 646 minecraft:white_concrete
fill 124 189 646 124 191 646 minecraft:purple_stained_glass
fill 130 189 604 130 191 604 minecraft:purple_stained_glass
fill 136 189 614 136 191 614 minecraft:purple_stained_glass
setblock 136 189 623 minecraft:white_concrete
fill 136 189 630 136 191 630 minecraft:purple_stained_glass
setblock 136 189 639 minecraft:amethyst_block
fill 94 190 607 94 206 607 minecraft:black_concrete
fill 94 190 611 94 204 611 minecraft:black_concrete
setblock 94 190 620 minecraft:amethyst_block
setblock 94 190 626 minecraft:crying_obsidian
fill 113 190 646 113 191 646 minecraft:crying_obsidian
fill 116 190 646 116 206 646 minecraft:black_concrete
setblock 136 190 617 minecraft:crying_obsidian
fill 136 190 623 136 206 623 minecraft:black_concrete
setblock 136 190 629 minecraft:amethyst_block
fill 136 190 639 136 201 639 minecraft:black_concrete
fill 94 191 620 94 206 620 minecraft:black_concrete
fill 94 191 626 94 202 626 minecraft:black_concrete
setblock 94 191 645 minecraft:amethyst_block
setblock 97 191 607 minecraft:light[level=14]
setblock 97 191 615 minecraft:light[level=14]
setblock 97 191 623 minecraft:light[level=14]
setblock 97 191 631 minecraft:light[level=14]
setblock 97 191 639 minecraft:light[level=14]
setblock 105 191 607 minecraft:light[level=14]
setblock 105 191 615 minecraft:light[level=14]
setblock 105 191 623 minecraft:light[level=14]
setblock 105 191 631 minecraft:light[level=14]
setblock 105 191 639 minecraft:light[level=14]
fill 107 191 632 107 192 632 minecraft:obsidian
setblock 107 191 646 minecraft:white_concrete
setblock 111 191 604 minecraft:white_concrete
setblock 113 191 607 minecraft:light[level=14]
setblock 113 191 615 minecraft:light[level=14]
setblock 113 191 623 minecraft:light[level=14]
setblock 113 191 631 minecraft:light[level=14]
setblock 113 191 639 minecraft:light[level=14]
setblock 121 191 607 minecraft:light[level=14]
setblock 121 191 615 minecraft:light[level=14]
setblock 121 191 623 minecraft:light[level=14]
setblock 121 191 631 minecraft:light[level=14]
setblock 121 191 639 minecraft:light[level=14]
setblock 129 191 607 minecraft:light[level=14]
setblock 129 191 615 minecraft:light[level=14]
setblock 129 191 623 minecraft:light[level=14]
setblock 129 191 631 minecraft:light[level=14]
setblock 129 191 639 minecraft:light[level=14]
fill 136 191 617 136 206 617 minecraft:black_concrete
fill 136 191 629 136 206 629 minecraft:black_concrete
setblock 94 192 610 minecraft:amethyst_block
fill 94 192 612 94 197 612 minecraft:black_concrete
fill 94 192 628 94 197 628 minecraft:black_concrete
fill 94 192 644 94 197 645 minecraft:black_concrete
fill 98 192 604 98 197 604 minecraft:black_concrete
setblock 103 192 646 minecraft:crying_obsidian
fill 107 192 646 108 197 646 minecraft:black_concrete
fill 111 192 604 111 206 604 minecraft:black_concrete
fill 113 192 646 113 198 646 minecraft:black_concrete
fill 114 192 604 114 197 604 minecraft:black_concrete
fill 117 192 641 117 193 641 minecraft:netherrack
fill 124 192 646 124 196 646 minecraft:black_concrete
setblock 125 192 646 minecraft:white_concrete
setblock 130 192 604 minecraft:amethyst_block
fill 136 192 614 136 197 614 minecraft:black_concrete
fill 136 192 630 136 197 630 minecraft:black_concrete
fill 136 192 641 136 193 642 minecraft:black_concrete
setblock 136 192 643 minecraft:white_concrete
fill 94 193 610 94 206 610 minecraft:black_concrete
setblock 94 193 614 minecraft:white_concrete
fill 103 193 646 103 206 646 minecraft:black_concrete
fill 125 193 646 125 203 646 minecraft:black_concrete
fill 130 193 604 130 197 604 minecraft:black_concrete
fill 136 193 643 136 206 643 minecraft:black_concrete
fill 94 194 614 94 202 614 minecraft:black_concrete
setblock 94 194 619 minecraft:white_concrete
setblock 102 194 646 minecraft:amethyst_block
fill 109 194 646 109 195 646 minecraft:white_concrete
setblock 115 194 646 minecraft:white_concrete
setblock 136 194 622 minecraft:amethyst_block
fill 136 194 641 136 204 641 minecraft:black_concrete
setblock 136 194 642 minecraft:amethyst_block
fill 94 195 619 94 202 619 minecraft:black_concrete
setblock 102 195 646 minecraft:white_concrete
fill 115 195 646 115 206 646 minecraft:black_concrete
fill 136 195 622 136 204 622 minecraft:black_concrete
fill 136 195 642 136 206 642 minecraft:black_concrete
fill 102 196 646 102 206 646 minecraft:black_concrete
fill 109 196 646 109 207 646 minecraft:black_concrete
setblock 135 196 646 minecraft:amethyst_block
setblock 100 197 604 minecraft:amethyst_block
setblock 124 197 646 minecraft:white_concrete
fill 135 197 646 135 206 646 minecraft:black_concrete
setblock 136 197 636 minecraft:white_concrete
fill 94 198 612 94 200 612 minecraft:purple_stained_glass
fill 94 198 628 94 200 628 minecraft:purple_stained_glass
fill 94 198 644 94 200 644 minecraft:purple_stained_glass
fill 94 198 645 94 200 645 minecraft:black_concrete
setblock 95 198 604 minecraft:amethyst_block
fill 98 198 604 98 200 604 minecraft:purple_stained_glass
fill 100 198 604 100 206 604 minecraft:black_concrete
fill 107 198 646 107 204 646 minecraft:black_concrete
fill 108 198 646 108 200 646 minecraft:purple_stained_glass
fill 114 198 604 114 200 604 minecraft:purple_stained_glass
fill 124 198 646 124 200 646 minecraft:purple_stained_glass
setblock 129 198 646 minecraft:crying_obsidian
fill 130 198 604 130 200 604 minecraft:purple_stained_glass
fill 136 198 614 136 200 614 minecraft:purple_stained_glass
fill 136 198 630 136 200 630 minecraft:purple_stained_glass
fill 136 198 636 136 199 636 minecraft:black_concrete
setblock 94 199 618 minecraft:white_concrete
fill 95 199 604 95 206 604 minecraft:black_concrete
setblock 97 199 607 minecraft:light[level=14]
setblock 97 199 615 minecraft:light[level=14]
setblock 97 199 623 minecraft:light[level=14]
setblock 97 199 631 minecraft:light[level=14]
setblock 97 199 639 minecraft:light[level=14]
setblock 104 199 604 minecraft:amethyst_block
setblock 105 199 607 minecraft:light[level=14]
setblock 105 199 615 minecraft:light[level=14]
setblock 105 199 623 minecraft:light[level=14]
setblock 105 199 631 minecraft:light[level=14]
setblock 105 199 639 minecraft:light[level=14]
setblock 111 199 646 minecraft:crying_obsidian
setblock 113 199 607 minecraft:light[level=14]
setblock 113 199 615 minecraft:light[level=14]
setblock 113 199 623 minecraft:light[level=14]
setblock 113 199 631 minecraft:light[level=14]
setblock 113 199 639 minecraft:light[level=14]
setblock 113 199 646 minecraft:white_concrete
setblock 121 199 607 minecraft:light[level=14]
setblock 121 199 615 minecraft:light[level=14]
setblock 121 199 623 minecraft:light[level=14]
setblock 121 199 631 minecraft:light[level=14]
setblock 121 199 639 minecraft:light[level=14]
setblock 129 199 607 minecraft:light[level=14]
setblock 129 199 615 minecraft:light[level=14]
setblock 129 199 623 minecraft:light[level=14]
setblock 129 199 631 minecraft:light[level=14]
setblock 129 199 639 minecraft:light[level=14]
fill 129 199 646 129 205 646 minecraft:black_concrete
fill 94 200 618 94 206 618 minecraft:black_concrete
fill 104 200 604 104 204 604 minecraft:black_concrete
fill 111 200 646 111 203 646 minecraft:black_concrete
fill 113 200 646 113 202 646 minecraft:black_concrete
setblock 136 200 616 minecraft:amethyst_block
setblock 136 200 636 minecraft:crying_obsidian
setblock 136 200 644 minecraft:white_concrete
fill 94 201 612 94 206 612 minecraft:black_concrete
fill 94 201 628 94 204 628 minecraft:black_concrete
fill 94 201 644 94 203 644 minecraft:black_concrete
setblock 94 201 645 minecraft:crying_obsidian
fill 98 201 604 98 206 604 minecraft:black_concrete
setblock 102 201 604 minecraft:white_concrete
fill 108 201 646 108 206 646 minecraft:black_concrete
setblock 114 201 604 minecraft:white_concrete
setblock 119 201 646 minecraft:white_concrete
fill 120 201 604 120 207 604 minecraft:black_concrete
setblock 121 201 604 minecraft:crying_obsidian
fill 124 201 646 124 203 646 minecraft:black_concrete
fill 130 201 604 130 206 604 minecraft:black_concrete
fill 132 201 632 135 204 632 minecraft:amethyst_block
fill 133 201 631 135 204 631 minecraft:amethyst_block
fill 133 201 633 135 204 633 minecraft:amethyst_block
fill 136 201 614 136 202 614 minecraft:black_concrete
fill 136 201 616 136 206 616 minecraft:black_concrete
fill 136 201 630 136 206 630 minecraft:black_concrete
setblock 136 201 635 minecraft:white_concrete
fill 136 201 636 136 202 636 minecraft:black_concrete
fill 136 201 644 136 204 644 minecraft:black_concrete
setblock 94 202 645 minecraft:black_concrete
fill 102 202 604 102 206 604 minecraft:black_concrete
fill 114 202 604 114 206 604 minecraft:black_concrete
fill 119 202 646 119 206 646 minecraft:black_concrete
fill 121 202 604 121 207 604 minecraft:black_concrete
setblock 122 202 646 minecraft:amethyst_block
fill 128 202 632 131 202 632 minecraft:amethyst_block
fill 130 202 631 132 202 631 minecraft:amethyst_block
fill 130 202 633 132 202 633 minecraft:amethyst_block
fill 134 202 630 134 203 630 minecraft:amethyst_block
fill 134 202 634 134 203 634 minecraft:amethyst_block
setblock 136 202 618 minecraft:white_concrete
fill 136 202 635 136 207 635 minecraft:black_concrete
setblock 136 202 639 minecraft:white_concrete
setblock 94 203 605 minecraft:obsidian
setblock 94 203 614 minecraft:obsidian
setblock 94 203 619 minecraft:obsidian
setblock 94 203 626 minecraft:obsidian
setblock 94 203 629 minecraft:obsidian
fill 94 203 633 94 203 634 minecraft:obsidian
setblock 94 203 639 minecraft:obsidian
setblock 94 203 645 minecraft:obsidian
setblock 107 203 604 minecraft:obsidian
fill 107 203 637 107 204 637 minecraft:amethyst_block
setblock 112 203 604 minecraft:obsidian
setblock 113 203 646 minecraft:obsidian
fill 122 203 646 122 206 646 minecraft:black_concrete
setblock 123 203 646 minecraft:obsidian
fill 130 203 632 131 203 632 minecraft:amethyst_block
fill 131 203 631 132 203 631 minecraft:amethyst_block
fill 131 203 633 132 203 633 minecraft:amethyst_block
setblock 134 203 646 minecraft:obsidian
setblock 136 203 614 minecraft:crying_obsidian
fill 136 203 618 136 206 618 minecraft:black_concrete
setblock 136 203 634 minecraft:obsidian
fill 136 203 636 136 204 636 minecraft:obsidian
fill 136 203 638 136 203 639 minecraft:obsidian
setblock 136 203 646 minecraft:obsidian
fill 94 204 605 94 206 605 minecraft:black_concrete
fill 94 204 614 94 206 614 minecraft:black_concrete
setblock 94 204 616 minecraft:obsidian
fill 94 204 619 94 206 619 minecraft:black_concrete
setblock 94 204 626 minecraft:black_concrete
setblock 94 204 629 minecraft:black_concrete
fill 94 204 632 94 205 632 minecraft:obsidian
fill 94 204 633 94 206 634 minecraft:black_concrete
setblock 94 204 637 minecraft:obsidian
fill 94 204 638 94 206 639 minecraft:black_concrete
setblock 94 204 641 minecraft:amethyst_block
setblock 94 204 644 minecraft:obsidian
fill 94 204 645 94 206 645 minecraft:black_concrete
fill 100 204 646 101 204 646 minecraft:obsidian
fill 105 204 604 105 205 604 minecraft:obsidian
fill 106 204 604 107 206 604 minecraft:black_concrete
setblock 108 204 604 minecraft:obsidian
setblock 111 204 646 minecraft:obsidian
fill 112 204 604 112 206 604 minecraft:black_concrete
fill 113 204 646 113 206 646 minecraft:black_concrete
setblock 116 204 604 minecraft:obsidian
fill 123 204 646 123 206 646 minecraft:black_concrete
setblock 124 204 604 minecraft:obsidian
fill 124 204 646 125 204 646 minecraft:obsidian
setblock 127 204 646 minecraft:obsidian
setblock 132 204 646 minecraft:white_concrete
setblock 133 204 646 minecraft:obsidian
fill 134 204 646 134 206 646 minecraft:black_concrete
fill 136 204 614 136 206 614 minecraft:black_concrete
setblock 136 204 621 minecraft:crying_obsidian
setblock 136 204 625 minecraft:obsidian
fill 136 204 627 136 205 627 minecraft:obsidian
fill 136 204 634 136 206 634 minecraft:black_concrete
fill 136 204 638 136 206 639 minecraft:black_concrete
fill 136 204 646 136 206 646 minecraft:black_concrete
setblock 94 205 611 minecraft:obsidian
setblock 94 205 613 minecraft:obsidian
fill 94 205 616 94 206 616 minecraft:black_concrete
setblock 94 205 617 minecraft:obsidian
setblock 94 205 626 minecraft:crying_obsidian
fill 94 205 628 94 205 630 minecraft:obsidian
fill 94 205 637 94 206 637 minecraft:black_concrete
setblock 94 205 640 minecraft:obsidian
fill 94 205 641 94 206 641 minecraft:black_concrete
fill 94 205 644 94 206 644 minecraft:black_concrete
setblock 99 205 604 minecraft:obsidian
setblock 100 205 646 minecraft:obsidian
fill 101 205 646 101 206 646 minecraft:black_concrete
setblock 104 205 604 minecraft:obsidian
fill 107 205 637 107 213 637 minecraft:obsidian
setblock 107 205 646 minecraft:obsidian
fill 108 205 604 108 206 604 minecraft:black_concrete
fill 111 205 646 111 206 646 minecraft:black_concrete
setblock 113 205 604 minecraft:obsidian
fill 116 205 604 116 206 604 minecraft:black_concrete
setblock 119 205 604 minecraft:obsidian
setblock 120 205 646 minecraft:obsidian
setblock 122 205 604 minecraft:amethyst_block
fill 124 205 604 124 206 604 minecraft:black_concrete
fill 124 205 646 125 206 646 minecraft:black_concrete
fill 127 205 646 127 206 646 minecraft:black_concrete
fill 132 205 646 133 206 646 minecraft:black_concrete
setblock 136 205 607 minecraft:obsidian
setblock 136 205 613 minecraft:obsidian
fill 136 205 621 136 206 621 minecraft:black_concrete
setblock 136 205 622 minecraft:obsidian
fill 136 205 625 136 206 625 minecraft:black_concrete
setblock 136 205 628 minecraft:obsidian
fill 136 205 636 136 206 636 minecraft:black_concrete
setblock 136 205 641 minecraft:obsidian
fill 136 205 644 136 205 645 minecraft:obsidian
setblock 94 206 611 minecraft:black_concrete
setblock 94 206 613 minecraft:black_concrete
setblock 94 206 617 minecraft:black_concrete
setblock 94 206 626 minecraft:black_concrete
fill 94 206 628 94 206 630 minecraft:black_concrete
setblock 94 206 632 minecraft:black_concrete
fill 94 206 640 94 207 640 minecraft:black_concrete
fill 99 206 604 99 207 604 minecraft:black_concrete
setblock 100 206 646 minecraft:black_concrete
fill 104 206 604 105 206 604 minecraft:black_concrete
setblock 107 206 646 minecraft:black_concrete
fill 108 206 637 108 213 637 minecraft:obsidian
setblock 113 206 604 minecraft:black_concrete
setblock 119 206 604 minecraft:black_concrete
setblock 120 206 646 minecraft:black_concrete
setblock 122 206 604 minecraft:black_concrete
setblock 123 206 604 minecraft:crying_obsidian
setblock 129 206 646 minecraft:amethyst_block
fill 136 206 607 136 207 607 minecraft:black_concrete
setblock 136 206 613 minecraft:black_concrete
setblock 136 206 622 minecraft:black_concrete
fill 136 206 627 136 206 628 minecraft:black_concrete
setblock 136 206 641 minecraft:black_concrete
fill 136 206 644 136 206 645 minecraft:black_concrete
fill 94 207 605 94 207 611 minecraft:obsidian
fill 94 207 612 94 209 612 minecraft:purple_stained_glass
fill 94 207 613 94 207 627 minecraft:obsidian
fill 94 207 628 94 209 628 minecraft:purple_stained_glass
fill 94 207 629 94 207 630 minecraft:obsidian
setblock 94 207 631 minecraft:amethyst_block
fill 94 207 632 94 212 635 minecraft:obsidian
fill 94 207 637 94 245 637 minecraft:obsidian
setblock 94 207 638 minecraft:black_concrete
fill 94 207 639 94 224 639 minecraft:obsidian
fill 94 207 641 94 207 643 minecraft:obsidian
fill 94 207 644 94 209 644 minecraft:purple_stained_glass
fill 94 207 645 94 290 646 minecraft:obsidian
fill 95 207 604 95 241 604 minecraft:obsidian
fill 95 207 646 107 208 646 minecraft:obsidian
fill 97 207 604 97 233 604 minecraft:obsidian
setblock 97 207 607 minecraft:light[level=14]
setblock 97 207 615 minecraft:light[level=14]
setblock 97 207 623 minecraft:light[level=14]
setblock 97 207 631 minecraft:light[level=14]
setblock 97 207 639 minecraft:light[level=14]
fill 98 207 604 98 209 604 minecraft:purple_stained_glass
fill 100 207 604 113 208 604 minecraft:obsidian
setblock 105 207 607 minecraft:light[level=14]
setblock 105 207 615 minecraft:light[level=14]
setblock 105 207 623 minecraft:light[level=14]
setblock 105 207 631 minecraft:light[level=14]
setblock 105 207 639 minecraft:light[level=14]
fill 106 207 637 106 213 637 minecraft:obsidian
fill 107 207 636 108 213 636 minecraft:obsidian
fill 107 207 638 108 213 638 minecraft:obsidian
fill 108 207 646 108 209 646 minecraft:purple_stained_glass
fill 110 207 646 120 207 646 minecraft:obsidian
setblock 113 207 607 minecraft:light[level=14]
setblock 113 207 615 minecraft:light[level=14]
setblock 113 207 623 minecraft:light[level=14]
setblock 113 207 631 minecraft:light[level=14]
setblock 113 207 639 minecraft:light[level=14]
fill 114 207 604 114 209 604 minecraft:purple_stained_glass
fill 115 207 604 119 207 604 minecraft:obsidian
setblock 121 207 607 minecraft:light[level=14]
setblock 121 207 615 minecraft:light[level=14]
setblock 121 207 623 minecraft:light[level=14]
setblock 121 207 631 minecraft:light[level=14]
setblock 121 207 639 minecraft:light[level=14]
fill 122 207 604 124 221 604 minecraft:obsidian
fill 122 207 646 123 207 646 minecraft:obsidian
fill 124 207 646 124 209 646 minecraft:purple_stained_glass
fill 125 207 646 136 207 646 minecraft:obsidian
fill 126 207 604 129 209 604 minecraft:obsidian
setblock 129 207 607 minecraft:light[level=14]
setblock 129 207 615 minecraft:light[level=14]
setblock 129 207 623 minecraft:light[level=14]
setblock 129 207 631 minecraft:light[level=14]
setblock 129 207 639 minecraft:light[level=14]
fill 130 207 604 130 209 604 minecraft:purple_stained_glass
fill 131 207 604 136 207 604 minecraft:obsidian
fill 136 207 605 136 219 606 minecraft:obsidian
fill 136 207 608 136 207 613 minecraft:obsidian
fill 136 207 614 136 209 614 minecraft:purple_stained_glass
fill 136 207 615 136 207 629 minecraft:obsidian
fill 136 207 630 136 209 630 minecraft:purple_stained_glass
fill 136 207 631 136 208 634 minecraft:obsidian
fill 136 207 636 136 254 638 minecraft:obsidian
setblock 136 207 639 minecraft:black_concrete
fill 136 207 640 136 207 643 minecraft:obsidian
setblock 136 207 644 minecraft:black_concrete
fill 136 207 645 136 284 645 minecraft:obsidian
fill 94 208 604 94 208 608 minecraft:obsidian
setblock 94 208 609 minecraft:black_concrete
fill 94 208 610 94 216 611 minecraft:obsidian
fill 94 208 613 94 246 613 minecraft:obsidian
setblock 94 208 614 minecraft:black_concrete
fill 94 208 615 94 208 619 minecraft:obsidian
setblock 94 208 620 minecraft:black_concrete
fill 94 208 621 94 208 627 minecraft:obsidian
fill 94 208 629 94 238 629 minecraft:obsidian
setblock 94 208 630 minecraft:black_concrete
fill 94 208 631 94 243 631 minecraft:obsidian
fill 94 208 638 94 244 638 minecraft:obsidian
fill 94 208 640 94 307 640 minecraft:obsidian
setblock 94 208 641 minecraft:black_concrete
fill 94 208 642 94 208 643 minecraft:obsidian
fill 96 208 604 96 227 604 minecraft:obsidian
fill 99 208 604 99 307 604 minecraft:obsidian
fill 106 208 636 106 213 636 minecraft:obsidian
fill 106 208 638 106 213 638 minecraft:obsidian
fill 109 208 637 109 213 637 minecraft:obsidian
fill 109 208 646 112 209 646 minecraft:obsidian
setblock 113 208 646 minecraft:black_concrete
fill 114 208 646 116 208 646 minecraft:obsidian
fill 115 208 604 118 208 604 minecraft:obsidian
fill 117 208 646 118 208 646 minecraft:black_concrete
setblock 119 208 604 minecraft:black_concrete
fill 119 208 646 121 208 646 minecraft:obsidian
fill 120 208 604 121 215 604 minecraft:obsidian
setblock 122 208 646 minecraft:amethyst_block
setblock 123 208 646 minecraft:obsidian
fill 125 208 604 125 221 604 minecraft:obsidian
fill 125 208 646 135 208 646 minecraft:obsidian
fill 131 208 604 131 246 604 minecraft:obsidian
setblock 132 208 604 minecraft:black_concrete
fill 133 208 604 136 211 604 minecraft:obsidian
fill 136 208 607 136 256 607 minecraft:obsidian
setblock 136 208 608 minecraft:black_concrete
fill 136 208 609 136 208 613 minecraft:obsidian
fill 136 208 615 136 238 615 minecraft:obsidian
fill 136 208 616 136 208 617 minecraft:black_concrete
fill 136 208 618 136 238 621 minecraft:obsidian
fill 136 208 622 136 208 623 minecraft:black_concrete
fill 136 208 624 136 210 626 minecraft:obsidian
setblock 136 208 627 minecraft:crying_obsidian
fill 136 208 628 136 225 629 minecraft:obsidian
fill 136 208 635 136 220 635 minecraft:obsidian
fill 136 208 639 136 208 640 minecraft:obsidian
fill 136 208 641 136 208 642 minecraft:black_concrete
fill 136 208 643 136 215 644 minecraft:obsidian
fill 136 208 646 136 209 646 minecraft:black_concrete
fill 94 209 604 94 240 606 minecraft:obsidian
setblock 94 209 607 minecraft:black_concrete
fill 94 209 608 94 275 608 minecraft:obsidian
setblock 94 209 609 minecraft:white_concrete
fill 94 209 614 94 221 616 minecraft:obsidian
setblock 94 209 617 minecraft:black_concrete
fill 94 209 618 94 234 618 minecraft:obsidian
setblock 94 209 619 minecraft:black_concrete
fill 94 209 620 94 221 624 minecraft:obsidian
setblock 94 209 625 minecraft:black_concrete
fill 94 209 626 94 214 627 minecraft:obsidian
fill 94 209 630 94 306 630 minecraft:obsidian
fill 94 209 636 94 245 636 minecraft:obsidian
fill 94 209 641 94 248 641 minecraft:obsidian
setblock 94 209 642 minecraft:black_concrete
fill 94 209 643 94 228 643 minecraft:obsidian
fill 95 209 646 105 212 646 minecraft:obsidian
fill 100 209 604 110 211 604 minecraft:obsidian
fill 100 209 626 101 210 626 minecraft:netherrack
fill 105 209 637 105 213 637 minecraft:obsidian
fill 106 209 639 108 213 639 minecraft:obsidian
setblock 106 209 646 minecraft:crying_obsidian
fill 107 209 635 108 213 635 minecraft:obsidian
fill 107 209 646 107 259 646 minecraft:obsidian
fill 109 209 636 109 213 636 minecraft:obsidian
fill 109 209 638 109 213 638 minecraft:obsidian
setblock 111 209 604 minecraft:black_concrete
fill 112 209 604 113 210 604 minecraft:obsidian
fill 113 209 646 114 213 646 minecraft:obsidian
fill 115 209 604 116 262 604 minecraft:obsidian
setblock 115 209 646 minecraft:black_concrete
fill 116 209 646 118 226 646 minecraft:obsidian
setblock 117 209 604 minecraft:black_concrete
fill 118 209 604 119 227 604 minecraft:obsidian
fill 119 209 646 120 209 646 minecraft:black_concrete
fill 121 209 646 122 215 646 minecraft:obsidian
setblock 123 209 646 minecraft:black_concrete
fill 125 209 646 125 240 646 minecraft:obsidian
setblock 126 209 646 minecraft:black_concrete
fill 127 209 646 127 212 646 minecraft:obsidian
setblock 128 209 646 minecraft:black_concrete
fill 129 209 646 135 217 646 minecraft:obsidian
fill 132 209 604 132 238 604 minecraft:obsidian
fill 136 209 608 136 213 612 minecraft:obsidian
setblock 136 209 613 minecraft:black_concrete
setblock 136 209 616 minecraft:black_concrete
fill 136 209 617 136 216 617 minecraft:obsidian
fill 136 209 622 136 239 623 minecraft:obsidian
fill 136 209 627 136 246 627 minecraft:obsidian
fill 136 209 631 136 220 633 minecraft:obsidian
setblock 136 209 634 minecraft:black_concrete
setblock 136 209 639 minecraft:black_concrete
fill 136 209 640 136 214 642 minecraft:obsidian
fill 94 210 607 94 292 607 minecraft:obsidian
fill 94 210 609 94 276 609 minecraft:obsidian
fill 94 210 612 94 215 612 minecraft:obsidian
fill 94 210 617 94 245 617 minecraft:obsidian
fill 94 210 619 94 302 619 minecraft:obsidian
fill 94 210 625 94 226 625 minecraft:obsidian
fill 94 210 628 94 215 628 minecraft:obsidian
fill 94 210 642 94 250 642 minecraft:obsidian
fill 94 210 644 94 215 644 minecraft:obsidian
fill 98 210 604 98 215 604 minecraft:obsidian
fill 105 210 636 105 213 636 minecraft:obsidian
fill 105 210 638 105 213 638 minecraft:obsidian
fill 106 210 635 106 213 635 minecraft:obsidian
fill 106 210 646 106 307 646 minecraft:obsidian
setblock 108 210 646 minecraft:amethyst_block
fill 109 210 635 109 213 635 minecraft:obsidian
fill 109 210 639 109 213 639 minecraft:obsidian
fill 109 210 646 111 218 646 minecraft:obsidian
fill 110 210 636 110 213 638 minecraft:obsidian
fill 111 210 604 111 263 604 minecraft:obsidian
setblock 112 210 646 minecraft:amethyst_block
fill 114 210 604 114 215 604 minecraft:obsidian
fill 115 210 646 115 258 646 minecraft:obsidian
fill 117 210 604 117 269 604 minecraft:obsidian
fill 119 210 646 120 216 646 minecraft:obsidian
fill 123 210 646 124 215 646 minecraft:obsidian
fill 126 210 604 127 241 604 minecraft:obsidian
fill 126 210 646 126 261 646 minecraft:obsidian
setblock 128 210 604 minecraft:crying_obsidian
fill 128 210 646 128 307 646 minecraft:obsidian
fill 129 210 604 130 215 604 minecraft:obsidian
fill 136 210 613 136 211 614 minecraft:obsidian
fill 136 210 616 136 242 616 minecraft:obsidian
fill 136 210 630 136 215 630 minecraft:obsidian
fill 136 210 634 136 307 634 minecraft:obsidian
fill 136 210 639 136 251 639 minecraft:obsidian
fill 136 210 646 136 307 646 minecraft:obsidian
fill 104 211 637 104 213 637 minecraft:obsidian
fill 105 211 635 105 213 635 minecraft:obsidian
fill 105 211 639 105 213 639 minecraft:obsidian
fill 106 211 634 108 213 634 minecraft:obsidian
fill 106 211 640 108 213 640 minecraft:obsidian
fill 108 211 646 108 215 646 minecraft:obsidian
fill 110 211 635 110 213 635 minecraft:obsidian
fill 110 211 639 110 213 639 minecraft:obsidian
fill 112 211 604 112 235 604 minecraft:obsidian
fill 112 211 646 112 255 646 minecraft:obsidian
setblock 113 211 604 minecraft:amethyst_block
fill 128 211 604 128 254 604 minecraft:obsidian
fill 136 211 624 136 248 625 minecraft:obsidian
setblock 136 211 626 minecraft:white_concrete
setblock 100 212 604 minecraft:white_concrete
fill 101 212 604 110 215 604 minecraft:obsidian
fill 104 212 636 104 213 636 minecraft:obsidian
fill 104 212 638 104 213 638 minecraft:obsidian
fill 105 212 634 105 213 634 minecraft:obsidian
fill 105 212 640 105 213 640 minecraft:obsidian
fill 109 212 634 109 213 634 minecraft:obsidian
fill 109 212 640 109 213 640 minecraft:obsidian
fill 111 212 636 111 213 638 minecraft:obsidian
setblock 113 212 604 minecraft:obsidian
fill 133 212 604 134 244 604 minecraft:obsidian
setblock 135 212 604 minecraft:amethyst_block
fill 136 212 604 136 307 604 minecraft:obsidian
setblock 136 212 613 minecraft:white_concrete
fill 136 212 614 136 215 614 minecraft:obsidian
fill 136 212 626 136 216 626 minecraft:obsidian
fill 94 213 632 94 263 633 minecraft:obsidian
setblock 94 213 634 minecraft:crying_obsidian
fill 94 213 635 94 220 635 minecraft:obsidian
fill 95 213 646 101 215 646 minecraft:obsidian
fill 100 213 604 100 307 604 minecraft:obsidian
setblock 102 213 646 minecraft:white_concrete
fill 103 213 646 105 214 646 minecraft:obsidian
setblock 104 213 635 minecraft:obsidian
setblock 104 213 639 minecraft:obsidian
fill 106 213 633 108 213 633 minecraft:obsidian
fill 106 213 641 109 213 641 minecraft:obsidian
setblock 110 213 634 minecraft:obsidian
setblock 110 213 640 minecraft:obsidian
setblock 111 213 635 minecraft:obsidian
setblock 111 213 639 minecraft:obsidian
setblock 113 213 604 minecraft:white_concrete
setblock 127 213 646 minecraft:white_concrete
fill 135 213 604 135 237 604 minecraft:obsidian
fill 136 213 613 136 307 613 minecraft:obsidian
fill 94 214 634 94 233 634 minecraft:obsidian
fill 102 214 646 102 237 646 minecraft:obsidian
fill 107 214 636 108 214 638 minecraft:amethyst_block
fill 113 214 604 113 228 604 minecraft:obsidian
setblock 113 214 646 minecraft:white_concrete
fill 114 214 646 114 227 646 minecraft:obsidian
fill 127 214 646 127 216 646 minecraft:obsidian
fill 136 214 608 136 214 611 minecraft:obsidian
setblock 136 214 612 minecraft:white_concrete
fill 94 215 626 94 288 626 minecraft:obsidian
setblock 94 215 627 minecraft:amethyst_block
setblock 97 215 607 minecraft:light[level=14]
setblock 97 215 615 minecraft:light[level=14]
setblock 97 215 623 minecraft:light[level=14]
setblock 97 215 631 minecraft:light[level=14]
setblock 97 215 639 minecraft:light[level=14]
setblock 103 215 646 minecraft:amethyst_block
fill 104 215 646 105 220 646 minecraft:obsidian
setblock 105 215 607 minecraft:light[level=14]
setblock 105 215 615 minecraft:light[level=14]
setblock 105 215 623 minecraft:light[level=14]
setblock 105 215 631 minecraft:light[level=14]
setblock 105 215 639 minecraft:light[level=14]
fill 107 215 637 107 215 638 minecraft:amethyst_block
fill 108 215 637 108 216 637 minecraft:amethyst_block
setblock 113 215 607 minecraft:light[level=14]
setblock 113 215 615 minecraft:light[level=14]
setblock 113 215 623 minecraft:light[level=14]
setblock 113 215 631 minecraft:light[level=14]
setblock 113 215 639 minecraft:light[level=14]
fill 113 215 646 113 249 646 minecraft:obsidian
setblock 121 215 607 minecraft:light[level=14]
setblock 121 215 615 minecraft:light[level=14]
setblock 121 215 623 minecraft:light[level=14]
setblock 121 215 631 minecraft:light[level=14]
setblock 121 215 639 minecraft:light[level=14]
setblock 129 215 607 minecraft:light[level=14]
setblock 129 215 615 minecraft:light[level=14]
setblock 129 215 623 minecraft:light[level=14]
setblock 129 215 631 minecraft:light[level=14]
setblock 129 215 639 minecraft:light[level=14]
fill 136 215 608 136 222 609 minecraft:obsidian
setblock 136 215 610 minecraft:crying_obsidian
fill 136 215 611 136 218 612 minecraft:obsidian
fill 136 215 640 136 232 640 minecraft:obsidian
setblock 136 215 641 minecraft:amethyst_block
fill 136 215 642 136 307 642 minecraft:obsidian
fill 94 216 612 94 218 612 minecraft:purple_stained_glass
fill 94 216 627 94 307 627 minecraft:obsidian
fill 94 216 628 94 218 628 minecraft:purple_stained_glass
fill 94 216 644 94 218 644 minecraft:purple_stained_glass
setblock 95 216 646 minecraft:amethyst_block
fill 96 216 646 101 216 646 minecraft:obsidian
fill 98 216 604 98 218 604 minecraft:purple_stained_glass
fill 101 216 604 106 220 604 minecraft:obsidian
fill 103 216 646 103 307 646 minecraft:obsidian
fill 107 216 604 108 216 604 minecraft:crying_obsidian
fill 107 216 637 107 217 637 minecraft:amethyst_block
fill 108 216 646 108 218 646 minecraft:purple_stained_glass
fill 109 216 604 110 272 604 minecraft:obsidian
fill 114 216 604 114 218 604 minecraft:purple_stained_glass
fill 120 216 604 120 237 604 minecraft:obsidian
setblock 121 216 604 minecraft:crying_obsidian
setblock 121 216 646 minecraft:crying_obsidian
setblock 122 216 646 minecraft:white_concrete
fill 123 216 646 123 233 646 minecraft:obsidian
fill 124 216 646 124 218 646 minecraft:purple_stained_glass
fill 129 216 604 129 307 604 minecraft:obsidian
fill 130 216 604 130 218 604 minecraft:purple_stained_glass
fill 136 216 610 136 220 610 minecraft:obsidian
fill 136 216 614 136 218 614 minecraft:purple_stained_glass
fill 136 216 630 136 218 630 minecraft:purple_stained_glass
setblock 136 216 641 minecraft:obsidian
setblock 136 216 643 minecraft:white_concrete
fill 136 216 644 136 228 644 minecraft:obsidian
fill 94 217 610 94 239 610 minecraft:obsidian
setblock 94 217 611 minecraft:amethyst_block
fill 95 217 646 98 221 646 minecraft:obsidian
setblock 99 217 646 minecraft:crying_obsidian
fill 100 217 646 101 219 646 minecraft:obsidian
fill 107 217 604 108 307 604 minecraft:obsidian
fill 119 217 646 119 303 646 minecraft:obsidian
setblock 120 217 646 minecraft:white_concrete
fill 121 217 604 121 285 604 minecraft:obsidian
fill 121 217 646 122 256 646 minecraft:obsidian
setblock 127 217 646 minecraft:white_concrete
setblock 136 217 617 minecraft:crying_obsidian
setblock 136 217 626 minecraft:amethyst_block
setblock 136 217 641 minecraft:amethyst_block
fill 136 217 643 136 254 643 minecraft:obsidian
fill 94 218 611 94 257 611 minecraft:obsidian
fill 99 218 646 99 229 646 minecraft:obsidian
fill 120 218 646 120 266 646 minecraft:obsidian
fill 127 218 646 127 307 646 minecraft:obsidian
setblock 129 218 646 minecraft:white_concrete
fill 130 218 646 135 234 646 minecraft:obsidian
fill 136 218 617 136 255 617 minecraft:obsidian
fill 136 218 626 136 301 626 minecraft:obsidian
setblock 136 218 641 minecraft:crying_obsidian
fill 94 219 612 94 224 612 minecraft:obsidian
setblock 94 219 628 minecraft:amethyst_block
fill 94 219 644 94 224 644 minecraft:obsidian
fill 98 219 604 98 224 604 minecraft:obsidian
fill 108 219 646 109 224 646 minecraft:obsidian
setblock 110 219 646 minecraft:amethyst_block
fill 111 219 646 111 232 646 minecraft:obsidian
fill 114 219 604 114 224 604 minecraft:obsidian
fill 124 219 646 124 224 646 minecraft:obsidian
fill 129 219 646 129 232 646 minecraft:obsidian
fill 130 219 604 130 224 604 minecraft:obsidian
fill 136 219 611 136 247 611 minecraft:obsidian
setblock 136 219 612 minecraft:white_concrete
fill 136 219 614 136 224 614 minecraft:obsidian
fill 136 219 630 136 222 630 minecraft:obsidian
fill 136 219 641 136 247 641 minecraft:obsidian
fill 94 220 628 94 224 628 minecraft:obsidian
setblock 100 220 646 minecraft:white_concrete
fill 101 220 646 101 299 646 minecraft:obsidian
fill 110 220 646 110 266 646 minecraft:obsidian
fill 136 220 605 136 221 605 minecraft:obsidian
setblock 136 220 606 minecraft:white_concrete
fill 136 220 612 136 253 612 minecraft:obsidian
setblock 94 221 635 minecraft:amethyst_block
fill 100 221 646 100 242 646 minecraft:obsidian
fill 101 221 604 105 232 604 minecraft:obsidian
fill 104 221 646 104 279 646 minecraft:obsidian
setblock 105 221 646 minecraft:white_concrete
setblock 106 221 604 minecraft:crying_obsidian
fill 107 221 630 107 222 630 minecraft:end_stone
fill 136 221 606 136 307 606 minecraft:obsidian
setblock 136 221 610 minecraft:white_concrete
setblock 136 221 631 minecraft:amethyst_block
fill 136 221 632 136 231 633 minecraft:obsidian
setblock 136 221 635 minecraft:amethyst_block
fill 94 222 614 94 268 614 minecraft:obsidian
setblock 94 222 615 minecraft:amethyst_block
fill 94 222 616 94 265 616 minecraft:obsidian
fill 94 222 620 94 307 621 minecraft:obsidian
setblock 94 222 622 minecraft:white_concrete
fill 94 222 623 94 260 624 minecraft:obsidian
fill 94 222 635 94 234 635 minecraft:obsidian
setblock 95 222 646 minecraft:crying_obsidian
fill 96 222 646 98 233 646 minecraft:obsidian
fill 105 222 646 105 307 646 minecraft:obsidian
fill 106 222 604 106 228 604 minecraft:obsidian
setblock 122 222 604 minecraft:amethyst_block
fill 123 222 604 124 243 604 minecraft:obsidian
setblock 125 222 604 minecraft:white_concrete
setblock 136 222 605 minecraft:amethyst_block
fill 136 222 610 136 292 610 minecraft:obsidian
fill 136 222 631 136 274 631 minecraft:obsidian
fill 136 222 635 136 236 635 minecraft:obsidian
fill 94 223 615 94 231 615 minecraft:obsidian
fill 94 223 622 94 233 622 minecraft:obsidian
fill 95 223 646 95 229 646 minecraft:obsidian
setblock 97 223 607 minecraft:light[level=14]
setblock 97 223 615 minecraft:light[level=14]
setblock 97 223 623 minecraft:light[level=14]
setblock 97 223 631 minecraft:light[level=14]
setblock 97 223 639 minecraft:light[level=14]
setblock 105 223 607 minecraft:light[level=14]
setblock 105 223 615 minecraft:light[level=14]
setblock 105 223 623 minecraft:light[level=14]
setblock 105 223 631 minecraft:light[level=14]
setblock 105 223 639 minecraft:light[level=14]
setblock 113 223 607 minecraft:light[level=14]
setblock 113 223 615 minecraft:light[level=14]
setblock 113 223 623 minecraft:light[level=14]
setblock 113 223 631 minecraft:light[level=14]
setblock 113 223 639 minecraft:light[level=14]
setblock 121 223 607 minecraft:light[level=14]
setblock 121 223 615 minecraft:light[level=14]
setblock 121 223 623 minecraft:light[level=14]
setblock 121 223 631 minecraft:light[level=14]
setblock 121 223 639 minecraft:light[level=14]
fill 122 223 604 122 300 604 minecraft:obsidian
fill 125 223 604 125 281 604 minecraft:obsidian
setblock 129 223 607 minecraft:light[level=14]
setblock 129 223 615 minecraft:light[level=14]
setblock 129 223 623 minecraft:light[level=14]
setblock 129 223 631 minecraft:light[level=14]
setblock 129 223 639 minecraft:light[level=14]
fill 136 223 605 136 227 605 minecraft:obsidian
fill 136 223 608 136 257 608 minecraft:obsidian
setblock 136 223 609 minecraft:crying_obsidian
setblock 136 223 630 minecraft:white_concrete
fill 136 224 609 136 259 609 minecraft:obsidian
setblock 136 224 630 minecraft:obsidian
fill 94 225 612 94 227 612 minecraft:purple_stained_glass
fill 94 225 628 94 227 628 minecraft:purple_stained_glass
setblock 94 225 639 minecraft:amethyst_block
fill 94 225 644 94 227 644 minecraft:purple_stained_glass
fill 98 225 604 98 227 604 minecraft:purple_stained_glass
fill 108 225 646 108 227 646 minecraft:purple_stained_glass
fill 109 225 646 109 237 646 minecraft:obsidian
fill 114 225 604 114 227 604 minecraft:purple_stained_glass
fill 124 225 646 124 227 646 minecraft:purple_stained_glass
fill 130 225 604 130 227 604 minecraft:purple_stained_glass
fill 136 225 614 136 227 614 minecraft:purple_stained_glass
fill 136 225 630 136 227 630 minecraft:purple_stained_glass
fill 94 226 639 94 262 639 minecraft:obsidian
setblock 136 226 628 minecraft:crying_obsidian
fill 136 226 629 136 233 629 minecraft:obsidian
setblock 94 227 625 minecraft:amethyst_block
setblock 116 227 646 minecraft:white_concrete
fill 117 227 646 118 307 646 minecraft:obsidian
fill 136 227 628 136 273 628 minecraft:obsidian
setblock 94 228 612 minecraft:white_concrete
fill 94 228 625 94 278 625 minecraft:obsidian
fill 94 228 628 94 242 628 minecraft:obsidian
fill 94 228 644 94 242 644 minecraft:obsidian
setblock 96 228 604 minecraft:amethyst_block
fill 98 228 604 98 236 604 minecraft:obsidian
fill 108 228 646 108 242 646 minecraft:obsidian
fill 114 228 604 114 242 604 minecraft:obsidian
setblock 114 228 646 minecraft:crying_obsidian
fill 116 228 646 116 252 646 minecraft:obsidian
setblock 118 228 604 minecraft:crying_obsidian
fill 119 228 604 119 241 604 minecraft:obsidian
fill 124 228 646 124 242 646 minecraft:obsidian
fill 130 228 604 130 237 604 minecraft:obsidian
setblock 136 228 605 minecraft:amethyst_block
fill 136 228 614 136 229 614 minecraft:obsidian
fill 136 228 630 136 242 630 minecraft:obsidian
fill 94 229 612 94 242 612 minecraft:obsidian
setblock 94 229 643 minecraft:white_concrete
fill 96 229 604 96 251 604 minecraft:obsidian
setblock 106 229 604 minecraft:amethyst_block
setblock 113 229 604 minecraft:crying_obsidian
fill 114 229 646 114 307 646 minecraft:obsidian
fill 118 229 604 118 254 604 minecraft:obsidian
setblock 136 229 605 minecraft:crying_obsidian
setblock 136 229 644 minecraft:amethyst_block
fill 94 230 643 94 238 643 minecraft:obsidian
setblock 95 230 646 minecraft:crying_obsidian
setblock 99 230 646 minecraft:white_concrete
fill 106 230 604 106 307 604 minecraft:obsidian
fill 113 230 604 113 307 604 minecraft:obsidian
fill 136 230 605 136 261 605 minecraft:obsidian
setblock 136 230 614 minecraft:amethyst_block
fill 136 230 644 136 248 644 minecraft:obsidian
fill 95 231 646 95 265 646 minecraft:obsidian
setblock 97 231 607 minecraft:light[level=14]
setblock 97 231 615 minecraft:light[level=14]
setblock 97 231 623 minecraft:light[level=14]
setblock 97 231 631 minecraft:light[level=14]
setblock 97 231 639 minecraft:light[level=14]
fill 99 231 646 99 240 646 minecraft:obsidian
setblock 105 231 607 minecraft:light[level=14]
setblock 105 231 615 minecraft:light[level=14]
setblock 105 231 623 minecraft:light[level=14]
setblock 105 231 631 minecraft:light[level=14]
setblock 105 231 639 minecraft:light[level=14]
setblock 113 231 607 minecraft:light[level=14]
setblock 113 231 615 minecraft:light[level=14]
setblock 113 231 623 minecraft:light[level=14]
setblock 113 231 631 minecraft:light[level=14]
setblock 113 231 639 minecraft:light[level=14]
setblock 121 231 607 minecraft:light[level=14]
setblock 121 231 615 minecraft:light[level=14]
setblock 121 231 623 minecraft:light[level=14]
setblock 121 231 631 minecraft:light[level=14]
setblock 121 231 639 minecraft:light[level=14]
setblock 129 231 607 minecraft:light[level=14]
setblock 129 231 615 minecraft:light[level=14]
setblock 129 231 623 minecraft:light[level=14]
setblock 129 231 631 minecraft:light[level=14]
setblock 129 231 639 minecraft:light[level=14]
fill 136 231 614 136 242 614 minecraft:obsidian
setblock 94 232 615 minecraft:crying_obsidian
fill 113 232 621 115 232 623 minecraft:redstone_block
fill 114 232 628 116 232 630 minecraft:redstone_block
fill 121 232 621 123 232 623 minecraft:redstone_block
fill 121 232 627 123 232 629 minecraft:redstone_block
fill 136 232 632 136 307 632 minecraft:obsidian
setblock 136 232 633 minecraft:white_concrete
fill 94 233 615 94 288 615 minecraft:obsidian
setblock 101 233 604 minecraft:white_concrete
fill 102 233 604 105 233 604 minecraft:obsidian
fill 108 233 625 109 233 625 minecraft:end_stone_bricks
fill 109 233 621 110 233 624 minecraft:end_stone_bricks
fill 109 233 626 110 233 629 minecraft:end_stone_bricks
fill 110 233 619 111 233 620 minecraft:end_stone_bricks
fill 110 233 625 116 233 625 minecraft:black_concrete
fill 110 233 630 111 233 631 minecraft:end_stone_bricks
fill 111 233 618 114 233 618 minecraft:end_stone_bricks
fill 111 233 621 111 234 621 minecraft:end_stone_bricks
fill 111 233 622 112 233 624 minecraft:black_concrete
fill 111 233 626 113 233 628 minecraft:black_concrete
fill 111 233 629 111 234 629 minecraft:end_stone_bricks
fill 111 233 632 114 233 632 minecraft:end_stone_bricks
setblock 111 233 646 minecraft:crying_obsidian
fill 112 233 617 117 233 617 minecraft:end_stone_bricks
fill 112 233 619 112 234 619 minecraft:end_stone_bricks
fill 112 233 620 112 233 621 minecraft:black_concrete
fill 112 233 629 113 233 630 minecraft:black_concrete
fill 112 233 631 112 234 631 minecraft:end_stone_bricks
fill 112 233 633 117 233 633 minecraft:end_stone_bricks
fill 113 233 619 123 233 620 minecraft:black_concrete
fill 113 233 624 116 233 624 minecraft:black_concrete
fill 113 233 631 123 233 631 minecraft:black_concrete
fill 114 233 616 122 233 616 minecraft:end_stone_bricks
fill 114 233 626 116 233 627 minecraft:black_concrete
fill 114 233 634 122 233 634 minecraft:end_stone_bricks
fill 115 233 618 121 234 618 minecraft:black_concrete
fill 115 233 632 121 234 632 minecraft:black_concrete
fill 116 233 621 120 233 623 minecraft:black_concrete
fill 117 233 627 120 233 630 minecraft:black_concrete
fill 118 233 615 118 234 615 minecraft:end_stone_bricks
fill 118 233 617 118 234 617 minecraft:black_concrete
fill 118 233 633 118 234 633 minecraft:black_concrete
fill 118 233 635 118 234 635 minecraft:end_stone_bricks
fill 119 233 617 124 233 617 minecraft:end_stone_bricks
fill 119 233 633 124 233 633 minecraft:end_stone_bricks
fill 120 233 624 125 233 626 minecraft:black_concrete
fill 121 233 630 124 233 630 minecraft:black_concrete
fill 122 233 618 125 233 618 minecraft:end_stone_bricks
fill 122 233 632 125 233 632 minecraft:end_stone_bricks
fill 124 233 619 126 234 619 minecraft:end_stone_bricks
fill 124 233 620 124 233 623 minecraft:black_concrete
fill 124 233 627 124 233 629 minecraft:black_concrete
fill 124 233 631 126 234 631 minecraft:end_stone_bricks
fill 125 233 620 126 233 621 minecraft:end_stone_bricks
fill 125 233 622 125 234 623 minecraft:black_concrete
fill 125 233 627 125 234 628 minecraft:black_concrete
fill 125 233 629 126 233 630 minecraft:end_stone_bricks
fill 126 233 622 127 233 624 minecraft:end_stone_bricks
fill 126 233 625 126 234 625 minecraft:black_concrete
fill 126 233 626 127 233 628 minecraft:end_stone_bricks
fill 127 233 621 127 234 621 minecraft:end_stone_bricks
fill 127 233 625 128 234 625 minecraft:end_stone_bricks
fill 127 233 629 127 234 629 minecraft:end_stone_bricks
setblock 129 233 646 minecraft:amethyst_block
fill 136 233 633 136 251 633 minecraft:obsidian
setblock 136 233 640 minecraft:amethyst_block
setblock 94 234 622 minecraft:amethyst_block
setblock 94 234 634 minecraft:amethyst_block
fill 95 234 605 107 234 645 minecraft:end_stone
fill 96 234 646 97 275 646 minecraft:obsidian
setblock 97 234 604 minecraft:white_concrete
setblock 98 234 646 minecraft:amethyst_block
fill 101 234 604 104 250 604 minecraft:obsidian
setblock 105 234 604 minecraft:crying_obsidian
fill 108 234 605 108 234 624 minecraft:end_stone
setblock 108 234 625 minecraft:end_stone_bricks
fill 108 234 626 108 234 645 minecraft:end_stone
fill 109 234 605 109 234 620 minecraft:end_stone
setblock 109 234 621 minecraft:pearlescent_froglight
fill 109 234 622 109 234 624 minecraft:end_stone_bricks
setblock 109 234 625 minecraft:pearlescent_froglight
fill 109 234 626 109 234 628 minecraft:end_stone_bricks
setblock 109 234 629 minecraft:pearlescent_froglight
fill 109 234 630 109 234 645 minecraft:end_stone
fill 110 234 605 110 234 618 minecraft:end_stone
setblock 110 234 619 minecraft:end_stone_bricks
setblock 110 234 620 minecraft:pearlescent_froglight
fill 110 234 621 110 234 623 minecraft:end_stone_bricks
setblock 110 234 624 minecraft:pearlescent_froglight
fill 110 234 625 115 234 625 minecraft:black_concrete
fill 110 234 626 110 234 627 minecraft:end_stone_bricks
setblock 110 234 628 minecraft:pearlescent_froglight
fill 110 234 629 110 234 631 minecraft:end_stone_bricks
fill 110 234 632 110 234 645 minecraft:end_stone
fill 111 234 605 111 234 617 minecraft:end_stone
setblock 111 234 618 minecraft:end_stone_bricks
setblock 111 234 619 minecraft:pearlescent_froglight
setblock 111 234 620 minecraft:end_stone_bricks
fill 111 234 622 111 234 624 minecraft:black_concrete
fill 111 234 626 112 234 628 minecraft:black_concrete
setblock 111 234 630 minecraft:end_stone_bricks
setblock 111 234 631 minecraft:pearlescent_froglight
fill 111 234 632 113 234 632 minecraft:end_stone_bricks
fill 111 234 633 111 234 645 minecraft:end_stone
fill 111 234 646 111 307 646 minecraft:obsidian
fill 112 234 605 113 234 616 minecraft:end_stone
setblock 112 234 617 minecraft:end_stone_bricks
setblock 112 234 618 minecraft:pearlescent_froglight
fill 112 234 620 112 234 624 minecraft:crying_obsidian
fill 112 234 629 112 234 630 minecraft:black_concrete
setblock 112 234 633 minecraft:end_stone_bricks
fill 112 234 634 113 234 645 minecraft:end_stone
setblock 113 234 617 minecraft:pearlescent_froglight
fill 113 234 618 114 234 618 minecraft:end_stone_bricks
fill 113 234 619 123 234 619 minecraft:black_concrete
fill 113 234 620 116 234 620 minecraft:crying_obsidian
fill 113 234 621 115 234 623 minecraft:end_stone
fill 113 234 624 116 234 624 minecraft:crying_obsidian
fill 113 234 626 115 234 626 minecraft:black_concrete
fill 113 234 627 113 234 631 minecraft:crying_obsidian
setblock 113 234 633 minecraft:pearlescent_froglight
fill 114 234 605 117 234 615 minecraft:end_stone
setblock 114 234 616 minecraft:pearlescent_froglight
fill 114 234 617 116 234 617 minecraft:end_stone_bricks
fill 114 234 627 120 234 627 minecraft:crying_obsidian
fill 114 234 628 116 234 630 minecraft:end_stone
fill 114 234 631 117 234 631 minecraft:crying_obsidian
setblock 114 234 632 minecraft:pearlescent_froglight
fill 114 234 633 115 234 634 minecraft:end_stone_bricks
fill 114 234 635 117 234 645 minecraft:end_stone
fill 115 234 616 117 234 616 minecraft:end_stone_bricks
fill 116 234 621 116 234 623 minecraft:crying_obsidian
fill 116 234 625 116 234 626 minecraft:crying_obsidian
setblock 116 234 633 minecraft:end_stone_bricks
setblock 116 234 634 minecraft:pearlescent_froglight
setblock 117 234 617 minecraft:pearlescent_froglight
fill 117 234 620 119 234 622 minecraft:black_concrete
fill 117 234 623 120 234 623 minecraft:crying_obsidian
fill 117 234 628 117 234 630 minecraft:crying_obsidian
setblock 117 234 633 minecraft:pearlescent_froglight
fill 117 234 634 119 234 634 minecraft:end_stone_bricks
fill 118 234 605 135 234 614 minecraft:end_stone
setblock 118 234 616 minecraft:pearlescent_froglight
fill 118 234 628 119 234 631 minecraft:black_concrete
fill 118 234 636 135 234 645 minecraft:end_stone
fill 119 234 615 135 234 615 minecraft:end_stone
fill 119 234 616 120 234 617 minecraft:end_stone_bricks
fill 119 234 633 120 234 633 minecraft:end_stone_bricks
fill 119 234 635 135 234 635 minecraft:end_stone
fill 120 234 620 120 234 622 minecraft:crying_obsidian
fill 120 234 624 120 234 626 minecraft:crying_obsidian
fill 120 234 628 120 234 630 minecraft:crying_obsidian
fill 120 234 631 123 234 631 minecraft:black_concrete
setblock 120 234 634 minecraft:pearlescent_froglight
setblock 121 234 616 minecraft:end_stone_bricks
setblock 121 234 617 minecraft:pearlescent_froglight
fill 121 234 620 124 234 620 minecraft:crying_obsidian
fill 121 234 621 123 234 623 minecraft:end_stone
fill 121 234 624 124 234 624 minecraft:crying_obsidian
fill 121 234 625 125 234 625 minecraft:black_concrete
fill 121 234 626 124 234 626 minecraft:crying_obsidian
fill 121 234 627 123 234 629 minecraft:end_stone
fill 121 234 630 124 234 630 minecraft:crying_obsidian
setblock 121 234 633 minecraft:pearlescent_froglight
fill 121 234 634 122 234 634 minecraft:end_stone_bricks
setblock 122 234 616 minecraft:pearlescent_froglight
fill 122 234 617 123 234 618 minecraft:end_stone_bricks
setblock 122 234 632 minecraft:pearlescent_froglight
fill 122 234 633 124 234 633 minecraft:end_stone_bricks
fill 123 234 616 135 234 616 minecraft:end_stone
fill 123 234 632 125 234 632 minecraft:end_stone_bricks
fill 123 234 634 135 234 634 minecraft:end_stone
setblock 123 234 646 minecraft:white_concrete
setblock 124 234 617 minecraft:end_stone_bricks
setblock 124 234 618 minecraft:pearlescent_froglight
fill 124 234 621 124 234 623 minecraft:crying_obsidian
fill 124 234 627 124 234 629 minecraft:crying_obsidian
fill 125 234 617 135 234 617 minecraft:end_stone
setblock 125 234 618 minecraft:end_stone_bricks
setblock 125 234 620 minecraft:end_stone_bricks
setblock 125 234 621 minecraft:pearlescent_froglight
setblock 125 234 624 minecraft:black_concrete
setblock 125 234 626 minecraft:black_concrete
setblock 125 234 629 minecraft:pearlescent_froglight
fill 125 234 630 126 234 630 minecraft:end_stone_bricks
fill 125 234 633 135 234 633 minecraft:end_stone
fill 126 234 618 135 234 618 minecraft:end_stone
setblock 126 234 620 minecraft:pearlescent_froglight
fill 126 234 621 126 234 623 minecraft:end_stone_bricks
setblock 126 234 624 minecraft:pearlescent_froglight
fill 126 234 626 126 234 627 minecraft:end_stone_bricks
setblock 126 234 628 minecraft:pearlescent_froglight
setblock 126 234 629 minecraft:end_stone_bricks
fill 126 234 632 135 234 632 minecraft:end_stone
fill 127 234 619 135 234 620 minecraft:end_stone
setblock 127 234 622 minecraft:end_stone_bricks
setblock 127 234 623 minecraft:pearlescent_froglight
setblock 127 234 624 minecraft:end_stone_bricks
setblock 127 234 626 minecraft:end_stone_bricks
setblock 127 234 627 minecraft:pearlescent_froglight
setblock 127 234 628 minecraft:end_stone_bricks
fill 127 234 630 135 234 631 minecraft:end_stone
fill 128 234 621 135 234 624 minecraft:end_stone
fill 128 234 626 135 234 629 minecraft:end_stone
fill 129 234 625 135 234 625 minecraft:end_stone
fill 129 234 646 129 301 646 minecraft:obsidian
fill 136 234 629 136 235 629 minecraft:amethyst_block
fill 136 234 640 136 307 640 minecraft:obsidian
setblock 94 235 618 minecraft:amethyst_block
fill 94 235 622 94 263 622 minecraft:obsidian
fill 94 235 634 94 255 634 minecraft:obsidian
setblock 94 235 635 minecraft:amethyst_block
fill 97 235 604 97 304 604 minecraft:obsidian
fill 98 235 646 98 304 646 minecraft:obsidian
fill 105 235 604 105 269 604 minecraft:obsidian
fill 108 235 616 110 238 616 minecraft:end_stone_bricks
fill 108 235 634 110 238 634 minecraft:end_stone_bricks
fill 109 235 615 109 238 615 minecraft:end_stone_bricks
fill 109 235 617 109 238 617 minecraft:end_stone_bricks
fill 109 235 633 109 238 633 minecraft:end_stone_bricks
fill 109 235 635 109 238 635 minecraft:end_stone_bricks
fill 123 235 646 123 271 646 minecraft:obsidian
fill 126 235 616 128 238 616 minecraft:end_stone_bricks
fill 126 235 634 128 238 634 minecraft:end_stone_bricks
fill 127 235 615 127 238 615 minecraft:end_stone_bricks
fill 127 235 617 127 238 617 minecraft:end_stone_bricks
fill 127 235 633 127 238 633 minecraft:end_stone_bricks
fill 127 235 635 127 238 635 minecraft:end_stone_bricks
fill 130 235 646 131 271 646 minecraft:obsidian
setblock 132 235 646 minecraft:white_concrete
fill 133 235 646 135 307 646 minecraft:obsidian
fill 94 236 618 94 238 618 minecraft:obsidian
fill 94 236 635 94 279 635 minecraft:obsidian
setblock 112 236 604 minecraft:crying_obsidian
fill 132 236 646 132 241 646 minecraft:obsidian
fill 136 236 629 136 307 629 minecraft:obsidian
setblock 98 237 604 minecraft:amethyst_block
fill 112 237 604 112 307 604 minecraft:obsidian
setblock 136 237 635 minecraft:amethyst_block
fill 98 238 604 98 242 604 minecraft:obsidian
setblock 102 238 646 minecraft:amethyst_block
fill 105 238 628 106 238 628 minecraft:netherrack
setblock 109 238 646 minecraft:white_concrete
setblock 120 238 604 minecraft:crying_obsidian
setblock 130 238 604 minecraft:amethyst_block
setblock 135 238 604 minecraft:amethyst_block
fill 136 238 635 136 239 635 minecraft:obsidian
setblock 94 239 618 minecraft:crying_obsidian
setblock 94 239 629 minecraft:white_concrete
setblock 94 239 643 minecraft:crying_obsidian
setblock 97 239 607 minecraft:light[level=14]
setblock 97 239 615 minecraft:light[level=14]
setblock 97 239 623 minecraft:light[level=14]
setblock 97 239 631 minecraft:light[level=14]
setblock 97 239 639 minecraft:light[level=14]
fill 102 239 646 102 274 646 minecraft:obsidian
setblock 105 239 607 minecraft:light[level=14]
setblock 105 239 615 minecraft:light[level=14]
setblock 105 239 623 minecraft:light[level=14]
setblock 105 239 631 minecraft:light[level=14]
setblock 105 239 639 minecraft:light[level=14]
fill 109 239 646 109 263 646 minecraft:obsidian
setblock 113 239 607 minecraft:light[level=14]
setblock 113 239 615 minecraft:light[level=14]
setblock 113 239 623 minecraft:light[level=14]
setblock 113 239 631 minecraft:light[level=14]
setblock 113 239 639 minecraft:light[level=14]
fill 120 239 604 120 249 604 minecraft:obsidian
setblock 121 239 607 minecraft:light[level=14]
setblock 121 239 615 minecraft:light[level=14]
setblock 121 239 623 minecraft:light[level=14]
setblock 121 239 631 minecraft:light[level=14]
setblock 121 239 639 minecraft:light[level=14]
setblock 129 239 607 minecraft:light[level=14]
setblock 129 239 615 minecraft:light[level=14]
setblock 129 239 623 minecraft:light[level=14]
setblock 129 239 631 minecraft:light[level=14]
setblock 129 239 639 minecraft:light[level=14]
fill 130 239 604 130 242 604 minecraft:obsidian
setblock 132 239 604 minecraft:white_concrete
fill 135 239 604 135 261 604 minecraft:obsidian
setblock 136 239 615 minecraft:white_concrete
fill 136 239 618 136 259 620 minecraft:obsidian
setblock 136 239 621 minecraft:white_concrete
setblock 94 240 610 minecraft:amethyst_block
fill 94 240 618 94 307 618 minecraft:obsidian
fill 94 240 629 94 307 629 minecraft:obsidian
fill 94 240 643 94 307 643 minecraft:obsidian
fill 132 240 604 132 243 604 minecraft:obsidian
fill 136 240 615 136 254 615 minecraft:obsidian
fill 136 240 621 136 307 621 minecraft:obsidian
setblock 136 240 622 minecraft:white_concrete
fill 136 240 623 136 281 623 minecraft:obsidian
setblock 136 240 635 minecraft:amethyst_block
fill 94 241 604 94 307 605 minecraft:obsidian
setblock 94 241 606 minecraft:amethyst_block
fill 94 241 610 94 296 610 minecraft:obsidian
setblock 99 241 646 minecraft:crying_obsidian
setblock 125 241 646 minecraft:crying_obsidian
fill 136 241 622 136 307 622 minecraft:obsidian
fill 136 241 635 136 277 635 minecraft:obsidian
fill 94 242 606 94 307 606 minecraft:obsidian
setblock 95 242 604 minecraft:amethyst_block
fill 99 242 646 99 261 646 minecraft:obsidian
setblock 119 242 604 minecraft:white_concrete
fill 125 242 646 125 276 646 minecraft:obsidian
fill 126 242 604 126 307 604 minecraft:obsidian
setblock 127 242 604 minecraft:amethyst_block
setblock 132 242 646 minecraft:amethyst_block
fill 94 243 612 94 245 612 minecraft:purple_stained_glass
fill 94 243 628 94 245 628 minecraft:purple_stained_glass
fill 94 243 644 94 245 644 minecraft:purple_stained_glass
fill 95 243 604 95 307 604 minecraft:obsidian
fill 98 243 604 98 245 604 minecraft:purple_stained_glass
setblock 100 243 646 minecraft:white_concrete
fill 108 243 646 108 245 646 minecraft:purple_stained_glass
fill 114 243 604 114 245 604 minecraft:purple_stained_glass
fill 119 243 604 119 307 604 minecraft:obsidian
fill 124 243 646 124 245 646 minecraft:purple_stained_glass
fill 127 243 604 127 274 604 minecraft:obsidian
fill 130 243 604 130 245 604 minecraft:purple_stained_glass
fill 132 243 646 132 292 646 minecraft:obsidian
fill 136 243 614 136 245 614 minecraft:purple_stained_glass
setblock 136 243 616 minecraft:crying_obsidian
fill 136 243 630 136 245 630 minecraft:purple_stained_glass
setblock 94 244 631 minecraft:amethyst_block
fill 100 244 646 100 307 646 minecraft:obsidian
fill 121 244 605 123 247 606 minecraft:amethyst_block
setblock 123 244 604 minecraft:amethyst_block
fill 124 244 604 124 285 604 minecraft:obsidian
setblock 132 244 604 minecraft:crying_obsidian
fill 136 244 616 136 252 616 minecraft:obsidian
setblock 94 245 631 minecraft:obsidian
setblock 94 245 638 minecraft:crying_obsidian
fill 120 245 605 120 246 605 minecraft:amethyst_block
fill 121 245 607 123 247 607 minecraft:amethyst_block
fill 123 245 604 123 307 604 minecraft:obsidian
fill 124 245 605 124 246 605 minecraft:amethyst_block
fill 132 245 604 132 307 604 minecraft:obsidian
setblock 133 245 604 minecraft:amethyst_block
fill 134 245 604 134 247 604 minecraft:obsidian
fill 94 246 612 94 251 612 minecraft:obsidian
setblock 94 246 617 minecraft:crying_obsidian
fill 94 246 628 94 251 628 minecraft:obsidian
setblock 94 246 631 minecraft:amethyst_block
setblock 94 246 636 minecraft:crying_obsidian
setblock 94 246 637 minecraft:white_concrete
fill 94 246 638 94 267 638 minecraft:obsidian
fill 94 246 644 94 251 644 minecraft:obsidian
fill 98 246 604 98 251 604 minecraft:obsidian
fill 108 246 646 108 251 646 minecraft:obsidian
fill 114 246 604 114 251 604 minecraft:obsidian
fill 122 246 608 122 247 608 minecraft:amethyst_block
fill 124 246 646 124 251 646 minecraft:obsidian
fill 130 246 604 130 251 604 minecraft:obsidian
fill 133 246 604 133 280 604 minecraft:obsidian
fill 136 246 614 136 251 614 minecraft:obsidian
fill 136 246 630 136 251 630 minecraft:obsidian
setblock 94 247 613 minecraft:crying_obsidian
fill 94 247 617 94 269 617 minecraft:obsidian
fill 94 247 631 94 252 631 minecraft:obsidian
fill 94 247 636 94 269 637 minecraft:obsidian
setblock 97 247 607 minecraft:light[level=14]
setblock 97 247 615 minecraft:light[level=14]
setblock 97 247 623 minecraft:light[level=14]
setblock 97 247 631 minecraft:light[level=14]
setblock 97 247 639 minecraft:light[level=14]
setblock 105 247 607 minecraft:light[level=14]
setblock 105 247 615 minecraft:light[level=14]
setblock 105 247 623 minecraft:light[level=14]
setblock 105 247 631 minecraft:light[level=14]
setblock 105 247 639 minecraft:light[level=14]
setblock 113 247 607 minecraft:light[level=14]
setblock 113 247 615 minecraft:light[level=14]
setblock 113 247 623 minecraft:light[level=14]
setblock 113 247 631 minecraft:light[level=14]
setblock 113 247 639 minecraft:light[level=14]
setblock 121 247 615 minecraft:light[level=14]
setblock 121 247 623 minecraft:light[level=14]
setblock 121 247 631 minecraft:light[level=14]
setblock 121 247 639 minecraft:light[level=14]
setblock 122 247 609 minecraft:amethyst_block
setblock 129 247 607 minecraft:light[level=14]
setblock 129 247 615 minecraft:light[level=14]
setblock 129 247 623 minecraft:light[level=14]
setblock 129 247 631 minecraft:light[level=14]
setblock 129 247 639 minecraft:light[level=14]
setblock 131 247 604 minecraft:crying_obsidian
setblock 136 247 627 minecraft:amethyst_block
fill 94 248 613 94 307 613 minecraft:obsidian
fill 121 248 632 122 249 633 minecraft:netherrack
fill 131 248 604 131 265 604 minecraft:obsidian
setblock 134 248 604 minecraft:amethyst_block
setblock 136 248 611 minecraft:amethyst_block
fill 136 248 627 136 307 627 minecraft:obsidian
setblock 136 248 641 minecraft:crying_obsidian
setblock 94 249 641 minecraft:crying_obsidian
fill 134 249 604 134 307 604 minecraft:obsidian
fill 136 249 611 136 307 611 minecraft:obsidian
setblock 136 249 624 minecraft:obsidian
setblock 136 249 625 minecraft:amethyst_block
fill 136 249 641 136 307 641 minecraft:obsidian
setblock 136 249 644 minecraft:crying_obsidian
fill 94 250 641 94 276 641 minecraft:obsidian
setblock 113 250 646 minecraft:amethyst_block
setblock 120 250 604 minecraft:white_concrete
setblock 136 250 624 minecraft:amethyst_block
fill 136 250 625 136 307 625 minecraft:obsidian
fill 136 250 644 136 253 644 minecraft:obsidian
setblock 94 251 642 minecraft:white_concrete
fill 101 251 604 101 307 604 minecraft:obsidian
setblock 102 251 604 minecraft:amethyst_block
fill 103 251 604 104 266 604 minecraft:obsidian
fill 106 251 628 107 252 628 minecraft:netherrack
fill 113 251 646 113 285 646 minecraft:obsidian
fill 120 251 604 120 307 604 minecraft:obsidian
fill 136 251 624 136 307 624 minecraft:obsidian
fill 94 252 612 94 254 612 minecraft:purple_stained_glass
fill 94 252 628 94 254 628 minecraft:purple_stained_glass
fill 94 252 642 94 307 642 minecraft:obsidian
fill 94 252 644 94 254 644 minecraft:purple_stained_glass
setblock 96 252 604 minecraft:amethyst_block
fill 98 252 604 98 254 604 minecraft:purple_stained_glass
fill 102 252 604 102 263 604 minecraft:obsidian
fill 108 252 646 108 254 646 minecraft:purple_stained_glass
fill 114 252 604 114 254 604 minecraft:purple_stained_glass
fill 124 252 646 124 254 646 minecraft:purple_stained_glass
fill 130 252 604 130 254 604 minecraft:purple_stained_glass
fill 136 252 614 136 254 614 minecraft:purple_stained_glass
fill 136 252 630 136 254 630 minecraft:purple_stained_glass
setblock 136 252 633 minecraft:amethyst_block
setblock 136 252 639 minecraft:crying_obsidian
setblock 94 253 631 minecraft:white_concrete
fill 96 253 604 96 282 604 minecraft:obsidian
setblock 116 253 646 minecraft:white_concrete
setblock 136 253 616 minecraft:amethyst_block
fill 136 253 633 136 283 633 minecraft:obsidian
fill 136 253 639 136 283 639 minecraft:obsidian
fill 94 254 631 94 307 631 minecraft:obsidian
fill 116 254 646 116 307 646 minecraft:obsidian
setblock 136 254 612 minecraft:amethyst_block
fill 136 254 616 136 293 616 minecraft:obsidian
setblock 136 254 644 minecraft:white_concrete
fill 94 255 612 94 260 612 minecraft:obsidian
fill 94 255 628 94 260 628 minecraft:obsidian
fill 94 255 644 94 260 644 minecraft:obsidian
setblock 97 255 607 minecraft:light[level=14]
setblock 97 255 615 minecraft:light[level=14]
setblock 97 255 623 minecraft:light[level=14]
setblock 97 255 631 minecraft:light[level=14]
setblock 97 255 639 minecraft:light[level=14]
fill 98 255 604 98 260 604 minecraft:obsidian
setblock 105 255 607 minecraft:light[level=14]
setblock 105 255 615 minecraft:light[level=14]
setblock 105 255 623 minecraft:light[level=14]
setblock 105 255 631 minecraft:light[level=14]
setblock 105 255 639 minecraft:light[level=14]
fill 108 255 646 108 260 646 minecraft:obsidian
setblock 113 255 607 minecraft:light[level=14]
setblock 113 255 615 minecraft:light[level=14]
setblock 113 255 623 minecraft:light[level=14]
setblock 113 255 631 minecraft:light[level=14]
setblock 113 255 639 minecraft:light[level=14]
fill 114 255 604 114 260 604 minecraft:obsidian
setblock 118 255 604 minecraft:amethyst_block
setblock 121 255 607 minecraft:light[level=14]
setblock 121 255 615 minecraft:light[level=14]
setblock 121 255 623 minecraft:light[level=14]
setblock 121 255 631 minecraft:light[level=14]
setblock 121 255 639 minecraft:light[level=14]
fill 124 255 646 124 260 646 minecraft:obsidian
setblock 128 255 604 minecraft:white_concrete
setblock 129 255 607 minecraft:light[level=14]
setblock 129 255 615 minecraft:light[level=14]
setblock 129 255 623 minecraft:light[level=14]
setblock 129 255 631 minecraft:light[level=14]
setblock 129 255 639 minecraft:light[level=14]
fill 130 255 604 130 260 604 minecraft:obsidian
fill 136 255 612 136 263 612 minecraft:obsidian
fill 136 255 614 136 260 614 minecraft:obsidian
setblock 136 255 615 minecraft:crying_obsidian
fill 136 255 630 136 260 630 minecraft:obsidian
fill 136 255 636 136 307 636 minecraft:obsidian
setblock 136 255 637 minecraft:crying_obsidian
fill 136 255 638 136 256 638 minecraft:obsidian
setblock 136 255 643 minecraft:crying_obsidian
fill 136 255 644 136 267 644 minecraft:obsidian
setblock 94 256 634 minecraft:white_concrete
fill 105 256 624 106 257 624 minecraft:netherrack
fill 108 256 621 108 257 621 minecraft:end_stone
setblock 112 256 646 minecraft:crying_obsidian
fill 118 256 604 118 307 604 minecraft:obsidian
fill 128 256 604 128 303 604 minecraft:obsidian
fill 136 256 615 136 307 615 minecraft:obsidian
setblock 136 256 617 minecraft:crying_obsidian
fill 136 256 637 136 266 637 minecraft:obsidian
fill 136 256 643 136 307 643 minecraft:obsidian
fill 94 257 634 94 260 634 minecraft:obsidian
fill 112 257 646 112 307 646 minecraft:obsidian
setblock 121 257 646 minecraft:white_concrete
fill 122 257 646 122 307 646 minecraft:obsidian
setblock 136 257 607 minecraft:amethyst_block
fill 136 257 617 136 285 617 minecraft:obsidian
setblock 136 257 638 minecraft:crying_obsidian
setblock 94 258 611 minecraft:amethyst_block
fill 121 258 646 121 267 646 minecraft:obsidian
fill 136 258 607 136 266 607 minecraft:obsidian
setblock 136 258 608 minecraft:white_concrete
fill 136 258 638 136 288 638 minecraft:obsidian
fill 94 259 611 94 307 611 minecraft:obsidian
setblock 115 259 646 minecraft:amethyst_block
fill 136 259 608 136 275 608 minecraft:obsidian
setblock 107 260 646 minecraft:crying_obsidian
fill 115 260 646 115 307 646 minecraft:obsidian
setblock 136 260 609 minecraft:crying_obsidian
fill 136 260 618 136 270 618 minecraft:obsidian
setblock 136 260 619 minecraft:amethyst_block
fill 136 260 620 136 307 620 minecraft:obsidian
fill 94 261 612 94 263 612 minecraft:purple_stained_glass
setblock 94 261 623 minecraft:white_concrete
fill 94 261 624 94 307 624 minecraft:obsidian
fill 94 261 628 94 263 628 minecraft:purple_stained_glass
setblock 94 261 634 minecraft:crying_obsidian
fill 94 261 644 94 263 644 minecraft:purple_stained_glass
fill 98 261 604 98 263 604 minecraft:purple_stained_glass
fill 107 261 646 107 269 646 minecraft:obsidian
fill 108 261 646 108 263 646 minecraft:purple_stained_glass
fill 114 261 604 114 263 604 minecraft:purple_stained_glass
fill 124 261 646 124 263 646 minecraft:purple_stained_glass
fill 130 261 604 130 263 604 minecraft:purple_stained_glass
fill 136 261 609 136 307 609 minecraft:obsidian
fill 136 261 614 136 263 614 minecraft:purple_stained_glass
fill 136 261 619 136 307 619 minecraft:obsidian
fill 136 261 630 136 263 630 minecraft:purple_stained_glass
fill 94 262 623 94 275 623 minecraft:obsidian
fill 94 262 634 94 297 634 minecraft:obsidian
setblock 99 262 646 minecraft:crying_obsidian
setblock 126 262 646 minecraft:white_concrete
setblock 135 262 604 minecraft:white_concrete
setblock 136 262 605 minecraft:amethyst_block
setblock 94 263 639 minecraft:crying_obsidian
setblock 97 263 607 minecraft:light[level=14]
setblock 97 263 615 minecraft:light[level=14]
setblock 97 263 623 minecraft:light[level=14]
setblock 97 263 631 minecraft:light[level=14]
setblock 97 263 639 minecraft:light[level=14]
fill 99 263 646 99 274 646 minecraft:obsidian
setblock 105 263 607 minecraft:light[level=14]
setblock 105 263 615 minecraft:light[level=14]
setblock 105 263 623 minecraft:light[level=14]
setblock 105 263 631 minecraft:light[level=14]
setblock 105 263 639 minecraft:light[level=14]
setblock 113 263 607 minecraft:light[level=14]
setblock 113 263 615 minecraft:light[level=14]
setblock 113 263 623 minecraft:light[level=14]
setblock 113 263 631 minecraft:light[level=14]
setblock 113 263 639 minecraft:light[level=14]
fill 115 263 604 115 285 604 minecraft:obsidian
setblock 116 263 604 minecraft:white_concrete
setblock 121 263 607 minecraft:light[level=14]
setblock 121 263 615 minecraft:light[level=14]
setblock 121 263 623 minecraft:light[level=14]
setblock 121 263 631 minecraft:light[level=14]
setblock 121 263 639 minecraft:light[level=14]
fill 126 263 646 126 284 646 minecraft:obsidian
setblock 129 263 607 minecraft:light[level=14]
setblock 129 263 615 minecraft:light[level=14]
setblock 129 263 623 minecraft:light[level=14]
setblock 129 263 631 minecraft:light[level=14]
setblock 129 263 639 minecraft:light[level=14]
fill 135 263 604 135 307 604 minecraft:obsidian
fill 136 263 605 136 272 605 minecraft:obsidian
fill 94 264 612 94 269 612 minecraft:obsidian
setblock 94 264 622 minecraft:amethyst_block
fill 94 264 628 94 269 628 minecraft:obsidian
setblock 94 264 632 minecraft:amethyst_block
fill 94 264 633 94 266 633 minecraft:obsidian
fill 94 264 639 94 279 639 minecraft:obsidian
fill 94 264 644 94 269 644 minecraft:obsidian
fill 98 264 604 98 269 604 minecraft:obsidian
setblock 102 264 604 minecraft:crying_obsidian
fill 108 264 646 108 269 646 minecraft:obsidian
setblock 109 264 646 minecraft:white_concrete
setblock 111 264 604 minecraft:amethyst_block
fill 114 264 604 114 269 604 minecraft:obsidian
fill 116 264 604 116 307 604 minecraft:obsidian
fill 124 264 646 124 269 646 minecraft:obsidian
fill 130 264 604 130 269 604 minecraft:obsidian
setblock 136 264 612 minecraft:amethyst_block
fill 136 264 614 136 269 614 minecraft:obsidian
fill 136 264 630 136 269 630 minecraft:obsidian
fill 94 265 622 94 270 622 minecraft:obsidian
fill 94 265 632 94 278 632 minecraft:obsidian
fill 102 265 604 102 290 604 minecraft:obsidian
fill 109 265 646 109 307 646 minecraft:obsidian
fill 111 265 604 111 280 604 minecraft:obsidian
schedule function dropper:buildpart/146_2 1t
