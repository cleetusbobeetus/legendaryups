fill 533 125 264 534 126 265 minecraft:white_concrete
fill 533 125 266 534 125 267 minecraft:black_concrete
fill 533 125 268 534 125 269 minecraft:white_concrete
fill 535 125 229 536 125 229 minecraft:black_concrete
fill 535 125 230 536 125 231 minecraft:white_concrete
fill 535 125 232 536 126 233 minecraft:black_concrete
fill 535 125 234 536 126 235 minecraft:white_concrete
fill 535 125 236 536 126 237 minecraft:black_concrete
fill 535 125 238 536 126 239 minecraft:white_concrete
fill 535 125 240 536 126 241 minecraft:black_concrete
fill 535 125 242 536 126 243 minecraft:white_concrete
fill 535 125 244 536 125 244 minecraft:black_concrete
fill 535 125 252 536 125 253 minecraft:black_concrete
fill 535 125 254 536 126 255 minecraft:white_concrete
fill 535 125 256 536 126 257 minecraft:black_concrete
fill 535 125 258 536 126 259 minecraft:white_concrete
fill 535 125 260 536 126 261 minecraft:black_concrete
fill 535 125 262 536 126 263 minecraft:white_concrete
fill 535 125 264 536 126 265 minecraft:black_concrete
fill 535 125 266 536 125 267 minecraft:white_concrete
fill 535 125 268 536 125 269 minecraft:black_concrete
setblock 536 125 245 minecraft:black_concrete
setblock 536 125 251 minecraft:white_concrete
fill 537 125 229 538 125 229 minecraft:white_concrete
fill 537 125 230 538 125 231 minecraft:black_concrete
fill 537 125 232 538 126 233 minecraft:white_concrete
fill 537 125 234 538 126 235 minecraft:black_concrete
fill 537 125 236 538 126 237 minecraft:white_concrete
fill 537 125 238 538 126 239 minecraft:black_concrete
fill 537 125 240 538 126 241 minecraft:white_concrete
fill 537 125 242 538 126 243 minecraft:black_concrete
fill 537 125 244 538 125 245 minecraft:white_concrete
fill 537 125 251 538 125 251 minecraft:black_concrete
fill 537 125 252 538 126 253 minecraft:white_concrete
fill 537 125 254 538 126 255 minecraft:black_concrete
fill 537 125 256 538 126 257 minecraft:white_concrete
fill 537 125 258 538 126 259 minecraft:black_concrete
fill 537 125 260 538 126 261 minecraft:white_concrete
fill 537 125 262 538 126 263 minecraft:black_concrete
fill 537 125 264 538 126 265 minecraft:white_concrete
fill 537 125 266 538 125 267 minecraft:black_concrete
fill 537 125 268 538 125 269 minecraft:white_concrete
fill 538 125 246 538 125 247 minecraft:black_concrete
setblock 538 125 249 minecraft:white_concrete
setblock 538 125 250 minecraft:black_concrete
fill 539 125 229 540 125 229 minecraft:black_concrete
fill 539 125 230 540 125 231 minecraft:white_concrete
fill 539 125 232 540 126 233 minecraft:black_concrete
fill 539 125 234 540 126 235 minecraft:white_concrete
fill 539 125 236 540 126 237 minecraft:black_concrete
fill 539 125 238 540 126 239 minecraft:white_concrete
fill 539 125 240 540 126 241 minecraft:black_concrete
fill 539 125 242 540 126 243 minecraft:white_concrete
fill 539 125 244 540 126 245 minecraft:black_concrete
fill 539 125 246 540 125 247 minecraft:white_concrete
fill 539 125 248 540 125 249 minecraft:black_concrete
fill 539 125 250 540 126 251 minecraft:white_concrete
fill 539 125 252 540 126 253 minecraft:black_concrete
fill 539 125 254 540 126 255 minecraft:white_concrete
fill 539 125 256 540 126 257 minecraft:black_concrete
fill 539 125 258 540 126 259 minecraft:white_concrete
fill 539 125 260 540 126 261 minecraft:black_concrete
fill 539 125 262 540 126 263 minecraft:white_concrete
fill 539 125 264 540 126 265 minecraft:black_concrete
fill 539 125 266 540 125 267 minecraft:white_concrete
fill 539 125 268 540 125 269 minecraft:black_concrete
fill 541 125 229 542 125 229 minecraft:white_concrete
fill 541 125 230 542 125 231 minecraft:black_concrete
fill 541 125 232 542 126 233 minecraft:white_concrete
fill 541 125 234 542 126 235 minecraft:black_concrete
fill 541 125 236 542 126 237 minecraft:white_concrete
fill 541 125 238 542 126 239 minecraft:black_concrete
fill 541 125 240 542 126 241 minecraft:white_concrete
fill 541 125 242 542 126 243 minecraft:black_concrete
fill 541 125 244 542 126 245 minecraft:white_concrete
fill 541 125 246 542 126 247 minecraft:black_concrete
fill 541 125 248 542 126 249 minecraft:white_concrete
fill 541 125 250 542 126 251 minecraft:black_concrete
fill 541 125 252 542 126 253 minecraft:white_concrete
fill 541 125 254 542 126 255 minecraft:black_concrete
fill 541 125 256 542 126 257 minecraft:white_concrete
fill 541 125 258 542 126 259 minecraft:black_concrete
fill 541 125 260 542 126 261 minecraft:white_concrete
fill 541 125 262 542 126 263 minecraft:black_concrete
fill 541 125 264 542 126 265 minecraft:white_concrete
fill 541 125 266 542 125 267 minecraft:black_concrete
fill 541 125 268 542 125 269 minecraft:white_concrete
fill 543 125 229 544 125 229 minecraft:black_concrete
fill 543 125 230 544 125 231 minecraft:white_concrete
fill 543 125 232 544 126 233 minecraft:black_concrete
fill 543 125 234 544 126 235 minecraft:white_concrete
fill 543 125 236 544 126 237 minecraft:black_concrete
fill 543 125 238 544 126 239 minecraft:white_concrete
fill 543 125 240 544 126 241 minecraft:black_concrete
fill 543 125 242 544 126 243 minecraft:white_concrete
fill 543 125 244 544 126 245 minecraft:black_concrete
fill 543 125 246 544 126 247 minecraft:white_concrete
fill 543 125 248 544 126 249 minecraft:black_concrete
fill 543 125 250 544 126 251 minecraft:white_concrete
fill 543 125 252 544 126 253 minecraft:black_concrete
fill 543 125 254 544 126 255 minecraft:white_concrete
fill 543 125 256 544 126 257 minecraft:black_concrete
fill 543 125 258 544 126 259 minecraft:white_concrete
fill 543 125 260 544 126 261 minecraft:black_concrete
fill 543 125 262 544 126 263 minecraft:white_concrete
fill 543 125 264 544 126 265 minecraft:black_concrete
fill 543 125 266 544 125 267 minecraft:white_concrete
fill 543 125 268 544 125 269 minecraft:black_concrete
fill 545 125 229 546 125 229 minecraft:white_concrete
fill 545 125 230 546 125 231 minecraft:black_concrete
fill 545 125 232 546 126 233 minecraft:white_concrete
fill 545 125 234 546 126 235 minecraft:black_concrete
fill 545 125 236 546 126 237 minecraft:white_concrete
fill 545 125 238 546 126 239 minecraft:black_concrete
fill 545 125 240 546 126 241 minecraft:white_concrete
fill 545 125 242 546 126 243 minecraft:black_concrete
fill 545 125 244 546 126 245 minecraft:white_concrete
fill 545 125 246 546 126 247 minecraft:black_concrete
fill 545 125 248 546 126 249 minecraft:white_concrete
fill 545 125 250 546 126 251 minecraft:black_concrete
fill 545 125 252 546 126 253 minecraft:white_concrete
fill 545 125 254 546 126 255 minecraft:black_concrete
fill 545 125 256 546 126 257 minecraft:white_concrete
fill 545 125 258 546 126 259 minecraft:black_concrete
fill 545 125 260 546 126 261 minecraft:white_concrete
fill 545 125 262 546 126 263 minecraft:black_concrete
fill 545 125 264 546 126 265 minecraft:white_concrete
fill 545 125 266 546 125 267 minecraft:black_concrete
fill 545 125 268 546 125 269 minecraft:white_concrete
fill 547 125 229 548 125 229 minecraft:black_concrete
fill 547 125 230 548 125 231 minecraft:white_concrete
fill 547 125 232 548 126 233 minecraft:black_concrete
fill 547 125 234 548 126 235 minecraft:white_concrete
fill 547 125 236 548 126 237 minecraft:black_concrete
fill 547 125 238 548 126 239 minecraft:white_concrete
fill 547 125 240 548 126 241 minecraft:black_concrete
fill 547 125 242 548 126 243 minecraft:white_concrete
fill 547 125 244 548 126 245 minecraft:black_concrete
fill 547 125 246 548 126 247 minecraft:white_concrete
fill 547 125 248 548 126 249 minecraft:black_concrete
fill 547 125 250 548 126 251 minecraft:white_concrete
fill 547 125 252 548 126 253 minecraft:black_concrete
fill 547 125 254 548 126 255 minecraft:white_concrete
fill 547 125 256 548 126 257 minecraft:black_concrete
fill 547 125 258 548 126 259 minecraft:white_concrete
fill 547 125 260 548 126 261 minecraft:black_concrete
fill 547 125 262 548 126 263 minecraft:white_concrete
fill 547 125 264 548 126 265 minecraft:black_concrete
fill 547 125 266 548 125 267 minecraft:white_concrete
fill 547 125 268 548 125 269 minecraft:black_concrete
fill 549 125 229 550 125 229 minecraft:white_concrete
fill 549 125 230 550 125 231 minecraft:black_concrete
fill 549 125 232 550 126 233 minecraft:white_concrete
fill 549 125 234 550 126 235 minecraft:black_concrete
fill 549 125 236 550 126 237 minecraft:white_concrete
fill 549 125 238 550 126 239 minecraft:black_concrete
fill 549 125 240 550 126 241 minecraft:white_concrete
fill 549 125 242 550 126 243 minecraft:black_concrete
fill 549 125 244 550 126 245 minecraft:white_concrete
fill 549 125 246 550 126 247 minecraft:black_concrete
fill 549 125 248 550 126 249 minecraft:white_concrete
fill 549 125 250 550 126 251 minecraft:black_concrete
fill 549 125 252 550 126 253 minecraft:white_concrete
fill 549 125 254 550 126 255 minecraft:black_concrete
fill 549 125 256 550 126 257 minecraft:white_concrete
fill 549 125 258 550 126 259 minecraft:black_concrete
fill 549 125 260 550 126 261 minecraft:white_concrete
fill 549 125 262 550 126 263 minecraft:black_concrete
fill 549 125 264 550 126 265 minecraft:white_concrete
fill 549 125 266 550 125 267 minecraft:black_concrete
fill 549 125 268 550 125 269 minecraft:white_concrete
fill 551 125 229 552 125 229 minecraft:black_concrete
fill 551 125 230 552 125 231 minecraft:white_concrete
fill 551 125 232 552 126 233 minecraft:black_concrete
fill 551 125 234 552 126 235 minecraft:white_concrete
fill 551 125 236 552 126 237 minecraft:black_concrete
fill 551 125 238 552 126 239 minecraft:white_concrete
fill 551 125 240 552 126 241 minecraft:black_concrete
fill 551 125 242 552 126 243 minecraft:white_concrete
fill 551 125 244 552 126 245 minecraft:black_concrete
fill 551 125 246 552 126 247 minecraft:white_concrete
fill 551 125 248 552 126 249 minecraft:black_concrete
fill 551 125 250 552 126 251 minecraft:white_concrete
fill 551 125 252 552 126 253 minecraft:black_concrete
fill 551 125 254 552 126 255 minecraft:white_concrete
fill 551 125 256 552 126 257 minecraft:black_concrete
fill 551 125 258 552 126 259 minecraft:white_concrete
fill 551 125 260 552 126 261 minecraft:black_concrete
fill 551 125 262 552 126 263 minecraft:white_concrete
fill 551 125 264 552 126 265 minecraft:black_concrete
fill 551 125 266 552 125 267 minecraft:white_concrete
fill 551 125 268 552 125 269 minecraft:black_concrete
fill 553 125 229 554 125 229 minecraft:white_concrete
fill 553 125 230 554 125 231 minecraft:black_concrete
fill 553 125 232 554 126 233 minecraft:white_concrete
fill 553 125 234 554 126 235 minecraft:black_concrete
fill 553 125 236 554 126 237 minecraft:white_concrete
fill 553 125 238 554 126 239 minecraft:black_concrete
fill 553 125 240 554 126 241 minecraft:white_concrete
fill 553 125 242 554 126 243 minecraft:black_concrete
fill 553 125 244 554 126 245 minecraft:white_concrete
fill 553 125 246 554 126 247 minecraft:black_concrete
fill 553 125 248 554 126 249 minecraft:white_concrete
fill 553 125 250 554 126 251 minecraft:black_concrete
fill 553 125 252 554 126 253 minecraft:white_concrete
fill 553 125 254 554 126 255 minecraft:black_concrete
fill 553 125 256 554 126 257 minecraft:white_concrete
fill 553 125 258 554 126 259 minecraft:black_concrete
fill 553 125 260 554 126 261 minecraft:white_concrete
fill 553 125 262 554 126 263 minecraft:black_concrete
fill 553 125 264 554 126 265 minecraft:white_concrete
fill 553 125 266 554 125 267 minecraft:black_concrete
fill 553 125 268 554 125 269 minecraft:white_concrete
fill 555 125 229 556 125 229 minecraft:black_concrete
fill 555 125 230 556 125 231 minecraft:white_concrete
fill 555 125 232 556 125 233 minecraft:black_concrete
fill 555 125 234 556 125 235 minecraft:white_concrete
fill 555 125 236 556 125 237 minecraft:black_concrete
fill 555 125 238 556 125 239 minecraft:white_concrete
fill 555 125 240 556 125 241 minecraft:black_concrete
fill 555 125 242 556 125 243 minecraft:white_concrete
fill 555 125 244 556 125 245 minecraft:black_concrete
fill 555 125 246 556 125 247 minecraft:white_concrete
fill 555 125 248 556 125 249 minecraft:black_concrete
fill 555 125 250 556 125 251 minecraft:white_concrete
fill 555 125 252 556 125 253 minecraft:black_concrete
fill 555 125 254 556 125 255 minecraft:white_concrete
fill 555 125 256 556 125 257 minecraft:black_concrete
fill 555 125 258 556 125 259 minecraft:white_concrete
fill 555 125 260 556 125 261 minecraft:black_concrete
fill 555 125 262 556 125 263 minecraft:white_concrete
fill 555 125 264 556 125 265 minecraft:black_concrete
fill 555 125 266 556 125 267 minecraft:white_concrete
fill 555 125 268 556 125 269 minecraft:black_concrete
fill 557 125 229 558 125 229 minecraft:white_concrete
fill 557 125 230 558 125 231 minecraft:black_concrete
fill 557 125 232 558 125 233 minecraft:white_concrete
fill 557 125 234 558 125 235 minecraft:black_concrete
fill 557 125 236 558 125 237 minecraft:white_concrete
fill 557 125 238 558 125 239 minecraft:black_concrete
fill 557 125 240 558 125 241 minecraft:white_concrete
fill 557 125 242 558 125 243 minecraft:black_concrete
fill 557 125 244 558 125 245 minecraft:white_concrete
fill 557 125 246 558 125 247 minecraft:black_concrete
fill 557 125 248 558 125 249 minecraft:white_concrete
fill 557 125 250 558 125 251 minecraft:black_concrete
fill 557 125 252 558 125 253 minecraft:white_concrete
fill 557 125 254 558 125 255 minecraft:black_concrete
fill 557 125 256 558 125 257 minecraft:white_concrete
fill 557 125 258 558 125 259 minecraft:black_concrete
fill 557 125 260 558 125 261 minecraft:white_concrete
fill 557 125 262 558 125 263 minecraft:black_concrete
fill 557 125 264 558 125 265 minecraft:white_concrete
fill 557 125 266 558 125 267 minecraft:black_concrete
fill 557 125 268 558 125 269 minecraft:white_concrete
setblock 559 125 246 minecraft:mossy_stone_bricks
setblock 559 125 247 minecraft:stone_bricks
fill 517 126 228 517 126 229 minecraft:white_concrete
fill 517 126 230 517 126 231 minecraft:black_concrete
fill 517 126 232 517 126 233 minecraft:white_concrete
fill 517 126 234 517 126 235 minecraft:black_concrete
fill 517 126 236 517 126 237 minecraft:white_concrete
fill 517 126 238 517 126 239 minecraft:black_concrete
fill 517 126 240 517 126 241 minecraft:white_concrete
fill 517 126 242 517 126 243 minecraft:black_concrete
fill 517 126 244 517 126 245 minecraft:white_concrete
fill 517 126 246 517 126 247 minecraft:black_concrete
fill 517 126 248 517 126 249 minecraft:white_concrete
fill 517 126 250 517 126 251 minecraft:black_concrete
fill 517 126 252 517 126 253 minecraft:white_concrete
fill 517 126 254 517 126 255 minecraft:black_concrete
fill 517 126 256 517 126 257 minecraft:white_concrete
fill 517 126 258 517 126 259 minecraft:black_concrete
fill 517 126 260 517 126 261 minecraft:white_concrete
fill 517 126 262 517 126 263 minecraft:black_concrete
fill 517 126 264 517 126 265 minecraft:white_concrete
fill 517 126 266 517 126 267 minecraft:black_concrete
fill 517 126 268 517 126 269 minecraft:white_concrete
fill 517 126 270 518 126 270 minecraft:black_concrete
setblock 518 126 228 minecraft:white_concrete
fill 518 126 229 520 126 269 minecraft:dark_oak_planks
fill 519 126 228 520 126 228 minecraft:black_concrete
fill 519 126 270 520 126 270 minecraft:white_concrete
fill 521 126 228 522 126 228 minecraft:white_concrete
fill 521 126 229 558 126 231 minecraft:dark_oak_planks
fill 521 126 266 522 126 266 minecraft:black_concrete
fill 521 126 267 558 126 269 minecraft:dark_oak_planks
fill 521 126 270 522 126 270 minecraft:black_concrete
fill 523 126 228 524 126 228 minecraft:black_concrete
fill 523 126 266 524 126 266 minecraft:white_concrete
fill 523 126 270 524 126 270 minecraft:white_concrete
fill 525 126 228 526 126 228 minecraft:white_concrete
fill 525 126 266 526 126 266 minecraft:black_concrete
fill 525 126 270 526 126 270 minecraft:black_concrete
fill 527 126 228 528 126 228 minecraft:black_concrete
fill 527 126 266 528 126 266 minecraft:white_concrete
fill 527 126 270 528 126 270 minecraft:white_concrete
fill 529 126 228 530 126 228 minecraft:white_concrete
fill 529 126 266 530 126 266 minecraft:black_concrete
fill 529 126 270 530 126 270 minecraft:black_concrete
fill 531 126 228 532 126 228 minecraft:black_concrete
fill 531 126 244 531 126 245 minecraft:black_concrete
setblock 531 126 246 minecraft:white_concrete
fill 531 126 247 531 126 249 minecraft:spruce_planks
fill 531 126 250 531 126 251 minecraft:white_concrete
fill 531 126 266 532 126 266 minecraft:white_concrete
fill 531 126 270 532 126 270 minecraft:white_concrete
setblock 532 126 244 minecraft:black_concrete
fill 532 126 245 532 126 247 minecraft:spruce_planks
fill 532 126 249 532 126 251 minecraft:spruce_planks
fill 533 126 228 534 126 228 minecraft:white_concrete
setblock 533 126 244 minecraft:white_concrete
fill 533 126 245 534 126 245 minecraft:spruce_planks
fill 533 126 251 534 126 251 minecraft:spruce_planks
fill 533 126 252 533 126 253 minecraft:white_concrete
fill 533 126 266 534 126 266 minecraft:black_concrete
fill 533 126 270 534 126 270 minecraft:black_concrete
fill 534 126 244 536 126 244 minecraft:spruce_planks
fill 534 126 252 536 126 252 minecraft:spruce_planks
setblock 534 126 253 minecraft:white_concrete
fill 535 126 228 536 126 228 minecraft:black_concrete
fill 535 126 253 536 126 253 minecraft:black_concrete
fill 535 126 266 536 126 266 minecraft:white_concrete
fill 535 126 270 536 126 270 minecraft:white_concrete
fill 536 126 245 538 126 245 minecraft:spruce_planks
fill 536 126 251 538 126 251 minecraft:spruce_planks
fill 537 126 228 538 126 228 minecraft:white_concrete
fill 537 126 244 538 126 244 minecraft:white_concrete
fill 537 126 266 538 126 266 minecraft:black_concrete
fill 537 126 270 538 126 270 minecraft:black_concrete
fill 538 126 246 538 126 247 minecraft:spruce_planks
fill 538 126 249 538 126 250 minecraft:spruce_planks
fill 539 126 228 540 126 228 minecraft:black_concrete
fill 539 126 246 540 126 246 minecraft:white_concrete
fill 539 126 247 539 126 249 minecraft:spruce_planks
fill 539 126 266 540 126 266 minecraft:white_concrete
fill 539 126 270 540 126 270 minecraft:white_concrete
setblock 540 126 247 minecraft:white_concrete
fill 540 126 248 540 126 249 minecraft:black_concrete
fill 541 126 228 542 126 228 minecraft:white_concrete
fill 541 126 266 542 126 266 minecraft:black_concrete
fill 541 126 270 542 126 270 minecraft:black_concrete
fill 543 126 228 544 126 228 minecraft:black_concrete
fill 543 126 266 544 126 266 minecraft:white_concrete
fill 543 126 270 544 126 270 minecraft:white_concrete
fill 545 126 228 546 126 228 minecraft:white_concrete
fill 545 126 266 546 126 266 minecraft:black_concrete
fill 545 126 270 546 126 270 minecraft:black_concrete
fill 547 126 228 548 126 228 minecraft:black_concrete
fill 547 126 266 548 126 266 minecraft:white_concrete
fill 547 126 270 548 126 270 minecraft:white_concrete
fill 549 126 228 550 126 228 minecraft:white_concrete
fill 549 126 266 550 126 266 minecraft:black_concrete
fill 549 126 270 550 126 270 minecraft:black_concrete
fill 551 126 228 552 126 228 minecraft:black_concrete
fill 551 126 266 552 126 266 minecraft:white_concrete
fill 551 126 270 552 126 270 minecraft:white_concrete
fill 553 126 228 554 126 228 minecraft:white_concrete
fill 553 126 266 554 126 266 minecraft:black_concrete
fill 553 126 270 554 126 270 minecraft:black_concrete
fill 555 126 228 556 126 228 minecraft:black_concrete
fill 555 126 232 555 126 233 minecraft:black_concrete
fill 555 126 234 555 126 235 minecraft:white_concrete
fill 555 126 236 555 126 237 minecraft:black_concrete
fill 555 126 238 555 126 239 minecraft:white_concrete
fill 555 126 240 555 126 241 minecraft:black_concrete
fill 555 126 242 555 126 243 minecraft:white_concrete
fill 555 126 244 555 126 245 minecraft:black_concrete
fill 555 126 246 555 126 247 minecraft:white_concrete
fill 555 126 248 555 126 249 minecraft:black_concrete
fill 555 126 250 555 126 251 minecraft:white_concrete
fill 555 126 252 555 126 253 minecraft:black_concrete
fill 555 126 254 555 126 255 minecraft:white_concrete
fill 555 126 256 555 126 257 minecraft:black_concrete
fill 555 126 258 555 126 259 minecraft:white_concrete
fill 555 126 260 555 126 261 minecraft:black_concrete
fill 555 126 262 555 126 263 minecraft:white_concrete
fill 555 126 264 555 126 265 minecraft:black_concrete
setblock 555 126 266 minecraft:white_concrete
fill 555 126 270 556 126 270 minecraft:white_concrete
fill 556 126 232 558 126 266 minecraft:dark_oak_planks
fill 557 126 228 558 126 228 minecraft:white_concrete
fill 557 126 270 558 126 270 minecraft:black_concrete
fill 559 126 228 559 126 229 minecraft:black_concrete
fill 559 126 230 559 126 231 minecraft:white_concrete
fill 559 126 232 559 126 233 minecraft:black_concrete
fill 559 126 234 559 126 235 minecraft:white_concrete
fill 559 126 236 559 126 237 minecraft:black_concrete
fill 559 126 238 559 126 239 minecraft:white_concrete
fill 559 126 240 559 126 241 minecraft:black_concrete
fill 559 126 242 559 126 243 minecraft:white_concrete
fill 559 126 244 559 126 245 minecraft:black_concrete
fill 559 126 246 559 126 247 minecraft:white_concrete
fill 559 126 248 559 126 249 minecraft:black_concrete
fill 559 126 250 559 126 251 minecraft:white_concrete
fill 559 126 252 559 126 253 minecraft:black_concrete
fill 559 126 254 559 126 255 minecraft:white_concrete
fill 559 126 256 559 126 257 minecraft:black_concrete
fill 559 126 258 559 126 259 minecraft:white_concrete
fill 559 126 260 559 126 261 minecraft:black_concrete
fill 559 126 262 559 126 263 minecraft:white_concrete
fill 559 126 264 559 126 265 minecraft:black_concrete
fill 559 126 266 559 126 267 minecraft:white_concrete
fill 559 126 268 559 126 269 minecraft:black_concrete
setblock 559 126 270 minecraft:white_concrete
fill 517 127 228 517 127 270 minecraft:purple_terracotta
fill 518 127 228 559 127 228 minecraft:purple_terracotta
fill 518 127 270 559 127 270 minecraft:purple_terracotta
fill 559 127 229 559 127 269 minecraft:purple_terracotta
setblock 517 128 228 minecraft:magenta_terracotta
fill 517 128 229 517 129 231 minecraft:purple_terracotta
setblock 517 128 232 minecraft:magenta_terracotta
fill 517 128 233 517 128 235 minecraft:purple_terracotta
setblock 517 128 236 minecraft:magenta_terracotta
fill 517 128 237 517 129 239 minecraft:purple_terracotta
setblock 517 128 240 minecraft:magenta_terracotta
fill 517 128 241 517 129 243 minecraft:purple_terracotta
setblock 517 128 244 minecraft:magenta_terracotta
fill 517 128 245 517 129 247 minecraft:purple_terracotta
setblock 517 128 248 minecraft:magenta_terracotta
fill 517 128 249 517 129 251 minecraft:purple_terracotta
setblock 517 128 252 minecraft:magenta_terracotta
fill 517 128 253 517 129 255 minecraft:purple_terracotta
setblock 517 128 256 minecraft:magenta_terracotta
fill 517 128 257 517 129 259 minecraft:purple_terracotta
setblock 517 128 260 minecraft:magenta_terracotta
fill 517 128 261 517 129 263 minecraft:purple_terracotta
setblock 517 128 264 minecraft:light_gray_terracotta
fill 517 128 265 517 129 267 minecraft:purple_terracotta
setblock 517 128 268 minecraft:magenta_terracotta
fill 517 128 269 517 212 269 minecraft:purple_terracotta
setblock 517 128 270 minecraft:magenta_terracotta
fill 518 128 228 520 129 228 minecraft:purple_terracotta
fill 518 128 270 520 129 270 minecraft:purple_terracotta
fill 519 128 244 519 128 245 minecraft:spruce_planks
setblock 520 128 231 minecraft:light[level=11]
setblock 520 128 239 minecraft:light[level=11]
setblock 520 128 247 minecraft:light[level=11]
setblock 520 128 255 minecraft:light[level=11]
setblock 520 128 263 minecraft:light[level=11]
setblock 521 128 228 minecraft:magenta_terracotta
setblock 521 128 270 minecraft:magenta_terracotta
fill 522 128 228 524 129 228 minecraft:purple_terracotta
fill 522 128 270 524 129 270 minecraft:purple_terracotta
setblock 525 128 228 minecraft:magenta_terracotta
setblock 525 128 270 minecraft:magenta_terracotta
fill 526 128 228 528 129 228 minecraft:purple_terracotta
fill 526 128 270 528 129 270 minecraft:purple_terracotta
setblock 528 128 231 minecraft:light[level=11]
setblock 528 128 239 minecraft:light[level=11]
setblock 528 128 247 minecraft:light[level=11]
setblock 528 128 255 minecraft:light[level=11]
setblock 528 128 263 minecraft:light[level=11]
setblock 529 128 228 minecraft:magenta_terracotta
setblock 529 128 270 minecraft:magenta_terracotta
fill 530 128 228 532 129 228 minecraft:purple_terracotta
fill 530 128 270 532 129 270 minecraft:purple_terracotta
setblock 533 128 228 minecraft:magenta_terracotta
setblock 533 128 270 minecraft:magenta_terracotta
setblock 534 128 228 minecraft:light_gray_terracotta
fill 534 128 270 536 129 270 minecraft:purple_terracotta
fill 535 128 228 536 129 228 minecraft:purple_terracotta
setblock 536 128 231 minecraft:light[level=11]
setblock 536 128 239 minecraft:light[level=11]
setblock 536 128 255 minecraft:light[level=11]
setblock 536 128 263 minecraft:light[level=11]
setblock 537 128 228 minecraft:magenta_terracotta
setblock 537 128 270 minecraft:magenta_terracotta
fill 538 128 228 540 129 228 minecraft:purple_terracotta
fill 538 128 270 540 129 270 minecraft:purple_terracotta
setblock 541 128 228 minecraft:magenta_terracotta
setblock 541 128 270 minecraft:magenta_terracotta
fill 542 128 228 544 129 228 minecraft:purple_terracotta
fill 542 128 270 544 129 270 minecraft:purple_terracotta
setblock 544 128 231 minecraft:light[level=11]
setblock 544 128 239 minecraft:light[level=11]
setblock 544 128 247 minecraft:light[level=11]
setblock 544 128 255 minecraft:light[level=11]
setblock 544 128 263 minecraft:light[level=11]
setblock 545 128 228 minecraft:magenta_terracotta
setblock 545 128 270 minecraft:magenta_terracotta
fill 546 128 228 548 129 228 minecraft:purple_terracotta
fill 546 128 270 548 129 270 minecraft:purple_terracotta
setblock 549 128 228 minecraft:magenta_terracotta
setblock 549 128 270 minecraft:magenta_terracotta
fill 550 128 228 552 129 228 minecraft:purple_terracotta
fill 550 128 270 552 129 270 minecraft:purple_terracotta
setblock 552 128 231 minecraft:light[level=11]
setblock 552 128 239 minecraft:light[level=11]
setblock 552 128 247 minecraft:light[level=11]
setblock 552 128 255 minecraft:light[level=11]
setblock 552 128 263 minecraft:light[level=11]
setblock 553 128 228 minecraft:magenta_terracotta
setblock 553 128 270 minecraft:magenta_terracotta
fill 554 128 228 556 129 228 minecraft:purple_terracotta
fill 554 128 270 556 129 270 minecraft:purple_terracotta
setblock 557 128 228 minecraft:magenta_terracotta
setblock 557 128 270 minecraft:magenta_terracotta
fill 558 128 228 558 212 228 minecraft:purple_terracotta
fill 558 128 270 559 129 270 minecraft:purple_terracotta
setblock 559 128 228 minecraft:magenta_terracotta
fill 559 128 229 559 129 231 minecraft:purple_terracotta
setblock 559 128 232 minecraft:magenta_terracotta
fill 559 128 233 559 129 235 minecraft:purple_terracotta
setblock 559 128 236 minecraft:magenta_terracotta
fill 559 128 237 559 129 239 minecraft:purple_terracotta
setblock 559 128 240 minecraft:magenta_terracotta
fill 559 128 241 559 129 243 minecraft:purple_terracotta
setblock 559 128 244 minecraft:magenta_terracotta
fill 559 128 245 559 129 247 minecraft:purple_terracotta
setblock 559 128 248 minecraft:magenta_terracotta
fill 559 128 249 559 129 251 minecraft:purple_terracotta
setblock 559 128 252 minecraft:magenta_terracotta
fill 559 128 253 559 129 255 minecraft:purple_terracotta
setblock 559 128 256 minecraft:magenta_terracotta
fill 559 128 257 559 129 259 minecraft:purple_terracotta
setblock 559 128 260 minecraft:magenta_terracotta
fill 559 128 261 559 129 263 minecraft:purple_terracotta
setblock 559 128 264 minecraft:magenta_terracotta
fill 559 128 265 559 129 267 minecraft:purple_terracotta
setblock 559 128 268 minecraft:magenta_terracotta
fill 559 128 269 559 212 269 minecraft:purple_terracotta
fill 517 129 228 517 131 228 minecraft:purple_terracotta
fill 517 129 232 517 129 234 minecraft:purple_terracotta
setblock 517 129 235 minecraft:light_gray_terracotta
fill 517 129 236 517 131 236 minecraft:purple_terracotta
fill 517 129 240 517 131 240 minecraft:purple_terracotta
fill 517 129 244 517 131 244 minecraft:purple_terracotta
fill 517 129 248 517 131 248 minecraft:purple_terracotta
fill 517 129 252 517 131 252 minecraft:purple_terracotta
fill 517 129 256 517 130 256 minecraft:purple_terracotta
fill 517 129 260 517 131 260 minecraft:purple_terracotta
fill 517 129 264 517 131 264 minecraft:purple_terracotta
fill 517 129 268 517 131 268 minecraft:purple_terracotta
setblock 517 129 270 minecraft:purple_terracotta
fill 518 129 244 519 129 245 minecraft:dark_oak_planks
fill 519 129 246 519 129 247 minecraft:spruce_planks
fill 521 129 228 521 131 228 minecraft:purple_terracotta
fill 521 129 270 521 131 270 minecraft:purple_terracotta
fill 525 129 228 525 131 228 minecraft:purple_terracotta
fill 525 129 270 525 131 270 minecraft:purple_terracotta
fill 529 129 228 529 131 228 minecraft:purple_terracotta
fill 529 129 270 529 131 270 minecraft:purple_terracotta
fill 533 129 228 534 131 228 minecraft:purple_terracotta
fill 533 129 270 533 131 270 minecraft:purple_terracotta
fill 537 129 228 537 131 228 minecraft:purple_terracotta
fill 537 129 270 537 131 270 minecraft:purple_terracotta
fill 541 129 228 541 131 228 minecraft:purple_terracotta
fill 541 129 270 541 131 270 minecraft:purple_terracotta
fill 545 129 228 545 131 228 minecraft:purple_terracotta
fill 545 129 270 545 131 270 minecraft:purple_terracotta
fill 549 129 228 549 131 228 minecraft:purple_terracotta
fill 549 129 270 549 131 270 minecraft:purple_terracotta
fill 553 129 228 553 131 228 minecraft:purple_terracotta
fill 553 129 270 553 131 270 minecraft:purple_terracotta
fill 557 129 228 557 131 228 minecraft:purple_terracotta
fill 557 129 270 557 131 270 minecraft:purple_terracotta
setblock 559 129 228 minecraft:purple_terracotta
fill 559 129 232 559 131 232 minecraft:purple_terracotta
fill 559 129 236 559 131 236 minecraft:purple_terracotta
fill 559 129 240 559 131 240 minecraft:purple_terracotta
fill 559 129 244 559 131 244 minecraft:purple_terracotta
fill 559 129 248 559 131 248 minecraft:purple_terracotta
fill 559 129 252 559 131 252 minecraft:purple_terracotta
fill 559 129 256 559 131 256 minecraft:purple_terracotta
fill 559 129 260 559 131 260 minecraft:purple_terracotta
fill 559 129 264 559 131 264 minecraft:purple_terracotta
fill 559 129 268 559 131 268 minecraft:purple_terracotta
fill 517 130 229 517 212 229 minecraft:purple_terracotta
setblock 517 130 230 minecraft:magenta_terracotta
fill 517 130 231 517 131 233 minecraft:purple_terracotta
setblock 517 130 234 minecraft:magenta_terracotta
fill 517 130 235 517 212 235 minecraft:purple_terracotta
fill 517 130 237 517 212 237 minecraft:purple_terracotta
setblock 517 130 238 minecraft:magenta_terracotta
fill 517 130 239 517 170 239 minecraft:purple_terracotta
fill 517 130 241 517 212 241 minecraft:purple_terracotta
setblock 517 130 242 minecraft:magenta_terracotta
fill 517 130 243 517 175 243 minecraft:purple_terracotta
fill 517 130 245 517 212 245 minecraft:purple_terracotta
setblock 517 130 246 minecraft:magenta_terracotta
fill 517 130 247 517 212 247 minecraft:purple_terracotta
fill 517 130 249 517 212 249 minecraft:purple_terracotta
setblock 517 130 250 minecraft:magenta_terracotta
fill 517 130 251 517 212 251 minecraft:purple_terracotta
fill 517 130 253 517 212 253 minecraft:purple_terracotta
setblock 517 130 254 minecraft:magenta_terracotta
fill 517 130 255 517 145 255 minecraft:purple_terracotta
fill 517 130 257 517 212 257 minecraft:purple_terracotta
setblock 517 130 258 minecraft:magenta_terracotta
fill 517 130 259 517 172 259 minecraft:purple_terracotta
fill 517 130 261 517 212 261 minecraft:purple_terracotta
setblock 517 130 262 minecraft:magenta_terracotta
fill 517 130 263 517 212 263 minecraft:purple_terracotta
fill 517 130 265 517 212 265 minecraft:purple_terracotta
setblock 517 130 266 minecraft:magenta_terracotta
fill 517 130 267 517 212 267 minecraft:purple_terracotta
setblock 517 130 270 minecraft:magenta_terracotta
setblock 518 130 228 minecraft:purple_terracotta
fill 518 130 246 519 130 247 minecraft:dark_oak_planks
fill 518 130 270 518 212 270 minecraft:purple_terracotta
setblock 519 130 228 minecraft:magenta_terracotta
fill 519 130 248 519 130 249 minecraft:spruce_planks
setblock 519 130 270 minecraft:magenta_terracotta
fill 520 130 228 520 212 228 minecraft:purple_terracotta
setblock 520 130 231 minecraft:light[level=12]
setblock 520 130 238 minecraft:light[level=12]
setblock 520 130 245 minecraft:light[level=12]
setblock 520 130 252 minecraft:light[level=12]
setblock 520 130 259 minecraft:light[level=12]
setblock 520 130 266 minecraft:light[level=12]
fill 520 130 270 520 212 270 minecraft:purple_terracotta
fill 522 130 228 522 212 228 minecraft:purple_terracotta
fill 522 130 270 522 212 270 minecraft:purple_terracotta
setblock 523 130 228 minecraft:magenta_terracotta
setblock 523 130 270 minecraft:magenta_terracotta
fill 524 130 228 524 212 228 minecraft:purple_terracotta
fill 524 130 270 524 208 270 minecraft:purple_terracotta
fill 526 130 228 526 212 228 minecraft:purple_terracotta
fill 526 130 270 526 212 270 minecraft:purple_terracotta
setblock 527 130 228 minecraft:magenta_terracotta
setblock 527 130 231 minecraft:light[level=12]
setblock 527 130 238 minecraft:light[level=12]
setblock 527 130 245 minecraft:light[level=12]
setblock 527 130 252 minecraft:light[level=12]
setblock 527 130 259 minecraft:light[level=12]
setblock 527 130 266 minecraft:light[level=12]
setblock 527 130 270 minecraft:magenta_terracotta
fill 528 130 228 528 212 228 minecraft:purple_terracotta
fill 528 130 270 528 196 270 minecraft:purple_terracotta
fill 530 130 228 530 200 228 minecraft:purple_terracotta
fill 530 130 270 530 138 270 minecraft:purple_terracotta
setblock 531 130 228 minecraft:magenta_terracotta
setblock 531 130 270 minecraft:magenta_terracotta
fill 532 130 228 532 212 228 minecraft:purple_terracotta
fill 532 130 270 532 212 270 minecraft:purple_terracotta
setblock 534 130 231 minecraft:light[level=12]
setblock 534 130 238 minecraft:light[level=12]
setblock 534 130 245 minecraft:light[level=12]
setblock 534 130 252 minecraft:light[level=12]
setblock 534 130 259 minecraft:light[level=12]
setblock 534 130 266 minecraft:light[level=12]
fill 534 130 270 534 212 270 minecraft:purple_terracotta
setblock 535 130 228 minecraft:magenta_terracotta
setblock 535 130 270 minecraft:magenta_terracotta
fill 536 130 228 536 212 228 minecraft:purple_terracotta
fill 536 130 270 536 137 270 minecraft:purple_terracotta
fill 538 130 228 538 194 228 minecraft:purple_terracotta
fill 538 130 270 538 212 270 minecraft:purple_terracotta
setblock 539 130 228 minecraft:magenta_terracotta
setblock 539 130 270 minecraft:magenta_terracotta
fill 540 130 228 540 141 228 minecraft:purple_terracotta
fill 540 130 270 540 212 270 minecraft:purple_terracotta
setblock 541 130 231 minecraft:light[level=12]
setblock 541 130 238 minecraft:light[level=12]
setblock 541 130 245 minecraft:light[level=12]
setblock 541 130 252 minecraft:light[level=12]
setblock 541 130 259 minecraft:light[level=12]
setblock 541 130 266 minecraft:light[level=12]
fill 542 130 228 542 212 228 minecraft:purple_terracotta
fill 542 130 270 542 212 270 minecraft:purple_terracotta
setblock 543 130 228 minecraft:magenta_terracotta
setblock 543 130 270 minecraft:magenta_terracotta
fill 544 130 228 544 212 228 minecraft:purple_terracotta
fill 544 130 270 544 212 270 minecraft:purple_terracotta
fill 546 130 228 546 177 228 minecraft:purple_terracotta
fill 546 130 270 546 212 270 minecraft:purple_terracotta
setblock 547 130 228 minecraft:magenta_terracotta
setblock 547 130 270 minecraft:magenta_terracotta
fill 548 130 228 548 212 228 minecraft:purple_terracotta
setblock 548 130 231 minecraft:light[level=12]
setblock 548 130 238 minecraft:light[level=12]
setblock 548 130 245 minecraft:light[level=12]
setblock 548 130 252 minecraft:light[level=12]
setblock 548 130 259 minecraft:light[level=12]
setblock 548 130 266 minecraft:light[level=12]
fill 548 130 270 548 212 270 minecraft:purple_terracotta
fill 550 130 228 550 159 228 minecraft:purple_terracotta
fill 550 130 270 550 196 270 minecraft:purple_terracotta
setblock 551 130 228 minecraft:magenta_terracotta
setblock 551 130 270 minecraft:magenta_terracotta
fill 552 130 228 552 212 228 minecraft:purple_terracotta
fill 552 130 270 552 212 270 minecraft:purple_terracotta
fill 554 130 228 554 212 228 minecraft:purple_terracotta
fill 554 130 270 554 212 270 minecraft:purple_terracotta
setblock 555 130 228 minecraft:magenta_terracotta
setblock 555 130 231 minecraft:light[level=12]
setblock 555 130 238 minecraft:light[level=12]
setblock 555 130 245 minecraft:light[level=12]
setblock 555 130 252 minecraft:light[level=12]
setblock 555 130 259 minecraft:light[level=12]
setblock 555 130 266 minecraft:light[level=12]
setblock 555 130 270 minecraft:magenta_terracotta
fill 556 130 228 556 212 228 minecraft:purple_terracotta
fill 556 130 270 556 155 270 minecraft:purple_terracotta
fill 558 130 270 558 139 270 minecraft:purple_terracotta
setblock 559 130 228 minecraft:magenta_terracotta
fill 559 130 229 559 202 229 minecraft:purple_terracotta
setblock 559 130 230 minecraft:magenta_terracotta
fill 559 130 231 559 212 231 minecraft:purple_terracotta
fill 559 130 233 559 150 233 minecraft:purple_terracotta
setblock 559 130 234 minecraft:magenta_terracotta
fill 559 130 235 559 190 235 minecraft:purple_terracotta
fill 559 130 237 559 212 237 minecraft:purple_terracotta
setblock 559 130 238 minecraft:magenta_terracotta
fill 559 130 239 559 212 239 minecraft:purple_terracotta
fill 559 130 241 559 179 241 minecraft:purple_terracotta
setblock 559 130 242 minecraft:magenta_terracotta
fill 559 130 243 559 212 243 minecraft:purple_terracotta
fill 559 130 245 559 212 245 minecraft:purple_terracotta
setblock 559 130 246 minecraft:magenta_terracotta
fill 559 130 247 559 178 247 minecraft:purple_terracotta
fill 559 130 249 559 212 249 minecraft:purple_terracotta
setblock 559 130 250 minecraft:magenta_terracotta
fill 559 130 251 559 212 251 minecraft:purple_terracotta
fill 559 130 253 559 212 253 minecraft:purple_terracotta
setblock 559 130 254 minecraft:magenta_terracotta
fill 559 130 255 559 212 255 minecraft:purple_terracotta
fill 559 130 257 559 157 257 minecraft:purple_terracotta
setblock 559 130 258 minecraft:magenta_terracotta
fill 559 130 259 559 212 259 minecraft:purple_terracotta
fill 559 130 261 559 212 261 minecraft:purple_terracotta
setblock 559 130 262 minecraft:magenta_terracotta
fill 559 130 263 559 183 263 minecraft:purple_terracotta
fill 559 130 265 559 175 265 minecraft:purple_terracotta
setblock 559 130 266 minecraft:magenta_terracotta
fill 559 130 267 559 136 267 minecraft:purple_terracotta
setblock 559 130 270 minecraft:magenta_terracotta
fill 517 131 230 517 133 230 minecraft:purple_terracotta
fill 517 131 234 517 133 234 minecraft:purple_terracotta
fill 517 131 238 517 133 238 minecraft:purple_terracotta
setblock 517 131 242 minecraft:black_terracotta
fill 517 131 246 517 133 246 minecraft:purple_terracotta
fill 517 131 250 517 133 250 minecraft:purple_terracotta
fill 517 131 254 517 133 254 minecraft:purple_terracotta
setblock 517 131 256 minecraft:black_terracotta
fill 517 131 258 517 133 258 minecraft:purple_terracotta
fill 517 131 262 517 133 262 minecraft:purple_terracotta
fill 517 131 266 517 133 266 minecraft:purple_terracotta
setblock 517 131 270 minecraft:purple_terracotta
setblock 518 131 228 minecraft:gray_terracotta
fill 518 131 248 519 131 249 minecraft:dark_oak_planks
fill 519 131 228 519 133 228 minecraft:purple_terracotta
fill 519 131 250 519 131 251 minecraft:spruce_planks
fill 519 131 270 519 133 270 minecraft:purple_terracotta
fill 523 131 228 523 133 228 minecraft:purple_terracotta
fill 523 131 270 523 133 270 minecraft:purple_terracotta
fill 527 131 228 527 133 228 minecraft:purple_terracotta
fill 527 131 270 527 133 270 minecraft:purple_terracotta
fill 531 131 228 531 133 228 minecraft:purple_terracotta
fill 531 131 270 531 133 270 minecraft:purple_terracotta
fill 535 131 228 535 133 228 minecraft:purple_terracotta
fill 535 131 270 535 133 270 minecraft:purple_terracotta
fill 539 131 228 539 133 228 minecraft:purple_terracotta
fill 539 131 270 539 133 270 minecraft:purple_terracotta
fill 543 131 228 543 133 228 minecraft:purple_terracotta
fill 543 131 270 543 133 270 minecraft:purple_terracotta
fill 547 131 228 547 133 228 minecraft:purple_terracotta
fill 547 131 270 547 133 270 minecraft:purple_terracotta
fill 551 131 228 551 133 228 minecraft:purple_terracotta
fill 551 131 270 551 133 270 minecraft:purple_terracotta
fill 555 131 228 555 133 228 minecraft:purple_terracotta
fill 555 131 270 555 133 270 minecraft:purple_terracotta
setblock 559 131 228 minecraft:purple_terracotta
fill 559 131 230 559 133 230 minecraft:purple_terracotta
fill 559 131 234 559 133 234 minecraft:purple_terracotta
fill 559 131 238 559 133 238 minecraft:purple_terracotta
fill 559 131 242 559 133 242 minecraft:purple_terracotta
fill 559 131 246 559 133 246 minecraft:purple_terracotta
fill 559 131 250 559 133 250 minecraft:purple_terracotta
fill 559 131 254 559 133 254 minecraft:purple_terracotta
fill 559 131 258 559 133 258 minecraft:purple_terracotta
fill 559 131 262 559 133 262 minecraft:purple_terracotta
fill 559 131 266 559 133 266 minecraft:purple_terracotta
fill 559 131 270 559 133 270 minecraft:purple_terracotta
setblock 517 132 228 minecraft:magenta_terracotta
fill 517 132 231 517 212 231 minecraft:purple_terracotta
setblock 517 132 232 minecraft:magenta_terracotta
fill 517 132 233 517 136 233 minecraft:purple_terracotta
setblock 517 132 236 minecraft:magenta_terracotta
setblock 517 132 240 minecraft:magenta_terracotta
fill 517 132 242 517 133 242 minecraft:purple_terracotta
setblock 517 132 244 minecraft:magenta_terracotta
setblock 517 132 248 minecraft:magenta_terracotta
setblock 517 132 252 minecraft:magenta_terracotta
setblock 517 132 256 minecraft:magenta_terracotta
setblock 517 132 260 minecraft:magenta_terracotta
setblock 517 132 264 minecraft:magenta_terracotta
setblock 517 132 268 minecraft:magenta_terracotta
setblock 517 132 270 minecraft:magenta_terracotta
fill 518 132 228 518 212 228 minecraft:purple_terracotta
fill 518 132 250 519 132 251 minecraft:dark_oak_planks
fill 519 132 252 519 132 253 minecraft:spruce_planks
setblock 521 132 228 minecraft:magenta_terracotta
setblock 521 132 270 minecraft:magenta_terracotta
setblock 525 132 228 minecraft:magenta_terracotta
setblock 525 132 270 minecraft:magenta_terracotta
setblock 529 132 228 minecraft:magenta_terracotta
setblock 529 132 270 minecraft:magenta_terracotta
setblock 533 132 228 minecraft:magenta_terracotta
setblock 533 132 270 minecraft:magenta_terracotta
fill 534 132 228 534 212 228 minecraft:purple_terracotta
setblock 537 132 228 minecraft:magenta_terracotta
setblock 537 132 270 minecraft:magenta_terracotta
setblock 541 132 228 minecraft:magenta_terracotta
setblock 541 132 270 minecraft:magenta_terracotta
setblock 545 132 228 minecraft:magenta_terracotta
setblock 545 132 270 minecraft:magenta_terracotta
setblock 549 132 228 minecraft:magenta_terracotta
setblock 549 132 270 minecraft:magenta_terracotta
setblock 553 132 228 minecraft:magenta_terracotta
setblock 553 132 270 minecraft:magenta_terracotta
setblock 557 132 228 minecraft:magenta_terracotta
setblock 557 132 270 minecraft:magenta_terracotta
setblock 559 132 228 minecraft:magenta_terracotta
setblock 559 132 232 minecraft:magenta_terracotta
setblock 559 132 236 minecraft:magenta_terracotta
setblock 559 132 240 minecraft:magenta_terracotta
setblock 559 132 244 minecraft:magenta_terracotta
setblock 559 132 248 minecraft:magenta_terracotta
setblock 559 132 252 minecraft:magenta_terracotta
setblock 559 132 256 minecraft:magenta_terracotta
setblock 559 132 260 minecraft:magenta_terracotta
setblock 559 132 264 minecraft:magenta_terracotta
setblock 559 132 268 minecraft:gray_terracotta
fill 517 133 228 517 135 228 minecraft:purple_terracotta
fill 517 133 232 517 135 232 minecraft:purple_terracotta
fill 517 133 236 517 135 236 minecraft:purple_terracotta
fill 517 133 240 517 135 240 minecraft:purple_terracotta
fill 517 133 244 517 135 244 minecraft:purple_terracotta
fill 517 133 248 517 135 248 minecraft:purple_terracotta
fill 517 133 252 517 135 252 minecraft:purple_terracotta
fill 517 133 256 517 135 256 minecraft:purple_terracotta
fill 517 133 260 517 135 260 minecraft:purple_terracotta
fill 517 133 264 517 135 264 minecraft:purple_terracotta
fill 517 133 268 517 135 268 minecraft:purple_terracotta
setblock 517 133 270 minecraft:purple_terracotta
fill 518 133 252 519 133 253 minecraft:dark_oak_planks
fill 519 133 254 519 133 255 minecraft:spruce_planks
fill 521 133 228 521 135 228 minecraft:purple_terracotta
fill 521 133 270 521 135 270 minecraft:purple_terracotta
fill 525 133 228 525 135 228 minecraft:purple_terracotta
fill 525 133 270 525 135 270 minecraft:purple_terracotta
fill 529 133 228 529 135 228 minecraft:purple_terracotta
fill 529 133 270 529 135 270 minecraft:purple_terracotta
fill 533 133 228 533 135 228 minecraft:purple_terracotta
fill 533 133 270 533 135 270 minecraft:purple_terracotta
fill 537 133 228 537 135 228 minecraft:purple_terracotta
fill 537 133 270 537 135 270 minecraft:purple_terracotta
fill 541 133 228 541 135 228 minecraft:purple_terracotta
fill 541 133 270 541 135 270 minecraft:purple_terracotta
fill 545 133 228 545 135 228 minecraft:purple_terracotta
fill 545 133 270 545 135 270 minecraft:purple_terracotta
fill 549 133 228 549 135 228 minecraft:purple_terracotta
fill 549 133 270 549 135 270 minecraft:purple_terracotta
fill 553 133 228 553 135 228 minecraft:purple_terracotta
fill 553 133 270 553 135 270 minecraft:purple_terracotta
fill 557 133 228 557 135 228 minecraft:purple_terracotta
fill 557 133 270 557 135 270 minecraft:purple_terracotta
setblock 559 133 228 minecraft:purple_terracotta
fill 559 133 232 559 135 232 minecraft:purple_terracotta
fill 559 133 236 559 135 236 minecraft:purple_terracotta
fill 559 133 240 559 135 240 minecraft:purple_terracotta
fill 559 133 244 559 135 244 minecraft:purple_terracotta
fill 559 133 248 559 135 248 minecraft:purple_terracotta
fill 559 133 252 559 135 252 minecraft:purple_terracotta
fill 559 133 256 559 135 256 minecraft:purple_terracotta
fill 559 133 260 559 135 260 minecraft:purple_terracotta
fill 559 133 264 559 135 264 minecraft:purple_terracotta
fill 559 133 268 559 135 268 minecraft:purple_terracotta
setblock 517 134 230 minecraft:magenta_terracotta
setblock 517 134 234 minecraft:magenta_terracotta
setblock 517 134 238 minecraft:magenta_terracotta
setblock 517 134 242 minecraft:magenta_terracotta
setblock 517 134 246 minecraft:magenta_terracotta
setblock 517 134 250 minecraft:magenta_terracotta
setblock 517 134 254 minecraft:magenta_terracotta
setblock 517 134 258 minecraft:magenta_terracotta
setblock 517 134 262 minecraft:magenta_terracotta
setblock 517 134 266 minecraft:magenta_terracotta
setblock 517 134 270 minecraft:magenta_terracotta
fill 518 134 254 519 134 255 minecraft:dark_oak_planks
setblock 519 134 228 minecraft:magenta_terracotta
fill 519 134 256 519 134 257 minecraft:spruce_planks
setblock 519 134 270 minecraft:magenta_terracotta
setblock 523 134 228 minecraft:light_gray_terracotta
setblock 523 134 270 minecraft:magenta_terracotta
setblock 527 134 228 minecraft:magenta_terracotta
setblock 527 134 270 minecraft:magenta_terracotta
setblock 531 134 228 minecraft:magenta_terracotta
setblock 531 134 270 minecraft:magenta_terracotta
setblock 535 134 228 minecraft:magenta_terracotta
setblock 535 134 270 minecraft:magenta_terracotta
setblock 539 134 228 minecraft:magenta_terracotta
setblock 539 134 270 minecraft:magenta_terracotta
setblock 543 134 228 minecraft:magenta_terracotta
setblock 543 134 270 minecraft:magenta_terracotta
setblock 547 134 228 minecraft:magenta_terracotta
setblock 547 134 270 minecraft:magenta_terracotta
setblock 551 134 228 minecraft:magenta_terracotta
setblock 551 134 270 minecraft:magenta_terracotta
setblock 555 134 228 minecraft:magenta_terracotta
setblock 555 134 270 minecraft:magenta_terracotta
setblock 559 134 228 minecraft:magenta_terracotta
setblock 559 134 230 minecraft:magenta_terracotta
setblock 559 134 234 minecraft:magenta_terracotta
setblock 559 134 238 minecraft:magenta_terracotta
setblock 559 134 242 minecraft:magenta_terracotta
setblock 559 134 246 minecraft:magenta_terracotta
setblock 559 134 250 minecraft:magenta_terracotta
setblock 559 134 254 minecraft:magenta_terracotta
setblock 559 134 258 minecraft:magenta_terracotta
setblock 559 134 262 minecraft:magenta_terracotta
setblock 559 134 266 minecraft:magenta_terracotta
setblock 559 134 270 minecraft:magenta_terracotta
fill 517 135 230 517 137 230 minecraft:purple_terracotta
fill 517 135 234 517 137 234 minecraft:purple_terracotta
fill 517 135 238 517 137 238 minecraft:purple_terracotta
fill 517 135 242 517 137 242 minecraft:purple_terracotta
fill 517 135 246 517 137 246 minecraft:purple_terracotta
fill 517 135 250 517 137 250 minecraft:purple_terracotta
fill 517 135 254 517 137 254 minecraft:purple_terracotta
fill 517 135 258 517 137 258 minecraft:purple_terracotta
fill 517 135 262 517 137 262 minecraft:purple_terracotta
fill 517 135 266 517 137 266 minecraft:purple_terracotta
setblock 517 135 270 minecraft:purple_terracotta
fill 518 135 256 519 135 257 minecraft:dark_oak_planks
fill 519 135 228 519 137 228 minecraft:purple_terracotta
fill 519 135 258 519 135 259 minecraft:spruce_planks
fill 519 135 270 519 137 270 minecraft:purple_terracotta
fill 523 135 228 523 137 228 minecraft:purple_terracotta
fill 523 135 270 523 137 270 minecraft:purple_terracotta
fill 527 135 228 527 137 228 minecraft:purple_terracotta
fill 527 135 270 527 137 270 minecraft:purple_terracotta
fill 529 135 230 529 148 230 minecraft:purple_wool
fill 531 135 228 531 137 228 minecraft:purple_terracotta
fill 531 135 270 531 137 270 minecraft:purple_terracotta
fill 535 135 228 535 137 228 minecraft:purple_terracotta
fill 535 135 270 535 137 270 minecraft:purple_terracotta
fill 539 135 228 539 137 228 minecraft:purple_terracotta
fill 539 135 270 539 137 270 minecraft:purple_terracotta
fill 543 135 228 543 137 228 minecraft:purple_terracotta
fill 543 135 270 543 137 270 minecraft:purple_terracotta
fill 547 135 228 547 137 228 minecraft:purple_terracotta
fill 547 135 270 547 137 270 minecraft:purple_terracotta
fill 551 135 228 551 137 228 minecraft:purple_terracotta
fill 551 135 270 551 137 270 minecraft:purple_terracotta
fill 555 135 228 555 137 228 minecraft:purple_terracotta
fill 555 135 270 555 137 270 minecraft:purple_terracotta
setblock 559 135 228 minecraft:purple_terracotta
fill 559 135 230 559 137 230 minecraft:purple_terracotta
fill 559 135 234 559 137 234 minecraft:purple_terracotta
fill 559 135 238 559 137 238 minecraft:purple_terracotta
fill 559 135 242 559 137 242 minecraft:purple_terracotta
fill 559 135 246 559 137 246 minecraft:purple_terracotta
fill 559 135 250 559 137 250 minecraft:purple_terracotta
fill 559 135 254 559 137 254 minecraft:purple_terracotta
fill 559 135 258 559 137 258 minecraft:purple_terracotta
fill 559 135 262 559 137 262 minecraft:purple_terracotta
fill 559 135 266 559 137 266 minecraft:purple_terracotta
fill 559 135 270 559 137 270 minecraft:purple_terracotta
setblock 517 136 228 minecraft:magenta_terracotta
setblock 517 136 232 minecraft:magenta_terracotta
setblock 517 136 236 minecraft:magenta_terracotta
setblock 517 136 240 minecraft:magenta_terracotta
setblock 517 136 244 minecraft:magenta_terracotta
setblock 517 136 248 minecraft:magenta_terracotta
setblock 517 136 252 minecraft:magenta_terracotta
setblock 517 136 256 minecraft:magenta_terracotta
setblock 517 136 260 minecraft:magenta_terracotta
setblock 517 136 264 minecraft:magenta_terracotta
setblock 517 136 268 minecraft:magenta_terracotta
setblock 517 136 270 minecraft:magenta_terracotta
fill 518 136 258 519 136 259 minecraft:dark_oak_planks
fill 519 136 260 519 136 261 minecraft:spruce_planks
setblock 520 136 231 minecraft:light[level=11]
setblock 520 136 238 minecraft:light[level=12]
setblock 520 136 239 minecraft:light[level=11]
setblock 520 136 245 minecraft:light[level=12]
setblock 520 136 247 minecraft:light[level=11]
setblock 520 136 252 minecraft:light[level=12]
setblock 520 136 255 minecraft:light[level=11]
setblock 520 136 259 minecraft:light[level=12]
setblock 520 136 263 minecraft:light[level=11]
setblock 520 136 266 minecraft:light[level=12]
setblock 521 136 228 minecraft:magenta_terracotta
setblock 521 136 270 minecraft:magenta_terracotta
setblock 525 136 228 minecraft:magenta_terracotta
setblock 525 136 270 minecraft:magenta_terracotta
fill 527 136 230 528 148 230 minecraft:purple_wool
setblock 527 136 231 minecraft:light[level=12]
setblock 527 136 238 minecraft:light[level=12]
setblock 527 136 245 minecraft:light[level=12]
setblock 527 136 252 minecraft:light[level=12]
setblock 527 136 259 minecraft:light[level=12]
setblock 527 136 266 minecraft:light[level=12]
setblock 528 136 231 minecraft:light[level=11]
setblock 528 136 239 minecraft:light[level=11]
setblock 528 136 247 minecraft:light[level=11]
setblock 528 136 255 minecraft:light[level=11]
setblock 528 136 263 minecraft:light[level=11]
setblock 529 136 228 minecraft:magenta_terracotta
setblock 529 136 270 minecraft:magenta_terracotta
fill 530 136 230 531 148 230 minecraft:purple_wool
setblock 533 136 228 minecraft:magenta_terracotta
setblock 533 136 270 minecraft:magenta_terracotta
setblock 534 136 231 minecraft:light[level=12]
setblock 534 136 238 minecraft:light[level=12]
setblock 534 136 245 minecraft:light[level=12]
setblock 534 136 252 minecraft:light[level=12]
setblock 534 136 259 minecraft:light[level=12]
setblock 534 136 266 minecraft:light[level=12]
setblock 536 136 231 minecraft:light[level=11]
setblock 536 136 239 minecraft:light[level=11]
setblock 536 136 247 minecraft:light[level=11]
setblock 536 136 255 minecraft:light[level=11]
setblock 536 136 263 minecraft:light[level=11]
setblock 537 136 228 minecraft:magenta_terracotta
setblock 537 136 270 minecraft:magenta_terracotta
setblock 541 136 228 minecraft:magenta_terracotta
setblock 541 136 231 minecraft:light[level=12]
setblock 541 136 238 minecraft:light[level=12]
setblock 541 136 245 minecraft:light[level=12]
setblock 541 136 252 minecraft:light[level=12]
setblock 541 136 259 minecraft:light[level=12]
setblock 541 136 266 minecraft:light[level=12]
setblock 541 136 270 minecraft:magenta_terracotta
setblock 544 136 231 minecraft:light[level=11]
setblock 544 136 239 minecraft:light[level=11]
setblock 544 136 247 minecraft:light[level=11]
setblock 544 136 255 minecraft:light[level=11]
setblock 544 136 263 minecraft:light[level=11]
setblock 545 136 228 minecraft:magenta_terracotta
setblock 545 136 270 minecraft:magenta_terracotta
setblock 548 136 231 minecraft:light[level=12]
setblock 548 136 238 minecraft:light[level=12]
setblock 548 136 245 minecraft:light[level=12]
setblock 548 136 252 minecraft:light[level=12]
setblock 548 136 259 minecraft:light[level=12]
setblock 548 136 266 minecraft:light[level=12]
setblock 549 136 228 minecraft:magenta_terracotta
setblock 549 136 270 minecraft:magenta_terracotta
setblock 552 136 231 minecraft:light[level=11]
setblock 552 136 239 minecraft:light[level=11]
setblock 552 136 247 minecraft:light[level=11]
setblock 552 136 255 minecraft:light[level=11]
setblock 552 136 263 minecraft:light[level=11]
setblock 553 136 228 minecraft:magenta_terracotta
setblock 553 136 270 minecraft:magenta_terracotta
setblock 555 136 231 minecraft:light[level=12]
setblock 555 136 238 minecraft:light[level=12]
setblock 555 136 245 minecraft:light[level=12]
setblock 555 136 252 minecraft:light[level=12]
setblock 555 136 259 minecraft:light[level=12]
setblock 555 136 266 minecraft:light[level=12]
setblock 557 136 228 minecraft:magenta_terracotta
setblock 557 136 270 minecraft:magenta_terracotta
setblock 559 136 228 minecraft:magenta_terracotta
setblock 559 136 232 minecraft:magenta_terracotta
setblock 559 136 236 minecraft:magenta_terracotta
setblock 559 136 240 minecraft:magenta_terracotta
setblock 559 136 244 minecraft:magenta_terracotta
setblock 559 136 248 minecraft:magenta_terracotta
setblock 559 136 252 minecraft:magenta_terracotta
setblock 559 136 256 minecraft:magenta_terracotta
setblock 559 136 260 minecraft:magenta_terracotta
setblock 559 136 264 minecraft:magenta_terracotta
setblock 559 136 268 minecraft:magenta_terracotta
fill 517 137 228 517 139 228 minecraft:purple_terracotta
fill 517 137 232 517 139 232 minecraft:purple_terracotta
setblock 517 137 233 minecraft:light_gray_terracotta
fill 517 137 236 517 139 236 minecraft:purple_terracotta
fill 517 137 240 517 139 240 minecraft:purple_terracotta
fill 517 137 244 517 139 244 minecraft:purple_terracotta
fill 517 137 248 517 139 248 minecraft:purple_terracotta
fill 517 137 252 517 139 252 minecraft:purple_terracotta
fill 517 137 256 517 139 256 minecraft:purple_terracotta
fill 517 137 260 517 139 260 minecraft:purple_terracotta
fill 517 137 264 517 139 264 minecraft:purple_terracotta
fill 517 137 268 517 139 268 minecraft:purple_terracotta
setblock 517 137 270 minecraft:purple_terracotta
fill 518 137 260 519 137 261 minecraft:dark_oak_planks
fill 519 137 262 519 137 263 minecraft:spruce_planks
fill 521 137 228 521 139 228 minecraft:purple_terracotta
fill 521 137 270 521 139 270 minecraft:purple_terracotta
fill 525 137 228 525 139 228 minecraft:purple_terracotta
fill 525 137 270 525 139 270 minecraft:purple_terracotta
fill 529 137 228 529 139 228 minecraft:purple_terracotta
fill 529 137 270 529 139 270 minecraft:purple_terracotta
fill 533 137 228 533 139 228 minecraft:purple_terracotta
fill 533 137 270 533 139 270 minecraft:purple_terracotta
fill 537 137 228 537 139 228 minecraft:purple_terracotta
fill 537 137 270 537 139 270 minecraft:purple_terracotta
fill 541 137 228 541 139 228 minecraft:purple_terracotta
fill 541 137 270 541 139 270 minecraft:purple_terracotta
fill 545 137 228 545 139 228 minecraft:purple_terracotta
fill 545 137 270 545 139 270 minecraft:purple_terracotta
fill 549 137 228 549 139 228 minecraft:purple_terracotta
fill 549 137 270 549 139 270 minecraft:purple_terracotta
fill 553 137 228 553 139 228 minecraft:purple_terracotta
fill 553 137 270 553 139 270 minecraft:purple_terracotta
fill 557 137 228 557 139 228 minecraft:purple_terracotta
fill 557 137 270 557 139 270 minecraft:purple_terracotta
setblock 559 137 228 minecraft:purple_terracotta
fill 559 137 232 559 139 232 minecraft:purple_terracotta
fill 559 137 236 559 139 236 minecraft:purple_terracotta
fill 559 137 240 559 139 240 minecraft:purple_terracotta
fill 559 137 244 559 139 244 minecraft:purple_terracotta
fill 559 137 248 559 139 248 minecraft:purple_terracotta
fill 559 137 252 559 139 252 minecraft:purple_terracotta
fill 559 137 256 559 139 256 minecraft:purple_terracotta
fill 559 137 260 559 139 260 minecraft:purple_terracotta
fill 559 137 264 559 139 264 minecraft:purple_terracotta
setblock 559 137 267 minecraft:light_gray_terracotta
fill 559 137 268 559 139 268 minecraft:purple_terracotta
setblock 517 138 230 minecraft:magenta_terracotta
fill 517 138 233 517 212 233 minecraft:purple_terracotta
setblock 517 138 234 minecraft:magenta_terracotta
setblock 517 138 238 minecraft:magenta_terracotta
setblock 517 138 242 minecraft:magenta_terracotta
setblock 517 138 246 minecraft:magenta_terracotta
setblock 517 138 250 minecraft:magenta_terracotta
setblock 517 138 254 minecraft:magenta_terracotta
setblock 517 138 258 minecraft:magenta_terracotta
setblock 517 138 262 minecraft:magenta_terracotta
setblock 517 138 266 minecraft:magenta_terracotta
setblock 517 138 270 minecraft:magenta_terracotta
fill 518 138 262 519 138 263 minecraft:dark_oak_planks
setblock 519 138 228 minecraft:magenta_terracotta
fill 519 138 264 519 138 265 minecraft:spruce_planks
setblock 519 138 270 minecraft:magenta_terracotta
setblock 523 138 228 minecraft:magenta_terracotta
setblock 523 138 270 minecraft:magenta_terracotta
setblock 527 138 228 minecraft:magenta_terracotta
setblock 527 138 270 minecraft:magenta_terracotta
setblock 531 138 228 minecraft:magenta_terracotta
setblock 531 138 270 minecraft:magenta_terracotta
setblock 535 138 228 minecraft:magenta_terracotta
setblock 535 138 270 minecraft:magenta_terracotta
setblock 536 138 270 minecraft:black_terracotta
setblock 539 138 228 minecraft:magenta_terracotta
setblock 539 138 270 minecraft:magenta_terracotta
setblock 543 138 228 minecraft:magenta_terracotta
setblock 543 138 270 minecraft:magenta_terracotta
setblock 547 138 228 minecraft:magenta_terracotta
setblock 547 138 270 minecraft:magenta_terracotta
setblock 551 138 228 minecraft:magenta_terracotta
setblock 551 138 270 minecraft:magenta_terracotta
setblock 555 138 228 minecraft:magenta_terracotta
setblock 555 138 270 minecraft:magenta_terracotta
setblock 559 138 228 minecraft:magenta_terracotta
setblock 559 138 230 minecraft:black_terracotta
setblock 559 138 234 minecraft:magenta_terracotta
setblock 559 138 238 minecraft:magenta_terracotta
setblock 559 138 242 minecraft:magenta_terracotta
setblock 559 138 246 minecraft:magenta_terracotta
setblock 559 138 250 minecraft:magenta_terracotta
setblock 559 138 254 minecraft:magenta_terracotta
setblock 559 138 258 minecraft:magenta_terracotta
setblock 559 138 262 minecraft:magenta_terracotta
setblock 559 138 266 minecraft:magenta_terracotta
fill 559 138 267 559 212 267 minecraft:purple_terracotta
setblock 559 138 270 minecraft:magenta_terracotta
fill 517 139 230 517 141 230 minecraft:purple_terracotta
fill 517 139 234 517 141 234 minecraft:purple_terracotta
fill 517 139 238 517 141 238 minecraft:purple_terracotta
fill 517 139 242 517 141 242 minecraft:purple_terracotta
fill 517 139 246 517 141 246 minecraft:purple_terracotta
fill 517 139 250 517 141 250 minecraft:purple_terracotta
fill 517 139 254 517 141 254 minecraft:purple_terracotta
fill 517 139 258 517 141 258 minecraft:purple_terracotta
fill 517 139 262 517 141 262 minecraft:purple_terracotta
fill 517 139 266 517 141 266 minecraft:purple_terracotta
setblock 517 139 270 minecraft:purple_terracotta
fill 518 139 264 519 139 265 minecraft:dark_oak_planks
fill 519 139 228 519 141 228 minecraft:purple_terracotta
fill 519 139 266 519 139 267 minecraft:spruce_planks
fill 519 139 270 519 141 270 minecraft:purple_terracotta
fill 523 139 228 523 141 228 minecraft:purple_terracotta
fill 523 139 270 523 141 270 minecraft:purple_terracotta
fill 527 139 228 527 141 228 minecraft:purple_terracotta
fill 527 139 270 527 141 270 minecraft:purple_terracotta
setblock 530 139 270 minecraft:light_gray_terracotta
fill 531 139 228 531 141 228 minecraft:purple_terracotta
fill 531 139 270 531 141 270 minecraft:purple_terracotta
fill 535 139 228 535 141 228 minecraft:purple_terracotta
fill 535 139 270 536 141 270 minecraft:purple_terracotta
fill 539 139 228 539 141 228 minecraft:purple_terracotta
fill 539 139 270 539 141 270 minecraft:purple_terracotta
fill 543 139 228 543 141 228 minecraft:purple_terracotta
fill 543 139 270 543 141 270 minecraft:purple_terracotta
fill 547 139 228 547 141 228 minecraft:purple_terracotta
setblock 547 139 270 minecraft:gray_terracotta
fill 551 139 228 551 141 228 minecraft:purple_terracotta
fill 551 139 270 551 141 270 minecraft:purple_terracotta
fill 555 139 228 555 141 228 minecraft:purple_terracotta
fill 555 139 270 555 141 270 minecraft:purple_terracotta
setblock 559 139 228 minecraft:purple_terracotta
fill 559 139 230 559 140 230 minecraft:purple_terracotta
fill 559 139 234 559 141 234 minecraft:purple_terracotta
fill 559 139 238 559 141 238 minecraft:purple_terracotta
fill 559 139 242 559 141 242 minecraft:purple_terracotta
fill 559 139 246 559 141 246 minecraft:purple_terracotta
fill 559 139 250 559 141 250 minecraft:purple_terracotta
fill 559 139 254 559 141 254 minecraft:purple_terracotta
fill 559 139 258 559 141 258 minecraft:purple_terracotta
fill 559 139 262 559 141 262 minecraft:purple_terracotta
fill 559 139 266 559 141 266 minecraft:purple_terracotta
fill 559 139 270 559 141 270 minecraft:purple_terracotta
setblock 517 140 228 minecraft:magenta_terracotta
setblock 517 140 232 minecraft:magenta_terracotta
setblock 517 140 236 minecraft:magenta_terracotta
setblock 517 140 240 minecraft:magenta_terracotta
setblock 517 140 244 minecraft:magenta_terracotta
setblock 517 140 248 minecraft:magenta_terracotta
setblock 517 140 252 minecraft:magenta_terracotta
setblock 517 140 256 minecraft:magenta_terracotta
setblock 517 140 260 minecraft:magenta_terracotta
setblock 517 140 264 minecraft:magenta_terracotta
setblock 517 140 268 minecraft:magenta_terracotta
setblock 517 140 270 minecraft:magenta_terracotta
fill 518 140 266 519 140 267 minecraft:dark_oak_planks
setblock 519 140 268 minecraft:spruce_planks
setblock 521 140 228 minecraft:magenta_terracotta
setblock 521 140 270 minecraft:magenta_terracotta
setblock 525 140 228 minecraft:magenta_terracotta
setblock 525 140 270 minecraft:magenta_terracotta
setblock 529 140 228 minecraft:magenta_terracotta
setblock 529 140 270 minecraft:magenta_terracotta
fill 530 140 270 530 199 270 minecraft:purple_terracotta
setblock 533 140 228 minecraft:magenta_terracotta
setblock 533 140 270 minecraft:magenta_terracotta
setblock 537 140 228 minecraft:magenta_terracotta
setblock 537 140 270 minecraft:magenta_terracotta
setblock 541 140 228 minecraft:magenta_terracotta
setblock 541 140 270 minecraft:magenta_terracotta
setblock 545 140 228 minecraft:magenta_terracotta
setblock 545 140 270 minecraft:magenta_terracotta
fill 547 140 270 547 141 270 minecraft:purple_terracotta
setblock 549 140 228 minecraft:magenta_terracotta
setblock 549 140 270 minecraft:magenta_terracotta
setblock 553 140 228 minecraft:magenta_terracotta
setblock 553 140 270 minecraft:magenta_terracotta
setblock 557 140 228 minecraft:magenta_terracotta
setblock 557 140 270 minecraft:magenta_terracotta
setblock 558 140 270 minecraft:gray_terracotta
setblock 559 140 228 minecraft:magenta_terracotta
setblock 559 140 232 minecraft:magenta_terracotta
setblock 559 140 236 minecraft:magenta_terracotta
setblock 559 140 240 minecraft:magenta_terracotta
setblock 559 140 244 minecraft:magenta_terracotta
setblock 559 140 248 minecraft:magenta_terracotta
setblock 559 140 252 minecraft:magenta_terracotta
setblock 559 140 256 minecraft:magenta_terracotta
setblock 559 140 260 minecraft:magenta_terracotta
setblock 559 140 264 minecraft:magenta_terracotta
setblock 559 140 268 minecraft:magenta_terracotta
fill 517 141 228 517 143 228 minecraft:purple_terracotta
fill 517 141 232 517 143 232 minecraft:purple_terracotta
fill 517 141 236 517 143 236 minecraft:purple_terracotta
fill 517 141 240 517 143 240 minecraft:purple_terracotta
fill 517 141 244 517 143 244 minecraft:purple_terracotta
fill 517 141 248 517 143 248 minecraft:purple_terracotta
fill 517 141 252 517 143 252 minecraft:purple_terracotta
fill 517 141 256 517 143 256 minecraft:purple_terracotta
fill 517 141 260 517 143 260 minecraft:purple_terracotta
fill 517 141 264 517 143 264 minecraft:purple_terracotta
fill 517 141 268 517 143 268 minecraft:purple_terracotta
setblock 517 141 270 minecraft:purple_terracotta
fill 518 141 268 519 141 269 minecraft:dark_oak_planks
fill 520 141 268 521 141 268 minecraft:spruce_planks
fill 521 141 228 521 143 228 minecraft:purple_terracotta
fill 521 141 270 521 143 270 minecraft:purple_terracotta
fill 525 141 228 525 143 228 minecraft:purple_terracotta
fill 525 141 270 525 143 270 minecraft:purple_terracotta
fill 529 141 228 529 143 228 minecraft:purple_terracotta
fill 529 141 270 529 143 270 minecraft:purple_terracotta
fill 533 141 228 533 143 228 minecraft:purple_terracotta
fill 533 141 270 533 143 270 minecraft:purple_terracotta
fill 537 141 228 537 143 228 minecraft:purple_terracotta
fill 537 141 270 537 143 270 minecraft:purple_terracotta
fill 541 141 228 541 143 228 minecraft:purple_terracotta
fill 541 141 270 541 143 270 minecraft:purple_terracotta
fill 545 141 228 545 143 228 minecraft:purple_terracotta
fill 545 141 270 545 143 270 minecraft:purple_terracotta
fill 549 141 228 549 143 228 minecraft:purple_terracotta
fill 549 141 270 549 143 270 minecraft:purple_terracotta
fill 553 141 228 553 143 228 minecraft:purple_terracotta
fill 553 141 270 553 143 270 minecraft:purple_terracotta
fill 557 141 228 557 143 228 minecraft:purple_terracotta
fill 557 141 270 558 143 270 minecraft:purple_terracotta
setblock 559 141 228 minecraft:purple_terracotta
setblock 559 141 230 minecraft:black_terracotta
fill 559 141 232 559 143 232 minecraft:purple_terracotta
fill 559 141 236 559 143 236 minecraft:purple_terracotta
fill 559 141 240 559 143 240 minecraft:purple_terracotta
fill 559 141 244 559 143 244 minecraft:purple_terracotta
fill 559 141 248 559 143 248 minecraft:purple_terracotta
fill 559 141 252 559 143 252 minecraft:purple_terracotta
fill 559 141 256 559 143 256 minecraft:purple_terracotta
fill 559 141 260 559 143 260 minecraft:purple_terracotta
fill 559 141 264 559 143 264 minecraft:purple_terracotta
fill 559 141 268 559 143 268 minecraft:purple_terracotta
setblock 517 142 230 minecraft:magenta_terracotta
setblock 517 142 234 minecraft:magenta_terracotta
setblock 517 142 238 minecraft:magenta_terracotta
setblock 517 142 242 minecraft:magenta_terracotta
setblock 517 142 246 minecraft:magenta_terracotta
setblock 517 142 250 minecraft:magenta_terracotta
setblock 517 142 254 minecraft:magenta_terracotta
setblock 517 142 258 minecraft:magenta_terracotta
setblock 517 142 262 minecraft:magenta_terracotta
setblock 517 142 266 minecraft:magenta_terracotta
setblock 517 142 270 minecraft:magenta_terracotta
setblock 519 142 228 minecraft:magenta_terracotta
setblock 519 142 270 minecraft:magenta_terracotta
setblock 520 142 231 minecraft:light[level=12]
setblock 520 142 238 minecraft:light[level=12]
setblock 520 142 245 minecraft:light[level=12]
setblock 520 142 252 minecraft:light[level=12]
setblock 520 142 259 minecraft:light[level=12]
setblock 520 142 266 minecraft:light[level=12]
fill 520 142 268 521 142 269 minecraft:dark_oak_planks
fill 522 142 268 523 142 268 minecraft:spruce_planks
setblock 523 142 228 minecraft:magenta_terracotta
setblock 523 142 270 minecraft:magenta_terracotta
setblock 527 142 228 minecraft:magenta_terracotta
setblock 527 142 231 minecraft:light[level=12]
setblock 527 142 238 minecraft:light[level=12]
setblock 527 142 245 minecraft:light[level=12]
setblock 527 142 252 minecraft:light[level=12]
setblock 527 142 259 minecraft:light[level=12]
setblock 527 142 266 minecraft:light[level=12]
setblock 527 142 270 minecraft:magenta_terracotta
setblock 531 142 228 minecraft:magenta_terracotta
setblock 531 142 270 minecraft:magenta_terracotta
setblock 534 142 231 minecraft:light[level=12]
setblock 534 142 238 minecraft:light[level=12]
setblock 534 142 245 minecraft:light[level=12]
setblock 534 142 252 minecraft:light[level=12]
setblock 534 142 259 minecraft:light[level=12]
setblock 534 142 266 minecraft:light[level=12]
setblock 535 142 228 minecraft:magenta_terracotta
setblock 535 142 270 minecraft:magenta_terracotta
fill 536 142 270 536 212 270 minecraft:purple_terracotta
setblock 539 142 228 minecraft:magenta_terracotta
setblock 539 142 270 minecraft:magenta_terracotta
setblock 540 142 228 minecraft:light_gray_terracotta
setblock 541 142 231 minecraft:light[level=12]
setblock 541 142 238 minecraft:light[level=12]
setblock 541 142 245 minecraft:light[level=12]
setblock 541 142 252 minecraft:light[level=12]
setblock 541 142 259 minecraft:light[level=12]
setblock 541 142 266 minecraft:light[level=12]
setblock 543 142 228 minecraft:magenta_terracotta
setblock 543 142 270 minecraft:magenta_terracotta
setblock 547 142 228 minecraft:magenta_terracotta
setblock 547 142 270 minecraft:magenta_terracotta
setblock 548 142 231 minecraft:light[level=12]
setblock 548 142 238 minecraft:light[level=12]
setblock 548 142 245 minecraft:light[level=12]
setblock 548 142 252 minecraft:light[level=12]
setblock 548 142 259 minecraft:light[level=12]
setblock 548 142 266 minecraft:light[level=12]
setblock 551 142 228 minecraft:magenta_terracotta
setblock 551 142 270 minecraft:magenta_terracotta
setblock 555 142 228 minecraft:magenta_terracotta
setblock 555 142 231 minecraft:light[level=12]
setblock 555 142 238 minecraft:light[level=12]
setblock 555 142 245 minecraft:light[level=12]
setblock 555 142 252 minecraft:light[level=12]
setblock 555 142 259 minecraft:light[level=12]
setblock 555 142 266 minecraft:light[level=12]
setblock 555 142 270 minecraft:magenta_terracotta
setblock 559 142 228 minecraft:magenta_terracotta
setblock 559 142 230 minecraft:magenta_terracotta
setblock 559 142 234 minecraft:magenta_terracotta
setblock 559 142 238 minecraft:magenta_terracotta
setblock 559 142 242 minecraft:magenta_terracotta
setblock 559 142 246 minecraft:magenta_terracotta
setblock 559 142 250 minecraft:magenta_terracotta
setblock 559 142 254 minecraft:magenta_terracotta
setblock 559 142 258 minecraft:magenta_terracotta
setblock 559 142 262 minecraft:magenta_terracotta
setblock 559 142 266 minecraft:magenta_terracotta
setblock 559 142 270 minecraft:magenta_terracotta
fill 517 143 230 517 145 230 minecraft:purple_terracotta
fill 517 143 234 517 145 234 minecraft:purple_terracotta
fill 517 143 238 517 144 238 minecraft:purple_terracotta
fill 517 143 242 517 145 242 minecraft:purple_terracotta
fill 517 143 246 517 145 246 minecraft:purple_terracotta
fill 517 143 250 517 145 250 minecraft:purple_terracotta
fill 517 143 254 517 145 254 minecraft:purple_terracotta
fill 517 143 258 517 145 258 minecraft:purple_terracotta
fill 517 143 262 517 145 262 minecraft:purple_terracotta
fill 517 143 266 517 145 266 minecraft:purple_terracotta
setblock 517 143 270 minecraft:purple_terracotta
fill 519 143 228 519 145 228 minecraft:purple_terracotta
fill 519 143 270 519 145 270 minecraft:purple_terracotta
fill 522 143 268 523 143 269 minecraft:dark_oak_planks
fill 523 143 228 523 145 228 minecraft:purple_terracotta
fill 523 143 270 523 145 270 minecraft:purple_terracotta
fill 524 143 268 525 143 268 minecraft:spruce_planks
fill 527 143 228 527 145 228 minecraft:purple_terracotta
fill 527 143 270 527 145 270 minecraft:purple_terracotta
fill 531 143 228 531 145 228 minecraft:purple_terracotta
fill 531 143 270 531 145 270 minecraft:purple_terracotta
fill 535 143 228 535 145 228 minecraft:purple_terracotta
fill 535 143 270 535 145 270 minecraft:purple_terracotta
fill 539 143 228 540 145 228 minecraft:purple_terracotta
fill 539 143 270 539 145 270 minecraft:purple_terracotta
fill 543 143 228 543 145 228 minecraft:purple_terracotta
fill 543 143 270 543 145 270 minecraft:purple_terracotta
fill 547 143 228 547 145 228 minecraft:purple_terracotta
fill 547 143 270 547 145 270 minecraft:purple_terracotta
fill 551 143 228 551 145 228 minecraft:purple_terracotta
fill 551 143 270 551 145 270 minecraft:purple_terracotta
fill 555 143 228 555 145 228 minecraft:purple_terracotta
fill 555 143 270 555 145 270 minecraft:purple_terracotta
setblock 559 143 228 minecraft:purple_terracotta
fill 559 143 230 559 145 230 minecraft:purple_terracotta
fill 559 143 234 559 145 234 minecraft:purple_terracotta
fill 559 143 238 559 145 238 minecraft:purple_terracotta
fill 559 143 242 559 145 242 minecraft:purple_terracotta
fill 559 143 246 559 145 246 minecraft:purple_terracotta
fill 559 143 250 559 145 250 minecraft:purple_terracotta
fill 559 143 254 559 145 254 minecraft:purple_terracotta
fill 559 143 258 559 145 258 minecraft:purple_terracotta
fill 559 143 262 559 145 262 minecraft:purple_terracotta
fill 559 143 266 559 145 266 minecraft:purple_terracotta
fill 559 143 270 559 145 270 minecraft:purple_terracotta
setblock 517 144 228 minecraft:magenta_terracotta
setblock 517 144 232 minecraft:magenta_terracotta
setblock 517 144 236 minecraft:magenta_terracotta
setblock 517 144 240 minecraft:magenta_terracotta
setblock 517 144 244 minecraft:magenta_terracotta
setblock 517 144 248 minecraft:magenta_terracotta
setblock 517 144 252 minecraft:magenta_terracotta
setblock 517 144 256 minecraft:magenta_terracotta
setblock 517 144 260 minecraft:magenta_terracotta
setblock 517 144 264 minecraft:magenta_terracotta
setblock 517 144 268 minecraft:magenta_terracotta
setblock 517 144 270 minecraft:magenta_terracotta
setblock 520 144 231 minecraft:light[level=11]
setblock 520 144 239 minecraft:light[level=11]
setblock 520 144 247 minecraft:light[level=11]
setblock 520 144 255 minecraft:light[level=11]
setblock 520 144 263 minecraft:light[level=11]
setblock 521 144 228 minecraft:magenta_terracotta
setblock 521 144 270 minecraft:magenta_terracotta
fill 524 144 268 525 144 269 minecraft:dark_oak_planks
setblock 525 144 228 minecraft:magenta_terracotta
setblock 525 144 270 minecraft:magenta_terracotta
fill 526 144 268 527 144 268 minecraft:spruce_planks
setblock 528 144 231 minecraft:light[level=11]
setblock 528 144 239 minecraft:light[level=11]
setblock 528 144 247 minecraft:light[level=11]
setblock 528 144 255 minecraft:light[level=11]
setblock 528 144 263 minecraft:light[level=11]
setblock 529 144 228 minecraft:magenta_terracotta
setblock 529 144 270 minecraft:magenta_terracotta
setblock 533 144 228 minecraft:magenta_terracotta
setblock 533 144 270 minecraft:magenta_terracotta
setblock 536 144 231 minecraft:light[level=11]
setblock 536 144 239 minecraft:light[level=11]
setblock 536 144 247 minecraft:light[level=11]
setblock 536 144 255 minecraft:light[level=11]
setblock 536 144 263 minecraft:light[level=11]
setblock 537 144 228 minecraft:magenta_terracotta
setblock 537 144 270 minecraft:magenta_terracotta
setblock 541 144 228 minecraft:magenta_terracotta
setblock 541 144 270 minecraft:magenta_terracotta
setblock 544 144 231 minecraft:light[level=11]
setblock 544 144 239 minecraft:light[level=11]
setblock 544 144 247 minecraft:light[level=11]
setblock 544 144 255 minecraft:light[level=11]
setblock 544 144 263 minecraft:light[level=11]
setblock 545 144 228 minecraft:magenta_terracotta
setblock 545 144 270 minecraft:magenta_terracotta
setblock 549 144 228 minecraft:magenta_terracotta
setblock 549 144 270 minecraft:magenta_terracotta
setblock 552 144 231 minecraft:light[level=11]
setblock 552 144 239 minecraft:light[level=11]
setblock 552 144 247 minecraft:light[level=11]
setblock 552 144 255 minecraft:light[level=11]
setblock 552 144 263 minecraft:light[level=11]
setblock 553 144 228 minecraft:magenta_terracotta
setblock 553 144 270 minecraft:magenta_terracotta
setblock 557 144 228 minecraft:magenta_terracotta
setblock 557 144 270 minecraft:magenta_terracotta
fill 558 144 270 558 192 270 minecraft:purple_terracotta
setblock 559 144 228 minecraft:magenta_terracotta
setblock 559 144 232 minecraft:magenta_terracotta
setblock 559 144 236 minecraft:magenta_terracotta
setblock 559 144 240 minecraft:magenta_terracotta
setblock 559 144 244 minecraft:magenta_terracotta
setblock 559 144 248 minecraft:magenta_terracotta
setblock 559 144 252 minecraft:magenta_terracotta
setblock 559 144 256 minecraft:magenta_terracotta
setblock 559 144 260 minecraft:magenta_terracotta
setblock 559 144 264 minecraft:magenta_terracotta
setblock 559 144 268 minecraft:magenta_terracotta
fill 517 145 228 517 147 228 minecraft:purple_terracotta
fill 517 145 232 517 147 232 minecraft:purple_terracotta
fill 517 145 236 517 147 236 minecraft:purple_terracotta
setblock 517 145 238 minecraft:gray_terracotta
fill 517 145 240 517 147 240 minecraft:purple_terracotta
fill 517 145 244 517 147 244 minecraft:purple_terracotta
fill 517 145 248 517 147 248 minecraft:purple_terracotta
fill 517 145 252 517 147 252 minecraft:purple_terracotta
fill 517 145 256 517 147 256 minecraft:purple_terracotta
fill 517 145 260 517 147 260 minecraft:purple_terracotta
fill 517 145 264 517 147 264 minecraft:purple_terracotta
fill 517 145 268 517 147 268 minecraft:purple_terracotta
setblock 517 145 270 minecraft:purple_terracotta
fill 521 145 228 521 147 228 minecraft:purple_terracotta
fill 521 145 270 521 147 270 minecraft:purple_terracotta
fill 525 145 228 525 147 228 minecraft:purple_terracotta
fill 525 145 270 525 147 270 minecraft:purple_terracotta
fill 526 145 268 527 145 269 minecraft:dark_oak_planks
fill 528 145 268 529 145 268 minecraft:spruce_planks
fill 529 145 228 529 147 228 minecraft:purple_terracotta
fill 529 145 270 529 147 270 minecraft:purple_terracotta
fill 533 145 228 533 147 228 minecraft:purple_terracotta
fill 533 145 270 533 147 270 minecraft:purple_terracotta
fill 537 145 228 537 147 228 minecraft:purple_terracotta
fill 537 145 270 537 147 270 minecraft:purple_terracotta
fill 541 145 228 541 147 228 minecraft:purple_terracotta
fill 541 145 270 541 147 270 minecraft:purple_terracotta
fill 545 145 228 545 147 228 minecraft:purple_terracotta
fill 545 145 270 545 147 270 minecraft:purple_terracotta
fill 549 145 228 549 147 228 minecraft:purple_terracotta
fill 549 145 270 549 147 270 minecraft:purple_terracotta
fill 553 145 228 553 147 228 minecraft:purple_terracotta
fill 553 145 270 553 147 270 minecraft:purple_terracotta
fill 557 145 228 557 147 228 minecraft:purple_terracotta
fill 557 145 270 557 147 270 minecraft:purple_terracotta
setblock 559 145 228 minecraft:purple_terracotta
fill 559 145 232 559 147 232 minecraft:purple_terracotta
fill 559 145 236 559 147 236 minecraft:purple_terracotta
fill 559 145 240 559 147 240 minecraft:purple_terracotta
fill 559 145 244 559 147 244 minecraft:purple_terracotta
fill 559 145 248 559 147 248 minecraft:purple_terracotta
fill 559 145 252 559 147 252 minecraft:purple_terracotta
fill 559 145 256 559 147 256 minecraft:purple_terracotta
fill 559 145 260 559 147 260 minecraft:purple_terracotta
fill 559 145 264 559 147 264 minecraft:purple_terracotta
fill 559 145 268 559 147 268 minecraft:purple_terracotta
setblock 517 146 230 minecraft:magenta_terracotta
setblock 517 146 234 minecraft:magenta_terracotta
setblock 517 146 238 minecraft:magenta_terracotta
setblock 517 146 242 minecraft:magenta_terracotta
setblock 517 146 246 minecraft:magenta_terracotta
setblock 517 146 250 minecraft:magenta_terracotta
setblock 517 146 254 minecraft:magenta_terracotta
setblock 517 146 255 minecraft:black_terracotta
setblock 517 146 258 minecraft:magenta_terracotta
setblock 517 146 262 minecraft:magenta_terracotta
setblock 517 146 266 minecraft:magenta_terracotta
setblock 517 146 270 minecraft:magenta_terracotta
setblock 519 146 228 minecraft:magenta_terracotta
setblock 519 146 270 minecraft:magenta_terracotta
setblock 523 146 228 minecraft:magenta_terracotta
setblock 523 146 270 minecraft:magenta_terracotta
setblock 527 146 228 minecraft:magenta_terracotta
setblock 527 146 270 minecraft:magenta_terracotta
fill 528 146 268 529 146 269 minecraft:dark_oak_planks
fill 530 146 268 531 146 268 minecraft:spruce_planks
setblock 531 146 228 minecraft:magenta_terracotta
setblock 531 146 270 minecraft:magenta_terracotta
fill 533 146 260 533 148 261 minecraft:white_stained_glass
fill 534 146 259 534 148 260 minecraft:white_stained_glass
setblock 535 146 228 minecraft:magenta_terracotta
setblock 535 146 270 minecraft:magenta_terracotta
setblock 539 146 228 minecraft:magenta_terracotta
setblock 539 146 270 minecraft:magenta_terracotta
fill 540 146 228 540 212 228 minecraft:purple_terracotta
fill 541 146 262 545 147 266 minecraft:dark_oak_planks
setblock 543 146 228 minecraft:magenta_terracotta
fill 543 146 267 543 146 268 minecraft:dark_oak_planks
setblock 543 146 270 minecraft:magenta_terracotta
setblock 547 146 228 minecraft:magenta_terracotta
setblock 547 146 270 minecraft:magenta_terracotta
setblock 551 146 228 minecraft:magenta_terracotta
setblock 551 146 270 minecraft:magenta_terracotta
setblock 555 146 228 minecraft:magenta_terracotta
setblock 555 146 270 minecraft:magenta_terracotta
setblock 559 146 228 minecraft:magenta_terracotta
setblock 559 146 230 minecraft:magenta_terracotta
setblock 559 146 234 minecraft:magenta_terracotta
setblock 559 146 238 minecraft:magenta_terracotta
setblock 559 146 242 minecraft:magenta_terracotta
setblock 559 146 246 minecraft:magenta_terracotta
setblock 559 146 250 minecraft:magenta_terracotta
setblock 559 146 254 minecraft:magenta_terracotta
setblock 559 146 258 minecraft:magenta_terracotta
setblock 559 146 262 minecraft:magenta_terracotta
setblock 559 146 266 minecraft:magenta_terracotta
setblock 559 146 270 minecraft:magenta_terracotta
fill 517 147 230 517 149 230 minecraft:purple_terracotta
fill 517 147 234 517 149 234 minecraft:purple_terracotta
fill 517 147 238 517 149 238 minecraft:purple_terracotta
fill 517 147 242 517 149 242 minecraft:purple_terracotta
fill 517 147 246 517 149 246 minecraft:purple_terracotta
setblock 517 147 250 minecraft:purple_terracotta
fill 517 147 254 517 149 255 minecraft:purple_terracotta
fill 517 147 258 517 149 258 minecraft:purple_terracotta
fill 517 147 262 517 149 262 minecraft:purple_terracotta
fill 517 147 266 517 149 266 minecraft:purple_terracotta
setblock 517 147 270 minecraft:purple_terracotta
fill 519 147 228 519 149 228 minecraft:purple_terracotta
fill 519 147 270 519 149 270 minecraft:purple_terracotta
fill 523 147 228 523 149 228 minecraft:purple_terracotta
fill 523 147 270 523 149 270 minecraft:purple_terracotta
fill 527 147 228 527 149 228 minecraft:purple_terracotta
fill 527 147 270 527 149 270 minecraft:purple_terracotta
fill 530 147 268 531 147 269 minecraft:dark_oak_planks
fill 531 147 228 531 149 228 minecraft:purple_terracotta
fill 531 147 270 531 149 270 minecraft:purple_terracotta
fill 532 147 259 532 149 261 minecraft:white_stained_glass
fill 532 147 268 533 147 268 minecraft:spruce_planks
fill 533 147 259 533 148 259 minecraft:white_stained_glass
fill 534 147 261 535 148 261 minecraft:white_stained_glass
fill 535 147 228 535 149 228 minecraft:purple_terracotta
fill 535 147 259 535 149 260 minecraft:white_stained_glass
fill 535 147 270 535 149 270 minecraft:purple_terracotta
fill 539 147 228 539 149 228 minecraft:purple_terracotta
fill 539 147 270 539 149 270 minecraft:purple_terracotta
fill 543 147 228 543 149 228 minecraft:purple_terracotta
fill 543 147 270 543 149 270 minecraft:purple_terracotta
fill 547 147 228 547 149 228 minecraft:purple_terracotta
fill 547 147 270 547 149 270 minecraft:purple_terracotta
fill 551 147 228 551 149 228 minecraft:purple_terracotta
fill 551 147 270 551 149 270 minecraft:purple_terracotta
fill 555 147 228 555 149 228 minecraft:purple_terracotta
fill 555 147 270 555 149 270 minecraft:purple_terracotta
setblock 559 147 228 minecraft:purple_terracotta
fill 559 147 230 559 149 230 minecraft:purple_terracotta
fill 559 147 234 559 149 234 minecraft:purple_terracotta
fill 559 147 238 559 149 238 minecraft:purple_terracotta
fill 559 147 242 559 149 242 minecraft:purple_terracotta
fill 559 147 246 559 149 246 minecraft:purple_terracotta
fill 559 147 250 559 149 250 minecraft:purple_terracotta
fill 559 147 254 559 149 254 minecraft:purple_terracotta
fill 559 147 258 559 149 258 minecraft:purple_terracotta
fill 559 147 262 559 149 262 minecraft:purple_terracotta
fill 559 147 266 559 149 266 minecraft:purple_terracotta
fill 559 147 270 559 149 270 minecraft:purple_terracotta
setblock 517 148 228 minecraft:magenta_terracotta
setblock 517 148 232 minecraft:magenta_terracotta
setblock 517 148 236 minecraft:magenta_terracotta
setblock 517 148 240 minecraft:magenta_terracotta
setblock 517 148 244 minecraft:magenta_terracotta
setblock 517 148 248 minecraft:magenta_terracotta
setblock 517 148 250 minecraft:light_gray_terracotta
setblock 517 148 252 minecraft:magenta_terracotta
setblock 517 148 256 minecraft:magenta_terracotta
setblock 517 148 260 minecraft:magenta_terracotta
setblock 517 148 264 minecraft:magenta_terracotta
setblock 517 148 268 minecraft:magenta_terracotta
setblock 517 148 270 minecraft:magenta_terracotta
setblock 520 148 231 minecraft:light[level=12]
setblock 520 148 238 minecraft:light[level=12]
setblock 520 148 245 minecraft:light[level=12]
setblock 520 148 252 minecraft:light[level=12]
setblock 520 148 259 minecraft:light[level=12]
setblock 520 148 266 minecraft:light[level=12]
setblock 521 148 228 minecraft:magenta_terracotta
setblock 521 148 270 minecraft:magenta_terracotta
setblock 525 148 228 minecraft:magenta_terracotta
setblock 525 148 270 minecraft:magenta_terracotta
setblock 527 148 231 minecraft:light[level=12]
setblock 527 148 238 minecraft:light[level=12]
setblock 527 148 245 minecraft:light[level=12]
setblock 527 148 252 minecraft:light[level=12]
setblock 527 148 259 minecraft:light[level=12]
setblock 527 148 266 minecraft:light[level=12]
setblock 529 148 228 minecraft:magenta_terracotta
setblock 529 148 270 minecraft:magenta_terracotta
fill 532 148 268 533 148 269 minecraft:dark_oak_planks
setblock 533 148 228 minecraft:magenta_terracotta
fill 533 148 258 534 149 258 minecraft:white_stained_glass
fill 533 148 262 534 149 262 minecraft:white_stained_glass
setblock 533 148 270 minecraft:magenta_terracotta
setblock 534 148 231 minecraft:light[level=12]
setblock 534 148 238 minecraft:light[level=12]
setblock 534 148 245 minecraft:light[level=12]
setblock 534 148 252 minecraft:light[level=12]
setblock 534 148 266 minecraft:light[level=12]
fill 534 148 268 535 148 268 minecraft:spruce_planks
setblock 537 148 228 minecraft:magenta_terracotta
setblock 537 148 270 minecraft:magenta_terracotta
setblock 541 148 228 minecraft:magenta_terracotta
setblock 541 148 231 minecraft:light[level=12]
setblock 541 148 238 minecraft:light[level=12]
setblock 541 148 245 minecraft:light[level=12]
setblock 541 148 252 minecraft:light[level=12]
setblock 541 148 259 minecraft:light[level=12]
setblock 541 148 266 minecraft:light[level=12]
setblock 541 148 270 minecraft:magenta_terracotta
fill 542 148 264 544 156 264 minecraft:purple_concrete
fill 543 148 263 543 156 263 minecraft:purple_concrete
fill 543 148 265 543 156 265 minecraft:purple_concrete
setblock 545 148 228 minecraft:magenta_terracotta
setblock 545 148 270 minecraft:magenta_terracotta
setblock 548 148 231 minecraft:light[level=12]
setblock 548 148 238 minecraft:light[level=12]
setblock 548 148 245 minecraft:light[level=12]
setblock 548 148 252 minecraft:light[level=12]
setblock 548 148 259 minecraft:light[level=12]
setblock 548 148 266 minecraft:light[level=12]
setblock 549 148 228 minecraft:magenta_terracotta
setblock 549 148 270 minecraft:magenta_terracotta
setblock 553 148 228 minecraft:magenta_terracotta
setblock 553 148 270 minecraft:magenta_terracotta
setblock 555 148 231 minecraft:light[level=12]
setblock 555 148 238 minecraft:light[level=12]
setblock 555 148 245 minecraft:light[level=12]
setblock 555 148 252 minecraft:light[level=12]
setblock 555 148 259 minecraft:light[level=12]
setblock 555 148 266 minecraft:light[level=12]
setblock 557 148 228 minecraft:magenta_terracotta
setblock 557 148 270 minecraft:magenta_terracotta
setblock 559 148 228 minecraft:magenta_terracotta
setblock 559 148 232 minecraft:magenta_terracotta
setblock 559 148 236 minecraft:magenta_terracotta
setblock 559 148 240 minecraft:magenta_terracotta
setblock 559 148 244 minecraft:magenta_terracotta
setblock 559 148 248 minecraft:magenta_terracotta
setblock 559 148 252 minecraft:magenta_terracotta
setblock 559 148 256 minecraft:magenta_terracotta
setblock 559 148 260 minecraft:magenta_terracotta
setblock 559 148 264 minecraft:magenta_terracotta
setblock 559 148 268 minecraft:magenta_terracotta
fill 517 149 228 517 151 228 minecraft:purple_terracotta
fill 517 149 232 517 151 232 minecraft:purple_terracotta
fill 517 149 236 517 151 236 minecraft:purple_terracotta
fill 517 149 240 517 151 240 minecraft:purple_terracotta
fill 517 149 244 517 151 244 minecraft:purple_terracotta
fill 517 149 248 517 151 248 minecraft:purple_terracotta
setblock 517 149 250 minecraft:purple_terracotta
fill 517 149 252 517 151 252 minecraft:purple_terracotta
fill 517 149 256 517 151 256 minecraft:purple_terracotta
fill 517 149 260 517 151 260 minecraft:purple_terracotta
fill 517 149 264 517 151 264 minecraft:purple_terracotta
fill 517 149 268 517 151 268 minecraft:purple_terracotta
setblock 517 149 270 minecraft:purple_terracotta
fill 521 149 228 521 151 228 minecraft:purple_terracotta
fill 521 149 270 521 151 270 minecraft:purple_terracotta
fill 525 149 228 525 151 228 minecraft:purple_terracotta
fill 525 149 270 525 151 270 minecraft:purple_terracotta
fill 526 149 230 532 150 230 minecraft:iron_bars
fill 529 149 228 529 151 228 minecraft:purple_terracotta
fill 529 149 270 529 151 270 minecraft:purple_terracotta
fill 533 149 228 533 151 228 minecraft:purple_terracotta
fill 533 149 259 534 151 261 minecraft:white_concrete
fill 533 149 270 533 151 270 minecraft:purple_terracotta
fill 534 149 268 535 149 269 minecraft:dark_oak_planks
fill 535 149 261 535 150 261 minecraft:white_stained_glass
fill 536 149 268 537 149 268 minecraft:spruce_planks
fill 537 149 228 537 151 228 minecraft:purple_terracotta
fill 537 149 270 537 151 270 minecraft:purple_terracotta
fill 541 149 228 541 151 228 minecraft:purple_terracotta
fill 541 149 270 541 151 270 minecraft:purple_terracotta
fill 545 149 228 545 151 228 minecraft:purple_terracotta
fill 545 149 270 545 151 270 minecraft:purple_terracotta
fill 549 149 228 549 151 228 minecraft:purple_terracotta
fill 549 149 270 549 151 270 minecraft:purple_terracotta
fill 553 149 228 553 151 228 minecraft:purple_terracotta
fill 553 149 270 553 151 270 minecraft:purple_terracotta
fill 557 149 228 557 151 228 minecraft:purple_terracotta
fill 557 149 270 557 151 270 minecraft:purple_terracotta
setblock 559 149 228 minecraft:purple_terracotta
fill 559 149 232 559 151 232 minecraft:purple_terracotta
fill 559 149 236 559 151 236 minecraft:purple_terracotta
fill 559 149 240 559 151 240 minecraft:purple_terracotta
fill 559 149 244 559 151 244 minecraft:purple_terracotta
fill 559 149 248 559 151 248 minecraft:purple_terracotta
fill 559 149 252 559 151 252 minecraft:purple_terracotta
fill 559 149 256 559 151 256 minecraft:purple_terracotta
fill 559 149 260 559 151 260 minecraft:purple_terracotta
fill 559 149 264 559 151 264 minecraft:purple_terracotta
fill 559 149 268 559 151 268 minecraft:purple_terracotta
setblock 517 150 230 minecraft:magenta_terracotta
setblock 517 150 234 minecraft:magenta_terracotta
setblock 517 150 238 minecraft:magenta_terracotta
setblock 517 150 242 minecraft:magenta_terracotta
setblock 517 150 246 minecraft:magenta_terracotta
setblock 517 150 250 minecraft:magenta_terracotta
setblock 517 150 254 minecraft:magenta_terracotta
fill 517 150 255 517 212 255 minecraft:purple_terracotta
setblock 517 150 258 minecraft:magenta_terracotta
setblock 517 150 262 minecraft:magenta_terracotta
setblock 517 150 266 minecraft:magenta_terracotta
setblock 517 150 270 minecraft:magenta_terracotta
setblock 519 150 228 minecraft:magenta_terracotta
setblock 519 150 270 minecraft:magenta_terracotta
setblock 523 150 228 minecraft:magenta_terracotta
setblock 523 150 270 minecraft:magenta_terracotta
setblock 527 150 228 minecraft:magenta_terracotta
setblock 527 150 270 minecraft:magenta_terracotta
setblock 531 150 228 minecraft:magenta_terracotta
setblock 531 150 270 minecraft:magenta_terracotta
fill 532 150 259 532 150 260 minecraft:white_concrete
setblock 532 150 261 minecraft:white_stained_glass
setblock 535 150 228 minecraft:magenta_terracotta
fill 535 150 259 535 150 260 minecraft:white_concrete
setblock 535 150 270 minecraft:magenta_terracotta
fill 536 150 268 537 150 269 minecraft:dark_oak_planks
fill 538 150 268 539 150 268 minecraft:spruce_planks
setblock 539 150 228 minecraft:magenta_terracotta
setblock 539 150 270 minecraft:magenta_terracotta
setblock 543 150 228 minecraft:magenta_terracotta
setblock 543 150 270 minecraft:magenta_terracotta
setblock 547 150 228 minecraft:magenta_terracotta
setblock 547 150 270 minecraft:magenta_terracotta
setblock 551 150 228 minecraft:magenta_terracotta
setblock 551 150 270 minecraft:magenta_terracotta
setblock 555 150 228 minecraft:magenta_terracotta
setblock 555 150 270 minecraft:magenta_terracotta
setblock 559 150 228 minecraft:magenta_terracotta
setblock 559 150 230 minecraft:magenta_terracotta
setblock 559 150 234 minecraft:magenta_terracotta
setblock 559 150 238 minecraft:magenta_terracotta
setblock 559 150 242 minecraft:magenta_terracotta
setblock 559 150 246 minecraft:magenta_terracotta
setblock 559 150 250 minecraft:magenta_terracotta
setblock 559 150 254 minecraft:magenta_terracotta
setblock 559 150 258 minecraft:magenta_terracotta
setblock 559 150 262 minecraft:magenta_terracotta
setblock 559 150 266 minecraft:magenta_terracotta
setblock 559 150 270 minecraft:magenta_terracotta
fill 517 151 230 517 153 230 minecraft:purple_terracotta
fill 517 151 234 517 153 234 minecraft:purple_terracotta
fill 517 151 238 517 153 238 minecraft:purple_terracotta
fill 517 151 242 517 153 242 minecraft:purple_terracotta
fill 517 151 246 517 153 246 minecraft:purple_terracotta
fill 517 151 250 517 153 250 minecraft:purple_terracotta
fill 517 151 254 517 153 254 minecraft:purple_terracotta
fill 517 151 258 517 153 258 minecraft:purple_terracotta
fill 517 151 262 517 153 262 minecraft:purple_terracotta
fill 517 151 266 517 153 266 minecraft:purple_terracotta
setblock 517 151 270 minecraft:purple_terracotta
fill 519 151 228 519 153 228 minecraft:purple_terracotta
fill 519 151 270 519 153 270 minecraft:purple_terracotta
fill 523 151 228 523 153 228 minecraft:purple_terracotta
fill 523 151 270 523 153 270 minecraft:purple_terracotta
fill 527 151 228 527 153 228 minecraft:purple_terracotta
fill 527 151 270 527 153 270 minecraft:purple_terracotta
fill 531 151 228 531 153 228 minecraft:purple_terracotta
fill 531 151 270 531 153 270 minecraft:purple_terracotta
fill 535 151 228 535 153 228 minecraft:purple_terracotta
fill 535 151 270 535 153 270 minecraft:purple_terracotta
fill 537 151 269 537 157 269 minecraft:gold_block
fill 538 151 268 539 151 269 minecraft:dark_oak_planks
fill 539 151 228 539 153 228 minecraft:purple_terracotta
fill 539 151 270 539 153 270 minecraft:purple_terracotta
fill 540 151 268 541 151 268 minecraft:spruce_planks
fill 540 151 269 541 151 269 minecraft:gold_block
fill 543 151 228 543 153 228 minecraft:purple_terracotta
fill 543 151 270 543 153 270 minecraft:purple_terracotta
fill 547 151 228 547 153 228 minecraft:purple_terracotta
fill 547 151 270 547 153 270 minecraft:purple_terracotta
fill 551 151 228 551 153 228 minecraft:purple_terracotta
fill 551 151 270 551 153 270 minecraft:purple_terracotta
fill 555 151 228 555 153 228 minecraft:purple_terracotta
fill 555 151 270 555 153 270 minecraft:purple_terracotta
setblock 559 151 228 minecraft:purple_terracotta
fill 559 151 230 559 153 230 minecraft:purple_terracotta
setblock 559 151 233 minecraft:light_gray_terracotta
fill 559 151 234 559 153 234 minecraft:purple_terracotta
fill 559 151 238 559 153 238 minecraft:purple_terracotta
fill 559 151 242 559 153 242 minecraft:purple_terracotta
fill 559 151 246 559 153 246 minecraft:purple_terracotta
fill 559 151 250 559 153 250 minecraft:purple_terracotta
fill 559 151 254 559 153 254 minecraft:purple_terracotta
fill 559 151 258 559 153 258 minecraft:purple_terracotta
fill 559 151 262 559 153 262 minecraft:purple_terracotta
fill 559 151 266 559 153 266 minecraft:purple_terracotta
fill 559 151 270 559 153 270 minecraft:purple_terracotta
setblock 517 152 228 minecraft:magenta_terracotta
setblock 517 152 232 minecraft:magenta_terracotta
setblock 517 152 236 minecraft:magenta_terracotta
setblock 517 152 240 minecraft:magenta_terracotta
setblock 517 152 244 minecraft:magenta_terracotta
setblock 517 152 248 minecraft:magenta_terracotta
setblock 517 152 252 minecraft:magenta_terracotta
setblock 517 152 256 minecraft:magenta_terracotta
setblock 517 152 260 minecraft:magenta_terracotta
setblock 517 152 264 minecraft:magenta_terracotta
setblock 517 152 268 minecraft:magenta_terracotta
setblock 517 152 270 minecraft:magenta_terracotta
setblock 520 152 231 minecraft:light[level=11]
setblock 520 152 239 minecraft:light[level=11]
setblock 520 152 247 minecraft:light[level=11]
setblock 520 152 255 minecraft:light[level=11]
setblock 520 152 263 minecraft:light[level=11]
setblock 521 152 228 minecraft:magenta_terracotta
setblock 521 152 270 minecraft:magenta_terracotta
setblock 525 152 228 minecraft:magenta_terracotta
setblock 525 152 270 minecraft:magenta_terracotta
setblock 528 152 231 minecraft:light[level=11]
setblock 528 152 239 minecraft:light[level=11]
setblock 528 152 247 minecraft:light[level=11]
setblock 528 152 255 minecraft:light[level=11]
setblock 528 152 263 minecraft:light[level=11]
setblock 529 152 228 minecraft:magenta_terracotta
setblock 529 152 270 minecraft:magenta_terracotta
setblock 533 152 228 minecraft:magenta_terracotta
setblock 533 152 270 minecraft:magenta_terracotta
setblock 536 152 231 minecraft:light[level=11]
setblock 536 152 239 minecraft:light[level=11]
setblock 536 152 247 minecraft:light[level=11]
setblock 536 152 255 minecraft:light[level=11]
setblock 536 152 263 minecraft:light[level=11]
setblock 537 152 228 minecraft:magenta_terracotta
setblock 537 152 270 minecraft:magenta_terracotta
fill 538 152 269 539 153 269 minecraft:black_concrete
fill 540 152 268 541 152 269 minecraft:dark_oak_planks
setblock 541 152 228 minecraft:magenta_terracotta
setblock 541 152 270 minecraft:magenta_terracotta
fill 542 152 268 543 152 268 minecraft:spruce_planks
fill 543 152 238 545 154 239 minecraft:white_stained_glass
setblock 544 152 231 minecraft:light[level=11]
fill 544 152 237 544 154 237 minecraft:white_stained_glass
setblock 544 152 247 minecraft:light[level=11]
setblock 544 152 255 minecraft:light[level=11]
setblock 544 152 263 minecraft:light[level=11]
setblock 545 152 228 minecraft:magenta_terracotta
setblock 545 152 270 minecraft:magenta_terracotta
setblock 549 152 228 minecraft:magenta_terracotta
setblock 549 152 270 minecraft:magenta_terracotta
setblock 552 152 231 minecraft:light[level=11]
setblock 552 152 239 minecraft:light[level=11]
setblock 552 152 247 minecraft:light[level=11]
setblock 552 152 255 minecraft:light[level=11]
setblock 552 152 263 minecraft:light[level=11]
setblock 553 152 228 minecraft:magenta_terracotta
setblock 553 152 270 minecraft:magenta_terracotta
setblock 557 152 228 minecraft:magenta_terracotta
setblock 557 152 270 minecraft:magenta_terracotta
setblock 559 152 228 minecraft:magenta_terracotta
setblock 559 152 232 minecraft:magenta_terracotta
fill 559 152 233 559 212 233 minecraft:purple_terracotta
setblock 559 152 236 minecraft:magenta_terracotta
setblock 559 152 240 minecraft:magenta_terracotta
setblock 559 152 244 minecraft:magenta_terracotta
setblock 559 152 248 minecraft:magenta_terracotta
setblock 559 152 252 minecraft:magenta_terracotta
setblock 559 152 256 minecraft:magenta_terracotta
setblock 559 152 260 minecraft:magenta_terracotta
setblock 559 152 264 minecraft:magenta_terracotta
setblock 559 152 268 minecraft:magenta_terracotta
fill 517 153 228 517 155 228 minecraft:purple_terracotta
fill 517 153 232 517 155 232 minecraft:purple_terracotta
fill 517 153 236 517 155 236 minecraft:purple_terracotta
fill 517 153 240 517 155 240 minecraft:purple_terracotta
fill 517 153 244 517 155 244 minecraft:purple_terracotta
fill 517 153 248 517 155 248 minecraft:purple_terracotta
fill 517 153 252 517 155 252 minecraft:purple_terracotta
fill 517 153 256 517 155 256 minecraft:purple_terracotta
fill 517 153 260 517 155 260 minecraft:purple_terracotta
fill 517 153 264 517 155 264 minecraft:purple_terracotta
fill 517 153 268 517 155 268 minecraft:purple_terracotta
setblock 517 153 270 minecraft:purple_terracotta
fill 521 153 228 521 155 228 minecraft:purple_terracotta
fill 521 153 270 521 155 270 minecraft:purple_terracotta
fill 525 153 228 525 155 228 minecraft:purple_terracotta
fill 525 153 270 525 155 270 minecraft:purple_terracotta
fill 529 153 228 529 155 228 minecraft:purple_terracotta
fill 529 153 270 529 155 270 minecraft:purple_terracotta
fill 533 153 228 533 155 228 minecraft:purple_terracotta
fill 533 153 270 533 155 270 minecraft:purple_terracotta
fill 537 153 228 537 155 228 minecraft:purple_terracotta
fill 537 153 270 537 155 270 minecraft:purple_terracotta
setblock 540 153 269 minecraft:black_concrete
fill 541 153 228 541 155 228 minecraft:purple_terracotta
fill 541 153 269 541 157 269 minecraft:gold_block
fill 541 153 270 541 155 270 minecraft:purple_terracotta
fill 542 153 268 543 153 269 minecraft:dark_oak_planks
fill 543 153 237 543 155 237 minecraft:white_stained_glass
fill 544 153 240 544 155 240 minecraft:white_stained_glass
fill 544 153 268 545 153 268 minecraft:spruce_planks
fill 545 153 228 545 155 228 minecraft:purple_terracotta
fill 545 153 237 545 155 237 minecraft:white_stained_glass
fill 545 153 270 545 155 270 minecraft:purple_terracotta
fill 549 153 228 549 155 228 minecraft:purple_terracotta
fill 549 153 270 549 155 270 minecraft:purple_terracotta
fill 553 153 228 553 155 228 minecraft:purple_terracotta
fill 553 153 270 553 155 270 minecraft:purple_terracotta
fill 557 153 228 557 155 228 minecraft:purple_terracotta
fill 557 153 270 557 155 270 minecraft:purple_terracotta
setblock 559 153 228 minecraft:purple_terracotta
fill 559 153 232 559 155 232 minecraft:purple_terracotta
fill 559 153 236 559 155 236 minecraft:purple_terracotta
fill 559 153 240 559 155 240 minecraft:purple_terracotta
fill 559 153 244 559 155 244 minecraft:purple_terracotta
fill 559 153 248 559 155 248 minecraft:purple_terracotta
fill 559 153 252 559 155 252 minecraft:purple_terracotta
fill 559 153 256 559 155 256 minecraft:purple_terracotta
fill 559 153 260 559 155 260 minecraft:purple_terracotta
fill 559 153 264 559 155 264 minecraft:purple_terracotta
fill 559 153 268 559 155 268 minecraft:purple_terracotta
setblock 517 154 230 minecraft:magenta_terracotta
setblock 517 154 234 minecraft:magenta_terracotta
setblock 517 154 238 minecraft:magenta_terracotta
setblock 517 154 242 minecraft:magenta_terracotta
setblock 517 154 246 minecraft:magenta_terracotta
setblock 517 154 250 minecraft:magenta_terracotta
setblock 517 154 254 minecraft:magenta_terracotta
setblock 517 154 258 minecraft:magenta_terracotta
setblock 517 154 262 minecraft:magenta_terracotta
setblock 517 154 266 minecraft:magenta_terracotta
setblock 517 154 270 minecraft:magenta_terracotta
setblock 519 154 228 minecraft:magenta_terracotta
setblock 519 154 270 minecraft:magenta_terracotta
setblock 520 154 231 minecraft:light[level=12]
setblock 520 154 238 minecraft:light[level=12]
setblock 520 154 245 minecraft:light[level=12]
setblock 520 154 252 minecraft:light[level=12]
setblock 520 154 259 minecraft:light[level=12]
setblock 520 154 266 minecraft:light[level=12]
setblock 523 154 228 minecraft:magenta_terracotta
setblock 523 154 270 minecraft:magenta_terracotta
setblock 527 154 228 minecraft:magenta_terracotta
setblock 527 154 231 minecraft:light[level=12]
setblock 527 154 238 minecraft:light[level=12]
setblock 527 154 245 minecraft:light[level=12]
setblock 527 154 252 minecraft:light[level=12]
setblock 527 154 259 minecraft:light[level=12]
setblock 527 154 266 minecraft:light[level=12]
setblock 527 154 270 minecraft:magenta_terracotta
setblock 531 154 228 minecraft:magenta_terracotta
setblock 531 154 270 minecraft:magenta_terracotta
setblock 534 154 231 minecraft:light[level=12]
setblock 534 154 238 minecraft:light[level=12]
setblock 534 154 245 minecraft:light[level=12]
setblock 534 154 252 minecraft:light[level=12]
setblock 534 154 259 minecraft:light[level=12]
setblock 534 154 266 minecraft:light[level=12]
setblock 535 154 228 minecraft:magenta_terracotta
setblock 535 154 270 minecraft:magenta_terracotta
fill 538 154 269 540 154 269 minecraft:light_gray_concrete
setblock 539 154 228 minecraft:magenta_terracotta
setblock 539 154 270 minecraft:magenta_terracotta
setblock 541 154 231 minecraft:light[level=12]
setblock 541 154 238 minecraft:light[level=12]
setblock 541 154 245 minecraft:light[level=12]
setblock 541 154 252 minecraft:light[level=12]
setblock 541 154 259 minecraft:light[level=12]
setblock 541 154 266 minecraft:light[level=12]
fill 542 154 238 542 155 239 minecraft:white_stained_glass
setblock 543 154 228 minecraft:magenta_terracotta
fill 543 154 240 543 155 240 minecraft:white_stained_glass
setblock 543 154 270 minecraft:magenta_terracotta
fill 544 154 268 545 154 269 minecraft:dark_oak_planks
fill 545 154 240 545 155 240 minecraft:white_stained_glass
fill 546 154 238 546 155 239 minecraft:white_stained_glass
fill 546 154 268 547 154 268 minecraft:spruce_planks
setblock 547 154 228 minecraft:magenta_terracotta
setblock 547 154 270 minecraft:magenta_terracotta
setblock 548 154 231 minecraft:light[level=12]
setblock 548 154 238 minecraft:light[level=12]
setblock 548 154 245 minecraft:light[level=12]
setblock 548 154 252 minecraft:light[level=12]
setblock 548 154 259 minecraft:light[level=12]
setblock 548 154 266 minecraft:light[level=12]
setblock 551 154 228 minecraft:magenta_terracotta
setblock 551 154 270 minecraft:magenta_terracotta
setblock 555 154 228 minecraft:magenta_terracotta
setblock 555 154 231 minecraft:light[level=12]
setblock 555 154 238 minecraft:light[level=12]
setblock 555 154 245 minecraft:light[level=12]
setblock 555 154 252 minecraft:light[level=12]
setblock 555 154 259 minecraft:light[level=12]
setblock 555 154 266 minecraft:light[level=12]
setblock 555 154 270 minecraft:magenta_terracotta
setblock 559 154 228 minecraft:magenta_terracotta
setblock 559 154 230 minecraft:magenta_terracotta
setblock 559 154 234 minecraft:magenta_terracotta
setblock 559 154 238 minecraft:magenta_terracotta
setblock 559 154 242 minecraft:magenta_terracotta
setblock 559 154 246 minecraft:magenta_terracotta
setblock 559 154 250 minecraft:magenta_terracotta
setblock 559 154 254 minecraft:magenta_terracotta
setblock 559 154 258 minecraft:magenta_terracotta
setblock 559 154 262 minecraft:magenta_terracotta
setblock 559 154 266 minecraft:magenta_terracotta
setblock 559 154 270 minecraft:magenta_terracotta
fill 517 155 230 517 157 230 minecraft:purple_terracotta
fill 517 155 234 517 157 234 minecraft:purple_terracotta
fill 517 155 238 517 157 238 minecraft:purple_terracotta
fill 517 155 242 517 157 242 minecraft:purple_terracotta
fill 517 155 246 517 157 246 minecraft:purple_terracotta
fill 517 155 250 517 157 250 minecraft:purple_terracotta
fill 517 155 254 517 157 254 minecraft:purple_terracotta
fill 517 155 258 517 157 258 minecraft:purple_terracotta
fill 517 155 262 517 157 262 minecraft:purple_terracotta
fill 517 155 266 517 157 266 minecraft:purple_terracotta
setblock 517 155 270 minecraft:purple_terracotta
fill 519 155 228 519 157 228 minecraft:purple_terracotta
fill 519 155 270 519 157 270 minecraft:purple_terracotta
fill 523 155 228 523 157 228 minecraft:purple_terracotta
fill 523 155 270 523 157 270 minecraft:purple_terracotta
fill 527 155 228 527 157 228 minecraft:purple_terracotta
fill 527 155 270 527 157 270 minecraft:purple_terracotta
fill 531 155 228 531 157 228 minecraft:purple_terracotta
fill 531 155 270 531 157 270 minecraft:purple_terracotta
fill 535 155 228 535 157 228 minecraft:purple_terracotta
fill 535 155 270 535 157 270 minecraft:purple_terracotta
setblock 538 155 269 minecraft:green_concrete
fill 539 155 228 539 157 228 minecraft:purple_terracotta
fill 539 155 269 539 156 269 minecraft:light_gray_concrete
fill 539 155 270 539 157 270 minecraft:purple_terracotta
setblock 540 155 269 minecraft:green_concrete
setblock 543 155 228 minecraft:purple_terracotta
fill 543 155 238 545 157 239 minecraft:white_concrete
fill 543 155 270 543 156 270 minecraft:purple_terracotta
setblock 544 155 237 minecraft:black_concrete
fill 546 155 268 547 155 269 minecraft:dark_oak_planks
fill 547 155 228 547 157 228 minecraft:purple_terracotta
fill 547 155 270 547 157 270 minecraft:purple_terracotta
fill 548 155 268 549 155 268 minecraft:spruce_planks
fill 551 155 228 551 157 228 minecraft:purple_terracotta
fill 551 155 270 551 157 270 minecraft:purple_terracotta
fill 555 155 228 555 157 228 minecraft:purple_terracotta
fill 555 155 270 555 157 270 minecraft:purple_terracotta
setblock 559 155 228 minecraft:purple_terracotta
fill 559 155 230 559 157 230 minecraft:purple_terracotta
fill 559 155 234 559 157 234 minecraft:purple_terracotta
fill 559 155 238 559 157 238 minecraft:purple_terracotta
fill 559 155 242 559 157 242 minecraft:purple_terracotta
fill 559 155 246 559 157 246 minecraft:purple_terracotta
fill 559 155 250 559 157 250 minecraft:purple_terracotta
fill 559 155 254 559 157 254 minecraft:purple_terracotta
fill 559 155 258 559 157 258 minecraft:purple_terracotta
fill 559 155 262 559 157 262 minecraft:purple_terracotta
fill 559 155 266 559 157 266 minecraft:purple_terracotta
fill 559 155 270 559 157 270 minecraft:purple_terracotta
setblock 517 156 228 minecraft:magenta_terracotta
setblock 517 156 232 minecraft:magenta_terracotta
setblock 517 156 236 minecraft:magenta_terracotta
setblock 517 156 240 minecraft:magenta_terracotta
setblock 517 156 244 minecraft:magenta_terracotta
setblock 517 156 248 minecraft:magenta_terracotta
setblock 517 156 252 minecraft:magenta_terracotta
setblock 517 156 256 minecraft:magenta_terracotta
setblock 517 156 260 minecraft:magenta_terracotta
setblock 517 156 264 minecraft:magenta_terracotta
setblock 517 156 268 minecraft:magenta_terracotta
setblock 517 156 270 minecraft:magenta_terracotta
setblock 521 156 228 minecraft:magenta_terracotta
setblock 521 156 270 minecraft:magenta_terracotta
setblock 525 156 228 minecraft:magenta_terracotta
setblock 525 156 270 minecraft:magenta_terracotta
setblock 529 156 228 minecraft:magenta_terracotta
setblock 529 156 270 minecraft:magenta_terracotta
setblock 533 156 228 minecraft:magenta_terracotta
setblock 533 156 270 minecraft:magenta_terracotta
setblock 537 156 228 minecraft:magenta_terracotta
setblock 537 156 270 minecraft:magenta_terracotta
setblock 538 156 269 minecraft:light_gray_concrete
setblock 540 156 269 minecraft:light_gray_concrete
setblock 541 156 228 minecraft:magenta_terracotta
setblock 541 156 270 minecraft:magenta_terracotta
setblock 543 156 228 minecraft:black_terracotta
setblock 543 156 237 minecraft:black_concrete
fill 544 156 237 544 157 237 minecraft:white_concrete
setblock 544 156 240 minecraft:white_concrete
setblock 545 156 228 minecraft:magenta_terracotta
setblock 545 156 237 minecraft:black_concrete
setblock 545 156 270 minecraft:magenta_terracotta
fill 548 156 268 549 156 269 minecraft:dark_oak_planks
setblock 549 156 228 minecraft:magenta_terracotta
setblock 549 156 270 minecraft:magenta_terracotta
fill 550 156 268 551 156 268 minecraft:spruce_planks
setblock 553 156 228 minecraft:magenta_terracotta
setblock 553 156 270 minecraft:magenta_terracotta
setblock 556 156 270 minecraft:light_gray_terracotta
setblock 557 156 228 minecraft:magenta_terracotta
setblock 557 156 270 minecraft:magenta_terracotta
setblock 559 156 228 minecraft:magenta_terracotta
setblock 559 156 232 minecraft:magenta_terracotta
setblock 559 156 236 minecraft:magenta_terracotta
setblock 559 156 240 minecraft:magenta_terracotta
setblock 559 156 244 minecraft:magenta_terracotta
setblock 559 156 248 minecraft:magenta_terracotta
setblock 559 156 252 minecraft:magenta_terracotta
setblock 559 156 256 minecraft:magenta_terracotta
setblock 559 156 260 minecraft:magenta_terracotta
setblock 559 156 264 minecraft:magenta_terracotta
setblock 559 156 268 minecraft:magenta_terracotta
fill 517 157 228 517 159 228 minecraft:purple_terracotta
fill 517 157 232 517 159 232 minecraft:purple_terracotta
fill 517 157 236 517 159 236 minecraft:purple_terracotta
fill 517 157 240 517 159 240 minecraft:purple_terracotta
fill 517 157 244 517 159 244 minecraft:purple_terracotta
fill 517 157 248 517 159 248 minecraft:purple_terracotta
fill 517 157 252 517 159 252 minecraft:purple_terracotta
fill 517 157 256 517 159 256 minecraft:purple_terracotta
fill 517 157 260 517 159 260 minecraft:purple_terracotta
fill 517 157 264 517 159 264 minecraft:purple_terracotta
fill 517 157 268 517 159 268 minecraft:purple_terracotta
setblock 517 157 270 minecraft:purple_terracotta
fill 521 157 228 521 159 228 minecraft:purple_terracotta
fill 521 157 270 521 159 270 minecraft:purple_terracotta
fill 525 157 228 525 159 228 minecraft:purple_terracotta
fill 525 157 270 525 159 270 minecraft:purple_terracotta
fill 529 157 228 529 159 228 minecraft:purple_terracotta
fill 529 157 270 529 159 270 minecraft:purple_terracotta
fill 533 157 228 533 159 228 minecraft:purple_terracotta
fill 533 157 270 533 158 270 minecraft:purple_terracotta
fill 537 157 228 537 159 228 minecraft:purple_terracotta
fill 537 157 270 537 159 270 minecraft:purple_terracotta
fill 538 157 269 540 157 269 minecraft:gold_block
fill 541 157 228 541 159 228 minecraft:purple_terracotta
fill 541 157 270 541 159 270 minecraft:purple_terracotta
setblock 543 157 228 minecraft:purple_terracotta
setblock 543 157 270 minecraft:black_terracotta
fill 545 157 228 545 159 228 minecraft:purple_terracotta
fill 545 157 270 545 159 270 minecraft:purple_terracotta
fill 549 157 228 549 159 228 minecraft:purple_terracotta
fill 549 157 270 549 159 270 minecraft:purple_terracotta
fill 550 157 268 551 157 269 minecraft:dark_oak_planks
fill 552 157 268 553 157 268 minecraft:spruce_planks
fill 553 157 228 553 159 228 minecraft:purple_terracotta
fill 553 157 270 553 159 270 minecraft:purple_terracotta
fill 556 157 270 557 159 270 minecraft:purple_terracotta
fill 557 157 228 557 159 228 minecraft:purple_terracotta
setblock 559 157 228 minecraft:purple_terracotta
fill 559 157 232 559 159 232 minecraft:purple_terracotta
fill 559 157 236 559 159 236 minecraft:purple_terracotta
fill 559 157 240 559 159 240 minecraft:purple_terracotta
fill 559 157 244 559 159 244 minecraft:purple_terracotta
fill 559 157 248 559 159 248 minecraft:purple_terracotta
fill 559 157 252 559 159 252 minecraft:purple_terracotta
fill 559 157 256 559 159 256 minecraft:purple_terracotta
fill 559 157 260 559 159 260 minecraft:purple_terracotta
fill 559 157 264 559 159 264 minecraft:purple_terracotta
fill 559 157 268 559 159 268 minecraft:purple_terracotta
setblock 517 158 230 minecraft:magenta_terracotta
setblock 517 158 234 minecraft:magenta_terracotta
setblock 517 158 238 minecraft:magenta_terracotta
setblock 517 158 242 minecraft:magenta_terracotta
setblock 517 158 246 minecraft:magenta_terracotta
setblock 517 158 250 minecraft:magenta_terracotta
setblock 517 158 254 minecraft:magenta_terracotta
setblock 517 158 258 minecraft:magenta_terracotta
setblock 517 158 262 minecraft:magenta_terracotta
setblock 517 158 266 minecraft:magenta_terracotta
setblock 517 158 270 minecraft:magenta_terracotta
setblock 519 158 228 minecraft:magenta_terracotta
setblock 519 158 270 minecraft:magenta_terracotta
setblock 523 158 228 minecraft:magenta_terracotta
setblock 523 158 270 minecraft:magenta_terracotta
setblock 527 158 228 minecraft:magenta_terracotta
setblock 527 158 270 minecraft:magenta_terracotta
setblock 531 158 228 minecraft:magenta_terracotta
setblock 531 158 270 minecraft:magenta_terracotta
setblock 535 158 228 minecraft:magenta_terracotta
setblock 535 158 270 minecraft:magenta_terracotta
setblock 539 158 228 minecraft:magenta_terracotta
setblock 539 158 270 minecraft:magenta_terracotta
setblock 543 158 228 minecraft:magenta_terracotta
setblock 543 158 264 minecraft:jack_o_lantern
setblock 543 158 270 minecraft:magenta_terracotta
setblock 547 158 228 minecraft:magenta_terracotta
setblock 547 158 270 minecraft:magenta_terracotta
setblock 551 158 228 minecraft:magenta_terracotta
setblock 551 158 270 minecraft:magenta_terracotta
fill 552 158 268 553 158 269 minecraft:dark_oak_planks
fill 554 158 268 555 158 268 minecraft:spruce_planks
setblock 555 158 228 minecraft:magenta_terracotta
setblock 555 158 270 minecraft:magenta_terracotta
setblock 559 158 228 minecraft:magenta_terracotta
setblock 559 158 230 minecraft:magenta_terracotta
setblock 559 158 234 minecraft:magenta_terracotta
setblock 559 158 238 minecraft:magenta_terracotta
setblock 559 158 242 minecraft:magenta_terracotta
setblock 559 158 246 minecraft:magenta_terracotta
setblock 559 158 250 minecraft:magenta_terracotta
setblock 559 158 254 minecraft:magenta_terracotta
setblock 559 158 257 minecraft:black_terracotta
setblock 559 158 258 minecraft:magenta_terracotta
setblock 559 158 262 minecraft:magenta_terracotta
setblock 559 158 266 minecraft:magenta_terracotta
setblock 559 158 270 minecraft:magenta_terracotta
fill 517 159 230 517 161 230 minecraft:purple_terracotta
fill 517 159 234 517 161 234 minecraft:purple_terracotta
fill 517 159 238 517 161 238 minecraft:purple_terracotta
fill 517 159 242 517 161 242 minecraft:purple_terracotta
fill 517 159 246 517 161 246 minecraft:purple_terracotta
fill 517 159 250 517 161 250 minecraft:purple_terracotta
fill 517 159 254 517 161 254 minecraft:purple_terracotta
fill 517 159 258 517 161 258 minecraft:purple_terracotta
fill 517 159 262 517 161 262 minecraft:purple_terracotta
fill 517 159 266 517 161 266 minecraft:purple_terracotta
setblock 517 159 270 minecraft:purple_terracotta
fill 519 159 228 519 161 228 minecraft:purple_terracotta
fill 519 159 270 519 161 270 minecraft:purple_terracotta
fill 523 159 228 523 161 228 minecraft:purple_terracotta
fill 523 159 270 523 161 270 minecraft:purple_terracotta
fill 527 159 228 527 161 228 minecraft:purple_terracotta
fill 527 159 270 527 161 270 minecraft:purple_terracotta
fill 531 159 228 531 161 228 minecraft:purple_terracotta
fill 531 159 270 531 161 270 minecraft:purple_terracotta
setblock 533 159 270 minecraft:light_gray_terracotta
fill 535 159 228 535 161 228 minecraft:purple_terracotta
fill 535 159 270 535 161 270 minecraft:purple_terracotta
fill 539 159 228 539 161 228 minecraft:purple_terracotta
fill 539 159 270 539 161 270 minecraft:purple_terracotta
fill 543 159 228 543 161 228 minecraft:purple_terracotta
fill 543 159 270 543 161 270 minecraft:purple_terracotta
fill 547 159 228 547 161 228 minecraft:purple_terracotta
fill 547 159 270 547 161 270 minecraft:purple_terracotta
fill 551 159 228 551 161 228 minecraft:purple_terracotta
fill 551 159 270 551 161 270 minecraft:purple_terracotta
fill 554 159 268 555 159 269 minecraft:dark_oak_planks
fill 555 159 228 555 161 228 minecraft:purple_terracotta
fill 555 159 270 555 161 270 minecraft:purple_terracotta
fill 556 159 268 557 159 268 minecraft:spruce_planks
setblock 559 159 228 minecraft:purple_terracotta
fill 559 159 230 559 161 230 minecraft:purple_terracotta
fill 559 159 234 559 161 234 minecraft:purple_terracotta
fill 559 159 238 559 161 238 minecraft:purple_terracotta
fill 559 159 242 559 161 242 minecraft:purple_terracotta
fill 559 159 246 559 161 246 minecraft:purple_terracotta
fill 559 159 250 559 161 250 minecraft:purple_terracotta
fill 559 159 254 559 161 254 minecraft:purple_terracotta
fill 559 159 257 559 161 258 minecraft:purple_terracotta
fill 559 159 262 559 161 262 minecraft:purple_terracotta
fill 559 159 266 559 161 266 minecraft:purple_terracotta
fill 559 159 270 559 161 270 minecraft:purple_terracotta
setblock 517 160 228 minecraft:magenta_terracotta
setblock 517 160 232 minecraft:magenta_terracotta
setblock 517 160 236 minecraft:magenta_terracotta
setblock 517 160 240 minecraft:magenta_terracotta
setblock 517 160 244 minecraft:magenta_terracotta
setblock 517 160 248 minecraft:magenta_terracotta
setblock 517 160 252 minecraft:magenta_terracotta
setblock 517 160 256 minecraft:magenta_terracotta
setblock 517 160 260 minecraft:magenta_terracotta
setblock 517 160 264 minecraft:magenta_terracotta
setblock 517 160 268 minecraft:magenta_terracotta
setblock 517 160 270 minecraft:magenta_terracotta
setblock 520 160 231 minecraft:light[level=11]
setblock 520 160 238 minecraft:light[level=12]
setblock 520 160 239 minecraft:light[level=11]
setblock 520 160 245 minecraft:light[level=12]
setblock 520 160 247 minecraft:light[level=11]
setblock 520 160 252 minecraft:light[level=12]
setblock 520 160 255 minecraft:light[level=11]
setblock 520 160 259 minecraft:light[level=12]
setblock 520 160 263 minecraft:light[level=11]
setblock 520 160 266 minecraft:light[level=12]
setblock 521 160 228 minecraft:magenta_terracotta
setblock 521 160 270 minecraft:magenta_terracotta
setblock 525 160 228 minecraft:magenta_terracotta
setblock 525 160 270 minecraft:magenta_terracotta
setblock 527 160 231 minecraft:light[level=12]
setblock 527 160 238 minecraft:light[level=12]
setblock 527 160 245 minecraft:light[level=12]
setblock 527 160 252 minecraft:light[level=12]
setblock 527 160 259 minecraft:light[level=12]
setblock 527 160 266 minecraft:light[level=12]
setblock 528 160 231 minecraft:light[level=11]
setblock 528 160 239 minecraft:light[level=11]
setblock 528 160 247 minecraft:light[level=11]
setblock 528 160 255 minecraft:light[level=11]
setblock 528 160 263 minecraft:light[level=11]
setblock 529 160 228 minecraft:magenta_terracotta
setblock 529 160 270 minecraft:magenta_terracotta
setblock 533 160 228 minecraft:magenta_terracotta
setblock 533 160 270 minecraft:magenta_terracotta
setblock 534 160 231 minecraft:light[level=12]
setblock 534 160 238 minecraft:light[level=12]
setblock 534 160 245 minecraft:light[level=12]
setblock 534 160 252 minecraft:light[level=12]
setblock 534 160 259 minecraft:light[level=12]
setblock 534 160 266 minecraft:light[level=12]
setblock 536 160 231 minecraft:light[level=11]
setblock 536 160 239 minecraft:light[level=11]
setblock 536 160 247 minecraft:light[level=11]
setblock 536 160 255 minecraft:light[level=11]
setblock 536 160 263 minecraft:light[level=11]
setblock 537 160 228 minecraft:magenta_terracotta
setblock 537 160 270 minecraft:magenta_terracotta
setblock 541 160 228 minecraft:magenta_terracotta
setblock 541 160 231 minecraft:light[level=12]
setblock 541 160 238 minecraft:light[level=12]
setblock 541 160 245 minecraft:light[level=12]
setblock 541 160 252 minecraft:light[level=12]
setblock 541 160 259 minecraft:light[level=12]
setblock 541 160 266 minecraft:light[level=12]
setblock 541 160 270 minecraft:magenta_terracotta
setblock 544 160 231 minecraft:light[level=11]
setblock 544 160 239 minecraft:light[level=11]
setblock 544 160 247 minecraft:light[level=11]
setblock 544 160 255 minecraft:light[level=11]
setblock 544 160 263 minecraft:light[level=11]
setblock 545 160 228 minecraft:magenta_terracotta
setblock 545 160 270 minecraft:magenta_terracotta
setblock 548 160 231 minecraft:light[level=12]
setblock 548 160 238 minecraft:light[level=12]
setblock 548 160 245 minecraft:light[level=12]
setblock 548 160 252 minecraft:light[level=12]
setblock 548 160 259 minecraft:light[level=12]
setblock 548 160 266 minecraft:light[level=12]
setblock 549 160 228 minecraft:magenta_terracotta
setblock 549 160 270 minecraft:magenta_terracotta
setblock 550 160 228 minecraft:black_terracotta
setblock 552 160 231 minecraft:light[level=11]
setblock 552 160 239 minecraft:light[level=11]
setblock 552 160 247 minecraft:light[level=11]
setblock 552 160 255 minecraft:light[level=11]
setblock 552 160 263 minecraft:light[level=11]
setblock 553 160 228 minecraft:magenta_terracotta
setblock 553 160 270 minecraft:magenta_terracotta
setblock 555 160 231 minecraft:light[level=12]
setblock 555 160 238 minecraft:light[level=12]
setblock 555 160 245 minecraft:light[level=12]
setblock 555 160 252 minecraft:light[level=12]
setblock 555 160 259 minecraft:light[level=12]
setblock 555 160 266 minecraft:light[level=12]
fill 556 160 268 558 160 269 minecraft:dark_oak_planks
fill 556 160 270 556 212 270 minecraft:purple_terracotta
setblock 557 160 228 minecraft:magenta_terracotta
setblock 557 160 267 minecraft:spruce_planks
setblock 557 160 270 minecraft:magenta_terracotta
setblock 559 160 228 minecraft:magenta_terracotta
setblock 559 160 232 minecraft:magenta_terracotta
setblock 559 160 236 minecraft:magenta_terracotta
setblock 559 160 240 minecraft:magenta_terracotta
setblock 559 160 244 minecraft:magenta_terracotta
setblock 559 160 248 minecraft:magenta_terracotta
setblock 559 160 252 minecraft:magenta_terracotta
setblock 559 160 256 minecraft:magenta_terracotta
setblock 559 160 260 minecraft:magenta_terracotta
setblock 559 160 264 minecraft:magenta_terracotta
setblock 559 160 268 minecraft:magenta_terracotta
fill 517 161 228 517 163 228 minecraft:purple_terracotta
fill 517 161 232 517 163 232 minecraft:purple_terracotta
fill 517 161 236 517 163 236 minecraft:purple_terracotta
fill 517 161 240 517 163 240 minecraft:purple_terracotta
fill 517 161 244 517 163 244 minecraft:purple_terracotta
fill 517 161 248 517 163 248 minecraft:purple_terracotta
fill 517 161 252 517 163 252 minecraft:purple_terracotta
fill 517 161 256 517 163 256 minecraft:purple_terracotta
fill 517 161 260 517 163 260 minecraft:purple_terracotta
fill 517 161 264 517 163 264 minecraft:purple_terracotta
fill 517 161 268 517 163 268 minecraft:purple_terracotta
setblock 517 161 270 minecraft:purple_terracotta
fill 521 161 228 521 163 228 minecraft:purple_terracotta
fill 521 161 270 521 163 270 minecraft:purple_terracotta
fill 525 161 228 525 163 228 minecraft:purple_terracotta
fill 525 161 270 525 163 270 minecraft:purple_terracotta
fill 529 161 228 529 163 228 minecraft:purple_terracotta
fill 529 161 270 529 163 270 minecraft:purple_terracotta
fill 533 161 228 533 163 228 minecraft:purple_terracotta
fill 533 161 270 533 163 270 minecraft:purple_terracotta
fill 537 161 228 537 163 228 minecraft:purple_terracotta
fill 537 161 270 537 163 270 minecraft:purple_terracotta
fill 541 161 228 541 163 228 minecraft:purple_terracotta
fill 541 161 270 541 163 270 minecraft:purple_terracotta
fill 545 161 228 545 163 228 minecraft:purple_terracotta
fill 545 161 270 545 163 270 minecraft:purple_terracotta
fill 549 161 228 550 163 228 minecraft:purple_terracotta
fill 549 161 270 549 163 270 minecraft:purple_terracotta
fill 553 161 228 553 163 228 minecraft:purple_terracotta
fill 553 161 270 553 163 270 minecraft:purple_terracotta
fill 557 161 228 557 163 228 minecraft:purple_terracotta
fill 557 161 265 557 161 266 minecraft:spruce_planks
fill 557 161 267 558 161 269 minecraft:dark_oak_planks
setblock 557 161 270 minecraft:purple_terracotta
setblock 559 161 228 minecraft:purple_terracotta
fill 559 161 232 559 163 232 minecraft:purple_terracotta
fill 559 161 236 559 163 236 minecraft:purple_terracotta
fill 559 161 240 559 163 240 minecraft:purple_terracotta
fill 559 161 244 559 163 244 minecraft:purple_terracotta
fill 559 161 248 559 163 248 minecraft:purple_terracotta
fill 559 161 252 559 163 252 minecraft:purple_terracotta
fill 559 161 256 559 163 256 minecraft:purple_terracotta
fill 559 161 260 559 163 260 minecraft:purple_terracotta
fill 559 161 264 559 163 264 minecraft:purple_terracotta
fill 559 161 268 559 163 268 minecraft:purple_terracotta
setblock 517 162 230 minecraft:magenta_terracotta
setblock 517 162 234 minecraft:magenta_terracotta
setblock 517 162 238 minecraft:magenta_terracotta
setblock 517 162 242 minecraft:magenta_terracotta
setblock 517 162 246 minecraft:magenta_terracotta
setblock 517 162 250 minecraft:magenta_terracotta
setblock 517 162 254 minecraft:magenta_terracotta
setblock 517 162 258 minecraft:magenta_terracotta
setblock 517 162 262 minecraft:magenta_terracotta
setblock 517 162 266 minecraft:magenta_terracotta
setblock 517 162 270 minecraft:magenta_terracotta
setblock 519 162 228 minecraft:magenta_terracotta
setblock 519 162 270 minecraft:magenta_terracotta
setblock 523 162 228 minecraft:magenta_terracotta
setblock 523 162 270 minecraft:magenta_terracotta
schedule function dropper:buildpart/59_2 1t
