fill 474 239 297 474 240 297 minecraft:deepslate_tiles
setblock 474 239 301 minecraft:cobbled_deepslate
fill 474 239 302 474 242 302 minecraft:deepslate_tiles
setblock 474 239 315 minecraft:deepslate_tiles
setblock 474 239 316 minecraft:cobbled_deepslate
fill 475 239 276 475 242 276 minecraft:deepslate_tiles
fill 475 239 295 475 241 295 minecraft:black_concrete
fill 475 239 297 475 241 297 minecraft:black_concrete
setblock 475 239 315 minecraft:cobbled_deepslate
fill 475 239 316 478 239 316 minecraft:deepslate_tiles
fill 476 239 296 476 241 296 minecraft:black_concrete
fill 476 239 315 476 240 315 minecraft:deepslate_tiles
setblock 478 239 277 minecraft:cobbled_deepslate
setblock 479 239 276 minecraft:cobbled_deepslate
setblock 479 239 316 minecraft:cobbled_deepslate
fill 480 239 276 480 240 276 minecraft:deepslate_tiles
setblock 480 239 316 minecraft:deepslate_tiles
fill 485 239 276 488 239 276 minecraft:deepslate_tiles
setblock 488 239 277 minecraft:cobbled_deepslate
setblock 489 239 276 minecraft:cobbled_deepslate
fill 489 239 277 492 239 277 minecraft:deepslate_tiles
fill 489 239 278 489 240 278 minecraft:cobbled_deepslate
setblock 489 239 316 minecraft:cobbled_deepslate
fill 490 239 276 493 239 276 minecraft:deepslate_tiles
fill 490 239 278 491 239 278 minecraft:deepslate_tiles
fill 490 239 316 493 239 316 minecraft:deepslate_tiles
setblock 492 239 278 minecraft:cobbled_deepslate
fill 492 239 279 495 239 279 minecraft:deepslate_tiles
setblock 493 239 277 minecraft:cobbled_deepslate
fill 493 239 278 493 242 278 minecraft:deepslate_tiles
setblock 494 239 276 minecraft:cobbled_deepslate
fill 494 239 277 497 239 277 minecraft:deepslate_tiles
setblock 494 239 315 minecraft:deepslate_tiles
setblock 494 239 316 minecraft:cobbled_deepslate
fill 495 239 276 498 239 276 minecraft:deepslate_tiles
setblock 495 239 315 minecraft:cobbled_deepslate
fill 495 239 316 498 239 316 minecraft:deepslate_tiles
setblock 496 239 279 minecraft:cobbled_deepslate
setblock 496 239 315 minecraft:deepslate_tiles
setblock 497 239 278 minecraft:cobbled_deepslate
fill 497 239 279 497 240 279 minecraft:deepslate_tiles
setblock 498 239 277 minecraft:cobbled_deepslate
fill 498 239 278 498 242 278 minecraft:deepslate_tiles
setblock 499 239 276 minecraft:cobbled_deepslate
fill 499 239 277 499 242 277 minecraft:deepslate_tiles
setblock 499 239 316 minecraft:cobbled_deepslate
fill 500 239 276 503 239 276 minecraft:deepslate_tiles
fill 500 239 316 503 239 316 minecraft:deepslate_tiles
setblock 502 239 278 minecraft:cobbled_deepslate
setblock 503 239 277 minecraft:cobbled_deepslate
setblock 503 239 278 minecraft:deepslate_tiles
setblock 504 239 276 minecraft:cobbled_deepslate
fill 504 239 277 504 242 277 minecraft:deepslate_tiles
setblock 504 239 316 minecraft:cobbled_deepslate
fill 505 239 276 505 242 276 minecraft:deepslate_tiles
fill 505 239 316 505 241 316 minecraft:deepslate_tiles
setblock 507 239 278 minecraft:cobbled_deepslate
setblock 508 239 277 minecraft:cobbled_deepslate
fill 508 239 278 508 241 278 minecraft:deepslate_tiles
setblock 509 239 276 minecraft:cobbled_deepslate
fill 509 239 277 509 242 277 minecraft:deepslate_tiles
setblock 509 239 316 minecraft:cobbled_deepslate
fill 510 239 276 510 242 276 minecraft:deepslate_tiles
setblock 510 239 280 minecraft:cobbled_deepslate
fill 510 239 281 510 242 281 minecraft:deepslate_tiles
setblock 510 239 300 minecraft:cobbled_deepslate
fill 510 239 301 510 240 303 minecraft:deepslate_tiles
setblock 510 239 315 minecraft:cobbled_deepslate
fill 510 239 316 510 242 316 minecraft:deepslate_tiles
setblock 511 239 279 minecraft:cobbled_deepslate
fill 511 239 280 511 242 280 minecraft:deepslate_tiles
setblock 511 239 283 minecraft:deepslate_tiles
setblock 511 239 284 minecraft:cobbled_deepslate
fill 511 239 285 511 242 285 minecraft:deepslate_tiles
setblock 511 239 293 minecraft:deepslate_tiles
setblock 511 239 294 minecraft:cobbled_deepslate
fill 511 239 295 511 242 295 minecraft:deepslate_tiles
setblock 511 239 299 minecraft:cobbled_deepslate
fill 511 239 300 511 242 300 minecraft:deepslate_tiles
setblock 511 239 303 minecraft:deepslate_tiles
setblock 511 239 304 minecraft:cobbled_deepslate
fill 511 239 305 511 242 305 minecraft:deepslate_tiles
setblock 511 239 309 minecraft:cobbled_deepslate
fill 511 239 310 511 242 310 minecraft:deepslate_tiles
setblock 511 239 314 minecraft:cobbled_deepslate
fill 511 239 315 511 242 315 minecraft:deepslate_tiles
fill 471 240 276 471 240 277 minecraft:deepslate_tiles
setblock 471 240 278 minecraft:cobbled_deepslate
fill 471 240 279 471 243 279 minecraft:deepslate_tiles
setblock 471 240 283 minecraft:cobbled_deepslate
fill 471 240 284 471 243 284 minecraft:deepslate_tiles
fill 471 240 291 471 240 292 minecraft:deepslate_tiles
setblock 471 240 293 minecraft:cobbled_deepslate
fill 471 240 294 471 240 297 minecraft:deepslate_tiles
setblock 471 240 298 minecraft:cobbled_deepslate
fill 471 240 299 471 240 302 minecraft:deepslate_tiles
setblock 471 240 303 minecraft:cobbled_deepslate
fill 471 240 304 471 240 307 minecraft:deepslate_tiles
setblock 471 240 308 minecraft:cobbled_deepslate
fill 471 240 309 471 240 312 minecraft:deepslate_tiles
setblock 471 240 313 minecraft:cobbled_deepslate
fill 471 240 314 471 241 316 minecraft:deepslate_tiles
setblock 472 240 276 minecraft:deepslate_tiles
setblock 472 240 277 minecraft:cobbled_deepslate
fill 472 240 278 472 243 278 minecraft:deepslate_tiles
setblock 472 240 282 minecraft:cobbled_deepslate
setblock 472 240 293 minecraft:deepslate_tiles
setblock 472 240 297 minecraft:cobbled_deepslate
fill 472 240 298 472 240 301 minecraft:deepslate_tiles
setblock 472 240 302 minecraft:cobbled_deepslate
fill 472 240 303 472 240 306 minecraft:deepslate_tiles
setblock 472 240 307 minecraft:cobbled_deepslate
fill 472 240 308 472 240 311 minecraft:deepslate_tiles
setblock 472 240 312 minecraft:cobbled_deepslate
fill 472 240 313 472 241 313 minecraft:deepslate_tiles
fill 472 240 315 472 240 316 minecraft:deepslate_tiles
setblock 473 240 276 minecraft:cobbled_deepslate
fill 473 240 277 473 242 277 minecraft:deepslate_tiles
setblock 473 240 296 minecraft:cobbled_deepslate
fill 473 240 297 473 243 297 minecraft:deepslate_tiles
setblock 473 240 301 minecraft:cobbled_deepslate
fill 473 240 302 473 240 305 minecraft:deepslate_tiles
setblock 473 240 306 minecraft:cobbled_deepslate
fill 473 240 307 473 243 307 minecraft:deepslate_tiles
setblock 473 240 315 minecraft:deepslate_tiles
setblock 473 240 316 minecraft:cobbled_deepslate
fill 474 240 276 474 243 276 minecraft:deepslate_tiles
fill 474 240 296 474 241 296 minecraft:black_concrete
setblock 474 240 300 minecraft:cobbled_deepslate
fill 474 240 301 474 243 301 minecraft:deepslate_tiles
setblock 474 240 315 minecraft:cobbled_deepslate
fill 474 240 316 477 240 316 minecraft:deepslate_tiles
setblock 475 240 315 minecraft:deepslate_tiles
setblock 477 240 277 minecraft:cobbled_deepslate
setblock 478 240 276 minecraft:cobbled_deepslate
setblock 478 240 316 minecraft:cobbled_deepslate
setblock 479 240 276 minecraft:deepslate_tiles
setblock 479 240 316 minecraft:deepslate_tiles
fill 486 240 276 487 240 276 minecraft:deepslate_tiles
setblock 488 240 276 minecraft:cobbled_deepslate
fill 488 240 277 491 240 277 minecraft:deepslate_tiles
fill 489 240 276 492 240 276 minecraft:deepslate_tiles
setblock 490 240 278 minecraft:deepslate_tiles
fill 490 240 316 492 240 316 minecraft:deepslate_tiles
setblock 491 240 278 minecraft:cobbled_deepslate
setblock 492 240 277 minecraft:cobbled_deepslate
fill 492 240 278 492 242 279 minecraft:deepslate_tiles
setblock 493 240 276 minecraft:cobbled_deepslate
fill 493 240 277 496 240 277 minecraft:deepslate_tiles
fill 493 240 279 494 240 279 minecraft:deepslate_tiles
setblock 493 240 316 minecraft:cobbled_deepslate
fill 493 240 317 493 308 317 minecraft:deepslate_tiles
fill 494 240 276 497 240 276 minecraft:deepslate_tiles
fill 494 240 316 497 240 316 minecraft:deepslate_tiles
setblock 494 240 317 minecraft:redstone_block
setblock 495 240 279 minecraft:cobbled_deepslate
fill 495 240 317 498 308 317 minecraft:deepslate_tiles
setblock 496 240 278 minecraft:cobbled_deepslate
fill 496 240 279 496 241 279 minecraft:deepslate_tiles
setblock 497 240 277 minecraft:cobbled_deepslate
fill 497 240 278 497 243 278 minecraft:deepslate_tiles
setblock 498 240 276 minecraft:cobbled_deepslate
fill 498 240 277 498 243 277 minecraft:deepslate_tiles
setblock 498 240 316 minecraft:cobbled_deepslate
fill 499 240 276 502 240 276 minecraft:deepslate_tiles
fill 499 240 316 502 240 316 minecraft:deepslate_tiles
setblock 501 240 278 minecraft:cobbled_deepslate
setblock 502 240 277 minecraft:cobbled_deepslate
setblock 503 240 276 minecraft:cobbled_deepslate
fill 503 240 277 503 242 277 minecraft:deepslate_tiles
setblock 503 240 316 minecraft:cobbled_deepslate
fill 504 240 276 504 243 276 minecraft:deepslate_tiles
setblock 504 240 316 minecraft:deepslate_tiles
setblock 507 240 277 minecraft:cobbled_deepslate
setblock 507 240 278 minecraft:deepslate_tiles
setblock 508 240 276 minecraft:cobbled_deepslate
fill 508 240 277 508 243 277 minecraft:deepslate_tiles
setblock 508 240 316 minecraft:cobbled_deepslate
fill 509 240 276 509 243 276 minecraft:deepslate_tiles
setblock 509 240 315 minecraft:cobbled_deepslate
fill 509 240 316 509 243 316 minecraft:deepslate_tiles
setblock 510 240 279 minecraft:cobbled_deepslate
fill 510 240 280 510 243 280 minecraft:deepslate_tiles
setblock 510 240 298 minecraft:deepslate_tiles
setblock 510 240 299 minecraft:cobbled_deepslate
fill 510 240 300 510 243 300 minecraft:deepslate_tiles
setblock 510 240 304 minecraft:cobbled_deepslate
fill 510 240 305 510 243 305 minecraft:deepslate_tiles
setblock 510 240 314 minecraft:cobbled_deepslate
fill 510 240 315 510 243 315 minecraft:deepslate_tiles
setblock 511 240 278 minecraft:cobbled_deepslate
fill 511 240 279 511 243 279 minecraft:deepslate_tiles
setblock 511 240 283 minecraft:cobbled_deepslate
fill 511 240 284 511 243 284 minecraft:deepslate_tiles
fill 511 240 294 511 241 294 minecraft:deepslate_tiles
setblock 511 240 298 minecraft:cobbled_deepslate
fill 511 240 299 511 243 299 minecraft:deepslate_tiles
setblock 511 240 303 minecraft:cobbled_deepslate
fill 511 240 304 511 243 304 minecraft:deepslate_tiles
setblock 511 240 308 minecraft:cobbled_deepslate
fill 511 240 309 511 243 309 minecraft:deepslate_tiles
setblock 511 240 313 minecraft:cobbled_deepslate
fill 511 240 314 511 243 314 minecraft:deepslate_tiles
fill 512 240 288 512 308 289 minecraft:deepslate_tiles
setblock 512 240 290 minecraft:redstone_block
fill 512 240 291 512 308 291 minecraft:deepslate_tiles
setblock 470 241 292 minecraft:white_wool
fill 470 241 293 471 241 296 minecraft:deepslate_tiles
setblock 471 241 276 minecraft:deepslate_tiles
setblock 471 241 277 minecraft:cobbled_deepslate
fill 471 241 278 471 244 278 minecraft:deepslate_tiles
setblock 471 241 281 minecraft:deepslate_tiles
setblock 471 241 282 minecraft:cobbled_deepslate
fill 471 241 283 471 244 283 minecraft:deepslate_tiles
fill 471 241 285 471 242 285 minecraft:deepslate_tiles
setblock 471 241 292 minecraft:cobbled_deepslate
setblock 471 241 297 minecraft:cobbled_deepslate
fill 471 241 298 471 241 301 minecraft:deepslate_tiles
setblock 471 241 302 minecraft:cobbled_deepslate
fill 471 241 303 471 241 306 minecraft:deepslate_tiles
setblock 471 241 307 minecraft:cobbled_deepslate
fill 471 241 308 471 241 311 minecraft:deepslate_tiles
setblock 471 241 312 minecraft:cobbled_deepslate
fill 471 241 313 471 244 313 minecraft:deepslate_tiles
setblock 472 241 276 minecraft:cobbled_deepslate
fill 472 241 277 472 242 277 minecraft:deepslate_tiles
setblock 472 241 281 minecraft:cobbled_deepslate
fill 472 241 282 472 244 282 minecraft:deepslate_tiles
setblock 472 241 295 minecraft:deepslate_tiles
setblock 472 241 296 minecraft:cobbled_deepslate
fill 472 241 297 472 241 300 minecraft:deepslate_tiles
setblock 472 241 301 minecraft:cobbled_deepslate
fill 472 241 302 472 241 305 minecraft:deepslate_tiles
setblock 472 241 306 minecraft:cobbled_deepslate
fill 472 241 307 472 241 310 minecraft:deepslate_tiles
setblock 472 241 311 minecraft:cobbled_deepslate
fill 472 241 312 472 242 312 minecraft:deepslate_tiles
setblock 472 241 315 minecraft:deepslate_tiles
setblock 472 241 316 minecraft:cobbled_deepslate
fill 473 241 276 473 244 276 minecraft:deepslate_tiles
setblock 473 241 278 minecraft:light[level=12]
setblock 473 241 285 minecraft:light[level=12]
setblock 473 241 292 minecraft:light[level=12]
setblock 473 241 296 minecraft:deepslate_tiles
setblock 473 241 300 minecraft:cobbled_deepslate
fill 473 241 301 473 241 304 minecraft:deepslate_tiles
setblock 473 241 305 minecraft:cobbled_deepslate
fill 473 241 306 473 244 306 minecraft:deepslate_tiles
setblock 473 241 313 minecraft:light[level=12]
setblock 473 241 315 minecraft:cobbled_deepslate
fill 473 241 316 476 241 316 minecraft:deepslate_tiles
setblock 474 241 299 minecraft:cobbled_deepslate
fill 474 241 300 474 242 300 minecraft:deepslate_tiles
setblock 474 241 303 minecraft:deepslate_tiles
setblock 474 241 304 minecraft:cobbled_deepslate
setblock 474 241 315 minecraft:deepslate_tiles
setblock 477 241 276 minecraft:cobbled_deepslate
setblock 477 241 316 minecraft:cobbled_deepslate
setblock 478 241 276 minecraft:deepslate_tiles
setblock 480 241 278 minecraft:light[level=12]
setblock 480 241 285 minecraft:light[level=12]
setblock 480 241 292 minecraft:light[level=12]
setblock 480 241 299 minecraft:light[level=12]
setblock 480 241 306 minecraft:light[level=12]
setblock 480 241 313 minecraft:light[level=12]
setblock 486 241 275 minecraft:white_wool
setblock 486 241 276 minecraft:deepslate_tiles
fill 487 241 275 489 247 275 minecraft:deepslate_tiles
setblock 487 241 276 minecraft:cobbled_deepslate
setblock 487 241 278 minecraft:light[level=12]
setblock 487 241 285 minecraft:light[level=12]
setblock 487 241 292 minecraft:light[level=12]
setblock 487 241 299 minecraft:light[level=12]
setblock 487 241 306 minecraft:light[level=12]
setblock 487 241 313 minecraft:light[level=12]
fill 488 241 276 490 241 277 minecraft:deepslate_tiles
setblock 489 241 278 minecraft:deepslate_tiles
setblock 490 241 278 minecraft:cobbled_deepslate
setblock 491 241 276 minecraft:deepslate_tiles
setblock 491 241 277 minecraft:cobbled_deepslate
fill 491 241 278 491 244 278 minecraft:deepslate_tiles
setblock 491 241 316 minecraft:deepslate_tiles
setblock 492 241 276 minecraft:cobbled_deepslate
fill 492 241 277 495 241 277 minecraft:deepslate_tiles
setblock 492 241 316 minecraft:cobbled_deepslate
fill 493 241 276 496 241 276 minecraft:deepslate_tiles
setblock 493 241 279 minecraft:deepslate_tiles
fill 493 241 316 496 241 316 minecraft:deepslate_tiles
setblock 494 241 279 minecraft:cobbled_deepslate
setblock 494 241 285 minecraft:light[level=12]
setblock 494 241 292 minecraft:light[level=12]
setblock 494 241 299 minecraft:light[level=12]
setblock 494 241 306 minecraft:light[level=12]
setblock 494 241 313 minecraft:light[level=12]
fill 494 241 317 494 305 317 minecraft:deepslate_tiles
setblock 495 241 278 minecraft:cobbled_deepslate
fill 495 241 279 495 242 279 minecraft:deepslate_tiles
setblock 496 241 277 minecraft:cobbled_deepslate
fill 496 241 278 496 244 278 minecraft:deepslate_tiles
setblock 497 241 276 minecraft:cobbled_deepslate
fill 497 241 277 497 244 277 minecraft:deepslate_tiles
setblock 497 241 316 minecraft:cobbled_deepslate
fill 498 241 276 501 241 276 minecraft:deepslate_tiles
fill 498 241 316 499 241 316 minecraft:deepslate_tiles
setblock 500 241 278 minecraft:cobbled_deepslate
setblock 501 241 277 minecraft:cobbled_deepslate
setblock 501 241 278 minecraft:light[level=12]
setblock 501 241 285 minecraft:light[level=12]
setblock 501 241 292 minecraft:light[level=12]
setblock 501 241 299 minecraft:light[level=12]
setblock 501 241 306 minecraft:light[level=12]
setblock 501 241 313 minecraft:light[level=12]
setblock 502 241 276 minecraft:cobbled_deepslate
fill 502 241 277 502 242 277 minecraft:deepslate_tiles
fill 503 241 276 503 244 276 minecraft:deepslate_tiles
setblock 506 241 277 minecraft:cobbled_deepslate
setblock 507 241 276 minecraft:cobbled_deepslate
fill 507 241 277 507 244 277 minecraft:deepslate_tiles
setblock 507 241 316 minecraft:cobbled_deepslate
fill 508 241 275 508 244 276 minecraft:deepslate_tiles
setblock 508 241 285 minecraft:light[level=12]
setblock 508 241 292 minecraft:light[level=12]
setblock 508 241 299 minecraft:light[level=12]
setblock 508 241 306 minecraft:light[level=12]
setblock 508 241 313 minecraft:light[level=12]
fill 508 241 316 508 244 316 minecraft:deepslate_tiles
fill 509 241 275 510 308 275 minecraft:deepslate_tiles
setblock 509 241 279 minecraft:cobbled_deepslate
fill 509 241 315 509 242 315 minecraft:deepslate_tiles
setblock 510 241 278 minecraft:cobbled_deepslate
fill 510 241 279 510 244 279 minecraft:deepslate_tiles
setblock 510 241 283 minecraft:cobbled_deepslate
setblock 510 241 298 minecraft:cobbled_deepslate
fill 510 241 299 510 244 299 minecraft:deepslate_tiles
fill 510 241 301 510 241 302 minecraft:deepslate_tiles
setblock 510 241 303 minecraft:cobbled_deepslate
fill 510 241 304 510 244 304 minecraft:deepslate_tiles
fill 510 241 306 510 242 306 minecraft:deepslate_tiles
setblock 510 241 313 minecraft:cobbled_deepslate
fill 510 241 314 510 244 314 minecraft:deepslate_tiles
setblock 511 241 275 minecraft:white_wool
setblock 511 241 277 minecraft:cobbled_deepslate
fill 511 241 278 511 244 278 minecraft:deepslate_tiles
setblock 511 241 282 minecraft:cobbled_deepslate
fill 511 241 283 511 244 283 minecraft:deepslate_tiles
setblock 511 241 297 minecraft:cobbled_deepslate
fill 511 241 298 511 244 298 minecraft:deepslate_tiles
setblock 511 241 302 minecraft:cobbled_deepslate
fill 511 241 303 511 244 303 minecraft:deepslate_tiles
setblock 511 241 307 minecraft:cobbled_deepslate
fill 511 241 308 511 244 308 minecraft:deepslate_tiles
setblock 511 241 312 minecraft:cobbled_deepslate
fill 511 241 313 511 244 313 minecraft:deepslate_tiles
fill 512 241 275 512 308 275 minecraft:deepslate_tiles
fill 512 241 290 512 276 290 minecraft:deepslate_tiles
setblock 470 242 281 minecraft:white_wool
fill 470 242 292 470 274 296 minecraft:deepslate_tiles
setblock 471 242 276 minecraft:cobbled_deepslate
fill 471 242 277 471 245 277 minecraft:deepslate_tiles
setblock 471 242 281 minecraft:cobbled_deepslate
fill 471 242 282 471 245 282 minecraft:deepslate_tiles
fill 471 242 293 471 242 295 minecraft:deepslate_tiles
setblock 471 242 296 minecraft:cobbled_deepslate
fill 471 242 297 471 242 300 minecraft:deepslate_tiles
setblock 471 242 301 minecraft:cobbled_deepslate
fill 471 242 302 471 242 305 minecraft:deepslate_tiles
setblock 471 242 306 minecraft:cobbled_deepslate
fill 471 242 307 471 242 310 minecraft:deepslate_tiles
setblock 471 242 311 minecraft:cobbled_deepslate
fill 471 242 312 471 245 312 minecraft:deepslate_tiles
fill 471 242 314 471 242 315 minecraft:deepslate_tiles
setblock 471 242 316 minecraft:cobbled_deepslate
fill 472 242 276 472 245 276 minecraft:deepslate_tiles
setblock 472 242 280 minecraft:cobbled_deepslate
fill 472 242 281 472 245 281 minecraft:deepslate_tiles
setblock 472 242 295 minecraft:cobbled_deepslate
fill 472 242 296 472 242 299 minecraft:deepslate_tiles
setblock 472 242 300 minecraft:cobbled_deepslate
fill 472 242 301 472 242 304 minecraft:deepslate_tiles
setblock 472 242 305 minecraft:cobbled_deepslate
fill 472 242 306 472 242 309 minecraft:deepslate_tiles
setblock 472 242 310 minecraft:cobbled_deepslate
setblock 472 242 311 minecraft:deepslate_tiles
setblock 472 242 315 minecraft:cobbled_deepslate
fill 472 242 316 475 242 316 minecraft:deepslate_tiles
setblock 473 242 299 minecraft:cobbled_deepslate
fill 473 242 300 473 242 303 minecraft:deepslate_tiles
setblock 473 242 304 minecraft:cobbled_deepslate
fill 473 242 305 473 245 305 minecraft:deepslate_tiles
setblock 474 242 299 minecraft:deepslate_tiles
setblock 474 242 303 minecraft:cobbled_deepslate
setblock 475 242 317 minecraft:redstone_block
setblock 476 242 276 minecraft:cobbled_deepslate
fill 486 242 275 486 308 275 minecraft:deepslate_tiles
fill 487 242 276 490 242 276 minecraft:deepslate_tiles
fill 488 242 277 489 242 277 minecraft:deepslate_tiles
setblock 490 242 277 minecraft:cobbled_deepslate
fill 490 242 278 490 245 278 minecraft:deepslate_tiles
setblock 491 242 276 minecraft:cobbled_deepslate
fill 491 242 277 494 242 277 minecraft:deepslate_tiles
setblock 491 242 316 minecraft:cobbled_deepslate
fill 492 242 276 495 242 276 minecraft:deepslate_tiles
fill 492 242 316 495 242 316 minecraft:deepslate_tiles
setblock 493 242 279 minecraft:cobbled_deepslate
setblock 494 242 278 minecraft:cobbled_deepslate
setblock 494 242 279 minecraft:deepslate_tiles
setblock 495 242 277 minecraft:cobbled_deepslate
fill 495 242 278 495 245 278 minecraft:deepslate_tiles
setblock 496 242 276 minecraft:cobbled_deepslate
fill 496 242 277 496 245 277 minecraft:deepslate_tiles
setblock 496 242 316 minecraft:cobbled_deepslate
fill 497 242 276 500 242 276 minecraft:deepslate_tiles
setblock 500 242 277 minecraft:cobbled_deepslate
setblock 501 242 276 minecraft:cobbled_deepslate
setblock 501 242 277 minecraft:deepslate_tiles
fill 502 242 276 502 245 276 minecraft:deepslate_tiles
setblock 505 242 277 minecraft:cobbled_deepslate
setblock 506 242 276 minecraft:cobbled_deepslate
fill 506 242 277 506 245 277 minecraft:deepslate_tiles
setblock 506 242 316 minecraft:cobbled_deepslate
fill 507 242 276 507 245 276 minecraft:deepslate_tiles
fill 507 242 316 507 245 316 minecraft:deepslate_tiles
setblock 509 242 278 minecraft:cobbled_deepslate
setblock 509 242 279 minecraft:deepslate_tiles
setblock 510 242 277 minecraft:cobbled_deepslate
fill 510 242 278 510 245 278 minecraft:deepslate_tiles
setblock 510 242 282 minecraft:cobbled_deepslate
fill 510 242 283 510 245 283 minecraft:deepslate_tiles
setblock 510 242 301 minecraft:deepslate_tiles
setblock 510 242 302 minecraft:cobbled_deepslate
fill 510 242 303 510 245 303 minecraft:deepslate_tiles
setblock 510 242 307 minecraft:cobbled_deepslate
fill 510 242 308 510 245 308 minecraft:deepslate_tiles
fill 511 242 275 511 278 275 minecraft:deepslate_tiles
setblock 511 242 276 minecraft:cobbled_deepslate
fill 511 242 277 511 245 277 minecraft:deepslate_tiles
setblock 511 242 281 minecraft:cobbled_deepslate
fill 511 242 282 511 245 282 minecraft:deepslate_tiles
setblock 511 242 296 minecraft:cobbled_deepslate
fill 511 242 297 511 245 297 minecraft:deepslate_tiles
setblock 511 242 301 minecraft:cobbled_deepslate
fill 511 242 302 511 245 302 minecraft:deepslate_tiles
setblock 511 242 306 minecraft:cobbled_deepslate
fill 511 242 307 511 245 307 minecraft:deepslate_tiles
setblock 511 242 311 minecraft:cobbled_deepslate
fill 511 242 312 511 245 312 minecraft:deepslate_tiles
setblock 511 242 316 minecraft:cobbled_deepslate
fill 470 243 281 471 246 281 minecraft:deepslate_tiles
setblock 470 243 314 minecraft:redstone_block
fill 471 243 276 471 246 276 minecraft:deepslate_tiles
setblock 471 243 280 minecraft:cobbled_deepslate
setblock 471 243 285 minecraft:cobbled_deepslate
fill 471 243 286 471 246 286 minecraft:deepslate_tiles
fill 471 243 293 471 243 294 minecraft:deepslate_tiles
setblock 471 243 295 minecraft:cobbled_deepslate
fill 471 243 296 471 243 299 minecraft:deepslate_tiles
setblock 471 243 300 minecraft:cobbled_deepslate
fill 471 243 301 471 243 304 minecraft:deepslate_tiles
setblock 471 243 305 minecraft:cobbled_deepslate
fill 471 243 306 471 243 309 minecraft:deepslate_tiles
setblock 471 243 310 minecraft:cobbled_deepslate
fill 471 243 311 471 246 311 minecraft:deepslate_tiles
setblock 471 243 314 minecraft:deepslate_tiles
setblock 471 243 315 minecraft:cobbled_deepslate
fill 471 243 316 474 243 316 minecraft:deepslate_tiles
setblock 472 243 279 minecraft:cobbled_deepslate
fill 472 243 280 472 244 280 minecraft:deepslate_tiles
fill 472 243 295 472 243 298 minecraft:deepslate_tiles
setblock 472 243 299 minecraft:cobbled_deepslate
fill 472 243 300 472 243 303 minecraft:deepslate_tiles
setblock 472 243 304 minecraft:cobbled_deepslate
fill 472 243 305 472 243 308 minecraft:deepslate_tiles
setblock 472 243 309 minecraft:cobbled_deepslate
fill 472 243 310 472 246 310 minecraft:deepslate_tiles
setblock 473 243 298 minecraft:cobbled_deepslate
fill 473 243 299 473 243 302 minecraft:deepslate_tiles
setblock 473 243 303 minecraft:cobbled_deepslate
fill 473 243 304 473 246 304 minecraft:deepslate_tiles
setblock 474 243 302 minecraft:cobbled_deepslate
setblock 474 243 303 minecraft:deepslate_tiles
setblock 475 243 276 minecraft:cobbled_deepslate
fill 475 243 277 475 252 277 minecraft:white_wool
fill 475 243 317 475 268 317 minecraft:deepslate_tiles
fill 487 243 276 489 243 276 minecraft:deepslate_tiles
setblock 488 243 277 minecraft:deepslate_tiles
setblock 489 243 277 minecraft:cobbled_deepslate
setblock 490 243 276 minecraft:cobbled_deepslate
fill 490 243 277 493 243 277 minecraft:deepslate_tiles
fill 491 243 276 494 243 276 minecraft:deepslate_tiles
setblock 492 243 278 minecraft:deepslate_tiles
setblock 492 243 279 minecraft:cobbled_deepslate
setblock 493 243 278 minecraft:cobbled_deepslate
setblock 493 243 279 minecraft:deepslate_tiles
setblock 494 243 277 minecraft:cobbled_deepslate
fill 494 243 278 494 246 278 minecraft:deepslate_tiles
setblock 495 243 276 minecraft:cobbled_deepslate
fill 495 243 277 495 246 277 minecraft:deepslate_tiles
fill 496 243 276 499 243 276 minecraft:deepslate_tiles
setblock 499 243 277 minecraft:cobbled_deepslate
setblock 499 243 317 minecraft:redstone_block
setblock 500 243 276 minecraft:cobbled_deepslate
setblock 500 243 277 minecraft:deepslate_tiles
fill 500 243 317 501 255 317 minecraft:deepslate_tiles
fill 501 243 276 501 245 276 minecraft:deepslate_tiles
setblock 505 243 276 minecraft:cobbled_deepslate
setblock 505 243 277 minecraft:deepslate_tiles
fill 506 243 276 506 246 276 minecraft:deepslate_tiles
fill 506 243 316 506 246 316 minecraft:deepslate_tiles
setblock 509 243 277 minecraft:cobbled_deepslate
setblock 510 243 276 minecraft:cobbled_deepslate
fill 510 243 277 510 246 277 minecraft:deepslate_tiles
setblock 510 243 281 minecraft:cobbled_deepslate
fill 510 243 282 510 246 282 minecraft:deepslate_tiles
setblock 510 243 301 minecraft:cobbled_deepslate
fill 510 243 302 510 246 302 minecraft:deepslate_tiles
setblock 510 243 306 minecraft:cobbled_deepslate
fill 510 243 307 510 246 307 minecraft:deepslate_tiles
fill 510 243 309 510 244 309 minecraft:deepslate_tiles
setblock 510 243 316 minecraft:cobbled_deepslate
fill 511 243 276 511 246 276 minecraft:deepslate_tiles
setblock 511 243 280 minecraft:cobbled_deepslate
fill 511 243 281 511 246 281 minecraft:deepslate_tiles
setblock 511 243 285 minecraft:cobbled_deepslate
fill 511 243 286 511 246 286 minecraft:deepslate_tiles
fill 511 243 296 511 246 296 minecraft:deepslate_tiles
setblock 511 243 300 minecraft:cobbled_deepslate
fill 511 243 301 511 246 301 minecraft:deepslate_tiles
setblock 511 243 305 minecraft:cobbled_deepslate
fill 511 243 306 511 246 306 minecraft:deepslate_tiles
setblock 511 243 310 minecraft:cobbled_deepslate
fill 511 243 311 511 246 311 minecraft:deepslate_tiles
setblock 511 243 315 minecraft:cobbled_deepslate
fill 511 243 316 511 246 316 minecraft:deepslate_tiles
fill 470 244 314 470 268 314 minecraft:deepslate_tiles
setblock 471 244 279 minecraft:cobbled_deepslate
fill 471 244 280 471 247 280 minecraft:deepslate_tiles
setblock 471 244 284 minecraft:cobbled_deepslate
fill 471 244 285 471 247 285 minecraft:deepslate_tiles
fill 471 244 287 471 245 287 minecraft:deepslate_tiles
setblock 471 244 293 minecraft:deepslate_tiles
setblock 471 244 294 minecraft:cobbled_deepslate
fill 471 244 295 471 244 298 minecraft:deepslate_tiles
setblock 471 244 299 minecraft:cobbled_deepslate
fill 471 244 300 471 244 303 minecraft:deepslate_tiles
setblock 471 244 304 minecraft:cobbled_deepslate
fill 471 244 305 471 244 308 minecraft:deepslate_tiles
setblock 471 244 309 minecraft:cobbled_deepslate
fill 471 244 310 471 247 310 minecraft:deepslate_tiles
setblock 471 244 314 minecraft:cobbled_deepslate
fill 471 244 315 471 246 316 minecraft:deepslate_tiles
fill 472 244 296 472 244 297 minecraft:deepslate_tiles
setblock 472 244 298 minecraft:cobbled_deepslate
fill 472 244 299 472 244 302 minecraft:deepslate_tiles
setblock 472 244 303 minecraft:cobbled_deepslate
fill 472 244 304 472 244 307 minecraft:deepslate_tiles
setblock 472 244 308 minecraft:cobbled_deepslate
fill 472 244 309 472 247 309 minecraft:deepslate_tiles
fill 472 244 316 473 244 316 minecraft:deepslate_tiles
fill 473 244 298 473 244 301 minecraft:deepslate_tiles
setblock 473 244 302 minecraft:cobbled_deepslate
fill 473 244 303 473 247 303 minecraft:deepslate_tiles
setblock 473 244 307 minecraft:cobbled_deepslate
fill 487 244 276 488 244 276 minecraft:deepslate_tiles
setblock 488 244 277 minecraft:cobbled_deepslate
setblock 489 244 276 minecraft:cobbled_deepslate
fill 489 244 277 489 246 278 minecraft:deepslate_tiles
fill 490 244 276 492 244 277 minecraft:deepslate_tiles
setblock 492 244 278 minecraft:cobbled_deepslate
setblock 493 244 276 minecraft:deepslate_tiles
setblock 493 244 277 minecraft:cobbled_deepslate
fill 493 244 278 493 247 278 minecraft:deepslate_tiles
setblock 494 244 276 minecraft:cobbled_deepslate
fill 494 244 277 494 247 277 minecraft:deepslate_tiles
fill 495 244 276 498 244 276 minecraft:deepslate_tiles
setblock 498 244 277 minecraft:cobbled_deepslate
setblock 499 244 276 minecraft:cobbled_deepslate
fill 499 244 317 499 308 317 minecraft:deepslate_tiles
fill 500 244 276 500 245 276 minecraft:deepslate_tiles
setblock 504 244 276 minecraft:cobbled_deepslate
fill 505 244 276 505 247 276 minecraft:deepslate_tiles
setblock 508 244 277 minecraft:cobbled_deepslate
setblock 509 244 276 minecraft:cobbled_deepslate
fill 509 244 277 509 247 277 minecraft:deepslate_tiles
setblock 509 244 316 minecraft:cobbled_deepslate
fill 510 244 276 510 247 276 minecraft:deepslate_tiles
setblock 510 244 280 minecraft:cobbled_deepslate
fill 510 244 281 510 247 281 minecraft:deepslate_tiles
setblock 510 244 300 minecraft:cobbled_deepslate
fill 510 244 301 510 247 301 minecraft:deepslate_tiles
setblock 510 244 305 minecraft:cobbled_deepslate
fill 510 244 306 510 247 306 minecraft:deepslate_tiles
setblock 510 244 310 minecraft:cobbled_deepslate
fill 510 244 311 510 246 312 minecraft:deepslate_tiles
setblock 510 244 315 minecraft:cobbled_deepslate
fill 510 244 316 510 247 316 minecraft:deepslate_tiles
setblock 511 244 279 minecraft:cobbled_deepslate
fill 511 244 280 511 247 280 minecraft:deepslate_tiles
setblock 511 244 284 minecraft:cobbled_deepslate
fill 511 244 285 511 247 285 minecraft:deepslate_tiles
setblock 511 244 299 minecraft:cobbled_deepslate
fill 511 244 300 511 247 300 minecraft:deepslate_tiles
setblock 511 244 304 minecraft:cobbled_deepslate
fill 511 244 305 511 247 305 minecraft:deepslate_tiles
setblock 511 244 309 minecraft:cobbled_deepslate
fill 511 244 310 511 247 310 minecraft:deepslate_tiles
setblock 511 244 314 minecraft:cobbled_deepslate
fill 511 244 315 511 247 315 minecraft:deepslate_tiles
setblock 471 245 278 minecraft:cobbled_deepslate
fill 471 245 279 471 248 279 minecraft:deepslate_tiles
setblock 471 245 283 minecraft:cobbled_deepslate
fill 471 245 284 471 248 284 minecraft:deepslate_tiles
setblock 471 245 288 minecraft:cobbled_deepslate
fill 471 245 289 471 248 289 minecraft:deepslate_tiles
setblock 471 245 292 minecraft:deepslate_tiles
setblock 471 245 293 minecraft:cobbled_deepslate
fill 471 245 294 471 245 297 minecraft:deepslate_tiles
setblock 471 245 298 minecraft:cobbled_deepslate
fill 471 245 299 471 245 302 minecraft:deepslate_tiles
setblock 471 245 303 minecraft:cobbled_deepslate
fill 471 245 304 471 245 307 minecraft:deepslate_tiles
setblock 471 245 308 minecraft:cobbled_deepslate
fill 471 245 309 471 248 309 minecraft:deepslate_tiles
setblock 471 245 313 minecraft:cobbled_deepslate
fill 471 245 314 471 248 314 minecraft:deepslate_tiles
setblock 472 245 282 minecraft:cobbled_deepslate
fill 472 245 283 472 248 283 minecraft:deepslate_tiles
setblock 472 245 296 minecraft:deepslate_tiles
setblock 472 245 297 minecraft:cobbled_deepslate
fill 472 245 298 472 245 301 minecraft:deepslate_tiles
setblock 472 245 302 minecraft:cobbled_deepslate
fill 472 245 303 472 245 306 minecraft:deepslate_tiles
setblock 472 245 307 minecraft:cobbled_deepslate
fill 472 245 308 472 248 308 minecraft:deepslate_tiles
setblock 472 245 316 minecraft:deepslate_tiles
setblock 473 245 278 minecraft:light[level=13]
setblock 473 245 286 minecraft:light[level=13]
setblock 473 245 294 minecraft:light[level=13]
fill 473 245 299 473 245 300 minecraft:deepslate_tiles
setblock 473 245 301 minecraft:cobbled_deepslate
fill 473 245 302 473 248 302 minecraft:deepslate_tiles
setblock 473 245 306 minecraft:cobbled_deepslate
fill 473 245 307 473 248 307 minecraft:deepslate_tiles
setblock 473 245 310 minecraft:light[level=13]
fill 476 245 317 476 308 317 minecraft:deepslate_tiles
setblock 477 245 317 minecraft:redstone_block
fill 478 245 317 479 261 317 minecraft:deepslate_tiles
setblock 481 245 278 minecraft:light[level=13]
setblock 481 245 286 minecraft:light[level=13]
setblock 481 245 294 minecraft:light[level=13]
setblock 481 245 302 minecraft:light[level=13]
setblock 481 245 310 minecraft:light[level=13]
setblock 487 245 276 minecraft:deepslate_tiles
setblock 488 245 276 minecraft:cobbled_deepslate
fill 488 245 277 488 248 277 minecraft:deepslate_tiles
fill 489 245 276 492 245 276 minecraft:deepslate_tiles
setblock 489 245 286 minecraft:light[level=13]
setblock 489 245 294 minecraft:light[level=13]
setblock 489 245 302 minecraft:light[level=13]
setblock 489 245 310 minecraft:light[level=13]
fill 490 245 277 491 245 277 minecraft:deepslate_tiles
setblock 491 245 278 minecraft:cobbled_deepslate
setblock 492 245 277 minecraft:cobbled_deepslate
fill 492 245 278 492 248 278 minecraft:deepslate_tiles
setblock 493 245 276 minecraft:cobbled_deepslate
fill 493 245 277 493 248 277 minecraft:deepslate_tiles
fill 494 245 276 497 245 276 minecraft:deepslate_tiles
setblock 497 245 277 minecraft:cobbled_deepslate
setblock 497 245 278 minecraft:light[level=13]
setblock 497 245 286 minecraft:light[level=13]
setblock 497 245 294 minecraft:light[level=13]
setblock 497 245 302 minecraft:light[level=13]
setblock 497 245 310 minecraft:light[level=13]
setblock 498 245 276 minecraft:cobbled_deepslate
fill 499 245 276 499 246 276 minecraft:deepslate_tiles
setblock 503 245 276 minecraft:cobbled_deepslate
fill 504 245 276 504 248 276 minecraft:deepslate_tiles
setblock 505 245 278 minecraft:light[level=13]
setblock 505 245 286 minecraft:light[level=13]
setblock 505 245 294 minecraft:light[level=13]
setblock 505 245 302 minecraft:light[level=13]
setblock 505 245 310 minecraft:light[level=13]
setblock 507 245 277 minecraft:cobbled_deepslate
fill 508 245 275 508 308 275 minecraft:deepslate_tiles
setblock 508 245 276 minecraft:cobbled_deepslate
fill 508 245 277 508 248 277 minecraft:deepslate_tiles
setblock 508 245 316 minecraft:cobbled_deepslate
fill 509 245 276 509 248 276 minecraft:deepslate_tiles
fill 509 245 303 509 245 304 minecraft:deepslate_tiles
setblock 509 245 305 minecraft:cobbled_deepslate
fill 509 245 306 509 248 306 minecraft:deepslate_tiles
setblock 509 245 315 minecraft:cobbled_deepslate
fill 509 245 316 509 248 316 minecraft:deepslate_tiles
setblock 510 245 279 minecraft:cobbled_deepslate
fill 510 245 280 510 248 280 minecraft:deepslate_tiles
setblock 510 245 284 minecraft:cobbled_deepslate
setblock 510 245 299 minecraft:cobbled_deepslate
fill 510 245 300 510 248 300 minecraft:deepslate_tiles
setblock 510 245 304 minecraft:cobbled_deepslate
fill 510 245 305 510 248 305 minecraft:deepslate_tiles
setblock 510 245 309 minecraft:cobbled_deepslate
fill 510 245 310 510 248 310 minecraft:deepslate_tiles
setblock 510 245 313 minecraft:deepslate_tiles
setblock 510 245 314 minecraft:cobbled_deepslate
fill 510 245 315 510 248 315 minecraft:deepslate_tiles
setblock 511 245 278 minecraft:cobbled_deepslate
fill 511 245 279 511 248 279 minecraft:deepslate_tiles
setblock 511 245 283 minecraft:cobbled_deepslate
fill 511 245 284 511 248 284 minecraft:deepslate_tiles
setblock 511 245 287 minecraft:deepslate_tiles
setblock 511 245 298 minecraft:cobbled_deepslate
fill 511 245 299 511 248 299 minecraft:deepslate_tiles
setblock 511 245 303 minecraft:cobbled_deepslate
fill 511 245 304 511 248 304 minecraft:deepslate_tiles
setblock 511 245 308 minecraft:cobbled_deepslate
fill 511 245 309 511 248 309 minecraft:deepslate_tiles
setblock 511 245 313 minecraft:cobbled_deepslate
fill 511 245 314 511 248 314 minecraft:deepslate_tiles
setblock 471 246 277 minecraft:cobbled_deepslate
fill 471 246 278 471 249 278 minecraft:deepslate_tiles
setblock 471 246 282 minecraft:cobbled_deepslate
fill 471 246 283 471 249 283 minecraft:deepslate_tiles
setblock 471 246 287 minecraft:cobbled_deepslate
fill 471 246 288 471 249 288 minecraft:deepslate_tiles
fill 471 246 290 471 246 291 minecraft:deepslate_tiles
setblock 471 246 292 minecraft:cobbled_deepslate
fill 471 246 293 471 246 296 minecraft:deepslate_tiles
setblock 471 246 297 minecraft:cobbled_deepslate
fill 471 246 298 471 246 301 minecraft:deepslate_tiles
setblock 471 246 302 minecraft:cobbled_deepslate
fill 471 246 303 471 246 306 minecraft:deepslate_tiles
setblock 471 246 307 minecraft:cobbled_deepslate
fill 471 246 308 471 249 308 minecraft:deepslate_tiles
setblock 471 246 312 minecraft:cobbled_deepslate
fill 471 246 313 471 249 313 minecraft:deepslate_tiles
setblock 472 246 281 minecraft:cobbled_deepslate
fill 472 246 282 472 249 282 minecraft:deepslate_tiles
fill 472 246 284 472 246 285 minecraft:deepslate_tiles
setblock 472 246 296 minecraft:cobbled_deepslate
fill 472 246 297 472 246 300 minecraft:deepslate_tiles
setblock 472 246 301 minecraft:cobbled_deepslate
fill 472 246 302 472 246 305 minecraft:deepslate_tiles
setblock 472 246 306 minecraft:cobbled_deepslate
fill 472 246 307 472 249 307 minecraft:deepslate_tiles
setblock 472 246 311 minecraft:cobbled_deepslate
setblock 473 246 299 minecraft:deepslate_tiles
setblock 473 246 300 minecraft:cobbled_deepslate
fill 473 246 301 473 249 301 minecraft:deepslate_tiles
setblock 473 246 305 minecraft:cobbled_deepslate
fill 473 246 306 473 249 306 minecraft:deepslate_tiles
fill 473 246 308 473 247 308 minecraft:deepslate_tiles
fill 477 246 317 477 308 317 minecraft:deepslate_tiles
setblock 486 246 276 minecraft:deepslate_tiles
setblock 487 246 276 minecraft:cobbled_deepslate
fill 487 246 277 487 249 277 minecraft:deepslate_tiles
fill 488 246 276 491 246 276 minecraft:deepslate_tiles
setblock 490 246 277 minecraft:deepslate_tiles
setblock 490 246 278 minecraft:cobbled_deepslate
setblock 491 246 277 minecraft:cobbled_deepslate
fill 491 246 278 491 249 278 minecraft:deepslate_tiles
fill 491 246 317 491 295 317 minecraft:deepslate_tiles
setblock 492 246 276 minecraft:cobbled_deepslate
fill 492 246 277 492 249 277 minecraft:deepslate_tiles
setblock 492 246 317 minecraft:white_wool
fill 493 246 276 496 246 276 minecraft:deepslate_tiles
setblock 496 246 277 minecraft:cobbled_deepslate
setblock 497 246 276 minecraft:cobbled_deepslate
fill 498 246 276 498 249 276 minecraft:deepslate_tiles
setblock 502 246 276 minecraft:cobbled_deepslate
fill 503 246 276 503 249 276 minecraft:deepslate_tiles
fill 505 246 316 505 247 316 minecraft:deepslate_tiles
setblock 506 246 277 minecraft:cobbled_deepslate
setblock 507 246 276 minecraft:cobbled_deepslate
fill 507 246 277 507 249 277 minecraft:deepslate_tiles
setblock 507 246 316 minecraft:cobbled_deepslate
fill 508 246 276 508 249 276 minecraft:deepslate_tiles
setblock 508 246 315 minecraft:cobbled_deepslate
fill 508 246 316 508 249 316 minecraft:deepslate_tiles
fill 509 246 302 509 246 303 minecraft:deepslate_tiles
setblock 509 246 304 minecraft:cobbled_deepslate
fill 509 246 305 509 249 305 minecraft:deepslate_tiles
fill 509 246 307 509 246 308 minecraft:deepslate_tiles
setblock 509 246 309 minecraft:cobbled_deepslate
fill 509 246 315 509 249 315 minecraft:deepslate_tiles
setblock 510 246 278 minecraft:cobbled_deepslate
fill 510 246 279 510 249 279 minecraft:deepslate_tiles
setblock 510 246 283 minecraft:cobbled_deepslate
fill 510 246 284 510 248 285 minecraft:deepslate_tiles
fill 510 246 299 510 249 299 minecraft:deepslate_tiles
setblock 510 246 303 minecraft:cobbled_deepslate
fill 510 246 304 510 249 304 minecraft:deepslate_tiles
setblock 510 246 308 minecraft:cobbled_deepslate
fill 510 246 309 510 249 309 minecraft:deepslate_tiles
setblock 510 246 313 minecraft:cobbled_deepslate
fill 510 246 314 510 249 314 minecraft:deepslate_tiles
setblock 511 246 277 minecraft:cobbled_deepslate
fill 511 246 278 511 249 278 minecraft:deepslate_tiles
setblock 511 246 282 minecraft:cobbled_deepslate
fill 511 246 283 511 249 283 minecraft:deepslate_tiles
setblock 511 246 287 minecraft:cobbled_deepslate
fill 511 246 288 511 249 288 minecraft:deepslate_tiles
setblock 511 246 297 minecraft:cobbled_deepslate
fill 511 246 298 511 249 298 minecraft:deepslate_tiles
setblock 511 246 302 minecraft:cobbled_deepslate
fill 511 246 303 511 249 303 minecraft:deepslate_tiles
setblock 511 246 307 minecraft:cobbled_deepslate
fill 511 246 308 511 249 308 minecraft:deepslate_tiles
setblock 511 246 312 minecraft:cobbled_deepslate
fill 511 246 313 511 249 313 minecraft:deepslate_tiles
fill 512 246 302 512 298 302 minecraft:deepslate_tiles
setblock 512 246 303 minecraft:redstone_block
fill 470 247 281 470 308 281 minecraft:deepslate_tiles
fill 471 247 277 471 248 277 minecraft:deepslate_tiles
setblock 471 247 281 minecraft:cobbled_deepslate
fill 471 247 282 471 250 282 minecraft:deepslate_tiles
setblock 471 247 286 minecraft:cobbled_deepslate
fill 471 247 287 472 249 287 minecraft:deepslate_tiles
setblock 471 247 290 minecraft:deepslate_tiles
setblock 471 247 291 minecraft:cobbled_deepslate
fill 471 247 292 471 247 295 minecraft:deepslate_tiles
setblock 471 247 296 minecraft:cobbled_deepslate
fill 471 247 297 471 247 300 minecraft:deepslate_tiles
setblock 471 247 301 minecraft:cobbled_deepslate
fill 471 247 302 471 247 305 minecraft:deepslate_tiles
setblock 471 247 306 minecraft:cobbled_deepslate
fill 471 247 307 471 250 307 minecraft:deepslate_tiles
setblock 471 247 311 minecraft:cobbled_deepslate
fill 471 247 312 471 250 312 minecraft:deepslate_tiles
setblock 471 247 315 minecraft:deepslate_tiles
setblock 471 247 316 minecraft:cobbled_deepslate
fill 472 247 281 472 249 281 minecraft:deepslate_tiles
setblock 472 247 284 minecraft:deepslate_tiles
setblock 472 247 285 minecraft:cobbled_deepslate
fill 472 247 286 472 250 286 minecraft:deepslate_tiles
fill 472 247 296 472 247 299 minecraft:deepslate_tiles
setblock 472 247 300 minecraft:cobbled_deepslate
fill 472 247 301 472 247 304 minecraft:deepslate_tiles
setblock 472 247 305 minecraft:cobbled_deepslate
fill 472 247 306 472 250 306 minecraft:deepslate_tiles
setblock 472 247 310 minecraft:cobbled_deepslate
fill 472 247 311 472 250 311 minecraft:deepslate_tiles
setblock 473 247 278 minecraft:light[level=12]
setblock 473 247 285 minecraft:light[level=12]
setblock 473 247 292 minecraft:light[level=12]
setblock 473 247 299 minecraft:light[level=12]
fill 473 247 300 473 248 300 minecraft:deepslate_tiles
setblock 473 247 304 minecraft:cobbled_deepslate
fill 473 247 305 473 250 305 minecraft:deepslate_tiles
setblock 473 247 313 minecraft:light[level=12]
setblock 474 247 317 minecraft:white_wool
setblock 480 247 278 minecraft:light[level=12]
setblock 480 247 285 minecraft:light[level=12]
setblock 480 247 292 minecraft:light[level=12]
setblock 480 247 299 minecraft:light[level=12]
setblock 480 247 306 minecraft:light[level=12]
setblock 480 247 313 minecraft:light[level=12]
fill 481 247 303 482 248 303 minecraft:white_wool
setblock 486 247 276 minecraft:cobbled_deepslate
fill 487 247 276 490 247 276 minecraft:deepslate_tiles
setblock 487 247 278 minecraft:light[level=12]
setblock 487 247 285 minecraft:light[level=12]
setblock 487 247 292 minecraft:light[level=12]
setblock 487 247 299 minecraft:light[level=12]
setblock 487 247 306 minecraft:light[level=12]
setblock 487 247 313 minecraft:light[level=12]
setblock 488 247 278 minecraft:deepslate_tiles
setblock 489 247 277 minecraft:deepslate_tiles
setblock 489 247 278 minecraft:cobbled_deepslate
fill 489 247 310 489 250 311 minecraft:white_terracotta
setblock 490 247 277 minecraft:cobbled_deepslate
fill 490 247 278 490 250 278 minecraft:deepslate_tiles
fill 490 247 311 490 250 311 minecraft:white_terracotta
setblock 491 247 276 minecraft:cobbled_deepslate
fill 491 247 277 491 250 277 minecraft:deepslate_tiles
fill 492 247 276 495 247 276 minecraft:deepslate_tiles
fill 492 247 317 492 308 317 minecraft:deepslate_tiles
setblock 494 247 278 minecraft:light[level=12]
setblock 494 247 285 minecraft:light[level=12]
setblock 494 247 292 minecraft:light[level=12]
setblock 494 247 299 minecraft:light[level=12]
setblock 494 247 306 minecraft:light[level=12]
setblock 494 247 313 minecraft:light[level=12]
setblock 495 247 277 minecraft:cobbled_deepslate
setblock 496 247 276 minecraft:cobbled_deepslate
fill 497 247 276 497 250 276 minecraft:deepslate_tiles
setblock 501 247 278 minecraft:light[level=12]
setblock 501 247 285 minecraft:light[level=12]
setblock 501 247 292 minecraft:light[level=12]
setblock 501 247 299 minecraft:light[level=12]
setblock 501 247 306 minecraft:light[level=12]
setblock 501 247 313 minecraft:light[level=12]
fill 502 247 276 502 250 276 minecraft:deepslate_tiles
fill 504 247 316 504 248 316 minecraft:deepslate_tiles
setblock 506 247 276 minecraft:cobbled_deepslate
fill 506 247 277 506 250 277 minecraft:deepslate_tiles
setblock 506 247 316 minecraft:cobbled_deepslate
fill 507 247 276 507 250 276 minecraft:deepslate_tiles
setblock 507 247 315 minecraft:cobbled_deepslate
fill 507 247 316 507 250 316 minecraft:deepslate_tiles
setblock 508 247 278 minecraft:light[level=12]
setblock 508 247 285 minecraft:light[level=12]
setblock 508 247 292 minecraft:light[level=12]
setblock 508 247 299 minecraft:light[level=12]
setblock 508 247 306 minecraft:light[level=12]
setblock 508 247 313 minecraft:light[level=12]
fill 508 247 315 508 250 315 minecraft:deepslate_tiles
setblock 509 247 302 minecraft:deepslate_tiles
setblock 509 247 303 minecraft:cobbled_deepslate
fill 509 247 304 509 250 304 minecraft:deepslate_tiles
setblock 509 247 307 minecraft:deepslate_tiles
setblock 509 247 308 minecraft:cobbled_deepslate
fill 509 247 309 509 248 311 minecraft:deepslate_tiles
setblock 510 247 277 minecraft:cobbled_deepslate
fill 510 247 278 510 249 278 minecraft:deepslate_tiles
setblock 510 247 282 minecraft:cobbled_deepslate
fill 510 247 283 510 250 283 minecraft:deepslate_tiles
setblock 510 247 286 minecraft:deepslate_tiles
setblock 510 247 302 minecraft:cobbled_deepslate
fill 510 247 303 510 250 303 minecraft:deepslate_tiles
setblock 510 247 307 minecraft:cobbled_deepslate
fill 510 247 308 510 250 308 minecraft:deepslate_tiles
setblock 510 247 311 minecraft:deepslate_tiles
setblock 510 247 312 minecraft:cobbled_deepslate
fill 510 247 313 510 250 313 minecraft:deepslate_tiles
setblock 511 247 276 minecraft:cobbled_deepslate
fill 511 247 277 511 250 277 minecraft:deepslate_tiles
setblock 511 247 281 minecraft:cobbled_deepslate
fill 511 247 282 511 250 282 minecraft:deepslate_tiles
setblock 511 247 286 minecraft:cobbled_deepslate
fill 511 247 287 511 250 287 minecraft:deepslate_tiles
fill 511 247 289 511 248 289 minecraft:deepslate_tiles
setblock 511 247 296 minecraft:cobbled_deepslate
fill 511 247 297 511 250 297 minecraft:deepslate_tiles
setblock 511 247 301 minecraft:cobbled_deepslate
fill 511 247 302 511 250 302 minecraft:deepslate_tiles
setblock 511 247 306 minecraft:cobbled_deepslate
fill 511 247 307 512 250 307 minecraft:deepslate_tiles
setblock 511 247 311 minecraft:cobbled_deepslate
fill 511 247 312 511 250 312 minecraft:deepslate_tiles
setblock 511 247 316 minecraft:cobbled_deepslate
setblock 512 247 303 minecraft:deepslate_tiles
setblock 512 247 305 minecraft:redstone_block
fill 512 247 306 512 308 306 minecraft:deepslate_tiles
fill 512 247 308 512 282 311 minecraft:deepslate_tiles
setblock 471 248 280 minecraft:cobbled_deepslate
fill 471 248 281 471 251 281 minecraft:deepslate_tiles
setblock 471 248 285 minecraft:cobbled_deepslate
fill 471 248 286 471 251 286 minecraft:deepslate_tiles
setblock 471 248 290 minecraft:cobbled_deepslate
fill 471 248 291 471 248 294 minecraft:deepslate_tiles
setblock 471 248 295 minecraft:cobbled_deepslate
fill 471 248 296 471 248 299 minecraft:deepslate_tiles
setblock 471 248 300 minecraft:cobbled_deepslate
fill 471 248 301 471 248 304 minecraft:deepslate_tiles
setblock 471 248 305 minecraft:cobbled_deepslate
fill 471 248 306 471 251 306 minecraft:deepslate_tiles
setblock 471 248 310 minecraft:cobbled_deepslate
fill 471 248 311 471 251 311 minecraft:deepslate_tiles
setblock 471 248 315 minecraft:cobbled_deepslate
fill 471 248 316 471 251 316 minecraft:deepslate_tiles
setblock 472 248 284 minecraft:cobbled_deepslate
fill 472 248 285 472 251 285 minecraft:deepslate_tiles
setblock 472 248 288 minecraft:deepslate_tiles
setblock 472 248 289 minecraft:cobbled_deepslate
fill 472 248 290 472 251 290 minecraft:deepslate_tiles
fill 472 248 296 472 248 298 minecraft:deepslate_tiles
setblock 472 248 299 minecraft:cobbled_deepslate
fill 472 248 300 472 248 303 minecraft:deepslate_tiles
setblock 472 248 304 minecraft:cobbled_deepslate
fill 472 248 305 472 251 305 minecraft:deepslate_tiles
setblock 472 248 309 minecraft:cobbled_deepslate
fill 472 248 310 472 251 310 minecraft:deepslate_tiles
fill 472 248 312 472 249 312 minecraft:deepslate_tiles
setblock 473 248 303 minecraft:cobbled_deepslate
fill 473 248 304 473 251 304 minecraft:deepslate_tiles
setblock 473 248 308 minecraft:cobbled_deepslate
fill 473 248 309 473 251 309 minecraft:deepslate_tiles
fill 474 248 317 474 302 317 minecraft:deepslate_tiles
setblock 485 248 276 minecraft:cobbled_deepslate
fill 486 248 276 486 250 277 minecraft:deepslate_tiles
fill 487 248 275 488 249 276 minecraft:deepslate_tiles
setblock 488 248 278 minecraft:cobbled_deepslate
fill 488 248 311 488 249 311 minecraft:white_terracotta
setblock 489 248 275 minecraft:redstone_block
setblock 489 248 276 minecraft:deepslate_tiles
setblock 489 248 277 minecraft:cobbled_deepslate
fill 489 248 278 489 251 278 minecraft:deepslate_tiles
fill 489 248 312 489 249 312 minecraft:white_terracotta
setblock 489 248 316 minecraft:deepslate_tiles
setblock 490 248 276 minecraft:cobbled_deepslate
fill 490 248 277 490 251 277 minecraft:deepslate_tiles
fill 490 248 310 490 249 310 minecraft:white_terracotta
setblock 490 248 316 minecraft:cobbled_deepslate
fill 491 248 276 494 248 276 minecraft:deepslate_tiles
fill 491 248 316 492 250 316 minecraft:deepslate_tiles
setblock 493 248 278 minecraft:cobbled_deepslate
setblock 494 248 277 minecraft:cobbled_deepslate
setblock 495 248 276 minecraft:cobbled_deepslate
setblock 495 248 277 minecraft:deepslate_tiles
fill 496 248 276 496 251 276 minecraft:deepslate_tiles
fill 501 248 276 501 251 276 minecraft:deepslate_tiles
fill 503 248 316 503 249 316 minecraft:deepslate_tiles
setblock 505 248 276 minecraft:cobbled_deepslate
setblock 505 248 316 minecraft:cobbled_deepslate
fill 506 248 276 506 251 276 minecraft:deepslate_tiles
setblock 506 248 315 minecraft:cobbled_deepslate
fill 506 248 316 506 251 316 minecraft:deepslate_tiles
fill 507 248 315 507 251 315 minecraft:deepslate_tiles
fill 508 248 305 508 248 307 minecraft:deepslate_tiles
setblock 508 248 308 minecraft:cobbled_deepslate
fill 508 248 309 508 251 309 minecraft:deepslate_tiles
setblock 509 248 277 minecraft:cobbled_deepslate
setblock 509 248 282 minecraft:cobbled_deepslate
fill 509 248 283 509 250 283 minecraft:deepslate_tiles
setblock 509 248 301 minecraft:deepslate_tiles
setblock 509 248 302 minecraft:cobbled_deepslate
fill 509 248 303 509 251 303 minecraft:deepslate_tiles
setblock 509 248 307 minecraft:cobbled_deepslate
fill 509 248 308 509 251 308 minecraft:deepslate_tiles
setblock 509 248 312 minecraft:cobbled_deepslate
fill 509 248 313 509 251 313 minecraft:deepslate_tiles
setblock 510 248 276 minecraft:cobbled_deepslate
fill 510 248 277 510 249 277 minecraft:deepslate_tiles
setblock 510 248 281 minecraft:cobbled_deepslate
fill 510 248 282 510 251 282 minecraft:deepslate_tiles
setblock 510 248 286 minecraft:cobbled_deepslate
fill 510 248 287 510 251 287 minecraft:deepslate_tiles
setblock 510 248 301 minecraft:cobbled_deepslate
fill 510 248 302 510 251 302 minecraft:deepslate_tiles
setblock 510 248 306 minecraft:cobbled_deepslate
fill 510 248 307 510 251 307 minecraft:deepslate_tiles
setblock 510 248 311 minecraft:cobbled_deepslate
fill 510 248 312 510 251 312 minecraft:deepslate_tiles
setblock 510 248 316 minecraft:cobbled_deepslate
fill 511 248 276 511 251 276 minecraft:deepslate_tiles
setblock 511 248 280 minecraft:cobbled_deepslate
fill 511 248 281 511 251 281 minecraft:deepslate_tiles
setblock 511 248 285 minecraft:cobbled_deepslate
fill 511 248 286 511 251 286 minecraft:deepslate_tiles
setblock 511 248 290 minecraft:cobbled_deepslate
fill 511 248 291 511 251 291 minecraft:deepslate_tiles
setblock 511 248 295 minecraft:cobbled_deepslate
fill 511 248 296 511 251 296 minecraft:deepslate_tiles
setblock 511 248 300 minecraft:cobbled_deepslate
fill 511 248 301 511 251 301 minecraft:deepslate_tiles
setblock 511 248 305 minecraft:cobbled_deepslate
fill 511 248 306 511 251 306 minecraft:deepslate_tiles
setblock 511 248 310 minecraft:cobbled_deepslate
fill 511 248 311 511 251 311 minecraft:deepslate_tiles
setblock 511 248 315 minecraft:cobbled_deepslate
fill 511 248 316 511 251 316 minecraft:deepslate_tiles
setblock 512 248 303 minecraft:white_wool
fill 512 248 305 512 308 305 minecraft:deepslate_tiles
setblock 471 249 279 minecraft:cobbled_deepslate
fill 471 249 280 471 252 280 minecraft:deepslate_tiles
setblock 471 249 284 minecraft:cobbled_deepslate
fill 471 249 285 471 252 285 minecraft:deepslate_tiles
setblock 471 249 289 minecraft:cobbled_deepslate
fill 471 249 290 471 249 293 minecraft:deepslate_tiles
setblock 471 249 294 minecraft:cobbled_deepslate
fill 471 249 295 471 249 298 minecraft:deepslate_tiles
setblock 471 249 299 minecraft:cobbled_deepslate
fill 471 249 300 471 249 303 minecraft:deepslate_tiles
setblock 471 249 304 minecraft:cobbled_deepslate
fill 471 249 305 471 252 305 minecraft:deepslate_tiles
setblock 471 249 309 minecraft:cobbled_deepslate
fill 471 249 310 471 252 310 minecraft:deepslate_tiles
setblock 471 249 314 minecraft:cobbled_deepslate
fill 471 249 315 471 252 315 minecraft:deepslate_tiles
setblock 472 249 283 minecraft:cobbled_deepslate
fill 472 249 284 472 252 284 minecraft:deepslate_tiles
setblock 472 249 288 minecraft:cobbled_deepslate
fill 472 249 289 472 252 289 minecraft:deepslate_tiles
fill 472 249 291 472 249 292 minecraft:deepslate_tiles
setblock 472 249 293 minecraft:cobbled_deepslate
fill 472 249 294 472 249 297 minecraft:deepslate_tiles
setblock 472 249 298 minecraft:cobbled_deepslate
fill 472 249 299 472 249 302 minecraft:deepslate_tiles
setblock 472 249 303 minecraft:cobbled_deepslate
fill 472 249 304 472 252 304 minecraft:deepslate_tiles
setblock 472 249 308 minecraft:cobbled_deepslate
fill 472 249 309 472 252 309 minecraft:deepslate_tiles
setblock 473 249 302 minecraft:cobbled_deepslate
fill 473 249 303 473 251 303 minecraft:deepslate_tiles
setblock 473 249 307 minecraft:cobbled_deepslate
fill 473 249 308 473 252 308 minecraft:deepslate_tiles
setblock 484 249 276 minecraft:cobbled_deepslate
fill 485 249 276 485 252 276 minecraft:deepslate_tiles
setblock 487 249 278 minecraft:cobbled_deepslate
setblock 488 249 277 minecraft:cobbled_deepslate
fill 488 249 278 488 252 278 minecraft:deepslate_tiles
setblock 488 249 316 minecraft:deepslate_tiles
fill 489 249 275 489 285 275 minecraft:deepslate_tiles
setblock 489 249 276 minecraft:cobbled_deepslate
fill 489 249 277 489 252 277 minecraft:deepslate_tiles
setblock 489 249 316 minecraft:cobbled_deepslate
fill 490 249 276 493 249 276 minecraft:deepslate_tiles
fill 490 249 316 490 252 316 minecraft:deepslate_tiles
setblock 492 249 278 minecraft:cobbled_deepslate
setblock 493 249 277 minecraft:cobbled_deepslate
setblock 493 249 316 minecraft:deepslate_tiles
setblock 494 249 276 minecraft:cobbled_deepslate
fill 494 249 277 494 250 277 minecraft:deepslate_tiles
fill 495 249 276 495 252 276 minecraft:deepslate_tiles
setblock 499 249 276 minecraft:cobbled_deepslate
fill 500 249 276 500 252 276 minecraft:deepslate_tiles
fill 502 249 316 502 250 316 minecraft:deepslate_tiles
setblock 504 249 276 minecraft:cobbled_deepslate
setblock 504 249 315 minecraft:deepslate_tiles
setblock 504 249 316 minecraft:cobbled_deepslate
fill 505 249 276 505 251 277 minecraft:deepslate_tiles
setblock 505 249 315 minecraft:cobbled_deepslate
fill 505 249 316 505 252 316 minecraft:deepslate_tiles
fill 506 249 315 506 252 315 minecraft:deepslate_tiles
fill 507 249 314 509 250 314 minecraft:deepslate_tiles
setblock 508 249 277 minecraft:cobbled_deepslate
fill 508 249 304 508 249 306 minecraft:deepslate_tiles
setblock 508 249 307 minecraft:cobbled_deepslate
fill 508 249 308 508 252 308 minecraft:deepslate_tiles
fill 508 249 310 508 249 311 minecraft:deepslate_tiles
setblock 509 249 276 minecraft:cobbled_deepslate
fill 509 249 277 509 250 277 minecraft:deepslate_tiles
setblock 509 249 282 minecraft:deepslate_tiles
fill 509 249 284 509 249 285 minecraft:deepslate_tiles
setblock 509 249 301 minecraft:cobbled_deepslate
fill 509 249 302 509 252 302 minecraft:deepslate_tiles
setblock 509 249 306 minecraft:cobbled_deepslate
fill 509 249 307 509 252 307 minecraft:deepslate_tiles
fill 509 249 309 509 249 310 minecraft:deepslate_tiles
setblock 509 249 311 minecraft:cobbled_deepslate
fill 509 249 312 509 252 312 minecraft:deepslate_tiles
setblock 509 249 316 minecraft:cobbled_deepslate
fill 510 249 276 510 252 276 minecraft:deepslate_tiles
setblock 510 249 280 minecraft:cobbled_deepslate
fill 510 249 281 510 251 281 minecraft:deepslate_tiles
setblock 510 249 284 minecraft:deepslate_tiles
setblock 510 249 285 minecraft:cobbled_deepslate
fill 510 249 286 510 252 286 minecraft:deepslate_tiles
fill 510 249 288 510 249 289 minecraft:deepslate_tiles
fill 510 249 298 510 250 298 minecraft:deepslate_tiles
setblock 510 249 300 minecraft:cobbled_deepslate
fill 510 249 301 510 252 301 minecraft:deepslate_tiles
setblock 510 249 305 minecraft:cobbled_deepslate
fill 510 249 306 510 252 306 minecraft:deepslate_tiles
setblock 510 249 310 minecraft:cobbled_deepslate
fill 510 249 311 510 252 311 minecraft:deepslate_tiles
setblock 510 249 315 minecraft:cobbled_deepslate
fill 510 249 316 510 252 316 minecraft:deepslate_tiles
setblock 511 249 279 minecraft:cobbled_deepslate
fill 511 249 280 511 252 280 minecraft:deepslate_tiles
setblock 511 249 284 minecraft:cobbled_deepslate
fill 511 249 285 511 252 285 minecraft:deepslate_tiles
setblock 511 249 289 minecraft:cobbled_deepslate
fill 511 249 290 511 252 290 minecraft:deepslate_tiles
fill 511 249 292 511 249 293 minecraft:deepslate_tiles
setblock 511 249 294 minecraft:cobbled_deepslate
fill 511 249 295 511 252 295 minecraft:deepslate_tiles
setblock 511 249 299 minecraft:cobbled_deepslate
fill 511 249 300 511 252 300 minecraft:deepslate_tiles
setblock 511 249 304 minecraft:cobbled_deepslate
fill 511 249 305 511 252 305 minecraft:deepslate_tiles
setblock 511 249 309 minecraft:cobbled_deepslate
fill 511 249 310 511 252 310 minecraft:deepslate_tiles
setblock 511 249 314 minecraft:cobbled_deepslate
fill 511 249 315 511 252 315 minecraft:deepslate_tiles
fill 512 249 303 512 295 303 minecraft:deepslate_tiles
setblock 470 250 286 minecraft:white_wool
fill 470 250 287 471 250 287 minecraft:deepslate_tiles
setblock 471 250 278 minecraft:cobbled_deepslate
fill 471 250 279 471 251 279 minecraft:deepslate_tiles
setblock 471 250 283 minecraft:cobbled_deepslate
fill 471 250 284 471 253 284 minecraft:deepslate_tiles
setblock 471 250 288 minecraft:cobbled_deepslate
fill 471 250 289 471 250 292 minecraft:deepslate_tiles
setblock 471 250 293 minecraft:cobbled_deepslate
fill 471 250 294 471 250 297 minecraft:deepslate_tiles
setblock 471 250 298 minecraft:cobbled_deepslate
fill 471 250 299 471 250 302 minecraft:deepslate_tiles
setblock 471 250 303 minecraft:cobbled_deepslate
fill 471 250 304 471 253 304 minecraft:deepslate_tiles
setblock 471 250 308 minecraft:cobbled_deepslate
fill 471 250 309 471 253 309 minecraft:deepslate_tiles
setblock 471 250 313 minecraft:cobbled_deepslate
fill 471 250 314 471 253 314 minecraft:deepslate_tiles
setblock 472 250 282 minecraft:cobbled_deepslate
fill 472 250 283 472 252 283 minecraft:deepslate_tiles
setblock 472 250 287 minecraft:cobbled_deepslate
fill 472 250 288 472 253 288 minecraft:deepslate_tiles
setblock 472 250 291 minecraft:deepslate_tiles
setblock 472 250 292 minecraft:cobbled_deepslate
fill 472 250 293 472 250 296 minecraft:deepslate_tiles
setblock 472 250 297 minecraft:cobbled_deepslate
fill 472 250 298 472 250 301 minecraft:deepslate_tiles
setblock 472 250 302 minecraft:cobbled_deepslate
fill 472 250 303 472 253 303 minecraft:deepslate_tiles
setblock 472 250 307 minecraft:cobbled_deepslate
fill 472 250 308 472 253 308 minecraft:deepslate_tiles
setblock 472 250 312 minecraft:cobbled_deepslate
setblock 473 250 302 minecraft:deepslate_tiles
setblock 473 250 306 minecraft:cobbled_deepslate
fill 473 250 307 473 252 307 minecraft:deepslate_tiles
fill 484 250 276 484 253 276 minecraft:deepslate_tiles
fill 485 250 277 485 251 277 minecraft:deepslate_tiles
fill 486 250 316 487 250 316 minecraft:deepslate_tiles
fill 487 250 275 487 250 276 minecraft:deepslate_tiles
setblock 487 250 277 minecraft:cobbled_deepslate
fill 487 250 278 487 252 278 minecraft:deepslate_tiles
fill 488 250 275 488 282 275 minecraft:deepslate_tiles
setblock 488 250 276 minecraft:cobbled_deepslate
fill 488 250 277 488 253 277 minecraft:deepslate_tiles
setblock 488 250 316 minecraft:cobbled_deepslate
fill 489 250 276 492 250 276 minecraft:deepslate_tiles
fill 489 250 316 489 253 316 minecraft:deepslate_tiles
setblock 491 250 278 minecraft:cobbled_deepslate
setblock 492 250 277 minecraft:cobbled_deepslate
setblock 493 250 276 minecraft:cobbled_deepslate
fill 493 250 277 493 251 277 minecraft:deepslate_tiles
setblock 493 250 316 minecraft:cobbled_deepslate
fill 494 250 276 494 253 276 minecraft:deepslate_tiles
setblock 498 250 276 minecraft:cobbled_deepslate
fill 499 250 276 499 253 276 minecraft:deepslate_tiles
fill 500 250 316 501 251 316 minecraft:deepslate_tiles
setblock 503 250 276 minecraft:cobbled_deepslate
setblock 503 250 315 minecraft:deepslate_tiles
setblock 503 250 316 minecraft:cobbled_deepslate
fill 504 250 276 504 253 276 minecraft:deepslate_tiles
setblock 504 250 315 minecraft:cobbled_deepslate
fill 504 250 316 504 253 316 minecraft:deepslate_tiles
setblock 505 250 314 minecraft:cobbled_deepslate
fill 505 250 315 505 253 315 minecraft:deepslate_tiles
fill 506 250 314 506 253 314 minecraft:deepslate_tiles
setblock 507 250 277 minecraft:cobbled_deepslate
setblock 508 250 276 minecraft:cobbled_deepslate
fill 508 250 277 508 251 277 minecraft:deepslate_tiles
fill 508 250 303 508 250 305 minecraft:deepslate_tiles
setblock 508 250 306 minecraft:cobbled_deepslate
fill 508 250 307 508 253 307 minecraft:deepslate_tiles
setblock 508 250 310 minecraft:deepslate_tiles
setblock 508 250 311 minecraft:cobbled_deepslate
fill 508 250 312 508 253 312 minecraft:deepslate_tiles
setblock 508 250 316 minecraft:cobbled_deepslate
fill 509 250 276 509 253 276 minecraft:deepslate_tiles
setblock 509 250 284 minecraft:deepslate_tiles
setblock 509 250 285 minecraft:cobbled_deepslate
fill 509 250 286 509 252 286 minecraft:deepslate_tiles
fill 509 250 301 509 251 301 minecraft:deepslate_tiles
setblock 509 250 305 minecraft:cobbled_deepslate
fill 509 250 306 509 253 306 minecraft:deepslate_tiles
setblock 509 250 309 minecraft:deepslate_tiles
setblock 509 250 310 minecraft:cobbled_deepslate
fill 509 250 311 509 253 311 minecraft:deepslate_tiles
setblock 509 250 315 minecraft:cobbled_deepslate
fill 509 250 316 509 253 316 minecraft:deepslate_tiles
setblock 510 250 279 minecraft:cobbled_deepslate
fill 510 250 280 510 251 280 minecraft:deepslate_tiles
setblock 510 250 284 minecraft:cobbled_deepslate
fill 510 250 285 510 253 285 minecraft:deepslate_tiles
setblock 510 250 288 minecraft:deepslate_tiles
setblock 510 250 289 minecraft:cobbled_deepslate
fill 510 250 290 510 253 290 minecraft:deepslate_tiles
setblock 510 250 299 minecraft:cobbled_deepslate
fill 510 250 300 510 253 300 minecraft:deepslate_tiles
setblock 510 250 304 minecraft:cobbled_deepslate
fill 510 250 305 510 253 305 minecraft:deepslate_tiles
setblock 510 250 309 minecraft:cobbled_deepslate
fill 510 250 310 510 253 310 minecraft:deepslate_tiles
setblock 510 250 314 minecraft:cobbled_deepslate
fill 510 250 315 510 253 315 minecraft:deepslate_tiles
setblock 511 250 278 minecraft:cobbled_deepslate
fill 511 250 279 511 252 279 minecraft:deepslate_tiles
setblock 511 250 283 minecraft:cobbled_deepslate
fill 511 250 284 511 253 284 minecraft:deepslate_tiles
setblock 511 250 288 minecraft:cobbled_deepslate
fill 511 250 289 511 253 289 minecraft:deepslate_tiles
setblock 511 250 292 minecraft:deepslate_tiles
setblock 511 250 293 minecraft:cobbled_deepslate
fill 511 250 294 511 253 294 minecraft:deepslate_tiles
setblock 511 250 298 minecraft:cobbled_deepslate
fill 511 250 299 511 253 299 minecraft:deepslate_tiles
setblock 511 250 303 minecraft:cobbled_deepslate
fill 511 250 304 511 253 304 minecraft:deepslate_tiles
setblock 511 250 308 minecraft:cobbled_deepslate
fill 511 250 309 511 253 309 minecraft:deepslate_tiles
setblock 511 250 313 minecraft:cobbled_deepslate
fill 511 250 314 511 253 314 minecraft:deepslate_tiles
fill 470 251 286 470 277 287 minecraft:deepslate_tiles
setblock 471 251 282 minecraft:cobbled_deepslate
fill 471 251 283 471 254 283 minecraft:deepslate_tiles
setblock 471 251 287 minecraft:cobbled_deepslate
fill 471 251 288 471 251 291 minecraft:deepslate_tiles
setblock 471 251 292 minecraft:cobbled_deepslate
fill 471 251 293 471 251 296 minecraft:deepslate_tiles
setblock 471 251 297 minecraft:cobbled_deepslate
fill 471 251 298 471 251 301 minecraft:deepslate_tiles
setblock 471 251 302 minecraft:cobbled_deepslate
fill 471 251 303 471 254 303 minecraft:deepslate_tiles
setblock 471 251 307 minecraft:cobbled_deepslate
fill 471 251 308 471 254 308 minecraft:deepslate_tiles
setblock 471 251 312 minecraft:cobbled_deepslate
fill 471 251 313 472 251 313 minecraft:deepslate_tiles
setblock 472 251 282 minecraft:deepslate_tiles
setblock 472 251 286 minecraft:cobbled_deepslate
fill 472 251 287 473 251 287 minecraft:deepslate_tiles
setblock 472 251 291 minecraft:cobbled_deepslate
fill 472 251 292 472 251 295 minecraft:deepslate_tiles
setblock 472 251 296 minecraft:cobbled_deepslate
fill 472 251 297 472 251 300 minecraft:deepslate_tiles
setblock 472 251 301 minecraft:cobbled_deepslate
fill 472 251 302 472 253 302 minecraft:deepslate_tiles
setblock 472 251 306 minecraft:cobbled_deepslate
fill 472 251 307 472 254 307 minecraft:deepslate_tiles
setblock 472 251 311 minecraft:cobbled_deepslate
fill 472 251 312 472 253 312 minecraft:deepslate_tiles
fill 473 251 288 473 252 288 minecraft:deepslate_tiles
setblock 473 251 305 minecraft:cobbled_deepslate
fill 473 251 306 473 252 306 minecraft:deepslate_tiles
fill 483 251 276 483 254 276 minecraft:deepslate_tiles
fill 485 251 316 486 251 316 minecraft:deepslate_tiles
setblock 486 251 276 minecraft:deepslate_tiles
setblock 486 251 277 minecraft:cobbled_deepslate
fill 486 251 278 486 252 278 minecraft:deepslate_tiles
fill 487 251 275 487 308 275 minecraft:deepslate_tiles
setblock 487 251 276 minecraft:cobbled_deepslate
fill 487 251 277 487 254 277 minecraft:deepslate_tiles
setblock 487 251 316 minecraft:cobbled_deepslate
fill 488 251 276 491 251 276 minecraft:deepslate_tiles
fill 488 251 316 488 254 316 minecraft:deepslate_tiles
fill 489 251 311 489 254 311 minecraft:white_wool
setblock 490 251 278 minecraft:cobbled_deepslate
setblock 491 251 277 minecraft:cobbled_deepslate
setblock 491 251 278 minecraft:deepslate_tiles
setblock 491 251 316 minecraft:deepslate_tiles
setblock 492 251 276 minecraft:cobbled_deepslate
fill 492 251 277 492 252 277 minecraft:deepslate_tiles
setblock 492 251 316 minecraft:cobbled_deepslate
fill 493 251 276 493 254 276 minecraft:deepslate_tiles
fill 493 251 316 494 253 316 minecraft:deepslate_tiles
setblock 497 251 276 minecraft:cobbled_deepslate
setblock 498 251 276 minecraft:deepslate_tiles
fill 499 251 316 499 253 316 minecraft:deepslate_tiles
setblock 502 251 276 minecraft:cobbled_deepslate
setblock 502 251 315 minecraft:deepslate_tiles
setblock 502 251 316 minecraft:cobbled_deepslate
fill 503 251 276 503 254 276 minecraft:deepslate_tiles
setblock 503 251 315 minecraft:cobbled_deepslate
fill 503 251 316 503 254 316 minecraft:deepslate_tiles
setblock 504 251 277 minecraft:deepslate_tiles
setblock 504 251 314 minecraft:cobbled_deepslate
fill 504 251 315 504 254 315 minecraft:deepslate_tiles
fill 505 251 314 505 254 314 minecraft:deepslate_tiles
setblock 506 251 277 minecraft:cobbled_deepslate
fill 506 251 313 508 252 313 minecraft:deepslate_tiles
setblock 507 251 276 minecraft:cobbled_deepslate
fill 507 251 277 507 252 277 minecraft:deepslate_tiles
fill 507 251 307 507 251 310 minecraft:deepslate_tiles
fill 507 251 314 508 251 314 minecraft:deepslate_tiles
setblock 507 251 316 minecraft:cobbled_deepslate
fill 508 251 276 508 254 276 minecraft:deepslate_tiles
setblock 508 251 304 minecraft:deepslate_tiles
setblock 508 251 305 minecraft:cobbled_deepslate
fill 508 251 306 508 254 306 minecraft:deepslate_tiles
setblock 508 251 310 minecraft:cobbled_deepslate
fill 508 251 311 508 254 311 minecraft:deepslate_tiles
setblock 508 251 315 minecraft:cobbled_deepslate
fill 508 251 316 508 254 316 minecraft:deepslate_tiles
setblock 509 251 284 minecraft:cobbled_deepslate
setblock 509 251 285 minecraft:deepslate_tiles
fill 509 251 287 509 252 287 minecraft:deepslate_tiles
setblock 509 251 304 minecraft:cobbled_deepslate
fill 509 251 305 509 254 305 minecraft:deepslate_tiles
setblock 509 251 309 minecraft:cobbled_deepslate
fill 509 251 310 509 254 310 minecraft:deepslate_tiles
setblock 509 251 314 minecraft:cobbled_deepslate
fill 509 251 315 509 254 315 minecraft:deepslate_tiles
setblock 510 251 283 minecraft:cobbled_deepslate
fill 510 251 284 510 253 284 minecraft:deepslate_tiles
setblock 510 251 288 minecraft:cobbled_deepslate
fill 510 251 289 510 254 289 minecraft:deepslate_tiles
fill 510 251 291 510 251 292 minecraft:deepslate_tiles
setblock 510 251 298 minecraft:cobbled_deepslate
fill 510 251 299 510 252 299 minecraft:deepslate_tiles
setblock 510 251 303 minecraft:cobbled_deepslate
fill 510 251 304 510 254 304 minecraft:deepslate_tiles
setblock 510 251 308 minecraft:cobbled_deepslate
fill 510 251 309 510 254 309 minecraft:deepslate_tiles
setblock 510 251 313 minecraft:cobbled_deepslate
fill 510 251 314 510 254 314 minecraft:deepslate_tiles
setblock 511 251 277 minecraft:cobbled_deepslate
setblock 511 251 278 minecraft:deepslate_tiles
setblock 511 251 282 minecraft:cobbled_deepslate
fill 511 251 283 511 253 283 minecraft:deepslate_tiles
setblock 511 251 287 minecraft:cobbled_deepslate
fill 511 251 288 511 254 288 minecraft:deepslate_tiles
setblock 511 251 292 minecraft:cobbled_deepslate
fill 511 251 293 511 254 293 minecraft:deepslate_tiles
setblock 511 251 297 minecraft:cobbled_deepslate
fill 511 251 298 511 254 298 minecraft:deepslate_tiles
setblock 511 251 302 minecraft:cobbled_deepslate
fill 511 251 303 511 254 303 minecraft:deepslate_tiles
setblock 511 251 307 minecraft:cobbled_deepslate
fill 511 251 308 511 254 308 minecraft:deepslate_tiles
setblock 511 251 312 minecraft:cobbled_deepslate
fill 511 251 313 511 254 313 minecraft:deepslate_tiles
fill 512 251 307 512 308 307 minecraft:deepslate_tiles
setblock 471 252 281 minecraft:cobbled_deepslate
fill 471 252 282 471 253 282 minecraft:deepslate_tiles
setblock 471 252 286 minecraft:cobbled_deepslate
fill 471 252 287 471 252 290 minecraft:deepslate_tiles
setblock 471 252 291 minecraft:cobbled_deepslate
fill 471 252 292 471 252 295 minecraft:deepslate_tiles
setblock 471 252 296 minecraft:cobbled_deepslate
fill 471 252 297 471 252 300 minecraft:deepslate_tiles
setblock 471 252 301 minecraft:cobbled_deepslate
fill 471 252 302 471 255 302 minecraft:deepslate_tiles
setblock 471 252 306 minecraft:cobbled_deepslate
fill 471 252 307 471 255 307 minecraft:deepslate_tiles
setblock 471 252 311 minecraft:cobbled_deepslate
fill 471 252 312 471 254 313 minecraft:deepslate_tiles
setblock 471 252 316 minecraft:cobbled_deepslate
setblock 472 252 285 minecraft:cobbled_deepslate
fill 472 252 286 472 254 287 minecraft:deepslate_tiles
setblock 472 252 290 minecraft:cobbled_deepslate
fill 472 252 291 472 252 294 minecraft:deepslate_tiles
setblock 472 252 295 minecraft:cobbled_deepslate
fill 472 252 296 472 252 299 minecraft:deepslate_tiles
setblock 472 252 300 minecraft:cobbled_deepslate
fill 472 252 301 472 253 301 minecraft:deepslate_tiles
setblock 472 252 305 minecraft:cobbled_deepslate
fill 472 252 306 472 254 306 minecraft:deepslate_tiles
setblock 472 252 310 minecraft:cobbled_deepslate
fill 472 252 311 472 254 311 minecraft:deepslate_tiles
setblock 473 252 289 minecraft:cobbled_deepslate
setblock 473 252 305 minecraft:deepslate_tiles
setblock 484 252 277 minecraft:deepslate_tiles
fill 484 252 316 485 252 316 minecraft:deepslate_tiles
setblock 485 252 277 minecraft:cobbled_deepslate
setblock 486 252 276 minecraft:cobbled_deepslate
fill 486 252 277 486 255 277 minecraft:deepslate_tiles
setblock 486 252 316 minecraft:cobbled_deepslate
fill 487 252 276 490 252 276 minecraft:deepslate_tiles
setblock 487 252 315 minecraft:cobbled_deepslate
fill 487 252 316 487 255 316 minecraft:deepslate_tiles
fill 488 252 315 490 253 315 minecraft:deepslate_tiles
setblock 489 252 278 minecraft:cobbled_deepslate
setblock 490 252 277 minecraft:cobbled_deepslate
setblock 491 252 276 minecraft:cobbled_deepslate
fill 491 252 277 491 253 277 minecraft:deepslate_tiles
setblock 491 252 316 minecraft:cobbled_deepslate
fill 492 252 276 492 255 276 minecraft:deepslate_tiles
fill 492 252 316 492 255 316 minecraft:deepslate_tiles
setblock 495 252 316 minecraft:deepslate_tiles
setblock 496 252 276 minecraft:cobbled_deepslate
setblock 496 252 316 minecraft:cobbled_deepslate
fill 497 252 316 498 254 316 minecraft:deepslate_tiles
setblock 500 252 316 minecraft:deepslate_tiles
setblock 501 252 276 minecraft:cobbled_deepslate
setblock 501 252 315 minecraft:deepslate_tiles
setblock 501 252 316 minecraft:cobbled_deepslate
fill 502 252 276 502 255 276 minecraft:deepslate_tiles
setblock 502 252 315 minecraft:cobbled_deepslate
fill 502 252 316 502 255 316 minecraft:deepslate_tiles
setblock 503 252 314 minecraft:cobbled_deepslate
fill 503 252 315 503 255 315 minecraft:deepslate_tiles
fill 504 252 314 504 255 314 minecraft:deepslate_tiles
setblock 505 252 276 minecraft:deepslate_tiles
setblock 505 252 277 minecraft:cobbled_deepslate
fill 505 252 313 505 255 313 minecraft:deepslate_tiles
setblock 506 252 276 minecraft:cobbled_deepslate
setblock 506 252 277 minecraft:deepslate_tiles
setblock 506 252 316 minecraft:cobbled_deepslate
fill 507 252 276 507 255 276 minecraft:deepslate_tiles
fill 507 252 307 507 252 309 minecraft:deepslate_tiles
setblock 507 252 310 minecraft:cobbled_deepslate
fill 507 252 311 507 254 311 minecraft:deepslate_tiles
setblock 507 252 314 minecraft:deepslate_tiles
setblock 507 252 315 minecraft:cobbled_deepslate
fill 507 252 316 507 255 316 minecraft:deepslate_tiles
setblock 508 252 304 minecraft:cobbled_deepslate
fill 508 252 305 508 253 305 minecraft:deepslate_tiles
setblock 508 252 309 minecraft:cobbled_deepslate
fill 508 252 310 508 255 310 minecraft:deepslate_tiles
setblock 508 252 314 minecraft:cobbled_deepslate
fill 508 252 315 508 255 315 minecraft:deepslate_tiles
setblock 509 252 288 minecraft:cobbled_deepslate
setblock 509 252 303 minecraft:cobbled_deepslate
fill 509 252 304 509 254 304 minecraft:deepslate_tiles
setblock 509 252 308 minecraft:cobbled_deepslate
fill 509 252 309 509 255 309 minecraft:deepslate_tiles
setblock 509 252 313 minecraft:cobbled_deepslate
fill 509 252 314 509 255 314 minecraft:deepslate_tiles
setblock 510 252 282 minecraft:cobbled_deepslate
setblock 510 252 283 minecraft:deepslate_tiles
setblock 510 252 287 minecraft:cobbled_deepslate
fill 510 252 288 510 255 288 minecraft:deepslate_tiles
setblock 510 252 291 minecraft:deepslate_tiles
setblock 510 252 292 minecraft:cobbled_deepslate
setblock 510 252 302 minecraft:cobbled_deepslate
fill 510 252 303 510 255 303 minecraft:deepslate_tiles
setblock 510 252 307 minecraft:cobbled_deepslate
fill 510 252 308 510 255 308 minecraft:deepslate_tiles
setblock 510 252 312 minecraft:cobbled_deepslate
fill 510 252 313 510 255 313 minecraft:deepslate_tiles
setblock 511 252 281 minecraft:cobbled_deepslate
fill 511 252 282 511 253 282 minecraft:deepslate_tiles
setblock 511 252 286 minecraft:cobbled_deepslate
fill 511 252 287 511 255 287 minecraft:deepslate_tiles
setblock 511 252 291 minecraft:cobbled_deepslate
fill 511 252 292 511 255 292 minecraft:deepslate_tiles
setblock 511 252 296 minecraft:cobbled_deepslate
fill 511 252 297 511 255 297 minecraft:deepslate_tiles
setblock 511 252 301 minecraft:cobbled_deepslate
fill 511 252 302 511 255 302 minecraft:deepslate_tiles
setblock 511 252 306 minecraft:cobbled_deepslate
fill 511 252 307 511 255 307 minecraft:deepslate_tiles
setblock 511 252 311 minecraft:cobbled_deepslate
fill 511 252 312 511 255 312 minecraft:deepslate_tiles
setblock 511 252 316 minecraft:cobbled_deepslate
setblock 471 253 281 minecraft:deepslate_tiles
setblock 471 253 285 minecraft:cobbled_deepslate
fill 471 253 286 471 253 289 minecraft:deepslate_tiles
setblock 471 253 290 minecraft:cobbled_deepslate
fill 471 253 291 471 253 294 minecraft:deepslate_tiles
setblock 471 253 295 minecraft:cobbled_deepslate
fill 471 253 296 471 253 299 minecraft:deepslate_tiles
setblock 471 253 300 minecraft:cobbled_deepslate
fill 471 253 301 471 255 301 minecraft:deepslate_tiles
setblock 471 253 305 minecraft:cobbled_deepslate
fill 471 253 306 471 256 306 minecraft:deepslate_tiles
setblock 471 253 310 minecraft:cobbled_deepslate
fill 471 253 311 471 256 311 minecraft:deepslate_tiles
setblock 471 253 315 minecraft:cobbled_deepslate
setblock 472 253 284 minecraft:cobbled_deepslate
fill 472 253 285 472 254 285 minecraft:deepslate_tiles
setblock 472 253 289 minecraft:cobbled_deepslate
fill 472 253 290 472 253 293 minecraft:deepslate_tiles
setblock 472 253 294 minecraft:cobbled_deepslate
setblock 472 253 295 minecraft:deepslate_tiles
setblock 472 253 304 minecraft:cobbled_deepslate
fill 472 253 305 472 254 305 minecraft:deepslate_tiles
setblock 472 253 309 minecraft:cobbled_deepslate
fill 472 253 310 472 254 310 minecraft:deepslate_tiles
setblock 473 253 278 minecraft:light[level=13]
setblock 473 253 285 minecraft:light[level=12]
setblock 473 253 286 minecraft:light[level=13]
setblock 473 253 292 minecraft:light[level=12]
setblock 473 253 294 minecraft:light[level=13]
setblock 473 253 299 minecraft:light[level=12]
setblock 473 253 302 minecraft:light[level=13]
setblock 473 253 306 minecraft:light[level=12]
setblock 473 253 310 minecraft:light[level=13]
setblock 473 253 313 minecraft:light[level=12]
setblock 480 253 278 minecraft:light[level=12]
setblock 480 253 285 minecraft:light[level=12]
setblock 480 253 292 minecraft:light[level=12]
setblock 480 253 299 minecraft:light[level=12]
setblock 480 253 306 minecraft:light[level=12]
setblock 480 253 313 minecraft:light[level=12]
setblock 481 253 278 minecraft:light[level=13]
setblock 481 253 286 minecraft:light[level=13]
setblock 481 253 294 minecraft:light[level=13]
setblock 481 253 302 minecraft:light[level=13]
setblock 481 253 310 minecraft:light[level=13]
fill 482 253 276 482 255 276 minecraft:deepslate_tiles
fill 482 253 313 482 257 313 minecraft:black_concrete
fill 483 253 316 484 253 316 minecraft:deepslate_tiles
setblock 484 253 277 minecraft:cobbled_deepslate
setblock 485 253 276 minecraft:cobbled_deepslate
fill 485 253 277 485 256 277 minecraft:deepslate_tiles
setblock 485 253 316 minecraft:cobbled_deepslate
fill 486 253 276 489 253 276 minecraft:deepslate_tiles
setblock 486 253 315 minecraft:cobbled_deepslate
fill 486 253 316 486 256 316 minecraft:deepslate_tiles
setblock 487 253 278 minecraft:light[level=12]
setblock 487 253 285 minecraft:light[level=12]
setblock 487 253 292 minecraft:light[level=12]
setblock 487 253 299 minecraft:light[level=12]
setblock 487 253 306 minecraft:light[level=12]
setblock 487 253 313 minecraft:light[level=12]
fill 487 253 315 487 256 315 minecraft:deepslate_tiles
setblock 489 253 277 minecraft:cobbled_deepslate
setblock 489 253 278 minecraft:light[level=13]
setblock 489 253 286 minecraft:light[level=13]
setblock 489 253 294 minecraft:light[level=13]
setblock 489 253 302 minecraft:light[level=13]
setblock 489 253 310 minecraft:light[level=13]
setblock 490 253 276 minecraft:cobbled_deepslate
fill 490 253 277 490 254 277 minecraft:deepslate_tiles
setblock 490 253 316 minecraft:cobbled_deepslate
fill 491 253 276 491 256 276 minecraft:deepslate_tiles
fill 491 253 316 491 256 316 minecraft:deepslate_tiles
setblock 494 253 278 minecraft:light[level=12]
setblock 494 253 285 minecraft:light[level=12]
setblock 494 253 292 minecraft:light[level=12]
setblock 494 253 299 minecraft:light[level=12]
setblock 494 253 306 minecraft:light[level=12]
setblock 494 253 313 minecraft:light[level=12]
setblock 495 253 276 minecraft:cobbled_deepslate
setblock 495 253 316 minecraft:cobbled_deepslate
fill 496 253 316 496 256 316 minecraft:deepslate_tiles
setblock 497 253 278 minecraft:light[level=13]
setblock 497 253 286 minecraft:light[level=13]
setblock 497 253 294 minecraft:light[level=13]
setblock 497 253 302 minecraft:light[level=13]
setblock 497 253 310 minecraft:light[level=13]
setblock 500 253 276 minecraft:cobbled_deepslate
setblock 500 253 315 minecraft:deepslate_tiles
setblock 500 253 316 minecraft:cobbled_deepslate
fill 501 253 276 501 256 276 minecraft:deepslate_tiles
setblock 501 253 278 minecraft:light[level=12]
setblock 501 253 285 minecraft:light[level=12]
setblock 501 253 292 minecraft:light[level=12]
setblock 501 253 299 minecraft:light[level=12]
setblock 501 253 306 minecraft:light[level=12]
setblock 501 253 313 minecraft:light[level=12]
setblock 501 253 315 minecraft:cobbled_deepslate
fill 501 253 316 501 256 316 minecraft:deepslate_tiles
setblock 502 253 314 minecraft:cobbled_deepslate
fill 502 253 315 502 256 315 minecraft:deepslate_tiles
fill 503 253 314 503 256 314 minecraft:deepslate_tiles
fill 504 253 313 504 256 313 minecraft:deepslate_tiles
setblock 505 253 276 minecraft:cobbled_deepslate
setblock 505 253 278 minecraft:light[level=13]
setblock 505 253 286 minecraft:light[level=13]
setblock 505 253 294 minecraft:light[level=13]
setblock 505 253 302 minecraft:light[level=13]
setblock 505 253 310 minecraft:light[level=13]
setblock 505 253 316 minecraft:cobbled_deepslate
fill 506 253 276 506 256 276 minecraft:deepslate_tiles
fill 506 253 313 507 253 313 minecraft:deepslate_tiles
setblock 506 253 315 minecraft:cobbled_deepslate
fill 506 253 316 506 256 316 minecraft:deepslate_tiles
setblock 507 253 308 minecraft:deepslate_tiles
setblock 507 253 309 minecraft:cobbled_deepslate
fill 507 253 310 507 254 310 minecraft:deepslate_tiles
setblock 507 253 314 minecraft:cobbled_deepslate
fill 507 253 315 507 256 315 minecraft:deepslate_tiles
setblock 508 253 278 minecraft:light[level=12]
setblock 508 253 285 minecraft:light[level=12]
setblock 508 253 292 minecraft:light[level=12]
setblock 508 253 299 minecraft:light[level=12]
setblock 508 253 308 minecraft:cobbled_deepslate
fill 508 253 309 508 256 309 minecraft:deepslate_tiles
setblock 508 253 313 minecraft:cobbled_deepslate
fill 508 253 314 508 256 314 minecraft:deepslate_tiles
setblock 509 253 302 minecraft:cobbled_deepslate
setblock 509 253 303 minecraft:deepslate_tiles
setblock 509 253 307 minecraft:cobbled_deepslate
fill 509 253 308 509 256 308 minecraft:deepslate_tiles
setblock 509 253 312 minecraft:cobbled_deepslate
fill 509 253 313 509 256 313 minecraft:deepslate_tiles
setblock 510 253 286 minecraft:cobbled_deepslate
fill 510 253 287 510 254 287 minecraft:deepslate_tiles
setblock 510 253 291 minecraft:cobbled_deepslate
fill 510 253 292 510 253 293 minecraft:deepslate_tiles
setblock 510 253 301 minecraft:cobbled_deepslate
fill 510 253 302 510 254 302 minecraft:deepslate_tiles
setblock 510 253 306 minecraft:cobbled_deepslate
fill 510 253 307 510 256 307 minecraft:deepslate_tiles
setblock 510 253 311 minecraft:cobbled_deepslate
fill 510 253 312 510 256 312 minecraft:deepslate_tiles
setblock 510 253 316 minecraft:cobbled_deepslate
setblock 511 253 285 minecraft:cobbled_deepslate
fill 511 253 286 511 255 286 minecraft:deepslate_tiles
setblock 511 253 290 minecraft:cobbled_deepslate
fill 511 253 291 511 256 291 minecraft:deepslate_tiles
setblock 511 253 295 minecraft:cobbled_deepslate
fill 511 253 296 511 256 296 minecraft:deepslate_tiles
setblock 511 253 300 minecraft:cobbled_deepslate
fill 511 253 301 511 255 301 minecraft:deepslate_tiles
setblock 511 253 305 minecraft:cobbled_deepslate
fill 511 253 306 511 256 306 minecraft:deepslate_tiles
setblock 511 253 310 minecraft:cobbled_deepslate
fill 511 253 311 511 256 311 minecraft:deepslate_tiles
setblock 511 253 315 minecraft:cobbled_deepslate
fill 511 253 316 511 256 316 minecraft:deepslate_tiles
fill 470 254 282 470 308 283 minecraft:deepslate_tiles
setblock 470 254 284 minecraft:white_wool
fill 470 254 285 471 256 285 minecraft:deepslate_tiles
setblock 471 254 284 minecraft:cobbled_deepslate
fill 471 254 286 471 254 288 minecraft:deepslate_tiles
setblock 471 254 289 minecraft:cobbled_deepslate
fill 471 254 290 471 254 293 minecraft:deepslate_tiles
setblock 471 254 294 minecraft:cobbled_deepslate
fill 471 254 295 471 254 298 minecraft:deepslate_tiles
setblock 471 254 299 minecraft:cobbled_deepslate
fill 471 254 300 471 255 300 minecraft:deepslate_tiles
setblock 471 254 304 minecraft:cobbled_deepslate
fill 471 254 305 471 256 305 minecraft:deepslate_tiles
setblock 471 254 309 minecraft:cobbled_deepslate
fill 471 254 310 471 257 310 minecraft:deepslate_tiles
setblock 471 254 314 minecraft:cobbled_deepslate
setblock 471 254 315 minecraft:deepslate_tiles
setblock 472 254 288 minecraft:cobbled_deepslate
fill 472 254 289 472 254 292 minecraft:deepslate_tiles
setblock 472 254 293 minecraft:cobbled_deepslate
fill 472 254 294 472 255 294 minecraft:deepslate_tiles
setblock 472 254 304 minecraft:deepslate_tiles
setblock 472 254 308 minecraft:cobbled_deepslate
fill 472 254 309 472 255 309 minecraft:deepslate_tiles
fill 482 254 316 483 254 316 minecraft:deepslate_tiles
setblock 484 254 276 minecraft:cobbled_deepslate
fill 484 254 277 484 257 277 minecraft:deepslate_tiles
setblock 484 254 316 minecraft:cobbled_deepslate
fill 485 254 276 488 254 276 minecraft:deepslate_tiles
setblock 485 254 315 minecraft:cobbled_deepslate
fill 485 254 316 485 257 316 minecraft:deepslate_tiles
fill 486 254 315 486 257 315 minecraft:deepslate_tiles
setblock 488 254 277 minecraft:cobbled_deepslate
fill 488 254 315 489 254 315 minecraft:deepslate_tiles
setblock 489 254 276 minecraft:cobbled_deepslate
fill 489 254 277 489 255 277 minecraft:deepslate_tiles
setblock 489 254 316 minecraft:cobbled_deepslate
fill 490 254 276 490 257 276 minecraft:deepslate_tiles
setblock 490 254 315 minecraft:cobbled_deepslate
fill 490 254 316 490 257 316 minecraft:deepslate_tiles
setblock 493 254 316 minecraft:deepslate_tiles
setblock 494 254 276 minecraft:cobbled_deepslate
setblock 494 254 316 minecraft:cobbled_deepslate
fill 495 254 316 495 257 316 minecraft:deepslate_tiles
setblock 499 254 315 minecraft:deepslate_tiles
setblock 499 254 316 minecraft:cobbled_deepslate
fill 500 254 276 500 257 276 minecraft:deepslate_tiles
setblock 500 254 315 minecraft:cobbled_deepslate
fill 500 254 316 500 257 316 minecraft:deepslate_tiles
setblock 501 254 314 minecraft:cobbled_deepslate
fill 501 254 315 501 257 315 minecraft:deepslate_tiles
fill 502 254 314 502 257 314 minecraft:deepslate_tiles
fill 503 254 313 503 257 313 minecraft:deepslate_tiles
setblock 504 254 276 minecraft:cobbled_deepslate
setblock 504 254 316 minecraft:cobbled_deepslate
fill 505 254 276 505 257 276 minecraft:deepslate_tiles
setblock 505 254 315 minecraft:cobbled_deepslate
fill 505 254 316 505 257 316 minecraft:deepslate_tiles
setblock 506 254 313 minecraft:deepslate_tiles
setblock 506 254 314 minecraft:cobbled_deepslate
fill 506 254 315 506 257 315 minecraft:deepslate_tiles
setblock 507 254 309 minecraft:deepslate_tiles
setblock 507 254 313 minecraft:cobbled_deepslate
fill 507 254 314 507 257 314 minecraft:deepslate_tiles
setblock 508 254 307 minecraft:cobbled_deepslate
fill 508 254 308 508 255 308 minecraft:deepslate_tiles
setblock 508 254 312 minecraft:cobbled_deepslate
fill 508 254 313 508 255 313 minecraft:deepslate_tiles
setblock 509 254 276 minecraft:cobbled_deepslate
setblock 509 254 306 minecraft:cobbled_deepslate
fill 509 254 307 509 256 307 minecraft:deepslate_tiles
setblock 509 254 311 minecraft:cobbled_deepslate
fill 509 254 312 509 257 312 minecraft:deepslate_tiles
setblock 509 254 316 minecraft:cobbled_deepslate
setblock 510 254 286 minecraft:deepslate_tiles
setblock 510 254 290 minecraft:cobbled_deepslate
fill 510 254 291 510 255 292 minecraft:deepslate_tiles
setblock 510 254 301 minecraft:deepslate_tiles
setblock 510 254 305 minecraft:cobbled_deepslate
fill 510 254 306 510 257 306 minecraft:deepslate_tiles
setblock 510 254 310 minecraft:cobbled_deepslate
fill 510 254 311 510 257 311 minecraft:deepslate_tiles
setblock 510 254 315 minecraft:cobbled_deepslate
fill 510 254 316 510 257 316 minecraft:deepslate_tiles
setblock 511 254 284 minecraft:cobbled_deepslate
fill 511 254 285 511 255 285 minecraft:deepslate_tiles
setblock 511 254 289 minecraft:cobbled_deepslate
fill 511 254 290 511 257 290 minecraft:deepslate_tiles
setblock 511 254 294 minecraft:cobbled_deepslate
fill 511 254 295 511 257 295 minecraft:deepslate_tiles
setblock 511 254 299 minecraft:cobbled_deepslate
fill 511 254 300 511 255 300 minecraft:deepslate_tiles
setblock 511 254 304 minecraft:cobbled_deepslate
fill 511 254 305 511 257 305 minecraft:deepslate_tiles
setblock 511 254 309 minecraft:cobbled_deepslate
fill 511 254 310 511 257 310 minecraft:deepslate_tiles
setblock 511 254 314 minecraft:cobbled_deepslate
fill 511 254 315 511 257 315 minecraft:deepslate_tiles
setblock 512 254 316 minecraft:redstone_block
fill 470 255 284 471 255 284 minecraft:deepslate_tiles
fill 471 255 286 471 255 287 minecraft:deepslate_tiles
setblock 471 255 288 minecraft:cobbled_deepslate
fill 471 255 289 471 255 292 minecraft:deepslate_tiles
setblock 471 255 293 minecraft:cobbled_deepslate
fill 471 255 294 471 255 297 minecraft:deepslate_tiles
setblock 471 255 298 minecraft:cobbled_deepslate
setblock 471 255 299 minecraft:deepslate_tiles
setblock 471 255 303 minecraft:cobbled_deepslate
fill 471 255 304 471 256 304 minecraft:deepslate_tiles
setblock 471 255 308 minecraft:cobbled_deepslate
fill 471 255 309 471 257 309 minecraft:deepslate_tiles
setblock 471 255 312 minecraft:deepslate_tiles
setblock 471 255 313 minecraft:cobbled_deepslate
setblock 471 255 314 minecraft:deepslate_tiles
setblock 472 255 287 minecraft:cobbled_deepslate
fill 472 255 288 472 255 291 minecraft:deepslate_tiles
setblock 472 255 292 minecraft:cobbled_deepslate
fill 472 255 293 472 258 293 minecraft:deepslate_tiles
setblock 482 255 316 minecraft:deepslate_tiles
setblock 483 255 276 minecraft:cobbled_deepslate
setblock 483 255 316 minecraft:cobbled_deepslate
fill 484 255 276 487 255 276 minecraft:deepslate_tiles
setblock 484 255 315 minecraft:cobbled_deepslate
fill 484 255 316 484 258 316 minecraft:deepslate_tiles
fill 485 255 315 485 258 315 minecraft:deepslate_tiles
setblock 487 255 277 minecraft:cobbled_deepslate
setblock 488 255 276 minecraft:cobbled_deepslate
fill 488 255 277 488 256 277 minecraft:deepslate_tiles
setblock 488 255 315 minecraft:deepslate_tiles
setblock 488 255 316 minecraft:cobbled_deepslate
fill 489 255 276 489 258 276 minecraft:deepslate_tiles
setblock 489 255 315 minecraft:cobbled_deepslate
fill 489 255 316 489 258 316 minecraft:deepslate_tiles
setblock 490 255 315 minecraft:deepslate_tiles
setblock 493 255 316 minecraft:cobbled_deepslate
fill 494 255 316 494 258 316 minecraft:deepslate_tiles
setblock 497 255 316 minecraft:deepslate_tiles
setblock 498 255 315 minecraft:deepslate_tiles
setblock 498 255 316 minecraft:cobbled_deepslate
setblock 499 255 315 minecraft:cobbled_deepslate
fill 499 255 316 499 258 316 minecraft:deepslate_tiles
fill 500 255 315 500 258 315 minecraft:deepslate_tiles
fill 501 255 314 501 258 314 minecraft:deepslate_tiles
setblock 503 255 276 minecraft:cobbled_deepslate
setblock 503 255 316 minecraft:cobbled_deepslate
fill 504 255 276 504 258 276 minecraft:deepslate_tiles
setblock 504 255 315 minecraft:cobbled_deepslate
fill 504 255 316 504 258 316 minecraft:deepslate_tiles
setblock 505 255 314 minecraft:cobbled_deepslate
fill 505 255 315 505 258 315 minecraft:deepslate_tiles
setblock 506 255 313 minecraft:cobbled_deepslate
fill 506 255 314 506 258 314 minecraft:deepslate_tiles
fill 507 255 313 507 256 313 minecraft:deepslate_tiles
setblock 508 255 276 minecraft:cobbled_deepslate
setblock 508 255 307 minecraft:deepslate_tiles
setblock 508 255 311 minecraft:cobbled_deepslate
fill 508 255 312 508 256 312 minecraft:deepslate_tiles
setblock 508 255 316 minecraft:cobbled_deepslate
setblock 509 255 305 minecraft:cobbled_deepslate
setblock 509 255 306 minecraft:deepslate_tiles
setblock 509 255 310 minecraft:cobbled_deepslate
fill 509 255 311 509 257 311 minecraft:deepslate_tiles
setblock 509 255 315 minecraft:cobbled_deepslate
fill 509 255 316 509 258 316 minecraft:deepslate_tiles
setblock 510 255 289 minecraft:cobbled_deepslate
setblock 510 255 290 minecraft:deepslate_tiles
setblock 510 255 304 minecraft:cobbled_deepslate
fill 510 255 305 510 256 305 minecraft:deepslate_tiles
setblock 510 255 309 minecraft:cobbled_deepslate
fill 510 255 310 510 258 310 minecraft:deepslate_tiles
setblock 510 255 314 minecraft:cobbled_deepslate
fill 510 255 315 510 257 315 minecraft:deepslate_tiles
setblock 511 255 288 minecraft:cobbled_deepslate
fill 511 255 289 511 257 289 minecraft:deepslate_tiles
setblock 511 255 293 minecraft:cobbled_deepslate
fill 511 255 294 511 258 294 minecraft:deepslate_tiles
setblock 511 255 298 minecraft:cobbled_deepslate
setblock 511 255 299 minecraft:deepslate_tiles
setblock 511 255 303 minecraft:cobbled_deepslate
fill 511 255 304 511 257 304 minecraft:deepslate_tiles
setblock 511 255 308 minecraft:cobbled_deepslate
fill 511 255 309 511 258 309 minecraft:deepslate_tiles
setblock 511 255 313 minecraft:cobbled_deepslate
fill 511 255 314 511 258 314 minecraft:deepslate_tiles
fill 512 255 316 512 256 316 minecraft:deepslate_tiles
fill 470 256 284 470 308 284 minecraft:deepslate_tiles
setblock 471 256 286 minecraft:deepslate_tiles
setblock 471 256 287 minecraft:cobbled_deepslate
fill 471 256 288 471 256 291 minecraft:deepslate_tiles
setblock 471 256 292 minecraft:cobbled_deepslate
fill 471 256 293 471 256 296 minecraft:deepslate_tiles
setblock 471 256 297 minecraft:cobbled_deepslate
setblock 471 256 298 minecraft:deepslate_tiles
setblock 471 256 307 minecraft:cobbled_deepslate
fill 471 256 308 471 257 308 minecraft:deepslate_tiles
setblock 471 256 312 minecraft:cobbled_deepslate
setblock 471 256 313 minecraft:deepslate_tiles
fill 472 256 288 472 256 290 minecraft:deepslate_tiles
setblock 472 256 291 minecraft:cobbled_deepslate
fill 472 256 292 472 259 292 minecraft:deepslate_tiles
setblock 481 256 276 minecraft:deepslate_tiles
fill 481 256 313 481 257 313 minecraft:black_concrete
setblock 481 256 316 minecraft:deepslate_tiles
setblock 482 256 276 minecraft:cobbled_deepslate
fill 482 256 312 482 257 312 minecraft:black_concrete
fill 482 256 314 482 257 314 minecraft:black_concrete
setblock 482 256 316 minecraft:cobbled_deepslate
fill 483 256 276 486 256 276 minecraft:deepslate_tiles
fill 483 256 313 483 257 313 minecraft:black_concrete
fill 483 256 316 483 259 316 minecraft:deepslate_tiles
fill 484 256 315 484 259 315 minecraft:deepslate_tiles
setblock 486 256 277 minecraft:cobbled_deepslate
setblock 487 256 276 minecraft:cobbled_deepslate
fill 487 256 277 487 257 277 minecraft:deepslate_tiles
setblock 487 256 316 minecraft:cobbled_deepslate
fill 488 256 276 488 259 276 minecraft:deepslate_tiles
setblock 488 256 315 minecraft:cobbled_deepslate
fill 488 256 316 488 259 316 minecraft:deepslate_tiles
fill 489 256 315 489 257 315 minecraft:deepslate_tiles
setblock 492 256 276 minecraft:cobbled_deepslate
setblock 492 256 316 minecraft:cobbled_deepslate
fill 493 256 316 493 259 316 minecraft:deepslate_tiles
setblock 497 256 316 minecraft:cobbled_deepslate
setblock 498 256 315 minecraft:cobbled_deepslate
fill 498 256 316 498 259 316 minecraft:deepslate_tiles
fill 499 256 280 499 263 280 minecraft:cobbled_deepslate
fill 499 256 315 499 259 315 minecraft:deepslate_tiles
fill 500 256 314 500 259 314 minecraft:deepslate_tiles
fill 500 256 317 500 261 317 minecraft:deepslate_tiles
setblock 501 256 317 minecraft:redstone_block
setblock 502 256 276 minecraft:cobbled_deepslate
fill 502 256 313 502 258 313 minecraft:deepslate_tiles
setblock 502 256 316 minecraft:cobbled_deepslate
fill 503 256 276 503 259 276 minecraft:deepslate_tiles
setblock 503 256 315 minecraft:cobbled_deepslate
fill 503 256 316 503 259 316 minecraft:deepslate_tiles
setblock 504 256 314 minecraft:cobbled_deepslate
fill 504 256 315 504 259 315 minecraft:deepslate_tiles
setblock 505 256 313 minecraft:cobbled_deepslate
fill 505 256 314 505 259 314 minecraft:deepslate_tiles
fill 506 256 313 506 258 313 minecraft:deepslate_tiles
setblock 507 256 276 minecraft:cobbled_deepslate
setblock 507 256 316 minecraft:cobbled_deepslate
setblock 508 256 310 minecraft:cobbled_deepslate
setblock 508 256 311 minecraft:deepslate_tiles
setblock 508 256 315 minecraft:cobbled_deepslate
fill 508 256 316 508 259 316 minecraft:deepslate_tiles
setblock 509 256 309 minecraft:cobbled_deepslate
fill 509 256 310 509 257 310 minecraft:deepslate_tiles
setblock 509 256 314 minecraft:cobbled_deepslate
fill 509 256 315 509 259 315 minecraft:deepslate_tiles
setblock 510 256 308 minecraft:cobbled_deepslate
fill 510 256 309 510 258 309 minecraft:deepslate_tiles
setblock 510 256 313 minecraft:cobbled_deepslate
fill 510 256 314 510 258 314 minecraft:deepslate_tiles
setblock 511 256 287 minecraft:cobbled_deepslate
setblock 511 256 288 minecraft:deepslate_tiles
setblock 511 256 292 minecraft:cobbled_deepslate
fill 511 256 293 511 259 293 minecraft:deepslate_tiles
setblock 511 256 302 minecraft:cobbled_deepslate
setblock 511 256 303 minecraft:deepslate_tiles
setblock 511 256 307 minecraft:cobbled_deepslate
fill 511 256 308 511 259 308 minecraft:deepslate_tiles
setblock 511 256 312 minecraft:cobbled_deepslate
fill 511 256 313 511 259 313 minecraft:deepslate_tiles
fill 470 257 285 470 308 285 minecraft:deepslate_tiles
setblock 471 257 286 minecraft:cobbled_deepslate
fill 471 257 287 471 257 290 minecraft:deepslate_tiles
setblock 471 257 291 minecraft:cobbled_deepslate
fill 471 257 292 471 257 295 minecraft:deepslate_tiles
setblock 471 257 296 minecraft:cobbled_deepslate
fill 471 257 297 471 260 297 minecraft:deepslate_tiles
setblock 471 257 311 minecraft:cobbled_deepslate
setblock 471 257 312 minecraft:deepslate_tiles
setblock 472 257 289 minecraft:deepslate_tiles
setblock 472 257 290 minecraft:cobbled_deepslate
fill 472 257 291 472 260 291 minecraft:deepslate_tiles
fill 476 257 300 477 258 301 minecraft:white_wool
setblock 481 257 276 minecraft:cobbled_deepslate
setblock 481 257 316 minecraft:cobbled_deepslate
fill 482 257 276 485 257 276 minecraft:deepslate_tiles
fill 482 257 316 482 260 316 minecraft:deepslate_tiles
fill 483 257 315 483 260 315 minecraft:deepslate_tiles
setblock 485 257 277 minecraft:cobbled_deepslate
setblock 486 257 276 minecraft:cobbled_deepslate
fill 486 257 277 486 260 277 minecraft:deepslate_tiles
setblock 486 257 316 minecraft:cobbled_deepslate
fill 487 257 276 487 260 276 minecraft:deepslate_tiles
setblock 487 257 315 minecraft:cobbled_deepslate
fill 487 257 316 487 260 316 minecraft:deepslate_tiles
fill 488 257 315 488 260 315 minecraft:deepslate_tiles
setblock 491 257 276 minecraft:cobbled_deepslate
setblock 491 257 316 minecraft:cobbled_deepslate
fill 492 257 316 492 260 316 minecraft:deepslate_tiles
setblock 496 257 316 minecraft:cobbled_deepslate
setblock 497 257 315 minecraft:cobbled_deepslate
fill 497 257 316 497 260 316 minecraft:deepslate_tiles
fill 498 257 315 498 260 315 minecraft:deepslate_tiles
fill 499 257 276 499 258 276 minecraft:deepslate_tiles
setblock 501 257 276 minecraft:cobbled_deepslate
setblock 501 257 316 minecraft:cobbled_deepslate
fill 501 257 317 501 308 317 minecraft:deepslate_tiles
fill 502 257 276 502 260 276 minecraft:deepslate_tiles
setblock 502 257 315 minecraft:cobbled_deepslate
fill 502 257 316 502 260 316 minecraft:deepslate_tiles
setblock 503 257 314 minecraft:cobbled_deepslate
setblock 503 257 315 minecraft:white_wool
setblock 504 257 313 minecraft:cobbled_deepslate
setblock 504 257 314 minecraft:white_wool
setblock 505 257 313 minecraft:white_wool
setblock 506 257 276 minecraft:cobbled_deepslate
setblock 506 257 312 minecraft:white_wool
setblock 506 257 316 minecraft:cobbled_deepslate
setblock 507 257 315 minecraft:cobbled_deepslate
fill 507 257 316 507 260 316 minecraft:deepslate_tiles
setblock 508 257 314 minecraft:cobbled_deepslate
fill 508 257 315 508 260 315 minecraft:deepslate_tiles
setblock 509 257 309 minecraft:deepslate_tiles
setblock 509 257 313 minecraft:cobbled_deepslate
setblock 510 257 307 minecraft:cobbled_deepslate
setblock 510 257 308 minecraft:deepslate_tiles
setblock 510 257 312 minecraft:cobbled_deepslate
fill 510 257 313 510 259 313 minecraft:deepslate_tiles
setblock 511 257 291 minecraft:cobbled_deepslate
fill 511 257 292 511 260 292 minecraft:deepslate_tiles
setblock 511 257 296 minecraft:cobbled_deepslate
setblock 511 257 306 minecraft:cobbled_deepslate
fill 511 257 307 511 258 307 minecraft:deepslate_tiles
setblock 511 257 311 minecraft:cobbled_deepslate
fill 511 257 312 511 260 312 minecraft:deepslate_tiles
setblock 511 257 316 minecraft:cobbled_deepslate
setblock 512 257 316 minecraft:white_wool
fill 471 258 287 471 258 289 minecraft:deepslate_tiles
setblock 471 258 290 minecraft:cobbled_deepslate
fill 471 258 291 471 258 294 minecraft:deepslate_tiles
setblock 471 258 295 minecraft:cobbled_deepslate
fill 471 258 296 471 261 296 minecraft:deepslate_tiles
setblock 472 258 290 minecraft:deepslate_tiles
setblock 480 258 276 minecraft:cobbled_deepslate
setblock 480 258 316 minecraft:cobbled_deepslate
fill 481 258 276 484 258 276 minecraft:deepslate_tiles
fill 481 258 316 481 261 316 minecraft:deepslate_tiles
fill 482 258 315 482 261 315 minecraft:deepslate_tiles
setblock 483 258 277 minecraft:deepslate_tiles
setblock 484 258 277 minecraft:cobbled_deepslate
setblock 485 258 276 minecraft:cobbled_deepslate
fill 485 258 277 485 261 277 minecraft:deepslate_tiles
setblock 485 258 316 minecraft:cobbled_deepslate
fill 486 258 276 486 261 276 minecraft:deepslate_tiles
setblock 486 258 315 minecraft:cobbled_deepslate
fill 486 258 316 486 261 316 minecraft:deepslate_tiles
fill 487 258 315 487 261 315 minecraft:deepslate_tiles
setblock 490 258 276 minecraft:cobbled_deepslate
setblock 490 258 316 minecraft:cobbled_deepslate
fill 491 258 276 491 261 276 minecraft:deepslate_tiles
fill 491 258 316 491 261 316 minecraft:deepslate_tiles
setblock 495 258 316 minecraft:cobbled_deepslate
setblock 496 258 315 minecraft:cobbled_deepslate
fill 496 258 316 496 261 316 minecraft:deepslate_tiles
fill 497 258 315 497 261 315 minecraft:deepslate_tiles
fill 499 258 314 499 260 314 minecraft:deepslate_tiles
setblock 500 258 276 minecraft:cobbled_deepslate
setblock 500 258 316 minecraft:cobbled_deepslate
fill 501 258 276 501 261 276 minecraft:deepslate_tiles
setblock 501 258 315 minecraft:cobbled_deepslate
fill 501 258 316 501 261 316 minecraft:deepslate_tiles
setblock 502 258 314 minecraft:cobbled_deepslate
fill 502 258 315 503 260 315 minecraft:deepslate_tiles
setblock 503 258 313 minecraft:cobbled_deepslate
fill 503 258 314 504 260 314 minecraft:deepslate_tiles
fill 504 258 313 505 259 313 minecraft:deepslate_tiles
setblock 505 258 276 minecraft:cobbled_deepslate
fill 505 258 312 505 267 312 minecraft:black_concrete
setblock 505 258 316 minecraft:cobbled_deepslate
fill 506 258 276 506 261 276 minecraft:deepslate_tiles
setblock 506 258 315 minecraft:cobbled_deepslate
fill 506 258 316 506 261 316 minecraft:deepslate_tiles
setblock 507 258 311 minecraft:white_wool
setblock 507 258 314 minecraft:cobbled_deepslate
fill 507 258 315 507 261 315 minecraft:deepslate_tiles
setblock 508 258 310 minecraft:white_wool
setblock 508 258 314 minecraft:deepslate_tiles
setblock 509 258 309 minecraft:white_wool
setblock 510 258 308 minecraft:white_wool
setblock 510 258 311 minecraft:cobbled_deepslate
fill 510 258 312 510 259 312 minecraft:deepslate_tiles
setblock 510 258 316 minecraft:cobbled_deepslate
setblock 511 258 290 minecraft:cobbled_deepslate
fill 511 258 291 511 261 291 minecraft:deepslate_tiles
setblock 511 258 295 minecraft:cobbled_deepslate
fill 511 258 296 511 261 296 minecraft:deepslate_tiles
setblock 511 258 306 minecraft:deepslate_tiles
setblock 511 258 310 minecraft:cobbled_deepslate
fill 511 258 311 511 261 311 minecraft:deepslate_tiles
setblock 511 258 315 minecraft:cobbled_deepslate
fill 511 258 316 512 258 316 minecraft:deepslate_tiles
setblock 471 259 288 minecraft:deepslate_tiles
setblock 471 259 289 minecraft:cobbled_deepslate
fill 471 259 290 471 259 293 minecraft:deepslate_tiles
setblock 471 259 294 minecraft:cobbled_deepslate
fill 471 259 295 471 262 295 minecraft:deepslate_tiles
setblock 472 259 293 minecraft:cobbled_deepslate
setblock 473 259 278 minecraft:light[level=12]
setblock 473 259 285 minecraft:light[level=12]
setblock 473 259 292 minecraft:light[level=12]
setblock 473 259 299 minecraft:light[level=12]
setblock 473 259 306 minecraft:light[level=12]
setblock 473 259 313 minecraft:light[level=12]
fill 474 259 309 474 270 309 minecraft:white_wool
setblock 479 259 276 minecraft:cobbled_deepslate
setblock 479 259 316 minecraft:cobbled_deepslate
fill 480 259 276 483 259 276 minecraft:deepslate_tiles
setblock 480 259 278 minecraft:light[level=12]
setblock 480 259 285 minecraft:light[level=12]
setblock 480 259 292 minecraft:light[level=12]
setblock 480 259 299 minecraft:light[level=12]
setblock 480 259 306 minecraft:light[level=12]
setblock 480 259 313 minecraft:light[level=12]
fill 480 259 316 480 262 316 minecraft:deepslate_tiles
fill 481 259 315 481 262 315 minecraft:deepslate_tiles
setblock 482 259 277 minecraft:deepslate_tiles
setblock 483 259 277 minecraft:cobbled_deepslate
setblock 484 259 276 minecraft:cobbled_deepslate
fill 484 259 277 484 262 277 minecraft:deepslate_tiles
setblock 484 259 316 minecraft:cobbled_deepslate
fill 485 259 276 485 262 276 minecraft:deepslate_tiles
setblock 485 259 315 minecraft:cobbled_deepslate
fill 485 259 316 485 262 316 minecraft:deepslate_tiles
fill 486 259 315 486 262 315 minecraft:deepslate_tiles
setblock 487 259 277 minecraft:deepslate_tiles
setblock 487 259 278 minecraft:light[level=12]
setblock 487 259 285 minecraft:light[level=12]
setblock 487 259 292 minecraft:light[level=12]
setblock 487 259 299 minecraft:light[level=12]
setblock 487 259 306 minecraft:light[level=12]
setblock 487 259 313 minecraft:light[level=12]
setblock 489 259 276 minecraft:cobbled_deepslate
setblock 489 259 315 minecraft:deepslate_tiles
setblock 489 259 316 minecraft:cobbled_deepslate
fill 490 259 276 490 262 276 minecraft:deepslate_tiles
fill 490 259 316 490 262 316 minecraft:deepslate_tiles
setblock 494 259 278 minecraft:light[level=12]
setblock 494 259 285 minecraft:light[level=12]
setblock 494 259 292 minecraft:light[level=12]
setblock 494 259 299 minecraft:light[level=12]
setblock 494 259 306 minecraft:light[level=12]
setblock 494 259 313 minecraft:light[level=12]
setblock 494 259 316 minecraft:cobbled_deepslate
setblock 495 259 315 minecraft:cobbled_deepslate
fill 495 259 316 495 262 316 minecraft:deepslate_tiles
fill 496 259 315 496 262 315 minecraft:deepslate_tiles
fill 497 259 276 498 259 276 minecraft:deepslate_tiles
fill 498 259 314 498 261 314 minecraft:deepslate_tiles
setblock 499 259 276 minecraft:cobbled_deepslate
setblock 499 259 316 minecraft:cobbled_deepslate
fill 500 259 276 500 262 276 minecraft:deepslate_tiles
setblock 500 259 315 minecraft:cobbled_deepslate
fill 500 259 316 500 262 316 minecraft:deepslate_tiles
setblock 501 259 278 minecraft:light[level=12]
setblock 501 259 285 minecraft:light[level=12]
setblock 501 259 292 minecraft:light[level=12]
setblock 501 259 299 minecraft:light[level=12]
setblock 501 259 306 minecraft:light[level=12]
setblock 501 259 313 minecraft:deepslate_tiles
setblock 501 259 314 minecraft:cobbled_deepslate
fill 501 259 315 501 262 315 minecraft:deepslate_tiles
setblock 502 259 313 minecraft:cobbled_deepslate
fill 502 259 314 502 262 314 minecraft:deepslate_tiles
fill 503 259 313 503 262 313 minecraft:deepslate_tiles
setblock 504 259 276 minecraft:cobbled_deepslate
setblock 504 259 316 minecraft:cobbled_deepslate
fill 505 259 276 505 262 276 minecraft:deepslate_tiles
setblock 505 259 315 minecraft:cobbled_deepslate
fill 505 259 316 505 262 316 minecraft:deepslate_tiles
setblock 506 259 314 minecraft:cobbled_deepslate
fill 506 259 315 506 262 315 minecraft:deepslate_tiles
fill 507 259 314 507 261 314 minecraft:deepslate_tiles
setblock 508 259 278 minecraft:light[level=12]
setblock 508 259 285 minecraft:light[level=12]
setblock 508 259 292 minecraft:light[level=12]
setblock 508 259 299 minecraft:light[level=12]
setblock 508 259 306 minecraft:light[level=12]
setblock 508 259 313 minecraft:light[level=12]
setblock 509 259 316 minecraft:cobbled_deepslate
setblock 510 259 310 minecraft:cobbled_deepslate
setblock 510 259 311 minecraft:deepslate_tiles
fill 510 259 316 510 262 316 minecraft:deepslate_tiles
fill 511 259 290 511 262 290 minecraft:deepslate_tiles
setblock 511 259 294 minecraft:cobbled_deepslate
fill 511 259 295 511 262 295 minecraft:deepslate_tiles
fill 511 259 297 511 260 297 minecraft:deepslate_tiles
setblock 511 259 309 minecraft:cobbled_deepslate
fill 511 259 310 511 261 310 minecraft:deepslate_tiles
setblock 511 259 314 minecraft:cobbled_deepslate
fill 511 259 315 511 262 315 minecraft:deepslate_tiles
fill 512 259 316 512 308 316 minecraft:deepslate_tiles
setblock 471 260 288 minecraft:cobbled_deepslate
fill 471 260 289 471 260 292 minecraft:deepslate_tiles
setblock 471 260 293 minecraft:cobbled_deepslate
fill 471 260 294 472 262 294 minecraft:deepslate_tiles
setblock 471 260 298 minecraft:cobbled_deepslate
setblock 472 260 292 minecraft:cobbled_deepslate
fill 472 260 293 472 263 293 minecraft:deepslate_tiles
setblock 478 260 276 minecraft:cobbled_deepslate
setblock 478 260 316 minecraft:cobbled_deepslate
fill 479 260 276 482 260 276 minecraft:deepslate_tiles
fill 479 260 316 479 263 316 minecraft:deepslate_tiles
fill 480 260 277 481 260 277 minecraft:deepslate_tiles
fill 480 260 315 480 263 315 minecraft:deepslate_tiles
setblock 482 260 277 minecraft:cobbled_deepslate
setblock 483 260 276 minecraft:cobbled_deepslate
fill 483 260 277 483 263 277 minecraft:deepslate_tiles
setblock 483 260 316 minecraft:cobbled_deepslate
fill 484 260 276 484 263 276 minecraft:deepslate_tiles
setblock 484 260 315 minecraft:cobbled_deepslate
fill 484 260 316 484 263 316 minecraft:deepslate_tiles
fill 485 260 315 485 263 315 minecraft:deepslate_tiles
setblock 487 260 277 minecraft:cobbled_deepslate
setblock 488 260 276 minecraft:cobbled_deepslate
setblock 488 260 316 minecraft:cobbled_deepslate
fill 489 260 276 489 263 276 minecraft:deepslate_tiles
setblock 489 260 315 minecraft:cobbled_deepslate
fill 489 260 316 489 263 316 minecraft:deepslate_tiles
setblock 492 260 276 minecraft:deepslate_tiles
setblock 493 260 276 minecraft:cobbled_deepslate
setblock 493 260 316 minecraft:cobbled_deepslate
fill 494 260 276 497 260 276 minecraft:deepslate_tiles
setblock 494 260 315 minecraft:cobbled_deepslate
fill 494 260 316 494 263 316 minecraft:deepslate_tiles
fill 495 260 315 495 263 315 minecraft:deepslate_tiles
setblock 498 260 276 minecraft:cobbled_deepslate
setblock 498 260 316 minecraft:cobbled_deepslate
fill 499 260 276 499 263 276 minecraft:deepslate_tiles
setblock 499 260 315 minecraft:cobbled_deepslate
fill 499 260 316 499 263 316 minecraft:deepslate_tiles
setblock 500 260 314 minecraft:cobbled_deepslate
fill 500 260 315 500 263 315 minecraft:deepslate_tiles
setblock 501 260 313 minecraft:cobbled_deepslate
fill 501 260 314 501 263 314 minecraft:deepslate_tiles
fill 502 260 313 502 263 313 minecraft:deepslate_tiles
setblock 503 260 276 minecraft:cobbled_deepslate
setblock 503 260 316 minecraft:cobbled_deepslate
fill 504 260 276 504 263 276 minecraft:deepslate_tiles
fill 504 260 313 504 261 313 minecraft:deepslate_tiles
setblock 504 260 315 minecraft:cobbled_deepslate
fill 504 260 316 504 263 316 minecraft:deepslate_tiles
setblock 505 260 314 minecraft:cobbled_deepslate
fill 505 260 315 505 263 315 minecraft:deepslate_tiles
fill 506 260 314 506 263 314 minecraft:deepslate_tiles
setblock 508 260 316 minecraft:cobbled_deepslate
setblock 509 260 315 minecraft:cobbled_deepslate
fill 509 260 316 509 263 316 minecraft:deepslate_tiles
setblock 511 260 293 minecraft:cobbled_deepslate
fill 511 260 294 511 263 294 minecraft:deepslate_tiles
setblock 511 260 298 minecraft:cobbled_deepslate
setblock 511 260 309 minecraft:deepslate_tiles
setblock 511 260 313 minecraft:cobbled_deepslate
fill 511 260 314 511 263 314 minecraft:deepslate_tiles
fill 471 261 288 471 261 291 minecraft:deepslate_tiles
setblock 471 261 292 minecraft:cobbled_deepslate
fill 471 261 293 471 264 293 minecraft:deepslate_tiles
setblock 471 261 297 minecraft:cobbled_deepslate
fill 471 261 298 471 264 298 minecraft:deepslate_tiles
setblock 472 261 291 minecraft:cobbled_deepslate
fill 472 261 292 472 264 292 minecraft:deepslate_tiles
setblock 472 261 295 minecraft:deepslate_tiles
setblock 473 261 278 minecraft:light[level=13]
setblock 473 261 286 minecraft:light[level=13]
setblock 473 261 294 minecraft:light[level=13]
setblock 473 261 302 minecraft:light[level=13]
setblock 473 261 310 minecraft:light[level=13]
setblock 476 261 276 minecraft:deepslate_tiles
setblock 477 261 276 minecraft:cobbled_deepslate
setblock 477 261 316 minecraft:cobbled_deepslate
fill 478 261 276 481 261 276 minecraft:deepslate_tiles
fill 478 261 316 478 264 316 minecraft:deepslate_tiles
fill 479 261 277 480 261 277 minecraft:deepslate_tiles
fill 479 261 315 479 264 315 minecraft:deepslate_tiles
setblock 481 261 277 minecraft:cobbled_deepslate
setblock 481 261 278 minecraft:light[level=13]
setblock 481 261 286 minecraft:light[level=13]
setblock 481 261 294 minecraft:light[level=13]
setblock 481 261 302 minecraft:light[level=13]
setblock 481 261 310 minecraft:light[level=13]
setblock 482 261 276 minecraft:cobbled_deepslate
fill 482 261 277 482 264 277 minecraft:deepslate_tiles
setblock 482 261 316 minecraft:cobbled_deepslate
fill 483 261 276 483 264 276 minecraft:deepslate_tiles
setblock 483 261 315 minecraft:cobbled_deepslate
fill 483 261 316 483 264 316 minecraft:deepslate_tiles
fill 484 261 315 484 264 315 minecraft:deepslate_tiles
setblock 486 261 277 minecraft:cobbled_deepslate
setblock 487 261 276 minecraft:cobbled_deepslate
fill 487 261 277 488 263 277 minecraft:deepslate_tiles
setblock 487 261 316 minecraft:cobbled_deepslate
fill 488 261 276 488 264 276 minecraft:deepslate_tiles
setblock 488 261 315 minecraft:cobbled_deepslate
fill 488 261 316 488 264 316 minecraft:deepslate_tiles
setblock 489 261 278 minecraft:light[level=13]
setblock 489 261 286 minecraft:light[level=13]
setblock 489 261 294 minecraft:light[level=13]
setblock 489 261 302 minecraft:light[level=13]
setblock 489 261 310 minecraft:light[level=13]
fill 489 261 315 492 261 315 minecraft:deepslate_tiles
setblock 492 261 276 minecraft:cobbled_deepslate
setblock 492 261 316 minecraft:cobbled_deepslate
fill 493 261 276 496 261 276 minecraft:deepslate_tiles
setblock 493 261 315 minecraft:cobbled_deepslate
fill 493 261 316 493 264 316 minecraft:deepslate_tiles
fill 494 261 315 494 264 315 minecraft:deepslate_tiles
setblock 497 261 276 minecraft:cobbled_deepslate
setblock 497 261 278 minecraft:light[level=13]
setblock 497 261 286 minecraft:light[level=13]
setblock 497 261 294 minecraft:light[level=13]
setblock 497 261 302 minecraft:light[level=13]
setblock 497 261 310 minecraft:light[level=13]
fill 497 261 314 497 262 314 minecraft:deepslate_tiles
setblock 497 261 316 minecraft:cobbled_deepslate
fill 498 261 276 498 264 276 minecraft:deepslate_tiles
fill 498 261 280 498 263 280 minecraft:cobbled_deepslate
setblock 498 261 315 minecraft:cobbled_deepslate
fill 498 261 316 498 264 316 minecraft:deepslate_tiles
fill 499 261 279 499 263 279 minecraft:cobbled_deepslate
fill 499 261 281 499 263 281 minecraft:cobbled_deepslate
setblock 499 261 314 minecraft:cobbled_deepslate
fill 499 261 315 499 264 315 minecraft:deepslate_tiles
setblock 500 261 277 minecraft:deepslate_tiles
fill 500 261 280 500 263 280 minecraft:cobbled_deepslate
setblock 500 261 313 minecraft:cobbled_deepslate
fill 500 261 314 500 264 314 minecraft:deepslate_tiles
setblock 501 261 277 minecraft:cobbled_deepslate
fill 501 261 313 501 264 313 minecraft:deepslate_tiles
setblock 502 261 276 minecraft:cobbled_deepslate
setblock 502 261 315 minecraft:deepslate_tiles
setblock 502 261 316 minecraft:cobbled_deepslate
fill 503 261 276 503 264 276 minecraft:deepslate_tiles
setblock 503 261 314 minecraft:deepslate_tiles
setblock 503 261 315 minecraft:cobbled_deepslate
fill 503 261 316 503 264 316 minecraft:deepslate_tiles
setblock 504 261 314 minecraft:cobbled_deepslate
fill 504 261 315 504 264 315 minecraft:deepslate_tiles
setblock 505 261 278 minecraft:light[level=13]
setblock 505 261 286 minecraft:light[level=13]
setblock 505 261 294 minecraft:light[level=13]
setblock 505 261 302 minecraft:light[level=13]
setblock 505 261 310 minecraft:light[level=13]
fill 505 261 314 505 264 314 minecraft:deepslate_tiles
setblock 507 261 316 minecraft:cobbled_deepslate
setblock 508 261 315 minecraft:cobbled_deepslate
fill 508 261 316 508 264 316 minecraft:deepslate_tiles
setblock 509 261 315 minecraft:deepslate_tiles
setblock 511 261 292 minecraft:cobbled_deepslate
fill 511 261 293 511 264 293 minecraft:deepslate_tiles
setblock 511 261 297 minecraft:cobbled_deepslate
fill 511 261 298 511 263 299 minecraft:deepslate_tiles
setblock 511 261 312 minecraft:cobbled_deepslate
fill 511 261 313 511 264 313 minecraft:deepslate_tiles
setblock 511 261 316 minecraft:deepslate_tiles
fill 471 262 288 471 262 290 minecraft:deepslate_tiles
setblock 471 262 291 minecraft:cobbled_deepslate
fill 471 262 292 471 265 292 minecraft:deepslate_tiles
setblock 471 262 296 minecraft:cobbled_deepslate
fill 471 262 297 471 265 297 minecraft:deepslate_tiles
fill 471 262 299 471 263 299 minecraft:deepslate_tiles
setblock 472 262 290 minecraft:cobbled_deepslate
fill 472 262 291 472 265 291 minecraft:deepslate_tiles
setblock 472 262 295 minecraft:cobbled_deepslate
fill 472 262 296 472 265 296 minecraft:deepslate_tiles
setblock 475 262 276 minecraft:deepslate_tiles
setblock 475 262 316 minecraft:deepslate_tiles
setblock 476 262 276 minecraft:cobbled_deepslate
setblock 476 262 316 minecraft:cobbled_deepslate
fill 477 262 276 479 262 277 minecraft:deepslate_tiles
fill 477 262 316 477 265 316 minecraft:deepslate_tiles
fill 478 262 315 478 265 315 minecraft:deepslate_tiles
fill 478 262 317 478 272 317 minecraft:deepslate_tiles
setblock 479 262 317 minecraft:white_wool
setblock 480 262 276 minecraft:deepslate_tiles
setblock 480 262 277 minecraft:cobbled_deepslate
fill 480 262 278 483 262 278 minecraft:deepslate_tiles
setblock 481 262 276 minecraft:cobbled_deepslate
fill 481 262 277 481 265 277 minecraft:deepslate_tiles
setblock 481 262 316 minecraft:cobbled_deepslate
fill 482 262 276 482 265 276 minecraft:deepslate_tiles
setblock 482 262 314 minecraft:deepslate_tiles
setblock 482 262 315 minecraft:cobbled_deepslate
fill 482 262 316 482 265 316 minecraft:deepslate_tiles
setblock 483 262 314 minecraft:cobbled_deepslate
fill 483 262 315 483 265 315 minecraft:deepslate_tiles
setblock 484 262 278 minecraft:cobbled_deepslate
fill 484 262 314 484 264 314 minecraft:deepslate_tiles
setblock 485 262 277 minecraft:cobbled_deepslate
setblock 486 262 276 minecraft:cobbled_deepslate
fill 486 262 277 486 265 277 minecraft:deepslate_tiles
setblock 486 262 316 minecraft:cobbled_deepslate
fill 487 262 276 487 265 276 minecraft:deepslate_tiles
setblock 487 262 315 minecraft:cobbled_deepslate
fill 487 262 316 487 265 316 minecraft:deepslate_tiles
fill 488 262 315 491 262 315 minecraft:deepslate_tiles
setblock 491 262 276 minecraft:cobbled_deepslate
setblock 491 262 316 minecraft:cobbled_deepslate
fill 492 262 276 495 262 276 minecraft:deepslate_tiles
setblock 492 262 315 minecraft:cobbled_deepslate
fill 492 262 316 492 265 316 minecraft:deepslate_tiles
fill 493 262 315 493 265 315 minecraft:deepslate_tiles
setblock 496 262 276 minecraft:cobbled_deepslate
fill 496 262 314 496 263 314 minecraft:deepslate_tiles
setblock 496 262 316 minecraft:cobbled_deepslate
fill 497 262 276 497 264 277 minecraft:deepslate_tiles
setblock 497 262 315 minecraft:cobbled_deepslate
fill 497 262 316 497 265 316 minecraft:deepslate_tiles
fill 498 262 277 499 262 277 minecraft:deepslate_tiles
setblock 498 262 314 minecraft:cobbled_deepslate
fill 498 262 315 498 265 315 minecraft:deepslate_tiles
setblock 499 262 313 minecraft:cobbled_deepslate
fill 499 262 314 499 265 314 minecraft:deepslate_tiles
setblock 500 262 277 minecraft:cobbled_deepslate
fill 500 262 313 500 265 313 minecraft:deepslate_tiles
setblock 500 262 317 minecraft:white_wool
setblock 501 262 276 minecraft:cobbled_deepslate
fill 501 262 277 503 263 277 minecraft:deepslate_tiles
setblock 501 262 316 minecraft:cobbled_deepslate
fill 502 262 276 502 265 276 minecraft:deepslate_tiles
setblock 502 262 315 minecraft:cobbled_deepslate
fill 502 262 316 502 265 316 minecraft:deepslate_tiles
setblock 503 262 314 minecraft:cobbled_deepslate
fill 503 262 315 503 265 315 minecraft:deepslate_tiles
setblock 504 262 313 minecraft:cobbled_deepslate
fill 504 262 314 504 265 314 minecraft:deepslate_tiles
setblock 506 262 276 minecraft:cobbled_deepslate
setblock 506 262 316 minecraft:cobbled_deepslate
fill 507 262 276 507 265 276 minecraft:deepslate_tiles
setblock 507 262 315 minecraft:cobbled_deepslate
fill 507 262 316 507 265 316 minecraft:deepslate_tiles
fill 508 262 315 508 264 315 minecraft:deepslate_tiles
fill 510 262 293 510 262 296 minecraft:deepslate_tiles
setblock 510 262 297 minecraft:cobbled_deepslate
setblock 511 262 291 minecraft:cobbled_deepslate
fill 511 262 292 511 265 292 minecraft:deepslate_tiles
setblock 511 262 296 minecraft:cobbled_deepslate
fill 511 262 297 511 265 297 minecraft:deepslate_tiles
setblock 511 262 300 minecraft:deepslate_tiles
setblock 511 262 301 minecraft:cobbled_deepslate
setblock 511 262 311 minecraft:cobbled_deepslate
fill 511 262 312 511 264 312 minecraft:deepslate_tiles
setblock 511 262 316 minecraft:cobbled_deepslate
fill 470 263 298 470 294 304 minecraft:deepslate_tiles
setblock 470 263 305 minecraft:white_wool
fill 470 263 306 470 308 307 minecraft:deepslate_tiles
fill 471 263 288 471 263 289 minecraft:deepslate_tiles
setblock 471 263 290 minecraft:cobbled_deepslate
fill 471 263 291 471 266 291 minecraft:deepslate_tiles
setblock 471 263 294 minecraft:deepslate_tiles
setblock 471 263 295 minecraft:cobbled_deepslate
fill 471 263 296 471 266 296 minecraft:deepslate_tiles
setblock 471 263 300 minecraft:cobbled_deepslate
fill 472 263 290 472 266 290 minecraft:deepslate_tiles
setblock 472 263 294 minecraft:cobbled_deepslate
fill 472 263 295 472 266 295 minecraft:deepslate_tiles
fill 472 263 297 472 264 297 minecraft:deepslate_tiles
fill 473 263 276 474 263 276 minecraft:deepslate_tiles
setblock 474 263 316 minecraft:deepslate_tiles
setblock 475 263 276 minecraft:cobbled_deepslate
setblock 475 263 316 minecraft:cobbled_deepslate
fill 476 263 276 478 263 277 minecraft:deepslate_tiles
fill 476 263 316 476 266 316 minecraft:deepslate_tiles
fill 477 263 315 477 266 315 minecraft:deepslate_tiles
setblock 478 263 278 minecraft:cobbled_deepslate
setblock 479 263 276 minecraft:deepslate_tiles
setblock 479 263 277 minecraft:cobbled_deepslate
fill 479 263 278 482 263 278 minecraft:deepslate_tiles
fill 479 263 317 479 303 317 minecraft:deepslate_tiles
setblock 480 263 276 minecraft:cobbled_deepslate
fill 480 263 277 480 266 277 minecraft:deepslate_tiles
setblock 480 263 316 minecraft:cobbled_deepslate
fill 481 263 276 481 266 276 minecraft:deepslate_tiles
setblock 481 263 314 minecraft:deepslate_tiles
setblock 481 263 315 minecraft:cobbled_deepslate
fill 481 263 316 481 266 316 minecraft:deepslate_tiles
setblock 482 263 314 minecraft:cobbled_deepslate
fill 482 263 315 482 266 315 minecraft:deepslate_tiles
setblock 483 263 278 minecraft:cobbled_deepslate
fill 483 263 314 483 265 314 minecraft:deepslate_tiles
setblock 484 263 277 minecraft:cobbled_deepslate
fill 484 263 278 485 265 278 minecraft:deepslate_tiles
setblock 485 263 276 minecraft:cobbled_deepslate
fill 485 263 277 485 266 277 minecraft:deepslate_tiles
setblock 485 263 316 minecraft:cobbled_deepslate
fill 486 263 276 486 266 276 minecraft:deepslate_tiles
setblock 486 263 315 minecraft:cobbled_deepslate
fill 486 263 316 486 266 316 minecraft:deepslate_tiles
fill 487 263 315 490 263 315 minecraft:deepslate_tiles
setblock 489 263 277 minecraft:cobbled_deepslate
setblock 490 263 276 minecraft:cobbled_deepslate
fill 490 263 277 490 266 277 minecraft:deepslate_tiles
setblock 490 263 316 minecraft:cobbled_deepslate
fill 491 263 276 494 263 276 minecraft:deepslate_tiles
setblock 491 263 315 minecraft:cobbled_deepslate
fill 491 263 316 491 266 316 minecraft:deepslate_tiles
fill 492 263 315 492 266 315 minecraft:deepslate_tiles
setblock 494 263 277 minecraft:cobbled_deepslate
setblock 495 263 276 minecraft:cobbled_deepslate
fill 495 263 277 496 265 277 minecraft:deepslate_tiles
fill 495 263 314 495 264 314 minecraft:deepslate_tiles
setblock 495 263 316 minecraft:cobbled_deepslate
fill 496 263 276 496 266 276 minecraft:deepslate_tiles
setblock 496 263 315 minecraft:cobbled_deepslate
fill 496 263 316 496 266 316 minecraft:deepslate_tiles
setblock 497 263 314 minecraft:cobbled_deepslate
fill 497 263 315 497 266 315 minecraft:deepslate_tiles
setblock 498 263 277 minecraft:deepslate_tiles
setblock 498 263 313 minecraft:cobbled_deepslate
fill 498 263 314 498 266 314 minecraft:deepslate_tiles
setblock 499 263 277 minecraft:cobbled_deepslate
fill 499 263 313 499 266 313 minecraft:deepslate_tiles
setblock 500 263 276 minecraft:cobbled_deepslate
fill 500 263 277 500 266 277 minecraft:deepslate_tiles
setblock 500 263 316 minecraft:cobbled_deepslate
fill 500 263 317 500 308 317 minecraft:deepslate_tiles
fill 501 263 276 501 266 276 minecraft:deepslate_tiles
setblock 501 263 315 minecraft:cobbled_deepslate
fill 501 263 316 501 266 316 minecraft:deepslate_tiles
setblock 502 263 314 minecraft:cobbled_deepslate
fill 502 263 315 502 266 315 minecraft:deepslate_tiles
setblock 503 263 313 minecraft:cobbled_deepslate
fill 503 263 314 503 266 314 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_11 1t
