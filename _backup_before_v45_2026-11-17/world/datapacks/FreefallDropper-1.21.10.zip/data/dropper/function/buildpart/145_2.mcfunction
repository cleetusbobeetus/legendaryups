setblock 83 199 614 minecraft:sea_lantern
setblock 83 199 616 minecraft:sea_lantern
setblock 83 199 618 minecraft:sea_lantern
setblock 83 199 638 minecraft:sea_lantern
setblock 83 199 640 minecraft:sea_lantern
setblock 83 199 642 minecraft:sea_lantern
setblock 83 199 644 minecraft:sea_lantern
setblock 84 199 607 minecraft:sea_lantern
setblock 84 199 609 minecraft:sea_lantern
setblock 84 199 611 minecraft:sea_lantern
setblock 84 199 613 minecraft:sea_lantern
setblock 84 199 615 minecraft:sea_lantern
setblock 84 199 617 minecraft:sea_lantern
setblock 84 199 637 minecraft:sea_lantern
setblock 84 199 639 minecraft:sea_lantern
setblock 84 199 641 minecraft:sea_lantern
setblock 84 199 643 minecraft:sea_lantern
fill 84 199 644 84 218 644 minecraft:light_gray_concrete
setblock 84 199 645 minecraft:sea_lantern
setblock 85 199 606 minecraft:sea_lantern
setblock 85 199 608 minecraft:sea_lantern
setblock 85 199 610 minecraft:sea_lantern
setblock 85 199 612 minecraft:sea_lantern
setblock 85 199 614 minecraft:sea_lantern
setblock 85 199 616 minecraft:sea_lantern
setblock 85 199 618 minecraft:sea_lantern
setblock 86 199 607 minecraft:sea_lantern
setblock 86 199 609 minecraft:sea_lantern
setblock 86 199 611 minecraft:sea_lantern
setblock 86 199 613 minecraft:sea_lantern
setblock 86 199 615 minecraft:sea_lantern
setblock 86 199 617 minecraft:sea_lantern
setblock 87 199 606 minecraft:sea_lantern
setblock 87 199 608 minecraft:sea_lantern
setblock 87 199 610 minecraft:sea_lantern
setblock 87 199 612 minecraft:sea_lantern
setblock 87 199 614 minecraft:sea_lantern
setblock 87 199 616 minecraft:sea_lantern
setblock 87 199 618 minecraft:sea_lantern
setblock 88 199 607 minecraft:sea_lantern
setblock 88 199 609 minecraft:sea_lantern
setblock 88 199 611 minecraft:sea_lantern
setblock 88 199 613 minecraft:sea_lantern
setblock 88 199 615 minecraft:sea_lantern
setblock 88 199 617 minecraft:sea_lantern
fill 47 200 609 47 205 609 minecraft:sea_lantern
fill 47 200 617 47 205 617 minecraft:sea_lantern
fill 47 200 625 47 205 625 minecraft:sea_lantern
fill 47 200 633 47 205 633 minecraft:sea_lantern
fill 47 200 641 47 205 641 minecraft:sea_lantern
fill 50 200 646 50 205 646 minecraft:sea_lantern
fill 54 200 604 54 205 604 minecraft:sea_lantern
fill 58 200 646 58 205 646 minecraft:sea_lantern
fill 62 200 604 62 205 604 minecraft:sea_lantern
fill 66 200 646 66 205 646 minecraft:sea_lantern
fill 70 200 604 70 205 604 minecraft:sea_lantern
fill 74 200 637 74 201 637 minecraft:light_gray_concrete
fill 74 200 639 74 201 639 minecraft:light_gray_concrete
fill 74 200 641 74 201 641 minecraft:light_gray_concrete
fill 74 200 643 74 201 643 minecraft:light_gray_concrete
fill 74 200 645 74 201 645 minecraft:light_gray_concrete
fill 74 200 646 74 205 646 minecraft:sea_lantern
fill 75 200 638 75 201 638 minecraft:light_gray_concrete
fill 75 200 640 75 201 640 minecraft:light_gray_concrete
fill 75 200 642 75 201 642 minecraft:light_gray_concrete
fill 75 200 644 75 201 644 minecraft:light_gray_concrete
fill 76 200 637 76 201 637 minecraft:light_gray_concrete
fill 76 200 639 76 201 639 minecraft:light_gray_concrete
fill 76 200 641 76 201 641 minecraft:light_gray_concrete
fill 76 200 643 76 201 643 minecraft:light_gray_concrete
fill 76 200 645 76 201 645 minecraft:light_gray_concrete
fill 77 200 638 77 201 638 minecraft:light_gray_concrete
fill 77 200 640 77 201 640 minecraft:light_gray_concrete
fill 77 200 642 77 201 642 minecraft:light_gray_concrete
fill 77 200 644 77 201 644 minecraft:light_gray_concrete
fill 78 200 604 78 205 604 minecraft:sea_lantern
fill 78 200 637 78 201 637 minecraft:light_gray_concrete
fill 78 200 639 78 201 639 minecraft:light_gray_concrete
fill 78 200 641 78 201 641 minecraft:light_gray_concrete
fill 78 200 643 78 201 643 minecraft:light_gray_concrete
fill 78 200 645 78 201 645 minecraft:light_gray_concrete
fill 79 200 638 79 201 638 minecraft:light_gray_concrete
fill 79 200 640 79 201 640 minecraft:light_gray_concrete
fill 79 200 642 79 201 642 minecraft:light_gray_concrete
fill 79 200 644 79 201 644 minecraft:light_gray_concrete
fill 80 200 637 80 201 637 minecraft:light_gray_concrete
fill 80 200 639 80 201 639 minecraft:light_gray_concrete
fill 80 200 641 80 201 641 minecraft:light_gray_concrete
fill 80 200 643 80 201 643 minecraft:light_gray_concrete
fill 80 200 645 80 201 645 minecraft:light_gray_concrete
fill 81 200 638 81 201 638 minecraft:light_gray_concrete
fill 81 200 640 81 201 640 minecraft:light_gray_concrete
fill 81 200 642 81 201 642 minecraft:light_gray_concrete
fill 81 200 644 81 201 644 minecraft:light_gray_concrete
fill 82 200 637 82 201 637 minecraft:light_gray_concrete
fill 82 200 639 82 201 639 minecraft:light_gray_concrete
fill 82 200 641 82 201 641 minecraft:light_gray_concrete
fill 82 200 643 82 201 643 minecraft:light_gray_concrete
fill 82 200 645 82 201 645 minecraft:light_gray_concrete
fill 82 200 646 82 205 646 minecraft:sea_lantern
fill 83 200 606 83 201 606 minecraft:light_gray_concrete
fill 83 200 608 83 201 608 minecraft:light_gray_concrete
fill 83 200 610 83 201 610 minecraft:light_gray_concrete
fill 83 200 612 83 201 612 minecraft:light_gray_concrete
fill 83 200 614 83 201 614 minecraft:light_gray_concrete
fill 83 200 616 83 201 616 minecraft:light_gray_concrete
fill 83 200 618 83 201 618 minecraft:light_gray_concrete
fill 83 200 638 83 201 638 minecraft:light_gray_concrete
fill 83 200 640 83 201 640 minecraft:light_gray_concrete
fill 83 200 642 83 201 642 minecraft:light_gray_concrete
fill 83 200 644 83 201 644 minecraft:light_gray_concrete
fill 84 200 607 84 201 607 minecraft:light_gray_concrete
fill 84 200 609 84 201 609 minecraft:light_gray_concrete
fill 84 200 611 84 201 611 minecraft:light_gray_concrete
fill 84 200 613 84 201 613 minecraft:light_gray_concrete
fill 84 200 615 84 201 615 minecraft:light_gray_concrete
fill 84 200 617 84 201 617 minecraft:light_gray_concrete
fill 84 200 637 84 201 637 minecraft:light_gray_concrete
fill 84 200 639 84 201 639 minecraft:light_gray_concrete
fill 84 200 641 84 201 641 minecraft:light_gray_concrete
fill 84 200 643 84 201 643 minecraft:light_gray_concrete
fill 84 200 645 84 201 645 minecraft:light_gray_concrete
fill 85 200 606 85 201 606 minecraft:light_gray_concrete
fill 85 200 608 85 201 608 minecraft:light_gray_concrete
fill 85 200 610 85 201 610 minecraft:light_gray_concrete
fill 85 200 612 85 201 612 minecraft:light_gray_concrete
fill 85 200 614 85 201 614 minecraft:light_gray_concrete
fill 85 200 616 85 201 616 minecraft:light_gray_concrete
fill 85 200 618 85 201 618 minecraft:light_gray_concrete
fill 86 200 604 86 205 604 minecraft:sea_lantern
fill 86 200 607 86 201 607 minecraft:light_gray_concrete
fill 86 200 609 86 201 609 minecraft:light_gray_concrete
fill 86 200 611 86 201 611 minecraft:light_gray_concrete
fill 86 200 613 86 201 613 minecraft:light_gray_concrete
fill 86 200 615 86 201 615 minecraft:light_gray_concrete
fill 86 200 617 86 201 617 minecraft:light_gray_concrete
fill 87 200 606 87 201 606 minecraft:light_gray_concrete
fill 87 200 608 87 201 608 minecraft:light_gray_concrete
fill 87 200 610 87 201 610 minecraft:light_gray_concrete
fill 87 200 612 87 201 612 minecraft:light_gray_concrete
fill 87 200 614 87 201 614 minecraft:light_gray_concrete
fill 87 200 616 87 201 616 minecraft:light_gray_concrete
fill 87 200 618 87 201 618 minecraft:light_gray_concrete
fill 88 200 607 88 201 607 minecraft:light_gray_concrete
fill 88 200 609 88 201 609 minecraft:light_gray_concrete
fill 88 200 611 88 201 611 minecraft:light_gray_concrete
fill 88 200 613 88 201 613 minecraft:light_gray_concrete
fill 88 200 615 88 201 615 minecraft:light_gray_concrete
fill 88 200 617 88 201 617 minecraft:light_gray_concrete
fill 89 200 609 89 205 609 minecraft:sea_lantern
fill 89 200 617 89 205 617 minecraft:sea_lantern
fill 89 200 625 89 205 625 minecraft:sea_lantern
fill 89 200 633 89 205 633 minecraft:sea_lantern
fill 89 200 641 89 205 641 minecraft:sea_lantern
fill 72 202 615 73 203 616 minecraft:magenta_concrete
setblock 74 202 637 minecraft:sea_lantern
setblock 74 202 639 minecraft:sea_lantern
setblock 74 202 641 minecraft:sea_lantern
setblock 74 202 643 minecraft:sea_lantern
setblock 74 202 645 minecraft:sea_lantern
setblock 75 202 638 minecraft:sea_lantern
setblock 75 202 640 minecraft:sea_lantern
setblock 75 202 642 minecraft:sea_lantern
setblock 75 202 644 minecraft:sea_lantern
setblock 76 202 637 minecraft:sea_lantern
setblock 76 202 639 minecraft:sea_lantern
setblock 76 202 641 minecraft:sea_lantern
setblock 76 202 643 minecraft:sea_lantern
setblock 76 202 645 minecraft:sea_lantern
setblock 77 202 638 minecraft:sea_lantern
setblock 77 202 640 minecraft:sea_lantern
setblock 77 202 642 minecraft:sea_lantern
setblock 77 202 644 minecraft:sea_lantern
setblock 78 202 637 minecraft:sea_lantern
setblock 78 202 639 minecraft:sea_lantern
setblock 78 202 641 minecraft:sea_lantern
setblock 78 202 643 minecraft:sea_lantern
setblock 78 202 645 minecraft:sea_lantern
setblock 79 202 638 minecraft:sea_lantern
setblock 79 202 640 minecraft:sea_lantern
setblock 79 202 642 minecraft:sea_lantern
setblock 79 202 644 minecraft:sea_lantern
setblock 80 202 637 minecraft:sea_lantern
setblock 80 202 639 minecraft:sea_lantern
setblock 80 202 641 minecraft:sea_lantern
setblock 80 202 643 minecraft:sea_lantern
setblock 80 202 645 minecraft:sea_lantern
setblock 81 202 638 minecraft:sea_lantern
setblock 81 202 640 minecraft:sea_lantern
setblock 81 202 642 minecraft:sea_lantern
setblock 81 202 644 minecraft:sea_lantern
setblock 82 202 637 minecraft:sea_lantern
setblock 82 202 639 minecraft:sea_lantern
setblock 82 202 641 minecraft:sea_lantern
setblock 82 202 643 minecraft:sea_lantern
setblock 82 202 645 minecraft:sea_lantern
setblock 83 202 606 minecraft:sea_lantern
setblock 83 202 608 minecraft:sea_lantern
setblock 83 202 610 minecraft:sea_lantern
setblock 83 202 612 minecraft:sea_lantern
setblock 83 202 614 minecraft:sea_lantern
setblock 83 202 616 minecraft:sea_lantern
setblock 83 202 618 minecraft:sea_lantern
setblock 83 202 638 minecraft:sea_lantern
setblock 83 202 640 minecraft:sea_lantern
setblock 83 202 642 minecraft:sea_lantern
setblock 83 202 644 minecraft:sea_lantern
setblock 84 202 607 minecraft:sea_lantern
setblock 84 202 609 minecraft:sea_lantern
setblock 84 202 611 minecraft:sea_lantern
setblock 84 202 613 minecraft:sea_lantern
setblock 84 202 615 minecraft:sea_lantern
setblock 84 202 617 minecraft:sea_lantern
setblock 84 202 637 minecraft:sea_lantern
setblock 84 202 639 minecraft:sea_lantern
setblock 84 202 641 minecraft:sea_lantern
setblock 84 202 643 minecraft:sea_lantern
setblock 84 202 645 minecraft:sea_lantern
setblock 85 202 606 minecraft:sea_lantern
setblock 85 202 608 minecraft:sea_lantern
setblock 85 202 610 minecraft:sea_lantern
setblock 85 202 612 minecraft:sea_lantern
setblock 85 202 614 minecraft:sea_lantern
setblock 85 202 616 minecraft:sea_lantern
setblock 85 202 618 minecraft:sea_lantern
setblock 86 202 607 minecraft:sea_lantern
setblock 86 202 609 minecraft:sea_lantern
setblock 86 202 611 minecraft:sea_lantern
setblock 86 202 613 minecraft:sea_lantern
setblock 86 202 615 minecraft:sea_lantern
setblock 86 202 617 minecraft:sea_lantern
setblock 87 202 606 minecraft:sea_lantern
setblock 87 202 608 minecraft:sea_lantern
setblock 87 202 610 minecraft:sea_lantern
setblock 87 202 612 minecraft:sea_lantern
setblock 87 202 614 minecraft:sea_lantern
setblock 87 202 616 minecraft:sea_lantern
setblock 87 202 618 minecraft:sea_lantern
setblock 88 202 607 minecraft:sea_lantern
setblock 88 202 609 minecraft:sea_lantern
setblock 88 202 611 minecraft:sea_lantern
setblock 88 202 613 minecraft:sea_lantern
setblock 88 202 615 minecraft:sea_lantern
setblock 88 202 617 minecraft:sea_lantern
setblock 50 203 607 minecraft:light[level=14]
setblock 50 203 615 minecraft:light[level=14]
setblock 50 203 623 minecraft:light[level=14]
setblock 50 203 631 minecraft:light[level=14]
setblock 50 203 639 minecraft:light[level=14]
setblock 58 203 607 minecraft:light[level=14]
setblock 58 203 615 minecraft:light[level=14]
setblock 58 203 623 minecraft:light[level=14]
setblock 58 203 631 minecraft:light[level=14]
setblock 58 203 639 minecraft:light[level=14]
setblock 66 203 615 minecraft:light[level=14]
setblock 66 203 623 minecraft:light[level=14]
setblock 66 203 631 minecraft:light[level=14]
setblock 66 203 639 minecraft:light[level=14]
fill 68 203 614 69 204 614 minecraft:glass
setblock 74 203 615 minecraft:light[level=14]
setblock 74 203 623 minecraft:light[level=14]
setblock 74 203 631 minecraft:light[level=14]
fill 74 203 637 74 204 637 minecraft:light_gray_concrete
fill 74 203 639 74 204 639 minecraft:light_gray_concrete
fill 74 203 641 74 204 641 minecraft:light_gray_concrete
fill 74 203 643 74 204 643 minecraft:light_gray_concrete
fill 74 203 645 74 204 645 minecraft:light_gray_concrete
fill 75 203 638 75 204 638 minecraft:light_gray_concrete
fill 75 203 640 75 204 640 minecraft:light_gray_concrete
fill 75 203 642 75 204 642 minecraft:light_gray_concrete
fill 75 203 644 75 204 644 minecraft:light_gray_concrete
fill 76 203 637 76 204 637 minecraft:light_gray_concrete
fill 76 203 639 76 204 639 minecraft:light_gray_concrete
fill 76 203 641 76 204 641 minecraft:light_gray_concrete
fill 76 203 643 76 204 643 minecraft:light_gray_concrete
fill 76 203 645 76 204 645 minecraft:light_gray_concrete
fill 77 203 638 77 204 638 minecraft:light_gray_concrete
fill 77 203 640 77 204 640 minecraft:light_gray_concrete
fill 77 203 642 77 204 642 minecraft:light_gray_concrete
fill 77 203 644 77 204 644 minecraft:light_gray_concrete
fill 78 203 637 78 204 637 minecraft:light_gray_concrete
fill 78 203 639 78 204 639 minecraft:light_gray_concrete
fill 78 203 641 78 204 641 minecraft:light_gray_concrete
fill 78 203 643 78 204 643 minecraft:light_gray_concrete
fill 78 203 645 78 204 645 minecraft:light_gray_concrete
fill 79 203 638 79 204 638 minecraft:light_gray_concrete
fill 79 203 640 79 204 640 minecraft:light_gray_concrete
fill 79 203 642 79 204 642 minecraft:light_gray_concrete
fill 79 203 644 79 204 644 minecraft:light_gray_concrete
fill 80 203 637 80 204 637 minecraft:light_gray_concrete
fill 80 203 639 80 204 639 minecraft:light_gray_concrete
fill 80 203 641 80 204 641 minecraft:light_gray_concrete
fill 80 203 643 80 204 643 minecraft:light_gray_concrete
fill 80 203 645 80 204 645 minecraft:light_gray_concrete
fill 81 203 638 81 204 638 minecraft:light_gray_concrete
fill 81 203 640 81 204 640 minecraft:light_gray_concrete
fill 81 203 642 81 204 642 minecraft:light_gray_concrete
fill 81 203 644 81 204 644 minecraft:light_gray_concrete
setblock 82 203 607 minecraft:light[level=14]
setblock 82 203 615 minecraft:light[level=14]
setblock 82 203 623 minecraft:light[level=14]
setblock 82 203 631 minecraft:light[level=14]
fill 82 203 637 82 204 637 minecraft:light_gray_concrete
fill 82 203 639 82 204 639 minecraft:light_gray_concrete
fill 82 203 641 82 204 641 minecraft:light_gray_concrete
fill 82 203 643 82 204 643 minecraft:light_gray_concrete
fill 82 203 645 82 204 645 minecraft:light_gray_concrete
fill 83 203 606 83 204 606 minecraft:light_gray_concrete
fill 83 203 608 83 204 608 minecraft:light_gray_concrete
fill 83 203 610 83 204 610 minecraft:light_gray_concrete
fill 83 203 612 83 204 612 minecraft:light_gray_concrete
fill 83 203 614 83 204 614 minecraft:light_gray_concrete
fill 83 203 616 83 204 616 minecraft:light_gray_concrete
fill 83 203 618 83 204 618 minecraft:light_gray_concrete
fill 83 203 638 83 204 638 minecraft:light_gray_concrete
fill 83 203 640 83 204 640 minecraft:light_gray_concrete
fill 83 203 642 83 204 642 minecraft:light_gray_concrete
fill 83 203 644 83 204 644 minecraft:light_gray_concrete
fill 84 203 607 84 204 607 minecraft:light_gray_concrete
fill 84 203 609 84 204 609 minecraft:light_gray_concrete
fill 84 203 611 84 204 611 minecraft:light_gray_concrete
fill 84 203 613 84 204 613 minecraft:light_gray_concrete
fill 84 203 615 84 204 615 minecraft:light_gray_concrete
fill 84 203 617 84 204 617 minecraft:light_gray_concrete
fill 84 203 637 84 204 637 minecraft:light_gray_concrete
fill 84 203 639 84 204 639 minecraft:light_gray_concrete
fill 84 203 641 84 204 641 minecraft:light_gray_concrete
fill 84 203 643 84 204 643 minecraft:light_gray_concrete
fill 84 203 645 84 204 645 minecraft:light_gray_concrete
fill 85 203 606 85 204 606 minecraft:light_gray_concrete
fill 85 203 608 85 204 608 minecraft:light_gray_concrete
fill 85 203 610 85 204 610 minecraft:light_gray_concrete
fill 85 203 612 85 204 612 minecraft:light_gray_concrete
fill 85 203 614 85 204 614 minecraft:light_gray_concrete
fill 85 203 616 85 204 616 minecraft:light_gray_concrete
fill 85 203 618 85 204 618 minecraft:light_gray_concrete
fill 86 203 607 86 204 607 minecraft:light_gray_concrete
fill 86 203 609 86 204 609 minecraft:light_gray_concrete
fill 86 203 611 86 204 611 minecraft:light_gray_concrete
fill 86 203 613 86 204 613 minecraft:light_gray_concrete
fill 86 203 615 86 204 615 minecraft:light_gray_concrete
fill 86 203 617 86 204 617 minecraft:light_gray_concrete
fill 87 203 606 87 204 606 minecraft:light_gray_concrete
fill 87 203 608 87 204 608 minecraft:light_gray_concrete
fill 87 203 610 87 204 610 minecraft:light_gray_concrete
fill 87 203 612 87 204 612 minecraft:light_gray_concrete
fill 87 203 614 87 204 614 minecraft:light_gray_concrete
fill 87 203 616 87 204 616 minecraft:light_gray_concrete
fill 87 203 618 87 204 618 minecraft:light_gray_concrete
fill 88 203 607 88 204 607 minecraft:light_gray_concrete
fill 88 203 609 88 204 609 minecraft:light_gray_concrete
fill 88 203 611 88 204 611 minecraft:light_gray_concrete
fill 88 203 613 88 204 613 minecraft:light_gray_concrete
fill 88 203 615 88 204 615 minecraft:light_gray_concrete
fill 88 203 617 88 204 617 minecraft:light_gray_concrete
fill 57 204 643 57 209 643 minecraft:magenta_concrete
fill 52 205 618 52 210 618 minecraft:magenta_concrete
setblock 74 205 637 minecraft:sea_lantern
setblock 74 205 639 minecraft:sea_lantern
setblock 74 205 641 minecraft:sea_lantern
setblock 74 205 643 minecraft:sea_lantern
setblock 74 205 645 minecraft:sea_lantern
setblock 75 205 638 minecraft:sea_lantern
setblock 75 205 640 minecraft:sea_lantern
setblock 75 205 642 minecraft:sea_lantern
setblock 75 205 644 minecraft:sea_lantern
setblock 76 205 637 minecraft:sea_lantern
setblock 76 205 639 minecraft:sea_lantern
setblock 76 205 641 minecraft:sea_lantern
setblock 76 205 643 minecraft:sea_lantern
setblock 76 205 645 minecraft:sea_lantern
setblock 77 205 638 minecraft:sea_lantern
setblock 77 205 640 minecraft:sea_lantern
setblock 77 205 642 minecraft:sea_lantern
setblock 77 205 644 minecraft:sea_lantern
setblock 78 205 637 minecraft:sea_lantern
setblock 78 205 639 minecraft:sea_lantern
setblock 78 205 641 minecraft:sea_lantern
setblock 78 205 643 minecraft:sea_lantern
setblock 78 205 645 minecraft:sea_lantern
setblock 79 205 638 minecraft:sea_lantern
setblock 79 205 640 minecraft:sea_lantern
setblock 79 205 642 minecraft:sea_lantern
setblock 79 205 644 minecraft:sea_lantern
setblock 80 205 637 minecraft:sea_lantern
setblock 80 205 639 minecraft:sea_lantern
setblock 80 205 641 minecraft:sea_lantern
setblock 80 205 643 minecraft:sea_lantern
setblock 80 205 645 minecraft:sea_lantern
setblock 81 205 638 minecraft:sea_lantern
setblock 81 205 640 minecraft:sea_lantern
setblock 81 205 642 minecraft:sea_lantern
setblock 81 205 644 minecraft:sea_lantern
setblock 82 205 637 minecraft:sea_lantern
setblock 82 205 639 minecraft:sea_lantern
setblock 82 205 641 minecraft:sea_lantern
setblock 82 205 643 minecraft:sea_lantern
setblock 82 205 645 minecraft:sea_lantern
setblock 83 205 606 minecraft:sea_lantern
setblock 83 205 608 minecraft:sea_lantern
setblock 83 205 610 minecraft:sea_lantern
setblock 83 205 612 minecraft:sea_lantern
setblock 83 205 614 minecraft:sea_lantern
setblock 83 205 616 minecraft:sea_lantern
setblock 83 205 618 minecraft:sea_lantern
setblock 83 205 638 minecraft:sea_lantern
setblock 83 205 640 minecraft:sea_lantern
setblock 83 205 642 minecraft:sea_lantern
setblock 83 205 644 minecraft:sea_lantern
setblock 84 205 607 minecraft:sea_lantern
setblock 84 205 609 minecraft:sea_lantern
setblock 84 205 611 minecraft:sea_lantern
setblock 84 205 613 minecraft:sea_lantern
setblock 84 205 615 minecraft:sea_lantern
setblock 84 205 617 minecraft:sea_lantern
setblock 84 205 637 minecraft:sea_lantern
setblock 84 205 639 minecraft:sea_lantern
setblock 84 205 641 minecraft:sea_lantern
setblock 84 205 643 minecraft:sea_lantern
setblock 84 205 645 minecraft:sea_lantern
setblock 85 205 606 minecraft:sea_lantern
setblock 85 205 608 minecraft:sea_lantern
setblock 85 205 610 minecraft:sea_lantern
setblock 85 205 612 minecraft:sea_lantern
setblock 85 205 614 minecraft:sea_lantern
setblock 85 205 616 minecraft:sea_lantern
setblock 85 205 618 minecraft:sea_lantern
setblock 86 205 607 minecraft:sea_lantern
setblock 86 205 609 minecraft:sea_lantern
setblock 86 205 611 minecraft:sea_lantern
setblock 86 205 613 minecraft:sea_lantern
setblock 86 205 615 minecraft:sea_lantern
setblock 86 205 617 minecraft:sea_lantern
setblock 87 205 606 minecraft:sea_lantern
setblock 87 205 608 minecraft:sea_lantern
setblock 87 205 610 minecraft:sea_lantern
setblock 87 205 612 minecraft:sea_lantern
setblock 87 205 614 minecraft:sea_lantern
setblock 87 205 616 minecraft:sea_lantern
setblock 87 205 618 minecraft:sea_lantern
setblock 88 205 607 minecraft:sea_lantern
setblock 88 205 609 minecraft:sea_lantern
setblock 88 205 611 minecraft:sea_lantern
setblock 88 205 613 minecraft:sea_lantern
setblock 88 205 615 minecraft:sea_lantern
setblock 88 205 617 minecraft:sea_lantern
fill 47 206 609 47 213 609 minecraft:black_concrete
fill 47 206 617 47 213 617 minecraft:black_concrete
fill 47 206 625 47 213 625 minecraft:black_concrete
fill 47 206 633 47 213 633 minecraft:black_concrete
fill 47 206 641 47 213 641 minecraft:black_concrete
fill 50 206 646 50 213 646 minecraft:black_concrete
fill 51 206 618 51 210 618 minecraft:magenta_concrete
fill 54 206 604 54 213 604 minecraft:black_concrete
fill 56 206 610 57 207 611 minecraft:magenta_concrete
fill 57 206 642 57 209 642 minecraft:magenta_concrete
fill 58 206 646 58 213 646 minecraft:black_concrete
fill 62 206 604 62 213 604 minecraft:black_concrete
fill 66 206 646 66 213 646 minecraft:black_concrete
fill 70 206 604 70 213 604 minecraft:black_concrete
fill 74 206 637 74 207 637 minecraft:light_gray_concrete
fill 74 206 639 74 207 639 minecraft:light_gray_concrete
fill 74 206 641 74 207 641 minecraft:light_gray_concrete
fill 74 206 643 74 207 643 minecraft:light_gray_concrete
fill 74 206 645 74 207 645 minecraft:light_gray_concrete
fill 74 206 646 74 213 646 minecraft:black_concrete
fill 75 206 638 75 207 638 minecraft:light_gray_concrete
fill 75 206 640 75 207 640 minecraft:light_gray_concrete
fill 75 206 642 75 207 642 minecraft:light_gray_concrete
fill 75 206 644 75 207 644 minecraft:light_gray_concrete
fill 76 206 637 76 207 637 minecraft:light_gray_concrete
fill 76 206 639 76 207 639 minecraft:light_gray_concrete
fill 76 206 641 76 207 641 minecraft:light_gray_concrete
fill 76 206 643 76 207 643 minecraft:light_gray_concrete
fill 76 206 645 76 207 645 minecraft:light_gray_concrete
fill 77 206 638 77 207 638 minecraft:light_gray_concrete
fill 77 206 640 77 207 640 minecraft:light_gray_concrete
fill 77 206 642 77 207 642 minecraft:light_gray_concrete
fill 77 206 644 77 207 644 minecraft:light_gray_concrete
fill 78 206 604 78 213 604 minecraft:black_concrete
fill 78 206 637 78 207 637 minecraft:light_gray_concrete
fill 78 206 639 78 207 639 minecraft:light_gray_concrete
fill 78 206 641 78 207 641 minecraft:light_gray_concrete
fill 78 206 643 78 207 643 minecraft:light_gray_concrete
fill 78 206 645 78 207 645 minecraft:light_gray_concrete
fill 79 206 638 79 207 638 minecraft:light_gray_concrete
fill 79 206 640 79 207 640 minecraft:light_gray_concrete
fill 79 206 642 79 207 642 minecraft:light_gray_concrete
fill 79 206 644 79 207 644 minecraft:light_gray_concrete
fill 80 206 637 80 207 637 minecraft:light_gray_concrete
fill 80 206 639 80 207 639 minecraft:light_gray_concrete
fill 80 206 641 80 207 641 minecraft:light_gray_concrete
fill 80 206 643 80 207 643 minecraft:light_gray_concrete
fill 80 206 645 80 207 645 minecraft:light_gray_concrete
fill 81 206 638 81 207 638 minecraft:light_gray_concrete
fill 81 206 640 81 207 640 minecraft:light_gray_concrete
fill 81 206 642 81 207 642 minecraft:light_gray_concrete
fill 81 206 644 81 207 644 minecraft:light_gray_concrete
fill 82 206 637 82 207 637 minecraft:light_gray_concrete
fill 82 206 639 82 207 639 minecraft:light_gray_concrete
fill 82 206 641 82 207 641 minecraft:light_gray_concrete
fill 82 206 643 82 207 643 minecraft:light_gray_concrete
fill 82 206 645 82 207 645 minecraft:light_gray_concrete
fill 82 206 646 82 213 646 minecraft:black_concrete
fill 83 206 606 83 208 606 minecraft:light_gray_concrete
fill 83 206 608 83 208 608 minecraft:light_gray_concrete
fill 83 206 610 83 208 610 minecraft:light_gray_concrete
fill 83 206 612 83 208 612 minecraft:light_gray_concrete
fill 83 206 614 83 208 614 minecraft:light_gray_concrete
fill 83 206 616 83 208 616 minecraft:light_gray_concrete
fill 83 206 618 83 208 618 minecraft:light_gray_concrete
fill 83 206 638 83 207 638 minecraft:light_gray_concrete
fill 83 206 640 83 207 640 minecraft:light_gray_concrete
fill 83 206 642 83 207 642 minecraft:light_gray_concrete
fill 83 206 644 83 207 644 minecraft:light_gray_concrete
fill 84 206 607 84 208 607 minecraft:light_gray_concrete
fill 84 206 609 84 208 609 minecraft:light_gray_concrete
fill 84 206 611 84 208 611 minecraft:light_gray_concrete
fill 84 206 613 84 208 613 minecraft:light_gray_concrete
fill 84 206 615 84 208 615 minecraft:light_gray_concrete
fill 84 206 617 84 208 617 minecraft:light_gray_concrete
fill 84 206 637 84 207 637 minecraft:light_gray_concrete
fill 84 206 639 84 207 639 minecraft:light_gray_concrete
fill 84 206 641 84 207 641 minecraft:light_gray_concrete
fill 84 206 643 84 207 643 minecraft:light_gray_concrete
fill 84 206 645 84 207 645 minecraft:light_gray_concrete
fill 85 206 606 85 208 606 minecraft:light_gray_concrete
fill 85 206 608 85 208 608 minecraft:light_gray_concrete
fill 85 206 610 85 208 610 minecraft:light_gray_concrete
fill 85 206 612 85 208 612 minecraft:light_gray_concrete
fill 85 206 614 85 208 614 minecraft:light_gray_concrete
fill 85 206 616 85 208 616 minecraft:light_gray_concrete
fill 85 206 618 85 208 618 minecraft:light_gray_concrete
fill 86 206 604 86 213 604 minecraft:black_concrete
fill 86 206 607 86 208 607 minecraft:light_gray_concrete
fill 86 206 609 86 208 609 minecraft:light_gray_concrete
fill 86 206 611 86 208 611 minecraft:light_gray_concrete
fill 86 206 613 86 208 613 minecraft:light_gray_concrete
fill 86 206 615 86 208 615 minecraft:light_gray_concrete
fill 86 206 617 86 208 617 minecraft:light_gray_concrete
fill 87 206 606 87 208 606 minecraft:light_gray_concrete
fill 87 206 608 87 208 608 minecraft:light_gray_concrete
fill 87 206 610 87 208 610 minecraft:light_gray_concrete
fill 87 206 612 87 208 612 minecraft:light_gray_concrete
fill 87 206 614 87 208 614 minecraft:light_gray_concrete
fill 87 206 616 87 208 616 minecraft:light_gray_concrete
fill 87 206 618 87 208 618 minecraft:light_gray_concrete
fill 88 206 607 88 235 607 minecraft:light_gray_concrete
fill 88 206 609 88 208 609 minecraft:light_gray_concrete
fill 88 206 611 88 208 611 minecraft:light_gray_concrete
fill 88 206 613 88 208 613 minecraft:light_gray_concrete
fill 88 206 615 88 235 615 minecraft:light_gray_concrete
fill 88 206 617 88 208 617 minecraft:light_gray_concrete
fill 89 206 609 89 213 609 minecraft:black_concrete
fill 89 206 617 89 213 617 minecraft:black_concrete
fill 89 206 625 89 213 625 minecraft:black_concrete
fill 89 206 633 89 213 633 minecraft:black_concrete
fill 89 206 641 89 213 641 minecraft:black_concrete
fill 51 207 617 52 210 617 minecraft:magenta_concrete
fill 51 207 619 52 210 619 minecraft:magenta_concrete
fill 53 207 618 53 210 618 minecraft:magenta_concrete
fill 81 207 617 82 208 618 minecraft:glass
fill 82 207 616 82 208 616 minecraft:glass
fill 50 208 617 50 210 619 minecraft:magenta_concrete
fill 51 208 616 52 210 616 minecraft:magenta_concrete
fill 51 208 620 52 210 620 minecraft:magenta_concrete
fill 53 208 617 53 210 617 minecraft:magenta_concrete
fill 53 208 619 53 210 619 minecraft:magenta_concrete
fill 56 208 642 56 209 643 minecraft:magenta_concrete
fill 57 208 644 57 209 644 minecraft:magenta_concrete
fill 58 208 642 58 209 643 minecraft:magenta_concrete
setblock 74 208 637 minecraft:sea_lantern
setblock 74 208 639 minecraft:sea_lantern
setblock 74 208 641 minecraft:sea_lantern
setblock 74 208 643 minecraft:sea_lantern
setblock 74 208 645 minecraft:sea_lantern
setblock 75 208 638 minecraft:sea_lantern
setblock 75 208 640 minecraft:sea_lantern
setblock 75 208 642 minecraft:sea_lantern
setblock 75 208 644 minecraft:sea_lantern
setblock 76 208 637 minecraft:sea_lantern
setblock 76 208 639 minecraft:sea_lantern
setblock 76 208 641 minecraft:sea_lantern
setblock 76 208 643 minecraft:sea_lantern
setblock 76 208 645 minecraft:sea_lantern
setblock 77 208 638 minecraft:sea_lantern
setblock 77 208 640 minecraft:sea_lantern
setblock 77 208 642 minecraft:sea_lantern
setblock 77 208 644 minecraft:sea_lantern
setblock 78 208 637 minecraft:sea_lantern
setblock 78 208 639 minecraft:sea_lantern
setblock 78 208 641 minecraft:sea_lantern
setblock 78 208 643 minecraft:sea_lantern
setblock 78 208 645 minecraft:sea_lantern
setblock 79 208 638 minecraft:sea_lantern
setblock 79 208 640 minecraft:sea_lantern
setblock 79 208 642 minecraft:sea_lantern
setblock 79 208 644 minecraft:sea_lantern
setblock 80 208 637 minecraft:sea_lantern
setblock 80 208 639 minecraft:sea_lantern
setblock 80 208 641 minecraft:sea_lantern
setblock 80 208 643 minecraft:sea_lantern
setblock 80 208 645 minecraft:sea_lantern
setblock 81 208 638 minecraft:sea_lantern
setblock 81 208 640 minecraft:sea_lantern
setblock 81 208 642 minecraft:sea_lantern
setblock 81 208 644 minecraft:sea_lantern
setblock 82 208 637 minecraft:sea_lantern
setblock 82 208 639 minecraft:sea_lantern
setblock 82 208 641 minecraft:sea_lantern
setblock 82 208 643 minecraft:sea_lantern
setblock 82 208 645 minecraft:sea_lantern
setblock 83 208 638 minecraft:sea_lantern
setblock 83 208 640 minecraft:sea_lantern
setblock 83 208 642 minecraft:sea_lantern
setblock 83 208 644 minecraft:sea_lantern
setblock 84 208 637 minecraft:sea_lantern
setblock 84 208 639 minecraft:sea_lantern
setblock 84 208 641 minecraft:sea_lantern
setblock 84 208 643 minecraft:sea_lantern
setblock 84 208 645 minecraft:sea_lantern
setblock 49 209 618 minecraft:magenta_concrete
fill 50 209 616 50 210 616 minecraft:magenta_concrete
fill 50 209 620 50 210 620 minecraft:magenta_concrete
fill 53 209 615 54 209 615 minecraft:glass
fill 53 209 616 53 210 616 minecraft:magenta_concrete
fill 53 209 620 53 210 620 minecraft:magenta_concrete
setblock 54 209 616 minecraft:glass
fill 54 209 617 54 210 619 minecraft:magenta_concrete
fill 74 209 637 74 210 637 minecraft:light_gray_concrete
fill 74 209 639 74 210 639 minecraft:light_gray_concrete
fill 74 209 641 74 210 641 minecraft:light_gray_concrete
fill 74 209 643 74 210 643 minecraft:light_gray_concrete
fill 74 209 645 74 210 645 minecraft:light_gray_concrete
fill 75 209 638 75 210 638 minecraft:light_gray_concrete
fill 75 209 640 75 210 640 minecraft:light_gray_concrete
fill 75 209 642 75 210 642 minecraft:light_gray_concrete
fill 75 209 644 75 210 644 minecraft:light_gray_concrete
fill 76 209 637 76 210 637 minecraft:light_gray_concrete
fill 76 209 639 76 210 639 minecraft:light_gray_concrete
fill 76 209 641 76 210 641 minecraft:light_gray_concrete
fill 76 209 643 76 210 643 minecraft:light_gray_concrete
fill 76 209 645 76 210 645 minecraft:light_gray_concrete
fill 77 209 638 77 210 638 minecraft:light_gray_concrete
fill 77 209 640 77 210 640 minecraft:light_gray_concrete
fill 77 209 642 77 210 642 minecraft:light_gray_concrete
fill 77 209 644 77 210 644 minecraft:light_gray_concrete
fill 78 209 637 78 210 637 minecraft:light_gray_concrete
fill 78 209 639 78 210 639 minecraft:light_gray_concrete
fill 78 209 641 78 210 641 minecraft:light_gray_concrete
fill 78 209 643 78 210 643 minecraft:light_gray_concrete
fill 78 209 645 78 210 645 minecraft:light_gray_concrete
fill 79 209 638 79 210 638 minecraft:light_gray_concrete
fill 79 209 640 79 210 640 minecraft:light_gray_concrete
fill 79 209 642 79 210 642 minecraft:light_gray_concrete
fill 79 209 644 79 210 644 minecraft:light_gray_concrete
fill 80 209 637 80 210 637 minecraft:light_gray_concrete
fill 80 209 639 80 210 639 minecraft:light_gray_concrete
fill 80 209 641 80 210 641 minecraft:light_gray_concrete
fill 80 209 643 80 210 643 minecraft:light_gray_concrete
fill 80 209 645 80 210 645 minecraft:light_gray_concrete
fill 81 209 638 81 210 638 minecraft:light_gray_concrete
fill 81 209 640 81 210 640 minecraft:light_gray_concrete
fill 81 209 642 81 210 642 minecraft:light_gray_concrete
fill 81 209 644 81 210 644 minecraft:light_gray_concrete
fill 82 209 637 82 210 637 minecraft:light_gray_concrete
fill 82 209 639 82 210 639 minecraft:light_gray_concrete
fill 82 209 641 82 210 641 minecraft:light_gray_concrete
fill 82 209 643 82 210 643 minecraft:light_gray_concrete
fill 82 209 645 82 210 645 minecraft:light_gray_concrete
fill 83 209 638 83 210 638 minecraft:light_gray_concrete
fill 83 209 640 83 210 640 minecraft:light_gray_concrete
fill 83 209 642 83 210 642 minecraft:light_gray_concrete
fill 83 209 644 83 210 644 minecraft:light_gray_concrete
fill 84 209 637 84 210 637 minecraft:light_gray_concrete
fill 84 209 639 84 210 639 minecraft:light_gray_concrete
fill 84 209 641 84 210 641 minecraft:light_gray_concrete
fill 84 209 643 84 210 643 minecraft:light_gray_concrete
fill 84 209 645 84 210 645 minecraft:light_gray_concrete
fill 48 210 605 48 211 610 minecraft:light_gray_concrete
fill 48 210 613 49 210 618 minecraft:light_gray_concrete
fill 48 210 621 49 210 626 minecraft:light_gray_concrete
fill 48 210 629 49 210 634 minecraft:light_gray_concrete
fill 48 210 637 49 210 642 minecraft:light_gray_concrete
fill 48 210 645 53 210 645 minecraft:light_gray_concrete
fill 49 210 606 49 210 612 minecraft:light_gray_concrete
fill 49 210 619 49 213 620 minecraft:light_gray_concrete
fill 49 210 627 49 210 628 minecraft:light_gray_concrete
fill 49 210 635 49 210 636 minecraft:light_gray_concrete
fill 49 210 643 49 210 644 minecraft:light_gray_concrete
fill 50 210 606 61 210 606 minecraft:light_gray_concrete
fill 50 210 644 73 210 644 minecraft:light_gray_concrete
fill 51 210 605 56 211 605 minecraft:light_gray_concrete
fill 51 210 615 53 210 615 minecraft:magenta_concrete
fill 51 210 621 53 210 621 minecraft:magenta_concrete
fill 52 210 641 62 210 643 minecraft:light_gray_concrete
setblock 54 210 615 minecraft:glass
setblock 54 210 616 minecraft:magenta_concrete
setblock 54 210 620 minecraft:magenta_concrete
setblock 55 210 618 minecraft:magenta_concrete
fill 56 210 645 61 210 645 minecraft:light_gray_concrete
fill 59 210 605 61 211 605 minecraft:light_gray_concrete
fill 64 210 645 69 211 645 minecraft:light_gray_concrete
fill 72 210 645 73 211 645 minecraft:light_gray_concrete
fill 75 210 605 80 210 606 minecraft:light_gray_concrete
fill 81 210 606 87 210 606 minecraft:light_gray_concrete
fill 83 210 605 88 211 605 minecraft:light_gray_concrete
fill 85 210 644 85 210 645 minecraft:light_gray_concrete
fill 86 210 644 88 210 644 minecraft:light_gray_concrete
fill 87 210 607 87 210 643 minecraft:light_gray_concrete
fill 88 210 608 88 211 613 minecraft:light_gray_concrete
fill 88 210 616 88 211 621 minecraft:light_gray_concrete
fill 88 210 624 88 211 629 minecraft:light_gray_concrete
fill 88 210 632 88 211 637 minecraft:light_gray_concrete
fill 88 210 640 88 211 643 minecraft:light_gray_concrete
fill 88 210 645 88 211 645 minecraft:light_gray_concrete
fill 48 211 613 48 211 618 minecraft:light_gray_concrete
fill 48 211 621 48 211 626 minecraft:light_gray_concrete
fill 48 211 629 48 211 634 minecraft:light_gray_concrete
fill 48 211 637 48 211 642 minecraft:light_gray_concrete
fill 48 211 645 51 211 645 minecraft:light_gray_concrete
fill 49 211 614 56 213 618 minecraft:light_gray_concrete
fill 49 211 621 56 213 622 minecraft:light_gray_concrete
setblock 50 211 607 minecraft:light[level=14]
fill 50 211 619 56 213 620 minecraft:light_gray_concrete
setblock 50 211 623 minecraft:light[level=14]
setblock 50 211 631 minecraft:light[level=14]
setblock 50 211 639 minecraft:light[level=14]
setblock 52 211 641 minecraft:sea_lantern
fill 52 211 642 52 235 642 minecraft:light_gray_concrete
setblock 52 211 643 minecraft:sea_lantern
fill 52 211 644 52 235 644 minecraft:light_gray_concrete
setblock 52 211 645 minecraft:sea_lantern
fill 53 211 641 53 235 641 minecraft:light_gray_concrete
setblock 53 211 642 minecraft:sea_lantern
fill 53 211 643 53 235 643 minecraft:light_gray_concrete
setblock 53 211 644 minecraft:sea_lantern
fill 53 211 645 53 235 645 minecraft:light_gray_concrete
setblock 54 211 641 minecraft:sea_lantern
fill 54 211 642 54 235 642 minecraft:light_gray_concrete
setblock 54 211 643 minecraft:sea_lantern
fill 54 211 644 54 235 644 minecraft:light_gray_concrete
setblock 54 211 645 minecraft:sea_lantern
fill 55 211 641 55 235 641 minecraft:light_gray_concrete
setblock 55 211 642 minecraft:sea_lantern
fill 55 211 643 55 235 643 minecraft:light_gray_concrete
setblock 55 211 644 minecraft:sea_lantern
fill 55 211 645 55 235 645 minecraft:light_gray_concrete
setblock 56 211 641 minecraft:sea_lantern
fill 56 211 642 56 235 642 minecraft:light_gray_concrete
setblock 56 211 643 minecraft:sea_lantern
fill 56 211 644 56 235 644 minecraft:light_gray_concrete
setblock 56 211 645 minecraft:sea_lantern
fill 57 211 641 57 235 641 minecraft:light_gray_concrete
setblock 57 211 642 minecraft:sea_lantern
fill 57 211 643 57 235 643 minecraft:light_gray_concrete
setblock 57 211 644 minecraft:sea_lantern
fill 57 211 645 57 235 645 minecraft:light_gray_concrete
setblock 58 211 607 minecraft:light[level=14]
setblock 58 211 615 minecraft:light[level=14]
setblock 58 211 623 minecraft:light[level=14]
setblock 58 211 631 minecraft:light[level=14]
setblock 58 211 639 minecraft:light[level=14]
setblock 58 211 641 minecraft:sea_lantern
fill 58 211 642 58 235 642 minecraft:light_gray_concrete
setblock 58 211 643 minecraft:sea_lantern
fill 58 211 644 58 235 644 minecraft:light_gray_concrete
setblock 58 211 645 minecraft:sea_lantern
fill 59 211 641 59 235 641 minecraft:light_gray_concrete
setblock 59 211 642 minecraft:sea_lantern
fill 59 211 643 59 235 643 minecraft:light_gray_concrete
setblock 59 211 644 minecraft:sea_lantern
fill 59 211 645 59 235 645 minecraft:light_gray_concrete
setblock 60 211 641 minecraft:sea_lantern
fill 60 211 642 60 235 642 minecraft:light_gray_concrete
setblock 60 211 643 minecraft:sea_lantern
fill 60 211 644 60 235 644 minecraft:light_gray_concrete
setblock 60 211 645 minecraft:sea_lantern
fill 61 211 641 61 235 641 minecraft:light_gray_concrete
setblock 61 211 642 minecraft:sea_lantern
fill 61 211 643 61 235 643 minecraft:light_gray_concrete
setblock 61 211 644 minecraft:sea_lantern
fill 61 211 645 61 235 645 minecraft:light_gray_concrete
setblock 62 211 641 minecraft:sea_lantern
fill 62 211 642 62 235 642 minecraft:light_gray_concrete
setblock 62 211 643 minecraft:sea_lantern
fill 62 211 644 62 235 644 minecraft:light_gray_concrete
setblock 62 211 645 minecraft:sea_lantern
fill 63 211 645 63 235 645 minecraft:light_gray_concrete
setblock 66 211 615 minecraft:light[level=14]
setblock 66 211 623 minecraft:light[level=14]
setblock 66 211 631 minecraft:light[level=14]
setblock 66 211 639 minecraft:light[level=14]
setblock 74 211 615 minecraft:light[level=14]
setblock 74 211 623 minecraft:light[level=14]
setblock 74 211 631 minecraft:light[level=14]
setblock 74 211 637 minecraft:sea_lantern
setblock 74 211 639 minecraft:sea_lantern
setblock 74 211 641 minecraft:sea_lantern
setblock 74 211 643 minecraft:sea_lantern
setblock 74 211 645 minecraft:sea_lantern
fill 75 211 605 80 211 605 minecraft:light_gray_concrete
setblock 75 211 638 minecraft:sea_lantern
setblock 75 211 640 minecraft:sea_lantern
setblock 75 211 642 minecraft:sea_lantern
setblock 75 211 644 minecraft:sea_lantern
setblock 76 211 637 minecraft:sea_lantern
setblock 76 211 639 minecraft:sea_lantern
setblock 76 211 641 minecraft:sea_lantern
setblock 76 211 643 minecraft:sea_lantern
setblock 76 211 645 minecraft:sea_lantern
setblock 77 211 638 minecraft:sea_lantern
setblock 77 211 640 minecraft:sea_lantern
setblock 77 211 642 minecraft:sea_lantern
setblock 77 211 644 minecraft:sea_lantern
setblock 78 211 637 minecraft:sea_lantern
setblock 78 211 639 minecraft:sea_lantern
setblock 78 211 641 minecraft:sea_lantern
setblock 78 211 643 minecraft:sea_lantern
setblock 78 211 645 minecraft:sea_lantern
setblock 79 211 638 minecraft:sea_lantern
setblock 79 211 640 minecraft:sea_lantern
setblock 79 211 642 minecraft:sea_lantern
setblock 79 211 644 minecraft:sea_lantern
setblock 80 211 637 minecraft:sea_lantern
setblock 80 211 639 minecraft:sea_lantern
setblock 80 211 641 minecraft:sea_lantern
setblock 80 211 643 minecraft:sea_lantern
setblock 80 211 645 minecraft:sea_lantern
setblock 81 211 638 minecraft:sea_lantern
setblock 81 211 640 minecraft:sea_lantern
setblock 81 211 642 minecraft:sea_lantern
setblock 81 211 644 minecraft:sea_lantern
setblock 82 211 607 minecraft:light[level=14]
setblock 82 211 615 minecraft:light[level=14]
setblock 82 211 623 minecraft:light[level=14]
setblock 82 211 631 minecraft:light[level=14]
setblock 82 211 637 minecraft:sea_lantern
setblock 82 211 639 minecraft:sea_lantern
setblock 82 211 641 minecraft:sea_lantern
setblock 82 211 643 minecraft:sea_lantern
setblock 82 211 645 minecraft:sea_lantern
setblock 83 211 638 minecraft:sea_lantern
setblock 83 211 640 minecraft:sea_lantern
setblock 83 211 642 minecraft:sea_lantern
setblock 83 211 644 minecraft:sea_lantern
setblock 84 211 637 minecraft:sea_lantern
setblock 84 211 639 minecraft:sea_lantern
setblock 84 211 641 minecraft:sea_lantern
setblock 84 211 643 minecraft:sea_lantern
setblock 84 211 645 minecraft:sea_lantern
setblock 85 211 645 minecraft:light_gray_concrete
setblock 88 211 644 minecraft:light_gray_concrete
fill 48 212 614 48 213 618 minecraft:light_gray_concrete
fill 48 212 621 48 213 622 minecraft:light_gray_concrete
fill 52 212 641 52 213 641 minecraft:light_gray_concrete
fill 52 212 643 52 213 643 minecraft:light_gray_concrete
fill 52 212 645 52 213 645 minecraft:light_gray_concrete
fill 53 212 642 53 213 642 minecraft:light_gray_concrete
fill 53 212 644 53 213 644 minecraft:light_gray_concrete
fill 54 212 641 54 213 641 minecraft:light_gray_concrete
fill 54 212 643 54 213 643 minecraft:light_gray_concrete
fill 54 212 645 54 213 645 minecraft:light_gray_concrete
fill 55 212 642 55 213 642 minecraft:light_gray_concrete
fill 55 212 644 55 213 644 minecraft:light_gray_concrete
fill 56 212 641 56 213 641 minecraft:light_gray_concrete
fill 56 212 643 56 213 643 minecraft:light_gray_concrete
fill 56 212 645 56 213 645 minecraft:light_gray_concrete
fill 57 212 642 57 213 642 minecraft:light_gray_concrete
fill 57 212 644 57 213 644 minecraft:light_gray_concrete
fill 58 212 641 58 213 641 minecraft:light_gray_concrete
fill 58 212 643 58 213 643 minecraft:light_gray_concrete
fill 58 212 645 58 213 645 minecraft:light_gray_concrete
fill 59 212 642 59 213 642 minecraft:light_gray_concrete
fill 59 212 644 59 213 644 minecraft:light_gray_concrete
fill 60 212 641 60 213 641 minecraft:light_gray_concrete
fill 60 212 643 60 213 643 minecraft:light_gray_concrete
fill 60 212 645 60 213 645 minecraft:light_gray_concrete
fill 61 212 642 61 213 642 minecraft:light_gray_concrete
fill 61 212 644 61 213 644 minecraft:light_gray_concrete
fill 62 212 641 62 213 641 minecraft:light_gray_concrete
fill 62 212 643 62 213 643 minecraft:light_gray_concrete
fill 62 212 645 62 213 645 minecraft:light_gray_concrete
fill 74 212 637 74 213 637 minecraft:light_gray_concrete
fill 74 212 639 74 213 639 minecraft:light_gray_concrete
fill 74 212 641 74 213 641 minecraft:light_gray_concrete
fill 74 212 643 74 213 643 minecraft:light_gray_concrete
fill 74 212 645 74 213 645 minecraft:light_gray_concrete
fill 75 212 638 75 213 638 minecraft:light_gray_concrete
fill 75 212 640 75 213 640 minecraft:light_gray_concrete
fill 75 212 642 75 213 642 minecraft:light_gray_concrete
fill 75 212 644 75 213 644 minecraft:light_gray_concrete
fill 76 212 637 76 213 637 minecraft:light_gray_concrete
fill 76 212 639 76 213 639 minecraft:light_gray_concrete
fill 76 212 641 76 213 641 minecraft:light_gray_concrete
fill 76 212 643 76 213 643 minecraft:light_gray_concrete
fill 76 212 645 76 213 645 minecraft:light_gray_concrete
fill 77 212 638 77 213 638 minecraft:light_gray_concrete
fill 77 212 640 77 213 640 minecraft:light_gray_concrete
fill 77 212 642 77 213 642 minecraft:light_gray_concrete
fill 77 212 644 77 213 644 minecraft:light_gray_concrete
fill 78 212 637 78 213 637 minecraft:light_gray_concrete
fill 78 212 639 78 213 639 minecraft:light_gray_concrete
fill 78 212 641 78 213 641 minecraft:light_gray_concrete
fill 78 212 643 78 213 643 minecraft:light_gray_concrete
fill 78 212 645 78 213 645 minecraft:light_gray_concrete
fill 79 212 638 79 213 638 minecraft:light_gray_concrete
fill 79 212 640 79 213 640 minecraft:light_gray_concrete
fill 79 212 642 79 213 642 minecraft:light_gray_concrete
fill 79 212 644 79 213 644 minecraft:light_gray_concrete
fill 80 212 637 80 213 637 minecraft:light_gray_concrete
fill 80 212 639 80 213 639 minecraft:light_gray_concrete
fill 80 212 641 80 213 641 minecraft:light_gray_concrete
fill 80 212 643 80 213 643 minecraft:light_gray_concrete
fill 80 212 645 80 213 645 minecraft:light_gray_concrete
fill 81 212 638 81 213 638 minecraft:light_gray_concrete
fill 81 212 640 81 213 640 minecraft:light_gray_concrete
fill 81 212 642 81 213 642 minecraft:light_gray_concrete
fill 81 212 644 81 213 644 minecraft:light_gray_concrete
fill 82 212 637 82 213 637 minecraft:light_gray_concrete
fill 82 212 639 82 213 639 minecraft:light_gray_concrete
fill 82 212 641 82 213 641 minecraft:light_gray_concrete
fill 82 212 643 82 213 643 minecraft:light_gray_concrete
fill 82 212 645 82 213 645 minecraft:light_gray_concrete
fill 83 212 638 83 213 638 minecraft:light_gray_concrete
fill 83 212 640 83 213 640 minecraft:light_gray_concrete
fill 83 212 642 83 213 642 minecraft:light_gray_concrete
fill 83 212 644 83 213 644 minecraft:light_gray_concrete
fill 84 212 637 84 213 637 minecraft:light_gray_concrete
fill 84 212 639 84 213 639 minecraft:light_gray_concrete
fill 84 212 641 84 213 641 minecraft:light_gray_concrete
fill 84 212 643 84 213 643 minecraft:light_gray_concrete
fill 84 212 645 84 213 645 minecraft:light_gray_concrete
fill 47 214 609 47 219 609 minecraft:sea_lantern
fill 47 214 617 48 214 617 minecraft:sea_lantern
fill 47 214 625 47 219 625 minecraft:sea_lantern
fill 47 214 633 47 219 633 minecraft:sea_lantern
fill 47 214 641 47 219 641 minecraft:sea_lantern
fill 48 214 614 48 235 614 minecraft:light_gray_concrete
setblock 48 214 615 minecraft:sea_lantern
fill 48 214 616 48 235 616 minecraft:light_gray_concrete
fill 48 214 618 48 235 618 minecraft:light_gray_concrete
setblock 48 214 619 minecraft:sea_lantern
fill 48 214 620 48 235 620 minecraft:light_gray_concrete
setblock 48 214 621 minecraft:sea_lantern
fill 48 214 622 48 235 622 minecraft:light_gray_concrete
setblock 49 214 614 minecraft:sea_lantern
fill 49 214 615 49 235 615 minecraft:light_gray_concrete
setblock 49 214 616 minecraft:sea_lantern
fill 49 214 617 49 235 617 minecraft:light_gray_concrete
setblock 49 214 618 minecraft:sea_lantern
fill 49 214 619 49 235 619 minecraft:light_gray_concrete
setblock 49 214 620 minecraft:sea_lantern
fill 49 214 621 49 235 621 minecraft:light_gray_concrete
setblock 49 214 622 minecraft:sea_lantern
fill 50 214 614 50 235 614 minecraft:light_gray_concrete
setblock 50 214 615 minecraft:sea_lantern
fill 50 214 616 50 235 616 minecraft:light_gray_concrete
setblock 50 214 617 minecraft:sea_lantern
fill 50 214 618 50 235 618 minecraft:light_gray_concrete
setblock 50 214 619 minecraft:sea_lantern
fill 50 214 620 50 235 620 minecraft:light_gray_concrete
setblock 50 214 621 minecraft:sea_lantern
fill 50 214 622 50 235 622 minecraft:light_gray_concrete
fill 50 214 646 50 219 646 minecraft:sea_lantern
setblock 51 214 614 minecraft:sea_lantern
fill 51 214 615 51 235 615 minecraft:light_gray_concrete
setblock 51 214 616 minecraft:sea_lantern
fill 51 214 617 51 235 617 minecraft:light_gray_concrete
setblock 51 214 618 minecraft:sea_lantern
fill 51 214 619 51 235 619 minecraft:light_gray_concrete
setblock 51 214 620 minecraft:sea_lantern
fill 51 214 621 51 235 621 minecraft:light_gray_concrete
setblock 51 214 622 minecraft:sea_lantern
fill 52 214 614 52 235 614 minecraft:light_gray_concrete
setblock 52 214 615 minecraft:sea_lantern
fill 52 214 616 52 235 616 minecraft:light_gray_concrete
setblock 52 214 617 minecraft:sea_lantern
fill 52 214 618 52 235 618 minecraft:light_gray_concrete
setblock 52 214 619 minecraft:sea_lantern
fill 52 214 620 52 235 620 minecraft:light_gray_concrete
setblock 52 214 621 minecraft:sea_lantern
fill 52 214 622 52 235 622 minecraft:light_gray_concrete
setblock 52 214 641 minecraft:sea_lantern
setblock 52 214 643 minecraft:sea_lantern
setblock 52 214 645 minecraft:sea_lantern
setblock 53 214 614 minecraft:sea_lantern
fill 53 214 615 53 235 615 minecraft:light_gray_concrete
setblock 53 214 616 minecraft:sea_lantern
fill 53 214 617 53 235 617 minecraft:light_gray_concrete
setblock 53 214 618 minecraft:sea_lantern
fill 53 214 619 53 235 619 minecraft:light_gray_concrete
setblock 53 214 620 minecraft:sea_lantern
fill 53 214 621 53 235 621 minecraft:light_gray_concrete
setblock 53 214 622 minecraft:sea_lantern
setblock 53 214 642 minecraft:sea_lantern
setblock 53 214 644 minecraft:sea_lantern
fill 54 214 604 54 219 604 minecraft:sea_lantern
fill 54 214 614 54 235 614 minecraft:light_gray_concrete
setblock 54 214 615 minecraft:sea_lantern
fill 54 214 616 54 235 616 minecraft:light_gray_concrete
setblock 54 214 617 minecraft:sea_lantern
fill 54 214 618 54 235 618 minecraft:light_gray_concrete
setblock 54 214 619 minecraft:sea_lantern
fill 54 214 620 54 235 620 minecraft:light_gray_concrete
setblock 54 214 621 minecraft:sea_lantern
fill 54 214 622 54 235 622 minecraft:light_gray_concrete
setblock 54 214 641 minecraft:sea_lantern
setblock 54 214 643 minecraft:sea_lantern
setblock 54 214 645 minecraft:sea_lantern
setblock 55 214 614 minecraft:sea_lantern
fill 55 214 615 55 235 615 minecraft:light_gray_concrete
setblock 55 214 616 minecraft:sea_lantern
fill 55 214 617 55 235 617 minecraft:light_gray_concrete
setblock 55 214 618 minecraft:sea_lantern
fill 55 214 619 55 235 619 minecraft:light_gray_concrete
setblock 55 214 620 minecraft:sea_lantern
fill 55 214 621 55 235 621 minecraft:light_gray_concrete
setblock 55 214 622 minecraft:sea_lantern
setblock 55 214 642 minecraft:sea_lantern
setblock 55 214 644 minecraft:sea_lantern
fill 56 214 614 56 235 614 minecraft:light_gray_concrete
setblock 56 214 615 minecraft:sea_lantern
fill 56 214 616 56 235 616 minecraft:light_gray_concrete
setblock 56 214 617 minecraft:sea_lantern
fill 56 214 618 56 235 618 minecraft:light_gray_concrete
setblock 56 214 619 minecraft:sea_lantern
fill 56 214 620 56 235 620 minecraft:light_gray_concrete
setblock 56 214 621 minecraft:sea_lantern
fill 56 214 622 56 235 622 minecraft:light_gray_concrete
setblock 56 214 641 minecraft:sea_lantern
setblock 56 214 643 minecraft:sea_lantern
setblock 56 214 645 minecraft:sea_lantern
setblock 57 214 642 minecraft:sea_lantern
setblock 57 214 644 minecraft:sea_lantern
setblock 58 214 641 minecraft:sea_lantern
setblock 58 214 643 minecraft:sea_lantern
fill 58 214 645 58 214 646 minecraft:sea_lantern
fill 59 214 608 59 219 608 minecraft:magenta_concrete
setblock 59 214 642 minecraft:sea_lantern
setblock 59 214 644 minecraft:sea_lantern
setblock 60 214 641 minecraft:sea_lantern
setblock 60 214 643 minecraft:sea_lantern
setblock 60 214 645 minecraft:sea_lantern
setblock 61 214 642 minecraft:sea_lantern
setblock 61 214 644 minecraft:sea_lantern
fill 62 214 604 62 219 604 minecraft:sea_lantern
setblock 62 214 641 minecraft:sea_lantern
setblock 62 214 643 minecraft:sea_lantern
setblock 62 214 645 minecraft:sea_lantern
fill 66 214 646 66 219 646 minecraft:sea_lantern
fill 70 214 604 70 219 604 minecraft:sea_lantern
setblock 74 214 637 minecraft:sea_lantern
setblock 74 214 639 minecraft:sea_lantern
setblock 74 214 641 minecraft:sea_lantern
setblock 74 214 643 minecraft:sea_lantern
fill 74 214 645 74 214 646 minecraft:sea_lantern
setblock 75 214 638 minecraft:sea_lantern
setblock 75 214 640 minecraft:sea_lantern
setblock 75 214 642 minecraft:sea_lantern
setblock 75 214 644 minecraft:sea_lantern
setblock 76 214 637 minecraft:sea_lantern
setblock 76 214 639 minecraft:sea_lantern
setblock 76 214 641 minecraft:sea_lantern
setblock 76 214 643 minecraft:sea_lantern
setblock 76 214 645 minecraft:sea_lantern
setblock 77 214 638 minecraft:sea_lantern
setblock 77 214 640 minecraft:sea_lantern
setblock 77 214 642 minecraft:sea_lantern
setblock 77 214 644 minecraft:sea_lantern
fill 78 214 604 78 219 604 minecraft:sea_lantern
setblock 78 214 637 minecraft:sea_lantern
setblock 78 214 639 minecraft:sea_lantern
setblock 78 214 641 minecraft:sea_lantern
setblock 78 214 643 minecraft:sea_lantern
setblock 78 214 645 minecraft:sea_lantern
setblock 79 214 638 minecraft:sea_lantern
setblock 79 214 640 minecraft:sea_lantern
setblock 79 214 642 minecraft:sea_lantern
setblock 79 214 644 minecraft:sea_lantern
setblock 80 214 637 minecraft:sea_lantern
setblock 80 214 639 minecraft:sea_lantern
setblock 80 214 641 minecraft:sea_lantern
setblock 80 214 643 minecraft:sea_lantern
setblock 80 214 645 minecraft:sea_lantern
setblock 81 214 638 minecraft:sea_lantern
setblock 81 214 640 minecraft:sea_lantern
setblock 81 214 642 minecraft:sea_lantern
setblock 81 214 644 minecraft:sea_lantern
setblock 82 214 637 minecraft:sea_lantern
setblock 82 214 639 minecraft:sea_lantern
setblock 82 214 641 minecraft:sea_lantern
setblock 82 214 643 minecraft:sea_lantern
fill 82 214 645 82 214 646 minecraft:sea_lantern
setblock 83 214 638 minecraft:sea_lantern
setblock 83 214 640 minecraft:sea_lantern
setblock 83 214 642 minecraft:sea_lantern
setblock 83 214 644 minecraft:sea_lantern
setblock 84 214 637 minecraft:sea_lantern
setblock 84 214 639 minecraft:sea_lantern
setblock 84 214 641 minecraft:sea_lantern
setblock 84 214 643 minecraft:sea_lantern
setblock 84 214 645 minecraft:sea_lantern
fill 86 214 604 86 219 604 minecraft:sea_lantern
fill 89 214 609 89 219 609 minecraft:sea_lantern
fill 89 214 617 89 219 617 minecraft:sea_lantern
fill 89 214 625 89 219 625 minecraft:sea_lantern
fill 89 214 633 89 219 633 minecraft:sea_lantern
fill 89 214 641 89 219 641 minecraft:sea_lantern
setblock 47 215 616 minecraft:gray_concrete
fill 47 215 617 47 219 617 minecraft:sea_lantern
setblock 47 215 645 minecraft:gray_concrete
fill 47 215 646 47 218 646 minecraft:black_concrete
fill 48 215 615 48 216 615 minecraft:light_gray_concrete
fill 48 215 617 48 216 617 minecraft:light_gray_concrete
fill 48 215 619 48 216 619 minecraft:light_gray_concrete
fill 48 215 621 48 216 621 minecraft:light_gray_concrete
fill 49 215 614 49 216 614 minecraft:light_gray_concrete
fill 49 215 616 49 216 616 minecraft:light_gray_concrete
fill 49 215 618 49 216 618 minecraft:light_gray_concrete
fill 49 215 620 49 216 620 minecraft:light_gray_concrete
fill 49 215 622 49 216 622 minecraft:light_gray_concrete
fill 50 215 604 50 218 604 minecraft:black_concrete
fill 50 215 615 50 216 615 minecraft:light_gray_concrete
fill 50 215 617 50 216 617 minecraft:light_gray_concrete
fill 50 215 619 50 216 619 minecraft:light_gray_concrete
fill 50 215 621 50 216 621 minecraft:light_gray_concrete
setblock 51 215 604 minecraft:gray_concrete
fill 51 215 614 51 216 614 minecraft:light_gray_concrete
fill 51 215 616 51 216 616 minecraft:light_gray_concrete
fill 51 215 618 51 216 618 minecraft:light_gray_concrete
fill 51 215 620 51 216 620 minecraft:light_gray_concrete
fill 51 215 622 51 216 622 minecraft:light_gray_concrete
fill 52 215 604 52 219 604 minecraft:black_concrete
fill 52 215 615 52 216 615 minecraft:light_gray_concrete
fill 52 215 617 52 216 617 minecraft:light_gray_concrete
fill 52 215 619 52 216 619 minecraft:light_gray_concrete
fill 52 215 621 52 216 621 minecraft:light_gray_concrete
fill 52 215 641 52 216 641 minecraft:light_gray_concrete
fill 52 215 643 52 216 643 minecraft:light_gray_concrete
fill 52 215 645 52 216 645 minecraft:light_gray_concrete
fill 53 215 614 53 216 614 minecraft:light_gray_concrete
fill 53 215 616 53 216 616 minecraft:light_gray_concrete
fill 53 215 618 53 216 618 minecraft:light_gray_concrete
fill 53 215 620 53 216 620 minecraft:light_gray_concrete
fill 53 215 622 53 216 622 minecraft:light_gray_concrete
fill 53 215 642 53 216 642 minecraft:light_gray_concrete
fill 53 215 644 53 216 644 minecraft:light_gray_concrete
fill 54 215 615 54 216 615 minecraft:light_gray_concrete
fill 54 215 617 54 216 617 minecraft:light_gray_concrete
fill 54 215 619 54 216 619 minecraft:light_gray_concrete
fill 54 215 621 54 216 621 minecraft:light_gray_concrete
fill 54 215 641 54 216 641 minecraft:light_gray_concrete
fill 54 215 643 54 216 643 minecraft:light_gray_concrete
fill 54 215 645 54 216 645 minecraft:light_gray_concrete
fill 55 215 614 55 216 614 minecraft:light_gray_concrete
fill 55 215 616 55 216 616 minecraft:light_gray_concrete
fill 55 215 618 55 216 618 minecraft:light_gray_concrete
fill 55 215 620 55 216 620 minecraft:light_gray_concrete
fill 55 215 622 55 216 622 minecraft:light_gray_concrete
fill 55 215 642 55 216 642 minecraft:light_gray_concrete
fill 55 215 644 55 216 644 minecraft:light_gray_concrete
fill 56 215 615 56 216 615 minecraft:light_gray_concrete
fill 56 215 617 56 216 617 minecraft:light_gray_concrete
fill 56 215 619 56 216 619 minecraft:light_gray_concrete
fill 56 215 621 56 216 621 minecraft:light_gray_concrete
fill 56 215 641 56 216 641 minecraft:light_gray_concrete
fill 56 215 643 56 216 643 minecraft:light_gray_concrete
fill 56 215 645 56 216 645 minecraft:light_gray_concrete
setblock 56 215 646 minecraft:gray_concrete
fill 57 215 642 57 216 642 minecraft:light_gray_concrete
fill 57 215 644 57 216 644 minecraft:light_gray_concrete
fill 58 215 641 58 216 641 minecraft:light_gray_concrete
fill 58 215 643 58 216 643 minecraft:light_gray_concrete
fill 58 215 645 58 216 645 minecraft:light_gray_concrete
fill 58 215 646 58 219 646 minecraft:sea_lantern
fill 59 215 609 59 219 609 minecraft:magenta_concrete
fill 59 215 642 59 216 642 minecraft:light_gray_concrete
fill 59 215 644 59 216 644 minecraft:light_gray_concrete
fill 60 215 641 60 216 641 minecraft:light_gray_concrete
fill 60 215 643 60 216 643 minecraft:light_gray_concrete
fill 60 215 645 60 216 645 minecraft:light_gray_concrete
fill 61 215 642 61 216 642 minecraft:light_gray_concrete
fill 61 215 644 61 216 644 minecraft:light_gray_concrete
setblock 61 215 646 minecraft:gray_concrete
fill 62 215 641 62 216 641 minecraft:light_gray_concrete
fill 62 215 643 62 216 643 minecraft:light_gray_concrete
fill 62 215 645 62 216 645 minecraft:light_gray_concrete
fill 63 215 646 63 216 646 minecraft:gray_concrete
setblock 72 215 646 minecraft:gray_concrete
fill 73 215 604 73 218 604 minecraft:black_concrete
setblock 74 215 604 minecraft:gray_concrete
fill 74 215 637 74 216 637 minecraft:light_gray_concrete
fill 74 215 639 74 216 639 minecraft:light_gray_concrete
fill 74 215 641 74 216 641 minecraft:light_gray_concrete
fill 74 215 643 74 216 643 minecraft:light_gray_concrete
fill 74 215 645 74 216 645 minecraft:light_gray_concrete
fill 74 215 646 74 219 646 minecraft:sea_lantern
fill 75 215 604 77 218 604 minecraft:black_concrete
fill 75 215 638 75 216 638 minecraft:light_gray_concrete
fill 75 215 640 75 216 640 minecraft:light_gray_concrete
fill 75 215 642 75 216 642 minecraft:light_gray_concrete
fill 75 215 644 75 216 644 minecraft:light_gray_concrete
fill 76 215 637 76 216 637 minecraft:light_gray_concrete
fill 76 215 639 76 216 639 minecraft:light_gray_concrete
fill 76 215 641 76 216 641 minecraft:light_gray_concrete
fill 76 215 643 76 216 643 minecraft:light_gray_concrete
fill 76 215 645 76 216 645 minecraft:light_gray_concrete
fill 77 215 638 77 216 638 minecraft:light_gray_concrete
fill 77 215 640 77 216 640 minecraft:light_gray_concrete
fill 77 215 642 77 216 642 minecraft:light_gray_concrete
fill 77 215 644 77 216 644 minecraft:light_gray_concrete
setblock 77 215 646 minecraft:gray_concrete
fill 78 215 637 78 216 637 minecraft:light_gray_concrete
fill 78 215 639 78 216 639 minecraft:light_gray_concrete
fill 78 215 641 78 216 641 minecraft:light_gray_concrete
fill 78 215 643 78 216 643 minecraft:light_gray_concrete
fill 78 215 645 78 216 645 minecraft:light_gray_concrete
fill 78 215 646 78 218 646 minecraft:black_concrete
fill 79 215 638 79 216 638 minecraft:light_gray_concrete
fill 79 215 640 79 216 640 minecraft:light_gray_concrete
fill 79 215 642 79 216 642 minecraft:light_gray_concrete
fill 79 215 644 79 216 644 minecraft:light_gray_concrete
fill 80 215 637 80 216 637 minecraft:light_gray_concrete
fill 80 215 639 80 216 639 minecraft:light_gray_concrete
fill 80 215 641 80 216 641 minecraft:light_gray_concrete
fill 80 215 643 80 216 643 minecraft:light_gray_concrete
fill 80 215 645 80 216 645 minecraft:light_gray_concrete
fill 81 215 638 81 216 638 minecraft:light_gray_concrete
fill 81 215 640 81 216 640 minecraft:light_gray_concrete
fill 81 215 642 81 216 642 minecraft:light_gray_concrete
fill 81 215 644 81 216 644 minecraft:light_gray_concrete
fill 82 215 637 82 216 637 minecraft:light_gray_concrete
fill 82 215 639 82 216 639 minecraft:light_gray_concrete
fill 82 215 641 82 216 641 minecraft:light_gray_concrete
fill 82 215 643 82 216 643 minecraft:light_gray_concrete
fill 82 215 645 82 216 645 minecraft:light_gray_concrete
fill 82 215 646 82 219 646 minecraft:sea_lantern
fill 83 215 638 83 216 638 minecraft:light_gray_concrete
fill 83 215 640 83 216 640 minecraft:light_gray_concrete
fill 83 215 642 83 216 642 minecraft:light_gray_concrete
fill 83 215 644 83 216 644 minecraft:light_gray_concrete
fill 84 215 637 84 216 637 minecraft:light_gray_concrete
fill 84 215 639 84 216 639 minecraft:light_gray_concrete
fill 84 215 641 84 216 641 minecraft:light_gray_concrete
fill 84 215 643 84 216 643 minecraft:light_gray_concrete
fill 84 215 645 84 216 645 minecraft:light_gray_concrete
setblock 84 215 646 minecraft:gray_concrete
fill 85 215 646 86 218 646 minecraft:black_concrete
setblock 87 215 646 minecraft:gray_concrete
fill 88 215 646 89 215 646 minecraft:black_concrete
fill 89 215 604 89 219 604 minecraft:black_concrete
setblock 89 215 605 minecraft:gray_concrete
fill 89 215 606 89 218 608 minecraft:black_concrete
fill 89 215 611 89 218 612 minecraft:black_concrete
setblock 89 215 613 minecraft:gray_concrete
fill 89 215 614 89 218 615 minecraft:black_concrete
fill 89 215 618 89 218 618 minecraft:black_concrete
setblock 89 215 619 minecraft:gray_concrete
fill 89 215 620 89 218 620 minecraft:black_concrete
setblock 89 215 621 minecraft:gray_concrete
fill 89 215 622 89 218 622 minecraft:black_concrete
setblock 47 216 614 minecraft:gray_concrete
fill 47 216 616 47 218 616 minecraft:black_concrete
fill 47 216 642 47 219 642 minecraft:black_concrete
setblock 47 216 643 minecraft:gray_concrete
fill 47 216 645 47 218 645 minecraft:black_concrete
setblock 51 216 604 minecraft:black_concrete
fill 55 216 604 56 218 604 minecraft:black_concrete
setblock 56 216 646 minecraft:black_concrete
setblock 57 216 604 minecraft:gray_concrete
fill 58 216 604 58 218 604 minecraft:black_concrete
fill 58 216 608 58 219 609 minecraft:magenta_concrete
setblock 59 216 604 minecraft:gray_concrete
fill 59 216 607 59 219 607 minecraft:magenta_concrete
setblock 59 216 646 minecraft:gray_concrete
fill 60 216 604 61 218 604 minecraft:black_concrete
fill 60 216 608 60 219 609 minecraft:magenta_concrete
fill 60 216 646 61 218 646 minecraft:black_concrete
setblock 67 216 646 minecraft:gray_concrete
setblock 68 216 646 minecraft:black_concrete
fill 72 216 646 72 218 646 minecraft:black_concrete
setblock 73 216 646 minecraft:gray_concrete
fill 74 216 604 74 218 604 minecraft:black_concrete
fill 76 216 646 76 217 646 minecraft:gray_concrete
fill 77 216 646 77 218 646 minecraft:black_concrete
fill 84 216 646 84 218 646 minecraft:black_concrete
fill 85 216 604 85 217 604 minecraft:gray_concrete
fill 87 216 646 88 216 646 minecraft:black_concrete
fill 89 216 605 89 218 605 minecraft:black_concrete
fill 89 216 613 89 218 613 minecraft:black_concrete
fill 89 216 619 89 218 619 minecraft:black_concrete
fill 89 216 621 89 218 621 minecraft:black_concrete
fill 89 216 646 89 217 646 minecraft:gray_concrete
fill 47 217 610 47 218 611 minecraft:black_concrete
setblock 47 217 612 minecraft:gray_concrete
fill 47 217 613 47 218 614 minecraft:black_concrete
setblock 47 217 627 minecraft:gray_concrete
fill 47 217 643 47 218 643 minecraft:black_concrete
setblock 48 217 615 minecraft:sea_lantern
setblock 48 217 617 minecraft:sea_lantern
setblock 48 217 619 minecraft:sea_lantern
setblock 48 217 621 minecraft:sea_lantern
setblock 49 217 614 minecraft:sea_lantern
setblock 49 217 616 minecraft:sea_lantern
setblock 49 217 618 minecraft:sea_lantern
setblock 49 217 620 minecraft:sea_lantern
setblock 49 217 622 minecraft:sea_lantern
setblock 50 217 615 minecraft:sea_lantern
setblock 50 217 617 minecraft:sea_lantern
setblock 50 217 619 minecraft:sea_lantern
setblock 50 217 621 minecraft:sea_lantern
setblock 51 217 604 minecraft:gray_concrete
setblock 51 217 614 minecraft:sea_lantern
setblock 51 217 616 minecraft:sea_lantern
setblock 51 217 618 minecraft:sea_lantern
setblock 51 217 620 minecraft:sea_lantern
setblock 51 217 622 minecraft:sea_lantern
setblock 52 217 615 minecraft:sea_lantern
setblock 52 217 617 minecraft:sea_lantern
setblock 52 217 619 minecraft:sea_lantern
setblock 52 217 621 minecraft:sea_lantern
setblock 52 217 641 minecraft:sea_lantern
setblock 52 217 643 minecraft:sea_lantern
setblock 52 217 645 minecraft:sea_lantern
setblock 53 217 604 minecraft:gray_concrete
setblock 53 217 614 minecraft:sea_lantern
setblock 53 217 616 minecraft:sea_lantern
setblock 53 217 618 minecraft:sea_lantern
setblock 53 217 620 minecraft:sea_lantern
setblock 53 217 622 minecraft:sea_lantern
setblock 53 217 642 minecraft:sea_lantern
setblock 53 217 644 minecraft:sea_lantern
setblock 54 217 615 minecraft:sea_lantern
setblock 54 217 617 minecraft:sea_lantern
setblock 54 217 619 minecraft:sea_lantern
setblock 54 217 621 minecraft:sea_lantern
setblock 54 217 641 minecraft:sea_lantern
setblock 54 217 643 minecraft:sea_lantern
setblock 54 217 645 minecraft:sea_lantern
setblock 55 217 614 minecraft:sea_lantern
setblock 55 217 616 minecraft:sea_lantern
setblock 55 217 618 minecraft:sea_lantern
setblock 55 217 620 minecraft:sea_lantern
setblock 55 217 622 minecraft:sea_lantern
setblock 55 217 642 minecraft:sea_lantern
setblock 55 217 644 minecraft:sea_lantern
setblock 56 217 615 minecraft:sea_lantern
setblock 56 217 617 minecraft:sea_lantern
setblock 56 217 619 minecraft:sea_lantern
setblock 56 217 621 minecraft:sea_lantern
setblock 56 217 641 minecraft:sea_lantern
setblock 56 217 643 minecraft:sea_lantern
setblock 56 217 645 minecraft:sea_lantern
setblock 56 217 646 minecraft:gray_concrete
fill 57 217 604 57 218 604 minecraft:black_concrete
fill 57 217 608 57 219 608 minecraft:magenta_concrete
setblock 57 217 642 minecraft:sea_lantern
setblock 57 217 644 minecraft:sea_lantern
fill 58 217 607 58 219 607 minecraft:magenta_concrete
fill 58 217 610 60 219 610 minecraft:magenta_concrete
setblock 58 217 641 minecraft:sea_lantern
setblock 58 217 643 minecraft:sea_lantern
setblock 58 217 645 minecraft:sea_lantern
fill 59 217 604 59 218 604 minecraft:black_concrete
setblock 59 217 642 minecraft:sea_lantern
setblock 59 217 644 minecraft:sea_lantern
fill 59 217 646 59 218 646 minecraft:black_concrete
fill 60 217 607 60 219 607 minecraft:magenta_concrete
setblock 60 217 641 minecraft:sea_lantern
setblock 60 217 643 minecraft:sea_lantern
setblock 60 217 645 minecraft:sea_lantern
fill 61 217 608 61 219 608 minecraft:magenta_concrete
setblock 61 217 642 minecraft:sea_lantern
setblock 61 217 644 minecraft:sea_lantern
setblock 62 217 641 minecraft:sea_lantern
setblock 62 217 643 minecraft:sea_lantern
setblock 62 217 645 minecraft:sea_lantern
fill 63 217 604 63 218 604 minecraft:black_concrete
fill 63 217 646 63 219 646 minecraft:black_concrete
setblock 64 217 604 minecraft:gray_concrete
fill 65 217 604 67 218 604 minecraft:black_concrete
fill 67 217 646 67 220 646 minecraft:black_concrete
setblock 68 217 646 minecraft:gray_concrete
setblock 69 217 604 minecraft:gray_concrete
fill 73 217 646 73 218 646 minecraft:black_concrete
setblock 74 217 637 minecraft:sea_lantern
setblock 74 217 639 minecraft:sea_lantern
setblock 74 217 641 minecraft:sea_lantern
setblock 74 217 643 minecraft:sea_lantern
setblock 74 217 645 minecraft:sea_lantern
setblock 75 217 638 minecraft:sea_lantern
setblock 75 217 640 minecraft:sea_lantern
setblock 75 217 642 minecraft:sea_lantern
setblock 75 217 644 minecraft:sea_lantern
setblock 76 217 637 minecraft:sea_lantern
setblock 76 217 639 minecraft:sea_lantern
setblock 76 217 641 minecraft:sea_lantern
setblock 76 217 643 minecraft:sea_lantern
setblock 76 217 645 minecraft:sea_lantern
setblock 77 217 638 minecraft:sea_lantern
setblock 77 217 640 minecraft:sea_lantern
setblock 77 217 642 minecraft:sea_lantern
setblock 77 217 644 minecraft:sea_lantern
setblock 78 217 637 minecraft:sea_lantern
setblock 78 217 639 minecraft:sea_lantern
setblock 78 217 641 minecraft:sea_lantern
setblock 78 217 643 minecraft:sea_lantern
setblock 78 217 645 minecraft:sea_lantern
setblock 79 217 638 minecraft:sea_lantern
setblock 79 217 640 minecraft:sea_lantern
setblock 79 217 642 minecraft:sea_lantern
setblock 79 217 644 minecraft:sea_lantern
setblock 80 217 637 minecraft:sea_lantern
setblock 80 217 639 minecraft:sea_lantern
setblock 80 217 641 minecraft:sea_lantern
setblock 80 217 643 minecraft:sea_lantern
setblock 80 217 645 minecraft:sea_lantern
setblock 81 217 638 minecraft:sea_lantern
setblock 81 217 640 minecraft:sea_lantern
setblock 81 217 642 minecraft:sea_lantern
setblock 81 217 644 minecraft:sea_lantern
setblock 82 217 637 minecraft:sea_lantern
setblock 82 217 639 minecraft:sea_lantern
setblock 82 217 641 minecraft:sea_lantern
setblock 82 217 643 minecraft:sea_lantern
setblock 82 217 645 minecraft:sea_lantern
setblock 83 217 638 minecraft:sea_lantern
setblock 83 217 640 minecraft:sea_lantern
setblock 83 217 642 minecraft:sea_lantern
setblock 83 217 644 minecraft:sea_lantern
setblock 84 217 637 minecraft:sea_lantern
setblock 84 217 639 minecraft:sea_lantern
setblock 84 217 641 minecraft:sea_lantern
setblock 84 217 643 minecraft:sea_lantern
setblock 84 217 645 minecraft:sea_lantern
fill 87 217 646 87 218 646 minecraft:black_concrete
setblock 88 217 646 minecraft:gray_concrete
setblock 89 217 616 minecraft:gray_concrete
setblock 89 217 626 minecraft:gray_concrete
fill 89 217 627 89 218 631 minecraft:black_concrete
setblock 89 217 632 minecraft:gray_concrete
setblock 47 218 612 minecraft:black_concrete
setblock 47 218 627 minecraft:black_concrete
fill 48 218 615 48 219 615 minecraft:light_gray_concrete
fill 48 218 617 48 219 617 minecraft:light_gray_concrete
fill 48 218 619 48 219 619 minecraft:light_gray_concrete
fill 48 218 621 48 219 621 minecraft:light_gray_concrete
fill 49 218 614 49 219 614 minecraft:light_gray_concrete
fill 49 218 616 49 219 616 minecraft:light_gray_concrete
fill 49 218 618 49 219 618 minecraft:light_gray_concrete
fill 49 218 620 49 219 620 minecraft:light_gray_concrete
fill 49 218 622 49 219 622 minecraft:light_gray_concrete
fill 50 218 615 50 219 615 minecraft:light_gray_concrete
fill 50 218 617 50 219 617 minecraft:light_gray_concrete
fill 50 218 619 50 219 619 minecraft:light_gray_concrete
fill 50 218 621 50 219 621 minecraft:light_gray_concrete
setblock 51 218 604 minecraft:black_concrete
fill 51 218 614 51 219 614 minecraft:light_gray_concrete
fill 51 218 616 51 219 616 minecraft:light_gray_concrete
fill 51 218 618 51 219 618 minecraft:light_gray_concrete
fill 51 218 620 51 219 620 minecraft:light_gray_concrete
fill 51 218 622 51 219 622 minecraft:light_gray_concrete
fill 52 218 615 52 219 615 minecraft:light_gray_concrete
fill 52 218 617 52 219 617 minecraft:light_gray_concrete
fill 52 218 619 52 219 619 minecraft:light_gray_concrete
fill 52 218 621 52 219 621 minecraft:light_gray_concrete
fill 52 218 641 52 219 641 minecraft:light_gray_concrete
fill 52 218 643 52 219 643 minecraft:light_gray_concrete
fill 52 218 645 52 219 645 minecraft:light_gray_concrete
fill 53 218 604 53 219 604 minecraft:black_concrete
fill 53 218 614 53 219 614 minecraft:light_gray_concrete
fill 53 218 616 53 219 616 minecraft:light_gray_concrete
fill 53 218 618 53 219 618 minecraft:light_gray_concrete
fill 53 218 620 53 219 620 minecraft:light_gray_concrete
fill 53 218 622 53 219 622 minecraft:light_gray_concrete
fill 53 218 642 53 219 642 minecraft:light_gray_concrete
fill 53 218 644 53 219 644 minecraft:light_gray_concrete
fill 54 218 615 54 219 615 minecraft:light_gray_concrete
fill 54 218 617 54 219 617 minecraft:light_gray_concrete
fill 54 218 619 54 219 619 minecraft:light_gray_concrete
fill 54 218 621 54 219 621 minecraft:light_gray_concrete
fill 54 218 641 54 219 641 minecraft:light_gray_concrete
fill 54 218 643 54 219 643 minecraft:light_gray_concrete
fill 54 218 645 54 219 645 minecraft:light_gray_concrete
fill 55 218 614 55 219 614 minecraft:light_gray_concrete
fill 55 218 616 55 219 616 minecraft:light_gray_concrete
fill 55 218 618 55 219 618 minecraft:light_gray_concrete
fill 55 218 620 55 219 620 minecraft:light_gray_concrete
fill 55 218 622 55 219 622 minecraft:light_gray_concrete
fill 55 218 642 55 219 642 minecraft:light_gray_concrete
fill 55 218 644 55 219 644 minecraft:light_gray_concrete
fill 56 218 615 56 219 615 minecraft:light_gray_concrete
fill 56 218 617 56 219 617 minecraft:light_gray_concrete
fill 56 218 619 56 219 619 minecraft:light_gray_concrete
fill 56 218 621 56 219 621 minecraft:light_gray_concrete
fill 56 218 641 56 219 641 minecraft:light_gray_concrete
fill 56 218 643 56 219 643 minecraft:light_gray_concrete
fill 56 218 645 56 219 645 minecraft:light_gray_concrete
setblock 56 218 646 minecraft:black_concrete
fill 57 218 607 57 219 607 minecraft:magenta_concrete
fill 57 218 609 57 219 609 minecraft:magenta_concrete
fill 57 218 642 57 219 642 minecraft:light_gray_concrete
fill 57 218 644 57 219 644 minecraft:light_gray_concrete
fill 58 218 606 60 219 606 minecraft:magenta_concrete
fill 58 218 641 58 219 641 minecraft:light_gray_concrete
fill 58 218 643 58 219 643 minecraft:light_gray_concrete
fill 58 218 645 58 219 645 minecraft:light_gray_concrete
fill 59 218 642 59 219 642 minecraft:light_gray_concrete
fill 59 218 644 59 219 644 minecraft:light_gray_concrete
fill 60 218 641 60 219 641 minecraft:light_gray_concrete
fill 60 218 643 60 219 643 minecraft:light_gray_concrete
fill 60 218 645 60 219 645 minecraft:light_gray_concrete
fill 61 218 607 61 219 607 minecraft:magenta_concrete
fill 61 218 609 61 219 609 minecraft:magenta_concrete
fill 61 218 642 61 219 642 minecraft:light_gray_concrete
fill 61 218 644 61 219 644 minecraft:light_gray_concrete
fill 62 218 641 62 219 641 minecraft:light_gray_concrete
fill 62 218 643 62 219 643 minecraft:light_gray_concrete
fill 62 218 645 62 219 645 minecraft:light_gray_concrete
setblock 64 218 604 minecraft:black_concrete
setblock 68 218 646 minecraft:black_concrete
setblock 69 218 604 minecraft:black_concrete
setblock 74 218 637 minecraft:light_gray_concrete
setblock 74 218 639 minecraft:light_gray_concrete
setblock 74 218 641 minecraft:light_gray_concrete
setblock 74 218 643 minecraft:light_gray_concrete
setblock 74 218 645 minecraft:light_gray_concrete
setblock 75 218 638 minecraft:light_gray_concrete
setblock 75 218 640 minecraft:light_gray_concrete
setblock 75 218 642 minecraft:light_gray_concrete
setblock 75 218 644 minecraft:light_gray_concrete
setblock 76 218 637 minecraft:light_gray_concrete
setblock 76 218 639 minecraft:light_gray_concrete
setblock 76 218 641 minecraft:light_gray_concrete
setblock 76 218 643 minecraft:light_gray_concrete
setblock 76 218 645 minecraft:light_gray_concrete
setblock 76 218 646 minecraft:black_concrete
setblock 77 218 638 minecraft:light_gray_concrete
setblock 77 218 640 minecraft:light_gray_concrete
setblock 77 218 642 minecraft:light_gray_concrete
setblock 77 218 644 minecraft:light_gray_concrete
setblock 78 218 637 minecraft:light_gray_concrete
setblock 78 218 639 minecraft:light_gray_concrete
setblock 78 218 641 minecraft:light_gray_concrete
setblock 78 218 643 minecraft:light_gray_concrete
fill 78 218 645 78 235 645 minecraft:light_gray_concrete
setblock 79 218 638 minecraft:light_gray_concrete
setblock 79 218 640 minecraft:light_gray_concrete
setblock 79 218 642 minecraft:light_gray_concrete
setblock 79 218 644 minecraft:light_gray_concrete
setblock 80 218 637 minecraft:light_gray_concrete
setblock 80 218 639 minecraft:light_gray_concrete
setblock 80 218 641 minecraft:light_gray_concrete
setblock 80 218 643 minecraft:light_gray_concrete
setblock 80 218 645 minecraft:light_gray_concrete
setblock 81 218 638 minecraft:light_gray_concrete
setblock 81 218 640 minecraft:light_gray_concrete
setblock 81 218 642 minecraft:light_gray_concrete
setblock 81 218 644 minecraft:light_gray_concrete
setblock 82 218 637 minecraft:light_gray_concrete
setblock 82 218 639 minecraft:light_gray_concrete
setblock 82 218 641 minecraft:light_gray_concrete
setblock 82 218 643 minecraft:light_gray_concrete
setblock 82 218 645 minecraft:light_gray_concrete
setblock 83 218 638 minecraft:light_gray_concrete
setblock 83 218 640 minecraft:light_gray_concrete
setblock 83 218 642 minecraft:light_gray_concrete
setblock 83 218 644 minecraft:light_gray_concrete
setblock 84 218 637 minecraft:light_gray_concrete
setblock 84 218 639 minecraft:light_gray_concrete
setblock 84 218 641 minecraft:light_gray_concrete
setblock 84 218 643 minecraft:light_gray_concrete
setblock 84 218 645 minecraft:light_gray_concrete
setblock 85 218 604 minecraft:black_concrete
fill 88 218 646 89 218 646 minecraft:black_concrete
fill 89 218 616 89 219 616 minecraft:black_concrete
setblock 89 218 626 minecraft:black_concrete
fill 89 218 632 89 219 632 minecraft:black_concrete
fill 47 219 604 47 307 608 minecraft:gray_concrete
fill 47 219 610 47 219 616 minecraft:gray_concrete
fill 47 219 618 47 307 618 minecraft:gray_concrete
setblock 47 219 619 minecraft:black_concrete
fill 47 219 620 47 219 624 minecraft:gray_concrete
fill 47 219 626 47 220 628 minecraft:gray_concrete
setblock 47 219 629 minecraft:black_concrete
fill 47 219 630 47 307 631 minecraft:gray_concrete
setblock 47 219 632 minecraft:black_concrete
fill 47 219 634 47 219 640 minecraft:gray_concrete
fill 47 219 643 47 219 646 minecraft:gray_concrete
fill 48 219 604 51 307 604 minecraft:gray_concrete
fill 48 219 646 49 307 646 minecraft:gray_concrete
setblock 50 219 607 minecraft:light[level=14]
setblock 50 219 623 minecraft:light[level=14]
setblock 50 219 631 minecraft:light[level=14]
setblock 50 219 639 minecraft:light[level=14]
fill 52 219 646 57 220 646 minecraft:gray_concrete
fill 55 219 604 61 219 604 minecraft:gray_concrete
fill 56 219 608 56 219 609 minecraft:magenta_concrete
setblock 57 219 606 minecraft:magenta_concrete
setblock 57 219 610 minecraft:magenta_concrete
fill 58 219 611 60 219 611 minecraft:magenta_concrete
setblock 58 219 615 minecraft:light[level=14]
setblock 58 219 623 minecraft:light[level=14]
setblock 58 219 631 minecraft:light[level=14]
setblock 58 219 639 minecraft:light[level=14]
fill 59 219 646 62 220 646 minecraft:gray_concrete
setblock 61 219 606 minecraft:magenta_concrete
setblock 61 219 610 minecraft:magenta_concrete
fill 63 219 604 64 307 604 minecraft:gray_concrete
fill 64 219 646 65 307 646 minecraft:gray_concrete
setblock 65 219 604 minecraft:black_concrete
fill 66 219 604 69 219 604 minecraft:gray_concrete
setblock 66 219 615 minecraft:light[level=14]
setblock 66 219 623 minecraft:light[level=14]
setblock 66 219 631 minecraft:light[level=14]
setblock 66 219 639 minecraft:light[level=14]
fill 68 219 646 73 219 646 minecraft:gray_concrete
fill 71 219 604 77 220 604 minecraft:gray_concrete
setblock 74 219 615 minecraft:light[level=14]
setblock 74 219 623 minecraft:light[level=14]
setblock 74 219 631 minecraft:light[level=14]
setblock 74 219 639 minecraft:light[level=14]
fill 75 219 646 80 220 646 minecraft:gray_concrete
fill 79 219 604 85 219 604 minecraft:gray_concrete
setblock 82 219 607 minecraft:light[level=14]
setblock 82 219 615 minecraft:light[level=14]
setblock 82 219 623 minecraft:light[level=14]
setblock 82 219 631 minecraft:light[level=14]
setblock 82 219 639 minecraft:light[level=14]
fill 84 219 646 87 307 646 minecraft:gray_concrete
fill 85 219 636 85 224 636 minecraft:magenta_concrete
fill 87 219 604 88 219 604 minecraft:gray_concrete
setblock 88 219 646 minecraft:black_concrete
fill 89 219 605 89 220 607 minecraft:gray_concrete
setblock 89 219 608 minecraft:black_concrete
fill 89 219 610 89 307 610 minecraft:gray_concrete
setblock 89 219 611 minecraft:black_concrete
fill 89 219 612 89 219 613 minecraft:gray_concrete
setblock 89 219 614 minecraft:black_concrete
fill 89 219 615 89 307 615 minecraft:gray_concrete
fill 89 219 618 89 220 624 minecraft:gray_concrete
setblock 89 219 626 minecraft:gray_concrete
setblock 89 219 627 minecraft:black_concrete
fill 89 219 628 89 219 631 minecraft:gray_concrete
fill 89 219 634 89 220 639 minecraft:gray_concrete
setblock 89 219 640 minecraft:black_concrete
fill 89 219 642 89 307 643 minecraft:gray_concrete
fill 89 219 645 89 307 646 minecraft:gray_concrete
setblock 47 220 609 minecraft:black_concrete
fill 47 220 610 47 220 611 minecraft:gray_concrete
setblock 47 220 612 minecraft:black_concrete
fill 47 220 613 47 227 617 minecraft:gray_concrete
fill 47 220 619 47 307 619 minecraft:gray_concrete
setblock 47 220 620 minecraft:black_concrete
fill 47 220 621 47 307 622 minecraft:gray_concrete
setblock 47 220 623 minecraft:black_concrete
fill 47 220 624 47 307 624 minecraft:gray_concrete
setblock 47 220 625 minecraft:black_concrete
fill 47 220 629 47 307 629 minecraft:gray_concrete
fill 47 220 632 47 227 634 minecraft:gray_concrete
setblock 47 220 635 minecraft:black_concrete
fill 47 220 636 47 227 643 minecraft:gray_concrete
setblock 47 220 644 minecraft:black_concrete
fill 47 220 645 47 307 645 minecraft:gray_concrete
setblock 47 220 646 minecraft:black_concrete
setblock 48 220 615 minecraft:sea_lantern
setblock 48 220 617 minecraft:sea_lantern
setblock 48 220 619 minecraft:sea_lantern
setblock 48 220 621 minecraft:sea_lantern
setblock 49 220 614 minecraft:sea_lantern
setblock 49 220 616 minecraft:sea_lantern
setblock 49 220 618 minecraft:sea_lantern
setblock 49 220 620 minecraft:sea_lantern
setblock 49 220 622 minecraft:sea_lantern
setblock 50 220 615 minecraft:sea_lantern
setblock 50 220 617 minecraft:sea_lantern
setblock 50 220 619 minecraft:sea_lantern
setblock 50 220 621 minecraft:sea_lantern
fill 50 220 646 51 220 646 minecraft:gray_concrete
setblock 51 220 614 minecraft:sea_lantern
setblock 51 220 616 minecraft:sea_lantern
setblock 51 220 618 minecraft:sea_lantern
setblock 51 220 620 minecraft:sea_lantern
setblock 51 220 622 minecraft:sea_lantern
fill 52 220 604 60 220 604 minecraft:gray_concrete
setblock 52 220 615 minecraft:sea_lantern
setblock 52 220 617 minecraft:sea_lantern
setblock 52 220 619 minecraft:sea_lantern
setblock 52 220 621 minecraft:sea_lantern
setblock 52 220 641 minecraft:sea_lantern
setblock 52 220 643 minecraft:sea_lantern
setblock 52 220 645 minecraft:sea_lantern
fill 53 220 605 56 222 612 minecraft:light_gray_concrete
setblock 53 220 614 minecraft:sea_lantern
setblock 53 220 616 minecraft:sea_lantern
setblock 53 220 618 minecraft:sea_lantern
setblock 53 220 620 minecraft:sea_lantern
setblock 53 220 622 minecraft:sea_lantern
setblock 53 220 642 minecraft:sea_lantern
setblock 53 220 644 minecraft:sea_lantern
setblock 54 220 615 minecraft:sea_lantern
setblock 54 220 617 minecraft:sea_lantern
setblock 54 220 619 minecraft:sea_lantern
setblock 54 220 621 minecraft:sea_lantern
setblock 54 220 641 minecraft:sea_lantern
setblock 54 220 643 minecraft:sea_lantern
setblock 54 220 645 minecraft:sea_lantern
setblock 55 220 614 minecraft:sea_lantern
setblock 55 220 616 minecraft:sea_lantern
setblock 55 220 618 minecraft:sea_lantern
setblock 55 220 620 minecraft:sea_lantern
setblock 55 220 622 minecraft:sea_lantern
setblock 55 220 642 minecraft:sea_lantern
setblock 55 220 644 minecraft:sea_lantern
setblock 56 220 615 minecraft:sea_lantern
setblock 56 220 617 minecraft:sea_lantern
setblock 56 220 619 minecraft:sea_lantern
setblock 56 220 621 minecraft:sea_lantern
setblock 56 220 641 minecraft:sea_lantern
setblock 56 220 643 minecraft:sea_lantern
setblock 56 220 645 minecraft:sea_lantern
fill 57 220 606 61 222 612 minecraft:light_gray_concrete
setblock 57 220 642 minecraft:sea_lantern
setblock 57 220 644 minecraft:sea_lantern
setblock 58 220 641 minecraft:sea_lantern
setblock 58 220 643 minecraft:sea_lantern
setblock 58 220 645 minecraft:sea_lantern
fill 58 220 646 58 227 646 minecraft:gray_concrete
fill 59 220 605 61 222 605 minecraft:light_gray_concrete
setblock 59 220 642 minecraft:sea_lantern
setblock 59 220 644 minecraft:sea_lantern
setblock 60 220 641 minecraft:sea_lantern
setblock 60 220 643 minecraft:sea_lantern
setblock 60 220 645 minecraft:sea_lantern
setblock 61 220 604 minecraft:black_concrete
setblock 61 220 642 minecraft:sea_lantern
setblock 61 220 644 minecraft:sea_lantern
fill 62 220 604 62 227 604 minecraft:gray_concrete
setblock 62 220 641 minecraft:sea_lantern
setblock 62 220 643 minecraft:sea_lantern
setblock 62 220 645 minecraft:sea_lantern
fill 63 220 646 63 307 646 minecraft:gray_concrete
fill 65 220 604 65 307 604 minecraft:gray_concrete
fill 66 220 604 67 220 604 minecraft:black_concrete
fill 66 220 646 66 227 646 minecraft:gray_concrete
fill 68 220 604 70 227 604 minecraft:gray_concrete
fill 68 220 646 68 221 646 minecraft:black_concrete
fill 69 220 646 74 227 646 minecraft:gray_concrete
fill 78 220 604 81 220 604 minecraft:gray_concrete
fill 81 220 646 81 307 646 minecraft:gray_concrete
setblock 82 220 604 minecraft:black_concrete
setblock 82 220 646 minecraft:black_concrete
fill 83 220 604 87 227 604 minecraft:gray_concrete
fill 83 220 646 83 307 646 minecraft:gray_concrete
setblock 88 220 604 minecraft:black_concrete
fill 88 220 646 88 307 646 minecraft:gray_concrete
fill 89 220 604 89 307 604 minecraft:gray_concrete
fill 89 220 608 89 227 609 minecraft:gray_concrete
fill 89 220 611 89 307 612 minecraft:gray_concrete
setblock 89 220 613 minecraft:black_concrete
fill 89 220 614 89 307 614 minecraft:gray_concrete
fill 89 220 616 89 227 617 minecraft:gray_concrete
fill 89 220 625 89 227 625 minecraft:gray_concrete
setblock 89 220 626 minecraft:black_concrete
fill 89 220 627 89 220 629 minecraft:gray_concrete
fill 89 220 630 89 220 631 minecraft:black_concrete
fill 89 220 632 89 220 633 minecraft:gray_concrete
fill 89 220 640 89 227 641 minecraft:gray_concrete
fill 89 220 644 89 307 644 minecraft:gray_concrete
fill 47 221 609 47 227 610 minecraft:gray_concrete
setblock 47 221 611 minecraft:black_concrete
fill 47 221 612 47 307 612 minecraft:gray_concrete
fill 47 221 620 47 307 620 minecraft:gray_concrete
fill 47 221 623 47 307 623 minecraft:gray_concrete
fill 47 221 625 47 227 627 minecraft:gray_concrete
setblock 47 221 628 minecraft:black_concrete
fill 47 221 635 47 307 635 minecraft:gray_concrete
fill 47 221 644 47 307 644 minecraft:gray_concrete
fill 47 221 646 47 307 646 minecraft:gray_concrete
fill 48 221 615 48 222 615 minecraft:light_gray_concrete
fill 48 221 617 48 222 617 minecraft:light_gray_concrete
fill 48 221 619 48 222 619 minecraft:light_gray_concrete
fill 48 221 621 48 222 621 minecraft:light_gray_concrete
fill 49 221 614 49 222 614 minecraft:light_gray_concrete
fill 49 221 616 49 222 616 minecraft:light_gray_concrete
fill 49 221 618 49 222 618 minecraft:light_gray_concrete
fill 49 221 620 49 222 620 minecraft:light_gray_concrete
fill 49 221 622 49 222 622 minecraft:light_gray_concrete
fill 50 221 615 50 222 615 minecraft:light_gray_concrete
fill 50 221 617 50 222 617 minecraft:light_gray_concrete
fill 50 221 619 50 222 619 minecraft:light_gray_concrete
fill 50 221 621 50 222 621 minecraft:light_gray_concrete
fill 50 221 646 50 227 646 minecraft:gray_concrete
fill 51 221 614 51 222 614 minecraft:light_gray_concrete
fill 51 221 616 51 222 616 minecraft:light_gray_concrete
fill 51 221 618 51 222 618 minecraft:light_gray_concrete
fill 51 221 620 51 222 620 minecraft:light_gray_concrete
fill 51 221 622 51 222 622 minecraft:light_gray_concrete
setblock 51 221 646 minecraft:black_concrete
fill 52 221 604 59 227 604 minecraft:gray_concrete
fill 52 221 615 52 222 615 minecraft:light_gray_concrete
fill 52 221 617 52 222 617 minecraft:light_gray_concrete
fill 52 221 619 52 222 619 minecraft:light_gray_concrete
fill 52 221 621 52 222 621 minecraft:light_gray_concrete
fill 52 221 641 52 222 641 minecraft:light_gray_concrete
fill 52 221 643 52 222 643 minecraft:light_gray_concrete
fill 52 221 645 52 222 645 minecraft:light_gray_concrete
fill 52 221 646 54 307 646 minecraft:gray_concrete
fill 53 221 614 53 222 614 minecraft:light_gray_concrete
fill 53 221 616 53 222 616 minecraft:light_gray_concrete
fill 53 221 618 53 222 618 minecraft:light_gray_concrete
fill 53 221 620 53 222 620 minecraft:light_gray_concrete
fill 53 221 622 53 222 622 minecraft:light_gray_concrete
fill 53 221 642 53 222 642 minecraft:light_gray_concrete
fill 53 221 644 53 222 644 minecraft:light_gray_concrete
fill 54 221 615 54 222 615 minecraft:light_gray_concrete
fill 54 221 617 54 222 617 minecraft:light_gray_concrete
fill 54 221 619 54 222 619 minecraft:light_gray_concrete
fill 54 221 621 54 222 621 minecraft:light_gray_concrete
fill 54 221 641 54 222 641 minecraft:light_gray_concrete
fill 54 221 643 54 222 643 minecraft:light_gray_concrete
fill 54 221 645 54 222 645 minecraft:light_gray_concrete
fill 55 221 614 55 222 614 minecraft:light_gray_concrete
fill 55 221 616 55 222 616 minecraft:light_gray_concrete
fill 55 221 618 55 222 618 minecraft:light_gray_concrete
fill 55 221 620 55 222 620 minecraft:light_gray_concrete
fill 55 221 622 55 222 622 minecraft:light_gray_concrete
fill 55 221 642 55 222 642 minecraft:light_gray_concrete
fill 55 221 644 55 222 644 minecraft:light_gray_concrete
setblock 55 221 646 minecraft:black_concrete
fill 56 221 615 56 222 615 minecraft:light_gray_concrete
fill 56 221 617 56 222 617 minecraft:light_gray_concrete
fill 56 221 619 56 222 619 minecraft:light_gray_concrete
fill 56 221 621 56 222 621 minecraft:light_gray_concrete
fill 56 221 641 56 222 641 minecraft:light_gray_concrete
fill 56 221 643 56 222 643 minecraft:light_gray_concrete
fill 56 221 645 56 222 645 minecraft:light_gray_concrete
fill 56 221 646 57 307 646 minecraft:gray_concrete
fill 57 221 642 57 222 642 minecraft:light_gray_concrete
fill 57 221 644 57 222 644 minecraft:light_gray_concrete
fill 58 221 641 58 222 641 minecraft:light_gray_concrete
fill 58 221 643 58 222 643 minecraft:light_gray_concrete
fill 58 221 645 58 222 645 minecraft:light_gray_concrete
fill 59 221 642 59 222 642 minecraft:light_gray_concrete
fill 59 221 644 59 222 644 minecraft:light_gray_concrete
fill 59 221 646 59 307 646 minecraft:gray_concrete
setblock 60 221 604 minecraft:black_concrete
fill 60 221 641 60 222 641 minecraft:light_gray_concrete
fill 60 221 643 60 222 643 minecraft:light_gray_concrete
fill 60 221 645 60 222 645 minecraft:light_gray_concrete
fill 60 221 646 61 221 646 minecraft:black_concrete
fill 61 221 604 61 307 604 minecraft:gray_concrete
fill 61 221 642 61 222 642 minecraft:light_gray_concrete
fill 61 221 644 61 222 644 minecraft:light_gray_concrete
fill 62 221 605 65 222 612 minecraft:light_gray_concrete
fill 62 221 641 62 222 641 minecraft:light_gray_concrete
fill 62 221 643 62 222 643 minecraft:light_gray_concrete
fill 62 221 645 62 222 645 minecraft:light_gray_concrete
fill 62 221 646 62 307 646 minecraft:gray_concrete
fill 66 221 604 67 307 604 minecraft:gray_concrete
fill 66 221 605 66 235 605 minecraft:light_gray_concrete
fill 67 221 646 67 307 646 minecraft:gray_concrete
fill 71 221 604 72 307 604 minecraft:gray_concrete
fill 73 221 604 74 221 604 minecraft:black_concrete
fill 73 221 605 74 235 605 minecraft:light_gray_concrete
fill 75 221 604 75 307 604 minecraft:gray_concrete
fill 75 221 646 78 307 646 minecraft:gray_concrete
setblock 76 221 604 minecraft:black_concrete
fill 77 221 604 77 307 604 minecraft:gray_concrete
setblock 78 221 604 minecraft:black_concrete
fill 79 221 604 82 307 604 minecraft:gray_concrete
setblock 79 221 646 minecraft:black_concrete
fill 80 221 646 80 307 646 minecraft:gray_concrete
fill 82 221 646 82 227 646 minecraft:gray_concrete
fill 84 221 633 84 222 634 minecraft:glass
fill 84 221 636 84 224 636 minecraft:magenta_concrete
fill 85 221 633 85 222 633 minecraft:glass
fill 85 221 635 85 224 635 minecraft:magenta_concrete
fill 85 221 637 85 224 637 minecraft:magenta_concrete
fill 88 221 604 88 307 604 minecraft:gray_concrete
fill 89 221 605 89 307 606 minecraft:gray_concrete
setblock 89 221 607 minecraft:black_concrete
fill 89 221 613 89 307 613 minecraft:gray_concrete
fill 89 221 618 89 307 623 minecraft:gray_concrete
setblock 89 221 624 minecraft:black_concrete
fill 89 221 626 89 307 626 minecraft:gray_concrete
fill 89 221 627 89 221 628 minecraft:black_concrete
fill 89 221 629 89 307 631 minecraft:gray_concrete
setblock 89 221 632 minecraft:black_concrete
fill 89 221 633 89 227 633 minecraft:gray_concrete
setblock 89 221 634 minecraft:black_concrete
fill 89 221 635 89 307 636 minecraft:gray_concrete
setblock 89 221 637 minecraft:black_concrete
fill 89 221 638 89 307 639 minecraft:gray_concrete
fill 47 222 611 47 307 611 minecraft:gray_concrete
fill 47 222 628 47 307 628 minecraft:gray_concrete
fill 51 222 646 51 307 646 minecraft:gray_concrete
fill 55 222 646 55 307 646 minecraft:gray_concrete
fill 60 222 604 60 307 604 minecraft:gray_concrete
fill 60 222 646 61 307 646 minecraft:gray_concrete
fill 68 222 646 68 307 646 minecraft:gray_concrete
fill 73 222 604 74 307 604 minecraft:gray_concrete
fill 76 222 604 76 307 604 minecraft:gray_concrete
fill 78 222 604 78 227 604 minecraft:gray_concrete
fill 79 222 646 79 307 646 minecraft:gray_concrete
fill 84 222 635 84 224 635 minecraft:magenta_concrete
fill 84 222 637 84 224 637 minecraft:magenta_concrete
fill 86 222 636 86 224 636 minecraft:magenta_concrete
fill 89 222 607 89 307 607 minecraft:gray_concrete
fill 89 222 624 89 307 624 minecraft:gray_concrete
fill 89 222 627 89 307 628 minecraft:gray_concrete
fill 89 222 632 89 307 632 minecraft:gray_concrete
fill 89 222 634 89 307 634 minecraft:gray_concrete
fill 89 222 637 89 307 637 minecraft:gray_concrete
setblock 48 223 615 minecraft:sea_lantern
setblock 48 223 617 minecraft:sea_lantern
setblock 48 223 619 minecraft:sea_lantern
setblock 48 223 621 minecraft:sea_lantern
setblock 49 223 614 minecraft:sea_lantern
setblock 49 223 616 minecraft:sea_lantern
setblock 49 223 618 minecraft:sea_lantern
setblock 49 223 620 minecraft:sea_lantern
setblock 49 223 622 minecraft:sea_lantern
setblock 50 223 615 minecraft:sea_lantern
setblock 50 223 617 minecraft:sea_lantern
setblock 50 223 619 minecraft:sea_lantern
setblock 50 223 621 minecraft:sea_lantern
setblock 51 223 614 minecraft:sea_lantern
setblock 51 223 616 minecraft:sea_lantern
setblock 51 223 618 minecraft:sea_lantern
setblock 51 223 620 minecraft:sea_lantern
setblock 51 223 622 minecraft:sea_lantern
setblock 52 223 615 minecraft:sea_lantern
setblock 52 223 617 minecraft:sea_lantern
setblock 52 223 619 minecraft:sea_lantern
setblock 52 223 621 minecraft:sea_lantern
setblock 52 223 641 minecraft:sea_lantern
setblock 52 223 643 minecraft:sea_lantern
setblock 52 223 645 minecraft:sea_lantern
fill 53 223 605 53 235 605 minecraft:light_gray_concrete
setblock 53 223 606 minecraft:sea_lantern
fill 53 223 607 53 235 607 minecraft:light_gray_concrete
setblock 53 223 608 minecraft:sea_lantern
fill 53 223 609 53 235 609 minecraft:light_gray_concrete
setblock 53 223 610 minecraft:sea_lantern
fill 53 223 611 53 235 611 minecraft:light_gray_concrete
setblock 53 223 612 minecraft:sea_lantern
setblock 53 223 614 minecraft:sea_lantern
setblock 53 223 616 minecraft:sea_lantern
setblock 53 223 618 minecraft:sea_lantern
setblock 53 223 620 minecraft:sea_lantern
setblock 53 223 622 minecraft:sea_lantern
setblock 53 223 642 minecraft:sea_lantern
setblock 53 223 644 minecraft:sea_lantern
setblock 54 223 605 minecraft:sea_lantern
fill 54 223 606 54 235 606 minecraft:light_gray_concrete
setblock 54 223 607 minecraft:sea_lantern
fill 54 223 608 54 235 608 minecraft:light_gray_concrete
setblock 54 223 609 minecraft:sea_lantern
fill 54 223 610 54 235 610 minecraft:light_gray_concrete
setblock 54 223 611 minecraft:sea_lantern
fill 54 223 612 54 235 612 minecraft:light_gray_concrete
setblock 54 223 615 minecraft:sea_lantern
setblock 54 223 617 minecraft:sea_lantern
setblock 54 223 619 minecraft:sea_lantern
setblock 54 223 621 minecraft:sea_lantern
setblock 54 223 641 minecraft:sea_lantern
setblock 54 223 643 minecraft:sea_lantern
setblock 54 223 645 minecraft:sea_lantern
fill 55 223 605 55 235 605 minecraft:light_gray_concrete
setblock 55 223 606 minecraft:sea_lantern
fill 55 223 607 55 235 607 minecraft:light_gray_concrete
setblock 55 223 608 minecraft:sea_lantern
fill 55 223 609 55 235 609 minecraft:light_gray_concrete
setblock 55 223 610 minecraft:sea_lantern
fill 55 223 611 55 235 611 minecraft:light_gray_concrete
setblock 55 223 612 minecraft:sea_lantern
setblock 55 223 614 minecraft:sea_lantern
setblock 55 223 616 minecraft:sea_lantern
setblock 55 223 618 minecraft:sea_lantern
setblock 55 223 620 minecraft:sea_lantern
setblock 55 223 622 minecraft:sea_lantern
setblock 55 223 642 minecraft:sea_lantern
setblock 55 223 644 minecraft:sea_lantern
setblock 56 223 605 minecraft:sea_lantern
fill 56 223 606 56 235 606 minecraft:light_gray_concrete
setblock 56 223 607 minecraft:sea_lantern
fill 56 223 608 56 235 608 minecraft:light_gray_concrete
setblock 56 223 609 minecraft:sea_lantern
fill 56 223 610 56 235 610 minecraft:light_gray_concrete
setblock 56 223 611 minecraft:sea_lantern
fill 56 223 612 56 235 612 minecraft:light_gray_concrete
setblock 56 223 615 minecraft:sea_lantern
setblock 56 223 617 minecraft:sea_lantern
setblock 56 223 619 minecraft:sea_lantern
setblock 56 223 621 minecraft:sea_lantern
setblock 56 223 641 minecraft:sea_lantern
setblock 56 223 643 minecraft:sea_lantern
setblock 56 223 645 minecraft:sea_lantern
fill 57 223 605 57 235 605 minecraft:light_gray_concrete
setblock 57 223 606 minecraft:sea_lantern
fill 57 223 607 57 235 607 minecraft:light_gray_concrete
setblock 57 223 608 minecraft:sea_lantern
fill 57 223 609 57 235 609 minecraft:light_gray_concrete
setblock 57 223 610 minecraft:sea_lantern
fill 57 223 611 57 235 611 minecraft:light_gray_concrete
setblock 57 223 612 minecraft:sea_lantern
setblock 57 223 642 minecraft:sea_lantern
setblock 57 223 644 minecraft:sea_lantern
setblock 58 223 605 minecraft:sea_lantern
fill 58 223 606 58 235 606 minecraft:light_gray_concrete
setblock 58 223 607 minecraft:sea_lantern
fill 58 223 608 58 235 608 minecraft:light_gray_concrete
setblock 58 223 609 minecraft:sea_lantern
fill 58 223 610 58 235 610 minecraft:light_gray_concrete
setblock 58 223 611 minecraft:sea_lantern
fill 58 223 612 58 235 612 minecraft:light_gray_concrete
setblock 58 223 641 minecraft:sea_lantern
setblock 58 223 643 minecraft:sea_lantern
setblock 58 223 645 minecraft:sea_lantern
fill 59 223 605 59 235 605 minecraft:light_gray_concrete
setblock 59 223 606 minecraft:sea_lantern
fill 59 223 607 59 235 607 minecraft:light_gray_concrete
setblock 59 223 608 minecraft:sea_lantern
fill 59 223 609 59 235 609 minecraft:light_gray_concrete
setblock 59 223 610 minecraft:sea_lantern
fill 59 223 611 59 235 611 minecraft:light_gray_concrete
setblock 59 223 612 minecraft:sea_lantern
setblock 59 223 642 minecraft:sea_lantern
setblock 59 223 644 minecraft:sea_lantern
setblock 60 223 605 minecraft:sea_lantern
fill 60 223 606 60 235 606 minecraft:light_gray_concrete
setblock 60 223 607 minecraft:sea_lantern
fill 60 223 608 60 235 608 minecraft:light_gray_concrete
setblock 60 223 609 minecraft:sea_lantern
fill 60 223 610 60 235 610 minecraft:light_gray_concrete
setblock 60 223 611 minecraft:sea_lantern
fill 60 223 612 60 235 612 minecraft:light_gray_concrete
setblock 60 223 641 minecraft:sea_lantern
setblock 60 223 643 minecraft:sea_lantern
setblock 60 223 645 minecraft:sea_lantern
fill 61 223 605 61 235 605 minecraft:light_gray_concrete
setblock 61 223 606 minecraft:sea_lantern
fill 61 223 607 61 235 607 minecraft:light_gray_concrete
setblock 61 223 608 minecraft:sea_lantern
fill 61 223 609 61 235 609 minecraft:light_gray_concrete
setblock 61 223 610 minecraft:sea_lantern
fill 61 223 611 61 235 611 minecraft:light_gray_concrete
setblock 61 223 612 minecraft:sea_lantern
fill 61 223 619 62 224 620 minecraft:gray_concrete
setblock 61 223 642 minecraft:sea_lantern
setblock 61 223 644 minecraft:sea_lantern
setblock 62 223 605 minecraft:sea_lantern
fill 62 223 606 62 235 606 minecraft:light_gray_concrete
setblock 62 223 607 minecraft:sea_lantern
fill 62 223 608 62 235 608 minecraft:light_gray_concrete
setblock 62 223 609 minecraft:sea_lantern
fill 62 223 610 62 235 610 minecraft:light_gray_concrete
setblock 62 223 611 minecraft:sea_lantern
fill 62 223 612 62 235 612 minecraft:light_gray_concrete
setblock 62 223 641 minecraft:sea_lantern
setblock 62 223 643 minecraft:sea_lantern
setblock 62 223 645 minecraft:sea_lantern
fill 63 223 605 63 235 605 minecraft:light_gray_concrete
setblock 63 223 606 minecraft:sea_lantern
fill 63 223 607 63 235 607 minecraft:light_gray_concrete
setblock 63 223 608 minecraft:sea_lantern
fill 63 223 609 63 235 609 minecraft:light_gray_concrete
setblock 63 223 610 minecraft:sea_lantern
fill 63 223 611 63 235 611 minecraft:light_gray_concrete
setblock 63 223 612 minecraft:sea_lantern
setblock 64 223 605 minecraft:sea_lantern
fill 64 223 606 64 235 606 minecraft:light_gray_concrete
setblock 64 223 607 minecraft:sea_lantern
fill 64 223 608 64 235 608 minecraft:light_gray_concrete
setblock 64 223 609 minecraft:sea_lantern
fill 64 223 610 64 235 610 minecraft:light_gray_concrete
setblock 64 223 611 minecraft:sea_lantern
fill 64 223 612 64 235 612 minecraft:light_gray_concrete
fill 65 223 605 65 235 605 minecraft:light_gray_concrete
setblock 65 223 606 minecraft:sea_lantern
fill 65 223 607 65 235 607 minecraft:light_gray_concrete
setblock 65 223 608 minecraft:sea_lantern
fill 65 223 609 65 235 609 minecraft:light_gray_concrete
setblock 65 223 610 minecraft:sea_lantern
fill 65 223 611 65 235 611 minecraft:light_gray_concrete
setblock 65 223 612 minecraft:sea_lantern
fill 83 223 636 83 224 636 minecraft:magenta_concrete
fill 86 223 635 86 224 635 minecraft:magenta_concrete
fill 86 223 637 86 224 637 minecraft:magenta_concrete
fill 48 224 605 48 225 610 minecraft:light_gray_concrete
fill 48 224 613 49 224 613 minecraft:light_gray_concrete
fill 48 224 615 48 225 615 minecraft:light_gray_concrete
fill 48 224 617 48 225 617 minecraft:light_gray_concrete
fill 48 224 619 48 225 619 minecraft:light_gray_concrete
fill 48 224 621 48 225 621 minecraft:light_gray_concrete
fill 48 224 623 49 224 626 minecraft:light_gray_concrete
fill 48 224 629 49 224 634 minecraft:light_gray_concrete
fill 48 224 637 49 224 642 minecraft:light_gray_concrete
fill 48 224 645 52 225 645 minecraft:light_gray_concrete
fill 49 224 606 49 224 612 minecraft:light_gray_concrete
fill 49 224 614 49 225 614 minecraft:light_gray_concrete
fill 49 224 616 49 225 616 minecraft:light_gray_concrete
fill 49 224 618 49 225 618 minecraft:light_gray_concrete
fill 49 224 620 49 225 620 minecraft:light_gray_concrete
fill 49 224 622 49 225 622 minecraft:light_gray_concrete
fill 49 224 627 49 224 628 minecraft:light_gray_concrete
fill 49 224 635 49 224 636 minecraft:light_gray_concrete
fill 49 224 643 49 224 644 minecraft:light_gray_concrete
fill 50 224 606 53 224 606 minecraft:light_gray_concrete
fill 50 224 615 50 225 615 minecraft:light_gray_concrete
fill 50 224 617 50 225 617 minecraft:light_gray_concrete
fill 50 224 619 50 225 619 minecraft:light_gray_concrete
fill 50 224 621 50 225 621 minecraft:light_gray_concrete
fill 50 224 644 51 224 644 minecraft:light_gray_concrete
fill 51 224 605 52 225 605 minecraft:light_gray_concrete
fill 51 224 614 51 225 614 minecraft:light_gray_concrete
fill 51 224 616 51 225 616 minecraft:light_gray_concrete
fill 51 224 618 51 225 618 minecraft:light_gray_concrete
fill 51 224 620 51 225 620 minecraft:light_gray_concrete
fill 51 224 622 51 225 622 minecraft:light_gray_concrete
fill 52 224 615 52 225 615 minecraft:light_gray_concrete
fill 52 224 617 52 225 617 minecraft:light_gray_concrete
fill 52 224 619 52 225 619 minecraft:light_gray_concrete
fill 52 224 621 52 225 621 minecraft:light_gray_concrete
fill 52 224 641 52 225 641 minecraft:light_gray_concrete
fill 52 224 643 52 225 643 minecraft:light_gray_concrete
fill 53 224 608 53 225 608 minecraft:light_gray_concrete
fill 53 224 610 53 225 610 minecraft:light_gray_concrete
fill 53 224 612 53 225 612 minecraft:light_gray_concrete
fill 53 224 614 53 225 614 minecraft:light_gray_concrete
fill 53 224 616 53 225 616 minecraft:light_gray_concrete
fill 53 224 618 53 225 618 minecraft:light_gray_concrete
fill 53 224 620 53 225 620 minecraft:light_gray_concrete
fill 53 224 622 53 225 622 minecraft:light_gray_concrete
fill 53 224 642 53 225 642 minecraft:light_gray_concrete
fill 53 224 644 53 225 644 minecraft:light_gray_concrete
fill 54 224 605 54 225 605 minecraft:light_gray_concrete
fill 54 224 607 54 225 607 minecraft:light_gray_concrete
fill 54 224 609 54 225 609 minecraft:light_gray_concrete
fill 54 224 611 54 225 611 minecraft:light_gray_concrete
fill 54 224 615 54 225 615 minecraft:light_gray_concrete
fill 54 224 617 54 225 617 minecraft:light_gray_concrete
fill 54 224 619 54 225 619 minecraft:light_gray_concrete
fill 54 224 621 54 225 621 minecraft:light_gray_concrete
fill 54 224 641 54 225 641 minecraft:light_gray_concrete
fill 54 224 643 54 225 643 minecraft:light_gray_concrete
fill 54 224 645 54 225 645 minecraft:light_gray_concrete
fill 55 224 606 55 225 606 minecraft:light_gray_concrete
fill 55 224 608 55 225 608 minecraft:light_gray_concrete
fill 55 224 610 55 225 610 minecraft:light_gray_concrete
fill 55 224 612 55 225 612 minecraft:light_gray_concrete
fill 55 224 614 55 225 614 minecraft:light_gray_concrete
fill 55 224 616 55 225 616 minecraft:light_gray_concrete
fill 55 224 618 55 225 618 minecraft:light_gray_concrete
fill 55 224 620 55 225 620 minecraft:light_gray_concrete
fill 55 224 622 55 225 622 minecraft:light_gray_concrete
fill 55 224 642 55 225 642 minecraft:light_gray_concrete
fill 55 224 644 55 225 644 minecraft:light_gray_concrete
fill 56 224 605 56 225 605 minecraft:light_gray_concrete
fill 56 224 607 56 225 607 minecraft:light_gray_concrete
fill 56 224 609 56 225 609 minecraft:light_gray_concrete
fill 56 224 611 56 225 611 minecraft:light_gray_concrete
fill 56 224 615 56 225 615 minecraft:light_gray_concrete
fill 56 224 617 56 225 617 minecraft:light_gray_concrete
fill 56 224 619 56 225 619 minecraft:light_gray_concrete
fill 56 224 621 56 225 621 minecraft:light_gray_concrete
fill 56 224 641 56 225 641 minecraft:light_gray_concrete
fill 56 224 643 56 225 643 minecraft:light_gray_concrete
fill 56 224 645 56 225 645 minecraft:light_gray_concrete
fill 57 224 606 57 225 606 minecraft:light_gray_concrete
fill 57 224 608 57 225 608 minecraft:light_gray_concrete
fill 57 224 610 57 225 610 minecraft:light_gray_concrete
fill 57 224 612 57 225 612 minecraft:light_gray_concrete
fill 57 224 642 57 225 642 minecraft:light_gray_concrete
fill 57 224 644 57 225 644 minecraft:light_gray_concrete
fill 58 224 605 58 225 605 minecraft:light_gray_concrete
fill 58 224 607 58 225 607 minecraft:light_gray_concrete
fill 58 224 609 58 225 609 minecraft:light_gray_concrete
fill 58 224 611 58 225 611 minecraft:light_gray_concrete
fill 58 224 641 58 225 641 minecraft:light_gray_concrete
fill 58 224 643 58 225 643 minecraft:light_gray_concrete
fill 58 224 645 58 225 645 minecraft:light_gray_concrete
fill 59 224 606 59 225 606 minecraft:light_gray_concrete
fill 59 224 608 59 225 608 minecraft:light_gray_concrete
fill 59 224 610 59 225 610 minecraft:light_gray_concrete
fill 59 224 612 59 225 612 minecraft:light_gray_concrete
fill 59 224 642 59 225 642 minecraft:light_gray_concrete
fill 59 224 644 59 225 644 minecraft:light_gray_concrete
fill 60 224 605 60 225 605 minecraft:light_gray_concrete
fill 60 224 607 60 225 607 minecraft:light_gray_concrete
fill 60 224 609 60 225 609 minecraft:light_gray_concrete
fill 60 224 611 60 225 611 minecraft:light_gray_concrete
fill 60 224 641 60 225 641 minecraft:light_gray_concrete
fill 60 224 643 60 225 643 minecraft:light_gray_concrete
fill 60 224 645 60 225 645 minecraft:light_gray_concrete
fill 61 224 606 61 225 606 minecraft:light_gray_concrete
fill 61 224 608 61 225 608 minecraft:light_gray_concrete
fill 61 224 610 61 225 610 minecraft:light_gray_concrete
fill 61 224 612 61 225 612 minecraft:light_gray_concrete
fill 61 224 642 61 225 642 minecraft:light_gray_concrete
fill 61 224 644 61 225 644 minecraft:light_gray_concrete
fill 62 224 605 62 225 605 minecraft:light_gray_concrete
fill 62 224 607 62 225 607 minecraft:light_gray_concrete
fill 62 224 609 62 225 609 minecraft:light_gray_concrete
fill 62 224 611 62 225 611 minecraft:light_gray_concrete
fill 62 224 641 62 225 641 minecraft:light_gray_concrete
fill 62 224 643 62 225 643 minecraft:light_gray_concrete
fill 62 224 645 62 225 645 minecraft:light_gray_concrete
fill 63 224 606 63 225 606 minecraft:light_gray_concrete
fill 63 224 608 63 225 608 minecraft:light_gray_concrete
fill 63 224 610 63 225 610 minecraft:light_gray_concrete
fill 63 224 612 63 225 612 minecraft:light_gray_concrete
fill 63 224 644 88 224 644 minecraft:light_gray_concrete
fill 64 224 605 64 225 605 minecraft:light_gray_concrete
fill 64 224 607 64 225 607 minecraft:light_gray_concrete
fill 64 224 609 64 225 609 minecraft:light_gray_concrete
fill 64 224 611 64 225 611 minecraft:light_gray_concrete
fill 64 224 645 69 225 645 minecraft:light_gray_concrete
fill 65 224 606 87 224 606 minecraft:light_gray_concrete
fill 65 224 608 65 225 608 minecraft:light_gray_concrete
fill 65 224 610 65 225 610 minecraft:light_gray_concrete
fill 65 224 612 65 225 612 minecraft:light_gray_concrete
fill 67 224 605 72 225 605 minecraft:light_gray_concrete
fill 72 224 645 77 225 645 minecraft:light_gray_concrete
fill 75 224 605 80 225 605 minecraft:light_gray_concrete
fill 80 224 645 85 225 645 minecraft:light_gray_concrete
fill 83 224 605 88 225 605 minecraft:light_gray_concrete
setblock 83 224 635 minecraft:magenta_concrete
setblock 83 224 637 minecraft:magenta_concrete
fill 84 224 634 85 224 634 minecraft:magenta_concrete
fill 84 224 638 85 224 638 minecraft:magenta_concrete
fill 87 224 607 87 224 643 minecraft:light_gray_concrete
fill 88 224 608 88 225 613 minecraft:light_gray_concrete
fill 88 224 616 88 225 621 minecraft:light_gray_concrete
fill 88 224 624 88 225 629 minecraft:light_gray_concrete
fill 88 224 632 88 235 637 minecraft:light_gray_concrete
fill 88 224 640 88 225 643 minecraft:light_gray_concrete
fill 88 224 645 88 225 645 minecraft:light_gray_concrete
setblock 48 225 613 minecraft:light_gray_concrete
fill 48 225 623 48 225 626 minecraft:light_gray_concrete
fill 48 225 629 48 225 634 minecraft:light_gray_concrete
fill 48 225 637 48 225 642 minecraft:light_gray_concrete
setblock 53 225 606 minecraft:light_gray_concrete
setblock 65 225 606 minecraft:light_gray_concrete
fill 65 225 616 66 226 617 minecraft:gray_concrete
fill 82 225 631 87 235 641 minecraft:light_gray_concrete
setblock 88 225 644 minecraft:light_gray_concrete
setblock 48 226 615 minecraft:sea_lantern
setblock 48 226 617 minecraft:sea_lantern
setblock 48 226 619 minecraft:sea_lantern
setblock 48 226 621 minecraft:sea_lantern
setblock 49 226 614 minecraft:sea_lantern
setblock 49 226 616 minecraft:sea_lantern
setblock 49 226 618 minecraft:sea_lantern
setblock 49 226 620 minecraft:sea_lantern
setblock 49 226 622 minecraft:sea_lantern
setblock 50 226 615 minecraft:sea_lantern
setblock 50 226 617 minecraft:sea_lantern
setblock 50 226 619 minecraft:sea_lantern
setblock 50 226 621 minecraft:sea_lantern
setblock 51 226 614 minecraft:sea_lantern
setblock 51 226 616 minecraft:sea_lantern
setblock 51 226 618 minecraft:sea_lantern
setblock 51 226 620 minecraft:sea_lantern
setblock 51 226 622 minecraft:sea_lantern
setblock 52 226 615 minecraft:sea_lantern
setblock 52 226 617 minecraft:sea_lantern
setblock 52 226 619 minecraft:sea_lantern
setblock 52 226 621 minecraft:sea_lantern
setblock 52 226 641 minecraft:sea_lantern
setblock 52 226 643 minecraft:sea_lantern
setblock 52 226 645 minecraft:sea_lantern
setblock 53 226 606 minecraft:sea_lantern
setblock 53 226 608 minecraft:sea_lantern
setblock 53 226 610 minecraft:sea_lantern
setblock 53 226 612 minecraft:sea_lantern
setblock 53 226 614 minecraft:sea_lantern
setblock 53 226 616 minecraft:sea_lantern
setblock 53 226 618 minecraft:sea_lantern
setblock 53 226 620 minecraft:sea_lantern
setblock 53 226 622 minecraft:sea_lantern
setblock 53 226 642 minecraft:sea_lantern
setblock 53 226 644 minecraft:sea_lantern
setblock 54 226 605 minecraft:sea_lantern
setblock 54 226 607 minecraft:sea_lantern
setblock 54 226 609 minecraft:sea_lantern
setblock 54 226 611 minecraft:sea_lantern
setblock 54 226 615 minecraft:sea_lantern
setblock 54 226 617 minecraft:sea_lantern
setblock 54 226 619 minecraft:sea_lantern
setblock 54 226 621 minecraft:sea_lantern
setblock 54 226 641 minecraft:sea_lantern
setblock 54 226 643 minecraft:sea_lantern
setblock 54 226 645 minecraft:sea_lantern
setblock 55 226 606 minecraft:sea_lantern
setblock 55 226 608 minecraft:sea_lantern
setblock 55 226 610 minecraft:sea_lantern
setblock 55 226 612 minecraft:sea_lantern
setblock 55 226 614 minecraft:sea_lantern
setblock 55 226 616 minecraft:sea_lantern
setblock 55 226 618 minecraft:sea_lantern
setblock 55 226 620 minecraft:sea_lantern
setblock 55 226 622 minecraft:sea_lantern
setblock 55 226 642 minecraft:sea_lantern
setblock 55 226 644 minecraft:sea_lantern
setblock 56 226 605 minecraft:sea_lantern
setblock 56 226 607 minecraft:sea_lantern
setblock 56 226 609 minecraft:sea_lantern
setblock 56 226 611 minecraft:sea_lantern
setblock 56 226 615 minecraft:sea_lantern
setblock 56 226 617 minecraft:sea_lantern
setblock 56 226 619 minecraft:sea_lantern
setblock 56 226 621 minecraft:sea_lantern
setblock 56 226 641 minecraft:sea_lantern
setblock 56 226 643 minecraft:sea_lantern
setblock 56 226 645 minecraft:sea_lantern
setblock 57 226 606 minecraft:sea_lantern
setblock 57 226 608 minecraft:sea_lantern
setblock 57 226 610 minecraft:sea_lantern
setblock 57 226 612 minecraft:sea_lantern
setblock 57 226 642 minecraft:sea_lantern
setblock 57 226 644 minecraft:sea_lantern
setblock 58 226 605 minecraft:sea_lantern
setblock 58 226 607 minecraft:sea_lantern
setblock 58 226 609 minecraft:sea_lantern
setblock 58 226 611 minecraft:sea_lantern
setblock 58 226 641 minecraft:sea_lantern
setblock 58 226 643 minecraft:sea_lantern
setblock 58 226 645 minecraft:sea_lantern
setblock 59 226 606 minecraft:sea_lantern
setblock 59 226 608 minecraft:sea_lantern
setblock 59 226 610 minecraft:sea_lantern
setblock 59 226 612 minecraft:sea_lantern
setblock 59 226 642 minecraft:sea_lantern
setblock 59 226 644 minecraft:sea_lantern
setblock 60 226 605 minecraft:sea_lantern
setblock 60 226 607 minecraft:sea_lantern
setblock 60 226 609 minecraft:sea_lantern
setblock 60 226 611 minecraft:sea_lantern
setblock 60 226 641 minecraft:sea_lantern
setblock 60 226 643 minecraft:sea_lantern
setblock 60 226 645 minecraft:sea_lantern
setblock 61 226 606 minecraft:sea_lantern
setblock 61 226 608 minecraft:sea_lantern
setblock 61 226 610 minecraft:sea_lantern
setblock 61 226 612 minecraft:sea_lantern
setblock 61 226 642 minecraft:sea_lantern
setblock 61 226 644 minecraft:sea_lantern
setblock 62 226 605 minecraft:sea_lantern
setblock 62 226 607 minecraft:sea_lantern
setblock 62 226 609 minecraft:sea_lantern
setblock 62 226 611 minecraft:sea_lantern
setblock 62 226 641 minecraft:sea_lantern
setblock 62 226 643 minecraft:sea_lantern
setblock 62 226 645 minecraft:sea_lantern
setblock 63 226 606 minecraft:sea_lantern
setblock 63 226 608 minecraft:sea_lantern
setblock 63 226 610 minecraft:sea_lantern
setblock 63 226 612 minecraft:sea_lantern
setblock 64 226 605 minecraft:sea_lantern
setblock 64 226 607 minecraft:sea_lantern
setblock 64 226 609 minecraft:sea_lantern
setblock 64 226 611 minecraft:sea_lantern
setblock 65 226 606 minecraft:sea_lantern
setblock 65 226 608 minecraft:sea_lantern
setblock 65 226 610 minecraft:sea_lantern
setblock 65 226 612 minecraft:sea_lantern
fill 88 226 640 88 235 641 minecraft:light_gray_concrete
fill 48 227 615 48 228 615 minecraft:light_gray_concrete
fill 48 227 617 48 228 617 minecraft:light_gray_concrete
fill 48 227 619 48 228 619 minecraft:light_gray_concrete
fill 48 227 621 48 228 621 minecraft:light_gray_concrete
fill 49 227 614 49 228 614 minecraft:light_gray_concrete
fill 49 227 616 49 228 616 minecraft:light_gray_concrete
fill 49 227 618 49 228 618 minecraft:light_gray_concrete
fill 49 227 620 49 228 620 minecraft:light_gray_concrete
fill 49 227 622 49 228 622 minecraft:light_gray_concrete
setblock 50 227 607 minecraft:light[level=14]
fill 50 227 615 50 228 615 minecraft:light_gray_concrete
fill 50 227 617 50 228 617 minecraft:light_gray_concrete
fill 50 227 619 50 228 619 minecraft:light_gray_concrete
fill 50 227 621 50 228 621 minecraft:light_gray_concrete
setblock 50 227 623 minecraft:light[level=14]
setblock 50 227 631 minecraft:light[level=14]
setblock 50 227 639 minecraft:light[level=14]
fill 51 227 614 51 228 614 minecraft:light_gray_concrete
fill 51 227 616 51 228 616 minecraft:light_gray_concrete
fill 51 227 618 51 228 618 minecraft:light_gray_concrete
fill 51 227 620 51 228 620 minecraft:light_gray_concrete
fill 51 227 622 51 228 622 minecraft:light_gray_concrete
fill 52 227 615 52 228 615 minecraft:light_gray_concrete
fill 52 227 617 52 228 617 minecraft:light_gray_concrete
fill 52 227 619 52 228 619 minecraft:light_gray_concrete
fill 52 227 621 52 228 621 minecraft:light_gray_concrete
fill 52 227 641 52 228 641 minecraft:light_gray_concrete
fill 52 227 643 52 228 643 minecraft:light_gray_concrete
fill 52 227 645 52 228 645 minecraft:light_gray_concrete
fill 53 227 606 53 228 606 minecraft:light_gray_concrete
fill 53 227 608 53 228 608 minecraft:light_gray_concrete
fill 53 227 610 53 228 610 minecraft:light_gray_concrete
fill 53 227 612 53 228 612 minecraft:light_gray_concrete
fill 53 227 614 53 228 614 minecraft:light_gray_concrete
fill 53 227 616 53 228 616 minecraft:light_gray_concrete
fill 53 227 618 53 228 618 minecraft:light_gray_concrete
fill 53 227 620 53 228 620 minecraft:light_gray_concrete
fill 53 227 622 53 228 622 minecraft:light_gray_concrete
fill 53 227 642 53 228 642 minecraft:light_gray_concrete
fill 53 227 644 53 228 644 minecraft:light_gray_concrete
fill 54 227 605 54 228 605 minecraft:light_gray_concrete
fill 54 227 607 54 228 607 minecraft:light_gray_concrete
fill 54 227 609 54 228 609 minecraft:light_gray_concrete
fill 54 227 611 54 228 611 minecraft:light_gray_concrete
fill 54 227 615 54 228 615 minecraft:light_gray_concrete
fill 54 227 617 54 228 617 minecraft:light_gray_concrete
fill 54 227 619 54 228 619 minecraft:light_gray_concrete
fill 54 227 621 54 228 621 minecraft:light_gray_concrete
fill 54 227 641 54 228 641 minecraft:light_gray_concrete
fill 54 227 643 54 228 643 minecraft:light_gray_concrete
fill 54 227 645 54 228 645 minecraft:light_gray_concrete
fill 55 227 606 55 228 606 minecraft:light_gray_concrete
fill 55 227 608 55 228 608 minecraft:light_gray_concrete
fill 55 227 610 55 228 610 minecraft:light_gray_concrete
fill 55 227 612 55 228 612 minecraft:light_gray_concrete
fill 55 227 614 55 228 614 minecraft:light_gray_concrete
fill 55 227 616 55 228 616 minecraft:light_gray_concrete
fill 55 227 618 55 228 618 minecraft:light_gray_concrete
fill 55 227 620 55 228 620 minecraft:light_gray_concrete
fill 55 227 622 55 228 622 minecraft:light_gray_concrete
fill 55 227 642 55 228 642 minecraft:light_gray_concrete
fill 55 227 644 55 228 644 minecraft:light_gray_concrete
fill 56 227 605 56 228 605 minecraft:light_gray_concrete
fill 56 227 607 56 228 607 minecraft:light_gray_concrete
fill 56 227 609 56 228 609 minecraft:light_gray_concrete
fill 56 227 611 56 228 611 minecraft:light_gray_concrete
fill 56 227 615 56 228 615 minecraft:light_gray_concrete
fill 56 227 617 56 228 617 minecraft:light_gray_concrete
fill 56 227 619 56 228 619 minecraft:light_gray_concrete
fill 56 227 621 56 228 621 minecraft:light_gray_concrete
fill 56 227 641 56 228 641 minecraft:light_gray_concrete
fill 56 227 643 56 228 643 minecraft:light_gray_concrete
fill 56 227 645 56 228 645 minecraft:light_gray_concrete
fill 57 227 606 57 228 606 minecraft:light_gray_concrete
fill 57 227 608 57 228 608 minecraft:light_gray_concrete
fill 57 227 610 57 228 610 minecraft:light_gray_concrete
fill 57 227 612 57 228 612 minecraft:light_gray_concrete
fill 57 227 642 57 228 642 minecraft:light_gray_concrete
fill 57 227 644 57 228 644 minecraft:light_gray_concrete
fill 58 227 605 58 228 605 minecraft:light_gray_concrete
fill 58 227 607 58 228 607 minecraft:light_gray_concrete
fill 58 227 609 58 228 609 minecraft:light_gray_concrete
fill 58 227 611 58 228 611 minecraft:light_gray_concrete
setblock 58 227 615 minecraft:light[level=14]
setblock 58 227 623 minecraft:light[level=14]
setblock 58 227 631 minecraft:light[level=14]
setblock 58 227 639 minecraft:light[level=14]
fill 58 227 641 58 228 641 minecraft:light_gray_concrete
fill 58 227 643 58 228 643 minecraft:light_gray_concrete
fill 58 227 645 58 228 645 minecraft:light_gray_concrete
fill 59 227 606 59 228 606 minecraft:light_gray_concrete
fill 59 227 608 59 228 608 minecraft:light_gray_concrete
fill 59 227 610 59 228 610 minecraft:light_gray_concrete
fill 59 227 612 59 228 612 minecraft:light_gray_concrete
fill 59 227 642 59 228 642 minecraft:light_gray_concrete
fill 59 227 644 59 228 644 minecraft:light_gray_concrete
fill 60 227 605 60 228 605 minecraft:light_gray_concrete
fill 60 227 607 60 228 607 minecraft:light_gray_concrete
fill 60 227 609 60 228 609 minecraft:light_gray_concrete
fill 60 227 611 60 228 611 minecraft:light_gray_concrete
fill 60 227 641 60 228 641 minecraft:light_gray_concrete
fill 60 227 643 60 228 643 minecraft:light_gray_concrete
fill 60 227 645 60 228 645 minecraft:light_gray_concrete
fill 61 227 606 61 228 606 minecraft:light_gray_concrete
fill 61 227 608 61 228 608 minecraft:light_gray_concrete
fill 61 227 610 61 228 610 minecraft:light_gray_concrete
fill 61 227 612 61 228 612 minecraft:light_gray_concrete
fill 61 227 642 61 228 642 minecraft:light_gray_concrete
fill 61 227 644 61 228 644 minecraft:light_gray_concrete
fill 62 227 605 62 228 605 minecraft:light_gray_concrete
fill 62 227 607 62 228 607 minecraft:light_gray_concrete
fill 62 227 609 62 228 609 minecraft:light_gray_concrete
fill 62 227 611 62 228 611 minecraft:light_gray_concrete
fill 62 227 641 62 228 641 minecraft:light_gray_concrete
fill 62 227 643 62 228 643 minecraft:light_gray_concrete
fill 62 227 645 62 228 645 minecraft:light_gray_concrete
fill 63 227 606 63 228 606 minecraft:light_gray_concrete
fill 63 227 608 63 228 608 minecraft:light_gray_concrete
fill 63 227 610 63 228 610 minecraft:light_gray_concrete
fill 63 227 612 63 228 612 minecraft:light_gray_concrete
fill 64 227 605 64 228 605 minecraft:light_gray_concrete
fill 64 227 607 64 228 607 minecraft:light_gray_concrete
fill 64 227 609 64 228 609 minecraft:light_gray_concrete
fill 64 227 611 64 228 611 minecraft:light_gray_concrete
fill 65 227 606 65 228 606 minecraft:light_gray_concrete
fill 65 227 608 65 228 608 minecraft:light_gray_concrete
fill 65 227 610 65 228 610 minecraft:light_gray_concrete
fill 65 227 612 65 228 612 minecraft:light_gray_concrete
setblock 66 227 607 minecraft:light[level=14]
setblock 66 227 615 minecraft:light[level=14]
schedule function dropper:buildpart/145_3 1t
