setblock 403 266 631 minecraft:light[level=12]
setblock 403 266 639 minecraft:light[level=12]
fill 408 266 604 408 271 604 minecraft:black_concrete
fill 408 266 646 409 266 646 minecraft:red_concrete
fill 409 266 604 410 266 604 minecraft:red_concrete
fill 410 266 646 411 271 646 minecraft:black_concrete
fill 411 266 604 411 271 604 minecraft:black_concrete
setblock 411 266 607 minecraft:light[level=12]
setblock 411 266 615 minecraft:light[level=12]
setblock 411 266 623 minecraft:light[level=12]
setblock 411 266 631 minecraft:light[level=12]
setblock 411 266 639 minecraft:light[level=12]
fill 413 266 604 413 267 604 minecraft:red_concrete
fill 417 266 646 417 267 646 minecraft:red_concrete
fill 418 266 605 418 271 606 minecraft:black_concrete
fill 418 266 607 418 267 608 minecraft:red_concrete
setblock 418 266 616 minecraft:red_concrete
fill 418 266 617 418 271 618 minecraft:black_concrete
fill 418 266 619 418 267 620 minecraft:red_concrete
fill 418 266 625 418 271 626 minecraft:black_concrete
fill 418 266 627 418 266 628 minecraft:red_concrete
fill 418 266 629 418 271 629 minecraft:black_concrete
fill 418 266 637 418 271 638 minecraft:black_concrete
fill 418 266 639 418 267 640 minecraft:red_concrete
fill 418 266 646 418 271 646 minecraft:black_concrete
fill 376 267 606 376 269 607 minecraft:black_concrete
fill 376 267 622 376 267 623 minecraft:red_concrete
setblock 376 267 626 minecraft:red_concrete
fill 376 267 627 376 270 627 minecraft:black_concrete
fill 376 267 638 376 270 638 minecraft:black_concrete
fill 376 267 642 376 269 642 minecraft:black_concrete
setblock 376 267 643 minecraft:red_concrete
fill 378 267 604 378 270 604 minecraft:black_concrete
setblock 382 267 604 minecraft:red_concrete
setblock 384 267 646 minecraft:red_concrete
fill 388 267 646 389 270 646 minecraft:black_concrete
fill 389 267 604 389 270 604 minecraft:black_concrete
setblock 390 267 604 minecraft:red_concrete
fill 391 267 612 392 267 612 minecraft:crying_obsidian
setblock 392 267 613 minecraft:crying_obsidian
setblock 393 267 604 minecraft:red_concrete
fill 393 267 643 395 268 643 minecraft:red_concrete
fill 394 267 642 394 268 642 minecraft:red_concrete
fill 394 267 644 394 268 644 minecraft:red_concrete
setblock 405 267 646 minecraft:red_concrete
setblock 408 267 646 minecraft:red_concrete
fill 409 267 604 410 270 604 minecraft:black_concrete
fill 409 267 646 409 270 646 minecraft:black_concrete
setblock 414 267 604 minecraft:red_concrete
setblock 416 267 646 minecraft:red_concrete
setblock 418 267 611 minecraft:red_concrete
fill 418 267 616 418 270 616 minecraft:black_concrete
fill 418 267 627 418 270 627 minecraft:black_concrete
setblock 418 267 628 minecraft:red_concrete
fill 418 267 631 418 267 632 minecraft:red_concrete
setblock 376 268 604 minecraft:red_concrete
fill 376 268 612 376 269 613 minecraft:red_concrete
fill 376 268 614 376 285 615 minecraft:black_concrete
fill 376 268 621 376 269 621 minecraft:red_concrete
fill 376 268 622 376 269 623 minecraft:black_concrete
fill 376 268 624 376 268 625 minecraft:red_concrete
fill 376 268 626 376 285 626 minecraft:black_concrete
fill 376 268 632 376 269 633 minecraft:red_concrete
fill 376 268 634 376 286 635 minecraft:black_concrete
fill 376 268 643 376 289 643 minecraft:black_concrete
fill 376 268 644 376 268 645 minecraft:red_concrete
fill 376 268 646 377 285 646 minecraft:black_concrete
fill 381 268 604 382 286 604 minecraft:black_concrete
fill 382 268 646 383 269 646 minecraft:red_concrete
fill 383 268 604 384 269 604 minecraft:red_concrete
fill 384 268 646 385 286 646 minecraft:black_concrete
setblock 386 268 646 minecraft:red_concrete
fill 389 268 612 391 268 612 minecraft:crying_obsidian
fill 390 268 604 390 285 604 minecraft:black_concrete
fill 391 268 604 392 268 604 minecraft:red_concrete
fill 393 268 604 393 289 604 minecraft:black_concrete
fill 394 268 646 395 269 646 minecraft:red_concrete
fill 395 268 604 395 269 604 minecraft:red_concrete
fill 396 268 646 397 285 646 minecraft:black_concrete
fill 401 268 604 402 285 604 minecraft:black_concrete
fill 403 268 604 404 269 604 minecraft:red_concrete
fill 403 268 646 403 269 646 minecraft:red_concrete
fill 405 268 646 405 289 646 minecraft:black_concrete
fill 406 268 646 407 268 646 minecraft:red_concrete
fill 408 268 646 408 285 646 minecraft:black_concrete
setblock 412 268 604 minecraft:red_concrete
fill 413 268 604 414 286 604 minecraft:black_concrete
fill 414 268 646 415 269 646 minecraft:red_concrete
fill 415 268 604 416 269 604 minecraft:red_concrete
fill 416 268 646 417 286 646 minecraft:black_concrete
fill 418 268 607 418 285 608 minecraft:black_concrete
fill 418 268 609 418 268 610 minecraft:red_concrete
fill 418 268 611 418 289 611 minecraft:black_concrete
fill 418 268 619 418 286 620 minecraft:black_concrete
fill 418 268 621 418 269 622 minecraft:red_concrete
fill 418 268 628 418 285 628 minecraft:black_concrete
setblock 418 268 630 minecraft:red_concrete
fill 418 268 631 418 289 632 minecraft:black_concrete
fill 418 268 633 418 269 633 minecraft:red_concrete
fill 418 268 639 418 285 640 minecraft:black_concrete
fill 418 268 641 418 268 642 minecraft:red_concrete
fill 376 269 604 376 271 604 minecraft:black_concrete
setblock 376 269 609 minecraft:red_concrete
setblock 376 269 620 minecraft:red_concrete
fill 376 269 624 376 271 625 minecraft:black_concrete
fill 376 269 640 376 269 641 minecraft:red_concrete
setblock 376 269 644 minecraft:red_concrete
fill 376 269 645 376 272 645 minecraft:black_concrete
fill 386 269 646 386 272 646 minecraft:black_concrete
fill 388 269 611 389 269 612 minecraft:crying_obsidian
setblock 390 269 612 minecraft:crying_obsidian
fill 391 269 604 392 272 604 minecraft:black_concrete
setblock 391 269 646 minecraft:red_concrete
setblock 396 269 604 minecraft:red_concrete
setblock 402 269 646 minecraft:red_concrete
fill 406 269 646 407 272 646 minecraft:black_concrete
setblock 407 269 604 minecraft:red_concrete
fill 412 269 604 412 272 604 minecraft:black_concrete
fill 418 269 609 418 272 609 minecraft:black_concrete
setblock 418 269 610 minecraft:red_concrete
fill 418 269 613 418 269 614 minecraft:red_concrete
fill 418 269 630 418 272 630 minecraft:black_concrete
setblock 418 269 634 minecraft:red_concrete
fill 418 269 641 418 272 641 minecraft:black_concrete
setblock 418 269 642 minecraft:red_concrete
setblock 418 269 645 minecraft:red_concrete
setblock 376 270 606 minecraft:black_concrete
fill 376 270 607 376 271 607 minecraft:red_concrete
fill 376 270 609 376 283 609 minecraft:black_concrete
fill 376 270 610 376 270 611 minecraft:red_concrete
fill 376 270 612 376 272 613 minecraft:black_concrete
fill 376 270 618 376 271 619 minecraft:red_concrete
fill 376 270 620 376 283 621 minecraft:black_concrete
setblock 376 270 622 minecraft:red_concrete
fill 376 270 623 376 289 623 minecraft:black_concrete
fill 376 270 630 376 271 631 minecraft:red_concrete
fill 376 270 632 376 283 633 minecraft:black_concrete
fill 376 270 639 376 271 639 minecraft:red_concrete
fill 376 270 640 376 283 641 minecraft:black_concrete
setblock 376 270 642 minecraft:red_concrete
fill 376 270 644 376 287 644 minecraft:black_concrete
fill 377 270 604 377 271 604 minecraft:red_concrete
fill 377 270 605 379 270 605 minecraft:polished_blackstone
fill 377 270 607 377 270 609 minecraft:polished_blackstone
fill 377 270 611 377 270 613 minecraft:polished_blackstone
fill 377 270 615 377 270 617 minecraft:polished_blackstone
fill 377 270 619 377 270 621 minecraft:polished_blackstone
fill 377 270 623 377 270 625 minecraft:polished_blackstone
fill 377 270 627 377 270 629 minecraft:polished_blackstone
fill 377 270 631 377 270 633 minecraft:polished_blackstone
fill 377 270 635 377 270 637 minecraft:polished_blackstone
fill 377 270 639 377 270 641 minecraft:polished_blackstone
fill 377 270 643 377 270 645 minecraft:polished_blackstone
fill 379 270 645 381 270 645 minecraft:polished_blackstone
fill 380 270 646 381 271 646 minecraft:red_concrete
fill 381 270 605 383 270 605 minecraft:polished_blackstone
fill 382 270 646 383 283 646 minecraft:black_concrete
fill 383 270 604 384 283 604 minecraft:black_concrete
fill 383 270 645 385 270 645 minecraft:polished_blackstone
fill 385 270 604 386 271 604 minecraft:red_concrete
fill 385 270 605 387 270 605 minecraft:polished_blackstone
fill 386 270 611 388 270 611 minecraft:crying_obsidian
fill 387 270 612 388 270 612 minecraft:crying_obsidian
fill 387 270 645 389 270 645 minecraft:polished_blackstone
fill 389 270 605 391 270 605 minecraft:polished_blackstone
fill 391 270 645 393 270 645 minecraft:polished_blackstone
fill 391 270 646 391 283 646 minecraft:black_concrete
fill 392 270 646 393 270 646 minecraft:red_concrete
fill 393 270 605 395 270 605 minecraft:polished_blackstone
setblock 394 270 604 minecraft:red_concrete
fill 394 270 646 395 287 646 minecraft:black_concrete
fill 395 270 604 396 283 604 minecraft:black_concrete
fill 395 270 645 397 270 645 minecraft:polished_blackstone
fill 397 270 604 398 271 604 minecraft:red_concrete
fill 397 270 605 399 270 605 minecraft:polished_blackstone
fill 399 270 645 401 270 645 minecraft:polished_blackstone
fill 400 270 646 401 271 646 minecraft:red_concrete
fill 401 270 605 403 270 605 minecraft:polished_blackstone
fill 402 270 646 403 283 646 minecraft:black_concrete
fill 403 270 604 404 287 604 minecraft:black_concrete
fill 403 270 645 405 270 645 minecraft:polished_blackstone
setblock 404 270 646 minecraft:red_concrete
fill 405 270 604 406 270 604 minecraft:red_concrete
fill 405 270 605 407 270 605 minecraft:polished_blackstone
fill 407 270 604 407 283 604 minecraft:black_concrete
fill 407 270 645 409 270 645 minecraft:polished_blackstone
fill 409 270 605 411 270 605 minecraft:polished_blackstone
fill 411 270 645 413 270 645 minecraft:polished_blackstone
fill 412 270 646 413 271 646 minecraft:red_concrete
fill 413 270 605 415 270 605 minecraft:polished_blackstone
fill 414 270 646 415 283 646 minecraft:black_concrete
fill 415 270 604 416 283 604 minecraft:black_concrete
fill 415 270 645 417 270 645 minecraft:polished_blackstone
fill 417 270 604 418 271 604 minecraft:red_concrete
fill 417 270 605 417 270 607 minecraft:polished_blackstone
fill 417 270 609 417 270 611 minecraft:polished_blackstone
fill 417 270 613 417 270 615 minecraft:polished_blackstone
fill 417 270 617 417 270 619 minecraft:polished_blackstone
fill 417 270 621 417 270 623 minecraft:polished_blackstone
fill 417 270 625 417 270 627 minecraft:polished_blackstone
fill 417 270 629 417 270 631 minecraft:polished_blackstone
fill 417 270 633 417 270 635 minecraft:polished_blackstone
fill 417 270 637 417 270 639 minecraft:polished_blackstone
fill 417 270 641 417 270 643 minecraft:polished_blackstone
fill 418 270 610 418 287 610 minecraft:black_concrete
setblock 418 270 612 minecraft:red_concrete
fill 418 270 613 418 283 614 minecraft:black_concrete
fill 418 270 615 418 271 615 minecraft:red_concrete
fill 418 270 621 418 283 622 minecraft:black_concrete
fill 418 270 623 418 270 624 minecraft:red_concrete
fill 418 270 633 418 283 634 minecraft:black_concrete
fill 418 270 635 418 271 636 minecraft:red_concrete
fill 418 270 642 418 287 642 minecraft:black_concrete
fill 418 270 643 418 270 644 minecraft:red_concrete
fill 418 270 645 418 283 645 minecraft:black_concrete
setblock 376 271 606 minecraft:red_concrete
setblock 376 271 610 minecraft:red_concrete
fill 376 271 611 376 289 611 minecraft:black_concrete
fill 376 271 622 376 289 622 minecraft:black_concrete
setblock 376 271 627 minecraft:red_concrete
setblock 376 271 638 minecraft:red_concrete
fill 376 271 642 376 289 642 minecraft:black_concrete
setblock 378 271 604 minecraft:red_concrete
fill 384 271 611 386 271 611 minecraft:crying_obsidian
fill 388 271 646 389 271 646 minecraft:red_concrete
setblock 389 271 604 minecraft:red_concrete
setblock 392 271 646 minecraft:red_concrete
fill 393 271 646 393 289 646 minecraft:black_concrete
fill 394 271 604 394 289 604 minecraft:black_concrete
fill 404 271 646 404 289 646 minecraft:black_concrete
fill 405 271 604 405 289 604 minecraft:black_concrete
setblock 406 271 604 minecraft:red_concrete
fill 409 271 604 410 271 604 minecraft:red_concrete
setblock 409 271 646 minecraft:red_concrete
fill 418 271 612 418 289 612 minecraft:black_concrete
setblock 418 271 616 minecraft:red_concrete
fill 418 271 623 418 289 623 minecraft:black_concrete
setblock 418 271 624 minecraft:red_concrete
setblock 418 271 627 minecraft:red_concrete
fill 418 271 643 418 289 644 minecraft:black_concrete
fill 376 272 604 376 273 605 minecraft:red_concrete
fill 376 272 606 376 285 607 minecraft:black_concrete
setblock 376 272 608 minecraft:red_concrete
fill 376 272 610 376 289 610 minecraft:black_concrete
fill 376 272 616 376 273 617 minecraft:red_concrete
fill 376 272 618 376 285 619 minecraft:black_concrete
setblock 376 272 624 minecraft:black_concrete
fill 376 272 625 376 273 625 minecraft:red_concrete
fill 376 272 627 376 285 627 minecraft:black_concrete
fill 376 272 628 376 272 629 minecraft:red_concrete
fill 376 272 630 376 289 631 minecraft:black_concrete
fill 376 272 636 376 273 637 minecraft:red_concrete
fill 376 272 638 376 285 639 minecraft:black_concrete
fill 377 272 604 378 285 604 minecraft:black_concrete
fill 378 272 646 379 272 646 minecraft:red_concrete
fill 379 272 604 380 273 604 minecraft:red_concrete
fill 380 272 646 381 285 646 minecraft:black_concrete
fill 384 272 611 385 272 611 minecraft:crying_obsidian
fill 385 272 604 386 289 604 minecraft:black_concrete
fill 387 272 604 388 272 604 minecraft:red_concrete
fill 387 272 646 387 273 646 minecraft:red_concrete
fill 388 272 646 389 285 646 minecraft:black_concrete
fill 389 272 604 389 285 604 minecraft:black_concrete
setblock 390 272 646 minecraft:red_concrete
fill 392 272 646 392 289 646 minecraft:black_concrete
fill 397 272 604 398 285 604 minecraft:black_concrete
fill 398 272 646 399 273 646 minecraft:red_concrete
fill 399 272 604 400 273 604 minecraft:red_concrete
fill 400 272 646 401 285 646 minecraft:black_concrete
fill 406 272 604 406 289 604 minecraft:black_concrete
setblock 408 272 604 minecraft:red_concrete
fill 409 272 604 410 285 604 minecraft:black_concrete
fill 409 272 646 409 285 646 minecraft:black_concrete
fill 410 272 646 411 272 646 minecraft:red_concrete
fill 411 272 604 411 273 604 minecraft:red_concrete
fill 412 272 646 413 289 646 minecraft:black_concrete
fill 417 272 604 418 285 604 minecraft:black_concrete
fill 418 272 605 418 272 606 minecraft:red_concrete
fill 418 272 615 418 285 616 minecraft:black_concrete
fill 418 272 617 418 273 618 minecraft:red_concrete
fill 418 272 624 418 289 624 minecraft:black_concrete
fill 418 272 625 418 272 626 minecraft:red_concrete
fill 418 272 627 418 285 627 minecraft:black_concrete
fill 418 272 629 418 273 629 minecraft:red_concrete
fill 418 272 635 418 285 636 minecraft:black_concrete
fill 418 272 637 418 273 638 minecraft:red_concrete
fill 418 272 646 418 273 646 minecraft:red_concrete
fill 376 273 608 376 283 608 minecraft:black_concrete
fill 376 273 612 376 287 612 minecraft:black_concrete
setblock 376 273 613 minecraft:red_concrete
setblock 376 273 624 minecraft:red_concrete
setblock 376 273 628 minecraft:red_concrete
fill 376 273 629 376 283 629 minecraft:black_concrete
setblock 376 273 645 minecraft:red_concrete
setblock 378 273 646 minecraft:red_concrete
fill 379 273 646 379 283 646 minecraft:black_concrete
setblock 386 273 646 minecraft:red_concrete
fill 387 273 604 387 283 604 minecraft:black_concrete
setblock 388 273 604 minecraft:red_concrete
fill 390 273 646 390 283 646 minecraft:black_concrete
fill 391 273 604 392 273 604 minecraft:red_concrete
fill 406 273 646 407 273 646 minecraft:red_concrete
fill 408 273 604 408 283 604 minecraft:black_concrete
setblock 410 273 646 minecraft:red_concrete
fill 411 273 646 411 283 646 minecraft:black_concrete
setblock 412 273 604 minecraft:red_concrete
fill 418 273 605 418 283 605 minecraft:black_concrete
setblock 418 273 606 minecraft:red_concrete
setblock 418 273 609 minecraft:red_concrete
fill 418 273 625 418 283 626 minecraft:black_concrete
setblock 418 273 630 minecraft:red_concrete
setblock 418 273 641 minecraft:red_concrete
fill 376 274 604 376 287 605 minecraft:black_concrete
fill 376 274 613 376 287 613 minecraft:black_concrete
fill 376 274 616 376 284 617 minecraft:black_concrete
fill 376 274 624 376 287 625 minecraft:black_concrete
fill 376 274 628 376 283 628 minecraft:black_concrete
fill 376 274 636 376 284 637 minecraft:black_concrete
fill 376 274 645 376 287 645 minecraft:black_concrete
fill 378 274 646 378 284 646 minecraft:black_concrete
fill 379 274 604 380 284 604 minecraft:black_concrete
setblock 379 274 607 minecraft:light[level=12]
setblock 379 274 615 minecraft:light[level=12]
setblock 379 274 623 minecraft:light[level=12]
setblock 379 274 631 minecraft:light[level=12]
setblock 379 274 639 minecraft:light[level=12]
fill 386 274 646 387 287 646 minecraft:black_concrete
setblock 387 274 607 minecraft:light[level=12]
setblock 387 274 615 minecraft:light[level=12]
setblock 387 274 623 minecraft:light[level=12]
setblock 387 274 631 minecraft:light[level=12]
setblock 387 274 639 minecraft:light[level=12]
fill 388 274 604 388 284 604 minecraft:black_concrete
fill 391 274 604 392 287 604 minecraft:black_concrete
setblock 395 274 607 minecraft:light[level=12]
setblock 395 274 615 minecraft:light[level=12]
setblock 395 274 623 minecraft:light[level=12]
setblock 395 274 631 minecraft:light[level=12]
setblock 395 274 639 minecraft:light[level=12]
fill 398 274 646 399 284 646 minecraft:black_concrete
fill 399 274 604 400 284 604 minecraft:black_concrete
setblock 403 274 607 minecraft:light[level=12]
setblock 403 274 615 minecraft:light[level=12]
setblock 403 274 623 minecraft:light[level=12]
setblock 403 274 631 minecraft:light[level=12]
setblock 403 274 639 minecraft:light[level=12]
fill 406 274 646 407 287 646 minecraft:black_concrete
fill 410 274 646 410 284 646 minecraft:black_concrete
fill 411 274 604 412 287 604 minecraft:black_concrete
setblock 411 274 607 minecraft:light[level=12]
setblock 411 274 615 minecraft:light[level=12]
setblock 411 274 623 minecraft:light[level=12]
setblock 411 274 631 minecraft:light[level=12]
setblock 411 274 639 minecraft:light[level=12]
fill 418 274 606 418 284 606 minecraft:black_concrete
fill 418 274 609 418 287 609 minecraft:black_concrete
fill 418 274 617 418 284 618 minecraft:black_concrete
fill 418 274 629 418 287 630 minecraft:black_concrete
fill 418 274 637 418 284 638 minecraft:black_concrete
fill 418 274 641 418 287 641 minecraft:black_concrete
fill 418 274 646 418 287 646 minecraft:black_concrete
fill 394 278 624 396 278 626 minecraft:redstone_block
fill 399 278 629 401 278 631 minecraft:redstone_block
fill 402 278 620 404 278 622 minecraft:redstone_block
fill 383 279 625 384 280 625 minecraft:purple_terracotta
fill 384 279 622 385 280 624 minecraft:purple_terracotta
fill 384 279 626 385 280 628 minecraft:purple_terracotta
fill 385 279 620 386 280 621 minecraft:purple_terracotta
fill 385 279 625 393 279 625 minecraft:black_concrete
fill 385 279 629 386 280 630 minecraft:purple_terracotta
fill 386 279 619 388 280 619 minecraft:purple_terracotta
fill 386 279 622 393 279 624 minecraft:black_concrete
fill 386 279 626 393 279 628 minecraft:black_concrete
fill 386 279 631 388 280 631 minecraft:purple_terracotta
fill 387 279 618 390 280 618 minecraft:purple_terracotta
fill 387 279 620 387 280 620 minecraft:purple_terracotta
fill 387 279 621 395 280 621 minecraft:black_concrete
fill 387 279 629 395 280 629 minecraft:black_concrete
fill 387 279 630 387 280 630 minecraft:purple_terracotta
fill 387 279 632 390 280 632 minecraft:purple_terracotta
fill 388 279 617 392 280 617 minecraft:purple_terracotta
fill 388 279 620 396 280 620 minecraft:black_concrete
fill 388 279 630 396 280 630 minecraft:black_concrete
fill 388 279 633 392 280 633 minecraft:purple_terracotta
fill 389 279 619 394 280 619 minecraft:black_concrete
fill 389 279 631 394 280 631 minecraft:black_concrete
fill 390 279 616 396 280 616 minecraft:purple_terracotta
fill 390 279 634 396 280 634 minecraft:purple_terracotta
fill 391 279 618 409 280 618 minecraft:black_concrete
fill 391 279 632 409 279 632 minecraft:black_concrete
fill 393 279 615 407 280 615 minecraft:purple_terracotta
fill 393 279 617 407 280 617 minecraft:black_concrete
fill 393 279 633 407 280 633 minecraft:black_concrete
fill 393 279 635 407 280 635 minecraft:purple_terracotta
fill 394 279 622 394 279 623 minecraft:black_concrete
fill 394 279 627 394 279 628 minecraft:black_concrete
fill 395 279 619 395 280 619 minecraft:magma_block
fill 395 279 622 395 280 622 minecraft:orange_concrete
setblock 395 279 623 minecraft:red_concrete
setblock 395 279 627 minecraft:red_concrete
fill 395 279 628 395 280 628 minecraft:orange_concrete
fill 395 279 631 395 280 631 minecraft:magma_block
fill 396 279 619 398 280 619 minecraft:black_concrete
fill 396 279 621 396 280 622 minecraft:red_concrete
setblock 396 279 623 minecraft:orange_concrete
setblock 396 279 627 minecraft:orange_concrete
fill 396 279 628 396 280 629 minecraft:red_concrete
fill 396 279 631 398 279 631 minecraft:black_concrete
fill 397 279 614 403 280 614 minecraft:purple_terracotta
fill 397 279 616 403 280 616 minecraft:black_concrete
fill 397 279 620 397 280 620 minecraft:red_concrete
fill 397 279 621 397 280 621 minecraft:orange_concrete
fill 397 279 622 397 279 624 minecraft:red_concrete
fill 397 279 625 398 279 625 minecraft:black_concrete
fill 397 279 626 397 279 628 minecraft:red_concrete
fill 397 279 629 397 280 629 minecraft:orange_concrete
fill 397 279 630 397 280 630 minecraft:red_concrete
fill 397 279 634 403 280 634 minecraft:black_concrete
fill 397 279 636 403 280 636 minecraft:purple_terracotta
fill 398 279 620 398 280 620 minecraft:orange_concrete
fill 398 279 621 398 280 622 minecraft:red_concrete
fill 398 279 623 398 279 624 minecraft:black_concrete
fill 398 279 626 398 279 627 minecraft:black_concrete
fill 398 279 628 398 279 629 minecraft:red_concrete
setblock 398 279 630 minecraft:orange_concrete
fill 399 279 619 399 280 621 minecraft:red_concrete
fill 399 279 622 399 280 622 minecraft:orange_concrete
fill 399 279 623 402 279 623 minecraft:black_concrete
fill 399 279 627 402 279 627 minecraft:black_concrete
setblock 399 279 628 minecraft:orange_concrete
fill 400 279 619 400 280 621 minecraft:orange_concrete
fill 400 279 622 400 280 622 minecraft:black_concrete
setblock 400 279 628 minecraft:black_concrete
fill 401 279 619 401 279 621 minecraft:red_concrete
setblock 401 279 622 minecraft:orange_concrete
setblock 401 279 628 minecraft:orange_concrete
fill 402 279 619 404 279 619 minecraft:black_concrete
fill 402 279 624 402 279 626 minecraft:black_concrete
fill 402 279 628 402 279 629 minecraft:red_concrete
setblock 402 279 630 minecraft:orange_concrete
fill 402 279 631 404 279 631 minecraft:black_concrete
fill 403 279 623 403 279 624 minecraft:red_concrete
fill 403 279 625 403 280 625 minecraft:black_concrete
fill 403 279 626 403 280 628 minecraft:red_concrete
fill 403 279 629 403 280 629 minecraft:orange_concrete
fill 403 279 630 403 280 630 minecraft:red_concrete
fill 404 279 616 410 280 616 minecraft:purple_terracotta
setblock 404 279 623 minecraft:orange_concrete
fill 404 279 624 404 280 626 minecraft:red_concrete
fill 404 279 627 404 280 627 minecraft:orange_concrete
fill 404 279 628 404 280 629 minecraft:red_concrete
fill 404 279 630 412 280 630 minecraft:black_concrete
fill 404 279 634 410 280 634 minecraft:purple_terracotta
setblock 405 279 619 minecraft:magma_block
fill 405 279 620 412 279 621 minecraft:black_concrete
setblock 405 279 622 minecraft:orange_concrete
setblock 405 279 623 minecraft:red_concrete
fill 405 279 624 406 280 624 minecraft:orange_concrete
fill 405 279 625 406 280 625 minecraft:red_concrete
fill 405 279 626 406 280 626 minecraft:orange_concrete
fill 405 279 627 405 280 627 minecraft:red_concrete
fill 405 279 628 405 280 628 minecraft:orange_concrete
fill 405 279 629 413 280 629 minecraft:black_concrete
fill 405 279 631 405 280 631 minecraft:magma_block
fill 406 279 619 411 280 619 minecraft:black_concrete
fill 406 279 622 414 280 623 minecraft:black_concrete
fill 406 279 627 414 280 628 minecraft:black_concrete
fill 406 279 631 411 280 631 minecraft:black_concrete
fill 407 279 624 414 280 626 minecraft:black_concrete
fill 408 279 617 412 280 617 minecraft:purple_terracotta
fill 408 279 633 412 280 633 minecraft:purple_terracotta
fill 410 279 618 413 280 618 minecraft:purple_terracotta
fill 410 279 632 413 280 632 minecraft:purple_terracotta
fill 412 279 619 414 280 619 minecraft:purple_terracotta
fill 412 279 631 414 280 631 minecraft:purple_terracotta
fill 413 279 620 415 280 620 minecraft:purple_terracotta
fill 413 279 621 413 280 621 minecraft:black_concrete
fill 413 279 630 415 280 630 minecraft:purple_terracotta
fill 414 279 621 415 280 621 minecraft:purple_terracotta
fill 414 279 629 415 280 629 minecraft:purple_terracotta
fill 415 279 622 416 280 624 minecraft:purple_terracotta
fill 415 279 625 415 280 625 minecraft:black_concrete
fill 415 279 626 416 280 628 minecraft:purple_terracotta
fill 416 279 625 417 280 625 minecraft:purple_terracotta
fill 377 280 605 382 280 645 minecraft:black_concrete
fill 383 280 605 383 280 624 minecraft:black_concrete
fill 383 280 626 383 280 645 minecraft:black_concrete
fill 384 280 605 384 280 621 minecraft:black_concrete
fill 384 280 629 384 280 645 minecraft:black_concrete
fill 385 280 605 385 280 619 minecraft:black_concrete
fill 385 280 625 392 280 625 minecraft:black_concrete
fill 385 280 631 385 280 645 minecraft:black_concrete
fill 386 280 605 386 280 618 minecraft:black_concrete
fill 386 280 622 392 280 624 minecraft:black_concrete
fill 386 280 626 392 280 628 minecraft:black_concrete
fill 386 280 632 386 280 645 minecraft:black_concrete
fill 387 280 605 387 280 617 minecraft:black_concrete
fill 387 280 633 387 280 645 minecraft:black_concrete
fill 388 280 605 389 280 616 minecraft:black_concrete
fill 388 280 634 389 280 645 minecraft:black_concrete
fill 390 280 605 392 280 615 minecraft:black_concrete
fill 390 280 635 392 280 645 minecraft:black_concrete
fill 391 280 632 397 280 632 minecraft:black_concrete
fill 393 280 605 396 280 614 minecraft:black_concrete
fill 393 280 622 394 280 622 minecraft:black_concrete
fill 393 280 623 393 280 627 minecraft:shroomlight
fill 393 280 628 394 280 628 minecraft:black_concrete
fill 393 280 636 396 280 645 minecraft:black_concrete
fill 394 280 623 405 280 623 minecraft:shroomlight
fill 394 280 624 396 280 626 minecraft:black_concrete
fill 394 280 627 402 280 627 minecraft:shroomlight
fill 396 280 631 397 280 631 minecraft:black_concrete
fill 397 280 605 417 280 613 minecraft:black_concrete
setblock 397 280 622 minecraft:red_concrete
fill 397 280 624 398 280 626 minecraft:shroomlight
setblock 397 280 628 minecraft:red_concrete
fill 397 280 637 417 280 645 minecraft:black_concrete
fill 398 280 628 398 280 632 minecraft:shroomlight
fill 399 280 628 402 280 628 minecraft:shroomlight
fill 399 280 629 401 280 631 minecraft:black_concrete
fill 399 280 632 402 280 632 minecraft:shroomlight
fill 401 280 619 401 280 622 minecraft:shroomlight
fill 402 280 619 405 280 619 minecraft:shroomlight
fill 402 280 620 404 280 622 minecraft:black_concrete
fill 402 280 624 402 280 626 minecraft:shroomlight
fill 402 280 629 402 280 631 minecraft:shroomlight
setblock 403 280 624 minecraft:red_concrete
fill 403 280 631 404 280 632 minecraft:black_concrete
fill 404 280 614 417 280 614 minecraft:black_concrete
fill 404 280 636 417 280 636 minecraft:black_concrete
fill 405 280 620 405 280 622 minecraft:shroomlight
fill 405 280 632 409 280 632 minecraft:black_concrete
fill 406 280 620 412 280 621 minecraft:black_concrete
fill 408 280 615 417 280 615 minecraft:black_concrete
fill 408 280 635 417 280 635 minecraft:black_concrete
fill 411 280 616 417 280 616 minecraft:black_concrete
fill 411 280 634 417 280 634 minecraft:black_concrete
fill 413 280 617 417 280 617 minecraft:black_concrete
fill 413 280 633 417 280 633 minecraft:black_concrete
fill 414 280 618 417 280 618 minecraft:black_concrete
fill 414 280 632 417 280 632 minecraft:black_concrete
fill 415 280 619 417 280 619 minecraft:black_concrete
fill 415 280 631 417 280 631 minecraft:black_concrete
fill 416 280 620 417 280 621 minecraft:black_concrete
fill 416 280 629 417 280 630 minecraft:black_concrete
fill 417 280 622 417 280 624 minecraft:black_concrete
fill 417 280 626 417 280 628 minecraft:black_concrete
setblock 379 282 607 minecraft:light[level=12]
setblock 379 282 615 minecraft:light[level=12]
setblock 379 282 623 minecraft:light[level=12]
setblock 379 282 631 minecraft:light[level=12]
setblock 379 282 639 minecraft:light[level=12]
setblock 387 282 607 minecraft:light[level=12]
setblock 387 282 615 minecraft:light[level=12]
setblock 387 282 623 minecraft:light[level=12]
setblock 387 282 631 minecraft:light[level=12]
setblock 387 282 639 minecraft:light[level=12]
setblock 395 282 607 minecraft:light[level=12]
setblock 395 282 615 minecraft:light[level=12]
setblock 395 282 623 minecraft:light[level=12]
setblock 395 282 631 minecraft:light[level=12]
setblock 395 282 639 minecraft:light[level=12]
setblock 403 282 607 minecraft:light[level=12]
setblock 403 282 615 minecraft:light[level=12]
setblock 403 282 623 minecraft:light[level=12]
setblock 403 282 631 minecraft:light[level=12]
setblock 403 282 639 minecraft:light[level=12]
setblock 411 282 607 minecraft:light[level=12]
setblock 411 282 615 minecraft:light[level=12]
setblock 411 282 623 minecraft:light[level=12]
setblock 411 282 631 minecraft:light[level=12]
setblock 411 282 639 minecraft:light[level=12]
fill 376 284 608 376 285 609 minecraft:red_concrete
fill 376 284 620 376 284 621 minecraft:red_concrete
fill 376 284 628 376 285 629 minecraft:red_concrete
setblock 376 284 632 minecraft:red_concrete
fill 376 284 633 376 287 633 minecraft:black_concrete
fill 376 284 640 376 285 641 minecraft:red_concrete
fill 379 284 646 379 285 646 minecraft:red_concrete
fill 382 284 646 383 284 646 minecraft:red_concrete
fill 383 284 604 383 287 604 minecraft:black_concrete
fill 383 284 623 384 284 624 minecraft:blackstone
setblock 384 284 604 minecraft:red_concrete
fill 387 284 604 387 285 604 minecraft:red_concrete
fill 390 284 646 391 285 646 minecraft:red_concrete
fill 395 284 604 396 284 604 minecraft:red_concrete
fill 402 284 646 403 284 646 minecraft:red_concrete
fill 407 284 604 408 285 604 minecraft:red_concrete
fill 411 284 646 411 285 646 minecraft:red_concrete
setblock 414 284 646 minecraft:red_concrete
fill 415 284 604 416 284 604 minecraft:red_concrete
fill 415 284 646 415 287 646 minecraft:black_concrete
fill 418 284 605 418 285 605 minecraft:red_concrete
fill 418 284 613 418 285 614 minecraft:red_concrete
fill 418 284 621 418 287 621 minecraft:black_concrete
setblock 418 284 622 minecraft:red_concrete
fill 418 284 625 418 285 626 minecraft:red_concrete
fill 418 284 633 418 284 634 minecraft:red_concrete
fill 418 284 645 418 285 645 minecraft:red_concrete
fill 376 285 616 376 285 617 minecraft:red_concrete
setblock 376 285 620 minecraft:red_concrete
fill 376 285 621 376 288 621 minecraft:black_concrete
fill 376 285 632 376 288 632 minecraft:black_concrete
fill 376 285 636 376 287 636 minecraft:black_concrete
setblock 376 285 637 minecraft:red_concrete
setblock 378 285 646 minecraft:red_concrete
setblock 379 285 604 minecraft:red_concrete
fill 380 285 604 380 287 604 minecraft:black_concrete
fill 382 285 646 383 288 646 minecraft:black_concrete
fill 384 285 604 384 288 604 minecraft:black_concrete
setblock 388 285 604 minecraft:red_concrete
fill 395 285 604 395 288 604 minecraft:black_concrete
setblock 396 285 604 minecraft:red_concrete
fill 398 285 646 398 287 646 minecraft:black_concrete
setblock 399 285 604 minecraft:red_concrete
setblock 399 285 646 minecraft:red_concrete
fill 400 285 604 400 287 604 minecraft:black_concrete
setblock 402 285 646 minecraft:red_concrete
fill 403 285 646 403 288 646 minecraft:black_concrete
setblock 410 285 646 minecraft:red_concrete
fill 414 285 646 414 288 646 minecraft:black_concrete
fill 415 285 604 416 288 604 minecraft:black_concrete
setblock 418 285 606 minecraft:red_concrete
setblock 418 285 617 minecraft:red_concrete
fill 418 285 618 418 287 618 minecraft:black_concrete
fill 418 285 622 418 288 622 minecraft:black_concrete
fill 418 285 633 418 288 633 minecraft:black_concrete
setblock 418 285 634 minecraft:red_concrete
fill 418 285 637 418 285 638 minecraft:red_concrete
fill 376 286 606 376 287 607 minecraft:red_concrete
fill 376 286 608 376 291 609 minecraft:black_concrete
setblock 376 286 614 minecraft:black_concrete
fill 376 286 615 376 287 615 minecraft:red_concrete
fill 376 286 616 376 291 617 minecraft:black_concrete
setblock 376 286 618 minecraft:red_concrete
fill 376 286 619 376 289 620 minecraft:black_concrete
fill 376 286 626 376 287 627 minecraft:red_concrete
fill 376 286 628 376 291 629 minecraft:black_concrete
fill 376 286 637 376 291 637 minecraft:black_concrete
fill 376 286 638 376 286 639 minecraft:red_concrete
fill 376 286 640 376 291 641 minecraft:black_concrete
fill 376 286 646 377 287 646 minecraft:red_concrete
fill 377 286 604 378 286 604 minecraft:red_concrete
fill 378 286 646 379 291 646 minecraft:black_concrete
fill 379 286 604 379 287 604 minecraft:black_concrete
setblock 380 286 646 minecraft:red_concrete
fill 381 286 646 381 289 646 minecraft:black_concrete
fill 387 286 604 388 291 604 minecraft:black_concrete
fill 388 286 646 389 287 646 minecraft:red_concrete
fill 389 286 604 390 287 604 minecraft:red_concrete
fill 390 286 646 391 291 646 minecraft:black_concrete
fill 396 286 604 396 291 604 minecraft:black_concrete
setblock 396 286 646 minecraft:black_concrete
fill 397 286 604 398 286 604 minecraft:red_concrete
fill 397 286 646 397 287 646 minecraft:red_concrete
fill 399 286 604 399 291 604 minecraft:black_concrete
fill 399 286 646 399 291 646 minecraft:black_concrete
fill 400 286 646 401 286 646 minecraft:red_concrete
fill 401 286 604 401 287 604 minecraft:red_concrete
setblock 402 286 604 minecraft:black_concrete
fill 402 286 646 402 291 646 minecraft:black_concrete
fill 407 286 604 408 291 604 minecraft:black_concrete
fill 408 286 646 409 287 646 minecraft:red_concrete
fill 409 286 604 410 287 604 minecraft:red_concrete
fill 410 286 646 411 291 646 minecraft:black_concrete
fill 417 286 604 417 289 604 minecraft:black_concrete
setblock 418 286 604 minecraft:red_concrete
fill 418 286 605 418 291 606 minecraft:black_concrete
fill 418 286 607 418 287 608 minecraft:red_concrete
fill 418 286 613 418 291 614 minecraft:black_concrete
fill 418 286 615 418 286 616 minecraft:red_concrete
fill 418 286 617 418 291 617 minecraft:black_concrete
fill 418 286 625 418 291 626 minecraft:black_concrete
fill 418 286 627 418 287 628 minecraft:red_concrete
fill 418 286 634 418 289 635 minecraft:black_concrete
setblock 418 286 636 minecraft:red_concrete
fill 418 286 637 418 291 638 minecraft:black_concrete
fill 418 286 639 418 287 639 minecraft:red_concrete
setblock 418 286 640 minecraft:black_concrete
fill 418 286 645 418 291 645 minecraft:black_concrete
setblock 376 287 614 minecraft:red_concrete
fill 376 287 618 376 290 618 minecraft:black_concrete
fill 376 287 634 376 287 635 minecraft:red_concrete
setblock 376 287 638 minecraft:red_concrete
fill 376 287 639 376 290 639 minecraft:black_concrete
fill 377 287 604 377 290 604 minecraft:black_concrete
setblock 378 287 604 minecraft:red_concrete
fill 380 287 646 380 290 646 minecraft:black_concrete
fill 381 287 604 382 287 604 minecraft:red_concrete
fill 384 287 646 384 289 646 minecraft:black_concrete
setblock 385 287 646 minecraft:red_concrete
setblock 396 287 646 minecraft:red_concrete
fill 397 287 604 398 290 604 minecraft:black_concrete
fill 400 287 646 401 290 646 minecraft:black_concrete
setblock 402 287 604 minecraft:red_concrete
setblock 413 287 604 minecraft:red_concrete
fill 413 287 613 414 300 615 minecraft:polished_blackstone
fill 414 287 604 414 289 604 minecraft:black_concrete
fill 416 287 646 416 289 646 minecraft:black_concrete
setblock 417 287 646 minecraft:red_concrete
fill 418 287 604 418 290 604 minecraft:black_concrete
fill 418 287 615 418 290 615 minecraft:black_concrete
setblock 418 287 616 minecraft:red_concrete
fill 418 287 619 418 287 620 minecraft:red_concrete
fill 418 287 636 418 290 636 minecraft:black_concrete
setblock 418 287 640 minecraft:red_concrete
fill 376 288 604 376 288 605 minecraft:red_concrete
fill 376 288 606 376 290 607 minecraft:black_concrete
fill 376 288 612 376 289 613 minecraft:red_concrete
fill 376 288 614 376 293 615 minecraft:black_concrete
fill 376 288 624 376 288 625 minecraft:red_concrete
fill 376 288 626 376 293 627 minecraft:black_concrete
fill 376 288 633 376 289 633 minecraft:red_concrete
fill 376 288 634 376 293 635 minecraft:black_concrete
setblock 376 288 636 minecraft:red_concrete
fill 376 288 638 376 293 638 minecraft:black_concrete
fill 376 288 644 376 289 645 minecraft:red_concrete
fill 376 288 646 377 293 646 minecraft:black_concrete
fill 377 288 605 379 288 605 minecraft:polished_blackstone
fill 377 288 607 377 288 609 minecraft:polished_blackstone
fill 377 288 611 377 288 613 minecraft:polished_blackstone
fill 377 288 615 377 288 617 minecraft:polished_blackstone
fill 377 288 619 377 288 621 minecraft:polished_blackstone
fill 377 288 623 377 288 625 minecraft:polished_blackstone
fill 377 288 627 377 288 629 minecraft:polished_blackstone
fill 377 288 631 377 288 633 minecraft:polished_blackstone
fill 377 288 635 377 288 637 minecraft:polished_blackstone
fill 377 288 639 377 288 641 minecraft:polished_blackstone
fill 377 288 643 377 288 645 minecraft:polished_blackstone
fill 378 288 604 378 293 604 minecraft:black_concrete
fill 379 288 604 380 288 604 minecraft:red_concrete
fill 379 288 645 381 288 645 minecraft:polished_blackstone
fill 381 288 604 382 289 604 minecraft:black_concrete
fill 381 288 605 383 288 605 minecraft:polished_blackstone
fill 383 288 604 383 289 604 minecraft:red_concrete
fill 383 288 645 385 288 645 minecraft:polished_blackstone
fill 385 288 605 387 288 605 minecraft:polished_blackstone
fill 385 288 646 385 293 646 minecraft:black_concrete
fill 386 288 646 387 288 646 minecraft:red_concrete
fill 387 288 645 389 288 645 minecraft:polished_blackstone
fill 388 288 646 389 293 646 minecraft:black_concrete
fill 389 288 604 390 293 604 minecraft:black_concrete
fill 389 288 605 391 288 605 minecraft:polished_blackstone
fill 391 288 604 392 289 604 minecraft:red_concrete
fill 391 288 645 393 288 645 minecraft:polished_blackstone
fill 393 288 605 395 288 605 minecraft:polished_blackstone
fill 394 288 646 395 289 646 minecraft:red_concrete
fill 395 288 645 397 288 645 minecraft:polished_blackstone
fill 396 288 646 397 293 646 minecraft:black_concrete
fill 397 288 605 399 288 605 minecraft:polished_blackstone
setblock 398 288 646 minecraft:red_concrete
fill 399 288 645 401 288 645 minecraft:polished_blackstone
setblock 400 288 604 minecraft:red_concrete
fill 401 288 604 402 293 604 minecraft:black_concrete
fill 401 288 605 403 288 605 minecraft:polished_blackstone
fill 403 288 604 404 289 604 minecraft:red_concrete
fill 403 288 645 405 288 645 minecraft:polished_blackstone
fill 405 288 605 407 288 605 minecraft:polished_blackstone
fill 406 288 646 407 289 646 minecraft:red_concrete
fill 407 288 645 409 288 645 minecraft:polished_blackstone
fill 408 288 628 410 300 630 minecraft:polished_blackstone
fill 408 288 646 409 293 646 minecraft:black_concrete
fill 409 288 604 410 293 604 minecraft:black_concrete
fill 409 288 605 411 288 605 minecraft:polished_blackstone
fill 409 288 627 409 300 627 minecraft:polished_blackstone
fill 411 288 604 412 288 604 minecraft:red_concrete
fill 411 288 645 413 288 645 minecraft:polished_blackstone
fill 412 288 614 412 289 615 minecraft:black_concrete
fill 413 288 604 413 293 604 minecraft:black_concrete
fill 413 288 605 415 288 605 minecraft:polished_blackstone
fill 415 288 614 415 289 615 minecraft:black_concrete
fill 415 288 645 417 288 645 minecraft:polished_blackstone
fill 415 288 646 415 289 646 minecraft:red_concrete
fill 417 288 605 417 288 607 minecraft:polished_blackstone
fill 417 288 609 417 288 611 minecraft:polished_blackstone
fill 417 288 613 417 288 615 minecraft:polished_blackstone
fill 417 288 617 417 288 619 minecraft:polished_blackstone
fill 417 288 621 417 288 623 minecraft:polished_blackstone
fill 417 288 625 417 288 627 minecraft:polished_blackstone
fill 417 288 629 417 288 631 minecraft:polished_blackstone
fill 417 288 633 417 288 635 minecraft:polished_blackstone
fill 417 288 637 417 288 639 minecraft:polished_blackstone
fill 417 288 641 417 288 643 minecraft:polished_blackstone
fill 417 288 646 417 293 646 minecraft:black_concrete
fill 418 288 607 418 293 608 minecraft:black_concrete
fill 418 288 609 418 289 610 minecraft:red_concrete
fill 418 288 616 418 293 616 minecraft:black_concrete
setblock 418 288 618 minecraft:red_concrete
fill 418 288 619 418 293 620 minecraft:black_concrete
fill 418 288 621 418 289 621 minecraft:red_concrete
fill 418 288 627 418 293 628 minecraft:black_concrete
fill 418 288 629 418 288 630 minecraft:red_concrete
fill 418 288 639 418 293 640 minecraft:black_concrete
fill 418 288 641 418 289 642 minecraft:red_concrete
setblock 418 288 646 minecraft:red_concrete
setblock 376 289 604 minecraft:red_concrete
fill 376 289 605 376 292 605 minecraft:black_concrete
setblock 376 289 621 minecraft:red_concrete
setblock 376 289 624 minecraft:red_concrete
fill 376 289 625 376 292 625 minecraft:black_concrete
setblock 376 289 632 minecraft:red_concrete
fill 376 289 636 376 292 636 minecraft:black_concrete
fill 379 289 604 380 291 604 minecraft:black_concrete
fill 382 289 646 383 289 646 minecraft:red_concrete
setblock 384 289 604 minecraft:red_concrete
setblock 386 289 646 minecraft:red_concrete
fill 387 289 646 387 292 646 minecraft:black_concrete
setblock 395 289 604 minecraft:red_concrete
fill 398 289 646 398 292 646 minecraft:black_concrete
fill 400 289 604 400 292 604 minecraft:black_concrete
setblock 403 289 646 minecraft:red_concrete
fill 407 289 628 407 290 629 minecraft:black_concrete
fill 408 289 627 408 290 627 minecraft:black_concrete
fill 409 289 631 409 290 631 minecraft:black_concrete
fill 410 289 627 411 290 627 minecraft:black_concrete
fill 411 289 604 411 292 604 minecraft:black_concrete
fill 411 289 620 413 300 622 minecraft:polished_blackstone
fill 411 289 628 411 290 630 minecraft:black_concrete
setblock 412 289 604 minecraft:red_concrete
setblock 412 289 613 minecraft:black_concrete
fill 413 289 612 414 289 612 minecraft:black_concrete
fill 413 289 616 414 289 616 minecraft:black_concrete
setblock 414 289 646 minecraft:red_concrete
fill 415 289 604 416 289 604 minecraft:red_concrete
setblock 415 289 613 minecraft:black_concrete
fill 418 289 618 418 292 618 minecraft:black_concrete
setblock 418 289 622 minecraft:red_concrete
fill 418 289 629 418 292 629 minecraft:black_concrete
setblock 418 289 630 minecraft:red_concrete
setblock 418 289 633 minecraft:red_concrete
fill 418 289 646 418 292 646 minecraft:black_concrete
fill 376 290 604 376 292 604 minecraft:black_concrete
fill 376 290 610 376 291 611 minecraft:red_concrete
fill 376 290 612 376 295 613 minecraft:black_concrete
fill 376 290 619 376 291 619 minecraft:red_concrete
fill 376 290 620 376 291 621 minecraft:black_concrete
fill 376 290 622 376 290 623 minecraft:red_concrete
fill 376 290 624 376 295 624 minecraft:black_concrete
fill 376 290 630 376 291 631 minecraft:red_concrete
fill 376 290 632 376 295 633 minecraft:black_concrete
fill 376 290 642 376 290 643 minecraft:red_concrete
fill 376 290 644 376 295 645 minecraft:black_concrete
setblock 379 290 607 minecraft:light[level=12]
setblock 379 290 615 minecraft:light[level=12]
setblock 379 290 623 minecraft:light[level=12]
setblock 379 290 631 minecraft:light[level=12]
setblock 379 290 639 minecraft:light[level=12]
fill 381 290 604 381 293 604 minecraft:black_concrete
fill 381 290 646 381 291 646 minecraft:red_concrete
setblock 382 290 604 minecraft:red_concrete
fill 382 290 646 383 295 646 minecraft:black_concrete
fill 383 290 604 384 295 604 minecraft:black_concrete
fill 383 290 626 385 295 627 minecraft:yellow_concrete
fill 384 290 625 384 295 625 minecraft:yellow_concrete
fill 384 290 628 384 295 628 minecraft:yellow_concrete
setblock 384 290 646 minecraft:red_concrete
fill 385 290 604 386 291 604 minecraft:red_concrete
fill 386 290 646 386 295 646 minecraft:black_concrete
setblock 387 290 607 minecraft:light[level=12]
setblock 387 290 615 minecraft:light[level=12]
setblock 387 290 623 minecraft:light[level=12]
setblock 387 290 631 minecraft:light[level=12]
setblock 387 290 639 minecraft:light[level=12]
fill 391 290 604 392 292 604 minecraft:black_concrete
fill 392 290 646 393 291 646 minecraft:red_concrete
fill 393 290 604 394 290 604 minecraft:red_concrete
fill 394 290 646 395 295 646 minecraft:black_concrete
fill 395 290 604 395 295 604 minecraft:black_concrete
setblock 395 290 607 minecraft:light[level=12]
setblock 395 290 615 minecraft:light[level=12]
setblock 395 290 623 minecraft:light[level=12]
setblock 395 290 631 minecraft:light[level=12]
setblock 395 290 639 minecraft:light[level=12]
fill 403 290 604 404 295 604 minecraft:black_concrete
setblock 403 290 607 minecraft:light[level=12]
setblock 403 290 615 minecraft:light[level=12]
setblock 403 290 623 minecraft:light[level=12]
setblock 403 290 631 minecraft:light[level=12]
setblock 403 290 639 minecraft:light[level=12]
fill 403 290 646 403 295 646 minecraft:black_concrete
fill 404 290 646 405 290 646 minecraft:red_concrete
fill 405 290 604 406 291 604 minecraft:red_concrete
fill 406 290 628 406 290 629 minecraft:black_concrete
fill 406 290 646 407 295 646 minecraft:black_concrete
setblock 407 290 627 minecraft:black_concrete
fill 407 290 630 407 290 631 minecraft:black_concrete
fill 408 290 626 410 290 626 minecraft:black_concrete
setblock 408 290 631 minecraft:black_concrete
fill 410 290 620 410 291 622 minecraft:black_concrete
fill 410 290 631 411 290 631 minecraft:black_concrete
setblock 411 290 607 minecraft:light[level=12]
setblock 411 290 615 minecraft:light[level=12]
fill 411 290 619 413 291 619 minecraft:black_concrete
fill 411 290 623 413 291 623 minecraft:black_concrete
setblock 411 290 639 minecraft:light[level=12]
fill 412 290 604 412 295 604 minecraft:black_concrete
fill 412 290 628 412 290 630 minecraft:black_concrete
fill 412 290 646 413 291 646 minecraft:red_concrete
setblock 414 290 604 minecraft:red_concrete
fill 414 290 621 414 291 621 minecraft:black_concrete
fill 414 290 646 415 295 646 minecraft:black_concrete
fill 415 290 604 416 295 604 minecraft:black_concrete
setblock 416 290 646 minecraft:red_concrete
fill 417 290 604 417 291 604 minecraft:red_concrete
fill 418 290 609 418 295 610 minecraft:black_concrete
fill 418 290 611 418 290 612 minecraft:red_concrete
fill 418 290 621 418 295 622 minecraft:black_concrete
fill 418 290 623 418 291 624 minecraft:red_concrete
fill 418 290 630 418 295 630 minecraft:black_concrete
fill 418 290 631 418 290 632 minecraft:red_concrete
fill 418 290 633 418 291 634 minecraft:black_concrete
fill 418 290 635 418 291 635 minecraft:red_concrete
fill 418 290 641 418 295 642 minecraft:black_concrete
fill 418 290 643 418 291 644 minecraft:red_concrete
fill 376 291 606 376 293 606 minecraft:black_concrete
setblock 376 291 607 minecraft:red_concrete
setblock 376 291 618 minecraft:red_concrete
fill 376 291 622 376 294 623 minecraft:black_concrete
setblock 376 291 639 minecraft:red_concrete
setblock 376 291 642 minecraft:red_concrete
fill 376 291 643 376 294 643 minecraft:black_concrete
setblock 377 291 604 minecraft:red_concrete
setblock 380 291 646 minecraft:red_concrete
fill 382 291 604 382 293 604 minecraft:black_concrete
fill 382 291 625 382 294 628 minecraft:yellow_concrete
fill 383 291 625 383 294 625 minecraft:yellow_concrete
fill 383 291 628 383 294 628 minecraft:yellow_concrete
fill 384 291 624 384 294 624 minecraft:yellow_concrete
fill 384 291 629 384 294 629 minecraft:yellow_concrete
fill 384 291 646 384 294 646 minecraft:black_concrete
fill 385 291 625 385 294 625 minecraft:yellow_concrete
fill 385 291 628 385 294 628 minecraft:yellow_concrete
fill 386 291 626 386 294 627 minecraft:yellow_concrete
fill 393 291 604 393 294 604 minecraft:black_concrete
setblock 394 291 604 minecraft:red_concrete
fill 397 291 604 398 291 604 minecraft:red_concrete
fill 400 291 646 401 291 646 minecraft:red_concrete
setblock 404 291 646 minecraft:red_concrete
fill 405 291 646 405 294 646 minecraft:black_concrete
fill 409 291 620 409 291 622 minecraft:black_concrete
setblock 410 291 619 minecraft:black_concrete
setblock 410 291 623 minecraft:black_concrete
fill 411 291 618 412 291 618 minecraft:black_concrete
setblock 412 291 624 minecraft:black_concrete
fill 414 291 604 414 294 604 minecraft:black_concrete
fill 414 291 619 414 291 620 minecraft:black_concrete
fill 414 291 622 414 291 623 minecraft:black_concrete
fill 416 291 646 416 294 646 minecraft:black_concrete
setblock 418 291 604 minecraft:red_concrete
fill 418 291 611 418 294 611 minecraft:black_concrete
setblock 418 291 612 minecraft:red_concrete
setblock 418 291 615 minecraft:red_concrete
fill 418 291 631 418 294 632 minecraft:black_concrete
setblock 418 291 636 minecraft:red_concrete
fill 376 292 607 376 297 607 minecraft:black_concrete
fill 376 292 608 376 292 609 minecraft:red_concrete
fill 376 292 610 376 297 611 minecraft:black_concrete
fill 376 292 616 376 293 617 minecraft:red_concrete
fill 376 292 618 376 297 619 minecraft:black_concrete
setblock 376 292 620 minecraft:red_concrete
fill 376 292 621 376 295 621 minecraft:black_concrete
fill 376 292 628 376 293 629 minecraft:red_concrete
fill 376 292 630 376 297 631 minecraft:black_concrete
fill 376 292 637 376 293 637 minecraft:red_concrete
fill 376 292 639 376 297 639 minecraft:black_concrete
fill 376 292 640 376 292 641 minecraft:red_concrete
fill 376 292 642 376 297 642 minecraft:black_concrete
fill 377 292 604 377 297 604 minecraft:black_concrete
fill 378 292 646 379 293 646 minecraft:red_concrete
fill 379 292 604 379 293 604 minecraft:red_concrete
setblock 380 292 604 minecraft:black_concrete
fill 380 292 646 381 297 646 minecraft:black_concrete
fill 383 292 624 383 293 624 minecraft:yellow_concrete
fill 383 292 629 383 293 629 minecraft:yellow_concrete
fill 385 292 604 386 297 604 minecraft:black_concrete
fill 385 292 624 385 293 624 minecraft:yellow_concrete
fill 385 292 629 385 293 629 minecraft:yellow_concrete
fill 386 292 625 386 293 625 minecraft:yellow_concrete
fill 386 292 628 386 293 628 minecraft:yellow_concrete
fill 387 292 604 388 293 604 minecraft:red_concrete
fill 390 292 646 391 292 646 minecraft:red_concrete
fill 392 292 646 393 297 646 minecraft:black_concrete
fill 394 292 604 394 294 604 minecraft:black_concrete
setblock 396 292 604 minecraft:red_concrete
fill 397 292 604 398 297 604 minecraft:black_concrete
fill 399 292 604 399 293 604 minecraft:red_concrete
fill 399 292 646 399 293 646 minecraft:red_concrete
fill 400 292 646 401 297 646 minecraft:black_concrete
setblock 402 292 646 minecraft:red_concrete
fill 404 292 646 404 297 646 minecraft:black_concrete
fill 405 292 604 406 297 604 minecraft:black_concrete
fill 407 292 604 408 292 604 minecraft:red_concrete
fill 410 292 646 411 293 646 minecraft:red_concrete
fill 412 292 646 413 297 646 minecraft:black_concrete
fill 417 292 604 418 297 604 minecraft:black_concrete
fill 418 292 605 418 293 606 minecraft:red_concrete
fill 418 292 612 418 297 612 minecraft:black_concrete
fill 418 292 613 418 292 614 minecraft:red_concrete
fill 418 292 615 418 297 615 minecraft:black_concrete
fill 418 292 617 418 293 617 minecraft:red_concrete
fill 418 292 623 418 297 624 minecraft:black_concrete
fill 418 292 625 418 293 626 minecraft:red_concrete
fill 418 292 633 418 295 633 minecraft:black_concrete
setblock 418 292 634 minecraft:red_concrete
fill 418 292 635 418 297 636 minecraft:black_concrete
fill 418 292 637 418 293 638 minecraft:red_concrete
fill 418 292 643 418 297 644 minecraft:black_concrete
setblock 418 292 645 minecraft:red_concrete
fill 376 293 604 376 293 605 minecraft:red_concrete
setblock 376 293 608 minecraft:red_concrete
fill 376 293 609 376 296 609 minecraft:black_concrete
fill 376 293 620 376 296 620 minecraft:black_concrete
setblock 376 293 625 minecraft:red_concrete
setblock 376 293 636 minecraft:red_concrete
fill 376 293 640 376 296 641 minecraft:black_concrete
setblock 380 293 604 minecraft:red_concrete
setblock 387 293 646 minecraft:red_concrete
setblock 390 293 646 minecraft:red_concrete
setblock 391 293 604 minecraft:red_concrete
fill 391 293 646 391 296 646 minecraft:black_concrete
fill 392 293 604 392 295 604 minecraft:black_concrete
fill 396 293 604 396 296 604 minecraft:black_concrete
setblock 398 293 646 minecraft:red_concrete
setblock 400 293 604 minecraft:red_concrete
fill 402 293 646 402 296 646 minecraft:black_concrete
fill 407 293 604 407 296 604 minecraft:black_concrete
setblock 408 293 604 minecraft:red_concrete
setblock 411 293 604 minecraft:red_concrete
fill 418 293 613 418 296 614 minecraft:black_concrete
setblock 418 293 618 minecraft:red_concrete
setblock 418 293 629 minecraft:red_concrete
fill 418 293 634 418 296 634 minecraft:black_concrete
fill 418 293 645 418 296 645 minecraft:black_concrete
setblock 418 293 646 minecraft:red_concrete
fill 376 294 604 376 299 605 minecraft:black_concrete
setblock 376 294 606 minecraft:red_concrete
fill 376 294 608 376 299 608 minecraft:black_concrete
fill 376 294 614 376 295 615 minecraft:red_concrete
fill 376 294 616 376 299 617 minecraft:black_concrete
fill 376 294 625 376 299 625 minecraft:black_concrete
fill 376 294 626 376 294 627 minecraft:red_concrete
fill 376 294 628 376 299 629 minecraft:black_concrete
fill 376 294 634 376 295 635 minecraft:red_concrete
fill 376 294 636 376 299 637 minecraft:black_concrete
setblock 376 294 638 minecraft:red_concrete
fill 376 294 646 377 295 646 minecraft:red_concrete
fill 377 294 605 379 294 605 minecraft:polished_blackstone
fill 377 294 607 377 294 609 minecraft:polished_blackstone
fill 377 294 611 377 294 613 minecraft:polished_blackstone
fill 377 294 615 377 294 617 minecraft:polished_blackstone
fill 377 294 619 377 294 621 minecraft:polished_blackstone
fill 377 294 623 377 294 625 minecraft:polished_blackstone
fill 377 294 627 377 294 629 minecraft:polished_blackstone
fill 377 294 631 377 294 633 minecraft:polished_blackstone
fill 377 294 635 377 294 637 minecraft:polished_blackstone
fill 377 294 639 377 294 641 minecraft:polished_blackstone
fill 377 294 643 377 294 645 minecraft:polished_blackstone
setblock 378 294 604 minecraft:red_concrete
fill 378 294 646 379 299 646 minecraft:black_concrete
fill 379 294 604 380 299 604 minecraft:black_concrete
fill 379 294 645 381 294 645 minecraft:polished_blackstone
fill 381 294 604 382 295 604 minecraft:red_concrete
fill 381 294 605 383 294 605 minecraft:polished_blackstone
fill 383 294 645 385 294 645 minecraft:polished_blackstone
fill 385 294 605 387 294 605 minecraft:polished_blackstone
fill 385 294 646 385 295 646 minecraft:red_concrete
fill 387 294 604 388 299 604 minecraft:black_concrete
fill 387 294 645 389 294 645 minecraft:polished_blackstone
fill 387 294 646 387 299 646 minecraft:black_concrete
fill 388 294 646 389 294 646 minecraft:red_concrete
fill 389 294 604 390 294 604 minecraft:red_concrete
fill 389 294 605 391 294 605 minecraft:polished_blackstone
fill 390 294 646 390 299 646 minecraft:black_concrete
fill 391 294 604 391 295 604 minecraft:black_concrete
fill 391 294 645 393 294 645 minecraft:polished_blackstone
fill 393 294 605 395 294 605 minecraft:polished_blackstone
fill 395 294 645 397 294 645 minecraft:polished_blackstone
fill 396 294 646 397 295 646 minecraft:red_concrete
fill 397 294 605 399 294 605 minecraft:polished_blackstone
fill 398 294 646 399 299 646 minecraft:black_concrete
fill 399 294 604 400 299 604 minecraft:black_concrete
fill 399 294 645 401 294 645 minecraft:polished_blackstone
fill 401 294 604 402 295 604 minecraft:red_concrete
fill 401 294 605 403 294 605 minecraft:polished_blackstone
fill 403 294 645 405 294 645 minecraft:polished_blackstone
fill 405 294 605 407 294 605 minecraft:polished_blackstone
fill 407 294 645 409 294 645 minecraft:polished_blackstone
fill 408 294 604 408 299 604 minecraft:black_concrete
fill 408 294 646 409 294 646 minecraft:red_concrete
fill 409 294 604 410 294 604 minecraft:red_concrete
fill 409 294 605 411 294 605 minecraft:polished_blackstone
fill 410 294 646 411 299 646 minecraft:black_concrete
fill 411 294 604 411 299 604 minecraft:black_concrete
fill 411 294 645 413 294 645 minecraft:polished_blackstone
fill 413 294 604 413 295 604 minecraft:red_concrete
fill 413 294 605 415 294 605 minecraft:polished_blackstone
fill 415 294 645 417 294 645 minecraft:polished_blackstone
fill 417 294 605 417 294 607 minecraft:polished_blackstone
fill 417 294 609 417 294 611 minecraft:polished_blackstone
fill 417 294 613 417 294 615 minecraft:polished_blackstone
fill 417 294 617 417 294 619 minecraft:polished_blackstone
fill 417 294 621 417 294 623 minecraft:polished_blackstone
fill 417 294 625 417 294 627 minecraft:polished_blackstone
fill 417 294 629 417 294 631 minecraft:polished_blackstone
fill 417 294 633 417 294 635 minecraft:polished_blackstone
fill 417 294 637 417 294 639 minecraft:polished_blackstone
fill 417 294 641 417 294 643 minecraft:polished_blackstone
fill 417 294 646 417 295 646 minecraft:red_concrete
fill 418 294 605 418 299 606 minecraft:black_concrete
fill 418 294 607 418 295 608 minecraft:red_concrete
setblock 418 294 616 minecraft:red_concrete
fill 418 294 617 418 299 618 minecraft:black_concrete
fill 418 294 619 418 295 620 minecraft:red_concrete
fill 418 294 625 418 299 626 minecraft:black_concrete
fill 418 294 627 418 294 628 minecraft:red_concrete
fill 418 294 629 418 299 629 minecraft:black_concrete
fill 418 294 637 418 299 638 minecraft:black_concrete
fill 418 294 639 418 295 640 minecraft:red_concrete
fill 418 294 646 418 299 646 minecraft:black_concrete
fill 376 295 606 376 298 606 minecraft:black_concrete
fill 376 295 622 376 295 623 minecraft:red_concrete
setblock 376 295 626 minecraft:red_concrete
fill 376 295 627 376 298 627 minecraft:black_concrete
fill 376 295 638 376 298 638 minecraft:black_concrete
setblock 376 295 643 minecraft:red_concrete
fill 378 295 604 378 298 604 minecraft:black_concrete
setblock 384 295 646 minecraft:red_concrete
fill 388 295 646 389 298 646 minecraft:black_concrete
fill 389 295 604 389 298 604 minecraft:black_concrete
setblock 390 295 604 minecraft:red_concrete
fill 393 295 604 394 295 604 minecraft:red_concrete
setblock 405 295 646 minecraft:red_concrete
setblock 408 295 646 minecraft:red_concrete
fill 409 295 604 410 298 604 minecraft:black_concrete
fill 409 295 646 409 298 646 minecraft:black_concrete
setblock 414 295 604 minecraft:red_concrete
setblock 416 295 646 minecraft:red_concrete
setblock 418 295 611 minecraft:red_concrete
fill 418 295 616 418 298 616 minecraft:black_concrete
fill 418 295 627 418 298 627 minecraft:black_concrete
setblock 418 295 628 minecraft:red_concrete
fill 418 295 631 418 295 632 minecraft:red_concrete
fill 376 296 612 376 296 613 minecraft:red_concrete
fill 376 296 614 376 307 615 minecraft:black_concrete
fill 376 296 621 376 297 621 minecraft:red_concrete
fill 376 296 622 376 307 623 minecraft:black_concrete
setblock 376 296 624 minecraft:red_concrete
fill 376 296 626 376 307 626 minecraft:black_concrete
fill 376 296 632 376 297 633 minecraft:red_concrete
fill 376 296 634 376 307 635 minecraft:black_concrete
fill 376 296 643 376 307 643 minecraft:black_concrete
fill 376 296 644 376 296 645 minecraft:red_concrete
fill 376 296 646 377 307 646 minecraft:black_concrete
fill 381 296 604 382 307 604 minecraft:black_concrete
fill 382 296 646 383 297 646 minecraft:red_concrete
fill 383 296 604 384 297 604 minecraft:red_concrete
fill 384 296 646 385 307 646 minecraft:black_concrete
setblock 386 296 646 minecraft:red_concrete
fill 390 296 604 390 307 604 minecraft:black_concrete
fill 391 296 604 392 296 604 minecraft:red_concrete
fill 393 296 604 394 297 604 minecraft:black_concrete
fill 394 296 646 395 297 646 minecraft:red_concrete
fill 395 296 604 395 297 604 minecraft:red_concrete
fill 396 296 646 397 307 646 minecraft:black_concrete
fill 401 296 604 402 307 604 minecraft:black_concrete
fill 403 296 604 404 297 604 minecraft:red_concrete
fill 403 296 646 403 297 646 minecraft:red_concrete
fill 405 296 646 405 307 646 minecraft:black_concrete
fill 406 296 646 407 296 646 minecraft:red_concrete
fill 408 296 646 408 307 646 minecraft:black_concrete
setblock 412 296 604 minecraft:red_concrete
fill 413 296 604 414 307 604 minecraft:black_concrete
fill 414 296 646 415 297 646 minecraft:red_concrete
fill 415 296 604 416 297 604 minecraft:red_concrete
fill 416 296 646 417 307 646 minecraft:black_concrete
fill 418 296 607 418 307 608 minecraft:black_concrete
fill 418 296 609 418 296 610 minecraft:red_concrete
fill 418 296 611 418 307 611 minecraft:black_concrete
fill 418 296 619 418 307 620 minecraft:black_concrete
fill 418 296 621 418 297 622 minecraft:red_concrete
fill 418 296 628 418 307 628 minecraft:black_concrete
setblock 418 296 630 minecraft:red_concrete
fill 418 296 631 418 307 632 minecraft:black_concrete
fill 418 296 633 418 297 633 minecraft:red_concrete
fill 418 296 639 418 307 640 minecraft:black_concrete
fill 418 296 641 418 296 642 minecraft:red_concrete
setblock 376 297 609 minecraft:red_concrete
setblock 376 297 612 minecraft:red_concrete
fill 376 297 613 376 307 613 minecraft:black_concrete
setblock 376 297 620 minecraft:red_concrete
fill 376 297 624 376 307 624 minecraft:black_concrete
fill 376 297 640 376 297 641 minecraft:red_concrete
setblock 376 297 644 minecraft:red_concrete
fill 376 297 645 376 307 645 minecraft:black_concrete
fill 386 297 646 386 307 646 minecraft:black_concrete
fill 391 297 604 392 299 604 minecraft:black_concrete
setblock 391 297 646 minecraft:red_concrete
setblock 396 297 604 minecraft:red_concrete
setblock 402 297 646 minecraft:red_concrete
fill 406 297 628 407 297 630 minecraft:red_concrete
fill 406 297 646 407 307 646 minecraft:black_concrete
setblock 407 297 604 minecraft:red_concrete
fill 407 297 626 408 297 627 minecraft:red_concrete
fill 407 297 631 411 297 631 minecraft:red_concrete
fill 409 297 620 410 297 622 minecraft:red_concrete
fill 409 297 626 411 297 626 minecraft:red_concrete
setblock 409 297 632 minecraft:red_concrete
fill 410 297 619 414 297 619 minecraft:red_concrete
fill 410 297 623 414 297 623 minecraft:red_concrete
fill 410 297 627 412 297 627 minecraft:red_concrete
fill 411 297 618 413 297 618 minecraft:red_concrete
fill 411 297 624 413 297 624 minecraft:red_concrete
fill 411 297 628 412 297 630 minecraft:red_concrete
fill 412 297 604 412 307 604 minecraft:black_concrete
fill 412 297 613 412 298 615 minecraft:red_concrete
fill 413 297 612 414 297 612 minecraft:red_concrete
fill 413 297 616 414 298 616 minecraft:red_concrete
fill 414 297 620 414 298 622 minecraft:red_concrete
fill 415 297 613 415 298 615 minecraft:red_concrete
setblock 415 297 621 minecraft:red_concrete
fill 418 297 609 418 307 609 minecraft:black_concrete
setblock 418 297 610 minecraft:red_concrete
fill 418 297 613 418 297 614 minecraft:red_concrete
fill 418 297 630 418 307 630 minecraft:black_concrete
setblock 418 297 634 minecraft:red_concrete
fill 418 297 641 418 307 641 minecraft:black_concrete
setblock 418 297 642 minecraft:red_concrete
setblock 418 297 645 minecraft:red_concrete
fill 376 298 607 376 299 607 minecraft:red_concrete
fill 376 298 609 376 307 609 minecraft:black_concrete
fill 376 298 610 376 298 611 minecraft:red_concrete
fill 376 298 612 376 307 612 minecraft:black_concrete
fill 376 298 618 376 299 619 minecraft:red_concrete
fill 376 298 620 376 307 621 minecraft:black_concrete
fill 376 298 630 376 298 631 minecraft:red_concrete
fill 376 298 632 376 307 633 minecraft:black_concrete
fill 376 298 639 376 299 639 minecraft:red_concrete
fill 376 298 640 376 307 641 minecraft:black_concrete
setblock 376 298 642 minecraft:red_concrete
fill 376 298 644 376 307 644 minecraft:black_concrete
fill 377 298 604 377 299 604 minecraft:red_concrete
setblock 379 298 607 minecraft:light[level=12]
setblock 379 298 615 minecraft:light[level=12]
setblock 379 298 623 minecraft:light[level=12]
setblock 379 298 631 minecraft:light[level=12]
setblock 379 298 639 minecraft:light[level=12]
fill 380 298 646 381 299 646 minecraft:red_concrete
fill 382 298 646 383 307 646 minecraft:black_concrete
fill 383 298 604 384 307 604 minecraft:black_concrete
fill 385 298 604 386 299 604 minecraft:red_concrete
setblock 387 298 607 minecraft:light[level=12]
setblock 387 298 615 minecraft:light[level=12]
setblock 387 298 623 minecraft:light[level=12]
setblock 387 298 631 minecraft:light[level=12]
setblock 387 298 639 minecraft:light[level=12]
fill 391 298 646 391 307 646 minecraft:black_concrete
fill 392 298 646 393 298 646 minecraft:red_concrete
fill 393 298 604 393 307 604 minecraft:black_concrete
setblock 394 298 604 minecraft:red_concrete
fill 394 298 646 395 307 646 minecraft:black_concrete
fill 395 298 604 396 307 604 minecraft:black_concrete
setblock 395 298 607 minecraft:light[level=12]
setblock 395 298 615 minecraft:light[level=12]
setblock 395 298 623 minecraft:light[level=12]
setblock 395 298 631 minecraft:light[level=12]
setblock 395 298 639 minecraft:light[level=12]
fill 397 298 604 398 299 604 minecraft:red_concrete
fill 400 298 646 401 299 646 minecraft:red_concrete
fill 402 298 646 403 307 646 minecraft:black_concrete
fill 403 298 604 404 307 604 minecraft:black_concrete
setblock 403 298 607 minecraft:light[level=12]
setblock 403 298 615 minecraft:light[level=12]
setblock 403 298 623 minecraft:light[level=12]
setblock 403 298 631 minecraft:light[level=12]
setblock 403 298 639 minecraft:light[level=12]
setblock 404 298 646 minecraft:red_concrete
fill 405 298 604 406 298 604 minecraft:red_concrete
fill 407 298 604 407 307 604 minecraft:black_concrete
fill 407 298 627 407 298 630 minecraft:red_concrete
fill 408 298 626 408 298 627 minecraft:red_concrete
fill 408 298 631 410 298 631 minecraft:red_concrete
fill 409 298 626 410 298 626 minecraft:red_concrete
fill 410 298 619 410 298 623 minecraft:red_concrete
fill 410 298 627 411 298 627 minecraft:red_concrete
setblock 411 298 607 minecraft:light[level=12]
setblock 411 298 615 minecraft:light[level=12]
fill 411 298 619 413 298 619 minecraft:red_concrete
fill 411 298 623 413 298 623 minecraft:red_concrete
fill 411 298 628 411 298 630 minecraft:red_concrete
setblock 411 298 631 minecraft:light[level=12]
setblock 411 298 639 minecraft:light[level=12]
fill 412 298 646 413 299 646 minecraft:red_concrete
fill 414 298 646 415 307 646 minecraft:black_concrete
fill 415 298 604 416 307 604 minecraft:black_concrete
fill 417 298 604 418 299 604 minecraft:red_concrete
fill 418 298 610 418 307 610 minecraft:black_concrete
setblock 418 298 612 minecraft:red_concrete
fill 418 298 613 418 307 614 minecraft:black_concrete
fill 418 298 615 418 299 615 minecraft:red_concrete
fill 418 298 621 418 307 622 minecraft:black_concrete
fill 418 298 623 418 298 624 minecraft:red_concrete
fill 418 298 633 418 307 634 minecraft:black_concrete
fill 418 298 635 418 299 636 minecraft:red_concrete
fill 418 298 642 418 307 642 minecraft:black_concrete
fill 418 298 643 418 298 644 minecraft:red_concrete
fill 418 298 645 418 307 645 minecraft:black_concrete
setblock 376 299 606 minecraft:red_concrete
fill 376 299 610 376 307 611 minecraft:black_concrete
setblock 376 299 627 minecraft:red_concrete
setblock 376 299 630 minecraft:red_concrete
fill 376 299 631 376 307 631 minecraft:black_concrete
setblock 376 299 638 minecraft:red_concrete
fill 376 299 642 376 307 642 minecraft:black_concrete
setblock 378 299 604 minecraft:red_concrete
fill 388 299 646 389 299 646 minecraft:red_concrete
setblock 389 299 604 minecraft:red_concrete
setblock 392 299 646 minecraft:red_concrete
fill 393 299 646 393 307 646 minecraft:black_concrete
fill 394 299 604 394 307 604 minecraft:black_concrete
fill 404 299 646 404 307 646 minecraft:black_concrete
fill 405 299 604 405 307 604 minecraft:black_concrete
setblock 406 299 604 minecraft:red_concrete
fill 407 299 628 407 299 629 minecraft:red_concrete
setblock 408 299 627 minecraft:red_concrete
fill 409 299 604 410 299 604 minecraft:red_concrete
setblock 409 299 646 minecraft:red_concrete
fill 410 299 620 410 299 622 minecraft:red_concrete
setblock 410 299 627 minecraft:red_concrete
fill 411 299 619 412 299 619 minecraft:red_concrete
fill 411 299 623 412 299 623 minecraft:red_concrete
fill 411 299 628 411 299 629 minecraft:red_concrete
setblock 412 299 614 minecraft:red_concrete
setblock 414 299 621 minecraft:red_concrete
setblock 415 299 614 minecraft:red_concrete
fill 418 299 612 418 307 612 minecraft:black_concrete
setblock 418 299 616 minecraft:red_concrete
fill 418 299 623 418 307 623 minecraft:black_concrete
setblock 418 299 624 minecraft:red_concrete
setblock 418 299 627 minecraft:red_concrete
fill 418 299 643 418 307 644 minecraft:black_concrete
fill 376 300 604 376 300 605 minecraft:red_concrete
fill 376 300 606 376 307 607 minecraft:black_concrete
setblock 376 300 608 minecraft:red_concrete
fill 376 300 616 376 300 617 minecraft:red_concrete
fill 376 300 618 376 307 619 minecraft:black_concrete
setblock 376 300 625 minecraft:red_concrete
fill 376 300 627 376 307 627 minecraft:black_concrete
fill 376 300 628 376 300 629 minecraft:red_concrete
fill 376 300 630 376 307 630 minecraft:black_concrete
fill 376 300 636 376 300 637 minecraft:red_concrete
fill 376 300 638 376 307 639 minecraft:black_concrete
fill 377 300 604 378 307 604 minecraft:black_concrete
fill 377 300 605 379 300 605 minecraft:polished_blackstone
fill 377 300 607 377 300 609 minecraft:polished_blackstone
fill 377 300 611 377 300 613 minecraft:polished_blackstone
fill 377 300 615 377 300 617 minecraft:polished_blackstone
fill 377 300 619 377 300 621 minecraft:polished_blackstone
fill 377 300 623 377 300 625 minecraft:polished_blackstone
fill 377 300 627 377 300 629 minecraft:polished_blackstone
fill 377 300 631 377 300 633 minecraft:polished_blackstone
fill 377 300 635 377 300 637 minecraft:polished_blackstone
fill 377 300 639 377 300 641 minecraft:polished_blackstone
fill 377 300 643 377 300 645 minecraft:polished_blackstone
fill 378 300 646 379 300 646 minecraft:red_concrete
fill 379 300 604 380 300 604 minecraft:red_concrete
fill 379 300 645 381 300 645 minecraft:polished_blackstone
fill 380 300 646 381 307 646 minecraft:black_concrete
fill 381 300 605 383 300 605 minecraft:polished_blackstone
fill 383 300 645 385 300 645 minecraft:polished_blackstone
fill 385 300 604 386 307 604 minecraft:black_concrete
fill 385 300 605 387 300 605 minecraft:polished_blackstone
fill 387 300 604 388 300 604 minecraft:red_concrete
fill 387 300 645 389 300 645 minecraft:polished_blackstone
setblock 387 300 646 minecraft:red_concrete
fill 388 300 646 389 307 646 minecraft:black_concrete
fill 389 300 604 389 307 604 minecraft:black_concrete
fill 389 300 605 391 300 605 minecraft:polished_blackstone
setblock 390 300 646 minecraft:red_concrete
setblock 391 300 604 minecraft:red_concrete
fill 391 300 645 393 300 645 minecraft:polished_blackstone
fill 392 300 604 392 307 604 minecraft:black_concrete
fill 392 300 646 392 307 646 minecraft:black_concrete
fill 393 300 605 395 300 605 minecraft:polished_blackstone
fill 395 300 645 397 300 645 minecraft:polished_blackstone
fill 397 300 604 398 307 604 minecraft:black_concrete
fill 397 300 605 399 300 605 minecraft:polished_blackstone
fill 398 300 646 399 300 646 minecraft:red_concrete
fill 399 300 604 400 300 604 minecraft:red_concrete
fill 399 300 645 401 300 645 minecraft:polished_blackstone
fill 400 300 646 401 307 646 minecraft:black_concrete
fill 401 300 605 403 300 605 minecraft:polished_blackstone
fill 403 300 645 405 300 645 minecraft:polished_blackstone
fill 405 300 605 407 300 605 minecraft:polished_blackstone
fill 406 300 604 406 307 604 minecraft:black_concrete
fill 407 300 645 409 300 645 minecraft:polished_blackstone
setblock 408 300 604 minecraft:red_concrete
fill 409 300 604 410 307 604 minecraft:black_concrete
fill 409 300 605 411 300 605 minecraft:polished_blackstone
fill 409 300 646 409 307 646 minecraft:black_concrete
fill 410 300 646 411 300 646 minecraft:red_concrete
setblock 411 300 604 minecraft:red_concrete
fill 411 300 645 413 300 645 minecraft:polished_blackstone
fill 412 300 646 413 307 646 minecraft:black_concrete
fill 413 300 605 415 300 605 minecraft:polished_blackstone
fill 415 300 645 417 300 645 minecraft:polished_blackstone
fill 417 300 604 418 307 604 minecraft:black_concrete
fill 417 300 605 417 300 607 minecraft:polished_blackstone
fill 417 300 609 417 300 611 minecraft:polished_blackstone
fill 417 300 613 417 300 615 minecraft:polished_blackstone
fill 417 300 617 417 300 619 minecraft:polished_blackstone
fill 417 300 621 417 300 623 minecraft:polished_blackstone
fill 417 300 625 417 300 627 minecraft:polished_blackstone
fill 417 300 629 417 300 631 minecraft:polished_blackstone
fill 417 300 633 417 300 635 minecraft:polished_blackstone
fill 417 300 637 417 300 639 minecraft:polished_blackstone
fill 417 300 641 417 300 643 minecraft:polished_blackstone
fill 418 300 605 418 300 606 minecraft:red_concrete
fill 418 300 615 418 307 616 minecraft:black_concrete
fill 418 300 617 418 300 618 minecraft:red_concrete
fill 418 300 624 418 307 624 minecraft:black_concrete
fill 418 300 625 418 300 626 minecraft:red_concrete
fill 418 300 627 418 307 627 minecraft:black_concrete
setblock 418 300 629 minecraft:red_concrete
fill 418 300 635 418 307 636 minecraft:black_concrete
fill 418 300 637 418 300 638 minecraft:red_concrete
setblock 418 300 646 minecraft:red_concrete
fill 376 301 604 376 307 605 minecraft:black_concrete
fill 376 301 608 376 307 608 minecraft:black_concrete
fill 376 301 616 376 307 617 minecraft:black_concrete
fill 376 301 625 376 307 625 minecraft:black_concrete
fill 376 301 628 376 307 629 minecraft:black_concrete
fill 376 301 636 376 307 637 minecraft:black_concrete
fill 378 301 646 379 307 646 minecraft:black_concrete
fill 379 301 604 380 307 604 minecraft:black_concrete
fill 387 301 604 388 307 604 minecraft:black_concrete
fill 387 301 646 387 307 646 minecraft:black_concrete
fill 390 301 646 390 307 646 minecraft:black_concrete
fill 391 301 604 391 307 604 minecraft:black_concrete
fill 398 301 646 399 307 646 minecraft:black_concrete
fill 399 301 604 400 307 604 minecraft:black_concrete
fill 408 301 604 408 307 604 minecraft:black_concrete
fill 410 301 646 411 307 646 minecraft:black_concrete
fill 411 301 604 411 307 604 minecraft:black_concrete
fill 418 301 605 418 307 606 minecraft:black_concrete
fill 418 301 617 418 307 618 minecraft:black_concrete
fill 418 301 625 418 307 626 minecraft:black_concrete
fill 418 301 629 418 307 629 minecraft:black_concrete
fill 418 301 637 418 307 638 minecraft:black_concrete
fill 418 301 646 418 307 646 minecraft:black_concrete
