setblock 465 130 623 minecraft:black_concrete
fill 465 130 624 465 188 624 minecraft:gray_concrete
fill 465 130 625 465 135 625 minecraft:pearlescent_froglight
fill 465 130 626 465 185 627 minecraft:gray_concrete
fill 465 130 631 465 184 632 minecraft:gray_concrete
fill 465 130 633 465 135 633 minecraft:pearlescent_froglight
fill 465 130 634 465 187 638 minecraft:gray_concrete
fill 465 130 639 465 130 640 minecraft:black_concrete
fill 465 130 641 465 135 641 minecraft:pearlescent_froglight
fill 465 130 642 465 183 645 minecraft:gray_concrete
fill 423 131 611 423 187 611 minecraft:gray_concrete
fill 423 131 613 423 183 613 minecraft:gray_concrete
fill 423 131 615 423 187 615 minecraft:gray_concrete
fill 423 131 624 423 183 624 minecraft:gray_concrete
fill 423 131 644 423 185 644 minecraft:gray_concrete
fill 426 131 619 426 131 624 minecraft:quartz_block
setblock 426 131 625 minecraft:white_concrete
fill 426 131 626 426 131 631 minecraft:quartz_block
fill 427 131 604 428 187 604 minecraft:gray_concrete
fill 427 131 617 427 131 619 minecraft:quartz_block
fill 427 131 620 428 131 624 minecraft:white_concrete
fill 427 131 626 428 131 630 minecraft:white_concrete
fill 427 131 631 427 131 633 minecraft:quartz_block
fill 428 131 615 428 131 616 minecraft:quartz_block
fill 428 131 617 428 131 619 minecraft:white_concrete
setblock 428 131 625 minecraft:white_concrete
fill 428 131 631 428 131 633 minecraft:white_concrete
fill 428 131 634 428 131 635 minecraft:quartz_block
fill 429 131 614 429 131 615 minecraft:quartz_block
fill 429 131 616 430 131 616 minecraft:white_concrete
fill 429 131 618 429 131 619 minecraft:white_concrete
fill 429 131 631 429 131 632 minecraft:white_concrete
fill 429 131 634 430 131 634 minecraft:white_concrete
fill 429 131 635 429 131 636 minecraft:quartz_block
setblock 430 131 613 minecraft:quartz_block
fill 430 131 614 431 131 615 minecraft:white_concrete
setblock 430 131 617 minecraft:white_concrete
setblock 430 131 633 minecraft:white_concrete
fill 430 131 635 431 131 636 minecraft:white_concrete
setblock 430 131 637 minecraft:quartz_block
setblock 431 131 612 minecraft:quartz_block
fill 431 131 613 433 131 613 minecraft:white_concrete
fill 431 131 637 433 131 637 minecraft:white_concrete
setblock 431 131 638 minecraft:quartz_block
setblock 432 131 611 minecraft:quartz_block
fill 432 131 612 434 131 612 minecraft:white_concrete
setblock 432 131 614 minecraft:white_concrete
setblock 432 131 636 minecraft:white_concrete
fill 432 131 638 434 131 638 minecraft:white_concrete
setblock 432 131 639 minecraft:quartz_block
fill 433 131 610 434 131 610 minecraft:quartz_block
fill 433 131 611 436 131 611 minecraft:white_concrete
fill 433 131 639 436 131 639 minecraft:white_concrete
fill 433 131 640 434 131 640 minecraft:quartz_block
fill 434 131 609 435 131 609 minecraft:quartz_block
fill 434 131 641 435 131 641 minecraft:quartz_block
setblock 435 131 610 minecraft:white_concrete
setblock 435 131 640 minecraft:white_concrete
fill 436 131 608 437 131 608 minecraft:quartz_block
fill 436 131 609 437 131 609 minecraft:white_concrete
fill 436 131 641 452 131 641 minecraft:white_concrete
fill 436 131 642 438 131 642 minecraft:quartz_block
setblock 437 131 610 minecraft:white_concrete
fill 437 131 640 438 131 640 minecraft:white_concrete
setblock 438 131 607 minecraft:quartz_block
fill 438 131 608 438 134 608 minecraft:orange_concrete
fill 438 131 612 438 134 612 minecraft:orange_concrete
fill 438 131 643 443 131 643 minecraft:quartz_block
fill 438 131 646 438 185 646 minecraft:gray_concrete
fill 439 131 604 439 187 604 minecraft:gray_concrete
fill 439 131 607 442 134 607 minecraft:orange_concrete
fill 439 131 613 439 134 613 minecraft:orange_concrete
fill 439 131 642 443 131 642 minecraft:white_concrete
fill 440 131 646 440 187 646 minecraft:gray_concrete
fill 442 131 613 442 134 613 minecraft:orange_concrete
setblock 443 131 607 minecraft:quartz_block
fill 443 131 608 443 134 608 minecraft:orange_concrete
setblock 444 131 607 minecraft:white_concrete
fill 444 131 609 444 134 611 minecraft:orange_concrete
setblock 444 131 643 minecraft:white_concrete
fill 445 131 607 450 131 607 minecraft:quartz_block
fill 445 131 608 449 131 609 minecraft:white_concrete
fill 445 131 642 449 131 642 minecraft:white_concrete
fill 445 131 643 450 131 643 minecraft:quartz_block
fill 450 131 608 452 131 608 minecraft:quartz_block
fill 450 131 609 451 131 610 minecraft:white_concrete
fill 450 131 640 451 131 640 minecraft:white_concrete
fill 450 131 642 452 131 642 minecraft:quartz_block
setblock 452 131 609 minecraft:white_concrete
fill 452 131 611 455 131 611 minecraft:white_concrete
fill 452 131 639 455 131 639 minecraft:white_concrete
fill 452 131 646 452 187 646 minecraft:gray_concrete
fill 453 131 609 454 131 609 minecraft:quartz_block
setblock 453 131 610 minecraft:white_concrete
setblock 453 131 640 minecraft:white_concrete
fill 453 131 641 454 131 641 minecraft:quartz_block
fill 454 131 610 455 131 610 minecraft:quartz_block
fill 454 131 612 456 131 612 minecraft:white_concrete
fill 454 131 638 456 131 638 minecraft:white_concrete
fill 454 131 640 455 131 640 minecraft:quartz_block
fill 455 131 613 457 131 613 minecraft:white_concrete
fill 455 131 637 457 131 637 minecraft:white_concrete
fill 456 131 604 456 183 604 minecraft:gray_concrete
setblock 456 131 611 minecraft:quartz_block
fill 456 131 614 458 131 614 minecraft:white_concrete
fill 456 131 636 458 131 636 minecraft:white_concrete
setblock 456 131 639 minecraft:quartz_block
setblock 457 131 612 minecraft:quartz_block
fill 457 131 615 458 131 615 minecraft:white_concrete
fill 457 131 635 458 131 635 minecraft:white_concrete
setblock 457 131 638 minecraft:quartz_block
setblock 458 131 613 minecraft:quartz_block
fill 458 131 616 458 131 617 minecraft:white_concrete
fill 458 131 633 458 131 634 minecraft:white_concrete
setblock 458 131 637 minecraft:quartz_block
fill 459 131 615 460 131 615 minecraft:quartz_block
setblock 459 131 616 minecraft:white_concrete
fill 459 131 618 460 131 619 minecraft:white_concrete
fill 459 131 631 460 131 632 minecraft:white_concrete
setblock 459 131 634 minecraft:white_concrete
fill 459 131 635 460 131 635 minecraft:quartz_block
setblock 460 131 616 minecraft:quartz_block
setblock 460 131 617 minecraft:white_concrete
fill 460 131 620 460 131 630 minecraft:white_concrete
setblock 460 131 633 minecraft:white_concrete
setblock 460 131 634 minecraft:quartz_block
fill 461 131 617 461 131 619 minecraft:quartz_block
fill 461 131 620 461 131 624 minecraft:white_concrete
fill 461 131 626 461 131 630 minecraft:white_concrete
fill 461 131 631 461 131 633 minecraft:quartz_block
fill 462 131 620 462 131 624 minecraft:quartz_block
setblock 462 131 625 minecraft:white_concrete
fill 462 131 626 462 131 630 minecraft:quartz_block
fill 465 131 615 465 184 615 minecraft:gray_concrete
fill 465 131 623 465 185 623 minecraft:gray_concrete
fill 465 131 628 465 184 628 minecraft:gray_concrete
fill 465 131 639 465 185 640 minecraft:gray_concrete
fill 425 132 624 425 132 626 minecraft:pearlescent_froglight
fill 426 132 620 426 132 623 minecraft:pearlescent_froglight
fill 426 132 627 426 132 631 minecraft:pearlescent_froglight
fill 427 132 632 427 132 633 minecraft:pearlescent_froglight
fill 428 132 634 428 132 635 minecraft:pearlescent_froglight
setblock 429 132 636 minecraft:pearlescent_froglight
setblock 430 132 637 minecraft:pearlescent_froglight
setblock 431 132 638 minecraft:pearlescent_froglight
setblock 432 132 639 minecraft:pearlescent_froglight
setblock 433 132 640 minecraft:pearlescent_froglight
fill 434 132 641 435 132 641 minecraft:pearlescent_froglight
fill 436 132 642 437 132 642 minecraft:pearlescent_froglight
fill 437 132 609 437 133 611 minecraft:orange_concrete
fill 438 132 613 438 133 613 minecraft:orange_concrete
fill 438 132 643 442 132 643 minecraft:pearlescent_froglight
fill 440 132 614 441 133 614 minecraft:orange_concrete
fill 443 132 613 443 133 613 minecraft:orange_concrete
fill 443 132 644 445 132 644 minecraft:pearlescent_froglight
fill 444 132 612 444 133 612 minecraft:orange_concrete
fill 446 132 643 450 132 643 minecraft:pearlescent_froglight
fill 451 132 642 452 132 642 minecraft:pearlescent_froglight
fill 453 132 641 454 132 641 minecraft:pearlescent_froglight
setblock 455 132 640 minecraft:pearlescent_froglight
setblock 456 132 639 minecraft:pearlescent_froglight
setblock 457 132 638 minecraft:pearlescent_froglight
setblock 458 132 637 minecraft:pearlescent_froglight
setblock 459 132 636 minecraft:pearlescent_froglight
fill 423 136 609 423 143 609 minecraft:gray_concrete
fill 423 136 617 423 143 617 minecraft:gray_concrete
fill 423 136 625 423 143 625 minecraft:gray_concrete
fill 423 136 633 423 143 633 minecraft:gray_concrete
fill 423 136 641 423 143 641 minecraft:gray_concrete
fill 426 136 646 426 143 646 minecraft:gray_concrete
fill 427 136 625 427 138 625 minecraft:purple_concrete
fill 429 136 617 429 138 617 minecraft:purple_concrete
fill 429 136 633 429 138 633 minecraft:purple_concrete
fill 430 136 604 430 143 604 minecraft:gray_concrete
fill 434 136 646 434 143 646 minecraft:gray_concrete
fill 436 136 610 436 138 610 minecraft:purple_concrete
fill 436 136 640 436 138 640 minecraft:purple_concrete
fill 438 136 604 438 143 604 minecraft:gray_concrete
fill 442 136 646 442 143 646 minecraft:gray_concrete
fill 444 136 608 444 138 608 minecraft:purple_concrete
fill 444 136 642 444 138 642 minecraft:purple_concrete
fill 446 136 604 446 143 604 minecraft:gray_concrete
fill 450 136 646 450 143 646 minecraft:gray_concrete
fill 452 136 610 452 138 610 minecraft:purple_concrete
fill 452 136 640 452 138 640 minecraft:purple_concrete
fill 454 136 604 454 143 604 minecraft:gray_concrete
fill 458 136 646 458 143 646 minecraft:gray_concrete
fill 459 136 617 459 138 617 minecraft:purple_concrete
fill 459 136 633 459 138 633 minecraft:purple_concrete
fill 461 136 625 461 138 625 minecraft:purple_concrete
fill 462 136 604 462 143 604 minecraft:gray_concrete
fill 465 136 609 465 143 609 minecraft:gray_concrete
fill 465 136 617 465 143 617 minecraft:gray_concrete
fill 465 136 625 465 143 625 minecraft:gray_concrete
fill 465 136 633 465 143 633 minecraft:gray_concrete
fill 465 136 641 465 143 641 minecraft:gray_concrete
setblock 426 137 625 minecraft:purple_concrete
fill 427 137 620 428 137 624 minecraft:purple_concrete
fill 427 137 626 428 137 630 minecraft:purple_concrete
fill 428 137 617 428 137 619 minecraft:purple_concrete
setblock 428 137 625 minecraft:purple_concrete
fill 428 137 631 428 137 633 minecraft:purple_concrete
fill 429 137 616 430 137 616 minecraft:purple_concrete
fill 429 137 618 429 137 619 minecraft:purple_concrete
fill 429 137 631 429 137 632 minecraft:purple_concrete
fill 429 137 634 430 137 634 minecraft:purple_concrete
fill 430 137 614 431 137 615 minecraft:purple_concrete
setblock 430 137 617 minecraft:purple_concrete
setblock 430 137 633 minecraft:purple_concrete
fill 430 137 635 431 137 636 minecraft:purple_concrete
fill 431 137 613 433 137 613 minecraft:purple_concrete
fill 431 137 637 433 137 637 minecraft:purple_concrete
fill 432 137 612 434 137 612 minecraft:purple_concrete
setblock 432 137 614 minecraft:purple_concrete
setblock 432 137 636 minecraft:purple_concrete
fill 432 137 638 434 137 638 minecraft:purple_concrete
fill 433 137 611 436 137 611 minecraft:purple_concrete
fill 433 137 639 436 137 639 minecraft:purple_concrete
setblock 435 137 610 minecraft:purple_concrete
setblock 435 137 640 minecraft:purple_concrete
fill 436 137 609 452 137 609 minecraft:purple_concrete
fill 436 137 641 452 137 641 minecraft:purple_concrete
fill 437 137 610 438 137 610 minecraft:purple_concrete
fill 437 137 640 438 137 640 minecraft:purple_concrete
fill 439 137 608 443 137 608 minecraft:purple_concrete
fill 439 137 642 443 137 642 minecraft:purple_concrete
setblock 444 137 607 minecraft:purple_concrete
setblock 444 137 643 minecraft:purple_concrete
fill 445 137 608 449 137 608 minecraft:purple_concrete
fill 445 137 642 449 137 642 minecraft:purple_concrete
fill 448 137 633 449 138 633 minecraft:gold_block
fill 450 137 610 451 137 610 minecraft:purple_concrete
fill 450 137 640 451 137 640 minecraft:purple_concrete
fill 452 137 611 455 137 611 minecraft:purple_concrete
fill 452 137 639 455 137 639 minecraft:purple_concrete
setblock 453 137 610 minecraft:purple_concrete
setblock 453 137 640 minecraft:purple_concrete
fill 454 137 612 456 137 612 minecraft:purple_concrete
fill 454 137 638 456 137 638 minecraft:purple_concrete
fill 455 137 613 457 137 613 minecraft:purple_concrete
fill 455 137 637 457 137 637 minecraft:purple_concrete
fill 456 137 614 458 137 614 minecraft:purple_concrete
fill 456 137 636 458 137 636 minecraft:purple_concrete
fill 457 137 615 458 137 615 minecraft:purple_concrete
fill 457 137 635 458 137 635 minecraft:purple_concrete
fill 458 137 616 458 137 617 minecraft:purple_concrete
fill 458 137 633 458 137 634 minecraft:purple_concrete
setblock 459 137 616 minecraft:purple_concrete
fill 459 137 618 460 137 619 minecraft:purple_concrete
fill 459 137 631 460 137 632 minecraft:purple_concrete
setblock 459 137 634 minecraft:purple_concrete
setblock 460 137 617 minecraft:purple_concrete
fill 460 137 620 460 137 630 minecraft:purple_concrete
setblock 460 137 633 minecraft:purple_concrete
fill 461 137 620 461 137 624 minecraft:purple_concrete
fill 461 137 626 461 137 630 minecraft:purple_concrete
setblock 462 137 625 minecraft:purple_concrete
setblock 426 138 607 minecraft:light[level=13]
setblock 426 138 615 minecraft:light[level=13]
fill 426 138 619 426 139 631 minecraft:quartz_block
setblock 426 138 639 minecraft:light[level=13]
fill 427 138 617 427 139 624 minecraft:quartz_block
fill 427 138 626 427 139 633 minecraft:quartz_block
fill 428 138 615 428 139 619 minecraft:quartz_block
fill 428 138 631 428 139 635 minecraft:quartz_block
fill 429 138 614 429 139 616 minecraft:quartz_block
fill 429 138 634 429 139 636 minecraft:quartz_block
fill 430 138 613 430 139 615 minecraft:quartz_block
fill 430 138 635 430 139 637 minecraft:quartz_block
fill 431 138 612 431 139 614 minecraft:quartz_block
fill 431 138 636 431 139 638 minecraft:quartz_block
fill 432 138 611 433 139 612 minecraft:quartz_block
fill 432 138 638 433 139 639 minecraft:quartz_block
fill 433 138 610 435 139 610 minecraft:quartz_block
fill 433 138 640 435 139 640 minecraft:quartz_block
setblock 434 138 607 minecraft:light[level=13]
fill 434 138 609 438 139 609 minecraft:quartz_block
fill 434 138 611 434 139 611 minecraft:quartz_block
setblock 434 138 615 minecraft:light[level=13]
setblock 434 138 623 minecraft:light[level=13]
setblock 434 138 631 minecraft:light[level=13]
fill 434 138 639 434 139 639 minecraft:quartz_block
fill 434 138 641 438 139 641 minecraft:quartz_block
fill 436 138 608 443 139 608 minecraft:quartz_block
fill 436 138 642 443 139 642 minecraft:quartz_block
fill 438 138 607 450 139 607 minecraft:quartz_block
fill 438 138 643 450 139 643 minecraft:quartz_block
setblock 442 138 615 minecraft:light[level=13]
setblock 442 138 623 minecraft:light[level=13]
setblock 442 138 631 minecraft:light[level=13]
setblock 442 138 639 minecraft:light[level=13]
fill 445 138 608 452 139 608 minecraft:quartz_block
fill 445 138 642 452 139 642 minecraft:quartz_block
fill 450 138 609 454 139 609 minecraft:quartz_block
setblock 450 138 615 minecraft:light[level=13]
setblock 450 138 623 minecraft:light[level=13]
setblock 450 138 631 minecraft:light[level=13]
setblock 450 138 639 minecraft:light[level=13]
fill 450 138 641 454 139 641 minecraft:quartz_block
fill 453 138 610 455 139 610 minecraft:quartz_block
fill 453 138 640 455 139 640 minecraft:quartz_block
fill 454 138 611 456 139 611 minecraft:quartz_block
fill 454 138 639 456 139 639 minecraft:quartz_block
fill 455 138 612 457 139 612 minecraft:quartz_block
fill 455 138 638 457 139 638 minecraft:quartz_block
fill 457 138 613 458 139 614 minecraft:quartz_block
fill 457 138 636 458 139 637 minecraft:quartz_block
setblock 458 138 607 minecraft:light[level=13]
fill 458 138 615 460 139 615 minecraft:quartz_block
setblock 458 138 623 minecraft:light[level=13]
setblock 458 138 631 minecraft:light[level=13]
fill 458 138 635 460 139 635 minecraft:quartz_block
setblock 458 138 639 minecraft:light[level=13]
fill 459 138 614 459 139 614 minecraft:quartz_block
fill 459 138 616 460 139 616 minecraft:quartz_block
fill 459 138 634 460 139 634 minecraft:quartz_block
fill 459 138 636 459 139 636 minecraft:quartz_block
fill 460 138 617 461 139 619 minecraft:quartz_block
fill 460 138 631 461 139 633 minecraft:quartz_block
fill 461 138 620 462 139 624 minecraft:quartz_block
fill 461 138 626 462 139 630 minecraft:quartz_block
fill 462 138 619 462 139 619 minecraft:quartz_block
fill 462 138 625 462 139 625 minecraft:quartz_block
fill 462 138 631 462 139 631 minecraft:quartz_block
fill 424 140 605 424 141 610 minecraft:quartz_block
fill 424 140 613 425 140 618 minecraft:quartz_block
fill 424 140 621 425 140 626 minecraft:quartz_block
fill 424 140 629 425 140 634 minecraft:quartz_block
fill 424 140 637 425 140 642 minecraft:quartz_block
fill 424 140 645 429 141 645 minecraft:quartz_block
fill 425 140 606 425 140 612 minecraft:quartz_block
fill 425 140 619 425 140 620 minecraft:quartz_block
fill 425 140 627 425 140 628 minecraft:quartz_block
fill 425 140 635 425 140 636 minecraft:quartz_block
fill 425 140 643 425 140 644 minecraft:quartz_block
fill 426 140 606 463 140 606 minecraft:quartz_block
fill 426 140 619 426 140 623 minecraft:pearlescent_froglight
fill 426 140 627 426 140 631 minecraft:pearlescent_froglight
fill 426 140 644 464 140 644 minecraft:quartz_block
fill 427 140 605 432 141 605 minecraft:quartz_block
fill 427 140 617 427 140 618 minecraft:pearlescent_froglight
fill 427 140 632 427 140 633 minecraft:pearlescent_froglight
fill 428 140 615 428 140 616 minecraft:pearlescent_froglight
fill 428 140 634 428 140 635 minecraft:pearlescent_froglight
setblock 429 140 614 minecraft:pearlescent_froglight
setblock 429 140 636 minecraft:pearlescent_froglight
setblock 430 140 613 minecraft:pearlescent_froglight
setblock 430 140 637 minecraft:pearlescent_froglight
setblock 431 140 612 minecraft:pearlescent_froglight
setblock 431 140 638 minecraft:pearlescent_froglight
setblock 432 140 611 minecraft:pearlescent_froglight
setblock 432 140 639 minecraft:pearlescent_froglight
fill 432 140 645 437 141 645 minecraft:quartz_block
setblock 433 140 610 minecraft:pearlescent_froglight
setblock 433 140 640 minecraft:pearlescent_froglight
fill 434 140 609 435 140 609 minecraft:pearlescent_froglight
fill 434 140 641 435 140 641 minecraft:pearlescent_froglight
fill 435 140 605 440 141 605 minecraft:quartz_block
fill 436 140 642 437 140 642 minecraft:pearlescent_froglight
fill 438 140 643 442 140 643 minecraft:pearlescent_froglight
fill 440 140 645 445 141 645 minecraft:quartz_block
fill 443 140 605 448 141 605 minecraft:quartz_block
fill 446 140 643 450 140 643 minecraft:pearlescent_froglight
fill 448 140 645 453 141 645 minecraft:quartz_block
fill 451 140 605 456 141 605 minecraft:quartz_block
fill 451 140 642 452 140 642 minecraft:pearlescent_froglight
fill 453 140 641 454 140 641 minecraft:pearlescent_froglight
setblock 455 140 640 minecraft:pearlescent_froglight
setblock 456 140 639 minecraft:pearlescent_froglight
fill 456 140 645 461 141 645 minecraft:quartz_block
setblock 457 140 638 minecraft:pearlescent_froglight
setblock 458 140 637 minecraft:pearlescent_froglight
fill 459 140 605 464 141 605 minecraft:quartz_block
setblock 459 140 636 minecraft:pearlescent_froglight
fill 460 140 634 460 140 635 minecraft:pearlescent_froglight
fill 461 140 632 461 140 633 minecraft:pearlescent_froglight
fill 462 140 619 462 140 623 minecraft:pearlescent_froglight
fill 462 140 627 462 140 631 minecraft:pearlescent_froglight
fill 463 140 607 463 140 643 minecraft:quartz_block
fill 464 140 608 464 141 613 minecraft:quartz_block
fill 464 140 616 464 141 621 minecraft:quartz_block
fill 464 140 624 464 141 629 minecraft:quartz_block
fill 464 140 632 464 141 637 minecraft:quartz_block
fill 464 140 640 464 141 643 minecraft:quartz_block
fill 464 140 645 464 141 645 minecraft:quartz_block
fill 424 141 613 424 141 618 minecraft:quartz_block
fill 424 141 621 424 141 626 minecraft:quartz_block
fill 424 141 629 424 141 634 minecraft:quartz_block
fill 424 141 637 424 141 642 minecraft:quartz_block
setblock 464 141 644 minecraft:quartz_block
fill 437 142 615 437 143 616 minecraft:black_concrete
fill 423 144 609 423 149 609 minecraft:pearlescent_froglight
fill 423 144 617 423 149 617 minecraft:pearlescent_froglight
fill 423 144 625 423 149 625 minecraft:pearlescent_froglight
fill 423 144 633 423 149 633 minecraft:pearlescent_froglight
fill 423 144 641 423 149 641 minecraft:pearlescent_froglight
fill 426 144 646 426 149 646 minecraft:pearlescent_froglight
fill 430 144 604 430 149 604 minecraft:pearlescent_froglight
fill 434 144 646 434 149 646 minecraft:pearlescent_froglight
fill 438 144 604 438 149 604 minecraft:pearlescent_froglight
fill 442 144 646 442 149 646 minecraft:pearlescent_froglight
fill 446 144 604 446 149 604 minecraft:pearlescent_froglight
fill 450 144 646 450 149 646 minecraft:pearlescent_froglight
fill 454 144 604 454 149 604 minecraft:pearlescent_froglight
fill 458 144 646 458 149 646 minecraft:pearlescent_froglight
fill 462 144 604 462 149 604 minecraft:pearlescent_froglight
fill 465 144 609 465 149 609 minecraft:pearlescent_froglight
fill 465 144 617 465 149 617 minecraft:pearlescent_froglight
fill 465 144 625 465 149 625 minecraft:pearlescent_froglight
fill 465 144 633 465 149 633 minecraft:pearlescent_froglight
fill 465 144 641 465 149 641 minecraft:pearlescent_froglight
fill 434 145 639 435 146 639 minecraft:black_concrete
setblock 426 146 607 minecraft:light[level=13]
setblock 426 146 615 minecraft:light[level=13]
setblock 426 146 623 minecraft:light[level=13]
setblock 426 146 631 minecraft:light[level=13]
setblock 426 146 639 minecraft:light[level=13]
setblock 434 146 607 minecraft:light[level=13]
setblock 434 146 615 minecraft:light[level=13]
setblock 434 146 623 minecraft:light[level=13]
setblock 434 146 631 minecraft:light[level=13]
setblock 442 146 607 minecraft:light[level=13]
setblock 442 146 615 minecraft:light[level=13]
setblock 442 146 623 minecraft:light[level=13]
setblock 442 146 631 minecraft:light[level=13]
setblock 442 146 639 minecraft:light[level=13]
setblock 450 146 607 minecraft:light[level=13]
setblock 450 146 615 minecraft:light[level=13]
setblock 450 146 623 minecraft:light[level=13]
setblock 450 146 631 minecraft:light[level=13]
setblock 450 146 639 minecraft:light[level=13]
setblock 458 146 607 minecraft:light[level=13]
setblock 458 146 615 minecraft:light[level=13]
setblock 458 146 623 minecraft:light[level=13]
setblock 458 146 631 minecraft:light[level=13]
setblock 458 146 639 minecraft:light[level=13]
fill 449 149 632 449 150 633 minecraft:black_concrete
fill 456 149 634 457 150 634 minecraft:gold_block
fill 457 149 633 457 150 633 minecraft:gold_block
fill 457 149 635 457 150 635 minecraft:gold_block
fill 423 150 609 423 161 609 minecraft:gray_concrete
fill 423 150 617 423 161 617 minecraft:gray_concrete
fill 423 150 625 423 161 625 minecraft:gray_concrete
fill 423 150 633 423 161 633 minecraft:gray_concrete
fill 423 150 641 423 161 641 minecraft:gray_concrete
fill 426 150 646 426 161 646 minecraft:gray_concrete
fill 430 150 604 430 161 604 minecraft:gray_concrete
fill 434 150 646 434 161 646 minecraft:gray_concrete
fill 438 150 604 438 161 604 minecraft:gray_concrete
fill 442 150 646 442 161 646 minecraft:gray_concrete
fill 446 150 604 446 161 604 minecraft:gray_concrete
fill 450 150 646 450 161 646 minecraft:gray_concrete
fill 454 150 604 454 161 604 minecraft:gray_concrete
fill 458 150 646 458 161 646 minecraft:gray_concrete
fill 462 150 604 462 161 604 minecraft:gray_concrete
fill 465 150 609 465 161 609 minecraft:gray_concrete
fill 465 150 617 465 161 617 minecraft:gray_concrete
fill 465 150 625 465 161 625 minecraft:gray_concrete
fill 465 150 633 465 161 633 minecraft:gray_concrete
fill 465 150 641 465 161 641 minecraft:gray_concrete
setblock 426 154 607 minecraft:light[level=13]
setblock 426 154 615 minecraft:light[level=13]
setblock 426 154 623 minecraft:light[level=13]
setblock 426 154 631 minecraft:light[level=13]
setblock 426 154 639 minecraft:light[level=13]
setblock 434 154 607 minecraft:light[level=13]
setblock 434 154 615 minecraft:light[level=13]
setblock 434 154 623 minecraft:light[level=13]
setblock 434 154 631 minecraft:light[level=13]
setblock 434 154 639 minecraft:light[level=13]
setblock 442 154 607 minecraft:light[level=13]
setblock 442 154 615 minecraft:light[level=13]
setblock 442 154 623 minecraft:light[level=13]
setblock 442 154 631 minecraft:light[level=13]
setblock 442 154 639 minecraft:light[level=13]
setblock 450 154 607 minecraft:light[level=13]
setblock 450 154 615 minecraft:light[level=13]
setblock 450 154 623 minecraft:light[level=13]
setblock 450 154 631 minecraft:light[level=13]
setblock 450 154 639 minecraft:light[level=13]
setblock 458 154 607 minecraft:light[level=13]
setblock 458 154 615 minecraft:light[level=13]
setblock 458 154 623 minecraft:light[level=13]
setblock 458 154 631 minecraft:light[level=13]
setblock 458 154 639 minecraft:light[level=13]
fill 437 156 625 439 156 627 minecraft:redstone_block
fill 437 156 631 439 156 633 minecraft:redstone_block
fill 442 156 633 444 156 635 minecraft:redstone_block
fill 444 156 624 446 156 626 minecraft:redstone_block
fill 428 157 629 429 158 629 minecraft:gold_block
fill 429 157 624 429 158 628 minecraft:gold_block
fill 429 157 630 429 158 634 minecraft:gold_block
fill 430 157 622 430 158 624 minecraft:gold_block
fill 430 157 625 436 157 633 minecraft:black_concrete
fill 430 157 634 430 158 636 minecraft:gold_block
fill 431 157 621 431 158 622 minecraft:gold_block
fill 431 157 623 443 157 624 minecraft:black_concrete
fill 431 157 634 441 157 635 minecraft:black_concrete
fill 431 157 636 431 158 637 minecraft:gold_block
fill 432 157 620 432 158 621 minecraft:gold_block
fill 432 157 622 452 158 622 minecraft:black_concrete
fill 432 157 636 452 157 636 minecraft:black_concrete
fill 432 157 637 432 158 638 minecraft:gold_block
fill 433 157 619 433 158 620 minecraft:gold_block
fill 433 157 621 451 158 621 minecraft:black_concrete
fill 433 157 637 451 157 637 minecraft:black_concrete
fill 433 157 638 433 158 639 minecraft:gold_block
fill 434 157 618 434 158 619 minecraft:gold_block
fill 434 157 620 450 158 620 minecraft:black_concrete
fill 434 157 638 450 158 638 minecraft:black_concrete
fill 434 157 639 434 158 640 minecraft:gold_block
fill 435 157 617 435 158 618 minecraft:gold_block
fill 435 157 619 449 157 619 minecraft:black_concrete
fill 435 157 639 449 157 639 minecraft:black_concrete
fill 435 157 640 435 158 641 minecraft:gold_block
fill 436 157 617 437 158 617 minecraft:gold_block
fill 436 157 618 448 157 618 minecraft:black_concrete
fill 436 157 640 448 157 640 minecraft:black_concrete
fill 436 157 641 437 158 641 minecraft:gold_block
fill 437 157 616 447 158 616 minecraft:gold_block
fill 437 157 628 440 157 630 minecraft:black_concrete
fill 437 157 642 447 158 642 minecraft:gold_block
fill 438 157 617 446 157 617 minecraft:black_concrete
fill 438 157 641 446 157 641 minecraft:black_concrete
fill 440 157 625 443 157 627 minecraft:black_concrete
fill 440 157 631 441 157 633 minecraft:black_concrete
fill 442 157 615 442 158 615 minecraft:gold_block
fill 442 157 631 454 157 632 minecraft:black_concrete
fill 442 157 643 442 158 643 minecraft:gold_block
fill 444 157 623 453 157 623 minecraft:black_concrete
fill 444 157 627 454 157 630 minecraft:black_concrete
fill 445 157 633 453 157 635 minecraft:black_concrete
fill 447 157 617 449 158 617 minecraft:gold_block
fill 447 157 624 453 157 626 minecraft:black_concrete
fill 447 157 641 449 158 641 minecraft:gold_block
fill 449 157 618 450 158 618 minecraft:gold_block
fill 449 157 640 450 158 640 minecraft:gold_block
fill 450 157 619 451 158 619 minecraft:gold_block
fill 450 157 639 451 158 639 minecraft:gold_block
fill 451 157 620 452 158 620 minecraft:gold_block
fill 451 157 638 452 158 638 minecraft:gold_block
fill 452 157 621 453 158 621 minecraft:gold_block
fill 452 157 637 453 158 637 minecraft:gold_block
fill 453 157 622 454 158 622 minecraft:gold_block
fill 453 157 636 454 158 636 minecraft:gold_block
fill 454 157 623 454 158 624 minecraft:gold_block
fill 454 157 625 454 158 626 minecraft:black_concrete
fill 454 157 633 454 158 633 minecraft:black_concrete
fill 454 157 634 454 158 635 minecraft:gold_block
fill 455 157 624 455 158 634 minecraft:gold_block
fill 456 157 629 456 158 629 minecraft:gold_block
fill 424 158 605 427 158 645 minecraft:black_concrete
fill 428 158 605 428 158 628 minecraft:black_concrete
fill 428 158 630 428 158 645 minecraft:black_concrete
fill 429 158 605 429 158 623 minecraft:black_concrete
fill 429 158 635 429 158 645 minecraft:black_concrete
fill 430 158 605 430 158 621 minecraft:black_concrete
fill 430 158 625 435 158 628 minecraft:black_concrete
fill 430 158 629 431 158 629 minecraft:white_concrete
fill 430 158 630 435 158 633 minecraft:black_concrete
fill 430 158 637 430 158 645 minecraft:black_concrete
fill 431 158 605 431 158 620 minecraft:black_concrete
fill 431 158 623 432 158 623 minecraft:white_concrete
fill 431 158 624 435 158 624 minecraft:black_concrete
fill 431 158 634 435 158 634 minecraft:black_concrete
fill 431 158 635 432 158 635 minecraft:white_concrete
fill 431 158 638 431 158 645 minecraft:black_concrete
fill 432 158 605 432 158 619 minecraft:black_concrete
fill 432 158 629 438 158 629 minecraft:black_concrete
fill 432 158 636 434 158 636 minecraft:black_concrete
fill 432 158 639 432 158 645 minecraft:black_concrete
fill 433 158 605 433 158 618 minecraft:black_concrete
fill 433 158 623 442 158 623 minecraft:black_concrete
fill 433 158 635 435 158 635 minecraft:black_concrete
fill 433 158 637 434 158 637 minecraft:black_concrete
fill 433 158 640 433 158 645 minecraft:black_concrete
fill 434 158 605 434 158 617 minecraft:black_concrete
fill 434 158 641 434 158 645 minecraft:black_concrete
fill 435 158 605 436 158 616 minecraft:black_concrete
setblock 435 158 619 minecraft:black_concrete
fill 435 158 636 435 158 637 minecraft:gold_block
setblock 435 158 639 minecraft:black_concrete
fill 435 158 642 436 158 645 minecraft:black_concrete
fill 436 158 618 436 158 619 minecraft:white_concrete
fill 436 158 624 436 158 628 minecraft:pearlescent_froglight
fill 436 158 630 436 158 634 minecraft:pearlescent_froglight
fill 436 158 635 436 158 636 minecraft:gold_block
fill 436 158 637 451 158 637 minecraft:black_concrete
fill 436 158 639 436 158 640 minecraft:white_concrete
fill 437 158 605 441 158 615 minecraft:black_concrete
fill 437 158 618 441 158 619 minecraft:black_concrete
fill 437 158 624 440 158 624 minecraft:pearlescent_froglight
fill 437 158 625 439 158 627 minecraft:black_concrete
fill 437 158 628 438 158 628 minecraft:pearlescent_froglight
fill 437 158 630 438 158 630 minecraft:pearlescent_froglight
fill 437 158 631 439 158 633 minecraft:black_concrete
fill 437 158 634 441 158 634 minecraft:pearlescent_froglight
setblock 437 158 635 minecraft:gold_block
fill 437 158 636 440 158 636 minecraft:black_concrete
fill 437 158 639 441 158 640 minecraft:black_concrete
fill 437 158 643 441 158 645 minecraft:black_concrete
fill 438 158 617 441 158 617 minecraft:black_concrete
fill 438 158 635 440 158 635 minecraft:black_concrete
fill 438 158 641 441 158 641 minecraft:black_concrete
fill 439 158 628 439 158 630 minecraft:red_nether_bricks
fill 440 158 625 440 158 626 minecraft:pearlescent_froglight
setblock 440 158 627 minecraft:red_nether_bricks
fill 440 158 628 440 158 630 minecraft:shroomlight
setblock 440 158 631 minecraft:red_nether_bricks
fill 440 158 632 441 158 633 minecraft:pearlescent_froglight
fill 441 158 624 442 158 626 minecraft:black_concrete
fill 441 158 627 443 158 627 minecraft:shroomlight
fill 441 158 631 443 158 631 minecraft:shroomlight
fill 441 158 635 441 158 636 minecraft:pearlescent_froglight
fill 442 158 605 464 158 614 minecraft:black_concrete
fill 442 158 617 442 158 618 minecraft:white_concrete
fill 442 158 619 447 158 619 minecraft:black_concrete
fill 442 158 632 445 158 632 minecraft:pearlescent_froglight
fill 442 158 633 444 158 635 minecraft:black_concrete
fill 442 158 636 445 158 636 minecraft:pearlescent_froglight
fill 442 158 639 447 158 639 minecraft:black_concrete
fill 442 158 640 442 158 641 minecraft:white_concrete
fill 442 158 644 464 158 645 minecraft:black_concrete
fill 443 158 615 464 158 615 minecraft:black_concrete
fill 443 158 617 446 158 618 minecraft:black_concrete
fill 443 158 623 443 158 626 minecraft:pearlescent_froglight
fill 443 158 640 446 158 641 minecraft:black_concrete
fill 443 158 643 464 158 643 minecraft:black_concrete
fill 444 158 623 447 158 623 minecraft:pearlescent_froglight
fill 444 158 624 446 158 626 minecraft:black_concrete
setblock 444 158 627 minecraft:red_nether_bricks
fill 444 158 628 444 158 630 minecraft:shroomlight
setblock 444 158 631 minecraft:red_nether_bricks
fill 445 158 627 447 158 627 minecraft:pearlescent_froglight
fill 445 158 628 445 158 630 minecraft:red_nether_bricks
setblock 445 158 631 minecraft:gold_block
fill 445 158 633 445 158 635 minecraft:pearlescent_froglight
fill 446 158 628 452 158 631 minecraft:black_concrete
fill 446 158 632 446 158 633 minecraft:gold_block
fill 446 158 634 447 158 636 minecraft:black_concrete
setblock 447 158 618 minecraft:black_concrete
fill 447 158 624 447 158 626 minecraft:pearlescent_froglight
fill 447 158 632 454 158 632 minecraft:black_concrete
setblock 447 158 633 minecraft:gold_block
setblock 447 158 640 minecraft:black_concrete
fill 448 158 616 464 158 616 minecraft:black_concrete
fill 448 158 618 448 158 619 minecraft:white_concrete
fill 448 158 623 451 158 627 minecraft:black_concrete
fill 448 158 633 453 158 633 minecraft:black_concrete
setblock 448 158 634 minecraft:gold_block
fill 448 158 635 451 158 636 minecraft:black_concrete
fill 448 158 639 448 158 640 minecraft:white_concrete
fill 448 158 642 464 158 642 minecraft:black_concrete
setblock 449 158 619 minecraft:black_concrete
fill 449 158 634 453 158 634 minecraft:black_concrete
setblock 449 158 639 minecraft:black_concrete
fill 450 158 617 464 158 617 minecraft:black_concrete
fill 450 158 641 464 158 641 minecraft:black_concrete
fill 451 158 618 464 158 618 minecraft:black_concrete
fill 451 158 640 464 158 640 minecraft:black_concrete
fill 452 158 619 464 158 619 minecraft:black_concrete
fill 452 158 623 453 158 623 minecraft:white_concrete
fill 452 158 624 453 158 627 minecraft:black_concrete
fill 452 158 635 453 158 635 minecraft:white_concrete
setblock 452 158 636 minecraft:black_concrete
fill 452 158 639 464 158 639 minecraft:black_concrete
fill 453 158 620 464 158 620 minecraft:black_concrete
fill 453 158 628 454 158 628 minecraft:black_concrete
fill 453 158 629 454 158 629 minecraft:white_concrete
fill 453 158 630 454 158 631 minecraft:black_concrete
fill 453 158 638 464 158 638 minecraft:black_concrete
fill 454 158 621 464 158 621 minecraft:black_concrete
setblock 454 158 627 minecraft:black_concrete
fill 454 158 637 464 158 637 minecraft:black_concrete
fill 455 158 622 464 158 623 minecraft:black_concrete
fill 455 158 635 464 158 636 minecraft:black_concrete
fill 456 158 624 464 158 628 minecraft:black_concrete
fill 456 158 630 464 158 634 minecraft:black_concrete
fill 457 158 629 464 158 629 minecraft:black_concrete
fill 436 159 629 438 159 629 minecraft:red_nether_bricks
fill 437 159 627 439 159 628 minecraft:red_nether_bricks
fill 437 159 630 439 159 631 minecraft:red_nether_bricks
fill 438 159 626 441 159 626 minecraft:red_nether_bricks
fill 438 159 632 441 159 632 minecraft:red_nether_bricks
fill 439 159 625 445 159 625 minecraft:red_nether_bricks
fill 439 159 629 440 159 629 minecraft:quartz_block
fill 439 159 633 445 159 633 minecraft:red_nether_bricks
fill 440 159 627 440 160 628 minecraft:quartz_block
fill 440 159 630 440 160 631 minecraft:quartz_block
fill 441 159 627 444 159 627 minecraft:quartz_block
fill 441 159 631 444 159 631 minecraft:quartz_block
fill 442 159 626 442 160 626 minecraft:quartz_block
fill 442 159 632 442 160 632 minecraft:quartz_block
fill 443 159 626 446 159 626 minecraft:red_nether_bricks
fill 443 159 632 446 159 632 minecraft:red_nether_bricks
fill 444 159 628 444 159 630 minecraft:quartz_block
fill 445 159 627 447 159 628 minecraft:red_nether_bricks
fill 445 159 629 445 160 629 minecraft:quartz_block
fill 445 159 630 447 159 631 minecraft:red_nether_bricks
fill 446 159 629 448 159 629 minecraft:red_nether_bricks
fill 435 160 627 437 168 631 minecraft:red_nether_bricks
fill 436 160 626 439 166 626 minecraft:red_nether_bricks
fill 436 160 632 439 166 632 minecraft:red_nether_bricks
fill 437 160 625 441 165 625 minecraft:red_nether_bricks
fill 437 160 633 441 165 633 minecraft:red_nether_bricks
fill 438 160 624 446 167 624 minecraft:red_nether_bricks
fill 438 160 627 438 165 628 minecraft:red_nether_bricks
fill 438 160 629 439 160 629 minecraft:quartz_block
fill 438 160 630 438 165 631 minecraft:red_nether_bricks
fill 438 160 634 446 167 634 minecraft:red_nether_bricks
fill 439 160 627 439 160 628 minecraft:quartz_block
fill 439 160 630 439 160 631 minecraft:quartz_block
fill 440 160 626 441 160 626 minecraft:quartz_block
fill 440 160 632 441 160 632 minecraft:quartz_block
fill 441 160 623 443 169 623 minecraft:red_nether_bricks
setblock 441 160 627 minecraft:quartz_block
setblock 441 160 631 minecraft:quartz_block
fill 441 160 635 443 169 635 minecraft:red_nether_bricks
setblock 442 160 625 minecraft:quartz_block
setblock 442 160 633 minecraft:quartz_block
fill 443 160 625 447 165 625 minecraft:red_nether_bricks
fill 443 160 626 444 160 627 minecraft:quartz_block
fill 443 160 631 444 160 632 minecraft:quartz_block
fill 443 160 633 447 165 633 minecraft:red_nether_bricks
fill 444 160 628 445 160 628 minecraft:quartz_block
fill 444 160 630 445 160 630 minecraft:quartz_block
fill 445 160 626 448 160 626 minecraft:red_nether_bricks
setblock 445 160 627 minecraft:quartz_block
setblock 445 160 631 minecraft:quartz_block
fill 445 160 632 448 160 632 minecraft:red_nether_bricks
fill 446 160 627 446 160 628 minecraft:red_nether_bricks
setblock 446 160 629 minecraft:quartz_block
fill 446 160 630 446 160 631 minecraft:red_nether_bricks
setblock 447 160 627 minecraft:red_nether_bricks
fill 447 160 628 453 166 630 minecraft:nether_bricks
setblock 447 160 631 minecraft:red_nether_bricks
fill 448 160 627 452 166 627 minecraft:nether_bricks
fill 448 160 631 452 166 631 minecraft:nether_bricks
fill 434 161 627 434 168 631 minecraft:red_nether_bricks
fill 435 161 626 435 169 626 minecraft:red_nether_bricks
fill 435 161 632 435 169 632 minecraft:red_nether_bricks
fill 436 161 625 436 169 625 minecraft:red_nether_bricks
fill 436 161 633 436 169 633 minecraft:red_nether_bricks
fill 437 161 624 437 169 624 minecraft:red_nether_bricks
fill 437 161 634 437 169 634 minecraft:red_nether_bricks
fill 438 161 623 440 168 623 minecraft:red_nether_bricks
fill 438 161 629 439 162 629 minecraft:red_nether_bricks
fill 438 161 635 440 168 635 minecraft:red_nether_bricks
fill 439 161 627 439 162 628 minecraft:red_nether_bricks
fill 439 161 630 439 162 631 minecraft:red_nether_bricks
fill 440 161 626 440 161 627 minecraft:red_nether_bricks
fill 440 161 631 440 161 632 minecraft:red_nether_bricks
fill 441 161 626 446 161 626 minecraft:red_nether_bricks
fill 441 161 632 446 161 632 minecraft:red_nether_bricks
fill 442 161 625 442 165 625 minecraft:red_nether_bricks
fill 442 161 633 442 165 633 minecraft:red_nether_bricks
fill 444 161 623 446 168 623 minecraft:red_nether_bricks
fill 444 161 627 445 161 627 minecraft:red_nether_bricks
fill 444 161 631 445 161 631 minecraft:red_nether_bricks
fill 444 161 635 446 168 635 minecraft:red_nether_bricks
setblock 445 161 628 minecraft:red_nether_bricks
fill 445 161 629 446 162 629 minecraft:nether_bricks
setblock 445 161 630 minecraft:red_nether_bricks
fill 446 161 627 446 165 628 minecraft:nether_bricks
fill 446 161 630 446 165 631 minecraft:nether_bricks
fill 447 161 624 447 169 624 minecraft:red_nether_bricks
fill 447 161 626 447 165 627 minecraft:nether_bricks
fill 447 161 631 447 165 632 minecraft:nether_bricks
fill 447 161 634 447 169 634 minecraft:red_nether_bricks
setblock 448 161 625 minecraft:red_nether_bricks
fill 448 161 626 453 165 626 minecraft:nether_bricks
fill 448 161 632 453 165 632 minecraft:nether_bricks
setblock 448 161 633 minecraft:red_nether_bricks
fill 453 161 627 454 163 627 minecraft:nether_bricks
fill 453 161 631 454 163 631 minecraft:nether_bricks
fill 454 161 628 454 165 630 minecraft:nether_bricks
fill 455 161 629 455 165 629 minecraft:nether_bricks
fill 423 162 609 423 163 609 minecraft:pearlescent_froglight
fill 423 162 617 423 163 617 minecraft:pearlescent_froglight
fill 423 162 625 423 163 625 minecraft:pearlescent_froglight
fill 423 162 633 423 163 633 minecraft:pearlescent_froglight
fill 423 162 641 423 163 641 minecraft:pearlescent_froglight
fill 424 162 611 424 199 612 minecraft:quartz_block
fill 424 162 619 424 199 620 minecraft:quartz_block
fill 424 162 627 424 199 628 minecraft:quartz_block
fill 424 162 635 424 199 636 minecraft:quartz_block
fill 424 162 643 424 199 644 minecraft:quartz_block
fill 425 162 605 426 199 605 minecraft:quartz_block
fill 425 162 623 425 163 625 minecraft:black_concrete
setblock 426 162 607 minecraft:light[level=13]
setblock 426 162 615 minecraft:light[level=13]
fill 426 162 623 426 163 624 minecraft:black_concrete
setblock 426 162 631 minecraft:light[level=13]
setblock 426 162 639 minecraft:light[level=13]
fill 426 162 646 426 163 646 minecraft:pearlescent_froglight
fill 430 162 604 430 163 604 minecraft:pearlescent_froglight
fill 430 162 645 431 199 645 minecraft:quartz_block
fill 433 162 605 434 199 605 minecraft:quartz_block
fill 433 162 628 433 167 630 minecraft:red_nether_bricks
setblock 434 162 607 minecraft:light[level=13]
setblock 434 162 615 minecraft:light[level=13]
setblock 434 162 623 minecraft:light[level=13]
fill 434 162 626 434 168 626 minecraft:red_nether_bricks
fill 434 162 632 434 168 632 minecraft:red_nether_bricks
setblock 434 162 639 minecraft:light[level=13]
fill 434 162 646 434 163 646 minecraft:pearlescent_froglight
fill 435 162 625 435 168 625 minecraft:red_nether_bricks
fill 435 162 633 435 168 633 minecraft:red_nether_bricks
fill 436 162 624 436 168 624 minecraft:red_nether_bricks
fill 436 162 634 436 168 634 minecraft:red_nether_bricks
fill 437 162 623 437 167 623 minecraft:red_nether_bricks
fill 437 162 635 437 167 635 minecraft:red_nether_bricks
fill 438 162 604 438 163 604 minecraft:pearlescent_froglight
fill 438 162 645 439 199 645 minecraft:quartz_block
fill 439 162 622 445 166 622 minecraft:red_nether_bricks
fill 439 162 636 445 166 636 minecraft:red_nether_bricks
fill 440 162 626 445 162 626 minecraft:red_nether_bricks
fill 440 162 632 445 162 632 minecraft:red_nether_bricks
fill 441 162 605 442 199 605 minecraft:quartz_block
setblock 442 162 607 minecraft:light[level=13]
setblock 442 162 615 minecraft:light[level=13]
setblock 442 162 639 minecraft:light[level=13]
fill 442 162 646 442 163 646 minecraft:pearlescent_froglight
fill 445 162 627 445 162 628 minecraft:nether_bricks
fill 445 162 630 445 162 631 minecraft:nether_bricks
fill 446 162 604 446 163 604 minecraft:pearlescent_froglight
fill 446 162 626 446 164 626 minecraft:nether_bricks
fill 446 162 632 446 164 632 minecraft:nether_bricks
fill 446 162 645 447 199 645 minecraft:quartz_block
fill 447 162 623 447 167 623 minecraft:red_nether_bricks
fill 447 162 635 447 167 635 minecraft:red_nether_bricks
fill 448 162 624 448 168 624 minecraft:red_nether_bricks
fill 448 162 625 452 164 625 minecraft:nether_bricks
fill 448 162 633 452 164 633 minecraft:nether_bricks
fill 448 162 634 448 168 634 minecraft:red_nether_bricks
fill 449 162 605 450 199 605 minecraft:quartz_block
setblock 450 162 607 minecraft:light[level=13]
setblock 450 162 615 minecraft:light[level=13]
setblock 450 162 623 minecraft:light[level=13]
setblock 450 162 639 minecraft:light[level=13]
fill 450 162 646 450 163 646 minecraft:pearlescent_froglight
fill 454 162 604 454 163 604 minecraft:pearlescent_froglight
fill 454 162 626 454 164 626 minecraft:nether_bricks
fill 454 162 632 454 164 632 minecraft:nether_bricks
fill 454 162 645 455 199 645 minecraft:quartz_block
fill 455 162 627 455 164 628 minecraft:nether_bricks
fill 455 162 630 455 164 631 minecraft:nether_bricks
fill 457 162 605 458 199 605 minecraft:quartz_block
setblock 458 162 607 minecraft:light[level=13]
setblock 458 162 615 minecraft:light[level=13]
setblock 458 162 623 minecraft:light[level=13]
setblock 458 162 631 minecraft:light[level=13]
setblock 458 162 639 minecraft:light[level=13]
fill 458 162 646 458 163 646 minecraft:pearlescent_froglight
fill 462 162 604 462 163 604 minecraft:pearlescent_froglight
fill 462 162 645 463 199 645 minecraft:quartz_block
fill 464 162 606 464 199 607 minecraft:quartz_block
fill 464 162 614 464 199 615 minecraft:quartz_block
fill 464 162 622 464 199 623 minecraft:quartz_block
fill 464 162 630 464 199 631 minecraft:quartz_block
fill 464 162 638 464 199 639 minecraft:quartz_block
fill 465 162 609 465 163 609 minecraft:pearlescent_froglight
fill 465 162 617 465 163 617 minecraft:pearlescent_froglight
fill 465 162 625 465 163 625 minecraft:pearlescent_froglight
fill 465 162 633 465 163 633 minecraft:pearlescent_froglight
fill 465 162 641 465 163 641 minecraft:pearlescent_froglight
fill 433 163 627 433 167 627 minecraft:red_nether_bricks
fill 433 163 631 433 167 631 minecraft:red_nether_bricks
fill 434 163 625 434 167 625 minecraft:red_nether_bricks
fill 434 163 633 434 167 633 minecraft:red_nether_bricks
fill 435 163 624 435 167 624 minecraft:red_nether_bricks
fill 435 163 634 435 167 634 minecraft:red_nether_bricks
fill 436 163 623 436 166 623 minecraft:red_nether_bricks
fill 436 163 635 436 166 635 minecraft:red_nether_bricks
fill 438 163 622 438 166 622 minecraft:red_nether_bricks
fill 438 163 629 438 165 629 minecraft:red_nether_bricks
fill 438 163 636 438 166 636 minecraft:red_nether_bricks
fill 439 163 627 439 164 627 minecraft:red_nether_bricks
fill 439 163 631 439 164 631 minecraft:red_nether_bricks
fill 440 163 626 440 164 626 minecraft:red_nether_bricks
fill 440 163 632 440 164 632 minecraft:red_nether_bricks
fill 444 163 626 445 164 626 minecraft:red_nether_bricks
fill 444 163 632 445 164 632 minecraft:red_nether_bricks
fill 445 163 627 445 164 627 minecraft:nether_bricks
fill 445 163 631 445 164 631 minecraft:nether_bricks
fill 446 163 622 446 166 622 minecraft:red_nether_bricks
fill 446 163 629 446 165 629 minecraft:nether_bricks
fill 446 163 636 446 166 636 minecraft:red_nether_bricks
fill 448 163 623 448 166 623 minecraft:red_nether_bricks
fill 448 163 635 448 166 635 minecraft:red_nether_bricks
fill 449 163 624 449 167 624 minecraft:red_nether_bricks
fill 449 163 634 449 167 634 minecraft:red_nether_bricks
fill 454 163 613 456 168 616 minecraft:red_terracotta
fill 423 164 609 423 171 609 minecraft:gray_concrete
fill 423 164 617 423 171 617 minecraft:gray_concrete
fill 423 164 625 423 171 625 minecraft:gray_concrete
fill 423 164 633 423 171 633 minecraft:gray_concrete
fill 423 164 641 423 171 641 minecraft:gray_concrete
fill 426 164 646 426 171 646 minecraft:gray_concrete
fill 430 164 604 430 171 604 minecraft:gray_concrete
fill 433 164 626 433 166 626 minecraft:red_nether_bricks
fill 433 164 632 433 166 632 minecraft:red_nether_bricks
fill 434 164 646 434 171 646 minecraft:gray_concrete
fill 438 164 604 438 171 604 minecraft:gray_concrete
fill 442 164 646 442 171 646 minecraft:gray_concrete
fill 446 164 604 446 171 604 minecraft:gray_concrete
fill 450 164 646 450 171 646 minecraft:gray_concrete
fill 453 164 613 453 167 616 minecraft:red_terracotta
fill 453 164 627 453 166 627 minecraft:nether_bricks
fill 453 164 631 453 166 631 minecraft:nether_bricks
fill 454 164 604 454 171 604 minecraft:gray_concrete
fill 454 164 612 456 167 612 minecraft:red_terracotta
fill 454 164 627 454 165 627 minecraft:black_concrete
fill 454 164 631 454 165 631 minecraft:black_concrete
fill 455 164 617 456 167 617 minecraft:red_terracotta
fill 457 164 613 457 167 616 minecraft:red_terracotta
fill 458 164 646 458 171 646 minecraft:gray_concrete
fill 462 164 604 462 171 604 minecraft:gray_concrete
fill 465 164 609 465 171 609 minecraft:gray_concrete
fill 465 164 617 465 171 617 minecraft:gray_concrete
fill 465 164 625 465 171 625 minecraft:gray_concrete
fill 465 164 633 465 171 633 minecraft:gray_concrete
fill 465 164 641 465 171 641 minecraft:gray_concrete
fill 445 165 626 446 166 626 minecraft:red_nether_bricks
fill 445 165 632 446 166 632 minecraft:red_nether_bricks
fill 448 165 625 450 167 625 minecraft:red_nether_bricks
fill 448 165 633 450 167 633 minecraft:red_nether_bricks
fill 452 165 614 452 166 614 minecraft:red_terracotta
fill 454 165 617 454 166 617 minecraft:red_terracotta
setblock 455 165 628 minecraft:nether_bricks
setblock 455 165 630 minecraft:nether_bricks
fill 457 165 612 457 166 612 minecraft:red_terracotta
fill 458 165 614 458 166 615 minecraft:red_terracotta
fill 437 166 625 440 167 625 minecraft:red_nether_bricks
fill 437 166 633 440 167 633 minecraft:red_nether_bricks
fill 438 166 627 438 167 627 minecraft:red_nether_bricks
fill 438 166 631 438 167 631 minecraft:red_nether_bricks
fill 444 166 625 447 167 625 minecraft:red_nether_bricks
fill 444 166 633 447 167 633 minecraft:red_nether_bricks
fill 446 166 627 446 167 627 minecraft:red_nether_bricks
fill 446 166 631 446 167 631 minecraft:red_nether_bricks
fill 447 166 626 448 169 626 minecraft:red_nether_bricks
setblock 447 166 627 minecraft:nether_bricks
setblock 447 166 631 minecraft:nether_bricks
fill 447 166 632 448 169 632 minecraft:red_nether_bricks
fill 449 166 626 451 166 626 minecraft:nether_bricks
fill 449 166 632 451 166 632 minecraft:nether_bricks
setblock 454 166 629 minecraft:nether_bricks
fill 436 167 626 438 168 626 minecraft:red_nether_bricks
fill 436 167 632 438 168 632 minecraft:red_nether_bricks
setblock 439 167 622 minecraft:red_nether_bricks
setblock 439 167 636 minecraft:red_nether_bricks
setblock 440 167 622 minecraft:black_concrete
setblock 440 167 636 minecraft:black_concrete
fill 441 167 622 445 167 622 minecraft:red_nether_bricks
fill 441 167 636 445 167 636 minecraft:red_nether_bricks
fill 446 167 626 446 168 626 minecraft:red_nether_bricks
fill 446 167 632 446 168 632 minecraft:red_nether_bricks
fill 447 167 627 448 168 631 minecraft:red_nether_bricks
fill 449 167 626 450 168 628 minecraft:red_nether_bricks
fill 449 167 629 451 167 629 minecraft:nether_bricks
fill 449 167 630 450 168 632 minecraft:red_nether_bricks
fill 451 167 627 451 167 628 minecraft:red_nether_bricks
fill 451 167 630 451 167 631 minecraft:red_nether_bricks
fill 424 168 605 424 169 610 minecraft:quartz_block
fill 424 168 613 425 168 618 minecraft:quartz_block
fill 424 168 621 425 168 626 minecraft:quartz_block
fill 424 168 629 425 168 634 minecraft:quartz_block
fill 424 168 637 425 168 642 minecraft:quartz_block
fill 424 168 645 429 169 645 minecraft:quartz_block
fill 425 168 606 425 168 612 minecraft:quartz_block
fill 425 168 619 425 168 620 minecraft:quartz_block
fill 425 168 627 425 168 628 minecraft:quartz_block
fill 425 168 635 425 168 636 minecraft:quartz_block
fill 425 168 643 425 168 644 minecraft:quartz_block
fill 426 168 606 463 168 606 minecraft:quartz_block
fill 426 168 644 464 168 644 minecraft:quartz_block
fill 427 168 605 432 169 605 minecraft:quartz_block
fill 432 168 645 437 169 645 minecraft:quartz_block
fill 435 168 605 440 169 605 minecraft:quartz_block
fill 437 168 621 440 168 621 minecraft:black_concrete
fill 437 168 625 439 168 625 minecraft:red_nether_bricks
fill 437 168 633 439 168 633 minecraft:red_nether_bricks
fill 437 168 637 440 168 637 minecraft:black_concrete
fill 438 168 624 444 168 624 minecraft:red_nether_bricks
fill 438 168 634 444 168 634 minecraft:red_nether_bricks
fill 440 168 645 445 169 645 minecraft:quartz_block
fill 441 168 622 443 168 622 minecraft:red_nether_bricks
fill 441 168 636 443 168 636 minecraft:red_nether_bricks
fill 443 168 605 448 169 605 minecraft:quartz_block
fill 445 168 624 445 168 625 minecraft:shroomlight
fill 445 168 633 445 168 634 minecraft:shroomlight
fill 446 168 624 446 168 625 minecraft:red_nether_bricks
fill 446 168 633 446 168 634 minecraft:red_nether_bricks
fill 447 168 625 449 168 625 minecraft:red_nether_bricks
fill 447 168 633 449 168 633 minecraft:red_nether_bricks
fill 448 168 645 453 169 645 minecraft:quartz_block
fill 449 168 629 450 169 629 minecraft:red_nether_bricks
fill 451 168 605 456 169 605 minecraft:quartz_block
fill 456 168 645 461 169 645 minecraft:quartz_block
fill 459 168 605 464 169 605 minecraft:quartz_block
fill 463 168 607 463 168 643 minecraft:quartz_block
fill 464 168 608 464 169 613 minecraft:quartz_block
fill 464 168 616 464 169 621 minecraft:quartz_block
fill 464 168 624 464 169 629 minecraft:quartz_block
fill 464 168 632 464 169 637 minecraft:quartz_block
fill 464 168 640 464 169 643 minecraft:quartz_block
fill 464 168 645 464 169 645 minecraft:quartz_block
fill 424 169 613 424 169 618 minecraft:quartz_block
fill 424 169 621 424 169 626 minecraft:quartz_block
fill 424 169 629 424 169 634 minecraft:quartz_block
fill 424 169 637 424 169 642 minecraft:quartz_block
fill 434 169 619 436 169 619 minecraft:black_concrete
fill 434 169 629 436 169 629 minecraft:red_nether_bricks
fill 434 169 639 436 169 639 minecraft:black_concrete
fill 435 169 620 439 169 620 minecraft:black_concrete
fill 435 169 627 437 169 628 minecraft:red_nether_bricks
fill 435 169 630 437 169 631 minecraft:red_nether_bricks
fill 435 169 638 439 169 638 minecraft:black_concrete
fill 436 169 626 437 169 626 minecraft:red_nether_bricks
fill 436 169 632 437 169 632 minecraft:red_nether_bricks
fill 437 169 625 438 169 625 minecraft:red_nether_bricks
fill 437 169 633 438 169 633 minecraft:red_nether_bricks
fill 438 169 624 441 169 624 minecraft:red_nether_bricks
fill 438 169 634 441 169 634 minecraft:red_nether_bricks
setblock 440 169 621 minecraft:black_concrete
setblock 440 169 623 minecraft:red_nether_bricks
setblock 440 169 635 minecraft:red_nether_bricks
setblock 440 169 637 minecraft:black_concrete
setblock 443 169 624 minecraft:red_nether_bricks
setblock 443 169 634 minecraft:red_nether_bricks
setblock 444 169 623 minecraft:red_nether_bricks
fill 444 169 624 446 169 624 minecraft:shroomlight
fill 444 169 634 446 169 634 minecraft:shroomlight
setblock 444 169 635 minecraft:red_nether_bricks
setblock 446 169 625 minecraft:shroomlight
setblock 446 169 633 minecraft:shroomlight
fill 447 169 625 448 169 625 minecraft:red_nether_bricks
fill 447 169 627 449 169 628 minecraft:red_nether_bricks
fill 447 169 630 449 169 631 minecraft:red_nether_bricks
fill 447 169 633 448 169 633 minecraft:red_nether_bricks
fill 448 169 629 448 170 629 minecraft:red_nether_bricks
setblock 449 169 626 minecraft:red_nether_bricks
setblock 449 169 632 minecraft:red_nether_bricks
setblock 464 169 644 minecraft:quartz_block
setblock 426 170 607 minecraft:light[level=13]
setblock 426 170 615 minecraft:light[level=13]
setblock 426 170 623 minecraft:light[level=13]
setblock 426 170 631 minecraft:light[level=13]
setblock 426 170 639 minecraft:light[level=13]
setblock 432 170 618 minecraft:black_concrete
setblock 432 170 640 minecraft:black_concrete
setblock 434 170 607 minecraft:light[level=13]
setblock 434 170 615 minecraft:light[level=13]
setblock 434 170 623 minecraft:light[level=13]
setblock 434 170 631 minecraft:light[level=13]
setblock 434 170 639 minecraft:light[level=13]
setblock 435 170 618 minecraft:black_concrete
setblock 435 170 640 minecraft:black_concrete
fill 436 170 619 437 170 619 minecraft:black_concrete
fill 436 170 627 436 170 631 minecraft:red_nether_bricks
fill 436 170 639 437 170 639 minecraft:black_concrete
fill 437 170 626 437 170 627 minecraft:red_nether_bricks
fill 437 170 631 437 170 632 minecraft:red_nether_bricks
fill 438 170 625 438 171 625 minecraft:blackstone
fill 438 170 633 438 171 633 minecraft:blackstone
setblock 439 170 619 minecraft:black_concrete
fill 439 170 624 439 171 624 minecraft:blackstone
fill 439 170 634 439 171 634 minecraft:blackstone
setblock 439 170 639 minecraft:black_concrete
setblock 440 170 620 minecraft:black_concrete
setblock 440 170 624 minecraft:red_nether_bricks
setblock 440 170 634 minecraft:red_nether_bricks
fill 440 170 635 440 171 636 minecraft:white_concrete
setblock 440 170 638 minecraft:black_concrete
setblock 442 170 607 minecraft:light[level=13]
setblock 442 170 615 minecraft:light[level=13]
setblock 442 170 623 minecraft:light[level=13]
setblock 442 170 639 minecraft:light[level=13]
fill 444 170 606 445 171 607 minecraft:black_concrete
setblock 444 170 624 minecraft:red_nether_bricks
setblock 444 170 634 minecraft:red_nether_bricks
setblock 446 170 625 minecraft:red_nether_bricks
setblock 446 170 633 minecraft:red_nether_bricks
fill 447 170 626 447 170 627 minecraft:red_nether_bricks
fill 447 170 631 447 170 632 minecraft:red_nether_bricks
fill 448 170 627 448 170 628 minecraft:red_nether_bricks
fill 448 170 630 448 170 631 minecraft:red_nether_bricks
setblock 450 170 607 minecraft:light[level=13]
setblock 450 170 615 minecraft:light[level=13]
setblock 450 170 623 minecraft:light[level=13]
setblock 450 170 631 minecraft:light[level=13]
setblock 450 170 639 minecraft:light[level=13]
setblock 458 170 607 minecraft:light[level=13]
setblock 458 170 615 minecraft:light[level=13]
setblock 458 170 623 minecraft:light[level=13]
setblock 458 170 631 minecraft:light[level=13]
setblock 458 170 639 minecraft:light[level=13]
fill 428 171 616 429 171 616 minecraft:black_concrete
fill 428 171 642 429 171 642 minecraft:black_concrete
fill 429 171 617 430 171 617 minecraft:black_concrete
fill 429 171 641 430 171 641 minecraft:black_concrete
fill 433 171 617 434 171 617 minecraft:black_concrete
fill 433 171 641 434 171 641 minecraft:black_concrete
setblock 436 171 618 minecraft:black_concrete
setblock 436 171 640 minecraft:black_concrete
fill 438 171 618 438 172 618 minecraft:black_concrete
fill 438 171 624 438 173 624 minecraft:blackstone
fill 438 171 634 438 173 634 minecraft:blackstone
fill 438 171 640 438 172 640 minecraft:black_concrete
fill 440 171 619 440 172 619 minecraft:black_concrete
fill 440 171 639 440 172 639 minecraft:black_concrete
fill 423 172 609 423 177 609 minecraft:pearlescent_froglight
fill 423 172 617 423 177 617 minecraft:pearlescent_froglight
fill 423 172 625 423 177 625 minecraft:pearlescent_froglight
fill 423 172 633 423 177 633 minecraft:pearlescent_froglight
fill 423 172 641 423 177 641 minecraft:pearlescent_froglight
fill 426 172 646 426 177 646 minecraft:pearlescent_froglight
setblock 428 172 616 minecraft:black_concrete
setblock 428 172 642 minecraft:black_concrete
fill 430 172 604 430 177 604 minecraft:pearlescent_froglight
fill 431 172 615 431 173 615 minecraft:black_concrete
fill 431 172 643 431 173 643 minecraft:black_concrete
setblock 432 172 616 minecraft:black_concrete
setblock 432 172 642 minecraft:black_concrete
fill 434 172 646 434 177 646 minecraft:pearlescent_froglight
fill 435 172 617 435 173 617 minecraft:black_concrete
fill 435 172 641 435 173 641 minecraft:black_concrete
fill 437 172 623 437 174 624 minecraft:blackstone
fill 437 172 634 437 174 635 minecraft:blackstone
fill 438 172 604 438 177 604 minecraft:pearlescent_froglight
fill 438 172 617 438 173 617 minecraft:black_concrete
fill 438 172 623 438 173 623 minecraft:blackstone
fill 438 172 635 438 173 635 minecraft:blackstone
fill 438 172 641 438 173 641 minecraft:black_concrete
fill 440 172 618 440 173 618 minecraft:black_concrete
fill 440 172 640 440 173 640 minecraft:black_concrete
fill 442 172 646 442 177 646 minecraft:pearlescent_froglight
fill 446 172 604 446 177 604 minecraft:pearlescent_froglight
fill 450 172 646 450 177 646 minecraft:pearlescent_froglight
fill 454 172 604 454 177 604 minecraft:pearlescent_froglight
fill 458 172 646 458 177 646 minecraft:pearlescent_froglight
fill 462 172 604 462 177 604 minecraft:pearlescent_froglight
fill 465 172 609 465 177 609 minecraft:pearlescent_froglight
fill 465 172 617 465 177 617 minecraft:pearlescent_froglight
fill 465 172 625 465 177 625 minecraft:pearlescent_froglight
fill 465 172 633 465 177 633 minecraft:pearlescent_froglight
fill 465 172 641 465 177 641 minecraft:pearlescent_froglight
fill 434 173 616 434 174 616 minecraft:black_concrete
fill 434 173 642 434 174 642 minecraft:black_concrete
fill 436 173 623 436 175 623 minecraft:blackstone
fill 436 173 624 436 174 625 minecraft:white_concrete
fill 436 173 635 436 175 635 minecraft:blackstone
fill 440 173 616 440 176 616 minecraft:black_concrete
fill 436 174 622 437 174 622 minecraft:blackstone
fill 436 174 636 437 174 636 minecraft:blackstone
fill 437 174 615 437 174 616 minecraft:black_concrete
fill 437 174 642 437 174 643 minecraft:black_concrete
setblock 440 174 617 minecraft:black_concrete
setblock 440 174 641 minecraft:black_concrete
fill 435 175 622 435 176 623 minecraft:blackstone
fill 435 175 635 435 176 636 minecraft:blackstone
fill 436 175 622 436 176 622 minecraft:blackstone
fill 436 175 636 436 176 636 minecraft:blackstone
setblock 437 175 615 minecraft:black_concrete
setblock 437 175 623 minecraft:blackstone
setblock 437 175 635 minecraft:blackstone
setblock 437 175 643 minecraft:black_concrete
fill 440 175 642 440 176 642 minecraft:black_concrete
fill 434 176 621 434 177 622 minecraft:blackstone
fill 434 176 636 434 177 637 minecraft:blackstone
fill 435 176 621 435 177 621 minecraft:blackstone
fill 435 176 637 435 177 637 minecraft:blackstone
fill 458 176 620 458 177 620 minecraft:gold_block
setblock 435 177 622 minecraft:blackstone
setblock 435 177 636 minecraft:blackstone
fill 423 178 609 423 185 609 minecraft:gray_concrete
fill 423 178 617 423 185 617 minecraft:gray_concrete
fill 423 178 625 423 185 625 minecraft:gray_concrete
fill 423 178 633 423 185 633 minecraft:gray_concrete
fill 423 178 641 423 185 641 minecraft:gray_concrete
setblock 426 178 607 minecraft:light[level=13]
setblock 426 178 615 minecraft:light[level=13]
setblock 426 178 623 minecraft:light[level=13]
setblock 426 178 631 minecraft:light[level=13]
setblock 426 178 639 minecraft:light[level=13]
fill 426 178 646 426 185 646 minecraft:gray_concrete
fill 430 178 604 430 183 604 minecraft:gray_concrete
setblock 434 178 607 minecraft:light[level=13]
setblock 434 178 615 minecraft:light[level=13]
setblock 434 178 621 minecraft:blackstone
setblock 434 178 623 minecraft:light[level=13]
setblock 434 178 631 minecraft:light[level=13]
setblock 434 178 637 minecraft:blackstone
setblock 434 178 639 minecraft:light[level=13]
fill 434 178 646 434 185 646 minecraft:gray_concrete
fill 438 178 604 438 185 604 minecraft:gray_concrete
setblock 442 178 607 minecraft:light[level=13]
setblock 442 178 615 minecraft:light[level=13]
setblock 442 178 623 minecraft:light[level=13]
setblock 442 178 631 minecraft:light[level=13]
setblock 442 178 639 minecraft:light[level=13]
fill 442 178 646 442 183 646 minecraft:gray_concrete
fill 446 178 604 446 185 604 minecraft:gray_concrete
setblock 450 178 607 minecraft:light[level=13]
setblock 450 178 615 minecraft:light[level=13]
setblock 450 178 623 minecraft:light[level=13]
setblock 450 178 631 minecraft:light[level=13]
setblock 450 178 639 minecraft:light[level=13]
fill 450 178 646 450 183 646 minecraft:gray_concrete
fill 454 178 604 454 185 604 minecraft:gray_concrete
setblock 458 178 607 minecraft:light[level=13]
setblock 458 178 615 minecraft:light[level=13]
setblock 458 178 623 minecraft:light[level=13]
setblock 458 178 631 minecraft:light[level=13]
setblock 458 178 639 minecraft:light[level=13]
fill 458 178 646 458 185 646 minecraft:gray_concrete
fill 462 178 604 462 185 604 minecraft:gray_concrete
fill 465 178 609 465 185 609 minecraft:gray_concrete
fill 465 178 617 465 185 617 minecraft:gray_concrete
fill 465 178 625 465 185 625 minecraft:gray_concrete
fill 465 178 633 465 185 633 minecraft:gray_concrete
fill 465 178 641 465 185 641 minecraft:gray_concrete
fill 457 179 622 457 180 623 minecraft:black_concrete
fill 430 181 623 430 182 623 minecraft:gold_block
fill 424 182 605 424 183 610 minecraft:quartz_block
fill 424 182 613 425 182 618 minecraft:quartz_block
fill 424 182 621 425 182 626 minecraft:quartz_block
fill 424 182 629 425 182 634 minecraft:quartz_block
fill 424 182 637 425 182 642 minecraft:quartz_block
fill 424 182 645 429 183 645 minecraft:quartz_block
fill 425 182 606 425 182 612 minecraft:quartz_block
fill 425 182 619 425 182 620 minecraft:quartz_block
fill 425 182 627 425 182 628 minecraft:quartz_block
fill 425 182 635 425 182 636 minecraft:quartz_block
fill 425 182 643 425 182 644 minecraft:quartz_block
fill 426 182 606 463 182 606 minecraft:quartz_block
fill 426 182 644 464 182 644 minecraft:quartz_block
fill 427 182 605 432 183 605 minecraft:quartz_block
fill 432 182 645 437 183 645 minecraft:quartz_block
fill 435 182 605 440 183 605 minecraft:quartz_block
fill 440 182 645 445 183 645 minecraft:quartz_block
fill 443 182 605 448 183 605 minecraft:quartz_block
fill 448 182 645 453 183 645 minecraft:quartz_block
fill 451 182 605 456 183 605 minecraft:quartz_block
fill 456 182 645 461 183 645 minecraft:quartz_block
fill 459 182 605 464 183 605 minecraft:quartz_block
fill 463 182 607 463 182 643 minecraft:quartz_block
fill 464 182 608 464 183 613 minecraft:quartz_block
fill 464 182 616 464 183 621 minecraft:quartz_block
fill 464 182 624 464 183 629 minecraft:quartz_block
fill 464 182 632 464 183 637 minecraft:quartz_block
fill 464 182 640 464 183 643 minecraft:quartz_block
fill 464 182 645 464 183 645 minecraft:quartz_block
fill 424 183 613 424 183 618 minecraft:quartz_block
fill 424 183 621 424 183 626 minecraft:quartz_block
fill 424 183 629 424 183 634 minecraft:quartz_block
fill 424 183 637 424 183 642 minecraft:quartz_block
setblock 464 183 644 minecraft:quartz_block
setblock 423 184 604 minecraft:light_gray_concrete
fill 423 184 605 423 184 608 minecraft:gray_concrete
setblock 423 184 613 minecraft:light_gray_concrete
setblock 423 184 624 minecraft:light_gray_concrete
setblock 423 184 638 minecraft:light_gray_concrete
fill 424 184 604 424 187 604 minecraft:gray_concrete
setblock 425 184 604 minecraft:light_gray_concrete
setblock 426 184 604 minecraft:gray_concrete
setblock 427 184 646 minecraft:light_gray_concrete
fill 428 184 646 429 187 646 minecraft:gray_concrete
setblock 430 184 604 minecraft:light_gray_concrete
setblock 430 184 646 minecraft:light_gray_concrete
fill 431 184 646 431 187 646 minecraft:gray_concrete
setblock 432 184 646 minecraft:light_gray_concrete
setblock 440 184 604 minecraft:light_gray_concrete
fill 441 184 604 445 184 604 minecraft:gray_concrete
setblock 442 184 646 minecraft:light_gray_concrete
setblock 450 184 646 minecraft:light_gray_concrete
setblock 453 184 646 minecraft:light_gray_concrete
fill 454 184 646 456 184 646 minecraft:gray_concrete
fill 456 184 604 457 184 604 minecraft:light_gray_concrete
fill 457 184 646 457 185 646 minecraft:light_gray_concrete
fill 458 184 604 461 184 604 minecraft:gray_concrete
fill 465 184 618 465 187 619 minecraft:gray_concrete
fill 465 184 620 465 184 621 minecraft:light_gray_concrete
setblock 465 184 630 minecraft:light_gray_concrete
fill 465 184 642 465 184 644 minecraft:gray_concrete
setblock 465 184 645 minecraft:light_gray_concrete
fill 423 185 604 423 187 606 minecraft:gray_concrete
setblock 423 185 607 minecraft:light_gray_concrete
fill 423 185 608 423 187 608 minecraft:gray_concrete
fill 423 185 613 423 187 613 minecraft:gray_concrete
fill 423 185 622 423 186 622 minecraft:light_gray_concrete
fill 423 185 624 423 188 624 minecraft:gray_concrete
fill 423 185 638 423 187 638 minecraft:gray_concrete
fill 425 185 604 425 187 604 minecraft:gray_concrete
setblock 426 185 604 minecraft:light_gray_concrete
fill 427 185 646 427 187 646 minecraft:gray_concrete
setblock 430 185 604 minecraft:gray_concrete
fill 430 185 646 430 187 646 minecraft:gray_concrete
setblock 432 185 646 minecraft:gray_concrete
fill 433 185 604 434 185 604 minecraft:light_gray_concrete
fill 435 185 604 435 187 604 minecraft:gray_concrete
fill 440 185 604 441 187 604 minecraft:gray_concrete
setblock 442 185 604 minecraft:light_gray_concrete
setblock 442 185 646 minecraft:gray_concrete
fill 443 185 604 444 187 604 minecraft:gray_concrete
setblock 445 185 604 minecraft:light_gray_concrete
setblock 447 185 604 minecraft:light_gray_concrete
fill 448 185 604 453 187 604 minecraft:gray_concrete
setblock 450 185 646 minecraft:gray_concrete
fill 453 185 646 454 187 646 minecraft:gray_concrete
fill 455 185 646 455 186 646 minecraft:light_gray_concrete
fill 456 185 604 457 187 604 minecraft:gray_concrete
fill 456 185 646 456 187 646 minecraft:gray_concrete
setblock 458 185 604 minecraft:light_gray_concrete
fill 459 185 604 461 185 604 minecraft:gray_concrete
fill 459 185 646 460 187 646 minecraft:gray_concrete
setblock 461 185 646 minecraft:light_gray_concrete
fill 462 185 646 463 187 646 minecraft:gray_concrete
fill 463 185 604 464 187 604 minecraft:gray_concrete
setblock 464 185 646 minecraft:light_gray_concrete
setblock 465 185 604 minecraft:light_gray_concrete
setblock 465 185 615 minecraft:light_gray_concrete
fill 465 185 620 465 187 621 minecraft:gray_concrete
setblock 465 185 628 minecraft:light_gray_concrete
fill 465 185 630 465 187 630 minecraft:gray_concrete
setblock 465 185 631 minecraft:light_gray_concrete
fill 465 185 632 465 187 632 minecraft:gray_concrete
fill 465 185 642 465 187 642 minecraft:gray_concrete
setblock 465 185 643 minecraft:light_gray_concrete
fill 465 185 644 465 187 646 minecraft:gray_concrete
fill 423 186 607 423 187 607 minecraft:gray_concrete
fill 423 186 609 423 191 609 minecraft:pearlescent_froglight
fill 423 186 617 423 191 617 minecraft:pearlescent_froglight
fill 423 186 625 423 191 625 minecraft:pearlescent_froglight
fill 423 186 626 423 187 628 minecraft:gray_concrete
setblock 423 186 629 minecraft:light_gray_concrete
fill 423 186 630 423 187 630 minecraft:gray_concrete
setblock 423 186 631 minecraft:light_gray_concrete
fill 423 186 632 423 187 632 minecraft:gray_concrete
fill 423 186 633 423 191 633 minecraft:pearlescent_froglight
fill 423 186 639 423 187 639 minecraft:gray_concrete
setblock 423 186 640 minecraft:light_gray_concrete
fill 423 186 641 423 191 641 minecraft:pearlescent_froglight
setblock 423 186 644 minecraft:light_gray_concrete
fill 423 186 645 423 187 645 minecraft:gray_concrete
setblock 423 186 646 minecraft:light_gray_concrete
fill 426 186 604 426 187 604 minecraft:gray_concrete
setblock 426 186 607 minecraft:light[level=13]
setblock 426 186 615 minecraft:light[level=13]
setblock 426 186 623 minecraft:light[level=13]
setblock 426 186 631 minecraft:light[level=13]
setblock 426 186 639 minecraft:light[level=13]
fill 426 186 646 426 191 646 minecraft:pearlescent_froglight
fill 430 186 604 430 191 604 minecraft:pearlescent_froglight
setblock 432 186 646 minecraft:light_gray_concrete
fill 433 186 604 434 187 604 minecraft:gray_concrete
setblock 434 186 607 minecraft:light[level=13]
setblock 434 186 615 minecraft:light[level=13]
setblock 434 186 623 minecraft:light[level=13]
setblock 434 186 631 minecraft:light[level=13]
setblock 434 186 639 minecraft:light[level=13]
fill 434 186 646 434 191 646 minecraft:pearlescent_froglight
fill 436 186 612 436 187 612 minecraft:black_concrete
fill 438 186 604 438 191 604 minecraft:pearlescent_froglight
setblock 438 186 646 minecraft:light_gray_concrete
fill 442 186 604 442 187 604 minecraft:gray_concrete
setblock 442 186 607 minecraft:light[level=13]
setblock 442 186 615 minecraft:light[level=13]
setblock 442 186 623 minecraft:light[level=13]
setblock 442 186 631 minecraft:light[level=13]
setblock 442 186 639 minecraft:light[level=13]
fill 442 186 646 442 191 646 minecraft:pearlescent_froglight
fill 445 186 604 445 187 604 minecraft:gray_concrete
fill 446 186 604 446 191 604 minecraft:pearlescent_froglight
fill 447 186 604 447 187 604 minecraft:gray_concrete
setblock 450 186 607 minecraft:light[level=13]
setblock 450 186 615 minecraft:light[level=13]
setblock 450 186 623 minecraft:light[level=13]
setblock 450 186 631 minecraft:light[level=13]
setblock 450 186 639 minecraft:light[level=13]
fill 450 186 646 450 191 646 minecraft:pearlescent_froglight
fill 454 186 604 454 191 604 minecraft:pearlescent_froglight
fill 457 186 646 457 188 646 minecraft:gray_concrete
fill 458 186 604 459 187 604 minecraft:gray_concrete
setblock 458 186 607 minecraft:light[level=13]
setblock 458 186 615 minecraft:light[level=13]
setblock 458 186 623 minecraft:light[level=13]
setblock 458 186 631 minecraft:light[level=13]
setblock 458 186 639 minecraft:light[level=13]
fill 458 186 646 458 191 646 minecraft:pearlescent_froglight
setblock 460 186 604 minecraft:light_gray_concrete
fill 461 186 604 461 187 604 minecraft:gray_concrete
fill 461 186 646 461 187 646 minecraft:gray_concrete
fill 462 186 604 462 191 604 minecraft:pearlescent_froglight
fill 464 186 646 464 187 646 minecraft:gray_concrete
fill 465 186 604 465 189 604 minecraft:gray_concrete
fill 465 186 609 465 191 609 minecraft:pearlescent_froglight
fill 465 186 615 465 187 615 minecraft:gray_concrete
fill 465 186 617 465 191 617 minecraft:pearlescent_froglight
setblock 465 186 623 minecraft:light_gray_concrete
fill 465 186 625 465 191 625 minecraft:pearlescent_froglight
fill 465 186 626 465 187 626 minecraft:gray_concrete
setblock 465 186 627 minecraft:light_gray_concrete
fill 465 186 628 465 188 628 minecraft:gray_concrete
fill 465 186 631 465 188 631 minecraft:gray_concrete
fill 465 186 633 465 191 633 minecraft:pearlescent_froglight
setblock 465 186 639 minecraft:light_gray_concrete
fill 465 186 640 465 187 640 minecraft:gray_concrete
fill 465 186 641 465 191 641 minecraft:pearlescent_froglight
fill 465 186 643 465 188 643 minecraft:gray_concrete
setblock 423 187 622 minecraft:gray_concrete
setblock 423 187 629 minecraft:gray_concrete
setblock 423 187 631 minecraft:gray_concrete
setblock 423 187 640 minecraft:gray_concrete
setblock 423 187 644 minecraft:gray_concrete
setblock 423 187 646 minecraft:gray_concrete
setblock 432 187 646 minecraft:gray_concrete
setblock 438 187 646 minecraft:gray_concrete
setblock 455 187 646 minecraft:gray_concrete
setblock 460 187 604 minecraft:gray_concrete
setblock 465 187 623 minecraft:gray_concrete
setblock 465 187 627 minecraft:gray_concrete
setblock 465 187 639 minecraft:gray_concrete
fill 423 188 604 423 243 608 minecraft:light_gray_concrete
fill 423 188 610 423 189 616 minecraft:light_gray_concrete
fill 423 188 618 423 247 618 minecraft:light_gray_concrete
setblock 423 188 619 minecraft:gray_concrete
fill 423 188 620 423 247 623 minecraft:light_gray_concrete
fill 423 188 626 423 188 632 minecraft:light_gray_concrete
fill 423 188 634 423 247 635 minecraft:light_gray_concrete
fill 423 188 636 423 189 636 minecraft:gray_concrete
fill 423 188 637 423 244 640 minecraft:light_gray_concrete
fill 423 188 642 423 188 646 minecraft:light_gray_concrete
fill 424 188 604 426 243 604 minecraft:light_gray_concrete
fill 424 188 646 425 189 646 minecraft:light_gray_concrete
setblock 427 188 604 minecraft:gray_concrete
fill 427 188 646 427 247 646 minecraft:light_gray_concrete
fill 428 188 604 429 188 604 minecraft:light_gray_concrete
fill 428 188 646 428 189 646 minecraft:gray_concrete
fill 429 188 646 432 188 646 minecraft:light_gray_concrete
fill 431 188 604 437 189 604 minecraft:light_gray_concrete
fill 435 188 646 438 188 646 minecraft:light_gray_concrete
fill 439 188 604 440 245 604 minecraft:light_gray_concrete
fill 440 188 646 441 247 646 minecraft:light_gray_concrete
setblock 441 188 604 minecraft:gray_concrete
fill 442 188 604 445 189 604 minecraft:light_gray_concrete
setblock 443 188 646 minecraft:light_gray_concrete
setblock 444 188 646 minecraft:gray_concrete
fill 445 188 646 446 189 646 minecraft:light_gray_concrete
fill 447 188 604 453 188 604 minecraft:light_gray_concrete
setblock 447 188 646 minecraft:gray_concrete
fill 448 188 646 449 189 646 minecraft:light_gray_concrete
fill 451 188 646 452 188 646 minecraft:light_gray_concrete
setblock 453 188 646 minecraft:gray_concrete
fill 454 188 646 456 247 646 minecraft:light_gray_concrete
fill 455 188 604 461 188 604 minecraft:light_gray_concrete
fill 459 188 646 465 189 646 minecraft:light_gray_concrete
fill 463 188 604 464 247 604 minecraft:light_gray_concrete
fill 465 188 605 465 188 608 minecraft:light_gray_concrete
fill 465 188 610 465 243 610 minecraft:light_gray_concrete
fill 465 188 611 465 188 612 minecraft:gray_concrete
fill 465 188 613 465 247 615 minecraft:light_gray_concrete
fill 465 188 618 465 243 620 minecraft:light_gray_concrete
setblock 465 188 621 minecraft:gray_concrete
fill 465 188 622 465 188 623 minecraft:light_gray_concrete
fill 465 188 626 465 247 627 minecraft:light_gray_concrete
fill 465 188 629 465 188 630 minecraft:light_gray_concrete
setblock 465 188 632 minecraft:light_gray_concrete
fill 465 188 634 465 189 640 minecraft:light_gray_concrete
fill 465 188 642 465 247 642 minecraft:light_gray_concrete
fill 465 188 644 465 244 645 minecraft:light_gray_concrete
fill 423 189 619 423 243 619 minecraft:light_gray_concrete
fill 423 189 624 423 247 624 minecraft:light_gray_concrete
fill 423 189 626 423 244 626 minecraft:light_gray_concrete
fill 423 189 627 423 189 628 minecraft:gray_concrete
fill 423 189 629 423 189 632 minecraft:light_gray_concrete
setblock 423 189 642 minecraft:gray_concrete
fill 423 189 643 423 189 646 minecraft:light_gray_concrete
setblock 427 189 604 minecraft:light_gray_concrete
setblock 428 189 604 minecraft:gray_concrete
fill 429 189 604 429 247 604 minecraft:light_gray_concrete
fill 429 189 646 430 189 646 minecraft:light_gray_concrete
setblock 431 189 646 minecraft:gray_concrete
fill 432 189 646 433 247 646 minecraft:light_gray_concrete
fill 435 189 646 436 245 646 minecraft:light_gray_concrete
fill 437 189 646 438 189 646 minecraft:gray_concrete
setblock 439 189 646 minecraft:light_gray_concrete
fill 441 189 604 441 245 604 minecraft:light_gray_concrete
setblock 443 189 646 minecraft:gray_concrete
setblock 444 189 646 minecraft:light_gray_concrete
fill 447 189 604 451 189 604 minecraft:light_gray_concrete
fill 447 189 646 447 243 646 minecraft:light_gray_concrete
fill 451 189 646 451 247 646 minecraft:light_gray_concrete
setblock 452 189 604 minecraft:gray_concrete
fill 452 189 646 452 190 646 minecraft:gray_concrete
fill 453 189 604 453 244 604 minecraft:light_gray_concrete
fill 453 189 646 453 247 646 minecraft:light_gray_concrete
fill 455 189 604 457 189 604 minecraft:light_gray_concrete
fill 457 189 646 457 245 646 minecraft:light_gray_concrete
fill 458 189 604 460 189 604 minecraft:gray_concrete
setblock 461 189 604 minecraft:light_gray_concrete
fill 465 189 605 465 243 607 minecraft:light_gray_concrete
setblock 465 189 608 minecraft:gray_concrete
fill 465 189 611 465 247 612 minecraft:light_gray_concrete
fill 465 189 616 465 245 616 minecraft:light_gray_concrete
fill 465 189 621 465 244 621 minecraft:light_gray_concrete
setblock 465 189 622 minecraft:gray_concrete
fill 465 189 623 465 245 624 minecraft:light_gray_concrete
fill 465 189 628 465 245 629 minecraft:light_gray_concrete
setblock 465 189 630 minecraft:gray_concrete
fill 465 189 631 465 247 631 minecraft:light_gray_concrete
setblock 465 189 632 minecraft:gray_concrete
fill 465 189 643 465 247 643 minecraft:light_gray_concrete
fill 423 190 610 423 243 612 minecraft:light_gray_concrete
setblock 423 190 613 minecraft:gray_concrete
fill 423 190 614 423 247 615 minecraft:light_gray_concrete
setblock 423 190 616 minecraft:gray_concrete
fill 423 190 627 423 243 630 minecraft:light_gray_concrete
fill 423 190 631 423 190 632 minecraft:gray_concrete
fill 423 190 636 423 247 636 minecraft:light_gray_concrete
fill 423 190 642 423 243 645 minecraft:light_gray_concrete
fill 423 190 646 424 190 646 minecraft:gray_concrete
fill 425 190 646 425 247 646 minecraft:light_gray_concrete
setblock 427 190 604 minecraft:gray_concrete
fill 428 190 604 428 247 604 minecraft:light_gray_concrete
fill 428 190 646 429 247 646 minecraft:light_gray_concrete
setblock 430 190 646 minecraft:gray_concrete
fill 431 190 604 434 243 604 minecraft:light_gray_concrete
fill 431 190 646 431 249 646 minecraft:light_gray_concrete
setblock 435 190 604 minecraft:gray_concrete
fill 436 190 604 437 247 604 minecraft:light_gray_concrete
fill 437 190 646 438 243 646 minecraft:light_gray_concrete
setblock 439 190 646 minecraft:gray_concrete
fill 442 190 604 444 247 604 minecraft:light_gray_concrete
fill 443 190 646 443 245 646 minecraft:light_gray_concrete
fill 444 190 646 445 190 646 minecraft:gray_concrete
setblock 445 190 604 minecraft:gray_concrete
fill 446 190 646 446 245 646 minecraft:light_gray_concrete
fill 447 190 604 450 245 604 minecraft:light_gray_concrete
fill 448 190 646 448 243 646 minecraft:light_gray_concrete
setblock 449 190 646 minecraft:gray_concrete
setblock 451 190 604 minecraft:gray_concrete
fill 452 190 604 452 247 604 minecraft:light_gray_concrete
setblock 455 190 604 minecraft:gray_concrete
fill 456 190 604 458 243 604 minecraft:light_gray_concrete
setblock 459 190 604 minecraft:gray_concrete
fill 459 190 646 463 243 646 minecraft:light_gray_concrete
fill 460 190 604 460 247 604 minecraft:light_gray_concrete
setblock 461 190 604 minecraft:gray_concrete
setblock 464 190 646 minecraft:gray_concrete
fill 465 190 604 465 247 604 minecraft:light_gray_concrete
fill 465 190 608 465 245 608 minecraft:light_gray_concrete
fill 465 190 622 465 247 622 minecraft:light_gray_concrete
fill 465 190 630 465 247 630 minecraft:light_gray_concrete
fill 465 190 632 465 247 632 minecraft:light_gray_concrete
fill 465 190 634 465 245 637 minecraft:light_gray_concrete
setblock 465 190 638 minecraft:gray_concrete
fill 465 190 639 465 247 640 minecraft:light_gray_concrete
fill 465 190 646 465 247 646 minecraft:light_gray_concrete
fill 423 191 613 423 247 613 minecraft:light_gray_concrete
fill 423 191 616 423 244 616 minecraft:light_gray_concrete
fill 423 191 631 423 247 632 minecraft:light_gray_concrete
fill 423 191 646 424 247 646 minecraft:light_gray_concrete
fill 427 191 604 427 243 604 minecraft:light_gray_concrete
fill 430 191 646 430 247 646 minecraft:light_gray_concrete
fill 435 191 604 435 245 604 minecraft:light_gray_concrete
fill 439 191 646 439 247 646 minecraft:light_gray_concrete
fill 444 191 646 445 245 646 minecraft:light_gray_concrete
fill 445 191 604 445 247 604 minecraft:light_gray_concrete
fill 449 191 646 449 247 646 minecraft:light_gray_concrete
fill 451 191 604 451 245 604 minecraft:light_gray_concrete
fill 452 191 646 452 244 646 minecraft:light_gray_concrete
fill 455 191 604 455 244 604 minecraft:light_gray_concrete
fill 459 191 604 459 247 604 minecraft:light_gray_concrete
fill 461 191 604 461 248 604 minecraft:light_gray_concrete
fill 464 191 646 464 245 646 minecraft:light_gray_concrete
fill 465 191 638 465 245 638 minecraft:light_gray_concrete
fill 423 192 609 423 213 609 minecraft:light_gray_concrete
fill 423 192 617 423 213 617 minecraft:light_gray_concrete
fill 423 192 625 423 213 625 minecraft:light_gray_concrete
fill 423 192 633 423 213 633 minecraft:light_gray_concrete
fill 423 192 641 423 213 641 minecraft:light_gray_concrete
fill 426 192 646 426 213 646 minecraft:light_gray_concrete
fill 430 192 604 430 213 604 minecraft:light_gray_concrete
fill 434 192 646 434 213 646 minecraft:light_gray_concrete
fill 438 192 604 438 213 604 minecraft:light_gray_concrete
fill 442 192 646 442 213 646 minecraft:light_gray_concrete
fill 446 192 604 446 213 604 minecraft:light_gray_concrete
fill 450 192 646 450 213 646 minecraft:light_gray_concrete
fill 454 192 604 454 213 604 minecraft:light_gray_concrete
fill 458 192 646 458 213 646 minecraft:light_gray_concrete
fill 462 192 604 462 213 604 minecraft:light_gray_concrete
fill 465 192 609 465 213 609 minecraft:light_gray_concrete
fill 465 192 617 465 213 617 minecraft:light_gray_concrete
fill 465 192 625 465 213 625 minecraft:light_gray_concrete
fill 465 192 633 465 213 633 minecraft:light_gray_concrete
fill 465 192 641 465 213 641 minecraft:light_gray_concrete
setblock 426 194 607 minecraft:light[level=13]
setblock 426 194 615 minecraft:light[level=13]
setblock 426 194 623 minecraft:light[level=13]
setblock 426 194 631 minecraft:light[level=13]
setblock 426 194 639 minecraft:light[level=13]
setblock 434 194 607 minecraft:light[level=13]
setblock 434 194 615 minecraft:light[level=13]
setblock 434 194 623 minecraft:light[level=13]
setblock 434 194 631 minecraft:light[level=13]
setblock 434 194 639 minecraft:light[level=13]
setblock 442 194 607 minecraft:light[level=13]
setblock 442 194 615 minecraft:light[level=13]
setblock 442 194 623 minecraft:light[level=13]
setblock 442 194 631 minecraft:light[level=13]
setblock 442 194 639 minecraft:light[level=13]
setblock 450 194 607 minecraft:light[level=13]
setblock 450 194 615 minecraft:light[level=13]
setblock 450 194 623 minecraft:light[level=13]
setblock 450 194 631 minecraft:light[level=13]
setblock 450 194 639 minecraft:light[level=13]
setblock 458 194 607 minecraft:light[level=13]
setblock 458 194 615 minecraft:light[level=13]
setblock 458 194 623 minecraft:light[level=13]
setblock 458 194 631 minecraft:light[level=13]
setblock 458 194 639 minecraft:light[level=13]
fill 424 196 605 424 197 610 minecraft:quartz_block
fill 424 196 613 425 196 618 minecraft:quartz_block
fill 424 196 621 425 196 626 minecraft:quartz_block
fill 424 196 629 425 196 634 minecraft:quartz_block
fill 424 196 637 425 196 642 minecraft:quartz_block
fill 424 196 645 429 197 645 minecraft:quartz_block
fill 425 196 606 425 196 612 minecraft:quartz_block
fill 425 196 619 425 196 620 minecraft:quartz_block
fill 425 196 627 425 196 628 minecraft:quartz_block
fill 425 196 635 425 196 636 minecraft:quartz_block
fill 425 196 643 425 196 644 minecraft:quartz_block
fill 426 196 606 463 196 606 minecraft:quartz_block
fill 426 196 644 464 196 644 minecraft:quartz_block
fill 427 196 605 432 197 605 minecraft:quartz_block
fill 432 196 645 437 197 645 minecraft:quartz_block
fill 435 196 605 440 197 605 minecraft:quartz_block
fill 440 196 645 445 197 645 minecraft:quartz_block
fill 443 196 605 448 197 605 minecraft:quartz_block
fill 448 196 634 448 197 634 minecraft:gold_block
fill 448 196 645 453 197 645 minecraft:quartz_block
fill 451 196 605 456 197 605 minecraft:quartz_block
fill 456 196 645 461 197 645 minecraft:quartz_block
fill 459 196 605 464 197 605 minecraft:quartz_block
fill 463 196 607 463 196 643 minecraft:quartz_block
fill 464 196 608 464 197 613 minecraft:quartz_block
fill 464 196 616 464 197 621 minecraft:quartz_block
fill 464 196 624 464 197 629 minecraft:quartz_block
fill 464 196 632 464 197 637 minecraft:quartz_block
fill 464 196 640 464 197 643 minecraft:quartz_block
fill 464 196 645 464 197 645 minecraft:quartz_block
fill 424 197 613 424 197 618 minecraft:quartz_block
fill 424 197 621 424 197 626 minecraft:quartz_block
fill 424 197 629 424 197 634 minecraft:quartz_block
fill 424 197 637 424 197 642 minecraft:quartz_block
setblock 464 197 644 minecraft:quartz_block
setblock 426 202 607 minecraft:light[level=13]
setblock 426 202 615 minecraft:light[level=13]
setblock 426 202 623 minecraft:light[level=13]
setblock 426 202 631 minecraft:light[level=13]
setblock 426 202 639 minecraft:light[level=13]
setblock 434 202 607 minecraft:light[level=13]
setblock 434 202 615 minecraft:light[level=13]
setblock 434 202 623 minecraft:light[level=13]
setblock 434 202 631 minecraft:light[level=13]
setblock 434 202 639 minecraft:light[level=13]
setblock 442 202 607 minecraft:light[level=13]
setblock 442 202 615 minecraft:light[level=13]
setblock 442 202 623 minecraft:light[level=13]
setblock 442 202 631 minecraft:light[level=13]
setblock 442 202 639 minecraft:light[level=13]
setblock 450 202 607 minecraft:light[level=13]
setblock 450 202 615 minecraft:light[level=13]
setblock 450 202 623 minecraft:light[level=13]
setblock 450 202 631 minecraft:light[level=13]
setblock 450 202 639 minecraft:light[level=13]
setblock 458 202 607 minecraft:light[level=13]
setblock 458 202 615 minecraft:light[level=13]
setblock 458 202 623 minecraft:light[level=13]
setblock 458 202 631 minecraft:light[level=13]
setblock 458 202 639 minecraft:light[level=13]
fill 439 204 631 441 204 633 minecraft:redstone_block
fill 442 204 623 444 204 625 minecraft:redstone_block
fill 447 204 625 449 204 627 minecraft:redstone_block
fill 447 204 631 449 204 633 minecraft:redstone_block
fill 428 205 629 429 206 629 minecraft:gold_block
fill 429 205 626 430 206 628 minecraft:gold_block
fill 429 205 630 430 206 632 minecraft:gold_block
fill 430 205 624 431 206 625 minecraft:gold_block
fill 430 205 629 438 206 629 minecraft:white_concrete
fill 430 205 633 431 206 634 minecraft:gold_block
fill 431 205 623 433 206 623 minecraft:gold_block
fill 431 205 626 438 206 628 minecraft:white_concrete
fill 431 205 630 438 205 632 minecraft:white_concrete
fill 431 205 635 433 206 635 minecraft:gold_block
fill 432 205 622 435 206 622 minecraft:gold_block
fill 432 205 624 432 206 624 minecraft:gold_block
fill 432 205 625 439 206 625 minecraft:white_concrete
fill 432 205 633 438 205 633 minecraft:white_concrete
fill 432 205 634 432 206 634 minecraft:gold_block
fill 432 205 636 435 206 636 minecraft:gold_block
fill 433 205 624 440 206 624 minecraft:white_concrete
fill 433 205 634 440 205 634 minecraft:white_concrete
fill 434 205 621 438 206 621 minecraft:gold_block
fill 434 205 623 441 205 623 minecraft:white_concrete
fill 434 205 635 454 206 635 minecraft:white_concrete
fill 434 205 637 438 206 637 minecraft:gold_block
fill 436 205 620 452 206 620 minecraft:gold_block
fill 436 205 622 452 205 622 minecraft:white_concrete
fill 436 205 636 452 206 636 minecraft:white_concrete
fill 436 205 638 452 206 638 minecraft:gold_block
fill 439 205 619 449 206 619 minecraft:gold_block
fill 439 205 621 449 206 621 minecraft:white_concrete
fill 439 205 626 439 206 626 minecraft:gray_concrete
fill 439 205 627 439 206 627 minecraft:black_concrete
fill 439 205 628 439 206 628 minecraft:gray_concrete
fill 439 205 629 442 205 629 minecraft:black_concrete
setblock 439 205 630 minecraft:gray_concrete
fill 439 205 637 449 206 637 minecraft:white_concrete
fill 439 205 639 449 206 639 minecraft:gold_block
fill 440 205 625 440 206 626 minecraft:black_concrete
fill 440 205 627 440 206 627 minecraft:gray_concrete
fill 440 205 628 442 205 628 minecraft:black_concrete
fill 440 205 630 442 205 630 minecraft:black_concrete
setblock 441 205 624 minecraft:black_concrete
setblock 441 205 625 minecraft:gray_concrete
fill 441 205 626 442 205 627 minecraft:black_concrete
setblock 441 205 634 minecraft:black_concrete
fill 442 205 631 442 205 633 minecraft:black_concrete
setblock 442 205 634 minecraft:gray_concrete
fill 443 205 626 445 205 626 minecraft:gray_concrete
fill 443 205 627 446 205 627 minecraft:black_concrete
fill 443 205 631 446 205 631 minecraft:black_concrete
fill 443 205 632 445 206 632 minecraft:gray_concrete
fill 443 205 633 443 206 634 minecraft:black_concrete
fill 444 205 633 444 206 634 minecraft:gray_concrete
fill 445 205 623 454 205 623 minecraft:white_concrete
fill 445 205 624 445 205 625 minecraft:black_concrete
fill 445 205 633 445 206 634 minecraft:black_concrete
setblock 446 205 624 minecraft:gray_concrete
fill 446 205 625 446 205 626 minecraft:black_concrete
fill 446 205 628 448 205 630 minecraft:black_concrete
fill 446 205 632 446 205 633 minecraft:black_concrete
setblock 446 205 634 minecraft:gray_concrete
setblock 447 205 624 minecraft:black_concrete
setblock 447 205 634 minecraft:black_concrete
fill 448 205 624 455 205 624 minecraft:white_concrete
fill 448 205 634 455 205 634 minecraft:white_concrete
setblock 449 205 628 minecraft:gray_concrete
fill 449 205 629 449 206 629 minecraft:black_concrete
setblock 449 205 630 minecraft:gray_concrete
fill 450 205 621 454 206 621 minecraft:gold_block
fill 450 205 625 456 205 633 minecraft:white_concrete
fill 450 205 637 454 206 637 minecraft:gold_block
fill 453 205 622 456 206 622 minecraft:gold_block
fill 453 205 636 456 206 636 minecraft:gold_block
fill 455 205 623 457 206 623 minecraft:gold_block
fill 455 205 635 457 206 635 minecraft:gold_block
fill 456 205 624 458 206 624 minecraft:gold_block
fill 456 205 634 458 206 634 minecraft:gold_block
fill 457 205 625 458 206 625 minecraft:gold_block
fill 457 205 626 457 206 632 minecraft:white_concrete
fill 457 205 633 458 206 633 minecraft:gold_block
fill 458 205 626 459 206 628 minecraft:gold_block
fill 458 205 629 458 206 629 minecraft:white_concrete
fill 458 205 630 459 206 632 minecraft:gold_block
fill 459 205 629 460 206 629 minecraft:gold_block
fill 424 206 605 427 206 645 minecraft:gray_concrete
fill 428 206 605 428 206 628 minecraft:gray_concrete
fill 428 206 630 428 206 645 minecraft:gray_concrete
fill 429 206 605 429 206 625 minecraft:gray_concrete
fill 429 206 633 429 206 645 minecraft:gray_concrete
fill 430 206 605 430 206 623 minecraft:gray_concrete
fill 430 206 635 430 206 645 minecraft:gray_concrete
fill 431 206 605 431 206 622 minecraft:gray_concrete
fill 431 206 630 437 206 632 minecraft:white_concrete
fill 431 206 636 431 206 645 minecraft:gray_concrete
fill 432 206 605 433 206 621 minecraft:gray_concrete
fill 432 206 633 437 206 633 minecraft:white_concrete
fill 432 206 637 433 206 645 minecraft:gray_concrete
fill 433 206 634 437 206 634 minecraft:white_concrete
fill 434 206 605 435 206 620 minecraft:gray_concrete
fill 434 206 623 440 206 623 minecraft:white_concrete
fill 434 206 638 435 206 645 minecraft:gray_concrete
fill 436 206 605 438 206 619 minecraft:gray_concrete
fill 436 206 622 440 206 622 minecraft:white_concrete
fill 436 206 639 438 206 645 minecraft:gray_concrete
fill 438 206 630 438 206 634 minecraft:pearlescent_froglight
fill 439 206 605 464 206 618 minecraft:gray_concrete
fill 439 206 629 441 206 629 minecraft:black_concrete
fill 439 206 630 442 206 630 minecraft:pearlescent_froglight
fill 439 206 631 441 206 633 minecraft:gray_concrete
fill 439 206 634 442 206 634 minecraft:pearlescent_froglight
fill 439 206 640 464 206 645 minecraft:gray_concrete
fill 440 206 628 441 206 628 minecraft:black_concrete
fill 441 206 622 441 206 626 minecraft:pearlescent_froglight
setblock 441 206 627 minecraft:black_concrete
fill 442 206 622 445 206 622 minecraft:pearlescent_froglight
fill 442 206 623 444 206 625 minecraft:gray_concrete
fill 442 206 626 442 206 629 minecraft:pearlescent_froglight
fill 442 206 631 442 206 633 minecraft:pearlescent_froglight
fill 443 206 626 446 206 627 minecraft:pearlescent_froglight
fill 443 206 631 446 206 631 minecraft:pearlescent_froglight
fill 445 206 623 445 206 625 minecraft:pearlescent_froglight
fill 446 206 622 452 206 623 minecraft:white_concrete
fill 446 206 624 446 206 625 minecraft:pearlescent_froglight
fill 446 206 628 446 206 630 minecraft:pearlescent_froglight
fill 446 206 632 446 206 634 minecraft:pearlescent_froglight
fill 447 206 624 450 206 624 minecraft:pearlescent_froglight
fill 447 206 625 449 206 627 minecraft:gray_concrete
fill 447 206 628 450 206 628 minecraft:pearlescent_froglight
fill 447 206 629 448 206 629 minecraft:black_concrete
fill 447 206 630 450 206 630 minecraft:pearlescent_froglight
fill 447 206 631 449 206 633 minecraft:gray_concrete
fill 447 206 634 450 206 634 minecraft:pearlescent_froglight
fill 450 206 619 464 206 619 minecraft:gray_concrete
fill 450 206 625 450 206 627 minecraft:pearlescent_froglight
fill 450 206 629 456 206 629 minecraft:white_concrete
fill 450 206 631 450 206 633 minecraft:pearlescent_froglight
fill 450 206 639 464 206 639 minecraft:gray_concrete
fill 451 206 624 455 206 628 minecraft:white_concrete
fill 451 206 630 455 206 634 minecraft:white_concrete
fill 453 206 620 464 206 620 minecraft:gray_concrete
fill 453 206 623 454 206 623 minecraft:white_concrete
fill 453 206 638 464 206 638 minecraft:gray_concrete
fill 455 206 621 464 206 621 minecraft:gray_concrete
fill 455 206 637 464 206 637 minecraft:gray_concrete
fill 456 206 625 456 206 628 minecraft:white_concrete
fill 456 206 630 456 206 633 minecraft:white_concrete
fill 457 206 622 464 206 622 minecraft:gray_concrete
fill 457 206 636 464 206 636 minecraft:gray_concrete
fill 458 206 623 464 206 623 minecraft:gray_concrete
fill 458 206 635 464 206 635 minecraft:gray_concrete
fill 459 206 624 464 206 625 minecraft:gray_concrete
fill 459 206 633 464 206 634 minecraft:gray_concrete
fill 460 206 626 464 206 628 minecraft:gray_concrete
fill 460 206 630 464 206 632 minecraft:gray_concrete
fill 461 206 629 464 206 629 minecraft:gray_concrete
fill 424 210 605 425 210 645 minecraft:quartz_block
fill 426 210 605 464 210 606 minecraft:quartz_block
setblock 426 210 607 minecraft:light[level=13]
setblock 426 210 615 minecraft:light[level=13]
setblock 426 210 623 minecraft:light[level=13]
setblock 426 210 631 minecraft:light[level=13]
setblock 426 210 639 minecraft:light[level=13]
fill 426 210 644 464 210 645 minecraft:quartz_block
setblock 434 210 607 minecraft:light[level=13]
setblock 434 210 615 minecraft:light[level=13]
setblock 434 210 623 minecraft:light[level=13]
setblock 434 210 631 minecraft:light[level=13]
setblock 434 210 639 minecraft:light[level=13]
setblock 442 210 607 minecraft:light[level=13]
setblock 442 210 615 minecraft:light[level=13]
setblock 442 210 623 minecraft:light[level=13]
setblock 442 210 631 minecraft:light[level=13]
setblock 442 210 639 minecraft:light[level=13]
setblock 450 210 607 minecraft:light[level=13]
setblock 450 210 615 minecraft:light[level=13]
setblock 450 210 623 minecraft:light[level=13]
setblock 450 210 631 minecraft:light[level=13]
setblock 450 210 639 minecraft:light[level=13]
setblock 458 210 607 minecraft:light[level=13]
setblock 458 210 615 minecraft:light[level=13]
setblock 458 210 623 minecraft:light[level=13]
setblock 458 210 631 minecraft:light[level=13]
setblock 458 210 639 minecraft:light[level=13]
fill 463 210 607 464 210 643 minecraft:quartz_block
fill 424 211 605 424 211 645 minecraft:quartz_block
fill 425 211 605 464 211 605 minecraft:quartz_block
fill 425 211 645 464 211 645 minecraft:quartz_block
fill 464 211 606 464 211 644 minecraft:quartz_block
fill 424 212 611 424 240 612 minecraft:quartz_block
fill 424 212 619 424 240 620 minecraft:quartz_block
fill 424 212 627 424 240 628 minecraft:quartz_block
fill 424 212 635 424 240 636 minecraft:quartz_block
fill 424 212 643 424 240 644 minecraft:quartz_block
fill 425 212 605 426 240 605 minecraft:quartz_block
fill 430 212 645 431 240 645 minecraft:quartz_block
fill 433 212 605 434 240 605 minecraft:quartz_block
fill 438 212 645 439 240 645 minecraft:quartz_block
fill 441 212 605 442 240 605 minecraft:quartz_block
fill 446 212 645 447 240 645 minecraft:quartz_block
fill 449 212 605 450 240 605 minecraft:quartz_block
fill 452 212 634 454 213 634 minecraft:white_concrete
fill 453 212 635 454 213 635 minecraft:white_concrete
fill 454 212 645 455 240 645 minecraft:quartz_block
fill 457 212 605 458 240 605 minecraft:quartz_block
fill 462 212 645 463 240 645 minecraft:quartz_block
fill 464 212 606 464 240 607 minecraft:quartz_block
fill 464 212 614 464 240 615 minecraft:quartz_block
fill 464 212 622 464 240 623 minecraft:quartz_block
fill 464 212 630 464 240 631 minecraft:quartz_block
fill 464 212 638 464 240 639 minecraft:quartz_block
fill 423 214 609 423 219 609 minecraft:pearlescent_froglight
fill 423 214 617 423 219 617 minecraft:pearlescent_froglight
fill 423 214 625 423 219 625 minecraft:pearlescent_froglight
fill 423 214 633 423 219 633 minecraft:pearlescent_froglight
fill 423 214 641 423 219 641 minecraft:pearlescent_froglight
fill 426 214 646 426 219 646 minecraft:pearlescent_froglight
fill 430 214 604 430 219 604 minecraft:pearlescent_froglight
fill 434 214 646 434 219 646 minecraft:pearlescent_froglight
fill 438 214 604 438 219 604 minecraft:pearlescent_froglight
fill 442 214 646 442 219 646 minecraft:pearlescent_froglight
fill 446 214 604 446 219 604 minecraft:pearlescent_froglight
fill 450 214 646 450 219 646 minecraft:pearlescent_froglight
fill 454 214 604 454 219 604 minecraft:pearlescent_froglight
fill 458 214 646 458 219 646 minecraft:pearlescent_froglight
fill 462 214 604 462 219 604 minecraft:pearlescent_froglight
fill 465 214 609 465 219 609 minecraft:pearlescent_froglight
fill 465 214 617 465 219 617 minecraft:pearlescent_froglight
fill 465 214 625 465 219 625 minecraft:pearlescent_froglight
fill 465 214 633 465 219 633 minecraft:pearlescent_froglight
fill 465 214 641 465 219 641 minecraft:pearlescent_froglight
fill 435 217 636 437 218 637 minecraft:white_concrete
setblock 426 218 607 minecraft:light[level=13]
setblock 426 218 615 minecraft:light[level=13]
setblock 426 218 623 minecraft:light[level=13]
setblock 426 218 631 minecraft:light[level=13]
setblock 426 218 639 minecraft:light[level=13]
setblock 434 218 607 minecraft:light[level=13]
setblock 434 218 615 minecraft:light[level=13]
setblock 434 218 623 minecraft:light[level=13]
setblock 434 218 631 minecraft:light[level=13]
setblock 434 218 639 minecraft:light[level=13]
setblock 442 218 607 minecraft:light[level=13]
setblock 442 218 615 minecraft:light[level=13]
setblock 442 218 623 minecraft:light[level=13]
setblock 442 218 631 minecraft:light[level=13]
setblock 442 218 639 minecraft:light[level=13]
setblock 450 218 607 minecraft:light[level=13]
setblock 450 218 615 minecraft:light[level=13]
setblock 450 218 623 minecraft:light[level=13]
setblock 450 218 631 minecraft:light[level=13]
setblock 450 218 639 minecraft:light[level=13]
setblock 458 218 607 minecraft:light[level=13]
setblock 458 218 615 minecraft:light[level=13]
setblock 458 218 623 minecraft:light[level=13]
setblock 458 218 631 minecraft:light[level=13]
setblock 458 218 639 minecraft:light[level=13]
fill 455 219 625 461 221 631 minecraft:stone
fill 462 219 627 463 220 629 minecraft:gold_block
fill 423 220 609 423 227 609 minecraft:light_gray_concrete
fill 423 220 617 423 227 617 minecraft:light_gray_concrete
fill 423 220 625 423 227 625 minecraft:light_gray_concrete
fill 423 220 633 423 227 633 minecraft:light_gray_concrete
fill 423 220 641 423 227 641 minecraft:light_gray_concrete
fill 426 220 646 426 227 646 minecraft:light_gray_concrete
fill 430 220 604 430 227 604 minecraft:light_gray_concrete
fill 434 220 646 434 227 646 minecraft:light_gray_concrete
fill 438 220 604 438 227 604 minecraft:light_gray_concrete
fill 442 220 646 442 227 646 minecraft:light_gray_concrete
fill 446 220 604 446 227 604 minecraft:light_gray_concrete
fill 450 220 646 450 227 646 minecraft:light_gray_concrete
fill 454 220 604 454 227 604 minecraft:light_gray_concrete
fill 458 220 646 458 227 646 minecraft:light_gray_concrete
fill 462 220 604 462 227 604 minecraft:light_gray_concrete
fill 465 220 609 465 227 609 minecraft:light_gray_concrete
fill 465 220 617 465 227 617 minecraft:light_gray_concrete
fill 465 220 625 465 227 625 minecraft:light_gray_concrete
fill 465 220 633 465 227 633 minecraft:light_gray_concrete
fill 465 220 641 465 227 641 minecraft:light_gray_concrete
fill 451 221 642 451 222 643 minecraft:black_concrete
fill 447 222 613 447 223 614 minecraft:gold_block
fill 455 222 625 461 224 631 minecraft:dirt
fill 424 224 605 424 225 610 minecraft:quartz_block
fill 424 224 613 425 224 618 minecraft:quartz_block
fill 424 224 621 425 224 626 minecraft:quartz_block
fill 424 224 629 425 224 634 minecraft:quartz_block
fill 424 224 637 425 224 642 minecraft:quartz_block
fill 424 224 645 429 225 645 minecraft:quartz_block
fill 425 224 606 425 224 612 minecraft:quartz_block
fill 425 224 619 425 224 620 minecraft:quartz_block
fill 425 224 627 425 224 628 minecraft:quartz_block
fill 425 224 635 425 224 636 minecraft:quartz_block
fill 425 224 643 425 224 644 minecraft:quartz_block
fill 426 224 606 463 224 606 minecraft:quartz_block
fill 426 224 644 464 224 644 minecraft:quartz_block
fill 427 224 605 432 225 605 minecraft:quartz_block
fill 432 224 645 437 225 645 minecraft:quartz_block
fill 435 224 605 440 225 605 minecraft:quartz_block
fill 440 224 645 445 225 645 minecraft:quartz_block
fill 443 224 605 448 225 605 minecraft:quartz_block
fill 448 224 645 453 225 645 minecraft:quartz_block
fill 451 224 605 456 225 605 minecraft:quartz_block
fill 456 224 645 461 225 645 minecraft:quartz_block
fill 459 224 605 464 225 605 minecraft:quartz_block
fill 463 224 607 463 224 643 minecraft:quartz_block
fill 464 224 608 464 225 613 minecraft:quartz_block
fill 464 224 616 464 225 621 minecraft:quartz_block
fill 464 224 624 464 225 629 minecraft:quartz_block
fill 464 224 632 464 225 637 minecraft:quartz_block
fill 464 224 640 464 225 643 minecraft:quartz_block
fill 464 224 645 464 225 645 minecraft:quartz_block
fill 424 225 613 424 225 618 minecraft:quartz_block
fill 424 225 621 424 225 626 minecraft:quartz_block
fill 424 225 629 424 225 634 minecraft:quartz_block
fill 424 225 637 424 225 642 minecraft:quartz_block
fill 427 225 626 433 227 632 minecraft:stone
fill 455 225 625 461 225 631 minecraft:moss_block
setblock 464 225 644 minecraft:quartz_block
setblock 426 226 607 minecraft:light[level=13]
setblock 426 226 615 minecraft:light[level=13]
setblock 426 226 623 minecraft:light[level=13]
setblock 426 226 631 minecraft:light[level=13]
setblock 426 226 639 minecraft:light[level=13]
setblock 434 226 607 minecraft:light[level=13]
setblock 434 226 615 minecraft:light[level=13]
setblock 434 226 623 minecraft:light[level=13]
setblock 434 226 631 minecraft:light[level=13]
setblock 434 226 639 minecraft:light[level=13]
setblock 442 226 607 minecraft:light[level=13]
setblock 442 226 615 minecraft:light[level=13]
setblock 442 226 623 minecraft:light[level=13]
setblock 442 226 631 minecraft:light[level=13]
setblock 442 226 639 minecraft:light[level=13]
setblock 450 226 607 minecraft:light[level=13]
setblock 450 226 615 minecraft:light[level=13]
setblock 450 226 623 minecraft:light[level=13]
setblock 450 226 631 minecraft:light[level=13]
setblock 450 226 639 minecraft:light[level=13]
setblock 458 226 607 minecraft:light[level=13]
setblock 458 226 615 minecraft:light[level=13]
setblock 458 226 623 minecraft:light[level=13]
fill 458 226 628 458 230 628 minecraft:oak_log
setblock 458 226 631 minecraft:light[level=13]
setblock 458 226 639 minecraft:light[level=13]
fill 423 228 609 423 233 609 minecraft:pearlescent_froglight
fill 423 228 617 423 233 617 minecraft:pearlescent_froglight
fill 423 228 625 423 233 625 minecraft:pearlescent_froglight
fill 423 228 633 423 233 633 minecraft:pearlescent_froglight
fill 423 228 641 423 233 641 minecraft:pearlescent_froglight
fill 426 228 646 426 233 646 minecraft:pearlescent_froglight
fill 427 228 626 433 230 632 minecraft:dirt
fill 430 228 604 430 233 604 minecraft:pearlescent_froglight
fill 434 228 646 434 233 646 minecraft:pearlescent_froglight
fill 438 228 604 438 233 604 minecraft:pearlescent_froglight
fill 442 228 646 442 233 646 minecraft:pearlescent_froglight
fill 446 228 604 446 233 604 minecraft:pearlescent_froglight
fill 450 228 646 450 233 646 minecraft:pearlescent_froglight
fill 454 228 604 454 233 604 minecraft:pearlescent_froglight
fill 458 228 646 458 233 646 minecraft:pearlescent_froglight
fill 462 228 604 462 233 604 minecraft:pearlescent_froglight
fill 465 228 609 465 233 609 minecraft:pearlescent_froglight
fill 465 228 617 465 233 617 minecraft:pearlescent_froglight
fill 465 228 625 465 233 625 minecraft:pearlescent_froglight
fill 465 228 633 465 233 633 minecraft:pearlescent_froglight
fill 465 228 641 465 233 641 minecraft:pearlescent_froglight
fill 457 230 627 457 233 629 minecraft:oak_leaves[persistent=true]
fill 458 230 627 459 233 627 minecraft:oak_leaves[persistent=true]
fill 458 230 629 459 233 629 minecraft:oak_leaves[persistent=true]
fill 459 230 628 459 233 628 minecraft:oak_leaves[persistent=true]
fill 427 231 626 433 231 632 minecraft:moss_block
fill 433 231 613 433 232 614 minecraft:gold_block
fill 435 231 609 441 233 615 minecraft:stone
fill 458 231 626 458 232 626 minecraft:oak_leaves[persistent=true]
fill 458 231 628 458 233 628 minecraft:oak_leaves[persistent=true]
fill 458 231 630 459 232 630 minecraft:oak_leaves[persistent=true]
fill 460 231 628 460 232 629 minecraft:oak_leaves[persistent=true]
fill 430 232 629 430 236 629 minecraft:oak_log
fill 456 233 611 456 234 611 minecraft:gold_block
fill 423 234 609 423 247 609 minecraft:light_gray_concrete
fill 423 234 617 423 247 617 minecraft:light_gray_concrete
fill 423 234 625 423 247 625 minecraft:light_gray_concrete
fill 423 234 633 423 247 633 minecraft:light_gray_concrete
fill 423 234 641 423 247 641 minecraft:light_gray_concrete
setblock 426 234 607 minecraft:light[level=13]
setblock 426 234 615 minecraft:light[level=13]
setblock 426 234 623 minecraft:light[level=13]
setblock 426 234 631 minecraft:light[level=13]
setblock 426 234 639 minecraft:light[level=13]
fill 426 234 646 426 243 646 minecraft:light_gray_concrete
fill 430 234 604 430 247 604 minecraft:light_gray_concrete
setblock 434 234 607 minecraft:light[level=13]
setblock 434 234 615 minecraft:light[level=13]
setblock 434 234 623 minecraft:light[level=13]
setblock 434 234 631 minecraft:light[level=13]
setblock 434 234 639 minecraft:light[level=13]
fill 434 234 646 434 243 646 minecraft:light_gray_concrete
fill 435 234 609 441 236 615 minecraft:dirt
fill 438 234 604 438 247 604 minecraft:light_gray_concrete
setblock 442 234 607 minecraft:light[level=13]
setblock 442 234 615 minecraft:light[level=13]
setblock 442 234 623 minecraft:light[level=13]
setblock 442 234 631 minecraft:light[level=13]
setblock 442 234 639 minecraft:light[level=13]
fill 442 234 646 442 247 646 minecraft:light_gray_concrete
fill 446 234 604 446 247 604 minecraft:light_gray_concrete
setblock 450 234 607 minecraft:light[level=13]
setblock 450 234 615 minecraft:light[level=13]
setblock 450 234 623 minecraft:light[level=13]
setblock 450 234 631 minecraft:light[level=13]
setblock 450 234 639 minecraft:light[level=13]
fill 450 234 646 450 247 646 minecraft:light_gray_concrete
fill 454 234 604 454 245 604 minecraft:light_gray_concrete
setblock 458 234 607 minecraft:light[level=13]
setblock 458 234 615 minecraft:light[level=13]
setblock 458 234 623 minecraft:light[level=13]
setblock 458 234 631 minecraft:light[level=13]
setblock 458 234 639 minecraft:light[level=13]
fill 458 234 646 458 245 646 minecraft:light_gray_concrete
fill 462 234 604 462 249 604 minecraft:light_gray_concrete
fill 465 234 609 465 247 609 minecraft:light_gray_concrete
fill 465 234 617 465 247 617 minecraft:light_gray_concrete
fill 465 234 625 465 247 625 minecraft:light_gray_concrete
fill 465 234 633 465 243 633 minecraft:light_gray_concrete
fill 465 234 641 465 247 641 minecraft:light_gray_concrete
fill 429 236 628 429 239 630 minecraft:oak_leaves[persistent=true]
fill 430 236 628 431 239 628 minecraft:oak_leaves[persistent=true]
fill 430 236 630 431 239 630 minecraft:oak_leaves[persistent=true]
fill 431 236 629 431 239 629 minecraft:oak_leaves[persistent=true]
fill 442 236 638 442 240 639 minecraft:orange_concrete
fill 443 236 638 443 240 638 minecraft:orange_concrete
fill 428 237 629 428 238 629 minecraft:oak_leaves[persistent=true]
fill 429 237 627 431 238 627 minecraft:oak_leaves[persistent=true]
fill 430 237 629 430 239 629 minecraft:oak_leaves[persistent=true]
fill 432 237 629 432 238 629 minecraft:oak_leaves[persistent=true]
fill 435 237 609 441 237 615 minecraft:moss_block
fill 440 237 637 441 240 639 minecraft:orange_concrete
fill 441 237 636 443 240 636 minecraft:orange_concrete
fill 441 237 640 443 240 640 minecraft:orange_concrete
fill 442 237 637 444 240 637 minecraft:orange_concrete
fill 443 237 639 444 240 639 minecraft:orange_concrete
fill 444 237 638 444 240 638 minecraft:orange_concrete
fill 424 238 605 424 239 610 minecraft:quartz_block
fill 424 238 613 425 238 618 minecraft:quartz_block
fill 424 238 621 425 238 626 minecraft:quartz_block
fill 424 238 629 425 238 634 minecraft:quartz_block
fill 424 238 637 425 238 642 minecraft:quartz_block
fill 424 238 645 429 239 645 minecraft:quartz_block
fill 425 238 606 425 238 612 minecraft:quartz_block
fill 425 238 619 425 238 620 minecraft:quartz_block
fill 425 238 627 425 238 628 minecraft:quartz_block
fill 425 238 635 425 238 636 minecraft:quartz_block
fill 425 238 643 425 238 644 minecraft:quartz_block
fill 426 238 606 463 238 606 minecraft:quartz_block
fill 426 238 644 464 238 644 minecraft:quartz_block
fill 427 238 605 432 239 605 minecraft:quartz_block
fill 432 238 645 437 239 645 minecraft:quartz_block
fill 435 238 605 440 239 605 minecraft:quartz_block
fill 439 238 638 439 240 639 minecraft:orange_concrete
fill 440 238 636 440 240 636 minecraft:orange_concrete
fill 440 238 640 440 240 640 minecraft:orange_concrete
fill 440 238 645 445 239 645 minecraft:quartz_block
fill 441 238 641 443 240 641 minecraft:orange_concrete
fill 442 238 635 443 240 635 minecraft:orange_concrete
fill 443 238 605 448 239 605 minecraft:quartz_block
fill 444 238 636 444 240 636 minecraft:orange_concrete
fill 444 238 640 444 240 640 minecraft:orange_concrete
fill 445 238 637 445 240 639 minecraft:orange_concrete
fill 448 238 645 453 239 645 minecraft:quartz_block
fill 451 238 605 456 239 605 minecraft:quartz_block
fill 455 238 614 455 239 614 minecraft:gold_block
fill 456 238 645 461 239 645 minecraft:quartz_block
fill 459 238 605 464 239 605 minecraft:quartz_block
fill 463 238 607 463 238 643 minecraft:quartz_block
fill 464 238 608 464 239 613 minecraft:quartz_block
fill 464 238 616 464 239 621 minecraft:quartz_block
fill 464 238 624 464 239 629 minecraft:quartz_block
fill 464 238 632 464 239 637 minecraft:quartz_block
fill 464 238 640 464 239 643 minecraft:quartz_block
fill 464 238 645 464 239 645 minecraft:quartz_block
fill 424 239 613 424 239 618 minecraft:quartz_block
fill 424 239 621 424 239 626 minecraft:quartz_block
fill 424 239 629 424 239 634 minecraft:quartz_block
fill 424 239 637 424 239 642 minecraft:quartz_block
fill 439 239 637 439 240 637 minecraft:orange_concrete
fill 440 239 641 440 240 641 minecraft:orange_concrete
fill 441 239 635 441 240 635 minecraft:orange_concrete
fill 442 239 616 443 240 617 minecraft:gold_block
fill 443 239 615 443 240 615 minecraft:gold_block
fill 444 239 641 444 240 641 minecraft:orange_concrete
fill 445 239 640 445 240 640 minecraft:orange_concrete
setblock 464 239 644 minecraft:quartz_block
setblock 426 242 607 minecraft:light[level=13]
setblock 426 242 615 minecraft:light[level=13]
setblock 426 242 623 minecraft:light[level=13]
setblock 426 242 631 minecraft:light[level=13]
setblock 426 242 639 minecraft:light[level=13]
setblock 434 242 607 minecraft:light[level=13]
setblock 434 242 615 minecraft:light[level=13]
setblock 434 242 623 minecraft:light[level=13]
setblock 434 242 631 minecraft:light[level=13]
setblock 434 242 639 minecraft:light[level=13]
setblock 442 242 607 minecraft:light[level=13]
setblock 442 242 615 minecraft:light[level=13]
setblock 442 242 623 minecraft:light[level=13]
setblock 442 242 631 minecraft:light[level=13]
setblock 442 242 639 minecraft:light[level=13]
setblock 450 242 607 minecraft:light[level=13]
setblock 450 242 615 minecraft:light[level=13]
setblock 450 242 623 minecraft:light[level=13]
setblock 450 242 631 minecraft:light[level=13]
setblock 450 242 639 minecraft:light[level=13]
setblock 458 242 607 minecraft:light[level=13]
setblock 458 242 615 minecraft:light[level=13]
setblock 458 242 623 minecraft:light[level=13]
setblock 458 242 631 minecraft:light[level=13]
setblock 458 242 639 minecraft:light[level=13]
fill 423 244 604 425 244 604 minecraft:light_gray_concrete
setblock 423 244 605 minecraft:white_concrete
fill 423 244 606 423 244 608 minecraft:light_gray_concrete
fill 423 244 610 423 245 610 minecraft:white_concrete
fill 423 244 611 423 247 612 minecraft:light_gray_concrete
fill 423 244 619 423 245 619 minecraft:white_concrete
fill 423 244 627 423 247 629 minecraft:light_gray_concrete
setblock 423 244 630 minecraft:white_concrete
fill 423 244 642 423 244 644 minecraft:light_gray_concrete
fill 423 244 645 423 245 645 minecraft:white_concrete
fill 426 244 604 427 244 604 minecraft:white_concrete
setblock 426 244 646 minecraft:white_concrete
fill 431 244 604 432 244 604 minecraft:light_gray_concrete
setblock 433 244 604 minecraft:white_concrete
fill 434 244 604 434 247 604 minecraft:light_gray_concrete
setblock 434 244 646 minecraft:white_concrete
fill 437 244 646 437 245 646 minecraft:white_concrete
fill 438 244 646 438 248 646 minecraft:light_gray_concrete
fill 447 244 646 448 244 646 minecraft:white_concrete
setblock 456 244 604 minecraft:white_concrete
fill 457 244 604 458 247 604 minecraft:light_gray_concrete
fill 459 244 646 460 247 646 minecraft:light_gray_concrete
fill 461 244 646 463 244 646 minecraft:white_concrete
setblock 465 244 605 minecraft:white_concrete
fill 465 244 606 465 247 607 minecraft:light_gray_concrete
setblock 465 244 610 minecraft:white_concrete
fill 465 244 618 465 245 618 minecraft:light_gray_concrete
setblock 465 244 619 minecraft:white_concrete
fill 465 244 620 465 247 620 minecraft:light_gray_concrete
setblock 465 244 633 minecraft:white_concrete
setblock 423 245 604 minecraft:white_concrete
fill 423 245 605 423 247 607 minecraft:light_gray_concrete
setblock 423 245 608 minecraft:white_concrete
setblock 423 245 616 minecraft:white_concrete
setblock 423 245 626 minecraft:white_concrete
fill 423 245 630 423 247 630 minecraft:light_gray_concrete
setblock 423 245 637 minecraft:white_concrete
fill 423 245 638 423 247 640 minecraft:light_gray_concrete
fill 423 245 642 423 247 643 minecraft:light_gray_concrete
setblock 423 245 644 minecraft:white_concrete
fill 424 245 604 427 247 604 minecraft:light_gray_concrete
fill 426 245 646 426 247 646 minecraft:light_gray_concrete
fill 431 245 604 431 247 604 minecraft:light_gray_concrete
setblock 432 245 604 minecraft:white_concrete
fill 433 245 604 433 247 604 minecraft:light_gray_concrete
fill 434 245 646 434 247 646 minecraft:light_gray_concrete
fill 439 245 623 441 245 625 minecraft:redstone_block
fill 439 245 629 441 245 631 minecraft:redstone_block
fill 446 245 630 448 245 632 minecraft:redstone_block
fill 447 245 623 449 245 625 minecraft:redstone_block
fill 447 245 646 448 245 646 minecraft:light_gray_concrete
setblock 452 245 646 minecraft:white_concrete
setblock 453 245 604 minecraft:white_concrete
setblock 455 245 604 minecraft:white_concrete
fill 456 245 604 456 247 604 minecraft:light_gray_concrete
fill 461 245 646 462 247 646 minecraft:light_gray_concrete
setblock 463 245 646 minecraft:white_concrete
fill 465 245 605 465 247 605 minecraft:light_gray_concrete
fill 465 245 610 465 247 610 minecraft:light_gray_concrete
setblock 465 245 619 minecraft:light_gray_concrete
setblock 465 245 621 minecraft:white_concrete
fill 465 245 633 465 247 633 minecraft:light_gray_concrete
setblock 465 245 644 minecraft:white_concrete
fill 465 245 645 465 247 645 minecraft:light_gray_concrete
fill 423 246 604 423 247 604 minecraft:light_gray_concrete
fill 423 246 608 423 247 608 minecraft:light_gray_concrete
fill 423 246 610 423 247 610 minecraft:light_gray_concrete
fill 423 246 616 423 247 616 minecraft:light_gray_concrete
fill 423 246 619 423 247 619 minecraft:light_gray_concrete
fill 423 246 626 423 247 626 minecraft:light_gray_concrete
fill 423 246 637 423 247 637 minecraft:light_gray_concrete
fill 423 246 644 423 247 645 minecraft:light_gray_concrete
fill 425 246 626 442 246 628 minecraft:black_concrete
fill 432 246 604 432 247 604 minecraft:light_gray_concrete
setblock 435 246 604 minecraft:white_concrete
setblock 435 246 646 minecraft:white_concrete
fill 436 246 646 437 247 646 minecraft:light_gray_concrete
setblock 439 246 604 minecraft:white_concrete
fill 440 246 604 440 247 604 minecraft:light_gray_concrete
setblock 441 246 604 minecraft:white_concrete
fill 443 246 608 445 246 625 minecraft:black_concrete
fill 443 246 629 445 246 646 minecraft:black_concrete
fill 446 246 626 463 246 628 minecraft:black_concrete
setblock 446 246 646 minecraft:white_concrete
fill 447 246 604 448 247 604 minecraft:light_gray_concrete
fill 447 246 646 447 247 646 minecraft:light_gray_concrete
setblock 448 246 646 minecraft:white_concrete
setblock 449 246 604 minecraft:white_concrete
fill 450 246 604 450 247 604 minecraft:light_gray_concrete
setblock 451 246 604 minecraft:white_concrete
fill 452 246 646 452 247 646 minecraft:light_gray_concrete
fill 453 246 604 453 247 604 minecraft:light_gray_concrete
setblock 454 246 604 minecraft:white_concrete
fill 455 246 604 455 247 604 minecraft:light_gray_concrete
fill 457 246 646 458 246 646 minecraft:white_concrete
fill 463 246 646 463 247 646 minecraft:light_gray_concrete
setblock 464 246 646 minecraft:white_concrete
setblock 465 246 608 minecraft:white_concrete
setblock 465 246 616 minecraft:white_concrete
fill 465 246 618 465 246 619 minecraft:white_concrete
fill 465 246 621 465 247 621 minecraft:light_gray_concrete
setblock 465 246 623 minecraft:white_concrete
fill 465 246 624 465 247 624 minecraft:light_gray_concrete
setblock 465 246 628 minecraft:white_concrete
fill 465 246 629 465 248 629 minecraft:light_gray_concrete
fill 465 246 634 465 247 634 minecraft:light_gray_concrete
setblock 465 246 635 minecraft:white_concrete
fill 465 246 636 465 247 637 minecraft:light_gray_concrete
setblock 465 246 638 minecraft:white_concrete
fill 465 246 644 465 247 644 minecraft:light_gray_concrete
fill 424 247 605 424 247 645 minecraft:light_gray_concrete
fill 425 247 605 437 247 625 minecraft:light_gray_concrete
fill 425 247 626 437 247 626 minecraft:gold_block
fill 425 247 627 441 247 627 minecraft:black_concrete
fill 425 247 628 437 247 628 minecraft:gold_block
fill 425 247 629 437 247 645 minecraft:light_gray_concrete
setblock 435 247 604 minecraft:light_gray_concrete
setblock 435 247 646 minecraft:light_gray_concrete
fill 438 247 605 439 247 621 minecraft:light_gray_concrete
fill 438 247 622 438 247 626 minecraft:pearlescent_froglight
fill 438 247 628 438 247 632 minecraft:pearlescent_froglight
fill 438 247 633 439 247 645 minecraft:light_gray_concrete
setblock 439 247 604 minecraft:light_gray_concrete
fill 439 247 622 441 247 622 minecraft:pearlescent_froglight
fill 439 247 623 441 247 625 minecraft:light_gray_concrete
fill 439 247 626 441 247 626 minecraft:pearlescent_froglight
fill 439 247 628 441 247 628 minecraft:pearlescent_froglight
fill 439 247 629 441 247 631 minecraft:light_gray_concrete
fill 439 247 632 441 247 632 minecraft:pearlescent_froglight
fill 440 247 605 441 247 619 minecraft:light_gray_concrete
fill 440 247 620 448 258 621 minecraft:green_terracotta
fill 440 247 633 448 258 634 minecraft:lime_terracotta
fill 440 247 635 441 247 645 minecraft:light_gray_concrete
setblock 441 247 604 minecraft:light_gray_concrete
fill 442 247 605 442 247 618 minecraft:light_gray_concrete
fill 442 247 619 446 258 619 minecraft:green_terracotta
fill 442 247 622 446 258 622 minecraft:green_terracotta
fill 442 247 623 442 247 625 minecraft:pearlescent_froglight
fill 442 247 626 442 247 628 minecraft:verdant_froglight
fill 442 247 629 442 247 631 minecraft:pearlescent_froglight
fill 442 247 632 446 258 632 minecraft:lime_terracotta
fill 442 247 635 446 258 635 minecraft:lime_terracotta
fill 442 247 636 442 247 645 minecraft:light_gray_concrete
fill 443 247 605 464 247 607 minecraft:light_gray_concrete
fill 443 247 608 443 247 618 minecraft:gold_block
fill 443 247 623 443 247 624 minecraft:gold_block
fill 443 247 625 445 247 625 minecraft:verdant_froglight
fill 443 247 629 445 247 629 minecraft:verdant_froglight
fill 443 247 630 443 247 631 minecraft:gold_block
fill 443 247 636 443 247 646 minecraft:gold_block
fill 444 247 608 444 247 618 minecraft:black_concrete
fill 444 247 623 444 247 624 minecraft:black_concrete
fill 444 247 630 444 247 631 minecraft:black_concrete
fill 444 247 636 444 247 646 minecraft:black_concrete
fill 445 247 608 445 247 618 minecraft:gold_block
fill 445 247 623 445 247 624 minecraft:gold_block
fill 445 247 630 445 247 631 minecraft:pearlescent_froglight
fill 445 247 636 445 247 646 minecraft:gold_block
fill 446 247 608 464 247 618 minecraft:light_gray_concrete
fill 446 247 623 446 247 625 minecraft:pearlescent_froglight
fill 446 247 626 446 247 628 minecraft:verdant_froglight
fill 446 247 629 449 247 629 minecraft:pearlescent_froglight
fill 446 247 630 448 247 631 minecraft:light_gray_concrete
fill 446 247 636 446 247 646 minecraft:light_gray_concrete
fill 447 247 619 465 247 619 minecraft:light_gray_concrete
fill 447 247 622 450 247 622 minecraft:pearlescent_froglight
fill 447 247 623 449 247 625 minecraft:light_gray_concrete
fill 447 247 626 450 247 626 minecraft:pearlescent_froglight
fill 447 247 627 463 247 627 minecraft:black_concrete
fill 447 247 628 463 247 628 minecraft:gold_block
fill 447 247 632 448 247 632 minecraft:light_gray_concrete
fill 447 247 635 464 247 645 minecraft:light_gray_concrete
setblock 448 247 646 minecraft:light_gray_concrete
setblock 449 247 604 minecraft:light_gray_concrete
fill 449 247 620 464 247 621 minecraft:light_gray_concrete
fill 449 247 630 449 247 633 minecraft:pearlescent_froglight
fill 449 247 634 464 247 634 minecraft:light_gray_concrete
fill 450 247 623 450 247 625 minecraft:pearlescent_froglight
fill 450 247 629 464 247 633 minecraft:light_gray_concrete
setblock 451 247 604 minecraft:light_gray_concrete
fill 451 247 622 464 247 625 minecraft:light_gray_concrete
fill 451 247 626 463 247 626 minecraft:gold_block
setblock 454 247 604 minecraft:light_gray_concrete
fill 457 247 646 458 247 646 minecraft:light_gray_concrete
fill 464 247 626 464 247 628 minecraft:light_gray_concrete
setblock 464 247 646 minecraft:light_gray_concrete
setblock 465 247 608 minecraft:light_gray_concrete
setblock 465 247 616 minecraft:light_gray_concrete
fill 465 247 618 465 248 618 minecraft:light_gray_concrete
setblock 465 247 623 minecraft:light_gray_concrete
setblock 465 247 628 minecraft:light_gray_concrete
setblock 465 247 635 minecraft:light_gray_concrete
fill 465 247 638 465 248 638 minecraft:light_gray_concrete
fill 423 248 604 423 248 646 minecraft:white_concrete
fill 424 248 604 436 248 604 minecraft:white_concrete
fill 424 248 646 430 255 646 minecraft:white_concrete
fill 432 248 646 437 255 646 minecraft:white_concrete
fill 437 248 604 437 249 604 minecraft:light_gray_concrete
fill 438 248 604 441 248 604 minecraft:white_concrete
fill 438 248 619 439 257 622 minecraft:green_terracotta
fill 438 248 632 439 257 635 minecraft:lime_terracotta
fill 439 248 646 439 307 646 minecraft:white_concrete
fill 440 248 619 441 258 619 minecraft:green_terracotta
fill 440 248 622 441 258 622 minecraft:green_terracotta
fill 440 248 632 441 258 632 minecraft:lime_terracotta
fill 440 248 635 441 258 635 minecraft:lime_terracotta
fill 440 248 646 440 249 646 minecraft:light_gray_concrete
fill 441 248 618 447 257 618 minecraft:green_terracotta
fill 441 248 623 447 255 623 minecraft:green_terracotta
fill 441 248 631 447 255 631 minecraft:lime_terracotta
fill 441 248 636 447 257 636 minecraft:lime_terracotta
fill 441 248 646 444 248 646 minecraft:white_concrete
setblock 442 248 604 minecraft:light_gray_concrete
fill 443 248 604 460 248 604 minecraft:white_concrete
setblock 445 248 646 minecraft:light_gray_concrete
fill 446 248 646 465 249 646 minecraft:white_concrete
fill 447 248 619 450 257 619 minecraft:green_terracotta
fill 447 248 622 450 257 622 minecraft:green_terracotta
fill 447 248 632 450 257 632 minecraft:lime_terracotta
fill 447 248 635 450 257 635 minecraft:lime_terracotta
fill 449 248 620 450 258 621 minecraft:green_terracotta
fill 449 248 633 450 258 634 minecraft:lime_terracotta
fill 463 248 604 465 249 604 minecraft:white_concrete
fill 465 248 605 465 248 614 minecraft:white_concrete
setblock 465 248 615 minecraft:light_gray_concrete
fill 465 248 616 465 255 617 minecraft:white_concrete
fill 465 248 619 465 248 628 minecraft:white_concrete
fill 465 248 630 465 248 637 minecraft:white_concrete
fill 465 248 639 465 307 639 minecraft:white_concrete
setblock 465 248 640 minecraft:light_gray_concrete
fill 465 248 641 465 255 645 minecraft:white_concrete
fill 423 249 604 423 249 615 minecraft:white_concrete
setblock 423 249 616 minecraft:light_gray_concrete
fill 423 249 617 423 255 620 minecraft:white_concrete
setblock 423 249 621 minecraft:light_gray_concrete
fill 423 249 622 423 255 626 minecraft:white_concrete
fill 423 249 627 423 249 628 minecraft:light_gray_concrete
fill 423 249 629 423 307 631 minecraft:white_concrete
setblock 423 249 632 minecraft:light_gray_concrete
fill 423 249 633 423 255 646 minecraft:white_concrete
fill 424 249 604 427 307 604 minecraft:white_concrete
setblock 428 249 604 minecraft:light_gray_concrete
fill 429 249 604 431 255 604 minecraft:white_concrete
setblock 432 249 604 minecraft:light_gray_concrete
fill 433 249 604 436 307 604 minecraft:white_concrete
fill 436 249 620 437 257 621 minecraft:green_terracotta
fill 436 249 633 437 257 634 minecraft:lime_terracotta
fill 437 249 619 437 257 619 minecraft:green_terracotta
fill 437 249 622 437 257 622 minecraft:green_terracotta
fill 437 249 632 437 257 632 minecraft:lime_terracotta
fill 437 249 635 437 257 635 minecraft:lime_terracotta
setblock 438 249 604 minecraft:light_gray_concrete
fill 438 249 618 440 256 618 minecraft:green_terracotta
fill 438 249 623 440 256 623 minecraft:green_terracotta
fill 438 249 631 440 256 631 minecraft:lime_terracotta
fill 438 249 636 440 256 636 minecraft:lime_terracotta
fill 438 249 646 438 307 646 minecraft:white_concrete
fill 439 249 604 440 249 604 minecraft:white_concrete
setblock 441 249 604 minecraft:light_gray_concrete
fill 441 249 646 442 255 646 minecraft:white_concrete
fill 442 249 604 445 307 604 minecraft:white_concrete
fill 443 249 617 445 256 617 minecraft:green_terracotta
fill 443 249 624 445 251 624 minecraft:green_terracotta
fill 443 249 630 445 251 630 minecraft:lime_terracotta
fill 443 249 637 445 256 637 minecraft:lime_terracotta
fill 443 249 646 443 250 646 minecraft:light_gray_concrete
fill 444 249 646 445 307 646 minecraft:white_concrete
setblock 446 249 604 minecraft:light_gray_concrete
fill 447 249 604 453 249 604 minecraft:white_concrete
fill 448 249 618 450 256 618 minecraft:green_terracotta
fill 448 249 623 450 256 623 minecraft:green_terracotta
fill 448 249 631 450 256 631 minecraft:lime_terracotta
fill 448 249 636 450 256 636 minecraft:lime_terracotta
fill 451 249 619 451 257 622 minecraft:green_terracotta
fill 451 249 632 451 257 635 minecraft:lime_terracotta
fill 452 249 620 452 257 621 minecraft:green_terracotta
fill 452 249 633 452 257 634 minecraft:lime_terracotta
setblock 454 249 604 minecraft:light_gray_concrete
fill 455 249 604 461 249 604 minecraft:white_concrete
fill 465 249 605 465 255 609 minecraft:white_concrete
setblock 465 249 610 minecraft:light_gray_concrete
fill 465 249 611 465 307 612 minecraft:white_concrete
setblock 465 249 613 minecraft:light_gray_concrete
fill 465 249 614 465 307 615 minecraft:white_concrete
fill 465 249 618 465 307 618 minecraft:white_concrete
fill 465 249 619 465 250 619 minecraft:light_gray_concrete
fill 465 249 620 465 307 620 minecraft:white_concrete
fill 465 249 621 465 250 621 minecraft:light_gray_concrete
fill 465 249 622 465 249 633 minecraft:white_concrete
setblock 465 249 634 minecraft:light_gray_concrete
fill 465 249 635 465 307 638 minecraft:white_concrete
fill 465 249 640 465 307 640 minecraft:white_concrete
fill 423 250 604 423 255 612 minecraft:white_concrete
setblock 423 250 613 minecraft:light_gray_concrete
fill 423 250 614 423 307 616 minecraft:white_concrete
fill 423 250 621 423 307 621 minecraft:white_concrete
fill 423 250 627 423 307 628 minecraft:white_concrete
fill 423 250 632 423 307 632 minecraft:white_concrete
setblock 426 250 607 minecraft:light[level=13]
setblock 426 250 615 minecraft:light[level=13]
schedule function dropper:buildpart/153_2 1t
