setblock 274 209 470 minecraft:brown_terracotta
fill 275 209 464 275 212 464 minecraft:brown_terracotta
setblock 275 209 468 minecraft:bone_block
fill 275 209 469 275 211 469 minecraft:brown_terracotta
setblock 275 209 473 minecraft:bone_block
fill 275 209 474 275 212 474 minecraft:brown_terracotta
setblock 276 209 467 minecraft:bone_block
fill 276 209 468 276 212 468 minecraft:brown_terracotta
setblock 276 209 472 minecraft:bone_block
fill 276 209 473 276 212 473 minecraft:brown_terracotta
setblock 276 209 476 minecraft:brown_terracotta
setblock 276 209 492 minecraft:bone_block
fill 276 209 493 276 209 496 minecraft:brown_terracotta
setblock 276 209 497 minecraft:bone_block
fill 276 209 498 276 211 499 minecraft:brown_terracotta
fill 277 209 464 277 210 469 minecraft:soul_soil
fill 277 209 471 277 307 474 minecraft:soul_soil
fill 277 209 476 277 209 480 minecraft:soul_soil
fill 277 209 482 277 209 488 minecraft:soul_soil
setblock 277 209 489 minecraft:brown_terracotta
fill 277 209 490 277 210 504 minecraft:soul_soil
fill 235 210 464 235 307 464 minecraft:soul_soil
fill 235 210 471 235 307 471 minecraft:soul_soil
fill 235 210 473 235 307 473 minecraft:soul_soil
fill 235 210 478 235 210 481 minecraft:soul_soil
fill 235 210 482 235 210 483 minecraft:brown_terracotta
fill 235 210 484 235 307 484 minecraft:soul_soil
fill 235 210 489 235 210 500 minecraft:soul_soil
setblock 235 210 501 minecraft:brown_terracotta
fill 235 210 502 235 307 505 minecraft:soul_soil
setblock 236 210 471 minecraft:bone_block
fill 236 210 472 236 211 472 minecraft:brown_terracotta
fill 236 210 474 236 211 474 minecraft:brown_terracotta
setblock 236 210 491 minecraft:bone_block
fill 236 210 492 236 213 492 minecraft:brown_terracotta
setblock 236 210 496 minecraft:bone_block
fill 236 210 497 236 213 497 minecraft:brown_terracotta
fill 236 210 499 236 210 500 minecraft:brown_terracotta
setblock 236 210 501 minecraft:bone_block
fill 236 210 502 236 212 503 minecraft:brown_terracotta
fill 236 210 505 238 307 505 minecraft:soul_soil
setblock 237 210 495 minecraft:bone_block
fill 237 210 496 238 212 496 minecraft:brown_terracotta
setblock 237 210 499 minecraft:brown_terracotta
setblock 237 210 500 minecraft:bone_block
setblock 238 210 494 minecraft:bone_block
fill 238 210 495 238 213 495 minecraft:brown_terracotta
setblock 239 210 505 minecraft:brown_terracotta
fill 240 210 504 240 212 504 minecraft:brown_terracotta
fill 240 210 505 241 210 505 minecraft:soul_soil
setblock 242 210 505 minecraft:brown_terracotta
setblock 243 210 503 minecraft:brown_terracotta
setblock 243 210 504 minecraft:bone_block
fill 243 210 505 249 210 505 minecraft:soul_soil
fill 244 210 463 244 307 463 minecraft:soul_soil
setblock 244 210 503 minecraft:bone_block
fill 244 210 504 244 213 504 minecraft:brown_terracotta
fill 245 210 503 245 213 503 minecraft:brown_terracotta
fill 247 210 503 247 211 503 minecraft:brown_terracotta
setblock 248 210 464 minecraft:bone_block
setblock 248 210 504 minecraft:bone_block
fill 249 210 463 250 307 463 minecraft:soul_soil
fill 249 210 504 249 213 504 minecraft:brown_terracotta
setblock 250 210 505 minecraft:brown_terracotta
setblock 251 210 463 minecraft:brown_terracotta
fill 251 210 505 254 210 505 minecraft:soul_soil
fill 252 210 463 253 307 463 minecraft:soul_soil
setblock 254 210 463 minecraft:brown_terracotta
fill 255 210 463 255 307 463 minecraft:soul_soil
setblock 255 210 505 minecraft:brown_terracotta
fill 256 210 505 260 210 505 minecraft:soul_soil
fill 261 210 505 261 211 505 minecraft:brown_terracotta
setblock 262 210 464 minecraft:brown_terracotta
fill 262 210 505 264 307 505 minecraft:soul_soil
setblock 263 210 464 minecraft:bone_block
fill 263 210 465 263 213 465 minecraft:brown_terracotta
fill 264 210 464 264 213 464 minecraft:brown_terracotta
fill 265 210 504 265 211 505 minecraft:brown_terracotta
setblock 266 210 465 minecraft:brown_terracotta
setblock 266 210 466 minecraft:bone_block
fill 266 210 505 270 307 505 minecraft:soul_soil
setblock 267 210 465 minecraft:bone_block
fill 267 210 466 267 213 466 minecraft:brown_terracotta
setblock 267 210 504 minecraft:brown_terracotta
fill 268 210 463 268 307 463 minecraft:soul_soil
setblock 268 210 464 minecraft:bone_block
fill 268 210 465 268 213 465 minecraft:brown_terracotta
setblock 268 210 504 minecraft:bone_block
fill 269 210 464 269 213 464 minecraft:brown_terracotta
fill 269 210 504 270 212 504 minecraft:brown_terracotta
fill 270 210 463 270 307 463 minecraft:soul_soil
setblock 271 210 466 minecraft:bone_block
setblock 272 210 465 minecraft:bone_block
fill 272 210 505 272 307 505 minecraft:soul_soil
setblock 273 210 464 minecraft:bone_block
setblock 273 210 465 minecraft:brown_terracotta
setblock 273 210 504 minecraft:bone_block
setblock 273 210 505 minecraft:brown_terracotta
fill 274 210 464 274 212 464 minecraft:brown_terracotta
fill 274 210 504 274 213 504 minecraft:brown_terracotta
fill 274 210 505 274 307 505 minecraft:soul_soil
setblock 275 210 467 minecraft:bone_block
setblock 275 210 468 minecraft:brown_terracotta
setblock 275 210 472 minecraft:bone_block
fill 275 210 473 275 212 473 minecraft:brown_terracotta
setblock 275 210 475 minecraft:brown_terracotta
setblock 275 210 505 minecraft:brown_terracotta
setblock 276 210 466 minecraft:bone_block
fill 276 210 467 276 212 467 minecraft:brown_terracotta
setblock 276 210 471 minecraft:bone_block
fill 276 210 472 276 213 472 minecraft:brown_terracotta
setblock 276 210 476 minecraft:bone_block
fill 276 210 492 276 210 495 minecraft:brown_terracotta
setblock 276 210 496 minecraft:bone_block
fill 276 210 497 276 213 497 minecraft:brown_terracotta
setblock 276 210 500 minecraft:brown_terracotta
setblock 276 210 501 minecraft:bone_block
fill 276 210 502 276 213 502 minecraft:brown_terracotta
fill 276 210 505 277 307 505 minecraft:soul_soil
fill 277 210 470 277 307 470 minecraft:soul_soil
fill 277 210 475 277 210 478 minecraft:soul_soil
setblock 277 210 479 minecraft:brown_terracotta
fill 277 210 480 277 307 480 minecraft:soul_soil
fill 277 210 482 277 307 485 minecraft:soul_soil
fill 277 210 486 277 211 486 minecraft:brown_terracotta
fill 277 210 487 277 307 489 minecraft:soul_soil
fill 235 211 478 235 307 478 minecraft:soul_soil
setblock 235 211 479 minecraft:brown_terracotta
fill 235 211 480 235 307 483 minecraft:soul_soil
fill 235 211 489 235 307 499 minecraft:soul_soil
setblock 235 211 500 minecraft:brown_terracotta
fill 235 211 501 235 307 501 minecraft:soul_soil
setblock 236 211 471 minecraft:brown_terracotta
setblock 236 211 490 minecraft:bone_block
fill 236 211 491 236 214 491 minecraft:brown_terracotta
setblock 236 211 495 minecraft:bone_block
fill 236 211 496 236 214 496 minecraft:brown_terracotta
setblock 236 211 499 minecraft:brown_terracotta
setblock 236 211 500 minecraft:bone_block
fill 236 211 501 237 213 501 minecraft:brown_terracotta
setblock 236 211 504 minecraft:brown_terracotta
setblock 237 211 494 minecraft:bone_block
fill 237 211 495 237 214 495 minecraft:brown_terracotta
setblock 237 211 499 minecraft:bone_block
fill 237 211 500 237 214 500 minecraft:brown_terracotta
setblock 237 211 504 minecraft:bone_block
setblock 238 211 466 minecraft:light[level=12]
setblock 238 211 474 minecraft:light[level=12]
setblock 238 211 482 minecraft:light[level=12]
setblock 238 211 490 minecraft:light[level=12]
fill 238 211 494 238 213 494 minecraft:brown_terracotta
setblock 238 211 497 minecraft:brown_terracotta
setblock 238 211 498 minecraft:bone_block
fill 238 211 504 239 213 504 minecraft:brown_terracotta
fill 239 211 505 240 307 505 minecraft:soul_soil
fill 241 211 504 241 211 505 minecraft:brown_terracotta
setblock 242 211 503 minecraft:brown_terracotta
setblock 242 211 504 minecraft:bone_block
fill 242 211 505 244 307 505 minecraft:soul_soil
setblock 243 211 503 minecraft:bone_block
fill 243 211 504 243 214 504 minecraft:brown_terracotta
setblock 244 211 464 minecraft:brown_terracotta
fill 244 211 503 244 214 503 minecraft:brown_terracotta
setblock 245 211 505 minecraft:brown_terracotta
setblock 246 211 466 minecraft:light[level=12]
setblock 246 211 474 minecraft:light[level=12]
setblock 246 211 482 minecraft:light[level=12]
setblock 246 211 490 minecraft:light[level=12]
setblock 246 211 498 minecraft:light[level=12]
fill 246 211 505 251 307 505 minecraft:soul_soil
setblock 247 211 464 minecraft:bone_block
setblock 247 211 504 minecraft:bone_block
setblock 248 211 503 minecraft:bone_block
fill 248 211 504 248 214 504 minecraft:brown_terracotta
fill 251 211 463 251 307 463 minecraft:soul_soil
setblock 252 211 505 minecraft:brown_terracotta
fill 253 211 505 256 307 505 minecraft:soul_soil
fill 254 211 463 254 307 463 minecraft:soul_soil
setblock 254 211 466 minecraft:light[level=12]
setblock 254 211 474 minecraft:light[level=12]
setblock 254 211 482 minecraft:light[level=12]
setblock 254 211 490 minecraft:light[level=12]
setblock 254 211 498 minecraft:light[level=12]
fill 256 211 463 258 307 463 minecraft:soul_soil
setblock 257 211 505 minecraft:brown_terracotta
fill 258 211 505 259 307 505 minecraft:soul_soil
fill 259 211 463 260 211 463 minecraft:brown_terracotta
setblock 260 211 505 minecraft:brown_terracotta
fill 261 211 463 265 307 463 minecraft:soul_soil
setblock 261 211 464 minecraft:brown_terracotta
setblock 262 211 464 minecraft:bone_block
setblock 262 211 466 minecraft:light[level=12]
setblock 262 211 474 minecraft:light[level=12]
setblock 262 211 482 minecraft:light[level=12]
setblock 262 211 490 minecraft:light[level=12]
setblock 262 211 498 minecraft:light[level=12]
fill 263 211 464 263 214 464 minecraft:brown_terracotta
setblock 264 211 466 minecraft:brown_terracotta
fill 264 211 504 264 213 504 minecraft:brown_terracotta
setblock 265 211 466 minecraft:bone_block
setblock 266 211 463 minecraft:brown_terracotta
setblock 266 211 465 minecraft:bone_block
fill 266 211 466 266 213 466 minecraft:brown_terracotta
fill 266 211 503 267 211 503 minecraft:brown_terracotta
fill 267 211 463 267 307 463 minecraft:soul_soil
setblock 267 211 464 minecraft:bone_block
fill 267 211 465 267 214 465 minecraft:brown_terracotta
setblock 267 211 504 minecraft:bone_block
fill 268 211 464 268 214 464 minecraft:brown_terracotta
setblock 268 211 503 minecraft:bone_block
fill 268 211 504 268 214 504 minecraft:brown_terracotta
fill 269 211 503 270 213 503 minecraft:brown_terracotta
setblock 270 211 466 minecraft:bone_block
setblock 270 211 474 minecraft:light[level=12]
setblock 270 211 482 minecraft:light[level=12]
setblock 270 211 490 minecraft:light[level=12]
setblock 270 211 498 minecraft:light[level=12]
setblock 271 211 465 minecraft:bone_block
setblock 272 211 464 minecraft:bone_block
setblock 272 211 465 minecraft:brown_terracotta
setblock 272 211 504 minecraft:bone_block
fill 273 211 464 273 213 464 minecraft:brown_terracotta
fill 273 211 504 273 214 504 minecraft:brown_terracotta
fill 273 211 505 273 307 505 minecraft:soul_soil
setblock 275 211 471 minecraft:bone_block
fill 275 211 472 275 212 472 minecraft:brown_terracotta
setblock 275 211 496 minecraft:bone_block
fill 275 211 497 275 213 498 minecraft:brown_terracotta
fill 275 211 504 276 211 504 minecraft:brown_terracotta
fill 275 211 505 275 307 505 minecraft:soul_soil
setblock 276 211 465 minecraft:bone_block
setblock 276 211 466 minecraft:brown_terracotta
setblock 276 211 470 minecraft:bone_block
fill 276 211 471 276 213 471 minecraft:brown_terracotta
setblock 276 211 475 minecraft:bone_block
fill 276 211 476 276 213 477 minecraft:brown_terracotta
fill 276 211 492 276 211 494 minecraft:brown_terracotta
setblock 276 211 495 minecraft:bone_block
fill 276 211 496 276 214 496 minecraft:brown_terracotta
setblock 276 211 500 minecraft:bone_block
fill 276 211 501 277 211 501 minecraft:brown_terracotta
fill 276 211 503 276 212 503 minecraft:brown_terracotta
fill 277 211 464 277 307 464 minecraft:soul_soil
setblock 277 211 465 minecraft:brown_terracotta
fill 277 211 466 277 307 469 minecraft:soul_soil
fill 277 211 475 277 307 476 minecraft:soul_soil
fill 277 211 477 277 211 478 minecraft:brown_terracotta
fill 277 211 479 277 307 479 minecraft:soul_soil
fill 277 211 481 277 307 481 minecraft:soul_soil
fill 277 211 490 277 307 496 minecraft:soul_soil
setblock 277 211 497 minecraft:brown_terracotta
fill 277 211 498 277 307 500 minecraft:soul_soil
fill 277 211 502 277 307 504 minecraft:soul_soil
fill 235 212 479 235 307 479 minecraft:soul_soil
fill 235 212 500 235 307 500 minecraft:soul_soil
setblock 236 212 474 minecraft:bone_block
fill 236 212 490 236 213 490 minecraft:brown_terracotta
setblock 236 212 493 minecraft:brown_terracotta
setblock 236 212 494 minecraft:bone_block
fill 236 212 495 236 215 495 minecraft:brown_terracotta
setblock 236 212 498 minecraft:brown_terracotta
setblock 236 212 499 minecraft:bone_block
fill 236 212 500 236 215 500 minecraft:brown_terracotta
setblock 236 212 504 minecraft:bone_block
setblock 237 212 493 minecraft:bone_block
fill 237 212 494 237 215 494 minecraft:brown_terracotta
setblock 237 212 498 minecraft:bone_block
fill 237 212 499 238 214 499 minecraft:brown_terracotta
fill 237 212 504 237 215 504 minecraft:brown_terracotta
setblock 238 212 497 minecraft:bone_block
fill 238 212 498 238 215 498 minecraft:brown_terracotta
setblock 241 212 503 minecraft:brown_terracotta
setblock 241 212 504 minecraft:bone_block
fill 241 212 505 241 307 505 minecraft:soul_soil
setblock 242 212 503 minecraft:bone_block
fill 242 212 504 242 215 504 minecraft:brown_terracotta
fill 243 212 503 243 215 503 minecraft:brown_terracotta
fill 244 212 502 245 214 502 minecraft:brown_terracotta
fill 245 212 505 245 307 505 minecraft:soul_soil
setblock 246 212 464 minecraft:bone_block
setblock 246 212 504 minecraft:bone_block
setblock 247 212 503 minecraft:bone_block
fill 247 212 504 247 215 504 minecraft:brown_terracotta
setblock 248 212 503 minecraft:brown_terracotta
fill 252 212 505 252 307 505 minecraft:soul_soil
fill 257 212 505 257 307 505 minecraft:soul_soil
fill 259 212 463 260 307 463 minecraft:soul_soil
fill 260 212 505 261 307 505 minecraft:soul_soil
setblock 261 212 464 minecraft:bone_block
fill 262 212 464 262 215 464 minecraft:brown_terracotta
fill 263 212 504 263 214 504 minecraft:brown_terracotta
setblock 264 212 466 minecraft:bone_block
setblock 265 212 465 minecraft:bone_block
fill 265 212 466 265 213 466 minecraft:brown_terracotta
fill 265 212 503 265 212 504 minecraft:brown_terracotta
fill 265 212 505 265 307 505 minecraft:soul_soil
fill 266 212 463 266 307 463 minecraft:soul_soil
setblock 266 212 464 minecraft:bone_block
fill 266 212 465 266 215 465 minecraft:brown_terracotta
setblock 266 212 503 minecraft:brown_terracotta
setblock 266 212 504 minecraft:bone_block
fill 267 212 464 267 215 464 minecraft:brown_terracotta
setblock 267 212 503 minecraft:bone_block
fill 267 212 504 267 215 504 minecraft:brown_terracotta
fill 268 212 503 268 215 503 minecraft:brown_terracotta
setblock 269 212 466 minecraft:bone_block
setblock 270 212 465 minecraft:bone_block
setblock 271 212 464 minecraft:bone_block
setblock 271 212 465 minecraft:brown_terracotta
setblock 271 212 504 minecraft:bone_block
fill 272 212 464 272 214 464 minecraft:brown_terracotta
fill 272 212 504 272 215 504 minecraft:brown_terracotta
setblock 275 212 471 minecraft:brown_terracotta
setblock 275 212 496 minecraft:brown_terracotta
setblock 275 212 499 minecraft:brown_terracotta
setblock 275 212 504 minecraft:brown_terracotta
setblock 276 212 469 minecraft:bone_block
fill 276 212 470 276 213 470 minecraft:brown_terracotta
setblock 276 212 474 minecraft:bone_block
fill 276 212 475 276 214 475 minecraft:brown_terracotta
setblock 276 212 493 minecraft:brown_terracotta
setblock 276 212 494 minecraft:bone_block
fill 276 212 495 276 215 495 minecraft:brown_terracotta
setblock 276 212 498 minecraft:brown_terracotta
setblock 276 212 499 minecraft:bone_block
fill 276 212 500 276 214 501 minecraft:brown_terracotta
setblock 276 212 504 minecraft:bone_block
fill 277 212 465 277 307 465 minecraft:soul_soil
fill 277 212 477 277 307 478 minecraft:soul_soil
fill 277 212 486 277 307 486 minecraft:soul_soil
fill 277 212 497 277 307 497 minecraft:soul_soil
fill 277 212 501 277 307 501 minecraft:soul_soil
setblock 236 213 493 minecraft:bone_block
fill 236 213 494 236 216 494 minecraft:brown_terracotta
setblock 236 213 498 minecraft:bone_block
fill 236 213 499 236 216 499 minecraft:brown_terracotta
setblock 236 213 502 minecraft:brown_terracotta
setblock 236 213 503 minecraft:bone_block
fill 236 213 504 236 216 504 minecraft:brown_terracotta
setblock 237 213 492 minecraft:bone_block
fill 237 213 493 237 215 493 minecraft:brown_terracotta
setblock 237 213 496 minecraft:brown_terracotta
setblock 237 213 497 minecraft:bone_block
fill 237 213 498 237 216 498 minecraft:brown_terracotta
setblock 237 213 502 minecraft:bone_block
setblock 238 213 496 minecraft:bone_block
fill 238 213 497 238 216 497 minecraft:brown_terracotta
setblock 240 213 503 minecraft:brown_terracotta
setblock 240 213 504 minecraft:bone_block
setblock 241 213 503 minecraft:bone_block
fill 241 213 504 241 216 504 minecraft:brown_terracotta
setblock 242 213 502 minecraft:bone_block
fill 242 213 503 242 216 503 minecraft:brown_terracotta
fill 243 213 502 243 216 502 minecraft:brown_terracotta
setblock 245 213 504 minecraft:bone_block
setblock 246 213 503 minecraft:bone_block
fill 246 213 504 246 216 504 minecraft:brown_terracotta
fill 247 213 503 247 214 503 minecraft:brown_terracotta
fill 261 213 464 261 216 464 minecraft:brown_terracotta
fill 262 213 504 262 215 504 minecraft:brown_terracotta
setblock 264 213 465 minecraft:bone_block
fill 264 213 503 265 213 503 minecraft:brown_terracotta
setblock 265 213 464 minecraft:bone_block
fill 265 213 465 265 216 465 minecraft:brown_terracotta
setblock 265 213 504 minecraft:bone_block
fill 266 213 464 266 216 464 minecraft:brown_terracotta
setblock 266 213 503 minecraft:bone_block
fill 266 213 504 266 216 504 minecraft:brown_terracotta
fill 267 213 503 267 216 503 minecraft:brown_terracotta
setblock 269 213 465 minecraft:bone_block
setblock 269 213 504 minecraft:brown_terracotta
setblock 270 213 464 minecraft:bone_block
setblock 270 213 465 minecraft:brown_terracotta
setblock 270 213 504 minecraft:bone_block
fill 271 213 464 271 215 464 minecraft:brown_terracotta
fill 271 213 504 271 216 504 minecraft:brown_terracotta
setblock 275 213 499 minecraft:bone_block
fill 275 213 500 275 216 500 minecraft:brown_terracotta
setblock 275 213 504 minecraft:bone_block
setblock 276 213 469 minecraft:brown_terracotta
setblock 276 213 473 minecraft:bone_block
fill 276 213 474 276 214 474 minecraft:brown_terracotta
setblock 276 213 493 minecraft:bone_block
fill 276 213 494 276 215 494 minecraft:brown_terracotta
setblock 276 213 498 minecraft:bone_block
fill 276 213 499 276 216 499 minecraft:brown_terracotta
setblock 276 213 503 minecraft:bone_block
fill 276 213 504 276 216 504 minecraft:brown_terracotta
setblock 236 214 492 minecraft:bone_block
fill 236 214 493 236 217 493 minecraft:brown_terracotta
setblock 236 214 497 minecraft:bone_block
fill 236 214 498 236 217 498 minecraft:brown_terracotta
setblock 236 214 501 minecraft:brown_terracotta
setblock 236 214 502 minecraft:bone_block
fill 236 214 503 236 217 503 minecraft:brown_terracotta
setblock 237 214 496 minecraft:bone_block
fill 237 214 497 237 217 497 minecraft:brown_terracotta
setblock 237 214 501 minecraft:bone_block
fill 237 214 502 237 217 502 minecraft:brown_terracotta
setblock 238 214 495 minecraft:bone_block
fill 238 214 496 238 216 496 minecraft:brown_terracotta
setblock 238 214 500 minecraft:bone_block
setblock 238 214 504 minecraft:brown_terracotta
setblock 239 214 503 minecraft:brown_terracotta
setblock 239 214 504 minecraft:bone_block
setblock 240 214 503 minecraft:bone_block
fill 240 214 504 240 217 504 minecraft:brown_terracotta
fill 241 214 503 241 217 503 minecraft:brown_terracotta
fill 242 214 502 242 217 502 minecraft:brown_terracotta
setblock 244 214 504 minecraft:bone_block
setblock 245 214 503 minecraft:bone_block
fill 245 214 504 245 217 504 minecraft:brown_terracotta
fill 246 214 503 246 215 503 minecraft:brown_terracotta
fill 260 214 464 260 217 464 minecraft:brown_terracotta
fill 261 214 504 261 216 504 minecraft:brown_terracotta
setblock 262 214 465 minecraft:brown_terracotta
setblock 263 214 465 minecraft:bone_block
fill 263 214 503 264 214 503 minecraft:brown_terracotta
setblock 264 214 464 minecraft:bone_block
fill 264 214 465 264 217 465 minecraft:brown_terracotta
setblock 264 214 504 minecraft:bone_block
fill 265 214 464 265 217 464 minecraft:brown_terracotta
setblock 265 214 503 minecraft:bone_block
fill 265 214 504 265 217 504 minecraft:brown_terracotta
fill 266 214 503 266 217 503 minecraft:brown_terracotta
setblock 268 214 465 minecraft:bone_block
setblock 269 214 464 minecraft:bone_block
setblock 269 214 465 minecraft:brown_terracotta
setblock 269 214 503 minecraft:brown_terracotta
setblock 269 214 504 minecraft:bone_block
fill 270 214 464 270 217 464 minecraft:brown_terracotta
setblock 270 214 503 minecraft:bone_block
fill 270 214 504 270 217 504 minecraft:brown_terracotta
setblock 274 214 504 minecraft:bone_block
setblock 275 214 497 minecraft:brown_terracotta
setblock 275 214 498 minecraft:bone_block
fill 275 214 499 275 217 499 minecraft:brown_terracotta
fill 275 214 504 275 217 504 minecraft:brown_terracotta
setblock 276 214 472 minecraft:bone_block
setblock 276 214 473 minecraft:brown_terracotta
setblock 276 214 476 minecraft:brown_terracotta
setblock 276 214 497 minecraft:bone_block
fill 276 214 498 276 217 498 minecraft:brown_terracotta
setblock 276 214 502 minecraft:bone_block
fill 276 214 503 276 217 503 minecraft:brown_terracotta
fill 236 215 492 236 216 492 minecraft:brown_terracotta
setblock 236 215 496 minecraft:bone_block
fill 236 215 497 236 218 497 minecraft:brown_terracotta
setblock 236 215 501 minecraft:bone_block
fill 236 215 502 236 218 502 minecraft:brown_terracotta
setblock 237 215 495 minecraft:bone_block
fill 237 215 496 237 218 496 minecraft:brown_terracotta
setblock 237 215 499 minecraft:brown_terracotta
setblock 237 215 500 minecraft:bone_block
fill 237 215 501 237 218 501 minecraft:brown_terracotta
setblock 238 215 499 minecraft:bone_block
fill 238 215 500 238 218 500 minecraft:brown_terracotta
setblock 238 215 504 minecraft:bone_block
setblock 239 215 503 minecraft:bone_block
fill 239 215 504 239 218 504 minecraft:brown_terracotta
fill 240 215 503 240 218 503 minecraft:brown_terracotta
fill 241 215 502 241 218 502 minecraft:brown_terracotta
setblock 243 215 504 minecraft:bone_block
setblock 244 215 502 minecraft:brown_terracotta
setblock 244 215 503 minecraft:bone_block
fill 244 215 504 244 218 504 minecraft:brown_terracotta
fill 245 215 503 245 218 503 minecraft:brown_terracotta
setblock 248 215 504 minecraft:bone_block
setblock 262 215 465 minecraft:bone_block
setblock 263 215 464 minecraft:bone_block
fill 263 215 465 263 218 465 minecraft:brown_terracotta
setblock 263 215 503 minecraft:brown_terracotta
setblock 263 215 504 minecraft:bone_block
fill 264 215 464 264 218 464 minecraft:brown_terracotta
setblock 264 215 503 minecraft:bone_block
fill 264 215 504 264 218 504 minecraft:brown_terracotta
fill 265 215 503 265 218 503 minecraft:brown_terracotta
setblock 267 215 465 minecraft:bone_block
setblock 268 215 464 minecraft:bone_block
setblock 268 215 465 minecraft:brown_terracotta
setblock 268 215 504 minecraft:bone_block
fill 269 215 464 269 218 464 minecraft:brown_terracotta
setblock 269 215 503 minecraft:bone_block
fill 269 215 504 269 218 504 minecraft:brown_terracotta
setblock 273 215 504 minecraft:bone_block
fill 274 215 504 274 218 504 minecraft:brown_terracotta
setblock 275 215 498 minecraft:brown_terracotta
setblock 276 215 496 minecraft:bone_block
fill 276 215 497 276 218 497 minecraft:brown_terracotta
setblock 276 215 500 minecraft:brown_terracotta
setblock 276 215 501 minecraft:bone_block
fill 276 215 502 276 218 502 minecraft:brown_terracotta
setblock 236 216 495 minecraft:bone_block
fill 236 216 496 236 219 496 minecraft:brown_terracotta
setblock 236 216 500 minecraft:bone_block
fill 236 216 501 236 219 501 minecraft:brown_terracotta
setblock 237 216 494 minecraft:bone_block
fill 237 216 495 237 219 495 minecraft:brown_terracotta
setblock 237 216 499 minecraft:bone_block
fill 237 216 500 237 219 500 minecraft:brown_terracotta
setblock 237 216 504 minecraft:bone_block
setblock 238 216 498 minecraft:bone_block
fill 238 216 499 238 219 499 minecraft:brown_terracotta
setblock 238 216 503 minecraft:bone_block
fill 238 216 504 238 219 504 minecraft:brown_terracotta
fill 239 216 503 239 219 503 minecraft:brown_terracotta
setblock 242 216 504 minecraft:bone_block
setblock 243 216 503 minecraft:bone_block
fill 243 216 504 243 219 504 minecraft:brown_terracotta
fill 244 216 503 244 219 503 minecraft:brown_terracotta
setblock 247 216 504 minecraft:bone_block
fill 260 216 504 260 217 504 minecraft:brown_terracotta
setblock 262 216 464 minecraft:bone_block
fill 262 216 465 262 219 465 minecraft:brown_terracotta
setblock 262 216 503 minecraft:brown_terracotta
setblock 262 216 504 minecraft:bone_block
fill 263 216 464 263 219 464 minecraft:brown_terracotta
setblock 263 216 503 minecraft:bone_block
fill 263 216 504 263 219 504 minecraft:brown_terracotta
fill 264 216 503 264 219 503 minecraft:brown_terracotta
setblock 266 216 465 minecraft:bone_block
setblock 267 216 464 minecraft:bone_block
setblock 267 216 465 minecraft:brown_terracotta
setblock 267 216 504 minecraft:bone_block
fill 268 216 464 268 219 464 minecraft:brown_terracotta
setblock 268 216 503 minecraft:bone_block
fill 268 216 504 268 219 504 minecraft:brown_terracotta
fill 269 216 503 269 219 503 minecraft:brown_terracotta
setblock 272 216 504 minecraft:bone_block
fill 273 216 504 273 219 504 minecraft:brown_terracotta
setblock 275 216 501 minecraft:bone_block
setblock 276 216 495 minecraft:bone_block
fill 276 216 496 276 219 496 minecraft:brown_terracotta
setblock 276 216 500 minecraft:bone_block
fill 276 216 501 276 219 501 minecraft:brown_terracotta
setblock 236 217 494 minecraft:bone_block
fill 236 217 495 236 220 495 minecraft:brown_terracotta
setblock 236 217 499 minecraft:bone_block
fill 236 217 500 236 220 500 minecraft:brown_terracotta
setblock 236 217 504 minecraft:bone_block
setblock 237 217 498 minecraft:bone_block
fill 237 217 499 237 220 499 minecraft:brown_terracotta
fill 237 217 504 237 220 504 minecraft:brown_terracotta
setblock 238 217 497 minecraft:bone_block
fill 238 217 498 238 220 498 minecraft:brown_terracotta
fill 238 217 503 238 220 503 minecraft:brown_terracotta
setblock 241 217 504 minecraft:bone_block
setblock 242 217 503 minecraft:bone_block
fill 242 217 504 242 220 504 minecraft:brown_terracotta
fill 243 217 503 243 220 503 minecraft:brown_terracotta
setblock 246 217 504 minecraft:bone_block
fill 259 217 464 259 218 464 minecraft:brown_terracotta
setblock 261 217 464 minecraft:bone_block
setblock 261 217 504 minecraft:bone_block
fill 262 217 464 262 220 464 minecraft:brown_terracotta
setblock 262 217 503 minecraft:bone_block
fill 262 217 504 262 220 504 minecraft:brown_terracotta
fill 263 217 503 263 220 503 minecraft:brown_terracotta
setblock 265 217 465 minecraft:bone_block
setblock 266 217 464 minecraft:bone_block
setblock 266 217 465 minecraft:brown_terracotta
setblock 266 217 504 minecraft:bone_block
fill 267 217 464 267 220 464 minecraft:brown_terracotta
setblock 267 217 503 minecraft:bone_block
fill 267 217 504 267 220 504 minecraft:brown_terracotta
fill 268 217 503 268 220 503 minecraft:brown_terracotta
setblock 271 217 504 minecraft:bone_block
fill 272 217 504 272 220 504 minecraft:brown_terracotta
setblock 275 217 500 minecraft:bone_block
fill 275 217 501 275 220 501 minecraft:brown_terracotta
setblock 276 217 495 minecraft:brown_terracotta
setblock 276 217 499 minecraft:bone_block
fill 276 217 500 276 220 500 minecraft:brown_terracotta
setblock 276 217 504 minecraft:bone_block
fill 236 218 479 236 219 481 minecraft:brown_terracotta
setblock 236 218 493 minecraft:bone_block
fill 236 218 494 236 221 494 minecraft:brown_terracotta
setblock 236 218 498 minecraft:bone_block
fill 236 218 499 236 221 499 minecraft:brown_terracotta
setblock 236 218 503 minecraft:bone_block
fill 236 218 504 236 221 504 minecraft:brown_terracotta
setblock 237 218 497 minecraft:bone_block
fill 237 218 498 237 221 498 minecraft:brown_terracotta
setblock 237 218 502 minecraft:bone_block
fill 237 218 503 237 221 503 minecraft:brown_terracotta
fill 240 218 502 240 219 502 minecraft:brown_terracotta
setblock 240 218 504 minecraft:bone_block
setblock 241 218 503 minecraft:bone_block
fill 241 218 504 241 221 504 minecraft:brown_terracotta
setblock 242 218 502 minecraft:bone_block
fill 242 218 503 242 221 503 minecraft:brown_terracotta
setblock 245 218 504 minecraft:bone_block
fill 246 218 504 246 221 504 minecraft:brown_terracotta
fill 255 218 498 256 219 498 minecraft:soul_soil
setblock 259 218 504 minecraft:brown_terracotta
setblock 260 218 464 minecraft:bone_block
setblock 260 218 504 minecraft:bone_block
fill 261 218 464 261 220 465 minecraft:brown_terracotta
setblock 261 218 503 minecraft:bone_block
fill 261 218 504 261 221 504 minecraft:brown_terracotta
fill 262 218 503 262 221 503 minecraft:brown_terracotta
setblock 264 218 465 minecraft:bone_block
setblock 265 218 464 minecraft:bone_block
fill 265 218 465 265 221 465 minecraft:brown_terracotta
setblock 265 218 504 minecraft:bone_block
fill 266 218 464 266 221 464 minecraft:brown_terracotta
setblock 266 218 503 minecraft:bone_block
fill 266 218 504 266 221 504 minecraft:brown_terracotta
fill 267 218 503 267 221 503 minecraft:brown_terracotta
setblock 270 218 504 minecraft:bone_block
fill 271 218 504 271 221 504 minecraft:brown_terracotta
setblock 275 218 499 minecraft:bone_block
fill 275 218 500 275 221 500 minecraft:brown_terracotta
fill 275 218 502 275 218 503 minecraft:brown_terracotta
setblock 275 218 504 minecraft:bone_block
setblock 276 218 498 minecraft:bone_block
fill 276 218 499 276 221 499 minecraft:brown_terracotta
setblock 276 218 503 minecraft:bone_block
fill 276 218 504 276 221 504 minecraft:brown_terracotta
fill 236 219 478 236 222 478 minecraft:brown_terracotta
setblock 236 219 482 minecraft:bone_block
fill 236 219 483 236 221 484 minecraft:brown_terracotta
fill 236 219 493 236 222 493 minecraft:brown_terracotta
setblock 236 219 497 minecraft:bone_block
fill 236 219 498 236 222 498 minecraft:brown_terracotta
setblock 236 219 502 minecraft:bone_block
fill 236 219 503 236 222 503 minecraft:brown_terracotta
setblock 237 219 496 minecraft:bone_block
fill 237 219 497 237 222 497 minecraft:brown_terracotta
setblock 237 219 501 minecraft:bone_block
fill 237 219 502 237 222 502 minecraft:brown_terracotta
setblock 238 219 466 minecraft:light[level=12]
setblock 238 219 474 minecraft:light[level=12]
setblock 238 219 482 minecraft:light[level=12]
setblock 238 219 490 minecraft:light[level=12]
setblock 238 219 500 minecraft:bone_block
fill 238 219 501 238 222 501 minecraft:brown_terracotta
fill 239 219 502 239 220 502 minecraft:brown_terracotta
setblock 239 219 504 minecraft:bone_block
setblock 240 219 503 minecraft:bone_block
fill 240 219 504 240 222 504 minecraft:brown_terracotta
setblock 241 219 502 minecraft:bone_block
fill 241 219 503 241 222 503 minecraft:brown_terracotta
fill 242 219 502 242 222 502 minecraft:brown_terracotta
setblock 244 219 504 minecraft:bone_block
fill 245 219 504 245 222 504 minecraft:brown_terracotta
setblock 246 219 466 minecraft:light[level=12]
setblock 246 219 474 minecraft:light[level=12]
setblock 246 219 482 minecraft:light[level=12]
setblock 246 219 490 minecraft:light[level=12]
setblock 246 219 498 minecraft:light[level=12]
setblock 254 219 466 minecraft:light[level=12]
setblock 254 219 474 minecraft:light[level=12]
setblock 254 219 482 minecraft:light[level=12]
setblock 254 219 490 minecraft:light[level=12]
setblock 254 219 498 minecraft:light[level=12]
fill 257 219 464 258 219 464 minecraft:brown_terracotta
setblock 258 219 504 minecraft:brown_terracotta
setblock 259 219 464 minecraft:bone_block
setblock 259 219 504 minecraft:bone_block
fill 260 219 464 260 221 465 minecraft:brown_terracotta
setblock 260 219 503 minecraft:bone_block
fill 260 219 504 260 222 504 minecraft:brown_terracotta
fill 261 219 503 261 222 503 minecraft:brown_terracotta
setblock 262 219 466 minecraft:light[level=12]
setblock 262 219 474 minecraft:light[level=12]
setblock 262 219 482 minecraft:light[level=12]
setblock 262 219 490 minecraft:light[level=12]
setblock 262 219 498 minecraft:light[level=12]
setblock 263 219 465 minecraft:bone_block
setblock 264 219 464 minecraft:bone_block
fill 264 219 465 264 222 465 minecraft:brown_terracotta
setblock 264 219 504 minecraft:bone_block
fill 265 219 464 265 222 464 minecraft:brown_terracotta
setblock 265 219 503 minecraft:bone_block
fill 265 219 504 265 222 504 minecraft:brown_terracotta
fill 266 219 465 266 220 465 minecraft:brown_terracotta
fill 266 219 503 266 222 503 minecraft:brown_terracotta
setblock 269 219 464 minecraft:bone_block
setblock 269 219 504 minecraft:bone_block
setblock 270 219 466 minecraft:light[level=12]
setblock 270 219 474 minecraft:light[level=12]
setblock 270 219 482 minecraft:light[level=12]
setblock 270 219 490 minecraft:light[level=12]
setblock 270 219 498 minecraft:light[level=12]
fill 270 219 504 270 222 504 minecraft:brown_terracotta
setblock 274 219 503 minecraft:brown_terracotta
setblock 274 219 504 minecraft:bone_block
fill 275 219 499 275 222 499 minecraft:brown_terracotta
setblock 275 219 502 minecraft:brown_terracotta
setblock 275 219 503 minecraft:bone_block
fill 275 219 504 275 222 504 minecraft:brown_terracotta
setblock 276 219 497 minecraft:bone_block
fill 276 219 498 276 222 498 minecraft:brown_terracotta
setblock 276 219 502 minecraft:bone_block
fill 276 219 503 276 222 503 minecraft:brown_terracotta
fill 236 220 477 236 223 477 minecraft:brown_terracotta
fill 236 220 479 236 220 480 minecraft:brown_terracotta
setblock 236 220 481 minecraft:bone_block
fill 236 220 482 237 222 482 minecraft:brown_terracotta
setblock 236 220 485 minecraft:brown_terracotta
setblock 236 220 486 minecraft:bone_block
fill 236 220 487 236 222 488 minecraft:brown_terracotta
fill 236 220 492 236 223 492 minecraft:brown_terracotta
setblock 236 220 496 minecraft:bone_block
fill 236 220 497 236 223 497 minecraft:brown_terracotta
setblock 236 220 501 minecraft:bone_block
fill 236 220 502 236 223 502 minecraft:brown_terracotta
setblock 237 220 479 minecraft:brown_terracotta
setblock 237 220 480 minecraft:bone_block
fill 237 220 481 237 223 481 minecraft:brown_terracotta
fill 237 220 483 237 220 484 minecraft:brown_terracotta
setblock 237 220 485 minecraft:bone_block
setblock 237 220 495 minecraft:bone_block
fill 237 220 496 237 223 496 minecraft:brown_terracotta
setblock 237 220 500 minecraft:bone_block
fill 237 220 501 237 223 501 minecraft:brown_terracotta
setblock 238 220 499 minecraft:bone_block
fill 238 220 500 238 223 500 minecraft:brown_terracotta
fill 238 220 502 238 221 502 minecraft:brown_terracotta
setblock 238 220 504 minecraft:bone_block
setblock 239 220 503 minecraft:bone_block
fill 239 220 504 239 223 504 minecraft:brown_terracotta
fill 240 220 464 242 220 464 minecraft:brown_terracotta
setblock 240 220 502 minecraft:bone_block
fill 240 220 503 240 223 503 minecraft:brown_terracotta
fill 241 220 502 241 223 502 minecraft:brown_terracotta
setblock 243 220 504 minecraft:bone_block
setblock 244 220 503 minecraft:bone_block
fill 244 220 504 244 223 504 minecraft:brown_terracotta
fill 256 220 464 257 220 464 minecraft:brown_terracotta
setblock 257 220 504 minecraft:brown_terracotta
setblock 258 220 464 minecraft:bone_block
setblock 258 220 504 minecraft:bone_block
fill 259 220 464 259 222 465 minecraft:brown_terracotta
setblock 259 220 503 minecraft:bone_block
fill 259 220 504 259 223 504 minecraft:brown_terracotta
fill 260 220 503 260 223 503 minecraft:brown_terracotta
setblock 262 220 465 minecraft:bone_block
fill 262 220 502 264 220 502 minecraft:brown_terracotta
setblock 263 220 464 minecraft:bone_block
fill 263 220 465 263 223 465 minecraft:brown_terracotta
setblock 263 220 504 minecraft:bone_block
fill 264 220 464 264 223 464 minecraft:brown_terracotta
setblock 264 220 503 minecraft:bone_block
fill 264 220 504 264 223 504 minecraft:brown_terracotta
fill 265 220 503 265 223 503 minecraft:brown_terracotta
setblock 268 220 464 minecraft:bone_block
setblock 268 220 504 minecraft:bone_block
fill 269 220 464 270 222 464 minecraft:brown_terracotta
setblock 269 220 503 minecraft:bone_block
fill 269 220 504 269 223 504 minecraft:brown_terracotta
fill 270 220 503 273 220 503 minecraft:brown_terracotta
setblock 273 220 504 minecraft:bone_block
setblock 274 220 503 minecraft:bone_block
fill 274 220 504 274 223 504 minecraft:brown_terracotta
setblock 275 220 502 minecraft:bone_block
fill 275 220 503 275 223 503 minecraft:brown_terracotta
fill 276 220 464 276 221 464 minecraft:brown_terracotta
setblock 276 220 495 minecraft:brown_terracotta
setblock 276 220 496 minecraft:bone_block
fill 276 220 497 276 223 497 minecraft:brown_terracotta
setblock 276 220 501 minecraft:bone_block
fill 276 220 502 276 223 502 minecraft:brown_terracotta
setblock 236 221 479 minecraft:brown_terracotta
setblock 236 221 480 minecraft:bone_block
fill 236 221 481 236 224 481 minecraft:brown_terracotta
setblock 236 221 485 minecraft:bone_block
fill 236 221 486 237 223 486 minecraft:brown_terracotta
setblock 236 221 489 minecraft:brown_terracotta
setblock 236 221 490 minecraft:bone_block
fill 236 221 491 236 224 491 minecraft:brown_terracotta
setblock 236 221 495 minecraft:bone_block
fill 236 221 496 236 224 496 minecraft:brown_terracotta
setblock 236 221 500 minecraft:bone_block
fill 236 221 501 236 224 501 minecraft:brown_terracotta
setblock 237 221 478 minecraft:brown_terracotta
setblock 237 221 479 minecraft:bone_block
fill 237 221 480 238 223 480 minecraft:brown_terracotta
setblock 237 221 483 minecraft:brown_terracotta
setblock 237 221 484 minecraft:bone_block
fill 237 221 485 238 223 485 minecraft:brown_terracotta
fill 237 221 487 237 221 488 minecraft:brown_terracotta
fill 237 221 495 237 224 495 minecraft:brown_terracotta
setblock 237 221 499 minecraft:bone_block
fill 237 221 500 237 224 500 minecraft:brown_terracotta
setblock 237 221 504 minecraft:bone_block
fill 238 221 464 241 221 464 minecraft:brown_terracotta
fill 238 221 481 238 221 482 minecraft:brown_terracotta
setblock 238 221 483 minecraft:bone_block
fill 238 221 484 238 224 484 minecraft:brown_terracotta
setblock 238 221 498 minecraft:bone_block
fill 238 221 499 238 224 499 minecraft:brown_terracotta
setblock 238 221 503 minecraft:bone_block
fill 238 221 504 238 224 504 minecraft:brown_terracotta
setblock 239 221 502 minecraft:bone_block
fill 239 221 503 239 224 503 minecraft:brown_terracotta
fill 240 221 502 240 224 502 minecraft:brown_terracotta
setblock 242 221 464 minecraft:bone_block
setblock 242 221 504 minecraft:bone_block
fill 243 221 464 244 223 464 minecraft:brown_terracotta
setblock 243 221 503 minecraft:bone_block
fill 243 221 504 243 224 504 minecraft:brown_terracotta
fill 244 221 503 244 224 503 minecraft:brown_terracotta
fill 255 221 464 256 221 464 minecraft:brown_terracotta
fill 255 221 504 256 221 504 minecraft:brown_terracotta
setblock 257 221 464 minecraft:bone_block
fill 257 221 465 258 223 465 minecraft:brown_terracotta
setblock 257 221 504 minecraft:bone_block
fill 258 221 464 258 224 464 minecraft:brown_terracotta
setblock 258 221 503 minecraft:bone_block
fill 258 221 504 258 224 504 minecraft:brown_terracotta
fill 259 221 503 259 224 503 minecraft:brown_terracotta
setblock 261 221 464 minecraft:brown_terracotta
setblock 261 221 465 minecraft:bone_block
fill 261 221 466 262 223 466 minecraft:brown_terracotta
fill 261 221 502 263 221 502 minecraft:brown_terracotta
setblock 262 221 464 minecraft:bone_block
fill 262 221 465 262 224 465 minecraft:brown_terracotta
setblock 262 221 504 minecraft:bone_block
fill 263 221 464 263 224 464 minecraft:brown_terracotta
setblock 263 221 503 minecraft:bone_block
fill 263 221 504 263 224 504 minecraft:brown_terracotta
setblock 264 221 502 minecraft:bone_block
fill 264 221 503 264 224 503 minecraft:brown_terracotta
fill 265 221 502 265 224 502 minecraft:brown_terracotta
setblock 266 221 465 minecraft:bone_block
setblock 267 221 464 minecraft:bone_block
setblock 267 221 504 minecraft:bone_block
fill 268 221 464 268 224 464 minecraft:brown_terracotta
setblock 268 221 503 minecraft:bone_block
fill 268 221 504 268 224 504 minecraft:brown_terracotta
fill 269 221 503 272 221 503 minecraft:brown_terracotta
setblock 271 221 464 minecraft:brown_terracotta
setblock 272 221 464 minecraft:bone_block
setblock 272 221 504 minecraft:bone_block
fill 273 221 464 275 222 464 minecraft:brown_terracotta
setblock 273 221 503 minecraft:bone_block
fill 273 221 504 273 224 504 minecraft:brown_terracotta
fill 274 221 503 274 224 503 minecraft:brown_terracotta
fill 275 221 498 275 223 498 minecraft:brown_terracotta
setblock 275 221 501 minecraft:bone_block
fill 275 221 502 275 224 502 minecraft:brown_terracotta
setblock 276 221 465 minecraft:bone_block
setblock 276 221 479 minecraft:brown_terracotta
setblock 276 221 480 minecraft:bone_block
fill 276 221 481 276 221 484 minecraft:brown_terracotta
setblock 276 221 495 minecraft:bone_block
fill 276 221 496 276 224 496 minecraft:brown_terracotta
setblock 276 221 500 minecraft:bone_block
fill 276 221 501 276 224 501 minecraft:brown_terracotta
setblock 236 222 464 minecraft:bone_block
fill 236 222 476 236 224 476 minecraft:brown_terracotta
setblock 236 222 479 minecraft:bone_block
fill 236 222 480 236 225 480 minecraft:brown_terracotta
setblock 236 222 483 minecraft:brown_terracotta
setblock 236 222 484 minecraft:bone_block
fill 236 222 485 236 225 485 minecraft:brown_terracotta
setblock 236 222 489 minecraft:bone_block
fill 236 222 490 237 224 490 minecraft:brown_terracotta
setblock 236 222 494 minecraft:bone_block
fill 236 222 495 236 225 495 minecraft:brown_terracotta
setblock 236 222 499 minecraft:bone_block
fill 236 222 500 236 225 500 minecraft:brown_terracotta
setblock 236 222 504 minecraft:bone_block
fill 237 222 464 240 222 464 minecraft:brown_terracotta
setblock 237 222 477 minecraft:brown_terracotta
setblock 237 222 478 minecraft:bone_block
fill 237 222 479 238 224 479 minecraft:brown_terracotta
setblock 237 222 483 minecraft:bone_block
fill 237 222 484 237 225 484 minecraft:brown_terracotta
setblock 237 222 487 minecraft:brown_terracotta
setblock 237 222 488 minecraft:bone_block
fill 237 222 489 237 225 489 minecraft:brown_terracotta
fill 237 222 491 237 222 492 minecraft:brown_terracotta
setblock 237 222 493 minecraft:bone_block
fill 237 222 494 237 225 494 minecraft:brown_terracotta
setblock 237 222 498 minecraft:bone_block
fill 237 222 499 237 225 499 minecraft:brown_terracotta
setblock 237 222 503 minecraft:bone_block
fill 237 222 504 237 225 504 minecraft:brown_terracotta
setblock 238 222 481 minecraft:brown_terracotta
setblock 238 222 482 minecraft:bone_block
fill 238 222 483 239 224 483 minecraft:brown_terracotta
setblock 238 222 486 minecraft:brown_terracotta
setblock 238 222 487 minecraft:bone_block
fill 238 222 488 238 225 488 minecraft:brown_terracotta
fill 238 222 498 238 225 498 minecraft:brown_terracotta
setblock 238 222 502 minecraft:bone_block
fill 238 222 503 238 225 503 minecraft:brown_terracotta
setblock 239 222 481 minecraft:bone_block
fill 239 222 482 239 225 482 minecraft:brown_terracotta
fill 239 222 484 239 222 485 minecraft:brown_terracotta
fill 239 222 502 239 225 502 minecraft:brown_terracotta
setblock 241 222 464 minecraft:bone_block
setblock 241 222 504 minecraft:bone_block
fill 242 222 464 242 225 464 minecraft:brown_terracotta
setblock 242 222 503 minecraft:bone_block
fill 242 222 504 242 225 504 minecraft:brown_terracotta
fill 243 222 503 243 225 503 minecraft:brown_terracotta
setblock 245 222 464 minecraft:brown_terracotta
setblock 246 222 504 minecraft:bone_block
fill 247 222 504 247 225 504 minecraft:brown_terracotta
fill 253 222 464 255 222 464 minecraft:brown_terracotta
fill 254 222 504 255 222 504 minecraft:brown_terracotta
setblock 256 222 464 minecraft:bone_block
fill 256 222 465 256 225 465 minecraft:brown_terracotta
setblock 256 222 503 minecraft:brown_terracotta
setblock 256 222 504 minecraft:bone_block
fill 257 222 464 257 225 464 minecraft:brown_terracotta
setblock 257 222 503 minecraft:bone_block
fill 257 222 504 257 225 504 minecraft:brown_terracotta
fill 258 222 503 258 225 503 minecraft:brown_terracotta
setblock 259 222 466 minecraft:bone_block
fill 259 222 502 262 222 502 minecraft:brown_terracotta
setblock 260 222 464 minecraft:brown_terracotta
setblock 260 222 465 minecraft:bone_block
fill 260 222 466 260 225 466 minecraft:brown_terracotta
setblock 261 222 464 minecraft:bone_block
fill 261 222 465 261 225 465 minecraft:brown_terracotta
setblock 261 222 504 minecraft:bone_block
fill 262 222 464 262 225 464 minecraft:brown_terracotta
setblock 262 222 503 minecraft:bone_block
fill 262 222 504 262 225 504 minecraft:brown_terracotta
setblock 263 222 466 minecraft:brown_terracotta
setblock 263 222 502 minecraft:bone_block
fill 263 222 503 263 225 503 minecraft:brown_terracotta
fill 264 222 502 264 225 502 minecraft:brown_terracotta
setblock 265 222 465 minecraft:bone_block
setblock 266 222 464 minecraft:bone_block
fill 266 222 465 267 224 465 minecraft:brown_terracotta
setblock 266 222 504 minecraft:bone_block
fill 267 222 464 267 225 464 minecraft:brown_terracotta
setblock 267 222 503 minecraft:bone_block
fill 267 222 504 267 225 504 minecraft:brown_terracotta
fill 268 222 503 271 222 503 minecraft:brown_terracotta
setblock 271 222 464 minecraft:bone_block
setblock 271 222 504 minecraft:bone_block
fill 272 222 464 272 225 464 minecraft:brown_terracotta
setblock 272 222 503 minecraft:bone_block
fill 272 222 504 272 225 504 minecraft:brown_terracotta
fill 273 222 503 273 225 503 minecraft:brown_terracotta
fill 274 222 502 274 225 502 minecraft:brown_terracotta
setblock 275 222 500 minecraft:bone_block
fill 275 222 501 275 225 501 minecraft:brown_terracotta
setblock 276 222 464 minecraft:bone_block
fill 276 222 465 276 224 466 minecraft:brown_terracotta
setblock 276 222 478 minecraft:brown_terracotta
setblock 276 222 479 minecraft:bone_block
fill 276 222 480 276 222 483 minecraft:brown_terracotta
setblock 276 222 484 minecraft:bone_block
fill 276 222 485 276 222 488 minecraft:brown_terracotta
setblock 276 222 493 minecraft:brown_terracotta
setblock 276 222 494 minecraft:bone_block
fill 276 222 495 276 225 495 minecraft:brown_terracotta
setblock 276 222 499 minecraft:bone_block
fill 276 222 500 276 225 500 minecraft:brown_terracotta
setblock 276 222 504 minecraft:bone_block
fill 236 223 464 236 224 466 minecraft:brown_terracotta
fill 236 223 475 236 225 475 minecraft:brown_terracotta
setblock 236 223 478 minecraft:bone_block
fill 236 223 479 236 225 479 minecraft:brown_terracotta
setblock 236 223 482 minecraft:brown_terracotta
setblock 236 223 483 minecraft:bone_block
fill 236 223 484 236 225 484 minecraft:brown_terracotta
setblock 236 223 487 minecraft:brown_terracotta
setblock 236 223 488 minecraft:bone_block
fill 236 223 489 236 225 489 minecraft:brown_terracotta
setblock 236 223 493 minecraft:bone_block
fill 236 223 494 236 225 494 minecraft:brown_terracotta
setblock 236 223 498 minecraft:bone_block
fill 236 223 499 236 225 499 minecraft:brown_terracotta
setblock 236 223 503 minecraft:bone_block
fill 236 223 504 236 225 504 minecraft:brown_terracotta
fill 237 223 464 239 223 464 minecraft:brown_terracotta
setblock 237 223 477 minecraft:bone_block
fill 237 223 478 238 225 478 minecraft:brown_terracotta
setblock 237 223 482 minecraft:bone_block
fill 237 223 483 237 225 483 minecraft:brown_terracotta
setblock 237 223 487 minecraft:bone_block
fill 237 223 488 237 225 488 minecraft:brown_terracotta
setblock 237 223 491 minecraft:brown_terracotta
setblock 237 223 492 minecraft:bone_block
fill 237 223 493 237 225 493 minecraft:brown_terracotta
setblock 237 223 497 minecraft:bone_block
fill 237 223 498 237 225 498 minecraft:brown_terracotta
setblock 237 223 502 minecraft:bone_block
fill 237 223 503 237 225 503 minecraft:brown_terracotta
setblock 238 223 481 minecraft:bone_block
fill 238 223 482 238 225 482 minecraft:brown_terracotta
setblock 238 223 486 minecraft:bone_block
fill 238 223 487 239 225 487 minecraft:brown_terracotta
fill 238 223 489 238 223 490 minecraft:brown_terracotta
setblock 238 223 501 minecraft:bone_block
fill 238 223 502 238 225 502 minecraft:brown_terracotta
setblock 239 223 465 minecraft:bone_block
setblock 239 223 480 minecraft:bone_block
fill 239 223 481 239 225 481 minecraft:brown_terracotta
setblock 239 223 484 minecraft:brown_terracotta
setblock 239 223 485 minecraft:bone_block
fill 239 223 486 239 225 486 minecraft:brown_terracotta
setblock 240 223 464 minecraft:bone_block
fill 240 223 465 241 225 465 minecraft:brown_terracotta
setblock 240 223 504 minecraft:bone_block
fill 241 223 464 241 225 464 minecraft:brown_terracotta
setblock 241 223 503 minecraft:bone_block
fill 241 223 504 241 225 504 minecraft:brown_terracotta
setblock 242 223 502 minecraft:bone_block
fill 242 223 503 242 225 503 minecraft:brown_terracotta
setblock 245 223 464 minecraft:bone_block
setblock 245 223 504 minecraft:bone_block
fill 246 223 464 247 225 464 minecraft:brown_terracotta
fill 246 223 504 246 225 504 minecraft:brown_terracotta
fill 251 223 464 254 223 464 minecraft:brown_terracotta
fill 252 223 504 254 223 504 minecraft:brown_terracotta
setblock 254 223 465 minecraft:bone_block
setblock 255 223 464 minecraft:bone_block
fill 255 223 465 255 225 465 minecraft:brown_terracotta
setblock 255 223 503 minecraft:brown_terracotta
setblock 255 223 504 minecraft:bone_block
fill 256 223 464 256 225 464 minecraft:brown_terracotta
setblock 256 223 503 minecraft:bone_block
fill 256 223 504 256 225 504 minecraft:brown_terracotta
setblock 257 223 466 minecraft:brown_terracotta
fill 257 223 503 257 225 503 minecraft:brown_terracotta
setblock 258 223 466 minecraft:bone_block
fill 258 223 502 261 223 502 minecraft:brown_terracotta
setblock 259 223 464 minecraft:brown_terracotta
setblock 259 223 465 minecraft:bone_block
fill 259 223 466 259 225 466 minecraft:brown_terracotta
setblock 260 223 464 minecraft:bone_block
fill 260 223 465 260 225 465 minecraft:brown_terracotta
setblock 260 223 504 minecraft:bone_block
fill 261 223 464 261 225 464 minecraft:brown_terracotta
setblock 261 223 503 minecraft:bone_block
fill 261 223 504 261 225 504 minecraft:brown_terracotta
setblock 262 223 502 minecraft:bone_block
fill 262 223 503 262 225 503 minecraft:brown_terracotta
setblock 263 223 466 minecraft:bone_block
fill 263 223 502 263 225 502 minecraft:brown_terracotta
setblock 264 223 465 minecraft:bone_block
fill 264 223 466 264 225 466 minecraft:brown_terracotta
setblock 265 223 464 minecraft:bone_block
fill 265 223 465 265 225 465 minecraft:brown_terracotta
setblock 265 223 504 minecraft:bone_block
fill 266 223 464 266 225 464 minecraft:brown_terracotta
setblock 266 223 503 minecraft:bone_block
fill 266 223 504 266 225 504 minecraft:brown_terracotta
fill 267 223 503 270 223 503 minecraft:brown_terracotta
setblock 268 223 465 minecraft:brown_terracotta
setblock 269 223 464 minecraft:brown_terracotta
setblock 270 223 464 minecraft:bone_block
setblock 270 223 504 minecraft:bone_block
fill 271 223 464 271 225 464 minecraft:brown_terracotta
setblock 271 223 503 minecraft:bone_block
fill 271 223 504 271 225 504 minecraft:brown_terracotta
fill 272 223 503 272 225 503 minecraft:brown_terracotta
fill 273 223 464 274 223 464 minecraft:brown_terracotta
fill 273 223 502 273 225 502 minecraft:brown_terracotta
fill 274 223 501 274 225 501 minecraft:brown_terracotta
setblock 275 223 464 minecraft:bone_block
fill 275 223 465 275 225 465 minecraft:brown_terracotta
fill 275 223 497 275 224 497 minecraft:brown_terracotta
setblock 275 223 499 minecraft:bone_block
fill 275 223 500 275 225 500 minecraft:brown_terracotta
setblock 275 223 504 minecraft:bone_block
fill 276 223 464 276 225 464 minecraft:brown_terracotta
setblock 276 223 467 minecraft:brown_terracotta
setblock 276 223 477 minecraft:brown_terracotta
setblock 276 223 478 minecraft:bone_block
fill 276 223 479 276 223 482 minecraft:brown_terracotta
setblock 276 223 483 minecraft:bone_block
fill 276 223 484 276 223 487 minecraft:brown_terracotta
setblock 276 223 488 minecraft:bone_block
fill 276 223 489 276 223 492 minecraft:brown_terracotta
setblock 276 223 493 minecraft:bone_block
fill 276 223 494 276 225 494 minecraft:brown_terracotta
setblock 276 223 498 minecraft:bone_block
fill 276 223 499 276 225 499 minecraft:brown_terracotta
setblock 276 223 503 minecraft:bone_block
fill 276 223 504 276 225 504 minecraft:brown_terracotta
setblock 236 224 467 minecraft:bone_block
fill 236 224 468 236 225 468 minecraft:brown_terracotta
setblock 236 224 477 minecraft:bone_block
fill 236 224 478 236 225 478 minecraft:brown_terracotta
setblock 236 224 482 minecraft:bone_block
fill 236 224 483 236 225 483 minecraft:brown_terracotta
setblock 236 224 486 minecraft:brown_terracotta
setblock 236 224 487 minecraft:bone_block
fill 236 224 488 236 225 488 minecraft:brown_terracotta
setblock 236 224 492 minecraft:bone_block
fill 236 224 493 236 225 493 minecraft:brown_terracotta
setblock 236 224 497 minecraft:bone_block
fill 236 224 498 236 225 498 minecraft:brown_terracotta
setblock 236 224 502 minecraft:bone_block
fill 236 224 503 236 225 503 minecraft:brown_terracotta
fill 237 224 464 237 224 465 minecraft:brown_terracotta
setblock 237 224 476 minecraft:bone_block
fill 237 224 477 237 225 477 minecraft:brown_terracotta
setblock 237 224 480 minecraft:brown_terracotta
setblock 237 224 481 minecraft:bone_block
fill 237 224 482 237 225 482 minecraft:brown_terracotta
setblock 237 224 485 minecraft:brown_terracotta
setblock 237 224 486 minecraft:bone_block
fill 237 224 487 237 225 487 minecraft:brown_terracotta
setblock 237 224 491 minecraft:bone_block
fill 237 224 492 238 225 492 minecraft:brown_terracotta
setblock 237 224 496 minecraft:bone_block
fill 237 224 497 237 225 497 minecraft:brown_terracotta
setblock 237 224 501 minecraft:bone_block
fill 237 224 502 237 225 502 minecraft:brown_terracotta
setblock 238 224 464 minecraft:brown_terracotta
setblock 238 224 465 minecraft:bone_block
setblock 238 224 480 minecraft:bone_block
fill 238 224 481 238 225 481 minecraft:brown_terracotta
setblock 238 224 485 minecraft:bone_block
fill 238 224 486 238 225 486 minecraft:brown_terracotta
setblock 238 224 489 minecraft:brown_terracotta
setblock 238 224 490 minecraft:bone_block
fill 238 224 491 238 225 491 minecraft:brown_terracotta
setblock 238 224 500 minecraft:bone_block
fill 238 224 501 238 225 501 minecraft:brown_terracotta
setblock 239 224 464 minecraft:bone_block
fill 239 224 465 239 225 465 minecraft:brown_terracotta
fill 239 224 480 239 225 480 minecraft:brown_terracotta
setblock 239 224 484 minecraft:bone_block
fill 239 224 485 240 225 485 minecraft:brown_terracotta
setblock 239 224 488 minecraft:brown_terracotta
setblock 239 224 504 minecraft:bone_block
fill 240 224 464 240 225 464 minecraft:brown_terracotta
setblock 240 224 483 minecraft:bone_block
fill 240 224 484 240 225 484 minecraft:brown_terracotta
setblock 240 224 503 minecraft:bone_block
fill 240 224 504 240 225 504 minecraft:brown_terracotta
setblock 241 224 502 minecraft:bone_block
fill 241 224 503 241 225 503 minecraft:brown_terracotta
setblock 242 224 465 minecraft:brown_terracotta
setblock 243 224 464 minecraft:brown_terracotta
setblock 243 224 465 minecraft:bone_block
setblock 244 224 464 minecraft:bone_block
setblock 244 224 504 minecraft:bone_block
fill 245 224 464 245 225 464 minecraft:brown_terracotta
fill 245 224 504 245 225 504 minecraft:brown_terracotta
setblock 248 224 464 minecraft:brown_terracotta
setblock 249 224 464 minecraft:bone_block
fill 250 224 464 253 224 464 minecraft:brown_terracotta
fill 251 224 504 253 224 504 minecraft:brown_terracotta
setblock 253 224 465 minecraft:bone_block
setblock 254 224 464 minecraft:bone_block
fill 254 224 465 254 225 465 minecraft:brown_terracotta
setblock 254 224 504 minecraft:bone_block
fill 255 224 464 255 225 464 minecraft:brown_terracotta
fill 255 224 466 256 224 466 minecraft:brown_terracotta
setblock 255 224 503 minecraft:bone_block
fill 255 224 504 255 225 504 minecraft:brown_terracotta
fill 256 224 503 256 225 503 minecraft:brown_terracotta
setblock 257 224 465 minecraft:brown_terracotta
setblock 257 224 466 minecraft:bone_block
setblock 258 224 465 minecraft:bone_block
fill 258 224 466 258 225 466 minecraft:brown_terracotta
fill 258 224 502 260 224 502 minecraft:brown_terracotta
setblock 259 224 464 minecraft:bone_block
fill 259 224 465 259 225 465 minecraft:brown_terracotta
fill 259 224 467 260 224 467 minecraft:brown_terracotta
setblock 259 224 504 minecraft:bone_block
fill 260 224 464 260 225 464 minecraft:brown_terracotta
setblock 260 224 503 minecraft:bone_block
fill 260 224 504 260 225 504 minecraft:brown_terracotta
setblock 261 224 466 minecraft:brown_terracotta
setblock 261 224 502 minecraft:bone_block
fill 261 224 503 261 225 503 minecraft:brown_terracotta
setblock 262 224 466 minecraft:bone_block
fill 262 224 502 262 225 502 minecraft:brown_terracotta
setblock 263 224 465 minecraft:bone_block
fill 263 224 466 263 225 466 minecraft:brown_terracotta
setblock 264 224 464 minecraft:bone_block
fill 264 224 465 264 225 465 minecraft:brown_terracotta
setblock 264 224 504 minecraft:bone_block
fill 265 224 464 265 225 464 minecraft:brown_terracotta
fill 265 224 466 265 225 466 minecraft:brown_terracotta
setblock 265 224 503 minecraft:bone_block
fill 265 224 504 265 225 504 minecraft:brown_terracotta
fill 266 224 503 269 224 503 minecraft:brown_terracotta
setblock 268 224 465 minecraft:bone_block
setblock 269 224 464 minecraft:bone_block
fill 269 224 465 269 225 465 minecraft:brown_terracotta
setblock 269 224 504 minecraft:bone_block
fill 270 224 464 270 225 464 minecraft:brown_terracotta
setblock 270 224 503 minecraft:bone_block
fill 270 224 504 270 225 504 minecraft:brown_terracotta
fill 271 224 503 271 225 503 minecraft:brown_terracotta
setblock 272 224 465 minecraft:brown_terracotta
fill 272 224 502 272 225 502 minecraft:brown_terracotta
setblock 273 224 464 minecraft:brown_terracotta
setblock 273 224 465 minecraft:bone_block
setblock 274 224 464 minecraft:bone_block
fill 274 224 465 274 225 465 minecraft:brown_terracotta
fill 274 224 500 274 225 500 minecraft:brown_terracotta
setblock 274 224 504 minecraft:bone_block
fill 275 224 464 275 225 464 minecraft:brown_terracotta
fill 275 224 466 275 225 466 minecraft:brown_terracotta
fill 275 224 481 275 224 482 minecraft:brown_terracotta
setblock 275 224 483 minecraft:bone_block
fill 275 224 484 275 224 487 minecraft:brown_terracotta
setblock 275 224 488 minecraft:bone_block
fill 275 224 496 275 225 496 minecraft:brown_terracotta
setblock 275 224 498 minecraft:bone_block
fill 275 224 499 275 225 499 minecraft:brown_terracotta
setblock 275 224 503 minecraft:bone_block
fill 275 224 504 275 225 504 minecraft:brown_terracotta
setblock 276 224 467 minecraft:bone_block
fill 276 224 468 276 225 468 minecraft:brown_terracotta
setblock 276 224 477 minecraft:bone_block
fill 276 224 478 276 224 481 minecraft:brown_terracotta
setblock 276 224 482 minecraft:bone_block
fill 276 224 483 276 224 486 minecraft:brown_terracotta
setblock 276 224 487 minecraft:bone_block
fill 276 224 488 276 224 491 minecraft:brown_terracotta
setblock 276 224 492 minecraft:bone_block
fill 276 224 493 276 225 493 minecraft:brown_terracotta
setblock 276 224 497 minecraft:bone_block
fill 276 224 498 276 225 498 minecraft:brown_terracotta
setblock 276 224 502 minecraft:bone_block
fill 276 224 503 276 225 503 minecraft:brown_terracotta
fill 236 225 464 236 225 465 minecraft:brown_terracotta
setblock 236 225 466 minecraft:bone_block
fill 236 225 467 237 225 467 minecraft:brown_terracotta
fill 236 225 469 236 225 470 minecraft:brown_terracotta
fill 236 225 473 236 225 474 minecraft:brown_terracotta
setblock 236 225 476 minecraft:bone_block
setblock 236 225 477 minecraft:brown_terracotta
setblock 236 225 481 minecraft:bone_block
setblock 236 225 482 minecraft:brown_terracotta
setblock 236 225 486 minecraft:bone_block
setblock 236 225 487 minecraft:brown_terracotta
setblock 236 225 490 minecraft:brown_terracotta
setblock 236 225 491 minecraft:bone_block
setblock 236 225 492 minecraft:brown_terracotta
setblock 236 225 496 minecraft:bone_block
setblock 236 225 497 minecraft:brown_terracotta
setblock 236 225 501 minecraft:bone_block
setblock 236 225 502 minecraft:brown_terracotta
setblock 237 225 464 minecraft:brown_terracotta
setblock 237 225 465 minecraft:bone_block
setblock 237 225 466 minecraft:brown_terracotta
setblock 237 225 476 minecraft:brown_terracotta
setblock 237 225 479 minecraft:brown_terracotta
setblock 237 225 480 minecraft:bone_block
setblock 237 225 481 minecraft:brown_terracotta
setblock 237 225 485 minecraft:bone_block
setblock 237 225 486 minecraft:brown_terracotta
setblock 237 225 490 minecraft:bone_block
setblock 237 225 491 minecraft:brown_terracotta
setblock 237 225 495 minecraft:bone_block
setblock 237 225 496 minecraft:brown_terracotta
setblock 237 225 500 minecraft:bone_block
setblock 237 225 501 minecraft:brown_terracotta
setblock 238 225 464 minecraft:bone_block
setblock 238 225 465 minecraft:brown_terracotta
setblock 238 225 479 minecraft:bone_block
setblock 238 225 480 minecraft:brown_terracotta
setblock 238 225 483 minecraft:brown_terracotta
setblock 238 225 484 minecraft:bone_block
setblock 238 225 485 minecraft:brown_terracotta
setblock 238 225 489 minecraft:bone_block
setblock 238 225 490 minecraft:brown_terracotta
setblock 238 225 493 minecraft:brown_terracotta
setblock 238 225 499 minecraft:bone_block
setblock 238 225 500 minecraft:brown_terracotta
setblock 238 225 504 minecraft:bone_block
setblock 239 225 464 minecraft:brown_terracotta
setblock 239 225 483 minecraft:bone_block
setblock 239 225 484 minecraft:brown_terracotta
setblock 239 225 488 minecraft:bone_block
setblock 239 225 489 minecraft:brown_terracotta
setblock 239 225 503 minecraft:bone_block
setblock 239 225 504 minecraft:brown_terracotta
setblock 240 225 482 minecraft:bone_block
setblock 240 225 483 minecraft:brown_terracotta
setblock 240 225 486 minecraft:brown_terracotta
setblock 240 225 502 minecraft:bone_block
setblock 240 225 503 minecraft:brown_terracotta
setblock 241 225 502 minecraft:brown_terracotta
setblock 242 225 465 minecraft:bone_block
setblock 243 225 464 minecraft:bone_block
setblock 243 225 465 minecraft:brown_terracotta
setblock 243 225 504 minecraft:bone_block
setblock 244 225 464 minecraft:brown_terracotta
setblock 244 225 504 minecraft:brown_terracotta
setblock 248 225 464 minecraft:bone_block
fill 249 225 464 252 225 464 minecraft:brown_terracotta
fill 250 225 504 252 225 504 minecraft:brown_terracotta
setblock 251 225 465 minecraft:brown_terracotta
setblock 252 225 465 minecraft:bone_block
setblock 253 225 464 minecraft:bone_block
setblock 253 225 465 minecraft:brown_terracotta
setblock 253 225 504 minecraft:bone_block
setblock 254 225 464 minecraft:brown_terracotta
fill 254 225 466 255 225 466 minecraft:brown_terracotta
setblock 254 225 503 minecraft:bone_block
setblock 254 225 504 minecraft:brown_terracotta
setblock 255 225 503 minecraft:brown_terracotta
setblock 256 225 466 minecraft:bone_block
setblock 257 225 465 minecraft:bone_block
fill 257 225 466 257 225 467 minecraft:brown_terracotta
fill 257 225 502 259 225 502 minecraft:brown_terracotta
setblock 258 225 464 minecraft:bone_block
setblock 258 225 465 minecraft:brown_terracotta
fill 258 225 467 259 225 467 minecraft:brown_terracotta
setblock 258 225 504 minecraft:bone_block
setblock 259 225 464 minecraft:brown_terracotta
setblock 259 225 503 minecraft:bone_block
setblock 259 225 504 minecraft:brown_terracotta
setblock 260 225 467 minecraft:bone_block
setblock 260 225 502 minecraft:bone_block
setblock 260 225 503 minecraft:brown_terracotta
setblock 261 225 466 minecraft:bone_block
setblock 261 225 467 minecraft:brown_terracotta
setblock 261 225 502 minecraft:brown_terracotta
setblock 262 225 465 minecraft:bone_block
setblock 262 225 466 minecraft:brown_terracotta
setblock 263 225 464 minecraft:bone_block
setblock 263 225 465 minecraft:brown_terracotta
setblock 263 225 504 minecraft:bone_block
setblock 264 225 464 minecraft:brown_terracotta
setblock 264 225 503 minecraft:bone_block
setblock 264 225 504 minecraft:brown_terracotta
fill 265 225 503 268 225 503 minecraft:brown_terracotta
setblock 266 225 465 minecraft:brown_terracotta
setblock 267 225 465 minecraft:bone_block
setblock 268 225 464 minecraft:bone_block
setblock 268 225 465 minecraft:brown_terracotta
setblock 268 225 504 minecraft:bone_block
setblock 269 225 464 minecraft:brown_terracotta
setblock 269 225 503 minecraft:bone_block
setblock 269 225 504 minecraft:brown_terracotta
fill 270 225 465 271 225 465 minecraft:brown_terracotta
setblock 270 225 503 minecraft:brown_terracotta
setblock 272 225 465 minecraft:bone_block
setblock 273 225 464 minecraft:bone_block
setblock 273 225 465 minecraft:brown_terracotta
setblock 273 225 504 minecraft:bone_block
setblock 274 225 464 minecraft:brown_terracotta
setblock 274 225 503 minecraft:bone_block
setblock 274 225 504 minecraft:brown_terracotta
setblock 275 225 467 minecraft:bone_block
fill 275 225 480 275 225 481 minecraft:brown_terracotta
setblock 275 225 482 minecraft:bone_block
fill 275 225 483 275 225 486 minecraft:brown_terracotta
setblock 275 225 487 minecraft:bone_block
fill 275 225 488 275 225 491 minecraft:brown_terracotta
setblock 275 225 492 minecraft:bone_block
fill 275 225 493 275 225 495 minecraft:brown_terracotta
setblock 275 225 497 minecraft:bone_block
setblock 275 225 498 minecraft:brown_terracotta
setblock 275 225 502 minecraft:bone_block
setblock 275 225 503 minecraft:brown_terracotta
setblock 276 225 465 minecraft:brown_terracotta
setblock 276 225 466 minecraft:bone_block
setblock 276 225 467 minecraft:brown_terracotta
fill 276 225 469 276 225 470 minecraft:brown_terracotta
fill 276 225 477 276 225 480 minecraft:brown_terracotta
setblock 276 225 481 minecraft:bone_block
fill 276 225 482 276 225 485 minecraft:brown_terracotta
setblock 276 225 486 minecraft:bone_block
fill 276 225 487 276 225 490 minecraft:brown_terracotta
setblock 276 225 491 minecraft:bone_block
setblock 276 225 492 minecraft:brown_terracotta
setblock 276 225 496 minecraft:bone_block
setblock 276 225 497 minecraft:brown_terracotta
setblock 276 225 501 minecraft:bone_block
setblock 276 225 502 minecraft:brown_terracotta
setblock 238 227 466 minecraft:light[level=12]
setblock 238 227 474 minecraft:light[level=12]
setblock 238 227 482 minecraft:light[level=12]
setblock 238 227 490 minecraft:light[level=12]
setblock 238 227 498 minecraft:light[level=12]
setblock 246 227 466 minecraft:light[level=12]
setblock 246 227 474 minecraft:light[level=12]
setblock 246 227 482 minecraft:light[level=12]
setblock 246 227 490 minecraft:light[level=12]
setblock 246 227 498 minecraft:light[level=12]
setblock 254 227 466 minecraft:light[level=12]
setblock 254 227 474 minecraft:light[level=12]
setblock 254 227 482 minecraft:light[level=12]
setblock 254 227 490 minecraft:light[level=12]
setblock 254 227 498 minecraft:light[level=12]
setblock 262 227 466 minecraft:light[level=12]
setblock 262 227 474 minecraft:light[level=12]
setblock 262 227 482 minecraft:light[level=12]
setblock 262 227 490 minecraft:light[level=12]
setblock 262 227 498 minecraft:light[level=12]
setblock 270 227 466 minecraft:light[level=12]
setblock 270 227 474 minecraft:light[level=12]
setblock 270 227 482 minecraft:light[level=12]
setblock 270 227 490 minecraft:light[level=12]
setblock 270 227 498 minecraft:light[level=12]
fill 241 231 484 249 231 492 minecraft:bone_block
fill 242 231 482 262 231 483 minecraft:bone_block
fill 242 231 493 262 232 494 minecraft:bone_block
fill 243 231 481 261 232 481 minecraft:bone_block
fill 243 231 495 261 232 495 minecraft:bone_block
fill 244 231 480 260 232 480 minecraft:bone_block
fill 244 231 496 260 232 496 minecraft:bone_block
fill 245 231 479 259 231 479 minecraft:bone_block
fill 245 231 497 259 232 497 minecraft:bone_block
fill 246 231 473 258 231 478 minecraft:bone_block
fill 247 231 498 257 232 498 minecraft:bone_block
fill 250 231 484 250 231 485 minecraft:bone_block
fill 250 231 487 250 231 492 minecraft:bone_block
fill 250 231 499 254 232 499 minecraft:bone_block
setblock 251 231 484 minecraft:bone_block
fill 251 231 488 251 231 492 minecraft:bone_block
fill 252 231 489 263 231 492 minecraft:bone_block
fill 253 231 484 263 231 484 minecraft:bone_block
fill 253 231 488 263 231 488 minecraft:bone_block
fill 254 231 485 263 231 485 minecraft:bone_block
fill 254 231 487 263 231 487 minecraft:bone_block
fill 255 231 486 263 231 486 minecraft:bone_block
fill 236 232 464 240 232 504 minecraft:brown_terracotta
fill 241 232 464 241 232 483 minecraft:brown_terracotta
fill 241 232 484 244 232 492 minecraft:bone_block
fill 241 232 493 241 232 504 minecraft:brown_terracotta
fill 242 232 464 242 232 481 minecraft:brown_terracotta
fill 242 232 482 250 232 483 minecraft:bone_block
fill 242 232 495 242 232 504 minecraft:brown_terracotta
fill 243 232 464 243 232 480 minecraft:brown_terracotta
fill 243 232 496 243 232 504 minecraft:brown_terracotta
fill 244 232 464 244 232 479 minecraft:brown_terracotta
fill 244 232 497 244 232 504 minecraft:brown_terracotta
fill 245 232 464 245 232 478 minecraft:brown_terracotta
fill 245 232 479 246 232 479 minecraft:bone_block
fill 245 232 484 246 232 486 minecraft:bone_block
fill 245 232 487 249 232 489 minecraft:shroomlight
fill 245 232 490 245 232 492 minecraft:bone_block
fill 245 232 498 246 232 504 minecraft:brown_terracotta
fill 246 232 464 276 232 472 minecraft:brown_terracotta
fill 246 232 473 246 232 478 minecraft:bone_block
fill 246 232 490 249 232 490 minecraft:shroomlight
fill 246 232 491 246 232 492 minecraft:bone_block
fill 247 232 473 258 232 477 minecraft:bone_block
fill 247 232 478 247 232 479 minecraft:black_concrete
fill 247 232 484 248 232 485 minecraft:bone_block
fill 247 232 486 248 232 486 minecraft:shroomlight
setblock 247 232 491 minecraft:shroomlight
fill 247 232 492 263 232 492 minecraft:bone_block
fill 247 232 499 249 232 504 minecraft:brown_terracotta
fill 248 232 478 248 232 479 minecraft:bone_block
fill 248 232 491 256 232 491 minecraft:bone_block
fill 249 232 478 249 232 479 minecraft:black_concrete
setblock 249 232 484 minecraft:bone_block
setblock 249 232 485 minecraft:shroomlight
setblock 249 232 486 minecraft:smooth_sandstone
fill 250 232 478 250 232 479 minecraft:bone_block
fill 250 232 484 250 232 485 minecraft:ochre_froglight
fill 250 232 487 250 232 488 minecraft:ochre_froglight
fill 250 232 489 250 232 490 minecraft:bone_block
fill 250 232 500 276 232 504 minecraft:brown_terracotta
fill 251 232 478 251 232 479 minecraft:black_concrete
fill 251 232 482 262 232 482 minecraft:bone_block
setblock 251 232 483 minecraft:shroomlight
setblock 251 232 484 minecraft:ochre_froglight
setblock 251 232 488 minecraft:ochre_froglight
setblock 251 232 489 minecraft:shroomlight
fill 251 232 490 254 232 490 minecraft:bone_block
fill 252 232 478 252 232 479 minecraft:bone_block
setblock 252 232 483 minecraft:smooth_sandstone
setblock 252 232 489 minecraft:smooth_sandstone
fill 253 232 478 253 232 479 minecraft:black_concrete
setblock 253 232 483 minecraft:shroomlight
fill 253 232 484 254 232 484 minecraft:ochre_froglight
fill 253 232 488 254 232 488 minecraft:ochre_froglight
setblock 253 232 489 minecraft:shroomlight
fill 254 232 478 254 232 479 minecraft:bone_block
fill 254 232 483 262 232 483 minecraft:bone_block
setblock 254 232 485 minecraft:ochre_froglight
setblock 254 232 487 minecraft:ochre_froglight
setblock 254 232 489 minecraft:bone_block
fill 255 232 478 255 232 479 minecraft:black_concrete
fill 255 232 484 263 232 484 minecraft:bone_block
setblock 255 232 485 minecraft:shroomlight
setblock 255 232 486 minecraft:smooth_sandstone
fill 255 232 487 258 232 490 minecraft:shroomlight
fill 255 232 499 276 232 499 minecraft:brown_terracotta
fill 256 232 478 256 232 479 minecraft:bone_block
fill 256 232 485 263 232 485 minecraft:bone_block
fill 256 232 486 257 232 486 minecraft:shroomlight
fill 257 232 478 257 232 479 minecraft:black_concrete
setblock 257 232 491 minecraft:shroomlight
fill 258 232 478 258 232 479 minecraft:bone_block
fill 258 232 486 263 232 486 minecraft:bone_block
fill 258 232 491 263 232 491 minecraft:bone_block
fill 258 232 498 276 232 498 minecraft:brown_terracotta
fill 259 232 473 276 232 478 minecraft:brown_terracotta
setblock 259 232 479 minecraft:bone_block
fill 259 232 487 259 232 489 minecraft:shroomlight
fill 259 232 490 263 232 490 minecraft:bone_block
fill 260 232 479 276 232 479 minecraft:brown_terracotta
fill 260 232 487 263 232 489 minecraft:bone_block
fill 260 232 497 276 232 497 minecraft:brown_terracotta
fill 261 232 480 276 232 480 minecraft:brown_terracotta
fill 261 232 496 276 232 496 minecraft:brown_terracotta
fill 262 232 481 276 232 481 minecraft:brown_terracotta
fill 262 232 495 276 232 495 minecraft:brown_terracotta
fill 263 232 482 276 232 483 minecraft:brown_terracotta
fill 263 232 493 276 232 494 minecraft:brown_terracotta
fill 264 232 484 276 232 492 minecraft:brown_terracotta
fill 243 233 477 243 234 477 minecraft:bone_block
fill 243 233 486 243 239 486 minecraft:bone_block
fill 243 233 495 243 234 495 minecraft:bone_block
fill 246 233 477 246 234 477 minecraft:bone_block
fill 246 233 486 246 239 486 minecraft:bone_block
fill 246 233 495 246 234 495 minecraft:bone_block
fill 249 233 477 249 234 477 minecraft:bone_block
fill 249 233 486 249 239 486 minecraft:bone_block
fill 249 233 495 249 234 495 minecraft:bone_block
fill 252 233 477 252 234 477 minecraft:bone_block
fill 252 233 495 252 234 495 minecraft:bone_block
fill 255 233 477 255 234 477 minecraft:bone_block
fill 255 233 486 255 239 486 minecraft:bone_block
fill 255 233 495 255 234 495 minecraft:bone_block
fill 258 233 477 258 234 477 minecraft:bone_block
fill 258 233 486 258 239 486 minecraft:bone_block
fill 258 233 495 258 234 495 minecraft:bone_block
fill 261 233 477 261 234 477 minecraft:bone_block
fill 261 233 486 261 239 486 minecraft:bone_block
fill 261 233 495 261 234 495 minecraft:bone_block
setblock 238 235 466 minecraft:light[level=12]
setblock 238 235 474 minecraft:light[level=12]
setblock 238 235 482 minecraft:light[level=12]
setblock 238 235 490 minecraft:light[level=12]
setblock 238 235 498 minecraft:light[level=12]
fill 243 235 478 243 236 478 minecraft:bone_block
fill 243 235 494 243 236 494 minecraft:bone_block
setblock 246 235 466 minecraft:light[level=12]
setblock 246 235 474 minecraft:light[level=12]
fill 246 235 478 246 236 478 minecraft:bone_block
setblock 246 235 482 minecraft:light[level=12]
setblock 246 235 490 minecraft:light[level=12]
fill 246 235 494 246 236 494 minecraft:bone_block
setblock 246 235 498 minecraft:light[level=12]
fill 249 235 478 249 236 478 minecraft:bone_block
fill 249 235 494 249 236 494 minecraft:bone_block
fill 252 235 478 252 236 478 minecraft:bone_block
fill 252 235 494 252 236 494 minecraft:bone_block
setblock 254 235 466 minecraft:light[level=12]
setblock 254 235 474 minecraft:light[level=12]
setblock 254 235 482 minecraft:light[level=12]
setblock 254 235 490 minecraft:light[level=12]
setblock 254 235 498 minecraft:light[level=12]
fill 255 235 478 255 236 478 minecraft:bone_block
fill 255 235 494 255 236 494 minecraft:bone_block
fill 258 235 478 258 236 478 minecraft:bone_block
fill 258 235 494 258 236 494 minecraft:bone_block
fill 261 235 478 261 236 478 minecraft:bone_block
fill 261 235 494 261 236 494 minecraft:bone_block
setblock 262 235 466 minecraft:light[level=12]
setblock 262 235 474 minecraft:light[level=12]
setblock 262 235 482 minecraft:light[level=12]
setblock 262 235 490 minecraft:light[level=12]
setblock 262 235 498 minecraft:light[level=12]
setblock 270 235 466 minecraft:light[level=12]
setblock 270 235 474 minecraft:light[level=12]
setblock 270 235 482 minecraft:light[level=12]
setblock 270 235 490 minecraft:light[level=12]
setblock 270 235 498 minecraft:light[level=12]
setblock 236 236 465 minecraft:bone_block
fill 236 236 466 236 236 469 minecraft:brown_terracotta
setblock 236 236 470 minecraft:bone_block
fill 236 236 471 236 236 474 minecraft:brown_terracotta
setblock 236 236 475 minecraft:bone_block
fill 236 236 476 236 236 479 minecraft:brown_terracotta
setblock 236 236 480 minecraft:bone_block
fill 236 236 481 236 236 484 minecraft:brown_terracotta
setblock 236 236 485 minecraft:bone_block
fill 236 236 486 236 236 489 minecraft:brown_terracotta
setblock 236 236 490 minecraft:bone_block
fill 236 236 491 236 236 494 minecraft:brown_terracotta
setblock 236 236 495 minecraft:bone_block
fill 236 236 496 236 237 498 minecraft:brown_terracotta
setblock 237 236 468 minecraft:brown_terracotta
setblock 237 236 469 minecraft:bone_block
fill 237 236 470 237 236 473 minecraft:brown_terracotta
setblock 237 236 474 minecraft:bone_block
fill 237 236 475 237 237 477 minecraft:brown_terracotta
setblock 237 236 484 minecraft:bone_block
fill 237 236 485 237 236 488 minecraft:brown_terracotta
setblock 237 236 489 minecraft:bone_block
fill 237 236 490 237 236 493 minecraft:brown_terracotta
setblock 237 236 494 minecraft:bone_block
fill 237 236 495 237 239 495 minecraft:brown_terracotta
setblock 246 236 464 minecraft:brown_terracotta
setblock 247 236 464 minecraft:bone_block
fill 248 236 464 250 236 465 minecraft:brown_terracotta
fill 248 236 470 250 237 470 minecraft:bone_block
setblock 249 236 466 minecraft:brown_terracotta
fill 249 236 469 249 237 469 minecraft:bone_block
fill 249 236 471 249 237 471 minecraft:bone_block
setblock 250 236 466 minecraft:bone_block
setblock 251 236 464 minecraft:brown_terracotta
setblock 251 236 465 minecraft:bone_block
fill 251 236 466 253 236 467 minecraft:brown_terracotta
setblock 251 236 504 minecraft:brown_terracotta
setblock 252 236 464 minecraft:bone_block
fill 252 236 465 255 236 465 minecraft:brown_terracotta
setblock 252 236 504 minecraft:bone_block
fill 253 236 464 256 236 464 minecraft:brown_terracotta
fill 253 236 504 256 236 504 minecraft:brown_terracotta
setblock 254 236 466 minecraft:brown_terracotta
setblock 254 236 467 minecraft:bone_block
setblock 255 236 466 minecraft:bone_block
setblock 255 236 467 minecraft:brown_terracotta
setblock 256 236 465 minecraft:bone_block
fill 256 236 466 257 236 466 minecraft:brown_terracotta
setblock 257 236 464 minecraft:bone_block
fill 257 236 465 259 236 465 minecraft:brown_terracotta
setblock 257 236 504 minecraft:bone_block
fill 258 236 464 261 236 464 minecraft:brown_terracotta
fill 258 236 504 259 238 504 minecraft:brown_terracotta
setblock 267 236 504 minecraft:bone_block
fill 268 236 464 271 236 464 minecraft:brown_terracotta
fill 268 236 504 271 236 504 minecraft:brown_terracotta
setblock 272 236 464 minecraft:bone_block
setblock 272 236 504 minecraft:bone_block
fill 273 236 464 275 237 464 minecraft:brown_terracotta
fill 273 236 489 273 236 492 minecraft:brown_terracotta
setblock 273 236 493 minecraft:bone_block
fill 273 236 494 275 236 495 minecraft:brown_terracotta
fill 273 236 504 276 236 504 minecraft:brown_terracotta
setblock 274 236 486 minecraft:brown_terracotta
setblock 274 236 487 minecraft:bone_block
fill 274 236 488 274 236 491 minecraft:brown_terracotta
setblock 274 236 492 minecraft:bone_block
fill 274 236 493 276 237 493 minecraft:brown_terracotta
setblock 274 236 496 minecraft:brown_terracotta
setblock 274 236 497 minecraft:bone_block
fill 274 236 498 276 237 498 minecraft:brown_terracotta
fill 275 236 468 275 236 470 minecraft:brown_terracotta
setblock 275 236 471 minecraft:bone_block
fill 275 236 472 276 237 473 minecraft:brown_terracotta
fill 275 236 484 275 236 485 minecraft:brown_terracotta
setblock 275 236 486 minecraft:bone_block
fill 275 236 487 275 236 490 minecraft:brown_terracotta
setblock 275 236 491 minecraft:bone_block
fill 275 236 492 276 238 492 minecraft:brown_terracotta
setblock 275 236 496 minecraft:bone_block
fill 275 236 497 276 238 497 minecraft:brown_terracotta
fill 275 236 499 275 236 500 minecraft:brown_terracotta
setblock 276 236 465 minecraft:bone_block
fill 276 236 466 276 236 469 minecraft:brown_terracotta
setblock 276 236 470 minecraft:bone_block
fill 276 236 471 276 239 471 minecraft:brown_terracotta
setblock 276 236 474 minecraft:brown_terracotta
setblock 276 236 475 minecraft:bone_block
fill 276 236 476 276 236 479 minecraft:brown_terracotta
setblock 276 236 480 minecraft:bone_block
fill 276 236 481 276 236 484 minecraft:brown_terracotta
setblock 276 236 485 minecraft:bone_block
fill 276 236 486 276 236 489 minecraft:brown_terracotta
setblock 276 236 490 minecraft:bone_block
fill 276 236 491 276 239 491 minecraft:brown_terracotta
setblock 276 236 494 minecraft:brown_terracotta
setblock 276 236 495 minecraft:bone_block
fill 276 236 496 276 239 496 minecraft:brown_terracotta
setblock 276 236 499 minecraft:brown_terracotta
setblock 276 236 500 minecraft:bone_block
fill 276 236 501 276 237 503 minecraft:brown_terracotta
fill 236 237 465 236 237 468 minecraft:brown_terracotta
setblock 236 237 469 minecraft:bone_block
fill 236 237 470 236 237 473 minecraft:brown_terracotta
setblock 236 237 474 minecraft:bone_block
fill 236 237 475 236 237 478 minecraft:brown_terracotta
setblock 236 237 479 minecraft:bone_block
fill 236 237 480 236 237 483 minecraft:brown_terracotta
setblock 236 237 484 minecraft:bone_block
fill 236 237 485 236 237 488 minecraft:brown_terracotta
setblock 236 237 489 minecraft:bone_block
fill 236 237 490 236 237 493 minecraft:brown_terracotta
setblock 236 237 494 minecraft:bone_block
fill 236 237 495 236 240 495 minecraft:brown_terracotta
setblock 236 237 499 minecraft:bone_block
setblock 237 237 468 minecraft:bone_block
fill 237 237 469 237 237 472 minecraft:brown_terracotta
setblock 237 237 473 minecraft:bone_block
fill 237 237 474 237 240 474 minecraft:brown_terracotta
setblock 237 237 478 minecraft:bone_block
fill 237 237 485 237 237 487 minecraft:brown_terracotta
setblock 237 237 488 minecraft:bone_block
fill 237 237 489 237 237 492 minecraft:brown_terracotta
setblock 237 237 493 minecraft:bone_block
fill 237 237 494 237 240 494 minecraft:brown_terracotta
fill 238 237 496 238 244 496 minecraft:bone_block
fill 243 237 479 243 238 479 minecraft:bone_block
fill 243 237 493 243 238 493 minecraft:bone_block
setblock 246 237 464 minecraft:bone_block
fill 246 237 479 246 238 479 minecraft:bone_block
fill 246 237 493 246 238 493 minecraft:bone_block
fill 247 237 464 249 237 465 minecraft:brown_terracotta
setblock 248 237 466 minecraft:brown_terracotta
setblock 249 237 466 minecraft:bone_block
fill 249 237 479 249 238 479 minecraft:bone_block
fill 249 237 493 249 238 493 minecraft:bone_block
setblock 250 237 464 minecraft:brown_terracotta
setblock 250 237 465 minecraft:bone_block
fill 250 237 466 252 237 467 minecraft:brown_terracotta
setblock 250 237 504 minecraft:brown_terracotta
setblock 251 237 464 minecraft:bone_block
fill 251 237 465 254 237 465 minecraft:brown_terracotta
setblock 251 237 504 minecraft:bone_block
fill 252 237 464 255 237 464 minecraft:brown_terracotta
fill 252 237 479 252 238 479 minecraft:bone_block
fill 252 237 493 252 238 493 minecraft:bone_block
fill 252 237 504 255 237 504 minecraft:brown_terracotta
setblock 253 237 466 minecraft:brown_terracotta
setblock 253 237 467 minecraft:bone_block
setblock 254 237 466 minecraft:bone_block
fill 254 237 467 254 238 467 minecraft:brown_terracotta
setblock 255 237 465 minecraft:bone_block
fill 255 237 466 256 238 466 minecraft:brown_terracotta
fill 255 237 479 255 238 479 minecraft:bone_block
fill 255 237 493 255 238 493 minecraft:bone_block
setblock 256 237 464 minecraft:bone_block
fill 256 237 465 258 238 465 minecraft:brown_terracotta
setblock 256 237 504 minecraft:bone_block
fill 257 237 464 260 237 464 minecraft:brown_terracotta
fill 257 237 504 257 240 504 minecraft:brown_terracotta
fill 258 237 479 258 238 479 minecraft:bone_block
fill 258 237 493 258 238 493 minecraft:bone_block
fill 261 237 479 261 238 479 minecraft:bone_block
fill 261 237 493 261 238 493 minecraft:bone_block
fill 263 237 485 266 243 487 minecraft:bone_block
fill 264 237 484 265 244 484 minecraft:bone_block
fill 264 237 488 264 244 488 minecraft:bone_block
setblock 266 237 504 minecraft:bone_block
fill 267 237 486 267 243 486 minecraft:bone_block
fill 267 237 504 270 237 504 minecraft:brown_terracotta
fill 268 237 464 270 237 464 minecraft:brown_terracotta
fill 270 237 503 271 237 503 minecraft:brown_terracotta
setblock 271 237 464 minecraft:bone_block
setblock 271 237 504 minecraft:bone_block
fill 272 237 464 272 240 464 minecraft:brown_terracotta
setblock 272 237 503 minecraft:bone_block
fill 272 237 504 275 237 504 minecraft:brown_terracotta
fill 273 237 489 273 237 491 minecraft:brown_terracotta
setblock 273 237 492 minecraft:bone_block
fill 273 237 493 273 237 496 minecraft:brown_terracotta
fill 273 237 503 273 240 503 minecraft:brown_terracotta
setblock 274 237 486 minecraft:bone_block
fill 274 237 487 274 237 490 minecraft:brown_terracotta
setblock 274 237 491 minecraft:bone_block
fill 274 237 492 274 240 492 minecraft:brown_terracotta
fill 274 237 494 274 237 495 minecraft:brown_terracotta
setblock 274 237 496 minecraft:bone_block
fill 274 237 497 274 240 497 minecraft:brown_terracotta
fill 274 237 499 275 237 499 minecraft:brown_terracotta
fill 275 237 468 275 237 469 minecraft:brown_terracotta
setblock 275 237 470 minecraft:bone_block
fill 275 237 471 275 240 471 minecraft:brown_terracotta
setblock 275 237 474 minecraft:brown_terracotta
setblock 275 237 475 minecraft:bone_block
setblock 275 237 484 minecraft:brown_terracotta
setblock 275 237 485 minecraft:bone_block
fill 275 237 486 275 237 489 minecraft:brown_terracotta
setblock 275 237 490 minecraft:bone_block
fill 275 237 491 275 240 491 minecraft:brown_terracotta
setblock 275 237 494 minecraft:brown_terracotta
setblock 275 237 495 minecraft:bone_block
fill 275 237 496 275 240 496 minecraft:brown_terracotta
setblock 275 237 500 minecraft:bone_block
fill 276 237 465 276 237 468 minecraft:brown_terracotta
setblock 276 237 469 minecraft:bone_block
fill 276 237 470 276 240 470 minecraft:brown_terracotta
setblock 276 237 474 minecraft:bone_block
fill 276 237 475 276 237 478 minecraft:brown_terracotta
setblock 276 237 479 minecraft:bone_block
fill 276 237 480 276 237 483 minecraft:brown_terracotta
setblock 276 237 484 minecraft:bone_block
fill 276 237 485 276 237 488 minecraft:brown_terracotta
setblock 276 237 489 minecraft:bone_block
fill 276 237 490 276 240 490 minecraft:brown_terracotta
setblock 276 237 494 minecraft:bone_block
fill 276 237 495 276 240 495 minecraft:brown_terracotta
setblock 276 237 499 minecraft:bone_block
fill 276 237 500 276 240 500 minecraft:brown_terracotta
fill 236 238 465 236 238 467 minecraft:brown_terracotta
setblock 236 238 468 minecraft:bone_block
fill 236 238 469 236 238 472 minecraft:brown_terracotta
setblock 236 238 473 minecraft:bone_block
fill 236 238 474 236 238 477 minecraft:brown_terracotta
setblock 236 238 478 minecraft:bone_block
fill 236 238 479 236 238 482 minecraft:brown_terracotta
setblock 236 238 483 minecraft:bone_block
fill 236 238 484 236 238 487 minecraft:brown_terracotta
setblock 236 238 488 minecraft:bone_block
fill 236 238 489 236 238 492 minecraft:brown_terracotta
setblock 236 238 493 minecraft:bone_block
fill 236 238 494 236 241 494 minecraft:brown_terracotta
fill 236 238 496 236 238 497 minecraft:brown_terracotta
setblock 236 238 498 minecraft:bone_block
fill 236 238 499 236 241 499 minecraft:brown_terracotta
fill 237 238 468 237 238 471 minecraft:brown_terracotta
setblock 237 238 472 minecraft:bone_block
fill 237 238 473 238 240 473 minecraft:brown_terracotta
fill 237 238 475 237 238 476 minecraft:brown_terracotta
setblock 237 238 477 minecraft:bone_block
fill 237 238 478 237 240 479 minecraft:brown_terracotta
setblock 237 238 486 minecraft:brown_terracotta
setblock 237 238 487 minecraft:bone_block
fill 237 238 488 237 238 491 minecraft:brown_terracotta
setblock 237 238 492 minecraft:bone_block
fill 237 238 493 237 241 493 minecraft:brown_terracotta
setblock 237 238 496 minecraft:brown_terracotta
fill 238 238 472 238 241 472 minecraft:brown_terracotta
fill 238 238 474 238 239 474 minecraft:brown_terracotta
fill 243 238 480 243 240 480 minecraft:bone_block
fill 243 238 492 243 240 492 minecraft:bone_block
setblock 245 238 464 minecraft:bone_block
fill 246 238 464 248 238 465 minecraft:brown_terracotta
fill 246 238 480 246 240 480 minecraft:bone_block
fill 246 238 492 246 240 492 minecraft:bone_block
setblock 248 238 466 minecraft:bone_block
setblock 249 238 464 minecraft:brown_terracotta
setblock 249 238 465 minecraft:bone_block
fill 249 238 466 252 238 466 minecraft:brown_terracotta
fill 249 238 480 249 240 480 minecraft:bone_block
fill 249 238 492 249 240 492 minecraft:bone_block
setblock 249 238 504 minecraft:brown_terracotta
setblock 250 238 464 minecraft:bone_block
fill 250 238 465 253 238 465 minecraft:brown_terracotta
fill 250 238 467 251 238 467 minecraft:brown_terracotta
setblock 250 238 504 minecraft:bone_block
fill 251 238 464 254 238 464 minecraft:brown_terracotta
fill 251 238 504 254 238 504 minecraft:brown_terracotta
setblock 252 238 467 minecraft:bone_block
fill 252 238 480 252 240 480 minecraft:bone_block
fill 252 238 492 252 240 492 minecraft:bone_block
fill 252 238 503 254 239 503 minecraft:brown_terracotta
setblock 253 238 466 minecraft:bone_block
fill 253 238 467 253 239 467 minecraft:brown_terracotta
setblock 254 238 465 minecraft:bone_block
fill 254 238 466 254 240 466 minecraft:brown_terracotta
setblock 255 238 464 minecraft:bone_block
fill 255 238 465 255 241 465 minecraft:brown_terracotta
fill 255 238 480 255 240 480 minecraft:bone_block
fill 255 238 492 255 240 492 minecraft:bone_block
setblock 255 238 504 minecraft:bone_block
fill 256 238 464 259 238 464 minecraft:brown_terracotta
fill 256 238 504 256 241 504 minecraft:brown_terracotta
fill 258 238 480 258 240 480 minecraft:bone_block
fill 258 238 492 258 240 492 minecraft:bone_block
setblock 260 238 464 minecraft:bone_block
fill 261 238 480 261 240 480 minecraft:bone_block
fill 261 238 492 261 240 492 minecraft:bone_block
fill 262 238 486 262 243 487 minecraft:bone_block
fill 263 238 484 263 243 484 minecraft:bone_block
fill 263 238 488 263 243 488 minecraft:bone_block
fill 265 238 488 267 243 488 minecraft:bone_block
setblock 265 238 504 minecraft:bone_block
fill 266 238 484 267 243 484 minecraft:bone_block
fill 266 238 504 269 238 504 minecraft:brown_terracotta
fill 267 238 464 269 238 464 minecraft:brown_terracotta
fill 267 238 485 268 242 485 minecraft:bone_block
fill 267 238 487 268 242 487 minecraft:bone_block
fill 268 238 486 268 242 486 minecraft:bone_block
fill 268 238 503 270 238 503 minecraft:brown_terracotta
setblock 270 238 464 minecraft:bone_block
setblock 270 238 504 minecraft:bone_block
fill 271 238 464 271 241 464 minecraft:brown_terracotta
setblock 271 238 503 minecraft:bone_block
fill 271 238 504 274 238 504 minecraft:brown_terracotta
setblock 272 238 492 minecraft:bone_block
fill 272 238 493 274 238 494 minecraft:brown_terracotta
fill 272 238 503 272 241 503 minecraft:brown_terracotta
fill 273 238 464 274 238 464 minecraft:brown_terracotta
fill 273 238 489 273 238 490 minecraft:brown_terracotta
setblock 273 238 491 minecraft:bone_block
fill 273 238 492 273 241 492 minecraft:brown_terracotta
setblock 273 238 495 minecraft:brown_terracotta
setblock 273 238 496 minecraft:bone_block
fill 273 238 497 273 241 497 minecraft:brown_terracotta
fill 274 238 486 274 238 489 minecraft:brown_terracotta
setblock 274 238 490 minecraft:bone_block
fill 274 238 491 274 241 491 minecraft:brown_terracotta
setblock 274 238 495 minecraft:bone_block
fill 274 238 496 274 241 496 minecraft:brown_terracotta
fill 274 238 498 274 238 499 minecraft:brown_terracotta
setblock 275 238 468 minecraft:brown_terracotta
setblock 275 238 469 minecraft:bone_block
fill 275 238 470 275 241 470 minecraft:brown_terracotta
fill 275 238 472 275 238 473 minecraft:brown_terracotta
setblock 275 238 474 minecraft:bone_block
fill 275 238 475 275 238 478 minecraft:brown_terracotta
setblock 275 238 483 minecraft:brown_terracotta
setblock 275 238 484 minecraft:bone_block
fill 275 238 485 275 238 488 minecraft:brown_terracotta
setblock 275 238 489 minecraft:bone_block
fill 275 238 490 275 241 490 minecraft:brown_terracotta
setblock 275 238 493 minecraft:brown_terracotta
setblock 275 238 494 minecraft:bone_block
fill 275 238 495 275 241 495 minecraft:brown_terracotta
setblock 275 238 498 minecraft:brown_terracotta
setblock 275 238 499 minecraft:bone_block
fill 275 238 500 275 240 501 minecraft:brown_terracotta
setblock 275 238 504 minecraft:bone_block
fill 276 238 466 276 238 467 minecraft:brown_terracotta
setblock 276 238 468 minecraft:bone_block
fill 276 238 469 276 241 469 minecraft:brown_terracotta
setblock 276 238 472 minecraft:brown_terracotta
setblock 276 238 473 minecraft:bone_block
fill 276 238 474 276 238 477 minecraft:brown_terracotta
setblock 276 238 478 minecraft:bone_block
fill 276 238 479 276 238 482 minecraft:brown_terracotta
setblock 276 238 483 minecraft:bone_block
fill 276 238 484 276 238 487 minecraft:brown_terracotta
setblock 276 238 488 minecraft:bone_block
fill 276 238 489 276 241 489 minecraft:brown_terracotta
setblock 276 238 493 minecraft:bone_block
fill 276 238 494 276 241 494 minecraft:brown_terracotta
setblock 276 238 498 minecraft:bone_block
fill 276 238 499 276 241 499 minecraft:brown_terracotta
fill 276 238 501 276 238 502 minecraft:brown_terracotta
setblock 276 238 503 minecraft:bone_block
fill 236 239 465 236 239 466 minecraft:brown_terracotta
setblock 236 239 467 minecraft:bone_block
fill 236 239 468 236 239 471 minecraft:brown_terracotta
setblock 236 239 472 minecraft:bone_block
fill 236 239 473 236 239 476 minecraft:brown_terracotta
setblock 236 239 477 minecraft:bone_block
fill 236 239 478 236 239 481 minecraft:brown_terracotta
setblock 236 239 482 minecraft:bone_block
fill 236 239 483 236 239 486 minecraft:brown_terracotta
setblock 236 239 487 minecraft:bone_block
fill 236 239 488 236 239 491 minecraft:brown_terracotta
setblock 236 239 492 minecraft:bone_block
fill 236 239 493 236 242 493 minecraft:brown_terracotta
setblock 236 239 496 minecraft:brown_terracotta
setblock 236 239 497 minecraft:bone_block
fill 236 239 498 236 242 498 minecraft:brown_terracotta
fill 237 239 468 237 239 470 minecraft:brown_terracotta
setblock 237 239 471 minecraft:bone_block
fill 237 239 472 237 242 472 minecraft:brown_terracotta
setblock 237 239 475 minecraft:brown_terracotta
setblock 237 239 476 minecraft:bone_block
fill 237 239 477 237 242 477 minecraft:brown_terracotta
setblock 237 239 480 minecraft:brown_terracotta
fill 237 239 488 237 239 490 minecraft:brown_terracotta
setblock 237 239 491 minecraft:bone_block
fill 237 239 492 237 240 492 minecraft:brown_terracotta
setblock 237 239 496 minecraft:bone_block
setblock 238 239 471 minecraft:brown_terracotta
setblock 238 239 475 minecraft:bone_block
fill 243 239 485 243 242 485 minecraft:bone_block
fill 243 239 487 243 242 487 minecraft:bone_block
setblock 244 239 464 minecraft:bone_block
fill 245 239 464 248 239 464 minecraft:brown_terracotta
fill 246 239 465 247 239 465 minecraft:brown_terracotta
fill 246 239 485 246 242 485 minecraft:bone_block
fill 246 239 487 246 242 487 minecraft:bone_block
setblock 247 239 466 minecraft:bone_block
setblock 248 239 465 minecraft:bone_block
fill 248 239 466 251 239 466 minecraft:brown_terracotta
setblock 248 239 504 minecraft:brown_terracotta
setblock 249 239 464 minecraft:bone_block
fill 249 239 465 252 239 465 minecraft:brown_terracotta
fill 249 239 467 250 239 467 minecraft:brown_terracotta
fill 249 239 485 249 242 485 minecraft:bone_block
fill 249 239 487 249 242 487 minecraft:bone_block
setblock 249 239 504 minecraft:bone_block
fill 250 239 464 253 239 464 minecraft:brown_terracotta
setblock 250 239 503 minecraft:bone_block
fill 250 239 504 253 239 504 minecraft:brown_terracotta
setblock 251 239 467 minecraft:bone_block
fill 251 239 503 251 242 503 minecraft:brown_terracotta
setblock 252 239 466 minecraft:bone_block
fill 252 239 467 252 240 467 minecraft:brown_terracotta
fill 252 239 485 252 242 485 minecraft:bone_block
setblock 253 239 465 minecraft:bone_block
fill 253 239 466 253 241 466 minecraft:brown_terracotta
setblock 254 239 464 minecraft:bone_block
fill 254 239 465 254 242 465 minecraft:brown_terracotta
setblock 254 239 504 minecraft:bone_block
fill 255 239 464 258 239 464 minecraft:brown_terracotta
setblock 255 239 466 minecraft:brown_terracotta
fill 255 239 485 255 242 485 minecraft:bone_block
fill 255 239 487 255 242 487 minecraft:bone_block
setblock 255 239 503 minecraft:bone_block
fill 255 239 504 255 242 504 minecraft:brown_terracotta
fill 256 239 465 257 239 465 minecraft:brown_terracotta
fill 258 239 485 258 242 485 minecraft:bone_block
fill 258 239 487 258 242 487 minecraft:bone_block
setblock 258 239 504 minecraft:brown_terracotta
setblock 259 239 464 minecraft:bone_block
setblock 259 239 504 minecraft:bone_block
fill 260 239 504 260 242 504 minecraft:brown_terracotta
fill 261 239 485 262 242 485 minecraft:bone_block
fill 261 239 487 261 242 487 minecraft:bone_block
setblock 263 239 504 minecraft:brown_terracotta
fill 264 239 483 267 242 483 minecraft:bone_block
fill 264 239 489 267 242 489 minecraft:bone_block
setblock 264 239 504 minecraft:bone_block
fill 265 239 504 268 239 504 minecraft:brown_terracotta
fill 267 239 464 268 239 464 minecraft:brown_terracotta
fill 267 239 503 269 239 503 minecraft:brown_terracotta
fill 268 239 484 268 242 484 minecraft:bone_block
fill 268 239 488 268 241 488 minecraft:bone_block
setblock 269 239 464 minecraft:bone_block
fill 269 239 486 269 240 486 minecraft:bone_block
setblock 269 239 504 minecraft:bone_block
fill 270 239 464 270 242 464 minecraft:brown_terracotta
setblock 270 239 503 minecraft:bone_block
fill 270 239 504 273 239 504 minecraft:brown_terracotta
fill 271 239 503 271 242 503 minecraft:brown_terracotta
fill 272 239 492 272 239 495 minecraft:brown_terracotta
setblock 272 239 496 minecraft:bone_block
setblock 273 239 464 minecraft:brown_terracotta
setblock 273 239 489 minecraft:brown_terracotta
setblock 273 239 490 minecraft:bone_block
fill 273 239 491 273 241 491 minecraft:brown_terracotta
fill 273 239 493 273 239 494 minecraft:brown_terracotta
setblock 273 239 495 minecraft:bone_block
fill 273 239 496 273 242 496 minecraft:brown_terracotta
fill 273 239 498 274 239 498 minecraft:brown_terracotta
setblock 274 239 464 minecraft:bone_block
fill 274 239 472 274 239 473 minecraft:brown_terracotta
setblock 274 239 474 minecraft:bone_block
fill 274 239 487 274 239 488 minecraft:brown_terracotta
setblock 274 239 489 minecraft:bone_block
fill 274 239 490 274 242 490 minecraft:brown_terracotta
setblock 274 239 493 minecraft:brown_terracotta
setblock 274 239 494 minecraft:bone_block
fill 274 239 495 274 242 495 minecraft:brown_terracotta
setblock 274 239 499 minecraft:bone_block
fill 274 239 500 274 241 500 minecraft:brown_terracotta
setblock 274 239 504 minecraft:bone_block
fill 275 239 469 275 240 469 minecraft:brown_terracotta
setblock 275 239 472 minecraft:brown_terracotta
setblock 275 239 473 minecraft:bone_block
fill 275 239 474 275 239 477 minecraft:brown_terracotta
setblock 275 239 478 minecraft:bone_block
fill 275 239 479 275 239 482 minecraft:brown_terracotta
setblock 275 239 483 minecraft:bone_block
fill 275 239 484 275 239 487 minecraft:brown_terracotta
setblock 275 239 488 minecraft:bone_block
fill 275 239 489 275 242 489 minecraft:brown_terracotta
setblock 275 239 492 minecraft:brown_terracotta
setblock 275 239 493 minecraft:bone_block
fill 275 239 494 275 242 494 minecraft:brown_terracotta
setblock 275 239 497 minecraft:brown_terracotta
setblock 275 239 498 minecraft:bone_block
fill 275 239 499 275 242 499 minecraft:brown_terracotta
fill 275 239 504 275 240 504 minecraft:brown_terracotta
setblock 276 239 467 minecraft:bone_block
fill 276 239 468 276 240 468 minecraft:brown_terracotta
setblock 276 239 472 minecraft:bone_block
fill 276 239 473 276 239 476 minecraft:brown_terracotta
setblock 276 239 477 minecraft:bone_block
fill 276 239 478 276 239 481 minecraft:brown_terracotta
setblock 276 239 482 minecraft:bone_block
fill 276 239 483 276 239 486 minecraft:brown_terracotta
setblock 276 239 487 minecraft:bone_block
fill 276 239 488 276 242 488 minecraft:brown_terracotta
setblock 276 239 492 minecraft:bone_block
fill 276 239 493 276 242 493 minecraft:brown_terracotta
setblock 276 239 497 minecraft:bone_block
fill 276 239 498 276 242 498 minecraft:brown_terracotta
setblock 276 239 501 minecraft:brown_terracotta
setblock 276 239 502 minecraft:bone_block
setblock 276 239 503 minecraft:brown_terracotta
setblock 236 240 466 minecraft:bone_block
fill 236 240 467 236 240 470 minecraft:brown_terracotta
setblock 236 240 471 minecraft:bone_block
fill 236 240 472 236 240 475 minecraft:brown_terracotta
setblock 236 240 476 minecraft:bone_block
fill 236 240 477 236 240 480 minecraft:brown_terracotta
setblock 236 240 481 minecraft:bone_block
fill 236 240 482 236 240 485 minecraft:brown_terracotta
setblock 236 240 486 minecraft:bone_block
fill 236 240 487 236 240 490 minecraft:brown_terracotta
setblock 236 240 491 minecraft:bone_block
fill 236 240 492 236 243 492 minecraft:brown_terracotta
setblock 236 240 496 minecraft:bone_block
fill 236 240 497 236 243 497 minecraft:brown_terracotta
setblock 236 240 500 minecraft:brown_terracotta
setblock 237 240 469 minecraft:brown_terracotta
setblock 237 240 470 minecraft:bone_block
fill 237 240 471 237 243 471 minecraft:brown_terracotta
setblock 237 240 475 minecraft:bone_block
fill 237 240 476 238 242 476 minecraft:brown_terracotta
setblock 237 240 480 minecraft:bone_block
setblock 237 240 490 minecraft:bone_block
setblock 237 240 491 minecraft:brown_terracotta
setblock 237 240 495 minecraft:bone_block
setblock 237 240 496 minecraft:brown_terracotta
setblock 238 240 474 minecraft:bone_block
fill 238 240 475 238 242 475 minecraft:brown_terracotta
fill 242 240 466 246 241 470 minecraft:soul_soil
fill 243 240 481 243 241 481 minecraft:bone_block
fill 243 240 491 243 241 491 minecraft:bone_block
fill 244 240 464 247 240 464 minecraft:brown_terracotta
setblock 244 240 465 minecraft:soul_soil
setblock 246 240 465 minecraft:brown_terracotta
fill 246 240 481 246 241 481 minecraft:bone_block
fill 246 240 491 246 241 491 minecraft:bone_block
setblock 247 240 465 minecraft:bone_block
fill 247 240 466 250 240 466 minecraft:brown_terracotta
setblock 247 240 504 minecraft:brown_terracotta
setblock 248 240 464 minecraft:bone_block
fill 248 240 465 251 240 465 minecraft:brown_terracotta
setblock 248 240 504 minecraft:bone_block
fill 249 240 464 252 240 464 minecraft:brown_terracotta
setblock 249 240 467 minecraft:brown_terracotta
fill 249 240 481 249 241 481 minecraft:bone_block
fill 249 240 491 249 241 491 minecraft:bone_block
setblock 249 240 503 minecraft:bone_block
fill 249 240 504 252 240 504 minecraft:brown_terracotta
setblock 250 240 467 minecraft:bone_block
fill 250 240 503 250 243 503 minecraft:brown_terracotta
setblock 251 240 466 minecraft:bone_block
setblock 251 240 467 minecraft:brown_terracotta
setblock 252 240 465 minecraft:bone_block
fill 252 240 466 252 242 466 minecraft:brown_terracotta
fill 252 240 481 252 241 481 minecraft:bone_block
fill 252 240 491 252 241 491 minecraft:bone_block
fill 252 240 503 253 240 503 minecraft:brown_terracotta
setblock 253 240 464 minecraft:bone_block
fill 253 240 465 253 243 465 minecraft:brown_terracotta
setblock 253 240 504 minecraft:bone_block
fill 254 240 464 257 240 464 minecraft:brown_terracotta
setblock 254 240 503 minecraft:bone_block
fill 254 240 504 254 243 504 minecraft:brown_terracotta
fill 255 240 481 255 241 481 minecraft:bone_block
fill 255 240 491 255 241 491 minecraft:bone_block
fill 255 240 503 256 242 503 minecraft:brown_terracotta
setblock 256 240 465 minecraft:brown_terracotta
setblock 258 240 464 minecraft:bone_block
fill 258 240 481 258 241 481 minecraft:bone_block
fill 258 240 491 258 241 491 minecraft:bone_block
setblock 258 240 504 minecraft:bone_block
setblock 259 240 464 minecraft:brown_terracotta
fill 259 240 504 259 243 504 minecraft:brown_terracotta
fill 261 240 481 261 241 481 minecraft:bone_block
fill 261 240 491 261 241 491 minecraft:bone_block
fill 261 240 504 262 240 504 minecraft:brown_terracotta
fill 262 240 484 262 242 484 minecraft:bone_block
fill 263 240 489 263 242 489 minecraft:bone_block
setblock 263 240 504 minecraft:bone_block
fill 264 240 504 267 240 504 minecraft:brown_terracotta
fill 265 240 490 265 241 490 minecraft:bone_block
fill 266 240 464 267 240 464 minecraft:brown_terracotta
fill 266 240 503 268 240 503 minecraft:brown_terracotta
setblock 268 240 464 minecraft:bone_block
fill 268 240 502 269 240 502 minecraft:brown_terracotta
setblock 268 240 504 minecraft:bone_block
fill 269 240 464 269 243 464 minecraft:brown_terracotta
setblock 269 240 503 minecraft:bone_block
fill 269 240 504 272 240 504 minecraft:brown_terracotta
setblock 270 240 502 minecraft:bone_block
fill 270 240 503 270 243 503 minecraft:brown_terracotta
fill 271 240 502 271 243 502 minecraft:brown_terracotta
fill 272 240 492 272 240 494 minecraft:brown_terracotta
setblock 272 240 495 minecraft:bone_block
fill 272 240 496 272 241 496 minecraft:brown_terracotta
setblock 273 240 464 minecraft:bone_block
setblock 273 240 489 minecraft:bone_block
fill 273 240 490 273 241 490 minecraft:brown_terracotta
setblock 273 240 493 minecraft:brown_terracotta
setblock 273 240 494 minecraft:bone_block
fill 273 240 495 273 243 495 minecraft:brown_terracotta
setblock 273 240 498 minecraft:brown_terracotta
setblock 273 240 504 minecraft:bone_block
setblock 274 240 472 minecraft:brown_terracotta
setblock 274 240 473 minecraft:bone_block
fill 274 240 474 275 240 476 minecraft:brown_terracotta
setblock 274 240 487 minecraft:brown_terracotta
setblock 274 240 488 minecraft:bone_block
fill 274 240 489 274 241 489 minecraft:brown_terracotta
setblock 274 240 493 minecraft:bone_block
fill 274 240 494 274 243 494 minecraft:brown_terracotta
setblock 274 240 498 minecraft:bone_block
fill 274 240 499 274 243 499 minecraft:brown_terracotta
fill 274 240 504 274 242 504 minecraft:brown_terracotta
setblock 275 240 472 minecraft:bone_block
fill 275 240 473 276 242 473 minecraft:brown_terracotta
setblock 275 240 477 minecraft:bone_block
fill 275 240 478 275 240 481 minecraft:brown_terracotta
setblock 275 240 482 minecraft:bone_block
fill 275 240 483 275 240 486 minecraft:brown_terracotta
setblock 275 240 487 minecraft:bone_block
fill 275 240 488 275 242 488 minecraft:brown_terracotta
setblock 275 240 492 minecraft:bone_block
fill 275 240 493 275 243 493 minecraft:brown_terracotta
setblock 275 240 497 minecraft:bone_block
fill 275 240 498 275 243 498 minecraft:brown_terracotta
setblock 276 240 471 minecraft:bone_block
fill 276 240 472 276 243 472 minecraft:brown_terracotta
fill 276 240 474 276 240 475 minecraft:brown_terracotta
setblock 276 240 476 minecraft:bone_block
fill 276 240 477 276 240 480 minecraft:brown_terracotta
setblock 276 240 481 minecraft:bone_block
fill 276 240 482 276 240 485 minecraft:brown_terracotta
setblock 276 240 486 minecraft:bone_block
fill 276 240 487 276 243 487 minecraft:brown_terracotta
setblock 276 240 491 minecraft:bone_block
fill 276 240 492 276 243 492 minecraft:brown_terracotta
setblock 276 240 496 minecraft:bone_block
fill 276 240 497 276 243 497 minecraft:brown_terracotta
setblock 276 240 501 minecraft:bone_block
fill 276 240 502 276 242 502 minecraft:brown_terracotta
fill 236 241 467 236 241 469 minecraft:brown_terracotta
setblock 236 241 470 minecraft:bone_block
fill 236 241 471 236 241 474 minecraft:brown_terracotta
setblock 236 241 475 minecraft:bone_block
fill 236 241 476 236 241 479 minecraft:brown_terracotta
setblock 236 241 480 minecraft:bone_block
fill 236 241 481 236 241 484 minecraft:brown_terracotta
setblock 236 241 485 minecraft:bone_block
fill 236 241 486 236 241 489 minecraft:brown_terracotta
setblock 236 241 490 minecraft:bone_block
fill 236 241 491 236 243 491 minecraft:brown_terracotta
setblock 236 241 495 minecraft:bone_block
fill 236 241 496 236 244 496 minecraft:brown_terracotta
setblock 236 241 500 minecraft:bone_block
setblock 237 241 469 minecraft:bone_block
fill 237 241 470 237 242 470 minecraft:brown_terracotta
setblock 237 241 473 minecraft:brown_terracotta
setblock 237 241 474 minecraft:bone_block
fill 237 241 475 237 244 475 minecraft:brown_terracotta
setblock 237 241 478 minecraft:brown_terracotta
setblock 237 241 479 minecraft:bone_block
fill 237 241 480 237 243 480 minecraft:brown_terracotta
setblock 237 241 494 minecraft:bone_block
setblock 237 241 495 minecraft:brown_terracotta
fill 237 241 496 237 244 496 minecraft:bone_block
setblock 238 241 473 minecraft:bone_block
fill 238 241 474 238 242 474 minecraft:brown_terracotta
fill 238 241 495 238 244 495 minecraft:bone_block
fill 238 241 497 238 244 497 minecraft:bone_block
fill 239 241 496 239 244 496 minecraft:bone_block
fill 243 241 482 243 242 482 minecraft:bone_block
fill 243 241 490 243 242 490 minecraft:bone_block
fill 244 241 464 246 241 464 minecraft:brown_terracotta
setblock 245 241 465 minecraft:brown_terracotta
setblock 246 241 465 minecraft:bone_block
fill 246 241 482 246 242 482 minecraft:bone_block
fill 246 241 490 246 242 490 minecraft:bone_block
setblock 246 241 504 minecraft:brown_terracotta
setblock 247 241 464 minecraft:bone_block
fill 247 241 465 249 241 466 minecraft:brown_terracotta
setblock 247 241 504 minecraft:bone_block
fill 248 241 464 251 241 464 minecraft:brown_terracotta
setblock 248 241 503 minecraft:bone_block
fill 248 241 504 251 241 504 minecraft:brown_terracotta
fill 249 241 482 249 242 482 minecraft:bone_block
fill 249 241 490 249 242 490 minecraft:bone_block
fill 249 241 503 249 244 503 minecraft:brown_terracotta
setblock 250 241 465 minecraft:brown_terracotta
setblock 250 241 466 minecraft:bone_block
setblock 251 241 465 minecraft:bone_block
fill 251 241 466 251 242 466 minecraft:brown_terracotta
setblock 252 241 464 minecraft:bone_block
fill 252 241 465 252 244 465 minecraft:brown_terracotta
fill 252 241 482 252 242 482 minecraft:bone_block
fill 252 241 490 252 242 490 minecraft:bone_block
setblock 252 241 503 minecraft:brown_terracotta
setblock 252 241 504 minecraft:bone_block
fill 253 241 464 256 241 464 minecraft:brown_terracotta
setblock 253 241 503 minecraft:bone_block
fill 253 241 504 253 244 504 minecraft:brown_terracotta
fill 254 241 503 254 244 503 minecraft:brown_terracotta
fill 255 241 482 255 242 482 minecraft:bone_block
fill 255 241 490 255 242 490 minecraft:bone_block
setblock 257 241 464 minecraft:bone_block
setblock 257 241 504 minecraft:bone_block
setblock 258 241 464 minecraft:brown_terracotta
fill 258 241 482 258 242 482 minecraft:bone_block
fill 258 241 490 258 242 490 minecraft:bone_block
fill 258 241 504 258 244 504 minecraft:brown_terracotta
fill 261 241 482 261 242 482 minecraft:bone_block
fill 261 241 490 261 242 490 minecraft:bone_block
setblock 261 241 504 minecraft:brown_terracotta
setblock 262 241 504 minecraft:bone_block
fill 263 241 504 266 241 504 minecraft:brown_terracotta
fill 265 241 503 267 241 503 minecraft:brown_terracotta
setblock 266 241 482 minecraft:bone_block
setblock 266 241 490 minecraft:bone_block
setblock 267 241 464 minecraft:bone_block
fill 267 241 502 268 241 502 minecraft:brown_terracotta
setblock 267 241 504 minecraft:bone_block
fill 268 241 464 268 243 464 minecraft:brown_terracotta
setblock 268 241 503 minecraft:bone_block
fill 268 241 504 271 241 504 minecraft:brown_terracotta
setblock 269 241 502 minecraft:bone_block
fill 269 241 503 269 244 503 minecraft:brown_terracotta
fill 270 241 502 270 244 502 minecraft:brown_terracotta
setblock 272 241 464 minecraft:bone_block
setblock 272 241 493 minecraft:brown_terracotta
setblock 272 241 494 minecraft:bone_block
setblock 272 241 495 minecraft:brown_terracotta
setblock 272 241 504 minecraft:bone_block
setblock 273 241 493 minecraft:bone_block
fill 273 241 494 273 243 494 minecraft:brown_terracotta
setblock 273 241 498 minecraft:bone_block
setblock 273 241 503 minecraft:bone_block
fill 273 241 504 273 244 504 minecraft:brown_terracotta
fill 274 241 473 274 241 476 minecraft:brown_terracotta
setblock 274 241 477 minecraft:bone_block
setblock 274 241 488 minecraft:brown_terracotta
setblock 274 241 492 minecraft:bone_block
fill 274 241 493 274 243 493 minecraft:brown_terracotta
setblock 274 241 497 minecraft:bone_block
fill 274 241 498 274 243 498 minecraft:brown_terracotta
setblock 275 241 471 minecraft:bone_block
fill 275 241 472 275 242 472 minecraft:brown_terracotta
fill 275 241 474 275 241 475 minecraft:brown_terracotta
setblock 275 241 476 minecraft:bone_block
fill 275 241 477 275 241 480 minecraft:brown_terracotta
setblock 275 241 481 minecraft:bone_block
fill 275 241 482 275 241 485 minecraft:brown_terracotta
setblock 275 241 486 minecraft:bone_block
fill 275 241 487 275 242 487 minecraft:brown_terracotta
setblock 275 241 491 minecraft:bone_block
fill 275 241 492 275 244 492 minecraft:brown_terracotta
setblock 275 241 496 minecraft:bone_block
fill 275 241 497 275 244 497 minecraft:brown_terracotta
setblock 275 241 500 minecraft:brown_terracotta
setblock 275 241 501 minecraft:bone_block
setblock 276 241 470 minecraft:bone_block
fill 276 241 471 276 243 471 minecraft:brown_terracotta
setblock 276 241 474 minecraft:brown_terracotta
setblock 276 241 475 minecraft:bone_block
fill 276 241 476 276 241 479 minecraft:brown_terracotta
setblock 276 241 480 minecraft:bone_block
fill 276 241 481 276 241 484 minecraft:brown_terracotta
setblock 276 241 485 minecraft:bone_block
fill 276 241 486 276 243 486 minecraft:brown_terracotta
setblock 276 241 490 minecraft:bone_block
fill 276 241 491 276 244 491 minecraft:brown_terracotta
setblock 276 241 495 minecraft:bone_block
fill 276 241 496 276 244 496 minecraft:brown_terracotta
setblock 276 241 500 minecraft:bone_block
fill 276 241 501 276 244 501 minecraft:brown_terracotta
setblock 236 242 468 minecraft:brown_terracotta
setblock 236 242 469 minecraft:bone_block
fill 236 242 470 236 242 473 minecraft:brown_terracotta
setblock 236 242 474 minecraft:bone_block
fill 236 242 475 236 242 478 minecraft:brown_terracotta
setblock 236 242 479 minecraft:bone_block
fill 236 242 480 236 242 483 minecraft:brown_terracotta
setblock 236 242 484 minecraft:bone_block
fill 236 242 485 236 242 488 minecraft:brown_terracotta
setblock 236 242 489 minecraft:bone_block
setblock 236 242 490 minecraft:brown_terracotta
setblock 236 242 494 minecraft:bone_block
fill 236 242 495 236 243 495 minecraft:brown_terracotta
setblock 236 242 499 minecraft:bone_block
setblock 237 242 473 minecraft:bone_block
fill 237 242 474 237 245 474 minecraft:brown_terracotta
setblock 237 242 478 minecraft:bone_block
fill 237 242 479 237 245 479 minecraft:brown_terracotta
fill 237 242 495 237 244 495 minecraft:bone_block
fill 237 242 497 237 244 497 minecraft:bone_block
setblock 238 242 473 minecraft:brown_terracotta
fill 239 242 495 239 244 495 minecraft:bone_block
fill 239 242 497 239 244 497 minecraft:bone_block
fill 239 242 499 239 252 499 minecraft:bone_block
fill 240 242 467 242 243 467 minecraft:bone_block
fill 240 242 469 242 243 469 minecraft:bone_block
fill 241 242 468 241 243 468 minecraft:bone_block
fill 241 242 486 251 243 486 minecraft:bone_block
fill 243 242 464 245 242 464 minecraft:brown_terracotta
fill 243 242 483 243 242 484 minecraft:bone_block
fill 243 242 488 243 242 489 minecraft:bone_block
setblock 245 242 465 minecraft:bone_block
setblock 245 242 504 minecraft:brown_terracotta
setblock 246 242 464 minecraft:bone_block
fill 246 242 465 249 242 465 minecraft:brown_terracotta
fill 246 242 483 246 242 484 minecraft:bone_block
fill 246 242 488 246 242 489 minecraft:bone_block
setblock 246 242 504 minecraft:bone_block
fill 247 242 464 250 242 464 minecraft:brown_terracotta
fill 247 242 466 248 242 466 minecraft:brown_terracotta
setblock 247 242 503 minecraft:bone_block
fill 247 242 504 250 242 504 minecraft:brown_terracotta
fill 248 242 503 248 245 503 minecraft:brown_terracotta
setblock 249 242 466 minecraft:bone_block
fill 249 242 483 249 242 484 minecraft:bone_block
fill 249 242 488 249 242 489 minecraft:bone_block
setblock 250 242 465 minecraft:bone_block
fill 250 242 466 250 243 466 minecraft:brown_terracotta
fill 250 242 502 252 242 502 minecraft:brown_terracotta
setblock 251 242 464 minecraft:bone_block
fill 251 242 465 251 244 465 minecraft:brown_terracotta
setblock 251 242 504 minecraft:bone_block
fill 252 242 464 255 242 464 minecraft:brown_terracotta
fill 252 242 483 252 242 484 minecraft:bone_block
fill 252 242 488 252 242 489 minecraft:bone_block
setblock 252 242 503 minecraft:bone_block
fill 252 242 504 252 245 504 minecraft:brown_terracotta
fill 253 242 503 253 245 503 minecraft:brown_terracotta
fill 255 242 483 255 242 484 minecraft:bone_block
fill 255 242 486 261 243 486 minecraft:bone_block
fill 255 242 488 255 242 489 minecraft:bone_block
setblock 256 242 464 minecraft:bone_block
setblock 256 242 504 minecraft:bone_block
setblock 257 242 464 minecraft:brown_terracotta
fill 257 242 504 257 245 504 minecraft:brown_terracotta
fill 258 242 483 258 242 484 minecraft:bone_block
fill 258 242 488 258 242 489 minecraft:bone_block
fill 261 242 483 261 242 484 minecraft:bone_block
fill 261 242 488 261 242 489 minecraft:bone_block
setblock 261 242 504 minecraft:bone_block
fill 262 242 504 265 242 504 minecraft:brown_terracotta
fill 264 242 503 266 242 503 minecraft:brown_terracotta
fill 266 242 502 267 242 502 minecraft:brown_terracotta
setblock 266 242 504 minecraft:bone_block
setblock 267 242 464 minecraft:brown_terracotta
setblock 267 242 503 minecraft:bone_block
fill 267 242 504 270 242 504 minecraft:brown_terracotta
setblock 268 242 502 minecraft:bone_block
fill 268 242 503 268 245 503 minecraft:brown_terracotta
fill 269 242 502 269 245 502 minecraft:brown_terracotta
setblock 271 242 464 minecraft:bone_block
setblock 271 242 504 minecraft:bone_block
setblock 272 242 503 minecraft:bone_block
fill 272 242 504 272 245 504 minecraft:brown_terracotta
setblock 273 242 492 minecraft:bone_block
setblock 273 242 493 minecraft:brown_terracotta
setblock 273 242 497 minecraft:bone_block
setblock 273 242 498 minecraft:brown_terracotta
setblock 273 242 503 minecraft:brown_terracotta
fill 274 242 474 274 242 475 minecraft:brown_terracotta
setblock 274 242 476 minecraft:bone_block
fill 274 242 477 276 242 477 minecraft:brown_terracotta
setblock 274 242 491 minecraft:bone_block
fill 274 242 492 274 243 492 minecraft:brown_terracotta
setblock 274 242 496 minecraft:bone_block
fill 274 242 497 274 244 497 minecraft:brown_terracotta
setblock 275 242 474 minecraft:brown_terracotta
setblock 275 242 475 minecraft:bone_block
fill 275 242 476 276 244 476 minecraft:brown_terracotta
fill 275 242 478 275 242 479 minecraft:brown_terracotta
setblock 275 242 480 minecraft:bone_block
fill 275 242 481 276 242 482 minecraft:brown_terracotta
setblock 275 242 486 minecraft:brown_terracotta
setblock 275 242 490 minecraft:bone_block
fill 275 242 491 275 243 491 minecraft:brown_terracotta
setblock 275 242 495 minecraft:bone_block
fill 275 242 496 275 245 496 minecraft:brown_terracotta
setblock 275 242 500 minecraft:bone_block
setblock 275 242 501 minecraft:brown_terracotta
setblock 276 242 470 minecraft:brown_terracotta
setblock 276 242 474 minecraft:bone_block
fill 276 242 475 276 245 475 minecraft:brown_terracotta
setblock 276 242 478 minecraft:brown_terracotta
setblock 276 242 479 minecraft:bone_block
fill 276 242 480 276 245 480 minecraft:brown_terracotta
setblock 276 242 483 minecraft:brown_terracotta
setblock 276 242 484 minecraft:bone_block
fill 276 242 485 276 244 485 minecraft:brown_terracotta
setblock 276 242 489 minecraft:bone_block
fill 276 242 490 276 244 490 minecraft:brown_terracotta
setblock 276 242 494 minecraft:bone_block
fill 276 242 495 276 245 495 minecraft:brown_terracotta
setblock 276 242 499 minecraft:bone_block
fill 276 242 500 276 245 500 minecraft:brown_terracotta
fill 236 243 469 236 243 472 minecraft:brown_terracotta
setblock 236 243 473 minecraft:bone_block
fill 236 243 474 236 243 477 minecraft:brown_terracotta
setblock 236 243 478 minecraft:bone_block
fill 236 243 479 236 243 482 minecraft:brown_terracotta
setblock 236 243 483 minecraft:bone_block
setblock 236 243 484 minecraft:brown_terracotta
setblock 236 243 493 minecraft:bone_block
setblock 236 243 494 minecraft:brown_terracotta
setblock 236 243 498 minecraft:bone_block
setblock 236 243 499 minecraft:brown_terracotta
setblock 237 243 472 minecraft:bone_block
fill 237 243 473 237 244 473 minecraft:brown_terracotta
setblock 237 243 476 minecraft:brown_terracotta
setblock 237 243 477 minecraft:bone_block
fill 237 243 478 237 246 478 minecraft:brown_terracotta
setblock 238 243 466 minecraft:light[level=12]
setblock 238 243 474 minecraft:light[level=12]
setblock 238 243 482 minecraft:light[level=12]
setblock 238 243 490 minecraft:light[level=12]
setblock 238 243 498 minecraft:light[level=12]
fill 242 243 468 243 244 468 minecraft:bone_block
fill 243 243 464 244 243 464 minecraft:brown_terracotta
setblock 245 243 464 minecraft:bone_block
fill 245 243 465 248 243 465 minecraft:brown_terracotta
setblock 245 243 504 minecraft:bone_block
fill 246 243 464 249 243 464 minecraft:brown_terracotta
setblock 246 243 466 minecraft:light[level=12]
setblock 246 243 474 minecraft:light[level=12]
setblock 246 243 482 minecraft:light[level=12]
setblock 246 243 490 minecraft:light[level=12]
setblock 246 243 498 minecraft:light[level=12]
fill 246 243 504 249 243 504 minecraft:brown_terracotta
fill 247 243 503 247 246 503 minecraft:brown_terracotta
setblock 248 243 466 minecraft:bone_block
schedule function dropper:buildpart/113_8 1t
