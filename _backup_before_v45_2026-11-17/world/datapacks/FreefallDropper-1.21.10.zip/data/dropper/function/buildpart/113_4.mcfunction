fill 236 119 503 236 121 504 minecraft:brown_terracotta
fill 237 119 464 237 119 465 minecraft:brown_terracotta
setblock 237 119 466 minecraft:bone_block
fill 237 119 467 237 119 470 minecraft:brown_terracotta
setblock 237 119 471 minecraft:bone_block
fill 237 119 472 237 122 472 minecraft:brown_terracotta
setblock 237 119 476 minecraft:bone_block
fill 237 119 477 237 122 477 minecraft:brown_terracotta
setblock 237 119 491 minecraft:bone_block
fill 237 119 492 237 122 492 minecraft:brown_terracotta
setblock 237 119 495 minecraft:brown_terracotta
setblock 237 119 496 minecraft:bone_block
fill 237 119 497 237 122 497 minecraft:brown_terracotta
fill 237 119 504 238 119 504 minecraft:brown_terracotta
setblock 238 119 464 minecraft:brown_terracotta
setblock 238 119 465 minecraft:bone_block
fill 238 119 466 238 120 466 minecraft:brown_terracotta
setblock 238 119 470 minecraft:bone_block
fill 238 119 471 238 122 471 minecraft:brown_terracotta
setblock 238 119 475 minecraft:bone_block
setblock 239 119 464 minecraft:bone_block
fill 239 119 465 239 122 465 minecraft:brown_terracotta
setblock 239 119 504 minecraft:bone_block
fill 240 119 464 240 122 464 minecraft:brown_terracotta
fill 240 119 504 241 121 504 minecraft:brown_terracotta
fill 251 119 504 251 121 504 minecraft:brown_terracotta
setblock 253 119 464 minecraft:brown_terracotta
setblock 254 119 464 minecraft:bone_block
setblock 254 119 503 minecraft:brown_terracotta
setblock 254 119 504 minecraft:bone_block
fill 255 119 464 255 122 464 minecraft:brown_terracotta
setblock 255 119 503 minecraft:bone_block
fill 255 119 504 255 122 504 minecraft:brown_terracotta
fill 256 119 503 256 122 503 minecraft:brown_terracotta
fill 257 119 504 258 119 504 minecraft:brown_terracotta
setblock 259 119 504 minecraft:bone_block
setblock 274 119 464 minecraft:bone_block
setblock 274 119 469 minecraft:bone_block
fill 274 119 470 274 122 470 minecraft:brown_terracotta
setblock 274 119 474 minecraft:bone_block
fill 274 119 475 274 122 475 minecraft:brown_terracotta
fill 274 119 477 274 119 478 minecraft:brown_terracotta
fill 275 119 464 275 122 464 minecraft:brown_terracotta
setblock 275 119 468 minecraft:bone_block
fill 275 119 469 275 122 469 minecraft:brown_terracotta
setblock 275 119 473 minecraft:bone_block
fill 275 119 474 275 122 474 minecraft:brown_terracotta
setblock 275 119 478 minecraft:bone_block
fill 275 119 479 275 122 479 minecraft:brown_terracotta
fill 275 119 481 275 119 482 minecraft:brown_terracotta
setblock 275 119 483 minecraft:bone_block
fill 275 119 485 275 121 485 minecraft:brown_terracotta
setblock 275 119 488 minecraft:bone_block
fill 275 119 489 275 122 489 minecraft:brown_terracotta
setblock 275 119 493 minecraft:bone_block
fill 275 119 494 275 122 494 minecraft:brown_terracotta
fill 275 119 496 275 120 496 minecraft:brown_terracotta
setblock 276 119 467 minecraft:bone_block
fill 276 119 468 276 122 468 minecraft:brown_terracotta
setblock 276 119 472 minecraft:bone_block
fill 276 119 473 276 122 473 minecraft:brown_terracotta
setblock 276 119 477 minecraft:bone_block
fill 276 119 478 276 122 478 minecraft:brown_terracotta
setblock 276 119 482 minecraft:bone_block
fill 276 119 483 276 122 483 minecraft:brown_terracotta
setblock 276 119 487 minecraft:bone_block
fill 276 119 488 276 122 488 minecraft:brown_terracotta
setblock 276 119 492 minecraft:bone_block
fill 276 119 493 276 122 493 minecraft:brown_terracotta
setblock 276 119 497 minecraft:bone_block
fill 276 119 498 276 120 500 minecraft:brown_terracotta
fill 236 120 464 236 120 465 minecraft:brown_terracotta
setblock 236 120 466 minecraft:bone_block
fill 236 120 467 236 120 470 minecraft:brown_terracotta
setblock 236 120 471 minecraft:bone_block
fill 236 120 472 236 120 475 minecraft:brown_terracotta
setblock 236 120 476 minecraft:bone_block
fill 236 120 477 236 123 477 minecraft:brown_terracotta
setblock 236 120 481 minecraft:bone_block
fill 236 120 482 236 122 483 minecraft:brown_terracotta
setblock 236 120 486 minecraft:bone_block
fill 236 120 487 236 122 487 minecraft:brown_terracotta
setblock 236 120 491 minecraft:bone_block
fill 236 120 492 236 123 492 minecraft:brown_terracotta
setblock 236 120 496 minecraft:bone_block
fill 236 120 497 236 123 497 minecraft:brown_terracotta
fill 236 120 499 236 120 500 minecraft:brown_terracotta
setblock 236 120 501 minecraft:bone_block
fill 236 120 502 236 123 502 minecraft:brown_terracotta
setblock 237 120 464 minecraft:brown_terracotta
setblock 237 120 465 minecraft:bone_block
fill 237 120 466 237 120 469 minecraft:brown_terracotta
setblock 237 120 470 minecraft:bone_block
fill 237 120 471 237 123 471 minecraft:brown_terracotta
setblock 237 120 475 minecraft:bone_block
fill 237 120 476 238 122 476 minecraft:brown_terracotta
setblock 237 120 479 minecraft:brown_terracotta
fill 237 120 491 237 121 491 minecraft:brown_terracotta
setblock 237 120 495 minecraft:bone_block
fill 237 120 496 237 123 496 minecraft:brown_terracotta
setblock 237 120 499 minecraft:brown_terracotta
setblock 237 120 500 minecraft:bone_block
fill 237 120 501 237 123 501 minecraft:brown_terracotta
setblock 237 120 504 minecraft:brown_terracotta
setblock 238 120 464 minecraft:bone_block
fill 238 120 465 238 123 465 minecraft:brown_terracotta
setblock 238 120 469 minecraft:bone_block
fill 238 120 470 238 123 470 minecraft:brown_terracotta
setblock 238 120 474 minecraft:bone_block
fill 238 120 475 238 123 475 minecraft:brown_terracotta
setblock 238 120 504 minecraft:bone_block
fill 239 120 464 239 123 464 minecraft:brown_terracotta
fill 239 120 504 239 123 504 minecraft:brown_terracotta
fill 240 120 465 240 121 465 minecraft:brown_terracotta
fill 249 120 504 250 122 504 minecraft:brown_terracotta
setblock 252 120 464 minecraft:brown_terracotta
fill 252 120 503 253 120 503 minecraft:brown_terracotta
setblock 253 120 464 minecraft:bone_block
setblock 253 120 504 minecraft:bone_block
fill 254 120 464 254 123 464 minecraft:brown_terracotta
setblock 254 120 503 minecraft:bone_block
fill 254 120 504 254 123 504 minecraft:brown_terracotta
fill 255 120 503 255 123 503 minecraft:brown_terracotta
fill 257 120 503 257 120 504 minecraft:brown_terracotta
setblock 258 120 504 minecraft:bone_block
fill 259 120 504 259 123 504 minecraft:brown_terracotta
setblock 273 120 464 minecraft:bone_block
fill 273 120 472 273 120 473 minecraft:brown_terracotta
setblock 273 120 474 minecraft:bone_block
fill 273 120 475 273 123 475 minecraft:brown_terracotta
fill 274 120 464 274 123 464 minecraft:brown_terracotta
setblock 274 120 468 minecraft:bone_block
fill 274 120 469 274 123 469 minecraft:brown_terracotta
setblock 274 120 472 minecraft:brown_terracotta
setblock 274 120 473 minecraft:bone_block
fill 274 120 474 274 123 474 minecraft:brown_terracotta
setblock 274 120 477 minecraft:brown_terracotta
setblock 274 120 478 minecraft:bone_block
fill 274 120 479 274 123 479 minecraft:brown_terracotta
setblock 274 120 493 minecraft:bone_block
fill 275 120 465 275 121 465 minecraft:brown_terracotta
setblock 275 120 467 minecraft:bone_block
fill 275 120 468 275 123 468 minecraft:brown_terracotta
setblock 275 120 472 minecraft:bone_block
fill 275 120 473 275 123 473 minecraft:brown_terracotta
setblock 275 120 477 minecraft:bone_block
fill 275 120 478 275 123 478 minecraft:brown_terracotta
setblock 275 120 481 minecraft:brown_terracotta
setblock 275 120 482 minecraft:bone_block
fill 275 120 483 275 122 484 minecraft:brown_terracotta
setblock 275 120 487 minecraft:bone_block
fill 275 120 488 275 123 488 minecraft:brown_terracotta
setblock 275 120 492 minecraft:bone_block
fill 275 120 493 275 123 493 minecraft:brown_terracotta
setblock 275 120 497 minecraft:bone_block
fill 275 120 498 275 123 498 minecraft:brown_terracotta
setblock 276 120 466 minecraft:bone_block
fill 276 120 467 276 123 467 minecraft:brown_terracotta
setblock 276 120 471 minecraft:bone_block
fill 276 120 472 276 123 472 minecraft:brown_terracotta
setblock 276 120 476 minecraft:bone_block
fill 276 120 477 276 123 477 minecraft:brown_terracotta
setblock 276 120 481 minecraft:bone_block
fill 276 120 482 276 123 482 minecraft:brown_terracotta
setblock 276 120 486 minecraft:bone_block
fill 276 120 487 276 123 487 minecraft:brown_terracotta
setblock 276 120 491 minecraft:bone_block
fill 276 120 492 276 123 492 minecraft:brown_terracotta
setblock 276 120 496 minecraft:bone_block
fill 276 120 497 276 123 497 minecraft:brown_terracotta
setblock 276 120 501 minecraft:bone_block
fill 276 120 502 276 123 502 minecraft:brown_terracotta
setblock 236 121 464 minecraft:brown_terracotta
setblock 236 121 465 minecraft:bone_block
fill 236 121 466 236 121 469 minecraft:brown_terracotta
setblock 236 121 470 minecraft:bone_block
fill 236 121 471 236 121 474 minecraft:brown_terracotta
setblock 236 121 475 minecraft:bone_block
fill 236 121 476 236 124 476 minecraft:brown_terracotta
setblock 236 121 480 minecraft:bone_block
fill 236 121 481 236 124 481 minecraft:brown_terracotta
setblock 236 121 484 minecraft:brown_terracotta
setblock 236 121 486 minecraft:brown_terracotta
setblock 236 121 490 minecraft:bone_block
fill 236 121 491 236 124 491 minecraft:brown_terracotta
setblock 236 121 495 minecraft:bone_block
fill 236 121 496 236 124 496 minecraft:brown_terracotta
setblock 236 121 499 minecraft:brown_terracotta
setblock 236 121 500 minecraft:bone_block
fill 236 121 501 236 124 501 minecraft:brown_terracotta
setblock 237 121 464 minecraft:bone_block
fill 237 121 465 237 121 468 minecraft:brown_terracotta
setblock 237 121 469 minecraft:bone_block
fill 237 121 470 237 124 470 minecraft:brown_terracotta
setblock 237 121 474 minecraft:bone_block
fill 237 121 475 237 124 475 minecraft:brown_terracotta
setblock 237 121 479 minecraft:bone_block
setblock 237 121 494 minecraft:bone_block
fill 237 121 495 237 124 495 minecraft:brown_terracotta
setblock 237 121 499 minecraft:bone_block
fill 237 121 500 237 124 500 minecraft:brown_terracotta
fill 237 121 502 237 121 503 minecraft:brown_terracotta
setblock 237 121 504 minecraft:bone_block
fill 238 121 464 238 124 464 minecraft:brown_terracotta
setblock 238 121 468 minecraft:bone_block
fill 238 121 469 238 123 469 minecraft:brown_terracotta
setblock 238 121 473 minecraft:bone_block
fill 238 121 474 238 124 474 minecraft:brown_terracotta
setblock 238 121 503 minecraft:bone_block
fill 238 121 504 238 124 504 minecraft:brown_terracotta
setblock 242 121 464 minecraft:bone_block
setblock 242 121 504 minecraft:bone_block
fill 243 121 504 243 124 504 minecraft:brown_terracotta
setblock 247 121 504 minecraft:bone_block
fill 248 121 504 248 124 504 minecraft:brown_terracotta
fill 250 121 503 252 121 503 minecraft:brown_terracotta
setblock 251 121 464 minecraft:brown_terracotta
setblock 252 121 464 minecraft:bone_block
setblock 252 121 504 minecraft:bone_block
fill 253 121 464 253 124 464 minecraft:brown_terracotta
setblock 253 121 502 minecraft:brown_terracotta
setblock 253 121 503 minecraft:bone_block
fill 253 121 504 253 124 504 minecraft:brown_terracotta
setblock 254 121 502 minecraft:bone_block
fill 254 121 503 254 124 503 minecraft:brown_terracotta
fill 255 121 502 256 123 502 minecraft:brown_terracotta
setblock 257 121 503 minecraft:brown_terracotta
setblock 257 121 504 minecraft:bone_block
setblock 258 121 503 minecraft:bone_block
fill 258 121 504 258 124 504 minecraft:brown_terracotta
setblock 272 121 464 minecraft:bone_block
fill 273 121 464 273 124 464 minecraft:brown_terracotta
fill 273 121 471 273 121 472 minecraft:brown_terracotta
setblock 273 121 473 minecraft:bone_block
fill 273 121 474 273 124 474 minecraft:brown_terracotta
fill 273 121 476 273 121 477 minecraft:brown_terracotta
fill 274 121 465 274 122 465 minecraft:brown_terracotta
fill 274 121 468 274 124 468 minecraft:brown_terracotta
setblock 274 121 472 minecraft:bone_block
fill 274 121 473 274 124 473 minecraft:brown_terracotta
setblock 274 121 477 minecraft:bone_block
fill 274 121 478 274 124 478 minecraft:brown_terracotta
fill 274 121 480 274 121 481 minecraft:brown_terracotta
setblock 274 121 492 minecraft:bone_block
fill 274 121 493 274 122 495 minecraft:brown_terracotta
setblock 275 121 466 minecraft:bone_block
fill 275 121 467 275 124 467 minecraft:brown_terracotta
setblock 275 121 471 minecraft:bone_block
fill 275 121 472 275 124 472 minecraft:brown_terracotta
setblock 275 121 476 minecraft:bone_block
fill 275 121 477 275 124 477 minecraft:brown_terracotta
setblock 275 121 481 minecraft:bone_block
fill 275 121 482 275 124 482 minecraft:brown_terracotta
setblock 275 121 486 minecraft:bone_block
fill 275 121 487 275 123 487 minecraft:brown_terracotta
setblock 275 121 491 minecraft:bone_block
fill 275 121 492 275 124 492 minecraft:brown_terracotta
setblock 275 121 496 minecraft:bone_block
fill 275 121 497 275 124 497 minecraft:brown_terracotta
fill 275 121 499 276 121 499 minecraft:brown_terracotta
fill 275 121 504 276 121 504 minecraft:brown_terracotta
setblock 276 121 465 minecraft:bone_block
fill 276 121 466 276 124 466 minecraft:brown_terracotta
setblock 276 121 470 minecraft:bone_block
fill 276 121 471 276 124 471 minecraft:brown_terracotta
setblock 276 121 475 minecraft:bone_block
fill 276 121 476 276 124 476 minecraft:brown_terracotta
setblock 276 121 480 minecraft:bone_block
fill 276 121 481 276 124 481 minecraft:brown_terracotta
setblock 276 121 485 minecraft:bone_block
fill 276 121 486 276 124 486 minecraft:brown_terracotta
setblock 276 121 490 minecraft:bone_block
fill 276 121 491 276 124 491 minecraft:brown_terracotta
setblock 276 121 495 minecraft:bone_block
fill 276 121 496 276 124 496 minecraft:brown_terracotta
fill 276 121 498 276 122 498 minecraft:brown_terracotta
setblock 276 121 500 minecraft:bone_block
fill 276 121 501 276 124 501 minecraft:brown_terracotta
fill 276 121 503 276 122 503 minecraft:brown_terracotta
setblock 236 122 464 minecraft:bone_block
fill 236 122 465 236 122 468 minecraft:brown_terracotta
setblock 236 122 469 minecraft:bone_block
fill 236 122 470 236 122 473 minecraft:brown_terracotta
setblock 236 122 474 minecraft:bone_block
fill 236 122 475 236 125 475 minecraft:brown_terracotta
setblock 236 122 479 minecraft:bone_block
fill 236 122 480 237 124 480 minecraft:brown_terracotta
setblock 236 122 484 minecraft:bone_block
setblock 236 122 489 minecraft:bone_block
fill 236 122 490 236 124 490 minecraft:brown_terracotta
setblock 236 122 494 minecraft:bone_block
fill 236 122 495 236 125 495 minecraft:brown_terracotta
setblock 236 122 498 minecraft:brown_terracotta
setblock 236 122 499 minecraft:bone_block
fill 236 122 500 236 125 500 minecraft:brown_terracotta
setblock 236 122 503 minecraft:brown_terracotta
setblock 236 122 504 minecraft:bone_block
fill 237 122 464 237 122 467 minecraft:brown_terracotta
setblock 237 122 468 minecraft:bone_block
fill 237 122 469 237 125 469 minecraft:brown_terracotta
setblock 237 122 473 minecraft:bone_block
fill 237 122 474 237 125 474 minecraft:brown_terracotta
setblock 237 122 478 minecraft:bone_block
fill 237 122 479 237 125 479 minecraft:brown_terracotta
setblock 237 122 493 minecraft:bone_block
fill 237 122 494 237 125 494 minecraft:brown_terracotta
setblock 237 122 498 minecraft:bone_block
fill 237 122 499 238 124 499 minecraft:brown_terracotta
setblock 237 122 502 minecraft:brown_terracotta
setblock 237 122 503 minecraft:bone_block
fill 237 122 504 237 125 504 minecraft:brown_terracotta
setblock 238 122 468 minecraft:brown_terracotta
setblock 238 122 472 minecraft:bone_block
fill 238 122 473 238 124 473 minecraft:brown_terracotta
setblock 238 122 496 minecraft:brown_terracotta
setblock 238 122 497 minecraft:bone_block
fill 238 122 498 238 125 498 minecraft:brown_terracotta
fill 238 122 503 239 124 503 minecraft:brown_terracotta
setblock 240 122 504 minecraft:brown_terracotta
setblock 241 122 464 minecraft:bone_block
setblock 241 122 504 minecraft:bone_block
setblock 242 122 464 minecraft:brown_terracotta
fill 242 122 504 242 125 504 minecraft:brown_terracotta
fill 244 122 504 245 122 504 minecraft:brown_terracotta
setblock 246 122 504 minecraft:bone_block
fill 247 122 504 247 125 504 minecraft:brown_terracotta
fill 248 122 503 251 122 503 minecraft:brown_terracotta
setblock 250 122 464 minecraft:brown_terracotta
setblock 251 122 464 minecraft:bone_block
fill 251 122 502 252 122 502 minecraft:brown_terracotta
setblock 251 122 504 minecraft:bone_block
fill 252 122 464 252 125 464 minecraft:brown_terracotta
setblock 252 122 503 minecraft:bone_block
fill 252 122 504 252 125 504 minecraft:brown_terracotta
setblock 253 122 502 minecraft:bone_block
fill 253 122 503 253 125 503 minecraft:brown_terracotta
fill 254 122 502 254 125 502 minecraft:brown_terracotta
setblock 256 122 464 minecraft:bone_block
setblock 256 122 504 minecraft:bone_block
setblock 257 122 503 minecraft:bone_block
fill 257 122 504 257 125 504 minecraft:brown_terracotta
fill 258 122 503 258 124 503 minecraft:brown_terracotta
fill 272 122 464 272 125 464 minecraft:brown_terracotta
fill 273 122 465 273 123 465 minecraft:brown_terracotta
fill 273 122 470 273 122 471 minecraft:brown_terracotta
setblock 273 122 472 minecraft:bone_block
fill 273 122 473 273 125 473 minecraft:brown_terracotta
setblock 273 122 476 minecraft:brown_terracotta
setblock 273 122 477 minecraft:bone_block
fill 273 122 478 273 124 479 minecraft:brown_terracotta
fill 273 122 504 275 122 504 minecraft:brown_terracotta
fill 274 122 467 274 124 467 minecraft:brown_terracotta
setblock 274 122 471 minecraft:bone_block
fill 274 122 472 274 125 472 minecraft:brown_terracotta
setblock 274 122 476 minecraft:bone_block
fill 274 122 477 274 125 477 minecraft:brown_terracotta
setblock 274 122 480 minecraft:brown_terracotta
setblock 274 122 481 minecraft:bone_block
fill 274 122 482 274 125 482 minecraft:brown_terracotta
setblock 274 122 492 minecraft:brown_terracotta
setblock 274 122 496 minecraft:bone_block
fill 274 122 497 274 125 497 minecraft:brown_terracotta
setblock 275 122 465 minecraft:bone_block
fill 275 122 466 275 125 466 minecraft:brown_terracotta
setblock 275 122 470 minecraft:bone_block
fill 275 122 471 275 125 471 minecraft:brown_terracotta
setblock 275 122 475 minecraft:bone_block
fill 275 122 476 275 125 476 minecraft:brown_terracotta
setblock 275 122 480 minecraft:bone_block
fill 275 122 481 275 125 481 minecraft:brown_terracotta
setblock 275 122 485 minecraft:bone_block
fill 275 122 486 275 123 486 minecraft:brown_terracotta
setblock 275 122 490 minecraft:bone_block
fill 275 122 491 275 124 491 minecraft:brown_terracotta
setblock 275 122 495 minecraft:bone_block
fill 275 122 496 275 125 496 minecraft:brown_terracotta
setblock 275 122 499 minecraft:brown_terracotta
setblock 275 122 500 minecraft:bone_block
fill 275 122 501 275 125 501 minecraft:brown_terracotta
setblock 276 122 464 minecraft:bone_block
fill 276 122 465 276 125 465 minecraft:brown_terracotta
setblock 276 122 469 minecraft:bone_block
fill 276 122 470 276 125 470 minecraft:brown_terracotta
setblock 276 122 474 minecraft:bone_block
fill 276 122 475 276 125 475 minecraft:brown_terracotta
setblock 276 122 479 minecraft:bone_block
fill 276 122 480 276 125 480 minecraft:brown_terracotta
setblock 276 122 484 minecraft:bone_block
fill 276 122 485 276 125 485 minecraft:brown_terracotta
setblock 276 122 489 minecraft:bone_block
fill 276 122 490 276 125 490 minecraft:brown_terracotta
setblock 276 122 494 minecraft:bone_block
fill 276 122 495 276 125 495 minecraft:brown_terracotta
setblock 276 122 499 minecraft:bone_block
fill 276 122 500 276 125 500 minecraft:brown_terracotta
setblock 276 122 504 minecraft:bone_block
fill 236 123 464 236 123 467 minecraft:brown_terracotta
setblock 236 123 468 minecraft:bone_block
fill 236 123 469 236 123 472 minecraft:brown_terracotta
setblock 236 123 473 minecraft:bone_block
fill 236 123 474 236 126 474 minecraft:brown_terracotta
setblock 236 123 478 minecraft:bone_block
fill 236 123 479 236 126 479 minecraft:brown_terracotta
setblock 236 123 482 minecraft:brown_terracotta
setblock 236 123 483 minecraft:bone_block
fill 236 123 484 236 124 484 minecraft:brown_terracotta
setblock 236 123 488 minecraft:bone_block
setblock 236 123 489 minecraft:brown_terracotta
setblock 236 123 493 minecraft:bone_block
fill 236 123 494 236 126 494 minecraft:brown_terracotta
setblock 236 123 498 minecraft:bone_block
fill 236 123 499 236 126 499 minecraft:brown_terracotta
setblock 236 123 503 minecraft:bone_block
fill 236 123 504 236 126 504 minecraft:brown_terracotta
fill 237 123 464 237 123 466 minecraft:brown_terracotta
setblock 237 123 467 minecraft:bone_block
fill 237 123 468 237 125 468 minecraft:brown_terracotta
setblock 237 123 472 minecraft:bone_block
fill 237 123 473 237 126 473 minecraft:brown_terracotta
setblock 237 123 476 minecraft:brown_terracotta
setblock 237 123 477 minecraft:bone_block
fill 237 123 478 237 126 478 minecraft:brown_terracotta
setblock 237 123 492 minecraft:bone_block
fill 237 123 493 237 124 493 minecraft:brown_terracotta
setblock 237 123 497 minecraft:bone_block
fill 237 123 498 237 126 498 minecraft:brown_terracotta
setblock 237 123 502 minecraft:bone_block
fill 237 123 503 237 126 503 minecraft:brown_terracotta
setblock 238 123 466 minecraft:light[level=12]
setblock 238 123 471 minecraft:bone_block
fill 238 123 472 238 124 472 minecraft:brown_terracotta
setblock 238 123 476 minecraft:bone_block
setblock 238 123 482 minecraft:light[level=12]
setblock 238 123 490 minecraft:light[level=12]
setblock 238 123 496 minecraft:bone_block
fill 238 123 497 238 124 497 minecraft:brown_terracotta
setblock 238 123 500 minecraft:brown_terracotta
setblock 239 123 465 minecraft:bone_block
setblock 240 123 464 minecraft:bone_block
setblock 240 123 503 minecraft:brown_terracotta
setblock 240 123 504 minecraft:bone_block
fill 241 123 464 241 124 464 minecraft:brown_terracotta
fill 241 123 504 241 126 504 minecraft:brown_terracotta
setblock 244 123 504 minecraft:brown_terracotta
setblock 245 123 504 minecraft:bone_block
setblock 246 123 466 minecraft:light[level=12]
setblock 246 123 474 minecraft:light[level=12]
setblock 246 123 482 minecraft:light[level=12]
setblock 246 123 490 minecraft:light[level=12]
setblock 246 123 498 minecraft:light[level=12]
fill 246 123 504 246 126 504 minecraft:brown_terracotta
fill 247 123 503 250 123 503 minecraft:brown_terracotta
fill 249 123 502 251 123 502 minecraft:brown_terracotta
setblock 249 123 504 minecraft:brown_terracotta
setblock 250 123 464 minecraft:bone_block
setblock 250 123 504 minecraft:bone_block
fill 251 123 464 251 126 464 minecraft:brown_terracotta
fill 251 123 501 252 123 501 minecraft:brown_terracotta
setblock 251 123 503 minecraft:bone_block
fill 251 123 504 251 126 504 minecraft:brown_terracotta
setblock 252 123 502 minecraft:bone_block
fill 252 123 503 252 126 503 minecraft:brown_terracotta
setblock 253 123 501 minecraft:bone_block
fill 253 123 502 253 126 502 minecraft:brown_terracotta
setblock 254 123 466 minecraft:light[level=12]
setblock 254 123 474 minecraft:light[level=12]
setblock 254 123 490 minecraft:light[level=12]
setblock 254 123 498 minecraft:light[level=12]
fill 254 123 501 255 125 501 minecraft:brown_terracotta
setblock 255 123 464 minecraft:bone_block
setblock 255 123 504 minecraft:bone_block
setblock 256 123 464 minecraft:brown_terracotta
setblock 256 123 503 minecraft:bone_block
fill 256 123 504 256 126 504 minecraft:brown_terracotta
setblock 257 123 502 minecraft:bone_block
fill 257 123 503 257 126 503 minecraft:brown_terracotta
setblock 262 123 466 minecraft:light[level=12]
setblock 262 123 474 minecraft:light[level=12]
setblock 262 123 482 minecraft:light[level=12]
setblock 262 123 490 minecraft:light[level=12]
setblock 262 123 498 minecraft:light[level=12]
fill 265 123 481 266 124 481 minecraft:soul_soil
fill 266 123 480 266 124 480 minecraft:soul_soil
fill 266 123 482 266 124 482 minecraft:soul_soil
setblock 270 123 466 minecraft:light[level=12]
setblock 270 123 474 minecraft:light[level=12]
setblock 270 123 482 minecraft:light[level=12]
setblock 270 123 490 minecraft:light[level=12]
setblock 270 123 498 minecraft:light[level=12]
fill 271 123 464 271 126 464 minecraft:brown_terracotta
fill 272 123 474 272 123 476 minecraft:brown_terracotta
fill 272 123 504 274 123 504 minecraft:brown_terracotta
setblock 273 123 470 minecraft:brown_terracotta
setblock 273 123 471 minecraft:bone_block
fill 273 123 472 273 126 472 minecraft:brown_terracotta
setblock 273 123 476 minecraft:bone_block
fill 273 123 477 273 126 477 minecraft:brown_terracotta
setblock 273 123 480 minecraft:brown_terracotta
setblock 274 123 465 minecraft:bone_block
setblock 274 123 470 minecraft:bone_block
fill 274 123 471 274 126 471 minecraft:brown_terracotta
setblock 274 123 475 minecraft:bone_block
fill 274 123 476 274 126 476 minecraft:brown_terracotta
setblock 274 123 480 minecraft:bone_block
fill 274 123 481 274 126 481 minecraft:brown_terracotta
fill 274 123 493 274 123 494 minecraft:brown_terracotta
setblock 274 123 495 minecraft:bone_block
fill 274 123 496 274 124 496 minecraft:brown_terracotta
fill 274 123 498 274 124 498 minecraft:brown_terracotta
setblock 275 123 464 minecraft:bone_block
fill 275 123 465 275 126 465 minecraft:brown_terracotta
setblock 275 123 469 minecraft:bone_block
fill 275 123 470 275 126 470 minecraft:brown_terracotta
setblock 275 123 474 minecraft:bone_block
fill 275 123 475 275 126 475 minecraft:brown_terracotta
setblock 275 123 479 minecraft:bone_block
fill 275 123 480 275 126 480 minecraft:brown_terracotta
setblock 275 123 483 minecraft:brown_terracotta
setblock 275 123 484 minecraft:bone_block
fill 275 123 485 275 125 485 minecraft:brown_terracotta
setblock 275 123 489 minecraft:bone_block
fill 275 123 490 275 124 490 minecraft:brown_terracotta
setblock 275 123 494 minecraft:bone_block
fill 275 123 495 275 126 495 minecraft:brown_terracotta
setblock 275 123 499 minecraft:bone_block
fill 275 123 500 275 126 500 minecraft:brown_terracotta
fill 275 123 502 275 124 502 minecraft:brown_terracotta
setblock 275 123 504 minecraft:bone_block
fill 276 123 464 276 126 464 minecraft:brown_terracotta
setblock 276 123 468 minecraft:bone_block
fill 276 123 469 276 126 469 minecraft:brown_terracotta
setblock 276 123 473 minecraft:bone_block
fill 276 123 474 276 126 474 minecraft:brown_terracotta
setblock 276 123 478 minecraft:bone_block
fill 276 123 479 276 126 479 minecraft:brown_terracotta
setblock 276 123 483 minecraft:bone_block
fill 276 123 484 276 126 484 minecraft:brown_terracotta
setblock 276 123 488 minecraft:bone_block
fill 276 123 489 276 125 489 minecraft:brown_terracotta
setblock 276 123 493 minecraft:bone_block
fill 276 123 494 276 126 494 minecraft:brown_terracotta
setblock 276 123 498 minecraft:bone_block
fill 276 123 499 276 126 499 minecraft:brown_terracotta
setblock 276 123 503 minecraft:bone_block
fill 276 123 504 276 126 504 minecraft:brown_terracotta
fill 236 124 464 236 124 466 minecraft:brown_terracotta
setblock 236 124 467 minecraft:bone_block
fill 236 124 468 236 124 471 minecraft:brown_terracotta
setblock 236 124 472 minecraft:bone_block
fill 236 124 473 236 127 473 minecraft:brown_terracotta
setblock 236 124 477 minecraft:bone_block
fill 236 124 478 236 127 478 minecraft:brown_terracotta
setblock 236 124 482 minecraft:bone_block
fill 236 124 483 236 126 483 minecraft:brown_terracotta
setblock 236 124 492 minecraft:bone_block
fill 236 124 493 236 126 493 minecraft:brown_terracotta
setblock 236 124 497 minecraft:bone_block
fill 236 124 498 236 127 498 minecraft:brown_terracotta
setblock 236 124 502 minecraft:bone_block
fill 236 124 503 236 127 503 minecraft:brown_terracotta
fill 237 124 464 237 124 465 minecraft:brown_terracotta
setblock 237 124 466 minecraft:bone_block
fill 237 124 467 237 125 467 minecraft:brown_terracotta
setblock 237 124 471 minecraft:bone_block
fill 237 124 472 237 126 472 minecraft:brown_terracotta
setblock 237 124 476 minecraft:bone_block
fill 237 124 477 237 127 477 minecraft:brown_terracotta
setblock 237 124 496 minecraft:bone_block
fill 237 124 497 237 127 497 minecraft:brown_terracotta
setblock 237 124 501 minecraft:bone_block
fill 237 124 502 237 127 502 minecraft:brown_terracotta
setblock 238 124 465 minecraft:bone_block
setblock 238 124 475 minecraft:bone_block
setblock 238 124 476 minecraft:brown_terracotta
setblock 238 124 500 minecraft:bone_block
fill 238 124 501 238 126 501 minecraft:brown_terracotta
setblock 239 124 464 minecraft:bone_block
setblock 239 124 504 minecraft:bone_block
fill 240 124 464 240 125 464 minecraft:brown_terracotta
setblock 240 124 503 minecraft:bone_block
fill 240 124 504 240 127 504 minecraft:brown_terracotta
fill 241 124 503 242 126 503 minecraft:brown_terracotta
setblock 244 124 503 minecraft:brown_terracotta
setblock 244 124 504 minecraft:bone_block
setblock 245 124 503 minecraft:bone_block
fill 245 124 504 245 127 504 minecraft:brown_terracotta
fill 246 124 503 249 124 503 minecraft:brown_terracotta
fill 248 124 502 250 124 502 minecraft:brown_terracotta
setblock 249 124 464 minecraft:bone_block
setblock 249 124 504 minecraft:bone_block
fill 250 124 464 250 127 464 minecraft:brown_terracotta
fill 250 124 501 251 124 501 minecraft:brown_terracotta
setblock 250 124 503 minecraft:bone_block
fill 250 124 504 250 127 504 minecraft:brown_terracotta
setblock 251 124 502 minecraft:bone_block
fill 251 124 503 251 127 503 minecraft:brown_terracotta
setblock 252 124 501 minecraft:bone_block
fill 252 124 502 252 127 502 minecraft:brown_terracotta
fill 253 124 501 253 127 501 minecraft:brown_terracotta
setblock 254 124 464 minecraft:bone_block
setblock 254 124 504 minecraft:bone_block
fill 255 124 464 255 125 464 minecraft:brown_terracotta
setblock 255 124 502 minecraft:brown_terracotta
setblock 255 124 503 minecraft:bone_block
fill 255 124 504 255 127 504 minecraft:brown_terracotta
setblock 256 124 502 minecraft:bone_block
fill 256 124 503 256 127 503 minecraft:brown_terracotta
setblock 257 124 502 minecraft:brown_terracotta
setblock 259 124 504 minecraft:bone_block
fill 270 124 464 270 127 464 minecraft:brown_terracotta
fill 270 124 504 273 124 504 minecraft:brown_terracotta
setblock 272 124 465 minecraft:brown_terracotta
fill 272 124 474 272 124 475 minecraft:brown_terracotta
setblock 272 124 476 minecraft:bone_block
fill 272 124 477 272 126 477 minecraft:brown_terracotta
setblock 273 124 465 minecraft:bone_block
setblock 273 124 470 minecraft:bone_block
fill 273 124 471 273 125 471 minecraft:brown_terracotta
setblock 273 124 475 minecraft:bone_block
fill 273 124 476 273 127 476 minecraft:brown_terracotta
setblock 273 124 480 minecraft:bone_block
fill 273 124 503 274 124 503 minecraft:brown_terracotta
setblock 274 124 464 minecraft:bone_block
fill 274 124 465 274 127 465 minecraft:brown_terracotta
setblock 274 124 469 minecraft:bone_block
fill 274 124 470 274 126 470 minecraft:brown_terracotta
setblock 274 124 474 minecraft:bone_block
fill 274 124 475 274 127 475 minecraft:brown_terracotta
setblock 274 124 479 minecraft:bone_block
fill 274 124 480 274 127 480 minecraft:brown_terracotta
setblock 274 124 483 minecraft:brown_terracotta
setblock 274 124 495 minecraft:brown_terracotta
setblock 274 124 499 minecraft:bone_block
setblock 274 124 504 minecraft:bone_block
fill 275 124 464 275 127 464 minecraft:brown_terracotta
setblock 275 124 468 minecraft:bone_block
fill 275 124 469 275 127 469 minecraft:brown_terracotta
setblock 275 124 473 minecraft:bone_block
fill 275 124 474 275 127 474 minecraft:brown_terracotta
setblock 275 124 478 minecraft:bone_block
fill 275 124 479 275 127 479 minecraft:brown_terracotta
setblock 275 124 483 minecraft:bone_block
fill 275 124 484 275 126 484 minecraft:brown_terracotta
setblock 275 124 493 minecraft:bone_block
fill 275 124 494 275 125 494 minecraft:brown_terracotta
setblock 275 124 498 minecraft:bone_block
fill 275 124 499 275 127 499 minecraft:brown_terracotta
setblock 275 124 503 minecraft:bone_block
fill 275 124 504 275 127 504 minecraft:brown_terracotta
setblock 276 124 467 minecraft:bone_block
fill 276 124 468 276 127 468 minecraft:brown_terracotta
setblock 276 124 472 minecraft:bone_block
fill 276 124 473 276 127 473 minecraft:brown_terracotta
setblock 276 124 477 minecraft:bone_block
fill 276 124 478 276 127 478 minecraft:brown_terracotta
setblock 276 124 482 minecraft:bone_block
fill 276 124 483 276 127 483 minecraft:brown_terracotta
setblock 276 124 487 minecraft:bone_block
fill 276 124 488 276 125 488 minecraft:brown_terracotta
setblock 276 124 492 minecraft:bone_block
fill 276 124 493 276 126 493 minecraft:brown_terracotta
setblock 276 124 497 minecraft:bone_block
fill 276 124 498 276 127 498 minecraft:brown_terracotta
setblock 276 124 502 minecraft:bone_block
fill 276 124 503 276 127 503 minecraft:brown_terracotta
fill 236 125 464 236 125 465 minecraft:brown_terracotta
setblock 236 125 466 minecraft:bone_block
fill 236 125 467 236 125 470 minecraft:brown_terracotta
setblock 236 125 471 minecraft:bone_block
fill 236 125 472 236 128 472 minecraft:brown_terracotta
setblock 236 125 476 minecraft:bone_block
fill 236 125 477 236 128 477 minecraft:brown_terracotta
setblock 236 125 480 minecraft:brown_terracotta
setblock 236 125 481 minecraft:bone_block
fill 236 125 482 236 128 482 minecraft:brown_terracotta
setblock 236 125 491 minecraft:bone_block
fill 236 125 492 236 126 492 minecraft:brown_terracotta
setblock 236 125 496 minecraft:bone_block
fill 236 125 497 236 128 497 minecraft:brown_terracotta
setblock 236 125 501 minecraft:bone_block
fill 236 125 502 236 128 502 minecraft:brown_terracotta
setblock 237 125 464 minecraft:brown_terracotta
setblock 237 125 465 minecraft:bone_block
setblock 237 125 466 minecraft:brown_terracotta
setblock 237 125 470 minecraft:bone_block
fill 237 125 471 237 126 471 minecraft:brown_terracotta
setblock 237 125 475 minecraft:bone_block
fill 237 125 476 237 127 476 minecraft:brown_terracotta
setblock 237 125 480 minecraft:bone_block
setblock 237 125 495 minecraft:bone_block
fill 237 125 496 237 127 496 minecraft:brown_terracotta
setblock 237 125 499 minecraft:brown_terracotta
setblock 237 125 500 minecraft:bone_block
fill 237 125 501 237 128 501 minecraft:brown_terracotta
setblock 238 125 464 minecraft:bone_block
setblock 238 125 499 minecraft:bone_block
fill 238 125 500 238 126 500 minecraft:brown_terracotta
setblock 238 125 503 minecraft:brown_terracotta
setblock 238 125 504 minecraft:bone_block
fill 239 125 464 239 127 464 minecraft:brown_terracotta
setblock 239 125 503 minecraft:bone_block
fill 239 125 504 239 128 504 minecraft:brown_terracotta
fill 240 125 503 240 128 503 minecraft:brown_terracotta
setblock 243 125 503 minecraft:brown_terracotta
setblock 243 125 504 minecraft:bone_block
setblock 244 125 503 minecraft:bone_block
fill 244 125 504 244 128 504 minecraft:brown_terracotta
fill 245 125 503 248 125 503 minecraft:brown_terracotta
fill 247 125 502 249 125 502 minecraft:brown_terracotta
setblock 248 125 504 minecraft:bone_block
fill 249 125 464 249 128 464 minecraft:brown_terracotta
fill 249 125 501 250 125 501 minecraft:brown_terracotta
setblock 249 125 503 minecraft:bone_block
fill 249 125 504 249 128 504 minecraft:brown_terracotta
setblock 250 125 502 minecraft:bone_block
fill 250 125 503 250 128 503 minecraft:brown_terracotta
setblock 251 125 501 minecraft:bone_block
fill 251 125 502 251 128 502 minecraft:brown_terracotta
fill 252 125 501 252 128 501 minecraft:brown_terracotta
setblock 253 125 464 minecraft:bone_block
setblock 253 125 504 minecraft:bone_block
fill 254 125 464 254 126 464 minecraft:brown_terracotta
setblock 254 125 503 minecraft:bone_block
fill 254 125 504 254 128 504 minecraft:brown_terracotta
setblock 255 125 502 minecraft:bone_block
fill 255 125 503 255 128 503 minecraft:brown_terracotta
fill 256 125 502 256 126 502 minecraft:brown_terracotta
setblock 258 125 504 minecraft:bone_block
setblock 259 125 504 minecraft:brown_terracotta
fill 269 125 504 272 125 504 minecraft:brown_terracotta
setblock 272 125 465 minecraft:bone_block
setblock 272 125 474 minecraft:brown_terracotta
setblock 272 125 475 minecraft:bone_block
fill 272 125 476 272 126 476 minecraft:brown_terracotta
fill 272 125 478 273 125 478 minecraft:brown_terracotta
fill 272 125 503 273 125 503 minecraft:brown_terracotta
setblock 273 125 464 minecraft:bone_block
fill 273 125 465 273 128 465 minecraft:brown_terracotta
setblock 273 125 474 minecraft:bone_block
fill 273 125 475 273 128 475 minecraft:brown_terracotta
setblock 273 125 479 minecraft:bone_block
fill 273 125 480 273 126 481 minecraft:brown_terracotta
setblock 273 125 504 minecraft:bone_block
fill 274 125 464 274 128 464 minecraft:brown_terracotta
setblock 274 125 468 minecraft:bone_block
fill 274 125 469 274 126 469 minecraft:brown_terracotta
setblock 274 125 473 minecraft:bone_block
fill 274 125 474 274 128 474 minecraft:brown_terracotta
setblock 274 125 478 minecraft:bone_block
fill 274 125 479 274 128 479 minecraft:brown_terracotta
setblock 274 125 483 minecraft:bone_block
setblock 274 125 498 minecraft:bone_block
setblock 274 125 499 minecraft:brown_terracotta
setblock 274 125 503 minecraft:bone_block
fill 274 125 504 274 128 504 minecraft:brown_terracotta
setblock 275 125 467 minecraft:bone_block
fill 275 125 468 275 127 468 minecraft:brown_terracotta
setblock 275 125 472 minecraft:bone_block
fill 275 125 473 275 128 473 minecraft:brown_terracotta
setblock 275 125 477 minecraft:bone_block
fill 275 125 478 275 128 478 minecraft:brown_terracotta
setblock 275 125 482 minecraft:bone_block
fill 275 125 483 275 128 483 minecraft:brown_terracotta
setblock 275 125 493 minecraft:brown_terracotta
setblock 275 125 497 minecraft:bone_block
fill 275 125 498 275 127 498 minecraft:brown_terracotta
setblock 275 125 502 minecraft:bone_block
fill 275 125 503 275 128 503 minecraft:brown_terracotta
setblock 276 125 466 minecraft:bone_block
fill 276 125 467 276 128 467 minecraft:brown_terracotta
setblock 276 125 471 minecraft:bone_block
fill 276 125 472 276 128 472 minecraft:brown_terracotta
setblock 276 125 476 minecraft:bone_block
fill 276 125 477 276 128 477 minecraft:brown_terracotta
setblock 276 125 481 minecraft:bone_block
fill 276 125 482 276 128 482 minecraft:brown_terracotta
setblock 276 125 486 minecraft:bone_block
setblock 276 125 487 minecraft:brown_terracotta
setblock 276 125 491 minecraft:bone_block
fill 276 125 492 276 126 492 minecraft:brown_terracotta
setblock 276 125 496 minecraft:bone_block
fill 276 125 497 276 128 497 minecraft:brown_terracotta
setblock 276 125 501 minecraft:bone_block
fill 276 125 502 276 128 502 minecraft:brown_terracotta
setblock 236 126 464 minecraft:brown_terracotta
setblock 236 126 465 minecraft:bone_block
fill 236 126 466 236 126 469 minecraft:brown_terracotta
setblock 236 126 470 minecraft:bone_block
fill 236 126 471 236 128 471 minecraft:brown_terracotta
setblock 236 126 475 minecraft:bone_block
fill 236 126 476 236 129 476 minecraft:brown_terracotta
setblock 236 126 480 minecraft:bone_block
fill 236 126 481 236 129 481 minecraft:brown_terracotta
setblock 236 126 495 minecraft:bone_block
fill 236 126 496 236 129 496 minecraft:brown_terracotta
setblock 236 126 500 minecraft:bone_block
fill 236 126 501 236 129 501 minecraft:brown_terracotta
setblock 237 126 464 minecraft:bone_block
setblock 237 126 474 minecraft:bone_block
fill 237 126 475 237 127 475 minecraft:brown_terracotta
setblock 237 126 479 minecraft:bone_block
setblock 237 126 495 minecraft:brown_terracotta
setblock 237 126 499 minecraft:bone_block
fill 237 126 500 237 129 500 minecraft:brown_terracotta
setblock 237 126 504 minecraft:bone_block
fill 238 126 464 238 128 464 minecraft:brown_terracotta
setblock 238 126 499 minecraft:brown_terracotta
setblock 238 126 503 minecraft:bone_block
fill 238 126 504 238 129 504 minecraft:brown_terracotta
fill 239 126 503 239 129 503 minecraft:brown_terracotta
setblock 242 126 504 minecraft:bone_block
setblock 243 126 503 minecraft:bone_block
fill 243 126 504 243 129 504 minecraft:brown_terracotta
fill 244 126 503 247 126 503 minecraft:brown_terracotta
fill 246 126 502 248 126 502 minecraft:brown_terracotta
setblock 247 126 504 minecraft:bone_block
setblock 248 126 503 minecraft:bone_block
fill 248 126 504 248 129 504 minecraft:brown_terracotta
setblock 249 126 501 minecraft:brown_terracotta
setblock 249 126 502 minecraft:bone_block
fill 249 126 503 249 129 503 minecraft:brown_terracotta
setblock 250 126 501 minecraft:bone_block
fill 250 126 502 250 129 502 minecraft:brown_terracotta
fill 251 126 501 251 129 501 minecraft:brown_terracotta
setblock 252 126 464 minecraft:bone_block
setblock 252 126 504 minecraft:bone_block
fill 253 126 464 253 127 464 minecraft:brown_terracotta
setblock 253 126 503 minecraft:bone_block
fill 253 126 504 253 129 504 minecraft:brown_terracotta
setblock 254 126 501 minecraft:brown_terracotta
setblock 254 126 502 minecraft:bone_block
fill 254 126 503 254 129 503 minecraft:brown_terracotta
fill 255 126 502 255 127 502 minecraft:brown_terracotta
setblock 257 126 504 minecraft:bone_block
fill 258 126 504 258 127 504 minecraft:brown_terracotta
fill 269 126 464 269 128 464 minecraft:brown_terracotta
fill 269 126 504 271 126 504 minecraft:brown_terracotta
fill 271 126 503 272 126 503 minecraft:brown_terracotta
setblock 272 126 464 minecraft:bone_block
fill 272 126 465 272 129 465 minecraft:brown_terracotta
setblock 272 126 478 minecraft:brown_terracotta
setblock 272 126 504 minecraft:bone_block
fill 273 126 464 273 129 464 minecraft:brown_terracotta
setblock 273 126 473 minecraft:bone_block
fill 273 126 474 273 127 474 minecraft:brown_terracotta
setblock 273 126 478 minecraft:bone_block
fill 273 126 479 273 128 479 minecraft:brown_terracotta
setblock 273 126 503 minecraft:bone_block
fill 273 126 504 273 129 504 minecraft:brown_terracotta
setblock 274 126 472 minecraft:bone_block
fill 274 126 473 274 128 473 minecraft:brown_terracotta
setblock 274 126 477 minecraft:bone_block
fill 274 126 478 274 129 478 minecraft:brown_terracotta
setblock 274 126 482 minecraft:bone_block
fill 274 126 503 274 129 503 minecraft:brown_terracotta
setblock 275 126 466 minecraft:bone_block
fill 275 126 467 275 127 467 minecraft:brown_terracotta
setblock 275 126 471 minecraft:bone_block
fill 275 126 472 275 129 472 minecraft:brown_terracotta
setblock 275 126 476 minecraft:bone_block
fill 275 126 477 275 129 477 minecraft:brown_terracotta
setblock 275 126 481 minecraft:bone_block
fill 275 126 482 275 129 482 minecraft:brown_terracotta
setblock 275 126 496 minecraft:bone_block
fill 275 126 497 275 127 497 minecraft:brown_terracotta
setblock 275 126 501 minecraft:bone_block
fill 275 126 502 275 129 502 minecraft:brown_terracotta
setblock 276 126 465 minecraft:bone_block
fill 276 126 466 276 129 466 minecraft:brown_terracotta
setblock 276 126 470 minecraft:bone_block
fill 276 126 471 276 129 471 minecraft:brown_terracotta
setblock 276 126 475 minecraft:bone_block
fill 276 126 476 276 129 476 minecraft:brown_terracotta
setblock 276 126 480 minecraft:bone_block
fill 276 126 481 276 129 481 minecraft:brown_terracotta
setblock 276 126 485 minecraft:bone_block
setblock 276 126 486 minecraft:brown_terracotta
setblock 276 126 495 minecraft:bone_block
fill 276 126 496 276 128 496 minecraft:brown_terracotta
setblock 276 126 500 minecraft:bone_block
fill 276 126 501 276 129 501 minecraft:brown_terracotta
setblock 236 127 464 minecraft:bone_block
fill 236 127 465 236 127 468 minecraft:brown_terracotta
setblock 236 127 469 minecraft:bone_block
fill 236 127 470 236 128 470 minecraft:brown_terracotta
setblock 236 127 474 minecraft:bone_block
fill 236 127 475 236 129 475 minecraft:brown_terracotta
setblock 236 127 479 minecraft:bone_block
fill 236 127 480 236 129 480 minecraft:brown_terracotta
setblock 236 127 494 minecraft:bone_block
fill 236 127 495 236 128 495 minecraft:brown_terracotta
setblock 236 127 499 minecraft:bone_block
fill 236 127 500 236 130 500 minecraft:brown_terracotta
setblock 236 127 504 minecraft:bone_block
fill 237 127 464 237 130 464 minecraft:brown_terracotta
setblock 237 127 498 minecraft:bone_block
fill 237 127 499 237 129 499 minecraft:brown_terracotta
setblock 237 127 503 minecraft:bone_block
fill 237 127 504 237 130 504 minecraft:brown_terracotta
fill 238 127 503 238 130 503 minecraft:brown_terracotta
fill 239 127 476 239 131 476 minecraft:soul_soil
setblock 241 127 503 minecraft:brown_terracotta
setblock 241 127 504 minecraft:bone_block
setblock 242 127 503 minecraft:bone_block
fill 242 127 504 242 130 504 minecraft:brown_terracotta
fill 243 127 503 246 127 503 minecraft:brown_terracotta
fill 246 127 502 247 127 502 minecraft:brown_terracotta
setblock 246 127 504 minecraft:bone_block
setblock 247 127 503 minecraft:bone_block
fill 247 127 504 247 130 504 minecraft:brown_terracotta
setblock 248 127 501 minecraft:brown_terracotta
setblock 248 127 502 minecraft:bone_block
fill 248 127 503 248 130 503 minecraft:brown_terracotta
setblock 249 127 501 minecraft:bone_block
fill 249 127 502 249 130 502 minecraft:brown_terracotta
fill 250 127 501 250 129 501 minecraft:brown_terracotta
setblock 251 127 464 minecraft:bone_block
setblock 251 127 504 minecraft:bone_block
fill 252 127 464 252 128 464 minecraft:brown_terracotta
setblock 252 127 503 minecraft:bone_block
fill 252 127 504 252 130 504 minecraft:brown_terracotta
setblock 253 127 502 minecraft:bone_block
fill 253 127 503 253 130 503 minecraft:brown_terracotta
fill 254 127 502 254 128 502 minecraft:brown_terracotta
setblock 256 127 504 minecraft:bone_block
fill 257 127 504 257 128 504 minecraft:brown_terracotta
fill 268 127 504 270 127 504 minecraft:brown_terracotta
fill 270 127 503 271 127 503 minecraft:brown_terracotta
setblock 271 127 464 minecraft:bone_block
setblock 271 127 504 minecraft:bone_block
fill 272 127 464 272 130 464 minecraft:brown_terracotta
setblock 272 127 503 minecraft:bone_block
fill 272 127 504 272 130 504 minecraft:brown_terracotta
setblock 273 127 473 minecraft:brown_terracotta
setblock 273 127 477 minecraft:bone_block
fill 273 127 478 273 128 478 minecraft:brown_terracotta
fill 273 127 480 273 128 480 minecraft:brown_terracotta
fill 273 127 503 273 130 503 minecraft:brown_terracotta
setblock 274 127 471 minecraft:bone_block
fill 274 127 472 274 128 472 minecraft:brown_terracotta
setblock 274 127 476 minecraft:bone_block
fill 274 127 477 274 130 477 minecraft:brown_terracotta
setblock 274 127 481 minecraft:bone_block
fill 274 127 482 274 128 482 minecraft:brown_terracotta
setblock 275 127 465 minecraft:bone_block
setblock 275 127 466 minecraft:brown_terracotta
setblock 275 127 470 minecraft:bone_block
fill 275 127 471 275 128 471 minecraft:brown_terracotta
setblock 275 127 475 minecraft:bone_block
fill 275 127 476 275 130 476 minecraft:brown_terracotta
setblock 275 127 480 minecraft:bone_block
fill 275 127 481 275 130 481 minecraft:brown_terracotta
setblock 275 127 500 minecraft:bone_block
fill 275 127 501 275 129 501 minecraft:brown_terracotta
setblock 276 127 464 minecraft:bone_block
fill 276 127 465 276 130 465 minecraft:brown_terracotta
setblock 276 127 469 minecraft:bone_block
fill 276 127 470 276 129 470 minecraft:brown_terracotta
setblock 276 127 474 minecraft:bone_block
fill 276 127 475 276 130 475 minecraft:brown_terracotta
setblock 276 127 479 minecraft:bone_block
fill 276 127 480 276 130 480 minecraft:brown_terracotta
setblock 276 127 484 minecraft:bone_block
setblock 276 127 485 minecraft:brown_terracotta
setblock 276 127 495 minecraft:brown_terracotta
setblock 276 127 499 minecraft:bone_block
fill 276 127 500 276 130 500 minecraft:brown_terracotta
setblock 276 127 504 minecraft:bone_block
fill 236 128 464 236 128 467 minecraft:brown_terracotta
setblock 236 128 468 minecraft:bone_block
setblock 236 128 469 minecraft:brown_terracotta
setblock 236 128 473 minecraft:bone_block
setblock 236 128 474 minecraft:brown_terracotta
setblock 236 128 478 minecraft:bone_block
fill 236 128 479 236 129 479 minecraft:brown_terracotta
setblock 236 128 498 minecraft:bone_block
fill 236 128 499 236 131 499 minecraft:brown_terracotta
setblock 236 128 503 minecraft:bone_block
fill 236 128 504 236 131 504 minecraft:brown_terracotta
setblock 237 128 498 minecraft:brown_terracotta
setblock 237 128 502 minecraft:bone_block
fill 237 128 503 237 131 503 minecraft:brown_terracotta
setblock 240 128 504 minecraft:bone_block
setblock 241 128 503 minecraft:bone_block
fill 241 128 504 241 131 504 minecraft:brown_terracotta
fill 242 128 503 245 128 503 minecraft:brown_terracotta
setblock 245 128 504 minecraft:bone_block
setblock 246 128 502 minecraft:brown_terracotta
setblock 246 128 503 minecraft:bone_block
fill 246 128 504 246 131 504 minecraft:brown_terracotta
setblock 247 128 502 minecraft:bone_block
fill 247 128 503 247 131 503 minecraft:brown_terracotta
fill 248 128 464 248 129 464 minecraft:brown_terracotta
setblock 248 128 501 minecraft:bone_block
fill 248 128 502 248 131 502 minecraft:brown_terracotta
fill 249 128 501 249 129 501 minecraft:brown_terracotta
setblock 250 128 464 minecraft:bone_block
setblock 250 128 504 minecraft:bone_block
fill 251 128 464 251 131 464 minecraft:brown_terracotta
setblock 251 128 503 minecraft:bone_block
fill 251 128 504 251 131 504 minecraft:brown_terracotta
setblock 252 128 502 minecraft:bone_block
fill 252 128 503 252 131 503 minecraft:brown_terracotta
fill 253 128 502 253 130 502 minecraft:brown_terracotta
setblock 255 128 504 minecraft:bone_block
setblock 256 128 503 minecraft:bone_block
fill 256 128 504 256 130 504 minecraft:brown_terracotta
fill 268 128 464 268 129 464 minecraft:brown_terracotta
fill 268 128 504 269 128 504 minecraft:brown_terracotta
setblock 270 128 464 minecraft:bone_block
setblock 270 128 503 minecraft:brown_terracotta
setblock 270 128 504 minecraft:bone_block
fill 271 128 464 271 130 465 minecraft:brown_terracotta
setblock 271 128 503 minecraft:bone_block
fill 271 128 504 271 131 504 minecraft:brown_terracotta
fill 272 128 503 272 131 503 minecraft:brown_terracotta
setblock 273 128 476 minecraft:bone_block
setblock 273 128 477 minecraft:brown_terracotta
setblock 274 128 465 minecraft:bone_block
setblock 274 128 475 minecraft:bone_block
fill 274 128 476 274 129 476 minecraft:brown_terracotta
setblock 274 128 480 minecraft:bone_block
fill 274 128 481 274 129 481 minecraft:brown_terracotta
setblock 275 128 464 minecraft:bone_block
setblock 275 128 469 minecraft:bone_block
setblock 275 128 470 minecraft:brown_terracotta
setblock 275 128 474 minecraft:bone_block
fill 275 128 475 275 130 475 minecraft:brown_terracotta
setblock 275 128 479 minecraft:bone_block
fill 275 128 480 275 131 480 minecraft:brown_terracotta
setblock 275 128 499 minecraft:bone_block
setblock 275 128 500 minecraft:brown_terracotta
setblock 275 128 504 minecraft:bone_block
fill 276 128 464 276 131 464 minecraft:brown_terracotta
setblock 276 128 468 minecraft:bone_block
fill 276 128 469 276 129 469 minecraft:brown_terracotta
setblock 276 128 473 minecraft:bone_block
fill 276 128 474 276 131 474 minecraft:brown_terracotta
setblock 276 128 478 minecraft:bone_block
fill 276 128 479 276 131 479 minecraft:brown_terracotta
setblock 276 128 483 minecraft:bone_block
setblock 276 128 484 minecraft:brown_terracotta
setblock 276 128 498 minecraft:bone_block
fill 276 128 499 276 130 499 minecraft:brown_terracotta
setblock 276 128 503 minecraft:bone_block
fill 276 128 504 276 131 504 minecraft:brown_terracotta
fill 236 129 464 236 129 466 minecraft:brown_terracotta
setblock 236 129 477 minecraft:bone_block
setblock 236 129 478 minecraft:brown_terracotta
setblock 236 129 497 minecraft:bone_block
fill 236 129 498 236 132 498 minecraft:brown_terracotta
setblock 236 129 502 minecraft:bone_block
fill 236 129 503 236 132 503 minecraft:brown_terracotta
setblock 237 129 501 minecraft:bone_block
fill 237 129 502 237 132 502 minecraft:brown_terracotta
fill 238 129 476 238 131 476 minecraft:soul_soil
fill 239 129 475 239 131 475 minecraft:soul_soil
fill 239 129 477 239 131 477 minecraft:soul_soil
setblock 239 129 504 minecraft:bone_block
fill 240 129 476 240 131 476 minecraft:soul_soil
setblock 240 129 503 minecraft:bone_block
fill 240 129 504 240 132 504 minecraft:brown_terracotta
fill 241 129 503 244 129 503 minecraft:brown_terracotta
setblock 244 129 504 minecraft:bone_block
setblock 245 129 502 minecraft:brown_terracotta
setblock 245 129 503 minecraft:bone_block
fill 245 129 504 245 132 504 minecraft:brown_terracotta
setblock 246 129 502 minecraft:bone_block
fill 246 129 503 246 132 503 minecraft:brown_terracotta
fill 247 129 502 247 132 502 minecraft:brown_terracotta
setblock 249 129 464 minecraft:bone_block
setblock 249 129 504 minecraft:bone_block
fill 250 129 464 250 132 464 minecraft:brown_terracotta
setblock 250 129 503 minecraft:bone_block
fill 250 129 504 250 132 504 minecraft:brown_terracotta
setblock 251 129 502 minecraft:bone_block
fill 251 129 503 251 132 503 minecraft:brown_terracotta
fill 252 129 502 252 131 502 minecraft:brown_terracotta
setblock 254 129 504 minecraft:bone_block
setblock 255 129 503 minecraft:bone_block
fill 255 129 504 255 132 504 minecraft:brown_terracotta
fill 267 129 504 268 129 504 minecraft:brown_terracotta
setblock 269 129 464 minecraft:bone_block
setblock 269 129 504 minecraft:bone_block
fill 270 129 464 270 132 464 minecraft:brown_terracotta
setblock 270 129 503 minecraft:bone_block
fill 270 129 504 270 132 504 minecraft:brown_terracotta
fill 271 129 503 271 132 503 minecraft:brown_terracotta
setblock 273 129 465 minecraft:bone_block
setblock 274 129 464 minecraft:bone_block
fill 274 129 465 274 132 465 minecraft:brown_terracotta
setblock 274 129 474 minecraft:bone_block
setblock 274 129 475 minecraft:brown_terracotta
setblock 274 129 479 minecraft:bone_block
fill 274 129 480 274 130 480 minecraft:brown_terracotta
setblock 274 129 504 minecraft:bone_block
fill 275 129 464 275 132 464 minecraft:brown_terracotta
setblock 275 129 473 minecraft:bone_block
fill 275 129 474 275 130 474 minecraft:brown_terracotta
setblock 275 129 478 minecraft:bone_block
fill 275 129 479 275 131 479 minecraft:brown_terracotta
setblock 275 129 503 minecraft:bone_block
fill 275 129 504 275 132 504 minecraft:brown_terracotta
setblock 276 129 467 minecraft:bone_block
setblock 276 129 468 minecraft:brown_terracotta
setblock 276 129 472 minecraft:bone_block
fill 276 129 473 276 130 473 minecraft:brown_terracotta
setblock 276 129 477 minecraft:bone_block
fill 276 129 478 276 132 478 minecraft:brown_terracotta
setblock 276 129 482 minecraft:bone_block
fill 276 129 483 276 132 483 minecraft:brown_terracotta
setblock 276 129 498 minecraft:brown_terracotta
setblock 276 129 502 minecraft:bone_block
fill 276 129 503 276 132 503 minecraft:brown_terracotta
fill 236 130 464 236 130 465 minecraft:brown_terracotta
setblock 236 130 497 minecraft:brown_terracotta
setblock 236 130 501 minecraft:bone_block
fill 236 130 502 236 133 502 minecraft:brown_terracotta
setblock 237 130 500 minecraft:bone_block
fill 237 130 501 237 133 501 minecraft:brown_terracotta
fill 238 130 475 238 131 475 minecraft:soul_soil
fill 238 130 477 238 131 477 minecraft:soul_soil
setblock 238 130 504 minecraft:bone_block
setblock 239 130 503 minecraft:bone_block
fill 239 130 504 239 133 504 minecraft:brown_terracotta
fill 240 130 475 240 131 475 minecraft:soul_soil
fill 240 130 477 240 131 477 minecraft:soul_soil
fill 240 130 503 243 130 503 minecraft:brown_terracotta
setblock 243 130 504 minecraft:bone_block
setblock 244 130 503 minecraft:bone_block
fill 244 130 504 244 133 504 minecraft:brown_terracotta
setblock 245 130 502 minecraft:bone_block
fill 245 130 503 245 133 503 minecraft:brown_terracotta
fill 246 130 502 246 133 502 minecraft:brown_terracotta
setblock 247 130 464 minecraft:brown_terracotta
setblock 248 130 464 minecraft:bone_block
setblock 248 130 504 minecraft:bone_block
fill 249 130 464 249 133 464 minecraft:brown_terracotta
setblock 249 130 503 minecraft:bone_block
fill 249 130 504 249 133 504 minecraft:brown_terracotta
setblock 250 130 502 minecraft:bone_block
fill 250 130 503 250 133 503 minecraft:brown_terracotta
fill 251 130 502 251 133 502 minecraft:brown_terracotta
setblock 253 130 504 minecraft:bone_block
setblock 254 130 503 minecraft:bone_block
fill 254 130 504 254 133 504 minecraft:brown_terracotta
fill 266 130 504 267 130 504 minecraft:brown_terracotta
setblock 267 130 464 minecraft:brown_terracotta
setblock 268 130 464 minecraft:bone_block
setblock 268 130 504 minecraft:bone_block
fill 269 130 464 269 133 464 minecraft:brown_terracotta
setblock 269 130 503 minecraft:bone_block
fill 269 130 504 269 133 504 minecraft:brown_terracotta
fill 270 130 465 270 131 465 minecraft:brown_terracotta
fill 270 130 503 270 133 503 minecraft:brown_terracotta
setblock 272 130 465 minecraft:bone_block
setblock 273 130 464 minecraft:bone_block
fill 273 130 465 273 133 465 minecraft:brown_terracotta
setblock 273 130 504 minecraft:bone_block
fill 274 130 464 274 133 464 minecraft:brown_terracotta
setblock 274 130 478 minecraft:bone_block
setblock 274 130 479 minecraft:brown_terracotta
setblock 274 130 503 minecraft:bone_block
fill 274 130 504 274 133 504 minecraft:brown_terracotta
setblock 275 130 477 minecraft:bone_block
fill 275 130 478 275 131 478 minecraft:brown_terracotta
setblock 275 130 482 minecraft:bone_block
setblock 276 130 466 minecraft:bone_block
fill 276 130 467 276 133 467 minecraft:brown_terracotta
setblock 276 130 471 minecraft:bone_block
setblock 276 130 472 minecraft:brown_terracotta
setblock 276 130 476 minecraft:bone_block
fill 276 130 477 276 132 477 minecraft:brown_terracotta
setblock 276 130 481 minecraft:bone_block
fill 276 130 482 276 133 482 minecraft:brown_terracotta
setblock 276 130 501 minecraft:bone_block
fill 276 130 502 276 133 502 minecraft:brown_terracotta
setblock 236 131 464 minecraft:brown_terracotta
setblock 236 131 465 minecraft:bone_block
setblock 236 131 500 minecraft:bone_block
fill 236 131 501 236 134 501 minecraft:brown_terracotta
setblock 237 131 464 minecraft:bone_block
setblock 237 131 504 minecraft:bone_block
setblock 238 131 466 minecraft:light[level=12]
setblock 238 131 474 minecraft:light[level=12]
setblock 238 131 482 minecraft:light[level=12]
setblock 238 131 490 minecraft:light[level=12]
setblock 238 131 498 minecraft:light[level=12]
setblock 238 131 503 minecraft:bone_block
fill 238 131 504 238 134 504 minecraft:brown_terracotta
fill 239 131 503 242 131 503 minecraft:brown_terracotta
setblock 242 131 504 minecraft:bone_block
setblock 243 131 503 minecraft:bone_block
fill 243 131 504 243 134 504 minecraft:brown_terracotta
fill 244 131 503 244 134 503 minecraft:brown_terracotta
fill 245 131 464 246 131 464 minecraft:brown_terracotta
fill 245 131 502 245 134 502 minecraft:brown_terracotta
setblock 246 131 466 minecraft:light[level=12]
setblock 246 131 474 minecraft:light[level=12]
setblock 246 131 482 minecraft:light[level=12]
setblock 246 131 490 minecraft:light[level=12]
setblock 246 131 498 minecraft:light[level=12]
setblock 247 131 464 minecraft:bone_block
setblock 247 131 504 minecraft:bone_block
fill 248 131 464 248 134 464 minecraft:brown_terracotta
setblock 248 131 503 minecraft:bone_block
fill 248 131 504 248 134 504 minecraft:brown_terracotta
setblock 249 131 502 minecraft:bone_block
fill 249 131 503 249 134 503 minecraft:brown_terracotta
fill 250 131 502 250 134 502 minecraft:brown_terracotta
setblock 252 131 504 minecraft:bone_block
setblock 253 131 503 minecraft:bone_block
fill 253 131 504 253 134 504 minecraft:brown_terracotta
setblock 254 131 466 minecraft:light[level=12]
setblock 254 131 474 minecraft:light[level=12]
setblock 254 131 482 minecraft:light[level=12]
setblock 254 131 490 minecraft:light[level=12]
setblock 254 131 498 minecraft:light[level=12]
setblock 254 131 503 minecraft:brown_terracotta
setblock 262 131 466 minecraft:light[level=12]
setblock 262 131 474 minecraft:light[level=12]
setblock 262 131 482 minecraft:light[level=12]
setblock 262 131 490 minecraft:light[level=12]
setblock 262 131 498 minecraft:light[level=12]
setblock 266 131 464 minecraft:brown_terracotta
setblock 266 131 504 minecraft:brown_terracotta
setblock 267 131 464 minecraft:bone_block
setblock 267 131 504 minecraft:bone_block
fill 268 131 464 268 134 464 minecraft:brown_terracotta
setblock 268 131 503 minecraft:bone_block
fill 268 131 504 268 134 504 minecraft:brown_terracotta
fill 269 131 465 269 132 465 minecraft:brown_terracotta
fill 269 131 503 269 134 503 minecraft:brown_terracotta
setblock 270 131 466 minecraft:light[level=12]
setblock 270 131 474 minecraft:light[level=12]
setblock 270 131 482 minecraft:light[level=12]
setblock 270 131 490 minecraft:light[level=12]
setblock 270 131 498 minecraft:light[level=12]
setblock 271 131 464 minecraft:brown_terracotta
setblock 271 131 465 minecraft:bone_block
setblock 272 131 464 minecraft:bone_block
fill 272 131 465 272 134 465 minecraft:brown_terracotta
setblock 272 131 504 minecraft:bone_block
fill 273 131 464 273 134 464 minecraft:brown_terracotta
setblock 273 131 503 minecraft:bone_block
fill 273 131 504 273 134 504 minecraft:brown_terracotta
fill 274 131 503 274 134 503 minecraft:brown_terracotta
setblock 275 131 477 minecraft:brown_terracotta
setblock 275 131 481 minecraft:bone_block
setblock 276 131 465 minecraft:bone_block
fill 276 131 466 276 134 466 minecraft:brown_terracotta
setblock 276 131 475 minecraft:bone_block
fill 276 131 476 276 132 476 minecraft:brown_terracotta
setblock 276 131 480 minecraft:bone_block
fill 276 131 481 276 134 481 minecraft:brown_terracotta
setblock 276 131 500 minecraft:bone_block
fill 276 131 501 276 134 501 minecraft:brown_terracotta
setblock 236 132 464 minecraft:bone_block
fill 236 132 465 236 135 465 minecraft:brown_terracotta
setblock 236 132 499 minecraft:bone_block
fill 236 132 500 236 135 500 minecraft:brown_terracotta
setblock 236 132 504 minecraft:bone_block
fill 237 132 464 237 135 464 minecraft:brown_terracotta
setblock 237 132 503 minecraft:bone_block
fill 237 132 504 237 135 504 minecraft:brown_terracotta
fill 238 132 503 241 132 503 minecraft:brown_terracotta
setblock 241 132 504 minecraft:bone_block
setblock 242 132 503 minecraft:bone_block
fill 242 132 504 242 135 504 minecraft:brown_terracotta
fill 243 132 503 243 135 503 minecraft:brown_terracotta
fill 244 132 464 245 132 464 minecraft:brown_terracotta
fill 244 132 502 244 135 502 minecraft:brown_terracotta
setblock 246 132 464 minecraft:bone_block
setblock 246 132 504 minecraft:bone_block
fill 247 132 464 247 135 464 minecraft:brown_terracotta
setblock 247 132 503 minecraft:bone_block
fill 247 132 504 247 135 504 minecraft:brown_terracotta
setblock 248 132 502 minecraft:bone_block
fill 248 132 503 248 135 503 minecraft:brown_terracotta
fill 249 132 502 249 135 502 minecraft:brown_terracotta
setblock 251 132 464 minecraft:bone_block
setblock 251 132 504 minecraft:bone_block
fill 252 132 464 252 135 464 minecraft:brown_terracotta
setblock 252 132 503 minecraft:bone_block
fill 252 132 504 252 135 504 minecraft:brown_terracotta
fill 253 132 503 253 135 503 minecraft:brown_terracotta
setblock 265 132 464 minecraft:brown_terracotta
setblock 265 132 504 minecraft:brown_terracotta
setblock 266 132 464 minecraft:bone_block
setblock 266 132 504 minecraft:bone_block
fill 267 132 464 267 134 465 minecraft:brown_terracotta
setblock 267 132 503 minecraft:bone_block
fill 267 132 504 267 135 504 minecraft:brown_terracotta
fill 268 132 465 268 133 465 minecraft:brown_terracotta
fill 268 132 503 268 135 503 minecraft:brown_terracotta
setblock 270 132 465 minecraft:bone_block
setblock 271 132 464 minecraft:bone_block
fill 271 132 465 271 135 465 minecraft:brown_terracotta
setblock 271 132 504 minecraft:bone_block
fill 272 132 464 272 135 464 minecraft:brown_terracotta
setblock 272 132 503 minecraft:bone_block
fill 272 132 504 272 135 504 minecraft:brown_terracotta
fill 273 132 503 273 135 503 minecraft:brown_terracotta
setblock 276 132 464 minecraft:bone_block
fill 276 132 465 276 135 465 minecraft:brown_terracotta
setblock 276 132 479 minecraft:bone_block
fill 276 132 480 276 134 480 minecraft:brown_terracotta
setblock 276 132 504 minecraft:bone_block
fill 236 133 464 236 136 464 minecraft:brown_terracotta
fill 236 133 499 236 136 499 minecraft:brown_terracotta
setblock 236 133 503 minecraft:bone_block
fill 236 133 504 236 136 504 minecraft:brown_terracotta
setblock 237 133 502 minecraft:bone_block
fill 237 133 503 240 133 503 minecraft:brown_terracotta
fill 238 133 464 239 133 464 minecraft:brown_terracotta
setblock 240 133 464 minecraft:bone_block
setblock 240 133 504 minecraft:bone_block
fill 241 133 464 244 133 464 minecraft:brown_terracotta
setblock 241 133 503 minecraft:bone_block
fill 241 133 504 241 136 504 minecraft:brown_terracotta
fill 242 133 503 242 136 503 minecraft:brown_terracotta
fill 243 133 502 243 136 502 minecraft:brown_terracotta
setblock 245 133 464 minecraft:bone_block
setblock 245 133 504 minecraft:bone_block
fill 246 133 464 246 136 464 minecraft:brown_terracotta
setblock 246 133 503 minecraft:bone_block
fill 246 133 504 246 136 504 minecraft:brown_terracotta
setblock 247 133 502 minecraft:bone_block
fill 247 133 503 247 136 503 minecraft:brown_terracotta
fill 248 133 502 248 136 502 minecraft:brown_terracotta
setblock 250 133 464 minecraft:bone_block
setblock 250 133 504 minecraft:bone_block
fill 251 133 464 251 136 464 minecraft:brown_terracotta
setblock 251 133 503 minecraft:bone_block
fill 251 133 504 251 136 504 minecraft:brown_terracotta
fill 252 133 503 252 136 503 minecraft:brown_terracotta
setblock 255 133 504 minecraft:bone_block
fill 263 133 464 264 133 464 minecraft:brown_terracotta
setblock 264 133 504 minecraft:brown_terracotta
setblock 265 133 464 minecraft:bone_block
setblock 265 133 504 minecraft:bone_block
fill 266 133 464 266 135 465 minecraft:brown_terracotta
setblock 266 133 503 minecraft:bone_block
fill 266 133 504 266 136 504 minecraft:brown_terracotta
fill 267 133 503 267 136 503 minecraft:brown_terracotta
setblock 269 133 465 minecraft:bone_block
setblock 270 133 464 minecraft:bone_block
fill 270 133 465 270 136 465 minecraft:brown_terracotta
setblock 270 133 504 minecraft:bone_block
fill 271 133 464 271 136 464 minecraft:brown_terracotta
setblock 271 133 503 minecraft:bone_block
fill 271 133 504 271 136 504 minecraft:brown_terracotta
fill 272 133 503 272 136 503 minecraft:brown_terracotta
setblock 274 133 465 minecraft:bone_block
setblock 275 133 464 minecraft:bone_block
fill 275 133 465 275 136 465 minecraft:brown_terracotta
setblock 275 133 504 minecraft:bone_block
fill 276 133 464 276 136 464 minecraft:brown_terracotta
setblock 276 133 468 minecraft:bone_block
setblock 276 133 478 minecraft:bone_block
setblock 276 133 479 minecraft:brown_terracotta
setblock 276 133 483 minecraft:bone_block
setblock 276 133 503 minecraft:bone_block
fill 276 133 504 276 136 504 minecraft:brown_terracotta
setblock 236 134 466 minecraft:brown_terracotta
setblock 236 134 502 minecraft:bone_block
fill 236 134 503 239 134 503 minecraft:brown_terracotta
setblock 237 134 501 minecraft:bone_block
fill 237 134 502 237 137 502 minecraft:brown_terracotta
setblock 238 134 464 minecraft:brown_terracotta
setblock 239 134 464 minecraft:bone_block
setblock 239 134 504 minecraft:bone_block
fill 240 134 464 243 134 464 minecraft:brown_terracotta
setblock 240 134 503 minecraft:bone_block
fill 240 134 504 240 137 504 minecraft:brown_terracotta
fill 241 134 503 241 137 503 minecraft:brown_terracotta
fill 242 134 502 242 137 502 minecraft:brown_terracotta
setblock 244 134 464 minecraft:bone_block
setblock 244 134 504 minecraft:bone_block
fill 245 134 464 245 137 464 minecraft:brown_terracotta
setblock 245 134 503 minecraft:bone_block
fill 245 134 504 245 137 504 minecraft:brown_terracotta
fill 246 134 465 247 134 465 minecraft:brown_terracotta
setblock 246 134 502 minecraft:bone_block
fill 246 134 503 246 137 503 minecraft:brown_terracotta
fill 247 134 502 247 137 502 minecraft:brown_terracotta
setblock 248 134 465 minecraft:bone_block
setblock 249 134 464 minecraft:bone_block
setblock 249 134 504 minecraft:bone_block
fill 250 134 464 250 137 464 minecraft:brown_terracotta
setblock 250 134 503 minecraft:bone_block
fill 250 134 504 250 137 504 minecraft:brown_terracotta
setblock 251 134 502 minecraft:bone_block
fill 251 134 503 251 137 503 minecraft:brown_terracotta
setblock 253 134 464 minecraft:brown_terracotta
setblock 254 134 504 minecraft:bone_block
fill 255 134 504 255 136 504 minecraft:brown_terracotta
fill 262 134 464 263 134 464 minecraft:brown_terracotta
fill 262 134 504 263 134 504 minecraft:brown_terracotta
setblock 264 134 464 minecraft:bone_block
fill 264 134 465 265 136 465 minecraft:brown_terracotta
setblock 264 134 504 minecraft:bone_block
fill 265 134 464 265 137 464 minecraft:brown_terracotta
setblock 265 134 503 minecraft:bone_block
fill 265 134 504 265 137 504 minecraft:brown_terracotta
fill 266 134 503 266 137 503 minecraft:brown_terracotta
setblock 267 134 466 minecraft:bone_block
setblock 268 134 465 minecraft:bone_block
fill 268 134 466 271 134 466 minecraft:brown_terracotta
setblock 269 134 464 minecraft:bone_block
fill 269 134 465 269 137 465 minecraft:brown_terracotta
setblock 269 134 504 minecraft:bone_block
fill 270 134 464 270 137 464 minecraft:brown_terracotta
setblock 270 134 503 minecraft:bone_block
fill 270 134 504 270 137 504 minecraft:brown_terracotta
fill 271 134 503 271 137 503 minecraft:brown_terracotta
setblock 272 134 466 minecraft:bone_block
setblock 273 134 465 minecraft:bone_block
setblock 274 134 464 minecraft:bone_block
fill 274 134 465 274 137 465 minecraft:brown_terracotta
setblock 274 134 504 minecraft:bone_block
fill 275 134 464 275 137 464 minecraft:brown_terracotta
fill 275 134 466 275 135 466 minecraft:brown_terracotta
setblock 275 134 503 minecraft:bone_block
fill 275 134 504 275 137 504 minecraft:brown_terracotta
setblock 276 134 467 minecraft:bone_block
fill 276 134 468 276 137 468 minecraft:brown_terracotta
setblock 276 134 482 minecraft:bone_block
fill 276 134 483 276 137 483 minecraft:brown_terracotta
setblock 276 134 502 minecraft:bone_block
fill 276 134 503 276 137 503 minecraft:brown_terracotta
setblock 236 135 466 minecraft:bone_block
setblock 236 135 501 minecraft:bone_block
fill 236 135 502 236 137 503 minecraft:brown_terracotta
fill 237 135 501 237 137 501 minecraft:brown_terracotta
fill 237 135 503 238 135 503 minecraft:brown_terracotta
setblock 238 135 464 minecraft:bone_block
setblock 238 135 504 minecraft:bone_block
fill 239 135 464 242 135 464 minecraft:brown_terracotta
setblock 239 135 503 minecraft:bone_block
fill 239 135 504 239 138 504 minecraft:brown_terracotta
fill 240 135 503 240 138 503 minecraft:brown_terracotta
setblock 243 135 464 minecraft:bone_block
fill 243 135 465 246 135 465 minecraft:brown_terracotta
setblock 243 135 504 minecraft:bone_block
fill 244 135 464 244 138 464 minecraft:brown_terracotta
setblock 244 135 503 minecraft:bone_block
fill 244 135 504 244 138 504 minecraft:brown_terracotta
setblock 245 135 502 minecraft:bone_block
fill 245 135 503 245 138 503 minecraft:brown_terracotta
fill 246 135 502 246 138 502 minecraft:brown_terracotta
setblock 247 135 465 minecraft:bone_block
setblock 248 135 464 minecraft:bone_block
fill 248 135 465 250 136 465 minecraft:brown_terracotta
setblock 248 135 504 minecraft:bone_block
fill 249 135 464 249 138 464 minecraft:brown_terracotta
setblock 249 135 503 minecraft:bone_block
fill 249 135 504 249 138 504 minecraft:brown_terracotta
setblock 250 135 502 minecraft:bone_block
fill 250 135 503 250 138 503 minecraft:brown_terracotta
setblock 253 135 464 minecraft:bone_block
setblock 253 135 504 minecraft:bone_block
fill 254 135 464 254 138 464 minecraft:brown_terracotta
fill 254 135 504 254 137 504 minecraft:brown_terracotta
fill 260 135 464 262 135 464 minecraft:brown_terracotta
fill 261 135 504 262 135 504 minecraft:brown_terracotta
setblock 263 135 464 minecraft:bone_block
fill 263 135 465 263 138 465 minecraft:brown_terracotta
setblock 263 135 504 minecraft:bone_block
fill 264 135 464 264 138 464 minecraft:brown_terracotta
fill 264 135 504 264 138 504 minecraft:brown_terracotta
setblock 265 135 466 minecraft:brown_terracotta
fill 265 135 503 265 138 503 minecraft:brown_terracotta
setblock 266 135 466 minecraft:bone_block
setblock 267 135 464 minecraft:brown_terracotta
setblock 267 135 465 minecraft:bone_block
fill 267 135 466 270 135 466 minecraft:brown_terracotta
setblock 268 135 464 minecraft:bone_block
fill 268 135 465 268 138 465 minecraft:brown_terracotta
setblock 268 135 504 minecraft:bone_block
fill 269 135 464 269 138 464 minecraft:brown_terracotta
setblock 269 135 503 minecraft:bone_block
fill 269 135 504 269 138 504 minecraft:brown_terracotta
fill 270 135 503 270 138 503 minecraft:brown_terracotta
setblock 271 135 466 minecraft:bone_block
setblock 272 135 465 minecraft:bone_block
fill 272 135 466 273 137 466 minecraft:brown_terracotta
setblock 273 135 464 minecraft:bone_block
fill 273 135 465 273 138 465 minecraft:brown_terracotta
setblock 273 135 504 minecraft:bone_block
fill 274 135 464 274 138 464 minecraft:brown_terracotta
setblock 274 135 503 minecraft:bone_block
fill 274 135 504 274 138 504 minecraft:brown_terracotta
setblock 275 135 467 minecraft:bone_block
fill 275 135 503 275 137 503 minecraft:brown_terracotta
setblock 276 135 466 minecraft:bone_block
fill 276 135 467 276 138 467 minecraft:brown_terracotta
fill 276 135 469 276 136 469 minecraft:brown_terracotta
setblock 276 135 481 minecraft:bone_block
fill 276 135 482 276 136 482 minecraft:brown_terracotta
setblock 276 135 501 minecraft:bone_block
fill 276 135 502 276 138 502 minecraft:brown_terracotta
setblock 236 136 465 minecraft:bone_block
fill 236 136 466 236 138 467 minecraft:brown_terracotta
setblock 236 136 484 minecraft:brown_terracotta
setblock 236 136 485 minecraft:bone_block
fill 236 136 486 236 139 486 minecraft:brown_terracotta
setblock 236 136 500 minecraft:bone_block
fill 236 136 501 236 139 501 minecraft:brown_terracotta
setblock 237 136 464 minecraft:bone_block
setblock 237 136 503 minecraft:brown_terracotta
setblock 237 136 504 minecraft:bone_block
fill 238 136 464 241 136 464 minecraft:brown_terracotta
setblock 238 136 503 minecraft:bone_block
fill 238 136 504 238 139 504 minecraft:brown_terracotta
fill 239 136 503 239 139 503 minecraft:brown_terracotta
setblock 241 136 465 minecraft:bone_block
fill 241 136 502 241 138 502 minecraft:brown_terracotta
setblock 242 136 464 minecraft:bone_block
fill 242 136 465 245 136 465 minecraft:brown_terracotta
setblock 242 136 504 minecraft:bone_block
fill 243 136 464 243 139 464 minecraft:brown_terracotta
setblock 243 136 503 minecraft:bone_block
fill 243 136 504 243 139 504 minecraft:brown_terracotta
setblock 244 136 502 minecraft:bone_block
fill 244 136 503 244 139 503 minecraft:brown_terracotta
fill 245 136 502 245 139 502 minecraft:brown_terracotta
setblock 246 136 465 minecraft:bone_block
setblock 247 136 464 minecraft:bone_block
fill 247 136 465 247 139 465 minecraft:brown_terracotta
setblock 247 136 504 minecraft:bone_block
fill 248 136 464 248 139 464 minecraft:brown_terracotta
setblock 248 136 503 minecraft:bone_block
fill 248 136 504 248 139 504 minecraft:brown_terracotta
setblock 249 136 502 minecraft:bone_block
fill 249 136 503 249 139 503 minecraft:brown_terracotta
setblock 250 136 502 minecraft:brown_terracotta
setblock 252 136 464 minecraft:bone_block
setblock 252 136 504 minecraft:bone_block
fill 253 136 464 253 139 464 minecraft:brown_terracotta
fill 253 136 504 253 138 504 minecraft:brown_terracotta
fill 255 136 464 255 137 464 minecraft:brown_terracotta
fill 258 136 464 261 136 464 minecraft:brown_terracotta
fill 260 136 504 261 136 504 minecraft:brown_terracotta
setblock 261 136 465 minecraft:bone_block
setblock 262 136 464 minecraft:bone_block
fill 262 136 465 262 139 465 minecraft:brown_terracotta
setblock 262 136 504 minecraft:bone_block
fill 263 136 464 263 139 464 minecraft:brown_terracotta
fill 263 136 504 263 139 504 minecraft:brown_terracotta
setblock 264 136 466 minecraft:brown_terracotta
fill 264 136 503 264 139 503 minecraft:brown_terracotta
setblock 265 136 466 minecraft:bone_block
setblock 266 136 464 minecraft:brown_terracotta
setblock 266 136 465 minecraft:bone_block
fill 266 136 466 269 136 466 minecraft:brown_terracotta
setblock 267 136 464 minecraft:bone_block
fill 267 136 465 267 139 465 minecraft:brown_terracotta
fill 267 136 467 268 136 467 minecraft:brown_terracotta
setblock 267 136 504 minecraft:bone_block
fill 268 136 464 268 139 464 minecraft:brown_terracotta
setblock 268 136 503 minecraft:bone_block
fill 268 136 504 268 139 504 minecraft:brown_terracotta
setblock 269 136 467 minecraft:bone_block
fill 269 136 503 269 139 503 minecraft:brown_terracotta
setblock 270 136 466 minecraft:bone_block
setblock 271 136 465 minecraft:bone_block
fill 271 136 466 271 139 466 minecraft:brown_terracotta
setblock 272 136 464 minecraft:bone_block
fill 272 136 465 272 139 465 minecraft:brown_terracotta
setblock 272 136 504 minecraft:bone_block
fill 273 136 464 273 139 464 minecraft:brown_terracotta
setblock 273 136 503 minecraft:bone_block
fill 273 136 504 273 139 504 minecraft:brown_terracotta
setblock 274 136 466 minecraft:brown_terracotta
fill 274 136 503 274 137 503 minecraft:brown_terracotta
setblock 275 136 466 minecraft:bone_block
fill 275 136 467 275 138 468 minecraft:brown_terracotta
setblock 276 136 465 minecraft:bone_block
fill 276 136 466 276 139 466 minecraft:brown_terracotta
setblock 276 136 470 minecraft:bone_block
setblock 276 136 484 minecraft:brown_terracotta
fill 276 136 501 276 138 501 minecraft:brown_terracotta
setblock 236 137 464 minecraft:bone_block
fill 236 137 465 239 137 465 minecraft:brown_terracotta
setblock 236 137 468 minecraft:brown_terracotta
setblock 236 137 484 minecraft:bone_block
fill 236 137 485 236 140 485 minecraft:brown_terracotta
fill 236 137 487 236 137 488 minecraft:brown_terracotta
setblock 236 137 489 minecraft:bone_block
setblock 236 137 499 minecraft:bone_block
fill 236 137 500 236 140 500 minecraft:brown_terracotta
setblock 236 137 504 minecraft:bone_block
fill 237 137 464 240 137 464 minecraft:brown_terracotta
setblock 237 137 503 minecraft:bone_block
fill 237 137 504 237 140 504 minecraft:brown_terracotta
fill 238 137 503 238 140 503 minecraft:brown_terracotta
setblock 240 137 465 minecraft:bone_block
setblock 241 137 464 minecraft:bone_block
fill 241 137 465 244 137 465 minecraft:brown_terracotta
setblock 241 137 504 minecraft:bone_block
fill 242 137 464 242 140 464 minecraft:brown_terracotta
setblock 242 137 503 minecraft:bone_block
fill 242 137 504 242 140 504 minecraft:brown_terracotta
setblock 243 137 502 minecraft:bone_block
fill 243 137 503 243 140 503 minecraft:brown_terracotta
fill 244 137 502 244 140 502 minecraft:brown_terracotta
setblock 245 137 465 minecraft:bone_block
fill 245 137 486 246 138 487 minecraft:bone_block
setblock 246 137 464 minecraft:bone_block
fill 246 137 465 246 140 465 minecraft:brown_terracotta
fill 246 137 488 246 138 488 minecraft:bone_block
setblock 246 137 504 minecraft:bone_block
fill 247 137 464 247 140 464 minecraft:brown_terracotta
setblock 247 137 503 minecraft:bone_block
fill 247 137 504 247 140 504 minecraft:brown_terracotta
fill 248 137 465 249 137 465 minecraft:brown_terracotta
setblock 248 137 502 minecraft:bone_block
fill 248 137 503 248 140 503 minecraft:brown_terracotta
setblock 249 137 502 minecraft:brown_terracotta
setblock 250 137 465 minecraft:bone_block
setblock 251 137 464 minecraft:bone_block
fill 251 137 465 251 138 465 minecraft:brown_terracotta
setblock 251 137 504 minecraft:bone_block
fill 252 137 464 252 140 464 minecraft:brown_terracotta
fill 252 137 504 252 139 504 minecraft:brown_terracotta
setblock 256 137 464 minecraft:bone_block
fill 257 137 464 260 137 464 minecraft:brown_terracotta
setblock 260 137 465 minecraft:bone_block
setblock 260 137 504 minecraft:brown_terracotta
setblock 261 137 464 minecraft:bone_block
fill 261 137 465 261 140 465 minecraft:brown_terracotta
setblock 261 137 504 minecraft:bone_block
fill 262 137 464 262 140 464 minecraft:brown_terracotta
fill 262 137 466 263 137 466 minecraft:brown_terracotta
fill 262 137 504 262 140 504 minecraft:brown_terracotta
fill 263 137 503 263 139 503 minecraft:brown_terracotta
setblock 264 137 465 minecraft:brown_terracotta
setblock 264 137 466 minecraft:bone_block
setblock 265 137 465 minecraft:bone_block
fill 265 137 466 267 137 467 minecraft:brown_terracotta
setblock 266 137 464 minecraft:bone_block
fill 266 137 465 266 140 465 minecraft:brown_terracotta
setblock 266 137 504 minecraft:bone_block
fill 267 137 464 267 140 464 minecraft:brown_terracotta
setblock 267 137 503 minecraft:bone_block
fill 267 137 504 267 140 504 minecraft:brown_terracotta
setblock 268 137 466 minecraft:brown_terracotta
setblock 268 137 467 minecraft:bone_block
fill 268 137 503 268 140 503 minecraft:brown_terracotta
setblock 269 137 466 minecraft:bone_block
fill 269 137 467 270 139 467 minecraft:brown_terracotta
setblock 270 137 465 minecraft:bone_block
fill 270 137 466 270 140 466 minecraft:brown_terracotta
setblock 271 137 464 minecraft:bone_block
fill 271 137 465 271 140 465 minecraft:brown_terracotta
setblock 271 137 504 minecraft:bone_block
fill 272 137 464 272 140 464 minecraft:brown_terracotta
setblock 272 137 503 minecraft:bone_block
fill 272 137 504 272 140 504 minecraft:brown_terracotta
fill 273 137 503 273 138 503 minecraft:brown_terracotta
setblock 274 137 466 minecraft:bone_block
setblock 275 137 465 minecraft:bone_block
fill 275 137 466 275 140 466 minecraft:brown_terracotta
setblock 276 137 464 minecraft:bone_block
fill 276 137 465 276 140 465 minecraft:brown_terracotta
setblock 276 137 469 minecraft:bone_block
fill 276 137 470 276 140 470 minecraft:brown_terracotta
setblock 276 137 484 minecraft:bone_block
fill 276 137 485 276 138 485 minecraft:brown_terracotta
setblock 276 137 504 minecraft:bone_block
fill 236 138 464 238 138 465 minecraft:brown_terracotta
setblock 236 138 468 minecraft:bone_block
fill 236 138 484 236 140 484 minecraft:brown_terracotta
setblock 236 138 487 minecraft:brown_terracotta
setblock 236 138 488 minecraft:bone_block
fill 236 138 489 236 139 491 minecraft:brown_terracotta
fill 236 138 499 236 139 499 minecraft:brown_terracotta
setblock 236 138 502 minecraft:brown_terracotta
setblock 236 138 503 minecraft:bone_block
fill 236 138 504 236 141 504 minecraft:brown_terracotta
setblock 237 138 502 minecraft:bone_block
fill 237 138 503 237 140 503 minecraft:brown_terracotta
setblock 239 138 464 minecraft:brown_terracotta
setblock 239 138 465 minecraft:bone_block
setblock 240 138 464 minecraft:bone_block
fill 240 138 465 243 138 465 minecraft:brown_terracotta
setblock 240 138 504 minecraft:bone_block
fill 241 138 464 241 141 464 minecraft:brown_terracotta
setblock 241 138 503 minecraft:bone_block
fill 241 138 504 241 141 504 minecraft:brown_terracotta
setblock 242 138 502 minecraft:bone_block
fill 242 138 503 242 141 503 minecraft:brown_terracotta
fill 243 138 502 243 140 502 minecraft:brown_terracotta
setblock 244 138 465 minecraft:bone_block
fill 244 138 466 247 138 466 minecraft:brown_terracotta
setblock 245 138 464 minecraft:bone_block
fill 245 138 465 245 141 465 minecraft:brown_terracotta
setblock 245 138 504 minecraft:bone_block
fill 246 138 464 246 141 464 minecraft:brown_terracotta
setblock 246 138 503 minecraft:bone_block
fill 246 138 504 246 141 504 minecraft:brown_terracotta
setblock 247 138 502 minecraft:bone_block
fill 247 138 503 247 140 503 minecraft:brown_terracotta
setblock 248 138 465 minecraft:brown_terracotta
setblock 248 138 502 minecraft:brown_terracotta
setblock 249 138 465 minecraft:bone_block
setblock 250 138 464 minecraft:bone_block
fill 250 138 465 250 139 465 minecraft:brown_terracotta
setblock 250 138 504 minecraft:bone_block
fill 251 138 464 251 141 464 minecraft:brown_terracotta
setblock 251 138 503 minecraft:bone_block
fill 251 138 504 251 140 504 minecraft:brown_terracotta
setblock 255 138 464 minecraft:bone_block
fill 256 138 464 259 138 464 minecraft:brown_terracotta
setblock 259 138 465 minecraft:bone_block
setblock 259 138 504 minecraft:brown_terracotta
setblock 260 138 464 minecraft:bone_block
fill 260 138 465 260 141 465 minecraft:brown_terracotta
setblock 260 138 504 minecraft:bone_block
fill 261 138 464 261 141 464 minecraft:brown_terracotta
fill 261 138 466 262 138 466 minecraft:brown_terracotta
fill 261 138 504 261 141 504 minecraft:brown_terracotta
setblock 263 138 466 minecraft:bone_block
setblock 264 138 465 minecraft:bone_block
fill 264 138 466 266 138 467 minecraft:brown_terracotta
setblock 265 138 464 minecraft:bone_block
fill 265 138 465 265 141 465 minecraft:brown_terracotta
setblock 265 138 504 minecraft:bone_block
fill 266 138 464 266 141 464 minecraft:brown_terracotta
setblock 266 138 503 minecraft:bone_block
fill 266 138 504 266 141 504 minecraft:brown_terracotta
setblock 267 138 466 minecraft:brown_terracotta
setblock 267 138 467 minecraft:bone_block
fill 267 138 503 267 140 503 minecraft:brown_terracotta
setblock 268 138 466 minecraft:bone_block
fill 268 138 467 268 141 467 minecraft:brown_terracotta
setblock 269 138 465 minecraft:bone_block
fill 269 138 466 269 141 466 minecraft:brown_terracotta
setblock 270 138 464 minecraft:bone_block
fill 270 138 465 270 141 465 minecraft:brown_terracotta
setblock 270 138 504 minecraft:bone_block
fill 271 138 464 271 141 464 minecraft:brown_terracotta
setblock 271 138 467 minecraft:brown_terracotta
setblock 271 138 503 minecraft:bone_block
fill 271 138 504 271 141 504 minecraft:brown_terracotta
setblock 272 138 466 minecraft:brown_terracotta
setblock 272 138 503 minecraft:brown_terracotta
setblock 273 138 466 minecraft:bone_block
setblock 274 138 465 minecraft:bone_block
fill 274 138 466 274 139 467 minecraft:brown_terracotta
setblock 275 138 464 minecraft:bone_block
fill 275 138 465 275 141 465 minecraft:brown_terracotta
setblock 275 138 469 minecraft:bone_block
setblock 275 138 504 minecraft:bone_block
fill 276 138 464 276 141 464 minecraft:brown_terracotta
setblock 276 138 468 minecraft:bone_block
fill 276 138 469 276 141 469 minecraft:brown_terracotta
fill 276 138 471 276 139 471 minecraft:brown_terracotta
setblock 276 138 484 minecraft:brown_terracotta
fill 276 138 486 276 139 486 minecraft:brown_terracotta
setblock 276 138 503 minecraft:bone_block
fill 276 138 504 276 141 504 minecraft:brown_terracotta
fill 236 139 464 236 139 466 minecraft:brown_terracotta
setblock 236 139 467 minecraft:bone_block
fill 236 139 468 236 142 468 minecraft:brown_terracotta
setblock 236 139 487 minecraft:bone_block
fill 236 139 488 237 141 488 minecraft:brown_terracotta
setblock 236 139 492 minecraft:bone_block
fill 236 139 493 236 142 493 minecraft:brown_terracotta
setblock 236 139 502 minecraft:bone_block
fill 236 139 503 236 142 503 minecraft:brown_terracotta
fill 237 139 464 237 139 465 minecraft:brown_terracotta
setblock 237 139 466 minecraft:bone_block
fill 237 139 487 237 142 487 minecraft:brown_terracotta
fill 237 139 489 237 140 489 minecraft:brown_terracotta
setblock 237 139 502 minecraft:brown_terracotta
setblock 238 139 464 minecraft:brown_terracotta
setblock 238 139 465 minecraft:bone_block
setblock 238 139 466 minecraft:light[level=12]
setblock 238 139 474 minecraft:light[level=12]
setblock 238 139 482 minecraft:light[level=12]
setblock 238 139 490 minecraft:light[level=12]
setblock 238 139 498 minecraft:light[level=12]
setblock 239 139 464 minecraft:bone_block
fill 239 139 465 242 139 465 minecraft:brown_terracotta
setblock 239 139 504 minecraft:bone_block
fill 240 139 464 240 142 464 minecraft:brown_terracotta
setblock 240 139 503 minecraft:bone_block
fill 240 139 504 240 142 504 minecraft:brown_terracotta
setblock 241 139 502 minecraft:bone_block
fill 241 139 503 241 142 503 minecraft:brown_terracotta
setblock 242 139 502 minecraft:brown_terracotta
setblock 243 139 465 minecraft:bone_block
fill 243 139 466 246 139 466 minecraft:brown_terracotta
setblock 244 139 464 minecraft:bone_block
fill 244 139 465 244 142 465 minecraft:brown_terracotta
setblock 244 139 504 minecraft:bone_block
fill 245 139 464 245 142 464 minecraft:brown_terracotta
setblock 245 139 503 minecraft:bone_block
fill 245 139 504 245 142 504 minecraft:brown_terracotta
setblock 246 139 474 minecraft:light[level=12]
setblock 246 139 482 minecraft:light[level=12]
setblock 246 139 490 minecraft:light[level=12]
setblock 246 139 498 minecraft:light[level=12]
setblock 246 139 502 minecraft:bone_block
fill 246 139 503 246 141 503 minecraft:brown_terracotta
setblock 247 139 502 minecraft:brown_terracotta
setblock 248 139 465 minecraft:bone_block
setblock 249 139 464 minecraft:bone_block
fill 249 139 465 249 140 465 minecraft:brown_terracotta
setblock 249 139 504 minecraft:bone_block
fill 250 139 464 250 141 464 minecraft:brown_terracotta
fill 250 139 504 250 140 504 minecraft:brown_terracotta
setblock 254 139 464 minecraft:bone_block
setblock 254 139 466 minecraft:light[level=12]
setblock 254 139 474 minecraft:light[level=12]
setblock 254 139 482 minecraft:light[level=12]
setblock 254 139 490 minecraft:light[level=12]
setblock 254 139 498 minecraft:light[level=12]
fill 255 139 464 258 139 464 minecraft:brown_terracotta
setblock 258 139 465 minecraft:bone_block
setblock 259 139 464 minecraft:bone_block
fill 259 139 465 259 142 465 minecraft:brown_terracotta
fill 260 139 464 260 142 464 minecraft:brown_terracotta
fill 260 139 504 260 140 504 minecraft:brown_terracotta
setblock 261 139 466 minecraft:brown_terracotta
setblock 262 139 466 minecraft:bone_block
setblock 262 139 474 minecraft:light[level=12]
setblock 262 139 482 minecraft:light[level=12]
setblock 262 139 490 minecraft:light[level=12]
setblock 262 139 498 minecraft:light[level=12]
setblock 263 139 465 minecraft:bone_block
fill 263 139 466 265 139 467 minecraft:brown_terracotta
setblock 264 139 464 minecraft:bone_block
fill 264 139 465 264 142 465 minecraft:brown_terracotta
setblock 264 139 504 minecraft:bone_block
fill 265 139 464 265 142 464 minecraft:brown_terracotta
setblock 265 139 503 minecraft:bone_block
fill 265 139 504 265 142 504 minecraft:brown_terracotta
setblock 266 139 466 minecraft:brown_terracotta
setblock 266 139 467 minecraft:bone_block
fill 266 139 503 266 140 503 minecraft:brown_terracotta
setblock 267 139 466 minecraft:bone_block
fill 267 139 467 267 142 467 minecraft:brown_terracotta
setblock 268 139 465 minecraft:bone_block
fill 268 139 466 268 142 466 minecraft:brown_terracotta
setblock 269 139 464 minecraft:bone_block
fill 269 139 465 269 142 465 minecraft:brown_terracotta
setblock 269 139 504 minecraft:bone_block
fill 270 139 464 270 142 464 minecraft:brown_terracotta
setblock 270 139 474 minecraft:light[level=12]
setblock 270 139 482 minecraft:light[level=12]
setblock 270 139 490 minecraft:light[level=12]
setblock 270 139 498 minecraft:light[level=12]
setblock 270 139 503 minecraft:bone_block
fill 270 139 504 270 142 504 minecraft:brown_terracotta
setblock 271 139 503 minecraft:brown_terracotta
setblock 272 139 466 minecraft:bone_block
setblock 273 139 465 minecraft:bone_block
fill 273 139 466 273 140 466 minecraft:brown_terracotta
setblock 274 139 464 minecraft:bone_block
fill 274 139 465 274 142 465 minecraft:brown_terracotta
setblock 274 139 504 minecraft:bone_block
fill 275 139 464 275 142 464 minecraft:brown_terracotta
setblock 275 139 467 minecraft:brown_terracotta
setblock 275 139 468 minecraft:bone_block
fill 275 139 469 275 141 469 minecraft:brown_terracotta
fill 275 139 504 275 142 504 minecraft:brown_terracotta
setblock 276 139 467 minecraft:bone_block
fill 276 139 468 276 142 468 minecraft:brown_terracotta
setblock 276 139 487 minecraft:bone_block
setblock 276 139 502 minecraft:bone_block
fill 276 139 503 276 141 503 minecraft:brown_terracotta
fill 236 140 464 236 140 465 minecraft:brown_terracotta
setblock 236 140 466 minecraft:bone_block
fill 236 140 467 236 143 467 minecraft:brown_terracotta
setblock 236 140 486 minecraft:bone_block
fill 236 140 487 236 143 487 minecraft:brown_terracotta
fill 236 140 489 236 140 490 minecraft:brown_terracotta
setblock 236 140 491 minecraft:bone_block
fill 236 140 492 236 143 492 minecraft:brown_terracotta
fill 236 140 494 236 140 495 minecraft:brown_terracotta
setblock 236 140 501 minecraft:bone_block
fill 236 140 502 236 142 502 minecraft:brown_terracotta
setblock 237 140 464 minecraft:brown_terracotta
setblock 237 140 465 minecraft:bone_block
setblock 237 140 490 minecraft:bone_block
fill 237 140 491 237 143 491 minecraft:brown_terracotta
setblock 238 140 464 minecraft:bone_block
fill 238 140 465 241 140 465 minecraft:brown_terracotta
setblock 238 140 504 minecraft:bone_block
fill 239 140 464 239 143 464 minecraft:brown_terracotta
setblock 239 140 503 minecraft:bone_block
fill 239 140 504 239 143 504 minecraft:brown_terracotta
fill 240 140 503 240 142 503 minecraft:brown_terracotta
setblock 242 140 465 minecraft:bone_block
setblock 243 140 464 minecraft:bone_block
fill 243 140 465 243 140 466 minecraft:brown_terracotta
setblock 243 140 504 minecraft:bone_block
fill 244 140 464 244 143 464 minecraft:brown_terracotta
fill 244 140 466 245 140 466 minecraft:brown_terracotta
setblock 244 140 503 minecraft:bone_block
fill 244 140 504 244 143 504 minecraft:brown_terracotta
fill 245 140 503 245 142 503 minecraft:brown_terracotta
setblock 246 140 466 minecraft:bone_block
setblock 247 140 465 minecraft:bone_block
setblock 248 140 464 minecraft:bone_block
fill 248 140 465 248 141 465 minecraft:brown_terracotta
setblock 248 140 504 minecraft:bone_block
fill 249 140 464 249 142 464 minecraft:brown_terracotta
fill 249 140 504 249 141 504 minecraft:brown_terracotta
setblock 253 140 464 minecraft:bone_block
fill 254 140 464 257 140 464 minecraft:brown_terracotta
setblock 258 140 464 minecraft:bone_block
fill 258 140 465 258 143 465 minecraft:brown_terracotta
fill 259 140 464 259 143 464 minecraft:brown_terracotta
setblock 260 140 466 minecraft:brown_terracotta
setblock 261 140 466 minecraft:bone_block
setblock 262 140 465 minecraft:bone_block
fill 262 140 466 264 140 467 minecraft:brown_terracotta
setblock 263 140 464 minecraft:bone_block
fill 263 140 465 263 143 465 minecraft:brown_terracotta
setblock 263 140 504 minecraft:bone_block
fill 264 140 464 264 143 464 minecraft:brown_terracotta
setblock 264 140 503 minecraft:bone_block
fill 264 140 504 264 143 504 minecraft:brown_terracotta
setblock 265 140 466 minecraft:brown_terracotta
setblock 265 140 467 minecraft:bone_block
setblock 265 140 503 minecraft:brown_terracotta
setblock 266 140 466 minecraft:bone_block
fill 266 140 467 266 143 467 minecraft:brown_terracotta
setblock 267 140 465 minecraft:bone_block
fill 267 140 466 267 143 466 minecraft:brown_terracotta
setblock 268 140 464 minecraft:bone_block
fill 268 140 465 268 143 465 minecraft:brown_terracotta
setblock 268 140 504 minecraft:bone_block
fill 269 140 464 269 143 464 minecraft:brown_terracotta
setblock 269 140 467 minecraft:brown_terracotta
setblock 269 140 503 minecraft:bone_block
fill 269 140 504 269 142 504 minecraft:brown_terracotta
setblock 270 140 467 minecraft:bone_block
setblock 271 140 466 minecraft:bone_block
setblock 272 140 465 minecraft:bone_block
fill 272 140 466 272 141 466 minecraft:brown_terracotta
setblock 273 140 464 minecraft:bone_block
fill 273 140 465 273 143 465 minecraft:brown_terracotta
setblock 273 140 504 minecraft:bone_block
fill 274 140 464 274 143 464 minecraft:brown_terracotta
setblock 274 140 466 minecraft:brown_terracotta
fill 274 140 504 274 141 504 minecraft:brown_terracotta
setblock 275 140 467 minecraft:bone_block
fill 275 140 468 275 143 468 minecraft:brown_terracotta
setblock 276 140 466 minecraft:bone_block
fill 276 140 467 276 143 467 minecraft:brown_terracotta
setblock 276 140 471 minecraft:bone_block
setblock 276 140 502 minecraft:brown_terracotta
setblock 236 141 464 minecraft:brown_terracotta
setblock 236 141 465 minecraft:bone_block
fill 236 141 466 236 144 466 minecraft:brown_terracotta
setblock 236 141 485 minecraft:bone_block
fill 236 141 486 236 144 486 minecraft:brown_terracotta
setblock 236 141 489 minecraft:brown_terracotta
setblock 236 141 490 minecraft:bone_block
fill 236 141 491 236 144 491 minecraft:brown_terracotta
setblock 236 141 494 minecraft:brown_terracotta
setblock 236 141 495 minecraft:bone_block
fill 236 141 496 236 144 496 minecraft:brown_terracotta
setblock 236 141 501 minecraft:brown_terracotta
setblock 237 141 464 minecraft:bone_block
setblock 237 141 489 minecraft:bone_block
fill 237 141 490 237 144 490 minecraft:brown_terracotta
fill 237 141 492 237 142 492 minecraft:brown_terracotta
setblock 237 141 504 minecraft:bone_block
fill 238 141 464 238 141 465 minecraft:brown_terracotta
fill 238 141 504 238 144 504 minecraft:brown_terracotta
fill 239 141 465 240 141 465 minecraft:brown_terracotta
setblock 239 141 503 minecraft:brown_terracotta
setblock 241 141 465 minecraft:bone_block
setblock 242 141 464 minecraft:bone_block
fill 242 141 465 243 143 465 minecraft:brown_terracotta
setblock 242 141 504 minecraft:bone_block
fill 243 141 464 243 144 464 minecraft:brown_terracotta
setblock 243 141 503 minecraft:bone_block
fill 243 141 504 243 144 504 minecraft:brown_terracotta
fill 244 141 503 244 142 503 minecraft:brown_terracotta
setblock 246 141 465 minecraft:bone_block
setblock 247 141 464 minecraft:bone_block
setblock 247 141 465 minecraft:brown_terracotta
setblock 247 141 504 minecraft:bone_block
fill 248 141 464 248 142 464 minecraft:brown_terracotta
fill 248 141 504 248 142 504 minecraft:brown_terracotta
setblock 256 141 464 minecraft:brown_terracotta
setblock 257 141 464 minecraft:bone_block
fill 258 141 464 258 144 464 minecraft:brown_terracotta
setblock 260 141 466 minecraft:bone_block
setblock 261 141 465 minecraft:bone_block
fill 261 141 466 264 141 466 minecraft:brown_terracotta
setblock 262 141 464 minecraft:bone_block
fill 262 141 465 262 144 465 minecraft:brown_terracotta
fill 262 141 467 263 141 467 minecraft:brown_terracotta
setblock 262 141 504 minecraft:bone_block
fill 263 141 464 263 144 464 minecraft:brown_terracotta
fill 263 141 504 263 144 504 minecraft:brown_terracotta
setblock 264 141 467 minecraft:bone_block
setblock 265 141 466 minecraft:bone_block
fill 265 141 467 265 144 467 minecraft:brown_terracotta
setblock 266 141 465 minecraft:bone_block
fill 266 141 466 266 144 466 minecraft:brown_terracotta
setblock 267 141 464 minecraft:bone_block
fill 267 141 465 267 144 465 minecraft:brown_terracotta
setblock 267 141 504 minecraft:bone_block
fill 268 141 464 268 144 464 minecraft:brown_terracotta
fill 268 141 504 268 143 504 minecraft:brown_terracotta
setblock 269 141 467 minecraft:bone_block
setblock 270 141 466 minecraft:bone_block
setblock 271 141 465 minecraft:bone_block
fill 271 141 466 271 142 466 minecraft:brown_terracotta
setblock 272 141 464 minecraft:bone_block
fill 272 141 465 272 143 465 minecraft:brown_terracotta
setblock 272 141 504 minecraft:bone_block
fill 273 141 464 273 144 464 minecraft:brown_terracotta
setblock 273 141 504 minecraft:brown_terracotta
setblock 275 141 466 minecraft:bone_block
fill 275 141 467 275 143 467 minecraft:brown_terracotta
setblock 276 141 465 minecraft:bone_block
fill 276 141 466 276 144 466 minecraft:brown_terracotta
setblock 276 141 470 minecraft:bone_block
fill 276 141 471 276 144 471 minecraft:brown_terracotta
setblock 236 142 464 minecraft:bone_block
fill 236 142 465 236 143 465 minecraft:brown_terracotta
setblock 236 142 488 minecraft:brown_terracotta
setblock 236 142 489 minecraft:bone_block
fill 236 142 490 236 145 490 minecraft:brown_terracotta
setblock 236 142 494 minecraft:bone_block
fill 236 142 495 236 145 495 minecraft:brown_terracotta
setblock 236 142 504 minecraft:bone_block
fill 237 142 464 238 143 464 minecraft:brown_terracotta
setblock 237 142 488 minecraft:bone_block
fill 237 142 489 237 145 489 minecraft:brown_terracotta
setblock 237 142 493 minecraft:bone_block
fill 237 142 504 237 144 504 minecraft:brown_terracotta
setblock 239 142 465 minecraft:brown_terracotta
setblock 240 142 465 minecraft:bone_block
setblock 241 142 464 minecraft:bone_block
fill 241 142 465 241 143 465 minecraft:brown_terracotta
setblock 241 142 504 minecraft:bone_block
fill 242 142 464 242 145 464 minecraft:brown_terracotta
setblock 242 142 503 minecraft:bone_block
fill 242 142 504 242 145 504 minecraft:brown_terracotta
setblock 243 142 503 minecraft:brown_terracotta
setblock 245 142 465 minecraft:bone_block
setblock 246 142 464 minecraft:bone_block
setblock 246 142 465 minecraft:brown_terracotta
setblock 246 142 504 minecraft:bone_block
fill 247 142 464 247 143 464 minecraft:brown_terracotta
setblock 247 142 504 minecraft:brown_terracotta
fill 257 142 464 257 145 464 minecraft:brown_terracotta
setblock 260 142 465 minecraft:bone_block
fill 260 142 466 263 142 466 minecraft:brown_terracotta
setblock 261 142 464 minecraft:bone_block
fill 261 142 465 261 145 465 minecraft:brown_terracotta
setblock 261 142 504 minecraft:bone_block
fill 262 142 464 262 145 464 minecraft:brown_terracotta
setblock 262 142 467 minecraft:brown_terracotta
fill 262 142 504 262 143 504 minecraft:brown_terracotta
setblock 263 142 467 minecraft:bone_block
setblock 264 142 466 minecraft:bone_block
fill 264 142 467 264 144 467 minecraft:brown_terracotta
setblock 265 142 465 minecraft:bone_block
fill 265 142 466 265 145 466 minecraft:brown_terracotta
setblock 266 142 464 minecraft:bone_block
fill 266 142 465 266 145 465 minecraft:brown_terracotta
setblock 266 142 504 minecraft:bone_block
fill 267 142 464 267 145 464 minecraft:brown_terracotta
fill 267 142 504 267 143 504 minecraft:brown_terracotta
setblock 268 142 467 minecraft:bone_block
setblock 269 142 466 minecraft:bone_block
setblock 270 142 465 minecraft:bone_block
setblock 270 142 466 minecraft:brown_terracotta
setblock 271 142 464 minecraft:bone_block
fill 271 142 465 271 143 465 minecraft:brown_terracotta
setblock 271 142 504 minecraft:bone_block
fill 272 142 464 272 145 464 minecraft:brown_terracotta
setblock 275 142 465 minecraft:bone_block
fill 275 142 466 275 143 466 minecraft:brown_terracotta
setblock 276 142 464 minecraft:bone_block
fill 276 142 465 276 145 465 minecraft:brown_terracotta
setblock 276 142 469 minecraft:bone_block
fill 276 142 470 276 145 470 minecraft:brown_terracotta
setblock 276 142 504 minecraft:bone_block
setblock 236 143 464 minecraft:brown_terracotta
setblock 236 143 468 minecraft:bone_block
setblock 236 143 488 minecraft:bone_block
fill 236 143 489 236 146 489 minecraft:brown_terracotta
setblock 236 143 493 minecraft:bone_block
fill 236 143 494 237 145 494 minecraft:brown_terracotta
setblock 236 143 497 minecraft:brown_terracotta
setblock 236 143 504 minecraft:brown_terracotta
fill 237 143 488 237 146 488 minecraft:brown_terracotta
setblock 237 143 492 minecraft:bone_block
fill 237 143 493 237 146 493 minecraft:brown_terracotta
setblock 238 143 490 minecraft:brown_terracotta
setblock 238 143 491 minecraft:bone_block
setblock 240 143 464 minecraft:bone_block
setblock 240 143 504 minecraft:bone_block
fill 241 143 464 241 146 464 minecraft:brown_terracotta
fill 241 143 504 241 146 504 minecraft:brown_terracotta
setblock 244 143 465 minecraft:bone_block
setblock 245 143 464 minecraft:bone_block
setblock 245 143 504 minecraft:bone_block
setblock 246 143 464 minecraft:brown_terracotta
setblock 246 143 504 minecraft:brown_terracotta
setblock 259 143 465 minecraft:bone_block
setblock 260 143 464 minecraft:bone_block
fill 260 143 465 260 145 466 minecraft:brown_terracotta
fill 261 143 464 261 146 464 minecraft:brown_terracotta
fill 261 143 466 262 143 466 minecraft:brown_terracotta
setblock 262 143 467 minecraft:bone_block
setblock 263 143 466 minecraft:bone_block
fill 263 143 467 263 145 467 minecraft:brown_terracotta
setblock 264 143 465 minecraft:bone_block
fill 264 143 466 264 146 466 minecraft:brown_terracotta
setblock 265 143 464 minecraft:bone_block
fill 265 143 465 265 146 465 minecraft:brown_terracotta
setblock 265 143 504 minecraft:bone_block
fill 266 143 464 266 146 464 minecraft:brown_terracotta
fill 266 143 504 266 144 504 minecraft:brown_terracotta
setblock 268 143 466 minecraft:bone_block
setblock 269 143 465 minecraft:bone_block
setblock 269 143 466 minecraft:brown_terracotta
setblock 270 143 464 minecraft:bone_block
fill 270 143 465 270 144 465 minecraft:brown_terracotta
fill 271 143 464 271 145 464 minecraft:brown_terracotta
setblock 274 143 465 minecraft:bone_block
setblock 275 143 464 minecraft:bone_block
setblock 275 143 465 minecraft:brown_terracotta
fill 276 143 464 276 146 464 minecraft:brown_terracotta
setblock 276 143 468 minecraft:bone_block
fill 276 143 469 276 146 469 minecraft:brown_terracotta
setblock 276 143 504 minecraft:brown_terracotta
setblock 236 144 467 minecraft:bone_block
setblock 236 144 468 minecraft:brown_terracotta
setblock 236 144 487 minecraft:bone_block
fill 236 144 488 236 147 488 minecraft:brown_terracotta
setblock 236 144 492 minecraft:bone_block
fill 236 144 493 236 147 493 minecraft:brown_terracotta
setblock 236 144 497 minecraft:bone_block
fill 236 144 498 236 147 498 minecraft:brown_terracotta
setblock 237 144 491 minecraft:bone_block
fill 237 144 492 238 146 492 minecraft:brown_terracotta
setblock 237 144 495 minecraft:brown_terracotta
setblock 238 144 464 minecraft:brown_terracotta
setblock 238 144 489 minecraft:brown_terracotta
setblock 238 144 490 minecraft:bone_block
fill 238 144 491 238 147 491 minecraft:brown_terracotta
fill 238 144 493 238 145 493 minecraft:brown_terracotta
setblock 239 144 464 minecraft:bone_block
setblock 239 144 504 minecraft:bone_block
fill 240 144 464 240 146 464 minecraft:brown_terracotta
fill 240 144 504 240 147 504 minecraft:brown_terracotta
setblock 244 144 464 minecraft:bone_block
setblock 244 144 504 minecraft:bone_block
setblock 245 144 464 minecraft:brown_terracotta
setblock 259 144 464 minecraft:bone_block
fill 259 144 465 259 147 465 minecraft:brown_terracotta
fill 260 144 464 260 147 464 minecraft:brown_terracotta
setblock 261 144 466 minecraft:brown_terracotta
setblock 262 144 466 minecraft:bone_block
setblock 262 144 467 minecraft:brown_terracotta
setblock 263 144 465 minecraft:bone_block
fill 263 144 466 263 147 466 minecraft:brown_terracotta
setblock 264 144 464 minecraft:bone_block
fill 264 144 465 264 147 465 minecraft:brown_terracotta
setblock 264 144 504 minecraft:bone_block
fill 265 144 464 265 147 464 minecraft:brown_terracotta
setblock 265 144 504 minecraft:brown_terracotta
setblock 267 144 466 minecraft:bone_block
setblock 268 144 465 minecraft:bone_block
setblock 268 144 466 minecraft:brown_terracotta
setblock 269 144 464 minecraft:bone_block
fill 269 144 465 269 145 465 minecraft:brown_terracotta
fill 270 144 464 270 146 464 minecraft:brown_terracotta
setblock 274 144 464 minecraft:bone_block
fill 275 144 464 275 147 464 minecraft:brown_terracotta
setblock 276 144 467 minecraft:bone_block
fill 276 144 468 276 147 468 minecraft:brown_terracotta
setblock 276 144 491 minecraft:brown_terracotta
setblock 276 144 492 minecraft:bone_block
setblock 236 145 486 minecraft:bone_block
fill 236 145 487 236 148 487 minecraft:brown_terracotta
setblock 236 145 491 minecraft:bone_block
fill 236 145 492 236 148 492 minecraft:brown_terracotta
setblock 236 145 496 minecraft:bone_block
fill 236 145 497 236 148 497 minecraft:brown_terracotta
fill 236 145 499 236 146 499 minecraft:brown_terracotta
setblock 237 145 490 minecraft:bone_block
fill 237 145 491 237 148 491 minecraft:brown_terracotta
setblock 237 145 495 minecraft:bone_block
fill 237 145 496 237 148 496 minecraft:brown_terracotta
setblock 238 145 489 minecraft:bone_block
fill 238 145 490 238 148 490 minecraft:brown_terracotta
setblock 238 145 494 minecraft:bone_block
setblock 238 145 504 minecraft:bone_block
setblock 239 145 464 minecraft:brown_terracotta
fill 239 145 504 239 148 504 minecraft:brown_terracotta
setblock 243 145 464 minecraft:bone_block
setblock 243 145 504 minecraft:bone_block
setblock 244 145 464 minecraft:brown_terracotta
setblock 258 145 464 minecraft:bone_block
fill 259 145 464 259 148 464 minecraft:brown_terracotta
setblock 261 145 466 minecraft:bone_block
setblock 262 145 465 minecraft:bone_block
fill 262 145 466 262 148 466 minecraft:brown_terracotta
setblock 263 145 464 minecraft:bone_block
fill 263 145 465 263 148 465 minecraft:brown_terracotta
fill 264 145 464 264 148 464 minecraft:brown_terracotta
setblock 266 145 466 minecraft:bone_block
setblock 267 145 465 minecraft:bone_block
setblock 268 145 464 minecraft:bone_block
setblock 268 145 465 minecraft:brown_terracotta
fill 269 145 464 269 147 464 minecraft:brown_terracotta
setblock 273 145 464 minecraft:bone_block
setblock 274 145 464 minecraft:brown_terracotta
setblock 276 145 466 minecraft:bone_block
fill 276 145 467 276 148 467 minecraft:brown_terracotta
setblock 276 145 471 minecraft:bone_block
setblock 276 145 490 minecraft:brown_terracotta
setblock 276 145 491 minecraft:bone_block
fill 276 145 492 276 145 495 minecraft:brown_terracotta
setblock 236 146 469 minecraft:brown_terracotta
fill 236 146 486 236 149 486 minecraft:brown_terracotta
setblock 236 146 490 minecraft:bone_block
fill 236 146 491 236 149 491 minecraft:brown_terracotta
setblock 236 146 494 minecraft:brown_terracotta
setblock 236 146 495 minecraft:bone_block
fill 236 146 496 236 149 496 minecraft:brown_terracotta
setblock 236 146 500 minecraft:bone_block
fill 237 146 487 237 147 487 minecraft:brown_terracotta
setblock 237 146 489 minecraft:bone_block
fill 237 146 490 237 149 490 minecraft:brown_terracotta
setblock 237 146 494 minecraft:bone_block
fill 237 146 495 238 148 495 minecraft:brown_terracotta
fill 237 146 497 237 147 497 minecraft:brown_terracotta
fill 238 146 489 238 149 489 minecraft:brown_terracotta
setblock 238 146 493 minecraft:bone_block
fill 238 146 494 238 149 494 minecraft:brown_terracotta
fill 238 146 504 238 149 504 minecraft:brown_terracotta
setblock 242 146 464 minecraft:bone_block
setblock 242 146 504 minecraft:bone_block
setblock 257 146 464 minecraft:bone_block
fill 258 146 464 258 148 465 minecraft:brown_terracotta
setblock 260 146 465 minecraft:brown_terracotta
setblock 260 146 466 minecraft:bone_block
setblock 261 146 465 minecraft:bone_block
fill 261 146 466 261 149 466 minecraft:brown_terracotta
setblock 262 146 464 minecraft:bone_block
fill 262 146 465 262 149 465 minecraft:brown_terracotta
fill 263 146 464 263 149 464 minecraft:brown_terracotta
setblock 265 146 466 minecraft:bone_block
setblock 266 146 465 minecraft:bone_block
setblock 267 146 464 minecraft:bone_block
setblock 267 146 465 minecraft:brown_terracotta
fill 268 146 464 268 149 464 minecraft:brown_terracotta
setblock 276 146 465 minecraft:bone_block
fill 276 146 466 276 149 466 minecraft:brown_terracotta
setblock 276 146 470 minecraft:bone_block
fill 276 146 471 276 148 472 minecraft:brown_terracotta
setblock 276 146 489 minecraft:brown_terracotta
setblock 276 146 490 minecraft:bone_block
fill 276 146 491 276 146 494 minecraft:brown_terracotta
setblock 276 146 495 minecraft:bone_block
fill 276 146 496 276 147 498 minecraft:brown_terracotta
setblock 236 147 468 minecraft:brown_terracotta
setblock 236 147 469 minecraft:bone_block
fill 236 147 470 236 148 472 minecraft:brown_terracotta
setblock 236 147 489 minecraft:bone_block
fill 236 147 490 236 150 490 minecraft:brown_terracotta
setblock 236 147 494 minecraft:bone_block
fill 236 147 495 236 150 495 minecraft:brown_terracotta
setblock 236 147 499 minecraft:bone_block
fill 236 147 500 236 149 501 minecraft:brown_terracotta
setblock 237 147 488 minecraft:bone_block
fill 237 147 489 237 150 489 minecraft:brown_terracotta
setblock 237 147 492 minecraft:brown_terracotta
setblock 237 147 493 minecraft:bone_block
fill 237 147 494 237 150 494 minecraft:brown_terracotta
setblock 237 147 498 minecraft:bone_block
fill 237 147 499 237 150 499 minecraft:brown_terracotta
setblock 238 147 466 minecraft:light[level=12]
setblock 238 147 474 minecraft:light[level=12]
setblock 238 147 482 minecraft:light[level=12]
setblock 238 147 492 minecraft:bone_block
fill 238 147 493 239 149 493 minecraft:brown_terracotta
setblock 238 147 496 minecraft:brown_terracotta
setblock 238 147 497 minecraft:bone_block
setblock 238 147 498 minecraft:light[level=12]
setblock 239 147 491 minecraft:bone_block
fill 239 147 492 239 150 492 minecraft:brown_terracotta
fill 239 147 494 239 148 494 minecraft:brown_terracotta
setblock 241 147 504 minecraft:bone_block
setblock 246 147 466 minecraft:light[level=12]
setblock 246 147 474 minecraft:light[level=12]
setblock 246 147 482 minecraft:light[level=12]
setblock 246 147 490 minecraft:light[level=12]
setblock 246 147 498 minecraft:light[level=12]
setblock 254 147 466 minecraft:light[level=12]
setblock 254 147 474 minecraft:light[level=12]
setblock 254 147 482 minecraft:light[level=12]
setblock 254 147 490 minecraft:light[level=12]
setblock 254 147 498 minecraft:light[level=12]
fill 257 147 464 257 150 464 minecraft:brown_terracotta
setblock 260 147 465 minecraft:bone_block
fill 260 147 466 260 150 466 minecraft:brown_terracotta
setblock 261 147 464 minecraft:bone_block
fill 261 147 465 261 150 465 minecraft:brown_terracotta
fill 262 147 464 262 150 464 minecraft:brown_terracotta
setblock 262 147 474 minecraft:light[level=12]
setblock 262 147 482 minecraft:light[level=12]
setblock 262 147 490 minecraft:light[level=12]
setblock 262 147 498 minecraft:light[level=12]
setblock 264 147 466 minecraft:bone_block
setblock 265 147 465 minecraft:bone_block
setblock 266 147 464 minecraft:bone_block
fill 266 147 465 266 148 465 minecraft:brown_terracotta
fill 267 147 464 267 150 464 minecraft:brown_terracotta
setblock 270 147 466 minecraft:light[level=12]
setblock 270 147 474 minecraft:light[level=12]
setblock 270 147 482 minecraft:light[level=12]
setblock 270 147 490 minecraft:light[level=12]
setblock 270 147 498 minecraft:light[level=12]
setblock 276 147 464 minecraft:bone_block
fill 276 147 465 276 150 465 minecraft:brown_terracotta
setblock 276 147 469 minecraft:bone_block
fill 276 147 470 276 150 470 minecraft:brown_terracotta
setblock 276 147 473 minecraft:brown_terracotta
setblock 276 147 489 minecraft:bone_block
fill 276 147 490 276 147 493 minecraft:brown_terracotta
setblock 276 147 494 minecraft:bone_block
fill 276 147 495 276 150 495 minecraft:brown_terracotta
setblock 276 147 499 minecraft:bone_block
fill 276 147 500 276 147 503 minecraft:brown_terracotta
setblock 276 147 504 minecraft:bone_block
setblock 236 148 467 minecraft:brown_terracotta
setblock 236 148 468 minecraft:bone_block
fill 236 148 469 236 151 469 minecraft:brown_terracotta
setblock 236 148 473 minecraft:bone_block
fill 236 148 474 236 150 475 minecraft:brown_terracotta
fill 236 148 485 236 150 485 minecraft:brown_terracotta
setblock 236 148 488 minecraft:bone_block
fill 236 148 489 236 151 489 minecraft:brown_terracotta
setblock 236 148 493 minecraft:bone_block
fill 236 148 494 236 151 494 minecraft:brown_terracotta
setblock 236 148 498 minecraft:bone_block
fill 236 148 499 236 151 499 minecraft:brown_terracotta
setblock 236 148 502 minecraft:brown_terracotta
setblock 236 148 503 minecraft:bone_block
setblock 237 148 487 minecraft:bone_block
fill 237 148 488 238 150 488 minecraft:brown_terracotta
setblock 237 148 492 minecraft:bone_block
fill 237 148 493 237 151 493 minecraft:brown_terracotta
setblock 237 148 497 minecraft:bone_block
fill 237 148 498 238 150 498 minecraft:brown_terracotta
fill 237 148 500 237 149 500 minecraft:brown_terracotta
fill 237 148 504 237 150 504 minecraft:brown_terracotta
setblock 238 148 491 minecraft:bone_block
fill 238 148 492 238 151 492 minecraft:brown_terracotta
setblock 238 148 496 minecraft:bone_block
fill 238 148 497 238 151 497 minecraft:brown_terracotta
setblock 239 148 490 minecraft:bone_block
fill 239 148 491 239 151 491 minecraft:brown_terracotta
setblock 239 148 495 minecraft:bone_block
fill 239 148 496 239 151 496 minecraft:brown_terracotta
setblock 240 148 504 minecraft:bone_block
fill 241 148 504 241 151 504 minecraft:brown_terracotta
fill 256 148 464 256 151 464 minecraft:brown_terracotta
fill 258 148 497 262 149 501 minecraft:soul_soil
setblock 259 148 465 minecraft:bone_block
fill 259 148 466 259 151 466 minecraft:brown_terracotta
setblock 260 148 464 minecraft:bone_block
fill 260 148 465 260 151 465 minecraft:brown_terracotta
fill 260 148 502 260 148 503 minecraft:soul_soil
fill 261 148 464 261 151 464 minecraft:brown_terracotta
setblock 263 148 466 minecraft:bone_block
setblock 264 148 465 minecraft:bone_block
setblock 264 148 466 minecraft:brown_terracotta
setblock 265 148 464 minecraft:bone_block
fill 265 148 465 265 150 465 minecraft:brown_terracotta
fill 266 148 464 266 151 464 minecraft:brown_terracotta
setblock 275 148 464 minecraft:bone_block
setblock 275 148 493 minecraft:brown_terracotta
setblock 275 148 494 minecraft:bone_block
fill 275 148 495 275 149 497 minecraft:brown_terracotta
setblock 275 148 504 minecraft:bone_block
fill 276 148 464 276 151 464 minecraft:brown_terracotta
setblock 276 148 468 minecraft:bone_block
fill 276 148 469 276 151 469 minecraft:brown_terracotta
setblock 276 148 473 minecraft:bone_block
fill 276 148 474 276 151 474 minecraft:brown_terracotta
setblock 276 148 488 minecraft:bone_block
fill 276 148 489 276 148 492 minecraft:brown_terracotta
setblock 276 148 493 minecraft:bone_block
fill 276 148 494 276 151 494 minecraft:brown_terracotta
fill 276 148 496 276 148 497 minecraft:brown_terracotta
setblock 276 148 498 minecraft:bone_block
fill 276 148 499 276 148 502 minecraft:brown_terracotta
setblock 276 148 503 minecraft:bone_block
fill 276 148 504 276 151 504 minecraft:brown_terracotta
setblock 236 149 467 minecraft:bone_block
fill 236 149 468 236 152 468 minecraft:brown_terracotta
fill 236 149 470 236 149 471 minecraft:brown_terracotta
setblock 236 149 472 minecraft:bone_block
fill 236 149 473 237 151 473 minecraft:brown_terracotta
setblock 236 149 476 minecraft:brown_terracotta
setblock 236 149 477 minecraft:bone_block
fill 236 149 478 236 152 478 minecraft:brown_terracotta
fill 236 149 484 236 151 484 minecraft:brown_terracotta
setblock 236 149 487 minecraft:bone_block
fill 236 149 488 236 152 488 minecraft:brown_terracotta
setblock 236 149 492 minecraft:bone_block
fill 236 149 493 236 152 493 minecraft:brown_terracotta
setblock 236 149 497 minecraft:bone_block
fill 236 149 498 236 152 498 minecraft:brown_terracotta
setblock 236 149 502 minecraft:bone_block
fill 236 149 503 236 151 504 minecraft:brown_terracotta
setblock 237 149 470 minecraft:brown_terracotta
setblock 237 149 471 minecraft:bone_block
fill 237 149 472 237 152 472 minecraft:brown_terracotta
fill 237 149 474 237 149 475 minecraft:brown_terracotta
setblock 237 149 486 minecraft:bone_block
fill 237 149 487 237 152 487 minecraft:brown_terracotta
setblock 237 149 491 minecraft:bone_block
fill 237 149 492 237 152 492 minecraft:brown_terracotta
setblock 237 149 495 minecraft:brown_terracotta
setblock 237 149 496 minecraft:bone_block
fill 237 149 497 237 152 497 minecraft:brown_terracotta
setblock 237 149 501 minecraft:bone_block
setblock 238 149 490 minecraft:bone_block
fill 238 149 491 238 152 491 minecraft:brown_terracotta
setblock 238 149 495 minecraft:bone_block
fill 238 149 496 238 152 496 minecraft:brown_terracotta
setblock 238 149 499 minecraft:brown_terracotta
fill 239 149 490 239 152 490 minecraft:brown_terracotta
setblock 239 149 494 minecraft:bone_block
fill 239 149 495 239 152 495 minecraft:brown_terracotta
fill 239 149 497 239 150 497 minecraft:brown_terracotta
setblock 239 149 504 minecraft:bone_block
fill 240 149 504 240 152 504 minecraft:brown_terracotta
setblock 257 149 465 minecraft:brown_terracotta
setblock 258 149 464 minecraft:brown_terracotta
setblock 258 149 465 minecraft:bone_block
fill 258 149 474 258 150 475 minecraft:soul_soil
setblock 259 149 464 minecraft:bone_block
fill 259 149 465 259 152 465 minecraft:brown_terracotta
fill 260 149 464 260 152 464 minecraft:brown_terracotta
fill 260 149 504 263 149 504 minecraft:brown_terracotta
setblock 262 149 466 minecraft:bone_block
setblock 263 149 465 minecraft:bone_block
fill 263 149 466 263 150 466 minecraft:brown_terracotta
setblock 264 149 464 minecraft:bone_block
fill 264 149 465 264 152 465 minecraft:brown_terracotta
fill 265 149 464 265 152 464 minecraft:brown_terracotta
setblock 274 149 464 minecraft:bone_block
setblock 274 149 504 minecraft:bone_block
fill 275 149 464 275 152 464 minecraft:brown_terracotta
fill 275 149 469 275 149 472 minecraft:brown_terracotta
fill 275 149 491 275 149 492 minecraft:brown_terracotta
setblock 275 149 493 minecraft:bone_block
fill 275 149 494 275 152 494 minecraft:brown_terracotta
setblock 275 149 498 minecraft:bone_block
fill 275 149 499 276 150 500 minecraft:brown_terracotta
fill 275 149 504 275 152 504 minecraft:brown_terracotta
setblock 276 149 467 minecraft:bone_block
fill 276 149 468 276 152 468 minecraft:brown_terracotta
setblock 276 149 471 minecraft:brown_terracotta
setblock 276 149 472 minecraft:bone_block
fill 276 149 473 276 152 473 minecraft:brown_terracotta
fill 276 149 475 276 149 476 minecraft:brown_terracotta
fill 276 149 488 276 149 491 minecraft:brown_terracotta
setblock 276 149 492 minecraft:bone_block
fill 276 149 493 276 152 493 minecraft:brown_terracotta
setblock 276 149 496 minecraft:brown_terracotta
setblock 276 149 497 minecraft:bone_block
fill 276 149 498 276 152 498 minecraft:brown_terracotta
setblock 276 149 501 minecraft:brown_terracotta
setblock 276 149 502 minecraft:bone_block
fill 276 149 503 276 152 503 minecraft:brown_terracotta
setblock 236 150 466 minecraft:bone_block
fill 236 150 467 236 153 467 minecraft:brown_terracotta
setblock 236 150 470 minecraft:brown_terracotta
setblock 236 150 471 minecraft:bone_block
fill 236 150 472 236 153 472 minecraft:brown_terracotta
setblock 236 150 476 minecraft:bone_block
fill 236 150 477 237 152 477 minecraft:brown_terracotta
fill 236 150 479 236 150 480 minecraft:brown_terracotta
setblock 236 150 481 minecraft:bone_block
fill 236 150 482 236 152 483 minecraft:brown_terracotta
setblock 236 150 486 minecraft:bone_block
fill 236 150 487 236 153 487 minecraft:brown_terracotta
setblock 236 150 491 minecraft:bone_block
schedule function dropper:buildpart/113_5 1t
