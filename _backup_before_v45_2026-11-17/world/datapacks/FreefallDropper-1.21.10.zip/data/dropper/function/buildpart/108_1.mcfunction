setblock 27 22 466 minecraft:light[level=12]
setblock 27 22 474 minecraft:light[level=12]
setblock 27 22 482 minecraft:light[level=12]
setblock 27 22 490 minecraft:light[level=12]
setblock 27 22 498 minecraft:light[level=12]
setblock 30 22 464 minecraft:bookshelf
setblock 30 22 504 minecraft:bookshelf
setblock 35 22 466 minecraft:light[level=12]
setblock 35 22 474 minecraft:light[level=12]
setblock 35 22 482 minecraft:light[level=12]
setblock 35 22 490 minecraft:light[level=12]
setblock 35 22 498 minecraft:light[level=12]
setblock 37 22 464 minecraft:bookshelf
setblock 37 22 504 minecraft:bookshelf
setblock 41 22 467 minecraft:bookshelf
setblock 41 22 474 minecraft:bookshelf
setblock 41 22 481 minecraft:bookshelf
setblock 41 22 488 minecraft:bookshelf
setblock 41 22 495 minecraft:bookshelf
setblock 41 22 502 minecraft:bookshelf
setblock 1 23 464 minecraft:bookshelf
setblock 1 23 471 minecraft:bookshelf
setblock 1 23 478 minecraft:bookshelf
setblock 1 23 485 minecraft:bookshelf
setblock 1 23 492 minecraft:bookshelf
setblock 1 23 499 minecraft:bookshelf
setblock 3 23 504 minecraft:bookshelf
setblock 8 23 464 minecraft:bookshelf
setblock 10 23 504 minecraft:bookshelf
fill 15 23 464 16 23 466 minecraft:bookshelf
fill 17 23 465 19 23 466 minecraft:bookshelf
setblock 17 23 504 minecraft:bookshelf
fill 18 23 464 19 24 464 minecraft:bookshelf
fill 22 23 464 22 25 464 minecraft:bookshelf
setblock 24 23 504 minecraft:bookshelf
setblock 29 23 464 minecraft:bookshelf
setblock 31 23 504 minecraft:bookshelf
setblock 36 23 464 minecraft:bookshelf
setblock 38 23 504 minecraft:bookshelf
setblock 41 23 466 minecraft:bookshelf
setblock 41 23 473 minecraft:bookshelf
setblock 41 23 480 minecraft:bookshelf
setblock 41 23 487 minecraft:bookshelf
setblock 41 23 494 minecraft:bookshelf
setblock 41 23 501 minecraft:bookshelf
setblock 1 24 465 minecraft:bookshelf
setblock 1 24 472 minecraft:bookshelf
setblock 1 24 479 minecraft:bookshelf
setblock 1 24 486 minecraft:bookshelf
setblock 1 24 493 minecraft:bookshelf
setblock 1 24 500 minecraft:bookshelf
setblock 4 24 504 minecraft:bookshelf
setblock 7 24 464 minecraft:bookshelf
setblock 11 24 504 minecraft:bookshelf
setblock 14 24 464 minecraft:bookshelf
fill 18 24 465 22 24 466 minecraft:bookshelf
setblock 18 24 504 minecraft:bookshelf
fill 20 24 464 21 25 464 minecraft:bookshelf
setblock 25 24 504 minecraft:bookshelf
setblock 28 24 464 minecraft:bookshelf
setblock 32 24 504 minecraft:bookshelf
setblock 35 24 464 minecraft:bookshelf
setblock 39 24 504 minecraft:bookshelf
setblock 41 24 465 minecraft:bookshelf
setblock 41 24 472 minecraft:bookshelf
setblock 41 24 479 minecraft:bookshelf
setblock 41 24 486 minecraft:bookshelf
setblock 41 24 493 minecraft:bookshelf
setblock 41 24 500 minecraft:bookshelf
setblock 1 25 466 minecraft:bookshelf
setblock 1 25 473 minecraft:bookshelf
setblock 1 25 480 minecraft:bookshelf
setblock 1 25 487 minecraft:bookshelf
setblock 1 25 494 minecraft:bookshelf
setblock 1 25 501 minecraft:bookshelf
setblock 5 25 504 minecraft:bookshelf
setblock 6 25 464 minecraft:bookshelf
setblock 12 25 504 minecraft:bookshelf
setblock 13 25 464 minecraft:bookshelf
setblock 19 25 504 minecraft:bookshelf
fill 21 25 465 25 25 466 minecraft:bookshelf
setblock 23 25 464 minecraft:bookshelf
fill 25 25 464 25 27 464 minecraft:bookshelf
setblock 26 25 504 minecraft:bookshelf
fill 27 25 464 27 26 464 minecraft:bookshelf
setblock 33 25 504 minecraft:bookshelf
setblock 34 25 464 minecraft:bookshelf
setblock 40 25 504 minecraft:bookshelf
setblock 41 25 464 minecraft:bookshelf
setblock 41 25 471 minecraft:bookshelf
setblock 41 25 478 minecraft:bookshelf
setblock 41 25 485 minecraft:bookshelf
setblock 41 25 492 minecraft:bookshelf
setblock 41 25 499 minecraft:bookshelf
setblock 1 26 467 minecraft:bookshelf
setblock 1 26 474 minecraft:bookshelf
setblock 1 26 481 minecraft:bookshelf
setblock 1 26 488 minecraft:bookshelf
setblock 1 26 495 minecraft:bookshelf
setblock 1 26 502 minecraft:bookshelf
setblock 5 26 464 minecraft:bookshelf
setblock 6 26 504 minecraft:bookshelf
setblock 12 26 464 minecraft:bookshelf
setblock 13 26 504 minecraft:bookshelf
setblock 19 26 464 minecraft:bookshelf
setblock 20 26 504 minecraft:bookshelf
fill 24 26 465 28 26 466 minecraft:bookshelf
setblock 26 26 464 minecraft:bookshelf
setblock 27 26 504 minecraft:bookshelf
fill 28 26 464 29 27 464 minecraft:bookshelf
fill 33 26 464 33 28 464 minecraft:bookshelf
setblock 34 26 504 minecraft:bookshelf
setblock 40 26 464 minecraft:bookshelf
setblock 41 26 470 minecraft:bookshelf
setblock 41 26 477 minecraft:bookshelf
setblock 41 26 484 minecraft:bookshelf
setblock 41 26 491 minecraft:bookshelf
setblock 41 26 498 minecraft:bookshelf
setblock 41 26 504 minecraft:bookshelf
setblock 1 27 468 minecraft:bookshelf
setblock 1 27 475 minecraft:bookshelf
setblock 1 27 482 minecraft:bookshelf
setblock 1 27 489 minecraft:bookshelf
setblock 1 27 496 minecraft:bookshelf
setblock 1 27 503 minecraft:bookshelf
setblock 4 27 464 minecraft:bookshelf
setblock 7 27 504 minecraft:bookshelf
setblock 11 27 464 minecraft:bookshelf
setblock 14 27 504 minecraft:bookshelf
setblock 18 27 464 minecraft:bookshelf
setblock 21 27 504 minecraft:bookshelf
fill 27 27 465 32 27 466 minecraft:bookshelf
setblock 28 27 504 minecraft:bookshelf
setblock 30 27 464 minecraft:bookshelf
fill 32 27 464 32 28 464 minecraft:bookshelf
setblock 35 27 504 minecraft:bookshelf
setblock 39 27 464 minecraft:bookshelf
setblock 41 27 469 minecraft:bookshelf
setblock 41 27 476 minecraft:bookshelf
setblock 41 27 483 minecraft:bookshelf
setblock 41 27 490 minecraft:bookshelf
setblock 41 27 497 minecraft:bookshelf
fill 30 28 466 36 28 466 minecraft:bookshelf
fill 31 28 465 37 28 465 minecraft:bookshelf
fill 34 28 464 37 28 464 minecraft:bookshelf
fill 1 29 470 1 30 470 minecraft:bookshelf
fill 1 29 477 1 30 477 minecraft:bookshelf
fill 1 29 484 1 30 484 minecraft:bookshelf
fill 1 29 491 1 30 491 minecraft:bookshelf
fill 1 29 498 1 30 498 minecraft:bookshelf
fill 2 29 464 2 30 464 minecraft:bookshelf
fill 2 29 504 2 30 504 minecraft:bookshelf
fill 9 29 464 9 30 464 minecraft:bookshelf
fill 9 29 504 9 30 504 minecraft:bookshelf
fill 16 29 464 16 30 464 minecraft:bookshelf
fill 16 29 504 16 30 504 minecraft:bookshelf
fill 23 29 464 23 30 464 minecraft:bookshelf
fill 23 29 504 23 30 504 minecraft:bookshelf
fill 30 29 464 30 30 464 minecraft:bookshelf
fill 30 29 504 30 30 504 minecraft:bookshelf
fill 34 29 466 41 29 466 minecraft:bookshelf
fill 35 29 465 41 29 465 minecraft:bookshelf
fill 36 29 464 37 30 464 minecraft:bookshelf
fill 37 29 504 37 30 504 minecraft:bookshelf
fill 39 29 464 41 30 464 minecraft:bookshelf
fill 39 29 467 39 30 468 minecraft:bookshelf
fill 40 29 467 41 30 467 minecraft:bookshelf
fill 41 29 474 41 32 474 minecraft:bookshelf
fill 41 29 481 41 30 481 minecraft:bookshelf
fill 41 29 488 41 30 488 minecraft:bookshelf
fill 41 29 495 41 30 495 minecraft:bookshelf
fill 41 29 502 41 30 502 minecraft:bookshelf
fill 1 30 464 1 30 468 minecraft:bookshelf
fill 1 30 471 1 30 475 minecraft:bookshelf
fill 1 30 478 1 30 482 minecraft:bookshelf
fill 1 30 485 1 30 489 minecraft:bookshelf
fill 1 30 492 1 30 496 minecraft:bookshelf
fill 1 30 499 1 30 503 minecraft:bookshelf
setblock 3 30 466 minecraft:light[level=12]
setblock 3 30 474 minecraft:light[level=12]
setblock 3 30 482 minecraft:light[level=12]
setblock 3 30 490 minecraft:light[level=12]
setblock 3 30 498 minecraft:light[level=12]
fill 3 30 504 7 30 504 minecraft:bookshelf
fill 4 30 464 8 30 464 minecraft:bookshelf
fill 10 30 504 14 30 504 minecraft:bookshelf
fill 11 30 464 15 30 464 minecraft:bookshelf
setblock 11 30 466 minecraft:light[level=12]
setblock 11 30 474 minecraft:light[level=12]
setblock 11 30 482 minecraft:light[level=12]
setblock 11 30 490 minecraft:light[level=12]
fill 11 30 497 12 31 498 minecraft:red_wool
fill 17 30 504 21 30 504 minecraft:bookshelf
fill 18 30 464 22 30 464 minecraft:bookshelf
setblock 19 30 466 minecraft:light[level=12]
setblock 19 30 474 minecraft:light[level=12]
setblock 19 30 482 minecraft:light[level=12]
setblock 19 30 490 minecraft:light[level=12]
setblock 19 30 498 minecraft:light[level=12]
fill 24 30 504 28 30 504 minecraft:bookshelf
fill 25 30 464 29 30 464 minecraft:bookshelf
setblock 27 30 466 minecraft:light[level=12]
setblock 27 30 474 minecraft:light[level=12]
setblock 27 30 482 minecraft:light[level=12]
setblock 27 30 490 minecraft:light[level=12]
setblock 27 30 498 minecraft:light[level=12]
fill 31 30 504 35 30 504 minecraft:bookshelf
fill 32 30 464 35 30 464 minecraft:bookshelf
setblock 35 30 466 minecraft:light[level=12]
setblock 35 30 474 minecraft:light[level=12]
setblock 35 30 482 minecraft:light[level=12]
setblock 35 30 490 minecraft:light[level=12]
setblock 35 30 498 minecraft:light[level=12]
fill 38 30 504 41 30 504 minecraft:bookshelf
fill 39 30 466 41 30 466 minecraft:bookshelf
fill 39 30 469 41 30 472 minecraft:bookshelf
fill 40 30 465 41 30 465 minecraft:bookshelf
setblock 40 30 468 minecraft:bookshelf
fill 41 30 473 41 31 473 minecraft:bookshelf
fill 41 30 476 41 30 480 minecraft:bookshelf
fill 41 30 483 41 30 487 minecraft:bookshelf
fill 41 30 490 41 30 494 minecraft:bookshelf
fill 41 30 497 41 30 501 minecraft:bookshelf
setblock 1 31 465 minecraft:bookshelf
setblock 1 31 472 minecraft:bookshelf
setblock 1 31 479 minecraft:bookshelf
setblock 1 31 486 minecraft:bookshelf
setblock 1 31 493 minecraft:bookshelf
setblock 1 31 500 minecraft:bookshelf
setblock 4 31 504 minecraft:bookshelf
setblock 7 31 464 minecraft:bookshelf
setblock 11 31 504 minecraft:bookshelf
setblock 14 31 464 minecraft:bookshelf
setblock 18 31 504 minecraft:bookshelf
setblock 21 31 464 minecraft:bookshelf
setblock 25 31 504 minecraft:bookshelf
setblock 28 31 464 minecraft:bookshelf
setblock 32 31 504 minecraft:bookshelf
setblock 35 31 464 minecraft:bookshelf
fill 39 31 471 40 31 476 minecraft:bookshelf
setblock 39 31 504 minecraft:bookshelf
fill 40 31 470 41 31 470 minecraft:bookshelf
setblock 41 31 465 minecraft:bookshelf
setblock 41 31 469 minecraft:bookshelf
fill 41 31 471 41 31 472 minecraft:bookshelf
fill 41 31 479 41 33 479 minecraft:bookshelf
setblock 41 31 486 minecraft:bookshelf
setblock 41 31 493 minecraft:bookshelf
setblock 41 31 500 minecraft:bookshelf
setblock 1 32 466 minecraft:bookshelf
setblock 1 32 473 minecraft:bookshelf
setblock 1 32 480 minecraft:bookshelf
setblock 1 32 487 minecraft:bookshelf
setblock 1 32 494 minecraft:bookshelf
setblock 1 32 501 minecraft:bookshelf
setblock 5 32 504 minecraft:bookshelf
setblock 6 32 464 minecraft:bookshelf
setblock 12 32 504 minecraft:bookshelf
setblock 13 32 464 minecraft:bookshelf
setblock 19 32 504 minecraft:bookshelf
setblock 20 32 464 minecraft:bookshelf
setblock 26 32 504 minecraft:bookshelf
setblock 27 32 464 minecraft:bookshelf
setblock 33 32 504 minecraft:bookshelf
setblock 34 32 464 minecraft:bookshelf
fill 39 32 475 40 32 479 minecraft:bookshelf
setblock 40 32 474 minecraft:bookshelf
setblock 40 32 504 minecraft:bookshelf
setblock 41 32 464 minecraft:bookshelf
setblock 41 32 471 minecraft:bookshelf
fill 41 32 476 41 32 478 minecraft:bookshelf
setblock 41 32 485 minecraft:bookshelf
setblock 41 32 492 minecraft:bookshelf
setblock 41 32 499 minecraft:bookshelf
setblock 1 33 467 minecraft:bookshelf
setblock 1 33 474 minecraft:bookshelf
setblock 1 33 481 minecraft:bookshelf
setblock 1 33 488 minecraft:bookshelf
setblock 1 33 495 minecraft:bookshelf
fill 1 33 499 3 34 499 minecraft:gold_block
setblock 1 33 502 minecraft:bookshelf
setblock 5 33 464 minecraft:bookshelf
setblock 6 33 504 minecraft:bookshelf
setblock 12 33 464 minecraft:bookshelf
setblock 13 33 504 minecraft:bookshelf
setblock 19 33 464 minecraft:bookshelf
setblock 20 33 504 minecraft:bookshelf
setblock 26 33 464 minecraft:bookshelf
setblock 27 33 504 minecraft:bookshelf
setblock 33 33 464 minecraft:bookshelf
setblock 34 33 504 minecraft:bookshelf
fill 39 33 478 40 33 482 minecraft:bookshelf
setblock 40 33 464 minecraft:bookshelf
setblock 41 33 470 minecraft:bookshelf
fill 41 33 477 41 33 478 minecraft:bookshelf
fill 41 33 480 41 33 481 minecraft:bookshelf
fill 41 33 484 41 35 484 minecraft:bookshelf
setblock 41 33 491 minecraft:bookshelf
setblock 41 33 498 minecraft:bookshelf
setblock 41 33 504 minecraft:bookshelf
setblock 1 34 468 minecraft:bookshelf
setblock 1 34 475 minecraft:bookshelf
setblock 1 34 482 minecraft:bookshelf
setblock 1 34 489 minecraft:bookshelf
setblock 1 34 496 minecraft:bookshelf
setblock 1 34 503 minecraft:bookshelf
setblock 4 34 464 minecraft:bookshelf
setblock 7 34 504 minecraft:bookshelf
setblock 11 34 464 minecraft:bookshelf
setblock 14 34 504 minecraft:bookshelf
setblock 18 34 464 minecraft:bookshelf
setblock 21 34 504 minecraft:bookshelf
setblock 25 34 464 minecraft:bookshelf
setblock 28 34 504 minecraft:bookshelf
setblock 32 34 464 minecraft:bookshelf
setblock 35 34 504 minecraft:bookshelf
setblock 39 34 464 minecraft:bookshelf
fill 39 34 481 40 34 485 minecraft:bookshelf
setblock 41 34 469 minecraft:bookshelf
setblock 41 34 476 minecraft:bookshelf
setblock 41 34 481 minecraft:bookshelf
setblock 41 34 483 minecraft:bookshelf
fill 41 34 485 41 35 485 minecraft:bookshelf
setblock 41 34 490 minecraft:bookshelf
setblock 41 34 497 minecraft:bookshelf
fill 39 35 484 40 35 488 minecraft:bookshelf
fill 41 35 486 41 35 488 minecraft:bookshelf
setblock 1 36 470 minecraft:bookshelf
setblock 1 36 477 minecraft:bookshelf
setblock 1 36 484 minecraft:bookshelf
setblock 1 36 491 minecraft:bookshelf
setblock 1 36 498 minecraft:bookshelf
setblock 2 36 464 minecraft:bookshelf
setblock 2 36 504 minecraft:bookshelf
setblock 9 36 464 minecraft:bookshelf
setblock 9 36 504 minecraft:bookshelf
setblock 16 36 464 minecraft:bookshelf
setblock 16 36 504 minecraft:bookshelf
setblock 23 36 464 minecraft:bookshelf
setblock 23 36 504 minecraft:bookshelf
setblock 30 36 464 minecraft:bookshelf
setblock 30 36 504 minecraft:bookshelf
setblock 37 36 464 minecraft:bookshelf
setblock 37 36 504 minecraft:bookshelf
fill 39 36 487 40 36 491 minecraft:bookshelf
setblock 41 36 467 minecraft:bookshelf
setblock 41 36 474 minecraft:bookshelf
setblock 41 36 481 minecraft:bookshelf
fill 41 36 487 41 36 488 minecraft:bookshelf
fill 41 36 490 41 36 492 minecraft:bookshelf
fill 41 36 495 41 38 495 minecraft:bookshelf
setblock 41 36 502 minecraft:bookshelf
setblock 1 37 464 minecraft:bookshelf
setblock 1 37 471 minecraft:bookshelf
setblock 1 37 478 minecraft:bookshelf
setblock 1 37 485 minecraft:bookshelf
setblock 1 37 492 minecraft:bookshelf
setblock 1 37 499 minecraft:bookshelf
setblock 3 37 504 minecraft:bookshelf
setblock 8 37 464 minecraft:bookshelf
setblock 10 37 504 minecraft:bookshelf
setblock 15 37 464 minecraft:bookshelf
setblock 17 37 504 minecraft:bookshelf
setblock 22 37 464 minecraft:bookshelf
setblock 24 37 504 minecraft:bookshelf
setblock 29 37 464 minecraft:bookshelf
setblock 31 37 504 minecraft:bookshelf
setblock 36 37 464 minecraft:bookshelf
setblock 38 37 504 minecraft:bookshelf
fill 39 37 490 40 37 495 minecraft:bookshelf
setblock 41 37 466 minecraft:bookshelf
setblock 41 37 473 minecraft:bookshelf
setblock 41 37 480 minecraft:bookshelf
setblock 41 37 487 minecraft:bookshelf
fill 41 37 491 41 37 494 minecraft:bookshelf
fill 41 37 501 41 40 501 minecraft:bookshelf
setblock 1 38 465 minecraft:bookshelf
setblock 1 38 472 minecraft:bookshelf
setblock 1 38 479 minecraft:bookshelf
setblock 1 38 486 minecraft:bookshelf
setblock 1 38 493 minecraft:bookshelf
setblock 1 38 500 minecraft:bookshelf
setblock 3 38 466 minecraft:light[level=12]
setblock 3 38 474 minecraft:light[level=12]
setblock 3 38 482 minecraft:light[level=12]
setblock 3 38 490 minecraft:light[level=12]
setblock 3 38 498 minecraft:light[level=12]
setblock 4 38 504 minecraft:bookshelf
setblock 7 38 464 minecraft:bookshelf
setblock 11 38 466 minecraft:light[level=12]
setblock 11 38 474 minecraft:light[level=12]
setblock 11 38 482 minecraft:light[level=12]
setblock 11 38 490 minecraft:light[level=12]
setblock 11 38 498 minecraft:light[level=12]
setblock 11 38 504 minecraft:bookshelf
setblock 14 38 464 minecraft:bookshelf
setblock 18 38 504 minecraft:bookshelf
setblock 19 38 466 minecraft:light[level=12]
setblock 19 38 474 minecraft:light[level=12]
setblock 19 38 482 minecraft:light[level=12]
setblock 19 38 490 minecraft:light[level=12]
setblock 19 38 498 minecraft:light[level=12]
setblock 21 38 464 minecraft:bookshelf
setblock 25 38 504 minecraft:bookshelf
setblock 27 38 466 minecraft:light[level=12]
setblock 27 38 474 minecraft:light[level=12]
setblock 27 38 482 minecraft:light[level=12]
setblock 27 38 490 minecraft:light[level=12]
setblock 27 38 498 minecraft:light[level=12]
setblock 28 38 464 minecraft:bookshelf
setblock 32 38 504 minecraft:bookshelf
setblock 35 38 464 minecraft:bookshelf
setblock 35 38 466 minecraft:light[level=12]
setblock 35 38 474 minecraft:light[level=12]
setblock 35 38 482 minecraft:light[level=12]
setblock 35 38 490 minecraft:light[level=12]
setblock 35 38 498 minecraft:light[level=12]
fill 39 38 493 39 38 499 minecraft:bookshelf
fill 39 38 504 39 40 504 minecraft:bookshelf
fill 40 38 494 40 38 500 minecraft:bookshelf
setblock 41 38 465 minecraft:bookshelf
setblock 41 38 472 minecraft:bookshelf
setblock 41 38 479 minecraft:bookshelf
setblock 41 38 486 minecraft:bookshelf
fill 41 38 493 41 38 494 minecraft:bookshelf
fill 41 38 497 41 38 500 minecraft:bookshelf
fill 1 39 466 1 40 466 minecraft:bookshelf
fill 1 39 473 1 40 473 minecraft:bookshelf
fill 1 39 480 1 40 480 minecraft:bookshelf
fill 1 39 487 1 40 487 minecraft:bookshelf
fill 1 39 494 1 40 494 minecraft:bookshelf
fill 1 39 501 1 40 501 minecraft:bookshelf
fill 5 39 504 5 40 504 minecraft:bookshelf
fill 6 39 464 6 40 464 minecraft:bookshelf
fill 12 39 504 12 40 504 minecraft:bookshelf
fill 13 39 464 13 40 464 minecraft:bookshelf
fill 19 39 504 19 40 504 minecraft:bookshelf
fill 20 39 464 20 40 464 minecraft:bookshelf
fill 26 39 504 26 40 504 minecraft:bookshelf
fill 27 39 464 27 40 464 minecraft:bookshelf
fill 33 39 504 33 41 504 minecraft:bookshelf
fill 34 39 464 34 40 464 minecraft:bookshelf
fill 37 39 502 41 39 502 minecraft:bookshelf
fill 38 39 503 40 40 503 minecraft:bookshelf
fill 39 39 497 39 39 501 minecraft:bookshelf
fill 40 39 498 40 39 501 minecraft:bookshelf
fill 40 39 504 41 40 504 minecraft:bookshelf
fill 41 39 464 41 40 464 minecraft:bookshelf
fill 41 39 471 41 40 471 minecraft:bookshelf
fill 41 39 478 41 40 478 minecraft:bookshelf
fill 41 39 485 41 40 485 minecraft:bookshelf
fill 41 39 492 41 40 492 minecraft:bookshelf
fill 41 39 499 41 40 500 minecraft:bookshelf
fill 1 40 464 1 40 465 minecraft:bookshelf
fill 1 40 467 1 40 468 minecraft:bookshelf
fill 1 40 470 1 40 472 minecraft:bookshelf
fill 1 40 474 1 40 475 minecraft:bookshelf
fill 1 40 477 1 40 479 minecraft:bookshelf
fill 1 40 481 1 40 482 minecraft:bookshelf
fill 1 40 484 1 40 486 minecraft:bookshelf
fill 1 40 488 1 40 489 minecraft:bookshelf
fill 1 40 491 1 40 493 minecraft:bookshelf
fill 1 40 495 1 40 496 minecraft:bookshelf
fill 1 40 498 1 40 500 minecraft:bookshelf
fill 1 40 502 1 40 503 minecraft:bookshelf
setblock 2 40 464 minecraft:bookshelf
fill 2 40 504 4 40 504 minecraft:bookshelf
fill 4 40 464 5 40 464 minecraft:bookshelf
fill 6 40 504 7 40 504 minecraft:bookshelf
fill 7 40 464 9 40 464 minecraft:bookshelf
fill 9 40 504 11 40 504 minecraft:bookshelf
fill 10 40 478 11 41 479 minecraft:red_wool
fill 11 40 464 12 40 464 minecraft:bookshelf
fill 13 40 504 14 40 504 minecraft:bookshelf
fill 14 40 464 16 40 464 minecraft:bookshelf
fill 16 40 504 18 40 504 minecraft:bookshelf
fill 18 40 464 19 40 464 minecraft:bookshelf
fill 20 40 504 21 40 504 minecraft:bookshelf
fill 21 40 464 23 40 464 minecraft:bookshelf
fill 23 40 504 25 40 504 minecraft:bookshelf
fill 25 40 464 26 40 464 minecraft:bookshelf
fill 27 40 504 28 40 504 minecraft:bookshelf
fill 28 40 464 30 40 464 minecraft:bookshelf
fill 30 40 504 32 41 504 minecraft:bookshelf
fill 32 40 464 33 40 464 minecraft:bookshelf
fill 33 40 502 37 40 503 minecraft:bookshelf
fill 34 40 504 35 41 504 minecraft:bookshelf
fill 35 40 464 37 40 464 minecraft:bookshelf
fill 37 40 504 38 40 504 minecraft:bookshelf
fill 38 40 502 39 40 502 minecraft:bookshelf
fill 39 40 464 40 40 464 minecraft:bookshelf
fill 41 40 465 41 40 467 minecraft:bookshelf
fill 41 40 469 41 40 470 minecraft:bookshelf
fill 41 40 472 41 40 474 minecraft:bookshelf
fill 41 40 476 41 40 477 minecraft:bookshelf
fill 41 40 479 41 40 481 minecraft:bookshelf
fill 41 40 483 41 40 484 minecraft:bookshelf
fill 41 40 486 41 40 488 minecraft:bookshelf
fill 41 40 490 41 40 491 minecraft:bookshelf
fill 41 40 493 41 40 495 minecraft:bookshelf
fill 41 40 497 41 40 498 minecraft:bookshelf
setblock 41 40 502 minecraft:bookshelf
setblock 1 41 468 minecraft:bookshelf
setblock 1 41 475 minecraft:bookshelf
setblock 1 41 482 minecraft:bookshelf
setblock 1 41 489 minecraft:bookshelf
setblock 1 41 496 minecraft:bookshelf
setblock 1 41 503 minecraft:bookshelf
setblock 4 41 464 minecraft:bookshelf
setblock 7 41 504 minecraft:bookshelf
setblock 11 41 464 minecraft:bookshelf
setblock 14 41 504 minecraft:bookshelf
setblock 18 41 464 minecraft:bookshelf
setblock 21 41 504 minecraft:bookshelf
setblock 25 41 464 minecraft:bookshelf
fill 28 41 504 28 42 504 minecraft:bookshelf
fill 29 41 502 34 41 503 minecraft:bookshelf
setblock 32 41 464 minecraft:bookshelf
setblock 35 41 503 minecraft:bookshelf
setblock 39 41 464 minecraft:bookshelf
setblock 41 41 469 minecraft:bookshelf
setblock 41 41 476 minecraft:bookshelf
setblock 41 41 483 minecraft:bookshelf
setblock 41 41 490 minecraft:bookshelf
setblock 41 41 497 minecraft:bookshelf
fill 26 42 502 27 43 504 minecraft:bookshelf
fill 28 42 502 30 42 503 minecraft:bookshelf
fill 30 42 504 31 42 504 minecraft:bookshelf
setblock 31 42 503 minecraft:bookshelf
setblock 1 43 470 minecraft:bookshelf
setblock 1 43 477 minecraft:bookshelf
setblock 1 43 484 minecraft:bookshelf
setblock 1 43 491 minecraft:bookshelf
setblock 1 43 498 minecraft:bookshelf
setblock 2 43 464 minecraft:bookshelf
setblock 2 43 504 minecraft:bookshelf
setblock 9 43 464 minecraft:bookshelf
setblock 9 43 504 minecraft:bookshelf
setblock 16 43 464 minecraft:bookshelf
setblock 16 43 504 minecraft:bookshelf
setblock 23 43 464 minecraft:bookshelf
fill 23 43 502 25 43 504 minecraft:bookshelf
setblock 30 43 464 minecraft:bookshelf
setblock 30 43 504 minecraft:bookshelf
setblock 37 43 464 minecraft:bookshelf
setblock 37 43 504 minecraft:bookshelf
setblock 41 43 467 minecraft:bookshelf
setblock 41 43 474 minecraft:bookshelf
setblock 41 43 481 minecraft:bookshelf
setblock 41 43 488 minecraft:bookshelf
setblock 41 43 495 minecraft:bookshelf
setblock 41 43 502 minecraft:bookshelf
setblock 1 44 464 minecraft:bookshelf
setblock 1 44 471 minecraft:bookshelf
setblock 1 44 478 minecraft:bookshelf
setblock 1 44 485 minecraft:bookshelf
setblock 1 44 492 minecraft:bookshelf
setblock 1 44 499 minecraft:bookshelf
setblock 3 44 504 minecraft:bookshelf
setblock 8 44 464 minecraft:bookshelf
setblock 10 44 504 minecraft:bookshelf
setblock 15 44 464 minecraft:bookshelf
fill 17 44 504 17 46 504 minecraft:bookshelf
fill 20 44 502 21 45 504 minecraft:bookshelf
setblock 22 44 464 minecraft:bookshelf
fill 22 44 502 24 44 503 minecraft:bookshelf
fill 23 44 504 24 44 504 minecraft:bookshelf
setblock 29 44 464 minecraft:bookshelf
setblock 31 44 504 minecraft:bookshelf
setblock 36 44 464 minecraft:bookshelf
setblock 38 44 504 minecraft:bookshelf
setblock 41 44 466 minecraft:bookshelf
setblock 41 44 473 minecraft:bookshelf
setblock 41 44 480 minecraft:bookshelf
setblock 41 44 487 minecraft:bookshelf
setblock 41 44 494 minecraft:bookshelf
setblock 41 44 501 minecraft:bookshelf
setblock 1 45 465 minecraft:bookshelf
setblock 1 45 472 minecraft:bookshelf
setblock 1 45 479 minecraft:bookshelf
setblock 1 45 486 minecraft:bookshelf
setblock 1 45 493 minecraft:bookshelf
setblock 1 45 500 minecraft:bookshelf
setblock 4 45 504 minecraft:bookshelf
setblock 7 45 464 minecraft:bookshelf
setblock 11 45 504 minecraft:bookshelf
setblock 14 45 464 minecraft:bookshelf
fill 17 45 502 19 45 503 minecraft:bookshelf
fill 18 45 504 19 46 504 minecraft:bookshelf
setblock 21 45 464 minecraft:bookshelf
setblock 25 45 504 minecraft:bookshelf
setblock 28 45 464 minecraft:bookshelf
setblock 32 45 504 minecraft:bookshelf
setblock 35 45 464 minecraft:bookshelf
setblock 39 45 504 minecraft:bookshelf
setblock 41 45 465 minecraft:bookshelf
setblock 41 45 472 minecraft:bookshelf
setblock 41 45 479 minecraft:bookshelf
setblock 41 45 486 minecraft:bookshelf
setblock 41 45 493 minecraft:bookshelf
setblock 41 45 500 minecraft:bookshelf
setblock 1 46 466 minecraft:bookshelf
setblock 1 46 473 minecraft:bookshelf
setblock 1 46 480 minecraft:bookshelf
setblock 1 46 487 minecraft:bookshelf
setblock 1 46 494 minecraft:bookshelf
setblock 1 46 501 minecraft:bookshelf
setblock 3 46 466 minecraft:light[level=12]
setblock 3 46 474 minecraft:light[level=12]
setblock 3 46 482 minecraft:light[level=12]
setblock 3 46 490 minecraft:light[level=12]
setblock 3 46 498 minecraft:light[level=12]
setblock 5 46 504 minecraft:bookshelf
setblock 6 46 464 minecraft:bookshelf
setblock 11 46 466 minecraft:light[level=12]
setblock 11 46 474 minecraft:light[level=12]
setblock 11 46 482 minecraft:light[level=12]
setblock 11 46 490 minecraft:light[level=12]
setblock 11 46 498 minecraft:light[level=12]
fill 12 46 504 14 47 504 minecraft:bookshelf
setblock 13 46 464 minecraft:bookshelf
fill 14 46 502 18 46 503 minecraft:bookshelf
setblock 16 46 504 minecraft:bookshelf
setblock 19 46 466 minecraft:light[level=12]
setblock 19 46 474 minecraft:light[level=12]
setblock 19 46 482 minecraft:light[level=12]
setblock 19 46 490 minecraft:light[level=12]
setblock 19 46 498 minecraft:light[level=12]
setblock 20 46 464 minecraft:bookshelf
setblock 26 46 504 minecraft:bookshelf
setblock 27 46 464 minecraft:bookshelf
setblock 27 46 466 minecraft:light[level=12]
setblock 27 46 474 minecraft:light[level=12]
setblock 27 46 482 minecraft:light[level=12]
setblock 27 46 490 minecraft:light[level=12]
setblock 27 46 498 minecraft:light[level=12]
setblock 33 46 504 minecraft:bookshelf
setblock 34 46 464 minecraft:bookshelf
setblock 35 46 466 minecraft:light[level=12]
setblock 35 46 474 minecraft:light[level=12]
setblock 35 46 482 minecraft:light[level=12]
setblock 35 46 490 minecraft:light[level=12]
setblock 35 46 498 minecraft:light[level=12]
setblock 40 46 504 minecraft:bookshelf
setblock 41 46 464 minecraft:bookshelf
setblock 41 46 471 minecraft:bookshelf
setblock 41 46 478 minecraft:bookshelf
setblock 41 46 485 minecraft:bookshelf
setblock 41 46 492 minecraft:bookshelf
setblock 41 46 499 minecraft:bookshelf
setblock 1 47 467 minecraft:bookshelf
fill 1 47 472 3 48 472 minecraft:gold_block
setblock 1 47 474 minecraft:bookshelf
setblock 1 47 481 minecraft:bookshelf
setblock 1 47 488 minecraft:bookshelf
setblock 1 47 495 minecraft:bookshelf
setblock 1 47 502 minecraft:bookshelf
setblock 5 47 464 minecraft:bookshelf
fill 6 47 504 6 50 504 minecraft:bookshelf
fill 9 47 504 11 48 504 minecraft:bookshelf
fill 10 47 502 15 47 503 minecraft:bookshelf
setblock 12 47 464 minecraft:bookshelf
setblock 19 47 464 minecraft:bookshelf
setblock 20 47 504 minecraft:bookshelf
setblock 26 47 464 minecraft:bookshelf
setblock 27 47 504 minecraft:bookshelf
setblock 33 47 464 minecraft:bookshelf
setblock 34 47 504 minecraft:bookshelf
setblock 40 47 464 minecraft:bookshelf
setblock 41 47 470 minecraft:bookshelf
setblock 41 47 477 minecraft:bookshelf
setblock 41 47 484 minecraft:bookshelf
setblock 41 47 491 minecraft:bookshelf
setblock 41 47 498 minecraft:bookshelf
setblock 41 47 504 minecraft:bookshelf
setblock 1 48 468 minecraft:bookshelf
setblock 1 48 475 minecraft:bookshelf
setblock 1 48 482 minecraft:bookshelf
setblock 1 48 489 minecraft:bookshelf
setblock 1 48 496 minecraft:bookshelf
fill 1 48 503 1 50 503 minecraft:bookshelf
setblock 4 48 464 minecraft:bookshelf
fill 4 48 504 5 50 504 minecraft:bookshelf
fill 5 48 503 11 48 503 minecraft:bookshelf
fill 6 48 502 12 48 502 minecraft:bookshelf
setblock 7 48 504 minecraft:bookshelf
setblock 11 48 464 minecraft:bookshelf
setblock 14 48 504 minecraft:bookshelf
setblock 18 48 464 minecraft:bookshelf
setblock 21 48 504 minecraft:bookshelf
setblock 25 48 464 minecraft:bookshelf
setblock 28 48 504 minecraft:bookshelf
setblock 32 48 464 minecraft:bookshelf
setblock 35 48 504 minecraft:bookshelf
setblock 39 48 464 minecraft:bookshelf
setblock 41 48 469 minecraft:bookshelf
setblock 41 48 476 minecraft:bookshelf
setblock 41 48 483 minecraft:bookshelf
setblock 41 48 490 minecraft:bookshelf
setblock 41 48 497 minecraft:bookshelf
fill 1 49 502 8 49 502 minecraft:bookshelf
fill 2 49 501 3 50 501 minecraft:bookshelf
fill 2 49 503 3 49 504 minecraft:bookshelf
fill 3 49 500 3 50 500 minecraft:bookshelf
fill 4 49 503 7 49 503 minecraft:bookshelf
fill 12 49 489 12 50 490 minecraft:white_wool
fill 24 49 497 28 50 501 minecraft:dark_oak_planks
fill 26 49 502 26 49 503 minecraft:dark_oak_planks
fill 1 50 464 1 50 468 minecraft:bookshelf
fill 1 50 470 1 50 475 minecraft:bookshelf
fill 1 50 477 1 50 482 minecraft:bookshelf
fill 1 50 484 1 50 489 minecraft:bookshelf
fill 1 50 491 1 50 496 minecraft:bookshelf
fill 1 50 498 1 50 502 minecraft:bookshelf
setblock 2 50 464 minecraft:bookshelf
fill 2 50 496 2 50 500 minecraft:bookshelf
fill 2 50 502 2 50 504 minecraft:bookshelf
fill 3 50 496 3 50 499 minecraft:bookshelf
setblock 3 50 502 minecraft:bookshelf
fill 3 50 504 3 51 504 minecraft:bookshelf
fill 4 50 464 9 50 464 minecraft:bookshelf
setblock 7 50 504 minecraft:bookshelf
fill 9 50 504 14 50 504 minecraft:bookshelf
fill 11 50 464 16 50 464 minecraft:bookshelf
fill 16 50 504 21 50 504 minecraft:bookshelf
fill 18 50 464 23 50 464 minecraft:bookshelf
fill 23 50 504 28 50 504 minecraft:bookshelf
fill 25 50 464 30 50 464 minecraft:bookshelf
fill 30 50 504 35 50 504 minecraft:bookshelf
fill 32 50 464 37 50 464 minecraft:bookshelf
fill 37 50 504 41 50 504 minecraft:bookshelf
fill 39 50 464 41 50 464 minecraft:bookshelf
fill 41 50 465 41 50 467 minecraft:bookshelf
fill 41 50 469 41 50 474 minecraft:bookshelf
fill 41 50 476 41 50 481 minecraft:bookshelf
fill 41 50 483 41 50 488 minecraft:bookshelf
fill 41 50 490 41 50 495 minecraft:bookshelf
fill 41 50 497 41 50 502 minecraft:bookshelf
setblock 1 51 464 minecraft:bookshelf
setblock 1 51 471 minecraft:bookshelf
setblock 1 51 478 minecraft:bookshelf
setblock 1 51 485 minecraft:bookshelf
fill 1 51 492 3 51 496 minecraft:bookshelf
fill 1 51 498 1 51 499 minecraft:bookshelf
fill 2 51 497 2 51 498 minecraft:bookshelf
setblock 3 51 497 minecraft:bookshelf
setblock 8 51 464 minecraft:bookshelf
setblock 10 51 504 minecraft:bookshelf
setblock 15 51 464 minecraft:bookshelf
setblock 17 51 504 minecraft:bookshelf
setblock 22 51 464 minecraft:bookshelf
setblock 24 51 504 minecraft:bookshelf
fill 25 51 499 27 56 499 minecraft:purple_concrete
fill 26 51 498 26 56 498 minecraft:purple_concrete
fill 26 51 500 26 56 500 minecraft:purple_concrete
setblock 29 51 464 minecraft:bookshelf
setblock 31 51 504 minecraft:bookshelf
setblock 36 51 464 minecraft:bookshelf
setblock 38 51 504 minecraft:bookshelf
setblock 41 51 466 minecraft:bookshelf
setblock 41 51 473 minecraft:bookshelf
setblock 41 51 480 minecraft:bookshelf
setblock 41 51 487 minecraft:bookshelf
setblock 41 51 494 minecraft:bookshelf
setblock 41 51 501 minecraft:bookshelf
setblock 1 52 465 minecraft:bookshelf
setblock 1 52 472 minecraft:bookshelf
setblock 1 52 479 minecraft:bookshelf
fill 1 52 486 1 54 486 minecraft:bookshelf
fill 1 52 489 3 53 489 minecraft:bookshelf
fill 1 52 491 2 52 494 minecraft:bookshelf
setblock 1 52 500 minecraft:bookshelf
fill 2 52 490 3 53 490 minecraft:bookshelf
fill 3 52 491 3 52 493 minecraft:bookshelf
setblock 4 52 504 minecraft:bookshelf
setblock 7 52 464 minecraft:bookshelf
setblock 11 52 504 minecraft:bookshelf
setblock 14 52 464 minecraft:bookshelf
setblock 18 52 504 minecraft:bookshelf
setblock 21 52 464 minecraft:bookshelf
setblock 25 52 504 minecraft:bookshelf
setblock 28 52 464 minecraft:bookshelf
setblock 32 52 504 minecraft:bookshelf
setblock 35 52 464 minecraft:bookshelf
setblock 39 52 504 minecraft:bookshelf
setblock 41 52 465 minecraft:bookshelf
setblock 41 52 472 minecraft:bookshelf
setblock 41 52 479 minecraft:bookshelf
setblock 41 52 486 minecraft:bookshelf
setblock 41 52 493 minecraft:bookshelf
setblock 41 52 500 minecraft:bookshelf
setblock 1 53 466 minecraft:bookshelf
setblock 1 53 473 minecraft:bookshelf
setblock 1 53 480 minecraft:bookshelf
fill 1 53 487 3 53 488 minecraft:bookshelf
setblock 1 53 494 minecraft:bookshelf
setblock 1 53 501 minecraft:bookshelf
fill 2 53 486 3 54 486 minecraft:bookshelf
setblock 5 53 504 minecraft:bookshelf
setblock 6 53 464 minecraft:bookshelf
setblock 12 53 504 minecraft:bookshelf
setblock 13 53 464 minecraft:bookshelf
setblock 19 53 504 minecraft:bookshelf
setblock 20 53 464 minecraft:bookshelf
setblock 26 53 504 minecraft:bookshelf
setblock 27 53 464 minecraft:bookshelf
setblock 33 53 504 minecraft:bookshelf
setblock 34 53 464 minecraft:bookshelf
setblock 40 53 504 minecraft:bookshelf
setblock 41 53 464 minecraft:bookshelf
setblock 41 53 471 minecraft:bookshelf
setblock 41 53 478 minecraft:bookshelf
setblock 41 53 485 minecraft:bookshelf
setblock 41 53 492 minecraft:bookshelf
setblock 41 53 499 minecraft:bookshelf
setblock 1 54 467 minecraft:bookshelf
setblock 1 54 474 minecraft:bookshelf
fill 1 54 481 1 56 481 minecraft:bookshelf
fill 1 54 484 3 54 485 minecraft:bookshelf
fill 1 54 487 1 54 488 minecraft:bookshelf
setblock 1 54 495 minecraft:bookshelf
setblock 1 54 502 minecraft:bookshelf
fill 2 54 483 3 55 483 minecraft:bookshelf
fill 2 54 487 3 54 487 minecraft:bookshelf
setblock 3 54 466 minecraft:light[level=12]
setblock 3 54 474 minecraft:light[level=12]
setblock 3 54 482 minecraft:light[level=12]
setblock 3 54 490 minecraft:light[level=12]
setblock 3 54 498 minecraft:light[level=12]
setblock 5 54 464 minecraft:bookshelf
setblock 6 54 504 minecraft:bookshelf
setblock 11 54 466 minecraft:light[level=12]
setblock 11 54 474 minecraft:light[level=12]
setblock 11 54 482 minecraft:light[level=12]
setblock 11 54 490 minecraft:light[level=12]
setblock 11 54 498 minecraft:light[level=12]
setblock 12 54 464 minecraft:bookshelf
setblock 13 54 504 minecraft:bookshelf
setblock 19 54 464 minecraft:bookshelf
setblock 19 54 466 minecraft:light[level=12]
setblock 19 54 474 minecraft:light[level=12]
setblock 19 54 482 minecraft:light[level=12]
setblock 19 54 490 minecraft:light[level=12]
setblock 19 54 498 minecraft:light[level=12]
setblock 20 54 504 minecraft:bookshelf
setblock 26 54 464 minecraft:bookshelf
setblock 27 54 466 minecraft:light[level=12]
setblock 27 54 474 minecraft:light[level=12]
setblock 27 54 482 minecraft:light[level=12]
setblock 27 54 490 minecraft:light[level=12]
setblock 27 54 498 minecraft:light[level=12]
setblock 27 54 504 minecraft:bookshelf
setblock 33 54 464 minecraft:bookshelf
setblock 34 54 504 minecraft:bookshelf
setblock 35 54 466 minecraft:light[level=12]
setblock 35 54 474 minecraft:light[level=12]
setblock 35 54 482 minecraft:light[level=12]
setblock 35 54 490 minecraft:light[level=12]
setblock 35 54 498 minecraft:light[level=12]
setblock 40 54 464 minecraft:bookshelf
setblock 41 54 470 minecraft:bookshelf
setblock 41 54 477 minecraft:bookshelf
setblock 41 54 484 minecraft:bookshelf
setblock 41 54 491 minecraft:bookshelf
setblock 41 54 498 minecraft:bookshelf
setblock 41 54 504 minecraft:bookshelf
setblock 1 55 468 minecraft:bookshelf
setblock 1 55 475 minecraft:bookshelf
fill 1 55 480 3 56 480 minecraft:bookshelf
fill 1 55 482 3 55 482 minecraft:bookshelf
fill 1 55 484 3 55 484 minecraft:bookshelf
setblock 1 55 489 minecraft:bookshelf
setblock 1 55 496 minecraft:bookshelf
setblock 1 55 503 minecraft:bookshelf
fill 2 55 481 3 56 481 minecraft:bookshelf
setblock 4 55 464 minecraft:bookshelf
setblock 7 55 504 minecraft:bookshelf
setblock 11 55 464 minecraft:bookshelf
setblock 14 55 504 minecraft:bookshelf
setblock 18 55 464 minecraft:bookshelf
setblock 21 55 504 minecraft:bookshelf
setblock 25 55 464 minecraft:bookshelf
setblock 28 55 504 minecraft:bookshelf
setblock 32 55 464 minecraft:bookshelf
setblock 35 55 504 minecraft:bookshelf
setblock 39 55 464 minecraft:bookshelf
setblock 41 55 469 minecraft:bookshelf
setblock 41 55 476 minecraft:bookshelf
setblock 41 55 483 minecraft:bookshelf
setblock 41 55 490 minecraft:bookshelf
setblock 41 55 497 minecraft:bookshelf
fill 1 56 477 3 56 479 minecraft:bookshelf
fill 1 57 470 1 58 470 minecraft:bookshelf
fill 1 57 472 1 57 475 minecraft:bookshelf
fill 1 57 477 3 57 477 minecraft:bookshelf
setblock 1 57 484 minecraft:bookshelf
setblock 1 57 491 minecraft:bookshelf
setblock 1 57 498 minecraft:bookshelf
setblock 2 57 464 minecraft:bookshelf
fill 2 57 473 3 57 476 minecraft:bookshelf
fill 2 57 478 3 57 478 minecraft:bookshelf
setblock 2 57 504 minecraft:bookshelf
setblock 9 57 464 minecraft:bookshelf
setblock 9 57 504 minecraft:bookshelf
setblock 16 57 464 minecraft:bookshelf
setblock 16 57 504 minecraft:bookshelf
setblock 23 57 464 minecraft:bookshelf
setblock 23 57 504 minecraft:bookshelf
setblock 30 57 464 minecraft:bookshelf
setblock 30 57 504 minecraft:bookshelf
setblock 37 57 464 minecraft:bookshelf
setblock 37 57 504 minecraft:bookshelf
setblock 41 57 467 minecraft:bookshelf
setblock 41 57 474 minecraft:bookshelf
setblock 41 57 481 minecraft:bookshelf
setblock 41 57 488 minecraft:bookshelf
setblock 41 57 495 minecraft:bookshelf
setblock 41 57 502 minecraft:bookshelf
fill 1 58 464 1 60 464 minecraft:bookshelf
fill 1 58 467 1 60 468 minecraft:bookshelf
fill 1 58 471 3 58 474 minecraft:bookshelf
setblock 1 58 478 minecraft:bookshelf
setblock 1 58 485 minecraft:bookshelf
setblock 1 58 492 minecraft:bookshelf
setblock 1 58 499 minecraft:bookshelf
fill 2 58 468 2 59 470 minecraft:bookshelf
fill 3 58 469 3 59 470 minecraft:bookshelf
setblock 3 58 475 minecraft:bookshelf
setblock 3 58 504 minecraft:bookshelf
setblock 8 58 464 minecraft:bookshelf
setblock 10 58 504 minecraft:bookshelf
setblock 15 58 464 minecraft:bookshelf
setblock 17 58 504 minecraft:bookshelf
setblock 22 58 464 minecraft:bookshelf
setblock 24 58 504 minecraft:bookshelf
setblock 29 58 464 minecraft:bookshelf
setblock 31 58 504 minecraft:bookshelf
setblock 36 58 464 minecraft:bookshelf
setblock 38 58 504 minecraft:bookshelf
setblock 41 58 466 minecraft:bookshelf
setblock 41 58 473 minecraft:bookshelf
setblock 41 58 480 minecraft:bookshelf
setblock 41 58 487 minecraft:bookshelf
setblock 41 58 494 minecraft:bookshelf
setblock 41 58 501 minecraft:bookshelf
fill 1 59 465 4 59 466 minecraft:bookshelf
fill 1 59 472 1 60 472 minecraft:bookshelf
fill 1 59 479 1 60 479 minecraft:bookshelf
fill 1 59 486 1 60 486 minecraft:bookshelf
fill 1 59 493 1 60 493 minecraft:bookshelf
fill 1 59 500 1 60 500 minecraft:bookshelf
fill 2 59 464 2 60 464 minecraft:bookshelf
fill 2 59 467 3 59 467 minecraft:bookshelf
setblock 3 59 468 minecraft:bookshelf
setblock 3 59 471 minecraft:bookshelf
fill 4 59 504 4 60 504 minecraft:bookshelf
fill 5 59 466 5 60 466 minecraft:bookshelf
fill 7 59 464 7 61 464 minecraft:bookshelf
fill 11 59 504 11 60 504 minecraft:bookshelf
fill 14 59 464 14 60 464 minecraft:bookshelf
fill 18 59 504 18 60 504 minecraft:bookshelf
fill 21 59 464 21 60 464 minecraft:bookshelf
fill 25 59 504 25 60 504 minecraft:bookshelf
fill 28 59 464 28 60 464 minecraft:bookshelf
fill 32 59 504 32 60 504 minecraft:bookshelf
fill 35 59 464 35 60 464 minecraft:bookshelf
fill 39 59 504 39 60 504 minecraft:bookshelf
fill 41 59 465 41 60 465 minecraft:bookshelf
fill 41 59 472 41 60 472 minecraft:bookshelf
fill 41 59 479 41 60 479 minecraft:bookshelf
fill 41 59 486 41 60 486 minecraft:bookshelf
fill 41 59 493 41 60 493 minecraft:bookshelf
fill 41 59 500 41 60 500 minecraft:bookshelf
fill 1 60 465 1 60 466 minecraft:bookshelf
fill 1 60 470 1 60 471 minecraft:bookshelf
fill 1 60 473 1 60 475 minecraft:bookshelf
fill 1 60 477 1 60 478 minecraft:bookshelf
fill 1 60 480 1 60 482 minecraft:bookshelf
fill 1 60 484 1 60 485 minecraft:bookshelf
fill 1 60 487 1 60 489 minecraft:bookshelf
fill 1 60 491 1 60 492 minecraft:bookshelf
fill 1 60 494 1 60 496 minecraft:bookshelf
fill 1 60 498 1 60 499 minecraft:bookshelf
fill 1 60 501 1 60 503 minecraft:bookshelf
fill 2 60 465 9 60 465 minecraft:bookshelf
fill 2 60 504 3 60 504 minecraft:bookshelf
fill 3 60 466 4 60 466 minecraft:bookshelf
fill 4 60 464 6 60 464 minecraft:bookshelf
fill 5 60 504 7 60 504 minecraft:bookshelf
fill 6 60 466 9 60 466 minecraft:bookshelf
fill 8 60 464 9 61 464 minecraft:bookshelf
fill 9 60 504 10 60 504 minecraft:bookshelf
fill 11 60 464 13 60 464 minecraft:bookshelf
fill 12 60 504 14 60 504 minecraft:bookshelf
fill 15 60 464 16 60 464 minecraft:bookshelf
fill 16 60 504 17 60 504 minecraft:bookshelf
fill 18 60 464 20 60 464 minecraft:bookshelf
fill 19 60 504 21 60 504 minecraft:bookshelf
fill 22 60 464 23 60 464 minecraft:bookshelf
fill 23 60 504 24 60 504 minecraft:bookshelf
fill 25 60 464 27 60 464 minecraft:bookshelf
fill 26 60 504 28 60 504 minecraft:bookshelf
fill 29 60 464 30 60 464 minecraft:bookshelf
fill 30 60 504 31 60 504 minecraft:bookshelf
fill 32 60 464 34 60 464 minecraft:bookshelf
fill 33 60 504 35 60 504 minecraft:bookshelf
fill 36 60 464 37 60 464 minecraft:bookshelf
fill 37 60 504 38 60 504 minecraft:bookshelf
fill 39 60 464 41 60 464 minecraft:bookshelf
fill 40 60 504 41 60 504 minecraft:bookshelf
fill 41 60 466 41 60 467 minecraft:bookshelf
fill 41 60 469 41 60 471 minecraft:bookshelf
fill 41 60 473 41 60 474 minecraft:bookshelf
fill 41 60 476 41 60 478 minecraft:bookshelf
fill 41 60 480 41 60 481 minecraft:bookshelf
fill 41 60 483 41 60 485 minecraft:bookshelf
fill 41 60 487 41 60 488 minecraft:bookshelf
fill 41 60 490 41 60 492 minecraft:bookshelf
fill 41 60 494 41 60 495 minecraft:bookshelf
fill 41 60 497 41 60 499 minecraft:bookshelf
fill 41 60 501 41 60 502 minecraft:bookshelf
setblock 1 61 467 minecraft:bookshelf
setblock 1 61 474 minecraft:bookshelf
setblock 1 61 481 minecraft:bookshelf
setblock 1 61 488 minecraft:bookshelf
setblock 1 61 495 minecraft:bookshelf
setblock 1 61 502 minecraft:bookshelf
fill 5 61 464 6 61 464 minecraft:bookshelf
setblock 6 61 504 minecraft:bookshelf
fill 7 61 465 13 61 465 minecraft:bookshelf
fill 8 61 466 13 61 466 minecraft:bookshelf
fill 11 61 464 12 62 464 minecraft:bookshelf
setblock 13 61 504 minecraft:bookshelf
setblock 19 61 464 minecraft:bookshelf
setblock 20 61 504 minecraft:bookshelf
setblock 26 61 464 minecraft:bookshelf
setblock 26 61 499 minecraft:ochre_froglight
setblock 27 61 504 minecraft:bookshelf
setblock 33 61 464 minecraft:bookshelf
setblock 34 61 504 minecraft:bookshelf
setblock 40 61 464 minecraft:bookshelf
setblock 41 61 470 minecraft:bookshelf
setblock 41 61 477 minecraft:bookshelf
setblock 41 61 484 minecraft:bookshelf
setblock 41 61 491 minecraft:bookshelf
setblock 41 61 498 minecraft:bookshelf
setblock 41 61 504 minecraft:bookshelf
setblock 1 62 468 minecraft:bookshelf
setblock 1 62 475 minecraft:bookshelf
setblock 1 62 482 minecraft:bookshelf
setblock 1 62 489 minecraft:bookshelf
setblock 1 62 496 minecraft:bookshelf
setblock 1 62 503 minecraft:bookshelf
setblock 3 62 466 minecraft:light[level=12]
setblock 3 62 474 minecraft:light[level=12]
setblock 3 62 482 minecraft:light[level=12]
setblock 3 62 490 minecraft:light[level=12]
setblock 3 62 498 minecraft:light[level=12]
setblock 4 62 464 minecraft:bookshelf
setblock 7 62 504 minecraft:bookshelf
fill 11 62 465 16 62 465 minecraft:bookshelf
setblock 11 62 466 minecraft:light[level=12]
setblock 11 62 474 minecraft:light[level=12]
setblock 11 62 482 minecraft:light[level=12]
setblock 11 62 490 minecraft:light[level=12]
setblock 11 62 498 minecraft:light[level=12]
fill 12 62 466 16 62 466 minecraft:bookshelf
fill 13 62 464 16 62 464 minecraft:bookshelf
setblock 14 62 504 minecraft:bookshelf
fill 18 62 464 18 64 464 minecraft:bookshelf
setblock 19 62 466 minecraft:light[level=12]
setblock 19 62 474 minecraft:light[level=12]
setblock 19 62 482 minecraft:light[level=12]
setblock 19 62 490 minecraft:light[level=12]
setblock 19 62 498 minecraft:light[level=12]
setblock 21 62 504 minecraft:bookshelf
setblock 25 62 464 minecraft:bookshelf
setblock 27 62 466 minecraft:light[level=12]
fill 27 62 470 29 63 470 minecraft:green_wool
setblock 27 62 474 minecraft:light[level=12]
setblock 27 62 482 minecraft:light[level=12]
setblock 27 62 490 minecraft:light[level=12]
setblock 27 62 498 minecraft:light[level=12]
fill 28 62 469 28 63 469 minecraft:green_wool
fill 28 62 471 28 63 471 minecraft:green_wool
setblock 28 62 504 minecraft:bookshelf
setblock 32 62 464 minecraft:bookshelf
setblock 35 62 466 minecraft:light[level=12]
setblock 35 62 474 minecraft:light[level=12]
setblock 35 62 482 minecraft:light[level=12]
setblock 35 62 490 minecraft:light[level=12]
setblock 35 62 498 minecraft:light[level=12]
setblock 35 62 504 minecraft:bookshelf
setblock 39 62 464 minecraft:bookshelf
setblock 41 62 469 minecraft:bookshelf
setblock 41 62 476 minecraft:bookshelf
setblock 41 62 483 minecraft:bookshelf
setblock 41 62 490 minecraft:bookshelf
setblock 41 62 497 minecraft:bookshelf
fill 15 63 464 16 63 466 minecraft:bookshelf
fill 17 63 465 19 63 466 minecraft:bookshelf
fill 19 63 464 19 64 464 minecraft:bookshelf
setblock 1 64 470 minecraft:bookshelf
setblock 1 64 477 minecraft:bookshelf
setblock 1 64 484 minecraft:bookshelf
setblock 1 64 491 minecraft:bookshelf
setblock 1 64 498 minecraft:bookshelf
setblock 2 64 464 minecraft:bookshelf
setblock 2 64 504 minecraft:bookshelf
setblock 9 64 464 minecraft:bookshelf
setblock 9 64 504 minecraft:bookshelf
setblock 16 64 464 minecraft:bookshelf
setblock 16 64 504 minecraft:bookshelf
fill 18 64 465 22 64 466 minecraft:bookshelf
fill 20 64 464 23 64 464 minecraft:bookshelf
setblock 23 64 504 minecraft:bookshelf
setblock 30 64 464 minecraft:bookshelf
setblock 30 64 504 minecraft:bookshelf
setblock 37 64 464 minecraft:bookshelf
setblock 37 64 504 minecraft:bookshelf
setblock 41 64 467 minecraft:bookshelf
setblock 41 64 474 minecraft:bookshelf
setblock 41 64 481 minecraft:bookshelf
setblock 41 64 488 minecraft:bookshelf
setblock 41 64 495 minecraft:bookshelf
setblock 41 64 502 minecraft:bookshelf
setblock 1 65 464 minecraft:bookshelf
setblock 1 65 471 minecraft:bookshelf
setblock 1 65 478 minecraft:bookshelf
setblock 1 65 485 minecraft:bookshelf
setblock 1 65 492 minecraft:bookshelf
setblock 1 65 499 minecraft:bookshelf
setblock 3 65 504 minecraft:bookshelf
setblock 8 65 464 minecraft:bookshelf
setblock 10 65 504 minecraft:bookshelf
setblock 15 65 464 minecraft:bookshelf
setblock 17 65 504 minecraft:bookshelf
fill 21 65 464 23 65 466 minecraft:bookshelf
fill 24 65 465 25 66 466 minecraft:bookshelf
setblock 24 65 504 minecraft:bookshelf
fill 25 65 464 25 66 464 minecraft:bookshelf
fill 29 65 464 29 67 464 minecraft:bookshelf
setblock 31 65 504 minecraft:bookshelf
setblock 36 65 464 minecraft:bookshelf
setblock 38 65 504 minecraft:bookshelf
setblock 41 65 466 minecraft:bookshelf
setblock 41 65 473 minecraft:bookshelf
setblock 41 65 480 minecraft:bookshelf
setblock 41 65 487 minecraft:bookshelf
setblock 41 65 494 minecraft:bookshelf
setblock 41 65 501 minecraft:bookshelf
setblock 1 66 465 minecraft:bookshelf
setblock 1 66 472 minecraft:bookshelf
setblock 1 66 479 minecraft:bookshelf
setblock 1 66 486 minecraft:bookshelf
setblock 1 66 493 minecraft:bookshelf
setblock 1 66 500 minecraft:bookshelf
setblock 4 66 504 minecraft:bookshelf
fill 5 66 464 5 67 466 minecraft:gold_block
setblock 7 66 464 minecraft:bookshelf
setblock 11 66 504 minecraft:bookshelf
setblock 14 66 464 minecraft:bookshelf
setblock 18 66 504 minecraft:bookshelf
setblock 21 66 464 minecraft:bookshelf
setblock 25 66 504 minecraft:bookshelf
fill 26 66 464 28 66 466 minecraft:bookshelf
setblock 32 66 504 minecraft:bookshelf
setblock 35 66 464 minecraft:bookshelf
setblock 39 66 504 minecraft:bookshelf
setblock 41 66 465 minecraft:bookshelf
setblock 41 66 472 minecraft:bookshelf
setblock 41 66 479 minecraft:bookshelf
setblock 41 66 486 minecraft:bookshelf
setblock 41 66 493 minecraft:bookshelf
setblock 41 66 500 minecraft:bookshelf
setblock 1 67 466 minecraft:bookshelf
setblock 1 67 473 minecraft:bookshelf
setblock 1 67 480 minecraft:bookshelf
setblock 1 67 487 minecraft:bookshelf
setblock 1 67 494 minecraft:bookshelf
setblock 1 67 501 minecraft:bookshelf
setblock 5 67 504 minecraft:bookshelf
setblock 6 67 464 minecraft:bookshelf
setblock 12 67 504 minecraft:bookshelf
setblock 13 67 464 minecraft:bookshelf
setblock 19 67 504 minecraft:bookshelf
setblock 20 67 464 minecraft:bookshelf
setblock 26 67 504 minecraft:bookshelf
fill 27 67 464 28 67 466 minecraft:bookshelf
fill 29 67 465 32 67 466 minecraft:bookshelf
setblock 30 67 464 minecraft:bookshelf
fill 32 67 464 34 68 464 minecraft:bookshelf
setblock 33 67 504 minecraft:bookshelf
setblock 40 67 504 minecraft:bookshelf
setblock 41 67 464 minecraft:bookshelf
setblock 41 67 471 minecraft:bookshelf
setblock 41 67 478 minecraft:bookshelf
setblock 41 67 485 minecraft:bookshelf
setblock 41 67 492 minecraft:bookshelf
setblock 41 67 499 minecraft:bookshelf
setblock 1 68 467 minecraft:bookshelf
setblock 1 68 474 minecraft:bookshelf
setblock 1 68 481 minecraft:bookshelf
setblock 1 68 488 minecraft:bookshelf
setblock 1 68 495 minecraft:bookshelf
setblock 1 68 502 minecraft:bookshelf
setblock 5 68 464 minecraft:bookshelf
setblock 6 68 504 minecraft:bookshelf
setblock 12 68 464 minecraft:bookshelf
setblock 13 68 504 minecraft:bookshelf
setblock 19 68 464 minecraft:bookshelf
setblock 20 68 504 minecraft:bookshelf
setblock 26 68 464 minecraft:bookshelf
setblock 27 68 504 minecraft:bookshelf
fill 30 68 466 36 68 466 minecraft:bookshelf
fill 31 68 465 37 68 465 minecraft:bookshelf
setblock 34 68 504 minecraft:bookshelf
fill 35 68 464 37 68 464 minecraft:bookshelf
fill 40 68 464 40 70 464 minecraft:bookshelf
setblock 41 68 470 minecraft:bookshelf
setblock 41 68 477 minecraft:bookshelf
setblock 41 68 484 minecraft:bookshelf
setblock 41 68 491 minecraft:bookshelf
setblock 41 68 498 minecraft:bookshelf
setblock 41 68 504 minecraft:bookshelf
fill 1 69 468 1 70 468 minecraft:bookshelf
fill 1 69 475 1 70 475 minecraft:bookshelf
fill 1 69 482 1 70 482 minecraft:bookshelf
fill 1 69 489 1 70 489 minecraft:bookshelf
fill 1 69 496 1 70 496 minecraft:bookshelf
fill 1 69 503 1 70 503 minecraft:bookshelf
fill 4 69 464 4 70 464 minecraft:bookshelf
fill 7 69 504 7 70 504 minecraft:bookshelf
fill 11 69 464 11 70 464 minecraft:bookshelf
fill 14 69 504 14 70 504 minecraft:bookshelf
fill 18 69 464 18 70 464 minecraft:bookshelf
fill 21 69 504 21 70 504 minecraft:bookshelf
fill 25 69 464 25 70 464 minecraft:bookshelf
fill 26 69 491 26 70 491 minecraft:red_wool
fill 28 69 504 28 70 504 minecraft:bookshelf
fill 32 69 464 32 70 464 minecraft:bookshelf
fill 34 69 466 41 69 466 minecraft:bookshelf
fill 35 69 465 41 69 465 minecraft:bookshelf
fill 35 69 504 35 70 504 minecraft:bookshelf
fill 36 69 464 37 70 464 minecraft:bookshelf
fill 39 69 464 39 70 464 minecraft:bookshelf
fill 39 69 467 39 70 468 minecraft:bookshelf
fill 40 69 467 40 70 467 minecraft:bookshelf
fill 41 69 464 41 70 464 minecraft:bookshelf
fill 41 69 469 41 71 469 minecraft:bookshelf
fill 41 69 476 41 70 476 minecraft:bookshelf
fill 41 69 483 41 70 483 minecraft:bookshelf
fill 41 69 490 41 70 490 minecraft:bookshelf
fill 41 69 497 41 70 497 minecraft:bookshelf
fill 1 70 464 1 70 467 minecraft:bookshelf
fill 1 70 470 1 70 474 minecraft:bookshelf
fill 1 70 477 1 70 481 minecraft:bookshelf
fill 1 70 484 1 70 488 minecraft:bookshelf
fill 1 70 491 1 70 495 minecraft:bookshelf
fill 1 70 498 1 70 502 minecraft:bookshelf
fill 2 70 464 2 71 464 minecraft:bookshelf
fill 2 70 504 6 70 504 minecraft:bookshelf
setblock 3 70 466 minecraft:light[level=12]
setblock 3 70 474 minecraft:light[level=12]
setblock 3 70 482 minecraft:light[level=12]
setblock 3 70 490 minecraft:light[level=12]
setblock 3 70 498 minecraft:light[level=12]
fill 5 70 464 9 70 464 minecraft:bookshelf
fill 9 70 504 13 70 504 minecraft:bookshelf
setblock 11 70 466 minecraft:light[level=12]
setblock 11 70 474 minecraft:light[level=12]
setblock 11 70 482 minecraft:light[level=12]
setblock 11 70 490 minecraft:light[level=12]
setblock 11 70 498 minecraft:light[level=12]
fill 12 70 464 16 70 464 minecraft:bookshelf
fill 16 70 504 20 70 504 minecraft:bookshelf
fill 19 70 464 23 70 464 minecraft:bookshelf
setblock 19 70 466 minecraft:light[level=12]
setblock 19 70 474 minecraft:light[level=12]
setblock 19 70 482 minecraft:light[level=12]
setblock 19 70 490 minecraft:light[level=12]
setblock 19 70 498 minecraft:light[level=12]
fill 23 70 504 27 70 504 minecraft:bookshelf
fill 26 70 464 30 70 464 minecraft:bookshelf
setblock 27 70 466 minecraft:light[level=12]
setblock 27 70 474 minecraft:light[level=12]
setblock 27 70 482 minecraft:light[level=12]
setblock 27 70 490 minecraft:light[level=12]
setblock 27 70 498 minecraft:light[level=12]
fill 30 70 504 34 70 504 minecraft:bookshelf
fill 33 70 464 35 70 464 minecraft:bookshelf
setblock 35 70 466 minecraft:light[level=12]
setblock 35 70 474 minecraft:light[level=12]
setblock 35 70 482 minecraft:light[level=12]
setblock 35 70 490 minecraft:light[level=12]
setblock 35 70 498 minecraft:light[level=12]
fill 37 70 504 41 70 504 minecraft:bookshelf
fill 39 70 466 41 70 466 minecraft:bookshelf
fill 39 70 469 40 70 472 minecraft:bookshelf
fill 40 70 465 41 70 465 minecraft:bookshelf
setblock 40 70 468 minecraft:bookshelf
fill 41 70 467 41 71 467 minecraft:bookshelf
fill 41 70 470 41 71 474 minecraft:bookshelf
fill 41 70 477 41 70 481 minecraft:bookshelf
fill 41 70 484 41 70 488 minecraft:bookshelf
fill 41 70 491 41 70 495 minecraft:bookshelf
fill 41 70 498 41 70 502 minecraft:bookshelf
setblock 1 71 470 minecraft:bookshelf
setblock 1 71 477 minecraft:bookshelf
setblock 1 71 484 minecraft:bookshelf
setblock 1 71 491 minecraft:bookshelf
setblock 1 71 498 minecraft:bookshelf
setblock 2 71 504 minecraft:bookshelf
fill 6 71 464 6 72 466 minecraft:gold_block
setblock 9 71 464 minecraft:bookshelf
setblock 9 71 504 minecraft:bookshelf
setblock 16 71 464 minecraft:bookshelf
setblock 16 71 504 minecraft:bookshelf
setblock 23 71 464 minecraft:bookshelf
setblock 23 71 504 minecraft:bookshelf
setblock 30 71 464 minecraft:bookshelf
setblock 30 71 504 minecraft:bookshelf
setblock 37 71 464 minecraft:bookshelf
setblock 37 71 504 minecraft:bookshelf
fill 39 71 471 40 71 476 minecraft:bookshelf
setblock 40 71 470 minecraft:bookshelf
setblock 41 71 481 minecraft:bookshelf
setblock 41 71 488 minecraft:bookshelf
setblock 41 71 495 minecraft:bookshelf
setblock 41 71 502 minecraft:bookshelf
setblock 1 72 464 minecraft:bookshelf
setblock 1 72 471 minecraft:bookshelf
setblock 1 72 478 minecraft:bookshelf
setblock 1 72 485 minecraft:bookshelf
setblock 1 72 492 minecraft:bookshelf
setblock 1 72 499 minecraft:bookshelf
setblock 3 72 504 minecraft:bookshelf
setblock 8 72 464 minecraft:bookshelf
setblock 10 72 504 minecraft:bookshelf
setblock 15 72 464 minecraft:bookshelf
setblock 17 72 504 minecraft:bookshelf
setblock 22 72 464 minecraft:bookshelf
setblock 24 72 504 minecraft:bookshelf
setblock 29 72 464 minecraft:bookshelf
setblock 31 72 504 minecraft:bookshelf
setblock 36 72 464 minecraft:bookshelf
setblock 38 72 504 minecraft:bookshelf
fill 39 72 475 40 72 479 minecraft:bookshelf
fill 40 72 474 41 72 474 minecraft:bookshelf
setblock 41 72 466 minecraft:bookshelf
setblock 41 72 473 minecraft:bookshelf
fill 41 72 476 41 72 480 minecraft:bookshelf
setblock 41 72 487 minecraft:bookshelf
setblock 41 72 494 minecraft:bookshelf
setblock 41 72 501 minecraft:bookshelf
setblock 1 73 465 minecraft:bookshelf
setblock 1 73 472 minecraft:bookshelf
setblock 1 73 479 minecraft:bookshelf
setblock 1 73 486 minecraft:bookshelf
setblock 1 73 493 minecraft:bookshelf
setblock 1 73 500 minecraft:bookshelf
setblock 4 73 504 minecraft:bookshelf
setblock 7 73 464 minecraft:bookshelf
setblock 11 73 504 minecraft:bookshelf
setblock 14 73 464 minecraft:bookshelf
setblock 18 73 504 minecraft:bookshelf
setblock 21 73 464 minecraft:bookshelf
setblock 25 73 504 minecraft:bookshelf
setblock 28 73 464 minecraft:bookshelf
setblock 32 73 504 minecraft:bookshelf
setblock 35 73 464 minecraft:bookshelf
fill 39 73 478 40 73 482 minecraft:bookshelf
setblock 39 73 504 minecraft:bookshelf
setblock 41 73 465 minecraft:bookshelf
setblock 41 73 472 minecraft:bookshelf
fill 41 73 478 41 73 481 minecraft:bookshelf
setblock 41 73 486 minecraft:bookshelf
setblock 41 73 493 minecraft:bookshelf
setblock 41 73 500 minecraft:bookshelf
setblock 3 78 466 minecraft:light[level=12]
setblock 3 78 474 minecraft:light[level=12]
setblock 3 78 482 minecraft:light[level=12]
setblock 3 78 490 minecraft:light[level=12]
setblock 3 78 498 minecraft:light[level=12]
setblock 11 78 466 minecraft:light[level=12]
setblock 11 78 474 minecraft:light[level=12]
setblock 11 78 482 minecraft:light[level=12]
setblock 11 78 490 minecraft:light[level=12]
setblock 11 78 498 minecraft:light[level=12]
fill 13 78 487 15 78 489 minecraft:redstone_block
fill 14 78 494 16 78 496 minecraft:redstone_block
setblock 19 78 466 minecraft:light[level=12]
setblock 19 78 474 minecraft:light[level=12]
setblock 19 78 482 minecraft:light[level=12]
setblock 19 78 498 minecraft:light[level=12]
fill 20 78 486 22 78 488 minecraft:redstone_block
fill 22 78 491 24 78 493 minecraft:redstone_block
setblock 27 78 466 minecraft:light[level=12]
setblock 27 78 474 minecraft:light[level=12]
setblock 27 78 482 minecraft:light[level=12]
setblock 27 78 490 minecraft:light[level=12]
setblock 27 78 498 minecraft:light[level=12]
setblock 35 78 466 minecraft:light[level=12]
setblock 35 78 474 minecraft:light[level=12]
setblock 35 78 482 minecraft:light[level=12]
setblock 35 78 490 minecraft:light[level=12]
setblock 35 78 498 minecraft:light[level=12]
fill 12 79 490 12 79 492 minecraft:black_concrete
setblock 13 79 490 minecraft:black_concrete
fill 13 79 491 16 79 491 minecraft:blue_concrete
fill 13 79 492 13 79 494 minecraft:black_concrete
fill 14 79 490 16 79 490 minecraft:blue_concrete
fill 14 79 492 16 79 493 minecraft:blue_concrete
fill 15 79 486 17 79 486 minecraft:black_concrete
fill 16 79 487 19 79 489 minecraft:blue_concrete
fill 17 79 485 19 79 485 minecraft:black_concrete
fill 17 79 493 21 79 495 minecraft:blue_concrete
fill 17 79 496 17 79 497 minecraft:black_concrete
fill 18 79 486 18 80 486 minecraft:blue_concrete
fill 18 79 496 18 80 496 minecraft:blue_concrete
fill 18 79 497 19 81 497 minecraft:black_concrete
setblock 19 79 486 minecraft:black_concrete
fill 19 79 496 21 81 496 minecraft:black_concrete
fill 20 79 489 21 79 492 minecraft:blue_concrete
fill 22 79 489 22 79 490 minecraft:blue_concrete
setblock 22 79 494 minecraft:blue_concrete
fill 22 79 495 22 81 495 minecraft:black_concrete
fill 23 79 488 23 79 490 minecraft:black_concrete
setblock 23 79 494 minecraft:black_concrete
setblock 24 79 490 minecraft:black_concrete
fill 1 80 464 11 80 504 minecraft:dark_oak_planks
fill 12 80 464 15 80 485 minecraft:dark_oak_planks
fill 12 80 486 12 80 490 minecraft:ochre_froglight
fill 12 80 491 12 80 493 minecraft:black_concrete
fill 12 80 494 12 80 504 minecraft:dark_oak_planks
fill 13 80 486 16 80 486 minecraft:ochre_froglight
fill 13 80 487 15 80 489 minecraft:dark_oak_planks
fill 13 80 490 16 80 490 minecraft:ochre_froglight
fill 13 80 491 15 80 491 minecraft:blue_concrete
fill 13 80 492 13 81 492 minecraft:black_concrete
fill 13 80 493 13 80 497 minecraft:ochre_froglight
fill 13 80 498 41 80 504 minecraft:dark_oak_planks
fill 14 80 492 15 80 492 minecraft:blue_concrete
fill 14 80 493 21 80 493 minecraft:ochre_froglight
fill 14 80 494 16 80 496 minecraft:dark_oak_planks
fill 14 80 497 17 80 497 minecraft:ochre_froglight
fill 16 80 464 41 80 484 minecraft:dark_oak_planks
fill 16 80 485 18 80 485 minecraft:black_concrete
fill 16 80 487 16 80 489 minecraft:ochre_froglight
fill 16 80 491 16 80 492 minecraft:ochre_froglight
fill 17 80 486 17 81 486 minecraft:black_concrete
fill 17 80 487 18 80 488 minecraft:blue_concrete
fill 17 80 489 23 80 489 minecraft:ochre_froglight
fill 17 80 494 17 80 496 minecraft:ochre_froglight
fill 18 80 494 20 80 495 minecraft:blue_concrete
fill 19 80 485 19 80 488 minecraft:ochre_froglight
fill 20 80 485 23 80 485 minecraft:ochre_froglight
fill 20 80 486 22 80 488 minecraft:dark_oak_planks
fill 20 80 490 21 80 492 minecraft:ochre_froglight
setblock 20 80 497 minecraft:black_concrete
fill 21 80 494 25 80 494 minecraft:ochre_froglight
setblock 21 80 495 minecraft:blue_concrete
fill 21 80 497 41 80 497 minecraft:dark_oak_planks
fill 22 80 490 25 80 490 minecraft:ochre_froglight
fill 22 80 491 24 80 493 minecraft:dark_oak_planks
setblock 22 80 496 minecraft:black_concrete
fill 23 80 486 23 80 488 minecraft:ochre_froglight
setblock 23 80 495 minecraft:black_concrete
fill 23 80 496 41 80 496 minecraft:dark_oak_planks
fill 24 80 485 41 80 488 minecraft:dark_oak_planks
setblock 24 80 489 minecraft:black_concrete
fill 24 80 495 41 80 495 minecraft:dark_oak_planks
fill 25 80 489 41 80 489 minecraft:dark_oak_planks
fill 25 80 491 25 80 493 minecraft:ochre_froglight
fill 26 80 490 41 80 494 minecraft:dark_oak_planks
fill 12 81 490 12 81 492 minecraft:black_concrete
fill 13 81 488 14 81 491 minecraft:black_concrete
fill 13 81 493 14 81 494 minecraft:black_concrete
fill 14 81 487 22 81 487 minecraft:black_concrete
setblock 14 81 492 minecraft:black_concrete
fill 14 81 495 21 81 495 minecraft:black_concrete
fill 15 81 486 16 81 486 minecraft:black_concrete
setblock 15 81 488 minecraft:black_concrete
setblock 15 81 494 minecraft:black_concrete
fill 15 81 496 18 81 496 minecraft:black_concrete
fill 17 81 485 19 81 485 minecraft:black_concrete
setblock 17 81 497 minecraft:black_concrete
fill 18 81 486 21 81 486 minecraft:black_concrete
fill 21 81 488 23 81 488 minecraft:black_concrete
fill 21 81 494 23 81 494 minecraft:black_concrete
fill 22 81 489 23 81 493 minecraft:black_concrete
fill 24 81 490 24 81 492 minecraft:black_concrete
fill 1 84 469 8 102 477 minecraft:bookshelf
fill 1 84 483 1 152 483 minecraft:bookshelf
fill 1 84 490 1 152 490 minecraft:bookshelf
fill 1 84 497 1 152 497 minecraft:bookshelf
fill 1 84 504 1 152 504 minecraft:bookshelf
fill 3 84 464 3 152 464 minecraft:bookshelf
fill 6 84 494 12 84 504 minecraft:bookshelf
fill 10 84 464 10 152 464 minecraft:bookshelf
fill 15 84 504 15 152 504 minecraft:bookshelf
fill 17 84 464 17 152 464 minecraft:bookshelf
fill 22 84 504 22 152 504 minecraft:bookshelf
fill 23 84 473 23 85 473 minecraft:red_wool
fill 24 84 464 24 152 464 minecraft:bookshelf
fill 29 84 504 29 152 504 minecraft:bookshelf
fill 31 84 464 31 152 464 minecraft:bookshelf
fill 36 84 504 36 152 504 minecraft:bookshelf
fill 38 84 464 38 152 464 minecraft:bookshelf
fill 39 84 481 41 84 485 minecraft:bookshelf
fill 41 84 468 41 152 468 minecraft:bookshelf
fill 41 84 475 41 152 475 minecraft:bookshelf
fill 41 84 489 41 152 489 minecraft:bookshelf
fill 41 84 496 41 152 496 minecraft:bookshelf
fill 41 84 503 41 152 503 minecraft:bookshelf
setblock 1 85 484 minecraft:bookshelf
setblock 1 85 491 minecraft:bookshelf
setblock 1 85 498 minecraft:bookshelf
setblock 2 85 464 minecraft:bookshelf
setblock 2 85 504 minecraft:bookshelf
fill 6 85 494 6 105 494 minecraft:bookshelf
setblock 6 85 495 minecraft:ochre_froglight
fill 6 85 496 6 105 496 minecraft:bookshelf
setblock 6 85 497 minecraft:ochre_froglight
fill 6 85 498 6 105 498 minecraft:bookshelf
setblock 6 85 499 minecraft:ochre_froglight
fill 6 85 500 6 105 500 minecraft:bookshelf
setblock 6 85 501 minecraft:ochre_froglight
fill 6 85 502 6 105 502 minecraft:bookshelf
setblock 6 85 503 minecraft:ochre_froglight
fill 6 85 504 6 105 504 minecraft:bookshelf
setblock 7 85 494 minecraft:ochre_froglight
fill 7 85 495 7 105 495 minecraft:bookshelf
setblock 7 85 496 minecraft:ochre_froglight
fill 7 85 497 7 105 497 minecraft:bookshelf
setblock 7 85 498 minecraft:ochre_froglight
fill 7 85 499 7 105 499 minecraft:bookshelf
setblock 7 85 500 minecraft:ochre_froglight
fill 7 85 501 7 105 501 minecraft:bookshelf
setblock 7 85 502 minecraft:ochre_froglight
fill 7 85 503 7 105 503 minecraft:bookshelf
setblock 7 85 504 minecraft:ochre_froglight
fill 8 85 494 8 105 494 minecraft:bookshelf
setblock 8 85 495 minecraft:ochre_froglight
fill 8 85 496 8 105 496 minecraft:bookshelf
setblock 8 85 497 minecraft:ochre_froglight
fill 8 85 498 8 105 498 minecraft:bookshelf
setblock 8 85 499 minecraft:ochre_froglight
fill 8 85 500 8 105 500 minecraft:bookshelf
setblock 8 85 501 minecraft:ochre_froglight
fill 8 85 502 8 105 502 minecraft:bookshelf
setblock 8 85 503 minecraft:ochre_froglight
fill 8 85 504 8 152 504 minecraft:bookshelf
setblock 9 85 464 minecraft:bookshelf
setblock 9 85 494 minecraft:ochre_froglight
fill 9 85 495 9 105 495 minecraft:bookshelf
setblock 9 85 496 minecraft:ochre_froglight
fill 9 85 497 9 105 497 minecraft:bookshelf
setblock 9 85 498 minecraft:ochre_froglight
fill 9 85 499 9 105 499 minecraft:bookshelf
setblock 9 85 500 minecraft:ochre_froglight
fill 9 85 501 9 105 501 minecraft:bookshelf
setblock 9 85 502 minecraft:ochre_froglight
fill 9 85 503 9 105 503 minecraft:bookshelf
setblock 9 85 504 minecraft:ochre_froglight
fill 10 85 494 10 105 494 minecraft:bookshelf
setblock 10 85 495 minecraft:ochre_froglight
fill 10 85 496 10 105 496 minecraft:bookshelf
setblock 10 85 497 minecraft:ochre_froglight
fill 10 85 498 10 105 498 minecraft:bookshelf
setblock 10 85 499 minecraft:ochre_froglight
fill 10 85 500 10 105 500 minecraft:bookshelf
setblock 10 85 501 minecraft:ochre_froglight
fill 10 85 502 10 105 502 minecraft:bookshelf
setblock 10 85 503 minecraft:ochre_froglight
fill 10 85 504 10 105 504 minecraft:bookshelf
setblock 11 85 494 minecraft:ochre_froglight
fill 11 85 495 11 105 495 minecraft:bookshelf
setblock 11 85 496 minecraft:ochre_froglight
fill 11 85 497 11 105 497 minecraft:bookshelf
setblock 11 85 498 minecraft:ochre_froglight
fill 11 85 499 11 105 499 minecraft:bookshelf
setblock 11 85 500 minecraft:ochre_froglight
fill 11 85 501 11 105 501 minecraft:bookshelf
setblock 11 85 502 minecraft:ochre_froglight
fill 11 85 503 11 105 503 minecraft:bookshelf
setblock 11 85 504 minecraft:ochre_froglight
fill 12 85 494 12 105 494 minecraft:bookshelf
setblock 12 85 495 minecraft:ochre_froglight
fill 12 85 496 12 105 496 minecraft:bookshelf
setblock 12 85 497 minecraft:ochre_froglight
fill 12 85 498 12 105 498 minecraft:bookshelf
setblock 12 85 499 minecraft:ochre_froglight
fill 12 85 500 12 105 500 minecraft:bookshelf
setblock 12 85 501 minecraft:ochre_froglight
fill 12 85 502 12 105 502 minecraft:bookshelf
setblock 12 85 503 minecraft:ochre_froglight
fill 12 85 504 12 105 504 minecraft:bookshelf
setblock 16 85 464 minecraft:bookshelf
setblock 16 85 504 minecraft:bookshelf
setblock 23 85 464 minecraft:bookshelf
setblock 23 85 504 minecraft:bookshelf
setblock 30 85 464 minecraft:bookshelf
setblock 30 85 504 minecraft:bookshelf
setblock 37 85 464 minecraft:bookshelf
setblock 37 85 504 minecraft:bookshelf
fill 39 85 484 41 85 488 minecraft:bookshelf
setblock 41 85 467 minecraft:bookshelf
setblock 41 85 474 minecraft:bookshelf
fill 41 85 481 41 85 482 minecraft:bookshelf
setblock 41 85 495 minecraft:bookshelf
setblock 41 85 502 minecraft:bookshelf
setblock 1 86 464 minecraft:bookshelf
setblock 1 86 478 minecraft:bookshelf
setblock 1 86 485 minecraft:bookshelf
setblock 1 86 492 minecraft:bookshelf
setblock 1 86 499 minecraft:bookshelf
setblock 3 86 466 minecraft:light[level=12]
setblock 3 86 482 minecraft:light[level=12]
setblock 3 86 490 minecraft:light[level=12]
setblock 3 86 498 minecraft:light[level=12]
setblock 3 86 504 minecraft:bookshelf
fill 6 86 495 6 87 495 minecraft:bookshelf
fill 6 86 497 6 87 497 minecraft:bookshelf
fill 6 86 499 6 87 499 minecraft:bookshelf
fill 6 86 501 6 87 501 minecraft:bookshelf
fill 6 86 503 6 87 503 minecraft:bookshelf
fill 7 86 494 7 87 494 minecraft:bookshelf
fill 7 86 496 7 87 496 minecraft:bookshelf
fill 7 86 498 7 87 498 minecraft:bookshelf
fill 7 86 500 7 87 500 minecraft:bookshelf
fill 7 86 502 7 87 502 minecraft:bookshelf
fill 7 86 504 7 87 504 minecraft:bookshelf
setblock 8 86 464 minecraft:bookshelf
fill 8 86 495 8 87 495 minecraft:bookshelf
fill 8 86 497 8 87 497 minecraft:bookshelf
fill 8 86 499 8 87 499 minecraft:bookshelf
fill 8 86 501 8 87 501 minecraft:bookshelf
fill 8 86 503 8 87 503 minecraft:bookshelf
fill 9 86 494 9 87 494 minecraft:bookshelf
fill 9 86 496 9 87 496 minecraft:bookshelf
fill 9 86 498 9 87 498 minecraft:bookshelf
fill 9 86 500 9 87 500 minecraft:bookshelf
fill 9 86 502 9 87 502 minecraft:bookshelf
fill 9 86 504 9 87 504 minecraft:bookshelf
fill 10 86 495 10 87 495 minecraft:bookshelf
fill 10 86 497 10 87 497 minecraft:bookshelf
fill 10 86 499 10 87 499 minecraft:bookshelf
fill 10 86 501 10 87 501 minecraft:bookshelf
fill 10 86 503 10 87 503 minecraft:bookshelf
setblock 11 86 466 minecraft:light[level=12]
setblock 11 86 474 minecraft:light[level=12]
setblock 11 86 482 minecraft:light[level=12]
setblock 11 86 490 minecraft:light[level=12]
fill 11 86 494 11 87 494 minecraft:bookshelf
fill 11 86 496 11 87 496 minecraft:bookshelf
fill 11 86 498 11 87 498 minecraft:bookshelf
fill 11 86 500 11 87 500 minecraft:bookshelf
fill 11 86 502 11 87 502 minecraft:bookshelf
fill 11 86 504 11 87 504 minecraft:bookshelf
fill 12 86 495 12 87 495 minecraft:bookshelf
fill 12 86 497 12 87 497 minecraft:bookshelf
fill 12 86 499 12 87 499 minecraft:bookshelf
fill 12 86 501 12 87 501 minecraft:bookshelf
fill 12 86 503 12 87 503 minecraft:bookshelf
setblock 15 86 464 minecraft:bookshelf
setblock 17 86 504 minecraft:bookshelf
setblock 19 86 466 minecraft:light[level=12]
setblock 19 86 474 minecraft:light[level=12]
setblock 19 86 482 minecraft:light[level=12]
setblock 19 86 490 minecraft:light[level=12]
setblock 19 86 498 minecraft:light[level=12]
setblock 22 86 464 minecraft:bookshelf
setblock 24 86 504 minecraft:bookshelf
setblock 27 86 466 minecraft:light[level=12]
setblock 27 86 474 minecraft:light[level=12]
setblock 27 86 482 minecraft:light[level=12]
setblock 27 86 490 minecraft:light[level=12]
setblock 27 86 498 minecraft:light[level=12]
setblock 29 86 464 minecraft:bookshelf
setblock 31 86 504 minecraft:bookshelf
setblock 35 86 466 minecraft:light[level=12]
setblock 35 86 474 minecraft:light[level=12]
setblock 35 86 482 minecraft:light[level=12]
setblock 35 86 490 minecraft:light[level=12]
setblock 35 86 498 minecraft:light[level=12]
setblock 36 86 464 minecraft:bookshelf
setblock 38 86 504 minecraft:bookshelf
fill 39 86 487 40 86 491 minecraft:bookshelf
setblock 41 86 466 minecraft:bookshelf
setblock 41 86 473 minecraft:bookshelf
setblock 41 86 480 minecraft:bookshelf
fill 41 86 482 41 152 482 minecraft:bookshelf
fill 41 86 487 41 86 488 minecraft:bookshelf
fill 41 86 490 41 86 492 minecraft:bookshelf
fill 41 86 494 41 88 494 minecraft:bookshelf
setblock 41 86 501 minecraft:bookshelf
setblock 1 87 465 minecraft:bookshelf
setblock 1 87 479 minecraft:bookshelf
setblock 1 87 486 minecraft:bookshelf
setblock 1 87 493 minecraft:bookshelf
setblock 1 87 500 minecraft:bookshelf
setblock 4 87 504 minecraft:bookshelf
setblock 7 87 464 minecraft:bookshelf
setblock 14 87 464 minecraft:bookshelf
setblock 18 87 504 minecraft:bookshelf
setblock 21 87 464 minecraft:bookshelf
setblock 25 87 504 minecraft:bookshelf
setblock 28 87 464 minecraft:bookshelf
setblock 32 87 504 minecraft:bookshelf
setblock 35 87 464 minecraft:bookshelf
fill 39 87 490 40 87 495 minecraft:bookshelf
setblock 39 87 504 minecraft:bookshelf
setblock 41 87 465 minecraft:bookshelf
setblock 41 87 472 minecraft:bookshelf
setblock 41 87 479 minecraft:bookshelf
setblock 41 87 486 minecraft:bookshelf
fill 41 87 491 41 87 493 minecraft:bookshelf
fill 41 87 495 41 88 495 minecraft:bookshelf
fill 41 87 500 41 90 500 minecraft:bookshelf
setblock 1 88 466 minecraft:bookshelf
setblock 1 88 480 minecraft:bookshelf
setblock 1 88 487 minecraft:bookshelf
setblock 1 88 494 minecraft:bookshelf
setblock 1 88 501 minecraft:bookshelf
setblock 5 88 504 minecraft:bookshelf
setblock 6 88 464 minecraft:bookshelf
setblock 6 88 495 minecraft:ochre_froglight
setblock 6 88 497 minecraft:ochre_froglight
setblock 6 88 499 minecraft:ochre_froglight
setblock 6 88 501 minecraft:ochre_froglight
setblock 6 88 503 minecraft:ochre_froglight
setblock 7 88 494 minecraft:ochre_froglight
setblock 7 88 496 minecraft:ochre_froglight
setblock 7 88 498 minecraft:ochre_froglight
setblock 7 88 500 minecraft:ochre_froglight
setblock 7 88 502 minecraft:ochre_froglight
setblock 7 88 504 minecraft:ochre_froglight
setblock 8 88 495 minecraft:ochre_froglight
setblock 8 88 497 minecraft:ochre_froglight
setblock 8 88 499 minecraft:ochre_froglight
setblock 8 88 501 minecraft:ochre_froglight
setblock 8 88 503 minecraft:ochre_froglight
setblock 9 88 494 minecraft:ochre_froglight
setblock 9 88 496 minecraft:ochre_froglight
setblock 9 88 498 minecraft:ochre_froglight
setblock 9 88 500 minecraft:ochre_froglight
setblock 9 88 502 minecraft:ochre_froglight
setblock 9 88 504 minecraft:ochre_froglight
setblock 10 88 495 minecraft:ochre_froglight
setblock 10 88 497 minecraft:ochre_froglight
setblock 10 88 499 minecraft:ochre_froglight
setblock 10 88 501 minecraft:ochre_froglight
setblock 10 88 503 minecraft:ochre_froglight
setblock 11 88 494 minecraft:ochre_froglight
setblock 11 88 496 minecraft:ochre_froglight
setblock 11 88 498 minecraft:ochre_froglight
setblock 11 88 500 minecraft:ochre_froglight
setblock 11 88 502 minecraft:ochre_froglight
setblock 11 88 504 minecraft:ochre_froglight
setblock 12 88 495 minecraft:ochre_froglight
setblock 12 88 497 minecraft:ochre_froglight
setblock 12 88 499 minecraft:ochre_froglight
setblock 12 88 501 minecraft:ochre_froglight
setblock 12 88 503 minecraft:ochre_froglight
setblock 13 88 464 minecraft:bookshelf
setblock 19 88 504 minecraft:bookshelf
setblock 20 88 464 minecraft:bookshelf
setblock 26 88 504 minecraft:bookshelf
setblock 27 88 464 minecraft:bookshelf
setblock 33 88 504 minecraft:bookshelf
setblock 34 88 464 minecraft:bookshelf
fill 39 88 493 39 88 499 minecraft:bookshelf
fill 40 88 494 40 88 500 minecraft:bookshelf
fill 40 88 504 40 90 504 minecraft:bookshelf
setblock 41 88 464 minecraft:bookshelf
setblock 41 88 471 minecraft:bookshelf
setblock 41 88 478 minecraft:bookshelf
setblock 41 88 485 minecraft:bookshelf
setblock 41 88 492 minecraft:bookshelf
fill 41 88 497 41 88 499 minecraft:bookshelf
fill 41 88 501 41 90 501 minecraft:bookshelf
fill 1 89 467 1 90 467 minecraft:bookshelf
fill 1 89 481 1 90 481 minecraft:bookshelf
fill 1 89 488 1 90 488 minecraft:bookshelf
fill 1 89 495 1 90 495 minecraft:bookshelf
fill 1 89 502 1 90 502 minecraft:bookshelf
fill 5 89 464 5 90 464 minecraft:bookshelf
fill 6 89 495 6 90 495 minecraft:bookshelf
fill 6 89 497 6 90 497 minecraft:bookshelf
fill 6 89 499 6 90 499 minecraft:bookshelf
fill 6 89 501 6 90 501 minecraft:bookshelf
fill 6 89 503 6 90 503 minecraft:bookshelf
fill 7 89 494 7 90 494 minecraft:bookshelf
fill 7 89 496 7 90 496 minecraft:bookshelf
fill 7 89 498 7 90 498 minecraft:bookshelf
fill 7 89 500 7 90 500 minecraft:bookshelf
fill 7 89 502 7 90 502 minecraft:bookshelf
fill 7 89 504 7 90 504 minecraft:bookshelf
fill 8 89 495 8 90 495 minecraft:bookshelf
fill 8 89 497 8 90 497 minecraft:bookshelf
fill 8 89 499 8 90 499 minecraft:bookshelf
fill 8 89 501 8 90 501 minecraft:bookshelf
fill 8 89 503 8 90 503 minecraft:bookshelf
fill 9 89 494 9 90 494 minecraft:bookshelf
fill 9 89 496 9 90 496 minecraft:bookshelf
fill 9 89 498 9 90 498 minecraft:bookshelf
fill 9 89 500 9 90 500 minecraft:bookshelf
fill 9 89 502 9 90 502 minecraft:bookshelf
fill 9 89 504 9 90 504 minecraft:bookshelf
fill 10 89 495 10 90 495 minecraft:bookshelf
fill 10 89 497 10 90 497 minecraft:bookshelf
fill 10 89 499 10 90 499 minecraft:bookshelf
fill 10 89 501 10 90 501 minecraft:bookshelf
fill 10 89 503 10 90 503 minecraft:bookshelf
fill 11 89 494 11 90 494 minecraft:bookshelf
fill 11 89 496 11 90 496 minecraft:bookshelf
fill 11 89 498 11 90 498 minecraft:bookshelf
fill 11 89 500 11 90 500 minecraft:bookshelf
fill 11 89 502 11 90 502 minecraft:bookshelf
fill 11 89 504 11 90 504 minecraft:bookshelf
fill 12 89 464 12 90 464 minecraft:bookshelf
fill 12 89 495 12 90 495 minecraft:bookshelf
fill 12 89 497 12 90 497 minecraft:bookshelf
fill 12 89 499 12 90 499 minecraft:bookshelf
fill 12 89 501 12 90 501 minecraft:bookshelf
fill 12 89 503 12 90 503 minecraft:bookshelf
fill 13 89 504 13 90 504 minecraft:bookshelf
fill 19 89 464 19 90 464 minecraft:bookshelf
fill 20 89 504 20 90 504 minecraft:bookshelf
fill 26 89 464 26 90 464 minecraft:bookshelf
fill 27 89 504 27 90 504 minecraft:bookshelf
fill 33 89 464 33 90 464 minecraft:bookshelf
fill 34 89 504 34 91 504 minecraft:bookshelf
fill 37 89 502 41 89 502 minecraft:bookshelf
fill 38 89 503 40 90 503 minecraft:bookshelf
fill 39 89 497 39 89 501 minecraft:bookshelf
fill 39 89 504 39 90 504 minecraft:bookshelf
fill 40 89 464 40 90 464 minecraft:bookshelf
fill 40 89 498 40 89 501 minecraft:bookshelf
fill 41 89 470 41 90 470 minecraft:bookshelf
fill 41 89 477 41 90 477 minecraft:bookshelf
fill 41 89 484 41 90 484 minecraft:bookshelf
fill 41 89 491 41 90 491 minecraft:bookshelf
fill 41 89 498 41 90 499 minecraft:bookshelf
fill 41 89 504 41 90 504 minecraft:bookshelf
fill 1 90 464 1 90 466 minecraft:bookshelf
setblock 1 90 468 minecraft:bookshelf
fill 1 90 478 1 90 480 minecraft:bookshelf
setblock 1 90 482 minecraft:bookshelf
fill 1 90 484 1 90 487 minecraft:bookshelf
setblock 1 90 489 minecraft:bookshelf
fill 1 90 491 1 90 494 minecraft:bookshelf
setblock 1 90 496 minecraft:bookshelf
fill 1 90 498 1 90 501 minecraft:bookshelf
setblock 1 90 503 minecraft:bookshelf
setblock 2 90 464 minecraft:bookshelf
fill 2 90 504 5 90 504 minecraft:bookshelf
setblock 4 90 464 minecraft:bookshelf
fill 6 90 464 9 90 464 minecraft:bookshelf
setblock 11 90 464 minecraft:bookshelf
fill 13 90 464 16 90 464 minecraft:bookshelf
setblock 14 90 504 minecraft:bookshelf
fill 16 90 504 19 90 504 minecraft:bookshelf
setblock 18 90 464 minecraft:bookshelf
fill 20 90 464 23 90 464 minecraft:bookshelf
setblock 21 90 504 minecraft:bookshelf
fill 23 90 504 26 90 504 minecraft:bookshelf
setblock 25 90 464 minecraft:bookshelf
fill 27 90 464 30 90 464 minecraft:bookshelf
setblock 28 90 504 minecraft:bookshelf
fill 30 90 504 33 91 504 minecraft:bookshelf
setblock 32 90 464 minecraft:bookshelf
fill 33 90 502 37 90 503 minecraft:bookshelf
fill 34 90 464 37 90 464 minecraft:bookshelf
fill 35 90 504 35 91 504 minecraft:bookshelf
fill 37 90 504 38 90 504 minecraft:bookshelf
fill 38 90 502 39 90 502 minecraft:bookshelf
setblock 39 90 464 minecraft:bookshelf
fill 41 90 464 41 90 467 minecraft:bookshelf
setblock 41 90 469 minecraft:bookshelf
fill 41 90 471 41 90 474 minecraft:bookshelf
setblock 41 90 476 minecraft:bookshelf
fill 41 90 478 41 90 481 minecraft:bookshelf
setblock 41 90 483 minecraft:bookshelf
fill 41 90 485 41 90 488 minecraft:bookshelf
setblock 41 90 490 minecraft:bookshelf
fill 41 90 492 41 90 495 minecraft:bookshelf
setblock 41 90 497 minecraft:bookshelf
setblock 41 90 502 minecraft:bookshelf
fill 0 91 463 0 94 463 minecraft:dark_oak_planks
setblock 0 91 464 minecraft:bookshelf
fill 0 91 465 0 92 469 minecraft:dark_oak_planks
setblock 0 91 470 minecraft:bookshelf
fill 0 91 471 0 91 480 minecraft:dark_oak_planks
setblock 0 91 481 minecraft:bookshelf
fill 0 91 482 0 91 486 minecraft:dark_oak_planks
setblock 0 91 487 minecraft:bookshelf
fill 0 91 488 0 91 500 minecraft:dark_oak_planks
fill 0 91 501 0 91 502 minecraft:bookshelf
fill 0 91 503 0 94 505 minecraft:dark_oak_planks
fill 1 91 505 22 91 505 minecraft:dark_oak_planks
setblock 6 91 495 minecraft:ochre_froglight
setblock 6 91 497 minecraft:ochre_froglight
setblock 6 91 499 minecraft:ochre_froglight
setblock 6 91 501 minecraft:ochre_froglight
setblock 6 91 503 minecraft:ochre_froglight
setblock 7 91 494 minecraft:ochre_froglight
setblock 7 91 496 minecraft:ochre_froglight
setblock 7 91 498 minecraft:ochre_froglight
setblock 7 91 500 minecraft:ochre_froglight
setblock 7 91 502 minecraft:ochre_froglight
setblock 7 91 504 minecraft:ochre_froglight
setblock 8 91 495 minecraft:ochre_froglight
setblock 8 91 497 minecraft:ochre_froglight
setblock 8 91 499 minecraft:ochre_froglight
setblock 8 91 501 minecraft:ochre_froglight
setblock 8 91 503 minecraft:ochre_froglight
setblock 9 91 494 minecraft:ochre_froglight
setblock 9 91 496 minecraft:ochre_froglight
setblock 9 91 498 minecraft:ochre_froglight
setblock 9 91 500 minecraft:ochre_froglight
setblock 9 91 502 minecraft:ochre_froglight
setblock 9 91 504 minecraft:ochre_froglight
setblock 10 91 495 minecraft:ochre_froglight
setblock 10 91 497 minecraft:ochre_froglight
setblock 10 91 499 minecraft:ochre_froglight
setblock 10 91 501 minecraft:ochre_froglight
setblock 10 91 503 minecraft:ochre_froglight
setblock 11 91 494 minecraft:ochre_froglight
setblock 11 91 496 minecraft:ochre_froglight
setblock 11 91 498 minecraft:ochre_froglight
setblock 11 91 500 minecraft:ochre_froglight
setblock 11 91 502 minecraft:ochre_froglight
setblock 11 91 504 minecraft:ochre_froglight
setblock 12 91 495 minecraft:ochre_froglight
setblock 12 91 497 minecraft:ochre_froglight
setblock 12 91 499 minecraft:ochre_froglight
setblock 12 91 501 minecraft:ochre_froglight
setblock 12 91 503 minecraft:ochre_froglight
setblock 23 91 505 minecraft:bookshelf
fill 24 91 505 25 94 505 minecraft:dark_oak_planks
setblock 26 91 505 minecraft:bookshelf
fill 27 91 505 35 91 505 minecraft:dark_oak_planks
fill 29 91 502 34 91 503 minecraft:bookshelf
setblock 35 91 503 minecraft:bookshelf
fill 36 91 505 36 92 505 minecraft:bookshelf
fill 37 91 505 38 92 505 minecraft:dark_oak_planks
fill 39 91 505 40 91 505 minecraft:bookshelf
fill 41 91 505 42 94 505 minecraft:dark_oak_planks
fill 42 91 464 42 91 465 minecraft:dark_oak_planks
fill 42 91 466 42 92 466 minecraft:bookshelf
fill 42 91 467 42 94 469 minecraft:dark_oak_planks
fill 42 91 470 42 92 470 minecraft:bookshelf
fill 42 91 471 42 91 478 minecraft:dark_oak_planks
fill 42 91 479 42 91 480 minecraft:bookshelf
fill 42 91 481 42 92 486 minecraft:dark_oak_planks
setblock 42 91 487 minecraft:bookshelf
fill 42 91 488 42 91 493 minecraft:dark_oak_planks
setblock 42 91 494 minecraft:bookshelf
fill 42 91 495 42 94 496 minecraft:dark_oak_planks
fill 42 91 497 42 91 498 minecraft:bookshelf
fill 42 91 499 42 94 504 minecraft:dark_oak_planks
fill 0 92 464 0 94 464 minecraft:dark_oak_planks
fill 0 92 470 0 94 477 minecraft:dark_oak_planks
setblock 0 92 478 minecraft:bookshelf
fill 0 92 479 0 92 485 minecraft:dark_oak_planks
fill 0 92 486 0 93 486 minecraft:bookshelf
fill 0 92 487 0 92 490 minecraft:dark_oak_planks
fill 0 92 491 1 92 491 minecraft:bookshelf
fill 0 92 492 0 92 502 minecraft:dark_oak_planks
setblock 1 92 463 minecraft:bookshelf
setblock 1 92 484 minecraft:bookshelf
setblock 1 92 498 minecraft:bookshelf
fill 1 92 505 1 95 505 minecraft:dark_oak_planks
fill 2 92 463 26 92 463 minecraft:dark_oak_planks
setblock 2 92 464 minecraft:bookshelf
fill 2 92 504 2 92 505 minecraft:bookshelf
fill 3 92 505 21 92 505 minecraft:dark_oak_planks
fill 6 92 495 6 93 495 minecraft:bookshelf
fill 6 92 497 6 93 497 minecraft:bookshelf
fill 6 92 499 6 93 499 minecraft:bookshelf
fill 6 92 501 6 93 501 minecraft:bookshelf
fill 6 92 503 6 93 503 minecraft:bookshelf
fill 7 92 494 7 93 494 minecraft:bookshelf
fill 7 92 496 7 93 496 minecraft:bookshelf
fill 7 92 498 7 93 498 minecraft:bookshelf
fill 7 92 500 7 93 500 minecraft:bookshelf
fill 7 92 502 7 93 502 minecraft:bookshelf
fill 7 92 504 7 93 504 minecraft:bookshelf
fill 8 92 495 8 93 495 minecraft:bookshelf
fill 8 92 497 8 93 497 minecraft:bookshelf
fill 8 92 499 8 93 499 minecraft:bookshelf
fill 8 92 501 8 93 501 minecraft:bookshelf
fill 8 92 503 8 93 503 minecraft:bookshelf
setblock 9 92 464 minecraft:bookshelf
fill 9 92 494 9 93 494 minecraft:bookshelf
fill 9 92 496 9 93 496 minecraft:bookshelf
fill 9 92 498 9 93 498 minecraft:bookshelf
fill 9 92 500 9 93 500 minecraft:bookshelf
fill 9 92 502 9 93 502 minecraft:bookshelf
fill 9 92 504 9 93 504 minecraft:bookshelf
fill 10 92 495 10 93 495 minecraft:bookshelf
fill 10 92 497 10 93 497 minecraft:bookshelf
fill 10 92 499 10 93 499 minecraft:bookshelf
fill 10 92 501 10 93 501 minecraft:bookshelf
fill 10 92 503 10 93 503 minecraft:bookshelf
fill 11 92 494 11 93 494 minecraft:bookshelf
fill 11 92 496 11 93 496 minecraft:bookshelf
fill 11 92 498 11 93 498 minecraft:bookshelf
fill 11 92 500 11 93 500 minecraft:bookshelf
fill 11 92 502 11 93 502 minecraft:bookshelf
fill 11 92 504 11 93 504 minecraft:bookshelf
fill 12 92 495 12 93 495 minecraft:bookshelf
fill 12 92 497 12 93 497 minecraft:bookshelf
fill 12 92 499 12 93 499 minecraft:bookshelf
fill 12 92 501 12 93 501 minecraft:bookshelf
fill 12 92 503 12 93 503 minecraft:bookshelf
setblock 16 92 464 minecraft:bookshelf
setblock 16 92 504 minecraft:bookshelf
setblock 22 92 505 minecraft:bookshelf
setblock 23 92 464 minecraft:bookshelf
fill 23 92 504 23 94 504 minecraft:bookshelf
fill 23 92 505 23 94 505 minecraft:dark_oak_planks
fill 26 92 502 28 92 504 minecraft:bookshelf
fill 26 92 505 33 92 505 minecraft:dark_oak_planks
setblock 27 92 463 minecraft:bookshelf
fill 28 92 463 33 94 463 minecraft:dark_oak_planks
fill 29 92 502 30 92 503 minecraft:bookshelf
setblock 30 92 464 minecraft:bookshelf
fill 30 92 504 31 92 504 minecraft:bookshelf
setblock 31 92 503 minecraft:bookshelf
setblock 34 92 463 minecraft:bookshelf
setblock 34 92 505 minecraft:bookshelf
fill 35 92 463 37 92 463 minecraft:dark_oak_planks
fill 35 92 505 35 95 505 minecraft:dark_oak_planks
setblock 37 92 464 minecraft:bookshelf
setblock 37 92 504 minecraft:bookshelf
fill 38 92 463 39 92 463 minecraft:bookshelf
fill 39 92 505 40 94 505 minecraft:dark_oak_planks
fill 40 92 463 40 94 463 minecraft:dark_oak_planks
setblock 41 92 463 minecraft:bookshelf
setblock 41 92 467 minecraft:bookshelf
setblock 41 92 474 minecraft:bookshelf
setblock 41 92 481 minecraft:bookshelf
setblock 41 92 488 minecraft:bookshelf
setblock 41 92 495 minecraft:bookshelf
setblock 41 92 502 minecraft:bookshelf
fill 42 92 463 42 94 464 minecraft:dark_oak_planks
setblock 42 92 465 minecraft:bookshelf
setblock 42 92 471 minecraft:bookshelf
fill 42 92 472 42 94 480 minecraft:dark_oak_planks
fill 42 92 487 42 94 489 minecraft:dark_oak_planks
setblock 42 92 490 minecraft:bookshelf
fill 42 92 491 42 92 494 minecraft:dark_oak_planks
fill 42 92 497 42 94 498 minecraft:dark_oak_planks
setblock 0 93 465 minecraft:bookshelf
fill 0 93 466 0 94 469 minecraft:dark_oak_planks
fill 0 93 478 0 94 479 minecraft:dark_oak_planks
setblock 0 93 480 minecraft:bookshelf
fill 0 93 481 0 94 485 minecraft:dark_oak_planks
fill 0 93 487 0 94 488 minecraft:dark_oak_planks
setblock 0 93 489 minecraft:bookshelf
fill 0 93 490 0 94 498 minecraft:dark_oak_planks
fill 0 93 499 1 93 499 minecraft:bookshelf
fill 0 93 500 0 94 502 minecraft:dark_oak_planks
fill 1 93 463 3 94 463 minecraft:dark_oak_planks
setblock 1 93 464 minecraft:bookshelf
setblock 1 93 478 minecraft:bookshelf
setblock 1 93 485 minecraft:bookshelf
setblock 1 93 492 minecraft:bookshelf
fill 2 93 505 4 94 505 minecraft:dark_oak_planks
setblock 3 93 504 minecraft:bookshelf
setblock 4 93 463 minecraft:bookshelf
fill 5 93 463 7 94 463 minecraft:dark_oak_planks
fill 5 93 505 6 93 505 minecraft:bookshelf
fill 7 93 505 7 94 505 minecraft:dark_oak_planks
fill 8 93 463 8 93 464 minecraft:bookshelf
setblock 8 93 505 minecraft:bookshelf
fill 9 93 463 19 94 463 minecraft:dark_oak_planks
fill 9 93 505 17 94 505 minecraft:dark_oak_planks
setblock 15 93 464 minecraft:bookshelf
setblock 17 93 504 minecraft:bookshelf
setblock 18 93 505 minecraft:bookshelf
fill 19 93 505 22 94 505 minecraft:dark_oak_planks
setblock 20 93 463 minecraft:bookshelf
fill 21 93 463 25 94 463 minecraft:dark_oak_planks
setblock 22 93 464 minecraft:bookshelf
fill 23 93 502 27 93 503 minecraft:bookshelf
fill 24 93 504 27 93 504 minecraft:bookshelf
setblock 26 93 463 minecraft:bookshelf
setblock 26 93 505 minecraft:bookshelf
fill 27 93 463 27 94 463 minecraft:dark_oak_planks
fill 27 93 505 27 94 505 minecraft:dark_oak_planks
setblock 28 93 505 minecraft:bookshelf
setblock 29 93 464 minecraft:bookshelf
fill 29 93 505 32 94 505 minecraft:dark_oak_planks
setblock 31 93 504 minecraft:bookshelf
setblock 33 93 505 minecraft:bookshelf
fill 34 93 463 35 94 463 minecraft:dark_oak_planks
fill 34 93 505 34 95 505 minecraft:dark_oak_planks
fill 36 93 463 36 93 464 minecraft:bookshelf
fill 36 93 505 37 94 505 minecraft:dark_oak_planks
fill 37 93 463 39 94 463 minecraft:dark_oak_planks
fill 38 93 504 38 93 505 minecraft:bookshelf
fill 41 93 463 41 94 463 minecraft:dark_oak_planks
setblock 41 93 466 minecraft:bookshelf
setblock 41 93 473 minecraft:bookshelf
setblock 41 93 480 minecraft:bookshelf
setblock 41 93 487 minecraft:bookshelf
setblock 41 93 494 minecraft:bookshelf
setblock 41 93 501 minecraft:bookshelf
fill 42 93 465 42 94 466 minecraft:dark_oak_planks
fill 42 93 470 42 94 471 minecraft:dark_oak_planks
fill 42 93 481 42 94 481 minecraft:dark_oak_planks
setblock 42 93 482 minecraft:bookshelf
fill 42 93 483 42 94 486 minecraft:dark_oak_planks
fill 42 93 490 42 95 490 minecraft:dark_oak_planks
setblock 42 93 491 minecraft:bookshelf
fill 42 93 492 42 94 494 minecraft:dark_oak_planks
setblock 0 94 465 minecraft:dark_oak_planks
setblock 0 94 480 minecraft:dark_oak_planks
setblock 0 94 486 minecraft:dark_oak_planks
setblock 0 94 489 minecraft:dark_oak_planks
setblock 0 94 499 minecraft:dark_oak_planks
setblock 1 94 465 minecraft:bookshelf
setblock 1 94 479 minecraft:bookshelf
setblock 1 94 486 minecraft:bookshelf
setblock 1 94 493 minecraft:bookshelf
setblock 1 94 500 minecraft:bookshelf
setblock 3 94 466 minecraft:light[level=12]
setblock 3 94 482 minecraft:light[level=12]
setblock 3 94 490 minecraft:light[level=12]
setblock 3 94 498 minecraft:light[level=12]
fill 4 94 463 4 95 463 minecraft:dark_oak_planks
setblock 4 94 504 minecraft:bookshelf
fill 5 94 505 6 94 505 minecraft:dark_oak_planks
setblock 6 94 495 minecraft:ochre_froglight
setblock 6 94 497 minecraft:ochre_froglight
setblock 6 94 499 minecraft:ochre_froglight
setblock 6 94 501 minecraft:ochre_froglight
setblock 6 94 503 minecraft:ochre_froglight
setblock 7 94 464 minecraft:bookshelf
setblock 7 94 494 minecraft:ochre_froglight
setblock 7 94 496 minecraft:ochre_froglight
setblock 7 94 498 minecraft:ochre_froglight
setblock 7 94 500 minecraft:ochre_froglight
setblock 7 94 502 minecraft:ochre_froglight
setblock 7 94 504 minecraft:ochre_froglight
fill 8 94 463 8 95 463 minecraft:dark_oak_planks
setblock 8 94 495 minecraft:ochre_froglight
setblock 8 94 497 minecraft:ochre_froglight
setblock 8 94 499 minecraft:ochre_froglight
setblock 8 94 501 minecraft:ochre_froglight
setblock 8 94 503 minecraft:ochre_froglight
setblock 8 94 505 minecraft:dark_oak_planks
setblock 9 94 494 minecraft:ochre_froglight
setblock 9 94 496 minecraft:ochre_froglight
setblock 9 94 498 minecraft:ochre_froglight
setblock 9 94 500 minecraft:ochre_froglight
setblock 9 94 502 minecraft:ochre_froglight
setblock 9 94 504 minecraft:ochre_froglight
setblock 10 94 495 minecraft:ochre_froglight
setblock 10 94 497 minecraft:ochre_froglight
setblock 10 94 499 minecraft:ochre_froglight
setblock 10 94 501 minecraft:ochre_froglight
setblock 10 94 503 minecraft:ochre_froglight
setblock 11 94 466 minecraft:light[level=12]
setblock 11 94 474 minecraft:light[level=12]
setblock 11 94 482 minecraft:light[level=12]
setblock 11 94 490 minecraft:light[level=12]
setblock 11 94 494 minecraft:ochre_froglight
setblock 11 94 496 minecraft:ochre_froglight
setblock 11 94 498 minecraft:ochre_froglight
setblock 11 94 500 minecraft:ochre_froglight
setblock 11 94 502 minecraft:ochre_froglight
setblock 11 94 504 minecraft:ochre_froglight
setblock 12 94 495 minecraft:ochre_froglight
setblock 12 94 497 minecraft:ochre_froglight
setblock 12 94 499 minecraft:ochre_froglight
setblock 12 94 501 minecraft:ochre_froglight
setblock 12 94 503 minecraft:ochre_froglight
setblock 14 94 464 minecraft:bookshelf
fill 18 94 504 18 96 504 minecraft:bookshelf
setblock 18 94 505 minecraft:dark_oak_planks
setblock 19 94 466 minecraft:light[level=12]
setblock 19 94 474 minecraft:light[level=12]
setblock 19 94 482 minecraft:light[level=12]
setblock 19 94 498 minecraft:light[level=12]
setblock 20 94 463 minecraft:dark_oak_planks
fill 20 94 502 21 95 504 minecraft:bookshelf
setblock 21 94 464 minecraft:bookshelf
fill 22 94 502 24 94 503 minecraft:bookshelf
fill 24 94 504 25 94 504 minecraft:bookshelf
setblock 26 94 463 minecraft:dark_oak_planks
setblock 26 94 505 minecraft:dark_oak_planks
setblock 27 94 466 minecraft:light[level=12]
setblock 27 94 474 minecraft:light[level=12]
setblock 27 94 482 minecraft:light[level=12]
setblock 27 94 490 minecraft:light[level=12]
setblock 27 94 498 minecraft:light[level=12]
setblock 28 94 464 minecraft:bookshelf
setblock 28 94 505 minecraft:dark_oak_planks
setblock 32 94 504 minecraft:bookshelf
setblock 33 94 505 minecraft:dark_oak_planks
setblock 35 94 464 minecraft:bookshelf
setblock 35 94 466 minecraft:light[level=12]
setblock 35 94 474 minecraft:light[level=12]
setblock 35 94 482 minecraft:light[level=12]
setblock 35 94 490 minecraft:light[level=12]
setblock 35 94 498 minecraft:light[level=12]
setblock 36 94 463 minecraft:dark_oak_planks
setblock 38 94 505 minecraft:dark_oak_planks
setblock 39 94 504 minecraft:bookshelf
setblock 41 94 465 minecraft:bookshelf
setblock 41 94 472 minecraft:bookshelf
setblock 41 94 479 minecraft:bookshelf
setblock 41 94 486 minecraft:bookshelf
setblock 41 94 493 minecraft:bookshelf
setblock 41 94 500 minecraft:bookshelf
setblock 42 94 482 minecraft:dark_oak_planks
setblock 42 94 491 minecraft:dark_oak_planks
fill 0 95 463 0 95 474 minecraft:bookshelf
setblock 0 95 475 minecraft:dark_oak_planks
fill 0 95 476 0 95 483 minecraft:bookshelf
setblock 0 95 484 minecraft:dark_oak_planks
fill 0 95 485 0 197 490 minecraft:bookshelf
fill 0 95 491 0 96 491 minecraft:dark_oak_planks
fill 0 95 492 0 95 504 minecraft:bookshelf
setblock 0 95 505 minecraft:dark_oak_planks
fill 1 95 463 3 96 463 minecraft:bookshelf
setblock 1 95 466 minecraft:bookshelf
setblock 1 95 480 minecraft:bookshelf
setblock 1 95 487 minecraft:bookshelf
setblock 1 95 494 minecraft:bookshelf
setblock 1 95 501 minecraft:bookshelf
fill 2 95 505 9 95 505 minecraft:bookshelf
fill 5 95 463 7 198 463 minecraft:bookshelf
setblock 5 95 504 minecraft:bookshelf
setblock 6 95 464 minecraft:bookshelf
fill 6 95 495 6 96 495 minecraft:bookshelf
fill 6 95 497 6 96 497 minecraft:bookshelf
fill 6 95 499 6 96 499 minecraft:bookshelf
fill 6 95 501 6 96 501 minecraft:bookshelf
fill 6 95 503 6 96 503 minecraft:bookshelf
fill 7 95 494 7 96 494 minecraft:bookshelf
fill 7 95 496 7 96 496 minecraft:bookshelf
fill 7 95 498 7 96 498 minecraft:bookshelf
fill 7 95 500 7 96 500 minecraft:bookshelf
fill 7 95 502 7 96 502 minecraft:bookshelf
fill 7 95 504 7 96 504 minecraft:bookshelf
fill 8 95 495 8 96 495 minecraft:bookshelf
fill 8 95 497 8 96 497 minecraft:bookshelf
fill 8 95 499 8 96 499 minecraft:bookshelf
fill 8 95 501 8 96 501 minecraft:bookshelf
fill 8 95 503 8 96 503 minecraft:bookshelf
fill 9 95 463 30 95 463 minecraft:bookshelf
fill 9 95 494 9 96 494 minecraft:bookshelf
fill 9 95 496 9 96 496 minecraft:bookshelf
fill 9 95 498 9 96 498 minecraft:bookshelf
fill 9 95 500 9 96 500 minecraft:bookshelf
fill 9 95 502 9 96 502 minecraft:bookshelf
fill 9 95 504 9 96 504 minecraft:bookshelf
fill 10 95 495 10 96 495 minecraft:bookshelf
fill 10 95 497 10 96 497 minecraft:bookshelf
fill 10 95 499 10 96 499 minecraft:bookshelf
fill 10 95 501 10 96 501 minecraft:bookshelf
fill 10 95 503 10 96 503 minecraft:bookshelf
fill 10 95 505 11 95 505 minecraft:dark_oak_planks
fill 11 95 494 11 96 494 minecraft:bookshelf
fill 11 95 496 11 96 496 minecraft:bookshelf
fill 11 95 498 11 96 498 minecraft:bookshelf
fill 11 95 500 11 96 500 minecraft:bookshelf
fill 11 95 502 11 96 502 minecraft:bookshelf
fill 11 95 504 11 96 504 minecraft:bookshelf
fill 12 95 495 12 96 495 minecraft:bookshelf
fill 12 95 497 12 96 497 minecraft:bookshelf
fill 12 95 499 12 96 499 minecraft:bookshelf
fill 12 95 501 12 96 501 minecraft:bookshelf
fill 12 95 503 12 96 503 minecraft:bookshelf
fill 12 95 505 19 95 505 minecraft:bookshelf
setblock 13 95 464 minecraft:bookshelf
fill 17 95 502 17 96 504 minecraft:bookshelf
fill 18 95 502 19 95 503 minecraft:bookshelf
setblock 19 95 504 minecraft:bookshelf
setblock 20 95 464 minecraft:bookshelf
fill 20 95 505 20 96 505 minecraft:dark_oak_planks
fill 21 95 505 33 96 505 minecraft:bookshelf
setblock 26 95 504 minecraft:bookshelf
setblock 27 95 464 minecraft:bookshelf
setblock 31 95 463 minecraft:dark_oak_planks
fill 32 95 463 33 96 463 minecraft:bookshelf
setblock 33 95 504 minecraft:bookshelf
fill 34 95 463 34 96 463 minecraft:dark_oak_planks
setblock 34 95 464 minecraft:bookshelf
fill 35 95 463 41 197 463 minecraft:bookshelf
fill 36 95 505 36 201 505 minecraft:bookshelf
setblock 37 95 505 minecraft:dark_oak_planks
fill 38 95 505 41 197 505 minecraft:bookshelf
setblock 40 95 504 minecraft:bookshelf
fill 41 95 464 42 95 464 minecraft:bookshelf
fill 41 95 471 42 95 471 minecraft:bookshelf
fill 41 95 478 42 95 478 minecraft:bookshelf
fill 41 95 485 42 95 485 minecraft:bookshelf
fill 41 95 492 42 95 492 minecraft:bookshelf
fill 41 95 499 42 95 499 minecraft:bookshelf
setblock 42 95 463 minecraft:dark_oak_planks
fill 42 95 465 42 198 470 minecraft:bookshelf
fill 42 95 472 42 95 476 minecraft:bookshelf
setblock 42 95 477 minecraft:dark_oak_planks
fill 42 95 479 42 201 484 minecraft:bookshelf
fill 42 95 486 42 95 489 minecraft:bookshelf
fill 42 95 491 42 199 491 minecraft:bookshelf
fill 42 95 493 42 95 498 minecraft:bookshelf
fill 42 95 500 42 96 504 minecraft:bookshelf
setblock 42 95 505 minecraft:dark_oak_planks
fill 0 96 463 0 197 467 minecraft:bookshelf
setblock 0 96 468 minecraft:dark_oak_planks
fill 0 96 469 0 197 475 minecraft:bookshelf
fill 0 96 476 0 97 476 minecraft:dark_oak_planks
fill 0 96 477 0 96 484 minecraft:bookshelf
fill 0 96 492 0 96 498 minecraft:bookshelf
setblock 0 96 499 minecraft:dark_oak_planks
fill 0 96 500 0 197 505 minecraft:bookshelf
setblock 1 96 467 minecraft:bookshelf
setblock 1 96 481 minecraft:bookshelf
setblock 1 96 488 minecraft:bookshelf
setblock 1 96 495 minecraft:bookshelf
setblock 1 96 502 minecraft:bookshelf
fill 1 96 505 5 201 505 minecraft:bookshelf
setblock 4 96 463 minecraft:bookshelf
setblock 5 96 464 minecraft:bookshelf
setblock 6 96 505 minecraft:dark_oak_planks
fill 7 96 505 8 197 505 minecraft:bookshelf
fill 8 96 463 10 96 463 minecraft:bookshelf
setblock 9 96 505 minecraft:dark_oak_planks
fill 10 96 505 12 96 505 minecraft:bookshelf
fill 11 96 463 12 96 463 minecraft:dark_oak_planks
setblock 12 96 464 minecraft:bookshelf
fill 13 96 463 15 96 463 minecraft:bookshelf
fill 13 96 504 14 97 504 minecraft:bookshelf
setblock 13 96 505 minecraft:dark_oak_planks
fill 14 96 502 16 96 503 minecraft:bookshelf
fill 14 96 505 18 198 505 minecraft:bookshelf
setblock 16 96 463 minecraft:dark_oak_planks
setblock 16 96 504 minecraft:bookshelf
fill 17 96 463 24 96 463 minecraft:bookshelf
fill 18 96 502 18 96 503 minecraft:bookshelf
setblock 19 96 464 minecraft:bookshelf
setblock 19 96 505 minecraft:dark_oak_planks
setblock 20 96 504 minecraft:bookshelf
setblock 25 96 463 minecraft:dark_oak_planks
fill 26 96 463 26 96 464 minecraft:bookshelf
fill 27 96 463 31 199 463 minecraft:bookshelf
setblock 27 96 504 minecraft:bookshelf
setblock 33 96 464 minecraft:bookshelf
fill 34 96 504 34 96 505 minecraft:bookshelf
fill 35 96 505 35 198 505 minecraft:bookshelf
fill 37 96 505 37 197 505 minecraft:bookshelf
setblock 40 96 464 minecraft:bookshelf
setblock 41 96 470 minecraft:bookshelf
fill 41 96 477 42 96 477 minecraft:bookshelf
setblock 41 96 484 minecraft:bookshelf
setblock 41 96 491 minecraft:bookshelf
fill 41 96 498 42 96 498 minecraft:bookshelf
setblock 41 96 504 minecraft:bookshelf
fill 42 96 463 42 197 464 minecraft:bookshelf
setblock 42 96 471 minecraft:dark_oak_planks
fill 42 96 472 42 96 474 minecraft:bookshelf
setblock 42 96 475 minecraft:dark_oak_planks
fill 42 96 476 42 201 476 minecraft:bookshelf
fill 42 96 478 42 201 478 minecraft:bookshelf
fill 42 96 485 42 201 486 minecraft:bookshelf
fill 42 96 487 42 97 487 minecraft:dark_oak_planks
fill 42 96 488 42 96 490 minecraft:bookshelf
fill 42 96 492 42 201 494 minecraft:bookshelf
setblock 42 96 495 minecraft:dark_oak_planks
fill 42 96 496 42 96 497 minecraft:bookshelf
fill 42 96 499 42 197 499 minecraft:bookshelf
fill 42 96 505 42 202 505 minecraft:bookshelf
fill 0 97 468 1 97 468 minecraft:bookshelf
fill 0 97 477 0 201 477 minecraft:bookshelf
setblock 0 97 478 minecraft:dark_oak_planks
fill 0 97 479 0 197 480 minecraft:bookshelf
setblock 0 97 481 minecraft:dark_oak_planks
fill 0 97 482 0 201 484 minecraft:bookshelf
fill 0 97 491 0 197 492 minecraft:bookshelf
setblock 0 97 493 minecraft:dark_oak_planks
fill 0 97 494 0 198 499 minecraft:bookshelf
fill 1 97 463 1 198 463 minecraft:bookshelf
setblock 1 97 482 minecraft:bookshelf
setblock 1 97 489 minecraft:bookshelf
setblock 1 97 496 minecraft:bookshelf
setblock 1 97 503 minecraft:bookshelf
setblock 2 97 463 minecraft:dark_oak_planks
fill 3 97 463 3 197 463 minecraft:bookshelf
setblock 4 97 463 minecraft:dark_oak_planks
setblock 4 97 464 minecraft:bookshelf
setblock 6 97 495 minecraft:ochre_froglight
setblock 6 97 497 minecraft:ochre_froglight
setblock 6 97 499 minecraft:ochre_froglight
setblock 6 97 501 minecraft:ochre_froglight
setblock 6 97 503 minecraft:ochre_froglight
fill 6 97 505 6 201 505 minecraft:bookshelf
setblock 7 97 494 minecraft:ochre_froglight
setblock 7 97 496 minecraft:ochre_froglight
setblock 7 97 498 minecraft:ochre_froglight
setblock 7 97 500 minecraft:ochre_froglight
setblock 7 97 502 minecraft:ochre_froglight
setblock 7 97 504 minecraft:ochre_froglight
fill 8 97 463 9 197 463 minecraft:bookshelf
setblock 8 97 495 minecraft:ochre_froglight
setblock 8 97 497 minecraft:ochre_froglight
setblock 8 97 499 minecraft:ochre_froglight
setblock 8 97 501 minecraft:ochre_froglight
setblock 8 97 503 minecraft:ochre_froglight
setblock 9 97 494 minecraft:ochre_froglight
setblock 9 97 496 minecraft:ochre_froglight
setblock 9 97 498 minecraft:ochre_froglight
setblock 9 97 500 minecraft:ochre_froglight
setblock 9 97 502 minecraft:ochre_froglight
setblock 9 97 504 minecraft:ochre_froglight
fill 9 97 505 9 199 505 minecraft:bookshelf
setblock 10 97 463 minecraft:dark_oak_planks
setblock 10 97 495 minecraft:ochre_froglight
setblock 10 97 497 minecraft:ochre_froglight
setblock 10 97 499 minecraft:ochre_froglight
setblock 10 97 501 minecraft:ochre_froglight
setblock 10 97 503 minecraft:ochre_froglight
setblock 10 97 505 minecraft:dark_oak_planks
fill 11 97 463 11 97 464 minecraft:bookshelf
setblock 11 97 494 minecraft:ochre_froglight
setblock 11 97 496 minecraft:ochre_froglight
setblock 11 97 498 minecraft:ochre_froglight
setblock 11 97 500 minecraft:ochre_froglight
setblock 11 97 502 minecraft:ochre_froglight
setblock 11 97 504 minecraft:ochre_froglight
fill 11 97 505 13 201 505 minecraft:bookshelf
fill 12 97 463 14 201 463 minecraft:bookshelf
setblock 12 97 495 minecraft:ochre_froglight
setblock 12 97 497 minecraft:ochre_froglight
setblock 12 97 499 minecraft:ochre_froglight
setblock 12 97 501 minecraft:ochre_froglight
setblock 12 97 503 minecraft:ochre_froglight
fill 13 97 502 15 97 503 minecraft:bookshelf
setblock 15 97 463 minecraft:dark_oak_planks
fill 16 97 463 21 198 463 minecraft:bookshelf
setblock 18 97 464 minecraft:bookshelf
fill 19 97 505 20 197 505 minecraft:bookshelf
setblock 21 97 504 minecraft:bookshelf
setblock 21 97 505 minecraft:dark_oak_planks
setblock 22 97 463 minecraft:dark_oak_planks
fill 22 97 505 34 197 505 minecraft:bookshelf
fill 23 97 463 26 197 463 minecraft:bookshelf
setblock 25 97 464 minecraft:bookshelf
setblock 28 97 504 minecraft:bookshelf
setblock 32 97 463 minecraft:dark_oak_planks
setblock 32 97 464 minecraft:bookshelf
fill 33 97 463 34 197 463 minecraft:bookshelf
setblock 35 97 504 minecraft:bookshelf
setblock 39 97 464 minecraft:bookshelf
setblock 41 97 469 minecraft:bookshelf
setblock 41 97 476 minecraft:bookshelf
setblock 41 97 483 minecraft:bookshelf
fill 41 97 490 42 97 490 minecraft:bookshelf
fill 41 97 497 42 97 497 minecraft:bookshelf
fill 42 97 471 42 197 473 minecraft:bookshelf
setblock 42 97 474 minecraft:dark_oak_planks
fill 42 97 475 42 201 475 minecraft:bookshelf
fill 42 97 477 42 201 477 minecraft:bookshelf
fill 42 97 488 42 197 488 minecraft:bookshelf
setblock 42 97 489 minecraft:dark_oak_planks
fill 42 97 495 42 201 495 minecraft:bookshelf
setblock 42 97 496 minecraft:dark_oak_planks
fill 42 97 498 42 199 498 minecraft:bookshelf
fill 42 97 500 42 201 500 minecraft:bookshelf
setblock 42 97 501 minecraft:dark_oak_planks
fill 42 97 502 42 201 502 minecraft:bookshelf
setblock 42 97 503 minecraft:dark_oak_planks
fill 42 97 504 42 201 504 minecraft:bookshelf
fill 0 98 468 0 201 468 minecraft:bookshelf
fill 0 98 476 0 199 476 minecraft:bookshelf
fill 0 98 478 0 201 478 minecraft:bookshelf
fill 0 98 481 0 201 481 minecraft:bookshelf
fill 0 98 493 0 201 493 minecraft:bookshelf
fill 2 98 463 2 201 463 minecraft:bookshelf
fill 4 98 463 4 201 463 minecraft:bookshelf
fill 4 98 504 5 100 504 minecraft:bookshelf
fill 5 98 503 6 99 503 minecraft:bookshelf
fill 6 98 495 6 99 495 minecraft:bookshelf
fill 6 98 497 6 99 497 minecraft:bookshelf
fill 6 98 499 6 99 499 minecraft:bookshelf
fill 6 98 501 6 99 501 minecraft:bookshelf
fill 7 98 494 7 99 494 minecraft:bookshelf
fill 7 98 496 7 99 496 minecraft:bookshelf
fill 7 98 498 7 99 498 minecraft:bookshelf
fill 7 98 500 7 99 500 minecraft:bookshelf
fill 7 98 502 7 99 502 minecraft:bookshelf
fill 7 98 504 7 99 504 minecraft:bookshelf
fill 8 98 495 8 99 495 minecraft:bookshelf
schedule function dropper:buildpart/108_2 1t
