setblock 182 76 334 minecraft:dark_prismarine
fill 182 76 335 182 79 335 minecraft:blue_terracotta
setblock 182 76 338 minecraft:blue_terracotta
setblock 182 76 344 minecraft:purple_concrete
setblock 182 76 354 minecraft:dark_prismarine
fill 182 76 355 182 79 355 minecraft:blue_terracotta
setblock 182 76 359 minecraft:dark_prismarine
fill 182 76 360 182 79 360 minecraft:blue_terracotta
fill 182 76 362 182 76 363 minecraft:blue_terracotta
setblock 141 77 329 minecraft:light_blue_wool
fill 141 77 357 141 125 359 minecraft:black_concrete
setblock 141 77 360 minecraft:cyan_concrete
fill 141 77 361 141 77 362 minecraft:black_concrete
setblock 142 77 322 minecraft:light_blue_wool
setblock 142 77 323 minecraft:purple_concrete
setblock 142 77 333 minecraft:dark_prismarine
fill 142 77 334 142 80 334 minecraft:blue_terracotta
setblock 142 77 337 minecraft:blue_terracotta
setblock 142 77 348 minecraft:purple_concrete
setblock 142 77 353 minecraft:dark_prismarine
fill 142 77 354 142 77 357 minecraft:blue_terracotta
setblock 142 77 358 minecraft:dark_prismarine
fill 142 77 359 142 80 359 minecraft:blue_terracotta
setblock 142 77 362 minecraft:blue_terracotta
setblock 142 77 363 minecraft:dark_prismarine
setblock 143 77 352 minecraft:dark_prismarine
fill 143 77 353 143 80 353 minecraft:blue_terracotta
setblock 143 77 356 minecraft:blue_terracotta
setblock 143 77 357 minecraft:dark_prismarine
fill 143 77 358 143 80 358 minecraft:blue_terracotta
setblock 143 77 362 minecraft:dark_prismarine
fill 143 77 363 143 80 363 minecraft:blue_terracotta
setblock 144 77 325 minecraft:light[level=13]
setblock 144 77 332 minecraft:light[level=12]
setblock 144 77 333 minecraft:light[level=13]
setblock 144 77 339 minecraft:light[level=12]
setblock 144 77 341 minecraft:light[level=13]
setblock 144 77 346 minecraft:light[level=12]
setblock 144 77 349 minecraft:light[level=13]
setblock 144 77 352 minecraft:blue_terracotta
setblock 144 77 356 minecraft:dark_prismarine
fill 144 77 357 144 80 357 minecraft:blue_terracotta
setblock 144 77 360 minecraft:blue_terracotta
setblock 144 77 361 minecraft:dark_prismarine
fill 144 77 362 144 80 362 minecraft:blue_terracotta
fill 145 77 349 145 102 349 minecraft:magenta_terracotta
setblock 145 77 355 minecraft:dark_prismarine
fill 145 77 356 145 80 356 minecraft:blue_terracotta
setblock 145 77 359 minecraft:blue_terracotta
fill 145 77 361 145 80 361 minecraft:blue_terracotta
fill 146 77 324 146 86 324 minecraft:iron_bars
fill 146 77 360 146 80 360 minecraft:blue_terracotta
setblock 147 77 323 minecraft:dark_prismarine
setblock 147 77 363 minecraft:dark_prismarine
fill 148 77 323 148 79 323 minecraft:blue_terracotta
fill 148 77 360 149 77 360 minecraft:blue_terracotta
setblock 148 77 362 minecraft:dark_prismarine
fill 148 77 363 148 80 363 minecraft:blue_terracotta
setblock 149 77 361 minecraft:dark_prismarine
fill 149 77 362 149 80 362 minecraft:blue_terracotta
setblock 150 77 360 minecraft:dark_prismarine
fill 150 77 361 150 80 361 minecraft:blue_terracotta
setblock 151 77 325 minecraft:light[level=12]
setblock 151 77 332 minecraft:light[level=12]
setblock 151 77 339 minecraft:light[level=12]
setblock 151 77 346 minecraft:light[level=12]
setblock 151 77 353 minecraft:light[level=12]
setblock 151 77 360 minecraft:light[level=12]
setblock 152 77 325 minecraft:light[level=13]
setblock 152 77 333 minecraft:light[level=13]
setblock 152 77 341 minecraft:light[level=13]
setblock 152 77 349 minecraft:light[level=13]
setblock 152 77 357 minecraft:light[level=13]
setblock 152 77 363 minecraft:dark_prismarine
setblock 153 77 323 minecraft:purple_concrete
setblock 153 77 362 minecraft:dark_prismarine
fill 153 77 363 153 80 363 minecraft:blue_terracotta
setblock 158 77 325 minecraft:light[level=12]
setblock 158 77 332 minecraft:light[level=12]
setblock 158 77 339 minecraft:light[level=12]
setblock 158 77 346 minecraft:light[level=12]
setblock 158 77 353 minecraft:light[level=12]
setblock 158 77 360 minecraft:light[level=12]
setblock 160 77 325 minecraft:light[level=13]
setblock 160 77 333 minecraft:light[level=13]
setblock 160 77 341 minecraft:light[level=13]
setblock 160 77 349 minecraft:light[level=13]
setblock 165 77 325 minecraft:light[level=12]
setblock 165 77 332 minecraft:light[level=12]
setblock 165 77 339 minecraft:light[level=12]
setblock 165 77 346 minecraft:light[level=12]
setblock 165 77 353 minecraft:light[level=12]
setblock 165 77 360 minecraft:light[level=12]
setblock 166 77 363 minecraft:blue_terracotta
setblock 167 77 323 minecraft:dark_prismarine
setblock 167 77 363 minecraft:dark_prismarine
fill 168 77 323 168 80 323 minecraft:blue_terracotta
setblock 168 77 325 minecraft:light[level=13]
setblock 168 77 333 minecraft:light[level=13]
setblock 168 77 341 minecraft:light[level=13]
setblock 168 77 349 minecraft:light[level=13]
setblock 168 77 357 minecraft:light[level=13]
fill 168 77 363 171 77 363 minecraft:blue_terracotta
setblock 171 77 324 minecraft:dark_prismarine
setblock 172 77 323 minecraft:dark_prismarine
setblock 172 77 324 minecraft:blue_terracotta
setblock 172 77 325 minecraft:light[level=12]
setblock 172 77 332 minecraft:light[level=12]
setblock 172 77 339 minecraft:light[level=12]
setblock 172 77 346 minecraft:light[level=12]
setblock 172 77 353 minecraft:light[level=12]
setblock 172 77 360 minecraft:light[level=12]
setblock 172 77 363 minecraft:dark_prismarine
fill 173 77 323 173 80 323 minecraft:blue_terracotta
fill 173 77 363 173 80 363 minecraft:blue_terracotta
setblock 176 77 325 minecraft:light[level=13]
setblock 176 77 333 minecraft:light[level=13]
setblock 176 77 341 minecraft:light[level=13]
setblock 176 77 357 minecraft:light[level=13]
setblock 177 77 323 minecraft:dark_prismarine
fill 177 77 349 177 93 349 minecraft:magenta_terracotta
setblock 179 77 325 minecraft:light[level=12]
setblock 179 77 332 minecraft:light[level=12]
setblock 179 77 339 minecraft:light[level=12]
setblock 179 77 346 minecraft:light[level=12]
setblock 179 77 353 minecraft:light[level=12]
setblock 179 77 360 minecraft:light[level=12]
setblock 181 77 330 minecraft:blue_terracotta
setblock 181 77 334 minecraft:dark_prismarine
setblock 181 77 335 minecraft:blue_terracotta
setblock 181 77 363 minecraft:blue_terracotta
setblock 182 77 323 minecraft:dark_prismarine
fill 182 77 324 182 80 324 minecraft:blue_terracotta
setblock 182 77 328 minecraft:dark_prismarine
fill 182 77 329 182 79 329 minecraft:blue_terracotta
setblock 182 77 333 minecraft:dark_prismarine
fill 182 77 334 182 80 334 minecraft:blue_terracotta
setblock 182 77 338 minecraft:dark_prismarine
setblock 182 77 353 minecraft:dark_prismarine
fill 182 77 354 182 80 354 minecraft:blue_terracotta
setblock 182 77 357 minecraft:blue_terracotta
setblock 182 77 358 minecraft:dark_prismarine
fill 182 77 359 182 80 359 minecraft:blue_terracotta
setblock 182 77 362 minecraft:blue_terracotta
setblock 182 77 363 minecraft:dark_prismarine
setblock 183 77 362 minecraft:light_blue_wool
fill 141 78 329 141 131 329 minecraft:black_concrete
fill 141 78 360 141 83 360 minecraft:black_concrete
setblock 141 78 361 minecraft:light_blue_wool
fill 141 78 362 141 127 362 minecraft:black_concrete
fill 142 78 322 142 93 322 minecraft:black_concrete
setblock 142 78 329 minecraft:purple_concrete
setblock 142 78 332 minecraft:dark_prismarine
fill 142 78 333 142 79 333 minecraft:blue_terracotta
setblock 142 78 337 minecraft:dark_prismarine
fill 142 78 338 142 81 338 minecraft:blue_terracotta
setblock 142 78 352 minecraft:dark_prismarine
fill 142 78 353 142 78 356 minecraft:blue_terracotta
setblock 142 78 357 minecraft:dark_prismarine
fill 142 78 358 142 81 358 minecraft:blue_terracotta
setblock 142 78 361 minecraft:blue_terracotta
setblock 142 78 362 minecraft:dark_prismarine
fill 142 78 363 142 81 363 minecraft:blue_terracotta
setblock 143 78 351 minecraft:dark_prismarine
fill 143 78 352 143 80 352 minecraft:blue_terracotta
setblock 143 78 356 minecraft:dark_prismarine
fill 143 78 357 143 81 357 minecraft:blue_terracotta
setblock 143 78 361 minecraft:dark_prismarine
fill 143 78 362 143 81 362 minecraft:blue_terracotta
setblock 144 78 354 minecraft:blue_terracotta
setblock 144 78 355 minecraft:dark_prismarine
fill 144 78 356 144 81 356 minecraft:blue_terracotta
setblock 144 78 360 minecraft:dark_prismarine
fill 144 78 361 144 81 361 minecraft:blue_terracotta
setblock 145 78 354 minecraft:dark_prismarine
fill 145 78 355 145 79 355 minecraft:blue_terracotta
setblock 145 78 359 minecraft:dark_prismarine
fill 145 78 360 145 81 360 minecraft:blue_terracotta
setblock 146 78 323 minecraft:dark_prismarine
setblock 146 78 363 minecraft:dark_prismarine
fill 147 78 323 147 80 323 minecraft:blue_terracotta
setblock 147 78 362 minecraft:dark_prismarine
fill 147 78 363 147 81 363 minecraft:blue_terracotta
setblock 148 78 360 minecraft:blue_terracotta
setblock 148 78 361 minecraft:dark_prismarine
fill 148 78 362 148 81 362 minecraft:blue_terracotta
setblock 149 78 360 minecraft:dark_prismarine
fill 149 78 361 149 81 361 minecraft:blue_terracotta
setblock 150 78 360 minecraft:blue_terracotta
setblock 151 78 363 minecraft:dark_prismarine
setblock 152 78 362 minecraft:dark_prismarine
fill 152 78 363 152 81 363 minecraft:blue_terracotta
setblock 153 78 362 minecraft:blue_terracotta
setblock 158 78 363 minecraft:purple_concrete
setblock 166 78 323 minecraft:dark_prismarine
setblock 166 78 363 minecraft:dark_prismarine
fill 167 78 323 167 81 323 minecraft:blue_terracotta
fill 167 78 363 170 78 363 minecraft:blue_terracotta
setblock 169 78 322 minecraft:cyan_concrete
fill 169 78 362 170 78 362 minecraft:blue_terracotta
fill 170 78 322 170 131 322 minecraft:black_concrete
setblock 170 78 324 minecraft:dark_prismarine
setblock 171 78 323 minecraft:dark_prismarine
setblock 171 78 324 minecraft:blue_terracotta
setblock 171 78 363 minecraft:dark_prismarine
fill 172 78 323 172 81 323 minecraft:blue_terracotta
fill 172 78 363 172 81 363 minecraft:blue_terracotta
fill 174 78 363 174 79 363 minecraft:blue_terracotta
setblock 176 78 323 minecraft:dark_prismarine
setblock 177 78 363 minecraft:purple_concrete
setblock 180 78 363 minecraft:blue_terracotta
setblock 181 78 323 minecraft:dark_prismarine
setblock 181 78 333 minecraft:dark_prismarine
setblock 181 78 334 minecraft:blue_terracotta
setblock 181 78 358 minecraft:dark_prismarine
setblock 181 78 363 minecraft:dark_prismarine
fill 182 78 323 182 81 323 minecraft:blue_terracotta
setblock 182 78 327 minecraft:dark_prismarine
fill 182 78 328 182 79 328 minecraft:blue_terracotta
setblock 182 78 332 minecraft:dark_prismarine
fill 182 78 333 182 81 333 minecraft:blue_terracotta
setblock 182 78 337 minecraft:dark_prismarine
fill 182 78 338 182 81 338 minecraft:blue_terracotta
setblock 182 78 351 minecraft:purple_concrete
fill 182 78 353 182 79 353 minecraft:blue_terracotta
setblock 182 78 357 minecraft:dark_prismarine
fill 182 78 358 182 81 358 minecraft:blue_terracotta
setblock 182 78 362 minecraft:dark_prismarine
fill 182 78 363 182 81 363 minecraft:blue_terracotta
setblock 183 78 362 minecraft:black_concrete
fill 141 79 361 141 127 361 minecraft:black_concrete
setblock 142 79 335 minecraft:blue_terracotta
setblock 142 79 336 minecraft:dark_prismarine
fill 142 79 337 142 82 337 minecraft:blue_terracotta
fill 142 79 339 142 80 339 minecraft:blue_terracotta
setblock 142 79 341 minecraft:purple_concrete
setblock 142 79 351 minecraft:dark_prismarine
fill 142 79 352 142 79 355 minecraft:blue_terracotta
setblock 142 79 356 minecraft:dark_prismarine
fill 142 79 357 142 82 357 minecraft:blue_terracotta
setblock 142 79 361 minecraft:dark_prismarine
fill 142 79 362 142 82 362 minecraft:blue_terracotta
setblock 143 79 355 minecraft:dark_prismarine
fill 143 79 356 143 82 356 minecraft:blue_terracotta
setblock 143 79 360 minecraft:dark_prismarine
fill 143 79 361 143 82 361 minecraft:blue_terracotta
setblock 144 79 354 minecraft:dark_prismarine
fill 144 79 355 144 82 355 minecraft:blue_terracotta
setblock 144 79 358 minecraft:blue_terracotta
setblock 144 79 359 minecraft:dark_prismarine
fill 144 79 360 144 82 360 minecraft:blue_terracotta
setblock 145 79 323 minecraft:dark_prismarine
setblock 145 79 358 minecraft:dark_prismarine
fill 145 79 359 145 82 359 minecraft:blue_terracotta
setblock 145 79 363 minecraft:dark_prismarine
fill 146 79 323 146 82 323 minecraft:blue_terracotta
setblock 146 79 362 minecraft:dark_prismarine
fill 146 79 363 146 82 363 minecraft:blue_terracotta
setblock 147 79 361 minecraft:dark_prismarine
fill 147 79 362 147 82 362 minecraft:blue_terracotta
setblock 148 79 360 minecraft:dark_prismarine
fill 148 79 361 148 82 361 minecraft:blue_terracotta
setblock 149 79 360 minecraft:blue_terracotta
setblock 150 79 363 minecraft:dark_prismarine
setblock 151 79 362 minecraft:dark_prismarine
fill 151 79 363 151 82 363 minecraft:blue_terracotta
setblock 152 79 362 minecraft:blue_terracotta
setblock 160 79 323 minecraft:purple_concrete
fill 164 79 331 164 102 331 minecraft:magenta_terracotta
setblock 164 79 363 minecraft:purple_concrete
setblock 165 79 323 minecraft:dark_prismarine
setblock 165 79 363 minecraft:dark_prismarine
fill 166 79 323 166 82 323 minecraft:blue_terracotta
fill 166 79 363 169 79 363 minecraft:blue_terracotta
fill 168 79 362 169 80 362 minecraft:blue_terracotta
fill 169 79 322 169 131 322 minecraft:black_concrete
setblock 169 79 324 minecraft:dark_prismarine
setblock 170 79 323 minecraft:dark_prismarine
setblock 170 79 363 minecraft:dark_prismarine
fill 171 79 323 171 82 323 minecraft:blue_terracotta
fill 171 79 363 171 82 363 minecraft:blue_terracotta
setblock 175 79 323 minecraft:dark_prismarine
fill 178 79 350 178 82 350 minecraft:magenta_terracotta
fill 179 79 342 179 86 342 minecraft:dark_prismarine
setblock 180 79 363 minecraft:dark_prismarine
fill 181 79 323 181 82 323 minecraft:blue_terracotta
fill 181 79 358 181 80 360 minecraft:blue_terracotta
fill 181 79 363 181 82 363 minecraft:blue_terracotta
setblock 182 79 326 minecraft:purple_concrete
setblock 182 79 331 minecraft:dark_prismarine
fill 182 79 332 182 81 332 minecraft:blue_terracotta
setblock 182 79 336 minecraft:dark_prismarine
fill 182 79 337 182 82 337 minecraft:blue_terracotta
fill 182 79 339 182 80 339 minecraft:blue_terracotta
setblock 182 79 345 minecraft:purple_concrete
setblock 182 79 356 minecraft:dark_prismarine
fill 182 79 357 182 82 357 minecraft:blue_terracotta
setblock 182 79 361 minecraft:dark_prismarine
fill 182 79 362 182 82 362 minecraft:blue_terracotta
setblock 183 79 362 minecraft:light_blue_wool
setblock 142 80 335 minecraft:dark_prismarine
fill 142 80 336 142 83 336 minecraft:blue_terracotta
setblock 142 80 340 minecraft:dark_prismarine
setblock 142 80 347 minecraft:purple_concrete
fill 142 80 351 142 80 354 minecraft:blue_terracotta
setblock 142 80 355 minecraft:dark_prismarine
fill 142 80 356 142 83 356 minecraft:blue_terracotta
setblock 142 80 360 minecraft:dark_prismarine
fill 142 80 361 142 83 361 minecraft:blue_terracotta
setblock 143 80 354 minecraft:dark_prismarine
fill 143 80 355 143 83 355 minecraft:blue_terracotta
setblock 143 80 359 minecraft:dark_prismarine
fill 143 80 360 143 83 360 minecraft:blue_terracotta
fill 144 80 347 145 81 348 minecraft:dark_prismarine
fill 144 80 354 144 81 354 minecraft:blue_terracotta
setblock 144 80 358 minecraft:dark_prismarine
fill 144 80 359 144 83 359 minecraft:blue_terracotta
setblock 144 80 363 minecraft:dark_prismarine
fill 145 80 323 145 83 323 minecraft:blue_terracotta
setblock 145 80 357 minecraft:dark_prismarine
fill 145 80 358 145 82 358 minecraft:blue_terracotta
setblock 145 80 362 minecraft:dark_prismarine
fill 145 80 363 145 83 363 minecraft:blue_terracotta
setblock 146 80 361 minecraft:dark_prismarine
fill 146 80 362 146 83 362 minecraft:blue_terracotta
setblock 147 80 360 minecraft:dark_prismarine
fill 147 80 361 147 83 361 minecraft:blue_terracotta
setblock 148 80 360 minecraft:blue_terracotta
setblock 149 80 363 minecraft:dark_prismarine
setblock 150 80 362 minecraft:dark_prismarine
fill 150 80 363 150 83 363 minecraft:blue_terracotta
fill 151 80 362 151 81 362 minecraft:blue_terracotta
setblock 154 80 323 minecraft:purple_concrete
fill 160 80 358 160 102 358 minecraft:magenta_terracotta
fill 162 80 356 162 92 357 minecraft:magenta_terracotta
setblock 163 80 356 minecraft:magenta_terracotta
setblock 164 80 363 minecraft:dark_prismarine
fill 165 80 323 165 83 323 minecraft:blue_terracotta
fill 165 80 363 168 80 363 minecraft:blue_terracotta
setblock 169 80 323 minecraft:dark_prismarine
setblock 169 80 363 minecraft:dark_prismarine
fill 170 80 323 170 83 323 minecraft:blue_terracotta
fill 170 80 363 170 83 363 minecraft:blue_terracotta
setblock 174 80 323 minecraft:dark_prismarine
setblock 179 80 323 minecraft:purple_concrete
setblock 179 80 363 minecraft:dark_prismarine
fill 180 80 363 180 83 363 minecraft:blue_terracotta
setblock 181 80 361 minecraft:dark_prismarine
fill 181 80 362 181 83 362 minecraft:blue_terracotta
setblock 182 80 330 minecraft:dark_prismarine
setblock 182 80 331 minecraft:blue_terracotta
setblock 182 80 335 minecraft:dark_prismarine
fill 182 80 336 182 83 336 minecraft:blue_terracotta
setblock 182 80 355 minecraft:dark_prismarine
fill 182 80 356 182 83 356 minecraft:blue_terracotta
setblock 182 80 360 minecraft:dark_prismarine
fill 182 80 361 182 83 361 minecraft:blue_terracotta
fill 183 80 362 183 131 362 minecraft:black_concrete
setblock 142 81 328 minecraft:purple_concrete
fill 142 81 335 142 82 335 minecraft:blue_terracotta
setblock 142 81 339 minecraft:dark_prismarine
fill 142 81 340 142 83 341 minecraft:blue_terracotta
fill 142 81 351 142 81 353 minecraft:blue_terracotta
setblock 142 81 354 minecraft:dark_prismarine
fill 142 81 355 142 84 355 minecraft:blue_terracotta
setblock 142 81 359 minecraft:dark_prismarine
fill 142 81 360 142 84 360 minecraft:blue_terracotta
setblock 143 81 353 minecraft:dark_prismarine
fill 143 81 354 143 84 354 minecraft:blue_terracotta
setblock 143 81 358 minecraft:dark_prismarine
fill 143 81 359 143 84 359 minecraft:blue_terracotta
setblock 143 81 363 minecraft:dark_prismarine
setblock 144 81 357 minecraft:dark_prismarine
fill 144 81 358 144 84 358 minecraft:blue_terracotta
setblock 144 81 362 minecraft:dark_prismarine
fill 144 81 363 144 84 363 minecraft:blue_terracotta
setblock 145 81 357 minecraft:blue_terracotta
setblock 145 81 361 minecraft:dark_prismarine
fill 145 81 362 145 84 362 minecraft:blue_terracotta
setblock 146 81 360 minecraft:dark_prismarine
fill 146 81 361 146 84 361 minecraft:blue_terracotta
setblock 147 81 360 minecraft:blue_terracotta
setblock 148 81 323 minecraft:purple_concrete
setblock 148 81 363 minecraft:dark_prismarine
setblock 149 81 362 minecraft:dark_prismarine
fill 149 81 363 149 84 363 minecraft:blue_terracotta
fill 150 81 362 150 84 362 minecraft:blue_terracotta
fill 164 81 323 164 84 323 minecraft:blue_terracotta
fill 164 81 363 167 81 363 minecraft:blue_terracotta
fill 167 81 362 168 81 362 minecraft:blue_terracotta
setblock 168 81 323 minecraft:dark_prismarine
setblock 168 81 363 minecraft:dark_prismarine
fill 169 81 323 169 84 323 minecraft:blue_terracotta
fill 169 81 363 169 84 363 minecraft:blue_terracotta
setblock 173 81 323 minecraft:dark_prismarine
setblock 173 81 363 minecraft:dark_prismarine
setblock 176 81 363 minecraft:purple_concrete
setblock 178 81 363 minecraft:dark_prismarine
fill 179 81 363 179 84 363 minecraft:blue_terracotta
fill 181 81 358 181 81 359 minecraft:blue_terracotta
setblock 181 81 360 minecraft:dark_prismarine
fill 181 81 361 181 84 361 minecraft:blue_terracotta
setblock 182 81 324 minecraft:dark_prismarine
setblock 182 81 334 minecraft:dark_prismarine
fill 182 81 335 182 84 335 minecraft:blue_terracotta
setblock 182 81 339 minecraft:dark_prismarine
setblock 182 81 354 minecraft:dark_prismarine
fill 182 81 355 182 84 355 minecraft:blue_terracotta
setblock 182 81 359 minecraft:dark_prismarine
fill 182 81 360 182 84 360 minecraft:blue_terracotta
setblock 142 82 334 minecraft:purple_concrete
setblock 142 82 338 minecraft:dark_prismarine
fill 142 82 339 142 85 339 minecraft:blue_terracotta
setblock 142 82 342 minecraft:blue_terracotta
setblock 142 82 343 minecraft:dark_prismarine
fill 142 82 351 142 82 352 minecraft:blue_terracotta
setblock 142 82 353 minecraft:dark_prismarine
fill 142 82 354 142 85 354 minecraft:blue_terracotta
setblock 142 82 358 minecraft:dark_prismarine
fill 142 82 359 142 85 359 minecraft:blue_terracotta
setblock 142 82 363 minecraft:dark_prismarine
setblock 142 82 364 minecraft:cyan_concrete
fill 143 82 353 143 85 353 minecraft:blue_terracotta
setblock 143 82 357 minecraft:dark_prismarine
fill 143 82 358 143 85 358 minecraft:blue_terracotta
setblock 143 82 362 minecraft:dark_prismarine
fill 143 82 363 143 85 363 minecraft:blue_terracotta
fill 144 82 323 144 84 323 minecraft:blue_terracotta
setblock 144 82 356 minecraft:dark_prismarine
fill 144 82 357 144 85 357 minecraft:blue_terracotta
setblock 144 82 361 minecraft:dark_prismarine
fill 144 82 362 144 85 362 minecraft:blue_terracotta
setblock 145 82 360 minecraft:dark_prismarine
fill 145 82 361 145 85 361 minecraft:blue_terracotta
setblock 146 82 360 minecraft:blue_terracotta
setblock 147 82 363 minecraft:dark_prismarine
setblock 148 82 362 minecraft:dark_prismarine
fill 148 82 363 148 85 363 minecraft:blue_terracotta
setblock 149 82 361 minecraft:dark_prismarine
fill 149 82 362 149 85 362 minecraft:blue_terracotta
setblock 152 82 363 minecraft:dark_prismarine
setblock 157 82 363 minecraft:purple_concrete
fill 159 82 356 159 102 356 minecraft:magenta_terracotta
fill 163 82 363 166 82 363 minecraft:blue_terracotta
fill 166 82 362 167 82 362 minecraft:blue_terracotta
setblock 167 82 323 minecraft:dark_prismarine
setblock 167 82 363 minecraft:dark_prismarine
fill 168 82 323 168 85 323 minecraft:blue_terracotta
setblock 168 82 362 minecraft:dark_prismarine
fill 168 82 363 168 85 363 minecraft:blue_terracotta
setblock 172 82 323 minecraft:dark_prismarine
setblock 172 82 363 minecraft:dark_prismarine
fill 173 82 323 173 85 323 minecraft:blue_terracotta
fill 173 82 363 174 84 363 minecraft:blue_terracotta
setblock 177 82 363 minecraft:dark_prismarine
fill 178 82 363 178 85 363 minecraft:blue_terracotta
fill 180 82 323 180 83 323 minecraft:blue_terracotta
fill 180 82 362 180 84 362 minecraft:blue_terracotta
setblock 181 82 358 minecraft:blue_terracotta
setblock 181 82 359 minecraft:dark_prismarine
fill 181 82 360 181 85 360 minecraft:blue_terracotta
setblock 182 82 323 minecraft:dark_prismarine
fill 182 82 324 182 84 325 minecraft:blue_terracotta
setblock 182 82 327 minecraft:purple_concrete
setblock 182 82 334 minecraft:blue_terracotta
setblock 182 82 338 minecraft:dark_prismarine
fill 182 82 339 182 84 340 minecraft:blue_terracotta
setblock 182 82 352 minecraft:purple_concrete
fill 182 82 354 182 85 354 minecraft:blue_terracotta
setblock 182 82 358 minecraft:dark_prismarine
fill 182 82 359 182 85 359 minecraft:blue_terracotta
setblock 182 82 363 minecraft:dark_prismarine
fill 141 83 322 141 128 323 minecraft:black_concrete
setblock 141 83 324 minecraft:cyan_concrete
fill 141 83 325 141 131 325 minecraft:black_concrete
fill 142 83 323 143 85 323 minecraft:blue_terracotta
setblock 142 83 337 minecraft:dark_prismarine
fill 142 83 338 143 85 338 minecraft:blue_terracotta
setblock 142 83 342 minecraft:dark_prismarine
fill 142 83 343 142 83 346 minecraft:blue_terracotta
fill 142 83 350 142 83 351 minecraft:blue_terracotta
setblock 142 83 352 minecraft:dark_prismarine
fill 142 83 353 142 86 353 minecraft:blue_terracotta
setblock 142 83 357 minecraft:dark_prismarine
fill 142 83 358 142 86 358 minecraft:blue_terracotta
setblock 142 83 362 minecraft:dark_prismarine
fill 142 83 363 142 86 363 minecraft:blue_terracotta
fill 142 83 364 142 132 364 minecraft:black_concrete
fill 143 83 339 143 83 340 minecraft:blue_terracotta
setblock 143 83 341 minecraft:dark_prismarine
fill 143 83 342 143 86 342 minecraft:blue_terracotta
setblock 143 83 356 minecraft:dark_prismarine
fill 143 83 357 143 86 357 minecraft:blue_terracotta
setblock 143 83 361 minecraft:dark_prismarine
fill 143 83 362 143 86 362 minecraft:blue_terracotta
setblock 144 83 325 minecraft:light[level=12]
setblock 144 83 332 minecraft:light[level=12]
setblock 144 83 339 minecraft:light[level=12]
setblock 144 83 346 minecraft:light[level=12]
setblock 144 83 353 minecraft:light[level=12]
setblock 144 83 355 minecraft:dark_prismarine
fill 144 83 356 144 86 356 minecraft:blue_terracotta
setblock 144 83 360 minecraft:dark_prismarine
fill 144 83 361 144 86 361 minecraft:blue_terracotta
setblock 145 83 359 minecraft:dark_prismarine
fill 145 83 360 145 85 360 minecraft:blue_terracotta
setblock 146 83 323 minecraft:dark_prismarine
setblock 146 83 363 minecraft:dark_prismarine
fill 147 83 323 147 86 323 minecraft:blue_terracotta
setblock 147 83 362 minecraft:dark_prismarine
fill 147 83 363 147 86 363 minecraft:blue_terracotta
setblock 148 83 361 minecraft:dark_prismarine
fill 148 83 362 148 86 362 minecraft:blue_terracotta
setblock 151 83 325 minecraft:light[level=12]
setblock 151 83 332 minecraft:light[level=12]
setblock 151 83 339 minecraft:light[level=12]
setblock 151 83 346 minecraft:light[level=12]
setblock 151 83 353 minecraft:light[level=12]
setblock 151 83 360 minecraft:light[level=12]
setblock 151 83 363 minecraft:dark_prismarine
fill 155 83 337 156 84 337 minecraft:spruce_planks
setblock 158 83 325 minecraft:light[level=12]
fill 158 83 329 158 95 329 minecraft:iron_bars
setblock 158 83 332 minecraft:light[level=12]
setblock 158 83 339 minecraft:light[level=12]
setblock 158 83 346 minecraft:light[level=12]
setblock 158 83 353 minecraft:light[level=12]
setblock 158 83 360 minecraft:light[level=12]
fill 159 83 357 159 102 357 minecraft:magenta_terracotta
setblock 161 83 323 minecraft:purple_concrete
fill 162 83 363 165 83 363 minecraft:blue_terracotta
fill 163 83 323 163 85 323 minecraft:blue_terracotta
setblock 165 83 325 minecraft:light[level=12]
setblock 165 83 332 minecraft:light[level=12]
setblock 165 83 339 minecraft:light[level=12]
setblock 165 83 346 minecraft:light[level=12]
setblock 165 83 353 minecraft:light[level=12]
setblock 165 83 360 minecraft:light[level=12]
fill 165 83 362 166 83 362 minecraft:blue_terracotta
setblock 166 83 323 minecraft:dark_prismarine
fill 166 83 324 168 84 324 minecraft:blue_terracotta
setblock 166 83 363 minecraft:dark_prismarine
fill 167 83 323 167 86 323 minecraft:blue_terracotta
setblock 167 83 362 minecraft:dark_prismarine
fill 167 83 363 167 86 363 minecraft:blue_terracotta
fill 168 83 362 169 85 362 minecraft:blue_terracotta
setblock 168 83 364 minecraft:light_blue_wool
setblock 171 83 323 minecraft:dark_prismarine
setblock 171 83 363 minecraft:dark_prismarine
fill 172 83 323 172 86 323 minecraft:blue_terracotta
setblock 172 83 325 minecraft:light[level=12]
setblock 172 83 332 minecraft:light[level=12]
setblock 172 83 339 minecraft:light[level=12]
setblock 172 83 346 minecraft:light[level=12]
setblock 172 83 353 minecraft:light[level=12]
setblock 172 83 360 minecraft:light[level=12]
fill 172 83 363 172 86 363 minecraft:blue_terracotta
fill 174 83 323 174 84 323 minecraft:blue_terracotta
setblock 175 83 363 minecraft:blue_terracotta
setblock 176 83 363 minecraft:dark_prismarine
fill 177 83 363 177 86 363 minecraft:blue_terracotta
fill 178 83 323 179 84 323 minecraft:blue_terracotta
fill 178 83 342 178 86 342 minecraft:dark_prismarine
setblock 179 83 325 minecraft:light[level=12]
setblock 179 83 332 minecraft:light[level=12]
fill 179 83 337 179 102 337 minecraft:magenta_terracotta
setblock 179 83 339 minecraft:light[level=12]
fill 179 83 341 179 86 341 minecraft:dark_prismarine
fill 179 83 343 179 86 343 minecraft:dark_prismarine
setblock 179 83 346 minecraft:light[level=12]
setblock 179 83 353 minecraft:light[level=12]
setblock 179 83 360 minecraft:light[level=12]
fill 179 83 362 179 85 362 minecraft:blue_terracotta
fill 180 83 342 180 86 342 minecraft:dark_prismarine
setblock 181 83 323 minecraft:dark_prismarine
setblock 181 83 358 minecraft:dark_prismarine
fill 181 83 359 181 86 359 minecraft:blue_terracotta
setblock 181 83 363 minecraft:dark_prismarine
fill 182 83 323 182 86 323 minecraft:blue_terracotta
setblock 182 83 337 minecraft:dark_prismarine
fill 182 83 338 182 86 338 minecraft:blue_terracotta
setblock 182 83 341 minecraft:blue_terracotta
setblock 182 83 346 minecraft:purple_concrete
setblock 182 83 357 minecraft:dark_prismarine
fill 182 83 358 182 86 358 minecraft:blue_terracotta
setblock 182 83 362 minecraft:dark_prismarine
fill 182 83 363 182 86 363 minecraft:blue_terracotta
fill 141 84 324 141 131 324 minecraft:black_concrete
setblock 141 84 360 minecraft:cyan_concrete
fill 142 84 324 142 85 324 minecraft:blue_terracotta
setblock 142 84 327 minecraft:purple_concrete
setblock 142 84 335 minecraft:blue_terracotta
setblock 142 84 336 minecraft:dark_prismarine
fill 142 84 337 143 86 337 minecraft:blue_terracotta
setblock 142 84 340 minecraft:blue_terracotta
setblock 142 84 341 minecraft:dark_prismarine
fill 142 84 342 142 84 345 minecraft:blue_terracotta
setblock 142 84 346 minecraft:dark_prismarine
fill 142 84 347 142 84 350 minecraft:blue_terracotta
setblock 142 84 351 minecraft:dark_prismarine
fill 142 84 352 143 86 352 minecraft:blue_terracotta
setblock 142 84 356 minecraft:dark_prismarine
fill 142 84 357 142 87 357 minecraft:blue_terracotta
setblock 142 84 361 minecraft:dark_prismarine
fill 142 84 362 142 87 362 minecraft:blue_terracotta
setblock 143 84 339 minecraft:blue_terracotta
setblock 143 84 340 minecraft:dark_prismarine
fill 143 84 341 143 87 341 minecraft:blue_terracotta
fill 143 84 343 143 84 344 minecraft:blue_terracotta
setblock 143 84 345 minecraft:dark_prismarine
setblock 143 84 355 minecraft:dark_prismarine
fill 143 84 356 143 87 356 minecraft:blue_terracotta
setblock 143 84 360 minecraft:dark_prismarine
fill 143 84 361 143 87 361 minecraft:blue_terracotta
fill 144 84 355 144 87 355 minecraft:blue_terracotta
setblock 144 84 359 minecraft:dark_prismarine
fill 144 84 360 144 87 360 minecraft:blue_terracotta
setblock 145 84 323 minecraft:dark_prismarine
setblock 145 84 363 minecraft:dark_prismarine
fill 146 84 323 146 87 323 minecraft:blue_terracotta
setblock 146 84 362 minecraft:dark_prismarine
fill 146 84 363 146 87 363 minecraft:blue_terracotta
fill 147 84 349 147 85 349 minecraft:pink_terracotta
setblock 147 84 361 minecraft:dark_prismarine
fill 147 84 362 147 87 362 minecraft:blue_terracotta
setblock 148 84 335 minecraft:magenta_terracotta
fill 148 84 336 148 85 336 minecraft:pink_terracotta
fill 148 84 349 148 102 349 minecraft:magenta_terracotta
fill 148 84 361 148 85 361 minecraft:blue_terracotta
setblock 149 84 322 minecraft:light_blue_wool
fill 149 84 323 149 85 323 minecraft:purple_concrete
setblock 150 84 363 minecraft:dark_prismarine
fill 151 84 363 151 87 363 minecraft:blue_terracotta
setblock 153 84 322 minecraft:light_blue_wool
fill 154 84 322 155 84 322 minecraft:black_concrete
setblock 155 84 323 minecraft:purple_concrete
fill 161 84 323 162 86 323 minecraft:blue_terracotta
fill 161 84 356 161 85 356 minecraft:pink_terracotta
fill 161 84 363 164 84 363 minecraft:blue_terracotta
fill 163 84 330 163 85 330 minecraft:pink_terracotta
setblock 164 84 324 minecraft:dark_prismarine
fill 164 84 362 165 84 362 minecraft:blue_terracotta
setblock 165 84 323 minecraft:dark_prismarine
fill 165 84 324 165 87 324 minecraft:blue_terracotta
setblock 165 84 363 minecraft:dark_prismarine
fill 166 84 323 166 87 323 minecraft:blue_terracotta
setblock 166 84 362 minecraft:dark_prismarine
fill 166 84 363 166 87 363 minecraft:blue_terracotta
fill 167 84 362 167 87 362 minecraft:blue_terracotta
fill 168 84 364 168 122 364 minecraft:black_concrete
setblock 169 84 324 minecraft:dark_prismarine
setblock 170 84 323 minecraft:dark_prismarine
setblock 170 84 363 minecraft:dark_prismarine
fill 171 84 323 171 87 323 minecraft:blue_terracotta
fill 171 84 363 171 87 363 minecraft:blue_terracotta
fill 174 84 350 174 102 350 minecraft:magenta_terracotta
setblock 175 84 323 minecraft:dark_prismarine
setblock 175 84 363 minecraft:dark_prismarine
fill 176 84 323 177 86 323 minecraft:blue_terracotta
fill 176 84 349 176 102 349 minecraft:magenta_terracotta
fill 176 84 350 176 85 350 minecraft:pink_terracotta
fill 176 84 351 176 102 351 minecraft:magenta_terracotta
fill 176 84 363 176 87 363 minecraft:blue_terracotta
fill 177 84 337 177 85 337 minecraft:pink_terracotta
fill 178 84 341 178 86 341 minecraft:dark_prismarine
fill 178 84 343 178 86 343 minecraft:dark_prismarine
fill 178 84 362 178 86 362 minecraft:blue_terracotta
setblock 180 84 323 minecraft:dark_prismarine
fill 180 84 341 180 86 341 minecraft:dark_prismarine
fill 180 84 343 180 86 343 minecraft:dark_prismarine
setblock 180 84 363 minecraft:dark_prismarine
fill 181 84 323 181 87 323 minecraft:blue_terracotta
setblock 181 84 357 minecraft:dark_prismarine
fill 181 84 358 181 87 358 minecraft:blue_terracotta
setblock 181 84 362 minecraft:dark_prismarine
fill 181 84 363 181 87 363 minecraft:blue_terracotta
setblock 182 84 326 minecraft:dark_prismarine
setblock 182 84 336 minecraft:dark_prismarine
fill 182 84 337 182 87 337 minecraft:blue_terracotta
setblock 182 84 341 minecraft:dark_prismarine
fill 182 84 342 182 86 343 minecraft:blue_terracotta
setblock 182 84 356 minecraft:dark_prismarine
fill 182 84 357 182 87 357 minecraft:blue_terracotta
setblock 182 84 361 minecraft:dark_prismarine
fill 182 84 362 182 87 362 minecraft:blue_terracotta
fill 141 85 360 141 128 360 minecraft:black_concrete
setblock 142 85 325 minecraft:dark_prismarine
setblock 142 85 333 minecraft:purple_concrete
setblock 142 85 335 minecraft:dark_prismarine
fill 142 85 336 142 88 336 minecraft:blue_terracotta
setblock 142 85 340 minecraft:dark_prismarine
fill 142 85 341 142 85 344 minecraft:blue_terracotta
setblock 142 85 345 minecraft:dark_prismarine
fill 142 85 346 142 85 349 minecraft:blue_terracotta
setblock 142 85 350 minecraft:dark_prismarine
fill 142 85 351 143 87 351 minecraft:blue_terracotta
setblock 142 85 355 minecraft:dark_prismarine
fill 142 85 356 142 88 356 minecraft:blue_terracotta
setblock 142 85 360 minecraft:dark_prismarine
fill 142 85 361 142 88 361 minecraft:blue_terracotta
setblock 143 85 339 minecraft:dark_prismarine
fill 143 85 340 144 87 340 minecraft:blue_terracotta
setblock 143 85 343 minecraft:blue_terracotta
setblock 143 85 344 minecraft:dark_prismarine
fill 143 85 345 143 85 348 minecraft:blue_terracotta
setblock 143 85 349 minecraft:dark_prismarine
fill 143 85 350 143 88 350 minecraft:blue_terracotta
setblock 143 85 354 minecraft:dark_prismarine
fill 143 85 355 143 88 355 minecraft:blue_terracotta
setblock 143 85 359 minecraft:dark_prismarine
fill 143 85 360 143 88 360 minecraft:blue_terracotta
setblock 144 85 323 minecraft:dark_prismarine
setblock 144 85 325 minecraft:light[level=13]
setblock 144 85 333 minecraft:light[level=13]
fill 144 85 339 144 88 339 minecraft:blue_terracotta
fill 144 85 341 144 85 342 minecraft:blue_terracotta
setblock 144 85 343 minecraft:dark_prismarine
fill 144 85 344 144 88 344 minecraft:blue_terracotta
setblock 144 85 349 minecraft:light[level=13]
setblock 144 85 358 minecraft:dark_prismarine
fill 144 85 359 144 88 359 minecraft:blue_terracotta
setblock 144 85 363 minecraft:dark_prismarine
fill 145 85 323 145 88 323 minecraft:blue_terracotta
setblock 145 85 362 minecraft:dark_prismarine
fill 145 85 363 145 88 363 minecraft:blue_terracotta
setblock 146 85 349 minecraft:pink_terracotta
setblock 146 85 361 minecraft:dark_prismarine
fill 146 85 362 146 88 362 minecraft:blue_terracotta
fill 147 85 361 147 87 361 minecraft:blue_terracotta
setblock 148 85 323 minecraft:blue_terracotta
setblock 148 85 335 minecraft:pink_terracotta
fill 149 85 322 149 127 322 minecraft:black_concrete
setblock 149 85 363 minecraft:dark_prismarine
fill 150 85 363 150 88 363 minecraft:blue_terracotta
setblock 152 85 325 minecraft:light[level=13]
setblock 152 85 333 minecraft:light[level=13]
setblock 152 85 341 minecraft:light[level=13]
setblock 152 85 349 minecraft:light[level=13]
setblock 152 85 357 minecraft:light[level=13]
fill 153 85 322 154 119 322 minecraft:black_concrete
setblock 153 85 364 minecraft:light_blue_wool
fill 154 85 364 154 127 364 minecraft:black_concrete
setblock 155 85 322 minecraft:light_blue_wool
setblock 156 85 363 minecraft:purple_concrete
fill 160 85 323 160 88 323 minecraft:blue_terracotta
setblock 160 85 325 minecraft:light[level=13]
setblock 160 85 333 minecraft:light[level=13]
setblock 160 85 341 minecraft:light[level=13]
setblock 160 85 349 minecraft:light[level=13]
setblock 160 85 356 minecraft:pink_terracotta
fill 160 85 357 160 102 357 minecraft:magenta_terracotta
fill 160 85 363 163 85 363 minecraft:blue_terracotta
setblock 161 85 357 minecraft:pink_terracotta
fill 162 85 362 164 85 362 minecraft:blue_terracotta
setblock 163 85 324 minecraft:dark_prismarine
setblock 163 85 329 minecraft:pink_terracotta
setblock 164 85 323 minecraft:dark_prismarine
fill 164 85 324 164 88 324 minecraft:blue_terracotta
fill 164 85 328 164 102 328 minecraft:magenta_terracotta
setblock 164 85 363 minecraft:dark_prismarine
fill 165 85 323 165 88 323 minecraft:blue_terracotta
setblock 165 85 362 minecraft:dark_prismarine
fill 165 85 363 165 88 363 minecraft:blue_terracotta
fill 166 85 324 167 85 324 minecraft:blue_terracotta
fill 166 85 362 166 88 362 minecraft:blue_terracotta
setblock 168 85 324 minecraft:dark_prismarine
setblock 168 85 325 minecraft:light[level=13]
setblock 168 85 333 minecraft:light[level=13]
setblock 168 85 341 minecraft:light[level=13]
setblock 168 85 349 minecraft:light[level=13]
setblock 168 85 357 minecraft:light[level=13]
setblock 169 85 323 minecraft:dark_prismarine
fill 169 85 324 170 87 324 minecraft:blue_terracotta
setblock 169 85 363 minecraft:dark_prismarine
fill 170 85 323 170 88 323 minecraft:blue_terracotta
setblock 170 85 362 minecraft:dark_prismarine
fill 170 85 363 170 88 363 minecraft:blue_terracotta
setblock 173 85 363 minecraft:blue_terracotta
setblock 174 85 323 minecraft:dark_prismarine
setblock 174 85 363 minecraft:dark_prismarine
fill 175 85 323 175 88 323 minecraft:blue_terracotta
fill 175 85 363 175 88 363 minecraft:blue_terracotta
setblock 176 85 325 minecraft:light[level=13]
setblock 176 85 333 minecraft:light[level=13]
setblock 176 85 341 minecraft:light[level=13]
setblock 176 85 357 minecraft:light[level=13]
fill 177 85 362 177 87 362 minecraft:blue_terracotta
setblock 178 85 323 minecraft:blue_terracotta
setblock 179 85 323 minecraft:dark_prismarine
setblock 179 85 363 minecraft:dark_prismarine
fill 180 85 323 180 87 324 minecraft:blue_terracotta
fill 180 85 360 180 85 361 minecraft:blue_terracotta
setblock 180 85 362 minecraft:dark_prismarine
fill 180 85 363 180 88 363 minecraft:blue_terracotta
fill 181 85 324 182 85 324 minecraft:blue_terracotta
fill 181 85 357 181 88 357 minecraft:blue_terracotta
setblock 181 85 361 minecraft:dark_prismarine
fill 181 85 362 181 88 362 minecraft:blue_terracotta
setblock 182 85 325 minecraft:dark_prismarine
fill 182 85 326 182 87 327 minecraft:blue_terracotta
setblock 182 85 328 minecraft:purple_concrete
setblock 182 85 334 minecraft:purple_concrete
setblock 182 85 335 minecraft:dark_prismarine
fill 182 85 336 182 88 336 minecraft:blue_terracotta
setblock 182 85 339 minecraft:blue_terracotta
setblock 182 85 340 minecraft:dark_prismarine
fill 182 85 341 182 88 341 minecraft:blue_terracotta
setblock 182 85 344 minecraft:blue_terracotta
setblock 182 85 345 minecraft:dark_prismarine
fill 182 85 353 182 86 353 minecraft:blue_terracotta
setblock 182 85 355 minecraft:dark_prismarine
fill 182 85 356 182 88 356 minecraft:blue_terracotta
setblock 182 85 360 minecraft:dark_prismarine
fill 182 85 361 182 88 361 minecraft:blue_terracotta
setblock 142 86 323 minecraft:blue_terracotta
setblock 142 86 324 minecraft:dark_prismarine
fill 142 86 325 142 88 326 minecraft:blue_terracotta
fill 142 86 335 142 89 335 minecraft:blue_terracotta
setblock 142 86 338 minecraft:blue_terracotta
setblock 142 86 339 minecraft:dark_prismarine
fill 142 86 340 142 86 343 minecraft:blue_terracotta
setblock 142 86 344 minecraft:dark_prismarine
fill 142 86 345 142 86 348 minecraft:blue_terracotta
setblock 142 86 349 minecraft:dark_prismarine
fill 142 86 350 142 89 350 minecraft:blue_terracotta
setblock 142 86 354 minecraft:dark_prismarine
fill 142 86 355 142 89 355 minecraft:blue_terracotta
setblock 142 86 359 minecraft:dark_prismarine
fill 142 86 360 142 89 360 minecraft:blue_terracotta
setblock 143 86 323 minecraft:dark_prismarine
setblock 143 86 338 minecraft:dark_prismarine
fill 143 86 339 143 89 339 minecraft:blue_terracotta
setblock 143 86 343 minecraft:dark_prismarine
fill 143 86 344 143 86 347 minecraft:blue_terracotta
setblock 143 86 348 minecraft:dark_prismarine
fill 143 86 349 143 89 349 minecraft:blue_terracotta
setblock 143 86 353 minecraft:dark_prismarine
fill 143 86 354 143 89 354 minecraft:blue_terracotta
setblock 143 86 358 minecraft:dark_prismarine
fill 143 86 359 143 89 359 minecraft:blue_terracotta
setblock 143 86 363 minecraft:dark_prismarine
fill 144 86 323 144 89 323 minecraft:blue_terracotta
setblock 144 86 341 minecraft:blue_terracotta
setblock 144 86 342 minecraft:dark_prismarine
fill 144 86 343 144 89 343 minecraft:blue_terracotta
fill 144 86 345 144 86 346 minecraft:blue_terracotta
setblock 144 86 347 minecraft:dark_prismarine
setblock 144 86 357 minecraft:dark_prismarine
fill 144 86 358 144 89 358 minecraft:blue_terracotta
setblock 144 86 362 minecraft:dark_prismarine
fill 144 86 363 144 89 363 minecraft:blue_terracotta
setblock 145 86 361 minecraft:dark_prismarine
fill 145 86 362 145 89 362 minecraft:blue_terracotta
fill 146 86 349 147 102 349 minecraft:magenta_terracotta
fill 146 86 361 146 89 361 minecraft:blue_terracotta
fill 147 86 336 148 102 336 minecraft:magenta_terracotta
setblock 148 86 323 minecraft:dark_prismarine
fill 148 86 335 148 102 335 minecraft:magenta_terracotta
setblock 148 86 363 minecraft:dark_prismarine
setblock 149 86 362 minecraft:dark_prismarine
fill 149 86 363 149 89 363 minecraft:blue_terracotta
fill 153 86 364 153 127 364 minecraft:black_concrete
fill 155 86 322 155 88 322 minecraft:black_concrete
setblock 158 86 323 minecraft:dark_prismarine
setblock 158 86 363 minecraft:dark_prismarine
fill 159 86 323 159 89 323 minecraft:blue_terracotta
fill 159 86 363 162 86 363 minecraft:blue_terracotta
fill 159 86 364 159 131 364 minecraft:black_concrete
fill 160 86 356 161 102 356 minecraft:magenta_terracotta
setblock 160 86 364 minecraft:light_blue_wool
setblock 161 86 324 minecraft:blue_terracotta
fill 161 86 357 161 102 357 minecraft:magenta_terracotta
fill 161 86 362 163 86 362 minecraft:blue_terracotta
setblock 162 86 324 minecraft:dark_prismarine
setblock 163 86 323 minecraft:dark_prismarine
fill 163 86 324 163 89 324 minecraft:blue_terracotta
fill 163 86 329 163 102 330 minecraft:magenta_terracotta
setblock 163 86 363 minecraft:dark_prismarine
fill 164 86 323 164 89 323 minecraft:blue_terracotta
setblock 164 86 362 minecraft:dark_prismarine
fill 164 86 363 164 89 363 minecraft:blue_terracotta
setblock 165 86 325 minecraft:blue_terracotta
fill 165 86 330 165 102 330 minecraft:magenta_terracotta
fill 165 86 362 165 89 362 minecraft:blue_terracotta
setblock 166 86 324 minecraft:blue_terracotta
setblock 166 86 325 minecraft:dark_prismarine
setblock 167 86 324 minecraft:dark_prismarine
setblock 168 86 323 minecraft:dark_prismarine
fill 168 86 324 168 89 324 minecraft:blue_terracotta
setblock 168 86 362 minecraft:blue_terracotta
setblock 168 86 363 minecraft:dark_prismarine
fill 169 86 323 169 89 323 minecraft:blue_terracotta
setblock 169 86 362 minecraft:dark_prismarine
fill 169 86 363 169 89 363 minecraft:blue_terracotta
fill 170 86 362 170 89 362 minecraft:blue_terracotta
setblock 171 86 324 minecraft:blue_terracotta
setblock 173 86 323 minecraft:dark_prismarine
setblock 173 86 363 minecraft:dark_prismarine
fill 174 86 323 174 89 323 minecraft:blue_terracotta
fill 174 86 363 174 89 363 minecraft:blue_terracotta
fill 176 86 350 176 102 350 minecraft:magenta_terracotta
fill 176 86 362 176 88 362 minecraft:blue_terracotta
fill 177 86 337 177 102 337 minecraft:magenta_terracotta
setblock 177 86 342 minecraft:dark_prismarine
setblock 178 86 323 minecraft:dark_prismarine
fill 178 86 324 179 88 324 minecraft:blue_terracotta
setblock 178 86 363 minecraft:dark_prismarine
fill 179 86 323 179 89 323 minecraft:blue_terracotta
setblock 179 86 340 minecraft:dark_prismarine
setblock 179 86 344 minecraft:dark_prismarine
setblock 179 86 361 minecraft:blue_terracotta
setblock 179 86 362 minecraft:dark_prismarine
fill 179 86 363 179 89 363 minecraft:blue_terracotta
setblock 180 86 360 minecraft:blue_terracotta
setblock 180 86 361 minecraft:dark_prismarine
fill 180 86 362 180 89 362 minecraft:blue_terracotta
setblock 181 86 324 minecraft:blue_terracotta
setblock 181 86 325 minecraft:dark_prismarine
fill 181 86 341 181 89 341 minecraft:blue_terracotta
setblock 181 86 342 minecraft:dark_prismarine
fill 181 86 356 181 89 356 minecraft:blue_terracotta
setblock 181 86 360 minecraft:dark_prismarine
fill 181 86 361 181 89 361 minecraft:blue_terracotta
setblock 182 86 324 minecraft:dark_prismarine
fill 182 86 325 182 89 325 minecraft:blue_terracotta
setblock 182 86 328 minecraft:blue_terracotta
setblock 182 86 329 minecraft:dark_prismarine
setblock 182 86 334 minecraft:dark_prismarine
fill 182 86 335 182 89 335 minecraft:blue_terracotta
setblock 182 86 339 minecraft:dark_prismarine
fill 182 86 340 182 89 340 minecraft:blue_terracotta
setblock 182 86 344 minecraft:dark_prismarine
fill 182 86 345 182 86 348 minecraft:blue_terracotta
setblock 182 86 349 minecraft:dark_prismarine
fill 182 86 350 182 87 352 minecraft:blue_terracotta
setblock 182 86 354 minecraft:dark_prismarine
fill 182 86 355 182 89 355 minecraft:blue_terracotta
setblock 182 86 359 minecraft:dark_prismarine
fill 182 86 360 182 89 360 minecraft:blue_terracotta
fill 183 86 330 183 127 330 minecraft:black_concrete
setblock 183 86 331 minecraft:light_blue_wool
setblock 142 87 323 minecraft:dark_prismarine
fill 142 87 324 145 87 324 minecraft:blue_terracotta
setblock 142 87 327 minecraft:blue_terracotta
fill 142 87 334 142 90 334 minecraft:blue_terracotta
setblock 142 87 337 minecraft:blue_terracotta
setblock 142 87 338 minecraft:dark_prismarine
fill 142 87 339 142 87 342 minecraft:blue_terracotta
setblock 142 87 343 minecraft:dark_prismarine
fill 142 87 344 142 87 347 minecraft:blue_terracotta
setblock 142 87 348 minecraft:dark_prismarine
fill 142 87 349 142 90 349 minecraft:blue_terracotta
setblock 142 87 352 minecraft:blue_terracotta
setblock 142 87 353 minecraft:dark_prismarine
fill 142 87 354 142 90 354 minecraft:blue_terracotta
setblock 142 87 358 minecraft:dark_prismarine
fill 142 87 359 142 90 359 minecraft:blue_terracotta
setblock 142 87 363 minecraft:dark_prismarine
fill 143 87 323 143 90 323 minecraft:blue_terracotta
fill 143 87 325 143 88 325 minecraft:blue_terracotta
setblock 143 87 336 minecraft:blue_terracotta
setblock 143 87 337 minecraft:dark_prismarine
fill 143 87 338 144 88 338 minecraft:blue_terracotta
setblock 143 87 342 minecraft:dark_prismarine
fill 143 87 343 143 87 346 minecraft:blue_terracotta
setblock 143 87 347 minecraft:dark_prismarine
fill 143 87 348 144 89 348 minecraft:blue_terracotta
setblock 143 87 352 minecraft:dark_prismarine
fill 143 87 353 143 90 353 minecraft:blue_terracotta
setblock 143 87 357 minecraft:dark_prismarine
fill 143 87 358 143 90 358 minecraft:blue_terracotta
setblock 143 87 362 minecraft:dark_prismarine
fill 143 87 363 143 90 363 minecraft:blue_terracotta
setblock 144 87 341 minecraft:dark_prismarine
fill 144 87 342 145 89 342 minecraft:blue_terracotta
setblock 144 87 345 minecraft:blue_terracotta
setblock 144 87 346 minecraft:dark_prismarine
fill 144 87 347 144 90 347 minecraft:blue_terracotta
fill 144 87 349 144 87 350 minecraft:blue_terracotta
setblock 144 87 356 minecraft:dark_prismarine
fill 144 87 357 144 89 357 minecraft:blue_terracotta
setblock 144 87 361 minecraft:dark_prismarine
fill 144 87 362 144 90 362 minecraft:blue_terracotta
fill 145 87 343 145 87 344 minecraft:blue_terracotta
setblock 145 87 345 minecraft:dark_prismarine
fill 145 87 361 145 90 361 minecraft:blue_terracotta
setblock 147 87 323 minecraft:dark_prismarine
fill 147 87 350 147 102 350 minecraft:magenta_terracotta
setblock 147 87 363 minecraft:dark_prismarine
fill 148 87 323 149 89 323 minecraft:blue_terracotta
fill 148 87 334 148 102 334 minecraft:magenta_terracotta
setblock 148 87 362 minecraft:dark_prismarine
fill 148 87 363 148 90 363 minecraft:blue_terracotta
fill 149 87 362 149 88 362 minecraft:blue_terracotta
setblock 152 87 363 minecraft:dark_prismarine
setblock 156 87 323 minecraft:purple_concrete
setblock 157 87 323 minecraft:dark_prismarine
setblock 157 87 363 minecraft:dark_prismarine
fill 158 87 323 158 90 323 minecraft:blue_terracotta
fill 158 87 363 161 87 363 minecraft:blue_terracotta
fill 159 87 324 160 87 324 minecraft:blue_terracotta
fill 160 87 362 162 87 362 minecraft:blue_terracotta
fill 160 87 364 160 131 364 minecraft:black_concrete
setblock 161 87 323 minecraft:blue_terracotta
setblock 161 87 324 minecraft:dark_prismarine
setblock 162 87 323 minecraft:dark_prismarine
fill 162 87 324 162 89 325 minecraft:blue_terracotta
setblock 162 87 363 minecraft:dark_prismarine
fill 163 87 323 163 90 323 minecraft:blue_terracotta
fill 163 87 325 164 87 325 minecraft:blue_terracotta
setblock 163 87 362 minecraft:dark_prismarine
fill 163 87 363 163 90 363 minecraft:blue_terracotta
fill 164 87 362 164 90 362 minecraft:blue_terracotta
setblock 165 87 325 minecraft:dark_prismarine
setblock 166 87 324 minecraft:dark_prismarine
fill 166 87 325 168 88 325 minecraft:blue_terracotta
setblock 167 87 323 minecraft:dark_prismarine
fill 167 87 324 167 90 324 minecraft:blue_terracotta
setblock 167 87 363 minecraft:dark_prismarine
fill 168 87 323 168 90 323 minecraft:blue_terracotta
setblock 168 87 362 minecraft:dark_prismarine
fill 168 87 363 168 90 363 minecraft:blue_terracotta
fill 169 87 362 169 90 362 minecraft:blue_terracotta
setblock 171 87 324 minecraft:dark_prismarine
fill 171 87 362 171 88 362 minecraft:blue_terracotta
setblock 172 87 323 minecraft:dark_prismarine
fill 172 87 324 175 87 324 minecraft:blue_terracotta
setblock 172 87 363 minecraft:dark_prismarine
fill 173 87 323 173 90 323 minecraft:blue_terracotta
setblock 173 87 362 minecraft:dark_prismarine
fill 173 87 363 173 90 363 minecraft:blue_terracotta
fill 174 87 362 175 89 362 minecraft:blue_terracotta
setblock 176 87 323 minecraft:blue_terracotta
setblock 176 87 324 minecraft:dark_prismarine
setblock 177 87 323 minecraft:dark_prismarine
fill 177 87 324 177 90 324 minecraft:blue_terracotta
setblock 177 87 363 minecraft:dark_prismarine
fill 178 87 323 178 90 323 minecraft:blue_terracotta
setblock 178 87 361 minecraft:blue_terracotta
setblock 178 87 362 minecraft:dark_prismarine
fill 178 87 363 178 90 363 minecraft:blue_terracotta
setblock 179 87 361 minecraft:dark_prismarine
fill 179 87 362 179 90 362 minecraft:blue_terracotta
setblock 180 87 359 minecraft:blue_terracotta
setblock 180 87 360 minecraft:dark_prismarine
fill 180 87 361 180 90 361 minecraft:blue_terracotta
setblock 181 87 324 minecraft:dark_prismarine
fill 181 87 325 181 88 327 minecraft:blue_terracotta
setblock 181 87 339 minecraft:dark_prismarine
fill 181 87 340 181 90 340 minecraft:blue_terracotta
fill 181 87 342 181 87 343 minecraft:blue_terracotta
setblock 181 87 344 minecraft:dark_prismarine
fill 181 87 345 182 89 345 minecraft:blue_terracotta
fill 181 87 355 181 90 355 minecraft:blue_terracotta
setblock 181 87 359 minecraft:dark_prismarine
fill 181 87 360 181 90 360 minecraft:blue_terracotta
setblock 182 87 323 minecraft:dark_prismarine
fill 182 87 324 182 90 324 minecraft:blue_terracotta
setblock 182 87 328 minecraft:dark_prismarine
fill 182 87 329 182 89 330 minecraft:blue_terracotta
fill 182 87 334 182 90 334 minecraft:blue_terracotta
setblock 182 87 338 minecraft:dark_prismarine
fill 182 87 339 182 90 339 minecraft:blue_terracotta
setblock 182 87 342 minecraft:blue_terracotta
setblock 182 87 343 minecraft:dark_prismarine
fill 182 87 344 182 90 344 minecraft:blue_terracotta
fill 182 87 346 182 87 347 minecraft:blue_terracotta
setblock 182 87 348 minecraft:dark_prismarine
fill 182 87 349 182 90 349 minecraft:blue_terracotta
setblock 182 87 353 minecraft:dark_prismarine
fill 182 87 354 182 90 354 minecraft:blue_terracotta
setblock 182 87 358 minecraft:dark_prismarine
fill 182 87 359 182 90 359 minecraft:blue_terracotta
setblock 182 87 363 minecraft:dark_prismarine
fill 183 87 331 183 131 331 minecraft:black_concrete
fill 142 88 323 142 90 324 minecraft:blue_terracotta
setblock 142 88 327 minecraft:dark_prismarine
fill 142 88 328 142 90 329 minecraft:blue_terracotta
setblock 142 88 332 minecraft:purple_concrete
fill 142 88 333 142 91 333 minecraft:blue_terracotta
setblock 142 88 337 minecraft:dark_prismarine
fill 142 88 338 142 88 341 minecraft:blue_terracotta
setblock 142 88 342 minecraft:dark_prismarine
fill 142 88 343 142 88 346 minecraft:blue_terracotta
setblock 142 88 347 minecraft:dark_prismarine
fill 142 88 348 142 91 348 minecraft:blue_terracotta
setblock 142 88 351 minecraft:blue_terracotta
setblock 142 88 352 minecraft:dark_prismarine
fill 142 88 353 142 91 353 minecraft:blue_terracotta
setblock 142 88 357 minecraft:dark_prismarine
fill 142 88 358 142 91 358 minecraft:blue_terracotta
setblock 142 88 362 minecraft:dark_prismarine
fill 142 88 363 142 91 363 minecraft:blue_terracotta
fill 143 88 324 144 88 324 minecraft:blue_terracotta
setblock 143 88 326 minecraft:dark_prismarine
setblock 143 88 336 minecraft:dark_prismarine
fill 143 88 337 143 91 337 minecraft:blue_terracotta
setblock 143 88 340 minecraft:blue_terracotta
setblock 143 88 341 minecraft:dark_prismarine
fill 143 88 342 143 88 345 minecraft:blue_terracotta
setblock 143 88 346 minecraft:dark_prismarine
fill 143 88 347 143 91 347 minecraft:blue_terracotta
setblock 143 88 351 minecraft:dark_prismarine
fill 143 88 352 144 90 352 minecraft:blue_terracotta
setblock 143 88 356 minecraft:dark_prismarine
fill 143 88 357 143 91 357 minecraft:blue_terracotta
setblock 143 88 361 minecraft:dark_prismarine
fill 143 88 362 143 91 362 minecraft:blue_terracotta
setblock 144 88 340 minecraft:dark_prismarine
fill 144 88 341 145 89 341 minecraft:blue_terracotta
setblock 144 88 345 minecraft:dark_prismarine
fill 144 88 346 145 90 346 minecraft:blue_terracotta
setblock 144 88 349 minecraft:blue_terracotta
setblock 144 88 350 minecraft:dark_prismarine
fill 144 88 351 144 91 351 minecraft:blue_terracotta
setblock 144 88 355 minecraft:dark_prismarine
fill 144 88 356 144 89 356 minecraft:blue_terracotta
setblock 144 88 360 minecraft:dark_prismarine
fill 144 88 361 144 91 361 minecraft:blue_terracotta
setblock 145 88 324 minecraft:dark_prismarine
setblock 145 88 343 minecraft:blue_terracotta
setblock 145 88 344 minecraft:dark_prismarine
fill 145 88 345 145 91 345 minecraft:blue_terracotta
fill 145 88 347 145 89 347 minecraft:blue_terracotta
setblock 146 88 323 minecraft:dark_prismarine
fill 146 88 324 146 91 324 minecraft:blue_terracotta
setblock 146 88 363 minecraft:dark_prismarine
setblock 147 88 322 minecraft:cyan_concrete
fill 147 88 323 147 91 323 minecraft:blue_terracotta
setblock 147 88 362 minecraft:dark_prismarine
fill 147 88 363 147 91 363 minecraft:blue_terracotta
fill 148 88 362 148 89 362 minecraft:blue_terracotta
fill 149 88 334 149 102 334 minecraft:magenta_terracotta
setblock 150 88 323 minecraft:blue_terracotta
setblock 151 88 363 minecraft:dark_prismarine
fill 152 88 363 152 89 363 minecraft:blue_terracotta
setblock 155 88 323 minecraft:blue_terracotta
setblock 155 88 363 minecraft:blue_terracotta
setblock 156 88 323 minecraft:dark_prismarine
setblock 156 88 363 minecraft:dark_prismarine
fill 157 88 323 157 91 323 minecraft:blue_terracotta
fill 157 88 363 160 88 363 minecraft:blue_terracotta
fill 158 88 324 159 88 324 minecraft:blue_terracotta
fill 159 88 362 161 88 362 minecraft:blue_terracotta
setblock 160 88 324 minecraft:dark_prismarine
fill 160 88 325 161 90 325 minecraft:blue_terracotta
setblock 161 88 323 minecraft:dark_prismarine
fill 161 88 324 161 91 324 minecraft:blue_terracotta
setblock 161 88 363 minecraft:dark_prismarine
fill 162 88 323 162 91 323 minecraft:blue_terracotta
setblock 162 88 362 minecraft:dark_prismarine
fill 162 88 363 162 91 363 minecraft:blue_terracotta
setblock 163 88 325 minecraft:blue_terracotta
fill 163 88 362 163 91 362 minecraft:blue_terracotta
setblock 164 88 325 minecraft:dark_prismarine
setblock 165 88 324 minecraft:dark_prismarine
fill 165 88 325 165 91 325 minecraft:blue_terracotta
fill 165 88 329 165 102 329 minecraft:magenta_terracotta
setblock 166 88 323 minecraft:dark_prismarine
fill 166 88 324 166 91 324 minecraft:blue_terracotta
setblock 166 88 363 minecraft:dark_prismarine
fill 167 88 323 167 91 323 minecraft:blue_terracotta
setblock 167 88 362 minecraft:dark_prismarine
fill 167 88 363 167 91 363 minecraft:blue_terracotta
fill 168 88 362 168 90 362 minecraft:blue_terracotta
setblock 169 88 324 minecraft:blue_terracotta
setblock 169 88 325 minecraft:dark_prismarine
setblock 170 88 324 minecraft:dark_prismarine
setblock 171 88 323 minecraft:dark_prismarine
fill 171 88 324 174 88 324 minecraft:blue_terracotta
setblock 171 88 363 minecraft:dark_prismarine
fill 172 88 323 172 91 323 minecraft:blue_terracotta
setblock 172 88 362 minecraft:dark_prismarine
fill 172 88 363 172 91 363 minecraft:blue_terracotta
fill 173 88 362 173 91 362 minecraft:blue_terracotta
setblock 175 88 324 minecraft:dark_prismarine
setblock 176 88 323 minecraft:dark_prismarine
fill 176 88 324 176 91 324 minecraft:blue_terracotta
setblock 176 88 363 minecraft:dark_prismarine
fill 177 88 323 177 91 323 minecraft:blue_terracotta
setblock 177 88 362 minecraft:dark_prismarine
fill 177 88 363 177 91 363 minecraft:blue_terracotta
setblock 178 88 361 minecraft:dark_prismarine
fill 178 88 362 178 91 362 minecraft:blue_terracotta
setblock 179 88 325 minecraft:dark_prismarine
fill 179 88 361 179 91 361 minecraft:blue_terracotta
setblock 180 88 323 minecraft:blue_terracotta
setblock 180 88 324 minecraft:dark_prismarine
fill 180 88 325 180 91 325 minecraft:blue_terracotta
setblock 180 88 358 minecraft:blue_terracotta
setblock 180 88 359 minecraft:dark_prismarine
fill 180 88 360 180 91 360 minecraft:blue_terracotta
setblock 181 88 323 minecraft:dark_prismarine
fill 181 88 324 181 91 324 minecraft:blue_terracotta
setblock 181 88 328 minecraft:dark_prismarine
setblock 181 88 338 minecraft:dark_prismarine
fill 181 88 339 181 91 339 minecraft:blue_terracotta
setblock 181 88 342 minecraft:blue_terracotta
setblock 181 88 343 minecraft:dark_prismarine
fill 181 88 344 181 91 344 minecraft:blue_terracotta
fill 181 88 346 181 88 347 minecraft:blue_terracotta
setblock 181 88 348 minecraft:dark_prismarine
fill 181 88 349 181 91 349 minecraft:blue_terracotta
fill 181 88 354 181 91 354 minecraft:blue_terracotta
setblock 181 88 358 minecraft:dark_prismarine
fill 181 88 359 181 91 359 minecraft:blue_terracotta
setblock 181 88 363 minecraft:dark_prismarine
fill 182 88 323 182 91 323 minecraft:blue_terracotta
setblock 182 88 326 minecraft:blue_terracotta
setblock 182 88 327 minecraft:dark_prismarine
fill 182 88 328 182 91 328 minecraft:blue_terracotta
setblock 182 88 331 minecraft:blue_terracotta
setblock 182 88 332 minecraft:dark_prismarine
fill 182 88 333 182 91 333 minecraft:blue_terracotta
setblock 182 88 337 minecraft:dark_prismarine
fill 182 88 338 182 91 338 minecraft:blue_terracotta
setblock 182 88 342 minecraft:dark_prismarine
fill 182 88 343 182 91 343 minecraft:blue_terracotta
setblock 182 88 346 minecraft:blue_terracotta
setblock 182 88 347 minecraft:dark_prismarine
fill 182 88 348 182 91 348 minecraft:blue_terracotta
fill 182 88 350 182 88 351 minecraft:blue_terracotta
setblock 182 88 352 minecraft:dark_prismarine
fill 182 88 353 182 91 353 minecraft:blue_terracotta
setblock 182 88 357 minecraft:dark_prismarine
fill 182 88 358 182 91 358 minecraft:blue_terracotta
setblock 182 88 362 minecraft:dark_prismarine
fill 182 88 363 182 91 363 minecraft:blue_terracotta
setblock 142 89 325 minecraft:blue_terracotta
setblock 142 89 326 minecraft:dark_prismarine
fill 142 89 327 143 91 327 minecraft:blue_terracotta
setblock 142 89 330 minecraft:blue_terracotta
setblock 142 89 331 minecraft:dark_prismarine
fill 142 89 332 142 92 332 minecraft:blue_terracotta
setblock 142 89 336 minecraft:dark_prismarine
fill 142 89 337 142 89 340 minecraft:blue_terracotta
setblock 142 89 341 minecraft:dark_prismarine
fill 142 89 342 142 89 345 minecraft:blue_terracotta
setblock 142 89 346 minecraft:dark_prismarine
fill 142 89 347 142 92 347 minecraft:blue_terracotta
setblock 142 89 351 minecraft:dark_prismarine
fill 142 89 352 142 92 352 minecraft:blue_terracotta
setblock 142 89 356 minecraft:dark_prismarine
fill 142 89 357 142 92 357 minecraft:blue_terracotta
setblock 142 89 361 minecraft:dark_prismarine
fill 142 89 362 142 92 362 minecraft:blue_terracotta
setblock 143 89 324 minecraft:blue_terracotta
setblock 143 89 325 minecraft:dark_prismarine
fill 143 89 326 143 92 326 minecraft:blue_terracotta
setblock 143 89 336 minecraft:blue_terracotta
fill 143 89 338 143 90 338 minecraft:blue_terracotta
setblock 143 89 340 minecraft:dark_prismarine
fill 143 89 341 143 89 344 minecraft:blue_terracotta
setblock 143 89 345 minecraft:dark_prismarine
fill 143 89 346 143 92 346 minecraft:blue_terracotta
setblock 143 89 350 minecraft:dark_prismarine
fill 143 89 351 143 92 351 minecraft:blue_terracotta
setblock 143 89 355 minecraft:dark_prismarine
fill 143 89 356 143 92 356 minecraft:blue_terracotta
setblock 143 89 360 minecraft:dark_prismarine
fill 143 89 361 143 92 361 minecraft:blue_terracotta
setblock 144 89 324 minecraft:dark_prismarine
setblock 144 89 325 minecraft:light[level=12]
setblock 144 89 332 minecraft:light[level=12]
setblock 144 89 339 minecraft:dark_prismarine
fill 144 89 340 144 91 340 minecraft:blue_terracotta
setblock 144 89 344 minecraft:dark_prismarine
fill 144 89 345 144 92 345 minecraft:blue_terracotta
setblock 144 89 349 minecraft:dark_prismarine
fill 144 89 350 144 92 350 minecraft:blue_terracotta
setblock 144 89 353 minecraft:blue_terracotta
setblock 144 89 359 minecraft:dark_prismarine
fill 144 89 360 144 90 360 minecraft:blue_terracotta
fill 144 89 364 147 92 364 minecraft:black_concrete
setblock 145 89 323 minecraft:dark_prismarine
fill 145 89 324 145 92 324 minecraft:blue_terracotta
setblock 145 89 343 minecraft:dark_prismarine
fill 145 89 344 145 92 344 minecraft:blue_terracotta
setblock 145 89 348 minecraft:dark_prismarine
setblock 145 89 363 minecraft:dark_prismarine
fill 146 89 323 146 92 323 minecraft:blue_terracotta
setblock 146 89 362 minecraft:dark_prismarine
fill 146 89 363 146 92 363 minecraft:blue_terracotta
fill 147 89 322 147 127 322 minecraft:black_concrete
fill 147 89 362 147 90 362 minecraft:blue_terracotta
setblock 148 89 364 minecraft:cyan_concrete
fill 149 89 364 149 131 364 minecraft:black_concrete
setblock 150 89 323 minecraft:dark_prismarine
fill 150 89 336 150 102 336 minecraft:magenta_terracotta
setblock 150 89 363 minecraft:dark_prismarine
fill 151 89 323 154 89 323 minecraft:blue_terracotta
setblock 151 89 325 minecraft:light[level=12]
setblock 151 89 332 minecraft:light[level=12]
setblock 151 89 339 minecraft:light[level=12]
setblock 151 89 346 minecraft:light[level=12]
setblock 151 89 353 minecraft:light[level=12]
setblock 151 89 360 minecraft:light[level=12]
fill 151 89 363 151 90 363 minecraft:blue_terracotta
setblock 154 89 363 minecraft:blue_terracotta
setblock 155 89 322 minecraft:cyan_concrete
setblock 155 89 323 minecraft:dark_prismarine
setblock 155 89 363 minecraft:dark_prismarine
fill 156 89 323 156 92 323 minecraft:blue_terracotta
fill 156 89 363 159 89 363 minecraft:blue_terracotta
fill 157 89 324 158 89 324 minecraft:blue_terracotta
setblock 158 89 325 minecraft:light[level=12]
setblock 158 89 332 minecraft:light[level=12]
setblock 158 89 339 minecraft:light[level=12]
setblock 158 89 346 minecraft:light[level=12]
setblock 158 89 353 minecraft:light[level=12]
setblock 158 89 360 minecraft:light[level=12]
setblock 159 89 324 minecraft:dark_prismarine
fill 159 89 325 159 92 325 minecraft:blue_terracotta
fill 159 89 362 160 89 362 minecraft:blue_terracotta
setblock 160 89 323 minecraft:dark_prismarine
fill 160 89 324 160 92 324 minecraft:blue_terracotta
setblock 160 89 363 minecraft:dark_prismarine
fill 161 89 323 161 92 323 minecraft:blue_terracotta
setblock 161 89 362 minecraft:dark_prismarine
fill 161 89 363 161 92 363 minecraft:blue_terracotta
setblock 162 89 326 minecraft:dark_prismarine
fill 162 89 362 162 92 362 minecraft:blue_terracotta
setblock 163 89 325 minecraft:dark_prismarine
fill 163 89 326 165 90 326 minecraft:blue_terracotta
setblock 164 89 324 minecraft:dark_prismarine
fill 164 89 325 164 92 325 minecraft:blue_terracotta
setblock 165 89 323 minecraft:dark_prismarine
fill 165 89 324 165 92 324 minecraft:blue_terracotta
setblock 165 89 332 minecraft:light[level=12]
setblock 165 89 339 minecraft:light[level=12]
setblock 165 89 346 minecraft:light[level=12]
setblock 165 89 353 minecraft:light[level=12]
setblock 165 89 360 minecraft:light[level=12]
setblock 165 89 363 minecraft:dark_prismarine
fill 166 89 323 166 92 323 minecraft:blue_terracotta
fill 166 89 325 167 89 325 minecraft:blue_terracotta
setblock 166 89 362 minecraft:dark_prismarine
fill 166 89 363 166 92 363 minecraft:blue_terracotta
fill 167 89 362 167 91 362 minecraft:blue_terracotta
setblock 168 89 325 minecraft:dark_prismarine
setblock 169 89 324 minecraft:dark_prismarine
fill 169 89 325 170 91 325 minecraft:blue_terracotta
setblock 170 89 323 minecraft:dark_prismarine
fill 170 89 324 173 89 324 minecraft:blue_terracotta
setblock 170 89 363 minecraft:dark_prismarine
fill 171 89 323 171 92 323 minecraft:blue_terracotta
setblock 171 89 362 minecraft:dark_prismarine
fill 171 89 363 171 92 363 minecraft:blue_terracotta
setblock 172 89 325 minecraft:light[level=12]
setblock 172 89 332 minecraft:light[level=12]
setblock 172 89 339 minecraft:light[level=12]
setblock 172 89 346 minecraft:light[level=12]
setblock 172 89 353 minecraft:light[level=12]
setblock 172 89 360 minecraft:light[level=12]
fill 172 89 362 172 90 362 minecraft:blue_terracotta
setblock 174 89 324 minecraft:dark_prismarine
fill 174 89 351 174 102 351 minecraft:magenta_terracotta
setblock 175 89 323 minecraft:dark_prismarine
fill 175 89 324 175 92 324 minecraft:blue_terracotta
setblock 175 89 363 minecraft:dark_prismarine
fill 176 89 323 176 92 323 minecraft:blue_terracotta
setblock 176 89 362 minecraft:dark_prismarine
fill 176 89 363 176 92 363 minecraft:blue_terracotta
setblock 177 89 325 minecraft:blue_terracotta
setblock 177 89 361 minecraft:dark_prismarine
fill 177 89 362 177 92 362 minecraft:blue_terracotta
setblock 178 89 324 minecraft:blue_terracotta
setblock 178 89 325 minecraft:dark_prismarine
fill 178 89 361 178 92 361 minecraft:blue_terracotta
setblock 179 89 324 minecraft:dark_prismarine
fill 179 89 325 179 92 325 minecraft:blue_terracotta
setblock 179 89 332 minecraft:light[level=12]
setblock 179 89 339 minecraft:light[level=12]
setblock 179 89 346 minecraft:light[level=12]
setblock 179 89 353 minecraft:light[level=12]
setblock 179 89 360 minecraft:light[level=12]
setblock 180 89 323 minecraft:dark_prismarine
fill 180 89 324 180 92 324 minecraft:blue_terracotta
fill 180 89 326 181 89 326 minecraft:blue_terracotta
setblock 180 89 358 minecraft:dark_prismarine
fill 180 89 359 180 92 359 minecraft:blue_terracotta
setblock 180 89 363 minecraft:dark_prismarine
fill 181 89 323 181 92 323 minecraft:blue_terracotta
fill 181 89 325 181 90 325 minecraft:blue_terracotta
setblock 181 89 327 minecraft:dark_prismarine
fill 181 89 328 181 92 328 minecraft:blue_terracotta
setblock 181 89 338 minecraft:blue_terracotta
setblock 181 89 342 minecraft:dark_prismarine
fill 181 89 343 181 92 343 minecraft:blue_terracotta
setblock 181 89 346 minecraft:blue_terracotta
setblock 181 89 347 minecraft:dark_prismarine
fill 181 89 348 181 92 348 minecraft:blue_terracotta
fill 181 89 350 181 89 351 minecraft:blue_terracotta
setblock 181 89 352 minecraft:dark_prismarine
fill 181 89 353 181 92 353 minecraft:blue_terracotta
setblock 181 89 357 minecraft:dark_prismarine
fill 181 89 358 181 92 358 minecraft:blue_terracotta
setblock 181 89 362 minecraft:dark_prismarine
fill 181 89 363 181 92 363 minecraft:blue_terracotta
setblock 182 89 326 minecraft:dark_prismarine
fill 182 89 327 182 92 327 minecraft:blue_terracotta
setblock 182 89 331 minecraft:dark_prismarine
fill 182 89 332 182 92 332 minecraft:blue_terracotta
setblock 182 89 336 minecraft:dark_prismarine
fill 182 89 337 182 92 337 minecraft:blue_terracotta
setblock 182 89 341 minecraft:dark_prismarine
fill 182 89 342 182 92 342 minecraft:blue_terracotta
setblock 182 89 346 minecraft:dark_prismarine
fill 182 89 347 182 92 347 minecraft:blue_terracotta
setblock 182 89 350 minecraft:blue_terracotta
setblock 182 89 351 minecraft:dark_prismarine
fill 182 89 352 182 92 352 minecraft:blue_terracotta
setblock 182 89 356 minecraft:dark_prismarine
fill 182 89 357 182 92 357 minecraft:blue_terracotta
setblock 182 89 361 minecraft:dark_prismarine
fill 182 89 362 182 92 362 minecraft:blue_terracotta
setblock 142 90 325 minecraft:dark_prismarine
fill 142 90 326 142 93 326 minecraft:blue_terracotta
setblock 142 90 330 minecraft:dark_prismarine
fill 142 90 331 142 93 331 minecraft:blue_terracotta
setblock 142 90 335 minecraft:dark_prismarine
fill 142 90 336 142 90 339 minecraft:blue_terracotta
setblock 142 90 340 minecraft:dark_prismarine
fill 142 90 341 142 90 344 minecraft:blue_terracotta
setblock 142 90 345 minecraft:dark_prismarine
fill 142 90 346 142 93 346 minecraft:blue_terracotta
setblock 142 90 350 minecraft:dark_prismarine
fill 142 90 351 142 93 351 minecraft:blue_terracotta
setblock 142 90 355 minecraft:dark_prismarine
fill 142 90 356 142 93 356 minecraft:blue_terracotta
setblock 142 90 360 minecraft:dark_prismarine
fill 142 90 361 142 93 361 minecraft:blue_terracotta
setblock 143 90 324 minecraft:dark_prismarine
fill 143 90 325 143 93 325 minecraft:blue_terracotta
setblock 143 90 339 minecraft:dark_prismarine
fill 143 90 340 143 90 343 minecraft:blue_terracotta
setblock 143 90 344 minecraft:dark_prismarine
fill 143 90 345 143 93 345 minecraft:blue_terracotta
setblock 143 90 348 minecraft:blue_terracotta
setblock 143 90 349 minecraft:dark_prismarine
fill 143 90 350 143 93 350 minecraft:blue_terracotta
setblock 143 90 354 minecraft:dark_prismarine
fill 143 90 355 143 93 355 minecraft:blue_terracotta
setblock 143 90 359 minecraft:dark_prismarine
fill 143 90 360 143 93 360 minecraft:blue_terracotta
setblock 144 90 323 minecraft:dark_prismarine
fill 144 90 324 144 93 324 minecraft:blue_terracotta
setblock 144 90 339 minecraft:blue_terracotta
fill 144 90 341 144 90 342 minecraft:blue_terracotta
setblock 144 90 343 minecraft:dark_prismarine
fill 144 90 344 144 93 344 minecraft:blue_terracotta
setblock 144 90 348 minecraft:dark_prismarine
fill 144 90 349 144 93 349 minecraft:blue_terracotta
setblock 144 90 353 minecraft:dark_prismarine
setblock 144 90 358 minecraft:dark_prismarine
setblock 144 90 359 minecraft:blue_terracotta
setblock 144 90 363 minecraft:dark_prismarine
fill 145 90 323 145 93 323 minecraft:blue_terracotta
setblock 145 90 342 minecraft:dark_prismarine
fill 145 90 343 145 91 343 minecraft:blue_terracotta
setblock 145 90 347 minecraft:dark_prismarine
fill 145 90 348 145 92 348 minecraft:blue_terracotta
setblock 145 90 362 minecraft:dark_prismarine
fill 145 90 363 145 93 363 minecraft:blue_terracotta
fill 146 90 362 146 91 362 minecraft:blue_terracotta
setblock 148 90 323 minecraft:blue_terracotta
fill 148 90 364 148 128 364 minecraft:black_concrete
setblock 149 90 323 minecraft:dark_prismarine
setblock 149 90 363 minecraft:dark_prismarine
fill 150 90 323 153 90 323 minecraft:blue_terracotta
setblock 150 90 363 minecraft:blue_terracotta
setblock 154 90 323 minecraft:dark_prismarine
setblock 154 90 363 minecraft:dark_prismarine
fill 155 90 322 155 131 322 minecraft:black_concrete
fill 155 90 323 155 93 323 minecraft:blue_terracotta
fill 155 90 363 158 90 363 minecraft:blue_terracotta
fill 156 90 324 157 90 324 minecraft:blue_terracotta
setblock 158 90 324 minecraft:dark_prismarine
fill 158 90 325 158 93 325 minecraft:blue_terracotta
fill 158 90 362 159 90 362 minecraft:blue_terracotta
setblock 159 90 323 minecraft:dark_prismarine
fill 159 90 324 159 93 324 minecraft:blue_terracotta
fill 159 90 355 159 102 355 minecraft:magenta_terracotta
setblock 159 90 363 minecraft:dark_prismarine
fill 160 90 323 160 93 323 minecraft:blue_terracotta
setblock 160 90 362 minecraft:dark_prismarine
fill 160 90 363 160 93 363 minecraft:blue_terracotta
setblock 161 90 326 minecraft:dark_prismarine
fill 161 90 362 161 93 362 minecraft:blue_terracotta
setblock 162 90 324 minecraft:blue_terracotta
setblock 162 90 325 minecraft:dark_prismarine
fill 162 90 326 162 93 326 minecraft:blue_terracotta
setblock 163 90 324 minecraft:dark_prismarine
fill 163 90 325 163 93 325 minecraft:blue_terracotta
setblock 164 90 323 minecraft:dark_prismarine
fill 164 90 324 164 93 324 minecraft:blue_terracotta
setblock 164 90 363 minecraft:dark_prismarine
fill 165 90 323 165 93 323 minecraft:blue_terracotta
setblock 165 90 362 minecraft:dark_prismarine
fill 165 90 363 165 93 363 minecraft:blue_terracotta
setblock 166 90 325 minecraft:blue_terracotta
setblock 166 90 326 minecraft:dark_prismarine
fill 166 90 362 166 91 362 minecraft:blue_terracotta
setblock 167 90 325 minecraft:dark_prismarine
setblock 168 90 324 minecraft:dark_prismarine
fill 168 90 325 168 93 325 minecraft:blue_terracotta
setblock 169 90 323 minecraft:dark_prismarine
fill 169 90 324 172 90 324 minecraft:blue_terracotta
setblock 169 90 363 minecraft:dark_prismarine
fill 170 90 323 170 93 323 minecraft:blue_terracotta
setblock 170 90 362 minecraft:dark_prismarine
fill 170 90 363 170 93 363 minecraft:blue_terracotta
setblock 171 90 362 minecraft:blue_terracotta
setblock 173 90 324 minecraft:dark_prismarine
setblock 174 90 323 minecraft:dark_prismarine
fill 174 90 324 174 93 324 minecraft:blue_terracotta
setblock 174 90 362 minecraft:blue_terracotta
setblock 174 90 363 minecraft:dark_prismarine
fill 175 90 323 175 93 323 minecraft:blue_terracotta
fill 175 90 325 176 90 325 minecraft:blue_terracotta
setblock 175 90 362 minecraft:dark_prismarine
fill 175 90 363 175 93 363 minecraft:blue_terracotta
fill 176 90 362 176 93 362 minecraft:blue_terracotta
setblock 177 90 325 minecraft:dark_prismarine
fill 177 90 361 177 92 361 minecraft:blue_terracotta
setblock 178 90 324 minecraft:dark_prismarine
fill 178 90 325 178 93 325 minecraft:blue_terracotta
setblock 179 90 323 minecraft:dark_prismarine
fill 179 90 324 179 93 324 minecraft:blue_terracotta
setblock 179 90 363 minecraft:dark_prismarine
fill 180 90 323 180 93 323 minecraft:blue_terracotta
setblock 180 90 326 minecraft:blue_terracotta
setblock 180 90 327 minecraft:dark_prismarine
fill 180 90 343 180 90 346 minecraft:blue_terracotta
setblock 180 90 347 minecraft:dark_prismarine
fill 180 90 358 180 92 358 minecraft:blue_terracotta
setblock 180 90 362 minecraft:dark_prismarine
fill 180 90 363 180 93 363 minecraft:blue_terracotta
setblock 181 90 326 minecraft:dark_prismarine
fill 181 90 327 181 93 327 minecraft:blue_terracotta
fill 181 90 329 182 90 329 minecraft:blue_terracotta
setblock 181 90 341 minecraft:dark_prismarine
fill 181 90 342 181 93 342 minecraft:blue_terracotta
setblock 181 90 345 minecraft:blue_terracotta
setblock 181 90 346 minecraft:dark_prismarine
fill 181 90 347 181 93 347 minecraft:blue_terracotta
setblock 181 90 350 minecraft:blue_terracotta
setblock 181 90 351 minecraft:dark_prismarine
fill 181 90 352 181 93 352 minecraft:blue_terracotta
setblock 181 90 356 minecraft:dark_prismarine
fill 181 90 357 181 93 357 minecraft:blue_terracotta
setblock 181 90 361 minecraft:dark_prismarine
fill 181 90 362 181 93 362 minecraft:blue_terracotta
setblock 182 90 325 minecraft:dark_prismarine
fill 182 90 326 182 93 326 minecraft:blue_terracotta
setblock 182 90 330 minecraft:dark_prismarine
fill 182 90 331 182 93 331 minecraft:blue_terracotta
setblock 182 90 335 minecraft:dark_prismarine
fill 182 90 336 182 91 336 minecraft:blue_terracotta
setblock 182 90 340 minecraft:dark_prismarine
fill 182 90 341 182 93 341 minecraft:blue_terracotta
setblock 182 90 345 minecraft:dark_prismarine
fill 182 90 346 182 93 346 minecraft:blue_terracotta
setblock 182 90 350 minecraft:dark_prismarine
fill 182 90 351 182 93 351 minecraft:blue_terracotta
setblock 182 90 355 minecraft:dark_prismarine
fill 182 90 356 182 93 356 minecraft:blue_terracotta
setblock 182 90 360 minecraft:dark_prismarine
fill 182 90 361 182 93 361 minecraft:blue_terracotta
setblock 142 91 323 minecraft:blue_terracotta
setblock 142 91 324 minecraft:dark_prismarine
fill 142 91 325 142 94 325 minecraft:blue_terracotta
setblock 142 91 328 minecraft:blue_terracotta
setblock 142 91 329 minecraft:dark_prismarine
fill 142 91 330 142 94 330 minecraft:blue_terracotta
setblock 142 91 334 minecraft:dark_prismarine
fill 142 91 335 142 91 338 minecraft:blue_terracotta
setblock 142 91 339 minecraft:dark_prismarine
fill 142 91 340 142 91 343 minecraft:blue_terracotta
setblock 142 91 344 minecraft:dark_prismarine
fill 142 91 345 142 94 345 minecraft:blue_terracotta
setblock 142 91 349 minecraft:dark_prismarine
fill 142 91 350 142 94 350 minecraft:blue_terracotta
setblock 142 91 354 minecraft:dark_prismarine
fill 142 91 355 142 94 355 minecraft:blue_terracotta
setblock 142 91 359 minecraft:dark_prismarine
fill 142 91 360 142 94 360 minecraft:blue_terracotta
setblock 143 91 323 minecraft:dark_prismarine
fill 143 91 324 143 94 324 minecraft:blue_terracotta
setblock 143 91 328 minecraft:dark_prismarine
setblock 143 91 338 minecraft:dark_prismarine
fill 143 91 339 143 91 342 minecraft:blue_terracotta
setblock 143 91 343 minecraft:dark_prismarine
fill 143 91 344 143 94 344 minecraft:blue_terracotta
setblock 143 91 348 minecraft:dark_prismarine
fill 143 91 349 143 94 349 minecraft:blue_terracotta
setblock 143 91 352 minecraft:blue_terracotta
setblock 143 91 353 minecraft:dark_prismarine
fill 143 91 354 143 94 354 minecraft:blue_terracotta
setblock 143 91 358 minecraft:dark_prismarine
fill 143 91 359 143 92 359 minecraft:blue_terracotta
setblock 143 91 363 minecraft:dark_prismarine
fill 144 91 323 144 94 323 minecraft:blue_terracotta
setblock 144 91 341 minecraft:blue_terracotta
setblock 144 91 342 minecraft:dark_prismarine
fill 144 91 343 144 94 343 minecraft:blue_terracotta
setblock 144 91 346 minecraft:blue_terracotta
setblock 144 91 347 minecraft:dark_prismarine
fill 144 91 348 144 94 348 minecraft:blue_terracotta
setblock 144 91 352 minecraft:dark_prismarine
setblock 144 91 362 minecraft:dark_prismarine
fill 144 91 363 144 94 363 minecraft:blue_terracotta
setblock 145 91 342 minecraft:blue_terracotta
setblock 145 91 346 minecraft:dark_prismarine
fill 145 91 347 145 92 347 minecraft:blue_terracotta
fill 145 91 350 145 102 350 minecraft:magenta_terracotta
fill 145 91 362 145 92 362 minecraft:blue_terracotta
setblock 148 91 323 minecraft:dark_prismarine
setblock 148 91 363 minecraft:dark_prismarine
fill 149 91 323 152 91 323 minecraft:blue_terracotta
setblock 149 91 363 minecraft:blue_terracotta
fill 150 91 335 150 102 335 minecraft:magenta_terracotta
setblock 153 91 323 minecraft:dark_prismarine
fill 154 91 323 154 94 323 minecraft:blue_terracotta
fill 155 91 324 156 91 324 minecraft:blue_terracotta
fill 155 91 363 157 91 363 minecraft:blue_terracotta
setblock 157 91 324 minecraft:dark_prismarine
fill 157 91 325 157 94 325 minecraft:blue_terracotta
setblock 158 91 323 minecraft:dark_prismarine
fill 158 91 324 158 94 324 minecraft:blue_terracotta
setblock 158 91 363 minecraft:dark_prismarine
fill 159 91 323 159 94 323 minecraft:blue_terracotta
setblock 159 91 326 minecraft:blue_terracotta
setblock 159 91 362 minecraft:dark_prismarine
fill 159 91 363 159 94 363 minecraft:blue_terracotta
setblock 160 91 325 minecraft:blue_terracotta
setblock 160 91 326 minecraft:dark_prismarine
fill 160 91 362 160 92 362 minecraft:blue_terracotta
setblock 161 91 325 minecraft:dark_prismarine
fill 161 91 326 161 94 326 minecraft:blue_terracotta
setblock 162 91 324 minecraft:dark_prismarine
fill 162 91 325 162 94 325 minecraft:blue_terracotta
setblock 163 91 323 minecraft:dark_prismarine
fill 163 91 324 163 94 324 minecraft:blue_terracotta
fill 163 91 326 164 91 326 minecraft:blue_terracotta
setblock 163 91 363 minecraft:dark_prismarine
fill 164 91 323 164 94 323 minecraft:blue_terracotta
setblock 164 91 362 minecraft:dark_prismarine
fill 164 91 363 164 94 363 minecraft:blue_terracotta
setblock 165 91 326 minecraft:dark_prismarine
fill 165 91 362 165 92 362 minecraft:blue_terracotta
setblock 166 91 325 minecraft:dark_prismarine
setblock 166 91 326 minecraft:blue_terracotta
setblock 167 91 324 minecraft:dark_prismarine
fill 167 91 325 167 94 325 minecraft:blue_terracotta
fill 167 91 354 167 92 354 minecraft:black_concrete
setblock 168 91 323 minecraft:dark_prismarine
fill 168 91 324 171 91 324 minecraft:blue_terracotta
setblock 168 91 363 minecraft:dark_prismarine
fill 169 91 323 169 94 323 minecraft:blue_terracotta
fill 169 91 363 169 94 363 minecraft:blue_terracotta
setblock 169 91 364 minecraft:cyan_concrete
setblock 172 91 324 minecraft:dark_prismarine
setblock 173 91 323 minecraft:dark_prismarine
fill 173 91 324 173 94 324 minecraft:blue_terracotta
setblock 173 91 363 minecraft:dark_prismarine
fill 174 91 323 174 94 323 minecraft:blue_terracotta
fill 174 91 325 175 91 325 minecraft:blue_terracotta
setblock 174 91 362 minecraft:dark_prismarine
fill 174 91 363 174 94 363 minecraft:blue_terracotta
setblock 174 91 364 minecraft:cyan_concrete
fill 175 91 362 175 94 362 minecraft:blue_terracotta
setblock 176 91 325 minecraft:dark_prismarine
setblock 177 91 324 minecraft:dark_prismarine
fill 177 91 325 177 94 325 minecraft:blue_terracotta
setblock 178 91 323 minecraft:dark_prismarine
fill 178 91 324 178 94 324 minecraft:blue_terracotta
setblock 178 91 363 minecraft:dark_prismarine
fill 179 91 323 179 94 323 minecraft:blue_terracotta
fill 179 91 338 179 102 338 minecraft:magenta_terracotta
setblock 179 91 362 minecraft:dark_prismarine
fill 179 91 363 179 94 363 minecraft:blue_terracotta
setblock 180 91 326 minecraft:dark_prismarine
fill 180 91 327 180 94 327 minecraft:blue_terracotta
fill 180 91 343 180 91 345 minecraft:blue_terracotta
setblock 180 91 346 minecraft:dark_prismarine
fill 180 91 347 180 92 349 minecraft:blue_terracotta
setblock 180 91 361 minecraft:dark_prismarine
fill 180 91 362 180 94 362 minecraft:blue_terracotta
setblock 181 91 325 minecraft:dark_prismarine
fill 181 91 326 181 94 326 minecraft:blue_terracotta
setblock 181 91 329 minecraft:blue_terracotta
setblock 181 91 340 minecraft:dark_prismarine
fill 181 91 341 181 93 341 minecraft:blue_terracotta
setblock 181 91 345 minecraft:dark_prismarine
fill 181 91 346 181 94 346 minecraft:blue_terracotta
setblock 181 91 350 minecraft:dark_prismarine
fill 181 91 351 181 94 351 minecraft:blue_terracotta
setblock 181 91 355 minecraft:dark_prismarine
fill 181 91 356 181 94 356 minecraft:blue_terracotta
setblock 181 91 360 minecraft:dark_prismarine
fill 181 91 361 181 94 361 minecraft:blue_terracotta
setblock 182 91 324 minecraft:dark_prismarine
fill 182 91 325 182 94 325 minecraft:blue_terracotta
setblock 182 91 329 minecraft:dark_prismarine
fill 182 91 330 182 94 330 minecraft:blue_terracotta
setblock 182 91 334 minecraft:dark_prismarine
setblock 182 91 335 minecraft:blue_terracotta
setblock 182 91 339 minecraft:dark_prismarine
fill 182 91 340 182 94 340 minecraft:blue_terracotta
setblock 182 91 344 minecraft:dark_prismarine
fill 182 91 345 182 94 345 minecraft:blue_terracotta
setblock 182 91 349 minecraft:dark_prismarine
fill 182 91 350 182 94 350 minecraft:blue_terracotta
setblock 182 91 354 minecraft:dark_prismarine
fill 182 91 355 182 94 355 minecraft:blue_terracotta
setblock 182 91 359 minecraft:dark_prismarine
fill 182 91 360 182 94 360 minecraft:blue_terracotta
setblock 142 92 323 minecraft:dark_prismarine
fill 142 92 324 142 95 324 minecraft:blue_terracotta
setblock 142 92 327 minecraft:blue_terracotta
setblock 142 92 328 minecraft:dark_prismarine
fill 142 92 329 142 95 329 minecraft:blue_terracotta
setblock 142 92 333 minecraft:dark_prismarine
fill 142 92 334 142 92 337 minecraft:blue_terracotta
setblock 142 92 338 minecraft:dark_prismarine
fill 142 92 339 142 92 342 minecraft:blue_terracotta
setblock 142 92 343 minecraft:dark_prismarine
fill 142 92 344 142 95 344 minecraft:blue_terracotta
setblock 142 92 348 minecraft:dark_prismarine
fill 142 92 349 142 95 349 minecraft:blue_terracotta
setblock 142 92 353 minecraft:dark_prismarine
fill 142 92 354 142 95 354 minecraft:blue_terracotta
setblock 142 92 358 minecraft:dark_prismarine
fill 142 92 359 142 95 359 minecraft:blue_terracotta
setblock 142 92 363 minecraft:dark_prismarine
fill 143 92 323 143 95 323 minecraft:blue_terracotta
setblock 143 92 327 minecraft:dark_prismarine
setblock 143 92 328 minecraft:blue_terracotta
fill 143 92 338 143 92 341 minecraft:blue_terracotta
setblock 143 92 342 minecraft:dark_prismarine
fill 143 92 343 143 95 343 minecraft:blue_terracotta
setblock 143 92 347 minecraft:dark_prismarine
fill 143 92 348 143 95 348 minecraft:blue_terracotta
setblock 143 92 352 minecraft:dark_prismarine
fill 143 92 353 143 95 353 minecraft:blue_terracotta
setblock 143 92 357 minecraft:dark_prismarine
setblock 143 92 358 minecraft:blue_terracotta
setblock 143 92 362 minecraft:dark_prismarine
fill 143 92 363 143 95 363 minecraft:blue_terracotta
setblock 144 92 341 minecraft:dark_prismarine
fill 144 92 342 144 93 342 minecraft:blue_terracotta
setblock 144 92 346 minecraft:dark_prismarine
fill 144 92 347 144 95 347 minecraft:blue_terracotta
setblock 144 92 351 minecraft:dark_prismarine
setblock 144 92 352 minecraft:blue_terracotta
setblock 144 92 362 minecraft:blue_terracotta
setblock 145 92 345 minecraft:dark_prismarine
setblock 145 92 346 minecraft:blue_terracotta
setblock 147 92 323 minecraft:dark_prismarine
setblock 147 92 363 minecraft:dark_prismarine
fill 148 92 323 151 92 323 minecraft:blue_terracotta
setblock 152 92 323 minecraft:dark_prismarine
fill 153 92 323 153 95 323 minecraft:blue_terracotta
fill 154 92 324 155 92 324 minecraft:blue_terracotta
setblock 154 92 363 minecraft:purple_concrete
fill 155 92 363 156 92 363 minecraft:blue_terracotta
setblock 156 92 324 minecraft:dark_prismarine
setblock 157 92 323 minecraft:dark_prismarine
fill 157 92 324 157 95 324 minecraft:blue_terracotta
setblock 157 92 363 minecraft:dark_prismarine
fill 158 92 323 158 95 323 minecraft:blue_terracotta
fill 158 92 363 158 95 363 minecraft:blue_terracotta
setblock 159 92 326 minecraft:dark_prismarine
setblock 159 92 362 minecraft:blue_terracotta
setblock 160 92 325 minecraft:dark_prismarine
fill 160 92 326 160 95 326 minecraft:blue_terracotta
setblock 161 92 324 minecraft:dark_prismarine
fill 161 92 325 161 95 325 minecraft:blue_terracotta
setblock 162 92 323 minecraft:dark_prismarine
fill 162 92 324 162 95 324 minecraft:blue_terracotta
setblock 162 92 363 minecraft:dark_prismarine
fill 163 92 323 163 95 323 minecraft:blue_terracotta
setblock 163 92 326 minecraft:blue_terracotta
setblock 163 92 362 minecraft:dark_prismarine
fill 163 92 363 163 95 363 minecraft:blue_terracotta
setblock 164 92 326 minecraft:dark_prismarine
setblock 164 92 362 minecraft:blue_terracotta
setblock 165 92 325 minecraft:dark_prismarine
setblock 165 92 326 minecraft:blue_terracotta
setblock 166 92 324 minecraft:dark_prismarine
fill 166 92 325 166 94 325 minecraft:blue_terracotta
setblock 167 92 323 minecraft:dark_prismarine
fill 167 92 324 170 92 324 minecraft:blue_terracotta
fill 167 92 351 168 93 351 minecraft:dark_prismarine
setblock 167 92 363 minecraft:dark_prismarine
fill 168 92 323 168 95 323 minecraft:blue_terracotta
fill 168 92 363 168 94 363 minecraft:blue_terracotta
setblock 169 92 325 minecraft:blue_terracotta
fill 169 92 364 169 131 364 minecraft:black_concrete
setblock 171 92 324 minecraft:dark_prismarine
setblock 172 92 323 minecraft:dark_prismarine
fill 172 92 324 172 95 324 minecraft:blue_terracotta
setblock 172 92 363 minecraft:dark_prismarine
fill 173 92 323 173 95 323 minecraft:blue_terracotta
fill 173 92 363 173 95 363 minecraft:blue_terracotta
setblock 174 92 325 minecraft:blue_terracotta
fill 174 92 362 174 93 362 minecraft:blue_terracotta
fill 174 92 364 174 128 364 minecraft:black_concrete
setblock 175 92 325 minecraft:dark_prismarine
fill 175 92 352 175 102 352 minecraft:magenta_terracotta
setblock 176 92 324 minecraft:dark_prismarine
fill 176 92 325 176 95 325 minecraft:blue_terracotta
setblock 177 92 323 minecraft:dark_prismarine
fill 177 92 324 177 95 324 minecraft:blue_terracotta
setblock 177 92 363 minecraft:dark_prismarine
fill 178 92 323 178 95 323 minecraft:blue_terracotta
setblock 178 92 362 minecraft:dark_prismarine
fill 178 92 363 178 95 363 minecraft:blue_terracotta
setblock 179 92 361 minecraft:dark_prismarine
fill 179 92 362 179 95 362 minecraft:blue_terracotta
setblock 180 92 325 minecraft:dark_prismarine
fill 180 92 326 180 95 326 minecraft:blue_terracotta
fill 180 92 343 180 92 344 minecraft:blue_terracotta
setblock 180 92 345 minecraft:dark_prismarine
fill 180 92 346 180 95 346 minecraft:blue_terracotta
setblock 180 92 350 minecraft:dark_prismarine
fill 180 92 351 180 95 351 minecraft:blue_terracotta
setblock 180 92 360 minecraft:dark_prismarine
fill 180 92 361 180 94 361 minecraft:blue_terracotta
setblock 181 92 324 minecraft:dark_prismarine
fill 181 92 325 181 95 325 minecraft:blue_terracotta
setblock 181 92 329 minecraft:dark_prismarine
setblock 181 92 340 minecraft:blue_terracotta
setblock 181 92 344 minecraft:dark_prismarine
fill 181 92 345 181 95 345 minecraft:blue_terracotta
setblock 181 92 349 minecraft:dark_prismarine
fill 181 92 350 181 95 350 minecraft:blue_terracotta
setblock 181 92 354 minecraft:dark_prismarine
fill 181 92 355 181 95 355 minecraft:blue_terracotta
setblock 181 92 359 minecraft:dark_prismarine
fill 181 92 360 181 95 360 minecraft:blue_terracotta
setblock 182 92 323 minecraft:dark_prismarine
fill 182 92 324 182 95 324 minecraft:blue_terracotta
setblock 182 92 328 minecraft:dark_prismarine
fill 182 92 329 182 95 329 minecraft:blue_terracotta
setblock 182 92 338 minecraft:dark_prismarine
fill 182 92 339 182 93 339 minecraft:blue_terracotta
setblock 182 92 343 minecraft:dark_prismarine
fill 182 92 344 182 95 344 minecraft:blue_terracotta
setblock 182 92 348 minecraft:dark_prismarine
fill 182 92 349 182 95 349 minecraft:blue_terracotta
setblock 182 92 353 minecraft:dark_prismarine
fill 182 92 354 182 95 354 minecraft:blue_terracotta
setblock 182 92 358 minecraft:dark_prismarine
fill 182 92 359 182 95 359 minecraft:blue_terracotta
setblock 182 92 363 minecraft:dark_prismarine
setblock 183 92 339 minecraft:cyan_concrete
fill 183 92 346 183 127 348 minecraft:black_concrete
setblock 183 92 349 minecraft:light_blue_wool
fill 142 93 323 142 96 323 minecraft:blue_terracotta
setblock 142 93 327 minecraft:dark_prismarine
fill 142 93 328 142 96 328 minecraft:blue_terracotta
setblock 142 93 332 minecraft:dark_prismarine
fill 142 93 333 142 93 336 minecraft:blue_terracotta
setblock 142 93 337 minecraft:dark_prismarine
fill 142 93 338 142 93 341 minecraft:blue_terracotta
setblock 142 93 342 minecraft:dark_prismarine
fill 142 93 343 142 96 343 minecraft:blue_terracotta
setblock 142 93 347 minecraft:dark_prismarine
fill 142 93 348 142 96 348 minecraft:blue_terracotta
setblock 142 93 352 minecraft:dark_prismarine
fill 142 93 353 142 96 353 minecraft:blue_terracotta
setblock 142 93 357 minecraft:dark_prismarine
fill 142 93 358 142 95 358 minecraft:blue_terracotta
setblock 142 93 362 minecraft:dark_prismarine
fill 142 93 363 142 95 363 minecraft:blue_terracotta
setblock 143 93 326 minecraft:dark_prismarine
setblock 143 93 327 minecraft:blue_terracotta
fill 143 93 339 143 93 340 minecraft:blue_terracotta
setblock 143 93 341 minecraft:dark_prismarine
fill 143 93 342 143 95 342 minecraft:blue_terracotta
setblock 143 93 346 minecraft:dark_prismarine
fill 143 93 347 143 96 347 minecraft:blue_terracotta
setblock 143 93 351 minecraft:dark_prismarine
fill 143 93 352 143 96 352 minecraft:blue_terracotta
setblock 143 93 356 minecraft:dark_prismarine
setblock 143 93 361 minecraft:dark_prismarine
setblock 143 93 362 minecraft:blue_terracotta
setblock 144 93 325 minecraft:light[level=13]
setblock 144 93 333 minecraft:light[level=13]
setblock 144 93 341 minecraft:light[level=13]
setblock 144 93 345 minecraft:dark_prismarine
fill 144 93 346 144 95 346 minecraft:blue_terracotta
setblock 144 93 350 minecraft:dark_prismarine
fill 144 93 351 144 94 351 minecraft:blue_terracotta
setblock 144 93 357 minecraft:light[level=13]
fill 144 93 364 145 116 364 minecraft:black_concrete
fill 145 93 348 145 102 348 minecraft:magenta_terracotta
setblock 146 93 323 minecraft:dark_prismarine
setblock 146 93 363 minecraft:dark_prismarine
setblock 146 93 364 minecraft:light_blue_wool
setblock 147 93 323 minecraft:blue_terracotta
fill 147 93 364 147 127 364 minecraft:black_concrete
setblock 152 93 323 minecraft:blue_terracotta
setblock 152 93 325 minecraft:light[level=13]
setblock 152 93 333 minecraft:light[level=13]
setblock 152 93 341 minecraft:light[level=13]
setblock 152 93 349 minecraft:light[level=13]
setblock 152 93 357 minecraft:light[level=13]
setblock 154 93 324 minecraft:blue_terracotta
setblock 155 93 324 minecraft:dark_prismarine
setblock 156 93 323 minecraft:dark_prismarine
fill 156 93 324 156 95 325 minecraft:blue_terracotta
setblock 156 93 363 minecraft:dark_prismarine
fill 157 93 323 157 96 323 minecraft:blue_terracotta
fill 157 93 363 157 95 363 minecraft:blue_terracotta
setblock 158 93 326 minecraft:dark_prismarine
setblock 159 93 325 minecraft:dark_prismarine
fill 159 93 326 159 96 326 minecraft:blue_terracotta
setblock 160 93 324 minecraft:dark_prismarine
fill 160 93 325 160 96 325 minecraft:blue_terracotta
setblock 160 93 333 minecraft:light[level=13]
setblock 160 93 341 minecraft:light[level=13]
setblock 160 93 349 minecraft:light[level=13]
setblock 161 93 323 minecraft:dark_prismarine
fill 161 93 324 161 96 324 minecraft:blue_terracotta
setblock 161 93 363 minecraft:dark_prismarine
fill 162 93 323 162 96 323 minecraft:blue_terracotta
fill 162 93 356 162 94 356 minecraft:magenta_terracotta
setblock 162 93 362 minecraft:dark_prismarine
fill 162 93 363 162 96 363 minecraft:blue_terracotta
setblock 163 93 326 minecraft:dark_prismarine
setblock 164 93 325 minecraft:dark_prismarine
setblock 164 93 326 minecraft:blue_terracotta
setblock 165 93 324 minecraft:dark_prismarine
fill 165 93 325 165 95 325 minecraft:blue_terracotta
fill 165 93 331 165 102 331 minecraft:magenta_terracotta
setblock 166 93 323 minecraft:dark_prismarine
fill 166 93 324 169 93 324 minecraft:blue_terracotta
setblock 166 93 363 minecraft:dark_prismarine
fill 167 93 323 167 96 323 minecraft:blue_terracotta
fill 167 93 363 167 94 363 minecraft:blue_terracotta
setblock 168 93 333 minecraft:light[level=13]
setblock 168 93 341 minecraft:light[level=13]
setblock 168 93 349 minecraft:light[level=13]
setblock 168 93 357 minecraft:light[level=13]
setblock 170 93 324 minecraft:dark_prismarine
setblock 171 93 323 minecraft:dark_prismarine
fill 171 93 324 171 96 324 minecraft:blue_terracotta
setblock 171 93 363 minecraft:dark_prismarine
fill 172 93 323 172 96 323 minecraft:blue_terracotta
fill 172 93 363 172 96 363 minecraft:blue_terracotta
setblock 174 93 325 minecraft:dark_prismarine
fill 174 93 349 174 102 349 minecraft:magenta_terracotta
setblock 175 93 324 minecraft:dark_prismarine
fill 175 93 325 175 95 325 minecraft:blue_terracotta
setblock 176 93 323 minecraft:dark_prismarine
fill 176 93 324 176 96 324 minecraft:blue_terracotta
setblock 176 93 333 minecraft:light[level=13]
setblock 176 93 341 minecraft:light[level=13]
setblock 176 93 357 minecraft:light[level=13]
setblock 176 93 363 minecraft:dark_prismarine
fill 177 93 323 177 96 323 minecraft:blue_terracotta
setblock 177 93 362 minecraft:dark_prismarine
fill 177 93 363 177 96 363 minecraft:blue_terracotta
setblock 178 93 361 minecraft:dark_prismarine
fill 178 93 362 178 96 362 minecraft:blue_terracotta
setblock 179 93 325 minecraft:dark_prismarine
fill 179 93 361 179 94 361 minecraft:blue_terracotta
setblock 180 93 324 minecraft:dark_prismarine
fill 180 93 325 180 95 325 minecraft:blue_terracotta
setblock 180 93 344 minecraft:dark_prismarine
fill 180 93 345 180 94 345 minecraft:blue_terracotta
fill 180 93 347 180 93 348 minecraft:blue_terracotta
setblock 180 93 349 minecraft:dark_prismarine
fill 180 93 350 180 96 350 minecraft:blue_terracotta
fill 180 93 352 180 94 352 minecraft:blue_terracotta
setblock 180 93 359 minecraft:dark_prismarine
setblock 180 93 360 minecraft:blue_terracotta
setblock 181 93 323 minecraft:dark_prismarine
fill 181 93 324 181 96 324 minecraft:blue_terracotta
setblock 181 93 328 minecraft:dark_prismarine
fill 181 93 329 181 95 329 minecraft:blue_terracotta
setblock 181 93 343 minecraft:dark_prismarine
fill 181 93 344 181 96 344 minecraft:blue_terracotta
setblock 181 93 348 minecraft:dark_prismarine
fill 181 93 349 181 96 349 minecraft:blue_terracotta
setblock 181 93 353 minecraft:dark_prismarine
fill 181 93 354 181 96 354 minecraft:blue_terracotta
setblock 181 93 358 minecraft:dark_prismarine
fill 181 93 359 181 96 359 minecraft:blue_terracotta
setblock 181 93 363 minecraft:dark_prismarine
fill 182 93 323 182 96 323 minecraft:blue_terracotta
setblock 182 93 327 minecraft:dark_prismarine
fill 182 93 328 182 96 328 minecraft:blue_terracotta
setblock 182 93 332 minecraft:dark_prismarine
setblock 182 93 338 minecraft:blue_terracotta
setblock 182 93 342 minecraft:dark_prismarine
fill 182 93 343 182 96 343 minecraft:blue_terracotta
setblock 182 93 347 minecraft:dark_prismarine
fill 182 93 348 182 96 348 minecraft:blue_terracotta
setblock 182 93 352 minecraft:dark_prismarine
fill 182 93 353 182 96 353 minecraft:blue_terracotta
setblock 182 93 357 minecraft:dark_prismarine
fill 182 93 358 182 96 358 minecraft:blue_terracotta
setblock 182 93 362 minecraft:dark_prismarine
fill 182 93 363 182 96 363 minecraft:blue_terracotta
fill 183 93 339 183 131 339 minecraft:black_concrete
fill 183 93 349 183 103 349 minecraft:black_concrete
setblock 142 94 322 minecraft:cyan_concrete
setblock 142 94 326 minecraft:dark_prismarine
fill 142 94 327 142 97 327 minecraft:blue_terracotta
setblock 142 94 331 minecraft:dark_prismarine
fill 142 94 332 142 97 332 minecraft:blue_terracotta
fill 142 94 337 142 94 340 minecraft:blue_terracotta
setblock 142 94 341 minecraft:dark_prismarine
fill 142 94 342 142 97 342 minecraft:blue_terracotta
setblock 142 94 346 minecraft:dark_prismarine
fill 142 94 347 142 97 347 minecraft:blue_terracotta
setblock 142 94 351 minecraft:dark_prismarine
fill 142 94 352 142 97 352 minecraft:blue_terracotta
setblock 142 94 356 minecraft:dark_prismarine
fill 142 94 357 142 96 357 minecraft:blue_terracotta
setblock 142 94 361 minecraft:dark_prismarine
fill 142 94 362 142 95 362 minecraft:blue_terracotta
setblock 143 94 325 minecraft:dark_prismarine
setblock 143 94 326 minecraft:blue_terracotta
fill 143 94 335 143 94 336 minecraft:purple_concrete
setblock 143 94 340 minecraft:dark_prismarine
fill 143 94 341 143 95 341 minecraft:blue_terracotta
setblock 143 94 345 minecraft:dark_prismarine
fill 143 94 346 143 97 346 minecraft:blue_terracotta
setblock 143 94 350 minecraft:dark_prismarine
fill 143 94 351 143 97 351 minecraft:blue_terracotta
fill 144 94 334 145 94 334 minecraft:purple_concrete
fill 144 94 337 145 95 337 minecraft:purple_concrete
setblock 144 94 344 minecraft:dark_prismarine
fill 144 94 345 144 95 345 minecraft:blue_terracotta
setblock 144 94 349 minecraft:dark_prismarine
fill 144 94 350 144 95 350 minecraft:blue_terracotta
setblock 145 94 323 minecraft:dark_prismarine
fill 146 94 335 146 94 336 minecraft:purple_concrete
fill 146 94 364 146 131 364 minecraft:black_concrete
setblock 147 94 363 minecraft:purple_concrete
fill 152 94 323 152 95 323 minecraft:purple_concrete
fill 153 94 335 154 95 335 minecraft:dark_prismarine
setblock 154 94 324 minecraft:dark_prismarine
setblock 155 94 323 minecraft:dark_prismarine
fill 155 94 324 155 97 324 minecraft:blue_terracotta
fill 156 94 323 156 97 323 minecraft:blue_terracotta
setblock 158 94 325 minecraft:dark_prismarine
fill 158 94 326 158 96 326 minecraft:blue_terracotta
setblock 159 94 324 minecraft:dark_prismarine
fill 159 94 325 159 97 325 minecraft:blue_terracotta
setblock 160 94 323 minecraft:dark_prismarine
fill 160 94 324 160 97 324 minecraft:blue_terracotta
setblock 160 94 363 minecraft:dark_prismarine
fill 161 94 323 161 97 323 minecraft:blue_terracotta
fill 161 94 363 161 96 363 minecraft:blue_terracotta
setblock 162 94 326 minecraft:dark_prismarine
setblock 163 94 325 minecraft:dark_prismarine
setblock 163 94 326 minecraft:blue_terracotta
setblock 164 94 324 minecraft:dark_prismarine
fill 164 94 325 164 96 325 minecraft:blue_terracotta
setblock 165 94 323 minecraft:dark_prismarine
fill 165 94 324 168 94 324 minecraft:blue_terracotta
setblock 165 94 363 minecraft:dark_prismarine
fill 166 94 323 166 97 323 minecraft:blue_terracotta
setblock 166 94 363 minecraft:blue_terracotta
setblock 169 94 324 minecraft:dark_prismarine
setblock 170 94 323 minecraft:dark_prismarine
fill 170 94 324 170 95 324 minecraft:blue_terracotta
setblock 170 94 363 minecraft:dark_prismarine
fill 171 94 323 171 97 323 minecraft:blue_terracotta
setblock 171 94 363 minecraft:blue_terracotta
setblock 174 94 324 minecraft:dark_prismarine
setblock 175 94 323 minecraft:dark_prismarine
fill 175 94 324 175 97 324 minecraft:blue_terracotta
setblock 175 94 363 minecraft:dark_prismarine
fill 176 94 323 176 97 323 minecraft:blue_terracotta
setblock 176 94 362 minecraft:dark_prismarine
fill 176 94 363 176 97 363 minecraft:blue_terracotta
fill 177 94 362 177 97 362 minecraft:blue_terracotta
setblock 178 94 325 minecraft:dark_prismarine
setblock 178 94 339 minecraft:magenta_terracotta
setblock 179 94 324 minecraft:dark_prismarine
fill 179 94 325 179 96 325 minecraft:blue_terracotta
setblock 180 94 323 minecraft:dark_prismarine
fill 180 94 324 180 97 324 minecraft:blue_terracotta
setblock 180 94 347 minecraft:blue_terracotta
setblock 180 94 348 minecraft:dark_prismarine
fill 180 94 349 180 97 349 minecraft:blue_terracotta
setblock 180 94 363 minecraft:dark_prismarine
fill 181 94 323 181 97 323 minecraft:blue_terracotta
setblock 181 94 327 minecraft:dark_prismarine
fill 181 94 328 181 97 328 minecraft:blue_terracotta
setblock 181 94 342 minecraft:dark_prismarine
fill 181 94 343 181 95 343 minecraft:blue_terracotta
setblock 181 94 347 minecraft:dark_prismarine
fill 181 94 348 181 97 348 minecraft:blue_terracotta
setblock 181 94 352 minecraft:dark_prismarine
fill 181 94 353 181 97 353 minecraft:blue_terracotta
setblock 181 94 357 minecraft:dark_prismarine
fill 181 94 358 181 96 358 minecraft:blue_terracotta
setblock 181 94 362 minecraft:dark_prismarine
fill 181 94 363 181 97 363 minecraft:blue_terracotta
setblock 182 94 326 minecraft:dark_prismarine
fill 182 94 327 182 97 327 minecraft:blue_terracotta
setblock 182 94 331 minecraft:dark_prismarine
setblock 182 94 341 minecraft:dark_prismarine
fill 182 94 342 182 96 342 minecraft:blue_terracotta
setblock 182 94 346 minecraft:dark_prismarine
fill 182 94 347 182 97 347 minecraft:blue_terracotta
setblock 182 94 351 minecraft:dark_prismarine
fill 182 94 352 182 97 352 minecraft:blue_terracotta
setblock 182 94 356 minecraft:dark_prismarine
fill 182 94 357 182 97 357 minecraft:blue_terracotta
setblock 182 94 361 minecraft:dark_prismarine
fill 182 94 362 182 97 362 minecraft:blue_terracotta
fill 142 95 322 142 131 322 minecraft:black_concrete
setblock 142 95 325 minecraft:dark_prismarine
fill 142 95 326 142 97 326 minecraft:blue_terracotta
setblock 142 95 330 minecraft:dark_prismarine
fill 142 95 331 142 97 331 minecraft:blue_terracotta
fill 142 95 338 142 95 339 minecraft:blue_terracotta
setblock 142 95 340 minecraft:dark_prismarine
fill 142 95 341 142 97 341 minecraft:blue_terracotta
setblock 142 95 345 minecraft:dark_prismarine
fill 142 95 346 142 97 346 minecraft:blue_terracotta
setblock 142 95 350 minecraft:dark_prismarine
fill 142 95 351 142 97 351 minecraft:blue_terracotta
setblock 142 95 355 minecraft:dark_prismarine
fill 142 95 356 142 97 356 minecraft:blue_terracotta
setblock 142 95 360 minecraft:dark_prismarine
setblock 142 95 361 minecraft:blue_terracotta
setblock 143 95 336 minecraft:purple_concrete
setblock 143 95 344 minecraft:dark_prismarine
fill 143 95 345 143 97 345 minecraft:blue_terracotta
setblock 143 95 349 minecraft:dark_prismarine
fill 143 95 350 143 97 350 minecraft:blue_terracotta
setblock 143 95 354 minecraft:dark_prismarine
setblock 144 95 323 minecraft:dark_prismarine
setblock 144 95 325 minecraft:light[level=12]
setblock 144 95 332 minecraft:light[level=12]
setblock 144 95 339 minecraft:light[level=12]
setblock 144 95 348 minecraft:dark_prismarine
fill 144 95 349 144 96 349 minecraft:blue_terracotta
setblock 144 95 353 minecraft:light[level=12]
setblock 144 95 360 minecraft:light[level=12]
setblock 146 95 323 minecraft:purple_concrete
setblock 146 95 336 minecraft:purple_concrete
fill 148 95 337 148 102 337 minecraft:magenta_terracotta
setblock 151 95 325 minecraft:light[level=12]
setblock 151 95 332 minecraft:light[level=12]
setblock 151 95 339 minecraft:light[level=12]
setblock 151 95 346 minecraft:light[level=12]
setblock 151 95 353 minecraft:light[level=12]
setblock 151 95 360 minecraft:light[level=12]
setblock 153 95 363 minecraft:purple_concrete
setblock 154 95 323 minecraft:dark_prismarine
fill 154 95 324 154 97 324 minecraft:blue_terracotta
fill 155 95 323 155 97 323 minecraft:blue_terracotta
setblock 157 95 325 minecraft:dark_prismarine
setblock 158 95 324 minecraft:dark_prismarine
fill 158 95 325 158 97 325 minecraft:blue_terracotta
setblock 158 95 332 minecraft:light[level=12]
setblock 158 95 339 minecraft:light[level=12]
setblock 158 95 346 minecraft:light[level=12]
setblock 158 95 353 minecraft:light[level=12]
setblock 158 95 360 minecraft:light[level=12]
setblock 159 95 323 minecraft:dark_prismarine
fill 159 95 324 159 97 324 minecraft:blue_terracotta
setblock 159 95 363 minecraft:dark_prismarine
fill 160 95 323 160 97 323 minecraft:blue_terracotta
fill 160 95 363 160 96 363 minecraft:blue_terracotta
setblock 161 95 326 minecraft:dark_prismarine
setblock 162 95 325 minecraft:dark_prismarine
setblock 162 95 326 minecraft:blue_terracotta
setblock 163 95 324 minecraft:dark_prismarine
fill 163 95 325 163 97 325 minecraft:blue_terracotta
setblock 164 95 323 minecraft:dark_prismarine
fill 164 95 324 167 95 324 minecraft:blue_terracotta
setblock 164 95 363 minecraft:dark_prismarine
fill 165 95 323 165 97 323 minecraft:blue_terracotta
setblock 165 95 332 minecraft:light[level=12]
setblock 165 95 339 minecraft:light[level=12]
setblock 165 95 346 minecraft:light[level=12]
setblock 165 95 353 minecraft:light[level=12]
setblock 165 95 360 minecraft:light[level=12]
setblock 168 95 324 minecraft:dark_prismarine
setblock 169 95 323 minecraft:dark_prismarine
setblock 169 95 324 minecraft:blue_terracotta
fill 170 95 323 170 97 323 minecraft:blue_terracotta
setblock 172 95 325 minecraft:light[level=12]
setblock 172 95 332 minecraft:light[level=12]
setblock 172 95 339 minecraft:light[level=12]
setblock 172 95 346 minecraft:light[level=12]
setblock 172 95 353 minecraft:light[level=12]
setblock 172 95 360 minecraft:light[level=12]
setblock 173 95 324 minecraft:dark_prismarine
setblock 174 95 323 minecraft:dark_prismarine
fill 174 95 324 174 97 324 minecraft:blue_terracotta
setblock 174 95 363 minecraft:dark_prismarine
fill 175 95 323 175 97 323 minecraft:blue_terracotta
setblock 175 95 362 minecraft:dark_prismarine
fill 175 95 363 175 97 363 minecraft:blue_terracotta
fill 176 95 362 176 97 362 minecraft:blue_terracotta
setblock 177 95 325 minecraft:dark_prismarine
setblock 178 95 324 minecraft:dark_prismarine
fill 178 95 325 178 96 325 minecraft:blue_terracotta
setblock 179 95 323 minecraft:dark_prismarine
fill 179 95 324 179 97 324 minecraft:blue_terracotta
setblock 179 95 332 minecraft:light[level=12]
setblock 179 95 339 minecraft:light[level=12]
setblock 179 95 346 minecraft:light[level=12]
setblock 179 95 353 minecraft:light[level=12]
setblock 179 95 360 minecraft:light[level=12]
setblock 179 95 363 minecraft:dark_prismarine
fill 180 95 323 180 97 323 minecraft:blue_terracotta
setblock 180 95 347 minecraft:dark_prismarine
fill 180 95 348 180 97 348 minecraft:blue_terracotta
setblock 180 95 352 minecraft:dark_prismarine
fill 180 95 353 180 97 353 minecraft:blue_terracotta
setblock 180 95 362 minecraft:dark_prismarine
fill 180 95 363 180 97 363 minecraft:blue_terracotta
setblock 181 95 326 minecraft:dark_prismarine
fill 181 95 327 181 97 327 minecraft:blue_terracotta
setblock 181 95 346 minecraft:dark_prismarine
fill 181 95 347 181 97 347 minecraft:blue_terracotta
setblock 181 95 351 minecraft:dark_prismarine
fill 181 95 352 181 97 352 minecraft:blue_terracotta
setblock 181 95 356 minecraft:dark_prismarine
fill 181 95 357 181 97 357 minecraft:blue_terracotta
setblock 181 95 361 minecraft:dark_prismarine
fill 181 95 362 181 96 362 minecraft:blue_terracotta
setblock 182 95 325 minecraft:dark_prismarine
fill 182 95 326 182 97 326 minecraft:blue_terracotta
setblock 182 95 330 minecraft:dark_prismarine
setblock 182 95 331 minecraft:blue_terracotta
setblock 182 95 337 minecraft:purple_concrete
setblock 182 95 341 minecraft:blue_terracotta
setblock 182 95 345 minecraft:dark_prismarine
fill 182 95 346 182 97 346 minecraft:blue_terracotta
setblock 182 95 350 minecraft:dark_prismarine
fill 182 95 351 182 97 351 minecraft:blue_terracotta
setblock 182 95 355 minecraft:dark_prismarine
fill 182 95 356 182 97 356 minecraft:blue_terracotta
setblock 182 95 360 minecraft:dark_prismarine
fill 182 95 361 182 97 361 minecraft:blue_terracotta
setblock 142 96 324 minecraft:dark_prismarine
fill 142 96 325 142 97 325 minecraft:blue_terracotta
setblock 142 96 329 minecraft:dark_prismarine
fill 142 96 330 142 97 330 minecraft:blue_terracotta
setblock 142 96 336 minecraft:purple_concrete
setblock 142 96 339 minecraft:dark_prismarine
fill 142 96 340 142 97 340 minecraft:blue_terracotta
setblock 142 96 344 minecraft:dark_prismarine
fill 142 96 345 142 97 345 minecraft:blue_terracotta
setblock 142 96 349 minecraft:dark_prismarine
fill 142 96 350 142 97 350 minecraft:blue_terracotta
setblock 142 96 354 minecraft:dark_prismarine
fill 142 96 355 142 97 355 minecraft:blue_terracotta
setblock 143 96 343 minecraft:dark_prismarine
fill 143 96 344 143 97 344 minecraft:blue_terracotta
setblock 143 96 348 minecraft:dark_prismarine
fill 143 96 349 143 97 349 minecraft:blue_terracotta
setblock 143 96 353 minecraft:dark_prismarine
setblock 144 96 347 minecraft:dark_prismarine
setblock 144 96 348 minecraft:blue_terracotta
fill 150 96 341 152 97 341 minecraft:black_concrete
fill 151 96 340 151 97 340 minecraft:black_concrete
setblock 153 96 323 minecraft:dark_prismarine
fill 154 96 323 154 97 323 minecraft:blue_terracotta
setblock 156 96 324 minecraft:blue_terracotta
setblock 156 96 325 minecraft:dark_prismarine
setblock 157 96 324 minecraft:dark_prismarine
fill 157 96 325 157 97 325 minecraft:blue_terracotta
setblock 158 96 323 minecraft:dark_prismarine
fill 158 96 324 158 97 324 minecraft:blue_terracotta
setblock 158 96 363 minecraft:dark_prismarine
fill 159 96 323 159 97 323 minecraft:blue_terracotta
setblock 159 96 363 minecraft:blue_terracotta
setblock 160 96 326 minecraft:dark_prismarine
setblock 161 96 325 minecraft:dark_prismarine
setblock 161 96 326 minecraft:blue_terracotta
setblock 162 96 324 minecraft:dark_prismarine
fill 162 96 325 162 97 325 minecraft:blue_terracotta
setblock 163 96 323 minecraft:dark_prismarine
fill 163 96 324 166 96 324 minecraft:blue_terracotta
fill 164 96 323 164 97 323 minecraft:blue_terracotta
setblock 167 96 324 minecraft:dark_prismarine
setblock 168 96 323 minecraft:dark_prismarine
fill 169 96 323 169 97 323 minecraft:blue_terracotta
setblock 172 96 324 minecraft:dark_prismarine
setblock 173 96 323 minecraft:dark_prismarine
fill 173 96 324 173 97 324 minecraft:blue_terracotta
setblock 173 96 363 minecraft:dark_prismarine
fill 174 96 323 174 97 323 minecraft:blue_terracotta
fill 174 96 363 174 97 363 minecraft:blue_terracotta
setblock 176 96 325 minecraft:dark_prismarine
setblock 177 96 324 minecraft:dark_prismarine
setblock 177 96 325 minecraft:blue_terracotta
setblock 178 96 323 minecraft:dark_prismarine
fill 178 96 324 178 97 324 minecraft:blue_terracotta
setblock 178 96 363 minecraft:dark_prismarine
fill 179 96 323 179 97 323 minecraft:blue_terracotta
setblock 179 96 362 minecraft:dark_prismarine
fill 179 96 363 179 97 363 minecraft:blue_terracotta
fill 180 96 347 180 97 347 minecraft:blue_terracotta
setblock 180 96 351 minecraft:dark_prismarine
fill 180 96 352 180 97 352 minecraft:blue_terracotta
fill 180 96 362 180 97 362 minecraft:blue_terracotta
setblock 181 96 325 minecraft:dark_prismarine
fill 181 96 326 181 97 326 minecraft:blue_terracotta
setblock 181 96 345 minecraft:dark_prismarine
fill 181 96 346 181 97 346 minecraft:blue_terracotta
setblock 181 96 350 minecraft:dark_prismarine
fill 181 96 351 181 97 351 minecraft:blue_terracotta
setblock 181 96 355 minecraft:dark_prismarine
fill 181 96 356 181 97 356 minecraft:blue_terracotta
setblock 181 96 360 minecraft:dark_prismarine
setblock 181 96 361 minecraft:blue_terracotta
setblock 182 96 324 minecraft:dark_prismarine
fill 182 96 325 182 97 325 minecraft:blue_terracotta
setblock 182 96 329 minecraft:dark_prismarine
fill 182 96 330 182 97 330 minecraft:blue_terracotta
setblock 182 96 331 minecraft:purple_concrete
setblock 182 96 344 minecraft:dark_prismarine
fill 182 96 345 182 97 345 minecraft:blue_terracotta
setblock 182 96 349 minecraft:dark_prismarine
fill 182 96 350 182 97 350 minecraft:blue_terracotta
setblock 182 96 354 minecraft:dark_prismarine
fill 182 96 355 182 97 355 minecraft:blue_terracotta
setblock 182 96 359 minecraft:dark_prismarine
fill 182 96 360 182 97 360 minecraft:blue_terracotta
setblock 141 97 349 minecraft:cyan_concrete
setblock 142 97 328 minecraft:dark_prismarine
setblock 142 97 329 minecraft:blue_terracotta
setblock 142 97 343 minecraft:dark_prismarine
setblock 142 97 344 minecraft:blue_terracotta
setblock 142 97 348 minecraft:dark_prismarine
setblock 142 97 349 minecraft:blue_terracotta
setblock 142 97 353 minecraft:dark_prismarine
setblock 142 97 354 minecraft:blue_terracotta
setblock 142 97 361 minecraft:purple_concrete
setblock 143 97 347 minecraft:dark_prismarine
setblock 143 97 348 minecraft:blue_terracotta
setblock 143 97 352 minecraft:dark_prismarine
setblock 143 97 353 minecraft:blue_terracotta
setblock 146 97 363 minecraft:purple_concrete
setblock 153 97 323 minecraft:blue_terracotta
setblock 156 97 324 minecraft:dark_prismarine
setblock 156 97 325 minecraft:blue_terracotta
setblock 157 97 323 minecraft:dark_prismarine
setblock 157 97 324 minecraft:blue_terracotta
setblock 158 97 323 minecraft:blue_terracotta
setblock 159 97 326 minecraft:dark_prismarine
fill 159 97 358 159 102 358 minecraft:magenta_terracotta
setblock 160 97 325 minecraft:dark_prismarine
setblock 161 97 324 minecraft:dark_prismarine
setblock 161 97 325 minecraft:blue_terracotta
setblock 162 97 323 minecraft:dark_prismarine
fill 162 97 324 165 97 324 minecraft:blue_terracotta
setblock 163 97 323 minecraft:blue_terracotta
setblock 165 97 363 minecraft:purple_concrete
setblock 167 97 323 minecraft:dark_prismarine
setblock 168 97 323 minecraft:blue_terracotta
setblock 172 97 323 minecraft:dark_prismarine
setblock 172 97 324 minecraft:blue_terracotta
setblock 173 97 323 minecraft:blue_terracotta
setblock 173 97 363 minecraft:blue_terracotta
setblock 176 97 324 minecraft:dark_prismarine
setblock 177 97 323 minecraft:dark_prismarine
setblock 177 97 324 minecraft:blue_terracotta
setblock 177 97 363 minecraft:dark_prismarine
setblock 178 97 323 minecraft:blue_terracotta
setblock 178 97 362 minecraft:dark_prismarine
setblock 178 97 363 minecraft:blue_terracotta
setblock 179 97 362 minecraft:blue_terracotta
setblock 180 97 350 minecraft:dark_prismarine
setblock 180 97 351 minecraft:blue_terracotta
setblock 180 97 354 minecraft:blue_terracotta
setblock 181 97 324 minecraft:dark_prismarine
setblock 181 97 325 minecraft:blue_terracotta
setblock 181 97 345 minecraft:blue_terracotta
setblock 181 97 349 minecraft:dark_prismarine
setblock 181 97 350 minecraft:blue_terracotta
setblock 181 97 354 minecraft:dark_prismarine
setblock 181 97 355 minecraft:blue_terracotta
setblock 182 97 323 minecraft:dark_prismarine
setblock 182 97 324 minecraft:blue_terracotta
setblock 182 97 328 minecraft:dark_prismarine
setblock 182 97 329 minecraft:blue_terracotta
setblock 182 97 343 minecraft:dark_prismarine
setblock 182 97 344 minecraft:blue_terracotta
setblock 182 97 348 minecraft:dark_prismarine
setblock 182 97 349 minecraft:blue_terracotta
setblock 182 97 353 minecraft:dark_prismarine
setblock 182 97 354 minecraft:blue_terracotta
setblock 182 97 358 minecraft:dark_prismarine
setblock 182 97 359 minecraft:blue_terracotta
setblock 182 97 363 minecraft:dark_prismarine
fill 141 98 349 141 131 349 minecraft:black_concrete
fill 158 98 356 158 102 356 minecraft:magenta_terracotta
fill 178 98 339 178 102 339 minecraft:magenta_terracotta
fill 158 99 357 158 102 357 minecraft:magenta_terracotta
setblock 144 101 325 minecraft:light[level=13]
setblock 144 101 332 minecraft:light[level=12]
setblock 144 101 333 minecraft:light[level=13]
setblock 144 101 339 minecraft:light[level=12]
setblock 144 101 341 minecraft:light[level=13]
setblock 144 101 346 minecraft:light[level=12]
setblock 144 101 349 minecraft:light[level=13]
setblock 144 101 353 minecraft:light[level=12]
setblock 144 101 357 minecraft:light[level=13]
setblock 144 101 360 minecraft:light[level=12]
setblock 151 101 325 minecraft:light[level=12]
setblock 151 101 332 minecraft:light[level=12]
setblock 151 101 339 minecraft:light[level=12]
setblock 151 101 346 minecraft:light[level=12]
setblock 151 101 353 minecraft:light[level=12]
setblock 151 101 360 minecraft:light[level=12]
setblock 152 101 325 minecraft:light[level=13]
setblock 152 101 333 minecraft:light[level=13]
setblock 152 101 341 minecraft:light[level=13]
setblock 152 101 349 minecraft:light[level=13]
setblock 152 101 357 minecraft:light[level=13]
setblock 158 101 325 minecraft:light[level=12]
setblock 158 101 332 minecraft:light[level=12]
setblock 158 101 339 minecraft:light[level=12]
setblock 158 101 346 minecraft:light[level=12]
setblock 158 101 353 minecraft:light[level=12]
setblock 158 101 360 minecraft:light[level=12]
setblock 160 101 325 minecraft:light[level=13]
setblock 160 101 333 minecraft:light[level=13]
setblock 160 101 341 minecraft:light[level=13]
setblock 160 101 349 minecraft:light[level=13]
setblock 165 101 325 minecraft:light[level=12]
setblock 165 101 332 minecraft:light[level=12]
setblock 165 101 339 minecraft:light[level=12]
setblock 165 101 346 minecraft:light[level=12]
setblock 165 101 353 minecraft:light[level=12]
setblock 165 101 360 minecraft:light[level=12]
setblock 168 101 325 minecraft:light[level=13]
setblock 168 101 333 minecraft:light[level=13]
setblock 168 101 341 minecraft:light[level=13]
setblock 168 101 349 minecraft:light[level=13]
setblock 168 101 357 minecraft:light[level=13]
setblock 172 101 325 minecraft:light[level=12]
setblock 172 101 332 minecraft:light[level=12]
setblock 172 101 339 minecraft:light[level=12]
setblock 172 101 346 minecraft:light[level=12]
setblock 172 101 353 minecraft:light[level=12]
setblock 172 101 360 minecraft:light[level=12]
setblock 176 101 325 minecraft:light[level=13]
setblock 176 101 333 minecraft:light[level=13]
setblock 176 101 341 minecraft:light[level=13]
setblock 176 101 357 minecraft:light[level=13]
setblock 179 101 325 minecraft:light[level=12]
setblock 179 101 332 minecraft:light[level=12]
setblock 179 101 339 minecraft:light[level=12]
setblock 179 101 346 minecraft:light[level=12]
setblock 179 101 353 minecraft:light[level=12]
setblock 179 101 360 minecraft:light[level=12]
setblock 183 101 334 minecraft:light_blue_wool
fill 141 102 343 141 114 343 minecraft:black_concrete
setblock 141 102 344 minecraft:cyan_concrete
setblock 150 102 337 minecraft:magenta_terracotta
setblock 157 102 364 minecraft:light_blue_wool
setblock 166 102 330 minecraft:magenta_terracotta
setblock 180 102 364 minecraft:light_blue_wool
fill 183 102 334 183 131 334 minecraft:black_concrete
fill 141 103 344 141 131 344 minecraft:black_concrete
fill 142 103 332 157 103 354 minecraft:purple_terracotta
fill 143 103 331 181 103 331 minecraft:purple_terracotta
fill 143 103 355 181 103 355 minecraft:purple_terracotta
fill 144 103 329 180 103 330 minecraft:purple_terracotta
fill 144 103 356 180 103 357 minecraft:purple_terracotta
fill 145 103 328 179 103 328 minecraft:purple_terracotta
fill 145 103 358 179 103 358 minecraft:purple_terracotta
fill 146 103 327 178 103 327 minecraft:purple_terracotta
fill 146 103 359 178 103 359 minecraft:purple_terracotta
fill 147 103 326 177 103 326 minecraft:purple_terracotta
fill 147 103 360 177 103 360 minecraft:purple_terracotta
fill 148 103 325 176 103 325 minecraft:purple_terracotta
fill 148 103 361 176 103 361 minecraft:purple_terracotta
fill 150 103 324 174 103 324 minecraft:purple_terracotta
fill 150 103 362 174 103 362 minecraft:purple_terracotta
fill 151 103 323 173 103 323 minecraft:purple_terracotta
fill 151 103 363 173 103 363 minecraft:purple_terracotta
fill 157 103 364 157 127 364 minecraft:black_concrete
fill 158 103 332 158 103 342 minecraft:purple_terracotta
fill 158 103 346 158 103 354 minecraft:purple_terracotta
fill 159 103 332 182 103 341 minecraft:purple_terracotta
fill 159 103 347 182 103 354 minecraft:purple_terracotta
fill 162 103 342 182 103 342 minecraft:purple_terracotta
fill 162 103 346 182 103 346 minecraft:purple_terracotta
fill 163 103 343 182 103 345 minecraft:purple_terracotta
fill 180 103 364 180 129 364 minecraft:black_concrete
schedule function dropper:buildpart/75_6 1t
