setblock 48 126 589 minecraft:calcite
fill 48 126 590 48 128 590 minecraft:cobbled_deepslate
setblock 48 126 594 minecraft:calcite
fill 48 126 595 48 126 598 minecraft:cobbled_deepslate
fill 49 126 590 50 127 590 minecraft:light_blue_stained_glass
setblock 49 126 593 minecraft:calcite
fill 49 126 594 49 129 594 minecraft:cobbled_deepslate
fill 49 126 596 49 126 597 minecraft:cobbled_deepslate
setblock 49 126 598 minecraft:calcite
fill 50 126 592 52 128 592 minecraft:light_blue_stained_glass
setblock 50 126 593 minecraft:cobbled_deepslate
setblock 50 126 596 minecraft:cobbled_deepslate
setblock 50 126 597 minecraft:calcite
fill 50 126 598 50 129 598 minecraft:cobbled_deepslate
fill 51 126 558 53 126 558 minecraft:cobbled_deepslate
fill 51 126 591 51 128 591 minecraft:light_blue_stained_glass
fill 51 126 593 51 128 593 minecraft:light_blue_stained_glass
setblock 51 126 596 minecraft:calcite
fill 51 126 597 54 126 597 minecraft:cobbled_deepslate
fill 52 126 596 52 129 596 minecraft:cobbled_deepslate
setblock 53 126 580 minecraft:light_blue_stained_glass
fill 53 126 595 56 126 595 minecraft:cobbled_deepslate
setblock 54 126 558 minecraft:calcite
setblock 54 126 598 minecraft:calcite
fill 55 126 558 55 129 558 minecraft:cobbled_deepslate
setblock 55 126 597 minecraft:calcite
fill 55 126 598 55 129 598 minecraft:cobbled_deepslate
setblock 56 126 596 minecraft:calcite
fill 56 126 597 56 129 597 minecraft:cobbled_deepslate
setblock 57 126 595 minecraft:calcite
fill 57 126 596 57 129 596 minecraft:cobbled_deepslate
setblock 58 126 595 minecraft:cobbled_deepslate
setblock 59 126 558 minecraft:calcite
setblock 59 126 598 minecraft:calcite
fill 60 126 558 60 127 558 minecraft:cobbled_deepslate
setblock 60 126 597 minecraft:calcite
fill 60 126 598 60 129 598 minecraft:cobbled_deepslate
setblock 61 126 596 minecraft:calcite
fill 61 126 597 61 127 597 minecraft:cobbled_deepslate
setblock 64 126 598 minecraft:calcite
fill 71 126 598 73 126 598 minecraft:cobbled_deepslate
fill 73 126 597 74 126 597 minecraft:cobbled_deepslate
setblock 74 126 558 minecraft:calcite
fill 74 126 559 74 129 559 minecraft:cobbled_deepslate
setblock 74 126 598 minecraft:calcite
fill 75 126 558 75 129 558 minecraft:cobbled_deepslate
setblock 75 126 597 minecraft:calcite
fill 75 126 598 75 129 598 minecraft:cobbled_deepslate
fill 76 126 597 76 129 597 minecraft:cobbled_deepslate
setblock 77 126 596 minecraft:cobbled_deepslate
setblock 78 126 559 minecraft:calcite
setblock 79 126 558 minecraft:calcite
fill 79 126 559 79 129 559 minecraft:cobbled_deepslate
setblock 79 126 598 minecraft:calcite
fill 80 126 558 80 129 558 minecraft:cobbled_deepslate
setblock 80 126 596 minecraft:cobbled_deepslate
setblock 80 126 597 minecraft:calcite
fill 80 126 598 80 129 598 minecraft:cobbled_deepslate
fill 81 126 597 81 129 597 minecraft:cobbled_deepslate
fill 82 126 561 84 127 561 minecraft:light_blue_stained_glass
setblock 83 126 559 minecraft:calcite
fill 83 126 560 85 127 560 minecraft:light_blue_stained_glass
fill 83 126 562 85 127 562 minecraft:light_blue_stained_glass
setblock 84 126 558 minecraft:calcite
setblock 84 126 598 minecraft:calcite
fill 85 126 558 85 129 558 minecraft:cobbled_deepslate
fill 85 126 559 87 128 559 minecraft:light_blue_stained_glass
fill 85 126 563 88 128 563 minecraft:light_blue_stained_glass
setblock 85 126 597 minecraft:calcite
fill 85 126 598 85 129 598 minecraft:cobbled_deepslate
fill 86 126 597 86 127 597 minecraft:cobbled_deepslate
setblock 87 126 595 minecraft:calcite
fill 87 126 596 87 127 596 minecraft:cobbled_deepslate
setblock 88 126 559 minecraft:calcite
setblock 88 126 574 minecraft:calcite
setblock 88 126 594 minecraft:calcite
fill 88 126 595 88 129 595 minecraft:cobbled_deepslate
fill 48 127 579 51 127 581 minecraft:light_blue_stained_glass
setblock 48 127 593 minecraft:calcite
fill 48 127 594 48 127 597 minecraft:cobbled_deepslate
setblock 48 127 598 minecraft:calcite
fill 49 127 591 49 128 591 minecraft:light_blue_stained_glass
setblock 49 127 592 minecraft:calcite
fill 49 127 593 49 129 593 minecraft:cobbled_deepslate
setblock 49 127 596 minecraft:cobbled_deepslate
setblock 49 127 597 minecraft:calcite
fill 49 127 598 49 130 598 minecraft:cobbled_deepslate
fill 50 127 558 52 127 558 minecraft:cobbled_deepslate
fill 50 127 593 50 128 593 minecraft:light_blue_stained_glass
setblock 50 127 596 minecraft:calcite
fill 50 127 597 53 127 597 minecraft:cobbled_deepslate
fill 51 127 596 51 130 596 minecraft:cobbled_deepslate
fill 52 127 591 53 128 591 minecraft:light_blue_stained_glass
fill 52 127 593 53 128 593 minecraft:light_blue_stained_glass
setblock 53 127 558 minecraft:calcite
fill 53 127 592 54 128 592 minecraft:light_blue_stained_glass
fill 53 127 595 55 127 595 minecraft:cobbled_deepslate
setblock 53 127 598 minecraft:calcite
fill 54 127 558 54 130 558 minecraft:cobbled_deepslate
setblock 54 127 597 minecraft:calcite
fill 54 127 598 54 130 598 minecraft:cobbled_deepslate
setblock 55 127 596 minecraft:calcite
fill 55 127 597 55 130 597 minecraft:cobbled_deepslate
setblock 56 127 595 minecraft:calcite
fill 56 127 596 56 130 596 minecraft:cobbled_deepslate
setblock 57 127 595 minecraft:cobbled_deepslate
setblock 58 127 558 minecraft:calcite
setblock 58 127 598 minecraft:calcite
fill 59 127 558 59 129 558 minecraft:cobbled_deepslate
setblock 59 127 597 minecraft:calcite
fill 59 127 598 59 130 598 minecraft:cobbled_deepslate
setblock 60 127 596 minecraft:calcite
fill 60 127 597 60 128 597 minecraft:cobbled_deepslate
setblock 63 127 598 minecraft:calcite
fill 71 127 558 71 128 558 minecraft:cobbled_deepslate
fill 71 127 598 72 127 598 minecraft:cobbled_deepslate
setblock 73 127 558 minecraft:calcite
setblock 73 127 597 minecraft:cobbled_deepslate
setblock 73 127 598 minecraft:calcite
fill 74 127 558 74 130 558 minecraft:cobbled_deepslate
setblock 74 127 597 minecraft:calcite
fill 74 127 598 74 130 598 minecraft:cobbled_deepslate
fill 75 127 597 75 130 597 minecraft:cobbled_deepslate
setblock 77 127 559 minecraft:calcite
setblock 78 127 558 minecraft:calcite
fill 78 127 559 78 130 559 minecraft:cobbled_deepslate
setblock 78 127 598 minecraft:calcite
fill 79 127 558 79 130 558 minecraft:cobbled_deepslate
setblock 79 127 597 minecraft:calcite
fill 79 127 598 79 130 598 minecraft:cobbled_deepslate
fill 80 127 597 80 130 597 minecraft:cobbled_deepslate
setblock 82 127 559 minecraft:calcite
setblock 83 127 558 minecraft:calcite
setblock 83 127 598 minecraft:calcite
fill 84 127 558 84 130 558 minecraft:cobbled_deepslate
setblock 84 127 597 minecraft:calcite
fill 84 127 598 84 130 598 minecraft:cobbled_deepslate
setblock 85 127 597 minecraft:cobbled_deepslate
fill 87 127 564 87 128 564 minecraft:light_blue_stained_glass
setblock 88 127 558 minecraft:calcite
fill 88 127 559 88 130 559 minecraft:cobbled_deepslate
setblock 88 127 593 minecraft:calcite
fill 88 127 594 88 130 594 minecraft:cobbled_deepslate
setblock 88 127 598 minecraft:calcite
fill 48 128 579 49 128 581 minecraft:light_blue_stained_glass
setblock 48 128 592 minecraft:calcite
fill 48 128 593 48 128 596 minecraft:cobbled_deepslate
setblock 48 128 597 minecraft:calcite
fill 48 128 598 48 131 598 minecraft:cobbled_deepslate
setblock 49 128 590 minecraft:light_blue_stained_glass
setblock 49 128 592 minecraft:cobbled_deepslate
setblock 49 128 596 minecraft:calcite
fill 49 128 597 52 128 597 minecraft:cobbled_deepslate
fill 50 128 558 51 128 558 minecraft:cobbled_deepslate
setblock 50 128 580 minecraft:light_blue_stained_glass
setblock 50 128 595 minecraft:calcite
fill 50 128 596 50 129 596 minecraft:cobbled_deepslate
setblock 52 128 558 minecraft:calcite
setblock 52 128 598 minecraft:calcite
fill 53 128 558 53 131 558 minecraft:cobbled_deepslate
setblock 53 128 597 minecraft:calcite
fill 53 128 598 53 131 598 minecraft:cobbled_deepslate
setblock 54 128 596 minecraft:calcite
fill 54 128 597 54 131 597 minecraft:cobbled_deepslate
setblock 55 128 592 minecraft:light_blue_stained_glass
fill 55 128 596 55 131 596 minecraft:cobbled_deepslate
setblock 57 128 558 minecraft:calcite
setblock 57 128 598 minecraft:calcite
fill 58 128 558 58 131 558 minecraft:cobbled_deepslate
setblock 58 128 597 minecraft:calcite
fill 58 128 598 58 131 598 minecraft:cobbled_deepslate
fill 59 128 597 59 129 597 minecraft:cobbled_deepslate
setblock 62 128 598 minecraft:calcite
setblock 71 128 598 minecraft:cobbled_deepslate
setblock 72 128 558 minecraft:calcite
setblock 72 128 598 minecraft:calcite
fill 73 128 558 73 130 559 minecraft:cobbled_deepslate
setblock 73 128 597 minecraft:calcite
fill 73 128 598 73 131 598 minecraft:cobbled_deepslate
fill 74 128 597 74 131 597 minecraft:cobbled_deepslate
setblock 76 128 559 minecraft:calcite
setblock 77 128 558 minecraft:calcite
fill 77 128 559 77 131 559 minecraft:cobbled_deepslate
setblock 77 128 598 minecraft:calcite
fill 78 128 558 78 131 558 minecraft:cobbled_deepslate
setblock 78 128 597 minecraft:calcite
fill 78 128 598 78 131 598 minecraft:cobbled_deepslate
fill 79 128 597 79 131 597 minecraft:cobbled_deepslate
setblock 81 128 559 minecraft:calcite
setblock 82 128 558 minecraft:calcite
fill 82 128 559 82 129 559 minecraft:cobbled_deepslate
setblock 82 128 598 minecraft:calcite
fill 83 128 558 83 131 558 minecraft:cobbled_deepslate
fill 83 128 561 84 128 561 minecraft:light_blue_stained_glass
setblock 83 128 597 minecraft:calcite
fill 83 128 598 83 131 598 minecraft:cobbled_deepslate
fill 84 128 560 85 128 560 minecraft:light_blue_stained_glass
fill 84 128 562 85 128 562 minecraft:light_blue_stained_glass
setblock 87 128 558 minecraft:calcite
setblock 87 128 598 minecraft:calcite
fill 88 128 558 88 131 558 minecraft:cobbled_deepslate
fill 88 128 593 88 129 593 minecraft:cobbled_deepslate
setblock 88 128 597 minecraft:calcite
fill 88 128 598 88 131 598 minecraft:cobbled_deepslate
setblock 48 129 591 minecraft:calcite
fill 48 129 592 48 129 595 minecraft:cobbled_deepslate
setblock 48 129 596 minecraft:calcite
fill 48 129 597 51 129 597 minecraft:cobbled_deepslate
fill 49 129 558 50 129 558 minecraft:cobbled_deepslate
fill 49 129 592 51 129 592 minecraft:light_blue_stained_glass
setblock 49 129 595 minecraft:calcite
fill 49 129 596 49 132 596 minecraft:cobbled_deepslate
setblock 51 129 558 minecraft:calcite
setblock 51 129 598 minecraft:calcite
fill 52 129 558 52 132 558 minecraft:cobbled_deepslate
setblock 52 129 597 minecraft:calcite
fill 52 129 598 52 132 598 minecraft:cobbled_deepslate
setblock 53 129 596 minecraft:calcite
fill 53 129 597 53 132 597 minecraft:cobbled_deepslate
fill 54 129 596 54 132 596 minecraft:cobbled_deepslate
setblock 56 129 558 minecraft:calcite
setblock 56 129 598 minecraft:calcite
fill 57 129 558 57 132 558 minecraft:cobbled_deepslate
setblock 57 129 597 minecraft:calcite
fill 57 129 598 57 132 598 minecraft:cobbled_deepslate
fill 58 129 597 58 131 597 minecraft:cobbled_deepslate
setblock 61 129 598 minecraft:calcite
setblock 70 129 558 minecraft:cobbled_deepslate
setblock 70 129 598 minecraft:cobbled_deepslate
setblock 71 129 558 minecraft:calcite
setblock 71 129 598 minecraft:calcite
fill 72 129 558 72 131 559 minecraft:cobbled_deepslate
fill 72 129 598 72 132 598 minecraft:cobbled_deepslate
fill 73 129 597 73 132 597 minecraft:cobbled_deepslate
setblock 75 129 559 minecraft:calcite
setblock 76 129 558 minecraft:calcite
fill 76 129 559 76 132 559 minecraft:cobbled_deepslate
setblock 76 129 598 minecraft:calcite
fill 77 129 558 77 132 558 minecraft:cobbled_deepslate
setblock 77 129 597 minecraft:calcite
fill 77 129 598 77 132 598 minecraft:cobbled_deepslate
fill 78 129 597 78 132 597 minecraft:cobbled_deepslate
setblock 80 129 559 minecraft:calcite
setblock 81 129 558 minecraft:calcite
fill 81 129 559 81 132 559 minecraft:cobbled_deepslate
setblock 81 129 598 minecraft:calcite
fill 82 129 558 82 132 558 minecraft:cobbled_deepslate
fill 82 129 598 82 132 598 minecraft:cobbled_deepslate
setblock 84 129 561 minecraft:light_blue_stained_glass
setblock 85 129 560 minecraft:light_blue_stained_glass
setblock 85 129 562 minecraft:light_blue_stained_glass
setblock 86 129 558 minecraft:calcite
fill 86 129 559 87 129 559 minecraft:light_blue_stained_glass
fill 86 129 563 88 129 563 minecraft:light_blue_stained_glass
setblock 86 129 598 minecraft:calcite
fill 87 129 558 87 132 558 minecraft:cobbled_deepslate
setblock 87 129 597 minecraft:calcite
fill 87 129 598 87 132 598 minecraft:cobbled_deepslate
setblock 88 129 596 minecraft:calcite
fill 88 129 597 88 132 597 minecraft:cobbled_deepslate
fill 48 130 558 49 130 558 minecraft:cobbled_deepslate
fill 48 130 577 48 130 579 minecraft:cobbled_deepslate
fill 48 130 591 48 130 594 minecraft:cobbled_deepslate
setblock 48 130 595 minecraft:calcite
fill 48 130 596 48 132 597 minecraft:cobbled_deepslate
setblock 49 130 594 minecraft:calcite
fill 49 130 595 49 133 595 minecraft:cobbled_deepslate
fill 49 130 597 50 130 597 minecraft:cobbled_deepslate
setblock 50 130 558 minecraft:calcite
setblock 50 130 598 minecraft:calcite
fill 51 130 558 51 133 558 minecraft:cobbled_deepslate
setblock 51 130 597 minecraft:calcite
fill 51 130 598 51 133 598 minecraft:cobbled_deepslate
setblock 52 130 596 minecraft:calcite
fill 52 130 597 52 133 597 minecraft:cobbled_deepslate
fill 53 130 596 53 133 596 minecraft:cobbled_deepslate
setblock 55 130 558 minecraft:calcite
setblock 55 130 598 minecraft:calcite
fill 56 130 558 56 133 558 minecraft:cobbled_deepslate
setblock 56 130 597 minecraft:calcite
fill 56 130 598 56 133 598 minecraft:cobbled_deepslate
fill 57 130 597 57 132 597 minecraft:cobbled_deepslate
setblock 60 130 598 minecraft:calcite
setblock 61 130 598 minecraft:cobbled_deepslate
setblock 69 130 558 minecraft:cobbled_deepslate
setblock 70 130 558 minecraft:calcite
setblock 70 130 598 minecraft:calcite
fill 71 130 558 71 133 558 minecraft:cobbled_deepslate
fill 71 130 598 71 133 598 minecraft:cobbled_deepslate
setblock 74 130 559 minecraft:calcite
setblock 75 130 558 minecraft:calcite
fill 75 130 559 75 132 560 minecraft:cobbled_deepslate
setblock 75 130 598 minecraft:calcite
fill 76 130 558 76 133 558 minecraft:cobbled_deepslate
fill 76 130 560 77 130 560 minecraft:cobbled_deepslate
setblock 76 130 597 minecraft:calcite
fill 76 130 598 76 133 598 minecraft:cobbled_deepslate
fill 77 130 597 77 133 597 minecraft:cobbled_deepslate
setblock 79 130 559 minecraft:calcite
setblock 80 130 558 minecraft:calcite
fill 80 130 559 80 133 559 minecraft:cobbled_deepslate
setblock 80 130 598 minecraft:calcite
fill 81 130 558 81 133 558 minecraft:cobbled_deepslate
fill 81 130 598 81 133 598 minecraft:cobbled_deepslate
setblock 85 130 558 minecraft:calcite
setblock 85 130 598 minecraft:calcite
fill 86 130 558 86 133 558 minecraft:cobbled_deepslate
fill 86 130 560 87 130 561 minecraft:light_blue_stained_glass
fill 86 130 598 86 133 598 minecraft:cobbled_deepslate
fill 87 130 597 87 133 597 minecraft:cobbled_deepslate
setblock 88 130 560 minecraft:calcite
setblock 88 130 561 minecraft:light_blue_stained_glass
setblock 88 130 595 minecraft:calcite
fill 88 130 596 88 133 596 minecraft:cobbled_deepslate
setblock 48 131 558 minecraft:cobbled_deepslate
fill 48 131 576 48 131 578 minecraft:cobbled_deepslate
setblock 48 131 579 minecraft:calcite
fill 48 131 580 48 132 582 minecraft:cobbled_deepslate
fill 48 131 591 48 131 593 minecraft:cobbled_deepslate
setblock 48 131 594 minecraft:calcite
fill 48 131 595 48 134 595 minecraft:cobbled_deepslate
setblock 49 131 558 minecraft:calcite
fill 49 131 594 49 134 594 minecraft:cobbled_deepslate
setblock 49 131 597 minecraft:cobbled_deepslate
setblock 49 131 598 minecraft:calcite
fill 50 131 558 50 134 558 minecraft:cobbled_deepslate
setblock 50 131 597 minecraft:calcite
fill 50 131 598 50 134 598 minecraft:cobbled_deepslate
setblock 51 131 596 minecraft:calcite
fill 51 131 597 51 134 597 minecraft:cobbled_deepslate
fill 52 131 596 52 134 596 minecraft:cobbled_deepslate
setblock 54 131 558 minecraft:calcite
setblock 54 131 598 minecraft:calcite
fill 55 131 558 55 134 558 minecraft:cobbled_deepslate
setblock 55 131 597 minecraft:calcite
fill 55 131 598 55 134 598 minecraft:cobbled_deepslate
fill 56 131 597 56 134 597 minecraft:cobbled_deepslate
setblock 59 131 598 minecraft:calcite
setblock 60 131 598 minecraft:cobbled_deepslate
setblock 68 131 558 minecraft:cobbled_deepslate
setblock 69 131 558 minecraft:calcite
fill 70 131 558 70 134 558 minecraft:cobbled_deepslate
fill 70 131 598 70 134 598 minecraft:cobbled_deepslate
fill 71 131 559 71 132 559 minecraft:cobbled_deepslate
setblock 73 131 558 minecraft:cobbled_deepslate
setblock 73 131 559 minecraft:calcite
fill 73 131 560 74 133 560 minecraft:cobbled_deepslate
setblock 74 131 558 minecraft:calcite
fill 74 131 559 74 134 559 minecraft:cobbled_deepslate
setblock 74 131 598 minecraft:calcite
fill 75 131 558 75 134 558 minecraft:cobbled_deepslate
setblock 75 131 597 minecraft:calcite
fill 75 131 598 75 134 598 minecraft:cobbled_deepslate
setblock 76 131 560 minecraft:cobbled_deepslate
fill 76 131 597 76 134 597 minecraft:cobbled_deepslate
setblock 77 131 560 minecraft:calcite
setblock 78 131 559 minecraft:calcite
setblock 79 131 558 minecraft:calcite
fill 79 131 559 79 134 559 minecraft:cobbled_deepslate
setblock 79 131 598 minecraft:calcite
fill 80 131 558 80 134 558 minecraft:cobbled_deepslate
fill 80 131 598 80 134 598 minecraft:cobbled_deepslate
setblock 82 131 559 minecraft:cobbled_deepslate
setblock 84 131 558 minecraft:calcite
setblock 84 131 598 minecraft:calcite
fill 85 131 558 85 134 558 minecraft:cobbled_deepslate
fill 85 131 598 85 134 598 minecraft:cobbled_deepslate
setblock 88 131 559 minecraft:calcite
fill 88 131 560 88 134 560 minecraft:cobbled_deepslate
setblock 88 131 594 minecraft:calcite
fill 88 131 595 88 134 595 minecraft:cobbled_deepslate
setblock 48 132 558 minecraft:calcite
fill 48 132 559 48 135 559 minecraft:cobbled_deepslate
fill 48 132 575 48 132 577 minecraft:cobbled_deepslate
setblock 48 132 578 minecraft:calcite
fill 48 132 579 49 134 579 minecraft:cobbled_deepslate
setblock 48 132 583 minecraft:calcite
fill 48 132 584 48 133 586 minecraft:cobbled_deepslate
fill 48 132 591 48 132 592 minecraft:cobbled_deepslate
setblock 48 132 593 minecraft:calcite
fill 48 132 594 48 135 594 minecraft:cobbled_deepslate
setblock 48 132 598 minecraft:calcite
fill 49 132 558 49 135 558 minecraft:cobbled_deepslate
setblock 49 132 577 minecraft:calcite
fill 49 132 578 49 135 578 minecraft:cobbled_deepslate
fill 49 132 580 49 132 581 minecraft:cobbled_deepslate
setblock 49 132 582 minecraft:calcite
fill 49 132 583 49 135 583 minecraft:cobbled_deepslate
setblock 49 132 597 minecraft:calcite
fill 49 132 598 49 135 598 minecraft:cobbled_deepslate
setblock 50 132 560 minecraft:light[level=14]
setblock 50 132 568 minecraft:light[level=14]
setblock 50 132 576 minecraft:light[level=14]
setblock 50 132 584 minecraft:light[level=14]
setblock 50 132 592 minecraft:light[level=14]
fill 50 132 597 50 135 597 minecraft:cobbled_deepslate
fill 51 132 596 51 135 596 minecraft:cobbled_deepslate
setblock 53 132 558 minecraft:calcite
fill 53 132 559 53 135 559 minecraft:cobbled_deepslate
setblock 53 132 598 minecraft:calcite
fill 54 132 558 54 135 558 minecraft:cobbled_deepslate
setblock 54 132 597 minecraft:calcite
fill 54 132 598 54 135 598 minecraft:cobbled_deepslate
fill 55 132 597 55 135 597 minecraft:cobbled_deepslate
setblock 58 132 558 minecraft:calcite
setblock 58 132 560 minecraft:light[level=14]
setblock 58 132 568 minecraft:light[level=14]
setblock 58 132 576 minecraft:light[level=14]
setblock 58 132 584 minecraft:light[level=14]
setblock 58 132 592 minecraft:light[level=14]
setblock 58 132 598 minecraft:calcite
fill 59 132 598 59 133 598 minecraft:cobbled_deepslate
setblock 66 132 560 minecraft:light[level=14]
setblock 66 132 568 minecraft:light[level=14]
setblock 66 132 576 minecraft:light[level=14]
setblock 66 132 592 minecraft:light[level=14]
setblock 67 132 558 minecraft:cobbled_deepslate
setblock 68 132 558 minecraft:calcite
fill 69 132 558 69 134 559 minecraft:cobbled_deepslate
fill 69 132 598 69 135 598 minecraft:cobbled_deepslate
fill 70 132 559 70 133 559 minecraft:cobbled_deepslate
setblock 72 132 558 minecraft:cobbled_deepslate
setblock 72 132 559 minecraft:calcite
fill 72 132 560 72 135 560 minecraft:cobbled_deepslate
setblock 73 132 558 minecraft:calcite
fill 73 132 559 73 135 559 minecraft:cobbled_deepslate
setblock 73 132 598 minecraft:calcite
fill 74 132 558 74 135 558 minecraft:cobbled_deepslate
setblock 74 132 568 minecraft:light[level=14]
setblock 74 132 576 minecraft:light[level=14]
setblock 74 132 584 minecraft:light[level=14]
setblock 74 132 592 minecraft:light[level=14]
setblock 74 132 597 minecraft:calcite
fill 74 132 598 74 135 598 minecraft:cobbled_deepslate
fill 75 132 597 75 135 597 minecraft:cobbled_deepslate
setblock 76 132 560 minecraft:calcite
setblock 77 132 559 minecraft:calcite
fill 77 132 560 78 134 560 minecraft:cobbled_deepslate
setblock 78 132 558 minecraft:calcite
fill 78 132 559 78 135 559 minecraft:cobbled_deepslate
setblock 78 132 598 minecraft:calcite
fill 79 132 558 79 135 558 minecraft:cobbled_deepslate
fill 79 132 598 79 135 598 minecraft:cobbled_deepslate
setblock 82 132 559 minecraft:calcite
setblock 82 132 560 minecraft:light[level=14]
setblock 82 132 568 minecraft:light[level=14]
setblock 82 132 576 minecraft:light[level=14]
setblock 82 132 584 minecraft:light[level=14]
setblock 82 132 592 minecraft:light[level=14]
setblock 83 132 558 minecraft:calcite
setblock 83 132 598 minecraft:calcite
fill 84 132 558 84 135 558 minecraft:cobbled_deepslate
fill 84 132 598 84 135 598 minecraft:cobbled_deepslate
setblock 88 132 558 minecraft:calcite
fill 88 132 559 88 135 559 minecraft:cobbled_deepslate
fill 88 132 561 88 133 561 minecraft:cobbled_deepslate
setblock 88 132 593 minecraft:calcite
fill 88 132 594 88 135 594 minecraft:cobbled_deepslate
setblock 88 132 598 minecraft:calcite
fill 48 133 558 48 136 558 minecraft:cobbled_deepslate
fill 48 133 560 48 134 560 minecraft:cobbled_deepslate
fill 48 133 575 48 133 576 minecraft:cobbled_deepslate
setblock 48 133 577 minecraft:calcite
fill 48 133 578 48 136 578 minecraft:cobbled_deepslate
fill 48 133 580 48 133 581 minecraft:cobbled_deepslate
setblock 48 133 582 minecraft:calcite
fill 48 133 583 48 136 583 minecraft:cobbled_deepslate
setblock 48 133 587 minecraft:calcite
fill 48 133 588 48 133 591 minecraft:cobbled_deepslate
setblock 48 133 592 minecraft:calcite
fill 48 133 593 49 135 593 minecraft:cobbled_deepslate
setblock 48 133 596 minecraft:cobbled_deepslate
setblock 48 133 597 minecraft:calcite
fill 48 133 598 48 136 598 minecraft:cobbled_deepslate
setblock 49 133 576 minecraft:calcite
fill 49 133 577 49 136 577 minecraft:cobbled_deepslate
setblock 49 133 580 minecraft:cobbled_deepslate
setblock 49 133 581 minecraft:calcite
fill 49 133 582 50 135 582 minecraft:cobbled_deepslate
fill 49 133 584 49 133 585 minecraft:cobbled_deepslate
setblock 49 133 586 minecraft:calcite
setblock 49 133 596 minecraft:calcite
fill 49 133 597 49 136 597 minecraft:cobbled_deepslate
setblock 50 133 559 minecraft:cobbled_deepslate
fill 50 133 578 50 133 579 minecraft:cobbled_deepslate
setblock 50 133 580 minecraft:calcite
fill 50 133 581 50 136 581 minecraft:cobbled_deepslate
fill 50 133 583 50 134 583 minecraft:cobbled_deepslate
setblock 51 133 559 minecraft:calcite
setblock 52 133 558 minecraft:calcite
fill 52 133 559 52 136 559 minecraft:cobbled_deepslate
setblock 52 133 598 minecraft:calcite
fill 53 133 558 53 136 558 minecraft:cobbled_deepslate
setblock 53 133 597 minecraft:calcite
fill 53 133 598 53 136 598 minecraft:cobbled_deepslate
fill 54 133 559 55 133 559 minecraft:cobbled_deepslate
fill 54 133 597 54 136 597 minecraft:cobbled_deepslate
setblock 57 133 558 minecraft:calcite
setblock 57 133 598 minecraft:calcite
fill 58 133 558 59 135 558 minecraft:cobbled_deepslate
fill 58 133 598 58 135 598 minecraft:cobbled_deepslate
setblock 66 133 558 minecraft:cobbled_deepslate
setblock 67 133 558 minecraft:calcite
fill 68 133 558 68 135 559 minecraft:cobbled_deepslate
fill 68 133 598 68 136 598 minecraft:cobbled_deepslate
setblock 70 133 560 minecraft:calcite
setblock 71 133 559 minecraft:calcite
fill 71 133 560 71 136 560 minecraft:cobbled_deepslate
setblock 72 133 558 minecraft:calcite
fill 72 133 559 72 136 559 minecraft:cobbled_deepslate
setblock 72 133 597 minecraft:cobbled_deepslate
setblock 72 133 598 minecraft:calcite
fill 73 133 558 73 136 558 minecraft:cobbled_deepslate
setblock 73 133 597 minecraft:calcite
fill 73 133 598 73 136 598 minecraft:cobbled_deepslate
fill 74 133 597 74 136 597 minecraft:cobbled_deepslate
setblock 75 133 559 minecraft:cobbled_deepslate
setblock 75 133 560 minecraft:calcite
setblock 76 133 559 minecraft:calcite
fill 76 133 560 76 136 560 minecraft:cobbled_deepslate
setblock 77 133 558 minecraft:calcite
fill 77 133 559 77 136 559 minecraft:cobbled_deepslate
setblock 77 133 598 minecraft:calcite
fill 78 133 558 78 136 558 minecraft:cobbled_deepslate
setblock 78 133 597 minecraft:calcite
fill 78 133 598 78 136 598 minecraft:cobbled_deepslate
setblock 81 133 559 minecraft:calcite
setblock 82 133 558 minecraft:calcite
fill 82 133 559 85 133 559 minecraft:cobbled_deepslate
setblock 82 133 598 minecraft:calcite
fill 83 133 558 83 136 558 minecraft:cobbled_deepslate
fill 83 133 598 83 136 598 minecraft:cobbled_deepslate
setblock 86 133 559 minecraft:calcite
fill 86 133 597 86 134 597 minecraft:cobbled_deepslate
setblock 87 133 558 minecraft:calcite
fill 87 133 559 87 135 560 minecraft:cobbled_deepslate
fill 87 133 596 87 134 596 minecraft:cobbled_deepslate
setblock 87 133 598 minecraft:calcite
fill 88 133 558 88 136 558 minecraft:cobbled_deepslate
setblock 88 133 562 minecraft:calcite
setblock 88 133 577 minecraft:calcite
fill 88 133 578 88 133 581 minecraft:cobbled_deepslate
setblock 88 133 582 minecraft:calcite
fill 88 133 593 88 136 593 minecraft:cobbled_deepslate
setblock 88 133 597 minecraft:calcite
fill 88 133 598 88 136 598 minecraft:cobbled_deepslate
setblock 48 134 561 minecraft:calcite
fill 48 134 562 48 137 562 minecraft:cobbled_deepslate
fill 48 134 574 48 134 575 minecraft:cobbled_deepslate
setblock 48 134 576 minecraft:calcite
fill 48 134 577 48 137 577 minecraft:cobbled_deepslate
setblock 48 134 580 minecraft:cobbled_deepslate
setblock 48 134 581 minecraft:calcite
fill 48 134 582 48 137 582 minecraft:cobbled_deepslate
fill 48 134 584 48 134 585 minecraft:cobbled_deepslate
setblock 48 134 586 minecraft:calcite
fill 48 134 587 48 134 590 minecraft:cobbled_deepslate
setblock 48 134 591 minecraft:calcite
fill 48 134 592 49 136 592 minecraft:cobbled_deepslate
setblock 48 134 596 minecraft:calcite
fill 48 134 597 48 137 597 minecraft:cobbled_deepslate
setblock 49 134 559 minecraft:cobbled_deepslate
setblock 49 134 560 minecraft:calcite
setblock 49 134 575 minecraft:calcite
fill 49 134 576 49 137 576 minecraft:cobbled_deepslate
setblock 49 134 580 minecraft:calcite
fill 49 134 581 49 137 581 minecraft:cobbled_deepslate
setblock 49 134 584 minecraft:cobbled_deepslate
setblock 49 134 585 minecraft:calcite
fill 49 134 586 49 134 589 minecraft:cobbled_deepslate
setblock 49 134 590 minecraft:calcite
fill 49 134 591 49 137 591 minecraft:cobbled_deepslate
setblock 49 134 595 minecraft:calcite
fill 49 134 596 49 137 596 minecraft:cobbled_deepslate
setblock 50 134 559 minecraft:calcite
fill 50 134 577 50 134 578 minecraft:cobbled_deepslate
setblock 50 134 579 minecraft:calcite
fill 50 134 580 51 136 580 minecraft:cobbled_deepslate
setblock 50 134 584 minecraft:calcite
fill 50 134 585 50 136 586 minecraft:cobbled_deepslate
setblock 51 134 558 minecraft:calcite
fill 51 134 559 51 137 559 minecraft:cobbled_deepslate
fill 51 134 579 51 137 579 minecraft:cobbled_deepslate
fill 51 134 581 51 134 582 minecraft:cobbled_deepslate
setblock 51 134 583 minecraft:calcite
setblock 51 134 598 minecraft:calcite
fill 52 134 558 52 137 558 minecraft:cobbled_deepslate
setblock 52 134 597 minecraft:calcite
fill 52 134 598 52 137 598 minecraft:cobbled_deepslate
fill 53 134 597 53 137 597 minecraft:cobbled_deepslate
setblock 54 134 559 minecraft:cobbled_deepslate
setblock 55 134 559 minecraft:calcite
setblock 56 134 558 minecraft:calcite
fill 56 134 559 56 137 559 minecraft:cobbled_deepslate
setblock 56 134 598 minecraft:calcite
fill 57 134 558 57 137 558 minecraft:cobbled_deepslate
fill 57 134 598 57 136 598 minecraft:cobbled_deepslate
fill 64 134 558 65 134 558 minecraft:cobbled_deepslate
setblock 66 134 558 minecraft:calcite
fill 67 134 558 67 136 559 minecraft:cobbled_deepslate
setblock 69 134 560 minecraft:calcite
setblock 70 134 559 minecraft:calcite
fill 70 134 560 70 137 560 minecraft:cobbled_deepslate
setblock 71 134 558 minecraft:calcite
fill 71 134 559 71 137 559 minecraft:cobbled_deepslate
setblock 71 134 597 minecraft:cobbled_deepslate
setblock 71 134 598 minecraft:calcite
fill 72 134 558 72 137 558 minecraft:cobbled_deepslate
setblock 72 134 561 minecraft:cobbled_deepslate
setblock 72 134 597 minecraft:calcite
fill 72 134 598 72 137 598 minecraft:cobbled_deepslate
setblock 73 134 560 minecraft:cobbled_deepslate
setblock 73 134 561 minecraft:calcite
fill 73 134 597 73 137 597 minecraft:cobbled_deepslate
setblock 74 134 560 minecraft:calcite
fill 74 134 561 75 136 561 minecraft:cobbled_deepslate
setblock 75 134 559 minecraft:calcite
fill 75 134 560 75 137 560 minecraft:cobbled_deepslate
setblock 76 134 558 minecraft:calcite
fill 76 134 559 76 137 559 minecraft:cobbled_deepslate
setblock 76 134 598 minecraft:calcite
fill 77 134 558 77 137 558 minecraft:cobbled_deepslate
setblock 77 134 597 minecraft:calcite
fill 77 134 598 77 137 598 minecraft:cobbled_deepslate
setblock 79 134 560 minecraft:calcite
setblock 80 134 559 minecraft:calcite
setblock 81 134 558 minecraft:calcite
fill 81 134 559 84 134 559 minecraft:cobbled_deepslate
setblock 81 134 598 minecraft:calcite
fill 82 134 558 82 137 558 minecraft:cobbled_deepslate
fill 82 134 598 82 137 598 minecraft:cobbled_deepslate
setblock 85 134 559 minecraft:calcite
setblock 86 134 558 minecraft:calcite
fill 86 134 559 86 137 559 minecraft:cobbled_deepslate
setblock 86 134 598 minecraft:calcite
fill 87 134 558 87 137 558 minecraft:cobbled_deepslate
setblock 87 134 561 minecraft:cobbled_deepslate
setblock 87 134 597 minecraft:calcite
fill 87 134 598 87 137 598 minecraft:cobbled_deepslate
setblock 88 134 561 minecraft:calcite
fill 88 134 562 88 135 564 minecraft:cobbled_deepslate
setblock 88 134 576 minecraft:calcite
fill 88 134 577 88 134 580 minecraft:cobbled_deepslate
setblock 88 134 581 minecraft:calcite
fill 88 134 582 88 134 585 minecraft:cobbled_deepslate
setblock 88 134 586 minecraft:calcite
setblock 88 134 591 minecraft:calcite
fill 88 134 592 88 137 592 minecraft:cobbled_deepslate
setblock 88 134 596 minecraft:calcite
fill 88 134 597 88 137 597 minecraft:cobbled_deepslate
setblock 48 135 560 minecraft:calcite
fill 48 135 561 49 137 561 minecraft:cobbled_deepslate
fill 48 135 563 48 135 564 minecraft:cobbled_deepslate
setblock 48 135 574 minecraft:cobbled_deepslate
setblock 48 135 575 minecraft:calcite
fill 48 135 576 48 138 576 minecraft:cobbled_deepslate
setblock 48 135 579 minecraft:cobbled_deepslate
setblock 48 135 580 minecraft:calcite
fill 48 135 581 48 138 581 minecraft:cobbled_deepslate
setblock 48 135 584 minecraft:cobbled_deepslate
setblock 48 135 585 minecraft:calcite
fill 48 135 586 48 135 589 minecraft:cobbled_deepslate
setblock 48 135 590 minecraft:calcite
fill 48 135 591 48 138 591 minecraft:cobbled_deepslate
setblock 48 135 595 minecraft:calcite
fill 48 135 596 48 138 596 minecraft:cobbled_deepslate
setblock 49 135 559 minecraft:calcite
fill 49 135 560 49 138 560 minecraft:cobbled_deepslate
fill 49 135 575 49 138 575 minecraft:cobbled_deepslate
setblock 49 135 579 minecraft:calcite
fill 49 135 580 49 138 580 minecraft:cobbled_deepslate
setblock 49 135 584 minecraft:calcite
fill 49 135 585 49 135 588 minecraft:cobbled_deepslate
setblock 49 135 589 minecraft:calcite
fill 49 135 590 49 138 590 minecraft:cobbled_deepslate
setblock 49 135 594 minecraft:calcite
fill 49 135 595 49 138 595 minecraft:cobbled_deepslate
setblock 50 135 558 minecraft:calcite
fill 50 135 559 50 138 559 minecraft:cobbled_deepslate
fill 50 135 576 50 135 577 minecraft:cobbled_deepslate
setblock 50 135 578 minecraft:calcite
fill 50 135 579 50 138 579 minecraft:cobbled_deepslate
setblock 50 135 583 minecraft:calcite
fill 50 135 584 51 137 584 minecraft:cobbled_deepslate
setblock 50 135 587 minecraft:cobbled_deepslate
setblock 50 135 588 minecraft:calcite
setblock 50 135 596 minecraft:cobbled_deepslate
setblock 50 135 598 minecraft:calcite
fill 51 135 558 51 138 558 minecraft:cobbled_deepslate
fill 51 135 578 51 138 578 minecraft:cobbled_deepslate
setblock 51 135 581 minecraft:cobbled_deepslate
setblock 51 135 582 minecraft:calcite
fill 51 135 583 51 138 583 minecraft:cobbled_deepslate
fill 51 135 585 51 136 585 minecraft:cobbled_deepslate
setblock 51 135 597 minecraft:calcite
fill 51 135 598 51 138 598 minecraft:cobbled_deepslate
fill 52 135 597 52 138 597 minecraft:cobbled_deepslate
setblock 54 135 559 minecraft:calcite
setblock 55 135 558 minecraft:calcite
fill 55 135 559 55 138 559 minecraft:cobbled_deepslate
setblock 55 135 598 minecraft:calcite
fill 56 135 558 56 138 558 minecraft:cobbled_deepslate
fill 56 135 598 56 137 598 minecraft:cobbled_deepslate
setblock 60 135 558 minecraft:calcite
fill 61 135 558 64 135 558 minecraft:cobbled_deepslate
setblock 65 135 558 minecraft:calcite
fill 66 135 558 66 137 559 minecraft:cobbled_deepslate
fill 67 135 598 67 137 598 minecraft:cobbled_deepslate
setblock 68 135 560 minecraft:calcite
setblock 69 135 558 minecraft:cobbled_deepslate
setblock 69 135 559 minecraft:calcite
fill 69 135 560 69 138 560 minecraft:cobbled_deepslate
setblock 70 135 558 minecraft:calcite
fill 70 135 559 70 138 559 minecraft:cobbled_deepslate
fill 70 135 561 71 135 561 minecraft:cobbled_deepslate
setblock 70 135 598 minecraft:calcite
fill 71 135 558 71 138 558 minecraft:cobbled_deepslate
setblock 71 135 597 minecraft:calcite
fill 71 135 598 71 138 598 minecraft:cobbled_deepslate
setblock 72 135 561 minecraft:calcite
fill 72 135 597 72 138 597 minecraft:cobbled_deepslate
setblock 73 135 560 minecraft:calcite
fill 73 135 561 73 138 561 minecraft:cobbled_deepslate
setblock 74 135 559 minecraft:calcite
fill 74 135 560 74 138 560 minecraft:cobbled_deepslate
setblock 75 135 558 minecraft:calcite
fill 75 135 559 75 138 559 minecraft:cobbled_deepslate
setblock 75 135 598 minecraft:calcite
fill 76 135 558 76 138 558 minecraft:cobbled_deepslate
setblock 76 135 561 minecraft:cobbled_deepslate
setblock 76 135 597 minecraft:calcite
fill 76 135 598 76 138 598 minecraft:cobbled_deepslate
setblock 77 135 560 minecraft:cobbled_deepslate
setblock 77 135 597 minecraft:cobbled_deepslate
setblock 78 135 560 minecraft:calcite
setblock 79 135 559 minecraft:calcite
fill 79 135 560 80 137 560 minecraft:cobbled_deepslate
setblock 80 135 558 minecraft:calcite
fill 80 135 559 83 135 559 minecraft:cobbled_deepslate
setblock 80 135 598 minecraft:calcite
fill 81 135 558 81 138 558 minecraft:cobbled_deepslate
fill 81 135 598 81 138 598 minecraft:cobbled_deepslate
setblock 84 135 559 minecraft:calcite
setblock 85 135 558 minecraft:calcite
fill 85 135 559 85 138 559 minecraft:cobbled_deepslate
setblock 85 135 597 minecraft:cobbled_deepslate
setblock 85 135 598 minecraft:calcite
fill 86 135 558 86 138 558 minecraft:cobbled_deepslate
setblock 86 135 597 minecraft:calcite
fill 86 135 598 86 138 598 minecraft:cobbled_deepslate
setblock 87 135 561 minecraft:calcite
fill 87 135 562 87 138 562 minecraft:cobbled_deepslate
setblock 87 135 595 minecraft:cobbled_deepslate
setblock 87 135 596 minecraft:calcite
fill 87 135 597 87 138 597 minecraft:cobbled_deepslate
setblock 88 135 560 minecraft:calcite
fill 88 135 561 88 138 561 minecraft:cobbled_deepslate
setblock 88 135 565 minecraft:calcite
fill 88 135 576 88 135 579 minecraft:cobbled_deepslate
setblock 88 135 580 minecraft:calcite
fill 88 135 581 88 135 584 minecraft:cobbled_deepslate
setblock 88 135 585 minecraft:calcite
fill 88 135 586 88 135 589 minecraft:cobbled_deepslate
setblock 88 135 590 minecraft:calcite
fill 88 135 591 88 138 591 minecraft:cobbled_deepslate
setblock 88 135 595 minecraft:calcite
fill 88 135 596 88 138 596 minecraft:cobbled_deepslate
setblock 48 136 559 minecraft:calcite
fill 48 136 560 48 139 560 minecraft:cobbled_deepslate
setblock 48 136 563 minecraft:cobbled_deepslate
setblock 48 136 564 minecraft:calcite
fill 48 136 565 48 139 565 minecraft:cobbled_deepslate
setblock 48 136 573 minecraft:cobbled_deepslate
setblock 48 136 574 minecraft:calcite
fill 48 136 575 48 139 575 minecraft:cobbled_deepslate
setblock 48 136 579 minecraft:calcite
fill 48 136 580 48 139 580 minecraft:cobbled_deepslate
setblock 48 136 584 minecraft:calcite
fill 48 136 585 48 136 588 minecraft:cobbled_deepslate
setblock 48 136 589 minecraft:calcite
fill 48 136 590 48 139 590 minecraft:cobbled_deepslate
setblock 48 136 593 minecraft:cobbled_deepslate
setblock 48 136 594 minecraft:calcite
fill 48 136 595 48 139 595 minecraft:cobbled_deepslate
setblock 49 136 558 minecraft:calcite
fill 49 136 559 49 139 559 minecraft:cobbled_deepslate
setblock 49 136 562 minecraft:cobbled_deepslate
setblock 49 136 563 minecraft:calcite
fill 49 136 574 49 139 574 minecraft:cobbled_deepslate
setblock 49 136 578 minecraft:calcite
fill 49 136 579 49 139 579 minecraft:cobbled_deepslate
setblock 49 136 582 minecraft:cobbled_deepslate
setblock 49 136 583 minecraft:calcite
fill 49 136 584 49 136 587 minecraft:cobbled_deepslate
setblock 49 136 588 minecraft:calcite
fill 49 136 589 50 138 589 minecraft:cobbled_deepslate
setblock 49 136 593 minecraft:calcite
fill 49 136 594 49 139 594 minecraft:cobbled_deepslate
setblock 49 136 598 minecraft:calcite
fill 50 136 558 50 139 558 minecraft:cobbled_deepslate
setblock 50 136 576 minecraft:cobbled_deepslate
setblock 50 136 577 minecraft:calcite
fill 50 136 578 50 139 578 minecraft:cobbled_deepslate
setblock 50 136 582 minecraft:calcite
fill 50 136 583 50 139 583 minecraft:cobbled_deepslate
setblock 50 136 587 minecraft:calcite
fill 50 136 588 50 139 588 minecraft:cobbled_deepslate
fill 50 136 590 50 137 590 minecraft:cobbled_deepslate
setblock 50 136 597 minecraft:calcite
fill 50 136 598 50 139 598 minecraft:cobbled_deepslate
setblock 51 136 560 minecraft:cobbled_deepslate
setblock 51 136 581 minecraft:calcite
fill 51 136 582 52 138 582 minecraft:cobbled_deepslate
setblock 51 136 586 minecraft:calcite
fill 51 136 597 51 139 597 minecraft:cobbled_deepslate
setblock 52 136 560 minecraft:calcite
setblock 52 136 580 minecraft:calcite
fill 52 136 581 52 138 581 minecraft:cobbled_deepslate
fill 52 136 583 52 137 583 minecraft:cobbled_deepslate
setblock 53 136 559 minecraft:calcite
setblock 54 136 558 minecraft:calcite
fill 54 136 559 54 139 559 minecraft:cobbled_deepslate
setblock 54 136 598 minecraft:calcite
fill 55 136 558 55 139 558 minecraft:cobbled_deepslate
fill 55 136 598 55 138 598 minecraft:cobbled_deepslate
setblock 58 136 558 minecraft:cobbled_deepslate
setblock 59 136 558 minecraft:calcite
fill 60 136 558 63 136 558 minecraft:cobbled_deepslate
setblock 64 136 558 minecraft:calcite
fill 64 136 559 65 138 559 minecraft:cobbled_deepslate
fill 65 136 558 65 139 558 minecraft:cobbled_deepslate
setblock 67 136 560 minecraft:calcite
setblock 68 136 558 minecraft:cobbled_deepslate
setblock 68 136 559 minecraft:calcite
fill 68 136 560 68 139 560 minecraft:cobbled_deepslate
setblock 69 136 558 minecraft:calcite
fill 69 136 559 69 139 559 minecraft:cobbled_deepslate
fill 69 136 561 70 136 561 minecraft:cobbled_deepslate
setblock 69 136 598 minecraft:calcite
fill 70 136 558 70 139 558 minecraft:cobbled_deepslate
setblock 70 136 597 minecraft:calcite
fill 70 136 598 70 139 598 minecraft:cobbled_deepslate
setblock 71 136 561 minecraft:calcite
fill 71 136 597 71 139 597 minecraft:cobbled_deepslate
setblock 72 136 560 minecraft:calcite
fill 72 136 561 72 139 561 minecraft:cobbled_deepslate
setblock 73 136 559 minecraft:calcite
fill 73 136 560 73 139 560 minecraft:cobbled_deepslate
setblock 74 136 558 minecraft:calcite
fill 74 136 559 74 139 559 minecraft:cobbled_deepslate
setblock 74 136 598 minecraft:calcite
fill 75 136 558 75 139 558 minecraft:cobbled_deepslate
setblock 75 136 597 minecraft:calcite
fill 75 136 598 75 139 598 minecraft:cobbled_deepslate
setblock 76 136 561 minecraft:calcite
fill 76 136 597 76 137 597 minecraft:cobbled_deepslate
setblock 77 136 560 minecraft:calcite
setblock 78 136 559 minecraft:calcite
fill 78 136 560 78 139 560 minecraft:cobbled_deepslate
setblock 79 136 558 minecraft:calcite
fill 79 136 559 82 136 559 minecraft:cobbled_deepslate
setblock 79 136 598 minecraft:calcite
fill 80 136 558 80 139 558 minecraft:cobbled_deepslate
fill 80 136 598 80 139 598 minecraft:cobbled_deepslate
setblock 83 136 559 minecraft:calcite
setblock 84 136 558 minecraft:calcite
fill 84 136 559 84 139 559 minecraft:cobbled_deepslate
setblock 84 136 598 minecraft:calcite
fill 85 136 558 85 139 558 minecraft:cobbled_deepslate
setblock 85 136 597 minecraft:calcite
fill 85 136 598 85 139 598 minecraft:cobbled_deepslate
setblock 86 136 560 minecraft:cobbled_deepslate
fill 86 136 597 86 139 597 minecraft:cobbled_deepslate
setblock 87 136 559 minecraft:cobbled_deepslate
setblock 87 136 560 minecraft:calcite
fill 87 136 561 87 139 561 minecraft:cobbled_deepslate
fill 87 136 563 88 136 563 minecraft:cobbled_deepslate
setblock 87 136 579 minecraft:cobbled_deepslate
setblock 87 136 580 minecraft:calcite
fill 87 136 581 87 136 584 minecraft:cobbled_deepslate
setblock 87 136 585 minecraft:calcite
fill 87 136 586 88 138 586 minecraft:cobbled_deepslate
setblock 87 136 594 minecraft:cobbled_deepslate
setblock 87 136 595 minecraft:calcite
fill 87 136 596 87 139 596 minecraft:cobbled_deepslate
setblock 88 136 559 minecraft:calcite
fill 88 136 560 88 139 560 minecraft:cobbled_deepslate
fill 88 136 562 88 137 562 minecraft:cobbled_deepslate
setblock 88 136 564 minecraft:calcite
fill 88 136 565 88 138 566 minecraft:cobbled_deepslate
fill 88 136 575 88 136 578 minecraft:cobbled_deepslate
setblock 88 136 579 minecraft:calcite
fill 88 136 580 88 136 583 minecraft:cobbled_deepslate
setblock 88 136 584 minecraft:calcite
fill 88 136 585 88 139 585 minecraft:cobbled_deepslate
fill 88 136 587 88 136 588 minecraft:cobbled_deepslate
setblock 88 136 589 minecraft:calcite
fill 88 136 590 88 139 590 minecraft:cobbled_deepslate
setblock 88 136 594 minecraft:calcite
fill 88 136 595 88 139 595 minecraft:cobbled_deepslate
setblock 48 137 558 minecraft:calcite
fill 48 137 559 48 140 559 minecraft:cobbled_deepslate
setblock 48 137 563 minecraft:calcite
fill 48 137 564 49 139 564 minecraft:cobbled_deepslate
fill 48 137 566 48 137 567 minecraft:cobbled_deepslate
setblock 48 137 568 minecraft:calcite
fill 48 137 571 48 137 572 minecraft:cobbled_deepslate
setblock 48 137 573 minecraft:calcite
fill 48 137 574 48 140 574 minecraft:cobbled_deepslate
setblock 48 137 578 minecraft:calcite
fill 48 137 579 48 140 579 minecraft:cobbled_deepslate
setblock 48 137 583 minecraft:calcite
fill 48 137 584 48 137 587 minecraft:cobbled_deepslate
setblock 48 137 588 minecraft:calcite
fill 48 137 589 48 140 589 minecraft:cobbled_deepslate
setblock 48 137 592 minecraft:cobbled_deepslate
setblock 48 137 593 minecraft:calcite
fill 48 137 594 48 140 594 minecraft:cobbled_deepslate
setblock 48 137 598 minecraft:calcite
fill 49 137 558 49 140 558 minecraft:cobbled_deepslate
setblock 49 137 562 minecraft:calcite
fill 49 137 563 49 140 563 minecraft:cobbled_deepslate
fill 49 137 565 49 138 565 minecraft:cobbled_deepslate
setblock 49 137 577 minecraft:calcite
fill 49 137 578 49 140 578 minecraft:cobbled_deepslate
setblock 49 137 582 minecraft:calcite
fill 49 137 583 49 137 586 minecraft:cobbled_deepslate
setblock 49 137 587 minecraft:calcite
fill 49 137 588 49 140 588 minecraft:cobbled_deepslate
setblock 49 137 592 minecraft:calcite
fill 49 137 593 49 140 593 minecraft:cobbled_deepslate
setblock 49 137 597 minecraft:calcite
fill 49 137 598 49 140 598 minecraft:cobbled_deepslate
setblock 50 137 560 minecraft:cobbled_deepslate
setblock 50 137 561 minecraft:calcite
setblock 50 137 576 minecraft:calcite
fill 50 137 577 50 140 577 minecraft:cobbled_deepslate
setblock 50 137 580 minecraft:cobbled_deepslate
setblock 50 137 581 minecraft:calcite
fill 50 137 582 50 140 582 minecraft:cobbled_deepslate
setblock 50 137 585 minecraft:cobbled_deepslate
setblock 50 137 586 minecraft:calcite
fill 50 137 587 51 139 587 minecraft:cobbled_deepslate
setblock 50 137 591 minecraft:calcite
fill 50 137 597 50 140 597 minecraft:cobbled_deepslate
setblock 51 137 560 minecraft:calcite
setblock 51 137 580 minecraft:calcite
fill 51 137 581 51 140 581 minecraft:cobbled_deepslate
setblock 51 137 585 minecraft:calcite
fill 51 137 586 51 140 586 minecraft:cobbled_deepslate
setblock 52 137 559 minecraft:calcite
fill 52 137 560 53 137 560 minecraft:cobbled_deepslate
setblock 52 137 580 minecraft:cobbled_deepslate
setblock 52 137 584 minecraft:calcite
setblock 53 137 558 minecraft:calcite
fill 53 137 559 53 140 559 minecraft:cobbled_deepslate
setblock 53 137 598 minecraft:calcite
fill 54 137 558 54 140 558 minecraft:cobbled_deepslate
setblock 54 137 597 minecraft:calcite
fill 54 137 598 54 139 598 minecraft:cobbled_deepslate
setblock 58 137 558 minecraft:calcite
fill 59 137 558 62 137 558 minecraft:cobbled_deepslate
setblock 63 137 558 minecraft:calcite
fill 64 137 558 64 140 558 minecraft:cobbled_deepslate
fill 64 137 562 64 138 562 minecraft:light_blue_stained_glass
setblock 66 137 560 minecraft:calcite
fill 66 137 598 66 138 598 minecraft:cobbled_deepslate
setblock 67 137 558 minecraft:cobbled_deepslate
setblock 67 137 559 minecraft:calcite
fill 67 137 560 67 140 560 minecraft:cobbled_deepslate
setblock 68 137 558 minecraft:calcite
fill 68 137 559 68 140 559 minecraft:cobbled_deepslate
fill 68 137 561 69 137 561 minecraft:cobbled_deepslate
setblock 68 137 598 minecraft:calcite
fill 69 137 558 69 140 558 minecraft:cobbled_deepslate
fill 69 137 598 69 140 598 minecraft:cobbled_deepslate
setblock 70 137 561 minecraft:calcite
fill 70 137 597 70 138 597 minecraft:cobbled_deepslate
setblock 71 137 560 minecraft:calcite
fill 71 137 561 71 139 562 minecraft:cobbled_deepslate
setblock 72 137 559 minecraft:calcite
fill 72 137 560 72 140 560 minecraft:cobbled_deepslate
fill 72 137 562 73 137 562 minecraft:cobbled_deepslate
setblock 73 137 558 minecraft:calcite
fill 73 137 559 73 140 559 minecraft:cobbled_deepslate
setblock 73 137 598 minecraft:calcite
fill 74 137 558 74 140 558 minecraft:cobbled_deepslate
setblock 74 137 561 minecraft:cobbled_deepslate
setblock 74 137 597 minecraft:calcite
fill 74 137 598 74 140 598 minecraft:cobbled_deepslate
setblock 75 137 561 minecraft:calcite
setblock 75 137 597 minecraft:cobbled_deepslate
setblock 76 137 560 minecraft:calcite
fill 76 137 561 76 138 561 minecraft:cobbled_deepslate
setblock 77 137 559 minecraft:calcite
fill 77 137 560 77 140 560 minecraft:cobbled_deepslate
setblock 78 137 558 minecraft:calcite
fill 78 137 559 81 137 559 minecraft:cobbled_deepslate
setblock 78 137 598 minecraft:calcite
fill 79 137 558 79 140 558 minecraft:cobbled_deepslate
fill 79 137 598 79 140 598 minecraft:cobbled_deepslate
setblock 82 137 559 minecraft:calcite
setblock 83 137 558 minecraft:calcite
fill 83 137 559 83 140 559 minecraft:cobbled_deepslate
setblock 83 137 598 minecraft:calcite
fill 84 137 558 84 140 558 minecraft:cobbled_deepslate
fill 84 137 560 85 137 560 minecraft:cobbled_deepslate
setblock 84 137 597 minecraft:calcite
fill 84 137 598 84 140 598 minecraft:cobbled_deepslate
fill 85 137 597 85 140 597 minecraft:cobbled_deepslate
setblock 86 137 560 minecraft:calcite
fill 86 137 561 86 140 561 minecraft:cobbled_deepslate
setblock 87 137 559 minecraft:calcite
fill 87 137 560 87 140 560 minecraft:cobbled_deepslate
setblock 87 137 563 minecraft:cobbled_deepslate
setblock 87 137 564 minecraft:calcite
setblock 87 137 579 minecraft:calcite
fill 87 137 580 87 137 583 minecraft:cobbled_deepslate
setblock 87 137 584 minecraft:calcite
fill 87 137 585 87 140 585 minecraft:cobbled_deepslate
fill 87 137 587 87 137 588 minecraft:cobbled_deepslate
setblock 87 137 589 minecraft:calcite
fill 87 137 590 87 137 593 minecraft:cobbled_deepslate
setblock 87 137 594 minecraft:calcite
fill 87 137 595 87 140 595 minecraft:cobbled_deepslate
setblock 88 137 558 minecraft:calcite
fill 88 137 559 88 140 559 minecraft:cobbled_deepslate
setblock 88 137 563 minecraft:calcite
fill 88 137 564 88 140 564 minecraft:cobbled_deepslate
setblock 88 137 567 minecraft:cobbled_deepslate
fill 88 137 575 88 137 577 minecraft:cobbled_deepslate
setblock 88 137 578 minecraft:calcite
fill 88 137 579 88 137 582 minecraft:cobbled_deepslate
setblock 88 137 583 minecraft:calcite
fill 88 137 584 88 140 584 minecraft:cobbled_deepslate
setblock 88 137 587 minecraft:cobbled_deepslate
setblock 88 137 588 minecraft:calcite
fill 88 137 589 88 140 589 minecraft:cobbled_deepslate
setblock 88 137 593 minecraft:calcite
fill 88 137 594 88 140 594 minecraft:cobbled_deepslate
setblock 88 137 598 minecraft:calcite
fill 48 138 558 48 141 558 minecraft:cobbled_deepslate
setblock 48 138 561 minecraft:cobbled_deepslate
setblock 48 138 562 minecraft:calcite
fill 48 138 563 48 141 563 minecraft:cobbled_deepslate
setblock 48 138 566 minecraft:cobbled_deepslate
setblock 48 138 567 minecraft:calcite
fill 48 138 568 48 138 571 minecraft:cobbled_deepslate
setblock 48 138 572 minecraft:calcite
fill 48 138 573 48 141 573 minecraft:cobbled_deepslate
setblock 48 138 577 minecraft:calcite
fill 48 138 578 48 141 578 minecraft:cobbled_deepslate
setblock 48 138 582 minecraft:calcite
fill 48 138 583 48 138 586 minecraft:cobbled_deepslate
setblock 48 138 587 minecraft:calcite
fill 48 138 588 48 141 588 minecraft:cobbled_deepslate
setblock 48 138 592 minecraft:calcite
fill 48 138 593 48 141 593 minecraft:cobbled_deepslate
setblock 48 138 597 minecraft:calcite
fill 48 138 598 48 141 598 minecraft:cobbled_deepslate
setblock 49 138 561 minecraft:calcite
fill 49 138 562 50 140 562 minecraft:cobbled_deepslate
setblock 49 138 566 minecraft:calcite
setblock 49 138 576 minecraft:calcite
fill 49 138 577 49 141 577 minecraft:cobbled_deepslate
setblock 49 138 581 minecraft:calcite
fill 49 138 582 49 138 585 minecraft:cobbled_deepslate
setblock 49 138 586 minecraft:calcite
fill 49 138 587 49 141 587 minecraft:cobbled_deepslate
setblock 49 138 591 minecraft:calcite
fill 49 138 592 49 141 592 minecraft:cobbled_deepslate
setblock 49 138 596 minecraft:calcite
fill 49 138 597 49 140 597 minecraft:cobbled_deepslate
setblock 50 138 560 minecraft:calcite
fill 50 138 561 50 139 561 minecraft:cobbled_deepslate
fill 50 138 563 50 139 563 minecraft:cobbled_deepslate
fill 50 138 576 50 139 576 minecraft:cobbled_deepslate
setblock 50 138 580 minecraft:calcite
fill 50 138 581 50 141 581 minecraft:cobbled_deepslate
setblock 50 138 584 minecraft:cobbled_deepslate
setblock 50 138 585 minecraft:calcite
fill 50 138 586 50 141 586 minecraft:cobbled_deepslate
setblock 50 138 590 minecraft:calcite
fill 50 138 591 50 141 591 minecraft:cobbled_deepslate
setblock 51 138 559 minecraft:calcite
fill 51 138 560 52 138 560 minecraft:cobbled_deepslate
setblock 51 138 579 minecraft:calcite
fill 51 138 580 51 140 580 minecraft:cobbled_deepslate
setblock 51 138 584 minecraft:calcite
fill 51 138 585 51 141 585 minecraft:cobbled_deepslate
setblock 51 138 588 minecraft:cobbled_deepslate
setblock 52 138 558 minecraft:calcite
fill 52 138 559 52 140 559 minecraft:cobbled_deepslate
setblock 52 138 583 minecraft:calcite
fill 52 138 584 52 139 584 minecraft:cobbled_deepslate
setblock 52 138 598 minecraft:calcite
fill 53 138 558 53 141 558 minecraft:cobbled_deepslate
setblock 53 138 597 minecraft:calcite
fill 53 138 598 53 140 598 minecraft:cobbled_deepslate
setblock 57 138 558 minecraft:calcite
fill 58 138 558 61 138 558 minecraft:cobbled_deepslate
setblock 62 138 558 minecraft:calcite
fill 63 138 558 63 140 559 minecraft:cobbled_deepslate
setblock 65 138 560 minecraft:calcite
setblock 66 138 558 minecraft:cobbled_deepslate
setblock 66 138 559 minecraft:calcite
fill 66 138 560 66 141 560 minecraft:cobbled_deepslate
setblock 67 138 558 minecraft:calcite
fill 67 138 559 67 141 559 minecraft:cobbled_deepslate
fill 67 138 561 68 138 561 minecraft:cobbled_deepslate
setblock 67 138 598 minecraft:calcite
fill 68 138 558 68 141 558 minecraft:cobbled_deepslate
fill 68 138 598 68 141 598 minecraft:cobbled_deepslate
setblock 69 138 561 minecraft:calcite
fill 69 138 562 70 140 562 minecraft:cobbled_deepslate
setblock 70 138 560 minecraft:calcite
fill 70 138 561 70 141 561 minecraft:cobbled_deepslate
setblock 71 138 559 minecraft:calcite
fill 71 138 560 71 141 560 minecraft:cobbled_deepslate
setblock 72 138 558 minecraft:calcite
fill 72 138 559 72 141 559 minecraft:cobbled_deepslate
setblock 72 138 562 minecraft:cobbled_deepslate
setblock 72 138 598 minecraft:calcite
fill 73 138 558 73 141 558 minecraft:cobbled_deepslate
setblock 73 138 562 minecraft:calcite
setblock 73 138 597 minecraft:calcite
fill 73 138 598 73 141 598 minecraft:cobbled_deepslate
setblock 74 138 561 minecraft:calcite
setblock 74 138 597 minecraft:cobbled_deepslate
setblock 75 138 560 minecraft:calcite
fill 75 138 561 75 139 561 minecraft:cobbled_deepslate
setblock 76 138 559 minecraft:calcite
fill 76 138 560 76 140 560 minecraft:cobbled_deepslate
setblock 77 138 558 minecraft:calcite
fill 77 138 559 80 138 559 minecraft:cobbled_deepslate
setblock 77 138 598 minecraft:calcite
fill 78 138 558 78 141 558 minecraft:cobbled_deepslate
fill 78 138 598 78 140 598 minecraft:cobbled_deepslate
setblock 79 138 560 minecraft:cobbled_deepslate
setblock 80 138 560 minecraft:calcite
setblock 81 138 559 minecraft:calcite
setblock 82 138 558 minecraft:calcite
fill 82 138 559 82 141 559 minecraft:cobbled_deepslate
setblock 82 138 598 minecraft:calcite
fill 83 138 558 83 141 558 minecraft:cobbled_deepslate
fill 83 138 598 83 141 598 minecraft:cobbled_deepslate
setblock 84 138 560 minecraft:cobbled_deepslate
fill 84 138 597 84 139 597 minecraft:cobbled_deepslate
setblock 85 138 560 minecraft:calcite
setblock 86 138 559 minecraft:calcite
fill 86 138 560 86 140 560 minecraft:cobbled_deepslate
fill 86 138 562 86 139 562 minecraft:cobbled_deepslate
setblock 87 138 558 minecraft:calcite
fill 87 138 559 87 141 559 minecraft:cobbled_deepslate
setblock 87 138 563 minecraft:calcite
fill 87 138 564 87 140 565 minecraft:cobbled_deepslate
setblock 87 138 578 minecraft:calcite
fill 87 138 579 87 138 582 minecraft:cobbled_deepslate
setblock 87 138 583 minecraft:calcite
fill 87 138 584 87 141 584 minecraft:cobbled_deepslate
setblock 87 138 587 minecraft:cobbled_deepslate
setblock 87 138 588 minecraft:calcite
fill 87 138 589 87 138 592 minecraft:cobbled_deepslate
setblock 87 138 593 minecraft:calcite
fill 87 138 594 87 141 594 minecraft:cobbled_deepslate
setblock 87 138 598 minecraft:calcite
fill 88 138 558 88 141 558 minecraft:cobbled_deepslate
setblock 88 138 562 minecraft:calcite
fill 88 138 563 88 141 563 minecraft:cobbled_deepslate
setblock 88 138 567 minecraft:calcite
fill 88 138 568 88 141 568 minecraft:cobbled_deepslate
fill 88 138 575 88 138 576 minecraft:cobbled_deepslate
setblock 88 138 577 minecraft:calcite
fill 88 138 578 88 138 581 minecraft:cobbled_deepslate
setblock 88 138 582 minecraft:calcite
fill 88 138 583 88 141 583 minecraft:cobbled_deepslate
setblock 88 138 587 minecraft:calcite
fill 88 138 588 88 141 588 minecraft:cobbled_deepslate
setblock 88 138 592 minecraft:calcite
fill 88 138 593 88 141 593 minecraft:cobbled_deepslate
setblock 88 138 597 minecraft:calcite
fill 88 138 598 88 141 598 minecraft:cobbled_deepslate
setblock 48 139 561 minecraft:calcite
fill 48 139 562 48 142 562 minecraft:cobbled_deepslate
setblock 48 139 566 minecraft:calcite
fill 48 139 567 48 139 570 minecraft:cobbled_deepslate
setblock 48 139 571 minecraft:calcite
fill 48 139 572 48 142 572 minecraft:cobbled_deepslate
setblock 48 139 576 minecraft:calcite
fill 48 139 577 48 142 577 minecraft:cobbled_deepslate
setblock 48 139 581 minecraft:calcite
fill 48 139 582 48 139 585 minecraft:cobbled_deepslate
setblock 48 139 586 minecraft:calcite
fill 48 139 587 48 142 587 minecraft:cobbled_deepslate
setblock 48 139 591 minecraft:calcite
fill 48 139 592 48 142 592 minecraft:cobbled_deepslate
setblock 48 139 596 minecraft:calcite
fill 48 139 597 48 142 597 minecraft:cobbled_deepslate
setblock 49 139 560 minecraft:calcite
fill 49 139 561 49 142 561 minecraft:cobbled_deepslate
setblock 49 139 565 minecraft:calcite
fill 49 139 566 49 140 568 minecraft:cobbled_deepslate
setblock 49 139 575 minecraft:calcite
fill 49 139 576 49 142 576 minecraft:cobbled_deepslate
setblock 49 139 580 minecraft:calcite
fill 49 139 581 49 139 584 minecraft:cobbled_deepslate
setblock 49 139 585 minecraft:calcite
fill 49 139 586 49 142 586 minecraft:cobbled_deepslate
setblock 49 139 589 minecraft:cobbled_deepslate
setblock 49 139 590 minecraft:calcite
fill 49 139 591 49 142 591 minecraft:cobbled_deepslate
setblock 49 139 595 minecraft:calcite
fill 49 139 596 49 140 596 minecraft:cobbled_deepslate
setblock 50 139 559 minecraft:calcite
fill 50 139 560 51 139 560 minecraft:cobbled_deepslate
setblock 50 139 564 minecraft:calcite
setblock 50 139 579 minecraft:calcite
fill 50 139 580 50 142 580 minecraft:cobbled_deepslate
setblock 50 139 584 minecraft:calcite
fill 50 139 585 50 142 585 minecraft:cobbled_deepslate
setblock 50 139 589 minecraft:calcite
fill 50 139 590 50 142 590 minecraft:cobbled_deepslate
setblock 51 139 558 minecraft:calcite
fill 51 139 559 51 140 559 minecraft:cobbled_deepslate
setblock 51 139 578 minecraft:calcite
fill 51 139 579 51 140 579 minecraft:cobbled_deepslate
setblock 51 139 582 minecraft:cobbled_deepslate
setblock 51 139 583 minecraft:calcite
fill 51 139 584 51 142 584 minecraft:cobbled_deepslate
setblock 51 139 588 minecraft:calcite
setblock 51 139 598 minecraft:calcite
fill 52 139 558 52 141 558 minecraft:cobbled_deepslate
setblock 52 139 582 minecraft:calcite
setblock 52 139 583 minecraft:cobbled_deepslate
fill 52 139 598 52 140 598 minecraft:cobbled_deepslate
setblock 56 139 558 minecraft:calcite
setblock 57 139 558 minecraft:cobbled_deepslate
setblock 61 139 558 minecraft:calcite
fill 62 139 558 62 141 558 minecraft:cobbled_deepslate
setblock 64 139 559 minecraft:cobbled_deepslate
fill 64 139 562 64 145 563 minecraft:deepslate
setblock 65 139 559 minecraft:calcite
fill 65 139 560 65 142 560 minecraft:cobbled_deepslate
setblock 66 139 558 minecraft:calcite
fill 66 139 559 66 142 559 minecraft:cobbled_deepslate
fill 66 139 561 67 139 561 minecraft:cobbled_deepslate
setblock 66 139 598 minecraft:calcite
fill 67 139 558 67 142 558 minecraft:cobbled_deepslate
fill 67 139 598 67 142 598 minecraft:cobbled_deepslate
setblock 68 139 561 minecraft:calcite
setblock 69 139 560 minecraft:calcite
fill 69 139 561 69 142 561 minecraft:cobbled_deepslate
setblock 70 139 559 minecraft:calcite
fill 70 139 560 70 142 560 minecraft:cobbled_deepslate
setblock 71 139 558 minecraft:calcite
fill 71 139 559 71 142 559 minecraft:cobbled_deepslate
setblock 71 139 598 minecraft:calcite
fill 72 139 558 72 142 558 minecraft:cobbled_deepslate
setblock 72 139 562 minecraft:calcite
setblock 72 139 597 minecraft:calcite
fill 72 139 598 72 142 598 minecraft:cobbled_deepslate
setblock 73 139 561 minecraft:calcite
setblock 74 139 560 minecraft:calcite
fill 74 139 561 74 140 561 minecraft:cobbled_deepslate
setblock 75 139 559 minecraft:calcite
fill 75 139 560 75 141 560 minecraft:cobbled_deepslate
setblock 76 139 558 minecraft:calcite
fill 76 139 559 79 139 559 minecraft:cobbled_deepslate
setblock 76 139 598 minecraft:calcite
fill 77 139 558 77 142 558 minecraft:cobbled_deepslate
fill 77 139 598 77 140 598 minecraft:cobbled_deepslate
setblock 79 139 560 minecraft:calcite
setblock 80 139 559 minecraft:calcite
setblock 81 139 558 minecraft:calcite
fill 81 139 559 81 141 559 minecraft:cobbled_deepslate
setblock 81 139 598 minecraft:calcite
fill 82 139 558 82 142 558 minecraft:cobbled_deepslate
fill 82 139 598 82 142 598 minecraft:cobbled_deepslate
setblock 84 139 560 minecraft:calcite
setblock 85 139 559 minecraft:calcite
fill 85 139 560 85 140 560 minecraft:cobbled_deepslate
setblock 86 139 558 minecraft:calcite
fill 86 139 559 86 142 559 minecraft:cobbled_deepslate
setblock 86 139 563 minecraft:calcite
setblock 86 139 583 minecraft:calcite
fill 86 139 584 86 139 587 minecraft:cobbled_deepslate
setblock 86 139 598 minecraft:calcite
fill 87 139 558 87 142 558 minecraft:cobbled_deepslate
setblock 87 139 562 minecraft:calcite
fill 87 139 563 87 142 563 minecraft:cobbled_deepslate
setblock 87 139 566 minecraft:cobbled_deepslate
fill 87 139 579 87 139 581 minecraft:cobbled_deepslate
setblock 87 139 582 minecraft:calcite
fill 87 139 583 87 142 583 minecraft:cobbled_deepslate
setblock 87 139 586 minecraft:cobbled_deepslate
setblock 87 139 587 minecraft:calcite
fill 87 139 588 87 139 591 minecraft:cobbled_deepslate
setblock 87 139 592 minecraft:calcite
fill 87 139 593 87 142 593 minecraft:cobbled_deepslate
setblock 87 139 597 minecraft:calcite
fill 87 139 598 87 142 598 minecraft:cobbled_deepslate
setblock 88 139 561 minecraft:calcite
fill 88 139 562 88 142 562 minecraft:cobbled_deepslate
setblock 88 139 565 minecraft:cobbled_deepslate
setblock 88 139 566 minecraft:calcite
fill 88 139 567 88 142 567 minecraft:cobbled_deepslate
fill 88 139 569 88 140 569 minecraft:cobbled_deepslate
setblock 88 139 575 minecraft:cobbled_deepslate
setblock 88 139 576 minecraft:calcite
fill 88 139 577 88 139 580 minecraft:cobbled_deepslate
setblock 88 139 581 minecraft:calcite
fill 88 139 582 88 142 582 minecraft:cobbled_deepslate
setblock 88 139 586 minecraft:calcite
fill 88 139 587 88 142 587 minecraft:cobbled_deepslate
setblock 88 139 591 minecraft:calcite
fill 88 139 592 88 142 592 minecraft:cobbled_deepslate
setblock 88 139 596 minecraft:calcite
fill 88 139 597 88 142 597 minecraft:cobbled_deepslate
setblock 48 140 560 minecraft:calcite
fill 48 140 561 48 143 561 minecraft:cobbled_deepslate
setblock 48 140 564 minecraft:cobbled_deepslate
setblock 48 140 565 minecraft:calcite
fill 48 140 566 48 140 569 minecraft:cobbled_deepslate
setblock 48 140 570 minecraft:calcite
fill 48 140 571 48 143 571 minecraft:cobbled_deepslate
setblock 48 140 575 minecraft:calcite
fill 48 140 576 48 143 576 minecraft:cobbled_deepslate
setblock 48 140 580 minecraft:calcite
fill 48 140 581 48 140 584 minecraft:cobbled_deepslate
setblock 48 140 585 minecraft:calcite
fill 48 140 586 48 143 586 minecraft:cobbled_deepslate
setblock 48 140 590 minecraft:calcite
fill 48 140 591 48 143 591 minecraft:cobbled_deepslate
setblock 48 140 595 minecraft:calcite
fill 48 140 596 48 143 596 minecraft:cobbled_deepslate
setblock 49 140 559 minecraft:calcite
fill 49 140 560 49 142 560 minecraft:cobbled_deepslate
setblock 49 140 564 minecraft:calcite
fill 49 140 565 49 143 565 minecraft:cobbled_deepslate
setblock 49 140 569 minecraft:calcite
setblock 49 140 574 minecraft:calcite
fill 49 140 575 49 141 575 minecraft:cobbled_deepslate
setblock 49 140 579 minecraft:calcite
fill 49 140 580 49 140 583 minecraft:cobbled_deepslate
setblock 49 140 584 minecraft:calcite
fill 49 140 585 49 143 585 minecraft:cobbled_deepslate
setblock 49 140 589 minecraft:calcite
fill 49 140 590 49 143 590 minecraft:cobbled_deepslate
setblock 49 140 594 minecraft:calcite
setblock 49 140 595 minecraft:cobbled_deepslate
setblock 50 140 558 minecraft:calcite
fill 50 140 559 50 141 559 minecraft:cobbled_deepslate
setblock 50 140 560 minecraft:light[level=14]
setblock 50 140 563 minecraft:calcite
setblock 50 140 564 minecraft:cobbled_deepslate
setblock 50 140 568 minecraft:light[level=14]
setblock 50 140 576 minecraft:light[level=14]
setblock 50 140 578 minecraft:calcite
fill 50 140 579 50 142 579 minecraft:cobbled_deepslate
setblock 50 140 583 minecraft:calcite
fill 50 140 584 50 143 584 minecraft:cobbled_deepslate
setblock 50 140 587 minecraft:cobbled_deepslate
setblock 50 140 588 minecraft:calcite
fill 50 140 589 50 143 589 minecraft:cobbled_deepslate
setblock 50 140 592 minecraft:light[level=14]
setblock 50 140 598 minecraft:calcite
fill 51 140 558 51 142 558 minecraft:cobbled_deepslate
setblock 51 140 582 minecraft:calcite
fill 51 140 583 51 142 583 minecraft:cobbled_deepslate
setblock 51 140 587 minecraft:calcite
setblock 51 140 588 minecraft:cobbled_deepslate
fill 51 140 598 51 141 598 minecraft:cobbled_deepslate
setblock 55 140 558 minecraft:calcite
setblock 58 140 560 minecraft:light[level=14]
setblock 58 140 568 minecraft:light[level=14]
setblock 58 140 576 minecraft:light[level=14]
setblock 58 140 584 minecraft:light[level=14]
setblock 58 140 592 minecraft:light[level=14]
setblock 64 140 559 minecraft:calcite
setblock 65 140 558 minecraft:calcite
fill 65 140 559 65 143 559 minecraft:cobbled_deepslate
fill 66 140 558 66 143 558 minecraft:cobbled_deepslate
setblock 66 140 561 minecraft:cobbled_deepslate
setblock 66 140 568 minecraft:light[level=14]
setblock 66 140 576 minecraft:light[level=14]
setblock 66 140 592 minecraft:light[level=14]
setblock 66 140 598 minecraft:cobbled_deepslate
setblock 67 140 561 minecraft:calcite
setblock 68 140 560 minecraft:calcite
fill 68 140 561 68 143 561 minecraft:cobbled_deepslate
setblock 69 140 559 minecraft:calcite
fill 69 140 560 69 143 560 minecraft:cobbled_deepslate
setblock 70 140 558 minecraft:calcite
fill 70 140 559 70 143 559 minecraft:cobbled_deepslate
setblock 70 140 598 minecraft:calcite
fill 71 140 558 71 143 558 minecraft:cobbled_deepslate
setblock 71 140 561 minecraft:cobbled_deepslate
setblock 71 140 562 minecraft:calcite
fill 71 140 598 71 142 598 minecraft:cobbled_deepslate
setblock 72 140 561 minecraft:calcite
setblock 73 140 560 minecraft:calcite
fill 73 140 561 73 141 561 minecraft:cobbled_deepslate
setblock 74 140 559 minecraft:calcite
fill 74 140 560 74 141 560 minecraft:cobbled_deepslate
setblock 74 140 568 minecraft:light[level=14]
setblock 74 140 576 minecraft:light[level=14]
setblock 74 140 584 minecraft:light[level=14]
setblock 74 140 592 minecraft:light[level=14]
setblock 75 140 558 minecraft:calcite
fill 75 140 559 78 140 559 minecraft:cobbled_deepslate
setblock 75 140 598 minecraft:calcite
fill 76 140 558 76 143 558 minecraft:cobbled_deepslate
setblock 76 140 598 minecraft:cobbled_deepslate
setblock 79 140 559 minecraft:calcite
setblock 80 140 558 minecraft:calcite
setblock 80 140 559 minecraft:cobbled_deepslate
setblock 80 140 598 minecraft:calcite
fill 81 140 558 81 142 558 minecraft:cobbled_deepslate
fill 81 140 598 81 141 598 minecraft:cobbled_deepslate
setblock 82 140 560 minecraft:light[level=14]
setblock 82 140 568 minecraft:light[level=14]
setblock 82 140 576 minecraft:light[level=14]
setblock 82 140 584 minecraft:light[level=14]
setblock 82 140 592 minecraft:light[level=14]
setblock 84 140 559 minecraft:calcite
setblock 85 140 558 minecraft:calcite
fill 85 140 559 85 142 559 minecraft:cobbled_deepslate
setblock 85 140 598 minecraft:calcite
fill 86 140 558 86 143 558 minecraft:cobbled_deepslate
setblock 86 140 562 minecraft:calcite
setblock 86 140 563 minecraft:cobbled_deepslate
fill 86 140 583 86 140 586 minecraft:cobbled_deepslate
setblock 86 140 587 minecraft:calcite
fill 86 140 588 87 141 589 minecraft:cobbled_deepslate
setblock 86 140 597 minecraft:calcite
fill 86 140 598 86 143 598 minecraft:cobbled_deepslate
setblock 87 140 561 minecraft:calcite
fill 87 140 562 87 143 562 minecraft:cobbled_deepslate
setblock 87 140 566 minecraft:calcite
fill 87 140 579 87 140 580 minecraft:cobbled_deepslate
setblock 87 140 581 minecraft:calcite
fill 87 140 582 87 143 582 minecraft:cobbled_deepslate
setblock 87 140 586 minecraft:calcite
fill 87 140 587 87 143 587 minecraft:cobbled_deepslate
setblock 87 140 590 minecraft:cobbled_deepslate
setblock 87 140 591 minecraft:calcite
fill 87 140 592 87 143 592 minecraft:cobbled_deepslate
setblock 87 140 596 minecraft:calcite
fill 87 140 597 87 143 597 minecraft:cobbled_deepslate
setblock 88 140 560 minecraft:calcite
fill 88 140 561 88 143 561 minecraft:cobbled_deepslate
setblock 88 140 565 minecraft:calcite
fill 88 140 566 88 143 566 minecraft:cobbled_deepslate
setblock 88 140 570 minecraft:calcite
setblock 88 140 575 minecraft:calcite
fill 88 140 576 88 140 579 minecraft:cobbled_deepslate
setblock 88 140 580 minecraft:calcite
fill 88 140 581 88 143 581 minecraft:cobbled_deepslate
setblock 88 140 585 minecraft:calcite
fill 88 140 586 88 143 586 minecraft:cobbled_deepslate
setblock 88 140 590 minecraft:calcite
fill 88 140 591 88 143 591 minecraft:cobbled_deepslate
setblock 88 140 595 minecraft:calcite
fill 88 140 596 88 143 596 minecraft:cobbled_deepslate
setblock 48 141 559 minecraft:calcite
fill 48 141 560 48 144 560 minecraft:cobbled_deepslate
setblock 48 141 564 minecraft:calcite
fill 48 141 565 48 141 568 minecraft:cobbled_deepslate
setblock 48 141 569 minecraft:calcite
fill 48 141 570 48 144 570 minecraft:cobbled_deepslate
setblock 48 141 574 minecraft:calcite
fill 48 141 575 48 144 575 minecraft:cobbled_deepslate
setblock 48 141 579 minecraft:calcite
fill 48 141 580 48 141 583 minecraft:cobbled_deepslate
setblock 48 141 584 minecraft:calcite
fill 48 141 585 48 144 585 minecraft:cobbled_deepslate
setblock 48 141 589 minecraft:calcite
fill 48 141 590 48 144 590 minecraft:cobbled_deepslate
setblock 48 141 594 minecraft:calcite
fill 48 141 595 48 144 595 minecraft:cobbled_deepslate
setblock 49 141 558 minecraft:calcite
setblock 49 141 559 minecraft:cobbled_deepslate
setblock 49 141 562 minecraft:cobbled_deepslate
setblock 49 141 563 minecraft:calcite
fill 49 141 564 49 144 564 minecraft:cobbled_deepslate
fill 49 141 566 49 141 567 minecraft:cobbled_deepslate
setblock 49 141 568 minecraft:calcite
fill 49 141 569 49 144 569 minecraft:cobbled_deepslate
setblock 49 141 578 minecraft:calcite
fill 49 141 579 49 141 582 minecraft:cobbled_deepslate
setblock 49 141 583 minecraft:calcite
fill 49 141 584 49 144 584 minecraft:cobbled_deepslate
setblock 49 141 588 minecraft:calcite
fill 49 141 589 49 144 589 minecraft:cobbled_deepslate
setblock 49 141 593 minecraft:calcite
setblock 49 141 594 minecraft:cobbled_deepslate
setblock 49 141 598 minecraft:calcite
fill 50 141 558 50 142 558 minecraft:cobbled_deepslate
setblock 50 141 578 minecraft:cobbled_deepslate
setblock 50 141 582 minecraft:calcite
fill 50 141 583 50 144 583 minecraft:cobbled_deepslate
setblock 50 141 587 minecraft:calcite
fill 50 141 588 50 144 588 minecraft:cobbled_deepslate
fill 50 141 598 50 142 598 minecraft:cobbled_deepslate
setblock 51 141 581 minecraft:calcite
setblock 51 141 582 minecraft:cobbled_deepslate
setblock 51 141 586 minecraft:calcite
fill 51 141 587 51 142 587 minecraft:cobbled_deepslate
setblock 63 141 558 minecraft:cobbled_deepslate
setblock 63 141 559 minecraft:calcite
fill 63 141 562 63 145 563 minecraft:deepslate
setblock 64 141 558 minecraft:calcite
fill 64 141 559 64 144 559 minecraft:cobbled_deepslate
fill 64 141 561 64 145 561 minecraft:deepslate
fill 65 141 558 65 144 558 minecraft:cobbled_deepslate
fill 65 141 562 65 145 563 minecraft:deepslate
setblock 66 141 561 minecraft:calcite
setblock 67 141 560 minecraft:calcite
fill 67 141 561 67 142 561 minecraft:cobbled_deepslate
setblock 68 141 559 minecraft:calcite
fill 68 141 560 68 144 560 minecraft:cobbled_deepslate
setblock 69 141 558 minecraft:calcite
fill 69 141 559 69 144 559 minecraft:cobbled_deepslate
setblock 69 141 598 minecraft:calcite
fill 70 141 558 70 144 558 minecraft:cobbled_deepslate
fill 70 141 598 70 143 598 minecraft:cobbled_deepslate
setblock 71 141 561 minecraft:calcite
setblock 72 141 560 minecraft:calcite
setblock 72 141 561 minecraft:cobbled_deepslate
setblock 73 141 559 minecraft:calcite
fill 73 141 560 73 142 560 minecraft:cobbled_deepslate
setblock 74 141 558 minecraft:calcite
fill 74 141 559 77 141 559 minecraft:cobbled_deepslate
setblock 74 141 598 minecraft:calcite
fill 75 141 558 75 143 558 minecraft:cobbled_deepslate
fill 75 141 561 77 144 561 minecraft:light_blue_stained_glass
setblock 75 141 598 minecraft:cobbled_deepslate
fill 76 141 560 78 143 560 minecraft:light_blue_stained_glass
setblock 78 141 559 minecraft:calcite
setblock 79 141 558 minecraft:calcite
setblock 79 141 559 minecraft:cobbled_deepslate
fill 80 141 558 80 142 558 minecraft:cobbled_deepslate
setblock 83 141 559 minecraft:calcite
setblock 84 141 558 minecraft:calcite
fill 84 141 559 84 142 559 minecraft:cobbled_deepslate
setblock 84 141 598 minecraft:calcite
fill 85 141 558 85 144 558 minecraft:cobbled_deepslate
fill 85 141 591 85 146 591 minecraft:deepslate
setblock 85 141 597 minecraft:calcite
fill 85 141 598 85 144 598 minecraft:cobbled_deepslate
setblock 86 141 561 minecraft:calcite
setblock 86 141 562 minecraft:cobbled_deepslate
fill 86 141 583 86 141 585 minecraft:cobbled_deepslate
setblock 86 141 586 minecraft:calcite
fill 86 141 587 86 144 587 minecraft:cobbled_deepslate
setblock 86 141 590 minecraft:cobbled_deepslate
fill 86 141 597 86 143 597 minecraft:cobbled_deepslate
setblock 87 141 560 minecraft:calcite
fill 87 141 561 87 144 561 minecraft:cobbled_deepslate
setblock 87 141 564 minecraft:cobbled_deepslate
setblock 87 141 565 minecraft:calcite
fill 87 141 566 87 144 566 minecraft:cobbled_deepslate
setblock 87 141 579 minecraft:cobbled_deepslate
setblock 87 141 580 minecraft:calcite
fill 87 141 581 87 144 581 minecraft:cobbled_deepslate
setblock 87 141 585 minecraft:calcite
fill 87 141 586 87 144 586 minecraft:cobbled_deepslate
setblock 87 141 590 minecraft:calcite
fill 87 141 591 87 144 591 minecraft:cobbled_deepslate
setblock 87 141 595 minecraft:calcite
fill 87 141 596 87 144 596 minecraft:cobbled_deepslate
setblock 88 141 559 minecraft:calcite
fill 88 141 560 88 144 560 minecraft:cobbled_deepslate
setblock 88 141 564 minecraft:calcite
fill 88 141 565 88 144 565 minecraft:cobbled_deepslate
setblock 88 141 569 minecraft:calcite
fill 88 141 570 88 144 570 minecraft:cobbled_deepslate
fill 88 141 576 88 141 578 minecraft:cobbled_deepslate
setblock 88 141 579 minecraft:calcite
fill 88 141 580 88 144 580 minecraft:cobbled_deepslate
setblock 88 141 584 minecraft:calcite
fill 88 141 585 88 144 585 minecraft:cobbled_deepslate
setblock 88 141 589 minecraft:calcite
fill 88 141 590 88 144 590 minecraft:cobbled_deepslate
setblock 88 141 594 minecraft:calcite
fill 88 141 595 88 144 595 minecraft:cobbled_deepslate
setblock 48 142 558 minecraft:calcite
fill 48 142 559 48 143 559 minecraft:cobbled_deepslate
setblock 48 142 563 minecraft:calcite
fill 48 142 564 48 142 567 minecraft:cobbled_deepslate
setblock 48 142 568 minecraft:calcite
fill 48 142 569 48 145 569 minecraft:cobbled_deepslate
setblock 48 142 573 minecraft:calcite
fill 48 142 574 48 145 574 minecraft:cobbled_deepslate
setblock 48 142 578 minecraft:calcite
fill 48 142 579 48 142 582 minecraft:cobbled_deepslate
setblock 48 142 583 minecraft:calcite
fill 48 142 584 48 145 584 minecraft:cobbled_deepslate
setblock 48 142 588 minecraft:calcite
fill 48 142 589 48 145 589 minecraft:cobbled_deepslate
setblock 48 142 593 minecraft:calcite
fill 48 142 594 48 145 594 minecraft:cobbled_deepslate
setblock 48 142 598 minecraft:calcite
setblock 49 142 558 minecraft:cobbled_deepslate
setblock 49 142 562 minecraft:calcite
fill 49 142 563 49 144 563 minecraft:cobbled_deepslate
setblock 49 142 566 minecraft:cobbled_deepslate
setblock 49 142 567 minecraft:calcite
fill 49 142 568 49 145 568 minecraft:cobbled_deepslate
fill 49 142 570 49 143 570 minecraft:cobbled_deepslate
setblock 49 142 577 minecraft:calcite
fill 49 142 578 49 142 581 minecraft:cobbled_deepslate
setblock 49 142 582 minecraft:calcite
fill 49 142 583 49 145 583 minecraft:cobbled_deepslate
setblock 49 142 587 minecraft:calcite
fill 49 142 588 49 145 588 minecraft:cobbled_deepslate
setblock 49 142 592 minecraft:calcite
fill 49 142 593 49 143 593 minecraft:cobbled_deepslate
setblock 49 142 598 minecraft:cobbled_deepslate
setblock 50 142 581 minecraft:calcite
fill 50 142 582 50 144 582 minecraft:cobbled_deepslate
setblock 50 142 586 minecraft:calcite
fill 50 142 587 50 145 587 minecraft:cobbled_deepslate
setblock 51 142 585 minecraft:calcite
setblock 51 142 586 minecraft:cobbled_deepslate
setblock 63 142 558 minecraft:calcite
fill 63 142 561 63 145 561 minecraft:deepslate
fill 63 142 564 65 145 564 minecraft:deepslate
fill 64 142 558 64 145 558 minecraft:cobbled_deepslate
fill 65 142 561 65 145 561 minecraft:deepslate
setblock 66 142 560 minecraft:calcite
setblock 67 142 559 minecraft:calcite
fill 67 142 560 67 145 560 minecraft:cobbled_deepslate
setblock 68 142 558 minecraft:calcite
fill 68 142 559 68 145 559 minecraft:cobbled_deepslate
setblock 68 142 598 minecraft:calcite
fill 69 142 558 69 145 558 minecraft:cobbled_deepslate
fill 69 142 598 69 143 598 minecraft:cobbled_deepslate
setblock 70 142 561 minecraft:calcite
setblock 71 142 560 minecraft:calcite
setblock 71 142 561 minecraft:cobbled_deepslate
fill 71 142 562 71 144 562 minecraft:light_blue_stained_glass
setblock 72 142 559 minecraft:calcite
fill 72 142 560 72 143 560 minecraft:cobbled_deepslate
fill 72 142 561 72 144 561 minecraft:light_blue_stained_glass
setblock 73 142 558 minecraft:calcite
fill 73 142 559 76 142 559 minecraft:cobbled_deepslate
setblock 73 142 598 minecraft:calcite
fill 74 142 558 74 144 558 minecraft:cobbled_deepslate
fill 74 142 560 75 143 560 minecraft:light_blue_stained_glass
fill 75 142 562 77 143 562 minecraft:light_blue_stained_glass
fill 77 142 559 78 143 559 minecraft:light_blue_stained_glass
setblock 78 142 558 minecraft:calcite
setblock 79 142 558 minecraft:cobbled_deepslate
setblock 83 142 558 minecraft:calcite
setblock 83 142 598 minecraft:calcite
fill 84 142 558 84 145 558 minecraft:cobbled_deepslate
fill 84 142 598 84 145 598 minecraft:cobbled_deepslate
fill 86 142 583 86 142 584 minecraft:cobbled_deepslate
setblock 86 142 585 minecraft:calcite
fill 86 142 586 86 145 586 minecraft:cobbled_deepslate
fill 86 142 588 86 142 589 minecraft:cobbled_deepslate
setblock 86 142 590 minecraft:calcite
fill 86 142 591 86 145 591 minecraft:cobbled_deepslate
setblock 87 142 559 minecraft:calcite
fill 87 142 560 87 143 560 minecraft:cobbled_deepslate
setblock 87 142 564 minecraft:calcite
fill 87 142 565 87 145 565 minecraft:cobbled_deepslate
fill 87 142 567 87 143 567 minecraft:cobbled_deepslate
setblock 87 142 580 minecraft:cobbled_deepslate
setblock 87 142 584 minecraft:calcite
fill 87 142 585 87 145 585 minecraft:cobbled_deepslate
setblock 87 142 588 minecraft:cobbled_deepslate
setblock 87 142 589 minecraft:calcite
fill 87 142 590 87 145 590 minecraft:cobbled_deepslate
setblock 87 142 594 minecraft:calcite
fill 87 142 595 87 145 595 minecraft:cobbled_deepslate
setblock 88 142 558 minecraft:calcite
fill 88 142 559 88 145 559 minecraft:cobbled_deepslate
setblock 88 142 563 minecraft:calcite
fill 88 142 564 88 145 564 minecraft:cobbled_deepslate
setblock 88 142 568 minecraft:calcite
fill 88 142 569 88 145 569 minecraft:cobbled_deepslate
setblock 88 142 577 minecraft:cobbled_deepslate
setblock 88 142 578 minecraft:calcite
fill 88 142 579 88 145 579 minecraft:cobbled_deepslate
setblock 88 142 583 minecraft:calcite
fill 88 142 584 88 145 584 minecraft:cobbled_deepslate
setblock 88 142 588 minecraft:calcite
fill 88 142 589 88 145 589 minecraft:cobbled_deepslate
setblock 88 142 593 minecraft:calcite
fill 88 142 594 88 145 594 minecraft:cobbled_deepslate
setblock 88 142 598 minecraft:calcite
setblock 48 143 558 minecraft:cobbled_deepslate
setblock 48 143 562 minecraft:calcite
fill 48 143 563 48 143 566 minecraft:cobbled_deepslate
setblock 48 143 567 minecraft:calcite
fill 48 143 568 48 146 568 minecraft:cobbled_deepslate
setblock 48 143 572 minecraft:calcite
fill 48 143 573 48 146 573 minecraft:cobbled_deepslate
setblock 48 143 577 minecraft:calcite
fill 48 143 578 48 143 581 minecraft:cobbled_deepslate
setblock 48 143 582 minecraft:calcite
fill 48 143 583 48 146 583 minecraft:cobbled_deepslate
setblock 48 143 587 minecraft:calcite
fill 48 143 588 48 146 588 minecraft:cobbled_deepslate
setblock 48 143 592 minecraft:calcite
fill 48 143 593 48 146 593 minecraft:cobbled_deepslate
setblock 48 143 597 minecraft:calcite
setblock 48 143 598 minecraft:cobbled_deepslate
setblock 49 143 562 minecraft:cobbled_deepslate
setblock 49 143 566 minecraft:calcite
fill 49 143 567 49 146 567 minecraft:cobbled_deepslate
fill 49 143 577 49 143 580 minecraft:cobbled_deepslate
setblock 49 143 581 minecraft:calcite
fill 49 143 582 49 146 582 minecraft:cobbled_deepslate
setblock 49 143 586 minecraft:calcite
fill 49 143 587 49 146 587 minecraft:cobbled_deepslate
setblock 49 143 591 minecraft:calcite
fill 49 143 592 49 146 592 minecraft:cobbled_deepslate
setblock 50 143 581 minecraft:cobbled_deepslate
setblock 50 143 585 minecraft:calcite
fill 50 143 586 50 146 586 minecraft:cobbled_deepslate
setblock 50 143 590 minecraft:calcite
fill 62 143 562 62 145 563 minecraft:deepslate
fill 63 143 558 63 146 558 minecraft:cobbled_deepslate
setblock 66 143 559 minecraft:calcite
fill 66 143 560 66 144 560 minecraft:cobbled_deepslate
fill 66 143 562 66 145 563 minecraft:deepslate
setblock 67 143 558 minecraft:calcite
fill 67 143 559 67 146 559 minecraft:cobbled_deepslate
fill 68 143 558 68 146 558 minecraft:cobbled_deepslate
setblock 68 143 598 minecraft:cobbled_deepslate
setblock 69 143 561 minecraft:calcite
setblock 70 143 560 minecraft:calcite
fill 70 143 561 70 144 562 minecraft:light_blue_stained_glass
setblock 71 143 559 minecraft:calcite
setblock 71 143 560 minecraft:cobbled_deepslate
fill 71 143 561 71 144 561 minecraft:light_blue_stained_glass
fill 71 143 563 71 144 563 minecraft:light_blue_stained_glass
setblock 72 143 558 minecraft:calcite
fill 72 143 559 74 143 559 minecraft:cobbled_deepslate
fill 72 143 562 72 144 562 minecraft:light_blue_stained_glass
fill 73 143 558 73 145 558 minecraft:cobbled_deepslate
fill 75 143 559 76 144 559 minecraft:light_blue_stained_glass
fill 75 143 563 77 143 563 minecraft:light_blue_stained_glass
fill 77 143 558 78 143 558 minecraft:light_blue_stained_glass
setblock 82 143 558 minecraft:calcite
fill 83 143 558 83 144 558 minecraft:cobbled_deepslate
fill 83 143 598 83 146 598 minecraft:cobbled_deepslate
setblock 86 143 559 minecraft:calcite
setblock 86 143 584 minecraft:calcite
fill 86 143 585 86 146 585 minecraft:cobbled_deepslate
setblock 86 143 588 minecraft:cobbled_deepslate
setblock 86 143 589 minecraft:calcite
fill 86 143 590 86 146 590 minecraft:cobbled_deepslate
fill 86 143 592 86 144 592 minecraft:cobbled_deepslate
setblock 87 143 558 minecraft:calcite
setblock 87 143 559 minecraft:cobbled_deepslate
setblock 87 143 563 minecraft:calcite
fill 87 143 564 87 145 564 minecraft:cobbled_deepslate
setblock 87 143 583 minecraft:calcite
fill 87 143 584 87 146 584 minecraft:cobbled_deepslate
setblock 87 143 588 minecraft:calcite
fill 87 143 589 87 146 589 minecraft:cobbled_deepslate
setblock 87 143 593 minecraft:calcite
fill 87 143 594 87 146 594 minecraft:cobbled_deepslate
setblock 87 143 598 minecraft:calcite
fill 88 143 558 88 144 558 minecraft:cobbled_deepslate
setblock 88 143 562 minecraft:calcite
fill 88 143 563 88 146 563 minecraft:cobbled_deepslate
setblock 88 143 567 minecraft:calcite
fill 88 143 568 88 146 568 minecraft:cobbled_deepslate
fill 88 143 578 88 144 578 minecraft:cobbled_deepslate
setblock 88 143 582 minecraft:calcite
fill 88 143 583 88 146 583 minecraft:cobbled_deepslate
setblock 88 143 587 minecraft:calcite
fill 88 143 588 88 146 588 minecraft:cobbled_deepslate
setblock 88 143 592 minecraft:calcite
fill 88 143 593 88 146 593 minecraft:cobbled_deepslate
setblock 88 143 597 minecraft:calcite
fill 88 143 598 88 146 598 minecraft:cobbled_deepslate
setblock 48 144 561 minecraft:calcite
fill 48 144 562 48 144 565 minecraft:cobbled_deepslate
setblock 48 144 566 minecraft:calcite
fill 48 144 567 48 147 567 minecraft:cobbled_deepslate
setblock 48 144 571 minecraft:calcite
fill 48 144 572 48 147 572 minecraft:cobbled_deepslate
setblock 48 144 576 minecraft:calcite
fill 48 144 577 48 144 580 minecraft:cobbled_deepslate
setblock 48 144 581 minecraft:calcite
fill 48 144 582 48 147 582 minecraft:cobbled_deepslate
setblock 48 144 586 minecraft:calcite
fill 48 144 587 48 147 587 minecraft:cobbled_deepslate
setblock 48 144 591 minecraft:calcite
fill 48 144 592 48 147 592 minecraft:cobbled_deepslate
setblock 48 144 596 minecraft:calcite
setblock 49 144 565 minecraft:calcite
fill 49 144 566 49 147 566 minecraft:cobbled_deepslate
setblock 49 144 570 minecraft:calcite
fill 49 144 578 49 144 579 minecraft:cobbled_deepslate
setblock 49 144 580 minecraft:calcite
fill 49 144 581 49 147 581 minecraft:cobbled_deepslate
setblock 49 144 585 minecraft:calcite
fill 49 144 586 49 147 586 minecraft:cobbled_deepslate
setblock 49 144 590 minecraft:calcite
fill 49 144 591 49 147 591 minecraft:cobbled_deepslate
setblock 50 144 584 minecraft:calcite
fill 50 144 585 50 145 585 minecraft:cobbled_deepslate
setblock 50 144 589 minecraft:calcite
fill 62 144 561 62 145 561 minecraft:deepslate
fill 62 144 564 62 145 564 minecraft:deepslate
fill 63 144 560 65 145 560 minecraft:deepslate
fill 63 144 565 65 145 565 minecraft:deepslate
setblock 65 144 559 minecraft:calcite
setblock 66 144 558 minecraft:calcite
fill 66 144 559 66 147 559 minecraft:cobbled_deepslate
fill 66 144 561 66 145 561 minecraft:deepslate
fill 66 144 564 66 145 564 minecraft:deepslate
fill 67 144 558 67 147 558 minecraft:cobbled_deepslate
setblock 69 144 560 minecraft:calcite
setblock 70 144 559 minecraft:calcite
setblock 70 144 560 minecraft:cobbled_deepslate
setblock 70 144 563 minecraft:light_blue_stained_glass
setblock 71 144 558 minecraft:calcite
fill 71 144 559 72 144 559 minecraft:cobbled_deepslate
fill 71 144 560 72 144 560 minecraft:light_blue_stained_glass
fill 71 144 564 71 145 564 minecraft:light_blue_stained_glass
fill 72 144 558 72 146 558 minecraft:cobbled_deepslate
setblock 72 144 563 minecraft:light_blue_stained_glass
fill 75 144 558 77 144 558 minecraft:light_blue_stained_glass
fill 75 144 560 77 144 560 minecraft:light_blue_stained_glass
fill 76 144 562 76 144 564 minecraft:light_blue_stained_glass
setblock 77 144 559 minecraft:light_blue_stained_glass
fill 84 144 591 84 147 591 minecraft:deepslate
fill 85 144 590 85 145 590 minecraft:deepslate
fill 85 144 592 85 146 592 minecraft:deepslate
setblock 86 144 558 minecraft:calcite
fill 86 144 584 86 147 584 minecraft:cobbled_deepslate
setblock 86 144 588 minecraft:calcite
fill 86 144 589 86 147 589 minecraft:cobbled_deepslate
setblock 86 144 598 minecraft:calcite
fill 87 144 558 87 145 558 minecraft:cobbled_deepslate
setblock 87 144 562 minecraft:calcite
fill 87 144 563 87 145 563 minecraft:cobbled_deepslate
setblock 87 144 567 minecraft:calcite
setblock 87 144 582 minecraft:calcite
fill 87 144 583 87 147 583 minecraft:cobbled_deepslate
setblock 87 144 587 minecraft:calcite
fill 87 144 588 87 147 588 minecraft:cobbled_deepslate
setblock 87 144 592 minecraft:calcite
fill 87 144 593 87 147 593 minecraft:cobbled_deepslate
setblock 87 144 597 minecraft:calcite
fill 87 144 598 87 147 598 minecraft:cobbled_deepslate
setblock 88 144 561 minecraft:calcite
fill 88 144 562 88 147 562 minecraft:cobbled_deepslate
setblock 88 144 566 minecraft:calcite
fill 88 144 567 88 147 567 minecraft:cobbled_deepslate
setblock 88 144 571 minecraft:calcite
setblock 88 144 581 minecraft:calcite
fill 88 144 582 88 147 582 minecraft:cobbled_deepslate
setblock 88 144 586 minecraft:calcite
fill 88 144 587 88 147 587 minecraft:cobbled_deepslate
setblock 88 144 591 minecraft:calcite
fill 88 144 592 88 147 592 minecraft:cobbled_deepslate
setblock 88 144 596 minecraft:calcite
fill 88 144 597 88 147 597 minecraft:cobbled_deepslate
fill 48 145 561 48 145 564 minecraft:cobbled_deepslate
setblock 48 145 565 minecraft:calcite
fill 48 145 566 48 148 566 minecraft:cobbled_deepslate
setblock 48 145 570 minecraft:calcite
fill 48 145 571 49 147 571 minecraft:cobbled_deepslate
setblock 48 145 575 minecraft:calcite
fill 48 145 576 48 145 579 minecraft:cobbled_deepslate
setblock 48 145 580 minecraft:calcite
fill 48 145 581 48 148 581 minecraft:cobbled_deepslate
setblock 48 145 585 minecraft:calcite
fill 48 145 586 48 148 586 minecraft:cobbled_deepslate
setblock 48 145 590 minecraft:calcite
fill 48 145 591 48 148 591 minecraft:cobbled_deepslate
setblock 48 145 595 minecraft:calcite
setblock 49 145 564 minecraft:calcite
fill 49 145 565 49 148 565 minecraft:cobbled_deepslate
setblock 49 145 569 minecraft:calcite
fill 49 145 570 49 148 570 minecraft:cobbled_deepslate
setblock 49 145 579 minecraft:calcite
fill 49 145 580 49 146 580 minecraft:cobbled_deepslate
setblock 49 145 584 minecraft:calcite
fill 49 145 585 49 148 585 minecraft:cobbled_deepslate
setblock 49 145 589 minecraft:calcite
fill 49 145 590 49 148 590 minecraft:cobbled_deepslate
fill 50 145 570 50 148 570 minecraft:deepslate
setblock 50 145 584 minecraft:cobbled_deepslate
setblock 50 145 588 minecraft:calcite
setblock 50 145 589 minecraft:cobbled_deepslate
fill 61 145 561 61 145 563 minecraft:deepslate
setblock 62 145 560 minecraft:deepslate
setblock 62 145 565 minecraft:deepslate
setblock 65 145 558 minecraft:calcite
fill 65 145 559 65 148 559 minecraft:cobbled_deepslate
fill 66 145 558 66 148 558 minecraft:cobbled_deepslate
setblock 66 145 560 minecraft:deepslate
setblock 66 145 565 minecraft:deepslate
fill 67 145 562 67 145 563 minecraft:deepslate
setblock 68 145 560 minecraft:calcite
setblock 69 145 559 minecraft:calcite
setblock 70 145 558 minecraft:calcite
fill 70 145 559 71 145 559 minecraft:cobbled_deepslate
fill 71 145 558 71 148 558 minecraft:cobbled_deepslate
fill 82 145 598 82 147 598 minecraft:cobbled_deepslate
setblock 85 145 558 minecraft:calcite
setblock 85 145 598 minecraft:calcite
fill 86 145 558 86 146 558 minecraft:cobbled_deepslate
setblock 86 145 587 minecraft:calcite
fill 86 145 588 86 148 588 minecraft:cobbled_deepslate
setblock 86 145 592 minecraft:calcite
fill 86 145 593 86 148 593 minecraft:cobbled_deepslate
setblock 86 145 597 minecraft:calcite
fill 86 145 598 86 148 598 minecraft:cobbled_deepslate
setblock 87 145 566 minecraft:calcite
fill 87 145 567 87 148 567 minecraft:cobbled_deepslate
setblock 87 145 581 minecraft:calcite
fill 87 145 582 87 148 582 minecraft:cobbled_deepslate
setblock 87 145 586 minecraft:calcite
fill 87 145 587 87 148 587 minecraft:cobbled_deepslate
setblock 87 145 591 minecraft:calcite
fill 87 145 592 87 148 592 minecraft:cobbled_deepslate
setblock 87 145 596 minecraft:calcite
setblock 88 145 560 minecraft:calcite
fill 88 145 561 88 146 561 minecraft:cobbled_deepslate
setblock 88 145 565 minecraft:calcite
fill 88 145 566 88 148 566 minecraft:cobbled_deepslate
setblock 88 145 570 minecraft:calcite
fill 88 145 571 88 148 571 minecraft:cobbled_deepslate
setblock 88 145 580 minecraft:calcite
fill 88 145 581 88 148 581 minecraft:cobbled_deepslate
setblock 88 145 585 minecraft:calcite
fill 88 145 586 88 148 586 minecraft:cobbled_deepslate
setblock 88 145 590 minecraft:calcite
fill 88 145 591 88 148 591 minecraft:cobbled_deepslate
setblock 88 145 595 minecraft:calcite
fill 88 145 596 88 148 596 minecraft:cobbled_deepslate
fill 48 146 562 48 146 563 minecraft:cobbled_deepslate
setblock 48 146 564 minecraft:calcite
fill 48 146 565 48 149 565 minecraft:cobbled_deepslate
setblock 48 146 569 minecraft:calcite
fill 48 146 570 48 149 570 minecraft:cobbled_deepslate
setblock 48 146 574 minecraft:calcite
fill 48 146 575 48 146 578 minecraft:cobbled_deepslate
setblock 48 146 579 minecraft:calcite
fill 48 146 580 48 149 580 minecraft:cobbled_deepslate
setblock 48 146 584 minecraft:calcite
fill 48 146 585 48 149 585 minecraft:cobbled_deepslate
setblock 48 146 589 minecraft:calcite
fill 48 146 590 48 149 590 minecraft:cobbled_deepslate
setblock 48 146 594 minecraft:calcite
fill 48 146 595 48 149 595 minecraft:cobbled_deepslate
setblock 49 146 568 minecraft:calcite
fill 49 146 569 49 149 569 minecraft:cobbled_deepslate
setblock 49 146 572 minecraft:cobbled_deepslate
setblock 49 146 583 minecraft:calcite
fill 49 146 584 49 149 584 minecraft:cobbled_deepslate
setblock 49 146 588 minecraft:calcite
fill 49 146 589 49 149 589 minecraft:cobbled_deepslate
setblock 50 146 587 minecraft:calcite
setblock 50 146 588 minecraft:cobbled_deepslate
fill 57 146 597 57 151 597 minecraft:light_blue_stained_glass
fill 63 146 562 65 146 563 minecraft:light_blue_stained_glass
setblock 64 146 558 minecraft:calcite
fill 65 146 558 65 149 558 minecraft:cobbled_deepslate
setblock 68 146 559 minecraft:calcite
setblock 69 146 558 minecraft:calcite
fill 69 146 559 69 147 559 minecraft:cobbled_deepslate
fill 70 146 558 70 149 558 minecraft:cobbled_deepslate
fill 84 146 590 84 147 590 minecraft:deepslate
fill 84 146 592 84 147 592 minecraft:deepslate
setblock 84 146 598 minecraft:calcite
fill 85 146 558 85 149 558 minecraft:cobbled_deepslate
fill 85 146 588 85 147 590 minecraft:cobbled_deepslate
setblock 85 146 597 minecraft:calcite
fill 85 146 598 85 149 598 minecraft:cobbled_deepslate
setblock 86 146 586 minecraft:calcite
fill 86 146 587 86 149 587 minecraft:cobbled_deepslate
setblock 86 146 591 minecraft:calcite
fill 86 146 592 86 149 592 minecraft:cobbled_deepslate
fill 86 146 594 86 147 594 minecraft:cobbled_deepslate
fill 86 146 597 87 148 597 minecraft:cobbled_deepslate
setblock 87 146 565 minecraft:calcite
fill 87 146 566 87 149 566 minecraft:cobbled_deepslate
fill 87 146 568 87 147 568 minecraft:cobbled_deepslate
setblock 87 146 585 minecraft:calcite
fill 87 146 586 87 149 586 minecraft:cobbled_deepslate
setblock 87 146 590 minecraft:calcite
fill 87 146 591 87 149 591 minecraft:cobbled_deepslate
setblock 87 146 595 minecraft:calcite
fill 87 146 596 87 149 596 minecraft:cobbled_deepslate
setblock 88 146 564 minecraft:calcite
fill 88 146 565 88 149 565 minecraft:cobbled_deepslate
setblock 88 146 569 minecraft:calcite
fill 88 146 570 88 149 570 minecraft:cobbled_deepslate
fill 88 146 572 88 146 573 minecraft:cobbled_deepslate
setblock 88 146 579 minecraft:calcite
fill 88 146 580 88 149 580 minecraft:cobbled_deepslate
setblock 88 146 584 minecraft:calcite
fill 88 146 585 88 149 585 minecraft:cobbled_deepslate
setblock 88 146 589 minecraft:calcite
fill 88 146 590 88 149 590 minecraft:cobbled_deepslate
setblock 88 146 594 minecraft:calcite
fill 88 146 595 88 149 595 minecraft:cobbled_deepslate
setblock 48 147 562 minecraft:cobbled_deepslate
setblock 48 147 563 minecraft:calcite
fill 48 147 564 48 150 564 minecraft:cobbled_deepslate
setblock 48 147 568 minecraft:calcite
fill 48 147 569 48 150 569 minecraft:cobbled_deepslate
setblock 48 147 573 minecraft:calcite
fill 48 147 574 48 147 577 minecraft:cobbled_deepslate
setblock 48 147 578 minecraft:calcite
fill 48 147 579 48 150 579 minecraft:cobbled_deepslate
setblock 48 147 583 minecraft:calcite
fill 48 147 584 48 150 584 minecraft:cobbled_deepslate
setblock 48 147 588 minecraft:calcite
fill 48 147 589 48 150 589 minecraft:cobbled_deepslate
setblock 48 147 593 minecraft:calcite
fill 48 147 594 48 150 594 minecraft:cobbled_deepslate
fill 48 147 596 48 148 596 minecraft:cobbled_deepslate
setblock 49 147 567 minecraft:calcite
fill 49 147 568 49 150 568 minecraft:cobbled_deepslate
setblock 49 147 572 minecraft:calcite
fill 49 147 573 49 149 574 minecraft:cobbled_deepslate
setblock 49 147 582 minecraft:calcite
fill 49 147 583 49 149 583 minecraft:cobbled_deepslate
setblock 49 147 587 minecraft:calcite
fill 49 147 588 49 150 588 minecraft:cobbled_deepslate
setblock 49 147 592 minecraft:calcite
fill 50 147 569 50 149 569 minecraft:deepslate
fill 50 147 571 50 149 571 minecraft:deepslate
fill 51 147 570 51 149 570 minecraft:deepslate
fill 55 147 597 56 150 597 minecraft:light_blue_stained_glass
fill 56 147 595 58 150 596 minecraft:light_blue_stained_glass
fill 56 147 598 58 150 598 minecraft:light_blue_stained_glass
fill 58 147 597 59 150 597 minecraft:light_blue_stained_glass
setblock 62 147 558 minecraft:cobbled_deepslate
setblock 63 147 558 minecraft:calcite
fill 64 147 558 64 149 559 minecraft:cobbled_deepslate
fill 64 147 562 64 148 563 minecraft:light_blue_stained_glass
fill 66 147 598 67 147 598 minecraft:cobbled_deepslate
setblock 67 147 559 minecraft:calcite
setblock 68 147 558 minecraft:calcite
fill 68 147 559 68 150 559 minecraft:cobbled_deepslate
setblock 68 147 598 minecraft:calcite
fill 69 147 558 69 150 558 minecraft:cobbled_deepslate
fill 69 147 598 69 150 598 minecraft:cobbled_deepslate
fill 80 147 598 81 148 598 minecraft:cobbled_deepslate
setblock 83 147 597 minecraft:cobbled_deepslate
setblock 83 147 598 minecraft:calcite
fill 84 147 558 84 150 558 minecraft:cobbled_deepslate
setblock 84 147 597 minecraft:calcite
fill 84 147 598 84 150 598 minecraft:cobbled_deepslate
fill 85 147 587 85 150 587 minecraft:cobbled_deepslate
setblock 85 147 591 minecraft:calcite
fill 85 147 592 85 150 592 minecraft:cobbled_deepslate
fill 85 147 597 85 150 597 minecraft:cobbled_deepslate
setblock 86 147 585 minecraft:calcite
fill 86 147 586 86 150 586 minecraft:cobbled_deepslate
setblock 86 147 590 minecraft:calcite
fill 86 147 591 86 150 591 minecraft:cobbled_deepslate
setblock 86 147 595 minecraft:calcite
setblock 87 147 565 minecraft:cobbled_deepslate
setblock 87 147 569 minecraft:calcite
fill 87 147 570 87 150 570 minecraft:cobbled_deepslate
setblock 87 147 584 minecraft:calcite
fill 87 147 585 87 150 585 minecraft:cobbled_deepslate
setblock 87 147 589 minecraft:calcite
fill 87 147 590 87 150 590 minecraft:cobbled_deepslate
setblock 87 147 594 minecraft:calcite
fill 87 147 595 87 150 595 minecraft:cobbled_deepslate
setblock 88 147 563 minecraft:calcite
fill 88 147 564 88 150 564 minecraft:cobbled_deepslate
setblock 88 147 568 minecraft:calcite
fill 88 147 569 88 150 569 minecraft:cobbled_deepslate
setblock 88 147 572 minecraft:cobbled_deepslate
setblock 88 147 573 minecraft:calcite
fill 88 147 574 88 149 575 minecraft:cobbled_deepslate
setblock 88 147 578 minecraft:calcite
fill 88 147 579 88 150 579 minecraft:cobbled_deepslate
setblock 88 147 583 minecraft:calcite
fill 88 147 584 88 150 584 minecraft:cobbled_deepslate
setblock 88 147 588 minecraft:calcite
fill 88 147 589 88 150 589 minecraft:cobbled_deepslate
setblock 88 147 593 minecraft:calcite
fill 88 147 594 88 150 594 minecraft:cobbled_deepslate
setblock 88 147 598 minecraft:calcite
setblock 48 148 562 minecraft:calcite
fill 48 148 563 48 151 563 minecraft:cobbled_deepslate
setblock 48 148 567 minecraft:calcite
fill 48 148 568 48 151 568 minecraft:cobbled_deepslate
setblock 48 148 571 minecraft:cobbled_deepslate
setblock 48 148 572 minecraft:calcite
fill 48 148 573 48 148 576 minecraft:cobbled_deepslate
setblock 48 148 577 minecraft:calcite
fill 48 148 578 48 151 578 minecraft:cobbled_deepslate
setblock 48 148 582 minecraft:calcite
fill 48 148 583 48 151 583 minecraft:cobbled_deepslate
setblock 48 148 587 minecraft:calcite
fill 48 148 588 48 151 588 minecraft:cobbled_deepslate
setblock 48 148 592 minecraft:calcite
fill 48 148 593 49 150 593 minecraft:cobbled_deepslate
setblock 49 148 566 minecraft:calcite
fill 49 148 567 49 151 567 minecraft:cobbled_deepslate
setblock 49 148 571 minecraft:calcite
fill 49 148 572 49 151 572 minecraft:cobbled_deepslate
setblock 49 148 575 minecraft:cobbled_deepslate
setblock 49 148 582 minecraft:cobbled_deepslate
setblock 49 148 586 minecraft:calcite
fill 49 148 587 49 151 587 minecraft:cobbled_deepslate
setblock 49 148 591 minecraft:calcite
fill 49 148 592 49 151 592 minecraft:cobbled_deepslate
setblock 50 148 560 minecraft:light[level=14]
setblock 50 148 568 minecraft:light[level=14]
setblock 50 148 576 minecraft:light[level=14]
setblock 50 148 584 minecraft:light[level=14]
setblock 50 148 592 minecraft:light[level=14]
fill 51 148 569 51 149 569 minecraft:deepslate
fill 51 148 571 51 149 571 minecraft:deepslate
fill 55 148 596 55 149 596 minecraft:light_blue_stained_glass
fill 55 148 598 55 149 598 minecraft:light_blue_stained_glass
fill 56 148 594 58 150 594 minecraft:light_blue_stained_glass
fill 57 148 593 57 150 593 minecraft:light_blue_stained_glass
setblock 58 148 560 minecraft:light[level=14]
setblock 58 148 568 minecraft:light[level=14]
setblock 58 148 576 minecraft:light[level=14]
setblock 58 148 584 minecraft:light[level=14]
setblock 58 148 592 minecraft:light[level=14]
fill 59 148 596 59 149 596 minecraft:light_blue_stained_glass
fill 59 148 598 59 149 598 minecraft:light_blue_stained_glass
setblock 61 148 558 minecraft:cobbled_deepslate
setblock 62 148 558 minecraft:calcite
fill 63 148 558 63 150 559 minecraft:cobbled_deepslate
fill 64 148 598 66 148 598 minecraft:cobbled_deepslate
setblock 66 148 559 minecraft:calcite
setblock 66 148 560 minecraft:light[level=14]
setblock 66 148 568 minecraft:light[level=14]
setblock 66 148 576 minecraft:light[level=14]
setblock 66 148 592 minecraft:light[level=14]
setblock 67 148 558 minecraft:calcite
fill 67 148 559 67 151 559 minecraft:cobbled_deepslate
setblock 67 148 598 minecraft:calcite
fill 68 148 558 68 151 558 minecraft:cobbled_deepslate
fill 68 148 598 68 151 598 minecraft:cobbled_deepslate
fill 70 148 598 70 149 598 minecraft:cobbled_deepslate
setblock 74 148 560 minecraft:light[level=14]
setblock 74 148 568 minecraft:light[level=14]
setblock 74 148 576 minecraft:light[level=14]
setblock 74 148 584 minecraft:light[level=14]
setblock 74 148 592 minecraft:light[level=14]
fill 79 148 598 79 150 598 minecraft:cobbled_deepslate
fill 81 148 597 82 148 597 minecraft:cobbled_deepslate
setblock 82 148 560 minecraft:light[level=14]
setblock 82 148 568 minecraft:light[level=14]
setblock 82 148 576 minecraft:light[level=14]
setblock 82 148 584 minecraft:light[level=14]
setblock 82 148 592 minecraft:light[level=14]
setblock 82 148 598 minecraft:calcite
fill 83 148 558 83 151 558 minecraft:cobbled_deepslate
setblock 83 148 597 minecraft:calcite
fill 83 148 598 83 151 598 minecraft:cobbled_deepslate
setblock 84 148 596 minecraft:calcite
fill 84 148 597 84 151 597 minecraft:cobbled_deepslate
fill 85 148 588 85 148 589 minecraft:cobbled_deepslate
setblock 85 148 590 minecraft:calcite
fill 85 148 591 85 151 591 minecraft:cobbled_deepslate
fill 85 148 593 85 149 593 minecraft:cobbled_deepslate
fill 85 148 596 86 150 596 minecraft:cobbled_deepslate
setblock 86 148 584 minecraft:calcite
fill 86 148 585 86 151 585 minecraft:cobbled_deepslate
setblock 86 148 589 minecraft:calcite
fill 86 148 590 86 151 590 minecraft:cobbled_deepslate
setblock 86 148 594 minecraft:calcite
fill 86 148 595 86 151 595 minecraft:cobbled_deepslate
setblock 87 148 568 minecraft:calcite
fill 87 148 569 87 151 569 minecraft:cobbled_deepslate
fill 87 148 571 87 148 572 minecraft:cobbled_deepslate
setblock 87 148 583 minecraft:calcite
fill 87 148 584 87 151 584 minecraft:cobbled_deepslate
setblock 87 148 588 minecraft:calcite
fill 87 148 589 87 151 589 minecraft:cobbled_deepslate
setblock 87 148 593 minecraft:calcite
fill 87 148 594 87 151 594 minecraft:cobbled_deepslate
setblock 87 148 598 minecraft:calcite
fill 88 148 563 88 149 563 minecraft:cobbled_deepslate
setblock 88 148 567 minecraft:calcite
fill 88 148 568 88 151 568 minecraft:cobbled_deepslate
setblock 88 148 572 minecraft:calcite
fill 88 148 573 88 151 573 minecraft:cobbled_deepslate
setblock 88 148 576 minecraft:cobbled_deepslate
setblock 88 148 577 minecraft:calcite
fill 88 148 578 88 151 578 minecraft:cobbled_deepslate
setblock 88 148 582 minecraft:calcite
fill 88 148 583 88 151 583 minecraft:cobbled_deepslate
setblock 88 148 587 minecraft:calcite
fill 88 148 588 88 151 588 minecraft:cobbled_deepslate
setblock 88 148 592 minecraft:calcite
fill 88 148 593 88 151 593 minecraft:cobbled_deepslate
setblock 88 148 597 minecraft:calcite
fill 88 148 598 88 151 598 minecraft:cobbled_deepslate
setblock 48 149 566 minecraft:calcite
fill 48 149 567 48 152 567 minecraft:cobbled_deepslate
setblock 48 149 571 minecraft:calcite
fill 48 149 572 48 149 575 minecraft:cobbled_deepslate
setblock 48 149 576 minecraft:calcite
fill 48 149 577 49 151 577 minecraft:cobbled_deepslate
setblock 48 149 581 minecraft:calcite
fill 48 149 582 48 152 582 minecraft:cobbled_deepslate
setblock 48 149 586 minecraft:calcite
fill 48 149 587 48 152 587 minecraft:cobbled_deepslate
setblock 48 149 591 minecraft:calcite
fill 48 149 592 48 152 592 minecraft:cobbled_deepslate
setblock 48 149 596 minecraft:calcite
fill 48 149 597 48 152 597 minecraft:cobbled_deepslate
setblock 49 149 565 minecraft:calcite
fill 49 149 566 49 152 566 minecraft:cobbled_deepslate
setblock 49 149 570 minecraft:calcite
fill 49 149 571 49 152 571 minecraft:cobbled_deepslate
setblock 49 149 575 minecraft:calcite
fill 49 149 576 49 152 576 minecraft:cobbled_deepslate
setblock 49 149 585 minecraft:calcite
fill 49 149 586 49 151 586 minecraft:cobbled_deepslate
setblock 49 149 590 minecraft:calcite
fill 49 149 591 49 152 591 minecraft:cobbled_deepslate
fill 50 149 570 50 152 570 minecraft:cobbled_deepslate
setblock 55 149 595 minecraft:light_blue_stained_glass
fill 56 149 593 56 150 593 minecraft:light_blue_stained_glass
fill 57 149 591 57 150 592 minecraft:light_blue_stained_glass
fill 58 149 593 58 150 593 minecraft:light_blue_stained_glass
setblock 59 149 595 minecraft:light_blue_stained_glass
setblock 60 149 558 minecraft:cobbled_deepslate
setblock 61 149 558 minecraft:calcite
fill 62 149 558 62 151 559 minecraft:cobbled_deepslate
fill 62 149 598 65 149 598 minecraft:cobbled_deepslate
setblock 64 149 562 minecraft:light_blue_stained_glass
setblock 65 149 559 minecraft:calcite
fill 65 149 597 66 149 597 minecraft:cobbled_deepslate
setblock 66 149 558 minecraft:calcite
fill 66 149 559 66 152 559 minecraft:cobbled_deepslate
setblock 66 149 598 minecraft:calcite
fill 67 149 558 67 152 558 minecraft:cobbled_deepslate
setblock 67 149 597 minecraft:calcite
fill 67 149 598 67 152 598 minecraft:cobbled_deepslate
setblock 71 149 558 minecraft:calcite
setblock 71 149 598 minecraft:calcite
fill 72 149 598 72 152 598 minecraft:cobbled_deepslate
fill 77 149 598 78 151 598 minecraft:cobbled_deepslate
fill 79 149 597 81 149 597 minecraft:cobbled_deepslate
setblock 80 149 598 minecraft:cobbled_deepslate
setblock 81 149 558 minecraft:calcite
fill 81 149 596 82 149 596 minecraft:cobbled_deepslate
setblock 81 149 598 minecraft:calcite
fill 82 149 558 82 152 558 minecraft:cobbled_deepslate
setblock 82 149 597 minecraft:calcite
fill 82 149 598 82 152 598 minecraft:cobbled_deepslate
setblock 83 149 596 minecraft:calcite
fill 83 149 597 83 152 597 minecraft:cobbled_deepslate
fill 84 149 596 84 152 596 minecraft:cobbled_deepslate
setblock 85 149 588 minecraft:cobbled_deepslate
setblock 85 149 589 minecraft:calcite
fill 85 149 590 85 152 590 minecraft:cobbled_deepslate
setblock 85 149 594 minecraft:calcite
setblock 86 149 558 minecraft:calcite
fill 86 149 584 86 151 584 minecraft:cobbled_deepslate
setblock 86 149 588 minecraft:calcite
fill 86 149 589 86 152 589 minecraft:cobbled_deepslate
setblock 86 149 593 minecraft:calcite
fill 86 149 594 86 152 594 minecraft:cobbled_deepslate
setblock 86 149 597 minecraft:cobbled_deepslate
setblock 86 149 598 minecraft:calcite
setblock 87 149 567 minecraft:calcite
fill 87 149 568 87 152 568 minecraft:cobbled_deepslate
setblock 87 149 571 minecraft:cobbled_deepslate
setblock 87 149 572 minecraft:calcite
fill 87 149 573 87 151 574 minecraft:cobbled_deepslate
setblock 87 149 581 minecraft:cobbled_deepslate
setblock 87 149 582 minecraft:calcite
fill 87 149 583 87 152 583 minecraft:cobbled_deepslate
setblock 87 149 587 minecraft:calcite
fill 87 149 588 87 152 588 minecraft:cobbled_deepslate
setblock 87 149 592 minecraft:calcite
fill 87 149 593 87 152 593 minecraft:cobbled_deepslate
setblock 87 149 597 minecraft:calcite
fill 87 149 598 87 152 598 minecraft:cobbled_deepslate
setblock 88 149 566 minecraft:calcite
fill 88 149 567 88 152 567 minecraft:cobbled_deepslate
setblock 88 149 571 minecraft:calcite
fill 88 149 572 88 152 572 minecraft:cobbled_deepslate
setblock 88 149 576 minecraft:calcite
fill 88 149 577 88 152 577 minecraft:cobbled_deepslate
setblock 88 149 581 minecraft:calcite
fill 88 149 582 88 152 582 minecraft:cobbled_deepslate
setblock 88 149 586 minecraft:calcite
fill 88 149 587 88 152 587 minecraft:cobbled_deepslate
setblock 88 149 591 minecraft:calcite
fill 88 149 592 88 152 592 minecraft:cobbled_deepslate
setblock 88 149 596 minecraft:calcite
fill 88 149 597 88 152 597 minecraft:cobbled_deepslate
setblock 48 150 565 minecraft:calcite
fill 48 150 566 48 153 566 minecraft:cobbled_deepslate
setblock 48 150 570 minecraft:calcite
fill 48 150 571 48 150 574 minecraft:cobbled_deepslate
setblock 48 150 575 minecraft:calcite
fill 48 150 576 48 153 576 minecraft:cobbled_deepslate
setblock 48 150 580 minecraft:calcite
fill 48 150 581 48 153 581 minecraft:cobbled_deepslate
setblock 48 150 585 minecraft:calcite
fill 48 150 586 48 153 586 minecraft:cobbled_deepslate
setblock 48 150 590 minecraft:calcite
fill 48 150 591 48 153 591 minecraft:cobbled_deepslate
setblock 48 150 595 minecraft:calcite
fill 48 150 596 48 153 596 minecraft:cobbled_deepslate
setblock 49 150 569 minecraft:calcite
fill 49 150 570 49 153 570 minecraft:cobbled_deepslate
setblock 49 150 573 minecraft:cobbled_deepslate
setblock 49 150 574 minecraft:calcite
fill 49 150 575 49 153 575 minecraft:cobbled_deepslate
setblock 49 150 578 minecraft:cobbled_deepslate
setblock 49 150 584 minecraft:calcite
setblock 49 150 585 minecraft:cobbled_deepslate
setblock 49 150 589 minecraft:calcite
fill 49 150 590 49 152 590 minecraft:cobbled_deepslate
setblock 49 150 594 minecraft:calcite
fill 50 150 569 50 152 569 minecraft:cobbled_deepslate
fill 50 150 571 50 150 572 minecraft:cobbled_deepslate
setblock 56 150 592 minecraft:light_blue_stained_glass
setblock 57 150 590 minecraft:light_blue_stained_glass
setblock 58 150 592 minecraft:light_blue_stained_glass
setblock 59 150 558 minecraft:cobbled_deepslate
setblock 60 150 558 minecraft:calcite
setblock 60 150 598 minecraft:calcite
fill 61 150 558 61 152 559 minecraft:cobbled_deepslate
fill 61 150 598 64 150 598 minecraft:cobbled_deepslate
fill 63 150 597 65 150 597 minecraft:cobbled_deepslate
setblock 64 150 558 minecraft:cobbled_deepslate
setblock 64 150 559 minecraft:calcite
setblock 65 150 558 minecraft:calcite
fill 65 150 559 65 153 559 minecraft:cobbled_deepslate
setblock 65 150 598 minecraft:calcite
fill 66 150 558 66 153 558 minecraft:cobbled_deepslate
setblock 66 150 597 minecraft:calcite
fill 66 150 598 66 153 598 minecraft:cobbled_deepslate
fill 67 150 597 69 151 597 minecraft:cobbled_deepslate
setblock 70 150 558 minecraft:calcite
setblock 70 150 598 minecraft:calcite
fill 71 150 558 71 153 558 minecraft:cobbled_deepslate
fill 71 150 598 71 153 598 minecraft:cobbled_deepslate
fill 73 150 598 74 150 598 minecraft:cobbled_deepslate
setblock 75 150 598 minecraft:calcite
fill 76 150 598 76 153 598 minecraft:cobbled_deepslate
fill 77 150 597 80 150 597 minecraft:cobbled_deepslate
fill 79 150 596 81 150 596 minecraft:cobbled_deepslate
setblock 80 150 558 minecraft:calcite
setblock 80 150 598 minecraft:calcite
fill 81 150 558 81 153 558 minecraft:cobbled_deepslate
setblock 81 150 597 minecraft:calcite
fill 81 150 598 81 153 598 minecraft:cobbled_deepslate
setblock 82 150 595 minecraft:cobbled_deepslate
setblock 82 150 596 minecraft:calcite
fill 82 150 597 82 153 597 minecraft:cobbled_deepslate
setblock 83 150 595 minecraft:calcite
fill 83 150 596 83 153 596 minecraft:cobbled_deepslate
fill 84 150 586 85 151 586 minecraft:light_blue_stained_glass
fill 84 150 590 84 151 592 minecraft:cobbled_deepslate
fill 84 150 595 85 152 595 minecraft:cobbled_deepslate
setblock 85 150 558 minecraft:calcite
fill 85 150 585 85 151 585 minecraft:light_blue_stained_glass
setblock 85 150 588 minecraft:calcite
fill 85 150 589 85 153 589 minecraft:cobbled_deepslate
setblock 85 150 593 minecraft:calcite
fill 85 150 594 85 153 594 minecraft:cobbled_deepslate
setblock 85 150 598 minecraft:calcite
fill 86 150 558 86 153 558 minecraft:cobbled_deepslate
setblock 86 150 587 minecraft:calcite
fill 86 150 588 86 153 588 minecraft:cobbled_deepslate
setblock 86 150 592 minecraft:calcite
fill 86 150 593 86 153 593 minecraft:cobbled_deepslate
setblock 86 150 597 minecraft:calcite
fill 86 150 598 86 153 598 minecraft:cobbled_deepslate
setblock 87 150 566 minecraft:calcite
fill 87 150 567 87 152 567 minecraft:cobbled_deepslate
setblock 87 150 571 minecraft:calcite
fill 87 150 572 87 153 572 minecraft:cobbled_deepslate
setblock 87 150 575 minecraft:cobbled_deepslate
setblock 87 150 576 minecraft:calcite
fill 87 150 577 87 153 577 minecraft:cobbled_deepslate
setblock 87 150 580 minecraft:cobbled_deepslate
setblock 87 150 581 minecraft:calcite
fill 87 150 582 87 153 582 minecraft:cobbled_deepslate
setblock 87 150 586 minecraft:calcite
fill 87 150 587 87 153 587 minecraft:cobbled_deepslate
setblock 87 150 591 minecraft:calcite
fill 87 150 592 87 153 592 minecraft:cobbled_deepslate
setblock 87 150 596 minecraft:calcite
fill 87 150 597 87 153 597 minecraft:cobbled_deepslate
setblock 88 150 565 minecraft:calcite
fill 88 150 566 88 153 566 minecraft:cobbled_deepslate
setblock 88 150 570 minecraft:calcite
fill 88 150 571 88 153 571 minecraft:cobbled_deepslate
setblock 88 150 574 minecraft:cobbled_deepslate
setblock 88 150 575 minecraft:calcite
fill 88 150 576 88 153 576 minecraft:cobbled_deepslate
setblock 88 150 580 minecraft:calcite
fill 88 150 581 88 153 581 minecraft:cobbled_deepslate
setblock 88 150 585 minecraft:calcite
fill 88 150 586 88 153 586 minecraft:cobbled_deepslate
setblock 88 150 590 minecraft:calcite
fill 88 150 591 88 153 591 minecraft:cobbled_deepslate
setblock 88 150 595 minecraft:calcite
fill 88 150 596 88 153 596 minecraft:cobbled_deepslate
setblock 48 151 564 minecraft:calcite
fill 48 151 565 48 154 565 minecraft:cobbled_deepslate
setblock 48 151 569 minecraft:calcite
fill 48 151 570 48 151 573 minecraft:cobbled_deepslate
setblock 48 151 574 minecraft:calcite
fill 48 151 575 48 154 575 minecraft:cobbled_deepslate
setblock 48 151 579 minecraft:calcite
fill 48 151 580 48 154 580 minecraft:cobbled_deepslate
setblock 48 151 584 minecraft:calcite
fill 48 151 585 48 154 585 minecraft:cobbled_deepslate
setblock 48 151 589 minecraft:calcite
fill 48 151 590 48 154 590 minecraft:cobbled_deepslate
setblock 48 151 593 minecraft:cobbled_deepslate
setblock 48 151 594 minecraft:calcite
fill 48 151 595 48 154 595 minecraft:cobbled_deepslate
setblock 49 151 568 minecraft:calcite
fill 49 151 569 49 154 569 minecraft:cobbled_deepslate
setblock 49 151 573 minecraft:calcite
fill 49 151 574 50 153 574 minecraft:cobbled_deepslate
setblock 49 151 578 minecraft:calcite
setblock 49 151 588 minecraft:calcite
fill 49 151 589 49 152 589 minecraft:cobbled_deepslate
setblock 49 151 593 minecraft:calcite
fill 49 151 594 49 152 594 minecraft:cobbled_deepslate
setblock 50 151 571 minecraft:cobbled_deepslate
setblock 50 151 572 minecraft:calcite
fill 50 151 573 50 154 573 minecraft:cobbled_deepslate
setblock 58 151 558 minecraft:cobbled_deepslate
setblock 59 151 558 minecraft:calcite
setblock 59 151 598 minecraft:calcite
fill 60 151 558 60 153 559 minecraft:cobbled_deepslate
fill 60 151 598 63 151 598 minecraft:cobbled_deepslate
fill 61 151 597 64 151 597 minecraft:cobbled_deepslate
setblock 63 151 558 minecraft:cobbled_deepslate
setblock 63 151 559 minecraft:calcite
fill 63 151 560 65 152 560 minecraft:cobbled_deepslate
setblock 64 151 558 minecraft:calcite
fill 64 151 559 64 154 559 minecraft:cobbled_deepslate
fill 64 151 596 65 151 596 minecraft:cobbled_deepslate
setblock 64 151 598 minecraft:calcite
fill 65 151 558 65 154 558 minecraft:cobbled_deepslate
setblock 65 151 597 minecraft:calcite
fill 65 151 598 65 154 598 minecraft:cobbled_deepslate
setblock 66 151 596 minecraft:calcite
fill 66 151 597 66 154 597 minecraft:cobbled_deepslate
setblock 68 151 559 minecraft:calcite
setblock 69 151 558 minecraft:calcite
setblock 69 151 598 minecraft:calcite
fill 70 151 558 70 154 558 minecraft:cobbled_deepslate
setblock 70 151 597 minecraft:calcite
fill 70 151 598 70 154 598 minecraft:cobbled_deepslate
fill 71 151 597 71 154 597 minecraft:cobbled_deepslate
fill 72 151 558 72 152 558 minecraft:cobbled_deepslate
setblock 73 151 598 minecraft:cobbled_deepslate
setblock 74 151 598 minecraft:calcite
setblock 75 151 597 minecraft:calcite
fill 75 151 598 75 154 598 minecraft:cobbled_deepslate
fill 76 151 597 79 151 597 minecraft:cobbled_deepslate
setblock 78 151 558 minecraft:cobbled_deepslate
fill 78 151 596 80 151 596 minecraft:cobbled_deepslate
setblock 79 151 558 minecraft:calcite
setblock 79 151 598 minecraft:calcite
fill 80 151 558 80 154 558 minecraft:cobbled_deepslate
fill 80 151 595 81 151 595 minecraft:cobbled_deepslate
setblock 80 151 597 minecraft:calcite
fill 80 151 598 80 154 598 minecraft:cobbled_deepslate
setblock 81 151 596 minecraft:calcite
fill 81 151 597 81 154 597 minecraft:cobbled_deepslate
setblock 82 151 595 minecraft:calcite
fill 82 151 596 82 154 596 minecraft:cobbled_deepslate
setblock 83 151 586 minecraft:light_blue_stained_glass
setblock 83 151 594 minecraft:calcite
fill 83 151 595 83 154 595 minecraft:cobbled_deepslate
setblock 84 151 558 minecraft:calcite
setblock 84 151 593 minecraft:calcite
fill 84 151 594 84 153 594 minecraft:cobbled_deepslate
setblock 84 151 598 minecraft:calcite
fill 85 151 558 85 154 558 minecraft:cobbled_deepslate
setblock 85 151 587 minecraft:calcite
fill 85 151 588 85 153 588 minecraft:cobbled_deepslate
setblock 85 151 592 minecraft:calcite
fill 85 151 593 85 154 593 minecraft:cobbled_deepslate
setblock 85 151 596 minecraft:cobbled_deepslate
setblock 85 151 597 minecraft:calcite
fill 85 151 598 85 154 598 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_5 1t
