setblock 263 64 504 minecraft:brown_terracotta
setblock 264 64 464 minecraft:bone_block
setblock 264 64 504 minecraft:bone_block
fill 265 64 464 265 66 465 minecraft:brown_terracotta
fill 265 64 504 265 67 504 minecraft:brown_terracotta
fill 266 64 503 267 66 503 minecraft:brown_terracotta
fill 267 64 504 268 64 504 minecraft:brown_terracotta
setblock 268 64 464 minecraft:brown_terracotta
setblock 268 64 465 minecraft:bone_block
setblock 269 64 464 minecraft:bone_block
fill 269 64 465 269 67 465 minecraft:brown_terracotta
setblock 269 64 504 minecraft:bone_block
fill 270 64 464 270 67 464 minecraft:brown_terracotta
fill 270 64 504 270 67 504 minecraft:brown_terracotta
fill 272 64 504 272 65 504 minecraft:brown_terracotta
setblock 274 64 464 minecraft:bone_block
setblock 274 64 474 minecraft:bone_block
fill 275 64 464 275 67 464 minecraft:brown_terracotta
setblock 275 64 473 minecraft:bone_block
fill 275 64 474 275 66 474 minecraft:brown_terracotta
fill 276 64 465 276 65 465 minecraft:brown_terracotta
setblock 276 64 467 minecraft:bone_block
fill 276 64 468 276 66 468 minecraft:brown_terracotta
setblock 276 64 472 minecraft:bone_block
fill 276 64 473 276 67 473 minecraft:brown_terracotta
setblock 276 64 477 minecraft:bone_block
fill 276 64 478 276 67 478 minecraft:brown_terracotta
fill 276 64 495 276 64 496 minecraft:brown_terracotta
setblock 276 64 497 minecraft:bone_block
fill 276 64 498 276 67 498 minecraft:brown_terracotta
setblock 276 64 501 minecraft:brown_terracotta
setblock 276 64 502 minecraft:bone_block
setblock 236 65 472 minecraft:brown_terracotta
setblock 236 65 476 minecraft:bone_block
fill 236 65 477 236 67 477 minecraft:brown_terracotta
setblock 236 65 496 minecraft:bone_block
fill 236 65 497 236 65 500 minecraft:brown_terracotta
setblock 236 65 501 minecraft:bone_block
fill 236 65 502 236 68 502 minecraft:brown_terracotta
fill 237 65 476 242 65 476 minecraft:soul_soil
setblock 237 65 494 minecraft:brown_terracotta
setblock 237 65 495 minecraft:bone_block
fill 237 65 496 237 65 499 minecraft:brown_terracotta
setblock 237 65 500 minecraft:bone_block
fill 237 65 501 238 67 501 minecraft:brown_terracotta
fill 237 65 503 237 65 504 minecraft:brown_terracotta
fill 238 65 474 242 66 475 minecraft:soul_soil
fill 238 65 477 242 66 478 minecraft:soul_soil
fill 238 65 496 238 65 498 minecraft:brown_terracotta
setblock 238 65 499 minecraft:bone_block
fill 238 65 500 238 68 500 minecraft:brown_terracotta
setblock 238 65 503 minecraft:brown_terracotta
setblock 238 65 504 minecraft:bone_block
setblock 239 65 502 minecraft:brown_terracotta
setblock 239 65 503 minecraft:bone_block
fill 239 65 504 239 68 504 minecraft:brown_terracotta
fill 240 65 464 240 67 464 minecraft:brown_terracotta
setblock 240 65 502 minecraft:bone_block
fill 240 65 503 243 65 503 minecraft:brown_terracotta
setblock 241 65 501 minecraft:bone_block
fill 241 65 502 244 65 502 minecraft:brown_terracotta
setblock 242 65 464 minecraft:brown_terracotta
fill 242 65 501 245 65 501 minecraft:brown_terracotta
setblock 243 65 464 minecraft:bone_block
setblock 243 65 504 minecraft:bone_block
fill 244 65 464 244 68 464 minecraft:brown_terracotta
fill 244 65 500 245 66 500 minecraft:brown_terracotta
setblock 244 65 503 minecraft:bone_block
fill 244 65 504 244 68 504 minecraft:brown_terracotta
setblock 245 65 502 minecraft:bone_block
fill 245 65 503 245 68 503 minecraft:brown_terracotta
fill 246 65 469 246 66 470 minecraft:soul_soil
setblock 246 65 501 minecraft:bone_block
fill 246 65 502 246 68 502 minecraft:brown_terracotta
setblock 247 65 464 minecraft:brown_terracotta
fill 247 65 501 247 67 501 minecraft:brown_terracotta
setblock 248 65 504 minecraft:bone_block
setblock 249 65 503 minecraft:bone_block
fill 249 65 504 249 68 504 minecraft:brown_terracotta
fill 250 65 503 250 67 503 minecraft:brown_terracotta
setblock 262 65 464 minecraft:brown_terracotta
setblock 262 65 504 minecraft:brown_terracotta
setblock 263 65 464 minecraft:bone_block
setblock 263 65 504 minecraft:bone_block
fill 264 65 464 264 67 465 minecraft:brown_terracotta
setblock 264 65 503 minecraft:bone_block
fill 264 65 504 264 68 504 minecraft:brown_terracotta
fill 265 65 503 265 68 503 minecraft:brown_terracotta
setblock 267 65 464 minecraft:brown_terracotta
setblock 267 65 465 minecraft:bone_block
setblock 267 65 504 minecraft:brown_terracotta
setblock 268 65 464 minecraft:bone_block
fill 268 65 465 268 68 465 minecraft:brown_terracotta
setblock 268 65 503 minecraft:brown_terracotta
setblock 268 65 504 minecraft:bone_block
fill 269 65 464 269 68 464 minecraft:brown_terracotta
setblock 269 65 503 minecraft:bone_block
fill 269 65 504 269 68 504 minecraft:brown_terracotta
setblock 273 65 464 minecraft:bone_block
setblock 273 65 504 minecraft:bone_block
fill 274 65 464 274 68 464 minecraft:brown_terracotta
fill 274 65 504 276 66 504 minecraft:brown_terracotta
setblock 275 65 472 minecraft:bone_block
fill 275 65 473 275 66 473 minecraft:brown_terracotta
setblock 275 65 476 minecraft:brown_terracotta
setblock 275 65 477 minecraft:bone_block
fill 276 65 464 276 66 464 minecraft:brown_terracotta
setblock 276 65 466 minecraft:bone_block
fill 276 65 467 276 66 467 minecraft:brown_terracotta
setblock 276 65 471 minecraft:bone_block
fill 276 65 472 276 67 472 minecraft:brown_terracotta
setblock 276 65 476 minecraft:bone_block
fill 276 65 477 276 68 477 minecraft:brown_terracotta
setblock 276 65 480 minecraft:brown_terracotta
setblock 276 65 495 minecraft:brown_terracotta
setblock 276 65 496 minecraft:bone_block
fill 276 65 497 276 68 497 minecraft:brown_terracotta
setblock 276 65 501 minecraft:bone_block
fill 276 65 502 276 67 503 minecraft:brown_terracotta
fill 236 66 475 236 68 475 minecraft:bone_block
fill 236 66 476 236 67 476 minecraft:brown_terracotta
fill 236 66 478 236 67 478 minecraft:brown_terracotta
setblock 236 66 495 minecraft:bone_block
fill 236 66 496 236 66 499 minecraft:brown_terracotta
setblock 236 66 500 minecraft:bone_block
fill 236 66 501 236 69 501 minecraft:brown_terracotta
fill 237 66 495 237 66 498 minecraft:brown_terracotta
setblock 237 66 499 minecraft:bone_block
fill 237 66 500 237 69 500 minecraft:brown_terracotta
setblock 237 66 503 minecraft:brown_terracotta
setblock 237 66 504 minecraft:bone_block
fill 238 66 476 242 66 476 minecraft:soul_soil
fill 238 66 496 238 66 497 minecraft:brown_terracotta
setblock 238 66 498 minecraft:bone_block
fill 238 66 499 239 68 499 minecraft:brown_terracotta
setblock 238 66 502 minecraft:brown_terracotta
setblock 238 66 503 minecraft:bone_block
fill 238 66 504 238 69 504 minecraft:brown_terracotta
fill 239 66 464 239 68 464 minecraft:brown_terracotta
setblock 239 66 502 minecraft:bone_block
fill 239 66 503 242 66 503 minecraft:brown_terracotta
setblock 240 66 501 minecraft:bone_block
fill 240 66 502 243 66 502 minecraft:brown_terracotta
fill 241 66 501 244 66 501 minecraft:brown_terracotta
setblock 242 66 464 minecraft:bone_block
setblock 242 66 504 minecraft:bone_block
fill 243 66 464 243 69 464 minecraft:brown_terracotta
fill 243 66 500 243 67 500 minecraft:brown_terracotta
setblock 243 66 503 minecraft:bone_block
fill 243 66 504 243 69 504 minecraft:brown_terracotta
setblock 244 66 502 minecraft:bone_block
fill 244 66 503 244 69 503 minecraft:brown_terracotta
setblock 245 66 501 minecraft:bone_block
fill 245 66 502 245 69 502 minecraft:brown_terracotta
fill 246 66 501 246 68 501 minecraft:brown_terracotta
setblock 247 66 464 minecraft:bone_block
setblock 247 66 504 minecraft:bone_block
setblock 248 66 502 minecraft:brown_terracotta
setblock 248 66 503 minecraft:bone_block
fill 248 66 504 248 69 504 minecraft:brown_terracotta
setblock 249 66 502 minecraft:bone_block
fill 249 66 503 249 68 503 minecraft:brown_terracotta
setblock 261 66 464 minecraft:brown_terracotta
setblock 261 66 504 minecraft:brown_terracotta
setblock 262 66 464 minecraft:bone_block
setblock 262 66 504 minecraft:bone_block
fill 263 66 464 263 69 464 minecraft:brown_terracotta
setblock 263 66 503 minecraft:bone_block
fill 263 66 504 263 69 504 minecraft:brown_terracotta
fill 264 66 503 264 69 503 minecraft:brown_terracotta
setblock 266 66 464 minecraft:brown_terracotta
setblock 266 66 465 minecraft:bone_block
setblock 267 66 464 minecraft:bone_block
fill 267 66 465 267 69 465 minecraft:brown_terracotta
setblock 267 66 504 minecraft:bone_block
fill 268 66 464 268 69 464 minecraft:brown_terracotta
setblock 268 66 503 minecraft:bone_block
fill 268 66 504 268 69 504 minecraft:brown_terracotta
fill 269 66 503 269 68 503 minecraft:brown_terracotta
setblock 272 66 464 minecraft:bone_block
setblock 272 66 504 minecraft:bone_block
fill 273 66 464 273 69 464 minecraft:brown_terracotta
fill 273 66 504 273 69 504 minecraft:brown_terracotta
setblock 275 66 476 minecraft:bone_block
setblock 275 66 477 minecraft:brown_terracotta
setblock 276 66 465 minecraft:bone_block
setblock 276 66 466 minecraft:brown_terracotta
setblock 276 66 470 minecraft:bone_block
fill 276 66 471 276 67 471 minecraft:brown_terracotta
setblock 276 66 475 minecraft:bone_block
fill 276 66 476 276 69 476 minecraft:brown_terracotta
setblock 276 66 480 minecraft:bone_block
fill 276 66 496 276 67 496 minecraft:brown_terracotta
setblock 276 66 499 minecraft:brown_terracotta
setblock 276 66 500 minecraft:bone_block
fill 276 66 501 276 69 501 minecraft:brown_terracotta
setblock 236 67 494 minecraft:bone_block
fill 236 67 495 236 67 498 minecraft:brown_terracotta
setblock 236 67 499 minecraft:bone_block
fill 236 67 500 236 70 500 minecraft:brown_terracotta
setblock 236 67 503 minecraft:brown_terracotta
setblock 236 67 504 minecraft:bone_block
fill 237 67 475 237 68 477 minecraft:bone_block
fill 237 67 495 237 67 497 minecraft:brown_terracotta
setblock 237 67 498 minecraft:bone_block
fill 237 67 499 237 70 499 minecraft:brown_terracotta
setblock 237 67 503 minecraft:bone_block
fill 237 67 504 237 70 504 minecraft:brown_terracotta
setblock 238 67 466 minecraft:light[level=12]
setblock 238 67 474 minecraft:light[level=12]
fill 238 67 475 238 68 475 minecraft:bone_block
fill 238 67 477 238 68 477 minecraft:bone_block
setblock 238 67 482 minecraft:light[level=12]
setblock 238 67 490 minecraft:light[level=12]
setblock 238 67 496 minecraft:brown_terracotta
setblock 238 67 497 minecraft:bone_block
fill 238 67 498 238 70 498 minecraft:brown_terracotta
setblock 238 67 502 minecraft:bone_block
fill 238 67 503 241 67 503 minecraft:brown_terracotta
setblock 239 67 500 minecraft:brown_terracotta
fill 239 67 502 242 67 502 minecraft:brown_terracotta
fill 240 67 501 243 67 501 minecraft:brown_terracotta
setblock 241 67 464 minecraft:bone_block
setblock 241 67 504 minecraft:bone_block
fill 242 67 464 242 70 464 minecraft:brown_terracotta
setblock 242 67 503 minecraft:bone_block
fill 242 67 504 242 70 504 minecraft:brown_terracotta
setblock 243 67 502 minecraft:bone_block
fill 243 67 503 243 70 503 minecraft:brown_terracotta
setblock 244 67 500 minecraft:brown_terracotta
setblock 244 67 501 minecraft:bone_block
fill 244 67 502 244 70 502 minecraft:brown_terracotta
fill 245 67 501 245 69 501 minecraft:brown_terracotta
setblock 246 67 464 minecraft:bone_block
setblock 246 67 466 minecraft:light[level=12]
setblock 246 67 474 minecraft:light[level=12]
setblock 246 67 482 minecraft:light[level=12]
setblock 246 67 490 minecraft:light[level=12]
setblock 246 67 498 minecraft:light[level=12]
setblock 246 67 504 minecraft:bone_block
setblock 247 67 503 minecraft:bone_block
fill 247 67 504 247 70 504 minecraft:brown_terracotta
setblock 248 67 502 minecraft:bone_block
fill 248 67 503 248 69 503 minecraft:brown_terracotta
setblock 251 67 504 minecraft:bone_block
setblock 254 67 466 minecraft:light[level=12]
setblock 254 67 474 minecraft:light[level=12]
setblock 254 67 490 minecraft:light[level=12]
setblock 254 67 498 minecraft:light[level=12]
fill 258 67 502 258 77 502 minecraft:bone_block
setblock 260 67 504 minecraft:brown_terracotta
setblock 261 67 464 minecraft:bone_block
setblock 261 67 504 minecraft:bone_block
fill 262 67 464 262 70 464 minecraft:brown_terracotta
setblock 262 67 466 minecraft:light[level=12]
setblock 262 67 474 minecraft:light[level=12]
setblock 262 67 482 minecraft:light[level=12]
setblock 262 67 490 minecraft:light[level=12]
setblock 262 67 498 minecraft:light[level=12]
setblock 262 67 503 minecraft:bone_block
fill 262 67 504 262 70 504 minecraft:brown_terracotta
fill 263 67 465 263 68 465 minecraft:brown_terracotta
fill 263 67 503 263 70 503 minecraft:brown_terracotta
setblock 265 67 464 minecraft:brown_terracotta
setblock 265 67 465 minecraft:bone_block
setblock 266 67 464 minecraft:bone_block
fill 266 67 465 266 70 465 minecraft:brown_terracotta
setblock 266 67 503 minecraft:brown_terracotta
setblock 266 67 504 minecraft:bone_block
fill 267 67 464 267 70 464 minecraft:brown_terracotta
setblock 267 67 503 minecraft:bone_block
fill 267 67 504 267 70 504 minecraft:brown_terracotta
fill 268 67 503 268 69 503 minecraft:brown_terracotta
setblock 270 67 466 minecraft:light[level=12]
setblock 270 67 474 minecraft:light[level=12]
setblock 270 67 482 minecraft:light[level=12]
setblock 270 67 490 minecraft:light[level=12]
setblock 270 67 498 minecraft:light[level=12]
setblock 271 67 464 minecraft:bone_block
setblock 271 67 504 minecraft:bone_block
fill 272 67 464 272 70 464 minecraft:brown_terracotta
fill 272 67 504 272 70 504 minecraft:brown_terracotta
fill 274 67 504 275 67 504 minecraft:brown_terracotta
setblock 276 67 464 minecraft:bone_block
fill 276 67 465 276 70 465 minecraft:brown_terracotta
setblock 276 67 470 minecraft:brown_terracotta
setblock 276 67 474 minecraft:bone_block
fill 276 67 475 276 69 475 minecraft:brown_terracotta
setblock 276 67 479 minecraft:bone_block
fill 276 67 480 276 69 480 minecraft:brown_terracotta
setblock 276 67 499 minecraft:bone_block
fill 276 67 500 276 70 500 minecraft:brown_terracotta
setblock 276 67 504 minecraft:bone_block
setblock 236 68 477 minecraft:bone_block
fill 236 68 494 236 68 497 minecraft:brown_terracotta
setblock 236 68 498 minecraft:bone_block
fill 236 68 499 236 71 499 minecraft:brown_terracotta
setblock 236 68 503 minecraft:bone_block
fill 236 68 504 236 71 504 minecraft:brown_terracotta
fill 237 68 495 237 68 496 minecraft:brown_terracotta
setblock 237 68 497 minecraft:bone_block
fill 237 68 498 237 71 498 minecraft:brown_terracotta
setblock 237 68 501 minecraft:brown_terracotta
setblock 237 68 502 minecraft:bone_block
fill 237 68 503 240 68 503 minecraft:brown_terracotta
fill 238 68 464 238 69 464 minecraft:brown_terracotta
fill 238 68 476 239 69 476 minecraft:bone_block
fill 238 68 497 238 69 497 minecraft:brown_terracotta
setblock 238 68 501 minecraft:bone_block
fill 238 68 502 241 68 502 minecraft:brown_terracotta
setblock 239 68 500 minecraft:bone_block
fill 239 68 501 242 68 501 minecraft:brown_terracotta
setblock 240 68 464 minecraft:bone_block
setblock 240 68 504 minecraft:bone_block
fill 241 68 464 241 71 464 minecraft:brown_terracotta
setblock 241 68 503 minecraft:bone_block
fill 241 68 504 241 71 504 minecraft:brown_terracotta
setblock 242 68 502 minecraft:bone_block
fill 242 68 503 242 71 503 minecraft:brown_terracotta
setblock 243 68 501 minecraft:bone_block
fill 243 68 502 243 71 502 minecraft:brown_terracotta
fill 244 68 501 244 70 501 minecraft:brown_terracotta
setblock 245 68 464 minecraft:bone_block
setblock 245 68 504 minecraft:bone_block
setblock 246 68 464 minecraft:brown_terracotta
setblock 246 68 503 minecraft:bone_block
fill 246 68 504 246 71 504 minecraft:brown_terracotta
setblock 247 68 502 minecraft:bone_block
fill 247 68 503 247 71 503 minecraft:brown_terracotta
setblock 248 68 502 minecraft:brown_terracotta
setblock 250 68 504 minecraft:bone_block
setblock 259 68 504 minecraft:brown_terracotta
setblock 260 68 464 minecraft:bone_block
setblock 260 68 504 minecraft:bone_block
fill 261 68 464 261 71 464 minecraft:brown_terracotta
setblock 261 68 503 minecraft:bone_block
fill 261 68 504 261 71 504 minecraft:brown_terracotta
fill 262 68 503 262 71 503 minecraft:brown_terracotta
setblock 264 68 464 minecraft:brown_terracotta
setblock 264 68 465 minecraft:bone_block
setblock 265 68 464 minecraft:bone_block
fill 265 68 465 265 71 465 minecraft:brown_terracotta
setblock 265 68 504 minecraft:bone_block
fill 266 68 464 266 71 464 minecraft:brown_terracotta
setblock 266 68 503 minecraft:bone_block
fill 266 68 504 266 71 504 minecraft:brown_terracotta
fill 267 68 503 267 70 503 minecraft:brown_terracotta
setblock 270 68 464 minecraft:bone_block
setblock 270 68 504 minecraft:bone_block
fill 271 68 464 271 71 464 minecraft:brown_terracotta
fill 271 68 504 271 71 504 minecraft:brown_terracotta
setblock 274 68 504 minecraft:brown_terracotta
setblock 275 68 464 minecraft:bone_block
setblock 275 68 504 minecraft:bone_block
fill 276 68 464 276 71 464 minecraft:brown_terracotta
setblock 276 68 473 minecraft:bone_block
setblock 276 68 474 minecraft:brown_terracotta
setblock 276 68 478 minecraft:bone_block
fill 276 68 479 276 70 479 minecraft:brown_terracotta
setblock 276 68 498 minecraft:bone_block
fill 276 68 499 276 71 499 minecraft:brown_terracotta
setblock 276 68 502 minecraft:brown_terracotta
setblock 276 68 503 minecraft:bone_block
fill 276 68 504 276 71 504 minecraft:brown_terracotta
fill 236 69 494 236 69 496 minecraft:brown_terracotta
setblock 236 69 497 minecraft:bone_block
fill 236 69 498 236 72 498 minecraft:brown_terracotta
setblock 236 69 502 minecraft:bone_block
fill 236 69 503 239 69 503 minecraft:brown_terracotta
setblock 237 69 496 minecraft:bone_block
fill 237 69 497 237 72 497 minecraft:brown_terracotta
setblock 237 69 501 minecraft:bone_block
fill 237 69 502 240 69 502 minecraft:brown_terracotta
setblock 238 69 499 minecraft:brown_terracotta
setblock 238 69 500 minecraft:bone_block
fill 238 69 501 241 69 501 minecraft:brown_terracotta
setblock 239 69 464 minecraft:bone_block
setblock 239 69 500 minecraft:brown_terracotta
setblock 239 69 504 minecraft:bone_block
fill 240 69 464 240 72 464 minecraft:brown_terracotta
fill 240 69 476 240 70 476 minecraft:bone_block
setblock 240 69 503 minecraft:bone_block
fill 240 69 504 240 72 504 minecraft:brown_terracotta
setblock 241 69 502 minecraft:bone_block
fill 241 69 503 241 72 503 minecraft:brown_terracotta
setblock 242 69 501 minecraft:bone_block
fill 242 69 502 242 72 502 minecraft:brown_terracotta
fill 243 69 501 243 70 501 minecraft:brown_terracotta
setblock 244 69 464 minecraft:bone_block
setblock 244 69 504 minecraft:bone_block
fill 245 69 464 245 70 464 minecraft:brown_terracotta
setblock 245 69 503 minecraft:bone_block
fill 245 69 504 245 72 504 minecraft:brown_terracotta
setblock 246 69 502 minecraft:bone_block
fill 246 69 503 246 72 503 minecraft:brown_terracotta
setblock 247 69 502 minecraft:brown_terracotta
setblock 249 69 504 minecraft:bone_block
setblock 250 69 504 minecraft:brown_terracotta
setblock 259 69 504 minecraft:bone_block
fill 260 69 464 260 72 464 minecraft:brown_terracotta
fill 260 69 504 260 72 504 minecraft:brown_terracotta
fill 261 69 503 261 72 503 minecraft:brown_terracotta
setblock 262 69 465 minecraft:brown_terracotta
setblock 263 69 465 minecraft:bone_block
setblock 264 69 464 minecraft:bone_block
fill 264 69 465 264 72 465 minecraft:brown_terracotta
setblock 264 69 504 minecraft:bone_block
fill 265 69 464 265 72 464 minecraft:brown_terracotta
setblock 265 69 503 minecraft:bone_block
fill 265 69 504 265 72 504 minecraft:brown_terracotta
fill 266 69 503 266 72 503 minecraft:brown_terracotta
setblock 269 69 464 minecraft:bone_block
setblock 269 69 504 minecraft:bone_block
fill 270 69 464 270 72 464 minecraft:brown_terracotta
fill 270 69 504 270 72 504 minecraft:brown_terracotta
setblock 274 69 464 minecraft:bone_block
setblock 274 69 504 minecraft:bone_block
fill 275 69 464 275 72 464 minecraft:brown_terracotta
fill 275 69 504 275 72 504 minecraft:brown_terracotta
setblock 276 69 477 minecraft:bone_block
fill 276 69 478 276 70 478 minecraft:brown_terracotta
setblock 276 69 497 minecraft:bone_block
fill 276 69 498 276 72 498 minecraft:brown_terracotta
setblock 276 69 502 minecraft:bone_block
fill 276 69 503 276 72 503 minecraft:brown_terracotta
setblock 236 70 495 minecraft:brown_terracotta
setblock 236 70 496 minecraft:bone_block
fill 236 70 497 236 73 497 minecraft:brown_terracotta
setblock 236 70 501 minecraft:bone_block
fill 236 70 502 238 70 503 minecraft:brown_terracotta
setblock 237 70 496 minecraft:brown_terracotta
setblock 237 70 500 minecraft:bone_block
fill 237 70 501 238 72 501 minecraft:brown_terracotta
setblock 238 70 464 minecraft:bone_block
setblock 238 70 499 minecraft:bone_block
fill 238 70 500 238 73 500 minecraft:brown_terracotta
setblock 238 70 504 minecraft:bone_block
fill 239 70 464 239 73 464 minecraft:brown_terracotta
setblock 239 70 502 minecraft:brown_terracotta
setblock 239 70 503 minecraft:bone_block
fill 239 70 504 239 73 504 minecraft:brown_terracotta
setblock 240 70 501 minecraft:brown_terracotta
setblock 240 70 502 minecraft:bone_block
fill 240 70 503 240 73 503 minecraft:brown_terracotta
fill 241 70 476 242 71 476 minecraft:bone_block
setblock 241 70 501 minecraft:bone_block
fill 241 70 502 241 73 502 minecraft:brown_terracotta
fill 242 70 501 242 71 501 minecraft:brown_terracotta
setblock 243 70 464 minecraft:bone_block
setblock 243 70 504 minecraft:bone_block
fill 244 70 464 244 73 464 minecraft:brown_terracotta
setblock 244 70 503 minecraft:bone_block
fill 244 70 504 244 73 504 minecraft:brown_terracotta
setblock 245 70 502 minecraft:bone_block
fill 245 70 503 245 73 503 minecraft:brown_terracotta
setblock 246 70 502 minecraft:brown_terracotta
setblock 248 70 504 minecraft:bone_block
setblock 249 70 504 minecraft:brown_terracotta
setblock 258 70 504 minecraft:bone_block
fill 259 70 464 259 73 464 minecraft:brown_terracotta
fill 259 70 504 259 73 504 minecraft:brown_terracotta
setblock 262 70 465 minecraft:bone_block
setblock 263 70 464 minecraft:bone_block
fill 263 70 465 263 73 465 minecraft:brown_terracotta
setblock 263 70 504 minecraft:bone_block
fill 264 70 464 264 73 464 minecraft:brown_terracotta
setblock 264 70 503 minecraft:bone_block
fill 264 70 504 264 73 504 minecraft:brown_terracotta
fill 265 70 503 265 73 503 minecraft:brown_terracotta
setblock 267 70 465 minecraft:bone_block
setblock 268 70 464 minecraft:bone_block
setblock 268 70 504 minecraft:bone_block
fill 269 70 464 269 73 464 minecraft:brown_terracotta
fill 269 70 504 269 73 504 minecraft:brown_terracotta
setblock 273 70 464 minecraft:bone_block
setblock 273 70 504 minecraft:bone_block
fill 274 70 464 274 73 464 minecraft:brown_terracotta
fill 274 70 504 274 73 504 minecraft:brown_terracotta
fill 275 70 503 275 73 503 minecraft:brown_terracotta
setblock 276 70 501 minecraft:bone_block
fill 276 70 502 276 73 502 minecraft:brown_terracotta
setblock 236 71 495 minecraft:bone_block
fill 236 71 496 236 74 496 minecraft:brown_terracotta
setblock 236 71 500 minecraft:bone_block
fill 236 71 501 236 72 503 minecraft:brown_terracotta
setblock 237 71 464 minecraft:bone_block
setblock 237 71 499 minecraft:bone_block
fill 237 71 500 237 74 500 minecraft:brown_terracotta
fill 237 71 502 237 71 503 minecraft:brown_terracotta
setblock 237 71 504 minecraft:bone_block
fill 238 71 464 238 74 464 minecraft:brown_terracotta
fill 238 71 499 238 74 499 minecraft:brown_terracotta
setblock 238 71 502 minecraft:brown_terracotta
setblock 238 71 503 minecraft:bone_block
fill 238 71 504 238 74 504 minecraft:brown_terracotta
setblock 239 71 502 minecraft:bone_block
fill 239 71 503 239 74 503 minecraft:brown_terracotta
setblock 240 71 501 minecraft:bone_block
fill 240 71 502 240 74 502 minecraft:brown_terracotta
setblock 241 71 501 minecraft:brown_terracotta
setblock 242 71 464 minecraft:bone_block
fill 242 71 475 244 72 475 minecraft:bone_block
fill 242 71 477 244 72 477 minecraft:bone_block
setblock 242 71 504 minecraft:bone_block
fill 243 71 464 243 74 464 minecraft:brown_terracotta
fill 243 71 476 243 72 476 minecraft:bone_block
setblock 243 71 503 minecraft:bone_block
fill 243 71 504 243 74 504 minecraft:brown_terracotta
setblock 244 71 502 minecraft:bone_block
fill 244 71 503 244 74 503 minecraft:brown_terracotta
setblock 245 71 502 minecraft:brown_terracotta
setblock 247 71 504 minecraft:bone_block
fill 248 71 504 248 72 504 minecraft:brown_terracotta
fill 258 71 464 258 74 464 minecraft:brown_terracotta
fill 258 71 504 258 74 504 minecraft:brown_terracotta
setblock 261 71 465 minecraft:bone_block
setblock 262 71 464 minecraft:bone_block
fill 262 71 465 262 74 465 minecraft:brown_terracotta
setblock 262 71 504 minecraft:bone_block
fill 263 71 464 263 74 464 minecraft:brown_terracotta
setblock 263 71 503 minecraft:bone_block
fill 263 71 504 263 74 504 minecraft:brown_terracotta
fill 264 71 503 264 74 503 minecraft:brown_terracotta
setblock 266 71 465 minecraft:bone_block
setblock 267 71 464 minecraft:bone_block
setblock 267 71 504 minecraft:bone_block
fill 268 71 464 268 74 464 minecraft:brown_terracotta
fill 268 71 504 268 74 504 minecraft:brown_terracotta
setblock 272 71 464 minecraft:bone_block
setblock 272 71 504 minecraft:bone_block
fill 273 71 464 273 74 464 minecraft:brown_terracotta
fill 273 71 502 273 80 502 minecraft:bone_block
fill 273 71 504 273 74 504 minecraft:brown_terracotta
fill 275 71 502 275 74 502 minecraft:brown_terracotta
setblock 276 71 465 minecraft:bone_block
setblock 276 71 500 minecraft:bone_block
fill 276 71 501 276 74 501 minecraft:brown_terracotta
setblock 236 72 464 minecraft:bone_block
fill 236 72 480 236 72 483 minecraft:brown_terracotta
setblock 236 72 484 minecraft:bone_block
fill 236 72 495 236 75 495 minecraft:brown_terracotta
setblock 236 72 499 minecraft:bone_block
fill 236 72 500 236 75 500 minecraft:brown_terracotta
setblock 236 72 504 minecraft:bone_block
fill 237 72 464 237 75 464 minecraft:brown_terracotta
setblock 237 72 498 minecraft:bone_block
fill 237 72 499 237 75 499 minecraft:brown_terracotta
setblock 237 72 502 minecraft:brown_terracotta
setblock 237 72 503 minecraft:bone_block
fill 237 72 504 237 75 504 minecraft:brown_terracotta
setblock 238 72 502 minecraft:bone_block
fill 238 72 503 238 75 503 minecraft:brown_terracotta
fill 239 72 502 239 75 502 minecraft:brown_terracotta
setblock 241 72 464 minecraft:bone_block
setblock 241 72 504 minecraft:bone_block
fill 242 72 464 242 75 464 minecraft:brown_terracotta
setblock 242 72 503 minecraft:bone_block
fill 242 72 504 242 75 504 minecraft:brown_terracotta
setblock 243 72 502 minecraft:bone_block
fill 243 72 503 243 75 503 minecraft:brown_terracotta
setblock 244 72 502 minecraft:brown_terracotta
setblock 246 72 504 minecraft:bone_block
fill 247 72 504 247 75 504 minecraft:brown_terracotta
fill 257 72 464 257 75 464 minecraft:brown_terracotta
fill 257 72 504 257 75 504 minecraft:brown_terracotta
setblock 260 72 465 minecraft:bone_block
fill 260 72 503 260 73 503 minecraft:brown_terracotta
setblock 261 72 464 minecraft:bone_block
fill 261 72 465 261 75 465 minecraft:brown_terracotta
setblock 261 72 504 minecraft:bone_block
fill 262 72 464 262 75 464 minecraft:brown_terracotta
setblock 262 72 503 minecraft:bone_block
fill 262 72 504 262 75 504 minecraft:brown_terracotta
fill 263 72 503 263 75 503 minecraft:brown_terracotta
setblock 265 72 465 minecraft:bone_block
setblock 266 72 464 minecraft:bone_block
fill 266 72 465 266 75 465 minecraft:brown_terracotta
setblock 266 72 504 minecraft:bone_block
fill 267 72 464 267 75 464 minecraft:brown_terracotta
fill 267 72 504 267 75 504 minecraft:brown_terracotta
setblock 271 72 464 minecraft:bone_block
setblock 271 72 504 minecraft:bone_block
fill 272 72 464 272 75 464 minecraft:brown_terracotta
fill 272 72 504 272 75 504 minecraft:brown_terracotta
setblock 276 72 464 minecraft:bone_block
fill 276 72 465 276 74 466 minecraft:brown_terracotta
setblock 276 72 499 minecraft:bone_block
fill 276 72 500 276 75 500 minecraft:brown_terracotta
setblock 276 72 504 minecraft:bone_block
fill 236 73 464 236 75 465 minecraft:brown_terracotta
fill 236 73 480 236 73 482 minecraft:brown_terracotta
setblock 236 73 483 minecraft:bone_block
fill 236 73 484 236 73 487 minecraft:brown_terracotta
setblock 236 73 498 minecraft:bone_block
fill 236 73 499 236 76 499 minecraft:brown_terracotta
fill 236 73 501 236 73 502 minecraft:brown_terracotta
setblock 236 73 503 minecraft:bone_block
fill 236 73 504 236 76 504 minecraft:brown_terracotta
fill 237 73 483 237 75 484 minecraft:brown_terracotta
setblock 237 73 497 minecraft:bone_block
fill 237 73 498 237 76 498 minecraft:brown_terracotta
setblock 237 73 501 minecraft:brown_terracotta
setblock 237 73 502 minecraft:bone_block
fill 237 73 503 237 76 503 minecraft:brown_terracotta
setblock 238 73 501 minecraft:bone_block
fill 238 73 502 238 76 502 minecraft:brown_terracotta
setblock 240 73 464 minecraft:bone_block
setblock 240 73 504 minecraft:bone_block
fill 241 73 464 241 76 464 minecraft:brown_terracotta
setblock 241 73 503 minecraft:bone_block
fill 241 73 504 241 76 504 minecraft:brown_terracotta
setblock 242 73 502 minecraft:bone_block
fill 242 73 503 242 76 503 minecraft:brown_terracotta
fill 243 73 502 243 74 502 minecraft:brown_terracotta
setblock 245 73 504 minecraft:bone_block
fill 246 73 504 246 76 504 minecraft:brown_terracotta
fill 249 73 488 249 74 488 minecraft:bone_block
fill 256 73 464 256 76 464 minecraft:brown_terracotta
fill 256 73 504 256 76 504 minecraft:brown_terracotta
fill 257 73 502 257 77 502 minecraft:bone_block
fill 258 73 501 258 77 501 minecraft:bone_block
fill 258 73 503 258 74 503 minecraft:bone_block
setblock 259 73 465 minecraft:bone_block
fill 259 73 502 259 77 502 minecraft:bone_block
setblock 260 73 464 minecraft:bone_block
fill 260 73 465 260 76 465 minecraft:brown_terracotta
setblock 260 73 504 minecraft:bone_block
fill 261 73 464 261 76 464 minecraft:brown_terracotta
setblock 261 73 503 minecraft:bone_block
fill 261 73 504 261 76 504 minecraft:brown_terracotta
fill 262 73 503 262 76 503 minecraft:brown_terracotta
setblock 264 73 465 minecraft:bone_block
setblock 265 73 464 minecraft:bone_block
fill 265 73 465 265 76 465 minecraft:brown_terracotta
setblock 265 73 504 minecraft:bone_block
fill 266 73 464 266 76 464 minecraft:brown_terracotta
fill 266 73 504 266 76 504 minecraft:brown_terracotta
fill 267 73 465 267 74 465 minecraft:brown_terracotta
setblock 270 73 464 minecraft:bone_block
setblock 270 73 504 minecraft:bone_block
fill 271 73 464 271 76 464 minecraft:brown_terracotta
fill 271 73 504 271 76 504 minecraft:brown_terracotta
fill 274 73 503 274 74 503 minecraft:brown_terracotta
setblock 275 73 464 minecraft:bone_block
fill 275 73 501 275 75 501 minecraft:brown_terracotta
setblock 275 73 504 minecraft:bone_block
fill 276 73 464 276 76 464 minecraft:brown_terracotta
setblock 276 73 467 minecraft:brown_terracotta
setblock 276 73 498 minecraft:bone_block
fill 276 73 499 276 76 499 minecraft:brown_terracotta
setblock 276 73 503 minecraft:bone_block
fill 276 73 504 276 76 504 minecraft:brown_terracotta
fill 236 74 479 236 74 481 minecraft:brown_terracotta
setblock 236 74 482 minecraft:bone_block
fill 236 74 483 236 74 486 minecraft:brown_terracotta
setblock 236 74 487 minecraft:bone_block
fill 236 74 488 236 74 491 minecraft:brown_terracotta
setblock 236 74 492 minecraft:bone_block
fill 236 74 493 236 76 494 minecraft:brown_terracotta
setblock 236 74 497 minecraft:bone_block
fill 236 74 498 236 77 498 minecraft:brown_terracotta
setblock 236 74 501 minecraft:brown_terracotta
setblock 236 74 502 minecraft:bone_block
fill 236 74 503 236 77 503 minecraft:brown_terracotta
setblock 237 74 481 minecraft:bone_block
fill 237 74 482 237 77 482 minecraft:brown_terracotta
setblock 237 74 485 minecraft:brown_terracotta
setblock 237 74 486 minecraft:bone_block
fill 237 74 487 237 76 488 minecraft:brown_terracotta
fill 237 74 497 237 77 497 minecraft:brown_terracotta
setblock 237 74 501 minecraft:bone_block
fill 237 74 502 237 77 502 minecraft:brown_terracotta
setblock 238 74 500 minecraft:bone_block
fill 238 74 501 238 77 501 minecraft:brown_terracotta
setblock 239 74 464 minecraft:bone_block
setblock 239 74 504 minecraft:bone_block
fill 240 74 464 240 77 464 minecraft:brown_terracotta
setblock 240 74 503 minecraft:bone_block
fill 240 74 504 240 77 504 minecraft:brown_terracotta
setblock 241 74 502 minecraft:bone_block
fill 241 74 503 241 77 503 minecraft:brown_terracotta
fill 242 74 502 242 76 502 minecraft:brown_terracotta
setblock 244 74 464 minecraft:bone_block
setblock 244 74 504 minecraft:bone_block
setblock 245 74 503 minecraft:bone_block
fill 245 74 504 245 77 504 minecraft:brown_terracotta
fill 255 74 464 255 77 464 minecraft:brown_terracotta
setblock 258 74 465 minecraft:bone_block
setblock 259 74 464 minecraft:bone_block
fill 259 74 465 259 77 465 minecraft:brown_terracotta
setblock 259 74 503 minecraft:brown_terracotta
setblock 259 74 504 minecraft:bone_block
fill 260 74 464 260 77 464 minecraft:brown_terracotta
setblock 260 74 503 minecraft:bone_block
fill 260 74 504 260 77 504 minecraft:brown_terracotta
fill 261 74 503 261 77 503 minecraft:brown_terracotta
setblock 262 74 466 minecraft:bone_block
setblock 263 74 465 minecraft:bone_block
setblock 264 74 464 minecraft:bone_block
fill 264 74 465 264 77 465 minecraft:brown_terracotta
setblock 264 74 504 minecraft:bone_block
fill 265 74 464 265 77 464 minecraft:brown_terracotta
setblock 265 74 503 minecraft:bone_block
fill 265 74 504 265 77 504 minecraft:brown_terracotta
setblock 269 74 464 minecraft:bone_block
setblock 269 74 504 minecraft:bone_block
fill 270 74 464 270 77 464 minecraft:brown_terracotta
fill 270 74 504 270 77 504 minecraft:brown_terracotta
fill 273 74 503 273 75 503 minecraft:brown_terracotta
setblock 274 74 464 minecraft:bone_block
setblock 274 74 504 minecraft:bone_block
fill 275 74 464 275 76 465 minecraft:brown_terracotta
setblock 275 74 503 minecraft:bone_block
fill 275 74 504 275 77 504 minecraft:brown_terracotta
setblock 276 74 467 minecraft:bone_block
fill 276 74 468 276 77 468 minecraft:brown_terracotta
setblock 276 74 481 minecraft:brown_terracotta
setblock 276 74 482 minecraft:bone_block
fill 276 74 483 276 75 485 minecraft:brown_terracotta
fill 276 74 498 276 77 498 minecraft:brown_terracotta
setblock 276 74 502 minecraft:bone_block
fill 276 74 503 276 77 503 minecraft:brown_terracotta
setblock 236 75 466 minecraft:bone_block
fill 236 75 467 236 78 467 minecraft:brown_terracotta
fill 236 75 479 236 75 480 minecraft:brown_terracotta
setblock 236 75 481 minecraft:bone_block
fill 236 75 482 236 75 485 minecraft:brown_terracotta
setblock 236 75 486 minecraft:bone_block
fill 236 75 487 236 75 490 minecraft:brown_terracotta
setblock 236 75 491 minecraft:bone_block
fill 236 75 492 237 77 492 minecraft:brown_terracotta
setblock 236 75 496 minecraft:bone_block
fill 236 75 497 236 78 497 minecraft:brown_terracotta
setblock 236 75 501 minecraft:bone_block
fill 236 75 502 236 78 502 minecraft:brown_terracotta
setblock 237 75 465 minecraft:bone_block
setblock 237 75 480 minecraft:bone_block
fill 237 75 481 237 78 481 minecraft:brown_terracotta
setblock 237 75 485 minecraft:bone_block
fill 237 75 486 238 77 486 minecraft:brown_terracotta
setblock 237 75 489 minecraft:brown_terracotta
setblock 237 75 490 minecraft:bone_block
fill 237 75 491 237 78 491 minecraft:brown_terracotta
setblock 237 75 495 minecraft:bone_block
fill 237 75 496 237 78 496 minecraft:brown_terracotta
setblock 237 75 500 minecraft:bone_block
fill 237 75 501 237 78 501 minecraft:brown_terracotta
setblock 238 75 464 minecraft:bone_block
fill 238 75 465 241 75 465 minecraft:brown_terracotta
setblock 238 75 466 minecraft:light[level=12]
setblock 238 75 474 minecraft:light[level=12]
fill 238 75 482 238 75 483 minecraft:brown_terracotta
setblock 238 75 484 minecraft:bone_block
fill 238 75 485 238 78 485 minecraft:brown_terracotta
fill 238 75 487 238 75 488 minecraft:brown_terracotta
setblock 238 75 490 minecraft:light[level=12]
setblock 238 75 498 minecraft:light[level=12]
setblock 238 75 499 minecraft:bone_block
fill 238 75 500 238 78 500 minecraft:brown_terracotta
setblock 238 75 504 minecraft:bone_block
fill 239 75 464 239 78 464 minecraft:brown_terracotta
setblock 239 75 503 minecraft:bone_block
fill 239 75 504 239 78 504 minecraft:brown_terracotta
setblock 240 75 502 minecraft:bone_block
fill 240 75 503 240 78 503 minecraft:brown_terracotta
fill 241 75 502 241 77 502 minecraft:brown_terracotta
setblock 243 75 464 minecraft:bone_block
setblock 243 75 504 minecraft:bone_block
fill 244 75 464 245 77 464 minecraft:brown_terracotta
setblock 244 75 503 minecraft:bone_block
fill 244 75 504 244 78 504 minecraft:brown_terracotta
setblock 246 75 466 minecraft:light[level=12]
setblock 246 75 474 minecraft:light[level=12]
setblock 246 75 482 minecraft:light[level=12]
setblock 246 75 490 minecraft:light[level=12]
setblock 246 75 498 minecraft:light[level=12]
fill 254 75 464 254 78 464 minecraft:brown_terracotta
setblock 254 75 466 minecraft:light[level=12]
setblock 254 75 474 minecraft:light[level=12]
setblock 254 75 490 minecraft:light[level=12]
setblock 254 75 498 minecraft:light[level=12]
fill 255 75 504 255 77 504 minecraft:brown_terracotta
setblock 256 75 465 minecraft:brown_terracotta
setblock 257 75 465 minecraft:bone_block
fill 257 75 501 257 77 501 minecraft:bone_block
setblock 257 75 503 minecraft:bone_block
setblock 258 75 464 minecraft:bone_block
fill 258 75 465 258 78 465 minecraft:brown_terracotta
setblock 258 75 503 minecraft:brown_terracotta
setblock 258 75 504 minecraft:bone_block
fill 259 75 464 259 78 464 minecraft:brown_terracotta
fill 259 75 466 260 75 466 minecraft:brown_terracotta
fill 259 75 501 259 77 501 minecraft:bone_block
setblock 259 75 503 minecraft:bone_block
fill 259 75 504 259 78 504 minecraft:brown_terracotta
fill 260 75 503 260 78 503 minecraft:brown_terracotta
setblock 261 75 466 minecraft:bone_block
setblock 262 75 465 minecraft:bone_block
fill 262 75 466 264 76 466 minecraft:brown_terracotta
setblock 262 75 474 minecraft:light[level=12]
setblock 262 75 482 minecraft:light[level=12]
setblock 262 75 490 minecraft:light[level=12]
setblock 262 75 498 minecraft:light[level=12]
setblock 263 75 464 minecraft:bone_block
fill 263 75 465 263 78 465 minecraft:brown_terracotta
setblock 263 75 504 minecraft:bone_block
fill 264 75 464 264 78 464 minecraft:brown_terracotta
setblock 264 75 503 minecraft:bone_block
fill 264 75 504 264 78 504 minecraft:brown_terracotta
fill 265 75 503 265 77 503 minecraft:brown_terracotta
setblock 267 75 465 minecraft:bone_block
setblock 268 75 464 minecraft:bone_block
fill 268 75 465 269 77 465 minecraft:brown_terracotta
setblock 268 75 504 minecraft:bone_block
fill 269 75 464 269 78 464 minecraft:brown_terracotta
fill 269 75 504 269 78 504 minecraft:brown_terracotta
setblock 270 75 466 minecraft:light[level=12]
setblock 270 75 474 minecraft:light[level=12]
setblock 270 75 482 minecraft:light[level=12]
setblock 270 75 490 minecraft:light[level=12]
setblock 270 75 498 minecraft:light[level=12]
setblock 272 75 465 minecraft:bone_block
setblock 273 75 464 minecraft:bone_block
fill 273 75 465 274 77 465 minecraft:brown_terracotta
setblock 273 75 504 minecraft:bone_block
fill 274 75 464 274 78 464 minecraft:brown_terracotta
setblock 274 75 503 minecraft:bone_block
fill 274 75 504 274 78 504 minecraft:brown_terracotta
setblock 275 75 466 minecraft:brown_terracotta
fill 275 75 500 275 76 500 minecraft:brown_terracotta
setblock 275 75 502 minecraft:bone_block
fill 275 75 503 275 78 503 minecraft:brown_terracotta
setblock 276 75 465 minecraft:brown_terracotta
setblock 276 75 466 minecraft:bone_block
fill 276 75 467 276 78 467 minecraft:brown_terracotta
fill 276 75 469 276 76 469 minecraft:brown_terracotta
setblock 276 75 480 minecraft:brown_terracotta
setblock 276 75 481 minecraft:bone_block
fill 276 75 482 276 78 482 minecraft:brown_terracotta
setblock 276 75 486 minecraft:bone_block
fill 276 75 487 276 77 488 minecraft:brown_terracotta
fill 276 75 497 276 78 497 minecraft:brown_terracotta
setblock 276 75 501 minecraft:bone_block
fill 276 75 502 276 78 502 minecraft:brown_terracotta
setblock 236 76 464 minecraft:brown_terracotta
setblock 236 76 465 minecraft:bone_block
fill 236 76 466 237 78 466 minecraft:brown_terracotta
fill 236 76 468 236 77 468 minecraft:brown_terracotta
fill 236 76 478 236 76 479 minecraft:brown_terracotta
setblock 236 76 480 minecraft:bone_block
fill 236 76 481 236 76 484 minecraft:brown_terracotta
setblock 236 76 485 minecraft:bone_block
fill 236 76 486 236 76 489 minecraft:brown_terracotta
setblock 236 76 490 minecraft:bone_block
fill 236 76 491 236 79 491 minecraft:brown_terracotta
setblock 236 76 495 minecraft:bone_block
fill 236 76 496 236 79 496 minecraft:brown_terracotta
setblock 236 76 500 minecraft:bone_block
fill 236 76 501 236 79 501 minecraft:brown_terracotta
setblock 237 76 464 minecraft:bone_block
fill 237 76 465 240 76 465 minecraft:brown_terracotta
fill 237 76 480 237 79 480 minecraft:brown_terracotta
setblock 237 76 483 minecraft:brown_terracotta
setblock 237 76 484 minecraft:bone_block
fill 237 76 485 237 79 485 minecraft:brown_terracotta
setblock 237 76 489 minecraft:bone_block
fill 237 76 490 238 78 490 minecraft:brown_terracotta
setblock 237 76 493 minecraft:brown_terracotta
setblock 237 76 494 minecraft:bone_block
fill 237 76 495 237 79 495 minecraft:brown_terracotta
setblock 237 76 499 minecraft:bone_block
fill 237 76 500 237 79 500 minecraft:brown_terracotta
setblock 237 76 504 minecraft:bone_block
fill 238 76 464 238 79 464 minecraft:brown_terracotta
setblock 238 76 482 minecraft:brown_terracotta
setblock 238 76 483 minecraft:bone_block
fill 238 76 484 239 78 484 minecraft:brown_terracotta
setblock 238 76 487 minecraft:brown_terracotta
setblock 238 76 488 minecraft:bone_block
fill 238 76 489 238 79 489 minecraft:brown_terracotta
fill 238 76 491 238 77 491 minecraft:brown_terracotta
fill 238 76 499 238 79 499 minecraft:brown_terracotta
setblock 238 76 503 minecraft:bone_block
fill 238 76 504 238 79 504 minecraft:brown_terracotta
fill 239 76 485 239 76 486 minecraft:brown_terracotta
setblock 239 76 487 minecraft:bone_block
setblock 239 76 502 minecraft:bone_block
fill 239 76 503 239 79 503 minecraft:brown_terracotta
fill 240 76 502 240 78 502 minecraft:brown_terracotta
setblock 241 76 465 minecraft:bone_block
setblock 242 76 464 minecraft:bone_block
fill 242 76 465 242 79 465 minecraft:brown_terracotta
setblock 242 76 504 minecraft:bone_block
fill 243 76 464 243 79 464 minecraft:brown_terracotta
setblock 243 76 503 minecraft:bone_block
fill 243 76 504 243 79 504 minecraft:brown_terracotta
fill 244 76 503 244 77 503 minecraft:brown_terracotta
setblock 247 76 504 minecraft:bone_block
setblock 252 76 464 minecraft:bone_block
fill 253 76 464 253 79 464 minecraft:brown_terracotta
fill 254 76 504 254 78 504 minecraft:brown_terracotta
setblock 255 76 465 minecraft:brown_terracotta
setblock 256 76 465 minecraft:bone_block
setblock 257 76 464 minecraft:bone_block
fill 257 76 465 257 78 466 minecraft:brown_terracotta
setblock 257 76 503 minecraft:brown_terracotta
setblock 257 76 504 minecraft:bone_block
fill 258 76 464 258 79 464 minecraft:brown_terracotta
fill 258 76 466 259 76 466 minecraft:brown_terracotta
setblock 258 76 503 minecraft:bone_block
fill 258 76 504 258 79 504 minecraft:brown_terracotta
fill 259 76 503 259 79 503 minecraft:brown_terracotta
setblock 260 76 466 minecraft:bone_block
setblock 261 76 465 minecraft:bone_block
fill 261 76 466 261 79 466 minecraft:brown_terracotta
setblock 262 76 464 minecraft:bone_block
fill 262 76 465 262 79 465 minecraft:brown_terracotta
setblock 262 76 504 minecraft:bone_block
fill 263 76 464 263 79 464 minecraft:brown_terracotta
setblock 263 76 503 minecraft:bone_block
fill 263 76 504 263 79 504 minecraft:brown_terracotta
fill 264 76 503 264 78 503 minecraft:brown_terracotta
setblock 265 76 466 minecraft:bone_block
setblock 266 76 465 minecraft:bone_block
setblock 267 76 464 minecraft:bone_block
fill 267 76 465 267 79 465 minecraft:brown_terracotta
setblock 267 76 504 minecraft:bone_block
fill 268 76 464 268 79 464 minecraft:brown_terracotta
fill 268 76 504 268 79 504 minecraft:brown_terracotta
setblock 270 76 465 minecraft:brown_terracotta
setblock 271 76 465 minecraft:bone_block
setblock 272 76 464 minecraft:bone_block
fill 272 76 465 272 79 465 minecraft:brown_terracotta
setblock 272 76 503 minecraft:brown_terracotta
setblock 272 76 504 minecraft:bone_block
fill 273 76 464 273 79 464 minecraft:brown_terracotta
setblock 273 76 503 minecraft:bone_block
fill 273 76 504 273 79 504 minecraft:brown_terracotta
fill 274 76 503 274 79 503 minecraft:brown_terracotta
setblock 275 76 466 minecraft:bone_block
fill 275 76 467 275 79 467 minecraft:brown_terracotta
setblock 275 76 501 minecraft:bone_block
fill 275 76 502 275 79 502 minecraft:brown_terracotta
setblock 276 76 465 minecraft:bone_block
fill 276 76 466 276 79 466 minecraft:brown_terracotta
setblock 276 76 470 minecraft:bone_block
setblock 276 76 479 minecraft:brown_terracotta
setblock 276 76 480 minecraft:bone_block
fill 276 76 481 276 79 481 minecraft:brown_terracotta
fill 276 76 483 276 76 484 minecraft:brown_terracotta
setblock 276 76 485 minecraft:bone_block
fill 276 76 486 276 79 486 minecraft:brown_terracotta
setblock 276 76 489 minecraft:brown_terracotta
setblock 276 76 490 minecraft:bone_block
fill 276 76 491 276 78 492 minecraft:brown_terracotta
setblock 276 76 494 minecraft:brown_terracotta
setblock 276 76 495 minecraft:bone_block
fill 276 76 496 276 79 496 minecraft:brown_terracotta
setblock 276 76 500 minecraft:bone_block
fill 276 76 501 276 79 501 minecraft:brown_terracotta
setblock 236 77 464 minecraft:bone_block
fill 236 77 465 239 77 465 minecraft:brown_terracotta
setblock 236 77 469 minecraft:bone_block
fill 236 77 470 236 80 470 minecraft:brown_terracotta
setblock 236 77 478 minecraft:brown_terracotta
setblock 236 77 479 minecraft:bone_block
fill 236 77 480 236 77 483 minecraft:brown_terracotta
setblock 236 77 484 minecraft:bone_block
fill 236 77 485 236 77 488 minecraft:brown_terracotta
setblock 236 77 489 minecraft:bone_block
fill 236 77 490 236 80 490 minecraft:brown_terracotta
setblock 236 77 493 minecraft:brown_terracotta
setblock 236 77 494 minecraft:bone_block
fill 236 77 495 236 80 495 minecraft:brown_terracotta
setblock 236 77 499 minecraft:bone_block
fill 236 77 500 236 80 500 minecraft:brown_terracotta
setblock 236 77 504 minecraft:bone_block
fill 237 77 464 237 80 464 minecraft:brown_terracotta
setblock 237 77 467 minecraft:brown_terracotta
fill 237 77 479 237 80 479 minecraft:brown_terracotta
setblock 237 77 483 minecraft:bone_block
fill 237 77 484 237 80 484 minecraft:brown_terracotta
setblock 237 77 487 minecraft:brown_terracotta
setblock 237 77 488 minecraft:bone_block
fill 237 77 489 237 80 489 minecraft:brown_terracotta
setblock 237 77 493 minecraft:bone_block
fill 237 77 494 237 80 494 minecraft:brown_terracotta
setblock 237 77 498 minecraft:bone_block
fill 237 77 499 237 80 499 minecraft:brown_terracotta
setblock 237 77 503 minecraft:bone_block
fill 237 77 504 237 80 504 minecraft:brown_terracotta
setblock 238 77 481 minecraft:brown_terracotta
setblock 238 77 482 minecraft:bone_block
fill 238 77 483 239 79 483 minecraft:brown_terracotta
setblock 238 77 487 minecraft:bone_block
fill 238 77 488 239 79 488 minecraft:brown_terracotta
setblock 238 77 492 minecraft:bone_block
fill 238 77 493 238 80 493 minecraft:brown_terracotta
fill 238 77 498 238 79 498 minecraft:brown_terracotta
setblock 238 77 502 minecraft:bone_block
fill 238 77 503 238 80 503 minecraft:brown_terracotta
setblock 239 77 485 minecraft:brown_terracotta
setblock 239 77 486 minecraft:bone_block
fill 239 77 487 239 80 487 minecraft:brown_terracotta
fill 239 77 489 239 78 489 minecraft:brown_terracotta
fill 239 77 502 239 79 502 minecraft:brown_terracotta
setblock 240 77 465 minecraft:bone_block
setblock 241 77 464 minecraft:bone_block
fill 241 77 465 241 80 465 minecraft:brown_terracotta
setblock 241 77 504 minecraft:bone_block
fill 242 77 464 242 80 464 minecraft:brown_terracotta
setblock 242 77 503 minecraft:bone_block
fill 242 77 504 242 80 504 minecraft:brown_terracotta
fill 243 77 503 243 78 503 minecraft:brown_terracotta
setblock 246 77 464 minecraft:bone_block
setblock 246 77 504 minecraft:bone_block
setblock 250 77 464 minecraft:brown_terracotta
setblock 251 77 464 minecraft:bone_block
fill 252 77 464 252 80 464 minecraft:brown_terracotta
fill 253 77 465 254 77 465 minecraft:brown_terracotta
fill 253 77 504 253 79 504 minecraft:brown_terracotta
setblock 255 77 465 minecraft:bone_block
setblock 256 77 464 minecraft:bone_block
fill 256 77 465 256 79 466 minecraft:brown_terracotta
setblock 256 77 503 minecraft:brown_terracotta
setblock 256 77 504 minecraft:bone_block
fill 257 77 464 257 80 464 minecraft:brown_terracotta
setblock 257 77 503 minecraft:bone_block
fill 257 77 504 257 80 504 minecraft:brown_terracotta
setblock 258 77 466 minecraft:brown_terracotta
fill 258 77 503 258 80 503 minecraft:brown_terracotta
setblock 259 77 466 minecraft:bone_block
fill 259 77 467 261 78 467 minecraft:brown_terracotta
setblock 260 77 465 minecraft:bone_block
fill 260 77 466 260 80 466 minecraft:brown_terracotta
setblock 261 77 464 minecraft:bone_block
fill 261 77 465 261 80 465 minecraft:brown_terracotta
setblock 261 77 504 minecraft:bone_block
fill 262 77 464 262 80 464 minecraft:brown_terracotta
fill 262 77 466 263 77 466 minecraft:brown_terracotta
setblock 262 77 503 minecraft:bone_block
fill 262 77 504 262 80 504 minecraft:brown_terracotta
fill 263 77 503 263 79 503 minecraft:brown_terracotta
setblock 264 77 466 minecraft:bone_block
setblock 265 77 465 minecraft:bone_block
fill 265 77 466 266 79 466 minecraft:brown_terracotta
setblock 266 77 464 minecraft:bone_block
fill 266 77 465 266 80 465 minecraft:brown_terracotta
setblock 266 77 504 minecraft:bone_block
fill 267 77 464 267 80 464 minecraft:brown_terracotta
fill 267 77 504 267 80 504 minecraft:brown_terracotta
setblock 270 77 465 minecraft:bone_block
setblock 271 77 464 minecraft:bone_block
fill 271 77 465 271 80 465 minecraft:brown_terracotta
setblock 271 77 503 minecraft:brown_terracotta
setblock 271 77 504 minecraft:bone_block
fill 272 77 464 272 80 464 minecraft:brown_terracotta
fill 272 77 502 272 77 503 minecraft:bone_block
fill 272 77 504 272 80 504 minecraft:brown_terracotta
fill 273 77 501 273 80 501 minecraft:bone_block
fill 273 77 503 273 80 503 minecraft:brown_terracotta
setblock 274 77 466 minecraft:bone_block
setblock 274 77 502 minecraft:bone_block
setblock 275 77 464 minecraft:brown_terracotta
setblock 275 77 465 minecraft:bone_block
fill 275 77 466 275 80 466 minecraft:brown_terracotta
fill 275 77 468 275 78 468 minecraft:brown_terracotta
setblock 275 77 484 minecraft:brown_terracotta
setblock 275 77 485 minecraft:bone_block
fill 275 77 486 275 79 487 minecraft:brown_terracotta
setblock 275 77 499 minecraft:brown_terracotta
setblock 275 77 500 minecraft:bone_block
fill 275 77 501 275 80 501 minecraft:brown_terracotta
setblock 276 77 464 minecraft:bone_block
fill 276 77 465 276 80 465 minecraft:brown_terracotta
setblock 276 77 469 minecraft:bone_block
fill 276 77 470 276 79 471 minecraft:brown_terracotta
setblock 276 77 479 minecraft:bone_block
fill 276 77 480 276 80 480 minecraft:brown_terracotta
setblock 276 77 483 minecraft:brown_terracotta
setblock 276 77 484 minecraft:bone_block
fill 276 77 485 276 80 485 minecraft:brown_terracotta
setblock 276 77 489 minecraft:bone_block
fill 276 77 490 276 80 490 minecraft:brown_terracotta
setblock 276 77 493 minecraft:brown_terracotta
setblock 276 77 494 minecraft:bone_block
fill 276 77 495 276 80 495 minecraft:brown_terracotta
setblock 276 77 499 minecraft:bone_block
fill 276 77 500 276 80 500 minecraft:brown_terracotta
setblock 276 77 504 minecraft:bone_block
fill 236 78 464 236 80 465 minecraft:brown_terracotta
setblock 236 78 468 minecraft:bone_block
fill 236 78 469 237 80 469 minecraft:brown_terracotta
fill 236 78 471 236 79 471 minecraft:brown_terracotta
setblock 236 78 477 minecraft:brown_terracotta
setblock 236 78 478 minecraft:bone_block
fill 236 78 479 236 78 482 minecraft:brown_terracotta
setblock 236 78 483 minecraft:bone_block
fill 236 78 484 236 78 487 minecraft:brown_terracotta
setblock 236 78 488 minecraft:bone_block
fill 236 78 489 236 81 489 minecraft:brown_terracotta
setblock 236 78 492 minecraft:brown_terracotta
setblock 236 78 493 minecraft:bone_block
fill 236 78 494 236 81 494 minecraft:brown_terracotta
setblock 236 78 498 minecraft:bone_block
fill 236 78 499 236 81 499 minecraft:brown_terracotta
setblock 236 78 503 minecraft:bone_block
fill 236 78 504 236 81 504 minecraft:brown_terracotta
fill 237 78 465 238 78 465 minecraft:brown_terracotta
setblock 237 78 467 minecraft:bone_block
fill 237 78 468 237 81 468 minecraft:brown_terracotta
setblock 237 78 482 minecraft:bone_block
fill 237 78 483 237 81 483 minecraft:brown_terracotta
setblock 237 78 486 minecraft:brown_terracotta
setblock 237 78 487 minecraft:bone_block
fill 237 78 488 237 81 488 minecraft:brown_terracotta
setblock 237 78 492 minecraft:bone_block
fill 237 78 493 237 81 493 minecraft:brown_terracotta
setblock 237 78 497 minecraft:bone_block
fill 237 78 498 237 81 498 minecraft:brown_terracotta
setblock 237 78 502 minecraft:bone_block
fill 237 78 503 237 81 503 minecraft:brown_terracotta
setblock 238 78 466 minecraft:bone_block
setblock 238 78 481 minecraft:bone_block
fill 238 78 482 238 81 482 minecraft:brown_terracotta
setblock 238 78 486 minecraft:bone_block
fill 238 78 487 238 81 487 minecraft:brown_terracotta
setblock 238 78 491 minecraft:bone_block
fill 238 78 492 238 81 492 minecraft:brown_terracotta
fill 238 78 494 238 78 495 minecraft:brown_terracotta
setblock 238 78 496 minecraft:bone_block
fill 238 78 497 238 80 497 minecraft:brown_terracotta
setblock 238 78 501 minecraft:bone_block
fill 238 78 502 238 80 502 minecraft:brown_terracotta
setblock 239 78 465 minecraft:bone_block
setblock 239 78 485 minecraft:bone_block
fill 239 78 486 239 81 486 minecraft:brown_terracotta
setblock 239 78 490 minecraft:bone_block
fill 239 78 491 239 81 491 minecraft:brown_terracotta
setblock 240 78 464 minecraft:bone_block
fill 240 78 465 240 81 465 minecraft:brown_terracotta
setblock 240 78 504 minecraft:bone_block
fill 241 78 464 241 81 464 minecraft:brown_terracotta
setblock 241 78 503 minecraft:bone_block
fill 241 78 504 241 81 504 minecraft:brown_terracotta
fill 242 78 503 242 79 503 minecraft:brown_terracotta
setblock 243 78 465 minecraft:brown_terracotta
setblock 244 78 464 minecraft:brown_terracotta
setblock 245 78 464 minecraft:bone_block
setblock 245 78 504 minecraft:bone_block
fill 246 78 464 249 78 464 minecraft:brown_terracotta
setblock 246 78 504 minecraft:brown_terracotta
setblock 250 78 464 minecraft:bone_block
fill 251 78 464 251 81 464 minecraft:brown_terracotta
fill 252 78 465 253 78 465 minecraft:brown_terracotta
fill 252 78 504 252 80 504 minecraft:brown_terracotta
setblock 254 78 465 minecraft:bone_block
fill 254 78 466 255 80 466 minecraft:brown_terracotta
setblock 255 78 464 minecraft:bone_block
fill 255 78 465 255 81 465 minecraft:brown_terracotta
setblock 255 78 504 minecraft:bone_block
fill 256 78 464 256 81 464 minecraft:brown_terracotta
setblock 256 78 503 minecraft:bone_block
fill 256 78 504 256 81 504 minecraft:brown_terracotta
setblock 257 78 467 minecraft:bone_block
fill 257 78 503 257 81 503 minecraft:brown_terracotta
setblock 258 78 466 minecraft:bone_block
fill 258 78 467 258 81 467 minecraft:brown_terracotta
setblock 259 78 465 minecraft:bone_block
fill 259 78 466 259 81 466 minecraft:brown_terracotta
setblock 260 78 464 minecraft:bone_block
fill 260 78 465 260 81 465 minecraft:brown_terracotta
setblock 260 78 504 minecraft:bone_block
fill 261 78 464 261 81 464 minecraft:brown_terracotta
setblock 261 78 503 minecraft:bone_block
fill 261 78 504 261 81 504 minecraft:brown_terracotta
setblock 262 78 466 minecraft:brown_terracotta
setblock 262 78 467 minecraft:bone_block
fill 262 78 503 262 80 503 minecraft:brown_terracotta
setblock 263 78 466 minecraft:bone_block
setblock 264 78 465 minecraft:bone_block
fill 264 78 466 264 81 466 minecraft:brown_terracotta
setblock 265 78 464 minecraft:bone_block
fill 265 78 465 265 81 465 minecraft:brown_terracotta
setblock 265 78 504 minecraft:bone_block
fill 266 78 464 266 81 464 minecraft:brown_terracotta
fill 266 78 504 266 81 504 minecraft:brown_terracotta
setblock 267 78 466 minecraft:brown_terracotta
setblock 268 78 465 minecraft:brown_terracotta
setblock 269 78 465 minecraft:bone_block
setblock 270 78 464 minecraft:bone_block
fill 270 78 465 270 81 465 minecraft:brown_terracotta
setblock 270 78 503 minecraft:brown_terracotta
setblock 270 78 504 minecraft:bone_block
fill 271 78 464 271 81 464 minecraft:brown_terracotta
setblock 271 78 503 minecraft:bone_block
fill 271 78 504 271 81 504 minecraft:brown_terracotta
setblock 272 78 466 minecraft:brown_terracotta
fill 272 78 502 272 80 502 minecraft:bone_block
fill 272 78 503 272 81 503 minecraft:brown_terracotta
setblock 273 78 465 minecraft:brown_terracotta
setblock 273 78 466 minecraft:bone_block
setblock 274 78 465 minecraft:bone_block
fill 274 78 466 274 80 467 minecraft:brown_terracotta
fill 274 78 502 274 80 502 minecraft:brown_terracotta
setblock 275 78 464 minecraft:bone_block
fill 275 78 465 275 81 465 minecraft:brown_terracotta
setblock 275 78 469 minecraft:bone_block
fill 275 78 470 275 81 470 minecraft:brown_terracotta
setblock 275 78 483 minecraft:brown_terracotta
setblock 275 78 484 minecraft:bone_block
fill 275 78 485 275 81 485 minecraft:brown_terracotta
setblock 275 78 488 minecraft:brown_terracotta
setblock 275 78 489 minecraft:bone_block
fill 275 78 490 275 80 491 minecraft:brown_terracotta
setblock 275 78 498 minecraft:brown_terracotta
setblock 275 78 499 minecraft:bone_block
fill 275 78 500 275 81 500 minecraft:brown_terracotta
setblock 275 78 504 minecraft:bone_block
fill 276 78 464 276 81 464 minecraft:brown_terracotta
setblock 276 78 468 minecraft:bone_block
fill 276 78 469 276 81 469 minecraft:brown_terracotta
setblock 276 78 472 minecraft:brown_terracotta
setblock 276 78 473 minecraft:bone_block
setblock 276 78 478 minecraft:bone_block
fill 276 78 479 276 81 479 minecraft:brown_terracotta
setblock 276 78 483 minecraft:bone_block
fill 276 78 484 276 81 484 minecraft:brown_terracotta
setblock 276 78 487 minecraft:brown_terracotta
setblock 276 78 488 minecraft:bone_block
fill 276 78 489 276 81 489 minecraft:brown_terracotta
setblock 276 78 493 minecraft:bone_block
fill 276 78 494 276 81 494 minecraft:brown_terracotta
setblock 276 78 498 minecraft:bone_block
fill 276 78 499 276 81 499 minecraft:brown_terracotta
setblock 276 78 503 minecraft:bone_block
fill 276 78 504 276 81 504 minecraft:brown_terracotta
setblock 236 79 466 minecraft:brown_terracotta
setblock 236 79 467 minecraft:bone_block
fill 236 79 468 236 82 468 minecraft:brown_terracotta
setblock 236 79 472 minecraft:bone_block
fill 236 79 473 236 79 476 minecraft:brown_terracotta
setblock 236 79 477 minecraft:bone_block
fill 236 79 478 236 79 481 minecraft:brown_terracotta
setblock 236 79 482 minecraft:bone_block
fill 236 79 483 236 79 486 minecraft:brown_terracotta
setblock 236 79 487 minecraft:bone_block
fill 236 79 488 236 82 488 minecraft:brown_terracotta
setblock 236 79 492 minecraft:bone_block
fill 236 79 493 236 82 493 minecraft:brown_terracotta
setblock 236 79 497 minecraft:bone_block
fill 236 79 498 236 82 498 minecraft:brown_terracotta
setblock 236 79 502 minecraft:bone_block
fill 236 79 503 236 82 503 minecraft:brown_terracotta
setblock 237 79 465 minecraft:brown_terracotta
setblock 237 79 466 minecraft:bone_block
fill 237 79 467 237 82 467 minecraft:brown_terracotta
setblock 237 79 470 minecraft:brown_terracotta
setblock 237 79 481 minecraft:bone_block
fill 237 79 482 237 82 482 minecraft:brown_terracotta
setblock 237 79 486 minecraft:bone_block
fill 237 79 487 237 82 487 minecraft:brown_terracotta
setblock 237 79 490 minecraft:brown_terracotta
setblock 237 79 491 minecraft:bone_block
fill 237 79 492 237 82 492 minecraft:brown_terracotta
setblock 237 79 496 minecraft:bone_block
fill 237 79 497 237 82 497 minecraft:brown_terracotta
setblock 237 79 501 minecraft:bone_block
fill 237 79 502 237 82 502 minecraft:brown_terracotta
setblock 238 79 465 minecraft:bone_block
fill 238 79 466 239 80 466 minecraft:brown_terracotta
fill 238 79 481 238 80 481 minecraft:brown_terracotta
setblock 238 79 484 minecraft:brown_terracotta
setblock 238 79 485 minecraft:bone_block
fill 238 79 486 238 82 486 minecraft:brown_terracotta
setblock 238 79 490 minecraft:bone_block
fill 238 79 491 238 82 491 minecraft:brown_terracotta
setblock 238 79 494 minecraft:brown_terracotta
setblock 238 79 495 minecraft:bone_block
fill 238 79 496 238 82 496 minecraft:brown_terracotta
setblock 238 79 500 minecraft:bone_block
fill 238 79 501 238 80 501 minecraft:brown_terracotta
setblock 239 79 464 minecraft:bone_block
fill 239 79 465 239 82 465 minecraft:brown_terracotta
setblock 239 79 484 minecraft:bone_block
fill 239 79 485 239 82 485 minecraft:brown_terracotta
setblock 239 79 489 minecraft:bone_block
fill 239 79 490 239 82 490 minecraft:brown_terracotta
fill 239 79 492 239 80 492 minecraft:brown_terracotta
setblock 239 79 504 minecraft:bone_block
fill 240 79 464 240 82 464 minecraft:brown_terracotta
setblock 240 79 503 minecraft:bone_block
fill 240 79 504 240 82 504 minecraft:brown_terracotta
fill 241 79 503 241 80 503 minecraft:brown_terracotta
setblock 243 79 465 minecraft:bone_block
setblock 244 79 464 minecraft:bone_block
setblock 244 79 504 minecraft:bone_block
fill 245 79 464 248 79 464 minecraft:brown_terracotta
setblock 245 79 504 minecraft:brown_terracotta
setblock 249 79 464 minecraft:bone_block
fill 250 79 464 250 82 464 minecraft:brown_terracotta
fill 251 79 465 252 79 465 minecraft:brown_terracotta
setblock 253 79 465 minecraft:bone_block
fill 253 79 466 253 82 466 minecraft:brown_terracotta
setblock 254 79 464 minecraft:bone_block
fill 254 79 465 254 82 465 minecraft:brown_terracotta
setblock 254 79 504 minecraft:bone_block
fill 255 79 464 255 82 464 minecraft:brown_terracotta
setblock 255 79 467 minecraft:brown_terracotta
fill 255 79 504 255 82 504 minecraft:brown_terracotta
setblock 256 79 467 minecraft:bone_block
fill 256 79 503 256 80 503 minecraft:brown_terracotta
setblock 257 79 465 minecraft:brown_terracotta
setblock 257 79 466 minecraft:bone_block
fill 257 79 467 257 82 467 minecraft:brown_terracotta
setblock 258 79 465 minecraft:bone_block
fill 258 79 466 258 82 466 minecraft:brown_terracotta
setblock 259 79 464 minecraft:bone_block
fill 259 79 465 259 82 465 minecraft:brown_terracotta
fill 259 79 467 260 79 467 minecraft:brown_terracotta
setblock 259 79 504 minecraft:bone_block
fill 260 79 464 260 82 464 minecraft:brown_terracotta
setblock 260 79 503 minecraft:bone_block
fill 260 79 504 260 82 504 minecraft:brown_terracotta
setblock 261 79 467 minecraft:bone_block
fill 261 79 503 261 80 503 minecraft:brown_terracotta
setblock 262 79 466 minecraft:bone_block
fill 262 79 467 263 80 467 minecraft:brown_terracotta
setblock 263 79 465 minecraft:bone_block
fill 263 79 466 263 82 466 minecraft:brown_terracotta
setblock 264 79 464 minecraft:bone_block
fill 264 79 465 264 82 465 minecraft:brown_terracotta
setblock 264 79 504 minecraft:bone_block
fill 265 79 464 265 82 464 minecraft:brown_terracotta
fill 265 79 504 265 82 504 minecraft:brown_terracotta
setblock 267 79 466 minecraft:bone_block
setblock 268 79 465 minecraft:bone_block
fill 268 79 466 271 79 466 minecraft:brown_terracotta
setblock 269 79 464 minecraft:bone_block
fill 269 79 465 269 82 465 minecraft:brown_terracotta
setblock 269 79 504 minecraft:bone_block
fill 270 79 464 270 82 464 minecraft:brown_terracotta
setblock 270 79 503 minecraft:bone_block
fill 270 79 504 270 82 504 minecraft:brown_terracotta
fill 271 79 503 271 82 503 minecraft:brown_terracotta
setblock 272 79 466 minecraft:bone_block
setblock 273 79 465 minecraft:bone_block
fill 273 79 466 273 82 466 minecraft:brown_terracotta
setblock 274 79 464 minecraft:bone_block
fill 274 79 465 274 82 465 minecraft:brown_terracotta
setblock 274 79 468 minecraft:brown_terracotta
setblock 274 79 504 minecraft:bone_block
fill 275 79 464 275 82 464 minecraft:brown_terracotta
setblock 275 79 468 minecraft:bone_block
fill 275 79 469 275 82 469 minecraft:brown_terracotta
fill 275 79 471 275 80 471 minecraft:brown_terracotta
setblock 275 79 482 minecraft:brown_terracotta
setblock 275 79 483 minecraft:bone_block
fill 275 79 484 275 82 484 minecraft:brown_terracotta
setblock 275 79 488 minecraft:bone_block
fill 275 79 489 275 82 489 minecraft:brown_terracotta
setblock 275 79 492 minecraft:brown_terracotta
setblock 275 79 493 minecraft:bone_block
fill 275 79 494 275 79 497 minecraft:brown_terracotta
setblock 275 79 498 minecraft:bone_block
fill 275 79 499 275 82 499 minecraft:brown_terracotta
setblock 275 79 503 minecraft:bone_block
fill 275 79 504 275 82 504 minecraft:brown_terracotta
setblock 276 79 467 minecraft:bone_block
fill 276 79 468 276 82 468 minecraft:brown_terracotta
setblock 276 79 472 minecraft:bone_block
fill 276 79 473 276 81 474 minecraft:brown_terracotta
fill 276 79 478 276 80 478 minecraft:brown_terracotta
setblock 276 79 482 minecraft:bone_block
fill 276 79 483 276 82 483 minecraft:brown_terracotta
setblock 276 79 487 minecraft:bone_block
fill 276 79 488 276 82 488 minecraft:brown_terracotta
setblock 276 79 491 minecraft:brown_terracotta
setblock 276 79 492 minecraft:bone_block
fill 276 79 493 276 82 493 minecraft:brown_terracotta
setblock 276 79 497 minecraft:bone_block
fill 276 79 498 276 82 498 minecraft:brown_terracotta
setblock 276 79 502 minecraft:bone_block
fill 276 79 503 276 82 503 minecraft:brown_terracotta
setblock 236 80 466 minecraft:bone_block
fill 236 80 467 236 83 467 minecraft:brown_terracotta
setblock 236 80 471 minecraft:bone_block
fill 236 80 472 236 80 475 minecraft:brown_terracotta
setblock 236 80 476 minecraft:bone_block
fill 236 80 477 236 80 480 minecraft:brown_terracotta
setblock 236 80 481 minecraft:bone_block
fill 236 80 482 236 80 485 minecraft:brown_terracotta
setblock 236 80 486 minecraft:bone_block
fill 236 80 487 236 83 487 minecraft:brown_terracotta
setblock 236 80 491 minecraft:bone_block
fill 236 80 492 236 83 492 minecraft:brown_terracotta
setblock 236 80 496 minecraft:bone_block
fill 236 80 497 236 83 497 minecraft:brown_terracotta
setblock 236 80 501 minecraft:bone_block
fill 236 80 502 236 83 502 minecraft:brown_terracotta
setblock 237 80 465 minecraft:bone_block
fill 237 80 466 237 83 466 minecraft:brown_terracotta
setblock 237 80 470 minecraft:bone_block
fill 237 80 471 237 83 471 minecraft:brown_terracotta
setblock 237 80 480 minecraft:bone_block
fill 237 80 481 237 83 481 minecraft:brown_terracotta
setblock 237 80 485 minecraft:bone_block
fill 237 80 486 237 83 486 minecraft:brown_terracotta
setblock 237 80 490 minecraft:bone_block
fill 237 80 491 237 83 491 minecraft:brown_terracotta
setblock 237 80 495 minecraft:bone_block
fill 237 80 496 237 83 496 minecraft:brown_terracotta
setblock 237 80 500 minecraft:bone_block
fill 237 80 501 237 82 501 minecraft:brown_terracotta
setblock 238 80 464 minecraft:bone_block
fill 238 80 465 238 83 465 minecraft:brown_terracotta
fill 238 80 467 238 81 467 minecraft:brown_terracotta
setblock 238 80 483 minecraft:brown_terracotta
setblock 238 80 484 minecraft:bone_block
fill 238 80 485 238 83 485 minecraft:brown_terracotta
setblock 238 80 488 minecraft:brown_terracotta
setblock 238 80 489 minecraft:bone_block
fill 238 80 490 238 83 490 minecraft:brown_terracotta
setblock 238 80 494 minecraft:bone_block
fill 238 80 495 238 83 495 minecraft:brown_terracotta
setblock 238 80 504 minecraft:bone_block
fill 239 80 464 239 83 464 minecraft:brown_terracotta
setblock 239 80 483 minecraft:bone_block
fill 239 80 484 239 81 484 minecraft:brown_terracotta
setblock 239 80 488 minecraft:bone_block
fill 239 80 489 239 83 489 minecraft:brown_terracotta
setblock 239 80 503 minecraft:bone_block
fill 239 80 504 239 83 504 minecraft:brown_terracotta
fill 240 80 503 240 81 503 minecraft:brown_terracotta
setblock 242 80 465 minecraft:bone_block
setblock 243 80 464 minecraft:bone_block
setblock 243 80 504 minecraft:bone_block
fill 244 80 464 247 80 464 minecraft:brown_terracotta
setblock 244 80 504 minecraft:brown_terracotta
setblock 248 80 464 minecraft:bone_block
fill 249 80 464 249 83 464 minecraft:brown_terracotta
fill 250 80 465 251 80 465 minecraft:brown_terracotta
setblock 252 80 465 minecraft:bone_block
fill 252 80 466 252 83 466 minecraft:brown_terracotta
setblock 253 80 464 minecraft:bone_block
fill 253 80 465 253 83 465 minecraft:brown_terracotta
setblock 253 80 504 minecraft:bone_block
fill 254 80 464 254 83 464 minecraft:brown_terracotta
setblock 254 80 467 minecraft:brown_terracotta
fill 254 80 504 254 83 504 minecraft:brown_terracotta
setblock 255 80 467 minecraft:bone_block
setblock 256 80 465 minecraft:brown_terracotta
setblock 256 80 466 minecraft:bone_block
fill 256 80 467 256 83 467 minecraft:brown_terracotta
setblock 257 80 465 minecraft:bone_block
fill 257 80 466 257 83 466 minecraft:brown_terracotta
setblock 258 80 464 minecraft:bone_block
fill 258 80 465 258 83 465 minecraft:brown_terracotta
setblock 258 80 504 minecraft:bone_block
fill 259 80 464 259 83 464 minecraft:brown_terracotta
setblock 259 80 467 minecraft:brown_terracotta
setblock 259 80 503 minecraft:bone_block
fill 259 80 504 259 83 504 minecraft:brown_terracotta
setblock 260 80 467 minecraft:bone_block
setblock 260 80 503 minecraft:brown_terracotta
setblock 261 80 466 minecraft:bone_block
fill 261 80 467 261 82 467 minecraft:brown_terracotta
setblock 262 80 465 minecraft:bone_block
fill 262 80 466 262 83 466 minecraft:brown_terracotta
setblock 263 80 464 minecraft:bone_block
fill 263 80 465 263 83 465 minecraft:brown_terracotta
setblock 263 80 504 minecraft:bone_block
fill 264 80 464 264 83 464 minecraft:brown_terracotta
fill 264 80 504 264 82 504 minecraft:brown_terracotta
setblock 265 80 466 minecraft:brown_terracotta
setblock 266 80 466 minecraft:bone_block
setblock 267 80 465 minecraft:bone_block
fill 267 80 466 270 80 466 minecraft:brown_terracotta
setblock 268 80 464 minecraft:bone_block
fill 268 80 465 268 83 465 minecraft:brown_terracotta
setblock 268 80 504 minecraft:bone_block
fill 269 80 464 269 83 464 minecraft:brown_terracotta
fill 269 80 504 269 83 504 minecraft:brown_terracotta
setblock 270 80 503 minecraft:brown_terracotta
setblock 271 80 466 minecraft:bone_block
setblock 272 80 465 minecraft:bone_block
fill 272 80 466 272 83 466 minecraft:brown_terracotta
setblock 272 80 501 minecraft:bone_block
setblock 273 80 464 minecraft:bone_block
fill 273 80 465 273 83 465 minecraft:brown_terracotta
setblock 273 80 504 minecraft:bone_block
fill 274 80 464 274 83 464 minecraft:brown_terracotta
setblock 274 80 468 minecraft:bone_block
fill 274 80 469 274 83 469 minecraft:brown_terracotta
setblock 274 80 488 minecraft:bone_block
fill 274 80 489 274 83 489 minecraft:brown_terracotta
setblock 274 80 501 minecraft:bone_block
setblock 274 80 503 minecraft:bone_block
fill 274 80 504 274 83 504 minecraft:brown_terracotta
setblock 275 80 467 minecraft:bone_block
fill 275 80 468 275 83 468 minecraft:brown_terracotta
fill 275 80 483 275 81 483 minecraft:brown_terracotta
setblock 275 80 486 minecraft:brown_terracotta
setblock 275 80 487 minecraft:bone_block
fill 275 80 488 275 83 488 minecraft:brown_terracotta
setblock 275 80 492 minecraft:bone_block
fill 275 80 493 275 80 496 minecraft:brown_terracotta
setblock 275 80 497 minecraft:bone_block
fill 275 80 498 275 83 498 minecraft:brown_terracotta
setblock 275 80 502 minecraft:bone_block
fill 275 80 503 275 83 503 minecraft:brown_terracotta
setblock 276 80 466 minecraft:bone_block
fill 276 80 467 276 83 467 minecraft:brown_terracotta
setblock 276 80 470 minecraft:brown_terracotta
setblock 276 80 471 minecraft:bone_block
fill 276 80 472 276 83 472 minecraft:brown_terracotta
setblock 276 80 475 minecraft:brown_terracotta
setblock 276 80 481 minecraft:bone_block
fill 276 80 482 276 83 482 minecraft:brown_terracotta
setblock 276 80 486 minecraft:bone_block
fill 276 80 487 276 83 487 minecraft:brown_terracotta
setblock 276 80 491 minecraft:bone_block
fill 276 80 492 276 83 492 minecraft:brown_terracotta
setblock 276 80 496 minecraft:bone_block
fill 276 80 497 276 83 497 minecraft:brown_terracotta
setblock 276 80 501 minecraft:bone_block
fill 276 80 502 276 83 502 minecraft:brown_terracotta
setblock 236 81 464 minecraft:brown_terracotta
setblock 236 81 465 minecraft:bone_block
fill 236 81 466 236 84 466 minecraft:brown_terracotta
setblock 236 81 469 minecraft:brown_terracotta
setblock 236 81 470 minecraft:bone_block
fill 236 81 471 236 81 474 minecraft:brown_terracotta
setblock 236 81 475 minecraft:bone_block
fill 236 81 476 236 81 479 minecraft:brown_terracotta
setblock 236 81 480 minecraft:bone_block
fill 236 81 481 236 81 484 minecraft:brown_terracotta
setblock 236 81 485 minecraft:bone_block
fill 236 81 486 236 84 486 minecraft:brown_terracotta
setblock 236 81 490 minecraft:bone_block
fill 236 81 491 236 84 491 minecraft:brown_terracotta
setblock 236 81 495 minecraft:bone_block
fill 236 81 496 236 84 496 minecraft:brown_terracotta
setblock 236 81 500 minecraft:bone_block
fill 236 81 501 236 84 501 minecraft:brown_terracotta
setblock 237 81 464 minecraft:bone_block
fill 237 81 465 237 83 465 minecraft:brown_terracotta
setblock 237 81 469 minecraft:bone_block
fill 237 81 470 237 84 470 minecraft:brown_terracotta
setblock 237 81 479 minecraft:bone_block
fill 237 81 480 237 82 480 minecraft:brown_terracotta
setblock 237 81 484 minecraft:bone_block
fill 237 81 485 237 84 485 minecraft:brown_terracotta
setblock 237 81 489 minecraft:bone_block
fill 237 81 490 237 84 490 minecraft:brown_terracotta
setblock 237 81 494 minecraft:bone_block
fill 237 81 495 237 84 495 minecraft:brown_terracotta
setblock 237 81 499 minecraft:bone_block
fill 237 81 500 237 83 500 minecraft:brown_terracotta
setblock 237 81 504 minecraft:bone_block
fill 238 81 464 238 84 464 minecraft:brown_terracotta
setblock 238 81 466 minecraft:brown_terracotta
setblock 238 81 483 minecraft:bone_block
fill 238 81 484 238 83 484 minecraft:brown_terracotta
setblock 238 81 488 minecraft:bone_block
fill 238 81 489 238 84 489 minecraft:brown_terracotta
setblock 238 81 493 minecraft:bone_block
fill 238 81 494 238 84 494 minecraft:brown_terracotta
setblock 238 81 503 minecraft:bone_block
fill 238 81 504 238 84 504 minecraft:brown_terracotta
setblock 239 81 487 minecraft:bone_block
fill 239 81 488 239 83 488 minecraft:brown_terracotta
setblock 239 81 492 minecraft:bone_block
setblock 239 81 503 minecraft:brown_terracotta
setblock 241 81 465 minecraft:bone_block
setblock 242 81 464 minecraft:bone_block
setblock 242 81 504 minecraft:bone_block
fill 243 81 464 245 81 464 minecraft:brown_terracotta
setblock 247 81 464 minecraft:bone_block
fill 248 81 464 248 82 464 minecraft:brown_terracotta
setblock 250 81 465 minecraft:brown_terracotta
setblock 251 81 465 minecraft:bone_block
setblock 252 81 464 minecraft:bone_block
fill 252 81 465 252 84 465 minecraft:brown_terracotta
setblock 252 81 504 minecraft:bone_block
fill 253 81 464 253 84 464 minecraft:brown_terracotta
fill 253 81 504 253 83 504 minecraft:brown_terracotta
setblock 254 81 466 minecraft:brown_terracotta
setblock 254 81 467 minecraft:bone_block
setblock 255 81 466 minecraft:bone_block
fill 255 81 467 255 84 467 minecraft:brown_terracotta
setblock 256 81 465 minecraft:bone_block
fill 256 81 466 256 84 466 minecraft:brown_terracotta
setblock 257 81 464 minecraft:bone_block
fill 257 81 465 257 84 465 minecraft:brown_terracotta
setblock 257 81 504 minecraft:bone_block
fill 258 81 464 258 84 464 minecraft:brown_terracotta
setblock 258 81 503 minecraft:bone_block
fill 258 81 504 258 84 504 minecraft:brown_terracotta
setblock 259 81 467 minecraft:bone_block
setblock 259 81 503 minecraft:brown_terracotta
setblock 260 81 466 minecraft:bone_block
fill 260 81 467 260 83 467 minecraft:brown_terracotta
setblock 261 81 465 minecraft:bone_block
fill 261 81 466 261 84 466 minecraft:brown_terracotta
setblock 262 81 464 minecraft:bone_block
fill 262 81 465 262 84 465 minecraft:brown_terracotta
setblock 262 81 467 minecraft:brown_terracotta
setblock 262 81 504 minecraft:bone_block
fill 263 81 464 263 84 464 minecraft:brown_terracotta
fill 263 81 504 263 82 504 minecraft:brown_terracotta
setblock 265 81 466 minecraft:bone_block
setblock 266 81 465 minecraft:bone_block
fill 266 81 466 269 81 466 minecraft:brown_terracotta
setblock 267 81 464 minecraft:bone_block
fill 267 81 465 267 84 465 minecraft:brown_terracotta
setblock 267 81 504 minecraft:bone_block
fill 268 81 464 268 84 464 minecraft:brown_terracotta
fill 268 81 504 268 84 504 minecraft:brown_terracotta
setblock 270 81 466 minecraft:bone_block
setblock 271 81 465 minecraft:bone_block
fill 271 81 466 271 83 466 minecraft:brown_terracotta
setblock 272 81 464 minecraft:bone_block
fill 272 81 465 272 84 465 minecraft:brown_terracotta
setblock 272 81 504 minecraft:bone_block
fill 273 81 464 273 84 464 minecraft:brown_terracotta
setblock 273 81 503 minecraft:bone_block
fill 273 81 504 273 84 504 minecraft:brown_terracotta
setblock 274 81 466 minecraft:brown_terracotta
setblock 274 81 467 minecraft:bone_block
fill 274 81 468 274 84 468 minecraft:brown_terracotta
setblock 274 81 487 minecraft:bone_block
fill 274 81 488 274 84 488 minecraft:brown_terracotta
fill 274 81 490 274 81 491 minecraft:brown_terracotta
setblock 274 81 492 minecraft:bone_block
setblock 274 81 502 minecraft:bone_block
fill 274 81 503 274 84 503 minecraft:brown_terracotta
setblock 275 81 466 minecraft:bone_block
fill 275 81 467 275 84 467 minecraft:brown_terracotta
setblock 275 81 471 minecraft:bone_block
fill 275 81 472 275 84 472 minecraft:brown_terracotta
setblock 275 81 486 minecraft:bone_block
fill 275 81 487 275 84 487 minecraft:brown_terracotta
setblock 275 81 490 minecraft:brown_terracotta
setblock 275 81 491 minecraft:bone_block
fill 275 81 492 275 81 495 minecraft:brown_terracotta
setblock 275 81 496 minecraft:bone_block
fill 275 81 497 275 84 497 minecraft:brown_terracotta
setblock 275 81 501 minecraft:bone_block
fill 275 81 502 275 84 502 minecraft:brown_terracotta
setblock 276 81 465 minecraft:bone_block
fill 276 81 466 276 84 466 minecraft:brown_terracotta
setblock 276 81 470 minecraft:bone_block
fill 276 81 471 276 84 471 minecraft:brown_terracotta
setblock 276 81 475 minecraft:bone_block
setblock 276 81 480 minecraft:bone_block
fill 276 81 481 276 83 481 minecraft:brown_terracotta
setblock 276 81 485 minecraft:bone_block
fill 276 81 486 276 84 486 minecraft:brown_terracotta
setblock 276 81 490 minecraft:bone_block
fill 276 81 491 276 84 491 minecraft:brown_terracotta
setblock 276 81 495 minecraft:bone_block
fill 276 81 496 276 84 496 minecraft:brown_terracotta
setblock 276 81 500 minecraft:bone_block
fill 276 81 501 276 84 501 minecraft:brown_terracotta
setblock 236 82 464 minecraft:bone_block
fill 236 82 465 236 85 465 minecraft:brown_terracotta
setblock 236 82 469 minecraft:bone_block
fill 236 82 470 236 82 473 minecraft:brown_terracotta
setblock 236 82 474 minecraft:bone_block
fill 236 82 475 236 82 478 minecraft:brown_terracotta
setblock 236 82 479 minecraft:bone_block
fill 236 82 480 236 82 483 minecraft:brown_terracotta
setblock 236 82 484 minecraft:bone_block
fill 236 82 485 236 85 485 minecraft:brown_terracotta
setblock 236 82 489 minecraft:bone_block
fill 236 82 490 236 85 490 minecraft:brown_terracotta
setblock 236 82 494 minecraft:bone_block
fill 236 82 495 236 85 495 minecraft:brown_terracotta
setblock 236 82 499 minecraft:bone_block
fill 236 82 500 236 85 500 minecraft:brown_terracotta
setblock 236 82 504 minecraft:bone_block
fill 237 82 464 237 85 464 minecraft:brown_terracotta
setblock 237 82 468 minecraft:bone_block
fill 237 82 469 237 85 469 minecraft:brown_terracotta
setblock 237 82 472 minecraft:brown_terracotta
setblock 237 82 483 minecraft:bone_block
fill 237 82 484 237 85 484 minecraft:brown_terracotta
setblock 237 82 488 minecraft:bone_block
fill 237 82 489 237 85 489 minecraft:brown_terracotta
setblock 237 82 493 minecraft:bone_block
fill 237 82 494 237 85 494 minecraft:brown_terracotta
setblock 237 82 498 minecraft:bone_block
fill 237 82 499 237 83 499 minecraft:brown_terracotta
setblock 237 82 503 minecraft:bone_block
fill 237 82 504 237 84 504 minecraft:brown_terracotta
setblock 238 82 483 minecraft:brown_terracotta
setblock 238 82 487 minecraft:bone_block
fill 238 82 488 238 85 488 minecraft:brown_terracotta
setblock 238 82 492 minecraft:bone_block
fill 238 82 493 238 85 493 minecraft:brown_terracotta
setblock 238 82 503 minecraft:brown_terracotta
setblock 239 82 486 minecraft:bone_block
fill 239 82 487 239 83 487 minecraft:brown_terracotta
setblock 239 82 491 minecraft:bone_block
setblock 239 82 492 minecraft:brown_terracotta
setblock 240 82 465 minecraft:bone_block
setblock 241 82 464 minecraft:bone_block
setblock 241 82 504 minecraft:bone_block
fill 242 82 464 243 82 464 minecraft:brown_terracotta
setblock 250 82 465 minecraft:bone_block
setblock 251 82 464 minecraft:bone_block
fill 251 82 465 251 85 465 minecraft:brown_terracotta
fill 252 82 464 252 85 464 minecraft:brown_terracotta
setblock 253 82 467 minecraft:bone_block
setblock 254 82 466 minecraft:bone_block
fill 254 82 467 254 85 467 minecraft:brown_terracotta
setblock 255 82 465 minecraft:bone_block
fill 255 82 466 255 85 466 minecraft:brown_terracotta
setblock 256 82 464 minecraft:bone_block
fill 256 82 465 256 85 465 minecraft:brown_terracotta
setblock 256 82 504 minecraft:bone_block
fill 257 82 464 257 85 464 minecraft:brown_terracotta
fill 257 82 504 257 84 504 minecraft:brown_terracotta
setblock 258 82 467 minecraft:bone_block
setblock 259 82 466 minecraft:bone_block
fill 259 82 467 259 83 467 minecraft:brown_terracotta
setblock 260 82 465 minecraft:bone_block
fill 260 82 466 260 84 466 minecraft:brown_terracotta
setblock 261 82 464 minecraft:bone_block
fill 261 82 465 261 85 465 minecraft:brown_terracotta
setblock 261 82 504 minecraft:bone_block
fill 262 82 464 262 85 464 minecraft:brown_terracotta
fill 262 82 504 262 83 504 minecraft:brown_terracotta
setblock 264 82 466 minecraft:bone_block
setblock 265 82 465 minecraft:bone_block
setblock 265 82 466 minecraft:brown_terracotta
setblock 266 82 464 minecraft:bone_block
fill 266 82 465 266 84 465 minecraft:brown_terracotta
setblock 266 82 504 minecraft:bone_block
fill 267 82 464 267 85 464 minecraft:brown_terracotta
fill 267 82 504 267 83 504 minecraft:brown_terracotta
setblock 270 82 465 minecraft:bone_block
setblock 270 82 466 minecraft:brown_terracotta
setblock 271 82 464 minecraft:bone_block
fill 271 82 465 271 85 465 minecraft:brown_terracotta
setblock 271 82 504 minecraft:bone_block
fill 272 82 464 272 85 464 minecraft:brown_terracotta
setblock 272 82 503 minecraft:bone_block
fill 272 82 504 272 85 504 minecraft:brown_terracotta
fill 273 82 503 273 85 503 minecraft:brown_terracotta
setblock 274 82 466 minecraft:bone_block
fill 274 82 467 274 84 467 minecraft:brown_terracotta
setblock 274 82 487 minecraft:brown_terracotta
setblock 274 82 490 minecraft:brown_terracotta
setblock 274 82 491 minecraft:bone_block
fill 274 82 492 275 83 493 minecraft:brown_terracotta
setblock 275 82 465 minecraft:bone_block
fill 275 82 466 275 85 466 minecraft:brown_terracotta
setblock 275 82 470 minecraft:bone_block
fill 275 82 471 275 85 471 minecraft:brown_terracotta
setblock 275 82 485 minecraft:bone_block
fill 275 82 486 275 85 486 minecraft:brown_terracotta
setblock 275 82 490 minecraft:bone_block
fill 275 82 491 275 85 491 minecraft:brown_terracotta
setblock 275 82 494 minecraft:brown_terracotta
setblock 275 82 495 minecraft:bone_block
fill 275 82 496 275 85 496 minecraft:brown_terracotta
setblock 275 82 500 minecraft:bone_block
fill 275 82 501 275 85 501 minecraft:brown_terracotta
setblock 276 82 464 minecraft:bone_block
fill 276 82 465 276 85 465 minecraft:brown_terracotta
setblock 276 82 469 minecraft:bone_block
fill 276 82 470 276 85 470 minecraft:brown_terracotta
setblock 276 82 473 minecraft:brown_terracotta
setblock 276 82 474 minecraft:bone_block
fill 276 82 475 276 84 475 minecraft:brown_terracotta
setblock 276 82 480 minecraft:brown_terracotta
setblock 276 82 484 minecraft:bone_block
fill 276 82 485 276 85 485 minecraft:brown_terracotta
setblock 276 82 489 minecraft:bone_block
fill 276 82 490 276 85 490 minecraft:brown_terracotta
setblock 276 82 494 minecraft:bone_block
fill 276 82 495 276 85 495 minecraft:brown_terracotta
setblock 276 82 499 minecraft:bone_block
fill 276 82 500 276 85 500 minecraft:brown_terracotta
setblock 276 82 504 minecraft:bone_block
fill 236 83 464 236 85 464 minecraft:brown_terracotta
setblock 236 83 468 minecraft:bone_block
fill 236 83 469 236 83 472 minecraft:brown_terracotta
setblock 236 83 473 minecraft:bone_block
fill 236 83 474 236 83 477 minecraft:brown_terracotta
setblock 236 83 478 minecraft:bone_block
fill 236 83 479 236 83 482 minecraft:brown_terracotta
setblock 236 83 483 minecraft:bone_block
fill 236 83 484 236 86 484 minecraft:brown_terracotta
setblock 236 83 488 minecraft:bone_block
fill 236 83 489 236 86 489 minecraft:brown_terracotta
setblock 236 83 493 minecraft:bone_block
fill 236 83 494 236 86 494 minecraft:brown_terracotta
setblock 236 83 498 minecraft:bone_block
fill 236 83 499 236 86 499 minecraft:brown_terracotta
setblock 236 83 503 minecraft:bone_block
fill 236 83 504 236 85 504 minecraft:brown_terracotta
setblock 237 83 467 minecraft:bone_block
fill 237 83 468 237 85 468 minecraft:brown_terracotta
setblock 237 83 472 minecraft:bone_block
setblock 237 83 482 minecraft:bone_block
fill 237 83 483 237 85 483 minecraft:brown_terracotta
setblock 237 83 487 minecraft:bone_block
fill 237 83 488 237 86 488 minecraft:brown_terracotta
setblock 237 83 492 minecraft:bone_block
fill 237 83 493 237 86 493 minecraft:brown_terracotta
setblock 237 83 497 minecraft:bone_block
fill 237 83 498 237 84 498 minecraft:brown_terracotta
setblock 237 83 503 minecraft:brown_terracotta
setblock 238 83 466 minecraft:light[level=12]
setblock 238 83 474 minecraft:light[level=12]
setblock 238 83 482 minecraft:light[level=12]
setblock 238 83 486 minecraft:bone_block
fill 238 83 487 238 85 487 minecraft:brown_terracotta
setblock 238 83 491 minecraft:bone_block
fill 238 83 492 238 86 492 minecraft:brown_terracotta
setblock 238 83 498 minecraft:light[level=12]
setblock 239 83 490 minecraft:bone_block
setblock 239 83 491 minecraft:brown_terracotta
setblock 240 83 464 minecraft:bone_block
setblock 241 83 464 minecraft:brown_terracotta
setblock 246 83 466 minecraft:light[level=12]
setblock 246 83 474 minecraft:light[level=12]
setblock 246 83 482 minecraft:light[level=12]
setblock 246 83 490 minecraft:light[level=12]
setblock 246 83 498 minecraft:light[level=12]
setblock 250 83 464 minecraft:bone_block
setblock 250 83 465 minecraft:brown_terracotta
fill 251 83 464 251 86 464 minecraft:brown_terracotta
setblock 253 83 466 minecraft:bone_block
setblock 253 83 467 minecraft:brown_terracotta
setblock 254 83 465 minecraft:bone_block
fill 254 83 466 254 86 466 minecraft:brown_terracotta
setblock 254 83 474 minecraft:light[level=12]
setblock 254 83 490 minecraft:light[level=12]
setblock 254 83 498 minecraft:light[level=12]
setblock 255 83 464 minecraft:bone_block
fill 255 83 465 255 86 465 minecraft:brown_terracotta
setblock 255 83 504 minecraft:bone_block
fill 256 83 464 256 86 464 minecraft:brown_terracotta
fill 256 83 504 256 85 504 minecraft:brown_terracotta
setblock 257 83 467 minecraft:bone_block
setblock 258 83 466 minecraft:bone_block
fill 258 83 467 258 84 467 minecraft:brown_terracotta
setblock 259 83 465 minecraft:bone_block
fill 259 83 466 259 85 466 minecraft:brown_terracotta
setblock 260 83 464 minecraft:bone_block
fill 260 83 465 260 86 465 minecraft:brown_terracotta
setblock 260 83 504 minecraft:bone_block
fill 261 83 464 261 86 464 minecraft:brown_terracotta
setblock 261 83 504 minecraft:brown_terracotta
setblock 262 83 474 minecraft:light[level=12]
setblock 262 83 482 minecraft:light[level=12]
setblock 262 83 490 minecraft:light[level=12]
setblock 262 83 498 minecraft:light[level=12]
setblock 263 83 466 minecraft:bone_block
setblock 264 83 465 minecraft:bone_block
setblock 265 83 464 minecraft:bone_block
fill 265 83 465 265 84 465 minecraft:brown_terracotta
fill 266 83 464 266 86 464 minecraft:brown_terracotta
setblock 269 83 465 minecraft:bone_block
setblock 270 83 464 minecraft:bone_block
fill 270 83 465 270 86 465 minecraft:brown_terracotta
setblock 270 83 466 minecraft:light[level=12]
setblock 270 83 474 minecraft:light[level=12]
setblock 270 83 482 minecraft:light[level=12]
setblock 270 83 490 minecraft:light[level=12]
setblock 270 83 498 minecraft:light[level=12]
setblock 270 83 504 minecraft:bone_block
fill 271 83 464 271 86 464 minecraft:brown_terracotta
setblock 271 83 503 minecraft:bone_block
fill 271 83 504 271 86 504 minecraft:brown_terracotta
fill 272 83 503 272 85 503 minecraft:brown_terracotta
setblock 273 83 466 minecraft:bone_block
setblock 274 83 465 minecraft:bone_block
fill 274 83 466 274 84 466 minecraft:brown_terracotta
setblock 274 83 490 minecraft:bone_block
fill 274 83 491 274 86 491 minecraft:brown_terracotta
setblock 274 83 494 minecraft:brown_terracotta
setblock 274 83 495 minecraft:bone_block
setblock 275 83 464 minecraft:bone_block
fill 275 83 465 275 86 465 minecraft:brown_terracotta
setblock 275 83 469 minecraft:bone_block
fill 275 83 470 275 86 470 minecraft:brown_terracotta
setblock 275 83 484 minecraft:bone_block
fill 275 83 485 275 84 485 minecraft:brown_terracotta
setblock 275 83 489 minecraft:bone_block
fill 275 83 490 275 86 490 minecraft:brown_terracotta
setblock 275 83 494 minecraft:bone_block
fill 275 83 495 275 86 495 minecraft:brown_terracotta
setblock 275 83 499 minecraft:bone_block
fill 275 83 500 275 86 500 minecraft:brown_terracotta
setblock 275 83 504 minecraft:bone_block
fill 276 83 464 276 86 464 minecraft:brown_terracotta
setblock 276 83 468 minecraft:bone_block
fill 276 83 469 276 86 469 minecraft:brown_terracotta
setblock 276 83 473 minecraft:bone_block
fill 276 83 474 276 86 474 minecraft:brown_terracotta
setblock 276 83 483 minecraft:bone_block
fill 276 83 484 276 86 484 minecraft:brown_terracotta
setblock 276 83 488 minecraft:bone_block
fill 276 83 489 276 86 489 minecraft:brown_terracotta
setblock 276 83 493 minecraft:bone_block
fill 276 83 494 276 86 494 minecraft:brown_terracotta
setblock 276 83 498 minecraft:bone_block
fill 276 83 499 276 86 499 minecraft:brown_terracotta
setblock 276 83 503 minecraft:bone_block
fill 276 83 504 276 86 504 minecraft:brown_terracotta
setblock 236 84 467 minecraft:bone_block
fill 236 84 468 236 84 471 minecraft:brown_terracotta
setblock 236 84 472 minecraft:bone_block
fill 236 84 473 236 84 476 minecraft:brown_terracotta
setblock 236 84 477 minecraft:bone_block
fill 236 84 478 236 84 481 minecraft:brown_terracotta
setblock 236 84 482 minecraft:bone_block
fill 236 84 483 236 87 483 minecraft:brown_terracotta
setblock 236 84 487 minecraft:bone_block
fill 236 84 488 236 87 488 minecraft:brown_terracotta
setblock 236 84 492 minecraft:bone_block
fill 236 84 493 236 87 493 minecraft:brown_terracotta
setblock 236 84 497 minecraft:bone_block
fill 236 84 498 236 87 498 minecraft:brown_terracotta
setblock 236 84 502 minecraft:bone_block
fill 236 84 503 236 85 503 minecraft:brown_terracotta
setblock 237 84 466 minecraft:bone_block
setblock 237 84 467 minecraft:brown_terracotta
setblock 237 84 471 minecraft:bone_block
setblock 237 84 472 minecraft:brown_terracotta
setblock 237 84 482 minecraft:brown_terracotta
setblock 237 84 486 minecraft:bone_block
fill 237 84 487 237 87 487 minecraft:brown_terracotta
setblock 237 84 491 minecraft:bone_block
fill 237 84 492 237 87 492 minecraft:brown_terracotta
setblock 237 84 496 minecraft:bone_block
fill 237 84 497 237 87 497 minecraft:brown_terracotta
setblock 238 84 485 minecraft:bone_block
fill 238 84 486 238 85 486 minecraft:brown_terracotta
setblock 238 84 490 minecraft:bone_block
fill 238 84 491 238 87 491 minecraft:brown_terracotta
setblock 238 84 495 minecraft:bone_block
setblock 239 84 464 minecraft:bone_block
setblock 249 84 464 minecraft:bone_block
fill 250 84 464 250 87 464 minecraft:brown_terracotta
setblock 252 84 466 minecraft:bone_block
setblock 253 84 465 minecraft:bone_block
fill 253 84 466 253 87 466 minecraft:brown_terracotta
setblock 254 84 464 minecraft:bone_block
fill 254 84 465 254 87 465 minecraft:brown_terracotta
setblock 254 84 504 minecraft:bone_block
fill 255 84 464 255 87 464 minecraft:brown_terracotta
setblock 255 84 504 minecraft:brown_terracotta
setblock 256 84 467 minecraft:bone_block
setblock 257 84 466 minecraft:bone_block
fill 257 84 467 257 85 467 minecraft:brown_terracotta
setblock 258 84 465 minecraft:bone_block
fill 258 84 466 258 86 466 minecraft:brown_terracotta
setblock 259 84 464 minecraft:bone_block
fill 259 84 465 259 87 465 minecraft:brown_terracotta
setblock 259 84 504 minecraft:bone_block
fill 260 84 464 260 87 464 minecraft:brown_terracotta
setblock 263 84 465 minecraft:bone_block
setblock 264 84 464 minecraft:bone_block
setblock 264 84 465 minecraft:brown_terracotta
fill 265 84 464 265 85 464 minecraft:brown_terracotta
setblock 268 84 465 minecraft:bone_block
setblock 269 84 464 minecraft:bone_block
fill 269 84 465 269 85 465 minecraft:brown_terracotta
setblock 269 84 504 minecraft:bone_block
fill 270 84 464 270 87 464 minecraft:brown_terracotta
fill 270 84 504 270 87 504 minecraft:brown_terracotta
setblock 272 84 466 minecraft:bone_block
setblock 273 84 465 minecraft:bone_block
setblock 273 84 466 minecraft:brown_terracotta
setblock 274 84 464 minecraft:bone_block
fill 274 84 465 274 86 465 minecraft:brown_terracotta
setblock 274 84 469 minecraft:bone_block
setblock 274 84 489 minecraft:bone_block
fill 274 84 490 274 87 490 minecraft:brown_terracotta
fill 274 84 492 274 84 493 minecraft:brown_terracotta
setblock 274 84 494 minecraft:bone_block
fill 274 84 495 274 87 495 minecraft:brown_terracotta
setblock 274 84 504 minecraft:bone_block
fill 275 84 464 275 87 464 minecraft:brown_terracotta
setblock 275 84 468 minecraft:bone_block
fill 275 84 469 275 87 469 minecraft:brown_terracotta
setblock 275 84 488 minecraft:bone_block
fill 275 84 489 275 87 489 minecraft:brown_terracotta
setblock 275 84 492 minecraft:brown_terracotta
setblock 275 84 493 minecraft:bone_block
fill 275 84 494 275 87 494 minecraft:brown_terracotta
setblock 275 84 498 minecraft:bone_block
fill 275 84 499 275 87 499 minecraft:brown_terracotta
setblock 275 84 503 minecraft:bone_block
fill 275 84 504 275 87 504 minecraft:brown_terracotta
setblock 276 84 467 minecraft:bone_block
fill 276 84 468 276 87 468 minecraft:brown_terracotta
setblock 276 84 472 minecraft:bone_block
fill 276 84 473 276 87 473 minecraft:brown_terracotta
setblock 276 84 482 minecraft:bone_block
fill 276 84 483 276 85 483 minecraft:brown_terracotta
setblock 276 84 487 minecraft:bone_block
fill 276 84 488 276 87 488 minecraft:brown_terracotta
setblock 276 84 492 minecraft:bone_block
fill 276 84 493 276 87 493 minecraft:brown_terracotta
setblock 276 84 497 minecraft:bone_block
fill 276 84 498 276 87 498 minecraft:brown_terracotta
setblock 276 84 502 minecraft:bone_block
fill 276 84 503 276 87 503 minecraft:brown_terracotta
setblock 236 85 466 minecraft:bone_block
fill 236 85 467 236 85 470 minecraft:brown_terracotta
setblock 236 85 471 minecraft:bone_block
fill 236 85 472 236 85 475 minecraft:brown_terracotta
setblock 236 85 476 minecraft:bone_block
fill 236 85 477 236 85 480 minecraft:brown_terracotta
setblock 236 85 481 minecraft:bone_block
fill 236 85 482 236 88 482 minecraft:brown_terracotta
setblock 236 85 486 minecraft:bone_block
fill 236 85 487 236 88 487 minecraft:brown_terracotta
setblock 236 85 491 minecraft:bone_block
fill 236 85 492 236 88 492 minecraft:brown_terracotta
setblock 236 85 496 minecraft:bone_block
fill 236 85 497 236 88 497 minecraft:brown_terracotta
setblock 236 85 501 minecraft:bone_block
setblock 236 85 502 minecraft:brown_terracotta
setblock 237 85 470 minecraft:bone_block
setblock 237 85 471 minecraft:brown_terracotta
setblock 237 85 485 minecraft:bone_block
fill 237 85 486 237 88 486 minecraft:brown_terracotta
setblock 237 85 490 minecraft:bone_block
fill 237 85 491 237 88 491 minecraft:brown_terracotta
setblock 237 85 495 minecraft:bone_block
fill 237 85 496 237 88 496 minecraft:brown_terracotta
setblock 238 85 489 minecraft:bone_block
fill 238 85 490 238 87 490 minecraft:brown_terracotta
setblock 238 85 494 minecraft:bone_block
fill 244 85 488 245 86 489 minecraft:bone_block
setblock 252 85 465 minecraft:bone_block
fill 252 85 466 252 86 466 minecraft:brown_terracotta
setblock 253 85 464 minecraft:bone_block
fill 253 85 465 253 88 465 minecraft:brown_terracotta
fill 254 85 464 254 88 464 minecraft:brown_terracotta
setblock 255 85 467 minecraft:bone_block
setblock 256 85 466 minecraft:bone_block
setblock 256 85 467 minecraft:brown_terracotta
setblock 257 85 465 minecraft:bone_block
fill 257 85 466 257 86 466 minecraft:brown_terracotta
setblock 258 85 464 minecraft:bone_block
fill 258 85 465 258 87 465 minecraft:brown_terracotta
fill 259 85 464 259 88 464 minecraft:brown_terracotta
setblock 262 85 465 minecraft:bone_block
setblock 263 85 464 minecraft:bone_block
fill 264 85 464 264 86 464 minecraft:brown_terracotta
setblock 268 85 464 minecraft:bone_block
fill 269 85 464 269 88 464 minecraft:brown_terracotta
fill 269 85 504 269 88 504 minecraft:brown_terracotta
setblock 272 85 465 minecraft:bone_block
setblock 273 85 464 minecraft:bone_block
fill 273 85 465 273 87 465 minecraft:brown_terracotta
setblock 273 85 504 minecraft:bone_block
fill 274 85 464 274 88 464 minecraft:brown_terracotta
fill 274 85 489 274 87 489 minecraft:brown_terracotta
setblock 274 85 492 minecraft:brown_terracotta
setblock 274 85 493 minecraft:bone_block
fill 274 85 494 274 88 494 minecraft:brown_terracotta
fill 274 85 496 274 86 496 minecraft:brown_terracotta
setblock 274 85 503 minecraft:bone_block
fill 274 85 504 274 88 504 minecraft:brown_terracotta
setblock 275 85 467 minecraft:bone_block
fill 275 85 468 275 87 468 minecraft:brown_terracotta
setblock 275 85 472 minecraft:bone_block
setblock 275 85 487 minecraft:bone_block
fill 275 85 488 275 88 488 minecraft:brown_terracotta
setblock 275 85 492 minecraft:bone_block
fill 275 85 493 275 88 493 minecraft:brown_terracotta
setblock 275 85 497 minecraft:bone_block
fill 275 85 498 275 88 498 minecraft:brown_terracotta
setblock 275 85 502 minecraft:bone_block
fill 275 85 503 275 86 503 minecraft:brown_terracotta
setblock 276 85 466 minecraft:bone_block
fill 276 85 467 276 88 467 minecraft:brown_terracotta
setblock 276 85 471 minecraft:bone_block
fill 276 85 472 276 88 472 minecraft:brown_terracotta
setblock 276 85 486 minecraft:bone_block
fill 276 85 487 276 88 487 minecraft:brown_terracotta
setblock 276 85 491 minecraft:bone_block
fill 276 85 492 276 88 492 minecraft:brown_terracotta
setblock 276 85 496 minecraft:bone_block
fill 276 85 497 276 88 497 minecraft:brown_terracotta
setblock 276 85 501 minecraft:bone_block
fill 276 85 502 276 88 502 minecraft:brown_terracotta
setblock 236 86 465 minecraft:bone_block
fill 236 86 466 236 86 469 minecraft:brown_terracotta
setblock 236 86 470 minecraft:bone_block
fill 236 86 471 236 86 474 minecraft:brown_terracotta
setblock 236 86 475 minecraft:bone_block
fill 236 86 476 236 86 479 minecraft:brown_terracotta
setblock 236 86 480 minecraft:bone_block
fill 236 86 481 236 89 481 minecraft:brown_terracotta
setblock 236 86 485 minecraft:bone_block
fill 236 86 486 236 89 486 minecraft:brown_terracotta
setblock 236 86 490 minecraft:bone_block
fill 236 86 491 236 89 491 minecraft:brown_terracotta
setblock 236 86 495 minecraft:bone_block
fill 236 86 496 236 89 496 minecraft:brown_terracotta
setblock 236 86 500 minecraft:bone_block
setblock 236 86 501 minecraft:brown_terracotta
setblock 237 86 484 minecraft:bone_block
setblock 237 86 485 minecraft:brown_terracotta
setblock 237 86 489 minecraft:bone_block
fill 237 86 490 237 89 490 minecraft:brown_terracotta
setblock 237 86 494 minecraft:bone_block
fill 237 86 495 237 89 495 minecraft:brown_terracotta
setblock 238 86 488 minecraft:bone_block
setblock 238 86 489 minecraft:brown_terracotta
setblock 238 86 493 minecraft:bone_block
setblock 251 86 465 minecraft:bone_block
setblock 252 86 464 minecraft:bone_block
fill 252 86 465 252 89 465 minecraft:brown_terracotta
fill 253 86 464 253 89 464 minecraft:brown_terracotta
setblock 255 86 466 minecraft:bone_block
setblock 256 86 465 minecraft:bone_block
fill 256 86 466 256 87 466 minecraft:brown_terracotta
setblock 257 86 464 minecraft:bone_block
fill 257 86 465 257 89 465 minecraft:brown_terracotta
fill 258 86 464 258 89 464 minecraft:brown_terracotta
setblock 262 86 464 minecraft:bone_block
setblock 263 86 464 minecraft:brown_terracotta
setblock 267 86 464 minecraft:bone_block
fill 268 86 464 268 89 464 minecraft:brown_terracotta
setblock 271 86 465 minecraft:bone_block
setblock 272 86 464 minecraft:bone_block
fill 272 86 465 272 87 465 minecraft:brown_terracotta
setblock 272 86 504 minecraft:bone_block
fill 273 86 464 273 89 464 minecraft:brown_terracotta
setblock 273 86 503 minecraft:bone_block
fill 273 86 504 273 89 504 minecraft:brown_terracotta
setblock 274 86 492 minecraft:bone_block
fill 274 86 493 274 89 493 minecraft:brown_terracotta
setblock 274 86 497 minecraft:bone_block
fill 274 86 503 274 89 503 minecraft:brown_terracotta
setblock 275 86 466 minecraft:bone_block
fill 275 86 467 275 87 467 minecraft:brown_terracotta
setblock 275 86 471 minecraft:bone_block
fill 275 86 472 275 89 472 minecraft:brown_terracotta
setblock 275 86 486 minecraft:bone_block
fill 275 86 487 275 88 487 minecraft:brown_terracotta
setblock 275 86 491 minecraft:bone_block
fill 275 86 492 275 89 492 minecraft:brown_terracotta
setblock 275 86 496 minecraft:bone_block
fill 275 86 497 275 89 497 minecraft:brown_terracotta
setblock 275 86 501 minecraft:bone_block
fill 275 86 502 275 89 502 minecraft:brown_terracotta
setblock 276 86 465 minecraft:bone_block
fill 276 86 466 276 88 466 minecraft:brown_terracotta
setblock 276 86 470 minecraft:bone_block
fill 276 86 471 276 89 471 minecraft:brown_terracotta
setblock 276 86 485 minecraft:bone_block
fill 276 86 486 276 89 486 minecraft:brown_terracotta
setblock 276 86 490 minecraft:bone_block
fill 276 86 491 276 89 491 minecraft:brown_terracotta
setblock 276 86 495 minecraft:bone_block
fill 276 86 496 276 89 496 minecraft:brown_terracotta
setblock 276 86 500 minecraft:bone_block
fill 276 86 501 276 89 501 minecraft:brown_terracotta
fill 236 87 466 236 87 468 minecraft:brown_terracotta
setblock 236 87 469 minecraft:bone_block
fill 236 87 470 236 87 473 minecraft:brown_terracotta
setblock 236 87 474 minecraft:bone_block
fill 236 87 475 236 87 478 minecraft:brown_terracotta
setblock 236 87 479 minecraft:bone_block
fill 236 87 480 236 90 480 minecraft:brown_terracotta
setblock 236 87 484 minecraft:bone_block
fill 236 87 485 236 90 485 minecraft:brown_terracotta
setblock 236 87 489 minecraft:bone_block
fill 236 87 490 236 90 490 minecraft:brown_terracotta
setblock 236 87 494 minecraft:bone_block
fill 236 87 495 236 90 495 minecraft:brown_terracotta
setblock 236 87 499 minecraft:bone_block
fill 236 87 500 236 90 500 minecraft:brown_terracotta
setblock 237 87 488 minecraft:bone_block
fill 237 87 489 237 90 489 minecraft:brown_terracotta
setblock 237 87 493 minecraft:bone_block
fill 237 87 494 237 90 494 minecraft:brown_terracotta
setblock 238 87 492 minecraft:bone_block
setblock 238 87 493 minecraft:brown_terracotta
setblock 251 87 464 minecraft:bone_block
fill 251 87 465 251 90 465 minecraft:brown_terracotta
fill 252 87 464 252 90 464 minecraft:brown_terracotta
setblock 254 87 466 minecraft:bone_block
setblock 255 87 465 minecraft:bone_block
fill 255 87 466 255 88 466 minecraft:brown_terracotta
setblock 256 87 464 minecraft:bone_block
fill 256 87 465 256 90 465 minecraft:brown_terracotta
fill 257 87 464 257 90 464 minecraft:brown_terracotta
setblock 261 87 464 minecraft:bone_block
setblock 267 87 464 minecraft:brown_terracotta
setblock 271 87 464 minecraft:bone_block
setblock 271 87 465 minecraft:brown_terracotta
setblock 271 87 504 minecraft:bone_block
fill 272 87 464 272 90 464 minecraft:brown_terracotta
fill 272 87 504 272 90 504 minecraft:brown_terracotta
fill 273 87 503 273 90 503 minecraft:brown_terracotta
setblock 274 87 491 minecraft:bone_block
fill 274 87 492 274 90 492 minecraft:brown_terracotta
setblock 274 87 496 minecraft:bone_block
fill 274 87 497 274 89 498 minecraft:brown_terracotta
setblock 275 87 470 minecraft:bone_block
fill 275 87 471 275 90 471 minecraft:brown_terracotta
setblock 275 87 490 minecraft:bone_block
fill 275 87 491 275 90 491 minecraft:brown_terracotta
setblock 275 87 495 minecraft:bone_block
fill 275 87 496 275 90 496 minecraft:brown_terracotta
setblock 275 87 500 minecraft:bone_block
fill 275 87 501 275 90 501 minecraft:brown_terracotta
setblock 276 87 464 minecraft:bone_block
fill 276 87 465 276 88 465 minecraft:brown_terracotta
setblock 276 87 469 minecraft:bone_block
fill 276 87 470 276 90 470 minecraft:brown_terracotta
setblock 276 87 474 minecraft:bone_block
fill 276 87 475 276 90 475 minecraft:brown_terracotta
fill 276 87 485 276 90 485 minecraft:brown_terracotta
setblock 276 87 489 minecraft:bone_block
fill 276 87 490 276 90 490 minecraft:brown_terracotta
setblock 276 87 494 minecraft:bone_block
fill 276 87 495 276 90 495 minecraft:brown_terracotta
setblock 276 87 499 minecraft:bone_block
fill 276 87 500 276 90 500 minecraft:brown_terracotta
setblock 276 87 504 minecraft:bone_block
setblock 236 88 467 minecraft:brown_terracotta
setblock 236 88 468 minecraft:bone_block
fill 236 88 469 236 88 472 minecraft:brown_terracotta
setblock 236 88 473 minecraft:bone_block
fill 236 88 474 236 88 477 minecraft:brown_terracotta
setblock 236 88 478 minecraft:bone_block
fill 236 88 479 236 91 479 minecraft:brown_terracotta
setblock 236 88 483 minecraft:bone_block
fill 236 88 484 236 91 484 minecraft:brown_terracotta
setblock 236 88 488 minecraft:bone_block
fill 236 88 489 236 91 489 minecraft:brown_terracotta
setblock 236 88 493 minecraft:bone_block
fill 236 88 494 236 91 494 minecraft:brown_terracotta
setblock 236 88 498 minecraft:bone_block
fill 236 88 499 236 91 499 minecraft:brown_terracotta
setblock 237 88 487 minecraft:bone_block
fill 237 88 488 237 90 488 minecraft:brown_terracotta
setblock 237 88 492 minecraft:bone_block
fill 237 88 493 237 91 493 minecraft:brown_terracotta
setblock 237 88 497 minecraft:bone_block
setblock 250 88 464 minecraft:bone_block
fill 251 88 464 251 91 464 minecraft:brown_terracotta
setblock 253 88 466 minecraft:bone_block
setblock 254 88 465 minecraft:bone_block
fill 254 88 466 254 89 466 minecraft:brown_terracotta
setblock 255 88 464 minecraft:bone_block
fill 255 88 465 255 91 465 minecraft:brown_terracotta
fill 256 88 464 256 91 464 minecraft:brown_terracotta
setblock 260 88 464 minecraft:bone_block
fill 268 88 504 268 89 504 minecraft:brown_terracotta
setblock 270 88 464 minecraft:bone_block
setblock 270 88 504 minecraft:bone_block
fill 271 88 464 271 91 464 minecraft:brown_terracotta
fill 271 88 504 271 91 504 minecraft:brown_terracotta
fill 272 88 503 272 91 503 minecraft:brown_terracotta
setblock 274 88 490 minecraft:bone_block
fill 274 88 491 274 91 491 minecraft:brown_terracotta
setblock 274 88 495 minecraft:bone_block
fill 274 88 496 274 91 496 minecraft:brown_terracotta
setblock 274 88 499 minecraft:brown_terracotta
setblock 275 88 464 minecraft:bone_block
setblock 275 88 469 minecraft:bone_block
fill 275 88 470 275 89 470 minecraft:brown_terracotta
setblock 275 88 489 minecraft:bone_block
fill 275 88 490 275 91 490 minecraft:brown_terracotta
setblock 275 88 494 minecraft:bone_block
fill 275 88 495 275 91 495 minecraft:brown_terracotta
setblock 275 88 499 minecraft:bone_block
fill 275 88 500 275 91 500 minecraft:brown_terracotta
setblock 275 88 504 minecraft:bone_block
setblock 276 88 468 minecraft:bone_block
fill 276 88 469 276 91 469 minecraft:brown_terracotta
setblock 276 88 473 minecraft:bone_block
fill 276 88 474 276 91 474 minecraft:brown_terracotta
setblock 276 88 488 minecraft:bone_block
fill 276 88 489 276 91 489 minecraft:brown_terracotta
setblock 276 88 493 minecraft:bone_block
fill 276 88 494 276 91 494 minecraft:brown_terracotta
setblock 276 88 498 minecraft:bone_block
fill 276 88 499 276 91 499 minecraft:brown_terracotta
setblock 276 88 503 minecraft:bone_block
fill 276 88 504 276 91 504 minecraft:brown_terracotta
fill 236 89 468 236 89 471 minecraft:brown_terracotta
setblock 236 89 472 minecraft:bone_block
fill 236 89 473 236 89 476 minecraft:brown_terracotta
setblock 236 89 477 minecraft:bone_block
fill 236 89 478 236 92 478 minecraft:brown_terracotta
setblock 236 89 482 minecraft:bone_block
fill 236 89 483 236 92 483 minecraft:brown_terracotta
setblock 236 89 487 minecraft:bone_block
fill 236 89 488 236 92 488 minecraft:brown_terracotta
setblock 236 89 492 minecraft:bone_block
fill 236 89 493 236 92 493 minecraft:brown_terracotta
setblock 236 89 497 minecraft:bone_block
fill 236 89 498 236 92 498 minecraft:brown_terracotta
fill 237 89 473 237 90 474 minecraft:brown_terracotta
setblock 237 89 487 minecraft:brown_terracotta
setblock 237 89 491 minecraft:bone_block
fill 237 89 492 237 92 492 minecraft:brown_terracotta
setblock 237 89 496 minecraft:bone_block
fill 237 89 497 237 92 497 minecraft:brown_terracotta
setblock 249 89 464 minecraft:bone_block
fill 250 89 464 250 91 465 minecraft:brown_terracotta
setblock 253 89 465 minecraft:bone_block
fill 253 89 466 253 92 466 minecraft:brown_terracotta
setblock 254 89 464 minecraft:bone_block
fill 254 89 465 254 92 465 minecraft:brown_terracotta
fill 255 89 464 255 92 464 minecraft:brown_terracotta
setblock 259 89 464 minecraft:bone_block
fill 267 89 464 267 90 464 minecraft:brown_terracotta
setblock 269 89 464 minecraft:bone_block
setblock 269 89 504 minecraft:bone_block
fill 270 89 464 270 92 464 minecraft:brown_terracotta
setblock 270 89 503 minecraft:bone_block
fill 270 89 504 270 92 504 minecraft:brown_terracotta
fill 271 89 503 271 92 503 minecraft:brown_terracotta
fill 273 89 493 273 89 494 minecraft:brown_terracotta
setblock 273 89 495 minecraft:bone_block
fill 273 89 496 273 92 496 minecraft:brown_terracotta
setblock 274 89 464 minecraft:bone_block
fill 274 89 490 274 92 490 minecraft:brown_terracotta
setblock 274 89 494 minecraft:bone_block
fill 274 89 495 274 92 495 minecraft:brown_terracotta
setblock 274 89 499 minecraft:bone_block
setblock 274 89 504 minecraft:bone_block
setblock 275 89 473 minecraft:bone_block
setblock 275 89 488 minecraft:bone_block
fill 275 89 489 275 92 489 minecraft:brown_terracotta
setblock 275 89 493 minecraft:bone_block
fill 275 89 494 275 92 494 minecraft:brown_terracotta
setblock 275 89 498 minecraft:bone_block
fill 275 89 499 275 92 499 minecraft:brown_terracotta
fill 275 89 504 275 92 504 minecraft:brown_terracotta
setblock 276 89 467 minecraft:bone_block
fill 276 89 468 276 90 468 minecraft:brown_terracotta
setblock 276 89 472 minecraft:bone_block
fill 276 89 473 276 92 473 minecraft:brown_terracotta
setblock 276 89 476 minecraft:brown_terracotta
setblock 276 89 487 minecraft:bone_block
fill 276 89 488 276 92 488 minecraft:brown_terracotta
setblock 276 89 492 minecraft:bone_block
fill 276 89 493 276 92 493 minecraft:brown_terracotta
setblock 276 89 497 minecraft:bone_block
fill 276 89 498 276 92 498 minecraft:brown_terracotta
setblock 276 89 502 minecraft:bone_block
fill 276 89 503 276 92 503 minecraft:brown_terracotta
fill 236 90 468 236 90 470 minecraft:brown_terracotta
setblock 236 90 471 minecraft:bone_block
fill 236 90 472 236 90 475 minecraft:brown_terracotta
setblock 236 90 476 minecraft:bone_block
fill 236 90 477 237 92 477 minecraft:brown_terracotta
setblock 236 90 481 minecraft:bone_block
fill 236 90 482 236 93 482 minecraft:brown_terracotta
setblock 236 90 486 minecraft:bone_block
fill 236 90 487 236 93 487 minecraft:brown_terracotta
setblock 236 90 491 minecraft:bone_block
fill 236 90 492 236 93 492 minecraft:brown_terracotta
setblock 236 90 496 minecraft:bone_block
fill 236 90 497 236 93 497 minecraft:brown_terracotta
setblock 236 90 501 minecraft:bone_block
fill 237 90 472 237 92 472 minecraft:brown_terracotta
setblock 237 90 475 minecraft:bone_block
fill 237 90 476 237 93 476 minecraft:brown_terracotta
setblock 237 90 490 minecraft:bone_block
fill 237 90 491 237 93 491 minecraft:brown_terracotta
setblock 237 90 495 minecraft:bone_block
fill 237 90 496 237 93 496 minecraft:brown_terracotta
setblock 248 90 464 minecraft:bone_block
fill 249 90 464 249 93 464 minecraft:brown_terracotta
setblock 252 90 465 minecraft:bone_block
fill 252 90 466 252 93 466 minecraft:brown_terracotta
setblock 253 90 464 minecraft:bone_block
fill 253 90 465 253 93 465 minecraft:brown_terracotta
setblock 253 90 504 minecraft:bone_block
fill 254 90 464 254 93 464 minecraft:brown_terracotta
fill 254 90 504 254 93 504 minecraft:brown_terracotta
setblock 258 90 464 minecraft:bone_block
fill 259 90 464 259 93 464 minecraft:brown_terracotta
fill 266 90 504 267 90 504 minecraft:brown_terracotta
setblock 268 90 464 minecraft:bone_block
setblock 268 90 504 minecraft:bone_block
fill 269 90 464 269 93 464 minecraft:brown_terracotta
setblock 269 90 503 minecraft:bone_block
fill 269 90 504 269 93 504 minecraft:brown_terracotta
fill 270 90 503 270 93 503 minecraft:brown_terracotta
setblock 273 90 464 minecraft:bone_block
fill 273 90 492 273 90 493 minecraft:brown_terracotta
setblock 273 90 494 minecraft:bone_block
fill 273 90 495 273 93 495 minecraft:brown_terracotta
fill 273 90 497 273 90 498 minecraft:brown_terracotta
setblock 273 90 504 minecraft:bone_block
fill 274 90 464 274 91 464 minecraft:brown_terracotta
setblock 274 90 493 minecraft:bone_block
fill 274 90 494 274 93 494 minecraft:brown_terracotta
setblock 274 90 497 minecraft:brown_terracotta
setblock 274 90 498 minecraft:bone_block
fill 274 90 499 274 92 500 minecraft:brown_terracotta
setblock 274 90 503 minecraft:bone_block
fill 274 90 504 274 93 504 minecraft:brown_terracotta
setblock 275 90 472 minecraft:bone_block
fill 275 90 473 275 92 474 minecraft:brown_terracotta
fill 275 90 488 275 93 488 minecraft:brown_terracotta
setblock 275 90 492 minecraft:bone_block
fill 275 90 493 275 93 493 minecraft:brown_terracotta
setblock 275 90 497 minecraft:bone_block
fill 275 90 498 275 93 498 minecraft:brown_terracotta
setblock 275 90 502 minecraft:bone_block
setblock 276 90 471 minecraft:bone_block
fill 276 90 472 276 93 472 minecraft:brown_terracotta
setblock 276 90 476 minecraft:bone_block
fill 276 90 477 276 92 478 minecraft:brown_terracotta
setblock 276 90 486 minecraft:bone_block
fill 276 90 487 276 93 487 minecraft:brown_terracotta
setblock 276 90 491 minecraft:bone_block
fill 276 90 492 276 93 492 minecraft:brown_terracotta
setblock 276 90 496 minecraft:bone_block
fill 276 90 497 276 93 497 minecraft:brown_terracotta
setblock 276 90 501 minecraft:bone_block
fill 276 90 502 276 93 502 minecraft:brown_terracotta
setblock 236 91 469 minecraft:brown_terracotta
setblock 236 91 470 minecraft:bone_block
fill 236 91 471 236 91 474 minecraft:brown_terracotta
setblock 236 91 475 minecraft:bone_block
fill 236 91 476 236 93 476 minecraft:brown_terracotta
setblock 236 91 480 minecraft:bone_block
fill 236 91 481 236 93 481 minecraft:brown_terracotta
setblock 236 91 485 minecraft:bone_block
fill 236 91 486 236 93 486 minecraft:brown_terracotta
setblock 236 91 490 minecraft:bone_block
fill 236 91 491 236 93 491 minecraft:brown_terracotta
setblock 236 91 495 minecraft:bone_block
fill 236 91 496 236 93 496 minecraft:brown_terracotta
setblock 236 91 500 minecraft:bone_block
fill 236 91 501 236 93 501 minecraft:brown_terracotta
setblock 237 91 473 minecraft:brown_terracotta
setblock 237 91 474 minecraft:bone_block
fill 237 91 475 237 93 475 minecraft:brown_terracotta
setblock 237 91 478 minecraft:brown_terracotta
setblock 237 91 489 minecraft:bone_block
fill 237 91 490 237 92 490 minecraft:brown_terracotta
setblock 237 91 494 minecraft:bone_block
fill 237 91 495 237 93 495 minecraft:brown_terracotta
setblock 237 91 498 minecraft:brown_terracotta
setblock 238 91 466 minecraft:light[level=12]
setblock 238 91 474 minecraft:light[level=12]
setblock 238 91 482 minecraft:light[level=12]
setblock 238 91 490 minecraft:light[level=12]
setblock 238 91 498 minecraft:light[level=12]
setblock 246 91 466 minecraft:light[level=12]
setblock 246 91 474 minecraft:light[level=12]
setblock 246 91 482 minecraft:light[level=12]
setblock 246 91 490 minecraft:light[level=12]
setblock 246 91 498 minecraft:light[level=12]
fill 248 91 464 248 93 464 minecraft:brown_terracotta
fill 249 91 465 249 92 465 minecraft:brown_terracotta
fill 250 91 504 251 91 504 minecraft:brown_terracotta
setblock 251 91 465 minecraft:bone_block
fill 251 91 466 251 93 466 minecraft:brown_terracotta
setblock 252 91 464 minecraft:bone_block
fill 252 91 465 252 93 465 minecraft:brown_terracotta
setblock 252 91 504 minecraft:bone_block
fill 253 91 464 253 93 464 minecraft:brown_terracotta
fill 253 91 504 253 93 504 minecraft:brown_terracotta
setblock 254 91 466 minecraft:light[level=12]
setblock 254 91 474 minecraft:light[level=12]
setblock 254 91 490 minecraft:light[level=12]
setblock 254 91 498 minecraft:light[level=12]
fill 255 91 504 255 92 504 minecraft:brown_terracotta
setblock 256 91 465 minecraft:bone_block
setblock 257 91 464 minecraft:bone_block
fill 258 91 464 258 93 464 minecraft:brown_terracotta
setblock 262 91 466 minecraft:light[level=12]
setblock 262 91 474 minecraft:light[level=12]
setblock 262 91 482 minecraft:light[level=12]
setblock 262 91 490 minecraft:light[level=12]
setblock 262 91 498 minecraft:light[level=12]
fill 265 91 504 266 91 504 minecraft:brown_terracotta
setblock 266 91 464 minecraft:brown_terracotta
setblock 267 91 464 minecraft:bone_block
setblock 267 91 503 minecraft:brown_terracotta
setblock 267 91 504 minecraft:bone_block
fill 268 91 464 268 93 464 minecraft:brown_terracotta
setblock 268 91 503 minecraft:bone_block
fill 268 91 504 268 93 504 minecraft:brown_terracotta
fill 269 91 486 273 92 490 minecraft:soul_soil
schedule function dropper:buildpart/113_3 1t
