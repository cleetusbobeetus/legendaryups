setblock 346 200 465 minecraft:red_nether_bricks
setblock 347 200 464 minecraft:red_nether_bricks
fill 347 200 465 347 203 465 minecraft:pink_terracotta
setblock 347 200 504 minecraft:red_nether_bricks
fill 348 200 464 348 203 464 minecraft:pink_terracotta
setblock 348 200 503 minecraft:red_nether_bricks
fill 348 200 504 348 203 504 minecraft:pink_terracotta
setblock 349 200 466 minecraft:pink_terracotta
setblock 349 200 502 minecraft:red_nether_bricks
fill 349 200 503 349 203 503 minecraft:pink_terracotta
setblock 350 200 465 minecraft:pink_terracotta
setblock 350 200 466 minecraft:red_nether_bricks
fill 350 200 502 350 202 502 minecraft:pink_terracotta
setblock 351 200 465 minecraft:red_nether_bricks
fill 351 200 466 351 203 466 minecraft:pink_terracotta
setblock 352 200 464 minecraft:red_nether_bricks
fill 352 200 465 352 203 465 minecraft:pink_terracotta
setblock 352 200 504 minecraft:red_nether_bricks
fill 353 200 464 353 203 464 minecraft:pink_terracotta
setblock 353 200 503 minecraft:red_nether_bricks
fill 353 200 504 353 203 504 minecraft:pink_terracotta
setblock 354 200 502 minecraft:red_nether_bricks
fill 354 200 503 354 203 503 minecraft:pink_terracotta
setblock 355 200 502 minecraft:pink_terracotta
setblock 356 200 465 minecraft:red_nether_bricks
setblock 357 200 464 minecraft:red_nether_bricks
setblock 357 200 504 minecraft:red_nether_bricks
fill 358 200 464 358 201 464 minecraft:pink_terracotta
setblock 358 200 503 minecraft:red_nether_bricks
fill 358 200 504 361 200 504 minecraft:pink_terracotta
setblock 359 200 464 minecraft:white_concrete
setblock 367 200 464 minecraft:red_nether_bricks
setblock 367 200 504 minecraft:red_nether_bricks
fill 368 200 464 368 203 464 minecraft:pink_terracotta
setblock 368 200 483 minecraft:red_nether_bricks
fill 368 200 484 368 203 484 minecraft:pink_terracotta
setblock 368 200 488 minecraft:red_nether_bricks
fill 368 200 504 368 203 504 minecraft:pink_terracotta
setblock 369 200 482 minecraft:red_nether_bricks
fill 369 200 483 369 203 483 minecraft:pink_terracotta
setblock 369 200 487 minecraft:red_nether_bricks
fill 369 200 488 369 203 488 minecraft:pink_terracotta
setblock 370 200 466 minecraft:red_nether_bricks
fill 370 200 467 370 203 467 minecraft:pink_terracotta
setblock 370 200 471 minecraft:red_nether_bricks
fill 370 200 472 370 203 472 minecraft:pink_terracotta
setblock 370 200 476 minecraft:red_nether_bricks
fill 370 200 477 370 203 477 minecraft:pink_terracotta
setblock 370 200 481 minecraft:red_nether_bricks
fill 370 200 482 370 203 482 minecraft:pink_terracotta
setblock 370 200 486 minecraft:red_nether_bricks
fill 370 200 487 370 203 487 minecraft:pink_terracotta
setblock 370 200 491 minecraft:red_nether_bricks
fill 370 200 492 370 203 492 minecraft:pink_terracotta
setblock 370 200 497 minecraft:white_concrete
setblock 370 200 501 minecraft:red_nether_bricks
fill 370 200 502 370 202 502 minecraft:pink_terracotta
fill 329 201 498 329 205 498 minecraft:pink_terracotta
setblock 329 201 499 minecraft:red_terracotta
fill 329 201 500 329 202 503 minecraft:pink_terracotta
setblock 330 201 464 minecraft:pink_terracotta
setblock 330 201 465 minecraft:red_nether_bricks
fill 330 201 466 330 204 466 minecraft:pink_terracotta
setblock 330 201 470 minecraft:red_nether_bricks
fill 330 201 471 330 204 471 minecraft:pink_terracotta
setblock 330 201 475 minecraft:red_nether_bricks
fill 330 201 476 330 204 476 minecraft:pink_terracotta
setblock 330 201 480 minecraft:red_nether_bricks
fill 330 201 481 330 201 484 minecraft:pink_terracotta
setblock 330 201 485 minecraft:red_nether_bricks
fill 330 201 486 330 204 486 minecraft:pink_terracotta
setblock 330 201 490 minecraft:red_nether_bricks
fill 330 201 491 330 204 491 minecraft:pink_terracotta
setblock 331 201 464 minecraft:red_nether_bricks
fill 331 201 465 331 204 465 minecraft:pink_terracotta
setblock 331 201 468 minecraft:pink_terracotta
setblock 331 201 469 minecraft:red_nether_bricks
fill 331 201 470 331 204 470 minecraft:pink_terracotta
setblock 331 201 474 minecraft:red_nether_bricks
fill 331 201 475 331 204 475 minecraft:pink_terracotta
setblock 331 201 479 minecraft:red_nether_bricks
fill 331 201 480 331 204 480 minecraft:pink_terracotta
setblock 331 201 484 minecraft:red_nether_bricks
fill 331 201 485 331 204 485 minecraft:pink_terracotta
setblock 331 201 489 minecraft:red_nether_bricks
setblock 331 201 504 minecraft:red_nether_bricks
fill 332 201 464 332 204 464 minecraft:pink_terracotta
setblock 332 201 468 minecraft:red_nether_bricks
fill 332 201 469 332 204 469 minecraft:pink_terracotta
setblock 332 201 483 minecraft:red_nether_bricks
fill 332 201 484 332 202 484 minecraft:pink_terracotta
fill 332 201 504 332 204 504 minecraft:pink_terracotta
setblock 334 201 466 minecraft:red_nether_bricks
setblock 335 201 465 minecraft:red_nether_bricks
fill 335 201 466 335 204 466 minecraft:pink_terracotta
setblock 336 201 464 minecraft:red_nether_bricks
fill 336 201 465 336 204 465 minecraft:pink_terracotta
setblock 336 201 504 minecraft:red_nether_bricks
fill 337 201 464 340 201 464 minecraft:pink_terracotta
fill 337 201 504 337 202 504 minecraft:pink_terracotta
setblock 338 201 505 minecraft:red_terracotta
fill 339 201 463 340 202 463 minecraft:pink_terracotta
fill 339 201 505 344 201 505 minecraft:pink_terracotta
setblock 340 201 465 minecraft:red_nether_bricks
setblock 341 201 463 minecraft:red_terracotta
setblock 341 201 464 minecraft:red_nether_bricks
fill 341 201 465 341 204 465 minecraft:pink_terracotta
setblock 341 201 504 minecraft:red_nether_bricks
fill 342 201 464 342 204 464 minecraft:pink_terracotta
fill 342 201 467 342 217 467 minecraft:iron_block
fill 342 201 504 342 204 504 minecraft:pink_terracotta
setblock 344 201 463 minecraft:red_terracotta
fill 345 201 463 350 204 463 minecraft:pink_terracotta
setblock 345 201 465 minecraft:red_nether_bricks
setblock 346 201 464 minecraft:red_nether_bricks
fill 346 201 465 346 204 465 minecraft:pink_terracotta
setblock 346 201 504 minecraft:red_nether_bricks
fill 347 201 464 347 204 464 minecraft:pink_terracotta
setblock 347 201 503 minecraft:red_nether_bricks
fill 347 201 504 347 204 504 minecraft:pink_terracotta
fill 348 201 503 348 204 503 minecraft:pink_terracotta
setblock 349 201 466 minecraft:red_nether_bricks
setblock 350 201 465 minecraft:red_nether_bricks
fill 350 201 466 350 204 466 minecraft:pink_terracotta
setblock 351 201 463 minecraft:red_terracotta
setblock 351 201 464 minecraft:red_nether_bricks
fill 351 201 465 351 204 465 minecraft:pink_terracotta
setblock 351 201 504 minecraft:red_nether_bricks
fill 351 201 505 351 204 505 minecraft:pink_terracotta
fill 352 201 463 352 204 464 minecraft:pink_terracotta
setblock 352 201 503 minecraft:red_nether_bricks
fill 352 201 504 352 204 504 minecraft:pink_terracotta
setblock 352 201 505 minecraft:red_terracotta
fill 353 201 463 355 204 463 minecraft:pink_terracotta
setblock 353 201 502 minecraft:red_nether_bricks
fill 353 201 503 353 204 503 minecraft:pink_terracotta
fill 353 201 505 356 201 505 minecraft:pink_terracotta
setblock 355 201 465 minecraft:red_nether_bricks
setblock 356 201 464 minecraft:red_nether_bricks
setblock 356 201 504 minecraft:red_nether_bricks
fill 357 201 464 357 202 464 minecraft:pink_terracotta
fill 357 201 504 359 201 504 minecraft:pink_terracotta
setblock 357 201 505 minecraft:red_terracotta
fill 359 201 505 361 202 505 minecraft:pink_terracotta
fill 361 201 463 361 204 463 minecraft:pink_terracotta
setblock 362 201 463 minecraft:red_terracotta
setblock 362 201 505 minecraft:red_terracotta
fill 363 201 505 365 204 505 minecraft:pink_terracotta
setblock 366 201 505 minecraft:red_terracotta
fill 367 201 464 367 204 464 minecraft:pink_terracotta
fill 367 201 504 367 204 504 minecraft:pink_terracotta
setblock 368 201 482 minecraft:red_nether_bricks
fill 368 201 483 368 204 483 minecraft:pink_terracotta
setblock 368 201 486 minecraft:pink_terracotta
setblock 368 201 487 minecraft:red_nether_bricks
fill 368 201 488 368 203 489 minecraft:pink_terracotta
setblock 369 201 481 minecraft:red_nether_bricks
fill 369 201 482 369 204 482 minecraft:pink_terracotta
setblock 369 201 486 minecraft:red_nether_bricks
fill 369 201 487 369 204 487 minecraft:pink_terracotta
setblock 369 201 491 minecraft:red_nether_bricks
fill 369 201 492 369 204 492 minecraft:pink_terracotta
setblock 370 201 465 minecraft:red_nether_bricks
fill 370 201 466 371 204 466 minecraft:pink_terracotta
fill 370 201 468 370 201 469 minecraft:pink_terracotta
setblock 370 201 470 minecraft:red_nether_bricks
fill 370 201 471 370 204 471 minecraft:pink_terracotta
setblock 370 201 475 minecraft:red_nether_bricks
fill 370 201 476 370 204 476 minecraft:pink_terracotta
setblock 370 201 480 minecraft:red_nether_bricks
fill 370 201 481 370 204 481 minecraft:pink_terracotta
setblock 370 201 485 minecraft:red_nether_bricks
fill 370 201 486 371 204 486 minecraft:pink_terracotta
setblock 370 201 490 minecraft:red_nether_bricks
fill 370 201 491 370 204 491 minecraft:pink_terracotta
setblock 370 201 495 minecraft:red_nether_bricks
setblock 370 201 501 minecraft:pink_terracotta
fill 371 201 467 371 201 468 minecraft:red_terracotta
fill 371 201 470 371 205 470 minecraft:pink_terracotta
setblock 371 201 471 minecraft:red_terracotta
fill 371 201 487 371 201 488 minecraft:pink_terracotta
setblock 371 201 489 minecraft:red_terracotta
fill 371 201 497 371 204 498 minecraft:pink_terracotta
setblock 371 201 499 minecraft:red_terracotta
fill 371 201 500 371 204 500 minecraft:pink_terracotta
setblock 329 202 478 minecraft:red_terracotta
fill 329 202 479 329 204 491 minecraft:pink_terracotta
setblock 329 202 492 minecraft:red_terracotta
setblock 329 202 493 minecraft:pink_terracotta
setblock 329 202 494 minecraft:red_terracotta
fill 329 202 499 329 204 499 minecraft:pink_terracotta
setblock 330 202 463 minecraft:red_terracotta
setblock 330 202 464 minecraft:red_nether_bricks
fill 330 202 465 330 205 465 minecraft:pink_terracotta
setblock 330 202 469 minecraft:red_nether_bricks
fill 330 202 470 330 205 470 minecraft:pink_terracotta
setblock 330 202 474 minecraft:red_nether_bricks
fill 330 202 475 330 205 475 minecraft:pink_terracotta
setblock 330 202 479 minecraft:red_nether_bricks
fill 330 202 480 330 202 483 minecraft:pink_terracotta
setblock 330 202 484 minecraft:red_nether_bricks
fill 330 202 485 330 205 485 minecraft:pink_terracotta
setblock 330 202 489 minecraft:red_nether_bricks
fill 330 202 490 331 204 490 minecraft:pink_terracotta
setblock 330 202 504 minecraft:red_nether_bricks
setblock 330 202 505 minecraft:red_terracotta
fill 331 202 463 331 202 464 minecraft:pink_terracotta
setblock 331 202 468 minecraft:red_nether_bricks
fill 331 202 469 331 205 469 minecraft:pink_terracotta
setblock 331 202 473 minecraft:red_nether_bricks
fill 331 202 474 331 205 474 minecraft:pink_terracotta
setblock 331 202 478 minecraft:red_nether_bricks
fill 331 202 479 331 205 479 minecraft:pink_terracotta
setblock 331 202 483 minecraft:red_nether_bricks
fill 331 202 484 331 205 484 minecraft:pink_terracotta
setblock 331 202 488 minecraft:red_nether_bricks
fill 331 202 489 331 205 489 minecraft:pink_terracotta
fill 331 202 504 331 205 504 minecraft:pink_terracotta
fill 332 202 463 332 204 463 minecraft:pink_terracotta
setblock 332 202 467 minecraft:red_nether_bricks
fill 332 202 468 332 205 468 minecraft:pink_terracotta
fill 332 202 470 332 203 470 minecraft:pink_terracotta
setblock 333 202 466 minecraft:red_nether_bricks
setblock 334 202 463 minecraft:red_terracotta
setblock 334 202 465 minecraft:red_nether_bricks
fill 334 202 466 334 205 466 minecraft:pink_terracotta
fill 334 202 505 334 203 505 minecraft:red_terracotta
fill 335 202 463 337 202 463 minecraft:pink_terracotta
setblock 335 202 464 minecraft:red_nether_bricks
fill 335 202 465 335 205 465 minecraft:pink_terracotta
setblock 335 202 504 minecraft:red_nether_bricks
fill 336 202 464 339 202 464 minecraft:pink_terracotta
fill 336 202 504 336 203 504 minecraft:pink_terracotta
setblock 337 202 505 minecraft:red_terracotta
fill 338 202 505 341 204 505 minecraft:pink_terracotta
setblock 339 202 465 minecraft:red_nether_bricks
setblock 340 202 464 minecraft:red_nether_bricks
fill 340 202 465 340 205 465 minecraft:pink_terracotta
fill 341 202 463 341 205 464 minecraft:pink_terracotta
setblock 342 202 505 minecraft:red_terracotta
fill 343 202 505 344 204 505 minecraft:pink_terracotta
fill 344 202 463 344 207 463 minecraft:pink_terracotta
setblock 344 202 465 minecraft:red_nether_bricks
setblock 345 202 464 minecraft:red_nether_bricks
fill 345 202 465 345 205 465 minecraft:pink_terracotta
setblock 345 202 504 minecraft:red_nether_bricks
fill 346 202 464 346 205 464 minecraft:pink_terracotta
setblock 346 202 503 minecraft:red_nether_bricks
fill 346 202 504 346 205 504 minecraft:pink_terracotta
fill 347 202 503 347 205 503 minecraft:pink_terracotta
setblock 348 202 466 minecraft:red_nether_bricks
setblock 349 202 465 minecraft:red_nether_bricks
fill 349 202 466 349 205 466 minecraft:pink_terracotta
setblock 350 202 464 minecraft:red_nether_bricks
fill 350 202 465 350 205 465 minecraft:pink_terracotta
setblock 350 202 504 minecraft:red_nether_bricks
fill 351 202 463 351 204 464 minecraft:pink_terracotta
setblock 351 202 503 minecraft:red_nether_bricks
fill 351 202 504 351 205 504 minecraft:pink_terracotta
fill 352 202 503 352 205 503 minecraft:pink_terracotta
fill 352 202 505 352 204 505 minecraft:pink_terracotta
setblock 353 202 505 minecraft:red_terracotta
setblock 354 202 465 minecraft:red_nether_bricks
fill 354 202 505 357 202 505 minecraft:pink_terracotta
setblock 355 202 464 minecraft:red_nether_bricks
setblock 355 202 504 minecraft:red_nether_bricks
fill 356 202 464 356 205 464 minecraft:pink_terracotta
fill 356 202 504 358 202 504 minecraft:pink_terracotta
setblock 359 202 463 minecraft:red_terracotta
fill 362 202 463 362 204 463 minecraft:pink_terracotta
fill 362 202 505 362 204 505 minecraft:pink_terracotta
fill 366 202 464 366 205 464 minecraft:pink_terracotta
fill 366 202 505 366 204 505 minecraft:pink_terracotta
fill 368 202 482 368 205 482 minecraft:pink_terracotta
setblock 368 202 486 minecraft:red_nether_bricks
fill 368 202 487 368 205 487 minecraft:pink_terracotta
setblock 368 202 490 minecraft:pink_terracotta
setblock 369 202 465 minecraft:red_nether_bricks
fill 369 202 466 369 203 468 minecraft:pink_terracotta
setblock 369 202 480 minecraft:red_nether_bricks
fill 369 202 481 369 205 481 minecraft:pink_terracotta
setblock 369 202 485 minecraft:red_nether_bricks
fill 369 202 486 369 205 486 minecraft:pink_terracotta
setblock 369 202 490 minecraft:red_nether_bricks
fill 369 202 491 369 205 491 minecraft:pink_terracotta
setblock 370 202 464 minecraft:red_nether_bricks
fill 370 202 465 370 205 465 minecraft:pink_terracotta
fill 370 202 468 371 202 468 minecraft:pink_terracotta
setblock 370 202 469 minecraft:red_nether_bricks
fill 370 202 470 370 205 470 minecraft:pink_terracotta
setblock 370 202 474 minecraft:red_nether_bricks
fill 370 202 475 370 205 475 minecraft:pink_terracotta
setblock 370 202 479 minecraft:red_nether_bricks
fill 370 202 480 370 205 480 minecraft:pink_terracotta
setblock 370 202 484 minecraft:red_nether_bricks
fill 370 202 485 370 205 485 minecraft:pink_terracotta
setblock 370 202 489 minecraft:red_nether_bricks
fill 370 202 490 370 205 490 minecraft:pink_terracotta
setblock 370 202 494 minecraft:red_nether_bricks
fill 370 202 495 370 205 495 minecraft:pink_terracotta
setblock 370 202 504 minecraft:red_nether_bricks
fill 371 202 467 371 204 467 minecraft:pink_terracotta
fill 371 202 471 371 204 473 minecraft:pink_terracotta
setblock 371 202 474 minecraft:red_terracotta
fill 371 202 487 371 204 487 minecraft:pink_terracotta
setblock 371 202 488 minecraft:red_terracotta
fill 371 202 489 371 204 489 minecraft:pink_terracotta
setblock 371 202 499 minecraft:pink_terracotta
setblock 371 202 504 minecraft:red_terracotta
setblock 329 203 463 minecraft:red_terracotta
fill 329 203 464 331 204 464 minecraft:pink_terracotta
setblock 329 203 465 minecraft:red_terracotta
fill 329 203 466 329 204 467 minecraft:pink_terracotta
fill 329 203 469 329 204 471 minecraft:pink_terracotta
setblock 329 203 472 minecraft:red_terracotta
fill 329 203 473 329 204 473 minecraft:pink_terracotta
setblock 329 203 476 minecraft:red_terracotta
fill 329 203 477 329 204 478 minecraft:pink_terracotta
fill 329 203 492 329 204 492 minecraft:pink_terracotta
setblock 329 203 493 minecraft:red_terracotta
fill 329 203 494 329 204 494 minecraft:pink_terracotta
fill 329 203 500 329 204 501 minecraft:pink_terracotta
setblock 329 203 502 minecraft:red_terracotta
fill 329 203 503 329 204 503 minecraft:pink_terracotta
fill 330 203 463 330 205 463 minecraft:pink_terracotta
setblock 330 203 468 minecraft:red_nether_bricks
fill 330 203 469 330 206 469 minecraft:pink_terracotta
setblock 330 203 473 minecraft:red_nether_bricks
fill 330 203 474 330 206 474 minecraft:pink_terracotta
setblock 330 203 478 minecraft:red_nether_bricks
fill 330 203 479 330 203 482 minecraft:pink_terracotta
setblock 330 203 483 minecraft:red_nether_bricks
fill 330 203 484 330 206 484 minecraft:pink_terracotta
setblock 330 203 488 minecraft:red_nether_bricks
fill 330 203 489 330 206 489 minecraft:pink_terracotta
setblock 330 203 493 minecraft:red_nether_bricks
setblock 330 203 503 minecraft:red_nether_bricks
fill 330 203 504 330 205 505 minecraft:pink_terracotta
setblock 331 203 463 minecraft:red_terracotta
setblock 331 203 467 minecraft:red_nether_bricks
fill 331 203 468 331 206 468 minecraft:pink_terracotta
setblock 331 203 472 minecraft:red_nether_bricks
fill 331 203 473 331 206 473 minecraft:pink_terracotta
setblock 331 203 477 minecraft:red_nether_bricks
fill 331 203 478 331 206 478 minecraft:pink_terracotta
setblock 331 203 482 minecraft:red_nether_bricks
fill 331 203 483 331 206 483 minecraft:pink_terracotta
setblock 331 203 487 minecraft:red_nether_bricks
fill 331 203 488 331 206 488 minecraft:pink_terracotta
setblock 332 203 466 minecraft:red_nether_bricks
fill 332 203 467 332 206 467 minecraft:pink_terracotta
setblock 332 203 471 minecraft:red_nether_bricks
setblock 333 203 465 minecraft:red_nether_bricks
fill 333 203 466 333 206 466 minecraft:pink_terracotta
fill 334 203 463 335 204 463 minecraft:pink_terracotta
setblock 334 203 464 minecraft:red_nether_bricks
fill 334 203 465 334 206 465 minecraft:pink_terracotta
setblock 334 203 504 minecraft:red_nether_bricks
fill 335 203 464 338 203 464 minecraft:pink_terracotta
fill 335 203 504 335 205 504 minecraft:pink_terracotta
setblock 336 203 463 minecraft:red_terracotta
fill 337 203 463 337 204 463 minecraft:pink_terracotta
fill 337 203 505 337 204 505 minecraft:pink_terracotta
setblock 338 203 465 minecraft:red_nether_bricks
setblock 339 203 463 minecraft:red_terracotta
setblock 339 203 464 minecraft:red_nether_bricks
fill 339 203 465 339 206 465 minecraft:pink_terracotta
fill 340 203 463 340 204 464 minecraft:pink_terracotta
setblock 340 203 504 minecraft:white_concrete
fill 342 203 505 342 204 505 minecraft:pink_terracotta
setblock 343 203 465 minecraft:red_nether_bricks
setblock 344 203 464 minecraft:red_nether_bricks
fill 344 203 465 344 206 465 minecraft:pink_terracotta
setblock 344 203 504 minecraft:red_nether_bricks
fill 345 203 464 345 206 464 minecraft:pink_terracotta
fill 345 203 504 345 206 504 minecraft:pink_terracotta
setblock 346 203 466 minecraft:pink_terracotta
fill 346 203 503 346 206 503 minecraft:pink_terracotta
fill 346 203 505 347 203 505 minecraft:red_terracotta
setblock 347 203 466 minecraft:red_nether_bricks
setblock 348 203 465 minecraft:red_nether_bricks
fill 348 203 466 348 206 466 minecraft:pink_terracotta
fill 348 203 505 349 204 505 minecraft:pink_terracotta
setblock 349 203 464 minecraft:red_nether_bricks
fill 349 203 465 349 206 465 minecraft:pink_terracotta
setblock 349 203 504 minecraft:red_nether_bricks
fill 350 203 464 350 206 464 minecraft:pink_terracotta
setblock 350 203 503 minecraft:red_nether_bricks
fill 350 203 504 350 206 504 minecraft:pink_terracotta
setblock 350 203 505 minecraft:red_terracotta
fill 351 203 503 351 206 503 minecraft:pink_terracotta
setblock 353 203 465 minecraft:red_nether_bricks
fill 353 203 505 355 204 505 minecraft:pink_terracotta
setblock 354 203 464 minecraft:red_nether_bricks
fill 354 203 465 354 204 465 minecraft:pink_terracotta
setblock 354 203 504 minecraft:red_nether_bricks
fill 355 203 464 355 206 464 minecraft:pink_terracotta
fill 355 203 504 357 203 504 minecraft:pink_terracotta
fill 356 203 505 359 203 505 minecraft:red_terracotta
fill 359 203 463 359 204 463 minecraft:pink_terracotta
setblock 359 203 504 minecraft:white_concrete
setblock 360 203 463 minecraft:red_terracotta
setblock 360 203 464 minecraft:white_concrete
fill 360 203 505 361 204 505 minecraft:pink_terracotta
setblock 366 203 463 minecraft:red_terracotta
fill 367 203 463 370 204 463 minecraft:pink_terracotta
setblock 368 203 465 minecraft:red_nether_bricks
setblock 368 203 485 minecraft:red_nether_bricks
fill 368 203 486 368 206 486 minecraft:pink_terracotta
setblock 368 203 490 minecraft:red_nether_bricks
fill 368 203 491 368 206 491 minecraft:pink_terracotta
setblock 369 203 464 minecraft:red_nether_bricks
fill 369 203 465 369 206 465 minecraft:pink_terracotta
setblock 369 203 469 minecraft:red_nether_bricks
fill 369 203 470 369 205 471 minecraft:pink_terracotta
setblock 369 203 478 minecraft:pink_terracotta
setblock 369 203 479 minecraft:red_nether_bricks
fill 369 203 480 369 206 480 minecraft:pink_terracotta
setblock 369 203 484 minecraft:red_nether_bricks
fill 369 203 485 369 206 485 minecraft:pink_terracotta
setblock 369 203 489 minecraft:red_nether_bricks
fill 369 203 490 369 206 490 minecraft:pink_terracotta
setblock 369 203 493 minecraft:pink_terracotta
setblock 369 203 504 minecraft:red_nether_bricks
fill 370 203 464 370 206 464 minecraft:pink_terracotta
setblock 370 203 468 minecraft:red_nether_bricks
fill 370 203 469 370 206 469 minecraft:pink_terracotta
setblock 370 203 473 minecraft:red_nether_bricks
fill 370 203 474 371 204 474 minecraft:pink_terracotta
setblock 370 203 478 minecraft:red_nether_bricks
fill 370 203 479 370 206 479 minecraft:pink_terracotta
setblock 370 203 483 minecraft:red_nether_bricks
fill 370 203 484 370 206 484 minecraft:pink_terracotta
setblock 370 203 488 minecraft:red_nether_bricks
fill 370 203 489 370 206 489 minecraft:pink_terracotta
setblock 370 203 493 minecraft:red_nether_bricks
fill 370 203 494 370 206 494 minecraft:pink_terracotta
fill 370 203 496 370 204 496 minecraft:pink_terracotta
setblock 370 203 498 minecraft:white_concrete
setblock 370 203 503 minecraft:red_nether_bricks
fill 370 203 504 371 204 504 minecraft:pink_terracotta
setblock 370 203 505 minecraft:red_terracotta
setblock 371 203 463 minecraft:red_terracotta
setblock 371 203 468 minecraft:red_terracotta
fill 371 203 488 371 204 488 minecraft:pink_terracotta
setblock 371 203 490 minecraft:red_terracotta
setblock 371 203 495 minecraft:red_terracotta
setblock 371 203 499 minecraft:red_terracotta
setblock 371 203 502 minecraft:red_terracotta
fill 371 203 505 371 205 505 minecraft:pink_terracotta
setblock 329 204 463 minecraft:pink_terracotta
setblock 329 204 465 minecraft:pink_terracotta
setblock 329 204 472 minecraft:pink_terracotta
fill 329 204 476 329 205 476 minecraft:pink_terracotta
fill 329 204 493 330 204 493 minecraft:pink_terracotta
setblock 329 204 502 minecraft:pink_terracotta
setblock 330 204 467 minecraft:red_nether_bricks
fill 330 204 468 330 207 468 minecraft:pink_terracotta
setblock 330 204 472 minecraft:red_nether_bricks
fill 330 204 473 330 207 473 minecraft:pink_terracotta
setblock 330 204 477 minecraft:red_nether_bricks
fill 330 204 478 330 204 481 minecraft:pink_terracotta
setblock 330 204 482 minecraft:red_nether_bricks
fill 330 204 483 330 207 483 minecraft:pink_terracotta
setblock 330 204 487 minecraft:red_nether_bricks
fill 330 204 488 330 207 488 minecraft:pink_terracotta
setblock 330 204 492 minecraft:red_nether_bricks
fill 330 204 494 330 206 494 minecraft:pink_terracotta
setblock 330 204 495 minecraft:white_concrete
fill 330 204 503 330 207 503 minecraft:pink_terracotta
setblock 331 204 463 minecraft:pink_terracotta
setblock 331 204 466 minecraft:red_nether_bricks
fill 331 204 467 331 207 467 minecraft:pink_terracotta
setblock 331 204 471 minecraft:red_nether_bricks
fill 331 204 472 332 206 472 minecraft:pink_terracotta
setblock 331 204 476 minecraft:red_nether_bricks
fill 331 204 477 331 207 477 minecraft:pink_terracotta
setblock 331 204 481 minecraft:red_nether_bricks
fill 331 204 482 331 206 482 minecraft:pink_terracotta
setblock 331 204 486 minecraft:red_nether_bricks
fill 331 204 487 331 207 487 minecraft:pink_terracotta
setblock 331 204 491 minecraft:red_nether_bricks
setblock 332 204 465 minecraft:red_nether_bricks
fill 332 204 466 332 207 466 minecraft:pink_terracotta
setblock 332 204 470 minecraft:red_nether_bricks
fill 332 204 471 332 207 471 minecraft:pink_terracotta
setblock 333 204 464 minecraft:red_nether_bricks
fill 333 204 465 333 207 465 minecraft:pink_terracotta
setblock 333 204 504 minecraft:red_nether_bricks
fill 334 204 464 337 204 464 minecraft:pink_terracotta
fill 334 204 504 334 204 505 minecraft:pink_terracotta
setblock 336 204 463 minecraft:pink_terracotta
setblock 336 204 466 minecraft:red_nether_bricks
setblock 337 204 465 minecraft:red_nether_bricks
setblock 338 204 464 minecraft:red_nether_bricks
fill 338 204 465 338 207 465 minecraft:pink_terracotta
fill 339 204 463 339 205 464 minecraft:pink_terracotta
fill 341 204 504 341 205 504 minecraft:pink_terracotta
setblock 342 204 465 minecraft:red_nether_bricks
setblock 343 204 464 minecraft:red_nether_bricks
fill 343 204 465 343 207 465 minecraft:pink_terracotta
setblock 343 204 504 minecraft:red_nether_bricks
fill 344 204 464 344 207 464 minecraft:pink_terracotta
fill 344 204 504 344 207 504 minecraft:pink_terracotta
setblock 345 204 466 minecraft:pink_terracotta
fill 345 204 503 345 207 503 minecraft:pink_terracotta
setblock 346 204 466 minecraft:red_nether_bricks
fill 346 204 505 347 204 505 minecraft:pink_terracotta
setblock 347 204 465 minecraft:red_nether_bricks
fill 347 204 466 347 207 466 minecraft:pink_terracotta
setblock 348 204 464 minecraft:red_nether_bricks
fill 348 204 465 348 207 465 minecraft:pink_terracotta
setblock 348 204 504 minecraft:red_nether_bricks
fill 349 204 464 349 207 464 minecraft:pink_terracotta
setblock 349 204 503 minecraft:red_nether_bricks
fill 349 204 504 349 207 504 minecraft:pink_terracotta
fill 350 204 503 350 207 503 minecraft:pink_terracotta
setblock 350 204 505 minecraft:pink_terracotta
setblock 351 204 466 minecraft:red_nether_bricks
setblock 352 204 465 minecraft:red_nether_bricks
setblock 353 204 464 minecraft:red_nether_bricks
fill 353 204 465 353 207 465 minecraft:pink_terracotta
setblock 353 204 504 minecraft:red_nether_bricks
fill 354 204 464 354 207 464 minecraft:pink_terracotta
setblock 354 204 503 minecraft:red_nether_bricks
fill 354 204 504 356 205 504 minecraft:pink_terracotta
fill 356 204 505 359 204 505 minecraft:pink_terracotta
setblock 360 204 463 minecraft:pink_terracotta
fill 365 204 464 365 206 464 minecraft:pink_terracotta
setblock 365 204 504 minecraft:white_concrete
setblock 366 204 463 minecraft:pink_terracotta
setblock 367 204 465 minecraft:red_nether_bricks
fill 367 204 486 367 205 488 minecraft:pink_terracotta
setblock 368 204 464 minecraft:red_nether_bricks
fill 368 204 465 368 207 465 minecraft:pink_terracotta
setblock 368 204 484 minecraft:red_nether_bricks
fill 368 204 485 368 207 485 minecraft:pink_terracotta
setblock 368 204 488 minecraft:pink_terracotta
setblock 368 204 489 minecraft:red_nether_bricks
fill 368 204 490 368 207 490 minecraft:pink_terracotta
fill 368 204 492 368 205 492 minecraft:pink_terracotta
setblock 368 204 504 minecraft:red_nether_bricks
fill 369 204 464 369 207 464 minecraft:pink_terracotta
fill 369 204 466 369 204 467 minecraft:pink_terracotta
setblock 369 204 468 minecraft:red_nether_bricks
fill 369 204 469 369 207 469 minecraft:pink_terracotta
setblock 369 204 472 minecraft:pink_terracotta
setblock 369 204 473 minecraft:red_nether_bricks
fill 369 204 474 369 204 477 minecraft:pink_terracotta
setblock 369 204 478 minecraft:red_nether_bricks
fill 369 204 479 369 207 479 minecraft:pink_terracotta
setblock 369 204 483 minecraft:red_nether_bricks
fill 369 204 484 369 207 484 minecraft:pink_terracotta
setblock 369 204 488 minecraft:red_nether_bricks
fill 369 204 489 369 207 489 minecraft:pink_terracotta
setblock 369 204 493 minecraft:red_nether_bricks
fill 369 204 494 369 207 494 minecraft:pink_terracotta
fill 369 204 504 369 207 504 minecraft:pink_terracotta
setblock 370 204 467 minecraft:red_nether_bricks
fill 370 204 468 371 204 468 minecraft:pink_terracotta
setblock 370 204 472 minecraft:red_nether_bricks
fill 370 204 473 370 207 473 minecraft:pink_terracotta
setblock 370 204 477 minecraft:red_nether_bricks
fill 370 204 478 370 207 478 minecraft:pink_terracotta
setblock 370 204 482 minecraft:red_nether_bricks
fill 370 204 483 370 207 483 minecraft:pink_terracotta
setblock 370 204 487 minecraft:red_nether_bricks
fill 370 204 488 370 207 488 minecraft:pink_terracotta
setblock 370 204 492 minecraft:red_nether_bricks
fill 370 204 493 370 207 493 minecraft:pink_terracotta
fill 370 204 503 370 206 503 minecraft:pink_terracotta
setblock 370 204 505 minecraft:pink_terracotta
setblock 371 204 463 minecraft:pink_terracotta
setblock 371 204 490 minecraft:pink_terracotta
setblock 371 204 495 minecraft:pink_terracotta
setblock 371 204 499 minecraft:pink_terracotta
setblock 371 204 502 minecraft:pink_terracotta
fill 329 205 463 329 206 475 minecraft:red_terracotta
fill 329 205 477 329 206 481 minecraft:red_terracotta
fill 329 205 482 330 205 482 minecraft:pink_terracotta
fill 329 205 483 329 205 485 minecraft:red_terracotta
setblock 329 205 486 minecraft:pink_terracotta
fill 329 205 487 329 307 489 minecraft:red_terracotta
fill 329 205 490 330 205 490 minecraft:pink_terracotta
fill 329 205 491 329 307 494 minecraft:red_terracotta
fill 329 205 496 329 307 497 minecraft:red_terracotta
fill 329 205 499 329 205 505 minecraft:red_terracotta
fill 330 205 464 331 205 464 minecraft:pink_terracotta
setblock 330 205 466 minecraft:red_nether_bricks
fill 330 205 467 330 208 467 minecraft:pink_terracotta
setblock 330 205 471 minecraft:red_nether_bricks
fill 330 205 472 330 208 472 minecraft:pink_terracotta
setblock 330 205 476 minecraft:red_nether_bricks
fill 330 205 477 330 205 480 minecraft:pink_terracotta
setblock 330 205 481 minecraft:red_nether_bricks
setblock 330 205 486 minecraft:red_nether_bricks
fill 330 205 487 330 208 487 minecraft:pink_terracotta
setblock 330 205 491 minecraft:red_nether_bricks
fill 330 205 492 330 207 493 minecraft:pink_terracotta
setblock 330 205 495 minecraft:pink_terracotta
setblock 330 205 501 minecraft:white_concrete
fill 331 205 463 338 307 463 minecraft:red_terracotta
setblock 331 205 465 minecraft:red_nether_bricks
fill 331 205 466 331 208 466 minecraft:pink_terracotta
setblock 331 205 470 minecraft:red_nether_bricks
fill 331 205 471 331 208 471 minecraft:pink_terracotta
setblock 331 205 475 minecraft:red_nether_bricks
fill 331 205 476 331 208 476 minecraft:pink_terracotta
setblock 331 205 480 minecraft:red_nether_bricks
setblock 331 205 481 minecraft:pink_terracotta
setblock 331 205 485 minecraft:red_nether_bricks
fill 331 205 486 331 208 486 minecraft:pink_terracotta
setblock 331 205 490 minecraft:red_nether_bricks
fill 331 205 491 331 207 492 minecraft:pink_terracotta
fill 331 205 505 331 307 505 minecraft:red_terracotta
setblock 332 205 464 minecraft:red_nether_bricks
fill 332 205 465 332 208 465 minecraft:pink_terracotta
setblock 332 205 469 minecraft:red_nether_bricks
fill 332 205 470 332 208 470 minecraft:pink_terracotta
setblock 332 205 504 minecraft:red_nether_bricks
setblock 332 205 505 minecraft:pink_terracotta
fill 333 205 464 336 205 464 minecraft:pink_terracotta
setblock 333 205 467 minecraft:pink_terracotta
fill 333 205 504 334 207 504 minecraft:pink_terracotta
fill 333 205 505 344 205 505 minecraft:red_terracotta
setblock 335 205 466 minecraft:red_nether_bricks
setblock 336 205 465 minecraft:red_nether_bricks
fill 336 205 466 336 207 466 minecraft:pink_terracotta
setblock 337 205 464 minecraft:red_nether_bricks
fill 337 205 465 337 208 465 minecraft:pink_terracotta
fill 338 205 464 338 208 464 minecraft:pink_terracotta
fill 340 205 463 340 206 463 minecraft:red_terracotta
fill 340 205 464 340 206 464 minecraft:pink_terracotta
setblock 341 205 465 minecraft:red_nether_bricks
setblock 342 205 463 minecraft:pink_terracotta
setblock 342 205 464 minecraft:red_nether_bricks
fill 342 205 465 342 208 465 minecraft:pink_terracotta
setblock 342 205 504 minecraft:red_nether_bricks
setblock 343 205 463 minecraft:red_terracotta
fill 343 205 464 343 208 464 minecraft:pink_terracotta
fill 343 205 504 343 208 504 minecraft:pink_terracotta
setblock 344 205 466 minecraft:pink_terracotta
fill 345 205 463 349 307 463 minecraft:red_terracotta
setblock 345 205 466 minecraft:red_nether_bricks
setblock 346 205 465 minecraft:red_nether_bricks
fill 346 205 466 346 208 466 minecraft:pink_terracotta
setblock 346 205 505 minecraft:pink_terracotta
setblock 347 205 464 minecraft:red_nether_bricks
fill 347 205 465 347 208 465 minecraft:pink_terracotta
setblock 347 205 504 minecraft:red_nether_bricks
fill 347 205 505 357 205 505 minecraft:red_terracotta
fill 348 205 464 348 208 464 minecraft:pink_terracotta
setblock 348 205 503 minecraft:red_nether_bricks
fill 348 205 504 348 208 504 minecraft:pink_terracotta
fill 349 205 503 349 208 503 minecraft:pink_terracotta
fill 350 205 463 350 206 463 minecraft:pink_terracotta
setblock 350 205 466 minecraft:red_nether_bricks
fill 351 205 463 362 205 463 minecraft:red_terracotta
setblock 351 205 464 minecraft:pink_terracotta
setblock 351 205 465 minecraft:red_nether_bricks
fill 351 205 466 351 206 466 minecraft:pink_terracotta
setblock 352 205 464 minecraft:red_nether_bricks
fill 352 205 465 352 208 465 minecraft:pink_terracotta
setblock 352 205 504 minecraft:red_nether_bricks
fill 353 205 464 353 208 464 minecraft:pink_terracotta
setblock 353 205 503 minecraft:red_nether_bricks
fill 353 205 504 353 208 504 minecraft:pink_terracotta
setblock 358 205 505 minecraft:pink_terracotta
fill 359 205 505 370 205 505 minecraft:red_terracotta
fill 364 205 463 371 205 463 minecraft:red_terracotta
fill 364 205 464 364 207 464 minecraft:pink_terracotta
setblock 366 205 465 minecraft:red_nether_bricks
setblock 367 205 464 minecraft:red_nether_bricks
fill 367 205 465 367 208 465 minecraft:pink_terracotta
fill 367 205 485 367 208 485 minecraft:pink_terracotta
setblock 367 205 489 minecraft:red_nether_bricks
fill 367 205 490 367 208 490 minecraft:pink_terracotta
setblock 367 205 504 minecraft:red_nether_bricks
fill 368 205 464 368 208 464 minecraft:pink_terracotta
setblock 368 205 467 minecraft:pink_terracotta
setblock 368 205 468 minecraft:red_nether_bricks
fill 368 205 469 368 207 470 minecraft:pink_terracotta
setblock 368 205 483 minecraft:red_nether_bricks
fill 368 205 484 368 208 484 minecraft:pink_terracotta
setblock 368 205 488 minecraft:red_nether_bricks
fill 368 205 489 368 208 489 minecraft:pink_terracotta
setblock 368 205 493 minecraft:red_nether_bricks
fill 368 205 504 368 208 504 minecraft:pink_terracotta
setblock 369 205 466 minecraft:pink_terracotta
setblock 369 205 467 minecraft:red_nether_bricks
fill 369 205 468 370 207 468 minecraft:pink_terracotta
setblock 369 205 472 minecraft:red_nether_bricks
fill 369 205 473 369 205 476 minecraft:pink_terracotta
setblock 369 205 477 minecraft:red_nether_bricks
fill 369 205 478 369 208 478 minecraft:pink_terracotta
setblock 369 205 482 minecraft:red_nether_bricks
fill 369 205 483 369 208 483 minecraft:pink_terracotta
setblock 369 205 487 minecraft:red_nether_bricks
fill 369 205 488 369 208 488 minecraft:pink_terracotta
setblock 369 205 492 minecraft:red_nether_bricks
fill 369 205 493 369 208 493 minecraft:pink_terracotta
fill 369 205 495 369 206 495 minecraft:pink_terracotta
setblock 370 205 466 minecraft:red_nether_bricks
fill 370 205 467 370 208 467 minecraft:pink_terracotta
setblock 370 205 471 minecraft:red_nether_bricks
fill 370 205 472 370 208 472 minecraft:pink_terracotta
fill 370 205 474 370 206 474 minecraft:pink_terracotta
setblock 370 205 476 minecraft:red_nether_bricks
fill 370 205 477 370 208 477 minecraft:pink_terracotta
setblock 370 205 481 minecraft:red_nether_bricks
fill 370 205 482 370 208 482 minecraft:pink_terracotta
setblock 370 205 486 minecraft:red_nether_bricks
fill 370 205 487 370 208 487 minecraft:pink_terracotta
setblock 370 205 491 minecraft:red_nether_bricks
fill 370 205 492 370 208 492 minecraft:pink_terracotta
setblock 370 205 496 minecraft:red_nether_bricks
fill 370 205 497 370 208 497 minecraft:pink_terracotta
fill 370 205 504 370 206 504 minecraft:pink_terracotta
fill 371 205 464 371 307 469 minecraft:red_terracotta
fill 371 205 471 371 205 479 minecraft:red_terracotta
setblock 371 205 480 minecraft:pink_terracotta
fill 371 205 481 371 307 481 minecraft:red_terracotta
fill 371 205 483 371 205 504 minecraft:red_terracotta
fill 329 206 476 329 307 476 minecraft:red_terracotta
fill 329 206 482 329 307 483 minecraft:red_terracotta
fill 329 206 484 329 207 484 minecraft:pink_terracotta
fill 329 206 485 329 307 486 minecraft:red_terracotta
fill 329 206 490 329 307 490 minecraft:red_terracotta
fill 329 206 495 329 307 495 minecraft:red_terracotta
fill 329 206 498 329 307 504 minecraft:red_terracotta
setblock 329 206 505 minecraft:pink_terracotta
fill 330 206 463 330 307 463 minecraft:red_terracotta
setblock 330 206 464 minecraft:pink_terracotta
setblock 330 206 465 minecraft:red_nether_bricks
fill 330 206 466 330 209 466 minecraft:pink_terracotta
setblock 330 206 470 minecraft:red_nether_bricks
fill 330 206 471 330 209 471 minecraft:pink_terracotta
setblock 330 206 475 minecraft:red_nether_bricks
fill 330 206 476 330 206 479 minecraft:pink_terracotta
setblock 330 206 480 minecraft:red_nether_bricks
fill 330 206 481 330 208 482 minecraft:pink_terracotta
setblock 330 206 485 minecraft:red_nether_bricks
fill 330 206 486 330 209 486 minecraft:pink_terracotta
setblock 330 206 490 minecraft:red_nether_bricks
fill 330 206 491 330 209 491 minecraft:pink_terracotta
setblock 330 206 495 minecraft:red_nether_bricks
fill 330 206 496 330 209 496 minecraft:pink_terracotta
fill 330 206 502 330 208 502 minecraft:pink_terracotta
setblock 330 206 504 minecraft:pink_terracotta
fill 330 206 505 330 307 505 minecraft:red_terracotta
setblock 331 206 464 minecraft:red_nether_bricks
fill 331 206 465 331 209 465 minecraft:pink_terracotta
setblock 331 206 469 minecraft:red_nether_bricks
fill 331 206 470 331 209 470 minecraft:pink_terracotta
setblock 331 206 474 minecraft:red_nether_bricks
fill 331 206 475 331 209 475 minecraft:pink_terracotta
setblock 331 206 484 minecraft:red_nether_bricks
fill 331 206 485 331 207 485 minecraft:pink_terracotta
setblock 331 206 489 minecraft:red_nether_bricks
fill 331 206 490 331 209 490 minecraft:pink_terracotta
setblock 331 206 504 minecraft:red_nether_bricks
fill 332 206 464 335 206 464 minecraft:pink_terracotta
setblock 332 206 468 minecraft:red_nether_bricks
fill 332 206 469 333 208 469 minecraft:pink_terracotta
setblock 332 206 473 minecraft:red_nether_bricks
fill 332 206 504 332 209 504 minecraft:pink_terracotta
fill 332 206 505 338 307 505 minecraft:red_terracotta
setblock 333 206 467 minecraft:red_nether_bricks
fill 333 206 468 333 208 468 minecraft:pink_terracotta
setblock 334 206 466 minecraft:red_nether_bricks
setblock 335 206 465 minecraft:red_nether_bricks
fill 335 206 466 335 208 466 minecraft:pink_terracotta
setblock 336 206 464 minecraft:red_nether_bricks
fill 336 206 465 336 209 465 minecraft:pink_terracotta
fill 337 206 464 337 209 464 minecraft:pink_terracotta
fill 339 206 463 339 307 463 minecraft:red_terracotta
fill 339 206 464 339 207 464 minecraft:pink_terracotta
setblock 339 206 504 minecraft:white_concrete
setblock 339 206 505 minecraft:pink_terracotta
setblock 340 206 465 minecraft:red_nether_bricks
setblock 340 206 504 minecraft:pink_terracotta
fill 340 206 505 354 206 505 minecraft:red_terracotta
setblock 341 206 463 minecraft:pink_terracotta
setblock 341 206 464 minecraft:red_nether_bricks
fill 341 206 465 341 209 465 minecraft:pink_terracotta
setblock 341 206 504 minecraft:red_nether_bricks
fill 342 206 463 342 307 463 minecraft:red_terracotta
fill 342 206 464 342 209 464 minecraft:pink_terracotta
fill 342 206 466 343 206 466 minecraft:pink_terracotta
fill 342 206 504 342 209 504 minecraft:pink_terracotta
fill 343 206 463 343 207 463 minecraft:pink_terracotta
setblock 344 206 466 minecraft:red_nether_bricks
fill 344 206 503 344 208 503 minecraft:pink_terracotta
setblock 345 206 465 minecraft:red_nether_bricks
fill 345 206 466 345 209 466 minecraft:pink_terracotta
setblock 346 206 464 minecraft:red_nether_bricks
fill 346 206 465 346 209 465 minecraft:pink_terracotta
setblock 346 206 504 minecraft:red_nether_bricks
fill 347 206 464 347 209 464 minecraft:pink_terracotta
setblock 347 206 503 minecraft:red_nether_bricks
fill 347 206 504 347 209 504 minecraft:pink_terracotta
setblock 348 206 502 minecraft:red_nether_bricks
fill 348 206 503 348 209 503 minecraft:pink_terracotta
setblock 349 206 466 minecraft:red_nether_bricks
fill 349 206 502 349 208 502 minecraft:pink_terracotta
setblock 350 206 465 minecraft:red_nether_bricks
fill 350 206 466 350 208 466 minecraft:pink_terracotta
setblock 351 206 463 minecraft:pink_terracotta
setblock 351 206 464 minecraft:red_nether_bricks
fill 351 206 465 351 209 465 minecraft:pink_terracotta
setblock 351 206 504 minecraft:red_nether_bricks
fill 352 206 463 367 206 463 minecraft:red_terracotta
fill 352 206 464 352 209 464 minecraft:pink_terracotta
setblock 352 206 503 minecraft:red_nether_bricks
fill 352 206 504 352 209 504 minecraft:pink_terracotta
setblock 353 206 503 minecraft:pink_terracotta
fill 354 206 504 355 206 504 minecraft:pink_terracotta
setblock 355 206 505 minecraft:pink_terracotta
fill 356 206 505 361 307 505 minecraft:red_terracotta
setblock 358 206 504 minecraft:white_concrete
setblock 361 206 464 minecraft:white_concrete
setblock 362 206 505 minecraft:pink_terracotta
fill 363 206 505 365 307 505 minecraft:red_terracotta
setblock 365 206 465 minecraft:red_nether_bricks
setblock 366 206 464 minecraft:red_nether_bricks
fill 366 206 465 366 209 465 minecraft:pink_terracotta
setblock 366 206 504 minecraft:red_nether_bricks
setblock 366 206 505 minecraft:pink_terracotta
fill 367 206 464 367 209 464 minecraft:pink_terracotta
fill 367 206 466 368 206 466 minecraft:pink_terracotta
fill 367 206 486 367 206 487 minecraft:pink_terracotta
setblock 367 206 488 minecraft:red_nether_bricks
fill 367 206 489 367 209 489 minecraft:pink_terracotta
fill 367 206 491 367 207 491 minecraft:pink_terracotta
fill 367 206 504 367 209 504 minecraft:pink_terracotta
fill 367 206 505 369 307 505 minecraft:red_terracotta
setblock 368 206 463 minecraft:pink_terracotta
setblock 368 206 467 minecraft:red_nether_bricks
fill 368 206 468 368 209 468 minecraft:pink_terracotta
setblock 368 206 471 minecraft:pink_terracotta
setblock 368 206 472 minecraft:red_nether_bricks
fill 368 206 473 369 207 474 minecraft:pink_terracotta
setblock 368 206 481 minecraft:pink_terracotta
setblock 368 206 482 minecraft:red_nether_bricks
fill 368 206 483 368 209 483 minecraft:pink_terracotta
setblock 368 206 487 minecraft:red_nether_bricks
fill 368 206 488 368 209 488 minecraft:pink_terracotta
setblock 368 206 492 minecraft:red_nether_bricks
fill 368 206 493 368 208 494 minecraft:pink_terracotta
fill 369 206 463 371 307 463 minecraft:red_terracotta
setblock 369 206 466 minecraft:red_nether_bricks
fill 369 206 467 369 209 467 minecraft:pink_terracotta
setblock 369 206 470 minecraft:pink_terracotta
setblock 369 206 471 minecraft:red_nether_bricks
fill 369 206 472 369 209 472 minecraft:pink_terracotta
setblock 369 206 475 minecraft:pink_terracotta
setblock 369 206 476 minecraft:red_nether_bricks
fill 369 206 477 369 209 477 minecraft:pink_terracotta
setblock 369 206 481 minecraft:red_nether_bricks
fill 369 206 482 369 209 482 minecraft:pink_terracotta
setblock 369 206 486 minecraft:red_nether_bricks
fill 369 206 487 369 209 487 minecraft:pink_terracotta
setblock 369 206 491 minecraft:red_nether_bricks
fill 369 206 492 369 209 492 minecraft:pink_terracotta
setblock 369 206 496 minecraft:red_nether_bricks
setblock 370 206 465 minecraft:red_nether_bricks
fill 370 206 466 370 209 466 minecraft:pink_terracotta
setblock 370 206 470 minecraft:red_nether_bricks
fill 370 206 471 370 209 471 minecraft:pink_terracotta
setblock 370 206 475 minecraft:red_nether_bricks
fill 370 206 476 370 209 476 minecraft:pink_terracotta
setblock 370 206 480 minecraft:red_nether_bricks
fill 370 206 481 370 209 481 minecraft:pink_terracotta
setblock 370 206 485 minecraft:red_nether_bricks
fill 370 206 486 370 209 486 minecraft:pink_terracotta
setblock 370 206 490 minecraft:red_nether_bricks
fill 370 206 491 370 209 491 minecraft:pink_terracotta
setblock 370 206 495 minecraft:red_nether_bricks
fill 370 206 496 370 209 496 minecraft:pink_terracotta
fill 370 206 498 370 207 498 minecraft:pink_terracotta
setblock 370 206 499 minecraft:white_concrete
setblock 370 206 505 minecraft:pink_terracotta
fill 371 206 470 371 206 474 minecraft:red_terracotta
setblock 371 206 475 minecraft:pink_terracotta
fill 371 206 476 371 307 480 minecraft:red_terracotta
fill 371 206 482 371 206 483 minecraft:red_terracotta
setblock 371 206 484 minecraft:pink_terracotta
fill 371 206 485 371 206 491 minecraft:red_terracotta
setblock 371 206 492 minecraft:pink_terracotta
fill 371 206 493 371 206 499 minecraft:red_terracotta
setblock 371 206 500 minecraft:pink_terracotta
fill 371 206 501 371 307 502 minecraft:red_terracotta
fill 371 206 503 371 206 504 minecraft:pink_terracotta
fill 371 206 505 371 307 505 minecraft:red_terracotta
setblock 329 207 463 minecraft:pink_terracotta
fill 329 207 464 329 307 475 minecraft:red_terracotta
fill 329 207 477 329 307 478 minecraft:red_terracotta
setblock 329 207 479 minecraft:pink_terracotta
fill 329 207 480 329 307 481 minecraft:red_terracotta
fill 329 207 505 329 307 505 minecraft:red_terracotta
setblock 330 207 464 minecraft:red_nether_bricks
fill 330 207 465 330 210 465 minecraft:pink_terracotta
setblock 330 207 469 minecraft:red_nether_bricks
fill 330 207 470 330 210 470 minecraft:pink_terracotta
setblock 330 207 474 minecraft:red_nether_bricks
fill 330 207 475 330 207 478 minecraft:pink_terracotta
setblock 330 207 479 minecraft:red_nether_bricks
fill 330 207 480 330 210 480 minecraft:pink_terracotta
setblock 330 207 484 minecraft:red_nether_bricks
fill 330 207 485 330 210 485 minecraft:pink_terracotta
setblock 330 207 489 minecraft:red_nether_bricks
fill 330 207 490 330 210 490 minecraft:pink_terracotta
setblock 330 207 494 minecraft:red_nether_bricks
fill 330 207 495 330 210 495 minecraft:pink_terracotta
fill 330 207 497 330 207 498 minecraft:pink_terracotta
setblock 330 207 504 minecraft:red_nether_bricks
fill 331 207 464 334 207 464 minecraft:pink_terracotta
setblock 331 207 468 minecraft:red_nether_bricks
fill 331 207 469 331 210 469 minecraft:pink_terracotta
setblock 331 207 472 minecraft:pink_terracotta
setblock 331 207 473 minecraft:red_nether_bricks
fill 331 207 474 332 209 474 minecraft:pink_terracotta
setblock 331 207 478 minecraft:red_nether_bricks
setblock 331 207 484 minecraft:pink_terracotta
setblock 331 207 488 minecraft:red_nether_bricks
fill 331 207 489 331 209 489 minecraft:pink_terracotta
setblock 331 207 493 minecraft:red_nether_bricks
fill 331 207 504 331 210 504 minecraft:pink_terracotta
setblock 332 207 467 minecraft:red_nether_bricks
fill 332 207 468 332 210 468 minecraft:pink_terracotta
setblock 332 207 472 minecraft:red_nether_bricks
fill 332 207 473 332 210 473 minecraft:pink_terracotta
setblock 332 207 482 minecraft:light[level=12]
setblock 332 207 490 minecraft:light[level=12]
setblock 332 207 498 minecraft:light[level=12]
setblock 333 207 466 minecraft:red_nether_bricks
setblock 333 207 467 minecraft:pink_terracotta
setblock 334 207 465 minecraft:red_nether_bricks
fill 334 207 466 334 209 466 minecraft:pink_terracotta
setblock 335 207 464 minecraft:red_nether_bricks
fill 335 207 465 335 210 465 minecraft:pink_terracotta
fill 336 207 464 336 210 464 minecraft:pink_terracotta
setblock 339 207 465 minecraft:red_nether_bricks
setblock 339 207 504 minecraft:pink_terracotta
fill 339 207 505 346 307 505 minecraft:red_terracotta
setblock 340 207 463 minecraft:pink_terracotta
setblock 340 207 464 minecraft:red_nether_bricks
fill 340 207 465 340 210 465 minecraft:pink_terracotta
setblock 340 207 466 minecraft:light[level=12]
setblock 340 207 474 minecraft:light[level=12]
setblock 340 207 482 minecraft:light[level=12]
setblock 340 207 490 minecraft:light[level=12]
setblock 340 207 498 minecraft:light[level=12]
setblock 340 207 504 minecraft:red_nether_bricks
fill 341 207 463 341 307 463 minecraft:red_terracotta
fill 341 207 464 341 210 464 minecraft:pink_terracotta
fill 341 207 504 341 210 504 minecraft:pink_terracotta
setblock 342 207 466 minecraft:pink_terracotta
setblock 343 207 466 minecraft:red_nether_bricks
fill 343 207 503 343 209 503 minecraft:pink_terracotta
setblock 344 207 465 minecraft:red_nether_bricks
fill 344 207 466 344 210 466 minecraft:pink_terracotta
setblock 345 207 464 minecraft:red_nether_bricks
fill 345 207 465 345 210 465 minecraft:pink_terracotta
setblock 345 207 504 minecraft:red_nether_bricks
fill 346 207 464 346 210 464 minecraft:pink_terracotta
setblock 346 207 503 minecraft:red_nether_bricks
fill 346 207 504 346 210 504 minecraft:pink_terracotta
setblock 347 207 502 minecraft:red_nether_bricks
fill 347 207 503 347 210 503 minecraft:pink_terracotta
setblock 347 207 505 minecraft:pink_terracotta
setblock 348 207 466 minecraft:red_nether_bricks
setblock 348 207 474 minecraft:light[level=12]
setblock 348 207 482 minecraft:light[level=12]
setblock 348 207 490 minecraft:light[level=12]
setblock 348 207 498 minecraft:light[level=12]
fill 348 207 502 348 210 502 minecraft:pink_terracotta
fill 348 207 505 348 307 505 minecraft:red_terracotta
setblock 349 207 465 minecraft:red_nether_bricks
fill 349 207 466 349 209 466 minecraft:pink_terracotta
setblock 349 207 505 minecraft:pink_terracotta
fill 350 207 463 357 307 463 minecraft:red_terracotta
setblock 350 207 464 minecraft:red_nether_bricks
fill 350 207 465 350 210 465 minecraft:pink_terracotta
setblock 350 207 504 minecraft:red_nether_bricks
fill 350 207 505 355 307 505 minecraft:red_terracotta
fill 351 207 464 351 210 464 minecraft:pink_terracotta
setblock 351 207 503 minecraft:red_nether_bricks
fill 351 207 504 351 210 504 minecraft:pink_terracotta
fill 352 207 503 352 208 503 minecraft:pink_terracotta
setblock 354 207 504 minecraft:pink_terracotta
setblock 355 207 464 minecraft:white_concrete
setblock 355 207 504 minecraft:red_nether_bricks
setblock 356 207 466 minecraft:light[level=12]
setblock 356 207 474 minecraft:light[level=12]
setblock 356 207 482 minecraft:light[level=12]
setblock 356 207 490 minecraft:light[level=12]
setblock 356 207 498 minecraft:light[level=12]
setblock 358 207 463 minecraft:pink_terracotta
fill 359 207 463 363 307 463 minecraft:red_terracotta
fill 362 207 505 362 307 505 minecraft:red_terracotta
fill 363 207 464 363 208 464 minecraft:pink_terracotta
setblock 364 207 463 minecraft:pink_terracotta
setblock 364 207 466 minecraft:light[level=12]
setblock 364 207 474 minecraft:light[level=12]
setblock 364 207 482 minecraft:light[level=12]
setblock 364 207 490 minecraft:light[level=12]
setblock 364 207 498 minecraft:light[level=12]
setblock 364 207 504 minecraft:white_concrete
fill 365 207 463 366 307 463 minecraft:red_terracotta
setblock 365 207 464 minecraft:red_nether_bricks
fill 365 207 465 365 210 465 minecraft:pink_terracotta
fill 366 207 464 366 210 464 minecraft:pink_terracotta
fill 366 207 504 366 210 504 minecraft:pink_terracotta
fill 366 207 505 366 307 505 minecraft:red_terracotta
setblock 367 207 463 minecraft:pink_terracotta
setblock 367 207 466 minecraft:pink_terracotta
setblock 367 207 486 minecraft:pink_terracotta
setblock 367 207 487 minecraft:red_nether_bricks
fill 367 207 488 367 210 488 minecraft:pink_terracotta
setblock 367 207 492 minecraft:red_nether_bricks
fill 368 207 463 368 307 463 minecraft:red_terracotta
setblock 368 207 466 minecraft:red_nether_bricks
fill 368 207 467 368 210 467 minecraft:pink_terracotta
setblock 368 207 471 minecraft:red_nether_bricks
fill 368 207 472 368 210 472 minecraft:pink_terracotta
setblock 368 207 475 minecraft:pink_terracotta
setblock 368 207 476 minecraft:red_nether_bricks
fill 368 207 477 368 207 480 minecraft:pink_terracotta
setblock 368 207 481 minecraft:red_nether_bricks
fill 368 207 482 368 210 482 minecraft:pink_terracotta
setblock 368 207 486 minecraft:red_nether_bricks
fill 368 207 487 368 210 487 minecraft:pink_terracotta
setblock 368 207 491 minecraft:red_nether_bricks
fill 368 207 492 368 210 492 minecraft:pink_terracotta
setblock 369 207 465 minecraft:red_nether_bricks
fill 369 207 466 369 210 466 minecraft:pink_terracotta
setblock 369 207 470 minecraft:red_nether_bricks
fill 369 207 471 369 210 471 minecraft:pink_terracotta
setblock 369 207 475 minecraft:red_nether_bricks
fill 369 207 476 369 210 476 minecraft:pink_terracotta
setblock 369 207 480 minecraft:red_nether_bricks
fill 369 207 481 369 210 481 minecraft:pink_terracotta
setblock 369 207 485 minecraft:red_nether_bricks
fill 369 207 486 369 210 486 minecraft:pink_terracotta
setblock 369 207 490 minecraft:red_nether_bricks
fill 369 207 491 369 210 491 minecraft:pink_terracotta
setblock 369 207 495 minecraft:red_nether_bricks
fill 369 207 496 369 210 496 minecraft:pink_terracotta
setblock 370 207 464 minecraft:red_nether_bricks
fill 370 207 465 370 210 465 minecraft:pink_terracotta
setblock 370 207 469 minecraft:red_nether_bricks
fill 370 207 470 370 210 470 minecraft:pink_terracotta
setblock 370 207 474 minecraft:red_nether_bricks
fill 370 207 475 370 210 475 minecraft:pink_terracotta
setblock 370 207 479 minecraft:red_nether_bricks
fill 370 207 480 370 210 480 minecraft:pink_terracotta
setblock 370 207 484 minecraft:red_nether_bricks
fill 370 207 485 370 210 485 minecraft:pink_terracotta
setblock 370 207 489 minecraft:red_nether_bricks
fill 370 207 490 370 210 490 minecraft:pink_terracotta
setblock 370 207 494 minecraft:red_nether_bricks
fill 370 207 495 370 210 495 minecraft:pink_terracotta
setblock 370 207 499 minecraft:red_nether_bricks
setblock 370 207 504 minecraft:red_nether_bricks
fill 370 207 505 370 307 505 minecraft:red_terracotta
fill 371 207 470 371 307 471 minecraft:red_terracotta
setblock 371 207 472 minecraft:pink_terracotta
fill 371 207 473 371 307 475 minecraft:red_terracotta
setblock 371 207 482 minecraft:pink_terracotta
fill 371 207 483 371 307 486 minecraft:red_terracotta
setblock 371 207 487 minecraft:pink_terracotta
fill 371 207 488 371 307 497 minecraft:red_terracotta
setblock 371 207 498 minecraft:pink_terracotta
fill 371 207 499 371 307 500 minecraft:red_terracotta
fill 371 207 503 371 307 504 minecraft:red_terracotta
fill 329 208 463 329 307 463 minecraft:red_terracotta
fill 329 208 479 329 307 479 minecraft:red_terracotta
fill 329 208 484 329 307 484 minecraft:red_terracotta
fill 330 208 464 333 208 464 minecraft:pink_terracotta
setblock 330 208 468 minecraft:red_nether_bricks
fill 330 208 469 330 211 469 minecraft:pink_terracotta
setblock 330 208 473 minecraft:red_nether_bricks
fill 330 208 474 330 208 477 minecraft:pink_terracotta
setblock 330 208 478 minecraft:red_nether_bricks
fill 330 208 479 330 211 479 minecraft:pink_terracotta
setblock 330 208 483 minecraft:red_nether_bricks
fill 330 208 484 330 210 484 minecraft:pink_terracotta
setblock 330 208 488 minecraft:red_nether_bricks
fill 330 208 489 330 211 489 minecraft:pink_terracotta
setblock 330 208 492 minecraft:pink_terracotta
setblock 330 208 493 minecraft:red_nether_bricks
fill 330 208 494 331 210 494 minecraft:pink_terracotta
setblock 330 208 497 minecraft:pink_terracotta
setblock 330 208 498 minecraft:red_nether_bricks
fill 330 208 499 330 209 501 minecraft:pink_terracotta
setblock 330 208 503 minecraft:red_nether_bricks
fill 330 208 504 330 211 504 minecraft:pink_terracotta
setblock 331 208 467 minecraft:red_nether_bricks
fill 331 208 468 331 211 468 minecraft:pink_terracotta
setblock 331 208 472 minecraft:red_nether_bricks
fill 331 208 473 331 211 473 minecraft:pink_terracotta
setblock 331 208 477 minecraft:red_nether_bricks
setblock 331 208 478 minecraft:pink_terracotta
setblock 331 208 487 minecraft:red_nether_bricks
fill 331 208 488 331 209 488 minecraft:pink_terracotta
setblock 331 208 491 minecraft:pink_terracotta
setblock 331 208 492 minecraft:red_nether_bricks
fill 331 208 493 331 210 493 minecraft:pink_terracotta
setblock 332 208 466 minecraft:red_nether_bricks
fill 332 208 467 332 210 467 minecraft:pink_terracotta
setblock 332 208 471 minecraft:red_nether_bricks
fill 332 208 472 332 211 472 minecraft:pink_terracotta
setblock 333 208 465 minecraft:red_nether_bricks
fill 333 208 466 333 209 466 minecraft:pink_terracotta
setblock 333 208 504 minecraft:pink_terracotta
setblock 334 208 464 minecraft:red_nether_bricks
fill 334 208 465 334 210 465 minecraft:pink_terracotta
fill 335 208 464 335 211 464 minecraft:pink_terracotta
setblock 338 208 465 minecraft:red_nether_bricks
setblock 339 208 464 minecraft:red_nether_bricks
fill 339 208 465 339 210 465 minecraft:pink_terracotta
setblock 339 208 504 minecraft:red_nether_bricks
fill 340 208 463 340 307 463 minecraft:red_terracotta
fill 340 208 464 340 211 464 minecraft:pink_terracotta
fill 340 208 504 340 211 504 minecraft:pink_terracotta
setblock 341 208 466 minecraft:pink_terracotta
setblock 342 208 466 minecraft:red_nether_bricks
fill 343 208 463 344 307 463 minecraft:red_terracotta
setblock 343 208 465 minecraft:red_nether_bricks
fill 343 208 466 343 210 466 minecraft:pink_terracotta
setblock 344 208 464 minecraft:red_nether_bricks
fill 344 208 465 344 211 465 minecraft:pink_terracotta
setblock 344 208 504 minecraft:red_nether_bricks
fill 345 208 464 345 211 464 minecraft:pink_terracotta
setblock 345 208 503 minecraft:red_nether_bricks
fill 345 208 504 345 211 504 minecraft:pink_terracotta
setblock 346 208 502 minecraft:red_nether_bricks
fill 346 208 503 346 211 503 minecraft:pink_terracotta
setblock 347 208 466 minecraft:red_nether_bricks
fill 347 208 502 347 211 502 minecraft:pink_terracotta
fill 347 208 505 347 307 505 minecraft:red_terracotta
setblock 348 208 465 minecraft:red_nether_bricks
fill 348 208 466 348 209 466 minecraft:pink_terracotta
setblock 349 208 464 minecraft:red_nether_bricks
fill 349 208 465 349 210 465 minecraft:pink_terracotta
setblock 349 208 504 minecraft:red_nether_bricks
fill 349 208 505 349 307 505 minecraft:red_terracotta
fill 350 208 464 350 211 464 minecraft:pink_terracotta
setblock 350 208 503 minecraft:red_nether_bricks
fill 350 208 504 350 211 504 minecraft:pink_terracotta
fill 351 208 503 351 209 503 minecraft:pink_terracotta
setblock 354 208 464 minecraft:red_nether_bricks
setblock 354 208 504 minecraft:red_nether_bricks
fill 358 208 463 358 307 463 minecraft:red_terracotta
fill 364 208 463 364 307 463 minecraft:red_terracotta
setblock 364 208 464 minecraft:red_nether_bricks
fill 364 208 465 364 210 465 minecraft:pink_terracotta
fill 365 208 464 365 211 464 minecraft:pink_terracotta
fill 365 208 504 365 209 504 minecraft:pink_terracotta
setblock 366 208 466 minecraft:pink_terracotta
fill 367 208 463 367 307 463 minecraft:red_terracotta
setblock 367 208 466 minecraft:red_nether_bricks
fill 367 208 469 367 208 470 minecraft:pink_terracotta
setblock 367 208 471 minecraft:red_nether_bricks
fill 367 208 472 367 210 473 minecraft:pink_terracotta
setblock 367 208 486 minecraft:red_nether_bricks
fill 367 208 487 367 209 487 minecraft:pink_terracotta
setblock 367 208 491 minecraft:red_nether_bricks
fill 367 208 492 367 210 493 minecraft:pink_terracotta
setblock 368 208 465 minecraft:red_nether_bricks
fill 368 208 466 368 210 466 minecraft:pink_terracotta
setblock 368 208 469 minecraft:pink_terracotta
setblock 368 208 470 minecraft:red_nether_bricks
fill 368 208 471 368 211 471 minecraft:pink_terracotta
fill 368 208 473 368 208 474 minecraft:pink_terracotta
setblock 368 208 475 minecraft:red_nether_bricks
fill 368 208 476 368 208 479 minecraft:pink_terracotta
setblock 368 208 480 minecraft:red_nether_bricks
fill 368 208 481 368 210 481 minecraft:pink_terracotta
setblock 368 208 485 minecraft:red_nether_bricks
fill 368 208 486 368 211 486 minecraft:pink_terracotta
setblock 368 208 490 minecraft:red_nether_bricks
fill 368 208 491 368 211 491 minecraft:pink_terracotta
setblock 368 208 495 minecraft:red_nether_bricks
setblock 369 208 464 minecraft:red_nether_bricks
fill 369 208 465 369 211 465 minecraft:pink_terracotta
setblock 369 208 468 minecraft:pink_terracotta
setblock 369 208 469 minecraft:red_nether_bricks
fill 369 208 470 369 211 470 minecraft:pink_terracotta
setblock 369 208 473 minecraft:pink_terracotta
setblock 369 208 474 minecraft:red_nether_bricks
fill 369 208 475 369 211 475 minecraft:pink_terracotta
setblock 369 208 479 minecraft:red_nether_bricks
fill 369 208 480 369 211 480 minecraft:pink_terracotta
setblock 369 208 484 minecraft:red_nether_bricks
fill 369 208 485 369 211 485 minecraft:pink_terracotta
setblock 369 208 489 minecraft:red_nether_bricks
fill 369 208 490 369 211 490 minecraft:pink_terracotta
setblock 369 208 494 minecraft:red_nether_bricks
fill 369 208 495 369 211 495 minecraft:pink_terracotta
fill 369 208 497 369 209 497 minecraft:pink_terracotta
setblock 369 208 504 minecraft:red_nether_bricks
fill 370 208 464 370 211 464 minecraft:pink_terracotta
setblock 370 208 468 minecraft:red_nether_bricks
fill 370 208 469 370 211 469 minecraft:pink_terracotta
setblock 370 208 473 minecraft:red_nether_bricks
fill 370 208 474 370 211 474 minecraft:pink_terracotta
setblock 370 208 478 minecraft:red_nether_bricks
fill 370 208 479 370 211 479 minecraft:pink_terracotta
setblock 370 208 483 minecraft:red_nether_bricks
fill 370 208 484 370 211 484 minecraft:pink_terracotta
setblock 370 208 488 minecraft:red_nether_bricks
fill 370 208 489 370 211 489 minecraft:pink_terracotta
setblock 370 208 493 minecraft:red_nether_bricks
fill 370 208 494 370 211 494 minecraft:pink_terracotta
setblock 370 208 498 minecraft:red_nether_bricks
fill 370 208 499 370 211 499 minecraft:pink_terracotta
setblock 370 208 504 minecraft:pink_terracotta
fill 371 208 472 371 307 472 minecraft:red_terracotta
fill 371 208 482 371 307 482 minecraft:red_terracotta
fill 371 208 487 371 307 487 minecraft:red_terracotta
fill 371 208 498 371 307 498 minecraft:red_terracotta
fill 330 209 464 332 209 464 minecraft:pink_terracotta
setblock 330 209 467 minecraft:red_nether_bricks
fill 330 209 468 330 212 468 minecraft:pink_terracotta
setblock 330 209 472 minecraft:red_nether_bricks
fill 330 209 473 330 209 476 minecraft:pink_terracotta
setblock 330 209 477 minecraft:red_nether_bricks
fill 330 209 478 330 212 478 minecraft:pink_terracotta
setblock 330 209 481 minecraft:pink_terracotta
setblock 330 209 482 minecraft:red_nether_bricks
fill 330 209 483 330 210 483 minecraft:pink_terracotta
setblock 330 209 487 minecraft:red_nether_bricks
fill 330 209 488 330 211 488 minecraft:pink_terracotta
setblock 330 209 492 minecraft:red_nether_bricks
fill 330 209 493 330 212 493 minecraft:pink_terracotta
setblock 330 209 497 minecraft:red_nether_bricks
fill 330 209 498 330 212 498 minecraft:pink_terracotta
setblock 330 209 502 minecraft:red_nether_bricks
fill 330 209 503 330 210 503 minecraft:pink_terracotta
setblock 331 209 466 minecraft:red_nether_bricks
fill 331 209 467 331 212 467 minecraft:pink_terracotta
setblock 331 209 471 minecraft:red_nether_bricks
fill 331 209 472 331 212 472 minecraft:pink_terracotta
setblock 331 209 476 minecraft:red_nether_bricks
fill 331 209 477 331 211 477 minecraft:pink_terracotta
setblock 331 209 491 minecraft:red_nether_bricks
fill 331 209 492 331 210 492 minecraft:pink_terracotta
setblock 332 209 465 minecraft:red_nether_bricks
fill 332 209 466 332 210 466 minecraft:pink_terracotta
setblock 332 209 469 minecraft:pink_terracotta
setblock 332 209 470 minecraft:red_nether_bricks
fill 332 209 471 332 212 471 minecraft:pink_terracotta
setblock 333 209 464 minecraft:red_nether_bricks
fill 333 209 465 333 211 465 minecraft:pink_terracotta
fill 334 209 464 334 212 464 minecraft:pink_terracotta
setblock 337 209 465 minecraft:red_nether_bricks
setblock 338 209 464 minecraft:red_nether_bricks
fill 338 209 465 338 210 465 minecraft:pink_terracotta
fill 339 209 464 339 212 464 minecraft:pink_terracotta
fill 339 209 504 339 212 504 minecraft:pink_terracotta
setblock 342 209 465 minecraft:red_nether_bricks
fill 342 209 466 342 210 466 minecraft:pink_terracotta
fill 342 209 503 342 210 503 minecraft:pink_terracotta
setblock 343 209 464 minecraft:red_nether_bricks
fill 343 209 465 343 212 465 minecraft:pink_terracotta
setblock 343 209 504 minecraft:red_nether_bricks
fill 344 209 464 344 212 464 minecraft:pink_terracotta
setblock 344 209 503 minecraft:red_nether_bricks
fill 344 209 504 344 212 504 minecraft:pink_terracotta
setblock 345 209 502 minecraft:red_nether_bricks
fill 345 209 503 345 212 503 minecraft:pink_terracotta
setblock 346 209 466 minecraft:red_nether_bricks
fill 346 209 502 346 212 502 minecraft:pink_terracotta
setblock 347 209 465 minecraft:red_nether_bricks
fill 347 209 466 347 210 466 minecraft:pink_terracotta
setblock 348 209 464 minecraft:red_nether_bricks
fill 348 209 465 348 211 465 minecraft:pink_terracotta
setblock 348 209 504 minecraft:red_nether_bricks
fill 349 209 464 349 212 464 minecraft:pink_terracotta
setblock 349 209 503 minecraft:red_nether_bricks
fill 349 209 504 349 212 504 minecraft:pink_terracotta
fill 350 209 503 350 210 503 minecraft:pink_terracotta
setblock 353 209 464 minecraft:red_nether_bricks
setblock 353 209 504 minecraft:red_nether_bricks
setblock 357 209 504 minecraft:white_concrete
fill 361 209 484 362 210 485 minecraft:red_concrete
setblock 363 209 464 minecraft:red_nether_bricks
fill 364 209 464 364 212 464 minecraft:pink_terracotta
setblock 366 209 466 minecraft:red_nether_bricks
setblock 367 209 465 minecraft:red_nether_bricks
fill 367 209 466 367 210 466 minecraft:pink_terracotta
fill 367 209 468 367 209 469 minecraft:pink_terracotta
setblock 367 209 470 minecraft:red_nether_bricks
fill 367 209 471 367 212 471 minecraft:pink_terracotta
setblock 367 209 474 minecraft:pink_terracotta
setblock 367 209 475 minecraft:red_nether_bricks
setblock 367 209 486 minecraft:pink_terracotta
setblock 367 209 490 minecraft:red_nether_bricks
fill 367 209 491 367 211 491 minecraft:pink_terracotta
setblock 368 209 464 minecraft:red_nether_bricks
fill 368 209 465 368 211 465 minecraft:pink_terracotta
setblock 368 209 469 minecraft:red_nether_bricks
fill 368 209 470 368 212 470 minecraft:pink_terracotta
setblock 368 209 473 minecraft:pink_terracotta
setblock 368 209 474 minecraft:red_nether_bricks
fill 368 209 475 368 209 478 minecraft:pink_terracotta
setblock 368 209 479 minecraft:red_nether_bricks
fill 368 209 480 368 211 480 minecraft:pink_terracotta
setblock 368 209 484 minecraft:red_nether_bricks
fill 368 209 485 368 210 485 minecraft:pink_terracotta
setblock 368 209 489 minecraft:red_nether_bricks
fill 368 209 490 368 212 490 minecraft:pink_terracotta
setblock 368 209 493 minecraft:pink_terracotta
setblock 368 209 494 minecraft:red_nether_bricks
fill 368 209 495 368 211 495 minecraft:pink_terracotta
setblock 368 209 504 minecraft:red_nether_bricks
fill 369 209 464 369 212 464 minecraft:pink_terracotta
setblock 369 209 468 minecraft:red_nether_bricks
fill 369 209 469 369 212 469 minecraft:pink_terracotta
setblock 369 209 473 minecraft:red_nether_bricks
fill 369 209 474 369 212 474 minecraft:pink_terracotta
setblock 369 209 478 minecraft:red_nether_bricks
fill 369 209 479 369 212 479 minecraft:pink_terracotta
setblock 369 209 483 minecraft:red_nether_bricks
fill 369 209 484 369 211 484 minecraft:pink_terracotta
setblock 369 209 488 minecraft:red_nether_bricks
fill 369 209 489 369 212 489 minecraft:pink_terracotta
setblock 369 209 493 minecraft:red_nether_bricks
fill 369 209 494 369 212 494 minecraft:pink_terracotta
setblock 369 209 504 minecraft:pink_terracotta
setblock 370 209 467 minecraft:red_nether_bricks
fill 370 209 468 370 212 468 minecraft:pink_terracotta
setblock 370 209 472 minecraft:red_nether_bricks
fill 370 209 473 370 212 473 minecraft:pink_terracotta
setblock 370 209 477 minecraft:red_nether_bricks
fill 370 209 478 370 212 478 minecraft:pink_terracotta
setblock 370 209 482 minecraft:red_nether_bricks
fill 370 209 483 370 212 483 minecraft:pink_terracotta
setblock 370 209 487 minecraft:red_nether_bricks
fill 370 209 488 370 212 488 minecraft:pink_terracotta
setblock 370 209 492 minecraft:red_nether_bricks
fill 370 209 493 370 212 493 minecraft:pink_terracotta
setblock 370 209 497 minecraft:red_nether_bricks
fill 370 209 498 370 212 498 minecraft:pink_terracotta
fill 330 210 464 331 210 464 minecraft:pink_terracotta
setblock 330 210 466 minecraft:red_nether_bricks
fill 330 210 467 330 213 467 minecraft:pink_terracotta
setblock 330 210 471 minecraft:red_nether_bricks
fill 330 210 472 330 210 475 minecraft:pink_terracotta
setblock 330 210 476 minecraft:red_nether_bricks
fill 330 210 477 330 213 477 minecraft:pink_terracotta
setblock 330 210 481 minecraft:red_nether_bricks
setblock 330 210 482 minecraft:pink_terracotta
setblock 330 210 486 minecraft:red_nether_bricks
fill 330 210 487 330 211 487 minecraft:pink_terracotta
setblock 330 210 491 minecraft:red_nether_bricks
fill 330 210 492 330 213 492 minecraft:pink_terracotta
setblock 330 210 496 minecraft:red_nether_bricks
fill 330 210 497 330 213 497 minecraft:pink_terracotta
fill 330 210 499 330 210 500 minecraft:pink_terracotta
setblock 331 210 465 minecraft:red_nether_bricks
fill 331 210 466 331 212 466 minecraft:pink_terracotta
setblock 331 210 470 minecraft:red_nether_bricks
fill 331 210 471 331 213 471 minecraft:pink_terracotta
setblock 331 210 474 minecraft:pink_terracotta
setblock 331 210 475 minecraft:red_nether_bricks
fill 331 210 476 331 212 476 minecraft:pink_terracotta
setblock 331 210 490 minecraft:red_nether_bricks
setblock 331 210 491 minecraft:pink_terracotta
setblock 332 210 464 minecraft:red_nether_bricks
fill 332 210 465 332 211 465 minecraft:pink_terracotta
setblock 332 210 469 minecraft:red_nether_bricks
fill 332 210 470 332 211 470 minecraft:pink_terracotta
setblock 332 210 474 minecraft:red_nether_bricks
fill 333 210 464 333 212 464 minecraft:pink_terracotta
setblock 336 210 465 minecraft:red_nether_bricks
setblock 337 210 464 minecraft:red_nether_bricks
setblock 337 210 465 minecraft:pink_terracotta
fill 338 210 464 338 212 464 minecraft:pink_terracotta
setblock 338 210 504 minecraft:white_concrete
setblock 341 210 465 minecraft:red_nether_bricks
setblock 342 210 464 minecraft:red_nether_bricks
fill 342 210 465 342 212 465 minecraft:pink_terracotta
setblock 342 210 504 minecraft:red_nether_bricks
fill 343 210 464 343 213 464 minecraft:pink_terracotta
setblock 343 210 503 minecraft:red_nether_bricks
fill 343 210 504 343 213 504 minecraft:pink_terracotta
fill 344 210 503 344 213 503 minecraft:pink_terracotta
setblock 345 210 466 minecraft:red_nether_bricks
fill 345 210 502 345 212 502 minecraft:pink_terracotta
setblock 346 210 465 minecraft:red_nether_bricks
setblock 346 210 466 minecraft:pink_terracotta
setblock 347 210 464 minecraft:red_nether_bricks
fill 347 210 465 347 211 465 minecraft:pink_terracotta
setblock 347 210 504 minecraft:red_nether_bricks
fill 348 210 464 348 212 464 minecraft:pink_terracotta
setblock 348 210 503 minecraft:red_nether_bricks
fill 348 210 504 348 213 504 minecraft:pink_terracotta
fill 349 210 503 349 211 503 minecraft:pink_terracotta
setblock 352 210 504 minecraft:red_nether_bricks
setblock 362 210 464 minecraft:white_concrete
fill 363 210 464 363 211 464 minecraft:pink_terracotta
setblock 363 210 504 minecraft:white_concrete
setblock 366 210 465 minecraft:red_nether_bricks
setblock 366 210 466 minecraft:pink_terracotta
setblock 367 210 464 minecraft:red_nether_bricks
fill 367 210 465 367 212 465 minecraft:pink_terracotta
setblock 367 210 469 minecraft:red_nether_bricks
fill 367 210 470 367 212 470 minecraft:pink_terracotta
setblock 367 210 474 minecraft:red_nether_bricks
fill 367 210 475 368 211 476 minecraft:pink_terracotta
setblock 367 210 489 minecraft:red_nether_bricks
fill 367 210 490 367 211 490 minecraft:pink_terracotta
setblock 367 210 504 minecraft:red_nether_bricks
fill 368 210 464 368 213 464 minecraft:pink_terracotta
setblock 368 210 468 minecraft:red_nether_bricks
fill 368 210 469 368 213 469 minecraft:pink_terracotta
setblock 368 210 473 minecraft:red_nether_bricks
fill 368 210 474 368 213 474 minecraft:pink_terracotta
setblock 368 210 477 minecraft:pink_terracotta
setblock 368 210 478 minecraft:red_nether_bricks
fill 368 210 479 368 212 479 minecraft:pink_terracotta
setblock 368 210 483 minecraft:red_nether_bricks
setblock 368 210 484 minecraft:pink_terracotta
setblock 368 210 488 minecraft:red_nether_bricks
fill 368 210 489 368 211 489 minecraft:pink_terracotta
setblock 368 210 493 minecraft:red_nether_bricks
fill 368 210 494 368 212 494 minecraft:pink_terracotta
setblock 369 210 467 minecraft:red_nether_bricks
fill 369 210 468 369 213 468 minecraft:pink_terracotta
setblock 369 210 472 minecraft:red_nether_bricks
fill 369 210 473 369 213 473 minecraft:pink_terracotta
setblock 369 210 477 minecraft:red_nether_bricks
fill 369 210 478 369 213 478 minecraft:pink_terracotta
setblock 369 210 482 minecraft:red_nether_bricks
fill 369 210 483 369 211 483 minecraft:pink_terracotta
setblock 369 210 487 minecraft:red_nether_bricks
fill 369 210 488 369 212 488 minecraft:pink_terracotta
setblock 369 210 492 minecraft:red_nether_bricks
fill 369 210 493 369 213 493 minecraft:pink_terracotta
setblock 369 210 497 minecraft:red_nether_bricks
setblock 370 210 466 minecraft:red_nether_bricks
fill 370 210 467 370 213 467 minecraft:pink_terracotta
setblock 370 210 471 minecraft:red_nether_bricks
fill 370 210 472 370 213 472 minecraft:pink_terracotta
setblock 370 210 476 minecraft:red_nether_bricks
fill 370 210 477 370 213 477 minecraft:pink_terracotta
setblock 370 210 481 minecraft:red_nether_bricks
fill 370 210 482 370 213 482 minecraft:pink_terracotta
setblock 370 210 486 minecraft:red_nether_bricks
fill 370 210 487 370 213 487 minecraft:pink_terracotta
setblock 370 210 491 minecraft:red_nether_bricks
fill 370 210 492 370 213 492 minecraft:pink_terracotta
setblock 370 210 496 minecraft:red_nether_bricks
fill 370 210 497 370 213 497 minecraft:pink_terracotta
setblock 370 210 500 minecraft:white_concrete
setblock 330 211 464 minecraft:pink_terracotta
setblock 330 211 465 minecraft:red_nether_bricks
fill 330 211 466 330 214 466 minecraft:pink_terracotta
setblock 330 211 470 minecraft:red_nether_bricks
fill 330 211 471 330 211 474 minecraft:pink_terracotta
setblock 330 211 475 minecraft:red_nether_bricks
fill 330 211 476 330 214 476 minecraft:pink_terracotta
setblock 330 211 480 minecraft:red_nether_bricks
setblock 330 211 481 minecraft:pink_terracotta
setblock 330 211 486 minecraft:pink_terracotta
setblock 330 211 490 minecraft:red_nether_bricks
fill 330 211 491 330 212 491 minecraft:pink_terracotta
setblock 330 211 494 minecraft:pink_terracotta
setblock 330 211 495 minecraft:red_nether_bricks
fill 330 211 496 330 214 496 minecraft:pink_terracotta
setblock 330 211 499 minecraft:pink_terracotta
setblock 330 211 500 minecraft:red_nether_bricks
setblock 331 211 464 minecraft:red_nether_bricks
fill 331 211 465 331 212 465 minecraft:pink_terracotta
setblock 331 211 469 minecraft:red_nether_bricks
fill 331 211 470 331 214 470 minecraft:pink_terracotta
setblock 331 211 474 minecraft:red_nether_bricks
fill 331 211 475 331 213 475 minecraft:pink_terracotta
fill 331 211 492 331 222 492 minecraft:red_nether_bricks
fill 332 211 464 332 212 464 minecraft:pink_terracotta
setblock 332 211 468 minecraft:red_nether_bricks
setblock 332 211 469 minecraft:pink_terracotta
setblock 332 211 473 minecraft:red_nether_bricks
setblock 336 211 464 minecraft:red_nether_bricks
fill 337 211 464 337 212 464 minecraft:pink_terracotta
setblock 340 211 465 minecraft:red_nether_bricks
setblock 341 211 464 minecraft:red_nether_bricks
fill 341 211 465 341 212 465 minecraft:pink_terracotta
setblock 341 211 504 minecraft:red_nether_bricks
fill 342 211 464 342 214 464 minecraft:pink_terracotta
setblock 342 211 503 minecraft:red_nether_bricks
fill 342 211 504 342 214 504 minecraft:pink_terracotta
fill 343 211 503 343 214 503 minecraft:pink_terracotta
setblock 345 211 465 minecraft:red_nether_bricks
setblock 346 211 464 minecraft:red_nether_bricks
fill 346 211 465 346 212 465 minecraft:pink_terracotta
setblock 346 211 504 minecraft:red_nether_bricks
fill 347 211 464 347 213 464 minecraft:pink_terracotta
setblock 347 211 503 minecraft:red_nether_bricks
fill 347 211 504 347 214 504 minecraft:pink_terracotta
fill 348 211 503 348 213 503 minecraft:pink_terracotta
setblock 351 211 504 minecraft:red_nether_bricks
setblock 356 211 464 minecraft:white_concrete
setblock 365 211 465 minecraft:red_nether_bricks
setblock 366 211 464 minecraft:red_nether_bricks
setblock 366 211 465 minecraft:pink_terracotta
fill 367 211 464 367 213 464 minecraft:pink_terracotta
setblock 367 211 469 minecraft:pink_terracotta
setblock 367 211 472 minecraft:pink_terracotta
setblock 367 211 473 minecraft:red_nether_bricks
fill 367 211 474 367 214 474 minecraft:pink_terracotta
setblock 367 211 492 minecraft:pink_terracotta
setblock 368 211 467 minecraft:red_nether_bricks
fill 368 211 468 368 212 468 minecraft:pink_terracotta
setblock 368 211 472 minecraft:red_nether_bricks
fill 368 211 473 368 214 473 minecraft:pink_terracotta
setblock 368 211 477 minecraft:red_nether_bricks
fill 368 211 478 368 214 478 minecraft:pink_terracotta
setblock 368 211 487 minecraft:red_nether_bricks
setblock 368 211 488 minecraft:pink_terracotta
setblock 368 211 492 minecraft:red_nether_bricks
fill 368 211 493 368 212 493 minecraft:pink_terracotta
setblock 369 211 466 minecraft:red_nether_bricks
fill 369 211 467 369 213 467 minecraft:pink_terracotta
setblock 369 211 471 minecraft:red_nether_bricks
fill 369 211 472 369 214 472 minecraft:pink_terracotta
setblock 369 211 476 minecraft:red_nether_bricks
fill 369 211 477 369 214 477 minecraft:pink_terracotta
setblock 369 211 481 minecraft:red_nether_bricks
fill 369 211 482 369 212 482 minecraft:pink_terracotta
setblock 369 211 486 minecraft:red_nether_bricks
fill 369 211 487 369 212 487 minecraft:pink_terracotta
setblock 369 211 491 minecraft:red_nether_bricks
fill 369 211 492 369 213 492 minecraft:pink_terracotta
setblock 369 211 496 minecraft:red_nether_bricks
setblock 369 211 497 minecraft:pink_terracotta
setblock 369 211 504 minecraft:white_concrete
setblock 370 211 465 minecraft:red_nether_bricks
fill 370 211 466 370 214 466 minecraft:pink_terracotta
setblock 370 211 470 minecraft:red_nether_bricks
fill 370 211 471 370 214 471 minecraft:pink_terracotta
setblock 370 211 475 minecraft:red_nether_bricks
fill 370 211 476 370 214 476 minecraft:pink_terracotta
setblock 370 211 480 minecraft:red_nether_bricks
fill 370 211 481 370 214 481 minecraft:pink_terracotta
setblock 370 211 485 minecraft:red_nether_bricks
fill 370 211 486 370 212 486 minecraft:pink_terracotta
setblock 370 211 490 minecraft:red_nether_bricks
fill 370 211 491 370 213 491 minecraft:pink_terracotta
setblock 370 211 495 minecraft:red_nether_bricks
fill 370 211 496 370 214 496 minecraft:pink_terracotta
setblock 330 212 464 minecraft:red_nether_bricks
fill 330 212 465 330 214 465 minecraft:pink_terracotta
setblock 330 212 469 minecraft:red_nether_bricks
fill 330 212 470 330 212 473 minecraft:pink_terracotta
setblock 330 212 474 minecraft:red_nether_bricks
fill 330 212 475 330 215 475 minecraft:pink_terracotta
setblock 330 212 479 minecraft:red_nether_bricks
setblock 330 212 480 minecraft:white_concrete
setblock 330 212 489 minecraft:red_nether_bricks
setblock 330 212 490 minecraft:pink_terracotta
setblock 330 212 494 minecraft:red_nether_bricks
fill 330 212 495 330 214 495 minecraft:pink_terracotta
setblock 330 212 499 minecraft:red_nether_bricks
fill 331 212 464 331 213 464 minecraft:pink_terracotta
setblock 331 212 468 minecraft:red_nether_bricks
fill 331 212 469 331 213 469 minecraft:pink_terracotta
setblock 331 212 473 minecraft:red_nether_bricks
fill 331 212 474 331 214 474 minecraft:pink_terracotta
setblock 331 212 504 minecraft:white_concrete
setblock 340 212 464 minecraft:red_nether_bricks
setblock 340 212 504 minecraft:red_nether_bricks
fill 341 212 464 341 215 464 minecraft:pink_terracotta
setblock 341 212 503 minecraft:red_nether_bricks
fill 341 212 504 341 215 504 minecraft:pink_terracotta
fill 342 212 503 342 215 503 minecraft:pink_terracotta
setblock 344 212 465 minecraft:red_nether_bricks
setblock 345 212 464 minecraft:red_nether_bricks
setblock 345 212 465 minecraft:pink_terracotta
setblock 345 212 504 minecraft:red_nether_bricks
fill 346 212 464 346 213 464 minecraft:pink_terracotta
setblock 346 212 503 minecraft:red_nether_bricks
fill 346 212 504 346 215 504 minecraft:pink_terracotta
fill 347 212 503 347 214 503 minecraft:pink_terracotta
setblock 350 212 464 minecraft:white_concrete
setblock 350 212 504 minecraft:red_nether_bricks
setblock 365 212 464 minecraft:red_nether_bricks
fill 366 212 464 366 213 464 minecraft:pink_terracotta
setblock 367 212 472 minecraft:red_nether_bricks
fill 367 212 473 367 214 473 minecraft:pink_terracotta
fill 367 212 475 367 212 476 minecraft:pink_terracotta
setblock 368 212 471 minecraft:red_nether_bricks
fill 368 212 472 368 215 472 minecraft:pink_terracotta
setblock 368 212 475 minecraft:pink_terracotta
setblock 368 212 476 minecraft:red_nether_bricks
fill 368 212 477 368 215 477 minecraft:pink_terracotta
setblock 368 212 491 minecraft:red_nether_bricks
setblock 368 212 492 minecraft:pink_terracotta
setblock 369 212 466 minecraft:pink_terracotta
setblock 369 212 470 minecraft:red_nether_bricks
fill 369 212 471 369 215 471 minecraft:pink_terracotta
setblock 369 212 475 minecraft:red_nether_bricks
fill 369 212 476 369 215 476 minecraft:pink_terracotta
setblock 369 212 480 minecraft:red_nether_bricks
setblock 369 212 481 minecraft:pink_terracotta
setblock 369 212 486 minecraft:pink_terracotta
setblock 369 212 490 minecraft:red_nether_bricks
fill 369 212 491 369 213 491 minecraft:pink_terracotta
setblock 369 212 495 minecraft:red_nether_bricks
setblock 369 212 496 minecraft:pink_terracotta
setblock 370 212 464 minecraft:red_nether_bricks
fill 370 212 465 370 213 465 minecraft:pink_terracotta
setblock 370 212 469 minecraft:red_nether_bricks
fill 370 212 470 370 215 470 minecraft:pink_terracotta
setblock 370 212 474 minecraft:red_nether_bricks
fill 370 212 475 370 215 475 minecraft:pink_terracotta
setblock 370 212 479 minecraft:red_nether_bricks
fill 370 212 480 370 215 480 minecraft:pink_terracotta
setblock 370 212 484 minecraft:red_nether_bricks
setblock 370 212 485 minecraft:pink_terracotta
setblock 370 212 489 minecraft:red_nether_bricks
fill 370 212 490 370 213 490 minecraft:pink_terracotta
setblock 370 212 494 minecraft:red_nether_bricks
fill 370 212 495 370 214 495 minecraft:pink_terracotta
fill 330 213 464 330 214 464 minecraft:pink_terracotta
setblock 330 213 468 minecraft:red_nether_bricks
fill 330 213 469 330 213 472 minecraft:pink_terracotta
setblock 330 213 473 minecraft:red_nether_bricks
fill 330 213 474 330 216 474 minecraft:pink_terracotta
setblock 330 213 478 minecraft:red_nether_bricks
setblock 330 213 479 minecraft:pink_terracotta
setblock 330 213 486 minecraft:white_concrete
setblock 330 213 493 minecraft:red_nether_bricks
fill 330 213 494 330 214 494 minecraft:pink_terracotta
setblock 330 213 498 minecraft:red_nether_bricks
setblock 330 213 499 minecraft:pink_terracotta
setblock 331 213 467 minecraft:red_nether_bricks
setblock 331 213 468 minecraft:pink_terracotta
setblock 331 213 472 minecraft:red_nether_bricks
fill 331 213 473 331 214 473 minecraft:pink_terracotta
setblock 337 213 504 minecraft:white_concrete
fill 338 213 464 338 214 464 minecraft:white_concrete
setblock 339 213 464 minecraft:red_nether_bricks
setblock 339 213 504 minecraft:red_nether_bricks
fill 340 213 464 340 215 464 minecraft:pink_terracotta
fill 340 213 504 340 216 504 minecraft:pink_terracotta
fill 341 213 503 341 216 503 minecraft:pink_terracotta
setblock 344 213 464 minecraft:red_nether_bricks
setblock 344 213 504 minecraft:red_nether_bricks
fill 345 213 464 345 214 464 minecraft:pink_terracotta
setblock 345 213 503 minecraft:red_nether_bricks
fill 345 213 504 345 216 504 minecraft:pink_terracotta
fill 346 213 503 346 216 503 minecraft:pink_terracotta
setblock 349 213 504 minecraft:red_nether_bricks
setblock 356 213 504 minecraft:white_concrete
setblock 363 213 464 minecraft:white_concrete
setblock 365 213 464 minecraft:pink_terracotta
setblock 367 213 471 minecraft:red_nether_bricks
setblock 367 213 472 minecraft:pink_terracotta
setblock 367 213 475 minecraft:pink_terracotta
setblock 367 213 476 minecraft:red_nether_bricks
setblock 368 213 470 minecraft:red_nether_bricks
fill 368 213 471 368 215 471 minecraft:pink_terracotta
setblock 368 213 475 minecraft:red_nether_bricks
fill 368 213 476 368 216 476 minecraft:pink_terracotta
setblock 369 213 469 minecraft:red_nether_bricks
fill 369 213 470 369 216 470 minecraft:pink_terracotta
setblock 369 213 474 minecraft:red_nether_bricks
fill 369 213 475 369 216 475 minecraft:pink_terracotta
setblock 369 213 479 minecraft:red_nether_bricks
fill 369 213 480 369 214 480 minecraft:pink_terracotta
setblock 369 213 494 minecraft:red_nether_bricks
setblock 369 213 495 minecraft:pink_terracotta
setblock 370 213 468 minecraft:red_nether_bricks
fill 370 213 469 370 216 469 minecraft:pink_terracotta
setblock 370 213 473 minecraft:red_nether_bricks
fill 370 213 474 370 216 474 minecraft:pink_terracotta
setblock 370 213 478 minecraft:red_nether_bricks
fill 370 213 479 370 216 479 minecraft:pink_terracotta
setblock 370 213 483 minecraft:red_nether_bricks
setblock 370 213 488 minecraft:red_nether_bricks
setblock 370 213 489 minecraft:pink_terracotta
setblock 370 213 493 minecraft:red_nether_bricks
fill 370 213 494 370 214 494 minecraft:pink_terracotta
setblock 370 213 501 minecraft:white_concrete
setblock 330 214 467 minecraft:red_nether_bricks
fill 330 214 468 330 214 471 minecraft:pink_terracotta
setblock 330 214 472 minecraft:red_nether_bricks
fill 330 214 473 330 217 473 minecraft:pink_terracotta
setblock 330 214 477 minecraft:red_nether_bricks
fill 330 214 478 330 215 478 minecraft:pink_terracotta
setblock 330 214 492 minecraft:white_concrete
setblock 330 214 497 minecraft:red_nether_bricks
setblock 330 214 498 minecraft:pink_terracotta
setblock 331 214 471 minecraft:red_nether_bricks
setblock 331 214 472 minecraft:pink_terracotta
setblock 332 214 464 minecraft:white_concrete
fill 339 214 504 339 217 504 minecraft:pink_terracotta
setblock 343 214 464 minecraft:red_nether_bricks
setblock 343 214 504 minecraft:red_nether_bricks
fill 344 214 464 344 215 464 minecraft:pink_terracotta
setblock 344 214 503 minecraft:red_nether_bricks
fill 344 214 504 344 217 504 minecraft:pink_terracotta
fill 345 214 503 345 217 503 minecraft:pink_terracotta
setblock 348 214 504 minecraft:red_nether_bricks
setblock 357 214 464 minecraft:white_concrete
setblock 362 214 504 minecraft:white_concrete
setblock 367 214 475 minecraft:red_nether_bricks
setblock 368 214 470 minecraft:pink_terracotta
setblock 368 214 474 minecraft:red_nether_bricks
fill 368 214 475 368 217 475 minecraft:pink_terracotta
setblock 369 214 468 minecraft:red_nether_bricks
fill 369 214 469 369 215 469 minecraft:pink_terracotta
setblock 369 214 473 minecraft:red_nether_bricks
fill 369 214 474 369 217 474 minecraft:pink_terracotta
setblock 369 214 478 minecraft:red_nether_bricks
fill 369 214 479 369 217 479 minecraft:pink_terracotta
setblock 370 214 467 minecraft:red_nether_bricks
fill 370 214 468 370 215 468 minecraft:pink_terracotta
setblock 370 214 472 minecraft:red_nether_bricks
fill 370 214 473 370 217 473 minecraft:pink_terracotta
setblock 370 214 477 minecraft:red_nether_bricks
fill 370 214 478 370 217 478 minecraft:pink_terracotta
setblock 370 214 492 minecraft:red_nether_bricks
setblock 370 214 493 minecraft:pink_terracotta
fill 330 215 467 330 215 470 minecraft:pink_terracotta
setblock 330 215 471 minecraft:red_nether_bricks
fill 330 215 472 330 218 472 minecraft:pink_terracotta
setblock 330 215 476 minecraft:red_nether_bricks
fill 330 215 477 330 218 477 minecraft:pink_terracotta
setblock 330 215 479 minecraft:white_concrete
setblock 330 215 497 minecraft:pink_terracotta
setblock 330 215 498 minecraft:white_concrete
setblock 332 215 466 minecraft:light[level=12]
setblock 332 215 474 minecraft:light[level=12]
setblock 332 215 482 minecraft:light[level=12]
setblock 332 215 490 minecraft:light[level=12]
setblock 332 215 498 minecraft:light[level=12]
fill 338 215 504 338 218 504 minecraft:pink_terracotta
setblock 340 215 466 minecraft:light[level=12]
setblock 340 215 474 minecraft:light[level=12]
setblock 340 215 482 minecraft:light[level=12]
setblock 340 215 490 minecraft:light[level=12]
setblock 340 215 498 minecraft:light[level=12]
fill 340 215 503 340 217 503 minecraft:pink_terracotta
setblock 342 215 464 minecraft:red_nether_bricks
setblock 342 215 504 minecraft:red_nether_bricks
fill 343 215 464 343 216 464 minecraft:pink_terracotta
setblock 343 215 502 minecraft:pink_terracotta
setblock 343 215 503 minecraft:red_nether_bricks
fill 343 215 504 343 218 504 minecraft:pink_terracotta
setblock 344 215 502 minecraft:red_nether_bricks
fill 344 215 503 344 218 503 minecraft:pink_terracotta
setblock 347 215 504 minecraft:red_nether_bricks
setblock 348 215 466 minecraft:light[level=12]
setblock 348 215 474 minecraft:light[level=12]
setblock 348 215 482 minecraft:light[level=12]
setblock 348 215 490 minecraft:light[level=12]
setblock 348 215 498 minecraft:light[level=12]
setblock 348 215 504 minecraft:pink_terracotta
setblock 349 215 504 minecraft:white_concrete
setblock 351 215 464 minecraft:white_concrete
setblock 356 215 466 minecraft:light[level=12]
setblock 356 215 474 minecraft:light[level=12]
setblock 356 215 482 minecraft:light[level=12]
setblock 356 215 490 minecraft:light[level=12]
setblock 356 215 498 minecraft:light[level=12]
setblock 364 215 466 minecraft:light[level=12]
setblock 364 215 474 minecraft:light[level=12]
setblock 364 215 482 minecraft:light[level=12]
setblock 364 215 490 minecraft:light[level=12]
setblock 364 215 498 minecraft:light[level=12]
setblock 368 215 473 minecraft:red_nether_bricks
fill 368 215 474 368 217 474 minecraft:pink_terracotta
setblock 368 215 504 minecraft:white_concrete
setblock 369 215 472 minecraft:red_nether_bricks
fill 369 215 473 369 218 473 minecraft:pink_terracotta
setblock 369 215 477 minecraft:red_nether_bricks
fill 369 215 478 369 218 478 minecraft:pink_terracotta
setblock 370 215 464 minecraft:white_concrete
setblock 370 215 471 minecraft:red_nether_bricks
fill 370 215 472 370 218 472 minecraft:pink_terracotta
setblock 370 215 476 minecraft:red_nether_bricks
fill 370 215 477 370 218 477 minecraft:pink_terracotta
setblock 370 215 489 minecraft:white_concrete
setblock 330 216 469 minecraft:pink_terracotta
setblock 330 216 470 minecraft:red_nether_bricks
fill 330 216 471 330 217 471 minecraft:pink_terracotta
setblock 330 216 475 minecraft:red_nether_bricks
fill 330 216 476 330 219 476 minecraft:pink_terracotta
setblock 330 216 485 minecraft:white_concrete
setblock 330 216 504 minecraft:white_concrete
setblock 336 216 504 minecraft:white_concrete
fill 337 216 504 337 219 504 minecraft:pink_terracotta
fill 339 216 503 339 218 503 minecraft:pink_terracotta
setblock 341 216 464 minecraft:red_nether_bricks
setblock 341 216 504 minecraft:red_nether_bricks
fill 342 216 464 342 219 464 minecraft:pink_terracotta
setblock 342 216 502 minecraft:pink_terracotta
setblock 342 216 503 minecraft:red_nether_bricks
fill 342 216 504 342 219 504 minecraft:pink_terracotta
setblock 343 216 502 minecraft:red_nether_bricks
fill 343 216 503 343 219 503 minecraft:pink_terracotta
fill 344 216 502 344 219 502 minecraft:pink_terracotta
setblock 345 216 464 minecraft:white_concrete
setblock 346 216 504 minecraft:red_nether_bricks
fill 347 216 504 347 219 504 minecraft:pink_terracotta
fill 354 216 473 355 217 474 minecraft:red_concrete
fill 355 216 475 355 217 475 minecraft:red_concrete
setblock 355 216 504 minecraft:white_concrete
setblock 364 216 464 minecraft:white_concrete
setblock 368 216 473 minecraft:pink_terracotta
setblock 368 216 477 minecraft:red_nether_bricks
setblock 369 216 471 minecraft:red_nether_bricks
fill 369 216 472 369 218 472 minecraft:pink_terracotta
setblock 369 216 476 minecraft:red_nether_bricks
fill 369 216 477 369 219 477 minecraft:pink_terracotta
setblock 370 216 470 minecraft:red_nether_bricks
fill 370 216 471 370 219 471 minecraft:pink_terracotta
setblock 370 216 475 minecraft:red_nether_bricks
fill 370 216 476 370 219 476 minecraft:pink_terracotta
setblock 370 216 480 minecraft:red_nether_bricks
setblock 370 216 483 minecraft:white_concrete
setblock 370 216 502 minecraft:white_concrete
setblock 330 217 466 minecraft:white_concrete
setblock 330 217 470 minecraft:pink_terracotta
setblock 330 217 474 minecraft:red_nether_bricks
fill 330 217 475 330 220 475 minecraft:pink_terracotta
setblock 330 217 491 minecraft:white_concrete
setblock 330 217 498 minecraft:pink_terracotta
setblock 330 217 499 minecraft:red_nether_bricks
fill 336 217 504 336 220 504 minecraft:pink_terracotta
fill 338 217 503 338 219 503 minecraft:pink_terracotta
setblock 339 217 464 minecraft:white_concrete
setblock 340 217 464 minecraft:red_nether_bricks
fill 340 217 502 341 217 502 minecraft:pink_terracotta
setblock 340 217 504 minecraft:red_nether_bricks
fill 341 217 464 341 220 464 minecraft:pink_terracotta
setblock 341 217 503 minecraft:red_nether_bricks
fill 341 217 504 341 220 504 minecraft:pink_terracotta
setblock 342 217 502 minecraft:red_nether_bricks
fill 342 217 503 342 220 503 minecraft:pink_terracotta
fill 343 217 502 343 220 502 minecraft:pink_terracotta
setblock 345 217 504 minecraft:red_nether_bricks
setblock 346 217 503 minecraft:red_nether_bricks
fill 346 217 504 346 220 504 minecraft:pink_terracotta
setblock 358 217 464 minecraft:white_concrete
setblock 361 217 504 minecraft:white_concrete
setblock 368 217 476 minecraft:red_nether_bricks
fill 368 217 477 368 220 477 minecraft:pink_terracotta
setblock 369 217 471 minecraft:pink_terracotta
setblock 369 217 475 minecraft:red_nether_bricks
fill 369 217 476 369 220 476 minecraft:pink_terracotta
setblock 370 217 469 minecraft:red_nether_bricks
fill 370 217 470 370 220 470 minecraft:pink_terracotta
setblock 370 217 474 minecraft:red_nether_bricks
fill 370 217 475 370 220 475 minecraft:pink_terracotta
setblock 370 217 479 minecraft:red_nether_bricks
fill 370 217 480 370 220 480 minecraft:pink_terracotta
setblock 370 217 496 minecraft:white_concrete
setblock 330 218 473 minecraft:red_nether_bricks
fill 330 218 474 330 221 474 minecraft:pink_terracotta
setblock 330 218 478 minecraft:white_concrete
setblock 330 218 497 minecraft:white_concrete
setblock 330 218 498 minecraft:red_nether_bricks
fill 330 218 499 330 218 502 minecraft:pink_terracotta
setblock 333 218 464 minecraft:white_concrete
setblock 334 218 504 minecraft:red_nether_bricks
fill 335 218 504 335 221 504 minecraft:pink_terracotta
fill 336 218 503 337 220 503 minecraft:pink_terracotta
setblock 338 218 464 minecraft:pink_terracotta
fill 338 218 502 340 218 502 minecraft:pink_terracotta
setblock 339 218 464 minecraft:red_nether_bricks
setblock 339 218 504 minecraft:red_nether_bricks
fill 340 218 464 340 221 464 minecraft:pink_terracotta
setblock 340 218 503 minecraft:red_nether_bricks
fill 340 218 504 340 221 504 minecraft:pink_terracotta
setblock 341 218 501 minecraft:pink_terracotta
setblock 341 218 502 minecraft:red_nether_bricks
fill 341 218 503 341 221 503 minecraft:pink_terracotta
setblock 342 218 501 minecraft:red_nether_bricks
fill 342 218 502 342 221 502 minecraft:pink_terracotta
setblock 343 218 464 minecraft:pink_terracotta
setblock 344 218 504 minecraft:red_nether_bricks
setblock 345 218 502 minecraft:pink_terracotta
setblock 345 218 503 minecraft:red_nether_bricks
fill 345 218 504 345 221 504 minecraft:pink_terracotta
fill 346 218 503 346 221 503 minecraft:pink_terracotta
setblock 348 218 504 minecraft:white_concrete
setblock 352 218 464 minecraft:white_concrete
setblock 367 218 504 minecraft:white_concrete
setblock 368 218 475 minecraft:red_nether_bricks
fill 368 218 476 368 220 476 minecraft:pink_terracotta
setblock 369 218 474 minecraft:red_nether_bricks
fill 369 218 475 369 221 475 minecraft:pink_terracotta
setblock 369 218 479 minecraft:red_nether_bricks
setblock 370 218 473 minecraft:red_nether_bricks
fill 370 218 474 370 221 474 minecraft:pink_terracotta
setblock 370 218 478 minecraft:red_nether_bricks
fill 370 218 479 370 221 479 minecraft:pink_terracotta
fill 370 218 481 370 219 481 minecraft:pink_terracotta
setblock 370 218 490 minecraft:white_concrete
setblock 330 219 473 minecraft:pink_terracotta
setblock 330 219 477 minecraft:red_nether_bricks
fill 330 219 478 330 222 478 minecraft:pink_terracotta
setblock 330 219 484 minecraft:white_concrete
fill 330 219 492 330 219 493 minecraft:white_concrete
setblock 330 219 497 minecraft:red_nether_bricks
fill 330 219 498 330 219 501 minecraft:pink_terracotta
setblock 330 219 502 minecraft:red_nether_bricks
fill 330 219 503 330 221 504 minecraft:pink_terracotta
fill 331 219 491 333 220 491 minecraft:white_concrete
fill 331 219 493 331 219 494 minecraft:white_concrete
fill 331 219 504 332 219 504 minecraft:pink_terracotta
fill 332 219 494 333 219 494 minecraft:white_concrete
fill 333 219 475 333 220 476 minecraft:white_concrete
fill 333 219 493 333 221 493 minecraft:white_concrete
setblock 333 219 504 minecraft:red_nether_bricks
fill 334 219 474 335 220 474 minecraft:white_concrete
fill 334 219 477 335 220 477 minecraft:white_concrete
setblock 334 219 492 minecraft:white_concrete
fill 334 219 504 334 222 504 minecraft:pink_terracotta
fill 335 219 503 335 222 503 minecraft:pink_terracotta
fill 336 219 464 337 219 464 minecraft:pink_terracotta
fill 336 219 475 336 219 476 minecraft:white_concrete
fill 337 219 502 339 219 502 minecraft:pink_terracotta
setblock 338 219 464 minecraft:red_nether_bricks
setblock 338 219 504 minecraft:red_nether_bricks
fill 339 219 464 339 222 464 minecraft:pink_terracotta
fill 339 219 501 340 219 501 minecraft:pink_terracotta
setblock 339 219 503 minecraft:red_nether_bricks
fill 339 219 504 339 222 504 minecraft:pink_terracotta
fill 340 219 480 340 220 482 minecraft:white_concrete
setblock 340 219 502 minecraft:red_nether_bricks
fill 340 219 503 340 222 503 minecraft:pink_terracotta
fill 341 219 480 342 220 480 minecraft:white_concrete
fill 341 219 483 342 219 483 minecraft:white_concrete
setblock 341 219 501 minecraft:red_nether_bricks
fill 341 219 502 341 222 502 minecraft:pink_terracotta
fill 342 219 482 343 219 482 minecraft:white_concrete
fill 342 219 501 343 221 501 minecraft:pink_terracotta
setblock 343 219 464 minecraft:red_nether_bricks
setblock 343 219 481 minecraft:white_concrete
setblock 343 219 504 minecraft:red_nether_bricks
setblock 344 219 503 minecraft:red_nether_bricks
fill 344 219 504 344 222 504 minecraft:pink_terracotta
setblock 345 219 502 minecraft:red_nether_bricks
fill 345 219 503 345 222 503 minecraft:pink_terracotta
setblock 346 219 464 minecraft:white_concrete
fill 347 219 503 347 220 503 minecraft:pink_terracotta
setblock 348 219 504 minecraft:red_nether_bricks
setblock 354 219 504 minecraft:white_concrete
fill 359 219 504 362 219 504 minecraft:pink_terracotta
fill 361 219 464 362 219 464 minecraft:pink_terracotta
setblock 363 219 464 minecraft:red_nether_bricks
setblock 363 219 504 minecraft:red_nether_bricks
fill 364 219 464 365 221 464 minecraft:pink_terracotta
fill 364 219 504 365 221 504 minecraft:pink_terracotta
setblock 368 219 475 minecraft:pink_terracotta
setblock 369 219 473 minecraft:red_nether_bricks
fill 369 219 474 369 222 474 minecraft:pink_terracotta
setblock 369 219 478 minecraft:red_nether_bricks
fill 369 219 479 369 222 479 minecraft:pink_terracotta
setblock 370 219 465 minecraft:white_concrete
setblock 370 219 472 minecraft:red_nether_bricks
fill 370 219 473 370 222 473 minecraft:pink_terracotta
setblock 370 219 477 minecraft:red_nether_bricks
fill 370 219 478 370 222 478 minecraft:pink_terracotta
setblock 370 219 484 minecraft:white_concrete
setblock 330 220 465 minecraft:white_concrete
setblock 330 220 476 minecraft:red_nether_bricks
fill 330 220 477 330 222 477 minecraft:pink_terracotta
setblock 330 220 490 minecraft:white_concrete
fill 330 220 497 330 220 500 minecraft:pink_terracotta
setblock 330 220 501 minecraft:red_nether_bricks
fill 330 220 502 330 222 502 minecraft:pink_terracotta
fill 331 220 493 331 221 493 minecraft:white_concrete
fill 331 220 501 331 222 501 minecraft:pink_terracotta
setblock 331 220 504 minecraft:pink_terracotta
setblock 332 220 494 minecraft:white_concrete
setblock 332 220 504 minecraft:red_nether_bricks
setblock 333 220 503 minecraft:red_nether_bricks
fill 333 220 504 333 222 504 minecraft:pink_terracotta
fill 334 220 464 336 220 464 minecraft:pink_terracotta
fill 334 220 503 334 222 503 minecraft:pink_terracotta
fill 335 220 502 338 220 502 minecraft:pink_terracotta
setblock 337 220 464 minecraft:red_nether_bricks
fill 337 220 501 339 220 501 minecraft:pink_terracotta
setblock 337 220 504 minecraft:red_nether_bricks
fill 338 220 464 338 222 464 minecraft:pink_terracotta
setblock 338 220 503 minecraft:red_nether_bricks
fill 338 220 504 338 222 504 minecraft:pink_terracotta
setblock 339 220 502 minecraft:red_nether_bricks
fill 339 220 503 339 222 503 minecraft:pink_terracotta
setblock 340 220 501 minecraft:red_nether_bricks
fill 340 220 502 340 222 502 minecraft:pink_terracotta
fill 341 220 501 341 222 501 minecraft:pink_terracotta
setblock 342 220 464 minecraft:red_nether_bricks
fill 342 220 482 342 221 482 minecraft:white_concrete
setblock 342 220 504 minecraft:red_nether_bricks
fill 343 220 464 344 222 464 minecraft:pink_terracotta
setblock 343 220 503 minecraft:red_nether_bricks
fill 343 220 504 343 222 504 minecraft:pink_terracotta
setblock 344 220 501 minecraft:pink_terracotta
setblock 344 220 502 minecraft:red_nether_bricks
fill 344 220 503 344 222 503 minecraft:pink_terracotta
fill 345 220 502 346 222 502 minecraft:pink_terracotta
setblock 347 220 504 minecraft:red_nether_bricks
fill 348 220 504 348 222 504 minecraft:pink_terracotta
setblock 357 220 504 minecraft:red_nether_bricks
fill 358 220 504 361 220 504 minecraft:pink_terracotta
fill 359 220 464 361 220 464 minecraft:pink_terracotta
fill 360 220 503 362 220 503 minecraft:pink_terracotta
setblock 362 220 464 minecraft:red_nether_bricks
setblock 362 220 504 minecraft:red_nether_bricks
fill 363 220 464 363 222 464 minecraft:pink_terracotta
setblock 363 220 503 minecraft:red_nether_bricks
fill 363 220 504 363 222 504 minecraft:pink_terracotta
setblock 366 220 464 minecraft:pink_terracotta
setblock 366 220 504 minecraft:pink_terracotta
setblock 367 220 464 minecraft:red_nether_bricks
setblock 369 220 473 minecraft:pink_terracotta
setblock 369 220 477 minecraft:red_nether_bricks
fill 369 220 478 369 222 478 minecraft:pink_terracotta
fill 369 220 480 369 221 480 minecraft:pink_terracotta
setblock 370 220 471 minecraft:red_nether_bricks
fill 370 220 472 370 222 472 minecraft:pink_terracotta
setblock 370 220 476 minecraft:red_nether_bricks
fill 370 220 477 370 222 477 minecraft:pink_terracotta
setblock 370 220 481 minecraft:red_nether_bricks
fill 370 220 482 370 222 482 minecraft:pink_terracotta
setblock 370 220 503 minecraft:white_concrete
setblock 330 221 464 minecraft:pink_terracotta
setblock 330 221 471 minecraft:white_concrete
setblock 330 221 475 minecraft:red_nether_bricks
fill 330 221 476 330 222 476 minecraft:pink_terracotta
setblock 330 221 479 minecraft:pink_terracotta
setblock 330 221 496 minecraft:white_concrete
fill 330 221 497 330 221 499 minecraft:pink_terracotta
setblock 330 221 500 minecraft:red_nether_bricks
fill 330 221 501 330 222 501 minecraft:pink_terracotta
setblock 331 221 464 minecraft:red_nether_bricks
setblock 331 221 499 minecraft:red_nether_bricks
fill 331 221 500 331 222 500 minecraft:pink_terracotta
fill 331 221 502 331 221 503 minecraft:pink_terracotta
setblock 331 221 504 minecraft:red_nether_bricks
fill 332 221 464 335 221 464 minecraft:pink_terracotta
setblock 332 221 491 minecraft:white_concrete
setblock 332 221 503 minecraft:red_nether_bricks
fill 332 221 504 332 222 504 minecraft:pink_terracotta
fill 333 221 503 333 222 503 minecraft:pink_terracotta
fill 334 221 502 337 221 502 minecraft:pink_terracotta
setblock 336 221 464 minecraft:red_nether_bricks
fill 336 221 501 338 221 501 minecraft:pink_terracotta
setblock 336 221 503 minecraft:pink_terracotta
setblock 336 221 504 minecraft:red_nether_bricks
fill 337 221 464 337 222 464 minecraft:pink_terracotta
setblock 337 221 503 minecraft:red_nether_bricks
fill 337 221 504 337 222 504 minecraft:pink_terracotta
setblock 338 221 502 minecraft:red_nether_bricks
fill 338 221 503 338 222 503 minecraft:pink_terracotta
setblock 339 221 500 minecraft:pink_terracotta
setblock 339 221 501 minecraft:red_nether_bricks
fill 339 221 502 339 222 502 minecraft:pink_terracotta
setblock 340 221 481 minecraft:white_concrete
setblock 340 221 500 minecraft:red_nether_bricks
fill 340 221 501 340 222 501 minecraft:pink_terracotta
setblock 341 221 464 minecraft:red_nether_bricks
setblock 341 221 480 minecraft:white_concrete
fill 341 221 500 341 222 500 minecraft:pink_terracotta
setblock 341 221 504 minecraft:red_nether_bricks
fill 342 221 464 342 222 464 minecraft:pink_terracotta
setblock 342 221 503 minecraft:red_nether_bricks
fill 342 221 504 342 222 504 minecraft:pink_terracotta
setblock 343 221 502 minecraft:red_nether_bricks
fill 343 221 503 343 222 503 minecraft:pink_terracotta
setblock 344 221 501 minecraft:red_nether_bricks
fill 344 221 502 344 222 502 minecraft:pink_terracotta
setblock 346 221 504 minecraft:red_nether_bricks
setblock 347 221 503 minecraft:red_nether_bricks
fill 347 221 504 347 222 504 minecraft:pink_terracotta
fill 349 221 504 349 222 504 minecraft:pink_terracotta
setblock 355 221 504 minecraft:pink_terracotta
setblock 356 221 504 minecraft:red_nether_bricks
setblock 357 221 503 minecraft:red_nether_bricks
fill 357 221 504 360 221 504 minecraft:pink_terracotta
fill 358 221 464 360 221 464 minecraft:pink_terracotta
fill 358 221 503 361 221 503 minecraft:pink_terracotta
setblock 361 221 464 minecraft:red_nether_bricks
setblock 361 221 504 minecraft:red_nether_bricks
fill 362 221 464 362 222 464 minecraft:pink_terracotta
setblock 362 221 503 minecraft:red_nether_bricks
fill 362 221 504 362 222 504 minecraft:pink_terracotta
fill 363 221 503 364 222 503 minecraft:pink_terracotta
setblock 366 221 464 minecraft:red_nether_bricks
setblock 366 221 504 minecraft:red_nether_bricks
fill 367 221 464 370 221 464 minecraft:pink_terracotta
fill 367 221 504 368 222 504 minecraft:pink_terracotta
setblock 368 221 477 minecraft:red_nether_bricks
setblock 369 221 476 minecraft:red_nether_bricks
fill 369 221 477 369 222 477 minecraft:pink_terracotta
setblock 370 221 470 minecraft:red_nether_bricks
fill 370 221 471 370 222 471 minecraft:pink_terracotta
setblock 370 221 475 minecraft:red_nether_bricks
fill 370 221 476 370 222 476 minecraft:pink_terracotta
setblock 370 221 480 minecraft:red_nether_bricks
fill 370 221 481 370 222 481 minecraft:pink_terracotta
setblock 370 221 497 minecraft:white_concrete
setblock 370 221 500 minecraft:red_nether_bricks
fill 370 221 501 370 222 503 minecraft:pink_terracotta
setblock 330 222 464 minecraft:red_nether_bricks
setblock 330 222 465 minecraft:pink_terracotta
setblock 330 222 475 minecraft:pink_terracotta
setblock 330 222 479 minecraft:red_nether_bricks
setblock 330 222 480 minecraft:pink_terracotta
fill 330 222 496 330 222 498 minecraft:pink_terracotta
setblock 330 222 499 minecraft:red_nether_bricks
setblock 330 222 500 minecraft:pink_terracotta
setblock 330 222 503 minecraft:pink_terracotta
setblock 330 222 504 minecraft:red_nether_bricks
fill 331 222 464 334 222 464 minecraft:pink_terracotta
setblock 331 222 498 minecraft:red_nether_bricks
setblock 331 222 499 minecraft:pink_terracotta
setblock 331 222 502 minecraft:pink_terracotta
setblock 331 222 503 minecraft:red_nether_bricks
setblock 331 222 504 minecraft:pink_terracotta
setblock 332 222 501 minecraft:pink_terracotta
setblock 332 222 502 minecraft:red_nether_bricks
setblock 332 222 503 minecraft:pink_terracotta
fill 333 222 502 336 222 502 minecraft:pink_terracotta
setblock 335 222 464 minecraft:red_nether_bricks
fill 335 222 501 337 222 501 minecraft:pink_terracotta
setblock 335 222 504 minecraft:red_nether_bricks
fill 336 222 464 336 222 465 minecraft:pink_terracotta
setblock 336 222 503 minecraft:red_nether_bricks
setblock 336 222 504 minecraft:pink_terracotta
fill 337 222 465 338 222 465 minecraft:pink_terracotta
setblock 337 222 502 minecraft:red_nether_bricks
setblock 337 222 503 minecraft:pink_terracotta
setblock 338 222 500 minecraft:pink_terracotta
setblock 338 222 501 minecraft:red_nether_bricks
setblock 338 222 502 minecraft:pink_terracotta
setblock 339 222 465 minecraft:red_nether_bricks
setblock 339 222 500 minecraft:red_nether_bricks
setblock 339 222 501 minecraft:pink_terracotta
setblock 340 222 464 minecraft:red_nether_bricks
setblock 340 222 465 minecraft:pink_terracotta
setblock 340 222 500 minecraft:pink_terracotta
setblock 340 222 504 minecraft:red_nether_bricks
setblock 341 222 464 minecraft:pink_terracotta
setblock 341 222 503 minecraft:red_nether_bricks
setblock 341 222 504 minecraft:pink_terracotta
setblock 342 222 501 minecraft:pink_terracotta
setblock 342 222 502 minecraft:red_nether_bricks
setblock 342 222 503 minecraft:pink_terracotta
setblock 343 222 501 minecraft:red_nether_bricks
setblock 343 222 502 minecraft:pink_terracotta
setblock 344 222 501 minecraft:pink_terracotta
setblock 345 222 504 minecraft:red_nether_bricks
setblock 346 222 503 minecraft:red_nether_bricks
setblock 346 222 504 minecraft:pink_terracotta
fill 347 222 503 348 222 503 minecraft:pink_terracotta
setblock 350 222 504 minecraft:red_nether_bricks
fill 351 222 504 354 222 504 minecraft:pink_terracotta
setblock 353 222 464 minecraft:white_concrete
setblock 355 222 503 minecraft:pink_terracotta
setblock 355 222 504 minecraft:red_nether_bricks
fill 356 222 464 359 222 464 minecraft:pink_terracotta
setblock 356 222 503 minecraft:red_nether_bricks
fill 356 222 504 359 222 504 minecraft:pink_terracotta
fill 357 222 503 360 222 503 minecraft:pink_terracotta
setblock 359 222 465 minecraft:red_nether_bricks
fill 359 222 502 361 222 502 minecraft:pink_terracotta
setblock 360 222 464 minecraft:red_nether_bricks
fill 360 222 465 363 222 465 minecraft:pink_terracotta
setblock 360 222 504 minecraft:red_nether_bricks
setblock 361 222 464 minecraft:pink_terracotta
setblock 361 222 503 minecraft:red_nether_bricks
setblock 361 222 504 minecraft:pink_terracotta
setblock 362 222 503 minecraft:pink_terracotta
setblock 364 222 464 minecraft:pink_terracotta
setblock 364 222 465 minecraft:red_nether_bricks
setblock 364 222 504 minecraft:pink_terracotta
setblock 365 222 464 minecraft:red_nether_bricks
setblock 365 222 503 minecraft:pink_terracotta
setblock 365 222 504 minecraft:red_nether_bricks
fill 366 222 464 369 222 464 minecraft:pink_terracotta
setblock 366 222 504 minecraft:pink_terracotta
setblock 369 222 475 minecraft:red_nether_bricks
setblock 369 222 476 minecraft:pink_terracotta
setblock 369 222 480 minecraft:red_nether_bricks
setblock 369 222 481 minecraft:pink_terracotta
setblock 369 222 504 minecraft:pink_terracotta
setblock 370 222 464 minecraft:red_nether_bricks
fill 370 222 465 370 222 466 minecraft:pink_terracotta
setblock 370 222 470 minecraft:pink_terracotta
setblock 370 222 474 minecraft:red_nether_bricks
setblock 370 222 475 minecraft:pink_terracotta
setblock 370 222 479 minecraft:red_nether_bricks
setblock 370 222 480 minecraft:pink_terracotta
setblock 370 222 483 minecraft:pink_terracotta
setblock 370 222 491 minecraft:white_concrete
setblock 370 222 499 minecraft:red_nether_bricks
setblock 370 222 500 minecraft:pink_terracotta
setblock 370 222 504 minecraft:red_nether_bricks
setblock 332 223 466 minecraft:light[level=12]
setblock 332 223 474 minecraft:light[level=12]
setblock 332 223 482 minecraft:light[level=12]
setblock 332 223 490 minecraft:light[level=12]
setblock 332 223 498 minecraft:light[level=12]
setblock 340 223 466 minecraft:light[level=12]
setblock 340 223 474 minecraft:light[level=12]
setblock 340 223 482 minecraft:light[level=12]
setblock 340 223 490 minecraft:light[level=12]
setblock 340 223 498 minecraft:light[level=12]
setblock 348 223 466 minecraft:light[level=12]
setblock 348 223 474 minecraft:light[level=12]
setblock 348 223 482 minecraft:light[level=12]
setblock 348 223 490 minecraft:light[level=12]
setblock 348 223 498 minecraft:light[level=12]
setblock 356 223 466 minecraft:light[level=12]
setblock 356 223 474 minecraft:light[level=12]
setblock 356 223 482 minecraft:light[level=12]
setblock 356 223 490 minecraft:light[level=12]
setblock 356 223 498 minecraft:light[level=12]
setblock 364 223 466 minecraft:light[level=12]
setblock 364 223 474 minecraft:light[level=12]
setblock 364 223 482 minecraft:light[level=12]
setblock 364 223 490 minecraft:light[level=12]
setblock 364 223 498 minecraft:light[level=12]
fill 332 228 485 333 229 485 minecraft:red_terracotta
fill 333 228 482 334 229 484 minecraft:red_terracotta
fill 333 228 486 334 229 488 minecraft:red_terracotta
fill 334 228 480 335 229 481 minecraft:red_terracotta
fill 334 228 485 342 229 485 minecraft:white_concrete
fill 334 228 489 335 229 490 minecraft:red_terracotta
fill 335 228 479 337 229 479 minecraft:red_terracotta
fill 335 228 482 342 229 484 minecraft:white_concrete
fill 335 228 486 342 229 488 minecraft:white_concrete
fill 335 228 491 337 229 491 minecraft:red_terracotta
fill 336 228 478 339 229 478 minecraft:red_terracotta
fill 336 228 480 336 229 480 minecraft:red_terracotta
fill 336 228 481 344 229 481 minecraft:white_concrete
fill 336 228 489 344 229 489 minecraft:white_concrete
fill 336 228 490 336 229 490 minecraft:red_terracotta
fill 336 228 492 339 229 492 minecraft:red_terracotta
fill 337 228 477 341 229 477 minecraft:red_terracotta
fill 337 228 480 345 229 480 minecraft:white_concrete
fill 337 228 490 345 229 490 minecraft:white_concrete
fill 337 228 493 341 229 493 minecraft:red_terracotta
fill 338 228 479 343 229 479 minecraft:white_concrete
fill 338 228 491 343 229 491 minecraft:white_concrete
fill 339 228 476 345 229 476 minecraft:red_terracotta
fill 339 228 494 345 229 494 minecraft:red_terracotta
fill 340 228 478 358 229 478 minecraft:white_concrete
fill 340 228 492 358 229 492 minecraft:white_concrete
fill 342 228 475 356 229 475 minecraft:red_terracotta
fill 342 228 477 356 229 477 minecraft:white_concrete
fill 342 228 493 356 229 493 minecraft:white_concrete
fill 342 228 495 356 229 495 minecraft:red_terracotta
fill 343 228 482 343 229 483 minecraft:white_concrete
fill 343 228 484 344 229 484 minecraft:orange_concrete
fill 343 228 485 345 229 485 minecraft:red_concrete
fill 343 228 486 344 229 486 minecraft:orange_concrete
fill 343 228 487 343 229 488 minecraft:white_concrete
fill 344 228 479 344 229 479 minecraft:red_concrete
fill 344 228 482 344 229 482 minecraft:orange_concrete
fill 344 228 483 344 229 483 minecraft:red_concrete
fill 344 228 487 344 229 487 minecraft:red_concrete
fill 344 228 488 344 229 488 minecraft:orange_concrete
fill 344 228 491 344 229 491 minecraft:red_concrete
fill 345 228 479 347 229 479 minecraft:white_concrete
fill 345 228 481 345 229 482 minecraft:red_concrete
fill 345 228 483 345 229 483 minecraft:orange_concrete
fill 345 228 484 346 228 484 minecraft:red_concrete
fill 345 228 486 346 228 486 minecraft:red_concrete
fill 345 228 487 345 229 487 minecraft:orange_concrete
fill 345 228 488 345 229 489 minecraft:red_concrete
fill 345 228 491 347 229 491 minecraft:white_concrete
fill 346 228 474 352 229 474 minecraft:red_terracotta
fill 346 228 476 352 229 476 minecraft:white_concrete
fill 346 228 480 346 229 480 minecraft:red_concrete
fill 346 228 481 346 229 481 minecraft:orange_concrete
fill 346 228 482 346 229 483 minecraft:red_concrete
setblock 346 228 485 minecraft:black_concrete
fill 346 228 487 346 229 488 minecraft:red_concrete
fill 346 228 489 346 229 489 minecraft:orange_concrete
fill 346 228 490 346 229 490 minecraft:red_concrete
fill 346 228 494 352 229 494 minecraft:white_concrete
fill 346 228 496 352 229 496 minecraft:red_terracotta
fill 347 228 480 347 229 480 minecraft:orange_concrete
fill 347 228 481 347 229 482 minecraft:red_concrete
fill 347 228 483 347 228 484 minecraft:black_concrete
fill 347 228 486 347 228 487 minecraft:black_concrete
fill 347 228 488 347 229 489 minecraft:red_concrete
fill 347 228 490 347 229 490 minecraft:orange_concrete
fill 348 228 479 348 229 481 minecraft:red_concrete
setblock 348 228 482 minecraft:orange_concrete
setblock 348 228 483 minecraft:black_concrete
setblock 348 228 487 minecraft:black_concrete
setblock 348 228 488 minecraft:orange_concrete
fill 348 228 489 348 229 491 minecraft:red_concrete
fill 349 228 479 349 229 481 minecraft:orange_concrete
setblock 349 228 482 minecraft:black_concrete
setblock 349 228 488 minecraft:black_concrete
fill 349 228 489 349 229 491 minecraft:orange_concrete
fill 350 228 479 350 229 481 minecraft:red_concrete
setblock 350 228 482 minecraft:orange_concrete
fill 350 228 483 351 228 483 minecraft:black_concrete
fill 350 228 487 351 228 487 minecraft:black_concrete
setblock 350 228 488 minecraft:orange_concrete
fill 350 228 489 350 229 491 minecraft:red_concrete
fill 351 228 479 353 229 479 minecraft:white_concrete
fill 351 228 480 351 229 480 minecraft:orange_concrete
fill 351 228 481 351 229 482 minecraft:red_concrete
setblock 351 228 484 minecraft:black_concrete
setblock 351 228 486 minecraft:black_concrete
fill 351 228 488 351 229 489 minecraft:red_concrete
fill 351 228 490 351 229 490 minecraft:orange_concrete
fill 351 228 491 353 229 491 minecraft:white_concrete
fill 352 228 480 352 229 480 minecraft:red_concrete
fill 352 228 481 352 229 481 minecraft:orange_concrete
fill 352 228 482 352 228 484 minecraft:red_concrete
setblock 352 228 485 minecraft:black_concrete
fill 352 228 486 352 228 488 minecraft:red_concrete
fill 352 228 489 352 229 489 minecraft:orange_concrete
fill 352 228 490 352 229 490 minecraft:red_concrete
fill 353 228 476 359 229 476 minecraft:red_terracotta
fill 353 228 480 361 229 480 minecraft:white_concrete
fill 353 228 481 353 229 482 minecraft:red_concrete
fill 353 228 483 353 229 483 minecraft:orange_concrete
fill 353 228 484 353 229 486 minecraft:red_concrete
fill 353 228 487 353 229 487 minecraft:orange_concrete
fill 353 228 488 353 229 489 minecraft:red_concrete
fill 353 228 490 361 229 490 minecraft:white_concrete
fill 353 228 494 359 229 494 minecraft:red_terracotta
fill 354 228 479 354 229 479 minecraft:red_concrete
fill 354 228 481 362 229 481 minecraft:white_concrete
fill 354 228 482 354 229 482 minecraft:orange_concrete
fill 354 228 483 354 229 483 minecraft:red_concrete
fill 354 228 484 355 229 484 minecraft:orange_concrete
fill 354 228 485 355 229 485 minecraft:red_concrete
fill 354 228 486 355 229 486 minecraft:orange_concrete
fill 354 228 487 354 229 487 minecraft:red_concrete
fill 354 228 488 354 229 488 minecraft:orange_concrete
fill 354 228 489 362 229 489 minecraft:white_concrete
fill 354 228 491 354 229 491 minecraft:red_concrete
fill 355 228 479 360 229 479 minecraft:white_concrete
fill 355 228 482 363 229 483 minecraft:white_concrete
fill 355 228 487 363 229 488 minecraft:white_concrete
fill 355 228 491 360 229 491 minecraft:white_concrete
fill 356 228 484 363 229 486 minecraft:white_concrete
fill 357 228 477 361 229 477 minecraft:red_terracotta
fill 357 228 493 361 229 493 minecraft:red_terracotta
fill 359 228 478 362 229 478 minecraft:red_terracotta
fill 359 228 492 362 229 492 minecraft:red_terracotta
fill 361 228 479 363 229 479 minecraft:red_terracotta
fill 361 228 491 363 229 491 minecraft:red_terracotta
fill 362 228 480 364 229 480 minecraft:red_terracotta
fill 362 228 490 364 229 490 minecraft:red_terracotta
fill 363 228 481 364 229 481 minecraft:red_terracotta
fill 363 228 489 364 229 489 minecraft:red_terracotta
fill 364 228 482 365 229 484 minecraft:red_terracotta
fill 364 228 485 364 229 485 minecraft:white_concrete
fill 364 228 486 365 229 488 minecraft:red_terracotta
fill 365 228 485 366 229 485 minecraft:red_terracotta
fill 330 229 464 331 229 504 minecraft:red_terracotta
fill 332 229 464 332 229 484 minecraft:red_terracotta
fill 332 229 486 332 229 504 minecraft:red_terracotta
fill 333 229 464 333 229 481 minecraft:red_terracotta
fill 333 229 489 333 229 504 minecraft:red_terracotta
fill 334 229 464 334 229 479 minecraft:red_terracotta
fill 334 229 491 334 229 504 minecraft:red_terracotta
fill 335 229 464 335 229 478 minecraft:red_terracotta
fill 335 229 492 335 229 504 minecraft:red_terracotta
fill 336 229 464 336 229 477 minecraft:red_terracotta
fill 336 229 493 336 229 504 minecraft:red_terracotta
fill 337 229 464 338 229 476 minecraft:red_terracotta
fill 337 229 494 338 229 504 minecraft:red_terracotta
fill 339 229 464 341 229 475 minecraft:red_terracotta
fill 339 229 495 341 229 504 minecraft:red_terracotta
fill 342 229 464 345 229 474 minecraft:red_terracotta
fill 342 229 496 345 229 504 minecraft:red_terracotta
setblock 345 229 484 minecraft:red_concrete
setblock 345 229 486 minecraft:red_concrete
fill 346 229 464 370 229 473 minecraft:red_terracotta
fill 346 229 484 346 229 486 minecraft:shroomlight
fill 346 229 497 370 229 504 minecraft:red_terracotta
fill 347 229 483 347 229 484 minecraft:shroomlight
fill 347 229 486 347 229 487 minecraft:shroomlight
fill 348 229 482 348 229 483 minecraft:shroomlight
fill 348 229 487 348 229 488 minecraft:shroomlight
fill 349 229 482 350 229 482 minecraft:shroomlight
fill 349 229 488 350 229 488 minecraft:shroomlight
fill 350 229 483 351 229 483 minecraft:shroomlight
fill 350 229 487 351 229 487 minecraft:shroomlight
fill 351 229 484 352 229 484 minecraft:shroomlight
fill 351 229 486 352 229 486 minecraft:shroomlight
fill 352 229 482 352 229 483 minecraft:red_concrete
setblock 352 229 485 minecraft:shroomlight
fill 352 229 487 352 229 488 minecraft:red_concrete
fill 353 229 474 370 229 474 minecraft:red_terracotta
fill 353 229 496 370 229 496 minecraft:red_terracotta
fill 357 229 475 370 229 475 minecraft:red_terracotta
fill 357 229 495 370 229 495 minecraft:red_terracotta
fill 360 229 476 370 229 476 minecraft:red_terracotta
fill 360 229 494 370 229 494 minecraft:red_terracotta
fill 362 229 477 370 229 477 minecraft:red_terracotta
fill 362 229 493 370 229 493 minecraft:red_terracotta
fill 363 229 478 370 229 478 minecraft:red_terracotta
fill 363 229 492 370 229 492 minecraft:red_terracotta
fill 364 229 479 370 229 479 minecraft:red_terracotta
fill 364 229 491 370 229 491 minecraft:red_terracotta
fill 365 229 480 370 229 481 minecraft:red_terracotta
fill 365 229 489 370 229 490 minecraft:red_terracotta
fill 366 229 482 370 229 484 minecraft:red_terracotta
fill 366 229 486 370 229 488 minecraft:red_terracotta
fill 367 229 485 370 229 485 minecraft:red_terracotta
setblock 332 231 466 minecraft:light[level=12]
setblock 332 231 474 minecraft:light[level=12]
setblock 332 231 482 minecraft:light[level=12]
setblock 332 231 490 minecraft:light[level=12]
setblock 332 231 498 minecraft:light[level=12]
setblock 340 231 466 minecraft:light[level=12]
setblock 340 231 474 minecraft:light[level=12]
setblock 340 231 482 minecraft:light[level=12]
setblock 340 231 490 minecraft:light[level=12]
setblock 340 231 498 minecraft:light[level=12]
setblock 348 231 466 minecraft:light[level=12]
setblock 348 231 474 minecraft:light[level=12]
setblock 348 231 482 minecraft:light[level=12]
setblock 348 231 490 minecraft:light[level=12]
setblock 348 231 498 minecraft:light[level=12]
setblock 356 231 466 minecraft:light[level=12]
setblock 356 231 474 minecraft:light[level=12]
setblock 356 231 482 minecraft:light[level=12]
setblock 356 231 490 minecraft:light[level=12]
setblock 356 231 498 minecraft:light[level=12]
setblock 364 231 466 minecraft:light[level=12]
setblock 364 231 474 minecraft:light[level=12]
setblock 364 231 482 minecraft:light[level=12]
setblock 364 231 490 minecraft:light[level=12]
setblock 364 231 498 minecraft:light[level=12]
fill 330 233 464 330 233 467 minecraft:pink_terracotta
setblock 330 233 468 minecraft:red_nether_bricks
fill 330 233 469 330 235 470 minecraft:pink_terracotta
setblock 330 233 480 minecraft:white_concrete
setblock 330 233 483 minecraft:red_nether_bricks
fill 330 233 484 330 233 487 minecraft:pink_terracotta
setblock 330 233 488 minecraft:red_nether_bricks
fill 330 233 489 330 233 492 minecraft:pink_terracotta
setblock 330 233 493 minecraft:red_nether_bricks
fill 330 233 494 330 233 497 minecraft:pink_terracotta
setblock 330 233 498 minecraft:red_nether_bricks
fill 330 233 499 330 233 502 minecraft:pink_terracotta
setblock 330 233 503 minecraft:red_nether_bricks
fill 330 233 504 333 233 504 minecraft:pink_terracotta
fill 331 233 464 331 233 466 minecraft:pink_terracotta
setblock 331 233 467 minecraft:red_nether_bricks
fill 331 233 468 331 236 468 minecraft:pink_terracotta
fill 331 233 484 331 233 486 minecraft:pink_terracotta
setblock 331 233 487 minecraft:red_nether_bricks
fill 331 233 488 331 233 491 minecraft:pink_terracotta
setblock 331 233 492 minecraft:red_nether_bricks
fill 331 233 493 331 234 495 minecraft:pink_terracotta
fill 331 233 499 331 233 501 minecraft:pink_terracotta
setblock 331 233 502 minecraft:red_nether_bricks
fill 331 233 503 334 233 503 minecraft:pink_terracotta
fill 332 233 464 332 233 465 minecraft:pink_terracotta
setblock 332 233 486 minecraft:red_nether_bricks
fill 332 233 487 332 233 490 minecraft:pink_terracotta
setblock 332 233 491 minecraft:red_nether_bricks
setblock 333 233 464 minecraft:pink_terracotta
setblock 333 233 465 minecraft:red_nether_bricks
setblock 334 233 464 minecraft:red_nether_bricks
fill 334 233 465 337 233 465 minecraft:pink_terracotta
setblock 334 233 504 minecraft:red_nether_bricks
fill 335 233 464 338 233 464 minecraft:pink_terracotta
setblock 335 233 503 minecraft:red_nether_bricks
fill 335 233 504 338 233 504 minecraft:pink_terracotta
fill 336 233 503 337 233 503 minecraft:pink_terracotta
setblock 339 233 464 minecraft:red_nether_bricks
setblock 339 233 504 minecraft:red_nether_bricks
setblock 340 233 504 minecraft:pink_terracotta
fill 344 233 464 344 234 464 minecraft:white_concrete
setblock 348 233 464 minecraft:pink_terracotta
setblock 349 233 464 minecraft:red_nether_bricks
fill 350 233 464 352 233 465 minecraft:pink_terracotta
setblock 350 233 504 minecraft:white_concrete
fill 351 233 504 353 233 504 minecraft:pink_terracotta
setblock 352 233 466 minecraft:red_nether_bricks
setblock 353 233 464 minecraft:pink_terracotta
setblock 353 233 465 minecraft:red_nether_bricks
fill 353 233 466 356 233 466 minecraft:pink_terracotta
setblock 354 233 464 minecraft:red_nether_bricks
fill 354 233 465 357 233 465 minecraft:pink_terracotta
setblock 354 233 504 minecraft:red_nether_bricks
schedule function dropper:buildpart/115_8 1t
