fill 524 299 323 524 300 323 minecraft:stripped_dark_oak_log
fill 524 299 325 524 300 325 minecraft:stripped_dark_oak_log
fill 524 299 327 524 300 327 minecraft:stripped_dark_oak_log
fill 525 299 324 525 300 324 minecraft:stripped_dark_oak_log
fill 525 299 326 525 300 326 minecraft:stripped_dark_oak_log
fill 525 299 328 525 300 328 minecraft:stripped_dark_oak_log
fill 526 299 323 526 300 323 minecraft:stripped_dark_oak_log
fill 526 299 325 526 300 325 minecraft:stripped_dark_oak_log
fill 526 299 327 526 300 327 minecraft:stripped_dark_oak_log
fill 527 299 324 527 300 324 minecraft:stripped_dark_oak_log
fill 527 299 326 527 300 326 minecraft:stripped_dark_oak_log
fill 527 299 328 527 300 328 minecraft:stripped_dark_oak_log
fill 529 299 323 529 300 323 minecraft:stripped_dark_oak_log
fill 530 299 363 530 300 363 minecraft:stripped_dark_oak_log
fill 536 299 323 536 300 323 minecraft:stripped_dark_oak_log
fill 537 299 363 537 300 363 minecraft:stripped_dark_oak_log
fill 541 299 325 549 299 328 minecraft:red_concrete
fill 543 299 323 543 300 323 minecraft:stripped_dark_oak_log
fill 544 299 363 544 300 363 minecraft:stripped_dark_oak_log
fill 550 299 323 550 300 323 minecraft:stripped_dark_oak_log
fill 551 299 363 551 300 363 minecraft:stripped_dark_oak_log
fill 557 299 323 557 300 323 minecraft:stripped_dark_oak_log
fill 558 299 343 558 300 343 minecraft:stripped_dark_oak_log
fill 558 299 350 558 300 350 minecraft:stripped_dark_oak_log
fill 558 299 357 558 300 357 minecraft:stripped_dark_oak_log
fill 558 299 363 558 300 363 minecraft:stripped_dark_oak_log
fill 518 300 329 518 300 332 minecraft:stripped_dark_oak_log
setblock 518 300 334 minecraft:stripped_dark_oak_log
fill 518 300 336 518 300 339 minecraft:stripped_dark_oak_log
setblock 518 300 341 minecraft:stripped_dark_oak_log
fill 518 300 343 518 300 346 minecraft:stripped_dark_oak_log
setblock 518 300 348 minecraft:stripped_dark_oak_log
fill 518 300 350 518 300 353 minecraft:stripped_dark_oak_log
setblock 518 300 355 minecraft:stripped_dark_oak_log
fill 518 300 357 518 300 360 minecraft:stripped_dark_oak_log
setblock 518 300 362 minecraft:stripped_dark_oak_log
fill 519 300 363 522 300 363 minecraft:stripped_dark_oak_log
setblock 520 300 333 minecraft:light[level=14]
setblock 520 300 341 minecraft:light[level=14]
setblock 520 300 349 minecraft:light[level=14]
setblock 520 300 357 minecraft:light[level=14]
setblock 524 300 363 minecraft:stripped_dark_oak_log
fill 526 300 363 529 300 363 minecraft:stripped_dark_oak_log
setblock 528 300 323 minecraft:stripped_dark_oak_log
setblock 528 300 325 minecraft:light[level=14]
setblock 528 300 333 minecraft:light[level=14]
setblock 528 300 341 minecraft:light[level=14]
setblock 528 300 349 minecraft:light[level=14]
setblock 528 300 357 minecraft:light[level=14]
fill 530 300 323 533 300 323 minecraft:stripped_dark_oak_log
setblock 531 300 363 minecraft:stripped_dark_oak_log
fill 533 300 363 536 300 363 minecraft:stripped_dark_oak_log
setblock 535 300 323 minecraft:stripped_dark_oak_log
setblock 536 300 325 minecraft:light[level=14]
setblock 536 300 333 minecraft:light[level=14]
setblock 536 300 341 minecraft:light[level=14]
setblock 536 300 349 minecraft:light[level=14]
setblock 536 300 357 minecraft:light[level=14]
fill 537 300 323 540 300 323 minecraft:stripped_dark_oak_log
setblock 538 300 363 minecraft:stripped_dark_oak_log
fill 540 300 363 543 300 363 minecraft:stripped_dark_oak_log
setblock 542 300 323 minecraft:stripped_dark_oak_log
fill 542 300 326 548 300 327 minecraft:red_concrete
fill 544 300 323 547 300 323 minecraft:stripped_dark_oak_log
setblock 544 300 325 minecraft:light[level=14]
setblock 544 300 333 minecraft:light[level=14]
setblock 544 300 341 minecraft:light[level=14]
setblock 544 300 349 minecraft:light[level=14]
setblock 544 300 357 minecraft:light[level=14]
setblock 545 300 363 minecraft:stripped_dark_oak_log
fill 547 300 363 550 300 363 minecraft:stripped_dark_oak_log
setblock 549 300 323 minecraft:stripped_dark_oak_log
fill 551 300 323 554 300 323 minecraft:stripped_dark_oak_log
setblock 552 300 325 minecraft:light[level=14]
setblock 552 300 333 minecraft:light[level=14]
setblock 552 300 341 minecraft:light[level=14]
setblock 552 300 349 minecraft:light[level=14]
setblock 552 300 357 minecraft:light[level=14]
setblock 552 300 363 minecraft:stripped_dark_oak_log
fill 554 300 363 557 300 363 minecraft:stripped_dark_oak_log
setblock 556 300 323 minecraft:stripped_dark_oak_log
fill 558 300 323 558 300 326 minecraft:stripped_dark_oak_log
setblock 558 300 342 minecraft:stripped_dark_oak_log
fill 558 300 344 558 300 347 minecraft:stripped_dark_oak_log
setblock 558 300 349 minecraft:stripped_dark_oak_log
fill 558 300 351 558 300 354 minecraft:stripped_dark_oak_log
setblock 558 300 356 minecraft:stripped_dark_oak_log
fill 558 300 358 558 300 361 minecraft:stripped_dark_oak_log
