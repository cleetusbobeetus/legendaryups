setblock 31 150 278 minecraft:light[level=12]
setblock 31 150 285 minecraft:light[level=12]
setblock 31 150 292 minecraft:light[level=12]
setblock 31 150 299 minecraft:light[level=12]
setblock 31 150 306 minecraft:light[level=12]
setblock 31 150 313 minecraft:light[level=12]
setblock 38 150 278 minecraft:light[level=12]
setblock 38 150 285 minecraft:light[level=12]
setblock 38 150 292 minecraft:light[level=12]
setblock 38 150 299 minecraft:light[level=12]
setblock 38 150 306 minecraft:light[level=12]
setblock 38 150 313 minecraft:light[level=12]
fill 42 150 315 42 219 315 minecraft:blackstone
setblock 0 151 285 minecraft:magma_block
fill 0 151 286 0 160 287 minecraft:blackstone
fill 6 151 287 6 151 289 minecraft:red_nether_bricks
fill 6 151 290 7 153 291 minecraft:orange_terracotta
setblock 7 151 286 minecraft:red_nether_bricks
setblock 7 151 287 minecraft:nether_wart_block
setblock 8 151 284 minecraft:nether_wart_block
fill 8 151 285 8 153 285 minecraft:red_nether_bricks
fill 8 151 290 9 151 290 minecraft:red_nether_bricks
setblock 9 151 285 minecraft:nether_wart_block
fill 9 151 286 9 153 286 minecraft:red_nether_bricks
setblock 9 151 289 minecraft:orange_terracotta
setblock 10 151 283 minecraft:red_nether_bricks
fill 10 151 285 12 151 285 minecraft:red_nether_bricks
setblock 10 151 286 minecraft:nether_wart_block
fill 10 151 287 10 153 287 minecraft:red_nether_bricks
setblock 10 151 289 minecraft:red_nether_bricks
setblock 11 151 283 minecraft:nether_wart_block
fill 11 151 284 11 152 284 minecraft:red_nether_bricks
setblock 11 151 286 minecraft:red_nether_bricks
setblock 11 151 287 minecraft:nether_wart_block
fill 11 151 288 11 152 288 minecraft:red_nether_bricks
setblock 12 151 283 minecraft:red_nether_bricks
setblock 12 151 284 minecraft:nether_wart_block
setblock 13 151 282 minecraft:red_nether_bricks
setblock 13 151 285 minecraft:nether_wart_block
setblock 17 151 277 minecraft:amethyst_block
fill 18 151 275 18 217 275 minecraft:blackstone
fill 0 152 285 0 159 285 minecraft:blackstone
fill 1 152 275 1 216 275 minecraft:blackstone
setblock 2 152 275 minecraft:crying_obsidian
fill 5 152 289 5 152 291 minecraft:red_nether_bricks
fill 6 152 287 7 152 288 minecraft:red_nether_bricks
setblock 6 152 289 minecraft:nether_wart_block
fill 6 152 292 7 153 292 minecraft:orange_terracotta
setblock 6 152 293 minecraft:nether_wart_block
setblock 7 152 286 minecraft:nether_wart_block
fill 7 152 289 9 152 289 minecraft:red_nether_bricks
setblock 8 152 287 minecraft:nether_wart_block
setblock 8 152 288 minecraft:orange_terracotta
fill 8 152 290 8 152 291 minecraft:orange_terracotta
fill 8 152 292 8 154 292 minecraft:red_nether_bricks
setblock 9 152 284 minecraft:nether_wart_block
fill 9 152 285 9 153 285 minecraft:red_nether_bricks
setblock 9 152 287 minecraft:red_nether_bricks
setblock 9 152 288 minecraft:nether_wart_block
fill 9 152 290 9 152 291 minecraft:red_nether_bricks
setblock 10 152 285 minecraft:nether_wart_block
fill 10 152 286 10 153 286 minecraft:red_nether_bricks
setblock 10 152 289 minecraft:nether_wart_block
fill 11 152 285 12 152 285 minecraft:red_nether_bricks
setblock 11 152 286 minecraft:nether_wart_block
setblock 11 152 287 minecraft:red_nether_bricks
setblock 12 152 284 minecraft:red_nether_bricks
setblock 12 152 286 minecraft:red_nether_bricks
fill 16 152 275 17 155 275 minecraft:blackstone
setblock 42 152 311 minecraft:amethyst_block
fill 2 153 275 2 219 275 minecraft:blackstone
fill 5 153 289 5 153 290 minecraft:red_nether_bricks
setblock 5 153 291 minecraft:nether_wart_block
fill 5 153 292 5 153 293 minecraft:red_nether_bricks
fill 5 153 294 7 154 294 minecraft:orange_terracotta
fill 6 153 287 8 153 287 minecraft:red_nether_bricks
setblock 6 153 288 minecraft:nether_wart_block
fill 6 153 289 6 155 289 minecraft:red_nether_bricks
fill 6 153 293 6 154 293 minecraft:orange_terracotta
fill 6 153 295 6 155 295 minecraft:orange_terracotta
setblock 7 153 286 minecraft:red_nether_bricks
setblock 7 153 288 minecraft:red_nether_bricks
setblock 7 153 289 minecraft:nether_wart_block
setblock 7 153 293 minecraft:nether_wart_block
setblock 8 153 286 minecraft:nether_wart_block
fill 8 153 288 8 156 288 minecraft:bone_block
fill 8 153 289 10 153 289 minecraft:red_nether_bricks
setblock 8 153 290 minecraft:nether_wart_block
fill 8 153 291 8 155 291 minecraft:red_nether_bricks
setblock 8 153 293 minecraft:red_nether_bricks
setblock 9 153 287 minecraft:nether_wart_block
fill 9 153 288 9 154 288 minecraft:red_nether_bricks
setblock 9 153 290 minecraft:red_nether_bricks
setblock 9 153 291 minecraft:nether_wart_block
setblock 10 153 285 minecraft:red_nether_bricks
setblock 10 153 288 minecraft:nether_wart_block
setblock 11 153 286 minecraft:red_nether_bricks
fill 38 153 275 38 217 275 minecraft:blackstone
setblock 39 153 275 minecraft:magma_block
fill 40 153 275 40 185 275 minecraft:blackstone
fill 42 153 311 42 219 311 minecraft:blackstone
fill 4 154 291 5 154 292 minecraft:red_nether_bricks
setblock 4 154 293 minecraft:nether_wart_block
fill 4 154 294 4 155 295 minecraft:red_nether_bricks
setblock 5 154 289 minecraft:red_nether_bricks
setblock 5 154 290 minecraft:nether_wart_block
setblock 5 154 293 minecraft:orange_terracotta
fill 5 154 295 5 154 296 minecraft:orange_terracotta
setblock 6 154 288 minecraft:red_nether_bricks
fill 6 154 290 8 154 290 minecraft:red_nether_bricks
setblock 6 154 291 minecraft:nether_wart_block
fill 6 154 292 6 156 292 minecraft:red_nether_bricks
fill 6 154 296 6 155 296 minecraft:orange_terracotta
fill 7 154 287 9 154 287 minecraft:red_nether_bricks
setblock 7 154 288 minecraft:nether_wart_block
fill 7 154 289 7 155 289 minecraft:red_nether_bricks
setblock 7 154 291 minecraft:red_nether_bricks
setblock 7 154 292 minecraft:nether_wart_block
setblock 7 154 293 minecraft:orange_terracotta
fill 7 154 295 7 155 295 minecraft:orange_terracotta
setblock 7 154 296 minecraft:nether_wart_block
setblock 8 154 289 minecraft:nether_wart_block
setblock 8 154 293 minecraft:nether_wart_block
fill 8 154 294 8 156 294 minecraft:red_nether_bricks
setblock 9 154 289 minecraft:red_nether_bricks
setblock 9 154 290 minecraft:nether_wart_block
fill 9 154 291 9 154 292 minecraft:red_nether_bricks
fill 39 154 275 39 212 275 minecraft:blackstone
setblock 42 154 276 minecraft:magma_block
fill 0 155 277 0 184 277 minecraft:blackstone
setblock 0 155 278 minecraft:purple_concrete
fill 3 155 278 3 156 278 minecraft:light[level=12]
setblock 3 155 286 minecraft:light[level=12]
setblock 3 155 294 minecraft:light[level=12]
setblock 3 155 302 minecraft:light[level=12]
setblock 3 155 310 minecraft:light[level=12]
setblock 4 155 292 minecraft:nether_wart_block
fill 4 155 293 4 156 293 minecraft:red_nether_bricks
setblock 4 155 296 minecraft:nether_wart_block
fill 4 155 297 4 157 297 minecraft:red_nether_bricks
fill 5 155 290 5 155 292 minecraft:red_nether_bricks
setblock 5 155 293 minecraft:nether_wart_block
fill 5 155 294 5 155 295 minecraft:orange_terracotta
setblock 5 155 296 minecraft:red_nether_bricks
fill 5 155 297 7 156 298 minecraft:orange_terracotta
setblock 6 155 290 minecraft:nether_wart_block
fill 6 155 291 6 156 291 minecraft:red_nether_bricks
fill 6 155 293 8 155 293 minecraft:red_nether_bricks
setblock 6 155 294 minecraft:orange_terracotta
fill 6 155 299 6 157 299 minecraft:orange_terracotta
setblock 7 155 288 minecraft:red_nether_bricks
fill 7 155 290 8 155 290 minecraft:red_nether_bricks
setblock 7 155 291 minecraft:nether_wart_block
fill 7 155 292 7 157 292 minecraft:red_nether_bricks
setblock 7 155 294 minecraft:red_nether_bricks
fill 7 155 296 7 157 296 minecraft:red_nether_bricks
setblock 8 155 289 minecraft:red_nether_bricks
setblock 8 155 292 minecraft:nether_wart_block
setblock 8 155 295 minecraft:red_nether_bricks
setblock 8 155 296 minecraft:nether_wart_block
fill 9 155 317 11 169 317 minecraft:blackstone
setblock 11 155 278 minecraft:light[level=12]
setblock 11 155 286 minecraft:light[level=12]
setblock 11 155 294 minecraft:light[level=12]
setblock 11 155 302 minecraft:light[level=12]
setblock 11 155 310 minecraft:light[level=12]
setblock 12 155 317 minecraft:magma_block
setblock 19 155 278 minecraft:light[level=12]
setblock 19 155 286 minecraft:light[level=12]
setblock 19 155 294 minecraft:light[level=12]
setblock 19 155 302 minecraft:light[level=12]
setblock 19 155 310 minecraft:light[level=12]
setblock 27 155 278 minecraft:light[level=12]
setblock 27 155 286 minecraft:light[level=12]
setblock 27 155 294 minecraft:light[level=12]
setblock 27 155 302 minecraft:light[level=12]
setblock 27 155 310 minecraft:light[level=12]
setblock 35 155 278 minecraft:light[level=12]
setblock 35 155 286 minecraft:light[level=12]
setblock 35 155 294 minecraft:light[level=12]
setblock 35 155 302 minecraft:light[level=12]
setblock 35 155 310 minecraft:light[level=12]
fill 42 155 276 42 219 276 minecraft:blackstone
setblock 42 155 296 minecraft:magma_block
fill 42 155 297 42 205 299 minecraft:blackstone
fill 0 156 278 0 219 278 minecraft:blackstone
setblock 3 156 285 minecraft:light[level=12]
setblock 3 156 292 minecraft:light[level=12]
setblock 3 156 299 minecraft:light[level=12]
setblock 3 156 306 minecraft:light[level=12]
setblock 3 156 313 minecraft:light[level=12]
setblock 4 156 292 minecraft:red_nether_bricks
fill 4 156 294 6 156 294 minecraft:red_nether_bricks
setblock 4 156 295 minecraft:nether_wart_block
fill 4 156 296 4 158 296 minecraft:red_nether_bricks
setblock 4 156 298 minecraft:red_nether_bricks
setblock 5 156 291 minecraft:red_nether_bricks
setblock 5 156 292 minecraft:nether_wart_block
fill 5 156 293 5 157 293 minecraft:red_nether_bricks
setblock 5 156 295 minecraft:red_nether_bricks
setblock 5 156 296 minecraft:nether_wart_block
setblock 5 156 299 minecraft:orange_terracotta
setblock 5 156 300 minecraft:nether_wart_block
setblock 6 156 290 minecraft:red_nether_bricks
setblock 6 156 293 minecraft:nether_wart_block
fill 6 156 295 6 159 295 minecraft:bone_block
setblock 6 156 296 minecraft:red_nether_bricks
fill 6 156 300 7 156 300 minecraft:red_nether_bricks
setblock 7 156 290 minecraft:nether_wart_block
setblock 7 156 291 minecraft:red_nether_bricks
fill 7 156 293 8 156 293 minecraft:red_nether_bricks
setblock 7 156 294 minecraft:nether_wart_block
fill 7 156 295 7 158 295 minecraft:red_nether_bricks
setblock 7 156 299 minecraft:orange_terracotta
fill 7 156 301 7 158 301 minecraft:orange_terracotta
setblock 8 156 291 minecraft:nether_wart_block
setblock 8 156 292 minecraft:red_nether_bricks
setblock 8 156 295 minecraft:nether_wart_block
fill 8 156 296 8 156 298 minecraft:red_nether_bricks
setblock 10 156 278 minecraft:light[level=12]
setblock 10 156 285 minecraft:light[level=12]
setblock 10 156 292 minecraft:light[level=12]
setblock 10 156 299 minecraft:light[level=12]
setblock 10 156 306 minecraft:light[level=12]
setblock 10 156 313 minecraft:light[level=12]
fill 12 156 317 12 216 317 minecraft:blackstone
fill 16 156 275 16 215 275 minecraft:blackstone
setblock 17 156 275 minecraft:crying_obsidian
setblock 17 156 278 minecraft:light[level=12]
setblock 17 156 285 minecraft:light[level=12]
setblock 17 156 299 minecraft:light[level=12]
setblock 17 156 306 minecraft:light[level=12]
setblock 17 156 313 minecraft:light[level=12]
setblock 24 156 278 minecraft:light[level=12]
setblock 24 156 285 minecraft:light[level=12]
setblock 24 156 292 minecraft:light[level=12]
setblock 24 156 299 minecraft:light[level=12]
setblock 24 156 306 minecraft:light[level=12]
setblock 24 156 313 minecraft:light[level=12]
setblock 31 156 278 minecraft:light[level=12]
setblock 31 156 285 minecraft:light[level=12]
setblock 31 156 292 minecraft:light[level=12]
setblock 31 156 299 minecraft:light[level=12]
setblock 31 156 306 minecraft:light[level=12]
setblock 31 156 313 minecraft:light[level=12]
setblock 38 156 278 minecraft:light[level=12]
setblock 38 156 285 minecraft:light[level=12]
setblock 38 156 292 minecraft:light[level=12]
setblock 38 156 299 minecraft:light[level=12]
setblock 38 156 306 minecraft:light[level=12]
setblock 38 156 313 minecraft:light[level=12]
fill 42 156 296 42 219 296 minecraft:blackstone
fill 1 157 290 6 157 290 minecraft:amethyst_block
setblock 4 157 294 minecraft:nether_wart_block
setblock 4 157 295 minecraft:red_nether_bricks
setblock 4 157 298 minecraft:nether_wart_block
fill 4 157 299 4 158 300 minecraft:red_nether_bricks
setblock 5 157 292 minecraft:red_nether_bricks
fill 5 157 294 7 157 294 minecraft:red_nether_bricks
setblock 5 157 295 minecraft:nether_wart_block
fill 5 157 296 5 157 298 minecraft:red_nether_bricks
setblock 5 157 299 minecraft:nether_wart_block
fill 5 157 300 5 158 301 minecraft:red_nether_bricks
setblock 6 157 292 minecraft:nether_wart_block
setblock 6 157 293 minecraft:red_nether_bricks
setblock 6 157 296 minecraft:nether_wart_block
fill 6 157 297 6 159 297 minecraft:red_nether_bricks
setblock 6 157 298 minecraft:orange_terracotta
fill 6 157 300 6 158 302 minecraft:orange_terracotta
setblock 7 157 293 minecraft:nether_wart_block
setblock 7 157 297 minecraft:nether_wart_block
fill 7 157 298 7 158 299 minecraft:red_nether_bricks
fill 7 157 300 7 158 300 minecraft:orange_terracotta
fill 7 157 302 8 158 302 minecraft:orange_terracotta
setblock 8 157 294 minecraft:nether_wart_block
fill 8 157 295 8 157 297 minecraft:red_nether_bricks
setblock 8 157 298 minecraft:nether_wart_block
fill 8 157 299 8 158 300 minecraft:red_nether_bricks
fill 8 157 301 8 158 301 minecraft:orange_terracotta
fill 15 157 276 17 158 276 minecraft:amethyst_block
fill 16 157 277 16 159 277 minecraft:amethyst_block
fill 17 157 275 17 162 275 minecraft:blackstone
fill 0 158 289 0 197 292 minecraft:blackstone
setblock 0 158 293 minecraft:crying_obsidian
fill 0 158 294 0 160 300 minecraft:blackstone
fill 1 158 289 3 158 291 minecraft:amethyst_block
fill 4 158 290 5 158 290 minecraft:amethyst_block
setblock 4 158 297 minecraft:nether_wart_block
fill 4 158 298 4 159 298 minecraft:red_nether_bricks
setblock 4 158 301 minecraft:nether_wart_block
setblock 5 158 294 minecraft:nether_wart_block
fill 5 158 295 5 158 297 minecraft:red_nether_bricks
setblock 5 158 298 minecraft:nether_wart_block
fill 5 158 299 5 160 299 minecraft:red_nether_bricks
setblock 5 158 302 minecraft:nether_wart_block
setblock 6 158 294 minecraft:red_nether_bricks
fill 6 158 296 6 159 296 minecraft:red_nether_bricks
setblock 6 158 298 minecraft:red_nether_bricks
setblock 6 158 299 minecraft:nether_wart_block
setblock 6 158 303 minecraft:nether_wart_block
setblock 7 158 296 minecraft:nether_wart_block
fill 7 158 297 7 159 297 minecraft:red_nether_bricks
setblock 7 158 303 minecraft:orange_terracotta
setblock 7 158 304 minecraft:nether_wart_block
setblock 8 158 296 minecraft:red_nether_bricks
setblock 8 158 297 minecraft:nether_wart_block
fill 8 158 298 8 159 298 minecraft:red_nether_bricks
fill 8 158 303 9 158 303 minecraft:red_nether_bricks
fill 8 158 304 8 160 304 minecraft:orange_terracotta
setblock 9 158 301 minecraft:red_nether_bricks
setblock 9 158 302 minecraft:nether_wart_block
fill 13 158 276 14 159 279 minecraft:amethyst_block
fill 14 158 280 14 158 281 minecraft:amethyst_block
fill 15 158 277 15 159 279 minecraft:amethyst_block
fill 16 158 278 16 160 278 minecraft:amethyst_block
setblock 17 158 277 minecraft:amethyst_block
setblock 24 158 317 minecraft:purple_concrete
fill 0 159 293 0 203 293 minecraft:blackstone
setblock 0 159 307 minecraft:crying_obsidian
fill 1 159 289 2 159 291 minecraft:amethyst_block
setblock 3 159 290 minecraft:amethyst_block
setblock 4 159 299 minecraft:red_nether_bricks
setblock 4 159 300 minecraft:nether_wart_block
setblock 4 159 301 minecraft:red_nether_bricks
setblock 5 159 296 minecraft:red_nether_bricks
setblock 5 159 297 minecraft:nether_wart_block
fill 5 159 298 5 160 298 minecraft:red_nether_bricks
fill 5 159 300 7 159 300 minecraft:red_nether_bricks
setblock 5 159 301 minecraft:nether_wart_block
fill 5 159 302 5 160 303 minecraft:red_nether_bricks
setblock 6 159 298 minecraft:nether_wart_block
fill 6 159 299 6 160 299 minecraft:red_nether_bricks
fill 6 159 301 8 159 301 minecraft:red_nether_bricks
setblock 6 159 302 minecraft:nether_wart_block
fill 6 159 303 6 160 304 minecraft:red_nether_bricks
setblock 7 159 296 minecraft:red_nether_bricks
setblock 7 159 298 minecraft:red_nether_bricks
setblock 7 159 299 minecraft:nether_wart_block
setblock 7 159 302 minecraft:orange_terracotta
setblock 7 159 303 minecraft:nether_wart_block
setblock 7 159 304 minecraft:orange_terracotta
fill 7 159 305 7 160 305 minecraft:red_nether_bricks
setblock 8 159 299 minecraft:red_nether_bricks
setblock 8 159 300 minecraft:nether_wart_block
fill 8 159 302 9 160 302 minecraft:red_nether_bricks
fill 8 159 303 9 159 303 minecraft:orange_terracotta
fill 8 159 305 9 160 305 minecraft:orange_terracotta
setblock 8 159 306 minecraft:red_nether_bricks
setblock 9 159 300 minecraft:red_nether_bricks
setblock 9 159 301 minecraft:nether_wart_block
fill 9 159 304 9 160 304 minecraft:orange_terracotta
fill 9 159 306 9 160 306 minecraft:orange_terracotta
fill 10 159 304 10 159 305 minecraft:red_nether_bricks
fill 12 159 276 12 160 276 minecraft:amethyst_block
fill 15 159 276 16 160 276 minecraft:amethyst_block
setblock 20 159 275 minecraft:crying_obsidian
fill 21 159 275 27 162 275 minecraft:blackstone
fill 24 159 317 24 219 317 minecraft:blackstone
setblock 37 159 317 minecraft:magma_block
fill 0 160 283 1 162 285 minecraft:amethyst_block
fill 0 160 307 0 217 307 minecraft:blackstone
setblock 1 160 290 minecraft:amethyst_block
fill 2 160 283 2 163 284 minecraft:amethyst_block
setblock 5 160 300 minecraft:nether_wart_block
fill 5 160 301 5 161 301 minecraft:red_nether_bricks
setblock 6 160 298 minecraft:red_nether_bricks
fill 6 160 300 8 160 300 minecraft:red_nether_bricks
setblock 6 160 301 minecraft:nether_wart_block
fill 6 160 302 6 162 302 minecraft:red_nether_bricks
setblock 6 160 305 minecraft:nether_wart_block
setblock 7 160 298 minecraft:nether_wart_block
setblock 7 160 299 minecraft:red_nether_bricks
fill 7 160 301 9 160 301 minecraft:red_nether_bricks
fill 7 160 302 7 163 302 minecraft:bone_block
fill 7 160 303 7 161 304 minecraft:red_nether_bricks
setblock 7 160 306 minecraft:nether_wart_block
setblock 8 160 299 minecraft:nether_wart_block
setblock 8 160 303 minecraft:orange_terracotta
setblock 8 160 306 minecraft:orange_terracotta
setblock 8 160 307 minecraft:nether_wart_block
fill 9 160 303 10 160 303 minecraft:red_nether_bricks
setblock 9 160 307 minecraft:red_nether_bricks
setblock 10 160 304 minecraft:red_nether_bricks
fill 10 160 305 10 160 307 minecraft:orange_terracotta
fill 11 160 303 12 161 303 minecraft:gold_block
setblock 11 160 305 minecraft:red_nether_bricks
fill 11 160 306 11 161 307 minecraft:orange_terracotta
fill 13 160 276 14 160 278 minecraft:amethyst_block
fill 15 160 277 15 160 278 minecraft:amethyst_block
setblock 16 160 279 minecraft:amethyst_block
fill 20 160 275 20 219 275 minecraft:blackstone
fill 37 160 317 37 219 317 minecraft:blackstone
setblock 42 160 281 minecraft:purple_concrete
fill 0 161 282 1 161 282 minecraft:amethyst_block
fill 0 161 286 1 161 286 minecraft:amethyst_block
fill 0 161 287 0 202 287 minecraft:blackstone
fill 0 161 294 0 196 294 minecraft:blackstone
setblock 0 161 295 minecraft:magma_block
fill 0 161 296 0 165 300 minecraft:blackstone
fill 2 161 285 2 163 285 minecraft:amethyst_block
fill 2 161 312 2 169 312 minecraft:blackstone
setblock 3 161 284 minecraft:amethyst_block
setblock 5 161 302 minecraft:red_nether_bricks
setblock 6 161 300 minecraft:nether_wart_block
setblock 6 161 301 minecraft:red_nether_bricks
setblock 6 161 303 minecraft:red_nether_bricks
setblock 6 161 304 minecraft:nether_wart_block
setblock 6 161 305 minecraft:red_nether_bricks
fill 7 161 300 8 161 300 minecraft:red_nether_bricks
setblock 7 161 301 minecraft:nether_wart_block
setblock 7 161 305 minecraft:nether_wart_block
fill 7 161 306 7 163 306 minecraft:red_nether_bricks
fill 8 161 301 9 161 301 minecraft:red_nether_bricks
setblock 8 161 302 minecraft:nether_wart_block
fill 8 161 303 8 161 305 minecraft:red_nether_bricks
setblock 8 161 306 minecraft:nether_wart_block
fill 8 161 307 8 163 307 minecraft:red_nether_bricks
setblock 9 161 302 minecraft:red_nether_bricks
setblock 9 161 303 minecraft:nether_wart_block
fill 9 161 304 9 163 304 minecraft:red_nether_bricks
setblock 9 161 305 minecraft:orange_terracotta
setblock 9 161 306 minecraft:red_nether_bricks
fill 9 161 307 10 161 307 minecraft:orange_terracotta
fill 9 161 308 9 163 308 minecraft:red_nether_bricks
setblock 10 161 303 minecraft:red_nether_bricks
setblock 10 161 304 minecraft:nether_wart_block
fill 10 161 305 10 163 305 minecraft:red_nether_bricks
fill 10 161 306 10 162 306 minecraft:orange_terracotta
fill 10 161 308 12 162 308 minecraft:orange_terracotta
setblock 11 161 304 minecraft:red_nether_bricks
setblock 11 161 305 minecraft:nether_wart_block
setblock 11 161 309 minecraft:nether_wart_block
setblock 12 161 306 minecraft:nether_wart_block
fill 12 161 307 12 162 307 minecraft:orange_terracotta
fill 13 161 276 15 161 277 minecraft:amethyst_block
setblock 16 161 280 minecraft:amethyst_block
fill 42 161 281 42 208 281 minecraft:blackstone
fill 0 162 282 0 219 282 minecraft:blackstone
fill 0 162 286 0 202 286 minecraft:blackstone
fill 0 162 295 0 184 295 minecraft:blackstone
setblock 1 162 282 minecraft:amethyst_block
setblock 1 162 286 minecraft:amethyst_block
setblock 3 162 278 minecraft:light[level=12]
fill 3 162 285 3 162 286 minecraft:light[level=12]
setblock 3 162 292 minecraft:light[level=12]
setblock 3 162 294 minecraft:light[level=12]
setblock 3 162 299 minecraft:light[level=12]
setblock 3 162 302 minecraft:light[level=12]
setblock 3 162 306 minecraft:light[level=12]
setblock 3 162 310 minecraft:light[level=12]
setblock 3 162 313 minecraft:light[level=12]
setblock 6 162 303 minecraft:nether_wart_block
setblock 6 162 304 minecraft:red_nether_bricks
fill 7 162 303 9 162 303 minecraft:red_nether_bricks
setblock 7 162 304 minecraft:nether_wart_block
fill 7 162 305 7 163 305 minecraft:red_nether_bricks
setblock 8 162 302 minecraft:red_nether_bricks
setblock 8 162 304 minecraft:red_nether_bricks
setblock 8 162 305 minecraft:nether_wart_block
fill 8 162 306 8 164 306 minecraft:red_nether_bricks
setblock 8 162 308 minecraft:red_nether_bricks
setblock 9 162 302 minecraft:nether_wart_block
setblock 9 162 305 minecraft:red_nether_bricks
setblock 9 162 306 minecraft:nether_wart_block
fill 9 162 307 9 164 307 minecraft:red_nether_bricks
fill 9 162 309 11 162 309 minecraft:red_nether_bricks
fill 10 162 278 11 162 278 minecraft:light[level=12]
setblock 10 162 285 minecraft:light[level=12]
setblock 10 162 292 minecraft:light[level=12]
setblock 10 162 299 minecraft:light[level=12]
setblock 10 162 303 minecraft:nether_wart_block
fill 10 162 304 10 163 304 minecraft:red_nether_bricks
fill 10 162 307 11 162 307 minecraft:orange_terracotta
setblock 10 162 313 minecraft:light[level=12]
setblock 11 162 286 minecraft:light[level=12]
setblock 11 162 294 minecraft:light[level=12]
setblock 11 162 302 minecraft:light[level=12]
setblock 11 162 304 minecraft:nether_wart_block
fill 11 162 305 11 163 306 minecraft:red_nether_bricks
fill 11 162 310 12 163 310 minecraft:red_nether_bricks
setblock 12 162 305 minecraft:nether_wart_block
fill 12 162 306 12 164 306 minecraft:red_nether_bricks
fill 12 162 309 14 163 309 minecraft:orange_terracotta
fill 13 162 307 13 164 307 minecraft:red_nether_bricks
fill 13 162 308 13 163 308 minecraft:orange_terracotta
fill 13 162 310 14 164 310 minecraft:orange_terracotta
setblock 14 162 308 minecraft:red_nether_bricks
setblock 17 162 278 minecraft:light[level=12]
setblock 17 162 285 minecraft:light[level=12]
setblock 17 162 299 minecraft:light[level=12]
setblock 17 162 306 minecraft:light[level=12]
setblock 17 162 313 minecraft:light[level=12]
setblock 19 162 278 minecraft:light[level=12]
setblock 19 162 286 minecraft:light[level=12]
setblock 19 162 294 minecraft:light[level=12]
setblock 19 162 302 minecraft:light[level=12]
setblock 19 162 310 minecraft:light[level=12]
setblock 24 162 278 minecraft:light[level=12]
setblock 24 162 285 minecraft:light[level=12]
setblock 24 162 292 minecraft:light[level=12]
setblock 24 162 299 minecraft:light[level=12]
setblock 24 162 306 minecraft:light[level=12]
setblock 24 162 313 minecraft:light[level=12]
setblock 27 162 278 minecraft:light[level=12]
setblock 27 162 286 minecraft:light[level=12]
setblock 27 162 294 minecraft:light[level=12]
setblock 27 162 302 minecraft:light[level=12]
setblock 27 162 310 minecraft:light[level=12]
setblock 31 162 278 minecraft:light[level=12]
setblock 31 162 285 minecraft:light[level=12]
setblock 31 162 292 minecraft:light[level=12]
setblock 31 162 299 minecraft:light[level=12]
setblock 31 162 306 minecraft:light[level=12]
setblock 31 162 313 minecraft:light[level=12]
setblock 35 162 278 minecraft:light[level=12]
setblock 35 162 286 minecraft:light[level=12]
setblock 35 162 294 minecraft:light[level=12]
setblock 35 162 302 minecraft:light[level=12]
setblock 35 162 310 minecraft:light[level=12]
setblock 38 162 278 minecraft:light[level=12]
setblock 38 162 285 minecraft:light[level=12]
setblock 38 162 292 minecraft:light[level=12]
setblock 38 162 299 minecraft:light[level=12]
setblock 38 162 306 minecraft:light[level=12]
setblock 38 162 313 minecraft:light[level=12]
fill 0 163 283 0 219 283 minecraft:blackstone
fill 0 163 284 1 163 285 minecraft:amethyst_block
setblock 1 163 283 minecraft:amethyst_block
setblock 7 163 304 minecraft:red_nether_bricks
fill 8 163 303 9 163 303 minecraft:red_nether_bricks
setblock 8 163 304 minecraft:nether_wart_block
setblock 8 163 305 minecraft:red_nether_bricks
setblock 9 163 305 minecraft:nether_wart_block
fill 9 163 306 9 164 306 minecraft:red_nether_bricks
setblock 9 163 309 minecraft:nether_wart_block
setblock 10 163 306 minecraft:nether_wart_block
fill 10 163 307 10 163 309 minecraft:red_nether_bricks
fill 11 163 307 11 166 308 minecraft:bone_block
fill 11 163 309 11 164 309 minecraft:red_nether_bricks
setblock 12 163 305 minecraft:red_nether_bricks
setblock 12 163 307 minecraft:red_nether_bricks
setblock 12 163 308 minecraft:orange_terracotta
fill 13 163 306 13 164 306 minecraft:red_nether_bricks
fill 13 163 311 14 164 311 minecraft:red_nether_bricks
fill 14 163 307 14 165 307 minecraft:red_nether_bricks
setblock 14 163 308 minecraft:orange_terracotta
fill 15 163 308 15 165 308 minecraft:red_nether_bricks
fill 15 163 309 15 164 310 minecraft:orange_terracotta
setblock 15 163 311 minecraft:nether_wart_block
setblock 16 163 310 minecraft:red_nether_bricks
setblock 17 163 275 minecraft:magma_block
fill 21 163 275 21 219 275 minecraft:blackstone
setblock 22 163 275 minecraft:amethyst_block
fill 23 163 275 27 174 275 minecraft:blackstone
fill 0 164 284 0 171 285 minecraft:blackstone
setblock 9 164 305 minecraft:red_nether_bricks
setblock 9 164 308 minecraft:nether_wart_block
setblock 10 164 305 minecraft:nether_wart_block
fill 10 164 306 10 164 308 minecraft:red_nether_bricks
setblock 10 164 309 minecraft:nether_wart_block
setblock 11 164 305 minecraft:red_nether_bricks
setblock 11 164 306 minecraft:nether_wart_block
setblock 11 164 310 minecraft:nether_wart_block
setblock 12 164 307 minecraft:nether_wart_block
fill 12 164 308 12 164 310 minecraft:red_nether_bricks
setblock 12 164 311 minecraft:nether_wart_block
setblock 13 164 308 minecraft:nether_wart_block
fill 13 164 309 14 164 309 minecraft:orange_terracotta
setblock 14 164 308 minecraft:red_nether_bricks
fill 14 164 312 16 164 312 minecraft:red_nether_bricks
fill 15 164 311 18 164 311 minecraft:orange_terracotta
fill 16 164 308 16 165 309 minecraft:red_nether_bricks
fill 16 164 310 17 165 310 minecraft:orange_terracotta
fill 17 164 275 17 219 275 minecraft:blackstone
fill 17 164 309 17 166 309 minecraft:red_nether_bricks
fill 22 164 275 22 215 275 minecraft:blackstone
fill 28 164 306 29 165 307 minecraft:gold_block
fill 1 165 312 1 169 312 minecraft:blackstone
fill 2 165 311 2 169 311 minecraft:blackstone
fill 2 165 313 2 169 313 minecraft:blackstone
fill 3 165 312 3 169 312 minecraft:blackstone
setblock 10 165 307 minecraft:red_nether_bricks
setblock 10 165 308 minecraft:nether_wart_block
setblock 10 165 309 minecraft:red_nether_bricks
setblock 11 165 306 minecraft:red_nether_bricks
setblock 11 165 309 minecraft:nether_wart_block
setblock 11 165 310 minecraft:red_nether_bricks
setblock 12 165 306 minecraft:nether_wart_block
fill 12 165 307 12 165 309 minecraft:red_nether_bricks
setblock 12 165 310 minecraft:nether_wart_block
setblock 12 165 311 minecraft:red_nether_bricks
setblock 13 165 307 minecraft:nether_wart_block
fill 13 165 308 13 165 310 minecraft:red_nether_bricks
setblock 13 165 311 minecraft:nether_wart_block
setblock 14 165 308 minecraft:nether_wart_block
fill 14 165 309 14 165 311 minecraft:red_nether_bricks
setblock 14 165 312 minecraft:nether_wart_block
setblock 15 165 309 minecraft:nether_wart_block
setblock 15 165 310 minecraft:orange_terracotta
fill 15 165 311 15 165 312 minecraft:red_nether_bricks
fill 16 165 311 20 165 311 minecraft:orange_terracotta
fill 16 165 312 16 166 312 minecraft:red_nether_bricks
setblock 17 165 312 minecraft:orange_terracotta
fill 18 165 309 18 167 309 minecraft:red_nether_bricks
setblock 18 165 310 minecraft:orange_terracotta
setblock 18 165 312 minecraft:nether_wart_block
setblock 19 165 310 minecraft:red_nether_bricks
setblock 19 165 312 minecraft:red_nether_bricks
setblock 0 166 296 minecraft:purple_concrete
fill 0 166 297 0 180 300 minecraft:blackstone
fill 1 166 311 1 169 311 minecraft:blackstone
fill 1 166 313 1 169 313 minecraft:blackstone
fill 3 166 311 3 169 311 minecraft:blackstone
fill 3 166 313 3 169 313 minecraft:blackstone
setblock 11 166 309 minecraft:red_nether_bricks
fill 12 166 308 14 166 308 minecraft:red_nether_bricks
setblock 12 166 309 minecraft:nether_wart_block
setblock 12 166 310 minecraft:red_nether_bricks
fill 13 166 309 15 166 309 minecraft:red_nether_bricks
setblock 13 166 310 minecraft:nether_wart_block
setblock 13 166 311 minecraft:red_nether_bricks
fill 14 166 310 16 166 310 minecraft:red_nether_bricks
setblock 14 166 311 minecraft:nether_wart_block
setblock 14 166 312 minecraft:red_nether_bricks
setblock 15 166 308 minecraft:nether_wart_block
fill 15 166 311 16 166 311 minecraft:red_nether_bricks
setblock 15 166 312 minecraft:nether_wart_block
fill 16 166 308 17 166 308 minecraft:red_nether_bricks
setblock 16 166 309 minecraft:nether_wart_block
setblock 16 166 313 minecraft:nether_wart_block
fill 17 166 310 17 166 311 minecraft:orange_terracotta
fill 17 166 312 18 166 313 minecraft:red_nether_bricks
setblock 18 166 310 minecraft:red_nether_bricks
fill 18 166 311 21 166 311 minecraft:orange_terracotta
fill 19 166 309 19 168 309 minecraft:red_nether_bricks
fill 19 166 310 20 166 310 minecraft:orange_terracotta
fill 19 166 312 21 167 312 minecraft:orange_terracotta
fill 19 166 313 19 168 313 minecraft:red_nether_bricks
setblock 21 166 310 minecraft:nether_wart_block
fill 42 166 279 42 169 279 minecraft:blackstone
setblock 42 166 280 minecraft:magma_block
fill 0 167 296 0 219 296 minecraft:blackstone
setblock 13 167 309 minecraft:nether_wart_block
setblock 13 167 310 minecraft:red_nether_bricks
fill 14 167 309 16 167 309 minecraft:red_nether_bricks
setblock 14 167 310 minecraft:nether_wart_block
setblock 14 167 311 minecraft:red_nether_bricks
setblock 15 167 308 minecraft:red_nether_bricks
fill 15 167 310 17 167 310 minecraft:red_nether_bricks
setblock 15 167 311 minecraft:nether_wart_block
setblock 15 167 312 minecraft:red_nether_bricks
setblock 16 167 308 minecraft:nether_wart_block
setblock 16 167 311 minecraft:red_nether_bricks
setblock 16 167 312 minecraft:nether_wart_block
setblock 17 167 309 minecraft:nether_wart_block
fill 17 167 311 17 170 311 minecraft:bone_block
fill 17 167 312 18 167 312 minecraft:red_nether_bricks
setblock 17 167 313 minecraft:nether_wart_block
setblock 18 167 310 minecraft:nether_wart_block
fill 18 167 311 18 169 311 minecraft:red_nether_bricks
setblock 18 167 313 minecraft:red_nether_bricks
setblock 19 167 310 minecraft:red_nether_bricks
fill 19 167 311 24 167 311 minecraft:orange_terracotta
fill 20 167 309 20 169 309 minecraft:red_nether_bricks
fill 20 167 310 21 167 310 minecraft:orange_terracotta
fill 20 167 313 20 169 313 minecraft:red_nether_bricks
setblock 21 167 309 minecraft:nether_wart_block
setblock 21 167 313 minecraft:nether_wart_block
setblock 22 167 310 minecraft:nether_wart_block
fill 22 167 312 22 167 313 minecraft:red_nether_bricks
setblock 23 167 310 minecraft:red_nether_bricks
fill 23 167 312 23 169 312 minecraft:orange_terracotta
fill 42 167 280 42 184 280 minecraft:blackstone
fill 3 168 278 3 169 278 minecraft:light[level=12]
setblock 3 168 285 minecraft:light[level=12]
setblock 3 168 292 minecraft:light[level=12]
setblock 3 168 299 minecraft:light[level=12]
setblock 3 168 306 minecraft:light[level=12]
setblock 10 168 278 minecraft:light[level=12]
setblock 10 168 285 minecraft:light[level=12]
setblock 10 168 292 minecraft:light[level=12]
setblock 10 168 299 minecraft:light[level=12]
setblock 10 168 306 minecraft:light[level=12]
setblock 10 168 313 minecraft:light[level=12]
setblock 15 168 310 minecraft:nether_wart_block
setblock 15 168 311 minecraft:red_nether_bricks
fill 16 168 309 17 168 310 minecraft:red_nether_bricks
setblock 16 168 311 minecraft:nether_wart_block
setblock 16 168 312 minecraft:red_nether_bricks
setblock 17 168 278 minecraft:light[level=12]
setblock 17 168 285 minecraft:light[level=12]
setblock 17 168 299 minecraft:light[level=12]
setblock 17 168 306 minecraft:light[level=12]
setblock 17 168 312 minecraft:nether_wart_block
setblock 17 168 313 minecraft:red_nether_bricks
setblock 18 168 309 minecraft:nether_wart_block
fill 18 168 310 18 169 310 minecraft:red_nether_bricks
fill 18 168 312 20 168 312 minecraft:red_nether_bricks
setblock 18 168 313 minecraft:nether_wart_block
setblock 19 168 310 minecraft:nether_wart_block
fill 19 168 311 19 170 311 minecraft:red_nether_bricks
fill 20 168 310 22 168 310 minecraft:red_nether_bricks
setblock 20 168 311 minecraft:nether_wart_block
fill 21 168 309 21 170 309 minecraft:red_nether_bricks
fill 21 168 311 25 168 311 minecraft:orange_terracotta
setblock 21 168 312 minecraft:nether_wart_block
fill 21 168 313 21 170 313 minecraft:red_nether_bricks
setblock 22 168 309 minecraft:nether_wart_block
setblock 22 168 312 minecraft:red_nether_bricks
setblock 22 168 313 minecraft:nether_wart_block
setblock 23 168 309 minecraft:red_nether_bricks
fill 23 168 310 25 169 310 minecraft:orange_terracotta
setblock 23 168 313 minecraft:red_nether_bricks
setblock 24 168 278 minecraft:light[level=12]
setblock 24 168 285 minecraft:light[level=12]
setblock 24 168 292 minecraft:light[level=12]
setblock 24 168 299 minecraft:light[level=12]
setblock 24 168 306 minecraft:light[level=12]
fill 24 168 312 24 169 312 minecraft:orange_terracotta
setblock 24 168 313 minecraft:light[level=12]
setblock 25 168 312 minecraft:nether_wart_block
fill 30 168 275 32 173 275 minecraft:blackstone
setblock 31 168 278 minecraft:light[level=12]
setblock 31 168 285 minecraft:light[level=12]
setblock 31 168 292 minecraft:light[level=12]
setblock 31 168 299 minecraft:light[level=12]
setblock 31 168 306 minecraft:light[level=12]
setblock 31 168 313 minecraft:light[level=12]
setblock 33 168 275 minecraft:magma_block
setblock 38 168 278 minecraft:light[level=12]
setblock 38 168 285 minecraft:light[level=12]
setblock 38 168 292 minecraft:light[level=12]
setblock 38 168 299 minecraft:light[level=12]
setblock 38 168 306 minecraft:light[level=12]
setblock 38 168 313 minecraft:light[level=12]
setblock 2 169 310 minecraft:blackstone
setblock 2 169 314 minecraft:blackstone
setblock 3 169 286 minecraft:light[level=12]
setblock 3 169 294 minecraft:light[level=12]
setblock 3 169 302 minecraft:light[level=12]
setblock 3 169 310 minecraft:light[level=12]
setblock 4 169 312 minecraft:blackstone
setblock 11 169 278 minecraft:light[level=12]
setblock 11 169 286 minecraft:light[level=12]
setblock 11 169 294 minecraft:light[level=12]
setblock 11 169 302 minecraft:light[level=12]
setblock 11 169 310 minecraft:light[level=12]
setblock 17 169 310 minecraft:red_nether_bricks
setblock 17 169 312 minecraft:red_nether_bricks
setblock 18 169 312 minecraft:nether_wart_block
setblock 19 169 278 minecraft:light[level=12]
setblock 19 169 286 minecraft:light[level=12]
setblock 19 169 294 minecraft:light[level=12]
setblock 19 169 302 minecraft:light[level=12]
setblock 19 169 309 minecraft:nether_wart_block
fill 19 169 310 19 170 310 minecraft:red_nether_bricks
fill 19 169 312 21 169 312 minecraft:red_nether_bricks
setblock 19 169 313 minecraft:nether_wart_block
setblock 20 169 310 minecraft:nether_wart_block
fill 20 169 311 20 170 311 minecraft:red_nether_bricks
fill 21 169 310 22 169 310 minecraft:red_nether_bricks
setblock 21 169 311 minecraft:nether_wart_block
fill 22 169 309 22 170 309 minecraft:red_nether_bricks
setblock 22 169 311 minecraft:red_nether_bricks
setblock 22 169 312 minecraft:nether_wart_block
fill 22 169 313 22 171 313 minecraft:red_nether_bricks
setblock 23 169 309 minecraft:nether_wart_block
fill 23 169 311 27 169 311 minecraft:orange_terracotta
setblock 23 169 313 minecraft:nether_wart_block
fill 24 169 309 26 169 309 minecraft:red_nether_bricks
fill 24 169 313 25 169 313 minecraft:red_nether_bricks
fill 25 169 312 25 171 312 minecraft:red_nether_bricks
fill 26 169 310 27 171 310 minecraft:orange_terracotta
setblock 26 169 312 minecraft:nether_wart_block
setblock 27 169 278 minecraft:light[level=12]
setblock 27 169 286 minecraft:light[level=12]
setblock 27 169 294 minecraft:light[level=12]
setblock 27 169 302 minecraft:light[level=12]
fill 33 169 275 33 219 275 minecraft:blackstone
setblock 35 169 278 minecraft:light[level=12]
setblock 35 169 286 minecraft:light[level=12]
setblock 35 169 294 minecraft:light[level=12]
setblock 35 169 302 minecraft:light[level=12]
setblock 35 169 310 minecraft:light[level=12]
setblock 0 170 279 minecraft:crying_obsidian
fill 0 170 280 0 182 281 minecraft:blackstone
setblock 9 170 317 minecraft:magma_block
fill 10 170 317 11 216 317 minecraft:blackstone
setblock 19 170 312 minecraft:nether_wart_block
setblock 20 170 310 minecraft:red_nether_bricks
fill 20 170 312 22 170 312 minecraft:red_nether_bricks
setblock 20 170 313 minecraft:nether_wart_block
setblock 21 170 310 minecraft:nether_wart_block
fill 21 170 311 21 171 311 minecraft:red_nether_bricks
fill 22 170 310 24 170 310 minecraft:red_nether_bricks
setblock 22 170 311 minecraft:nether_wart_block
fill 23 170 309 23 171 309 minecraft:red_nether_bricks
setblock 23 170 311 minecraft:red_nether_bricks
setblock 23 170 312 minecraft:nether_wart_block
fill 23 170 313 23 171 313 minecraft:red_nether_bricks
setblock 24 170 309 minecraft:nether_wart_block
fill 24 170 311 24 174 311 minecraft:bone_block
setblock 24 170 312 minecraft:red_nether_bricks
setblock 24 170 313 minecraft:nether_wart_block
setblock 25 170 309 minecraft:red_nether_bricks
setblock 25 170 310 minecraft:nether_wart_block
fill 25 170 311 25 172 311 minecraft:red_nether_bricks
setblock 25 170 313 minecraft:red_nether_bricks
fill 26 170 308 26 172 308 minecraft:red_nether_bricks
fill 26 170 309 28 170 309 minecraft:orange_terracotta
fill 26 170 311 28 170 311 minecraft:orange_terracotta
fill 26 170 312 26 172 312 minecraft:red_nether_bricks
setblock 27 170 308 minecraft:nether_wart_block
setblock 27 170 312 minecraft:nether_wart_block
fill 28 170 310 28 171 310 minecraft:orange_terracotta
setblock 29 170 309 minecraft:red_nether_bricks
setblock 29 170 310 minecraft:nether_wart_block
setblock 42 170 279 minecraft:purple_concrete
fill 0 171 279 0 219 279 minecraft:blackstone
setblock 0 171 301 minecraft:purple_concrete
fill 9 171 317 9 219 317 minecraft:blackstone
setblock 21 171 310 minecraft:red_nether_bricks
fill 21 171 312 23 171 312 minecraft:red_nether_bricks
setblock 22 171 310 minecraft:nether_wart_block
setblock 22 171 311 minecraft:red_nether_bricks
fill 23 171 310 25 171 310 minecraft:red_nether_bricks
setblock 23 171 311 minecraft:nether_wart_block
fill 24 171 309 24 172 309 minecraft:red_nether_bricks
setblock 24 171 312 minecraft:nether_wart_block
setblock 24 171 313 minecraft:red_nether_bricks
setblock 25 171 308 minecraft:red_nether_bricks
setblock 25 171 309 minecraft:nether_wart_block
setblock 25 171 313 minecraft:nether_wart_block
setblock 26 171 309 minecraft:red_nether_bricks
fill 26 171 311 26 173 311 minecraft:red_nether_bricks
setblock 26 171 313 minecraft:red_nether_bricks
fill 27 171 308 27 173 308 minecraft:red_nether_bricks
fill 27 171 309 30 171 309 minecraft:orange_terracotta
setblock 27 171 311 minecraft:nether_wart_block
fill 27 171 312 27 173 312 minecraft:red_nether_bricks
setblock 28 171 308 minecraft:nether_wart_block
fill 28 171 311 29 171 311 minecraft:red_nether_bricks
setblock 28 171 312 minecraft:nether_wart_block
fill 29 171 308 31 172 308 minecraft:orange_terracotta
fill 29 171 310 29 173 310 minecraft:red_nether_bricks
setblock 30 171 310 minecraft:nether_wart_block
setblock 35 171 317 minecraft:magma_block
fill 36 171 317 36 206 317 minecraft:blackstone
fill 42 171 279 42 219 279 minecraft:blackstone
setblock 42 171 313 minecraft:crying_obsidian
setblock 0 172 284 minecraft:purple_concrete
setblock 0 172 285 minecraft:blackstone
fill 0 172 301 0 219 301 minecraft:blackstone
setblock 0 172 315 minecraft:amethyst_block
setblock 23 172 310 minecraft:nether_wart_block
fill 23 172 311 23 172 312 minecraft:red_nether_bricks
fill 24 172 310 26 172 310 minecraft:red_nether_bricks
setblock 24 172 312 minecraft:red_nether_bricks
fill 25 172 309 25 173 309 minecraft:red_nether_bricks
setblock 25 172 312 minecraft:nether_wart_block
setblock 26 172 309 minecraft:nether_wart_block
fill 27 172 309 28 172 309 minecraft:red_nether_bricks
setblock 27 172 310 minecraft:nether_wart_block
fill 27 172 311 27 174 311 minecraft:red_nether_bricks
setblock 28 172 307 minecraft:nether_wart_block
fill 28 172 308 28 174 308 minecraft:red_nether_bricks
setblock 28 172 310 minecraft:red_nether_bricks
setblock 28 172 311 minecraft:nether_wart_block
fill 28 172 312 28 173 312 minecraft:red_nether_bricks
setblock 29 172 275 minecraft:magma_block
setblock 29 172 307 minecraft:red_nether_bricks
fill 29 172 309 31 172 309 minecraft:orange_terracotta
fill 29 172 311 30 172 311 minecraft:red_nether_bricks
fill 30 172 306 30 174 306 minecraft:red_nether_bricks
fill 30 172 307 31 173 307 minecraft:orange_terracotta
fill 30 172 310 30 174 310 minecraft:red_nether_bricks
setblock 31 172 306 minecraft:nether_wart_block
setblock 31 172 310 minecraft:nether_wart_block
setblock 32 172 307 minecraft:nether_wart_block
fill 32 172 308 32 173 309 minecraft:red_nether_bricks
fill 35 172 317 35 201 317 minecraft:blackstone
fill 42 172 313 42 219 313 minecraft:blackstone
fill 0 173 284 0 216 284 minecraft:blackstone
setblock 0 173 285 minecraft:amethyst_block
fill 0 173 315 0 219 315 minecraft:blackstone
fill 25 173 310 27 173 310 minecraft:red_nether_bricks
setblock 25 173 311 minecraft:nether_wart_block
setblock 26 173 308 minecraft:nether_wart_block
setblock 26 173 309 minecraft:red_nether_bricks
setblock 26 173 312 minecraft:nether_wart_block
setblock 27 173 309 minecraft:nether_wart_block
fill 28 173 307 28 174 307 minecraft:red_nether_bricks
fill 28 173 309 30 173 309 minecraft:red_nether_bricks
setblock 28 173 310 minecraft:nether_wart_block
fill 28 173 311 28 174 311 minecraft:red_nether_bricks
fill 29 173 275 29 217 275 minecraft:blackstone
setblock 29 173 306 minecraft:red_nether_bricks
setblock 29 173 307 minecraft:nether_wart_block
fill 29 173 308 29 175 308 minecraft:red_nether_bricks
setblock 29 173 311 minecraft:nether_wart_block
fill 30 173 308 31 173 308 minecraft:orange_terracotta
setblock 30 173 311 minecraft:red_nether_bricks
setblock 31 173 305 minecraft:nether_wart_block
fill 31 173 306 33 173 306 minecraft:orange_terracotta
setblock 31 173 309 minecraft:nether_wart_block
fill 31 173 310 31 175 310 minecraft:red_nether_bricks
fill 32 173 305 34 174 305 minecraft:orange_terracotta
fill 32 173 307 33 174 307 minecraft:orange_terracotta
fill 33 173 308 33 175 308 minecraft:red_nether_bricks
setblock 41 173 275 minecraft:amethyst_block
fill 42 173 275 42 221 275 minecraft:blackstone
fill 0 174 285 0 219 285 minecraft:blackstone
setblock 3 174 278 minecraft:light[level=12]
setblock 3 174 285 minecraft:light[level=12]
setblock 3 174 292 minecraft:light[level=12]
setblock 3 174 299 minecraft:light[level=12]
setblock 3 174 306 minecraft:light[level=12]
setblock 3 174 313 minecraft:light[level=12]
setblock 10 174 278 minecraft:light[level=12]
setblock 10 174 285 minecraft:light[level=12]
setblock 10 174 292 minecraft:light[level=12]
setblock 10 174 299 minecraft:light[level=12]
setblock 10 174 306 minecraft:light[level=12]
setblock 10 174 313 minecraft:light[level=12]
setblock 17 174 278 minecraft:light[level=12]
setblock 17 174 285 minecraft:light[level=12]
setblock 17 174 299 minecraft:light[level=12]
setblock 17 174 306 minecraft:light[level=12]
setblock 17 174 313 minecraft:light[level=12]
setblock 24 174 278 minecraft:light[level=12]
setblock 24 174 285 minecraft:light[level=12]
setblock 24 174 292 minecraft:light[level=12]
setblock 24 174 299 minecraft:light[level=12]
setblock 24 174 306 minecraft:light[level=12]
setblock 24 174 313 minecraft:light[level=12]
fill 26 174 310 28 174 310 minecraft:red_nether_bricks
setblock 27 174 308 minecraft:nether_wart_block
setblock 27 174 309 minecraft:red_nether_bricks
setblock 28 174 309 minecraft:nether_wart_block
setblock 29 174 306 minecraft:nether_wart_block
fill 29 174 307 29 175 307 minecraft:red_nether_bricks
fill 29 174 309 31 174 309 minecraft:red_nether_bricks
setblock 29 174 310 minecraft:nether_wart_block
setblock 29 174 311 minecraft:red_nether_bricks
setblock 30 174 275 minecraft:magma_block
fill 30 174 305 31 175 305 minecraft:red_nether_bricks
setblock 30 174 307 minecraft:nether_wart_block
fill 30 174 308 31 175 308 minecraft:bone_block
setblock 30 174 311 minecraft:nether_wart_block
fill 31 174 275 32 195 275 minecraft:blackstone
setblock 31 174 278 minecraft:light[level=12]
setblock 31 174 285 minecraft:light[level=12]
setblock 31 174 292 minecraft:light[level=12]
setblock 31 174 299 minecraft:light[level=12]
fill 31 174 306 31 174 307 minecraft:red_nether_bricks
setblock 31 174 313 minecraft:light[level=12]
setblock 32 174 304 minecraft:red_nether_bricks
fill 32 174 306 34 174 306 minecraft:orange_terracotta
setblock 32 174 308 minecraft:red_nether_bricks
setblock 32 174 309 minecraft:nether_wart_block
fill 33 174 304 34 174 304 minecraft:orange_terracotta
setblock 33 174 309 minecraft:red_nether_bricks
fill 34 174 303 35 175 303 minecraft:orange_terracotta
setblock 34 174 307 minecraft:nether_wart_block
setblock 35 174 304 minecraft:nether_wart_block
fill 35 174 305 35 175 305 minecraft:red_nether_bricks
setblock 38 174 278 minecraft:light[level=12]
setblock 38 174 285 minecraft:light[level=12]
setblock 38 174 292 minecraft:light[level=12]
setblock 38 174 299 minecraft:light[level=12]
setblock 38 174 306 minecraft:light[level=12]
setblock 38 174 313 minecraft:light[level=12]
fill 41 174 275 41 219 275 minecraft:blackstone
fill 6 175 293 13 175 293 minecraft:basalt
fill 7 175 289 14 175 292 minecraft:basalt
fill 7 175 294 14 175 297 minecraft:basalt
fill 8 175 287 26 175 288 minecraft:basalt
fill 8 175 298 26 175 299 minecraft:basalt
fill 9 175 286 25 175 286 minecraft:basalt
fill 9 175 300 25 175 300 minecraft:basalt
fill 10 175 285 24 175 285 minecraft:basalt
fill 10 175 301 24 175 301 minecraft:basalt
fill 11 175 284 23 175 284 minecraft:basalt
fill 11 175 302 23 175 302 minecraft:basalt
fill 13 175 283 21 175 283 minecraft:basalt
fill 13 175 303 21 175 303 minecraft:basalt
fill 15 175 289 16 175 290 minecraft:basalt
fill 15 175 296 16 175 297 minecraft:basalt
setblock 17 175 282 minecraft:basalt
fill 17 175 289 27 175 289 minecraft:basalt
fill 17 175 297 27 175 297 minecraft:basalt
setblock 17 175 304 minecraft:basalt
fill 18 175 290 27 175 290 minecraft:basalt
fill 18 175 296 27 175 296 minecraft:basalt
fill 20 175 291 27 175 292 minecraft:basalt
fill 20 175 294 27 175 295 minecraft:basalt
fill 21 175 293 28 175 293 minecraft:basalt
fill 23 175 275 23 219 275 minecraft:blackstone
setblock 24 175 275 minecraft:crying_obsidian
fill 25 175 275 27 182 275 minecraft:blackstone
setblock 28 175 308 minecraft:nether_wart_block
setblock 28 175 309 minecraft:red_nether_bricks
setblock 29 175 309 minecraft:nether_wart_block
setblock 29 175 310 minecraft:red_nether_bricks
fill 30 175 275 30 219 275 minecraft:blackstone
setblock 30 175 306 minecraft:nether_wart_block
setblock 30 175 307 minecraft:red_nether_bricks
fill 30 175 309 32 175 309 minecraft:red_nether_bricks
setblock 30 175 310 minecraft:nether_wart_block
setblock 31 175 304 minecraft:red_nether_bricks
fill 31 175 306 32 175 306 minecraft:red_nether_bricks
setblock 31 175 307 minecraft:nether_wart_block
setblock 32 175 303 minecraft:red_nether_bricks
setblock 32 175 304 minecraft:nether_wart_block
setblock 32 175 305 minecraft:red_nether_bricks
fill 32 175 307 34 175 307 minecraft:red_nether_bricks
setblock 32 175 308 minecraft:nether_wart_block
setblock 33 175 302 minecraft:red_nether_bricks
setblock 33 175 303 minecraft:orange_terracotta
setblock 33 175 304 minecraft:red_nether_bricks
fill 33 175 305 33 175 306 minecraft:orange_terracotta
setblock 33 175 309 minecraft:nether_wart_block
fill 34 175 302 35 175 302 minecraft:orange_terracotta
fill 34 175 304 35 175 304 minecraft:orange_terracotta
setblock 34 175 305 minecraft:red_nether_bricks
setblock 34 175 306 minecraft:nether_wart_block
setblock 34 175 308 minecraft:red_nether_bricks
setblock 35 175 306 minecraft:red_nether_bricks
setblock 36 175 303 minecraft:red_nether_bricks
setblock 36 175 304 minecraft:nether_wart_block
setblock 42 175 306 minecraft:magma_block
fill 42 175 307 42 216 307 minecraft:blackstone
fill 1 176 276 9 176 316 minecraft:blackstone
fill 10 176 276 10 176 292 minecraft:blackstone
fill 10 176 293 11 176 293 minecraft:basalt
setblock 10 176 294 minecraft:polished_basalt
fill 10 176 295 10 176 296 minecraft:basalt
setblock 10 176 297 minecraft:polished_basalt
fill 10 176 298 10 176 299 minecraft:basalt
fill 10 176 300 10 176 316 minecraft:blackstone
fill 11 176 276 11 176 290 minecraft:blackstone
fill 11 176 291 12 176 291 minecraft:basalt
setblock 11 176 292 minecraft:polished_basalt
fill 11 176 294 12 176 294 minecraft:basalt
setblock 11 176 295 minecraft:polished_basalt
setblock 11 176 296 minecraft:magma_block
setblock 11 176 297 minecraft:basalt
setblock 11 176 298 minecraft:polished_basalt
fill 11 176 299 11 176 300 minecraft:basalt
setblock 11 176 301 minecraft:polished_basalt
fill 11 176 302 11 176 316 minecraft:blackstone
fill 12 176 276 12 176 288 minecraft:blackstone
setblock 12 176 289 minecraft:magma_block
setblock 12 176 290 minecraft:polished_basalt
setblock 12 176 292 minecraft:basalt
setblock 12 176 293 minecraft:polished_basalt
fill 12 176 295 13 176 295 minecraft:basalt
setblock 12 176 296 minecraft:polished_basalt
setblock 12 176 297 minecraft:magma_block
setblock 12 176 298 minecraft:basalt
setblock 12 176 299 minecraft:polished_basalt
fill 12 176 300 12 176 301 minecraft:basalt
setblock 12 176 302 minecraft:polished_basalt
fill 12 176 304 12 176 316 minecraft:blackstone
fill 13 176 276 13 176 287 minecraft:blackstone
setblock 13 176 288 minecraft:magma_block
fill 13 176 289 13 176 290 minecraft:basalt
setblock 13 176 291 minecraft:polished_basalt
fill 13 176 292 13 176 294 minecraft:ochre_froglight
setblock 13 176 296 minecraft:basalt
setblock 13 176 297 minecraft:polished_basalt
setblock 13 176 298 minecraft:magma_block
setblock 13 176 299 minecraft:basalt
setblock 13 176 300 minecraft:polished_basalt
fill 13 176 301 13 176 302 minecraft:basalt
setblock 13 176 303 minecraft:polished_basalt
fill 13 176 305 13 176 316 minecraft:blackstone
fill 14 176 276 15 176 286 minecraft:blackstone
setblock 14 176 287 minecraft:magma_block
fill 14 176 288 15 176 288 minecraft:basalt
setblock 14 176 289 minecraft:polished_basalt
fill 14 176 290 14 176 292 minecraft:ochre_froglight
fill 14 176 294 14 176 296 minecraft:ochre_froglight
fill 14 176 297 15 176 297 minecraft:basalt
setblock 14 176 298 minecraft:polished_basalt
setblock 14 176 299 minecraft:magma_block
fill 14 176 300 15 176 300 minecraft:basalt
setblock 14 176 301 minecraft:polished_basalt
fill 14 176 302 14 176 303 minecraft:basalt
fill 14 176 306 15 176 316 minecraft:blackstone
setblock 15 176 287 minecraft:polished_basalt
setblock 15 176 289 minecraft:basalt
fill 15 176 290 16 176 290 minecraft:ochre_froglight
fill 15 176 296 16 176 296 minecraft:ochre_froglight
fill 15 176 298 16 176 298 minecraft:basalt
setblock 15 176 299 minecraft:polished_basalt
fill 15 176 301 16 176 301 minecraft:basalt
setblock 15 176 302 minecraft:polished_basalt
setblock 15 176 303 minecraft:basalt
fill 16 176 276 17 176 285 minecraft:blackstone
fill 16 176 286 16 176 287 minecraft:basalt
setblock 16 176 288 minecraft:polished_basalt
fill 16 176 289 18 176 289 minecraft:ochre_froglight
fill 16 176 297 18 176 297 minecraft:ochre_froglight
fill 16 176 299 17 176 299 minecraft:basalt
setblock 16 176 300 minecraft:polished_basalt
fill 16 176 302 17 176 302 minecraft:basalt
setblock 16 176 303 minecraft:polished_basalt
fill 16 176 307 17 176 316 minecraft:blackstone
setblock 17 176 286 minecraft:polished_basalt
fill 17 176 287 17 176 288 minecraft:basalt
setblock 17 176 298 minecraft:polished_basalt
fill 17 176 300 18 176 300 minecraft:basalt
setblock 17 176 301 minecraft:polished_basalt
fill 17 176 303 18 176 303 minecraft:basalt
setblock 17 176 304 minecraft:polished_basalt
fill 18 176 276 41 176 284 minecraft:blackstone
fill 18 176 285 18 176 286 minecraft:basalt
setblock 18 176 287 minecraft:polished_basalt
setblock 18 176 288 minecraft:basalt
fill 18 176 290 20 176 290 minecraft:ochre_froglight
fill 18 176 296 20 176 296 minecraft:ochre_froglight
fill 18 176 298 19 176 298 minecraft:basalt
setblock 18 176 299 minecraft:polished_basalt
fill 18 176 301 19 176 301 minecraft:basalt
setblock 18 176 302 minecraft:polished_basalt
fill 18 176 308 41 176 316 minecraft:blackstone
setblock 19 176 285 minecraft:polished_basalt
fill 19 176 286 19 176 287 minecraft:basalt
setblock 19 176 288 minecraft:polished_basalt
setblock 19 176 289 minecraft:basalt
setblock 19 176 297 minecraft:polished_basalt
setblock 19 176 299 minecraft:basalt
setblock 19 176 300 minecraft:polished_basalt
fill 19 176 302 20 176 302 minecraft:basalt
setblock 19 176 303 minecraft:polished_basalt
fill 20 176 285 21 176 285 minecraft:basalt
setblock 20 176 286 minecraft:polished_basalt
setblock 20 176 287 minecraft:magma_block
setblock 20 176 288 minecraft:basalt
setblock 20 176 289 minecraft:polished_basalt
fill 20 176 291 20 176 292 minecraft:ochre_froglight
fill 20 176 294 20 176 295 minecraft:ochre_froglight
fill 20 176 297 21 176 297 minecraft:basalt
setblock 20 176 298 minecraft:polished_basalt
setblock 20 176 299 minecraft:magma_block
fill 20 176 300 21 176 300 minecraft:basalt
setblock 20 176 301 minecraft:polished_basalt
fill 20 176 303 21 176 303 minecraft:basalt
fill 21 176 286 22 176 286 minecraft:basalt
setblock 21 176 287 minecraft:polished_basalt
setblock 21 176 288 minecraft:magma_block
setblock 21 176 289 minecraft:basalt
setblock 21 176 290 minecraft:polished_basalt
setblock 21 176 291 minecraft:basalt
fill 21 176 292 21 176 294 minecraft:ochre_froglight
fill 21 176 295 22 176 295 minecraft:basalt
setblock 21 176 296 minecraft:polished_basalt
setblock 21 176 298 minecraft:magma_block
setblock 21 176 299 minecraft:polished_basalt
fill 21 176 301 22 176 301 minecraft:basalt
setblock 21 176 302 minecraft:polished_basalt
setblock 22 176 285 minecraft:polished_basalt
fill 22 176 287 23 176 287 minecraft:basalt
setblock 22 176 288 minecraft:polished_basalt
setblock 22 176 289 minecraft:magma_block
setblock 22 176 290 minecraft:basalt
setblock 22 176 291 minecraft:polished_basalt
fill 22 176 292 22 176 293 minecraft:basalt
setblock 22 176 294 minecraft:polished_basalt
setblock 22 176 296 minecraft:basalt
setblock 22 176 297 minecraft:magma_block
fill 22 176 298 22 176 299 minecraft:basalt
setblock 22 176 300 minecraft:polished_basalt
fill 22 176 302 23 176 302 minecraft:basalt
fill 23 176 285 24 176 285 minecraft:basalt
setblock 23 176 286 minecraft:polished_basalt
fill 23 176 288 24 176 288 minecraft:basalt
setblock 23 176 289 minecraft:polished_basalt
setblock 23 176 290 minecraft:magma_block
fill 23 176 291 24 176 291 minecraft:basalt
setblock 23 176 292 minecraft:polished_basalt
fill 23 176 293 23 176 294 minecraft:basalt
setblock 23 176 295 minecraft:polished_basalt
setblock 23 176 296 minecraft:magma_block
fill 23 176 297 24 176 297 minecraft:basalt
setblock 23 176 298 minecraft:polished_basalt
fill 23 176 299 23 176 300 minecraft:basalt
setblock 23 176 301 minecraft:polished_basalt
fill 24 176 275 24 219 275 minecraft:blackstone
fill 24 176 286 25 176 286 minecraft:basalt
setblock 24 176 287 minecraft:polished_basalt
fill 24 176 289 25 176 289 minecraft:basalt
setblock 24 176 290 minecraft:polished_basalt
fill 24 176 292 25 176 292 minecraft:basalt
setblock 24 176 293 minecraft:polished_basalt
fill 24 176 294 24 176 295 minecraft:basalt
setblock 24 176 296 minecraft:polished_basalt
fill 24 176 298 25 176 298 minecraft:basalt
setblock 24 176 299 minecraft:polished_basalt
fill 24 176 300 24 176 301 minecraft:basalt
fill 25 176 285 41 176 285 minecraft:blackstone
fill 25 176 287 26 176 287 minecraft:basalt
setblock 25 176 288 minecraft:polished_basalt
fill 25 176 290 26 176 290 minecraft:basalt
setblock 25 176 291 minecraft:polished_basalt
fill 25 176 293 26 176 293 minecraft:basalt
setblock 25 176 294 minecraft:polished_basalt
fill 25 176 295 25 176 296 minecraft:basalt
setblock 25 176 297 minecraft:polished_basalt
fill 25 176 299 26 176 299 minecraft:basalt
setblock 25 176 300 minecraft:polished_basalt
fill 25 176 307 41 176 307 minecraft:blackstone
setblock 26 176 288 minecraft:basalt
setblock 26 176 289 minecraft:polished_basalt
fill 26 176 291 27 176 291 minecraft:basalt
setblock 26 176 292 minecraft:polished_basalt
fill 26 176 294 27 176 294 minecraft:basalt
setblock 26 176 295 minecraft:polished_basalt
fill 26 176 296 26 176 297 minecraft:basalt
setblock 26 176 298 minecraft:polished_basalt
fill 27 176 286 41 176 286 minecraft:blackstone
setblock 27 176 289 minecraft:basalt
setblock 27 176 290 minecraft:polished_basalt
setblock 27 176 292 minecraft:basalt
setblock 27 176 293 minecraft:polished_basalt
setblock 27 176 295 minecraft:basalt
setblock 27 176 296 minecraft:polished_basalt
setblock 27 176 297 minecraft:basalt
setblock 27 176 302 minecraft:light[level=12]
fill 27 176 306 42 176 306 minecraft:blackstone
setblock 28 176 293 minecraft:basalt
fill 29 176 287 41 176 287 minecraft:blackstone
fill 29 176 305 41 176 305 minecraft:blackstone
fill 30 176 288 41 176 288 minecraft:blackstone
fill 30 176 304 41 176 304 minecraft:blackstone
fill 31 176 289 41 176 290 minecraft:blackstone
fill 31 176 302 41 176 303 minecraft:blackstone
fill 32 176 291 41 176 292 minecraft:blackstone
fill 32 176 300 41 176 301 minecraft:blackstone
fill 33 176 293 41 176 299 minecraft:blackstone
fill 5 177 275 10 185 275 minecraft:blackstone
fill 8 177 291 10 177 295 minecraft:shroomlight
fill 9 177 289 11 177 290 minecraft:shroomlight
fill 9 177 296 11 177 297 minecraft:shroomlight
fill 10 177 287 12 177 288 minecraft:shroomlight
fill 10 177 298 12 177 299 minecraft:shroomlight
setblock 11 177 275 minecraft:magma_block
fill 11 177 286 23 177 286 minecraft:shroomlight
fill 11 177 300 23 177 300 minecraft:shroomlight
fill 12 177 275 13 187 275 minecraft:blackstone
fill 13 177 285 21 177 285 minecraft:shroomlight
fill 13 177 287 14 177 287 minecraft:shroomlight
fill 13 177 299 14 177 299 minecraft:shroomlight
fill 13 177 301 21 177 301 minecraft:shroomlight
fill 15 177 284 19 177 284 minecraft:shroomlight
fill 15 177 302 19 177 302 minecraft:shroomlight
fill 20 177 287 24 177 287 minecraft:shroomlight
fill 20 177 299 24 177 299 minecraft:shroomlight
fill 22 177 288 24 177 288 minecraft:shroomlight
fill 22 177 298 24 177 298 minecraft:shroomlight
fill 23 177 289 25 177 290 minecraft:shroomlight
fill 23 177 296 25 177 297 minecraft:shroomlight
fill 24 177 291 26 177 295 minecraft:shroomlight
fill 30 177 308 31 177 308 minecraft:bone_block
setblock 31 177 305 minecraft:nether_wart_block
fill 31 177 306 31 177 307 minecraft:red_nether_bricks
fill 32 177 303 32 177 305 minecraft:red_nether_bricks
setblock 32 177 306 minecraft:nether_wart_block
setblock 32 177 307 minecraft:red_nether_bricks
setblock 32 177 317 minecraft:crying_obsidian
fill 33 177 301 34 177 302 minecraft:red_nether_bricks
setblock 33 177 303 minecraft:nether_wart_block
fill 33 177 304 33 177 306 minecraft:red_nether_bricks
setblock 33 177 307 minecraft:nether_wart_block
fill 33 177 317 33 203 317 minecraft:blackstone
setblock 34 177 299 minecraft:red_nether_bricks
setblock 34 177 300 minecraft:nether_wart_block
fill 34 177 303 36 177 303 minecraft:red_nether_bricks
setblock 34 177 304 minecraft:nether_wart_block
fill 34 177 305 34 177 307 minecraft:red_nether_bricks
setblock 35 177 298 minecraft:red_nether_bricks
fill 35 177 299 35 177 302 minecraft:orange_terracotta
fill 35 177 304 36 177 304 minecraft:red_nether_bricks
setblock 35 177 305 minecraft:nether_wart_block
setblock 35 177 306 minecraft:red_nether_bricks
fill 36 177 298 36 177 301 minecraft:orange_terracotta
setblock 36 177 302 minecraft:nether_wart_block
setblock 36 177 305 minecraft:red_nether_bricks
setblock 37 177 298 minecraft:red_nether_bricks
fill 37 177 299 37 177 300 minecraft:orange_terracotta
fill 37 177 301 37 177 302 minecraft:red_nether_bricks
setblock 37 177 303 minecraft:nether_wart_block
fill 42 177 306 42 216 306 minecraft:blackstone
fill 8 178 291 10 178 292 minecraft:yellow_wool
fill 8 178 293 10 178 295 minecraft:orange_wool
fill 9 178 289 11 178 290 minecraft:orange_wool
setblock 9 178 296 minecraft:orange_wool
fill 9 178 297 11 178 297 minecraft:yellow_wool
fill 10 178 287 10 178 288 minecraft:orange_wool
fill 10 178 296 11 178 296 minecraft:yellow_wool
setblock 10 178 298 minecraft:yellow_wool
fill 10 178 299 13 178 299 minecraft:orange_wool
fill 11 178 275 11 204 275 minecraft:blackstone
fill 11 178 286 12 178 287 minecraft:yellow_wool
setblock 11 178 288 minecraft:orange_wool
fill 11 178 298 12 178 298 minecraft:orange_wool
fill 11 178 300 13 178 300 minecraft:orange_wool
setblock 12 178 288 minecraft:yellow_wool
fill 13 178 285 16 178 286 minecraft:orange_wool
fill 13 178 287 13 179 287 minecraft:yellow_wool
fill 13 178 301 15 178 301 minecraft:yellow_wool
fill 14 178 287 14 179 287 minecraft:orange_wool
fill 14 178 299 14 178 300 minecraft:yellow_wool
fill 15 178 284 15 179 284 minecraft:orange_wool
setblock 15 178 300 minecraft:yellow_wool
fill 15 178 302 19 178 302 minecraft:orange_wool
fill 16 178 284 18 178 284 minecraft:yellow_wool
fill 16 178 300 18 178 301 minecraft:orange_wool
fill 17 178 285 17 178 286 minecraft:yellow_wool
fill 18 178 285 21 178 286 minecraft:orange_wool
fill 19 178 284 19 179 284 minecraft:orange_wool
fill 19 178 300 20 178 301 minecraft:yellow_wool
fill 20 178 287 20 179 287 minecraft:orange_wool
fill 20 178 299 20 179 299 minecraft:yellow_wool
fill 21 178 287 23 178 287 minecraft:yellow_wool
fill 21 178 299 23 178 300 minecraft:orange_wool
fill 21 178 301 21 179 301 minecraft:yellow_wool
fill 22 178 286 23 178 286 minecraft:yellow_wool
setblock 22 178 288 minecraft:yellow_wool
fill 22 178 298 23 178 298 minecraft:orange_wool
fill 23 178 288 24 178 290 minecraft:orange_wool
fill 23 178 296 24 178 297 minecraft:yellow_wool
setblock 24 178 287 minecraft:orange_wool
fill 24 178 291 26 178 292 minecraft:yellow_wool
fill 24 178 293 26 178 295 minecraft:orange_wool
setblock 24 178 298 minecraft:yellow_wool
setblock 24 178 299 minecraft:orange_wool
fill 25 178 289 25 178 290 minecraft:orange_wool
setblock 25 178 296 minecraft:orange_wool
setblock 25 178 297 minecraft:yellow_wool
fill 32 178 304 34 178 304 minecraft:red_nether_bricks
setblock 32 178 305 minecraft:nether_wart_block
fill 32 178 317 32 219 317 minecraft:blackstone
fill 33 178 300 34 178 301 minecraft:red_nether_bricks
setblock 33 178 302 minecraft:nether_wart_block
fill 33 178 303 33 179 303 minecraft:red_nether_bricks
fill 33 178 305 35 178 305 minecraft:red_nether_bricks
setblock 33 178 306 minecraft:nether_wart_block
setblock 34 178 298 minecraft:red_nether_bricks
setblock 34 178 299 minecraft:nether_wart_block
setblock 34 178 302 minecraft:red_nether_bricks
setblock 34 178 303 minecraft:nether_wart_block
setblock 34 178 306 minecraft:red_nether_bricks
setblock 35 178 297 minecraft:red_nether_bricks
fill 35 178 298 36 178 300 minecraft:orange_terracotta
fill 35 178 301 35 180 301 minecraft:red_nether_bricks
fill 35 178 302 35 181 302 minecraft:bone_block
fill 35 178 303 37 178 303 minecraft:red_nether_bricks
setblock 35 178 304 minecraft:nether_wart_block
fill 36 178 295 36 180 297 minecraft:orange_terracotta
setblock 36 178 301 minecraft:nether_wart_block
fill 36 178 302 36 180 302 minecraft:red_nether_bricks
setblock 36 178 304 minecraft:red_nether_bricks
fill 37 178 296 37 179 297 minecraft:orange_terracotta
setblock 37 178 298 minecraft:nether_wart_block
setblock 37 178 299 minecraft:orange_terracotta
fill 37 178 300 38 178 301 minecraft:red_nether_bricks
setblock 37 178 302 minecraft:nether_wart_block
setblock 38 178 298 minecraft:red_nether_bricks
setblock 38 178 299 minecraft:nether_wart_block
setblock 0 179 311 minecraft:purple_concrete
fill 8 179 293 10 179 293 minecraft:yellow_wool
fill 8 179 294 10 179 295 minecraft:orange_wool
fill 9 179 289 11 179 289 minecraft:orange_wool
setblock 9 179 290 minecraft:yellow_wool
fill 9 179 296 10 179 296 minecraft:yellow_wool
setblock 10 179 287 minecraft:yellow_wool
setblock 10 179 288 minecraft:orange_wool
fill 10 179 290 11 179 290 minecraft:orange_wool
setblock 10 179 291 minecraft:yellow_wool
setblock 10 179 299 minecraft:yellow_wool
setblock 11 179 288 minecraft:yellow_wool
setblock 11 179 298 minecraft:yellow_wool
fill 11 179 299 12 179 300 minecraft:orange_wool
setblock 12 179 298 minecraft:orange_wool
fill 13 179 285 15 179 285 minecraft:orange_wool
setblock 13 179 286 minecraft:yellow_wool
setblock 13 179 299 minecraft:orange_wool
fill 13 179 300 13 179 301 minecraft:yellow_wool
fill 14 179 286 15 179 286 minecraft:orange_wool
setblock 14 179 299 minecraft:yellow_wool
fill 15 179 301 15 179 302 minecraft:yellow_wool
fill 16 179 284 16 179 286 minecraft:yellow_wool
fill 16 179 300 16 180 300 minecraft:yellow_wool
fill 16 179 301 18 179 302 minecraft:orange_wool
setblock 17 179 300 minecraft:orange_wool
fill 18 179 284 18 179 286 minecraft:yellow_wool
fill 18 179 300 18 180 300 minecraft:yellow_wool
fill 19 179 285 20 179 286 minecraft:orange_wool
fill 19 179 301 19 179 302 minecraft:yellow_wool
setblock 21 179 285 minecraft:orange_wool
fill 21 179 286 21 179 287 minecraft:yellow_wool
fill 21 179 299 23 179 299 minecraft:orange_wool
setblock 21 179 300 minecraft:yellow_wool
setblock 22 179 298 minecraft:orange_wool
fill 22 179 300 23 179 300 minecraft:orange_wool
setblock 23 179 288 minecraft:yellow_wool
fill 23 179 289 24 179 290 minecraft:orange_wool
setblock 23 179 298 minecraft:yellow_wool
setblock 24 179 287 minecraft:yellow_wool
setblock 24 179 288 minecraft:orange_wool
setblock 24 179 291 minecraft:yellow_wool
fill 24 179 293 26 179 293 minecraft:yellow_wool
fill 24 179 294 26 179 295 minecraft:orange_wool
fill 24 179 296 25 179 296 minecraft:yellow_wool
setblock 24 179 299 minecraft:yellow_wool
setblock 25 179 289 minecraft:orange_wool
setblock 25 179 290 minecraft:yellow_wool
setblock 33 179 301 minecraft:nether_wart_block
setblock 33 179 302 minecraft:red_nether_bricks
setblock 34 179 297 minecraft:red_nether_bricks
setblock 34 179 298 minecraft:nether_wart_block
fill 34 179 299 34 179 301 minecraft:red_nether_bricks
setblock 34 179 302 minecraft:nether_wart_block
fill 34 179 303 34 179 304 minecraft:red_nether_bricks
fill 35 179 295 35 179 297 minecraft:orange_terracotta
fill 35 179 298 37 179 298 minecraft:red_nether_bricks
setblock 35 179 299 minecraft:nether_wart_block
fill 35 179 300 35 181 300 minecraft:red_nether_bricks
setblock 35 179 303 minecraft:nether_wart_block
setblock 35 179 304 minecraft:red_nether_bricks
fill 36 179 294 37 179 294 minecraft:red_nether_bricks
fill 36 179 299 38 179 299 minecraft:red_nether_bricks
setblock 36 179 300 minecraft:nether_wart_block
fill 36 179 301 36 180 301 minecraft:red_nether_bricks
setblock 36 179 303 minecraft:red_nether_bricks
fill 37 179 295 37 180 295 minecraft:orange_terracotta
fill 37 179 300 38 179 300 minecraft:red_nether_bricks
setblock 37 179 301 minecraft:nether_wart_block
setblock 37 179 302 minecraft:red_nether_bricks
fill 38 179 296 38 179 297 minecraft:red_nether_bricks
setblock 38 179 298 minecraft:nether_wart_block
setblock 38 179 301 minecraft:red_nether_bricks
fill 0 180 311 0 186 311 minecraft:blackstone
setblock 3 180 278 minecraft:light[level=12]
setblock 3 180 285 minecraft:light[level=12]
setblock 3 180 292 minecraft:light[level=12]
setblock 3 180 299 minecraft:light[level=12]
setblock 3 180 306 minecraft:light[level=12]
setblock 3 180 313 minecraft:light[level=12]
fill 8 180 294 10 180 295 minecraft:yellow_wool
fill 9 180 289 11 180 289 minecraft:yellow_wool
setblock 10 180 278 minecraft:light[level=12]
setblock 10 180 285 minecraft:light[level=12]
setblock 10 180 288 minecraft:yellow_wool
fill 10 180 290 11 180 290 minecraft:yellow_wool
setblock 10 180 292 minecraft:light[level=12]
setblock 10 180 299 minecraft:light[level=12]
setblock 10 180 306 minecraft:light[level=12]
setblock 10 180 313 minecraft:light[level=12]
fill 11 180 299 12 180 300 minecraft:yellow_wool
setblock 12 180 298 minecraft:yellow_wool
fill 13 180 285 15 180 285 minecraft:yellow_wool
setblock 13 180 299 minecraft:yellow_wool
fill 14 180 286 14 180 287 minecraft:yellow_wool
setblock 15 180 284 minecraft:yellow_wool
setblock 15 180 286 minecraft:yellow_wool
fill 16 180 301 18 180 302 minecraft:yellow_wool
setblock 17 180 278 minecraft:light[level=12]
setblock 17 180 285 minecraft:light[level=12]
setblock 17 180 299 minecraft:light[level=12]
setblock 17 180 300 minecraft:yellow_wool
setblock 17 180 306 minecraft:light[level=12]
setblock 17 180 313 minecraft:light[level=12]
fill 19 180 284 19 180 286 minecraft:yellow_wool
fill 20 180 285 20 180 287 minecraft:yellow_wool
setblock 21 180 285 minecraft:yellow_wool
fill 21 180 299 23 180 299 minecraft:yellow_wool
setblock 22 180 298 minecraft:yellow_wool
fill 22 180 300 23 180 300 minecraft:yellow_wool
fill 23 180 289 24 180 290 minecraft:yellow_wool
setblock 24 180 278 minecraft:light[level=12]
setblock 24 180 285 minecraft:light[level=12]
setblock 24 180 288 minecraft:yellow_wool
setblock 24 180 292 minecraft:light[level=12]
fill 24 180 294 26 180 295 minecraft:yellow_wool
setblock 24 180 299 minecraft:light[level=12]
setblock 24 180 306 minecraft:light[level=12]
setblock 24 180 313 minecraft:light[level=12]
setblock 25 180 289 minecraft:yellow_wool
setblock 31 180 278 minecraft:light[level=12]
setblock 31 180 285 minecraft:light[level=12]
setblock 31 180 292 minecraft:light[level=12]
setblock 31 180 299 minecraft:light[level=12]
setblock 31 180 306 minecraft:light[level=12]
setblock 31 180 313 minecraft:light[level=12]
fill 34 180 294 34 180 296 minecraft:red_nether_bricks
setblock 34 180 297 minecraft:nether_wart_block
fill 34 180 298 34 180 300 minecraft:red_nether_bricks
setblock 34 180 301 minecraft:nether_wart_block
setblock 34 180 302 minecraft:red_nether_bricks
fill 35 180 292 36 181 294 minecraft:orange_terracotta
fill 35 180 295 35 180 297 minecraft:red_nether_bricks
setblock 35 180 298 minecraft:nether_wart_block
fill 35 180 299 35 181 299 minecraft:red_nether_bricks
fill 36 180 298 38 180 298 minecraft:red_nether_bricks
setblock 36 180 299 minecraft:nether_wart_block
fill 36 180 300 36 181 300 minecraft:red_nether_bricks
fill 37 180 293 37 181 293 minecraft:orange_terracotta
fill 37 180 294 38 181 294 minecraft:red_nether_bricks
setblock 37 180 296 minecraft:orange_terracotta
fill 37 180 297 37 182 297 minecraft:red_nether_bricks
fill 37 180 299 38 180 299 minecraft:red_nether_bricks
setblock 37 180 300 minecraft:nether_wart_block
setblock 37 180 301 minecraft:red_nether_bricks
setblock 38 180 278 minecraft:light[level=12]
setblock 38 180 285 minecraft:light[level=12]
setblock 38 180 292 minecraft:light[level=12]
fill 38 180 295 38 180 296 minecraft:red_nether_bricks
setblock 38 180 297 minecraft:nether_wart_block
setblock 38 180 300 minecraft:red_nether_bricks
setblock 38 180 306 minecraft:light[level=12]
setblock 38 180 313 minecraft:light[level=12]
fill 39 180 290 39 189 290 minecraft:polished_blackstone
setblock 42 180 310 minecraft:amethyst_block
setblock 0 181 297 minecraft:amethyst_block
fill 0 181 298 0 186 300 minecraft:blackstone
setblock 34 181 291 minecraft:red_nether_bricks
setblock 34 181 292 minecraft:nether_wart_block
fill 34 181 293 34 181 295 minecraft:red_nether_bricks
setblock 34 181 296 minecraft:nether_wart_block
fill 34 181 297 34 181 298 minecraft:red_nether_bricks
fill 35 181 290 35 182 291 minecraft:orange_terracotta
fill 35 181 295 35 181 296 minecraft:red_nether_bricks
setblock 35 181 297 minecraft:nether_wart_block
fill 35 181 298 35 182 298 minecraft:red_nether_bricks
setblock 36 181 290 minecraft:nether_wart_block
fill 36 181 291 36 182 291 minecraft:orange_terracotta
fill 36 181 295 36 184 296 minecraft:bone_block
setblock 36 181 297 minecraft:red_nether_bricks
setblock 36 181 298 minecraft:nether_wart_block
fill 36 181 299 36 182 299 minecraft:red_nether_bricks
setblock 37 181 291 minecraft:nether_wart_block
setblock 37 181 292 minecraft:orange_terracotta
setblock 37 181 295 minecraft:nether_wart_block
fill 37 181 296 37 183 296 minecraft:red_nether_bricks
fill 37 181 298 38 181 298 minecraft:red_nether_bricks
setblock 37 181 299 minecraft:nether_wart_block
setblock 37 181 300 minecraft:red_nether_bricks
setblock 38 181 292 minecraft:nether_wart_block
fill 38 181 293 38 183 293 minecraft:red_nether_bricks
setblock 38 181 295 minecraft:red_nether_bricks
setblock 38 181 296 minecraft:nether_wart_block
fill 38 181 297 38 182 297 minecraft:red_nether_bricks
setblock 38 181 299 minecraft:red_nether_bricks
fill 42 181 310 42 202 310 minecraft:blackstone
fill 0 182 297 0 219 297 minecraft:blackstone
fill 0 182 302 0 216 303 minecraft:blackstone
setblock 0 182 304 minecraft:magma_block
fill 19 182 317 21 188 317 minecraft:blackstone
setblock 22 182 317 minecraft:purple_concrete
fill 23 182 317 23 219 317 minecraft:blackstone
fill 34 182 288 34 183 290 minecraft:orange_terracotta
setblock 34 182 291 minecraft:nether_wart_block
fill 34 182 292 34 182 294 minecraft:red_nether_bricks
setblock 34 182 295 minecraft:nether_wart_block
setblock 34 182 296 minecraft:red_nether_bricks
fill 35 182 288 35 183 289 minecraft:orange_terracotta
fill 35 182 292 36 182 292 minecraft:orange_terracotta
fill 35 182 293 35 182 295 minecraft:red_nether_bricks
setblock 35 182 296 minecraft:nether_wart_block
setblock 35 182 297 minecraft:red_nether_bricks
fill 36 182 289 36 182 290 minecraft:orange_terracotta
setblock 36 182 293 minecraft:orange_terracotta
fill 36 182 294 36 184 294 minecraft:red_nether_bricks
setblock 36 182 297 minecraft:nether_wart_block
setblock 36 182 298 minecraft:red_nether_bricks
setblock 37 182 290 minecraft:nether_wart_block
fill 37 182 291 37 182 293 minecraft:red_nether_bricks
setblock 37 182 294 minecraft:nether_wart_block
fill 37 182 295 37 183 295 minecraft:red_nether_bricks
setblock 37 182 298 minecraft:nether_wart_block
fill 38 182 292 38 183 292 minecraft:red_nether_bricks
setblock 38 182 294 minecraft:red_nether_bricks
setblock 38 182 295 minecraft:nether_wart_block
setblock 38 182 296 minecraft:red_nether_bricks
fill 0 183 280 0 204 280 minecraft:blackstone
setblock 0 183 281 minecraft:magma_block
fill 0 183 304 0 219 304 minecraft:blackstone
setblock 3 183 278 minecraft:light[level=12]
setblock 3 183 286 minecraft:light[level=12]
setblock 3 183 294 minecraft:light[level=12]
setblock 3 183 302 minecraft:light[level=12]
setblock 3 183 310 minecraft:light[level=12]
setblock 11 183 278 minecraft:light[level=12]
setblock 11 183 286 minecraft:light[level=12]
setblock 11 183 294 minecraft:light[level=12]
setblock 11 183 302 minecraft:light[level=12]
setblock 11 183 310 minecraft:light[level=12]
setblock 19 183 278 minecraft:light[level=12]
setblock 19 183 286 minecraft:light[level=12]
setblock 19 183 294 minecraft:light[level=12]
setblock 19 183 302 minecraft:light[level=12]
setblock 19 183 310 minecraft:light[level=12]
fill 22 183 317 22 198 317 minecraft:blackstone
fill 25 183 275 25 219 275 minecraft:blackstone
setblock 26 183 275 minecraft:amethyst_block
fill 27 183 275 27 219 275 minecraft:blackstone
setblock 27 183 278 minecraft:light[level=12]
setblock 27 183 286 minecraft:light[level=12]
setblock 27 183 294 minecraft:light[level=12]
setblock 27 183 302 minecraft:light[level=12]
setblock 27 183 310 minecraft:light[level=12]
fill 33 183 286 33 185 287 minecraft:orange_terracotta
setblock 33 183 288 minecraft:red_nether_bricks
setblock 33 183 289 minecraft:orange_terracotta
fill 33 183 290 33 183 292 minecraft:red_nether_bricks
setblock 34 183 287 minecraft:red_nether_bricks
fill 34 183 291 34 183 293 minecraft:red_nether_bricks
setblock 34 183 294 minecraft:nether_wart_block
setblock 35 183 278 minecraft:light[level=12]
setblock 35 183 286 minecraft:light[level=12]
setblock 35 183 287 minecraft:nether_wart_block
fill 35 183 290 36 183 290 minecraft:orange_terracotta
setblock 35 183 291 minecraft:nether_wart_block
fill 35 183 292 35 183 294 minecraft:red_nether_bricks
setblock 35 183 295 minecraft:nether_wart_block
setblock 35 183 296 minecraft:red_nether_bricks
setblock 35 183 302 minecraft:light[level=12]
setblock 35 183 310 minecraft:light[level=12]
setblock 36 183 288 minecraft:nether_wart_block
fill 36 183 289 36 185 289 minecraft:red_nether_bricks
fill 36 183 291 38 183 291 minecraft:red_nether_bricks
setblock 36 183 292 minecraft:nether_wart_block
fill 36 183 293 36 185 293 minecraft:red_nether_bricks
setblock 36 183 297 minecraft:red_nether_bricks
setblock 37 183 289 minecraft:nether_wart_block
fill 37 183 290 37 185 290 minecraft:red_nether_bricks
setblock 37 183 292 minecraft:red_nether_bricks
setblock 37 183 293 minecraft:nether_wart_block
fill 37 183 294 37 184 294 minecraft:red_nether_bricks
setblock 38 183 294 minecraft:nether_wart_block
setblock 38 183 295 minecraft:red_nether_bricks
fill 0 184 281 0 219 281 minecraft:blackstone
fill 26 184 275 26 219 275 minecraft:blackstone
setblock 31 184 286 minecraft:nether_wart_block
fill 32 184 285 32 185 287 minecraft:orange_terracotta
fill 32 184 288 32 185 289 minecraft:red_nether_bricks
fill 33 184 285 33 185 285 minecraft:orange_terracotta
fill 33 184 288 34 184 288 minecraft:orange_terracotta
fill 33 184 289 33 184 291 minecraft:red_nether_bricks
setblock 34 184 285 minecraft:nether_wart_block
fill 34 184 286 34 184 287 minecraft:orange_terracotta
fill 34 184 289 35 184 289 minecraft:orange_terracotta
fill 34 184 290 34 184 292 minecraft:red_nether_bricks
setblock 34 184 293 minecraft:nether_wart_block
setblock 35 184 286 minecraft:nether_wart_block
fill 35 184 287 35 185 288 minecraft:red_nether_bricks
setblock 35 184 290 minecraft:nether_wart_block
fill 35 184 291 35 184 293 minecraft:red_nether_bricks
setblock 35 184 294 minecraft:nether_wart_block
setblock 36 184 287 minecraft:nether_wart_block
fill 36 184 288 36 186 288 minecraft:red_nether_bricks
setblock 36 184 290 minecraft:red_nether_bricks
setblock 36 184 291 minecraft:nether_wart_block
fill 36 184 292 36 185 292 minecraft:red_nether_bricks
fill 37 184 289 37 185 289 minecraft:red_nether_bricks
setblock 37 184 291 minecraft:red_nether_bricks
setblock 37 184 292 minecraft:nether_wart_block
setblock 37 184 293 minecraft:red_nether_bricks
setblock 0 185 277 minecraft:amethyst_block
setblock 0 185 295 minecraft:amethyst_block
fill 29 185 317 29 219 317 minecraft:blackstone
fill 30 185 284 31 186 285 minecraft:orange_terracotta
fill 30 185 286 30 186 286 minecraft:red_nether_bricks
setblock 30 185 317 minecraft:magma_block
setblock 31 185 286 minecraft:orange_terracotta
fill 31 185 287 31 185 288 minecraft:red_nether_bricks
fill 31 185 317 31 219 317 minecraft:blackstone
fill 32 185 284 33 186 284 minecraft:red_nether_bricks
fill 33 185 288 33 185 290 minecraft:red_nether_bricks
setblock 33 185 291 minecraft:nether_wart_block
fill 34 185 285 34 186 286 minecraft:red_nether_bricks
setblock 34 185 287 minecraft:orange_terracotta
setblock 34 185 288 minecraft:nether_wart_block
fill 34 185 289 34 188 289 minecraft:bone_block
fill 34 185 290 35 185 291 minecraft:red_nether_bricks
setblock 34 185 292 minecraft:nether_wart_block
fill 35 185 286 35 187 286 minecraft:red_nether_bricks
setblock 35 185 289 minecraft:nether_wart_block
setblock 35 185 292 minecraft:red_nether_bricks
setblock 35 185 293 minecraft:nether_wart_block
fill 36 185 287 36 186 287 minecraft:red_nether_bricks
setblock 36 185 290 minecraft:nether_wart_block
setblock 36 185 291 minecraft:red_nether_bricks
setblock 37 185 291 minecraft:nether_wart_block
setblock 37 185 292 minecraft:red_nether_bricks
fill 38 185 290 38 189 290 minecraft:polished_blackstone
fill 39 185 289 39 189 289 minecraft:polished_blackstone
fill 39 185 291 39 189 291 minecraft:polished_blackstone
fill 40 185 290 40 189 290 minecraft:polished_blackstone
setblock 42 185 280 minecraft:purple_concrete
fill 0 186 277 0 219 277 minecraft:blackstone
fill 0 186 295 0 219 295 minecraft:blackstone
setblock 3 186 278 minecraft:light[level=12]
setblock 3 186 285 minecraft:light[level=12]
setblock 3 186 292 minecraft:light[level=12]
setblock 3 186 299 minecraft:light[level=12]
setblock 3 186 306 minecraft:light[level=12]
setblock 3 186 313 minecraft:light[level=12]
fill 5 186 275 8 187 275 minecraft:blackstone
fill 6 186 317 6 216 317 minecraft:blackstone
setblock 7 186 317 minecraft:crying_obsidian
setblock 9 186 275 minecraft:magma_block
fill 10 186 275 10 219 275 minecraft:blackstone
setblock 10 186 278 minecraft:light[level=12]
setblock 10 186 285 minecraft:light[level=12]
setblock 10 186 292 minecraft:light[level=12]
setblock 10 186 299 minecraft:light[level=12]
setblock 10 186 306 minecraft:light[level=12]
setblock 10 186 313 minecraft:light[level=12]
setblock 17 186 278 minecraft:light[level=12]
setblock 17 186 285 minecraft:light[level=12]
setblock 17 186 292 minecraft:light[level=12]
setblock 17 186 299 minecraft:light[level=12]
setblock 17 186 306 minecraft:light[level=12]
setblock 17 186 313 minecraft:light[level=12]
setblock 24 186 278 minecraft:light[level=12]
setblock 24 186 285 minecraft:light[level=12]
setblock 24 186 292 minecraft:light[level=12]
setblock 24 186 299 minecraft:light[level=12]
setblock 24 186 306 minecraft:light[level=12]
setblock 24 186 313 minecraft:light[level=12]
fill 29 186 283 29 187 284 minecraft:orange_terracotta
setblock 29 186 285 minecraft:red_nether_bricks
setblock 30 186 282 minecraft:red_nether_bricks
fill 30 186 283 31 186 283 minecraft:orange_terracotta
setblock 30 186 287 minecraft:nether_wart_block
fill 30 186 317 30 219 317 minecraft:blackstone
setblock 31 186 278 minecraft:light[level=12]
fill 31 186 286 31 186 287 minecraft:red_nether_bricks
setblock 31 186 288 minecraft:nether_wart_block
setblock 31 186 292 minecraft:light[level=12]
setblock 31 186 299 minecraft:light[level=12]
setblock 31 186 306 minecraft:light[level=12]
setblock 31 186 313 minecraft:light[level=12]
fill 32 186 283 32 187 283 minecraft:red_nether_bricks
setblock 32 186 285 minecraft:nether_wart_block
setblock 32 186 286 minecraft:orange_terracotta
fill 32 186 287 33 186 288 minecraft:red_nether_bricks
setblock 32 186 289 minecraft:nether_wart_block
setblock 33 186 285 minecraft:red_nether_bricks
setblock 33 186 286 minecraft:nether_wart_block
setblock 33 186 289 minecraft:red_nether_bricks
setblock 33 186 290 minecraft:nether_wart_block
fill 34 186 284 34 187 284 minecraft:red_nether_bricks
setblock 34 186 287 minecraft:nether_wart_block
fill 34 186 288 34 187 288 minecraft:red_nether_bricks
fill 34 186 290 36 186 290 minecraft:red_nether_bricks
setblock 34 186 291 minecraft:nether_wart_block
setblock 35 186 287 minecraft:red_nether_bricks
setblock 35 186 288 minecraft:nether_wart_block
fill 35 186 289 35 187 289 minecraft:red_nether_bricks
setblock 35 186 291 minecraft:red_nether_bricks
setblock 36 186 289 minecraft:nether_wart_block
setblock 38 186 278 minecraft:light[level=12]
setblock 38 186 285 minecraft:light[level=12]
setblock 38 186 292 minecraft:light[level=12]
setblock 38 186 299 minecraft:light[level=12]
setblock 38 186 306 minecraft:light[level=12]
setblock 38 186 313 minecraft:light[level=12]
setblock 40 186 275 minecraft:purple_concrete
fill 42 186 280 42 219 280 minecraft:blackstone
fill 0 187 298 0 219 299 minecraft:blackstone
setblock 0 187 300 minecraft:purple_concrete
setblock 0 187 311 minecraft:magma_block
fill 7 187 317 7 219 317 minecraft:blackstone
fill 9 187 275 9 216 275 minecraft:blackstone
fill 26 187 282 28 189 282 minecraft:orange_terracotta
fill 27 187 283 28 188 283 minecraft:orange_terracotta
setblock 28 187 281 minecraft:red_nether_bricks
setblock 28 187 284 minecraft:nether_wart_block
fill 28 187 285 28 189 285 minecraft:red_nether_bricks
setblock 29 187 281 minecraft:nether_wart_block
fill 29 187 282 29 189 282 minecraft:red_nether_bricks
setblock 29 187 285 minecraft:nether_wart_block
fill 29 187 286 29 188 286 minecraft:red_nether_bricks
setblock 30 187 282 minecraft:nether_wart_block
fill 30 187 283 30 187 284 minecraft:orange_terracotta
fill 30 187 285 32 187 285 minecraft:red_nether_bricks
setblock 30 187 286 minecraft:nether_wart_block
setblock 30 187 287 minecraft:red_nether_bricks
setblock 31 187 282 minecraft:red_nether_bricks
setblock 31 187 283 minecraft:nether_wart_block
setblock 31 187 284 minecraft:orange_terracotta
fill 31 187 286 33 187 286 minecraft:red_nether_bricks
setblock 31 187 287 minecraft:nether_wart_block
setblock 31 187 288 minecraft:red_nether_bricks
setblock 32 187 284 minecraft:nether_wart_block
fill 32 187 287 34 187 287 minecraft:red_nether_bricks
setblock 32 187 288 minecraft:nether_wart_block
fill 33 187 283 33 187 284 minecraft:red_nether_bricks
setblock 33 187 285 minecraft:nether_wart_block
setblock 33 187 288 minecraft:red_nether_bricks
setblock 33 187 289 minecraft:nether_wart_block
setblock 34 187 285 minecraft:red_nether_bricks
setblock 34 187 286 minecraft:nether_wart_block
setblock 35 187 287 minecraft:nether_wart_block
setblock 35 187 288 minecraft:red_nether_bricks
fill 38 187 289 38 189 289 minecraft:polished_blackstone
fill 38 187 291 38 189 291 minecraft:polished_blackstone
fill 40 187 275 40 219 275 minecraft:blackstone
fill 40 187 289 40 189 289 minecraft:polished_blackstone
fill 40 187 291 40 189 291 minecraft:polished_blackstone
fill 0 188 300 0 203 300 minecraft:blackstone
fill 0 188 311 0 217 311 minecraft:blackstone
fill 5 188 275 7 204 275 minecraft:blackstone
setblock 8 188 275 minecraft:crying_obsidian
fill 12 188 275 12 211 275 minecraft:blackstone
setblock 13 188 275 minecraft:amethyst_block
fill 25 188 281 25 188 282 minecraft:red_nether_bricks
fill 26 188 281 28 188 281 minecraft:orange_terracotta
setblock 26 188 283 minecraft:orange_terracotta
fill 27 188 284 28 189 284 minecraft:red_nether_bricks
fill 29 188 281 29 190 281 minecraft:red_nether_bricks
setblock 29 188 283 minecraft:red_nether_bricks
setblock 29 188 284 minecraft:nether_wart_block
fill 29 188 285 29 190 285 minecraft:red_nether_bricks
setblock 30 188 281 minecraft:nether_wart_block
fill 30 188 282 30 190 282 minecraft:red_nether_bricks
fill 30 188 283 30 191 284 minecraft:bone_block
setblock 30 188 285 minecraft:nether_wart_block
fill 30 188 286 30 189 286 minecraft:red_nether_bricks
setblock 31 188 282 minecraft:nether_wart_block
fill 31 188 283 31 188 285 minecraft:red_nether_bricks
setblock 31 188 286 minecraft:nether_wart_block
setblock 31 188 287 minecraft:red_nether_bricks
setblock 32 188 283 minecraft:nether_wart_block
fill 32 188 284 32 188 286 minecraft:red_nether_bricks
setblock 32 188 287 minecraft:nether_wart_block
setblock 33 188 284 minecraft:nether_wart_block
fill 33 188 285 33 188 287 minecraft:red_nether_bricks
setblock 34 188 285 minecraft:nether_wart_block
fill 34 188 286 34 188 287 minecraft:red_nether_bricks
fill 8 189 275 8 200 275 minecraft:blackstone
fill 13 189 275 13 219 275 minecraft:blackstone
fill 19 189 317 19 217 317 minecraft:blackstone
setblock 20 189 317 minecraft:crying_obsidian
fill 21 189 317 21 195 317 minecraft:blackstone
fill 23 189 281 25 190 282 minecraft:orange_terracotta
fill 24 189 280 24 190 280 minecraft:orange_terracotta
fill 24 189 283 24 191 283 minecraft:red_nether_bricks
fill 25 189 280 25 191 280 minecraft:red_nether_bricks
setblock 25 189 283 minecraft:nether_wart_block
setblock 26 189 280 minecraft:nether_wart_block
fill 26 189 281 27 189 281 minecraft:orange_terracotta
setblock 26 189 283 minecraft:red_nether_bricks
setblock 26 189 284 minecraft:nether_wart_block
fill 27 189 280 28 189 280 minecraft:red_nether_bricks
setblock 27 189 283 minecraft:orange_terracotta
setblock 28 189 281 minecraft:red_nether_bricks
fill 28 189 283 28 191 283 minecraft:red_nether_bricks
setblock 29 189 283 minecraft:nether_wart_block
fill 29 189 284 29 191 284 minecraft:red_nether_bricks
setblock 30 189 281 minecraft:red_nether_bricks
fill 30 189 285 30 190 285 minecraft:red_nether_bricks
fill 31 189 282 31 189 284 minecraft:red_nether_bricks
setblock 31 189 285 minecraft:nether_wart_block
setblock 31 189 286 minecraft:red_nether_bricks
fill 32 189 283 32 189 285 minecraft:red_nether_bricks
setblock 32 189 286 minecraft:nether_wart_block
setblock 3 190 278 minecraft:light[level=12]
setblock 3 190 286 minecraft:light[level=12]
setblock 3 190 294 minecraft:light[level=12]
setblock 3 190 302 minecraft:light[level=12]
setblock 3 190 310 minecraft:light[level=12]
setblock 11 190 278 minecraft:light[level=12]
setblock 11 190 286 minecraft:light[level=12]
setblock 11 190 294 minecraft:light[level=12]
setblock 11 190 302 minecraft:light[level=12]
setblock 11 190 310 minecraft:light[level=12]
setblock 19 190 278 minecraft:light[level=12]
setblock 19 190 286 minecraft:light[level=12]
setblock 19 190 294 minecraft:light[level=12]
setblock 19 190 302 minecraft:light[level=12]
setblock 19 190 310 minecraft:light[level=12]
fill 20 190 317 20 219 317 minecraft:blackstone
fill 21 190 280 22 190 280 minecraft:red_nether_bricks
fill 21 190 281 22 191 281 minecraft:orange_terracotta
setblock 22 190 282 minecraft:red_nether_bricks
fill 23 190 279 25 190 279 minecraft:red_nether_bricks
fill 23 190 280 23 191 280 minecraft:orange_terracotta
setblock 23 190 283 minecraft:red_nether_bricks
fill 25 190 283 25 190 284 minecraft:red_nether_bricks
setblock 26 190 279 minecraft:nether_wart_block
fill 26 190 280 26 190 282 minecraft:red_nether_bricks
setblock 26 190 283 minecraft:nether_wart_block
fill 26 190 284 26 191 284 minecraft:red_nether_bricks
setblock 27 190 278 minecraft:light[level=12]
setblock 27 190 280 minecraft:nether_wart_block
fill 27 190 281 27 190 283 minecraft:red_nether_bricks
setblock 27 190 284 minecraft:nether_wart_block
setblock 27 190 286 minecraft:light[level=12]
setblock 27 190 294 minecraft:light[level=12]
setblock 27 190 302 minecraft:light[level=12]
setblock 27 190 310 minecraft:light[level=12]
setblock 28 190 280 minecraft:red_nether_bricks
setblock 28 190 281 minecraft:nether_wart_block
fill 28 190 282 28 192 282 minecraft:red_nether_bricks
setblock 28 190 284 minecraft:red_nether_bricks
setblock 28 190 285 minecraft:nether_wart_block
setblock 29 190 282 minecraft:nether_wart_block
fill 29 190 283 29 191 283 minecraft:red_nether_bricks
setblock 31 190 283 minecraft:red_nether_bricks
setblock 31 190 284 minecraft:nether_wart_block
setblock 35 190 278 minecraft:light[level=12]
setblock 35 190 286 minecraft:light[level=12]
setblock 35 190 294 minecraft:light[level=12]
setblock 35 190 302 minecraft:light[level=12]
setblock 35 190 310 minecraft:light[level=12]
fill 19 191 280 20 192 281 minecraft:orange_terracotta
fill 20 191 282 21 191 282 minecraft:orange_terracotta
fill 21 191 279 22 192 279 minecraft:red_nether_bricks
fill 21 191 280 21 192 280 minecraft:orange_terracotta
fill 22 191 280 22 192 280 minecraft:red_nether_bricks
setblock 22 191 282 minecraft:nether_wart_block
fill 22 191 283 22 193 283 minecraft:red_nether_bricks
setblock 23 191 279 minecraft:nether_wart_block
fill 23 191 281 24 191 281 minecraft:orange_terracotta
fill 23 191 282 25 191 282 minecraft:red_nether_bricks
setblock 23 191 283 minecraft:nether_wart_block
fill 24 191 279 26 191 279 minecraft:red_nether_bricks
setblock 24 191 280 minecraft:nether_wart_block
setblock 25 191 281 minecraft:nether_wart_block
fill 25 191 283 26 192 283 minecraft:red_nether_bricks
fill 26 191 280 27 191 281 minecraft:red_nether_bricks
setblock 26 191 282 minecraft:nether_wart_block
setblock 27 191 282 minecraft:red_nether_bricks
setblock 27 191 283 minecraft:nether_wart_block
setblock 27 191 284 minecraft:red_nether_bricks
setblock 28 191 281 minecraft:red_nether_bricks
setblock 28 191 284 minecraft:nether_wart_block
setblock 29 191 281 minecraft:nether_wart_block
setblock 29 191 282 minecraft:red_nether_bricks
setblock 3 192 278 minecraft:light[level=12]
setblock 3 192 285 minecraft:light[level=12]
setblock 3 192 292 minecraft:light[level=12]
setblock 3 192 299 minecraft:light[level=12]
setblock 3 192 306 minecraft:light[level=12]
setblock 3 192 313 minecraft:light[level=12]
setblock 3 192 317 minecraft:purple_concrete
setblock 10 192 278 minecraft:light[level=12]
setblock 10 192 285 minecraft:light[level=12]
setblock 10 192 292 minecraft:light[level=12]
setblock 10 192 299 minecraft:light[level=12]
setblock 10 192 306 minecraft:light[level=12]
setblock 10 192 313 minecraft:light[level=12]
setblock 17 192 278 minecraft:light[level=12]
fill 17 192 281 17 194 282 minecraft:orange_terracotta
setblock 17 192 285 minecraft:light[level=12]
setblock 17 192 292 minecraft:light[level=12]
setblock 17 192 299 minecraft:light[level=12]
setblock 17 192 306 minecraft:light[level=12]
setblock 17 192 313 minecraft:light[level=12]
setblock 18 192 280 minecraft:red_nether_bricks
fill 18 192 281 18 194 281 minecraft:orange_terracotta
setblock 18 192 282 minecraft:red_nether_bricks
fill 19 192 279 19 194 279 minecraft:red_nether_bricks
fill 19 192 282 20 192 282 minecraft:orange_terracotta
setblock 20 192 279 minecraft:nether_wart_block
setblock 20 192 283 minecraft:nether_wart_block
setblock 21 192 281 minecraft:orange_terracotta
fill 21 192 282 21 192 283 minecraft:red_nether_bricks
setblock 22 192 281 minecraft:nether_wart_block
fill 22 192 282 22 194 282 minecraft:red_nether_bricks
fill 23 192 279 23 193 280 minecraft:red_nether_bricks
fill 23 192 281 23 195 281 minecraft:bone_block
setblock 23 192 282 minecraft:nether_wart_block
fill 23 192 283 23 193 283 minecraft:red_nether_bricks
setblock 24 192 278 minecraft:light[level=12]
setblock 24 192 279 minecraft:nether_wart_block
fill 24 192 280 24 192 282 minecraft:red_nether_bricks
setblock 24 192 283 minecraft:nether_wart_block
setblock 24 192 285 minecraft:light[level=12]
setblock 24 192 292 minecraft:light[level=12]
setblock 24 192 299 minecraft:light[level=12]
setblock 24 192 306 minecraft:light[level=12]
setblock 24 192 313 minecraft:light[level=12]
setblock 25 192 279 minecraft:red_nether_bricks
setblock 25 192 280 minecraft:nether_wart_block
fill 25 192 281 25 193 282 minecraft:red_nether_bricks
setblock 26 192 280 minecraft:red_nether_bricks
setblock 26 192 281 minecraft:nether_wart_block
setblock 26 192 282 minecraft:red_nether_bricks
setblock 27 192 281 minecraft:red_nether_bricks
setblock 27 192 282 minecraft:nether_wart_block
setblock 27 192 283 minecraft:red_nether_bricks
setblock 31 192 278 minecraft:light[level=12]
setblock 31 192 285 minecraft:light[level=12]
setblock 31 192 292 minecraft:light[level=12]
setblock 31 192 299 minecraft:light[level=12]
setblock 31 192 306 minecraft:light[level=12]
setblock 31 192 313 minecraft:light[level=12]
setblock 38 192 278 minecraft:light[level=12]
setblock 38 192 285 minecraft:light[level=12]
setblock 38 192 292 minecraft:light[level=12]
setblock 38 192 299 minecraft:light[level=12]
setblock 38 192 306 minecraft:light[level=12]
setblock 38 192 313 minecraft:light[level=12]
fill 3 193 317 3 216 317 minecraft:blackstone
setblock 15 193 281 minecraft:nether_wart_block
fill 15 193 282 16 194 282 minecraft:orange_terracotta
fill 16 193 280 16 194 280 minecraft:red_nether_bricks
fill 16 193 281 16 194 281 minecraft:orange_terracotta
fill 16 193 283 16 195 283 minecraft:red_nether_bricks
setblock 17 193 280 minecraft:orange_terracotta
setblock 17 193 283 minecraft:nether_wart_block
setblock 18 193 279 minecraft:red_nether_bricks
setblock 18 193 280 minecraft:nether_wart_block
setblock 18 193 282 minecraft:orange_terracotta
fill 18 193 283 20 193 283 minecraft:red_nether_bricks
fill 19 193 280 21 193 280 minecraft:red_nether_bricks
fill 19 193 281 20 193 281 minecraft:orange_terracotta
fill 19 193 282 19 195 282 minecraft:red_nether_bricks
fill 20 193 279 20 195 279 minecraft:red_nether_bricks
setblock 20 193 282 minecraft:nether_wart_block
setblock 21 193 279 minecraft:nether_wart_block
fill 21 193 281 21 193 282 minecraft:red_nether_bricks
setblock 21 193 283 minecraft:nether_wart_block
setblock 22 193 279 minecraft:red_nether_bricks
setblock 22 193 280 minecraft:nether_wart_block
fill 22 193 281 22 195 281 minecraft:red_nether_bricks
fill 23 193 282 23 194 282 minecraft:red_nether_bricks
fill 24 193 279 24 193 281 minecraft:red_nether_bricks
setblock 24 193 282 minecraft:nether_wart_block
setblock 24 193 283 minecraft:red_nether_bricks
setblock 25 193 280 minecraft:red_nether_bricks
setblock 26 193 281 minecraft:red_nether_bricks
setblock 42 193 312 minecraft:amethyst_block
setblock 4 194 317 minecraft:amethyst_block
fill 13 194 282 14 196 283 minecraft:orange_terracotta
fill 14 194 281 14 195 281 minecraft:red_nether_bricks
setblock 15 194 280 minecraft:nether_wart_block
setblock 15 194 281 minecraft:orange_terracotta
fill 15 194 283 15 195 283 minecraft:orange_terracotta
fill 17 194 279 17 195 280 minecraft:red_nether_bricks
fill 17 194 283 17 196 283 minecraft:red_nether_bricks
setblock 18 194 279 minecraft:nether_wart_block
fill 18 194 280 18 196 280 minecraft:red_nether_bricks
setblock 18 194 282 minecraft:red_nether_bricks
setblock 18 194 283 minecraft:nether_wart_block
setblock 19 194 280 minecraft:nether_wart_block
fill 19 194 281 19 196 281 minecraft:red_nether_bricks
fill 19 194 283 21 194 283 minecraft:red_nether_bricks
fill 20 194 280 22 194 280 minecraft:red_nether_bricks
setblock 20 194 281 minecraft:nether_wart_block
fill 20 194 282 20 195 282 minecraft:red_nether_bricks
setblock 21 194 279 minecraft:red_nether_bricks
setblock 21 194 281 minecraft:red_nether_bricks
setblock 21 194 282 minecraft:nether_wart_block
setblock 22 194 279 minecraft:nether_wart_block
setblock 23 194 280 minecraft:nether_wart_block
setblock 24 194 281 minecraft:nether_wart_block
fill 37 194 312 37 202 312 minecraft:blackstone
fill 42 194 312 42 215 312 minecraft:blackstone
fill 4 195 317 4 215 317 minecraft:blackstone
fill 12 195 282 12 196 282 minecraft:red_nether_bricks
fill 12 195 283 12 196 283 minecraft:orange_terracotta
setblock 12 195 284 minecraft:nether_wart_block
setblock 13 195 281 minecraft:nether_wart_block
fill 13 195 284 14 195 284 minecraft:orange_terracotta
fill 14 195 280 15 196 280 minecraft:red_nether_bricks
fill 15 195 281 15 196 281 minecraft:red_nether_bricks
setblock 15 195 282 minecraft:orange_terracotta
fill 15 195 284 15 197 284 minecraft:red_nether_bricks
setblock 16 195 279 minecraft:red_nether_bricks
setblock 16 195 280 minecraft:nether_wart_block
fill 16 195 281 16 198 282 minecraft:bone_block
setblock 16 195 284 minecraft:nether_wart_block
setblock 17 195 281 minecraft:nether_wart_block
fill 17 195 282 17 197 282 minecraft:red_nether_bricks
setblock 17 195 284 minecraft:red_nether_bricks
setblock 18 195 279 minecraft:red_nether_bricks
setblock 18 195 281 minecraft:red_nether_bricks
setblock 18 195 282 minecraft:nether_wart_block
fill 18 195 283 18 196 283 minecraft:red_nether_bricks
setblock 19 195 279 minecraft:nether_wart_block
fill 19 195 280 19 196 280 minecraft:red_nether_bricks
setblock 19 195 283 minecraft:nether_wart_block
setblock 20 195 280 minecraft:nether_wart_block
fill 20 195 281 20 196 281 minecraft:red_nether_bricks
setblock 21 195 280 minecraft:red_nether_bricks
setblock 21 195 281 minecraft:nether_wart_block
setblock 21 195 282 minecraft:red_nether_bricks
fill 40 195 284 41 196 284 minecraft:amethyst_block
fill 41 195 283 41 196 283 minecraft:amethyst_block
fill 41 195 285 41 196 285 minecraft:amethyst_block
fill 10 196 284 12 197 285 minecraft:orange_terracotta
setblock 11 196 282 minecraft:nether_wart_block
fill 11 196 283 11 198 283 minecraft:red_nether_bricks
fill 12 196 281 13 197 281 minecraft:red_nether_bricks
setblock 13 196 284 minecraft:orange_terracotta
fill 13 196 285 13 198 285 minecraft:red_nether_bricks
setblock 14 196 281 minecraft:nether_wart_block
setblock 14 196 284 minecraft:red_nether_bricks
setblock 14 196 285 minecraft:nether_wart_block
setblock 15 196 282 minecraft:nether_wart_block
fill 15 196 283 15 198 283 minecraft:red_nether_bricks
fill 16 196 280 16 197 280 minecraft:red_nether_bricks
setblock 16 196 283 minecraft:nether_wart_block
fill 16 196 284 16 197 284 minecraft:red_nether_bricks
setblock 17 196 280 minecraft:nether_wart_block
fill 17 196 281 17 197 281 minecraft:red_nether_bricks
setblock 18 196 281 minecraft:nether_wart_block
fill 18 196 282 18 197 282 minecraft:red_nether_bricks
setblock 19 196 282 minecraft:nether_wart_block
setblock 21 196 317 minecraft:crying_obsidian
setblock 31 196 275 minecraft:crying_obsidian
fill 32 196 275 32 219 275 minecraft:blackstone
fill 42 196 283 42 204 283 minecraft:blackstone
setblock 42 196 284 minecraft:amethyst_block
setblock 0 197 294 minecraft:amethyst_block
fill 3 197 278 3 198 278 minecraft:light[level=12]
setblock 3 197 286 minecraft:light[level=12]
setblock 3 197 294 minecraft:light[level=12]
setblock 3 197 302 minecraft:light[level=12]
setblock 3 197 310 minecraft:light[level=12]
fill 9 197 284 9 199 284 minecraft:red_nether_bricks
setblock 9 197 285 minecraft:orange_terracotta
setblock 9 197 286 minecraft:red_nether_bricks
setblock 9 197 287 minecraft:nether_wart_block
setblock 10 197 283 minecraft:red_nether_bricks
fill 10 197 286 11 198 286 minecraft:orange_terracotta
fill 10 197 287 11 197 287 minecraft:red_nether_bricks
setblock 11 197 278 minecraft:light[level=12]
fill 11 197 282 11 199 282 minecraft:red_nether_bricks
setblock 11 197 294 minecraft:light[level=12]
setblock 11 197 302 minecraft:light[level=12]
setblock 11 197 310 minecraft:light[level=12]
setblock 12 197 282 minecraft:nether_wart_block
fill 12 197 283 12 199 283 minecraft:red_nether_bricks
setblock 12 197 286 minecraft:nether_wart_block
fill 13 197 282 15 197 282 minecraft:red_nether_bricks
setblock 13 197 283 minecraft:nether_wart_block
fill 13 197 284 13 199 284 minecraft:red_nether_bricks
setblock 13 197 286 minecraft:red_nether_bricks
fill 14 197 276 16 200 277 minecraft:amethyst_block
setblock 14 197 280 minecraft:nether_wart_block
fill 14 197 281 14 198 281 minecraft:red_nether_bricks
setblock 14 197 283 minecraft:red_nether_bricks
setblock 14 197 284 minecraft:nether_wart_block
fill 14 197 285 14 198 285 minecraft:red_nether_bricks
setblock 15 197 280 minecraft:red_nether_bricks
setblock 15 197 281 minecraft:nether_wart_block
fill 16 197 283 16 198 283 minecraft:red_nether_bricks
setblock 17 197 280 minecraft:red_nether_bricks
setblock 17 197 283 minecraft:nether_wart_block
setblock 18 197 281 minecraft:red_nether_bricks
setblock 19 197 278 minecraft:light[level=12]
setblock 19 197 286 minecraft:light[level=12]
setblock 19 197 294 minecraft:light[level=12]
setblock 19 197 302 minecraft:light[level=12]
setblock 19 197 310 minecraft:light[level=12]
fill 21 197 317 21 215 317 minecraft:blackstone
setblock 27 197 278 minecraft:light[level=12]
setblock 27 197 286 minecraft:light[level=12]
setblock 27 197 294 minecraft:light[level=12]
setblock 27 197 302 minecraft:light[level=12]
setblock 27 197 310 minecraft:light[level=12]
fill 31 197 275 31 214 275 minecraft:blackstone
setblock 35 197 278 minecraft:light[level=12]
setblock 35 197 286 minecraft:light[level=12]
setblock 35 197 294 minecraft:light[level=12]
setblock 35 197 302 minecraft:light[level=12]
setblock 35 197 310 minecraft:light[level=12]
fill 42 197 284 42 219 284 minecraft:blackstone
fill 0 198 289 0 206 290 minecraft:blackstone
setblock 0 198 291 minecraft:crying_obsidian
fill 0 198 292 0 203 292 minecraft:blackstone
fill 0 198 294 0 219 294 minecraft:blackstone
setblock 3 198 285 minecraft:light[level=12]
setblock 3 198 292 minecraft:light[level=12]
setblock 3 198 299 minecraft:light[level=12]
setblock 3 198 306 minecraft:light[level=12]
setblock 3 198 313 minecraft:light[level=12]
setblock 8 198 285 minecraft:nether_wart_block
fill 8 198 286 8 198 289 minecraft:orange_terracotta
fill 9 198 283 9 199 283 minecraft:red_nether_bricks
setblock 9 198 285 minecraft:red_nether_bricks
fill 9 198 286 9 199 288 minecraft:orange_terracotta
setblock 10 198 278 minecraft:light[level=12]
setblock 10 198 283 minecraft:nether_wart_block
fill 10 198 284 10 200 284 minecraft:red_nether_bricks
fill 10 198 285 11 198 285 minecraft:orange_terracotta
setblock 10 198 287 minecraft:orange_terracotta
fill 10 198 288 10 200 288 minecraft:red_nether_bricks
setblock 10 198 292 minecraft:light[level=12]
setblock 10 198 299 minecraft:light[level=12]
setblock 10 198 306 minecraft:light[level=12]
setblock 10 198 313 minecraft:light[level=12]
setblock 11 198 284 minecraft:nether_wart_block
fill 11 198 287 12 198 287 minecraft:red_nether_bricks
setblock 12 198 281 minecraft:nether_wart_block
fill 12 198 282 12 199 282 minecraft:red_nether_bricks
setblock 12 198 284 minecraft:red_nether_bricks
setblock 12 198 285 minecraft:nether_wart_block
fill 12 198 286 12 200 286 minecraft:red_nether_bricks
fill 13 198 276 13 199 276 minecraft:amethyst_block
setblock 13 198 281 minecraft:red_nether_bricks
setblock 13 198 282 minecraft:nether_wart_block
fill 13 198 283 13 199 283 minecraft:red_nether_bricks
setblock 13 198 286 minecraft:nether_wart_block
fill 14 198 278 16 200 278 minecraft:amethyst_block
fill 14 198 282 15 198 282 minecraft:red_nether_bricks
setblock 14 198 283 minecraft:nether_wart_block
fill 14 198 284 14 199 284 minecraft:red_nether_bricks
setblock 15 198 281 minecraft:red_nether_bricks
setblock 15 198 284 minecraft:nether_wart_block
fill 17 198 276 17 199 276 minecraft:amethyst_block
setblock 17 198 278 minecraft:light[level=12]
setblock 17 198 285 minecraft:light[level=12]
setblock 17 198 292 minecraft:light[level=12]
setblock 17 198 299 minecraft:light[level=12]
setblock 17 198 306 minecraft:light[level=12]
setblock 17 198 313 minecraft:light[level=12]
setblock 24 198 278 minecraft:light[level=12]
setblock 24 198 285 minecraft:light[level=12]
setblock 24 198 292 minecraft:light[level=12]
setblock 24 198 299 minecraft:light[level=12]
setblock 24 198 306 minecraft:light[level=12]
setblock 24 198 313 minecraft:light[level=12]
setblock 31 198 278 minecraft:light[level=12]
setblock 31 198 285 minecraft:light[level=12]
setblock 31 198 292 minecraft:light[level=12]
setblock 31 198 299 minecraft:light[level=12]
setblock 31 198 306 minecraft:light[level=12]
setblock 31 198 313 minecraft:light[level=12]
setblock 38 198 278 minecraft:light[level=12]
setblock 38 198 285 minecraft:light[level=12]
setblock 38 198 292 minecraft:light[level=12]
setblock 38 198 299 minecraft:light[level=12]
setblock 38 198 306 minecraft:light[level=12]
setblock 38 198 313 minecraft:light[level=12]
fill 0 199 291 0 219 291 minecraft:blackstone
fill 6 199 288 6 200 288 minecraft:red_nether_bricks
fill 7 199 286 8 199 286 minecraft:red_nether_bricks
setblock 7 199 287 minecraft:nether_wart_block
fill 7 199 288 8 199 288 minecraft:orange_terracotta
setblock 7 199 289 minecraft:red_nether_bricks
fill 7 199 290 7 201 290 minecraft:orange_terracotta
setblock 8 199 284 minecraft:nether_wart_block
fill 8 199 285 8 201 285 minecraft:red_nether_bricks
setblock 8 199 287 minecraft:orange_terracotta
fill 8 199 289 9 199 289 minecraft:orange_terracotta
setblock 8 199 290 minecraft:red_nether_bricks
setblock 9 199 285 minecraft:nether_wart_block
fill 10 199 283 10 200 283 minecraft:red_nether_bricks
fill 10 199 285 10 202 285 minecraft:bone_block
setblock 10 199 286 minecraft:nether_wart_block
fill 10 199 287 10 201 287 minecraft:red_nether_bricks
setblock 10 199 289 minecraft:red_nether_bricks
setblock 11 199 283 minecraft:nether_wart_block
fill 11 199 284 11 199 286 minecraft:red_nether_bricks
setblock 11 199 287 minecraft:nether_wart_block
fill 11 199 288 11 200 288 minecraft:red_nether_bricks
setblock 12 199 284 minecraft:nether_wart_block
fill 12 199 285 12 200 285 minecraft:red_nether_bricks
setblock 12 199 287 minecraft:red_nether_bricks
setblock 13 199 282 minecraft:red_nether_bricks
setblock 13 199 285 minecraft:nether_wart_block
setblock 13 199 286 minecraft:red_nether_bricks
setblock 14 199 282 minecraft:nether_wart_block
setblock 14 199 283 minecraft:red_nether_bricks
fill 15 199 279 15 201 279 minecraft:amethyst_block
setblock 22 199 317 minecraft:purple_concrete
fill 36 199 312 36 202 312 minecraft:blackstone
fill 37 199 311 37 202 311 minecraft:blackstone
fill 37 199 313 37 202 313 minecraft:blackstone
fill 38 199 312 38 202 312 minecraft:blackstone
setblock 42 199 290 minecraft:crying_obsidian
fill 6 200 287 7 201 287 minecraft:red_nether_bricks
setblock 6 200 289 minecraft:nether_wart_block
fill 6 200 290 6 201 292 minecraft:orange_terracotta
setblock 7 200 286 minecraft:nether_wart_block
fill 7 200 288 7 201 288 minecraft:red_nether_bricks
fill 7 200 289 8 200 289 minecraft:orange_terracotta
fill 7 200 291 7 201 292 minecraft:orange_terracotta
fill 8 200 286 10 200 286 minecraft:red_nether_bricks
setblock 8 200 287 minecraft:nether_wart_block
fill 8 200 288 9 200 288 minecraft:orange_terracotta
fill 8 200 290 8 201 291 minecraft:orange_terracotta
setblock 9 200 284 minecraft:nether_wart_block
fill 9 200 285 9 201 285 minecraft:red_nether_bricks
setblock 9 200 287 minecraft:red_nether_bricks
fill 9 200 289 9 201 290 minecraft:red_nether_bricks
setblock 10 200 289 minecraft:nether_wart_block
fill 11 200 283 11 200 285 minecraft:red_nether_bricks
setblock 11 200 286 minecraft:nether_wart_block
fill 11 200 287 11 201 287 minecraft:red_nether_bricks
setblock 12 200 283 minecraft:nether_wart_block
setblock 12 200 284 minecraft:red_nether_bricks
setblock 13 200 284 minecraft:nether_wart_block
setblock 14 200 279 minecraft:amethyst_block
fill 15 200 280 15 201 280 minecraft:amethyst_block
setblock 16 200 279 minecraft:amethyst_block
fill 22 200 317 22 203 317 minecraft:blackstone
fill 42 200 290 42 221 290 minecraft:blackstone
fill 42 200 300 42 219 300 minecraft:blackstone
setblock 42 200 301 minecraft:amethyst_block
fill 5 201 289 5 201 290 minecraft:red_nether_bricks
setblock 5 201 291 minecraft:nether_wart_block
fill 5 201 292 5 201 293 minecraft:red_nether_bricks
setblock 6 201 288 minecraft:nether_wart_block
fill 6 201 289 6 203 289 minecraft:red_nether_bricks
fill 6 201 293 6 203 294 minecraft:orange_terracotta
setblock 7 201 286 minecraft:red_nether_bricks
setblock 7 201 289 minecraft:orange_terracotta
setblock 7 201 293 minecraft:nether_wart_block
setblock 8 201 275 minecraft:amethyst_block
setblock 8 201 286 minecraft:nether_wart_block
fill 8 201 287 8 201 289 minecraft:red_nether_bricks
fill 8 201 292 8 202 292 minecraft:red_nether_bricks
fill 9 201 286 11 201 286 minecraft:red_nether_bricks
setblock 9 201 287 minecraft:nether_wart_block
fill 9 201 288 9 203 288 minecraft:red_nether_bricks
setblock 9 201 291 minecraft:nether_wart_block
setblock 10 201 284 minecraft:nether_wart_block
setblock 10 201 288 minecraft:nether_wart_block
fill 10 201 289 10 202 289 minecraft:red_nether_bricks
setblock 11 201 285 minecraft:nether_wart_block
fill 36 201 311 36 202 311 minecraft:blackstone
fill 36 201 313 36 202 313 minecraft:blackstone
fill 38 201 311 38 202 311 minecraft:blackstone
fill 38 201 313 38 202 313 minecraft:blackstone
fill 42 201 301 42 219 301 minecraft:blackstone
fill 4 202 291 5 202 292 minecraft:red_nether_bricks
setblock 4 202 293 minecraft:nether_wart_block
fill 4 202 294 4 204 294 minecraft:red_nether_bricks
setblock 5 202 289 minecraft:red_nether_bricks
setblock 5 202 290 minecraft:nether_wart_block
fill 5 202 293 5 202 295 minecraft:orange_terracotta
setblock 6 202 287 minecraft:nether_wart_block
fill 6 202 288 6 203 288 minecraft:red_nether_bricks
fill 6 202 290 8 202 290 minecraft:red_nether_bricks
fill 6 202 291 7 202 291 minecraft:orange_terracotta
fill 6 202 292 6 204 292 minecraft:red_nether_bricks
fill 6 202 295 7 203 295 minecraft:orange_terracotta
setblock 6 202 296 minecraft:red_nether_bricks
fill 7 202 287 9 202 287 minecraft:red_nether_bricks
setblock 7 202 288 minecraft:nether_wart_block
fill 7 202 289 7 204 289 minecraft:red_nether_bricks
setblock 7 202 292 minecraft:nether_wart_block
fill 7 202 293 7 202 294 minecraft:orange_terracotta
fill 8 202 275 8 219 275 minecraft:blackstone
setblock 8 202 286 minecraft:red_nether_bricks
setblock 8 202 288 minecraft:red_nether_bricks
setblock 8 202 289 minecraft:nether_wart_block
fill 8 202 291 9 203 291 minecraft:red_nether_bricks
setblock 8 202 293 minecraft:nether_wart_block
fill 8 202 294 8 204 294 minecraft:red_nether_bricks
setblock 9 202 286 minecraft:nether_wart_block
setblock 9 202 289 minecraft:red_nether_bricks
setblock 9 202 290 minecraft:nether_wart_block
setblock 9 202 292 minecraft:red_nether_bricks
setblock 10 202 286 minecraft:red_nether_bricks
setblock 10 202 287 minecraft:nether_wart_block
setblock 10 202 288 minecraft:red_nether_bricks
setblock 14 202 317 minecraft:magma_block
fill 15 202 317 17 212 317 minecraft:blackstone
setblock 35 202 317 minecraft:crying_obsidian
fill 39 202 307 39 211 307 minecraft:blackstone
fill 40 202 308 41 204 308 minecraft:amethyst_block
fill 40 202 310 41 205 310 minecraft:amethyst_block
fill 41 202 309 42 205 309 minecraft:amethyst_block
fill 0 203 286 0 205 287 minecraft:amethyst_block
fill 1 203 287 2 205 288 minecraft:amethyst_block
fill 1 203 292 1 206 292 minecraft:amethyst_block
setblock 3 203 275 minecraft:crying_obsidian
fill 4 203 291 5 203 291 minecraft:red_nether_bricks
setblock 4 203 292 minecraft:nether_wart_block
fill 4 203 293 4 205 293 minecraft:red_nether_bricks
setblock 4 203 295 minecraft:red_nether_bricks
setblock 4 203 296 minecraft:nether_wart_block
setblock 5 203 289 minecraft:nether_wart_block
fill 5 203 290 5 204 290 minecraft:red_nether_bricks
setblock 5 203 292 minecraft:red_nether_bricks
setblock 5 203 293 minecraft:nether_wart_block
fill 5 203 294 5 203 295 minecraft:orange_terracotta
setblock 5 203 296 minecraft:red_nether_bricks
fill 5 203 297 7 204 297 minecraft:orange_terracotta
setblock 6 203 290 minecraft:nether_wart_block
fill 6 203 291 7 205 291 minecraft:bone_block
fill 6 203 296 6 204 296 minecraft:orange_terracotta
fill 6 203 298 6 205 298 minecraft:orange_terracotta
setblock 7 203 288 minecraft:red_nether_bricks
fill 7 203 290 9 203 290 minecraft:red_nether_bricks
fill 7 203 292 7 204 293 minecraft:red_nether_bricks
setblock 7 203 294 minecraft:orange_terracotta
fill 7 203 296 7 205 296 minecraft:red_nether_bricks
setblock 8 203 288 minecraft:nether_wart_block
setblock 8 203 289 minecraft:red_nether_bricks
setblock 8 203 292 minecraft:nether_wart_block
fill 8 203 293 8 205 293 minecraft:red_nether_bricks
setblock 8 203 295 minecraft:red_nether_bricks
setblock 9 203 289 minecraft:nether_wart_block
fill 14 203 317 14 219 317 minecraft:blackstone
fill 35 203 317 35 219 317 minecraft:blackstone
fill 40 203 309 40 204 309 minecraft:amethyst_block
fill 41 203 307 41 204 307 minecraft:amethyst_block
fill 41 203 311 41 204 311 minecraft:amethyst_block
fill 42 203 308 42 204 308 minecraft:amethyst_block
fill 42 203 310 42 204 310 minecraft:amethyst_block
fill 0 204 288 0 206 288 minecraft:amethyst_block
fill 0 204 292 0 204 293 minecraft:amethyst_block
setblock 0 204 300 minecraft:magma_block
fill 1 204 285 1 205 286 minecraft:amethyst_block
fill 1 204 291 2 205 291 minecraft:amethyst_block
fill 1 204 293 1 205 293 minecraft:amethyst_block
fill 2 204 286 2 206 286 minecraft:amethyst_block
fill 2 204 292 2 205 292 minecraft:amethyst_block
fill 3 204 275 3 215 275 minecraft:blackstone
setblock 3 204 278 minecraft:light[level=12]
fill 3 204 285 3 204 286 minecraft:light[level=12]
setblock 3 204 292 minecraft:light[level=12]
setblock 3 204 294 minecraft:light[level=12]
setblock 3 204 299 minecraft:light[level=12]
setblock 3 204 302 minecraft:light[level=12]
setblock 3 204 306 minecraft:light[level=12]
setblock 3 204 310 minecraft:light[level=12]
setblock 3 204 313 minecraft:light[level=12]
setblock 4 204 292 minecraft:red_nether_bricks
setblock 4 204 295 minecraft:nether_wart_block
fill 4 204 296 4 204 298 minecraft:red_nether_bricks
setblock 5 204 291 minecraft:red_nether_bricks
setblock 5 204 292 minecraft:nether_wart_block
fill 5 204 293 5 204 295 minecraft:red_nether_bricks
setblock 5 204 296 minecraft:orange_terracotta
fill 5 204 298 5 204 299 minecraft:orange_terracotta
setblock 6 204 290 minecraft:red_nether_bricks
setblock 6 204 293 minecraft:nether_wart_block
fill 6 204 294 6 205 295 minecraft:red_nether_bricks
fill 6 204 299 7 204 299 minecraft:orange_terracotta
setblock 6 204 300 minecraft:red_nether_bricks
setblock 7 204 290 minecraft:nether_wart_block
setblock 7 204 294 minecraft:nether_wart_block
fill 7 204 295 7 206 295 minecraft:red_nether_bricks
fill 7 204 298 7 205 298 minecraft:orange_terracotta
setblock 8 204 290 minecraft:red_nether_bricks
setblock 8 204 291 minecraft:nether_wart_block
setblock 8 204 292 minecraft:red_nether_bricks
setblock 8 204 295 minecraft:nether_wart_block
fill 8 204 296 8 205 297 minecraft:red_nether_bricks
fill 10 204 278 11 204 278 minecraft:light[level=12]
setblock 10 204 285 minecraft:light[level=12]
setblock 10 204 292 minecraft:light[level=12]
setblock 10 204 299 minecraft:light[level=12]
setblock 10 204 306 minecraft:light[level=12]
setblock 10 204 313 minecraft:light[level=12]
setblock 11 204 286 minecraft:light[level=12]
setblock 11 204 294 minecraft:light[level=12]
setblock 11 204 302 minecraft:light[level=12]
setblock 11 204 310 minecraft:light[level=12]
setblock 17 204 278 minecraft:light[level=12]
setblock 17 204 285 minecraft:light[level=12]
setblock 17 204 292 minecraft:light[level=12]
setblock 17 204 299 minecraft:light[level=12]
setblock 17 204 306 minecraft:light[level=12]
setblock 17 204 313 minecraft:light[level=12]
setblock 19 204 278 minecraft:light[level=12]
setblock 19 204 286 minecraft:light[level=12]
setblock 19 204 294 minecraft:light[level=12]
setblock 19 204 302 minecraft:light[level=12]
setblock 19 204 310 minecraft:light[level=12]
setblock 22 204 317 minecraft:crying_obsidian
setblock 24 204 278 minecraft:light[level=12]
setblock 24 204 285 minecraft:light[level=12]
setblock 24 204 292 minecraft:light[level=12]
setblock 24 204 299 minecraft:light[level=12]
setblock 24 204 306 minecraft:light[level=12]
setblock 24 204 313 minecraft:light[level=12]
setblock 27 204 278 minecraft:light[level=12]
setblock 27 204 286 minecraft:light[level=12]
setblock 27 204 294 minecraft:light[level=12]
setblock 27 204 302 minecraft:light[level=12]
setblock 27 204 310 minecraft:light[level=12]
setblock 31 204 278 minecraft:light[level=12]
setblock 31 204 285 minecraft:light[level=12]
setblock 31 204 292 minecraft:light[level=12]
setblock 31 204 299 minecraft:light[level=12]
setblock 31 204 306 minecraft:light[level=12]
setblock 31 204 313 minecraft:light[level=12]
setblock 33 204 317 minecraft:crying_obsidian
setblock 35 204 278 minecraft:light[level=12]
setblock 35 204 286 minecraft:light[level=12]
setblock 35 204 294 minecraft:light[level=12]
setblock 35 204 302 minecraft:light[level=12]
setblock 35 204 310 minecraft:light[level=12]
setblock 38 204 278 minecraft:light[level=12]
setblock 38 204 285 minecraft:light[level=12]
schedule function dropper:buildpart/60_4 1t
