fill 230 179 396 230 182 396 minecraft:moss_block
setblock 230 179 397 minecraft:lime_terracotta
fill 230 179 400 230 179 401 minecraft:lime_terracotta
fill 188 180 373 188 180 374 minecraft:lime_terracotta
fill 188 180 375 188 185 376 minecraft:moss_block
fill 188 180 382 188 181 382 minecraft:lime_terracotta
fill 188 180 383 188 185 384 minecraft:moss_block
setblock 188 180 385 minecraft:lime_terracotta
fill 188 180 387 188 185 387 minecraft:moss_block
fill 188 180 393 188 181 394 minecraft:lime_terracotta
fill 188 180 395 188 185 396 minecraft:moss_block
fill 188 180 404 188 185 404 minecraft:moss_block
fill 188 180 405 188 180 406 minecraft:lime_terracotta
fill 188 180 407 188 185 408 minecraft:moss_block
fill 189 180 369 189 185 369 minecraft:moss_block
fill 189 180 370 191 180 370 minecraft:mud
fill 189 180 372 189 180 374 minecraft:mud
fill 189 180 376 189 180 378 minecraft:mud
fill 189 180 380 189 180 382 minecraft:mud
fill 189 180 384 189 180 386 minecraft:mud
fill 189 180 388 189 180 390 minecraft:mud
fill 189 180 392 189 180 394 minecraft:mud
fill 189 180 396 189 180 398 minecraft:mud
fill 189 180 400 189 180 402 minecraft:mud
fill 189 180 404 189 180 406 minecraft:mud
fill 189 180 408 189 180 410 minecraft:mud
fill 190 180 411 191 181 411 minecraft:lime_terracotta
fill 191 180 410 193 180 410 minecraft:mud
fill 192 180 411 193 185 411 minecraft:moss_block
fill 193 180 370 195 180 370 minecraft:mud
setblock 194 180 411 minecraft:lime_terracotta
fill 195 180 410 197 180 410 minecraft:mud
fill 197 180 369 198 185 369 minecraft:moss_block
fill 197 180 370 199 180 370 minecraft:mud
fill 199 180 369 200 181 369 minecraft:lime_terracotta
fill 199 180 410 201 180 410 minecraft:mud
fill 201 180 370 203 180 370 minecraft:mud
fill 202 180 411 203 181 411 minecraft:lime_terracotta
fill 203 180 410 205 180 410 minecraft:mud
fill 204 180 411 205 185 411 minecraft:moss_block
fill 205 180 370 207 180 370 minecraft:mud
fill 206 180 369 206 185 369 minecraft:moss_block
fill 207 180 369 208 180 369 minecraft:lime_terracotta
fill 207 180 410 209 180 410 minecraft:mud
fill 209 180 369 210 181 369 minecraft:moss_block
fill 209 180 370 211 180 370 minecraft:mud
fill 211 180 369 211 181 369 minecraft:lime_terracotta
fill 211 180 410 213 180 410 minecraft:mud
fill 211 180 411 211 181 411 minecraft:lime_terracotta
fill 213 180 370 215 180 370 minecraft:mud
fill 213 180 411 213 185 411 minecraft:moss_block
fill 214 180 411 215 180 411 minecraft:lime_terracotta
fill 215 180 410 217 180 410 minecraft:mud
fill 216 180 411 216 185 411 minecraft:moss_block
fill 217 180 369 218 185 369 minecraft:moss_block
fill 217 180 370 219 180 370 minecraft:mud
fill 219 180 369 220 181 369 minecraft:lime_terracotta
fill 219 180 410 221 180 410 minecraft:mud
fill 221 180 370 223 180 370 minecraft:mud
fill 222 180 411 223 181 411 minecraft:lime_terracotta
fill 223 180 410 225 180 410 minecraft:mud
fill 224 180 411 225 185 411 minecraft:moss_block
fill 225 180 370 227 180 370 minecraft:mud
fill 227 180 410 229 180 410 minecraft:mud
setblock 228 180 369 minecraft:lime_terracotta
fill 229 180 369 230 185 369 minecraft:moss_block
fill 229 180 370 229 180 372 minecraft:mud
fill 229 180 374 229 180 376 minecraft:mud
fill 229 180 378 229 180 380 minecraft:mud
fill 229 180 382 229 180 384 minecraft:mud
fill 229 180 386 229 180 388 minecraft:mud
fill 229 180 390 229 180 392 minecraft:mud
fill 229 180 394 229 180 396 minecraft:mud
fill 229 180 398 229 180 400 minecraft:mud
fill 229 180 402 229 180 404 minecraft:mud
fill 229 180 406 229 180 408 minecraft:mud
fill 230 180 370 230 181 371 minecraft:lime_terracotta
fill 230 180 376 230 185 377 minecraft:moss_block
fill 230 180 378 230 180 379 minecraft:lime_terracotta
fill 230 180 380 230 185 380 minecraft:moss_block
fill 230 180 388 230 185 389 minecraft:moss_block
fill 230 180 390 230 181 391 minecraft:lime_terracotta
fill 230 180 397 230 185 397 minecraft:moss_block
setblock 230 180 399 minecraft:lime_terracotta
fill 230 180 400 230 185 401 minecraft:moss_block
fill 230 180 402 230 181 402 minecraft:lime_terracotta
fill 230 180 408 230 185 409 minecraft:moss_block
setblock 230 180 410 minecraft:lime_terracotta
setblock 188 181 370 minecraft:lime_terracotta
setblock 188 181 373 minecraft:lime_terracotta
fill 188 181 374 188 184 374 minecraft:moss_block
setblock 188 181 381 minecraft:lime_terracotta
fill 188 181 385 188 184 385 minecraft:moss_block
fill 188 181 401 188 181 402 minecraft:lime_terracotta
setblock 188 181 405 minecraft:lime_terracotta
fill 188 181 406 188 184 406 minecraft:moss_block
fill 191 181 369 192 181 369 minecraft:lime_terracotta
fill 194 181 411 194 184 411 minecraft:moss_block
setblock 199 181 411 minecraft:lime_terracotta
fill 207 181 369 208 183 369 minecraft:moss_block
setblock 210 181 411 minecraft:lime_terracotta
setblock 212 181 369 minecraft:lime_terracotta
fill 214 181 411 215 184 411 minecraft:moss_block
setblock 223 181 369 minecraft:lime_terracotta
fill 228 181 369 228 183 369 minecraft:moss_block
fill 230 181 378 230 184 378 minecraft:moss_block
setblock 230 181 379 minecraft:lime_terracotta
fill 230 181 382 230 181 383 minecraft:lime_terracotta
fill 230 181 399 230 184 399 minecraft:moss_block
setblock 230 181 403 minecraft:lime_terracotta
fill 230 181 410 230 184 410 minecraft:moss_block
fill 188 182 370 188 187 370 minecraft:moss_block
fill 188 182 371 188 182 372 minecraft:lime_terracotta
fill 188 182 373 188 187 373 minecraft:moss_block
fill 188 182 379 188 183 380 minecraft:lime_terracotta
fill 188 182 381 188 187 382 minecraft:moss_block
fill 188 182 391 188 182 392 minecraft:lime_terracotta
fill 188 182 393 188 187 394 minecraft:moss_block
fill 188 182 400 188 183 400 minecraft:lime_terracotta
fill 188 182 401 188 187 402 minecraft:moss_block
setblock 188 182 403 minecraft:lime_terracotta
fill 188 182 405 188 187 405 minecraft:moss_block
fill 188 182 411 189 183 411 minecraft:lime_terracotta
setblock 190 182 369 minecraft:lime_terracotta
fill 190 182 411 191 187 411 minecraft:moss_block
fill 191 182 369 192 187 369 minecraft:moss_block
fill 193 182 369 193 183 369 minecraft:lime_terracotta
fill 199 182 369 200 187 369 minecraft:moss_block
fill 199 182 411 199 187 411 minecraft:moss_block
fill 200 182 411 201 182 411 minecraft:lime_terracotta
fill 201 182 369 202 183 369 minecraft:lime_terracotta
fill 202 182 411 203 187 411 minecraft:moss_block
fill 208 182 411 209 183 411 minecraft:lime_terracotta
fill 209 182 369 209 185 369 minecraft:moss_block
setblock 210 182 369 minecraft:lime_terracotta
fill 210 182 411 211 187 411 minecraft:moss_block
fill 211 182 369 212 187 369 minecraft:moss_block
setblock 212 182 411 minecraft:lime_terracotta
fill 213 182 369 214 183 369 minecraft:lime_terracotta
fill 219 182 369 220 184 369 minecraft:moss_block
fill 220 182 411 221 183 411 minecraft:lime_terracotta
fill 221 182 369 222 182 369 minecraft:lime_terracotta
fill 222 182 411 223 187 411 minecraft:moss_block
fill 223 182 369 223 187 369 minecraft:moss_block
fill 225 182 369 225 183 369 minecraft:lime_terracotta
setblock 226 182 369 minecraft:moss_block
fill 229 182 411 229 183 411 minecraft:lime_terracotta
fill 230 182 370 230 187 371 minecraft:moss_block
fill 230 182 372 230 183 373 minecraft:lime_terracotta
fill 230 182 379 230 187 379 minecraft:moss_block
setblock 230 182 381 minecraft:lime_terracotta
fill 230 182 382 230 187 383 minecraft:moss_block
fill 230 182 384 230 183 384 minecraft:lime_terracotta
fill 230 182 390 230 187 391 minecraft:moss_block
fill 230 182 392 230 182 393 minecraft:lime_terracotta
fill 230 182 402 230 187 403 minecraft:moss_block
fill 230 182 404 230 183 405 minecraft:lime_terracotta
fill 188 183 371 188 186 372 minecraft:moss_block
setblock 188 183 388 minecraft:lime_terracotta
setblock 188 183 391 minecraft:lime_terracotta
fill 188 183 392 188 186 392 minecraft:moss_block
setblock 188 183 399 minecraft:lime_terracotta
fill 188 183 403 188 186 403 minecraft:moss_block
fill 190 183 369 190 186 369 minecraft:moss_block
setblock 191 183 372 minecraft:light[level=14]
setblock 191 183 380 minecraft:light[level=14]
setblock 191 183 388 minecraft:light[level=14]
setblock 191 183 396 minecraft:light[level=14]
setblock 191 183 404 minecraft:light[level=14]
setblock 194 183 369 minecraft:lime_terracotta
fill 196 183 411 197 183 411 minecraft:lime_terracotta
setblock 199 183 372 minecraft:light[level=14]
setblock 199 183 388 minecraft:light[level=14]
setblock 199 183 396 minecraft:light[level=14]
setblock 199 183 404 minecraft:light[level=14]
setblock 200 183 411 minecraft:lime_terracotta
fill 201 183 411 201 186 411 minecraft:moss_block
setblock 205 183 369 minecraft:lime_terracotta
setblock 207 183 372 minecraft:light[level=14]
setblock 207 183 380 minecraft:light[level=14]
setblock 207 183 388 minecraft:light[level=14]
setblock 207 183 396 minecraft:light[level=14]
setblock 207 183 404 minecraft:light[level=14]
fill 210 183 369 210 185 369 minecraft:moss_block
fill 212 183 411 212 186 411 minecraft:moss_block
setblock 215 183 372 minecraft:light[level=14]
setblock 215 183 380 minecraft:light[level=14]
setblock 215 183 388 minecraft:light[level=14]
setblock 215 183 396 minecraft:light[level=14]
setblock 215 183 404 minecraft:light[level=14]
setblock 217 183 411 minecraft:lime_terracotta
fill 221 183 369 221 186 369 minecraft:moss_block
setblock 222 183 369 minecraft:lime_terracotta
setblock 223 183 372 minecraft:light[level=14]
setblock 223 183 380 minecraft:light[level=14]
setblock 223 183 388 minecraft:light[level=14]
setblock 223 183 396 minecraft:light[level=14]
setblock 223 183 404 minecraft:light[level=14]
setblock 226 183 369 minecraft:lime_terracotta
setblock 228 183 411 minecraft:lime_terracotta
fill 230 183 381 230 186 381 minecraft:moss_block
setblock 230 183 385 minecraft:lime_terracotta
fill 230 183 392 230 186 392 minecraft:moss_block
setblock 230 183 393 minecraft:lime_terracotta
setblock 230 183 396 minecraft:lime_terracotta
setblock 188 184 369 minecraft:lime_terracotta
fill 188 184 377 188 185 378 minecraft:lime_terracotta
fill 188 184 379 188 189 380 minecraft:moss_block
fill 188 184 386 188 185 386 minecraft:lime_terracotta
fill 188 184 388 188 189 388 minecraft:moss_block
fill 188 184 389 188 184 390 minecraft:lime_terracotta
fill 188 184 391 188 189 391 minecraft:moss_block
fill 188 184 397 188 185 398 minecraft:lime_terracotta
fill 188 184 399 188 189 400 minecraft:moss_block
fill 188 184 409 188 184 410 minecraft:lime_terracotta
fill 188 184 411 189 189 411 minecraft:moss_block
fill 193 184 369 194 189 369 minecraft:moss_block
fill 195 184 369 196 185 369 minecraft:lime_terracotta
fill 195 184 411 195 185 411 minecraft:lime_terracotta
fill 196 184 411 197 189 411 minecraft:moss_block
setblock 198 184 411 minecraft:lime_terracotta
fill 200 184 411 200 189 411 minecraft:moss_block
fill 201 184 369 202 186 369 minecraft:moss_block
fill 203 184 369 204 184 369 minecraft:lime_terracotta
fill 205 184 369 205 189 369 minecraft:moss_block
fill 206 184 411 207 185 411 minecraft:lime_terracotta
fill 207 184 369 207 185 369 minecraft:lime_terracotta
setblock 208 184 369 minecraft:moss_block
fill 208 184 411 209 189 411 minecraft:moss_block
fill 213 184 369 214 189 369 minecraft:moss_block
fill 215 184 369 216 185 369 minecraft:lime_terracotta
fill 217 184 411 217 189 411 minecraft:moss_block
fill 218 184 411 219 184 411 minecraft:lime_terracotta
fill 220 184 411 221 189 411 minecraft:moss_block
fill 222 184 369 222 186 369 minecraft:moss_block
setblock 224 184 369 minecraft:lime_terracotta
fill 225 184 369 226 189 369 minecraft:moss_block
fill 226 184 411 227 185 411 minecraft:lime_terracotta
fill 227 184 369 228 185 369 minecraft:lime_terracotta
fill 228 184 411 229 189 411 minecraft:moss_block
fill 230 184 372 230 189 373 minecraft:moss_block
fill 230 184 374 230 184 375 minecraft:lime_terracotta
fill 230 184 384 230 189 385 minecraft:moss_block
fill 230 184 386 230 185 387 minecraft:lime_terracotta
fill 230 184 393 230 189 393 minecraft:moss_block
fill 230 184 394 230 184 395 minecraft:lime_terracotta
fill 230 184 396 230 189 396 minecraft:moss_block
fill 230 184 398 230 185 398 minecraft:lime_terracotta
fill 230 184 404 230 189 405 minecraft:moss_block
fill 230 184 406 230 185 407 minecraft:lime_terracotta
setblock 230 184 411 minecraft:lime_terracotta
fill 188 185 369 188 188 369 minecraft:moss_block
setblock 188 185 374 minecraft:lime_terracotta
setblock 188 185 385 minecraft:lime_terracotta
fill 188 185 389 188 188 390 minecraft:moss_block
setblock 188 185 406 minecraft:lime_terracotta
setblock 188 185 409 minecraft:lime_terracotta
fill 188 185 410 188 188 410 minecraft:moss_block
setblock 194 185 411 minecraft:lime_terracotta
fill 198 185 411 198 188 411 minecraft:moss_block
fill 203 185 369 203 188 369 minecraft:moss_block
setblock 204 185 369 minecraft:lime_terracotta
setblock 208 185 369 minecraft:lime_terracotta
fill 214 185 411 215 185 411 minecraft:lime_terracotta
setblock 218 185 411 minecraft:lime_terracotta
setblock 219 185 369 minecraft:lime_terracotta
fill 219 185 411 219 188 411 minecraft:moss_block
fill 220 185 369 220 187 369 minecraft:moss_block
fill 224 185 369 224 188 369 minecraft:moss_block
fill 230 185 374 230 188 374 minecraft:moss_block
setblock 230 185 375 minecraft:lime_terracotta
setblock 230 185 378 minecraft:lime_terracotta
fill 230 185 394 230 188 395 minecraft:moss_block
setblock 230 185 399 minecraft:lime_terracotta
setblock 230 185 410 minecraft:lime_terracotta
fill 230 185 411 230 188 411 minecraft:moss_block
fill 188 186 374 188 191 374 minecraft:moss_block
fill 188 186 375 188 186 376 minecraft:lime_terracotta
fill 188 186 377 188 189 378 minecraft:moss_block
fill 188 186 383 188 187 384 minecraft:lime_terracotta
fill 188 186 385 188 190 386 minecraft:moss_block
setblock 188 186 387 minecraft:lime_terracotta
fill 188 186 395 188 187 396 minecraft:lime_terracotta
fill 188 186 397 188 189 398 minecraft:moss_block
fill 188 186 404 188 187 404 minecraft:lime_terracotta
fill 188 186 406 188 191 406 minecraft:moss_block
fill 188 186 407 188 186 408 minecraft:lime_terracotta
fill 188 186 409 188 191 409 minecraft:moss_block
fill 189 186 369 189 187 369 minecraft:lime_terracotta
fill 189 186 370 191 186 370 minecraft:mud
fill 189 186 372 189 186 374 minecraft:mud
fill 189 186 376 189 186 378 minecraft:mud
fill 189 186 380 189 186 382 minecraft:mud
fill 189 186 384 189 186 386 minecraft:mud
fill 189 186 388 189 186 390 minecraft:mud
fill 189 186 392 189 186 394 minecraft:mud
fill 189 186 396 189 186 398 minecraft:mud
fill 189 186 400 189 186 402 minecraft:mud
fill 189 186 404 189 186 406 minecraft:mud
fill 189 186 408 189 186 410 minecraft:mud
fill 191 186 410 193 186 410 minecraft:mud
fill 192 186 411 193 187 411 minecraft:lime_terracotta
fill 193 186 370 195 186 370 minecraft:mud
fill 194 186 411 195 190 411 minecraft:moss_block
fill 195 186 369 196 191 369 minecraft:moss_block
fill 195 186 410 197 186 410 minecraft:mud
fill 197 186 369 198 187 369 minecraft:lime_terracotta
fill 197 186 370 199 186 370 minecraft:mud
fill 199 186 410 201 186 410 minecraft:mud
fill 201 186 370 203 186 370 minecraft:mud
fill 203 186 410 205 186 410 minecraft:mud
fill 204 186 369 204 188 369 minecraft:moss_block
fill 204 186 411 205 186 411 minecraft:lime_terracotta
fill 205 186 370 207 186 370 minecraft:mud
setblock 206 186 369 minecraft:lime_terracotta
fill 206 186 411 207 191 411 minecraft:moss_block
fill 207 186 369 208 191 369 minecraft:moss_block
fill 207 186 410 209 186 410 minecraft:mud
fill 209 186 369 210 187 369 minecraft:lime_terracotta
fill 209 186 370 211 186 370 minecraft:mud
fill 211 186 410 213 186 410 minecraft:mud
fill 213 186 370 215 186 370 minecraft:mud
fill 213 186 411 213 187 411 minecraft:lime_terracotta
fill 214 186 411 215 191 411 minecraft:moss_block
fill 215 186 369 216 189 369 minecraft:moss_block
fill 215 186 410 217 186 410 minecraft:mud
setblock 216 186 411 minecraft:lime_terracotta
fill 217 186 369 218 186 369 minecraft:lime_terracotta
fill 217 186 370 219 186 370 minecraft:mud
fill 218 186 411 218 191 411 minecraft:moss_block
fill 219 186 369 219 187 369 minecraft:moss_block
fill 219 186 410 221 186 410 minecraft:mud
fill 221 186 370 223 186 370 minecraft:mud
fill 223 186 410 225 186 410 minecraft:mud
fill 224 186 411 225 187 411 minecraft:lime_terracotta
fill 225 186 370 227 186 370 minecraft:mud
fill 226 186 411 227 191 411 minecraft:moss_block
fill 227 186 369 228 191 369 minecraft:moss_block
fill 227 186 410 229 186 410 minecraft:mud
fill 229 186 369 230 187 369 minecraft:lime_terracotta
fill 229 186 370 229 186 372 minecraft:mud
fill 229 186 374 229 186 376 minecraft:mud
fill 229 186 378 229 186 380 minecraft:mud
fill 229 186 382 229 186 384 minecraft:mud
fill 229 186 386 229 186 388 minecraft:mud
fill 229 186 390 229 186 392 minecraft:mud
fill 229 186 394 229 186 396 minecraft:mud
fill 229 186 398 229 186 400 minecraft:mud
fill 229 186 402 229 186 404 minecraft:mud
fill 229 186 406 229 186 408 minecraft:mud
fill 230 186 375 230 191 375 minecraft:moss_block
fill 230 186 376 230 186 377 minecraft:lime_terracotta
fill 230 186 378 230 191 378 minecraft:moss_block
fill 230 186 380 230 187 380 minecraft:lime_terracotta
fill 230 186 386 230 189 387 minecraft:moss_block
fill 230 186 388 230 187 389 minecraft:lime_terracotta
setblock 230 186 397 minecraft:lime_terracotta
fill 230 186 398 230 191 399 minecraft:moss_block
fill 230 186 400 230 187 401 minecraft:lime_terracotta
fill 230 186 406 230 189 407 minecraft:moss_block
fill 230 186 408 230 186 409 minecraft:lime_terracotta
fill 230 186 410 230 191 410 minecraft:moss_block
fill 188 187 371 188 187 372 minecraft:lime_terracotta
setblock 188 187 375 minecraft:lime_terracotta
fill 188 187 376 188 189 376 minecraft:moss_block
fill 188 187 387 188 189 387 minecraft:moss_block
setblock 188 187 392 minecraft:lime_terracotta
setblock 188 187 403 minecraft:lime_terracotta
fill 188 187 407 188 189 408 minecraft:moss_block
setblock 190 187 369 minecraft:lime_terracotta
setblock 201 187 369 minecraft:lime_terracotta
setblock 201 187 411 minecraft:lime_terracotta
fill 202 187 369 202 189 369 minecraft:moss_block
setblock 204 187 411 minecraft:lime_terracotta
fill 205 187 411 205 190 411 minecraft:moss_block
fill 206 187 369 206 190 369 minecraft:moss_block
setblock 212 187 411 minecraft:lime_terracotta
fill 216 187 411 216 190 411 minecraft:moss_block
fill 217 187 369 217 190 369 minecraft:moss_block
setblock 218 187 369 minecraft:lime_terracotta
fill 221 187 369 222 187 369 minecraft:lime_terracotta
fill 230 187 376 230 189 377 minecraft:moss_block
setblock 230 187 381 minecraft:lime_terracotta
setblock 230 187 392 minecraft:lime_terracotta
fill 230 187 397 230 190 397 minecraft:moss_block
fill 230 187 408 230 190 408 minecraft:moss_block
setblock 230 187 409 minecraft:lime_terracotta
fill 188 188 370 188 189 370 minecraft:lime_terracotta
fill 188 188 371 188 189 372 minecraft:moss_block
setblock 188 188 373 minecraft:lime_terracotta
fill 188 188 375 188 189 375 minecraft:moss_block
fill 188 188 381 188 189 382 minecraft:lime_terracotta
fill 188 188 383 188 189 384 minecraft:moss_block
fill 188 188 392 188 193 392 minecraft:moss_block
fill 188 188 393 188 188 394 minecraft:lime_terracotta
fill 188 188 395 188 191 396 minecraft:moss_block
fill 188 188 401 188 189 402 minecraft:lime_terracotta
fill 188 188 403 188 189 404 minecraft:moss_block
setblock 188 188 405 minecraft:lime_terracotta
fill 189 188 369 190 190 369 minecraft:moss_block
fill 190 188 411 191 189 411 minecraft:lime_terracotta
fill 191 188 369 192 189 369 minecraft:lime_terracotta
fill 192 188 411 193 190 411 minecraft:moss_block
fill 197 188 369 198 193 369 minecraft:moss_block
fill 199 188 369 200 188 369 minecraft:lime_terracotta
fill 199 188 411 199 189 411 minecraft:lime_terracotta
fill 201 188 369 201 193 369 minecraft:moss_block
fill 201 188 411 201 193 411 minecraft:moss_block
fill 202 188 411 203 188 411 minecraft:lime_terracotta
fill 204 188 411 204 190 411 minecraft:moss_block
fill 209 188 369 210 190 369 minecraft:moss_block
fill 210 188 411 211 189 411 minecraft:lime_terracotta
fill 211 188 369 212 189 369 minecraft:lime_terracotta
fill 212 188 411 213 193 411 minecraft:moss_block
fill 218 188 369 218 193 369 minecraft:moss_block
fill 219 188 369 220 188 369 minecraft:lime_terracotta
fill 221 188 369 222 189 369 minecraft:moss_block
fill 222 188 411 223 188 411 minecraft:lime_terracotta
fill 223 188 369 223 189 369 minecraft:lime_terracotta
fill 224 188 411 225 189 411 minecraft:moss_block
fill 229 188 369 230 193 369 minecraft:moss_block
fill 230 188 370 230 189 371 minecraft:lime_terracotta
setblock 230 188 379 minecraft:lime_terracotta
fill 230 188 380 230 193 381 minecraft:moss_block
fill 230 188 382 230 189 383 minecraft:lime_terracotta
fill 230 188 388 230 191 389 minecraft:moss_block
fill 230 188 390 230 188 391 minecraft:lime_terracotta
fill 230 188 392 230 189 392 minecraft:moss_block
fill 230 188 400 230 190 401 minecraft:moss_block
fill 230 188 402 230 189 403 minecraft:lime_terracotta
fill 230 188 409 230 191 409 minecraft:moss_block
setblock 188 189 369 minecraft:lime_terracotta
fill 188 189 373 188 192 373 minecraft:moss_block
fill 188 189 389 188 189 390 minecraft:lime_terracotta
setblock 188 189 393 minecraft:lime_terracotta
fill 188 189 394 188 192 394 minecraft:moss_block
fill 188 189 405 188 192 405 minecraft:moss_block
setblock 188 189 410 minecraft:lime_terracotta
setblock 198 189 411 minecraft:lime_terracotta
fill 199 189 369 199 192 369 minecraft:moss_block
setblock 200 189 369 minecraft:lime_terracotta
fill 202 189 411 203 191 411 minecraft:moss_block
fill 203 189 369 204 189 369 minecraft:lime_terracotta
fill 219 189 369 220 190 369 minecraft:moss_block
setblock 219 189 411 minecraft:lime_terracotta
setblock 222 189 411 minecraft:lime_terracotta
setblock 223 189 411 minecraft:moss_block
setblock 224 189 369 minecraft:lime_terracotta
setblock 230 189 374 minecraft:lime_terracotta
fill 230 189 379 230 191 379 minecraft:moss_block
fill 230 189 390 230 192 390 minecraft:moss_block
setblock 230 189 391 minecraft:lime_terracotta
fill 230 189 394 230 189 395 minecraft:lime_terracotta
setblock 230 189 411 minecraft:lime_terracotta
fill 188 190 369 188 193 371 minecraft:moss_block
setblock 188 190 372 minecraft:green_terracotta
fill 188 190 375 188 190 377 minecraft:green_terracotta
fill 188 190 378 188 191 378 minecraft:moss_block
fill 188 190 379 188 190 380 minecraft:lime_terracotta
fill 188 190 381 188 193 381 minecraft:moss_block
fill 188 190 382 188 190 383 minecraft:green_terracotta
fill 188 190 384 188 193 384 minecraft:moss_block
setblock 188 190 387 minecraft:green_terracotta
fill 188 190 388 188 191 388 minecraft:lime_terracotta
fill 188 190 389 188 190 390 minecraft:moss_block
setblock 188 190 391 minecraft:lime_terracotta
fill 188 190 393 188 193 393 minecraft:moss_block
fill 188 190 397 188 191 397 minecraft:moss_block
setblock 188 190 398 minecraft:green_terracotta
fill 188 190 399 188 191 400 minecraft:lime_terracotta
fill 188 190 401 188 193 402 minecraft:moss_block
setblock 188 190 403 minecraft:green_terracotta
fill 188 190 404 188 193 404 minecraft:moss_block
setblock 188 190 407 minecraft:moss_block
setblock 188 190 408 minecraft:green_terracotta
fill 188 190 410 188 193 410 minecraft:moss_block
fill 188 190 411 189 190 411 minecraft:lime_terracotta
fill 190 190 411 191 190 411 minecraft:moss_block
fill 191 190 369 192 193 369 minecraft:moss_block
fill 193 190 369 194 191 369 minecraft:lime_terracotta
fill 196 190 411 197 191 411 minecraft:lime_terracotta
fill 198 190 411 199 193 411 minecraft:moss_block
setblock 200 190 369 minecraft:moss_block
setblock 200 190 411 minecraft:lime_terracotta
setblock 202 190 369 minecraft:lime_terracotta
fill 203 190 369 204 193 369 minecraft:moss_block
fill 205 190 369 205 191 369 minecraft:lime_terracotta
fill 208 190 411 209 191 411 minecraft:lime_terracotta
fill 210 190 411 211 191 411 minecraft:moss_block
setblock 211 190 369 minecraft:green_terracotta
fill 212 190 369 212 194 369 minecraft:moss_block
fill 213 190 369 214 191 369 minecraft:lime_terracotta
setblock 215 190 369 minecraft:green_terracotta
fill 216 190 369 216 191 369 minecraft:moss_block
fill 217 190 411 217 191 411 minecraft:lime_terracotta
fill 219 190 395 219 191 397 minecraft:moss_block
fill 219 190 411 219 194 411 minecraft:moss_block
fill 220 190 396 220 191 397 minecraft:moss_block
fill 220 190 411 221 190 411 minecraft:lime_terracotta
fill 221 190 369 221 193 369 minecraft:moss_block
setblock 222 190 369 minecraft:lime_terracotta
fill 222 190 411 222 193 411 minecraft:moss_block
fill 223 190 369 224 193 369 minecraft:moss_block
fill 223 190 411 225 190 411 minecraft:green_terracotta
fill 225 190 369 226 191 369 minecraft:lime_terracotta
fill 228 190 411 229 191 411 minecraft:lime_terracotta
fill 230 190 370 230 191 370 minecraft:green_terracotta
fill 230 190 371 230 194 371 minecraft:moss_block
fill 230 190 372 230 190 373 minecraft:lime_terracotta
fill 230 190 374 230 193 374 minecraft:moss_block
fill 230 190 376 230 191 376 minecraft:lime_terracotta
setblock 230 190 377 minecraft:moss_block
fill 230 190 382 230 191 383 minecraft:moss_block
fill 230 190 384 230 191 385 minecraft:lime_terracotta
setblock 230 190 386 minecraft:green_terracotta
fill 230 190 387 230 191 387 minecraft:moss_block
fill 230 190 391 230 193 391 minecraft:moss_block
setblock 230 190 392 minecraft:green_terracotta
setblock 230 190 393 minecraft:lime_terracotta
fill 230 190 394 230 193 395 minecraft:moss_block
fill 230 190 396 230 191 396 minecraft:lime_terracotta
fill 230 190 402 230 190 403 minecraft:moss_block
fill 230 190 404 230 190 405 minecraft:lime_terracotta
fill 230 190 406 230 191 406 minecraft:moss_block
setblock 230 190 407 minecraft:green_terracotta
fill 230 190 411 230 193 411 minecraft:moss_block
fill 188 191 372 188 193 372 minecraft:moss_block
fill 188 191 375 188 193 375 minecraft:moss_block
setblock 188 191 376 minecraft:lime_terracotta
setblock 188 191 377 minecraft:moss_block
setblock 188 191 379 minecraft:lime_terracotta
fill 188 191 380 188 193 380 minecraft:moss_block
setblock 188 191 382 minecraft:green_terracotta
fill 188 191 383 188 193 383 minecraft:moss_block
setblock 188 191 385 minecraft:moss_block
setblock 188 191 386 minecraft:green_terracotta
setblock 188 191 387 minecraft:lime_terracotta
setblock 188 191 389 minecraft:green_terracotta
fill 188 191 390 188 191 391 minecraft:moss_block
setblock 188 191 398 minecraft:moss_block
fill 188 191 403 188 193 403 minecraft:moss_block
fill 188 191 407 188 191 408 minecraft:lime_terracotta
setblock 188 191 411 minecraft:lime_terracotta
fill 189 191 369 189 192 369 minecraft:green_terracotta
fill 189 191 411 190 191 411 minecraft:green_terracotta
fill 190 191 369 190 193 369 minecraft:moss_block
setblock 191 191 372 minecraft:light[level=14]
setblock 191 191 380 minecraft:light[level=14]
setblock 191 191 388 minecraft:light[level=14]
setblock 191 191 396 minecraft:light[level=14]
setblock 191 191 404 minecraft:light[level=14]
fill 191 191 411 192 191 411 minecraft:moss_block
setblock 193 191 411 minecraft:green_terracotta
setblock 194 191 411 minecraft:moss_block
setblock 195 191 411 minecraft:green_terracotta
setblock 199 191 372 minecraft:light[level=14]
setblock 199 191 388 minecraft:light[level=14]
setblock 199 191 396 minecraft:light[level=14]
setblock 199 191 404 minecraft:light[level=14]
setblock 200 191 369 minecraft:green_terracotta
fill 200 191 411 200 193 411 minecraft:moss_block
fill 202 191 369 202 194 369 minecraft:moss_block
setblock 204 191 411 minecraft:green_terracotta
setblock 205 191 411 minecraft:lime_terracotta
setblock 206 191 369 minecraft:lime_terracotta
setblock 207 191 372 minecraft:light[level=14]
setblock 207 191 380 minecraft:light[level=14]
setblock 207 191 388 minecraft:light[level=14]
setblock 207 191 396 minecraft:light[level=14]
setblock 207 191 404 minecraft:light[level=14]
fill 209 191 369 209 193 369 minecraft:moss_block
fill 210 191 369 210 192 369 minecraft:green_terracotta
fill 211 191 369 211 193 369 minecraft:moss_block
setblock 215 191 369 minecraft:moss_block
setblock 215 191 372 minecraft:light[level=14]
setblock 215 191 380 minecraft:light[level=14]
setblock 215 191 388 minecraft:light[level=14]
setblock 215 191 396 minecraft:light[level=14]
setblock 215 191 404 minecraft:light[level=14]
setblock 216 191 411 minecraft:lime_terracotta
setblock 217 191 369 minecraft:lime_terracotta
setblock 219 191 369 minecraft:green_terracotta
fill 220 191 369 220 192 369 minecraft:moss_block
setblock 220 191 411 minecraft:moss_block
setblock 221 191 411 minecraft:green_terracotta
fill 222 191 369 222 193 369 minecraft:moss_block
setblock 223 191 372 minecraft:light[level=14]
setblock 223 191 380 minecraft:light[level=14]
setblock 223 191 388 minecraft:light[level=14]
setblock 223 191 396 minecraft:light[level=14]
setblock 223 191 404 minecraft:light[level=14]
fill 223 191 411 225 192 411 minecraft:moss_block
fill 230 191 372 230 194 372 minecraft:moss_block
setblock 230 191 373 minecraft:lime_terracotta
setblock 230 191 377 minecraft:lime_terracotta
setblock 230 191 386 minecraft:moss_block
fill 230 191 392 230 193 393 minecraft:moss_block
setblock 230 191 397 minecraft:lime_terracotta
setblock 230 191 400 minecraft:green_terracotta
fill 230 191 401 230 193 402 minecraft:moss_block
setblock 230 191 403 minecraft:green_terracotta
fill 230 191 404 230 193 404 minecraft:moss_block
setblock 230 191 405 minecraft:lime_terracotta
setblock 230 191 407 minecraft:moss_block
setblock 230 191 408 minecraft:lime_terracotta
fill 188 192 374 188 193 374 minecraft:lime_terracotta
fill 188 192 376 188 193 376 minecraft:moss_block
fill 188 192 377 188 192 378 minecraft:lime_terracotta
setblock 188 192 379 minecraft:green_terracotta
fill 188 192 382 188 193 382 minecraft:moss_block
fill 188 192 385 188 193 386 minecraft:lime_terracotta
fill 188 192 387 188 193 390 minecraft:moss_block
setblock 188 192 391 minecraft:green_terracotta
fill 188 192 395 188 193 395 minecraft:moss_block
setblock 188 192 396 minecraft:green_terracotta
fill 188 192 397 188 192 398 minecraft:lime_terracotta
fill 188 192 399 188 193 400 minecraft:moss_block
fill 188 192 406 188 193 406 minecraft:lime_terracotta
fill 188 192 407 188 193 408 minecraft:moss_block
setblock 188 192 409 minecraft:lime_terracotta
fill 188 192 411 191 193 411 minecraft:moss_block
fill 189 192 370 191 192 370 minecraft:mud
fill 189 192 372 189 192 374 minecraft:mud
fill 189 192 376 189 192 378 minecraft:mud
fill 189 192 380 189 192 382 minecraft:mud
fill 189 192 384 189 192 386 minecraft:mud
fill 189 192 388 189 192 390 minecraft:mud
fill 189 192 392 189 192 394 minecraft:mud
fill 189 192 396 189 192 398 minecraft:mud
fill 189 192 400 189 192 402 minecraft:mud
fill 189 192 404 189 192 406 minecraft:mud
fill 189 192 408 189 192 410 minecraft:mud
fill 191 192 410 193 192 410 minecraft:mud
setblock 192 192 411 minecraft:green_terracotta
fill 193 192 369 193 193 369 minecraft:moss_block
fill 193 192 370 195 192 370 minecraft:mud
fill 193 192 411 193 193 411 minecraft:moss_block
setblock 194 192 369 minecraft:green_terracotta
fill 194 192 411 195 193 411 minecraft:lime_terracotta
fill 195 192 369 196 192 369 minecraft:lime_terracotta
fill 195 192 410 197 192 410 minecraft:mud
fill 196 192 411 197 193 411 minecraft:moss_block
fill 197 192 370 199 192 370 minecraft:mud
fill 199 192 410 201 192 410 minecraft:mud
fill 200 192 369 200 193 369 minecraft:moss_block
fill 201 192 370 203 192 370 minecraft:mud
setblock 202 192 411 minecraft:moss_block
fill 203 192 410 205 192 410 minecraft:mud
setblock 203 192 411 minecraft:green_terracotta
fill 204 192 411 205 193 411 minecraft:moss_block
fill 205 192 369 205 193 369 minecraft:moss_block
fill 205 192 370 207 192 370 minecraft:mud
setblock 206 192 369 minecraft:green_terracotta
fill 206 192 411 207 192 411 minecraft:lime_terracotta
fill 207 192 369 208 193 369 minecraft:lime_terracotta
fill 207 192 410 209 192 410 minecraft:mud
fill 208 192 411 209 193 411 minecraft:moss_block
fill 209 192 370 211 192 370 minecraft:mud
setblock 210 192 411 minecraft:green_terracotta
fill 211 192 410 213 192 410 minecraft:mud
fill 211 192 411 211 193 411 minecraft:moss_block
fill 213 192 369 214 193 369 minecraft:moss_block
fill 213 192 370 215 192 370 minecraft:mud
fill 214 192 411 215 193 411 minecraft:lime_terracotta
fill 215 192 369 216 192 369 minecraft:lime_terracotta
fill 215 192 410 217 192 410 minecraft:mud
fill 216 192 411 217 193 411 minecraft:moss_block
fill 217 192 369 217 193 369 minecraft:moss_block
fill 217 192 370 219 192 370 minecraft:mud
setblock 218 192 411 minecraft:lime_terracotta
fill 219 192 369 219 193 369 minecraft:lime_terracotta
fill 219 192 410 221 192 410 minecraft:mud
setblock 220 192 411 minecraft:green_terracotta
fill 221 192 370 223 192 370 minecraft:mud
fill 221 192 411 221 193 411 minecraft:moss_block
fill 223 192 410 225 192 410 minecraft:mud
fill 225 192 369 226 193 369 minecraft:moss_block
fill 225 192 370 227 192 370 minecraft:mud
fill 226 192 411 227 193 411 minecraft:lime_terracotta
fill 227 192 369 228 193 369 minecraft:lime_terracotta
fill 227 192 410 229 192 410 minecraft:mud
fill 228 192 411 229 193 411 minecraft:moss_block
fill 229 192 370 229 192 372 minecraft:mud
fill 229 192 374 229 192 376 minecraft:mud
fill 229 192 378 229 192 380 minecraft:mud
fill 229 192 382 229 192 384 minecraft:mud
fill 229 192 386 229 192 388 minecraft:mud
fill 229 192 390 229 192 392 minecraft:mud
fill 229 192 394 229 192 396 minecraft:mud
fill 229 192 398 229 192 400 minecraft:mud
fill 229 192 402 229 192 404 minecraft:mud
fill 229 192 406 229 192 408 minecraft:mud
setblock 230 192 370 minecraft:moss_block
fill 230 192 373 230 193 373 minecraft:moss_block
setblock 230 192 375 minecraft:lime_terracotta
fill 230 192 376 230 193 377 minecraft:moss_block
fill 230 192 378 230 193 379 minecraft:lime_terracotta
fill 230 192 382 230 193 382 minecraft:moss_block
setblock 230 192 383 minecraft:green_terracotta
fill 230 192 384 230 193 384 minecraft:moss_block
setblock 230 192 385 minecraft:green_terracotta
fill 230 192 386 230 192 387 minecraft:lime_terracotta
setblock 230 192 388 minecraft:green_terracotta
fill 230 192 389 230 193 389 minecraft:moss_block
fill 230 192 396 230 193 396 minecraft:moss_block
setblock 230 192 397 minecraft:green_terracotta
fill 230 192 398 230 193 399 minecraft:lime_terracotta
fill 230 192 400 230 193 400 minecraft:moss_block
fill 230 192 403 230 193 403 minecraft:moss_block
fill 230 192 405 230 193 405 minecraft:moss_block
fill 230 192 406 230 192 407 minecraft:lime_terracotta
fill 230 192 408 230 194 408 minecraft:moss_block
setblock 230 192 409 minecraft:green_terracotta
fill 230 192 410 230 193 410 minecraft:lime_terracotta
setblock 188 193 373 minecraft:lime_terracotta
fill 188 193 377 188 193 379 minecraft:moss_block
setblock 188 193 391 minecraft:moss_block
setblock 188 193 394 minecraft:lime_terracotta
setblock 188 193 396 minecraft:moss_block
setblock 188 193 397 minecraft:lime_terracotta
setblock 188 193 398 minecraft:moss_block
setblock 188 193 405 minecraft:lime_terracotta
setblock 188 193 409 minecraft:moss_block
setblock 189 193 369 minecraft:moss_block
setblock 192 193 411 minecraft:moss_block
fill 194 193 369 195 193 369 minecraft:moss_block
setblock 196 193 369 minecraft:lime_terracotta
setblock 199 193 369 minecraft:lime_terracotta
fill 202 193 411 203 193 411 minecraft:lime_terracotta
setblock 206 193 369 minecraft:moss_block
setblock 206 193 411 minecraft:lime_terracotta
setblock 207 193 411 minecraft:moss_block
setblock 210 193 369 minecraft:moss_block
setblock 210 193 411 minecraft:moss_block
setblock 215 193 369 minecraft:moss_block
setblock 216 193 369 minecraft:lime_terracotta
setblock 218 193 411 minecraft:moss_block
setblock 220 193 369 minecraft:lime_terracotta
setblock 220 193 411 minecraft:moss_block
setblock 223 193 411 minecraft:lime_terracotta
fill 224 193 411 225 193 411 minecraft:moss_block
setblock 230 193 370 minecraft:lime_terracotta
setblock 230 193 375 minecraft:moss_block
setblock 230 193 383 minecraft:moss_block
fill 230 193 385 230 193 386 minecraft:moss_block
setblock 230 193 387 minecraft:lime_terracotta
setblock 230 193 388 minecraft:moss_block
setblock 230 193 390 minecraft:lime_terracotta
setblock 230 193 397 minecraft:moss_block
fill 230 193 406 230 193 407 minecraft:moss_block
setblock 230 193 409 minecraft:moss_block
fill 188 194 369 188 195 370 minecraft:green_terracotta
fill 188 194 371 188 195 372 minecraft:lime_terracotta
setblock 188 194 373 minecraft:moss_block
fill 188 194 374 188 199 374 minecraft:green_terracotta
setblock 188 194 375 minecraft:lime_terracotta
fill 188 194 376 188 194 382 minecraft:green_terracotta
fill 188 194 383 188 195 384 minecraft:lime_terracotta
setblock 188 194 385 minecraft:moss_block
fill 188 194 386 188 195 388 minecraft:green_terracotta
fill 188 194 389 188 195 389 minecraft:moss_block
fill 188 194 390 188 194 391 minecraft:green_terracotta
fill 188 194 392 188 195 392 minecraft:lime_terracotta
fill 188 194 393 188 195 394 minecraft:green_terracotta
fill 188 194 395 188 194 396 minecraft:lime_terracotta
fill 188 194 397 188 196 398 minecraft:green_terracotta
setblock 188 194 399 minecraft:moss_block
fill 188 194 400 188 194 402 minecraft:green_terracotta
fill 188 194 403 188 195 404 minecraft:lime_terracotta
fill 188 194 405 188 197 407 minecraft:green_terracotta
setblock 188 194 408 minecraft:moss_block
fill 188 194 409 188 195 411 minecraft:green_terracotta
fill 189 194 369 190 195 369 minecraft:lime_terracotta
setblock 189 194 411 minecraft:moss_block
fill 190 194 411 191 195 411 minecraft:green_terracotta
fill 191 194 369 196 194 369 minecraft:green_terracotta
fill 192 194 411 193 194 411 minecraft:lime_terracotta
fill 194 194 411 195 194 411 minecraft:moss_block
fill 196 194 411 200 194 411 minecraft:green_terracotta
fill 197 194 369 198 194 369 minecraft:lime_terracotta
fill 199 194 369 200 195 369 minecraft:green_terracotta
fill 201 194 369 201 195 369 minecraft:lime_terracotta
fill 201 194 411 201 195 411 minecraft:lime_terracotta
fill 202 194 411 203 199 411 minecraft:green_terracotta
fill 203 194 369 208 195 369 minecraft:green_terracotta
setblock 204 194 411 minecraft:lime_terracotta
fill 205 194 411 211 194 411 minecraft:green_terracotta
fill 209 194 369 210 195 369 minecraft:lime_terracotta
fill 211 194 369 211 195 369 minecraft:green_terracotta
fill 212 194 411 213 195 411 minecraft:lime_terracotta
fill 213 194 369 217 194 369 minecraft:green_terracotta
setblock 214 194 411 minecraft:moss_block
fill 215 194 411 218 195 411 minecraft:green_terracotta
setblock 218 194 369 minecraft:lime_terracotta
fill 219 194 369 220 199 369 minecraft:green_terracotta
fill 220 194 411 223 194 411 minecraft:green_terracotta
fill 221 194 369 222 195 369 minecraft:lime_terracotta
fill 223 194 369 227 195 369 minecraft:green_terracotta
fill 224 194 411 225 194 411 minecraft:lime_terracotta
setblock 226 194 411 minecraft:moss_block
fill 227 194 411 230 194 411 minecraft:green_terracotta
setblock 228 194 369 minecraft:moss_block
fill 229 194 369 230 194 369 minecraft:lime_terracotta
fill 230 194 370 230 195 370 minecraft:green_terracotta
fill 230 194 373 230 194 379 minecraft:green_terracotta
fill 230 194 380 230 195 381 minecraft:lime_terracotta
fill 230 194 382 230 194 387 minecraft:green_terracotta
fill 230 194 388 230 194 389 minecraft:lime_terracotta
fill 230 194 390 230 195 391 minecraft:green_terracotta
fill 230 194 392 230 195 392 minecraft:lime_terracotta
fill 230 194 393 230 194 399 minecraft:green_terracotta
fill 230 194 400 230 195 401 minecraft:lime_terracotta
setblock 230 194 402 minecraft:moss_block
fill 230 194 403 230 194 407 minecraft:green_terracotta
setblock 230 194 409 minecraft:lime_terracotta
fill 230 194 410 230 199 410 minecraft:green_terracotta
fill 188 195 373 188 199 373 minecraft:green_terracotta
fill 188 195 375 188 196 379 minecraft:green_terracotta
setblock 188 195 380 minecraft:lime_terracotta
fill 188 195 381 188 195 382 minecraft:green_terracotta
fill 188 195 385 188 199 385 minecraft:green_terracotta
setblock 188 195 390 minecraft:green_terracotta
setblock 188 195 391 minecraft:lime_terracotta
fill 188 195 395 188 198 396 minecraft:green_terracotta
fill 188 195 399 188 197 399 minecraft:green_terracotta
setblock 188 195 400 minecraft:moss_block
fill 188 195 401 188 195 402 minecraft:green_terracotta
fill 188 195 408 188 197 408 minecraft:green_terracotta
setblock 189 195 411 minecraft:lime_terracotta
fill 191 195 369 193 195 369 minecraft:green_terracotta
setblock 192 195 411 minecraft:lime_terracotta
fill 193 195 411 199 195 411 minecraft:green_terracotta
fill 194 195 369 194 196 369 minecraft:moss_block
fill 195 195 369 198 196 369 minecraft:green_terracotta
setblock 200 195 411 minecraft:lime_terracotta
setblock 202 195 369 minecraft:lime_terracotta
fill 204 195 411 204 198 411 minecraft:green_terracotta
fill 205 195 411 206 195 411 minecraft:moss_block
fill 207 195 411 211 195 411 minecraft:green_terracotta
setblock 212 195 369 minecraft:green_terracotta
setblock 213 195 369 minecraft:lime_terracotta
fill 214 195 369 218 195 369 minecraft:green_terracotta
fill 214 195 411 214 199 411 minecraft:green_terracotta
setblock 219 195 411 minecraft:green_terracotta
fill 220 195 411 221 195 411 minecraft:lime_terracotta
setblock 222 195 411 minecraft:green_terracotta
setblock 223 195 411 minecraft:moss_block
setblock 224 195 411 minecraft:lime_terracotta
fill 225 195 411 228 197 411 minecraft:green_terracotta
fill 228 195 369 229 195 369 minecraft:green_terracotta
setblock 229 195 411 minecraft:moss_block
setblock 230 195 369 minecraft:lime_terracotta
setblock 230 195 371 minecraft:green_terracotta
fill 230 195 372 230 195 373 minecraft:lime_terracotta
fill 230 195 374 230 195 379 minecraft:green_terracotta
fill 230 195 382 230 195 383 minecraft:green_terracotta
setblock 230 195 384 minecraft:moss_block
fill 230 195 385 230 196 389 minecraft:green_terracotta
setblock 230 195 393 minecraft:lime_terracotta
fill 230 195 394 230 195 395 minecraft:green_terracotta
setblock 230 195 396 minecraft:moss_block
fill 230 195 397 230 195 399 minecraft:green_terracotta
fill 230 195 402 230 195 403 minecraft:green_terracotta
setblock 230 195 404 minecraft:lime_terracotta
fill 230 195 405 230 195 409 minecraft:green_terracotta
setblock 230 195 411 minecraft:green_terracotta
fill 188 196 369 188 197 370 minecraft:lime_terracotta
fill 188 196 371 188 201 372 minecraft:green_terracotta
fill 188 196 380 188 201 380 minecraft:green_terracotta
fill 188 196 381 188 196 382 minecraft:lime_terracotta
fill 188 196 383 188 201 384 minecraft:green_terracotta
fill 188 196 386 188 197 387 minecraft:green_terracotta
setblock 188 196 388 minecraft:moss_block
fill 188 196 389 188 197 390 minecraft:lime_terracotta
fill 188 196 391 188 201 392 minecraft:green_terracotta
setblock 188 196 393 minecraft:lime_terracotta
fill 188 196 394 188 199 394 minecraft:green_terracotta
fill 188 196 400 188 197 400 minecraft:green_terracotta
fill 188 196 401 188 197 402 minecraft:lime_terracotta
fill 188 196 403 188 201 404 minecraft:green_terracotta
setblock 188 196 409 minecraft:green_terracotta
fill 188 196 410 188 197 410 minecraft:lime_terracotta
setblock 188 196 411 minecraft:moss_block
fill 189 196 369 190 196 369 minecraft:moss_block
fill 189 196 411 189 201 411 minecraft:green_terracotta
fill 190 196 411 191 196 411 minecraft:lime_terracotta
fill 191 196 369 192 197 369 minecraft:lime_terracotta
fill 192 196 411 193 198 411 minecraft:green_terracotta
fill 193 196 369 193 197 369 minecraft:green_terracotta
setblock 194 196 411 minecraft:moss_block
fill 195 196 411 197 197 411 minecraft:green_terracotta
fill 198 196 411 199 197 411 minecraft:lime_terracotta
fill 199 196 369 199 199 369 minecraft:green_terracotta
setblock 200 196 369 minecraft:lime_terracotta
fill 200 196 411 201 201 411 minecraft:green_terracotta
fill 201 196 369 202 201 369 minecraft:green_terracotta
fill 203 196 369 204 197 369 minecraft:lime_terracotta
fill 205 196 369 210 197 369 minecraft:green_terracotta
fill 205 196 411 209 196 411 minecraft:green_terracotta
fill 210 196 411 211 196 411 minecraft:lime_terracotta
fill 211 196 369 212 196 369 minecraft:lime_terracotta
fill 212 196 411 213 201 411 minecraft:green_terracotta
setblock 213 196 369 minecraft:moss_block
fill 214 196 369 216 196 369 minecraft:green_terracotta
setblock 215 196 411 minecraft:moss_block
fill 216 196 411 218 196 411 minecraft:green_terracotta
setblock 217 196 369 minecraft:moss_block
fill 218 196 369 218 198 369 minecraft:green_terracotta
fill 219 196 411 219 197 411 minecraft:lime_terracotta
fill 220 196 411 221 201 411 minecraft:green_terracotta
fill 221 196 369 222 201 369 minecraft:green_terracotta
setblock 222 196 411 minecraft:lime_terracotta
fill 223 196 369 224 197 369 minecraft:lime_terracotta
fill 223 196 411 224 199 411 minecraft:green_terracotta
fill 225 196 369 227 197 369 minecraft:green_terracotta
setblock 228 196 369 minecraft:moss_block
fill 229 196 369 230 198 369 minecraft:green_terracotta
fill 229 196 411 229 197 411 minecraft:green_terracotta
fill 230 196 370 230 196 371 minecraft:lime_terracotta
fill 230 196 372 230 197 373 minecraft:green_terracotta
fill 230 196 374 230 197 374 minecraft:lime_terracotta
fill 230 196 375 230 196 380 minecraft:green_terracotta
setblock 230 196 381 minecraft:moss_block
fill 230 196 382 230 197 383 minecraft:lime_terracotta
fill 230 196 384 230 197 384 minecraft:green_terracotta
fill 230 196 390 230 199 390 minecraft:green_terracotta
setblock 230 196 391 minecraft:lime_terracotta
setblock 230 196 392 minecraft:moss_block
fill 230 196 393 230 201 393 minecraft:green_terracotta
fill 230 196 394 230 197 395 minecraft:lime_terracotta
fill 230 196 396 230 197 398 minecraft:green_terracotta
setblock 230 196 399 minecraft:moss_block
fill 230 196 400 230 201 401 minecraft:green_terracotta
fill 230 196 402 230 196 403 minecraft:lime_terracotta
setblock 230 196 404 minecraft:moss_block
fill 230 196 405 230 196 408 minecraft:green_terracotta
setblock 230 196 409 minecraft:moss_block
fill 230 196 411 230 197 411 minecraft:lime_terracotta
fill 188 197 375 188 197 376 minecraft:green_terracotta
fill 188 197 377 188 197 378 minecraft:lime_terracotta
setblock 188 197 379 minecraft:green_terracotta
setblock 188 197 381 minecraft:lime_terracotta
fill 188 197 382 188 200 382 minecraft:green_terracotta
setblock 188 197 388 minecraft:green_terracotta
fill 188 197 393 188 200 393 minecraft:green_terracotta
fill 188 197 397 188 199 397 minecraft:green_terracotta
setblock 188 197 398 minecraft:lime_terracotta
setblock 188 197 409 minecraft:lime_terracotta
setblock 188 197 411 minecraft:green_terracotta
fill 189 197 369 190 201 369 minecraft:green_terracotta
fill 190 197 411 191 200 411 minecraft:green_terracotta
setblock 194 197 369 minecraft:green_terracotta
fill 194 197 411 194 199 411 minecraft:green_terracotta
setblock 195 197 369 minecraft:lime_terracotta
fill 196 197 369 198 198 369 minecraft:green_terracotta
fill 200 197 369 200 200 369 minecraft:green_terracotta
fill 205 197 411 206 197 411 minecraft:green_terracotta
setblock 207 197 411 minecraft:lime_terracotta
fill 208 197 411 209 197 411 minecraft:green_terracotta
setblock 210 197 411 minecraft:lime_terracotta
fill 211 197 369 211 200 369 minecraft:green_terracotta
fill 211 197 411 211 200 411 minecraft:green_terracotta
setblock 212 197 369 minecraft:lime_terracotta
fill 213 197 369 214 197 369 minecraft:green_terracotta
fill 215 197 369 216 197 369 minecraft:lime_terracotta
fill 215 197 411 217 197 411 minecraft:green_terracotta
setblock 217 197 369 minecraft:green_terracotta
setblock 218 197 411 minecraft:lime_terracotta
fill 222 197 411 222 200 411 minecraft:green_terracotta
fill 228 197 369 228 199 369 minecraft:green_terracotta
fill 230 197 370 230 199 371 minecraft:green_terracotta
setblock 230 197 375 minecraft:lime_terracotta
fill 230 197 376 230 197 381 minecraft:green_terracotta
setblock 230 197 385 minecraft:green_terracotta
setblock 230 197 386 minecraft:lime_terracotta
fill 230 197 387 230 197 389 minecraft:green_terracotta
fill 230 197 391 230 199 392 minecraft:green_terracotta
fill 230 197 399 230 199 399 minecraft:green_terracotta
fill 230 197 402 230 200 402 minecraft:green_terracotta
setblock 230 197 403 minecraft:lime_terracotta
fill 230 197 404 230 197 405 minecraft:green_terracotta
fill 230 197 406 230 197 407 minecraft:lime_terracotta
fill 230 197 408 230 197 409 minecraft:green_terracotta
fill 188 198 369 188 215 370 minecraft:green_terracotta
setblock 188 198 375 minecraft:green_terracotta
fill 188 198 376 188 199 376 minecraft:lime_terracotta
fill 188 198 377 188 219 378 minecraft:green_terracotta
setblock 188 198 379 minecraft:lime_terracotta
fill 188 198 381 188 215 381 minecraft:green_terracotta
fill 188 198 386 188 199 386 minecraft:green_terracotta
fill 188 198 387 188 199 388 minecraft:lime_terracotta
fill 188 198 389 188 216 390 minecraft:green_terracotta
fill 188 198 398 188 219 398 minecraft:green_terracotta
fill 188 198 399 188 198 400 minecraft:lime_terracotta
fill 188 198 401 188 215 402 minecraft:green_terracotta
fill 188 198 405 188 199 406 minecraft:green_terracotta
fill 188 198 407 188 199 408 minecraft:lime_terracotta
fill 188 198 409 188 216 410 minecraft:green_terracotta
setblock 188 198 411 minecraft:lime_terracotta
fill 189 198 370 191 198 370 minecraft:mud
fill 189 198 372 189 198 374 minecraft:mud
fill 189 198 376 189 198 378 minecraft:mud
fill 189 198 380 189 198 382 minecraft:mud
fill 189 198 384 189 198 386 minecraft:mud
fill 189 198 388 189 198 390 minecraft:mud
fill 189 198 392 189 198 394 minecraft:mud
fill 189 198 396 189 198 398 minecraft:mud
fill 189 198 400 189 198 402 minecraft:mud
fill 189 198 404 189 198 406 minecraft:mud
fill 189 198 408 189 198 410 minecraft:mud
fill 191 198 369 192 215 369 minecraft:green_terracotta
fill 191 198 410 193 198 410 minecraft:mud
fill 193 198 369 194 198 369 minecraft:lime_terracotta
fill 193 198 370 195 198 370 minecraft:mud
fill 195 198 369 195 219 369 minecraft:green_terracotta
fill 195 198 410 197 198 410 minecraft:mud
fill 195 198 411 195 199 411 minecraft:green_terracotta
fill 196 198 411 197 199 411 minecraft:lime_terracotta
fill 197 198 370 199 198 370 minecraft:mud
fill 198 198 411 199 215 411 minecraft:green_terracotta
fill 199 198 410 201 198 410 minecraft:mud
fill 201 198 370 203 198 370 minecraft:mud
fill 203 198 369 204 216 369 minecraft:green_terracotta
fill 203 198 410 205 198 410 minecraft:mud
fill 205 198 369 206 199 369 minecraft:lime_terracotta
fill 205 198 370 207 198 370 minecraft:mud
fill 205 198 411 205 199 411 minecraft:lime_terracotta
fill 206 198 411 207 199 411 minecraft:green_terracotta
fill 207 198 369 210 199 369 minecraft:green_terracotta
fill 207 198 410 209 198 410 minecraft:mud
fill 208 198 411 209 198 411 minecraft:lime_terracotta
fill 209 198 370 211 198 370 minecraft:mud
fill 210 198 411 210 215 411 minecraft:green_terracotta
fill 211 198 410 213 198 410 minecraft:mud
fill 212 198 369 213 201 369 minecraft:green_terracotta
fill 212 198 401 214 199 402 minecraft:spruce_log
fill 213 198 370 215 198 370 minecraft:mud
setblock 214 198 369 minecraft:lime_terracotta
fill 215 198 369 216 219 369 minecraft:green_terracotta
fill 215 198 400 216 200 401 minecraft:spruce_log
fill 215 198 410 217 198 410 minecraft:mud
fill 215 198 411 215 199 411 minecraft:green_terracotta
fill 216 198 411 217 199 411 minecraft:lime_terracotta
fill 217 198 369 217 199 369 minecraft:lime_terracotta
fill 217 198 370 219 198 370 minecraft:mud
fill 218 198 411 219 216 411 minecraft:green_terracotta
fill 219 198 410 221 198 410 minecraft:mud
fill 221 198 370 223 198 370 minecraft:mud
fill 223 198 369 224 215 369 minecraft:green_terracotta
fill 223 198 410 225 198 410 minecraft:mud
fill 225 198 369 226 199 369 minecraft:lime_terracotta
fill 225 198 370 227 198 370 minecraft:mud
fill 225 198 411 227 198 411 minecraft:green_terracotta
fill 227 198 369 227 199 369 minecraft:green_terracotta
fill 227 198 410 229 198 410 minecraft:mud
fill 228 198 411 229 198 411 minecraft:lime_terracotta
fill 229 198 370 229 198 372 minecraft:mud
fill 229 198 374 229 198 376 minecraft:mud
fill 229 198 378 229 198 380 minecraft:mud
fill 229 198 382 229 198 384 minecraft:mud
fill 229 198 386 229 198 388 minecraft:mud
fill 229 198 390 229 198 392 minecraft:mud
fill 229 198 394 229 198 396 minecraft:mud
fill 229 198 398 229 198 400 minecraft:mud
fill 229 198 402 229 198 404 minecraft:mud
fill 229 198 406 229 198 408 minecraft:mud
fill 230 198 372 230 201 372 minecraft:green_terracotta
setblock 230 198 373 minecraft:lime_terracotta
fill 230 198 374 230 216 375 minecraft:green_terracotta
fill 230 198 376 230 199 377 minecraft:lime_terracotta
fill 230 198 378 230 199 383 minecraft:green_terracotta
fill 230 198 384 230 198 385 minecraft:lime_terracotta
fill 230 198 386 230 199 387 minecraft:green_terracotta
fill 230 198 388 230 199 388 minecraft:lime_terracotta
setblock 230 198 389 minecraft:green_terracotta
fill 230 198 394 230 215 395 minecraft:green_terracotta
fill 230 198 396 230 199 397 minecraft:lime_terracotta
fill 230 198 398 230 199 398 minecraft:green_terracotta
fill 230 198 403 230 201 404 minecraft:green_terracotta
setblock 230 198 405 minecraft:lime_terracotta
fill 230 198 406 230 216 407 minecraft:green_terracotta
fill 230 198 408 230 199 408 minecraft:lime_terracotta
setblock 230 198 409 minecraft:green_terracotta
fill 230 198 411 230 215 411 minecraft:green_terracotta
setblock 188 199 375 minecraft:lime_terracotta
fill 188 199 379 188 202 379 minecraft:green_terracotta
fill 188 199 395 188 199 396 minecraft:lime_terracotta
setblock 188 199 399 minecraft:lime_terracotta
fill 188 199 400 188 202 400 minecraft:green_terracotta
fill 188 199 411 188 202 411 minecraft:green_terracotta
setblock 191 199 372 minecraft:light[level=14]
setblock 191 199 380 minecraft:light[level=14]
setblock 191 199 388 minecraft:light[level=14]
setblock 191 199 396 minecraft:light[level=14]
setblock 191 199 404 minecraft:light[level=14]
fill 192 199 411 192 201 411 minecraft:green_terracotta
fill 193 199 369 193 202 369 minecraft:green_terracotta
setblock 193 199 411 minecraft:lime_terracotta
setblock 194 199 369 minecraft:lime_terracotta
setblock 196 199 369 minecraft:green_terracotta
fill 197 199 369 198 199 369 minecraft:lime_terracotta
setblock 199 199 372 minecraft:light[level=14]
setblock 199 199 388 minecraft:light[level=14]
setblock 199 199 396 minecraft:light[level=14]
setblock 199 199 404 minecraft:light[level=14]
setblock 204 199 411 minecraft:lime_terracotta
setblock 207 199 372 minecraft:light[level=14]
setblock 207 199 380 minecraft:light[level=14]
setblock 207 199 388 minecraft:light[level=14]
setblock 207 199 396 minecraft:light[level=14]
setblock 207 199 404 minecraft:light[level=14]
fill 208 199 411 209 202 411 minecraft:green_terracotta
fill 214 199 369 214 202 369 minecraft:green_terracotta
setblock 214 199 400 minecraft:spruce_log
setblock 215 199 372 minecraft:light[level=14]
setblock 215 199 380 minecraft:light[level=14]
setblock 215 199 388 minecraft:light[level=14]
setblock 215 199 396 minecraft:light[level=14]
setblock 215 199 402 minecraft:spruce_log
setblock 215 199 404 minecraft:light[level=14]
fill 217 199 399 218 200 401 minecraft:spruce_log
setblock 218 199 369 minecraft:lime_terracotta
fill 219 199 399 220 201 400 minecraft:spruce_log
fill 221 199 399 221 201 399 minecraft:spruce_log
setblock 223 199 372 minecraft:light[level=14]
setblock 223 199 380 minecraft:light[level=14]
setblock 223 199 388 minecraft:light[level=14]
setblock 223 199 396 minecraft:light[level=14]
setblock 223 199 404 minecraft:light[level=14]
setblock 225 199 411 minecraft:lime_terracotta
fill 226 199 411 227 199 411 minecraft:green_terracotta
setblock 228 199 411 minecraft:lime_terracotta
setblock 229 199 369 minecraft:lime_terracotta
fill 229 199 411 229 202 411 minecraft:green_terracotta
fill 230 199 369 230 201 369 minecraft:green_terracotta
fill 230 199 373 230 201 373 minecraft:green_terracotta
fill 230 199 384 230 202 384 minecraft:green_terracotta
setblock 230 199 385 minecraft:lime_terracotta
setblock 230 199 389 minecraft:lime_terracotta
fill 230 199 405 230 202 405 minecraft:green_terracotta
setblock 230 199 409 minecraft:lime_terracotta
fill 188 200 373 188 201 374 minecraft:lime_terracotta
fill 188 200 375 188 213 376 minecraft:green_terracotta
fill 188 200 385 188 200 386 minecraft:lime_terracotta
fill 188 200 387 188 213 388 minecraft:green_terracotta
fill 188 200 394 188 201 394 minecraft:lime_terracotta
fill 188 200 395 188 213 396 minecraft:green_terracotta
setblock 188 200 397 minecraft:lime_terracotta
fill 188 200 399 188 217 399 minecraft:green_terracotta
fill 188 200 405 188 201 406 minecraft:lime_terracotta
fill 188 200 407 188 213 408 minecraft:green_terracotta
fill 193 200 411 193 213 411 minecraft:green_terracotta
fill 194 200 369 194 217 369 minecraft:green_terracotta
fill 194 200 378 195 200 382 minecraft:lime_terracotta
fill 194 200 411 195 200 411 minecraft:lime_terracotta
fill 195 200 377 197 200 377 minecraft:lime_terracotta
fill 195 200 383 201 200 383 minecraft:lime_terracotta
setblock 196 200 369 minecraft:lime_terracotta
fill 196 200 375 197 200 376 minecraft:lime_terracotta
fill 196 200 378 197 200 379 minecraft:lime_terracotta
fill 196 200 380 196 203 381 minecraft:mud
fill 196 200 382 196 202 382 minecraft:lime_terracotta
fill 196 200 384 200 200 384 minecraft:lime_terracotta
fill 196 200 411 197 217 411 minecraft:green_terracotta
fill 197 200 369 198 213 369 minecraft:green_terracotta
fill 197 200 374 201 200 374 minecraft:lime_terracotta
fill 197 200 380 202 200 380 minecraft:lime_terracotta
fill 197 200 381 200 203 381 minecraft:mud
fill 198 200 375 198 202 375 minecraft:lime_terracotta
fill 198 200 379 202 200 379 minecraft:lime_terracotta
fill 199 200 369 199 201 369 minecraft:lime_terracotta
fill 199 200 373 200 200 373 minecraft:lime_terracotta
fill 200 200 382 202 200 382 minecraft:lime_terracotta
fill 201 200 375 202 201 375 minecraft:lime_terracotta
fill 201 200 381 202 200 381 minecraft:lime_terracotta
fill 202 200 376 203 200 378 minecraft:lime_terracotta
fill 202 200 411 203 201 411 minecraft:lime_terracotta
fill 204 200 411 205 213 411 minecraft:green_terracotta
fill 205 200 369 206 213 369 minecraft:green_terracotta
setblock 206 200 411 minecraft:lime_terracotta
fill 207 200 369 208 200 369 minecraft:lime_terracotta
fill 207 200 411 207 219 411 minecraft:green_terracotta
fill 209 200 369 210 201 369 minecraft:green_terracotta
setblock 214 200 401 minecraft:spruce_log
fill 214 200 411 215 201 411 minecraft:lime_terracotta
fill 216 200 411 217 213 411 minecraft:green_terracotta
fill 217 200 369 218 213 369 minecraft:green_terracotta
fill 219 200 369 220 201 369 minecraft:lime_terracotta
fill 221 200 398 223 201 398 minecraft:spruce_log
fill 221 200 400 222 200 400 minecraft:spruce_log
fill 222 200 399 223 201 399 minecraft:spruce_log
fill 223 200 411 223 201 411 minecraft:lime_terracotta
fill 224 200 411 225 201 411 minecraft:green_terracotta
fill 225 200 369 226 202 369 minecraft:green_terracotta
fill 226 200 411 227 200 411 minecraft:lime_terracotta
fill 227 200 369 228 200 369 minecraft:lime_terracotta
fill 228 200 411 228 217 411 minecraft:green_terracotta
fill 229 200 369 229 213 369 minecraft:green_terracotta
fill 230 200 370 230 201 370 minecraft:lime_terracotta
setblock 230 200 371 minecraft:green_terracotta
fill 230 200 376 230 213 377 minecraft:green_terracotta
fill 230 200 378 230 201 379 minecraft:lime_terracotta
fill 230 200 380 230 200 383 minecraft:green_terracotta
fill 230 200 385 230 202 386 minecraft:green_terracotta
setblock 230 200 387 minecraft:lime_terracotta
fill 230 200 388 230 213 389 minecraft:green_terracotta
fill 230 200 390 230 201 391 minecraft:lime_terracotta
fill 230 200 392 230 201 392 minecraft:green_terracotta
fill 230 200 396 230 213 397 minecraft:green_terracotta
fill 230 200 398 230 200 399 minecraft:lime_terracotta
fill 230 200 408 230 213 409 minecraft:green_terracotta
fill 230 200 410 230 201 410 minecraft:lime_terracotta
setblock 188 201 382 minecraft:lime_terracotta
setblock 188 201 385 minecraft:lime_terracotta
fill 188 201 386 188 219 386 minecraft:green_terracotta
setblock 188 201 393 minecraft:lime_terracotta
fill 188 201 397 188 219 397 minecraft:green_terracotta
fill 190 201 411 191 201 411 minecraft:lime_terracotta
fill 194 201 380 195 201 380 minecraft:lime_terracotta
setblock 194 201 411 minecraft:lime_terracotta
fill 195 201 378 195 201 379 minecraft:lime_terracotta
fill 195 201 381 195 201 382 minecraft:lime_terracotta
fill 195 201 411 195 219 411 minecraft:green_terracotta
fill 196 201 369 196 219 369 minecraft:green_terracotta
fill 196 201 377 197 201 378 minecraft:lime_terracotta
fill 196 201 379 196 203 379 minecraft:mud
fill 196 201 383 200 201 383 minecraft:lime_terracotta
fill 197 201 375 197 201 376 minecraft:lime_terracotta
fill 197 201 379 201 201 379 minecraft:lime_terracotta
fill 197 201 380 198 203 380 minecraft:mud
fill 197 201 384 198 201 384 minecraft:lime_terracotta
fill 198 201 374 200 201 374 minecraft:lime_terracotta
fill 199 201 380 201 201 380 minecraft:lime_terracotta
fill 199 201 404 202 201 406 minecraft:lime_concrete
setblock 200 201 369 minecraft:lime_terracotta
fill 200 201 382 201 201 382 minecraft:lime_terracotta
fill 200 201 403 201 201 403 minecraft:lime_concrete
fill 201 201 381 201 202 381 minecraft:lime_terracotta
setblock 201 201 407 minecraft:lime_concrete
fill 202 201 376 202 201 378 minecraft:lime_terracotta
setblock 203 201 405 minecraft:lime_concrete
fill 206 201 411 206 219 411 minecraft:green_terracotta
fill 207 201 369 207 219 369 minecraft:green_terracotta
setblock 208 201 369 minecraft:lime_terracotta
setblock 211 201 369 minecraft:lime_terracotta
setblock 211 201 411 minecraft:lime_terracotta
setblock 221 201 400 minecraft:spruce_log
setblock 222 201 411 minecraft:lime_terracotta
fill 226 201 411 227 219 411 minecraft:green_terracotta
fill 227 201 369 227 219 369 minecraft:green_terracotta
setblock 228 201 369 minecraft:lime_terracotta
setblock 230 201 371 minecraft:lime_terracotta
fill 230 201 380 230 201 381 minecraft:green_terracotta
setblock 230 201 382 minecraft:lime_terracotta
fill 230 201 383 230 215 383 minecraft:green_terracotta
fill 230 201 387 230 219 387 minecraft:green_terracotta
fill 230 201 398 230 219 398 minecraft:green_terracotta
setblock 230 201 399 minecraft:lime_terracotta
setblock 230 201 402 minecraft:lime_terracotta
fill 188 202 371 188 203 372 minecraft:lime_terracotta
fill 188 202 373 188 215 374 minecraft:green_terracotta
fill 188 202 380 188 203 380 minecraft:lime_terracotta
fill 188 202 382 188 215 382 minecraft:green_terracotta
fill 188 202 383 188 202 384 minecraft:lime_terracotta
fill 188 202 385 188 219 385 minecraft:green_terracotta
fill 188 202 391 188 203 392 minecraft:lime_terracotta
fill 188 202 393 188 215 394 minecraft:green_terracotta
fill 188 202 403 188 202 404 minecraft:lime_terracotta
fill 188 202 405 188 215 406 minecraft:green_terracotta
fill 189 202 369 190 202 369 minecraft:lime_terracotta
fill 189 202 411 189 203 411 minecraft:lime_terracotta
fill 190 202 411 191 215 411 minecraft:green_terracotta
setblock 192 202 411 minecraft:lime_terracotta
fill 194 202 411 194 219 411 minecraft:green_terracotta
fill 195 202 379 195 202 381 minecraft:lime_terracotta
fill 196 202 378 197 202 378 minecraft:lime_terracotta
fill 197 202 376 197 202 377 minecraft:lime_terracotta
fill 197 202 379 197 203 379 minecraft:mud
fill 197 202 383 199 202 383 minecraft:lime_terracotta
fill 198 202 379 201 202 379 minecraft:lime_terracotta
fill 199 202 369 200 215 369 minecraft:green_terracotta
fill 199 202 380 200 203 380 minecraft:mud
setblock 200 202 382 minecraft:lime_terracotta
fill 200 202 411 201 203 411 minecraft:lime_terracotta
fill 201 202 369 202 203 369 minecraft:lime_terracotta
setblock 201 202 375 minecraft:lime_terracotta
setblock 201 202 380 minecraft:lime_terracotta
fill 202 202 411 203 215 411 minecraft:green_terracotta
fill 208 202 369 208 219 369 minecraft:green_terracotta
fill 209 202 369 210 202 369 minecraft:lime_terracotta
fill 211 202 369 212 215 369 minecraft:green_terracotta
fill 211 202 411 211 215 411 minecraft:green_terracotta
fill 212 202 411 213 202 411 minecraft:lime_terracotta
fill 213 202 369 213 203 369 minecraft:lime_terracotta
fill 214 202 411 215 219 411 minecraft:green_terracotta
fill 219 202 369 220 215 369 minecraft:green_terracotta
fill 220 202 411 221 203 411 minecraft:lime_terracotta
fill 221 202 369 222 203 369 minecraft:lime_terracotta
fill 222 202 411 223 215 411 minecraft:green_terracotta
setblock 224 202 411 minecraft:lime_terracotta
fill 225 202 411 225 213 411 minecraft:green_terracotta
fill 228 202 369 228 219 369 minecraft:green_terracotta
setblock 230 202 369 minecraft:lime_terracotta
fill 230 202 370 230 215 371 minecraft:green_terracotta
fill 230 202 372 230 203 373 minecraft:lime_terracotta
fill 230 202 378 230 219 379 minecraft:green_terracotta
fill 230 202 380 230 202 381 minecraft:lime_terracotta
fill 230 202 382 230 215 382 minecraft:green_terracotta
fill 230 202 390 230 215 391 minecraft:green_terracotta
fill 230 202 392 230 203 393 minecraft:lime_terracotta
fill 230 202 399 230 219 399 minecraft:green_terracotta
fill 230 202 400 230 202 401 minecraft:lime_terracotta
fill 230 202 402 230 215 403 minecraft:green_terracotta
fill 230 202 404 230 203 404 minecraft:lime_terracotta
fill 230 202 410 230 219 410 minecraft:green_terracotta
setblock 188 203 379 minecraft:lime_terracotta
fill 188 203 383 188 213 384 minecraft:green_terracotta
setblock 188 203 400 minecraft:lime_terracotta
setblock 188 203 403 minecraft:lime_terracotta
fill 188 203 404 188 213 404 minecraft:green_terracotta
setblock 188 203 411 minecraft:lime_terracotta
fill 189 203 369 189 213 369 minecraft:green_terracotta
setblock 190 203 369 minecraft:lime_terracotta
fill 192 203 411 192 213 411 minecraft:green_terracotta
setblock 193 203 369 minecraft:lime_terracotta
setblock 197 203 378 minecraft:mud
fill 198 203 379 200 203 379 minecraft:mud
fill 208 203 411 209 203 411 minecraft:lime_terracotta
fill 209 203 369 210 213 369 minecraft:green_terracotta
setblock 212 203 411 minecraft:lime_terracotta
fill 213 203 411 213 213 411 minecraft:green_terracotta
setblock 214 203 369 minecraft:lime_terracotta
fill 224 203 411 224 213 411 minecraft:green_terracotta
setblock 225 203 369 minecraft:lime_terracotta
fill 226 203 369 226 217 369 minecraft:green_terracotta
setblock 229 203 411 minecraft:lime_terracotta
fill 230 203 369 230 213 369 minecraft:green_terracotta
fill 230 203 380 230 213 380 minecraft:green_terracotta
setblock 230 203 381 minecraft:lime_terracotta
fill 230 203 384 230 203 385 minecraft:lime_terracotta
fill 230 203 386 230 219 386 minecraft:green_terracotta
fill 230 203 400 230 213 401 minecraft:green_terracotta
setblock 230 203 405 minecraft:lime_terracotta
fill 188 204 371 188 214 372 minecraft:green_terracotta
fill 188 204 379 188 217 380 minecraft:green_terracotta
fill 188 204 391 188 214 392 minecraft:green_terracotta
fill 188 204 400 188 217 400 minecraft:green_terracotta
fill 188 204 403 188 214 403 minecraft:green_terracotta
fill 188 204 411 189 217 411 minecraft:green_terracotta
fill 190 204 369 190 214 369 minecraft:green_terracotta
fill 193 204 369 193 217 369 minecraft:green_terracotta
fill 200 204 411 201 214 411 minecraft:green_terracotta
fill 201 204 369 202 214 369 minecraft:green_terracotta
fill 208 204 411 209 217 411 minecraft:green_terracotta
fill 212 204 411 212 214 411 minecraft:green_terracotta
fill 213 204 369 214 217 369 minecraft:green_terracotta
fill 220 204 411 221 217 411 minecraft:green_terracotta
fill 221 204 369 222 214 369 minecraft:green_terracotta
fill 225 204 369 225 217 369 minecraft:green_terracotta
fill 229 204 411 229 217 411 minecraft:green_terracotta
fill 230 204 372 230 217 373 minecraft:green_terracotta
fill 230 204 381 230 214 381 minecraft:green_terracotta
fill 230 204 384 230 217 385 minecraft:green_terracotta
fill 230 204 392 230 214 393 minecraft:green_terracotta
fill 230 204 404 230 217 405 minecraft:green_terracotta
setblock 191 207 372 minecraft:light[level=14]
setblock 191 207 380 minecraft:light[level=14]
setblock 191 207 388 minecraft:light[level=14]
setblock 191 207 396 minecraft:light[level=14]
setblock 191 207 404 minecraft:light[level=14]
setblock 199 207 372 minecraft:light[level=14]
setblock 199 207 380 minecraft:light[level=14]
setblock 199 207 388 minecraft:light[level=14]
setblock 199 207 396 minecraft:light[level=14]
setblock 199 207 404 minecraft:light[level=14]
setblock 207 207 372 minecraft:light[level=14]
setblock 207 207 380 minecraft:light[level=14]
setblock 207 207 388 minecraft:light[level=14]
setblock 207 207 396 minecraft:light[level=14]
setblock 207 207 404 minecraft:light[level=14]
setblock 215 207 372 minecraft:light[level=14]
setblock 215 207 380 minecraft:light[level=14]
setblock 215 207 388 minecraft:light[level=14]
setblock 215 207 396 minecraft:light[level=14]
setblock 215 207 404 minecraft:light[level=14]
setblock 223 207 372 minecraft:light[level=14]
setblock 223 207 380 minecraft:light[level=14]
setblock 223 207 388 minecraft:light[level=14]
setblock 223 207 396 minecraft:light[level=14]
setblock 223 207 404 minecraft:light[level=14]
fill 204 208 384 204 208 390 minecraft:pink_terracotta
fill 205 208 383 205 208 386 minecraft:pink_terracotta
fill 205 208 388 205 208 391 minecraft:pink_terracotta
fill 206 208 382 206 208 383 minecraft:pink_terracotta
fill 206 208 391 206 208 392 minecraft:pink_terracotta
fill 207 208 381 209 208 382 minecraft:pink_terracotta
fill 207 208 392 209 208 393 minecraft:pink_terracotta
fill 210 208 381 213 208 381 minecraft:pink_terracotta
fill 210 208 393 213 208 393 minecraft:pink_terracotta
fill 211 208 382 214 208 382 minecraft:pink_terracotta
fill 211 208 392 214 208 392 minecraft:pink_terracotta
fill 214 208 383 215 208 383 minecraft:pink_terracotta
fill 214 208 391 215 208 391 minecraft:pink_terracotta
fill 215 208 384 216 208 386 minecraft:pink_terracotta
fill 215 208 388 216 208 390 minecraft:pink_terracotta
setblock 216 208 387 minecraft:pink_terracotta
fill 203 209 384 203 211 390 minecraft:pink_terracotta
fill 204 209 382 204 211 386 minecraft:pink_terracotta
fill 204 209 387 205 210 387 minecraft:red_terracotta
fill 204 209 388 204 211 392 minecraft:pink_terracotta
fill 205 209 381 205 211 383 minecraft:pink_terracotta
fill 205 209 384 205 210 384 minecraft:red_terracotta
fill 205 209 385 205 210 385 minecraft:pink_concrete
fill 205 209 386 206 210 386 minecraft:red_terracotta
fill 205 209 388 205 210 388 minecraft:pink_concrete
fill 205 209 389 205 210 390 minecraft:red_terracotta
fill 205 209 391 205 211 393 minecraft:pink_terracotta
fill 206 209 381 206 211 382 minecraft:pink_terracotta
fill 206 209 383 206 210 383 minecraft:red_terracotta
fill 206 209 384 206 210 384 minecraft:pink_concrete
fill 206 209 385 207 209 385 minecraft:red_terracotta
fill 206 209 387 206 210 387 minecraft:pink_concrete
fill 206 209 388 206 210 389 minecraft:red_terracotta
fill 206 209 390 206 210 390 minecraft:pink_concrete
fill 206 209 391 207 210 391 minecraft:red_terracotta
fill 206 209 392 206 211 393 minecraft:pink_terracotta
fill 207 209 380 209 211 381 minecraft:pink_terracotta
fill 207 209 382 207 210 382 minecraft:red_terracotta
fill 207 209 383 207 210 383 minecraft:pink_concrete
fill 207 209 384 208 209 384 minecraft:red_terracotta
setblock 207 209 386 minecraft:pink_concrete
fill 207 209 387 207 209 388 minecraft:red_terracotta
setblock 207 209 389 minecraft:pink_concrete
fill 207 209 390 208 209 390 minecraft:red_terracotta
fill 207 209 392 207 210 392 minecraft:pink_concrete
fill 207 209 393 209 211 394 minecraft:pink_terracotta
fill 208 209 382 208 210 382 minecraft:pink_concrete
fill 208 209 383 209 210 383 minecraft:red_terracotta
setblock 208 209 385 minecraft:pink_concrete
setblock 208 209 389 minecraft:red_terracotta
fill 208 209 391 208 210 391 minecraft:pink_concrete
fill 208 209 392 209 210 392 minecraft:red_terracotta
fill 209 209 382 210 210 382 minecraft:red_terracotta
setblock 209 209 384 minecraft:pink_concrete
setblock 209 209 390 minecraft:pink_concrete
fill 209 209 391 210 210 391 minecraft:red_terracotta
fill 210 209 380 213 211 380 minecraft:pink_terracotta
fill 210 209 381 210 210 381 minecraft:red_terracotta
fill 210 209 383 210 210 383 minecraft:pink_concrete
fill 210 209 384 211 209 384 minecraft:red_terracotta
fill 210 209 390 211 209 390 minecraft:red_terracotta
fill 210 209 392 210 210 392 minecraft:pink_concrete
fill 210 209 393 210 210 393 minecraft:red_terracotta
fill 210 209 394 213 211 394 minecraft:pink_terracotta
fill 211 209 381 215 211 381 minecraft:pink_terracotta
fill 211 209 382 211 210 382 minecraft:pink_concrete
fill 211 209 383 212 210 383 minecraft:red_terracotta
fill 211 209 391 211 210 391 minecraft:pink_concrete
fill 211 209 392 212 210 392 minecraft:red_terracotta
fill 211 209 393 215 211 393 minecraft:pink_terracotta
fill 212 209 382 213 210 382 minecraft:red_terracotta
setblock 212 209 384 minecraft:pink_concrete
fill 212 209 385 213 209 385 minecraft:red_terracotta
setblock 212 209 389 minecraft:red_terracotta
setblock 212 209 390 minecraft:pink_concrete
fill 212 209 391 213 210 391 minecraft:red_terracotta
fill 213 209 383 213 210 383 minecraft:pink_concrete
fill 213 209 384 214 210 384 minecraft:red_terracotta
setblock 213 209 386 minecraft:pink_concrete
fill 213 209 387 213 209 388 minecraft:red_terracotta
setblock 213 209 389 minecraft:pink_concrete
fill 213 209 390 214 210 390 minecraft:red_terracotta
fill 213 209 392 213 210 392 minecraft:pink_concrete
fill 214 209 382 216 211 382 minecraft:pink_terracotta
fill 214 209 383 214 210 383 minecraft:red_terracotta
fill 214 209 385 214 210 385 minecraft:pink_concrete
fill 214 209 386 214 210 387 minecraft:red_terracotta
fill 214 209 388 214 210 388 minecraft:pink_concrete
fill 214 209 389 215 210 389 minecraft:red_terracotta
fill 214 209 391 214 210 391 minecraft:pink_concrete
fill 214 209 392 216 211 392 minecraft:pink_terracotta
fill 215 209 383 216 211 383 minecraft:pink_terracotta
fill 215 209 384 215 210 384 minecraft:pink_concrete
fill 215 209 385 215 210 386 minecraft:red_terracotta
fill 215 209 387 215 210 387 minecraft:pink_concrete
fill 215 209 388 215 210 388 minecraft:red_terracotta
fill 215 209 390 215 210 390 minecraft:pink_concrete
fill 215 209 391 216 211 391 minecraft:pink_terracotta
fill 216 209 384 217 211 386 minecraft:pink_terracotta
fill 216 209 387 216 210 387 minecraft:red_terracotta
fill 216 209 388 217 211 390 minecraft:pink_terracotta
fill 217 209 387 217 211 387 minecraft:pink_terracotta
fill 189 210 370 202 210 410 minecraft:pink_terracotta
fill 203 210 370 203 210 383 minecraft:pink_terracotta
fill 203 210 391 203 210 410 minecraft:pink_terracotta
fill 204 210 370 204 210 381 minecraft:pink_terracotta
fill 204 210 393 204 210 410 minecraft:pink_terracotta
fill 205 210 370 206 210 380 minecraft:pink_terracotta
fill 205 210 394 206 210 410 minecraft:pink_terracotta
setblock 206 210 385 minecraft:red_terracotta
fill 207 210 370 229 210 379 minecraft:pink_terracotta
setblock 207 210 384 minecraft:red_terracotta
fill 207 210 385 207 210 389 minecraft:verdant_froglight
setblock 207 210 390 minecraft:red_terracotta
fill 207 210 395 229 210 410 minecraft:pink_terracotta
fill 208 210 384 208 210 385 minecraft:verdant_froglight
fill 208 210 389 208 210 390 minecraft:verdant_froglight
fill 209 210 384 212 210 384 minecraft:verdant_froglight
fill 209 210 390 212 210 390 minecraft:verdant_froglight
fill 212 210 385 213 210 385 minecraft:verdant_froglight
fill 212 210 389 213 210 389 minecraft:verdant_froglight
fill 213 210 386 213 210 388 minecraft:verdant_froglight
fill 214 210 380 229 210 380 minecraft:pink_terracotta
fill 214 210 394 229 210 394 minecraft:pink_terracotta
fill 216 210 381 229 210 381 minecraft:pink_terracotta
fill 216 210 393 229 210 393 minecraft:pink_terracotta
fill 217 210 382 229 210 383 minecraft:pink_terracotta
fill 217 210 391 229 210 392 minecraft:pink_terracotta
fill 218 210 384 229 210 390 minecraft:pink_terracotta
fill 204 211 387 205 211 387 minecraft:pink_terracotta
fill 205 211 384 206 211 386 minecraft:pink_terracotta
fill 205 211 388 206 211 390 minecraft:pink_terracotta
fill 206 211 383 209 211 383 minecraft:pink_terracotta
fill 206 211 391 209 211 391 minecraft:pink_terracotta
fill 207 211 382 213 211 382 minecraft:pink_terracotta
setblock 207 211 384 minecraft:pink_terracotta
setblock 207 211 390 minecraft:pink_terracotta
fill 207 211 392 213 211 392 minecraft:pink_terracotta
fill 210 211 381 210 212 381 minecraft:pink_terracotta
fill 210 211 393 210 212 393 minecraft:pink_terracotta
fill 211 211 383 214 211 383 minecraft:pink_terracotta
fill 211 211 391 214 211 391 minecraft:pink_terracotta
fill 213 211 384 215 211 384 minecraft:pink_terracotta
fill 213 211 390 215 211 390 minecraft:pink_terracotta
fill 214 211 385 215 211 386 minecraft:pink_terracotta
fill 214 211 388 215 211 389 minecraft:pink_terracotta
fill 215 211 387 216 211 387 minecraft:pink_terracotta
fill 204 212 384 204 212 390 minecraft:pink_terracotta
fill 205 212 383 205 212 386 minecraft:pink_terracotta
fill 205 212 388 205 212 391 minecraft:pink_terracotta
fill 206 212 382 206 212 383 minecraft:pink_terracotta
fill 206 212 391 206 212 392 minecraft:pink_terracotta
fill 207 212 381 209 212 382 minecraft:pink_terracotta
fill 207 212 392 209 212 393 minecraft:pink_terracotta
fill 211 212 381 213 212 382 minecraft:pink_terracotta
fill 211 212 392 213 212 393 minecraft:pink_terracotta
fill 214 212 382 214 212 383 minecraft:pink_terracotta
fill 214 212 391 214 212 392 minecraft:pink_terracotta
fill 215 212 383 215 212 386 minecraft:pink_terracotta
fill 215 212 388 215 212 391 minecraft:pink_terracotta
fill 216 212 384 216 212 390 minecraft:pink_terracotta
fill 188 214 375 188 214 376 minecraft:lime_terracotta
fill 188 214 383 188 215 384 minecraft:lime_terracotta
setblock 188 214 387 minecraft:lime_terracotta
fill 188 214 388 188 217 388 minecraft:green_terracotta
fill 188 214 395 188 215 396 minecraft:lime_terracotta
fill 188 214 404 188 215 404 minecraft:lime_terracotta
fill 188 214 407 188 214 408 minecraft:lime_terracotta
fill 189 214 369 189 215 369 minecraft:lime_terracotta
fill 192 214 411 193 215 411 minecraft:lime_terracotta
fill 197 214 369 198 215 369 minecraft:lime_terracotta
fill 204 214 411 205 214 411 minecraft:lime_terracotta
fill 205 214 369 205 217 369 minecraft:green_terracotta
setblock 206 214 369 minecraft:lime_terracotta
fill 209 214 369 210 215 369 minecraft:lime_terracotta
fill 213 214 411 213 215 411 minecraft:lime_terracotta
setblock 216 214 411 minecraft:lime_terracotta
fill 217 214 369 218 214 369 minecraft:lime_terracotta
fill 217 214 411 217 217 411 minecraft:green_terracotta
fill 224 214 411 225 215 411 minecraft:lime_terracotta
fill 229 214 369 230 215 369 minecraft:lime_terracotta
fill 230 214 376 230 217 376 minecraft:green_terracotta
setblock 230 214 377 minecraft:lime_terracotta
fill 230 214 380 230 215 380 minecraft:lime_terracotta
fill 230 214 388 230 215 389 minecraft:lime_terracotta
fill 230 214 396 230 217 396 minecraft:green_terracotta
setblock 230 214 397 minecraft:lime_terracotta
fill 230 214 400 230 215 401 minecraft:lime_terracotta
fill 230 214 408 230 214 409 minecraft:lime_terracotta
fill 188 215 371 188 215 372 minecraft:lime_terracotta
setblock 188 215 375 minecraft:lime_terracotta
fill 188 215 376 188 218 376 minecraft:green_terracotta
fill 188 215 387 188 218 387 minecraft:green_terracotta
fill 188 215 391 188 217 391 minecraft:green_terracotta
setblock 188 215 392 minecraft:lime_terracotta
setblock 188 215 403 minecraft:lime_terracotta
fill 188 215 407 188 218 408 minecraft:green_terracotta
setblock 190 215 369 minecraft:lime_terracotta
setblock 191 215 372 minecraft:light[level=14]
setblock 191 215 380 minecraft:light[level=14]
setblock 191 215 388 minecraft:light[level=14]
setblock 191 215 396 minecraft:light[level=14]
setblock 191 215 404 minecraft:light[level=14]
setblock 199 215 372 minecraft:light[level=14]
setblock 199 215 380 minecraft:light[level=14]
setblock 199 215 388 minecraft:light[level=14]
setblock 199 215 396 minecraft:light[level=14]
setblock 199 215 404 minecraft:light[level=14]
fill 200 215 411 200 217 411 minecraft:green_terracotta
setblock 201 215 369 minecraft:lime_terracotta
setblock 201 215 411 minecraft:lime_terracotta
fill 202 215 369 202 217 369 minecraft:green_terracotta
setblock 204 215 411 minecraft:lime_terracotta
fill 205 215 411 205 218 411 minecraft:green_terracotta
fill 206 215 369 206 218 369 minecraft:green_terracotta
setblock 207 215 372 minecraft:light[level=14]
setblock 207 215 380 minecraft:light[level=14]
setblock 207 215 388 minecraft:light[level=14]
setblock 207 215 396 minecraft:light[level=14]
setblock 207 215 404 minecraft:light[level=14]
setblock 212 215 411 minecraft:lime_terracotta
setblock 215 215 372 minecraft:light[level=14]
setblock 215 215 380 minecraft:light[level=14]
setblock 215 215 388 minecraft:light[level=14]
setblock 215 215 396 minecraft:light[level=14]
setblock 215 215 404 minecraft:light[level=14]
fill 216 215 411 216 218 411 minecraft:green_terracotta
fill 217 215 369 217 218 369 minecraft:green_terracotta
setblock 218 215 369 minecraft:lime_terracotta
fill 218 215 389 220 261 391 minecraft:mud
fill 219 215 388 220 261 388 minecraft:mud
fill 221 215 369 222 215 369 minecraft:lime_terracotta
fill 221 215 389 221 261 390 minecraft:mud
setblock 223 215 372 minecraft:light[level=14]
setblock 223 215 380 minecraft:light[level=14]
setblock 223 215 388 minecraft:light[level=14]
setblock 223 215 396 minecraft:light[level=14]
setblock 223 215 404 minecraft:light[level=14]
fill 230 215 377 230 218 377 minecraft:green_terracotta
setblock 230 215 381 minecraft:lime_terracotta
setblock 230 215 392 minecraft:lime_terracotta
fill 230 215 393 230 217 393 minecraft:green_terracotta
fill 230 215 397 230 217 397 minecraft:green_terracotta
fill 230 215 408 230 218 408 minecraft:green_terracotta
setblock 230 215 409 minecraft:lime_terracotta
fill 188 216 369 190 216 369 minecraft:green_terracotta
fill 188 216 370 188 217 370 minecraft:lime_terracotta
fill 188 216 371 188 221 372 minecraft:green_terracotta
setblock 188 216 373 minecraft:lime_terracotta
fill 188 216 374 188 219 375 minecraft:green_terracotta
fill 188 216 381 188 217 382 minecraft:lime_terracotta
fill 188 216 383 188 221 384 minecraft:green_terracotta
fill 188 216 392 188 221 392 minecraft:green_terracotta
fill 188 216 393 188 216 394 minecraft:lime_terracotta
fill 188 216 395 188 221 396 minecraft:green_terracotta
fill 188 216 401 188 217 402 minecraft:lime_terracotta
fill 188 216 403 188 221 404 minecraft:green_terracotta
setblock 188 216 405 minecraft:lime_terracotta
fill 188 216 406 188 219 406 minecraft:green_terracotta
fill 189 216 370 191 216 370 minecraft:mud
fill 189 216 372 189 216 374 minecraft:mud
fill 189 216 376 189 216 378 minecraft:mud
fill 189 216 380 189 216 382 minecraft:mud
fill 189 216 384 189 216 386 minecraft:mud
fill 189 216 388 189 216 390 minecraft:mud
fill 189 216 392 189 216 394 minecraft:mud
fill 189 216 396 189 216 398 minecraft:mud
fill 189 216 400 189 216 402 minecraft:mud
fill 189 216 404 189 216 406 minecraft:mud
fill 189 216 408 189 216 410 minecraft:mud
fill 190 216 411 191 217 411 minecraft:lime_terracotta
fill 191 216 369 192 217 369 minecraft:lime_terracotta
fill 191 216 410 193 216 410 minecraft:mud
fill 192 216 411 193 221 411 minecraft:green_terracotta
fill 193 216 370 195 216 370 minecraft:mud
fill 195 216 410 197 216 410 minecraft:mud
fill 197 216 369 198 221 369 minecraft:green_terracotta
fill 197 216 370 199 216 370 minecraft:mud
setblock 198 216 411 minecraft:green_terracotta
fill 199 216 369 200 216 369 minecraft:lime_terracotta
fill 199 216 410 201 216 410 minecraft:mud
fill 199 216 411 199 217 411 minecraft:lime_terracotta
fill 201 216 369 201 221 369 minecraft:green_terracotta
fill 201 216 370 203 216 370 minecraft:mud
fill 201 216 411 201 221 411 minecraft:green_terracotta
fill 202 216 411 203 216 411 minecraft:lime_terracotta
fill 203 216 410 205 216 410 minecraft:mud
fill 204 216 411 204 221 411 minecraft:green_terracotta
fill 205 216 370 207 216 370 minecraft:mud
fill 207 216 410 209 216 410 minecraft:mud
fill 209 216 369 210 221 369 minecraft:green_terracotta
fill 209 216 370 211 216 370 minecraft:mud
fill 210 216 411 211 217 411 minecraft:lime_terracotta
fill 211 216 369 212 217 369 minecraft:lime_terracotta
fill 211 216 410 213 216 410 minecraft:mud
fill 212 216 411 213 221 411 minecraft:green_terracotta
fill 213 216 370 215 216 370 minecraft:mud
fill 215 216 410 217 216 410 minecraft:mud
fill 217 216 370 219 216 370 minecraft:mud
fill 217 216 389 217 217 391 minecraft:mud
fill 218 216 369 219 219 369 minecraft:green_terracotta
fill 218 216 388 218 217 388 minecraft:mud
fill 218 216 392 220 217 392 minecraft:mud
fill 219 216 387 220 217 387 minecraft:mud
fill 219 216 410 221 216 410 minecraft:mud
setblock 220 216 369 minecraft:lime_terracotta
fill 221 216 369 222 221 369 minecraft:green_terracotta
fill 221 216 370 223 216 370 minecraft:mud
fill 221 216 388 221 217 388 minecraft:mud
fill 221 216 391 221 217 391 minecraft:mud
fill 222 216 389 222 217 390 minecraft:mud
fill 222 216 411 223 216 411 minecraft:lime_terracotta
fill 223 216 369 223 217 369 minecraft:lime_terracotta
fill 223 216 410 225 216 410 minecraft:mud
setblock 224 216 369 minecraft:green_terracotta
fill 224 216 411 225 221 411 minecraft:green_terracotta
fill 225 216 370 227 216 370 minecraft:mud
fill 227 216 410 229 216 410 minecraft:mud
fill 229 216 369 230 221 369 minecraft:green_terracotta
fill 229 216 370 229 216 372 minecraft:mud
fill 229 216 374 229 216 376 minecraft:mud
fill 229 216 378 229 216 380 minecraft:mud
fill 229 216 382 229 216 384 minecraft:mud
fill 229 216 386 229 216 388 minecraft:mud
fill 229 216 390 229 216 392 minecraft:mud
fill 229 216 394 229 216 396 minecraft:mud
fill 229 216 398 229 216 400 minecraft:mud
fill 229 216 402 229 216 404 minecraft:mud
fill 229 216 406 229 216 408 minecraft:mud
fill 230 216 370 230 216 371 minecraft:lime_terracotta
fill 230 216 380 230 221 381 minecraft:green_terracotta
fill 230 216 382 230 217 383 minecraft:lime_terracotta
fill 230 216 388 230 218 389 minecraft:green_terracotta
fill 230 216 390 230 216 391 minecraft:lime_terracotta
fill 230 216 392 230 221 392 minecraft:green_terracotta
fill 230 216 394 230 217 394 minecraft:lime_terracotta
setblock 230 216 395 minecraft:green_terracotta
fill 230 216 400 230 221 401 minecraft:green_terracotta
fill 230 216 402 230 217 403 minecraft:lime_terracotta
fill 230 216 409 230 218 409 minecraft:green_terracotta
fill 230 216 411 230 217 411 minecraft:lime_terracotta
setblock 188 217 369 minecraft:lime_terracotta
fill 188 217 373 188 220 373 minecraft:green_terracotta
fill 188 217 389 188 217 390 minecraft:lime_terracotta
setblock 188 217 393 minecraft:lime_terracotta
fill 188 217 394 188 220 394 minecraft:green_terracotta
fill 188 217 405 188 220 405 minecraft:green_terracotta
fill 188 217 409 188 219 409 minecraft:green_terracotta
setblock 188 217 410 minecraft:lime_terracotta
fill 189 217 369 190 221 369 minecraft:green_terracotta
setblock 198 217 411 minecraft:lime_terracotta
fill 199 217 369 199 220 369 minecraft:green_terracotta
setblock 200 217 369 minecraft:lime_terracotta
fill 202 217 411 203 220 411 minecraft:green_terracotta
fill 203 217 369 204 217 369 minecraft:lime_terracotta
fill 216 217 389 216 217 390 minecraft:mud
fill 217 217 387 217 217 388 minecraft:mud
setblock 217 217 392 minecraft:mud
setblock 218 217 387 minecraft:mud
fill 218 217 411 218 219 411 minecraft:green_terracotta
fill 219 217 393 220 217 393 minecraft:mud
setblock 219 217 411 minecraft:lime_terracotta
fill 220 217 369 220 220 369 minecraft:green_terracotta
setblock 221 217 387 minecraft:mud
setblock 221 217 392 minecraft:mud
setblock 222 217 388 minecraft:mud
setblock 222 217 391 minecraft:mud
setblock 222 217 411 minecraft:lime_terracotta
fill 223 217 411 223 220 411 minecraft:green_terracotta
setblock 224 217 369 minecraft:lime_terracotta
fill 230 217 370 230 220 370 minecraft:green_terracotta
setblock 230 217 371 minecraft:lime_terracotta
setblock 230 217 374 minecraft:lime_terracotta
fill 230 217 375 230 219 375 minecraft:green_terracotta
fill 230 217 390 230 220 390 minecraft:green_terracotta
setblock 230 217 391 minecraft:lime_terracotta
setblock 230 217 395 minecraft:lime_terracotta
setblock 230 217 406 minecraft:lime_terracotta
fill 230 217 407 230 219 407 minecraft:green_terracotta
fill 188 218 369 188 223 370 minecraft:green_terracotta
fill 188 218 379 188 218 380 minecraft:lime_terracotta
fill 188 218 381 188 223 382 minecraft:green_terracotta
fill 188 218 388 188 219 388 minecraft:lime_terracotta
fill 188 218 389 188 223 390 minecraft:green_terracotta
setblock 188 218 391 minecraft:lime_terracotta
fill 188 218 393 188 223 393 minecraft:green_terracotta
fill 188 218 399 188 219 400 minecraft:lime_terracotta
fill 188 218 401 188 223 402 minecraft:green_terracotta
fill 188 218 410 188 223 410 minecraft:green_terracotta
fill 188 218 411 189 218 411 minecraft:lime_terracotta
fill 190 218 411 191 223 411 minecraft:green_terracotta
fill 191 218 369 192 223 369 minecraft:green_terracotta
fill 193 218 369 194 219 369 minecraft:lime_terracotta
fill 196 218 411 197 219 411 minecraft:lime_terracotta
fill 198 218 411 199 223 411 minecraft:green_terracotta
fill 200 218 369 200 223 369 minecraft:green_terracotta
setblock 200 218 411 minecraft:lime_terracotta
setblock 202 218 369 minecraft:lime_terracotta
fill 203 218 369 204 223 369 minecraft:green_terracotta
fill 205 218 369 205 219 369 minecraft:lime_terracotta
fill 208 218 411 209 219 411 minecraft:lime_terracotta
fill 210 218 411 211 223 411 minecraft:green_terracotta
fill 211 218 369 212 223 369 minecraft:green_terracotta
fill 213 218 369 214 218 369 minecraft:lime_terracotta
fill 217 218 411 217 219 411 minecraft:lime_terracotta
fill 219 218 411 219 223 411 minecraft:green_terracotta
fill 220 218 411 221 218 411 minecraft:lime_terracotta
fill 222 218 411 222 223 411 minecraft:green_terracotta
fill 223 218 369 224 223 369 minecraft:green_terracotta
fill 225 218 369 226 219 369 minecraft:lime_terracotta
fill 228 218 411 229 219 411 minecraft:lime_terracotta
fill 230 218 371 230 223 371 minecraft:green_terracotta
fill 230 218 372 230 218 373 minecraft:lime_terracotta
fill 230 218 374 230 223 374 minecraft:green_terracotta
fill 230 218 376 230 219 376 minecraft:lime_terracotta
fill 230 218 382 230 223 383 minecraft:green_terracotta
fill 230 218 384 230 219 385 minecraft:lime_terracotta
fill 230 218 391 230 220 391 minecraft:green_terracotta
setblock 230 218 393 minecraft:lime_terracotta
fill 230 218 394 230 223 395 minecraft:green_terracotta
fill 230 218 396 230 219 397 minecraft:lime_terracotta
fill 230 218 402 230 223 403 minecraft:green_terracotta
fill 230 218 404 230 218 405 minecraft:lime_terracotta
fill 230 218 406 230 219 406 minecraft:green_terracotta
fill 230 218 411 230 223 411 minecraft:green_terracotta
setblock 188 219 376 minecraft:lime_terracotta
setblock 188 219 379 minecraft:lime_terracotta
fill 188 219 380 188 222 380 minecraft:green_terracotta
setblock 188 219 387 minecraft:lime_terracotta
fill 188 219 391 188 222 391 minecraft:green_terracotta
fill 188 219 407 188 219 408 minecraft:lime_terracotta
setblock 188 219 411 minecraft:lime_terracotta
fill 189 219 411 189 222 411 minecraft:green_terracotta
fill 200 219 411 200 222 411 minecraft:green_terracotta
fill 201 219 381 202 220 382 minecraft:lime_concrete
fill 202 219 369 202 222 369 minecraft:green_terracotta
setblock 205 219 411 minecraft:lime_terracotta
setblock 206 219 369 minecraft:lime_terracotta
fill 213 219 369 213 222 369 minecraft:green_terracotta
setblock 214 219 369 minecraft:lime_terracotta
setblock 216 219 411 minecraft:lime_terracotta
setblock 217 219 369 minecraft:lime_terracotta
fill 220 219 411 221 221 411 minecraft:green_terracotta
fill 230 219 372 230 222 373 minecraft:green_terracotta
setblock 230 219 377 minecraft:lime_terracotta
setblock 230 219 388 minecraft:lime_terracotta
fill 230 219 389 230 221 389 minecraft:green_terracotta
fill 230 219 393 230 222 393 minecraft:green_terracotta
fill 230 219 404 230 222 404 minecraft:green_terracotta
setblock 230 219 405 minecraft:lime_terracotta
fill 230 219 408 230 219 409 minecraft:lime_terracotta
fill 188 220 374 188 221 374 minecraft:lime_terracotta
fill 188 220 375 188 221 376 minecraft:green_terracotta
fill 188 220 377 188 220 378 minecraft:lime_terracotta
fill 188 220 379 188 225 379 minecraft:green_terracotta
fill 188 220 385 188 221 386 minecraft:lime_terracotta
fill 188 220 387 188 225 388 minecraft:green_terracotta
fill 188 220 397 188 220 398 minecraft:lime_terracotta
fill 188 220 399 188 225 400 minecraft:green_terracotta
fill 188 220 406 188 221 406 minecraft:lime_terracotta
fill 188 220 407 188 225 408 minecraft:green_terracotta
setblock 188 220 409 minecraft:lime_terracotta
fill 188 220 411 188 225 411 minecraft:green_terracotta
fill 193 220 369 194 225 369 minecraft:green_terracotta
fill 194 220 411 195 221 411 minecraft:lime_terracotta
fill 195 220 369 196 220 369 minecraft:lime_terracotta
fill 196 220 411 197 225 411 minecraft:green_terracotta
fill 205 220 369 206 225 369 minecraft:green_terracotta
fill 205 220 411 205 225 411 minecraft:green_terracotta
fill 206 220 411 207 220 411 minecraft:lime_terracotta
fill 207 220 369 208 221 369 minecraft:lime_terracotta
fill 208 220 411 209 225 411 minecraft:green_terracotta
fill 214 220 369 214 225 369 minecraft:green_terracotta
fill 214 220 411 215 221 411 minecraft:lime_terracotta
fill 215 220 369 216 220 369 minecraft:lime_terracotta
fill 216 220 411 217 225 411 minecraft:green_terracotta
fill 217 220 369 218 221 369 minecraft:green_terracotta
setblock 218 220 411 minecraft:lime_terracotta
fill 219 220 369 219 221 369 minecraft:lime_terracotta
fill 225 220 369 226 225 369 minecraft:green_terracotta
fill 226 220 411 227 221 411 minecraft:lime_terracotta
fill 227 220 369 228 221 369 minecraft:lime_terracotta
fill 228 220 411 229 225 411 minecraft:green_terracotta
setblock 230 220 375 minecraft:lime_terracotta
fill 230 220 376 230 225 377 minecraft:green_terracotta
fill 230 220 378 230 221 379 minecraft:lime_terracotta
fill 230 220 384 230 225 385 minecraft:green_terracotta
fill 230 220 386 230 220 387 minecraft:lime_terracotta
fill 230 220 388 230 225 388 minecraft:green_terracotta
fill 230 220 396 230 225 397 minecraft:green_terracotta
fill 230 220 398 230 221 399 minecraft:lime_terracotta
fill 230 220 405 230 225 405 minecraft:green_terracotta
fill 230 220 406 230 220 407 minecraft:lime_terracotta
fill 230 220 408 230 221 409 minecraft:green_terracotta
fill 230 220 410 230 221 410 minecraft:lime_terracotta
setblock 188 221 373 minecraft:lime_terracotta
fill 188 221 377 188 224 378 minecraft:green_terracotta
setblock 188 221 394 minecraft:lime_terracotta
setblock 188 221 397 minecraft:lime_terracotta
fill 188 221 398 188 224 398 minecraft:green_terracotta
setblock 188 221 405 minecraft:lime_terracotta
fill 188 221 409 188 224 409 minecraft:green_terracotta
fill 195 221 369 195 224 369 minecraft:green_terracotta
setblock 196 221 369 minecraft:lime_terracotta
setblock 199 221 369 minecraft:lime_terracotta
fill 202 221 411 203 221 411 minecraft:lime_terracotta
setblock 206 221 411 minecraft:lime_terracotta
fill 207 221 411 207 224 411 minecraft:green_terracotta
fill 215 221 369 216 224 369 minecraft:green_terracotta
fill 218 221 411 218 223 411 minecraft:green_terracotta
setblock 220 221 369 minecraft:lime_terracotta
setblock 223 221 411 minecraft:lime_terracotta
setblock 230 221 370 minecraft:lime_terracotta
fill 230 221 375 230 224 375 minecraft:green_terracotta
fill 230 221 386 230 224 386 minecraft:green_terracotta
setblock 230 221 387 minecraft:lime_terracotta
fill 230 221 390 230 221 391 minecraft:lime_terracotta
fill 230 221 406 230 223 407 minecraft:green_terracotta
fill 188 222 371 188 223 372 minecraft:lime_terracotta
fill 188 222 373 188 227 374 minecraft:green_terracotta
setblock 188 222 375 minecraft:lime_terracotta
fill 188 222 376 188 225 376 minecraft:green_terracotta
fill 188 222 383 188 223 384 minecraft:lime_terracotta
fill 188 222 385 188 227 386 minecraft:green_terracotta
fill 188 222 392 188 223 392 minecraft:lime_terracotta
fill 188 222 394 188 227 394 minecraft:green_terracotta
fill 188 222 395 188 222 396 minecraft:lime_terracotta
fill 188 222 397 188 227 397 minecraft:green_terracotta
fill 188 222 403 188 223 404 minecraft:lime_terracotta
fill 188 222 405 188 227 406 minecraft:green_terracotta
fill 189 222 369 190 223 369 minecraft:lime_terracotta
fill 189 222 370 191 222 370 minecraft:mud
fill 189 222 372 189 222 374 minecraft:mud
fill 189 222 376 189 222 378 minecraft:mud
fill 189 222 380 189 222 382 minecraft:mud
fill 189 222 384 189 222 386 minecraft:mud
fill 189 222 388 189 222 390 minecraft:mud
fill 189 222 392 189 222 394 minecraft:mud
fill 189 222 396 189 222 398 minecraft:mud
fill 189 222 400 189 222 402 minecraft:mud
fill 189 222 404 189 222 406 minecraft:mud
fill 189 222 408 189 222 410 minecraft:mud
fill 191 222 410 193 222 410 minecraft:mud
fill 192 222 411 193 222 411 minecraft:lime_terracotta
fill 193 222 370 195 222 370 minecraft:mud
fill 194 222 411 195 227 411 minecraft:green_terracotta
fill 195 222 410 197 222 410 minecraft:mud
fill 196 222 369 196 227 369 minecraft:green_terracotta
fill 197 222 369 198 222 369 minecraft:lime_terracotta
fill 197 222 370 199 222 370 minecraft:mud
fill 199 222 369 199 227 369 minecraft:green_terracotta
fill 199 222 410 201 222 410 minecraft:mud
fill 201 222 369 201 223 369 minecraft:lime_terracotta
fill 201 222 370 203 222 370 minecraft:mud
fill 201 222 411 201 223 411 minecraft:lime_terracotta
fill 202 222 411 203 227 411 minecraft:green_terracotta
fill 203 222 410 205 222 410 minecraft:mud
setblock 204 222 411 minecraft:lime_terracotta
fill 205 222 370 207 222 370 minecraft:mud
fill 206 222 411 206 227 411 minecraft:green_terracotta
fill 207 222 369 208 227 369 minecraft:green_terracotta
fill 207 222 410 209 222 410 minecraft:mud
fill 209 222 369 210 223 369 minecraft:lime_terracotta
fill 209 222 370 211 222 370 minecraft:mud
fill 211 222 410 213 222 410 minecraft:mud
fill 212 222 411 213 223 411 minecraft:lime_terracotta
fill 213 222 370 215 222 370 minecraft:mud
fill 214 222 411 215 227 411 minecraft:green_terracotta
fill 215 222 403 217 261 405 minecraft:mud
fill 215 222 410 217 222 410 minecraft:mud
fill 217 222 369 217 225 369 minecraft:green_terracotta
fill 217 222 370 219 222 370 minecraft:mud
setblock 218 222 369 minecraft:lime_terracotta
fill 218 222 404 218 261 404 minecraft:mud
fill 219 222 369 220 227 369 minecraft:green_terracotta
fill 219 222 410 221 222 410 minecraft:mud
setblock 220 222 411 minecraft:green_terracotta
fill 221 222 369 222 223 369 minecraft:lime_terracotta
fill 221 222 370 223 222 370 minecraft:mud
fill 221 222 411 221 223 411 minecraft:lime_terracotta
fill 223 222 410 225 222 410 minecraft:mud
fill 223 222 411 223 227 411 minecraft:green_terracotta
fill 224 222 411 225 222 411 minecraft:lime_terracotta
fill 225 222 370 227 222 370 minecraft:mud
fill 226 222 411 227 224 411 minecraft:green_terracotta
fill 227 222 369 228 227 369 minecraft:green_terracotta
fill 227 222 410 229 222 410 minecraft:mud
fill 229 222 369 230 222 369 minecraft:lime_terracotta
fill 229 222 370 229 222 372 minecraft:mud
fill 229 222 374 229 222 376 minecraft:mud
fill 229 222 378 229 222 380 minecraft:mud
fill 229 222 382 229 222 384 minecraft:mud
fill 229 222 386 229 222 388 minecraft:mud
fill 229 222 390 229 222 392 minecraft:mud
fill 229 222 394 229 222 396 minecraft:mud
fill 229 222 398 229 222 400 minecraft:mud
fill 229 222 402 229 222 404 minecraft:mud
fill 229 222 406 229 222 408 minecraft:mud
fill 230 222 370 230 227 370 minecraft:green_terracotta
fill 230 222 378 230 227 379 minecraft:green_terracotta
fill 230 222 380 230 223 381 minecraft:lime_terracotta
fill 230 222 387 230 227 387 minecraft:green_terracotta
setblock 230 222 389 minecraft:lime_terracotta
fill 230 222 390 230 227 391 minecraft:green_terracotta
fill 230 222 392 230 223 392 minecraft:lime_terracotta
fill 230 222 398 230 227 399 minecraft:green_terracotta
fill 230 222 400 230 223 401 minecraft:lime_terracotta
fill 230 222 408 230 225 408 minecraft:green_terracotta
setblock 230 222 409 minecraft:lime_terracotta
fill 230 222 410 230 227 410 minecraft:green_terracotta
fill 188 223 375 188 226 375 minecraft:green_terracotta
setblock 188 223 380 minecraft:lime_terracotta
setblock 188 223 391 minecraft:lime_terracotta
fill 188 223 395 188 226 396 minecraft:green_terracotta
setblock 189 223 411 minecraft:lime_terracotta
setblock 191 223 372 minecraft:light[level=14]
setblock 191 223 380 minecraft:light[level=14]
setblock 191 223 388 minecraft:light[level=14]
setblock 191 223 396 minecraft:light[level=14]
setblock 191 223 404 minecraft:light[level=14]
setblock 192 223 411 minecraft:lime_terracotta
fill 193 223 411 193 226 411 minecraft:green_terracotta
fill 194 223 397 195 224 398 minecraft:lime_concrete
fill 197 223 369 198 226 369 minecraft:green_terracotta
setblock 199 223 372 minecraft:light[level=14]
setblock 199 223 380 minecraft:light[level=14]
setblock 199 223 388 minecraft:light[level=14]
setblock 199 223 396 minecraft:light[level=14]
setblock 199 223 404 minecraft:light[level=14]
setblock 200 223 411 minecraft:lime_terracotta
setblock 202 223 369 minecraft:lime_terracotta
fill 204 223 411 204 226 411 minecraft:green_terracotta
setblock 207 223 372 minecraft:light[level=14]
setblock 207 223 380 minecraft:light[level=14]
setblock 207 223 388 minecraft:light[level=14]
setblock 207 223 396 minecraft:light[level=14]
setblock 207 223 404 minecraft:light[level=14]
setblock 213 223 369 minecraft:lime_terracotta
fill 214 223 403 214 224 404 minecraft:mud
setblock 215 223 372 minecraft:light[level=14]
setblock 215 223 380 minecraft:light[level=14]
setblock 215 223 388 minecraft:light[level=14]
setblock 215 223 396 minecraft:light[level=14]
fill 215 223 402 218 224 402 minecraft:mud
fill 215 223 406 218 224 406 minecraft:mud
fill 218 223 369 218 226 369 minecraft:green_terracotta
fill 218 223 403 218 224 403 minecraft:mud
fill 218 223 405 218 224 405 minecraft:mud
setblock 220 223 411 minecraft:lime_terracotta
setblock 223 223 372 minecraft:light[level=14]
setblock 223 223 380 minecraft:light[level=14]
setblock 223 223 388 minecraft:light[level=14]
setblock 223 223 396 minecraft:light[level=14]
setblock 223 223 404 minecraft:light[level=14]
setblock 224 223 411 minecraft:lime_terracotta
fill 225 223 411 225 226 411 minecraft:green_terracotta
fill 229 223 369 229 226 369 minecraft:green_terracotta
setblock 230 223 369 minecraft:lime_terracotta
fill 230 223 372 230 223 373 minecraft:lime_terracotta
fill 230 223 389 230 226 389 minecraft:green_terracotta
setblock 230 223 393 minecraft:lime_terracotta
setblock 230 223 404 minecraft:lime_terracotta
fill 230 223 409 230 225 409 minecraft:green_terracotta
fill 188 224 369 188 225 370 minecraft:lime_terracotta
fill 188 224 371 188 229 372 minecraft:green_terracotta
fill 188 224 380 188 229 380 minecraft:green_terracotta
fill 188 224 381 188 224 382 minecraft:lime_terracotta
fill 188 224 383 188 229 384 minecraft:green_terracotta
fill 188 224 389 188 225 390 minecraft:lime_terracotta
fill 188 224 391 188 229 392 minecraft:green_terracotta
setblock 188 224 393 minecraft:lime_terracotta
fill 188 224 401 188 225 402 minecraft:lime_terracotta
fill 188 224 403 188 229 404 minecraft:green_terracotta
fill 188 224 410 188 225 410 minecraft:lime_terracotta
fill 189 224 369 190 229 369 minecraft:green_terracotta
fill 189 224 411 189 229 411 minecraft:green_terracotta
fill 190 224 411 191 224 411 minecraft:lime_terracotta
fill 191 224 369 192 225 369 minecraft:lime_terracotta
fill 192 224 411 192 229 411 minecraft:green_terracotta
fill 198 224 411 199 225 411 minecraft:lime_terracotta
setblock 200 224 369 minecraft:lime_terracotta
fill 200 224 411 201 229 411 minecraft:green_terracotta
fill 201 224 369 202 229 369 minecraft:green_terracotta
fill 203 224 369 204 225 369 minecraft:lime_terracotta
fill 209 224 369 210 229 369 minecraft:green_terracotta
fill 210 224 411 211 224 411 minecraft:lime_terracotta
fill 211 224 369 212 224 369 minecraft:lime_terracotta
fill 212 224 411 213 229 411 minecraft:green_terracotta
fill 213 224 369 213 229 369 minecraft:green_terracotta
setblock 214 224 402 minecraft:mud
fill 214 224 405 214 224 406 minecraft:mud
fill 215 224 401 217 224 401 minecraft:mud
fill 215 224 407 217 224 407 minecraft:mud
fill 218 224 411 219 225 411 minecraft:lime_terracotta
fill 219 224 402 219 224 406 minecraft:mud
fill 220 224 411 221 229 411 minecraft:green_terracotta
fill 221 224 369 222 229 369 minecraft:green_terracotta
setblock 222 224 411 minecraft:lime_terracotta
fill 223 224 369 224 225 369 minecraft:lime_terracotta
fill 224 224 411 224 226 411 minecraft:green_terracotta
fill 230 224 369 230 229 369 minecraft:green_terracotta
setblock 230 224 371 minecraft:lime_terracotta
fill 230 224 372 230 229 373 minecraft:green_terracotta
fill 230 224 374 230 225 374 minecraft:lime_terracotta
fill 230 224 380 230 229 381 minecraft:green_terracotta
fill 230 224 382 230 224 383 minecraft:lime_terracotta
fill 230 224 392 230 229 393 minecraft:green_terracotta
fill 230 224 394 230 225 395 minecraft:lime_terracotta
fill 230 224 400 230 226 401 minecraft:green_terracotta
fill 230 224 402 230 224 403 minecraft:lime_terracotta
fill 230 224 404 230 229 404 minecraft:green_terracotta
fill 230 224 406 230 225 406 minecraft:lime_terracotta
setblock 230 224 407 minecraft:green_terracotta
fill 230 224 411 230 225 411 minecraft:lime_terracotta
fill 188 225 377 188 225 378 minecraft:lime_terracotta
setblock 188 225 381 minecraft:lime_terracotta
fill 188 225 382 188 228 382 minecraft:green_terracotta
fill 188 225 393 188 228 393 minecraft:green_terracotta
setblock 188 225 398 minecraft:lime_terracotta
setblock 188 225 409 minecraft:lime_terracotta
fill 190 225 411 191 228 411 minecraft:green_terracotta
setblock 195 225 369 minecraft:lime_terracotta
fill 200 225 369 200 228 369 minecraft:green_terracotta
setblock 207 225 411 minecraft:lime_terracotta
setblock 210 225 411 minecraft:lime_terracotta
fill 211 225 369 211 228 369 minecraft:green_terracotta
fill 211 225 411 211 228 411 minecraft:green_terracotta
setblock 212 225 369 minecraft:lime_terracotta
fill 215 225 369 216 225 369 minecraft:lime_terracotta
fill 222 225 411 222 228 411 minecraft:green_terracotta
fill 226 225 411 226 227 411 minecraft:green_terracotta
setblock 227 225 411 minecraft:lime_terracotta
fill 230 225 371 230 228 371 minecraft:green_terracotta
setblock 230 225 375 minecraft:lime_terracotta
fill 230 225 382 230 228 382 minecraft:green_terracotta
setblock 230 225 383 minecraft:lime_terracotta
setblock 230 225 386 minecraft:lime_terracotta
fill 230 225 402 230 228 402 minecraft:green_terracotta
setblock 230 225 403 minecraft:lime_terracotta
setblock 230 225 407 minecraft:lime_terracotta
fill 188 226 369 188 231 370 minecraft:green_terracotta
fill 188 226 376 188 227 376 minecraft:lime_terracotta
fill 188 226 377 188 231 378 minecraft:green_terracotta
setblock 188 226 379 minecraft:lime_terracotta
fill 188 226 381 188 231 381 minecraft:green_terracotta
fill 188 226 387 188 227 388 minecraft:lime_terracotta
fill 188 226 389 188 231 390 minecraft:green_terracotta
fill 188 226 398 188 231 398 minecraft:green_terracotta
fill 188 226 399 188 226 400 minecraft:lime_terracotta
fill 188 226 401 188 231 402 minecraft:green_terracotta
fill 188 226 407 188 227 408 minecraft:lime_terracotta
fill 188 226 409 188 231 410 minecraft:green_terracotta
setblock 188 226 411 minecraft:lime_terracotta
fill 191 226 369 192 231 369 minecraft:green_terracotta
fill 193 226 369 194 226 369 minecraft:lime_terracotta
fill 195 226 369 195 231 369 minecraft:green_terracotta
fill 196 226 411 197 227 411 minecraft:lime_terracotta
fill 198 226 411 199 231 411 minecraft:green_terracotta
fill 203 226 369 204 231 369 minecraft:green_terracotta
fill 205 226 369 206 227 369 minecraft:lime_terracotta
fill 205 226 411 205 227 411 minecraft:lime_terracotta
fill 207 226 411 207 231 411 minecraft:green_terracotta
fill 208 226 411 209 226 411 minecraft:lime_terracotta
fill 210 226 411 210 231 411 minecraft:green_terracotta
fill 212 226 369 212 231 369 minecraft:green_terracotta
setblock 214 226 369 minecraft:lime_terracotta
fill 215 226 369 216 231 369 minecraft:green_terracotta
fill 216 226 411 217 227 411 minecraft:lime_terracotta
fill 217 226 369 217 227 369 minecraft:lime_terracotta
fill 218 226 411 219 231 411 minecraft:green_terracotta
fill 223 226 369 224 231 369 minecraft:green_terracotta
fill 225 226 369 226 226 369 minecraft:lime_terracotta
fill 227 226 411 227 227 411 minecraft:green_terracotta
fill 228 226 411 229 226 411 minecraft:lime_terracotta
fill 230 226 374 230 231 375 minecraft:green_terracotta
fill 230 226 376 230 227 377 minecraft:lime_terracotta
fill 230 226 383 230 231 383 minecraft:green_terracotta
fill 230 226 384 230 226 385 minecraft:lime_terracotta
fill 230 226 386 230 231 386 minecraft:green_terracotta
fill 230 226 388 230 227 388 minecraft:lime_terracotta
fill 230 226 394 230 231 395 minecraft:green_terracotta
fill 230 226 396 230 227 397 minecraft:lime_terracotta
fill 230 226 403 230 228 403 minecraft:green_terracotta
setblock 230 226 405 minecraft:lime_terracotta
fill 230 226 406 230 231 407 minecraft:green_terracotta
fill 230 226 408 230 227 409 minecraft:lime_terracotta
fill 230 226 411 230 231 411 minecraft:green_terracotta
setblock 188 227 375 minecraft:lime_terracotta
fill 188 227 379 188 230 379 minecraft:green_terracotta
fill 188 227 395 188 227 396 minecraft:lime_terracotta
setblock 188 227 399 minecraft:lime_terracotta
fill 188 227 400 188 230 400 minecraft:green_terracotta
fill 188 227 411 188 230 411 minecraft:green_terracotta
fill 193 227 369 193 230 369 minecraft:green_terracotta
setblock 193 227 411 minecraft:lime_terracotta
setblock 194 227 369 minecraft:lime_terracotta
fill 197 227 369 198 227 369 minecraft:lime_terracotta
setblock 204 227 411 minecraft:lime_terracotta
fill 208 227 411 209 229 411 minecraft:green_terracotta
fill 214 227 369 214 230 369 minecraft:green_terracotta
fill 217 227 385 218 228 386 minecraft:moss_block
setblock 218 227 369 minecraft:lime_terracotta
fill 224 227 411 225 227 411 minecraft:lime_terracotta
fill 225 227 369 225 230 369 minecraft:green_terracotta
setblock 226 227 369 minecraft:lime_terracotta
setblock 228 227 411 minecraft:lime_terracotta
setblock 229 227 369 minecraft:lime_terracotta
fill 229 227 411 229 230 411 minecraft:green_terracotta
fill 230 227 384 230 230 385 minecraft:green_terracotta
setblock 230 227 389 minecraft:lime_terracotta
setblock 230 227 400 minecraft:lime_terracotta
fill 230 227 401 230 229 401 minecraft:green_terracotta
fill 230 227 405 230 230 405 minecraft:green_terracotta
fill 188 228 373 188 229 374 minecraft:lime_terracotta
fill 188 228 375 188 233 376 minecraft:green_terracotta
fill 188 228 385 188 228 386 minecraft:lime_terracotta
fill 188 228 387 188 233 388 minecraft:green_terracotta
fill 188 228 394 188 229 394 minecraft:lime_terracotta
fill 188 228 395 188 233 396 minecraft:green_terracotta
setblock 188 228 397 minecraft:lime_terracotta
fill 188 228 399 188 233 399 minecraft:green_terracotta
fill 188 228 405 188 229 406 minecraft:lime_terracotta
fill 188 228 407 188 233 408 minecraft:green_terracotta
fill 189 228 370 191 228 370 minecraft:mud
fill 189 228 372 189 228 374 minecraft:mud
fill 189 228 376 189 228 378 minecraft:mud
fill 189 228 380 189 228 382 minecraft:mud
fill 189 228 384 189 228 386 minecraft:mud
fill 189 228 388 189 228 390 minecraft:mud
fill 189 228 392 189 228 394 minecraft:mud
fill 189 228 396 189 228 398 minecraft:mud
fill 189 228 400 189 228 402 minecraft:mud
fill 189 228 404 189 228 406 minecraft:mud
fill 189 228 408 189 228 410 minecraft:mud
fill 191 228 410 193 228 410 minecraft:mud
fill 193 228 370 195 228 370 minecraft:mud
fill 193 228 411 193 233 411 minecraft:green_terracotta
fill 194 228 369 194 233 369 minecraft:green_terracotta
fill 194 228 411 195 228 411 minecraft:lime_terracotta
fill 195 228 410 197 228 410 minecraft:mud
setblock 196 228 369 minecraft:lime_terracotta
fill 196 228 411 197 233 411 minecraft:green_terracotta
fill 197 228 369 198 233 369 minecraft:green_terracotta
fill 197 228 370 199 228 370 minecraft:mud
fill 199 228 369 199 229 369 minecraft:lime_terracotta
fill 199 228 410 201 228 410 minecraft:mud
fill 201 228 370 203 228 370 minecraft:mud
fill 202 228 411 203 229 411 minecraft:lime_terracotta
fill 203 228 410 205 228 410 minecraft:mud
fill 204 228 411 205 233 411 minecraft:green_terracotta
fill 205 228 369 206 233 369 minecraft:green_terracotta
fill 205 228 370 207 228 370 minecraft:mud
setblock 206 228 411 minecraft:lime_terracotta
fill 207 228 369 208 228 369 minecraft:lime_terracotta
fill 207 228 410 209 228 410 minecraft:mud
fill 209 228 370 211 228 370 minecraft:mud
fill 211 228 410 213 228 410 minecraft:mud
fill 213 228 370 215 228 370 minecraft:mud
fill 214 228 411 215 229 411 minecraft:lime_terracotta
fill 215 228 410 217 228 410 minecraft:mud
fill 216 228 411 217 233 411 minecraft:green_terracotta
fill 217 228 369 218 233 369 minecraft:green_terracotta
fill 217 228 370 219 228 370 minecraft:mud
fill 219 228 369 220 229 369 minecraft:lime_terracotta
fill 219 228 410 221 228 410 minecraft:mud
fill 221 228 370 223 228 370 minecraft:mud
fill 223 228 410 225 228 410 minecraft:mud
fill 223 228 411 223 229 411 minecraft:lime_terracotta
fill 224 228 411 225 229 411 minecraft:green_terracotta
fill 225 228 370 227 228 370 minecraft:mud
fill 226 228 369 226 233 369 minecraft:green_terracotta
fill 226 228 411 227 228 411 minecraft:lime_terracotta
fill 227 228 369 228 228 369 minecraft:lime_terracotta
fill 227 228 410 229 228 410 minecraft:mud
fill 228 228 411 228 233 411 minecraft:green_terracotta
fill 229 228 369 229 233 369 minecraft:green_terracotta
fill 229 228 370 229 228 372 minecraft:mud
fill 229 228 374 229 228 376 minecraft:mud
fill 229 228 378 229 228 380 minecraft:mud
fill 229 228 382 229 228 384 minecraft:mud
fill 229 228 386 229 228 388 minecraft:mud
fill 229 228 390 229 228 392 minecraft:mud
fill 229 228 394 229 228 396 minecraft:mud
fill 229 228 398 229 228 400 minecraft:mud
fill 229 228 402 229 228 404 minecraft:mud
fill 229 228 406 229 228 408 minecraft:mud
fill 230 228 370 230 229 370 minecraft:lime_terracotta
fill 230 228 376 230 233 377 minecraft:green_terracotta
fill 230 228 378 230 229 379 minecraft:lime_terracotta
setblock 230 228 387 minecraft:lime_terracotta
fill 230 228 388 230 233 389 minecraft:green_terracotta
fill 230 228 390 230 229 391 minecraft:lime_terracotta
fill 230 228 396 230 233 397 minecraft:green_terracotta
fill 230 228 398 230 228 399 minecraft:lime_terracotta
fill 230 228 400 230 233 400 minecraft:green_terracotta
fill 230 228 408 230 233 409 minecraft:green_terracotta
fill 230 228 410 230 229 410 minecraft:lime_terracotta
setblock 188 229 382 minecraft:lime_terracotta
setblock 188 229 385 minecraft:lime_terracotta
fill 188 229 386 188 232 386 minecraft:green_terracotta
setblock 188 229 393 minecraft:lime_terracotta
fill 188 229 397 188 232 397 minecraft:green_terracotta
fill 190 229 411 191 229 411 minecraft:lime_terracotta
setblock 194 229 411 minecraft:lime_terracotta
fill 195 229 411 195 232 411 minecraft:green_terracotta
fill 196 229 369 196 232 369 minecraft:green_terracotta
setblock 200 229 369 minecraft:lime_terracotta
fill 206 229 411 206 231 411 minecraft:green_terracotta
fill 207 229 369 207 232 369 minecraft:green_terracotta
setblock 208 229 369 minecraft:lime_terracotta
setblock 211 229 369 minecraft:lime_terracotta
setblock 211 229 411 minecraft:lime_terracotta
setblock 222 229 411 minecraft:lime_terracotta
fill 226 229 411 227 231 411 minecraft:green_terracotta
fill 227 229 369 228 232 369 minecraft:green_terracotta
setblock 230 229 371 minecraft:lime_terracotta
setblock 230 229 382 minecraft:lime_terracotta
fill 230 229 387 230 232 387 minecraft:green_terracotta
fill 230 229 398 230 232 398 minecraft:green_terracotta
setblock 230 229 399 minecraft:lime_terracotta
fill 230 229 402 230 229 403 minecraft:lime_terracotta
fill 188 230 371 188 231 372 minecraft:lime_terracotta
fill 188 230 373 188 235 374 minecraft:green_terracotta
fill 188 230 380 188 231 380 minecraft:lime_terracotta
fill 188 230 382 188 235 382 minecraft:green_terracotta
fill 188 230 383 188 230 384 minecraft:lime_terracotta
fill 188 230 385 188 235 385 minecraft:green_terracotta
fill 188 230 391 188 231 392 minecraft:lime_terracotta
fill 188 230 393 188 235 394 minecraft:green_terracotta
fill 188 230 403 188 230 404 minecraft:lime_terracotta
fill 188 230 405 188 235 406 minecraft:green_terracotta
fill 189 230 369 190 230 369 minecraft:lime_terracotta
fill 189 230 411 189 231 411 minecraft:lime_terracotta
fill 190 230 411 191 235 411 minecraft:green_terracotta
setblock 192 230 411 minecraft:lime_terracotta
fill 194 230 411 194 235 411 minecraft:green_terracotta
fill 199 230 369 200 235 369 minecraft:green_terracotta
fill 200 230 411 201 231 411 minecraft:lime_terracotta
fill 201 230 369 202 231 369 minecraft:lime_terracotta
fill 202 230 411 203 235 411 minecraft:green_terracotta
fill 208 230 369 208 235 369 minecraft:green_terracotta
setblock 208 230 411 minecraft:green_terracotta
fill 209 230 369 210 230 369 minecraft:lime_terracotta
fill 209 230 411 209 231 411 minecraft:lime_terracotta
fill 211 230 369 211 235 369 minecraft:green_terracotta
fill 211 230 411 211 235 411 minecraft:green_terracotta
fill 212 230 411 213 230 411 minecraft:lime_terracotta
fill 213 230 369 213 231 369 minecraft:lime_terracotta
fill 214 230 411 215 232 411 minecraft:green_terracotta
fill 219 230 369 220 235 369 minecraft:green_terracotta
fill 220 230 411 221 231 411 minecraft:lime_terracotta
fill 221 230 369 222 231 369 minecraft:lime_terracotta
fill 222 230 411 223 235 411 minecraft:green_terracotta
setblock 224 230 411 minecraft:lime_terracotta
fill 225 230 411 225 233 411 minecraft:green_terracotta
setblock 230 230 369 minecraft:lime_terracotta
fill 230 230 370 230 235 371 minecraft:green_terracotta
fill 230 230 372 230 231 373 minecraft:lime_terracotta
fill 230 230 378 230 235 379 minecraft:green_terracotta
fill 230 230 380 230 230 381 minecraft:lime_terracotta
fill 230 230 382 230 235 382 minecraft:green_terracotta
fill 230 230 390 230 235 391 minecraft:green_terracotta
fill 230 230 392 230 231 393 minecraft:lime_terracotta
fill 230 230 399 230 235 399 minecraft:green_terracotta
setblock 230 230 401 minecraft:lime_terracotta
fill 230 230 402 230 235 403 minecraft:green_terracotta
fill 230 230 404 230 231 404 minecraft:lime_terracotta
fill 230 230 410 230 235 410 minecraft:green_terracotta
setblock 188 231 379 minecraft:lime_terracotta
fill 188 231 383 188 234 384 minecraft:green_terracotta
setblock 188 231 400 minecraft:lime_terracotta
setblock 188 231 403 minecraft:lime_terracotta
fill 188 231 404 188 234 404 minecraft:green_terracotta
setblock 188 231 411 minecraft:lime_terracotta
fill 189 231 369 189 234 369 minecraft:green_terracotta
setblock 190 231 369 minecraft:lime_terracotta
setblock 191 231 372 minecraft:light[level=14]
setblock 191 231 380 minecraft:light[level=14]
setblock 191 231 388 minecraft:light[level=14]
setblock 191 231 396 minecraft:light[level=14]
setblock 191 231 404 minecraft:light[level=14]
fill 192 231 411 192 234 411 minecraft:green_terracotta
setblock 193 231 369 minecraft:lime_terracotta
setblock 199 231 372 minecraft:light[level=14]
setblock 199 231 380 minecraft:light[level=14]
setblock 199 231 388 minecraft:light[level=14]
setblock 199 231 396 minecraft:light[level=14]
setblock 199 231 404 minecraft:light[level=14]
fill 203 231 380 203 233 380 minecraft:verdant_froglight
setblock 207 231 372 minecraft:light[level=14]
setblock 207 231 380 minecraft:light[level=14]
setblock 207 231 388 minecraft:light[level=14]
setblock 207 231 396 minecraft:light[level=14]
setblock 207 231 404 minecraft:light[level=14]
setblock 208 231 411 minecraft:lime_terracotta
fill 209 231 369 210 234 369 minecraft:green_terracotta
setblock 212 231 411 minecraft:lime_terracotta
fill 213 231 411 213 234 411 minecraft:green_terracotta
setblock 214 231 369 minecraft:lime_terracotta
setblock 215 231 372 minecraft:light[level=14]
setblock 215 231 380 minecraft:light[level=14]
setblock 215 231 388 minecraft:light[level=14]
setblock 215 231 396 minecraft:light[level=14]
setblock 223 231 372 minecraft:light[level=14]
setblock 223 231 380 minecraft:light[level=14]
setblock 223 231 388 minecraft:light[level=14]
setblock 223 231 396 minecraft:light[level=14]
setblock 223 231 404 minecraft:light[level=14]
fill 224 231 411 224 233 411 minecraft:green_terracotta
setblock 225 231 369 minecraft:lime_terracotta
setblock 229 231 411 minecraft:lime_terracotta
fill 230 231 369 230 234 369 minecraft:green_terracotta
fill 230 231 380 230 234 380 minecraft:green_terracotta
setblock 230 231 381 minecraft:lime_terracotta
fill 230 231 384 230 231 385 minecraft:lime_terracotta
fill 230 231 401 230 234 401 minecraft:green_terracotta
setblock 230 231 405 minecraft:lime_terracotta
fill 188 232 369 188 232 370 minecraft:lime_terracotta
fill 188 232 371 188 237 372 minecraft:green_terracotta
fill 188 232 377 188 233 378 minecraft:lime_terracotta
fill 188 232 379 188 237 380 minecraft:green_terracotta
setblock 188 232 381 minecraft:lime_terracotta
fill 188 232 389 188 233 390 minecraft:lime_terracotta
fill 188 232 391 188 237 392 minecraft:green_terracotta
fill 188 232 398 188 233 398 minecraft:lime_terracotta
fill 188 232 400 188 237 400 minecraft:green_terracotta
fill 188 232 401 188 232 402 minecraft:lime_terracotta
fill 188 232 403 188 237 403 minecraft:green_terracotta
fill 188 232 409 188 233 410 minecraft:lime_terracotta
fill 188 232 411 189 237 411 minecraft:green_terracotta
fill 190 232 369 190 237 369 minecraft:green_terracotta
fill 191 232 369 192 232 369 minecraft:lime_terracotta
fill 193 232 369 193 237 369 minecraft:green_terracotta
fill 195 232 369 195 233 369 minecraft:lime_terracotta
fill 198 232 411 199 232 411 minecraft:lime_terracotta
fill 200 232 411 201 237 411 minecraft:green_terracotta
fill 201 232 369 202 237 369 minecraft:green_terracotta
fill 203 232 369 204 233 369 minecraft:lime_terracotta
fill 206 232 411 207 233 411 minecraft:lime_terracotta
fill 208 232 411 209 237 411 minecraft:green_terracotta
setblock 210 232 411 minecraft:lime_terracotta
setblock 212 232 369 minecraft:lime_terracotta
fill 212 232 411 212 234 411 minecraft:green_terracotta
fill 213 232 369 214 237 369 minecraft:green_terracotta
fill 215 232 369 216 233 369 minecraft:lime_terracotta
fill 218 232 411 219 233 411 minecraft:lime_terracotta
fill 220 232 411 221 237 411 minecraft:green_terracotta
fill 221 232 369 222 237 369 minecraft:green_terracotta
fill 223 232 369 224 232 369 minecraft:lime_terracotta
fill 225 232 369 225 237 369 minecraft:green_terracotta
setblock 226 232 411 minecraft:green_terracotta
fill 227 232 411 227 233 411 minecraft:lime_terracotta
fill 229 232 411 229 237 411 minecraft:green_terracotta
fill 230 232 372 230 237 373 minecraft:green_terracotta
fill 230 232 374 230 233 375 minecraft:lime_terracotta
fill 230 232 381 230 237 381 minecraft:green_terracotta
setblock 230 232 383 minecraft:lime_terracotta
fill 230 232 384 230 237 385 minecraft:green_terracotta
fill 230 232 386 230 233 386 minecraft:lime_terracotta
fill 230 232 392 230 237 393 minecraft:green_terracotta
fill 230 232 394 230 232 395 minecraft:lime_terracotta
fill 230 232 404 230 237 405 minecraft:green_terracotta
fill 230 232 406 230 233 407 minecraft:lime_terracotta
fill 230 232 411 230 233 411 minecraft:lime_terracotta
setblock 188 233 369 minecraft:lime_terracotta
fill 188 233 370 188 236 370 minecraft:green_terracotta
fill 188 233 381 188 236 381 minecraft:green_terracotta
setblock 188 233 386 minecraft:lime_terracotta
setblock 188 233 397 minecraft:lime_terracotta
fill 188 233 401 188 236 402 minecraft:green_terracotta
fill 191 233 369 192 236 369 minecraft:green_terracotta
setblock 195 233 411 minecraft:lime_terracotta
setblock 196 233 369 minecraft:lime_terracotta
setblock 198 233 411 minecraft:lime_terracotta
fill 199 233 411 199 236 411 minecraft:green_terracotta
setblock 207 233 369 minecraft:lime_terracotta
fill 210 233 411 210 236 411 minecraft:green_terracotta
fill 212 233 369 212 236 369 minecraft:green_terracotta
fill 214 233 411 214 235 411 minecraft:green_terracotta
setblock 215 233 411 minecraft:lime_terracotta
fill 216 233 398 217 234 399 minecraft:lime_concrete
fill 223 233 369 223 236 369 minecraft:green_terracotta
setblock 224 233 369 minecraft:lime_terracotta
setblock 226 233 411 minecraft:lime_terracotta
fill 227 233 369 228 233 369 minecraft:lime_terracotta
fill 230 233 383 230 236 383 minecraft:green_terracotta
setblock 230 233 387 minecraft:lime_terracotta
fill 230 233 394 230 236 394 minecraft:green_terracotta
setblock 230 233 395 minecraft:lime_terracotta
setblock 230 233 398 minecraft:lime_terracotta
fill 188 234 369 188 239 369 minecraft:green_terracotta
fill 188 234 375 188 235 376 minecraft:lime_terracotta
fill 188 234 377 188 239 378 minecraft:green_terracotta
fill 188 234 386 188 239 386 minecraft:green_terracotta
fill 188 234 387 188 234 388 minecraft:lime_terracotta
fill 188 234 389 188 239 390 minecraft:green_terracotta
fill 188 234 395 188 235 396 minecraft:lime_terracotta
fill 188 234 397 188 239 398 minecraft:green_terracotta
setblock 188 234 399 minecraft:lime_terracotta
fill 188 234 407 188 235 408 minecraft:lime_terracotta
fill 188 234 409 188 239 410 minecraft:green_terracotta
fill 189 234 370 191 234 370 minecraft:mud
fill 189 234 372 189 234 374 minecraft:mud
fill 189 234 376 189 234 378 minecraft:mud
fill 189 234 380 189 234 382 minecraft:mud
fill 189 234 384 189 234 386 minecraft:mud
fill 189 234 388 189 234 390 minecraft:mud
fill 189 234 392 189 234 394 minecraft:mud
fill 189 234 396 189 234 398 minecraft:mud
fill 189 234 400 189 234 402 minecraft:mud
schedule function dropper:buildpart/88_5 1t
