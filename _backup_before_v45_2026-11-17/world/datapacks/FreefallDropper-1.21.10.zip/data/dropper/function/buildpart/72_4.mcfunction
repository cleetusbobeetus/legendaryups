setblock 28 118 346 minecraft:honeycomb_block
fill 29 118 336 29 118 338 minecraft:orange_stained_glass
fill 29 118 344 29 118 346 minecraft:orange_stained_glass
setblock 30 118 338 minecraft:orange_stained_glass
setblock 30 118 339 minecraft:honeycomb_block
fill 30 118 340 30 118 342 minecraft:orange_stained_glass
setblock 30 118 343 minecraft:honeycomb_block
setblock 30 118 344 minecraft:orange_stained_glass
setblock 31 118 341 minecraft:orange_stained_glass
setblock 9 119 364 minecraft:orange_terracotta
fill 17 119 338 17 120 344 minecraft:orange_stained_glass
fill 18 119 337 18 120 340 minecraft:orange_stained_glass
fill 18 119 342 18 120 345 minecraft:orange_stained_glass
fill 19 119 336 22 120 336 minecraft:orange_stained_glass
setblock 19 119 337 minecraft:honeycomb_block
setblock 19 119 345 minecraft:honeycomb_block
fill 19 119 346 22 120 346 minecraft:orange_stained_glass
fill 20 119 335 26 120 335 minecraft:orange_stained_glass
fill 20 119 347 26 120 347 minecraft:orange_stained_glass
fill 24 119 336 27 120 336 minecraft:orange_stained_glass
fill 24 119 346 27 120 346 minecraft:orange_stained_glass
setblock 27 119 337 minecraft:honeycomb_block
setblock 27 119 345 minecraft:honeycomb_block
fill 28 119 337 28 120 340 minecraft:orange_stained_glass
fill 28 119 342 28 120 345 minecraft:orange_stained_glass
fill 29 119 338 29 120 344 minecraft:orange_stained_glass
setblock 42 119 362 minecraft:yellow_concrete
fill 1 120 323 1 120 324 minecraft:orange_terracotta
setblock 1 120 325 minecraft:honeycomb_block
fill 1 120 326 1 120 328 minecraft:orange_terracotta
setblock 1 120 329 minecraft:honeycomb_block
fill 1 120 330 1 120 332 minecraft:orange_terracotta
setblock 1 120 333 minecraft:honeycomb_block
fill 1 120 334 1 120 336 minecraft:orange_terracotta
setblock 1 120 337 minecraft:honeycomb_block
fill 1 120 338 1 120 340 minecraft:orange_terracotta
setblock 1 120 341 minecraft:honeycomb_block
fill 1 120 342 1 120 344 minecraft:orange_terracotta
setblock 1 120 345 minecraft:honeycomb_block
fill 1 120 346 1 120 348 minecraft:orange_terracotta
setblock 1 120 349 minecraft:honeycomb_block
fill 1 120 350 1 120 352 minecraft:orange_terracotta
setblock 1 120 353 minecraft:honeycomb_block
fill 1 120 354 1 120 356 minecraft:orange_terracotta
setblock 1 120 357 minecraft:honeycomb_block
fill 1 120 358 1 120 360 minecraft:orange_terracotta
setblock 1 120 361 minecraft:honeycomb_block
fill 1 120 362 2 120 363 minecraft:orange_terracotta
setblock 2 120 323 minecraft:orange_terracotta
setblock 2 120 324 minecraft:honeycomb_block
fill 2 120 325 2 120 327 minecraft:orange_terracotta
setblock 2 120 328 minecraft:honeycomb_block
fill 2 120 329 2 120 331 minecraft:orange_terracotta
setblock 2 120 332 minecraft:honeycomb_block
fill 2 120 333 2 120 335 minecraft:orange_terracotta
setblock 2 120 336 minecraft:honeycomb_block
fill 2 120 337 2 120 339 minecraft:orange_terracotta
setblock 2 120 340 minecraft:honeycomb_block
fill 2 120 341 2 120 343 minecraft:orange_terracotta
setblock 2 120 344 minecraft:honeycomb_block
fill 2 120 345 2 120 347 minecraft:orange_terracotta
setblock 2 120 348 minecraft:honeycomb_block
fill 2 120 349 2 120 351 minecraft:orange_terracotta
setblock 2 120 352 minecraft:honeycomb_block
fill 2 120 353 2 120 355 minecraft:orange_terracotta
setblock 2 120 356 minecraft:honeycomb_block
fill 2 120 357 2 120 359 minecraft:orange_terracotta
setblock 2 120 360 minecraft:honeycomb_block
fill 2 120 361 4 120 361 minecraft:orange_terracotta
setblock 3 120 323 minecraft:honeycomb_block
fill 3 120 324 3 120 326 minecraft:orange_terracotta
setblock 3 120 327 minecraft:honeycomb_block
fill 3 120 328 3 120 330 minecraft:orange_terracotta
setblock 3 120 331 minecraft:honeycomb_block
fill 3 120 332 3 120 334 minecraft:orange_terracotta
setblock 3 120 335 minecraft:honeycomb_block
fill 3 120 336 3 120 338 minecraft:orange_terracotta
setblock 3 120 339 minecraft:honeycomb_block
fill 3 120 340 3 120 342 minecraft:orange_terracotta
setblock 3 120 343 minecraft:honeycomb_block
fill 3 120 344 3 120 346 minecraft:orange_terracotta
setblock 3 120 347 minecraft:honeycomb_block
fill 3 120 348 3 120 350 minecraft:orange_terracotta
setblock 3 120 351 minecraft:honeycomb_block
fill 3 120 352 3 120 354 minecraft:orange_terracotta
setblock 3 120 355 minecraft:honeycomb_block
fill 3 120 356 3 120 358 minecraft:orange_terracotta
setblock 3 120 359 minecraft:honeycomb_block
fill 3 120 360 5 120 360 minecraft:orange_terracotta
setblock 3 120 362 minecraft:orange_terracotta
setblock 3 120 363 minecraft:honeycomb_block
fill 4 120 323 4 120 325 minecraft:orange_terracotta
setblock 4 120 326 minecraft:honeycomb_block
fill 4 120 327 4 120 329 minecraft:orange_terracotta
setblock 4 120 330 minecraft:honeycomb_block
fill 4 120 331 4 120 333 minecraft:orange_terracotta
setblock 4 120 334 minecraft:honeycomb_block
fill 4 120 335 4 120 337 minecraft:orange_terracotta
setblock 4 120 338 minecraft:honeycomb_block
fill 4 120 339 4 120 341 minecraft:orange_terracotta
setblock 4 120 342 minecraft:honeycomb_block
fill 4 120 343 4 120 345 minecraft:orange_terracotta
setblock 4 120 346 minecraft:honeycomb_block
fill 4 120 347 4 120 349 minecraft:orange_terracotta
setblock 4 120 350 minecraft:honeycomb_block
fill 4 120 351 4 120 353 minecraft:orange_terracotta
setblock 4 120 354 minecraft:honeycomb_block
fill 4 120 355 4 120 357 minecraft:orange_terracotta
setblock 4 120 358 minecraft:honeycomb_block
fill 4 120 359 6 120 359 minecraft:orange_terracotta
setblock 4 120 362 minecraft:honeycomb_block
fill 4 120 363 6 120 363 minecraft:orange_terracotta
fill 5 120 323 5 120 324 minecraft:orange_terracotta
setblock 5 120 325 minecraft:honeycomb_block
fill 5 120 326 5 120 328 minecraft:orange_terracotta
setblock 5 120 329 minecraft:honeycomb_block
fill 5 120 330 5 120 332 minecraft:orange_terracotta
setblock 5 120 333 minecraft:honeycomb_block
fill 5 120 334 5 120 336 minecraft:orange_terracotta
setblock 5 120 337 minecraft:honeycomb_block
fill 5 120 338 5 120 340 minecraft:orange_terracotta
setblock 5 120 341 minecraft:honeycomb_block
fill 5 120 342 5 120 344 minecraft:orange_terracotta
setblock 5 120 345 minecraft:honeycomb_block
fill 5 120 346 5 120 348 minecraft:orange_terracotta
setblock 5 120 349 minecraft:honeycomb_block
fill 5 120 350 5 120 352 minecraft:orange_terracotta
setblock 5 120 353 minecraft:honeycomb_block
fill 5 120 354 5 120 356 minecraft:orange_terracotta
setblock 5 120 357 minecraft:honeycomb_block
fill 5 120 358 7 120 358 minecraft:orange_terracotta
setblock 5 120 361 minecraft:honeycomb_block
fill 5 120 362 7 120 362 minecraft:orange_terracotta
setblock 6 120 323 minecraft:orange_terracotta
setblock 6 120 324 minecraft:honeycomb_block
fill 6 120 325 6 120 327 minecraft:orange_terracotta
setblock 6 120 328 minecraft:honeycomb_block
fill 6 120 329 6 120 331 minecraft:orange_terracotta
setblock 6 120 332 minecraft:honeycomb_block
fill 6 120 333 6 120 335 minecraft:orange_terracotta
setblock 6 120 336 minecraft:honeycomb_block
fill 6 120 337 6 120 339 minecraft:orange_terracotta
setblock 6 120 340 minecraft:honeycomb_block
fill 6 120 341 6 120 343 minecraft:orange_terracotta
setblock 6 120 344 minecraft:honeycomb_block
fill 6 120 345 6 120 347 minecraft:orange_terracotta
setblock 6 120 348 minecraft:honeycomb_block
fill 6 120 349 6 120 351 minecraft:orange_terracotta
setblock 6 120 352 minecraft:honeycomb_block
fill 6 120 353 6 120 355 minecraft:orange_terracotta
setblock 6 120 356 minecraft:honeycomb_block
fill 6 120 357 8 120 357 minecraft:orange_terracotta
setblock 6 120 360 minecraft:honeycomb_block
fill 6 120 361 8 120 361 minecraft:orange_terracotta
setblock 7 120 323 minecraft:honeycomb_block
fill 7 120 324 7 120 326 minecraft:orange_terracotta
setblock 7 120 327 minecraft:honeycomb_block
fill 7 120 328 7 120 330 minecraft:orange_terracotta
setblock 7 120 331 minecraft:honeycomb_block
fill 7 120 332 7 120 334 minecraft:orange_terracotta
setblock 7 120 335 minecraft:honeycomb_block
fill 7 120 336 7 120 338 minecraft:orange_terracotta
setblock 7 120 339 minecraft:honeycomb_block
fill 7 120 340 7 120 342 minecraft:orange_terracotta
setblock 7 120 343 minecraft:honeycomb_block
fill 7 120 344 7 120 346 minecraft:orange_terracotta
setblock 7 120 347 minecraft:honeycomb_block
fill 7 120 348 7 120 350 minecraft:orange_terracotta
setblock 7 120 351 minecraft:honeycomb_block
fill 7 120 352 7 120 354 minecraft:orange_terracotta
setblock 7 120 355 minecraft:honeycomb_block
fill 7 120 356 9 120 356 minecraft:orange_terracotta
setblock 7 120 359 minecraft:honeycomb_block
fill 7 120 360 9 120 360 minecraft:orange_terracotta
setblock 7 120 363 minecraft:honeycomb_block
fill 8 120 323 8 120 325 minecraft:orange_terracotta
setblock 8 120 326 minecraft:honeycomb_block
fill 8 120 327 8 120 329 minecraft:orange_terracotta
setblock 8 120 330 minecraft:honeycomb_block
fill 8 120 331 8 120 333 minecraft:orange_terracotta
setblock 8 120 334 minecraft:honeycomb_block
fill 8 120 335 8 120 337 minecraft:orange_terracotta
setblock 8 120 338 minecraft:honeycomb_block
fill 8 120 339 8 120 341 minecraft:orange_terracotta
setblock 8 120 342 minecraft:honeycomb_block
fill 8 120 343 8 120 345 minecraft:orange_terracotta
setblock 8 120 346 minecraft:honeycomb_block
fill 8 120 347 8 120 349 minecraft:orange_terracotta
setblock 8 120 350 minecraft:honeycomb_block
fill 8 120 351 8 120 353 minecraft:orange_terracotta
setblock 8 120 354 minecraft:honeycomb_block
fill 8 120 355 10 120 355 minecraft:orange_terracotta
setblock 8 120 358 minecraft:honeycomb_block
fill 8 120 359 10 120 359 minecraft:orange_terracotta
setblock 8 120 362 minecraft:honeycomb_block
fill 8 120 363 10 120 363 minecraft:orange_terracotta
fill 9 120 323 9 120 324 minecraft:orange_terracotta
setblock 9 120 325 minecraft:honeycomb_block
fill 9 120 326 9 120 328 minecraft:orange_terracotta
setblock 9 120 329 minecraft:honeycomb_block
fill 9 120 330 9 120 332 minecraft:orange_terracotta
setblock 9 120 333 minecraft:honeycomb_block
fill 9 120 334 9 120 336 minecraft:orange_terracotta
setblock 9 120 337 minecraft:honeycomb_block
fill 9 120 338 9 120 340 minecraft:orange_terracotta
setblock 9 120 341 minecraft:honeycomb_block
fill 9 120 342 9 120 344 minecraft:orange_terracotta
setblock 9 120 345 minecraft:honeycomb_block
fill 9 120 346 9 120 348 minecraft:orange_terracotta
setblock 9 120 349 minecraft:honeycomb_block
fill 9 120 350 9 120 352 minecraft:orange_terracotta
setblock 9 120 353 minecraft:honeycomb_block
fill 9 120 354 11 120 354 minecraft:orange_terracotta
setblock 9 120 357 minecraft:honeycomb_block
fill 9 120 358 11 120 358 minecraft:orange_terracotta
setblock 9 120 361 minecraft:honeycomb_block
fill 9 120 362 11 120 362 minecraft:orange_terracotta
fill 9 120 364 9 308 364 minecraft:honeycomb_block
setblock 10 120 323 minecraft:orange_terracotta
setblock 10 120 324 minecraft:honeycomb_block
fill 10 120 325 10 120 327 minecraft:orange_terracotta
setblock 10 120 328 minecraft:honeycomb_block
fill 10 120 329 10 120 331 minecraft:orange_terracotta
setblock 10 120 332 minecraft:honeycomb_block
fill 10 120 333 10 120 335 minecraft:orange_terracotta
setblock 10 120 336 minecraft:honeycomb_block
fill 10 120 337 10 120 339 minecraft:orange_terracotta
setblock 10 120 340 minecraft:honeycomb_block
fill 10 120 341 10 120 343 minecraft:orange_terracotta
setblock 10 120 344 minecraft:honeycomb_block
fill 10 120 345 10 120 347 minecraft:orange_terracotta
setblock 10 120 348 minecraft:honeycomb_block
fill 10 120 349 10 120 351 minecraft:orange_terracotta
setblock 10 120 352 minecraft:honeycomb_block
fill 10 120 353 12 120 353 minecraft:orange_terracotta
setblock 10 120 356 minecraft:honeycomb_block
fill 10 120 357 12 120 357 minecraft:orange_terracotta
setblock 10 120 360 minecraft:honeycomb_block
fill 10 120 361 12 120 361 minecraft:orange_terracotta
setblock 11 120 323 minecraft:honeycomb_block
fill 11 120 324 11 120 326 minecraft:orange_terracotta
setblock 11 120 327 minecraft:honeycomb_block
fill 11 120 328 11 120 330 minecraft:orange_terracotta
setblock 11 120 331 minecraft:honeycomb_block
fill 11 120 332 11 120 334 minecraft:orange_terracotta
setblock 11 120 335 minecraft:honeycomb_block
fill 11 120 336 11 120 338 minecraft:orange_terracotta
setblock 11 120 339 minecraft:honeycomb_block
fill 11 120 340 11 120 342 minecraft:orange_terracotta
setblock 11 120 343 minecraft:honeycomb_block
fill 11 120 344 11 120 346 minecraft:orange_terracotta
setblock 11 120 347 minecraft:honeycomb_block
fill 11 120 348 11 120 350 minecraft:orange_terracotta
setblock 11 120 351 minecraft:honeycomb_block
fill 11 120 352 13 120 352 minecraft:orange_terracotta
setblock 11 120 355 minecraft:honeycomb_block
fill 11 120 356 13 120 356 minecraft:orange_terracotta
setblock 11 120 359 minecraft:honeycomb_block
fill 11 120 360 13 120 360 minecraft:orange_terracotta
setblock 11 120 363 minecraft:honeycomb_block
fill 12 120 323 12 120 325 minecraft:orange_terracotta
setblock 12 120 326 minecraft:honeycomb_block
fill 12 120 327 12 120 329 minecraft:orange_terracotta
setblock 12 120 330 minecraft:honeycomb_block
fill 12 120 331 12 120 333 minecraft:orange_terracotta
setblock 12 120 334 minecraft:honeycomb_block
fill 12 120 335 12 120 337 minecraft:orange_terracotta
setblock 12 120 338 minecraft:honeycomb_block
fill 12 120 339 12 120 341 minecraft:orange_terracotta
setblock 12 120 342 minecraft:honeycomb_block
fill 12 120 343 12 120 345 minecraft:orange_terracotta
setblock 12 120 346 minecraft:honeycomb_block
fill 12 120 347 12 120 349 minecraft:orange_terracotta
setblock 12 120 350 minecraft:honeycomb_block
fill 12 120 351 14 120 351 minecraft:orange_terracotta
setblock 12 120 354 minecraft:honeycomb_block
fill 12 120 355 14 120 355 minecraft:orange_terracotta
setblock 12 120 358 minecraft:honeycomb_block
fill 12 120 359 14 120 359 minecraft:orange_terracotta
setblock 12 120 362 minecraft:honeycomb_block
fill 12 120 363 14 120 363 minecraft:orange_terracotta
fill 13 120 323 13 120 324 minecraft:orange_terracotta
setblock 13 120 325 minecraft:honeycomb_block
fill 13 120 326 13 120 328 minecraft:orange_terracotta
setblock 13 120 329 minecraft:honeycomb_block
fill 13 120 330 13 120 332 minecraft:orange_terracotta
setblock 13 120 333 minecraft:honeycomb_block
fill 13 120 334 13 120 336 minecraft:orange_terracotta
setblock 13 120 337 minecraft:honeycomb_block
fill 13 120 338 13 120 340 minecraft:orange_terracotta
setblock 13 120 341 minecraft:honeycomb_block
fill 13 120 342 13 120 344 minecraft:orange_terracotta
setblock 13 120 345 minecraft:honeycomb_block
fill 13 120 346 13 120 348 minecraft:orange_terracotta
setblock 13 120 349 minecraft:honeycomb_block
fill 13 120 350 15 120 350 minecraft:orange_terracotta
setblock 13 120 353 minecraft:honeycomb_block
fill 13 120 354 15 120 354 minecraft:orange_terracotta
setblock 13 120 357 minecraft:honeycomb_block
fill 13 120 358 15 120 358 minecraft:orange_terracotta
setblock 13 120 361 minecraft:honeycomb_block
fill 13 120 362 15 120 362 minecraft:orange_terracotta
setblock 14 120 323 minecraft:orange_terracotta
setblock 14 120 324 minecraft:honeycomb_block
fill 14 120 325 14 120 327 minecraft:orange_terracotta
setblock 14 120 328 minecraft:honeycomb_block
fill 14 120 329 14 120 331 minecraft:orange_terracotta
setblock 14 120 332 minecraft:honeycomb_block
fill 14 120 333 14 120 335 minecraft:orange_terracotta
setblock 14 120 336 minecraft:honeycomb_block
fill 14 120 337 14 120 339 minecraft:orange_terracotta
setblock 14 120 340 minecraft:honeycomb_block
fill 14 120 341 14 120 343 minecraft:orange_terracotta
setblock 14 120 344 minecraft:honeycomb_block
fill 14 120 345 14 120 347 minecraft:orange_terracotta
setblock 14 120 348 minecraft:honeycomb_block
fill 14 120 349 16 120 349 minecraft:orange_terracotta
setblock 14 120 352 minecraft:honeycomb_block
fill 14 120 353 16 120 353 minecraft:orange_terracotta
setblock 14 120 356 minecraft:honeycomb_block
fill 14 120 357 16 120 357 minecraft:orange_terracotta
setblock 14 120 360 minecraft:honeycomb_block
fill 14 120 361 16 120 361 minecraft:orange_terracotta
setblock 15 120 323 minecraft:honeycomb_block
fill 15 120 324 15 120 326 minecraft:orange_terracotta
setblock 15 120 327 minecraft:honeycomb_block
fill 15 120 328 15 120 330 minecraft:orange_terracotta
setblock 15 120 331 minecraft:honeycomb_block
fill 15 120 332 15 120 334 minecraft:orange_terracotta
setblock 15 120 335 minecraft:honeycomb_block
fill 15 120 336 15 120 337 minecraft:orange_terracotta
fill 15 120 338 16 120 344 minecraft:orange_stained_glass
fill 15 120 345 15 120 346 minecraft:orange_terracotta
setblock 15 120 347 minecraft:honeycomb_block
fill 15 120 348 17 120 348 minecraft:orange_terracotta
setblock 15 120 351 minecraft:honeycomb_block
fill 15 120 352 17 120 352 minecraft:orange_terracotta
setblock 15 120 355 minecraft:honeycomb_block
fill 15 120 356 17 120 356 minecraft:orange_terracotta
setblock 15 120 359 minecraft:honeycomb_block
fill 15 120 360 17 120 360 minecraft:orange_terracotta
setblock 15 120 363 minecraft:honeycomb_block
fill 16 120 323 16 120 325 minecraft:orange_terracotta
setblock 16 120 326 minecraft:honeycomb_block
fill 16 120 327 16 120 329 minecraft:orange_terracotta
setblock 16 120 330 minecraft:honeycomb_block
fill 16 120 331 16 120 333 minecraft:orange_terracotta
setblock 16 120 334 minecraft:honeycomb_block
setblock 16 120 335 minecraft:orange_terracotta
fill 16 120 336 17 120 337 minecraft:orange_stained_glass
fill 16 120 345 17 120 346 minecraft:orange_stained_glass
setblock 16 120 347 minecraft:orange_terracotta
setblock 16 120 350 minecraft:honeycomb_block
fill 16 120 351 18 120 351 minecraft:orange_terracotta
setblock 16 120 354 minecraft:honeycomb_block
fill 16 120 355 18 120 355 minecraft:orange_terracotta
setblock 16 120 358 minecraft:honeycomb_block
fill 16 120 359 18 120 359 minecraft:orange_terracotta
setblock 16 120 362 minecraft:honeycomb_block
fill 16 120 363 18 120 363 minecraft:orange_terracotta
fill 17 120 323 17 120 324 minecraft:orange_terracotta
setblock 17 120 325 minecraft:honeycomb_block
fill 17 120 326 17 120 328 minecraft:orange_terracotta
setblock 17 120 329 minecraft:honeycomb_block
fill 17 120 330 17 120 332 minecraft:orange_terracotta
setblock 17 120 333 minecraft:honeycomb_block
setblock 17 120 334 minecraft:orange_terracotta
fill 17 120 335 19 120 335 minecraft:orange_stained_glass
fill 17 120 347 19 120 347 minecraft:orange_stained_glass
setblock 17 120 349 minecraft:honeycomb_block
fill 17 120 350 19 120 350 minecraft:orange_terracotta
setblock 17 120 353 minecraft:honeycomb_block
fill 17 120 354 19 120 354 minecraft:orange_terracotta
setblock 17 120 357 minecraft:honeycomb_block
fill 17 120 358 19 120 358 minecraft:orange_terracotta
setblock 17 120 361 minecraft:honeycomb_block
fill 17 120 362 19 120 362 minecraft:orange_terracotta
setblock 18 120 323 minecraft:orange_terracotta
setblock 18 120 324 minecraft:honeycomb_block
fill 18 120 325 18 120 327 minecraft:orange_terracotta
setblock 18 120 328 minecraft:honeycomb_block
fill 18 120 329 18 120 331 minecraft:orange_terracotta
setblock 18 120 332 minecraft:honeycomb_block
fill 18 120 333 19 120 333 minecraft:orange_terracotta
fill 18 120 334 28 120 334 minecraft:orange_stained_glass
setblock 18 120 336 minecraft:orange_stained_glass
fill 18 120 341 19 120 341 minecraft:orange_stained_glass
setblock 18 120 346 minecraft:orange_stained_glass
fill 18 120 348 28 120 348 minecraft:orange_stained_glass
fill 18 120 349 19 120 349 minecraft:orange_terracotta
setblock 18 120 352 minecraft:honeycomb_block
fill 18 120 353 20 120 353 minecraft:orange_terracotta
setblock 18 120 356 minecraft:honeycomb_block
fill 18 120 357 20 120 357 minecraft:orange_terracotta
setblock 18 120 360 minecraft:honeycomb_block
fill 18 120 361 20 120 361 minecraft:orange_terracotta
setblock 19 120 323 minecraft:honeycomb_block
fill 19 120 324 19 120 326 minecraft:orange_terracotta
setblock 19 120 327 minecraft:honeycomb_block
fill 19 120 328 19 120 330 minecraft:orange_terracotta
setblock 19 120 331 minecraft:honeycomb_block
fill 19 120 332 21 120 332 minecraft:orange_terracotta
fill 19 120 337 19 120 340 minecraft:orange_stained_glass
fill 19 120 342 19 120 345 minecraft:orange_stained_glass
setblock 19 120 351 minecraft:honeycomb_block
fill 19 120 352 21 120 352 minecraft:orange_terracotta
setblock 19 120 355 minecraft:honeycomb_block
fill 19 120 356 21 120 356 minecraft:orange_terracotta
setblock 19 120 359 minecraft:honeycomb_block
fill 19 120 360 21 120 360 minecraft:orange_terracotta
setblock 19 120 363 minecraft:honeycomb_block
fill 20 120 323 20 120 325 minecraft:orange_terracotta
setblock 20 120 326 minecraft:honeycomb_block
fill 20 120 327 20 120 329 minecraft:orange_terracotta
setblock 20 120 330 minecraft:honeycomb_block
fill 20 120 331 22 120 331 minecraft:orange_terracotta
fill 20 120 333 26 120 333 minecraft:orange_stained_glass
fill 20 120 337 20 120 338 minecraft:orange_stained_glass
fill 20 120 339 20 120 343 minecraft:ochre_froglight
fill 20 120 344 20 120 345 minecraft:orange_stained_glass
fill 20 120 349 26 120 349 minecraft:orange_stained_glass
setblock 20 120 350 minecraft:honeycomb_block
fill 20 120 351 22 120 351 minecraft:orange_terracotta
setblock 20 120 354 minecraft:honeycomb_block
fill 20 120 355 22 120 355 minecraft:orange_terracotta
setblock 20 120 358 minecraft:honeycomb_block
fill 20 120 359 22 120 359 minecraft:orange_terracotta
setblock 20 120 362 minecraft:honeycomb_block
fill 20 120 363 22 120 363 minecraft:orange_terracotta
fill 21 120 323 21 120 324 minecraft:orange_terracotta
setblock 21 120 325 minecraft:honeycomb_block
fill 21 120 326 21 120 328 minecraft:orange_terracotta
setblock 21 120 329 minecraft:honeycomb_block
fill 21 120 330 23 120 330 minecraft:orange_terracotta
fill 21 120 337 27 120 337 minecraft:orange_stained_glass
fill 21 120 338 21 120 339 minecraft:ochre_froglight
fill 21 120 343 21 120 344 minecraft:ochre_froglight
fill 21 120 345 27 120 345 minecraft:orange_stained_glass
fill 21 120 350 23 120 350 minecraft:orange_terracotta
setblock 21 120 353 minecraft:honeycomb_block
fill 21 120 354 23 120 354 minecraft:orange_terracotta
setblock 21 120 357 minecraft:honeycomb_block
fill 21 120 358 23 120 358 minecraft:orange_terracotta
setblock 21 120 361 minecraft:honeycomb_block
fill 21 120 362 23 120 362 minecraft:orange_terracotta
setblock 22 120 323 minecraft:orange_terracotta
setblock 22 120 324 minecraft:honeycomb_block
fill 22 120 325 22 120 327 minecraft:orange_terracotta
setblock 22 120 328 minecraft:honeycomb_block
fill 22 120 329 24 120 329 minecraft:orange_terracotta
setblock 22 120 332 minecraft:honeycomb_block
fill 22 120 338 25 120 338 minecraft:ochre_froglight
fill 22 120 344 25 120 344 minecraft:ochre_froglight
setblock 22 120 352 minecraft:honeycomb_block
fill 22 120 353 24 120 353 minecraft:orange_terracotta
setblock 22 120 356 minecraft:honeycomb_block
fill 22 120 357 24 120 357 minecraft:orange_terracotta
setblock 22 120 360 minecraft:honeycomb_block
fill 22 120 361 24 120 361 minecraft:orange_terracotta
setblock 23 120 323 minecraft:honeycomb_block
fill 23 120 324 23 120 326 minecraft:orange_terracotta
setblock 23 120 327 minecraft:honeycomb_block
fill 23 120 328 25 120 328 minecraft:orange_terracotta
setblock 23 120 331 minecraft:honeycomb_block
fill 23 120 332 25 120 332 minecraft:orange_terracotta
setblock 23 120 336 minecraft:orange_stained_glass
setblock 23 120 346 minecraft:orange_stained_glass
setblock 23 120 351 minecraft:honeycomb_block
fill 23 120 352 25 120 352 minecraft:orange_terracotta
setblock 23 120 355 minecraft:honeycomb_block
fill 23 120 356 25 120 356 minecraft:orange_terracotta
setblock 23 120 359 minecraft:honeycomb_block
fill 23 120 360 25 120 360 minecraft:orange_terracotta
setblock 23 120 363 minecraft:honeycomb_block
fill 24 120 323 24 120 325 minecraft:orange_terracotta
setblock 24 120 326 minecraft:honeycomb_block
fill 24 120 327 26 120 327 minecraft:orange_terracotta
setblock 24 120 330 minecraft:honeycomb_block
fill 24 120 331 26 120 331 minecraft:orange_terracotta
setblock 24 120 350 minecraft:honeycomb_block
fill 24 120 351 26 120 351 minecraft:orange_terracotta
setblock 24 120 354 minecraft:honeycomb_block
fill 24 120 355 26 120 355 minecraft:orange_terracotta
setblock 24 120 358 minecraft:honeycomb_block
fill 24 120 359 26 120 359 minecraft:orange_terracotta
setblock 24 120 362 minecraft:honeycomb_block
fill 24 120 363 26 120 363 minecraft:orange_terracotta
fill 25 120 323 25 120 324 minecraft:orange_terracotta
setblock 25 120 325 minecraft:honeycomb_block
fill 25 120 326 27 120 326 minecraft:orange_terracotta
setblock 25 120 329 minecraft:honeycomb_block
fill 25 120 330 27 120 330 minecraft:orange_terracotta
fill 25 120 339 26 120 339 minecraft:ochre_froglight
fill 25 120 343 26 120 343 minecraft:ochre_froglight
fill 25 120 350 27 120 350 minecraft:orange_terracotta
setblock 25 120 353 minecraft:honeycomb_block
fill 25 120 354 27 120 354 minecraft:orange_terracotta
setblock 25 120 357 minecraft:honeycomb_block
fill 25 120 358 27 120 358 minecraft:orange_terracotta
setblock 25 120 361 minecraft:honeycomb_block
fill 25 120 362 27 120 362 minecraft:orange_terracotta
setblock 26 120 323 minecraft:orange_terracotta
setblock 26 120 324 minecraft:honeycomb_block
fill 26 120 325 28 120 325 minecraft:orange_terracotta
setblock 26 120 328 minecraft:honeycomb_block
fill 26 120 329 28 120 329 minecraft:orange_terracotta
setblock 26 120 332 minecraft:honeycomb_block
fill 26 120 338 27 120 338 minecraft:orange_stained_glass
fill 26 120 340 26 120 342 minecraft:ochre_froglight
fill 26 120 344 27 120 344 minecraft:orange_stained_glass
setblock 26 120 352 minecraft:honeycomb_block
fill 26 120 353 28 120 353 minecraft:orange_terracotta
setblock 26 120 356 minecraft:honeycomb_block
fill 26 120 357 28 120 357 minecraft:orange_terracotta
setblock 26 120 360 minecraft:honeycomb_block
fill 26 120 361 28 120 361 minecraft:orange_terracotta
setblock 27 120 323 minecraft:honeycomb_block
fill 27 120 324 29 120 324 minecraft:orange_terracotta
setblock 27 120 327 minecraft:honeycomb_block
fill 27 120 328 29 120 328 minecraft:orange_terracotta
setblock 27 120 331 minecraft:honeycomb_block
fill 27 120 332 28 120 333 minecraft:orange_terracotta
fill 27 120 335 29 120 335 minecraft:orange_stained_glass
fill 27 120 339 27 120 343 minecraft:orange_stained_glass
fill 27 120 347 29 120 347 minecraft:orange_stained_glass
fill 27 120 349 28 120 349 minecraft:orange_terracotta
setblock 27 120 351 minecraft:honeycomb_block
fill 27 120 352 29 120 352 minecraft:orange_terracotta
setblock 27 120 355 minecraft:honeycomb_block
fill 27 120 356 29 120 356 minecraft:orange_terracotta
setblock 27 120 359 minecraft:honeycomb_block
fill 27 120 360 29 120 360 minecraft:orange_terracotta
setblock 27 120 363 minecraft:honeycomb_block
fill 28 120 323 30 120 323 minecraft:orange_terracotta
setblock 28 120 326 minecraft:honeycomb_block
fill 28 120 327 30 120 327 minecraft:orange_terracotta
setblock 28 120 330 minecraft:honeycomb_block
fill 28 120 331 30 120 331 minecraft:orange_terracotta
fill 28 120 336 30 120 336 minecraft:orange_stained_glass
setblock 28 120 341 minecraft:orange_stained_glass
fill 28 120 346 30 120 346 minecraft:orange_stained_glass
setblock 28 120 350 minecraft:honeycomb_block
fill 28 120 351 30 120 351 minecraft:orange_terracotta
setblock 28 120 354 minecraft:honeycomb_block
fill 28 120 355 30 120 355 minecraft:orange_terracotta
setblock 28 120 358 minecraft:honeycomb_block
fill 28 120 359 30 120 359 minecraft:orange_terracotta
setblock 28 120 362 minecraft:honeycomb_block
fill 28 120 363 30 120 363 minecraft:orange_terracotta
setblock 29 120 325 minecraft:honeycomb_block
fill 29 120 326 31 120 326 minecraft:orange_terracotta
setblock 29 120 329 minecraft:honeycomb_block
fill 29 120 330 31 120 330 minecraft:orange_terracotta
setblock 29 120 332 minecraft:orange_terracotta
setblock 29 120 333 minecraft:honeycomb_block
fill 29 120 334 31 120 334 minecraft:orange_terracotta
fill 29 120 337 30 120 337 minecraft:orange_stained_glass
fill 29 120 345 30 120 345 minecraft:orange_stained_glass
setblock 29 120 348 minecraft:orange_terracotta
setblock 29 120 349 minecraft:honeycomb_block
fill 29 120 350 31 120 350 minecraft:orange_terracotta
setblock 29 120 353 minecraft:honeycomb_block
fill 29 120 354 31 120 354 minecraft:orange_terracotta
setblock 29 120 357 minecraft:honeycomb_block
fill 29 120 358 31 120 358 minecraft:orange_terracotta
setblock 29 120 361 minecraft:honeycomb_block
fill 29 120 362 31 120 362 minecraft:orange_terracotta
setblock 30 120 324 minecraft:honeycomb_block
fill 30 120 325 32 120 325 minecraft:orange_terracotta
setblock 30 120 328 minecraft:honeycomb_block
fill 30 120 329 32 120 329 minecraft:orange_terracotta
setblock 30 120 332 minecraft:honeycomb_block
fill 30 120 333 32 120 333 minecraft:orange_terracotta
setblock 30 120 335 minecraft:orange_terracotta
fill 30 120 338 31 120 344 minecraft:orange_stained_glass
setblock 30 120 347 minecraft:orange_terracotta
setblock 30 120 348 minecraft:honeycomb_block
fill 30 120 349 32 120 349 minecraft:orange_terracotta
setblock 30 120 352 minecraft:honeycomb_block
fill 30 120 353 32 120 353 minecraft:orange_terracotta
setblock 30 120 356 minecraft:honeycomb_block
fill 30 120 357 32 120 357 minecraft:orange_terracotta
setblock 30 120 360 minecraft:honeycomb_block
fill 30 120 361 32 120 361 minecraft:orange_terracotta
setblock 31 120 323 minecraft:honeycomb_block
fill 31 120 324 33 120 324 minecraft:orange_terracotta
setblock 31 120 327 minecraft:honeycomb_block
fill 31 120 328 33 120 328 minecraft:orange_terracotta
setblock 31 120 331 minecraft:honeycomb_block
fill 31 120 332 33 120 332 minecraft:orange_terracotta
setblock 31 120 335 minecraft:honeycomb_block
fill 31 120 336 32 120 337 minecraft:orange_terracotta
fill 31 120 345 31 120 346 minecraft:orange_terracotta
setblock 31 120 347 minecraft:honeycomb_block
fill 31 120 348 33 120 348 minecraft:orange_terracotta
setblock 31 120 351 minecraft:honeycomb_block
fill 31 120 352 33 120 352 minecraft:orange_terracotta
setblock 31 120 355 minecraft:honeycomb_block
fill 31 120 356 33 120 356 minecraft:orange_terracotta
setblock 31 120 359 minecraft:honeycomb_block
fill 31 120 360 33 120 360 minecraft:orange_terracotta
setblock 31 120 363 minecraft:honeycomb_block
fill 32 120 323 34 120 323 minecraft:orange_terracotta
setblock 32 120 326 minecraft:honeycomb_block
fill 32 120 327 34 120 327 minecraft:orange_terracotta
setblock 32 120 330 minecraft:honeycomb_block
fill 32 120 331 34 120 331 minecraft:orange_terracotta
setblock 32 120 334 minecraft:honeycomb_block
fill 32 120 335 34 120 335 minecraft:orange_terracotta
setblock 32 120 338 minecraft:honeycomb_block
fill 32 120 339 32 120 341 minecraft:orange_terracotta
setblock 32 120 342 minecraft:honeycomb_block
fill 32 120 343 32 120 345 minecraft:orange_terracotta
setblock 32 120 346 minecraft:honeycomb_block
fill 32 120 347 34 120 347 minecraft:orange_terracotta
setblock 32 120 350 minecraft:honeycomb_block
fill 32 120 351 34 120 351 minecraft:orange_terracotta
setblock 32 120 354 minecraft:honeycomb_block
fill 32 120 355 34 120 355 minecraft:orange_terracotta
setblock 32 120 358 minecraft:honeycomb_block
fill 32 120 359 34 120 359 minecraft:orange_terracotta
setblock 32 120 362 minecraft:honeycomb_block
fill 32 120 363 34 120 363 minecraft:orange_terracotta
setblock 33 120 325 minecraft:honeycomb_block
fill 33 120 326 35 120 326 minecraft:orange_terracotta
setblock 33 120 329 minecraft:honeycomb_block
fill 33 120 330 35 120 330 minecraft:orange_terracotta
setblock 33 120 333 minecraft:honeycomb_block
fill 33 120 334 35 120 334 minecraft:orange_terracotta
setblock 33 120 336 minecraft:orange_terracotta
setblock 33 120 337 minecraft:honeycomb_block
fill 33 120 338 33 120 340 minecraft:orange_terracotta
setblock 33 120 341 minecraft:honeycomb_block
fill 33 120 342 33 120 344 minecraft:orange_terracotta
setblock 33 120 345 minecraft:honeycomb_block
fill 33 120 346 35 120 346 minecraft:orange_terracotta
setblock 33 120 349 minecraft:honeycomb_block
fill 33 120 350 35 120 350 minecraft:orange_terracotta
setblock 33 120 353 minecraft:honeycomb_block
fill 33 120 354 35 120 354 minecraft:orange_terracotta
setblock 33 120 357 minecraft:honeycomb_block
fill 33 120 358 35 120 358 minecraft:orange_terracotta
setblock 33 120 361 minecraft:honeycomb_block
fill 33 120 362 35 120 362 minecraft:orange_terracotta
setblock 34 120 324 minecraft:honeycomb_block
fill 34 120 325 36 120 325 minecraft:orange_terracotta
setblock 34 120 328 minecraft:honeycomb_block
fill 34 120 329 36 120 329 minecraft:orange_terracotta
setblock 34 120 332 minecraft:honeycomb_block
fill 34 120 333 36 120 333 minecraft:orange_terracotta
setblock 34 120 336 minecraft:honeycomb_block
fill 34 120 337 34 120 339 minecraft:orange_terracotta
setblock 34 120 340 minecraft:honeycomb_block
fill 34 120 341 34 120 343 minecraft:orange_terracotta
setblock 34 120 344 minecraft:honeycomb_block
fill 34 120 345 36 120 345 minecraft:orange_terracotta
setblock 34 120 348 minecraft:honeycomb_block
fill 34 120 349 36 120 349 minecraft:orange_terracotta
setblock 34 120 352 minecraft:honeycomb_block
fill 34 120 353 36 120 353 minecraft:orange_terracotta
setblock 34 120 356 minecraft:honeycomb_block
fill 34 120 357 36 120 357 minecraft:orange_terracotta
setblock 34 120 360 minecraft:honeycomb_block
fill 34 120 361 36 120 361 minecraft:orange_terracotta
setblock 35 120 323 minecraft:honeycomb_block
fill 35 120 324 37 120 324 minecraft:orange_terracotta
setblock 35 120 327 minecraft:honeycomb_block
fill 35 120 328 37 120 328 minecraft:orange_terracotta
setblock 35 120 331 minecraft:honeycomb_block
fill 35 120 332 37 120 332 minecraft:orange_terracotta
setblock 35 120 335 minecraft:honeycomb_block
fill 35 120 336 35 120 338 minecraft:orange_terracotta
setblock 35 120 339 minecraft:honeycomb_block
fill 35 120 340 35 120 342 minecraft:orange_terracotta
setblock 35 120 343 minecraft:honeycomb_block
fill 35 120 344 37 120 344 minecraft:orange_terracotta
setblock 35 120 347 minecraft:honeycomb_block
fill 35 120 348 37 120 348 minecraft:orange_terracotta
setblock 35 120 351 minecraft:honeycomb_block
fill 35 120 352 37 120 352 minecraft:orange_terracotta
setblock 35 120 355 minecraft:honeycomb_block
fill 35 120 356 37 120 356 minecraft:orange_terracotta
setblock 35 120 359 minecraft:honeycomb_block
fill 35 120 360 37 120 360 minecraft:orange_terracotta
setblock 35 120 363 minecraft:honeycomb_block
fill 36 120 323 38 120 323 minecraft:orange_terracotta
setblock 36 120 326 minecraft:honeycomb_block
fill 36 120 327 38 120 327 minecraft:orange_terracotta
setblock 36 120 330 minecraft:honeycomb_block
fill 36 120 331 38 120 331 minecraft:orange_terracotta
setblock 36 120 334 minecraft:honeycomb_block
fill 36 120 335 36 120 337 minecraft:orange_terracotta
setblock 36 120 338 minecraft:honeycomb_block
fill 36 120 339 36 120 341 minecraft:orange_terracotta
setblock 36 120 342 minecraft:honeycomb_block
fill 36 120 343 38 120 343 minecraft:orange_terracotta
setblock 36 120 346 minecraft:honeycomb_block
fill 36 120 347 38 120 347 minecraft:orange_terracotta
setblock 36 120 350 minecraft:honeycomb_block
fill 36 120 351 38 120 351 minecraft:orange_terracotta
setblock 36 120 354 minecraft:honeycomb_block
fill 36 120 355 38 120 355 minecraft:orange_terracotta
setblock 36 120 358 minecraft:honeycomb_block
fill 36 120 359 38 120 359 minecraft:orange_terracotta
setblock 36 120 362 minecraft:honeycomb_block
fill 36 120 363 38 120 363 minecraft:orange_terracotta
setblock 37 120 325 minecraft:honeycomb_block
fill 37 120 326 39 120 326 minecraft:orange_terracotta
setblock 37 120 329 minecraft:honeycomb_block
fill 37 120 330 39 120 330 minecraft:orange_terracotta
setblock 37 120 333 minecraft:honeycomb_block
fill 37 120 334 37 120 336 minecraft:orange_terracotta
setblock 37 120 337 minecraft:honeycomb_block
fill 37 120 338 37 120 340 minecraft:orange_terracotta
setblock 37 120 341 minecraft:honeycomb_block
fill 37 120 342 39 120 342 minecraft:orange_terracotta
setblock 37 120 345 minecraft:honeycomb_block
fill 37 120 346 39 120 346 minecraft:orange_terracotta
setblock 37 120 349 minecraft:honeycomb_block
fill 37 120 350 39 120 350 minecraft:orange_terracotta
setblock 37 120 353 minecraft:honeycomb_block
fill 37 120 354 39 120 354 minecraft:orange_terracotta
setblock 37 120 357 minecraft:honeycomb_block
fill 37 120 358 39 120 358 minecraft:orange_terracotta
setblock 37 120 361 minecraft:honeycomb_block
fill 37 120 362 39 120 362 minecraft:orange_terracotta
setblock 38 120 324 minecraft:honeycomb_block
fill 38 120 325 40 120 325 minecraft:orange_terracotta
setblock 38 120 328 minecraft:honeycomb_block
fill 38 120 329 40 120 329 minecraft:orange_terracotta
setblock 38 120 332 minecraft:honeycomb_block
fill 38 120 333 38 120 335 minecraft:orange_terracotta
setblock 38 120 336 minecraft:honeycomb_block
fill 38 120 337 38 120 339 minecraft:orange_terracotta
setblock 38 120 340 minecraft:honeycomb_block
fill 38 120 341 40 120 341 minecraft:orange_terracotta
setblock 38 120 344 minecraft:honeycomb_block
fill 38 120 345 40 120 345 minecraft:orange_terracotta
setblock 38 120 348 minecraft:honeycomb_block
fill 38 120 349 40 120 349 minecraft:orange_terracotta
setblock 38 120 352 minecraft:honeycomb_block
fill 38 120 353 40 120 353 minecraft:orange_terracotta
setblock 38 120 356 minecraft:honeycomb_block
fill 38 120 357 40 120 357 minecraft:orange_terracotta
setblock 38 120 360 minecraft:honeycomb_block
fill 38 120 361 40 120 361 minecraft:orange_terracotta
setblock 39 120 323 minecraft:honeycomb_block
fill 39 120 324 41 120 324 minecraft:orange_terracotta
setblock 39 120 327 minecraft:honeycomb_block
fill 39 120 328 41 120 328 minecraft:orange_terracotta
setblock 39 120 331 minecraft:honeycomb_block
fill 39 120 332 39 120 334 minecraft:orange_terracotta
setblock 39 120 335 minecraft:honeycomb_block
fill 39 120 336 39 120 338 minecraft:orange_terracotta
setblock 39 120 339 minecraft:honeycomb_block
fill 39 120 340 41 120 340 minecraft:orange_terracotta
setblock 39 120 343 minecraft:honeycomb_block
fill 39 120 344 41 120 344 minecraft:orange_terracotta
setblock 39 120 347 minecraft:honeycomb_block
fill 39 120 348 41 120 348 minecraft:orange_terracotta
setblock 39 120 351 minecraft:honeycomb_block
fill 39 120 352 41 120 352 minecraft:orange_terracotta
setblock 39 120 355 minecraft:honeycomb_block
fill 39 120 356 41 120 356 minecraft:orange_terracotta
setblock 39 120 359 minecraft:honeycomb_block
fill 39 120 360 41 120 360 minecraft:orange_terracotta
setblock 39 120 363 minecraft:honeycomb_block
fill 40 120 323 41 120 323 minecraft:orange_terracotta
setblock 40 120 326 minecraft:honeycomb_block
fill 40 120 327 41 120 327 minecraft:orange_terracotta
setblock 40 120 330 minecraft:honeycomb_block
fill 40 120 331 40 120 333 minecraft:orange_terracotta
setblock 40 120 334 minecraft:honeycomb_block
fill 40 120 335 40 120 337 minecraft:orange_terracotta
setblock 40 120 338 minecraft:honeycomb_block
fill 40 120 339 41 120 339 minecraft:orange_terracotta
setblock 40 120 342 minecraft:honeycomb_block
fill 40 120 343 41 120 343 minecraft:orange_terracotta
setblock 40 120 346 minecraft:honeycomb_block
fill 40 120 347 41 120 347 minecraft:orange_terracotta
setblock 40 120 350 minecraft:honeycomb_block
fill 40 120 351 41 120 351 minecraft:orange_terracotta
setblock 40 120 354 minecraft:honeycomb_block
fill 40 120 355 41 120 355 minecraft:orange_terracotta
setblock 40 120 358 minecraft:honeycomb_block
fill 40 120 359 41 120 359 minecraft:orange_terracotta
setblock 40 120 362 minecraft:honeycomb_block
fill 40 120 363 41 120 363 minecraft:orange_terracotta
setblock 41 120 325 minecraft:honeycomb_block
setblock 41 120 326 minecraft:orange_terracotta
setblock 41 120 329 minecraft:honeycomb_block
fill 41 120 330 41 120 332 minecraft:orange_terracotta
setblock 41 120 333 minecraft:honeycomb_block
fill 41 120 334 41 120 336 minecraft:orange_terracotta
setblock 41 120 337 minecraft:honeycomb_block
setblock 41 120 338 minecraft:orange_terracotta
setblock 41 120 341 minecraft:honeycomb_block
setblock 41 120 342 minecraft:orange_terracotta
setblock 41 120 345 minecraft:honeycomb_block
setblock 41 120 346 minecraft:orange_terracotta
setblock 41 120 349 minecraft:honeycomb_block
setblock 41 120 350 minecraft:orange_terracotta
setblock 41 120 353 minecraft:honeycomb_block
setblock 41 120 354 minecraft:orange_terracotta
setblock 41 120 357 minecraft:honeycomb_block
setblock 41 120 358 minecraft:orange_terracotta
setblock 41 120 361 minecraft:honeycomb_block
setblock 41 120 362 minecraft:orange_terracotta
fill 42 120 362 42 127 362 minecraft:honeycomb_block
setblock 2 121 322 minecraft:orange_terracotta
setblock 7 121 364 minecraft:yellow_concrete
setblock 17 121 364 minecraft:yellow_concrete
fill 20 121 340 20 121 341 minecraft:orange_stained_glass
setblock 21 121 339 minecraft:honeycomb_block
fill 22 121 338 24 121 338 minecraft:orange_stained_glass
fill 22 121 344 24 121 344 minecraft:orange_stained_glass
setblock 25 121 339 minecraft:honeycomb_block
setblock 25 121 343 minecraft:honeycomb_block
fill 26 121 340 26 121 342 minecraft:orange_stained_glass
setblock 0 122 359 minecraft:yellow_terracotta
fill 0 122 360 0 149 360 minecraft:honeycomb_block
fill 2 122 322 2 205 322 minecraft:honeycomb_block
setblock 3 122 325 minecraft:light[level=12]
setblock 3 122 332 minecraft:light[level=12]
setblock 3 122 339 minecraft:light[level=12]
setblock 3 122 346 minecraft:light[level=12]
setblock 3 122 353 minecraft:light[level=12]
setblock 3 122 360 minecraft:light[level=12]
fill 7 122 364 7 136 364 minecraft:honeycomb_block
setblock 10 122 325 minecraft:light[level=12]
setblock 10 122 332 minecraft:light[level=12]
setblock 10 122 339 minecraft:light[level=12]
setblock 10 122 346 minecraft:light[level=12]
setblock 10 122 353 minecraft:light[level=12]
setblock 10 122 360 minecraft:light[level=12]
setblock 17 122 325 minecraft:light[level=12]
setblock 17 122 332 minecraft:light[level=12]
setblock 17 122 339 minecraft:light[level=12]
setblock 17 122 346 minecraft:light[level=12]
setblock 17 122 353 minecraft:light[level=12]
setblock 17 122 360 minecraft:light[level=12]
fill 17 122 364 17 127 364 minecraft:honeycomb_block
setblock 24 122 325 minecraft:light[level=12]
setblock 24 122 332 minecraft:light[level=12]
setblock 24 122 346 minecraft:light[level=12]
setblock 24 122 353 minecraft:light[level=12]
setblock 24 122 360 minecraft:light[level=12]
setblock 31 122 325 minecraft:light[level=12]
setblock 31 122 332 minecraft:light[level=12]
setblock 31 122 339 minecraft:light[level=12]
setblock 31 122 346 minecraft:light[level=12]
setblock 31 122 353 minecraft:light[level=12]
setblock 31 122 360 minecraft:light[level=12]
setblock 33 122 364 minecraft:orange_terracotta
setblock 38 122 325 minecraft:light[level=12]
setblock 38 122 332 minecraft:light[level=12]
setblock 38 122 339 minecraft:light[level=12]
setblock 38 122 346 minecraft:light[level=12]
setblock 38 122 353 minecraft:light[level=12]
setblock 38 122 360 minecraft:light[level=12]
fill 0 123 359 0 202 359 minecraft:honeycomb_block
setblock 26 123 364 minecraft:yellow_terracotta
fill 33 123 364 33 124 364 minecraft:honeycomb_block
fill 1 124 323 1 124 325 minecraft:honeycomb_block
setblock 1 124 326 minecraft:yellow_terracotta
fill 1 124 327 1 124 330 minecraft:honeycomb_block
setblock 1 124 331 minecraft:yellow_terracotta
fill 1 124 332 1 124 335 minecraft:honeycomb_block
setblock 1 124 336 minecraft:yellow_terracotta
fill 1 124 337 1 126 338 minecraft:honeycomb_block
fill 1 124 353 1 124 355 minecraft:honeycomb_block
setblock 1 124 356 minecraft:yellow_terracotta
fill 1 124 357 1 127 357 minecraft:honeycomb_block
setblock 1 124 359 minecraft:honey_block
fill 2 124 323 3 124 323 minecraft:honeycomb_block
fill 2 124 326 2 124 329 minecraft:honeycomb_block
setblock 2 124 330 minecraft:yellow_terracotta
fill 2 124 331 2 124 334 minecraft:honeycomb_block
setblock 2 124 335 minecraft:yellow_terracotta
fill 2 124 336 2 127 336 minecraft:honeycomb_block
setblock 3 124 329 minecraft:yellow_terracotta
fill 3 124 330 3 124 333 minecraft:honeycomb_block
setblock 4 124 323 minecraft:yellow_terracotta
fill 4 124 324 7 124 324 minecraft:honeycomb_block
setblock 4 124 363 minecraft:yellow_terracotta
fill 5 124 323 8 124 323 minecraft:honeycomb_block
fill 5 124 363 8 124 363 minecraft:honeycomb_block
setblock 6 124 325 minecraft:honeycomb_block
fill 6 124 362 9 124 362 minecraft:honeycomb_block
setblock 7 124 325 minecraft:yellow_terracotta
setblock 8 124 324 minecraft:yellow_terracotta
fill 8 124 325 11 124 325 minecraft:honeycomb_block
fill 8 124 361 10 124 361 minecraft:honeycomb_block
setblock 9 124 323 minecraft:yellow_terracotta
fill 9 124 324 12 124 324 minecraft:honeycomb_block
setblock 9 124 363 minecraft:yellow_terracotta
fill 10 124 323 13 124 323 minecraft:honeycomb_block
setblock 10 124 362 minecraft:yellow_terracotta
fill 10 124 363 13 124 363 minecraft:honeycomb_block
setblock 11 124 361 minecraft:yellow_terracotta
fill 11 124 362 14 124 362 minecraft:honeycomb_block
fill 12 124 361 14 125 361 minecraft:honeycomb_block
setblock 13 124 324 minecraft:yellow_terracotta
fill 13 124 356 13 133 356 minecraft:flowering_azalea_leaves[persistent=true]
setblock 14 124 323 minecraft:yellow_terracotta
setblock 14 124 363 minecraft:yellow_terracotta
fill 15 124 323 15 125 323 minecraft:honeycomb_block
setblock 15 124 362 minecraft:yellow_terracotta
fill 15 124 363 18 124 363 minecraft:honeycomb_block
fill 16 124 362 16 125 362 minecraft:honeycomb_block
setblock 19 124 322 minecraft:orange_terracotta
fill 20 124 323 20 125 323 minecraft:honey_block
setblock 24 124 363 minecraft:yellow_terracotta
fill 25 124 363 28 124 363 minecraft:honeycomb_block
setblock 26 124 323 minecraft:honey_block
fill 26 124 364 26 162 364 minecraft:honeycomb_block
setblock 27 124 364 minecraft:yellow_terracotta
setblock 29 124 323 minecraft:yellow_terracotta
setblock 29 124 362 minecraft:honeycomb_block
setblock 29 124 363 minecraft:yellow_terracotta
fill 30 124 323 32 124 323 minecraft:honeycomb_block
fill 30 124 363 32 125 363 minecraft:honeycomb_block
setblock 39 124 332 minecraft:honeycomb_block
setblock 39 124 333 minecraft:yellow_terracotta
fill 39 124 334 41 125 334 minecraft:honeycomb_block
fill 40 124 329 40 124 331 minecraft:honeycomb_block
setblock 40 124 332 minecraft:yellow_terracotta
fill 40 124 333 41 126 333 minecraft:honeycomb_block
fill 40 124 335 40 124 336 minecraft:honeycomb_block
setblock 40 124 337 minecraft:yellow_terracotta
setblock 41 124 326 minecraft:yellow_terracotta
fill 41 124 327 41 124 330 minecraft:honeycomb_block
setblock 41 124 331 minecraft:yellow_terracotta
fill 41 124 332 41 127 332 minecraft:honeycomb_block
setblock 41 124 335 minecraft:honeycomb_block
setblock 41 124 336 minecraft:yellow_terracotta
fill 41 124 337 41 124 340 minecraft:honeycomb_block
fill 41 124 349 41 124 350 minecraft:honeycomb_block
setblock 41 124 351 minecraft:yellow_terracotta
fill 41 124 352 41 124 355 minecraft:honeycomb_block
setblock 41 124 363 minecraft:honey_block
setblock 42 124 344 minecraft:yellow_terracotta
fill 1 125 323 1 125 324 minecraft:honeycomb_block
setblock 1 125 325 minecraft:yellow_terracotta
fill 1 125 326 1 125 329 minecraft:honeycomb_block
setblock 1 125 330 minecraft:yellow_terracotta
fill 1 125 331 1 125 334 minecraft:honeycomb_block
setblock 1 125 335 minecraft:yellow_terracotta
fill 1 125 336 1 128 336 minecraft:honeycomb_block
setblock 1 125 340 minecraft:honey_block
fill 1 125 353 1 125 354 minecraft:honeycomb_block
setblock 1 125 355 minecraft:yellow_terracotta
fill 1 125 356 1 128 356 minecraft:honeycomb_block
fill 1 125 358 1 125 359 minecraft:honeycomb_block
setblock 2 125 323 minecraft:honeycomb_block
fill 2 125 326 2 125 328 minecraft:honeycomb_block
setblock 2 125 329 minecraft:yellow_terracotta
fill 2 125 330 2 125 333 minecraft:honeycomb_block
setblock 2 125 334 minecraft:yellow_terracotta
fill 2 125 335 2 128 335 minecraft:honeycomb_block
setblock 3 125 323 minecraft:yellow_terracotta
fill 3 125 329 3 125 332 minecraft:honeycomb_block
setblock 3 125 333 minecraft:yellow_terracotta
fill 3 125 334 3 126 334 minecraft:honeycomb_block
setblock 3 125 363 minecraft:yellow_terracotta
fill 4 125 323 6 125 324 minecraft:honeycomb_block
fill 4 125 363 7 125 363 minecraft:honeycomb_block
fill 5 125 362 8 125 362 minecraft:honeycomb_block
fill 6 125 322 6 208 322 minecraft:honeycomb_block
setblock 7 125 322 minecraft:yellow_concrete
setblock 7 125 323 minecraft:honeycomb_block
setblock 7 125 324 minecraft:yellow_terracotta
fill 7 125 325 10 125 325 minecraft:honeycomb_block
fill 7 125 361 9 125 361 minecraft:honeycomb_block
setblock 8 125 323 minecraft:yellow_terracotta
fill 8 125 324 11 125 324 minecraft:honeycomb_block
setblock 8 125 363 minecraft:yellow_terracotta
fill 9 125 323 12 125 323 minecraft:honeycomb_block
setblock 9 125 362 minecraft:yellow_terracotta
fill 9 125 363 12 125 363 minecraft:honeycomb_block
setblock 10 125 360 minecraft:honeycomb_block
setblock 10 125 361 minecraft:yellow_terracotta
fill 10 125 362 13 125 362 minecraft:honeycomb_block
fill 11 125 361 11 128 361 minecraft:honeycomb_block
setblock 12 125 324 minecraft:yellow_terracotta
setblock 13 125 323 minecraft:yellow_terracotta
setblock 13 125 363 minecraft:yellow_terracotta
fill 14 125 323 14 126 323 minecraft:honeycomb_block
setblock 14 125 362 minecraft:yellow_terracotta
fill 14 125 363 17 125 363 minecraft:honeycomb_block
fill 15 125 362 15 127 362 minecraft:honeycomb_block
setblock 18 125 363 minecraft:yellow_terracotta
fill 19 125 322 19 205 322 minecraft:honeycomb_block
setblock 22 125 363 minecraft:honey_block
setblock 23 125 363 minecraft:yellow_terracotta
fill 24 125 363 27 125 363 minecraft:honeycomb_block
setblock 27 125 322 minecraft:orange_terracotta
fill 27 125 362 28 125 362 minecraft:honeycomb_block
fill 27 125 364 27 285 364 minecraft:honeycomb_block
setblock 28 125 363 minecraft:yellow_terracotta
fill 29 125 323 31 125 323 minecraft:honeycomb_block
setblock 29 125 362 minecraft:yellow_terracotta
fill 29 125 363 29 128 363 minecraft:honeycomb_block
setblock 30 125 362 minecraft:honeycomb_block
setblock 33 125 364 minecraft:orange_terracotta
setblock 39 125 323 minecraft:honey_block
setblock 39 125 332 minecraft:yellow_terracotta
fill 39 125 333 39 126 333 minecraft:honeycomb_block
fill 39 125 335 40 125 335 minecraft:honeycomb_block
fill 40 125 329 40 125 330 minecraft:honeycomb_block
setblock 40 125 331 minecraft:yellow_terracotta
fill 40 125 332 40 128 332 minecraft:honeycomb_block
setblock 40 125 336 minecraft:yellow_terracotta
fill 40 125 337 41 126 338 minecraft:honeycomb_block
fill 41 125 326 41 125 329 minecraft:honeycomb_block
setblock 41 125 330 minecraft:yellow_terracotta
fill 41 125 331 41 128 331 minecraft:honeycomb_block
setblock 41 125 335 minecraft:yellow_terracotta
fill 41 125 336 41 128 336 minecraft:honeycomb_block
setblock 41 125 339 minecraft:honeycomb_block
setblock 41 125 340 minecraft:yellow_terracotta
fill 41 125 341 41 128 341 minecraft:honeycomb_block
setblock 41 125 346 minecraft:honey_block
fill 41 125 351 41 125 354 minecraft:honeycomb_block
setblock 41 125 355 minecraft:yellow_terracotta
fill 41 125 356 41 127 356 minecraft:honeycomb_block
fill 42 125 344 42 142 344 minecraft:honeycomb_block
setblock 1 126 323 minecraft:honeycomb_block
setblock 1 126 324 minecraft:yellow_terracotta
fill 1 126 325 1 126 328 minecraft:honeycomb_block
setblock 1 126 329 minecraft:yellow_terracotta
fill 1 126 330 1 126 333 minecraft:honeycomb_block
setblock 1 126 334 minecraft:yellow_terracotta
fill 1 126 335 1 129 335 minecraft:honeycomb_block
setblock 1 126 346 minecraft:honey_block
setblock 1 126 353 minecraft:honeycomb_block
setblock 1 126 354 minecraft:yellow_terracotta
fill 1 126 355 1 129 355 minecraft:honeycomb_block
setblock 1 126 358 minecraft:honeycomb_block
setblock 1 126 359 minecraft:yellow_terracotta
fill 1 126 360 1 128 361 minecraft:honeycomb_block
setblock 2 126 323 minecraft:yellow_terracotta
setblock 2 126 327 minecraft:honeycomb_block
setblock 2 126 328 minecraft:yellow_terracotta
fill 2 126 329 2 126 332 minecraft:honeycomb_block
setblock 2 126 333 minecraft:yellow_terracotta
fill 2 126 334 2 129 334 minecraft:honeycomb_block
setblock 2 126 363 minecraft:yellow_terracotta
fill 3 126 323 6 126 323 minecraft:honeycomb_block
fill 3 126 330 3 126 331 minecraft:honeycomb_block
setblock 3 126 332 minecraft:yellow_terracotta
fill 3 126 333 3 127 333 minecraft:honeycomb_block
fill 3 126 363 6 126 363 minecraft:honeycomb_block
fill 4 126 324 5 126 324 minecraft:honeycomb_block
fill 4 126 362 7 126 362 minecraft:honeycomb_block
setblock 6 126 324 minecraft:yellow_terracotta
fill 6 126 361 8 126 361 minecraft:honeycomb_block
fill 7 126 322 7 270 322 minecraft:honeycomb_block
setblock 7 126 323 minecraft:yellow_terracotta
fill 7 126 324 10 126 324 minecraft:honeycomb_block
setblock 7 126 363 minecraft:yellow_terracotta
fill 8 126 323 11 126 323 minecraft:honeycomb_block
setblock 8 126 362 minecraft:yellow_terracotta
fill 8 126 363 11 126 363 minecraft:honeycomb_block
setblock 9 126 360 minecraft:honeycomb_block
setblock 9 126 361 minecraft:yellow_terracotta
fill 9 126 362 12 126 362 minecraft:honeycomb_block
setblock 10 126 360 minecraft:yellow_terracotta
fill 10 126 361 10 129 361 minecraft:honeycomb_block
setblock 11 126 324 minecraft:yellow_terracotta
setblock 11 126 360 minecraft:honeycomb_block
setblock 12 126 323 minecraft:yellow_terracotta
fill 12 126 361 13 126 361 minecraft:honeycomb_block
setblock 12 126 363 minecraft:yellow_terracotta
fill 13 126 323 13 127 323 minecraft:honeycomb_block
setblock 13 126 362 minecraft:yellow_terracotta
fill 13 126 363 16 126 363 minecraft:honeycomb_block
fill 14 126 362 14 129 362 minecraft:honeycomb_block
setblock 17 126 363 minecraft:yellow_terracotta
setblock 18 126 363 minecraft:honeycomb_block
fill 23 126 363 26 126 363 minecraft:honeycomb_block
fill 26 126 362 27 126 362 minecraft:honeycomb_block
fill 27 126 322 27 150 322 minecraft:honeycomb_block
setblock 27 126 363 minecraft:yellow_terracotta
setblock 28 126 362 minecraft:yellow_terracotta
fill 28 126 363 28 129 363 minecraft:honeycomb_block
fill 29 126 362 29 127 362 minecraft:honeycomb_block
fill 30 126 363 31 126 363 minecraft:honeycomb_block
setblock 32 126 363 minecraft:yellow_terracotta
setblock 33 126 323 minecraft:honey_block
fill 33 126 364 33 216 364 minecraft:honeycomb_block
fill 34 126 363 34 127 363 minecraft:honey_block
fill 39 126 334 39 126 335 minecraft:honeycomb_block
setblock 40 126 330 minecraft:yellow_terracotta
fill 40 126 331 40 128 331 minecraft:honeycomb_block
setblock 40 126 334 minecraft:honeycomb_block
setblock 40 126 335 minecraft:yellow_terracotta
fill 40 126 336 40 129 336 minecraft:honeycomb_block
fill 41 126 327 41 126 328 minecraft:honeycomb_block
setblock 41 126 329 minecraft:yellow_terracotta
fill 41 126 330 41 129 330 minecraft:honeycomb_block
setblock 41 126 334 minecraft:yellow_terracotta
fill 41 126 335 41 129 335 minecraft:honeycomb_block
setblock 41 126 339 minecraft:yellow_terracotta
fill 41 126 340 41 129 340 minecraft:honeycomb_block
setblock 41 126 353 minecraft:honeycomb_block
setblock 41 126 354 minecraft:yellow_terracotta
setblock 41 126 355 minecraft:honeycomb_block
setblock 41 126 359 minecraft:honey_block
setblock 1 127 323 minecraft:yellow_terracotta
fill 1 127 324 1 127 327 minecraft:honeycomb_block
setblock 1 127 328 minecraft:yellow_terracotta
fill 1 127 329 1 127 332 minecraft:honeycomb_block
setblock 1 127 333 minecraft:yellow_terracotta
fill 1 127 334 1 130 334 minecraft:honeycomb_block
setblock 1 127 337 minecraft:honeycomb_block
setblock 1 127 338 minecraft:yellow_terracotta
fill 1 127 339 1 130 339 minecraft:honeycomb_block
setblock 1 127 352 minecraft:honey_block
fill 1 127 354 1 128 354 minecraft:honeycomb_block
setblock 1 127 358 minecraft:yellow_terracotta
fill 1 127 359 2 129 359 minecraft:honeycomb_block
setblock 1 127 362 minecraft:honeycomb_block
fill 2 127 323 5 127 323 minecraft:honeycomb_block
fill 2 127 328 2 127 331 minecraft:honeycomb_block
setblock 2 127 332 minecraft:yellow_terracotta
fill 2 127 333 2 130 333 minecraft:honeycomb_block
setblock 2 127 337 minecraft:yellow_terracotta
setblock 2 127 357 minecraft:yellow_terracotta
fill 2 127 358 2 130 358 minecraft:honeycomb_block
fill 2 127 363 5 127 363 minecraft:honeycomb_block
setblock 3 127 332 minecraft:honeycomb_block
fill 3 127 362 6 127 362 minecraft:honeycomb_block
setblock 4 127 324 minecraft:honeycomb_block
setblock 5 127 324 minecraft:yellow_terracotta
fill 5 127 361 7 127 361 minecraft:honeycomb_block
setblock 6 127 323 minecraft:yellow_terracotta
fill 6 127 324 9 127 324 minecraft:honeycomb_block
setblock 6 127 363 minecraft:yellow_terracotta
fill 7 127 323 10 127 323 minecraft:honeycomb_block
setblock 7 127 362 minecraft:yellow_terracotta
fill 7 127 363 10 127 363 minecraft:honeycomb_block
setblock 8 127 360 minecraft:honeycomb_block
setblock 8 127 361 minecraft:yellow_terracotta
fill 8 127 362 11 127 362 minecraft:honeycomb_block
setblock 9 127 360 minecraft:yellow_terracotta
fill 9 127 361 9 130 361 minecraft:honeycomb_block
setblock 10 127 324 minecraft:yellow_terracotta
fill 10 127 360 10 128 360 minecraft:honeycomb_block
setblock 11 127 323 minecraft:yellow_terracotta
setblock 11 127 363 minecraft:yellow_terracotta
fill 12 127 323 12 128 323 minecraft:honeycomb_block
setblock 12 127 361 minecraft:honeycomb_block
setblock 12 127 362 minecraft:yellow_terracotta
fill 12 127 363 15 127 363 minecraft:honeycomb_block
setblock 13 127 361 minecraft:yellow_terracotta
fill 13 127 362 13 130 362 minecraft:honeycomb_block
setblock 16 127 363 minecraft:yellow_terracotta
setblock 17 127 363 minecraft:honeycomb_block
setblock 21 127 322 minecraft:yellow_terracotta
fill 22 127 363 25 127 363 minecraft:honeycomb_block
setblock 23 127 322 minecraft:yellow_concrete
fill 25 127 362 26 127 362 minecraft:honeycomb_block
setblock 26 127 363 minecraft:yellow_terracotta
setblock 27 127 323 minecraft:honey_block
setblock 27 127 362 minecraft:yellow_terracotta
fill 27 127 363 27 130 363 minecraft:honeycomb_block
fill 28 127 362 28 129 362 minecraft:honeycomb_block
setblock 30 127 363 minecraft:honeycomb_block
setblock 31 127 363 minecraft:yellow_terracotta
setblock 40 127 330 minecraft:honeycomb_block
setblock 40 127 333 minecraft:honeycomb_block
setblock 40 127 334 minecraft:yellow_terracotta
fill 40 127 335 40 130 335 minecraft:honeycomb_block
fill 40 127 337 40 127 338 minecraft:honeycomb_block
setblock 40 127 363 minecraft:honey_block
setblock 41 127 327 minecraft:honeycomb_block
setblock 41 127 328 minecraft:yellow_terracotta
fill 41 127 329 41 130 329 minecraft:honeycomb_block
setblock 41 127 333 minecraft:yellow_terracotta
fill 41 127 334 41 130 334 minecraft:honeycomb_block
setblock 41 127 337 minecraft:honeycomb_block
setblock 41 127 338 minecraft:yellow_terracotta
fill 41 127 339 41 130 339 minecraft:honeycomb_block
setblock 41 127 353 minecraft:honey_block
setblock 42 127 357 minecraft:orange_terracotta
fill 1 128 323 1 128 326 minecraft:honeycomb_block
setblock 1 128 327 minecraft:yellow_terracotta
fill 1 128 328 1 128 331 minecraft:honeycomb_block
setblock 1 128 332 minecraft:yellow_terracotta
fill 1 128 333 1 131 333 minecraft:honeycomb_block
setblock 1 128 337 minecraft:yellow_terracotta
fill 1 128 338 1 131 338 minecraft:honeycomb_block
setblock 1 128 357 minecraft:yellow_terracotta
fill 1 128 358 1 131 358 minecraft:honeycomb_block
setblock 1 128 362 minecraft:yellow_terracotta
fill 1 128 363 1 131 364 minecraft:honeycomb_block
fill 2 128 323 4 128 323 minecraft:honeycomb_block
setblock 2 128 330 minecraft:honeycomb_block
setblock 2 128 331 minecraft:yellow_terracotta
fill 2 128 332 2 129 332 minecraft:honeycomb_block
setblock 2 128 336 minecraft:yellow_terracotta
fill 2 128 337 2 129 337 minecraft:honeycomb_block
fill 2 128 357 2 131 357 minecraft:honeycomb_block
setblock 2 128 360 minecraft:honeycomb_block
fill 2 128 363 4 128 363 minecraft:honeycomb_block
setblock 2 128 364 minecraft:yellow_terracotta
setblock 3 128 325 minecraft:light[level=15]
setblock 3 128 332 minecraft:light[level=12]
setblock 3 128 333 minecraft:light[level=15]
setblock 3 128 339 minecraft:light[level=12]
setblock 3 128 341 minecraft:light[level=15]
setblock 3 128 346 minecraft:light[level=12]
setblock 3 128 349 minecraft:light[level=15]
setblock 3 128 353 minecraft:light[level=12]
setblock 3 128 357 minecraft:light[level=15]
setblock 3 128 360 minecraft:light[level=12]
fill 3 128 362 5 128 362 minecraft:honeycomb_block
fill 3 128 364 3 130 364 minecraft:honeycomb_block
setblock 5 128 323 minecraft:yellow_terracotta
fill 5 128 324 8 128 324 minecraft:honeycomb_block
fill 5 128 361 6 128 361 minecraft:honeycomb_block
setblock 5 128 363 minecraft:yellow_terracotta
fill 6 128 323 9 128 323 minecraft:honeycomb_block
setblock 6 128 362 minecraft:yellow_terracotta
fill 6 128 363 9 128 363 minecraft:honeycomb_block
setblock 7 128 360 minecraft:honeycomb_block
setblock 7 128 361 minecraft:yellow_terracotta
fill 7 128 362 10 128 362 minecraft:honeycomb_block
setblock 8 128 360 minecraft:yellow_terracotta
fill 8 128 361 8 131 361 minecraft:honeycomb_block
setblock 9 128 324 minecraft:yellow_terracotta
fill 9 128 360 9 129 360 minecraft:honeycomb_block
setblock 10 128 323 minecraft:yellow_terracotta
setblock 10 128 325 minecraft:light[level=12]
setblock 10 128 332 minecraft:light[level=12]
setblock 10 128 339 minecraft:light[level=12]
setblock 10 128 346 minecraft:light[level=12]
setblock 10 128 353 minecraft:light[level=12]
setblock 10 128 363 minecraft:yellow_terracotta
fill 11 128 323 11 129 323 minecraft:honeycomb_block
setblock 11 128 325 minecraft:light[level=15]
setblock 11 128 333 minecraft:light[level=15]
setblock 11 128 341 minecraft:light[level=15]
setblock 11 128 349 minecraft:light[level=15]
setblock 11 128 357 minecraft:light[level=15]
setblock 11 128 362 minecraft:yellow_terracotta
fill 11 128 363 14 128 363 minecraft:honeycomb_block
setblock 12 128 361 minecraft:yellow_terracotta
fill 12 128 362 12 131 362 minecraft:honeycomb_block
setblock 15 128 363 minecraft:yellow_terracotta
fill 16 128 363 16 129 363 minecraft:honeycomb_block
setblock 17 128 325 minecraft:light[level=12]
setblock 17 128 332 minecraft:light[level=12]
setblock 17 128 339 minecraft:light[level=12]
setblock 17 128 346 minecraft:light[level=12]
setblock 17 128 353 minecraft:light[level=12]
setblock 17 128 360 minecraft:light[level=12]
setblock 17 128 364 minecraft:yellow_terracotta
setblock 19 128 325 minecraft:light[level=15]
setblock 19 128 333 minecraft:light[level=15]
setblock 19 128 341 minecraft:light[level=15]
setblock 19 128 349 minecraft:light[level=15]
setblock 19 128 357 minecraft:light[level=15]
fill 21 128 322 21 231 322 minecraft:honeycomb_block
setblock 21 128 323 minecraft:honey_block
setblock 21 128 363 minecraft:honey_block
fill 22 128 363 24 128 363 minecraft:honeycomb_block
fill 23 128 322 23 193 322 minecraft:honeycomb_block
setblock 24 128 325 minecraft:light[level=12]
setblock 24 128 332 minecraft:light[level=12]
setblock 24 128 339 minecraft:light[level=12]
setblock 24 128 346 minecraft:light[level=12]
setblock 24 128 353 minecraft:light[level=12]
setblock 24 128 360 minecraft:light[level=12]
setblock 25 128 362 minecraft:honeycomb_block
setblock 25 128 363 minecraft:yellow_terracotta
setblock 26 128 362 minecraft:yellow_terracotta
fill 26 128 363 26 131 363 minecraft:honeycomb_block
setblock 27 128 325 minecraft:light[level=15]
setblock 27 128 333 minecraft:light[level=15]
setblock 27 128 341 minecraft:light[level=15]
setblock 27 128 349 minecraft:light[level=15]
setblock 27 128 357 minecraft:light[level=15]
fill 27 128 362 27 131 362 minecraft:honeycomb_block
setblock 30 128 363 minecraft:yellow_terracotta
setblock 31 128 325 minecraft:light[level=12]
setblock 31 128 332 minecraft:light[level=12]
setblock 31 128 339 minecraft:light[level=12]
setblock 31 128 346 minecraft:light[level=12]
setblock 31 128 353 minecraft:light[level=12]
setblock 31 128 360 minecraft:light[level=12]
setblock 35 128 325 minecraft:light[level=15]
setblock 35 128 333 minecraft:light[level=15]
setblock 35 128 341 minecraft:light[level=15]
setblock 35 128 349 minecraft:light[level=15]
setblock 35 128 357 minecraft:light[level=15]
setblock 38 128 325 minecraft:light[level=12]
setblock 38 128 332 minecraft:light[level=12]
setblock 38 128 339 minecraft:light[level=12]
setblock 38 128 346 minecraft:light[level=12]
setblock 38 128 353 minecraft:light[level=12]
setblock 38 128 360 minecraft:light[level=12]
setblock 40 128 323 minecraft:honey_block
setblock 40 128 333 minecraft:yellow_terracotta
fill 40 128 334 40 131 334 minecraft:honeycomb_block
setblock 40 128 337 minecraft:honeycomb_block
setblock 40 128 338 minecraft:yellow_terracotta
fill 41 128 328 41 129 328 minecraft:honeycomb_block
setblock 41 128 332 minecraft:yellow_terracotta
fill 41 128 333 41 131 333 minecraft:honeycomb_block
setblock 41 128 337 minecraft:yellow_terracotta
fill 41 128 338 41 131 338 minecraft:honeycomb_block
setblock 41 128 347 minecraft:honey_block
fill 42 128 357 42 129 357 minecraft:honeycomb_block
setblock 42 128 362 minecraft:orange_terracotta
fill 1 129 323 1 130 324 minecraft:honeycomb_block
setblock 1 129 326 minecraft:honey_block
fill 1 129 327 1 129 330 minecraft:honeycomb_block
setblock 1 129 331 minecraft:yellow_terracotta
fill 1 129 332 1 132 332 minecraft:honeycomb_block
setblock 1 129 336 minecraft:yellow_terracotta
fill 1 129 337 1 132 337 minecraft:honeycomb_block
setblock 1 129 345 minecraft:honey_block
setblock 1 129 356 minecraft:yellow_terracotta
fill 1 129 357 1 132 357 minecraft:honeycomb_block
setblock 1 129 360 minecraft:honeycomb_block
setblock 1 129 361 minecraft:yellow_terracotta
fill 1 129 362 4 129 362 minecraft:honeycomb_block
fill 2 129 323 3 129 323 minecraft:honeycomb_block
setblock 2 129 335 minecraft:yellow_terracotta
fill 2 129 336 2 132 336 minecraft:honeycomb_block
setblock 2 129 360 minecraft:yellow_terracotta
fill 2 129 361 2 132 361 minecraft:honeycomb_block
fill 2 129 363 2 130 364 minecraft:honeycomb_block
setblock 3 129 363 minecraft:honeycomb_block
setblock 4 129 323 minecraft:yellow_terracotta
fill 4 129 361 5 129 361 minecraft:honeycomb_block
setblock 4 129 363 minecraft:yellow_terracotta
fill 5 129 323 7 129 324 minecraft:honeycomb_block
setblock 5 129 362 minecraft:yellow_terracotta
fill 5 129 363 8 129 363 minecraft:honeycomb_block
setblock 6 129 361 minecraft:yellow_terracotta
fill 6 129 362 9 129 362 minecraft:honeycomb_block
setblock 7 129 360 minecraft:yellow_terracotta
fill 7 129 361 7 132 361 minecraft:honeycomb_block
setblock 8 129 323 minecraft:honeycomb_block
fill 8 129 360 8 131 360 minecraft:honeycomb_block
setblock 9 129 323 minecraft:yellow_terracotta
setblock 9 129 363 minecraft:yellow_terracotta
fill 10 129 323 10 132 323 minecraft:honeycomb_block
setblock 10 129 362 minecraft:yellow_terracotta
fill 10 129 363 13 129 363 minecraft:honeycomb_block
setblock 11 129 361 minecraft:yellow_terracotta
fill 11 129 362 11 132 362 minecraft:honeycomb_block
setblock 12 129 361 minecraft:honeycomb_block
setblock 14 129 363 minecraft:yellow_terracotta
setblock 15 129 323 minecraft:honey_block
fill 15 129 363 15 132 363 minecraft:honeycomb_block
fill 17 129 364 17 162 364 minecraft:honeycomb_block
fill 22 129 363 23 129 363 minecraft:honeycomb_block
setblock 24 129 362 minecraft:honeycomb_block
setblock 24 129 363 minecraft:yellow_terracotta
setblock 25 129 362 minecraft:yellow_terracotta
fill 25 129 363 25 132 363 minecraft:honeycomb_block
fill 26 129 362 26 132 362 minecraft:honeycomb_block
setblock 29 129 363 minecraft:yellow_terracotta
setblock 30 129 363 minecraft:honeycomb_block
setblock 34 129 323 minecraft:honey_block
setblock 40 129 332 minecraft:yellow_terracotta
fill 40 129 333 40 131 333 minecraft:honeycomb_block
setblock 40 129 337 minecraft:yellow_terracotta
fill 40 129 338 40 132 338 minecraft:honeycomb_block
setblock 41 129 331 minecraft:yellow_terracotta
fill 41 129 332 41 132 332 minecraft:honeycomb_block
setblock 41 129 336 minecraft:yellow_terracotta
fill 41 129 337 41 132 337 minecraft:honeycomb_block
setblock 41 129 341 minecraft:yellow_terracotta
setblock 41 129 360 minecraft:honey_block
setblock 42 129 335 minecraft:yellow_concrete
fill 42 129 362 42 206 362 minecraft:honeycomb_block
setblock 0 130 329 minecraft:orange_terracotta
fill 0 130 354 0 132 354 minecraft:honeycomb_block
fill 0 130 355 1 130 355 minecraft:yellow_terracotta
fill 0 130 356 1 133 356 minecraft:honeycomb_block
setblock 1 130 329 minecraft:honeycomb_block
setblock 1 130 330 minecraft:yellow_terracotta
fill 1 130 331 1 133 331 minecraft:honeycomb_block
setblock 1 130 335 minecraft:yellow_terracotta
fill 1 130 336 1 133 336 minecraft:honeycomb_block
setblock 1 130 351 minecraft:honey_block
setblock 1 130 359 minecraft:honeycomb_block
setblock 1 130 360 minecraft:yellow_terracotta
fill 1 130 361 1 132 362 minecraft:honeycomb_block
setblock 2 130 323 minecraft:honeycomb_block
setblock 2 130 334 minecraft:yellow_terracotta
fill 2 130 335 2 131 335 minecraft:honeycomb_block
setblock 2 130 359 minecraft:yellow_terracotta
fill 2 130 360 3 132 360 minecraft:honeycomb_block
fill 2 130 362 3 130 362 minecraft:honeycomb_block
setblock 3 130 323 minecraft:yellow_terracotta
fill 3 130 359 3 133 359 minecraft:honeycomb_block
setblock 3 130 363 minecraft:yellow_terracotta
fill 4 130 323 7 130 323 minecraft:honeycomb_block
setblock 4 130 361 minecraft:honeycomb_block
setblock 4 130 362 minecraft:yellow_terracotta
fill 4 130 363 7 130 363 minecraft:honeycomb_block
fill 5 130 324 6 130 324 minecraft:honeycomb_block
setblock 5 130 361 minecraft:yellow_terracotta
fill 5 130 362 8 130 362 minecraft:honeycomb_block
fill 6 130 361 6 133 361 minecraft:honeycomb_block
setblock 6 130 364 minecraft:orange_terracotta
fill 7 130 360 7 133 360 minecraft:honeycomb_block
setblock 8 130 323 minecraft:yellow_terracotta
setblock 8 130 363 minecraft:yellow_terracotta
fill 9 130 323 9 133 323 minecraft:honeycomb_block
setblock 9 130 362 minecraft:yellow_terracotta
fill 9 130 363 12 130 363 minecraft:honeycomb_block
setblock 10 130 361 minecraft:yellow_terracotta
fill 10 130 362 10 133 362 minecraft:honeycomb_block
fill 11 130 361 11 131 361 minecraft:honeycomb_block
setblock 13 130 363 minecraft:yellow_terracotta
fill 14 130 363 14 133 363 minecraft:honeycomb_block
fill 21 130 363 22 130 363 minecraft:honeycomb_block
setblock 23 130 363 minecraft:yellow_terracotta
setblock 24 130 362 minecraft:yellow_terracotta
fill 24 130 363 24 133 363 minecraft:honeycomb_block
fill 25 130 362 25 133 362 minecraft:honeycomb_block
setblock 28 130 323 minecraft:honey_block
setblock 28 130 363 minecraft:yellow_terracotta
fill 29 130 363 29 133 363 minecraft:honeycomb_block
setblock 33 130 363 minecraft:honey_block
setblock 37 130 364 minecraft:yellow_terracotta
fill 38 130 364 39 154 364 minecraft:honeycomb_block
setblock 40 130 336 minecraft:yellow_terracotta
fill 40 130 337 40 133 337 minecraft:honeycomb_block
fill 40 130 339 40 131 339 minecraft:honeycomb_block
setblock 41 130 330 minecraft:yellow_terracotta
fill 41 130 331 41 133 331 minecraft:honeycomb_block
setblock 41 130 335 minecraft:yellow_terracotta
fill 41 130 336 41 133 336 minecraft:honeycomb_block
setblock 41 130 340 minecraft:yellow_terracotta
fill 41 130 341 41 133 341 minecraft:honeycomb_block
setblock 41 130 354 minecraft:honey_block
setblock 42 130 327 minecraft:yellow_terracotta
fill 42 130 335 42 132 335 minecraft:honeycomb_block
setblock 42 130 357 minecraft:yellow_concrete
fill 0 131 329 0 171 329 minecraft:honeycomb_block
fill 0 131 355 1 134 355 minecraft:honeycomb_block
setblock 1 131 323 minecraft:honeycomb_block
setblock 1 131 324 minecraft:yellow_terracotta
fill 1 131 325 1 134 325 minecraft:honeycomb_block
setblock 1 131 330 minecraft:honeycomb_block
setblock 1 131 334 minecraft:yellow_terracotta
fill 1 131 335 1 134 335 minecraft:honeycomb_block
setblock 1 131 339 minecraft:yellow_terracotta
fill 1 131 340 1 134 340 minecraft:honeycomb_block
setblock 1 131 359 minecraft:yellow_terracotta
fill 1 131 360 1 134 360 minecraft:honeycomb_block
setblock 2 131 323 minecraft:yellow_terracotta
setblock 2 131 358 minecraft:yellow_terracotta
fill 2 131 359 2 134 359 minecraft:honeycomb_block
setblock 2 131 362 minecraft:honeycomb_block
setblock 2 131 363 minecraft:yellow_terracotta
fill 2 131 364 2 213 364 minecraft:honeycomb_block
fill 3 131 323 6 131 323 minecraft:honeycomb_block
fill 3 131 358 3 134 358 minecraft:honeycomb_block
setblock 3 131 361 minecraft:honeycomb_block
setblock 3 131 362 minecraft:yellow_terracotta
fill 3 131 363 6 131 363 minecraft:honeycomb_block
setblock 3 131 364 minecraft:yellow_terracotta
setblock 4 131 361 minecraft:yellow_terracotta
fill 4 131 362 7 131 362 minecraft:honeycomb_block
setblock 5 131 324 minecraft:honeycomb_block
fill 5 131 361 5 134 361 minecraft:honeycomb_block
fill 6 131 360 6 134 360 minecraft:honeycomb_block
fill 6 131 364 6 288 364 minecraft:honeycomb_block
setblock 7 131 323 minecraft:yellow_terracotta
setblock 7 131 363 minecraft:yellow_terracotta
fill 8 131 323 8 134 323 minecraft:honeycomb_block
setblock 8 131 362 minecraft:yellow_terracotta
fill 8 131 363 11 131 363 minecraft:honeycomb_block
setblock 9 131 361 minecraft:yellow_terracotta
fill 9 131 362 9 134 362 minecraft:honeycomb_block
fill 10 131 361 10 134 361 minecraft:honeycomb_block
setblock 12 131 363 minecraft:yellow_terracotta
setblock 13 131 362 minecraft:yellow_terracotta
fill 13 131 363 13 134 363 minecraft:honeycomb_block
fill 20 131 363 21 131 363 minecraft:honeycomb_block
setblock 22 131 323 minecraft:honey_block
setblock 22 131 363 minecraft:yellow_terracotta
setblock 23 131 362 minecraft:yellow_terracotta
fill 23 131 363 23 134 363 minecraft:honeycomb_block
fill 24 131 362 24 134 362 minecraft:honeycomb_block
setblock 27 131 363 minecraft:yellow_terracotta
fill 28 131 363 28 134 363 minecraft:honeycomb_block
fill 37 131 364 37 308 364 minecraft:honeycomb_block
setblock 39 131 363 minecraft:honey_block
setblock 40 131 335 minecraft:yellow_terracotta
fill 40 131 336 40 134 336 minecraft:honeycomb_block
setblock 41 131 329 minecraft:yellow_terracotta
fill 41 131 330 41 134 330 minecraft:honeycomb_block
setblock 41 131 334 minecraft:yellow_terracotta
fill 41 131 335 41 134 335 minecraft:honeycomb_block
setblock 41 131 339 minecraft:yellow_terracotta
fill 41 131 340 41 134 340 minecraft:honeycomb_block
fill 41 131 342 41 132 342 minecraft:honeycomb_block
setblock 41 131 348 minecraft:honey_block
setblock 41 131 359 minecraft:yellow_terracotta
fill 41 131 360 41 133 361 minecraft:honeycomb_block
setblock 41 131 364 minecraft:yellow_concrete
fill 42 131 327 42 308 327 minecraft:honeycomb_block
setblock 42 131 341 minecraft:yellow_concrete
fill 42 131 357 42 167 357 minecraft:honeycomb_block
setblock 42 131 358 minecraft:orange_terracotta
setblock 42 131 359 minecraft:yellow_concrete
setblock 1 132 323 minecraft:yellow_terracotta
fill 1 132 324 1 135 324 minecraft:honeycomb_block
fill 1 132 326 1 133 326 minecraft:honeycomb_block
setblock 1 132 333 minecraft:yellow_terracotta
fill 1 132 334 1 135 334 minecraft:honeycomb_block
setblock 1 132 338 minecraft:yellow_terracotta
fill 1 132 339 1 135 339 minecraft:honeycomb_block
fill 1 132 341 1 133 341 minecraft:honeycomb_block
setblock 1 132 344 minecraft:honey_block
setblock 1 132 358 minecraft:yellow_terracotta
fill 1 132 359 1 135 359 minecraft:honeycomb_block
setblock 1 132 363 minecraft:yellow_terracotta
fill 1 132 364 1 244 364 minecraft:honeycomb_block
fill 2 132 323 5 132 323 minecraft:honeycomb_block
setblock 2 132 337 minecraft:yellow_terracotta
setblock 2 132 356 minecraft:honeycomb_block
setblock 2 132 357 minecraft:yellow_terracotta
fill 2 132 358 2 135 358 minecraft:honeycomb_block
setblock 2 132 362 minecraft:yellow_terracotta
fill 2 132 363 5 132 363 minecraft:honeycomb_block
fill 3 132 324 4 132 324 minecraft:honeycomb_block
fill 3 132 355 3 140 355 minecraft:yellow_terracotta
setblock 3 132 361 minecraft:yellow_terracotta
fill 3 132 362 6 132 362 minecraft:honeycomb_block
fill 3 132 364 3 254 364 minecraft:honeycomb_block
fill 4 132 361 4 135 361 minecraft:honeycomb_block
setblock 5 132 324 minecraft:yellow_terracotta
fill 5 132 360 5 135 360 minecraft:honeycomb_block
setblock 6 132 323 minecraft:yellow_terracotta
fill 6 132 324 6 135 324 minecraft:honeycomb_block
setblock 6 132 363 minecraft:yellow_terracotta
fill 7 132 323 7 135 323 minecraft:honeycomb_block
setblock 7 132 362 minecraft:yellow_terracotta
fill 7 132 363 10 132 363 minecraft:honeycomb_block
setblock 8 132 361 minecraft:yellow_terracotta
fill 8 132 362 8 135 362 minecraft:honeycomb_block
fill 9 132 361 9 135 361 minecraft:honeycomb_block
setblock 11 132 363 minecraft:yellow_terracotta
setblock 12 132 362 minecraft:yellow_terracotta
fill 12 132 363 12 135 363 minecraft:honeycomb_block
fill 13 132 362 13 135 362 minecraft:honeycomb_block
setblock 16 132 323 minecraft:honey_block
setblock 16 132 363 minecraft:yellow_terracotta
fill 17 132 363 20 132 363 minecraft:honeycomb_block
setblock 21 132 363 minecraft:yellow_terracotta
setblock 22 132 362 minecraft:yellow_terracotta
fill 22 132 363 22 135 363 minecraft:honeycomb_block
fill 23 132 362 23 135 362 minecraft:honeycomb_block
setblock 26 132 363 minecraft:yellow_terracotta
setblock 27 132 362 minecraft:yellow_terracotta
fill 27 132 363 27 135 363 minecraft:honeycomb_block
setblock 40 132 334 minecraft:yellow_terracotta
fill 40 132 335 40 135 335 minecraft:honeycomb_block
setblock 40 132 339 minecraft:yellow_terracotta
fill 40 132 340 40 135 340 minecraft:honeycomb_block
setblock 41 132 323 minecraft:yellow_terracotta
fill 41 132 324 41 132 327 minecraft:honeycomb_block
setblock 41 132 328 minecraft:yellow_terracotta
fill 41 132 329 41 135 329 minecraft:honeycomb_block
setblock 41 132 333 minecraft:yellow_terracotta
fill 41 132 334 41 135 334 minecraft:honeycomb_block
setblock 41 132 338 minecraft:yellow_terracotta
fill 41 132 339 41 135 339 minecraft:honeycomb_block
setblock 41 132 343 minecraft:yellow_terracotta
setblock 41 132 358 minecraft:yellow_terracotta
fill 41 132 359 42 135 359 minecraft:honeycomb_block
setblock 41 132 362 minecraft:honeycomb_block
setblock 41 132 363 minecraft:yellow_terracotta
fill 41 132 364 41 176 364 minecraft:honeycomb_block
fill 42 132 341 42 308 341 minecraft:honeycomb_block
setblock 42 132 355 minecraft:yellow_concrete
fill 42 132 356 42 141 356 minecraft:honeycomb_block
fill 42 132 358 42 237 358 minecraft:honeycomb_block
setblock 0 133 354 minecraft:yellow_concrete
fill 1 133 323 4 133 323 minecraft:honeycomb_block
setblock 1 133 327 minecraft:yellow_terracotta
fill 1 133 328 1 134 330 minecraft:honeycomb_block
setblock 1 133 332 minecraft:yellow_terracotta
fill 1 133 333 1 136 333 minecraft:honeycomb_block
setblock 1 133 337 minecraft:yellow_terracotta
fill 1 133 338 2 135 338 minecraft:honeycomb_block
setblock 1 133 342 minecraft:yellow_terracotta
setblock 1 133 350 minecraft:honey_block
setblock 1 133 357 minecraft:yellow_terracotta
fill 1 133 358 1 136 358 minecraft:honeycomb_block
setblock 1 133 361 minecraft:honeycomb_block
setblock 1 133 362 minecraft:yellow_terracotta
fill 1 133 363 4 133 363 minecraft:honeycomb_block
fill 2 133 324 3 133 324 minecraft:honeycomb_block
setblock 2 133 336 minecraft:yellow_terracotta
fill 2 133 337 2 136 337 minecraft:honeycomb_block
fill 2 133 339 2 134 339 minecraft:honeycomb_block
setblock 2 133 356 minecraft:yellow_terracotta
fill 2 133 357 2 136 357 minecraft:honeycomb_block
setblock 2 133 360 minecraft:honeycomb_block
setblock 2 133 361 minecraft:yellow_terracotta
fill 2 133 362 5 133 362 minecraft:honeycomb_block
setblock 3 133 360 minecraft:yellow_terracotta
fill 3 133 361 3 136 361 minecraft:honeycomb_block
setblock 4 133 324 minecraft:yellow_terracotta
fill 4 133 360 4 136 360 minecraft:honeycomb_block
setblock 5 133 323 minecraft:yellow_terracotta
fill 5 133 324 5 136 324 minecraft:honeycomb_block
setblock 5 133 363 minecraft:yellow_terracotta
fill 6 133 323 6 136 323 minecraft:honeycomb_block
setblock 6 133 362 minecraft:yellow_terracotta
fill 6 133 363 9 133 363 minecraft:honeycomb_block
setblock 7 133 361 minecraft:yellow_terracotta
fill 7 133 362 7 136 362 minecraft:honeycomb_block
fill 8 133 361 8 136 361 minecraft:honeycomb_block
setblock 10 133 323 minecraft:yellow_terracotta
setblock 10 133 363 minecraft:yellow_terracotta
setblock 11 133 362 minecraft:yellow_terracotta
fill 11 133 363 11 136 363 minecraft:honeycomb_block
fill 12 133 362 12 136 362 minecraft:honeycomb_block
setblock 15 133 363 minecraft:yellow_terracotta
fill 16 133 363 19 133 363 minecraft:honeycomb_block
setblock 20 133 362 minecraft:honeycomb_block
setblock 20 133 363 minecraft:yellow_terracotta
setblock 21 133 362 minecraft:yellow_terracotta
fill 21 133 363 21 136 363 minecraft:honeycomb_block
fill 22 133 362 22 136 362 minecraft:honeycomb_block
setblock 25 133 323 minecraft:yellow_terracotta
setblock 25 133 363 minecraft:yellow_terracotta
fill 26 133 323 26 136 323 minecraft:honeycomb_block
setblock 26 133 362 minecraft:yellow_terracotta
fill 26 133 363 26 136 363 minecraft:honeycomb_block
fill 27 133 362 27 136 362 minecraft:honeycomb_block
setblock 28 133 322 minecraft:yellow_terracotta
setblock 32 133 363 minecraft:honey_block
setblock 35 133 323 minecraft:honey_block
setblock 39 133 323 minecraft:honeycomb_block
setblock 40 133 323 minecraft:yellow_terracotta
fill 40 133 334 40 136 334 minecraft:honeycomb_block
setblock 40 133 338 minecraft:yellow_terracotta
fill 40 133 339 40 136 339 minecraft:honeycomb_block
fill 40 133 341 40 134 341 minecraft:honeycomb_block
setblock 40 133 363 minecraft:yellow_terracotta
fill 41 133 323 41 133 326 minecraft:honeycomb_block
setblock 41 133 327 minecraft:yellow_terracotta
fill 41 133 328 41 136 328 minecraft:honeycomb_block
setblock 41 133 332 minecraft:yellow_terracotta
fill 41 133 333 41 136 333 minecraft:honeycomb_block
setblock 41 133 337 minecraft:yellow_terracotta
fill 41 133 338 41 136 338 minecraft:honeycomb_block
setblock 41 133 342 minecraft:yellow_terracotta
fill 41 133 343 41 136 343 minecraft:honeycomb_block
setblock 41 133 357 minecraft:yellow_terracotta
fill 41 133 358 41 136 358 minecraft:honeycomb_block
setblock 41 133 362 minecraft:yellow_terracotta
fill 41 133 363 41 136 363 minecraft:honeycomb_block
setblock 42 133 323 minecraft:orange_terracotta
fill 42 133 324 42 169 324 minecraft:honeycomb_block
setblock 42 133 335 minecraft:yellow_terracotta
setblock 42 133 351 minecraft:yellow_concrete
fill 42 133 355 42 243 355 minecraft:honeycomb_block
fill 0 134 354 1 135 354 minecraft:honeycomb_block
fill 0 134 356 0 176 356 minecraft:honeycomb_block
fill 1 134 323 3 134 323 minecraft:honeycomb_block
setblock 1 134 326 minecraft:yellow_terracotta
fill 1 134 327 1 137 327 minecraft:honeycomb_block
setblock 1 134 331 minecraft:yellow_terracotta
fill 1 134 332 1 137 332 minecraft:honeycomb_block
setblock 1 134 336 minecraft:yellow_terracotta
fill 1 134 337 1 137 337 minecraft:honeycomb_block
setblock 1 134 341 minecraft:yellow_terracotta
fill 1 134 342 1 135 344 minecraft:honeycomb_block
setblock 1 134 356 minecraft:yellow_terracotta
fill 1 134 357 1 137 357 minecraft:honeycomb_block
setblock 1 134 361 minecraft:yellow_terracotta
fill 1 134 362 3 134 363 minecraft:honeycomb_block
setblock 2 134 324 minecraft:honeycomb_block
setblock 2 134 325 minecraft:yellow_terracotta
fill 2 134 326 2 137 326 minecraft:honeycomb_block
fill 2 134 336 2 137 336 minecraft:honeycomb_block
setblock 2 134 340 minecraft:yellow_terracotta
fill 2 134 341 2 137 341 minecraft:honeycomb_block
fill 2 134 356 2 137 356 minecraft:honeycomb_block
setblock 2 134 360 minecraft:yellow_terracotta
fill 2 134 361 2 137 361 minecraft:honeycomb_block
setblock 3 134 324 minecraft:yellow_terracotta
setblock 3 134 325 minecraft:light[level=12]
setblock 3 134 332 minecraft:light[level=12]
setblock 3 134 339 minecraft:light[level=12]
setblock 3 134 346 minecraft:light[level=12]
setblock 3 134 353 minecraft:light[level=12]
fill 3 134 357 3 135 357 minecraft:honeycomb_block
setblock 3 134 359 minecraft:yellow_terracotta
fill 3 134 360 3 137 360 minecraft:honeycomb_block
setblock 4 134 323 minecraft:yellow_terracotta
fill 4 134 324 4 137 324 minecraft:honeycomb_block
fill 4 134 359 4 137 359 minecraft:honeycomb_block
setblock 4 134 362 minecraft:honeycomb_block
fill 4 134 363 4 134 364 minecraft:yellow_terracotta
fill 5 134 323 5 137 323 minecraft:honeycomb_block
setblock 5 134 362 minecraft:yellow_terracotta
fill 5 134 363 8 134 363 minecraft:honeycomb_block
setblock 6 134 361 minecraft:yellow_terracotta
fill 6 134 362 6 137 362 minecraft:honeycomb_block
setblock 7 134 324 minecraft:honeycomb_block
setblock 7 134 360 minecraft:yellow_terracotta
fill 7 134 361 7 137 361 minecraft:honeycomb_block
setblock 9 134 323 minecraft:yellow_terracotta
setblock 9 134 363 minecraft:yellow_terracotta
fill 10 134 323 10 137 323 minecraft:honeycomb_block
setblock 10 134 325 minecraft:light[level=12]
setblock 10 134 332 minecraft:light[level=12]
setblock 10 134 339 minecraft:light[level=12]
setblock 10 134 346 minecraft:light[level=12]
setblock 10 134 353 minecraft:light[level=12]
setblock 10 134 360 minecraft:light[level=12]
setblock 10 134 362 minecraft:yellow_terracotta
fill 10 134 363 10 137 363 minecraft:honeycomb_block
fill 11 134 362 11 137 362 minecraft:honeycomb_block
setblock 14 134 362 minecraft:honeycomb_block
setblock 14 134 363 minecraft:yellow_terracotta
fill 15 134 363 18 134 363 minecraft:honeycomb_block
setblock 17 134 325 minecraft:light[level=12]
setblock 17 134 332 minecraft:light[level=12]
setblock 17 134 339 minecraft:light[level=12]
setblock 17 134 346 minecraft:light[level=12]
setblock 17 134 353 minecraft:light[level=12]
setblock 17 134 360 minecraft:light[level=12]
fill 18 134 362 19 134 362 minecraft:honeycomb_block
setblock 19 134 363 minecraft:yellow_terracotta
setblock 20 134 362 minecraft:yellow_terracotta
fill 20 134 363 20 137 363 minecraft:honeycomb_block
fill 21 134 362 21 137 362 minecraft:honeycomb_block
fill 22 134 323 23 134 323 minecraft:honeycomb_block
fill 23 134 361 24 135 361 minecraft:honeycomb_block
setblock 24 134 323 minecraft:yellow_terracotta
setblock 24 134 325 minecraft:light[level=12]
setblock 24 134 332 minecraft:light[level=12]
setblock 24 134 339 minecraft:light[level=12]
setblock 24 134 346 minecraft:light[level=12]
setblock 24 134 353 minecraft:light[level=12]
setblock 24 134 360 minecraft:light[level=12]
setblock 24 134 363 minecraft:yellow_terracotta
fill 25 134 323 25 137 323 minecraft:honeycomb_block
setblock 25 134 362 minecraft:yellow_terracotta
fill 25 134 363 25 137 363 minecraft:honeycomb_block
fill 26 134 362 26 137 362 minecraft:honeycomb_block
fill 27 134 323 28 134 323 minecraft:honeycomb_block
fill 28 134 322 28 165 322 minecraft:honeycomb_block
setblock 29 134 323 minecraft:honey_block
setblock 29 134 363 minecraft:yellow_terracotta
fill 30 134 324 30 138 324 minecraft:iron_block
fill 30 134 363 30 137 363 minecraft:honeycomb_block
setblock 31 134 325 minecraft:light[level=12]
setblock 31 134 332 minecraft:light[level=12]
setblock 31 134 339 minecraft:light[level=12]
setblock 31 134 346 minecraft:light[level=12]
fill 31 134 349 32 135 349 minecraft:yellow_concrete
setblock 31 134 353 minecraft:light[level=12]
setblock 31 134 360 minecraft:light[level=12]
setblock 38 134 323 minecraft:honeycomb_block
setblock 38 134 325 minecraft:light[level=12]
setblock 38 134 332 minecraft:light[level=12]
setblock 38 134 339 minecraft:light[level=12]
setblock 38 134 346 minecraft:light[level=12]
setblock 38 134 353 minecraft:light[level=12]
setblock 38 134 360 minecraft:light[level=12]
setblock 38 134 363 minecraft:honeycomb_block
setblock 39 134 323 minecraft:yellow_terracotta
setblock 39 134 363 minecraft:yellow_terracotta
fill 40 134 323 41 135 324 minecraft:honeycomb_block
fill 40 134 333 40 137 333 minecraft:honeycomb_block
setblock 40 134 337 minecraft:yellow_terracotta
fill 40 134 338 40 137 338 minecraft:honeycomb_block
setblock 40 134 342 minecraft:yellow_terracotta
fill 40 134 363 40 137 363 minecraft:honeycomb_block
setblock 41 134 325 minecraft:honeycomb_block
setblock 41 134 326 minecraft:yellow_terracotta
fill 41 134 327 41 137 327 minecraft:honeycomb_block
setblock 41 134 331 minecraft:yellow_terracotta
fill 41 134 332 41 137 332 minecraft:honeycomb_block
setblock 41 134 336 minecraft:yellow_terracotta
fill 41 134 337 41 137 337 minecraft:honeycomb_block
setblock 41 134 341 minecraft:yellow_terracotta
fill 41 134 342 41 137 342 minecraft:honeycomb_block
fill 41 134 344 41 134 345 minecraft:honeycomb_block
setblock 41 134 355 minecraft:honey_block
fill 41 134 357 41 137 357 minecraft:honeycomb_block
setblock 41 134 360 minecraft:honeycomb_block
setblock 41 134 361 minecraft:yellow_terracotta
fill 41 134 362 41 137 362 minecraft:honeycomb_block
fill 42 134 323 42 144 323 minecraft:honeycomb_block
fill 42 134 335 42 176 335 minecraft:honeycomb_block
fill 42 134 351 42 145 351 minecraft:honeycomb_block
fill 0 135 355 0 158 355 minecraft:honeycomb_block
fill 1 135 323 2 135 323 minecraft:honeycomb_block
setblock 1 135 325 minecraft:yellow_terracotta
fill 1 135 326 1 138 326 minecraft:honeycomb_block
fill 1 135 328 1 135 329 minecraft:honeycomb_block
setblock 1 135 330 minecraft:yellow_terracotta
fill 1 135 331 1 138 331 minecraft:honeycomb_block
setblock 1 135 335 minecraft:yellow_terracotta
fill 1 135 336 1 138 336 minecraft:honeycomb_block
setblock 1 135 340 minecraft:yellow_terracotta
fill 1 135 341 1 138 341 minecraft:honeycomb_block
setblock 1 135 345 minecraft:yellow_terracotta
fill 1 135 346 1 138 346 minecraft:honeycomb_block
fill 1 135 353 1 136 353 minecraft:honeycomb_block
setblock 1 135 355 minecraft:yellow_terracotta
fill 1 135 356 1 138 356 minecraft:honeycomb_block
setblock 1 135 360 minecraft:yellow_terracotta
fill 1 135 361 1 136 363 minecraft:honeycomb_block
setblock 2 135 324 minecraft:yellow_terracotta
fill 2 135 325 2 138 325 minecraft:honeycomb_block
fill 2 135 327 2 136 327 minecraft:honeycomb_block
setblock 2 135 339 minecraft:yellow_terracotta
fill 2 135 340 2 138 340 minecraft:honeycomb_block
fill 2 135 342 2 135 343 minecraft:honeycomb_block
fill 2 135 355 2 138 355 minecraft:honeycomb_block
setblock 2 135 359 minecraft:yellow_terracotta
fill 2 135 360 2 138 360 minecraft:honeycomb_block
fill 2 135 362 2 135 363 minecraft:honeycomb_block
setblock 3 135 323 minecraft:yellow_terracotta
fill 3 135 324 3 138 324 minecraft:honeycomb_block
setblock 3 135 358 minecraft:yellow_terracotta
fill 3 135 359 3 138 359 minecraft:honeycomb_block
setblock 3 135 362 minecraft:honeycomb_block
setblock 3 135 363 minecraft:yellow_terracotta
fill 4 135 323 4 138 323 minecraft:honeycomb_block
setblock 4 135 362 minecraft:yellow_terracotta
fill 4 135 363 4 138 364 minecraft:honeycomb_block
setblock 5 135 361 minecraft:yellow_terracotta
fill 5 135 362 5 137 363 minecraft:honeycomb_block
setblock 6 135 360 minecraft:yellow_terracotta
fill 6 135 361 6 138 361 minecraft:honeycomb_block
fill 6 135 363 7 135 363 minecraft:honeycomb_block
setblock 7 135 324 minecraft:yellow_terracotta
fill 7 135 360 7 136 360 minecraft:honeycomb_block
setblock 8 135 323 minecraft:yellow_terracotta
setblock 8 135 363 minecraft:yellow_terracotta
fill 9 135 323 9 138 323 minecraft:honeycomb_block
setblock 9 135 362 minecraft:yellow_terracotta
fill 9 135 363 9 138 363 minecraft:honeycomb_block
setblock 10 135 361 minecraft:yellow_terracotta
fill 10 135 362 10 138 362 minecraft:honeycomb_block
setblock 13 135 363 minecraft:yellow_terracotta
setblock 14 135 362 minecraft:yellow_terracotta
fill 14 135 363 17 135 363 minecraft:honeycomb_block
fill 15 135 362 18 135 362 minecraft:honeycomb_block
setblock 17 135 323 minecraft:honey_block
setblock 18 135 363 minecraft:yellow_terracotta
setblock 19 135 362 minecraft:yellow_terracotta
fill 19 135 363 19 138 363 minecraft:honeycomb_block
fill 20 135 323 22 135 323 minecraft:honeycomb_block
fill 20 135 362 20 138 362 minecraft:honeycomb_block
fill 21 135 361 22 137 361 minecraft:honeycomb_block
setblock 23 135 323 minecraft:yellow_terracotta
setblock 23 135 363 minecraft:yellow_terracotta
fill 24 135 323 24 138 323 minecraft:honeycomb_block
setblock 24 135 362 minecraft:yellow_terracotta
fill 24 135 363 24 138 363 minecraft:honeycomb_block
fill 25 135 362 25 138 362 minecraft:honeycomb_block
setblock 27 135 323 minecraft:honeycomb_block
setblock 28 135 323 minecraft:yellow_terracotta
setblock 28 135 362 minecraft:honeycomb_block
setblock 28 135 363 minecraft:yellow_terracotta
fill 29 135 323 30 137 323 minecraft:honeycomb_block
fill 29 135 363 29 138 363 minecraft:honeycomb_block
fill 35 135 323 37 135 323 minecraft:honeycomb_block
setblock 37 135 363 minecraft:honeycomb_block
setblock 38 135 323 minecraft:yellow_terracotta
setblock 38 135 363 minecraft:yellow_terracotta
fill 39 135 323 39 137 324 minecraft:honeycomb_block
setblock 39 135 362 minecraft:yellow_terracotta
fill 39 135 363 39 138 363 minecraft:honeycomb_block
setblock 40 135 325 minecraft:honeycomb_block
setblock 40 135 326 minecraft:yellow_terracotta
fill 40 135 327 40 138 327 minecraft:honeycomb_block
fill 40 135 332 40 138 332 minecraft:honeycomb_block
setblock 40 135 336 minecraft:yellow_terracotta
fill 40 135 337 40 138 337 minecraft:honeycomb_block
setblock 40 135 341 minecraft:yellow_terracotta
fill 40 135 342 40 137 343 minecraft:honeycomb_block
setblock 40 135 360 minecraft:honeycomb_block
setblock 40 135 361 minecraft:yellow_terracotta
fill 40 135 362 40 138 362 minecraft:honeycomb_block
setblock 41 135 325 minecraft:yellow_terracotta
fill 41 135 326 41 138 326 minecraft:honeycomb_block
setblock 41 135 330 minecraft:yellow_terracotta
fill 41 135 331 41 138 331 minecraft:honeycomb_block
setblock 41 135 335 minecraft:yellow_terracotta
fill 41 135 336 41 138 336 minecraft:honeycomb_block
setblock 41 135 340 minecraft:yellow_terracotta
fill 41 135 341 41 138 341 minecraft:honeycomb_block
setblock 41 135 344 minecraft:honeycomb_block
setblock 41 135 345 minecraft:yellow_terracotta
fill 41 135 346 41 138 346 minecraft:honeycomb_block
setblock 41 135 349 minecraft:honey_block
fill 41 135 356 41 138 356 minecraft:honeycomb_block
setblock 41 135 360 minecraft:yellow_terracotta
fill 41 135 361 41 138 361 minecraft:honeycomb_block
setblock 0 136 349 minecraft:orange_terracotta
fill 0 136 354 0 144 354 minecraft:honeycomb_block
setblock 1 136 323 minecraft:honeycomb_block
setblock 1 136 324 minecraft:yellow_terracotta
fill 1 136 325 1 139 325 minecraft:honeycomb_block
setblock 1 136 328 minecraft:honeycomb_block
setblock 1 136 329 minecraft:yellow_terracotta
fill 1 136 330 1 139 330 minecraft:honeycomb_block
setblock 1 136 334 minecraft:yellow_terracotta
fill 1 136 335 1 139 335 minecraft:honeycomb_block
setblock 1 136 338 minecraft:honeycomb_block
setblock 1 136 339 minecraft:yellow_terracotta
fill 1 136 340 1 139 340 minecraft:honeycomb_block
fill 1 136 342 1 136 343 minecraft:honeycomb_block
setblock 1 136 344 minecraft:yellow_terracotta
fill 1 136 345 2 138 345 minecraft:honeycomb_block
fill 1 136 347 1 136 348 minecraft:honeycomb_block
setblock 1 136 349 minecraft:yellow_terracotta
fill 1 136 350 1 137 352 minecraft:honeycomb_block
setblock 1 136 354 minecraft:yellow_terracotta
fill 1 136 355 1 139 355 minecraft:honeycomb_block
setblock 1 136 359 minecraft:yellow_terracotta
fill 1 136 360 1 139 360 minecraft:honeycomb_block
setblock 2 136 323 minecraft:yellow_terracotta
fill 2 136 324 2 139 324 minecraft:honeycomb_block
setblock 2 136 328 minecraft:yellow_terracotta
setblock 2 136 338 minecraft:yellow_terracotta
fill 2 136 339 2 139 339 minecraft:honeycomb_block
setblock 2 136 342 minecraft:honeycomb_block
setblock 2 136 343 minecraft:yellow_terracotta
fill 2 136 344 2 139 344 minecraft:honeycomb_block
setblock 2 136 358 minecraft:yellow_terracotta
fill 2 136 359 2 139 359 minecraft:honeycomb_block
setblock 2 136 362 minecraft:honeycomb_block
setblock 2 136 363 minecraft:yellow_terracotta
fill 3 136 323 3 139 323 minecraft:honeycomb_block
fill 3 136 325 4 136 325 minecraft:honeycomb_block
setblock 3 136 333 minecraft:light[level=15]
setblock 3 136 341 minecraft:light[level=15]
setblock 3 136 349 minecraft:light[level=15]
setblock 3 136 357 minecraft:yellow_terracotta
fill 3 136 358 3 139 358 minecraft:honeycomb_block
setblock 3 136 362 minecraft:yellow_terracotta
fill 3 136 363 3 139 363 minecraft:honeycomb_block
setblock 4 136 361 minecraft:yellow_terracotta
fill 4 136 362 4 139 362 minecraft:honeycomb_block
setblock 5 136 360 minecraft:yellow_terracotta
fill 5 136 361 5 139 361 minecraft:honeycomb_block
setblock 6 136 324 minecraft:yellow_terracotta
fill 6 136 360 6 138 360 minecraft:honeycomb_block
setblock 6 136 363 minecraft:honeycomb_block
setblock 7 136 323 minecraft:yellow_terracotta
fill 7 136 324 8 138 324 minecraft:honeycomb_block
setblock 7 136 363 minecraft:yellow_terracotta
fill 8 136 323 8 139 323 minecraft:honeycomb_block
setblock 8 136 362 minecraft:yellow_terracotta
fill 8 136 363 8 139 363 minecraft:honeycomb_block
setblock 9 136 361 minecraft:yellow_terracotta
fill 9 136 362 9 139 362 minecraft:honeycomb_block
fill 10 136 361 10 137 361 minecraft:honeycomb_block
setblock 11 136 323 minecraft:honeycomb_block
setblock 11 136 325 minecraft:light[level=15]
setblock 11 136 333 minecraft:light[level=15]
setblock 11 136 341 minecraft:light[level=15]
setblock 11 136 349 minecraft:light[level=15]
setblock 11 136 357 minecraft:light[level=15]
setblock 12 136 363 minecraft:yellow_terracotta
setblock 13 136 362 minecraft:yellow_terracotta
fill 13 136 363 16 136 363 minecraft:honeycomb_block
fill 14 136 362 17 136 362 minecraft:honeycomb_block
setblock 17 136 363 minecraft:yellow_terracotta
fill 18 136 323 21 136 323 minecraft:honeycomb_block
setblock 18 136 362 minecraft:yellow_terracotta
fill 18 136 363 18 139 363 minecraft:honeycomb_block
setblock 19 136 325 minecraft:light[level=15]
setblock 19 136 333 minecraft:light[level=15]
setblock 19 136 341 minecraft:light[level=15]
setblock 19 136 349 minecraft:light[level=15]
setblock 19 136 357 minecraft:light[level=15]
fill 19 136 362 19 139 362 minecraft:honeycomb_block
fill 20 136 361 20 139 361 minecraft:honeycomb_block
setblock 22 136 323 minecraft:yellow_terracotta
setblock 22 136 363 minecraft:yellow_terracotta
fill 23 136 323 23 138 324 minecraft:honeycomb_block
setblock 23 136 361 minecraft:honeycomb_block
setblock 23 136 362 minecraft:yellow_terracotta
fill 23 136 363 23 139 363 minecraft:honeycomb_block
fill 24 136 324 25 136 324 minecraft:honeycomb_block
setblock 24 136 361 minecraft:yellow_terracotta
fill 24 136 362 24 139 362 minecraft:honeycomb_block
setblock 26 136 324 minecraft:yellow_terracotta
setblock 27 136 323 minecraft:yellow_terracotta
setblock 27 136 325 minecraft:light[level=15]
setblock 27 136 333 minecraft:light[level=15]
setblock 27 136 341 minecraft:light[level=15]
setblock 27 136 349 minecraft:light[level=15]
setblock 27 136 357 minecraft:light[level=15]
setblock 27 136 363 minecraft:yellow_terracotta
fill 28 136 323 28 139 323 minecraft:honeycomb_block
setblock 28 136 362 minecraft:yellow_terracotta
fill 28 136 363 28 139 363 minecraft:honeycomb_block
setblock 31 136 323 minecraft:honeycomb_block
setblock 31 136 363 minecraft:honeycomb_block
setblock 32 136 323 minecraft:yellow_terracotta
fill 33 136 323 36 136 323 minecraft:honeycomb_block
setblock 35 136 325 minecraft:light[level=15]
setblock 35 136 333 minecraft:light[level=15]
setblock 35 136 341 minecraft:light[level=15]
setblock 35 136 349 minecraft:light[level=15]
setblock 35 136 357 minecraft:light[level=15]
fill 35 136 363 36 136 363 minecraft:honeycomb_block
setblock 37 136 323 minecraft:yellow_terracotta
fill 37 136 324 38 138 324 minecraft:honeycomb_block
setblock 37 136 363 minecraft:yellow_terracotta
fill 38 136 323 38 139 323 minecraft:honeycomb_block
setblock 38 136 362 minecraft:yellow_terracotta
fill 38 136 363 38 139 363 minecraft:honeycomb_block
fill 39 136 338 39 136 340 minecraft:honeycomb_block
fill 39 136 362 39 139 362 minecraft:honeycomb_block
fill 40 136 323 40 136 324 minecraft:honeycomb_block
setblock 40 136 325 minecraft:yellow_terracotta
fill 40 136 326 40 139 326 minecraft:honeycomb_block
fill 40 136 328 40 136 329 minecraft:honeycomb_block
setblock 40 136 330 minecraft:yellow_terracotta
fill 40 136 331 40 139 331 minecraft:honeycomb_block
setblock 40 136 335 minecraft:yellow_terracotta
fill 40 136 336 40 139 336 minecraft:honeycomb_block
setblock 40 136 340 minecraft:yellow_terracotta
fill 40 136 341 40 139 341 minecraft:honeycomb_block
setblock 40 136 344 minecraft:honeycomb_block
setblock 40 136 359 minecraft:honeycomb_block
setblock 40 136 360 minecraft:yellow_terracotta
fill 40 136 361 40 139 361 minecraft:honeycomb_block
setblock 41 136 323 minecraft:honeycomb_block
setblock 41 136 324 minecraft:yellow_terracotta
fill 41 136 325 41 139 325 minecraft:honeycomb_block
setblock 41 136 329 minecraft:yellow_terracotta
fill 41 136 330 41 139 330 minecraft:honeycomb_block
setblock 41 136 334 minecraft:yellow_terracotta
fill 41 136 335 41 139 335 minecraft:honeycomb_block
setblock 41 136 339 minecraft:yellow_terracotta
fill 41 136 340 41 139 340 minecraft:honeycomb_block
setblock 41 136 344 minecraft:yellow_terracotta
fill 41 136 345 41 139 345 minecraft:honeycomb_block
fill 41 136 347 41 137 347 minecraft:honeycomb_block
setblock 41 136 359 minecraft:yellow_terracotta
fill 41 136 360 41 139 360 minecraft:honeycomb_block
setblock 42 136 352 minecraft:orange_terracotta
fill 42 136 359 42 308 359 minecraft:honeycomb_block
fill 0 137 330 0 138 330 minecraft:yellow_terracotta
setblock 0 137 341 minecraft:yellow_terracotta
fill 0 137 349 1 140 349 minecraft:honeycomb_block
setblock 1 137 323 minecraft:yellow_terracotta
fill 1 137 324 1 140 324 minecraft:honeycomb_block
setblock 1 137 328 minecraft:yellow_terracotta
fill 1 137 329 2 139 329 minecraft:honeycomb_block
setblock 1 137 333 minecraft:yellow_terracotta
fill 1 137 334 1 140 334 minecraft:honeycomb_block
setblock 1 137 338 minecraft:yellow_terracotta
fill 1 137 339 1 140 339 minecraft:honeycomb_block
setblock 1 137 342 minecraft:honeycomb_block
setblock 1 137 343 minecraft:yellow_terracotta
fill 1 137 344 1 140 344 minecraft:honeycomb_block
setblock 1 137 347 minecraft:honeycomb_block
setblock 1 137 348 minecraft:yellow_terracotta
setblock 1 137 353 minecraft:yellow_terracotta
fill 1 137 354 2 139 354 minecraft:honeycomb_block
setblock 1 137 358 minecraft:yellow_terracotta
fill 1 137 359 1 140 359 minecraft:honeycomb_block
fill 1 137 361 1 137 362 minecraft:honeycomb_block
setblock 1 137 363 minecraft:yellow_terracotta
fill 2 137 323 2 140 323 minecraft:honeycomb_block
setblock 2 137 327 minecraft:yellow_terracotta
fill 2 137 328 2 140 328 minecraft:honeycomb_block
setblock 2 137 337 minecraft:yellow_terracotta
fill 2 137 338 2 139 338 minecraft:honeycomb_block
setblock 2 137 342 minecraft:yellow_terracotta
fill 2 137 343 3 139 343 minecraft:honeycomb_block
setblock 2 137 346 minecraft:honeycomb_block
setblock 2 137 347 minecraft:yellow_terracotta
fill 2 137 348 2 140 348 minecraft:honeycomb_block
setblock 2 137 357 minecraft:yellow_terracotta
fill 2 137 358 2 140 358 minecraft:honeycomb_block
setblock 2 137 362 minecraft:yellow_terracotta
fill 2 137 363 2 140 363 minecraft:honeycomb_block
setblock 3 137 325 minecraft:honeycomb_block
setblock 3 137 326 minecraft:yellow_terracotta
setblock 3 137 341 minecraft:yellow_terracotta
fill 3 137 342 3 139 342 minecraft:honeycomb_block
setblock 3 137 356 minecraft:yellow_terracotta
fill 3 137 357 3 140 357 minecraft:honeycomb_block
setblock 3 137 361 minecraft:yellow_terracotta
fill 3 137 362 3 140 362 minecraft:honeycomb_block
setblock 4 137 325 minecraft:yellow_terracotta
setblock 4 137 360 minecraft:yellow_terracotta
fill 4 137 361 4 140 361 minecraft:honeycomb_block
setblock 5 137 324 minecraft:yellow_terracotta
fill 5 137 325 5 140 325 minecraft:honeycomb_block
fill 5 137 360 5 139 360 minecraft:honeycomb_block
setblock 6 137 323 minecraft:yellow_terracotta
fill 6 137 324 6 140 324 minecraft:honeycomb_block
setblock 6 137 363 minecraft:yellow_terracotta
fill 7 137 323 7 140 323 minecraft:honeycomb_block
setblock 7 137 362 minecraft:yellow_terracotta
fill 7 137 363 7 140 363 minecraft:honeycomb_block
setblock 7 137 364 minecraft:yellow_terracotta
setblock 8 137 361 minecraft:yellow_terracotta
fill 8 137 362 8 140 362 minecraft:honeycomb_block
fill 9 137 361 9 138 361 minecraft:honeycomb_block
setblock 11 137 323 minecraft:yellow_terracotta
setblock 11 137 363 minecraft:yellow_terracotta
fill 12 137 323 12 140 323 minecraft:honeycomb_block
setblock 12 137 362 minecraft:yellow_terracotta
fill 12 137 363 15 137 363 minecraft:honeycomb_block
fill 13 137 362 16 137 362 minecraft:honeycomb_block
setblock 16 137 323 minecraft:yellow_terracotta
setblock 16 137 363 minecraft:yellow_terracotta
fill 17 137 323 20 137 323 minecraft:honeycomb_block
setblock 17 137 362 minecraft:yellow_terracotta
fill 17 137 363 17 140 363 minecraft:honeycomb_block
fill 18 137 362 18 140 362 minecraft:honeycomb_block
fill 19 137 361 19 139 361 minecraft:honeycomb_block
setblock 21 137 323 minecraft:yellow_terracotta
fill 21 137 324 22 139 324 minecraft:honeycomb_block
setblock 21 137 363 minecraft:yellow_terracotta
fill 22 137 323 22 140 323 minecraft:honeycomb_block
setblock 22 137 362 minecraft:yellow_terracotta
fill 22 137 363 22 140 363 minecraft:honeycomb_block
setblock 23 137 361 minecraft:yellow_terracotta
fill 23 137 362 23 140 362 minecraft:honeycomb_block
setblock 24 137 324 minecraft:honeycomb_block
setblock 24 137 361 minecraft:honeycomb_block
setblock 25 137 324 minecraft:yellow_terracotta
setblock 26 137 323 minecraft:yellow_terracotta
fill 26 137 324 27 139 324 minecraft:honeycomb_block
setblock 26 137 363 minecraft:yellow_terracotta
fill 27 137 323 27 140 323 minecraft:honeycomb_block
setblock 27 137 362 minecraft:yellow_terracotta
fill 27 137 363 27 140 363 minecraft:honeycomb_block
setblock 31 137 323 minecraft:yellow_terracotta
setblock 31 137 363 minecraft:yellow_terracotta
fill 32 137 323 35 137 323 minecraft:honeycomb_block
fill 32 137 363 35 137 363 minecraft:honeycomb_block
setblock 35 137 324 minecraft:yellow_terracotta
setblock 36 137 323 minecraft:yellow_terracotta
fill 36 137 324 36 140 324 minecraft:honeycomb_block
setblock 36 137 363 minecraft:yellow_terracotta
fill 37 137 323 37 140 323 minecraft:honeycomb_block
setblock 37 137 362 minecraft:yellow_terracotta
fill 37 137 363 37 140 363 minecraft:honeycomb_block
fill 38 137 362 38 140 362 minecraft:honeycomb_block
setblock 39 137 325 minecraft:yellow_terracotta
fill 39 137 326 39 140 326 minecraft:honeycomb_block
fill 39 137 338 39 137 339 minecraft:honeycomb_block
setblock 39 137 340 minecraft:yellow_terracotta
fill 39 137 341 39 139 342 minecraft:honeycomb_block
setblock 40 137 323 minecraft:honeycomb_block
setblock 40 137 324 minecraft:yellow_terracotta
fill 40 137 325 40 140 325 minecraft:honeycomb_block
setblock 40 137 328 minecraft:honeycomb_block
setblock 40 137 329 minecraft:yellow_terracotta
fill 40 137 330 40 140 330 minecraft:honeycomb_block
setblock 40 137 334 minecraft:yellow_terracotta
fill 40 137 335 40 140 335 minecraft:honeycomb_block
setblock 40 137 339 minecraft:yellow_terracotta
fill 40 137 340 40 140 340 minecraft:honeycomb_block
setblock 40 137 344 minecraft:yellow_terracotta
fill 40 137 345 40 139 346 minecraft:honeycomb_block
setblock 40 137 359 minecraft:yellow_terracotta
fill 40 137 360 40 140 360 minecraft:honeycomb_block
setblock 41 137 323 minecraft:yellow_terracotta
fill 41 137 324 41 140 324 minecraft:honeycomb_block
setblock 41 137 328 minecraft:yellow_terracotta
fill 41 137 329 41 140 329 minecraft:honeycomb_block
setblock 41 137 333 minecraft:yellow_terracotta
fill 41 137 334 41 140 334 minecraft:honeycomb_block
setblock 41 137 338 minecraft:yellow_terracotta
fill 41 137 339 41 140 339 minecraft:honeycomb_block
setblock 41 137 343 minecraft:yellow_terracotta
fill 41 137 344 41 140 344 minecraft:honeycomb_block
setblock 41 137 348 minecraft:yellow_terracotta
fill 41 137 349 41 140 349 minecraft:honeycomb_block
fill 41 137 355 41 139 355 minecraft:honeycomb_block
setblock 41 137 358 minecraft:yellow_terracotta
fill 41 137 359 41 140 359 minecraft:honeycomb_block
setblock 41 137 363 minecraft:yellow_terracotta
setblock 42 137 334 minecraft:orange_terracotta
fill 42 137 352 42 191 352 minecraft:honeycomb_block
setblock 0 138 340 minecraft:orange_terracotta
fill 0 138 341 0 260 341 minecraft:honeycomb_block
fill 1 138 323 1 141 323 minecraft:honeycomb_block
setblock 1 138 327 minecraft:yellow_terracotta
fill 1 138 328 1 141 328 minecraft:honeycomb_block
setblock 1 138 332 minecraft:yellow_terracotta
fill 1 138 333 1 141 333 minecraft:honeycomb_block
setblock 1 138 337 minecraft:yellow_terracotta
fill 1 138 338 1 141 338 minecraft:honeycomb_block
setblock 1 138 342 minecraft:yellow_terracotta
fill 1 138 343 1 141 343 minecraft:honeycomb_block
setblock 1 138 347 minecraft:yellow_terracotta
fill 1 138 348 1 141 348 minecraft:honeycomb_block
fill 1 138 350 1 138 351 minecraft:honeycomb_block
setblock 1 138 352 minecraft:yellow_terracotta
fill 1 138 353 2 140 353 minecraft:honeycomb_block
setblock 1 138 357 minecraft:yellow_terracotta
fill 1 138 358 1 141 358 minecraft:honeycomb_block
setblock 1 138 361 minecraft:honeycomb_block
setblock 1 138 362 minecraft:yellow_terracotta
fill 1 138 363 1 141 363 minecraft:honeycomb_block
setblock 2 138 326 minecraft:yellow_terracotta
fill 2 138 327 2 141 327 minecraft:honeycomb_block
setblock 2 138 337 minecraft:honeycomb_block
setblock 2 138 341 minecraft:yellow_terracotta
fill 2 138 342 2 141 342 minecraft:honeycomb_block
setblock 2 138 346 minecraft:yellow_terracotta
fill 2 138 347 2 141 347 minecraft:honeycomb_block
fill 2 138 349 2 138 350 minecraft:honeycomb_block
setblock 2 138 351 minecraft:yellow_terracotta
fill 2 138 352 2 141 352 minecraft:honeycomb_block
setblock 2 138 356 minecraft:yellow_terracotta
fill 2 138 357 2 141 357 minecraft:honeycomb_block
setblock 2 138 361 minecraft:yellow_terracotta
fill 2 138 362 2 141 362 minecraft:honeycomb_block
setblock 3 138 325 minecraft:yellow_terracotta
fill 3 138 326 3 141 326 minecraft:honeycomb_block
fill 3 138 341 3 139 341 minecraft:honeycomb_block
setblock 3 138 344 minecraft:honeycomb_block
setblock 3 138 345 minecraft:yellow_terracotta
fill 3 138 346 3 141 346 minecraft:honeycomb_block
fill 3 138 354 3 140 354 minecraft:yellow_terracotta
setblock 3 138 356 minecraft:honeycomb_block
setblock 3 138 360 minecraft:yellow_terracotta
fill 3 138 361 3 141 361 minecraft:honeycomb_block
setblock 4 138 324 minecraft:yellow_terracotta
fill 4 138 325 4 141 325 minecraft:honeycomb_block
fill 4 138 355 4 140 355 minecraft:yellow_terracotta
setblock 4 138 359 minecraft:yellow_terracotta
fill 4 138 360 4 139 360 minecraft:honeycomb_block
setblock 5 138 323 minecraft:yellow_terracotta
fill 5 138 324 5 141 324 minecraft:honeycomb_block
setblock 5 138 362 minecraft:honeycomb_block
setblock 5 138 363 minecraft:yellow_terracotta
fill 6 138 323 6 141 323 minecraft:honeycomb_block
setblock 6 138 362 minecraft:yellow_terracotta
fill 6 138 363 6 141 363 minecraft:honeycomb_block
setblock 7 138 361 minecraft:yellow_terracotta
fill 7 138 362 7 141 362 minecraft:honeycomb_block
fill 7 138 364 7 197 364 minecraft:honeycomb_block
fill 8 138 361 8 139 361 minecraft:honeycomb_block
setblock 10 138 323 minecraft:yellow_terracotta
setblock 10 138 363 minecraft:yellow_terracotta
fill 11 138 323 11 141 323 minecraft:honeycomb_block
setblock 11 138 362 minecraft:yellow_terracotta
fill 11 138 363 14 138 363 minecraft:honeycomb_block
fill 12 138 362 15 138 362 minecraft:honeycomb_block
fill 13 138 323 14 138 323 minecraft:honeycomb_block
setblock 15 138 323 minecraft:yellow_terracotta
setblock 15 138 363 minecraft:yellow_terracotta
fill 16 138 323 19 138 323 minecraft:honeycomb_block
setblock 16 138 362 minecraft:yellow_terracotta
fill 16 138 363 16 141 363 minecraft:honeycomb_block
fill 17 138 362 17 141 362 minecraft:honeycomb_block
setblock 19 138 324 minecraft:yellow_terracotta
setblock 20 138 323 minecraft:yellow_terracotta
fill 20 138 324 20 141 324 minecraft:honeycomb_block
setblock 20 138 363 minecraft:yellow_terracotta
fill 21 138 323 21 141 323 minecraft:honeycomb_block
setblock 21 138 361 minecraft:honeycomb_block
setblock 21 138 362 minecraft:yellow_terracotta
fill 21 138 363 21 141 363 minecraft:honeycomb_block
setblock 22 138 361 minecraft:yellow_terracotta
fill 22 138 362 22 141 362 minecraft:honeycomb_block
setblock 23 138 361 minecraft:honeycomb_block
setblock 24 138 324 minecraft:yellow_terracotta
setblock 25 138 323 minecraft:yellow_terracotta
fill 25 138 324 25 141 324 minecraft:honeycomb_block
setblock 25 138 363 minecraft:yellow_terracotta
fill 26 138 323 26 141 323 minecraft:honeycomb_block
setblock 26 138 362 minecraft:yellow_terracotta
fill 26 138 363 26 141 363 minecraft:honeycomb_block
setblock 27 138 362 minecraft:honeycomb_block
setblock 28 138 324 minecraft:honeycomb_block
setblock 29 138 323 minecraft:honeycomb_block
setblock 29 138 324 minecraft:yellow_terracotta
setblock 30 138 323 minecraft:yellow_terracotta
setblock 30 138 363 minecraft:yellow_terracotta
fill 31 138 323 34 138 323 minecraft:honeycomb_block
fill 31 138 363 34 138 363 minecraft:honeycomb_block
setblock 33 138 324 minecraft:honeycomb_block
setblock 34 138 324 minecraft:yellow_terracotta
setblock 35 138 323 minecraft:yellow_terracotta
fill 35 138 324 35 141 324 minecraft:honeycomb_block
setblock 35 138 363 minecraft:yellow_terracotta
fill 36 138 323 36 141 323 minecraft:honeycomb_block
fill 36 138 363 36 141 363 minecraft:honeycomb_block
setblock 37 138 325 minecraft:honeycomb_block
fill 37 138 362 37 141 362 minecraft:honeycomb_block
setblock 38 138 325 minecraft:yellow_terracotta
setblock 39 138 323 minecraft:honeycomb_block
setblock 39 138 324 minecraft:yellow_terracotta
fill 39 138 325 39 141 325 minecraft:honeycomb_block
fill 39 138 327 39 138 328 minecraft:honeycomb_block
setblock 39 138 338 minecraft:honeycomb_block
setblock 39 138 339 minecraft:yellow_terracotta
fill 39 138 340 39 140 340 minecraft:honeycomb_block
setblock 39 138 343 minecraft:honeycomb_block
setblock 40 138 323 minecraft:yellow_terracotta
fill 40 138 324 40 141 324 minecraft:honeycomb_block
setblock 40 138 328 minecraft:yellow_terracotta
fill 40 138 329 40 141 329 minecraft:honeycomb_block
setblock 40 138 333 minecraft:yellow_terracotta
fill 40 138 334 40 141 334 minecraft:honeycomb_block
setblock 40 138 338 minecraft:yellow_terracotta
fill 40 138 339 40 141 339 minecraft:honeycomb_block
setblock 40 138 342 minecraft:honeycomb_block
setblock 40 138 343 minecraft:yellow_terracotta
fill 40 138 344 40 141 344 minecraft:honeycomb_block
setblock 40 138 347 minecraft:honeycomb_block
setblock 40 138 358 minecraft:yellow_terracotta
fill 40 138 359 40 141 359 minecraft:honeycomb_block
setblock 40 138 363 minecraft:yellow_terracotta
fill 41 138 323 41 141 323 minecraft:honeycomb_block
setblock 41 138 327 minecraft:yellow_terracotta
fill 41 138 328 41 141 328 minecraft:honeycomb_block
setblock 41 138 332 minecraft:yellow_terracotta
fill 41 138 333 41 141 333 minecraft:honeycomb_block
setblock 41 138 337 minecraft:yellow_terracotta
fill 41 138 338 41 141 338 minecraft:honeycomb_block
setblock 41 138 342 minecraft:yellow_terracotta
fill 41 138 343 41 141 343 minecraft:honeycomb_block
setblock 41 138 347 minecraft:yellow_terracotta
fill 41 138 348 41 141 348 minecraft:honeycomb_block
fill 41 138 350 41 138 351 minecraft:honeycomb_block
fill 41 138 354 41 140 354 minecraft:honeycomb_block
setblock 41 138 357 minecraft:yellow_terracotta
fill 41 138 358 41 141 358 minecraft:honeycomb_block
setblock 41 138 362 minecraft:yellow_terracotta
fill 41 138 363 41 141 363 minecraft:honeycomb_block
fill 42 138 334 42 254 334 minecraft:honeycomb_block
fill 0 139 330 0 162 330 minecraft:honeycomb_block
fill 0 139 340 0 218 340 minecraft:honeycomb_block
setblock 1 139 326 minecraft:yellow_terracotta
fill 1 139 327 1 142 327 minecraft:honeycomb_block
setblock 1 139 331 minecraft:yellow_terracotta
fill 1 139 332 1 142 332 minecraft:honeycomb_block
setblock 1 139 336 minecraft:yellow_terracotta
fill 1 139 337 1 141 337 minecraft:honeycomb_block
setblock 1 139 341 minecraft:yellow_terracotta
fill 1 139 342 1 142 342 minecraft:honeycomb_block
setblock 1 139 345 minecraft:honeycomb_block
setblock 1 139 346 minecraft:yellow_terracotta
fill 1 139 347 1 142 347 minecraft:honeycomb_block
setblock 1 139 350 minecraft:honeycomb_block
setblock 1 139 351 minecraft:yellow_terracotta
fill 1 139 352 1 142 352 minecraft:honeycomb_block
setblock 1 139 356 minecraft:yellow_terracotta
fill 1 139 357 1 142 357 minecraft:honeycomb_block
setblock 1 139 361 minecraft:yellow_terracotta
fill 1 139 362 1 142 362 minecraft:honeycomb_block
setblock 2 139 325 minecraft:yellow_terracotta
fill 2 139 326 2 142 326 minecraft:honeycomb_block
setblock 2 139 330 minecraft:yellow_terracotta
setblock 2 139 340 minecraft:yellow_terracotta
fill 2 139 341 2 141 341 minecraft:honeycomb_block
setblock 2 139 345 minecraft:yellow_terracotta
fill 2 139 346 2 142 346 minecraft:honeycomb_block
setblock 2 139 349 minecraft:honeycomb_block
setblock 2 139 350 minecraft:yellow_terracotta
fill 2 139 351 2 142 351 minecraft:honeycomb_block
setblock 2 139 355 minecraft:yellow_terracotta
fill 2 139 356 2 142 356 minecraft:honeycomb_block
setblock 2 139 360 minecraft:yellow_terracotta
fill 2 139 361 2 142 361 minecraft:honeycomb_block
setblock 3 139 324 minecraft:yellow_terracotta
fill 3 139 325 3 142 325 minecraft:honeycomb_block
setblock 3 139 327 minecraft:honeycomb_block
setblock 3 139 344 minecraft:yellow_terracotta
fill 3 139 345 3 141 345 minecraft:honeycomb_block
fill 3 139 347 3 140 347 minecraft:honeycomb_block
fill 3 139 356 3 140 356 minecraft:yellow_terracotta
setblock 3 139 359 minecraft:yellow_terracotta
fill 3 139 360 3 141 360 minecraft:honeycomb_block
setblock 4 139 323 minecraft:yellow_terracotta
fill 4 139 324 4 142 324 minecraft:honeycomb_block
setblock 4 139 363 minecraft:yellow_terracotta
fill 4 139 364 4 189 364 minecraft:honeycomb_block
fill 5 139 323 5 142 323 minecraft:honeycomb_block
setblock 5 139 362 minecraft:yellow_terracotta
fill 5 139 363 5 142 363 minecraft:honeycomb_block
setblock 6 139 361 minecraft:yellow_terracotta
fill 6 139 362 6 142 362 minecraft:honeycomb_block
setblock 7 139 324 minecraft:honeycomb_block
fill 7 139 361 7 140 361 minecraft:honeycomb_block
setblock 8 139 324 minecraft:yellow_terracotta
setblock 9 139 323 minecraft:yellow_terracotta
setblock 9 139 363 minecraft:yellow_terracotta
fill 10 139 323 10 141 323 minecraft:honeycomb_block
setblock 10 139 362 minecraft:yellow_terracotta
fill 10 139 363 13 139 363 minecraft:honeycomb_block
fill 11 139 362 14 139 362 minecraft:honeycomb_block
setblock 13 139 323 minecraft:honeycomb_block
setblock 14 139 323 minecraft:yellow_terracotta
setblock 14 139 363 minecraft:yellow_terracotta
fill 15 139 323 18 139 323 minecraft:honeycomb_block
setblock 15 139 362 minecraft:yellow_terracotta
fill 15 139 363 15 142 363 minecraft:honeycomb_block
fill 16 139 362 16 141 362 minecraft:honeycomb_block
setblock 18 139 324 minecraft:yellow_terracotta
setblock 19 139 323 minecraft:yellow_terracotta
fill 19 139 324 19 142 324 minecraft:honeycomb_block
setblock 19 139 363 minecraft:yellow_terracotta
fill 20 139 323 20 142 323 minecraft:honeycomb_block
setblock 20 139 362 minecraft:yellow_terracotta
fill 20 139 363 20 142 363 minecraft:honeycomb_block
setblock 21 139 361 minecraft:yellow_terracotta
fill 21 139 362 21 142 362 minecraft:honeycomb_block
setblock 22 139 361 minecraft:honeycomb_block
setblock 23 139 323 minecraft:honeycomb_block
setblock 23 139 324 minecraft:yellow_terracotta
setblock 24 139 323 minecraft:yellow_terracotta
fill 24 139 324 24 142 324 minecraft:honeycomb_block
setblock 24 139 363 minecraft:yellow_terracotta
fill 25 139 323 25 142 323 minecraft:honeycomb_block
setblock 25 139 362 minecraft:yellow_terracotta
fill 25 139 363 25 142 363 minecraft:honeycomb_block
setblock 26 139 362 minecraft:honeycomb_block
setblock 28 139 324 minecraft:yellow_terracotta
setblock 29 139 323 minecraft:yellow_terracotta
fill 29 139 324 32 139 324 minecraft:honeycomb_block
setblock 29 139 363 minecraft:yellow_terracotta
fill 30 139 323 33 139 323 minecraft:honeycomb_block
fill 30 139 363 33 139 363 minecraft:honeycomb_block
setblock 31 139 322 minecraft:yellow_terracotta
setblock 33 139 324 minecraft:yellow_terracotta
setblock 34 139 323 minecraft:yellow_terracotta
fill 34 139 324 34 142 324 minecraft:honeycomb_block
setblock 34 139 363 minecraft:yellow_terracotta
fill 35 139 323 35 142 323 minecraft:honeycomb_block
fill 35 139 363 35 142 363 minecraft:honeycomb_block
setblock 36 139 325 minecraft:honeycomb_block
fill 36 139 362 36 140 362 minecraft:honeycomb_block
setblock 37 139 324 minecraft:honeycomb_block
setblock 37 139 325 minecraft:yellow_terracotta
setblock 38 139 324 minecraft:yellow_terracotta
fill 38 139 325 38 142 325 minecraft:honeycomb_block
setblock 39 139 323 minecraft:yellow_terracotta
fill 39 139 324 39 142 324 minecraft:honeycomb_block
setblock 39 139 327 minecraft:honeycomb_block
setblock 39 139 328 minecraft:yellow_terracotta
fill 39 139 329 39 142 329 minecraft:honeycomb_block
setblock 39 139 338 minecraft:yellow_terracotta
setblock 39 139 339 minecraft:honeycomb_block
setblock 39 139 343 minecraft:yellow_terracotta
fill 39 139 344 39 141 344 minecraft:honeycomb_block
setblock 39 139 361 minecraft:honeycomb_block
setblock 39 139 363 minecraft:yellow_terracotta
fill 40 139 323 40 142 323 minecraft:honeycomb_block
setblock 40 139 327 minecraft:yellow_terracotta
fill 40 139 328 40 142 328 minecraft:honeycomb_block
setblock 40 139 332 minecraft:yellow_terracotta
fill 40 139 333 40 142 333 minecraft:honeycomb_block
setblock 40 139 337 minecraft:yellow_terracotta
fill 40 139 338 40 141 338 minecraft:honeycomb_block
setblock 40 139 342 minecraft:yellow_terracotta
fill 40 139 343 40 142 343 minecraft:honeycomb_block
setblock 40 139 347 minecraft:yellow_terracotta
fill 40 139 348 40 142 348 minecraft:honeycomb_block
setblock 40 139 358 minecraft:honeycomb_block
setblock 40 139 362 minecraft:yellow_terracotta
fill 40 139 363 40 142 363 minecraft:honeycomb_block
setblock 41 139 326 minecraft:yellow_terracotta
fill 41 139 327 41 142 327 minecraft:honeycomb_block
setblock 41 139 331 minecraft:yellow_terracotta
fill 41 139 332 41 142 332 minecraft:honeycomb_block
setblock 41 139 336 minecraft:yellow_terracotta
fill 41 139 337 41 142 337 minecraft:honeycomb_block
setblock 41 139 341 minecraft:yellow_terracotta
fill 41 139 342 41 142 342 minecraft:honeycomb_block
setblock 41 139 346 minecraft:yellow_terracotta
fill 41 139 347 41 142 347 minecraft:honeycomb_block
setblock 41 139 350 minecraft:honeycomb_block
setblock 41 139 351 minecraft:yellow_terracotta
fill 41 139 352 41 141 353 minecraft:honeycomb_block
setblock 41 139 356 minecraft:yellow_terracotta
fill 41 139 357 41 142 357 minecraft:honeycomb_block
setblock 41 139 361 minecraft:yellow_terracotta
fill 41 139 362 41 142 362 minecraft:honeycomb_block
setblock 1 140 325 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_5 1t
