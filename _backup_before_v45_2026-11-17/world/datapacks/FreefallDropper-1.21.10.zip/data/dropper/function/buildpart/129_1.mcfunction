fill 459 136 510 459 137 510 minecraft:gold_block
fill 465 136 520 465 137 520 minecraft:gold_block
fill 465 136 529 465 151 529 minecraft:black_concrete
fill 465 136 536 465 137 536 minecraft:gold_block
setblock 426 137 552 minecraft:sea_lantern
setblock 432 137 510 minecraft:black_concrete
fill 444 137 510 444 143 510 minecraft:black_concrete
setblock 465 137 521 minecraft:sea_lantern
setblock 465 137 530 minecraft:light_blue_stained_glass
fill 465 137 531 465 160 531 minecraft:black_concrete
fill 423 138 518 423 144 518 minecraft:black_concrete
fill 423 138 534 423 143 534 minecraft:black_concrete
fill 423 138 550 423 144 550 minecraft:black_concrete
fill 426 138 552 426 159 552 minecraft:black_concrete
fill 427 138 510 427 144 510 minecraft:black_concrete
setblock 432 138 510 minecraft:light_blue_stained_glass
fill 437 138 552 437 144 552 minecraft:black_concrete
fill 443 138 510 443 144 510 minecraft:black_concrete
setblock 447 138 552 minecraft:light_blue_stained_glass
fill 453 138 552 453 144 552 minecraft:black_concrete
fill 459 138 510 459 144 510 minecraft:black_concrete
fill 465 138 520 465 144 521 minecraft:black_concrete
fill 465 138 530 465 155 530 minecraft:black_concrete
fill 465 138 536 465 144 536 minecraft:black_concrete
setblock 423 139 537 minecraft:white_concrete
fill 432 139 510 432 159 510 minecraft:black_concrete
fill 447 139 552 447 159 552 minecraft:black_concrete
setblock 423 140 514 minecraft:sea_lantern
fill 423 140 537 423 153 537 minecraft:black_concrete
setblock 428 140 552 minecraft:white_concrete
setblock 430 140 552 minecraft:light_blue_stained_glass
setblock 452 140 552 minecraft:light_blue_stained_glass
setblock 453 140 510 minecraft:white_concrete
fill 423 141 514 423 155 514 minecraft:black_concrete
setblock 423 141 524 minecraft:light_blue_stained_glass
fill 423 141 525 423 159 526 minecraft:black_concrete
setblock 426 141 513 minecraft:light[level=14]
setblock 426 141 521 minecraft:light[level=14]
setblock 426 141 529 minecraft:light[level=14]
setblock 426 141 537 minecraft:light[level=14]
setblock 426 141 545 minecraft:light[level=14]
fill 428 141 552 428 159 552 minecraft:black_concrete
fill 430 141 552 430 155 552 minecraft:black_concrete
setblock 434 141 513 minecraft:light[level=14]
setblock 434 141 521 minecraft:light[level=14]
setblock 434 141 529 minecraft:light[level=14]
setblock 434 141 537 minecraft:light[level=14]
setblock 434 141 545 minecraft:light[level=14]
setblock 437 141 510 minecraft:light_blue_stained_glass
setblock 442 141 513 minecraft:light[level=14]
setblock 442 141 521 minecraft:light[level=14]
setblock 442 141 529 minecraft:light[level=14]
setblock 442 141 537 minecraft:light[level=14]
setblock 442 141 545 minecraft:light[level=14]
setblock 450 141 513 minecraft:light[level=14]
setblock 450 141 521 minecraft:light[level=14]
setblock 450 141 529 minecraft:light[level=14]
setblock 450 141 537 minecraft:light[level=14]
setblock 450 141 545 minecraft:light[level=14]
fill 452 141 552 452 160 552 minecraft:black_concrete
fill 453 141 510 453 159 510 minecraft:black_concrete
setblock 458 141 513 minecraft:light[level=14]
setblock 458 141 521 minecraft:light[level=14]
setblock 458 141 529 minecraft:light[level=14]
setblock 458 141 537 minecraft:light[level=14]
setblock 458 141 545 minecraft:light[level=14]
fill 423 142 524 423 159 524 minecraft:black_concrete
setblock 434 142 510 minecraft:sea_lantern
fill 437 142 510 437 159 510 minecraft:black_concrete
setblock 449 142 510 minecraft:light_blue_stained_glass
setblock 457 142 510 minecraft:sea_lantern
setblock 465 142 515 minecraft:white_concrete
fill 434 143 510 434 157 510 minecraft:black_concrete
fill 449 143 510 449 150 510 minecraft:black_concrete
setblock 451 143 552 minecraft:sea_lantern
fill 457 143 510 457 161 510 minecraft:black_concrete
fill 465 143 515 465 156 515 minecraft:black_concrete
setblock 465 143 539 minecraft:white_concrete
setblock 423 144 534 minecraft:light_blue_stained_glass
setblock 423 144 542 minecraft:white_concrete
setblock 444 144 510 minecraft:white_concrete
fill 451 144 552 451 159 552 minecraft:black_concrete
fill 465 144 539 465 157 539 minecraft:black_concrete
fill 423 145 518 423 146 518 minecraft:gold_block
fill 423 145 534 423 146 534 minecraft:gold_block
fill 423 145 542 423 159 542 minecraft:black_concrete
fill 423 145 550 423 146 550 minecraft:gold_block
fill 427 145 510 427 146 510 minecraft:gold_block
fill 437 145 552 437 146 552 minecraft:gold_block
fill 443 145 510 443 146 510 minecraft:gold_block
fill 444 145 510 444 149 510 minecraft:black_concrete
fill 453 145 552 453 146 552 minecraft:gold_block
fill 459 145 510 459 146 510 minecraft:gold_block
setblock 464 145 552 minecraft:light_blue_stained_glass
setblock 465 145 511 minecraft:light_blue_stained_glass
fill 465 145 512 465 159 513 minecraft:black_concrete
fill 465 145 520 465 146 520 minecraft:gold_block
fill 465 145 521 465 159 521 minecraft:black_concrete
fill 465 145 536 465 146 536 minecraft:gold_block
setblock 423 146 544 minecraft:light_blue_stained_glass
fill 464 146 552 464 160 552 minecraft:black_concrete
fill 465 146 511 465 159 511 minecraft:black_concrete
fill 423 147 518 423 153 518 minecraft:black_concrete
setblock 423 147 527 minecraft:white_concrete
fill 423 147 534 423 151 534 minecraft:black_concrete
fill 423 147 544 423 155 544 minecraft:black_concrete
setblock 423 147 545 minecraft:white_concrete
fill 423 147 550 423 153 550 minecraft:black_concrete
fill 427 147 510 427 153 510 minecraft:black_concrete
setblock 432 147 552 minecraft:sea_lantern
setblock 436 147 510 minecraft:white_concrete
fill 437 147 552 437 153 552 minecraft:black_concrete
fill 443 147 510 443 153 510 minecraft:black_concrete
fill 443 147 544 447 148 548 minecraft:polished_blackstone
fill 445 147 549 445 147 550 minecraft:polished_blackstone
fill 453 147 552 453 153 552 minecraft:black_concrete
fill 459 147 510 459 153 510 minecraft:black_concrete
setblock 459 147 552 minecraft:sea_lantern
fill 465 147 520 465 153 520 minecraft:black_concrete
fill 465 147 536 465 153 536 minecraft:black_concrete
setblock 423 148 516 minecraft:white_concrete
fill 423 148 527 423 157 527 minecraft:black_concrete
fill 423 148 545 423 159 545 minecraft:black_concrete
fill 432 148 552 432 157 552 minecraft:black_concrete
fill 436 148 510 436 159 510 minecraft:black_concrete
setblock 445 148 510 minecraft:light_blue_stained_glass
fill 459 148 552 459 159 552 minecraft:black_concrete
setblock 465 148 516 minecraft:light_blue_stained_glass
fill 423 149 516 423 159 516 minecraft:black_concrete
setblock 426 149 513 minecraft:light[level=14]
setblock 426 149 521 minecraft:light[level=14]
setblock 426 149 529 minecraft:light[level=14]
setblock 426 149 537 minecraft:light[level=14]
setblock 426 149 545 minecraft:light[level=14]
setblock 434 149 513 minecraft:light[level=14]
setblock 434 149 521 minecraft:light[level=14]
setblock 434 149 529 minecraft:light[level=14]
setblock 434 149 537 minecraft:light[level=14]
setblock 434 149 545 minecraft:light[level=14]
setblock 442 149 513 minecraft:light[level=14]
setblock 442 149 521 minecraft:light[level=14]
setblock 442 149 529 minecraft:light[level=14]
setblock 442 149 537 minecraft:light[level=14]
setblock 442 149 545 minecraft:light[level=14]
setblock 444 149 552 minecraft:white_concrete
setblock 445 149 510 minecraft:black_concrete
setblock 448 149 552 minecraft:sea_lantern
setblock 450 149 513 minecraft:light[level=14]
setblock 450 149 521 minecraft:light[level=14]
setblock 450 149 529 minecraft:light[level=14]
setblock 450 149 537 minecraft:light[level=14]
setblock 450 149 545 minecraft:light[level=14]
setblock 458 149 513 minecraft:light[level=14]
setblock 458 149 521 minecraft:light[level=14]
setblock 458 149 529 minecraft:light[level=14]
setblock 458 149 537 minecraft:light[level=14]
setblock 458 149 545 minecraft:light[level=14]
fill 465 149 516 465 155 516 minecraft:black_concrete
setblock 430 150 510 minecraft:sea_lantern
fill 431 150 510 431 155 510 minecraft:black_concrete
fill 444 150 510 445 150 510 minecraft:light_blue_stained_glass
fill 444 150 552 444 157 552 minecraft:black_concrete
fill 445 150 546 445 157 546 minecraft:gold_block
fill 448 150 552 448 160 552 minecraft:black_concrete
setblock 463 150 510 minecraft:light_blue_stained_glass
setblock 423 151 531 minecraft:white_concrete
fill 430 151 510 430 153 510 minecraft:black_concrete
fill 443 151 545 444 156 547 minecraft:gold_block
fill 444 151 510 445 159 510 minecraft:black_concrete
fill 444 151 544 446 156 544 minecraft:gold_block
fill 444 151 548 446 156 548 minecraft:gold_block
fill 445 151 545 447 156 545 minecraft:gold_block
fill 445 151 547 447 156 547 minecraft:gold_block
fill 446 151 546 447 156 546 minecraft:gold_block
setblock 449 151 510 minecraft:light_blue_stained_glass
setblock 458 151 552 minecraft:sea_lantern
fill 463 151 510 463 155 510 minecraft:black_concrete
fill 423 152 531 423 160 531 minecraft:black_concrete
setblock 423 152 534 minecraft:light_blue_stained_glass
fill 433 152 520 435 159 522 minecraft:orange_concrete
fill 434 152 523 434 159 523 minecraft:orange_concrete
fill 442 152 545 442 155 547 minecraft:gold_block
fill 443 152 544 443 155 544 minecraft:gold_block
fill 443 152 548 443 155 548 minecraft:gold_block
fill 444 152 543 446 155 543 minecraft:gold_block
fill 444 152 549 446 155 549 minecraft:gold_block
fill 447 152 544 447 155 544 minecraft:gold_block
fill 447 152 548 447 155 548 minecraft:gold_block
fill 448 152 545 448 155 547 minecraft:gold_block
fill 449 152 510 449 159 510 minecraft:black_concrete
setblock 457 152 552 minecraft:light_blue_stained_glass
setblock 458 152 552 minecraft:black_concrete
setblock 465 152 529 minecraft:white_concrete
setblock 423 153 534 minecraft:black_concrete
fill 431 153 521 432 158 522 minecraft:orange_concrete
fill 432 153 519 432 158 520 minecraft:orange_concrete
fill 432 153 523 433 158 523 minecraft:orange_concrete
fill 433 153 519 435 158 519 minecraft:orange_concrete
fill 433 153 524 435 158 524 minecraft:orange_concrete
fill 435 153 523 436 158 523 minecraft:orange_concrete
fill 436 153 520 436 158 522 minecraft:orange_concrete
setblock 438 153 510 minecraft:sea_lantern
setblock 451 153 510 minecraft:white_concrete
fill 457 153 552 457 155 552 minecraft:black_concrete
setblock 458 153 552 minecraft:sea_lantern
fill 465 153 529 465 156 529 minecraft:black_concrete
setblock 423 154 512 minecraft:sea_lantern
fill 423 154 513 423 159 513 minecraft:black_concrete
fill 423 154 518 423 155 518 minecraft:gold_block
fill 423 154 534 423 155 534 minecraft:gold_block
setblock 423 154 537 minecraft:white_concrete
fill 423 154 550 423 155 550 minecraft:gold_block
fill 427 154 510 427 155 510 minecraft:gold_block
setblock 430 154 510 minecraft:light_blue_stained_glass
fill 431 154 520 431 157 520 minecraft:orange_concrete
fill 431 154 523 431 157 523 minecraft:orange_concrete
fill 432 154 524 432 157 524 minecraft:orange_concrete
fill 433 154 518 435 157 518 minecraft:orange_concrete
setblock 435 154 552 minecraft:light_blue_stained_glass
fill 436 154 519 436 157 519 minecraft:orange_concrete
fill 436 154 524 436 157 524 minecraft:orange_concrete
fill 437 154 520 437 157 523 minecraft:orange_concrete
fill 437 154 552 437 155 552 minecraft:gold_block
fill 438 154 510 438 159 510 minecraft:black_concrete
setblock 441 154 552 minecraft:sea_lantern
fill 443 154 510 443 155 510 minecraft:gold_block
setblock 449 154 552 minecraft:sea_lantern
fill 451 154 510 451 159 510 minecraft:black_concrete
fill 453 154 552 453 155 552 minecraft:gold_block
fill 458 154 552 458 159 552 minecraft:black_concrete
fill 459 154 510 459 155 510 minecraft:gold_block
fill 465 154 520 465 155 520 minecraft:gold_block
fill 465 154 536 465 155 536 minecraft:gold_block
fill 423 155 512 423 159 512 minecraft:black_concrete
fill 423 155 537 423 160 537 minecraft:black_concrete
setblock 430 155 510 minecraft:black_concrete
fill 431 155 519 431 156 519 minecraft:orange_concrete
fill 432 155 518 432 156 518 minecraft:orange_concrete
fill 433 155 525 435 156 525 minecraft:orange_concrete
fill 435 155 552 435 157 552 minecraft:black_concrete
fill 436 155 518 436 156 518 minecraft:orange_concrete
fill 437 155 519 437 156 519 minecraft:orange_concrete
fill 441 155 552 441 157 552 minecraft:black_concrete
setblock 449 155 552 minecraft:black_concrete
setblock 462 155 510 minecraft:sea_lantern
setblock 465 155 546 minecraft:light_blue_stained_glass
setblock 423 156 511 minecraft:blue_concrete
setblock 423 156 514 minecraft:blue_concrete
setblock 423 156 517 minecraft:blue_concrete
setblock 423 156 518 minecraft:black_concrete
fill 423 156 534 423 159 534 minecraft:black_concrete
setblock 423 156 538 minecraft:blue_concrete
setblock 423 156 540 minecraft:blue_concrete
setblock 423 156 544 minecraft:blue_concrete
fill 423 156 550 423 157 551 minecraft:black_concrete
fill 423 156 552 425 156 552 minecraft:blue_concrete
setblock 427 156 510 minecraft:blue_concrete
fill 430 156 510 431 156 510 minecraft:blue_concrete
setblock 430 156 552 minecraft:blue_concrete
setblock 436 156 552 minecraft:white_concrete
setblock 437 156 552 minecraft:black_concrete
setblock 438 156 552 minecraft:blue_concrete
setblock 441 156 510 minecraft:blue_concrete
setblock 442 156 552 minecraft:blue_concrete
setblock 443 156 510 minecraft:blue_concrete
setblock 449 156 552 minecraft:blue_concrete
setblock 452 156 510 minecraft:blue_concrete
fill 453 156 552 453 159 552 minecraft:black_concrete
fill 456 156 552 457 156 552 minecraft:blue_concrete
fill 459 156 510 459 159 510 minecraft:black_concrete
fill 462 156 510 462 159 510 minecraft:black_concrete
setblock 462 156 552 minecraft:white_concrete
setblock 463 156 510 minecraft:blue_concrete
setblock 465 156 516 minecraft:sea_lantern
fill 465 156 520 465 159 520 minecraft:black_concrete
setblock 465 156 530 minecraft:blue_concrete
setblock 465 156 535 minecraft:blue_concrete
fill 465 156 536 465 159 536 minecraft:black_concrete
setblock 465 156 537 minecraft:light_blue_stained_glass
fill 465 156 546 465 159 546 minecraft:black_concrete
setblock 465 156 550 minecraft:sea_lantern
fill 423 157 511 423 159 511 minecraft:black_concrete
fill 423 157 514 423 159 514 minecraft:black_concrete
setblock 423 157 515 minecraft:blue_concrete
fill 423 157 517 423 159 517 minecraft:black_concrete
fill 423 157 518 423 157 519 minecraft:blue_concrete
setblock 423 157 528 minecraft:blue_concrete
fill 423 157 538 423 159 538 minecraft:black_concrete
fill 423 157 540 423 159 540 minecraft:black_concrete
fill 423 157 544 423 159 544 minecraft:black_concrete
fill 423 157 552 425 159 552 minecraft:black_concrete
setblock 425 157 510 minecraft:blue_concrete
setblock 426 157 513 minecraft:light[level=14]
setblock 426 157 521 minecraft:light[level=14]
setblock 426 157 529 minecraft:light[level=14]
setblock 426 157 537 minecraft:light[level=14]
setblock 426 157 545 minecraft:light[level=14]
fill 427 157 510 427 159 510 minecraft:black_concrete
setblock 427 157 552 minecraft:blue_concrete
fill 430 157 510 431 159 510 minecraft:black_concrete
fill 430 157 552 430 160 552 minecraft:black_concrete
setblock 434 157 513 minecraft:light[level=14]
setblock 434 157 529 minecraft:light[level=14]
setblock 434 157 537 minecraft:light[level=14]
setblock 434 157 545 minecraft:light[level=14]
fill 436 157 552 436 159 552 minecraft:black_concrete
setblock 437 157 552 minecraft:light_blue_stained_glass
setblock 438 157 552 minecraft:black_concrete
fill 441 157 510 441 159 510 minecraft:black_concrete
setblock 442 157 513 minecraft:light[level=14]
setblock 442 157 521 minecraft:light[level=14]
setblock 442 157 529 minecraft:light[level=14]
setblock 442 157 537 minecraft:light[level=14]
setblock 442 157 545 minecraft:light[level=14]
fill 442 157 552 442 159 552 minecraft:black_concrete
setblock 443 157 510 minecraft:black_concrete
fill 449 157 552 449 159 552 minecraft:black_concrete
setblock 450 157 513 minecraft:light[level=14]
setblock 450 157 521 minecraft:light[level=14]
setblock 450 157 529 minecraft:light[level=14]
setblock 450 157 537 minecraft:light[level=14]
setblock 450 157 545 minecraft:light[level=14]
fill 452 157 510 452 159 510 minecraft:black_concrete
setblock 456 157 510 minecraft:blue_concrete
fill 456 157 552 457 157 552 minecraft:black_concrete
fill 458 157 510 458 158 510 minecraft:blue_concrete
setblock 458 157 513 minecraft:light[level=14]
setblock 458 157 521 minecraft:light[level=14]
setblock 458 157 529 minecraft:light[level=14]
setblock 458 157 537 minecraft:light[level=14]
setblock 458 157 545 minecraft:light[level=14]
setblock 460 157 510 minecraft:light_blue_stained_glass
fill 462 157 552 462 159 552 minecraft:black_concrete
fill 463 157 510 463 159 510 minecraft:black_concrete
fill 465 157 515 465 157 516 minecraft:blue_concrete
setblock 465 157 519 minecraft:blue_concrete
setblock 465 157 529 minecraft:blue_concrete
fill 465 157 530 465 158 530 minecraft:black_concrete
setblock 465 157 532 minecraft:sea_lantern
fill 465 157 533 465 159 533 minecraft:black_concrete
setblock 465 157 534 minecraft:blue_concrete
setblock 465 157 535 minecraft:black_concrete
fill 465 157 537 465 160 537 minecraft:black_concrete
setblock 465 157 544 minecraft:blue_concrete
fill 465 157 550 465 159 550 minecraft:black_concrete
setblock 465 157 552 minecraft:blue_concrete
fill 423 158 515 423 160 515 minecraft:black_concrete
fill 423 158 518 423 159 519 minecraft:black_concrete
setblock 423 158 527 minecraft:sea_lantern
fill 423 158 528 423 160 528 minecraft:black_concrete
setblock 423 158 530 minecraft:blue_concrete
fill 423 158 550 423 159 550 minecraft:black_concrete
setblock 423 158 551 minecraft:blue_concrete
fill 425 158 510 425 159 510 minecraft:black_concrete
setblock 426 158 510 minecraft:blue_concrete
fill 427 158 552 427 160 552 minecraft:black_concrete
setblock 432 158 552 minecraft:sea_lantern
setblock 434 158 510 minecraft:blue_concrete
setblock 434 158 552 minecraft:blue_concrete
setblock 435 158 552 minecraft:sea_lantern
fill 437 158 552 437 159 552 minecraft:black_concrete
setblock 438 158 552 minecraft:blue_concrete
setblock 441 158 552 minecraft:blue_concrete
setblock 443 158 510 minecraft:blue_concrete
setblock 444 158 552 minecraft:blue_concrete
setblock 448 158 510 minecraft:blue_concrete
setblock 450 158 552 minecraft:blue_concrete
fill 456 158 510 456 159 510 minecraft:black_concrete
setblock 456 158 552 minecraft:blue_concrete
fill 457 158 552 457 159 552 minecraft:black_concrete
fill 460 158 510 460 159 510 minecraft:black_concrete
fill 465 158 515 465 159 516 minecraft:black_concrete
fill 465 158 519 465 159 519 minecraft:black_concrete
fill 465 158 529 465 159 529 minecraft:black_concrete
fill 465 158 532 465 159 532 minecraft:black_concrete
setblock 465 158 534 minecraft:sea_lantern
setblock 465 158 535 minecraft:blue_concrete
setblock 465 158 539 minecraft:blue_concrete
setblock 465 158 543 minecraft:blue_concrete
fill 465 158 544 465 159 544 minecraft:black_concrete
setblock 465 158 548 minecraft:light_blue_stained_glass
fill 465 158 552 465 159 552 minecraft:black_concrete
setblock 423 159 521 minecraft:light_blue_stained_glass
setblock 423 159 527 minecraft:black_concrete
fill 423 159 530 423 160 530 minecraft:black_concrete
setblock 423 159 551 minecraft:black_concrete
setblock 426 159 510 minecraft:black_concrete
fill 432 159 552 432 160 552 minecraft:black_concrete
setblock 434 159 510 minecraft:black_concrete
fill 434 159 552 435 159 552 minecraft:black_concrete
setblock 438 159 552 minecraft:black_concrete
setblock 441 159 552 minecraft:black_concrete
setblock 442 159 510 minecraft:sea_lantern
setblock 443 159 510 minecraft:black_concrete
setblock 444 159 552 minecraft:black_concrete
setblock 448 159 510 minecraft:black_concrete
setblock 450 159 552 minecraft:black_concrete
setblock 456 159 552 minecraft:black_concrete
fill 458 159 510 458 160 510 minecraft:black_concrete
setblock 465 159 530 minecraft:light_blue_stained_glass
fill 465 159 534 465 159 535 minecraft:black_concrete
fill 465 159 539 465 160 539 minecraft:black_concrete
setblock 465 159 543 minecraft:black_concrete
setblock 465 159 548 minecraft:black_concrete
fill 423 160 510 423 160 514 minecraft:blue_concrete
fill 423 160 516 423 161 521 minecraft:blue_concrete
fill 423 160 524 423 161 527 minecraft:blue_concrete
fill 423 160 529 423 226 529 minecraft:blue_concrete
fill 423 160 533 423 161 535 minecraft:blue_concrete
fill 423 160 538 423 160 546 minecraft:blue_concrete
setblock 423 160 547 minecraft:white_concrete
fill 423 160 548 423 161 552 minecraft:blue_concrete
fill 424 160 510 427 160 510 minecraft:blue_concrete
fill 424 160 552 426 160 552 minecraft:blue_concrete
setblock 428 160 510 minecraft:white_concrete
fill 428 160 552 429 161 552 minecraft:blue_concrete
fill 429 160 510 441 160 510 minecraft:blue_concrete
fill 431 160 552 431 229 552 minecraft:blue_concrete
fill 433 160 552 438 160 552 minecraft:blue_concrete
fill 440 160 552 447 160 552 minecraft:blue_concrete
setblock 442 160 510 minecraft:black_concrete
fill 443 160 510 452 160 510 minecraft:blue_concrete
fill 449 160 552 451 179 552 minecraft:blue_concrete
setblock 453 160 510 minecraft:light_blue_stained_glass
fill 453 160 552 463 160 552 minecraft:blue_concrete
fill 454 160 510 456 160 510 minecraft:blue_concrete
fill 459 160 510 465 161 510 minecraft:blue_concrete
fill 465 160 511 465 178 513 minecraft:blue_concrete
fill 465 160 515 465 161 530 minecraft:blue_concrete
fill 465 160 532 465 160 536 minecraft:blue_concrete
fill 465 160 538 465 161 538 minecraft:blue_concrete
fill 465 160 540 465 160 552 minecraft:blue_concrete
setblock 423 161 510 minecraft:black_concrete
fill 423 161 511 423 181 511 minecraft:blue_concrete
setblock 423 161 512 minecraft:black_concrete
fill 423 161 513 423 161 515 minecraft:blue_concrete
fill 423 161 522 423 161 523 minecraft:blue_concrete
fill 423 161 528 423 198 528 minecraft:blue_concrete
fill 423 161 530 423 161 532 minecraft:blue_concrete
fill 423 161 537 423 233 537 minecraft:blue_concrete
setblock 423 161 538 minecraft:black_concrete
fill 423 161 539 423 161 544 minecraft:blue_concrete
setblock 423 161 545 minecraft:black_concrete
fill 423 161 546 423 162 547 minecraft:blue_concrete
fill 424 161 510 425 177 510 minecraft:blue_concrete
setblock 424 161 552 minecraft:black_concrete
fill 425 161 552 427 175 552 minecraft:blue_concrete
setblock 426 161 510 minecraft:black_concrete
fill 427 161 510 428 161 510 minecraft:blue_concrete
setblock 429 161 510 minecraft:white_concrete
fill 430 161 510 432 162 510 minecraft:blue_concrete
fill 430 161 552 430 165 552 minecraft:blue_concrete
fill 432 161 552 432 233 552 minecraft:blue_concrete
setblock 433 161 510 minecraft:sea_lantern
setblock 433 161 552 minecraft:black_concrete
fill 434 161 510 434 188 510 minecraft:blue_concrete
fill 434 161 552 436 180 552 minecraft:blue_concrete
setblock 435 161 510 minecraft:black_concrete
fill 436 161 510 438 174 510 minecraft:blue_concrete
setblock 437 161 552 minecraft:black_concrete
fill 438 161 552 441 161 552 minecraft:blue_concrete
setblock 439 161 510 minecraft:black_concrete
fill 440 161 510 443 161 510 minecraft:blue_concrete
setblock 442 161 552 minecraft:black_concrete
fill 443 161 552 447 161 552 minecraft:blue_concrete
setblock 444 161 510 minecraft:black_concrete
fill 445 161 510 455 161 510 minecraft:blue_concrete
setblock 448 161 552 minecraft:light_blue_stained_glass
fill 452 161 552 453 161 552 minecraft:blue_concrete
fill 454 161 552 455 161 552 minecraft:black_concrete
setblock 456 161 510 minecraft:black_concrete
fill 456 161 552 465 165 552 minecraft:blue_concrete
fill 458 161 510 458 200 510 minecraft:blue_concrete
fill 465 161 531 465 161 534 minecraft:blue_concrete
setblock 465 161 535 minecraft:black_concrete
fill 465 161 536 465 161 537 minecraft:blue_concrete
setblock 465 161 539 minecraft:blue_concrete
setblock 465 161 540 minecraft:white_concrete
fill 465 161 541 465 165 547 minecraft:blue_concrete
setblock 465 161 548 minecraft:black_concrete
fill 465 161 549 465 161 551 minecraft:blue_concrete
fill 423 162 510 423 229 510 minecraft:blue_concrete
fill 423 162 512 423 203 513 minecraft:blue_concrete
setblock 423 162 514 minecraft:black_concrete
fill 423 162 515 423 173 517 minecraft:blue_concrete
fill 423 162 518 423 164 518 minecraft:gold_block
fill 423 162 519 423 166 522 minecraft:blue_concrete
fill 423 162 523 423 162 524 minecraft:black_concrete
fill 423 162 525 423 183 525 minecraft:blue_concrete
setblock 423 162 526 minecraft:black_concrete
fill 423 162 527 423 233 527 minecraft:blue_concrete
setblock 423 162 530 minecraft:black_concrete
fill 423 162 531 423 197 533 minecraft:blue_concrete
fill 423 162 534 423 164 534 minecraft:gold_block
fill 423 162 535 423 179 536 minecraft:blue_concrete
fill 423 162 538 423 171 539 minecraft:blue_concrete
setblock 423 162 540 minecraft:black_concrete
fill 423 162 541 423 162 545 minecraft:blue_concrete
fill 423 162 548 423 170 549 minecraft:blue_concrete
fill 423 162 550 423 164 550 minecraft:gold_block
fill 423 162 551 423 231 551 minecraft:blue_concrete
setblock 423 162 552 minecraft:black_concrete
fill 424 162 552 424 232 552 minecraft:blue_concrete
fill 426 162 510 426 233 510 minecraft:blue_concrete
fill 427 162 510 427 164 510 minecraft:gold_block
fill 428 162 510 429 162 510 minecraft:blue_concrete
setblock 428 162 552 minecraft:black_concrete
fill 429 162 552 429 175 552 minecraft:blue_concrete
fill 433 162 510 433 221 510 minecraft:blue_concrete
fill 433 162 552 433 171 552 minecraft:blue_concrete
fill 435 162 510 435 188 510 minecraft:blue_concrete
fill 437 162 552 437 164 552 minecraft:gold_block
fill 438 162 552 438 164 552 minecraft:blue_concrete
fill 439 162 510 442 167 510 minecraft:blue_concrete
setblock 439 162 552 minecraft:black_concrete
fill 440 162 552 443 164 552 minecraft:blue_concrete
fill 443 162 510 443 164 510 minecraft:gold_block
fill 444 162 510 451 166 510 minecraft:blue_concrete
fill 444 162 552 445 162 552 minecraft:black_concrete
fill 446 162 552 448 197 552 minecraft:blue_concrete
setblock 452 162 510 minecraft:sea_lantern
fill 452 162 552 452 181 552 minecraft:blue_concrete
fill 453 162 510 457 182 510 minecraft:blue_concrete
fill 453 162 552 453 164 552 minecraft:gold_block
fill 454 162 552 455 233 552 minecraft:blue_concrete
fill 459 162 510 459 164 510 minecraft:gold_block
fill 460 162 510 461 162 510 minecraft:blue_concrete
setblock 462 162 510 minecraft:black_concrete
fill 463 162 510 463 215 510 minecraft:blue_concrete
fill 464 162 510 465 162 510 minecraft:black_concrete
fill 465 162 514 465 174 519 minecraft:blue_concrete
fill 465 162 520 465 164 520 minecraft:gold_block
fill 465 162 521 465 162 530 minecraft:blue_concrete
fill 465 162 531 465 162 532 minecraft:black_concrete
fill 465 162 533 465 181 535 minecraft:blue_concrete
fill 465 162 536 465 164 536 minecraft:gold_block
fill 465 162 537 465 233 537 minecraft:blue_concrete
setblock 465 162 538 minecraft:light_blue_stained_glass
setblock 465 162 539 minecraft:black_concrete
fill 465 162 540 465 174 540 minecraft:blue_concrete
fill 465 162 548 465 199 548 minecraft:blue_concrete
setblock 465 162 549 minecraft:black_concrete
fill 465 162 550 465 163 551 minecraft:blue_concrete
fill 423 163 514 423 171 514 minecraft:blue_concrete
fill 423 163 523 423 173 524 minecraft:blue_concrete
fill 423 163 526 423 196 526 minecraft:blue_concrete
fill 423 163 530 423 193 530 minecraft:blue_concrete
fill 423 163 540 423 170 541 minecraft:blue_concrete
setblock 423 163 542 minecraft:sea_lantern
fill 423 163 543 423 163 546 minecraft:blue_concrete
setblock 423 163 547 minecraft:white_concrete
fill 423 163 552 423 231 552 minecraft:blue_concrete
fill 428 163 510 428 233 510 minecraft:blue_concrete
fill 428 163 552 428 197 552 minecraft:blue_concrete
fill 429 163 510 430 163 510 minecraft:white_concrete
fill 431 163 510 432 187 510 minecraft:blue_concrete
fill 439 163 552 439 181 552 minecraft:blue_concrete
fill 444 163 552 445 183 552 minecraft:blue_concrete
fill 452 163 510 452 201 510 minecraft:blue_concrete
setblock 460 163 510 minecraft:sea_lantern
fill 461 163 510 462 182 510 minecraft:blue_concrete
fill 464 163 510 465 208 510 minecraft:blue_concrete
fill 465 163 521 465 174 529 minecraft:blue_concrete
setblock 465 163 530 minecraft:light_blue_stained_glass
fill 465 163 531 465 230 532 minecraft:blue_concrete
fill 465 163 538 465 171 539 minecraft:blue_concrete
fill 465 163 549 465 178 549 minecraft:blue_concrete
fill 423 164 542 423 172 542 minecraft:blue_concrete
setblock 423 164 543 minecraft:light_blue_stained_glass
fill 423 164 544 423 164 547 minecraft:blue_concrete
fill 429 164 510 430 164 510 minecraft:blue_concrete
fill 460 164 510 460 212 510 minecraft:blue_concrete
fill 465 164 530 465 184 530 minecraft:blue_concrete
setblock 465 164 550 minecraft:sea_lantern
fill 465 164 551 465 193 551 minecraft:blue_concrete
fill 423 165 518 423 171 518 minecraft:blue_concrete
fill 423 165 534 423 179 534 minecraft:blue_concrete
fill 423 165 543 423 171 543 minecraft:blue_concrete
setblock 423 165 544 minecraft:light_blue_stained_glass
fill 423 165 545 423 178 547 minecraft:blue_concrete
fill 423 165 550 423 166 550 minecraft:blue_concrete
setblock 426 165 513 minecraft:light[level=14]
setblock 426 165 521 minecraft:light[level=14]
setblock 426 165 529 minecraft:light[level=14]
setblock 426 165 537 minecraft:light[level=14]
setblock 426 165 545 minecraft:light[level=14]
setblock 427 165 510 minecraft:blue_concrete
setblock 429 165 510 minecraft:light_blue_stained_glass
fill 430 165 510 430 173 510 minecraft:blue_concrete
setblock 434 165 513 minecraft:light[level=14]
setblock 434 165 521 minecraft:light[level=14]
setblock 434 165 529 minecraft:light[level=14]
setblock 434 165 537 minecraft:light[level=14]
setblock 434 165 545 minecraft:light[level=14]
fill 437 165 552 437 179 552 minecraft:blue_concrete
setblock 438 165 552 minecraft:white_concrete
fill 440 165 552 442 170 552 minecraft:blue_concrete
setblock 442 165 513 minecraft:light[level=14]
setblock 442 165 521 minecraft:light[level=14]
setblock 442 165 529 minecraft:light[level=14]
setblock 442 165 537 minecraft:light[level=14]
setblock 442 165 545 minecraft:light[level=14]
fill 443 165 510 443 179 510 minecraft:blue_concrete
setblock 443 165 552 minecraft:sea_lantern
setblock 450 165 513 minecraft:light[level=14]
setblock 450 165 521 minecraft:light[level=14]
setblock 450 165 529 minecraft:light[level=14]
setblock 450 165 537 minecraft:light[level=14]
setblock 450 165 545 minecraft:light[level=14]
fill 453 165 552 453 179 552 minecraft:blue_concrete
setblock 458 165 513 minecraft:light[level=14]
setblock 458 165 521 minecraft:light[level=14]
setblock 458 165 529 minecraft:light[level=14]
setblock 458 165 537 minecraft:light[level=14]
setblock 458 165 545 minecraft:light[level=14]
fill 459 165 510 459 179 510 minecraft:blue_concrete
fill 465 165 520 465 169 520 minecraft:blue_concrete
fill 465 165 536 465 179 536 minecraft:blue_concrete
fill 465 165 550 465 213 550 minecraft:blue_concrete
fill 423 166 544 423 186 544 minecraft:blue_concrete
setblock 427 166 510 minecraft:white_concrete
fill 429 166 510 429 183 510 minecraft:blue_concrete
setblock 430 166 552 minecraft:sea_lantern
fill 438 166 552 438 173 552 minecraft:blue_concrete
fill 443 166 552 443 231 552 minecraft:blue_concrete
fill 456 166 552 461 181 552 minecraft:blue_concrete
setblock 462 166 552 minecraft:white_concrete
fill 463 166 552 465 167 552 minecraft:blue_concrete
fill 465 166 541 465 166 544 minecraft:blue_concrete
setblock 465 166 545 minecraft:sea_lantern
fill 465 166 546 465 210 547 minecraft:blue_concrete
setblock 423 167 519 minecraft:sea_lantern
fill 423 167 520 423 177 522 minecraft:blue_concrete
setblock 423 167 550 minecraft:sea_lantern
fill 427 167 510 427 179 510 minecraft:blue_concrete
setblock 430 167 552 minecraft:blue_concrete
fill 444 167 510 448 173 510 minecraft:blue_concrete
setblock 449 167 510 minecraft:white_concrete
fill 450 167 510 451 178 510 minecraft:blue_concrete
fill 462 167 552 462 168 552 minecraft:blue_concrete
fill 465 167 541 465 233 542 minecraft:blue_concrete
setblock 465 167 543 minecraft:light_blue_stained_glass
fill 465 167 544 465 230 545 minecraft:blue_concrete
fill 423 168 519 423 213 519 minecraft:blue_concrete
fill 423 168 550 423 179 550 minecraft:blue_concrete
setblock 430 168 552 minecraft:light_blue_stained_glass
setblock 439 168 510 minecraft:sea_lantern
fill 440 168 510 442 209 510 minecraft:blue_concrete
fill 449 168 510 449 233 510 minecraft:blue_concrete
setblock 463 168 552 minecraft:sea_lantern
fill 464 168 552 465 233 552 minecraft:blue_concrete
fill 465 168 543 465 233 543 minecraft:blue_concrete
fill 430 169 552 430 233 552 minecraft:blue_concrete
fill 439 169 510 439 182 510 minecraft:blue_concrete
setblock 462 169 552 minecraft:sea_lantern
fill 463 169 552 463 231 552 minecraft:blue_concrete
fill 462 170 552 462 212 552 minecraft:blue_concrete
setblock 465 170 520 minecraft:sea_lantern
fill 423 171 540 423 176 540 minecraft:blue_concrete
setblock 423 171 541 minecraft:white_concrete
setblock 423 171 548 minecraft:light_blue_stained_glass
fill 423 171 549 423 219 549 minecraft:blue_concrete
fill 440 171 552 440 182 552 minecraft:blue_concrete
setblock 441 171 552 minecraft:sea_lantern
fill 442 171 552 442 195 552 minecraft:blue_concrete
fill 465 171 520 465 179 520 minecraft:blue_concrete
setblock 423 172 514 minecraft:white_concrete
setblock 423 172 518 minecraft:light_blue_stained_glass
fill 423 172 538 423 230 538 minecraft:blue_concrete
setblock 423 172 539 minecraft:light_blue_stained_glass
fill 423 172 541 423 191 541 minecraft:blue_concrete
setblock 423 172 543 minecraft:sea_lantern
fill 423 172 548 423 214 548 minecraft:blue_concrete
setblock 433 172 552 minecraft:light_blue_stained_glass
fill 441 172 552 441 194 552 minecraft:blue_concrete
fill 465 172 538 465 195 538 minecraft:blue_concrete
setblock 465 172 539 minecraft:light_blue_stained_glass
fill 423 173 514 423 209 514 minecraft:blue_concrete
fill 423 173 518 423 179 518 minecraft:blue_concrete
fill 423 173 539 423 189 539 minecraft:blue_concrete
setblock 423 173 542 minecraft:sea_lantern
fill 423 173 543 423 206 543 minecraft:blue_concrete
setblock 426 173 513 minecraft:light[level=14]
setblock 426 173 521 minecraft:light[level=14]
setblock 426 173 529 minecraft:light[level=14]
setblock 426 173 537 minecraft:light[level=14]
setblock 426 173 545 minecraft:light[level=14]
fill 433 173 552 433 233 552 minecraft:blue_concrete
setblock 434 173 513 minecraft:light[level=14]
setblock 434 173 521 minecraft:light[level=14]
setblock 434 173 529 minecraft:light[level=14]
setblock 434 173 537 minecraft:light[level=14]
setblock 434 173 545 minecraft:light[level=14]
fill 439 173 527 441 173 529 minecraft:redstone_block
setblock 442 173 513 minecraft:light[level=14]
setblock 442 173 521 minecraft:light[level=14]
setblock 442 173 529 minecraft:light[level=14]
fill 442 173 536 444 173 538 minecraft:redstone_block
setblock 442 173 545 minecraft:light[level=14]
fill 446 173 528 448 173 530 minecraft:redstone_block
setblock 450 173 513 minecraft:light[level=14]
setblock 450 173 521 minecraft:light[level=14]
setblock 450 173 529 minecraft:light[level=14]
setblock 450 173 537 minecraft:light[level=14]
setblock 450 173 545 minecraft:light[level=14]
setblock 458 173 513 minecraft:light[level=14]
setblock 458 173 521 minecraft:light[level=14]
setblock 458 173 529 minecraft:light[level=14]
setblock 458 173 537 minecraft:light[level=14]
setblock 458 173 545 minecraft:light[level=14]
fill 465 173 539 465 233 539 minecraft:blue_concrete
setblock 423 174 515 minecraft:white_concrete
fill 423 174 516 423 178 517 minecraft:blue_concrete
setblock 423 174 523 minecraft:white_concrete
fill 423 174 524 423 234 524 minecraft:blue_concrete
fill 423 174 542 423 177 542 minecraft:blue_concrete
fill 428 174 532 441 174 532 minecraft:blue_concrete
setblock 430 174 510 minecraft:white_concrete
fill 431 174 525 433 175 525 minecraft:blue_concrete
fill 431 174 531 441 174 531 minecraft:blue_concrete
fill 431 174 533 441 174 533 minecraft:blue_concrete
fill 431 174 539 433 175 539 minecraft:blue_concrete
fill 432 174 526 435 175 526 minecraft:blue_concrete
fill 432 174 538 435 175 538 minecraft:blue_concrete
fill 433 174 527 437 174 527 minecraft:blue_concrete
fill 433 174 537 437 174 537 minecraft:blue_concrete
fill 434 174 528 438 174 528 minecraft:blue_concrete
fill 434 174 536 441 174 536 minecraft:blue_concrete
fill 435 174 529 438 174 529 minecraft:blue_concrete
fill 435 174 535 451 174 535 minecraft:blue_concrete
fill 436 174 520 436 175 522 minecraft:blue_concrete
fill 436 174 542 436 175 544 minecraft:blue_concrete
fill 437 174 521 437 175 524 minecraft:blue_concrete
fill 437 174 530 445 174 530 minecraft:blue_concrete
fill 437 174 534 449 174 534 minecraft:blue_concrete
fill 437 174 540 437 175 543 minecraft:blue_concrete
fill 438 174 522 438 174 526 minecraft:blue_concrete
fill 438 174 538 438 174 542 minecraft:blue_concrete
setblock 438 174 552 minecraft:light_blue_stained_glass
fill 439 174 523 439 174 526 minecraft:blue_concrete
fill 439 174 537 439 174 541 minecraft:blue_concrete
fill 440 174 524 440 174 526 minecraft:blue_concrete
fill 440 174 537 440 174 540 minecraft:blue_concrete
fill 441 174 526 448 174 526 minecraft:blue_concrete
fill 441 174 537 441 174 538 minecraft:blue_concrete
fill 442 174 520 444 174 525 minecraft:blue_concrete
fill 442 174 527 445 174 529 minecraft:blue_concrete
fill 442 174 539 444 174 544 minecraft:blue_concrete
fill 443 174 517 443 175 519 minecraft:blue_concrete
fill 443 174 545 443 175 547 minecraft:blue_concrete
fill 444 174 510 447 189 510 minecraft:blue_concrete
fill 445 174 531 455 174 533 minecraft:blue_concrete
fill 445 174 536 447 174 538 minecraft:blue_concrete
fill 446 174 524 448 174 525 minecraft:blue_concrete
fill 446 174 527 447 174 527 minecraft:blue_concrete
fill 446 174 539 448 174 540 minecraft:blue_concrete
fill 447 174 523 449 175 523 minecraft:blue_concrete
fill 447 174 541 449 175 541 minecraft:blue_concrete
setblock 448 174 510 minecraft:white_concrete
fill 448 174 522 450 175 522 minecraft:blue_concrete
fill 448 174 536 452 174 536 minecraft:blue_concrete
fill 448 174 538 448 175 538 minecraft:blue_concrete
fill 448 174 542 450 175 542 minecraft:blue_concrete
fill 449 174 521 450 175 521 minecraft:blue_concrete
fill 449 174 524 449 175 524 minecraft:blue_concrete
fill 449 174 527 449 174 530 minecraft:blue_concrete
fill 449 174 537 453 174 537 minecraft:blue_concrete
fill 449 174 540 449 175 540 minecraft:blue_concrete
fill 449 174 543 450 175 543 minecraft:blue_concrete
fill 450 174 520 450 175 520 minecraft:blue_concrete
fill 450 174 527 451 174 529 minecraft:blue_concrete
fill 450 174 544 450 175 544 minecraft:blue_concrete
fill 451 174 526 454 175 526 minecraft:blue_concrete
fill 451 174 538 454 175 538 minecraft:blue_concrete
fill 452 174 527 452 175 528 minecraft:blue_concrete
fill 453 174 525 455 175 525 minecraft:blue_concrete
fill 453 174 527 453 175 527 minecraft:blue_concrete
fill 453 174 539 455 175 539 minecraft:blue_concrete
fill 456 174 532 458 175 532 minecraft:blue_concrete
fill 423 175 515 423 230 515 minecraft:blue_concrete
fill 423 175 523 423 215 523 minecraft:blue_concrete
fill 424 175 511 427 175 551 minecraft:black_concrete
fill 428 175 511 430 175 531 minecraft:black_concrete
fill 428 175 532 432 175 532 minecraft:blue_concrete
fill 428 175 533 430 175 551 minecraft:black_concrete
fill 430 175 510 430 229 510 minecraft:blue_concrete
fill 431 175 511 435 175 524 minecraft:black_concrete
fill 431 175 526 431 175 530 minecraft:black_concrete
fill 431 175 531 435 175 531 minecraft:blue_concrete
fill 431 175 533 435 175 533 minecraft:blue_concrete
fill 431 175 534 431 175 538 minecraft:black_concrete
fill 431 175 540 435 175 551 minecraft:black_concrete
fill 432 175 527 432 175 530 minecraft:black_concrete
fill 432 175 534 432 175 537 minecraft:black_concrete
fill 433 175 527 434 175 527 minecraft:blue_concrete
fill 433 175 528 433 175 530 minecraft:black_concrete
fill 433 175 532 438 175 532 minecraft:black_concrete
fill 433 175 534 433 175 536 minecraft:black_concrete
fill 433 175 537 434 175 537 minecraft:blue_concrete
fill 434 175 525 437 175 525 minecraft:black_concrete
setblock 434 175 528 minecraft:blue_concrete
fill 434 175 529 434 175 530 minecraft:black_concrete
fill 434 175 534 434 175 535 minecraft:black_concrete
setblock 434 175 536 minecraft:blue_concrete
fill 434 175 539 437 175 539 minecraft:black_concrete
fill 435 175 527 435 175 528 minecraft:black_concrete
setblock 435 175 529 minecraft:blue_concrete
fill 435 175 530 436 175 530 minecraft:black_concrete
fill 435 175 534 436 175 534 minecraft:black_concrete
setblock 435 175 535 minecraft:blue_concrete
fill 435 175 536 435 175 537 minecraft:black_concrete
fill 436 175 510 437 176 510 minecraft:blue_concrete
fill 436 175 511 442 175 519 minecraft:black_concrete
fill 436 175 523 436 175 524 minecraft:black_concrete
fill 436 175 526 437 175 526 minecraft:black_concrete
fill 436 175 527 437 175 527 minecraft:blue_concrete
fill 436 175 528 437 175 529 minecraft:black_concrete
fill 436 175 531 439 175 531 minecraft:black_concrete
fill 436 175 533 439 175 533 minecraft:black_concrete
fill 436 175 535 438 175 536 minecraft:black_concrete
fill 436 175 537 437 175 537 minecraft:blue_concrete
fill 436 175 538 437 175 538 minecraft:black_concrete
fill 436 175 540 436 175 541 minecraft:black_concrete
fill 436 175 545 442 175 551 minecraft:black_concrete
fill 437 175 520 441 175 520 minecraft:black_concrete
setblock 437 175 530 minecraft:blue_concrete
setblock 437 175 534 minecraft:blue_concrete
fill 437 175 544 441 175 544 minecraft:black_concrete
fill 438 175 510 438 176 510 minecraft:white_concrete
fill 438 175 521 441 175 521 minecraft:black_concrete
fill 438 175 522 438 175 523 minecraft:blue_concrete
fill 438 175 524 439 175 524 minecraft:black_concrete
setblock 438 175 525 minecraft:blue_concrete
fill 438 175 526 438 175 530 minecraft:sea_lantern
fill 438 175 534 439 175 534 minecraft:black_concrete
fill 438 175 537 440 175 537 minecraft:black_concrete
fill 438 175 538 438 175 539 minecraft:blue_concrete
fill 438 175 540 439 175 540 minecraft:black_concrete
fill 438 175 541 438 175 542 minecraft:blue_concrete
fill 438 175 543 441 175 543 minecraft:black_concrete
fill 438 175 552 438 233 552 minecraft:blue_concrete
fill 439 175 522 441 175 522 minecraft:black_concrete
setblock 439 175 523 minecraft:blue_concrete
fill 439 175 525 447 175 525 minecraft:black_concrete
fill 439 175 526 442 175 526 minecraft:sea_lantern
fill 439 175 527 441 175 529 minecraft:black_concrete
fill 439 175 530 445 175 530 minecraft:sea_lantern
fill 439 175 532 440 175 532 minecraft:gold_block
fill 439 175 535 440 175 535 minecraft:black_concrete
setblock 439 175 536 minecraft:blue_concrete
fill 439 175 538 440 175 539 minecraft:black_concrete
setblock 439 175 541 minecraft:blue_concrete
fill 439 175 542 441 175 542 minecraft:black_concrete
fill 440 175 523 441 175 523 minecraft:black_concrete
setblock 440 175 524 minecraft:blue_concrete
setblock 440 175 531 minecraft:gold_block
fill 440 175 533 440 175 534 minecraft:gold_block
setblock 440 175 536 minecraft:black_concrete
setblock 440 175 540 minecraft:blue_concrete
fill 440 175 541 441 175 541 minecraft:black_concrete
setblock 441 175 524 minecraft:black_concrete
fill 441 175 531 441 175 539 minecraft:sea_lantern
setblock 441 175 540 minecraft:black_concrete
fill 442 175 520 442 175 524 minecraft:blue_concrete
fill 442 175 527 442 175 529 minecraft:sea_lantern
fill 442 175 534 445 175 535 minecraft:sea_lantern
fill 442 175 536 444 175 538 minecraft:black_concrete
fill 442 175 539 445 175 539 minecraft:sea_lantern
fill 442 175 540 442 175 544 minecraft:blue_concrete
fill 443 175 511 464 175 516 minecraft:black_concrete
fill 443 175 520 444 175 521 minecraft:blue_concrete
fill 443 175 522 443 175 524 minecraft:black_concrete
fill 443 175 526 444 175 527 minecraft:black_concrete
fill 443 175 528 443 175 529 minecraft:gold_block
fill 443 175 540 443 175 542 minecraft:black_concrete
fill 443 175 543 444 175 544 minecraft:blue_concrete
fill 443 175 548 464 175 551 minecraft:black_concrete
fill 444 175 517 464 175 519 minecraft:black_concrete
fill 444 175 522 444 175 524 minecraft:blue_concrete
setblock 444 175 528 minecraft:black_concrete
setblock 444 175 529 minecraft:gold_block
fill 444 175 540 444 175 542 minecraft:blue_concrete
fill 444 175 545 464 175 547 minecraft:black_concrete
fill 445 175 520 445 175 524 minecraft:black_concrete
setblock 445 175 526 minecraft:blue_concrete
fill 445 175 527 445 175 529 minecraft:sea_lantern
fill 445 175 531 445 175 533 minecraft:sea_lantern
fill 445 175 536 445 175 538 minecraft:sea_lantern
fill 445 175 540 445 175 544 minecraft:black_concrete
fill 446 175 520 446 175 523 minecraft:black_concrete
setblock 446 175 524 minecraft:blue_concrete
fill 446 175 526 447 175 526 minecraft:black_concrete
fill 446 175 527 449 175 527 minecraft:sea_lantern
fill 446 175 528 448 175 530 minecraft:black_concrete
fill 446 175 531 449 175 531 minecraft:sea_lantern
fill 446 175 532 446 175 534 minecraft:gold_block
fill 446 175 535 446 175 539 minecraft:black_concrete
setblock 446 175 540 minecraft:blue_concrete
fill 446 175 541 446 175 544 minecraft:black_concrete
fill 447 175 520 447 175 522 minecraft:black_concrete
fill 447 175 524 448 175 524 minecraft:black_concrete
setblock 447 175 532 minecraft:gold_block
fill 447 175 533 448 175 535 minecraft:black_concrete
setblock 447 175 536 minecraft:blue_concrete
fill 447 175 537 447 175 540 minecraft:black_concrete
fill 447 175 542 447 175 544 minecraft:black_concrete
fill 448 175 510 448 176 510 minecraft:blue_concrete
fill 448 175 520 448 175 521 minecraft:black_concrete
fill 448 175 525 448 175 526 minecraft:blue_concrete
fill 448 175 532 453 175 532 minecraft:black_concrete
fill 448 175 536 448 175 537 minecraft:black_concrete
setblock 448 175 539 minecraft:blue_concrete
setblock 448 175 540 minecraft:black_concrete
fill 448 175 543 448 175 544 minecraft:black_concrete
setblock 449 175 520 minecraft:black_concrete
fill 449 175 525 450 175 526 minecraft:black_concrete
fill 449 175 528 449 175 530 minecraft:sea_lantern
fill 449 175 533 450 175 533 minecraft:black_concrete
setblock 449 175 534 minecraft:blue_concrete
fill 449 175 535 450 175 536 minecraft:black_concrete
fill 449 175 537 450 175 537 minecraft:blue_concrete
fill 449 175 538 450 175 539 minecraft:black_concrete
setblock 449 175 544 minecraft:black_concrete
fill 450 175 523 464 175 524 minecraft:black_concrete
setblock 450 175 527 minecraft:blue_concrete
fill 450 175 528 450 175 531 minecraft:black_concrete
fill 450 175 534 464 175 534 minecraft:black_concrete
fill 450 175 540 464 175 541 minecraft:black_concrete
fill 451 175 520 464 175 522 minecraft:black_concrete
fill 451 175 525 452 175 525 minecraft:black_concrete
fill 451 175 527 451 175 528 minecraft:black_concrete
setblock 451 175 529 minecraft:blue_concrete
fill 451 175 530 464 175 530 minecraft:black_concrete
fill 451 175 531 455 175 531 minecraft:blue_concrete
fill 451 175 533 455 175 533 minecraft:blue_concrete
setblock 451 175 535 minecraft:blue_concrete
fill 451 175 536 451 175 537 minecraft:black_concrete
fill 451 175 539 452 175 539 minecraft:black_concrete
fill 451 175 542 464 175 544 minecraft:black_concrete
fill 452 175 529 464 175 529 minecraft:black_concrete
fill 452 175 535 464 175 535 minecraft:black_concrete
fill 452 175 536 452 175 537 minecraft:blue_concrete
fill 453 175 528 464 175 528 minecraft:black_concrete
fill 453 175 536 464 175 536 minecraft:black_concrete
setblock 453 175 537 minecraft:blue_concrete
fill 454 175 527 464 175 527 minecraft:black_concrete
fill 454 175 532 455 175 532 minecraft:blue_concrete
fill 454 175 537 464 175 537 minecraft:black_concrete
fill 455 175 526 464 175 526 minecraft:black_concrete
fill 455 175 538 464 175 538 minecraft:black_concrete
fill 456 175 525 464 175 525 minecraft:black_concrete
fill 456 175 531 464 175 531 minecraft:black_concrete
fill 456 175 533 464 175 533 minecraft:black_concrete
fill 456 175 539 464 175 539 minecraft:black_concrete
fill 459 175 532 464 175 532 minecraft:black_concrete
fill 465 175 514 465 188 518 minecraft:blue_concrete
setblock 465 175 519 minecraft:white_concrete
fill 465 175 521 465 195 523 minecraft:blue_concrete
setblock 465 175 524 minecraft:white_concrete
fill 465 175 525 465 227 526 minecraft:blue_concrete
setblock 465 175 527 minecraft:white_concrete
fill 465 175 528 465 225 529 minecraft:blue_concrete
setblock 465 175 540 minecraft:white_concrete
setblock 425 176 552 minecraft:light_blue_stained_glass
fill 426 176 552 427 206 552 minecraft:blue_concrete
setblock 429 176 552 minecraft:sea_lantern
fill 441 176 531 441 176 533 minecraft:lime_stained_glass
fill 442 176 530 444 176 530 minecraft:lime_stained_glass
fill 442 176 534 444 176 534 minecraft:lime_stained_glass
fill 445 176 531 445 176 533 minecraft:lime_stained_glass
fill 465 176 519 465 177 519 minecraft:blue_concrete
fill 465 176 524 465 233 524 minecraft:blue_concrete
fill 465 176 527 465 233 527 minecraft:blue_concrete
fill 465 176 540 465 233 540 minecraft:blue_concrete
setblock 423 177 540 minecraft:sea_lantern
fill 425 177 552 425 195 552 minecraft:blue_concrete
fill 429 177 552 429 194 552 minecraft:blue_concrete
fill 432 177 530 440 177 534 minecraft:light_gray_concrete
fill 433 177 527 453 177 529 minecraft:light_gray_concrete
fill 433 177 535 453 177 537 minecraft:light_gray_concrete
fill 434 177 526 452 180 526 minecraft:light_gray_concrete
fill 434 177 538 452 180 538 minecraft:light_gray_concrete
fill 435 177 525 451 180 525 minecraft:light_gray_concrete
fill 435 177 539 451 180 539 minecraft:light_gray_concrete
fill 436 177 510 436 191 510 minecraft:blue_concrete
fill 436 177 524 450 180 524 minecraft:light_gray_concrete
fill 436 177 540 450 180 540 minecraft:light_gray_concrete
setblock 437 177 510 minecraft:white_concrete
fill 437 177 523 449 180 523 minecraft:light_gray_concrete
fill 437 177 541 449 180 541 minecraft:light_gray_concrete
fill 438 177 510 438 196 510 minecraft:blue_concrete
fill 438 177 522 448 180 522 minecraft:light_gray_concrete
fill 438 177 542 448 180 542 minecraft:light_gray_concrete
fill 441 177 521 445 180 521 minecraft:light_gray_concrete
fill 441 177 530 441 177 531 minecraft:light_gray_concrete
fill 441 177 533 441 177 534 minecraft:light_gray_concrete
fill 441 177 543 445 180 543 minecraft:light_gray_concrete
setblock 442 177 530 minecraft:light_gray_concrete
setblock 442 177 534 minecraft:light_gray_concrete
fill 444 177 530 454 177 530 minecraft:light_gray_concrete
fill 444 177 534 454 177 534 minecraft:light_gray_concrete
fill 445 177 531 454 177 531 minecraft:light_gray_concrete
fill 445 177 533 454 177 533 minecraft:light_gray_concrete
fill 446 177 532 454 177 532 minecraft:light_gray_concrete
setblock 448 177 510 minecraft:white_concrete
setblock 423 178 520 minecraft:white_concrete
fill 423 178 521 423 193 522 minecraft:blue_concrete
setblock 423 178 540 minecraft:white_concrete
setblock 423 178 542 minecraft:sea_lantern
fill 424 178 510 424 185 510 minecraft:blue_concrete
setblock 425 178 510 minecraft:white_concrete
fill 430 178 528 430 179 536 minecraft:sea_lantern
fill 431 178 526 431 179 529 minecraft:sea_lantern
fill 431 178 530 439 178 534 minecraft:light_gray_concrete
fill 431 178 535 431 179 538 minecraft:sea_lantern
fill 432 178 524 432 179 526 minecraft:sea_lantern
fill 432 178 527 442 178 529 minecraft:light_gray_concrete
fill 432 178 535 442 178 537 minecraft:light_gray_concrete
fill 432 178 538 432 179 540 minecraft:sea_lantern
fill 433 178 523 433 179 524 minecraft:sea_lantern
fill 433 178 525 433 179 526 minecraft:light_gray_concrete
fill 433 178 538 433 179 539 minecraft:light_gray_concrete
fill 433 178 540 433 179 541 minecraft:sea_lantern
fill 434 178 522 434 179 523 minecraft:sea_lantern
fill 434 178 524 434 179 525 minecraft:light_gray_concrete
fill 434 178 539 434 179 540 minecraft:light_gray_concrete
fill 434 178 541 434 179 542 minecraft:sea_lantern
fill 435 178 521 435 179 522 minecraft:sea_lantern
fill 435 178 523 435 179 524 minecraft:light_gray_concrete
fill 435 178 540 435 179 541 minecraft:light_gray_concrete
fill 435 178 542 435 179 543 minecraft:sea_lantern
fill 436 178 521 437 179 521 minecraft:sea_lantern
fill 436 178 522 436 179 523 minecraft:light_gray_concrete
fill 436 178 541 436 179 542 minecraft:light_gray_concrete
fill 436 178 543 437 179 543 minecraft:sea_lantern
fill 437 178 510 437 218 510 minecraft:blue_concrete
fill 437 178 520 440 179 520 minecraft:sea_lantern
fill 437 178 522 437 179 522 minecraft:light_gray_concrete
fill 437 178 542 437 179 542 minecraft:light_gray_concrete
fill 437 178 544 440 179 544 minecraft:sea_lantern
fill 438 178 521 440 179 521 minecraft:light_gray_concrete
fill 438 178 543 440 179 543 minecraft:light_gray_concrete
fill 439 178 519 447 179 519 minecraft:sea_lantern
fill 439 178 545 447 179 545 minecraft:sea_lantern
fill 440 178 530 440 178 531 minecraft:light_gray_concrete
fill 440 178 532 440 181 532 minecraft:light_blue_stained_glass
fill 440 178 533 440 178 534 minecraft:light_gray_concrete
fill 441 178 520 445 179 520 minecraft:light_gray_concrete
fill 441 178 530 441 180 530 minecraft:light_blue_stained_glass
fill 441 178 534 441 180 534 minecraft:light_blue_stained_glass
fill 441 178 544 445 179 544 minecraft:light_gray_concrete
fill 443 178 527 454 178 528 minecraft:light_gray_concrete
fill 443 178 529 443 181 529 minecraft:light_blue_stained_glass
fill 443 178 535 443 181 535 minecraft:light_blue_stained_glass
fill 443 178 536 454 178 537 minecraft:light_gray_concrete
fill 444 178 529 454 178 529 minecraft:light_gray_concrete
fill 444 178 535 454 178 535 minecraft:light_gray_concrete
fill 445 178 530 445 180 530 minecraft:light_blue_stained_glass
fill 445 178 534 445 180 534 minecraft:light_blue_stained_glass
fill 446 178 520 449 179 520 minecraft:sea_lantern
fill 446 178 521 448 179 521 minecraft:light_gray_concrete
fill 446 178 530 455 178 531 minecraft:light_gray_concrete
fill 446 178 532 446 181 532 minecraft:light_blue_stained_glass
fill 446 178 533 455 178 534 minecraft:light_gray_concrete
fill 446 178 543 448 179 543 minecraft:light_gray_concrete
fill 446 178 544 449 179 544 minecraft:sea_lantern
fill 447 178 532 455 178 532 minecraft:light_gray_concrete
fill 448 178 510 448 196 510 minecraft:blue_concrete
fill 449 178 521 451 179 521 minecraft:sea_lantern
fill 449 178 522 450 179 522 minecraft:light_gray_concrete
fill 449 178 542 450 179 542 minecraft:light_gray_concrete
fill 449 178 543 451 179 543 minecraft:sea_lantern
fill 450 178 523 451 179 523 minecraft:light_gray_concrete
fill 450 178 541 451 179 541 minecraft:light_gray_concrete
fill 451 178 522 452 179 522 minecraft:sea_lantern
fill 451 178 524 452 179 524 minecraft:light_gray_concrete
fill 451 178 540 452 179 540 minecraft:light_gray_concrete
fill 451 178 542 452 179 542 minecraft:sea_lantern
fill 452 178 523 453 179 523 minecraft:sea_lantern
fill 452 178 525 453 179 525 minecraft:light_gray_concrete
fill 452 178 539 453 179 539 minecraft:light_gray_concrete
fill 452 178 541 453 179 541 minecraft:sea_lantern
fill 453 178 524 454 179 524 minecraft:sea_lantern
fill 453 178 526 453 179 526 minecraft:light_gray_concrete
fill 453 178 538 453 179 538 minecraft:light_gray_concrete
fill 453 178 540 454 179 540 minecraft:sea_lantern
fill 454 178 525 454 179 526 minecraft:sea_lantern
fill 454 178 538 454 179 539 minecraft:sea_lantern
fill 455 178 526 455 179 529 minecraft:sea_lantern
fill 455 178 535 455 179 538 minecraft:sea_lantern
fill 456 178 528 456 179 536 minecraft:sea_lantern
setblock 465 178 519 minecraft:white_concrete
fill 423 179 516 423 230 516 minecraft:blue_concrete
setblock 423 179 517 minecraft:white_concrete
fill 423 179 520 423 233 520 minecraft:blue_concrete
fill 423 179 540 423 229 540 minecraft:blue_concrete
fill 423 179 542 423 198 542 minecraft:blue_concrete
fill 423 179 545 423 189 545 minecraft:blue_concrete
setblock 423 179 546 minecraft:white_concrete
fill 423 179 547 423 214 547 minecraft:blue_concrete
fill 425 179 510 425 229 510 minecraft:blue_concrete
fill 431 179 530 438 179 534 minecraft:light_gray_concrete
fill 432 179 527 439 179 529 minecraft:light_gray_concrete
fill 432 179 535 439 179 537 minecraft:light_gray_concrete
fill 439 179 530 439 183 534 minecraft:light_blue_stained_glass
fill 439 179 547 439 218 547 minecraft:waxed_copper_block
fill 440 179 527 440 179 528 minecraft:light_gray_concrete
fill 440 179 529 440 182 531 minecraft:light_blue_stained_glass
fill 440 179 533 440 182 535 minecraft:light_blue_stained_glass
fill 440 179 536 440 179 537 minecraft:light_gray_concrete
fill 441 179 527 454 179 527 minecraft:light_gray_concrete
fill 441 179 528 442 182 529 minecraft:light_blue_stained_glass
fill 441 179 535 442 182 536 minecraft:light_blue_stained_glass
fill 441 179 537 454 179 537 minecraft:light_gray_concrete
fill 443 179 528 445 183 528 minecraft:light_blue_stained_glass
fill 443 179 536 445 183 536 minecraft:light_blue_stained_glass
fill 444 179 529 446 182 529 minecraft:light_blue_stained_glass
fill 444 179 535 446 182 535 minecraft:light_blue_stained_glass
fill 446 179 528 454 179 528 minecraft:light_gray_concrete
fill 446 179 530 447 182 531 minecraft:light_blue_stained_glass
fill 446 179 533 447 182 534 minecraft:light_blue_stained_glass
fill 446 179 536 454 179 536 minecraft:light_gray_concrete
fill 447 179 529 454 179 529 minecraft:light_gray_concrete
fill 447 179 532 447 183 532 minecraft:light_blue_stained_glass
fill 447 179 535 454 179 535 minecraft:light_gray_concrete
fill 448 179 530 455 179 534 minecraft:light_gray_concrete
fill 450 179 510 450 225 510 minecraft:blue_concrete
setblock 451 179 510 minecraft:sea_lantern
fill 459 179 540 461 218 542 minecraft:waxed_copper_block
fill 465 179 511 465 180 512 minecraft:blue_concrete
setblock 465 179 513 minecraft:sea_lantern
fill 465 179 519 465 184 519 minecraft:blue_concrete
setblock 465 179 549 minecraft:white_concrete
fill 423 180 517 423 233 517 minecraft:blue_concrete
fill 423 180 518 423 182 518 minecraft:gold_block
fill 423 180 534 423 182 534 minecraft:gold_block
fill 423 180 535 423 232 535 minecraft:blue_concrete
setblock 423 180 536 minecraft:light_blue_stained_glass
fill 423 180 546 423 227 546 minecraft:blue_concrete
fill 423 180 550 423 182 550 minecraft:gold_block
fill 427 180 510 427 182 510 minecraft:gold_block
fill 432 180 530 437 180 534 minecraft:light_gray_concrete
fill 433 180 527 438 180 529 minecraft:light_gray_concrete
fill 433 180 535 438 180 537 minecraft:light_gray_concrete
fill 437 180 552 437 182 552 minecraft:gold_block
fill 438 180 530 438 182 534 minecraft:light_blue_stained_glass
fill 439 180 527 440 180 527 minecraft:light_gray_concrete
fill 439 180 528 439 182 529 minecraft:light_blue_stained_glass
fill 439 180 535 439 182 536 minecraft:light_blue_stained_glass
fill 439 180 537 440 180 537 minecraft:light_gray_concrete
fill 440 180 528 440 182 528 minecraft:light_blue_stained_glass
fill 440 180 536 440 182 536 minecraft:light_blue_stained_glass
fill 441 180 527 445 182 527 minecraft:light_blue_stained_glass
fill 441 180 537 445 182 537 minecraft:light_blue_stained_glass
fill 443 180 510 443 182 510 minecraft:gold_block
fill 446 180 527 453 180 527 minecraft:light_gray_concrete
fill 446 180 528 447 182 528 minecraft:light_blue_stained_glass
fill 446 180 536 447 182 536 minecraft:light_blue_stained_glass
fill 446 180 537 453 180 537 minecraft:light_gray_concrete
fill 447 180 529 447 182 529 minecraft:light_blue_stained_glass
fill 447 180 535 447 182 535 minecraft:light_blue_stained_glass
fill 448 180 528 453 180 529 minecraft:light_gray_concrete
fill 448 180 530 448 182 534 minecraft:light_blue_stained_glass
fill 448 180 535 453 180 536 minecraft:light_gray_concrete
fill 449 180 530 454 180 534 minecraft:light_gray_concrete
fill 449 180 552 449 184 552 minecraft:blue_concrete
setblock 450 180 552 minecraft:light_blue_stained_glass
setblock 451 180 510 minecraft:light_blue_stained_glass
fill 451 180 552 451 204 552 minecraft:blue_concrete
fill 453 180 552 453 182 552 minecraft:gold_block
fill 459 180 510 459 182 510 minecraft:gold_block
setblock 465 180 513 minecraft:blue_concrete
fill 465 180 520 465 182 520 minecraft:gold_block
fill 465 180 536 465 182 536 minecraft:gold_block
fill 465 180 549 465 194 549 minecraft:blue_concrete
setblock 423 181 536 minecraft:blue_concrete
setblock 426 181 513 minecraft:light[level=14]
setblock 426 181 521 minecraft:light[level=14]
setblock 426 181 529 minecraft:light[level=14]
setblock 426 181 537 minecraft:light[level=14]
setblock 426 181 545 minecraft:light[level=14]
setblock 434 181 513 minecraft:light[level=14]
setblock 434 181 521 minecraft:light[level=14]
setblock 434 181 529 minecraft:light[level=14]
setblock 434 181 537 minecraft:light[level=14]
setblock 434 181 545 minecraft:light[level=14]
fill 434 181 552 435 190 552 minecraft:blue_concrete
setblock 436 181 552 minecraft:light_blue_stained_glass
setblock 437 181 532 minecraft:light_blue_stained_glass
setblock 438 181 529 minecraft:light_blue_stained_glass
setblock 438 181 535 minecraft:light_blue_stained_glass
fill 438 181 546 438 181 548 minecraft:waxed_cut_copper
fill 439 181 546 440 181 546 minecraft:waxed_cut_copper
fill 439 181 548 440 181 548 minecraft:waxed_cut_copper
setblock 440 181 527 minecraft:light_blue_stained_glass
setblock 440 181 537 minecraft:light_blue_stained_glass
setblock 440 181 547 minecraft:waxed_cut_copper
setblock 442 181 513 minecraft:light[level=14]
setblock 442 181 521 minecraft:light[level=14]
setblock 442 181 545 minecraft:light[level=14]
setblock 443 181 526 minecraft:light_blue_stained_glass
setblock 443 181 538 minecraft:light_blue_stained_glass
setblock 446 181 527 minecraft:light_blue_stained_glass
setblock 446 181 537 minecraft:light_blue_stained_glass
setblock 448 181 529 minecraft:light_blue_stained_glass
setblock 448 181 535 minecraft:light_blue_stained_glass
setblock 449 181 532 minecraft:light_blue_stained_glass
setblock 450 181 513 minecraft:light[level=14]
setblock 450 181 521 minecraft:light[level=14]
setblock 450 181 529 minecraft:light[level=14]
setblock 450 181 537 minecraft:light[level=14]
setblock 450 181 545 minecraft:light[level=14]
fill 450 181 552 450 202 552 minecraft:blue_concrete
fill 451 181 510 451 233 510 minecraft:blue_concrete
setblock 458 181 513 minecraft:light[level=14]
setblock 458 181 521 minecraft:light[level=14]
setblock 458 181 529 minecraft:light[level=14]
setblock 458 181 537 minecraft:light[level=14]
fill 458 181 540 458 181 542 minecraft:waxed_cut_copper
setblock 458 181 545 minecraft:light[level=14]
fill 459 181 539 461 181 539 minecraft:waxed_cut_copper
fill 459 181 543 461 181 543 minecraft:waxed_cut_copper
fill 462 181 540 462 181 542 minecraft:waxed_cut_copper
fill 465 181 511 465 227 511 minecraft:blue_concrete
fill 465 181 512 465 181 513 minecraft:light_blue_stained_glass
setblock 423 182 511 minecraft:white_concrete
setblock 423 182 536 minecraft:white_concrete
fill 436 182 552 436 233 552 minecraft:blue_concrete
setblock 439 182 552 minecraft:white_concrete
setblock 452 182 552 minecraft:white_concrete
setblock 456 182 552 minecraft:light_blue_stained_glass
fill 457 182 552 461 226 552 minecraft:blue_concrete
fill 465 182 512 465 188 513 minecraft:blue_concrete
fill 465 182 533 465 185 534 minecraft:blue_concrete
setblock 465 182 535 minecraft:sea_lantern
fill 423 183 511 423 208 511 minecraft:blue_concrete
fill 423 183 518 423 188 518 minecraft:blue_concrete
fill 423 183 534 423 188 534 minecraft:blue_concrete
fill 423 183 536 423 204 536 minecraft:blue_concrete
fill 423 183 550 423 188 550 minecraft:blue_concrete
fill 427 183 510 427 188 510 minecraft:blue_concrete
fill 437 183 552 437 188 552 minecraft:blue_concrete
setblock 439 183 510 minecraft:sea_lantern
setblock 439 183 552 minecraft:blue_concrete
fill 440 183 529 440 183 530 minecraft:light_blue_stained_glass
fill 440 183 534 440 183 535 minecraft:light_blue_stained_glass
setblock 440 183 552 minecraft:white_concrete
fill 441 183 528 441 183 529 minecraft:light_blue_stained_glass
fill 441 183 535 441 183 536 minecraft:light_blue_stained_glass
setblock 442 183 528 minecraft:light_blue_stained_glass
setblock 442 183 536 minecraft:light_blue_stained_glass
fill 443 183 510 443 188 510 minecraft:blue_concrete
fill 445 183 529 446 183 529 minecraft:light_blue_stained_glass
fill 445 183 535 446 183 535 minecraft:light_blue_stained_glass
fill 446 183 530 447 183 530 minecraft:light_blue_stained_glass
fill 446 183 534 447 183 534 minecraft:light_blue_stained_glass
setblock 447 183 531 minecraft:light_blue_stained_glass
setblock 447 183 533 minecraft:light_blue_stained_glass
fill 452 183 552 453 184 552 minecraft:blue_concrete
fill 453 183 510 454 194 510 minecraft:blue_concrete
setblock 455 183 510 minecraft:sea_lantern
fill 456 183 510 457 183 510 minecraft:blue_concrete
fill 456 183 552 456 190 552 minecraft:blue_concrete
fill 459 183 510 459 188 510 minecraft:blue_concrete
setblock 461 183 510 minecraft:light_blue_stained_glass
fill 462 183 510 462 234 510 minecraft:blue_concrete
fill 465 183 520 465 188 520 minecraft:blue_concrete
fill 465 183 535 465 188 536 minecraft:blue_concrete
setblock 423 184 525 minecraft:white_concrete
setblock 429 184 510 minecraft:sea_lantern
fill 439 184 510 439 230 510 minecraft:blue_concrete
setblock 439 184 552 minecraft:light_blue_stained_glass
fill 440 184 552 440 231 552 minecraft:blue_concrete
fill 444 184 552 444 229 552 minecraft:blue_concrete
setblock 445 184 552 minecraft:sea_lantern
fill 455 184 510 455 207 510 minecraft:blue_concrete
setblock 456 184 510 minecraft:sea_lantern
fill 457 184 510 457 208 510 minecraft:blue_concrete
fill 461 184 510 461 233 510 minecraft:blue_concrete
fill 423 185 525 423 202 525 minecraft:blue_concrete
fill 429 185 510 429 206 510 minecraft:blue_concrete
fill 439 185 552 439 233 552 minecraft:blue_concrete
fill 445 185 552 445 187 552 minecraft:blue_concrete
setblock 449 185 552 minecraft:white_concrete
fill 452 185 552 452 195 552 minecraft:blue_concrete
setblock 453 185 552 minecraft:white_concrete
fill 456 185 510 456 233 510 minecraft:blue_concrete
setblock 465 185 519 minecraft:light_blue_stained_glass
setblock 465 185 530 minecraft:sea_lantern
setblock 424 186 510 minecraft:sea_lantern
fill 438 186 546 438 186 548 minecraft:waxed_cut_copper
fill 439 186 546 440 186 546 minecraft:waxed_cut_copper
fill 439 186 548 440 186 548 minecraft:waxed_cut_copper
setblock 440 186 547 minecraft:waxed_cut_copper
fill 449 186 552 449 233 552 minecraft:blue_concrete
fill 453 186 552 453 188 552 minecraft:blue_concrete
fill 465 186 519 465 229 519 minecraft:blue_concrete
fill 465 186 530 465 230 530 minecraft:blue_concrete
fill 465 186 533 465 231 533 minecraft:blue_concrete
setblock 465 186 534 minecraft:white_concrete
setblock 423 187 544 minecraft:sea_lantern
fill 424 187 510 424 211 510 minecraft:blue_concrete
fill 465 187 534 465 196 534 minecraft:blue_concrete
fill 423 188 544 423 221 544 minecraft:blue_concrete
fill 431 188 510 431 198 510 minecraft:blue_concrete
setblock 432 188 510 minecraft:white_concrete
setblock 445 188 552 minecraft:white_concrete
fill 423 189 518 423 191 518 minecraft:gold_block
fill 423 189 534 423 191 534 minecraft:gold_block
fill 423 189 550 423 191 550 minecraft:gold_block
setblock 426 189 513 minecraft:light[level=14]
setblock 426 189 521 minecraft:light[level=14]
setblock 426 189 529 minecraft:light[level=14]
setblock 426 189 537 minecraft:light[level=14]
setblock 426 189 545 minecraft:light[level=14]
fill 427 189 510 427 191 510 minecraft:gold_block
fill 432 189 510 432 231 510 minecraft:blue_concrete
setblock 434 189 510 minecraft:sea_lantern
setblock 434 189 513 minecraft:light[level=14]
setblock 434 189 521 minecraft:light[level=14]
setblock 434 189 529 minecraft:light[level=14]
setblock 434 189 537 minecraft:light[level=14]
setblock 434 189 545 minecraft:light[level=14]
setblock 435 189 510 minecraft:light_blue_stained_glass
fill 437 189 552 437 191 552 minecraft:gold_block
setblock 442 189 513 minecraft:light[level=14]
setblock 442 189 521 minecraft:light[level=14]
setblock 442 189 529 minecraft:light[level=14]
setblock 442 189 537 minecraft:light[level=14]
setblock 442 189 545 minecraft:light[level=14]
fill 443 189 510 443 191 510 minecraft:gold_block
fill 445 189 552 445 230 552 minecraft:blue_concrete
setblock 450 189 513 minecraft:light[level=14]
setblock 450 189 521 minecraft:light[level=14]
setblock 450 189 529 minecraft:light[level=14]
setblock 450 189 537 minecraft:light[level=14]
setblock 450 189 545 minecraft:light[level=14]
fill 453 189 552 453 191 552 minecraft:gold_block
setblock 458 189 513 minecraft:light[level=14]
setblock 458 189 521 minecraft:light[level=14]
setblock 458 189 529 minecraft:light[level=14]
setblock 458 189 537 minecraft:light[level=14]
fill 458 189 540 458 189 542 minecraft:waxed_cut_copper
setblock 458 189 545 minecraft:light[level=14]
fill 459 189 510 459 191 510 minecraft:gold_block
fill 459 189 539 461 189 539 minecraft:waxed_cut_copper
fill 459 189 543 461 189 543 minecraft:waxed_cut_copper
fill 462 189 540 462 189 542 minecraft:waxed_cut_copper
setblock 465 189 512 minecraft:sea_lantern
fill 465 189 513 465 226 513 minecraft:blue_concrete
setblock 465 189 514 minecraft:white_concrete
fill 465 189 515 465 204 518 minecraft:blue_concrete
fill 465 189 520 465 191 520 minecraft:gold_block
fill 465 189 535 465 233 535 minecraft:blue_concrete
fill 465 189 536 465 191 536 minecraft:gold_block
setblock 423 190 539 minecraft:white_concrete
setblock 423 190 545 minecraft:light_blue_stained_glass
fill 434 190 510 435 233 510 minecraft:blue_concrete
fill 444 190 510 444 205 510 minecraft:blue_concrete
setblock 445 190 510 minecraft:white_concrete
fill 446 190 510 447 231 510 minecraft:blue_concrete
fill 465 190 512 465 233 512 minecraft:blue_concrete
fill 465 190 514 465 192 514 minecraft:blue_concrete
fill 423 191 539 423 224 539 minecraft:blue_concrete
fill 423 191 545 423 231 545 minecraft:blue_concrete
setblock 434 191 552 minecraft:sea_lantern
fill 435 191 552 435 233 552 minecraft:blue_concrete
fill 438 191 546 438 191 548 minecraft:waxed_cut_copper
fill 439 191 546 440 191 546 minecraft:waxed_cut_copper
fill 439 191 548 440 191 548 minecraft:waxed_cut_copper
setblock 440 191 547 minecraft:waxed_cut_copper
setblock 445 191 510 minecraft:blue_concrete
setblock 456 191 552 minecraft:white_concrete
fill 423 192 518 423 197 518 minecraft:blue_concrete
fill 423 192 534 423 197 534 minecraft:blue_concrete
setblock 423 192 541 minecraft:light_blue_stained_glass
fill 423 192 550 423 195 550 minecraft:blue_concrete
fill 427 192 510 427 197 510 minecraft:blue_concrete
fill 434 192 552 434 203 552 minecraft:blue_concrete
setblock 436 192 510 minecraft:sea_lantern
fill 437 192 552 437 197 552 minecraft:blue_concrete
fill 443 192 510 443 197 510 minecraft:blue_concrete
setblock 445 192 510 minecraft:sea_lantern
fill 453 192 552 453 197 552 minecraft:blue_concrete
fill 456 192 552 456 209 552 minecraft:blue_concrete
fill 459 192 510 459 197 510 minecraft:blue_concrete
fill 465 192 520 465 197 520 minecraft:blue_concrete
fill 465 192 536 465 197 536 minecraft:blue_concrete
fill 423 193 541 423 204 541 minecraft:blue_concrete
fill 436 193 510 436 225 510 minecraft:blue_concrete
fill 445 193 510 445 213 510 minecraft:blue_concrete
setblock 465 193 514 minecraft:sea_lantern
fill 423 194 521 423 210 521 minecraft:blue_concrete
setblock 423 194 522 minecraft:sea_lantern
setblock 423 194 530 minecraft:light_blue_stained_glass
fill 465 194 514 465 207 514 minecraft:blue_concrete
setblock 465 194 551 minecraft:white_concrete
fill 423 195 522 423 233 522 minecraft:blue_concrete
fill 423 195 530 423 233 530 minecraft:blue_concrete
setblock 429 195 552 minecraft:light_blue_stained_glass
setblock 441 195 552 minecraft:white_concrete
setblock 453 195 510 minecraft:sea_lantern
fill 454 195 510 454 196 510 minecraft:blue_concrete
setblock 465 195 549 minecraft:sea_lantern
fill 465 195 551 465 233 551 minecraft:blue_concrete
setblock 423 196 550 minecraft:light_blue_stained_glass
setblock 425 196 552 minecraft:white_concrete
fill 429 196 552 429 198 552 minecraft:blue_concrete
fill 438 196 546 438 196 548 minecraft:waxed_cut_copper
fill 439 196 546 440 196 546 minecraft:waxed_cut_copper
fill 439 196 548 440 196 548 minecraft:waxed_cut_copper
setblock 440 196 547 minecraft:waxed_cut_copper
fill 441 196 552 441 233 552 minecraft:blue_concrete
setblock 442 196 552 minecraft:white_concrete
setblock 452 196 552 minecraft:white_concrete
fill 453 196 510 453 231 510 minecraft:blue_concrete
fill 465 196 521 465 233 521 minecraft:blue_concrete
setblock 465 196 522 minecraft:white_concrete
fill 465 196 523 465 225 523 minecraft:blue_concrete
setblock 465 196 538 minecraft:light_blue_stained_glass
fill 465 196 549 465 234 549 minecraft:blue_concrete
setblock 423 197 526 minecraft:sea_lantern
setblock 423 197 550 minecraft:blue_concrete
fill 425 197 552 425 218 552 minecraft:blue_concrete
setblock 426 197 513 minecraft:light[level=14]
setblock 426 197 521 minecraft:light[level=14]
setblock 426 197 529 minecraft:light[level=14]
setblock 426 197 537 minecraft:light[level=14]
setblock 426 197 545 minecraft:light[level=14]
setblock 434 197 513 minecraft:light[level=14]
setblock 434 197 521 minecraft:light[level=14]
setblock 434 197 529 minecraft:light[level=14]
setblock 434 197 537 minecraft:light[level=14]
setblock 434 197 545 minecraft:light[level=14]
setblock 438 197 510 minecraft:light_blue_stained_glass
fill 440 197 511 440 198 513 minecraft:waxed_copper_block
setblock 442 197 513 minecraft:light[level=14]
setblock 442 197 521 minecraft:light[level=14]
setblock 442 197 529 minecraft:light[level=14]
setblock 442 197 537 minecraft:light[level=14]
setblock 442 197 545 minecraft:light[level=14]
fill 442 197 552 442 213 552 minecraft:blue_concrete
setblock 448 197 510 minecraft:light_blue_stained_glass
setblock 450 197 513 minecraft:light[level=14]
setblock 450 197 521 minecraft:light[level=14]
setblock 450 197 529 minecraft:light[level=14]
setblock 450 197 537 minecraft:light[level=14]
setblock 450 197 545 minecraft:light[level=14]
fill 452 197 552 452 234 552 minecraft:blue_concrete
setblock 454 197 510 minecraft:white_concrete
setblock 458 197 513 minecraft:light[level=14]
setblock 458 197 521 minecraft:light[level=14]
setblock 458 197 529 minecraft:light[level=14]
setblock 458 197 537 minecraft:light[level=14]
fill 458 197 540 458 197 542 minecraft:waxed_cut_copper
setblock 458 197 545 minecraft:light[level=14]
fill 459 197 539 461 197 539 minecraft:waxed_cut_copper
fill 459 197 543 461 197 543 minecraft:waxed_cut_copper
fill 462 197 540 462 197 542 minecraft:waxed_cut_copper
fill 465 197 522 465 233 522 minecraft:blue_concrete
setblock 465 197 534 minecraft:white_concrete
fill 465 197 538 465 229 538 minecraft:blue_concrete
fill 423 198 518 423 200 518 minecraft:gold_block
fill 423 198 526 423 227 526 minecraft:blue_concrete
fill 423 198 531 423 218 531 minecraft:blue_concrete
setblock 423 198 532 minecraft:white_concrete
fill 423 198 533 423 231 533 minecraft:blue_concrete
fill 423 198 534 423 200 534 minecraft:gold_block
fill 423 198 550 423 200 550 minecraft:gold_block
fill 427 198 510 427 200 510 minecraft:gold_block
setblock 428 198 552 minecraft:white_concrete
fill 437 198 552 437 200 552 minecraft:gold_block
fill 438 198 510 438 214 510 minecraft:blue_concrete
fill 443 198 510 443 200 510 minecraft:gold_block
setblock 446 198 552 minecraft:sea_lantern
fill 447 198 552 448 215 552 minecraft:blue_concrete
fill 448 198 510 448 233 510 minecraft:blue_concrete
fill 453 198 552 453 200 552 minecraft:gold_block
fill 454 198 510 454 233 510 minecraft:blue_concrete
fill 459 198 510 459 200 510 minecraft:gold_block
fill 465 198 520 465 200 520 minecraft:gold_block
fill 465 198 534 465 224 534 minecraft:blue_concrete
fill 465 198 536 465 200 536 minecraft:gold_block
setblock 423 199 528 minecraft:white_concrete
fill 423 199 532 423 209 532 minecraft:blue_concrete
setblock 423 199 542 minecraft:sea_lantern
fill 428 199 552 428 233 552 minecraft:blue_concrete
setblock 429 199 552 minecraft:light_blue_stained_glass
setblock 431 199 510 minecraft:white_concrete
fill 446 199 552 446 233 552 minecraft:blue_concrete
fill 423 200 528 423 208 528 minecraft:blue_concrete
fill 423 200 542 423 230 542 minecraft:blue_concrete
setblock 429 200 552 minecraft:sea_lantern
fill 431 200 510 431 206 510 minecraft:blue_concrete
setblock 465 200 548 minecraft:white_concrete
fill 423 201 518 423 206 518 minecraft:blue_concrete
fill 423 201 534 423 206 534 minecraft:blue_concrete
fill 423 201 550 423 206 550 minecraft:blue_concrete
fill 427 201 510 427 206 510 minecraft:blue_concrete
fill 429 201 552 429 234 552 minecraft:blue_concrete
fill 437 201 552 437 206 552 minecraft:blue_concrete
fill 438 201 546 438 201 548 minecraft:waxed_cut_copper
fill 439 201 546 440 201 546 minecraft:waxed_cut_copper
fill 439 201 548 440 201 548 minecraft:waxed_cut_copper
setblock 440 201 547 minecraft:waxed_cut_copper
fill 443 201 510 443 206 510 minecraft:blue_concrete
fill 453 201 552 453 206 552 minecraft:blue_concrete
setblock 458 201 510 minecraft:white_concrete
fill 459 201 510 459 206 510 minecraft:blue_concrete
fill 465 201 520 465 206 520 minecraft:blue_concrete
fill 465 201 536 465 206 536 minecraft:blue_concrete
fill 465 201 548 465 218 548 minecraft:blue_concrete
setblock 452 202 510 minecraft:white_concrete
fill 458 202 510 458 233 510 minecraft:blue_concrete
setblock 423 203 525 minecraft:sea_lantern
setblock 450 203 552 minecraft:light_blue_stained_glass
fill 452 203 510 452 233 510 minecraft:blue_concrete
setblock 423 204 512 minecraft:white_concrete
fill 423 204 513 423 233 513 minecraft:blue_concrete
fill 423 204 525 423 231 525 minecraft:blue_concrete
setblock 434 204 552 minecraft:white_concrete
fill 450 204 552 450 233 552 minecraft:blue_concrete
fill 423 205 512 423 233 512 minecraft:blue_concrete
setblock 423 205 536 minecraft:sea_lantern
setblock 423 205 541 minecraft:white_concrete
setblock 426 205 513 minecraft:light[level=14]
setblock 426 205 521 minecraft:light[level=14]
setblock 426 205 529 minecraft:light[level=14]
setblock 426 205 537 minecraft:light[level=14]
setblock 426 205 545 minecraft:light[level=14]
setblock 434 205 513 minecraft:light[level=14]
setblock 434 205 521 minecraft:light[level=14]
setblock 434 205 529 minecraft:light[level=14]
setblock 434 205 537 minecraft:light[level=14]
setblock 434 205 545 minecraft:light[level=14]
fill 434 205 552 434 210 552 minecraft:blue_concrete
setblock 442 205 513 minecraft:light[level=14]
setblock 442 205 521 minecraft:light[level=14]
setblock 442 205 529 minecraft:light[level=14]
setblock 442 205 537 minecraft:light[level=14]
setblock 442 205 545 minecraft:light[level=14]
setblock 450 205 513 minecraft:light[level=14]
setblock 450 205 521 minecraft:light[level=14]
setblock 450 205 529 minecraft:light[level=14]
setblock 450 205 537 minecraft:light[level=14]
setblock 450 205 545 minecraft:light[level=14]
setblock 451 205 552 minecraft:sea_lantern
setblock 458 205 513 minecraft:light[level=14]
setblock 458 205 521 minecraft:light[level=14]
setblock 458 205 529 minecraft:light[level=14]
setblock 458 205 537 minecraft:light[level=14]
fill 458 205 540 458 205 542 minecraft:waxed_cut_copper
setblock 458 205 545 minecraft:light[level=14]
fill 459 205 539 461 205 539 minecraft:waxed_cut_copper
fill 459 205 543 461 205 543 minecraft:waxed_cut_copper
fill 462 205 540 462 205 542 minecraft:waxed_cut_copper
fill 465 205 515 465 230 516 minecraft:blue_concrete
setblock 465 205 517 minecraft:light_blue_stained_glass
fill 465 205 518 465 233 518 minecraft:blue_concrete
fill 423 206 536 423 233 536 minecraft:blue_concrete
fill 423 206 541 423 233 541 minecraft:blue_concrete
fill 438 206 546 438 206 548 minecraft:waxed_cut_copper
fill 439 206 546 440 206 546 minecraft:waxed_cut_copper
fill 439 206 548 440 206 548 minecraft:waxed_cut_copper
setblock 440 206 547 minecraft:waxed_cut_copper
setblock 444 206 510 minecraft:light_blue_stained_glass
fill 451 206 552 451 233 552 minecraft:blue_concrete
fill 465 206 517 465 209 517 minecraft:blue_concrete
fill 423 207 518 423 209 518 minecraft:gold_block
fill 423 207 534 423 209 534 minecraft:gold_block
setblock 423 207 543 minecraft:light_blue_stained_glass
fill 423 207 550 423 209 550 minecraft:gold_block
fill 426 207 552 426 221 552 minecraft:blue_concrete
fill 427 207 510 427 209 510 minecraft:gold_block
setblock 427 207 552 minecraft:sea_lantern
setblock 429 207 510 minecraft:light_blue_stained_glass
fill 431 207 510 431 208 510 minecraft:light_blue_stained_glass
fill 437 207 552 437 209 552 minecraft:gold_block
fill 443 207 510 443 209 510 minecraft:gold_block
fill 444 207 510 444 229 510 minecraft:blue_concrete
fill 453 207 552 453 209 552 minecraft:gold_block
fill 459 207 510 459 209 510 minecraft:gold_block
fill 465 207 520 465 209 520 minecraft:gold_block
fill 465 207 536 465 209 536 minecraft:gold_block
fill 423 208 543 423 231 543 minecraft:blue_concrete
fill 427 208 552 427 231 552 minecraft:blue_concrete
fill 429 208 510 429 233 510 minecraft:blue_concrete
setblock 455 208 510 minecraft:white_concrete
setblock 465 208 514 minecraft:light_blue_stained_glass
setblock 423 209 511 minecraft:white_concrete
setblock 423 209 528 minecraft:white_concrete
fill 431 209 510 431 233 510 minecraft:blue_concrete
fill 455 209 510 455 227 510 minecraft:blue_concrete
setblock 457 209 510 minecraft:white_concrete
fill 462 209 540 463 210 542 minecraft:waxed_copper_block
setblock 464 209 510 minecraft:white_concrete
fill 464 209 541 464 210 541 minecraft:waxed_copper_block
fill 465 209 510 465 234 510 minecraft:blue_concrete
fill 465 209 514 465 233 514 minecraft:blue_concrete
fill 423 210 511 423 233 511 minecraft:blue_concrete
setblock 423 210 514 minecraft:light_blue_stained_glass
fill 423 210 518 423 215 518 minecraft:blue_concrete
fill 423 210 528 423 233 528 minecraft:blue_concrete
setblock 423 210 532 minecraft:white_concrete
fill 423 210 534 423 215 534 minecraft:blue_concrete
fill 423 210 550 423 215 550 minecraft:blue_concrete
fill 427 210 510 427 215 510 minecraft:blue_concrete
fill 437 210 552 437 215 552 minecraft:blue_concrete
fill 440 210 510 440 232 510 minecraft:blue_concrete
setblock 441 210 510 minecraft:light_blue_stained_glass
fill 442 210 510 443 215 510 minecraft:blue_concrete
fill 453 210 552 453 215 552 minecraft:blue_concrete
setblock 456 210 552 minecraft:white_concrete
fill 457 210 510 457 229 510 minecraft:blue_concrete
setblock 458 210 541 minecraft:sea_lantern
fill 459 210 510 459 215 510 minecraft:blue_concrete
fill 464 210 510 464 233 510 minecraft:blue_concrete
setblock 465 210 517 minecraft:white_concrete
fill 465 210 520 465 215 520 minecraft:blue_concrete
fill 465 210 536 465 215 536 minecraft:blue_concrete
setblock 423 211 514 minecraft:sea_lantern
setblock 423 211 521 minecraft:sea_lantern
fill 423 211 532 423 217 532 minecraft:blue_concrete
setblock 434 211 552 minecraft:sea_lantern
fill 438 211 546 438 211 548 minecraft:waxed_cut_copper
fill 439 211 546 440 211 546 minecraft:waxed_cut_copper
fill 439 211 548 440 211 548 minecraft:waxed_cut_copper
setblock 440 211 547 minecraft:waxed_cut_copper
fill 441 211 510 441 231 510 minecraft:blue_concrete
fill 456 211 552 456 219 552 minecraft:blue_concrete
fill 465 211 517 465 217 517 minecraft:blue_concrete
fill 465 211 546 465 233 546 minecraft:blue_concrete
setblock 465 211 547 minecraft:light_blue_stained_glass
fill 423 212 514 423 233 514 minecraft:blue_concrete
fill 423 212 521 423 231 521 minecraft:blue_concrete
setblock 424 212 510 minecraft:sea_lantern
fill 434 212 552 434 230 552 minecraft:blue_concrete
fill 457 212 532 461 213 536 minecraft:polished_blackstone
fill 461 212 515 463 213 515 minecraft:waxed_copper_block
fill 462 212 534 463 212 534 minecraft:polished_blackstone
fill 465 212 547 465 233 547 minecraft:blue_concrete
fill 424 213 510 424 228 510 minecraft:blue_concrete
setblock 426 213 513 minecraft:light[level=14]
setblock 426 213 521 minecraft:light[level=14]
setblock 426 213 529 minecraft:light[level=14]
setblock 426 213 537 minecraft:light[level=14]
setblock 426 213 545 minecraft:light[level=14]
setblock 434 213 513 minecraft:light[level=14]
setblock 434 213 521 minecraft:light[level=14]
setblock 434 213 529 minecraft:light[level=14]
setblock 434 213 537 minecraft:light[level=14]
setblock 434 213 545 minecraft:light[level=14]
setblock 442 213 513 minecraft:light[level=14]
setblock 442 213 521 minecraft:light[level=14]
setblock 442 213 529 minecraft:light[level=14]
setblock 442 213 537 minecraft:light[level=14]
setblock 442 213 545 minecraft:light[level=14]
setblock 450 213 513 minecraft:light[level=14]
setblock 450 213 521 minecraft:light[level=14]
setblock 450 213 529 minecraft:light[level=14]
setblock 450 213 537 minecraft:light[level=14]
setblock 450 213 545 minecraft:light[level=14]
setblock 458 213 513 minecraft:light[level=14]
setblock 458 213 521 minecraft:light[level=14]
setblock 458 213 529 minecraft:light[level=14]
setblock 458 213 537 minecraft:light[level=14]
fill 458 213 540 458 213 542 minecraft:waxed_cut_copper
setblock 458 213 545 minecraft:light[level=14]
fill 459 213 539 461 213 539 minecraft:waxed_cut_copper
fill 459 213 543 461 213 543 minecraft:waxed_cut_copper
setblock 460 213 510 minecraft:white_concrete
fill 462 213 540 462 213 542 minecraft:waxed_cut_copper
setblock 462 213 552 minecraft:light_blue_stained_glass
setblock 423 214 519 minecraft:sea_lantern
setblock 442 214 552 minecraft:white_concrete
setblock 445 214 510 minecraft:light_blue_stained_glass
fill 460 214 510 460 235 510 minecraft:blue_concrete
fill 462 214 552 462 215 552 minecraft:blue_concrete
setblock 465 214 550 minecraft:light_blue_stained_glass
fill 423 215 519 423 233 519 minecraft:blue_concrete
setblock 423 215 547 minecraft:sea_lantern
setblock 423 215 548 minecraft:white_concrete
setblock 438 215 510 minecraft:sea_lantern
fill 442 215 552 442 231 552 minecraft:blue_concrete
fill 445 215 510 445 229 510 minecraft:blue_concrete
fill 459 215 534 459 222 534 minecraft:gold_block
fill 465 215 550 465 229 550 minecraft:blue_concrete
fill 423 216 518 423 218 518 minecraft:gold_block
setblock 423 216 523 minecraft:light_blue_stained_glass
fill 423 216 534 423 218 534 minecraft:gold_block
fill 423 216 547 423 221 548 minecraft:blue_concrete
fill 423 216 550 423 218 550 minecraft:gold_block
fill 427 216 510 427 218 510 minecraft:gold_block
fill 437 216 552 437 218 552 minecraft:gold_block
fill 438 216 510 438 221 510 minecraft:blue_concrete
fill 438 216 546 438 216 548 minecraft:waxed_cut_copper
fill 439 216 546 440 216 546 minecraft:waxed_cut_copper
fill 439 216 548 440 216 548 minecraft:waxed_cut_copper
setblock 440 216 547 minecraft:waxed_cut_copper
fill 442 216 510 442 217 510 minecraft:blue_concrete
fill 443 216 510 443 218 510 minecraft:gold_block
setblock 447 216 552 minecraft:light_blue_stained_glass
fill 448 216 552 448 233 552 minecraft:blue_concrete
fill 453 216 552 453 218 552 minecraft:gold_block
fill 457 216 533 458 221 535 minecraft:gold_block
fill 458 216 532 460 221 532 minecraft:gold_block
fill 458 216 536 460 218 536 minecraft:gold_block
fill 459 216 510 459 218 510 minecraft:gold_block
fill 459 216 533 461 218 533 minecraft:gold_block
fill 459 216 535 461 218 535 minecraft:gold_block
fill 460 216 534 461 218 534 minecraft:gold_block
setblock 462 216 552 minecraft:sea_lantern
setblock 463 216 510 minecraft:white_concrete
fill 465 216 520 465 218 520 minecraft:gold_block
fill 465 216 536 465 218 536 minecraft:gold_block
fill 423 217 523 423 233 523 minecraft:blue_concrete
fill 447 217 552 447 219 552 minecraft:blue_concrete
fill 456 217 533 456 220 535 minecraft:gold_block
fill 457 217 532 457 220 532 minecraft:gold_block
fill 457 217 536 457 220 536 minecraft:gold_block
fill 458 217 531 460 220 531 minecraft:gold_block
fill 458 217 537 460 218 537 minecraft:gold_block
fill 461 217 532 461 218 532 minecraft:gold_block
fill 461 217 536 461 220 536 minecraft:gold_block
fill 462 217 533 462 220 535 minecraft:gold_block
fill 462 217 552 462 226 552 minecraft:blue_concrete
fill 463 217 510 463 233 510 minecraft:blue_concrete
setblock 423 218 532 minecraft:light_blue_stained_glass
fill 439 218 548 439 219 550 minecraft:waxed_copper_block
setblock 442 218 510 minecraft:sea_lantern
setblock 465 218 517 minecraft:light_blue_stained_glass
fill 423 219 518 423 224 518 minecraft:blue_concrete
setblock 423 219 531 minecraft:light_blue_stained_glass
fill 423 219 532 423 234 532 minecraft:blue_concrete
fill 423 219 534 423 224 534 minecraft:blue_concrete
fill 423 219 550 423 224 550 minecraft:blue_concrete
setblock 425 219 552 minecraft:white_concrete
fill 427 219 510 427 224 510 minecraft:blue_concrete
fill 427 219 527 427 220 535 minecraft:waxed_cut_copper
fill 428 219 524 428 220 527 minecraft:waxed_cut_copper
fill 428 219 535 428 220 538 minecraft:waxed_cut_copper
fill 429 219 522 429 220 524 minecraft:waxed_cut_copper
fill 429 219 538 429 220 540 minecraft:waxed_cut_copper
fill 430 219 521 430 220 522 minecraft:waxed_cut_copper
fill 430 219 540 430 220 541 minecraft:waxed_cut_copper
fill 431 219 520 431 220 521 minecraft:waxed_cut_copper
fill 431 219 541 431 220 542 minecraft:waxed_cut_copper
fill 432 219 519 432 220 519 minecraft:waxed_cut_copper
fill 432 219 543 432 220 543 minecraft:waxed_cut_copper
fill 433 219 518 434 220 518 minecraft:waxed_cut_copper
fill 433 219 544 434 220 544 minecraft:waxed_cut_copper
fill 434 219 517 435 220 517 minecraft:waxed_cut_copper
fill 434 219 545 435 220 545 minecraft:waxed_cut_copper
fill 435 219 516 437 220 516 minecraft:waxed_cut_copper
fill 435 219 546 437 220 546 minecraft:waxed_cut_copper
setblock 437 219 510 minecraft:light_blue_stained_glass
fill 437 219 515 440 220 515 minecraft:waxed_cut_copper
fill 437 219 547 440 220 547 minecraft:waxed_cut_copper
fill 437 219 552 437 224 552 minecraft:blue_concrete
setblock 439 219 546 minecraft:sea_lantern
fill 440 219 514 448 220 514 minecraft:waxed_cut_copper
fill 440 219 548 448 220 548 minecraft:waxed_cut_copper
fill 442 219 510 443 224 510 minecraft:blue_concrete
fill 448 219 515 451 220 515 minecraft:waxed_cut_copper
fill 448 219 547 451 220 547 minecraft:waxed_cut_copper
fill 451 219 516 453 220 516 minecraft:waxed_cut_copper
fill 451 219 546 453 220 546 minecraft:waxed_cut_copper
fill 453 219 517 454 220 517 minecraft:waxed_cut_copper
fill 453 219 545 454 220 545 minecraft:waxed_cut_copper
fill 453 219 552 453 223 552 minecraft:blue_concrete
fill 454 219 518 455 220 518 minecraft:waxed_cut_copper
fill 454 219 544 455 220 544 minecraft:waxed_cut_copper
fill 456 219 519 456 220 519 minecraft:waxed_cut_copper
fill 456 219 543 456 220 543 minecraft:waxed_cut_copper
fill 457 219 520 457 220 521 minecraft:waxed_cut_copper
fill 457 219 541 457 220 542 minecraft:waxed_cut_copper
fill 458 219 521 458 220 522 minecraft:waxed_cut_copper
fill 458 219 536 459 220 537 minecraft:gold_block
fill 458 219 540 458 221 541 minecraft:waxed_cut_copper
fill 459 219 510 459 224 510 minecraft:blue_concrete
fill 459 219 522 459 220 524 minecraft:waxed_cut_copper
fill 459 219 533 460 221 533 minecraft:gold_block
fill 459 219 535 459 221 535 minecraft:gold_block
fill 459 219 538 459 220 540 minecraft:waxed_cut_copper
fill 459 219 541 461 226 542 minecraft:waxed_copper_block
fill 460 219 524 460 220 527 minecraft:waxed_cut_copper
fill 460 219 534 460 221 534 minecraft:gold_block
fill 460 219 535 460 220 538 minecraft:waxed_cut_copper
fill 460 219 540 461 226 540 minecraft:waxed_copper_block
fill 461 219 527 461 220 535 minecraft:waxed_cut_copper
fill 465 219 517 465 233 517 minecraft:blue_concrete
fill 465 219 520 465 224 520 minecraft:blue_concrete
fill 465 219 536 465 224 536 minecraft:blue_concrete
setblock 465 219 548 minecraft:white_concrete
fill 423 220 531 423 233 531 minecraft:blue_concrete
setblock 423 220 549 minecraft:light_blue_stained_glass
fill 425 220 552 425 233 552 minecraft:blue_concrete
fill 437 220 510 437 233 510 minecraft:blue_concrete
setblock 447 220 552 minecraft:sea_lantern
setblock 456 220 552 minecraft:white_concrete
setblock 465 220 548 minecraft:blue_concrete
fill 423 221 549 423 229 549 minecraft:blue_concrete
setblock 426 221 513 minecraft:light[level=14]
setblock 426 221 521 minecraft:light[level=14]
setblock 426 221 529 minecraft:light[level=14]
fill 426 221 530 426 221 531 minecraft:sea_lantern
setblock 426 221 537 minecraft:light[level=14]
setblock 426 221 545 minecraft:light[level=14]
fill 427 221 525 427 221 529 minecraft:sea_lantern
fill 428 221 523 428 221 524 minecraft:sea_lantern
fill 429 221 521 429 221 522 minecraft:sea_lantern
fill 430 221 520 430 221 521 minecraft:sea_lantern
setblock 431 221 519 minecraft:sea_lantern
setblock 432 221 518 minecraft:sea_lantern
fill 433 221 517 434 221 517 minecraft:sea_lantern
fill 433 221 548 433 222 550 minecraft:waxed_copper_block
setblock 434 221 513 minecraft:light[level=14]
fill 434 221 516 435 221 516 minecraft:sea_lantern
setblock 434 221 521 minecraft:light[level=14]
setblock 434 221 529 minecraft:light[level=14]
setblock 434 221 537 minecraft:light[level=14]
setblock 434 221 545 minecraft:light[level=14]
fill 436 221 515 437 221 515 minecraft:sea_lantern
fill 438 221 514 442 221 514 minecraft:sea_lantern
fill 438 221 546 438 221 548 minecraft:waxed_cut_copper
fill 439 221 546 440 221 546 minecraft:waxed_cut_copper
fill 439 221 547 439 226 547 minecraft:waxed_copper_block
fill 439 221 548 440 221 548 minecraft:waxed_cut_copper
setblock 440 221 547 minecraft:waxed_cut_copper
setblock 442 221 513 minecraft:light[level=14]
setblock 442 221 521 minecraft:light[level=14]
setblock 442 221 529 minecraft:light[level=14]
setblock 442 221 537 minecraft:light[level=14]
setblock 442 221 545 minecraft:light[level=14]
fill 443 221 513 445 221 513 minecraft:sea_lantern
fill 446 221 514 450 221 514 minecraft:sea_lantern
fill 447 221 552 447 233 552 minecraft:blue_concrete
setblock 450 221 513 minecraft:light[level=14]
setblock 450 221 521 minecraft:light[level=14]
setblock 450 221 529 minecraft:light[level=14]
setblock 450 221 537 minecraft:light[level=14]
setblock 450 221 545 minecraft:light[level=14]
fill 451 221 515 452 221 515 minecraft:sea_lantern
fill 453 221 516 454 221 516 minecraft:sea_lantern
fill 454 221 517 455 221 517 minecraft:sea_lantern
setblock 456 221 518 minecraft:sea_lantern
fill 456 221 552 456 233 552 minecraft:blue_concrete
setblock 457 221 519 minecraft:sea_lantern
setblock 458 221 513 minecraft:light[level=14]
fill 458 221 520 458 221 521 minecraft:sea_lantern
setblock 458 221 529 minecraft:light[level=14]
fill 458 221 536 460 221 536 minecraft:gold_block
setblock 458 221 537 minecraft:light[level=14]
setblock 458 221 542 minecraft:waxed_cut_copper
setblock 458 221 545 minecraft:light[level=14]
fill 459 221 521 459 221 522 minecraft:sea_lantern
fill 459 221 539 461 221 539 minecraft:waxed_cut_copper
fill 459 221 540 459 226 540 minecraft:waxed_copper_block
fill 459 221 543 461 221 543 minecraft:waxed_cut_copper
fill 460 221 523 460 221 524 minecraft:sea_lantern
setblock 460 221 535 minecraft:gold_block
fill 461 221 525 461 221 529 minecraft:sea_lantern
fill 461 221 533 461 221 535 minecraft:sea_lantern
fill 462 221 530 462 221 532 minecraft:sea_lantern
fill 462 221 540 462 221 542 minecraft:waxed_cut_copper
setblock 465 221 548 minecraft:white_concrete
setblock 423 222 544 minecraft:light_blue_stained_glass
fill 423 222 547 423 233 547 minecraft:blue_concrete
setblock 423 222 548 minecraft:white_concrete
setblock 426 222 552 minecraft:light_blue_stained_glass
setblock 433 222 510 minecraft:light_blue_stained_glass
setblock 438 222 510 minecraft:light_blue_stained_glass
fill 465 222 548 465 233 548 minecraft:blue_concrete
fill 423 223 544 423 230 544 minecraft:blue_concrete
fill 423 223 548 423 233 548 minecraft:blue_concrete
fill 426 223 552 426 233 552 minecraft:blue_concrete
fill 433 223 510 433 233 510 minecraft:blue_concrete
fill 438 223 510 438 233 510 minecraft:blue_concrete
setblock 453 224 552 minecraft:white_concrete
fill 423 225 518 423 226 518 minecraft:gold_block
fill 423 225 534 423 226 534 minecraft:gold_block
setblock 423 225 539 minecraft:white_concrete
fill 423 225 550 423 226 550 minecraft:gold_block
fill 427 225 510 427 226 510 minecraft:gold_block
fill 437 225 552 437 226 552 minecraft:gold_block
fill 442 225 510 442 230 510 minecraft:blue_concrete
fill 443 225 510 443 226 510 minecraft:gold_block
fill 453 225 552 453 226 552 minecraft:gold_block
fill 459 225 510 459 226 510 minecraft:gold_block
fill 465 225 520 465 226 520 minecraft:gold_block
setblock 465 225 534 minecraft:light_blue_stained_glass
fill 465 225 536 465 226 536 minecraft:gold_block
fill 423 226 539 423 233 539 minecraft:blue_concrete
setblock 436 226 510 minecraft:light_blue_stained_glass
setblock 450 226 510 minecraft:white_concrete
setblock 465 226 523 minecraft:white_concrete
setblock 465 226 528 minecraft:light_blue_stained_glass
fill 465 226 529 465 229 529 minecraft:blue_concrete
fill 465 226 534 465 233 534 minecraft:blue_concrete
fill 423 227 518 423 233 518 minecraft:blue_concrete
setblock 423 227 529 minecraft:sea_lantern
fill 423 227 534 423 233 534 minecraft:blue_concrete
fill 423 227 550 423 228 550 minecraft:blue_concrete
fill 427 227 510 427 233 510 minecraft:blue_concrete
fill 436 227 510 436 229 510 minecraft:blue_concrete
fill 437 227 552 437 233 552 minecraft:blue_concrete
fill 443 227 510 443 230 510 minecraft:blue_concrete
fill 450 227 510 450 233 510 minecraft:blue_concrete
fill 453 227 552 453 233 552 minecraft:blue_concrete
fill 457 227 552 458 229 552 minecraft:blue_concrete
fill 459 227 510 459 233 510 minecraft:blue_concrete
setblock 459 227 552 minecraft:white_concrete
fill 460 227 552 461 233 552 minecraft:blue_concrete
setblock 462 227 552 minecraft:light_blue_stained_glass
setblock 465 227 513 minecraft:light_blue_stained_glass
fill 465 227 520 465 233 520 minecraft:blue_concrete
fill 465 227 523 465 233 523 minecraft:blue_concrete
fill 465 227 528 465 233 528 minecraft:blue_concrete
fill 465 227 536 465 233 536 minecraft:blue_concrete
setblock 423 228 526 minecraft:light_blue_stained_glass
fill 423 228 529 423 233 529 minecraft:blue_concrete
setblock 423 228 546 minecraft:light_blue_stained_glass
setblock 455 228 510 minecraft:white_concrete
fill 459 228 552 459 233 552 minecraft:blue_concrete
fill 462 228 552 462 229 552 minecraft:blue_concrete
setblock 465 228 511 minecraft:white_concrete
fill 465 228 513 465 234 513 minecraft:blue_concrete
fill 465 228 525 465 233 525 minecraft:blue_concrete
setblock 465 228 526 minecraft:sea_lantern
fill 423 229 526 423 233 526 minecraft:blue_concrete
fill 423 229 546 423 233 546 minecraft:blue_concrete
setblock 423 229 550 minecraft:sea_lantern
setblock 424 229 510 minecraft:sea_lantern
setblock 426 229 513 minecraft:light[level=14]
setblock 426 229 521 minecraft:light[level=14]
setblock 426 229 529 minecraft:light[level=14]
setblock 426 229 537 minecraft:light[level=14]
setblock 426 229 545 minecraft:light[level=14]
setblock 434 229 513 minecraft:light[level=14]
setblock 434 229 521 minecraft:light[level=14]
setblock 434 229 529 minecraft:light[level=14]
setblock 434 229 537 minecraft:light[level=14]
setblock 434 229 545 minecraft:light[level=14]
setblock 442 229 513 minecraft:light[level=14]
setblock 442 229 521 minecraft:light[level=14]
setblock 442 229 529 minecraft:light[level=14]
setblock 442 229 537 minecraft:light[level=14]
setblock 442 229 545 minecraft:light[level=14]
setblock 450 229 513 minecraft:light[level=14]
setblock 450 229 521 minecraft:light[level=14]
setblock 450 229 529 minecraft:light[level=14]
setblock 450 229 537 minecraft:light[level=14]
setblock 450 229 545 minecraft:light[level=14]
fill 455 229 510 455 234 510 minecraft:blue_concrete
setblock 458 229 513 minecraft:light[level=14]
setblock 458 229 521 minecraft:light[level=14]
setblock 458 229 529 minecraft:light[level=14]
setblock 458 229 537 minecraft:light[level=14]
setblock 458 229 545 minecraft:light[level=14]
fill 465 229 511 465 230 511 minecraft:blue_concrete
fill 465 229 526 465 233 526 minecraft:blue_concrete
setblock 423 230 510 minecraft:black_concrete
setblock 423 230 540 minecraft:black_concrete
setblock 423 230 549 minecraft:white_concrete
fill 423 230 550 423 233 550 minecraft:blue_concrete
fill 424 230 510 424 233 510 minecraft:blue_concrete
fill 425 230 510 425 231 510 minecraft:black_concrete
setblock 430 230 510 minecraft:black_concrete
setblock 431 230 552 minecraft:black_concrete
setblock 436 230 510 minecraft:black_concrete
fill 444 230 510 445 230 510 minecraft:black_concrete
setblock 444 230 552 minecraft:black_concrete
setblock 457 230 510 minecraft:black_concrete
fill 457 230 552 457 233 552 minecraft:blue_concrete
setblock 458 230 552 minecraft:black_concrete
fill 462 230 552 462 231 552 minecraft:black_concrete
setblock 465 230 519 minecraft:black_concrete
setblock 465 230 529 minecraft:light_blue_stained_glass
setblock 465 230 538 minecraft:black_concrete
setblock 465 230 550 minecraft:black_concrete
fill 423 231 510 423 233 510 minecraft:blue_concrete
fill 423 231 515 423 231 516 minecraft:black_concrete
setblock 423 231 538 minecraft:black_concrete
fill 423 231 540 423 233 540 minecraft:blue_concrete
setblock 423 231 542 minecraft:black_concrete
fill 423 231 544 423 232 544 minecraft:black_concrete
fill 423 231 549 423 233 549 minecraft:blue_concrete
fill 430 231 510 430 233 510 minecraft:blue_concrete
setblock 431 231 552 minecraft:blue_concrete
fill 434 231 552 434 232 552 minecraft:black_concrete
fill 436 231 510 436 233 510 minecraft:blue_concrete
setblock 438 231 534 minecraft:waxed_copper_block
setblock 439 231 510 minecraft:black_concrete
fill 442 231 510 443 231 510 minecraft:black_concrete
fill 444 231 510 445 231 510 minecraft:blue_concrete
setblock 444 231 552 minecraft:blue_concrete
setblock 445 231 527 minecraft:waxed_copper_block
setblock 445 231 541 minecraft:waxed_copper_block
fill 445 231 552 445 232 552 minecraft:black_concrete
setblock 452 231 534 minecraft:waxed_copper_block
fill 457 231 510 457 233 510 minecraft:blue_concrete
setblock 458 231 552 minecraft:blue_concrete
setblock 465 231 511 minecraft:white_concrete
setblock 465 231 515 minecraft:black_concrete
fill 465 231 516 465 233 516 minecraft:blue_concrete
fill 465 231 519 465 233 519 minecraft:blue_concrete
fill 465 231 529 465 233 529 minecraft:blue_concrete
setblock 465 231 530 minecraft:black_concrete
fill 465 231 531 465 233 531 minecraft:blue_concrete
fill 465 231 532 465 232 532 minecraft:black_concrete
fill 465 231 538 465 233 538 minecraft:blue_concrete
setblock 465 231 544 minecraft:light_blue_stained_glass
fill 465 231 545 465 233 545 minecraft:blue_concrete
fill 465 231 550 465 233 550 minecraft:blue_concrete
fill 423 232 515 423 233 516 minecraft:blue_concrete
setblock 423 232 521 minecraft:black_concrete
setblock 423 232 525 minecraft:light_blue_stained_glass
setblock 423 232 533 minecraft:black_concrete
fill 423 232 538 423 233 538 minecraft:blue_concrete
fill 423 232 542 423 233 542 minecraft:blue_concrete
setblock 423 232 543 minecraft:black_concrete
setblock 423 232 545 minecraft:black_concrete
fill 423 232 551 423 232 552 minecraft:black_concrete
fill 425 232 510 425 233 510 minecraft:blue_concrete
setblock 427 232 552 minecraft:black_concrete
setblock 431 232 552 minecraft:black_concrete
setblock 432 232 510 minecraft:black_concrete
fill 437 232 531 437 234 537 minecraft:waxed_copper_block
fill 438 232 529 438 234 533 minecraft:waxed_copper_block
fill 438 232 534 442 232 534 minecraft:light_blue_stained_glass
fill 438 232 535 438 234 539 minecraft:waxed_copper_block
fill 439 232 510 439 233 510 minecraft:blue_concrete
fill 439 232 528 439 234 530 minecraft:waxed_copper_block
fill 439 232 531 443 232 533 minecraft:light_blue_stained_glass
fill 439 232 535 443 232 537 minecraft:light_blue_stained_glass
fill 439 232 538 439 234 540 minecraft:waxed_copper_block
fill 440 232 527 440 234 529 minecraft:waxed_copper_block
fill 440 232 530 450 233 530 minecraft:light_blue_stained_glass
fill 440 232 538 450 233 538 minecraft:light_blue_stained_glass
fill 440 232 539 440 234 541 minecraft:waxed_copper_block
setblock 440 232 552 minecraft:black_concrete
setblock 441 232 510 minecraft:black_concrete
fill 441 232 527 441 234 528 minecraft:waxed_copper_block
fill 441 232 529 449 233 529 minecraft:light_blue_stained_glass
fill 441 232 539 449 233 539 minecraft:light_blue_stained_glass
fill 441 232 540 441 234 541 minecraft:waxed_copper_block
fill 442 232 510 444 233 510 minecraft:blue_concrete
fill 442 232 526 444 234 527 minecraft:waxed_copper_block
fill 442 232 528 448 233 528 minecraft:light_blue_stained_glass
fill 442 232 540 448 233 540 minecraft:light_blue_stained_glass
fill 442 232 541 444 234 542 minecraft:waxed_copper_block
fill 442 232 552 444 232 552 minecraft:black_concrete
fill 444 232 531 444 232 532 minecraft:light_blue_stained_glass
fill 444 232 536 444 232 537 minecraft:light_blue_stained_glass
setblock 445 232 510 minecraft:black_concrete
fill 445 232 526 448 234 526 minecraft:waxed_copper_block
fill 445 232 527 445 233 527 minecraft:light_blue_stained_glass
fill 445 232 531 451 232 531 minecraft:light_blue_stained_glass
fill 445 232 537 451 232 537 minecraft:light_blue_stained_glass
fill 445 232 541 445 233 541 minecraft:light_blue_stained_glass
fill 445 232 542 448 234 542 minecraft:waxed_copper_block
fill 446 232 510 446 233 510 minecraft:blue_concrete
fill 446 232 527 450 234 527 minecraft:waxed_copper_block
fill 446 232 532 451 232 532 minecraft:light_blue_stained_glass
fill 446 232 536 451 232 536 minecraft:light_blue_stained_glass
fill 446 232 541 450 234 541 minecraft:waxed_copper_block
setblock 447 232 510 minecraft:black_concrete
fill 447 232 533 451 232 533 minecraft:light_blue_stained_glass
fill 447 232 535 451 232 535 minecraft:light_blue_stained_glass
fill 448 232 534 452 232 534 minecraft:light_blue_stained_glass
fill 449 232 528 451 234 528 minecraft:waxed_copper_block
fill 449 232 540 451 234 540 minecraft:waxed_copper_block
fill 450 232 529 452 234 529 minecraft:waxed_copper_block
fill 450 232 539 452 234 539 minecraft:waxed_copper_block
fill 451 232 530 452 234 530 minecraft:waxed_copper_block
fill 451 232 538 452 234 538 minecraft:waxed_copper_block
fill 452 232 531 453 234 533 minecraft:waxed_copper_block
fill 452 232 535 453 234 537 minecraft:waxed_copper_block
setblock 453 232 510 minecraft:black_concrete
fill 453 232 534 453 234 534 minecraft:waxed_copper_block
setblock 458 232 552 minecraft:black_concrete
fill 462 232 552 462 233 552 minecraft:blue_concrete
setblock 463 232 552 minecraft:black_concrete
setblock 465 232 511 minecraft:black_concrete
fill 465 232 515 465 233 515 minecraft:blue_concrete
fill 465 232 530 465 233 530 minecraft:blue_concrete
setblock 465 232 533 minecraft:black_concrete
fill 465 232 544 465 234 544 minecraft:blue_concrete
setblock 423 233 521 minecraft:blue_concrete
setblock 423 233 525 minecraft:blue_concrete
fill 423 233 533 423 234 533 minecraft:blue_concrete
setblock 423 233 535 minecraft:sea_lantern
fill 423 233 543 423 233 545 minecraft:blue_concrete
fill 423 233 551 423 233 552 minecraft:blue_concrete
fill 424 233 511 435 233 551 minecraft:black_concrete
setblock 424 233 552 minecraft:white_concrete
setblock 427 233 552 minecraft:blue_concrete
setblock 431 233 552 minecraft:blue_concrete
setblock 432 233 510 minecraft:blue_concrete
setblock 434 233 552 minecraft:blue_concrete
fill 436 233 511 436 233 533 minecraft:black_concrete
setblock 436 233 534 minecraft:waxed_copper_block
fill 436 233 535 436 233 551 minecraft:black_concrete
fill 437 233 511 437 233 529 minecraft:black_concrete
setblock 437 233 530 minecraft:waxed_copper_block
setblock 437 233 538 minecraft:waxed_copper_block
fill 437 233 539 437 233 551 minecraft:black_concrete
fill 438 233 511 438 233 528 minecraft:black_concrete
fill 438 233 534 441 233 534 minecraft:light_blue_stained_glass
fill 438 233 540 438 233 551 minecraft:black_concrete
fill 439 233 511 439 233 527 minecraft:black_concrete
fill 439 233 531 441 233 533 minecraft:light_blue_stained_glass
fill 439 233 535 441 233 537 minecraft:light_blue_stained_glass
fill 439 233 541 439 233 551 minecraft:black_concrete
setblock 440 233 510 minecraft:light_blue_stained_glass
fill 440 233 511 440 233 526 minecraft:black_concrete
fill 440 233 542 440 233 551 minecraft:black_concrete
setblock 440 233 552 minecraft:blue_concrete
setblock 441 233 510 minecraft:blue_concrete
fill 441 233 511 444 233 525 minecraft:black_concrete
setblock 441 233 526 minecraft:waxed_copper_block
setblock 441 233 542 minecraft:waxed_copper_block
fill 441 233 543 444 233 551 minecraft:black_concrete
fill 442 233 531 442 233 532 minecraft:light_blue_stained_glass
fill 442 233 533 442 233 535 minecraft:sea_lantern
fill 442 233 536 442 233 537 minecraft:light_blue_stained_glass
fill 442 233 552 445 233 552 minecraft:blue_concrete
setblock 443 233 531 minecraft:light_blue_stained_glass
fill 443 233 532 443 233 533 minecraft:sea_lantern
fill 443 233 535 443 233 536 minecraft:sea_lantern
setblock 443 233 537 minecraft:light_blue_stained_glass
fill 444 233 531 444 233 532 minecraft:sea_lantern
fill 444 233 536 444 233 537 minecraft:sea_lantern
setblock 445 233 510 minecraft:blue_concrete
fill 445 233 511 464 233 524 minecraft:black_concrete
setblock 445 233 525 minecraft:waxed_copper_block
fill 445 233 531 446 233 531 minecraft:sea_lantern
fill 445 233 537 446 233 537 minecraft:sea_lantern
setblock 445 233 543 minecraft:waxed_copper_block
fill 445 233 544 464 233 551 minecraft:black_concrete
fill 446 233 525 464 233 525 minecraft:black_concrete
fill 446 233 532 447 233 532 minecraft:sea_lantern
fill 446 233 536 447 233 536 minecraft:sea_lantern
fill 446 233 543 464 233 543 minecraft:black_concrete
fill 447 233 510 447 234 510 minecraft:blue_concrete
fill 447 233 531 451 233 531 minecraft:light_blue_stained_glass
fill 447 233 533 448 233 533 minecraft:sea_lantern
fill 447 233 535 448 233 535 minecraft:sea_lantern
fill 447 233 537 451 233 537 minecraft:light_blue_stained_glass
fill 448 233 532 451 233 532 minecraft:light_blue_stained_glass
setblock 448 233 534 minecraft:sea_lantern
fill 448 233 536 451 233 536 minecraft:light_blue_stained_glass
setblock 449 233 526 minecraft:waxed_copper_block
fill 449 233 533 451 233 535 minecraft:light_blue_stained_glass
setblock 449 233 542 minecraft:waxed_copper_block
fill 450 233 526 464 233 526 minecraft:black_concrete
fill 450 233 542 464 233 542 minecraft:black_concrete
fill 451 233 527 464 233 527 minecraft:black_concrete
fill 451 233 541 464 233 541 minecraft:black_concrete
fill 452 233 528 464 233 528 minecraft:black_concrete
setblock 452 233 534 minecraft:light_blue_stained_glass
fill 452 233 540 464 233 540 minecraft:black_concrete
setblock 453 233 510 minecraft:blue_concrete
fill 453 233 529 464 233 529 minecraft:black_concrete
setblock 453 233 530 minecraft:waxed_copper_block
setblock 453 233 538 minecraft:waxed_copper_block
fill 453 233 539 464 233 539 minecraft:black_concrete
fill 454 233 530 464 233 533 minecraft:black_concrete
setblock 454 233 534 minecraft:waxed_copper_block
fill 454 233 535 464 233 538 minecraft:black_concrete
fill 455 233 534 464 233 534 minecraft:black_concrete
setblock 458 233 552 minecraft:blue_concrete
setblock 463 233 552 minecraft:sea_lantern
setblock 465 233 511 minecraft:sea_lantern
fill 465 233 532 465 233 533 minecraft:blue_concrete
fill 423 234 510 423 234 523 minecraft:black_concrete
fill 423 234 525 423 235 531 minecraft:black_concrete
fill 423 234 534 423 234 548 minecraft:black_concrete
setblock 423 234 549 minecraft:white_concrete
fill 423 234 550 423 242 552 minecraft:black_concrete
fill 424 234 510 427 242 510 minecraft:black_concrete
fill 424 234 552 428 235 552 minecraft:black_concrete
setblock 428 234 510 minecraft:light_blue_stained_glass
fill 429 234 510 434 234 510 minecraft:black_concrete
fill 430 234 552 451 234 552 minecraft:black_concrete
setblock 435 234 510 minecraft:blue_concrete
fill 436 234 510 438 234 510 minecraft:black_concrete
fill 438 234 534 439 234 534 minecraft:waxed_copper_block
setblock 439 234 510 minecraft:sea_lantern
fill 439 234 531 439 234 533 minecraft:waxed_copper_block
fill 439 234 535 439 234 537 minecraft:waxed_copper_block
fill 440 234 510 440 236 510 minecraft:blue_concrete
fill 440 234 530 440 234 532 minecraft:waxed_copper_block
fill 440 234 536 440 234 538 minecraft:waxed_copper_block
fill 441 234 510 446 234 510 minecraft:black_concrete
fill 441 234 529 441 234 530 minecraft:waxed_copper_block
fill 441 234 538 441 234 539 minecraft:waxed_copper_block
fill 442 234 528 443 234 529 minecraft:waxed_copper_block
fill 442 234 539 443 234 540 minecraft:waxed_copper_block
fill 444 234 528 448 234 528 minecraft:waxed_copper_block
fill 444 234 540 448 234 540 minecraft:waxed_copper_block
fill 445 234 527 445 235 527 minecraft:waxed_copper_block
fill 445 234 541 445 235 541 minecraft:waxed_copper_block
fill 447 234 529 449 234 529 minecraft:waxed_copper_block
fill 447 234 539 449 234 539 minecraft:waxed_copper_block
fill 448 234 510 454 234 510 minecraft:black_concrete
fill 449 234 530 450 234 530 minecraft:waxed_copper_block
fill 449 234 538 450 234 538 minecraft:waxed_copper_block
fill 450 234 531 451 234 532 minecraft:waxed_copper_block
fill 450 234 536 451 234 537 minecraft:waxed_copper_block
fill 451 234 533 451 234 535 minecraft:waxed_copper_block
fill 452 234 534 452 235 534 minecraft:waxed_copper_block
fill 453 234 552 456 234 552 minecraft:black_concrete
fill 456 234 510 459 242 510 minecraft:black_concrete
setblock 457 234 552 minecraft:sea_lantern
fill 458 234 552 465 235 552 minecraft:black_concrete
fill 461 234 510 461 289 510 minecraft:black_concrete
fill 463 234 510 464 254 510 minecraft:black_concrete
fill 465 234 511 465 249 512 minecraft:black_concrete
fill 465 234 514 465 235 525 minecraft:black_concrete
setblock 465 234 526 minecraft:sea_lantern
fill 465 234 527 465 243 531 minecraft:black_concrete
setblock 465 234 532 minecraft:blue_concrete
fill 465 234 533 465 234 543 minecraft:black_concrete
fill 465 234 545 465 235 548 minecraft:black_concrete
fill 465 234 550 465 234 551 minecraft:black_concrete
fill 423 235 510 423 235 521 minecraft:black_concrete
fill 423 235 522 423 235 523 minecraft:blue_concrete
fill 423 235 524 423 307 524 minecraft:black_concrete
fill 423 235 532 423 248 533 minecraft:black_concrete
fill 423 235 534 423 236 534 minecraft:blue_concrete
fill 423 235 535 423 235 539 minecraft:black_concrete
setblock 423 235 540 minecraft:blue_concrete
fill 423 235 541 423 235 543 minecraft:black_concrete
setblock 423 235 544 minecraft:white_concrete
fill 423 235 545 423 243 549 minecraft:black_concrete
fill 428 235 510 431 241 510 minecraft:black_concrete
fill 429 235 552 437 236 552 minecraft:black_concrete
setblock 432 235 510 minecraft:blue_concrete
fill 433 235 510 436 235 510 minecraft:black_concrete
fill 437 235 510 437 236 510 minecraft:blue_concrete
fill 438 235 510 439 263 510 minecraft:black_concrete
setblock 438 235 534 minecraft:waxed_copper_block
fill 438 235 552 439 235 552 minecraft:blue_concrete
fill 440 235 552 441 300 552 minecraft:black_concrete
fill 441 235 510 441 240 510 minecraft:black_concrete
setblock 442 235 510 minecraft:blue_concrete
setblock 442 235 552 minecraft:sea_lantern
fill 443 235 510 447 235 510 minecraft:black_concrete
fill 443 235 552 455 235 552 minecraft:black_concrete
setblock 448 235 510 minecraft:blue_concrete
fill 449 235 510 449 307 510 minecraft:black_concrete
setblock 450 235 510 minecraft:blue_concrete
fill 451 235 510 455 235 510 minecraft:black_concrete
setblock 456 235 552 minecraft:blue_concrete
fill 457 235 552 457 244 552 minecraft:black_concrete
fill 462 235 510 462 263 510 minecraft:black_concrete
fill 465 235 510 465 307 510 minecraft:black_concrete
fill 465 235 513 465 272 513 minecraft:black_concrete
fill 465 235 526 465 245 526 minecraft:black_concrete
fill 465 235 532 465 307 532 minecraft:black_concrete
setblock 465 235 533 minecraft:white_concrete
fill 465 235 534 465 237 541 minecraft:black_concrete
fill 465 235 542 465 236 542 minecraft:blue_concrete
fill 465 235 543 465 235 544 minecraft:black_concrete
fill 465 235 549 465 241 550 minecraft:black_concrete
fill 465 235 551 465 236 551 minecraft:blue_concrete
fill 423 236 510 423 307 510 minecraft:black_concrete
setblock 423 236 511 minecraft:sea_lantern
fill 423 236 512 423 236 523 minecraft:black_concrete
fill 423 236 525 423 249 525 minecraft:black_concrete
setblock 423 236 526 minecraft:blue_concrete
fill 423 236 527 423 251 531 minecraft:black_concrete
fill 423 236 535 423 236 537 minecraft:black_concrete
setblock 423 236 538 minecraft:blue_concrete
fill 423 236 539 423 242 541 minecraft:black_concrete
setblock 423 236 542 minecraft:blue_concrete
fill 423 236 543 423 240 543 minecraft:black_concrete
setblock 423 236 544 minecraft:blue_concrete
setblock 424 236 552 minecraft:white_concrete
fill 425 236 552 428 242 552 minecraft:black_concrete
fill 432 236 510 435 244 510 minecraft:black_concrete
setblock 436 236 510 minecraft:blue_concrete
fill 438 236 552 438 307 552 minecraft:black_concrete
setblock 439 236 552 minecraft:blue_concrete
fill 442 236 510 445 242 510 minecraft:black_concrete
fill 442 236 552 449 253 552 minecraft:black_concrete
setblock 446 236 510 minecraft:blue_concrete
fill 447 236 510 448 259 510 minecraft:black_concrete
fill 450 236 510 450 282 510 minecraft:black_concrete
setblock 450 236 552 minecraft:blue_concrete
setblock 451 236 510 minecraft:blue_concrete
fill 451 236 552 452 255 552 minecraft:black_concrete
fill 452 236 510 453 262 510 minecraft:black_concrete
setblock 453 236 552 minecraft:blue_concrete
setblock 454 236 510 minecraft:blue_concrete
fill 454 236 552 456 275 552 minecraft:black_concrete
fill 455 236 510 455 291 510 minecraft:black_concrete
fill 458 236 552 462 246 552 minecraft:black_concrete
fill 460 236 510 460 248 510 minecraft:black_concrete
setblock 463 236 552 minecraft:blue_concrete
fill 464 236 552 465 243 552 minecraft:black_concrete
fill 465 236 514 465 237 521 minecraft:black_concrete
setblock 465 236 522 minecraft:blue_concrete
fill 465 236 523 465 239 523 minecraft:black_concrete
setblock 465 236 524 minecraft:blue_concrete
fill 465 236 525 465 307 525 minecraft:black_concrete
fill 465 236 533 465 307 533 minecraft:black_concrete
setblock 465 236 543 minecraft:blue_concrete
fill 465 236 544 465 307 544 minecraft:black_concrete
setblock 465 236 545 minecraft:blue_concrete
fill 465 236 546 465 265 546 minecraft:black_concrete
fill 465 236 547 465 236 548 minecraft:blue_concrete
fill 423 237 511 423 244 512 minecraft:black_concrete
setblock 423 237 513 minecraft:white_concrete
fill 423 237 514 423 242 523 minecraft:black_concrete
fill 423 237 526 423 307 526 minecraft:black_concrete
fill 423 237 534 423 242 534 minecraft:black_concrete
setblock 423 237 535 minecraft:light_blue_stained_glass
fill 423 237 536 423 237 538 minecraft:black_concrete
fill 423 237 542 423 251 542 minecraft:black_concrete
fill 423 237 544 423 251 544 minecraft:black_concrete
fill 424 237 552 424 253 552 minecraft:black_concrete
setblock 426 237 513 minecraft:light[level=14]
setblock 426 237 521 minecraft:light[level=14]
setblock 426 237 529 minecraft:light[level=14]
setblock 426 237 537 minecraft:light[level=14]
setblock 426 237 545 minecraft:light[level=14]
setblock 429 237 552 minecraft:sea_lantern
fill 430 237 552 437 239 552 minecraft:black_concrete
setblock 434 237 513 minecraft:light[level=14]
setblock 434 237 521 minecraft:light[level=14]
setblock 434 237 529 minecraft:light[level=14]
setblock 434 237 537 minecraft:light[level=14]
setblock 434 237 545 minecraft:light[level=14]
fill 436 237 510 437 261 510 minecraft:black_concrete
fill 439 237 552 439 246 552 minecraft:black_concrete
fill 440 237 510 440 252 510 minecraft:black_concrete
setblock 442 237 513 minecraft:light[level=14]
setblock 442 237 521 minecraft:light[level=14]
setblock 442 237 529 minecraft:light[level=14]
setblock 442 237 537 minecraft:light[level=14]
setblock 442 237 545 minecraft:light[level=14]
fill 446 237 510 446 243 510 minecraft:black_concrete
setblock 450 237 513 minecraft:light[level=14]
setblock 450 237 521 minecraft:light[level=14]
setblock 450 237 529 minecraft:light[level=14]
setblock 450 237 537 minecraft:light[level=14]
setblock 450 237 545 minecraft:light[level=14]
fill 450 237 552 450 307 552 minecraft:black_concrete
fill 451 237 510 451 265 510 minecraft:black_concrete
fill 453 237 552 453 242 552 minecraft:black_concrete
fill 454 237 510 454 255 510 minecraft:black_concrete
setblock 458 237 513 minecraft:light[level=14]
setblock 458 237 521 minecraft:light[level=14]
setblock 458 237 529 minecraft:light[level=14]
setblock 458 237 537 minecraft:light[level=14]
setblock 458 237 545 minecraft:light[level=14]
fill 460 237 545 462 273 547 minecraft:waxed_copper_block
fill 463 237 552 463 254 552 minecraft:black_concrete
fill 465 237 522 465 307 522 minecraft:black_concrete
fill 465 237 524 465 265 524 minecraft:black_concrete
fill 465 237 542 465 250 543 minecraft:black_concrete
fill 465 237 545 465 257 545 minecraft:black_concrete
fill 465 237 547 465 255 548 minecraft:black_concrete
fill 465 237 551 465 270 551 minecraft:black_concrete
fill 423 238 513 423 270 513 minecraft:black_concrete
fill 423 238 535 423 307 536 minecraft:black_concrete
setblock 423 238 537 minecraft:light_blue_stained_glass
fill 423 238 538 423 289 538 minecraft:black_concrete
fill 429 238 552 429 281 552 minecraft:black_concrete
setblock 465 238 514 minecraft:light_blue_stained_glass
fill 465 238 515 465 242 521 minecraft:black_concrete
fill 465 238 534 465 242 536 minecraft:black_concrete
setblock 465 238 537 minecraft:sea_lantern
fill 465 238 538 465 256 541 minecraft:black_concrete
fill 423 239 537 423 307 537 minecraft:black_concrete
fill 459 239 545 459 239 547 minecraft:waxed_cut_copper
fill 460 239 544 462 239 544 minecraft:waxed_cut_copper
fill 460 239 548 462 239 548 minecraft:waxed_cut_copper
fill 463 239 545 463 239 547 minecraft:waxed_cut_copper
fill 465 239 514 465 307 514 minecraft:black_concrete
fill 465 239 537 465 268 537 minecraft:black_concrete
fill 430 240 552 431 255 552 minecraft:black_concrete
setblock 432 240 552 minecraft:white_concrete
fill 433 240 552 437 242 552 minecraft:black_concrete
setblock 465 240 523 minecraft:white_concrete
setblock 423 241 543 minecraft:white_concrete
fill 432 241 552 432 287 552 minecraft:black_concrete
setblock 441 241 510 minecraft:light_blue_stained_glass
fill 465 241 523 465 304 523 minecraft:black_concrete
fill 423 242 543 423 279 543 minecraft:black_concrete
fill 428 242 510 430 244 510 minecraft:black_concrete
setblock 431 242 510 minecraft:white_concrete
fill 441 242 510 441 265 510 minecraft:black_concrete
fill 465 242 549 465 282 549 minecraft:black_concrete
setblock 465 242 550 minecraft:white_concrete
fill 423 243 514 423 273 517 minecraft:black_concrete
fill 423 243 518 423 245 518 minecraft:gold_block
fill 423 243 519 423 250 523 minecraft:black_concrete
fill 423 243 534 423 245 534 minecraft:gold_block
fill 423 243 539 423 247 540 minecraft:black_concrete
setblock 423 243 541 minecraft:light_blue_stained_glass
fill 423 243 550 423 245 550 minecraft:gold_block
fill 423 243 551 423 307 552 minecraft:black_concrete
fill 424 243 510 426 254 510 minecraft:black_concrete
fill 425 243 552 427 265 552 minecraft:black_concrete
fill 427 243 510 427 245 510 minecraft:gold_block
setblock 428 243 552 minecraft:light_blue_stained_glass
fill 431 243 510 431 246 510 minecraft:black_concrete
fill 433 243 552 436 264 552 minecraft:black_concrete
fill 437 243 552 437 245 552 minecraft:gold_block
fill 442 243 510 442 256 510 minecraft:black_concrete
fill 443 243 510 443 245 510 minecraft:gold_block
fill 444 243 510 445 280 510 minecraft:black_concrete
fill 453 243 552 453 245 552 minecraft:gold_block
fill 456 243 510 458 283 510 minecraft:black_concrete
fill 459 243 510 459 245 510 minecraft:gold_block
fill 465 243 515 465 253 519 minecraft:black_concrete
fill 465 243 520 465 245 520 minecraft:gold_block
fill 465 243 521 465 250 521 minecraft:black_concrete
fill 465 243 534 465 258 535 minecraft:black_concrete
fill 465 243 536 465 245 536 minecraft:gold_block
fill 465 243 550 465 307 550 minecraft:black_concrete
fill 423 244 541 423 253 541 minecraft:black_concrete
fill 423 244 545 423 307 546 minecraft:black_concrete
setblock 423 244 547 minecraft:white_concrete
fill 423 244 548 423 264 549 minecraft:black_concrete
fill 428 244 552 428 257 552 minecraft:black_concrete
setblock 446 244 510 minecraft:white_concrete
setblock 464 244 552 minecraft:white_concrete
setblock 465 244 527 minecraft:white_concrete
fill 465 244 528 465 273 531 minecraft:black_concrete
fill 465 244 552 465 307 552 minecraft:black_concrete
setblock 423 245 511 minecraft:light_blue_stained_glass
fill 423 245 512 423 275 512 minecraft:black_concrete
fill 423 245 547 423 272 547 minecraft:black_concrete
setblock 426 245 513 minecraft:light[level=14]
setblock 426 245 521 minecraft:light[level=14]
setblock 426 245 529 minecraft:light[level=14]
setblock 426 245 537 minecraft:light[level=14]
setblock 426 245 545 minecraft:light[level=14]
setblock 428 245 510 minecraft:white_concrete
fill 429 245 510 430 262 510 minecraft:black_concrete
fill 432 245 510 434 246 510 minecraft:black_concrete
setblock 434 245 513 minecraft:light[level=14]
setblock 434 245 521 minecraft:light[level=14]
setblock 434 245 529 minecraft:light[level=14]
setblock 434 245 537 minecraft:light[level=14]
setblock 434 245 545 minecraft:light[level=14]
setblock 435 245 510 minecraft:sea_lantern
setblock 442 245 513 minecraft:light[level=14]
setblock 442 245 521 minecraft:light[level=14]
setblock 442 245 529 minecraft:light[level=14]
setblock 442 245 537 minecraft:light[level=14]
setblock 442 245 545 minecraft:light[level=14]
fill 446 245 510 446 253 510 minecraft:black_concrete
setblock 450 245 513 minecraft:light[level=14]
setblock 450 245 521 minecraft:light[level=14]
setblock 450 245 529 minecraft:light[level=14]
setblock 450 245 537 minecraft:light[level=14]
setblock 450 245 545 minecraft:light[level=14]
setblock 457 245 552 minecraft:sea_lantern
setblock 458 245 513 minecraft:light[level=14]
setblock 458 245 521 minecraft:light[level=14]
setblock 458 245 529 minecraft:light[level=14]
setblock 458 245 537 minecraft:light[level=14]
setblock 458 245 545 minecraft:light[level=14]
fill 464 245 552 464 307 552 minecraft:black_concrete
fill 465 245 527 465 307 527 minecraft:black_concrete
fill 423 246 511 423 258 511 minecraft:black_concrete
fill 423 246 518 423 251 518 minecraft:black_concrete
fill 423 246 534 423 251 534 minecraft:black_concrete
fill 423 246 550 423 251 550 minecraft:black_concrete
fill 427 246 510 428 247 510 minecraft:black_concrete
fill 435 246 510 435 295 510 minecraft:black_concrete
fill 437 246 552 437 251 552 minecraft:black_concrete
fill 443 246 510 443 251 510 minecraft:black_concrete
fill 453 246 552 453 251 552 minecraft:black_concrete
fill 457 246 552 457 274 552 minecraft:black_concrete
fill 459 246 510 459 251 510 minecraft:black_concrete
fill 459 246 545 459 246 547 minecraft:waxed_cut_copper
fill 460 246 544 462 246 544 minecraft:waxed_cut_copper
fill 460 246 548 462 246 548 minecraft:waxed_cut_copper
fill 463 246 545 463 246 547 minecraft:waxed_cut_copper
fill 465 246 520 465 251 520 minecraft:black_concrete
setblock 465 246 526 minecraft:white_concrete
fill 465 246 536 465 251 536 minecraft:black_concrete
setblock 431 247 510 minecraft:light_blue_stained_glass
fill 432 247 510 432 255 510 minecraft:black_concrete
setblock 433 247 510 minecraft:white_concrete
fill 434 247 510 434 307 510 minecraft:black_concrete
setblock 439 247 552 minecraft:light_blue_stained_glass
fill 458 247 552 459 250 552 minecraft:black_concrete
setblock 460 247 552 minecraft:sea_lantern
fill 461 247 552 462 285 552 minecraft:black_concrete
fill 465 247 526 465 280 526 minecraft:black_concrete
setblock 423 248 539 minecraft:sea_lantern
fill 423 248 540 423 307 540 minecraft:black_concrete
fill 427 248 510 427 251 510 minecraft:black_concrete
schedule function dropper:buildpart/129_2 1t
