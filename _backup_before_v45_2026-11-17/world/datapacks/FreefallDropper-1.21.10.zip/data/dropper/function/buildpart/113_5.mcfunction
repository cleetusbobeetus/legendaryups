fill 236 150 492 236 153 492 minecraft:brown_terracotta
setblock 236 150 496 minecraft:bone_block
fill 236 150 497 236 153 497 minecraft:brown_terracotta
setblock 236 150 500 minecraft:brown_terracotta
setblock 236 150 501 minecraft:bone_block
fill 236 150 502 237 152 502 minecraft:brown_terracotta
setblock 237 150 469 minecraft:brown_terracotta
setblock 237 150 470 minecraft:bone_block
fill 237 150 471 237 153 471 minecraft:brown_terracotta
setblock 237 150 474 minecraft:brown_terracotta
setblock 237 150 475 minecraft:bone_block
fill 237 150 476 237 153 476 minecraft:brown_terracotta
fill 237 150 478 237 150 479 minecraft:brown_terracotta
setblock 237 150 485 minecraft:bone_block
fill 237 150 486 237 153 486 minecraft:brown_terracotta
setblock 237 150 490 minecraft:bone_block
fill 237 150 491 237 153 491 minecraft:brown_terracotta
setblock 237 150 495 minecraft:bone_block
fill 237 150 496 237 153 496 minecraft:brown_terracotta
setblock 237 150 500 minecraft:bone_block
fill 237 150 501 237 153 501 minecraft:brown_terracotta
fill 237 150 503 238 150 503 minecraft:brown_terracotta
setblock 238 150 473 minecraft:brown_terracotta
setblock 238 150 474 minecraft:bone_block
fill 238 150 487 238 151 487 minecraft:brown_terracotta
setblock 238 150 489 minecraft:bone_block
fill 238 150 490 238 153 490 minecraft:brown_terracotta
setblock 238 150 493 minecraft:brown_terracotta
setblock 238 150 494 minecraft:bone_block
fill 238 150 495 238 153 495 minecraft:brown_terracotta
setblock 238 150 499 minecraft:bone_block
fill 238 150 500 238 153 500 minecraft:brown_terracotta
setblock 238 150 504 minecraft:bone_block
setblock 239 150 493 minecraft:bone_block
fill 239 150 494 239 153 494 minecraft:brown_terracotta
setblock 239 150 498 minecraft:bone_block
setblock 239 150 503 minecraft:bone_block
fill 239 150 504 239 153 504 minecraft:brown_terracotta
fill 255 150 464 255 152 464 minecraft:brown_terracotta
setblock 256 150 465 minecraft:brown_terracotta
fill 256 150 498 258 151 498 minecraft:bone_block
fill 256 150 500 258 151 500 minecraft:bone_block
setblock 257 150 465 minecraft:bone_block
fill 257 150 499 257 151 499 minecraft:bone_block
setblock 258 150 464 minecraft:bone_block
fill 258 150 465 258 152 466 minecraft:brown_terracotta
setblock 258 150 504 minecraft:bone_block
fill 259 150 464 259 153 464 minecraft:brown_terracotta
fill 259 150 504 262 150 504 minecraft:brown_terracotta
setblock 261 150 466 minecraft:bone_block
setblock 262 150 465 minecraft:bone_block
fill 262 150 466 262 151 466 minecraft:brown_terracotta
setblock 263 150 464 minecraft:bone_block
fill 263 150 465 263 153 465 minecraft:brown_terracotta
setblock 263 150 504 minecraft:bone_block
fill 264 150 464 264 153 464 minecraft:brown_terracotta
fill 264 150 497 268 151 501 minecraft:soul_soil
fill 264 150 504 264 153 504 minecraft:brown_terracotta
fill 266 150 502 266 150 503 minecraft:soul_soil
setblock 268 150 464 minecraft:bone_block
setblock 273 150 464 minecraft:bone_block
setblock 273 150 504 minecraft:bone_block
fill 274 150 464 274 153 464 minecraft:brown_terracotta
fill 274 150 504 274 153 504 minecraft:brown_terracotta
fill 275 150 468 275 150 471 minecraft:brown_terracotta
setblock 275 150 472 minecraft:bone_block
fill 275 150 473 275 152 474 minecraft:brown_terracotta
fill 275 150 490 275 150 491 minecraft:brown_terracotta
setblock 275 150 492 minecraft:bone_block
fill 275 150 493 275 153 493 minecraft:brown_terracotta
fill 275 150 495 275 150 496 minecraft:brown_terracotta
setblock 275 150 497 minecraft:bone_block
fill 275 150 498 275 153 498 minecraft:brown_terracotta
setblock 275 150 501 minecraft:brown_terracotta
setblock 275 150 502 minecraft:bone_block
fill 275 150 503 275 153 503 minecraft:brown_terracotta
setblock 276 150 466 minecraft:bone_block
fill 276 150 467 276 153 467 minecraft:brown_terracotta
setblock 276 150 471 minecraft:bone_block
fill 276 150 472 276 153 472 minecraft:brown_terracotta
setblock 276 150 475 minecraft:brown_terracotta
setblock 276 150 476 minecraft:bone_block
fill 276 150 477 276 152 478 minecraft:brown_terracotta
fill 276 150 487 276 150 490 minecraft:brown_terracotta
setblock 276 150 491 minecraft:bone_block
fill 276 150 492 276 153 492 minecraft:brown_terracotta
setblock 276 150 496 minecraft:bone_block
fill 276 150 497 276 153 497 minecraft:brown_terracotta
setblock 276 150 501 minecraft:bone_block
fill 276 150 502 276 153 502 minecraft:brown_terracotta
fill 236 151 466 236 154 466 minecraft:brown_terracotta
setblock 236 151 470 minecraft:bone_block
fill 236 151 471 236 154 471 minecraft:brown_terracotta
setblock 236 151 474 minecraft:brown_terracotta
setblock 236 151 475 minecraft:bone_block
fill 236 151 476 236 154 476 minecraft:brown_terracotta
setblock 236 151 479 minecraft:brown_terracotta
setblock 236 151 480 minecraft:bone_block
fill 236 151 481 237 153 481 minecraft:brown_terracotta
setblock 236 151 485 minecraft:bone_block
fill 236 151 486 236 154 486 minecraft:brown_terracotta
setblock 236 151 490 minecraft:bone_block
fill 236 151 491 236 154 491 minecraft:brown_terracotta
setblock 236 151 495 minecraft:bone_block
fill 236 151 496 236 154 496 minecraft:brown_terracotta
setblock 236 151 500 minecraft:bone_block
fill 236 151 501 236 154 501 minecraft:brown_terracotta
setblock 237 151 464 minecraft:bone_block
setblock 237 151 469 minecraft:bone_block
fill 237 151 470 237 154 470 minecraft:brown_terracotta
setblock 237 151 474 minecraft:bone_block
fill 237 151 475 238 153 475 minecraft:brown_terracotta
setblock 237 151 478 minecraft:brown_terracotta
setblock 237 151 479 minecraft:bone_block
fill 237 151 480 237 154 480 minecraft:brown_terracotta
fill 237 151 482 237 151 483 minecraft:brown_terracotta
setblock 237 151 484 minecraft:bone_block
fill 237 151 485 237 154 485 minecraft:brown_terracotta
setblock 237 151 488 minecraft:brown_terracotta
setblock 237 151 489 minecraft:bone_block
fill 237 151 490 237 154 490 minecraft:brown_terracotta
setblock 237 151 494 minecraft:bone_block
fill 237 151 495 237 154 495 minecraft:brown_terracotta
setblock 237 151 498 minecraft:brown_terracotta
setblock 237 151 499 minecraft:bone_block
fill 237 151 500 237 154 500 minecraft:brown_terracotta
setblock 237 151 503 minecraft:brown_terracotta
setblock 237 151 504 minecraft:bone_block
fill 238 151 464 239 152 464 minecraft:brown_terracotta
setblock 238 151 472 minecraft:brown_terracotta
setblock 238 151 473 minecraft:bone_block
fill 238 151 474 238 154 474 minecraft:brown_terracotta
fill 238 151 476 238 151 477 minecraft:brown_terracotta
setblock 238 151 478 minecraft:bone_block
setblock 238 151 488 minecraft:bone_block
fill 238 151 489 238 154 489 minecraft:brown_terracotta
setblock 238 151 493 minecraft:bone_block
fill 238 151 494 238 154 494 minecraft:brown_terracotta
setblock 238 151 498 minecraft:bone_block
fill 238 151 499 239 153 499 minecraft:brown_terracotta
fill 238 151 501 238 152 501 minecraft:brown_terracotta
setblock 238 151 503 minecraft:bone_block
fill 238 151 504 238 154 504 minecraft:brown_terracotta
setblock 239 151 492 minecraft:bone_block
fill 239 151 493 239 154 493 minecraft:brown_terracotta
setblock 239 151 497 minecraft:bone_block
fill 239 151 498 239 154 498 minecraft:brown_terracotta
fill 239 151 503 240 153 503 minecraft:brown_terracotta
setblock 242 151 504 minecraft:bone_block
fill 254 151 464 254 153 464 minecraft:brown_terracotta
setblock 256 151 465 minecraft:bone_block
setblock 257 151 464 minecraft:bone_block
fill 257 151 465 257 153 466 minecraft:brown_terracotta
setblock 257 151 504 minecraft:bone_block
fill 258 151 464 258 154 464 minecraft:brown_terracotta
fill 258 151 499 259 152 499 minecraft:bone_block
fill 258 151 504 261 151 504 minecraft:brown_terracotta
setblock 260 151 466 minecraft:bone_block
setblock 261 151 465 minecraft:bone_block
fill 261 151 466 261 152 466 minecraft:brown_terracotta
setblock 262 151 464 minecraft:bone_block
fill 262 151 465 262 154 465 minecraft:brown_terracotta
setblock 262 151 504 minecraft:bone_block
fill 263 151 464 263 154 464 minecraft:brown_terracotta
fill 263 151 504 263 154 504 minecraft:brown_terracotta
fill 265 151 504 266 151 504 minecraft:brown_terracotta
setblock 267 151 464 minecraft:bone_block
setblock 268 151 464 minecraft:brown_terracotta
setblock 271 151 504 minecraft:brown_terracotta
setblock 272 151 464 minecraft:bone_block
setblock 272 151 504 minecraft:bone_block
fill 273 151 464 273 154 464 minecraft:brown_terracotta
fill 273 151 504 273 154 504 minecraft:brown_terracotta
fill 274 151 493 274 151 496 minecraft:brown_terracotta
setblock 274 151 497 minecraft:bone_block
fill 274 151 498 274 152 500 minecraft:brown_terracotta
fill 274 151 503 274 154 503 minecraft:brown_terracotta
fill 275 151 468 275 151 470 minecraft:brown_terracotta
setblock 275 151 471 minecraft:bone_block
fill 275 151 472 275 154 472 minecraft:brown_terracotta
setblock 275 151 475 minecraft:brown_terracotta
setblock 275 151 476 minecraft:bone_block
setblock 275 151 490 minecraft:brown_terracotta
setblock 275 151 491 minecraft:bone_block
fill 275 151 492 275 154 492 minecraft:brown_terracotta
setblock 275 151 495 minecraft:brown_terracotta
setblock 275 151 496 minecraft:bone_block
fill 275 151 497 275 154 497 minecraft:brown_terracotta
fill 275 151 499 275 151 500 minecraft:brown_terracotta
setblock 275 151 501 minecraft:bone_block
fill 275 151 502 275 154 502 minecraft:brown_terracotta
setblock 276 151 465 minecraft:bone_block
fill 276 151 466 276 154 466 minecraft:brown_terracotta
setblock 276 151 470 minecraft:bone_block
fill 276 151 471 276 154 471 minecraft:brown_terracotta
setblock 276 151 475 minecraft:bone_block
fill 276 151 476 276 154 476 minecraft:brown_terracotta
setblock 276 151 479 minecraft:brown_terracotta
setblock 276 151 480 minecraft:bone_block
fill 276 151 486 276 151 489 minecraft:brown_terracotta
setblock 276 151 490 minecraft:bone_block
fill 276 151 491 276 154 491 minecraft:brown_terracotta
setblock 276 151 495 minecraft:bone_block
fill 276 151 496 276 154 496 minecraft:brown_terracotta
setblock 276 151 499 minecraft:brown_terracotta
setblock 276 151 500 minecraft:bone_block
fill 276 151 501 276 154 501 minecraft:brown_terracotta
setblock 236 152 464 minecraft:bone_block
fill 236 152 465 236 153 465 minecraft:brown_terracotta
setblock 236 152 469 minecraft:bone_block
fill 236 152 470 236 155 470 minecraft:brown_terracotta
setblock 236 152 473 minecraft:brown_terracotta
setblock 236 152 474 minecraft:bone_block
fill 236 152 475 236 155 475 minecraft:brown_terracotta
setblock 236 152 479 minecraft:bone_block
fill 236 152 480 236 155 480 minecraft:brown_terracotta
setblock 236 152 484 minecraft:bone_block
fill 236 152 485 236 155 485 minecraft:brown_terracotta
setblock 236 152 489 minecraft:bone_block
fill 236 152 490 236 155 490 minecraft:brown_terracotta
setblock 236 152 494 minecraft:bone_block
fill 236 152 495 236 155 495 minecraft:brown_terracotta
setblock 236 152 499 minecraft:bone_block
fill 236 152 500 236 155 500 minecraft:brown_terracotta
setblock 236 152 503 minecraft:brown_terracotta
setblock 236 152 504 minecraft:bone_block
fill 237 152 464 237 154 464 minecraft:brown_terracotta
fill 237 152 469 237 153 469 minecraft:brown_terracotta
setblock 237 152 473 minecraft:bone_block
fill 237 152 474 237 155 474 minecraft:brown_terracotta
setblock 237 152 478 minecraft:bone_block
fill 237 152 479 238 154 479 minecraft:brown_terracotta
setblock 237 152 482 minecraft:brown_terracotta
setblock 237 152 483 minecraft:bone_block
fill 237 152 484 237 155 484 minecraft:brown_terracotta
setblock 237 152 488 minecraft:bone_block
fill 237 152 489 237 155 489 minecraft:brown_terracotta
setblock 237 152 493 minecraft:bone_block
fill 237 152 494 237 155 494 minecraft:brown_terracotta
setblock 237 152 498 minecraft:bone_block
fill 237 152 499 237 155 499 minecraft:brown_terracotta
setblock 237 152 503 minecraft:bone_block
fill 237 152 504 237 155 504 minecraft:brown_terracotta
setblock 238 152 472 minecraft:bone_block
fill 238 152 473 238 155 473 minecraft:brown_terracotta
setblock 238 152 476 minecraft:brown_terracotta
setblock 238 152 477 minecraft:bone_block
fill 238 152 478 238 155 478 minecraft:brown_terracotta
fill 238 152 480 238 152 481 minecraft:brown_terracotta
setblock 238 152 486 minecraft:brown_terracotta
setblock 238 152 487 minecraft:bone_block
fill 238 152 488 238 154 488 minecraft:brown_terracotta
setblock 238 152 492 minecraft:bone_block
fill 238 152 493 238 155 493 minecraft:brown_terracotta
setblock 238 152 497 minecraft:bone_block
fill 238 152 498 238 155 498 minecraft:brown_terracotta
setblock 238 152 502 minecraft:bone_block
fill 238 152 503 238 155 503 minecraft:brown_terracotta
setblock 239 152 491 minecraft:bone_block
fill 239 152 492 239 154 492 minecraft:brown_terracotta
setblock 239 152 496 minecraft:bone_block
fill 239 152 497 239 155 497 minecraft:brown_terracotta
setblock 241 152 504 minecraft:bone_block
fill 242 152 504 242 153 504 minecraft:brown_terracotta
setblock 255 152 465 minecraft:bone_block
setblock 255 152 504 minecraft:brown_terracotta
setblock 256 152 464 minecraft:bone_block
fill 256 152 465 256 155 465 minecraft:brown_terracotta
setblock 256 152 504 minecraft:bone_block
fill 257 152 464 257 155 464 minecraft:brown_terracotta
fill 257 152 504 260 152 504 minecraft:brown_terracotta
fill 258 152 503 261 152 503 minecraft:brown_terracotta
setblock 259 152 466 minecraft:bone_block
setblock 260 152 465 minecraft:bone_block
fill 260 152 466 260 153 466 minecraft:brown_terracotta
fill 260 152 499 260 153 499 minecraft:bone_block
setblock 261 152 464 minecraft:bone_block
fill 261 152 465 261 155 465 minecraft:brown_terracotta
setblock 261 152 504 minecraft:bone_block
fill 262 152 464 262 155 464 minecraft:brown_terracotta
fill 262 152 498 264 155 498 minecraft:bone_block
fill 262 152 500 264 155 500 minecraft:bone_block
setblock 262 152 503 minecraft:bone_block
fill 262 152 504 262 155 504 minecraft:brown_terracotta
fill 263 152 499 263 155 499 minecraft:bone_block
setblock 265 152 504 minecraft:brown_terracotta
setblock 266 152 464 minecraft:bone_block
setblock 266 152 504 minecraft:bone_block
fill 267 152 464 267 153 464 minecraft:brown_terracotta
fill 267 152 504 270 152 504 minecraft:brown_terracotta
setblock 271 152 464 minecraft:bone_block
setblock 271 152 504 minecraft:bone_block
fill 272 152 464 272 155 464 minecraft:brown_terracotta
setblock 272 152 503 minecraft:bone_block
fill 272 152 504 272 155 504 minecraft:brown_terracotta
fill 273 152 503 273 155 503 minecraft:brown_terracotta
fill 274 152 493 274 152 495 minecraft:brown_terracotta
setblock 274 152 496 minecraft:bone_block
fill 274 152 497 274 155 497 minecraft:brown_terracotta
setblock 274 152 501 minecraft:bone_block
fill 274 152 502 274 155 502 minecraft:brown_terracotta
fill 275 152 468 275 152 469 minecraft:brown_terracotta
setblock 275 152 470 minecraft:bone_block
fill 275 152 471 275 154 471 minecraft:brown_terracotta
setblock 275 152 475 minecraft:bone_block
fill 275 152 476 275 154 477 minecraft:brown_terracotta
setblock 275 152 490 minecraft:bone_block
fill 275 152 491 275 155 491 minecraft:brown_terracotta
setblock 275 152 495 minecraft:bone_block
fill 275 152 496 275 155 496 minecraft:brown_terracotta
setblock 275 152 499 minecraft:brown_terracotta
setblock 275 152 500 minecraft:bone_block
fill 275 152 501 275 155 501 minecraft:brown_terracotta
setblock 276 152 464 minecraft:bone_block
fill 276 152 465 276 155 465 minecraft:brown_terracotta
setblock 276 152 469 minecraft:bone_block
fill 276 152 470 276 155 470 minecraft:brown_terracotta
setblock 276 152 474 minecraft:bone_block
fill 276 152 475 276 155 475 minecraft:brown_terracotta
setblock 276 152 479 minecraft:bone_block
fill 276 152 480 276 152 483 minecraft:brown_terracotta
setblock 276 152 484 minecraft:bone_block
fill 276 152 485 276 152 488 minecraft:brown_terracotta
setblock 276 152 489 minecraft:bone_block
fill 276 152 490 276 155 490 minecraft:brown_terracotta
setblock 276 152 494 minecraft:bone_block
fill 276 152 495 276 155 495 minecraft:brown_terracotta
setblock 276 152 499 minecraft:bone_block
fill 276 152 500 276 155 500 minecraft:brown_terracotta
setblock 276 152 504 minecraft:bone_block
fill 236 153 464 236 154 464 minecraft:brown_terracotta
setblock 236 153 468 minecraft:bone_block
fill 236 153 469 236 156 469 minecraft:brown_terracotta
setblock 236 153 473 minecraft:bone_block
fill 236 153 474 236 156 474 minecraft:brown_terracotta
setblock 236 153 477 minecraft:brown_terracotta
setblock 236 153 478 minecraft:bone_block
fill 236 153 479 236 156 479 minecraft:brown_terracotta
setblock 236 153 482 minecraft:brown_terracotta
setblock 236 153 483 minecraft:bone_block
fill 236 153 484 236 156 484 minecraft:brown_terracotta
setblock 236 153 488 minecraft:bone_block
fill 236 153 489 236 156 489 minecraft:brown_terracotta
setblock 236 153 493 minecraft:bone_block
fill 236 153 494 236 156 494 minecraft:brown_terracotta
setblock 236 153 498 minecraft:bone_block
fill 236 153 499 236 156 499 minecraft:brown_terracotta
setblock 236 153 502 minecraft:brown_terracotta
setblock 236 153 503 minecraft:bone_block
fill 236 153 504 236 156 504 minecraft:brown_terracotta
setblock 237 153 472 minecraft:bone_block
fill 237 153 473 237 156 473 minecraft:brown_terracotta
setblock 237 153 477 minecraft:bone_block
fill 237 153 478 237 156 478 minecraft:brown_terracotta
setblock 237 153 482 minecraft:bone_block
fill 237 153 483 238 155 483 minecraft:brown_terracotta
setblock 237 153 487 minecraft:bone_block
fill 237 153 488 237 156 488 minecraft:brown_terracotta
setblock 237 153 492 minecraft:bone_block
fill 237 153 493 237 156 493 minecraft:brown_terracotta
setblock 237 153 497 minecraft:bone_block
fill 237 153 498 237 156 498 minecraft:brown_terracotta
setblock 237 153 502 minecraft:bone_block
fill 237 153 503 237 156 503 minecraft:brown_terracotta
setblock 238 153 464 minecraft:brown_terracotta
setblock 238 153 472 minecraft:brown_terracotta
setblock 238 153 476 minecraft:bone_block
fill 238 153 477 239 154 477 minecraft:brown_terracotta
setblock 238 153 480 minecraft:brown_terracotta
setblock 238 153 481 minecraft:bone_block
fill 238 153 482 238 156 482 minecraft:brown_terracotta
fill 238 153 484 238 153 485 minecraft:brown_terracotta
setblock 238 153 486 minecraft:bone_block
fill 238 153 487 238 154 487 minecraft:brown_terracotta
setblock 238 153 491 minecraft:bone_block
fill 238 153 492 238 156 492 minecraft:brown_terracotta
setblock 238 153 496 minecraft:bone_block
fill 238 153 497 238 156 497 minecraft:brown_terracotta
setblock 238 153 501 minecraft:bone_block
fill 238 153 502 239 153 502 minecraft:brown_terracotta
fill 239 153 476 239 154 476 minecraft:brown_terracotta
setblock 239 153 491 minecraft:brown_terracotta
setblock 239 153 495 minecraft:bone_block
fill 239 153 496 239 155 496 minecraft:brown_terracotta
setblock 240 153 504 minecraft:bone_block
fill 241 153 504 241 155 504 minecraft:brown_terracotta
fill 253 153 464 253 154 464 minecraft:brown_terracotta
setblock 254 153 504 minecraft:brown_terracotta
setblock 255 153 464 minecraft:bone_block
fill 255 153 465 255 156 465 minecraft:brown_terracotta
setblock 255 153 504 minecraft:bone_block
fill 256 153 464 256 156 464 minecraft:brown_terracotta
fill 256 153 504 259 153 504 minecraft:brown_terracotta
fill 257 153 503 260 153 503 minecraft:brown_terracotta
setblock 258 153 465 minecraft:brown_terracotta
setblock 258 153 466 minecraft:bone_block
setblock 259 153 465 minecraft:bone_block
fill 259 153 466 259 154 466 minecraft:brown_terracotta
setblock 260 153 464 minecraft:bone_block
fill 260 153 465 260 156 465 minecraft:brown_terracotta
setblock 260 153 504 minecraft:bone_block
fill 261 153 464 261 156 464 minecraft:brown_terracotta
fill 261 153 499 262 154 499 minecraft:bone_block
setblock 261 153 503 minecraft:bone_block
fill 261 153 504 261 156 504 minecraft:brown_terracotta
fill 262 153 503 263 155 503 minecraft:brown_terracotta
fill 264 153 499 265 154 499 minecraft:bone_block
setblock 265 153 464 minecraft:bone_block
setblock 265 153 504 minecraft:bone_block
fill 266 153 464 266 154 464 minecraft:brown_terracotta
fill 266 153 504 269 153 504 minecraft:brown_terracotta
setblock 270 153 504 minecraft:bone_block
fill 271 153 464 271 156 464 minecraft:brown_terracotta
setblock 271 153 503 minecraft:bone_block
fill 271 153 504 271 156 504 minecraft:brown_terracotta
fill 272 153 503 272 156 503 minecraft:brown_terracotta
fill 273 153 502 273 156 502 minecraft:brown_terracotta
fill 274 153 493 274 153 494 minecraft:brown_terracotta
setblock 274 153 495 minecraft:bone_block
fill 274 153 496 274 156 496 minecraft:brown_terracotta
fill 274 153 498 274 153 499 minecraft:brown_terracotta
setblock 274 153 500 minecraft:bone_block
fill 274 153 501 274 156 501 minecraft:brown_terracotta
setblock 275 153 464 minecraft:bone_block
setblock 275 153 469 minecraft:bone_block
fill 275 153 470 275 154 470 minecraft:brown_terracotta
setblock 275 153 473 minecraft:brown_terracotta
setblock 275 153 474 minecraft:bone_block
fill 275 153 475 275 156 475 minecraft:brown_terracotta
setblock 275 153 478 minecraft:brown_terracotta
setblock 275 153 479 minecraft:bone_block
setblock 275 153 489 minecraft:bone_block
fill 275 153 490 275 156 490 minecraft:brown_terracotta
setblock 275 153 494 minecraft:bone_block
fill 275 153 495 275 156 495 minecraft:brown_terracotta
setblock 275 153 499 minecraft:bone_block
fill 275 153 500 275 156 500 minecraft:brown_terracotta
setblock 275 153 504 minecraft:bone_block
fill 276 153 464 276 156 464 minecraft:brown_terracotta
setblock 276 153 468 minecraft:bone_block
fill 276 153 469 276 156 469 minecraft:brown_terracotta
setblock 276 153 473 minecraft:bone_block
fill 276 153 474 276 156 474 minecraft:brown_terracotta
setblock 276 153 477 minecraft:brown_terracotta
setblock 276 153 478 minecraft:bone_block
fill 276 153 479 276 153 482 minecraft:brown_terracotta
setblock 276 153 483 minecraft:bone_block
fill 276 153 484 276 153 487 minecraft:brown_terracotta
setblock 276 153 488 minecraft:bone_block
fill 276 153 489 276 156 489 minecraft:brown_terracotta
setblock 276 153 493 minecraft:bone_block
fill 276 153 494 276 156 494 minecraft:brown_terracotta
setblock 276 153 498 minecraft:bone_block
fill 276 153 499 276 156 499 minecraft:brown_terracotta
setblock 276 153 503 minecraft:bone_block
fill 276 153 504 276 156 504 minecraft:brown_terracotta
setblock 236 154 467 minecraft:bone_block
fill 236 154 468 236 155 468 minecraft:brown_terracotta
setblock 236 154 472 minecraft:bone_block
fill 236 154 473 236 157 473 minecraft:brown_terracotta
setblock 236 154 477 minecraft:bone_block
fill 236 154 478 236 157 478 minecraft:brown_terracotta
setblock 236 154 481 minecraft:brown_terracotta
setblock 236 154 482 minecraft:bone_block
fill 236 154 483 236 157 483 minecraft:brown_terracotta
setblock 236 154 487 minecraft:bone_block
fill 236 154 488 236 157 488 minecraft:brown_terracotta
setblock 236 154 492 minecraft:bone_block
fill 236 154 493 236 157 493 minecraft:brown_terracotta
setblock 236 154 497 minecraft:bone_block
fill 236 154 498 236 157 498 minecraft:brown_terracotta
setblock 236 154 502 minecraft:bone_block
fill 236 154 503 236 157 503 minecraft:brown_terracotta
setblock 237 154 471 minecraft:bone_block
fill 237 154 472 237 156 472 minecraft:brown_terracotta
setblock 237 154 475 minecraft:brown_terracotta
setblock 237 154 476 minecraft:bone_block
fill 237 154 477 237 157 477 minecraft:brown_terracotta
setblock 237 154 481 minecraft:bone_block
fill 237 154 482 237 157 482 minecraft:brown_terracotta
setblock 237 154 486 minecraft:bone_block
fill 237 154 487 237 157 487 minecraft:brown_terracotta
setblock 237 154 491 minecraft:bone_block
fill 237 154 492 237 157 492 minecraft:brown_terracotta
setblock 237 154 496 minecraft:bone_block
fill 237 154 497 237 157 497 minecraft:brown_terracotta
setblock 237 154 501 minecraft:bone_block
fill 237 154 502 238 155 502 minecraft:brown_terracotta
setblock 238 154 475 minecraft:bone_block
fill 238 154 476 238 157 476 minecraft:brown_terracotta
setblock 238 154 480 minecraft:bone_block
fill 238 154 481 238 157 481 minecraft:brown_terracotta
setblock 238 154 484 minecraft:brown_terracotta
setblock 238 154 485 minecraft:bone_block
setblock 238 154 486 minecraft:brown_terracotta
setblock 238 154 490 minecraft:bone_block
fill 238 154 491 238 155 491 minecraft:brown_terracotta
setblock 238 154 495 minecraft:bone_block
fill 238 154 496 238 157 496 minecraft:brown_terracotta
setblock 238 154 499 minecraft:brown_terracotta
setblock 238 154 500 minecraft:bone_block
fill 238 154 501 238 157 501 minecraft:brown_terracotta
setblock 239 154 478 minecraft:brown_terracotta
setblock 239 154 494 minecraft:bone_block
fill 239 154 495 239 155 495 minecraft:brown_terracotta
setblock 239 154 499 minecraft:bone_block
setblock 239 154 503 minecraft:brown_terracotta
setblock 239 154 504 minecraft:bone_block
setblock 240 154 503 minecraft:bone_block
fill 240 154 504 240 157 504 minecraft:brown_terracotta
setblock 253 154 504 minecraft:brown_terracotta
setblock 254 154 464 minecraft:bone_block
fill 254 154 465 254 157 465 minecraft:brown_terracotta
setblock 254 154 504 minecraft:bone_block
fill 255 154 464 255 157 464 minecraft:brown_terracotta
setblock 255 154 503 minecraft:bone_block
fill 255 154 504 258 154 504 minecraft:brown_terracotta
fill 256 154 503 259 154 503 minecraft:brown_terracotta
setblock 257 154 465 minecraft:brown_terracotta
setblock 257 154 466 minecraft:bone_block
setblock 258 154 465 minecraft:bone_block
setblock 258 154 466 minecraft:brown_terracotta
setblock 259 154 464 minecraft:bone_block
fill 259 154 465 259 157 465 minecraft:brown_terracotta
setblock 259 154 504 minecraft:bone_block
fill 260 154 464 260 157 464 minecraft:brown_terracotta
setblock 260 154 503 minecraft:bone_block
fill 260 154 504 260 157 504 minecraft:brown_terracotta
fill 261 154 503 261 157 503 minecraft:brown_terracotta
setblock 264 154 464 minecraft:bone_block
setblock 264 154 504 minecraft:bone_block
fill 265 154 464 265 155 464 minecraft:brown_terracotta
fill 265 154 504 268 154 504 minecraft:brown_terracotta
fill 266 154 499 266 155 499 minecraft:bone_block
setblock 269 154 504 minecraft:bone_block
setblock 270 154 503 minecraft:bone_block
fill 270 154 504 270 157 504 minecraft:brown_terracotta
fill 271 154 503 271 157 503 minecraft:brown_terracotta
fill 272 154 502 272 157 502 minecraft:brown_terracotta
fill 273 154 497 273 154 499 minecraft:brown_terracotta
setblock 273 154 500 minecraft:bone_block
setblock 274 154 464 minecraft:bone_block
setblock 274 154 493 minecraft:brown_terracotta
setblock 274 154 494 minecraft:bone_block
fill 274 154 495 274 157 495 minecraft:brown_terracotta
setblock 274 154 498 minecraft:brown_terracotta
setblock 274 154 499 minecraft:bone_block
fill 274 154 500 274 157 500 minecraft:brown_terracotta
setblock 274 154 504 minecraft:bone_block
fill 275 154 464 275 157 464 minecraft:brown_terracotta
setblock 275 154 473 minecraft:bone_block
fill 275 154 474 275 156 474 minecraft:brown_terracotta
setblock 275 154 478 minecraft:bone_block
fill 275 154 479 276 155 480 minecraft:brown_terracotta
setblock 275 154 489 minecraft:brown_terracotta
setblock 275 154 493 minecraft:bone_block
fill 275 154 494 275 157 494 minecraft:brown_terracotta
setblock 275 154 498 minecraft:bone_block
fill 275 154 499 275 157 499 minecraft:brown_terracotta
setblock 275 154 503 minecraft:bone_block
fill 275 154 504 275 157 504 minecraft:brown_terracotta
setblock 276 154 467 minecraft:bone_block
fill 276 154 468 276 156 468 minecraft:brown_terracotta
setblock 276 154 472 minecraft:bone_block
fill 276 154 473 276 157 473 minecraft:brown_terracotta
setblock 276 154 477 minecraft:bone_block
fill 276 154 478 276 157 478 minecraft:brown_terracotta
setblock 276 154 481 minecraft:brown_terracotta
setblock 276 154 482 minecraft:bone_block
fill 276 154 483 276 154 486 minecraft:brown_terracotta
setblock 276 154 487 minecraft:bone_block
fill 276 154 488 276 157 488 minecraft:brown_terracotta
setblock 276 154 492 minecraft:bone_block
fill 276 154 493 276 157 493 minecraft:brown_terracotta
setblock 276 154 497 minecraft:bone_block
fill 276 154 498 276 157 498 minecraft:brown_terracotta
setblock 276 154 502 minecraft:bone_block
fill 276 154 503 276 157 503 minecraft:brown_terracotta
setblock 236 155 471 minecraft:bone_block
fill 236 155 472 236 158 472 minecraft:brown_terracotta
setblock 236 155 476 minecraft:bone_block
fill 236 155 477 236 158 477 minecraft:brown_terracotta
setblock 236 155 481 minecraft:bone_block
fill 236 155 482 236 158 482 minecraft:brown_terracotta
setblock 236 155 486 minecraft:bone_block
fill 236 155 487 236 158 487 minecraft:brown_terracotta
setblock 236 155 491 minecraft:bone_block
fill 236 155 492 236 158 492 minecraft:brown_terracotta
setblock 236 155 496 minecraft:bone_block
fill 236 155 497 236 158 497 minecraft:brown_terracotta
setblock 236 155 501 minecraft:bone_block
fill 236 155 502 236 158 502 minecraft:brown_terracotta
setblock 237 155 471 minecraft:brown_terracotta
setblock 237 155 475 minecraft:bone_block
fill 237 155 476 237 158 476 minecraft:brown_terracotta
setblock 237 155 479 minecraft:brown_terracotta
setblock 237 155 480 minecraft:bone_block
fill 237 155 481 237 158 481 minecraft:brown_terracotta
setblock 237 155 485 minecraft:bone_block
fill 237 155 486 237 158 486 minecraft:brown_terracotta
setblock 237 155 490 minecraft:bone_block
fill 237 155 491 237 158 491 minecraft:brown_terracotta
setblock 237 155 495 minecraft:bone_block
fill 237 155 496 237 158 496 minecraft:brown_terracotta
setblock 237 155 500 minecraft:bone_block
fill 237 155 501 237 158 501 minecraft:brown_terracotta
setblock 238 155 466 minecraft:light[level=12]
setblock 238 155 474 minecraft:bone_block
fill 238 155 475 238 156 475 minecraft:brown_terracotta
fill 238 155 477 238 156 477 minecraft:brown_terracotta
setblock 238 155 479 minecraft:bone_block
fill 238 155 480 238 158 480 minecraft:brown_terracotta
setblock 238 155 484 minecraft:bone_block
setblock 238 155 489 minecraft:bone_block
setblock 238 155 490 minecraft:brown_terracotta
setblock 238 155 494 minecraft:bone_block
fill 238 155 495 238 157 495 minecraft:brown_terracotta
setblock 238 155 499 minecraft:bone_block
fill 238 155 500 238 157 500 minecraft:brown_terracotta
setblock 238 155 504 minecraft:bone_block
setblock 239 155 498 minecraft:bone_block
setblock 239 155 503 minecraft:bone_block
fill 239 155 504 239 158 504 minecraft:brown_terracotta
setblock 246 155 466 minecraft:light[level=12]
setblock 246 155 474 minecraft:light[level=12]
setblock 246 155 482 minecraft:light[level=12]
setblock 246 155 490 minecraft:light[level=12]
setblock 246 155 498 minecraft:light[level=12]
setblock 252 155 464 minecraft:brown_terracotta
setblock 253 155 464 minecraft:bone_block
setblock 253 155 504 minecraft:bone_block
fill 254 155 464 254 158 464 minecraft:brown_terracotta
setblock 254 155 466 minecraft:light[level=12]
setblock 254 155 474 minecraft:light[level=12]
setblock 254 155 482 minecraft:light[level=12]
setblock 254 155 490 minecraft:light[level=12]
setblock 254 155 498 minecraft:light[level=12]
fill 254 155 504 257 155 504 minecraft:brown_terracotta
fill 255 155 503 258 155 503 minecraft:brown_terracotta
setblock 257 155 465 minecraft:bone_block
setblock 258 155 464 minecraft:bone_block
fill 258 155 465 258 158 465 minecraft:brown_terracotta
setblock 258 155 504 minecraft:bone_block
fill 259 155 464 259 158 464 minecraft:brown_terracotta
setblock 259 155 503 minecraft:bone_block
fill 259 155 504 259 158 504 minecraft:brown_terracotta
fill 260 155 503 260 158 503 minecraft:brown_terracotta
setblock 262 155 466 minecraft:light[level=12]
setblock 262 155 474 minecraft:light[level=12]
setblock 262 155 482 minecraft:light[level=12]
setblock 262 155 490 minecraft:light[level=12]
setblock 263 155 464 minecraft:bone_block
setblock 263 155 504 minecraft:bone_block
fill 264 155 464 264 156 464 minecraft:brown_terracotta
fill 264 155 504 267 155 504 minecraft:brown_terracotta
fill 267 155 499 268 156 499 minecraft:bone_block
setblock 268 155 504 minecraft:bone_block
setblock 269 155 503 minecraft:bone_block
fill 269 155 504 269 158 504 minecraft:brown_terracotta
setblock 270 155 466 minecraft:light[level=12]
setblock 270 155 474 minecraft:light[level=12]
setblock 270 155 482 minecraft:light[level=12]
setblock 270 155 490 minecraft:light[level=12]
setblock 270 155 498 minecraft:light[level=12]
fill 270 155 503 270 158 503 minecraft:brown_terracotta
fill 271 155 502 271 158 502 minecraft:brown_terracotta
setblock 273 155 464 minecraft:bone_block
fill 273 155 497 273 155 498 minecraft:brown_terracotta
setblock 273 155 499 minecraft:bone_block
fill 273 155 500 273 157 501 minecraft:brown_terracotta
setblock 273 155 504 minecraft:bone_block
fill 274 155 464 274 158 464 minecraft:brown_terracotta
setblock 274 155 493 minecraft:bone_block
fill 274 155 494 274 157 494 minecraft:brown_terracotta
setblock 274 155 498 minecraft:bone_block
fill 274 155 499 274 158 499 minecraft:brown_terracotta
setblock 274 155 503 minecraft:bone_block
fill 274 155 504 274 158 504 minecraft:brown_terracotta
setblock 275 155 472 minecraft:bone_block
fill 275 155 473 275 156 473 minecraft:brown_terracotta
setblock 275 155 476 minecraft:brown_terracotta
setblock 275 155 477 minecraft:bone_block
fill 275 155 478 275 158 478 minecraft:brown_terracotta
setblock 275 155 481 minecraft:brown_terracotta
setblock 275 155 492 minecraft:bone_block
fill 275 155 493 275 158 493 minecraft:brown_terracotta
setblock 275 155 497 minecraft:bone_block
fill 275 155 498 275 158 498 minecraft:brown_terracotta
setblock 275 155 502 minecraft:bone_block
fill 275 155 503 275 158 503 minecraft:brown_terracotta
setblock 276 155 466 minecraft:bone_block
fill 276 155 467 276 156 467 minecraft:brown_terracotta
setblock 276 155 471 minecraft:bone_block
fill 276 155 472 276 157 472 minecraft:brown_terracotta
setblock 276 155 476 minecraft:bone_block
fill 276 155 477 276 158 477 minecraft:brown_terracotta
setblock 276 155 481 minecraft:bone_block
fill 276 155 482 276 155 485 minecraft:brown_terracotta
setblock 276 155 486 minecraft:bone_block
fill 276 155 487 276 158 487 minecraft:brown_terracotta
setblock 276 155 491 minecraft:bone_block
fill 276 155 492 276 158 492 minecraft:brown_terracotta
setblock 276 155 496 minecraft:bone_block
fill 276 155 497 276 158 497 minecraft:brown_terracotta
setblock 276 155 501 minecraft:bone_block
fill 276 155 502 276 158 502 minecraft:brown_terracotta
setblock 236 156 470 minecraft:bone_block
fill 236 156 471 236 157 471 minecraft:brown_terracotta
setblock 236 156 475 minecraft:bone_block
fill 236 156 476 236 159 476 minecraft:brown_terracotta
setblock 236 156 480 minecraft:bone_block
fill 236 156 481 236 159 481 minecraft:brown_terracotta
setblock 236 156 485 minecraft:bone_block
fill 236 156 486 236 159 486 minecraft:brown_terracotta
setblock 236 156 490 minecraft:bone_block
fill 236 156 491 236 159 491 minecraft:brown_terracotta
setblock 236 156 495 minecraft:bone_block
fill 236 156 496 236 159 496 minecraft:brown_terracotta
setblock 236 156 500 minecraft:bone_block
fill 236 156 501 236 159 501 minecraft:brown_terracotta
setblock 237 156 474 minecraft:bone_block
fill 237 156 475 237 159 475 minecraft:brown_terracotta
setblock 237 156 479 minecraft:bone_block
fill 237 156 480 237 159 480 minecraft:brown_terracotta
setblock 237 156 483 minecraft:brown_terracotta
setblock 237 156 484 minecraft:bone_block
fill 237 156 485 237 159 485 minecraft:brown_terracotta
setblock 237 156 489 minecraft:bone_block
fill 237 156 490 237 158 490 minecraft:brown_terracotta
setblock 237 156 494 minecraft:bone_block
fill 237 156 495 237 159 495 minecraft:brown_terracotta
setblock 237 156 499 minecraft:bone_block
fill 237 156 500 237 159 500 minecraft:brown_terracotta
fill 237 156 502 237 157 502 minecraft:brown_terracotta
setblock 237 156 504 minecraft:bone_block
setblock 238 156 474 minecraft:brown_terracotta
setblock 238 156 478 minecraft:bone_block
fill 238 156 479 238 159 479 minecraft:brown_terracotta
setblock 238 156 483 minecraft:bone_block
setblock 238 156 484 minecraft:brown_terracotta
setblock 238 156 493 minecraft:bone_block
setblock 238 156 494 minecraft:brown_terracotta
setblock 238 156 498 minecraft:bone_block
fill 238 156 499 238 157 499 minecraft:brown_terracotta
setblock 238 156 503 minecraft:bone_block
fill 238 156 504 238 159 504 minecraft:brown_terracotta
setblock 239 156 503 minecraft:brown_terracotta
setblock 252 156 464 minecraft:bone_block
setblock 252 156 504 minecraft:bone_block
fill 253 156 464 253 159 464 minecraft:brown_terracotta
fill 253 156 504 256 156 504 minecraft:brown_terracotta
fill 254 156 503 257 156 503 minecraft:brown_terracotta
setblock 256 156 465 minecraft:bone_block
setblock 257 156 464 minecraft:bone_block
fill 257 156 465 257 159 465 minecraft:brown_terracotta
setblock 257 156 504 minecraft:bone_block
fill 258 156 464 258 159 464 minecraft:brown_terracotta
setblock 258 156 503 minecraft:bone_block
fill 258 156 504 258 159 504 minecraft:brown_terracotta
fill 259 156 503 259 159 503 minecraft:brown_terracotta
setblock 262 156 464 minecraft:bone_block
setblock 262 156 503 minecraft:brown_terracotta
setblock 262 156 504 minecraft:bone_block
fill 263 156 464 263 157 464 minecraft:brown_terracotta
fill 263 156 504 266 156 504 minecraft:brown_terracotta
setblock 267 156 504 minecraft:bone_block
fill 268 156 498 270 157 498 minecraft:bone_block
fill 268 156 500 270 157 500 minecraft:bone_block
setblock 268 156 503 minecraft:bone_block
fill 268 156 504 268 159 504 minecraft:brown_terracotta
fill 269 156 499 269 157 499 minecraft:bone_block
fill 269 156 503 269 159 503 minecraft:brown_terracotta
setblock 272 156 464 minecraft:bone_block
setblock 272 156 504 minecraft:bone_block
fill 273 156 464 273 159 464 minecraft:brown_terracotta
setblock 273 156 497 minecraft:brown_terracotta
setblock 273 156 498 minecraft:bone_block
fill 273 156 499 273 159 499 minecraft:brown_terracotta
setblock 273 156 503 minecraft:bone_block
fill 273 156 504 273 159 504 minecraft:brown_terracotta
setblock 274 156 493 minecraft:brown_terracotta
setblock 274 156 497 minecraft:bone_block
fill 274 156 498 274 159 498 minecraft:brown_terracotta
setblock 274 156 502 minecraft:bone_block
fill 274 156 503 274 159 503 minecraft:brown_terracotta
setblock 275 156 476 minecraft:bone_block
fill 275 156 477 275 159 477 minecraft:brown_terracotta
fill 275 156 479 275 156 480 minecraft:brown_terracotta
setblock 275 156 481 minecraft:bone_block
fill 275 156 482 276 158 482 minecraft:brown_terracotta
setblock 275 156 491 minecraft:bone_block
fill 275 156 492 275 159 492 minecraft:brown_terracotta
setblock 275 156 496 minecraft:bone_block
fill 275 156 497 275 159 497 minecraft:brown_terracotta
setblock 275 156 501 minecraft:bone_block
fill 275 156 502 275 159 502 minecraft:brown_terracotta
setblock 276 156 465 minecraft:bone_block
setblock 276 156 466 minecraft:brown_terracotta
setblock 276 156 470 minecraft:bone_block
fill 276 156 471 276 157 471 minecraft:brown_terracotta
setblock 276 156 475 minecraft:bone_block
fill 276 156 476 276 159 476 minecraft:brown_terracotta
setblock 276 156 479 minecraft:brown_terracotta
setblock 276 156 480 minecraft:bone_block
fill 276 156 481 276 159 481 minecraft:brown_terracotta
fill 276 156 483 276 156 484 minecraft:brown_terracotta
setblock 276 156 485 minecraft:bone_block
fill 276 156 486 276 159 486 minecraft:brown_terracotta
setblock 276 156 490 minecraft:bone_block
fill 276 156 491 276 159 491 minecraft:brown_terracotta
setblock 276 156 495 minecraft:bone_block
fill 276 156 496 276 159 496 minecraft:brown_terracotta
setblock 276 156 500 minecraft:bone_block
fill 276 156 501 276 159 501 minecraft:brown_terracotta
setblock 236 157 474 minecraft:bone_block
fill 236 157 475 236 160 475 minecraft:brown_terracotta
setblock 236 157 479 minecraft:bone_block
fill 236 157 480 236 160 480 minecraft:brown_terracotta
setblock 236 157 484 minecraft:bone_block
fill 236 157 485 236 160 485 minecraft:brown_terracotta
setblock 236 157 489 minecraft:bone_block
fill 236 157 490 236 160 490 minecraft:brown_terracotta
setblock 236 157 494 minecraft:bone_block
fill 236 157 495 236 160 495 minecraft:brown_terracotta
setblock 236 157 499 minecraft:bone_block
fill 236 157 500 236 160 500 minecraft:brown_terracotta
setblock 236 157 504 minecraft:bone_block
setblock 237 157 473 minecraft:bone_block
fill 237 157 474 237 158 474 minecraft:brown_terracotta
setblock 237 157 478 minecraft:bone_block
fill 237 157 479 237 160 479 minecraft:brown_terracotta
setblock 237 157 483 minecraft:bone_block
fill 237 157 484 237 160 484 minecraft:brown_terracotta
setblock 237 157 488 minecraft:bone_block
fill 237 157 489 237 158 489 minecraft:brown_terracotta
setblock 237 157 493 minecraft:bone_block
fill 237 157 494 237 159 494 minecraft:brown_terracotta
setblock 237 157 498 minecraft:bone_block
fill 237 157 499 237 160 499 minecraft:brown_terracotta
setblock 237 157 503 minecraft:bone_block
fill 237 157 504 237 160 504 minecraft:brown_terracotta
setblock 238 157 477 minecraft:bone_block
fill 238 157 478 238 159 478 minecraft:brown_terracotta
setblock 238 157 482 minecraft:bone_block
fill 238 157 483 238 160 483 minecraft:brown_terracotta
setblock 238 157 497 minecraft:bone_block
setblock 238 157 498 minecraft:brown_terracotta
fill 238 157 503 238 158 503 minecraft:brown_terracotta
setblock 251 157 464 minecraft:bone_block
setblock 251 157 504 minecraft:bone_block
fill 252 157 464 252 160 464 minecraft:brown_terracotta
fill 252 157 504 255 157 504 minecraft:brown_terracotta
fill 253 157 503 256 157 503 minecraft:brown_terracotta
setblock 255 157 465 minecraft:bone_block
setblock 256 157 464 minecraft:bone_block
fill 256 157 465 256 160 465 minecraft:brown_terracotta
setblock 256 157 504 minecraft:bone_block
fill 257 157 464 257 160 464 minecraft:brown_terracotta
setblock 257 157 503 minecraft:bone_block
fill 257 157 504 257 160 504 minecraft:brown_terracotta
fill 258 157 503 258 160 503 minecraft:brown_terracotta
setblock 261 157 464 minecraft:bone_block
setblock 261 157 504 minecraft:bone_block
fill 262 157 464 262 160 464 minecraft:brown_terracotta
setblock 262 157 503 minecraft:bone_block
fill 262 157 504 265 157 504 minecraft:brown_terracotta
setblock 266 157 504 minecraft:bone_block
fill 267 157 504 267 160 504 minecraft:brown_terracotta
fill 268 157 503 268 160 503 minecraft:brown_terracotta
fill 270 157 502 270 159 502 minecraft:brown_terracotta
setblock 271 157 464 minecraft:bone_block
setblock 271 157 504 minecraft:bone_block
fill 272 157 464 272 160 464 minecraft:brown_terracotta
setblock 272 157 503 minecraft:bone_block
fill 272 157 504 272 160 504 minecraft:brown_terracotta
fill 273 157 498 273 158 498 minecraft:brown_terracotta
setblock 273 157 502 minecraft:bone_block
fill 273 157 503 273 160 503 minecraft:brown_terracotta
setblock 274 157 496 minecraft:bone_block
fill 274 157 497 274 160 497 minecraft:brown_terracotta
setblock 274 157 501 minecraft:bone_block
fill 274 157 502 274 160 502 minecraft:brown_terracotta
setblock 275 157 475 minecraft:bone_block
fill 275 157 476 275 158 476 minecraft:brown_terracotta
setblock 275 157 479 minecraft:brown_terracotta
setblock 275 157 480 minecraft:bone_block
fill 275 157 481 275 160 481 minecraft:brown_terracotta
fill 275 157 483 276 157 483 minecraft:brown_terracotta
fill 275 157 491 275 158 491 minecraft:brown_terracotta
setblock 275 157 495 minecraft:bone_block
fill 275 157 496 275 160 496 minecraft:brown_terracotta
setblock 275 157 500 minecraft:bone_block
fill 275 157 501 275 160 501 minecraft:brown_terracotta
setblock 276 157 464 minecraft:bone_block
setblock 276 157 465 minecraft:brown_terracotta
setblock 276 157 474 minecraft:bone_block
fill 276 157 475 276 160 475 minecraft:brown_terracotta
setblock 276 157 479 minecraft:bone_block
fill 276 157 480 276 160 480 minecraft:brown_terracotta
setblock 276 157 484 minecraft:bone_block
fill 276 157 485 276 160 485 minecraft:brown_terracotta
setblock 276 157 489 minecraft:bone_block
fill 276 157 490 276 160 490 minecraft:brown_terracotta
setblock 276 157 494 minecraft:bone_block
fill 276 157 495 276 160 495 minecraft:brown_terracotta
setblock 276 157 499 minecraft:bone_block
fill 276 157 500 276 160 500 minecraft:brown_terracotta
setblock 276 157 504 minecraft:bone_block
setblock 236 158 473 minecraft:bone_block
fill 236 158 474 236 161 474 minecraft:brown_terracotta
setblock 236 158 478 minecraft:bone_block
fill 236 158 479 236 161 479 minecraft:brown_terracotta
setblock 236 158 483 minecraft:bone_block
fill 236 158 484 236 161 484 minecraft:brown_terracotta
setblock 236 158 488 minecraft:bone_block
fill 236 158 489 236 161 489 minecraft:brown_terracotta
setblock 236 158 493 minecraft:bone_block
fill 236 158 494 236 161 494 minecraft:brown_terracotta
setblock 236 158 498 minecraft:bone_block
fill 236 158 499 236 161 499 minecraft:brown_terracotta
setblock 236 158 503 minecraft:bone_block
fill 236 158 504 236 161 504 minecraft:brown_terracotta
setblock 237 158 477 minecraft:bone_block
fill 237 158 478 237 161 478 minecraft:brown_terracotta
setblock 237 158 482 minecraft:bone_block
fill 237 158 483 237 161 483 minecraft:brown_terracotta
setblock 237 158 487 minecraft:bone_block
fill 237 158 488 237 159 488 minecraft:brown_terracotta
setblock 237 158 492 minecraft:bone_block
setblock 237 158 493 minecraft:brown_terracotta
setblock 237 158 497 minecraft:bone_block
fill 237 158 498 237 160 498 minecraft:brown_terracotta
setblock 237 158 502 minecraft:bone_block
fill 237 158 503 237 160 503 minecraft:brown_terracotta
setblock 238 158 477 minecraft:brown_terracotta
setblock 238 158 481 minecraft:bone_block
fill 238 158 482 238 161 482 minecraft:brown_terracotta
fill 251 158 464 251 161 464 minecraft:brown_terracotta
fill 251 158 504 254 158 504 minecraft:brown_terracotta
setblock 253 158 465 minecraft:brown_terracotta
fill 253 158 503 255 158 503 minecraft:brown_terracotta
setblock 254 158 465 minecraft:bone_block
setblock 255 158 464 minecraft:bone_block
fill 255 158 465 255 161 465 minecraft:brown_terracotta
setblock 255 158 504 minecraft:bone_block
fill 256 158 464 256 161 464 minecraft:brown_terracotta
setblock 256 158 503 minecraft:bone_block
fill 256 158 504 256 161 504 minecraft:brown_terracotta
fill 257 158 503 257 161 503 minecraft:brown_terracotta
setblock 260 158 464 minecraft:bone_block
setblock 260 158 504 minecraft:bone_block
fill 261 158 464 261 161 464 minecraft:brown_terracotta
setblock 261 158 503 minecraft:bone_block
fill 261 158 504 264 158 504 minecraft:brown_terracotta
setblock 265 158 504 minecraft:bone_block
fill 266 158 504 266 161 504 minecraft:brown_terracotta
fill 267 158 503 267 161 503 minecraft:brown_terracotta
setblock 270 158 504 minecraft:bone_block
fill 271 158 464 271 161 464 minecraft:brown_terracotta
setblock 271 158 503 minecraft:bone_block
fill 271 158 504 271 161 504 minecraft:brown_terracotta
setblock 272 158 502 minecraft:bone_block
fill 272 158 503 272 161 503 minecraft:brown_terracotta
setblock 273 158 500 minecraft:brown_terracotta
setblock 273 158 501 minecraft:bone_block
fill 273 158 502 273 161 502 minecraft:brown_terracotta
setblock 274 158 495 minecraft:bone_block
fill 274 158 496 274 161 496 minecraft:brown_terracotta
setblock 274 158 500 minecraft:bone_block
fill 274 158 501 274 161 501 minecraft:brown_terracotta
setblock 275 158 464 minecraft:bone_block
setblock 275 158 479 minecraft:bone_block
fill 275 158 480 275 161 480 minecraft:brown_terracotta
setblock 275 158 483 minecraft:brown_terracotta
setblock 275 158 484 minecraft:bone_block
setblock 275 158 494 minecraft:bone_block
fill 275 158 495 275 161 495 minecraft:brown_terracotta
setblock 275 158 499 minecraft:bone_block
fill 275 158 500 275 161 500 minecraft:brown_terracotta
setblock 275 158 504 minecraft:bone_block
fill 276 158 464 276 161 464 minecraft:brown_terracotta
setblock 276 158 473 minecraft:bone_block
fill 276 158 474 276 159 474 minecraft:brown_terracotta
setblock 276 158 478 minecraft:bone_block
fill 276 158 479 276 161 479 minecraft:brown_terracotta
setblock 276 158 483 minecraft:bone_block
fill 276 158 484 276 161 484 minecraft:brown_terracotta
setblock 276 158 488 minecraft:bone_block
fill 276 158 489 276 161 489 minecraft:brown_terracotta
setblock 276 158 493 minecraft:bone_block
fill 276 158 494 276 161 494 minecraft:brown_terracotta
setblock 276 158 498 minecraft:bone_block
fill 276 158 499 276 161 499 minecraft:brown_terracotta
setblock 276 158 503 minecraft:bone_block
fill 276 158 504 276 161 504 minecraft:brown_terracotta
fill 236 159 473 236 160 473 minecraft:brown_terracotta
setblock 236 159 477 minecraft:bone_block
fill 236 159 478 236 162 478 minecraft:brown_terracotta
setblock 236 159 482 minecraft:bone_block
fill 236 159 483 236 162 483 minecraft:brown_terracotta
setblock 236 159 487 minecraft:bone_block
fill 236 159 488 236 162 488 minecraft:brown_terracotta
setblock 236 159 492 minecraft:bone_block
fill 236 159 493 236 162 493 minecraft:brown_terracotta
setblock 236 159 497 minecraft:bone_block
fill 236 159 498 236 162 498 minecraft:brown_terracotta
setblock 236 159 502 minecraft:bone_block
fill 236 159 503 236 162 503 minecraft:brown_terracotta
setblock 237 159 476 minecraft:bone_block
fill 237 159 477 237 162 477 minecraft:brown_terracotta
setblock 237 159 481 minecraft:bone_block
fill 237 159 482 237 162 482 minecraft:brown_terracotta
setblock 237 159 486 minecraft:bone_block
fill 237 159 487 237 162 487 minecraft:brown_terracotta
fill 237 159 489 237 162 489 minecraft:soul_soil
setblock 237 159 496 minecraft:bone_block
fill 237 159 497 237 160 497 minecraft:brown_terracotta
setblock 237 159 501 minecraft:bone_block
fill 237 159 502 237 161 502 minecraft:brown_terracotta
setblock 238 159 480 minecraft:bone_block
fill 238 159 481 238 162 481 minecraft:brown_terracotta
setblock 239 159 504 minecraft:bone_block
fill 250 159 464 250 162 464 minecraft:brown_terracotta
fill 250 159 504 253 159 504 minecraft:brown_terracotta
fill 252 159 503 254 159 503 minecraft:brown_terracotta
setblock 253 159 465 minecraft:bone_block
setblock 254 159 464 minecraft:bone_block
fill 254 159 465 254 162 465 minecraft:brown_terracotta
setblock 254 159 504 minecraft:bone_block
fill 255 159 464 255 162 464 minecraft:brown_terracotta
setblock 255 159 503 minecraft:bone_block
fill 255 159 504 255 162 504 minecraft:brown_terracotta
fill 256 159 503 256 162 503 minecraft:brown_terracotta
setblock 258 159 465 minecraft:bone_block
setblock 259 159 464 minecraft:bone_block
setblock 259 159 504 minecraft:bone_block
fill 260 159 464 260 162 464 minecraft:brown_terracotta
setblock 260 159 503 minecraft:bone_block
fill 260 159 504 263 159 504 minecraft:brown_terracotta
fill 261 159 503 261 162 503 minecraft:brown_terracotta
setblock 264 159 504 minecraft:bone_block
fill 265 159 504 265 162 504 minecraft:brown_terracotta
setblock 269 159 504 minecraft:bone_block
fill 270 159 464 270 162 464 minecraft:brown_terracotta
setblock 270 159 503 minecraft:bone_block
fill 270 159 504 270 162 504 minecraft:brown_terracotta
setblock 271 159 502 minecraft:bone_block
fill 271 159 503 271 162 503 minecraft:brown_terracotta
fill 272 159 502 272 162 502 minecraft:brown_terracotta
setblock 273 159 500 minecraft:bone_block
fill 273 159 501 273 162 501 minecraft:brown_terracotta
setblock 274 159 464 minecraft:bone_block
setblock 274 159 495 minecraft:brown_terracotta
setblock 274 159 499 minecraft:bone_block
fill 274 159 500 274 162 500 minecraft:brown_terracotta
setblock 274 159 504 minecraft:bone_block
fill 275 159 464 275 162 464 minecraft:brown_terracotta
setblock 275 159 478 minecraft:bone_block
fill 275 159 479 275 162 479 minecraft:brown_terracotta
setblock 275 159 482 minecraft:brown_terracotta
setblock 275 159 483 minecraft:bone_block
fill 275 159 484 275 161 485 minecraft:brown_terracotta
setblock 275 159 493 minecraft:bone_block
fill 275 159 494 275 162 494 minecraft:brown_terracotta
setblock 275 159 498 minecraft:bone_block
fill 275 159 499 275 162 499 minecraft:brown_terracotta
setblock 275 159 503 minecraft:bone_block
fill 275 159 504 275 162 504 minecraft:brown_terracotta
setblock 276 159 477 minecraft:bone_block
fill 276 159 478 276 162 478 minecraft:brown_terracotta
setblock 276 159 482 minecraft:bone_block
fill 276 159 483 276 162 483 minecraft:brown_terracotta
setblock 276 159 487 minecraft:bone_block
fill 276 159 488 276 162 488 minecraft:brown_terracotta
setblock 276 159 492 minecraft:bone_block
fill 276 159 493 276 162 493 minecraft:brown_terracotta
setblock 276 159 497 minecraft:bone_block
fill 276 159 498 276 162 498 minecraft:brown_terracotta
setblock 276 159 502 minecraft:bone_block
fill 276 159 503 276 162 503 minecraft:brown_terracotta
setblock 236 160 476 minecraft:bone_block
fill 236 160 477 236 163 477 minecraft:brown_terracotta
setblock 236 160 481 minecraft:bone_block
fill 236 160 482 236 163 482 minecraft:brown_terracotta
setblock 236 160 486 minecraft:bone_block
fill 236 160 487 236 163 487 minecraft:brown_terracotta
setblock 236 160 491 minecraft:bone_block
fill 236 160 492 236 163 492 minecraft:brown_terracotta
setblock 236 160 496 minecraft:bone_block
fill 236 160 497 236 163 497 minecraft:brown_terracotta
setblock 236 160 501 minecraft:bone_block
fill 236 160 502 236 163 502 minecraft:brown_terracotta
fill 237 160 476 237 161 476 minecraft:brown_terracotta
setblock 237 160 480 minecraft:bone_block
fill 237 160 481 237 163 481 minecraft:brown_terracotta
setblock 237 160 485 minecraft:bone_block
fill 237 160 486 237 163 486 minecraft:brown_terracotta
setblock 237 160 500 minecraft:bone_block
fill 237 160 501 237 161 501 minecraft:brown_terracotta
setblock 238 160 479 minecraft:bone_block
fill 238 160 480 238 163 480 minecraft:brown_terracotta
setblock 238 160 504 minecraft:bone_block
fill 249 160 464 249 163 464 minecraft:brown_terracotta
fill 249 160 504 252 160 504 minecraft:brown_terracotta
setblock 252 160 465 minecraft:bone_block
fill 252 160 503 253 160 503 minecraft:brown_terracotta
setblock 253 160 464 minecraft:bone_block
fill 253 160 465 253 163 465 minecraft:brown_terracotta
setblock 253 160 504 minecraft:bone_block
fill 254 160 464 254 163 464 minecraft:brown_terracotta
setblock 254 160 503 minecraft:bone_block
fill 254 160 504 254 163 504 minecraft:brown_terracotta
fill 255 160 503 255 163 503 minecraft:brown_terracotta
setblock 257 160 465 minecraft:bone_block
setblock 258 160 464 minecraft:bone_block
fill 258 160 465 258 163 465 minecraft:brown_terracotta
setblock 258 160 504 minecraft:bone_block
fill 259 160 464 259 163 464 minecraft:brown_terracotta
setblock 259 160 503 minecraft:bone_block
fill 259 160 504 262 160 504 minecraft:brown_terracotta
fill 260 160 503 260 163 503 minecraft:brown_terracotta
setblock 263 160 504 minecraft:bone_block
fill 264 160 504 264 163 504 minecraft:brown_terracotta
fill 266 160 503 266 162 503 minecraft:brown_terracotta
setblock 268 160 504 minecraft:bone_block
fill 269 160 464 269 163 464 minecraft:brown_terracotta
setblock 269 160 502 minecraft:brown_terracotta
setblock 269 160 503 minecraft:bone_block
fill 269 160 504 269 163 504 minecraft:brown_terracotta
setblock 270 160 502 minecraft:bone_block
fill 270 160 503 270 163 503 minecraft:brown_terracotta
fill 271 160 502 271 163 502 minecraft:brown_terracotta
fill 272 160 501 272 163 501 minecraft:brown_terracotta
setblock 273 160 464 minecraft:bone_block
fill 273 160 500 273 163 500 minecraft:brown_terracotta
setblock 273 160 504 minecraft:bone_block
fill 274 160 464 274 163 464 minecraft:brown_terracotta
setblock 274 160 498 minecraft:bone_block
fill 274 160 499 274 163 499 minecraft:brown_terracotta
setblock 274 160 503 minecraft:bone_block
fill 274 160 504 274 163 504 minecraft:brown_terracotta
fill 275 160 478 275 163 478 minecraft:brown_terracotta
setblock 275 160 482 minecraft:bone_block
fill 275 160 483 275 163 483 minecraft:brown_terracotta
setblock 275 160 486 minecraft:brown_terracotta
setblock 275 160 492 minecraft:bone_block
fill 275 160 493 275 163 493 minecraft:brown_terracotta
setblock 275 160 497 minecraft:bone_block
fill 275 160 498 275 163 498 minecraft:brown_terracotta
setblock 275 160 502 minecraft:bone_block
fill 275 160 503 275 163 503 minecraft:brown_terracotta
setblock 276 160 476 minecraft:bone_block
fill 276 160 477 276 163 477 minecraft:brown_terracotta
setblock 276 160 481 minecraft:bone_block
fill 276 160 482 276 163 482 minecraft:brown_terracotta
setblock 276 160 486 minecraft:bone_block
fill 276 160 487 276 163 487 minecraft:brown_terracotta
setblock 276 160 491 minecraft:bone_block
fill 276 160 492 276 163 492 minecraft:brown_terracotta
setblock 276 160 496 minecraft:bone_block
fill 276 160 497 276 163 497 minecraft:brown_terracotta
setblock 276 160 501 minecraft:bone_block
fill 276 160 502 276 163 502 minecraft:brown_terracotta
setblock 236 161 475 minecraft:bone_block
fill 236 161 476 236 164 476 minecraft:brown_terracotta
setblock 236 161 480 minecraft:bone_block
fill 236 161 481 236 164 481 minecraft:brown_terracotta
setblock 236 161 485 minecraft:bone_block
fill 236 161 486 236 164 486 minecraft:brown_terracotta
setblock 236 161 490 minecraft:bone_block
fill 236 161 491 236 164 491 minecraft:brown_terracotta
setblock 236 161 495 minecraft:bone_block
fill 236 161 496 236 164 496 minecraft:brown_terracotta
setblock 236 161 500 minecraft:bone_block
fill 236 161 501 236 164 501 minecraft:brown_terracotta
setblock 237 161 479 minecraft:bone_block
fill 237 161 480 237 164 480 minecraft:brown_terracotta
setblock 237 161 484 minecraft:bone_block
fill 237 161 485 237 164 485 minecraft:brown_terracotta
setblock 237 161 488 minecraft:soul_soil
fill 237 161 490 237 162 490 minecraft:soul_soil
setblock 237 161 500 minecraft:brown_terracotta
setblock 237 161 504 minecraft:bone_block
setblock 238 161 483 minecraft:bone_block
fill 238 161 489 238 162 489 minecraft:soul_soil
fill 238 161 504 238 164 504 minecraft:brown_terracotta
fill 248 161 464 248 164 464 minecraft:brown_terracotta
fill 248 161 504 251 161 504 minecraft:brown_terracotta
setblock 251 161 465 minecraft:bone_block
fill 251 161 503 252 161 503 minecraft:brown_terracotta
setblock 252 161 464 minecraft:bone_block
fill 252 161 465 252 164 465 minecraft:brown_terracotta
setblock 252 161 504 minecraft:bone_block
fill 253 161 464 253 164 464 minecraft:brown_terracotta
setblock 253 161 503 minecraft:bone_block
fill 253 161 504 253 164 504 minecraft:brown_terracotta
fill 254 161 503 254 164 503 minecraft:brown_terracotta
setblock 256 161 465 minecraft:bone_block
setblock 257 161 464 minecraft:bone_block
fill 257 161 465 257 164 465 minecraft:brown_terracotta
setblock 257 161 504 minecraft:bone_block
fill 258 161 464 258 164 464 minecraft:brown_terracotta
setblock 258 161 503 minecraft:bone_block
fill 258 161 504 261 161 504 minecraft:brown_terracotta
fill 259 161 503 259 164 503 minecraft:brown_terracotta
setblock 262 161 464 minecraft:bone_block
setblock 262 161 504 minecraft:bone_block
fill 263 161 464 263 164 464 minecraft:brown_terracotta
fill 263 161 504 263 164 504 minecraft:brown_terracotta
fill 264 161 503 265 163 503 minecraft:brown_terracotta
setblock 266 161 464 minecraft:brown_terracotta
setblock 267 161 464 minecraft:bone_block
setblock 267 161 504 minecraft:bone_block
fill 268 161 464 268 164 464 minecraft:brown_terracotta
setblock 268 161 502 minecraft:brown_terracotta
setblock 268 161 503 minecraft:bone_block
fill 268 161 504 268 164 504 minecraft:brown_terracotta
setblock 269 161 502 minecraft:bone_block
fill 269 161 503 269 164 503 minecraft:brown_terracotta
fill 270 161 502 270 164 502 minecraft:brown_terracotta
setblock 272 161 464 minecraft:bone_block
setblock 272 161 504 minecraft:bone_block
fill 273 161 464 273 164 464 minecraft:brown_terracotta
setblock 273 161 503 minecraft:bone_block
fill 273 161 504 273 164 504 minecraft:brown_terracotta
setblock 274 161 497 minecraft:bone_block
fill 274 161 498 274 164 498 minecraft:brown_terracotta
setblock 274 161 502 minecraft:bone_block
fill 274 161 503 274 164 503 minecraft:brown_terracotta
setblock 275 161 481 minecraft:bone_block
fill 275 161 482 275 164 482 minecraft:brown_terracotta
setblock 275 161 486 minecraft:bone_block
fill 275 161 487 275 163 488 minecraft:brown_terracotta
setblock 275 161 496 minecraft:bone_block
fill 275 161 497 275 164 497 minecraft:brown_terracotta
setblock 275 161 501 minecraft:bone_block
fill 275 161 502 275 164 502 minecraft:brown_terracotta
fill 276 161 476 276 163 476 minecraft:brown_terracotta
setblock 276 161 480 minecraft:bone_block
fill 276 161 481 276 164 481 minecraft:brown_terracotta
setblock 276 161 485 minecraft:bone_block
fill 276 161 486 276 164 486 minecraft:brown_terracotta
setblock 276 161 490 minecraft:bone_block
fill 276 161 491 276 164 491 minecraft:brown_terracotta
setblock 276 161 495 minecraft:bone_block
fill 276 161 496 276 164 496 minecraft:brown_terracotta
setblock 276 161 500 minecraft:bone_block
fill 276 161 501 276 164 501 minecraft:brown_terracotta
setblock 236 162 464 minecraft:bone_block
setblock 236 162 474 minecraft:bone_block
fill 236 162 475 236 164 475 minecraft:brown_terracotta
setblock 236 162 479 minecraft:bone_block
fill 236 162 480 236 164 480 minecraft:brown_terracotta
setblock 236 162 484 minecraft:bone_block
fill 236 162 485 236 164 485 minecraft:brown_terracotta
setblock 236 162 489 minecraft:bone_block
fill 236 162 490 236 164 490 minecraft:brown_terracotta
setblock 236 162 494 minecraft:bone_block
fill 236 162 495 236 164 495 minecraft:brown_terracotta
setblock 236 162 499 minecraft:bone_block
fill 236 162 500 236 164 500 minecraft:brown_terracotta
setblock 236 162 504 minecraft:bone_block
setblock 237 162 478 minecraft:bone_block
fill 237 162 479 237 164 479 minecraft:brown_terracotta
setblock 237 162 483 minecraft:bone_block
fill 237 162 484 238 164 484 minecraft:brown_terracotta
setblock 237 162 488 minecraft:bone_block
fill 237 162 504 237 164 504 minecraft:brown_terracotta
setblock 238 162 482 minecraft:bone_block
fill 238 162 483 238 164 483 minecraft:brown_terracotta
fill 246 162 484 246 163 484 minecraft:bone_block
fill 247 162 464 247 164 464 minecraft:brown_terracotta
fill 247 162 504 250 162 504 minecraft:brown_terracotta
setblock 249 162 465 minecraft:brown_terracotta
setblock 250 162 465 minecraft:bone_block
fill 250 162 503 251 162 503 minecraft:brown_terracotta
setblock 251 162 464 minecraft:bone_block
fill 251 162 465 251 164 465 minecraft:brown_terracotta
setblock 251 162 504 minecraft:bone_block
fill 252 162 464 252 164 464 minecraft:brown_terracotta
setblock 252 162 503 minecraft:bone_block
fill 252 162 504 252 164 504 minecraft:brown_terracotta
setblock 253 162 466 minecraft:brown_terracotta
fill 253 162 503 253 164 503 minecraft:brown_terracotta
setblock 254 162 466 minecraft:bone_block
fill 254 162 502 254 164 502 minecraft:brown_terracotta
setblock 255 162 465 minecraft:bone_block
setblock 256 162 464 minecraft:bone_block
fill 256 162 465 256 164 465 minecraft:brown_terracotta
setblock 256 162 504 minecraft:bone_block
fill 257 162 464 257 164 464 minecraft:brown_terracotta
setblock 257 162 503 minecraft:bone_block
fill 257 162 504 260 162 504 minecraft:brown_terracotta
fill 258 162 503 258 164 503 minecraft:brown_terracotta
setblock 261 162 464 minecraft:bone_block
setblock 261 162 504 minecraft:bone_block
fill 262 162 464 262 164 464 minecraft:brown_terracotta
setblock 262 162 503 minecraft:bone_block
fill 262 162 504 262 164 504 minecraft:brown_terracotta
fill 263 162 503 263 164 503 minecraft:brown_terracotta
fill 264 162 464 265 162 464 minecraft:brown_terracotta
setblock 266 162 464 minecraft:bone_block
setblock 266 162 504 minecraft:bone_block
fill 267 162 464 267 164 464 minecraft:brown_terracotta
setblock 267 162 503 minecraft:bone_block
fill 267 162 504 267 164 504 minecraft:brown_terracotta
setblock 268 162 502 minecraft:bone_block
fill 268 162 503 268 164 503 minecraft:brown_terracotta
fill 269 162 502 269 164 502 minecraft:brown_terracotta
setblock 271 162 464 minecraft:bone_block
fill 271 162 501 271 164 501 minecraft:brown_terracotta
setblock 271 162 504 minecraft:bone_block
fill 272 162 464 272 164 464 minecraft:brown_terracotta
setblock 272 162 503 minecraft:bone_block
fill 272 162 504 272 164 504 minecraft:brown_terracotta
setblock 273 162 502 minecraft:bone_block
fill 273 162 503 273 164 503 minecraft:brown_terracotta
fill 274 162 482 274 163 484 minecraft:brown_terracotta
fill 274 162 497 274 164 497 minecraft:brown_terracotta
setblock 274 162 501 minecraft:bone_block
fill 274 162 502 274 164 502 minecraft:brown_terracotta
setblock 275 162 480 minecraft:bone_block
fill 275 162 481 275 164 481 minecraft:brown_terracotta
setblock 275 162 484 minecraft:brown_terracotta
setblock 275 162 485 minecraft:bone_block
fill 275 162 486 275 164 486 minecraft:brown_terracotta
setblock 275 162 489 minecraft:brown_terracotta
setblock 275 162 490 minecraft:bone_block
fill 275 162 491 275 164 492 minecraft:brown_terracotta
setblock 275 162 495 minecraft:bone_block
fill 275 162 496 275 164 496 minecraft:brown_terracotta
setblock 275 162 500 minecraft:bone_block
fill 275 162 501 275 164 501 minecraft:brown_terracotta
setblock 276 162 464 minecraft:bone_block
fill 276 162 465 276 164 465 minecraft:brown_terracotta
setblock 276 162 479 minecraft:bone_block
fill 276 162 480 276 164 480 minecraft:brown_terracotta
setblock 276 162 484 minecraft:bone_block
fill 276 162 485 276 164 485 minecraft:brown_terracotta
setblock 276 162 489 minecraft:bone_block
fill 276 162 490 276 164 490 minecraft:brown_terracotta
setblock 276 162 494 minecraft:bone_block
fill 276 162 495 276 164 495 minecraft:brown_terracotta
setblock 276 162 499 minecraft:bone_block
fill 276 162 500 276 164 500 minecraft:brown_terracotta
setblock 276 162 504 minecraft:bone_block
fill 236 163 464 236 164 465 minecraft:brown_terracotta
fill 236 163 474 236 164 474 minecraft:brown_terracotta
setblock 236 163 478 minecraft:bone_block
fill 236 163 479 236 164 479 minecraft:brown_terracotta
setblock 236 163 483 minecraft:bone_block
fill 236 163 484 236 164 484 minecraft:brown_terracotta
setblock 236 163 488 minecraft:bone_block
fill 236 163 489 236 164 489 minecraft:brown_terracotta
setblock 236 163 493 minecraft:bone_block
fill 236 163 494 236 164 494 minecraft:brown_terracotta
setblock 236 163 498 minecraft:bone_block
fill 236 163 499 236 164 499 minecraft:brown_terracotta
setblock 236 163 503 minecraft:bone_block
fill 236 163 504 236 164 504 minecraft:brown_terracotta
fill 237 163 464 237 164 464 minecraft:brown_terracotta
setblock 237 163 477 minecraft:bone_block
fill 237 163 478 237 164 478 minecraft:brown_terracotta
setblock 237 163 482 minecraft:bone_block
fill 237 163 483 237 164 483 minecraft:brown_terracotta
setblock 237 163 487 minecraft:bone_block
fill 237 163 488 237 164 488 minecraft:brown_terracotta
setblock 238 163 466 minecraft:light[level=12]
setblock 238 163 474 minecraft:light[level=12]
setblock 238 163 481 minecraft:bone_block
fill 238 163 482 238 164 482 minecraft:brown_terracotta
setblock 238 163 490 minecraft:light[level=12]
setblock 238 163 498 minecraft:light[level=12]
setblock 245 163 464 minecraft:bone_block
fill 246 163 464 246 164 464 minecraft:brown_terracotta
setblock 246 163 466 minecraft:light[level=12]
setblock 246 163 474 minecraft:light[level=12]
setblock 246 163 482 minecraft:light[level=12]
setblock 246 163 490 minecraft:light[level=12]
setblock 246 163 498 minecraft:light[level=12]
fill 246 163 504 249 163 504 minecraft:brown_terracotta
setblock 248 163 465 minecraft:brown_terracotta
fill 248 163 486 248 164 487 minecraft:bone_block
setblock 249 163 465 minecraft:bone_block
fill 249 163 503 250 163 503 minecraft:brown_terracotta
setblock 250 163 464 minecraft:bone_block
fill 250 163 465 250 164 466 minecraft:brown_terracotta
setblock 250 163 504 minecraft:bone_block
fill 251 163 464 251 164 464 minecraft:brown_terracotta
fill 251 163 466 252 163 466 minecraft:brown_terracotta
setblock 251 163 503 minecraft:bone_block
fill 251 163 504 251 164 504 minecraft:brown_terracotta
fill 252 163 503 252 164 503 minecraft:brown_terracotta
setblock 253 163 466 minecraft:bone_block
fill 253 163 502 253 164 502 minecraft:brown_terracotta
setblock 254 163 465 minecraft:bone_block
fill 254 163 466 255 164 466 minecraft:brown_terracotta
setblock 254 163 474 minecraft:light[level=12]
setblock 254 163 482 minecraft:light[level=12]
setblock 254 163 490 minecraft:light[level=12]
setblock 254 163 498 minecraft:light[level=12]
setblock 255 163 464 minecraft:bone_block
fill 255 163 465 255 164 465 minecraft:brown_terracotta
fill 255 163 502 255 164 502 minecraft:brown_terracotta
setblock 255 163 504 minecraft:bone_block
fill 256 163 464 256 164 464 minecraft:brown_terracotta
setblock 256 163 503 minecraft:bone_block
fill 256 163 504 259 163 504 minecraft:brown_terracotta
fill 257 163 503 257 164 503 minecraft:brown_terracotta
setblock 259 163 465 minecraft:bone_block
setblock 260 163 464 minecraft:bone_block
setblock 260 163 504 minecraft:bone_block
fill 261 163 464 261 164 464 minecraft:brown_terracotta
setblock 261 163 503 minecraft:bone_block
fill 261 163 504 261 164 504 minecraft:brown_terracotta
setblock 262 163 466 minecraft:light[level=12]
setblock 262 163 474 minecraft:light[level=12]
setblock 262 163 482 minecraft:light[level=12]
setblock 262 163 490 minecraft:light[level=12]
setblock 262 163 498 minecraft:light[level=12]
fill 262 163 503 262 164 503 minecraft:brown_terracotta
setblock 264 163 464 minecraft:brown_terracotta
setblock 265 163 464 minecraft:bone_block
setblock 265 163 504 minecraft:bone_block
fill 266 163 464 266 164 464 minecraft:brown_terracotta
setblock 266 163 503 minecraft:bone_block
fill 266 163 504 266 164 504 minecraft:brown_terracotta
setblock 267 163 502 minecraft:bone_block
fill 267 163 503 267 164 503 minecraft:brown_terracotta
fill 268 163 502 268 164 502 minecraft:brown_terracotta
setblock 269 163 465 minecraft:bone_block
setblock 270 163 464 minecraft:bone_block
fill 270 163 465 273 163 465 minecraft:brown_terracotta
setblock 270 163 466 minecraft:light[level=12]
setblock 270 163 474 minecraft:light[level=12]
setblock 270 163 482 minecraft:light[level=12]
setblock 270 163 490 minecraft:light[level=12]
setblock 270 163 498 minecraft:light[level=12]
fill 270 163 501 270 164 501 minecraft:brown_terracotta
setblock 270 163 504 minecraft:bone_block
fill 271 163 464 271 164 464 minecraft:brown_terracotta
setblock 271 163 503 minecraft:bone_block
fill 271 163 504 271 164 504 minecraft:brown_terracotta
setblock 272 163 502 minecraft:bone_block
fill 272 163 503 272 164 503 minecraft:brown_terracotta
setblock 273 163 501 minecraft:bone_block
fill 273 163 502 273 164 502 minecraft:brown_terracotta
fill 274 163 481 274 164 481 minecraft:brown_terracotta
setblock 274 163 485 minecraft:bone_block
fill 274 163 486 274 164 487 minecraft:brown_terracotta
setblock 274 163 500 minecraft:bone_block
fill 274 163 501 274 164 501 minecraft:brown_terracotta
setblock 275 163 464 minecraft:bone_block
setblock 275 163 479 minecraft:bone_block
fill 275 163 480 275 164 480 minecraft:brown_terracotta
setblock 275 163 484 minecraft:bone_block
fill 275 163 485 275 164 485 minecraft:brown_terracotta
setblock 275 163 489 minecraft:bone_block
fill 275 163 490 275 164 490 minecraft:brown_terracotta
setblock 275 163 494 minecraft:bone_block
fill 275 163 495 275 164 495 minecraft:brown_terracotta
setblock 275 163 499 minecraft:bone_block
fill 275 163 500 275 164 500 minecraft:brown_terracotta
setblock 275 163 504 minecraft:bone_block
fill 276 163 464 276 164 464 minecraft:brown_terracotta
setblock 276 163 478 minecraft:bone_block
fill 276 163 479 276 164 479 minecraft:brown_terracotta
setblock 276 163 483 minecraft:bone_block
fill 276 163 484 276 164 484 minecraft:brown_terracotta
setblock 276 163 488 minecraft:bone_block
fill 276 163 489 276 164 489 minecraft:brown_terracotta
setblock 276 163 493 minecraft:bone_block
fill 276 163 494 276 164 494 minecraft:brown_terracotta
setblock 276 163 498 minecraft:bone_block
fill 276 163 499 276 164 499 minecraft:brown_terracotta
setblock 276 163 503 minecraft:bone_block
fill 276 163 504 276 164 504 minecraft:brown_terracotta
setblock 236 164 466 minecraft:brown_terracotta
setblock 236 164 467 minecraft:bone_block
setblock 236 164 477 minecraft:bone_block
setblock 236 164 478 minecraft:brown_terracotta
setblock 236 164 482 minecraft:bone_block
setblock 236 164 483 minecraft:brown_terracotta
setblock 236 164 487 minecraft:bone_block
setblock 236 164 488 minecraft:brown_terracotta
setblock 236 164 492 minecraft:bone_block
setblock 236 164 493 minecraft:brown_terracotta
setblock 236 164 497 minecraft:bone_block
setblock 236 164 498 minecraft:brown_terracotta
setblock 236 164 502 minecraft:bone_block
setblock 236 164 503 minecraft:brown_terracotta
setblock 237 164 477 minecraft:brown_terracotta
setblock 237 164 481 minecraft:bone_block
setblock 237 164 482 minecraft:brown_terracotta
setblock 237 164 486 minecraft:bone_block
setblock 237 164 487 minecraft:brown_terracotta
setblock 237 164 489 minecraft:brown_terracotta
setblock 238 164 464 minecraft:brown_terracotta
setblock 238 164 480 minecraft:bone_block
setblock 238 164 481 minecraft:brown_terracotta
setblock 238 164 485 minecraft:bone_block
setblock 243 164 464 minecraft:brown_terracotta
setblock 244 164 464 minecraft:bone_block
setblock 245 164 464 minecraft:brown_terracotta
fill 245 164 504 248 164 504 minecraft:brown_terracotta
fill 246 164 465 247 164 465 minecraft:brown_terracotta
setblock 248 164 465 minecraft:bone_block
fill 248 164 503 249 164 503 minecraft:brown_terracotta
setblock 249 164 464 minecraft:bone_block
fill 249 164 465 249 164 466 minecraft:brown_terracotta
setblock 249 164 504 minecraft:bone_block
setblock 250 164 464 minecraft:brown_terracotta
setblock 250 164 503 minecraft:bone_block
setblock 250 164 504 minecraft:brown_terracotta
setblock 251 164 466 minecraft:brown_terracotta
setblock 251 164 502 minecraft:bone_block
setblock 251 164 503 minecraft:brown_terracotta
setblock 252 164 466 minecraft:bone_block
setblock 252 164 502 minecraft:brown_terracotta
setblock 253 164 465 minecraft:bone_block
setblock 253 164 466 minecraft:brown_terracotta
setblock 254 164 464 minecraft:bone_block
setblock 254 164 465 minecraft:brown_terracotta
setblock 254 164 504 minecraft:bone_block
setblock 255 164 464 minecraft:brown_terracotta
setblock 255 164 503 minecraft:bone_block
fill 255 164 504 258 164 504 minecraft:brown_terracotta
setblock 256 164 466 minecraft:brown_terracotta
setblock 256 164 503 minecraft:brown_terracotta
setblock 258 164 465 minecraft:bone_block
setblock 259 164 464 minecraft:bone_block
fill 259 164 465 260 164 465 minecraft:brown_terracotta
setblock 259 164 504 minecraft:bone_block
setblock 260 164 464 minecraft:brown_terracotta
setblock 260 164 503 minecraft:bone_block
setblock 260 164 504 minecraft:brown_terracotta
setblock 261 164 503 minecraft:brown_terracotta
setblock 264 164 464 minecraft:bone_block
setblock 264 164 503 minecraft:brown_terracotta
setblock 264 164 504 minecraft:bone_block
setblock 265 164 464 minecraft:brown_terracotta
setblock 265 164 503 minecraft:bone_block
setblock 265 164 504 minecraft:brown_terracotta
fill 266 164 465 267 164 465 minecraft:brown_terracotta
setblock 266 164 502 minecraft:bone_block
setblock 266 164 503 minecraft:brown_terracotta
setblock 267 164 502 minecraft:brown_terracotta
setblock 268 164 465 minecraft:bone_block
setblock 269 164 464 minecraft:bone_block
fill 269 164 465 272 164 465 minecraft:brown_terracotta
setblock 269 164 504 minecraft:bone_block
setblock 270 164 464 minecraft:brown_terracotta
setblock 270 164 503 minecraft:bone_block
setblock 270 164 504 minecraft:brown_terracotta
setblock 271 164 502 minecraft:bone_block
setblock 271 164 503 minecraft:brown_terracotta
setblock 272 164 501 minecraft:bone_block
setblock 272 164 502 minecraft:brown_terracotta
setblock 273 164 465 minecraft:bone_block
setblock 273 164 501 minecraft:brown_terracotta
setblock 274 164 464 minecraft:bone_block
setblock 274 164 465 minecraft:brown_terracotta
fill 274 164 482 274 164 483 minecraft:brown_terracotta
setblock 274 164 484 minecraft:bone_block
setblock 274 164 485 minecraft:brown_terracotta
setblock 274 164 488 minecraft:brown_terracotta
setblock 274 164 489 minecraft:bone_block
setblock 274 164 499 minecraft:bone_block
setblock 274 164 500 minecraft:brown_terracotta
setblock 274 164 504 minecraft:bone_block
setblock 275 164 464 minecraft:brown_terracotta
setblock 275 164 478 minecraft:bone_block
setblock 275 164 479 minecraft:brown_terracotta
setblock 275 164 483 minecraft:bone_block
setblock 275 164 484 minecraft:brown_terracotta
setblock 275 164 487 minecraft:brown_terracotta
setblock 275 164 488 minecraft:bone_block
setblock 275 164 489 minecraft:brown_terracotta
setblock 275 164 493 minecraft:bone_block
setblock 275 164 494 minecraft:brown_terracotta
setblock 275 164 498 minecraft:bone_block
setblock 275 164 499 minecraft:brown_terracotta
setblock 275 164 503 minecraft:bone_block
setblock 275 164 504 minecraft:brown_terracotta
setblock 276 164 466 minecraft:brown_terracotta
setblock 276 164 477 minecraft:bone_block
setblock 276 164 478 minecraft:brown_terracotta
setblock 276 164 482 minecraft:bone_block
setblock 276 164 483 minecraft:brown_terracotta
setblock 276 164 487 minecraft:bone_block
setblock 276 164 488 minecraft:brown_terracotta
setblock 276 164 492 minecraft:bone_block
setblock 276 164 493 minecraft:brown_terracotta
setblock 276 164 497 minecraft:bone_block
setblock 276 164 498 minecraft:brown_terracotta
setblock 276 164 502 minecraft:bone_block
setblock 276 164 503 minecraft:brown_terracotta
fill 247 169 485 249 169 487 minecraft:redstone_block
fill 248 169 478 250 169 480 minecraft:redstone_block
fill 255 169 479 257 169 481 minecraft:redstone_block
fill 255 169 485 257 169 487 minecraft:redstone_block
fill 235 170 477 235 205 480 minecraft:brown_terracotta
fill 235 170 481 246 170 485 minecraft:bone_block
fill 235 170 486 235 208 487 minecraft:brown_terracotta
fill 247 170 481 250 170 484 minecraft:bone_block
fill 250 170 465 254 170 477 minecraft:bone_block
fill 250 170 485 254 170 501 minecraft:bone_block
fill 251 170 478 254 170 481 minecraft:bone_block
fill 254 170 482 270 170 484 minecraft:bone_block
fill 258 170 481 270 170 481 minecraft:bone_block
fill 258 170 485 270 170 485 minecraft:bone_block
fill 235 171 481 246 171 481 minecraft:white_terracotta
fill 235 171 482 245 171 484 minecraft:bone_block
fill 235 171 485 245 171 485 minecraft:white_terracotta
fill 236 171 464 246 171 480 minecraft:soul_soil
fill 236 171 486 245 171 504 minecraft:soul_soil
fill 246 171 482 249 171 483 minecraft:bone_block
fill 246 171 484 246 171 488 minecraft:shroomlight
fill 246 171 489 249 171 504 minecraft:soul_soil
fill 247 171 464 249 171 476 minecraft:soul_soil
fill 247 171 477 247 171 481 minecraft:shroomlight
fill 247 171 484 250 171 484 minecraft:shroomlight
fill 247 171 485 249 171 487 minecraft:soul_soil
fill 247 171 488 250 171 488 minecraft:shroomlight
fill 248 171 477 251 171 477 minecraft:shroomlight
fill 248 171 478 250 171 480 minecraft:soul_soil
fill 248 171 481 254 171 481 minecraft:shroomlight
fill 250 171 464 276 171 464 minecraft:soul_soil
fill 250 171 465 250 171 476 minecraft:white_terracotta
fill 250 171 482 250 171 483 minecraft:shroomlight
fill 250 171 485 250 171 487 minecraft:shroomlight
fill 250 171 489 250 171 501 minecraft:white_terracotta
fill 250 171 502 276 171 504 minecraft:soul_soil
fill 251 171 465 253 171 476 minecraft:bone_block
fill 251 171 478 251 171 480 minecraft:shroomlight
fill 251 171 485 254 171 485 minecraft:shroomlight
fill 251 171 486 253 171 501 minecraft:bone_block
fill 252 171 477 253 171 480 minecraft:bone_block
fill 254 171 465 254 171 477 minecraft:white_terracotta
fill 254 171 478 254 171 480 minecraft:shroomlight
fill 254 171 482 254 171 484 minecraft:shroomlight
fill 254 171 486 254 171 488 minecraft:shroomlight
fill 254 171 489 254 171 501 minecraft:white_terracotta
fill 255 171 465 276 171 477 minecraft:soul_soil
fill 255 171 478 258 171 478 minecraft:shroomlight
fill 255 171 479 257 171 481 minecraft:soul_soil
fill 255 171 482 258 171 482 minecraft:shroomlight
fill 255 171 483 270 171 483 minecraft:bone_block
fill 255 171 484 258 171 484 minecraft:shroomlight
fill 255 171 485 257 171 487 minecraft:soul_soil
fill 255 171 488 258 171 488 minecraft:shroomlight
fill 255 171 489 276 171 501 minecraft:soul_soil
fill 258 171 479 258 171 481 minecraft:shroomlight
fill 258 171 485 258 171 487 minecraft:shroomlight
fill 259 171 478 276 171 480 minecraft:soul_soil
fill 259 171 481 270 171 481 minecraft:white_terracotta
fill 259 171 482 270 171 482 minecraft:bone_block
fill 259 171 484 270 171 484 minecraft:bone_block
fill 259 171 485 270 171 485 minecraft:white_terracotta
fill 259 171 486 276 171 488 minecraft:soul_soil
fill 271 171 481 276 171 485 minecraft:soul_soil
fill 235 172 481 235 205 485 minecraft:brown_terracotta
fill 250 172 482 250 172 484 minecraft:lime_stained_glass
fill 251 172 481 253 172 481 minecraft:lime_stained_glass
fill 251 172 485 253 172 485 minecraft:lime_stained_glass
fill 254 172 482 254 172 484 minecraft:lime_stained_glass
fill 241 173 481 249 173 485 minecraft:light_gray_concrete
fill 242 173 478 262 173 480 minecraft:light_gray_concrete
fill 242 173 486 262 173 488 minecraft:light_gray_concrete
fill 243 173 477 261 176 477 minecraft:light_gray_concrete
fill 243 173 489 261 176 489 minecraft:light_gray_concrete
fill 244 173 476 260 176 476 minecraft:light_gray_concrete
fill 244 173 490 260 176 490 minecraft:light_gray_concrete
fill 245 173 475 259 176 475 minecraft:light_gray_concrete
fill 245 173 491 259 176 491 minecraft:light_gray_concrete
fill 246 173 474 258 176 474 minecraft:light_gray_concrete
fill 246 173 492 258 176 492 minecraft:light_gray_concrete
fill 247 173 473 257 176 473 minecraft:light_gray_concrete
fill 247 173 493 257 176 493 minecraft:light_gray_concrete
fill 250 173 472 254 176 472 minecraft:light_gray_concrete
fill 250 173 481 250 173 482 minecraft:light_gray_concrete
fill 250 173 484 250 173 485 minecraft:light_gray_concrete
fill 250 173 494 254 176 494 minecraft:light_gray_concrete
setblock 251 173 481 minecraft:light_gray_concrete
setblock 251 173 485 minecraft:light_gray_concrete
fill 253 173 481 263 173 481 minecraft:light_gray_concrete
fill 253 173 485 263 173 485 minecraft:light_gray_concrete
fill 254 173 482 263 173 482 minecraft:light_gray_concrete
fill 254 173 484 263 173 484 minecraft:light_gray_concrete
fill 255 173 483 263 173 483 minecraft:light_gray_concrete
fill 239 174 479 239 175 487 minecraft:sea_lantern
fill 240 174 477 240 175 480 minecraft:sea_lantern
fill 240 174 481 248 174 485 minecraft:light_gray_concrete
fill 240 174 486 240 175 489 minecraft:sea_lantern
fill 241 174 475 241 175 477 minecraft:sea_lantern
fill 241 174 478 251 174 480 minecraft:light_gray_concrete
fill 241 174 486 251 174 488 minecraft:light_gray_concrete
fill 241 174 489 241 175 491 minecraft:sea_lantern
fill 242 174 474 242 175 475 minecraft:sea_lantern
fill 242 174 476 242 175 477 minecraft:light_gray_concrete
fill 242 174 489 242 175 490 minecraft:light_gray_concrete
fill 242 174 491 242 175 492 minecraft:sea_lantern
fill 243 174 473 243 175 474 minecraft:sea_lantern
fill 243 174 475 243 175 476 minecraft:light_gray_concrete
fill 243 174 490 243 175 491 minecraft:light_gray_concrete
fill 243 174 492 243 175 493 minecraft:sea_lantern
fill 244 174 472 244 175 473 minecraft:sea_lantern
fill 244 174 474 244 175 475 minecraft:light_gray_concrete
fill 244 174 491 244 175 492 minecraft:light_gray_concrete
fill 244 174 493 244 175 494 minecraft:sea_lantern
fill 245 174 472 246 175 472 minecraft:sea_lantern
fill 245 174 473 245 175 474 minecraft:light_gray_concrete
fill 245 174 492 245 175 493 minecraft:light_gray_concrete
fill 245 174 494 246 175 494 minecraft:sea_lantern
fill 246 174 471 249 175 471 minecraft:sea_lantern
fill 246 174 473 246 175 473 minecraft:light_gray_concrete
fill 246 174 493 246 175 493 minecraft:light_gray_concrete
fill 246 174 495 249 175 495 minecraft:sea_lantern
fill 247 174 472 249 175 472 minecraft:light_gray_concrete
fill 247 174 494 249 175 494 minecraft:light_gray_concrete
fill 248 174 470 256 175 470 minecraft:sea_lantern
fill 248 174 496 256 175 496 minecraft:sea_lantern
fill 249 174 481 249 174 482 minecraft:light_gray_concrete
fill 249 174 483 249 177 483 minecraft:light_blue_stained_glass
fill 249 174 484 249 174 485 minecraft:light_gray_concrete
fill 250 174 471 254 175 471 minecraft:light_gray_concrete
fill 250 174 481 250 176 481 minecraft:light_blue_stained_glass
fill 250 174 485 250 176 485 minecraft:light_blue_stained_glass
fill 250 174 495 254 175 495 minecraft:light_gray_concrete
fill 252 174 478 263 174 479 minecraft:light_gray_concrete
fill 252 174 480 252 177 480 minecraft:light_blue_stained_glass
fill 252 174 486 252 177 486 minecraft:light_blue_stained_glass
fill 252 174 487 263 174 488 minecraft:light_gray_concrete
fill 253 174 480 263 174 480 minecraft:light_gray_concrete
fill 253 174 486 263 174 486 minecraft:light_gray_concrete
fill 254 174 481 254 176 481 minecraft:light_blue_stained_glass
fill 254 174 485 254 176 485 minecraft:light_blue_stained_glass
fill 255 174 471 258 175 471 minecraft:sea_lantern
fill 255 174 472 257 175 472 minecraft:light_gray_concrete
fill 255 174 481 264 174 482 minecraft:light_gray_concrete
fill 255 174 483 255 177 483 minecraft:light_blue_stained_glass
fill 255 174 484 264 174 485 minecraft:light_gray_concrete
fill 255 174 494 257 175 494 minecraft:light_gray_concrete
fill 255 174 495 258 175 495 minecraft:sea_lantern
fill 256 174 483 264 174 483 minecraft:light_gray_concrete
fill 258 174 472 260 175 472 minecraft:sea_lantern
fill 258 174 473 259 175 473 minecraft:light_gray_concrete
fill 258 174 493 259 175 493 minecraft:light_gray_concrete
fill 258 174 494 260 175 494 minecraft:sea_lantern
fill 259 174 474 260 175 474 minecraft:light_gray_concrete
fill 259 174 492 260 175 492 minecraft:light_gray_concrete
fill 260 174 473 261 175 473 minecraft:sea_lantern
fill 260 174 475 261 175 475 minecraft:light_gray_concrete
fill 260 174 491 261 175 491 minecraft:light_gray_concrete
fill 260 174 493 261 175 493 minecraft:sea_lantern
fill 261 174 474 262 175 474 minecraft:sea_lantern
fill 261 174 476 262 175 476 minecraft:light_gray_concrete
fill 261 174 490 262 175 490 minecraft:light_gray_concrete
fill 261 174 492 262 175 492 minecraft:sea_lantern
fill 262 174 475 263 175 475 minecraft:sea_lantern
fill 262 174 477 262 175 477 minecraft:light_gray_concrete
fill 262 174 489 262 175 489 minecraft:light_gray_concrete
fill 262 174 491 263 175 491 minecraft:sea_lantern
fill 263 174 476 263 175 477 minecraft:sea_lantern
fill 263 174 489 263 175 490 minecraft:sea_lantern
fill 264 174 477 264 175 480 minecraft:sea_lantern
fill 264 174 486 264 175 489 minecraft:sea_lantern
fill 265 174 479 265 175 487 minecraft:sea_lantern
fill 236 175 467 236 175 470 minecraft:brown_terracotta
setblock 236 175 471 minecraft:bone_block
fill 236 175 472 236 176 474 minecraft:brown_terracotta
fill 240 175 464 242 175 464 minecraft:brown_terracotta
fill 240 175 481 247 175 485 minecraft:light_gray_concrete
setblock 241 175 465 minecraft:brown_terracotta
fill 241 175 478 248 175 480 minecraft:light_gray_concrete
fill 241 175 486 248 175 488 minecraft:light_gray_concrete
setblock 242 175 465 minecraft:bone_block
fill 242 175 466 245 175 466 minecraft:brown_terracotta
setblock 243 175 464 minecraft:bone_block
fill 243 175 465 246 175 465 minecraft:brown_terracotta
fill 244 175 464 247 175 464 minecraft:brown_terracotta
setblock 245 175 467 minecraft:bone_block
fill 245 175 504 247 175 504 minecraft:brown_terracotta
setblock 246 175 466 minecraft:bone_block
fill 246 175 467 247 175 467 minecraft:brown_terracotta
setblock 247 175 465 minecraft:bone_block
fill 247 175 466 250 175 466 minecraft:brown_terracotta
setblock 248 175 464 minecraft:bone_block
fill 248 175 465 251 175 465 minecraft:brown_terracotta
fill 248 175 481 248 179 485 minecraft:light_blue_stained_glass
setblock 248 175 504 minecraft:bone_block
fill 249 175 464 252 175 464 minecraft:brown_terracotta
fill 249 175 478 249 175 479 minecraft:light_gray_concrete
fill 249 175 480 249 178 482 minecraft:light_blue_stained_glass
fill 249 175 484 249 178 486 minecraft:light_blue_stained_glass
fill 249 175 487 249 175 488 minecraft:light_gray_concrete
fill 249 175 504 250 176 504 minecraft:brown_terracotta
fill 250 175 478 263 175 478 minecraft:light_gray_concrete
fill 250 175 479 251 178 480 minecraft:light_blue_stained_glass
fill 250 175 486 251 178 487 minecraft:light_blue_stained_glass
fill 250 175 488 263 175 488 minecraft:light_gray_concrete
setblock 252 175 465 minecraft:bone_block
fill 252 175 479 254 179 479 minecraft:light_blue_stained_glass
fill 252 175 487 254 179 487 minecraft:light_blue_stained_glass
setblock 253 175 464 minecraft:bone_block
fill 253 175 480 255 178 480 minecraft:light_blue_stained_glass
fill 253 175 486 255 178 486 minecraft:light_blue_stained_glass
setblock 254 175 464 minecraft:brown_terracotta
fill 255 175 479 263 175 479 minecraft:light_gray_concrete
fill 255 175 481 256 178 482 minecraft:light_blue_stained_glass
fill 255 175 484 256 178 485 minecraft:light_blue_stained_glass
fill 255 175 487 263 175 487 minecraft:light_gray_concrete
fill 256 175 480 263 175 480 minecraft:light_gray_concrete
fill 256 175 483 256 179 483 minecraft:light_blue_stained_glass
fill 256 175 486 263 175 486 minecraft:light_gray_concrete
fill 257 175 481 264 175 485 minecraft:light_gray_concrete
fill 261 175 464 262 175 464 minecraft:brown_terracotta
fill 261 175 504 262 175 504 minecraft:brown_terracotta
setblock 263 175 464 minecraft:bone_block
setblock 263 175 504 minecraft:bone_block
fill 264 175 464 267 175 464 minecraft:brown_terracotta
fill 264 175 504 267 175 504 minecraft:brown_terracotta
fill 265 175 490 267 176 490 minecraft:soul_soil
fill 266 175 489 266 176 489 minecraft:soul_soil
fill 266 175 491 266 176 491 minecraft:soul_soil
setblock 268 175 464 minecraft:bone_block
setblock 268 175 504 minecraft:bone_block
fill 275 175 489 275 175 491 minecraft:brown_terracotta
setblock 276 175 486 minecraft:bone_block
fill 276 175 487 276 175 490 minecraft:brown_terracotta
setblock 276 175 491 minecraft:bone_block
fill 276 175 492 276 176 494 minecraft:brown_terracotta
fill 236 176 467 236 176 469 minecraft:brown_terracotta
setblock 236 176 470 minecraft:bone_block
fill 236 176 471 237 178 471 minecraft:brown_terracotta
setblock 236 176 475 minecraft:bone_block
setblock 237 176 469 minecraft:bone_block
fill 237 176 470 237 179 470 minecraft:brown_terracotta
fill 237 176 472 237 177 472 minecraft:brown_terracotta
fill 240 176 464 241 176 464 minecraft:brown_terracotta
setblock 241 176 465 minecraft:bone_block
fill 241 176 481 246 176 485 minecraft:light_gray_concrete
setblock 242 176 464 minecraft:bone_block
fill 242 176 465 244 176 466 minecraft:brown_terracotta
fill 242 176 478 247 176 480 minecraft:light_gray_concrete
fill 242 176 486 247 176 488 minecraft:light_gray_concrete
fill 243 176 464 246 176 464 minecraft:brown_terracotta
fill 244 176 504 246 176 504 minecraft:brown_terracotta
setblock 245 176 465 minecraft:brown_terracotta
setblock 245 176 466 minecraft:bone_block
fill 245 176 467 246 176 467 minecraft:brown_terracotta
setblock 246 176 465 minecraft:bone_block
fill 246 176 466 249 176 466 minecraft:brown_terracotta
setblock 247 176 464 minecraft:bone_block
fill 247 176 465 250 176 465 minecraft:brown_terracotta
fill 247 176 481 247 178 485 minecraft:light_blue_stained_glass
setblock 247 176 504 minecraft:bone_block
fill 248 176 464 251 176 464 minecraft:brown_terracotta
fill 248 176 478 249 176 478 minecraft:light_gray_concrete
fill 248 176 479 248 178 480 minecraft:light_blue_stained_glass
fill 248 176 486 248 178 487 minecraft:light_blue_stained_glass
fill 248 176 488 249 176 488 minecraft:light_gray_concrete
fill 248 176 504 248 179 504 minecraft:brown_terracotta
fill 249 176 479 249 178 479 minecraft:light_blue_stained_glass
fill 249 176 487 249 178 487 minecraft:light_blue_stained_glass
fill 250 176 478 254 178 478 minecraft:light_blue_stained_glass
fill 250 176 488 254 178 488 minecraft:light_blue_stained_glass
setblock 251 176 465 minecraft:bone_block
setblock 252 176 464 minecraft:bone_block
setblock 253 176 464 minecraft:brown_terracotta
fill 255 176 478 262 176 478 minecraft:light_gray_concrete
fill 255 176 479 256 178 479 minecraft:light_blue_stained_glass
fill 255 176 487 256 178 487 minecraft:light_blue_stained_glass
fill 255 176 488 262 176 488 minecraft:light_gray_concrete
fill 256 176 480 256 178 480 minecraft:light_blue_stained_glass
fill 256 176 486 256 178 486 minecraft:light_blue_stained_glass
fill 257 176 479 262 176 480 minecraft:light_gray_concrete
fill 257 176 481 257 178 485 minecraft:light_blue_stained_glass
fill 257 176 486 262 176 487 minecraft:light_gray_concrete
fill 258 176 481 263 176 485 minecraft:light_gray_concrete
setblock 261 176 464 minecraft:brown_terracotta
setblock 261 176 504 minecraft:brown_terracotta
setblock 262 176 464 minecraft:bone_block
setblock 262 176 504 minecraft:bone_block
fill 263 176 464 266 176 464 minecraft:brown_terracotta
fill 263 176 488 263 177 489 minecraft:bone_block
fill 263 176 504 266 176 504 minecraft:brown_terracotta
setblock 267 176 464 minecraft:bone_block
setblock 267 176 504 minecraft:bone_block
setblock 268 176 504 minecraft:brown_terracotta
fill 276 176 486 276 176 489 minecraft:brown_terracotta
setblock 276 176 490 minecraft:bone_block
fill 276 176 491 276 179 491 minecraft:brown_terracotta
fill 236 177 467 236 177 468 minecraft:brown_terracotta
setblock 236 177 469 minecraft:bone_block
fill 236 177 470 236 180 470 minecraft:brown_terracotta
fill 236 177 472 236 177 473 minecraft:brown_terracotta
setblock 236 177 474 minecraft:bone_block
fill 236 177 475 236 178 477 minecraft:brown_terracotta
setblock 237 177 468 minecraft:bone_block
fill 237 177 469 237 180 469 minecraft:brown_terracotta
setblock 237 177 473 minecraft:bone_block
fill 237 177 474 237 180 474 minecraft:brown_terracotta
fill 239 177 464 240 177 464 minecraft:brown_terracotta
setblock 240 177 465 minecraft:bone_block
setblock 241 177 464 minecraft:bone_block
fill 241 177 465 244 177 465 minecraft:brown_terracotta
fill 242 177 464 245 177 464 minecraft:brown_terracotta
fill 242 177 466 243 177 466 minecraft:brown_terracotta
fill 243 177 504 245 177 504 minecraft:brown_terracotta
setblock 244 177 466 minecraft:bone_block
fill 244 177 467 245 178 467 minecraft:brown_terracotta
setblock 245 177 465 minecraft:bone_block
fill 245 177 466 248 177 466 minecraft:brown_terracotta
setblock 246 177 464 minecraft:bone_block
fill 246 177 465 249 177 465 minecraft:brown_terracotta
setblock 246 177 483 minecraft:light_blue_stained_glass
setblock 246 177 504 minecraft:bone_block
fill 247 177 464 250 177 464 minecraft:brown_terracotta
setblock 247 177 480 minecraft:light_blue_stained_glass
setblock 247 177 486 minecraft:light_blue_stained_glass
fill 247 177 504 247 180 504 minecraft:brown_terracotta
setblock 249 177 478 minecraft:light_blue_stained_glass
setblock 249 177 488 minecraft:light_blue_stained_glass
fill 249 177 504 249 178 504 minecraft:brown_terracotta
setblock 250 177 465 minecraft:bone_block
setblock 251 177 464 minecraft:bone_block
setblock 252 177 464 minecraft:brown_terracotta
setblock 252 177 477 minecraft:light_blue_stained_glass
setblock 252 177 489 minecraft:light_blue_stained_glass
setblock 255 177 478 minecraft:light_blue_stained_glass
setblock 255 177 488 minecraft:light_blue_stained_glass
setblock 257 177 480 minecraft:light_blue_stained_glass
setblock 257 177 486 minecraft:light_blue_stained_glass
setblock 258 177 483 minecraft:light_blue_stained_glass
setblock 260 177 504 minecraft:brown_terracotta
setblock 261 177 464 minecraft:bone_block
setblock 261 177 504 minecraft:bone_block
fill 262 177 464 265 177 464 minecraft:brown_terracotta
fill 262 177 504 265 177 504 minecraft:brown_terracotta
setblock 266 177 464 minecraft:bone_block
setblock 266 177 504 minecraft:bone_block
fill 267 177 504 267 180 504 minecraft:brown_terracotta
fill 275 177 491 275 180 491 minecraft:brown_terracotta
fill 276 177 470 276 177 473 minecraft:brown_terracotta
setblock 276 177 474 minecraft:bone_block
fill 276 177 486 276 177 488 minecraft:brown_terracotta
setblock 276 177 489 minecraft:bone_block
fill 276 177 490 276 180 490 minecraft:brown_terracotta
fill 276 177 492 276 177 493 minecraft:brown_terracotta
setblock 276 177 494 minecraft:bone_block
fill 276 177 495 276 180 495 minecraft:brown_terracotta
fill 236 178 466 236 178 467 minecraft:brown_terracotta
setblock 236 178 468 minecraft:bone_block
fill 236 178 469 236 181 469 minecraft:brown_terracotta
setblock 236 178 472 minecraft:brown_terracotta
setblock 236 178 473 minecraft:bone_block
fill 236 178 474 236 181 474 minecraft:brown_terracotta
setblock 236 178 478 minecraft:bone_block
fill 237 178 468 237 181 468 minecraft:brown_terracotta
setblock 237 178 472 minecraft:bone_block
fill 237 178 473 238 180 473 minecraft:brown_terracotta
fill 237 178 475 237 178 476 minecraft:brown_terracotta
fill 238 178 464 239 178 464 minecraft:brown_terracotta
setblock 238 178 470 minecraft:brown_terracotta
setblock 238 178 471 minecraft:bone_block
fill 238 178 472 238 181 472 minecraft:brown_terracotta
setblock 240 178 464 minecraft:bone_block
fill 240 178 465 243 178 465 minecraft:brown_terracotta
fill 241 178 464 244 178 464 minecraft:brown_terracotta
fill 241 178 466 242 178 466 minecraft:brown_terracotta
fill 242 178 504 244 178 504 minecraft:brown_terracotta
setblock 243 178 466 minecraft:bone_block
setblock 244 178 465 minecraft:bone_block
fill 244 178 466 247 178 466 minecraft:brown_terracotta
setblock 245 178 464 minecraft:bone_block
fill 245 178 465 248 178 465 minecraft:brown_terracotta
setblock 245 178 504 minecraft:bone_block
fill 246 178 464 249 178 464 minecraft:brown_terracotta
fill 246 178 504 246 181 504 minecraft:brown_terracotta
setblock 249 178 465 minecraft:bone_block
setblock 250 178 464 minecraft:bone_block
setblock 250 178 504 minecraft:bone_block
fill 251 178 464 251 180 464 minecraft:brown_terracotta
setblock 259 178 504 minecraft:brown_terracotta
setblock 260 178 464 minecraft:bone_block
setblock 260 178 504 minecraft:bone_block
fill 261 178 464 264 178 464 minecraft:brown_terracotta
fill 261 178 504 264 178 504 minecraft:brown_terracotta
fill 262 178 503 264 179 503 minecraft:brown_terracotta
setblock 265 178 464 minecraft:bone_block
setblock 265 178 504 minecraft:bone_block
setblock 266 178 464 minecraft:brown_terracotta
fill 266 178 504 266 181 504 minecraft:brown_terracotta
fill 275 178 492 276 178 492 minecraft:brown_terracotta
fill 276 178 469 276 178 472 minecraft:brown_terracotta
setblock 276 178 473 minecraft:bone_block
fill 276 178 474 276 178 477 minecraft:brown_terracotta
fill 276 178 486 276 178 487 minecraft:brown_terracotta
setblock 276 178 488 minecraft:bone_block
fill 276 178 489 276 181 489 minecraft:brown_terracotta
setblock 276 178 493 minecraft:bone_block
fill 276 178 494 276 181 494 minecraft:brown_terracotta
fill 276 178 496 276 179 496 minecraft:brown_terracotta
setblock 236 179 466 minecraft:brown_terracotta
setblock 236 179 467 minecraft:bone_block
fill 236 179 468 236 182 468 minecraft:brown_terracotta
setblock 236 179 471 minecraft:brown_terracotta
setblock 236 179 472 minecraft:bone_block
fill 236 179 473 236 182 473 minecraft:brown_terracotta
fill 236 179 475 236 179 476 minecraft:brown_terracotta
setblock 236 179 477 minecraft:bone_block
fill 236 179 478 236 180 480 minecraft:brown_terracotta
setblock 236 179 491 minecraft:brown_terracotta
setblock 236 179 492 minecraft:bone_block
fill 236 179 493 236 181 494 minecraft:brown_terracotta
fill 237 179 467 237 182 467 minecraft:brown_terracotta
setblock 237 179 471 minecraft:bone_block
fill 237 179 472 237 182 472 minecraft:brown_terracotta
setblock 237 179 475 minecraft:brown_terracotta
setblock 237 179 476 minecraft:bone_block
fill 237 179 477 237 182 477 minecraft:brown_terracotta
setblock 238 179 464 minecraft:brown_terracotta
setblock 238 179 466 minecraft:light[level=12]
setblock 238 179 469 minecraft:brown_terracotta
setblock 238 179 470 minecraft:bone_block
fill 238 179 471 239 181 471 minecraft:brown_terracotta
setblock 238 179 474 minecraft:brown_terracotta
setblock 238 179 475 minecraft:bone_block
setblock 238 179 482 minecraft:light[level=12]
setblock 238 179 490 minecraft:light[level=12]
setblock 238 179 498 minecraft:light[level=12]
setblock 239 179 464 minecraft:bone_block
fill 239 179 465 242 179 465 minecraft:brown_terracotta
fill 239 179 472 239 179 473 minecraft:brown_terracotta
fill 240 179 464 243 179 464 minecraft:brown_terracotta
setblock 241 179 466 minecraft:brown_terracotta
fill 241 179 504 243 179 504 minecraft:brown_terracotta
setblock 242 179 466 minecraft:bone_block
setblock 243 179 465 minecraft:bone_block
fill 243 179 466 244 180 467 minecraft:brown_terracotta
setblock 244 179 464 minecraft:bone_block
fill 244 179 465 247 179 465 minecraft:brown_terracotta
setblock 244 179 504 minecraft:bone_block
fill 245 179 464 248 179 464 minecraft:brown_terracotta
fill 245 179 466 246 179 466 minecraft:brown_terracotta
fill 245 179 504 245 182 504 minecraft:brown_terracotta
setblock 246 179 474 minecraft:light[level=12]
setblock 246 179 482 minecraft:light[level=12]
setblock 246 179 490 minecraft:light[level=12]
setblock 246 179 498 minecraft:light[level=12]
setblock 247 179 466 minecraft:bone_block
setblock 248 179 465 minecraft:bone_block
setblock 249 179 464 minecraft:bone_block
setblock 249 179 465 minecraft:brown_terracotta
fill 249 179 480 249 179 481 minecraft:light_blue_stained_glass
fill 249 179 485 249 179 486 minecraft:light_blue_stained_glass
setblock 249 179 504 minecraft:bone_block
fill 250 179 464 250 181 464 minecraft:brown_terracotta
fill 250 179 479 250 179 480 minecraft:light_blue_stained_glass
fill 250 179 486 250 179 487 minecraft:light_blue_stained_glass
fill 250 179 504 250 182 504 minecraft:brown_terracotta
setblock 251 179 479 minecraft:light_blue_stained_glass
setblock 251 179 487 minecraft:light_blue_stained_glass
setblock 254 179 466 minecraft:light[level=12]
setblock 254 179 474 minecraft:light[level=12]
fill 254 179 480 255 179 480 minecraft:light_blue_stained_glass
fill 254 179 486 255 179 486 minecraft:light_blue_stained_glass
setblock 254 179 490 minecraft:light[level=12]
setblock 254 179 498 minecraft:light[level=12]
fill 255 179 481 256 179 481 minecraft:light_blue_stained_glass
fill 255 179 485 256 179 485 minecraft:light_blue_stained_glass
setblock 256 179 482 minecraft:light_blue_stained_glass
setblock 256 179 484 minecraft:light_blue_stained_glass
fill 257 179 504 258 179 504 minecraft:brown_terracotta
setblock 259 179 504 minecraft:bone_block
fill 260 179 464 263 179 464 minecraft:brown_terracotta
setblock 260 179 503 minecraft:bone_block
fill 260 179 504 263 179 504 minecraft:brown_terracotta
fill 261 179 503 261 182 503 minecraft:brown_terracotta
setblock 262 179 466 minecraft:light[level=12]
setblock 262 179 474 minecraft:light[level=12]
setblock 262 179 482 minecraft:light[level=12]
setblock 262 179 490 minecraft:light[level=12]
setblock 262 179 498 minecraft:light[level=12]
setblock 264 179 464 minecraft:bone_block
setblock 264 179 504 minecraft:bone_block
fill 265 179 464 265 180 464 minecraft:brown_terracotta
setblock 265 179 503 minecraft:bone_block
fill 265 179 504 265 182 504 minecraft:brown_terracotta
setblock 270 179 466 minecraft:light[level=12]
setblock 270 179 474 minecraft:light[level=12]
setblock 270 179 482 minecraft:light[level=12]
setblock 270 179 490 minecraft:light[level=12]
setblock 270 179 498 minecraft:light[level=12]
setblock 275 179 492 minecraft:brown_terracotta
setblock 275 179 493 minecraft:bone_block
fill 275 179 494 275 182 494 minecraft:brown_terracotta
fill 276 179 469 276 179 471 minecraft:brown_terracotta
setblock 276 179 472 minecraft:bone_block
fill 276 179 473 276 179 476 minecraft:brown_terracotta
setblock 276 179 477 minecraft:bone_block
fill 276 179 478 276 180 480 minecraft:brown_terracotta
fill 276 179 485 276 179 486 minecraft:brown_terracotta
setblock 276 179 487 minecraft:bone_block
fill 276 179 488 276 182 488 minecraft:brown_terracotta
setblock 276 179 492 minecraft:bone_block
fill 276 179 493 276 182 493 minecraft:brown_terracotta
setblock 276 179 497 minecraft:bone_block
setblock 236 180 465 minecraft:brown_terracotta
setblock 236 180 466 minecraft:bone_block
fill 236 180 467 236 183 467 minecraft:brown_terracotta
setblock 236 180 471 minecraft:bone_block
fill 236 180 472 236 183 472 minecraft:brown_terracotta
setblock 236 180 475 minecraft:brown_terracotta
setblock 236 180 476 minecraft:bone_block
fill 236 180 477 236 183 477 minecraft:brown_terracotta
setblock 236 180 481 minecraft:bone_block
setblock 236 180 490 minecraft:brown_terracotta
setblock 236 180 491 minecraft:bone_block
fill 236 180 492 236 183 492 minecraft:brown_terracotta
setblock 236 180 495 minecraft:brown_terracotta
setblock 236 180 496 minecraft:bone_block
fill 236 180 497 236 183 497 minecraft:brown_terracotta
setblock 237 180 464 minecraft:brown_terracotta
setblock 237 180 470 minecraft:bone_block
fill 237 180 471 237 183 471 minecraft:brown_terracotta
setblock 237 180 475 minecraft:bone_block
fill 237 180 476 238 182 476 minecraft:brown_terracotta
fill 237 180 478 237 180 479 minecraft:brown_terracotta
setblock 238 180 464 minecraft:bone_block
setblock 238 180 468 minecraft:brown_terracotta
setblock 238 180 469 minecraft:bone_block
fill 238 180 470 239 182 470 minecraft:brown_terracotta
setblock 238 180 474 minecraft:bone_block
fill 238 180 475 239 182 475 minecraft:brown_terracotta
fill 238 180 477 238 181 477 minecraft:brown_terracotta
fill 239 180 464 241 180 465 minecraft:brown_terracotta
setblock 239 180 472 minecraft:brown_terracotta
setblock 239 180 473 minecraft:bone_block
fill 239 180 474 239 183 474 minecraft:brown_terracotta
setblock 240 180 466 minecraft:brown_terracotta
fill 240 180 504 242 180 504 minecraft:brown_terracotta
setblock 241 180 466 minecraft:bone_block
setblock 242 180 464 minecraft:brown_terracotta
setblock 242 180 465 minecraft:bone_block
fill 242 180 466 242 180 467 minecraft:brown_terracotta
fill 242 180 503 243 180 503 minecraft:brown_terracotta
setblock 243 180 464 minecraft:bone_block
fill 243 180 465 246 180 465 minecraft:brown_terracotta
setblock 243 180 504 minecraft:bone_block
fill 244 180 464 247 180 464 minecraft:brown_terracotta
setblock 244 180 503 minecraft:bone_block
fill 244 180 504 244 183 504 minecraft:brown_terracotta
setblock 245 180 466 minecraft:brown_terracotta
fill 245 180 503 247 181 503 minecraft:brown_terracotta
setblock 246 180 466 minecraft:bone_block
setblock 247 180 465 minecraft:bone_block
setblock 248 180 464 minecraft:bone_block
fill 248 180 465 248 181 465 minecraft:brown_terracotta
setblock 248 180 504 minecraft:bone_block
fill 249 180 464 249 183 464 minecraft:brown_terracotta
fill 249 180 504 249 183 504 minecraft:brown_terracotta
fill 251 180 504 251 181 504 minecraft:brown_terracotta
fill 255 180 504 257 180 504 minecraft:brown_terracotta
setblock 258 180 504 minecraft:bone_block
fill 259 180 464 262 180 464 minecraft:brown_terracotta
setblock 259 180 503 minecraft:bone_block
fill 259 180 504 262 180 504 minecraft:brown_terracotta
fill 260 180 503 260 183 503 minecraft:brown_terracotta
fill 262 180 465 262 188 465 minecraft:soul_soil
fill 262 180 502 263 180 503 minecraft:brown_terracotta
setblock 263 180 464 minecraft:bone_block
setblock 263 180 504 minecraft:bone_block
fill 264 180 464 264 182 464 minecraft:brown_terracotta
setblock 264 180 503 minecraft:bone_block
fill 264 180 504 264 183 504 minecraft:brown_terracotta
fill 265 180 503 265 183 503 minecraft:brown_terracotta
setblock 275 180 472 minecraft:bone_block
fill 275 180 473 275 180 476 minecraft:brown_terracotta
setblock 275 180 477 minecraft:bone_block
setblock 275 180 492 minecraft:bone_block
fill 275 180 493 275 183 493 minecraft:brown_terracotta
fill 275 180 495 275 181 495 minecraft:brown_terracotta
fill 276 180 468 276 180 470 minecraft:brown_terracotta
setblock 276 180 471 minecraft:bone_block
fill 276 180 472 276 180 475 minecraft:brown_terracotta
setblock 276 180 476 minecraft:bone_block
fill 276 180 477 276 183 477 minecraft:brown_terracotta
setblock 276 180 481 minecraft:bone_block
fill 276 180 482 276 180 485 minecraft:brown_terracotta
setblock 276 180 486 minecraft:bone_block
fill 276 180 487 276 183 487 minecraft:brown_terracotta
setblock 276 180 491 minecraft:bone_block
fill 276 180 492 276 183 492 minecraft:brown_terracotta
setblock 276 180 496 minecraft:bone_block
fill 276 180 497 276 182 498 minecraft:brown_terracotta
setblock 236 181 464 minecraft:brown_terracotta
setblock 236 181 465 minecraft:bone_block
fill 236 181 466 237 183 466 minecraft:brown_terracotta
setblock 236 181 470 minecraft:bone_block
fill 236 181 471 236 184 471 minecraft:brown_terracotta
setblock 236 181 475 minecraft:bone_block
fill 236 181 476 236 184 476 minecraft:brown_terracotta
fill 236 181 478 236 181 479 minecraft:brown_terracotta
setblock 236 181 480 minecraft:bone_block
fill 236 181 481 236 183 482 minecraft:brown_terracotta
setblock 236 181 490 minecraft:bone_block
fill 236 181 491 236 183 491 minecraft:brown_terracotta
setblock 236 181 495 minecraft:bone_block
fill 236 181 496 236 184 496 minecraft:brown_terracotta
fill 236 181 498 236 181 499 minecraft:brown_terracotta
setblock 237 181 464 minecraft:bone_block
setblock 237 181 469 minecraft:bone_block
fill 237 181 470 237 184 470 minecraft:brown_terracotta
setblock 237 181 473 minecraft:brown_terracotta
setblock 237 181 474 minecraft:bone_block
fill 237 181 475 237 184 475 minecraft:brown_terracotta
setblock 237 181 478 minecraft:brown_terracotta
setblock 237 181 479 minecraft:bone_block
fill 237 181 480 237 184 480 minecraft:brown_terracotta
fill 238 181 464 240 181 465 minecraft:brown_terracotta
setblock 238 181 468 minecraft:bone_block
fill 238 181 469 239 181 469 minecraft:brown_terracotta
setblock 238 181 473 minecraft:bone_block
fill 238 181 474 238 184 474 minecraft:brown_terracotta
setblock 238 181 478 minecraft:bone_block
setblock 239 181 472 minecraft:bone_block
fill 239 181 473 239 184 473 minecraft:brown_terracotta
setblock 239 181 476 minecraft:brown_terracotta
fill 239 181 504 241 181 504 minecraft:brown_terracotta
setblock 240 181 466 minecraft:bone_block
setblock 241 181 464 minecraft:brown_terracotta
setblock 241 181 465 minecraft:bone_block
fill 241 181 466 244 181 466 minecraft:brown_terracotta
fill 241 181 503 242 181 503 minecraft:brown_terracotta
setblock 242 181 464 minecraft:bone_block
fill 242 181 465 245 181 465 minecraft:brown_terracotta
setblock 242 181 504 minecraft:bone_block
fill 243 181 464 246 181 464 minecraft:brown_terracotta
setblock 243 181 503 minecraft:bone_block
fill 243 181 504 243 184 504 minecraft:brown_terracotta
fill 244 181 503 244 184 503 minecraft:brown_terracotta
setblock 245 181 466 minecraft:bone_block
setblock 246 181 465 minecraft:bone_block
setblock 246 181 466 minecraft:brown_terracotta
setblock 247 181 464 minecraft:bone_block
fill 247 181 465 247 182 465 minecraft:brown_terracotta
setblock 247 181 504 minecraft:bone_block
fill 248 181 464 248 184 464 minecraft:brown_terracotta
setblock 248 181 503 minecraft:bone_block
fill 248 181 504 248 184 504 minecraft:brown_terracotta
setblock 252 181 504 minecraft:bone_block
fill 253 181 504 256 181 504 minecraft:brown_terracotta
setblock 257 181 503 minecraft:brown_terracotta
setblock 257 181 504 minecraft:bone_block
fill 258 181 464 261 181 464 minecraft:brown_terracotta
setblock 258 181 503 minecraft:bone_block
fill 258 181 504 261 181 504 minecraft:brown_terracotta
setblock 259 181 502 minecraft:bone_block
fill 259 181 503 259 184 503 minecraft:brown_terracotta
fill 260 181 502 263 181 502 minecraft:brown_terracotta
setblock 262 181 464 minecraft:bone_block
setblock 262 181 503 minecraft:brown_terracotta
setblock 262 181 504 minecraft:bone_block
fill 263 181 464 263 183 464 minecraft:brown_terracotta
setblock 263 181 503 minecraft:bone_block
fill 263 181 504 263 184 504 minecraft:brown_terracotta
setblock 264 181 502 minecraft:bone_block
fill 264 181 503 264 184 503 minecraft:brown_terracotta
setblock 266 181 503 minecraft:brown_terracotta
setblock 267 181 504 minecraft:bone_block
setblock 275 181 471 minecraft:bone_block
fill 275 181 472 275 181 475 minecraft:brown_terracotta
setblock 275 181 476 minecraft:bone_block
fill 275 181 477 275 182 479 minecraft:brown_terracotta
setblock 275 181 491 minecraft:bone_block
fill 275 181 492 275 182 492 minecraft:brown_terracotta
setblock 275 181 496 minecraft:bone_block
fill 276 181 468 276 181 469 minecraft:brown_terracotta
setblock 276 181 470 minecraft:bone_block
fill 276 181 471 276 181 474 minecraft:brown_terracotta
setblock 276 181 475 minecraft:bone_block
fill 276 181 476 276 184 476 minecraft:brown_terracotta
fill 276 181 478 276 181 479 minecraft:brown_terracotta
setblock 276 181 480 minecraft:bone_block
fill 276 181 481 276 181 484 minecraft:brown_terracotta
setblock 276 181 485 minecraft:bone_block
fill 276 181 486 276 184 486 minecraft:brown_terracotta
setblock 276 181 490 minecraft:bone_block
fill 276 181 491 276 184 491 minecraft:brown_terracotta
setblock 276 181 495 minecraft:bone_block
fill 276 181 496 276 184 496 minecraft:brown_terracotta
setblock 276 181 499 minecraft:brown_terracotta
setblock 236 182 464 minecraft:bone_block
fill 236 182 465 236 185 465 minecraft:brown_terracotta
setblock 236 182 469 minecraft:bone_block
fill 236 182 470 236 185 470 minecraft:brown_terracotta
setblock 236 182 474 minecraft:bone_block
fill 236 182 475 236 185 475 minecraft:brown_terracotta
setblock 236 182 478 minecraft:brown_terracotta
setblock 236 182 479 minecraft:bone_block
fill 236 182 480 236 185 480 minecraft:brown_terracotta
setblock 236 182 483 minecraft:brown_terracotta
setblock 236 182 493 minecraft:brown_terracotta
setblock 236 182 494 minecraft:bone_block
fill 236 182 495 237 184 495 minecraft:brown_terracotta
setblock 236 182 498 minecraft:brown_terracotta
setblock 236 182 499 minecraft:bone_block
fill 236 182 500 236 184 501 minecraft:brown_terracotta
fill 237 182 464 240 182 464 minecraft:brown_terracotta
setblock 237 182 468 minecraft:bone_block
fill 237 182 469 238 184 469 minecraft:brown_terracotta
setblock 237 182 473 minecraft:bone_block
fill 237 182 474 237 185 474 minecraft:brown_terracotta
setblock 237 182 478 minecraft:bone_block
fill 237 182 479 238 184 479 minecraft:brown_terracotta
fill 237 182 481 237 183 481 minecraft:brown_terracotta
fill 237 182 494 237 183 494 minecraft:brown_terracotta
fill 237 182 496 237 182 497 minecraft:brown_terracotta
setblock 237 182 498 minecraft:bone_block
fill 238 182 465 239 182 465 minecraft:brown_terracotta
fill 238 182 468 238 184 468 minecraft:brown_terracotta
setblock 238 182 471 minecraft:brown_terracotta
setblock 238 182 472 minecraft:bone_block
fill 238 182 473 238 185 473 minecraft:brown_terracotta
setblock 238 182 477 minecraft:bone_block
fill 238 182 478 238 185 478 minecraft:brown_terracotta
fill 238 182 504 240 182 504 minecraft:brown_terracotta
setblock 239 182 466 minecraft:bone_block
setblock 239 182 471 minecraft:bone_block
fill 239 182 472 239 184 472 minecraft:brown_terracotta
setblock 239 182 476 minecraft:bone_block
fill 239 182 477 239 185 477 minecraft:brown_terracotta
setblock 240 182 465 minecraft:bone_block
fill 240 182 466 243 182 466 minecraft:brown_terracotta
fill 240 182 503 241 182 503 minecraft:brown_terracotta
setblock 241 182 464 minecraft:bone_block
fill 241 182 465 244 182 465 minecraft:brown_terracotta
setblock 241 182 504 minecraft:bone_block
fill 242 182 464 245 182 464 minecraft:brown_terracotta
setblock 242 182 503 minecraft:bone_block
fill 242 182 504 242 185 504 minecraft:brown_terracotta
setblock 243 182 502 minecraft:bone_block
fill 243 182 503 243 185 503 minecraft:brown_terracotta
setblock 244 182 466 minecraft:bone_block
fill 244 182 502 244 185 502 minecraft:brown_terracotta
setblock 245 182 465 minecraft:bone_block
setblock 245 182 466 minecraft:brown_terracotta
fill 245 182 503 246 182 503 minecraft:brown_terracotta
setblock 246 182 464 minecraft:bone_block
fill 246 182 465 246 183 465 minecraft:brown_terracotta
setblock 246 182 504 minecraft:bone_block
fill 247 182 464 247 185 464 minecraft:brown_terracotta
fill 247 182 499 247 183 500 minecraft:bone_block
setblock 247 182 503 minecraft:bone_block
fill 247 182 504 247 185 504 minecraft:brown_terracotta
fill 248 182 503 248 185 503 minecraft:brown_terracotta
setblock 251 182 504 minecraft:bone_block
fill 252 182 504 255 182 504 minecraft:brown_terracotta
setblock 256 182 503 minecraft:brown_terracotta
setblock 256 182 504 minecraft:bone_block
setblock 257 182 503 minecraft:bone_block
fill 257 182 504 260 182 504 minecraft:brown_terracotta
fill 258 182 464 260 182 464 minecraft:brown_terracotta
setblock 258 182 502 minecraft:bone_block
fill 258 182 503 258 185 503 minecraft:brown_terracotta
fill 259 182 502 262 182 502 minecraft:brown_terracotta
setblock 261 182 464 minecraft:bone_block
fill 261 182 501 262 183 501 minecraft:brown_terracotta
setblock 261 182 504 minecraft:bone_block
fill 262 182 464 262 184 464 minecraft:brown_terracotta
setblock 262 182 503 minecraft:bone_block
fill 262 182 504 262 185 504 minecraft:brown_terracotta
setblock 263 182 502 minecraft:bone_block
fill 263 182 503 263 185 503 minecraft:brown_terracotta
fill 264 182 502 264 184 502 minecraft:brown_terracotta
setblock 266 182 504 minecraft:bone_block
setblock 267 182 504 minecraft:brown_terracotta
fill 275 182 471 275 182 474 minecraft:brown_terracotta
setblock 275 182 475 minecraft:bone_block
fill 275 182 476 275 185 476 minecraft:brown_terracotta
setblock 275 182 480 minecraft:bone_block
fill 275 182 481 276 184 481 minecraft:brown_terracotta
setblock 275 182 495 minecraft:bone_block
fill 275 182 496 275 184 496 minecraft:brown_terracotta
setblock 276 182 468 minecraft:brown_terracotta
setblock 276 182 469 minecraft:bone_block
fill 276 182 470 276 182 473 minecraft:brown_terracotta
setblock 276 182 474 minecraft:bone_block
fill 276 182 475 276 185 475 minecraft:brown_terracotta
setblock 276 182 478 minecraft:brown_terracotta
setblock 276 182 479 minecraft:bone_block
fill 276 182 480 276 185 480 minecraft:brown_terracotta
fill 276 182 482 276 182 483 minecraft:brown_terracotta
setblock 276 182 484 minecraft:bone_block
fill 276 182 485 276 185 485 minecraft:brown_terracotta
setblock 276 182 489 minecraft:bone_block
fill 276 182 490 276 185 490 minecraft:brown_terracotta
setblock 276 182 494 minecraft:bone_block
fill 276 182 495 276 185 495 minecraft:brown_terracotta
setblock 276 182 499 minecraft:bone_block
fill 276 182 500 276 185 500 minecraft:brown_terracotta
fill 236 183 464 239 183 464 minecraft:brown_terracotta
setblock 236 183 468 minecraft:bone_block
fill 236 183 469 236 186 469 minecraft:brown_terracotta
setblock 236 183 473 minecraft:bone_block
fill 236 183 474 236 186 474 minecraft:brown_terracotta
setblock 236 183 478 minecraft:bone_block
fill 236 183 479 236 186 479 minecraft:brown_terracotta
setblock 236 183 483 minecraft:bone_block
setblock 236 183 493 minecraft:bone_block
fill 236 183 494 236 186 494 minecraft:brown_terracotta
setblock 236 183 498 minecraft:bone_block
fill 236 183 499 237 185 499 minecraft:brown_terracotta
setblock 236 183 502 minecraft:brown_terracotta
setblock 236 183 503 minecraft:bone_block
fill 237 183 465 238 183 465 minecraft:brown_terracotta
setblock 237 183 467 minecraft:bone_block
fill 237 183 468 237 186 468 minecraft:brown_terracotta
setblock 237 183 472 minecraft:bone_block
fill 237 183 473 237 186 473 minecraft:brown_terracotta
setblock 237 183 476 minecraft:brown_terracotta
setblock 237 183 477 minecraft:bone_block
fill 237 183 478 237 186 478 minecraft:brown_terracotta
setblock 237 183 496 minecraft:brown_terracotta
setblock 237 183 497 minecraft:bone_block
fill 237 183 498 237 186 498 minecraft:brown_terracotta
fill 237 183 500 237 184 500 minecraft:brown_terracotta
fill 237 183 504 239 183 504 minecraft:brown_terracotta
setblock 238 183 470 minecraft:brown_terracotta
setblock 238 183 471 minecraft:bone_block
fill 238 183 472 238 186 472 minecraft:brown_terracotta
setblock 238 183 475 minecraft:brown_terracotta
setblock 238 183 476 minecraft:bone_block
fill 238 183 477 238 186 477 minecraft:brown_terracotta
setblock 239 183 465 minecraft:bone_block
fill 239 183 466 242 183 466 minecraft:brown_terracotta
setblock 239 183 470 minecraft:bone_block
fill 239 183 471 239 184 471 minecraft:brown_terracotta
setblock 239 183 475 minecraft:bone_block
fill 239 183 476 239 185 476 minecraft:brown_terracotta
fill 239 183 503 240 183 503 minecraft:brown_terracotta
setblock 240 183 464 minecraft:bone_block
fill 240 183 465 243 183 465 minecraft:brown_terracotta
setblock 240 183 504 minecraft:bone_block
fill 241 183 464 244 183 464 minecraft:brown_terracotta
setblock 241 183 502 minecraft:brown_terracotta
setblock 241 183 503 minecraft:bone_block
fill 241 183 504 241 186 504 minecraft:brown_terracotta
setblock 242 183 502 minecraft:bone_block
fill 242 183 503 242 186 503 minecraft:brown_terracotta
setblock 243 183 466 minecraft:bone_block
fill 243 183 502 243 186 502 minecraft:brown_terracotta
setblock 244 183 465 minecraft:bone_block
setblock 245 183 464 minecraft:bone_block
fill 245 183 465 245 184 465 minecraft:brown_terracotta
fill 245 183 502 245 183 503 minecraft:brown_terracotta
setblock 245 183 504 minecraft:bone_block
fill 246 183 464 246 186 464 minecraft:brown_terracotta
setblock 246 183 503 minecraft:bone_block
fill 246 183 504 246 186 504 minecraft:brown_terracotta
fill 247 183 503 247 186 503 minecraft:brown_terracotta
setblock 250 183 504 minecraft:bone_block
fill 251 183 504 254 183 504 minecraft:brown_terracotta
fill 254 183 503 255 183 503 minecraft:brown_terracotta
setblock 255 183 504 minecraft:bone_block
setblock 256 183 503 minecraft:bone_block
fill 256 183 504 259 183 504 minecraft:brown_terracotta
setblock 257 183 502 minecraft:bone_block
fill 257 183 503 257 186 503 minecraft:brown_terracotta
fill 258 183 464 259 183 464 minecraft:brown_terracotta
fill 258 183 502 261 183 502 minecraft:brown_terracotta
fill 259 183 501 260 185 501 minecraft:brown_terracotta
setblock 260 183 464 minecraft:bone_block
setblock 260 183 504 minecraft:bone_block
fill 261 183 464 261 184 464 minecraft:brown_terracotta
setblock 261 183 503 minecraft:bone_block
fill 261 183 504 261 186 504 minecraft:brown_terracotta
setblock 262 183 502 minecraft:bone_block
fill 262 183 503 262 186 503 minecraft:brown_terracotta
fill 263 183 502 263 185 502 minecraft:brown_terracotta
setblock 265 183 504 minecraft:bone_block
fill 266 183 504 266 184 504 minecraft:brown_terracotta
setblock 274 183 475 minecraft:bone_block
fill 274 183 476 274 185 477 minecraft:brown_terracotta
fill 275 183 471 275 183 473 minecraft:brown_terracotta
setblock 275 183 474 minecraft:bone_block
fill 275 183 475 275 186 475 minecraft:brown_terracotta
fill 275 183 477 275 183 478 minecraft:brown_terracotta
setblock 275 183 479 minecraft:bone_block
fill 275 183 480 275 186 480 minecraft:brown_terracotta
fill 275 183 482 276 183 482 minecraft:brown_terracotta
setblock 275 183 494 minecraft:bone_block
setblock 275 183 495 minecraft:brown_terracotta
fill 275 183 497 276 183 497 minecraft:brown_terracotta
setblock 276 183 468 minecraft:bone_block
fill 276 183 469 276 183 472 minecraft:brown_terracotta
setblock 276 183 473 minecraft:bone_block
fill 276 183 474 276 186 474 minecraft:brown_terracotta
schedule function dropper:buildpart/113_6 1t
