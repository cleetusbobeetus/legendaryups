setblock 188 143 301 minecraft:dark_prismarine
setblock 188 143 308 minecraft:dark_prismarine
setblock 191 143 286 minecraft:light[level=15]
setblock 191 143 294 minecraft:light[level=15]
setblock 191 143 302 minecraft:light[level=15]
setblock 191 143 310 minecraft:light[level=15]
setblock 196 143 275 minecraft:dark_prismarine
fill 197 143 292 197 144 293 minecraft:white_stained_glass
setblock 199 143 278 minecraft:light[level=15]
setblock 199 143 286 minecraft:light[level=15]
setblock 199 143 294 minecraft:light[level=15]
setblock 199 143 302 minecraft:light[level=15]
setblock 199 143 310 minecraft:light[level=15]
setblock 200 143 275 minecraft:dark_prismarine
setblock 202 143 275 minecraft:dark_prismarine
fill 204 143 275 204 144 275 minecraft:dark_prismarine
setblock 205 143 275 minecraft:sea_lantern
setblock 206 143 275 minecraft:dark_prismarine
setblock 207 143 278 minecraft:light[level=15]
setblock 207 143 286 minecraft:light[level=15]
setblock 207 143 294 minecraft:light[level=15]
setblock 207 143 302 minecraft:light[level=15]
setblock 207 143 310 minecraft:light[level=15]
setblock 209 143 275 minecraft:dark_prismarine
setblock 211 143 275 minecraft:dark_prismarine
setblock 215 143 278 minecraft:light[level=15]
setblock 215 143 286 minecraft:light[level=15]
setblock 215 143 294 minecraft:light[level=15]
setblock 215 143 302 minecraft:light[level=15]
setblock 215 143 310 minecraft:light[level=15]
setblock 223 143 278 minecraft:light[level=15]
setblock 223 143 286 minecraft:light[level=15]
setblock 223 143 294 minecraft:light[level=15]
setblock 223 143 302 minecraft:light[level=15]
setblock 223 143 310 minecraft:light[level=15]
fill 224 143 317 224 144 317 minecraft:dark_prismarine
setblock 225 143 275 minecraft:dark_prismarine
setblock 226 143 317 minecraft:dark_prismarine
setblock 229 143 275 minecraft:dark_prismarine
fill 230 143 298 230 144 298 minecraft:dark_prismarine
setblock 230 143 305 minecraft:dark_prismarine
fill 230 143 309 230 143 310 minecraft:dark_prismarine
setblock 230 143 316 minecraft:dark_prismarine
fill 188 144 276 188 208 277 minecraft:prismarine_bricks
fill 188 144 279 188 190 279 minecraft:prismarine_bricks
fill 188 144 281 188 144 290 minecraft:prismarine_bricks
fill 188 144 293 188 145 296 minecraft:prismarine_bricks
fill 188 144 298 188 144 309 minecraft:prismarine_bricks
fill 188 144 311 188 144 316 minecraft:prismarine_bricks
fill 189 144 275 192 189 275 minecraft:prismarine_bricks
fill 189 144 317 190 150 317 minecraft:prismarine_bricks
setblock 191 144 317 minecraft:dark_prismarine
fill 192 144 317 196 145 317 minecraft:prismarine_bricks
fill 194 144 275 200 145 275 minecraft:prismarine_bricks
fill 198 144 317 209 144 317 minecraft:prismarine_bricks
fill 202 144 275 203 145 275 minecraft:prismarine_bricks
fill 205 144 275 209 150 275 minecraft:prismarine_bricks
fill 211 144 275 222 145 275 minecraft:prismarine_bricks
fill 211 144 317 223 144 317 minecraft:prismarine_bricks
fill 224 144 275 229 145 275 minecraft:prismarine_bricks
fill 225 144 317 226 150 317 minecraft:prismarine_bricks
fill 228 144 317 230 145 317 minecraft:prismarine_bricks
fill 230 144 276 230 144 288 minecraft:prismarine_bricks
fill 230 144 290 230 150 290 minecraft:prismarine_bricks
setblock 230 144 291 minecraft:dark_prismarine
fill 230 144 292 230 144 295 minecraft:prismarine_bricks
setblock 230 144 296 minecraft:dark_prismarine
fill 230 144 297 230 145 297 minecraft:prismarine_bricks
fill 230 144 299 230 145 303 minecraft:prismarine_bricks
fill 230 144 305 230 144 316 minecraft:prismarine_bricks
fill 188 145 275 188 226 275 minecraft:prismarine_bricks
fill 188 145 278 188 226 278 minecraft:prismarine_bricks
fill 188 145 280 188 145 286 minecraft:prismarine_bricks
setblock 188 145 287 minecraft:dark_prismarine
fill 188 145 288 188 148 292 minecraft:prismarine_bricks
fill 188 145 297 188 145 301 minecraft:prismarine_bricks
setblock 188 145 302 minecraft:dark_prismarine
fill 188 145 303 188 145 311 minecraft:prismarine_bricks
setblock 188 145 312 minecraft:dark_prismarine
fill 188 145 313 188 145 315 minecraft:prismarine_bricks
setblock 188 145 316 minecraft:dark_prismarine
fill 188 145 317 188 150 317 minecraft:prismarine_bricks
setblock 191 145 317 minecraft:prismarine_bricks
fill 197 145 317 202 148 317 minecraft:prismarine_bricks
fill 201 145 275 201 227 275 minecraft:prismarine_bricks
setblock 203 145 317 minecraft:dark_prismarine
fill 204 145 275 204 161 275 minecraft:prismarine_bricks
fill 204 145 317 221 150 317 minecraft:prismarine_bricks
fill 210 145 275 210 150 275 minecraft:prismarine_bricks
setblock 222 145 317 minecraft:dark_prismarine
fill 223 145 275 223 226 275 minecraft:prismarine_bricks
fill 223 145 317 224 150 317 minecraft:prismarine_bricks
fill 227 145 317 227 150 317 minecraft:prismarine_bricks
fill 230 145 275 230 145 284 minecraft:prismarine_bricks
setblock 230 145 285 minecraft:dark_prismarine
fill 230 145 286 230 145 289 minecraft:prismarine_bricks
fill 230 145 291 230 150 292 minecraft:prismarine_bricks
setblock 230 145 293 minecraft:dark_prismarine
setblock 230 145 294 minecraft:sea_lantern
fill 230 145 295 230 226 296 minecraft:prismarine_bricks
setblock 230 145 298 minecraft:prismarine_bricks
fill 230 145 304 230 145 315 minecraft:prismarine_bricks
setblock 230 145 316 minecraft:dark_prismarine
fill 188 146 280 188 150 284 minecraft:prismarine_bricks
setblock 188 146 285 minecraft:dark_prismarine
fill 188 146 286 188 222 287 minecraft:prismarine_bricks
setblock 188 146 293 minecraft:dark_prismarine
fill 188 146 294 188 150 297 minecraft:prismarine_bricks
setblock 188 146 298 minecraft:dark_prismarine
fill 188 146 299 188 226 300 minecraft:prismarine_bricks
setblock 188 146 301 minecraft:dark_prismarine
fill 188 146 302 188 202 303 minecraft:prismarine_bricks
setblock 188 146 304 minecraft:dark_prismarine
fill 188 146 305 188 149 312 minecraft:prismarine_bricks
setblock 188 146 313 minecraft:dark_prismarine
fill 188 146 314 188 224 316 minecraft:prismarine_bricks
setblock 191 146 317 minecraft:dark_prismarine
setblock 192 146 317 minecraft:sea_lantern
fill 193 146 317 196 146 317 minecraft:prismarine_bricks
fill 194 146 275 195 150 275 minecraft:prismarine_bricks
setblock 196 146 275 minecraft:dark_prismarine
fill 197 146 275 197 150 275 minecraft:prismarine_bricks
setblock 198 146 275 minecraft:dark_prismarine
fill 199 146 275 200 223 275 minecraft:prismarine_bricks
fill 199 146 298 206 146 298 minecraft:prismarine_bricks
fill 200 146 294 207 146 297 minecraft:prismarine_bricks
fill 200 146 299 207 146 302 minecraft:prismarine_bricks
fill 201 146 292 219 146 293 minecraft:prismarine_bricks
fill 201 146 303 219 146 304 minecraft:prismarine_bricks
fill 202 146 275 202 226 275 minecraft:prismarine_bricks
fill 202 146 291 218 146 291 minecraft:prismarine_bricks
fill 202 146 305 218 146 305 minecraft:prismarine_bricks
setblock 203 146 275 minecraft:dark_prismarine
fill 203 146 290 217 146 290 minecraft:prismarine_bricks
fill 203 146 306 217 146 306 minecraft:prismarine_bricks
fill 203 146 317 203 150 317 minecraft:prismarine_bricks
fill 204 146 289 216 146 289 minecraft:prismarine_bricks
fill 204 146 307 216 146 307 minecraft:prismarine_bricks
fill 206 146 288 214 146 288 minecraft:prismarine_bricks
fill 206 146 308 214 146 308 minecraft:prismarine_bricks
fill 208 146 294 209 146 295 minecraft:prismarine_bricks
fill 208 146 301 209 146 302 minecraft:prismarine_bricks
fill 210 146 287 210 147 287 minecraft:prismarine_bricks
fill 210 146 294 220 146 294 minecraft:prismarine_bricks
fill 210 146 302 220 146 302 minecraft:prismarine_bricks
fill 210 146 309 210 147 309 minecraft:prismarine_bricks
fill 211 146 275 212 146 275 minecraft:dark_prismarine
fill 211 146 295 220 146 295 minecraft:prismarine_bricks
fill 211 146 301 220 146 301 minecraft:prismarine_bricks
fill 213 146 275 222 150 275 minecraft:prismarine_bricks
fill 213 146 296 220 146 297 minecraft:prismarine_bricks
fill 213 146 299 220 146 300 minecraft:prismarine_bricks
fill 214 146 298 221 146 298 minecraft:prismarine_bricks
fill 222 146 317 222 226 317 minecraft:prismarine_bricks
fill 224 146 275 226 146 275 minecraft:prismarine_bricks
setblock 227 146 275 minecraft:dark_prismarine
fill 228 146 275 230 224 275 minecraft:prismarine_bricks
fill 228 146 317 229 226 317 minecraft:prismarine_bricks
fill 230 146 276 230 150 280 minecraft:prismarine_bricks
setblock 230 146 281 minecraft:dark_prismarine
fill 230 146 282 230 150 288 minecraft:prismarine_bricks
setblock 230 146 289 minecraft:dark_prismarine
fill 230 146 293 230 156 294 minecraft:prismarine_bricks
fill 230 146 297 230 146 299 minecraft:dark_prismarine
fill 230 146 300 230 150 312 minecraft:prismarine_bricks
setblock 230 146 313 minecraft:dark_prismarine
fill 230 146 314 230 150 316 minecraft:prismarine_bricks
setblock 230 146 317 minecraft:dark_prismarine
fill 188 147 285 188 168 285 minecraft:prismarine_bricks
fill 188 147 293 188 150 293 minecraft:prismarine_bricks
fill 188 147 298 188 224 298 minecraft:prismarine_bricks
fill 188 147 301 188 226 301 minecraft:prismarine_bricks
fill 188 147 304 188 226 304 minecraft:prismarine_bricks
fill 188 147 313 188 148 313 minecraft:prismarine_bricks
fill 189 147 276 189 147 316 minecraft:dark_prismarine
fill 190 147 276 190 147 294 minecraft:dark_prismarine
fill 190 147 298 190 147 316 minecraft:dark_prismarine
fill 191 147 276 207 147 277 minecraft:dark_prismarine
fill 191 147 281 199 147 294 minecraft:dark_prismarine
fill 191 147 298 198 147 311 minecraft:dark_prismarine
fill 191 147 315 207 147 316 minecraft:dark_prismarine
fill 191 147 317 194 150 317 minecraft:prismarine_bricks
fill 193 147 275 193 226 275 minecraft:prismarine_bricks
fill 193 147 295 199 147 297 minecraft:dark_prismarine
fill 194 147 278 207 147 280 minecraft:dark_prismarine
fill 194 147 312 207 147 314 minecraft:dark_prismarine
setblock 195 147 317 minecraft:sea_lantern
fill 196 147 275 196 150 275 minecraft:prismarine_bricks
fill 196 147 317 196 226 317 minecraft:prismarine_bricks
fill 198 147 275 198 150 275 minecraft:prismarine_bricks
setblock 199 147 298 minecraft:prismarine_bricks
fill 199 147 299 199 147 311 minecraft:dark_prismarine
fill 200 147 281 200 147 293 minecraft:dark_prismarine
fill 200 147 294 200 147 302 minecraft:sea_lantern
fill 200 147 303 200 147 311 minecraft:dark_prismarine
fill 201 147 281 201 147 291 minecraft:dark_prismarine
fill 201 147 292 201 147 293 minecraft:sea_lantern
fill 201 147 294 203 147 295 minecraft:prismarine_bricks
fill 201 147 296 202 147 296 minecraft:prismarine
fill 201 147 297 202 147 299 minecraft:prismarine_bricks
fill 201 147 300 202 147 300 minecraft:prismarine
fill 201 147 301 203 147 302 minecraft:prismarine_bricks
fill 201 147 303 201 147 304 minecraft:sea_lantern
fill 201 147 305 201 147 311 minecraft:dark_prismarine
fill 202 147 281 202 147 290 minecraft:dark_prismarine
fill 202 147 291 202 147 292 minecraft:sea_lantern
fill 202 147 293 204 147 293 minecraft:prismarine_bricks
fill 202 147 303 204 147 303 minecraft:prismarine_bricks
fill 202 147 304 202 147 305 minecraft:sea_lantern
fill 202 147 306 202 147 311 minecraft:dark_prismarine
fill 203 147 275 203 226 275 minecraft:prismarine_bricks
fill 203 147 281 203 147 289 minecraft:dark_prismarine
fill 203 147 290 204 147 290 minecraft:sea_lantern
setblock 203 147 291 minecraft:prismarine
setblock 203 147 292 minecraft:prismarine_bricks
fill 203 147 296 203 147 300 minecraft:gold_block
setblock 203 147 304 minecraft:prismarine_bricks
setblock 203 147 305 minecraft:prismarine
fill 203 147 306 204 147 306 minecraft:sea_lantern
fill 203 147 307 203 147 311 minecraft:dark_prismarine
fill 204 147 281 205 147 288 minecraft:dark_prismarine
fill 204 147 289 205 147 289 minecraft:sea_lantern
fill 204 147 291 207 147 291 minecraft:prismarine_bricks
setblock 204 147 292 minecraft:prismarine
fill 204 147 294 204 147 295 minecraft:gold_block
fill 204 147 296 205 147 300 minecraft:prismarine_bricks
fill 204 147 301 204 147 302 minecraft:gold_block
setblock 204 147 304 minecraft:prismarine
fill 204 147 305 207 147 305 minecraft:prismarine_bricks
fill 204 147 307 205 147 307 minecraft:sea_lantern
fill 204 147 308 205 147 311 minecraft:dark_prismarine
fill 205 147 290 207 147 290 minecraft:prismarine_bricks
setblock 205 147 292 minecraft:prismarine_bricks
setblock 205 147 293 minecraft:gold_block
fill 205 147 294 205 147 295 minecraft:prismarine_bricks
fill 205 147 301 205 147 302 minecraft:prismarine_bricks
setblock 205 147 303 minecraft:gold_block
setblock 205 147 304 minecraft:prismarine_bricks
fill 205 147 306 207 147 306 minecraft:prismarine_bricks
fill 206 147 281 209 147 287 minecraft:dark_prismarine
fill 206 147 288 214 147 288 minecraft:sea_lantern
fill 206 147 289 207 147 289 minecraft:prismarine_bricks
fill 206 147 292 207 147 292 minecraft:gold_block
fill 206 147 293 214 147 293 minecraft:prismarine_bricks
setblock 206 147 294 minecraft:prismarine
fill 206 147 295 206 147 296 minecraft:prismarine_bricks
fill 206 147 297 206 147 299 minecraft:gold_block
fill 206 147 300 206 147 301 minecraft:prismarine_bricks
setblock 206 147 302 minecraft:prismarine
fill 206 147 303 214 147 303 minecraft:prismarine_bricks
fill 206 147 304 207 147 304 minecraft:gold_block
fill 206 147 307 207 147 307 minecraft:prismarine_bricks
fill 206 147 308 214 147 308 minecraft:sea_lantern
fill 206 147 309 209 147 311 minecraft:dark_prismarine
fill 207 147 294 208 147 294 minecraft:prismarine_bricks
fill 207 147 295 207 147 297 minecraft:gold_block
fill 207 147 299 207 147 301 minecraft:gold_block
fill 207 147 302 208 147 302 minecraft:prismarine_bricks
fill 208 147 276 229 147 276 minecraft:dark_prismarine
fill 208 147 280 224 147 280 minecraft:dark_prismarine
fill 208 147 289 208 147 290 minecraft:prismarine
fill 208 147 291 212 147 291 minecraft:gold_block
fill 208 147 292 212 147 292 minecraft:prismarine_bricks
fill 208 147 295 209 147 295 minecraft:gold_block
fill 208 147 301 209 147 301 minecraft:gold_block
fill 208 147 304 212 147 304 minecraft:prismarine_bricks
fill 208 147 305 212 147 305 minecraft:gold_block
fill 208 147 306 208 147 307 minecraft:prismarine
fill 208 147 312 224 147 312 minecraft:dark_prismarine
fill 208 147 316 229 147 316 minecraft:dark_prismarine
fill 209 147 289 211 147 290 minecraft:prismarine_bricks
fill 209 147 294 211 147 294 minecraft:gold_block
fill 209 147 302 211 147 302 minecraft:gold_block
fill 209 147 306 211 147 307 minecraft:prismarine_bricks
fill 210 147 281 229 147 286 minecraft:dark_prismarine
fill 210 147 310 229 147 311 minecraft:dark_prismarine
fill 211 147 275 212 172 275 minecraft:prismarine_bricks
fill 211 147 277 224 147 279 minecraft:dark_prismarine
fill 211 147 287 229 147 287 minecraft:dark_prismarine
fill 211 147 295 213 147 295 minecraft:gold_block
fill 211 147 301 213 147 301 minecraft:gold_block
fill 211 147 309 229 147 309 minecraft:dark_prismarine
fill 211 147 313 224 147 315 minecraft:dark_prismarine
fill 212 147 289 212 147 290 minecraft:prismarine
fill 212 147 294 213 147 294 minecraft:prismarine_bricks
fill 212 147 302 213 147 302 minecraft:prismarine_bricks
fill 212 147 306 212 147 307 minecraft:prismarine
fill 213 147 289 214 147 291 minecraft:prismarine_bricks
fill 213 147 292 214 147 292 minecraft:gold_block
fill 213 147 296 213 147 297 minecraft:gold_block
fill 213 147 299 213 147 300 minecraft:gold_block
fill 213 147 304 214 147 304 minecraft:gold_block
fill 213 147 305 214 147 307 minecraft:prismarine_bricks
setblock 214 147 294 minecraft:prismarine
fill 214 147 295 215 147 296 minecraft:prismarine_bricks
fill 214 147 297 214 147 299 minecraft:gold_block
fill 214 147 300 215 147 301 minecraft:prismarine_bricks
setblock 214 147 302 minecraft:prismarine
fill 215 147 288 229 147 288 minecraft:dark_prismarine
fill 215 147 289 216 147 289 minecraft:sea_lantern
fill 215 147 290 215 147 292 minecraft:prismarine_bricks
setblock 215 147 293 minecraft:gold_block
setblock 215 147 294 minecraft:prismarine_bricks
fill 215 147 297 216 147 299 minecraft:prismarine_bricks
setblock 215 147 302 minecraft:prismarine_bricks
setblock 215 147 303 minecraft:gold_block
fill 215 147 304 215 147 306 minecraft:prismarine_bricks
fill 215 147 307 216 147 307 minecraft:sea_lantern
fill 215 147 308 229 147 308 minecraft:dark_prismarine
fill 216 147 290 217 147 290 minecraft:sea_lantern
setblock 216 147 291 minecraft:prismarine_bricks
setblock 216 147 292 minecraft:prismarine
fill 216 147 293 218 147 293 minecraft:prismarine_bricks
fill 216 147 294 216 147 295 minecraft:gold_block
setblock 216 147 296 minecraft:prismarine_bricks
setblock 216 147 300 minecraft:prismarine_bricks
fill 216 147 301 216 147 302 minecraft:gold_block
fill 216 147 303 218 147 303 minecraft:prismarine_bricks
setblock 216 147 304 minecraft:prismarine
setblock 216 147 305 minecraft:prismarine_bricks
fill 216 147 306 217 147 306 minecraft:sea_lantern
fill 217 147 289 229 147 289 minecraft:dark_prismarine
setblock 217 147 291 minecraft:prismarine
setblock 217 147 292 minecraft:prismarine_bricks
fill 217 147 294 219 147 295 minecraft:prismarine_bricks
fill 217 147 296 217 147 300 minecraft:gold_block
fill 217 147 301 219 147 302 minecraft:prismarine_bricks
setblock 217 147 304 minecraft:prismarine_bricks
setblock 217 147 305 minecraft:prismarine
fill 217 147 307 229 147 307 minecraft:dark_prismarine
fill 218 147 290 229 147 290 minecraft:dark_prismarine
fill 218 147 291 218 147 292 minecraft:sea_lantern
fill 218 147 296 219 147 296 minecraft:prismarine
fill 218 147 297 219 147 299 minecraft:prismarine_bricks
fill 218 147 300 219 147 300 minecraft:prismarine
fill 218 147 304 218 147 305 minecraft:sea_lantern
fill 218 147 306 229 147 306 minecraft:dark_prismarine
fill 219 147 291 229 147 291 minecraft:dark_prismarine
fill 219 147 292 219 147 293 minecraft:sea_lantern
fill 219 147 303 219 147 304 minecraft:sea_lantern
fill 219 147 305 229 147 305 minecraft:dark_prismarine
fill 220 147 292 229 147 293 minecraft:dark_prismarine
fill 220 147 294 220 147 302 minecraft:sea_lantern
fill 220 147 303 229 147 304 minecraft:dark_prismarine
fill 221 147 294 225 147 297 minecraft:dark_prismarine
setblock 221 147 298 minecraft:prismarine_bricks
fill 221 147 299 229 147 302 minecraft:dark_prismarine
fill 222 147 298 229 147 298 minecraft:dark_prismarine
setblock 224 147 275 minecraft:sea_lantern
fill 225 147 275 227 223 275 minecraft:prismarine_bricks
fill 225 147 277 229 147 277 minecraft:dark_prismarine
fill 225 147 315 229 147 315 minecraft:dark_prismarine
fill 226 147 294 229 147 294 minecraft:dark_prismarine
fill 228 147 278 229 147 280 minecraft:dark_prismarine
fill 228 147 312 229 147 314 minecraft:dark_prismarine
fill 229 147 295 229 147 297 minecraft:dark_prismarine
fill 230 147 281 230 207 281 minecraft:prismarine_bricks
fill 230 147 289 230 150 289 minecraft:prismarine_bricks
fill 230 147 297 230 154 299 minecraft:prismarine_bricks
fill 230 147 313 230 150 313 minecraft:prismarine_bricks
fill 230 147 317 230 223 317 minecraft:prismarine_bricks
fill 195 148 317 195 226 317 minecraft:prismarine_bricks
fill 224 148 275 224 224 275 minecraft:prismarine_bricks
setblock 188 149 288 minecraft:sea_lantern
fill 188 149 289 188 158 292 minecraft:prismarine_bricks
setblock 188 149 313 minecraft:sea_lantern
fill 197 149 317 199 180 317 minecraft:prismarine_bricks
setblock 200 149 317 minecraft:sea_lantern
fill 201 149 317 202 150 317 minecraft:prismarine_bricks
fill 188 150 288 188 226 288 minecraft:prismarine_bricks
fill 188 150 305 188 150 311 minecraft:prismarine_bricks
setblock 188 150 312 minecraft:sea_lantern
fill 188 150 313 188 227 313 minecraft:prismarine_bricks
setblock 200 150 317 minecraft:prismarine_bricks
fill 188 151 280 188 211 280 minecraft:prismarine_bricks
fill 188 151 281 188 151 284 minecraft:sea_lantern
fill 188 151 293 188 151 296 minecraft:sea_lantern
fill 188 151 297 188 226 297 minecraft:prismarine_bricks
fill 188 151 305 188 151 308 minecraft:sea_lantern
fill 188 151 309 188 169 312 minecraft:prismarine_bricks
fill 188 151 317 191 151 317 minecraft:sea_lantern
fill 189 151 276 191 216 276 minecraft:prismarine_bricks
fill 189 151 286 189 216 288 minecraft:prismarine_bricks
fill 189 151 298 189 216 300 minecraft:prismarine_bricks
fill 189 151 310 189 216 312 minecraft:prismarine_bricks
setblock 191 151 286 minecraft:light[level=15]
setblock 191 151 294 minecraft:light[level=15]
setblock 191 151 302 minecraft:light[level=15]
setblock 191 151 310 minecraft:light[level=15]
fill 192 151 317 194 183 317 minecraft:prismarine_bricks
fill 194 151 275 194 223 275 minecraft:prismarine_bricks
fill 195 151 275 198 151 275 minecraft:sea_lantern
fill 195 151 316 197 216 316 minecraft:prismarine_bricks
setblock 199 151 278 minecraft:light[level=15]
setblock 199 151 286 minecraft:light[level=15]
setblock 199 151 294 minecraft:light[level=15]
setblock 199 151 302 minecraft:light[level=15]
setblock 199 151 310 minecraft:light[level=15]
fill 200 151 317 203 151 317 minecraft:sea_lantern
fill 201 151 276 203 216 276 minecraft:prismarine_bricks
fill 204 151 317 211 151 317 minecraft:prismarine_bricks
fill 205 151 275 206 171 275 minecraft:prismarine_bricks
fill 207 151 275 210 151 275 minecraft:sea_lantern
setblock 207 151 278 minecraft:light[level=15]
setblock 207 151 286 minecraft:light[level=15]
setblock 207 151 294 minecraft:light[level=15]
setblock 207 151 302 minecraft:light[level=15]
fill 207 151 306 207 153 316 minecraft:prismarine_bricks
fill 208 151 306 219 153 312 minecraft:prismarine_bricks
fill 208 151 316 221 153 316 minecraft:prismarine_bricks
fill 211 151 313 219 153 315 minecraft:prismarine_bricks
fill 212 151 317 215 151 317 minecraft:sea_lantern
fill 213 151 275 215 165 276 minecraft:prismarine_bricks
setblock 215 151 278 minecraft:light[level=15]
setblock 215 151 286 minecraft:light[level=15]
setblock 215 151 294 minecraft:light[level=15]
setblock 215 151 302 minecraft:light[level=15]
fill 216 151 275 218 226 275 minecraft:prismarine_bricks
fill 216 151 317 221 156 317 minecraft:prismarine_bricks
fill 219 151 275 222 151 275 minecraft:sea_lantern
fill 222 151 284 229 153 290 minecraft:prismarine_bricks
fill 222 151 312 222 151 314 minecraft:dark_prismarine
setblock 223 151 278 minecraft:light[level=15]
setblock 223 151 294 minecraft:light[level=15]
setblock 223 151 302 minecraft:light[level=15]
setblock 223 151 310 minecraft:light[level=15]
setblock 223 151 311 minecraft:dark_prismarine
fill 223 151 312 224 204 314 minecraft:prismarine_bricks
fill 223 151 315 225 151 315 minecraft:dark_prismarine
fill 223 151 317 223 226 317 minecraft:prismarine_bricks
fill 224 151 311 224 216 311 minecraft:prismarine_bricks
fill 224 151 317 227 151 317 minecraft:sea_lantern
fill 225 151 276 227 216 276 minecraft:prismarine_bricks
fill 225 151 311 226 151 311 minecraft:dark_prismarine
fill 229 151 296 229 216 298 minecraft:prismarine_bricks
fill 229 151 308 230 175 310 minecraft:prismarine_bricks
fill 230 151 276 230 151 279 minecraft:sea_lantern
fill 230 151 280 230 222 280 minecraft:prismarine_bricks
fill 230 151 282 230 152 287 minecraft:prismarine_bricks
fill 230 151 288 230 151 291 minecraft:sea_lantern
fill 230 151 292 230 174 292 minecraft:prismarine_bricks
fill 230 151 300 230 151 303 minecraft:sea_lantern
fill 230 151 304 230 174 307 minecraft:prismarine_bricks
fill 230 151 311 230 154 311 minecraft:prismarine_bricks
fill 230 151 312 230 151 315 minecraft:sea_lantern
fill 230 151 316 230 226 316 minecraft:prismarine_bricks
fill 188 152 281 188 165 281 minecraft:prismarine_bricks
fill 188 152 282 188 152 283 minecraft:sea_lantern
fill 188 152 284 188 165 284 minecraft:prismarine_bricks
fill 188 152 293 188 165 293 minecraft:prismarine_bricks
fill 188 152 294 188 152 295 minecraft:sea_lantern
fill 188 152 296 188 165 296 minecraft:prismarine_bricks
fill 188 152 305 188 165 305 minecraft:prismarine_bricks
fill 188 152 306 188 152 307 minecraft:sea_lantern
fill 188 152 308 188 165 308 minecraft:prismarine_bricks
fill 188 152 317 188 165 317 minecraft:prismarine_bricks
fill 189 152 317 190 152 317 minecraft:sea_lantern
fill 191 152 317 191 165 317 minecraft:prismarine_bricks
fill 195 152 275 195 165 275 minecraft:prismarine_bricks
fill 196 152 275 197 152 275 minecraft:sea_lantern
fill 198 152 275 198 165 275 minecraft:prismarine_bricks
fill 200 152 317 200 165 317 minecraft:prismarine_bricks
fill 201 152 317 202 152 317 minecraft:sea_lantern
fill 203 152 317 205 165 317 minecraft:prismarine_bricks
setblock 206 152 317 minecraft:sea_lantern
fill 207 152 275 207 165 275 minecraft:prismarine_bricks
fill 207 152 317 212 160 317 minecraft:prismarine_bricks
fill 208 152 275 209 152 275 minecraft:sea_lantern
fill 210 152 275 210 165 275 minecraft:prismarine_bricks
fill 213 152 317 214 152 317 minecraft:sea_lantern
fill 215 152 317 215 165 317 minecraft:prismarine_bricks
fill 219 152 275 219 160 275 minecraft:prismarine_bricks
fill 220 152 275 221 152 275 minecraft:sea_lantern
fill 222 152 275 222 165 275 minecraft:prismarine_bricks
fill 224 152 317 224 165 317 minecraft:prismarine_bricks
fill 225 152 317 226 152 317 minecraft:sea_lantern
fill 227 152 317 227 165 317 minecraft:prismarine_bricks
fill 230 152 276 230 165 276 minecraft:prismarine_bricks
fill 230 152 277 230 152 278 minecraft:sea_lantern
fill 230 152 279 230 165 279 minecraft:prismarine_bricks
fill 230 152 288 230 165 288 minecraft:prismarine_bricks
fill 230 152 289 230 152 290 minecraft:sea_lantern
fill 230 152 291 230 165 291 minecraft:prismarine_bricks
fill 230 152 300 230 165 300 minecraft:prismarine_bricks
fill 230 152 301 230 152 302 minecraft:sea_lantern
fill 230 152 303 230 165 303 minecraft:prismarine_bricks
fill 230 152 312 230 165 312 minecraft:prismarine_bricks
fill 230 152 313 230 152 314 minecraft:sea_lantern
fill 230 152 315 230 165 315 minecraft:prismarine_bricks
fill 188 153 282 188 165 283 minecraft:prismarine_bricks
fill 188 153 294 188 165 295 minecraft:prismarine_bricks
fill 188 153 306 188 165 307 minecraft:prismarine_bricks
fill 189 153 317 190 165 317 minecraft:prismarine_bricks
setblock 191 153 285 minecraft:light[level=12]
setblock 191 153 292 minecraft:light[level=12]
setblock 191 153 299 minecraft:light[level=12]
setblock 191 153 306 minecraft:light[level=12]
fill 196 153 275 197 165 275 minecraft:prismarine_bricks
setblock 198 153 278 minecraft:light[level=12]
setblock 198 153 285 minecraft:light[level=12]
setblock 198 153 292 minecraft:light[level=12]
setblock 198 153 299 minecraft:light[level=12]
setblock 198 153 306 minecraft:light[level=12]
setblock 198 153 313 minecraft:light[level=12]
fill 201 153 317 202 165 317 minecraft:prismarine_bricks
setblock 205 153 278 minecraft:light[level=12]
setblock 205 153 285 minecraft:light[level=12]
setblock 205 153 292 minecraft:light[level=12]
setblock 205 153 299 minecraft:light[level=12]
setblock 205 153 306 minecraft:light[level=12]
setblock 205 153 313 minecraft:light[level=12]
fill 206 153 317 206 222 317 minecraft:prismarine_bricks
fill 208 153 275 209 165 275 minecraft:prismarine_bricks
setblock 212 153 278 minecraft:light[level=12]
setblock 212 153 285 minecraft:light[level=12]
setblock 212 153 292 minecraft:light[level=12]
setblock 212 153 299 minecraft:light[level=12]
fill 213 153 317 214 165 317 minecraft:prismarine_bricks
setblock 219 153 278 minecraft:light[level=12]
setblock 219 153 285 minecraft:light[level=12]
setblock 219 153 292 minecraft:light[level=12]
setblock 219 153 299 minecraft:light[level=12]
fill 220 153 275 221 165 275 minecraft:prismarine_bricks
fill 225 153 317 226 165 317 minecraft:prismarine_bricks
setblock 226 153 292 minecraft:light[level=12]
setblock 226 153 299 minecraft:light[level=12]
setblock 226 153 306 minecraft:light[level=12]
fill 230 153 277 230 165 278 minecraft:prismarine_bricks
fill 230 153 282 230 194 284 minecraft:prismarine_bricks
setblock 230 153 285 minecraft:sea_lantern
fill 230 153 286 230 179 287 minecraft:prismarine_bricks
fill 230 153 289 230 165 290 minecraft:prismarine_bricks
fill 230 153 301 230 165 302 minecraft:prismarine_bricks
fill 230 153 313 230 165 314 minecraft:prismarine_bricks
setblock 207 154 306 minecraft:sea_lantern
fill 207 154 307 207 162 307 minecraft:prismarine_bricks
setblock 207 154 308 minecraft:sea_lantern
fill 207 154 309 207 162 309 minecraft:prismarine_bricks
setblock 207 154 310 minecraft:sea_lantern
fill 207 154 311 207 162 311 minecraft:prismarine_bricks
setblock 207 154 312 minecraft:sea_lantern
fill 207 154 313 207 162 313 minecraft:prismarine_bricks
setblock 207 154 314 minecraft:sea_lantern
fill 207 154 315 207 162 315 minecraft:prismarine_bricks
setblock 207 154 316 minecraft:sea_lantern
fill 208 154 306 208 162 306 minecraft:prismarine_bricks
setblock 208 154 307 minecraft:sea_lantern
fill 208 154 308 208 162 308 minecraft:prismarine_bricks
setblock 208 154 309 minecraft:sea_lantern
fill 208 154 310 208 162 310 minecraft:prismarine_bricks
setblock 208 154 311 minecraft:sea_lantern
fill 208 154 312 208 162 312 minecraft:prismarine_bricks
setblock 208 154 313 minecraft:sea_lantern
fill 208 154 314 208 165 314 minecraft:quartz_pillar
setblock 208 154 315 minecraft:sea_lantern
fill 208 154 316 208 216 316 minecraft:prismarine_bricks
setblock 209 154 306 minecraft:sea_lantern
fill 209 154 307 209 162 307 minecraft:prismarine_bricks
setblock 209 154 308 minecraft:sea_lantern
fill 209 154 309 209 162 309 minecraft:prismarine_bricks
setblock 209 154 310 minecraft:sea_lantern
fill 209 154 311 209 162 311 minecraft:prismarine_bricks
setblock 209 154 312 minecraft:sea_lantern
fill 209 154 313 209 165 313 minecraft:quartz_pillar
setblock 209 154 314 minecraft:sea_lantern
fill 209 154 315 209 165 315 minecraft:quartz_pillar
setblock 209 154 316 minecraft:sea_lantern
fill 210 154 306 210 162 306 minecraft:prismarine_bricks
setblock 210 154 307 minecraft:sea_lantern
fill 210 154 308 210 162 308 minecraft:prismarine_bricks
setblock 210 154 309 minecraft:sea_lantern
fill 210 154 310 210 162 310 minecraft:prismarine_bricks
setblock 210 154 311 minecraft:sea_lantern
fill 210 154 312 210 162 312 minecraft:prismarine_bricks
setblock 210 154 313 minecraft:sea_lantern
fill 210 154 314 210 165 314 minecraft:quartz_pillar
setblock 210 154 315 minecraft:sea_lantern
fill 210 154 316 210 162 316 minecraft:prismarine_bricks
setblock 211 154 306 minecraft:sea_lantern
fill 211 154 307 211 162 307 minecraft:prismarine_bricks
setblock 211 154 308 minecraft:sea_lantern
fill 211 154 309 211 162 309 minecraft:prismarine_bricks
setblock 211 154 310 minecraft:sea_lantern
fill 211 154 311 211 162 311 minecraft:prismarine_bricks
setblock 211 154 312 minecraft:sea_lantern
fill 211 154 313 211 162 313 minecraft:prismarine_bricks
setblock 211 154 314 minecraft:sea_lantern
fill 211 154 315 211 162 315 minecraft:prismarine_bricks
setblock 211 154 316 minecraft:sea_lantern
fill 212 154 306 212 162 306 minecraft:prismarine_bricks
setblock 212 154 307 minecraft:sea_lantern
fill 212 154 308 212 162 308 minecraft:prismarine_bricks
setblock 212 154 309 minecraft:sea_lantern
fill 212 154 310 212 162 310 minecraft:prismarine_bricks
setblock 212 154 311 minecraft:sea_lantern
fill 212 154 312 212 162 312 minecraft:prismarine_bricks
setblock 212 154 313 minecraft:sea_lantern
fill 212 154 314 212 162 314 minecraft:prismarine_bricks
setblock 212 154 315 minecraft:sea_lantern
fill 212 154 316 212 162 316 minecraft:prismarine_bricks
setblock 213 154 306 minecraft:sea_lantern
fill 213 154 307 213 162 307 minecraft:prismarine_bricks
setblock 213 154 308 minecraft:sea_lantern
fill 213 154 309 213 162 309 minecraft:prismarine_bricks
setblock 213 154 310 minecraft:sea_lantern
fill 213 154 311 213 162 311 minecraft:prismarine_bricks
setblock 213 154 312 minecraft:sea_lantern
fill 213 154 313 213 162 313 minecraft:prismarine_bricks
setblock 213 154 314 minecraft:sea_lantern
fill 213 154 315 213 162 315 minecraft:prismarine_bricks
setblock 213 154 316 minecraft:sea_lantern
fill 214 154 306 214 162 306 minecraft:prismarine_bricks
setblock 214 154 307 minecraft:sea_lantern
fill 214 154 308 214 162 308 minecraft:prismarine_bricks
setblock 214 154 309 minecraft:sea_lantern
fill 214 154 310 214 162 310 minecraft:prismarine_bricks
setblock 214 154 311 minecraft:sea_lantern
fill 214 154 312 214 162 312 minecraft:prismarine_bricks
setblock 214 154 313 minecraft:sea_lantern
fill 214 154 314 214 162 314 minecraft:prismarine_bricks
setblock 214 154 315 minecraft:sea_lantern
fill 214 154 316 214 162 316 minecraft:prismarine_bricks
setblock 215 154 306 minecraft:sea_lantern
fill 215 154 307 215 162 307 minecraft:prismarine_bricks
setblock 215 154 308 minecraft:sea_lantern
fill 215 154 309 215 162 309 minecraft:prismarine_bricks
setblock 215 154 310 minecraft:sea_lantern
fill 215 154 311 215 162 311 minecraft:prismarine_bricks
setblock 215 154 312 minecraft:sea_lantern
fill 215 154 313 215 162 313 minecraft:prismarine_bricks
setblock 215 154 314 minecraft:sea_lantern
fill 215 154 315 215 162 315 minecraft:prismarine_bricks
setblock 215 154 316 minecraft:sea_lantern
fill 216 154 306 216 162 306 minecraft:prismarine_bricks
setblock 216 154 307 minecraft:sea_lantern
fill 216 154 308 216 162 308 minecraft:prismarine_bricks
setblock 216 154 309 minecraft:sea_lantern
fill 216 154 310 216 162 310 minecraft:prismarine_bricks
setblock 216 154 311 minecraft:sea_lantern
fill 216 154 312 216 162 312 minecraft:prismarine_bricks
setblock 216 154 313 minecraft:sea_lantern
fill 216 154 314 216 162 314 minecraft:prismarine_bricks
setblock 216 154 315 minecraft:sea_lantern
fill 216 154 316 216 162 316 minecraft:prismarine_bricks
setblock 217 154 306 minecraft:sea_lantern
fill 217 154 307 217 162 307 minecraft:prismarine_bricks
setblock 217 154 308 minecraft:sea_lantern
fill 217 154 309 217 162 309 minecraft:prismarine_bricks
setblock 217 154 310 minecraft:sea_lantern
fill 217 154 311 217 162 311 minecraft:prismarine_bricks
setblock 217 154 312 minecraft:sea_lantern
fill 217 154 313 217 162 313 minecraft:prismarine_bricks
setblock 217 154 314 minecraft:sea_lantern
fill 217 154 315 217 162 315 minecraft:prismarine_bricks
setblock 217 154 316 minecraft:sea_lantern
fill 218 154 306 218 162 306 minecraft:prismarine_bricks
setblock 218 154 307 minecraft:sea_lantern
fill 218 154 308 218 162 308 minecraft:prismarine_bricks
setblock 218 154 309 minecraft:sea_lantern
fill 218 154 310 218 162 310 minecraft:prismarine_bricks
setblock 218 154 311 minecraft:sea_lantern
fill 218 154 312 218 162 312 minecraft:prismarine_bricks
setblock 218 154 313 minecraft:sea_lantern
fill 218 154 314 218 162 314 minecraft:prismarine_bricks
setblock 218 154 315 minecraft:sea_lantern
fill 218 154 316 218 162 316 minecraft:prismarine_bricks
setblock 219 154 306 minecraft:sea_lantern
fill 219 154 307 219 162 307 minecraft:prismarine_bricks
setblock 219 154 308 minecraft:sea_lantern
fill 219 154 309 219 162 309 minecraft:prismarine_bricks
setblock 219 154 310 minecraft:sea_lantern
fill 219 154 311 219 162 311 minecraft:prismarine_bricks
setblock 219 154 312 minecraft:sea_lantern
fill 219 154 313 219 162 313 minecraft:prismarine_bricks
setblock 219 154 314 minecraft:sea_lantern
fill 219 154 315 219 162 315 minecraft:prismarine_bricks
setblock 219 154 316 minecraft:sea_lantern
fill 220 154 316 221 216 316 minecraft:prismarine_bricks
fill 222 154 284 222 162 284 minecraft:prismarine_bricks
setblock 222 154 285 minecraft:sea_lantern
fill 222 154 286 222 162 286 minecraft:prismarine_bricks
setblock 222 154 287 minecraft:sea_lantern
fill 222 154 288 222 162 288 minecraft:prismarine_bricks
setblock 222 154 289 minecraft:sea_lantern
fill 222 154 290 222 162 290 minecraft:prismarine_bricks
setblock 223 154 284 minecraft:sea_lantern
fill 223 154 285 223 162 285 minecraft:prismarine_bricks
setblock 223 154 286 minecraft:sea_lantern
fill 223 154 287 223 162 287 minecraft:prismarine_bricks
setblock 223 154 288 minecraft:sea_lantern
fill 223 154 289 223 162 289 minecraft:prismarine_bricks
setblock 223 154 290 minecraft:sea_lantern
fill 224 154 284 224 162 284 minecraft:prismarine_bricks
setblock 224 154 285 minecraft:sea_lantern
fill 224 154 286 224 162 286 minecraft:prismarine_bricks
setblock 224 154 287 minecraft:sea_lantern
fill 224 154 288 224 162 288 minecraft:prismarine_bricks
setblock 224 154 289 minecraft:sea_lantern
fill 224 154 290 224 162 290 minecraft:prismarine_bricks
setblock 225 154 284 minecraft:sea_lantern
fill 225 154 285 225 162 285 minecraft:prismarine_bricks
setblock 225 154 286 minecraft:sea_lantern
fill 225 154 287 225 162 287 minecraft:prismarine_bricks
setblock 225 154 288 minecraft:sea_lantern
fill 225 154 289 225 162 289 minecraft:prismarine_bricks
setblock 225 154 290 minecraft:sea_lantern
fill 226 154 284 226 162 284 minecraft:prismarine_bricks
setblock 226 154 285 minecraft:sea_lantern
fill 226 154 286 226 162 286 minecraft:prismarine_bricks
setblock 226 154 287 minecraft:sea_lantern
fill 226 154 288 226 162 288 minecraft:prismarine_bricks
setblock 226 154 289 minecraft:sea_lantern
fill 226 154 290 226 162 290 minecraft:prismarine_bricks
setblock 227 154 284 minecraft:sea_lantern
fill 227 154 285 227 162 285 minecraft:prismarine_bricks
setblock 227 154 286 minecraft:sea_lantern
fill 227 154 287 227 162 287 minecraft:prismarine_bricks
setblock 227 154 288 minecraft:sea_lantern
fill 227 154 289 227 162 289 minecraft:prismarine_bricks
setblock 227 154 290 minecraft:sea_lantern
fill 228 154 284 228 162 284 minecraft:prismarine_bricks
setblock 228 154 285 minecraft:sea_lantern
fill 228 154 286 228 165 286 minecraft:prismarine_bricks
setblock 228 154 287 minecraft:sea_lantern
fill 228 154 288 228 162 288 minecraft:prismarine_bricks
setblock 228 154 289 minecraft:sea_lantern
fill 228 154 290 228 162 290 minecraft:prismarine_bricks
setblock 229 154 284 minecraft:sea_lantern
fill 229 154 285 230 216 285 minecraft:prismarine_bricks
setblock 229 154 286 minecraft:sea_lantern
fill 229 154 287 229 162 287 minecraft:prismarine_bricks
setblock 229 154 288 minecraft:sea_lantern
fill 229 154 289 229 162 289 minecraft:prismarine_bricks
setblock 229 154 290 minecraft:sea_lantern
fill 207 155 306 207 156 306 minecraft:prismarine_bricks
fill 207 155 308 207 156 308 minecraft:prismarine_bricks
fill 207 155 310 207 156 310 minecraft:prismarine_bricks
fill 207 155 312 207 156 312 minecraft:prismarine_bricks
fill 207 155 314 207 156 314 minecraft:prismarine_bricks
fill 207 155 316 207 156 316 minecraft:prismarine_bricks
fill 208 155 307 208 156 307 minecraft:prismarine_bricks
fill 208 155 309 208 156 309 minecraft:prismarine_bricks
fill 208 155 311 208 156 311 minecraft:prismarine_bricks
fill 208 155 313 208 156 313 minecraft:quartz_pillar
fill 208 155 315 208 156 315 minecraft:quartz_pillar
fill 209 155 306 209 156 306 minecraft:prismarine_bricks
fill 209 155 308 209 156 308 minecraft:prismarine_bricks
fill 209 155 310 209 156 310 minecraft:prismarine_bricks
fill 209 155 312 209 156 312 minecraft:prismarine_bricks
fill 209 155 314 209 156 314 minecraft:quartz_pillar
fill 209 155 316 209 156 316 minecraft:prismarine_bricks
fill 210 155 307 210 156 307 minecraft:prismarine_bricks
fill 210 155 309 210 156 309 minecraft:prismarine_bricks
fill 210 155 311 210 156 311 minecraft:prismarine_bricks
fill 210 155 313 210 156 313 minecraft:quartz_pillar
fill 210 155 315 210 156 315 minecraft:quartz_pillar
fill 211 155 306 211 156 306 minecraft:prismarine_bricks
fill 211 155 308 211 156 308 minecraft:prismarine_bricks
fill 211 155 310 211 156 310 minecraft:prismarine_bricks
fill 211 155 312 211 156 312 minecraft:prismarine_bricks
fill 211 155 314 211 156 314 minecraft:prismarine_bricks
fill 211 155 316 211 156 316 minecraft:prismarine_bricks
fill 212 155 307 212 156 307 minecraft:prismarine_bricks
fill 212 155 309 212 156 309 minecraft:prismarine_bricks
fill 212 155 311 212 156 311 minecraft:prismarine_bricks
fill 212 155 313 212 156 313 minecraft:prismarine_bricks
fill 212 155 315 212 156 315 minecraft:prismarine_bricks
fill 213 155 306 213 156 306 minecraft:prismarine_bricks
fill 213 155 308 213 156 308 minecraft:prismarine_bricks
fill 213 155 310 213 156 310 minecraft:prismarine_bricks
fill 213 155 312 213 156 312 minecraft:prismarine_bricks
fill 213 155 314 213 156 314 minecraft:prismarine_bricks
fill 213 155 316 213 156 316 minecraft:prismarine_bricks
fill 214 155 307 214 156 307 minecraft:prismarine_bricks
fill 214 155 309 214 156 309 minecraft:prismarine_bricks
fill 214 155 311 214 156 311 minecraft:prismarine_bricks
fill 214 155 313 214 156 313 minecraft:prismarine_bricks
fill 214 155 315 214 156 315 minecraft:prismarine_bricks
fill 215 155 306 215 156 306 minecraft:prismarine_bricks
fill 215 155 308 215 156 308 minecraft:prismarine_bricks
fill 215 155 310 215 156 310 minecraft:prismarine_bricks
fill 215 155 312 215 156 312 minecraft:prismarine_bricks
fill 215 155 314 215 156 314 minecraft:prismarine_bricks
fill 215 155 316 215 156 316 minecraft:prismarine_bricks
fill 216 155 307 216 156 307 minecraft:prismarine_bricks
fill 216 155 309 216 156 309 minecraft:prismarine_bricks
fill 216 155 311 216 156 311 minecraft:prismarine_bricks
fill 216 155 313 216 156 313 minecraft:prismarine_bricks
fill 216 155 315 216 156 315 minecraft:prismarine_bricks
fill 217 155 306 217 156 306 minecraft:prismarine_bricks
fill 217 155 308 217 156 308 minecraft:prismarine_bricks
fill 217 155 310 217 156 310 minecraft:prismarine_bricks
fill 217 155 312 217 156 312 minecraft:prismarine_bricks
fill 217 155 314 217 156 314 minecraft:prismarine_bricks
fill 217 155 316 217 156 316 minecraft:prismarine_bricks
fill 218 155 307 218 156 307 minecraft:prismarine_bricks
fill 218 155 309 218 156 309 minecraft:prismarine_bricks
fill 218 155 311 218 156 311 minecraft:prismarine_bricks
fill 218 155 313 218 156 313 minecraft:prismarine_bricks
fill 218 155 315 218 156 315 minecraft:prismarine_bricks
fill 219 155 306 219 156 306 minecraft:prismarine_bricks
fill 219 155 308 219 156 308 minecraft:prismarine_bricks
fill 219 155 310 219 156 310 minecraft:prismarine_bricks
fill 219 155 312 219 156 312 minecraft:prismarine_bricks
fill 219 155 314 219 156 314 minecraft:prismarine_bricks
fill 219 155 316 219 156 316 minecraft:prismarine_bricks
fill 222 155 285 222 156 285 minecraft:prismarine_bricks
fill 222 155 287 222 156 287 minecraft:prismarine_bricks
fill 222 155 289 222 156 289 minecraft:prismarine_bricks
fill 223 155 284 223 156 284 minecraft:prismarine_bricks
fill 223 155 286 223 156 286 minecraft:prismarine_bricks
fill 223 155 288 223 156 288 minecraft:prismarine_bricks
fill 223 155 290 223 156 290 minecraft:prismarine_bricks
fill 224 155 285 224 156 285 minecraft:prismarine_bricks
fill 224 155 287 224 156 287 minecraft:prismarine_bricks
fill 224 155 289 224 156 289 minecraft:prismarine_bricks
fill 225 155 284 225 156 284 minecraft:prismarine_bricks
fill 225 155 286 225 156 286 minecraft:prismarine_bricks
fill 225 155 288 225 156 288 minecraft:prismarine_bricks
fill 225 155 290 225 156 290 minecraft:prismarine_bricks
fill 226 155 285 226 156 285 minecraft:prismarine_bricks
fill 226 155 287 226 156 287 minecraft:prismarine_bricks
fill 226 155 289 226 156 289 minecraft:prismarine_bricks
fill 227 155 284 227 156 284 minecraft:prismarine_bricks
fill 227 155 286 227 156 286 minecraft:prismarine_bricks
fill 227 155 288 227 156 288 minecraft:prismarine_bricks
fill 227 155 290 227 156 290 minecraft:prismarine_bricks
fill 228 155 285 228 156 285 minecraft:prismarine_bricks
fill 228 155 287 228 156 287 minecraft:prismarine_bricks
fill 228 155 289 228 156 289 minecraft:prismarine_bricks
fill 229 155 284 229 156 284 minecraft:prismarine_bricks
fill 229 155 286 229 156 286 minecraft:prismarine_bricks
fill 229 155 288 229 156 288 minecraft:prismarine_bricks
fill 229 155 290 229 156 290 minecraft:prismarine_bricks
fill 230 155 297 230 226 297 minecraft:prismarine_bricks
setblock 230 155 298 minecraft:sea_lantern
fill 230 155 299 230 226 299 minecraft:prismarine_bricks
setblock 230 155 311 minecraft:sea_lantern
fill 230 156 298 230 195 298 minecraft:prismarine_bricks
fill 230 156 311 230 188 311 minecraft:prismarine_bricks
fill 197 157 306 198 158 306 minecraft:white_stained_glass
fill 202 157 289 202 158 289 minecraft:white_stained_glass
setblock 207 157 306 minecraft:sea_lantern
setblock 207 157 308 minecraft:sea_lantern
setblock 207 157 310 minecraft:sea_lantern
setblock 207 157 312 minecraft:sea_lantern
setblock 207 157 314 minecraft:sea_lantern
setblock 207 157 316 minecraft:sea_lantern
setblock 208 157 307 minecraft:sea_lantern
setblock 208 157 309 minecraft:sea_lantern
setblock 208 157 311 minecraft:sea_lantern
setblock 208 157 313 minecraft:sea_lantern
setblock 208 157 315 minecraft:sea_lantern
setblock 209 157 306 minecraft:sea_lantern
setblock 209 157 308 minecraft:sea_lantern
setblock 209 157 310 minecraft:sea_lantern
setblock 209 157 312 minecraft:sea_lantern
setblock 209 157 314 minecraft:sea_lantern
setblock 209 157 316 minecraft:sea_lantern
setblock 210 157 307 minecraft:sea_lantern
setblock 210 157 309 minecraft:sea_lantern
setblock 210 157 311 minecraft:sea_lantern
setblock 210 157 313 minecraft:sea_lantern
setblock 210 157 315 minecraft:sea_lantern
setblock 211 157 306 minecraft:sea_lantern
setblock 211 157 308 minecraft:sea_lantern
setblock 211 157 310 minecraft:sea_lantern
setblock 211 157 312 minecraft:sea_lantern
setblock 211 157 314 minecraft:sea_lantern
setblock 211 157 316 minecraft:sea_lantern
setblock 212 157 307 minecraft:sea_lantern
setblock 212 157 309 minecraft:sea_lantern
setblock 212 157 311 minecraft:sea_lantern
setblock 212 157 313 minecraft:sea_lantern
setblock 212 157 315 minecraft:sea_lantern
setblock 213 157 306 minecraft:sea_lantern
setblock 213 157 308 minecraft:sea_lantern
setblock 213 157 310 minecraft:sea_lantern
setblock 213 157 312 minecraft:sea_lantern
setblock 213 157 314 minecraft:sea_lantern
setblock 213 157 316 minecraft:sea_lantern
setblock 214 157 307 minecraft:sea_lantern
setblock 214 157 309 minecraft:sea_lantern
setblock 214 157 311 minecraft:sea_lantern
setblock 214 157 313 minecraft:sea_lantern
setblock 214 157 315 minecraft:sea_lantern
setblock 215 157 306 minecraft:sea_lantern
setblock 215 157 308 minecraft:sea_lantern
setblock 215 157 310 minecraft:sea_lantern
setblock 215 157 312 minecraft:sea_lantern
setblock 215 157 314 minecraft:sea_lantern
setblock 215 157 316 minecraft:sea_lantern
setblock 216 157 307 minecraft:sea_lantern
setblock 216 157 309 minecraft:sea_lantern
setblock 216 157 311 minecraft:sea_lantern
setblock 216 157 313 minecraft:sea_lantern
setblock 216 157 315 minecraft:sea_lantern
fill 216 157 317 217 224 317 minecraft:prismarine_bricks
setblock 217 157 306 minecraft:sea_lantern
setblock 217 157 308 minecraft:sea_lantern
setblock 217 157 310 minecraft:sea_lantern
setblock 217 157 312 minecraft:sea_lantern
setblock 217 157 314 minecraft:sea_lantern
setblock 217 157 316 minecraft:sea_lantern
setblock 218 157 307 minecraft:sea_lantern
setblock 218 157 309 minecraft:sea_lantern
setblock 218 157 311 minecraft:sea_lantern
setblock 218 157 313 minecraft:sea_lantern
setblock 218 157 315 minecraft:sea_lantern
setblock 218 157 317 minecraft:sea_lantern
setblock 219 157 306 minecraft:sea_lantern
setblock 219 157 308 minecraft:sea_lantern
setblock 219 157 310 minecraft:sea_lantern
setblock 219 157 312 minecraft:sea_lantern
setblock 219 157 314 minecraft:sea_lantern
setblock 219 157 316 minecraft:sea_lantern
fill 219 157 317 221 226 317 minecraft:prismarine_bricks
setblock 222 157 285 minecraft:sea_lantern
setblock 222 157 287 minecraft:sea_lantern
setblock 222 157 289 minecraft:sea_lantern
setblock 223 157 284 minecraft:sea_lantern
setblock 223 157 286 minecraft:sea_lantern
setblock 223 157 288 minecraft:sea_lantern
setblock 223 157 290 minecraft:sea_lantern
setblock 224 157 285 minecraft:sea_lantern
setblock 224 157 287 minecraft:sea_lantern
setblock 224 157 289 minecraft:sea_lantern
setblock 225 157 284 minecraft:sea_lantern
setblock 225 157 286 minecraft:sea_lantern
setblock 225 157 288 minecraft:sea_lantern
setblock 225 157 290 minecraft:sea_lantern
setblock 226 157 285 minecraft:sea_lantern
setblock 226 157 287 minecraft:sea_lantern
setblock 226 157 289 minecraft:sea_lantern
setblock 227 157 284 minecraft:sea_lantern
setblock 227 157 286 minecraft:sea_lantern
setblock 227 157 288 minecraft:sea_lantern
setblock 227 157 290 minecraft:sea_lantern
setblock 228 157 285 minecraft:sea_lantern
setblock 228 157 287 minecraft:sea_lantern
setblock 228 157 289 minecraft:sea_lantern
setblock 229 157 284 minecraft:sea_lantern
setblock 229 157 286 minecraft:sea_lantern
setblock 229 157 288 minecraft:sea_lantern
setblock 229 157 290 minecraft:sea_lantern
setblock 230 157 293 minecraft:sea_lantern
fill 230 157 294 230 169 294 minecraft:prismarine_bricks
fill 189 158 292 189 159 294 minecraft:prismarine_bricks
fill 207 158 306 207 159 306 minecraft:prismarine_bricks
fill 207 158 308 207 159 308 minecraft:prismarine_bricks
fill 207 158 310 207 159 310 minecraft:prismarine_bricks
fill 207 158 312 207 159 312 minecraft:prismarine_bricks
fill 207 158 314 207 159 314 minecraft:prismarine_bricks
fill 207 158 316 207 159 316 minecraft:prismarine_bricks
fill 208 158 307 208 159 307 minecraft:prismarine_bricks
fill 208 158 309 208 159 309 minecraft:prismarine_bricks
fill 208 158 311 208 159 311 minecraft:prismarine_bricks
fill 208 158 313 208 159 313 minecraft:quartz_pillar
fill 208 158 315 208 159 315 minecraft:quartz_pillar
fill 209 158 306 209 159 306 minecraft:prismarine_bricks
fill 209 158 308 209 159 308 minecraft:prismarine_bricks
fill 209 158 310 209 159 310 minecraft:prismarine_bricks
fill 209 158 312 209 159 312 minecraft:prismarine_bricks
fill 209 158 314 209 159 314 minecraft:quartz_pillar
fill 209 158 316 209 159 316 minecraft:prismarine_bricks
fill 210 158 307 210 159 307 minecraft:prismarine_bricks
fill 210 158 309 210 159 309 minecraft:prismarine_bricks
fill 210 158 311 210 159 311 minecraft:prismarine_bricks
fill 210 158 313 210 159 313 minecraft:quartz_pillar
fill 210 158 315 210 159 315 minecraft:quartz_pillar
fill 211 158 306 211 159 306 minecraft:prismarine_bricks
fill 211 158 308 211 159 308 minecraft:prismarine_bricks
fill 211 158 310 211 159 310 minecraft:prismarine_bricks
fill 211 158 312 211 159 312 minecraft:prismarine_bricks
fill 211 158 314 211 159 314 minecraft:prismarine_bricks
fill 211 158 316 211 159 316 minecraft:prismarine_bricks
fill 212 158 284 212 159 284 minecraft:white_stained_glass
fill 212 158 307 212 159 307 minecraft:prismarine_bricks
fill 212 158 309 212 159 309 minecraft:prismarine_bricks
fill 212 158 311 212 159 311 minecraft:prismarine_bricks
fill 212 158 313 212 159 313 minecraft:prismarine_bricks
fill 212 158 315 212 159 315 minecraft:prismarine_bricks
fill 213 158 306 213 159 306 minecraft:prismarine_bricks
fill 213 158 308 213 159 308 minecraft:prismarine_bricks
fill 213 158 310 213 159 310 minecraft:prismarine_bricks
fill 213 158 312 213 159 312 minecraft:prismarine_bricks
fill 213 158 314 213 159 314 minecraft:prismarine_bricks
fill 213 158 316 213 159 316 minecraft:prismarine_bricks
fill 214 158 307 214 159 307 minecraft:prismarine_bricks
fill 214 158 309 214 159 309 minecraft:prismarine_bricks
fill 214 158 311 214 159 311 minecraft:prismarine_bricks
fill 214 158 313 214 159 313 minecraft:prismarine_bricks
fill 214 158 315 214 159 315 minecraft:prismarine_bricks
fill 215 158 306 215 159 306 minecraft:prismarine_bricks
fill 215 158 308 215 159 308 minecraft:prismarine_bricks
fill 215 158 310 215 159 310 minecraft:prismarine_bricks
fill 215 158 312 215 159 312 minecraft:prismarine_bricks
fill 215 158 314 215 159 314 minecraft:prismarine_bricks
fill 215 158 316 215 159 316 minecraft:prismarine_bricks
fill 216 158 307 216 159 307 minecraft:prismarine_bricks
fill 216 158 309 216 159 309 minecraft:prismarine_bricks
fill 216 158 311 216 159 311 minecraft:prismarine_bricks
fill 216 158 313 216 159 313 minecraft:prismarine_bricks
fill 216 158 315 216 159 315 minecraft:prismarine_bricks
fill 217 158 306 217 159 306 minecraft:prismarine_bricks
fill 217 158 308 217 159 308 minecraft:prismarine_bricks
fill 217 158 310 217 159 310 minecraft:prismarine_bricks
fill 217 158 312 217 159 312 minecraft:prismarine_bricks
fill 217 158 314 217 159 314 minecraft:prismarine_bricks
fill 217 158 316 217 159 316 minecraft:prismarine_bricks
fill 218 158 307 218 159 307 minecraft:prismarine_bricks
fill 218 158 309 218 159 309 minecraft:prismarine_bricks
fill 218 158 311 218 159 311 minecraft:prismarine_bricks
fill 218 158 313 218 159 313 minecraft:prismarine_bricks
fill 218 158 315 218 159 315 minecraft:prismarine_bricks
fill 218 158 317 218 226 317 minecraft:prismarine_bricks
fill 219 158 306 219 159 306 minecraft:prismarine_bricks
fill 219 158 308 219 159 308 minecraft:prismarine_bricks
fill 219 158 310 219 159 310 minecraft:prismarine_bricks
fill 219 158 312 219 159 312 minecraft:prismarine_bricks
fill 219 158 314 219 159 314 minecraft:prismarine_bricks
fill 219 158 316 219 159 316 minecraft:prismarine_bricks
fill 222 158 285 222 159 285 minecraft:prismarine_bricks
fill 222 158 287 222 159 287 minecraft:prismarine_bricks
fill 222 158 289 222 159 289 minecraft:prismarine_bricks
fill 223 158 284 223 159 284 minecraft:prismarine_bricks
fill 223 158 286 223 159 286 minecraft:prismarine_bricks
fill 223 158 288 223 159 288 minecraft:prismarine_bricks
fill 223 158 290 223 159 290 minecraft:prismarine_bricks
fill 224 158 285 224 159 285 minecraft:prismarine_bricks
fill 224 158 287 224 159 287 minecraft:prismarine_bricks
fill 224 158 289 224 159 289 minecraft:prismarine_bricks
fill 225 158 284 225 159 284 minecraft:prismarine_bricks
fill 225 158 286 225 159 286 minecraft:prismarine_bricks
fill 225 158 288 225 159 288 minecraft:prismarine_bricks
fill 225 158 290 225 159 290 minecraft:prismarine_bricks
fill 226 158 285 226 159 285 minecraft:prismarine_bricks
fill 226 158 287 226 159 287 minecraft:prismarine_bricks
fill 226 158 289 226 159 289 minecraft:prismarine_bricks
fill 227 158 284 227 159 284 minecraft:prismarine_bricks
fill 227 158 286 227 159 286 minecraft:prismarine_bricks
fill 227 158 288 227 159 288 minecraft:prismarine_bricks
fill 227 158 290 227 159 290 minecraft:prismarine_bricks
fill 228 158 285 228 159 285 minecraft:prismarine_bricks
fill 228 158 287 228 159 287 minecraft:prismarine_bricks
fill 228 158 289 228 159 289 minecraft:prismarine_bricks
fill 228 158 292 229 159 294 minecraft:prismarine_bricks
fill 229 158 284 229 159 284 minecraft:prismarine_bricks
fill 229 158 286 229 159 286 minecraft:prismarine_bricks
fill 229 158 288 229 159 288 minecraft:prismarine_bricks
fill 229 158 290 229 159 290 minecraft:prismarine_bricks
fill 230 158 293 230 195 293 minecraft:prismarine_bricks
fill 188 159 289 188 179 289 minecraft:prismarine_bricks
setblock 188 159 290 minecraft:sea_lantern
fill 188 159 291 188 165 292 minecraft:prismarine_bricks
fill 190 159 292 190 160 294 minecraft:prismarine_bricks
setblock 191 159 285 minecraft:light[level=12]
setblock 191 159 286 minecraft:light[level=15]
setblock 191 159 292 minecraft:light[level=12]
fill 191 159 293 191 161 293 minecraft:prismarine_bricks
setblock 191 159 294 minecraft:light[level=15]
setblock 191 159 299 minecraft:light[level=12]
setblock 191 159 302 minecraft:light[level=15]
setblock 191 159 306 minecraft:light[level=12]
setblock 191 159 310 minecraft:light[level=15]
setblock 198 159 278 minecraft:light[level=12]
setblock 198 159 285 minecraft:light[level=12]
setblock 198 159 292 minecraft:light[level=12]
setblock 198 159 299 minecraft:light[level=12]
setblock 198 159 306 minecraft:light[level=12]
setblock 198 159 313 minecraft:light[level=12]
setblock 199 159 278 minecraft:light[level=15]
setblock 199 159 286 minecraft:light[level=15]
setblock 199 159 294 minecraft:light[level=15]
setblock 199 159 302 minecraft:light[level=15]
setblock 199 159 310 minecraft:light[level=15]
setblock 205 159 278 minecraft:light[level=12]
setblock 205 159 285 minecraft:light[level=12]
setblock 205 159 292 minecraft:light[level=12]
setblock 205 159 299 minecraft:light[level=12]
setblock 205 159 306 minecraft:light[level=12]
setblock 205 159 313 minecraft:light[level=12]
setblock 207 159 278 minecraft:light[level=15]
setblock 207 159 286 minecraft:light[level=15]
setblock 207 159 294 minecraft:light[level=15]
setblock 207 159 302 minecraft:light[level=15]
setblock 212 159 278 minecraft:light[level=12]
setblock 212 159 285 minecraft:light[level=12]
setblock 212 159 292 minecraft:light[level=12]
setblock 215 159 278 minecraft:light[level=15]
setblock 215 159 286 minecraft:light[level=15]
setblock 215 159 294 minecraft:light[level=15]
setblock 215 159 302 minecraft:light[level=15]
setblock 219 159 278 minecraft:light[level=12]
setblock 219 159 285 minecraft:light[level=12]
setblock 219 159 292 minecraft:light[level=12]
setblock 219 159 299 minecraft:light[level=12]
fill 222 159 312 222 159 314 minecraft:dark_prismarine
setblock 223 159 278 minecraft:light[level=15]
setblock 223 159 294 minecraft:light[level=15]
setblock 223 159 302 minecraft:light[level=15]
setblock 223 159 310 minecraft:light[level=15]
setblock 223 159 311 minecraft:dark_prismarine
fill 223 159 315 225 159 315 minecraft:dark_prismarine
fill 225 159 311 226 159 311 minecraft:dark_prismarine
setblock 226 159 292 minecraft:light[level=12]
fill 226 159 293 227 161 293 minecraft:prismarine_bricks
setblock 226 159 299 minecraft:light[level=12]
setblock 226 159 306 minecraft:light[level=12]
fill 227 159 292 227 160 292 minecraft:prismarine_bricks
fill 227 159 294 227 160 294 minecraft:prismarine_bricks
fill 188 160 290 188 222 290 minecraft:prismarine_bricks
setblock 189 160 293 minecraft:prismarine_bricks
fill 190 160 285 190 165 287 minecraft:prismarine_bricks
fill 190 160 298 190 165 299 minecraft:prismarine_bricks
fill 190 160 309 190 165 311 minecraft:prismarine_bricks
fill 191 160 292 191 161 292 minecraft:prismarine_bricks
fill 191 160 294 191 161 294 minecraft:prismarine_bricks
fill 192 160 293 192 162 293 minecraft:prismarine_bricks
fill 196 160 315 198 165 315 minecraft:prismarine_bricks
fill 200 160 277 202 165 277 minecraft:prismarine_bricks
setblock 207 160 306 minecraft:sea_lantern
setblock 207 160 308 minecraft:sea_lantern
setblock 207 160 310 minecraft:sea_lantern
setblock 207 160 312 minecraft:sea_lantern
setblock 207 160 314 minecraft:sea_lantern
setblock 207 160 316 minecraft:sea_lantern
setblock 208 160 307 minecraft:sea_lantern
setblock 208 160 309 minecraft:sea_lantern
setblock 208 160 311 minecraft:sea_lantern
setblock 208 160 313 minecraft:sea_lantern
setblock 208 160 315 minecraft:sea_lantern
setblock 209 160 306 minecraft:sea_lantern
setblock 209 160 308 minecraft:sea_lantern
setblock 209 160 310 minecraft:sea_lantern
setblock 209 160 312 minecraft:sea_lantern
setblock 209 160 314 minecraft:sea_lantern
setblock 209 160 316 minecraft:sea_lantern
setblock 210 160 307 minecraft:sea_lantern
setblock 210 160 309 minecraft:sea_lantern
setblock 210 160 311 minecraft:sea_lantern
setblock 210 160 313 minecraft:sea_lantern
setblock 210 160 315 minecraft:sea_lantern
setblock 211 160 306 minecraft:sea_lantern
setblock 211 160 308 minecraft:sea_lantern
setblock 211 160 310 minecraft:sea_lantern
setblock 211 160 312 minecraft:sea_lantern
setblock 211 160 314 minecraft:sea_lantern
setblock 211 160 316 minecraft:sea_lantern
fill 212 160 277 214 165 277 minecraft:prismarine_bricks
setblock 212 160 307 minecraft:sea_lantern
setblock 212 160 309 minecraft:sea_lantern
setblock 212 160 311 minecraft:sea_lantern
setblock 212 160 313 minecraft:sea_lantern
setblock 212 160 315 minecraft:sea_lantern
setblock 213 160 306 minecraft:sea_lantern
setblock 213 160 308 minecraft:sea_lantern
setblock 213 160 310 minecraft:sea_lantern
setblock 213 160 312 minecraft:sea_lantern
setblock 213 160 314 minecraft:sea_lantern
setblock 213 160 316 minecraft:sea_lantern
setblock 214 160 307 minecraft:sea_lantern
setblock 214 160 309 minecraft:sea_lantern
setblock 214 160 311 minecraft:sea_lantern
setblock 214 160 313 minecraft:sea_lantern
setblock 214 160 315 minecraft:sea_lantern
setblock 215 160 306 minecraft:sea_lantern
setblock 215 160 308 minecraft:sea_lantern
setblock 215 160 310 minecraft:sea_lantern
setblock 215 160 312 minecraft:sea_lantern
setblock 215 160 314 minecraft:sea_lantern
setblock 215 160 316 minecraft:sea_lantern
setblock 216 160 307 minecraft:sea_lantern
setblock 216 160 309 minecraft:sea_lantern
setblock 216 160 311 minecraft:sea_lantern
setblock 216 160 313 minecraft:sea_lantern
setblock 216 160 315 minecraft:sea_lantern
setblock 217 160 306 minecraft:sea_lantern
setblock 217 160 308 minecraft:sea_lantern
setblock 217 160 310 minecraft:sea_lantern
setblock 217 160 312 minecraft:sea_lantern
setblock 217 160 314 minecraft:sea_lantern
setblock 217 160 316 minecraft:sea_lantern
setblock 218 160 307 minecraft:sea_lantern
setblock 218 160 309 minecraft:sea_lantern
setblock 218 160 311 minecraft:sea_lantern
setblock 218 160 313 minecraft:sea_lantern
setblock 218 160 315 minecraft:sea_lantern
setblock 219 160 306 minecraft:sea_lantern
setblock 219 160 308 minecraft:sea_lantern
setblock 219 160 310 minecraft:sea_lantern
setblock 219 160 312 minecraft:sea_lantern
setblock 219 160 314 minecraft:sea_lantern
setblock 219 160 316 minecraft:sea_lantern
fill 220 160 315 222 165 315 minecraft:prismarine_bricks
setblock 222 160 285 minecraft:sea_lantern
setblock 222 160 287 minecraft:sea_lantern
setblock 222 160 289 minecraft:sea_lantern
setblock 223 160 284 minecraft:sea_lantern
setblock 223 160 286 minecraft:sea_lantern
setblock 223 160 288 minecraft:sea_lantern
setblock 223 160 290 minecraft:sea_lantern
fill 224 160 277 226 165 277 minecraft:prismarine_bricks
setblock 224 160 285 minecraft:sea_lantern
setblock 224 160 287 minecraft:sea_lantern
setblock 224 160 289 minecraft:sea_lantern
setblock 225 160 284 minecraft:sea_lantern
setblock 225 160 286 minecraft:sea_lantern
setblock 225 160 288 minecraft:sea_lantern
setblock 225 160 290 minecraft:sea_lantern
fill 225 160 293 225 162 293 minecraft:prismarine_bricks
setblock 226 160 285 minecraft:sea_lantern
setblock 226 160 287 minecraft:sea_lantern
setblock 226 160 289 minecraft:sea_lantern
fill 226 160 292 226 161 292 minecraft:prismarine_bricks
fill 226 160 294 226 161 294 minecraft:prismarine_bricks
setblock 227 160 284 minecraft:sea_lantern
setblock 227 160 286 minecraft:sea_lantern
setblock 227 160 288 minecraft:sea_lantern
setblock 227 160 290 minecraft:sea_lantern
setblock 228 160 285 minecraft:sea_lantern
setblock 228 160 287 minecraft:sea_lantern
setblock 228 160 289 minecraft:sea_lantern
setblock 228 160 293 minecraft:prismarine_bricks
fill 228 160 298 228 165 299 minecraft:prismarine_bricks
fill 228 160 309 228 165 311 minecraft:prismarine_bricks
setblock 229 160 284 minecraft:sea_lantern
setblock 229 160 286 minecraft:sea_lantern
setblock 229 160 288 minecraft:sea_lantern
setblock 229 160 290 minecraft:sea_lantern
setblock 229 160 293 minecraft:gold_block
setblock 189 161 293 minecraft:gold_block
setblock 190 161 293 minecraft:prismarine_bricks
fill 192 161 292 193 162 292 minecraft:prismarine_bricks
fill 192 161 294 193 162 294 minecraft:prismarine_bricks
fill 193 161 293 193 163 293 minecraft:prismarine_bricks
fill 207 161 306 207 162 306 minecraft:prismarine_bricks
fill 207 161 308 207 162 308 minecraft:prismarine_bricks
fill 207 161 310 207 162 310 minecraft:prismarine_bricks
fill 207 161 312 207 162 312 minecraft:prismarine_bricks
fill 207 161 314 207 162 314 minecraft:prismarine_bricks
fill 207 161 316 207 213 317 minecraft:prismarine_bricks
fill 208 161 307 208 162 307 minecraft:prismarine_bricks
fill 208 161 309 208 162 309 minecraft:prismarine_bricks
fill 208 161 311 208 162 311 minecraft:prismarine_bricks
fill 208 161 313 208 165 313 minecraft:quartz_pillar
fill 208 161 315 208 165 315 minecraft:quartz_pillar
fill 208 161 317 209 224 317 minecraft:prismarine_bricks
fill 209 161 306 209 162 306 minecraft:prismarine_bricks
fill 209 161 308 209 162 308 minecraft:prismarine_bricks
fill 209 161 310 209 162 310 minecraft:prismarine_bricks
fill 209 161 312 209 162 312 minecraft:prismarine_bricks
fill 209 161 314 209 165 314 minecraft:quartz_pillar
fill 209 161 316 209 216 316 minecraft:prismarine_bricks
fill 210 161 307 210 162 307 minecraft:prismarine_bricks
fill 210 161 309 210 162 309 minecraft:prismarine_bricks
fill 210 161 311 210 162 311 minecraft:prismarine_bricks
fill 210 161 313 210 165 313 minecraft:quartz_pillar
fill 210 161 315 210 165 315 minecraft:quartz_pillar
setblock 210 161 317 minecraft:sea_lantern
fill 211 161 306 211 162 306 minecraft:prismarine_bricks
fill 211 161 308 211 162 308 minecraft:prismarine_bricks
fill 211 161 310 211 162 310 minecraft:prismarine_bricks
fill 211 161 312 211 162 312 minecraft:prismarine_bricks
fill 211 161 314 211 162 314 minecraft:prismarine_bricks
fill 211 161 316 211 162 317 minecraft:prismarine_bricks
fill 212 161 307 212 162 307 minecraft:prismarine_bricks
fill 212 161 309 212 162 309 minecraft:prismarine_bricks
fill 212 161 311 212 162 311 minecraft:prismarine_bricks
fill 212 161 313 212 162 313 minecraft:prismarine_bricks
fill 212 161 315 212 162 315 minecraft:prismarine_bricks
fill 212 161 317 212 165 317 minecraft:prismarine_bricks
fill 213 161 306 213 162 306 minecraft:prismarine_bricks
fill 213 161 308 213 162 308 minecraft:prismarine_bricks
fill 213 161 310 213 162 310 minecraft:prismarine_bricks
fill 213 161 312 213 162 312 minecraft:prismarine_bricks
fill 213 161 314 213 162 314 minecraft:prismarine_bricks
fill 213 161 316 213 162 316 minecraft:prismarine_bricks
fill 214 161 307 214 162 307 minecraft:prismarine_bricks
fill 214 161 309 214 162 309 minecraft:prismarine_bricks
fill 214 161 311 214 162 311 minecraft:prismarine_bricks
fill 214 161 313 214 162 313 minecraft:prismarine_bricks
fill 214 161 315 214 162 315 minecraft:prismarine_bricks
fill 215 161 306 215 162 306 minecraft:prismarine_bricks
fill 215 161 308 215 162 308 minecraft:prismarine_bricks
fill 215 161 310 215 162 310 minecraft:prismarine_bricks
fill 215 161 312 215 162 312 minecraft:prismarine_bricks
fill 215 161 314 215 162 314 minecraft:prismarine_bricks
fill 215 161 316 215 162 316 minecraft:prismarine_bricks
fill 216 161 307 216 162 307 minecraft:prismarine_bricks
fill 216 161 309 216 162 309 minecraft:prismarine_bricks
fill 216 161 311 216 162 311 minecraft:prismarine_bricks
fill 216 161 313 216 162 313 minecraft:prismarine_bricks
fill 216 161 315 216 162 315 minecraft:prismarine_bricks
fill 217 161 306 217 162 306 minecraft:prismarine_bricks
fill 217 161 308 217 162 308 minecraft:prismarine_bricks
fill 217 161 310 217 162 310 minecraft:prismarine_bricks
fill 217 161 312 217 162 312 minecraft:prismarine_bricks
fill 217 161 314 217 162 314 minecraft:prismarine_bricks
fill 217 161 316 217 162 316 minecraft:prismarine_bricks
fill 218 161 307 218 162 307 minecraft:prismarine_bricks
fill 218 161 309 218 162 309 minecraft:prismarine_bricks
fill 218 161 311 218 162 311 minecraft:prismarine_bricks
fill 218 161 313 218 162 313 minecraft:prismarine_bricks
fill 218 161 315 218 162 315 minecraft:prismarine_bricks
setblock 219 161 275 minecraft:sea_lantern
fill 219 161 306 219 162 306 minecraft:prismarine_bricks
fill 219 161 308 219 162 308 minecraft:prismarine_bricks
fill 219 161 310 219 162 310 minecraft:prismarine_bricks
fill 219 161 312 219 162 312 minecraft:prismarine_bricks
fill 219 161 314 219 162 314 minecraft:prismarine_bricks
fill 219 161 316 219 216 316 minecraft:prismarine_bricks
fill 222 161 285 222 162 285 minecraft:prismarine_bricks
fill 222 161 287 222 162 287 minecraft:prismarine_bricks
fill 222 161 289 222 162 289 minecraft:prismarine_bricks
fill 223 161 284 223 162 284 minecraft:prismarine_bricks
fill 223 161 286 223 162 286 minecraft:prismarine_bricks
fill 223 161 288 223 162 288 minecraft:prismarine_bricks
fill 223 161 290 223 162 290 minecraft:prismarine_bricks
fill 224 161 285 224 162 285 minecraft:prismarine_bricks
fill 224 161 287 224 162 287 minecraft:prismarine_bricks
fill 224 161 289 224 162 289 minecraft:prismarine_bricks
fill 224 161 292 224 162 294 minecraft:prismarine_bricks
fill 225 161 284 225 162 284 minecraft:prismarine_bricks
fill 225 161 286 225 162 286 minecraft:prismarine_bricks
fill 225 161 288 225 162 288 minecraft:prismarine_bricks
fill 225 161 290 225 162 290 minecraft:prismarine_bricks
fill 225 161 292 225 162 292 minecraft:prismarine_bricks
fill 225 161 294 225 162 294 minecraft:prismarine_bricks
fill 226 161 285 226 162 285 minecraft:prismarine_bricks
fill 226 161 287 226 162 287 minecraft:prismarine_bricks
fill 226 161 289 226 162 289 minecraft:prismarine_bricks
fill 227 161 284 227 162 284 minecraft:prismarine_bricks
fill 227 161 286 227 162 286 minecraft:prismarine_bricks
fill 227 161 288 227 162 288 minecraft:prismarine_bricks
fill 227 161 290 227 162 290 minecraft:prismarine_bricks
fill 228 161 285 228 165 285 minecraft:prismarine_bricks
fill 228 161 287 228 165 287 minecraft:prismarine_bricks
fill 228 161 289 228 162 289 minecraft:prismarine_bricks
setblock 228 161 293 minecraft:gold_block
fill 229 161 284 229 216 284 minecraft:prismarine_bricks
fill 229 161 286 229 216 286 minecraft:prismarine_bricks
fill 229 161 288 229 162 288 minecraft:prismarine_bricks
fill 229 161 290 229 162 290 minecraft:prismarine_bricks
setblock 191 162 293 minecraft:gold_block
fill 194 162 292 194 163 294 minecraft:prismarine_bricks
fill 195 162 293 195 164 293 minecraft:prismarine_bricks
setblock 204 162 275 minecraft:sea_lantern
fill 210 162 317 210 226 317 minecraft:prismarine_bricks
fill 219 162 275 219 165 275 minecraft:prismarine_bricks
fill 222 162 293 223 164 293 minecraft:prismarine_bricks
fill 223 162 292 223 163 292 minecraft:prismarine_bricks
fill 223 162 294 223 163 294 minecraft:prismarine_bricks
setblock 226 162 293 minecraft:gold_block
setblock 192 163 293 minecraft:gold_block
fill 195 163 277 195 176 277 minecraft:green_terracotta
fill 195 163 292 195 164 292 minecraft:prismarine_bricks
fill 195 163 294 195 164 294 minecraft:prismarine_bricks
fill 196 163 293 196 165 293 minecraft:prismarine_bricks
fill 204 163 275 204 226 275 minecraft:prismarine_bricks
fill 208 163 307 218 163 312 minecraft:gold_block
fill 211 163 313 218 163 315 minecraft:gold_block
fill 211 163 317 211 223 317 minecraft:prismarine_bricks
fill 221 163 293 221 165 293 minecraft:prismarine_bricks
fill 222 163 292 222 164 292 minecraft:prismarine_bricks
fill 222 163 294 222 164 294 minecraft:prismarine_bricks
fill 223 163 285 227 163 289 minecraft:gold_block
setblock 224 163 293 minecraft:prismarine_bricks
setblock 225 163 293 minecraft:gold_block
fill 228 163 288 228 163 289 minecraft:gold_block
setblock 193 164 293 minecraft:gold_block
setblock 194 164 293 minecraft:prismarine_bricks
fill 196 164 292 197 164 292 minecraft:prismarine_bricks
fill 196 164 294 197 164 294 minecraft:prismarine_bricks
fill 197 164 293 198 166 293 minecraft:prismarine_bricks
fill 209 164 308 217 164 312 minecraft:gold_block
fill 211 164 313 217 164 314 minecraft:gold_block
fill 219 164 293 220 166 293 minecraft:prismarine_bricks
fill 220 164 292 221 164 292 minecraft:prismarine_bricks
fill 220 164 294 221 164 294 minecraft:prismarine_bricks
fill 224 164 286 227 164 288 minecraft:gold_block
setblock 224 164 293 minecraft:gold_block
fill 189 165 279 189 165 284 minecraft:dark_prismarine
fill 189 165 291 189 165 296 minecraft:dark_prismarine
fill 189 165 303 189 165 308 minecraft:dark_prismarine
fill 189 165 315 189 165 316 minecraft:dark_prismarine
fill 190 165 316 193 165 316 minecraft:dark_prismarine
setblock 191 165 285 minecraft:light[level=12]
setblock 191 165 292 minecraft:light[level=12]
setblock 191 165 299 minecraft:light[level=12]
setblock 191 165 306 minecraft:light[level=12]
fill 193 165 276 198 165 276 minecraft:dark_prismarine
fill 194 165 293 195 165 293 minecraft:gold_block
fill 197 165 292 199 165 292 minecraft:prismarine_bricks
fill 197 165 294 199 165 294 minecraft:prismarine_bricks
setblock 198 165 278 minecraft:light[level=12]
setblock 198 165 285 minecraft:light[level=12]
setblock 198 165 299 minecraft:light[level=12]
setblock 198 165 306 minecraft:light[level=12]
setblock 198 165 313 minecraft:light[level=12]
fill 199 165 293 200 167 293 minecraft:prismarine_bricks
fill 200 165 316 205 165 316 minecraft:dark_prismarine
fill 205 165 276 210 165 276 minecraft:dark_prismarine
setblock 205 165 278 minecraft:light[level=12]
setblock 205 165 285 minecraft:light[level=12]
setblock 205 165 292 minecraft:light[level=12]
setblock 205 165 299 minecraft:light[level=12]
setblock 205 165 306 minecraft:light[level=12]
setblock 205 165 313 minecraft:light[level=12]
fill 210 165 309 216 165 312 minecraft:gold_block
fill 211 165 313 216 165 313 minecraft:gold_block
setblock 212 165 278 minecraft:light[level=12]
setblock 212 165 285 minecraft:light[level=12]
setblock 212 165 292 minecraft:light[level=12]
setblock 212 165 306 minecraft:light[level=12]
fill 212 165 316 217 165 316 minecraft:dark_prismarine
fill 217 165 276 222 165 276 minecraft:dark_prismarine
fill 217 165 293 218 167 293 minecraft:prismarine_bricks
fill 218 165 292 220 165 292 minecraft:prismarine_bricks
fill 218 165 294 220 165 294 minecraft:prismarine_bricks
setblock 219 165 278 minecraft:light[level=12]
setblock 219 165 285 minecraft:light[level=12]
setblock 219 165 299 minecraft:light[level=12]
setblock 219 165 306 minecraft:light[level=12]
setblock 219 165 313 minecraft:light[level=12]
fill 222 165 293 223 165 293 minecraft:gold_block
fill 224 165 316 229 165 316 minecraft:dark_prismarine
fill 225 165 287 226 166 287 minecraft:gold_block
setblock 226 165 285 minecraft:light[level=12]
setblock 226 165 292 minecraft:light[level=12]
setblock 226 165 299 minecraft:light[level=12]
setblock 226 165 306 minecraft:light[level=12]
fill 229 165 276 229 165 281 minecraft:dark_prismarine
fill 229 165 288 229 165 293 minecraft:dark_prismarine
fill 229 165 300 229 165 305 minecraft:dark_prismarine
fill 229 165 312 229 165 315 minecraft:dark_prismarine
fill 188 166 281 188 171 284 minecraft:sea_lantern
setblock 188 166 291 minecraft:sea_lantern
fill 188 166 292 188 226 292 minecraft:prismarine_bricks
fill 188 166 293 188 171 296 minecraft:sea_lantern
fill 188 166 305 188 171 308 minecraft:sea_lantern
fill 188 166 317 191 171 317 minecraft:sea_lantern
fill 189 166 296 193 167 296 minecraft:prismarine_bricks
fill 190 166 279 194 167 279 minecraft:prismarine_bricks
fill 190 166 295 192 167 295 minecraft:prismarine_bricks
fill 190 166 297 192 167 297 minecraft:prismarine_bricks
fill 190 166 313 194 167 313 minecraft:prismarine_bricks
fill 191 166 278 193 167 278 minecraft:prismarine_bricks
fill 191 166 280 193 167 280 minecraft:prismarine_bricks
fill 191 166 294 191 167 294 minecraft:prismarine_bricks
fill 191 166 298 191 167 298 minecraft:prismarine_bricks
fill 191 166 312 193 167 312 minecraft:prismarine_bricks
fill 191 166 314 193 167 314 minecraft:prismarine_bricks
fill 192 166 277 192 167 277 minecraft:prismarine_bricks
fill 192 166 281 192 167 281 minecraft:prismarine_bricks
fill 192 166 311 192 167 311 minecraft:prismarine_bricks
fill 192 166 315 192 167 315 minecraft:prismarine_bricks
fill 195 166 275 198 171 275 minecraft:sea_lantern
setblock 196 166 293 minecraft:gold_block
fill 198 166 292 201 166 292 minecraft:prismarine_bricks
fill 198 166 294 201 166 294 minecraft:prismarine_bricks
fill 200 166 317 203 171 317 minecraft:sea_lantern
fill 201 166 293 202 168 293 minecraft:prismarine_bricks
fill 204 166 317 205 181 317 minecraft:prismarine_bricks
fill 207 166 275 210 171 275 minecraft:sea_lantern
fill 207 166 278 211 167 278 minecraft:prismarine_bricks
fill 207 166 314 211 167 314 minecraft:prismarine_bricks
fill 208 166 277 210 167 277 minecraft:prismarine_bricks
fill 208 166 279 210 167 279 minecraft:prismarine_bricks
fill 208 166 313 210 167 313 minecraft:prismarine_bricks
fill 208 166 315 210 167 315 minecraft:prismarine_bricks
fill 209 166 276 209 167 276 minecraft:prismarine_bricks
fill 209 166 280 209 167 280 minecraft:prismarine_bricks
fill 209 166 312 209 167 312 minecraft:prismarine_bricks
fill 211 166 310 215 166 312 minecraft:gold_block
fill 212 166 317 215 171 317 minecraft:sea_lantern
fill 213 166 275 213 166 276 minecraft:prismarine_bricks
setblock 214 166 275 minecraft:sea_lantern
fill 214 166 276 215 216 276 minecraft:prismarine_bricks
fill 215 166 275 215 226 275 minecraft:prismarine_bricks
fill 215 166 293 216 168 293 minecraft:prismarine_bricks
fill 216 166 292 219 166 292 minecraft:prismarine_bricks
fill 216 166 294 219 166 294 minecraft:prismarine_bricks
fill 219 166 275 222 171 275 minecraft:sea_lantern
setblock 221 166 293 minecraft:gold_block
fill 224 166 279 228 167 279 minecraft:prismarine_bricks
fill 224 166 317 227 171 317 minecraft:sea_lantern
fill 225 166 278 227 167 278 minecraft:prismarine_bricks
fill 225 166 280 227 167 280 minecraft:prismarine_bricks
fill 225 166 286 226 166 286 minecraft:gold_block
fill 225 166 288 226 166 288 minecraft:gold_block
fill 225 166 296 228 167 296 minecraft:prismarine_bricks
fill 225 166 312 227 167 314 minecraft:prismarine_bricks
fill 226 166 277 226 167 277 minecraft:prismarine_bricks
fill 226 166 281 226 167 281 minecraft:prismarine_bricks
fill 226 166 295 228 167 295 minecraft:prismarine_bricks
fill 226 166 297 228 167 297 minecraft:prismarine_bricks
fill 226 166 311 226 167 311 minecraft:prismarine_bricks
fill 226 166 315 226 167 315 minecraft:prismarine_bricks
fill 227 166 294 227 167 294 minecraft:prismarine_bricks
fill 227 166 298 227 167 298 minecraft:prismarine_bricks
fill 228 166 313 228 167 313 minecraft:prismarine_bricks
fill 230 166 276 230 171 279 minecraft:sea_lantern
fill 230 166 288 230 171 291 minecraft:sea_lantern
fill 230 166 300 230 171 303 minecraft:sea_lantern
fill 230 166 312 230 171 315 minecraft:sea_lantern
fill 188 167 291 188 222 291 minecraft:prismarine_bricks
setblock 191 167 286 minecraft:light[level=15]
setblock 191 167 302 minecraft:light[level=15]
setblock 191 167 310 minecraft:light[level=15]
setblock 198 167 293 minecraft:gold_block
setblock 199 167 278 minecraft:light[level=15]
setblock 199 167 286 minecraft:light[level=15]
setblock 199 167 294 minecraft:light[level=15]
setblock 199 167 302 minecraft:light[level=15]
setblock 199 167 310 minecraft:light[level=15]
fill 200 167 292 204 167 292 minecraft:prismarine_bricks
fill 200 167 294 204 167 294 minecraft:prismarine_bricks
fill 203 167 293 214 168 293 minecraft:prismarine_bricks
setblock 207 167 286 minecraft:light[level=15]
setblock 207 167 294 minecraft:light[level=15]
setblock 207 167 302 minecraft:light[level=15]
setblock 207 167 310 minecraft:light[level=15]
setblock 213 167 275 minecraft:sea_lantern
fill 213 167 276 213 216 276 minecraft:prismarine_bricks
fill 213 167 292 217 167 292 minecraft:prismarine_bricks
fill 213 167 294 217 167 294 minecraft:prismarine_bricks
fill 214 167 275 214 226 275 minecraft:prismarine_bricks
setblock 215 167 278 minecraft:light[level=15]
setblock 215 167 286 minecraft:light[level=15]
setblock 215 167 302 minecraft:light[level=15]
setblock 215 167 310 minecraft:light[level=15]
setblock 219 167 293 minecraft:gold_block
fill 222 167 312 222 167 314 minecraft:dark_prismarine
setblock 223 167 278 minecraft:light[level=15]
setblock 223 167 286 minecraft:light[level=15]
setblock 223 167 294 minecraft:light[level=15]
setblock 223 167 302 minecraft:light[level=15]
setblock 223 167 310 minecraft:light[level=15]
setblock 223 167 311 minecraft:dark_prismarine
fill 223 167 315 225 167 315 minecraft:dark_prismarine
setblock 225 167 311 minecraft:dark_prismarine
fill 190 168 295 192 195 297 minecraft:quartz_pillar
fill 191 168 278 193 195 280 minecraft:quartz_pillar
fill 191 168 312 193 195 314 minecraft:quartz_pillar
fill 199 168 293 200 168 293 minecraft:gold_block
fill 203 168 292 214 168 292 minecraft:prismarine_bricks
fill 203 168 294 214 168 294 minecraft:prismarine_bricks
fill 208 168 277 210 195 279 minecraft:quartz_pillar
fill 208 168 313 210 195 315 minecraft:quartz_pillar
fill 213 168 275 213 226 275 minecraft:prismarine_bricks
fill 217 168 293 218 168 293 minecraft:gold_block
fill 225 168 278 227 195 280 minecraft:quartz_pillar
fill 225 168 312 227 195 314 minecraft:quartz_pillar
fill 226 168 295 228 195 297 minecraft:quartz_pillar
fill 226 168 298 226 169 298 minecraft:sea_lantern
setblock 188 169 285 minecraft:sea_lantern
fill 202 169 293 203 169 293 minecraft:gold_block
fill 204 169 293 213 169 293 minecraft:prismarine_bricks
fill 206 169 292 211 169 292 minecraft:prismarine_bricks
fill 206 169 294 211 169 294 minecraft:prismarine_bricks
fill 214 169 293 215 169 293 minecraft:gold_block
fill 188 170 285 188 226 285 minecraft:prismarine_bricks
fill 188 170 309 188 200 310 minecraft:prismarine_bricks
setblock 188 170 311 minecraft:sea_lantern
fill 188 170 312 188 223 312 minecraft:prismarine_bricks
fill 205 170 293 212 170 293 minecraft:gold_block
fill 225 170 298 226 177 298 minecraft:dark_prismarine
setblock 230 170 294 minecraft:sea_lantern
fill 188 171 311 188 203 311 minecraft:prismarine_bricks
setblock 191 171 285 minecraft:light[level=12]
setblock 191 171 292 minecraft:light[level=12]
setblock 191 171 299 minecraft:light[level=12]
setblock 191 171 306 minecraft:light[level=12]
setblock 198 171 278 minecraft:light[level=12]
setblock 198 171 285 minecraft:light[level=12]
setblock 198 171 292 minecraft:light[level=12]
setblock 198 171 299 minecraft:light[level=12]
setblock 198 171 306 minecraft:light[level=12]
setblock 198 171 313 minecraft:light[level=12]
setblock 205 171 278 minecraft:light[level=12]
setblock 205 171 285 minecraft:light[level=12]
setblock 205 171 292 minecraft:light[level=12]
setblock 205 171 299 minecraft:light[level=12]
setblock 205 171 306 minecraft:light[level=12]
setblock 205 171 313 minecraft:light[level=12]
setblock 212 171 278 minecraft:light[level=12]
setblock 212 171 285 minecraft:light[level=12]
setblock 212 171 292 minecraft:light[level=12]
setblock 212 171 306 minecraft:light[level=12]
setblock 212 171 313 minecraft:light[level=12]
setblock 219 171 278 minecraft:light[level=12]
setblock 219 171 285 minecraft:light[level=12]
setblock 219 171 292 minecraft:light[level=12]
setblock 219 171 299 minecraft:light[level=12]
setblock 219 171 306 minecraft:light[level=12]
setblock 219 171 313 minecraft:light[level=12]
setblock 226 171 285 minecraft:light[level=12]
setblock 226 171 292 minecraft:light[level=12]
setblock 226 171 299 minecraft:light[level=12]
setblock 226 171 306 minecraft:light[level=12]
fill 230 171 294 230 223 294 minecraft:prismarine_bricks
fill 188 172 281 188 185 281 minecraft:prismarine_bricks
fill 188 172 282 188 172 283 minecraft:sea_lantern
fill 188 172 284 188 185 284 minecraft:prismarine_bricks
fill 188 172 293 188 178 293 minecraft:prismarine_bricks
fill 188 172 294 188 172 295 minecraft:sea_lantern
fill 188 172 296 188 185 296 minecraft:prismarine_bricks
fill 188 172 305 188 185 305 minecraft:prismarine_bricks
fill 188 172 306 188 172 307 minecraft:sea_lantern
fill 188 172 308 188 177 308 minecraft:prismarine_bricks
fill 188 172 317 188 185 317 minecraft:prismarine_bricks
fill 189 172 317 190 172 317 minecraft:sea_lantern
fill 191 172 317 191 185 317 minecraft:prismarine_bricks
fill 195 172 275 195 185 275 minecraft:prismarine_bricks
fill 195 172 282 195 173 282 minecraft:dark_prismarine
fill 196 172 275 197 172 275 minecraft:sea_lantern
fill 198 172 275 198 185 275 minecraft:prismarine_bricks
fill 200 172 317 200 185 317 minecraft:prismarine_bricks
fill 201 172 317 202 172 317 minecraft:sea_lantern
fill 203 172 317 203 185 317 minecraft:prismarine_bricks
fill 205 172 275 205 180 275 minecraft:prismarine_bricks
setblock 206 172 275 minecraft:sea_lantern
fill 206 172 309 206 173 309 minecraft:dark_prismarine
fill 207 172 275 207 185 275 minecraft:prismarine_bricks
fill 208 172 275 209 172 275 minecraft:sea_lantern
fill 210 172 275 210 185 275 minecraft:prismarine_bricks
fill 212 172 317 212 185 317 minecraft:prismarine_bricks
fill 213 172 317 214 172 317 minecraft:sea_lantern
fill 215 172 317 215 185 317 minecraft:prismarine_bricks
fill 219 172 275 219 185 275 minecraft:prismarine_bricks
fill 220 172 275 221 172 275 minecraft:sea_lantern
fill 222 172 275 222 185 275 minecraft:prismarine_bricks
fill 222 172 286 222 173 286 minecraft:dark_prismarine
fill 224 172 317 224 185 317 minecraft:prismarine_bricks
fill 225 172 299 226 177 299 minecraft:dark_prismarine
fill 225 172 317 226 172 317 minecraft:sea_lantern
fill 227 172 317 227 185 317 minecraft:prismarine_bricks
setblock 230 172 276 minecraft:prismarine_bricks
fill 230 172 277 230 172 278 minecraft:sea_lantern
fill 230 172 279 230 185 279 minecraft:prismarine_bricks
fill 230 172 288 230 185 288 minecraft:prismarine_bricks
fill 230 172 289 230 172 290 minecraft:sea_lantern
fill 230 172 291 230 185 291 minecraft:prismarine_bricks
fill 230 172 300 230 185 300 minecraft:prismarine_bricks
fill 230 172 301 230 172 302 minecraft:sea_lantern
fill 230 172 303 230 185 303 minecraft:prismarine_bricks
fill 230 172 312 230 185 312 minecraft:prismarine_bricks
fill 230 172 313 230 172 314 minecraft:sea_lantern
fill 230 172 315 230 185 315 minecraft:prismarine_bricks
fill 188 173 282 188 174 283 minecraft:prismarine_bricks
fill 188 173 294 188 180 295 minecraft:prismarine_bricks
fill 188 173 306 188 185 307 minecraft:prismarine_bricks
fill 189 173 317 190 185 317 minecraft:prismarine_bricks
fill 195 173 281 195 174 281 minecraft:dark_prismarine
fill 196 173 275 197 185 275 minecraft:prismarine_bricks
fill 201 173 317 202 185 317 minecraft:prismarine_bricks
fill 206 173 275 206 226 275 minecraft:prismarine_bricks
fill 206 173 310 206 174 310 minecraft:dark_prismarine
fill 208 173 275 209 185 275 minecraft:prismarine_bricks
fill 211 173 275 211 216 275 minecraft:prismarine_bricks
setblock 212 173 275 minecraft:sea_lantern
fill 213 173 317 214 182 317 minecraft:prismarine_bricks
fill 220 173 275 221 185 275 minecraft:prismarine_bricks
fill 223 173 286 223 174 286 minecraft:dark_prismarine
fill 224 173 298 224 177 298 minecraft:dark_prismarine
fill 225 173 297 225 177 297 minecraft:dark_prismarine
fill 225 173 317 226 185 317 minecraft:prismarine_bricks
fill 227 173 298 227 177 298 minecraft:dark_prismarine
setblock 230 173 276 minecraft:sea_lantern
fill 230 173 277 230 185 278 minecraft:prismarine_bricks
fill 230 173 289 230 185 290 minecraft:prismarine_bricks
fill 230 173 301 230 185 302 minecraft:prismarine_bricks
fill 230 173 313 230 185 314 minecraft:prismarine_bricks
fill 195 174 280 195 175 280 minecraft:dark_prismarine
fill 206 174 311 206 175 311 minecraft:dark_prismarine
fill 212 174 275 212 224 275 minecraft:prismarine_bricks
fill 224 174 286 224 175 286 minecraft:dark_prismarine
fill 224 174 297 224 177 297 minecraft:dark_prismarine
fill 224 174 299 224 177 299 minecraft:dark_prismarine
fill 225 174 300 226 177 300 minecraft:dark_prismarine
fill 227 174 299 227 177 299 minecraft:dark_prismarine
fill 230 174 276 230 179 276 minecraft:prismarine_bricks
fill 188 175 282 188 185 282 minecraft:prismarine_bricks
setblock 188 175 283 minecraft:sea_lantern
setblock 191 175 286 minecraft:light[level=15]
setblock 191 175 294 minecraft:light[level=15]
setblock 191 175 302 minecraft:light[level=15]
setblock 191 175 310 minecraft:light[level=15]
fill 195 175 279 195 176 279 minecraft:dark_prismarine
setblock 199 175 278 minecraft:light[level=15]
setblock 199 175 286 minecraft:light[level=15]
setblock 199 175 294 minecraft:light[level=15]
setblock 199 175 302 minecraft:light[level=15]
setblock 199 175 310 minecraft:light[level=15]
fill 206 175 312 206 176 312 minecraft:dark_prismarine
setblock 207 175 278 minecraft:light[level=15]
setblock 207 175 286 minecraft:light[level=15]
setblock 207 175 294 minecraft:light[level=15]
setblock 207 175 302 minecraft:light[level=15]
setblock 207 175 310 minecraft:light[level=15]
setblock 215 175 278 minecraft:light[level=15]
setblock 215 175 286 minecraft:light[level=15]
setblock 215 175 294 minecraft:light[level=15]
setblock 215 175 302 minecraft:light[level=15]
setblock 215 175 310 minecraft:light[level=15]
fill 222 175 312 222 175 314 minecraft:dark_prismarine
setblock 223 175 278 minecraft:light[level=15]
setblock 223 175 286 minecraft:light[level=15]
setblock 223 175 294 minecraft:light[level=15]
setblock 223 175 302 minecraft:light[level=15]
setblock 223 175 310 minecraft:light[level=15]
setblock 223 175 311 minecraft:dark_prismarine
fill 223 175 315 225 175 315 minecraft:dark_prismarine
fill 224 175 293 226 176 293 minecraft:white_stained_glass
fill 224 175 300 224 177 300 minecraft:dark_prismarine
fill 225 175 286 225 176 286 minecraft:dark_prismarine
fill 225 175 294 226 176 294 minecraft:white_stained_glass
fill 225 175 296 225 177 296 minecraft:dark_prismarine
fill 225 175 311 226 175 311 minecraft:dark_prismarine
fill 227 175 300 227 177 300 minecraft:dark_prismarine
fill 228 175 298 228 177 298 minecraft:dark_prismarine
setblock 230 175 292 minecraft:sea_lantern
fill 230 175 304 230 195 306 minecraft:prismarine_bricks
setblock 230 175 307 minecraft:sea_lantern
fill 188 176 283 188 185 283 minecraft:prismarine_bricks
fill 195 176 278 195 177 278 minecraft:dark_prismarine
fill 206 176 313 206 177 313 minecraft:dark_prismarine
fill 223 176 297 223 177 299 minecraft:dark_prismarine
fill 224 176 296 224 177 296 minecraft:dark_prismarine
fill 225 176 301 226 177 301 minecraft:dark_prismarine
fill 226 176 286 226 177 286 minecraft:dark_prismarine
fill 228 176 299 228 177 299 minecraft:dark_prismarine
fill 229 176 308 229 216 310 minecraft:prismarine_bricks
fill 230 176 292 230 226 292 minecraft:prismarine_bricks
fill 230 176 307 230 226 307 minecraft:prismarine_bricks
setblock 230 176 308 minecraft:sea_lantern
fill 230 176 309 230 224 310 minecraft:prismarine_bricks
setblock 191 177 285 minecraft:light[level=12]
setblock 191 177 292 minecraft:light[level=12]
setblock 191 177 299 minecraft:light[level=12]
setblock 191 177 306 minecraft:light[level=12]
fill 195 177 277 195 178 277 minecraft:dark_prismarine
setblock 198 177 278 minecraft:light[level=12]
setblock 198 177 285 minecraft:light[level=12]
setblock 198 177 292 minecraft:light[level=12]
setblock 198 177 299 minecraft:light[level=12]
setblock 198 177 306 minecraft:light[level=12]
setblock 198 177 313 minecraft:light[level=12]
setblock 205 177 278 minecraft:light[level=12]
setblock 205 177 285 minecraft:light[level=12]
setblock 205 177 292 minecraft:light[level=12]
setblock 205 177 299 minecraft:light[level=12]
setblock 205 177 306 minecraft:light[level=12]
setblock 205 177 313 minecraft:light[level=12]
fill 206 177 314 206 178 314 minecraft:dark_prismarine
setblock 212 177 278 minecraft:light[level=12]
setblock 212 177 285 minecraft:light[level=12]
setblock 212 177 292 minecraft:light[level=12]
setblock 212 177 306 minecraft:light[level=12]
setblock 212 177 313 minecraft:light[level=12]
setblock 219 177 278 minecraft:light[level=12]
setblock 219 177 285 minecraft:light[level=12]
setblock 219 177 292 minecraft:light[level=12]
setblock 219 177 299 minecraft:light[level=12]
setblock 219 177 306 minecraft:light[level=12]
setblock 219 177 313 minecraft:light[level=12]
setblock 223 177 296 minecraft:dark_prismarine
setblock 223 177 300 minecraft:dark_prismarine
setblock 224 177 301 minecraft:dark_prismarine
setblock 225 177 295 minecraft:dark_prismarine
setblock 226 177 285 minecraft:light[level=12]
setblock 226 177 292 minecraft:light[level=12]
setblock 226 177 306 minecraft:light[level=12]
fill 227 177 286 227 178 286 minecraft:dark_prismarine
setblock 227 177 301 minecraft:dark_prismarine
setblock 228 177 300 minecraft:dark_prismarine
fill 230 177 308 230 223 308 minecraft:prismarine_bricks
setblock 188 178 308 minecraft:sea_lantern
fill 195 178 276 195 179 276 minecraft:dark_prismarine
fill 206 178 315 206 179 315 minecraft:dark_prismarine
fill 225 178 297 225 182 297 minecraft:prismarine_bricks
fill 225 178 300 225 182 300 minecraft:prismarine_bricks
fill 227 178 299 227 180 299 minecraft:prismarine_bricks
fill 228 178 286 228 179 286 minecraft:dark_prismarine
setblock 188 179 293 minecraft:sea_lantern
fill 188 179 308 188 185 308 minecraft:prismarine_bricks
setblock 195 179 286 minecraft:sea_lantern
setblock 195 179 292 minecraft:sea_lantern
setblock 195 179 298 minecraft:sea_lantern
setblock 195 179 304 minecraft:sea_lantern
setblock 195 179 310 minecraft:sea_lantern
setblock 199 179 282 minecraft:sea_lantern
setblock 201 179 310 minecraft:sea_lantern
setblock 205 179 282 minecraft:sea_lantern
setblock 207 179 310 minecraft:sea_lantern
setblock 211 179 282 minecraft:sea_lantern
setblock 213 179 310 minecraft:sea_lantern
fill 216 179 304 216 180 304 minecraft:white_stained_glass
setblock 217 179 282 minecraft:sea_lantern
setblock 218 179 282 minecraft:green_terracotta
setblock 219 179 310 minecraft:sea_lantern
setblock 223 179 282 minecraft:sea_lantern
setblock 223 179 288 minecraft:sea_lantern
setblock 223 179 294 minecraft:sea_lantern
setblock 223 179 300 minecraft:sea_lantern
setblock 223 179 306 minecraft:sea_lantern
setblock 188 180 289 minecraft:sea_lantern
fill 188 180 293 195 180 293 minecraft:prismarine_bricks
fill 189 180 277 190 180 285 minecraft:prismarine_bricks
fill 189 180 289 195 180 292 minecraft:prismarine_bricks
fill 189 180 294 189 180 297 minecraft:prismarine_bricks
fill 189 180 301 195 180 309 minecraft:prismarine_bricks
fill 189 180 313 190 180 316 minecraft:prismarine_bricks
fill 190 180 286 195 180 288 minecraft:prismarine_bricks
fill 190 180 294 195 180 294 minecraft:prismarine_bricks
fill 190 180 298 195 180 300 minecraft:prismarine_bricks
fill 190 180 310 190 180 312 minecraft:prismarine_bricks
fill 191 180 277 207 180 277 minecraft:prismarine_bricks
fill 191 180 281 195 180 285 minecraft:prismarine_bricks
fill 191 180 310 223 180 311 minecraft:prismarine_bricks
fill 191 180 315 194 180 316 minecraft:prismarine_bricks
fill 192 180 276 200 180 276 minecraft:prismarine_bricks
fill 193 180 295 195 180 297 minecraft:prismarine_bricks
fill 194 180 278 207 180 280 minecraft:prismarine_bricks
fill 194 180 312 207 180 314 minecraft:prismarine_bricks
fill 195 180 315 207 180 315 minecraft:prismarine_bricks
fill 196 180 281 229 180 282 minecraft:prismarine_bricks
fill 198 180 316 206 180 316 minecraft:prismarine_bricks
fill 204 180 276 212 180 276 minecraft:prismarine_bricks
fill 208 180 280 224 180 280 minecraft:prismarine_bricks
fill 208 180 312 222 180 312 minecraft:prismarine_bricks
fill 210 180 316 218 180 316 minecraft:prismarine_bricks
fill 211 180 277 224 180 279 minecraft:prismarine_bricks
fill 211 180 313 222 180 315 minecraft:prismarine_bricks
fill 216 180 276 224 180 276 minecraft:prismarine_bricks
fill 222 180 316 229 180 316 minecraft:prismarine_bricks
fill 223 180 283 224 180 309 minecraft:prismarine_bricks
fill 223 180 315 229 180 315 minecraft:prismarine_bricks
fill 224 180 310 228 180 310 minecraft:prismarine_bricks
fill 225 180 277 229 180 277 minecraft:prismarine_bricks
fill 225 180 283 225 180 296 minecraft:prismarine_bricks
fill 225 180 298 226 180 299 minecraft:prismarine_bricks
fill 225 180 301 228 180 309 minecraft:prismarine_bricks
fill 225 180 311 229 180 311 minecraft:prismarine_bricks
fill 226 180 283 228 180 294 minecraft:prismarine_bricks
fill 226 180 300 229 180 300 minecraft:prismarine_bricks
fill 227 180 298 228 180 298 minecraft:prismarine_bricks
fill 228 180 276 229 180 276 minecraft:prismarine_bricks
fill 228 180 278 229 180 280 minecraft:prismarine_bricks
fill 228 180 299 229 180 299 minecraft:prismarine_bricks
fill 228 180 312 229 180 314 minecraft:prismarine_bricks
setblock 229 180 283 minecraft:prismarine_bricks
fill 229 180 287 229 180 295 minecraft:prismarine_bricks
fill 229 180 301 229 180 307 minecraft:prismarine_bricks
setblock 230 180 276 minecraft:sea_lantern
setblock 230 180 286 minecraft:sea_lantern
fill 230 180 287 230 226 287 minecraft:prismarine_bricks
fill 188 181 289 188 222 289 minecraft:prismarine_bricks
fill 188 181 293 188 185 293 minecraft:prismarine_bricks
setblock 188 181 294 minecraft:sea_lantern
fill 188 181 295 188 185 295 minecraft:prismarine_bricks
fill 190 181 285 190 185 287 minecraft:prismarine_bricks
fill 190 181 298 190 185 299 minecraft:prismarine_bricks
fill 190 181 309 190 185 311 minecraft:prismarine_bricks
fill 195 181 282 195 181 310 minecraft:gold_block
fill 196 181 282 223 181 282 minecraft:gold_block
fill 196 181 310 223 181 310 minecraft:gold_block
fill 196 181 315 198 185 315 minecraft:prismarine_bricks
fill 197 181 317 197 226 317 minecraft:prismarine_bricks
setblock 198 181 317 minecraft:sea_lantern
fill 199 181 317 199 223 317 minecraft:prismarine_bricks
fill 200 181 277 202 185 277 minecraft:prismarine_bricks
fill 204 181 306 205 182 306 minecraft:light_blue_stained_glass
setblock 205 181 275 minecraft:sea_lantern
fill 212 181 277 214 185 277 minecraft:prismarine_bricks
fill 220 181 315 222 185 315 minecraft:prismarine_bricks
fill 223 181 283 223 181 309 minecraft:gold_block
fill 224 181 277 226 185 277 minecraft:prismarine_bricks
fill 228 181 285 228 185 287 minecraft:prismarine_bricks
fill 228 181 298 228 185 299 minecraft:prismarine_bricks
fill 228 181 309 228 185 311 minecraft:prismarine_bricks
fill 230 181 276 230 185 276 minecraft:prismarine_bricks
fill 230 181 286 230 223 286 minecraft:prismarine_bricks
fill 188 182 294 188 185 294 minecraft:prismarine_bricks
fill 198 182 317 198 226 317 minecraft:prismarine_bricks
fill 204 182 317 204 224 317 minecraft:prismarine_bricks
fill 205 182 275 205 226 275 minecraft:prismarine_bricks
setblock 205 182 317 minecraft:sea_lantern
fill 218 182 282 218 193 282 minecraft:green_terracotta
setblock 191 183 285 minecraft:light[level=12]
setblock 191 183 286 minecraft:light[level=15]
setblock 191 183 292 minecraft:light[level=12]
setblock 191 183 294 minecraft:light[level=15]
setblock 191 183 299 minecraft:light[level=12]
setblock 191 183 302 minecraft:light[level=15]
setblock 191 183 306 minecraft:light[level=12]
setblock 191 183 310 minecraft:light[level=15]
setblock 198 183 278 minecraft:light[level=12]
setblock 198 183 285 minecraft:light[level=12]
setblock 198 183 292 minecraft:light[level=12]
setblock 198 183 299 minecraft:light[level=12]
setblock 198 183 306 minecraft:light[level=12]
setblock 198 183 313 minecraft:light[level=12]
setblock 199 183 278 minecraft:light[level=15]
setblock 199 183 286 minecraft:light[level=15]
setblock 199 183 294 minecraft:light[level=15]
setblock 199 183 302 minecraft:light[level=15]
setblock 199 183 310 minecraft:light[level=15]
setblock 205 183 278 minecraft:light[level=12]
setblock 205 183 285 minecraft:light[level=12]
setblock 205 183 292 minecraft:light[level=12]
setblock 205 183 299 minecraft:light[level=12]
setblock 205 183 306 minecraft:light[level=12]
setblock 205 183 313 minecraft:light[level=12]
fill 205 183 317 205 226 317 minecraft:prismarine_bricks
setblock 207 183 278 minecraft:light[level=15]
setblock 207 183 286 minecraft:light[level=15]
setblock 207 183 294 minecraft:light[level=15]
setblock 207 183 302 minecraft:light[level=15]
setblock 207 183 310 minecraft:light[level=15]
setblock 212 183 278 minecraft:light[level=12]
setblock 212 183 285 minecraft:light[level=12]
setblock 212 183 292 minecraft:light[level=12]
setblock 212 183 299 minecraft:light[level=12]
setblock 212 183 306 minecraft:light[level=12]
setblock 212 183 313 minecraft:light[level=12]
fill 213 183 317 213 185 317 minecraft:prismarine_bricks
setblock 214 183 317 minecraft:sea_lantern
setblock 215 183 278 minecraft:light[level=15]
setblock 215 183 286 minecraft:light[level=15]
setblock 215 183 294 minecraft:light[level=15]
setblock 215 183 302 minecraft:light[level=15]
setblock 215 183 310 minecraft:light[level=15]
setblock 219 183 278 minecraft:light[level=12]
setblock 219 183 285 minecraft:light[level=12]
setblock 219 183 292 minecraft:light[level=12]
setblock 219 183 299 minecraft:light[level=12]
setblock 219 183 306 minecraft:light[level=12]
setblock 219 183 313 minecraft:light[level=12]
fill 222 183 312 222 183 314 minecraft:dark_prismarine
setblock 223 183 278 minecraft:light[level=15]
setblock 223 183 286 minecraft:light[level=15]
setblock 223 183 294 minecraft:light[level=15]
setblock 223 183 302 minecraft:light[level=15]
setblock 223 183 310 minecraft:light[level=15]
setblock 223 183 311 minecraft:dark_prismarine
fill 223 183 315 225 183 315 minecraft:dark_prismarine
fill 225 183 311 226 183 311 minecraft:dark_prismarine
setblock 226 183 285 minecraft:light[level=12]
setblock 226 183 292 minecraft:light[level=12]
setblock 226 183 299 minecraft:light[level=12]
setblock 226 183 306 minecraft:light[level=12]
setblock 192 184 317 minecraft:sea_lantern
fill 193 184 317 194 212 317 minecraft:prismarine_bricks
fill 214 184 317 214 185 317 minecraft:prismarine_bricks
fill 189 185 279 189 185 284 minecraft:dark_prismarine
fill 189 185 291 189 185 296 minecraft:dark_prismarine
fill 189 185 303 189 185 308 minecraft:dark_prismarine
fill 189 185 315 189 185 316 minecraft:dark_prismarine
fill 190 185 316 193 185 316 minecraft:dark_prismarine
fill 192 185 317 192 215 317 minecraft:prismarine_bricks
fill 193 185 276 198 185 276 minecraft:dark_prismarine
fill 200 185 316 205 185 316 minecraft:dark_prismarine
fill 202 185 285 202 186 286 minecraft:light_blue_stained_glass
fill 205 185 276 210 185 276 minecraft:dark_prismarine
fill 212 185 316 217 185 316 minecraft:dark_prismarine
fill 217 185 276 222 185 276 minecraft:dark_prismarine
fill 224 185 316 229 185 316 minecraft:dark_prismarine
fill 229 185 276 229 185 281 minecraft:dark_prismarine
fill 229 185 288 229 185 293 minecraft:dark_prismarine
fill 229 185 300 229 185 305 minecraft:dark_prismarine
fill 229 185 312 229 185 315 minecraft:dark_prismarine
fill 188 186 281 188 191 284 minecraft:sea_lantern
fill 188 186 293 188 191 296 minecraft:sea_lantern
fill 188 186 305 188 191 308 minecraft:sea_lantern
fill 188 186 317 191 191 317 minecraft:sea_lantern
fill 195 186 275 198 191 275 minecraft:sea_lantern
fill 200 186 317 203 191 317 minecraft:sea_lantern
fill 207 186 275 210 191 275 minecraft:sea_lantern
fill 212 186 317 215 191 317 minecraft:sea_lantern
fill 219 186 275 222 191 275 minecraft:sea_lantern
fill 224 186 317 227 191 317 minecraft:sea_lantern
fill 230 186 276 230 191 279 minecraft:sea_lantern
fill 230 186 288 230 191 291 minecraft:sea_lantern
fill 230 186 300 230 191 303 minecraft:sea_lantern
fill 230 186 312 230 191 315 minecraft:sea_lantern
setblock 191 189 285 minecraft:light[level=12]
setblock 191 189 292 minecraft:light[level=12]
setblock 191 189 299 minecraft:light[level=12]
setblock 191 189 306 minecraft:light[level=12]
setblock 198 189 278 minecraft:light[level=12]
setblock 198 189 285 minecraft:light[level=12]
setblock 198 189 292 minecraft:light[level=12]
setblock 198 189 299 minecraft:light[level=12]
setblock 198 189 306 minecraft:light[level=12]
setblock 198 189 313 minecraft:light[level=12]
setblock 205 189 278 minecraft:light[level=12]
setblock 205 189 285 minecraft:light[level=12]
setblock 205 189 292 minecraft:light[level=12]
setblock 205 189 299 minecraft:light[level=12]
setblock 205 189 306 minecraft:light[level=12]
setblock 205 189 313 minecraft:light[level=12]
setblock 212 189 278 minecraft:light[level=12]
setblock 212 189 285 minecraft:light[level=12]
setblock 212 189 292 minecraft:light[level=12]
setblock 212 189 299 minecraft:light[level=12]
setblock 212 189 306 minecraft:light[level=12]
setblock 212 189 313 minecraft:light[level=12]
setblock 219 189 278 minecraft:light[level=12]
setblock 219 189 285 minecraft:light[level=12]
setblock 219 189 292 minecraft:light[level=12]
setblock 219 189 299 minecraft:light[level=12]
setblock 219 189 306 minecraft:light[level=12]
setblock 219 189 313 minecraft:light[level=12]
setblock 226 189 285 minecraft:light[level=12]
setblock 226 189 292 minecraft:light[level=12]
setblock 226 189 299 minecraft:light[level=12]
setblock 226 189 306 minecraft:light[level=12]
setblock 230 189 311 minecraft:sea_lantern
setblock 189 190 275 minecraft:sea_lantern
fill 190 190 275 192 224 275 minecraft:prismarine_bricks
fill 230 190 311 230 224 311 minecraft:prismarine_bricks
setblock 188 191 279 minecraft:sea_lantern
fill 189 191 275 189 224 275 minecraft:prismarine_bricks
setblock 191 191 286 minecraft:light[level=15]
setblock 191 191 294 minecraft:light[level=15]
setblock 191 191 302 minecraft:light[level=15]
setblock 191 191 310 minecraft:light[level=15]
setblock 199 191 278 minecraft:light[level=15]
setblock 199 191 286 minecraft:light[level=15]
setblock 199 191 294 minecraft:light[level=15]
setblock 199 191 302 minecraft:light[level=15]
setblock 199 191 310 minecraft:light[level=15]
setblock 207 191 278 minecraft:light[level=15]
setblock 207 191 286 minecraft:light[level=15]
setblock 207 191 294 minecraft:light[level=15]
setblock 207 191 302 minecraft:light[level=15]
setblock 207 191 310 minecraft:light[level=15]
setblock 215 191 278 minecraft:light[level=15]
setblock 215 191 286 minecraft:light[level=15]
setblock 215 191 294 minecraft:light[level=15]
setblock 215 191 302 minecraft:light[level=15]
setblock 215 191 310 minecraft:light[level=15]
fill 222 191 312 222 191 314 minecraft:dark_prismarine
setblock 223 191 278 minecraft:light[level=15]
setblock 223 191 286 minecraft:light[level=15]
setblock 223 191 294 minecraft:light[level=15]
setblock 223 191 302 minecraft:light[level=15]
setblock 223 191 310 minecraft:light[level=15]
setblock 223 191 311 minecraft:dark_prismarine
fill 223 191 315 225 191 315 minecraft:dark_prismarine
fill 225 191 311 226 191 311 minecraft:dark_prismarine
fill 188 192 279 188 226 279 minecraft:prismarine_bricks
fill 188 192 281 188 205 281 minecraft:prismarine_bricks
fill 188 192 282 188 192 283 minecraft:sea_lantern
fill 188 192 284 188 205 284 minecraft:prismarine_bricks
fill 188 192 293 188 205 293 minecraft:prismarine_bricks
fill 188 192 294 188 192 295 minecraft:sea_lantern
fill 188 192 296 188 197 296 minecraft:prismarine_bricks
fill 188 192 305 188 205 305 minecraft:prismarine_bricks
fill 188 192 306 188 192 307 minecraft:sea_lantern
fill 188 192 308 188 205 308 minecraft:prismarine_bricks
fill 188 192 317 188 205 317 minecraft:prismarine_bricks
fill 189 192 317 190 192 317 minecraft:sea_lantern
fill 191 192 317 191 205 317 minecraft:prismarine_bricks
fill 195 192 275 195 205 275 minecraft:prismarine_bricks
fill 196 192 275 197 192 275 minecraft:sea_lantern
fill 198 192 275 198 205 275 minecraft:prismarine_bricks
fill 200 192 317 200 205 317 minecraft:prismarine_bricks
fill 201 192 317 202 192 317 minecraft:sea_lantern
fill 203 192 317 203 205 317 minecraft:prismarine_bricks
fill 207 192 275 207 205 275 minecraft:prismarine_bricks
fill 208 192 275 209 192 275 minecraft:sea_lantern
fill 210 192 275 210 205 275 minecraft:prismarine_bricks
fill 212 192 317 212 193 317 minecraft:prismarine_bricks
fill 213 192 317 214 192 317 minecraft:sea_lantern
fill 215 192 317 215 205 317 minecraft:prismarine_bricks
fill 219 192 275 219 205 275 minecraft:prismarine_bricks
fill 220 192 275 221 192 275 minecraft:sea_lantern
fill 222 192 275 222 205 275 minecraft:prismarine_bricks
fill 224 192 317 224 199 317 minecraft:prismarine_bricks
fill 225 192 317 226 192 317 minecraft:sea_lantern
fill 227 192 317 227 205 317 minecraft:prismarine_bricks
fill 230 192 276 230 205 276 minecraft:prismarine_bricks
fill 230 192 277 230 192 278 minecraft:sea_lantern
fill 230 192 279 230 205 279 minecraft:prismarine_bricks
fill 230 192 288 230 205 288 minecraft:prismarine_bricks
fill 230 192 289 230 192 290 minecraft:sea_lantern
fill 230 192 291 230 205 291 minecraft:prismarine_bricks
fill 230 192 300 230 205 300 minecraft:prismarine_bricks
fill 230 192 301 230 192 302 minecraft:sea_lantern
fill 230 192 303 230 205 303 minecraft:prismarine_bricks
fill 230 192 312 230 205 312 minecraft:prismarine_bricks
fill 230 192 313 230 192 314 minecraft:sea_lantern
fill 230 192 315 230 205 315 minecraft:prismarine_bricks
fill 188 193 282 188 205 283 minecraft:prismarine_bricks
fill 188 193 294 188 194 295 minecraft:prismarine_bricks
fill 188 193 306 188 193 307 minecraft:prismarine_bricks
fill 189 193 317 190 205 317 minecraft:prismarine_bricks
fill 196 193 275 197 205 275 minecraft:prismarine_bricks
fill 201 193 317 202 202 317 minecraft:prismarine_bricks
fill 208 193 275 209 205 275 minecraft:prismarine_bricks
fill 213 193 317 214 205 317 minecraft:prismarine_bricks
fill 217 193 285 218 194 286 minecraft:light_blue_stained_glass
fill 220 193 275 221 205 275 minecraft:prismarine_bricks
fill 225 193 317 226 205 317 minecraft:prismarine_bricks
fill 230 193 277 230 199 278 minecraft:prismarine_bricks
fill 230 193 289 230 196 290 minecraft:prismarine_bricks
fill 230 193 301 230 205 302 minecraft:prismarine_bricks
fill 230 193 313 230 205 314 minecraft:prismarine_bricks
fill 188 194 306 188 205 306 minecraft:prismarine_bricks
setblock 188 194 307 minecraft:sea_lantern
setblock 212 194 317 minecraft:sea_lantern
fill 223 194 296 223 212 296 minecraft:iron_block
fill 188 195 294 188 205 294 minecraft:prismarine_bricks
setblock 188 195 295 minecraft:sea_lantern
fill 188 195 307 188 205 307 minecraft:prismarine_bricks
setblock 191 195 285 minecraft:light[level=12]
setblock 191 195 292 minecraft:light[level=12]
setblock 191 195 299 minecraft:light[level=12]
setblock 191 195 306 minecraft:light[level=12]
setblock 198 195 278 minecraft:light[level=12]
setblock 198 195 285 minecraft:light[level=12]
setblock 198 195 292 minecraft:light[level=12]
setblock 198 195 299 minecraft:light[level=12]
setblock 198 195 306 minecraft:light[level=12]
setblock 198 195 313 minecraft:light[level=12]
fill 203 195 281 203 196 281 minecraft:sea_lantern
fill 203 195 309 207 196 313 minecraft:dark_prismarine
setblock 205 195 278 minecraft:light[level=12]
setblock 205 195 285 minecraft:light[level=12]
setblock 205 195 292 minecraft:light[level=12]
setblock 205 195 299 minecraft:light[level=12]
setblock 205 195 306 minecraft:light[level=12]
fill 205 195 314 205 195 315 minecraft:dark_prismarine
setblock 212 195 278 minecraft:light[level=12]
setblock 212 195 285 minecraft:light[level=12]
setblock 212 195 292 minecraft:light[level=12]
setblock 212 195 299 minecraft:light[level=12]
setblock 212 195 306 minecraft:light[level=12]
setblock 212 195 313 minecraft:light[level=12]
fill 212 195 317 212 205 317 minecraft:prismarine_bricks
setblock 219 195 278 minecraft:light[level=12]
setblock 219 195 285 minecraft:light[level=12]
setblock 219 195 292 minecraft:light[level=12]
setblock 219 195 299 minecraft:light[level=12]
setblock 219 195 306 minecraft:light[level=12]
setblock 219 195 313 minecraft:light[level=12]
setblock 226 195 285 minecraft:light[level=12]
setblock 226 195 292 minecraft:light[level=12]
setblock 226 195 299 minecraft:light[level=12]
setblock 226 195 306 minecraft:light[level=12]
setblock 230 195 282 minecraft:sea_lantern
fill 230 195 283 230 226 284 minecraft:prismarine_bricks
fill 188 196 295 188 205 295 minecraft:prismarine_bricks
fill 189 196 296 193 197 296 minecraft:prismarine_bricks
fill 190 196 279 194 197 279 minecraft:prismarine_bricks
fill 190 196 295 192 197 295 minecraft:prismarine_bricks
fill 190 196 297 192 197 297 minecraft:prismarine_bricks
fill 190 196 313 194 197 313 minecraft:prismarine_bricks
fill 191 196 278 193 197 278 minecraft:prismarine_bricks
fill 191 196 280 193 197 280 minecraft:prismarine_bricks
fill 191 196 294 191 197 294 minecraft:prismarine_bricks
fill 191 196 298 191 197 298 minecraft:prismarine_bricks
fill 191 196 312 193 197 312 minecraft:prismarine_bricks
fill 191 196 314 193 197 314 minecraft:prismarine_bricks
fill 192 196 277 192 197 277 minecraft:prismarine_bricks
fill 192 196 281 192 197 281 minecraft:prismarine_bricks
fill 192 196 311 192 197 311 minecraft:prismarine_bricks
fill 192 196 315 192 197 315 minecraft:prismarine_bricks
fill 207 196 278 211 197 278 minecraft:prismarine_bricks
fill 207 196 314 211 197 314 minecraft:prismarine_bricks
fill 208 196 277 210 197 277 minecraft:prismarine_bricks
fill 208 196 279 210 197 279 minecraft:prismarine_bricks
fill 208 196 313 210 197 313 minecraft:prismarine_bricks
fill 208 196 315 210 197 315 minecraft:prismarine_bricks
fill 209 196 276 209 197 276 minecraft:prismarine_bricks
fill 209 196 280 209 197 280 minecraft:prismarine_bricks
fill 209 196 312 209 197 312 minecraft:prismarine_bricks
fill 224 196 279 228 197 279 minecraft:prismarine_bricks
fill 225 196 278 227 197 278 minecraft:prismarine_bricks
fill 225 196 280 227 197 280 minecraft:prismarine_bricks
fill 225 196 296 228 197 296 minecraft:prismarine_bricks
fill 225 196 312 227 197 314 minecraft:prismarine_bricks
fill 226 196 277 226 197 277 minecraft:prismarine_bricks
fill 226 196 281 226 197 281 minecraft:prismarine_bricks
fill 226 196 295 228 197 295 minecraft:prismarine_bricks
fill 226 196 297 228 197 297 minecraft:prismarine_bricks
fill 226 196 311 226 197 311 minecraft:prismarine_bricks
fill 226 196 315 226 197 315 minecraft:prismarine_bricks
fill 227 196 294 227 197 294 minecraft:prismarine_bricks
fill 227 196 298 227 197 298 minecraft:prismarine_bricks
fill 228 196 313 228 197 313 minecraft:prismarine_bricks
fill 230 196 282 230 224 282 minecraft:prismarine_bricks
setblock 230 196 293 minecraft:sea_lantern
setblock 230 196 298 minecraft:sea_lantern
fill 230 196 304 230 226 304 minecraft:prismarine_bricks
setblock 230 196 305 minecraft:sea_lantern
fill 230 196 306 230 223 306 minecraft:prismarine_bricks
fill 203 197 281 203 203 281 minecraft:dark_prismarine
fill 204 197 310 206 198 312 minecraft:prismarine_bricks
fill 230 197 289 230 205 289 minecraft:prismarine_bricks
setblock 230 197 290 minecraft:sea_lantern
fill 230 197 293 230 224 293 minecraft:prismarine_bricks
fill 230 197 298 230 222 298 minecraft:prismarine_bricks
fill 230 197 305 230 226 305 minecraft:prismarine_bricks
setblock 188 198 296 minecraft:sea_lantern
fill 190 198 295 192 225 297 minecraft:quartz_pillar
fill 191 198 278 193 225 280 minecraft:quartz_pillar
fill 191 198 312 193 225 314 minecraft:quartz_pillar
fill 196 198 297 196 199 298 minecraft:white_stained_glass
fill 203 198 280 203 203 280 minecraft:dark_prismarine
fill 208 198 277 210 225 279 minecraft:quartz_pillar
fill 208 198 313 210 225 315 minecraft:quartz_pillar
fill 225 198 278 227 225 280 minecraft:quartz_pillar
fill 225 198 312 227 225 314 minecraft:quartz_pillar
fill 226 198 295 228 223 297 minecraft:quartz_pillar
fill 230 198 290 230 205 290 minecraft:prismarine_bricks
fill 188 199 296 188 201 296 minecraft:prismarine_bricks
setblock 191 199 286 minecraft:light[level=15]
setblock 191 199 294 minecraft:light[level=15]
setblock 191 199 302 minecraft:light[level=15]
setblock 191 199 310 minecraft:light[level=15]
setblock 199 199 278 minecraft:light[level=15]
setblock 199 199 286 minecraft:light[level=15]
setblock 199 199 294 minecraft:light[level=15]
setblock 199 199 302 minecraft:light[level=15]
setblock 199 199 310 minecraft:light[level=15]
fill 202 199 280 202 203 281 minecraft:dark_prismarine
fill 203 199 282 203 203 282 minecraft:dark_prismarine
fill 204 199 280 204 203 281 minecraft:dark_prismarine
fill 204 199 311 206 201 311 minecraft:prismarine_bricks
fill 205 199 310 205 201 310 minecraft:prismarine_bricks
fill 205 199 312 205 201 312 minecraft:prismarine_bricks
setblock 207 199 278 minecraft:light[level=15]
setblock 207 199 286 minecraft:light[level=15]
setblock 207 199 294 minecraft:light[level=15]
setblock 207 199 302 minecraft:light[level=15]
setblock 207 199 310 minecraft:light[level=15]
setblock 215 199 278 minecraft:light[level=15]
setblock 215 199 286 minecraft:light[level=15]
setblock 215 199 294 minecraft:light[level=15]
setblock 215 199 302 minecraft:light[level=15]
setblock 215 199 310 minecraft:light[level=15]
fill 222 199 312 222 199 314 minecraft:dark_prismarine
setblock 223 199 278 minecraft:light[level=15]
setblock 223 199 286 minecraft:light[level=15]
setblock 223 199 294 minecraft:light[level=15]
setblock 223 199 302 minecraft:light[level=15]
setblock 223 199 310 minecraft:light[level=15]
setblock 223 199 311 minecraft:dark_prismarine
fill 223 199 315 225 199 315 minecraft:dark_prismarine
fill 225 199 311 226 199 311 minecraft:dark_prismarine
fill 190 200 285 190 206 287 minecraft:prismarine_bricks
fill 190 200 298 190 206 299 minecraft:prismarine_bricks
fill 190 200 309 190 206 311 minecraft:prismarine_bricks
fill 193 200 294 193 201 294 minecraft:dark_prismarine
fill 196 200 315 198 206 315 minecraft:prismarine_bricks
fill 200 200 277 202 206 277 minecraft:prismarine_bricks
fill 202 200 282 202 203 282 minecraft:dark_prismarine
fill 203 200 279 203 203 279 minecraft:dark_prismarine
fill 204 200 282 204 203 282 minecraft:dark_prismarine
fill 207 200 282 208 201 282 minecraft:white_stained_glass
fill 210 200 311 210 201 311 minecraft:dark_prismarine
fill 212 200 277 214 206 277 minecraft:prismarine_bricks
fill 214 200 311 214 201 311 minecraft:dark_prismarine
fill 219 200 289 219 201 290 minecraft:white_stained_glass
fill 220 200 315 222 206 315 minecraft:prismarine_bricks
fill 221 200 280 222 201 280 minecraft:dark_prismarine
fill 224 200 277 226 206 277 minecraft:prismarine_bricks
fill 224 200 307 224 201 307 minecraft:dark_prismarine
setblock 224 200 317 minecraft:sea_lantern
fill 228 200 285 228 206 287 minecraft:prismarine_bricks
fill 228 200 298 228 206 299 minecraft:prismarine_bricks
fill 228 200 309 228 206 311 minecraft:prismarine_bricks
setblock 230 200 277 minecraft:sea_lantern
fill 230 200 278 230 205 278 minecraft:prismarine_bricks
setblock 188 201 309 minecraft:sea_lantern
fill 188 201 310 188 226 310 minecraft:prismarine_bricks
setblock 191 201 285 minecraft:light[level=12]
setblock 191 201 292 minecraft:light[level=12]
setblock 191 201 299 minecraft:light[level=12]
setblock 191 201 306 minecraft:light[level=12]
fill 192 201 294 192 202 294 minecraft:dark_prismarine
setblock 198 201 278 minecraft:light[level=12]
setblock 198 201 285 minecraft:light[level=12]
setblock 198 201 292 minecraft:light[level=12]
setblock 198 201 299 minecraft:light[level=12]
setblock 198 201 306 minecraft:light[level=12]
setblock 198 201 313 minecraft:light[level=12]
fill 201 201 280 201 203 281 minecraft:dark_prismarine
fill 202 201 279 202 203 279 minecraft:dark_prismarine
fill 204 201 279 204 203 279 minecraft:dark_prismarine
setblock 205 201 278 minecraft:light[level=12]
fill 205 201 280 205 203 281 minecraft:dark_prismarine
setblock 205 201 285 minecraft:light[level=12]
setblock 205 201 292 minecraft:light[level=12]
setblock 205 201 299 minecraft:light[level=12]
setblock 205 201 306 minecraft:light[level=12]
setblock 205 201 313 minecraft:light[level=12]
fill 210 201 312 210 202 312 minecraft:dark_prismarine
setblock 212 201 278 minecraft:light[level=12]
setblock 212 201 285 minecraft:light[level=12]
setblock 212 201 292 minecraft:light[level=12]
setblock 212 201 299 minecraft:light[level=12]
setblock 212 201 306 minecraft:light[level=12]
setblock 212 201 313 minecraft:light[level=12]
fill 214 201 312 214 202 312 minecraft:dark_prismarine
setblock 219 201 278 minecraft:light[level=12]
setblock 219 201 285 minecraft:light[level=12]
setblock 219 201 292 minecraft:light[level=12]
setblock 219 201 299 minecraft:light[level=12]
setblock 219 201 306 minecraft:light[level=12]
setblock 219 201 313 minecraft:light[level=12]
fill 221 201 279 222 202 279 minecraft:dark_prismarine
fill 224 201 317 224 205 317 minecraft:prismarine_bricks
fill 225 201 307 225 202 307 minecraft:dark_prismarine
setblock 226 201 285 minecraft:light[level=12]
setblock 226 201 292 minecraft:light[level=12]
setblock 226 201 299 minecraft:light[level=12]
setblock 226 201 306 minecraft:light[level=12]
fill 230 201 277 230 205 277 minecraft:prismarine_bricks
setblock 188 202 296 minecraft:sea_lantern
fill 188 202 309 188 226 309 minecraft:prismarine_bricks
fill 191 202 294 191 203 294 minecraft:dark_prismarine
fill 201 202 279 201 203 279 minecraft:dark_prismarine
fill 201 202 282 201 203 282 minecraft:dark_prismarine
fill 202 202 283 204 203 283 minecraft:dark_prismarine
fill 203 202 278 203 203 278 minecraft:dark_prismarine
fill 205 202 279 205 203 279 minecraft:dark_prismarine
fill 205 202 282 205 203 282 minecraft:dark_prismarine
fill 205 202 311 205 206 311 minecraft:prismarine_bricks
fill 214 202 313 214 203 313 minecraft:dark_prismarine
fill 221 202 278 222 203 278 minecraft:dark_prismarine
fill 226 202 307 226 203 307 minecraft:dark_prismarine
fill 188 203 296 188 205 296 minecraft:prismarine_bricks
setblock 188 203 302 minecraft:sea_lantern
fill 188 203 303 188 226 303 minecraft:prismarine_bricks
fill 190 203 294 190 204 294 minecraft:dark_prismarine
fill 200 203 280 200 203 281 minecraft:dark_prismarine
setblock 201 203 283 minecraft:dark_prismarine
fill 201 203 317 201 205 317 minecraft:prismarine_bricks
setblock 202 203 278 minecraft:dark_prismarine
setblock 202 203 317 minecraft:sea_lantern
setblock 204 203 278 minecraft:dark_prismarine
setblock 205 203 283 minecraft:dark_prismarine
fill 206 203 280 206 203 281 minecraft:dark_prismarine
fill 214 203 314 214 204 314 minecraft:dark_prismarine
fill 221 203 277 222 204 277 minecraft:dark_prismarine
fill 227 203 307 227 204 307 minecraft:dark_prismarine
fill 188 204 302 188 222 302 minecraft:prismarine_bricks
setblock 188 204 311 minecraft:sea_lantern
fill 189 204 294 189 205 294 minecraft:dark_prismarine
fill 202 204 279 202 207 279 minecraft:prismarine_bricks
fill 202 204 282 202 205 282 minecraft:prismarine_bricks
fill 202 204 317 202 205 317 minecraft:prismarine_bricks
fill 205 204 281 205 205 281 minecraft:prismarine_bricks
fill 214 204 315 214 205 315 minecraft:dark_prismarine
fill 221 204 276 222 205 276 minecraft:dark_prismarine
fill 228 204 307 228 205 307 minecraft:dark_prismarine
fill 188 205 311 188 226 311 minecraft:prismarine_bricks
fill 189 205 279 189 205 284 minecraft:dark_prismarine
fill 189 205 291 189 205 293 minecraft:dark_prismarine
fill 189 205 295 189 205 296 minecraft:dark_prismarine
fill 189 205 303 189 205 308 minecraft:dark_prismarine
fill 189 205 315 189 205 316 minecraft:dark_prismarine
fill 190 205 316 193 205 316 minecraft:dark_prismarine
fill 193 205 276 198 205 276 minecraft:dark_prismarine
setblock 193 205 282 minecraft:sea_lantern
setblock 193 205 288 minecraft:sea_lantern
setblock 193 205 294 minecraft:sea_lantern
setblock 193 205 300 minecraft:sea_lantern
setblock 193 205 306 minecraft:sea_lantern
setblock 195 205 280 minecraft:sea_lantern
setblock 199 205 312 minecraft:sea_lantern
fill 200 205 316 205 205 316 minecraft:dark_prismarine
setblock 201 205 280 minecraft:sea_lantern
fill 205 205 276 210 205 276 minecraft:dark_prismarine
setblock 205 205 312 minecraft:sea_lantern
setblock 207 205 280 minecraft:sea_lantern
setblock 211 205 312 minecraft:sea_lantern
fill 212 205 316 217 205 316 minecraft:dark_prismarine
setblock 213 205 280 minecraft:sea_lantern
fill 217 205 276 220 205 276 minecraft:dark_prismarine
setblock 217 205 312 minecraft:sea_lantern
setblock 219 205 280 minecraft:sea_lantern
setblock 223 205 312 minecraft:sea_lantern
fill 223 205 313 224 216 314 minecraft:prismarine_bricks
fill 224 205 312 224 206 312 minecraft:prismarine_bricks
fill 224 205 316 229 205 316 minecraft:dark_prismarine
setblock 225 205 286 minecraft:sea_lantern
setblock 225 205 292 minecraft:sea_lantern
setblock 225 205 298 minecraft:sea_lantern
setblock 225 205 304 minecraft:sea_lantern
setblock 225 205 310 minecraft:sea_lantern
fill 229 205 276 229 205 281 minecraft:dark_prismarine
fill 229 205 288 229 205 293 minecraft:dark_prismarine
fill 229 205 300 229 205 305 minecraft:dark_prismarine
fill 229 205 312 229 205 315 minecraft:dark_prismarine
fill 188 206 281 188 211 284 minecraft:sea_lantern
fill 188 206 293 188 211 296 minecraft:sea_lantern
fill 188 206 305 188 211 308 minecraft:sea_lantern
fill 188 206 317 191 211 317 minecraft:sea_lantern
fill 189 206 277 189 206 285 minecraft:prismarine_bricks
fill 189 206 289 189 206 297 minecraft:prismarine_bricks
fill 189 206 301 189 206 309 minecraft:prismarine_bricks
fill 189 206 313 190 206 316 minecraft:prismarine_bricks
fill 190 206 277 190 206 284 minecraft:prismarine_bricks
fill 190 206 288 193 206 294 minecraft:prismarine_bricks
fill 190 206 300 193 206 308 minecraft:prismarine_bricks
setblock 190 206 312 minecraft:prismarine_bricks
fill 191 206 277 199 206 277 minecraft:prismarine_bricks
fill 191 206 281 193 206 287 minecraft:prismarine_bricks
fill 191 206 298 193 206 299 minecraft:prismarine_bricks
fill 191 206 309 193 206 311 minecraft:prismarine_bricks
fill 191 206 315 194 206 316 minecraft:prismarine_bricks
fill 192 206 276 200 206 276 minecraft:prismarine_bricks
fill 193 206 295 193 206 297 minecraft:prismarine_bricks
fill 194 206 278 201 206 280 minecraft:prismarine_bricks
fill 194 206 312 207 206 314 minecraft:prismarine_bricks
fill 195 206 275 198 211 275 minecraft:sea_lantern
setblock 195 206 315 minecraft:prismarine_bricks
fill 198 206 316 206 206 316 minecraft:prismarine_bricks
fill 199 206 315 207 206 315 minecraft:prismarine_bricks
fill 200 206 317 203 211 317 minecraft:sea_lantern
fill 202 206 278 207 206 278 minecraft:prismarine_bricks
fill 202 206 280 224 206 280 minecraft:prismarine_bricks
fill 202 206 284 202 207 284 minecraft:white_stained_glass
fill 203 206 277 207 206 277 minecraft:prismarine_bricks
fill 203 206 279 207 206 279 minecraft:prismarine_bricks
fill 204 206 276 212 206 276 minecraft:prismarine_bricks
fill 207 206 275 210 211 275 minecraft:sea_lantern
fill 208 206 312 223 206 312 minecraft:prismarine_bricks
fill 210 206 316 218 206 316 minecraft:prismarine_bricks
fill 211 206 277 211 206 279 minecraft:prismarine_bricks
fill 211 206 313 219 206 315 minecraft:prismarine_bricks
fill 212 206 278 224 206 279 minecraft:prismarine_bricks
fill 212 206 317 215 211 317 minecraft:sea_lantern
fill 215 206 277 223 206 277 minecraft:prismarine_bricks
fill 216 206 276 224 206 276 minecraft:prismarine_bricks
fill 219 206 275 222 211 275 minecraft:sea_lantern
fill 220 206 313 222 206 314 minecraft:prismarine_bricks
fill 222 206 316 229 206 316 minecraft:prismarine_bricks
fill 223 206 315 229 206 315 minecraft:prismarine_bricks
fill 224 206 317 227 211 317 minecraft:sea_lantern
fill 225 206 281 225 206 311 minecraft:prismarine_bricks
fill 226 206 281 227 206 294 minecraft:prismarine_bricks
fill 226 206 298 227 206 311 minecraft:prismarine_bricks
fill 227 206 277 229 206 277 minecraft:prismarine_bricks
fill 228 206 276 229 206 276 minecraft:prismarine_bricks
fill 228 206 278 228 206 284 minecraft:prismarine_bricks
fill 228 206 288 229 206 294 minecraft:prismarine_bricks
fill 228 206 300 228 206 308 minecraft:prismarine_bricks
fill 228 206 312 229 206 314 minecraft:prismarine_bricks
fill 229 206 278 229 206 283 minecraft:prismarine_bricks
setblock 229 206 287 minecraft:prismarine_bricks
setblock 229 206 295 minecraft:prismarine_bricks
fill 229 206 299 229 206 307 minecraft:prismarine_bricks
setblock 229 206 311 minecraft:prismarine_bricks
fill 230 206 276 230 211 279 minecraft:sea_lantern
fill 230 206 288 230 211 291 minecraft:sea_lantern
fill 230 206 300 230 211 303 minecraft:sea_lantern
fill 230 206 312 230 211 315 minecraft:sea_lantern
setblock 191 207 285 minecraft:light[level=12]
setblock 191 207 286 minecraft:light[level=15]
setblock 191 207 292 minecraft:light[level=12]
setblock 191 207 294 minecraft:light[level=15]
setblock 191 207 299 minecraft:light[level=12]
setblock 191 207 302 minecraft:light[level=15]
setblock 191 207 306 minecraft:light[level=12]
setblock 191 207 310 minecraft:light[level=15]
fill 193 207 281 193 207 311 minecraft:gold_block
fill 194 207 280 224 207 280 minecraft:gold_block
fill 194 207 312 224 207 312 minecraft:gold_block
setblock 198 207 278 minecraft:light[level=12]
setblock 198 207 285 minecraft:light[level=12]
setblock 198 207 292 minecraft:light[level=12]
setblock 198 207 299 minecraft:light[level=12]
setblock 198 207 306 minecraft:light[level=12]
setblock 198 207 313 minecraft:light[level=12]
setblock 199 207 278 minecraft:light[level=15]
setblock 199 207 286 minecraft:light[level=15]
setblock 199 207 294 minecraft:light[level=15]
setblock 199 207 302 minecraft:light[level=15]
setblock 199 207 310 minecraft:light[level=15]
setblock 205 207 278 minecraft:light[level=12]
setblock 205 207 285 minecraft:light[level=12]
setblock 205 207 292 minecraft:light[level=12]
setblock 205 207 299 minecraft:light[level=12]
setblock 205 207 306 minecraft:light[level=12]
setblock 205 207 311 minecraft:sea_lantern
setblock 205 207 313 minecraft:light[level=12]
setblock 207 207 278 minecraft:light[level=15]
setblock 207 207 286 minecraft:light[level=15]
setblock 207 207 294 minecraft:light[level=15]
setblock 207 207 302 minecraft:light[level=15]
setblock 207 207 310 minecraft:light[level=15]
setblock 212 207 278 minecraft:light[level=12]
setblock 212 207 285 minecraft:light[level=12]
schedule function dropper:buildpart/64_2 1t
