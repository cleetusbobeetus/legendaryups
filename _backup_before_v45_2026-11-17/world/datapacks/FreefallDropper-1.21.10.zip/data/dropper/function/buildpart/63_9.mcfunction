setblock 154 256 315 minecraft:snow_block
fill 154 256 316 157 256 316 minecraft:packed_ice
fill 155 256 315 155 257 315 minecraft:packed_ice
setblock 158 256 278 minecraft:light[level=12]
setblock 158 256 285 minecraft:light[level=12]
setblock 158 256 292 minecraft:light[level=12]
setblock 158 256 299 minecraft:light[level=12]
setblock 158 256 306 minecraft:light[level=12]
setblock 158 256 313 minecraft:light[level=12]
setblock 158 256 316 minecraft:snow_block
fill 159 256 316 162 256 316 minecraft:packed_ice
setblock 163 256 316 minecraft:snow_block
fill 164 256 276 164 259 276 minecraft:packed_ice
fill 164 256 316 164 259 316 minecraft:packed_ice
fill 165 256 275 165 283 275 minecraft:snow_block
setblock 165 256 278 minecraft:light[level=12]
setblock 165 256 285 minecraft:light[level=12]
setblock 165 256 292 minecraft:light[level=12]
setblock 165 256 299 minecraft:light[level=12]
setblock 165 256 306 minecraft:light[level=12]
setblock 165 256 313 minecraft:light[level=12]
fill 165 256 315 165 259 315 minecraft:packed_ice
setblock 167 256 277 minecraft:snow_block
setblock 168 256 276 minecraft:snow_block
fill 168 256 277 169 258 277 minecraft:packed_ice
fill 168 256 316 168 256 317 minecraft:snow_block
fill 169 256 276 169 259 276 minecraft:packed_ice
setblock 169 256 315 minecraft:snow_block
fill 169 256 316 169 259 316 minecraft:packed_ice
fill 170 256 315 170 258 315 minecraft:packed_ice
setblock 171 256 275 minecraft:white_concrete
setblock 171 256 277 minecraft:packed_ice
setblock 172 256 277 minecraft:snow_block
setblock 172 256 278 minecraft:light[level=12]
setblock 172 256 285 minecraft:light[level=12]
setblock 172 256 292 minecraft:light[level=12]
setblock 172 256 299 minecraft:light[level=12]
setblock 172 256 306 minecraft:light[level=12]
setblock 172 256 313 minecraft:light[level=12]
setblock 173 256 276 minecraft:snow_block
fill 173 256 277 173 259 277 minecraft:packed_ice
setblock 173 256 316 minecraft:snow_block
fill 174 256 275 174 308 275 minecraft:snow_block
fill 174 256 276 174 259 276 minecraft:packed_ice
fill 174 256 316 174 259 316 minecraft:packed_ice
fill 176 256 275 176 280 275 minecraft:snow_block
setblock 176 256 317 minecraft:light_blue_concrete
setblock 177 256 276 minecraft:packed_ice
fill 177 256 317 178 256 317 minecraft:snow_block
setblock 178 256 276 minecraft:snow_block
fill 179 256 276 179 259 276 minecraft:packed_ice
setblock 179 256 278 minecraft:light[level=12]
setblock 179 256 285 minecraft:light[level=12]
setblock 179 256 292 minecraft:light[level=12]
setblock 179 256 299 minecraft:light[level=12]
setblock 179 256 306 minecraft:light[level=12]
setblock 179 256 313 minecraft:light[level=12]
fill 181 256 316 181 257 316 minecraft:packed_ice
setblock 182 256 277 minecraft:snow_block
fill 182 256 278 182 259 278 minecraft:packed_ice
fill 182 256 280 182 256 281 minecraft:packed_ice
setblock 182 256 292 minecraft:snow_block
fill 182 256 293 182 259 293 minecraft:packed_ice
setblock 182 256 297 minecraft:snow_block
fill 182 256 314 182 258 314 minecraft:packed_ice
fill 183 256 305 183 308 305 minecraft:snow_block
setblock 142 257 276 minecraft:snow_block
fill 142 257 277 142 260 277 minecraft:packed_ice
setblock 142 257 281 minecraft:snow_block
fill 142 257 294 142 257 295 minecraft:packed_ice
setblock 142 257 296 minecraft:snow_block
fill 142 257 297 142 259 298 minecraft:packed_ice
setblock 142 257 311 minecraft:snow_block
fill 142 257 312 143 259 312 minecraft:packed_ice
setblock 142 257 315 minecraft:packed_ice
setblock 142 257 316 minecraft:snow_block
fill 143 257 276 143 260 276 minecraft:packed_ice
setblock 143 257 279 minecraft:packed_ice
setblock 143 257 280 minecraft:blue_ice
setblock 143 257 315 minecraft:snow_block
fill 143 257 316 143 260 316 minecraft:packed_ice
fill 143 257 317 143 308 317 minecraft:snow_block
setblock 144 257 279 minecraft:blue_ice
setblock 144 257 313 minecraft:packed_ice
setblock 144 257 314 minecraft:snow_block
fill 144 257 315 144 260 315 minecraft:packed_ice
setblock 145 257 278 minecraft:snow_block
fill 145 257 313 147 258 313 minecraft:blue_ice
fill 145 257 314 145 260 314 minecraft:packed_ice
setblock 146 257 277 minecraft:snow_block
fill 146 257 278 148 258 278 minecraft:packed_ice
fill 146 257 312 146 259 312 minecraft:blue_ice
setblock 147 257 276 minecraft:snow_block
fill 147 257 277 147 260 277 minecraft:packed_ice
setblock 147 257 316 minecraft:snow_block
fill 148 257 276 148 260 276 minecraft:packed_ice
setblock 148 257 315 minecraft:snow_block
fill 148 257 316 148 260 316 minecraft:packed_ice
setblock 149 257 314 minecraft:snow_block
fill 149 257 315 149 260 315 minecraft:packed_ice
fill 150 257 314 150 260 314 minecraft:packed_ice
setblock 151 257 277 minecraft:snow_block
setblock 152 257 276 minecraft:snow_block
fill 152 257 277 152 260 277 minecraft:packed_ice
setblock 152 257 316 minecraft:snow_block
fill 153 257 276 153 260 276 minecraft:packed_ice
setblock 153 257 315 minecraft:snow_block
fill 153 257 316 156 257 316 minecraft:packed_ice
fill 154 257 315 154 259 315 minecraft:packed_ice
fill 155 257 276 155 258 276 minecraft:packed_ice
setblock 157 257 316 minecraft:snow_block
fill 158 257 316 161 257 316 minecraft:packed_ice
setblock 161 257 317 minecraft:white_concrete
setblock 162 257 276 minecraft:snow_block
setblock 162 257 316 minecraft:snow_block
setblock 162 257 317 minecraft:light_blue_concrete
fill 163 257 276 163 260 276 minecraft:packed_ice
fill 163 257 316 163 260 316 minecraft:packed_ice
setblock 165 257 277 minecraft:packed_ice
setblock 166 257 277 minecraft:snow_block
setblock 167 257 276 minecraft:snow_block
fill 167 257 277 167 260 277 minecraft:packed_ice
setblock 167 257 316 minecraft:snow_block
fill 168 257 276 168 260 276 minecraft:packed_ice
setblock 168 257 315 minecraft:snow_block
fill 168 257 316 168 260 316 minecraft:packed_ice
fill 168 257 317 168 288 317 minecraft:snow_block
fill 169 257 315 169 259 315 minecraft:packed_ice
fill 171 257 275 171 308 275 minecraft:snow_block
setblock 171 257 277 minecraft:snow_block
setblock 172 257 276 minecraft:snow_block
fill 172 257 277 172 260 277 minecraft:packed_ice
setblock 172 257 316 minecraft:snow_block
fill 173 257 276 173 260 276 minecraft:packed_ice
fill 173 257 316 173 260 316 minecraft:packed_ice
fill 174 257 277 174 258 277 minecraft:packed_ice
fill 176 257 317 176 267 317 minecraft:snow_block
setblock 177 257 276 minecraft:snow_block
setblock 177 257 317 minecraft:white_concrete
fill 178 257 276 178 260 276 minecraft:packed_ice
fill 178 257 317 178 266 317 minecraft:snow_block
fill 179 257 277 180 257 277 minecraft:packed_ice
fill 180 257 316 180 258 316 minecraft:packed_ice
setblock 181 257 277 minecraft:snow_block
fill 181 257 278 181 259 279 minecraft:packed_ice
setblock 182 257 276 minecraft:snow_block
fill 182 257 277 182 260 277 minecraft:packed_ice
setblock 182 257 280 minecraft:packed_ice
setblock 182 257 281 minecraft:snow_block
fill 182 257 282 182 258 284 minecraft:packed_ice
fill 182 257 289 182 258 289 minecraft:packed_ice
setblock 182 257 291 minecraft:snow_block
fill 182 257 292 182 260 292 minecraft:packed_ice
setblock 182 257 296 minecraft:snow_block
fill 182 257 297 182 259 298 minecraft:packed_ice
setblock 182 257 316 minecraft:snow_block
fill 142 258 276 142 261 276 minecraft:packed_ice
setblock 142 258 280 minecraft:snow_block
fill 142 258 281 142 260 282 minecraft:packed_ice
fill 142 258 293 142 258 294 minecraft:packed_ice
setblock 142 258 295 minecraft:snow_block
fill 142 258 296 143 260 296 minecraft:packed_ice
setblock 142 258 299 minecraft:packed_ice
setblock 142 258 300 minecraft:snow_block
fill 142 258 301 142 260 302 minecraft:packed_ice
setblock 142 258 310 minecraft:snow_block
fill 142 258 311 143 260 311 minecraft:packed_ice
setblock 142 258 315 minecraft:snow_block
fill 142 258 316 142 261 316 minecraft:packed_ice
setblock 143 258 279 minecraft:snow_block
fill 143 258 280 143 261 280 minecraft:packed_ice
fill 143 258 297 143 258 298 minecraft:packed_ice
setblock 143 258 299 minecraft:snow_block
setblock 143 258 314 minecraft:snow_block
fill 143 258 315 143 261 315 minecraft:packed_ice
setblock 144 258 278 minecraft:snow_block
fill 144 258 279 144 261 279 minecraft:packed_ice
setblock 144 258 313 minecraft:snow_block
fill 144 258 314 144 261 314 minecraft:packed_ice
setblock 145 258 277 minecraft:snow_block
fill 145 258 278 145 261 278 minecraft:packed_ice
fill 145 258 279 145 258 280 minecraft:blue_ice
setblock 145 258 312 minecraft:blue_ice
setblock 146 258 276 minecraft:snow_block
fill 146 258 277 146 261 277 minecraft:packed_ice
fill 146 258 279 146 259 279 minecraft:blue_ice
fill 146 258 309 146 259 311 minecraft:blue_ice
setblock 146 258 316 minecraft:snow_block
fill 147 258 276 147 261 276 minecraft:packed_ice
setblock 147 258 312 minecraft:blue_ice
setblock 147 258 315 minecraft:snow_block
fill 147 258 316 147 261 316 minecraft:packed_ice
setblock 148 258 314 minecraft:snow_block
fill 148 258 315 148 261 315 minecraft:packed_ice
setblock 149 258 278 minecraft:snow_block
fill 149 258 314 149 261 314 minecraft:packed_ice
setblock 150 258 277 minecraft:snow_block
setblock 151 258 276 minecraft:snow_block
fill 151 258 277 151 261 277 minecraft:packed_ice
setblock 151 258 316 minecraft:snow_block
fill 152 258 276 152 261 276 minecraft:packed_ice
setblock 152 258 315 minecraft:snow_block
fill 152 258 316 155 258 316 minecraft:packed_ice
fill 153 258 315 153 260 315 minecraft:packed_ice
setblock 156 258 316 minecraft:snow_block
fill 157 258 316 160 258 316 minecraft:packed_ice
setblock 161 258 276 minecraft:snow_block
fill 161 258 316 161 258 317 minecraft:snow_block
fill 162 258 276 162 261 276 minecraft:packed_ice
fill 162 258 316 162 261 316 minecraft:packed_ice
fill 162 258 317 162 296 317 minecraft:snow_block
setblock 164 258 277 minecraft:packed_ice
fill 164 258 315 164 260 315 minecraft:packed_ice
setblock 165 258 276 minecraft:packed_ice
setblock 165 258 277 minecraft:snow_block
setblock 166 258 276 minecraft:snow_block
fill 166 258 277 166 261 277 minecraft:packed_ice
setblock 166 258 316 minecraft:snow_block
fill 167 258 276 167 261 276 minecraft:packed_ice
setblock 167 258 315 minecraft:snow_block
fill 167 258 316 167 261 316 minecraft:packed_ice
setblock 168 258 278 minecraft:packed_ice
fill 168 258 315 168 260 315 minecraft:packed_ice
setblock 169 258 278 minecraft:snow_block
setblock 170 258 276 minecraft:packed_ice
setblock 170 258 277 minecraft:snow_block
fill 170 258 278 170 261 278 minecraft:packed_ice
setblock 171 258 276 minecraft:snow_block
fill 171 258 277 171 261 277 minecraft:packed_ice
setblock 171 258 316 minecraft:snow_block
fill 172 258 276 172 261 276 minecraft:packed_ice
fill 172 258 316 172 261 316 minecraft:packed_ice
setblock 175 258 277 minecraft:snow_block
setblock 176 258 276 minecraft:snow_block
fill 176 258 277 179 258 277 minecraft:packed_ice
fill 177 258 276 177 261 276 minecraft:packed_ice
fill 177 258 317 177 292 317 minecraft:snow_block
fill 178 258 316 179 259 316 minecraft:packed_ice
setblock 180 258 277 minecraft:snow_block
setblock 181 258 276 minecraft:snow_block
fill 181 258 277 181 261 277 minecraft:packed_ice
setblock 181 258 280 minecraft:packed_ice
setblock 181 258 281 minecraft:snow_block
setblock 181 258 316 minecraft:snow_block
fill 182 258 276 182 261 276 minecraft:packed_ice
setblock 182 258 280 minecraft:snow_block
fill 182 258 281 182 261 281 minecraft:packed_ice
setblock 182 258 285 minecraft:snow_block
fill 182 258 286 182 259 288 minecraft:packed_ice
setblock 182 258 290 minecraft:snow_block
fill 182 258 291 182 261 291 minecraft:packed_ice
setblock 182 258 295 minecraft:snow_block
fill 182 258 296 182 261 296 minecraft:packed_ice
setblock 182 258 299 minecraft:packed_ice
setblock 182 258 300 minecraft:snow_block
fill 182 258 313 182 259 313 minecraft:packed_ice
setblock 182 258 315 minecraft:snow_block
fill 182 258 316 182 261 316 minecraft:packed_ice
fill 183 258 296 183 268 296 minecraft:snow_block
setblock 183 258 297 minecraft:white_concrete
setblock 183 258 306 minecraft:light_blue_concrete
fill 183 258 307 183 296 307 minecraft:snow_block
fill 141 259 280 141 291 281 minecraft:snow_block
setblock 141 259 282 minecraft:white_concrete
fill 141 259 283 141 308 285 minecraft:snow_block
setblock 142 259 278 minecraft:packed_ice
setblock 142 259 279 minecraft:snow_block
fill 142 259 280 142 262 280 minecraft:packed_ice
setblock 142 259 283 minecraft:packed_ice
setblock 142 259 284 minecraft:snow_block
fill 142 259 292 142 259 293 minecraft:packed_ice
setblock 142 259 294 minecraft:snow_block
fill 142 259 295 143 261 295 minecraft:packed_ice
setblock 142 259 299 minecraft:snow_block
fill 142 259 300 143 261 300 minecraft:packed_ice
setblock 142 259 303 minecraft:packed_ice
setblock 142 259 304 minecraft:snow_block
fill 142 259 305 142 259 308 minecraft:packed_ice
setblock 142 259 309 minecraft:snow_block
fill 142 259 310 143 261 310 minecraft:packed_ice
setblock 142 259 314 minecraft:snow_block
fill 142 259 315 142 262 315 minecraft:packed_ice
setblock 143 259 278 minecraft:snow_block
fill 143 259 279 143 262 279 minecraft:packed_ice
fill 143 259 281 143 259 282 minecraft:packed_ice
setblock 143 259 297 minecraft:packed_ice
setblock 143 259 298 minecraft:snow_block
fill 143 259 299 143 262 299 minecraft:packed_ice
fill 143 259 301 143 259 302 minecraft:packed_ice
setblock 143 259 303 minecraft:snow_block
setblock 143 259 313 minecraft:snow_block
fill 143 259 314 143 262 314 minecraft:packed_ice
setblock 144 259 277 minecraft:snow_block
fill 144 259 278 144 262 278 minecraft:packed_ice
fill 144 259 280 144 260 280 minecraft:packed_ice
setblock 144 259 312 minecraft:snow_block
fill 144 259 313 144 262 313 minecraft:packed_ice
setblock 145 259 276 minecraft:snow_block
fill 145 259 277 145 262 277 minecraft:packed_ice
setblock 145 259 279 minecraft:blue_ice
setblock 145 259 316 minecraft:snow_block
fill 146 259 276 146 262 276 minecraft:packed_ice
fill 146 259 278 147 259 278 minecraft:packed_ice
setblock 146 259 308 minecraft:blue_ice
setblock 146 259 313 minecraft:blue_ice
setblock 146 259 315 minecraft:snow_block
fill 146 259 316 146 262 316 minecraft:packed_ice
setblock 147 259 314 minecraft:snow_block
fill 147 259 315 147 262 315 minecraft:packed_ice
setblock 148 259 278 minecraft:snow_block
fill 148 259 314 148 262 314 minecraft:packed_ice
setblock 149 259 277 minecraft:snow_block
fill 149 259 278 149 261 278 minecraft:packed_ice
setblock 150 259 276 minecraft:snow_block
fill 150 259 277 150 262 277 minecraft:packed_ice
setblock 150 259 316 minecraft:snow_block
fill 151 259 276 151 262 276 minecraft:packed_ice
setblock 151 259 315 minecraft:snow_block
fill 151 259 316 154 259 316 minecraft:packed_ice
fill 152 259 315 152 261 315 minecraft:packed_ice
setblock 155 259 276 minecraft:snow_block
setblock 155 259 316 minecraft:snow_block
fill 156 259 276 156 261 276 minecraft:packed_ice
fill 156 259 316 159 259 316 minecraft:packed_ice
setblock 159 259 276 minecraft:packed_ice
fill 159 259 278 160 260 278 minecraft:snow_block
setblock 160 259 276 minecraft:snow_block
setblock 160 259 316 minecraft:snow_block
fill 161 259 276 161 262 276 minecraft:packed_ice
fill 161 259 316 161 262 316 minecraft:packed_ice
fill 161 259 317 161 302 317 minecraft:snow_block
fill 162 259 277 163 259 277 minecraft:packed_ice
setblock 163 259 275 minecraft:light_blue_concrete
fill 163 259 315 163 260 315 minecraft:packed_ice
setblock 164 259 277 minecraft:snow_block
setblock 165 259 276 minecraft:snow_block
fill 165 259 277 165 261 278 minecraft:packed_ice
setblock 165 259 316 minecraft:snow_block
fill 166 259 276 166 262 276 minecraft:packed_ice
fill 166 259 278 167 259 278 minecraft:packed_ice
setblock 166 259 315 minecraft:snow_block
fill 166 259 316 166 262 316 minecraft:packed_ice
fill 167 259 315 167 261 315 minecraft:packed_ice
setblock 168 259 277 minecraft:packed_ice
setblock 168 259 278 minecraft:snow_block
setblock 169 259 277 minecraft:snow_block
fill 169 259 278 169 262 278 minecraft:packed_ice
setblock 170 259 276 minecraft:snow_block
fill 170 259 277 170 262 277 minecraft:packed_ice
setblock 170 259 316 minecraft:snow_block
fill 171 259 276 171 262 276 minecraft:packed_ice
fill 171 259 278 172 259 278 minecraft:packed_ice
fill 171 259 316 171 262 316 minecraft:packed_ice
setblock 174 259 277 minecraft:snow_block
setblock 175 259 276 minecraft:snow_block
fill 175 259 277 178 259 277 minecraft:packed_ice
fill 176 259 276 176 262 276 minecraft:packed_ice
fill 177 259 316 177 261 316 minecraft:packed_ice
setblock 179 259 277 minecraft:snow_block
setblock 180 259 276 minecraft:snow_block
fill 180 259 277 180 260 279 minecraft:packed_ice
setblock 180 259 316 minecraft:snow_block
fill 181 259 276 181 262 276 minecraft:packed_ice
setblock 181 259 280 minecraft:snow_block
fill 181 259 281 181 260 283 minecraft:packed_ice
fill 181 259 316 181 262 316 minecraft:packed_ice
setblock 182 259 279 minecraft:snow_block
fill 182 259 280 182 262 280 minecraft:packed_ice
fill 182 259 282 182 259 283 minecraft:packed_ice
setblock 182 259 284 minecraft:snow_block
fill 182 259 285 182 262 285 minecraft:packed_ice
setblock 182 259 289 minecraft:snow_block
fill 182 259 290 182 262 290 minecraft:packed_ice
setblock 182 259 294 minecraft:snow_block
fill 182 259 295 182 262 295 minecraft:packed_ice
setblock 182 259 299 minecraft:snow_block
fill 182 259 300 182 260 302 minecraft:packed_ice
fill 182 259 312 182 260 312 minecraft:packed_ice
setblock 182 259 314 minecraft:snow_block
fill 182 259 315 182 262 315 minecraft:packed_ice
fill 183 259 297 183 267 297 minecraft:snow_block
fill 183 259 300 183 261 301 minecraft:snow_block
setblock 183 259 302 minecraft:white_concrete
fill 183 259 303 183 302 304 minecraft:snow_block
fill 183 259 306 183 308 306 minecraft:snow_block
fill 141 260 278 142 260 278 minecraft:snow_block
setblock 141 260 279 minecraft:light_blue_concrete
fill 141 260 282 141 308 282 minecraft:snow_block
fill 142 260 279 142 263 279 minecraft:packed_ice
setblock 142 260 283 minecraft:snow_block
fill 142 260 284 142 262 285 minecraft:packed_ice
setblock 142 260 292 minecraft:packed_ice
setblock 142 260 293 minecraft:snow_block
fill 142 260 294 143 261 294 minecraft:packed_ice
setblock 142 260 297 minecraft:packed_ice
setblock 142 260 298 minecraft:snow_block
fill 142 260 299 142 263 299 minecraft:packed_ice
setblock 142 260 303 minecraft:snow_block
fill 142 260 304 142 260 307 minecraft:packed_ice
setblock 142 260 308 minecraft:snow_block
fill 142 260 309 143 262 309 minecraft:packed_ice
setblock 142 260 312 minecraft:packed_ice
setblock 142 260 313 minecraft:snow_block
fill 142 260 314 142 263 314 minecraft:packed_ice
setblock 143 260 277 minecraft:snow_block
fill 143 260 278 143 263 278 minecraft:packed_ice
setblock 143 260 281 minecraft:packed_ice
setblock 143 260 282 minecraft:snow_block
fill 143 260 283 143 263 283 minecraft:packed_ice
setblock 143 260 297 minecraft:snow_block
fill 143 260 298 144 262 298 minecraft:packed_ice
setblock 143 260 301 minecraft:packed_ice
setblock 143 260 302 minecraft:snow_block
fill 143 260 303 143 260 306 minecraft:packed_ice
setblock 143 260 307 minecraft:snow_block
fill 143 260 308 143 263 308 minecraft:packed_ice
setblock 143 260 312 minecraft:snow_block
fill 143 260 313 143 263 313 minecraft:packed_ice
setblock 144 260 276 minecraft:snow_block
fill 144 260 277 144 263 277 minecraft:packed_ice
setblock 144 260 281 minecraft:snow_block
setblock 144 260 286 minecraft:light[level=15]
setblock 144 260 294 minecraft:light[level=15]
fill 144 260 297 144 263 297 minecraft:packed_ice
fill 144 260 299 144 260 300 minecraft:packed_ice
setblock 144 260 301 minecraft:snow_block
fill 144 260 302 144 262 303 minecraft:packed_ice
setblock 144 260 310 minecraft:light[level=15]
fill 144 260 312 144 263 312 minecraft:packed_ice
setblock 144 260 316 minecraft:snow_block
fill 145 260 276 145 263 276 minecraft:packed_ice
setblock 145 260 315 minecraft:snow_block
fill 145 260 316 145 263 316 minecraft:packed_ice
setblock 146 260 278 minecraft:packed_ice
setblock 146 260 314 minecraft:snow_block
fill 146 260 315 146 263 315 minecraft:packed_ice
setblock 147 260 278 minecraft:snow_block
fill 147 260 314 147 262 314 minecraft:packed_ice
setblock 148 260 277 minecraft:snow_block
fill 148 260 278 148 262 278 minecraft:packed_ice
setblock 149 260 276 minecraft:snow_block
fill 149 260 277 149 263 277 minecraft:packed_ice
setblock 149 260 316 minecraft:snow_block
fill 150 260 276 150 263 276 minecraft:packed_ice
setblock 150 260 315 minecraft:snow_block
fill 150 260 316 153 260 316 minecraft:packed_ice
fill 151 260 315 151 262 315 minecraft:packed_ice
setblock 152 260 278 minecraft:light[level=15]
setblock 152 260 286 minecraft:light[level=15]
setblock 152 260 294 minecraft:light[level=15]
setblock 152 260 302 minecraft:light[level=15]
setblock 152 260 310 minecraft:light[level=15]
setblock 154 260 276 minecraft:snow_block
setblock 154 260 316 minecraft:snow_block
fill 155 260 276 155 261 276 minecraft:packed_ice
fill 155 260 316 158 260 316 minecraft:packed_ice
fill 157 260 276 158 260 276 minecraft:packed_ice
setblock 159 260 276 minecraft:snow_block
setblock 159 260 316 minecraft:snow_block
fill 160 260 276 160 263 276 minecraft:packed_ice
setblock 160 260 286 minecraft:light[level=15]
setblock 160 260 302 minecraft:light[level=15]
setblock 160 260 310 minecraft:light[level=15]
fill 160 260 316 160 263 316 minecraft:packed_ice
fill 161 260 277 162 260 277 minecraft:packed_ice
fill 163 260 275 163 308 275 minecraft:snow_block
setblock 163 260 277 minecraft:snow_block
setblock 164 260 276 minecraft:snow_block
fill 164 260 277 164 262 278 minecraft:packed_ice
setblock 164 260 316 minecraft:snow_block
fill 165 260 276 165 263 276 minecraft:packed_ice
setblock 165 260 315 minecraft:snow_block
fill 165 260 316 165 263 316 minecraft:packed_ice
setblock 166 260 278 minecraft:packed_ice
fill 166 260 315 166 261 315 minecraft:packed_ice
setblock 167 260 278 minecraft:snow_block
setblock 168 260 277 minecraft:snow_block
fill 168 260 278 168 263 278 minecraft:packed_ice
setblock 168 260 286 minecraft:light[level=15]
setblock 168 260 294 minecraft:light[level=15]
setblock 168 260 302 minecraft:light[level=15]
setblock 168 260 310 minecraft:light[level=15]
setblock 169 260 276 minecraft:snow_block
fill 169 260 277 169 263 277 minecraft:packed_ice
setblock 169 260 316 minecraft:snow_block
fill 170 260 276 170 263 276 minecraft:packed_ice
fill 170 260 314 172 263 315 minecraft:blue_ice
fill 170 260 316 170 262 316 minecraft:packed_ice
setblock 171 260 278 minecraft:packed_ice
setblock 172 260 278 minecraft:snow_block
setblock 173 260 277 minecraft:snow_block
fill 173 260 278 173 262 278 minecraft:packed_ice
setblock 174 260 276 minecraft:snow_block
fill 174 260 277 177 260 277 minecraft:packed_ice
setblock 174 260 316 minecraft:snow_block
fill 175 260 276 175 263 276 minecraft:packed_ice
setblock 176 260 278 minecraft:light[level=15]
setblock 176 260 286 minecraft:light[level=15]
setblock 176 260 294 minecraft:light[level=15]
setblock 176 260 302 minecraft:light[level=15]
setblock 176 260 310 minecraft:light[level=15]
setblock 178 260 277 minecraft:snow_block
fill 178 260 278 179 262 278 minecraft:packed_ice
setblock 178 260 316 minecraft:packed_ice
setblock 179 260 276 minecraft:snow_block
fill 179 260 277 179 263 277 minecraft:packed_ice
setblock 179 260 316 minecraft:snow_block
fill 180 260 276 180 263 276 minecraft:packed_ice
setblock 180 260 280 minecraft:snow_block
fill 180 260 316 180 263 316 minecraft:packed_ice
setblock 181 260 278 minecraft:packed_ice
setblock 181 260 279 minecraft:snow_block
fill 181 260 280 181 263 280 minecraft:packed_ice
setblock 181 260 284 minecraft:snow_block
fill 181 260 295 181 260 298 minecraft:packed_ice
setblock 181 260 299 minecraft:snow_block
fill 181 260 315 181 263 315 minecraft:packed_ice
setblock 182 260 278 minecraft:snow_block
fill 182 260 279 182 263 279 minecraft:packed_ice
setblock 182 260 282 minecraft:packed_ice
setblock 182 260 283 minecraft:snow_block
fill 182 260 284 182 263 284 minecraft:packed_ice
fill 182 260 286 182 260 287 minecraft:packed_ice
setblock 182 260 288 minecraft:snow_block
fill 182 260 289 182 263 289 minecraft:packed_ice
setblock 182 260 293 minecraft:snow_block
fill 182 260 294 182 263 294 minecraft:packed_ice
setblock 182 260 297 minecraft:packed_ice
setblock 182 260 298 minecraft:snow_block
fill 182 260 299 182 263 299 minecraft:packed_ice
setblock 182 260 303 minecraft:snow_block
fill 182 260 304 182 263 304 minecraft:packed_ice
setblock 182 260 313 minecraft:snow_block
fill 182 260 314 182 263 314 minecraft:packed_ice
fill 183 260 302 183 280 302 minecraft:snow_block
fill 141 261 278 141 308 279 minecraft:snow_block
setblock 142 261 277 minecraft:snow_block
fill 142 261 278 142 264 278 minecraft:packed_ice
setblock 142 261 281 minecraft:packed_ice
setblock 142 261 282 minecraft:snow_block
fill 142 261 283 142 264 283 minecraft:packed_ice
setblock 142 261 286 minecraft:packed_ice
setblock 142 261 292 minecraft:snow_block
fill 142 261 293 142 263 293 minecraft:packed_ice
setblock 142 261 296 minecraft:packed_ice
setblock 142 261 297 minecraft:snow_block
fill 142 261 298 142 264 298 minecraft:packed_ice
setblock 142 261 301 minecraft:packed_ice
setblock 142 261 302 minecraft:snow_block
fill 142 261 303 142 261 306 minecraft:packed_ice
setblock 142 261 307 minecraft:snow_block
fill 142 261 308 142 264 308 minecraft:packed_ice
setblock 142 261 311 minecraft:packed_ice
setblock 142 261 312 minecraft:snow_block
fill 142 261 313 142 264 313 minecraft:packed_ice
setblock 143 261 276 minecraft:snow_block
fill 143 261 277 143 264 277 minecraft:packed_ice
setblock 143 261 281 minecraft:snow_block
fill 143 261 282 143 264 282 minecraft:packed_ice
setblock 143 261 296 minecraft:snow_block
fill 143 261 297 143 264 297 minecraft:packed_ice
setblock 143 261 301 minecraft:snow_block
fill 143 261 302 143 261 305 minecraft:packed_ice
setblock 143 261 306 minecraft:snow_block
fill 143 261 307 143 264 307 minecraft:packed_ice
setblock 143 261 311 minecraft:snow_block
fill 143 261 312 143 264 312 minecraft:packed_ice
setblock 143 261 316 minecraft:snow_block
fill 144 261 276 144 264 276 minecraft:packed_ice
setblock 144 261 280 minecraft:snow_block
fill 144 261 281 144 264 281 minecraft:packed_ice
setblock 144 261 296 minecraft:packed_ice
setblock 144 261 299 minecraft:packed_ice
setblock 144 261 300 minecraft:snow_block
fill 144 261 301 144 264 301 minecraft:packed_ice
setblock 144 261 304 minecraft:packed_ice
setblock 144 261 305 minecraft:snow_block
fill 144 261 306 144 264 306 minecraft:packed_ice
fill 144 261 311 144 263 311 minecraft:packed_ice
setblock 144 261 315 minecraft:snow_block
fill 144 261 316 144 264 316 minecraft:packed_ice
setblock 145 261 279 minecraft:snow_block
fill 145 261 300 145 263 300 minecraft:packed_ice
setblock 145 261 314 minecraft:snow_block
fill 145 261 315 145 264 315 minecraft:packed_ice
setblock 146 261 278 minecraft:snow_block
fill 146 261 314 146 263 314 minecraft:packed_ice
setblock 147 261 277 minecraft:snow_block
fill 147 261 278 147 263 278 minecraft:packed_ice
setblock 148 261 276 minecraft:snow_block
fill 148 261 277 148 264 277 minecraft:packed_ice
setblock 148 261 316 minecraft:snow_block
fill 149 261 276 149 264 276 minecraft:packed_ice
setblock 149 261 315 minecraft:snow_block
fill 149 261 316 152 261 316 minecraft:packed_ice
fill 150 261 315 150 262 315 minecraft:packed_ice
fill 152 261 277 152 262 279 minecraft:blue_ice
setblock 153 261 276 minecraft:snow_block
fill 153 261 277 153 262 277 minecraft:blue_ice
setblock 153 261 316 minecraft:snow_block
fill 154 261 276 154 262 276 minecraft:packed_ice
fill 154 261 316 157 261 316 minecraft:packed_ice
setblock 157 261 276 minecraft:packed_ice
setblock 158 261 276 minecraft:snow_block
setblock 158 261 316 minecraft:snow_block
fill 159 261 276 159 264 276 minecraft:packed_ice
fill 159 261 316 159 262 316 minecraft:packed_ice
setblock 161 261 277 minecraft:packed_ice
setblock 162 261 277 minecraft:snow_block
setblock 163 261 276 minecraft:snow_block
fill 163 261 277 163 263 278 minecraft:packed_ice
setblock 163 261 316 minecraft:snow_block
fill 164 261 276 164 264 276 minecraft:packed_ice
setblock 164 261 315 minecraft:snow_block
fill 164 261 316 164 264 316 minecraft:packed_ice
setblock 165 261 315 minecraft:packed_ice
setblock 166 261 278 minecraft:snow_block
setblock 167 261 277 minecraft:snow_block
fill 167 261 278 167 264 278 minecraft:packed_ice
setblock 168 261 276 minecraft:snow_block
fill 168 261 277 168 264 277 minecraft:packed_ice
fill 168 261 290 170 262 291 minecraft:white_concrete
setblock 168 261 316 minecraft:snow_block
fill 169 261 276 169 264 276 minecraft:packed_ice
fill 169 261 314 169 262 315 minecraft:blue_ice
fill 169 261 316 169 263 316 minecraft:packed_ice
fill 170 261 313 172 263 313 minecraft:blue_ice
setblock 171 261 278 minecraft:snow_block
setblock 172 261 277 minecraft:snow_block
fill 172 261 278 172 262 278 minecraft:packed_ice
setblock 173 261 276 minecraft:snow_block
fill 173 261 277 176 261 277 minecraft:packed_ice
fill 173 261 314 173 262 316 minecraft:blue_ice
fill 174 261 276 174 264 276 minecraft:packed_ice
fill 174 261 306 175 262 307 minecraft:snow_block
setblock 177 261 277 minecraft:snow_block
fill 177 261 278 177 264 278 minecraft:packed_ice
setblock 178 261 276 minecraft:snow_block
fill 178 261 277 178 264 277 minecraft:packed_ice
setblock 178 261 316 minecraft:snow_block
fill 179 261 276 179 264 276 minecraft:packed_ice
fill 179 261 316 179 264 316 minecraft:packed_ice
fill 180 261 277 180 261 278 minecraft:packed_ice
setblock 180 261 279 minecraft:snow_block
fill 180 261 280 180 262 282 minecraft:packed_ice
setblock 181 261 278 minecraft:snow_block
fill 181 261 279 181 264 279 minecraft:packed_ice
fill 181 261 281 181 261 282 minecraft:packed_ice
setblock 181 261 283 minecraft:snow_block
fill 181 261 284 181 263 285 minecraft:packed_ice
fill 181 261 296 181 261 297 minecraft:packed_ice
setblock 181 261 298 minecraft:snow_block
fill 181 261 299 181 263 300 minecraft:packed_ice
setblock 182 261 277 minecraft:snow_block
fill 182 261 278 182 264 278 minecraft:packed_ice
setblock 182 261 282 minecraft:snow_block
fill 182 261 283 182 264 283 minecraft:packed_ice
setblock 182 261 286 minecraft:packed_ice
setblock 182 261 287 minecraft:snow_block
fill 182 261 288 182 264 288 minecraft:packed_ice
setblock 182 261 292 minecraft:snow_block
fill 182 261 293 182 264 293 minecraft:packed_ice
setblock 182 261 297 minecraft:snow_block
fill 182 261 298 182 264 298 minecraft:packed_ice
fill 182 261 300 182 261 301 minecraft:packed_ice
setblock 182 261 302 minecraft:snow_block
fill 182 261 303 182 264 303 minecraft:packed_ice
fill 182 261 305 182 261 306 minecraft:packed_ice
setblock 182 261 311 minecraft:packed_ice
setblock 182 261 312 minecraft:snow_block
fill 182 261 313 182 264 313 minecraft:packed_ice
fill 183 261 309 183 272 311 minecraft:snow_block
setblock 183 261 312 minecraft:light_blue_concrete
fill 183 261 313 183 263 316 minecraft:snow_block
setblock 142 262 276 minecraft:snow_block
fill 142 262 277 142 265 277 minecraft:packed_ice
setblock 142 262 281 minecraft:snow_block
fill 142 262 282 142 265 282 minecraft:packed_ice
setblock 142 262 286 minecraft:snow_block
setblock 142 262 292 minecraft:packed_ice
fill 142 262 294 142 262 295 minecraft:packed_ice
setblock 142 262 296 minecraft:snow_block
fill 142 262 297 142 265 297 minecraft:packed_ice
setblock 142 262 300 minecraft:packed_ice
setblock 142 262 301 minecraft:snow_block
fill 142 262 302 142 262 305 minecraft:packed_ice
setblock 142 262 306 minecraft:snow_block
fill 142 262 307 142 265 307 minecraft:packed_ice
setblock 142 262 310 minecraft:packed_ice
setblock 142 262 311 minecraft:snow_block
fill 142 262 312 142 265 312 minecraft:packed_ice
setblock 142 262 316 minecraft:snow_block
fill 143 262 276 143 265 276 minecraft:packed_ice
setblock 143 262 280 minecraft:snow_block
fill 143 262 281 143 265 281 minecraft:packed_ice
setblock 143 262 284 minecraft:packed_ice
setblock 143 262 295 minecraft:snow_block
fill 143 262 296 143 264 296 minecraft:packed_ice
setblock 143 262 300 minecraft:snow_block
fill 143 262 301 143 262 304 minecraft:packed_ice
setblock 143 262 305 minecraft:snow_block
fill 143 262 306 143 265 306 minecraft:packed_ice
setblock 143 262 310 minecraft:snow_block
fill 143 262 311 143 265 311 minecraft:packed_ice
setblock 143 262 315 minecraft:snow_block
fill 143 262 316 143 265 316 minecraft:packed_ice
setblock 144 262 279 minecraft:snow_block
fill 144 262 280 144 265 280 minecraft:packed_ice
fill 144 262 282 144 263 282 minecraft:packed_ice
setblock 144 262 285 minecraft:light[level=12]
setblock 144 262 292 minecraft:light[level=12]
setblock 144 262 299 minecraft:snow_block
fill 144 262 300 144 265 300 minecraft:packed_ice
setblock 144 262 304 minecraft:snow_block
fill 144 262 305 144 265 305 minecraft:packed_ice
fill 144 262 307 144 262 308 minecraft:packed_ice
setblock 144 262 309 minecraft:snow_block
fill 144 262 310 144 263 310 minecraft:packed_ice
setblock 144 262 314 minecraft:snow_block
fill 144 262 315 144 265 315 minecraft:packed_ice
setblock 145 262 278 minecraft:snow_block
fill 145 262 301 145 262 302 minecraft:packed_ice
setblock 145 262 303 minecraft:snow_block
fill 145 262 314 145 263 314 minecraft:packed_ice
setblock 146 262 277 minecraft:snow_block
fill 146 262 278 146 264 278 minecraft:packed_ice
setblock 147 262 276 minecraft:snow_block
fill 147 262 277 147 265 277 minecraft:packed_ice
setblock 147 262 316 minecraft:snow_block
fill 148 262 276 148 265 276 minecraft:packed_ice
fill 148 262 279 148 268 279 minecraft:packed_ice
setblock 148 262 315 minecraft:snow_block
fill 148 262 316 151 262 316 minecraft:packed_ice
fill 149 262 315 149 263 315 minecraft:packed_ice
setblock 151 262 277 minecraft:snow_block
fill 151 262 278 151 262 279 minecraft:blue_ice
setblock 151 262 285 minecraft:light[level=12]
setblock 151 262 292 minecraft:light[level=12]
setblock 151 262 299 minecraft:light[level=12]
setblock 151 262 306 minecraft:light[level=12]
setblock 151 262 313 minecraft:light[level=12]
setblock 152 262 276 minecraft:snow_block
fill 152 262 280 152 262 282 minecraft:blue_ice
setblock 152 262 316 minecraft:snow_block
setblock 153 262 276 minecraft:packed_ice
fill 153 262 278 153 262 279 minecraft:blue_ice
fill 153 262 316 154 262 316 minecraft:packed_ice
setblock 157 262 276 minecraft:snow_block
fill 158 262 276 158 263 276 minecraft:packed_ice
setblock 158 262 278 minecraft:light[level=12]
setblock 158 262 285 minecraft:light[level=12]
setblock 158 262 292 minecraft:light[level=12]
setblock 158 262 299 minecraft:light[level=12]
setblock 158 262 306 minecraft:light[level=12]
setblock 158 262 313 minecraft:light[level=12]
setblock 160 262 277 minecraft:packed_ice
setblock 161 262 277 minecraft:snow_block
setblock 162 262 276 minecraft:snow_block
fill 162 262 277 162 264 278 minecraft:packed_ice
setblock 162 262 316 minecraft:snow_block
fill 163 262 276 163 265 276 minecraft:packed_ice
fill 163 262 316 163 264 316 minecraft:packed_ice
setblock 165 262 277 minecraft:packed_ice
setblock 165 262 278 minecraft:snow_block
setblock 165 262 285 minecraft:light[level=12]
setblock 165 262 292 minecraft:light[level=12]
setblock 165 262 299 minecraft:light[level=12]
setblock 165 262 306 minecraft:light[level=12]
setblock 165 262 313 minecraft:light[level=12]
setblock 166 262 277 minecraft:snow_block
fill 166 262 278 166 263 279 minecraft:packed_ice
setblock 167 262 276 minecraft:snow_block
fill 167 262 277 167 265 277 minecraft:packed_ice
setblock 167 262 279 minecraft:packed_ice
setblock 167 262 316 minecraft:snow_block
fill 168 262 276 168 265 276 minecraft:packed_ice
fill 168 262 316 168 263 316 minecraft:packed_ice
setblock 170 262 278 minecraft:snow_block
setblock 171 262 277 minecraft:snow_block
fill 171 262 278 171 263 278 minecraft:packed_ice
fill 171 262 312 171 263 312 minecraft:blue_ice
setblock 172 262 276 minecraft:snow_block
fill 172 262 277 175 262 277 minecraft:packed_ice
setblock 172 262 285 minecraft:light[level=12]
setblock 172 262 292 minecraft:light[level=12]
setblock 172 262 299 minecraft:light[level=12]
setblock 172 262 306 minecraft:light[level=12]
fill 172 262 316 172 263 316 minecraft:blue_ice
fill 173 262 276 173 265 276 minecraft:packed_ice
setblock 176 262 277 minecraft:snow_block
fill 176 262 278 176 263 278 minecraft:packed_ice
setblock 177 262 276 minecraft:snow_block
fill 177 262 277 177 265 277 minecraft:packed_ice
fill 178 262 276 178 265 276 minecraft:packed_ice
fill 178 262 316 178 264 316 minecraft:packed_ice
setblock 179 262 285 minecraft:light[level=12]
setblock 179 262 292 minecraft:light[level=12]
setblock 179 262 299 minecraft:light[level=12]
setblock 179 262 306 minecraft:light[level=12]
setblock 179 262 313 minecraft:light[level=12]
setblock 180 262 277 minecraft:packed_ice
setblock 180 262 278 minecraft:snow_block
fill 180 262 279 180 265 279 minecraft:packed_ice
setblock 181 262 277 minecraft:snow_block
fill 181 262 278 181 265 278 minecraft:packed_ice
setblock 181 262 281 minecraft:packed_ice
setblock 181 262 282 minecraft:snow_block
fill 181 262 283 181 265 283 minecraft:packed_ice
setblock 181 262 286 minecraft:packed_ice
fill 181 262 289 181 268 289 minecraft:packed_ice
setblock 181 262 296 minecraft:packed_ice
setblock 181 262 297 minecraft:snow_block
fill 181 262 298 181 263 298 minecraft:packed_ice
setblock 181 262 301 minecraft:packed_ice
setblock 181 262 302 minecraft:snow_block
setblock 182 262 276 minecraft:snow_block
fill 182 262 277 182 265 277 minecraft:packed_ice
setblock 182 262 281 minecraft:snow_block
fill 182 262 282 182 265 282 minecraft:packed_ice
setblock 182 262 286 minecraft:snow_block
fill 182 262 287 182 265 287 minecraft:packed_ice
setblock 182 262 291 minecraft:snow_block
fill 182 262 292 182 263 292 minecraft:packed_ice
setblock 182 262 296 minecraft:snow_block
fill 182 262 297 182 265 297 minecraft:packed_ice
setblock 182 262 300 minecraft:packed_ice
fill 182 262 301 183 262 301 minecraft:snow_block
fill 182 262 302 182 265 302 minecraft:packed_ice
setblock 182 262 305 minecraft:packed_ice
setblock 182 262 306 minecraft:snow_block
fill 182 262 307 182 262 310 minecraft:packed_ice
setblock 182 262 311 minecraft:snow_block
fill 182 262 312 182 265 312 minecraft:packed_ice
setblock 182 262 316 minecraft:snow_block
setblock 183 262 300 minecraft:white_concrete
fill 183 262 312 183 308 312 minecraft:snow_block
fill 142 263 276 142 266 276 minecraft:packed_ice
setblock 142 263 280 minecraft:snow_block
fill 142 263 281 142 266 281 minecraft:packed_ice
setblock 142 263 284 minecraft:packed_ice
setblock 142 263 285 minecraft:snow_block
fill 142 263 286 142 265 287 minecraft:packed_ice
setblock 142 263 294 minecraft:packed_ice
setblock 142 263 295 minecraft:snow_block
fill 142 263 296 142 266 296 minecraft:packed_ice
setblock 142 263 300 minecraft:snow_block
fill 142 263 301 142 263 304 minecraft:packed_ice
setblock 142 263 305 minecraft:snow_block
fill 142 263 306 142 266 306 minecraft:packed_ice
setblock 142 263 309 minecraft:packed_ice
setblock 142 263 310 minecraft:snow_block
fill 142 263 311 142 266 311 minecraft:packed_ice
setblock 142 263 315 minecraft:snow_block
fill 142 263 316 142 266 316 minecraft:packed_ice
setblock 143 263 279 minecraft:snow_block
fill 143 263 280 143 266 280 minecraft:packed_ice
setblock 143 263 284 minecraft:snow_block
setblock 143 263 295 minecraft:packed_ice
setblock 143 263 298 minecraft:packed_ice
setblock 143 263 299 minecraft:snow_block
fill 143 263 300 143 263 303 minecraft:packed_ice
setblock 143 263 304 minecraft:snow_block
fill 143 263 305 143 266 305 minecraft:packed_ice
setblock 143 263 309 minecraft:snow_block
fill 143 263 310 143 266 310 minecraft:packed_ice
setblock 143 263 314 minecraft:snow_block
fill 143 263 315 143 266 315 minecraft:packed_ice
setblock 144 263 278 minecraft:snow_block
fill 144 263 279 144 265 279 minecraft:packed_ice
setblock 144 263 298 minecraft:snow_block
fill 144 263 299 144 265 299 minecraft:packed_ice
setblock 144 263 302 minecraft:packed_ice
setblock 144 263 303 minecraft:snow_block
fill 144 263 304 145 265 304 minecraft:packed_ice
setblock 144 263 307 minecraft:packed_ice
setblock 144 263 308 minecraft:snow_block
fill 144 263 309 144 266 309 minecraft:packed_ice
setblock 144 263 313 minecraft:snow_block
fill 144 263 314 144 264 314 minecraft:packed_ice
setblock 145 263 277 minecraft:snow_block
fill 145 263 278 145 264 278 minecraft:packed_ice
setblock 145 263 301 minecraft:packed_ice
setblock 145 263 302 minecraft:snow_block
fill 145 263 303 145 265 303 minecraft:packed_ice
setblock 146 263 276 minecraft:snow_block
fill 146 263 277 146 265 277 minecraft:packed_ice
setblock 146 263 316 minecraft:snow_block
fill 147 263 276 147 266 276 minecraft:packed_ice
setblock 147 263 315 minecraft:snow_block
fill 147 263 316 150 263 316 minecraft:packed_ice
fill 148 263 315 148 264 315 minecraft:packed_ice
setblock 150 263 277 minecraft:snow_block
setblock 151 263 276 minecraft:snow_block
setblock 151 263 316 minecraft:snow_block
setblock 152 263 275 minecraft:white_concrete
setblock 152 263 276 minecraft:packed_ice
fill 152 263 277 152 263 278 minecraft:blue_ice
fill 152 263 281 152 263 282 minecraft:blue_ice
setblock 152 263 316 minecraft:packed_ice
setblock 160 263 277 minecraft:snow_block
setblock 161 263 276 minecraft:snow_block
fill 161 263 277 161 265 277 minecraft:packed_ice
setblock 161 263 316 minecraft:snow_block
fill 162 263 276 162 266 276 minecraft:packed_ice
fill 162 263 316 162 264 316 minecraft:packed_ice
setblock 164 263 277 minecraft:packed_ice
setblock 164 263 278 minecraft:snow_block
setblock 165 263 277 minecraft:snow_block
fill 165 263 278 165 265 278 minecraft:packed_ice
setblock 166 263 276 minecraft:snow_block
fill 166 263 277 166 266 277 minecraft:packed_ice
setblock 166 263 316 minecraft:snow_block
fill 167 263 276 167 266 276 minecraft:packed_ice
fill 167 263 316 167 264 316 minecraft:packed_ice
setblock 169 263 278 minecraft:snow_block
setblock 170 263 277 minecraft:snow_block
setblock 170 263 278 minecraft:packed_ice
setblock 170 263 312 minecraft:blue_ice
fill 170 263 316 171 263 316 minecraft:blue_ice
setblock 171 263 276 minecraft:snow_block
fill 171 263 277 174 263 277 minecraft:packed_ice
setblock 171 263 311 minecraft:blue_ice
fill 172 263 276 172 266 276 minecraft:packed_ice
setblock 172 263 312 minecraft:blue_ice
setblock 175 263 277 minecraft:snow_block
setblock 176 263 276 minecraft:snow_block
fill 176 263 277 176 266 277 minecraft:packed_ice
fill 177 263 276 177 266 276 minecraft:packed_ice
setblock 178 263 278 minecraft:packed_ice
setblock 179 263 278 minecraft:snow_block
setblock 180 263 277 minecraft:snow_block
fill 180 263 278 180 266 278 minecraft:packed_ice
fill 180 263 280 180 263 281 minecraft:packed_ice
setblock 180 263 282 minecraft:snow_block
fill 180 263 283 180 266 283 minecraft:packed_ice
setblock 181 263 276 minecraft:snow_block
fill 181 263 277 181 266 277 minecraft:packed_ice
setblock 181 263 281 minecraft:snow_block
fill 181 263 282 181 266 282 minecraft:packed_ice
setblock 181 263 286 minecraft:snow_block
setblock 181 263 297 minecraft:packed_ice
setblock 181 263 301 minecraft:snow_block
fill 181 263 302 181 265 303 minecraft:packed_ice
setblock 181 263 316 minecraft:snow_block
fill 182 263 276 182 266 276 minecraft:packed_ice
setblock 182 263 280 minecraft:snow_block
fill 182 263 281 182 266 281 minecraft:packed_ice
setblock 182 263 285 minecraft:snow_block
fill 182 263 286 182 266 286 minecraft:packed_ice
setblock 182 263 290 minecraft:snow_block
setblock 182 263 291 minecraft:packed_ice
setblock 182 263 295 minecraft:snow_block
fill 182 263 296 182 265 296 minecraft:packed_ice
fill 182 263 300 183 263 300 minecraft:snow_block
fill 182 263 301 182 266 301 minecraft:packed_ice
setblock 182 263 305 minecraft:snow_block
fill 182 263 306 182 263 309 minecraft:packed_ice
setblock 182 263 310 minecraft:snow_block
fill 182 263 311 182 266 311 minecraft:packed_ice
setblock 182 263 315 minecraft:snow_block
fill 182 263 316 182 266 316 minecraft:packed_ice
fill 183 263 301 183 308 301 minecraft:snow_block
setblock 142 264 279 minecraft:snow_block
fill 142 264 280 142 267 280 minecraft:packed_ice
setblock 142 264 284 minecraft:snow_block
fill 142 264 285 142 267 285 minecraft:packed_ice
setblock 142 264 294 minecraft:snow_block
fill 142 264 295 142 265 295 minecraft:packed_ice
setblock 142 264 299 minecraft:snow_block
fill 142 264 300 142 264 303 minecraft:packed_ice
setblock 142 264 304 minecraft:snow_block
fill 142 264 305 142 267 305 minecraft:packed_ice
setblock 142 264 309 minecraft:snow_block
fill 142 264 310 142 267 310 minecraft:packed_ice
setblock 142 264 314 minecraft:snow_block
fill 142 264 315 142 267 315 minecraft:packed_ice
setblock 143 264 278 minecraft:snow_block
fill 143 264 279 143 267 279 minecraft:packed_ice
setblock 143 264 283 minecraft:snow_block
fill 143 264 284 143 267 284 minecraft:packed_ice
setblock 143 264 298 minecraft:snow_block
fill 143 264 299 143 264 302 minecraft:packed_ice
setblock 143 264 303 minecraft:snow_block
fill 143 264 304 143 267 304 minecraft:packed_ice
setblock 143 264 308 minecraft:snow_block
fill 143 264 309 143 267 309 minecraft:packed_ice
setblock 143 264 313 minecraft:snow_block
fill 143 264 314 143 267 314 minecraft:packed_ice
setblock 144 264 277 minecraft:snow_block
fill 144 264 278 144 265 278 minecraft:packed_ice
setblock 144 264 298 minecraft:packed_ice
setblock 144 264 302 minecraft:snow_block
fill 144 264 303 144 267 303 minecraft:packed_ice
setblock 144 264 307 minecraft:snow_block
fill 144 264 308 144 267 308 minecraft:packed_ice
setblock 145 264 276 minecraft:snow_block
fill 145 264 277 145 266 277 minecraft:packed_ice
setblock 145 264 301 minecraft:snow_block
setblock 145 264 302 minecraft:packed_ice
setblock 145 264 316 minecraft:snow_block
fill 146 264 276 146 267 276 minecraft:packed_ice
setblock 146 264 315 minecraft:snow_block
fill 146 264 316 149 264 316 minecraft:packed_ice
setblock 147 264 315 minecraft:packed_ice
setblock 150 264 276 minecraft:snow_block
setblock 150 264 316 minecraft:snow_block
setblock 151 264 316 minecraft:packed_ice
fill 152 264 275 152 307 275 minecraft:snow_block
setblock 160 264 276 minecraft:snow_block
setblock 160 264 277 minecraft:packed_ice
fill 161 264 276 161 267 276 minecraft:packed_ice
setblock 161 264 316 minecraft:packed_ice
setblock 163 264 277 minecraft:packed_ice
setblock 163 264 278 minecraft:snow_block
setblock 164 264 277 minecraft:snow_block
fill 164 264 278 164 265 278 minecraft:packed_ice
setblock 165 264 276 minecraft:snow_block
fill 165 264 277 165 267 277 minecraft:packed_ice
setblock 165 264 316 minecraft:snow_block
fill 166 264 276 166 267 276 minecraft:packed_ice
fill 166 264 278 166 265 278 minecraft:packed_ice
setblock 166 264 316 minecraft:packed_ice
setblock 168 264 278 minecraft:snow_block
setblock 169 264 277 minecraft:snow_block
setblock 169 264 278 minecraft:packed_ice
setblock 170 264 276 minecraft:snow_block
fill 170 264 277 173 264 277 minecraft:packed_ice
setblock 170 264 317 minecraft:light_blue_concrete
fill 171 264 276 171 266 276 minecraft:packed_ice
setblock 174 264 277 minecraft:snow_block
setblock 175 264 276 minecraft:snow_block
fill 175 264 277 175 265 277 minecraft:packed_ice
fill 176 264 276 176 267 276 minecraft:packed_ice
setblock 178 264 278 minecraft:snow_block
setblock 179 264 277 minecraft:snow_block
fill 179 264 278 179 267 278 minecraft:packed_ice
setblock 180 264 276 minecraft:snow_block
fill 180 264 277 180 267 277 minecraft:packed_ice
setblock 180 264 280 minecraft:packed_ice
setblock 180 264 281 minecraft:snow_block
fill 180 264 282 180 267 282 minecraft:packed_ice
setblock 180 264 316 minecraft:snow_block
fill 181 264 276 181 267 276 minecraft:packed_ice
setblock 181 264 280 minecraft:snow_block
fill 181 264 281 181 267 281 minecraft:packed_ice
setblock 181 264 284 minecraft:packed_ice
setblock 181 264 285 minecraft:snow_block
fill 181 264 286 181 267 286 minecraft:packed_ice
setblock 181 264 299 minecraft:packed_ice
setblock 181 264 300 minecraft:snow_block
fill 181 264 301 181 266 301 minecraft:packed_ice
setblock 181 264 304 minecraft:packed_ice
setblock 181 264 315 minecraft:snow_block
fill 181 264 316 181 267 316 minecraft:packed_ice
setblock 182 264 279 minecraft:snow_block
fill 182 264 280 182 267 280 minecraft:packed_ice
setblock 182 264 284 minecraft:snow_block
fill 182 264 285 182 267 285 minecraft:packed_ice
setblock 182 264 289 minecraft:snow_block
setblock 182 264 290 minecraft:packed_ice
setblock 182 264 294 minecraft:snow_block
fill 182 264 295 182 265 295 minecraft:packed_ice
setblock 182 264 299 minecraft:snow_block
fill 182 264 300 182 267 300 minecraft:packed_ice
setblock 182 264 304 minecraft:snow_block
fill 182 264 305 182 264 308 minecraft:packed_ice
setblock 182 264 309 minecraft:snow_block
fill 182 264 310 182 267 310 minecraft:packed_ice
fill 182 264 314 183 264 314 minecraft:snow_block
fill 182 264 315 182 267 315 minecraft:packed_ice
fill 183 264 300 183 274 300 minecraft:snow_block
fill 183 264 313 183 308 313 minecraft:snow_block
setblock 183 264 315 minecraft:light_blue_concrete
fill 183 264 316 183 308 316 minecraft:snow_block
setblock 142 265 278 minecraft:snow_block
fill 142 265 279 142 268 279 minecraft:packed_ice
setblock 142 265 283 minecraft:snow_block
fill 142 265 284 142 268 284 minecraft:packed_ice
setblock 142 265 298 minecraft:snow_block
fill 142 265 299 142 265 302 minecraft:packed_ice
setblock 142 265 303 minecraft:snow_block
fill 142 265 304 142 268 304 minecraft:packed_ice
setblock 142 265 308 minecraft:snow_block
fill 142 265 309 142 268 309 minecraft:packed_ice
setblock 142 265 313 minecraft:snow_block
fill 142 265 314 142 268 314 minecraft:packed_ice
setblock 143 265 277 minecraft:snow_block
fill 143 265 278 143 267 278 minecraft:packed_ice
setblock 143 265 282 minecraft:snow_block
fill 143 265 283 143 268 283 minecraft:packed_ice
setblock 143 265 297 minecraft:snow_block
fill 143 265 298 143 265 301 minecraft:packed_ice
setblock 143 265 302 minecraft:snow_block
fill 143 265 303 143 268 303 minecraft:packed_ice
setblock 143 265 307 minecraft:snow_block
fill 143 265 308 143 268 308 minecraft:packed_ice
setblock 143 265 312 minecraft:snow_block
fill 143 265 313 143 268 313 minecraft:packed_ice
setblock 144 265 276 minecraft:snow_block
fill 144 265 277 144 267 277 minecraft:packed_ice
setblock 144 265 281 minecraft:snow_block
setblock 144 265 301 minecraft:snow_block
fill 144 265 302 144 268 302 minecraft:packed_ice
setblock 144 265 306 minecraft:snow_block
fill 144 265 307 144 268 307 minecraft:packed_ice
setblock 144 265 316 minecraft:snow_block
fill 145 265 276 145 267 276 minecraft:packed_ice
setblock 145 265 315 minecraft:snow_block
fill 145 265 316 148 265 316 minecraft:packed_ice
setblock 146 265 315 minecraft:packed_ice
setblock 149 265 276 minecraft:snow_block
setblock 149 265 316 minecraft:snow_block
fill 157 265 288 159 266 288 minecraft:snow_block
fill 158 265 287 159 266 287 minecraft:snow_block
setblock 159 265 276 minecraft:snow_block
fill 160 265 276 160 267 276 minecraft:packed_ice
setblock 162 265 277 minecraft:packed_ice
setblock 163 265 277 minecraft:snow_block
setblock 163 265 278 minecraft:packed_ice
setblock 164 265 276 minecraft:snow_block
fill 164 265 277 164 267 277 minecraft:packed_ice
fill 165 265 276 165 268 276 minecraft:packed_ice
setblock 167 265 278 minecraft:snow_block
fill 167 265 311 167 271 311 minecraft:packed_ice
setblock 168 265 277 minecraft:snow_block
setblock 169 265 276 minecraft:snow_block
fill 169 265 277 171 265 277 minecraft:packed_ice
fill 170 265 276 170 266 276 minecraft:packed_ice
fill 170 265 317 170 308 317 minecraft:snow_block
setblock 174 265 276 minecraft:snow_block
fill 175 265 276 175 268 276 minecraft:packed_ice
setblock 178 265 277 minecraft:snow_block
fill 178 265 278 178 266 278 minecraft:packed_ice
setblock 179 265 276 minecraft:snow_block
fill 179 265 277 179 268 277 minecraft:packed_ice
setblock 179 265 316 minecraft:snow_block
fill 180 265 276 180 268 276 minecraft:packed_ice
setblock 180 265 280 minecraft:snow_block
fill 180 265 281 180 268 281 minecraft:packed_ice
setblock 180 265 284 minecraft:packed_ice
fill 180 265 316 180 268 316 minecraft:packed_ice
setblock 181 265 279 minecraft:snow_block
fill 181 265 280 181 268 280 minecraft:packed_ice
setblock 181 265 284 minecraft:snow_block
fill 181 265 285 181 268 285 minecraft:packed_ice
setblock 181 265 300 minecraft:packed_ice
setblock 181 265 304 minecraft:snow_block
fill 181 265 305 182 267 305 minecraft:packed_ice
setblock 182 265 278 minecraft:snow_block
fill 182 265 279 182 268 279 minecraft:packed_ice
setblock 182 265 283 minecraft:snow_block
fill 182 265 284 182 268 284 minecraft:packed_ice
setblock 182 265 288 minecraft:snow_block
fill 182 265 289 182 268 289 minecraft:packed_ice
setblock 182 265 298 minecraft:snow_block
fill 182 265 299 182 268 299 minecraft:packed_ice
setblock 182 265 303 minecraft:snow_block
fill 182 265 304 182 268 304 minecraft:packed_ice
fill 182 265 306 182 265 307 minecraft:packed_ice
setblock 182 265 308 minecraft:snow_block
fill 182 265 309 182 268 309 minecraft:packed_ice
setblock 182 265 313 minecraft:snow_block
fill 182 265 314 182 268 314 minecraft:packed_ice
setblock 183 265 278 minecraft:light_blue_concrete
fill 183 265 314 183 267 315 minecraft:snow_block
setblock 142 266 277 minecraft:snow_block
fill 142 266 278 142 269 278 minecraft:packed_ice
setblock 142 266 282 minecraft:snow_block
fill 142 266 283 142 269 283 minecraft:packed_ice
setblock 142 266 286 minecraft:packed_ice
setblock 142 266 287 minecraft:snow_block
setblock 142 266 297 minecraft:snow_block
fill 142 266 298 142 266 301 minecraft:packed_ice
setblock 142 266 302 minecraft:snow_block
fill 142 266 303 142 269 303 minecraft:packed_ice
setblock 142 266 307 minecraft:snow_block
fill 142 266 308 142 269 308 minecraft:packed_ice
setblock 142 266 312 minecraft:snow_block
fill 142 266 313 142 269 313 minecraft:packed_ice
setblock 143 266 276 minecraft:snow_block
fill 143 266 277 143 267 277 minecraft:packed_ice
setblock 143 266 281 minecraft:snow_block
fill 143 266 282 143 269 282 minecraft:packed_ice
fill 143 266 298 143 266 300 minecraft:packed_ice
setblock 143 266 301 minecraft:snow_block
fill 143 266 302 143 269 302 minecraft:packed_ice
setblock 143 266 306 minecraft:snow_block
fill 143 266 307 143 269 307 minecraft:packed_ice
setblock 143 266 311 minecraft:snow_block
fill 143 266 312 143 269 312 minecraft:packed_ice
setblock 143 266 316 minecraft:snow_block
fill 144 266 276 144 268 276 minecraft:packed_ice
setblock 144 266 300 minecraft:snow_block
fill 144 266 301 144 268 301 minecraft:packed_ice
setblock 144 266 304 minecraft:packed_ice
setblock 144 266 305 minecraft:snow_block
fill 144 266 306 144 269 306 minecraft:packed_ice
setblock 144 266 315 minecraft:snow_block
fill 144 266 316 147 266 316 minecraft:packed_ice
setblock 145 266 315 minecraft:packed_ice
fill 158 266 275 160 308 275 minecraft:snow_block
setblock 161 266 275 minecraft:white_concrete
setblock 162 266 277 minecraft:snow_block
setblock 163 266 276 minecraft:snow_block
fill 163 266 277 163 267 277 minecraft:packed_ice
fill 164 266 276 164 269 276 minecraft:packed_ice
setblock 167 266 277 minecraft:snow_block
setblock 168 266 276 minecraft:snow_block
setblock 168 266 277 minecraft:packed_ice
setblock 169 266 276 minecraft:packed_ice
setblock 173 266 276 minecraft:snow_block
setblock 174 266 276 minecraft:packed_ice
setblock 177 266 277 minecraft:snow_block
fill 177 266 285 177 272 285 minecraft:snow_block
setblock 178 266 276 minecraft:snow_block
fill 178 266 277 178 269 277 minecraft:packed_ice
fill 179 266 276 179 269 276 minecraft:packed_ice
fill 179 266 316 179 269 316 minecraft:packed_ice
setblock 180 266 279 minecraft:snow_block
fill 180 266 280 180 269 280 minecraft:packed_ice
setblock 180 266 284 minecraft:snow_block
setblock 181 266 278 minecraft:snow_block
fill 181 266 279 181 269 279 minecraft:packed_ice
setblock 181 266 283 minecraft:snow_block
fill 181 266 284 181 269 284 minecraft:packed_ice
setblock 181 266 302 minecraft:packed_ice
setblock 181 266 303 minecraft:snow_block
fill 181 266 304 181 273 304 minecraft:packed_ice
fill 181 266 306 182 266 306 minecraft:packed_ice
setblock 182 266 277 minecraft:snow_block
fill 182 266 278 182 269 278 minecraft:packed_ice
setblock 182 266 282 minecraft:snow_block
fill 182 266 283 182 269 283 minecraft:packed_ice
setblock 182 266 287 minecraft:snow_block
fill 182 266 288 182 269 288 minecraft:packed_ice
setblock 182 266 297 minecraft:snow_block
fill 182 266 298 182 267 298 minecraft:packed_ice
setblock 182 266 302 minecraft:snow_block
fill 182 266 303 182 269 303 minecraft:packed_ice
setblock 182 266 307 minecraft:snow_block
fill 182 266 308 182 269 308 minecraft:packed_ice
setblock 182 266 312 minecraft:snow_block
fill 182 266 313 182 269 313 minecraft:packed_ice
fill 183 266 278 183 275 278 minecraft:snow_block
fill 141 267 287 141 287 287 minecraft:snow_block
setblock 141 267 288 minecraft:light_blue_concrete
setblock 142 267 276 minecraft:snow_block
fill 142 267 277 142 270 277 minecraft:packed_ice
setblock 142 267 281 minecraft:snow_block
fill 142 267 282 142 270 282 minecraft:packed_ice
setblock 142 267 286 minecraft:snow_block
fill 142 267 287 142 270 287 minecraft:packed_ice
setblock 142 267 296 minecraft:snow_block
fill 142 267 297 142 267 300 minecraft:packed_ice
setblock 142 267 301 minecraft:snow_block
fill 142 267 302 142 270 302 minecraft:packed_ice
setblock 142 267 306 minecraft:snow_block
fill 142 267 307 142 270 307 minecraft:packed_ice
setblock 142 267 311 minecraft:snow_block
fill 142 267 312 142 270 312 minecraft:packed_ice
setblock 142 267 316 minecraft:snow_block
fill 143 267 276 143 269 276 minecraft:packed_ice
setblock 143 267 280 minecraft:snow_block
fill 143 267 281 143 269 281 minecraft:packed_ice
fill 143 267 298 143 267 299 minecraft:packed_ice
setblock 143 267 300 minecraft:snow_block
fill 143 267 301 143 270 301 minecraft:packed_ice
setblock 143 267 305 minecraft:snow_block
fill 143 267 306 143 270 306 minecraft:packed_ice
setblock 143 267 310 minecraft:snow_block
fill 143 267 311 143 270 311 minecraft:packed_ice
setblock 143 267 315 minecraft:snow_block
fill 143 267 316 146 267 316 minecraft:packed_ice
setblock 144 267 304 minecraft:snow_block
fill 144 267 305 144 270 305 minecraft:packed_ice
setblock 144 267 309 minecraft:snow_block
fill 147 267 279 147 268 279 minecraft:packed_ice
fill 148 267 278 148 268 278 minecraft:packed_ice
fill 148 267 280 148 268 280 minecraft:packed_ice
fill 149 267 279 149 268 279 minecraft:packed_ice
fill 161 267 275 161 293 275 minecraft:snow_block
setblock 162 267 276 minecraft:snow_block
fill 163 267 276 163 270 276 minecraft:packed_ice
setblock 167 267 276 minecraft:snow_block
setblock 168 267 276 minecraft:packed_ice
setblock 177 267 276 minecraft:snow_block
fill 177 267 277 177 270 277 minecraft:packed_ice
fill 178 267 276 178 270 276 minecraft:packed_ice
setblock 178 267 317 minecraft:white_concrete
setblock 180 267 278 minecraft:snow_block
fill 180 267 279 180 270 279 minecraft:packed_ice
setblock 180 267 283 minecraft:snow_block
fill 180 267 284 180 270 284 minecraft:packed_ice
fill 180 267 289 180 268 289 minecraft:packed_ice
setblock 181 267 277 minecraft:snow_block
fill 181 267 278 181 270 278 minecraft:packed_ice
setblock 181 267 282 minecraft:snow_block
fill 181 267 283 181 270 283 minecraft:packed_ice
fill 181 267 288 181 268 288 minecraft:packed_ice
fill 181 267 290 181 268 290 minecraft:packed_ice
setblock 181 267 302 minecraft:snow_block
fill 181 267 303 181 270 303 minecraft:packed_ice
setblock 181 267 306 minecraft:packed_ice
setblock 181 267 307 minecraft:snow_block
setblock 182 267 276 minecraft:snow_block
fill 182 267 277 182 270 277 minecraft:packed_ice
setblock 182 267 281 minecraft:snow_block
fill 182 267 282 182 270 282 minecraft:packed_ice
setblock 182 267 286 minecraft:snow_block
fill 182 267 287 182 270 287 minecraft:packed_ice
setblock 182 267 301 minecraft:snow_block
fill 182 267 302 182 270 302 minecraft:packed_ice
setblock 182 267 306 minecraft:snow_block
fill 182 267 307 182 270 307 minecraft:packed_ice
setblock 182 267 311 minecraft:snow_block
fill 182 267 312 182 270 312 minecraft:packed_ice
setblock 182 267 316 minecraft:snow_block
fill 141 268 288 141 308 288 minecraft:snow_block
fill 142 268 276 142 271 276 minecraft:packed_ice
setblock 142 268 280 minecraft:snow_block
fill 142 268 281 142 271 281 minecraft:packed_ice
setblock 142 268 285 minecraft:snow_block
fill 142 268 286 142 271 286 minecraft:packed_ice
fill 142 268 297 142 268 299 minecraft:packed_ice
setblock 142 268 300 minecraft:snow_block
fill 142 268 301 142 271 301 minecraft:packed_ice
setblock 142 268 305 minecraft:snow_block
fill 142 268 306 142 271 306 minecraft:packed_ice
setblock 142 268 310 minecraft:snow_block
fill 142 268 311 142 271 311 minecraft:packed_ice
setblock 142 268 315 minecraft:snow_block
fill 142 268 316 145 268 316 minecraft:packed_ice
setblock 143 268 279 minecraft:snow_block
setblock 143 268 280 minecraft:packed_ice
setblock 143 268 284 minecraft:snow_block
setblock 143 268 299 minecraft:snow_block
fill 143 268 300 143 271 300 minecraft:packed_ice
setblock 143 268 304 minecraft:snow_block
fill 143 268 305 143 271 305 minecraft:packed_ice
setblock 143 268 309 minecraft:snow_block
fill 143 268 310 143 271 310 minecraft:packed_ice
setblock 143 268 314 minecraft:snow_block
setblock 144 268 278 minecraft:light[level=15]
setblock 144 268 285 minecraft:light[level=12]
setblock 144 268 286 minecraft:light[level=15]
setblock 144 268 292 minecraft:light[level=12]
setblock 144 268 294 minecraft:light[level=15]
setblock 144 268 299 minecraft:light[level=12]
setblock 144 268 303 minecraft:snow_block
fill 144 268 304 144 271 304 minecraft:packed_ice
setblock 144 268 308 minecraft:snow_block
fill 144 268 309 144 271 309 minecraft:packed_ice
setblock 144 268 310 minecraft:light[level=15]
setblock 144 268 313 minecraft:light[level=12]
setblock 151 268 278 minecraft:light[level=12]
setblock 151 268 285 minecraft:light[level=12]
setblock 151 268 292 minecraft:light[level=12]
setblock 151 268 299 minecraft:light[level=12]
setblock 151 268 306 minecraft:light[level=12]
setblock 151 268 313 minecraft:light[level=12]
setblock 152 268 278 minecraft:light[level=15]
setblock 152 268 286 minecraft:light[level=15]
setblock 152 268 294 minecraft:light[level=15]
setblock 152 268 302 minecraft:light[level=15]
setblock 152 268 310 minecraft:light[level=15]
fill 156 268 314 156 274 314 minecraft:packed_ice
setblock 158 268 278 minecraft:light[level=12]
setblock 158 268 285 minecraft:light[level=12]
setblock 158 268 292 minecraft:light[level=12]
setblock 158 268 299 minecraft:light[level=12]
setblock 158 268 306 minecraft:light[level=12]
setblock 158 268 313 minecraft:light[level=12]
setblock 160 268 278 minecraft:light[level=15]
setblock 160 268 286 minecraft:light[level=15]
setblock 160 268 302 minecraft:light[level=15]
setblock 160 268 310 minecraft:light[level=15]
setblock 161 268 276 minecraft:snow_block
fill 162 268 276 162 271 276 minecraft:packed_ice
setblock 165 268 278 minecraft:light[level=12]
setblock 165 268 285 minecraft:light[level=12]
setblock 165 268 292 minecraft:light[level=12]
setblock 165 268 299 minecraft:light[level=12]
setblock 165 268 306 minecraft:light[level=12]
setblock 165 268 313 minecraft:light[level=12]
setblock 166 268 276 minecraft:snow_block
setblock 168 268 278 minecraft:light[level=15]
setblock 168 268 286 minecraft:light[level=15]
setblock 168 268 294 minecraft:light[level=15]
setblock 168 268 302 minecraft:light[level=15]
setblock 168 268 310 minecraft:light[level=15]
setblock 172 268 278 minecraft:light[level=12]
setblock 172 268 285 minecraft:light[level=12]
setblock 172 268 292 minecraft:light[level=12]
setblock 172 268 299 minecraft:light[level=12]
setblock 172 268 306 minecraft:light[level=12]
setblock 172 268 313 minecraft:light[level=12]
fill 174 268 308 180 268 308 minecraft:blue_ice
setblock 176 268 276 minecraft:snow_block
setblock 176 268 278 minecraft:light[level=15]
setblock 176 268 286 minecraft:light[level=15]
setblock 176 268 294 minecraft:light[level=15]
setblock 176 268 302 minecraft:light[level=15]
setblock 176 268 310 minecraft:light[level=15]
setblock 176 268 317 minecraft:white_concrete
fill 177 268 276 177 271 276 minecraft:packed_ice
fill 178 268 317 178 308 317 minecraft:snow_block
setblock 179 268 278 minecraft:snow_block
setblock 179 268 285 minecraft:light[level=12]
setblock 179 268 292 minecraft:light[level=12]
setblock 179 268 299 minecraft:light[level=12]
setblock 179 268 306 minecraft:light[level=12]
setblock 179 268 313 minecraft:light[level=12]
setblock 180 268 277 minecraft:snow_block
fill 180 268 278 180 269 278 minecraft:packed_ice
setblock 180 268 282 minecraft:snow_block
fill 180 268 283 180 271 283 minecraft:packed_ice
setblock 181 268 276 minecraft:snow_block
fill 181 268 277 181 271 277 minecraft:packed_ice
setblock 181 268 281 minecraft:snow_block
fill 181 268 282 181 271 282 minecraft:packed_ice
setblock 181 268 286 minecraft:snow_block
fill 181 268 287 181 271 287 minecraft:packed_ice
fill 181 268 302 181 271 302 minecraft:packed_ice
setblock 181 268 305 minecraft:packed_ice
setblock 181 268 306 minecraft:snow_block
fill 181 268 307 181 269 309 minecraft:packed_ice
setblock 181 268 316 minecraft:snow_block
fill 182 268 276 182 271 276 minecraft:packed_ice
setblock 182 268 280 minecraft:snow_block
fill 182 268 281 182 271 281 minecraft:packed_ice
setblock 182 268 285 minecraft:snow_block
fill 182 268 286 182 271 286 minecraft:packed_ice
setblock 182 268 300 minecraft:snow_block
fill 182 268 301 182 271 301 minecraft:packed_ice
setblock 182 268 305 minecraft:snow_block
fill 182 268 306 182 271 306 minecraft:packed_ice
setblock 182 268 310 minecraft:snow_block
fill 182 268 311 182 271 311 minecraft:packed_ice
setblock 182 268 315 minecraft:snow_block
fill 182 268 316 182 271 316 minecraft:packed_ice
setblock 183 268 297 minecraft:white_concrete
fill 183 268 314 183 308 314 minecraft:snow_block
setblock 183 268 315 minecraft:white_concrete
setblock 142 269 279 minecraft:snow_block
fill 142 269 280 142 272 280 minecraft:packed_ice
setblock 142 269 284 minecraft:snow_block
fill 142 269 285 142 272 285 minecraft:packed_ice
setblock 142 269 288 minecraft:packed_ice
fill 142 269 297 142 269 298 minecraft:packed_ice
setblock 142 269 299 minecraft:snow_block
fill 142 269 300 142 272 300 minecraft:packed_ice
setblock 142 269 304 minecraft:snow_block
fill 142 269 305 142 272 305 minecraft:packed_ice
setblock 142 269 309 minecraft:snow_block
fill 142 269 310 142 272 310 minecraft:packed_ice
setblock 142 269 314 minecraft:snow_block
fill 142 269 315 142 271 316 minecraft:packed_ice
setblock 143 269 283 minecraft:snow_block
setblock 143 269 303 minecraft:snow_block
fill 143 269 304 143 272 304 minecraft:packed_ice
setblock 143 269 308 minecraft:snow_block
fill 143 269 309 143 272 309 minecraft:packed_ice
setblock 143 269 313 minecraft:snow_block
fill 143 269 316 144 269 316 minecraft:packed_ice
setblock 144 269 302 minecraft:snow_block
fill 144 269 303 144 272 303 minecraft:packed_ice
setblock 144 269 307 minecraft:snow_block
fill 144 269 308 144 272 308 minecraft:packed_ice
fill 161 269 276 161 272 276 minecraft:packed_ice
setblock 165 269 276 minecraft:snow_block
setblock 175 269 276 minecraft:snow_block
fill 176 269 276 176 272 276 minecraft:packed_ice
fill 176 269 317 176 302 317 minecraft:snow_block
fill 177 269 308 180 269 308 minecraft:blue_ice
fill 178 269 307 180 269 307 minecraft:blue_ice
fill 178 269 309 180 269 309 minecraft:blue_ice
fill 178 269 316 178 270 316 minecraft:packed_ice
setblock 179 269 277 minecraft:snow_block
setblock 180 269 276 minecraft:snow_block
fill 180 269 277 180 272 277 minecraft:packed_ice
setblock 180 269 281 minecraft:snow_block
fill 180 269 282 180 272 282 minecraft:packed_ice
setblock 180 269 285 minecraft:packed_ice
setblock 180 269 316 minecraft:snow_block
fill 181 269 276 181 272 276 minecraft:packed_ice
setblock 181 269 280 minecraft:snow_block
fill 181 269 281 181 272 281 minecraft:packed_ice
setblock 181 269 285 minecraft:snow_block
fill 181 269 286 181 272 286 minecraft:packed_ice
setblock 181 269 305 minecraft:snow_block
fill 181 269 306 181 272 306 minecraft:packed_ice
setblock 181 269 310 minecraft:snow_block
fill 181 269 311 181 271 312 minecraft:packed_ice
fill 181 269 316 181 272 316 minecraft:packed_ice
setblock 182 269 279 minecraft:snow_block
fill 182 269 280 182 272 280 minecraft:packed_ice
setblock 182 269 284 minecraft:snow_block
fill 182 269 285 182 272 285 minecraft:packed_ice
setblock 182 269 289 minecraft:snow_block
setblock 182 269 299 minecraft:snow_block
fill 182 269 300 182 272 300 minecraft:packed_ice
setblock 182 269 304 minecraft:snow_block
fill 182 269 305 182 272 305 minecraft:packed_ice
setblock 182 269 309 minecraft:snow_block
fill 182 269 310 182 272 310 minecraft:packed_ice
setblock 182 269 314 minecraft:snow_block
fill 182 269 315 182 272 315 minecraft:packed_ice
setblock 183 269 296 minecraft:white_concrete
fill 183 269 297 183 308 297 minecraft:snow_block
fill 183 269 315 183 308 315 minecraft:snow_block
setblock 142 270 278 minecraft:snow_block
fill 142 270 279 142 272 279 minecraft:packed_ice
setblock 142 270 283 minecraft:snow_block
fill 142 270 284 142 272 284 minecraft:packed_ice
setblock 142 270 288 minecraft:snow_block
fill 142 270 289 142 272 289 minecraft:packed_ice
setblock 142 270 297 minecraft:packed_ice
setblock 142 270 298 minecraft:snow_block
fill 142 270 299 142 272 299 minecraft:packed_ice
setblock 142 270 303 minecraft:snow_block
fill 142 270 304 142 272 304 minecraft:packed_ice
setblock 142 270 308 minecraft:snow_block
fill 142 270 309 142 272 309 minecraft:packed_ice
setblock 142 270 313 minecraft:snow_block
fill 142 270 314 143 272 314 minecraft:packed_ice
setblock 143 270 283 minecraft:packed_ice
setblock 143 270 302 minecraft:snow_block
fill 143 270 303 143 272 303 minecraft:packed_ice
setblock 143 270 307 minecraft:snow_block
fill 143 270 308 143 272 308 minecraft:packed_ice
setblock 143 270 312 minecraft:snow_block
fill 143 270 313 143 272 313 minecraft:packed_ice
setblock 143 270 316 minecraft:packed_ice
setblock 144 270 302 minecraft:packed_ice
setblock 144 270 306 minecraft:snow_block
fill 144 270 307 144 272 307 minecraft:packed_ice
setblock 144 270 310 minecraft:packed_ice
setblock 144 270 316 minecraft:snow_block
setblock 164 270 276 minecraft:snow_block
fill 166 270 311 166 271 311 minecraft:packed_ice
fill 167 270 310 167 271 310 minecraft:packed_ice
fill 167 270 312 167 271 312 minecraft:packed_ice
fill 168 270 311 168 271 311 minecraft:packed_ice
fill 175 270 276 175 272 276 minecraft:packed_ice
fill 176 270 285 176 272 285 minecraft:snow_block
fill 177 270 284 177 272 284 minecraft:snow_block
fill 177 270 286 177 272 286 minecraft:snow_block
setblock 178 270 277 minecraft:snow_block
fill 178 270 285 178 272 285 minecraft:snow_block
fill 178 270 308 180 270 308 minecraft:blue_ice
fill 179 270 275 179 270 276 minecraft:snow_block
fill 179 270 277 179 272 277 minecraft:packed_ice
fill 179 270 307 180 270 307 minecraft:blue_ice
fill 179 270 309 180 270 309 minecraft:blue_ice
setblock 179 270 316 minecraft:snow_block
setblock 180 270 275 minecraft:white_concrete
fill 180 270 276 180 272 276 minecraft:packed_ice
setblock 180 270 280 minecraft:snow_block
fill 180 270 281 180 272 281 minecraft:packed_ice
setblock 180 270 285 minecraft:snow_block
fill 180 270 316 180 272 316 minecraft:packed_ice
fill 181 270 275 183 279 275 minecraft:snow_block
setblock 181 270 279 minecraft:snow_block
fill 181 270 280 181 272 280 minecraft:packed_ice
setblock 181 270 284 minecraft:snow_block
fill 181 270 285 181 272 285 minecraft:packed_ice
setblock 181 270 288 minecraft:packed_ice
fill 181 270 305 181 273 305 minecraft:packed_ice
fill 181 270 307 181 270 308 minecraft:packed_ice
setblock 181 270 309 minecraft:snow_block
fill 181 270 310 181 272 310 minecraft:packed_ice
setblock 181 270 313 minecraft:packed_ice
setblock 181 270 314 minecraft:snow_block
fill 181 270 315 181 272 315 minecraft:packed_ice
setblock 182 270 278 minecraft:snow_block
fill 182 270 279 182 272 279 minecraft:packed_ice
setblock 182 270 283 minecraft:snow_block
fill 182 270 284 182 272 284 minecraft:packed_ice
setblock 182 270 288 minecraft:snow_block
fill 182 270 289 182 272 290 minecraft:packed_ice
setblock 182 270 303 minecraft:snow_block
fill 182 270 304 182 273 304 minecraft:packed_ice
setblock 182 270 308 minecraft:snow_block
fill 182 270 309 182 272 309 minecraft:packed_ice
setblock 182 270 313 minecraft:snow_block
fill 182 270 314 182 272 314 minecraft:packed_ice
fill 183 270 296 183 308 296 minecraft:snow_block
setblock 183 270 308 minecraft:white_concrete
setblock 142 271 277 minecraft:snow_block
fill 142 271 278 142 272 278 minecraft:packed_ice
setblock 142 271 282 minecraft:snow_block
fill 142 271 283 142 272 283 minecraft:packed_ice
setblock 142 271 287 minecraft:snow_block
fill 142 271 288 142 272 288 minecraft:packed_ice
fill 142 271 290 142 271 291 minecraft:packed_ice
setblock 142 271 297 minecraft:snow_block
fill 142 271 298 142 272 298 minecraft:packed_ice
setblock 142 271 302 minecraft:snow_block
fill 142 271 303 142 272 303 minecraft:packed_ice
setblock 142 271 307 minecraft:snow_block
fill 142 271 308 142 272 308 minecraft:packed_ice
setblock 142 271 312 minecraft:snow_block
fill 142 271 313 142 272 313 minecraft:packed_ice
fill 143 271 284 143 272 284 minecraft:packed_ice
setblock 143 271 301 minecraft:snow_block
fill 143 271 302 143 272 302 minecraft:packed_ice
setblock 143 271 306 minecraft:snow_block
fill 143 271 307 143 272 307 minecraft:packed_ice
setblock 143 271 311 minecraft:snow_block
fill 143 271 312 143 272 312 minecraft:packed_ice
setblock 143 271 316 minecraft:snow_block
setblock 144 271 305 minecraft:snow_block
fill 144 271 306 144 272 306 minecraft:packed_ice
setblock 144 271 310 minecraft:snow_block
fill 144 271 316 144 272 316 minecraft:packed_ice
fill 160 271 276 160 272 276 minecraft:packed_ice
setblock 163 271 276 minecraft:snow_block
fill 174 271 276 174 272 276 minecraft:packed_ice
setblock 176 271 277 minecraft:packed_ice
setblock 177 271 277 minecraft:snow_block
setblock 177 271 316 minecraft:packed_ice
setblock 178 271 276 minecraft:snow_block
fill 178 271 277 178 272 277 minecraft:packed_ice
setblock 178 271 316 minecraft:snow_block
fill 179 271 275 180 308 275 minecraft:snow_block
fill 179 271 276 179 272 276 minecraft:packed_ice
setblock 179 271 315 minecraft:snow_block
fill 179 271 316 179 272 316 minecraft:packed_ice
setblock 180 271 279 minecraft:snow_block
fill 180 271 280 180 272 280 minecraft:packed_ice
setblock 180 271 284 minecraft:snow_block
fill 180 271 285 180 272 286 minecraft:packed_ice
fill 180 271 305 180 271 308 minecraft:packed_ice
setblock 180 271 309 minecraft:snow_block
fill 180 271 310 180 272 310 minecraft:packed_ice
fill 180 271 315 180 272 315 minecraft:packed_ice
setblock 181 271 278 minecraft:snow_block
fill 181 271 279 181 272 279 minecraft:packed_ice
setblock 181 271 283 minecraft:snow_block
fill 181 271 284 181 272 284 minecraft:packed_ice
setblock 181 271 288 minecraft:snow_block
setblock 181 271 303 minecraft:snow_block
setblock 181 271 307 minecraft:packed_ice
setblock 181 271 308 minecraft:snow_block
fill 181 271 309 181 272 309 minecraft:packed_ice
setblock 181 271 313 minecraft:snow_block
fill 181 271 314 181 272 314 minecraft:packed_ice
setblock 182 271 277 minecraft:snow_block
fill 182 271 278 182 272 278 minecraft:packed_ice
setblock 182 271 282 minecraft:snow_block
fill 182 271 283 182 272 283 minecraft:packed_ice
setblock 182 271 287 minecraft:snow_block
fill 182 271 288 182 272 288 minecraft:packed_ice
setblock 182 271 302 minecraft:snow_block
fill 182 271 303 182 272 303 minecraft:packed_ice
setblock 182 271 307 minecraft:snow_block
fill 182 271 308 182 272 308 minecraft:packed_ice
setblock 182 271 312 minecraft:snow_block
fill 182 271 313 182 272 313 minecraft:packed_ice
fill 183 271 308 183 308 308 minecraft:snow_block
setblock 142 272 277 minecraft:packed_ice
setblock 142 272 281 minecraft:snow_block
setblock 142 272 282 minecraft:packed_ice
setblock 142 272 286 minecraft:snow_block
fill 142 272 287 143 272 287 minecraft:packed_ice
setblock 142 272 290 minecraft:packed_ice
setblock 142 272 291 minecraft:snow_block
fill 142 272 292 142 272 293 minecraft:packed_ice
setblock 142 272 296 minecraft:snow_block
setblock 142 272 297 minecraft:packed_ice
setblock 142 272 301 minecraft:snow_block
setblock 142 272 302 minecraft:packed_ice
setblock 142 272 306 minecraft:snow_block
setblock 142 272 307 minecraft:packed_ice
setblock 142 272 311 minecraft:snow_block
setblock 142 272 312 minecraft:packed_ice
setblock 142 272 315 minecraft:packed_ice
setblock 142 272 316 minecraft:snow_block
setblock 143 272 285 minecraft:snow_block
setblock 143 272 286 minecraft:packed_ice
setblock 143 272 300 minecraft:snow_block
setblock 143 272 301 minecraft:packed_ice
setblock 143 272 305 minecraft:snow_block
setblock 143 272 306 minecraft:packed_ice
setblock 143 272 310 minecraft:snow_block
fill 143 272 311 144 272 311 minecraft:packed_ice
setblock 143 272 315 minecraft:snow_block
setblock 143 272 316 minecraft:packed_ice
setblock 144 272 304 minecraft:snow_block
setblock 144 272 305 minecraft:packed_ice
setblock 144 272 309 minecraft:snow_block
setblock 144 272 310 minecraft:packed_ice
fill 156 272 317 156 308 317 minecraft:snow_block
setblock 157 272 317 minecraft:light_blue_concrete
fill 158 272 317 159 282 317 minecraft:snow_block
setblock 159 272 276 minecraft:packed_ice
setblock 162 272 276 minecraft:snow_block
setblock 163 272 276 minecraft:packed_ice
setblock 173 272 276 minecraft:packed_ice
fill 175 272 316 176 272 316 minecraft:packed_ice
setblock 176 272 277 minecraft:snow_block
setblock 176 272 284 minecraft:snow_block
setblock 176 272 286 minecraft:snow_block
setblock 177 272 276 minecraft:snow_block
setblock 177 272 277 minecraft:packed_ice
setblock 177 272 315 minecraft:packed_ice
setblock 177 272 316 minecraft:snow_block
setblock 178 272 276 minecraft:packed_ice
setblock 178 272 284 minecraft:snow_block
setblock 178 272 286 minecraft:snow_block
setblock 178 272 315 minecraft:snow_block
setblock 178 272 316 minecraft:packed_ice
setblock 179 272 315 minecraft:packed_ice
setblock 180 272 279 minecraft:packed_ice
setblock 180 272 283 minecraft:snow_block
setblock 180 272 284 minecraft:packed_ice
setblock 180 272 287 minecraft:packed_ice
fill 180 272 304 180 272 307 minecraft:packed_ice
setblock 180 272 308 minecraft:snow_block
setblock 180 272 309 minecraft:packed_ice
fill 180 272 311 180 272 312 minecraft:packed_ice
setblock 180 272 313 minecraft:snow_block
setblock 181 272 277 minecraft:snow_block
setblock 181 272 278 minecraft:packed_ice
setblock 181 272 282 minecraft:snow_block
setblock 181 272 283 minecraft:packed_ice
setblock 181 272 287 minecraft:snow_block
fill 181 272 288 181 272 289 minecraft:packed_ice
setblock 181 272 302 minecraft:snow_block
fill 181 272 303 181 273 303 minecraft:packed_ice
setblock 181 272 307 minecraft:snow_block
setblock 181 272 308 minecraft:packed_ice
setblock 181 272 311 minecraft:packed_ice
setblock 181 272 312 minecraft:snow_block
setblock 181 272 313 minecraft:packed_ice
setblock 182 272 276 minecraft:snow_block
setblock 182 272 277 minecraft:packed_ice
setblock 182 272 281 minecraft:snow_block
setblock 182 272 282 minecraft:packed_ice
setblock 182 272 286 minecraft:snow_block
setblock 182 272 287 minecraft:packed_ice
setblock 182 272 291 minecraft:snow_block
setblock 182 272 301 minecraft:snow_block
setblock 182 272 302 minecraft:packed_ice
setblock 182 272 306 minecraft:snow_block
setblock 182 272 307 minecraft:packed_ice
setblock 182 272 311 minecraft:snow_block
setblock 182 272 312 minecraft:packed_ice
setblock 182 272 316 minecraft:snow_block
setblock 151 273 317 minecraft:light_blue_concrete
fill 155 273 314 155 274 314 minecraft:packed_ice
fill 156 273 313 156 274 313 minecraft:packed_ice
fill 156 273 315 156 274 315 minecraft:packed_ice
fill 157 273 314 157 274 314 minecraft:packed_ice
fill 157 273 317 157 308 317 minecraft:snow_block
setblock 180 273 304 minecraft:packed_ice
fill 183 273 309 183 308 310 minecraft:snow_block
setblock 183 273 311 minecraft:light_blue_concrete
setblock 144 274 278 minecraft:light[level=12]
setblock 144 274 285 minecraft:light[level=12]
setblock 144 274 292 minecraft:light[level=12]
setblock 144 274 299 minecraft:light[level=12]
setblock 144 274 306 minecraft:light[level=12]
setblock 144 274 313 minecraft:light[level=12]
setblock 151 274 278 minecraft:light[level=12]
setblock 151 274 285 minecraft:light[level=12]
setblock 151 274 292 minecraft:light[level=12]
setblock 151 274 299 minecraft:light[level=12]
setblock 151 274 306 minecraft:light[level=12]
setblock 151 274 313 minecraft:light[level=12]
fill 151 274 317 151 308 317 minecraft:snow_block
setblock 158 274 278 minecraft:light[level=12]
setblock 158 274 285 minecraft:light[level=12]
setblock 158 274 292 minecraft:light[level=12]
setblock 158 274 299 minecraft:light[level=12]
setblock 158 274 306 minecraft:light[level=12]
setblock 158 274 313 minecraft:light[level=12]
setblock 165 274 278 minecraft:light[level=12]
setblock 165 274 285 minecraft:light[level=12]
setblock 165 274 292 minecraft:light[level=12]
setblock 165 274 299 minecraft:light[level=12]
setblock 165 274 306 minecraft:light[level=12]
setblock 165 274 313 minecraft:light[level=12]
setblock 172 274 278 minecraft:light[level=12]
setblock 172 274 285 minecraft:light[level=12]
setblock 172 274 292 minecraft:light[level=12]
setblock 172 274 299 minecraft:light[level=12]
setblock 172 274 306 minecraft:light[level=12]
setblock 172 274 313 minecraft:light[level=12]
setblock 179 274 278 minecraft:light[level=12]
setblock 179 274 285 minecraft:light[level=12]
setblock 179 274 292 minecraft:light[level=12]
setblock 179 274 299 minecraft:light[level=12]
setblock 179 274 306 minecraft:light[level=12]
setblock 179 274 313 minecraft:light[level=12]
fill 183 274 311 183 308 311 minecraft:snow_block
fill 141 275 296 141 308 297 minecraft:snow_block
setblock 141 275 298 minecraft:light_blue_concrete
setblock 152 275 317 minecraft:white_concrete
setblock 183 275 281 minecraft:light_blue_concrete
setblock 183 275 300 minecraft:light_blue_concrete
fill 141 276 298 141 308 298 minecraft:snow_block
setblock 144 276 278 minecraft:light[level=15]
setblock 144 276 286 minecraft:light[level=15]
setblock 144 276 294 minecraft:light[level=15]
setblock 144 276 302 minecraft:light[level=15]
setblock 144 276 310 minecraft:light[level=15]
setblock 152 276 278 minecraft:light[level=15]
setblock 152 276 286 minecraft:light[level=15]
setblock 152 276 294 minecraft:light[level=15]
setblock 152 276 302 minecraft:light[level=15]
setblock 152 276 310 minecraft:light[level=15]
fill 152 276 317 152 308 317 minecraft:snow_block
setblock 160 276 278 minecraft:light[level=15]
setblock 160 276 286 minecraft:light[level=15]
setblock 160 276 302 minecraft:light[level=15]
setblock 160 276 310 minecraft:light[level=15]
setblock 168 276 278 minecraft:light[level=15]
setblock 168 276 286 minecraft:light[level=15]
setblock 168 276 294 minecraft:light[level=15]
setblock 168 276 302 minecraft:light[level=15]
setblock 168 276 310 minecraft:light[level=15]
setblock 173 276 275 minecraft:white_concrete
setblock 176 276 278 minecraft:light[level=15]
setblock 176 276 286 minecraft:light[level=15]
setblock 176 276 294 minecraft:light[level=15]
setblock 176 276 302 minecraft:light[level=15]
setblock 176 276 310 minecraft:light[level=15]
setblock 183 276 278 minecraft:white_concrete
fill 183 276 281 183 281 281 minecraft:snow_block
fill 183 276 300 183 308 300 minecraft:snow_block
setblock 141 277 286 minecraft:white_concrete
fill 173 277 275 173 293 275 minecraft:snow_block
setblock 175 277 317 minecraft:light_blue_concrete
fill 183 277 276 183 308 276 minecraft:snow_block
setblock 183 277 277 minecraft:light_blue_concrete
fill 183 277 278 183 308 278 minecraft:snow_block
setblock 183 277 294 minecraft:light_blue_concrete
fill 141 278 286 141 308 286 minecraft:snow_block
setblock 141 278 295 minecraft:light_blue_concrete
fill 147 278 286 147 279 287 minecraft:blue_ice
fill 147 278 301 147 279 302 minecraft:blue_ice
fill 148 278 287 149 279 287 minecraft:blue_ice
fill 148 278 301 149 279 301 minecraft:blue_ice
fill 149 278 288 151 279 288 minecraft:blue_ice
fill 149 278 291 149 279 297 minecraft:blue_ice
fill 149 278 300 151 279 300 minecraft:blue_ice
fill 150 278 289 150 279 290 minecraft:blue_ice
fill 150 278 298 150 279 299 minecraft:blue_ice
fill 151 278 287 152 279 287 minecraft:blue_ice
fill 151 278 289 152 279 289 minecraft:blue_ice
fill 151 278 299 152 279 299 minecraft:blue_ice
fill 151 278 301 152 279 301 minecraft:blue_ice
fill 152 278 286 153 279 286 minecraft:blue_ice
fill 152 278 302 153 279 302 minecraft:blue_ice
fill 153 278 285 154 279 285 minecraft:blue_ice
fill 153 278 290 153 279 290 minecraft:blue_ice
fill 153 278 298 153 279 298 minecraft:blue_ice
fill 153 278 303 154 279 303 minecraft:blue_ice
fill 154 278 292 154 279 296 minecraft:blue_ice
fill 155 278 284 156 279 284 minecraft:blue_ice
fill 155 278 290 155 279 291 minecraft:blue_ice
fill 155 278 297 155 279 298 minecraft:blue_ice
fill 155 278 304 156 279 304 minecraft:blue_ice
fill 156 278 289 156 279 290 minecraft:blue_ice
fill 156 278 298 156 279 299 minecraft:blue_ice
fill 157 278 283 163 279 283 minecraft:blue_ice
fill 157 278 289 157 279 289 minecraft:blue_ice
setblock 157 278 293 minecraft:snow_block
setblock 157 278 295 minecraft:snow_block
fill 157 278 299 157 279 299 minecraft:blue_ice
fill 157 278 305 163 279 305 minecraft:blue_ice
fill 158 278 288 162 279 288 minecraft:blue_ice
fill 158 278 300 162 279 300 minecraft:blue_ice
setblock 159 278 291 minecraft:snow_block
setblock 159 278 297 minecraft:snow_block
fill 160 278 279 160 279 282 minecraft:blue_ice
fill 160 278 284 160 279 287 minecraft:blue_ice
fill 160 278 289 160 278 290 minecraft:blue_ice
fill 160 278 298 160 278 299 minecraft:blue_ice
fill 160 278 301 160 279 304 minecraft:blue_ice
fill 160 278 306 160 279 309 minecraft:blue_ice
setblock 161 278 291 minecraft:snow_block
setblock 161 278 297 minecraft:snow_block
fill 163 278 289 164 279 289 minecraft:blue_ice
setblock 163 278 293 minecraft:snow_block
setblock 163 278 295 minecraft:snow_block
fill 163 278 299 164 279 299 minecraft:blue_ice
fill 164 278 284 165 279 284 minecraft:blue_ice
fill 164 278 290 165 279 290 minecraft:blue_ice
fill 164 278 298 165 279 298 minecraft:blue_ice
fill 164 278 304 165 279 304 minecraft:blue_ice
fill 165 278 291 165 279 291 minecraft:blue_ice
fill 165 278 297 165 279 297 minecraft:blue_ice
fill 166 278 285 167 279 285 minecraft:blue_ice
fill 166 278 292 166 279 296 minecraft:blue_ice
fill 166 278 303 167 279 303 minecraft:blue_ice
fill 167 278 286 168 279 286 minecraft:blue_ice
fill 167 278 290 167 279 290 minecraft:blue_ice
fill 167 278 298 167 279 298 minecraft:blue_ice
fill 167 278 302 168 279 302 minecraft:blue_ice
fill 168 278 287 169 279 287 minecraft:blue_ice
fill 168 278 289 170 279 289 minecraft:blue_ice
fill 168 278 299 170 279 299 minecraft:blue_ice
fill 168 278 301 169 279 301 minecraft:blue_ice
fill 169 278 288 171 279 288 minecraft:blue_ice
fill 169 278 300 171 279 300 minecraft:blue_ice
fill 170 278 290 170 279 290 minecraft:blue_ice
fill 170 278 298 170 279 298 minecraft:blue_ice
fill 171 278 287 173 279 287 minecraft:blue_ice
fill 171 278 291 171 279 297 minecraft:blue_ice
fill 171 278 301 173 279 301 minecraft:blue_ice
fill 173 278 286 173 279 286 minecraft:blue_ice
fill 173 278 302 173 279 302 minecraft:blue_ice
fill 175 278 317 175 308 317 minecraft:snow_block
fill 183 278 277 183 285 277 minecraft:snow_block
fill 183 278 294 183 308 294 minecraft:snow_block
fill 141 279 295 141 308 295 minecraft:snow_block
fill 142 279 276 182 279 277 minecraft:white_stained_glass
setblock 142 279 278 minecraft:light_blue_stained_glass
fill 142 279 279 142 279 283 minecraft:white_stained_glass
setblock 142 279 284 minecraft:light_blue_stained_glass
fill 142 279 285 142 279 289 minecraft:white_stained_glass
setblock 142 279 290 minecraft:light_blue_stained_glass
fill 142 279 291 142 279 295 minecraft:white_stained_glass
setblock 142 279 296 minecraft:light_blue_stained_glass
fill 142 279 297 142 279 301 minecraft:white_stained_glass
setblock 142 279 302 minecraft:light_blue_stained_glass
fill 142 279 303 142 279 307 minecraft:white_stained_glass
setblock 142 279 308 minecraft:light_blue_stained_glass
fill 142 279 309 142 279 313 minecraft:white_stained_glass
setblock 142 279 314 minecraft:light_blue_stained_glass
fill 142 279 315 182 279 316 minecraft:white_stained_glass
fill 143 279 278 143 279 280 minecraft:white_stained_glass
setblock 143 279 281 minecraft:light_blue_stained_glass
fill 143 279 282 143 279 286 minecraft:white_stained_glass
setblock 143 279 287 minecraft:light_blue_stained_glass
fill 143 279 288 143 279 292 minecraft:white_stained_glass
setblock 143 279 293 minecraft:light_blue_stained_glass
fill 143 279 294 143 279 298 minecraft:white_stained_glass
setblock 143 279 299 minecraft:light_blue_stained_glass
fill 143 279 300 143 279 304 minecraft:white_stained_glass
setblock 143 279 305 minecraft:light_blue_stained_glass
fill 143 279 306 143 279 310 minecraft:white_stained_glass
setblock 143 279 311 minecraft:light_blue_stained_glass
fill 143 279 312 143 279 314 minecraft:white_stained_glass
setblock 144 279 278 minecraft:light_blue_stained_glass
fill 144 279 279 144 279 283 minecraft:white_stained_glass
setblock 144 279 284 minecraft:light_blue_stained_glass
fill 144 279 285 144 279 289 minecraft:white_stained_glass
setblock 144 279 290 minecraft:light_blue_stained_glass
fill 144 279 291 144 279 295 minecraft:white_stained_glass
setblock 144 279 296 minecraft:light_blue_stained_glass
fill 144 279 297 144 279 301 minecraft:white_stained_glass
setblock 144 279 302 minecraft:light_blue_stained_glass
fill 144 279 303 144 279 307 minecraft:white_stained_glass
setblock 144 279 308 minecraft:light_blue_stained_glass
fill 144 279 309 144 279 313 minecraft:white_stained_glass
setblock 144 279 314 minecraft:light_blue_stained_glass
fill 145 279 278 145 279 280 minecraft:white_stained_glass
setblock 145 279 281 minecraft:light_blue_stained_glass
fill 145 279 282 145 279 286 minecraft:white_stained_glass
setblock 145 279 287 minecraft:light_blue_stained_glass
fill 145 279 288 145 279 292 minecraft:white_stained_glass
setblock 145 279 293 minecraft:light_blue_stained_glass
fill 145 279 294 145 279 298 minecraft:white_stained_glass
setblock 145 279 299 minecraft:light_blue_stained_glass
fill 145 279 300 145 279 304 minecraft:white_stained_glass
setblock 145 279 305 minecraft:light_blue_stained_glass
fill 145 279 306 145 279 310 minecraft:white_stained_glass
setblock 145 279 311 minecraft:light_blue_stained_glass
fill 145 279 312 145 279 314 minecraft:white_stained_glass
setblock 146 279 278 minecraft:light_blue_stained_glass
fill 146 279 279 146 279 283 minecraft:white_stained_glass
setblock 146 279 284 minecraft:light_blue_stained_glass
fill 146 279 285 146 279 289 minecraft:white_stained_glass
setblock 146 279 290 minecraft:light_blue_stained_glass
fill 146 279 291 146 279 295 minecraft:white_stained_glass
setblock 146 279 296 minecraft:light_blue_stained_glass
fill 146 279 297 146 279 301 minecraft:white_stained_glass
setblock 146 279 302 minecraft:light_blue_stained_glass
fill 146 279 303 146 279 307 minecraft:white_stained_glass
setblock 146 279 308 minecraft:light_blue_stained_glass
fill 146 279 309 146 279 313 minecraft:white_stained_glass
setblock 146 279 314 minecraft:light_blue_stained_glass
fill 147 279 278 147 279 280 minecraft:white_stained_glass
setblock 147 279 281 minecraft:light_blue_stained_glass
fill 147 279 282 147 279 285 minecraft:white_stained_glass
fill 147 279 288 147 279 292 minecraft:white_stained_glass
setblock 147 279 293 minecraft:light_blue_stained_glass
fill 147 279 294 147 279 298 minecraft:white_stained_glass
setblock 147 279 299 minecraft:light_blue_stained_glass
fill 147 279 300 148 279 300 minecraft:white_stained_glass
fill 147 279 303 152 279 304 minecraft:white_stained_glass
setblock 147 279 305 minecraft:light_blue_stained_glass
fill 147 279 306 147 279 310 minecraft:white_stained_glass
setblock 147 279 311 minecraft:light_blue_stained_glass
fill 147 279 312 147 279 314 minecraft:white_stained_glass
setblock 148 279 278 minecraft:light_blue_stained_glass
fill 148 279 279 148 279 283 minecraft:white_stained_glass
setblock 148 279 284 minecraft:light_blue_stained_glass
fill 148 279 285 151 279 286 minecraft:white_stained_glass
fill 148 279 288 148 279 289 minecraft:white_stained_glass
setblock 148 279 290 minecraft:light_blue_stained_glass
fill 148 279 291 148 279 295 minecraft:white_stained_glass
setblock 148 279 296 minecraft:light_blue_stained_glass
fill 148 279 297 148 279 299 minecraft:white_stained_glass
setblock 148 279 302 minecraft:light_blue_stained_glass
fill 148 279 305 148 279 307 minecraft:white_stained_glass
setblock 148 279 308 minecraft:light_blue_stained_glass
fill 148 279 309 148 279 313 minecraft:white_stained_glass
setblock 148 279 314 minecraft:light_blue_stained_glass
fill 149 279 278 149 279 280 minecraft:white_stained_glass
setblock 149 279 281 minecraft:light_blue_stained_glass
fill 149 279 282 149 279 284 minecraft:white_stained_glass
fill 149 279 289 149 279 290 minecraft:white_stained_glass
setblock 149 279 298 minecraft:white_stained_glass
setblock 149 279 299 minecraft:light_blue_stained_glass
setblock 149 279 302 minecraft:white_stained_glass
setblock 149 279 305 minecraft:light_blue_stained_glass
fill 149 279 306 149 279 310 minecraft:white_stained_glass
setblock 149 279 311 minecraft:light_blue_stained_glass
fill 149 279 312 149 279 314 minecraft:white_stained_glass
setblock 150 279 278 minecraft:light_blue_stained_glass
fill 150 279 279 150 279 283 minecraft:white_stained_glass
setblock 150 279 284 minecraft:light_blue_stained_glass
setblock 150 279 287 minecraft:white_stained_glass
fill 150 279 291 150 279 295 minecraft:white_stained_glass
setblock 150 279 296 minecraft:light_blue_stained_glass
fill 150 279 297 154 279 297 minecraft:white_stained_glass
setblock 150 279 301 minecraft:white_stained_glass
setblock 150 279 302 minecraft:light_blue_stained_glass
fill 150 279 305 150 279 307 minecraft:white_stained_glass
setblock 150 279 308 minecraft:light_blue_stained_glass
fill 150 279 309 150 279 313 minecraft:white_stained_glass
setblock 150 279 314 minecraft:light_blue_stained_glass
fill 151 279 278 151 279 280 minecraft:white_stained_glass
setblock 151 279 281 minecraft:light_blue_stained_glass
fill 151 279 282 151 279 284 minecraft:white_stained_glass
fill 151 279 290 151 279 292 minecraft:white_stained_glass
setblock 151 279 293 minecraft:light_blue_stained_glass
fill 151 279 294 151 279 296 minecraft:white_stained_glass
fill 151 279 298 152 279 298 minecraft:white_stained_glass
setblock 151 279 302 minecraft:white_stained_glass
setblock 151 279 305 minecraft:light_blue_stained_glass
fill 151 279 306 151 279 310 minecraft:white_stained_glass
setblock 151 279 311 minecraft:light_blue_stained_glass
fill 151 279 312 151 279 314 minecraft:white_stained_glass
setblock 152 279 278 minecraft:light_blue_stained_glass
fill 152 279 279 152 279 283 minecraft:white_stained_glass
setblock 152 279 284 minecraft:light_blue_stained_glass
setblock 152 279 285 minecraft:white_stained_glass
fill 152 279 288 157 279 288 minecraft:white_stained_glass
setblock 152 279 290 minecraft:light_blue_stained_glass
fill 152 279 291 152 279 295 minecraft:white_stained_glass
setblock 152 279 296 minecraft:light_blue_stained_glass
fill 152 279 300 157 279 300 minecraft:white_stained_glass
fill 152 279 305 152 279 307 minecraft:white_stained_glass
setblock 152 279 308 minecraft:light_blue_stained_glass
fill 152 279 309 152 279 313 minecraft:white_stained_glass
setblock 152 279 314 minecraft:light_blue_stained_glass
fill 153 279 278 153 279 280 minecraft:white_stained_glass
setblock 153 279 281 minecraft:light_blue_stained_glass
fill 153 279 282 153 279 284 minecraft:white_stained_glass
setblock 153 279 287 minecraft:light_blue_stained_glass
fill 153 279 289 155 279 289 minecraft:white_stained_glass
fill 153 279 291 153 279 292 minecraft:white_stained_glass
setblock 153 279 293 minecraft:light_blue_stained_glass
fill 153 279 294 153 279 296 minecraft:white_stained_glass
setblock 153 279 299 minecraft:light_blue_stained_glass
fill 153 279 301 159 279 301 minecraft:white_stained_glass
fill 153 279 304 154 279 304 minecraft:white_stained_glass
setblock 153 279 305 minecraft:light_blue_stained_glass
fill 153 279 306 153 279 310 minecraft:white_stained_glass
setblock 153 279 311 minecraft:light_blue_stained_glass
fill 153 279 312 153 279 314 minecraft:white_stained_glass
setblock 154 279 278 minecraft:light_blue_stained_glass
fill 154 279 279 154 279 283 minecraft:white_stained_glass
setblock 154 279 284 minecraft:light_blue_stained_glass
fill 154 279 286 154 279 287 minecraft:white_stained_glass
setblock 154 279 290 minecraft:light_blue_stained_glass
setblock 154 279 291 minecraft:white_stained_glass
fill 154 279 298 154 279 299 minecraft:white_stained_glass
setblock 154 279 302 minecraft:light_blue_stained_glass
fill 154 279 305 154 279 307 minecraft:white_stained_glass
setblock 154 279 308 minecraft:light_blue_stained_glass
fill 154 279 309 154 279 313 minecraft:white_stained_glass
setblock 154 279 314 minecraft:light_blue_stained_glass
fill 155 279 278 155 279 280 minecraft:white_stained_glass
setblock 155 279 281 minecraft:light_blue_stained_glass
fill 155 279 282 156 279 283 minecraft:white_stained_glass
fill 155 279 285 159 279 286 minecraft:white_stained_glass
setblock 155 279 287 minecraft:light_blue_stained_glass
fill 155 279 292 156 279 292 minecraft:white_stained_glass
setblock 155 279 293 minecraft:light_blue_stained_glass
fill 155 279 294 155 279 296 minecraft:white_stained_glass
setblock 155 279 299 minecraft:light_blue_stained_glass
fill 155 279 302 155 279 303 minecraft:white_stained_glass
setblock 155 279 305 minecraft:light_blue_stained_glass
fill 155 279 306 155 279 310 minecraft:white_stained_glass
setblock 155 279 311 minecraft:light_blue_stained_glass
fill 155 279 312 155 279 314 minecraft:white_stained_glass
setblock 156 279 278 minecraft:light_blue_stained_glass
fill 156 279 279 156 279 281 minecraft:white_stained_glass
setblock 156 279 287 minecraft:white_stained_glass
setblock 156 279 291 minecraft:white_stained_glass
fill 156 279 293 156 279 295 minecraft:sea_lantern
setblock 156 279 296 minecraft:light_blue_stained_glass
setblock 156 279 297 minecraft:white_stained_glass
setblock 156 279 302 minecraft:light_blue_stained_glass
fill 156 279 303 159 279 303 minecraft:white_stained_glass
fill 156 279 305 156 279 307 minecraft:white_stained_glass
setblock 156 279 308 minecraft:light_blue_stained_glass
fill 156 279 309 156 279 313 minecraft:white_stained_glass
setblock 156 279 314 minecraft:light_blue_stained_glass
fill 157 279 278 157 279 280 minecraft:white_stained_glass
setblock 157 279 281 minecraft:light_blue_stained_glass
fill 157 279 282 159 279 282 minecraft:white_stained_glass
setblock 157 279 284 minecraft:white_stained_glass
setblock 157 279 287 minecraft:light_blue_stained_glass
setblock 157 279 290 minecraft:white_stained_glass
setblock 157 279 291 minecraft:sea_lantern
fill 157 279 292 157 279 293 minecraft:shroomlight
fill 157 279 295 157 279 296 minecraft:shroomlight
setblock 157 279 297 minecraft:sea_lantern
fill 157 279 298 158 279 298 minecraft:white_stained_glass
setblock 157 279 302 minecraft:white_stained_glass
fill 157 279 304 159 279 304 minecraft:white_stained_glass
fill 157 279 306 157 279 310 minecraft:white_stained_glass
setblock 157 279 311 minecraft:light_blue_stained_glass
fill 157 279 312 157 279 314 minecraft:white_stained_glass
setblock 158 279 278 minecraft:light_blue_stained_glass
fill 158 279 279 158 279 281 minecraft:white_stained_glass
setblock 158 279 284 minecraft:light_blue_stained_glass
setblock 158 279 287 minecraft:white_stained_glass
fill 158 279 289 159 279 289 minecraft:white_stained_glass
setblock 158 279 290 minecraft:light_blue_stained_glass
fill 158 279 291 159 279 291 minecraft:shroomlight
fill 158 279 297 159 279 297 minecraft:shroomlight
setblock 158 279 299 minecraft:white_stained_glass
setblock 158 279 302 minecraft:light_blue_stained_glass
fill 158 279 306 159 279 307 minecraft:white_stained_glass
setblock 158 279 308 minecraft:light_blue_stained_glass
fill 158 279 309 158 279 313 minecraft:white_stained_glass
setblock 158 279 314 minecraft:light_blue_stained_glass
fill 159 279 278 159 279 280 minecraft:white_stained_glass
setblock 159 279 281 minecraft:light_blue_stained_glass
setblock 159 279 284 minecraft:white_stained_glass
setblock 159 279 287 minecraft:light_blue_stained_glass
fill 159 279 290 161 279 290 minecraft:sea_lantern
fill 159 279 298 161 279 298 minecraft:sea_lantern
setblock 159 279 299 minecraft:light_blue_stained_glass
setblock 159 279 302 minecraft:white_stained_glass
fill 159 279 308 159 279 310 minecraft:white_stained_glass
setblock 159 279 311 minecraft:light_blue_stained_glass
fill 159 279 312 159 279 314 minecraft:white_stained_glass
setblock 160 279 278 minecraft:light_blue_stained_glass
setblock 160 279 289 minecraft:blue_ice
setblock 160 279 299 minecraft:blue_ice
fill 160 279 310 160 279 313 minecraft:white_stained_glass
setblock 160 279 314 minecraft:light_blue_stained_glass
fill 161 279 278 161 279 280 minecraft:white_stained_glass
setblock 161 279 281 minecraft:light_blue_stained_glass
fill 161 279 282 182 279 282 minecraft:white_stained_glass
fill 161 279 284 161 279 286 minecraft:white_stained_glass
setblock 161 279 287 minecraft:light_blue_stained_glass
fill 161 279 289 162 279 289 minecraft:white_stained_glass
fill 161 279 291 162 279 291 minecraft:shroomlight
fill 161 279 297 162 279 297 minecraft:shroomlight
setblock 161 279 299 minecraft:light_blue_stained_glass
fill 161 279 301 161 279 304 minecraft:white_stained_glass
fill 161 279 306 161 279 310 minecraft:white_stained_glass
setblock 161 279 311 minecraft:light_blue_stained_glass
fill 161 279 312 161 279 314 minecraft:white_stained_glass
setblock 162 279 278 minecraft:light_blue_stained_glass
fill 162 279 279 162 279 281 minecraft:white_stained_glass
setblock 162 279 284 minecraft:light_blue_stained_glass
fill 162 279 285 162 279 287 minecraft:white_stained_glass
setblock 162 279 290 minecraft:light_blue_stained_glass
fill 162 279 298 162 279 299 minecraft:white_stained_glass
fill 162 279 301 167 279 301 minecraft:white_stained_glass
setblock 162 279 302 minecraft:light_blue_stained_glass
fill 162 279 303 163 279 304 minecraft:white_stained_glass
fill 162 279 306 182 279 307 minecraft:white_stained_glass
setblock 162 279 308 minecraft:light_blue_stained_glass
fill 162 279 309 162 279 313 minecraft:white_stained_glass
setblock 162 279 314 minecraft:light_blue_stained_glass
fill 163 279 278 163 279 280 minecraft:white_stained_glass
setblock 163 279 281 minecraft:light_blue_stained_glass
fill 163 279 284 163 279 286 minecraft:white_stained_glass
setblock 163 279 287 minecraft:light_blue_stained_glass
fill 163 279 288 168 279 288 minecraft:white_stained_glass
setblock 163 279 290 minecraft:white_stained_glass
setblock 163 279 291 minecraft:sea_lantern
fill 163 279 292 163 279 293 minecraft:shroomlight
fill 163 279 295 163 279 296 minecraft:shroomlight
setblock 163 279 297 minecraft:sea_lantern
setblock 163 279 298 minecraft:white_stained_glass
fill 163 279 300 168 279 300 minecraft:white_stained_glass
setblock 163 279 302 minecraft:white_stained_glass
fill 163 279 308 163 279 310 minecraft:white_stained_glass
setblock 163 279 311 minecraft:light_blue_stained_glass
fill 163 279 312 163 279 314 minecraft:white_stained_glass
setblock 164 279 278 minecraft:light_blue_stained_glass
fill 164 279 279 164 279 281 minecraft:white_stained_glass
fill 164 279 283 182 279 283 minecraft:white_stained_glass
fill 164 279 285 164 279 287 minecraft:white_stained_glass
fill 164 279 291 164 279 292 minecraft:white_stained_glass
fill 164 279 293 164 279 295 minecraft:sea_lantern
setblock 164 279 296 minecraft:light_blue_stained_glass
setblock 164 279 297 minecraft:white_stained_glass
setblock 164 279 302 minecraft:light_blue_stained_glass
fill 164 279 303 165 279 303 minecraft:white_stained_glass
setblock 164 279 305 minecraft:white_stained_glass
setblock 164 279 308 minecraft:light_blue_stained_glass
fill 164 279 309 164 279 313 minecraft:white_stained_glass
setblock 164 279 314 minecraft:light_blue_stained_glass
fill 165 279 278 165 279 280 minecraft:white_stained_glass
setblock 165 279 281 minecraft:light_blue_stained_glass
fill 165 279 285 165 279 286 minecraft:white_stained_glass
setblock 165 279 287 minecraft:light_blue_stained_glass
fill 165 279 289 167 279 289 minecraft:white_stained_glass
setblock 165 279 292 minecraft:white_stained_glass
setblock 165 279 293 minecraft:light_blue_stained_glass
fill 165 279 294 165 279 296 minecraft:white_stained_glass
setblock 165 279 299 minecraft:light_blue_stained_glass
setblock 165 279 302 minecraft:white_stained_glass
setblock 165 279 305 minecraft:light_blue_stained_glass
fill 165 279 308 165 279 310 minecraft:white_stained_glass
setblock 165 279 311 minecraft:light_blue_stained_glass
fill 165 279 312 165 279 314 minecraft:white_stained_glass
setblock 166 279 278 minecraft:light_blue_stained_glass
fill 166 279 279 166 279 281 minecraft:white_stained_glass
setblock 166 279 284 minecraft:light_blue_stained_glass
fill 166 279 286 166 279 287 minecraft:white_stained_glass
setblock 166 279 290 minecraft:light_blue_stained_glass
fill 166 279 291 170 279 291 minecraft:white_stained_glass
fill 166 279 297 166 279 299 minecraft:white_stained_glass
setblock 166 279 302 minecraft:light_blue_stained_glass
fill 166 279 304 166 279 305 minecraft:white_stained_glass
setblock 166 279 308 minecraft:light_blue_stained_glass
fill 166 279 309 166 279 313 minecraft:white_stained_glass
setblock 166 279 314 minecraft:light_blue_stained_glass
fill 167 279 278 167 279 280 minecraft:white_stained_glass
setblock 167 279 281 minecraft:light_blue_stained_glass
setblock 167 279 284 minecraft:white_stained_glass
setblock 167 279 287 minecraft:light_blue_stained_glass
fill 167 279 292 170 279 292 minecraft:white_stained_glass
setblock 167 279 293 minecraft:light_blue_stained_glass
fill 167 279 294 167 279 297 minecraft:white_stained_glass
setblock 167 279 299 minecraft:light_blue_stained_glass
fill 167 279 304 182 279 304 minecraft:white_stained_glass
setblock 167 279 305 minecraft:light_blue_stained_glass
fill 167 279 308 167 279 310 minecraft:white_stained_glass
setblock 167 279 311 minecraft:light_blue_stained_glass
fill 167 279 312 167 279 314 minecraft:white_stained_glass
setblock 168 279 278 minecraft:light_blue_stained_glass
fill 168 279 279 168 279 281 minecraft:white_stained_glass
setblock 168 279 284 minecraft:light_blue_stained_glass
fill 168 279 285 182 279 285 minecraft:white_stained_glass
setblock 168 279 290 minecraft:light_blue_stained_glass
fill 168 279 293 168 279 295 minecraft:white_stained_glass
setblock 168 279 296 minecraft:light_blue_stained_glass
fill 168 279 297 169 279 298 minecraft:white_stained_glass
fill 168 279 303 182 279 303 minecraft:white_stained_glass
setblock 168 279 305 minecraft:white_stained_glass
setblock 168 279 308 minecraft:light_blue_stained_glass
fill 168 279 309 168 279 313 minecraft:white_stained_glass
setblock 168 279 314 minecraft:light_blue_stained_glass
fill 169 279 278 169 279 280 minecraft:white_stained_glass
setblock 169 279 281 minecraft:light_blue_stained_glass
setblock 169 279 284 minecraft:white_stained_glass
fill 169 279 286 172 279 286 minecraft:white_stained_glass
setblock 169 279 290 minecraft:white_stained_glass
setblock 169 279 293 minecraft:light_blue_stained_glass
fill 169 279 294 169 279 296 minecraft:white_stained_glass
setblock 169 279 302 minecraft:white_stained_glass
setblock 169 279 305 minecraft:light_blue_stained_glass
fill 169 279 308 169 279 310 minecraft:white_stained_glass
setblock 169 279 311 minecraft:light_blue_stained_glass
fill 169 279 312 169 279 314 minecraft:white_stained_glass
setblock 170 279 278 minecraft:light_blue_stained_glass
fill 170 279 279 170 279 281 minecraft:white_stained_glass
setblock 170 279 284 minecraft:light_blue_stained_glass
setblock 170 279 287 minecraft:white_stained_glass
fill 170 279 293 170 279 295 minecraft:white_stained_glass
setblock 170 279 296 minecraft:light_blue_stained_glass
setblock 170 279 297 minecraft:white_stained_glass
setblock 170 279 301 minecraft:white_stained_glass
setblock 170 279 302 minecraft:light_blue_stained_glass
setblock 170 279 305 minecraft:white_stained_glass
setblock 170 279 308 minecraft:light_blue_stained_glass
fill 170 279 309 170 279 313 minecraft:white_stained_glass
setblock 170 279 314 minecraft:light_blue_stained_glass
fill 171 279 278 171 279 280 minecraft:white_stained_glass
setblock 171 279 281 minecraft:light_blue_stained_glass
setblock 171 279 284 minecraft:white_stained_glass
fill 171 279 289 171 279 290 minecraft:white_stained_glass
fill 171 279 298 182 279 298 minecraft:white_stained_glass
setblock 171 279 299 minecraft:light_blue_stained_glass
setblock 171 279 302 minecraft:white_stained_glass
setblock 171 279 305 minecraft:light_blue_stained_glass
fill 171 279 308 171 279 310 minecraft:white_stained_glass
setblock 171 279 311 minecraft:light_blue_stained_glass
fill 171 279 312 171 279 314 minecraft:white_stained_glass
setblock 172 279 278 minecraft:light_blue_stained_glass
fill 172 279 279 172 279 281 minecraft:white_stained_glass
setblock 172 279 284 minecraft:light_blue_stained_glass
fill 172 279 288 182 279 289 minecraft:white_stained_glass
setblock 172 279 290 minecraft:light_blue_stained_glass
fill 172 279 291 172 279 295 minecraft:white_stained_glass
setblock 172 279 296 minecraft:light_blue_stained_glass
fill 172 279 297 182 279 297 minecraft:white_stained_glass
fill 172 279 299 172 279 300 minecraft:white_stained_glass
setblock 172 279 302 minecraft:light_blue_stained_glass
setblock 172 279 305 minecraft:white_stained_glass
setblock 172 279 308 minecraft:light_blue_stained_glass
fill 172 279 309 172 279 313 minecraft:white_stained_glass
setblock 172 279 314 minecraft:light_blue_stained_glass
fill 173 279 278 173 279 280 minecraft:white_stained_glass
setblock 173 279 281 minecraft:light_blue_stained_glass
setblock 173 279 284 minecraft:white_stained_glass
fill 173 279 290 173 279 292 minecraft:white_stained_glass
setblock 173 279 293 minecraft:light_blue_stained_glass
fill 173 279 294 173 279 296 minecraft:white_stained_glass
setblock 173 279 299 minecraft:light_blue_stained_glass
fill 173 279 300 182 279 300 minecraft:white_stained_glass
setblock 173 279 305 minecraft:light_blue_stained_glass
fill 173 279 308 173 279 310 minecraft:white_stained_glass
setblock 173 279 311 minecraft:light_blue_stained_glass
fill 173 279 312 173 279 314 minecraft:white_stained_glass
setblock 174 279 278 minecraft:light_blue_stained_glass
fill 174 279 279 174 279 281 minecraft:white_stained_glass
setblock 174 279 284 minecraft:light_blue_stained_glass
fill 174 279 286 174 279 287 minecraft:white_stained_glass
setblock 174 279 290 minecraft:light_blue_stained_glass
fill 174 279 291 174 279 295 minecraft:white_stained_glass
setblock 174 279 296 minecraft:light_blue_stained_glass
setblock 174 279 299 minecraft:white_stained_glass
fill 174 279 301 182 279 301 minecraft:white_stained_glass
setblock 174 279 302 minecraft:light_blue_stained_glass
setblock 174 279 305 minecraft:white_stained_glass
setblock 174 279 308 minecraft:light_blue_stained_glass
fill 174 279 309 174 279 313 minecraft:white_stained_glass
setblock 174 279 314 minecraft:light_blue_stained_glass
fill 175 279 278 175 279 280 minecraft:white_stained_glass
setblock 175 279 281 minecraft:light_blue_stained_glass
setblock 175 279 284 minecraft:white_stained_glass
fill 175 279 286 182 279 286 minecraft:white_stained_glass
setblock 175 279 287 minecraft:light_blue_stained_glass
fill 175 279 290 175 279 292 minecraft:white_stained_glass
setblock 175 279 293 minecraft:light_blue_stained_glass
fill 175 279 294 175 279 296 minecraft:white_stained_glass
setblock 175 279 299 minecraft:light_blue_stained_glass
setblock 175 279 302 minecraft:white_stained_glass
setblock 175 279 305 minecraft:light_blue_stained_glass
fill 175 279 308 175 279 310 minecraft:white_stained_glass
setblock 175 279 311 minecraft:light_blue_stained_glass
fill 175 279 312 175 279 314 minecraft:white_stained_glass
setblock 176 279 278 minecraft:light_blue_stained_glass
fill 176 279 279 176 279 281 minecraft:white_stained_glass
setblock 176 279 284 minecraft:light_blue_stained_glass
setblock 176 279 287 minecraft:white_stained_glass
setblock 176 279 290 minecraft:light_blue_stained_glass
fill 176 279 291 176 279 295 minecraft:white_stained_glass
setblock 176 279 296 minecraft:light_blue_stained_glass
setblock 176 279 299 minecraft:white_stained_glass
setblock 176 279 302 minecraft:light_blue_stained_glass
setblock 176 279 305 minecraft:white_stained_glass
setblock 176 279 308 minecraft:light_blue_stained_glass
fill 176 279 309 176 279 313 minecraft:white_stained_glass
setblock 176 279 314 minecraft:light_blue_stained_glass
fill 177 279 278 177 279 280 minecraft:white_stained_glass
setblock 177 279 281 minecraft:light_blue_stained_glass
setblock 177 279 284 minecraft:white_stained_glass
setblock 177 279 287 minecraft:light_blue_stained_glass
fill 177 279 290 177 279 292 minecraft:white_stained_glass
setblock 177 279 293 minecraft:light_blue_stained_glass
fill 177 279 294 177 279 296 minecraft:white_stained_glass
setblock 177 279 299 minecraft:light_blue_stained_glass
setblock 177 279 302 minecraft:white_stained_glass
setblock 177 279 305 minecraft:light_blue_stained_glass
fill 177 279 308 177 279 310 minecraft:white_stained_glass
setblock 177 279 311 minecraft:light_blue_stained_glass
fill 177 279 312 177 279 314 minecraft:white_stained_glass
setblock 178 279 278 minecraft:light_blue_stained_glass
fill 178 279 279 178 279 281 minecraft:white_stained_glass
setblock 178 279 284 minecraft:light_blue_stained_glass
setblock 178 279 287 minecraft:white_stained_glass
setblock 178 279 290 minecraft:light_blue_stained_glass
fill 178 279 291 178 279 295 minecraft:white_stained_glass
setblock 178 279 296 minecraft:light_blue_stained_glass
setblock 178 279 299 minecraft:white_stained_glass
setblock 178 279 302 minecraft:light_blue_stained_glass
setblock 178 279 305 minecraft:white_stained_glass
setblock 178 279 308 minecraft:light_blue_stained_glass
fill 178 279 309 178 279 313 minecraft:white_stained_glass
setblock 178 279 314 minecraft:light_blue_stained_glass
fill 179 279 278 179 279 280 minecraft:white_stained_glass
setblock 179 279 281 minecraft:light_blue_stained_glass
setblock 179 279 284 minecraft:white_stained_glass
setblock 179 279 287 minecraft:light_blue_stained_glass
fill 179 279 290 179 279 292 minecraft:white_stained_glass
setblock 179 279 293 minecraft:light_blue_stained_glass
fill 179 279 294 179 279 296 minecraft:white_stained_glass
setblock 179 279 299 minecraft:light_blue_stained_glass
setblock 179 279 302 minecraft:white_stained_glass
setblock 179 279 305 minecraft:light_blue_stained_glass
fill 179 279 308 179 279 310 minecraft:white_stained_glass
setblock 179 279 311 minecraft:light_blue_stained_glass
fill 179 279 312 179 279 314 minecraft:white_stained_glass
setblock 180 279 278 minecraft:light_blue_stained_glass
fill 180 279 279 180 279 281 minecraft:white_stained_glass
setblock 180 279 284 minecraft:light_blue_stained_glass
setblock 180 279 287 minecraft:white_stained_glass
setblock 180 279 290 minecraft:light_blue_stained_glass
fill 180 279 291 180 279 295 minecraft:white_stained_glass
setblock 180 279 296 minecraft:light_blue_stained_glass
setblock 180 279 299 minecraft:white_stained_glass
setblock 180 279 302 minecraft:light_blue_stained_glass
setblock 180 279 305 minecraft:white_stained_glass
setblock 180 279 308 minecraft:light_blue_stained_glass
fill 180 279 309 180 279 313 minecraft:white_stained_glass
setblock 180 279 314 minecraft:light_blue_stained_glass
fill 181 279 278 181 279 280 minecraft:white_stained_glass
setblock 181 279 281 minecraft:light_blue_stained_glass
setblock 181 279 284 minecraft:white_stained_glass
setblock 181 279 287 minecraft:light_blue_stained_glass
fill 181 279 290 181 279 292 minecraft:white_stained_glass
setblock 181 279 293 minecraft:light_blue_stained_glass
fill 181 279 294 181 279 296 minecraft:white_stained_glass
setblock 181 279 299 minecraft:light_blue_stained_glass
setblock 181 279 302 minecraft:white_stained_glass
setblock 181 279 305 minecraft:light_blue_stained_glass
fill 181 279 308 181 279 310 minecraft:white_stained_glass
setblock 181 279 311 minecraft:light_blue_stained_glass
fill 181 279 312 181 279 314 minecraft:white_stained_glass
setblock 182 279 278 minecraft:light_blue_stained_glass
fill 182 279 279 182 279 281 minecraft:white_stained_glass
setblock 182 279 284 minecraft:light_blue_stained_glass
setblock 182 279 287 minecraft:white_stained_glass
setblock 182 279 290 minecraft:light_blue_stained_glass
fill 182 279 291 182 279 295 minecraft:white_stained_glass
setblock 182 279 296 minecraft:light_blue_stained_glass
setblock 182 279 299 minecraft:white_stained_glass
setblock 182 279 302 minecraft:light_blue_stained_glass
setblock 182 279 305 minecraft:white_stained_glass
setblock 182 279 308 minecraft:light_blue_stained_glass
fill 182 279 309 182 279 313 minecraft:white_stained_glass
setblock 182 279 314 minecraft:light_blue_stained_glass
fill 142 280 278 143 280 310 minecraft:basalt
fill 143 280 277 146 280 277 minecraft:basalt
setblock 143 280 311 minecraft:basalt
fill 144 280 276 149 280 276 minecraft:basalt
setblock 144 280 278 minecraft:magma_block
fill 144 280 279 146 282 280 minecraft:basalt
setblock 144 280 281 minecraft:magma_block
fill 144 280 282 146 285 283 minecraft:basalt
setblock 144 280 284 minecraft:magma_block
fill 144 280 285 146 287 286 minecraft:basalt
setblock 144 280 287 minecraft:magma_block
fill 144 280 288 145 288 289 minecraft:basalt
setblock 144 280 290 minecraft:magma_block
fill 144 280 291 144 289 292 minecraft:basalt
setblock 144 280 293 minecraft:magma_block
fill 144 280 294 144 289 295 minecraft:basalt
setblock 144 280 296 minecraft:magma_block
fill 144 280 297 144 289 298 minecraft:basalt
setblock 144 280 299 minecraft:magma_block
fill 144 280 300 145 288 301 minecraft:basalt
setblock 144 280 302 minecraft:magma_block
fill 144 280 303 146 286 304 minecraft:basalt
setblock 144 280 305 minecraft:magma_block
fill 144 280 306 146 284 307 minecraft:basalt
setblock 144 280 308 minecraft:magma_block
fill 144 280 309 146 282 310 minecraft:basalt
setblock 144 280 311 minecraft:magma_block
fill 144 280 312 149 280 312 minecraft:basalt
setblock 144 280 313 minecraft:light[level=12]
fill 145 280 278 152 283 278 minecraft:basalt
fill 145 280 281 151 285 281 minecraft:basalt
fill 145 280 284 147 287 284 minecraft:basalt
fill 145 280 287 145 289 287 minecraft:basalt
fill 145 280 299 145 290 299 minecraft:basalt
fill 145 280 302 146 288 302 minecraft:basalt
fill 145 280 305 148 286 305 minecraft:basalt
fill 145 280 308 152 284 308 minecraft:basalt
fill 145 280 311 152 281 311 minecraft:basalt
fill 145 280 313 146 280 313 minecraft:basalt
fill 146 280 314 152 280 314 minecraft:basalt
setblock 147 280 277 minecraft:magma_block
fill 147 280 279 149 285 279 minecraft:basalt
setblock 147 280 280 minecraft:magma_block
fill 147 280 282 149 287 282 minecraft:basalt
setblock 147 280 283 minecraft:magma_block
fill 147 280 285 147 290 285 minecraft:basalt
fill 147 280 303 147 290 303 minecraft:basalt
setblock 147 280 304 minecraft:magma_block
fill 147 280 306 149 287 306 minecraft:basalt
setblock 147 280 307 minecraft:magma_block
schedule function dropper:buildpart/63_10 1t
