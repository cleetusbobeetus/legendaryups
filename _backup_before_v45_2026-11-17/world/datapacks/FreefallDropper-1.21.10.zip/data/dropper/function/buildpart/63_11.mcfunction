setblock 142 295 282 minecraft:packed_ice
setblock 142 295 283 minecraft:snow_block
fill 142 295 284 142 295 287 minecraft:packed_ice
setblock 142 295 288 minecraft:snow_block
fill 142 295 289 142 295 292 minecraft:packed_ice
setblock 142 295 293 minecraft:snow_block
fill 142 295 294 142 298 294 minecraft:packed_ice
setblock 142 295 298 minecraft:snow_block
fill 142 295 299 142 298 299 minecraft:packed_ice
setblock 142 295 303 minecraft:snow_block
fill 142 295 304 142 298 304 minecraft:packed_ice
fill 143 295 278 143 298 278 minecraft:packed_ice
setblock 143 295 282 minecraft:snow_block
fill 143 295 283 143 298 283 minecraft:packed_ice
setblock 143 295 287 minecraft:snow_block
setblock 143 295 296 minecraft:packed_ice
setblock 143 295 297 minecraft:snow_block
fill 143 295 298 143 298 298 minecraft:packed_ice
setblock 143 295 302 minecraft:snow_block
fill 143 295 303 143 298 303 minecraft:packed_ice
setblock 144 295 276 minecraft:snow_block
fill 144 295 277 144 298 277 minecraft:packed_ice
setblock 144 295 281 minecraft:snow_block
fill 144 295 282 144 298 282 minecraft:packed_ice
fill 144 295 284 144 296 284 minecraft:packed_ice
setblock 144 295 297 minecraft:packed_ice
setblock 144 295 301 minecraft:snow_block
fill 144 295 302 144 297 302 minecraft:packed_ice
fill 145 295 276 148 295 276 minecraft:packed_ice
setblock 147 295 278 minecraft:snow_block
setblock 148 295 277 minecraft:snow_block
fill 148 295 278 148 297 278 minecraft:packed_ice
setblock 149 295 276 minecraft:snow_block
fill 149 295 277 152 295 277 minecraft:packed_ice
fill 150 295 276 153 295 276 minecraft:packed_ice
setblock 150 295 289 minecraft:magma_block
setblock 150 295 290 minecraft:basalt
setblock 150 295 292 minecraft:magma_block
fill 150 295 293 150 295 294 minecraft:basalt
setblock 150 295 295 minecraft:magma_block
setblock 150 295 298 minecraft:magma_block
setblock 150 295 299 minecraft:basalt
setblock 152 295 278 minecraft:snow_block
setblock 152 295 294 minecraft:basalt
setblock 153 295 277 minecraft:snow_block
setblock 153 295 285 minecraft:magma_block
setblock 153 295 288 minecraft:magma_block
fill 153 295 289 153 295 290 minecraft:basalt
fill 153 295 291 154 295 291 minecraft:magma_block
setblock 153 295 292 minecraft:basalt
fill 153 295 293 153 295 295 minecraft:magma_block
setblock 153 295 296 minecraft:basalt
fill 153 295 297 154 295 297 minecraft:magma_block
fill 153 295 298 154 295 298 minecraft:basalt
setblock 153 295 300 minecraft:magma_block
setblock 153 295 303 minecraft:magma_block
fill 153 295 310 153 296 310 minecraft:packed_ice
fill 153 295 312 153 296 312 minecraft:packed_ice
setblock 154 295 276 minecraft:snow_block
fill 154 295 277 157 295 277 minecraft:packed_ice
fill 154 295 292 154 295 293 minecraft:magma_block
fill 154 295 295 154 295 296 minecraft:magma_block
fill 155 295 276 158 295 276 minecraft:packed_ice
setblock 155 295 284 minecraft:basalt
fill 155 295 289 155 295 290 minecraft:magma_block
fill 155 295 298 155 295 299 minecraft:magma_block
fill 155 295 310 155 296 310 minecraft:packed_ice
fill 155 295 312 155 296 312 minecraft:packed_ice
setblock 156 295 284 minecraft:magma_block
setblock 156 295 287 minecraft:magma_block
setblock 156 295 289 minecraft:magma_block
setblock 156 295 299 minecraft:magma_block
setblock 156 295 302 minecraft:magma_block
fill 157 295 283 158 295 283 minecraft:basalt
setblock 157 295 287 minecraft:basalt
fill 157 295 288 159 295 288 minecraft:magma_block
fill 157 295 300 159 295 300 minecraft:magma_block
setblock 158 295 277 minecraft:snow_block
setblock 158 295 301 minecraft:basalt
setblock 158 295 305 minecraft:basalt
setblock 159 295 276 minecraft:snow_block
fill 159 295 277 162 295 277 minecraft:packed_ice
setblock 159 295 283 minecraft:magma_block
fill 159 295 286 159 295 287 minecraft:magma_block
fill 159 295 301 161 295 301 minecraft:magma_block
setblock 159 295 304 minecraft:magma_block
fill 160 295 276 163 295 276 minecraft:packed_ice
fill 160 295 286 162 295 286 minecraft:basalt
fill 160 295 304 165 295 304 minecraft:basalt
fill 161 295 275 161 308 275 minecraft:snow_block
fill 161 295 278 161 296 278 minecraft:packed_ice
setblock 161 295 285 minecraft:basalt
fill 161 295 287 161 295 288 minecraft:magma_block
fill 161 295 300 163 295 300 minecraft:magma_block
setblock 161 295 303 minecraft:basalt
fill 161 295 316 163 295 316 minecraft:packed_ice
setblock 162 295 278 minecraft:snow_block
setblock 162 295 285 minecraft:magma_block
setblock 162 295 287 minecraft:basalt
fill 162 295 288 163 295 288 minecraft:magma_block
fill 162 295 301 163 295 301 minecraft:basalt
setblock 162 295 303 minecraft:magma_block
setblock 163 295 277 minecraft:snow_block
fill 163 295 278 163 296 278 minecraft:packed_ice
setblock 163 295 283 minecraft:basalt
setblock 163 295 305 minecraft:basalt
setblock 164 295 276 minecraft:snow_block
fill 164 295 277 164 298 277 minecraft:packed_ice
setblock 164 295 284 minecraft:basalt
fill 164 295 289 165 295 289 minecraft:magma_block
fill 164 295 299 165 295 299 minecraft:magma_block
setblock 164 295 316 minecraft:snow_block
fill 165 295 276 165 298 276 minecraft:packed_ice
setblock 165 295 284 minecraft:magma_block
setblock 165 295 287 minecraft:magma_block
setblock 165 295 290 minecraft:magma_block
setblock 165 295 298 minecraft:magma_block
setblock 165 295 302 minecraft:magma_block
setblock 165 295 315 minecraft:snow_block
fill 165 295 316 168 295 316 minecraft:packed_ice
fill 166 295 291 166 295 293 minecraft:magma_block
fill 166 295 295 166 295 297 minecraft:magma_block
fill 166 295 315 169 295 315 minecraft:packed_ice
setblock 167 295 278 minecraft:snow_block
setblock 167 295 289 minecraft:basalt
setblock 167 295 292 minecraft:basalt
fill 167 295 293 167 295 295 minecraft:magma_block
fill 167 295 296 168 295 296 minecraft:basalt
fill 168 295 275 168 308 275 minecraft:snow_block
setblock 168 295 277 minecraft:snow_block
fill 168 295 278 168 296 278 minecraft:packed_ice
setblock 168 295 286 minecraft:magma_block
setblock 168 295 289 minecraft:magma_block
setblock 168 295 291 minecraft:basalt
setblock 168 295 292 minecraft:magma_block
fill 168 295 293 168 295 294 minecraft:basalt
setblock 168 295 295 minecraft:magma_block
setblock 168 295 298 minecraft:magma_block
setblock 168 295 299 minecraft:basalt
setblock 168 295 301 minecraft:magma_block
setblock 169 295 276 minecraft:snow_block
fill 169 295 277 169 297 277 minecraft:packed_ice
setblock 169 295 301 minecraft:basalt
setblock 169 295 316 minecraft:snow_block
fill 170 295 276 170 297 276 minecraft:packed_ice
setblock 170 295 315 minecraft:snow_block
fill 170 295 316 170 298 316 minecraft:packed_ice
setblock 171 295 291 minecraft:magma_block
setblock 171 295 294 minecraft:magma_block
fill 171 295 295 171 295 296 minecraft:basalt
setblock 171 295 297 minecraft:magma_block
setblock 171 295 315 minecraft:packed_ice
fill 173 295 275 173 308 275 minecraft:snow_block
setblock 174 295 316 minecraft:snow_block
setblock 175 295 275 minecraft:white_concrete
setblock 181 295 299 minecraft:snow_block
fill 181 295 300 181 298 300 minecraft:packed_ice
setblock 181 295 304 minecraft:snow_block
fill 181 295 305 181 298 305 minecraft:packed_ice
fill 182 295 279 182 298 279 minecraft:packed_ice
setblock 182 295 283 minecraft:snow_block
setblock 182 295 294 minecraft:packed_ice
setblock 182 295 298 minecraft:snow_block
fill 182 295 299 182 298 299 minecraft:packed_ice
setblock 182 295 303 minecraft:snow_block
fill 182 295 304 182 298 304 minecraft:packed_ice
setblock 182 295 308 minecraft:snow_block
fill 182 295 309 182 298 309 minecraft:packed_ice
fill 183 295 279 183 308 279 minecraft:snow_block
fill 141 296 277 142 296 277 minecraft:snow_block
fill 142 296 278 142 299 278 minecraft:packed_ice
setblock 142 296 282 minecraft:snow_block
fill 142 296 283 142 296 286 minecraft:packed_ice
setblock 142 296 287 minecraft:snow_block
fill 142 296 288 142 296 291 minecraft:packed_ice
setblock 142 296 292 minecraft:snow_block
fill 142 296 293 142 299 293 minecraft:packed_ice
setblock 142 296 297 minecraft:snow_block
fill 142 296 298 142 299 298 minecraft:packed_ice
setblock 142 296 302 minecraft:snow_block
fill 142 296 303 142 299 303 minecraft:packed_ice
setblock 142 296 306 minecraft:packed_ice
setblock 142 296 307 minecraft:snow_block
setblock 143 296 276 minecraft:snow_block
setblock 143 296 280 minecraft:packed_ice
setblock 143 296 281 minecraft:snow_block
fill 143 296 282 143 299 282 minecraft:packed_ice
fill 143 296 284 143 296 285 minecraft:packed_ice
setblock 143 296 286 minecraft:snow_block
fill 143 296 287 143 298 288 minecraft:packed_ice
setblock 143 296 296 minecraft:snow_block
fill 143 296 297 143 299 297 minecraft:packed_ice
setblock 143 296 301 minecraft:snow_block
fill 143 296 302 143 299 302 minecraft:packed_ice
fill 144 296 276 147 296 276 minecraft:packed_ice
setblock 144 296 280 minecraft:snow_block
fill 144 296 281 144 299 281 minecraft:packed_ice
setblock 144 296 285 minecraft:snow_block
setblock 144 296 300 minecraft:snow_block
setblock 144 296 301 minecraft:packed_ice
setblock 146 296 278 minecraft:snow_block
setblock 147 296 277 minecraft:snow_block
fill 147 296 278 147 297 278 minecraft:packed_ice
setblock 148 296 276 minecraft:snow_block
fill 148 296 277 151 296 277 minecraft:packed_ice
fill 149 296 276 152 296 276 minecraft:packed_ice
setblock 152 296 277 minecraft:snow_block
setblock 152 296 311 minecraft:packed_ice
setblock 153 296 276 minecraft:snow_block
setblock 153 296 277 minecraft:packed_ice
fill 154 296 276 157 296 276 minecraft:packed_ice
setblock 154 296 309 minecraft:packed_ice
setblock 154 296 313 minecraft:packed_ice
setblock 156 296 311 minecraft:packed_ice
setblock 158 296 276 minecraft:snow_block
fill 159 296 276 162 296 276 minecraft:packed_ice
fill 160 296 277 160 296 278 minecraft:packed_ice
setblock 161 296 277 minecraft:packed_ice
setblock 162 296 277 minecraft:snow_block
setblock 162 296 278 minecraft:packed_ice
setblock 162 296 316 minecraft:packed_ice
setblock 163 296 276 minecraft:snow_block
fill 163 296 277 163 299 277 minecraft:packed_ice
setblock 163 296 316 minecraft:snow_block
fill 164 296 276 164 299 276 minecraft:packed_ice
fill 164 296 316 167 296 316 minecraft:packed_ice
fill 165 296 315 168 296 315 minecraft:packed_ice
setblock 166 296 278 minecraft:snow_block
setblock 167 296 277 minecraft:snow_block
setblock 167 296 278 minecraft:packed_ice
setblock 168 296 276 minecraft:snow_block
fill 168 296 277 168 297 277 minecraft:packed_ice
setblock 168 296 316 minecraft:snow_block
fill 169 296 276 169 299 276 minecraft:packed_ice
setblock 169 296 315 minecraft:snow_block
fill 169 296 316 169 299 316 minecraft:packed_ice
fill 175 296 275 175 308 275 minecraft:snow_block
setblock 181 296 298 minecraft:snow_block
fill 181 296 299 181 299 299 minecraft:packed_ice
setblock 181 296 303 minecraft:snow_block
fill 181 296 304 181 299 304 minecraft:packed_ice
setblock 181 296 307 minecraft:packed_ice
setblock 182 296 275 minecraft:light_blue_concrete
setblock 182 296 282 minecraft:snow_block
fill 182 296 283 182 297 285 minecraft:packed_ice
setblock 182 296 297 minecraft:snow_block
fill 182 296 298 182 299 298 minecraft:packed_ice
setblock 182 296 302 minecraft:snow_block
fill 182 296 303 182 299 303 minecraft:packed_ice
setblock 182 296 307 minecraft:snow_block
fill 182 296 308 182 299 308 minecraft:packed_ice
fill 183 296 275 183 308 275 minecraft:snow_block
fill 141 297 277 141 300 277 minecraft:snow_block
fill 142 297 277 142 300 277 minecraft:packed_ice
setblock 142 297 281 minecraft:snow_block
fill 142 297 282 142 297 285 minecraft:packed_ice
setblock 142 297 286 minecraft:snow_block
fill 142 297 287 142 297 290 minecraft:packed_ice
setblock 142 297 291 minecraft:snow_block
fill 142 297 292 142 300 292 minecraft:packed_ice
setblock 142 297 296 minecraft:snow_block
fill 142 297 297 142 300 297 minecraft:packed_ice
setblock 142 297 301 minecraft:snow_block
fill 142 297 302 142 300 302 minecraft:packed_ice
setblock 142 297 306 minecraft:snow_block
fill 142 297 307 142 299 308 minecraft:packed_ice
fill 143 297 276 146 297 276 minecraft:packed_ice
setblock 143 297 280 minecraft:snow_block
fill 143 297 281 143 300 281 minecraft:packed_ice
setblock 143 297 284 minecraft:packed_ice
setblock 143 297 285 minecraft:snow_block
fill 143 297 286 144 299 286 minecraft:packed_ice
setblock 143 297 289 minecraft:packed_ice
setblock 143 297 296 minecraft:packed_ice
setblock 143 297 300 minecraft:snow_block
fill 143 297 301 143 300 301 minecraft:packed_ice
setblock 143 297 305 minecraft:snow_block
fill 143 297 306 143 300 306 minecraft:packed_ice
fill 144 297 280 144 300 280 minecraft:packed_ice
setblock 144 297 284 minecraft:snow_block
fill 144 297 285 144 300 285 minecraft:packed_ice
setblock 146 297 277 minecraft:snow_block
setblock 146 297 278 minecraft:packed_ice
setblock 147 297 276 minecraft:snow_block
fill 147 297 277 150 297 277 minecraft:packed_ice
fill 148 297 276 151 297 276 minecraft:packed_ice
setblock 151 297 277 minecraft:snow_block
setblock 152 297 276 minecraft:snow_block
fill 152 297 291 152 298 292 minecraft:snow_block
fill 153 297 276 154 297 276 minecraft:packed_ice
setblock 157 297 276 minecraft:snow_block
fill 158 297 276 161 297 276 minecraft:packed_ice
setblock 161 297 277 minecraft:snow_block
setblock 162 297 276 minecraft:snow_block
fill 162 297 277 162 300 277 minecraft:packed_ice
setblock 162 297 316 minecraft:snow_block
setblock 162 297 317 minecraft:light_blue_concrete
fill 163 297 276 163 300 276 minecraft:packed_ice
fill 163 297 316 166 297 316 minecraft:packed_ice
setblock 164 297 278 minecraft:packed_ice
setblock 165 297 278 minecraft:snow_block
fill 165 297 315 167 297 315 minecraft:packed_ice
setblock 166 297 277 minecraft:snow_block
setblock 166 297 278 minecraft:packed_ice
setblock 167 297 276 minecraft:snow_block
fill 167 297 277 167 298 277 minecraft:packed_ice
setblock 167 297 316 minecraft:snow_block
fill 168 297 276 168 300 276 minecraft:packed_ice
setblock 168 297 315 minecraft:snow_block
fill 168 297 316 168 300 316 minecraft:packed_ice
fill 170 297 307 171 298 308 minecraft:white_concrete
setblock 181 297 302 minecraft:snow_block
fill 181 297 303 181 300 303 minecraft:packed_ice
setblock 181 297 307 minecraft:snow_block
fill 182 297 275 182 308 275 minecraft:snow_block
setblock 182 297 281 minecraft:snow_block
fill 182 297 282 182 300 282 minecraft:packed_ice
setblock 182 297 286 minecraft:snow_block
fill 182 297 287 182 300 287 minecraft:packed_ice
setblock 182 297 296 minecraft:snow_block
fill 182 297 297 182 300 297 minecraft:packed_ice
setblock 182 297 301 minecraft:snow_block
fill 182 297 302 182 300 302 minecraft:packed_ice
setblock 182 297 306 minecraft:snow_block
fill 182 297 307 182 300 307 minecraft:packed_ice
setblock 182 297 310 minecraft:packed_ice
setblock 183 297 298 minecraft:light_blue_concrete
setblock 183 297 307 minecraft:light_blue_concrete
setblock 142 298 280 minecraft:snow_block
fill 142 298 281 142 298 284 minecraft:packed_ice
setblock 142 298 285 minecraft:snow_block
fill 142 298 286 142 298 289 minecraft:packed_ice
setblock 142 298 290 minecraft:snow_block
fill 142 298 291 143 300 291 minecraft:packed_ice
setblock 142 298 295 minecraft:snow_block
fill 142 298 296 142 300 296 minecraft:packed_ice
setblock 142 298 300 minecraft:snow_block
fill 142 298 301 142 300 301 minecraft:packed_ice
setblock 142 298 305 minecraft:snow_block
fill 142 298 306 142 300 306 minecraft:packed_ice
fill 143 298 276 145 298 276 minecraft:packed_ice
setblock 143 298 279 minecraft:snow_block
fill 143 298 280 143 300 280 minecraft:packed_ice
setblock 143 298 284 minecraft:snow_block
fill 143 298 285 143 300 285 minecraft:packed_ice
setblock 143 298 289 minecraft:snow_block
fill 143 298 290 143 300 290 minecraft:packed_ice
setblock 143 298 299 minecraft:snow_block
fill 143 298 300 143 300 300 minecraft:packed_ice
setblock 143 298 304 minecraft:snow_block
fill 143 298 305 143 300 305 minecraft:packed_ice
setblock 144 298 275 minecraft:light_blue_concrete
setblock 144 298 278 minecraft:light[level=12]
setblock 144 298 283 minecraft:snow_block
fill 144 298 284 145 300 284 minecraft:packed_ice
setblock 144 298 287 minecraft:packed_ice
setblock 144 298 288 minecraft:snow_block
setblock 144 298 292 minecraft:light[level=12]
setblock 144 298 299 minecraft:light[level=12]
setblock 144 298 306 minecraft:light[level=12]
setblock 144 298 313 minecraft:light[level=12]
setblock 145 298 277 minecraft:snow_block
fill 145 298 283 145 300 283 minecraft:packed_ice
setblock 146 298 276 minecraft:snow_block
fill 146 298 277 149 298 277 minecraft:packed_ice
fill 147 298 276 150 298 276 minecraft:packed_ice
setblock 150 298 277 minecraft:snow_block
setblock 151 298 276 minecraft:snow_block
setblock 151 298 278 minecraft:light[level=12]
setblock 151 298 285 minecraft:light[level=12]
setblock 151 298 292 minecraft:light[level=12]
setblock 151 298 299 minecraft:light[level=12]
setblock 151 298 306 minecraft:light[level=12]
setblock 151 298 313 minecraft:light[level=12]
setblock 152 298 276 minecraft:packed_ice
setblock 154 298 317 minecraft:white_concrete
fill 158 298 276 160 298 276 minecraft:packed_ice
setblock 158 298 278 minecraft:light[level=12]
setblock 158 298 285 minecraft:light[level=12]
setblock 158 298 292 minecraft:light[level=12]
setblock 158 298 299 minecraft:light[level=12]
setblock 158 298 306 minecraft:light[level=12]
setblock 158 298 313 minecraft:light[level=12]
setblock 161 298 276 minecraft:snow_block
fill 161 298 277 161 300 277 minecraft:packed_ice
setblock 161 298 316 minecraft:snow_block
fill 162 298 276 162 300 276 minecraft:packed_ice
fill 162 298 316 165 298 316 minecraft:packed_ice
fill 162 298 317 162 303 317 minecraft:snow_block
setblock 165 298 277 minecraft:snow_block
setblock 165 298 278 minecraft:light[level=12]
setblock 165 298 285 minecraft:light[level=12]
setblock 165 298 292 minecraft:light[level=12]
setblock 165 298 299 minecraft:light[level=12]
setblock 165 298 306 minecraft:light[level=12]
setblock 165 298 313 minecraft:light[level=12]
fill 165 298 315 166 298 315 minecraft:packed_ice
setblock 166 298 276 minecraft:snow_block
fill 166 298 277 166 300 277 minecraft:packed_ice
setblock 166 298 316 minecraft:snow_block
fill 167 298 276 167 300 276 minecraft:packed_ice
setblock 167 298 315 minecraft:snow_block
fill 167 298 316 167 300 316 minecraft:packed_ice
setblock 172 298 278 minecraft:light[level=12]
setblock 172 298 285 minecraft:light[level=12]
setblock 172 298 292 minecraft:light[level=12]
setblock 172 298 299 minecraft:light[level=12]
setblock 172 298 306 minecraft:light[level=12]
setblock 172 298 313 minecraft:light[level=12]
fill 173 298 297 173 299 304 minecraft:snow_block
fill 174 298 303 174 299 315 minecraft:snow_block
fill 175 298 311 175 299 316 minecraft:snow_block
setblock 179 298 278 minecraft:light[level=12]
setblock 179 298 285 minecraft:light[level=12]
setblock 179 298 292 minecraft:light[level=12]
setblock 179 298 299 minecraft:light[level=12]
setblock 179 298 306 minecraft:light[level=12]
setblock 179 298 313 minecraft:light[level=12]
setblock 181 298 301 minecraft:snow_block
fill 181 298 302 181 300 302 minecraft:packed_ice
setblock 181 298 306 minecraft:snow_block
fill 181 298 307 181 300 308 minecraft:packed_ice
setblock 182 298 280 minecraft:snow_block
fill 182 298 281 182 300 281 minecraft:packed_ice
fill 182 298 283 182 298 284 minecraft:packed_ice
setblock 182 298 285 minecraft:snow_block
fill 182 298 286 182 300 286 minecraft:packed_ice
fill 182 298 288 182 298 289 minecraft:packed_ice
setblock 182 298 290 minecraft:snow_block
fill 182 298 293 182 298 294 minecraft:packed_ice
setblock 182 298 295 minecraft:snow_block
fill 182 298 296 182 300 296 minecraft:packed_ice
setblock 182 298 300 minecraft:snow_block
fill 182 298 301 182 300 301 minecraft:packed_ice
setblock 182 298 305 minecraft:snow_block
fill 182 298 306 182 300 306 minecraft:packed_ice
setblock 182 298 310 minecraft:snow_block
fill 182 298 311 182 300 311 minecraft:packed_ice
setblock 183 298 277 minecraft:light_blue_concrete
fill 183 298 298 183 308 298 minecraft:snow_block
fill 183 298 307 183 308 307 minecraft:snow_block
setblock 142 299 279 minecraft:snow_block
fill 142 299 280 142 299 283 minecraft:packed_ice
setblock 142 299 284 minecraft:snow_block
fill 142 299 285 142 299 288 minecraft:packed_ice
setblock 142 299 289 minecraft:snow_block
fill 142 299 290 142 300 290 minecraft:packed_ice
setblock 142 299 294 minecraft:snow_block
fill 142 299 295 142 300 295 minecraft:packed_ice
setblock 142 299 299 minecraft:snow_block
fill 142 299 300 142 300 300 minecraft:packed_ice
setblock 142 299 304 minecraft:snow_block
fill 142 299 305 142 300 305 minecraft:packed_ice
setblock 142 299 309 minecraft:snow_block
fill 143 299 276 144 299 276 minecraft:packed_ice
setblock 143 299 278 minecraft:snow_block
fill 143 299 279 143 300 279 minecraft:packed_ice
setblock 143 299 283 minecraft:snow_block
fill 143 299 284 143 300 284 minecraft:packed_ice
setblock 143 299 287 minecraft:packed_ice
setblock 143 299 288 minecraft:snow_block
fill 143 299 289 144 300 289 minecraft:packed_ice
setblock 143 299 292 minecraft:packed_ice
setblock 143 299 298 minecraft:snow_block
fill 143 299 299 143 300 299 minecraft:packed_ice
setblock 143 299 303 minecraft:snow_block
fill 143 299 304 143 300 304 minecraft:packed_ice
setblock 143 299 307 minecraft:packed_ice
fill 144 299 275 144 308 275 minecraft:snow_block
setblock 144 299 277 minecraft:snow_block
setblock 144 299 282 minecraft:snow_block
fill 144 299 283 144 300 283 minecraft:packed_ice
setblock 144 299 287 minecraft:snow_block
fill 144 299 288 144 300 288 minecraft:packed_ice
setblock 145 299 276 minecraft:snow_block
fill 145 299 277 148 299 277 minecraft:packed_ice
fill 145 299 282 145 300 282 minecraft:packed_ice
setblock 145 299 285 minecraft:packed_ice
setblock 145 299 286 minecraft:snow_block
fill 146 299 276 149 299 276 minecraft:packed_ice
setblock 150 299 276 minecraft:snow_block
setblock 151 299 276 minecraft:packed_ice
fill 154 299 317 154 308 317 minecraft:snow_block
fill 158 299 276 159 299 276 minecraft:packed_ice
setblock 159 299 317 minecraft:white_concrete
setblock 160 299 276 minecraft:snow_block
fill 161 299 276 161 300 276 minecraft:packed_ice
fill 161 299 316 164 299 316 minecraft:packed_ice
setblock 164 299 277 minecraft:snow_block
fill 164 299 315 165 299 315 minecraft:packed_ice
fill 164 299 317 164 308 317 minecraft:snow_block
setblock 165 299 276 minecraft:snow_block
fill 165 299 277 165 300 277 minecraft:packed_ice
setblock 165 299 316 minecraft:snow_block
setblock 165 299 317 minecraft:light_blue_concrete
setblock 166 299 275 minecraft:light_blue_concrete
fill 166 299 276 166 300 276 minecraft:packed_ice
setblock 166 299 315 minecraft:snow_block
fill 166 299 316 166 300 316 minecraft:packed_ice
fill 167 299 275 167 308 275 minecraft:snow_block
fill 167 299 315 167 300 315 minecraft:packed_ice
fill 170 299 276 171 300 277 minecraft:snow_block
setblock 170 299 316 minecraft:snow_block
fill 171 299 278 171 299 288 minecraft:snow_block
fill 172 299 280 172 299 298 minecraft:snow_block
fill 173 299 289 173 299 296 minecraft:snow_block
fill 173 299 305 173 299 307 minecraft:snow_block
fill 174 299 299 174 299 302 minecraft:snow_block
fill 175 299 309 175 299 310 minecraft:snow_block
fill 180 299 303 180 299 305 minecraft:packed_ice
fill 181 299 298 181 300 298 minecraft:packed_ice
setblock 181 299 300 minecraft:snow_block
fill 181 299 301 181 300 301 minecraft:packed_ice
setblock 181 299 305 minecraft:snow_block
fill 181 299 306 181 300 306 minecraft:packed_ice
setblock 181 299 309 minecraft:packed_ice
setblock 182 299 279 minecraft:snow_block
fill 182 299 280 182 300 280 minecraft:packed_ice
setblock 182 299 283 minecraft:packed_ice
setblock 182 299 284 minecraft:snow_block
fill 182 299 285 182 300 285 minecraft:packed_ice
setblock 182 299 288 minecraft:packed_ice
setblock 182 299 289 minecraft:snow_block
fill 182 299 290 182 299 293 minecraft:packed_ice
setblock 182 299 294 minecraft:snow_block
fill 182 299 295 182 300 295 minecraft:packed_ice
setblock 182 299 299 minecraft:snow_block
fill 182 299 300 182 300 300 minecraft:packed_ice
setblock 182 299 304 minecraft:snow_block
fill 182 299 305 182 300 305 minecraft:packed_ice
setblock 182 299 309 minecraft:snow_block
fill 182 299 310 182 300 310 minecraft:packed_ice
fill 183 299 277 183 305 277 minecraft:snow_block
fill 142 300 276 143 300 276 minecraft:packed_ice
setblock 142 300 278 minecraft:snow_block
fill 142 300 279 142 300 282 minecraft:packed_ice
setblock 142 300 283 minecraft:snow_block
fill 142 300 284 142 300 287 minecraft:packed_ice
setblock 142 300 288 minecraft:snow_block
setblock 142 300 289 minecraft:packed_ice
setblock 142 300 293 minecraft:snow_block
fill 142 300 294 143 300 294 minecraft:packed_ice
setblock 142 300 298 minecraft:snow_block
setblock 142 300 299 minecraft:packed_ice
setblock 142 300 303 minecraft:snow_block
setblock 142 300 304 minecraft:packed_ice
setblock 142 300 307 minecraft:packed_ice
setblock 142 300 308 minecraft:snow_block
fill 142 300 309 142 300 311 minecraft:packed_ice
setblock 143 300 278 minecraft:packed_ice
setblock 143 300 282 minecraft:snow_block
setblock 143 300 283 minecraft:packed_ice
setblock 143 300 286 minecraft:packed_ice
setblock 143 300 287 minecraft:snow_block
setblock 143 300 288 minecraft:packed_ice
setblock 143 300 292 minecraft:snow_block
setblock 143 300 293 minecraft:packed_ice
setblock 143 300 297 minecraft:snow_block
setblock 143 300 298 minecraft:packed_ice
setblock 143 300 302 minecraft:snow_block
setblock 143 300 303 minecraft:packed_ice
setblock 143 300 307 minecraft:snow_block
setblock 143 300 308 minecraft:packed_ice
setblock 144 300 276 minecraft:snow_block
fill 144 300 277 147 300 277 minecraft:packed_ice
setblock 144 300 278 minecraft:light[level=15]
setblock 144 300 279 minecraft:packed_ice
setblock 144 300 281 minecraft:snow_block
setblock 144 300 282 minecraft:packed_ice
setblock 144 300 286 minecraft:snow_block
fill 144 300 287 145 300 287 minecraft:packed_ice
setblock 144 300 290 minecraft:packed_ice
setblock 144 300 294 minecraft:light[level=15]
setblock 144 300 302 minecraft:light[level=15]
setblock 144 300 310 minecraft:light[level=15]
fill 145 300 276 148 300 276 minecraft:packed_ice
setblock 145 300 285 minecraft:snow_block
setblock 145 300 286 minecraft:packed_ice
setblock 148 300 277 minecraft:snow_block
setblock 149 300 276 minecraft:snow_block
setblock 150 300 276 minecraft:packed_ice
setblock 152 300 278 minecraft:light[level=15]
setblock 152 300 286 minecraft:light[level=15]
setblock 152 300 294 minecraft:light[level=15]
setblock 152 300 302 minecraft:light[level=15]
setblock 152 300 310 minecraft:light[level=15]
setblock 158 300 276 minecraft:packed_ice
setblock 159 300 276 minecraft:snow_block
fill 159 300 317 159 308 317 minecraft:snow_block
setblock 160 300 276 minecraft:packed_ice
setblock 160 300 278 minecraft:light[level=15]
setblock 160 300 286 minecraft:light[level=15]
setblock 160 300 302 minecraft:light[level=15]
setblock 160 300 310 minecraft:light[level=15]
fill 160 300 316 163 300 316 minecraft:packed_ice
fill 162 300 315 164 300 315 minecraft:packed_ice
setblock 163 300 277 minecraft:snow_block
setblock 164 300 276 minecraft:snow_block
setblock 164 300 277 minecraft:packed_ice
setblock 164 300 316 minecraft:snow_block
setblock 165 300 276 minecraft:packed_ice
setblock 165 300 315 minecraft:snow_block
setblock 165 300 316 minecraft:packed_ice
fill 165 300 317 165 308 317 minecraft:snow_block
fill 166 300 275 166 308 275 minecraft:snow_block
setblock 166 300 315 minecraft:packed_ice
setblock 168 300 278 minecraft:light[level=15]
setblock 168 300 286 minecraft:light[level=15]
setblock 168 300 294 minecraft:light[level=15]
setblock 168 300 302 minecraft:light[level=15]
setblock 168 300 310 minecraft:light[level=15]
setblock 169 300 316 minecraft:snow_block
fill 171 300 278 171 300 285 minecraft:snow_block
fill 172 300 281 172 300 292 minecraft:snow_block
fill 173 300 295 173 300 303 minecraft:blue_ice
fill 174 300 303 174 300 313 minecraft:blue_ice
fill 175 300 313 175 300 315 minecraft:blue_ice
setblock 176 300 278 minecraft:light[level=15]
setblock 176 300 286 minecraft:light[level=15]
setblock 176 300 294 minecraft:light[level=15]
setblock 176 300 302 minecraft:light[level=15]
setblock 176 300 310 minecraft:light[level=15]
fill 180 300 302 180 300 304 minecraft:packed_ice
setblock 180 300 305 minecraft:snow_block
fill 180 300 306 180 300 307 minecraft:packed_ice
setblock 181 300 283 minecraft:packed_ice
setblock 181 300 284 minecraft:snow_block
fill 181 300 285 181 300 288 minecraft:packed_ice
setblock 181 300 299 minecraft:snow_block
setblock 181 300 300 minecraft:packed_ice
setblock 181 300 304 minecraft:snow_block
setblock 181 300 305 minecraft:packed_ice
setblock 181 300 309 minecraft:snow_block
setblock 181 300 310 minecraft:packed_ice
setblock 182 300 279 minecraft:packed_ice
setblock 182 300 283 minecraft:snow_block
setblock 182 300 284 minecraft:packed_ice
setblock 182 300 288 minecraft:snow_block
fill 182 300 289 182 300 292 minecraft:packed_ice
setblock 182 300 293 minecraft:snow_block
setblock 182 300 294 minecraft:packed_ice
setblock 182 300 298 minecraft:snow_block
setblock 182 300 299 minecraft:packed_ice
setblock 182 300 303 minecraft:snow_block
setblock 182 300 304 minecraft:packed_ice
setblock 182 300 308 minecraft:snow_block
setblock 182 300 309 minecraft:packed_ice
setblock 182 300 312 minecraft:packed_ice
setblock 141 301 277 minecraft:white_concrete
fill 146 301 317 148 308 317 minecraft:snow_block
setblock 149 301 317 minecraft:white_concrete
fill 150 301 317 150 308 317 minecraft:snow_block
fill 141 302 277 141 308 277 minecraft:snow_block
setblock 149 302 317 minecraft:snow_block
setblock 177 302 317 minecraft:light_blue_concrete
setblock 141 303 280 minecraft:white_concrete
fill 141 303 281 141 308 281 minecraft:snow_block
setblock 146 303 275 minecraft:light_blue_concrete
setblock 149 303 317 minecraft:white_concrete
setblock 161 303 317 minecraft:white_concrete
setblock 176 303 317 minecraft:white_concrete
fill 177 303 317 177 308 317 minecraft:snow_block
setblock 183 303 280 minecraft:white_concrete
fill 183 303 303 183 308 303 minecraft:snow_block
setblock 183 303 304 minecraft:white_concrete
fill 141 304 280 141 308 280 minecraft:snow_block
fill 146 304 275 146 308 275 minecraft:snow_block
fill 149 304 317 149 307 317 minecraft:snow_block
fill 161 304 317 161 308 317 minecraft:snow_block
setblock 162 304 317 minecraft:white_concrete
fill 176 304 317 176 308 317 minecraft:snow_block
fill 183 304 280 183 308 280 minecraft:snow_block
setblock 183 304 288 minecraft:white_concrete
fill 183 304 289 183 308 291 minecraft:snow_block
fill 183 304 304 183 308 304 minecraft:snow_block
fill 148 305 275 148 308 275 minecraft:snow_block
setblock 149 305 275 minecraft:light_blue_concrete
fill 162 305 317 162 308 317 minecraft:snow_block
fill 183 305 288 183 308 288 minecraft:snow_block
fill 149 306 275 149 308 275 minecraft:snow_block
setblock 183 306 277 minecraft:white_concrete
fill 183 307 277 183 308 277 minecraft:snow_block
setblock 145 308 317 minecraft:light_blue_concrete
setblock 149 308 317 minecraft:light_blue_concrete
fill 152 308 275 153 308 275 minecraft:white_concrete
setblock 155 308 317 minecraft:white_concrete
