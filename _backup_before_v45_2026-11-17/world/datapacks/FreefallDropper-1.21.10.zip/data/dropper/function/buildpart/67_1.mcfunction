setblock 353 126 292 minecraft:light[level=12]
setblock 353 126 299 minecraft:light[level=12]
setblock 353 126 306 minecraft:light[level=12]
setblock 353 126 313 minecraft:light[level=12]
fill 353 126 317 353 127 317 minecraft:white_wool
fill 354 126 275 354 133 275 minecraft:white_concrete
fill 354 126 317 356 129 317 minecraft:white_concrete
setblock 360 126 278 minecraft:light[level=12]
setblock 360 126 285 minecraft:light[level=12]
setblock 360 126 292 minecraft:light[level=12]
setblock 360 126 299 minecraft:light[level=12]
setblock 360 126 306 minecraft:light[level=12]
setblock 360 126 313 minecraft:light[level=12]
setblock 367 126 278 minecraft:light[level=12]
setblock 367 126 285 minecraft:light[level=12]
setblock 367 126 292 minecraft:light[level=12]
setblock 367 126 299 minecraft:light[level=12]
setblock 367 126 306 minecraft:light[level=12]
setblock 367 126 313 minecraft:light[level=12]
fill 371 126 291 371 133 291 minecraft:white_concrete
fill 336 127 275 336 131 275 minecraft:white_concrete
fill 336 127 299 338 129 299 minecraft:packed_mud
fill 337 127 300 339 129 301 minecraft:packed_mud
setblock 371 127 280 minecraft:white_wool
setblock 371 127 292 minecraft:white_wool
fill 330 128 275 331 130 275 minecraft:white_concrete
setblock 332 128 275 minecraft:white_wool
setblock 332 128 278 minecraft:light[level=15]
setblock 332 128 286 minecraft:light[level=15]
setblock 332 128 294 minecraft:light[level=15]
setblock 332 128 302 minecraft:light[level=15]
setblock 332 128 310 minecraft:light[level=15]
fill 333 128 275 335 130 275 minecraft:white_concrete
fill 336 128 300 336 129 301 minecraft:packed_mud
fill 337 128 298 338 129 298 minecraft:packed_mud
fill 339 128 299 339 130 299 minecraft:packed_mud
setblock 340 128 278 minecraft:light[level=15]
setblock 340 128 286 minecraft:light[level=15]
setblock 340 128 294 minecraft:light[level=15]
setblock 340 128 302 minecraft:light[level=15]
setblock 340 128 310 minecraft:light[level=15]
setblock 348 128 278 minecraft:light[level=15]
setblock 348 128 286 minecraft:light[level=15]
setblock 348 128 294 minecraft:light[level=15]
setblock 348 128 302 minecraft:light[level=15]
setblock 348 128 310 minecraft:light[level=15]
setblock 350 128 317 minecraft:white_wool
fill 353 128 317 353 129 317 minecraft:white_concrete
setblock 356 128 278 minecraft:light[level=15]
setblock 356 128 286 minecraft:light[level=15]
setblock 356 128 294 minecraft:light[level=15]
setblock 356 128 302 minecraft:light[level=15]
setblock 356 128 310 minecraft:light[level=15]
setblock 364 128 278 minecraft:light[level=15]
setblock 364 128 286 minecraft:light[level=15]
setblock 364 128 294 minecraft:light[level=15]
setblock 364 128 302 minecraft:light[level=15]
setblock 364 128 310 minecraft:light[level=15]
fill 371 128 280 371 133 280 minecraft:white_concrete
fill 371 128 292 371 133 292 minecraft:white_concrete
fill 332 129 275 332 133 275 minecraft:white_concrete
setblock 339 129 298 minecraft:packed_mud
fill 350 129 317 350 130 317 minecraft:white_concrete
fill 329 130 298 329 130 300 minecraft:white_concrete
setblock 329 130 301 minecraft:light_blue_terracotta
setblock 329 130 302 minecraft:white_concrete
setblock 329 130 303 minecraft:light_blue_terracotta
setblock 329 130 306 minecraft:light_blue_terracotta
fill 329 130 311 329 133 311 minecraft:white_concrete
setblock 329 130 312 minecraft:white_wool
setblock 334 130 317 minecraft:light_blue_terracotta
fill 336 130 299 336 131 299 minecraft:moss_block
fill 336 130 300 339 130 300 minecraft:packed_mud
fill 336 130 301 336 131 301 minecraft:moss_block
fill 337 130 275 337 131 275 minecraft:light_blue_terracotta
fill 337 130 298 339 131 298 minecraft:moss_block
fill 337 130 299 338 130 299 minecraft:packed_mud
setblock 337 130 301 minecraft:packed_mud
fill 338 130 275 338 133 275 minecraft:white_concrete
fill 338 130 301 339 131 301 minecraft:moss_block
fill 340 130 299 340 131 300 minecraft:moss_block
setblock 351 130 275 minecraft:light_blue_terracotta
setblock 351 130 317 minecraft:light_blue_terracotta
setblock 353 130 317 minecraft:light_blue_terracotta
fill 354 130 317 354 131 317 minecraft:white_concrete
setblock 355 130 317 minecraft:light_blue_terracotta
fill 356 130 317 356 133 317 minecraft:white_concrete
setblock 358 130 317 minecraft:light_blue_terracotta
fill 359 130 317 360 131 317 minecraft:white_concrete
fill 361 130 317 361 131 317 minecraft:light_blue_terracotta
setblock 366 130 275 minecraft:light_blue_terracotta
setblock 367 130 275 minecraft:white_concrete
setblock 367 130 317 minecraft:light_blue_terracotta
setblock 371 130 293 minecraft:light_blue_terracotta
setblock 329 131 283 minecraft:light_blue_terracotta
setblock 329 131 285 minecraft:light_blue_terracotta
setblock 329 131 295 minecraft:light_blue_terracotta
setblock 329 131 298 minecraft:light_blue_terracotta
fill 329 131 299 329 133 299 minecraft:white_concrete
setblock 329 131 300 minecraft:white_wool
fill 329 131 301 329 133 301 minecraft:white_concrete
setblock 329 131 302 minecraft:light_blue_terracotta
fill 329 131 303 329 133 303 minecraft:white_concrete
fill 329 131 306 329 133 306 minecraft:white_concrete
fill 329 131 312 329 133 312 minecraft:white_concrete
fill 330 131 275 330 133 275 minecraft:white_concrete
setblock 331 131 275 minecraft:light_blue_terracotta
fill 333 131 275 333 134 275 minecraft:white_concrete
setblock 334 131 275 minecraft:light_blue_terracotta
fill 334 131 317 334 133 317 minecraft:white_concrete
fill 335 131 275 335 133 275 minecraft:white_concrete
fill 336 131 300 339 131 300 minecraft:moss_block
fill 337 131 299 339 131 299 minecraft:moss_block
setblock 337 131 301 minecraft:moss_block
setblock 348 131 275 minecraft:white_wool
setblock 349 131 275 minecraft:white_concrete
setblock 350 131 275 minecraft:light_blue_terracotta
fill 350 131 317 350 132 317 minecraft:light_blue_terracotta
fill 351 131 275 351 133 275 minecraft:white_concrete
fill 351 131 317 351 133 317 minecraft:white_concrete
setblock 352 131 317 minecraft:light_blue_terracotta
fill 353 131 317 353 133 317 minecraft:white_concrete
setblock 355 131 317 minecraft:white_concrete
fill 358 131 317 358 133 317 minecraft:white_concrete
setblock 360 131 275 minecraft:white_wool
setblock 362 131 317 minecraft:light_blue_terracotta
setblock 365 131 275 minecraft:light_blue_terracotta
fill 366 131 275 366 133 275 minecraft:white_concrete
setblock 367 131 275 minecraft:light_blue_terracotta
fill 367 131 317 367 133 317 minecraft:white_concrete
setblock 368 131 317 minecraft:light_blue_terracotta
fill 370 131 275 370 133 275 minecraft:white_concrete
fill 371 131 275 371 131 276 minecraft:light_blue_terracotta
setblock 371 131 278 minecraft:light_blue_terracotta
fill 371 131 293 371 133 293 minecraft:white_concrete
setblock 371 131 294 minecraft:light_blue_terracotta
setblock 371 131 317 minecraft:light_blue_terracotta
fill 329 132 283 329 133 283 minecraft:white_concrete
fill 329 132 285 329 135 285 minecraft:white_concrete
fill 329 132 295 329 133 295 minecraft:white_concrete
setblock 329 132 297 minecraft:light_blue_terracotta
fill 329 132 298 329 133 298 minecraft:white_concrete
fill 329 132 300 329 134 300 minecraft:white_concrete
fill 329 132 302 329 133 302 minecraft:white_concrete
setblock 329 132 310 minecraft:light_blue_terracotta
setblock 329 132 313 minecraft:light_blue_terracotta
fill 331 132 275 331 133 275 minecraft:white_concrete
setblock 332 132 278 minecraft:light[level=12]
setblock 332 132 285 minecraft:light[level=12]
setblock 332 132 292 minecraft:light[level=12]
setblock 332 132 299 minecraft:light[level=12]
setblock 332 132 306 minecraft:light[level=12]
setblock 332 132 313 minecraft:light[level=12]
fill 334 132 275 334 133 275 minecraft:white_concrete
setblock 336 132 275 minecraft:light_blue_terracotta
fill 337 132 275 337 133 275 minecraft:white_concrete
fill 337 132 317 337 135 317 minecraft:white_concrete
setblock 338 132 317 minecraft:light_blue_terracotta
setblock 339 132 278 minecraft:light[level=12]
setblock 339 132 285 minecraft:light[level=12]
setblock 339 132 292 minecraft:light[level=12]
setblock 339 132 299 minecraft:light[level=12]
setblock 339 132 306 minecraft:light[level=12]
setblock 339 132 313 minecraft:light[level=12]
setblock 346 132 278 minecraft:light[level=12]
setblock 346 132 285 minecraft:light[level=12]
setblock 346 132 292 minecraft:light[level=12]
setblock 346 132 299 minecraft:light[level=12]
setblock 346 132 306 minecraft:light[level=12]
setblock 346 132 313 minecraft:light[level=12]
fill 348 132 275 348 133 275 minecraft:white_concrete
setblock 349 132 275 minecraft:light_blue_terracotta
fill 350 132 275 350 133 275 minecraft:white_concrete
fill 352 132 317 352 133 317 minecraft:white_concrete
setblock 353 132 278 minecraft:light[level=12]
setblock 353 132 285 minecraft:light[level=12]
setblock 353 132 292 minecraft:light[level=12]
setblock 353 132 299 minecraft:light[level=12]
setblock 353 132 306 minecraft:light[level=12]
setblock 353 132 313 minecraft:light[level=12]
fill 354 132 317 355 132 317 minecraft:light_blue_terracotta
fill 359 132 317 359 133 317 minecraft:white_concrete
setblock 360 132 275 minecraft:light_blue_terracotta
setblock 360 132 278 minecraft:light[level=12]
setblock 360 132 285 minecraft:light[level=12]
setblock 360 132 292 minecraft:light[level=12]
setblock 360 132 299 minecraft:light[level=12]
setblock 360 132 306 minecraft:light[level=12]
setblock 360 132 313 minecraft:light[level=12]
setblock 360 132 317 minecraft:white_wool
fill 361 132 317 362 133 317 minecraft:white_concrete
setblock 363 132 317 minecraft:light_blue_terracotta
fill 365 132 275 365 133 275 minecraft:white_concrete
fill 367 132 275 367 133 275 minecraft:white_concrete
setblock 367 132 278 minecraft:light[level=12]
setblock 367 132 285 minecraft:light[level=12]
setblock 367 132 292 minecraft:light[level=12]
setblock 367 132 299 minecraft:light[level=12]
setblock 367 132 306 minecraft:light[level=12]
setblock 367 132 313 minecraft:light[level=12]
fill 368 132 317 368 133 317 minecraft:white_concrete
setblock 371 132 275 minecraft:light_blue_terracotta
fill 371 132 276 371 133 276 minecraft:white_concrete
fill 371 132 278 371 133 278 minecraft:white_concrete
setblock 371 132 281 minecraft:light_blue_terracotta
fill 371 132 294 371 133 294 minecraft:white_concrete
setblock 371 132 300 minecraft:light_blue_terracotta
setblock 371 132 308 minecraft:light_blue_terracotta
setblock 371 132 311 minecraft:light_blue_terracotta
setblock 371 132 314 minecraft:light_blue_terracotta
fill 371 132 317 371 133 317 minecraft:white_concrete
setblock 329 133 297 minecraft:white_concrete
setblock 329 133 310 minecraft:white_concrete
setblock 329 133 313 minecraft:white_concrete
setblock 336 133 275 minecraft:white_concrete
setblock 338 133 317 minecraft:white_concrete
fill 341 133 293 342 135 295 minecraft:red_concrete
fill 341 133 296 342 135 297 minecraft:purple_concrete
fill 342 133 290 342 135 292 minecraft:red_concrete
fill 342 133 298 342 135 300 minecraft:purple_concrete
fill 343 133 289 344 135 289 minecraft:orange_concrete
fill 343 133 290 343 135 291 minecraft:red_concrete
fill 343 133 292 348 133 298 minecraft:white_stained_glass
fill 343 133 299 343 135 300 minecraft:purple_concrete
fill 343 133 301 344 135 301 minecraft:light_blue_concrete
fill 344 133 288 345 135 288 minecraft:orange_concrete
fill 344 133 290 360 133 291 minecraft:white_stained_glass
fill 344 133 299 360 133 300 minecraft:white_stained_glass
fill 344 133 302 345 135 302 minecraft:light_blue_concrete
fill 345 133 287 346 135 287 minecraft:orange_concrete
fill 345 133 289 359 134 289 minecraft:white_stained_glass
fill 345 133 301 359 134 301 minecraft:white_stained_glass
fill 345 133 303 346 135 303 minecraft:light_blue_concrete
fill 346 133 286 346 135 286 minecraft:orange_concrete
fill 346 133 288 358 134 288 minecraft:white_stained_glass
fill 346 133 302 358 134 302 minecraft:white_stained_glass
fill 346 133 304 346 135 304 minecraft:light_blue_concrete
fill 347 133 285 348 135 286 minecraft:yellow_concrete
fill 347 133 287 357 134 287 minecraft:white_stained_glass
fill 347 133 303 357 134 303 minecraft:white_stained_glass
fill 347 133 304 348 135 305 minecraft:lime_concrete
setblock 349 133 275 minecraft:white_concrete
fill 349 133 285 351 135 285 minecraft:yellow_concrete
fill 349 133 286 355 134 286 minecraft:white_stained_glass
fill 349 133 292 349 133 294 minecraft:white_stained_glass
fill 349 133 296 349 133 298 minecraft:white_stained_glass
fill 349 133 304 355 134 304 minecraft:white_stained_glass
fill 349 133 305 352 135 305 minecraft:lime_concrete
fill 350 133 284 351 135 284 minecraft:yellow_concrete
fill 350 133 292 351 133 292 minecraft:white_stained_glass
fill 350 133 298 351 133 298 minecraft:white_stained_glass
fill 350 133 306 352 135 306 minecraft:lime_concrete
setblock 350 133 317 minecraft:white_concrete
fill 352 133 284 354 135 285 minecraft:lime_concrete
fill 353 133 292 361 133 292 minecraft:white_stained_glass
fill 353 133 298 361 133 298 minecraft:white_stained_glass
fill 353 133 305 354 135 306 minecraft:yellow_concrete
fill 354 133 317 355 133 317 minecraft:white_concrete
fill 355 133 285 357 135 285 minecraft:lime_concrete
fill 355 133 293 361 133 294 minecraft:white_stained_glass
fill 355 133 296 361 133 297 minecraft:white_stained_glass
fill 355 133 305 357 135 305 minecraft:yellow_concrete
fill 356 133 286 357 135 286 minecraft:lime_concrete
fill 356 133 295 361 133 295 minecraft:white_stained_glass
fill 356 133 304 357 135 304 minecraft:yellow_concrete
fill 358 133 286 358 135 287 minecraft:light_blue_concrete
fill 358 133 303 358 135 304 minecraft:orange_concrete
fill 359 133 287 359 135 288 minecraft:light_blue_concrete
fill 359 133 302 359 135 303 minecraft:orange_concrete
setblock 360 133 275 minecraft:white_concrete
fill 360 133 288 360 135 289 minecraft:light_blue_concrete
fill 360 133 301 360 135 302 minecraft:orange_concrete
setblock 360 133 317 minecraft:white_concrete
fill 361 133 289 361 135 289 minecraft:light_blue_concrete
fill 361 133 290 362 135 291 minecraft:purple_concrete
fill 361 133 299 362 135 300 minecraft:red_concrete
fill 361 133 301 361 135 301 minecraft:orange_concrete
fill 362 133 292 362 135 294 minecraft:purple_concrete
fill 362 133 295 362 135 298 minecraft:red_concrete
fill 363 133 293 363 135 294 minecraft:purple_concrete
fill 363 133 295 363 135 297 minecraft:red_concrete
setblock 363 133 317 minecraft:white_concrete
fill 371 133 275 371 134 275 minecraft:white_concrete
setblock 371 133 281 minecraft:white_concrete
fill 371 133 300 371 134 300 minecraft:white_concrete
setblock 371 133 308 minecraft:white_concrete
fill 371 133 311 371 134 311 minecraft:white_concrete
setblock 371 133 314 minecraft:white_wool
fill 329 134 275 332 134 275 minecraft:light_blue_terracotta
setblock 329 134 276 minecraft:white_concrete
fill 329 134 277 329 134 284 minecraft:light_blue_terracotta
fill 329 134 286 329 135 291 minecraft:light_blue_terracotta
setblock 329 134 292 minecraft:white_concrete
fill 329 134 293 329 134 299 minecraft:light_blue_terracotta
fill 329 134 301 329 134 316 minecraft:light_blue_terracotta
fill 330 134 276 330 134 277 minecraft:white_wool
setblock 330 134 278 minecraft:light_gray_wool
fill 330 134 279 330 134 281 minecraft:white_wool
setblock 330 134 282 minecraft:light_gray_wool
fill 330 134 283 330 134 285 minecraft:white_wool
setblock 330 134 286 minecraft:light_gray_wool
fill 330 134 287 330 134 289 minecraft:white_wool
setblock 330 134 290 minecraft:light_gray_wool
fill 330 134 291 330 134 293 minecraft:white_wool
setblock 330 134 294 minecraft:light_gray_wool
fill 330 134 295 330 134 297 minecraft:white_wool
setblock 330 134 298 minecraft:light_gray_wool
fill 330 134 299 330 134 301 minecraft:white_wool
setblock 330 134 302 minecraft:light_gray_wool
fill 330 134 303 330 134 305 minecraft:white_wool
setblock 330 134 306 minecraft:light_gray_wool
fill 330 134 307 330 134 309 minecraft:white_wool
setblock 330 134 310 minecraft:light_gray_wool
fill 330 134 311 330 134 313 minecraft:white_wool
setblock 330 134 314 minecraft:light_gray_wool
fill 330 134 315 331 134 316 minecraft:white_wool
fill 330 134 317 334 134 317 minecraft:light_blue_terracotta
setblock 331 134 276 minecraft:white_wool
setblock 331 134 277 minecraft:light_gray_wool
fill 331 134 278 331 134 280 minecraft:white_wool
setblock 331 134 281 minecraft:light_gray_wool
fill 331 134 282 331 134 284 minecraft:white_wool
setblock 331 134 285 minecraft:light_gray_wool
fill 331 134 286 331 134 288 minecraft:white_wool
setblock 331 134 289 minecraft:light_gray_wool
fill 331 134 290 331 134 292 minecraft:white_wool
setblock 331 134 293 minecraft:light_gray_wool
fill 331 134 294 331 134 296 minecraft:white_wool
setblock 331 134 297 minecraft:light_gray_wool
fill 331 134 298 331 134 300 minecraft:white_wool
setblock 331 134 301 minecraft:light_gray_wool
fill 331 134 302 331 134 304 minecraft:white_wool
setblock 331 134 305 minecraft:light_gray_wool
fill 331 134 306 331 134 308 minecraft:white_wool
setblock 331 134 309 minecraft:light_gray_wool
fill 331 134 310 331 134 312 minecraft:white_wool
setblock 331 134 313 minecraft:light_gray_wool
fill 331 134 314 333 134 314 minecraft:white_wool
setblock 332 134 276 minecraft:light_gray_wool
fill 332 134 277 332 134 279 minecraft:white_wool
setblock 332 134 280 minecraft:light_gray_wool
fill 332 134 281 332 134 283 minecraft:white_wool
setblock 332 134 284 minecraft:light_gray_wool
fill 332 134 285 332 134 287 minecraft:white_wool
setblock 332 134 288 minecraft:light_gray_wool
fill 332 134 289 332 134 291 minecraft:white_wool
setblock 332 134 292 minecraft:light_gray_wool
fill 332 134 293 332 134 295 minecraft:white_wool
setblock 332 134 296 minecraft:light_gray_wool
fill 332 134 297 332 134 299 minecraft:white_wool
setblock 332 134 300 minecraft:light_gray_wool
fill 332 134 301 332 134 303 minecraft:white_wool
setblock 332 134 304 minecraft:light_gray_wool
fill 332 134 305 332 134 307 minecraft:white_wool
setblock 332 134 308 minecraft:light_gray_wool
fill 332 134 309 332 134 311 minecraft:white_wool
setblock 332 134 312 minecraft:light_gray_wool
fill 332 134 313 334 134 313 minecraft:white_wool
setblock 332 134 315 minecraft:white_wool
setblock 332 134 316 minecraft:light_gray_wool
fill 333 134 276 333 134 278 minecraft:white_wool
setblock 333 134 279 minecraft:light_gray_wool
fill 333 134 280 333 134 282 minecraft:white_wool
setblock 333 134 283 minecraft:light_gray_wool
fill 333 134 284 333 134 286 minecraft:white_wool
setblock 333 134 287 minecraft:light_gray_wool
fill 333 134 288 333 134 290 minecraft:white_wool
setblock 333 134 291 minecraft:light_gray_wool
fill 333 134 292 333 134 294 minecraft:white_wool
setblock 333 134 295 minecraft:light_gray_wool
fill 333 134 296 333 134 298 minecraft:white_wool
setblock 333 134 299 minecraft:light_gray_wool
fill 333 134 300 333 134 302 minecraft:white_wool
setblock 333 134 303 minecraft:light_gray_wool
fill 333 134 304 333 134 306 minecraft:white_wool
setblock 333 134 307 minecraft:light_gray_wool
fill 333 134 308 333 134 310 minecraft:white_wool
setblock 333 134 311 minecraft:light_gray_wool
fill 333 134 312 335 134 312 minecraft:white_wool
setblock 333 134 315 minecraft:light_gray_wool
fill 333 134 316 335 134 316 minecraft:white_wool
fill 334 134 275 342 134 275 minecraft:light_blue_terracotta
fill 334 134 276 334 134 277 minecraft:white_wool
setblock 334 134 278 minecraft:light_gray_wool
fill 334 134 279 334 134 281 minecraft:white_wool
setblock 334 134 282 minecraft:light_gray_wool
fill 334 134 283 334 134 285 minecraft:white_wool
setblock 334 134 286 minecraft:light_gray_wool
fill 334 134 287 334 134 289 minecraft:white_wool
setblock 334 134 290 minecraft:light_gray_wool
fill 334 134 291 334 134 293 minecraft:white_wool
setblock 334 134 294 minecraft:light_gray_wool
fill 334 134 295 334 134 297 minecraft:white_wool
setblock 334 134 298 minecraft:light_gray_wool
fill 334 134 299 334 134 301 minecraft:white_wool
setblock 334 134 302 minecraft:light_gray_wool
fill 334 134 303 334 134 305 minecraft:white_wool
setblock 334 134 306 minecraft:light_gray_wool
fill 334 134 307 334 134 309 minecraft:white_wool
setblock 334 134 310 minecraft:light_gray_wool
fill 334 134 311 336 134 311 minecraft:white_wool
setblock 334 134 314 minecraft:light_gray_wool
fill 334 134 315 336 134 315 minecraft:white_wool
setblock 335 134 276 minecraft:white_wool
setblock 335 134 277 minecraft:light_gray_wool
fill 335 134 278 335 134 280 minecraft:white_wool
setblock 335 134 281 minecraft:light_gray_wool
fill 335 134 282 335 134 284 minecraft:white_wool
setblock 335 134 285 minecraft:light_gray_wool
fill 335 134 286 335 134 288 minecraft:white_wool
setblock 335 134 289 minecraft:light_gray_wool
fill 335 134 290 335 134 292 minecraft:white_wool
setblock 335 134 293 minecraft:light_gray_wool
fill 335 134 294 335 134 296 minecraft:white_wool
setblock 335 134 297 minecraft:light_gray_wool
fill 335 134 298 335 134 300 minecraft:white_wool
setblock 335 134 301 minecraft:light_gray_wool
fill 335 134 302 335 134 304 minecraft:white_wool
setblock 335 134 305 minecraft:light_gray_wool
fill 335 134 306 335 134 308 minecraft:white_wool
setblock 335 134 309 minecraft:light_gray_wool
fill 335 134 310 337 134 310 minecraft:white_wool
setblock 335 134 313 minecraft:light_gray_wool
fill 335 134 314 337 134 314 minecraft:white_wool
setblock 336 134 276 minecraft:light_gray_wool
fill 336 134 277 336 134 279 minecraft:white_wool
setblock 336 134 280 minecraft:light_gray_wool
fill 336 134 281 336 134 283 minecraft:white_wool
setblock 336 134 284 minecraft:light_gray_wool
fill 336 134 285 336 134 287 minecraft:white_wool
setblock 336 134 288 minecraft:light_gray_wool
fill 336 134 289 336 134 291 minecraft:white_wool
setblock 336 134 292 minecraft:light_gray_wool
fill 336 134 293 336 134 295 minecraft:white_wool
setblock 336 134 296 minecraft:light_gray_wool
fill 336 134 297 336 134 299 minecraft:white_wool
setblock 336 134 300 minecraft:light_gray_wool
fill 336 134 301 336 134 303 minecraft:white_wool
setblock 336 134 304 minecraft:light_gray_wool
fill 336 134 305 336 134 307 minecraft:white_wool
setblock 336 134 308 minecraft:light_gray_wool
fill 336 134 309 338 134 309 minecraft:white_wool
setblock 336 134 312 minecraft:light_gray_wool
fill 336 134 313 338 134 313 minecraft:white_wool
setblock 336 134 316 minecraft:light_gray_wool
fill 336 134 317 336 217 317 minecraft:light_blue_terracotta
fill 337 134 276 337 134 278 minecraft:white_wool
setblock 337 134 279 minecraft:light_gray_wool
fill 337 134 280 337 134 282 minecraft:white_wool
setblock 337 134 283 minecraft:light_gray_wool
fill 337 134 284 337 134 286 minecraft:white_wool
setblock 337 134 287 minecraft:light_gray_wool
fill 337 134 288 337 134 290 minecraft:white_wool
setblock 337 134 291 minecraft:light_gray_wool
fill 337 134 292 337 134 294 minecraft:white_wool
setblock 337 134 295 minecraft:light_gray_wool
fill 337 134 296 337 134 298 minecraft:white_wool
setblock 337 134 299 minecraft:light_gray_wool
fill 337 134 300 337 134 302 minecraft:white_wool
setblock 337 134 303 minecraft:light_gray_wool
fill 337 134 304 337 134 306 minecraft:white_wool
setblock 337 134 307 minecraft:light_gray_wool
fill 337 134 308 339 134 308 minecraft:white_wool
setblock 337 134 311 minecraft:light_gray_wool
fill 337 134 312 339 134 312 minecraft:white_wool
setblock 337 134 315 minecraft:light_gray_wool
fill 337 134 316 339 134 316 minecraft:white_wool
fill 338 134 276 338 134 277 minecraft:white_wool
setblock 338 134 278 minecraft:light_gray_wool
fill 338 134 279 338 134 281 minecraft:white_wool
setblock 338 134 282 minecraft:light_gray_wool
fill 338 134 283 338 134 285 minecraft:white_wool
setblock 338 134 286 minecraft:light_gray_wool
fill 338 134 287 338 134 289 minecraft:white_wool
setblock 338 134 290 minecraft:light_gray_wool
fill 338 134 291 338 134 293 minecraft:white_wool
setblock 338 134 294 minecraft:light_gray_wool
fill 338 134 295 338 134 297 minecraft:white_wool
setblock 338 134 298 minecraft:light_gray_wool
fill 338 134 299 338 134 301 minecraft:white_wool
setblock 338 134 302 minecraft:light_gray_wool
fill 338 134 303 338 134 305 minecraft:white_wool
setblock 338 134 306 minecraft:light_gray_wool
fill 338 134 307 340 134 307 minecraft:white_wool
setblock 338 134 310 minecraft:light_gray_wool
fill 338 134 311 340 134 311 minecraft:white_wool
setblock 338 134 314 minecraft:light_gray_wool
fill 338 134 315 340 134 315 minecraft:white_wool
fill 338 134 317 343 134 317 minecraft:light_blue_terracotta
setblock 339 134 276 minecraft:white_wool
setblock 339 134 277 minecraft:light_gray_wool
fill 339 134 278 339 134 280 minecraft:white_wool
setblock 339 134 281 minecraft:light_gray_wool
fill 339 134 282 339 134 284 minecraft:white_wool
setblock 339 134 285 minecraft:light_gray_wool
fill 339 134 286 339 134 288 minecraft:white_wool
setblock 339 134 289 minecraft:light_gray_wool
fill 339 134 290 339 134 292 minecraft:white_wool
setblock 339 134 293 minecraft:light_gray_wool
fill 339 134 294 339 134 296 minecraft:white_wool
setblock 339 134 297 minecraft:light_gray_wool
fill 339 134 298 339 134 300 minecraft:white_wool
setblock 339 134 301 minecraft:light_gray_wool
fill 339 134 302 339 134 304 minecraft:white_wool
setblock 339 134 305 minecraft:light_gray_wool
fill 339 134 306 341 134 306 minecraft:white_wool
setblock 339 134 309 minecraft:light_gray_wool
fill 339 134 310 341 134 310 minecraft:white_wool
setblock 339 134 313 minecraft:light_gray_wool
fill 339 134 314 341 134 314 minecraft:white_wool
setblock 340 134 276 minecraft:light_gray_wool
fill 340 134 277 340 134 279 minecraft:white_wool
setblock 340 134 280 minecraft:light_gray_wool
fill 340 134 281 340 134 283 minecraft:white_wool
setblock 340 134 284 minecraft:light_gray_wool
fill 340 134 285 340 134 287 minecraft:white_wool
setblock 340 134 288 minecraft:light_gray_wool
fill 340 134 289 340 134 291 minecraft:white_wool
setblock 340 134 292 minecraft:light_gray_wool
fill 340 134 293 340 134 295 minecraft:white_wool
setblock 340 134 296 minecraft:light_gray_wool
fill 340 134 297 340 134 299 minecraft:white_wool
setblock 340 134 300 minecraft:light_gray_wool
fill 340 134 301 340 134 303 minecraft:white_wool
setblock 340 134 304 minecraft:light_gray_wool
fill 340 134 305 342 134 305 minecraft:white_wool
setblock 340 134 308 minecraft:light_gray_wool
fill 340 134 309 342 134 309 minecraft:white_wool
setblock 340 134 312 minecraft:light_gray_wool
fill 340 134 313 342 134 313 minecraft:white_wool
setblock 340 134 316 minecraft:light_gray_wool
fill 341 134 276 341 134 278 minecraft:white_wool
setblock 341 134 279 minecraft:light_gray_wool
fill 341 134 280 341 134 282 minecraft:white_wool
setblock 341 134 283 minecraft:light_gray_wool
fill 341 134 284 341 134 286 minecraft:white_wool
setblock 341 134 287 minecraft:light_gray_wool
fill 341 134 288 341 134 290 minecraft:white_wool
setblock 341 134 291 minecraft:light_gray_wool
setblock 341 134 292 minecraft:red_concrete
setblock 341 134 298 minecraft:purple_concrete
setblock 341 134 299 minecraft:light_gray_wool
fill 341 134 300 341 134 302 minecraft:white_wool
setblock 341 134 303 minecraft:light_gray_wool
fill 341 134 304 343 134 304 minecraft:white_wool
setblock 341 134 307 minecraft:light_gray_wool
fill 341 134 308 343 134 308 minecraft:white_wool
setblock 341 134 311 minecraft:light_gray_wool
fill 341 134 312 343 134 312 minecraft:white_wool
setblock 341 134 315 minecraft:light_gray_wool
fill 341 134 316 343 134 316 minecraft:white_wool
fill 342 134 276 342 134 277 minecraft:white_wool
setblock 342 134 278 minecraft:light_gray_wool
fill 342 134 279 342 134 281 minecraft:white_wool
setblock 342 134 282 minecraft:light_gray_wool
fill 342 134 283 342 134 285 minecraft:white_wool
setblock 342 134 286 minecraft:light_gray_wool
fill 342 134 287 342 134 289 minecraft:white_wool
setblock 342 134 301 minecraft:white_wool
setblock 342 134 302 minecraft:light_gray_wool
fill 342 134 303 343 134 303 minecraft:white_wool
setblock 342 134 306 minecraft:light_gray_wool
fill 342 134 307 344 134 307 minecraft:white_wool
setblock 342 134 310 minecraft:light_gray_wool
fill 342 134 311 344 134 311 minecraft:white_wool
setblock 342 134 314 minecraft:light_gray_wool
fill 342 134 315 344 134 315 minecraft:white_wool
setblock 343 134 276 minecraft:white_wool
setblock 343 134 277 minecraft:light_gray_wool
fill 343 134 278 343 134 280 minecraft:white_wool
setblock 343 134 281 minecraft:light_gray_wool
fill 343 134 282 343 134 284 minecraft:white_wool
setblock 343 134 285 minecraft:light_gray_wool
fill 343 134 286 343 134 287 minecraft:white_wool
setblock 343 134 288 minecraft:orange_concrete
fill 343 134 292 347 134 298 minecraft:white_stained_glass
setblock 343 134 302 minecraft:light_blue_concrete
setblock 343 134 305 minecraft:light_gray_wool
fill 343 134 306 345 134 306 minecraft:white_wool
setblock 343 134 309 minecraft:light_gray_wool
fill 343 134 310 345 134 310 minecraft:white_wool
setblock 343 134 313 minecraft:light_gray_wool
fill 343 134 314 345 134 314 minecraft:white_wool
fill 344 134 275 363 134 275 minecraft:light_blue_terracotta
setblock 344 134 276 minecraft:light_gray_wool
fill 344 134 277 344 134 279 minecraft:white_wool
setblock 344 134 280 minecraft:light_gray_wool
fill 344 134 281 344 134 283 minecraft:white_wool
setblock 344 134 284 minecraft:light_gray_wool
fill 344 134 285 344 134 286 minecraft:white_wool
setblock 344 134 287 minecraft:orange_concrete
fill 344 134 290 350 134 291 minecraft:white_stained_glass
fill 344 134 299 350 134 300 minecraft:white_stained_glass
setblock 344 134 303 minecraft:light_blue_concrete
setblock 344 134 304 minecraft:light_gray_wool
fill 344 134 305 346 134 305 minecraft:white_wool
setblock 344 134 308 minecraft:light_gray_wool
fill 344 134 309 346 134 309 minecraft:white_wool
setblock 344 134 312 minecraft:light_gray_wool
fill 344 134 313 346 134 313 minecraft:white_wool
setblock 344 134 316 minecraft:light_gray_wool
setblock 344 134 317 minecraft:white_concrete
fill 345 134 276 345 134 278 minecraft:white_wool
setblock 345 134 279 minecraft:light_gray_wool
fill 345 134 280 345 134 282 minecraft:white_wool
setblock 345 134 283 minecraft:light_gray_wool
fill 345 134 284 346 134 285 minecraft:white_wool
setblock 345 134 286 minecraft:orange_concrete
setblock 345 134 304 minecraft:light_blue_concrete
setblock 345 134 307 minecraft:light_gray_wool
fill 345 134 308 347 134 308 minecraft:white_wool
setblock 345 134 311 minecraft:light_gray_wool
fill 345 134 312 347 134 312 minecraft:white_wool
setblock 345 134 315 minecraft:light_gray_wool
fill 345 134 316 347 134 316 minecraft:white_wool
fill 345 134 317 346 183 317 minecraft:light_blue_terracotta
fill 346 134 276 346 134 277 minecraft:white_wool
setblock 346 134 278 minecraft:light_gray_wool
fill 346 134 279 346 134 281 minecraft:white_wool
setblock 346 134 282 minecraft:light_gray_wool
fill 346 134 283 348 134 283 minecraft:white_wool
setblock 346 134 306 minecraft:light_gray_wool
fill 346 134 307 348 134 307 minecraft:white_wool
setblock 346 134 310 minecraft:light_gray_wool
fill 346 134 311 348 134 311 minecraft:white_wool
setblock 346 134 314 minecraft:light_gray_wool
fill 346 134 315 348 134 315 minecraft:white_wool
setblock 347 134 276 minecraft:white_wool
setblock 347 134 277 minecraft:light_gray_wool
fill 347 134 278 347 134 280 minecraft:white_wool
setblock 347 134 281 minecraft:light_gray_wool
fill 347 134 282 349 134 282 minecraft:white_wool
setblock 347 134 284 minecraft:white_wool
fill 347 134 306 348 134 306 minecraft:white_wool
setblock 347 134 309 minecraft:light_gray_wool
fill 347 134 310 349 134 310 minecraft:white_wool
setblock 347 134 313 minecraft:light_gray_wool
fill 347 134 314 349 134 314 minecraft:white_wool
setblock 347 134 317 minecraft:white_concrete
setblock 348 134 276 minecraft:light_gray_wool
fill 348 134 277 348 134 279 minecraft:white_wool
setblock 348 134 280 minecraft:light_gray_wool
fill 348 134 281 350 134 281 minecraft:white_wool
setblock 348 134 284 minecraft:light_gray_wool
fill 348 134 292 348 134 293 minecraft:white_stained_glass
fill 348 134 294 348 134 296 minecraft:yellow_concrete
fill 348 134 297 348 134 298 minecraft:white_stained_glass
setblock 348 134 308 minecraft:light_gray_wool
fill 348 134 309 350 134 309 minecraft:white_wool
setblock 348 134 312 minecraft:light_gray_wool
fill 348 134 313 350 134 313 minecraft:white_wool
setblock 348 134 316 minecraft:light_gray_wool
fill 348 134 317 369 134 317 minecraft:light_blue_terracotta
fill 349 134 276 349 134 278 minecraft:white_wool
setblock 349 134 279 minecraft:light_gray_wool
fill 349 134 280 351 134 280 minecraft:white_wool
setblock 349 134 283 minecraft:light_gray_wool
setblock 349 134 284 minecraft:yellow_concrete
fill 349 134 292 349 134 294 minecraft:yellow_concrete
fill 349 134 296 349 134 298 minecraft:yellow_concrete
setblock 349 134 306 minecraft:lime_concrete
setblock 349 134 307 minecraft:light_gray_wool
fill 349 134 308 351 134 308 minecraft:white_wool
setblock 349 134 311 minecraft:light_gray_wool
fill 349 134 312 351 134 312 minecraft:white_wool
setblock 349 134 315 minecraft:light_gray_wool
fill 349 134 316 351 134 316 minecraft:white_wool
fill 350 134 276 350 134 277 minecraft:white_wool
setblock 350 134 278 minecraft:light_gray_wool
fill 350 134 279 352 134 279 minecraft:white_wool
setblock 350 134 282 minecraft:light_gray_wool
fill 350 134 283 352 134 283 minecraft:white_wool
fill 350 134 292 351 134 292 minecraft:yellow_concrete
fill 350 134 298 351 134 298 minecraft:yellow_concrete
fill 350 134 307 352 134 307 minecraft:white_wool
setblock 350 134 310 minecraft:light_gray_wool
fill 350 134 311 352 134 311 minecraft:white_wool
setblock 350 134 314 minecraft:light_gray_wool
fill 350 134 315 352 134 315 minecraft:white_wool
setblock 351 134 276 minecraft:white_wool
setblock 351 134 277 minecraft:light_gray_wool
fill 351 134 278 353 134 278 minecraft:white_wool
setblock 351 134 281 minecraft:light_gray_wool
fill 351 134 282 353 134 282 minecraft:white_wool
fill 351 134 290 360 134 290 minecraft:white_stained_glass
fill 351 134 291 353 134 291 minecraft:yellow_concrete
fill 351 134 299 353 134 299 minecraft:yellow_concrete
fill 351 134 300 360 134 300 minecraft:white_stained_glass
setblock 351 134 309 minecraft:light_gray_wool
fill 351 134 310 353 134 310 minecraft:white_wool
setblock 351 134 313 minecraft:light_gray_wool
fill 351 134 314 353 134 314 minecraft:white_wool
setblock 352 134 276 minecraft:light_gray_wool
fill 352 134 277 354 134 277 minecraft:white_wool
setblock 352 134 280 minecraft:light_gray_wool
fill 352 134 281 354 134 281 minecraft:white_wool
setblock 352 134 308 minecraft:light_gray_wool
fill 352 134 309 354 134 309 minecraft:white_wool
setblock 352 134 312 minecraft:light_gray_wool
fill 352 134 313 354 134 313 minecraft:white_wool
setblock 352 134 316 minecraft:light_gray_wool
fill 353 134 276 355 134 276 minecraft:white_wool
setblock 353 134 279 minecraft:light_gray_wool
fill 353 134 280 355 134 280 minecraft:white_wool
setblock 353 134 283 minecraft:light_gray_wool
fill 353 134 292 355 134 292 minecraft:yellow_concrete
fill 353 134 298 355 134 298 minecraft:yellow_concrete
setblock 353 134 307 minecraft:light_gray_wool
fill 353 134 308 355 134 308 minecraft:white_wool
setblock 353 134 311 minecraft:light_gray_wool
fill 353 134 312 355 134 312 minecraft:white_wool
setblock 353 134 315 minecraft:light_gray_wool
fill 353 134 316 355 134 316 minecraft:white_wool
setblock 354 134 278 minecraft:light_gray_wool
fill 354 134 279 356 134 279 minecraft:white_wool
setblock 354 134 282 minecraft:light_gray_wool
fill 354 134 283 356 134 283 minecraft:white_wool
fill 354 134 291 360 134 291 minecraft:white_stained_glass
fill 354 134 299 360 134 299 minecraft:white_stained_glass
fill 354 134 307 356 134 307 minecraft:white_wool
setblock 354 134 310 minecraft:light_gray_wool
fill 354 134 311 356 134 311 minecraft:white_wool
setblock 354 134 314 minecraft:light_gray_wool
fill 354 134 315 356 134 315 minecraft:white_wool
setblock 355 134 277 minecraft:light_gray_wool
fill 355 134 278 357 134 278 minecraft:white_wool
setblock 355 134 281 minecraft:light_gray_wool
fill 355 134 282 357 134 282 minecraft:white_wool
setblock 355 134 284 minecraft:lime_concrete
fill 355 134 293 355 134 294 minecraft:yellow_concrete
fill 355 134 296 355 134 297 minecraft:yellow_concrete
setblock 355 134 306 minecraft:yellow_concrete
setblock 355 134 309 minecraft:light_gray_wool
fill 355 134 310 357 134 310 minecraft:white_wool
setblock 355 134 313 minecraft:light_gray_wool
fill 355 134 314 357 134 314 minecraft:white_wool
setblock 356 134 276 minecraft:light_gray_wool
fill 356 134 277 358 134 277 minecraft:white_wool
setblock 356 134 280 minecraft:light_gray_wool
fill 356 134 281 358 134 281 minecraft:white_wool
setblock 356 134 284 minecraft:light_gray_wool
fill 356 134 292 361 134 293 minecraft:white_stained_glass
fill 356 134 294 356 134 296 minecraft:yellow_concrete
fill 356 134 297 361 134 298 minecraft:white_stained_glass
fill 356 134 306 357 134 306 minecraft:white_wool
setblock 356 134 308 minecraft:light_gray_wool
fill 356 134 309 358 134 309 minecraft:white_wool
setblock 356 134 312 minecraft:light_gray_wool
fill 356 134 313 358 134 313 minecraft:white_wool
setblock 356 134 316 minecraft:light_gray_wool
fill 357 134 276 359 134 276 minecraft:white_wool
setblock 357 134 279 minecraft:light_gray_wool
fill 357 134 280 359 134 280 minecraft:white_wool
setblock 357 134 283 minecraft:light_gray_wool
fill 357 134 284 359 134 284 minecraft:white_wool
fill 357 134 294 361 134 296 minecraft:white_stained_glass
setblock 357 134 307 minecraft:light_gray_wool
fill 357 134 308 359 134 308 minecraft:white_wool
setblock 357 134 311 minecraft:light_gray_wool
fill 357 134 312 359 134 312 minecraft:white_wool
setblock 357 134 315 minecraft:light_gray_wool
fill 357 134 316 359 134 316 minecraft:white_wool
setblock 358 134 278 minecraft:light_gray_wool
fill 358 134 279 360 134 279 minecraft:white_wool
setblock 358 134 282 minecraft:light_gray_wool
fill 358 134 283 360 134 283 minecraft:white_wool
setblock 358 134 285 minecraft:white_wool
setblock 358 134 305 minecraft:white_wool
setblock 358 134 306 minecraft:light_gray_wool
fill 358 134 307 360 134 307 minecraft:white_wool
setblock 358 134 310 minecraft:light_gray_wool
fill 358 134 311 360 134 311 minecraft:white_wool
setblock 358 134 314 minecraft:light_gray_wool
fill 358 134 315 360 134 315 minecraft:white_wool
setblock 359 134 277 minecraft:light_gray_wool
fill 359 134 278 361 134 278 minecraft:white_wool
setblock 359 134 281 minecraft:light_gray_wool
fill 359 134 282 361 134 282 minecraft:white_wool
setblock 359 134 285 minecraft:light_gray_wool
setblock 359 134 286 minecraft:light_blue_concrete
setblock 359 134 304 minecraft:orange_concrete
setblock 359 134 305 minecraft:light_gray_wool
fill 359 134 306 361 134 306 minecraft:white_wool
setblock 359 134 309 minecraft:light_gray_wool
fill 359 134 310 361 134 310 minecraft:white_wool
setblock 359 134 313 minecraft:light_gray_wool
fill 359 134 314 361 134 314 minecraft:white_wool
setblock 360 134 276 minecraft:light_gray_wool
fill 360 134 277 362 134 277 minecraft:white_wool
setblock 360 134 280 minecraft:light_gray_wool
fill 360 134 281 362 134 281 minecraft:white_wool
setblock 360 134 284 minecraft:light_gray_wool
fill 360 134 285 361 134 286 minecraft:white_wool
setblock 360 134 287 minecraft:light_blue_concrete
setblock 360 134 303 minecraft:orange_concrete
setblock 360 134 304 minecraft:light_gray_wool
fill 360 134 305 362 134 305 minecraft:white_wool
setblock 360 134 308 minecraft:light_gray_wool
fill 360 134 309 362 134 309 minecraft:white_wool
setblock 360 134 312 minecraft:light_gray_wool
fill 360 134 313 362 134 313 minecraft:white_wool
setblock 360 134 316 minecraft:light_gray_wool
fill 361 134 276 363 134 276 minecraft:white_wool
setblock 361 134 279 minecraft:light_gray_wool
fill 361 134 280 363 134 280 minecraft:white_wool
setblock 361 134 283 minecraft:light_gray_wool
fill 361 134 284 363 134 284 minecraft:white_wool
setblock 361 134 287 minecraft:light_gray_wool
setblock 361 134 288 minecraft:light_blue_concrete
setblock 361 134 302 minecraft:orange_concrete
setblock 361 134 303 minecraft:light_gray_wool
fill 361 134 304 363 134 304 minecraft:white_wool
setblock 361 134 307 minecraft:light_gray_wool
fill 361 134 308 363 134 308 minecraft:white_wool
setblock 361 134 311 minecraft:light_gray_wool
fill 361 134 312 363 134 312 minecraft:white_wool
setblock 361 134 315 minecraft:light_gray_wool
fill 361 134 316 363 134 316 minecraft:white_wool
setblock 362 134 278 minecraft:light_gray_wool
fill 362 134 279 364 134 279 minecraft:white_wool
setblock 362 134 282 minecraft:light_gray_wool
fill 362 134 283 364 134 283 minecraft:white_wool
setblock 362 134 285 minecraft:white_wool
setblock 362 134 286 minecraft:light_gray_wool
fill 362 134 287 362 134 289 minecraft:white_wool
setblock 362 134 301 minecraft:white_wool
setblock 362 134 302 minecraft:light_gray_wool
fill 362 134 303 364 134 303 minecraft:white_wool
setblock 362 134 306 minecraft:light_gray_wool
fill 362 134 307 364 134 307 minecraft:white_wool
setblock 362 134 310 minecraft:light_gray_wool
fill 362 134 311 364 134 311 minecraft:white_wool
setblock 362 134 314 minecraft:light_gray_wool
fill 362 134 315 364 134 315 minecraft:white_wool
setblock 363 134 277 minecraft:light_gray_wool
fill 363 134 278 365 134 278 minecraft:white_wool
setblock 363 134 281 minecraft:light_gray_wool
fill 363 134 282 365 134 282 minecraft:white_wool
setblock 363 134 285 minecraft:light_gray_wool
fill 363 134 286 363 134 288 minecraft:white_wool
setblock 363 134 289 minecraft:light_gray_wool
fill 363 134 290 364 134 291 minecraft:white_wool
setblock 363 134 292 minecraft:purple_concrete
setblock 363 134 298 minecraft:red_concrete
fill 363 134 299 363 134 300 minecraft:white_wool
setblock 363 134 301 minecraft:light_gray_wool
fill 363 134 302 365 134 302 minecraft:white_wool
setblock 363 134 305 minecraft:light_gray_wool
fill 363 134 306 365 134 306 minecraft:white_wool
setblock 363 134 309 minecraft:light_gray_wool
fill 363 134 310 365 134 310 minecraft:white_wool
setblock 363 134 313 minecraft:light_gray_wool
fill 363 134 314 365 134 314 minecraft:white_wool
setblock 364 134 276 minecraft:light_gray_wool
fill 364 134 277 366 134 277 minecraft:white_wool
setblock 364 134 280 minecraft:light_gray_wool
fill 364 134 281 366 134 281 minecraft:white_wool
setblock 364 134 284 minecraft:light_gray_wool
fill 364 134 285 364 134 287 minecraft:white_wool
setblock 364 134 288 minecraft:light_gray_wool
fill 364 134 289 366 134 289 minecraft:white_wool
setblock 364 134 292 minecraft:light_gray_wool
fill 364 134 293 364 134 295 minecraft:white_wool
setblock 364 134 296 minecraft:light_gray_wool
fill 364 134 297 364 134 299 minecraft:white_wool
setblock 364 134 300 minecraft:light_gray_wool
fill 364 134 301 366 134 301 minecraft:white_wool
setblock 364 134 304 minecraft:light_gray_wool
fill 364 134 305 366 134 305 minecraft:white_wool
setblock 364 134 308 minecraft:light_gray_wool
fill 364 134 309 366 134 309 minecraft:white_wool
setblock 364 134 312 minecraft:light_gray_wool
fill 364 134 313 366 134 313 minecraft:white_wool
setblock 364 134 316 minecraft:light_gray_wool
fill 365 134 275 370 135 275 minecraft:light_blue_terracotta
fill 365 134 276 367 134 276 minecraft:white_wool
setblock 365 134 279 minecraft:light_gray_wool
fill 365 134 280 367 134 280 minecraft:white_wool
setblock 365 134 283 minecraft:light_gray_wool
fill 365 134 284 365 134 286 minecraft:white_wool
setblock 365 134 287 minecraft:light_gray_wool
fill 365 134 288 367 134 288 minecraft:white_wool
setblock 365 134 290 minecraft:white_wool
setblock 365 134 291 minecraft:light_gray_wool
fill 365 134 292 365 134 294 minecraft:white_wool
setblock 365 134 295 minecraft:light_gray_wool
fill 365 134 296 365 134 298 minecraft:white_wool
setblock 365 134 299 minecraft:light_gray_wool
fill 365 134 300 367 134 300 minecraft:white_wool
setblock 365 134 303 minecraft:light_gray_wool
fill 365 134 304 367 134 304 minecraft:white_wool
setblock 365 134 307 minecraft:light_gray_wool
fill 365 134 308 367 134 308 minecraft:white_wool
setblock 365 134 311 minecraft:light_gray_wool
fill 365 134 312 367 134 312 minecraft:white_wool
setblock 365 134 315 minecraft:light_gray_wool
fill 365 134 316 367 134 316 minecraft:white_wool
setblock 366 134 278 minecraft:light_gray_wool
fill 366 134 279 368 134 279 minecraft:white_wool
setblock 366 134 282 minecraft:light_gray_wool
fill 366 134 283 366 134 285 minecraft:white_wool
setblock 366 134 286 minecraft:light_gray_wool
fill 366 134 287 368 134 287 minecraft:white_wool
setblock 366 134 290 minecraft:light_gray_wool
fill 366 134 291 366 134 293 minecraft:white_wool
setblock 366 134 294 minecraft:light_gray_wool
fill 366 134 295 366 134 297 minecraft:white_wool
setblock 366 134 298 minecraft:light_gray_wool
fill 366 134 299 368 134 299 minecraft:white_wool
setblock 366 134 302 minecraft:light_gray_wool
fill 366 134 303 368 134 303 minecraft:white_wool
setblock 366 134 306 minecraft:light_gray_wool
fill 366 134 307 368 134 307 minecraft:white_wool
setblock 366 134 310 minecraft:light_gray_wool
fill 366 134 311 368 134 311 minecraft:white_wool
setblock 366 134 314 minecraft:light_gray_wool
fill 366 134 315 368 134 315 minecraft:white_wool
setblock 367 134 277 minecraft:light_gray_wool
fill 367 134 278 369 134 278 minecraft:white_wool
setblock 367 134 281 minecraft:light_gray_wool
fill 367 134 282 367 134 284 minecraft:white_wool
setblock 367 134 285 minecraft:light_gray_wool
fill 367 134 286 369 134 286 minecraft:white_wool
setblock 367 134 289 minecraft:light_gray_wool
fill 367 134 290 367 134 292 minecraft:white_wool
setblock 367 134 293 minecraft:light_gray_wool
fill 367 134 294 367 134 296 minecraft:white_wool
setblock 367 134 297 minecraft:light_gray_wool
fill 367 134 298 369 134 298 minecraft:white_wool
setblock 367 134 301 minecraft:light_gray_wool
fill 367 134 302 369 134 302 minecraft:white_wool
setblock 367 134 305 minecraft:light_gray_wool
fill 367 134 306 369 134 306 minecraft:white_wool
setblock 367 134 309 minecraft:light_gray_wool
fill 367 134 310 369 134 310 minecraft:white_wool
setblock 367 134 313 minecraft:light_gray_wool
fill 367 134 314 369 134 314 minecraft:white_wool
setblock 368 134 276 minecraft:light_gray_wool
fill 368 134 277 370 134 277 minecraft:white_wool
setblock 368 134 280 minecraft:light_gray_wool
fill 368 134 281 368 134 283 minecraft:white_wool
setblock 368 134 284 minecraft:light_gray_wool
fill 368 134 285 370 134 285 minecraft:white_wool
setblock 368 134 288 minecraft:light_gray_wool
fill 368 134 289 368 134 291 minecraft:white_wool
setblock 368 134 292 minecraft:light_gray_wool
fill 368 134 293 368 134 295 minecraft:white_wool
setblock 368 134 296 minecraft:light_gray_wool
fill 368 134 297 370 134 297 minecraft:white_wool
setblock 368 134 300 minecraft:light_gray_wool
fill 368 134 301 370 134 301 minecraft:white_wool
setblock 368 134 304 minecraft:light_gray_wool
fill 368 134 305 370 134 305 minecraft:white_wool
setblock 368 134 308 minecraft:light_gray_wool
fill 368 134 309 370 134 309 minecraft:white_wool
setblock 368 134 312 minecraft:light_gray_wool
fill 368 134 313 370 134 313 minecraft:white_wool
setblock 368 134 316 minecraft:light_gray_wool
fill 369 134 276 370 134 276 minecraft:white_wool
setblock 369 134 279 minecraft:light_gray_wool
fill 369 134 280 369 134 282 minecraft:white_wool
setblock 369 134 283 minecraft:light_gray_wool
fill 369 134 284 370 134 284 minecraft:white_wool
setblock 369 134 287 minecraft:light_gray_wool
fill 369 134 288 369 134 290 minecraft:white_wool
setblock 369 134 291 minecraft:light_gray_wool
fill 369 134 292 369 134 294 minecraft:white_wool
setblock 369 134 295 minecraft:light_gray_wool
fill 369 134 296 370 134 296 minecraft:white_wool
setblock 369 134 299 minecraft:light_gray_wool
fill 369 134 300 370 134 300 minecraft:white_wool
setblock 369 134 303 minecraft:light_gray_wool
fill 369 134 304 370 134 304 minecraft:white_wool
setblock 369 134 307 minecraft:light_gray_wool
fill 369 134 308 370 134 308 minecraft:white_wool
setblock 369 134 311 minecraft:light_gray_wool
fill 369 134 312 370 134 312 minecraft:white_wool
setblock 369 134 315 minecraft:light_gray_wool
fill 369 134 316 370 134 316 minecraft:white_wool
setblock 370 134 278 minecraft:light_gray_wool
fill 370 134 279 370 134 281 minecraft:white_wool
setblock 370 134 282 minecraft:light_gray_wool
setblock 370 134 283 minecraft:white_wool
setblock 370 134 286 minecraft:light_gray_wool
fill 370 134 287 370 134 289 minecraft:white_wool
setblock 370 134 290 minecraft:light_gray_wool
fill 370 134 291 370 134 293 minecraft:white_wool
setblock 370 134 294 minecraft:light_gray_wool
setblock 370 134 295 minecraft:white_wool
setblock 370 134 298 minecraft:light_gray_wool
setblock 370 134 299 minecraft:white_wool
setblock 370 134 302 minecraft:light_gray_wool
setblock 370 134 303 minecraft:white_wool
setblock 370 134 306 minecraft:light_gray_wool
setblock 370 134 307 minecraft:white_wool
setblock 370 134 310 minecraft:light_gray_wool
setblock 370 134 311 minecraft:white_wool
setblock 370 134 314 minecraft:light_gray_wool
setblock 370 134 315 minecraft:white_wool
fill 371 134 276 371 155 276 minecraft:light_blue_terracotta
fill 371 134 278 371 167 278 minecraft:light_blue_terracotta
fill 371 134 280 371 134 299 minecraft:light_blue_terracotta
fill 371 134 301 371 135 304 minecraft:light_blue_terracotta
fill 371 134 305 371 135 305 minecraft:white_concrete
fill 371 134 306 371 221 306 minecraft:light_blue_terracotta
setblock 371 134 307 minecraft:white_concrete
fill 371 134 308 371 215 310 minecraft:light_blue_terracotta
fill 371 134 313 371 135 317 minecraft:light_blue_terracotta
fill 329 135 275 329 136 275 minecraft:white_concrete
fill 329 135 276 329 152 279 minecraft:light_blue_terracotta
fill 329 135 280 329 136 280 minecraft:white_concrete
fill 329 135 281 329 139 284 minecraft:light_blue_terracotta
fill 329 135 292 329 135 295 minecraft:light_blue_terracotta
setblock 329 135 296 minecraft:white_concrete
fill 329 135 297 329 162 300 minecraft:light_blue_terracotta
setblock 329 135 301 minecraft:white_concrete
fill 329 135 302 329 135 306 minecraft:light_blue_terracotta
setblock 329 135 307 minecraft:white_concrete
fill 329 135 308 329 135 317 minecraft:light_blue_terracotta
fill 330 135 275 338 135 275 minecraft:light_blue_terracotta
fill 330 135 317 331 214 317 minecraft:light_blue_terracotta
setblock 332 135 317 minecraft:white_concrete
fill 333 135 317 335 158 317 minecraft:light_blue_terracotta
fill 338 135 317 338 190 317 minecraft:light_blue_terracotta
setblock 339 135 275 minecraft:white_concrete
setblock 339 135 317 minecraft:white_concrete
fill 340 135 275 346 142 275 minecraft:light_blue_terracotta
fill 340 135 317 344 165 317 minecraft:light_blue_terracotta
fill 343 135 292 344 135 295 minecraft:red_concrete
fill 343 135 296 344 135 298 minecraft:purple_concrete
fill 344 135 290 346 135 290 minecraft:orange_concrete
fill 344 135 291 345 135 291 minecraft:red_concrete
fill 344 135 299 345 135 299 minecraft:purple_concrete
fill 344 135 300 346 135 300 minecraft:light_blue_concrete
fill 345 135 289 347 135 289 minecraft:orange_concrete
fill 345 135 301 347 135 301 minecraft:light_blue_concrete
fill 346 135 288 347 135 288 minecraft:orange_concrete
fill 346 135 302 347 135 302 minecraft:light_blue_concrete
fill 347 135 275 348 135 275 minecraft:white_concrete
setblock 347 135 287 minecraft:orange_concrete
setblock 347 135 303 minecraft:light_blue_concrete
fill 347 135 317 350 189 317 minecraft:light_blue_terracotta
fill 348 135 287 348 135 288 minecraft:yellow_concrete
fill 348 135 302 348 135 303 minecraft:lime_concrete
fill 349 135 275 354 135 275 minecraft:light_blue_terracotta
fill 349 135 286 351 135 287 minecraft:yellow_concrete
fill 349 135 303 352 135 304 minecraft:lime_concrete
fill 351 135 317 351 136 317 minecraft:white_concrete
fill 352 135 286 355 135 287 minecraft:lime_concrete
fill 352 135 317 357 135 317 minecraft:light_blue_terracotta
fill 353 135 303 355 135 304 minecraft:yellow_concrete
setblock 355 135 275 minecraft:white_concrete
fill 356 135 275 358 135 275 minecraft:light_blue_terracotta
fill 356 135 287 356 135 288 minecraft:lime_concrete
fill 356 135 302 356 135 303 minecraft:yellow_concrete
fill 357 135 287 357 135 289 minecraft:light_blue_concrete
fill 357 135 301 357 135 303 minecraft:orange_concrete
fill 358 135 288 358 135 290 minecraft:light_blue_concrete
fill 358 135 300 358 135 302 minecraft:orange_concrete
setblock 358 135 317 minecraft:white_concrete
setblock 359 135 275 minecraft:white_concrete
fill 359 135 289 359 135 290 minecraft:light_blue_concrete
fill 359 135 291 360 135 291 minecraft:purple_concrete
fill 359 135 299 360 135 299 minecraft:red_concrete
fill 359 135 300 359 135 301 minecraft:orange_concrete
fill 359 135 317 362 135 317 minecraft:light_blue_terracotta
fill 360 135 275 364 150 275 minecraft:light_blue_terracotta
setblock 360 135 290 minecraft:light_blue_concrete
fill 360 135 292 361 135 294 minecraft:purple_concrete
fill 360 135 295 361 135 298 minecraft:red_concrete
setblock 360 135 300 minecraft:orange_concrete
setblock 363 135 317 minecraft:white_concrete
fill 364 135 317 364 137 317 minecraft:light_blue_terracotta
setblock 365 135 317 minecraft:white_concrete
fill 366 135 317 370 152 317 minecraft:light_blue_terracotta
fill 371 135 275 371 221 275 minecraft:light_blue_terracotta
fill 371 135 277 371 200 277 minecraft:light_blue_terracotta
fill 371 135 279 371 213 281 minecraft:light_blue_terracotta
setblock 371 135 282 minecraft:white_concrete
fill 371 135 283 371 150 284 minecraft:light_blue_terracotta
setblock 371 135 285 minecraft:white_concrete
fill 371 135 286 371 135 293 minecraft:light_blue_terracotta
fill 371 135 294 371 135 296 minecraft:white_concrete
fill 371 135 297 371 142 300 minecraft:light_blue_terracotta
fill 371 135 307 371 185 307 minecraft:light_blue_terracotta
fill 371 135 311 371 135 312 minecraft:light_blue_terracotta
fill 329 136 285 329 151 289 minecraft:light_blue_terracotta
setblock 329 136 290 minecraft:white_concrete
fill 329 136 291 329 189 294 minecraft:light_blue_terracotta
setblock 329 136 295 minecraft:white_concrete
fill 329 136 296 329 168 296 minecraft:light_blue_terracotta
fill 329 136 301 329 219 304 minecraft:light_blue_terracotta
setblock 329 136 305 minecraft:white_concrete
fill 329 136 306 329 221 306 minecraft:light_blue_terracotta
setblock 329 136 307 minecraft:white_wool
fill 329 136 308 329 180 309 minecraft:light_blue_terracotta
setblock 329 136 310 minecraft:white_concrete
fill 329 136 311 329 143 313 minecraft:light_blue_terracotta
setblock 329 136 314 minecraft:white_concrete
fill 329 136 315 329 218 317 minecraft:light_blue_terracotta
setblock 330 136 275 minecraft:white_concrete
fill 331 136 275 337 150 275 minecraft:light_blue_terracotta
setblock 332 136 278 minecraft:light[level=15]
setblock 332 136 286 minecraft:light[level=15]
setblock 332 136 294 minecraft:light[level=15]
setblock 332 136 302 minecraft:light[level=15]
setblock 332 136 310 minecraft:light[level=15]
fill 332 136 317 332 217 317 minecraft:light_blue_terracotta
fill 337 136 317 337 143 317 minecraft:light_blue_terracotta
setblock 338 136 275 minecraft:white_concrete
fill 339 136 275 339 204 275 minecraft:light_blue_terracotta
fill 339 136 317 339 196 317 minecraft:light_blue_terracotta
setblock 340 136 278 minecraft:light[level=15]
setblock 340 136 286 minecraft:light[level=15]
setblock 340 136 294 minecraft:light[level=15]
setblock 340 136 302 minecraft:light[level=15]
setblock 340 136 310 minecraft:light[level=15]
fill 347 136 275 352 144 275 minecraft:light_blue_terracotta
setblock 348 136 278 minecraft:light[level=15]
setblock 348 136 286 minecraft:light[level=15]
setblock 348 136 294 minecraft:light[level=15]
setblock 348 136 302 minecraft:light[level=15]
setblock 348 136 310 minecraft:light[level=15]
setblock 352 136 317 minecraft:white_concrete
setblock 353 136 275 minecraft:white_concrete
fill 353 136 317 356 152 317 minecraft:light_blue_terracotta
fill 354 136 275 355 139 275 minecraft:light_blue_terracotta
setblock 356 136 275 minecraft:white_concrete
setblock 356 136 278 minecraft:light[level=15]
setblock 356 136 286 minecraft:light[level=15]
setblock 356 136 294 minecraft:light[level=15]
setblock 356 136 302 minecraft:light[level=15]
setblock 356 136 310 minecraft:light[level=15]
fill 357 136 275 359 217 275 minecraft:light_blue_terracotta
setblock 357 136 317 minecraft:white_concrete
fill 358 136 317 359 140 317 minecraft:light_blue_terracotta
setblock 360 136 317 minecraft:white_concrete
fill 361 136 317 363 146 317 minecraft:light_blue_terracotta
setblock 364 136 278 minecraft:light[level=15]
setblock 364 136 286 minecraft:light[level=15]
setblock 364 136 294 minecraft:light[level=15]
setblock 364 136 302 minecraft:light[level=15]
setblock 364 136 310 minecraft:light[level=15]
setblock 365 136 275 minecraft:white_concrete
fill 365 136 317 365 155 317 minecraft:light_blue_terracotta
fill 366 136 275 366 195 275 minecraft:light_blue_terracotta
setblock 367 136 275 minecraft:white_concrete
fill 368 136 275 370 218 275 minecraft:light_blue_terracotta
fill 371 136 282 371 186 282 minecraft:light_blue_terracotta
fill 371 136 285 371 140 291 minecraft:light_blue_terracotta
setblock 371 136 292 minecraft:white_concrete
fill 371 136 293 371 161 293 minecraft:light_blue_terracotta
setblock 371 136 294 minecraft:white_concrete
fill 371 136 295 371 217 296 minecraft:light_blue_terracotta
fill 371 136 301 371 215 303 minecraft:light_blue_terracotta
setblock 371 136 304 minecraft:white_concrete
fill 371 136 305 371 221 305 minecraft:light_blue_terracotta
setblock 371 136 311 minecraft:white_concrete
fill 371 136 312 371 221 312 minecraft:light_blue_terracotta
setblock 371 136 313 minecraft:white_concrete
fill 371 136 314 371 148 316 minecraft:light_blue_terracotta
setblock 371 136 317 minecraft:white_concrete
fill 329 137 275 330 151 275 minecraft:light_blue_terracotta
fill 329 137 280 329 149 280 minecraft:light_blue_terracotta
fill 329 137 290 329 152 290 minecraft:light_blue_terracotta
fill 329 137 295 329 221 295 minecraft:light_blue_terracotta
fill 329 137 305 329 217 305 minecraft:light_blue_terracotta
fill 329 137 307 329 221 307 minecraft:light_blue_terracotta
fill 329 137 310 329 189 310 minecraft:light_blue_terracotta
fill 329 137 314 329 221 314 minecraft:light_blue_terracotta
fill 338 137 275 338 215 275 minecraft:light_blue_terracotta
fill 351 137 317 352 140 317 minecraft:light_blue_terracotta
fill 353 137 275 353 221 275 minecraft:light_blue_terracotta
fill 356 137 275 356 157 275 minecraft:light_blue_terracotta
fill 357 137 317 357 221 317 minecraft:light_blue_terracotta
fill 360 137 317 360 161 317 minecraft:light_blue_terracotta
fill 365 137 275 365 221 275 minecraft:light_blue_terracotta
fill 367 137 275 367 223 275 minecraft:light_blue_terracotta
fill 371 137 292 371 221 292 minecraft:light_blue_terracotta
fill 371 137 294 371 221 294 minecraft:light_blue_terracotta
fill 371 137 304 371 221 304 minecraft:light_blue_terracotta
fill 371 137 311 371 221 311 minecraft:light_blue_terracotta
fill 371 137 313 371 147 313 minecraft:light_blue_terracotta
fill 371 137 317 371 222 317 minecraft:light_blue_terracotta
setblock 332 138 278 minecraft:light[level=12]
setblock 332 138 285 minecraft:light[level=12]
setblock 332 138 292 minecraft:light[level=12]
setblock 332 138 299 minecraft:light[level=12]
setblock 332 138 306 minecraft:light[level=12]
setblock 332 138 313 minecraft:light[level=12]
setblock 339 138 278 minecraft:light[level=12]
setblock 339 138 285 minecraft:light[level=12]
setblock 339 138 292 minecraft:light[level=12]
setblock 339 138 299 minecraft:light[level=12]
setblock 339 138 306 minecraft:light[level=12]
setblock 339 138 313 minecraft:light[level=12]
setblock 346 138 278 minecraft:light[level=12]
setblock 346 138 285 minecraft:light[level=12]
setblock 346 138 292 minecraft:light[level=12]
setblock 346 138 299 minecraft:light[level=12]
setblock 346 138 306 minecraft:light[level=12]
fill 346 138 311 348 139 311 minecraft:white_concrete
setblock 346 138 313 minecraft:light[level=12]
fill 347 138 310 347 139 310 minecraft:white_concrete
fill 347 138 312 347 139 312 minecraft:white_concrete
setblock 353 138 278 minecraft:light[level=12]
setblock 353 138 285 minecraft:light[level=12]
setblock 353 138 292 minecraft:light[level=12]
setblock 353 138 299 minecraft:light[level=12]
setblock 353 138 306 minecraft:light[level=12]
setblock 353 138 313 minecraft:light[level=12]
setblock 360 138 278 minecraft:light[level=12]
setblock 360 138 285 minecraft:light[level=12]
setblock 360 138 292 minecraft:light[level=12]
setblock 360 138 299 minecraft:light[level=12]
setblock 360 138 306 minecraft:light[level=12]
setblock 360 138 313 minecraft:light[level=12]
setblock 364 138 317 minecraft:white_wool
setblock 367 138 278 minecraft:light[level=12]
setblock 367 138 285 minecraft:light[level=12]
setblock 367 138 292 minecraft:light[level=12]
setblock 367 138 299 minecraft:light[level=12]
setblock 367 138 306 minecraft:light[level=12]
setblock 367 138 313 minecraft:light[level=12]
fill 350 139 313 350 141 313 minecraft:ochre_froglight
fill 364 139 317 364 217 317 minecraft:light_blue_terracotta
fill 329 140 281 329 173 281 minecraft:light_blue_terracotta
setblock 329 140 282 minecraft:white_wool
fill 329 140 283 329 154 284 minecraft:light_blue_terracotta
fill 354 140 275 354 221 275 minecraft:light_blue_terracotta
setblock 355 140 275 minecraft:white_wool
fill 329 141 282 329 165 282 minecraft:light_blue_terracotta
fill 351 141 317 351 221 317 minecraft:light_blue_terracotta
setblock 352 141 317 minecraft:white_wool
fill 355 141 275 355 204 275 minecraft:light_blue_terracotta
setblock 358 141 317 minecraft:white_wool
fill 359 141 317 359 221 317 minecraft:light_blue_terracotta
fill 371 141 285 371 170 286 minecraft:light_blue_terracotta
setblock 371 141 287 minecraft:white_wool
fill 371 141 288 371 162 291 minecraft:light_blue_terracotta
fill 349 142 313 350 150 313 minecraft:dirt
fill 352 142 317 352 218 317 minecraft:light_blue_terracotta
fill 358 142 317 358 157 317 minecraft:light_blue_terracotta
fill 371 142 287 371 216 287 minecraft:light_blue_terracotta
fill 340 143 275 340 221 275 minecraft:light_blue_terracotta
setblock 341 143 275 minecraft:white_wool
fill 342 143 275 346 146 275 minecraft:light_blue_terracotta
fill 349 143 312 350 150 312 minecraft:dirt
fill 371 143 297 371 174 299 minecraft:light_blue_terracotta
setblock 371 143 300 minecraft:white_wool
setblock 329 144 311 minecraft:white_wool
fill 329 144 312 329 217 313 minecraft:light_blue_terracotta
setblock 332 144 278 minecraft:light[level=15]
setblock 332 144 285 minecraft:light[level=12]
setblock 332 144 286 minecraft:light[level=15]
setblock 332 144 292 minecraft:light[level=12]
setblock 332 144 294 minecraft:light[level=15]
setblock 332 144 299 minecraft:light[level=12]
setblock 332 144 302 minecraft:light[level=15]
setblock 332 144 306 minecraft:light[level=12]
setblock 332 144 310 minecraft:light[level=15]
setblock 332 144 313 minecraft:light[level=12]
setblock 337 144 317 minecraft:white_wool
setblock 339 144 278 minecraft:light[level=12]
setblock 339 144 285 minecraft:light[level=12]
setblock 339 144 292 minecraft:light[level=12]
setblock 339 144 299 minecraft:light[level=12]
setblock 339 144 306 minecraft:light[level=12]
setblock 339 144 313 minecraft:light[level=12]
setblock 340 144 278 minecraft:light[level=15]
setblock 340 144 286 minecraft:light[level=15]
setblock 340 144 294 minecraft:light[level=15]
setblock 340 144 302 minecraft:light[level=15]
setblock 340 144 310 minecraft:light[level=15]
fill 341 144 275 341 221 275 minecraft:light_blue_terracotta
setblock 346 144 278 minecraft:light[level=12]
setblock 346 144 285 minecraft:light[level=12]
setblock 346 144 292 minecraft:light[level=12]
setblock 346 144 299 minecraft:light[level=12]
setblock 346 144 306 minecraft:light[level=12]
setblock 346 144 313 minecraft:light[level=12]
setblock 348 144 278 minecraft:light[level=15]
setblock 348 144 286 minecraft:light[level=15]
setblock 348 144 294 minecraft:light[level=15]
setblock 348 144 302 minecraft:light[level=15]
setblock 348 144 310 minecraft:light[level=15]
fill 348 144 312 348 150 313 minecraft:dirt
fill 349 144 311 350 150 311 minecraft:dirt
fill 349 144 314 350 150 314 minecraft:dirt
fill 351 144 312 351 150 313 minecraft:dirt
setblock 353 144 278 minecraft:light[level=12]
setblock 353 144 285 minecraft:light[level=12]
setblock 353 144 292 minecraft:light[level=12]
setblock 353 144 299 minecraft:light[level=12]
setblock 353 144 306 minecraft:light[level=12]
setblock 353 144 313 minecraft:light[level=12]
setblock 356 144 278 minecraft:light[level=15]
setblock 356 144 286 minecraft:light[level=15]
setblock 356 144 294 minecraft:light[level=15]
setblock 356 144 302 minecraft:light[level=15]
setblock 356 144 310 minecraft:light[level=15]
setblock 360 144 278 minecraft:light[level=12]
setblock 360 144 285 minecraft:light[level=12]
setblock 360 144 292 minecraft:light[level=12]
setblock 360 144 299 minecraft:light[level=12]
setblock 360 144 306 minecraft:light[level=12]
setblock 360 144 313 minecraft:light[level=12]
setblock 364 144 278 minecraft:light[level=15]
setblock 364 144 286 minecraft:light[level=15]
setblock 364 144 294 minecraft:light[level=15]
setblock 364 144 302 minecraft:light[level=15]
setblock 364 144 310 minecraft:light[level=15]
setblock 367 144 278 minecraft:light[level=12]
setblock 367 144 285 minecraft:light[level=12]
setblock 367 144 292 minecraft:light[level=12]
setblock 367 144 299 minecraft:light[level=12]
setblock 367 144 306 minecraft:light[level=12]
setblock 367 144 313 minecraft:light[level=12]
fill 371 144 300 371 156 300 minecraft:light_blue_terracotta
fill 329 145 311 329 188 311 minecraft:light_blue_terracotta
fill 337 145 317 337 173 317 minecraft:light_blue_terracotta
fill 340 145 294 341 146 294 minecraft:white_concrete
fill 347 145 275 349 189 275 minecraft:light_blue_terracotta
fill 348 145 314 348 150 314 minecraft:dirt
setblock 350 145 275 minecraft:white_wool
fill 351 145 275 352 221 275 minecraft:light_blue_terracotta
fill 351 145 311 351 150 311 minecraft:dirt
fill 351 145 314 351 150 314 minecraft:dirt
fill 347 146 312 347 150 313 minecraft:dirt
fill 348 146 311 348 150 311 minecraft:dirt
fill 349 146 310 350 150 310 minecraft:dirt
fill 349 146 315 350 150 315 minecraft:dirt
fill 350 146 275 350 221 275 minecraft:light_blue_terracotta
fill 352 146 312 352 150 313 minecraft:dirt
fill 336 147 299 338 150 300 minecraft:packed_mud
fill 337 147 301 337 149 301 minecraft:packed_mud
fill 342 147 275 342 221 275 minecraft:light_blue_terracotta
setblock 343 147 275 minecraft:white_wool
fill 344 147 275 346 162 275 minecraft:light_blue_terracotta
fill 347 147 311 347 150 311 minecraft:dirt
fill 347 147 314 347 150 314 minecraft:dirt
fill 348 147 310 348 150 310 minecraft:dirt
fill 348 147 315 348 150 315 minecraft:dirt
fill 351 147 310 351 150 310 minecraft:dirt
fill 351 147 315 351 150 315 minecraft:dirt
fill 352 147 311 352 150 311 minecraft:dirt
fill 352 147 314 352 150 314 minecraft:dirt
setblock 361 147 317 minecraft:white_wool
fill 362 147 317 363 195 317 minecraft:light_blue_terracotta
fill 336 148 298 338 149 298 minecraft:packed_mud
setblock 336 148 301 minecraft:packed_mud
fill 338 148 301 338 149 301 minecraft:packed_mud
fill 339 148 299 339 149 300 minecraft:packed_mud
fill 343 148 275 343 221 275 minecraft:light_blue_terracotta
fill 346 148 312 346 150 313 minecraft:dirt
fill 347 148 310 347 150 310 minecraft:dirt
fill 347 148 315 347 150 315 minecraft:dirt
fill 349 148 309 350 150 309 minecraft:dirt
fill 349 148 316 350 150 316 minecraft:dirt
fill 352 148 310 352 150 310 minecraft:dirt
fill 352 148 315 352 150 315 minecraft:dirt
fill 353 148 312 353 150 313 minecraft:dirt
fill 361 148 317 361 162 317 minecraft:light_blue_terracotta
setblock 371 148 313 minecraft:white_wool
setblock 335 149 300 minecraft:packed_mud
setblock 339 149 301 minecraft:packed_mud
fill 346 149 311 346 150 311 minecraft:dirt
fill 346 149 314 346 150 314 minecraft:dirt
fill 348 149 309 348 150 309 minecraft:dirt
fill 348 149 316 348 150 316 minecraft:dirt
fill 351 149 309 351 150 309 minecraft:dirt
fill 351 149 316 351 150 316 minecraft:dirt
fill 353 149 311 353 150 311 minecraft:dirt
fill 353 149 314 353 150 314 minecraft:dirt
fill 356 149 307 357 150 307 minecraft:white_concrete
fill 371 149 313 371 218 313 minecraft:light_blue_terracotta
setblock 371 149 314 minecraft:white_wool
fill 371 149 315 371 204 316 minecraft:light_blue_terracotta
setblock 329 150 280 minecraft:white_wool
setblock 332 150 278 minecraft:light[level=12]
setblock 332 150 285 minecraft:light[level=12]
setblock 332 150 292 minecraft:light[level=12]
setblock 332 150 299 minecraft:light[level=12]
setblock 332 150 306 minecraft:light[level=12]
setblock 332 150 313 minecraft:light[level=12]
fill 335 150 300 335 151 301 minecraft:moss_block
fill 336 150 298 336 151 298 minecraft:moss_block
fill 336 150 301 339 150 301 minecraft:moss_block
fill 337 150 297 337 151 297 minecraft:moss_block
setblock 337 150 298 minecraft:packed_mud
fill 338 150 298 338 151 298 minecraft:moss_block
setblock 339 150 278 minecraft:light[level=12]
setblock 339 150 285 minecraft:light[level=12]
setblock 339 150 292 minecraft:light[level=12]
fill 339 150 299 339 151 299 minecraft:moss_block
setblock 339 150 300 minecraft:packed_mud
setblock 339 150 306 minecraft:light[level=12]
setblock 339 150 313 minecraft:light[level=12]
fill 345 150 312 345 150 313 minecraft:dirt
setblock 346 150 278 minecraft:light[level=12]
setblock 346 150 285 minecraft:light[level=12]
setblock 346 150 292 minecraft:light[level=12]
setblock 346 150 299 minecraft:light[level=12]
setblock 346 150 306 minecraft:light[level=12]
setblock 346 150 310 minecraft:dirt
setblock 346 150 315 minecraft:dirt
setblock 347 150 309 minecraft:dirt
setblock 347 150 316 minecraft:dirt
setblock 350 150 308 minecraft:dirt
setblock 352 150 309 minecraft:dirt
setblock 352 150 316 minecraft:dirt
setblock 353 150 278 minecraft:light[level=12]
setblock 353 150 285 minecraft:light[level=12]
setblock 353 150 292 minecraft:light[level=12]
setblock 353 150 299 minecraft:light[level=12]
setblock 353 150 306 minecraft:light[level=12]
setblock 353 150 310 minecraft:dirt
setblock 353 150 315 minecraft:dirt
fill 354 150 312 354 150 313 minecraft:dirt
setblock 360 150 278 minecraft:light[level=12]
setblock 360 150 285 minecraft:light[level=12]
setblock 360 150 292 minecraft:light[level=12]
setblock 360 150 299 minecraft:light[level=12]
setblock 360 150 306 minecraft:light[level=12]
setblock 360 150 313 minecraft:light[level=12]
setblock 367 150 278 minecraft:light[level=12]
setblock 367 150 285 minecraft:light[level=12]
setblock 367 150 292 minecraft:light[level=12]
setblock 367 150 299 minecraft:light[level=12]
setblock 367 150 306 minecraft:light[level=12]
setblock 367 150 313 minecraft:light[level=12]
fill 371 150 314 371 212 314 minecraft:light_blue_terracotta
fill 329 151 280 329 183 280 minecraft:light_blue_terracotta
fill 331 151 275 334 161 275 minecraft:light_blue_terracotta
setblock 335 151 275 minecraft:white_wool
fill 336 151 275 337 217 275 minecraft:light_blue_terracotta
fill 336 151 299 338 151 301 minecraft:moss_block
setblock 337 151 298 minecraft:moss_block
setblock 338 151 297 minecraft:moss_block
setblock 339 151 298 minecraft:moss_block
setblock 339 151 300 minecraft:moss_block
fill 360 151 275 362 184 275 minecraft:light_blue_terracotta
setblock 363 151 275 minecraft:white_wool
fill 364 151 275 364 157 275 minecraft:light_blue_terracotta
setblock 371 151 283 minecraft:white_wool
fill 371 151 284 371 221 284 minecraft:light_blue_terracotta
fill 329 152 275 329 217 275 minecraft:light_blue_terracotta
setblock 329 152 285 minecraft:white_wool
fill 329 152 286 329 153 289 minecraft:light_blue_terracotta
setblock 330 152 275 minecraft:white_wool
setblock 332 152 278 minecraft:light[level=15]
setblock 332 152 286 minecraft:light[level=15]
setblock 332 152 294 minecraft:light[level=15]
setblock 332 152 302 minecraft:light[level=15]
setblock 332 152 310 minecraft:light[level=15]
fill 335 152 275 335 162 275 minecraft:light_blue_terracotta
setblock 340 152 278 minecraft:light[level=15]
setblock 340 152 286 minecraft:light[level=15]
setblock 340 152 294 minecraft:light[level=15]
setblock 340 152 302 minecraft:light[level=15]
setblock 340 152 310 minecraft:light[level=15]
setblock 348 152 278 minecraft:light[level=15]
setblock 348 152 286 minecraft:light[level=15]
setblock 348 152 294 minecraft:light[level=15]
setblock 348 152 302 minecraft:light[level=15]
setblock 348 152 310 minecraft:light[level=15]
setblock 356 152 278 minecraft:light[level=15]
setblock 356 152 286 minecraft:light[level=15]
setblock 356 152 294 minecraft:light[level=15]
setblock 356 152 302 minecraft:light[level=15]
setblock 356 152 310 minecraft:light[level=15]
fill 360 152 296 363 154 296 minecraft:packed_mud
fill 361 152 297 363 155 297 minecraft:packed_mud
fill 362 152 295 363 154 295 minecraft:packed_mud
fill 363 152 275 363 218 275 minecraft:light_blue_terracotta
setblock 364 152 278 minecraft:light[level=15]
setblock 364 152 286 minecraft:light[level=15]
setblock 364 152 294 minecraft:light[level=15]
setblock 364 152 302 minecraft:light[level=15]
setblock 364 152 310 minecraft:light[level=15]
fill 371 152 283 371 221 283 minecraft:light_blue_terracotta
fill 329 153 276 329 219 276 minecraft:light_blue_terracotta
setblock 329 153 277 minecraft:white_wool
fill 329 153 278 329 216 279 minecraft:light_blue_terracotta
fill 329 153 285 329 221 285 minecraft:light_blue_terracotta
setblock 329 153 290 minecraft:white_wool
fill 330 153 275 330 215 275 minecraft:light_blue_terracotta
fill 353 153 317 353 221 317 minecraft:light_blue_terracotta
setblock 354 153 317 minecraft:white_wool
fill 355 153 317 356 162 317 minecraft:light_blue_terracotta
fill 360 153 295 361 153 295 minecraft:packed_mud
fill 360 153 297 360 154 297 minecraft:packed_mud
fill 362 153 298 362 155 298 minecraft:packed_mud
setblock 364 153 296 minecraft:packed_mud
fill 366 153 317 366 221 317 minecraft:light_blue_terracotta
setblock 367 153 317 minecraft:white_wool
fill 368 153 317 370 179 317 minecraft:light_blue_terracotta
fill 329 154 277 329 170 277 minecraft:light_blue_terracotta
fill 329 154 286 329 182 286 minecraft:light_blue_terracotta
setblock 329 154 287 minecraft:white_wool
fill 329 154 288 329 195 290 minecraft:light_blue_terracotta
fill 348 154 312 351 156 313 minecraft:oak_leaves[persistent=true]
fill 349 154 311 350 156 311 minecraft:oak_leaves[persistent=true]
fill 349 154 314 350 156 314 minecraft:oak_leaves[persistent=true]
fill 354 154 317 354 193 317 minecraft:light_blue_terracotta
fill 361 154 295 361 155 295 minecraft:packed_mud
setblock 361 154 298 minecraft:packed_mud
setblock 362 154 294 minecraft:packed_mud
setblock 363 154 298 minecraft:packed_mud
fill 367 154 317 367 221 317 minecraft:light_blue_terracotta
setblock 329 155 283 minecraft:white_wool
fill 329 155 284 329 220 284 minecraft:light_blue_terracotta
fill 329 155 287 329 166 287 minecraft:light_blue_terracotta
setblock 348 155 311 minecraft:oak_leaves[persistent=true]
setblock 348 155 314 minecraft:oak_leaves[persistent=true]
setblock 351 155 311 minecraft:oak_leaves[persistent=true]
setblock 351 155 314 minecraft:oak_leaves[persistent=true]
fill 360 155 295 360 156 297 minecraft:moss_block
fill 361 155 294 363 155 294 minecraft:moss_block
fill 361 155 296 362 155 296 minecraft:packed_mud
fill 361 155 298 361 156 298 minecraft:moss_block
setblock 362 155 295 minecraft:packed_mud
fill 363 155 295 364 155 296 minecraft:moss_block
fill 363 155 298 363 156 298 minecraft:moss_block
fill 329 156 283 329 212 283 minecraft:light_blue_terracotta
setblock 332 156 278 minecraft:light[level=12]
setblock 332 156 285 minecraft:light[level=12]
setblock 332 156 292 minecraft:light[level=12]
setblock 332 156 299 minecraft:light[level=12]
setblock 332 156 306 minecraft:light[level=12]
setblock 332 156 313 minecraft:light[level=12]
setblock 339 156 278 minecraft:light[level=12]
setblock 339 156 285 minecraft:light[level=12]
setblock 339 156 292 minecraft:light[level=12]
setblock 339 156 299 minecraft:light[level=12]
setblock 339 156 306 minecraft:light[level=12]
setblock 339 156 313 minecraft:light[level=12]
setblock 346 156 278 minecraft:light[level=12]
setblock 346 156 285 minecraft:light[level=12]
setblock 346 156 292 minecraft:light[level=12]
setblock 346 156 299 minecraft:light[level=12]
setblock 346 156 306 minecraft:light[level=12]
setblock 346 156 313 minecraft:light[level=12]
setblock 353 156 278 minecraft:light[level=12]
setblock 353 156 285 minecraft:light[level=12]
setblock 353 156 292 minecraft:light[level=12]
setblock 353 156 299 minecraft:light[level=12]
setblock 353 156 306 minecraft:light[level=12]
setblock 353 156 313 minecraft:light[level=12]
setblock 360 156 278 minecraft:light[level=12]
setblock 360 156 285 minecraft:light[level=12]
setblock 360 156 292 minecraft:light[level=12]
setblock 360 156 299 minecraft:light[level=12]
setblock 360 156 306 minecraft:light[level=12]
setblock 360 156 313 minecraft:light[level=12]
fill 361 156 294 362 156 297 minecraft:moss_block
setblock 362 156 298 minecraft:moss_block
fill 363 156 295 363 156 297 minecraft:moss_block
fill 364 156 296 364 156 297 minecraft:moss_block
setblock 365 156 317 minecraft:white_wool
setblock 367 156 278 minecraft:light[level=12]
setblock 367 156 285 minecraft:light[level=12]
setblock 367 156 292 minecraft:light[level=12]
setblock 367 156 299 minecraft:light[level=12]
setblock 367 156 306 minecraft:light[level=12]
setblock 367 156 313 minecraft:light[level=12]
setblock 371 156 276 minecraft:white_wool
fill 365 157 317 365 194 317 minecraft:light_blue_terracotta
fill 371 157 276 371 218 276 minecraft:light_blue_terracotta
setblock 371 157 300 minecraft:white_wool
setblock 356 158 275 minecraft:white_wool
setblock 358 158 317 minecraft:white_wool
setblock 364 158 275 minecraft:white_wool
fill 371 158 300 371 174 300 minecraft:light_blue_terracotta
fill 333 159 317 333 223 317 minecraft:light_blue_terracotta
fill 334 159 317 335 159 317 minecraft:white_wool
fill 356 159 275 356 221 275 minecraft:light_blue_terracotta
fill 358 159 317 358 218 317 minecraft:light_blue_terracotta
fill 364 159 275 364 216 275 minecraft:light_blue_terracotta
setblock 332 160 278 minecraft:light[level=15]
setblock 332 160 286 minecraft:light[level=15]
setblock 332 160 294 minecraft:light[level=15]
setblock 332 160 302 minecraft:light[level=15]
setblock 332 160 310 minecraft:light[level=15]
fill 334 160 317 335 218 317 minecraft:light_blue_terracotta
setblock 340 160 278 minecraft:light[level=15]
setblock 340 160 286 minecraft:light[level=15]
setblock 340 160 294 minecraft:light[level=15]
setblock 340 160 302 minecraft:light[level=15]
setblock 340 160 310 minecraft:light[level=15]
setblock 348 160 278 minecraft:light[level=15]
setblock 348 160 286 minecraft:light[level=15]
setblock 348 160 294 minecraft:light[level=15]
setblock 348 160 302 minecraft:light[level=15]
setblock 348 160 310 minecraft:light[level=15]
setblock 356 160 278 minecraft:light[level=15]
setblock 356 160 286 minecraft:light[level=15]
setblock 356 160 294 minecraft:light[level=15]
setblock 356 160 302 minecraft:light[level=15]
setblock 356 160 310 minecraft:light[level=15]
setblock 364 160 278 minecraft:light[level=15]
setblock 364 160 286 minecraft:light[level=15]
setblock 364 160 294 minecraft:light[level=15]
setblock 364 160 302 minecraft:light[level=15]
setblock 364 160 310 minecraft:light[level=15]
fill 353 161 305 354 162 305 minecraft:white_concrete
fill 331 162 275 333 213 275 minecraft:light_blue_terracotta
setblock 332 162 278 minecraft:light[level=12]
setblock 332 162 285 minecraft:light[level=12]
setblock 332 162 292 minecraft:light[level=12]
setblock 332 162 299 minecraft:light[level=12]
setblock 332 162 306 minecraft:light[level=12]
setblock 332 162 313 minecraft:light[level=12]
fill 333 162 297 333 163 297 minecraft:white_wool
setblock 334 162 275 minecraft:white_wool
setblock 339 162 278 minecraft:light[level=12]
setblock 339 162 285 minecraft:light[level=12]
setblock 339 162 292 minecraft:light[level=12]
setblock 339 162 299 minecraft:light[level=12]
setblock 339 162 306 minecraft:light[level=12]
setblock 339 162 313 minecraft:light[level=12]
setblock 346 162 278 minecraft:light[level=12]
setblock 346 162 285 minecraft:light[level=12]
setblock 346 162 292 minecraft:light[level=12]
setblock 346 162 299 minecraft:light[level=12]
setblock 346 162 306 minecraft:light[level=12]
setblock 346 162 313 minecraft:light[level=12]
setblock 353 162 278 minecraft:light[level=12]
setblock 353 162 285 minecraft:light[level=12]
setblock 353 162 292 minecraft:light[level=12]
setblock 353 162 299 minecraft:light[level=12]
setblock 353 162 306 minecraft:light[level=12]
fill 353 162 310 353 163 310 minecraft:ochre_froglight
setblock 353 162 313 minecraft:light[level=12]
setblock 360 162 278 minecraft:light[level=12]
setblock 360 162 285 minecraft:light[level=12]
setblock 360 162 292 minecraft:light[level=12]
setblock 360 162 299 minecraft:light[level=12]
setblock 360 162 306 minecraft:light[level=12]
setblock 360 162 313 minecraft:light[level=12]
setblock 360 162 317 minecraft:white_wool
setblock 367 162 278 minecraft:light[level=12]
setblock 367 162 285 minecraft:light[level=12]
setblock 367 162 292 minecraft:light[level=12]
setblock 367 162 299 minecraft:light[level=12]
setblock 367 162 306 minecraft:light[level=12]
setblock 367 162 313 minecraft:light[level=12]
setblock 371 162 293 minecraft:white_wool
fill 329 163 297 329 187 299 minecraft:light_blue_terracotta
setblock 329 163 300 minecraft:white_wool
fill 334 163 275 334 221 275 minecraft:light_blue_terracotta
setblock 335 163 275 minecraft:white_wool
setblock 344 163 275 minecraft:white_wool
fill 345 163 275 346 184 275 minecraft:light_blue_terracotta
fill 355 163 317 355 170 317 minecraft:light_blue_terracotta
setblock 356 163 317 minecraft:white_wool
fill 360 163 317 360 221 317 minecraft:light_blue_terracotta
setblock 361 163 317 minecraft:white_wool
setblock 371 163 288 minecraft:white_wool
fill 371 163 289 371 181 291 minecraft:light_blue_terracotta
fill 371 163 293 371 203 293 minecraft:light_blue_terracotta
fill 329 164 300 329 199 300 minecraft:light_blue_terracotta
fill 335 164 275 335 217 275 minecraft:light_blue_terracotta
fill 341 164 293 342 165 294 minecraft:white_wool
fill 344 164 275 344 218 275 minecraft:light_blue_terracotta
fill 353 164 310 353 174 310 minecraft:dirt
fill 356 164 317 356 208 317 minecraft:light_blue_terracotta
fill 361 164 317 361 221 317 minecraft:light_blue_terracotta
fill 371 164 288 371 221 288 minecraft:light_blue_terracotta
fill 333 165 287 335 166 288 minecraft:white_concrete
fill 353 165 311 353 174 311 minecraft:dirt
fill 362 165 299 362 166 299 minecraft:ochre_froglight
setblock 329 166 282 minecraft:white_wool
fill 340 166 317 340 221 317 minecraft:light_blue_terracotta
setblock 341 166 317 minecraft:white_wool
fill 342 166 317 344 181 317 minecraft:light_blue_terracotta
fill 352 166 310 352 174 310 minecraft:dirt
fill 353 166 309 353 174 309 minecraft:dirt
fill 354 166 310 354 174 311 minecraft:dirt
fill 329 167 282 329 215 282 minecraft:light_blue_terracotta
setblock 329 167 287 minecraft:white_wool
fill 341 167 317 341 218 317 minecraft:light_blue_terracotta
fill 352 167 309 352 174 309 minecraft:dirt
fill 352 167 311 352 174 311 minecraft:dirt
fill 354 167 309 354 174 309 minecraft:dirt
fill 362 167 299 362 174 299 minecraft:dirt
fill 329 168 287 329 195 287 minecraft:light_blue_terracotta
setblock 332 168 278 minecraft:light[level=15]
setblock 332 168 285 minecraft:light[level=12]
setblock 332 168 286 minecraft:light[level=15]
setblock 332 168 292 minecraft:light[level=12]
setblock 332 168 294 minecraft:light[level=15]
setblock 332 168 299 minecraft:light[level=12]
setblock 332 168 302 minecraft:light[level=15]
setblock 332 168 306 minecraft:light[level=12]
setblock 332 168 310 minecraft:light[level=15]
setblock 332 168 313 minecraft:light[level=12]
setblock 339 168 278 minecraft:light[level=12]
setblock 339 168 285 minecraft:light[level=12]
setblock 339 168 292 minecraft:light[level=12]
setblock 339 168 299 minecraft:light[level=12]
setblock 339 168 306 minecraft:light[level=12]
setblock 339 168 313 minecraft:light[level=12]
setblock 340 168 278 minecraft:light[level=15]
setblock 340 168 286 minecraft:light[level=15]
setblock 340 168 294 minecraft:light[level=15]
setblock 340 168 302 minecraft:light[level=15]
setblock 340 168 310 minecraft:light[level=15]
setblock 346 168 278 minecraft:light[level=12]
setblock 346 168 285 minecraft:light[level=12]
setblock 346 168 292 minecraft:light[level=12]
setblock 346 168 299 minecraft:light[level=12]
setblock 346 168 306 minecraft:light[level=12]
setblock 346 168 313 minecraft:light[level=12]
setblock 348 168 278 minecraft:light[level=15]
setblock 348 168 286 minecraft:light[level=15]
setblock 348 168 294 minecraft:light[level=15]
setblock 348 168 302 minecraft:light[level=15]
setblock 348 168 310 minecraft:light[level=15]
fill 351 168 310 351 174 311 minecraft:dirt
fill 352 168 312 354 174 312 minecraft:dirt
setblock 353 168 278 minecraft:light[level=12]
setblock 353 168 285 minecraft:light[level=12]
setblock 353 168 292 minecraft:light[level=12]
setblock 353 168 299 minecraft:light[level=12]
setblock 353 168 306 minecraft:light[level=12]
fill 353 168 308 353 174 308 minecraft:dirt
setblock 353 168 313 minecraft:light[level=12]
fill 355 168 310 355 174 311 minecraft:dirt
setblock 356 168 278 minecraft:light[level=15]
setblock 356 168 286 minecraft:light[level=15]
setblock 356 168 294 minecraft:light[level=15]
setblock 356 168 302 minecraft:light[level=15]
setblock 356 168 310 minecraft:light[level=15]
setblock 360 168 278 minecraft:light[level=12]
setblock 360 168 285 minecraft:light[level=12]
setblock 360 168 292 minecraft:light[level=12]
setblock 360 168 299 minecraft:light[level=12]
setblock 360 168 306 minecraft:light[level=12]
setblock 360 168 313 minecraft:light[level=12]
fill 361 168 299 361 174 299 minecraft:dirt
fill 362 168 298 362 174 298 minecraft:dirt
setblock 364 168 278 minecraft:light[level=15]
setblock 364 168 286 minecraft:light[level=15]
setblock 364 168 294 minecraft:light[level=15]
setblock 364 168 302 minecraft:light[level=15]
setblock 364 168 310 minecraft:light[level=15]
setblock 367 168 278 minecraft:light[level=12]
setblock 367 168 285 minecraft:light[level=12]
setblock 367 168 292 minecraft:light[level=12]
setblock 367 168 299 minecraft:light[level=12]
setblock 367 168 306 minecraft:light[level=12]
setblock 367 168 313 minecraft:light[level=12]
setblock 371 168 278 minecraft:white_wool
setblock 329 169 296 minecraft:white_wool
fill 351 169 309 351 174 309 minecraft:dirt
fill 351 169 312 351 174 312 minecraft:dirt
fill 352 169 308 352 174 308 minecraft:dirt
fill 354 169 308 354 174 308 minecraft:dirt
fill 355 169 309 355 174 309 minecraft:dirt
fill 355 169 312 355 174 312 minecraft:dirt
fill 361 169 298 361 174 298 minecraft:dirt
fill 363 169 299 363 174 299 minecraft:dirt
fill 371 169 278 371 206 278 minecraft:light_blue_terracotta
fill 329 170 296 329 221 296 minecraft:light_blue_terracotta
fill 350 170 310 350 174 311 minecraft:dirt
fill 351 170 308 351 174 308 minecraft:dirt
fill 352 170 313 354 174 313 minecraft:dirt
fill 353 170 307 353 174 307 minecraft:dirt
fill 355 170 308 355 174 308 minecraft:dirt
fill 356 170 309 356 174 311 minecraft:dirt
fill 361 170 300 362 174 300 minecraft:dirt
fill 362 170 297 362 174 297 minecraft:dirt
fill 363 170 298 363 174 298 minecraft:dirt
setblock 329 171 277 minecraft:white_wool
fill 349 171 282 349 172 283 minecraft:white_concrete
fill 350 171 309 350 174 309 minecraft:dirt
fill 350 171 312 350 174 312 minecraft:dirt
fill 351 171 313 351 174 313 minecraft:dirt
fill 352 171 307 352 174 307 minecraft:dirt
fill 354 171 307 354 174 307 minecraft:dirt
fill 355 171 313 355 174 313 minecraft:dirt
setblock 355 171 317 minecraft:white_wool
fill 356 171 308 356 174 308 minecraft:dirt
fill 356 171 312 356 174 312 minecraft:dirt
fill 360 171 298 360 174 300 minecraft:dirt
fill 361 171 297 361 174 297 minecraft:dirt
fill 363 171 293 363 173 293 minecraft:white_wool
fill 363 171 297 363 174 297 minecraft:dirt
fill 363 171 300 363 174 300 minecraft:dirt
fill 364 171 292 364 173 292 minecraft:white_wool
setblock 371 171 285 minecraft:white_wool
fill 371 171 286 371 207 286 minecraft:light_blue_terracotta
fill 329 172 277 329 221 277 minecraft:light_blue_terracotta
fill 349 172 309 349 174 311 minecraft:dirt
fill 350 172 308 350 174 308 minecraft:dirt
fill 350 172 313 350 174 313 minecraft:dirt
fill 351 172 307 351 174 307 minecraft:dirt
fill 352 172 314 354 174 314 minecraft:dirt
fill 353 172 306 353 174 306 minecraft:dirt
fill 355 172 307 355 174 307 minecraft:dirt
fill 355 172 317 355 173 317 minecraft:light_blue_terracotta
fill 356 172 313 356 174 313 minecraft:dirt
fill 357 172 309 357 174 311 minecraft:dirt
fill 360 172 297 360 174 297 minecraft:dirt
fill 361 172 291 362 172 293 minecraft:white_wool
fill 361 172 301 363 174 301 minecraft:dirt
fill 362 172 290 362 173 290 minecraft:white_wool
fill 362 172 294 364 173 294 minecraft:white_wool
fill 362 172 296 362 174 296 minecraft:dirt
fill 363 172 291 363 173 292 minecraft:white_wool
fill 364 172 291 366 172 291 minecraft:white_wool
fill 364 172 293 366 173 293 minecraft:white_wool
fill 364 172 298 364 174 300 minecraft:dirt
fill 365 172 292 366 172 292 minecraft:white_wool
fill 371 172 285 371 222 285 minecraft:light_blue_terracotta
fill 349 173 308 349 174 308 minecraft:dirt
fill 349 173 312 349 174 312 minecraft:dirt
fill 350 173 307 350 174 307 minecraft:dirt
fill 351 173 306 352 174 306 minecraft:dirt
fill 351 173 314 351 174 314 minecraft:dirt
fill 354 173 306 355 174 306 minecraft:dirt
fill 355 173 314 355 174 314 minecraft:dirt
fill 356 173 307 356 174 307 minecraft:dirt
fill 357 173 308 357 174 308 minecraft:dirt
fill 357 173 312 357 174 312 minecraft:dirt
fill 359 173 298 359 174 300 minecraft:dirt
fill 360 173 301 360 174 301 minecraft:dirt
fill 361 173 296 361 174 296 minecraft:dirt
fill 362 173 291 362 173 293 minecraft:white_wool
fill 363 173 290 364 173 290 minecraft:white_wool
fill 363 173 296 363 174 296 minecraft:dirt
fill 364 173 291 365 173 291 minecraft:white_wool
fill 364 173 297 364 174 297 minecraft:dirt
setblock 365 173 292 minecraft:white_wool
setblock 365 173 294 minecraft:white_wool
setblock 329 174 281 minecraft:white_wool
setblock 332 174 278 minecraft:light[level=12]
setblock 332 174 285 minecraft:light[level=12]
fill 332 174 289 333 175 290 minecraft:white_wool
setblock 332 174 292 minecraft:light[level=12]
setblock 332 174 299 minecraft:light[level=12]
setblock 332 174 306 minecraft:light[level=12]
setblock 332 174 313 minecraft:light[level=12]
setblock 337 174 317 minecraft:white_wool
setblock 339 174 278 minecraft:light[level=12]
setblock 339 174 285 minecraft:light[level=12]
setblock 339 174 292 minecraft:light[level=12]
setblock 339 174 299 minecraft:light[level=12]
setblock 339 174 306 minecraft:light[level=12]
setblock 339 174 313 minecraft:light[level=12]
fill 343 174 305 343 175 305 minecraft:ochre_froglight
setblock 346 174 278 minecraft:light[level=12]
setblock 346 174 285 minecraft:light[level=12]
setblock 346 174 292 minecraft:light[level=12]
setblock 346 174 299 minecraft:light[level=12]
setblock 346 174 306 minecraft:light[level=12]
setblock 346 174 313 minecraft:light[level=12]
fill 348 174 309 348 174 311 minecraft:dirt
setblock 349 174 307 minecraft:dirt
setblock 349 174 313 minecraft:dirt
setblock 350 174 306 minecraft:dirt
setblock 350 174 314 minecraft:dirt
fill 351 174 315 355 174 315 minecraft:dirt
setblock 353 174 278 minecraft:light[level=12]
setblock 353 174 285 minecraft:light[level=12]
setblock 353 174 292 minecraft:light[level=12]
setblock 353 174 299 minecraft:light[level=12]
setblock 353 174 305 minecraft:dirt
setblock 355 174 317 minecraft:white_wool
setblock 356 174 306 minecraft:dirt
setblock 356 174 314 minecraft:dirt
setblock 357 174 307 minecraft:dirt
setblock 357 174 313 minecraft:dirt
fill 358 174 309 358 174 311 minecraft:dirt
setblock 359 174 297 minecraft:dirt
setblock 359 174 301 minecraft:dirt
setblock 360 174 278 minecraft:light[level=12]
setblock 360 174 285 minecraft:light[level=12]
setblock 360 174 292 minecraft:light[level=12]
setblock 360 174 296 minecraft:dirt
setblock 360 174 306 minecraft:light[level=12]
setblock 360 174 313 minecraft:light[level=12]
fill 361 174 302 363 174 302 minecraft:dirt
setblock 364 174 293 minecraft:white_wool
setblock 364 174 296 minecraft:dirt
setblock 364 174 301 minecraft:dirt
fill 365 174 298 365 174 300 minecraft:dirt
setblock 367 174 278 minecraft:light[level=12]
setblock 367 174 285 minecraft:light[level=12]
setblock 367 174 292 minecraft:light[level=12]
setblock 367 174 299 minecraft:light[level=12]
setblock 367 174 306 minecraft:light[level=12]
setblock 367 174 313 minecraft:light[level=12]
fill 329 175 281 329 218 281 minecraft:light_blue_terracotta
fill 337 175 317 337 218 317 minecraft:light_blue_terracotta
fill 353 175 310 353 178 310 minecraft:white_concrete
fill 355 175 317 355 216 317 minecraft:light_blue_terracotta
fill 362 175 299 362 177 299 minecraft:white_concrete
fill 371 175 297 371 221 297 minecraft:light_blue_terracotta
setblock 371 175 298 minecraft:white_wool
fill 371 175 299 371 221 299 minecraft:light_blue_terracotta
setblock 371 175 300 minecraft:white_wool
setblock 332 176 278 minecraft:light[level=15]
setblock 332 176 286 minecraft:light[level=15]
setblock 332 176 294 minecraft:light[level=15]
setblock 332 176 302 minecraft:light[level=15]
setblock 332 176 310 minecraft:light[level=15]
setblock 340 176 278 minecraft:light[level=15]
setblock 340 176 286 minecraft:light[level=15]
setblock 340 176 294 minecraft:light[level=15]
setblock 340 176 302 minecraft:light[level=15]
setblock 340 176 310 minecraft:light[level=15]
fill 343 176 305 343 184 305 minecraft:dirt
setblock 348 176 278 minecraft:light[level=15]
setblock 348 176 286 minecraft:light[level=15]
setblock 348 176 294 minecraft:light[level=15]
setblock 348 176 302 minecraft:light[level=15]
setblock 348 176 310 minecraft:light[level=15]
setblock 356 176 278 minecraft:light[level=15]
setblock 356 176 286 minecraft:light[level=15]
setblock 356 176 294 minecraft:light[level=15]
setblock 356 176 302 minecraft:light[level=15]
setblock 356 176 310 minecraft:light[level=15]
setblock 364 176 278 minecraft:light[level=15]
setblock 364 176 286 minecraft:light[level=15]
setblock 364 176 294 minecraft:light[level=15]
setblock 364 176 302 minecraft:light[level=15]
setblock 364 176 310 minecraft:light[level=15]
fill 371 176 298 371 221 298 minecraft:light_blue_terracotta
fill 371 176 300 371 195 300 minecraft:light_blue_terracotta
fill 342 177 305 342 184 305 minecraft:dirt
fill 343 177 306 343 184 306 minecraft:dirt
fill 366 177 296 367 178 296 minecraft:white_wool
fill 342 178 306 342 184 306 minecraft:dirt
fill 343 178 304 343 184 304 minecraft:dirt
fill 344 178 305 344 184 305 minecraft:dirt
fill 352 178 309 352 180 311 minecraft:oak_leaves[persistent=true]
fill 353 178 309 354 180 309 minecraft:oak_leaves[persistent=true]
fill 353 178 311 353 180 312 minecraft:oak_leaves[persistent=true]
fill 354 178 310 354 180 311 minecraft:oak_leaves[persistent=true]
fill 355 178 310 355 180 310 minecraft:oak_leaves[persistent=true]
fill 360 178 298 363 180 299 minecraft:oak_leaves[persistent=true]
fill 361 178 297 362 180 297 minecraft:oak_leaves[persistent=true]
fill 361 178 300 363 180 300 minecraft:oak_leaves[persistent=true]
fill 341 179 305 341 184 306 minecraft:dirt
fill 342 179 304 342 184 304 minecraft:dirt
fill 342 179 307 343 184 307 minecraft:dirt
fill 344 179 304 344 184 304 minecraft:dirt
fill 344 179 306 344 184 306 minecraft:dirt
fill 345 179 308 349 179 310 minecraft:white_wool
fill 346 179 307 349 180 307 minecraft:white_wool
fill 346 179 311 348 180 311 minecraft:white_wool
fill 349 179 283 349 180 283 minecraft:white_wool
fill 350 179 308 350 179 309 minecraft:white_wool
fill 351 179 309 351 179 311 minecraft:oak_leaves[persistent=true]
setblock 352 179 312 minecraft:oak_leaves[persistent=true]
setblock 353 179 308 minecraft:oak_leaves[persistent=true]
fill 353 179 310 353 180 310 minecraft:oak_leaves[persistent=true]
setblock 354 179 312 minecraft:oak_leaves[persistent=true]
setblock 355 179 309 minecraft:oak_leaves[persistent=true]
setblock 355 179 311 minecraft:oak_leaves[persistent=true]
setblock 360 179 300 minecraft:oak_leaves[persistent=true]
setblock 362 179 301 minecraft:oak_leaves[persistent=true]
setblock 363 179 297 minecraft:oak_leaves[persistent=true]
fill 364 179 298 364 179 299 minecraft:oak_leaves[persistent=true]
setblock 332 180 278 minecraft:light[level=12]
setblock 332 180 285 minecraft:light[level=12]
setblock 332 180 292 minecraft:light[level=12]
setblock 332 180 299 minecraft:light[level=12]
setblock 332 180 306 minecraft:light[level=12]
setblock 332 180 313 minecraft:light[level=12]
setblock 339 180 278 minecraft:light[level=12]
setblock 339 180 285 minecraft:light[level=12]
setblock 339 180 292 minecraft:light[level=12]
setblock 339 180 299 minecraft:light[level=12]
setblock 339 180 306 minecraft:light[level=12]
setblock 339 180 313 minecraft:light[level=12]
fill 341 180 304 341 184 304 minecraft:dirt
fill 343 180 303 343 184 303 minecraft:dirt
fill 344 180 307 344 184 307 minecraft:dirt
fill 345 180 305 345 184 305 minecraft:dirt
fill 345 180 309 349 180 310 minecraft:white_wool
setblock 346 180 278 minecraft:light[level=12]
setblock 346 180 285 minecraft:light[level=12]
setblock 346 180 292 minecraft:light[level=12]
setblock 346 180 299 minecraft:light[level=12]
setblock 346 180 306 minecraft:light[level=12]
fill 346 180 308 349 180 308 minecraft:white_wool
setblock 346 180 313 minecraft:light[level=12]
fill 347 180 306 348 180 306 minecraft:white_wool
setblock 353 180 278 minecraft:light[level=12]
setblock 353 180 285 minecraft:light[level=12]
setblock 353 180 292 minecraft:light[level=12]
setblock 353 180 299 minecraft:light[level=12]
setblock 353 180 306 minecraft:light[level=12]
setblock 353 180 313 minecraft:light[level=12]
setblock 360 180 278 minecraft:light[level=12]
setblock 360 180 285 minecraft:light[level=12]
setblock 360 180 292 minecraft:light[level=12]
setblock 360 180 306 minecraft:light[level=12]
setblock 360 180 313 minecraft:light[level=12]
setblock 367 180 278 minecraft:light[level=12]
setblock 367 180 285 minecraft:light[level=12]
setblock 367 180 292 minecraft:light[level=12]
setblock 367 180 299 minecraft:light[level=12]
setblock 367 180 306 minecraft:light[level=12]
setblock 367 180 313 minecraft:light[level=12]
setblock 368 180 317 minecraft:white_wool
fill 369 180 317 370 193 317 minecraft:light_blue_terracotta
setblock 329 181 308 minecraft:white_wool
fill 329 181 309 329 218 309 minecraft:light_blue_terracotta
fill 340 181 305 340 184 306 minecraft:dirt
fill 341 181 303 342 184 303 minecraft:dirt
fill 341 181 307 341 184 307 minecraft:dirt
fill 342 181 308 343 184 308 minecraft:dirt
fill 344 181 303 344 184 303 minecraft:dirt
fill 345 181 304 345 184 304 minecraft:dirt
fill 345 181 306 345 184 306 minecraft:dirt
fill 368 181 317 368 221 317 minecraft:light_blue_terracotta
fill 329 182 308 329 221 308 minecraft:light_blue_terracotta
fill 340 182 304 340 184 304 minecraft:dirt
fill 340 182 307 340 184 307 minecraft:dirt
fill 341 182 308 341 184 308 minecraft:dirt
setblock 342 182 317 minecraft:white_wool
fill 343 182 302 343 184 302 minecraft:dirt
fill 343 182 317 344 221 317 minecraft:light_blue_terracotta
fill 344 182 308 344 184 308 minecraft:dirt
fill 345 182 303 345 184 303 minecraft:dirt
fill 345 182 307 345 184 307 minecraft:dirt
setblock 371 182 289 minecraft:white_wool
fill 371 182 290 371 200 291 minecraft:light_blue_terracotta
setblock 329 183 286 minecraft:white_wool
fill 339 183 305 339 184 306 minecraft:dirt
fill 340 183 303 340 184 303 minecraft:dirt
fill 341 183 302 342 184 302 minecraft:dirt
fill 342 183 309 343 184 309 minecraft:dirt
fill 342 183 317 342 219 317 minecraft:light_blue_terracotta
fill 344 183 302 344 184 302 minecraft:dirt
fill 345 183 308 345 184 308 minecraft:dirt
fill 346 183 304 346 184 307 minecraft:dirt
fill 371 183 289 371 221 289 minecraft:light_blue_terracotta
setblock 329 184 280 minecraft:white_wool
fill 329 184 286 329 221 286 minecraft:light_blue_terracotta
setblock 332 184 278 minecraft:light[level=15]
setblock 332 184 286 minecraft:light[level=15]
setblock 332 184 294 minecraft:light[level=15]
setblock 332 184 302 minecraft:light[level=15]
setblock 332 184 310 minecraft:light[level=15]
setblock 339 184 304 minecraft:dirt
setblock 339 184 307 minecraft:dirt
setblock 340 184 278 minecraft:light[level=15]
setblock 340 184 286 minecraft:light[level=15]
setblock 340 184 294 minecraft:light[level=15]
setblock 340 184 302 minecraft:dirt
setblock 340 184 308 minecraft:dirt
setblock 340 184 310 minecraft:light[level=15]
setblock 341 184 309 minecraft:dirt
setblock 344 184 309 minecraft:dirt
setblock 345 184 302 minecraft:dirt
setblock 345 184 317 minecraft:white_wool
setblock 346 184 303 minecraft:dirt
fill 346 184 317 346 221 317 minecraft:light_blue_terracotta
setblock 348 184 278 minecraft:light[level=15]
setblock 348 184 286 minecraft:light[level=15]
setblock 348 184 294 minecraft:light[level=15]
setblock 348 184 302 minecraft:light[level=15]
setblock 348 184 310 minecraft:light[level=15]
setblock 356 184 278 minecraft:light[level=15]
setblock 356 184 286 minecraft:light[level=15]
setblock 356 184 294 minecraft:light[level=15]
setblock 356 184 302 minecraft:light[level=15]
setblock 356 184 310 minecraft:light[level=15]
setblock 364 184 278 minecraft:light[level=15]
setblock 364 184 286 minecraft:light[level=15]
setblock 364 184 294 minecraft:light[level=15]
setblock 364 184 302 minecraft:light[level=15]
setblock 364 184 310 minecraft:light[level=15]
fill 367 184 293 367 185 293 minecraft:ochre_froglight
fill 329 185 280 329 221 280 minecraft:light_blue_terracotta
fill 343 185 305 343 187 305 minecraft:white_concrete
setblock 345 185 275 minecraft:white_wool
fill 345 185 317 345 221 317 minecraft:light_blue_terracotta
fill 346 185 275 346 221 275 minecraft:light_blue_terracotta
setblock 360 185 275 minecraft:white_wool
fill 360 185 286 360 187 286 minecraft:white_wool
fill 361 185 275 362 218 275 minecraft:light_blue_terracotta
setblock 332 186 278 minecraft:light[level=12]
setblock 332 186 285 minecraft:light[level=12]
setblock 332 186 292 minecraft:light[level=12]
setblock 332 186 299 minecraft:light[level=12]
setblock 332 186 306 minecraft:light[level=12]
setblock 332 186 313 minecraft:light[level=12]
setblock 339 186 278 minecraft:light[level=12]
setblock 339 186 285 minecraft:light[level=12]
setblock 339 186 292 minecraft:light[level=12]
setblock 339 186 299 minecraft:light[level=12]
setblock 339 186 306 minecraft:light[level=12]
setblock 339 186 313 minecraft:light[level=12]
fill 345 186 275 345 217 275 minecraft:light_blue_terracotta
setblock 346 186 278 minecraft:light[level=12]
setblock 346 186 285 minecraft:light[level=12]
setblock 346 186 292 minecraft:light[level=12]
setblock 346 186 299 minecraft:light[level=12]
setblock 346 186 306 minecraft:light[level=12]
setblock 346 186 313 minecraft:light[level=12]
setblock 353 186 278 minecraft:light[level=12]
setblock 353 186 285 minecraft:light[level=12]
setblock 353 186 292 minecraft:light[level=12]
setblock 353 186 299 minecraft:light[level=12]
setblock 353 186 306 minecraft:light[level=12]
setblock 353 186 313 minecraft:light[level=12]
fill 357 186 285 362 186 285 minecraft:white_wool
fill 358 186 284 362 186 284 minecraft:white_wool
fill 358 186 286 359 186 288 minecraft:white_wool
fill 360 186 275 360 218 275 minecraft:light_blue_terracotta
setblock 360 186 278 minecraft:light[level=12]
fill 360 186 287 361 187 287 minecraft:white_wool
setblock 360 186 292 minecraft:light[level=12]
setblock 360 186 299 minecraft:light[level=12]
setblock 360 186 306 minecraft:light[level=12]
setblock 360 186 313 minecraft:light[level=12]
fill 361 186 286 362 186 286 minecraft:white_wool
setblock 367 186 278 minecraft:light[level=12]
setblock 367 186 285 minecraft:light[level=12]
setblock 367 186 292 minecraft:light[level=12]
fill 367 186 293 367 196 293 minecraft:dirt
setblock 367 186 299 minecraft:light[level=12]
setblock 367 186 306 minecraft:light[level=12]
setblock 367 186 313 minecraft:light[level=12]
setblock 371 186 307 minecraft:white_wool
fill 340 187 285 343 189 285 minecraft:packed_mud
fill 341 187 286 342 190 286 minecraft:packed_mud
fill 342 187 284 342 189 284 minecraft:packed_mud
fill 357 187 286 359 187 286 minecraft:white_wool
fill 358 187 284 361 187 285 minecraft:white_wool
fill 358 187 287 359 187 287 minecraft:white_wool
fill 359 187 283 360 187 283 minecraft:white_wool
fill 359 187 288 361 187 288 minecraft:white_wool
setblock 361 187 286 minecraft:white_wool
fill 366 187 293 366 196 293 minecraft:dirt
fill 367 187 294 367 196 294 minecraft:dirt
setblock 371 187 282 minecraft:white_wool
fill 371 187 307 371 217 307 minecraft:light_blue_terracotta
fill 329 188 297 329 222 297 minecraft:light_blue_terracotta
setblock 329 188 298 minecraft:white_wool
fill 329 188 299 329 221 299 minecraft:light_blue_terracotta
fill 340 188 286 340 190 286 minecraft:packed_mud
fill 341 188 284 341 190 284 minecraft:packed_mud
fill 341 188 287 342 190 287 minecraft:packed_mud
fill 341 188 305 344 190 306 minecraft:oak_leaves[persistent=true]
fill 342 188 304 344 190 304 minecraft:oak_leaves[persistent=true]
fill 342 188 307 343 190 307 minecraft:oak_leaves[persistent=true]
setblock 343 188 284 minecraft:packed_mud
fill 343 188 286 343 190 286 minecraft:packed_mud
fill 359 188 285 359 188 286 minecraft:white_wool
fill 362 188 286 363 189 286 minecraft:white_concrete
fill 366 188 292 367 196 292 minecraft:dirt
fill 366 188 294 366 196 294 minecraft:dirt
fill 368 188 293 368 196 293 minecraft:dirt
fill 371 188 282 371 195 282 minecraft:light_blue_terracotta
fill 329 189 298 329 221 298 minecraft:light_blue_terracotta
setblock 329 189 311 minecraft:white_wool
fill 340 189 284 340 190 284 minecraft:packed_mud
setblock 341 189 283 minecraft:packed_mud
setblock 341 189 304 minecraft:oak_leaves[persistent=true]
setblock 341 189 307 minecraft:oak_leaves[persistent=true]
fill 342 189 303 343 189 303 minecraft:oak_leaves[persistent=true]
setblock 343 189 287 minecraft:packed_mud
setblock 344 189 307 minecraft:oak_leaves[persistent=true]
setblock 345 189 305 minecraft:oak_leaves[persistent=true]
fill 365 189 293 365 196 294 minecraft:dirt
fill 366 189 295 367 196 295 minecraft:dirt
fill 368 189 292 368 196 292 minecraft:dirt
fill 368 189 294 368 196 294 minecraft:dirt
fill 329 190 291 329 218 292 minecraft:light_blue_terracotta
setblock 329 190 293 minecraft:white_wool
fill 329 190 294 329 222 294 minecraft:light_blue_terracotta
setblock 329 190 310 minecraft:white_wool
fill 329 190 311 329 222 311 minecraft:light_blue_terracotta
fill 336 190 301 337 191 302 minecraft:white_wool
setblock 339 190 285 minecraft:moss_block
fill 340 190 285 342 190 285 minecraft:packed_mud
fill 340 190 287 340 191 287 minecraft:moss_block
fill 341 190 283 341 191 283 minecraft:moss_block
fill 342 190 284 343 191 284 minecraft:moss_block
fill 343 190 285 343 191 285 minecraft:moss_block
fill 343 190 287 343 191 287 minecraft:moss_block
fill 347 190 275 348 221 275 minecraft:light_blue_terracotta
fill 347 190 317 349 217 317 minecraft:light_blue_terracotta
setblock 349 190 275 minecraft:white_wool
setblock 350 190 317 minecraft:white_wool
fill 365 190 292 365 196 292 minecraft:dirt
fill 365 190 295 365 196 295 minecraft:dirt
fill 366 190 291 367 196 291 minecraft:dirt
fill 368 190 295 368 196 295 minecraft:dirt
fill 369 190 293 369 196 294 minecraft:dirt
fill 329 191 293 329 215 293 minecraft:light_blue_terracotta
fill 329 191 310 329 218 310 minecraft:light_blue_terracotta
fill 333 191 290 334 192 291 minecraft:white_concrete
setblock 338 191 317 minecraft:white_wool
fill 339 191 286 343 191 286 minecraft:moss_block
fill 340 191 284 341 191 285 minecraft:moss_block
fill 340 191 304 340 192 304 minecraft:white_concrete
fill 341 191 287 342 191 287 minecraft:moss_block
setblock 342 191 285 minecraft:moss_block
fill 349 191 275 349 221 275 minecraft:light_blue_terracotta
fill 350 191 317 350 221 317 minecraft:light_blue_terracotta
fill 364 191 292 364 196 294 minecraft:dirt
fill 365 191 291 365 196 291 minecraft:dirt
fill 366 191 296 367 196 296 minecraft:dirt
fill 368 191 291 368 196 291 minecraft:dirt
fill 369 191 292 369 196 292 minecraft:dirt
fill 369 191 295 369 196 295 minecraft:dirt
setblock 332 192 278 minecraft:light[level=15]
setblock 332 192 285 minecraft:light[level=12]
setblock 332 192 286 minecraft:light[level=15]
setblock 332 192 292 minecraft:light[level=12]
setblock 332 192 294 minecraft:light[level=15]
setblock 332 192 299 minecraft:light[level=12]
setblock 332 192 302 minecraft:light[level=15]
setblock 332 192 306 minecraft:light[level=12]
setblock 332 192 310 minecraft:light[level=15]
setblock 332 192 313 minecraft:light[level=12]
fill 338 192 317 338 218 317 minecraft:light_blue_terracotta
setblock 339 192 278 minecraft:light[level=12]
setblock 339 192 285 minecraft:light[level=12]
setblock 339 192 292 minecraft:light[level=12]
setblock 339 192 299 minecraft:light[level=12]
setblock 339 192 306 minecraft:light[level=12]
setblock 339 192 313 minecraft:light[level=12]
setblock 340 192 278 minecraft:light[level=15]
setblock 340 192 286 minecraft:light[level=15]
setblock 340 192 294 minecraft:light[level=15]
setblock 340 192 302 minecraft:light[level=15]
setblock 340 192 310 minecraft:light[level=15]
setblock 346 192 278 minecraft:light[level=12]
setblock 346 192 285 minecraft:light[level=12]
setblock 346 192 292 minecraft:light[level=12]
setblock 346 192 299 minecraft:light[level=12]
setblock 346 192 306 minecraft:light[level=12]
setblock 346 192 313 minecraft:light[level=12]
setblock 348 192 278 minecraft:light[level=15]
setblock 348 192 286 minecraft:light[level=15]
setblock 348 192 294 minecraft:light[level=15]
setblock 348 192 302 minecraft:light[level=15]
setblock 348 192 310 minecraft:light[level=15]
fill 350 192 283 350 193 283 minecraft:ochre_froglight
setblock 353 192 278 minecraft:light[level=12]
setblock 353 192 285 minecraft:light[level=12]
setblock 353 192 292 minecraft:light[level=12]
setblock 353 192 299 minecraft:light[level=12]
setblock 353 192 306 minecraft:light[level=12]
setblock 353 192 313 minecraft:light[level=12]
setblock 356 192 278 minecraft:light[level=15]
setblock 356 192 286 minecraft:light[level=15]
setblock 356 192 294 minecraft:light[level=15]
setblock 356 192 302 minecraft:light[level=15]
fill 356 192 304 356 193 304 minecraft:white_wool
setblock 356 192 310 minecraft:light[level=15]
setblock 360 192 278 minecraft:light[level=12]
setblock 360 192 285 minecraft:light[level=12]
setblock 360 192 292 minecraft:light[level=12]
setblock 360 192 299 minecraft:light[level=12]
setblock 360 192 306 minecraft:light[level=12]
setblock 360 192 313 minecraft:light[level=12]
setblock 364 192 278 minecraft:light[level=15]
setblock 364 192 286 minecraft:light[level=15]
fill 364 192 291 364 196 291 minecraft:dirt
fill 364 192 295 364 196 295 minecraft:dirt
setblock 364 192 302 minecraft:light[level=15]
setblock 364 192 310 minecraft:light[level=15]
fill 365 192 296 365 196 296 minecraft:dirt
fill 366 192 290 368 196 290 minecraft:dirt
setblock 367 192 278 minecraft:light[level=12]
setblock 367 192 285 minecraft:light[level=12]
setblock 367 192 299 minecraft:light[level=12]
setblock 367 192 306 minecraft:light[level=12]
setblock 367 192 313 minecraft:light[level=12]
fill 368 192 296 368 196 296 minecraft:dirt
fill 369 192 291 369 196 291 minecraft:dirt
fill 370 192 293 370 196 294 minecraft:dirt
fill 363 193 292 363 196 294 minecraft:dirt
fill 364 193 296 364 196 296 minecraft:dirt
fill 365 193 290 365 196 290 minecraft:dirt
fill 366 193 297 367 196 297 minecraft:dirt
fill 369 193 290 369 196 290 minecraft:dirt
fill 369 193 296 369 196 296 minecraft:dirt
fill 370 193 291 370 196 292 minecraft:dirt
fill 370 193 295 370 196 295 minecraft:dirt
fill 350 194 283 350 202 283 minecraft:dirt
setblock 354 194 317 minecraft:white_wool
fill 363 194 291 363 196 291 minecraft:dirt
fill 363 194 295 363 196 295 minecraft:dirt
fill 364 194 290 364 196 290 minecraft:dirt
fill 365 194 297 365 196 297 minecraft:dirt
fill 366 194 289 368 196 289 minecraft:dirt
fill 368 194 297 368 196 297 minecraft:dirt
fill 369 194 317 369 224 317 minecraft:light_blue_terracotta
fill 370 194 296 370 196 296 minecraft:dirt
setblock 370 194 317 minecraft:white_wool
fill 350 195 284 350 202 284 minecraft:dirt
fill 354 195 317 354 221 317 minecraft:light_blue_terracotta
fill 362 195 292 362 196 294 minecraft:dirt
fill 363 195 290 363 196 290 minecraft:dirt
fill 363 195 296 363 196 296 minecraft:dirt
fill 364 195 289 365 196 289 minecraft:dirt
fill 364 195 297 364 196 297 minecraft:dirt
setblock 365 195 317 minecraft:white_wool
fill 366 195 298 367 196 298 minecraft:dirt
fill 369 195 289 369 196 289 minecraft:dirt
fill 369 195 297 369 196 297 minecraft:dirt
fill 370 195 290 370 196 290 minecraft:dirt
fill 370 195 317 370 217 317 minecraft:light_blue_terracotta
fill 329 196 287 329 196 288 minecraft:white_wool
fill 329 196 289 329 212 290 minecraft:light_blue_terracotta
fill 351 196 283 351 202 284 minecraft:dirt
fill 360 196 310 361 197 310 minecraft:white_concrete
setblock 362 196 291 minecraft:dirt
setblock 362 196 295 minecraft:dirt
fill 362 196 317 362 218 317 minecraft:light_blue_terracotta
setblock 363 196 297 minecraft:dirt
setblock 363 196 317 minecraft:white_wool
fill 365 196 288 368 196 288 minecraft:dirt
setblock 365 196 298 minecraft:dirt
fill 365 196 317 365 221 317 minecraft:light_blue_terracotta
setblock 366 196 275 minecraft:white_wool
fill 368 196 298 369 196 298 minecraft:dirt
setblock 370 196 289 minecraft:dirt
setblock 370 196 297 minecraft:dirt
setblock 371 196 282 minecraft:white_wool
setblock 371 196 300 minecraft:white_wool
fill 329 197 287 329 219 288 minecraft:light_blue_terracotta
setblock 339 197 317 minecraft:white_wool
fill 349 197 283 349 202 284 minecraft:dirt
fill 350 197 282 350 202 282 minecraft:dirt
fill 363 197 317 363 221 317 minecraft:light_blue_terracotta
fill 366 197 275 366 221 275 minecraft:light_blue_terracotta
fill 367 197 293 367 199 293 minecraft:white_concrete
fill 371 197 282 371 217 282 minecraft:light_blue_terracotta
fill 371 197 300 371 217 300 minecraft:light_blue_terracotta
setblock 332 198 278 minecraft:light[level=12]
setblock 332 198 285 minecraft:light[level=12]
setblock 332 198 292 minecraft:light[level=12]
setblock 332 198 299 minecraft:light[level=12]
setblock 332 198 306 minecraft:light[level=12]
setblock 332 198 313 minecraft:light[level=12]
setblock 339 198 278 minecraft:light[level=12]
setblock 339 198 285 minecraft:light[level=12]
setblock 339 198 292 minecraft:light[level=12]
setblock 339 198 299 minecraft:light[level=12]
setblock 339 198 306 minecraft:light[level=12]
setblock 339 198 313 minecraft:light[level=12]
fill 339 198 317 339 221 317 minecraft:light_blue_terracotta
setblock 346 198 278 minecraft:light[level=12]
setblock 346 198 285 minecraft:light[level=12]
setblock 346 198 292 minecraft:light[level=12]
setblock 346 198 299 minecraft:light[level=12]
fill 346 198 306 346 199 307 minecraft:white_wool
setblock 346 198 313 minecraft:light[level=12]
fill 349 198 282 349 202 282 minecraft:dirt
fill 349 198 285 351 202 285 minecraft:dirt
fill 351 198 282 351 202 282 minecraft:dirt
fill 352 198 283 352 202 284 minecraft:dirt
setblock 353 198 278 minecraft:light[level=12]
setblock 353 198 285 minecraft:light[level=12]
setblock 353 198 292 minecraft:light[level=12]
setblock 353 198 299 minecraft:light[level=12]
setblock 353 198 306 minecraft:light[level=12]
setblock 353 198 313 minecraft:light[level=12]
setblock 360 198 278 minecraft:light[level=12]
setblock 360 198 285 minecraft:light[level=12]
setblock 360 198 292 minecraft:light[level=12]
setblock 360 198 299 minecraft:light[level=12]
setblock 360 198 306 minecraft:light[level=12]
setblock 360 198 313 minecraft:light[level=12]
setblock 367 198 278 minecraft:light[level=12]
setblock 367 198 285 minecraft:light[level=12]
setblock 367 198 292 minecraft:light[level=12]
setblock 367 198 299 minecraft:light[level=12]
setblock 367 198 306 minecraft:light[level=12]
setblock 367 198 313 minecraft:light[level=12]
fill 348 199 283 348 202 284 minecraft:dirt
fill 350 199 281 350 202 281 minecraft:dirt
fill 352 199 282 352 202 282 minecraft:dirt
fill 352 199 285 352 202 285 minecraft:dirt
setblock 329 200 300 minecraft:white_wool
setblock 332 200 278 minecraft:light[level=15]
setblock 332 200 286 minecraft:light[level=15]
setblock 332 200 294 minecraft:light[level=15]
setblock 332 200 302 minecraft:light[level=15]
setblock 332 200 310 minecraft:light[level=15]
setblock 340 200 278 minecraft:light[level=15]
setblock 340 200 286 minecraft:light[level=15]
setblock 340 200 294 minecraft:light[level=15]
setblock 340 200 302 minecraft:light[level=15]
setblock 340 200 310 minecraft:light[level=15]
setblock 348 200 278 minecraft:light[level=15]
fill 348 200 282 348 202 282 minecraft:dirt
fill 348 200 285 348 202 285 minecraft:dirt
setblock 348 200 286 minecraft:light[level=15]
setblock 348 200 294 minecraft:light[level=15]
setblock 348 200 302 minecraft:light[level=15]
setblock 348 200 310 minecraft:light[level=15]
fill 349 200 281 349 202 281 minecraft:dirt
fill 349 200 286 351 202 286 minecraft:dirt
fill 351 200 281 351 202 281 minecraft:dirt
fill 353 200 283 353 202 284 minecraft:dirt
setblock 356 200 278 minecraft:light[level=15]
setblock 356 200 286 minecraft:light[level=15]
setblock 356 200 294 minecraft:light[level=15]
setblock 356 200 302 minecraft:light[level=15]
setblock 356 200 310 minecraft:light[level=15]
setblock 364 200 278 minecraft:light[level=15]
setblock 364 200 286 minecraft:light[level=15]
setblock 364 200 294 minecraft:light[level=15]
setblock 364 200 302 minecraft:light[level=15]
setblock 364 200 310 minecraft:light[level=15]
fill 365 200 293 368 202 294 minecraft:oak_leaves[persistent=true]
fill 366 200 292 368 202 292 minecraft:oak_leaves[persistent=true]
fill 366 200 295 367 202 295 minecraft:oak_leaves[persistent=true]
fill 329 201 300 329 209 300 minecraft:light_blue_terracotta
fill 347 201 282 347 202 284 minecraft:dirt
fill 348 201 281 348 202 281 minecraft:dirt
fill 348 201 286 348 202 286 minecraft:dirt
fill 350 201 280 350 202 280 minecraft:dirt
fill 352 201 281 352 202 281 minecraft:dirt
fill 352 201 286 352 202 286 minecraft:dirt
fill 353 201 282 353 202 282 minecraft:dirt
fill 353 201 285 353 202 285 minecraft:dirt
setblock 365 201 292 minecraft:oak_leaves[persistent=true]
fill 366 201 291 367 201 291 minecraft:oak_leaves[persistent=true]
fill 366 201 296 367 202 296 minecraft:white_concrete
setblock 368 201 295 minecraft:oak_leaves[persistent=true]
setblock 369 201 293 minecraft:oak_leaves[persistent=true]
setblock 371 201 277 minecraft:white_wool
fill 371 201 290 371 221 290 minecraft:light_blue_terracotta
setblock 371 201 291 minecraft:white_wool
setblock 347 202 285 minecraft:dirt
setblock 349 202 280 minecraft:dirt
fill 349 202 287 351 202 287 minecraft:dirt
fill 351 202 280 352 202 280 minecraft:dirt
setblock 353 202 281 minecraft:dirt
setblock 353 202 286 minecraft:dirt
fill 354 202 283 354 202 284 minecraft:dirt
fill 371 202 277 371 221 277 minecraft:light_blue_terracotta
fill 371 202 291 371 221 291 minecraft:light_blue_terracotta
fill 350 203 283 350 205 283 minecraft:white_concrete
fill 360 203 294 363 205 294 minecraft:packed_mud
fill 361 203 295 362 205 296 minecraft:packed_mud
fill 362 203 293 363 205 293 minecraft:packed_mud
setblock 332 204 278 minecraft:light[level=12]
setblock 332 204 285 minecraft:light[level=12]
setblock 332 204 292 minecraft:light[level=12]
setblock 332 204 299 minecraft:light[level=12]
setblock 332 204 306 minecraft:light[level=12]
setblock 332 204 313 minecraft:light[level=12]
setblock 339 204 278 minecraft:light[level=12]
setblock 339 204 285 minecraft:light[level=12]
setblock 339 204 292 minecraft:light[level=12]
setblock 339 204 299 minecraft:light[level=12]
setblock 339 204 306 minecraft:light[level=12]
setblock 339 204 313 minecraft:light[level=12]
setblock 346 204 278 minecraft:light[level=12]
setblock 346 204 285 minecraft:light[level=12]
setblock 346 204 292 minecraft:light[level=12]
setblock 346 204 299 minecraft:light[level=12]
setblock 346 204 306 minecraft:light[level=12]
setblock 346 204 313 minecraft:light[level=12]
setblock 353 204 278 minecraft:light[level=12]
setblock 353 204 285 minecraft:light[level=12]
setblock 353 204 292 minecraft:light[level=12]
setblock 353 204 299 minecraft:light[level=12]
setblock 353 204 306 minecraft:light[level=12]
setblock 353 204 313 minecraft:light[level=12]
setblock 360 204 278 minecraft:light[level=12]
setblock 360 204 285 minecraft:light[level=12]
setblock 360 204 292 minecraft:light[level=12]
fill 360 204 295 360 204 296 minecraft:packed_mud
setblock 360 204 299 minecraft:light[level=12]
setblock 360 204 306 minecraft:light[level=12]
setblock 360 204 313 minecraft:light[level=12]
fill 361 204 293 361 206 293 minecraft:packed_mud
setblock 362 204 292 minecraft:packed_mud
fill 363 204 295 363 206 295 minecraft:packed_mud
setblock 367 204 278 minecraft:light[level=12]
setblock 367 204 285 minecraft:light[level=12]
setblock 367 204 292 minecraft:light[level=12]
setblock 367 204 299 minecraft:light[level=12]
setblock 367 204 306 minecraft:light[level=12]
setblock 367 204 313 minecraft:light[level=12]
setblock 371 204 293 minecraft:white_wool
setblock 339 205 275 minecraft:white_wool
fill 355 205 275 355 206 275 minecraft:white_wool
setblock 360 205 293 minecraft:packed_mud
setblock 360 205 295 minecraft:packed_mud
fill 371 205 293 371 221 293 minecraft:light_blue_terracotta
fill 371 205 315 371 222 315 minecraft:light_blue_terracotta
setblock 371 205 316 minecraft:white_wool
fill 339 206 275 339 219 275 minecraft:light_blue_terracotta
schedule function dropper:buildpart/67_2 1t
