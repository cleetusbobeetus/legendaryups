fill 170 1 362 170 3 362 minecraft:blue_terracotta
setblock 171 1 324 minecraft:blue_terracotta
setblock 171 1 325 minecraft:dark_prismarine
setblock 172 1 324 minecraft:dark_prismarine
fill 172 1 325 172 4 325 minecraft:blue_terracotta
setblock 173 1 323 minecraft:dark_prismarine
fill 173 1 324 173 4 324 minecraft:blue_terracotta
setblock 173 1 363 minecraft:dark_prismarine
fill 174 1 323 174 4 323 minecraft:blue_terracotta
fill 174 1 363 174 4 363 minecraft:blue_terracotta
setblock 176 1 325 minecraft:dark_prismarine
setblock 177 1 324 minecraft:dark_prismarine
fill 177 1 325 177 4 325 minecraft:blue_terracotta
setblock 178 1 323 minecraft:dark_prismarine
fill 178 1 324 178 4 324 minecraft:blue_terracotta
setblock 178 1 363 minecraft:dark_prismarine
fill 179 1 323 179 4 323 minecraft:blue_terracotta
fill 179 1 363 179 3 363 minecraft:blue_terracotta
setblock 181 1 325 minecraft:dark_prismarine
fill 181 1 326 181 2 328 minecraft:blue_terracotta
setblock 182 1 324 minecraft:dark_prismarine
fill 182 1 325 182 4 325 minecraft:blue_terracotta
setblock 182 1 329 minecraft:dark_prismarine
fill 182 1 330 182 3 331 minecraft:blue_terracotta
setblock 182 1 334 minecraft:purple_concrete
fill 182 1 340 182 2 340 minecraft:blue_terracotta
setblock 182 1 344 minecraft:dark_prismarine
fill 182 1 345 182 3 346 minecraft:blue_terracotta
setblock 182 1 353 minecraft:purple_concrete
fill 182 1 361 182 3 361 minecraft:blue_terracotta
setblock 142 2 323 minecraft:dark_prismarine
fill 142 2 324 145 2 324 minecraft:blue_terracotta
setblock 142 2 328 minecraft:dark_prismarine
fill 142 2 329 142 5 329 minecraft:blue_terracotta
setblock 142 2 339 minecraft:purple_concrete
setblock 142 2 342 minecraft:blue_terracotta
setblock 142 2 343 minecraft:dark_prismarine
fill 142 2 344 142 5 344 minecraft:blue_terracotta
setblock 142 2 348 minecraft:dark_prismarine
fill 142 2 349 142 4 350 minecraft:blue_terracotta
setblock 142 2 358 minecraft:dark_prismarine
fill 142 2 359 142 5 359 minecraft:blue_terracotta
setblock 142 2 362 minecraft:blue_terracotta
setblock 142 2 363 minecraft:dark_prismarine
fill 143 2 323 143 5 323 minecraft:blue_terracotta
setblock 143 2 327 minecraft:dark_prismarine
setblock 143 2 362 minecraft:dark_prismarine
fill 143 2 363 143 5 363 minecraft:blue_terracotta
setblock 144 2 325 minecraft:blue_terracotta
fill 144 2 362 144 5 362 minecraft:blue_terracotta
setblock 145 2 325 minecraft:dark_prismarine
fill 145 2 361 145 4 361 minecraft:blue_terracotta
setblock 146 2 324 minecraft:dark_prismarine
fill 146 2 325 149 2 325 minecraft:blue_terracotta
setblock 147 2 323 minecraft:dark_prismarine
fill 147 2 324 147 5 324 minecraft:blue_terracotta
setblock 147 2 363 minecraft:dark_prismarine
fill 148 2 323 148 5 323 minecraft:blue_terracotta
setblock 148 2 362 minecraft:dark_prismarine
fill 148 2 363 148 5 363 minecraft:blue_terracotta
setblock 149 2 361 minecraft:dark_prismarine
fill 149 2 362 149 5 362 minecraft:blue_terracotta
setblock 150 2 325 minecraft:dark_prismarine
fill 150 2 361 150 4 361 minecraft:blue_terracotta
setblock 151 2 324 minecraft:dark_prismarine
fill 151 2 325 151 4 325 minecraft:blue_terracotta
setblock 152 2 323 minecraft:dark_prismarine
fill 152 2 324 152 5 324 minecraft:blue_terracotta
setblock 152 2 363 minecraft:dark_prismarine
fill 153 2 323 153 5 323 minecraft:blue_terracotta
setblock 153 2 362 minecraft:dark_prismarine
fill 153 2 363 153 5 363 minecraft:blue_terracotta
fill 154 2 362 154 3 362 minecraft:blue_terracotta
setblock 157 2 323 minecraft:dark_prismarine
setblock 157 2 363 minecraft:dark_prismarine
fill 158 2 323 158 3 323 minecraft:blue_terracotta
fill 158 2 363 161 2 363 minecraft:blue_terracotta
fill 160 2 323 161 2 323 minecraft:blue_terracotta
setblock 162 2 323 minecraft:dark_prismarine
setblock 162 2 363 minecraft:dark_prismarine
fill 163 2 323 163 5 323 minecraft:blue_terracotta
fill 163 2 363 163 3 363 minecraft:blue_terracotta
fill 164 2 324 165 2 324 minecraft:blue_terracotta
setblock 166 2 324 minecraft:dark_prismarine
fill 166 2 325 169 2 325 minecraft:blue_terracotta
setblock 167 2 323 minecraft:dark_prismarine
fill 167 2 324 170 2 324 minecraft:blue_terracotta
setblock 167 2 363 minecraft:dark_prismarine
fill 168 2 323 168 5 323 minecraft:blue_terracotta
setblock 168 2 362 minecraft:dark_prismarine
fill 168 2 363 168 5 363 minecraft:blue_terracotta
fill 169 2 362 169 3 362 minecraft:blue_terracotta
setblock 170 2 325 minecraft:dark_prismarine
fill 170 2 326 173 2 326 minecraft:blue_terracotta
setblock 171 2 324 minecraft:dark_prismarine
fill 171 2 325 171 5 325 minecraft:blue_terracotta
setblock 172 2 323 minecraft:dark_prismarine
fill 172 2 324 172 5 324 minecraft:blue_terracotta
setblock 172 2 363 minecraft:dark_prismarine
fill 173 2 323 173 5 323 minecraft:blue_terracotta
fill 173 2 363 173 5 363 minecraft:blue_terracotta
setblock 174 2 325 minecraft:blue_terracotta
setblock 175 2 325 minecraft:dark_prismarine
setblock 176 2 324 minecraft:dark_prismarine
fill 176 2 325 176 5 325 minecraft:blue_terracotta
setblock 177 2 323 minecraft:dark_prismarine
fill 177 2 324 177 5 324 minecraft:blue_terracotta
setblock 177 2 363 minecraft:dark_prismarine
fill 178 2 323 178 5 323 minecraft:blue_terracotta
fill 178 2 325 179 2 325 minecraft:blue_terracotta
fill 178 2 363 178 3 363 minecraft:blue_terracotta
setblock 180 2 324 minecraft:blue_terracotta
setblock 180 2 325 minecraft:dark_prismarine
fill 180 2 350 180 27 350 minecraft:magenta_terracotta
setblock 181 2 324 minecraft:dark_prismarine
fill 181 2 325 181 5 325 minecraft:blue_terracotta
setblock 181 2 329 minecraft:dark_prismarine
setblock 182 2 323 minecraft:dark_prismarine
fill 182 2 324 182 5 324 minecraft:blue_terracotta
setblock 182 2 327 minecraft:blue_terracotta
setblock 182 2 328 minecraft:dark_prismarine
fill 182 2 329 182 5 329 minecraft:blue_terracotta
setblock 182 2 332 minecraft:blue_terracotta
setblock 182 2 342 minecraft:blue_terracotta
setblock 182 2 343 minecraft:dark_prismarine
fill 182 2 344 182 5 344 minecraft:blue_terracotta
setblock 182 2 347 minecraft:blue_terracotta
setblock 182 2 363 minecraft:dark_prismarine
fill 142 3 323 142 5 324 minecraft:blue_terracotta
setblock 142 3 327 minecraft:dark_prismarine
fill 142 3 328 143 5 328 minecraft:blue_terracotta
fill 142 3 330 142 4 330 minecraft:blue_terracotta
fill 142 3 343 142 5 343 minecraft:blue_terracotta
fill 142 3 345 142 3 346 minecraft:blue_terracotta
setblock 142 3 347 minecraft:dark_prismarine
fill 142 3 348 143 5 348 minecraft:blue_terracotta
setblock 142 3 351 minecraft:blue_terracotta
setblock 142 3 352 minecraft:dark_prismarine
fill 142 3 353 142 6 353 minecraft:blue_terracotta
setblock 142 3 357 minecraft:dark_prismarine
fill 142 3 358 142 6 358 minecraft:blue_terracotta
setblock 142 3 362 minecraft:dark_prismarine
fill 142 3 363 142 6 363 minecraft:blue_terracotta
fill 143 3 324 144 3 324 minecraft:blue_terracotta
setblock 143 3 326 minecraft:dark_prismarine
fill 143 3 327 143 6 327 minecraft:blue_terracotta
setblock 143 3 345 minecraft:blue_terracotta
setblock 143 3 346 minecraft:dark_prismarine
fill 143 3 347 143 6 347 minecraft:blue_terracotta
fill 143 3 349 143 3 350 minecraft:blue_terracotta
setblock 143 3 361 minecraft:dark_prismarine
fill 143 3 362 143 6 362 minecraft:blue_terracotta
setblock 144 3 325 minecraft:dark_prismarine
fill 144 3 326 144 6 326 minecraft:blue_terracotta
setblock 145 3 324 minecraft:dark_prismarine
fill 145 3 325 148 3 325 minecraft:blue_terracotta
setblock 146 3 323 minecraft:dark_prismarine
fill 146 3 324 146 6 324 minecraft:blue_terracotta
setblock 146 3 363 minecraft:dark_prismarine
fill 147 3 323 147 6 323 minecraft:blue_terracotta
setblock 147 3 362 minecraft:dark_prismarine
fill 147 3 363 147 6 363 minecraft:blue_terracotta
setblock 148 3 361 minecraft:dark_prismarine
fill 148 3 362 148 6 362 minecraft:blue_terracotta
setblock 149 3 325 minecraft:dark_prismarine
fill 149 3 361 149 5 361 minecraft:blue_terracotta
setblock 150 3 324 minecraft:dark_prismarine
fill 150 3 325 150 4 325 minecraft:blue_terracotta
setblock 151 3 323 minecraft:dark_prismarine
fill 151 3 324 151 6 324 minecraft:blue_terracotta
setblock 151 3 363 minecraft:dark_prismarine
fill 152 3 323 152 6 323 minecraft:blue_terracotta
setblock 152 3 362 minecraft:dark_prismarine
fill 152 3 363 152 6 363 minecraft:blue_terracotta
fill 153 3 362 153 4 362 minecraft:blue_terracotta
setblock 156 3 323 minecraft:dark_prismarine
setblock 156 3 363 minecraft:dark_prismarine
setblock 157 3 323 minecraft:blue_terracotta
fill 157 3 363 158 3 363 minecraft:blue_terracotta
setblock 160 3 323 minecraft:blue_terracotta
setblock 161 3 323 minecraft:dark_prismarine
fill 162 3 323 162 6 323 minecraft:blue_terracotta
setblock 164 3 324 minecraft:blue_terracotta
setblock 165 3 324 minecraft:dark_prismarine
setblock 166 3 323 minecraft:dark_prismarine
fill 166 3 324 168 3 325 minecraft:blue_terracotta
setblock 166 3 363 minecraft:dark_prismarine
fill 167 3 323 167 6 323 minecraft:blue_terracotta
fill 167 3 363 167 6 363 minecraft:blue_terracotta
setblock 168 3 326 minecraft:dark_prismarine
setblock 168 3 362 minecraft:blue_terracotta
setblock 169 3 324 minecraft:blue_terracotta
setblock 169 3 325 minecraft:dark_prismarine
fill 169 3 326 172 3 326 minecraft:blue_terracotta
setblock 170 3 324 minecraft:dark_prismarine
fill 170 3 325 170 6 325 minecraft:blue_terracotta
setblock 171 3 323 minecraft:dark_prismarine
fill 171 3 324 171 6 324 minecraft:blue_terracotta
setblock 171 3 363 minecraft:dark_prismarine
fill 172 3 323 172 6 323 minecraft:blue_terracotta
fill 172 3 363 172 5 363 minecraft:blue_terracotta
setblock 173 3 326 minecraft:dark_prismarine
setblock 174 3 325 minecraft:dark_prismarine
setblock 175 3 324 minecraft:dark_prismarine
fill 175 3 325 175 5 325 minecraft:blue_terracotta
setblock 176 3 323 minecraft:dark_prismarine
fill 176 3 324 176 6 324 minecraft:blue_terracotta
setblock 176 3 363 minecraft:dark_prismarine
fill 177 3 323 177 6 323 minecraft:blue_terracotta
setblock 177 3 363 minecraft:blue_terracotta
setblock 178 3 325 minecraft:blue_terracotta
setblock 179 3 325 minecraft:dark_prismarine
setblock 180 3 324 minecraft:dark_prismarine
fill 180 3 325 180 5 326 minecraft:blue_terracotta
setblock 181 3 323 minecraft:dark_prismarine
fill 181 3 324 181 6 324 minecraft:blue_terracotta
fill 181 3 326 181 3 327 minecraft:blue_terracotta
setblock 181 3 328 minecraft:dark_prismarine
fill 181 3 329 181 6 329 minecraft:blue_terracotta
setblock 181 3 363 minecraft:dark_prismarine
fill 182 3 323 182 6 323 minecraft:blue_terracotta
setblock 182 3 327 minecraft:dark_prismarine
fill 182 3 328 182 6 328 minecraft:blue_terracotta
setblock 182 3 332 minecraft:dark_prismarine
setblock 182 3 341 minecraft:purple_concrete
setblock 182 3 342 minecraft:dark_prismarine
fill 182 3 343 182 4 343 minecraft:blue_terracotta
setblock 182 3 347 minecraft:dark_prismarine
fill 182 3 348 182 6 348 minecraft:blue_terracotta
setblock 182 3 362 minecraft:dark_prismarine
fill 182 3 363 182 6 363 minecraft:blue_terracotta
setblock 142 4 326 minecraft:dark_prismarine
fill 142 4 327 142 7 327 minecraft:blue_terracotta
setblock 142 4 345 minecraft:blue_terracotta
setblock 142 4 346 minecraft:dark_prismarine
fill 142 4 347 142 7 347 minecraft:blue_terracotta
setblock 142 4 351 minecraft:dark_prismarine
fill 142 4 352 143 6 352 minecraft:blue_terracotta
fill 142 4 354 142 4 355 minecraft:blue_terracotta
setblock 142 4 356 minecraft:dark_prismarine
fill 142 4 357 142 7 357 minecraft:blue_terracotta
setblock 142 4 360 minecraft:blue_terracotta
setblock 142 4 361 minecraft:dark_prismarine
fill 142 4 362 142 7 362 minecraft:blue_terracotta
setblock 143 4 324 minecraft:blue_terracotta
setblock 143 4 325 minecraft:dark_prismarine
fill 143 4 326 143 7 326 minecraft:blue_terracotta
setblock 143 4 345 minecraft:dark_prismarine
fill 143 4 346 143 7 346 minecraft:blue_terracotta
setblock 143 4 349 minecraft:blue_terracotta
setblock 143 4 350 minecraft:dark_prismarine
fill 143 4 351 143 7 351 minecraft:blue_terracotta
setblock 143 4 360 minecraft:dark_prismarine
fill 143 4 361 143 6 361 minecraft:blue_terracotta
setblock 144 4 324 minecraft:dark_prismarine
fill 144 4 325 147 4 325 minecraft:blue_terracotta
setblock 144 4 348 minecraft:blue_terracotta
setblock 145 4 323 minecraft:dark_prismarine
fill 145 4 324 145 7 324 minecraft:blue_terracotta
setblock 145 4 363 minecraft:dark_prismarine
fill 146 4 323 146 7 323 minecraft:blue_terracotta
setblock 146 4 362 minecraft:dark_prismarine
fill 146 4 363 146 7 363 minecraft:blue_terracotta
setblock 147 4 361 minecraft:dark_prismarine
fill 147 4 362 147 7 362 minecraft:blue_terracotta
setblock 148 4 325 minecraft:dark_prismarine
fill 148 4 361 148 5 361 minecraft:blue_terracotta
setblock 149 4 324 minecraft:dark_prismarine
fill 149 4 325 149 5 325 minecraft:blue_terracotta
setblock 150 4 323 minecraft:dark_prismarine
fill 150 4 324 150 6 324 minecraft:blue_terracotta
setblock 150 4 363 minecraft:dark_prismarine
fill 151 4 323 151 7 323 minecraft:blue_terracotta
setblock 151 4 362 minecraft:dark_prismarine
fill 151 4 363 151 7 363 minecraft:blue_terracotta
fill 152 4 362 152 5 362 minecraft:blue_terracotta
fill 153 4 322 155 83 322 minecraft:black_concrete
setblock 155 4 323 minecraft:dark_prismarine
setblock 155 4 363 minecraft:dark_prismarine
setblock 156 4 322 minecraft:cyan_concrete
setblock 156 4 323 minecraft:blue_terracotta
setblock 156 4 363 minecraft:blue_terracotta
fill 157 4 322 157 131 322 minecraft:black_concrete
fill 160 4 329 160 32 329 minecraft:magenta_terracotta
setblock 161 4 323 minecraft:blue_terracotta
setblock 163 4 324 minecraft:blue_terracotta
setblock 164 4 324 minecraft:dark_prismarine
setblock 165 4 323 minecraft:dark_prismarine
fill 165 4 324 167 4 325 minecraft:blue_terracotta
setblock 165 4 363 minecraft:dark_prismarine
fill 166 4 323 166 7 323 minecraft:blue_terracotta
fill 166 4 363 166 6 363 minecraft:blue_terracotta
setblock 168 4 324 minecraft:blue_terracotta
setblock 168 4 325 minecraft:dark_prismarine
fill 168 4 326 171 4 326 minecraft:blue_terracotta
setblock 169 4 324 minecraft:dark_prismarine
fill 169 4 325 169 7 325 minecraft:blue_terracotta
setblock 170 4 323 minecraft:dark_prismarine
fill 170 4 324 170 7 324 minecraft:blue_terracotta
setblock 170 4 363 minecraft:dark_prismarine
fill 171 4 323 171 7 323 minecraft:blue_terracotta
fill 171 4 363 171 5 363 minecraft:blue_terracotta
setblock 172 4 326 minecraft:dark_prismarine
setblock 173 4 325 minecraft:dark_prismarine
setblock 174 4 324 minecraft:dark_prismarine
fill 174 4 325 174 6 325 minecraft:blue_terracotta
setblock 175 4 323 minecraft:dark_prismarine
fill 175 4 324 175 7 324 minecraft:blue_terracotta
fill 175 4 337 175 33 337 minecraft:magenta_terracotta
setblock 175 4 363 minecraft:dark_prismarine
fill 176 4 323 176 7 323 minecraft:blue_terracotta
setblock 178 4 325 minecraft:dark_prismarine
setblock 179 4 324 minecraft:dark_prismarine
setblock 179 4 325 minecraft:blue_terracotta
setblock 180 4 323 minecraft:dark_prismarine
fill 180 4 324 180 7 324 minecraft:blue_terracotta
setblock 180 4 363 minecraft:dark_prismarine
fill 181 4 323 181 7 323 minecraft:blue_terracotta
setblock 181 4 326 minecraft:blue_terracotta
setblock 181 4 327 minecraft:dark_prismarine
fill 181 4 328 181 7 328 minecraft:blue_terracotta
fill 181 4 330 182 4 330 minecraft:blue_terracotta
fill 181 4 363 181 6 363 minecraft:blue_terracotta
setblock 182 4 326 minecraft:dark_prismarine
fill 182 4 327 182 7 327 minecraft:blue_terracotta
setblock 182 4 331 minecraft:dark_prismarine
fill 182 4 332 182 6 333 minecraft:blue_terracotta
setblock 182 4 335 minecraft:purple_concrete
setblock 182 4 345 minecraft:blue_terracotta
setblock 182 4 346 minecraft:dark_prismarine
fill 182 4 347 182 7 347 minecraft:blue_terracotta
fill 182 4 349 182 5 349 minecraft:blue_terracotta
setblock 182 4 360 minecraft:purple_concrete
setblock 182 4 361 minecraft:dark_prismarine
fill 182 4 362 182 7 362 minecraft:blue_terracotta
setblock 142 5 325 minecraft:dark_prismarine
fill 142 5 326 142 8 326 minecraft:blue_terracotta
setblock 142 5 330 minecraft:dark_prismarine
setblock 142 5 332 minecraft:purple_concrete
setblock 142 5 345 minecraft:dark_prismarine
fill 142 5 346 142 8 346 minecraft:blue_terracotta
setblock 142 5 349 minecraft:blue_terracotta
setblock 142 5 350 minecraft:dark_prismarine
fill 142 5 351 142 8 351 minecraft:blue_terracotta
setblock 142 5 354 minecraft:blue_terracotta
setblock 142 5 355 minecraft:dark_prismarine
fill 142 5 356 142 8 356 minecraft:blue_terracotta
setblock 142 5 360 minecraft:dark_prismarine
fill 142 5 361 142 8 361 minecraft:blue_terracotta
setblock 143 5 324 minecraft:dark_prismarine
fill 143 5 325 146 5 325 minecraft:blue_terracotta
setblock 143 5 329 minecraft:dark_prismarine
fill 143 5 345 143 6 345 minecraft:blue_terracotta
setblock 143 5 349 minecraft:dark_prismarine
fill 143 5 350 144 7 350 minecraft:blue_terracotta
setblock 143 5 353 minecraft:blue_terracotta
setblock 143 5 354 minecraft:dark_prismarine
setblock 143 5 360 minecraft:blue_terracotta
setblock 144 5 323 minecraft:dark_prismarine
fill 144 5 324 144 8 324 minecraft:blue_terracotta
setblock 144 5 332 minecraft:light[level=12]
setblock 144 5 333 minecraft:light[level=13]
setblock 144 5 339 minecraft:light[level=12]
setblock 144 5 341 minecraft:light[level=13]
setblock 144 5 346 minecraft:light[level=12]
setblock 144 5 347 minecraft:blue_terracotta
setblock 144 5 348 minecraft:dark_prismarine
fill 144 5 349 144 8 349 minecraft:blue_terracotta
fill 144 5 351 144 6 351 minecraft:blue_terracotta
setblock 144 5 353 minecraft:light[level=12]
setblock 144 5 357 minecraft:light[level=13]
setblock 144 5 360 minecraft:light[level=12]
setblock 144 5 363 minecraft:dark_prismarine
fill 145 5 323 145 8 323 minecraft:blue_terracotta
fill 145 5 341 145 24 341 minecraft:iron_bars
setblock 145 5 362 minecraft:dark_prismarine
fill 145 5 363 145 8 363 minecraft:blue_terracotta
setblock 146 5 361 minecraft:dark_prismarine
fill 146 5 362 146 8 362 minecraft:blue_terracotta
setblock 147 5 325 minecraft:dark_prismarine
setblock 147 5 361 minecraft:blue_terracotta
setblock 148 5 324 minecraft:dark_prismarine
fill 148 5 325 148 6 325 minecraft:blue_terracotta
setblock 149 5 323 minecraft:dark_prismarine
fill 149 5 324 149 7 324 minecraft:blue_terracotta
setblock 149 5 363 minecraft:dark_prismarine
fill 150 5 323 150 8 323 minecraft:blue_terracotta
fill 150 5 353 150 10 353 minecraft:magenta_terracotta
setblock 150 5 362 minecraft:dark_prismarine
fill 150 5 363 150 8 363 minecraft:blue_terracotta
setblock 151 5 325 minecraft:light[level=12]
setblock 151 5 332 minecraft:light[level=12]
setblock 151 5 339 minecraft:light[level=12]
setblock 151 5 346 minecraft:light[level=12]
setblock 151 5 353 minecraft:light[level=12]
setblock 151 5 360 minecraft:light[level=12]
setblock 151 5 362 minecraft:blue_terracotta
setblock 152 5 325 minecraft:light[level=13]
setblock 152 5 333 minecraft:light[level=13]
setblock 152 5 341 minecraft:light[level=13]
setblock 152 5 349 minecraft:light[level=13]
setblock 152 5 357 minecraft:light[level=13]
setblock 154 5 323 minecraft:dark_prismarine
setblock 154 5 363 minecraft:dark_prismarine
setblock 155 5 363 minecraft:purple_concrete
fill 156 5 322 156 127 322 minecraft:black_concrete
setblock 158 5 325 minecraft:light[level=12]
setblock 158 5 332 minecraft:light[level=12]
setblock 158 5 339 minecraft:light[level=12]
setblock 158 5 346 minecraft:light[level=12]
setblock 158 5 353 minecraft:light[level=12]
setblock 158 5 360 minecraft:light[level=12]
setblock 160 5 325 minecraft:light[level=13]
setblock 160 5 333 minecraft:light[level=13]
setblock 160 5 349 minecraft:light[level=13]
setblock 160 5 357 minecraft:light[level=13]
setblock 163 5 324 minecraft:dark_prismarine
setblock 164 5 323 minecraft:dark_prismarine
fill 164 5 324 167 5 324 minecraft:blue_terracotta
fill 165 5 323 165 8 323 minecraft:blue_terracotta
fill 165 5 325 166 5 325 minecraft:blue_terracotta
setblock 165 5 332 minecraft:light[level=12]
setblock 165 5 339 minecraft:light[level=12]
setblock 165 5 346 minecraft:light[level=12]
setblock 165 5 353 minecraft:light[level=12]
fill 165 5 356 165 33 356 minecraft:magenta_terracotta
setblock 165 5 363 minecraft:blue_terracotta
setblock 167 5 325 minecraft:dark_prismarine
setblock 168 5 324 minecraft:dark_prismarine
fill 168 5 325 168 6 326 minecraft:blue_terracotta
setblock 168 5 333 minecraft:light[level=13]
setblock 168 5 341 minecraft:light[level=13]
setblock 168 5 349 minecraft:light[level=13]
setblock 168 5 357 minecraft:light[level=13]
fill 169 5 322 170 77 322 minecraft:black_concrete
setblock 169 5 323 minecraft:dark_prismarine
fill 169 5 324 169 8 324 minecraft:blue_terracotta
fill 169 5 326 170 5 326 minecraft:blue_terracotta
setblock 169 5 363 minecraft:dark_prismarine
fill 170 5 323 170 8 323 minecraft:blue_terracotta
fill 170 5 363 170 6 363 minecraft:blue_terracotta
setblock 171 5 322 minecraft:light_blue_wool
setblock 171 5 326 minecraft:dark_prismarine
fill 172 5 322 174 62 322 minecraft:black_concrete
setblock 172 5 325 minecraft:dark_prismarine
setblock 172 5 332 minecraft:light[level=12]
setblock 172 5 339 minecraft:light[level=12]
setblock 172 5 346 minecraft:light[level=12]
setblock 172 5 353 minecraft:light[level=12]
setblock 172 5 360 minecraft:light[level=12]
setblock 173 5 324 minecraft:dark_prismarine
fill 173 5 325 173 6 325 minecraft:blue_terracotta
setblock 174 5 323 minecraft:dark_prismarine
fill 174 5 324 174 7 324 minecraft:blue_terracotta
fill 175 5 323 175 8 323 minecraft:blue_terracotta
setblock 176 5 333 minecraft:light[level=13]
fill 176 5 334 176 23 334 minecraft:magenta_terracotta
fill 176 5 336 176 33 336 minecraft:magenta_terracotta
setblock 176 5 341 minecraft:light[level=13]
setblock 178 5 324 minecraft:dark_prismarine
setblock 179 5 323 minecraft:dark_prismarine
fill 179 5 324 179 7 324 minecraft:blue_terracotta
setblock 179 5 325 minecraft:light[level=12]
setblock 179 5 332 minecraft:light[level=12]
setblock 179 5 339 minecraft:light[level=12]
setblock 179 5 346 minecraft:light[level=12]
setblock 179 5 353 minecraft:light[level=12]
setblock 179 5 360 minecraft:light[level=12]
fill 180 5 323 180 8 323 minecraft:blue_terracotta
setblock 180 5 363 minecraft:purple_concrete
setblock 181 5 326 minecraft:dark_prismarine
fill 181 5 327 181 8 327 minecraft:blue_terracotta
setblock 181 5 330 minecraft:blue_terracotta
setblock 182 5 325 minecraft:dark_prismarine
fill 182 5 326 182 8 326 minecraft:blue_terracotta
setblock 182 5 330 minecraft:dark_prismarine
fill 182 5 331 182 8 331 minecraft:blue_terracotta
setblock 182 5 345 minecraft:dark_prismarine
fill 182 5 346 182 6 346 minecraft:blue_terracotta
setblock 182 5 350 minecraft:dark_prismarine
setblock 182 5 354 minecraft:purple_concrete
setblock 142 6 323 minecraft:blue_terracotta
setblock 142 6 324 minecraft:dark_prismarine
fill 142 6 325 145 6 325 minecraft:blue_terracotta
setblock 142 6 328 minecraft:blue_terracotta
setblock 142 6 329 minecraft:dark_prismarine
fill 142 6 330 142 8 331 minecraft:blue_terracotta
setblock 142 6 338 minecraft:purple_concrete
setblock 142 6 344 minecraft:dark_prismarine
fill 142 6 345 142 9 345 minecraft:blue_terracotta
setblock 142 6 348 minecraft:blue_terracotta
setblock 142 6 349 minecraft:dark_prismarine
fill 142 6 350 142 9 350 minecraft:blue_terracotta
setblock 142 6 354 minecraft:dark_prismarine
fill 142 6 355 143 8 355 minecraft:blue_terracotta
setblock 142 6 359 minecraft:dark_prismarine
fill 142 6 360 142 9 360 minecraft:blue_terracotta
setblock 143 6 323 minecraft:dark_prismarine
fill 143 6 324 143 9 324 minecraft:blue_terracotta
setblock 143 6 328 minecraft:dark_prismarine
fill 143 6 329 143 9 329 minecraft:blue_terracotta
setblock 143 6 348 minecraft:dark_prismarine
fill 143 6 349 143 9 349 minecraft:blue_terracotta
setblock 143 6 353 minecraft:dark_prismarine
fill 143 6 354 143 9 354 minecraft:blue_terracotta
setblock 143 6 363 minecraft:dark_prismarine
fill 144 6 323 144 9 323 minecraft:blue_terracotta
setblock 144 6 347 minecraft:dark_prismarine
fill 144 6 348 144 9 348 minecraft:blue_terracotta
setblock 144 6 352 minecraft:dark_prismarine
setblock 144 6 362 minecraft:dark_prismarine
fill 144 6 363 144 9 363 minecraft:blue_terracotta
fill 145 6 362 145 9 362 minecraft:blue_terracotta
setblock 146 6 325 minecraft:dark_prismarine
setblock 147 6 324 minecraft:dark_prismarine
setblock 147 6 325 minecraft:blue_terracotta
setblock 148 6 323 minecraft:dark_prismarine
fill 148 6 324 148 7 324 minecraft:blue_terracotta
setblock 148 6 363 minecraft:dark_prismarine
fill 149 6 323 149 8 323 minecraft:blue_terracotta
setblock 149 6 362 minecraft:dark_prismarine
fill 149 6 363 149 9 363 minecraft:blue_terracotta
setblock 150 6 362 minecraft:blue_terracotta
setblock 153 6 323 minecraft:dark_prismarine
setblock 153 6 363 minecraft:dark_prismarine
setblock 157 6 323 minecraft:purple_concrete
setblock 161 6 363 minecraft:purple_concrete
setblock 163 6 323 minecraft:dark_prismarine
fill 164 6 323 164 8 324 minecraft:blue_terracotta
fill 165 6 324 165 6 325 minecraft:blue_terracotta
setblock 166 6 324 minecraft:blue_terracotta
setblock 166 6 325 minecraft:dark_prismarine
setblock 167 6 324 minecraft:dark_prismarine
fill 167 6 325 167 8 325 minecraft:blue_terracotta
setblock 168 6 323 minecraft:dark_prismarine
fill 168 6 324 168 9 324 minecraft:blue_terracotta
setblock 168 6 363 minecraft:dark_prismarine
fill 169 6 323 169 9 323 minecraft:blue_terracotta
setblock 169 6 326 minecraft:blue_terracotta
setblock 169 6 363 minecraft:blue_terracotta
fill 171 6 322 171 131 322 minecraft:black_concrete
setblock 171 6 325 minecraft:dark_prismarine
setblock 172 6 324 minecraft:dark_prismarine
fill 172 6 325 172 7 325 minecraft:blue_terracotta
setblock 173 6 323 minecraft:dark_prismarine
fill 173 6 324 173 7 324 minecraft:blue_terracotta
fill 174 6 323 174 9 323 minecraft:blue_terracotta
setblock 177 6 324 minecraft:dark_prismarine
setblock 178 6 323 minecraft:dark_prismarine
fill 178 6 324 178 7 324 minecraft:blue_terracotta
fill 179 6 323 179 9 323 minecraft:blue_terracotta
setblock 181 6 325 minecraft:dark_prismarine
fill 181 6 326 181 9 326 minecraft:blue_terracotta
setblock 181 6 330 minecraft:dark_prismarine
setblock 182 6 324 minecraft:dark_prismarine
fill 182 6 325 182 9 325 minecraft:blue_terracotta
setblock 182 6 329 minecraft:dark_prismarine
fill 182 6 330 182 9 330 minecraft:blue_terracotta
fill 182 6 342 182 7 342 minecraft:purple_concrete
setblock 182 6 349 minecraft:dark_prismarine
fill 182 6 350 182 8 351 minecraft:blue_terracotta
setblock 142 7 323 minecraft:dark_prismarine
fill 142 7 324 142 9 325 minecraft:blue_terracotta
setblock 142 7 328 minecraft:dark_prismarine
fill 142 7 329 142 10 329 minecraft:blue_terracotta
setblock 142 7 344 minecraft:purple_concrete
setblock 142 7 348 minecraft:dark_prismarine
fill 142 7 349 142 10 349 minecraft:blue_terracotta
setblock 142 7 352 minecraft:blue_terracotta
setblock 142 7 353 minecraft:dark_prismarine
fill 142 7 354 142 10 354 minecraft:blue_terracotta
setblock 142 7 358 minecraft:dark_prismarine
fill 142 7 359 142 10 359 minecraft:blue_terracotta
setblock 142 7 363 minecraft:dark_prismarine
fill 143 7 323 143 10 323 minecraft:blue_terracotta
fill 143 7 325 143 8 325 minecraft:blue_terracotta
setblock 143 7 327 minecraft:dark_prismarine
fill 143 7 328 143 10 328 minecraft:blue_terracotta
setblock 143 7 347 minecraft:dark_prismarine
fill 143 7 348 143 10 348 minecraft:blue_terracotta
setblock 143 7 352 minecraft:dark_prismarine
fill 143 7 353 144 9 353 minecraft:blue_terracotta
setblock 143 7 356 minecraft:blue_terracotta
setblock 143 7 362 minecraft:dark_prismarine
fill 143 7 363 143 10 363 minecraft:blue_terracotta
setblock 144 7 351 minecraft:dark_prismarine
fill 144 7 352 144 10 352 minecraft:blue_terracotta
fill 144 7 362 144 8 362 minecraft:blue_terracotta
setblock 146 7 324 minecraft:dark_prismarine
setblock 147 7 323 minecraft:dark_prismarine
fill 147 7 324 147 8 324 minecraft:blue_terracotta
setblock 147 7 363 minecraft:dark_prismarine
fill 148 7 323 148 9 323 minecraft:blue_terracotta
setblock 148 7 362 minecraft:dark_prismarine
fill 148 7 363 148 10 363 minecraft:blue_terracotta
setblock 149 7 362 minecraft:blue_terracotta
fill 151 7 364 155 31 364 minecraft:black_concrete
setblock 156 7 364 minecraft:cyan_concrete
fill 157 7 327 158 7 327 minecraft:magenta_terracotta
fill 157 7 364 160 59 364 minecraft:black_concrete
setblock 162 7 323 minecraft:dark_prismarine
fill 163 7 323 163 10 323 minecraft:blue_terracotta
setblock 165 7 324 minecraft:blue_terracotta
setblock 166 7 324 minecraft:dark_prismarine
fill 166 7 325 166 8 325 minecraft:blue_terracotta
fill 166 7 358 167 7 358 minecraft:magenta_terracotta
setblock 167 7 323 minecraft:dark_prismarine
fill 167 7 324 167 10 324 minecraft:blue_terracotta
setblock 167 7 363 minecraft:purple_concrete
fill 168 7 323 168 10 323 minecraft:blue_terracotta
fill 168 7 325 168 8 325 minecraft:blue_terracotta
setblock 170 7 325 minecraft:dark_prismarine
setblock 171 7 324 minecraft:dark_prismarine
setblock 171 7 325 minecraft:blue_terracotta
setblock 172 7 323 minecraft:dark_prismarine
fill 172 7 324 172 8 324 minecraft:blue_terracotta
fill 173 7 323 173 9 323 minecraft:blue_terracotta
fill 173 7 363 173 8 363 minecraft:purple_concrete
fill 174 7 333 174 11 333 minecraft:magenta_terracotta
setblock 176 7 324 minecraft:dark_prismarine
setblock 177 7 323 minecraft:dark_prismarine
setblock 177 7 324 minecraft:blue_terracotta
fill 178 7 323 178 10 323 minecraft:blue_terracotta
setblock 181 7 324 minecraft:dark_prismarine
fill 181 7 325 181 10 325 minecraft:blue_terracotta
setblock 181 7 329 minecraft:dark_prismarine
fill 181 7 330 181 10 330 minecraft:blue_terracotta
setblock 182 7 323 minecraft:dark_prismarine
fill 182 7 324 182 10 324 minecraft:blue_terracotta
setblock 182 7 328 minecraft:dark_prismarine
fill 182 7 329 182 10 329 minecraft:blue_terracotta
setblock 182 7 332 minecraft:blue_terracotta
setblock 182 7 333 minecraft:dark_prismarine
setblock 182 7 336 minecraft:purple_concrete
setblock 182 7 348 minecraft:dark_prismarine
fill 182 7 349 182 10 349 minecraft:blue_terracotta
setblock 182 7 352 minecraft:blue_terracotta
setblock 182 7 361 minecraft:purple_concrete
setblock 182 7 363 minecraft:dark_prismarine
fill 141 8 333 141 9 337 minecraft:black_concrete
setblock 141 8 338 minecraft:cyan_concrete
fill 141 8 339 141 40 341 minecraft:black_concrete
fill 142 8 323 142 11 323 minecraft:blue_terracotta
setblock 142 8 327 minecraft:dark_prismarine
fill 142 8 328 142 11 328 minecraft:blue_terracotta
setblock 142 8 347 minecraft:dark_prismarine
fill 142 8 348 142 11 348 minecraft:blue_terracotta
setblock 142 8 352 minecraft:dark_prismarine
fill 142 8 353 142 11 353 minecraft:blue_terracotta
setblock 142 8 357 minecraft:dark_prismarine
fill 142 8 358 142 11 358 minecraft:blue_terracotta
setblock 142 8 362 minecraft:dark_prismarine
fill 142 8 363 142 11 363 minecraft:blue_terracotta
setblock 143 8 326 minecraft:dark_prismarine
fill 143 8 327 143 11 327 minecraft:blue_terracotta
setblock 143 8 346 minecraft:dark_prismarine
fill 143 8 347 143 11 347 minecraft:blue_terracotta
setblock 143 8 350 minecraft:blue_terracotta
setblock 143 8 351 minecraft:dark_prismarine
fill 143 8 352 143 11 352 minecraft:blue_terracotta
setblock 143 8 356 minecraft:dark_prismarine
fill 143 8 357 143 11 357 minecraft:blue_terracotta
setblock 144 8 350 minecraft:dark_prismarine
fill 144 8 351 144 11 351 minecraft:blue_terracotta
setblock 144 8 354 minecraft:blue_terracotta
setblock 145 8 324 minecraft:dark_prismarine
setblock 146 8 323 minecraft:dark_prismarine
setblock 146 8 324 minecraft:blue_terracotta
fill 146 8 335 147 8 336 minecraft:pink_terracotta
setblock 146 8 363 minecraft:dark_prismarine
fill 147 8 323 147 10 323 minecraft:blue_terracotta
setblock 147 8 362 minecraft:dark_prismarine
fill 147 8 363 147 11 363 minecraft:blue_terracotta
fill 149 8 350 150 8 351 minecraft:pink_terracotta
setblock 154 8 363 minecraft:purple_concrete
fill 156 8 364 156 132 364 minecraft:black_concrete
fill 157 8 327 157 21 328 minecraft:magenta_terracotta
fill 158 8 327 159 8 328 minecraft:pink_terracotta
setblock 165 8 324 minecraft:dark_prismarine
fill 165 8 358 166 9 358 minecraft:pink_terracotta
setblock 166 8 323 minecraft:dark_prismarine
fill 166 8 324 166 11 324 minecraft:blue_terracotta
fill 167 8 323 167 11 323 minecraft:blue_terracotta
fill 167 8 358 167 23 358 minecraft:magenta_terracotta
setblock 169 8 325 minecraft:dark_prismarine
setblock 170 8 324 minecraft:dark_prismarine
setblock 170 8 325 minecraft:blue_terracotta
setblock 171 8 323 minecraft:dark_prismarine
fill 171 8 324 171 9 324 minecraft:blue_terracotta
fill 172 8 323 172 10 323 minecraft:blue_terracotta
fill 174 8 335 174 9 336 minecraft:pink_terracotta
setblock 175 8 335 minecraft:pink_terracotta
setblock 176 8 323 minecraft:dark_prismarine
fill 177 8 323 177 9 323 minecraft:blue_terracotta
fill 177 8 350 177 33 350 minecraft:magenta_terracotta
fill 178 8 350 178 9 351 minecraft:pink_terracotta
fill 179 8 350 179 33 350 minecraft:magenta_terracotta
setblock 179 8 363 minecraft:purple_concrete
setblock 180 8 324 minecraft:dark_prismarine
setblock 181 8 323 minecraft:dark_prismarine
fill 181 8 324 181 11 324 minecraft:blue_terracotta
setblock 181 8 328 minecraft:dark_prismarine
fill 181 8 329 181 11 329 minecraft:blue_terracotta
fill 181 8 331 181 9 331 minecraft:blue_terracotta
fill 182 8 323 182 11 323 minecraft:blue_terracotta
setblock 182 8 327 minecraft:dark_prismarine
fill 182 8 328 182 11 328 minecraft:blue_terracotta
setblock 182 8 332 minecraft:dark_prismarine
fill 182 8 333 182 11 333 minecraft:blue_terracotta
setblock 182 8 347 minecraft:dark_prismarine
fill 182 8 348 182 11 348 minecraft:blue_terracotta
setblock 182 8 352 minecraft:dark_prismarine
fill 182 8 353 182 10 354 minecraft:blue_terracotta
setblock 182 8 355 minecraft:purple_concrete
fill 182 8 363 182 11 363 minecraft:blue_terracotta
fill 141 9 338 141 36 338 minecraft:black_concrete
setblock 142 9 326 minecraft:dark_prismarine
fill 142 9 327 142 12 327 minecraft:blue_terracotta
setblock 142 9 330 minecraft:blue_terracotta
setblock 142 9 331 minecraft:dark_prismarine
fill 142 9 332 142 12 332 minecraft:blue_terracotta
setblock 142 9 337 minecraft:purple_concrete
setblock 142 9 346 minecraft:dark_prismarine
fill 142 9 347 142 12 347 minecraft:blue_terracotta
setblock 142 9 351 minecraft:dark_prismarine
fill 142 9 352 142 12 352 minecraft:blue_terracotta
setblock 142 9 355 minecraft:blue_terracotta
setblock 142 9 356 minecraft:dark_prismarine
fill 142 9 357 142 12 357 minecraft:blue_terracotta
setblock 142 9 361 minecraft:dark_prismarine
fill 142 9 362 142 12 362 minecraft:blue_terracotta
setblock 143 9 325 minecraft:dark_prismarine
fill 143 9 326 143 11 326 minecraft:blue_terracotta
fill 143 9 346 143 12 346 minecraft:blue_terracotta
setblock 143 9 350 minecraft:dark_prismarine
fill 143 9 351 143 12 351 minecraft:blue_terracotta
setblock 143 9 355 minecraft:dark_prismarine
fill 143 9 356 143 12 356 minecraft:blue_terracotta
fill 143 9 358 143 10 358 minecraft:blue_terracotta
setblock 144 9 324 minecraft:dark_prismarine
setblock 144 9 349 minecraft:dark_prismarine
fill 144 9 350 144 12 350 minecraft:blue_terracotta
setblock 144 9 354 minecraft:dark_prismarine
fill 144 9 355 144 12 355 minecraft:blue_terracotta
setblock 145 9 323 minecraft:dark_prismarine
setblock 145 9 324 minecraft:blue_terracotta
setblock 145 9 363 minecraft:dark_prismarine
fill 146 9 323 146 11 323 minecraft:blue_terracotta
fill 146 9 335 146 9 336 minecraft:pink_terracotta
fill 146 9 363 146 12 363 minecraft:blue_terracotta
fill 147 9 335 147 33 336 minecraft:magenta_terracotta
fill 149 9 350 149 32 350 minecraft:magenta_terracotta
fill 149 9 351 150 9 351 minecraft:pink_terracotta
setblock 150 9 350 minecraft:pink_terracotta
fill 158 9 327 159 32 327 minecraft:magenta_terracotta
fill 158 9 328 159 9 328 minecraft:pink_terracotta
fill 158 9 330 158 33 330 minecraft:magenta_terracotta
setblock 160 9 363 minecraft:purple_concrete
setblock 164 9 323 minecraft:blue_terracotta
setblock 165 9 323 minecraft:dark_prismarine
fill 165 9 324 165 12 324 minecraft:blue_terracotta
fill 166 9 323 166 12 323 minecraft:blue_terracotta
fill 166 9 359 166 15 360 minecraft:magenta_terracotta
fill 167 9 359 167 18 359 minecraft:magenta_terracotta
setblock 169 9 324 minecraft:dark_prismarine
setblock 170 9 323 minecraft:dark_prismarine
setblock 170 9 324 minecraft:blue_terracotta
fill 171 9 323 171 10 323 minecraft:blue_terracotta
fill 175 9 324 175 14 324 minecraft:purple_concrete
fill 175 9 335 175 33 335 minecraft:magenta_terracotta
setblock 180 9 323 minecraft:dark_prismarine
setblock 180 9 324 minecraft:blue_terracotta
fill 181 9 323 181 12 323 minecraft:blue_terracotta
setblock 181 9 327 minecraft:dark_prismarine
fill 181 9 328 181 12 328 minecraft:blue_terracotta
setblock 182 9 326 minecraft:dark_prismarine
fill 182 9 327 182 12 327 minecraft:blue_terracotta
setblock 182 9 331 minecraft:dark_prismarine
fill 182 9 332 182 12 332 minecraft:blue_terracotta
fill 182 9 334 182 10 334 minecraft:blue_terracotta
fill 182 9 347 182 12 347 minecraft:blue_terracotta
setblock 182 9 350 minecraft:blue_terracotta
setblock 182 9 351 minecraft:dark_prismarine
fill 182 9 352 182 12 352 minecraft:blue_terracotta
setblock 182 9 355 minecraft:blue_terracotta
setblock 182 9 356 minecraft:dark_prismarine
fill 182 9 362 182 12 362 minecraft:blue_terracotta
fill 141 10 333 141 104 335 minecraft:black_concrete
setblock 141 10 336 minecraft:cyan_concrete
fill 141 10 337 141 131 337 minecraft:black_concrete
fill 141 10 349 141 96 349 minecraft:black_concrete
setblock 141 10 350 minecraft:light_blue_wool
setblock 142 10 324 minecraft:blue_terracotta
setblock 142 10 325 minecraft:dark_prismarine
fill 142 10 326 142 13 326 minecraft:blue_terracotta
setblock 142 10 330 minecraft:dark_prismarine
fill 142 10 331 142 13 331 minecraft:blue_terracotta
fill 142 10 333 142 11 333 minecraft:blue_terracotta
setblock 142 10 343 minecraft:purple_concrete
setblock 142 10 345 minecraft:dark_prismarine
fill 142 10 346 142 13 346 minecraft:blue_terracotta
setblock 142 10 350 minecraft:dark_prismarine
fill 142 10 351 142 13 351 minecraft:blue_terracotta
setblock 142 10 355 minecraft:dark_prismarine
fill 142 10 356 142 13 356 minecraft:blue_terracotta
setblock 142 10 360 minecraft:dark_prismarine
fill 142 10 361 142 13 361 minecraft:blue_terracotta
setblock 143 10 329 minecraft:dark_prismarine
fill 143 10 330 143 13 330 minecraft:blue_terracotta
setblock 143 10 349 minecraft:dark_prismarine
fill 143 10 350 143 13 350 minecraft:blue_terracotta
setblock 143 10 353 minecraft:blue_terracotta
setblock 143 10 354 minecraft:dark_prismarine
fill 143 10 355 143 13 355 minecraft:blue_terracotta
setblock 143 10 359 minecraft:dark_prismarine
fill 143 10 360 143 13 360 minecraft:blue_terracotta
setblock 144 10 323 minecraft:dark_prismarine
setblock 144 10 348 minecraft:dark_prismarine
fill 144 10 349 144 13 349 minecraft:blue_terracotta
setblock 144 10 353 minecraft:dark_prismarine
fill 144 10 354 144 13 354 minecraft:blue_terracotta
fill 144 10 356 144 11 356 minecraft:blue_terracotta
setblock 144 10 363 minecraft:dark_prismarine
fill 145 10 323 145 13 323 minecraft:blue_terracotta
setblock 145 10 351 minecraft:blue_terracotta
setblock 145 10 352 minecraft:dark_prismarine
fill 145 10 353 145 13 353 minecraft:blue_terracotta
fill 145 10 363 145 13 363 minecraft:blue_terracotta
fill 146 10 335 146 33 336 minecraft:magenta_terracotta
fill 148 10 349 148 33 349 minecraft:magenta_terracotta
fill 149 10 351 150 33 351 minecraft:magenta_terracotta
fill 150 10 350 150 33 350 minecraft:magenta_terracotta
setblock 158 10 323 minecraft:purple_concrete
fill 158 10 328 159 33 328 minecraft:magenta_terracotta
fill 159 10 330 159 33 330 minecraft:magenta_terracotta
setblock 164 10 323 minecraft:dark_prismarine
fill 165 10 323 165 13 323 minecraft:blue_terracotta
fill 165 10 358 166 33 358 minecraft:magenta_terracotta
setblock 166 10 363 minecraft:purple_concrete
setblock 168 10 324 minecraft:dark_prismarine
setblock 169 10 323 minecraft:dark_prismarine
setblock 169 10 324 minecraft:blue_terracotta
fill 170 10 323 170 13 323 minecraft:blue_terracotta
fill 173 10 334 174 19 334 minecraft:magenta_terracotta
setblock 173 10 364 minecraft:light_blue_wool
fill 174 10 335 174 33 336 minecraft:magenta_terracotta
setblock 177 10 323 minecraft:purple_concrete
fill 178 10 350 178 32 351 minecraft:magenta_terracotta
setblock 179 10 323 minecraft:dark_prismarine
fill 180 10 323 180 13 323 minecraft:blue_terracotta
setblock 181 10 326 minecraft:dark_prismarine
fill 181 10 327 181 13 327 minecraft:blue_terracotta
setblock 181 10 331 minecraft:dark_prismarine
fill 181 10 332 181 13 332 minecraft:blue_terracotta
setblock 182 10 325 minecraft:dark_prismarine
fill 182 10 326 182 13 326 minecraft:blue_terracotta
setblock 182 10 330 minecraft:dark_prismarine
fill 182 10 331 182 13 331 minecraft:blue_terracotta
setblock 182 10 343 minecraft:purple_concrete
setblock 182 10 350 minecraft:dark_prismarine
fill 182 10 351 182 13 351 minecraft:blue_terracotta
setblock 182 10 355 minecraft:dark_prismarine
fill 182 10 356 182 10 359 minecraft:blue_terracotta
setblock 182 10 360 minecraft:dark_prismarine
fill 182 10 361 182 13 361 minecraft:blue_terracotta
fill 141 11 336 141 70 336 minecraft:black_concrete
fill 141 11 350 141 131 350 minecraft:black_concrete
setblock 142 11 324 minecraft:dark_prismarine
fill 142 11 325 142 14 325 minecraft:blue_terracotta
setblock 142 11 329 minecraft:dark_prismarine
fill 142 11 330 142 14 330 minecraft:blue_terracotta
setblock 142 11 334 minecraft:dark_prismarine
fill 142 11 345 142 14 345 minecraft:blue_terracotta
setblock 142 11 349 minecraft:dark_prismarine
fill 142 11 350 142 14 350 minecraft:blue_terracotta
setblock 142 11 354 minecraft:dark_prismarine
fill 142 11 355 142 14 355 minecraft:blue_terracotta
setblock 142 11 359 minecraft:dark_prismarine
fill 142 11 360 142 14 360 minecraft:blue_terracotta
setblock 143 11 323 minecraft:dark_prismarine
setblock 143 11 328 minecraft:dark_prismarine
fill 143 11 329 143 14 329 minecraft:blue_terracotta
fill 143 11 331 143 12 331 minecraft:blue_terracotta
setblock 143 11 348 minecraft:dark_prismarine
fill 143 11 349 143 14 349 minecraft:blue_terracotta
setblock 143 11 353 minecraft:dark_prismarine
fill 143 11 354 143 14 354 minecraft:blue_terracotta
setblock 143 11 358 minecraft:dark_prismarine
fill 143 11 359 143 14 359 minecraft:blue_terracotta
fill 143 11 361 143 12 361 minecraft:blue_terracotta
setblock 143 11 363 minecraft:dark_prismarine
fill 144 11 323 144 14 323 minecraft:blue_terracotta
setblock 144 11 325 minecraft:light[level=12]
setblock 144 11 332 minecraft:light[level=12]
setblock 144 11 339 minecraft:light[level=12]
setblock 144 11 346 minecraft:light[level=12]
fill 144 11 348 144 14 348 minecraft:blue_terracotta
setblock 144 11 352 minecraft:dark_prismarine
fill 144 11 353 144 14 353 minecraft:blue_terracotta
setblock 144 11 357 minecraft:dark_prismarine
setblock 144 11 360 minecraft:light[level=12]
setblock 144 11 362 minecraft:dark_prismarine
fill 144 11 363 144 14 363 minecraft:blue_terracotta
setblock 145 11 350 minecraft:blue_terracotta
setblock 145 11 351 minecraft:dark_prismarine
fill 145 11 352 145 14 352 minecraft:blue_terracotta
fill 145 11 354 145 12 354 minecraft:blue_terracotta
setblock 151 11 325 minecraft:light[level=12]
setblock 151 11 332 minecraft:light[level=12]
setblock 151 11 339 minecraft:light[level=12]
setblock 151 11 346 minecraft:light[level=12]
setblock 151 11 353 minecraft:light[level=12]
setblock 151 11 360 minecraft:light[level=12]
setblock 152 11 323 minecraft:purple_concrete
setblock 153 11 363 minecraft:purple_concrete
setblock 158 11 325 minecraft:light[level=12]
setblock 158 11 332 minecraft:light[level=12]
setblock 158 11 339 minecraft:light[level=12]
setblock 158 11 346 minecraft:light[level=12]
setblock 158 11 353 minecraft:light[level=12]
setblock 158 11 360 minecraft:light[level=12]
setblock 163 11 323 minecraft:dark_prismarine
fill 164 11 323 164 14 323 minecraft:blue_terracotta
setblock 165 11 325 minecraft:light[level=12]
setblock 165 11 332 minecraft:light[level=12]
setblock 165 11 339 minecraft:light[level=12]
setblock 165 11 346 minecraft:light[level=12]
setblock 165 11 353 minecraft:light[level=12]
setblock 167 11 324 minecraft:dark_prismarine
setblock 168 11 323 minecraft:dark_prismarine
setblock 168 11 324 minecraft:blue_terracotta
fill 169 11 323 169 14 323 minecraft:blue_terracotta
setblock 171 11 323 minecraft:purple_concrete
setblock 172 11 325 minecraft:light[level=12]
setblock 172 11 332 minecraft:light[level=12]
setblock 172 11 339 minecraft:light[level=12]
setblock 172 11 346 minecraft:light[level=12]
setblock 172 11 353 minecraft:light[level=12]
setblock 172 11 360 minecraft:light[level=12]
setblock 172 11 363 minecraft:purple_concrete
fill 173 11 364 173 131 364 minecraft:black_concrete
fill 175 11 325 175 14 325 minecraft:purple_concrete
fill 176 11 350 176 33 351 minecraft:magenta_terracotta
setblock 178 11 323 minecraft:dark_prismarine
fill 179 11 323 179 14 323 minecraft:blue_terracotta
setblock 179 11 325 minecraft:light[level=12]
setblock 179 11 332 minecraft:light[level=12]
setblock 179 11 339 minecraft:light[level=12]
setblock 179 11 346 minecraft:light[level=12]
setblock 179 11 353 minecraft:light[level=12]
setblock 179 11 360 minecraft:light[level=12]
fill 180 11 324 180 12 324 minecraft:blue_terracotta
setblock 181 11 325 minecraft:dark_prismarine
fill 181 11 326 181 14 326 minecraft:blue_terracotta
setblock 181 11 330 minecraft:dark_prismarine
fill 181 11 331 181 14 331 minecraft:blue_terracotta
fill 181 11 333 181 12 333 minecraft:blue_terracotta
fill 181 11 353 182 11 353 minecraft:blue_terracotta
fill 181 11 363 181 12 363 minecraft:blue_terracotta
setblock 182 11 324 minecraft:dark_prismarine
fill 182 11 325 182 14 325 minecraft:blue_terracotta
setblock 182 11 329 minecraft:dark_prismarine
fill 182 11 330 182 14 330 minecraft:blue_terracotta
setblock 182 11 334 minecraft:dark_prismarine
fill 182 11 335 182 14 335 minecraft:blue_terracotta
setblock 182 11 337 minecraft:purple_concrete
setblock 182 11 349 minecraft:dark_prismarine
fill 182 11 350 182 14 350 minecraft:blue_terracotta
setblock 182 11 354 minecraft:dark_prismarine
fill 182 11 355 182 11 358 minecraft:blue_terracotta
setblock 182 11 359 minecraft:dark_prismarine
fill 182 11 360 182 14 360 minecraft:blue_terracotta
fill 141 12 352 141 17 354 minecraft:black_concrete
setblock 141 12 355 minecraft:light_blue_wool
fill 141 12 356 141 37 362 minecraft:black_concrete
setblock 142 12 323 minecraft:dark_prismarine
fill 142 12 324 142 15 324 minecraft:blue_terracotta
setblock 142 12 328 minecraft:dark_prismarine
fill 142 12 329 142 15 329 minecraft:blue_terracotta
setblock 142 12 333 minecraft:dark_prismarine
fill 142 12 334 142 13 336 minecraft:blue_terracotta
fill 142 12 344 142 15 344 minecraft:blue_terracotta
setblock 142 12 348 minecraft:dark_prismarine
fill 142 12 349 142 15 349 minecraft:blue_terracotta
setblock 142 12 353 minecraft:dark_prismarine
fill 142 12 354 142 15 354 minecraft:blue_terracotta
setblock 142 12 358 minecraft:dark_prismarine
fill 142 12 359 142 15 359 minecraft:blue_terracotta
setblock 142 12 363 minecraft:dark_prismarine
fill 143 12 323 143 15 323 minecraft:blue_terracotta
setblock 143 12 327 minecraft:dark_prismarine
fill 143 12 328 143 15 328 minecraft:blue_terracotta
setblock 143 12 332 minecraft:dark_prismarine
fill 143 12 333 143 15 333 minecraft:blue_terracotta
setblock 143 12 347 minecraft:dark_prismarine
fill 143 12 348 143 15 348 minecraft:blue_terracotta
setblock 143 12 352 minecraft:dark_prismarine
fill 143 12 353 143 15 353 minecraft:blue_terracotta
setblock 143 12 357 minecraft:dark_prismarine
fill 143 12 358 144 14 358 minecraft:blue_terracotta
setblock 143 12 362 minecraft:dark_prismarine
fill 143 12 363 143 15 363 minecraft:blue_terracotta
setblock 144 12 351 minecraft:dark_prismarine
fill 144 12 352 144 15 352 minecraft:blue_terracotta
setblock 144 12 356 minecraft:dark_prismarine
fill 144 12 357 144 15 357 minecraft:blue_terracotta
fill 144 12 359 144 13 359 minecraft:blue_terracotta
fill 144 12 362 145 14 362 minecraft:blue_terracotta
setblock 145 12 350 minecraft:dark_prismarine
fill 145 12 351 145 15 351 minecraft:blue_terracotta
setblock 145 12 355 minecraft:dark_prismarine
setblock 146 12 323 minecraft:purple_concrete
setblock 147 12 363 minecraft:dark_prismarine
fill 158 12 326 158 19 326 minecraft:magenta_terracotta
setblock 159 12 363 minecraft:purple_concrete
setblock 162 12 323 minecraft:dark_prismarine
fill 163 12 323 163 15 323 minecraft:blue_terracotta
fill 164 12 324 164 13 324 minecraft:blue_terracotta
setblock 166 12 324 minecraft:dark_prismarine
setblock 167 12 323 minecraft:dark_prismarine
fill 167 12 324 167 13 324 minecraft:blue_terracotta
fill 168 12 323 168 15 323 minecraft:blue_terracotta
fill 178 12 323 178 15 323 minecraft:blue_terracotta
setblock 178 12 363 minecraft:purple_concrete
fill 180 12 363 180 13 363 minecraft:blue_terracotta
setblock 181 12 324 minecraft:dark_prismarine
fill 181 12 325 181 15 325 minecraft:blue_terracotta
setblock 181 12 329 minecraft:dark_prismarine
fill 181 12 330 181 15 330 minecraft:blue_terracotta
setblock 181 12 334 minecraft:dark_prismarine
fill 181 12 351 181 12 353 minecraft:blue_terracotta
setblock 181 12 354 minecraft:dark_prismarine
fill 181 12 355 181 12 358 minecraft:blue_terracotta
setblock 182 12 323 minecraft:dark_prismarine
fill 182 12 324 182 15 324 minecraft:blue_terracotta
setblock 182 12 328 minecraft:dark_prismarine
fill 182 12 329 182 15 329 minecraft:blue_terracotta
setblock 182 12 333 minecraft:dark_prismarine
fill 182 12 334 182 15 334 minecraft:blue_terracotta
fill 182 12 336 182 13 336 minecraft:blue_terracotta
setblock 182 12 348 minecraft:dark_prismarine
fill 182 12 349 182 15 349 minecraft:blue_terracotta
setblock 182 12 353 minecraft:dark_prismarine
fill 182 12 354 182 12 357 minecraft:blue_terracotta
setblock 182 12 358 minecraft:dark_prismarine
fill 182 12 359 182 15 359 minecraft:blue_terracotta
setblock 182 12 363 minecraft:dark_prismarine
fill 141 13 355 141 131 355 minecraft:black_concrete
fill 142 13 323 142 16 323 minecraft:blue_terracotta
setblock 142 13 327 minecraft:dark_prismarine
fill 142 13 328 142 16 328 minecraft:blue_terracotta
setblock 142 13 332 minecraft:dark_prismarine
fill 142 13 333 142 16 333 minecraft:blue_terracotta
setblock 142 13 337 minecraft:dark_prismarine
fill 142 13 338 142 15 339 minecraft:blue_terracotta
setblock 142 13 342 minecraft:purple_concrete
fill 142 13 343 142 16 343 minecraft:blue_terracotta
setblock 142 13 347 minecraft:dark_prismarine
fill 142 13 348 142 16 348 minecraft:blue_terracotta
setblock 142 13 352 minecraft:dark_prismarine
fill 142 13 353 142 16 353 minecraft:blue_terracotta
setblock 142 13 357 minecraft:dark_prismarine
fill 142 13 358 142 16 358 minecraft:blue_terracotta
setblock 142 13 362 minecraft:dark_prismarine
fill 142 13 363 142 16 363 minecraft:blue_terracotta
fill 143 13 327 143 14 327 minecraft:blue_terracotta
setblock 143 13 331 minecraft:dark_prismarine
fill 143 13 332 143 16 332 minecraft:blue_terracotta
fill 143 13 334 143 13 335 minecraft:blue_terracotta
setblock 143 13 346 minecraft:dark_prismarine
fill 143 13 347 143 16 347 minecraft:blue_terracotta
setblock 143 13 351 minecraft:dark_prismarine
fill 143 13 352 143 16 352 minecraft:blue_terracotta
setblock 143 13 356 minecraft:dark_prismarine
fill 143 13 357 143 16 357 minecraft:blue_terracotta
setblock 143 13 361 minecraft:dark_prismarine
fill 143 13 362 143 16 362 minecraft:blue_terracotta
setblock 144 13 325 minecraft:light[level=13]
setblock 144 13 333 minecraft:light[level=13]
setblock 144 13 341 minecraft:light[level=13]
setblock 144 13 350 minecraft:dark_prismarine
fill 144 13 351 144 16 351 minecraft:blue_terracotta
setblock 144 13 355 minecraft:dark_prismarine
fill 144 13 356 145 15 356 minecraft:blue_terracotta
setblock 144 13 360 minecraft:dark_prismarine
fill 145 13 350 145 15 350 minecraft:blue_terracotta
setblock 145 13 354 minecraft:dark_prismarine
fill 145 13 355 145 16 355 minecraft:blue_terracotta
setblock 146 13 363 minecraft:dark_prismarine
fill 147 13 363 147 16 363 minecraft:blue_terracotta
fill 148 13 338 148 14 338 minecraft:sea_lantern
setblock 152 13 325 minecraft:light[level=13]
setblock 152 13 333 minecraft:light[level=13]
setblock 152 13 341 minecraft:light[level=13]
setblock 152 13 349 minecraft:light[level=13]
setblock 152 13 357 minecraft:light[level=13]
setblock 159 13 323 minecraft:purple_concrete
setblock 160 13 325 minecraft:light[level=13]
setblock 160 13 333 minecraft:light[level=13]
setblock 160 13 349 minecraft:light[level=13]
setblock 160 13 357 minecraft:light[level=13]
fill 162 13 323 162 16 323 minecraft:blue_terracotta
setblock 165 13 324 minecraft:dark_prismarine
setblock 165 13 363 minecraft:purple_concrete
setblock 166 13 323 minecraft:dark_prismarine
fill 166 13 324 166 16 324 minecraft:blue_terracotta
fill 167 13 323 167 16 323 minecraft:blue_terracotta
setblock 168 13 325 minecraft:light[level=13]
setblock 168 13 333 minecraft:light[level=13]
setblock 168 13 341 minecraft:light[level=13]
setblock 168 13 349 minecraft:light[level=13]
setblock 168 13 357 minecraft:light[level=13]
fill 174 13 324 174 14 325 minecraft:purple_concrete
fill 175 13 323 175 14 323 minecraft:purple_concrete
fill 176 13 324 176 14 325 minecraft:purple_concrete
setblock 176 13 333 minecraft:light[level=13]
setblock 176 13 341 minecraft:light[level=13]
setblock 176 13 349 minecraft:light[level=13]
fill 177 13 323 177 16 323 minecraft:blue_terracotta
fill 179 13 363 179 14 363 minecraft:blue_terracotta
setblock 180 13 324 minecraft:dark_prismarine
setblock 180 13 328 minecraft:blue_terracotta
setblock 180 13 329 minecraft:dark_prismarine
fill 180 13 330 180 15 331 minecraft:blue_terracotta
setblock 181 13 323 minecraft:dark_prismarine
fill 181 13 324 181 16 324 minecraft:blue_terracotta
setblock 181 13 328 minecraft:dark_prismarine
fill 181 13 329 181 16 329 minecraft:blue_terracotta
setblock 181 13 333 minecraft:dark_prismarine
fill 181 13 334 181 15 335 minecraft:blue_terracotta
fill 181 13 350 181 13 352 minecraft:blue_terracotta
setblock 181 13 353 minecraft:dark_prismarine
fill 181 13 354 181 13 357 minecraft:blue_terracotta
setblock 181 13 358 minecraft:dark_prismarine
fill 181 13 359 181 13 362 minecraft:blue_terracotta
setblock 181 13 363 minecraft:dark_prismarine
fill 182 13 323 182 16 323 minecraft:blue_terracotta
setblock 182 13 327 minecraft:dark_prismarine
fill 182 13 328 182 16 328 minecraft:blue_terracotta
setblock 182 13 332 minecraft:dark_prismarine
fill 182 13 333 182 16 333 minecraft:blue_terracotta
setblock 182 13 337 minecraft:dark_prismarine
fill 182 13 338 182 16 338 minecraft:blue_terracotta
setblock 182 13 344 minecraft:purple_concrete
setblock 182 13 346 minecraft:blue_terracotta
setblock 182 13 347 minecraft:dark_prismarine
fill 182 13 348 182 16 348 minecraft:blue_terracotta
setblock 182 13 352 minecraft:dark_prismarine
fill 182 13 353 182 13 356 minecraft:blue_terracotta
setblock 182 13 357 minecraft:dark_prismarine
fill 182 13 358 182 16 358 minecraft:blue_terracotta
setblock 182 13 362 minecraft:dark_prismarine
fill 182 13 363 182 16 363 minecraft:blue_terracotta
setblock 142 14 326 minecraft:dark_prismarine
fill 142 14 327 142 17 327 minecraft:blue_terracotta
setblock 142 14 331 minecraft:dark_prismarine
fill 142 14 332 142 17 332 minecraft:blue_terracotta
fill 142 14 334 142 14 335 minecraft:blue_terracotta
setblock 142 14 336 minecraft:dark_prismarine
fill 142 14 337 143 16 337 minecraft:blue_terracotta
setblock 142 14 340 minecraft:blue_terracotta
setblock 142 14 341 minecraft:dark_prismarine
fill 142 14 342 142 17 342 minecraft:blue_terracotta
setblock 142 14 346 minecraft:dark_prismarine
fill 142 14 347 142 17 347 minecraft:blue_terracotta
setblock 142 14 351 minecraft:dark_prismarine
fill 142 14 352 142 17 352 minecraft:blue_terracotta
setblock 142 14 356 minecraft:dark_prismarine
fill 142 14 357 142 17 357 minecraft:blue_terracotta
setblock 142 14 361 minecraft:dark_prismarine
fill 142 14 362 142 17 362 minecraft:blue_terracotta
setblock 143 14 330 minecraft:dark_prismarine
fill 143 14 331 143 17 331 minecraft:blue_terracotta
setblock 143 14 334 minecraft:blue_terracotta
setblock 143 14 335 minecraft:dark_prismarine
fill 143 14 336 143 17 336 minecraft:blue_terracotta
setblock 143 14 345 minecraft:dark_prismarine
fill 143 14 346 143 17 346 minecraft:blue_terracotta
setblock 143 14 350 minecraft:dark_prismarine
fill 143 14 351 143 17 351 minecraft:blue_terracotta
setblock 143 14 355 minecraft:dark_prismarine
fill 143 14 356 143 17 356 minecraft:blue_terracotta
setblock 143 14 360 minecraft:dark_prismarine
fill 143 14 361 144 16 361 minecraft:blue_terracotta
setblock 144 14 349 minecraft:dark_prismarine
fill 144 14 350 144 17 350 minecraft:blue_terracotta
setblock 144 14 354 minecraft:dark_prismarine
fill 144 14 355 144 17 355 minecraft:blue_terracotta
setblock 144 14 359 minecraft:dark_prismarine
fill 144 14 360 144 17 360 minecraft:blue_terracotta
setblock 145 14 353 minecraft:dark_prismarine
fill 145 14 354 145 17 354 minecraft:blue_terracotta
setblock 145 14 357 minecraft:blue_terracotta
setblock 145 14 363 minecraft:dark_prismarine
fill 146 14 363 146 17 363 minecraft:blue_terracotta
setblock 153 14 323 minecraft:purple_concrete
fill 161 14 323 161 17 323 minecraft:blue_terracotta
setblock 163 14 324 minecraft:blue_terracotta
fill 163 14 358 163 33 358 minecraft:magenta_terracotta
setblock 164 14 324 minecraft:dark_prismarine
fill 164 14 356 164 33 356 minecraft:magenta_terracotta
setblock 165 14 323 minecraft:dark_prismarine
fill 165 14 324 165 17 324 minecraft:blue_terracotta
fill 166 14 323 166 17 323 minecraft:blue_terracotta
setblock 170 14 323 minecraft:dark_prismarine
setblock 171 14 363 minecraft:purple_concrete
fill 176 14 323 176 15 323 minecraft:blue_terracotta
fill 176 14 337 176 33 337 minecraft:magenta_terracotta
fill 178 14 363 178 15 363 minecraft:blue_terracotta
setblock 179 14 324 minecraft:dark_prismarine
setblock 180 14 323 minecraft:dark_prismarine
fill 180 14 324 180 17 324 minecraft:blue_terracotta
setblock 180 14 328 minecraft:dark_prismarine
fill 180 14 329 180 17 329 minecraft:blue_terracotta
setblock 180 14 332 minecraft:blue_terracotta
setblock 180 14 333 minecraft:dark_prismarine
setblock 180 14 353 minecraft:dark_prismarine
fill 180 14 354 180 14 357 minecraft:blue_terracotta
setblock 180 14 358 minecraft:dark_prismarine
setblock 180 14 362 minecraft:blue_terracotta
setblock 180 14 363 minecraft:dark_prismarine
fill 181 14 323 181 17 323 minecraft:blue_terracotta
setblock 181 14 327 minecraft:dark_prismarine
fill 181 14 328 181 17 328 minecraft:blue_terracotta
setblock 181 14 332 minecraft:dark_prismarine
fill 181 14 333 181 17 333 minecraft:blue_terracotta
setblock 181 14 336 minecraft:blue_terracotta
fill 181 14 349 181 14 351 minecraft:blue_terracotta
setblock 181 14 352 minecraft:dark_prismarine
fill 181 14 353 181 14 356 minecraft:blue_terracotta
setblock 181 14 357 minecraft:dark_prismarine
fill 181 14 358 181 14 361 minecraft:blue_terracotta
setblock 181 14 362 minecraft:dark_prismarine
fill 181 14 363 181 17 363 minecraft:blue_terracotta
setblock 182 14 326 minecraft:dark_prismarine
fill 182 14 327 182 17 327 minecraft:blue_terracotta
setblock 182 14 331 minecraft:dark_prismarine
fill 182 14 332 182 17 332 minecraft:blue_terracotta
setblock 182 14 336 minecraft:dark_prismarine
fill 182 14 337 182 17 337 minecraft:blue_terracotta
fill 182 14 339 182 15 339 minecraft:blue_terracotta
setblock 182 14 346 minecraft:dark_prismarine
fill 182 14 347 182 17 347 minecraft:blue_terracotta
setblock 182 14 351 minecraft:dark_prismarine
fill 182 14 352 182 14 355 minecraft:blue_terracotta
setblock 182 14 356 minecraft:dark_prismarine
fill 182 14 357 182 17 357 minecraft:blue_terracotta
setblock 182 14 361 minecraft:dark_prismarine
fill 182 14 362 182 17 362 minecraft:blue_terracotta
setblock 142 15 325 minecraft:dark_prismarine
fill 142 15 326 142 18 326 minecraft:blue_terracotta
setblock 142 15 330 minecraft:dark_prismarine
fill 142 15 331 142 18 331 minecraft:blue_terracotta
setblock 142 15 334 minecraft:blue_terracotta
setblock 142 15 335 minecraft:dark_prismarine
fill 142 15 336 142 18 336 minecraft:blue_terracotta
setblock 142 15 340 minecraft:dark_prismarine
fill 142 15 341 142 18 341 minecraft:blue_terracotta
setblock 142 15 345 minecraft:dark_prismarine
fill 142 15 346 142 18 346 minecraft:blue_terracotta
setblock 142 15 350 minecraft:dark_prismarine
fill 142 15 351 142 18 351 minecraft:blue_terracotta
setblock 142 15 355 minecraft:dark_prismarine
fill 142 15 356 142 18 356 minecraft:blue_terracotta
setblock 142 15 360 minecraft:dark_prismarine
fill 142 15 361 142 18 361 minecraft:blue_terracotta
setblock 143 15 329 minecraft:dark_prismarine
fill 143 15 330 143 17 330 minecraft:blue_terracotta
setblock 143 15 334 minecraft:dark_prismarine
fill 143 15 335 143 18 335 minecraft:blue_terracotta
setblock 143 15 338 minecraft:blue_terracotta
setblock 143 15 339 minecraft:dark_prismarine
fill 143 15 340 143 18 340 minecraft:blue_terracotta
setblock 143 15 344 minecraft:dark_prismarine
fill 143 15 345 143 18 345 minecraft:blue_terracotta
setblock 143 15 349 minecraft:dark_prismarine
fill 143 15 350 143 18 350 minecraft:blue_terracotta
setblock 143 15 354 minecraft:dark_prismarine
fill 143 15 355 143 18 355 minecraft:blue_terracotta
setblock 143 15 358 minecraft:blue_terracotta
setblock 143 15 359 minecraft:dark_prismarine
fill 143 15 360 143 18 360 minecraft:blue_terracotta
setblock 144 15 323 minecraft:dark_prismarine
setblock 144 15 333 minecraft:dark_prismarine
setblock 144 15 348 minecraft:dark_prismarine
fill 144 15 349 144 18 349 minecraft:blue_terracotta
setblock 144 15 353 minecraft:dark_prismarine
fill 144 15 354 144 18 354 minecraft:blue_terracotta
setblock 144 15 358 minecraft:dark_prismarine
fill 144 15 359 144 18 359 minecraft:blue_terracotta
setblock 144 15 362 minecraft:blue_terracotta
setblock 144 15 363 minecraft:dark_prismarine
setblock 145 15 352 minecraft:dark_prismarine
fill 145 15 353 145 17 353 minecraft:blue_terracotta
setblock 145 15 357 minecraft:dark_prismarine
fill 145 15 358 145 18 358 minecraft:blue_terracotta
setblock 145 15 362 minecraft:dark_prismarine
fill 145 15 363 145 18 363 minecraft:blue_terracotta
fill 146 15 362 146 18 362 minecraft:blue_terracotta
setblock 147 15 323 minecraft:purple_concrete
fill 148 15 338 148 22 338 minecraft:black_concrete
setblock 152 15 363 minecraft:purple_concrete
fill 159 15 322 163 23 322 minecraft:black_concrete
fill 160 15 323 160 18 323 minecraft:blue_terracotta
fill 161 15 328 161 33 328 minecraft:magenta_terracotta
setblock 162 15 324 minecraft:blue_terracotta
fill 162 15 363 163 15 363 minecraft:blue_terracotta
setblock 163 15 324 minecraft:dark_prismarine
setblock 164 15 322 minecraft:cyan_concrete
setblock 164 15 323 minecraft:dark_prismarine
fill 164 15 324 164 18 324 minecraft:blue_terracotta
setblock 164 15 363 minecraft:dark_prismarine
fill 165 15 322 166 38 322 minecraft:black_concrete
fill 165 15 323 165 18 323 minecraft:blue_terracotta
fill 165 15 363 165 18 363 minecraft:blue_terracotta
setblock 169 15 323 minecraft:dark_prismarine
setblock 170 15 323 minecraft:blue_terracotta
fill 170 15 324 178 15 326 minecraft:dark_prismarine
fill 171 15 323 171 16 323 minecraft:dark_prismarine
setblock 172 15 323 minecraft:purple_concrete
fill 173 15 323 174 15 323 minecraft:dark_prismarine
fill 175 15 323 175 18 323 minecraft:blue_terracotta
fill 176 15 349 176 18 349 minecraft:magenta_terracotta
fill 176 15 363 177 16 363 minecraft:blue_terracotta
fill 178 15 362 179 15 362 minecraft:blue_terracotta
setblock 179 15 323 minecraft:dark_prismarine
setblock 179 15 324 minecraft:blue_terracotta
fill 179 15 325 180 15 326 minecraft:dark_prismarine
setblock 179 15 363 minecraft:dark_prismarine
setblock 180 15 323 minecraft:blue_terracotta
fill 180 15 328 180 16 328 minecraft:blue_terracotta
setblock 180 15 332 minecraft:dark_prismarine
fill 180 15 333 180 17 334 minecraft:blue_terracotta
setblock 180 15 352 minecraft:dark_prismarine
fill 180 15 353 180 15 356 minecraft:blue_terracotta
setblock 180 15 357 minecraft:dark_prismarine
fill 180 15 358 180 15 361 minecraft:blue_terracotta
setblock 180 15 362 minecraft:dark_prismarine
fill 180 15 363 180 18 363 minecraft:blue_terracotta
setblock 181 15 326 minecraft:dark_prismarine
fill 181 15 327 181 18 327 minecraft:blue_terracotta
setblock 181 15 331 minecraft:dark_prismarine
fill 181 15 332 181 18 332 minecraft:blue_terracotta
setblock 181 15 336 minecraft:dark_prismarine
fill 181 15 337 181 18 337 minecraft:blue_terracotta
fill 181 15 349 181 15 350 minecraft:blue_terracotta
setblock 181 15 351 minecraft:dark_prismarine
fill 181 15 352 181 15 355 minecraft:blue_terracotta
setblock 181 15 356 minecraft:dark_prismarine
fill 181 15 357 181 15 360 minecraft:blue_terracotta
setblock 181 15 361 minecraft:dark_prismarine
fill 181 15 362 181 18 362 minecraft:blue_terracotta
setblock 182 15 325 minecraft:dark_prismarine
fill 182 15 326 182 18 326 minecraft:blue_terracotta
setblock 182 15 330 minecraft:dark_prismarine
fill 182 15 331 182 18 331 minecraft:blue_terracotta
setblock 182 15 335 minecraft:dark_prismarine
fill 182 15 336 182 18 336 minecraft:blue_terracotta
setblock 182 15 340 minecraft:dark_prismarine
fill 182 15 341 182 18 341 minecraft:blue_terracotta
setblock 182 15 345 minecraft:dark_prismarine
fill 182 15 346 182 18 346 minecraft:blue_terracotta
setblock 182 15 350 minecraft:dark_prismarine
fill 182 15 351 182 15 354 minecraft:blue_terracotta
setblock 182 15 355 minecraft:dark_prismarine
fill 182 15 356 182 18 356 minecraft:blue_terracotta
setblock 182 15 360 minecraft:dark_prismarine
fill 182 15 361 182 18 361 minecraft:blue_terracotta
fill 141 16 327 141 131 327 minecraft:black_concrete
setblock 141 16 328 minecraft:cyan_concrete
setblock 142 16 324 minecraft:dark_prismarine
fill 142 16 325 142 18 325 minecraft:blue_terracotta
setblock 142 16 329 minecraft:dark_prismarine
fill 142 16 330 142 19 330 minecraft:blue_terracotta
setblock 142 16 334 minecraft:dark_prismarine
fill 142 16 335 142 19 335 minecraft:blue_terracotta
setblock 142 16 338 minecraft:blue_terracotta
setblock 142 16 339 minecraft:dark_prismarine
fill 142 16 340 142 19 340 minecraft:blue_terracotta
setblock 142 16 344 minecraft:dark_prismarine
fill 142 16 345 142 19 345 minecraft:blue_terracotta
setblock 142 16 349 minecraft:dark_prismarine
fill 142 16 350 142 19 350 minecraft:blue_terracotta
setblock 142 16 354 minecraft:dark_prismarine
fill 142 16 355 142 19 355 minecraft:blue_terracotta
setblock 142 16 359 minecraft:dark_prismarine
fill 142 16 360 142 19 360 minecraft:blue_terracotta
setblock 143 16 323 minecraft:dark_prismarine
setblock 143 16 328 minecraft:dark_prismarine
fill 143 16 329 143 17 329 minecraft:blue_terracotta
setblock 143 16 333 minecraft:dark_prismarine
fill 143 16 334 144 17 334 minecraft:blue_terracotta
setblock 143 16 338 minecraft:dark_prismarine
fill 143 16 339 143 19 339 minecraft:blue_terracotta
fill 143 16 341 143 16 342 minecraft:blue_terracotta
setblock 143 16 343 minecraft:dark_prismarine
fill 143 16 344 143 19 344 minecraft:blue_terracotta
setblock 143 16 348 minecraft:dark_prismarine
fill 143 16 349 143 19 349 minecraft:blue_terracotta
setblock 143 16 353 minecraft:dark_prismarine
fill 143 16 354 143 19 354 minecraft:blue_terracotta
setblock 143 16 358 minecraft:dark_prismarine
fill 143 16 359 143 19 359 minecraft:blue_terracotta
setblock 143 16 363 minecraft:dark_prismarine
setblock 144 16 323 minecraft:blue_terracotta
setblock 144 16 333 minecraft:blue_terracotta
fill 144 16 348 144 17 348 minecraft:blue_terracotta
setblock 144 16 352 minecraft:dark_prismarine
fill 144 16 353 144 19 353 minecraft:blue_terracotta
setblock 144 16 356 minecraft:blue_terracotta
setblock 144 16 357 minecraft:dark_prismarine
fill 144 16 358 144 19 358 minecraft:blue_terracotta
setblock 144 16 362 minecraft:dark_prismarine
fill 144 16 363 144 19 363 minecraft:blue_terracotta
setblock 145 16 351 minecraft:dark_prismarine
fill 145 16 352 145 17 352 minecraft:blue_terracotta
setblock 145 16 356 minecraft:dark_prismarine
fill 145 16 357 145 18 357 minecraft:blue_terracotta
setblock 145 16 361 minecraft:dark_prismarine
fill 145 16 362 145 19 362 minecraft:blue_terracotta
setblock 158 16 363 minecraft:purple_concrete
fill 159 16 323 159 19 323 minecraft:blue_terracotta
fill 160 16 363 162 16 363 minecraft:blue_terracotta
setblock 161 16 324 minecraft:blue_terracotta
setblock 162 16 324 minecraft:dark_prismarine
setblock 163 16 323 minecraft:dark_prismarine
fill 163 16 324 163 19 324 minecraft:blue_terracotta
fill 163 16 357 163 33 357 minecraft:magenta_terracotta
setblock 163 16 363 minecraft:dark_prismarine
fill 164 16 322 164 129 322 minecraft:black_concrete
fill 164 16 323 164 19 323 minecraft:blue_terracotta
fill 164 16 363 164 19 363 minecraft:blue_terracotta
fill 166 16 359 166 28 359 minecraft:magenta_terracotta
fill 166 16 363 166 17 363 minecraft:blue_terracotta
setblock 168 16 323 minecraft:dark_prismarine
fill 169 16 323 169 19 323 minecraft:blue_terracotta
setblock 170 16 323 minecraft:sea_lantern
fill 170 16 324 170 26 324 minecraft:dark_prismarine
setblock 170 16 325 minecraft:sea_lantern
fill 170 16 326 170 28 326 minecraft:dark_prismarine
setblock 171 16 324 minecraft:sea_lantern
fill 171 16 325 171 28 325 minecraft:dark_prismarine
setblock 171 16 326 minecraft:sea_lantern
setblock 172 16 323 minecraft:sea_lantern
fill 172 16 324 172 26 324 minecraft:dark_prismarine
setblock 172 16 325 minecraft:sea_lantern
fill 172 16 326 172 28 326 minecraft:dark_prismarine
setblock 173 16 323 minecraft:dark_prismarine
setblock 173 16 324 minecraft:sea_lantern
fill 173 16 325 173 27 325 minecraft:dark_prismarine
setblock 173 16 326 minecraft:sea_lantern
setblock 174 16 323 minecraft:sea_lantern
fill 174 16 324 174 24 324 minecraft:dark_prismarine
setblock 174 16 325 minecraft:sea_lantern
fill 174 16 326 174 28 326 minecraft:dark_prismarine
fill 174 16 346 174 17 346 minecraft:dark_prismarine
setblock 175 16 324 minecraft:sea_lantern
fill 175 16 325 175 27 325 minecraft:dark_prismarine
setblock 175 16 326 minecraft:sea_lantern
fill 175 16 363 175 18 363 minecraft:blue_terracotta
setblock 176 16 323 minecraft:sea_lantern
fill 176 16 324 176 22 324 minecraft:dark_prismarine
setblock 176 16 325 minecraft:sea_lantern
fill 176 16 326 176 28 326 minecraft:dark_prismarine
setblock 177 16 324 minecraft:sea_lantern
fill 177 16 325 177 28 325 minecraft:dark_prismarine
setblock 177 16 326 minecraft:sea_lantern
fill 177 16 362 178 16 362 minecraft:blue_terracotta
setblock 178 16 323 minecraft:sea_lantern
fill 178 16 324 178 19 324 minecraft:blue_terracotta
setblock 178 16 325 minecraft:sea_lantern
fill 178 16 326 178 28 326 minecraft:dark_prismarine
setblock 178 16 363 minecraft:dark_prismarine
fill 179 16 323 179 19 323 minecraft:blue_terracotta
setblock 179 16 324 minecraft:sea_lantern
fill 179 16 325 179 28 325 minecraft:dark_prismarine
setblock 179 16 326 minecraft:sea_lantern
setblock 179 16 361 minecraft:blue_terracotta
setblock 179 16 362 minecraft:dark_prismarine
fill 179 16 363 179 19 363 minecraft:blue_terracotta
setblock 180 16 323 minecraft:sea_lantern
setblock 180 16 325 minecraft:sea_lantern
fill 180 16 326 180 28 326 minecraft:dark_prismarine
setblock 180 16 330 minecraft:blue_terracotta
setblock 180 16 331 minecraft:dark_prismarine
fill 180 16 332 180 18 332 minecraft:blue_terracotta
setblock 180 16 335 minecraft:blue_terracotta
fill 180 16 352 180 16 355 minecraft:blue_terracotta
setblock 180 16 356 minecraft:dark_prismarine
fill 180 16 357 180 16 360 minecraft:blue_terracotta
setblock 180 16 361 minecraft:dark_prismarine
fill 180 16 362 180 19 362 minecraft:blue_terracotta
setblock 181 16 325 minecraft:dark_prismarine
fill 181 16 326 181 19 326 minecraft:blue_terracotta
setblock 181 16 330 minecraft:dark_prismarine
fill 181 16 331 181 19 331 minecraft:blue_terracotta
setblock 181 16 334 minecraft:blue_terracotta
setblock 181 16 335 minecraft:dark_prismarine
fill 181 16 336 181 19 336 minecraft:blue_terracotta
fill 181 16 338 181 16 339 minecraft:blue_terracotta
setblock 181 16 349 minecraft:blue_terracotta
setblock 181 16 350 minecraft:dark_prismarine
fill 181 16 351 181 16 354 minecraft:blue_terracotta
setblock 181 16 355 minecraft:dark_prismarine
fill 181 16 356 181 16 359 minecraft:blue_terracotta
setblock 181 16 360 minecraft:dark_prismarine
fill 181 16 361 181 19 361 minecraft:blue_terracotta
fill 181 16 364 181 68 364 minecraft:black_concrete
setblock 182 16 324 minecraft:dark_prismarine
fill 182 16 325 182 19 325 minecraft:blue_terracotta
setblock 182 16 329 minecraft:dark_prismarine
fill 182 16 330 182 19 330 minecraft:blue_terracotta
setblock 182 16 334 minecraft:dark_prismarine
fill 182 16 335 182 19 335 minecraft:blue_terracotta
setblock 182 16 339 minecraft:dark_prismarine
fill 182 16 340 182 19 340 minecraft:blue_terracotta
fill 182 16 342 182 16 343 minecraft:blue_terracotta
setblock 182 16 344 minecraft:dark_prismarine
fill 182 16 345 182 19 345 minecraft:blue_terracotta
setblock 182 16 349 minecraft:dark_prismarine
fill 182 16 350 182 16 353 minecraft:blue_terracotta
setblock 182 16 354 minecraft:dark_prismarine
fill 182 16 355 182 19 355 minecraft:blue_terracotta
setblock 182 16 359 minecraft:dark_prismarine
fill 182 16 360 182 19 360 minecraft:blue_terracotta
setblock 182 16 364 minecraft:light_blue_wool
fill 183 16 364 183 132 364 minecraft:black_concrete
fill 141 17 328 141 116 328 minecraft:black_concrete
setblock 142 17 323 minecraft:dark_prismarine
fill 142 17 324 142 18 324 minecraft:blue_terracotta
setblock 142 17 328 minecraft:dark_prismarine
fill 142 17 329 142 19 329 minecraft:blue_terracotta
setblock 142 17 333 minecraft:dark_prismarine
fill 142 17 334 142 20 334 minecraft:blue_terracotta
setblock 142 17 337 minecraft:blue_terracotta
setblock 142 17 338 minecraft:dark_prismarine
fill 142 17 339 142 20 339 minecraft:blue_terracotta
setblock 142 17 343 minecraft:dark_prismarine
fill 142 17 344 142 20 344 minecraft:blue_terracotta
setblock 142 17 348 minecraft:dark_prismarine
fill 142 17 349 142 20 349 minecraft:blue_terracotta
setblock 142 17 353 minecraft:dark_prismarine
fill 142 17 354 142 20 354 minecraft:blue_terracotta
setblock 142 17 358 minecraft:dark_prismarine
fill 142 17 359 142 20 359 minecraft:blue_terracotta
setblock 142 17 363 minecraft:dark_prismarine
fill 143 17 323 143 18 323 minecraft:blue_terracotta
setblock 143 17 332 minecraft:dark_prismarine
fill 143 17 333 143 20 333 minecraft:blue_terracotta
setblock 143 17 337 minecraft:dark_prismarine
fill 143 17 338 143 20 338 minecraft:blue_terracotta
setblock 143 17 341 minecraft:blue_terracotta
setblock 143 17 342 minecraft:dark_prismarine
fill 143 17 343 143 20 343 minecraft:blue_terracotta
setblock 143 17 347 minecraft:dark_prismarine
fill 143 17 348 143 20 348 minecraft:blue_terracotta
setblock 143 17 352 minecraft:dark_prismarine
fill 143 17 353 143 20 353 minecraft:blue_terracotta
setblock 143 17 357 minecraft:dark_prismarine
fill 143 17 358 143 20 358 minecraft:blue_terracotta
setblock 143 17 361 minecraft:blue_terracotta
setblock 143 17 362 minecraft:dark_prismarine
fill 143 17 363 143 20 363 minecraft:blue_terracotta
setblock 144 17 325 minecraft:light[level=12]
setblock 144 17 332 minecraft:light[level=12]
fill 144 17 337 144 19 337 minecraft:blue_terracotta
setblock 144 17 339 minecraft:light[level=12]
setblock 144 17 346 minecraft:light[level=12]
setblock 144 17 351 minecraft:dark_prismarine
fill 144 17 352 144 19 352 minecraft:blue_terracotta
setblock 144 17 356 minecraft:dark_prismarine
fill 144 17 357 144 20 357 minecraft:blue_terracotta
setblock 144 17 361 minecraft:dark_prismarine
fill 144 17 362 144 20 362 minecraft:blue_terracotta
setblock 145 17 355 minecraft:dark_prismarine
fill 145 17 356 145 18 356 minecraft:blue_terracotta
setblock 145 17 361 minecraft:blue_terracotta
fill 147 17 338 147 22 338 minecraft:black_concrete
setblock 147 17 363 minecraft:dark_prismarine
fill 148 17 337 148 22 337 minecraft:black_concrete
fill 148 17 339 148 22 339 minecraft:black_concrete
fill 149 17 338 149 22 338 minecraft:black_concrete
setblock 151 17 325 minecraft:light[level=12]
setblock 151 17 332 minecraft:light[level=12]
setblock 151 17 339 minecraft:light[level=12]
setblock 151 17 346 minecraft:light[level=12]
setblock 151 17 353 minecraft:light[level=12]
setblock 151 17 360 minecraft:light[level=12]
setblock 154 17 323 minecraft:purple_concrete
fill 158 17 323 158 20 323 minecraft:blue_terracotta
setblock 158 17 325 minecraft:light[level=12]
setblock 158 17 332 minecraft:light[level=12]
setblock 158 17 339 minecraft:light[level=12]
setblock 158 17 346 minecraft:light[level=12]
setblock 158 17 353 minecraft:light[level=12]
setblock 158 17 360 minecraft:light[level=12]
fill 158 17 363 161 17 363 minecraft:blue_terracotta
setblock 161 17 324 minecraft:dark_prismarine
setblock 162 17 323 minecraft:dark_prismarine
fill 162 17 324 162 20 324 minecraft:blue_terracotta
setblock 162 17 362 minecraft:blue_terracotta
setblock 162 17 363 minecraft:dark_prismarine
fill 163 17 323 163 20 323 minecraft:blue_terracotta
fill 163 17 363 163 20 363 minecraft:blue_terracotta
setblock 165 17 325 minecraft:light[level=12]
setblock 165 17 332 minecraft:light[level=12]
setblock 165 17 339 minecraft:light[level=12]
setblock 165 17 346 minecraft:light[level=12]
setblock 165 17 353 minecraft:light[level=12]
setblock 167 17 323 minecraft:dark_prismarine
setblock 167 17 363 minecraft:dark_prismarine
fill 168 17 323 168 20 323 minecraft:blue_terracotta
fill 170 17 323 171 17 323 minecraft:blue_terracotta
fill 170 17 325 170 18 325 minecraft:dark_prismarine
fill 170 17 363 170 18 363 minecraft:purple_concrete
fill 171 17 324 171 18 324 minecraft:dark_prismarine
fill 171 17 326 171 18 326 minecraft:dark_prismarine
setblock 172 17 323 minecraft:dark_prismarine
fill 172 17 325 172 18 325 minecraft:dark_prismarine
setblock 172 17 332 minecraft:light[level=12]
setblock 172 17 339 minecraft:light[level=12]
setblock 172 17 346 minecraft:light[level=12]
setblock 172 17 353 minecraft:light[level=12]
setblock 172 17 360 minecraft:light[level=12]
fill 173 17 323 174 18 323 minecraft:blue_terracotta
fill 173 17 324 173 18 324 minecraft:dark_prismarine
fill 173 17 326 173 18 326 minecraft:dark_prismarine
fill 173 17 338 174 18 338 minecraft:black_concrete
fill 173 17 363 174 19 363 minecraft:blue_terracotta
fill 174 17 325 174 18 325 minecraft:dark_prismarine
fill 175 17 324 175 18 324 minecraft:dark_prismarine
fill 175 17 326 175 18 326 minecraft:dark_prismarine
setblock 176 17 323 minecraft:blue_terracotta
fill 176 17 325 176 18 325 minecraft:dark_prismarine
fill 176 17 362 176 17 363 minecraft:blue_terracotta
setblock 177 17 323 minecraft:dark_prismarine
fill 177 17 324 177 18 324 minecraft:blue_terracotta
fill 177 17 326 177 18 326 minecraft:dark_prismarine
fill 177 17 361 177 17 362 minecraft:blue_terracotta
setblock 177 17 363 minecraft:dark_prismarine
fill 178 17 323 178 18 323 minecraft:blue_terracotta
fill 178 17 325 178 18 325 minecraft:dark_prismarine
setblock 178 17 361 minecraft:blue_terracotta
setblock 178 17 362 minecraft:dark_prismarine
fill 178 17 363 178 20 363 minecraft:blue_terracotta
fill 179 17 324 179 18 324 minecraft:blue_terracotta
fill 179 17 326 179 18 326 minecraft:dark_prismarine
setblock 179 17 332 minecraft:light[level=12]
setblock 179 17 339 minecraft:light[level=12]
setblock 179 17 346 minecraft:light[level=12]
setblock 179 17 353 minecraft:light[level=12]
setblock 179 17 355 minecraft:blue_terracotta
setblock 179 17 356 minecraft:dark_prismarine
fill 179 17 357 179 17 360 minecraft:blue_terracotta
setblock 179 17 361 minecraft:dark_prismarine
fill 179 17 362 179 20 362 minecraft:blue_terracotta
fill 180 17 323 180 18 323 minecraft:blue_terracotta
fill 180 17 325 180 18 325 minecraft:dark_prismarine
setblock 180 17 330 minecraft:dark_prismarine
fill 180 17 331 180 18 331 minecraft:blue_terracotta
setblock 180 17 335 minecraft:dark_prismarine
fill 180 17 336 180 19 336 minecraft:blue_terracotta
fill 180 17 352 180 17 354 minecraft:blue_terracotta
setblock 180 17 355 minecraft:dark_prismarine
fill 180 17 356 180 17 359 minecraft:blue_terracotta
setblock 180 17 360 minecraft:dark_prismarine
fill 180 17 361 180 20 361 minecraft:blue_terracotta
setblock 181 17 324 minecraft:dark_prismarine
fill 181 17 325 181 19 325 minecraft:blue_terracotta
setblock 181 17 329 minecraft:dark_prismarine
fill 181 17 330 181 19 330 minecraft:blue_terracotta
setblock 181 17 334 minecraft:dark_prismarine
fill 181 17 335 181 20 335 minecraft:blue_terracotta
setblock 181 17 338 minecraft:blue_terracotta
setblock 181 17 339 minecraft:dark_prismarine
fill 181 17 340 181 20 340 minecraft:blue_terracotta
setblock 181 17 349 minecraft:dark_prismarine
fill 181 17 350 181 17 353 minecraft:blue_terracotta
setblock 181 17 354 minecraft:dark_prismarine
fill 181 17 355 181 17 358 minecraft:blue_terracotta
setblock 181 17 359 minecraft:dark_prismarine
fill 181 17 360 181 20 360 minecraft:blue_terracotta
setblock 182 17 323 minecraft:dark_prismarine
fill 182 17 324 182 20 324 minecraft:blue_terracotta
setblock 182 17 328 minecraft:dark_prismarine
fill 182 17 329 182 20 329 minecraft:blue_terracotta
setblock 182 17 333 minecraft:dark_prismarine
fill 182 17 334 182 20 334 minecraft:blue_terracotta
setblock 182 17 338 minecraft:dark_prismarine
fill 182 17 339 182 20 339 minecraft:blue_terracotta
setblock 182 17 342 minecraft:blue_terracotta
setblock 182 17 343 minecraft:dark_prismarine
fill 182 17 344 182 20 344 minecraft:blue_terracotta
setblock 182 17 348 minecraft:dark_prismarine
fill 182 17 349 182 17 352 minecraft:blue_terracotta
setblock 182 17 353 minecraft:dark_prismarine
fill 182 17 354 182 20 354 minecraft:blue_terracotta
setblock 182 17 358 minecraft:dark_prismarine
fill 182 17 359 182 20 359 minecraft:blue_terracotta
setblock 182 17 363 minecraft:dark_prismarine
fill 182 17 364 182 28 364 minecraft:black_concrete
fill 183 17 335 183 131 336 minecraft:black_concrete
setblock 183 17 337 minecraft:cyan_concrete
fill 183 17 338 183 34 339 minecraft:black_concrete
fill 141 18 352 141 18 353 minecraft:cyan_concrete
fill 141 18 354 141 131 354 minecraft:black_concrete
fill 142 18 323 142 19 323 minecraft:blue_terracotta
setblock 142 18 327 minecraft:dark_prismarine
fill 142 18 328 142 19 328 minecraft:blue_terracotta
setblock 142 18 332 minecraft:dark_prismarine
fill 142 18 333 142 21 333 minecraft:blue_terracotta
setblock 142 18 337 minecraft:dark_prismarine
fill 142 18 338 142 21 338 minecraft:blue_terracotta
setblock 142 18 342 minecraft:dark_prismarine
fill 142 18 343 142 21 343 minecraft:blue_terracotta
setblock 142 18 347 minecraft:dark_prismarine
fill 142 18 348 142 21 348 minecraft:blue_terracotta
setblock 142 18 352 minecraft:dark_prismarine
fill 142 18 353 142 21 353 minecraft:blue_terracotta
setblock 142 18 357 minecraft:dark_prismarine
fill 142 18 358 142 21 358 minecraft:blue_terracotta
setblock 142 18 362 minecraft:dark_prismarine
fill 142 18 363 142 21 363 minecraft:blue_terracotta
setblock 143 18 331 minecraft:dark_prismarine
fill 143 18 332 143 19 332 minecraft:blue_terracotta
fill 143 18 334 143 19 334 minecraft:blue_terracotta
setblock 143 18 336 minecraft:dark_prismarine
fill 143 18 337 143 21 337 minecraft:blue_terracotta
setblock 143 18 341 minecraft:dark_prismarine
fill 143 18 342 143 21 342 minecraft:blue_terracotta
setblock 143 18 346 minecraft:dark_prismarine
fill 143 18 347 143 20 347 minecraft:blue_terracotta
setblock 143 18 351 minecraft:dark_prismarine
fill 143 18 352 143 21 352 minecraft:blue_terracotta
setblock 143 18 356 minecraft:dark_prismarine
fill 143 18 357 143 21 357 minecraft:blue_terracotta
setblock 143 18 361 minecraft:dark_prismarine
fill 143 18 362 143 21 362 minecraft:blue_terracotta
fill 144 18 338 144 19 338 minecraft:blue_terracotta
setblock 144 18 350 minecraft:dark_prismarine
fill 144 18 351 144 19 351 minecraft:blue_terracotta
setblock 144 18 355 minecraft:dark_prismarine
fill 144 18 356 144 21 356 minecraft:blue_terracotta
setblock 144 18 360 minecraft:dark_prismarine
fill 144 18 361 144 19 361 minecraft:blue_terracotta
setblock 145 18 354 minecraft:dark_prismarine
setblock 145 18 355 minecraft:blue_terracotta
setblock 146 18 363 minecraft:dark_prismarine
fill 147 18 339 147 22 339 minecraft:black_concrete
setblock 147 18 363 minecraft:blue_terracotta
setblock 148 18 323 minecraft:purple_concrete
fill 149 18 337 149 22 337 minecraft:black_concrete
fill 149 18 339 149 22 339 minecraft:black_concrete
fill 150 18 352 150 27 352 minecraft:magenta_terracotta
setblock 151 18 363 minecraft:purple_concrete
fill 157 18 363 160 18 363 minecraft:blue_terracotta
setblock 160 18 324 minecraft:dark_prismarine
fill 160 18 330 160 33 330 minecraft:magenta_terracotta
fill 160 18 362 161 18 362 minecraft:blue_terracotta
setblock 161 18 323 minecraft:dark_prismarine
fill 161 18 324 161 21 324 minecraft:blue_terracotta
setblock 161 18 363 minecraft:dark_prismarine
fill 162 18 323 162 21 323 minecraft:blue_terracotta
setblock 162 18 362 minecraft:dark_prismarine
fill 162 18 363 162 21 363 minecraft:blue_terracotta
fill 163 18 362 163 20 362 minecraft:blue_terracotta
setblock 165 18 324 minecraft:dark_prismarine
setblock 166 18 323 minecraft:dark_prismarine
setblock 166 18 363 minecraft:dark_prismarine
fill 167 18 323 167 21 323 minecraft:blue_terracotta
fill 167 18 363 167 21 363 minecraft:blue_terracotta
setblock 170 18 323 minecraft:blue_terracotta
fill 171 18 323 171 21 323 minecraft:dark_prismarine
setblock 172 18 323 minecraft:blue_terracotta
fill 172 18 363 172 21 363 minecraft:blue_terracotta
fill 175 18 362 176 18 362 minecraft:blue_terracotta
setblock 176 18 323 minecraft:dark_prismarine
setblock 176 18 363 minecraft:dark_prismarine
fill 177 18 323 177 21 323 minecraft:blue_terracotta
setblock 177 18 361 minecraft:blue_terracotta
setblock 177 18 362 minecraft:dark_prismarine
fill 177 18 363 177 21 363 minecraft:blue_terracotta
setblock 178 18 360 minecraft:blue_terracotta
setblock 178 18 361 minecraft:dark_prismarine
fill 178 18 362 178 21 362 minecraft:blue_terracotta
setblock 179 18 355 minecraft:dark_prismarine
fill 179 18 356 179 18 359 minecraft:blue_terracotta
setblock 179 18 360 minecraft:dark_prismarine
fill 179 18 361 179 21 361 minecraft:blue_terracotta
setblock 180 18 324 minecraft:dark_prismarine
setblock 180 18 330 minecraft:blue_terracotta
setblock 180 18 333 minecraft:blue_terracotta
setblock 180 18 334 minecraft:dark_prismarine
fill 180 18 335 180 19 335 minecraft:blue_terracotta
fill 180 18 337 180 19 337 minecraft:blue_terracotta
fill 180 18 352 180 18 353 minecraft:blue_terracotta
setblock 180 18 354 minecraft:dark_prismarine
fill 180 18 355 180 18 358 minecraft:blue_terracotta
setblock 180 18 359 minecraft:dark_prismarine
fill 180 18 360 180 21 360 minecraft:blue_terracotta
setblock 181 18 323 minecraft:dark_prismarine
fill 181 18 324 181 20 324 minecraft:blue_terracotta
setblock 181 18 328 minecraft:dark_prismarine
fill 181 18 329 181 19 329 minecraft:blue_terracotta
setblock 181 18 333 minecraft:dark_prismarine
fill 181 18 334 181 21 334 minecraft:blue_terracotta
setblock 181 18 338 minecraft:dark_prismarine
fill 181 18 339 181 21 339 minecraft:blue_terracotta
fill 181 18 349 181 18 352 minecraft:blue_terracotta
setblock 181 18 353 minecraft:dark_prismarine
fill 181 18 354 181 18 357 minecraft:blue_terracotta
setblock 181 18 358 minecraft:dark_prismarine
fill 181 18 359 181 21 359 minecraft:blue_terracotta
setblock 181 18 363 minecraft:dark_prismarine
fill 182 18 323 182 21 323 minecraft:blue_terracotta
setblock 182 18 327 minecraft:dark_prismarine
fill 182 18 328 182 20 328 minecraft:blue_terracotta
setblock 182 18 332 minecraft:dark_prismarine
fill 182 18 333 182 21 333 minecraft:blue_terracotta
setblock 182 18 337 minecraft:dark_prismarine
fill 182 18 338 182 21 338 minecraft:blue_terracotta
setblock 182 18 342 minecraft:dark_prismarine
fill 182 18 343 182 21 343 minecraft:blue_terracotta
setblock 182 18 347 minecraft:dark_prismarine
fill 182 18 348 182 18 351 minecraft:blue_terracotta
setblock 182 18 352 minecraft:dark_prismarine
fill 182 18 353 182 21 353 minecraft:blue_terracotta
setblock 182 18 357 minecraft:dark_prismarine
fill 182 18 358 182 21 358 minecraft:blue_terracotta
setblock 182 18 362 minecraft:dark_prismarine
fill 182 18 363 182 21 363 minecraft:blue_terracotta
fill 183 18 337 183 128 337 minecraft:black_concrete
fill 141 19 343 141 101 344 minecraft:black_concrete
setblock 141 19 345 minecraft:light_blue_wool
fill 141 19 346 141 74 348 minecraft:black_concrete
fill 141 19 352 141 121 353 minecraft:black_concrete
setblock 142 19 331 minecraft:dark_prismarine
fill 142 19 332 142 21 332 minecraft:blue_terracotta
setblock 142 19 336 minecraft:dark_prismarine
fill 142 19 337 142 22 337 minecraft:blue_terracotta
setblock 142 19 341 minecraft:dark_prismarine
fill 142 19 342 142 22 342 minecraft:blue_terracotta
setblock 142 19 346 minecraft:dark_prismarine
fill 142 19 347 142 22 347 minecraft:blue_terracotta
setblock 142 19 351 minecraft:dark_prismarine
fill 142 19 352 142 22 352 minecraft:blue_terracotta
setblock 142 19 356 minecraft:dark_prismarine
fill 142 19 357 142 22 357 minecraft:blue_terracotta
setblock 142 19 361 minecraft:dark_prismarine
fill 142 19 362 142 22 362 minecraft:blue_terracotta
setblock 143 19 335 minecraft:dark_prismarine
fill 143 19 336 143 22 336 minecraft:blue_terracotta
setblock 143 19 340 minecraft:dark_prismarine
fill 143 19 341 143 22 341 minecraft:blue_terracotta
setblock 143 19 345 minecraft:dark_prismarine
fill 143 19 346 143 20 346 minecraft:blue_terracotta
setblock 143 19 350 minecraft:dark_prismarine
fill 143 19 351 143 21 351 minecraft:blue_terracotta
setblock 143 19 355 minecraft:dark_prismarine
fill 143 19 356 143 22 356 minecraft:blue_terracotta
setblock 143 19 360 minecraft:dark_prismarine
fill 143 19 361 143 22 361 minecraft:blue_terracotta
setblock 144 19 354 minecraft:dark_prismarine
fill 144 19 355 144 20 355 minecraft:blue_terracotta
setblock 144 19 359 minecraft:dark_prismarine
fill 144 19 360 144 20 360 minecraft:blue_terracotta
fill 145 19 336 145 33 336 minecraft:magenta_terracotta
setblock 145 19 363 minecraft:dark_prismarine
fill 146 19 338 146 22 338 minecraft:black_concrete
fill 146 19 363 146 20 363 minecraft:blue_terracotta
fill 148 19 340 148 22 340 minecraft:black_concrete
fill 150 19 338 150 22 338 minecraft:black_concrete
fill 156 19 363 159 19 363 minecraft:blue_terracotta
fill 157 19 323 157 21 323 minecraft:blue_terracotta
fill 159 19 362 160 19 362 minecraft:blue_terracotta
setblock 160 19 323 minecraft:dark_prismarine
fill 160 19 324 160 21 324 minecraft:blue_terracotta
setblock 160 19 363 minecraft:dark_prismarine
fill 161 19 323 161 22 323 minecraft:blue_terracotta
setblock 161 19 362 minecraft:dark_prismarine
fill 161 19 363 161 22 363 minecraft:blue_terracotta
fill 162 19 362 162 21 362 minecraft:blue_terracotta
setblock 164 19 324 minecraft:dark_prismarine
setblock 165 19 323 minecraft:dark_prismarine
setblock 165 19 363 minecraft:dark_prismarine
fill 166 19 323 166 22 323 minecraft:blue_terracotta
fill 166 19 363 166 22 363 minecraft:blue_terracotta
fill 168 19 363 168 20 363 minecraft:blue_terracotta
setblock 170 19 323 minecraft:sea_lantern
setblock 170 19 325 minecraft:sea_lantern
setblock 171 19 324 minecraft:sea_lantern
setblock 171 19 326 minecraft:sea_lantern
fill 171 19 363 171 22 363 minecraft:blue_terracotta
setblock 172 19 323 minecraft:sea_lantern
setblock 172 19 325 minecraft:sea_lantern
fill 173 19 323 173 20 323 minecraft:blue_terracotta
setblock 173 19 324 minecraft:sea_lantern
setblock 173 19 326 minecraft:sea_lantern
setblock 174 19 323 minecraft:sea_lantern
setblock 174 19 325 minecraft:sea_lantern
fill 174 19 362 175 19 362 minecraft:blue_terracotta
setblock 175 19 323 minecraft:dark_prismarine
setblock 175 19 324 minecraft:sea_lantern
setblock 175 19 326 minecraft:sea_lantern
setblock 175 19 363 minecraft:dark_prismarine
setblock 176 19 323 minecraft:sea_lantern
setblock 176 19 325 minecraft:sea_lantern
setblock 176 19 361 minecraft:blue_terracotta
setblock 176 19 362 minecraft:dark_prismarine
fill 176 19 363 176 22 363 minecraft:blue_terracotta
setblock 177 19 324 minecraft:sea_lantern
setblock 177 19 326 minecraft:sea_lantern
setblock 177 19 361 minecraft:dark_prismarine
fill 177 19 362 177 22 362 minecraft:blue_terracotta
setblock 178 19 323 minecraft:sea_lantern
setblock 178 19 325 minecraft:sea_lantern
setblock 178 19 360 minecraft:dark_prismarine
fill 178 19 361 178 22 361 minecraft:blue_terracotta
setblock 179 19 324 minecraft:sea_lantern
setblock 179 19 326 minecraft:sea_lantern
fill 179 19 355 179 19 358 minecraft:blue_terracotta
setblock 179 19 359 minecraft:dark_prismarine
fill 179 19 360 179 22 360 minecraft:blue_terracotta
setblock 180 19 323 minecraft:sea_lantern
fill 180 19 324 180 21 324 minecraft:blue_terracotta
setblock 180 19 325 minecraft:sea_lantern
setblock 180 19 333 minecraft:dark_prismarine
setblock 180 19 334 minecraft:blue_terracotta
setblock 180 19 352 minecraft:blue_terracotta
setblock 180 19 353 minecraft:dark_prismarine
fill 180 19 354 180 19 357 minecraft:blue_terracotta
setblock 180 19 358 minecraft:dark_prismarine
fill 180 19 359 180 22 359 minecraft:blue_terracotta
setblock 180 19 363 minecraft:dark_prismarine
fill 181 19 323 181 22 323 minecraft:blue_terracotta
setblock 181 19 327 minecraft:dark_prismarine
setblock 181 19 328 minecraft:blue_terracotta
setblock 181 19 332 minecraft:dark_prismarine
fill 181 19 333 181 20 333 minecraft:blue_terracotta
setblock 181 19 337 minecraft:dark_prismarine
fill 181 19 338 181 22 338 minecraft:blue_terracotta
setblock 181 19 341 minecraft:blue_terracotta
fill 181 19 350 181 19 351 minecraft:blue_terracotta
setblock 181 19 352 minecraft:dark_prismarine
fill 181 19 353 181 19 356 minecraft:blue_terracotta
setblock 181 19 357 minecraft:dark_prismarine
fill 181 19 358 181 22 358 minecraft:blue_terracotta
setblock 181 19 362 minecraft:dark_prismarine
fill 181 19 363 181 22 363 minecraft:blue_terracotta
setblock 182 19 326 minecraft:dark_prismarine
fill 182 19 327 182 20 327 minecraft:blue_terracotta
setblock 182 19 331 minecraft:dark_prismarine
fill 182 19 332 182 21 332 minecraft:blue_terracotta
setblock 182 19 336 minecraft:dark_prismarine
fill 182 19 337 182 22 337 minecraft:blue_terracotta
setblock 182 19 341 minecraft:dark_prismarine
fill 182 19 342 182 22 342 minecraft:blue_terracotta
setblock 182 19 346 minecraft:dark_prismarine
fill 182 19 347 182 19 350 minecraft:blue_terracotta
setblock 182 19 351 minecraft:dark_prismarine
fill 182 19 352 182 22 352 minecraft:blue_terracotta
setblock 182 19 356 minecraft:dark_prismarine
fill 182 19 357 182 22 357 minecraft:blue_terracotta
setblock 182 19 361 minecraft:dark_prismarine
fill 182 19 362 182 22 362 minecraft:blue_terracotta
fill 141 20 345 141 129 345 minecraft:black_concrete
setblock 142 20 330 minecraft:dark_prismarine
setblock 142 20 331 minecraft:blue_terracotta
setblock 142 20 335 minecraft:dark_prismarine
fill 142 20 336 142 23 336 minecraft:blue_terracotta
setblock 142 20 340 minecraft:dark_prismarine
fill 142 20 341 142 23 341 minecraft:blue_terracotta
setblock 142 20 345 minecraft:dark_prismarine
fill 142 20 346 142 23 346 minecraft:blue_terracotta
setblock 142 20 350 minecraft:dark_prismarine
fill 142 20 351 142 23 351 minecraft:blue_terracotta
setblock 142 20 355 minecraft:dark_prismarine
fill 142 20 356 142 23 356 minecraft:blue_terracotta
setblock 142 20 360 minecraft:dark_prismarine
fill 142 20 361 142 23 361 minecraft:blue_terracotta
setblock 143 20 334 minecraft:dark_prismarine
fill 143 20 335 143 21 335 minecraft:blue_terracotta
setblock 143 20 339 minecraft:dark_prismarine
fill 143 20 340 143 23 340 minecraft:blue_terracotta
setblock 143 20 344 minecraft:dark_prismarine
setblock 143 20 345 minecraft:blue_terracotta
setblock 143 20 349 minecraft:dark_prismarine
fill 143 20 350 143 21 350 minecraft:blue_terracotta
setblock 143 20 354 minecraft:dark_prismarine
fill 143 20 355 143 23 355 minecraft:blue_terracotta
setblock 143 20 359 minecraft:dark_prismarine
fill 143 20 360 143 23 360 minecraft:blue_terracotta
setblock 144 20 353 minecraft:dark_prismarine
setblock 144 20 354 minecraft:blue_terracotta
setblock 144 20 358 minecraft:dark_prismarine
fill 144 20 359 144 21 359 minecraft:blue_terracotta
setblock 144 20 363 minecraft:dark_prismarine
setblock 145 20 362 minecraft:dark_prismarine
fill 145 20 363 145 22 363 minecraft:blue_terracotta
fill 146 20 339 146 22 339 minecraft:black_concrete
fill 147 20 340 147 22 340 minecraft:black_concrete
fill 147 20 350 147 33 350 minecraft:magenta_terracotta
fill 149 20 336 149 22 336 minecraft:black_concrete
fill 149 20 340 149 22 340 minecraft:black_concrete
fill 149 20 348 149 33 348 minecraft:magenta_terracotta
fill 150 20 337 150 22 337 minecraft:black_concrete
fill 150 20 339 150 22 339 minecraft:black_concrete
fill 156 20 363 158 20 363 minecraft:blue_terracotta
fill 158 20 362 159 20 362 minecraft:blue_terracotta
setblock 159 20 323 minecraft:dark_prismarine
setblock 159 20 363 minecraft:dark_prismarine
fill 160 20 323 160 23 323 minecraft:blue_terracotta
setblock 160 20 362 minecraft:dark_prismarine
fill 160 20 363 160 23 363 minecraft:blue_terracotta
fill 161 20 329 161 33 329 minecraft:magenta_terracotta
fill 161 20 362 161 23 362 minecraft:blue_terracotta
setblock 164 20 323 minecraft:dark_prismarine
setblock 164 20 363 minecraft:dark_prismarine
fill 165 20 323 165 23 323 minecraft:blue_terracotta
fill 165 20 359 165 33 359 minecraft:magenta_terracotta
fill 165 20 363 165 23 363 minecraft:blue_terracotta
fill 170 20 323 170 21 323 minecraft:dark_prismarine
fill 170 20 325 170 21 325 minecraft:dark_prismarine
fill 170 20 363 170 23 363 minecraft:blue_terracotta
fill 171 20 324 171 21 324 minecraft:dark_prismarine
fill 171 20 326 171 21 326 minecraft:dark_prismarine
fill 172 20 323 172 21 323 minecraft:blue_terracotta
fill 172 20 325 172 21 325 minecraft:dark_prismarine
fill 173 20 324 173 21 324 minecraft:dark_prismarine
fill 173 20 326 173 21 326 minecraft:dark_prismarine
fill 173 20 362 173 20 363 minecraft:blue_terracotta
setblock 174 20 323 minecraft:dark_prismarine
fill 174 20 325 174 21 325 minecraft:dark_prismarine
fill 174 20 334 174 28 334 minecraft:magenta_terracotta
setblock 174 20 362 minecraft:blue_terracotta
setblock 174 20 363 minecraft:dark_prismarine
fill 175 20 323 176 21 323 minecraft:blue_terracotta
fill 175 20 324 175 21 324 minecraft:dark_prismarine
fill 175 20 326 175 21 326 minecraft:dark_prismarine
setblock 175 20 361 minecraft:blue_terracotta
setblock 175 20 362 minecraft:dark_prismarine
fill 175 20 363 175 23 363 minecraft:blue_terracotta
fill 176 20 325 176 21 325 minecraft:dark_prismarine
setblock 176 20 361 minecraft:dark_prismarine
fill 176 20 362 176 23 362 minecraft:blue_terracotta
setblock 177 20 324 minecraft:blue_terracotta
fill 177 20 326 177 21 326 minecraft:dark_prismarine
setblock 177 20 360 minecraft:dark_prismarine
fill 177 20 361 177 23 361 minecraft:blue_terracotta
setblock 178 20 323 minecraft:blue_terracotta
fill 178 20 324 178 20 325 minecraft:dark_prismarine
fill 178 20 360 178 23 360 minecraft:blue_terracotta
setblock 179 20 323 minecraft:dark_prismarine
fill 179 20 324 179 21 324 minecraft:blue_terracotta
fill 179 20 326 179 21 326 minecraft:dark_prismarine
fill 179 20 356 179 20 357 minecraft:blue_terracotta
setblock 179 20 358 minecraft:dark_prismarine
fill 179 20 359 179 23 359 minecraft:blue_terracotta
setblock 179 20 363 minecraft:dark_prismarine
fill 180 20 323 180 21 323 minecraft:blue_terracotta
fill 180 20 325 180 21 325 minecraft:dark_prismarine
fill 180 20 353 180 20 356 minecraft:blue_terracotta
setblock 180 20 357 minecraft:dark_prismarine
fill 180 20 358 180 23 358 minecraft:blue_terracotta
setblock 180 20 362 minecraft:dark_prismarine
fill 180 20 363 180 23 363 minecraft:blue_terracotta
setblock 181 20 331 minecraft:dark_prismarine
setblock 181 20 332 minecraft:blue_terracotta
setblock 181 20 336 minecraft:dark_prismarine
fill 181 20 337 181 22 337 minecraft:blue_terracotta
setblock 181 20 341 minecraft:dark_prismarine
setblock 181 20 350 minecraft:blue_terracotta
setblock 181 20 351 minecraft:dark_prismarine
fill 181 20 352 181 20 355 minecraft:blue_terracotta
setblock 181 20 356 minecraft:dark_prismarine
fill 181 20 357 181 23 357 minecraft:blue_terracotta
setblock 181 20 361 minecraft:dark_prismarine
fill 181 20 362 181 23 362 minecraft:blue_terracotta
setblock 182 20 325 minecraft:dark_prismarine
setblock 182 20 326 minecraft:blue_terracotta
setblock 182 20 330 minecraft:dark_prismarine
fill 182 20 331 182 21 331 minecraft:blue_terracotta
setblock 182 20 335 minecraft:dark_prismarine
fill 182 20 336 182 23 336 minecraft:blue_terracotta
setblock 182 20 340 minecraft:dark_prismarine
fill 182 20 341 182 23 341 minecraft:blue_terracotta
setblock 182 20 345 minecraft:dark_prismarine
fill 182 20 346 182 20 349 minecraft:blue_terracotta
setblock 182 20 350 minecraft:dark_prismarine
fill 182 20 351 182 23 351 minecraft:blue_terracotta
setblock 182 20 355 minecraft:dark_prismarine
fill 182 20 356 182 23 356 minecraft:blue_terracotta
setblock 182 20 360 minecraft:dark_prismarine
fill 182 20 361 182 23 361 minecraft:blue_terracotta
setblock 183 20 334 minecraft:light_blue_wool
setblock 142 21 327 minecraft:purple_concrete
setblock 142 21 334 minecraft:dark_prismarine
fill 142 21 335 142 24 335 minecraft:blue_terracotta
setblock 142 21 339 minecraft:dark_prismarine
fill 142 21 340 142 24 340 minecraft:blue_terracotta
setblock 142 21 344 minecraft:dark_prismarine
fill 142 21 345 142 24 345 minecraft:blue_terracotta
setblock 142 21 349 minecraft:dark_prismarine
fill 142 21 350 142 24 350 minecraft:blue_terracotta
setblock 142 21 354 minecraft:dark_prismarine
fill 142 21 355 142 24 355 minecraft:blue_terracotta
setblock 142 21 359 minecraft:dark_prismarine
fill 142 21 360 142 24 360 minecraft:blue_terracotta
setblock 143 21 338 minecraft:dark_prismarine
fill 143 21 339 143 24 339 minecraft:blue_terracotta
setblock 143 21 343 minecraft:dark_prismarine
fill 143 21 344 143 22 344 minecraft:blue_terracotta
setblock 143 21 353 minecraft:dark_prismarine
fill 143 21 354 143 22 354 minecraft:blue_terracotta
setblock 143 21 358 minecraft:dark_prismarine
fill 143 21 359 143 24 359 minecraft:blue_terracotta
setblock 143 21 363 minecraft:dark_prismarine
setblock 144 21 325 minecraft:light[level=13]
setblock 144 21 333 minecraft:light[level=13]
setblock 144 21 341 minecraft:light[level=13]
setblock 144 21 349 minecraft:light[level=13]
setblock 144 21 357 minecraft:dark_prismarine
setblock 144 21 358 minecraft:blue_terracotta
setblock 144 21 362 minecraft:dark_prismarine
fill 144 21 363 144 24 363 minecraft:blue_terracotta
fill 145 21 338 145 22 338 minecraft:black_concrete
fill 146 21 340 146 22 340 minecraft:black_concrete
fill 148 21 341 148 22 341 minecraft:black_concrete
fill 148 21 344 149 22 344 minecraft:spruce_planks
fill 150 21 336 150 22 336 minecraft:black_concrete
fill 150 21 340 150 22 340 minecraft:black_concrete
setblock 150 21 363 minecraft:purple_concrete
fill 151 21 338 151 22 338 minecraft:black_concrete
setblock 152 21 325 minecraft:light[level=13]
setblock 152 21 333 minecraft:light[level=13]
setblock 152 21 341 minecraft:light[level=13]
setblock 152 21 349 minecraft:light[level=13]
setblock 152 21 357 minecraft:light[level=13]
fill 154 21 327 156 22 327 minecraft:black_concrete
setblock 155 21 323 minecraft:purple_concrete
fill 155 21 326 155 22 326 minecraft:black_concrete
fill 155 21 328 155 22 328 minecraft:black_concrete
fill 155 21 363 157 21 363 minecraft:blue_terracotta
fill 156 21 323 156 22 323 minecraft:blue_terracotta
setblock 158 21 323 minecraft:dark_prismarine
setblock 158 21 362 minecraft:blue_terracotta
setblock 158 21 363 minecraft:dark_prismarine
fill 159 21 323 159 24 323 minecraft:blue_terracotta
setblock 159 21 362 minecraft:dark_prismarine
fill 159 21 363 159 24 363 minecraft:blue_terracotta
setblock 160 21 325 minecraft:light[level=13]
setblock 160 21 333 minecraft:light[level=13]
setblock 160 21 349 minecraft:light[level=13]
setblock 160 21 357 minecraft:light[level=13]
fill 160 21 362 160 24 362 minecraft:blue_terracotta
setblock 163 21 323 minecraft:dark_prismarine
setblock 163 21 363 minecraft:dark_prismarine
fill 164 21 323 164 24 323 minecraft:blue_terracotta
fill 164 21 363 164 24 363 minecraft:blue_terracotta
setblock 168 21 325 minecraft:light[level=13]
setblock 168 21 333 minecraft:light[level=13]
setblock 168 21 341 minecraft:light[level=13]
setblock 168 21 349 minecraft:light[level=13]
setblock 168 21 357 minecraft:light[level=13]
fill 169 21 363 169 24 363 minecraft:blue_terracotta
setblock 173 21 323 minecraft:dark_prismarine
setblock 173 21 362 minecraft:blue_terracotta
setblock 173 21 363 minecraft:dark_prismarine
setblock 174 21 323 minecraft:blue_terracotta
setblock 174 21 362 minecraft:dark_prismarine
fill 174 21 363 174 24 363 minecraft:blue_terracotta
fill 175 21 338 175 33 338 minecraft:magenta_terracotta
setblock 175 21 361 minecraft:dark_prismarine
fill 175 21 362 175 24 362 minecraft:blue_terracotta
setblock 176 21 333 minecraft:light[level=13]
setblock 176 21 341 minecraft:light[level=13]
fill 176 21 349 176 33 349 minecraft:magenta_terracotta
fill 176 21 361 176 24 361 minecraft:blue_terracotta
setblock 177 21 324 minecraft:dark_prismarine
fill 177 21 360 177 24 360 minecraft:blue_terracotta
setblock 178 21 323 minecraft:dark_prismarine
fill 178 21 324 178 24 324 minecraft:blue_terracotta
setblock 178 21 325 minecraft:dark_prismarine
setblock 178 21 363 minecraft:dark_prismarine
fill 179 21 323 179 24 323 minecraft:blue_terracotta
setblock 179 21 357 minecraft:dark_prismarine
fill 179 21 358 179 23 358 minecraft:blue_terracotta
setblock 179 21 362 minecraft:dark_prismarine
fill 179 21 363 179 24 363 minecraft:blue_terracotta
fill 180 21 354 180 21 355 minecraft:blue_terracotta
setblock 180 21 356 minecraft:dark_prismarine
fill 180 21 357 180 24 357 minecraft:blue_terracotta
setblock 180 21 361 minecraft:dark_prismarine
fill 180 21 362 180 24 362 minecraft:blue_terracotta
setblock 181 21 335 minecraft:dark_prismarine
fill 181 21 336 181 22 336 minecraft:blue_terracotta
setblock 181 21 340 minecraft:dark_prismarine
setblock 181 21 341 minecraft:blue_terracotta
fill 181 21 351 181 21 354 minecraft:blue_terracotta
setblock 181 21 355 minecraft:dark_prismarine
fill 181 21 356 181 24 356 minecraft:blue_terracotta
setblock 181 21 360 minecraft:dark_prismarine
fill 181 21 361 181 24 361 minecraft:blue_terracotta
setblock 182 21 324 minecraft:dark_prismarine
setblock 182 21 325 minecraft:blue_terracotta
setblock 182 21 330 minecraft:blue_terracotta
setblock 182 21 334 minecraft:dark_prismarine
fill 182 21 335 182 23 335 minecraft:blue_terracotta
setblock 182 21 339 minecraft:dark_prismarine
fill 182 21 340 182 24 340 minecraft:blue_terracotta
setblock 182 21 344 minecraft:dark_prismarine
fill 182 21 345 182 21 348 minecraft:blue_terracotta
setblock 182 21 349 minecraft:dark_prismarine
fill 182 21 350 182 22 350 minecraft:blue_terracotta
setblock 182 21 354 minecraft:dark_prismarine
fill 182 21 355 182 24 355 minecraft:blue_terracotta
setblock 182 21 359 minecraft:dark_prismarine
fill 182 21 360 182 24 360 minecraft:blue_terracotta
fill 183 21 334 183 100 334 minecraft:black_concrete
setblock 142 22 333 minecraft:dark_prismarine
fill 142 22 334 142 23 334 minecraft:blue_terracotta
setblock 142 22 338 minecraft:dark_prismarine
fill 142 22 339 142 25 339 minecraft:blue_terracotta
setblock 142 22 343 minecraft:dark_prismarine
fill 142 22 344 142 25 344 minecraft:blue_terracotta
setblock 142 22 348 minecraft:dark_prismarine
fill 142 22 349 142 25 349 minecraft:blue_terracotta
setblock 142 22 353 minecraft:dark_prismarine
fill 142 22 354 142 25 354 minecraft:blue_terracotta
setblock 142 22 358 minecraft:dark_prismarine
fill 142 22 359 142 25 359 minecraft:blue_terracotta
setblock 142 22 363 minecraft:dark_prismarine
setblock 143 22 337 minecraft:dark_prismarine
fill 143 22 338 143 24 338 minecraft:blue_terracotta
setblock 143 22 342 minecraft:dark_prismarine
fill 143 22 343 143 25 343 minecraft:blue_terracotta
setblock 143 22 353 minecraft:blue_terracotta
setblock 143 22 357 minecraft:dark_prismarine
fill 143 22 358 143 24 358 minecraft:blue_terracotta
setblock 143 22 362 minecraft:dark_prismarine
fill 143 22 363 143 25 363 minecraft:blue_terracotta
setblock 145 22 339 minecraft:black_concrete
setblock 147 22 341 minecraft:black_concrete
setblock 149 22 323 minecraft:purple_concrete
setblock 149 22 335 minecraft:black_concrete
setblock 149 22 341 minecraft:black_concrete
fill 151 22 336 151 22 337 minecraft:black_concrete
setblock 151 22 339 minecraft:black_concrete
fill 155 22 363 156 22 363 minecraft:blue_terracotta
setblock 157 22 323 minecraft:dark_prismarine
fill 157 22 328 157 26 328 minecraft:magenta_terracotta
setblock 157 22 363 minecraft:dark_prismarine
fill 158 22 323 158 25 323 minecraft:blue_terracotta
setblock 158 22 362 minecraft:dark_prismarine
fill 158 22 363 158 25 363 minecraft:blue_terracotta
fill 159 22 362 159 25 362 minecraft:blue_terracotta
setblock 162 22 323 minecraft:dark_prismarine
setblock 162 22 363 minecraft:dark_prismarine
fill 163 22 323 163 25 323 minecraft:blue_terracotta
fill 163 22 363 163 25 363 minecraft:blue_terracotta
setblock 167 22 363 minecraft:dark_prismarine
setblock 168 22 323 minecraft:purple_concrete
fill 168 22 363 168 25 363 minecraft:blue_terracotta
setblock 170 22 323 minecraft:sea_lantern
setblock 170 22 325 minecraft:sea_lantern
setblock 171 22 323 minecraft:blue_terracotta
setblock 171 22 324 minecraft:sea_lantern
setblock 171 22 326 minecraft:sea_lantern
setblock 172 22 323 minecraft:sea_lantern
setblock 172 22 325 minecraft:sea_lantern
setblock 172 22 362 minecraft:blue_terracotta
setblock 172 22 363 minecraft:dark_prismarine
fill 173 22 323 173 25 323 minecraft:blue_terracotta
setblock 173 22 324 minecraft:sea_lantern
setblock 173 22 326 minecraft:sea_lantern
setblock 173 22 362 minecraft:dark_prismarine
fill 173 22 363 173 25 363 minecraft:blue_terracotta
setblock 174 22 323 minecraft:sea_lantern
setblock 174 22 325 minecraft:sea_lantern
fill 174 22 338 174 33 338 minecraft:magenta_terracotta
setblock 174 22 361 minecraft:dark_prismarine
fill 174 22 362 174 25 362 minecraft:blue_terracotta
fill 175 22 323 175 23 323 minecraft:blue_terracotta
setblock 175 22 324 minecraft:sea_lantern
setblock 175 22 326 minecraft:sea_lantern
fill 175 22 361 175 25 361 minecraft:blue_terracotta
setblock 176 22 323 minecraft:sea_lantern
setblock 176 22 325 minecraft:sea_lantern
setblock 177 22 323 minecraft:dark_prismarine
setblock 177 22 324 minecraft:sea_lantern
setblock 177 22 326 minecraft:sea_lantern
setblock 177 22 363 minecraft:dark_prismarine
setblock 178 22 323 minecraft:sea_lantern
setblock 178 22 325 minecraft:sea_lantern
setblock 178 22 362 minecraft:dark_prismarine
fill 178 22 363 178 25 363 minecraft:blue_terracotta
setblock 179 22 324 minecraft:sea_lantern
setblock 179 22 326 minecraft:sea_lantern
setblock 179 22 357 minecraft:blue_terracotta
setblock 179 22 361 minecraft:dark_prismarine
fill 179 22 362 179 25 362 minecraft:blue_terracotta
setblock 180 22 323 minecraft:sea_lantern
fill 180 22 324 180 28 324 minecraft:dark_prismarine
setblock 180 22 325 minecraft:sea_lantern
setblock 180 22 355 minecraft:dark_prismarine
fill 180 22 356 180 24 356 minecraft:blue_terracotta
setblock 180 22 360 minecraft:dark_prismarine
fill 180 22 361 180 25 361 minecraft:blue_terracotta
setblock 181 22 339 minecraft:dark_prismarine
setblock 181 22 340 minecraft:blue_terracotta
fill 181 22 352 181 22 353 minecraft:blue_terracotta
setblock 181 22 354 minecraft:dark_prismarine
fill 181 22 355 181 25 355 minecraft:blue_terracotta
setblock 181 22 359 minecraft:dark_prismarine
fill 181 22 360 181 25 360 minecraft:blue_terracotta
setblock 182 22 323 minecraft:dark_prismarine
setblock 182 22 324 minecraft:blue_terracotta
setblock 182 22 333 minecraft:dark_prismarine
setblock 182 22 334 minecraft:blue_terracotta
setblock 182 22 338 minecraft:dark_prismarine
fill 182 22 339 182 25 339 minecraft:blue_terracotta
setblock 182 22 343 minecraft:dark_prismarine
fill 182 22 344 182 24 345 minecraft:blue_terracotta
setblock 182 22 349 minecraft:blue_terracotta
setblock 182 22 353 minecraft:dark_prismarine
fill 182 22 354 182 25 354 minecraft:blue_terracotta
setblock 182 22 358 minecraft:dark_prismarine
fill 182 22 359 182 25 359 minecraft:blue_terracotta
setblock 182 22 363 minecraft:dark_prismarine
setblock 142 23 337 minecraft:dark_prismarine
fill 142 23 338 142 26 338 minecraft:blue_terracotta
setblock 142 23 342 minecraft:dark_prismarine
fill 142 23 343 142 26 343 minecraft:blue_terracotta
setblock 142 23 347 minecraft:dark_prismarine
fill 142 23 348 142 26 348 minecraft:blue_terracotta
setblock 142 23 352 minecraft:dark_prismarine
fill 142 23 353 142 25 353 minecraft:blue_terracotta
setblock 142 23 357 minecraft:dark_prismarine
fill 142 23 358 142 26 358 minecraft:blue_terracotta
setblock 142 23 362 minecraft:dark_prismarine
fill 142 23 363 142 26 363 minecraft:blue_terracotta
setblock 143 23 323 minecraft:purple_concrete
setblock 143 23 337 minecraft:blue_terracotta
setblock 143 23 341 minecraft:dark_prismarine
fill 143 23 342 143 26 342 minecraft:blue_terracotta
setblock 143 23 356 minecraft:dark_prismarine
setblock 143 23 357 minecraft:blue_terracotta
setblock 143 23 361 minecraft:dark_prismarine
setblock 143 23 362 minecraft:blue_terracotta
setblock 144 23 325 minecraft:light[level=12]
setblock 144 23 332 minecraft:light[level=12]
setblock 144 23 339 minecraft:light[level=12]
setblock 144 23 346 minecraft:light[level=12]
setblock 144 23 353 minecraft:light[level=12]
setblock 144 23 360 minecraft:light[level=12]
fill 147 23 351 147 33 351 minecraft:magenta_terracotta
fill 148 23 340 148 24 340 minecraft:dark_prismarine
fill 149 23 337 149 25 337 minecraft:dark_prismarine
setblock 151 23 325 minecraft:light[level=12]
setblock 151 23 332 minecraft:light[level=12]
setblock 151 23 339 minecraft:light[level=12]
setblock 151 23 346 minecraft:light[level=12]
setblock 151 23 353 minecraft:light[level=12]
setblock 151 23 360 minecraft:light[level=12]
fill 154 23 346 155 24 347 minecraft:spruce_planks
fill 154 23 363 155 23 363 minecraft:blue_terracotta
setblock 155 23 323 minecraft:blue_terracotta
setblock 156 23 323 minecraft:dark_prismarine
setblock 156 23 363 minecraft:dark_prismarine
fill 157 23 323 157 26 323 minecraft:blue_terracotta
setblock 157 23 362 minecraft:dark_prismarine
fill 157 23 363 157 26 363 minecraft:blue_terracotta
setblock 158 23 325 minecraft:light[level=12]
setblock 158 23 332 minecraft:light[level=12]
setblock 158 23 339 minecraft:light[level=12]
setblock 158 23 346 minecraft:light[level=12]
setblock 158 23 353 minecraft:light[level=12]
setblock 158 23 360 minecraft:light[level=12]
fill 158 23 362 158 26 362 minecraft:blue_terracotta
setblock 159 23 324 minecraft:blue_terracotta
setblock 160 23 324 minecraft:dark_prismarine
setblock 161 23 323 minecraft:dark_prismarine
setblock 161 23 363 minecraft:dark_prismarine
fill 162 23 323 162 26 323 minecraft:blue_terracotta
fill 162 23 363 162 26 363 minecraft:blue_terracotta
setblock 165 23 325 minecraft:light[level=12]
setblock 165 23 332 minecraft:light[level=12]
setblock 165 23 339 minecraft:light[level=12]
setblock 165 23 346 minecraft:light[level=12]
setblock 165 23 353 minecraft:light[level=12]
setblock 165 23 360 minecraft:light[level=12]
setblock 166 23 323 minecraft:dark_prismarine
setblock 166 23 363 minecraft:dark_prismarine
fill 167 23 363 167 26 363 minecraft:blue_terracotta
setblock 170 23 323 minecraft:blue_terracotta
fill 170 23 325 170 24 325 minecraft:dark_prismarine
fill 171 23 323 171 23 324 minecraft:dark_prismarine
fill 171 23 326 171 24 326 minecraft:dark_prismarine
setblock 171 23 363 minecraft:dark_prismarine
fill 172 23 323 172 24 323 minecraft:blue_terracotta
fill 172 23 325 172 24 325 minecraft:dark_prismarine
setblock 172 23 332 minecraft:light[level=12]
setblock 172 23 339 minecraft:light[level=12]
setblock 172 23 346 minecraft:light[level=12]
setblock 172 23 353 minecraft:light[level=12]
setblock 172 23 360 minecraft:light[level=12]
setblock 172 23 362 minecraft:dark_prismarine
fill 172 23 363 172 26 363 minecraft:blue_terracotta
fill 173 23 324 173 24 324 minecraft:dark_prismarine
fill 173 23 326 173 24 326 minecraft:dark_prismarine
fill 173 23 362 173 26 362 minecraft:blue_terracotta
fill 174 23 323 174 24 323 minecraft:blue_terracotta
fill 174 23 325 174 24 325 minecraft:dark_prismarine
fill 174 23 361 174 26 361 minecraft:blue_terracotta
setblock 175 23 324 minecraft:dark_prismarine
fill 175 23 326 175 24 326 minecraft:dark_prismarine
setblock 176 23 323 minecraft:dark_prismarine
fill 176 23 324 177 24 324 minecraft:blue_terracotta
fill 176 23 325 176 24 325 minecraft:dark_prismarine
setblock 176 23 363 minecraft:dark_prismarine
fill 177 23 323 178 24 323 minecraft:blue_terracotta
fill 177 23 326 177 24 326 minecraft:dark_prismarine
setblock 177 23 362 minecraft:dark_prismarine
fill 177 23 363 177 26 363 minecraft:blue_terracotta
fill 178 23 325 178 24 325 minecraft:dark_prismarine
setblock 178 23 361 minecraft:dark_prismarine
fill 178 23 362 178 26 362 minecraft:blue_terracotta
fill 179 23 324 179 24 324 minecraft:dark_prismarine
fill 179 23 326 179 24 326 minecraft:dark_prismarine
setblock 179 23 332 minecraft:light[level=12]
setblock 179 23 339 minecraft:light[level=12]
setblock 179 23 346 minecraft:light[level=12]
setblock 179 23 353 minecraft:light[level=12]
setblock 179 23 360 minecraft:dark_prismarine
fill 179 23 361 179 26 361 minecraft:blue_terracotta
setblock 180 23 323 minecraft:blue_terracotta
fill 180 23 325 180 24 325 minecraft:dark_prismarine
setblock 180 23 359 minecraft:dark_prismarine
fill 180 23 360 180 26 360 minecraft:blue_terracotta
setblock 181 23 323 minecraft:dark_prismarine
setblock 181 23 353 minecraft:dark_prismarine
fill 181 23 354 181 24 354 minecraft:blue_terracotta
setblock 181 23 358 minecraft:dark_prismarine
fill 181 23 359 181 26 359 minecraft:blue_terracotta
setblock 181 23 363 minecraft:dark_prismarine
fill 182 23 323 182 26 323 minecraft:blue_terracotta
setblock 182 23 328 minecraft:purple_concrete
setblock 182 23 337 minecraft:dark_prismarine
fill 182 23 338 182 26 338 minecraft:blue_terracotta
setblock 182 23 342 minecraft:dark_prismarine
fill 182 23 343 182 26 343 minecraft:blue_terracotta
setblock 182 23 347 minecraft:purple_concrete
setblock 182 23 352 minecraft:dark_prismarine
fill 182 23 353 182 26 353 minecraft:blue_terracotta
setblock 182 23 357 minecraft:dark_prismarine
fill 182 23 358 182 26 358 minecraft:blue_terracotta
setblock 182 23 362 minecraft:dark_prismarine
fill 182 23 363 182 26 363 minecraft:blue_terracotta
setblock 141 24 363 minecraft:light_blue_wool
setblock 142 24 336 minecraft:dark_prismarine
fill 142 24 337 142 27 337 minecraft:blue_terracotta
setblock 142 24 341 minecraft:dark_prismarine
fill 142 24 342 142 27 342 minecraft:blue_terracotta
setblock 142 24 346 minecraft:dark_prismarine
fill 142 24 347 142 27 347 minecraft:blue_terracotta
setblock 142 24 351 minecraft:dark_prismarine
fill 142 24 352 142 25 352 minecraft:blue_terracotta
setblock 142 24 356 minecraft:dark_prismarine
fill 142 24 357 142 27 357 minecraft:blue_terracotta
setblock 142 24 361 minecraft:dark_prismarine
fill 142 24 362 142 27 362 minecraft:blue_terracotta
setblock 143 24 340 minecraft:dark_prismarine
fill 143 24 341 143 27 341 minecraft:blue_terracotta
setblock 143 24 360 minecraft:dark_prismarine
fill 153 24 363 154 24 363 minecraft:blue_terracotta
setblock 154 24 323 minecraft:blue_terracotta
setblock 155 24 323 minecraft:dark_prismarine
setblock 155 24 363 minecraft:dark_prismarine
fill 156 24 323 156 27 323 minecraft:blue_terracotta
fill 156 24 363 156 27 363 minecraft:blue_terracotta
fill 157 24 362 157 27 362 minecraft:blue_terracotta
setblock 158 24 324 minecraft:blue_terracotta
fill 159 24 322 161 70 322 minecraft:black_concrete
setblock 159 24 324 minecraft:dark_prismarine
setblock 160 24 323 minecraft:dark_prismarine
fill 160 24 324 160 27 324 minecraft:blue_terracotta
setblock 160 24 363 minecraft:dark_prismarine
fill 161 24 323 161 27 323 minecraft:blue_terracotta
fill 161 24 327 161 33 327 minecraft:magenta_terracotta
fill 161 24 363 161 27 363 minecraft:blue_terracotta
setblock 162 24 322 minecraft:cyan_concrete
fill 163 24 322 163 131 322 minecraft:black_concrete
setblock 165 24 323 minecraft:dark_prismarine
setblock 165 24 363 minecraft:dark_prismarine
fill 166 24 323 169 24 323 minecraft:blue_terracotta
fill 166 24 363 166 27 363 minecraft:blue_terracotta
setblock 170 24 323 minecraft:dark_prismarine
setblock 170 24 363 minecraft:dark_prismarine
fill 171 24 323 171 27 323 minecraft:blue_terracotta
setblock 171 24 324 minecraft:dark_prismarine
schedule function dropper:buildpart/75_3 1t
