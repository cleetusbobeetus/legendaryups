setblock 339 300 306 minecraft:light[level=12]
setblock 339 300 313 minecraft:light[level=12]
fill 339 300 317 339 308 317 minecraft:light_blue_concrete
setblock 340 300 317 minecraft:white_wool
setblock 346 300 278 minecraft:light[level=12]
setblock 346 300 285 minecraft:light[level=12]
setblock 346 300 292 minecraft:light[level=12]
setblock 346 300 299 minecraft:light[level=12]
setblock 346 300 306 minecraft:light[level=12]
setblock 346 300 313 minecraft:light[level=12]
setblock 353 300 278 minecraft:light[level=12]
setblock 353 300 285 minecraft:light[level=12]
setblock 353 300 292 minecraft:light[level=12]
setblock 353 300 299 minecraft:light[level=12]
setblock 353 300 306 minecraft:light[level=12]
setblock 353 300 313 minecraft:light[level=12]
setblock 360 300 278 minecraft:light[level=12]
setblock 360 300 285 minecraft:light[level=12]
setblock 360 300 292 minecraft:light[level=12]
setblock 360 300 299 minecraft:light[level=12]
setblock 360 300 306 minecraft:light[level=12]
setblock 360 300 313 minecraft:light[level=12]
setblock 367 300 278 minecraft:light[level=12]
setblock 367 300 285 minecraft:light[level=12]
setblock 367 300 292 minecraft:light[level=12]
setblock 367 300 299 minecraft:light[level=12]
setblock 367 300 306 minecraft:light[level=12]
setblock 367 300 313 minecraft:light[level=12]
fill 371 300 302 371 308 302 minecraft:light_blue_concrete
setblock 371 300 303 minecraft:white_wool
setblock 371 300 313 minecraft:white_wool
fill 371 300 314 371 308 315 minecraft:light_blue_concrete
fill 329 301 294 329 308 294 minecraft:light_blue_concrete
fill 340 301 317 340 308 317 minecraft:light_blue_concrete
setblock 371 301 276 minecraft:white_wool
fill 371 301 303 371 308 303 minecraft:light_blue_concrete
fill 371 301 313 371 306 313 minecraft:light_blue_concrete
fill 371 302 276 371 304 276 minecraft:light_blue_concrete
setblock 341 303 275 minecraft:white_wool
setblock 367 303 317 minecraft:white_wool
setblock 329 304 300 minecraft:white_wool
fill 341 304 275 341 308 275 minecraft:light_blue_concrete
fill 347 304 317 347 308 317 minecraft:light_blue_concrete
setblock 348 304 317 minecraft:white_wool
fill 367 304 317 367 308 317 minecraft:light_blue_concrete
setblock 371 304 300 minecraft:white_wool
fill 329 305 300 329 308 300 minecraft:light_blue_concrete
fill 348 305 317 348 308 317 minecraft:light_blue_concrete
fill 365 305 275 365 308 275 minecraft:light_blue_concrete
setblock 366 305 275 minecraft:white_wool
setblock 371 305 276 minecraft:white_wool
setblock 371 305 292 minecraft:white_wool
fill 371 305 300 371 308 300 minecraft:light_blue_concrete
fill 366 306 275 366 308 275 minecraft:light_blue_concrete
fill 371 306 276 371 308 276 minecraft:light_blue_concrete
fill 371 306 292 371 308 292 minecraft:light_blue_concrete
setblock 342 307 275 minecraft:white_wool
fill 343 307 275 343 308 275 minecraft:light_blue_concrete
setblock 370 307 275 minecraft:white_wool
setblock 371 307 313 minecraft:white_wool
setblock 342 308 275 minecraft:light_blue_concrete
setblock 370 308 275 minecraft:light_blue_concrete
setblock 371 308 313 minecraft:light_blue_concrete
