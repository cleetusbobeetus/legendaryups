setblock 178 116 276 minecraft:snow_block
fill 178 116 277 178 119 277 minecraft:packed_ice
fill 179 116 275 179 132 275 minecraft:blue_ice
fill 179 116 276 179 119 276 minecraft:packed_ice
setblock 179 116 279 minecraft:packed_ice
setblock 179 116 280 minecraft:snow_block
fill 179 116 281 180 117 282 minecraft:packed_ice
setblock 180 116 278 minecraft:packed_ice
setblock 180 116 279 minecraft:snow_block
fill 180 116 280 180 119 280 minecraft:packed_ice
setblock 180 116 283 minecraft:packed_ice
setblock 180 116 284 minecraft:snow_block
fill 180 116 285 180 118 286 minecraft:packed_ice
setblock 181 116 278 minecraft:snow_block
fill 181 116 279 181 119 279 minecraft:packed_ice
setblock 181 116 282 minecraft:packed_ice
setblock 181 116 283 minecraft:snow_block
fill 181 116 284 181 119 284 minecraft:packed_ice
setblock 181 116 288 minecraft:snow_block
fill 181 116 289 181 119 289 minecraft:packed_ice
setblock 181 116 298 minecraft:snow_block
fill 181 116 299 181 117 299 minecraft:packed_ice
setblock 181 116 303 minecraft:snow_block
fill 181 116 304 181 117 306 minecraft:packed_ice
setblock 182 116 277 minecraft:snow_block
fill 182 116 278 182 119 278 minecraft:packed_ice
setblock 182 116 282 minecraft:snow_block
fill 182 116 283 182 119 283 minecraft:packed_ice
setblock 182 116 287 minecraft:snow_block
fill 182 116 288 182 119 288 minecraft:packed_ice
setblock 182 116 292 minecraft:snow_block
fill 182 116 293 182 119 293 minecraft:packed_ice
setblock 182 116 297 minecraft:snow_block
fill 182 116 298 182 119 298 minecraft:packed_ice
setblock 182 116 302 minecraft:snow_block
fill 182 116 303 182 119 303 minecraft:packed_ice
setblock 182 116 307 minecraft:snow_block
fill 182 116 308 182 119 308 minecraft:packed_ice
setblock 182 116 311 minecraft:packed_ice
setblock 182 116 312 minecraft:snow_block
fill 182 116 313 182 119 313 minecraft:packed_ice
fill 182 116 317 182 180 317 minecraft:blue_ice
setblock 183 116 276 minecraft:packed_ice
fill 183 116 277 183 135 278 minecraft:blue_ice
fill 183 116 284 183 127 290 minecraft:blue_ice
fill 183 116 291 183 116 292 minecraft:packed_ice
fill 183 116 293 183 119 301 minecraft:blue_ice
setblock 183 116 302 minecraft:packed_ice
fill 183 116 303 183 162 305 minecraft:blue_ice
fill 183 116 311 183 116 316 minecraft:blue_ice
setblock 183 116 317 minecraft:packed_ice
fill 141 117 282 141 135 283 minecraft:blue_ice
fill 141 117 286 141 180 286 minecraft:blue_ice
fill 141 117 287 142 117 287 minecraft:packed_ice
fill 141 117 288 141 129 291 minecraft:blue_ice
setblock 141 117 292 minecraft:packed_ice
fill 141 117 293 141 134 294 minecraft:blue_ice
fill 141 117 299 141 149 299 minecraft:blue_ice
fill 141 117 306 141 117 307 minecraft:packed_ice
fill 141 117 308 141 157 308 minecraft:blue_ice
fill 141 117 315 141 179 315 minecraft:blue_ice
setblock 142 117 276 minecraft:snow_block
fill 142 117 277 142 120 277 minecraft:packed_ice
setblock 142 117 281 minecraft:snow_block
fill 142 117 282 142 120 282 minecraft:packed_ice
setblock 142 117 286 minecraft:snow_block
fill 142 117 288 142 117 290 minecraft:packed_ice
setblock 142 117 291 minecraft:snow_block
setblock 142 117 296 minecraft:snow_block
fill 142 117 297 142 118 297 minecraft:packed_ice
setblock 142 117 301 minecraft:snow_block
fill 142 117 302 142 120 302 minecraft:packed_ice
setblock 142 117 306 minecraft:snow_block
fill 142 117 307 142 120 307 minecraft:packed_ice
setblock 142 117 310 minecraft:packed_ice
setblock 142 117 311 minecraft:snow_block
fill 142 117 312 142 120 312 minecraft:packed_ice
setblock 142 117 316 minecraft:snow_block
fill 142 117 317 145 175 317 minecraft:blue_ice
fill 143 117 276 143 120 276 minecraft:packed_ice
setblock 143 117 280 minecraft:snow_block
fill 143 117 281 143 120 281 minecraft:packed_ice
setblock 143 117 284 minecraft:packed_ice
setblock 143 117 285 minecraft:snow_block
fill 143 117 286 143 120 286 minecraft:packed_ice
setblock 143 117 299 minecraft:packed_ice
setblock 143 117 300 minecraft:snow_block
fill 143 117 301 143 120 301 minecraft:packed_ice
setblock 143 117 304 minecraft:packed_ice
setblock 143 117 305 minecraft:snow_block
fill 143 117 306 143 120 306 minecraft:packed_ice
setblock 143 117 310 minecraft:snow_block
fill 143 117 311 143 120 311 minecraft:packed_ice
setblock 143 117 314 minecraft:packed_ice
setblock 143 117 315 minecraft:snow_block
fill 143 117 316 143 120 316 minecraft:packed_ice
setblock 144 117 279 minecraft:snow_block
fill 144 117 280 144 119 280 minecraft:packed_ice
setblock 144 117 284 minecraft:snow_block
setblock 144 117 285 minecraft:packed_ice
setblock 144 117 304 minecraft:snow_block
fill 144 117 305 144 120 305 minecraft:packed_ice
setblock 144 117 308 minecraft:packed_ice
setblock 144 117 309 minecraft:snow_block
fill 144 117 310 144 120 310 minecraft:packed_ice
fill 144 117 315 144 120 315 minecraft:packed_ice
fill 145 117 275 146 120 275 minecraft:blue_ice
setblock 145 117 278 minecraft:snow_block
setblock 145 117 279 minecraft:packed_ice
setblock 145 117 306 minecraft:blue_ice
setblock 146 117 277 minecraft:snow_block
setblock 146 117 278 minecraft:packed_ice
setblock 146 117 317 minecraft:packed_ice
setblock 147 117 275 minecraft:packed_ice
setblock 147 117 276 minecraft:snow_block
fill 147 117 277 147 118 277 minecraft:packed_ice
setblock 147 117 316 minecraft:snow_block
fill 147 117 317 149 138 317 minecraft:blue_ice
fill 148 117 275 148 177 275 minecraft:blue_ice
fill 148 117 276 148 118 276 minecraft:packed_ice
setblock 148 117 315 minecraft:snow_block
fill 148 117 316 148 119 316 minecraft:packed_ice
setblock 149 117 275 minecraft:packed_ice
fill 150 117 275 159 122 275 minecraft:blue_ice
fill 154 117 317 154 179 317 minecraft:blue_ice
fill 157 117 317 159 121 317 minecraft:blue_ice
setblock 160 117 275 minecraft:packed_ice
setblock 160 117 317 minecraft:packed_ice
fill 161 117 275 172 122 275 minecraft:blue_ice
fill 161 117 317 169 122 317 minecraft:blue_ice
setblock 162 117 276 minecraft:snow_block
setblock 162 117 277 minecraft:packed_ice
setblock 162 117 316 minecraft:snow_block
fill 163 117 276 163 119 276 minecraft:packed_ice
fill 163 117 316 163 118 316 minecraft:packed_ice
setblock 164 117 277 minecraft:packed_ice
setblock 166 117 277 minecraft:snow_block
setblock 167 117 276 minecraft:snow_block
setblock 167 117 277 minecraft:packed_ice
fill 168 117 276 170 117 276 minecraft:packed_ice
setblock 170 117 317 minecraft:packed_ice
fill 171 117 317 173 137 317 minecraft:blue_ice
setblock 173 117 275 minecraft:packed_ice
fill 174 117 275 174 176 275 minecraft:blue_ice
setblock 174 117 317 minecraft:packed_ice
fill 176 117 275 176 179 275 minecraft:blue_ice
setblock 176 117 276 minecraft:packed_ice
setblock 177 117 276 minecraft:snow_block
fill 177 117 277 177 118 277 minecraft:packed_ice
fill 178 117 275 178 179 275 minecraft:blue_ice
fill 178 117 276 178 120 276 minecraft:packed_ice
setblock 179 117 280 minecraft:packed_ice
setblock 179 117 283 minecraft:packed_ice
fill 180 117 275 181 177 275 minecraft:blue_ice
setblock 180 117 278 minecraft:snow_block
fill 180 117 279 180 120 279 minecraft:packed_ice
setblock 180 117 283 minecraft:snow_block
fill 180 117 284 180 120 284 minecraft:packed_ice
setblock 180 117 287 minecraft:packed_ice
setblock 181 117 277 minecraft:snow_block
fill 181 117 278 181 120 278 minecraft:packed_ice
setblock 181 117 282 minecraft:snow_block
fill 181 117 283 181 120 283 minecraft:packed_ice
setblock 181 117 287 minecraft:snow_block
fill 181 117 288 181 120 288 minecraft:packed_ice
setblock 181 117 298 minecraft:packed_ice
setblock 181 117 302 minecraft:snow_block
fill 181 117 303 181 120 303 minecraft:packed_ice
setblock 182 117 275 minecraft:packed_ice
setblock 182 117 276 minecraft:snow_block
fill 182 117 277 182 120 277 minecraft:packed_ice
setblock 182 117 281 minecraft:snow_block
fill 182 117 282 182 120 282 minecraft:packed_ice
setblock 182 117 286 minecraft:snow_block
fill 182 117 287 182 120 287 minecraft:packed_ice
setblock 182 117 291 minecraft:snow_block
fill 182 117 292 182 120 292 minecraft:packed_ice
setblock 182 117 296 minecraft:snow_block
fill 182 117 297 182 119 297 minecraft:packed_ice
setblock 182 117 301 minecraft:snow_block
fill 182 117 302 182 120 302 minecraft:packed_ice
setblock 182 117 306 minecraft:snow_block
fill 182 117 307 183 117 307 minecraft:packed_ice
setblock 182 117 311 minecraft:snow_block
fill 182 117 312 182 120 312 minecraft:packed_ice
setblock 182 117 316 minecraft:snow_block
fill 183 117 275 183 135 276 minecraft:blue_ice
fill 183 117 291 183 148 292 minecraft:blue_ice
fill 183 117 302 183 179 302 minecraft:blue_ice
fill 183 117 306 183 159 306 minecraft:blue_ice
fill 183 117 308 183 123 314 minecraft:blue_ice
setblock 183 117 315 minecraft:packed_ice
fill 183 117 316 183 175 317 minecraft:blue_ice
fill 141 118 287 141 175 287 minecraft:blue_ice
fill 141 118 292 141 179 292 minecraft:blue_ice
fill 141 118 306 141 136 307 minecraft:blue_ice
fill 142 118 276 142 121 276 minecraft:packed_ice
setblock 142 118 280 minecraft:snow_block
fill 142 118 281 142 121 281 minecraft:packed_ice
setblock 142 118 284 minecraft:packed_ice
setblock 142 118 285 minecraft:snow_block
fill 142 118 286 142 118 289 minecraft:packed_ice
setblock 142 118 290 minecraft:snow_block
setblock 142 118 296 minecraft:packed_ice
setblock 142 118 300 minecraft:snow_block
fill 142 118 301 142 121 301 minecraft:packed_ice
setblock 142 118 305 minecraft:snow_block
fill 142 118 306 142 121 306 minecraft:packed_ice
setblock 142 118 310 minecraft:snow_block
fill 142 118 311 142 121 311 minecraft:packed_ice
setblock 142 118 315 minecraft:snow_block
fill 142 118 316 142 121 316 minecraft:packed_ice
setblock 143 118 279 minecraft:snow_block
fill 143 118 280 143 121 280 minecraft:packed_ice
setblock 143 118 284 minecraft:snow_block
fill 143 118 285 143 121 285 minecraft:packed_ice
setblock 143 118 299 minecraft:snow_block
fill 143 118 300 143 119 300 minecraft:packed_ice
setblock 143 118 304 minecraft:snow_block
fill 143 118 305 143 121 305 minecraft:packed_ice
setblock 143 118 309 minecraft:snow_block
fill 143 118 310 143 121 310 minecraft:packed_ice
setblock 143 118 314 minecraft:snow_block
fill 143 118 315 143 121 315 minecraft:packed_ice
setblock 144 118 278 minecraft:snow_block
fill 144 118 279 144 119 279 minecraft:packed_ice
setblock 144 118 283 minecraft:snow_block
setblock 144 118 284 minecraft:packed_ice
setblock 144 118 285 minecraft:light[level=12]
setblock 144 118 292 minecraft:light[level=12]
setblock 144 118 299 minecraft:light[level=12]
setblock 144 118 303 minecraft:snow_block
fill 144 118 304 144 120 304 minecraft:packed_ice
setblock 144 118 308 minecraft:snow_block
fill 144 118 309 144 121 309 minecraft:packed_ice
setblock 144 118 313 minecraft:light[level=12]
setblock 145 118 277 minecraft:snow_block
setblock 145 118 278 minecraft:packed_ice
setblock 146 118 276 minecraft:snow_block
fill 146 118 277 146 119 277 minecraft:packed_ice
setblock 146 118 316 minecraft:snow_block
setblock 146 118 317 minecraft:blue_ice
fill 147 118 275 147 179 275 minecraft:blue_ice
fill 147 118 276 147 119 276 minecraft:packed_ice
setblock 147 118 315 minecraft:snow_block
fill 147 118 316 147 120 316 minecraft:packed_ice
fill 149 118 275 149 179 275 minecraft:blue_ice
setblock 151 118 278 minecraft:light[level=12]
setblock 151 118 285 minecraft:light[level=12]
setblock 151 118 292 minecraft:light[level=12]
setblock 151 118 299 minecraft:light[level=12]
setblock 151 118 306 minecraft:light[level=12]
setblock 151 118 313 minecraft:light[level=12]
fill 156 118 317 156 179 317 minecraft:blue_ice
setblock 158 118 278 minecraft:light[level=12]
setblock 158 118 285 minecraft:light[level=12]
setblock 158 118 292 minecraft:light[level=12]
setblock 158 118 299 minecraft:light[level=12]
setblock 158 118 306 minecraft:light[level=12]
setblock 158 118 313 minecraft:light[level=12]
fill 160 118 275 160 167 275 minecraft:blue_ice
fill 160 118 317 160 174 317 minecraft:blue_ice
setblock 161 118 276 minecraft:snow_block
setblock 161 118 316 minecraft:snow_block
fill 162 118 276 162 119 276 minecraft:packed_ice
setblock 162 118 316 minecraft:packed_ice
setblock 165 118 278 minecraft:light[level=12]
setblock 165 118 285 minecraft:light[level=12]
setblock 165 118 292 minecraft:light[level=12]
setblock 165 118 299 minecraft:light[level=12]
setblock 165 118 306 minecraft:light[level=12]
setblock 165 118 313 minecraft:light[level=12]
setblock 166 118 276 minecraft:snow_block
setblock 167 118 276 minecraft:packed_ice
fill 170 118 317 170 179 317 minecraft:blue_ice
setblock 172 118 278 minecraft:light[level=12]
setblock 172 118 285 minecraft:light[level=12]
setblock 172 118 292 minecraft:light[level=12]
setblock 172 118 299 minecraft:light[level=12]
setblock 172 118 306 minecraft:light[level=12]
setblock 172 118 313 minecraft:light[level=12]
fill 173 118 275 173 134 275 minecraft:blue_ice
fill 174 118 317 174 176 317 minecraft:blue_ice
setblock 176 118 276 minecraft:snow_block
fill 177 118 276 177 121 276 minecraft:packed_ice
setblock 179 118 278 minecraft:snow_block
fill 179 118 281 179 118 282 minecraft:packed_ice
setblock 179 118 283 minecraft:snow_block
setblock 179 118 285 minecraft:light[level=12]
setblock 179 118 292 minecraft:light[level=12]
setblock 179 118 299 minecraft:light[level=12]
setblock 179 118 313 minecraft:light[level=12]
setblock 180 118 277 minecraft:snow_block
fill 180 118 278 180 120 278 minecraft:packed_ice
setblock 180 118 281 minecraft:packed_ice
setblock 180 118 282 minecraft:snow_block
fill 180 118 283 180 121 283 minecraft:packed_ice
setblock 180 118 287 minecraft:snow_block
setblock 180 118 316 minecraft:packed_ice
setblock 181 118 276 minecraft:snow_block
fill 181 118 277 181 121 277 minecraft:packed_ice
setblock 181 118 281 minecraft:snow_block
fill 181 118 282 181 121 282 minecraft:packed_ice
setblock 181 118 286 minecraft:snow_block
fill 181 118 287 181 121 287 minecraft:packed_ice
setblock 181 118 301 minecraft:snow_block
fill 181 118 302 181 119 302 minecraft:packed_ice
fill 181 118 304 181 118 305 minecraft:packed_ice
setblock 181 118 306 minecraft:snow_block
fill 181 118 307 182 120 307 minecraft:packed_ice
setblock 181 118 316 minecraft:snow_block
fill 182 118 275 182 128 275 minecraft:blue_ice
fill 182 118 276 182 121 276 minecraft:packed_ice
setblock 182 118 280 minecraft:snow_block
fill 182 118 281 182 121 281 minecraft:packed_ice
setblock 182 118 285 minecraft:snow_block
fill 182 118 286 182 121 286 minecraft:packed_ice
setblock 182 118 290 minecraft:snow_block
fill 182 118 291 182 121 291 minecraft:packed_ice
setblock 182 118 295 minecraft:snow_block
fill 182 118 296 182 119 296 minecraft:packed_ice
setblock 182 118 300 minecraft:snow_block
fill 182 118 301 182 121 301 minecraft:packed_ice
setblock 182 118 305 minecraft:snow_block
fill 182 118 306 182 121 306 minecraft:packed_ice
setblock 182 118 309 minecraft:packed_ice
setblock 182 118 310 minecraft:snow_block
fill 182 118 311 182 121 311 minecraft:packed_ice
setblock 182 118 315 minecraft:snow_block
fill 182 118 316 182 121 316 minecraft:packed_ice
fill 183 118 307 183 155 307 minecraft:blue_ice
fill 183 118 315 183 177 315 minecraft:blue_ice
setblock 142 119 279 minecraft:snow_block
fill 142 119 280 142 122 280 minecraft:packed_ice
setblock 142 119 284 minecraft:snow_block
fill 142 119 285 142 119 288 minecraft:packed_ice
setblock 142 119 289 minecraft:snow_block
fill 142 119 290 142 122 290 minecraft:packed_ice
setblock 142 119 299 minecraft:snow_block
fill 142 119 300 142 122 300 minecraft:packed_ice
setblock 142 119 304 minecraft:snow_block
fill 142 119 305 142 122 305 minecraft:packed_ice
setblock 142 119 309 minecraft:snow_block
fill 142 119 310 142 122 310 minecraft:packed_ice
setblock 142 119 314 minecraft:snow_block
fill 142 119 315 142 122 315 minecraft:packed_ice
setblock 143 119 278 minecraft:snow_block
fill 143 119 279 143 121 279 minecraft:packed_ice
setblock 143 119 283 minecraft:snow_block
fill 143 119 284 143 122 284 minecraft:packed_ice
setblock 143 119 303 minecraft:snow_block
fill 143 119 304 143 122 304 minecraft:packed_ice
setblock 143 119 308 minecraft:snow_block
fill 143 119 309 143 122 309 minecraft:packed_ice
setblock 143 119 313 minecraft:snow_block
fill 143 119 314 143 122 314 minecraft:packed_ice
setblock 144 119 277 minecraft:snow_block
setblock 144 119 278 minecraft:packed_ice
setblock 144 119 282 minecraft:snow_block
setblock 144 119 283 minecraft:packed_ice
setblock 144 119 303 minecraft:packed_ice
setblock 144 119 307 minecraft:snow_block
fill 144 119 308 144 122 308 minecraft:packed_ice
setblock 145 119 276 minecraft:snow_block
setblock 145 119 277 minecraft:packed_ice
setblock 145 119 316 minecraft:snow_block
fill 146 119 276 146 120 276 minecraft:packed_ice
fill 146 119 316 146 121 316 minecraft:packed_ice
setblock 146 119 317 minecraft:white_concrete
setblock 165 119 276 minecraft:snow_block
setblock 176 119 276 minecraft:packed_ice
setblock 179 119 277 minecraft:snow_block
setblock 179 119 278 minecraft:packed_ice
setblock 179 119 282 minecraft:snow_block
fill 179 119 283 179 119 284 minecraft:packed_ice
setblock 180 119 276 minecraft:snow_block
fill 180 119 277 180 122 277 minecraft:packed_ice
setblock 180 119 281 minecraft:snow_block
fill 180 119 282 180 122 282 minecraft:packed_ice
setblock 180 119 285 minecraft:packed_ice
setblock 180 119 286 minecraft:snow_block
fill 180 119 287 180 122 287 minecraft:packed_ice
setblock 180 119 316 minecraft:snow_block
fill 181 119 276 181 122 276 minecraft:packed_ice
setblock 181 119 280 minecraft:snow_block
fill 181 119 281 181 122 281 minecraft:packed_ice
setblock 181 119 285 minecraft:snow_block
fill 181 119 286 181 122 286 minecraft:packed_ice
setblock 181 119 290 minecraft:snow_block
setblock 181 119 301 minecraft:packed_ice
setblock 181 119 304 minecraft:packed_ice
setblock 181 119 305 minecraft:snow_block
fill 181 119 306 181 122 306 minecraft:packed_ice
fill 181 119 308 181 120 308 minecraft:packed_ice
fill 181 119 316 181 122 316 minecraft:packed_ice
setblock 182 119 279 minecraft:snow_block
fill 182 119 280 182 122 280 minecraft:packed_ice
setblock 182 119 284 minecraft:snow_block
fill 182 119 285 182 122 285 minecraft:packed_ice
setblock 182 119 289 minecraft:snow_block
fill 182 119 290 182 122 290 minecraft:packed_ice
setblock 182 119 294 minecraft:snow_block
setblock 182 119 295 minecraft:packed_ice
setblock 182 119 299 minecraft:snow_block
fill 182 119 300 182 121 300 minecraft:packed_ice
setblock 182 119 304 minecraft:snow_block
fill 182 119 305 182 122 305 minecraft:packed_ice
setblock 182 119 309 minecraft:snow_block
fill 182 119 310 182 122 310 minecraft:packed_ice
setblock 182 119 314 minecraft:snow_block
fill 182 119 315 182 122 315 minecraft:packed_ice
setblock 142 120 278 minecraft:snow_block
fill 142 120 279 142 123 279 minecraft:packed_ice
setblock 142 120 283 minecraft:snow_block
fill 142 120 284 142 120 287 minecraft:packed_ice
setblock 142 120 288 minecraft:snow_block
fill 142 120 289 142 123 289 minecraft:packed_ice
fill 142 120 296 143 123 298 minecraft:blue_ice
setblock 142 120 299 minecraft:packed_ice
setblock 142 120 303 minecraft:snow_block
fill 142 120 304 142 123 304 minecraft:packed_ice
setblock 142 120 308 minecraft:snow_block
fill 142 120 309 142 123 309 minecraft:packed_ice
setblock 142 120 313 minecraft:snow_block
fill 142 120 314 142 123 314 minecraft:packed_ice
setblock 143 120 277 minecraft:snow_block
fill 143 120 278 143 121 278 minecraft:packed_ice
setblock 143 120 282 minecraft:snow_block
fill 143 120 283 143 122 283 minecraft:packed_ice
setblock 143 120 287 minecraft:snow_block
setblock 143 120 302 minecraft:snow_block
fill 143 120 303 143 123 303 minecraft:packed_ice
setblock 143 120 307 minecraft:snow_block
fill 143 120 308 143 123 308 minecraft:packed_ice
setblock 143 120 312 minecraft:snow_block
fill 143 120 313 143 123 313 minecraft:packed_ice
setblock 144 120 276 minecraft:snow_block
setblock 144 120 277 minecraft:packed_ice
fill 144 120 297 144 123 297 minecraft:blue_ice
setblock 144 120 306 minecraft:snow_block
fill 144 120 307 144 123 307 minecraft:packed_ice
setblock 144 120 316 minecraft:snow_block
fill 145 120 276 145 121 276 minecraft:packed_ice
fill 145 120 316 145 123 316 minecraft:packed_ice
fill 146 120 317 146 175 317 minecraft:blue_ice
setblock 178 120 277 minecraft:snow_block
setblock 179 120 276 minecraft:snow_block
fill 179 120 277 179 123 277 minecraft:packed_ice
setblock 179 120 283 minecraft:packed_ice
fill 180 120 276 180 123 276 minecraft:packed_ice
setblock 180 120 280 minecraft:snow_block
fill 180 120 281 180 123 281 minecraft:packed_ice
setblock 180 120 285 minecraft:snow_block
fill 180 120 286 180 123 286 minecraft:packed_ice
fill 180 120 316 180 123 316 minecraft:packed_ice
setblock 181 120 279 minecraft:snow_block
fill 181 120 280 181 123 280 minecraft:packed_ice
setblock 181 120 284 minecraft:snow_block
fill 181 120 285 181 123 285 minecraft:packed_ice
setblock 181 120 289 minecraft:snow_block
fill 181 120 290 181 123 290 minecraft:packed_ice
setblock 181 120 304 minecraft:snow_block
fill 181 120 305 181 123 305 minecraft:packed_ice
setblock 182 120 278 minecraft:snow_block
fill 182 120 279 182 123 279 minecraft:packed_ice
setblock 182 120 283 minecraft:snow_block
fill 182 120 284 182 123 284 minecraft:packed_ice
setblock 182 120 288 minecraft:snow_block
fill 182 120 289 182 123 289 minecraft:packed_ice
setblock 182 120 299 minecraft:packed_ice
setblock 182 120 303 minecraft:snow_block
fill 182 120 304 182 123 304 minecraft:packed_ice
setblock 182 120 308 minecraft:snow_block
fill 182 120 309 182 123 309 minecraft:packed_ice
setblock 182 120 313 minecraft:snow_block
fill 182 120 314 182 123 314 minecraft:packed_ice
fill 183 120 293 183 164 297 minecraft:blue_ice
setblock 183 120 298 minecraft:white_concrete
fill 183 120 299 183 130 301 minecraft:blue_ice
setblock 142 121 277 minecraft:snow_block
fill 142 121 278 142 124 278 minecraft:packed_ice
setblock 142 121 282 minecraft:snow_block
fill 142 121 283 142 121 286 minecraft:packed_ice
setblock 142 121 287 minecraft:snow_block
fill 142 121 288 142 124 288 minecraft:packed_ice
fill 142 121 295 143 122 295 minecraft:blue_ice
fill 142 121 299 143 122 299 minecraft:blue_ice
setblock 142 121 302 minecraft:snow_block
fill 142 121 303 142 124 303 minecraft:packed_ice
setblock 142 121 307 minecraft:snow_block
fill 142 121 308 142 124 308 minecraft:packed_ice
setblock 142 121 312 minecraft:snow_block
fill 142 121 313 142 124 313 minecraft:packed_ice
setblock 143 121 276 minecraft:snow_block
setblock 143 121 281 minecraft:snow_block
fill 143 121 282 143 122 282 minecraft:packed_ice
setblock 143 121 286 minecraft:snow_block
setblock 143 121 302 minecraft:packed_ice
setblock 143 121 306 minecraft:snow_block
fill 143 121 307 143 124 307 minecraft:packed_ice
setblock 143 121 311 minecraft:snow_block
fill 143 121 312 143 124 312 minecraft:packed_ice
setblock 143 121 316 minecraft:snow_block
fill 144 121 276 144 122 276 minecraft:packed_ice
fill 144 121 296 145 122 296 minecraft:blue_ice
fill 144 121 298 145 122 298 minecraft:blue_ice
setblock 144 121 305 minecraft:snow_block
fill 144 121 306 144 123 306 minecraft:packed_ice
setblock 144 121 310 minecraft:snow_block
fill 144 121 316 144 124 316 minecraft:packed_ice
fill 145 121 275 145 167 275 minecraft:blue_ice
fill 145 121 297 146 123 297 minecraft:blue_ice
setblock 146 121 275 minecraft:light_blue_concrete
setblock 178 121 276 minecraft:snow_block
fill 179 121 276 179 124 276 minecraft:packed_ice
setblock 180 121 279 minecraft:snow_block
fill 180 121 280 180 124 280 minecraft:packed_ice
setblock 180 121 284 minecraft:snow_block
fill 180 121 285 180 124 285 minecraft:packed_ice
setblock 180 121 288 minecraft:packed_ice
setblock 181 121 278 minecraft:snow_block
fill 181 121 279 181 124 279 minecraft:packed_ice
setblock 181 121 283 minecraft:snow_block
fill 181 121 284 181 124 284 minecraft:packed_ice
setblock 181 121 288 minecraft:snow_block
fill 181 121 289 181 124 289 minecraft:packed_ice
setblock 181 121 304 minecraft:packed_ice
setblock 181 121 307 minecraft:packed_ice
setblock 181 121 308 minecraft:snow_block
fill 181 121 309 181 124 309 minecraft:packed_ice
setblock 182 121 277 minecraft:snow_block
fill 182 121 278 182 124 278 minecraft:packed_ice
setblock 182 121 282 minecraft:snow_block
fill 182 121 283 182 124 283 minecraft:packed_ice
setblock 182 121 287 minecraft:snow_block
fill 182 121 288 182 124 288 minecraft:packed_ice
setblock 182 121 292 minecraft:snow_block
setblock 182 121 302 minecraft:snow_block
fill 182 121 303 182 124 303 minecraft:packed_ice
setblock 182 121 307 minecraft:snow_block
fill 182 121 308 182 124 308 minecraft:packed_ice
setblock 182 121 312 minecraft:snow_block
fill 182 121 313 182 124 313 minecraft:packed_ice
fill 183 121 298 183 179 298 minecraft:blue_ice
setblock 142 122 276 minecraft:snow_block
fill 142 122 277 142 125 277 minecraft:packed_ice
setblock 142 122 281 minecraft:snow_block
fill 142 122 282 142 122 285 minecraft:packed_ice
setblock 142 122 286 minecraft:snow_block
fill 142 122 287 142 125 287 minecraft:packed_ice
setblock 142 122 301 minecraft:snow_block
fill 142 122 302 142 125 302 minecraft:packed_ice
setblock 142 122 306 minecraft:snow_block
fill 142 122 307 142 125 307 minecraft:packed_ice
setblock 142 122 311 minecraft:snow_block
fill 142 122 312 142 125 312 minecraft:packed_ice
setblock 142 122 316 minecraft:snow_block
fill 143 122 276 143 123 276 minecraft:packed_ice
setblock 143 122 281 minecraft:packed_ice
setblock 143 122 285 minecraft:snow_block
setblock 143 122 286 minecraft:packed_ice
setblock 143 122 305 minecraft:snow_block
fill 143 122 306 143 125 306 minecraft:packed_ice
setblock 143 122 310 minecraft:snow_block
fill 143 122 311 143 125 311 minecraft:packed_ice
setblock 143 122 315 minecraft:snow_block
fill 143 122 316 143 125 316 minecraft:packed_ice
setblock 144 122 309 minecraft:snow_block
fill 144 122 310 144 125 310 minecraft:packed_ice
fill 145 122 278 145 127 278 minecraft:packed_ice
fill 146 122 275 146 137 275 minecraft:blue_ice
setblock 146 122 296 minecraft:blue_ice
setblock 146 122 298 minecraft:blue_ice
setblock 147 122 297 minecraft:blue_ice
fill 157 122 317 157 179 317 minecraft:blue_ice
setblock 158 122 317 minecraft:light_blue_concrete
fill 159 122 317 159 149 317 minecraft:blue_ice
setblock 175 122 275 minecraft:white_concrete
setblock 177 122 276 minecraft:snow_block
fill 178 122 276 178 125 276 minecraft:packed_ice
setblock 180 122 279 minecraft:packed_ice
setblock 180 122 283 minecraft:snow_block
fill 180 122 284 180 125 284 minecraft:packed_ice
setblock 180 122 288 minecraft:snow_block
setblock 181 122 277 minecraft:snow_block
fill 181 122 278 181 125 278 minecraft:packed_ice
setblock 181 122 282 minecraft:snow_block
fill 181 122 283 181 125 283 minecraft:packed_ice
setblock 181 122 287 minecraft:snow_block
fill 181 122 288 181 125 288 minecraft:packed_ice
setblock 181 122 307 minecraft:snow_block
fill 181 122 308 181 125 308 minecraft:packed_ice
fill 181 122 310 181 122 311 minecraft:packed_ice
setblock 182 122 276 minecraft:snow_block
fill 182 122 277 182 125 277 minecraft:packed_ice
setblock 182 122 281 minecraft:snow_block
fill 182 122 282 182 125 282 minecraft:packed_ice
setblock 182 122 286 minecraft:snow_block
fill 182 122 287 182 125 287 minecraft:packed_ice
setblock 182 122 291 minecraft:snow_block
fill 182 122 292 182 125 292 minecraft:packed_ice
fill 182 122 302 182 123 302 minecraft:packed_ice
setblock 182 122 306 minecraft:snow_block
fill 182 122 307 182 125 307 minecraft:packed_ice
setblock 182 122 311 minecraft:snow_block
fill 182 122 312 182 125 312 minecraft:packed_ice
setblock 182 122 316 minecraft:snow_block
setblock 141 123 295 minecraft:white_concrete
fill 141 123 296 141 179 298 minecraft:blue_ice
fill 141 123 309 141 128 309 minecraft:blue_ice
setblock 141 123 310 minecraft:white_concrete
fill 141 123 311 141 133 312 minecraft:blue_ice
fill 142 123 276 142 126 276 minecraft:packed_ice
setblock 142 123 280 minecraft:snow_block
fill 142 123 281 142 123 284 minecraft:packed_ice
setblock 142 123 285 minecraft:snow_block
fill 142 123 286 142 126 286 minecraft:packed_ice
setblock 142 123 290 minecraft:snow_block
fill 142 123 301 142 126 301 minecraft:packed_ice
setblock 142 123 305 minecraft:snow_block
fill 142 123 306 142 126 306 minecraft:packed_ice
setblock 142 123 310 minecraft:snow_block
fill 142 123 311 142 126 311 minecraft:packed_ice
setblock 142 123 315 minecraft:snow_block
fill 142 123 316 142 126 316 minecraft:packed_ice
setblock 143 123 284 minecraft:snow_block
setblock 143 123 285 minecraft:packed_ice
setblock 143 123 304 minecraft:snow_block
fill 143 123 305 143 126 305 minecraft:packed_ice
setblock 143 123 309 minecraft:snow_block
fill 143 123 310 143 126 310 minecraft:packed_ice
setblock 143 123 314 minecraft:snow_block
fill 143 123 315 143 126 315 minecraft:packed_ice
setblock 144 123 296 minecraft:blue_ice
setblock 144 123 298 minecraft:blue_ice
setblock 144 123 308 minecraft:snow_block
fill 144 123 309 144 126 309 minecraft:packed_ice
fill 144 123 311 144 124 311 minecraft:packed_ice
fill 150 123 275 158 126 275 minecraft:blue_ice
fill 158 123 317 158 179 317 minecraft:blue_ice
setblock 159 123 275 minecraft:light_blue_concrete
fill 161 123 275 166 142 275 minecraft:blue_ice
setblock 161 123 317 minecraft:white_concrete
fill 162 123 317 169 144 317 minecraft:blue_ice
setblock 167 123 275 minecraft:white_concrete
fill 168 123 275 172 132 275 minecraft:blue_ice
fill 175 123 275 175 145 275 minecraft:blue_ice
fill 177 123 276 177 126 276 minecraft:packed_ice
fill 179 123 316 179 124 316 minecraft:packed_ice
setblock 180 123 277 minecraft:snow_block
setblock 180 123 282 minecraft:snow_block
fill 180 123 283 180 126 283 minecraft:packed_ice
setblock 180 123 287 minecraft:snow_block
fill 180 123 288 180 126 288 minecraft:packed_ice
setblock 181 123 276 minecraft:snow_block
fill 181 123 277 181 126 277 minecraft:packed_ice
setblock 181 123 281 minecraft:snow_block
fill 181 123 282 181 126 282 minecraft:packed_ice
setblock 181 123 286 minecraft:snow_block
fill 181 123 287 181 126 287 minecraft:packed_ice
setblock 181 123 306 minecraft:snow_block
fill 181 123 307 181 126 307 minecraft:packed_ice
setblock 181 123 310 minecraft:packed_ice
setblock 181 123 311 minecraft:snow_block
fill 181 123 312 181 125 313 minecraft:packed_ice
setblock 181 123 316 minecraft:snow_block
fill 182 123 276 182 126 276 minecraft:packed_ice
setblock 182 123 280 minecraft:snow_block
fill 182 123 281 182 126 281 minecraft:packed_ice
setblock 182 123 285 minecraft:snow_block
fill 182 123 286 182 126 286 minecraft:packed_ice
setblock 182 123 290 minecraft:snow_block
fill 182 123 291 182 126 291 minecraft:packed_ice
setblock 182 123 305 minecraft:snow_block
fill 182 123 306 182 126 306 minecraft:packed_ice
setblock 182 123 310 minecraft:snow_block
fill 182 123 311 182 126 311 minecraft:packed_ice
setblock 182 123 315 minecraft:snow_block
fill 182 123 316 182 126 316 minecraft:packed_ice
fill 141 124 295 141 134 295 minecraft:blue_ice
fill 141 124 310 141 177 310 minecraft:blue_ice
setblock 141 124 316 minecraft:light_blue_concrete
fill 141 124 317 141 180 317 minecraft:blue_ice
setblock 142 124 279 minecraft:snow_block
fill 142 124 280 142 124 283 minecraft:packed_ice
setblock 142 124 284 minecraft:snow_block
fill 142 124 285 142 127 285 minecraft:packed_ice
setblock 142 124 289 minecraft:snow_block
fill 142 124 290 142 126 291 minecraft:packed_ice
setblock 142 124 304 minecraft:snow_block
fill 142 124 305 142 127 305 minecraft:packed_ice
setblock 142 124 309 minecraft:snow_block
fill 142 124 310 142 127 310 minecraft:packed_ice
setblock 142 124 314 minecraft:snow_block
fill 142 124 315 142 127 315 minecraft:packed_ice
fill 143 124 304 143 127 304 minecraft:packed_ice
setblock 143 124 308 minecraft:snow_block
fill 143 124 309 143 127 309 minecraft:packed_ice
setblock 143 124 313 minecraft:snow_block
fill 143 124 314 143 127 314 minecraft:packed_ice
setblock 144 124 278 minecraft:light[level=15]
setblock 144 124 285 minecraft:light[level=12]
setblock 144 124 286 minecraft:light[level=15]
setblock 144 124 292 minecraft:light[level=12]
setblock 144 124 294 minecraft:light[level=15]
setblock 144 124 299 minecraft:light[level=12]
setblock 144 124 302 minecraft:light[level=15]
setblock 144 124 306 minecraft:light[level=12]
setblock 144 124 307 minecraft:snow_block
fill 144 124 308 144 127 308 minecraft:packed_ice
setblock 144 124 313 minecraft:light[level=12]
setblock 145 124 316 minecraft:snow_block
setblock 151 124 278 minecraft:light[level=12]
setblock 151 124 285 minecraft:light[level=12]
setblock 151 124 292 minecraft:light[level=12]
setblock 151 124 299 minecraft:light[level=12]
setblock 151 124 306 minecraft:light[level=12]
setblock 151 124 313 minecraft:light[level=12]
setblock 152 124 278 minecraft:light[level=15]
setblock 152 124 286 minecraft:light[level=15]
setblock 152 124 294 minecraft:light[level=15]
setblock 152 124 302 minecraft:light[level=15]
setblock 152 124 310 minecraft:light[level=15]
setblock 158 124 278 minecraft:light[level=12]
setblock 158 124 285 minecraft:light[level=12]
setblock 158 124 292 minecraft:light[level=12]
setblock 158 124 299 minecraft:light[level=12]
setblock 158 124 306 minecraft:light[level=12]
setblock 158 124 313 minecraft:light[level=12]
fill 159 124 275 159 175 275 minecraft:blue_ice
setblock 160 124 278 minecraft:light[level=15]
setblock 160 124 286 minecraft:light[level=15]
setblock 160 124 294 minecraft:light[level=15]
setblock 160 124 302 minecraft:light[level=15]
setblock 160 124 310 minecraft:light[level=15]
fill 161 124 317 161 142 317 minecraft:blue_ice
setblock 165 124 278 minecraft:light[level=12]
setblock 165 124 285 minecraft:light[level=12]
setblock 165 124 292 minecraft:light[level=12]
setblock 165 124 299 minecraft:light[level=12]
setblock 165 124 306 minecraft:light[level=12]
setblock 165 124 313 minecraft:light[level=12]
fill 167 124 275 167 179 275 minecraft:blue_ice
setblock 168 124 278 minecraft:light[level=15]
setblock 168 124 286 minecraft:light[level=15]
setblock 168 124 294 minecraft:light[level=15]
setblock 168 124 302 minecraft:light[level=15]
setblock 168 124 310 minecraft:light[level=15]
setblock 172 124 278 minecraft:light[level=12]
setblock 172 124 285 minecraft:light[level=12]
setblock 172 124 292 minecraft:light[level=12]
setblock 172 124 299 minecraft:light[level=12]
setblock 172 124 306 minecraft:light[level=12]
setblock 172 124 313 minecraft:light[level=12]
fill 176 124 276 176 127 276 minecraft:packed_ice
setblock 176 124 278 minecraft:light[level=15]
setblock 176 124 286 minecraft:light[level=15]
setblock 176 124 294 minecraft:light[level=15]
setblock 176 124 302 minecraft:light[level=15]
setblock 176 124 310 minecraft:light[level=15]
fill 177 124 316 178 125 316 minecraft:packed_ice
setblock 178 124 277 minecraft:packed_ice
setblock 179 124 277 minecraft:snow_block
setblock 179 124 278 minecraft:light[level=12]
setblock 179 124 285 minecraft:light[level=12]
setblock 179 124 292 minecraft:light[level=12]
setblock 179 124 299 minecraft:light[level=12]
setblock 179 124 313 minecraft:light[level=12]
setblock 180 124 276 minecraft:snow_block
fill 180 124 277 180 127 277 minecraft:packed_ice
setblock 180 124 281 minecraft:snow_block
fill 180 124 282 180 127 282 minecraft:packed_ice
setblock 180 124 286 minecraft:snow_block
fill 180 124 287 180 127 287 minecraft:packed_ice
fill 180 124 289 180 125 289 minecraft:packed_ice
setblock 180 124 315 minecraft:packed_ice
setblock 180 124 316 minecraft:snow_block
fill 181 124 276 181 127 276 minecraft:packed_ice
setblock 181 124 280 minecraft:snow_block
fill 181 124 281 181 127 281 minecraft:packed_ice
setblock 181 124 285 minecraft:snow_block
fill 181 124 286 181 127 286 minecraft:packed_ice
setblock 181 124 290 minecraft:snow_block
fill 181 124 291 181 127 291 minecraft:packed_ice
setblock 181 124 305 minecraft:snow_block
fill 181 124 306 181 127 306 minecraft:packed_ice
setblock 181 124 310 minecraft:snow_block
fill 181 124 311 181 127 311 minecraft:packed_ice
setblock 181 124 314 minecraft:packed_ice
setblock 181 124 315 minecraft:snow_block
fill 181 124 316 181 127 316 minecraft:packed_ice
setblock 182 124 279 minecraft:snow_block
fill 182 124 280 182 127 280 minecraft:packed_ice
setblock 182 124 284 minecraft:snow_block
fill 182 124 285 182 127 285 minecraft:packed_ice
setblock 182 124 289 minecraft:snow_block
fill 182 124 290 182 127 290 minecraft:packed_ice
setblock 182 124 304 minecraft:snow_block
fill 182 124 305 182 127 305 minecraft:packed_ice
setblock 182 124 309 minecraft:snow_block
fill 182 124 310 182 127 310 minecraft:packed_ice
setblock 182 124 314 minecraft:snow_block
fill 182 124 315 182 127 315 minecraft:packed_ice
fill 183 124 308 183 127 313 minecraft:blue_ice
setblock 183 124 314 minecraft:white_concrete
fill 141 125 316 141 146 316 minecraft:blue_ice
setblock 142 125 278 minecraft:snow_block
fill 142 125 279 142 125 282 minecraft:packed_ice
setblock 142 125 283 minecraft:snow_block
fill 142 125 284 142 128 284 minecraft:packed_ice
setblock 142 125 288 minecraft:snow_block
fill 142 125 289 142 128 289 minecraft:packed_ice
setblock 142 125 292 minecraft:packed_ice
setblock 142 125 303 minecraft:snow_block
fill 142 125 304 142 128 304 minecraft:packed_ice
setblock 142 125 308 minecraft:snow_block
fill 142 125 309 142 128 309 minecraft:packed_ice
setblock 142 125 313 minecraft:snow_block
fill 142 125 314 142 128 314 minecraft:packed_ice
setblock 143 125 307 minecraft:snow_block
fill 143 125 308 143 128 308 minecraft:packed_ice
setblock 143 125 312 minecraft:snow_block
fill 143 125 313 143 128 313 minecraft:packed_ice
fill 144 125 278 144 127 278 minecraft:packed_ice
fill 144 125 307 144 127 307 minecraft:packed_ice
setblock 144 125 311 minecraft:snow_block
fill 144 125 312 144 128 312 minecraft:packed_ice
setblock 144 125 315 minecraft:packed_ice
setblock 144 125 316 minecraft:snow_block
fill 145 125 277 145 127 277 minecraft:packed_ice
fill 145 125 279 145 127 279 minecraft:packed_ice
fill 145 125 316 146 127 316 minecraft:packed_ice
fill 146 125 278 146 127 278 minecraft:packed_ice
fill 157 125 316 158 125 316 minecraft:packed_ice
setblock 159 125 316 minecraft:snow_block
fill 175 125 276 175 128 276 minecraft:packed_ice
fill 176 125 316 176 127 316 minecraft:packed_ice
setblock 177 125 277 minecraft:packed_ice
setblock 178 125 277 minecraft:snow_block
fill 178 125 315 179 125 315 minecraft:packed_ice
setblock 179 125 276 minecraft:snow_block
fill 179 125 277 179 128 277 minecraft:packed_ice
setblock 179 125 286 minecraft:snow_block
setblock 179 125 316 minecraft:snow_block
fill 180 125 276 180 128 276 minecraft:packed_ice
fill 180 125 281 180 126 281 minecraft:packed_ice
setblock 180 125 285 minecraft:snow_block
fill 180 125 286 180 128 286 minecraft:packed_ice
setblock 180 125 309 minecraft:packed_ice
setblock 180 125 310 minecraft:snow_block
fill 180 125 311 180 128 311 minecraft:packed_ice
setblock 180 125 315 minecraft:snow_block
fill 180 125 316 180 128 316 minecraft:packed_ice
setblock 181 125 279 minecraft:snow_block
fill 181 125 280 181 128 280 minecraft:packed_ice
setblock 181 125 284 minecraft:snow_block
fill 181 125 285 181 128 285 minecraft:packed_ice
setblock 181 125 289 minecraft:snow_block
fill 181 125 290 181 128 290 minecraft:packed_ice
fill 181 125 305 181 126 305 minecraft:packed_ice
setblock 181 125 309 minecraft:snow_block
fill 181 125 310 181 128 310 minecraft:packed_ice
setblock 181 125 314 minecraft:snow_block
fill 181 125 315 181 128 315 minecraft:packed_ice
setblock 182 125 278 minecraft:snow_block
fill 182 125 279 182 128 279 minecraft:packed_ice
setblock 182 125 283 minecraft:snow_block
fill 182 125 284 182 128 284 minecraft:packed_ice
setblock 182 125 288 minecraft:snow_block
fill 182 125 289 182 128 289 minecraft:packed_ice
setblock 182 125 293 minecraft:snow_block
setblock 182 125 303 minecraft:snow_block
fill 182 125 304 182 128 304 minecraft:packed_ice
setblock 182 125 308 minecraft:snow_block
fill 182 125 309 182 128 309 minecraft:packed_ice
setblock 182 125 313 minecraft:snow_block
fill 182 125 314 182 128 314 minecraft:packed_ice
fill 183 125 314 183 180 314 minecraft:blue_ice
fill 141 126 300 141 131 304 minecraft:blue_ice
setblock 141 126 305 minecraft:light_blue_concrete
setblock 142 126 277 minecraft:snow_block
fill 142 126 280 142 126 281 minecraft:packed_ice
setblock 142 126 282 minecraft:snow_block
fill 142 126 283 142 128 283 minecraft:packed_ice
setblock 142 126 287 minecraft:snow_block
fill 142 126 288 142 129 288 minecraft:packed_ice
setblock 142 126 292 minecraft:snow_block
fill 142 126 293 142 129 293 minecraft:packed_ice
setblock 142 126 302 minecraft:snow_block
fill 142 126 303 142 129 303 minecraft:packed_ice
setblock 142 126 307 minecraft:snow_block
fill 142 126 308 142 129 308 minecraft:packed_ice
setblock 142 126 312 minecraft:snow_block
fill 142 126 313 142 129 313 minecraft:packed_ice
setblock 143 126 306 minecraft:snow_block
fill 143 126 307 143 129 307 minecraft:packed_ice
setblock 143 126 311 minecraft:snow_block
fill 143 126 312 143 129 312 minecraft:packed_ice
setblock 143 126 316 minecraft:snow_block
fill 144 126 277 144 127 277 minecraft:packed_ice
fill 144 126 279 144 127 279 minecraft:packed_ice
setblock 144 126 310 minecraft:snow_block
fill 144 126 311 144 129 311 minecraft:packed_ice
fill 144 126 313 144 127 313 minecraft:packed_ice
setblock 144 126 315 minecraft:snow_block
fill 144 126 316 144 129 316 minecraft:packed_ice
fill 145 126 315 145 129 315 minecraft:packed_ice
fill 146 126 277 146 127 277 minecraft:packed_ice
fill 146 126 279 146 127 279 minecraft:packed_ice
fill 154 126 316 157 126 316 minecraft:packed_ice
setblock 158 126 316 minecraft:snow_block
fill 159 126 316 161 127 316 minecraft:packed_ice
fill 174 126 276 174 129 276 minecraft:packed_ice
fill 175 126 316 175 128 316 minecraft:packed_ice
setblock 176 126 277 minecraft:packed_ice
fill 176 126 315 178 126 315 minecraft:packed_ice
setblock 177 126 277 minecraft:snow_block
setblock 177 126 316 minecraft:packed_ice
setblock 178 126 276 minecraft:snow_block
fill 178 126 277 178 129 277 minecraft:packed_ice
setblock 178 126 316 minecraft:snow_block
fill 179 126 276 179 129 276 minecraft:packed_ice
setblock 179 126 285 minecraft:snow_block
fill 179 126 286 179 127 287 minecraft:packed_ice
setblock 179 126 314 minecraft:packed_ice
setblock 179 126 315 minecraft:snow_block
fill 179 126 316 179 129 316 minecraft:packed_ice
setblock 180 126 284 minecraft:snow_block
fill 180 126 285 180 129 285 minecraft:packed_ice
setblock 180 126 289 minecraft:snow_block
fill 180 126 290 180 129 290 minecraft:packed_ice
setblock 180 126 308 minecraft:packed_ice
setblock 180 126 309 minecraft:snow_block
fill 180 126 310 180 129 310 minecraft:packed_ice
fill 180 126 312 180 126 313 minecraft:packed_ice
setblock 180 126 314 minecraft:snow_block
fill 180 126 315 180 129 315 minecraft:packed_ice
setblock 181 126 278 minecraft:snow_block
fill 181 126 279 181 129 279 minecraft:packed_ice
setblock 181 126 283 minecraft:snow_block
fill 181 126 284 181 129 284 minecraft:packed_ice
setblock 181 126 288 minecraft:snow_block
fill 181 126 289 181 129 289 minecraft:packed_ice
setblock 181 126 292 minecraft:packed_ice
setblock 181 126 308 minecraft:snow_block
fill 181 126 309 181 129 309 minecraft:packed_ice
setblock 181 126 312 minecraft:packed_ice
setblock 181 126 313 minecraft:snow_block
fill 181 126 314 181 129 314 minecraft:packed_ice
setblock 182 126 277 minecraft:snow_block
fill 182 126 278 182 129 278 minecraft:packed_ice
setblock 182 126 282 minecraft:snow_block
fill 182 126 283 182 129 283 minecraft:packed_ice
setblock 182 126 287 minecraft:snow_block
fill 182 126 288 182 129 288 minecraft:packed_ice
setblock 182 126 292 minecraft:snow_block
fill 182 126 293 182 128 294 minecraft:packed_ice
setblock 182 126 303 minecraft:packed_ice
setblock 182 126 307 minecraft:snow_block
fill 182 126 308 182 129 308 minecraft:packed_ice
setblock 182 126 312 minecraft:snow_block
fill 182 126 313 182 129 313 minecraft:packed_ice
fill 141 127 305 141 138 305 minecraft:blue_ice
setblock 142 127 276 minecraft:snow_block
fill 142 127 277 142 128 277 minecraft:packed_ice
setblock 142 127 282 minecraft:packed_ice
setblock 142 127 286 minecraft:snow_block
fill 142 127 287 142 130 287 minecraft:packed_ice
setblock 142 127 290 minecraft:packed_ice
setblock 142 127 291 minecraft:snow_block
fill 142 127 292 142 130 292 minecraft:packed_ice
fill 142 127 294 142 127 295 minecraft:packed_ice
setblock 142 127 301 minecraft:snow_block
fill 142 127 302 142 130 302 minecraft:packed_ice
setblock 142 127 306 minecraft:snow_block
fill 142 127 307 142 130 307 minecraft:packed_ice
setblock 142 127 311 minecraft:snow_block
fill 142 127 312 142 130 312 minecraft:packed_ice
setblock 142 127 316 minecraft:snow_block
setblock 143 127 305 minecraft:snow_block
fill 143 127 306 143 130 306 minecraft:packed_ice
setblock 143 127 310 minecraft:snow_block
fill 143 127 311 143 130 311 minecraft:packed_ice
setblock 143 127 315 minecraft:snow_block
fill 143 127 316 143 130 316 minecraft:packed_ice
setblock 144 127 309 minecraft:snow_block
fill 144 127 310 144 130 310 minecraft:packed_ice
setblock 144 127 314 minecraft:snow_block
fill 144 127 315 144 130 315 minecraft:packed_ice
setblock 147 127 316 minecraft:snow_block
fill 148 127 316 148 130 316 minecraft:packed_ice
fill 150 127 275 152 133 275 minecraft:blue_ice
setblock 151 127 316 minecraft:packed_ice
setblock 152 127 316 minecraft:snow_block
setblock 153 127 275 minecraft:light_blue_concrete
fill 153 127 316 156 127 316 minecraft:packed_ice
fill 154 127 275 158 139 275 minecraft:blue_ice
fill 154 127 315 157 127 315 minecraft:packed_ice
setblock 157 127 316 minecraft:snow_block
setblock 158 127 315 minecraft:snow_block
fill 158 127 316 158 130 316 minecraft:packed_ice
fill 159 127 315 160 129 315 minecraft:packed_ice
setblock 162 127 316 minecraft:snow_block
setblock 172 127 276 minecraft:snow_block
fill 173 127 276 173 130 276 minecraft:packed_ice
fill 173 127 316 174 129 316 minecraft:packed_ice
setblock 175 127 277 minecraft:packed_ice
fill 175 127 315 177 127 315 minecraft:packed_ice
setblock 176 127 277 minecraft:snow_block
setblock 177 127 276 minecraft:snow_block
fill 177 127 277 177 130 277 minecraft:packed_ice
fill 177 127 314 178 127 314 minecraft:packed_ice
setblock 177 127 316 minecraft:snow_block
fill 178 127 276 178 130 276 minecraft:packed_ice
setblock 178 127 315 minecraft:snow_block
fill 178 127 316 178 130 316 minecraft:packed_ice
setblock 179 127 288 minecraft:packed_ice
setblock 179 127 314 minecraft:snow_block
fill 179 127 315 179 130 315 minecraft:packed_ice
setblock 180 127 283 minecraft:snow_block
fill 180 127 284 180 128 284 minecraft:packed_ice
setblock 180 127 288 minecraft:snow_block
fill 180 127 289 180 130 289 minecraft:packed_ice
fill 180 127 291 180 128 291 minecraft:packed_ice
setblock 180 127 308 minecraft:snow_block
fill 180 127 309 180 130 309 minecraft:packed_ice
setblock 180 127 312 minecraft:packed_ice
setblock 180 127 313 minecraft:snow_block
fill 180 127 314 180 130 314 minecraft:packed_ice
setblock 181 127 277 minecraft:snow_block
fill 181 127 278 181 130 278 minecraft:packed_ice
setblock 181 127 282 minecraft:snow_block
fill 181 127 283 181 129 283 minecraft:packed_ice
setblock 181 127 287 minecraft:snow_block
fill 181 127 288 181 130 288 minecraft:packed_ice
setblock 181 127 292 minecraft:snow_block
fill 181 127 293 181 130 293 minecraft:packed_ice
setblock 181 127 307 minecraft:snow_block
fill 181 127 308 181 130 308 minecraft:packed_ice
setblock 181 127 312 minecraft:snow_block
fill 181 127 313 181 130 313 minecraft:packed_ice
setblock 182 127 276 minecraft:snow_block
fill 182 127 277 182 130 277 minecraft:packed_ice
setblock 182 127 281 minecraft:snow_block
fill 182 127 282 182 130 282 minecraft:packed_ice
setblock 182 127 286 minecraft:snow_block
fill 182 127 287 182 130 287 minecraft:packed_ice
setblock 182 127 291 minecraft:snow_block
fill 182 127 292 182 130 292 minecraft:packed_ice
setblock 182 127 306 minecraft:snow_block
fill 182 127 307 182 130 307 minecraft:packed_ice
setblock 182 127 311 minecraft:snow_block
fill 182 127 312 182 130 312 minecraft:packed_ice
setblock 182 127 316 minecraft:snow_block
fill 142 128 276 142 131 276 minecraft:packed_ice
setblock 142 128 285 minecraft:snow_block
fill 142 128 286 142 130 286 minecraft:packed_ice
setblock 142 128 290 minecraft:snow_block
fill 142 128 291 142 131 291 minecraft:packed_ice
setblock 142 128 294 minecraft:packed_ice
setblock 142 128 295 minecraft:snow_block
fill 142 128 296 142 130 297 minecraft:packed_ice
setblock 142 128 300 minecraft:snow_block
fill 142 128 301 142 131 301 minecraft:packed_ice
setblock 142 128 305 minecraft:snow_block
fill 142 128 306 142 131 306 minecraft:packed_ice
setblock 142 128 310 minecraft:snow_block
fill 142 128 311 142 131 311 minecraft:packed_ice
setblock 142 128 315 minecraft:snow_block
fill 142 128 316 142 131 316 minecraft:packed_ice
fill 143 128 305 143 129 305 minecraft:packed_ice
setblock 143 128 309 minecraft:snow_block
fill 143 128 310 143 131 310 minecraft:packed_ice
setblock 143 128 314 minecraft:snow_block
fill 143 128 315 143 131 315 minecraft:packed_ice
setblock 144 128 308 minecraft:snow_block
fill 144 128 309 144 130 309 minecraft:packed_ice
setblock 144 128 313 minecraft:snow_block
fill 144 128 314 144 131 314 minecraft:packed_ice
setblock 145 128 316 minecraft:packed_ice
fill 146 128 294 146 128 295 minecraft:blue_ice
setblock 146 128 315 minecraft:packed_ice
setblock 146 128 316 minecraft:snow_block
fill 147 128 293 147 129 294 minecraft:blue_ice
fill 147 128 296 150 129 296 minecraft:blue_ice
fill 147 128 316 147 131 316 minecraft:packed_ice
fill 148 128 292 149 128 293 minecraft:blue_ice
fill 148 128 297 149 128 297 minecraft:blue_ice
fill 149 128 316 150 128 316 minecraft:packed_ice
fill 150 128 293 150 129 295 minecraft:blue_ice
fill 150 128 317 152 134 317 minecraft:blue_ice
setblock 151 128 316 minecraft:snow_block
setblock 152 128 315 minecraft:snow_block
fill 152 128 316 155 128 316 minecraft:packed_ice
fill 153 128 275 153 155 275 minecraft:blue_ice
fill 153 128 286 153 128 289 minecraft:blue_ice
fill 153 128 315 156 128 315 minecraft:packed_ice
setblock 153 128 317 minecraft:white_concrete
fill 154 128 285 154 128 286 minecraft:blue_ice
fill 154 128 289 154 128 290 minecraft:blue_ice
fill 155 128 285 157 128 285 minecraft:blue_ice
fill 155 128 290 157 128 290 minecraft:blue_ice
fill 155 128 307 155 129 308 minecraft:blue_ice
fill 155 128 314 157 128 314 minecraft:packed_ice
setblock 156 128 276 minecraft:snow_block
fill 156 128 286 158 128 286 minecraft:blue_ice
fill 156 128 306 157 129 306 minecraft:blue_ice
fill 156 128 309 157 129 309 minecraft:blue_ice
setblock 156 128 316 minecraft:snow_block
fill 157 128 276 160 128 276 minecraft:packed_ice
fill 157 128 287 158 129 287 minecraft:blue_ice
fill 157 128 289 157 130 289 minecraft:blue_ice
setblock 157 128 315 minecraft:snow_block
fill 157 128 316 157 131 316 minecraft:packed_ice
fill 158 128 288 158 129 288 minecraft:blue_ice
fill 158 128 303 159 128 304 minecraft:blue_ice
fill 158 128 307 158 129 308 minecraft:blue_ice
setblock 158 128 314 minecraft:snow_block
fill 158 128 315 158 131 315 minecraft:packed_ice
fill 159 128 301 160 128 302 minecraft:blue_ice
fill 159 128 305 160 128 306 minecraft:blue_ice
fill 159 128 316 160 128 316 minecraft:packed_ice
setblock 161 128 276 minecraft:snow_block
fill 161 128 301 162 128 301 minecraft:blue_ice
fill 161 128 306 162 128 306 minecraft:blue_ice
setblock 161 128 316 minecraft:snow_block
fill 162 128 302 163 128 302 minecraft:blue_ice
fill 162 128 305 163 128 305 minecraft:blue_ice
fill 162 128 316 162 131 316 minecraft:packed_ice
fill 163 128 303 163 129 304 minecraft:blue_ice
fill 165 128 296 166 128 299 minecraft:blue_ice
fill 166 128 295 171 128 295 minecraft:blue_ice
fill 166 128 300 171 128 300 minecraft:blue_ice
fill 167 128 294 170 128 294 minecraft:blue_ice
fill 167 128 296 167 130 296 minecraft:blue_ice
fill 167 128 301 171 128 301 minecraft:blue_ice
setblock 171 128 276 minecraft:snow_block
fill 171 128 296 172 128 299 minecraft:blue_ice
setblock 171 128 316 minecraft:snow_block
fill 172 128 276 172 131 276 minecraft:packed_ice
fill 172 128 316 172 131 316 minecraft:packed_ice
fill 173 128 315 176 128 315 minecraft:packed_ice
setblock 174 128 277 minecraft:packed_ice
setblock 175 128 277 minecraft:snow_block
fill 175 128 303 176 128 306 minecraft:blue_ice
fill 175 128 314 177 128 314 minecraft:packed_ice
setblock 176 128 276 minecraft:snow_block
fill 176 128 277 176 131 277 minecraft:packed_ice
fill 176 128 302 181 128 302 minecraft:blue_ice
fill 176 128 307 180 128 307 minecraft:blue_ice
setblock 176 128 316 minecraft:snow_block
fill 177 128 276 177 131 276 minecraft:packed_ice
fill 177 128 278 178 128 278 minecraft:packed_ice
fill 177 128 301 180 128 301 minecraft:blue_ice
fill 177 128 306 177 130 306 minecraft:blue_ice
fill 177 128 308 179 128 308 minecraft:blue_ice
setblock 177 128 315 minecraft:snow_block
fill 177 128 316 177 131 316 minecraft:packed_ice
setblock 178 128 313 minecraft:packed_ice
setblock 178 128 314 minecraft:snow_block
fill 178 128 315 178 131 315 minecraft:packed_ice
setblock 179 128 278 minecraft:snow_block
setblock 179 128 287 minecraft:packed_ice
setblock 179 128 288 minecraft:snow_block
fill 179 128 311 179 128 312 minecraft:packed_ice
setblock 179 128 313 minecraft:snow_block
fill 179 128 314 179 131 314 minecraft:packed_ice
setblock 180 128 277 minecraft:snow_block
setblock 180 128 283 minecraft:packed_ice
setblock 180 128 287 minecraft:snow_block
fill 180 128 288 180 130 288 minecraft:packed_ice
fill 180 128 306 180 130 306 minecraft:blue_ice
fill 180 128 308 180 129 308 minecraft:packed_ice
setblock 180 128 312 minecraft:snow_block
fill 180 128 313 180 131 313 minecraft:packed_ice
setblock 181 128 276 minecraft:snow_block
fill 181 128 277 181 131 277 minecraft:packed_ice
setblock 181 128 281 minecraft:snow_block
fill 181 128 282 181 129 282 minecraft:packed_ice
setblock 181 128 286 minecraft:snow_block
fill 181 128 287 181 130 287 minecraft:packed_ice
setblock 181 128 291 minecraft:snow_block
fill 181 128 292 181 131 292 minecraft:packed_ice
fill 181 128 303 181 129 305 minecraft:blue_ice
setblock 181 128 306 minecraft:snow_block
fill 181 128 307 181 130 307 minecraft:packed_ice
setblock 181 128 311 minecraft:snow_block
fill 181 128 312 181 131 312 minecraft:packed_ice
setblock 181 128 316 minecraft:snow_block
fill 182 128 276 182 131 276 minecraft:packed_ice
setblock 182 128 280 minecraft:snow_block
fill 182 128 281 182 130 281 minecraft:packed_ice
setblock 182 128 285 minecraft:snow_block
fill 182 128 286 182 131 286 minecraft:packed_ice
setblock 182 128 290 minecraft:snow_block
fill 182 128 291 182 131 291 minecraft:packed_ice
setblock 182 128 295 minecraft:snow_block
setblock 182 128 303 minecraft:blue_ice
setblock 182 128 305 minecraft:snow_block
fill 182 128 306 182 131 306 minecraft:packed_ice
setblock 182 128 310 minecraft:snow_block
fill 182 128 311 182 131 311 minecraft:packed_ice
setblock 182 128 315 minecraft:snow_block
fill 182 128 316 182 131 316 minecraft:packed_ice
fill 183 128 279 183 130 279 minecraft:blue_ice
setblock 183 128 280 minecraft:light_blue_concrete
fill 183 128 281 183 178 284 minecraft:blue_ice
setblock 183 128 285 minecraft:light_blue_concrete
fill 183 128 286 183 167 287 minecraft:blue_ice
setblock 183 128 288 minecraft:white_concrete
fill 183 128 289 183 130 290 minecraft:blue_ice
fill 183 128 308 183 180 308 minecraft:blue_ice
setblock 183 128 309 minecraft:white_concrete
fill 183 128 310 183 166 313 minecraft:blue_ice
setblock 141 129 309 minecraft:white_concrete
setblock 142 129 285 minecraft:packed_ice
setblock 142 129 289 minecraft:snow_block
fill 142 129 290 142 131 290 minecraft:packed_ice
setblock 142 129 294 minecraft:snow_block
fill 142 129 295 142 131 295 minecraft:packed_ice
setblock 142 129 298 minecraft:packed_ice
setblock 142 129 299 minecraft:snow_block
fill 142 129 300 142 131 300 minecraft:packed_ice
setblock 142 129 304 minecraft:snow_block
fill 142 129 305 142 131 305 minecraft:packed_ice
setblock 142 129 309 minecraft:snow_block
fill 142 129 310 142 131 310 minecraft:packed_ice
setblock 142 129 314 minecraft:snow_block
fill 142 129 315 142 131 315 minecraft:packed_ice
setblock 143 129 308 minecraft:snow_block
fill 143 129 309 143 131 309 minecraft:packed_ice
setblock 143 129 313 minecraft:snow_block
fill 143 129 314 143 131 314 minecraft:packed_ice
setblock 144 129 308 minecraft:packed_ice
setblock 144 129 312 minecraft:snow_block
fill 144 129 313 144 131 313 minecraft:packed_ice
setblock 145 129 316 minecraft:snow_block
setblock 146 129 315 minecraft:snow_block
fill 146 129 316 146 131 316 minecraft:packed_ice
fill 147 129 315 150 129 315 minecraft:packed_ice
fill 148 129 293 149 130 293 minecraft:blue_ice
setblock 149 129 316 minecraft:packed_ice
setblock 150 129 316 minecraft:snow_block
setblock 151 129 315 minecraft:snow_block
fill 151 129 316 154 129 316 minecraft:packed_ice
fill 152 129 315 155 129 315 minecraft:packed_ice
fill 153 129 287 153 129 288 minecraft:blue_ice
fill 153 129 314 156 129 314 minecraft:packed_ice
fill 153 129 317 153 141 317 minecraft:blue_ice
fill 154 129 286 154 130 286 minecraft:blue_ice
fill 154 129 289 154 130 289 minecraft:blue_ice
setblock 155 129 276 minecraft:snow_block
fill 155 129 285 156 129 285 minecraft:blue_ice
fill 155 129 290 156 129 290 minecraft:blue_ice
setblock 155 129 316 minecraft:snow_block
fill 156 129 276 159 129 276 minecraft:packed_ice
fill 156 129 286 157 129 286 minecraft:blue_ice
setblock 156 129 315 minecraft:snow_block
fill 156 129 316 156 131 316 minecraft:packed_ice
setblock 157 129 314 minecraft:snow_block
fill 157 129 315 157 131 315 minecraft:packed_ice
fill 158 129 314 159 129 314 minecraft:packed_ice
fill 159 129 302 159 129 305 minecraft:blue_ice
setblock 159 129 316 minecraft:packed_ice
setblock 160 129 276 minecraft:snow_block
fill 160 129 302 160 130 302 minecraft:blue_ice
fill 160 129 305 160 130 305 minecraft:blue_ice
setblock 160 129 316 minecraft:snow_block
fill 161 129 276 161 131 276 minecraft:packed_ice
setblock 161 129 301 minecraft:blue_ice
setblock 161 129 306 minecraft:blue_ice
setblock 161 129 315 minecraft:snow_block
fill 161 129 316 161 131 316 minecraft:packed_ice
fill 162 129 302 162 130 302 minecraft:blue_ice
fill 162 129 305 162 130 305 minecraft:blue_ice
fill 163 129 316 163 130 316 minecraft:packed_ice
fill 166 129 296 166 129 299 minecraft:blue_ice
fill 167 129 295 170 129 295 minecraft:blue_ice
fill 167 129 300 171 129 300 minecraft:blue_ice
fill 168 129 301 169 129 301 minecraft:blue_ice
setblock 170 129 276 minecraft:snow_block
setblock 170 129 316 minecraft:snow_block
fill 171 129 276 171 131 276 minecraft:packed_ice
fill 171 129 296 171 129 299 minecraft:blue_ice
fill 171 129 316 171 131 316 minecraft:packed_ice
fill 172 129 277 173 129 277 minecraft:packed_ice
fill 172 129 297 172 129 298 minecraft:blue_ice
fill 172 129 315 175 129 315 minecraft:packed_ice
setblock 174 129 277 minecraft:snow_block
fill 174 129 314 176 129 314 minecraft:packed_ice
setblock 175 129 276 minecraft:snow_block
fill 175 129 277 175 131 278 minecraft:packed_ice
setblock 175 129 316 minecraft:snow_block
fill 176 129 276 176 131 276 minecraft:packed_ice
fill 176 129 278 177 129 278 minecraft:packed_ice
fill 176 129 302 176 129 306 minecraft:blue_ice
fill 176 129 313 177 129 313 minecraft:packed_ice
setblock 176 129 315 minecraft:snow_block
fill 176 129 316 176 131 316 minecraft:packed_ice
fill 177 129 302 180 129 302 minecraft:blue_ice
fill 177 129 307 180 129 307 minecraft:blue_ice
setblock 177 129 314 minecraft:snow_block
fill 177 129 315 177 131 315 minecraft:packed_ice
fill 177 129 317 179 140 317 minecraft:blue_ice
setblock 178 129 278 minecraft:snow_block
fill 178 129 301 179 129 301 minecraft:blue_ice
setblock 178 129 313 minecraft:snow_block
fill 178 129 314 178 131 314 minecraft:packed_ice
setblock 179 129 277 minecraft:snow_block
fill 179 129 278 179 130 278 minecraft:packed_ice
setblock 179 129 311 minecraft:packed_ice
setblock 179 129 312 minecraft:snow_block
fill 179 129 313 179 131 313 minecraft:packed_ice
setblock 180 129 276 minecraft:snow_block
fill 180 129 277 180 131 277 minecraft:packed_ice
setblock 180 129 286 minecraft:snow_block
fill 180 129 287 180 130 287 minecraft:packed_ice
setblock 180 129 291 minecraft:snow_block
setblock 180 129 311 minecraft:snow_block
fill 180 129 312 180 131 312 minecraft:packed_ice
setblock 180 129 316 minecraft:snow_block
setblock 180 129 317 minecraft:light_blue_concrete
fill 181 129 276 181 131 276 minecraft:packed_ice
setblock 181 129 280 minecraft:snow_block
setblock 181 129 281 minecraft:packed_ice
setblock 181 129 285 minecraft:snow_block
fill 181 129 286 181 130 286 minecraft:packed_ice
setblock 181 129 290 minecraft:snow_block
fill 181 129 291 181 131 291 minecraft:packed_ice
setblock 181 129 306 minecraft:packed_ice
setblock 181 129 310 minecraft:snow_block
fill 181 129 311 181 131 311 minecraft:packed_ice
setblock 181 129 315 minecraft:snow_block
fill 181 129 316 181 131 316 minecraft:packed_ice
fill 181 129 317 181 179 317 minecraft:blue_ice
setblock 182 129 275 minecraft:white_concrete
setblock 182 129 279 minecraft:snow_block
fill 182 129 280 182 131 280 minecraft:packed_ice
setblock 182 129 284 minecraft:snow_block
fill 182 129 285 182 131 285 minecraft:packed_ice
setblock 182 129 289 minecraft:snow_block
fill 182 129 290 182 131 290 minecraft:packed_ice
setblock 182 129 293 minecraft:packed_ice
setblock 182 129 294 minecraft:snow_block
fill 182 129 295 182 131 295 minecraft:packed_ice
setblock 182 129 304 minecraft:snow_block
fill 182 129 305 182 130 305 minecraft:packed_ice
setblock 182 129 309 minecraft:snow_block
fill 182 129 310 182 131 310 minecraft:packed_ice
setblock 182 129 314 minecraft:snow_block
fill 182 129 315 182 131 315 minecraft:packed_ice
fill 183 129 280 183 179 280 minecraft:blue_ice
fill 183 129 285 183 158 285 minecraft:blue_ice
fill 183 129 288 183 179 288 minecraft:blue_ice
fill 183 129 309 183 181 309 minecraft:blue_ice
fill 141 130 288 141 158 290 minecraft:blue_ice
setblock 141 130 291 minecraft:light_blue_concrete
fill 141 130 309 141 143 309 minecraft:blue_ice
setblock 142 130 288 minecraft:snow_block
fill 142 130 289 142 131 289 minecraft:packed_ice
setblock 142 130 293 minecraft:snow_block
fill 142 130 294 142 131 294 minecraft:packed_ice
setblock 142 130 298 minecraft:snow_block
fill 142 130 299 142 131 299 minecraft:packed_ice
setblock 142 130 303 minecraft:snow_block
fill 142 130 304 142 131 304 minecraft:packed_ice
setblock 142 130 308 minecraft:snow_block
fill 142 130 309 142 131 309 minecraft:packed_ice
setblock 142 130 313 minecraft:snow_block
fill 142 130 314 142 131 314 minecraft:packed_ice
setblock 143 130 307 minecraft:snow_block
fill 143 130 308 143 131 308 minecraft:packed_ice
setblock 143 130 312 minecraft:snow_block
fill 143 130 313 143 131 313 minecraft:packed_ice
setblock 144 130 278 minecraft:light[level=12]
setblock 144 130 285 minecraft:light[level=12]
setblock 144 130 292 minecraft:light[level=12]
setblock 144 130 299 minecraft:light[level=12]
setblock 144 130 306 minecraft:light[level=12]
setblock 144 130 311 minecraft:snow_block
fill 144 130 312 144 131 312 minecraft:packed_ice
setblock 144 130 316 minecraft:snow_block
setblock 145 130 315 minecraft:snow_block
fill 145 130 316 145 131 316 minecraft:packed_ice
fill 146 130 315 149 130 315 minecraft:packed_ice
setblock 147 130 294 minecraft:blue_ice
fill 148 130 296 149 130 296 minecraft:blue_ice
setblock 149 130 316 minecraft:snow_block
fill 150 130 294 150 130 295 minecraft:blue_ice
setblock 150 130 315 minecraft:snow_block
fill 150 130 316 153 130 316 minecraft:packed_ice
setblock 151 130 278 minecraft:light[level=12]
setblock 151 130 285 minecraft:light[level=12]
setblock 151 130 292 minecraft:light[level=12]
setblock 151 130 299 minecraft:light[level=12]
setblock 151 130 306 minecraft:light[level=12]
setblock 151 130 313 minecraft:light[level=12]
fill 151 130 315 154 130 315 minecraft:packed_ice
fill 152 130 314 155 130 314 minecraft:packed_ice
setblock 153 130 276 minecraft:packed_ice
setblock 154 130 276 minecraft:snow_block
setblock 154 130 316 minecraft:snow_block
fill 155 130 276 158 130 276 minecraft:packed_ice
setblock 155 130 315 minecraft:snow_block
fill 155 130 316 155 131 316 minecraft:packed_ice
setblock 156 130 286 minecraft:blue_ice
setblock 156 130 314 minecraft:snow_block
fill 156 130 315 156 131 315 minecraft:packed_ice
setblock 157 130 287 minecraft:blue_ice
fill 157 130 314 158 131 314 minecraft:packed_ice
setblock 158 130 278 minecraft:light[level=12]
setblock 158 130 285 minecraft:light[level=12]
setblock 158 130 292 minecraft:light[level=12]
setblock 158 130 299 minecraft:light[level=12]
setblock 158 130 306 minecraft:light[level=12]
setblock 158 130 313 minecraft:light[level=12]
setblock 159 130 276 minecraft:snow_block
fill 159 130 303 159 130 304 minecraft:blue_ice
setblock 159 130 315 minecraft:packed_ice
setblock 159 130 316 minecraft:snow_block
fill 160 130 276 160 131 276 minecraft:packed_ice
setblock 160 130 315 minecraft:snow_block
fill 160 130 316 160 131 316 minecraft:packed_ice
setblock 161 130 315 minecraft:packed_ice
fill 162 130 276 162 131 276 minecraft:packed_ice
setblock 165 130 278 minecraft:light[level=12]
setblock 165 130 285 minecraft:light[level=12]
setblock 165 130 292 minecraft:light[level=12]
setblock 165 130 299 minecraft:light[level=12]
setblock 165 130 306 minecraft:light[level=12]
setblock 165 130 313 minecraft:light[level=12]
fill 166 130 297 166 130 298 minecraft:blue_ice
setblock 168 130 276 minecraft:packed_ice
fill 168 130 295 169 130 295 minecraft:blue_ice
fill 168 130 300 170 130 300 minecraft:blue_ice
setblock 169 130 276 minecraft:snow_block
setblock 169 130 316 minecraft:snow_block
fill 170 130 276 170 131 276 minecraft:packed_ice
fill 170 130 291 171 131 292 minecraft:white_concrete
fill 170 130 316 170 131 316 minecraft:packed_ice
fill 171 130 277 172 130 277 minecraft:packed_ice
fill 171 130 297 171 130 299 minecraft:blue_ice
fill 171 130 315 174 130 315 minecraft:packed_ice
setblock 172 130 278 minecraft:light[level=12]
setblock 172 130 285 minecraft:light[level=12]
setblock 172 130 292 minecraft:light[level=12]
setblock 172 130 299 minecraft:light[level=12]
setblock 172 130 306 minecraft:light[level=12]
setblock 172 130 313 minecraft:light[level=12]
setblock 173 130 277 minecraft:snow_block
fill 173 130 314 175 130 314 minecraft:packed_ice
setblock 173 130 316 minecraft:packed_ice
setblock 174 130 276 minecraft:snow_block
fill 174 130 277 174 131 277 minecraft:packed_ice
setblock 174 130 316 minecraft:snow_block
fill 175 130 276 175 131 276 minecraft:packed_ice
setblock 175 130 315 minecraft:snow_block
fill 175 130 316 175 131 316 minecraft:packed_ice
setblock 176 130 278 minecraft:packed_ice
fill 176 130 303 176 130 305 minecraft:blue_ice
setblock 176 130 313 minecraft:packed_ice
setblock 176 130 314 minecraft:snow_block
fill 176 130 315 176 131 315 minecraft:packed_ice
setblock 177 130 278 minecraft:snow_block
fill 177 130 302 179 130 302 minecraft:blue_ice
setblock 177 130 313 minecraft:snow_block
fill 177 130 314 177 131 314 minecraft:packed_ice
setblock 178 130 277 minecraft:snow_block
fill 178 130 278 178 131 278 minecraft:packed_ice
fill 178 130 307 179 130 307 minecraft:blue_ice
fill 178 130 313 178 131 313 minecraft:packed_ice
setblock 179 130 276 minecraft:snow_block
fill 179 130 277 179 131 277 minecraft:packed_ice
setblock 179 130 285 minecraft:light[level=12]
setblock 179 130 292 minecraft:light[level=12]
setblock 179 130 299 minecraft:light[level=12]
setblock 179 130 311 minecraft:snow_block
fill 179 130 312 179 131 312 minecraft:packed_ice
setblock 179 130 316 minecraft:snow_block
fill 180 130 276 180 131 276 minecraft:packed_ice
setblock 180 130 290 minecraft:snow_block
setblock 180 130 291 minecraft:packed_ice
setblock 180 130 310 minecraft:snow_block
fill 180 130 311 180 131 311 minecraft:packed_ice
setblock 180 130 315 minecraft:snow_block
fill 180 130 316 180 131 316 minecraft:packed_ice
fill 180 130 317 180 179 317 minecraft:blue_ice
setblock 181 130 279 minecraft:snow_block
setblock 181 130 284 minecraft:snow_block
setblock 181 130 285 minecraft:packed_ice
setblock 181 130 289 minecraft:snow_block
fill 181 130 290 181 131 290 minecraft:packed_ice
setblock 181 130 294 minecraft:snow_block
fill 181 130 304 181 130 305 minecraft:blue_ice
setblock 181 130 309 minecraft:snow_block
fill 181 130 310 181 131 310 minecraft:packed_ice
setblock 181 130 314 minecraft:snow_block
fill 181 130 315 181 131 315 minecraft:packed_ice
fill 182 130 275 182 179 275 minecraft:blue_ice
setblock 182 130 278 minecraft:snow_block
fill 182 130 279 182 131 279 minecraft:packed_ice
setblock 182 130 283 minecraft:snow_block
fill 182 130 284 182 131 284 minecraft:packed_ice
setblock 182 130 288 minecraft:snow_block
fill 182 130 289 182 131 289 minecraft:packed_ice
setblock 182 130 293 minecraft:snow_block
fill 182 130 294 182 131 294 minecraft:packed_ice
fill 182 130 296 182 131 296 minecraft:packed_ice
setblock 182 130 308 minecraft:snow_block
fill 182 130 309 182 131 309 minecraft:packed_ice
setblock 182 130 313 minecraft:snow_block
fill 182 130 314 182 131 314 minecraft:packed_ice
fill 141 131 291 141 179 291 minecraft:blue_ice
setblock 142 131 288 minecraft:packed_ice
setblock 142 131 292 minecraft:snow_block
setblock 142 131 293 minecraft:packed_ice
setblock 142 131 296 minecraft:packed_ice
setblock 142 131 297 minecraft:snow_block
setblock 142 131 298 minecraft:packed_ice
setblock 142 131 302 minecraft:snow_block
setblock 142 131 303 minecraft:packed_ice
setblock 142 131 307 minecraft:snow_block
setblock 142 131 308 minecraft:packed_ice
setblock 142 131 312 minecraft:snow_block
setblock 142 131 313 minecraft:packed_ice
setblock 143 131 307 minecraft:packed_ice
setblock 143 131 311 minecraft:snow_block
setblock 143 131 312 minecraft:packed_ice
setblock 143 131 316 minecraft:snow_block
setblock 144 131 311 minecraft:packed_ice
setblock 144 131 315 minecraft:snow_block
setblock 144 131 316 minecraft:packed_ice
fill 145 131 315 148 131 315 minecraft:packed_ice
setblock 148 131 316 minecraft:snow_block
setblock 149 131 315 minecraft:snow_block
fill 149 131 316 152 131 316 minecraft:packed_ice
fill 150 131 315 153 131 315 minecraft:packed_ice
fill 151 131 314 154 131 314 minecraft:packed_ice
setblock 152 131 276 minecraft:packed_ice
setblock 153 131 276 minecraft:snow_block
setblock 153 131 316 minecraft:snow_block
fill 154 131 276 157 131 276 minecraft:packed_ice
setblock 154 131 315 minecraft:snow_block
setblock 154 131 316 minecraft:packed_ice
setblock 155 131 314 minecraft:snow_block
setblock 155 131 315 minecraft:packed_ice
setblock 156 131 314 minecraft:packed_ice
setblock 158 131 276 minecraft:snow_block
setblock 158 131 316 minecraft:snow_block
setblock 159 131 276 minecraft:packed_ice
setblock 159 131 315 minecraft:snow_block
setblock 159 131 316 minecraft:packed_ice
setblock 160 131 315 minecraft:packed_ice
setblock 163 131 316 minecraft:snow_block
setblock 167 131 276 minecraft:packed_ice
setblock 168 131 276 minecraft:snow_block
setblock 168 131 316 minecraft:snow_block
setblock 169 131 276 minecraft:packed_ice
setblock 169 131 316 minecraft:packed_ice
fill 170 131 315 173 131 315 minecraft:packed_ice
setblock 171 131 277 minecraft:packed_ice
setblock 172 131 277 minecraft:snow_block
fill 172 131 314 174 131 314 minecraft:packed_ice
setblock 173 131 276 minecraft:snow_block
setblock 173 131 277 minecraft:packed_ice
setblock 173 131 316 minecraft:snow_block
setblock 174 131 276 minecraft:packed_ice
setblock 174 131 278 minecraft:packed_ice
setblock 174 131 315 minecraft:snow_block
setblock 174 131 316 minecraft:packed_ice
setblock 175 131 313 minecraft:packed_ice
setblock 175 131 314 minecraft:snow_block
setblock 175 131 315 minecraft:packed_ice
setblock 176 131 278 minecraft:snow_block
setblock 176 131 313 minecraft:snow_block
setblock 176 131 314 minecraft:packed_ice
setblock 177 131 275 minecraft:white_concrete
setblock 177 131 277 minecraft:snow_block
setblock 177 131 278 minecraft:packed_ice
setblock 177 131 313 minecraft:packed_ice
setblock 178 131 276 minecraft:snow_block
setblock 178 131 277 minecraft:packed_ice
setblock 178 131 316 minecraft:snow_block
setblock 179 131 276 minecraft:packed_ice
setblock 179 131 315 minecraft:snow_block
setblock 179 131 316 minecraft:packed_ice
setblock 180 131 310 minecraft:packed_ice
setblock 180 131 314 minecraft:snow_block
setblock 180 131 315 minecraft:packed_ice
setblock 181 131 278 minecraft:snow_block
setblock 181 131 288 minecraft:snow_block
setblock 181 131 289 minecraft:packed_ice
setblock 181 131 293 minecraft:snow_block
setblock 181 131 308 minecraft:snow_block
setblock 181 131 309 minecraft:packed_ice
setblock 181 131 313 minecraft:snow_block
setblock 181 131 314 minecraft:packed_ice
setblock 182 131 277 minecraft:snow_block
setblock 182 131 278 minecraft:packed_ice
setblock 182 131 287 minecraft:snow_block
setblock 182 131 288 minecraft:packed_ice
setblock 182 131 292 minecraft:snow_block
setblock 182 131 293 minecraft:packed_ice
setblock 182 131 307 minecraft:snow_block
setblock 182 131 308 minecraft:packed_ice
setblock 182 131 312 minecraft:snow_block
setblock 182 131 313 minecraft:packed_ice
setblock 183 131 279 minecraft:light_blue_concrete
fill 183 131 289 183 153 289 minecraft:blue_ice
setblock 183 131 290 minecraft:white_concrete
fill 183 131 299 183 156 299 minecraft:blue_ice
setblock 183 131 300 minecraft:light_blue_concrete
fill 183 131 301 183 137 301 minecraft:blue_ice
fill 141 132 275 141 138 279 minecraft:blue_ice
setblock 141 132 280 minecraft:white_concrete
fill 141 132 281 141 179 281 minecraft:blue_ice
fill 141 132 300 141 179 300 minecraft:blue_ice
setblock 141 132 301 minecraft:light_blue_concrete
fill 141 132 302 141 169 304 minecraft:blue_ice
setblock 144 132 278 minecraft:light[level=15]
setblock 144 132 286 minecraft:light[level=15]
setblock 144 132 294 minecraft:light[level=15]
setblock 144 132 302 minecraft:light[level=15]
setblock 144 132 310 minecraft:light[level=15]
setblock 152 132 278 minecraft:light[level=15]
setblock 152 132 286 minecraft:light[level=15]
setblock 152 132 294 minecraft:light[level=15]
setblock 152 132 302 minecraft:light[level=15]
setblock 152 132 310 minecraft:light[level=15]
setblock 160 132 278 minecraft:light[level=15]
setblock 160 132 286 minecraft:light[level=15]
setblock 160 132 294 minecraft:light[level=15]
setblock 160 132 302 minecraft:light[level=15]
setblock 160 132 310 minecraft:light[level=15]
setblock 168 132 278 minecraft:light[level=15]
setblock 168 132 286 minecraft:light[level=15]
setblock 168 132 294 minecraft:light[level=15]
setblock 168 132 302 minecraft:light[level=15]
setblock 168 132 310 minecraft:light[level=15]
setblock 176 132 278 minecraft:light[level=15]
setblock 176 132 286 minecraft:light[level=15]
setblock 176 132 294 minecraft:light[level=15]
setblock 176 132 302 minecraft:light[level=15]
setblock 176 132 310 minecraft:light[level=15]
fill 177 132 275 177 154 275 minecraft:blue_ice
fill 183 132 279 183 174 279 minecraft:blue_ice
fill 183 132 290 183 179 290 minecraft:blue_ice
fill 183 132 300 183 177 300 minecraft:blue_ice
fill 141 133 280 141 176 280 minecraft:blue_ice
fill 141 133 301 141 177 301 minecraft:blue_ice
fill 168 133 275 170 154 275 minecraft:blue_ice
setblock 171 133 275 minecraft:light_blue_concrete
fill 172 133 275 172 143 275 minecraft:blue_ice
setblock 179 133 275 minecraft:white_concrete
fill 141 134 311 141 179 311 minecraft:blue_ice
setblock 141 134 312 minecraft:light_blue_concrete
setblock 150 134 275 minecraft:light_blue_concrete
fill 151 134 275 152 174 275 minecraft:blue_ice
fill 171 134 275 171 147 275 minecraft:blue_ice
fill 179 134 275 179 175 275 minecraft:blue_ice
fill 141 135 293 141 156 293 minecraft:blue_ice
setblock 141 135 294 minecraft:white_concrete
setblock 141 135 295 minecraft:light_blue_concrete
fill 141 135 312 141 154 312 minecraft:blue_ice
fill 150 135 275 150 179 275 minecraft:blue_ice
setblock 150 135 317 minecraft:white_concrete
fill 151 135 317 152 146 317 minecraft:blue_ice
setblock 173 135 275 minecraft:light_blue_concrete
fill 141 136 282 141 179 282 minecraft:blue_ice
setblock 141 136 283 minecraft:white_concrete
fill 141 136 294 141 179 295 minecraft:blue_ice
setblock 144 136 278 minecraft:light[level=12]
setblock 144 136 285 minecraft:light[level=12]
setblock 144 136 292 minecraft:light[level=12]
setblock 144 136 299 minecraft:light[level=12]
setblock 144 136 306 minecraft:light[level=12]
setblock 144 136 313 minecraft:light[level=12]
fill 150 136 317 150 143 317 minecraft:blue_ice
setblock 151 136 278 minecraft:light[level=12]
setblock 151 136 285 minecraft:light[level=12]
setblock 151 136 292 minecraft:light[level=12]
setblock 151 136 299 minecraft:light[level=12]
setblock 151 136 306 minecraft:light[level=12]
setblock 151 136 313 minecraft:light[level=12]
setblock 158 136 278 minecraft:light[level=12]
setblock 158 136 285 minecraft:light[level=12]
setblock 158 136 292 minecraft:light[level=12]
setblock 158 136 299 minecraft:light[level=12]
setblock 158 136 306 minecraft:light[level=12]
setblock 158 136 313 minecraft:light[level=12]
setblock 165 136 278 minecraft:light[level=12]
setblock 165 136 285 minecraft:light[level=12]
setblock 165 136 292 minecraft:light[level=12]
setblock 165 136 299 minecraft:light[level=12]
setblock 165 136 306 minecraft:light[level=12]
setblock 165 136 313 minecraft:light[level=12]
setblock 172 136 278 minecraft:light[level=12]
setblock 172 136 285 minecraft:light[level=12]
setblock 172 136 292 minecraft:light[level=12]
setblock 172 136 299 minecraft:light[level=12]
setblock 172 136 306 minecraft:light[level=12]
setblock 172 136 313 minecraft:light[level=12]
fill 173 136 275 173 172 275 minecraft:blue_ice
setblock 179 136 278 minecraft:light[level=12]
setblock 179 136 285 minecraft:light[level=12]
setblock 179 136 292 minecraft:light[level=12]
setblock 179 136 299 minecraft:light[level=12]
setblock 179 136 306 minecraft:light[level=12]
setblock 179 136 313 minecraft:light[level=12]
setblock 181 136 286 minecraft:packed_ice
fill 183 136 275 183 175 275 minecraft:blue_ice
setblock 183 136 276 minecraft:light_blue_concrete
fill 183 136 277 183 139 277 minecraft:blue_ice
setblock 183 136 278 minecraft:light_blue_concrete
setblock 141 137 283 minecraft:blue_ice
fill 141 137 306 141 179 306 minecraft:blue_ice
setblock 141 137 307 minecraft:light_blue_concrete
fill 142 137 276 142 138 279 minecraft:light_blue_stained_glass
fill 142 137 280 142 138 280 minecraft:white_stained_glass
fill 142 137 281 142 138 302 minecraft:light_blue_stained_glass
fill 142 137 303 142 138 303 minecraft:white_stained_glass
fill 142 137 304 143 138 310 minecraft:light_blue_stained_glass
fill 142 137 311 142 138 311 minecraft:white_stained_glass
fill 142 137 312 144 138 316 minecraft:light_blue_stained_glass
fill 143 137 276 143 138 277 minecraft:light_blue_stained_glass
fill 143 137 278 143 138 278 minecraft:white_stained_glass
fill 143 137 279 143 138 285 minecraft:light_blue_stained_glass
fill 143 137 286 143 138 286 minecraft:white_stained_glass
fill 143 137 287 143 138 293 minecraft:light_blue_stained_glass
fill 143 137 294 143 138 294 minecraft:white_stained_glass
fill 143 137 295 143 138 303 minecraft:light_blue_stained_glass
fill 143 137 311 150 138 311 minecraft:light_blue_stained_glass
fill 144 137 276 144 138 276 minecraft:white_stained_glass
fill 144 137 277 144 138 283 minecraft:light_blue_stained_glass
fill 144 137 284 144 138 284 minecraft:white_stained_glass
fill 144 137 285 144 138 291 minecraft:light_blue_stained_glass
fill 144 137 292 144 138 292 minecraft:white_stained_glass
fill 144 137 293 144 138 299 minecraft:light_blue_stained_glass
fill 144 137 300 144 138 300 minecraft:white_stained_glass
fill 144 137 301 144 138 307 minecraft:light_blue_stained_glass
fill 144 137 308 144 138 308 minecraft:white_stained_glass
fill 144 137 309 146 138 310 minecraft:light_blue_stained_glass
fill 145 137 276 146 138 281 minecraft:light_blue_stained_glass
fill 145 137 282 145 138 282 minecraft:white_stained_glass
fill 145 137 283 146 138 289 minecraft:light_blue_stained_glass
fill 145 137 290 145 138 290 minecraft:white_stained_glass
fill 145 137 291 145 138 297 minecraft:light_blue_stained_glass
fill 145 137 298 145 138 298 minecraft:white_stained_glass
fill 145 137 299 145 138 305 minecraft:light_blue_stained_glass
fill 145 137 306 145 138 306 minecraft:white_stained_glass
fill 145 137 307 148 138 308 minecraft:light_blue_stained_glass
fill 145 137 312 145 138 313 minecraft:light_blue_stained_glass
fill 145 137 314 145 138 314 minecraft:white_stained_glass
fill 145 137 315 147 138 316 minecraft:light_blue_stained_glass
fill 146 137 282 153 138 282 minecraft:light_blue_stained_glass
fill 146 137 290 147 138 295 minecraft:light_blue_stained_glass
fill 146 137 296 146 138 296 minecraft:white_stained_glass
fill 146 137 297 147 138 303 minecraft:light_blue_stained_glass
fill 146 137 304 146 138 304 minecraft:white_stained_glass
fill 146 137 305 149 138 306 minecraft:light_blue_stained_glass
fill 146 137 312 146 138 312 minecraft:white_stained_glass
fill 146 137 313 149 138 314 minecraft:light_blue_stained_glass
fill 147 137 276 147 138 278 minecraft:light_blue_stained_glass
fill 147 137 279 147 138 279 minecraft:white_stained_glass
fill 147 137 280 150 138 281 minecraft:light_blue_stained_glass
fill 147 137 283 147 138 286 minecraft:light_blue_stained_glass
fill 147 137 287 147 138 287 minecraft:white_stained_glass
fill 147 137 288 149 138 289 minecraft:light_blue_stained_glass
fill 147 137 296 154 138 296 minecraft:light_blue_stained_glass
fill 147 137 304 154 138 304 minecraft:light_blue_stained_glass
fill 147 137 309 151 138 309 minecraft:light_blue_stained_glass
fill 147 137 310 147 138 310 minecraft:white_stained_glass
fill 147 137 312 154 138 312 minecraft:light_blue_stained_glass
fill 148 137 276 152 138 276 minecraft:light_blue_stained_glass
fill 148 137 277 148 138 277 minecraft:white_stained_glass
fill 148 137 278 151 138 279 minecraft:light_blue_stained_glass
fill 148 137 283 148 138 284 minecraft:light_blue_stained_glass
fill 148 137 285 148 138 285 minecraft:white_stained_glass
fill 148 137 286 151 138 287 minecraft:light_blue_stained_glass
fill 148 137 290 148 138 292 minecraft:light_blue_stained_glass
fill 148 137 293 148 138 293 minecraft:white_stained_glass
fill 148 137 294 151 138 295 minecraft:light_blue_stained_glass
fill 148 137 297 148 138 300 minecraft:light_blue_stained_glass
fill 148 137 301 148 138 301 minecraft:white_stained_glass
fill 148 137 302 150 138 303 minecraft:light_blue_stained_glass
fill 148 137 310 155 138 310 minecraft:light_blue_stained_glass
fill 148 137 315 170 138 315 minecraft:light_blue_stained_glass
fill 148 137 316 148 138 316 minecraft:white_stained_glass
fill 149 137 277 156 138 277 minecraft:light_blue_stained_glass
fill 149 137 283 149 138 283 minecraft:white_stained_glass
fill 149 137 284 152 138 285 minecraft:light_blue_stained_glass
fill 149 137 290 153 138 290 minecraft:light_blue_stained_glass
fill 149 137 291 149 138 291 minecraft:white_stained_glass
fill 149 137 292 152 138 293 minecraft:light_blue_stained_glass
fill 149 137 297 149 138 298 minecraft:light_blue_stained_glass
fill 149 137 299 149 138 299 minecraft:white_stained_glass
fill 149 137 300 152 138 301 minecraft:light_blue_stained_glass
fill 149 137 307 149 138 307 minecraft:white_stained_glass
fill 149 137 308 174 138 308 minecraft:light_blue_stained_glass
fill 149 137 316 156 138 316 minecraft:light_blue_stained_glass
fill 150 137 283 157 138 283 minecraft:light_blue_stained_glass
fill 150 137 288 158 137 288 minecraft:light_blue_stained_glass
fill 150 137 289 150 138 289 minecraft:white_stained_glass
fill 150 137 291 157 137 291 minecraft:light_blue_stained_glass
fill 150 137 297 150 138 297 minecraft:white_stained_glass
fill 150 137 298 153 138 299 minecraft:light_blue_stained_glass
fill 150 137 305 150 138 305 minecraft:white_stained_glass
fill 150 137 306 153 138 307 minecraft:light_blue_stained_glass
fill 150 137 313 150 138 313 minecraft:white_stained_glass
fill 150 137 314 153 138 314 minecraft:light_blue_stained_glass
fill 151 137 280 151 138 280 minecraft:white_stained_glass
fill 151 137 281 167 138 281 minecraft:light_blue_stained_glass
fill 151 137 289 158 137 289 minecraft:light_blue_stained_glass
fill 151 137 297 158 138 297 minecraft:light_blue_stained_glass
fill 151 137 302 155 138 302 minecraft:light_blue_stained_glass
fill 151 137 303 151 138 303 minecraft:white_stained_glass
fill 151 137 305 158 138 305 minecraft:light_blue_stained_glass
fill 151 137 311 151 138 311 minecraft:white_stained_glass
fill 151 137 313 158 138 313 minecraft:light_blue_stained_glass
fill 152 137 278 152 138 278 minecraft:white_stained_glass
fill 152 137 279 155 138 280 minecraft:light_blue_stained_glass
fill 152 137 286 152 138 286 minecraft:white_stained_glass
fill 152 137 287 155 138 287 minecraft:light_blue_stained_glass
fill 152 137 294 152 138 294 minecraft:white_stained_glass
fill 152 137 295 159 138 295 minecraft:light_blue_stained_glass
fill 152 137 303 159 138 303 minecraft:light_blue_stained_glass
fill 152 137 309 152 138 309 minecraft:white_stained_glass
fill 152 137 311 159 138 311 minecraft:light_blue_stained_glass
fill 153 137 276 153 138 276 minecraft:white_stained_glass
fill 153 137 278 160 138 278 minecraft:light_blue_stained_glass
fill 153 137 284 153 138 284 minecraft:white_stained_glass
fill 153 137 285 156 138 286 minecraft:light_blue_stained_glass
fill 153 137 292 153 138 292 minecraft:white_stained_glass
fill 153 137 293 156 138 294 minecraft:light_blue_stained_glass
fill 153 137 300 153 138 300 minecraft:white_stained_glass
fill 153 137 301 178 138 301 minecraft:light_blue_stained_glass
fill 153 137 309 160 138 309 minecraft:light_blue_stained_glass
fill 154 137 276 161 138 276 minecraft:light_blue_stained_glass
fill 154 137 282 154 138 282 minecraft:white_stained_glass
fill 154 137 284 161 138 284 minecraft:light_blue_stained_glass
fill 154 137 290 154 138 290 minecraft:white_stained_glass
fill 154 137 292 158 137 292 minecraft:light_blue_stained_glass
fill 154 137 298 154 138 298 minecraft:white_stained_glass
fill 154 137 299 157 138 300 minecraft:light_blue_stained_glass
fill 154 137 306 154 138 306 minecraft:white_stained_glass
fill 154 137 307 157 138 307 minecraft:light_blue_stained_glass
fill 154 137 314 154 138 314 minecraft:white_stained_glass
fill 155 137 282 162 138 282 minecraft:light_blue_stained_glass
fill 155 137 290 157 137 290 minecraft:light_blue_stained_glass
fill 155 137 296 155 138 296 minecraft:white_stained_glass
fill 155 137 298 162 138 298 minecraft:light_blue_stained_glass
fill 155 137 304 155 138 304 minecraft:white_stained_glass
fill 155 137 306 162 138 306 minecraft:light_blue_stained_glass
fill 155 137 312 155 138 312 minecraft:white_stained_glass
fill 155 137 314 162 138 314 minecraft:light_blue_stained_glass
fill 156 137 279 156 138 279 minecraft:white_stained_glass
fill 156 137 280 159 138 280 minecraft:light_blue_stained_glass
fill 156 137 287 156 138 287 minecraft:white_stained_glass
fill 156 137 296 163 138 296 minecraft:light_blue_stained_glass
fill 156 137 302 156 138 302 minecraft:white_stained_glass
fill 156 137 304 163 138 304 minecraft:light_blue_stained_glass
fill 156 137 310 156 138 310 minecraft:white_stained_glass
fill 156 137 312 163 138 312 minecraft:light_blue_stained_glass
fill 157 137 277 157 138 277 minecraft:white_stained_glass
fill 157 137 279 164 138 279 minecraft:light_blue_stained_glass
fill 157 137 285 157 138 285 minecraft:white_stained_glass
fill 157 137 286 160 137 287 minecraft:light_blue_stained_glass
fill 157 137 293 157 138 293 minecraft:white_stained_glass
fill 157 137 294 182 137 294 minecraft:light_blue_stained_glass
fill 157 137 302 164 138 302 minecraft:light_blue_stained_glass
fill 157 137 310 164 138 310 minecraft:light_blue_stained_glass
fill 157 137 316 157 138 316 minecraft:white_stained_glass
fill 158 137 277 165 138 277 minecraft:light_blue_stained_glass
fill 158 137 283 158 138 283 minecraft:white_stained_glass
fill 158 137 285 165 138 285 minecraft:light_blue_stained_glass
setblock 158 137 291 minecraft:white_stained_glass
fill 158 137 293 160 137 293 minecraft:light_blue_stained_glass
fill 158 137 299 158 138 299 minecraft:white_stained_glass
fill 158 137 300 161 138 300 minecraft:light_blue_stained_glass
fill 158 137 307 158 138 307 minecraft:white_stained_glass
fill 158 137 316 165 138 316 minecraft:light_blue_stained_glass
fill 159 137 283 166 138 283 minecraft:light_blue_stained_glass
fill 159 137 297 159 138 297 minecraft:white_stained_glass
fill 159 137 299 166 138 299 minecraft:light_blue_stained_glass
fill 159 137 305 159 138 305 minecraft:white_stained_glass
fill 159 137 307 166 138 307 minecraft:light_blue_stained_glass
fill 159 137 313 159 138 313 minecraft:white_stained_glass
fill 160 137 280 160 138 280 minecraft:white_stained_glass
fill 160 137 295 160 138 295 minecraft:white_stained_glass
fill 160 137 297 167 138 297 minecraft:light_blue_stained_glass
fill 160 137 303 160 138 303 minecraft:white_stained_glass
fill 160 137 305 167 138 305 minecraft:light_blue_stained_glass
fill 160 137 311 160 138 311 minecraft:white_stained_glass
fill 160 137 313 167 138 313 minecraft:light_blue_stained_glass
fill 161 137 278 161 138 278 minecraft:white_stained_glass
fill 161 137 280 182 138 280 minecraft:light_blue_stained_glass
setblock 161 137 286 minecraft:white_stained_glass
fill 161 137 295 168 138 295 minecraft:light_blue_stained_glass
fill 161 137 303 168 138 303 minecraft:light_blue_stained_glass
fill 161 137 309 161 138 309 minecraft:white_stained_glass
fill 161 137 311 168 138 311 minecraft:light_blue_stained_glass
fill 162 137 276 162 138 276 minecraft:white_stained_glass
fill 162 137 278 169 138 278 minecraft:light_blue_stained_glass
fill 162 137 284 162 138 284 minecraft:white_stained_glass
fill 162 137 286 169 137 287 minecraft:light_blue_stained_glass
fill 162 137 293 165 137 293 minecraft:light_blue_stained_glass
fill 162 137 300 162 138 300 minecraft:white_stained_glass
fill 162 137 309 169 138 309 minecraft:light_blue_stained_glass
fill 163 137 276 170 138 276 minecraft:light_blue_stained_glass
fill 163 137 282 163 138 282 minecraft:white_stained_glass
fill 163 137 284 170 138 284 minecraft:light_blue_stained_glass
fill 163 137 298 163 138 298 minecraft:white_stained_glass
fill 163 137 300 170 138 300 minecraft:light_blue_stained_glass
fill 163 137 306 163 138 306 minecraft:white_stained_glass
fill 163 137 314 163 138 314 minecraft:white_stained_glass
fill 164 137 282 171 138 282 minecraft:light_blue_stained_glass
setblock 164 137 288 minecraft:white_stained_glass
fill 164 137 289 167 137 289 minecraft:light_blue_stained_glass
fill 164 137 291 166 137 292 minecraft:light_blue_stained_glass
fill 164 137 296 164 138 296 minecraft:white_stained_glass
fill 164 137 298 171 138 298 minecraft:light_blue_stained_glass
fill 164 137 304 164 138 304 minecraft:white_stained_glass
fill 164 137 306 171 138 306 minecraft:light_blue_stained_glass
fill 164 137 312 164 138 312 minecraft:white_stained_glass
fill 164 137 314 182 138 314 minecraft:light_blue_stained_glass
fill 165 137 279 165 138 279 minecraft:white_stained_glass
fill 165 137 288 172 138 288 minecraft:light_blue_stained_glass
fill 165 137 290 171 137 290 minecraft:light_blue_stained_glass
fill 165 137 296 172 138 296 minecraft:light_blue_stained_glass
fill 165 137 302 165 138 302 minecraft:white_stained_glass
fill 165 137 304 172 138 304 minecraft:light_blue_stained_glass
fill 165 137 310 165 138 310 minecraft:white_stained_glass
fill 165 137 312 172 138 312 minecraft:light_blue_stained_glass
fill 166 137 277 166 138 277 minecraft:white_stained_glass
fill 166 137 279 173 138 279 minecraft:light_blue_stained_glass
fill 166 137 285 166 138 285 minecraft:white_stained_glass
fill 166 137 293 166 138 293 minecraft:white_stained_glass
fill 166 137 302 173 138 302 minecraft:light_blue_stained_glass
fill 166 137 310 173 138 310 minecraft:light_blue_stained_glass
fill 166 137 316 166 138 316 minecraft:white_stained_glass
fill 167 137 277 174 138 277 minecraft:light_blue_stained_glass
fill 167 137 283 167 138 283 minecraft:white_stained_glass
fill 167 137 285 174 138 285 minecraft:light_blue_stained_glass
fill 167 137 291 167 138 291 minecraft:white_stained_glass
fill 167 137 292 170 138 293 minecraft:light_blue_stained_glass
fill 167 137 299 167 138 299 minecraft:white_stained_glass
fill 167 137 307 167 138 307 minecraft:white_stained_glass
fill 167 137 316 174 138 316 minecraft:light_blue_stained_glass
fill 168 137 281 168 138 281 minecraft:white_stained_glass
fill 168 137 283 175 138 283 minecraft:light_blue_stained_glass
fill 168 137 289 168 138 289 minecraft:white_stained_glass
fill 168 137 291 175 138 291 minecraft:light_blue_stained_glass
fill 168 137 297 168 138 297 minecraft:white_stained_glass
fill 168 137 299 175 138 299 minecraft:light_blue_stained_glass
fill 168 137 305 168 138 305 minecraft:white_stained_glass
fill 168 137 307 182 138 307 minecraft:light_blue_stained_glass
fill 168 137 313 168 138 313 minecraft:white_stained_glass
fill 169 137 281 176 138 281 minecraft:light_blue_stained_glass
fill 169 137 289 176 138 289 minecraft:light_blue_stained_glass
fill 169 137 295 169 138 295 minecraft:white_stained_glass
fill 169 137 297 176 138 297 minecraft:light_blue_stained_glass
fill 169 137 303 169 138 303 minecraft:white_stained_glass
fill 169 137 305 176 138 305 minecraft:light_blue_stained_glass
fill 169 137 311 169 138 311 minecraft:white_stained_glass
fill 169 137 313 176 138 313 minecraft:light_blue_stained_glass
fill 170 137 278 170 138 278 minecraft:white_stained_glass
fill 170 137 286 170 138 286 minecraft:white_stained_glass
fill 170 137 287 182 138 287 minecraft:light_blue_stained_glass
fill 170 137 295 177 138 295 minecraft:light_blue_stained_glass
fill 170 137 303 177 138 303 minecraft:light_blue_stained_glass
fill 170 137 309 170 138 309 minecraft:white_stained_glass
fill 170 137 311 177 138 311 minecraft:light_blue_stained_glass
fill 171 137 276 171 138 276 minecraft:white_stained_glass
fill 171 137 278 178 138 278 minecraft:light_blue_stained_glass
fill 171 137 284 171 138 284 minecraft:white_stained_glass
fill 171 137 286 178 138 286 minecraft:light_blue_stained_glass
fill 171 137 292 171 138 292 minecraft:white_stained_glass
fill 171 137 293 174 138 293 minecraft:light_blue_stained_glass
fill 171 137 300 171 138 300 minecraft:white_stained_glass
fill 171 137 309 178 138 309 minecraft:light_blue_stained_glass
fill 171 137 315 171 138 315 minecraft:white_stained_glass
fill 172 137 276 179 138 276 minecraft:light_blue_stained_glass
fill 172 137 282 172 138 282 minecraft:white_stained_glass
fill 172 137 284 179 138 284 minecraft:light_blue_stained_glass
fill 172 137 290 172 138 290 minecraft:white_stained_glass
fill 172 137 292 179 138 292 minecraft:light_blue_stained_glass
fill 172 137 298 172 138 298 minecraft:white_stained_glass
fill 172 137 300 182 138 300 minecraft:light_blue_stained_glass
fill 172 137 306 172 138 306 minecraft:white_stained_glass
fill 172 137 315 179 138 315 minecraft:light_blue_stained_glass
fill 173 137 282 180 138 282 minecraft:light_blue_stained_glass
fill 173 137 288 173 138 288 minecraft:white_stained_glass
fill 173 137 290 180 138 290 minecraft:light_blue_stained_glass
fill 173 137 296 173 138 296 minecraft:white_stained_glass
fill 173 137 298 180 138 298 minecraft:light_blue_stained_glass
fill 173 137 304 173 138 304 minecraft:white_stained_glass
fill 173 137 306 180 138 306 minecraft:light_blue_stained_glass
fill 173 137 312 173 138 312 minecraft:white_stained_glass
fill 174 137 279 174 138 279 minecraft:white_stained_glass
fill 174 137 288 181 138 288 minecraft:light_blue_stained_glass
fill 174 137 296 181 138 296 minecraft:light_blue_stained_glass
fill 174 137 302 174 138 302 minecraft:white_stained_glass
fill 174 137 304 181 138 304 minecraft:light_blue_stained_glass
fill 174 137 310 174 138 310 minecraft:white_stained_glass
fill 174 137 312 181 138 312 minecraft:light_blue_stained_glass
fill 175 137 277 175 138 277 minecraft:white_stained_glass
fill 175 137 279 182 138 279 minecraft:light_blue_stained_glass
fill 175 137 285 175 138 285 minecraft:white_stained_glass
fill 175 137 293 175 138 293 minecraft:white_stained_glass
fill 175 137 302 182 138 302 minecraft:light_blue_stained_glass
fill 175 137 308 175 138 308 minecraft:white_stained_glass
fill 175 137 310 182 138 310 minecraft:light_blue_stained_glass
fill 175 137 316 175 138 316 minecraft:white_stained_glass
fill 176 137 277 182 138 277 minecraft:light_blue_stained_glass
fill 176 137 283 176 138 283 minecraft:white_stained_glass
fill 176 137 285 182 138 285 minecraft:light_blue_stained_glass
fill 176 137 291 176 138 291 minecraft:white_stained_glass
fill 176 137 293 182 138 293 minecraft:light_blue_stained_glass
fill 176 137 299 176 138 299 minecraft:white_stained_glass
fill 176 137 308 182 138 308 minecraft:light_blue_stained_glass
fill 176 137 316 182 138 316 minecraft:light_blue_stained_glass
fill 177 137 281 177 138 281 minecraft:white_stained_glass
fill 177 137 283 182 138 283 minecraft:light_blue_stained_glass
fill 177 137 289 177 138 289 minecraft:white_stained_glass
fill 177 137 291 182 138 291 minecraft:light_blue_stained_glass
fill 177 137 297 177 138 297 minecraft:white_stained_glass
fill 177 137 299 182 138 299 minecraft:light_blue_stained_glass
fill 177 137 305 177 138 305 minecraft:white_stained_glass
fill 177 137 313 177 138 313 minecraft:white_stained_glass
fill 178 137 281 182 138 281 minecraft:light_blue_stained_glass
fill 178 137 289 182 138 289 minecraft:light_blue_stained_glass
fill 178 137 295 178 138 295 minecraft:white_stained_glass
fill 178 137 297 182 138 297 minecraft:light_blue_stained_glass
fill 178 137 303 178 138 303 minecraft:white_stained_glass
fill 178 137 305 182 138 305 minecraft:light_blue_stained_glass
fill 178 137 311 178 138 311 minecraft:white_stained_glass
fill 178 137 313 182 138 313 minecraft:light_blue_stained_glass
fill 179 137 278 179 138 278 minecraft:white_stained_glass
fill 179 137 286 179 138 286 minecraft:white_stained_glass
fill 179 137 295 182 138 295 minecraft:light_blue_stained_glass
fill 179 137 301 179 138 301 minecraft:white_stained_glass
fill 179 137 303 182 138 303 minecraft:light_blue_stained_glass
fill 179 137 309 179 138 309 minecraft:white_stained_glass
fill 179 137 311 182 138 311 minecraft:light_blue_stained_glass
fill 180 137 276 180 138 276 minecraft:white_stained_glass
fill 180 137 278 182 138 278 minecraft:light_blue_stained_glass
fill 180 137 284 180 138 284 minecraft:white_stained_glass
fill 180 137 286 182 138 286 minecraft:light_blue_stained_glass
fill 180 137 292 180 138 292 minecraft:white_stained_glass
fill 180 137 301 182 138 301 minecraft:light_blue_stained_glass
fill 180 137 309 182 138 309 minecraft:light_blue_stained_glass
fill 180 137 315 180 138 315 minecraft:white_stained_glass
fill 181 137 276 182 138 276 minecraft:light_blue_stained_glass
fill 181 137 282 181 138 282 minecraft:white_stained_glass
fill 181 137 284 182 138 284 minecraft:light_blue_stained_glass
fill 181 137 290 181 138 290 minecraft:white_stained_glass
fill 181 137 292 182 138 292 minecraft:light_blue_stained_glass
fill 181 137 298 181 138 298 minecraft:white_stained_glass
fill 181 137 306 181 138 306 minecraft:white_stained_glass
fill 181 137 315 182 138 315 minecraft:light_blue_stained_glass
fill 182 137 282 182 138 282 minecraft:light_blue_stained_glass
fill 182 137 288 182 138 288 minecraft:white_stained_glass
fill 182 137 290 182 138 290 minecraft:light_blue_stained_glass
fill 182 137 296 182 138 296 minecraft:white_stained_glass
fill 182 137 298 182 138 298 minecraft:light_blue_stained_glass
fill 182 137 304 182 138 304 minecraft:white_stained_glass
fill 182 137 306 182 138 306 minecraft:light_blue_stained_glass
fill 182 137 312 182 138 312 minecraft:white_stained_glass
fill 183 137 276 183 175 276 minecraft:blue_ice
fill 183 137 278 183 154 278 minecraft:blue_ice
setblock 141 138 283 minecraft:light_blue_concrete
fill 141 138 307 141 179 307 minecraft:blue_ice
setblock 146 138 275 minecraft:light_blue_concrete
fill 150 138 288 157 138 288 minecraft:light_blue_stained_glass
fill 150 138 291 156 138 291 minecraft:light_blue_stained_glass
fill 151 138 289 156 138 289 minecraft:light_blue_stained_glass
fill 154 138 292 157 138 292 minecraft:light_blue_stained_glass
fill 155 138 290 156 138 290 minecraft:light_blue_stained_glass
fill 157 138 286 157 138 287 minecraft:light_blue_stained_glass
fill 157 138 289 157 138 291 minecraft:white_concrete
fill 157 138 294 159 138 294 minecraft:light_blue_stained_glass
fill 158 138 286 159 138 286 minecraft:light_blue_stained_glass
fill 158 138 287 158 138 289 minecraft:white_concrete
fill 158 138 291 158 138 293 minecraft:white_concrete
fill 159 138 287 160 138 287 minecraft:white_concrete
fill 159 138 293 160 138 293 minecraft:white_concrete
fill 160 138 286 162 138 286 minecraft:white_concrete
fill 160 138 294 162 138 294 minecraft:white_concrete
fill 162 138 287 164 138 287 minecraft:white_concrete
fill 162 138 293 164 138 293 minecraft:white_concrete
fill 163 138 286 169 138 286 minecraft:light_blue_stained_glass
fill 163 138 294 182 138 294 minecraft:light_blue_stained_glass
fill 164 138 288 164 138 289 minecraft:white_concrete
fill 164 138 291 164 138 292 minecraft:white_concrete
fill 165 138 287 169 138 287 minecraft:light_blue_stained_glass
fill 165 138 289 165 138 291 minecraft:white_concrete
fill 165 138 292 165 138 293 minecraft:light_blue_stained_glass
fill 166 138 289 166 138 292 minecraft:light_blue_stained_glass
fill 167 138 289 167 138 290 minecraft:light_blue_stained_glass
fill 168 138 290 171 138 290 minecraft:light_blue_stained_glass
fill 171 138 317 171 179 317 minecraft:blue_ice
setblock 172 138 317 minecraft:white_concrete
fill 173 138 317 173 179 317 minecraft:blue_ice
setblock 183 138 301 minecraft:light_blue_concrete
fill 141 139 275 141 176 277 minecraft:blue_ice
setblock 141 139 278 minecraft:light_blue_concrete
fill 141 139 279 141 175 279 minecraft:blue_ice
fill 141 139 283 141 177 283 minecraft:blue_ice
setblock 141 139 305 minecraft:white_concrete
fill 146 139 275 146 154 275 minecraft:blue_ice
setblock 147 139 317 minecraft:light_blue_concrete
fill 148 139 317 149 179 317 minecraft:blue_ice
fill 172 139 317 172 179 317 minecraft:blue_ice
fill 181 139 286 181 142 286 minecraft:packed_ice
fill 183 139 301 183 168 301 minecraft:blue_ice
fill 141 140 278 141 179 278 minecraft:blue_ice
fill 141 140 305 141 175 305 minecraft:blue_ice
setblock 144 140 278 minecraft:light[level=15]
setblock 144 140 286 minecraft:light[level=15]
setblock 144 140 294 minecraft:light[level=15]
setblock 144 140 302 minecraft:light[level=15]
setblock 144 140 310 minecraft:light[level=15]
fill 147 140 317 147 176 317 minecraft:blue_ice
setblock 152 140 278 minecraft:light[level=15]
setblock 152 140 286 minecraft:light[level=15]
setblock 152 140 294 minecraft:light[level=15]
setblock 152 140 302 minecraft:light[level=15]
setblock 152 140 310 minecraft:light[level=15]
fill 154 140 275 155 156 275 minecraft:blue_ice
setblock 156 140 275 minecraft:light_blue_concrete
fill 157 140 275 158 163 275 minecraft:blue_ice
setblock 160 140 278 minecraft:light[level=15]
setblock 160 140 286 minecraft:light[level=15]
setblock 160 140 294 minecraft:light[level=15]
setblock 160 140 302 minecraft:light[level=15]
setblock 160 140 310 minecraft:light[level=15]
setblock 168 140 278 minecraft:light[level=15]
setblock 168 140 286 minecraft:light[level=15]
setblock 168 140 294 minecraft:light[level=15]
setblock 168 140 302 minecraft:light[level=15]
setblock 168 140 310 minecraft:light[level=15]
setblock 176 140 278 minecraft:light[level=15]
setblock 176 140 286 minecraft:light[level=15]
setblock 176 140 294 minecraft:light[level=15]
setblock 176 140 302 minecraft:light[level=15]
setblock 176 140 310 minecraft:light[level=15]
fill 177 140 289 177 146 289 minecraft:packed_ice
setblock 183 140 277 minecraft:white_concrete
fill 156 141 275 156 164 275 minecraft:blue_ice
setblock 177 141 317 minecraft:light_blue_concrete
fill 178 141 317 179 153 317 minecraft:blue_ice
fill 180 141 286 180 142 286 minecraft:packed_ice
fill 181 141 285 181 142 285 minecraft:packed_ice
fill 181 141 287 181 142 287 minecraft:packed_ice
fill 182 141 286 182 142 286 minecraft:packed_ice
fill 183 141 277 183 160 277 minecraft:blue_ice
fill 142 142 277 142 144 278 minecraft:packed_ice
fill 142 142 293 142 142 295 minecraft:packed_ice
setblock 142 142 296 minecraft:snow_block
fill 142 142 297 142 142 300 minecraft:packed_ice
setblock 142 142 301 minecraft:snow_block
fill 142 142 302 142 142 305 minecraft:packed_ice
setblock 142 142 306 minecraft:snow_block
fill 142 142 307 142 144 308 minecraft:packed_ice
setblock 142 142 316 minecraft:snow_block
fill 143 142 276 146 142 276 minecraft:packed_ice
setblock 143 142 295 minecraft:snow_block
fill 143 142 296 143 142 299 minecraft:packed_ice
setblock 143 142 300 minecraft:snow_block
fill 143 142 301 143 142 304 minecraft:packed_ice
setblock 143 142 305 minecraft:snow_block
fill 143 142 316 146 142 316 minecraft:packed_ice
setblock 144 142 278 minecraft:light[level=12]
setblock 144 142 285 minecraft:light[level=12]
setblock 144 142 292 minecraft:light[level=12]
fill 144 142 296 144 142 298 minecraft:packed_ice
setblock 144 142 299 minecraft:snow_block
fill 144 142 300 144 142 303 minecraft:packed_ice
setblock 144 142 306 minecraft:light[level=12]
setblock 144 142 313 minecraft:light[level=12]
fill 145 142 280 145 147 280 minecraft:snow_block
setblock 145 142 298 minecraft:snow_block
fill 145 142 299 145 143 301 minecraft:packed_ice
setblock 146 142 277 minecraft:snow_block
fill 146 142 291 147 149 293 minecraft:packed_ice
setblock 147 142 276 minecraft:snow_block
fill 147 142 277 150 142 277 minecraft:packed_ice
setblock 147 142 316 minecraft:snow_block
fill 148 142 276 151 142 276 minecraft:packed_ice
fill 148 142 278 149 142 278 minecraft:packed_ice
fill 148 142 316 151 142 316 minecraft:packed_ice
setblock 150 142 278 minecraft:snow_block
setblock 151 142 277 minecraft:snow_block
fill 151 142 278 154 142 278 minecraft:packed_ice
setblock 151 142 285 minecraft:light[level=12]
setblock 151 142 292 minecraft:light[level=12]
setblock 151 142 299 minecraft:light[level=12]
setblock 151 142 306 minecraft:light[level=12]
setblock 151 142 313 minecraft:light[level=12]
setblock 152 142 276 minecraft:snow_block
fill 152 142 277 155 142 277 minecraft:packed_ice
setblock 152 142 316 minecraft:snow_block
fill 153 142 276 156 142 276 minecraft:packed_ice
fill 153 142 316 154 143 316 minecraft:packed_ice
setblock 153 142 317 minecraft:white_concrete
setblock 155 142 278 minecraft:snow_block
setblock 156 142 277 minecraft:snow_block
setblock 157 142 276 minecraft:snow_block
fill 157 142 277 160 142 277 minecraft:packed_ice
fill 158 142 276 161 142 276 minecraft:packed_ice
setblock 158 142 278 minecraft:light[level=12]
setblock 158 142 285 minecraft:light[level=12]
setblock 158 142 292 minecraft:light[level=12]
setblock 158 142 299 minecraft:light[level=12]
setblock 158 142 306 minecraft:light[level=12]
setblock 158 142 313 minecraft:light[level=12]
setblock 161 142 277 minecraft:snow_block
setblock 162 142 276 minecraft:snow_block
fill 162 142 277 165 142 277 minecraft:packed_ice
fill 163 142 276 166 142 276 minecraft:packed_ice
fill 163 142 278 164 142 278 minecraft:packed_ice
fill 163 142 316 166 142 316 minecraft:packed_ice
setblock 165 142 278 minecraft:snow_block
setblock 165 142 285 minecraft:light[level=12]
setblock 165 142 292 minecraft:light[level=12]
setblock 165 142 299 minecraft:light[level=12]
setblock 165 142 306 minecraft:light[level=12]
setblock 165 142 313 minecraft:light[level=12]
setblock 166 142 277 minecraft:snow_block
fill 166 142 278 168 142 279 minecraft:packed_ice
fill 166 142 315 167 142 315 minecraft:packed_ice
setblock 167 142 276 minecraft:snow_block
fill 167 142 277 170 142 277 minecraft:packed_ice
setblock 167 142 316 minecraft:snow_block
fill 168 142 276 171 142 276 minecraft:packed_ice
setblock 168 142 315 minecraft:snow_block
fill 168 142 316 171 142 316 minecraft:packed_ice
setblock 169 142 278 minecraft:packed_ice
setblock 169 142 279 minecraft:snow_block
fill 169 142 315 172 142 315 minecraft:packed_ice
setblock 170 142 278 minecraft:snow_block
fill 170 142 279 173 142 279 minecraft:packed_ice
setblock 171 142 277 minecraft:snow_block
fill 171 142 278 174 142 278 minecraft:packed_ice
fill 171 142 314 172 142 314 minecraft:packed_ice
setblock 172 142 276 minecraft:snow_block
fill 172 142 277 175 142 277 minecraft:packed_ice
setblock 172 142 285 minecraft:light[level=12]
setblock 172 142 292 minecraft:light[level=12]
setblock 172 142 299 minecraft:light[level=12]
setblock 172 142 306 minecraft:light[level=12]
setblock 172 142 313 minecraft:light[level=12]
setblock 172 142 316 minecraft:snow_block
fill 173 142 276 176 142 276 minecraft:packed_ice
setblock 173 142 315 minecraft:snow_block
fill 173 142 316 176 142 316 minecraft:packed_ice
fill 174 142 315 177 142 315 minecraft:packed_ice
setblock 175 142 278 minecraft:snow_block
setblock 176 142 277 minecraft:snow_block
fill 176 142 278 176 143 278 minecraft:packed_ice
setblock 177 142 276 minecraft:snow_block
fill 177 142 277 179 143 277 minecraft:packed_ice
setblock 177 142 316 minecraft:snow_block
fill 177 142 317 177 176 317 minecraft:blue_ice
fill 178 142 276 181 142 276 minecraft:packed_ice
setblock 178 142 315 minecraft:snow_block
fill 178 142 316 181 142 316 minecraft:packed_ice
fill 179 142 278 182 142 280 minecraft:packed_ice
setblock 179 142 285 minecraft:light[level=12]
setblock 179 142 292 minecraft:light[level=12]
setblock 179 142 299 minecraft:light[level=12]
setblock 179 142 306 minecraft:light[level=12]
setblock 179 142 313 minecraft:light[level=12]
setblock 182 142 276 minecraft:snow_block
fill 182 142 277 182 145 277 minecraft:packed_ice
setblock 182 142 296 minecraft:snow_block
fill 182 142 297 182 142 300 minecraft:packed_ice
setblock 182 142 301 minecraft:snow_block
fill 182 142 302 182 142 305 minecraft:packed_ice
setblock 182 142 306 minecraft:snow_block
fill 182 142 307 182 144 308 minecraft:packed_ice
fill 182 142 312 182 142 315 minecraft:packed_ice
setblock 182 142 316 minecraft:snow_block
fill 142 143 276 145 143 276 minecraft:packed_ice
setblock 142 143 279 minecraft:packed_ice
setblock 142 143 280 minecraft:snow_block
fill 142 143 281 142 146 281 minecraft:packed_ice
fill 142 143 293 142 143 294 minecraft:packed_ice
setblock 142 143 295 minecraft:snow_block
fill 142 143 296 142 143 299 minecraft:packed_ice
setblock 142 143 300 minecraft:snow_block
fill 142 143 301 142 143 304 minecraft:packed_ice
setblock 142 143 305 minecraft:snow_block
fill 142 143 306 143 145 306 minecraft:packed_ice
setblock 142 143 309 minecraft:packed_ice
setblock 143 143 294 minecraft:snow_block
fill 143 143 295 143 143 298 minecraft:packed_ice
setblock 143 143 299 minecraft:snow_block
fill 143 143 300 143 143 303 minecraft:packed_ice
setblock 143 143 304 minecraft:snow_block
fill 143 143 305 143 146 305 minecraft:packed_ice
fill 143 143 316 145 143 316 minecraft:packed_ice
fill 144 143 296 144 143 297 minecraft:packed_ice
setblock 144 143 298 minecraft:snow_block
fill 144 143 299 144 143 302 minecraft:packed_ice
setblock 144 143 303 minecraft:snow_block
fill 144 143 304 144 146 304 minecraft:packed_ice
setblock 145 143 277 minecraft:snow_block
fill 145 143 291 145 149 292 minecraft:packed_ice
setblock 145 143 297 minecraft:snow_block
fill 145 143 298 145 146 298 minecraft:packed_ice
setblock 145 143 302 minecraft:snow_block
setblock 146 143 276 minecraft:snow_block
fill 146 143 277 149 143 277 minecraft:packed_ice
setblock 146 143 316 minecraft:snow_block
fill 147 143 276 150 143 276 minecraft:packed_ice
fill 147 143 278 148 143 278 minecraft:packed_ice
fill 147 143 316 150 143 316 minecraft:packed_ice
fill 148 143 291 148 149 292 minecraft:packed_ice
setblock 149 143 278 minecraft:snow_block
setblock 150 143 277 minecraft:snow_block
fill 150 143 278 153 143 278 minecraft:packed_ice
setblock 151 143 276 minecraft:snow_block
fill 151 143 277 154 143 277 minecraft:packed_ice
setblock 151 143 316 minecraft:snow_block
fill 152 143 276 155 143 276 minecraft:packed_ice
fill 152 143 316 152 144 316 minecraft:packed_ice
fill 153 143 317 153 175 317 minecraft:blue_ice
setblock 154 143 278 minecraft:snow_block
setblock 155 143 277 minecraft:snow_block
fill 155 143 278 155 144 278 minecraft:packed_ice
setblock 156 143 276 minecraft:snow_block
fill 156 143 277 159 143 277 minecraft:packed_ice
fill 157 143 276 160 143 276 minecraft:packed_ice
setblock 160 143 277 minecraft:snow_block
fill 161 143 275 164 150 275 minecraft:blue_ice
setblock 161 143 276 minecraft:snow_block
fill 161 143 277 163 143 278 minecraft:packed_ice
setblock 161 143 317 minecraft:light_blue_concrete
fill 162 143 276 165 143 276 minecraft:packed_ice
fill 163 143 316 165 143 316 minecraft:packed_ice
setblock 164 143 277 minecraft:packed_ice
setblock 164 143 278 minecraft:snow_block
fill 164 143 279 167 143 279 minecraft:packed_ice
setblock 165 143 275 minecraft:light_blue_concrete
setblock 165 143 277 minecraft:snow_block
fill 165 143 278 168 143 278 minecraft:packed_ice
fill 166 143 275 166 152 275 minecraft:blue_ice
setblock 166 143 276 minecraft:snow_block
fill 166 143 277 169 143 277 minecraft:packed_ice
setblock 166 143 315 minecraft:packed_ice
setblock 166 143 316 minecraft:snow_block
fill 167 143 276 170 143 276 minecraft:packed_ice
setblock 167 143 315 minecraft:snow_block
fill 167 143 316 170 143 316 minecraft:packed_ice
setblock 168 143 279 minecraft:snow_block
fill 168 143 315 171 143 315 minecraft:packed_ice
setblock 169 143 278 minecraft:snow_block
fill 169 143 279 169 145 280 minecraft:packed_ice
setblock 170 143 277 minecraft:snow_block
fill 170 143 278 172 143 279 minecraft:packed_ice
setblock 171 143 276 minecraft:snow_block
fill 171 143 277 174 143 277 minecraft:packed_ice
setblock 171 143 314 minecraft:packed_ice
setblock 171 143 316 minecraft:snow_block
fill 172 143 276 175 143 276 minecraft:packed_ice
setblock 172 143 315 minecraft:snow_block
fill 172 143 316 175 143 316 minecraft:packed_ice
setblock 173 143 278 minecraft:packed_ice
setblock 173 143 279 minecraft:snow_block
fill 173 143 315 176 143 315 minecraft:packed_ice
setblock 174 143 278 minecraft:snow_block
setblock 175 143 277 minecraft:snow_block
fill 175 143 278 175 144 278 minecraft:packed_ice
setblock 176 143 276 minecraft:snow_block
fill 176 143 277 176 145 277 minecraft:packed_ice
setblock 176 143 316 minecraft:snow_block
fill 177 143 276 180 143 276 minecraft:packed_ice
setblock 177 143 315 minecraft:snow_block
fill 177 143 316 180 143 316 minecraft:packed_ice
fill 179 143 278 181 144 280 minecraft:packed_ice
setblock 181 143 276 minecraft:snow_block
fill 181 143 299 181 143 300 minecraft:packed_ice
setblock 181 143 301 minecraft:snow_block
fill 181 143 302 182 143 304 minecraft:packed_ice
setblock 181 143 316 minecraft:snow_block
fill 182 143 276 182 146 276 minecraft:packed_ice
fill 182 143 278 182 143 279 minecraft:packed_ice
setblock 182 143 280 minecraft:snow_block
fill 182 143 281 182 146 281 minecraft:packed_ice
fill 182 143 296 182 143 299 minecraft:packed_ice
setblock 182 143 300 minecraft:snow_block
fill 182 143 301 182 146 301 minecraft:packed_ice
setblock 182 143 305 minecraft:snow_block
fill 182 143 306 182 146 306 minecraft:packed_ice
setblock 182 143 309 minecraft:packed_ice
setblock 182 143 310 minecraft:snow_block
fill 182 143 311 182 143 314 minecraft:packed_ice
setblock 182 143 315 minecraft:snow_block
fill 182 143 316 182 146 316 minecraft:packed_ice
setblock 141 144 309 minecraft:light_blue_concrete
fill 142 144 276 144 144 276 minecraft:packed_ice
setblock 142 144 279 minecraft:snow_block
fill 142 144 280 142 147 280 minecraft:packed_ice
fill 142 144 282 142 144 283 minecraft:packed_ice
setblock 142 144 284 minecraft:snow_block
fill 142 144 292 142 144 293 minecraft:packed_ice
setblock 142 144 294 minecraft:snow_block
fill 142 144 295 142 144 298 minecraft:packed_ice
setblock 142 144 299 minecraft:snow_block
fill 142 144 300 142 144 303 minecraft:packed_ice
setblock 142 144 304 minecraft:snow_block
fill 142 144 305 142 147 305 minecraft:packed_ice
setblock 142 144 309 minecraft:snow_block
fill 142 144 310 142 147 310 minecraft:packed_ice
fill 143 144 294 143 144 297 minecraft:packed_ice
setblock 143 144 298 minecraft:snow_block
fill 143 144 299 143 144 302 minecraft:packed_ice
setblock 143 144 303 minecraft:snow_block
fill 143 144 304 143 147 304 minecraft:packed_ice
setblock 143 144 307 minecraft:packed_ice
fill 143 144 316 144 144 316 minecraft:packed_ice
setblock 144 144 277 minecraft:snow_block
fill 144 144 295 144 144 296 minecraft:packed_ice
setblock 144 144 297 minecraft:snow_block
fill 144 144 298 144 144 301 minecraft:packed_ice
setblock 144 144 302 minecraft:snow_block
fill 144 144 303 145 146 303 minecraft:packed_ice
fill 144 144 305 144 144 306 minecraft:packed_ice
setblock 145 144 276 minecraft:snow_block
fill 145 144 277 148 144 277 minecraft:packed_ice
fill 145 144 293 145 149 293 minecraft:packed_ice
fill 145 144 297 145 145 297 minecraft:packed_ice
fill 145 144 299 145 144 300 minecraft:packed_ice
setblock 145 144 301 minecraft:snow_block
fill 145 144 302 145 147 302 minecraft:packed_ice
fill 145 144 304 145 145 304 minecraft:packed_ice
setblock 145 144 316 minecraft:snow_block
fill 146 144 276 149 144 276 minecraft:packed_ice
setblock 146 144 278 minecraft:snow_block
fill 146 144 290 147 149 290 minecraft:packed_ice
fill 146 144 294 147 149 294 minecraft:packed_ice
fill 146 144 316 149 144 316 minecraft:packed_ice
setblock 147 144 278 minecraft:packed_ice
setblock 148 144 278 minecraft:snow_block
fill 148 144 293 148 149 293 minecraft:packed_ice
setblock 149 144 277 minecraft:snow_block
fill 149 144 278 152 144 278 minecraft:packed_ice
setblock 150 144 276 minecraft:snow_block
fill 150 144 277 153 144 277 minecraft:packed_ice
setblock 150 144 316 minecraft:snow_block
setblock 150 144 317 minecraft:white_concrete
fill 151 144 276 154 144 276 minecraft:packed_ice
fill 151 144 316 151 145 316 minecraft:packed_ice
setblock 153 144 278 minecraft:snow_block
setblock 153 144 316 minecraft:packed_ice
setblock 154 144 277 minecraft:snow_block
fill 154 144 278 154 145 278 minecraft:packed_ice
setblock 155 144 276 minecraft:snow_block
fill 155 144 277 158 144 277 minecraft:packed_ice
fill 156 144 276 159 144 276 minecraft:packed_ice
setblock 159 144 277 minecraft:snow_block
setblock 160 144 276 minecraft:snow_block
fill 160 144 277 163 144 277 minecraft:packed_ice
fill 161 144 276 164 144 276 minecraft:packed_ice
fill 161 144 278 162 144 278 minecraft:packed_ice
fill 161 144 317 161 179 317 minecraft:blue_ice
setblock 163 144 278 minecraft:snow_block
fill 163 144 316 164 144 316 minecraft:packed_ice
setblock 164 144 277 minecraft:snow_block
fill 164 144 278 166 144 279 minecraft:packed_ice
setblock 165 144 275 minecraft:white_concrete
setblock 165 144 276 minecraft:snow_block
fill 165 144 277 168 144 277 minecraft:packed_ice
setblock 165 144 316 minecraft:snow_block
fill 166 144 276 169 144 276 minecraft:packed_ice
setblock 166 144 315 minecraft:snow_block
fill 166 144 316 169 144 316 minecraft:packed_ice
setblock 167 144 278 minecraft:packed_ice
setblock 167 144 279 minecraft:snow_block
fill 167 144 280 168 145 280 minecraft:packed_ice
fill 167 144 315 170 144 315 minecraft:packed_ice
setblock 168 144 278 minecraft:snow_block
fill 168 144 279 168 147 279 minecraft:packed_ice
setblock 169 144 277 minecraft:snow_block
fill 169 144 278 172 144 278 minecraft:packed_ice
setblock 170 144 276 minecraft:snow_block
fill 170 144 277 173 144 277 minecraft:packed_ice
fill 170 144 279 171 144 279 minecraft:packed_ice
setblock 170 144 316 minecraft:snow_block
fill 171 144 276 174 144 276 minecraft:packed_ice
setblock 171 144 315 minecraft:snow_block
fill 171 144 316 174 144 316 minecraft:packed_ice
setblock 172 144 275 minecraft:light_blue_concrete
setblock 172 144 279 minecraft:snow_block
fill 172 144 315 175 144 315 minecraft:packed_ice
setblock 173 144 278 minecraft:snow_block
setblock 173 144 279 minecraft:packed_ice
setblock 174 144 277 minecraft:snow_block
fill 174 144 278 174 145 278 minecraft:packed_ice
schedule function dropper:buildpart/63_4 1t
