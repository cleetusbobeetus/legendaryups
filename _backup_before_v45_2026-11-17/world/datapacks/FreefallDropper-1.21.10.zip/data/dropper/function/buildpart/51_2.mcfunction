setblock 172 282 252 minecraft:light[level=15]
setblock 172 282 259 minecraft:light[level=15]
setblock 172 282 266 minecraft:light[level=15]
setblock 179 282 231 minecraft:light[level=15]
setblock 179 282 238 minecraft:light[level=15]
setblock 179 282 245 minecraft:light[level=15]
setblock 179 282 252 minecraft:light[level=15]
setblock 179 282 259 minecraft:light[level=15]
setblock 179 282 266 minecraft:light[level=15]
setblock 156 283 247 minecraft:black_concrete
setblock 156 283 250 minecraft:black_concrete
setblock 156 283 252 minecraft:black_concrete
fill 159 283 243 161 283 243 minecraft:black_concrete
fill 159 283 255 161 283 255 minecraft:black_concrete
fill 160 283 246 160 284 248 minecraft:glass
fill 161 283 245 161 284 246 minecraft:glass
fill 161 283 248 161 284 249 minecraft:glass
fill 162 283 244 162 284 245 minecraft:glass
fill 162 283 249 162 284 250 minecraft:glass
fill 163 283 243 165 283 243 minecraft:black_concrete
fill 163 283 244 164 284 244 minecraft:glass
fill 163 283 250 164 284 250 minecraft:glass
fill 163 283 255 165 283 255 minecraft:black_concrete
fill 164 283 245 165 284 245 minecraft:glass
fill 164 283 249 165 284 249 minecraft:glass
fill 165 283 246 166 284 246 minecraft:glass
fill 165 283 248 166 284 248 minecraft:glass
fill 166 283 247 166 284 247 minecraft:glass
setblock 168 283 246 minecraft:black_concrete
setblock 168 283 248 minecraft:black_concrete
fill 168 283 251 168 283 252 minecraft:black_concrete
fill 156 284 244 156 284 254 minecraft:orange_concrete
fill 157 284 243 167 284 243 minecraft:orange_concrete
fill 157 284 255 167 284 255 minecraft:orange_concrete
fill 168 284 244 168 284 254 minecraft:orange_concrete
fill 142 285 229 143 285 269 minecraft:gray_concrete
fill 144 285 229 182 285 230 minecraft:gray_concrete
setblock 144 285 231 minecraft:light_gray_concrete
fill 144 285 232 144 285 233 minecraft:glass
setblock 144 285 234 minecraft:light_gray_concrete
fill 144 285 235 147 285 239 minecraft:glass
setblock 144 285 240 minecraft:light_gray_concrete
fill 144 285 241 144 285 242 minecraft:glass
setblock 144 285 243 minecraft:light_gray_concrete
fill 144 285 244 147 285 248 minecraft:glass
setblock 144 285 249 minecraft:light_gray_concrete
fill 144 285 250 144 285 251 minecraft:glass
setblock 144 285 252 minecraft:light_gray_concrete
fill 144 285 253 147 285 257 minecraft:glass
setblock 144 285 258 minecraft:light_gray_concrete
fill 144 285 259 144 285 260 minecraft:glass
setblock 144 285 261 minecraft:light_gray_concrete
fill 144 285 262 147 285 266 minecraft:glass
setblock 144 285 267 minecraft:light_gray_concrete
fill 144 285 268 182 285 269 minecraft:gray_concrete
fill 145 285 231 146 285 231 minecraft:glass
fill 145 285 232 146 285 233 minecraft:light_gray_concrete
fill 145 285 234 146 285 234 minecraft:glass
fill 145 285 240 146 285 240 minecraft:glass
fill 145 285 241 146 285 242 minecraft:light_gray_concrete
fill 145 285 243 146 285 243 minecraft:glass
fill 145 285 249 146 285 249 minecraft:glass
fill 145 285 250 146 285 251 minecraft:light_gray_concrete
fill 145 285 252 146 285 252 minecraft:glass
fill 145 285 258 146 285 258 minecraft:glass
fill 145 285 259 146 285 260 minecraft:light_gray_concrete
fill 145 285 261 146 285 261 minecraft:glass
fill 145 285 267 146 285 267 minecraft:glass
setblock 147 285 231 minecraft:light_gray_concrete
fill 147 285 232 153 285 233 minecraft:glass
setblock 147 285 234 minecraft:light_gray_concrete
setblock 147 285 240 minecraft:light_gray_concrete
fill 147 285 241 153 285 242 minecraft:glass
setblock 147 285 243 minecraft:light_gray_concrete
setblock 147 285 249 minecraft:light_gray_concrete
fill 147 285 250 153 285 251 minecraft:glass
setblock 147 285 252 minecraft:light_gray_concrete
setblock 147 285 258 minecraft:light_gray_concrete
fill 147 285 259 153 285 260 minecraft:glass
setblock 147 285 261 minecraft:light_gray_concrete
setblock 147 285 267 minecraft:light_gray_concrete
fill 148 285 231 152 285 231 minecraft:glass
fill 148 285 234 152 285 234 minecraft:glass
setblock 148 285 235 minecraft:light_gray_concrete
fill 148 285 236 148 285 238 minecraft:glass
setblock 148 285 239 minecraft:light_gray_concrete
fill 148 285 240 152 285 240 minecraft:glass
fill 148 285 243 152 285 243 minecraft:glass
setblock 148 285 244 minecraft:light_gray_concrete
fill 148 285 245 148 285 247 minecraft:glass
setblock 148 285 248 minecraft:light_gray_concrete
fill 148 285 249 152 285 249 minecraft:glass
fill 148 285 252 152 285 252 minecraft:glass
setblock 148 285 253 minecraft:light_gray_concrete
fill 148 285 254 148 285 256 minecraft:glass
setblock 148 285 257 minecraft:light_gray_concrete
fill 148 285 258 152 285 258 minecraft:glass
fill 148 285 261 152 285 261 minecraft:glass
setblock 148 285 262 minecraft:light_gray_concrete
fill 148 285 263 148 285 265 minecraft:glass
setblock 148 285 266 minecraft:light_gray_concrete
fill 148 285 267 152 285 267 minecraft:glass
fill 149 285 235 151 285 235 minecraft:glass
setblock 149 285 236 minecraft:light_gray_concrete
setblock 149 285 237 minecraft:glass
setblock 149 285 238 minecraft:light_gray_concrete
fill 149 285 239 151 285 239 minecraft:glass
fill 149 285 244 151 285 244 minecraft:glass
setblock 149 285 245 minecraft:light_gray_concrete
setblock 149 285 246 minecraft:glass
setblock 149 285 247 minecraft:light_gray_concrete
fill 149 285 248 151 285 248 minecraft:glass
fill 149 285 253 151 285 253 minecraft:glass
setblock 149 285 254 minecraft:light_gray_concrete
setblock 149 285 255 minecraft:glass
setblock 149 285 256 minecraft:light_gray_concrete
fill 149 285 257 151 285 257 minecraft:glass
fill 149 285 262 151 285 262 minecraft:glass
setblock 149 285 263 minecraft:light_gray_concrete
setblock 149 285 264 minecraft:glass
setblock 149 285 265 minecraft:light_gray_concrete
fill 149 285 266 151 285 266 minecraft:glass
setblock 150 285 236 minecraft:glass
setblock 150 285 237 minecraft:sea_lantern
setblock 150 285 238 minecraft:glass
setblock 150 285 245 minecraft:glass
setblock 150 285 246 minecraft:sea_lantern
setblock 150 285 247 minecraft:glass
setblock 150 285 254 minecraft:glass
setblock 150 285 255 minecraft:sea_lantern
setblock 150 285 256 minecraft:glass
setblock 150 285 263 minecraft:glass
setblock 150 285 264 minecraft:sea_lantern
setblock 150 285 265 minecraft:glass
setblock 151 285 236 minecraft:light_gray_concrete
fill 151 285 237 158 285 237 minecraft:glass
setblock 151 285 238 minecraft:light_gray_concrete
setblock 151 285 245 minecraft:light_gray_concrete
fill 151 285 246 155 285 246 minecraft:glass
setblock 151 285 247 minecraft:light_gray_concrete
setblock 151 285 254 minecraft:light_gray_concrete
fill 151 285 255 155 285 255 minecraft:glass
setblock 151 285 256 minecraft:light_gray_concrete
setblock 151 285 263 minecraft:light_gray_concrete
fill 151 285 264 158 285 264 minecraft:glass
setblock 151 285 265 minecraft:light_gray_concrete
setblock 152 285 235 minecraft:light_gray_concrete
fill 152 285 236 157 285 236 minecraft:glass
fill 152 285 238 157 285 238 minecraft:glass
setblock 152 285 239 minecraft:light_gray_concrete
setblock 152 285 244 minecraft:light_gray_concrete
fill 152 285 245 155 285 245 minecraft:glass
fill 152 285 247 155 285 247 minecraft:glass
setblock 152 285 248 minecraft:light_gray_concrete
setblock 152 285 253 minecraft:light_gray_concrete
fill 152 285 254 155 285 254 minecraft:glass
fill 152 285 256 157 285 256 minecraft:glass
setblock 152 285 257 minecraft:light_gray_concrete
setblock 152 285 262 minecraft:light_gray_concrete
fill 152 285 263 157 285 263 minecraft:glass
fill 152 285 265 157 285 265 minecraft:glass
setblock 152 285 266 minecraft:light_gray_concrete
setblock 153 285 231 minecraft:light_gray_concrete
setblock 153 285 234 minecraft:light_gray_concrete
fill 153 285 235 156 285 235 minecraft:glass
fill 153 285 239 156 285 239 minecraft:glass
setblock 153 285 240 minecraft:light_gray_concrete
setblock 153 285 243 minecraft:light_gray_concrete
fill 153 285 244 155 285 244 minecraft:glass
fill 153 285 248 155 285 248 minecraft:glass
setblock 153 285 249 minecraft:light_gray_concrete
setblock 153 285 252 minecraft:light_gray_concrete
fill 153 285 253 155 285 253 minecraft:glass
fill 153 285 257 156 285 257 minecraft:glass
setblock 153 285 258 minecraft:light_gray_concrete
setblock 153 285 261 minecraft:light_gray_concrete
fill 153 285 262 156 285 262 minecraft:glass
fill 153 285 266 156 285 266 minecraft:glass
setblock 153 285 267 minecraft:light_gray_concrete
fill 154 285 231 155 285 231 minecraft:glass
fill 154 285 232 155 285 233 minecraft:light_gray_concrete
fill 154 285 234 155 285 234 minecraft:glass
fill 154 285 240 155 285 240 minecraft:glass
fill 154 285 241 155 285 242 minecraft:light_gray_concrete
fill 154 285 243 155 285 243 minecraft:glass
fill 154 285 249 155 285 249 minecraft:glass
fill 154 285 250 155 285 251 minecraft:light_gray_concrete
fill 154 285 252 155 285 252 minecraft:glass
fill 154 285 258 155 285 258 minecraft:glass
fill 154 285 259 155 285 260 minecraft:light_gray_concrete
fill 154 285 261 155 285 261 minecraft:glass
fill 154 285 267 155 285 267 minecraft:glass
setblock 156 285 231 minecraft:light_gray_concrete
fill 156 285 232 162 285 233 minecraft:glass
setblock 156 285 234 minecraft:light_gray_concrete
setblock 156 285 240 minecraft:light_gray_concrete
fill 156 285 241 162 285 242 minecraft:glass
fill 156 285 244 156 285 254 minecraft:gold_block
setblock 156 285 258 minecraft:light_gray_concrete
fill 156 285 259 162 285 260 minecraft:glass
setblock 156 285 261 minecraft:light_gray_concrete
setblock 156 285 267 minecraft:light_gray_concrete
fill 157 285 231 161 285 231 minecraft:glass
fill 157 285 234 161 285 234 minecraft:glass
setblock 157 285 235 minecraft:light_gray_concrete
setblock 157 285 239 minecraft:light_gray_concrete
fill 157 285 240 161 285 240 minecraft:glass
fill 157 285 243 167 285 243 minecraft:gold_block
fill 157 285 255 167 285 255 minecraft:gold_block
setblock 157 285 257 minecraft:light_gray_concrete
fill 157 285 258 161 285 258 minecraft:glass
fill 157 285 261 161 285 261 minecraft:glass
setblock 157 285 262 minecraft:light_gray_concrete
setblock 157 285 266 minecraft:light_gray_concrete
fill 157 285 267 161 285 267 minecraft:glass
fill 158 285 235 160 285 235 minecraft:glass
setblock 158 285 236 minecraft:light_gray_concrete
setblock 158 285 238 minecraft:light_gray_concrete
fill 158 285 239 160 285 239 minecraft:glass
fill 158 285 245 158 285 253 minecraft:glass
setblock 158 285 256 minecraft:light_gray_concrete
fill 158 285 257 160 285 257 minecraft:glass
fill 158 285 262 160 285 262 minecraft:glass
setblock 158 285 263 minecraft:light_gray_concrete
setblock 158 285 265 minecraft:light_gray_concrete
fill 158 285 266 160 285 266 minecraft:glass
setblock 159 285 236 minecraft:glass
setblock 159 285 237 minecraft:sea_lantern
setblock 159 285 238 minecraft:glass
fill 159 285 245 159 285 249 minecraft:orange_stained_glass
fill 159 285 250 159 285 253 minecraft:glass
setblock 159 285 256 minecraft:glass
setblock 159 285 263 minecraft:glass
setblock 159 285 264 minecraft:sea_lantern
setblock 159 285 265 minecraft:glass
setblock 160 285 236 minecraft:light_gray_concrete
fill 160 285 237 167 285 237 minecraft:glass
setblock 160 285 238 minecraft:light_gray_concrete
setblock 160 285 245 minecraft:orange_stained_glass
fill 160 285 246 160 285 248 minecraft:sea_lantern
fill 160 285 249 160 285 250 minecraft:orange_stained_glass
fill 160 285 251 160 285 253 minecraft:glass
setblock 160 285 256 minecraft:light_gray_concrete
setblock 160 285 263 minecraft:light_gray_concrete
fill 160 285 264 167 285 264 minecraft:glass
setblock 160 285 265 minecraft:light_gray_concrete
setblock 161 285 235 minecraft:light_gray_concrete
fill 161 285 236 166 285 236 minecraft:glass
fill 161 285 238 166 285 238 minecraft:glass
setblock 161 285 239 minecraft:light_gray_concrete
fill 161 285 245 161 285 246 minecraft:sea_lantern
fill 161 285 248 161 285 249 minecraft:sea_lantern
fill 161 285 250 161 285 251 minecraft:orange_stained_glass
fill 161 285 252 166 285 253 minecraft:glass
fill 161 285 256 166 285 256 minecraft:glass
setblock 161 285 257 minecraft:light_gray_concrete
setblock 161 285 262 minecraft:light_gray_concrete
fill 161 285 263 166 285 263 minecraft:glass
fill 161 285 265 166 285 265 minecraft:glass
setblock 161 285 266 minecraft:light_gray_concrete
setblock 162 285 231 minecraft:light_gray_concrete
setblock 162 285 234 minecraft:light_gray_concrete
fill 162 285 235 165 285 235 minecraft:glass
fill 162 285 239 165 285 239 minecraft:glass
setblock 162 285 240 minecraft:light_gray_concrete
fill 162 285 244 162 285 245 minecraft:sea_lantern
fill 162 285 249 162 285 250 minecraft:sea_lantern
fill 162 285 251 165 285 251 minecraft:orange_stained_glass
fill 162 285 257 165 285 257 minecraft:glass
setblock 162 285 258 minecraft:light_gray_concrete
setblock 162 285 261 minecraft:light_gray_concrete
fill 162 285 262 165 285 262 minecraft:glass
fill 162 285 266 165 285 266 minecraft:glass
setblock 162 285 267 minecraft:light_gray_concrete
fill 163 285 231 164 285 231 minecraft:glass
fill 163 285 232 164 285 233 minecraft:light_gray_concrete
fill 163 285 234 164 285 234 minecraft:glass
fill 163 285 240 164 285 240 minecraft:glass
fill 163 285 241 164 285 242 minecraft:light_gray_concrete
fill 163 285 244 164 285 244 minecraft:sea_lantern
fill 163 285 250 164 285 250 minecraft:sea_lantern
fill 163 285 258 164 285 258 minecraft:glass
fill 163 285 259 164 285 260 minecraft:light_gray_concrete
fill 163 285 261 164 285 261 minecraft:glass
fill 163 285 267 164 285 267 minecraft:glass
fill 164 285 245 165 285 245 minecraft:sea_lantern
fill 164 285 249 165 285 249 minecraft:sea_lantern
setblock 165 285 231 minecraft:light_gray_concrete
fill 165 285 232 171 285 233 minecraft:glass
setblock 165 285 234 minecraft:light_gray_concrete
setblock 165 285 240 minecraft:light_gray_concrete
fill 165 285 241 171 285 242 minecraft:glass
fill 165 285 246 166 285 246 minecraft:sea_lantern
fill 165 285 248 166 285 248 minecraft:sea_lantern
fill 165 285 250 166 285 250 minecraft:orange_stained_glass
setblock 165 285 258 minecraft:light_gray_concrete
fill 165 285 259 171 285 260 minecraft:glass
setblock 165 285 261 minecraft:light_gray_concrete
setblock 165 285 267 minecraft:light_gray_concrete
fill 166 285 231 170 285 231 minecraft:glass
fill 166 285 234 170 285 234 minecraft:glass
setblock 166 285 235 minecraft:light_gray_concrete
setblock 166 285 239 minecraft:light_gray_concrete
fill 166 285 240 170 285 240 minecraft:glass
setblock 166 285 245 minecraft:orange_stained_glass
setblock 166 285 247 minecraft:sea_lantern
setblock 166 285 249 minecraft:orange_stained_glass
setblock 166 285 251 minecraft:glass
setblock 166 285 257 minecraft:light_gray_concrete
fill 166 285 258 170 285 258 minecraft:glass
fill 166 285 261 170 285 261 minecraft:glass
setblock 166 285 262 minecraft:light_gray_concrete
setblock 166 285 266 minecraft:light_gray_concrete
fill 166 285 267 170 285 267 minecraft:glass
fill 167 285 235 169 285 235 minecraft:glass
setblock 167 285 236 minecraft:light_gray_concrete
setblock 167 285 238 minecraft:light_gray_concrete
fill 167 285 239 169 285 239 minecraft:glass
setblock 167 285 256 minecraft:light_gray_concrete
fill 167 285 257 169 285 257 minecraft:glass
fill 167 285 262 169 285 262 minecraft:glass
setblock 167 285 263 minecraft:light_gray_concrete
setblock 167 285 265 minecraft:light_gray_concrete
fill 167 285 266 169 285 266 minecraft:glass
setblock 168 285 236 minecraft:glass
setblock 168 285 237 minecraft:sea_lantern
setblock 168 285 238 minecraft:glass
fill 168 285 244 168 285 254 minecraft:gold_block
setblock 168 285 256 minecraft:glass
setblock 168 285 263 minecraft:glass
setblock 168 285 264 minecraft:sea_lantern
setblock 168 285 265 minecraft:glass
setblock 169 285 236 minecraft:light_gray_concrete
fill 169 285 237 176 285 237 minecraft:glass
setblock 169 285 238 minecraft:light_gray_concrete
fill 169 285 243 169 285 244 minecraft:glass
setblock 169 285 245 minecraft:light_gray_concrete
fill 169 285 246 176 285 246 minecraft:glass
setblock 169 285 247 minecraft:light_gray_concrete
fill 169 285 248 169 285 253 minecraft:glass
setblock 169 285 254 minecraft:light_gray_concrete
fill 169 285 255 176 285 255 minecraft:glass
setblock 169 285 256 minecraft:light_gray_concrete
setblock 169 285 263 minecraft:light_gray_concrete
fill 169 285 264 176 285 264 minecraft:glass
setblock 169 285 265 minecraft:light_gray_concrete
setblock 170 285 235 minecraft:light_gray_concrete
fill 170 285 236 175 285 236 minecraft:glass
fill 170 285 238 175 285 238 minecraft:glass
setblock 170 285 239 minecraft:light_gray_concrete
setblock 170 285 243 minecraft:glass
setblock 170 285 244 minecraft:light_gray_concrete
fill 170 285 245 175 285 245 minecraft:glass
fill 170 285 247 175 285 247 minecraft:glass
setblock 170 285 248 minecraft:light_gray_concrete
fill 170 285 249 170 285 252 minecraft:glass
setblock 170 285 253 minecraft:light_gray_concrete
fill 170 285 254 175 285 254 minecraft:glass
fill 170 285 256 175 285 256 minecraft:glass
setblock 170 285 257 minecraft:light_gray_concrete
setblock 170 285 262 minecraft:light_gray_concrete
fill 170 285 263 175 285 263 minecraft:glass
fill 170 285 265 175 285 265 minecraft:glass
setblock 170 285 266 minecraft:light_gray_concrete
setblock 171 285 231 minecraft:light_gray_concrete
setblock 171 285 234 minecraft:light_gray_concrete
fill 171 285 235 174 285 235 minecraft:glass
fill 171 285 239 174 285 239 minecraft:glass
setblock 171 285 240 minecraft:light_gray_concrete
setblock 171 285 243 minecraft:light_gray_concrete
fill 171 285 244 174 285 244 minecraft:glass
fill 171 285 248 174 285 248 minecraft:glass
setblock 171 285 249 minecraft:light_gray_concrete
fill 171 285 250 171 285 251 minecraft:glass
setblock 171 285 252 minecraft:light_gray_concrete
fill 171 285 253 174 285 253 minecraft:glass
fill 171 285 257 174 285 257 minecraft:glass
setblock 171 285 258 minecraft:light_gray_concrete
setblock 171 285 261 minecraft:light_gray_concrete
fill 171 285 262 174 285 262 minecraft:glass
fill 171 285 266 174 285 266 minecraft:glass
setblock 171 285 267 minecraft:light_gray_concrete
fill 172 285 231 173 285 231 minecraft:glass
fill 172 285 232 173 285 233 minecraft:light_gray_concrete
fill 172 285 234 173 285 234 minecraft:glass
fill 172 285 240 173 285 240 minecraft:glass
fill 172 285 241 173 285 242 minecraft:light_gray_concrete
fill 172 285 243 173 285 243 minecraft:glass
fill 172 285 249 173 285 249 minecraft:glass
fill 172 285 250 173 285 251 minecraft:light_gray_concrete
fill 172 285 252 173 285 252 minecraft:glass
fill 172 285 258 173 285 258 minecraft:glass
fill 172 285 259 173 285 260 minecraft:light_gray_concrete
fill 172 285 261 173 285 261 minecraft:glass
fill 172 285 267 173 285 267 minecraft:glass
setblock 174 285 231 minecraft:light_gray_concrete
fill 174 285 232 180 285 233 minecraft:glass
setblock 174 285 234 minecraft:light_gray_concrete
setblock 174 285 240 minecraft:light_gray_concrete
fill 174 285 241 180 285 242 minecraft:glass
setblock 174 285 243 minecraft:light_gray_concrete
setblock 174 285 249 minecraft:light_gray_concrete
fill 174 285 250 180 285 251 minecraft:glass
setblock 174 285 252 minecraft:light_gray_concrete
setblock 174 285 258 minecraft:light_gray_concrete
fill 174 285 259 180 285 260 minecraft:glass
setblock 174 285 261 minecraft:light_gray_concrete
setblock 174 285 267 minecraft:light_gray_concrete
fill 175 285 231 179 285 231 minecraft:glass
fill 175 285 234 179 285 234 minecraft:glass
setblock 175 285 235 minecraft:light_gray_concrete
setblock 175 285 239 minecraft:light_gray_concrete
fill 175 285 240 179 285 240 minecraft:glass
fill 175 285 243 179 285 243 minecraft:glass
setblock 175 285 244 minecraft:light_gray_concrete
setblock 175 285 248 minecraft:light_gray_concrete
fill 175 285 249 179 285 249 minecraft:glass
fill 175 285 252 179 285 252 minecraft:glass
setblock 175 285 253 minecraft:light_gray_concrete
setblock 175 285 257 minecraft:light_gray_concrete
fill 175 285 258 179 285 258 minecraft:glass
fill 175 285 261 179 285 261 minecraft:glass
setblock 175 285 262 minecraft:light_gray_concrete
setblock 175 285 266 minecraft:light_gray_concrete
fill 175 285 267 179 285 267 minecraft:glass
fill 176 285 235 178 285 235 minecraft:glass
setblock 176 285 236 minecraft:light_gray_concrete
setblock 176 285 238 minecraft:light_gray_concrete
fill 176 285 239 178 285 239 minecraft:glass
fill 176 285 244 178 285 244 minecraft:glass
setblock 176 285 245 minecraft:light_gray_concrete
setblock 176 285 247 minecraft:light_gray_concrete
fill 176 285 248 178 285 248 minecraft:glass
fill 176 285 253 178 285 253 minecraft:glass
setblock 176 285 254 minecraft:light_gray_concrete
setblock 176 285 256 minecraft:light_gray_concrete
fill 176 285 257 178 285 257 minecraft:glass
fill 176 285 262 178 285 262 minecraft:glass
setblock 176 285 263 minecraft:light_gray_concrete
setblock 176 285 265 minecraft:light_gray_concrete
fill 176 285 266 178 285 266 minecraft:glass
setblock 177 285 236 minecraft:glass
setblock 177 285 237 minecraft:sea_lantern
setblock 177 285 238 minecraft:glass
setblock 177 285 245 minecraft:glass
setblock 177 285 246 minecraft:sea_lantern
setblock 177 285 247 minecraft:glass
setblock 177 285 254 minecraft:glass
setblock 177 285 255 minecraft:sea_lantern
setblock 177 285 256 minecraft:glass
setblock 177 285 263 minecraft:glass
setblock 177 285 264 minecraft:sea_lantern
setblock 177 285 265 minecraft:glass
setblock 178 285 236 minecraft:light_gray_concrete
fill 178 285 237 180 285 237 minecraft:glass
setblock 178 285 238 minecraft:light_gray_concrete
setblock 178 285 245 minecraft:light_gray_concrete
fill 178 285 246 180 285 246 minecraft:glass
setblock 178 285 247 minecraft:light_gray_concrete
setblock 178 285 254 minecraft:light_gray_concrete
fill 178 285 255 180 285 255 minecraft:glass
setblock 178 285 256 minecraft:light_gray_concrete
setblock 178 285 263 minecraft:light_gray_concrete
fill 178 285 264 180 285 264 minecraft:glass
setblock 178 285 265 minecraft:light_gray_concrete
setblock 179 285 235 minecraft:light_gray_concrete
fill 179 285 236 180 285 236 minecraft:glass
fill 179 285 238 180 285 238 minecraft:glass
setblock 179 285 239 minecraft:light_gray_concrete
setblock 179 285 244 minecraft:light_gray_concrete
fill 179 285 245 180 285 245 minecraft:glass
fill 179 285 247 180 285 247 minecraft:glass
setblock 179 285 248 minecraft:light_gray_concrete
setblock 179 285 253 minecraft:light_gray_concrete
fill 179 285 254 180 285 254 minecraft:glass
fill 179 285 256 180 285 256 minecraft:glass
setblock 179 285 257 minecraft:light_gray_concrete
setblock 179 285 262 minecraft:light_gray_concrete
fill 179 285 263 180 285 263 minecraft:glass
fill 179 285 265 180 285 265 minecraft:glass
setblock 179 285 266 minecraft:light_gray_concrete
setblock 180 285 231 minecraft:light_gray_concrete
setblock 180 285 234 minecraft:light_gray_concrete
setblock 180 285 235 minecraft:glass
setblock 180 285 239 minecraft:glass
setblock 180 285 240 minecraft:light_gray_concrete
setblock 180 285 243 minecraft:light_gray_concrete
setblock 180 285 244 minecraft:glass
setblock 180 285 248 minecraft:glass
setblock 180 285 249 minecraft:light_gray_concrete
setblock 180 285 252 minecraft:light_gray_concrete
setblock 180 285 253 minecraft:glass
setblock 180 285 257 minecraft:glass
setblock 180 285 258 minecraft:light_gray_concrete
setblock 180 285 261 minecraft:light_gray_concrete
setblock 180 285 262 minecraft:glass
setblock 180 285 266 minecraft:glass
setblock 180 285 267 minecraft:light_gray_concrete
fill 181 285 231 182 285 267 minecraft:gray_concrete
fill 157 286 244 157 303 244 minecraft:iron_bars
fill 157 286 254 157 303 254 minecraft:iron_bars
fill 167 286 244 167 303 244 minecraft:iron_bars
fill 167 286 254 167 303 254 minecraft:iron_bars
setblock 144 288 231 minecraft:light[level=15]
setblock 144 288 238 minecraft:light[level=15]
setblock 144 288 245 minecraft:light[level=15]
setblock 144 288 252 minecraft:light[level=15]
setblock 144 288 259 minecraft:light[level=15]
setblock 144 288 266 minecraft:light[level=15]
setblock 151 288 231 minecraft:light[level=15]
setblock 151 288 238 minecraft:light[level=15]
setblock 151 288 245 minecraft:light[level=15]
setblock 151 288 252 minecraft:light[level=15]
setblock 151 288 259 minecraft:light[level=15]
setblock 151 288 266 minecraft:light[level=15]
setblock 158 288 231 minecraft:light[level=15]
setblock 158 288 238 minecraft:light[level=15]
setblock 158 288 245 minecraft:light[level=15]
setblock 158 288 252 minecraft:light[level=15]
setblock 158 288 259 minecraft:light[level=15]
setblock 158 288 266 minecraft:light[level=15]
setblock 165 288 231 minecraft:light[level=15]
setblock 165 288 238 minecraft:light[level=15]
setblock 165 288 245 minecraft:light[level=15]
setblock 165 288 252 minecraft:light[level=15]
setblock 165 288 259 minecraft:light[level=15]
setblock 165 288 266 minecraft:light[level=15]
setblock 172 288 231 minecraft:light[level=15]
setblock 172 288 238 minecraft:light[level=15]
setblock 172 288 245 minecraft:light[level=15]
setblock 172 288 252 minecraft:light[level=15]
setblock 172 288 259 minecraft:light[level=15]
setblock 172 288 266 minecraft:light[level=15]
setblock 179 288 231 minecraft:light[level=15]
setblock 179 288 238 minecraft:light[level=15]
setblock 179 288 245 minecraft:light[level=15]
setblock 179 288 252 minecraft:light[level=15]
setblock 179 288 259 minecraft:light[level=15]
setblock 179 288 266 minecraft:light[level=15]
setblock 144 294 231 minecraft:light[level=15]
setblock 144 294 238 minecraft:light[level=15]
setblock 144 294 245 minecraft:light[level=15]
setblock 144 294 252 minecraft:light[level=15]
setblock 144 294 259 minecraft:light[level=15]
setblock 144 294 266 minecraft:light[level=15]
setblock 151 294 231 minecraft:light[level=15]
setblock 151 294 238 minecraft:light[level=15]
setblock 151 294 245 minecraft:light[level=15]
setblock 151 294 252 minecraft:light[level=15]
setblock 151 294 259 minecraft:light[level=15]
setblock 151 294 266 minecraft:light[level=15]
setblock 158 294 231 minecraft:light[level=15]
setblock 158 294 238 minecraft:light[level=15]
setblock 158 294 245 minecraft:light[level=15]
setblock 158 294 252 minecraft:light[level=15]
setblock 158 294 259 minecraft:light[level=15]
setblock 158 294 266 minecraft:light[level=15]
setblock 165 294 231 minecraft:light[level=15]
setblock 165 294 238 minecraft:light[level=15]
setblock 165 294 245 minecraft:light[level=15]
setblock 165 294 252 minecraft:light[level=15]
setblock 165 294 259 minecraft:light[level=15]
setblock 165 294 266 minecraft:light[level=15]
setblock 172 294 231 minecraft:light[level=15]
setblock 172 294 238 minecraft:light[level=15]
setblock 172 294 245 minecraft:light[level=15]
setblock 172 294 252 minecraft:light[level=15]
setblock 172 294 259 minecraft:light[level=15]
setblock 172 294 266 minecraft:light[level=15]
setblock 179 294 231 minecraft:light[level=15]
setblock 179 294 238 minecraft:light[level=15]
setblock 179 294 245 minecraft:light[level=15]
setblock 179 294 252 minecraft:light[level=15]
setblock 179 294 259 minecraft:light[level=15]
setblock 179 294 266 minecraft:light[level=15]
setblock 144 300 231 minecraft:light[level=15]
setblock 144 300 238 minecraft:light[level=15]
setblock 144 300 245 minecraft:light[level=15]
setblock 144 300 252 minecraft:light[level=15]
setblock 144 300 259 minecraft:light[level=15]
setblock 144 300 266 minecraft:light[level=15]
setblock 151 300 231 minecraft:light[level=15]
setblock 151 300 238 minecraft:light[level=15]
setblock 151 300 245 minecraft:light[level=15]
setblock 151 300 252 minecraft:light[level=15]
setblock 151 300 259 minecraft:light[level=15]
setblock 151 300 266 minecraft:light[level=15]
setblock 158 300 231 minecraft:light[level=15]
setblock 158 300 238 minecraft:light[level=15]
setblock 158 300 245 minecraft:light[level=15]
setblock 158 300 252 minecraft:light[level=15]
setblock 158 300 259 minecraft:light[level=15]
setblock 158 300 266 minecraft:light[level=15]
setblock 165 300 231 minecraft:light[level=15]
setblock 165 300 238 minecraft:light[level=15]
setblock 165 300 245 minecraft:light[level=15]
setblock 165 300 252 minecraft:light[level=15]
setblock 165 300 259 minecraft:light[level=15]
setblock 165 300 266 minecraft:light[level=15]
setblock 172 300 231 minecraft:light[level=15]
setblock 172 300 238 minecraft:light[level=15]
setblock 172 300 245 minecraft:light[level=15]
setblock 172 300 252 minecraft:light[level=15]
setblock 172 300 259 minecraft:light[level=15]
setblock 172 300 266 minecraft:light[level=15]
setblock 179 300 231 minecraft:light[level=15]
setblock 179 300 238 minecraft:light[level=15]
setblock 179 300 245 minecraft:light[level=15]
setblock 179 300 252 minecraft:light[level=15]
setblock 179 300 259 minecraft:light[level=15]
setblock 179 300 266 minecraft:light[level=15]
fill 142 307 233 145 307 233 minecraft:light_gray_concrete
fill 142 307 241 145 307 241 minecraft:light_gray_concrete
fill 142 307 249 145 307 249 minecraft:light_gray_concrete
fill 142 307 257 145 307 257 minecraft:light_gray_concrete
fill 142 307 265 145 307 265 minecraft:light_gray_concrete
fill 146 307 229 146 307 232 minecraft:light_gray_concrete
setblock 146 307 233 minecraft:sea_lantern
fill 146 307 234 146 307 240 minecraft:light_gray_concrete
setblock 146 307 241 minecraft:sea_lantern
fill 146 307 242 146 307 248 minecraft:light_gray_concrete
setblock 146 307 249 minecraft:sea_lantern
fill 146 307 250 146 307 256 minecraft:light_gray_concrete
setblock 146 307 257 minecraft:sea_lantern
fill 146 307 258 146 307 264 minecraft:light_gray_concrete
setblock 146 307 265 minecraft:sea_lantern
fill 146 307 266 146 307 269 minecraft:light_gray_concrete
fill 147 307 233 153 307 233 minecraft:light_gray_concrete
fill 147 307 241 153 307 241 minecraft:light_gray_concrete
fill 147 307 249 153 307 249 minecraft:light_gray_concrete
fill 147 307 257 153 307 257 minecraft:light_gray_concrete
fill 147 307 265 153 307 265 minecraft:light_gray_concrete
fill 154 307 229 154 307 232 minecraft:light_gray_concrete
setblock 154 307 233 minecraft:sea_lantern
fill 154 307 234 154 307 240 minecraft:light_gray_concrete
setblock 154 307 241 minecraft:sea_lantern
fill 154 307 242 154 307 248 minecraft:light_gray_concrete
setblock 154 307 249 minecraft:sea_lantern
fill 154 307 250 154 307 256 minecraft:light_gray_concrete
setblock 154 307 257 minecraft:sea_lantern
fill 154 307 258 154 307 264 minecraft:light_gray_concrete
setblock 154 307 265 minecraft:sea_lantern
fill 154 307 266 154 307 269 minecraft:light_gray_concrete
fill 155 307 233 161 307 233 minecraft:light_gray_concrete
fill 155 307 241 161 307 241 minecraft:light_gray_concrete
fill 155 307 249 160 307 249 minecraft:light_gray_concrete
fill 155 307 257 161 307 257 minecraft:light_gray_concrete
fill 155 307 265 161 307 265 minecraft:light_gray_concrete
fill 162 307 229 162 307 232 minecraft:light_gray_concrete
setblock 162 307 233 minecraft:sea_lantern
fill 162 307 234 162 307 240 minecraft:light_gray_concrete
setblock 162 307 241 minecraft:sea_lantern
fill 162 307 242 162 307 247 minecraft:light_gray_concrete
fill 162 307 251 162 307 256 minecraft:light_gray_concrete
setblock 162 307 257 minecraft:sea_lantern
fill 162 307 258 162 307 264 minecraft:light_gray_concrete
setblock 162 307 265 minecraft:sea_lantern
fill 162 307 266 162 307 269 minecraft:light_gray_concrete
fill 163 307 233 169 307 233 minecraft:light_gray_concrete
fill 163 307 241 169 307 241 minecraft:light_gray_concrete
fill 163 307 257 169 307 257 minecraft:light_gray_concrete
fill 163 307 265 169 307 265 minecraft:light_gray_concrete
fill 164 307 249 169 307 249 minecraft:light_gray_concrete
fill 170 307 229 170 307 232 minecraft:light_gray_concrete
setblock 170 307 233 minecraft:sea_lantern
fill 170 307 234 170 307 240 minecraft:light_gray_concrete
setblock 170 307 241 minecraft:sea_lantern
fill 170 307 242 170 307 248 minecraft:light_gray_concrete
setblock 170 307 249 minecraft:sea_lantern
fill 170 307 250 170 307 256 minecraft:light_gray_concrete
setblock 170 307 257 minecraft:sea_lantern
fill 170 307 258 170 307 264 minecraft:light_gray_concrete
setblock 170 307 265 minecraft:sea_lantern
fill 170 307 266 170 307 269 minecraft:light_gray_concrete
fill 171 307 233 177 307 233 minecraft:light_gray_concrete
fill 171 307 241 177 307 241 minecraft:light_gray_concrete
fill 171 307 249 177 307 249 minecraft:light_gray_concrete
fill 171 307 257 177 307 257 minecraft:light_gray_concrete
fill 171 307 265 177 307 265 minecraft:light_gray_concrete
fill 178 307 229 178 307 232 minecraft:light_gray_concrete
setblock 178 307 233 minecraft:sea_lantern
fill 178 307 234 178 307 240 minecraft:light_gray_concrete
setblock 178 307 241 minecraft:sea_lantern
fill 178 307 242 178 307 248 minecraft:light_gray_concrete
setblock 178 307 249 minecraft:sea_lantern
fill 178 307 250 178 307 256 minecraft:light_gray_concrete
setblock 178 307 257 minecraft:sea_lantern
fill 178 307 258 178 307 264 minecraft:light_gray_concrete
setblock 178 307 265 minecraft:sea_lantern
fill 178 307 266 178 307 269 minecraft:light_gray_concrete
fill 179 307 233 182 307 233 minecraft:light_gray_concrete
fill 179 307 241 182 307 241 minecraft:light_gray_concrete
fill 179 307 249 182 307 249 minecraft:light_gray_concrete
fill 179 307 257 182 307 257 minecraft:light_gray_concrete
fill 179 307 265 182 307 265 minecraft:light_gray_concrete
fill 142 308 229 182 308 269 minecraft:black_concrete
