fill 223 234 611 224 234 612 minecraft:magenta_concrete
fill 223 234 617 224 234 618 minecraft:magenta_concrete
fill 223 234 623 224 234 624 minecraft:magenta_concrete
fill 223 234 629 224 234 630 minecraft:magenta_concrete
fill 223 234 635 224 234 636 minecraft:magenta_concrete
fill 223 234 641 224 234 642 minecraft:magenta_concrete
fill 224 234 604 227 241 604 minecraft:lime_concrete
fill 224 234 605 224 234 606 minecraft:magenta_concrete
fill 225 234 605 225 234 606 minecraft:black_concrete
fill 225 234 611 225 234 612 minecraft:black_concrete
fill 225 234 617 225 234 618 minecraft:black_concrete
fill 225 234 623 225 234 624 minecraft:black_concrete
fill 225 234 629 225 234 630 minecraft:black_concrete
fill 225 234 635 225 234 636 minecraft:black_concrete
fill 225 234 641 225 234 642 minecraft:black_concrete
fill 226 234 605 227 234 606 minecraft:magenta_concrete
fill 226 234 611 227 234 612 minecraft:magenta_concrete
fill 226 234 617 227 234 618 minecraft:magenta_concrete
fill 226 234 623 227 234 624 minecraft:magenta_concrete
fill 226 234 629 227 234 630 minecraft:magenta_concrete
fill 226 234 635 227 234 636 minecraft:magenta_concrete
fill 226 234 641 227 234 642 minecraft:magenta_concrete
fill 228 234 605 228 234 606 minecraft:black_concrete
fill 228 234 611 228 234 612 minecraft:black_concrete
fill 228 234 617 228 234 618 minecraft:black_concrete
fill 228 234 623 228 234 624 minecraft:black_concrete
fill 228 234 629 228 234 630 minecraft:black_concrete
fill 228 234 635 228 234 636 minecraft:black_concrete
fill 228 234 641 228 234 642 minecraft:black_concrete
fill 229 234 605 229 234 606 minecraft:magenta_concrete
fill 229 234 611 229 234 612 minecraft:magenta_concrete
fill 229 234 617 229 234 618 minecraft:magenta_concrete
fill 229 234 623 229 234 624 minecraft:magenta_concrete
fill 229 234 629 229 234 630 minecraft:magenta_concrete
fill 229 234 635 229 234 636 minecraft:magenta_concrete
fill 229 234 641 229 234 642 minecraft:magenta_concrete
setblock 230 234 605 minecraft:magenta_concrete
fill 230 234 606 230 241 609 minecraft:lime_concrete
setblock 230 234 610 minecraft:magenta_concrete
fill 230 234 611 230 307 615 minecraft:lime_concrete
fill 230 234 622 230 307 622 minecraft:lime_concrete
fill 230 234 625 230 241 625 minecraft:lime_concrete
fill 230 234 632 230 307 632 minecraft:lime_concrete
setblock 230 234 633 minecraft:magenta_concrete
fill 230 234 634 230 234 644 minecraft:lime_concrete
setblock 230 234 645 minecraft:magenta_concrete
fill 188 235 608 188 307 608 minecraft:lime_concrete
fill 188 235 614 188 307 616 minecraft:lime_concrete
setblock 188 235 617 minecraft:magenta_concrete
setblock 188 235 619 minecraft:magenta_concrete
fill 188 235 620 188 307 621 minecraft:lime_concrete
fill 188 235 623 188 307 624 minecraft:lime_concrete
fill 188 235 625 188 235 626 minecraft:magenta_concrete
fill 188 235 627 188 307 627 minecraft:lime_concrete
fill 188 235 629 188 307 629 minecraft:lime_concrete
fill 188 235 632 188 307 632 minecraft:lime_concrete
fill 188 235 634 188 307 639 minecraft:lime_concrete
setblock 188 235 640 minecraft:magenta_concrete
fill 188 235 641 188 241 644 minecraft:lime_concrete
setblock 188 235 645 minecraft:magenta_concrete
fill 188 235 646 188 307 646 minecraft:lime_concrete
fill 190 235 646 190 307 646 minecraft:lime_concrete
fill 192 235 646 192 307 646 minecraft:lime_concrete
fill 193 235 604 194 307 604 minecraft:lime_concrete
setblock 193 235 646 minecraft:magenta_concrete
fill 194 235 646 197 307 646 minecraft:lime_concrete
setblock 195 235 604 minecraft:magenta_concrete
fill 196 235 604 199 307 604 minecraft:lime_concrete
fill 200 235 646 200 307 646 minecraft:lime_concrete
fill 202 235 604 202 307 604 minecraft:lime_concrete
fill 203 235 646 208 241 646 minecraft:lime_concrete
fill 206 235 604 206 307 604 minecraft:lime_concrete
setblock 209 235 646 minecraft:magenta_concrete
fill 210 235 604 214 241 604 minecraft:lime_concrete
fill 210 235 646 211 307 646 minecraft:lime_concrete
setblock 212 235 646 minecraft:magenta_concrete
fill 213 235 646 215 241 646 minecraft:lime_concrete
setblock 215 235 604 minecraft:magenta_concrete
fill 216 235 604 218 307 604 minecraft:lime_concrete
fill 216 235 646 217 235 646 minecraft:magenta_concrete
fill 218 235 646 221 307 646 minecraft:lime_concrete
setblock 219 235 604 minecraft:magenta_concrete
fill 220 235 604 223 307 604 minecraft:lime_concrete
setblock 222 235 646 minecraft:magenta_concrete
fill 223 235 646 229 241 646 minecraft:lime_concrete
fill 230 235 605 230 307 605 minecraft:lime_concrete
fill 230 235 610 230 307 610 minecraft:lime_concrete
fill 230 235 626 230 307 627 minecraft:lime_concrete
setblock 230 235 628 minecraft:magenta_concrete
fill 230 235 629 230 307 630 minecraft:lime_concrete
setblock 230 235 631 minecraft:magenta_concrete
fill 230 235 633 230 241 633 minecraft:lime_concrete
setblock 230 235 634 minecraft:magenta_concrete
fill 230 235 635 230 307 639 minecraft:lime_concrete
setblock 230 235 640 minecraft:magenta_concrete
fill 230 235 641 230 241 645 minecraft:lime_concrete
setblock 230 235 646 minecraft:magenta_concrete
fill 188 236 617 188 241 617 minecraft:lime_concrete
fill 188 236 619 188 307 619 minecraft:lime_concrete
fill 188 236 622 188 307 622 minecraft:lime_concrete
fill 188 236 625 188 241 626 minecraft:lime_concrete
fill 188 236 640 188 307 640 minecraft:lime_concrete
fill 188 236 645 188 307 645 minecraft:lime_concrete
fill 193 236 646 193 307 646 minecraft:lime_concrete
fill 195 236 604 195 241 604 minecraft:lime_concrete
fill 200 236 604 200 307 604 minecraft:lime_concrete
fill 209 236 646 209 307 646 minecraft:lime_concrete
fill 212 236 646 212 307 646 minecraft:lime_concrete
fill 215 236 604 215 307 604 minecraft:lime_concrete
fill 216 236 646 217 307 646 minecraft:lime_concrete
fill 219 236 604 219 241 604 minecraft:lime_concrete
fill 222 236 646 222 307 646 minecraft:lime_concrete
fill 230 236 628 230 307 628 minecraft:lime_concrete
fill 230 236 631 230 307 631 minecraft:lime_concrete
fill 230 236 634 230 307 634 minecraft:lime_concrete
fill 230 236 640 230 307 640 minecraft:lime_concrete
fill 230 236 646 230 307 646 minecraft:lime_concrete
fill 189 238 605 190 238 645 minecraft:black_concrete
fill 191 238 605 229 238 606 minecraft:black_concrete
fill 191 238 644 229 238 645 minecraft:black_concrete
fill 228 238 607 229 238 643 minecraft:black_concrete
fill 189 239 605 189 239 645 minecraft:black_concrete
fill 190 239 605 229 239 605 minecraft:black_concrete
fill 190 239 645 229 239 645 minecraft:black_concrete
setblock 191 239 607 minecraft:light[level=14]
setblock 191 239 615 minecraft:light[level=14]
setblock 191 239 623 minecraft:light[level=14]
setblock 191 239 631 minecraft:light[level=14]
setblock 191 239 639 minecraft:light[level=14]
setblock 199 239 607 minecraft:light[level=14]
setblock 199 239 615 minecraft:light[level=14]
setblock 199 239 623 minecraft:light[level=14]
setblock 199 239 631 minecraft:light[level=14]
setblock 199 239 639 minecraft:light[level=14]
setblock 207 239 607 minecraft:light[level=14]
setblock 207 239 615 minecraft:light[level=14]
setblock 207 239 623 minecraft:light[level=14]
setblock 207 239 631 minecraft:light[level=14]
setblock 207 239 639 minecraft:light[level=14]
setblock 215 239 607 minecraft:light[level=14]
setblock 215 239 615 minecraft:light[level=14]
setblock 215 239 623 minecraft:light[level=14]
setblock 215 239 631 minecraft:light[level=14]
setblock 215 239 639 minecraft:light[level=14]
setblock 223 239 607 minecraft:light[level=14]
setblock 223 239 615 minecraft:light[level=14]
setblock 223 239 623 minecraft:light[level=14]
setblock 223 239 631 minecraft:light[level=14]
setblock 223 239 639 minecraft:light[level=14]
fill 229 239 606 229 239 644 minecraft:black_concrete
fill 189 240 611 189 273 612 minecraft:black_concrete
fill 189 240 619 189 273 620 minecraft:black_concrete
fill 189 240 627 189 273 628 minecraft:black_concrete
fill 189 240 635 189 273 636 minecraft:black_concrete
fill 189 240 643 189 273 644 minecraft:black_concrete
fill 190 240 605 191 273 605 minecraft:black_concrete
fill 195 240 645 196 273 645 minecraft:black_concrete
fill 198 240 605 199 273 605 minecraft:black_concrete
fill 203 240 645 204 273 645 minecraft:black_concrete
fill 206 240 605 207 273 605 minecraft:black_concrete
fill 211 240 645 212 273 645 minecraft:black_concrete
fill 214 240 605 215 273 605 minecraft:black_concrete
fill 219 240 645 220 273 645 minecraft:black_concrete
fill 222 240 605 223 273 605 minecraft:black_concrete
fill 227 240 645 228 273 645 minecraft:black_concrete
fill 229 240 606 229 273 607 minecraft:black_concrete
fill 229 240 614 229 273 615 minecraft:black_concrete
fill 229 240 622 229 273 623 minecraft:black_concrete
fill 229 240 630 229 273 631 minecraft:black_concrete
fill 229 240 638 229 273 639 minecraft:black_concrete
fill 188 242 609 188 247 609 minecraft:sea_lantern
fill 188 242 610 188 307 613 minecraft:lime_concrete
fill 188 242 617 188 247 617 minecraft:sea_lantern
fill 188 242 625 188 247 625 minecraft:sea_lantern
fill 188 242 626 188 307 626 minecraft:lime_concrete
fill 188 242 633 188 247 633 minecraft:sea_lantern
fill 188 242 641 188 247 641 minecraft:sea_lantern
fill 188 242 642 188 307 644 minecraft:lime_concrete
fill 191 242 646 191 247 646 minecraft:sea_lantern
fill 195 242 604 195 247 604 minecraft:sea_lantern
fill 198 242 646 198 307 646 minecraft:lime_concrete
fill 199 242 646 199 247 646 minecraft:sea_lantern
fill 203 242 604 203 247 604 minecraft:sea_lantern
fill 203 242 646 206 307 646 minecraft:lime_concrete
fill 204 242 604 205 307 604 minecraft:lime_concrete
fill 207 242 646 207 247 646 minecraft:sea_lantern
fill 208 242 646 208 307 646 minecraft:lime_concrete
fill 210 242 604 210 307 604 minecraft:lime_concrete
fill 211 242 604 211 247 604 minecraft:sea_lantern
fill 212 242 604 214 307 604 minecraft:lime_concrete
fill 213 242 646 214 307 646 minecraft:lime_concrete
fill 215 242 646 215 247 646 minecraft:sea_lantern
fill 217 242 625 218 243 626 minecraft:yellow_concrete
fill 219 242 604 219 247 604 minecraft:sea_lantern
fill 223 242 646 223 247 646 minecraft:sea_lantern
fill 224 242 604 226 307 604 minecraft:lime_concrete
fill 224 242 646 229 307 646 minecraft:lime_concrete
fill 227 242 604 227 247 604 minecraft:sea_lantern
fill 230 242 606 230 307 608 minecraft:lime_concrete
fill 230 242 609 230 247 609 minecraft:sea_lantern
fill 230 242 616 230 307 616 minecraft:lime_concrete
fill 230 242 617 230 247 617 minecraft:sea_lantern
fill 230 242 618 230 307 621 minecraft:lime_concrete
fill 230 242 625 230 247 625 minecraft:sea_lantern
fill 230 242 633 230 247 633 minecraft:sea_lantern
fill 230 242 641 230 247 641 minecraft:sea_lantern
fill 230 242 642 230 307 645 minecraft:lime_concrete
fill 207 243 610 207 244 610 minecraft:white_stained_glass
fill 196 245 619 197 246 620 minecraft:lime_concrete
fill 207 245 610 207 253 610 minecraft:black_concrete
fill 208 246 610 208 253 610 minecraft:black_concrete
setblock 191 247 607 minecraft:light[level=14]
setblock 191 247 615 minecraft:light[level=14]
setblock 191 247 623 minecraft:light[level=14]
setblock 191 247 631 minecraft:light[level=14]
setblock 191 247 639 minecraft:light[level=14]
setblock 199 247 607 minecraft:light[level=14]
setblock 199 247 615 minecraft:light[level=14]
setblock 199 247 623 minecraft:light[level=14]
setblock 199 247 631 minecraft:light[level=14]
setblock 199 247 639 minecraft:light[level=14]
fill 206 247 610 206 253 610 minecraft:black_concrete
setblock 207 247 607 minecraft:light[level=14]
fill 207 247 609 207 253 609 minecraft:black_concrete
fill 207 247 611 208 253 611 minecraft:black_concrete
setblock 207 247 615 minecraft:light[level=14]
setblock 207 247 623 minecraft:light[level=14]
setblock 207 247 631 minecraft:light[level=14]
setblock 207 247 639 minecraft:light[level=14]
setblock 215 247 607 minecraft:light[level=14]
setblock 215 247 615 minecraft:light[level=14]
setblock 215 247 623 minecraft:light[level=14]
setblock 215 247 631 minecraft:light[level=14]
setblock 215 247 639 minecraft:light[level=14]
setblock 223 247 607 minecraft:light[level=14]
setblock 223 247 615 minecraft:light[level=14]
setblock 223 247 623 minecraft:light[level=14]
setblock 223 247 631 minecraft:light[level=14]
setblock 223 247 639 minecraft:light[level=14]
fill 188 248 609 188 255 609 minecraft:lime_concrete
fill 188 248 617 188 255 617 minecraft:lime_concrete
fill 188 248 625 188 255 625 minecraft:lime_concrete
fill 188 248 633 188 255 633 minecraft:lime_concrete
fill 188 248 641 188 255 641 minecraft:lime_concrete
fill 191 248 646 191 255 646 minecraft:lime_concrete
fill 195 248 604 195 255 604 minecraft:lime_concrete
fill 199 248 646 199 255 646 minecraft:lime_concrete
fill 203 248 604 203 255 604 minecraft:lime_concrete
fill 206 248 609 206 253 609 minecraft:black_concrete
fill 206 248 611 206 253 611 minecraft:black_concrete
fill 207 248 646 207 255 646 minecraft:lime_concrete
fill 208 248 609 208 253 609 minecraft:black_concrete
fill 209 248 610 209 253 610 minecraft:black_concrete
fill 211 248 604 211 255 604 minecraft:lime_concrete
fill 215 248 646 215 255 646 minecraft:lime_concrete
fill 219 248 604 219 255 604 minecraft:lime_concrete
fill 223 248 646 223 255 646 minecraft:lime_concrete
fill 227 248 604 227 255 604 minecraft:lime_concrete
fill 230 248 609 230 255 609 minecraft:lime_concrete
fill 230 248 617 230 255 617 minecraft:lime_concrete
fill 230 248 625 230 255 625 minecraft:lime_concrete
fill 230 248 633 230 255 633 minecraft:lime_concrete
fill 230 248 641 230 255 641 minecraft:lime_concrete
fill 205 249 610 205 253 610 minecraft:black_concrete
fill 207 249 608 208 253 608 minecraft:black_concrete
fill 207 249 612 208 253 612 minecraft:black_concrete
fill 209 249 609 209 253 609 minecraft:black_concrete
fill 209 249 611 209 253 611 minecraft:black_concrete
fill 198 250 620 199 251 621 minecraft:cyan_concrete
fill 205 250 609 205 253 609 minecraft:black_concrete
fill 205 250 611 205 253 611 minecraft:black_concrete
fill 206 250 608 206 253 608 minecraft:black_concrete
fill 206 250 612 206 253 612 minecraft:black_concrete
fill 209 250 608 209 253 608 minecraft:black_concrete
fill 209 250 612 209 253 612 minecraft:black_concrete
fill 204 251 610 204 253 610 minecraft:black_concrete
fill 205 251 608 205 253 608 minecraft:black_concrete
fill 205 251 612 205 253 612 minecraft:black_concrete
fill 206 251 613 208 253 613 minecraft:black_concrete
fill 207 251 607 208 253 607 minecraft:black_concrete
fill 210 251 609 210 253 611 minecraft:black_concrete
fill 218 251 620 219 252 621 minecraft:yellow_concrete
fill 189 252 605 189 253 610 minecraft:black_concrete
fill 189 252 613 190 252 618 minecraft:black_concrete
fill 189 252 621 190 252 626 minecraft:black_concrete
fill 189 252 629 190 252 634 minecraft:black_concrete
fill 189 252 637 190 252 642 minecraft:black_concrete
fill 189 252 645 194 253 645 minecraft:black_concrete
fill 190 252 606 190 252 612 minecraft:black_concrete
fill 190 252 619 190 252 620 minecraft:black_concrete
fill 190 252 627 190 252 628 minecraft:black_concrete
fill 190 252 635 190 252 636 minecraft:black_concrete
fill 190 252 643 190 252 644 minecraft:black_concrete
fill 191 252 606 228 252 606 minecraft:black_concrete
fill 191 252 644 229 252 644 minecraft:black_concrete
fill 192 252 605 197 253 605 minecraft:black_concrete
fill 197 252 645 202 253 645 minecraft:black_concrete
fill 200 252 605 205 253 605 minecraft:black_concrete
fill 204 252 609 204 253 609 minecraft:black_concrete
fill 204 252 611 204 253 611 minecraft:black_concrete
fill 205 252 613 205 253 613 minecraft:black_concrete
fill 205 252 645 210 253 645 minecraft:black_concrete
fill 206 252 607 206 253 607 minecraft:black_concrete
fill 208 252 605 213 253 605 minecraft:black_concrete
fill 209 252 607 209 253 607 minecraft:black_concrete
fill 209 252 613 209 253 613 minecraft:black_concrete
fill 210 252 608 210 253 608 minecraft:black_concrete
fill 210 252 612 210 253 612 minecraft:black_concrete
fill 213 252 645 218 253 645 minecraft:black_concrete
fill 216 252 605 221 253 605 minecraft:black_concrete
fill 221 252 645 226 253 645 minecraft:black_concrete
fill 224 252 605 229 253 605 minecraft:black_concrete
fill 228 252 607 228 252 643 minecraft:black_concrete
fill 229 252 608 229 253 613 minecraft:black_concrete
fill 229 252 616 229 253 621 minecraft:black_concrete
fill 229 252 624 229 253 629 minecraft:black_concrete
fill 229 252 632 229 253 637 minecraft:black_concrete
fill 229 252 640 229 253 643 minecraft:black_concrete
fill 229 252 645 229 253 645 minecraft:black_concrete
fill 189 253 613 189 253 618 minecraft:black_concrete
fill 189 253 621 189 253 626 minecraft:black_concrete
fill 189 253 629 189 253 634 minecraft:black_concrete
fill 189 253 637 189 253 642 minecraft:black_concrete
setblock 204 253 608 minecraft:black_concrete
setblock 204 253 612 minecraft:black_concrete
setblock 205 253 607 minecraft:black_concrete
fill 206 253 614 208 253 614 minecraft:black_concrete
fill 207 253 606 208 253 606 minecraft:black_concrete
setblock 210 253 607 minecraft:black_concrete
setblock 210 253 613 minecraft:black_concrete
fill 211 253 609 211 253 611 minecraft:black_concrete
setblock 229 253 644 minecraft:black_concrete
fill 206 254 610 208 254 610 minecraft:white_stained_glass
setblock 207 254 609 minecraft:white_stained_glass
fill 207 254 611 208 254 611 minecraft:white_stained_glass
setblock 191 255 607 minecraft:light[level=14]
setblock 191 255 615 minecraft:light[level=14]
setblock 191 255 623 minecraft:light[level=14]
setblock 191 255 631 minecraft:light[level=14]
setblock 191 255 639 minecraft:light[level=14]
setblock 199 255 607 minecraft:light[level=14]
setblock 199 255 615 minecraft:light[level=14]
setblock 199 255 623 minecraft:light[level=14]
setblock 199 255 631 minecraft:light[level=14]
setblock 199 255 639 minecraft:light[level=14]
setblock 207 255 607 minecraft:light[level=14]
fill 207 255 610 207 255 611 minecraft:white_stained_glass
setblock 207 255 615 minecraft:light[level=14]
setblock 207 255 623 minecraft:light[level=14]
setblock 207 255 631 minecraft:light[level=14]
setblock 207 255 639 minecraft:light[level=14]
fill 208 255 610 208 256 610 minecraft:white_stained_glass
setblock 215 255 607 minecraft:light[level=14]
setblock 215 255 615 minecraft:light[level=14]
setblock 215 255 623 minecraft:light[level=14]
setblock 215 255 631 minecraft:light[level=14]
setblock 215 255 639 minecraft:light[level=14]
setblock 223 255 607 minecraft:light[level=14]
setblock 223 255 615 minecraft:light[level=14]
setblock 223 255 623 minecraft:light[level=14]
setblock 223 255 631 minecraft:light[level=14]
setblock 223 255 639 minecraft:light[level=14]
fill 225 255 624 225 256 624 minecraft:lime_concrete
fill 188 256 609 188 261 609 minecraft:sea_lantern
fill 188 256 617 188 261 617 minecraft:sea_lantern
fill 188 256 625 188 261 625 minecraft:sea_lantern
fill 188 256 633 188 261 633 minecraft:sea_lantern
fill 188 256 641 188 261 641 minecraft:sea_lantern
fill 191 256 646 191 261 646 minecraft:sea_lantern
fill 195 256 604 195 261 604 minecraft:sea_lantern
fill 199 256 646 199 261 646 minecraft:sea_lantern
fill 203 256 604 203 261 604 minecraft:sea_lantern
fill 207 256 610 207 258 610 minecraft:white_stained_glass
fill 207 256 646 207 261 646 minecraft:sea_lantern
fill 211 256 604 211 261 604 minecraft:sea_lantern
fill 215 256 646 215 261 646 minecraft:sea_lantern
fill 219 256 604 219 261 604 minecraft:sea_lantern
fill 223 256 646 223 261 646 minecraft:sea_lantern
fill 227 256 604 227 261 604 minecraft:sea_lantern
fill 230 256 609 230 261 609 minecraft:sea_lantern
fill 230 256 617 230 261 617 minecraft:sea_lantern
fill 230 256 625 230 261 625 minecraft:sea_lantern
fill 230 256 633 230 261 633 minecraft:sea_lantern
fill 230 256 641 230 261 641 minecraft:sea_lantern
fill 213 257 616 214 258 617 minecraft:lime_concrete
fill 227 258 620 227 259 620 minecraft:yellow_concrete
fill 188 262 609 188 269 609 minecraft:lime_concrete
fill 188 262 617 188 269 617 minecraft:lime_concrete
fill 188 262 625 188 269 625 minecraft:lime_concrete
fill 188 262 633 188 269 633 minecraft:lime_concrete
fill 188 262 641 188 269 641 minecraft:lime_concrete
fill 191 262 646 191 269 646 minecraft:lime_concrete
fill 195 262 604 195 269 604 minecraft:lime_concrete
fill 199 262 646 199 269 646 minecraft:lime_concrete
fill 203 262 604 203 269 604 minecraft:lime_concrete
fill 207 262 646 207 269 646 minecraft:lime_concrete
fill 211 262 604 211 269 604 minecraft:lime_concrete
fill 215 262 646 215 269 646 minecraft:lime_concrete
fill 219 262 604 219 269 604 minecraft:lime_concrete
fill 223 262 646 223 269 646 minecraft:lime_concrete
fill 227 262 604 227 269 604 minecraft:lime_concrete
fill 230 262 609 230 269 609 minecraft:lime_concrete
fill 230 262 617 230 269 617 minecraft:lime_concrete
fill 230 262 625 230 269 625 minecraft:lime_concrete
fill 230 262 633 230 269 633 minecraft:lime_concrete
fill 230 262 641 230 269 641 minecraft:lime_concrete
setblock 191 263 607 minecraft:light[level=14]
setblock 191 263 615 minecraft:light[level=14]
setblock 191 263 623 minecraft:light[level=14]
setblock 191 263 631 minecraft:light[level=14]
setblock 191 263 639 minecraft:light[level=14]
setblock 199 263 607 minecraft:light[level=14]
setblock 199 263 615 minecraft:light[level=14]
setblock 199 263 623 minecraft:light[level=14]
setblock 199 263 631 minecraft:light[level=14]
setblock 199 263 639 minecraft:light[level=14]
setblock 207 263 607 minecraft:light[level=14]
setblock 207 263 615 minecraft:light[level=14]
setblock 207 263 623 minecraft:light[level=14]
setblock 207 263 631 minecraft:light[level=14]
setblock 207 263 639 minecraft:light[level=14]
setblock 215 263 607 minecraft:light[level=14]
setblock 215 263 615 minecraft:light[level=14]
setblock 215 263 623 minecraft:light[level=14]
setblock 215 263 631 minecraft:light[level=14]
setblock 215 263 639 minecraft:light[level=14]
fill 220 263 622 220 264 623 minecraft:cyan_concrete
setblock 223 263 607 minecraft:light[level=14]
setblock 223 263 615 minecraft:light[level=14]
setblock 223 263 623 minecraft:light[level=14]
setblock 223 263 631 minecraft:light[level=14]
setblock 223 263 639 minecraft:light[level=14]
fill 189 266 605 189 267 610 minecraft:black_concrete
fill 189 266 613 190 266 618 minecraft:black_concrete
fill 189 266 621 190 266 626 minecraft:black_concrete
fill 189 266 629 190 266 634 minecraft:black_concrete
fill 189 266 637 190 266 642 minecraft:black_concrete
fill 189 266 645 194 267 645 minecraft:black_concrete
fill 190 266 606 190 266 612 minecraft:black_concrete
fill 190 266 619 190 266 620 minecraft:black_concrete
fill 190 266 627 190 266 628 minecraft:black_concrete
fill 190 266 635 190 266 636 minecraft:black_concrete
fill 190 266 643 190 266 644 minecraft:black_concrete
fill 191 266 606 228 266 606 minecraft:black_concrete
fill 191 266 644 229 266 644 minecraft:black_concrete
fill 192 266 605 197 267 605 minecraft:black_concrete
fill 197 266 645 202 267 645 minecraft:black_concrete
fill 200 266 605 205 267 605 minecraft:black_concrete
fill 205 266 645 210 267 645 minecraft:black_concrete
fill 208 266 605 213 267 605 minecraft:black_concrete
fill 213 266 645 218 267 645 minecraft:black_concrete
fill 216 266 605 221 267 605 minecraft:black_concrete
fill 221 266 645 226 267 645 minecraft:black_concrete
fill 224 266 605 229 267 605 minecraft:black_concrete
fill 228 266 607 228 266 643 minecraft:black_concrete
fill 229 266 608 229 267 613 minecraft:black_concrete
fill 229 266 616 229 267 621 minecraft:black_concrete
fill 229 266 624 229 267 629 minecraft:black_concrete
fill 229 266 632 229 267 637 minecraft:black_concrete
fill 229 266 640 229 267 643 minecraft:black_concrete
fill 229 266 645 229 267 645 minecraft:black_concrete
fill 189 267 613 189 267 618 minecraft:black_concrete
fill 189 267 621 189 267 626 minecraft:black_concrete
fill 189 267 629 189 267 634 minecraft:black_concrete
fill 189 267 637 189 267 642 minecraft:black_concrete
setblock 229 267 644 minecraft:black_concrete
fill 202 268 616 202 269 616 minecraft:yellow_concrete
fill 188 270 609 188 273 609 minecraft:sea_lantern
fill 188 270 617 188 273 617 minecraft:sea_lantern
fill 188 270 625 188 273 625 minecraft:sea_lantern
fill 188 270 633 188 273 633 minecraft:sea_lantern
fill 188 270 641 188 273 641 minecraft:sea_lantern
fill 191 270 646 191 273 646 minecraft:sea_lantern
fill 195 270 604 195 273 604 minecraft:sea_lantern
fill 199 270 646 199 273 646 minecraft:sea_lantern
fill 203 270 604 203 273 604 minecraft:sea_lantern
fill 207 270 646 207 273 646 minecraft:sea_lantern
fill 211 270 604 211 273 604 minecraft:sea_lantern
fill 215 270 646 215 273 646 minecraft:sea_lantern
fill 218 270 630 220 271 631 minecraft:yellow_concrete
fill 219 270 604 219 273 604 minecraft:sea_lantern
fill 223 270 646 223 273 646 minecraft:sea_lantern
fill 227 270 604 227 273 604 minecraft:sea_lantern
fill 230 270 609 230 273 609 minecraft:sea_lantern
fill 230 270 617 230 273 617 minecraft:sea_lantern
fill 230 270 625 230 273 625 minecraft:sea_lantern
fill 230 270 633 230 273 633 minecraft:sea_lantern
fill 230 270 641 230 273 641 minecraft:sea_lantern
setblock 191 271 607 minecraft:light[level=14]
setblock 191 271 615 minecraft:light[level=14]
setblock 191 271 623 minecraft:light[level=14]
setblock 191 271 631 minecraft:light[level=14]
setblock 191 271 639 minecraft:light[level=14]
setblock 199 271 607 minecraft:light[level=14]
setblock 199 271 615 minecraft:light[level=14]
setblock 199 271 623 minecraft:light[level=14]
setblock 199 271 631 minecraft:light[level=14]
setblock 199 271 639 minecraft:light[level=14]
setblock 207 271 607 minecraft:light[level=14]
setblock 207 271 615 minecraft:light[level=14]
setblock 207 271 623 minecraft:light[level=14]
setblock 207 271 631 minecraft:light[level=14]
setblock 207 271 639 minecraft:light[level=14]
setblock 215 271 607 minecraft:light[level=14]
setblock 215 271 615 minecraft:light[level=14]
setblock 215 271 623 minecraft:light[level=14]
setblock 215 271 631 minecraft:light[level=14]
setblock 215 271 639 minecraft:light[level=14]
setblock 223 271 607 minecraft:light[level=14]
setblock 223 271 615 minecraft:light[level=14]
setblock 223 271 623 minecraft:light[level=14]
setblock 223 271 631 minecraft:light[level=14]
setblock 223 271 639 minecraft:light[level=14]
fill 188 274 609 188 283 609 minecraft:lime_concrete
fill 188 274 617 188 283 617 minecraft:lime_concrete
fill 188 274 625 188 283 625 minecraft:lime_concrete
fill 188 274 633 188 283 633 minecraft:lime_concrete
fill 188 274 641 188 283 641 minecraft:lime_concrete
fill 191 274 646 191 283 646 minecraft:lime_concrete
fill 195 274 604 195 283 604 minecraft:lime_concrete
fill 199 274 646 199 283 646 minecraft:lime_concrete
fill 203 274 604 203 283 604 minecraft:lime_concrete
fill 207 274 646 207 283 646 minecraft:lime_concrete
fill 211 274 604 211 283 604 minecraft:lime_concrete
fill 215 274 646 215 283 646 minecraft:lime_concrete
fill 219 274 604 219 283 604 minecraft:lime_concrete
fill 223 274 646 223 283 646 minecraft:lime_concrete
fill 227 274 604 227 283 604 minecraft:lime_concrete
fill 230 274 609 230 283 609 minecraft:lime_concrete
fill 230 274 617 230 283 617 minecraft:lime_concrete
fill 230 274 625 230 283 625 minecraft:lime_concrete
fill 230 274 633 230 283 633 minecraft:lime_concrete
fill 230 274 641 230 283 641 minecraft:lime_concrete
fill 206 278 624 208 278 626 minecraft:redstone_block
fill 211 278 630 213 278 632 minecraft:redstone_block
fill 214 278 621 216 278 623 minecraft:redstone_block
fill 189 279 605 190 280 607 minecraft:lime_concrete
fill 189 279 608 190 280 610 minecraft:black_concrete
fill 189 279 611 190 280 613 minecraft:lime_concrete
fill 189 279 614 190 280 616 minecraft:black_concrete
fill 189 279 617 190 280 619 minecraft:lime_concrete
fill 189 279 620 190 280 622 minecraft:black_concrete
fill 189 279 623 190 280 625 minecraft:lime_concrete
fill 189 279 626 190 280 628 minecraft:black_concrete
fill 189 279 629 190 280 631 minecraft:lime_concrete
fill 189 279 632 190 280 634 minecraft:black_concrete
fill 189 279 635 190 280 637 minecraft:lime_concrete
fill 189 279 638 190 280 640 minecraft:black_concrete
fill 189 279 641 190 280 643 minecraft:lime_concrete
fill 189 279 644 190 280 645 minecraft:black_concrete
fill 191 279 605 193 280 607 minecraft:black_concrete
fill 191 279 608 193 280 610 minecraft:lime_concrete
fill 191 279 611 193 280 613 minecraft:black_concrete
fill 191 279 614 193 280 616 minecraft:lime_concrete
fill 191 279 617 193 280 619 minecraft:black_concrete
fill 191 279 620 193 280 622 minecraft:lime_concrete
fill 191 279 623 193 280 625 minecraft:black_concrete
fill 191 279 626 193 280 628 minecraft:lime_concrete
fill 191 279 629 193 280 631 minecraft:black_concrete
fill 191 279 632 193 280 634 minecraft:lime_concrete
fill 191 279 635 193 280 637 minecraft:black_concrete
fill 191 279 638 193 280 640 minecraft:lime_concrete
fill 191 279 641 193 280 643 minecraft:black_concrete
fill 191 279 644 193 280 645 minecraft:lime_concrete
fill 194 279 605 196 280 607 minecraft:lime_concrete
fill 194 279 608 196 280 610 minecraft:black_concrete
fill 194 279 611 196 280 613 minecraft:lime_concrete
fill 194 279 614 196 280 616 minecraft:black_concrete
fill 194 279 617 196 280 619 minecraft:lime_concrete
fill 194 279 620 196 280 622 minecraft:black_concrete
fill 194 279 623 196 280 625 minecraft:lime_concrete
fill 194 279 626 196 280 628 minecraft:black_concrete
fill 194 279 629 196 280 631 minecraft:lime_concrete
fill 194 279 632 196 280 634 minecraft:black_concrete
fill 194 279 635 196 280 637 minecraft:lime_concrete
fill 194 279 638 196 280 640 minecraft:black_concrete
fill 194 279 641 196 280 643 minecraft:lime_concrete
fill 194 279 644 196 280 645 minecraft:black_concrete
fill 197 279 605 199 280 607 minecraft:black_concrete
fill 197 279 608 199 280 610 minecraft:lime_concrete
fill 197 279 611 199 280 613 minecraft:black_concrete
fill 197 279 614 199 280 616 minecraft:lime_concrete
fill 197 279 617 199 280 619 minecraft:black_concrete
fill 197 279 620 199 280 622 minecraft:lime_concrete
fill 197 279 623 199 280 625 minecraft:black_concrete
fill 197 279 626 199 280 628 minecraft:lime_concrete
fill 197 279 629 199 280 631 minecraft:black_concrete
fill 197 279 632 199 280 634 minecraft:lime_concrete
fill 197 279 635 199 280 637 minecraft:black_concrete
fill 197 279 638 199 280 640 minecraft:lime_concrete
fill 197 279 641 199 280 643 minecraft:black_concrete
fill 197 279 644 199 280 645 minecraft:lime_concrete
fill 200 279 605 202 280 607 minecraft:lime_concrete
fill 200 279 608 202 280 610 minecraft:black_concrete
fill 200 279 611 202 280 613 minecraft:lime_concrete
fill 200 279 614 202 280 616 minecraft:black_concrete
fill 200 279 617 202 280 619 minecraft:lime_concrete
fill 200 279 620 202 280 622 minecraft:black_concrete
fill 200 279 623 202 280 625 minecraft:lime_concrete
fill 200 279 626 202 280 628 minecraft:black_concrete
fill 200 279 629 202 280 631 minecraft:lime_concrete
fill 200 279 632 202 280 634 minecraft:black_concrete
fill 200 279 635 202 280 637 minecraft:lime_concrete
fill 200 279 638 202 280 640 minecraft:black_concrete
fill 200 279 641 202 280 643 minecraft:lime_concrete
fill 200 279 644 202 280 645 minecraft:black_concrete
fill 203 279 605 205 280 607 minecraft:black_concrete
fill 203 279 608 205 280 610 minecraft:lime_concrete
fill 203 279 611 205 280 613 minecraft:black_concrete
fill 203 279 614 205 280 616 minecraft:lime_concrete
fill 203 279 617 205 280 619 minecraft:black_concrete
fill 203 279 620 205 280 622 minecraft:lime_concrete
fill 203 279 623 205 279 625 minecraft:black_concrete
fill 203 279 626 205 279 628 minecraft:lime_concrete
fill 203 279 629 205 280 631 minecraft:black_concrete
fill 203 279 632 205 280 634 minecraft:lime_concrete
fill 203 279 635 205 280 637 minecraft:black_concrete
fill 203 279 638 205 280 640 minecraft:lime_concrete
fill 203 279 641 205 280 643 minecraft:black_concrete
fill 203 279 644 205 280 645 minecraft:lime_concrete
fill 206 279 605 208 280 607 minecraft:lime_concrete
fill 206 279 608 208 280 610 minecraft:black_concrete
fill 206 279 611 208 280 613 minecraft:lime_concrete
fill 206 279 614 208 280 616 minecraft:black_concrete
fill 206 279 617 208 280 619 minecraft:lime_concrete
fill 206 279 620 208 280 622 minecraft:black_concrete
fill 206 279 623 208 279 623 minecraft:lime_concrete
fill 206 279 627 208 279 628 minecraft:black_concrete
fill 206 279 629 208 280 631 minecraft:lime_concrete
fill 206 279 632 208 280 634 minecraft:black_concrete
fill 206 279 635 208 280 637 minecraft:lime_concrete
fill 206 279 638 208 280 640 minecraft:black_concrete
fill 206 279 641 208 280 643 minecraft:lime_concrete
fill 206 279 644 208 280 645 minecraft:black_concrete
fill 209 279 605 211 280 607 minecraft:black_concrete
fill 209 279 608 211 280 610 minecraft:lime_concrete
fill 209 279 611 211 280 613 minecraft:black_concrete
fill 209 279 614 211 280 616 minecraft:lime_concrete
fill 209 279 617 211 280 619 minecraft:black_concrete
fill 209 279 620 211 280 622 minecraft:lime_concrete
fill 209 279 623 210 279 625 minecraft:black_concrete
fill 209 279 626 210 279 628 minecraft:lime_concrete
fill 209 279 629 210 279 631 minecraft:black_concrete
fill 209 279 632 210 279 634 minecraft:lime_concrete
fill 209 279 635 211 280 637 minecraft:black_concrete
fill 209 279 638 211 280 640 minecraft:lime_concrete
fill 209 279 641 211 280 643 minecraft:black_concrete
fill 209 279 644 211 280 645 minecraft:lime_concrete
fill 211 279 623 211 279 624 minecraft:black_concrete
setblock 211 279 628 minecraft:lime_concrete
setblock 211 279 629 minecraft:black_concrete
fill 211 279 633 211 279 634 minecraft:lime_concrete
fill 212 279 605 214 280 607 minecraft:lime_concrete
fill 212 279 608 214 280 610 minecraft:black_concrete
fill 212 279 611 214 280 613 minecraft:lime_concrete
fill 212 279 614 214 280 616 minecraft:black_concrete
fill 212 279 617 214 280 619 minecraft:lime_concrete
fill 212 279 620 213 279 622 minecraft:black_concrete
fill 212 279 623 213 279 624 minecraft:lime_concrete
fill 212 279 628 214 279 628 minecraft:black_concrete
fill 212 279 629 214 279 629 minecraft:lime_concrete
fill 212 279 633 214 279 634 minecraft:black_concrete
fill 212 279 635 214 280 637 minecraft:lime_concrete
fill 212 279 638 214 280 640 minecraft:black_concrete
fill 212 279 641 214 280 643 minecraft:lime_concrete
fill 212 279 644 214 280 645 minecraft:black_concrete
setblock 214 279 620 minecraft:black_concrete
fill 214 279 624 214 279 625 minecraft:lime_concrete
fill 214 279 626 214 279 627 minecraft:black_concrete
fill 214 279 630 214 279 631 minecraft:lime_concrete
setblock 214 279 632 minecraft:black_concrete
fill 215 279 605 217 280 607 minecraft:black_concrete
fill 215 279 608 217 280 610 minecraft:lime_concrete
fill 215 279 611 217 280 613 minecraft:black_concrete
fill 215 279 614 217 280 616 minecraft:lime_concrete
fill 215 279 617 217 280 619 minecraft:black_concrete
fill 215 279 620 217 279 620 minecraft:lime_concrete
setblock 215 279 623 minecraft:light[level=14]
fill 215 279 624 217 279 625 minecraft:black_concrete
fill 215 279 626 217 280 628 minecraft:lime_concrete
fill 215 279 629 217 280 631 minecraft:black_concrete
fill 215 279 632 217 280 634 minecraft:lime_concrete
fill 215 279 635 217 280 637 minecraft:black_concrete
fill 215 279 638 217 280 640 minecraft:lime_concrete
fill 215 279 641 217 280 643 minecraft:black_concrete
fill 215 279 644 217 280 645 minecraft:lime_concrete
fill 217 279 621 217 279 622 minecraft:lime_concrete
setblock 217 279 623 minecraft:black_concrete
fill 218 279 605 220 280 607 minecraft:lime_concrete
fill 218 279 608 220 280 610 minecraft:black_concrete
fill 218 279 611 220 280 613 minecraft:lime_concrete
fill 218 279 614 220 280 616 minecraft:black_concrete
fill 218 279 617 220 280 619 minecraft:lime_concrete
fill 218 279 620 220 280 622 minecraft:black_concrete
fill 218 279 623 220 280 625 minecraft:lime_concrete
fill 218 279 626 220 280 628 minecraft:black_concrete
fill 218 279 629 220 280 631 minecraft:lime_concrete
fill 218 279 632 220 280 634 minecraft:black_concrete
fill 218 279 635 220 280 637 minecraft:lime_concrete
fill 218 279 638 220 280 640 minecraft:black_concrete
fill 218 279 641 220 280 643 minecraft:lime_concrete
fill 218 279 644 220 280 645 minecraft:black_concrete
fill 221 279 605 223 280 607 minecraft:black_concrete
fill 221 279 608 223 280 610 minecraft:lime_concrete
fill 221 279 611 223 280 613 minecraft:black_concrete
fill 221 279 614 223 280 616 minecraft:lime_concrete
fill 221 279 617 223 280 619 minecraft:black_concrete
fill 221 279 620 223 280 622 minecraft:lime_concrete
fill 221 279 623 223 280 625 minecraft:black_concrete
fill 221 279 626 223 280 628 minecraft:lime_concrete
fill 221 279 629 223 280 631 minecraft:black_concrete
fill 221 279 632 223 280 634 minecraft:lime_concrete
fill 221 279 635 223 280 637 minecraft:black_concrete
fill 221 279 638 223 280 640 minecraft:lime_concrete
fill 221 279 641 223 280 643 minecraft:black_concrete
fill 221 279 644 223 280 645 minecraft:lime_concrete
fill 224 279 605 226 280 607 minecraft:lime_concrete
fill 224 279 608 226 280 610 minecraft:black_concrete
fill 224 279 611 226 280 613 minecraft:lime_concrete
fill 224 279 614 226 280 616 minecraft:black_concrete
fill 224 279 617 226 280 619 minecraft:lime_concrete
fill 224 279 620 226 280 622 minecraft:black_concrete
fill 224 279 623 226 280 625 minecraft:lime_concrete
fill 224 279 626 226 280 628 minecraft:black_concrete
fill 224 279 629 226 280 631 minecraft:lime_concrete
fill 224 279 632 226 280 634 minecraft:black_concrete
fill 224 279 635 226 280 637 minecraft:lime_concrete
fill 224 279 638 226 280 640 minecraft:black_concrete
fill 224 279 641 226 280 643 minecraft:lime_concrete
fill 224 279 644 226 280 645 minecraft:black_concrete
fill 227 279 605 229 280 607 minecraft:black_concrete
fill 227 279 608 229 280 610 minecraft:lime_concrete
fill 227 279 611 229 280 613 minecraft:black_concrete
fill 227 279 614 229 280 616 minecraft:lime_concrete
fill 227 279 617 229 280 619 minecraft:black_concrete
fill 227 279 620 229 280 622 minecraft:lime_concrete
fill 227 279 623 229 280 625 minecraft:black_concrete
fill 227 279 626 229 280 628 minecraft:lime_concrete
fill 227 279 629 229 280 631 minecraft:black_concrete
fill 227 279 632 229 280 634 minecraft:lime_concrete
fill 227 279 635 229 280 637 minecraft:black_concrete
fill 227 279 638 229 280 640 minecraft:lime_concrete
fill 227 279 641 229 280 643 minecraft:black_concrete
fill 227 279 644 229 280 645 minecraft:lime_concrete
fill 203 280 623 204 280 625 minecraft:black_concrete
fill 203 280 626 204 280 628 minecraft:lime_concrete
fill 205 280 623 205 280 627 minecraft:sea_lantern
setblock 205 280 628 minecraft:lime_concrete
fill 206 280 623 209 280 623 minecraft:sea_lantern
fill 206 280 624 208 280 626 minecraft:lime_concrete
fill 206 280 627 210 280 627 minecraft:sea_lantern
fill 206 280 628 208 280 628 minecraft:black_concrete
fill 209 280 624 210 280 626 minecraft:sea_lantern
setblock 209 280 628 minecraft:lime_concrete
fill 209 280 629 209 280 631 minecraft:black_concrete
fill 209 280 632 209 280 634 minecraft:lime_concrete
fill 210 280 623 211 280 623 minecraft:black_concrete
fill 210 280 628 210 280 633 minecraft:sea_lantern
fill 210 280 634 211 280 634 minecraft:lime_concrete
fill 211 280 624 217 280 624 minecraft:sea_lantern
fill 211 280 628 214 280 629 minecraft:sea_lantern
fill 211 280 630 213 280 632 minecraft:lime_concrete
fill 211 280 633 214 280 633 minecraft:sea_lantern
fill 212 280 620 212 280 622 minecraft:black_concrete
setblock 212 280 623 minecraft:lime_concrete
fill 212 280 634 214 280 634 minecraft:black_concrete
fill 213 280 620 213 280 623 minecraft:sea_lantern
fill 214 280 620 217 280 620 minecraft:sea_lantern
fill 214 280 621 216 280 623 minecraft:lime_concrete
fill 214 280 625 214 280 627 minecraft:sea_lantern
fill 214 280 630 214 280 632 minecraft:sea_lantern
fill 215 280 625 217 280 625 minecraft:black_concrete
fill 217 280 621 217 280 623 minecraft:sea_lantern
fill 188 284 609 188 289 609 minecraft:sea_lantern
fill 188 284 617 188 289 617 minecraft:sea_lantern
fill 188 284 625 188 289 625 minecraft:sea_lantern
fill 188 284 633 188 289 633 minecraft:sea_lantern
fill 188 284 641 188 289 641 minecraft:sea_lantern
fill 189 284 611 189 300 612 minecraft:black_concrete
fill 189 284 619 189 300 620 minecraft:black_concrete
fill 189 284 627 189 300 628 minecraft:black_concrete
fill 189 284 635 189 300 636 minecraft:black_concrete
fill 189 284 643 189 300 644 minecraft:black_concrete
fill 190 284 605 191 300 605 minecraft:black_concrete
fill 191 284 646 191 289 646 minecraft:sea_lantern
fill 195 284 604 195 289 604 minecraft:sea_lantern
fill 195 284 645 196 300 645 minecraft:black_concrete
fill 198 284 605 199 300 605 minecraft:black_concrete
fill 199 284 646 199 289 646 minecraft:sea_lantern
fill 203 284 604 203 289 604 minecraft:sea_lantern
fill 203 284 641 211 285 645 minecraft:black_concrete
fill 206 284 605 207 300 605 minecraft:black_concrete
fill 207 284 646 207 289 646 minecraft:sea_lantern
fill 211 284 604 211 289 604 minecraft:sea_lantern
fill 212 284 645 212 300 645 minecraft:black_concrete
fill 214 284 605 215 300 605 minecraft:black_concrete
fill 215 284 646 215 289 646 minecraft:sea_lantern
fill 219 284 604 219 289 604 minecraft:sea_lantern
fill 219 284 645 220 300 645 minecraft:black_concrete
fill 222 284 605 223 300 605 minecraft:black_concrete
fill 223 284 646 223 289 646 minecraft:sea_lantern
fill 227 284 604 227 289 604 minecraft:sea_lantern
fill 227 284 645 228 300 645 minecraft:black_concrete
fill 229 284 606 229 300 607 minecraft:black_concrete
fill 229 284 614 229 300 615 minecraft:black_concrete
fill 229 284 622 229 300 623 minecraft:black_concrete
fill 229 284 630 229 300 631 minecraft:black_concrete
fill 229 284 638 229 300 639 minecraft:black_concrete
fill 230 284 609 230 289 609 minecraft:sea_lantern
fill 230 284 617 230 289 617 minecraft:sea_lantern
fill 230 284 625 230 289 625 minecraft:sea_lantern
fill 230 284 633 230 289 633 minecraft:sea_lantern
fill 230 284 641 230 289 641 minecraft:sea_lantern
fill 219 285 614 219 286 614 minecraft:white_stained_glass
setblock 203 286 641 minecraft:sea_lantern
fill 203 286 642 203 300 642 minecraft:black_concrete
setblock 203 286 643 minecraft:sea_lantern
fill 203 286 644 203 300 644 minecraft:black_concrete
setblock 203 286 645 minecraft:sea_lantern
fill 204 286 641 204 300 641 minecraft:black_concrete
setblock 204 286 642 minecraft:sea_lantern
fill 204 286 643 204 300 643 minecraft:black_concrete
setblock 204 286 644 minecraft:sea_lantern
fill 204 286 645 204 300 645 minecraft:black_concrete
setblock 205 286 641 minecraft:sea_lantern
fill 205 286 642 205 300 642 minecraft:black_concrete
setblock 205 286 643 minecraft:sea_lantern
fill 205 286 644 205 300 644 minecraft:black_concrete
setblock 205 286 645 minecraft:sea_lantern
fill 206 286 641 206 300 641 minecraft:black_concrete
setblock 206 286 642 minecraft:sea_lantern
fill 206 286 643 206 300 643 minecraft:black_concrete
setblock 206 286 644 minecraft:sea_lantern
fill 206 286 645 206 300 645 minecraft:black_concrete
setblock 207 286 641 minecraft:sea_lantern
fill 207 286 642 207 300 642 minecraft:black_concrete
setblock 207 286 643 minecraft:sea_lantern
fill 207 286 644 207 300 644 minecraft:black_concrete
setblock 207 286 645 minecraft:sea_lantern
fill 208 286 641 208 300 641 minecraft:black_concrete
setblock 208 286 642 minecraft:sea_lantern
fill 208 286 643 208 300 643 minecraft:black_concrete
setblock 208 286 644 minecraft:sea_lantern
fill 208 286 645 208 300 645 minecraft:black_concrete
setblock 209 286 641 minecraft:sea_lantern
fill 209 286 642 209 300 642 minecraft:black_concrete
setblock 209 286 643 minecraft:sea_lantern
fill 209 286 644 209 300 644 minecraft:black_concrete
setblock 209 286 645 minecraft:sea_lantern
fill 210 286 641 210 300 641 minecraft:black_concrete
setblock 210 286 642 minecraft:sea_lantern
fill 210 286 643 210 300 643 minecraft:black_concrete
setblock 210 286 644 minecraft:sea_lantern
fill 210 286 645 210 300 645 minecraft:black_concrete
setblock 211 286 641 minecraft:sea_lantern
fill 211 286 642 211 300 642 minecraft:black_concrete
setblock 211 286 643 minecraft:sea_lantern
fill 211 286 644 211 300 644 minecraft:black_concrete
setblock 211 286 645 minecraft:sea_lantern
setblock 191 287 607 minecraft:light[level=14]
setblock 191 287 615 minecraft:light[level=14]
setblock 191 287 623 minecraft:light[level=14]
setblock 191 287 631 minecraft:light[level=14]
setblock 191 287 639 minecraft:light[level=14]
setblock 199 287 607 minecraft:light[level=14]
setblock 199 287 615 minecraft:light[level=14]
setblock 199 287 623 minecraft:light[level=14]
setblock 199 287 631 minecraft:light[level=14]
setblock 199 287 639 minecraft:light[level=14]
fill 203 287 641 203 288 641 minecraft:black_concrete
fill 203 287 643 203 288 643 minecraft:black_concrete
fill 203 287 645 203 288 645 minecraft:black_concrete
fill 204 287 642 204 288 642 minecraft:black_concrete
fill 204 287 644 204 288 644 minecraft:black_concrete
fill 205 287 641 205 288 641 minecraft:black_concrete
fill 205 287 643 205 288 643 minecraft:black_concrete
fill 205 287 645 205 288 645 minecraft:black_concrete
fill 206 287 642 206 288 642 minecraft:black_concrete
fill 206 287 644 206 288 644 minecraft:black_concrete
setblock 207 287 607 minecraft:light[level=14]
setblock 207 287 615 minecraft:light[level=14]
setblock 207 287 623 minecraft:light[level=14]
setblock 207 287 631 minecraft:light[level=14]
setblock 207 287 639 minecraft:light[level=14]
fill 207 287 641 207 288 641 minecraft:black_concrete
fill 207 287 643 207 288 643 minecraft:black_concrete
fill 207 287 645 207 288 645 minecraft:black_concrete
fill 208 287 642 208 288 642 minecraft:black_concrete
fill 208 287 644 208 288 644 minecraft:black_concrete
fill 209 287 641 209 288 641 minecraft:black_concrete
fill 209 287 643 209 288 643 minecraft:black_concrete
fill 209 287 645 209 288 645 minecraft:black_concrete
fill 210 287 642 210 288 642 minecraft:black_concrete
fill 210 287 644 210 288 644 minecraft:black_concrete
fill 211 287 641 211 288 641 minecraft:black_concrete
fill 211 287 643 211 288 643 minecraft:black_concrete
fill 211 287 645 211 288 645 minecraft:black_concrete
setblock 215 287 607 minecraft:light[level=14]
setblock 215 287 615 minecraft:light[level=14]
setblock 215 287 623 minecraft:light[level=14]
setblock 215 287 631 minecraft:light[level=14]
setblock 215 287 639 minecraft:light[level=14]
fill 219 287 614 219 296 614 minecraft:black_concrete
setblock 223 287 607 minecraft:light[level=14]
setblock 223 287 615 minecraft:light[level=14]
setblock 223 287 623 minecraft:light[level=14]
setblock 223 287 631 minecraft:light[level=14]
setblock 223 287 639 minecraft:light[level=14]
setblock 203 289 641 minecraft:sea_lantern
setblock 203 289 643 minecraft:sea_lantern
setblock 203 289 645 minecraft:sea_lantern
setblock 204 289 642 minecraft:sea_lantern
setblock 204 289 644 minecraft:sea_lantern
setblock 205 289 641 minecraft:sea_lantern
setblock 205 289 643 minecraft:sea_lantern
setblock 205 289 645 minecraft:sea_lantern
setblock 206 289 642 minecraft:sea_lantern
setblock 206 289 644 minecraft:sea_lantern
setblock 207 289 641 minecraft:sea_lantern
setblock 207 289 643 minecraft:sea_lantern
setblock 207 289 645 minecraft:sea_lantern
setblock 208 289 642 minecraft:sea_lantern
setblock 208 289 644 minecraft:sea_lantern
setblock 209 289 641 minecraft:sea_lantern
setblock 209 289 643 minecraft:sea_lantern
setblock 209 289 645 minecraft:sea_lantern
setblock 210 289 642 minecraft:sea_lantern
setblock 210 289 644 minecraft:sea_lantern
setblock 211 289 641 minecraft:sea_lantern
setblock 211 289 643 minecraft:sea_lantern
setblock 211 289 645 minecraft:sea_lantern
fill 219 289 613 220 296 613 minecraft:black_concrete
fill 220 289 614 220 296 614 minecraft:black_concrete
fill 188 290 609 188 297 609 minecraft:lime_concrete
fill 188 290 617 188 297 617 minecraft:lime_concrete
fill 188 290 625 188 297 625 minecraft:lime_concrete
fill 188 290 633 188 297 633 minecraft:lime_concrete
fill 188 290 641 188 297 641 minecraft:lime_concrete
fill 191 290 646 191 297 646 minecraft:lime_concrete
fill 195 290 604 195 297 604 minecraft:lime_concrete
fill 199 290 616 200 291 617 minecraft:cyan_concrete
fill 199 290 646 199 297 646 minecraft:lime_concrete
fill 203 290 604 203 297 604 minecraft:lime_concrete
fill 203 290 641 203 291 641 minecraft:black_concrete
fill 203 290 643 203 291 643 minecraft:black_concrete
fill 203 290 645 203 291 645 minecraft:black_concrete
fill 204 290 642 204 291 642 minecraft:black_concrete
fill 204 290 644 204 291 644 minecraft:black_concrete
fill 205 290 641 205 291 641 minecraft:black_concrete
fill 205 290 643 205 291 643 minecraft:black_concrete
fill 205 290 645 205 291 645 minecraft:black_concrete
fill 206 290 642 206 291 642 minecraft:black_concrete
fill 206 290 644 206 291 644 minecraft:black_concrete
fill 207 290 641 207 291 641 minecraft:black_concrete
fill 207 290 643 207 291 643 minecraft:black_concrete
fill 207 290 645 207 291 645 minecraft:black_concrete
fill 207 290 646 207 297 646 minecraft:lime_concrete
fill 208 290 642 208 291 642 minecraft:black_concrete
fill 208 290 644 208 291 644 minecraft:black_concrete
fill 209 290 641 209 291 641 minecraft:black_concrete
fill 209 290 643 209 291 643 minecraft:black_concrete
fill 209 290 645 209 291 645 minecraft:black_concrete
fill 210 290 642 210 291 642 minecraft:black_concrete
fill 210 290 644 210 291 644 minecraft:black_concrete
fill 211 290 604 211 297 604 minecraft:lime_concrete
fill 211 290 641 211 291 641 minecraft:black_concrete
fill 211 290 643 211 291 643 minecraft:black_concrete
fill 211 290 645 211 291 645 minecraft:black_concrete
fill 215 290 646 215 297 646 minecraft:lime_concrete
fill 218 290 613 218 296 614 minecraft:black_concrete
fill 219 290 604 219 297 604 minecraft:lime_concrete
fill 219 290 615 220 296 615 minecraft:black_concrete
fill 223 290 646 223 297 646 minecraft:lime_concrete
fill 227 290 604 227 297 604 minecraft:lime_concrete
fill 230 290 609 230 297 609 minecraft:lime_concrete
fill 230 290 617 230 297 617 minecraft:lime_concrete
fill 230 290 625 230 297 625 minecraft:lime_concrete
fill 230 290 633 230 297 633 minecraft:lime_concrete
fill 230 290 641 230 297 641 minecraft:lime_concrete
fill 218 291 615 218 296 615 minecraft:black_concrete
fill 219 291 612 220 296 612 minecraft:black_concrete
fill 221 291 613 221 296 614 minecraft:black_concrete
setblock 203 292 641 minecraft:sea_lantern
setblock 203 292 643 minecraft:sea_lantern
setblock 203 292 645 minecraft:sea_lantern
setblock 204 292 642 minecraft:sea_lantern
setblock 204 292 644 minecraft:sea_lantern
setblock 205 292 641 minecraft:sea_lantern
setblock 205 292 643 minecraft:sea_lantern
setblock 205 292 645 minecraft:sea_lantern
setblock 206 292 642 minecraft:sea_lantern
setblock 206 292 644 minecraft:sea_lantern
setblock 207 292 641 minecraft:sea_lantern
setblock 207 292 643 minecraft:sea_lantern
setblock 207 292 645 minecraft:sea_lantern
setblock 208 292 642 minecraft:sea_lantern
setblock 208 292 644 minecraft:sea_lantern
setblock 209 292 641 minecraft:sea_lantern
setblock 209 292 643 minecraft:sea_lantern
setblock 209 292 645 minecraft:sea_lantern
setblock 210 292 642 minecraft:sea_lantern
setblock 210 292 644 minecraft:sea_lantern
setblock 211 292 641 minecraft:sea_lantern
setblock 211 292 643 minecraft:sea_lantern
setblock 211 292 645 minecraft:sea_lantern
fill 217 292 613 217 296 614 minecraft:black_concrete
fill 218 292 612 218 296 612 minecraft:black_concrete
fill 219 292 616 220 296 616 minecraft:black_concrete
fill 221 292 612 221 296 612 minecraft:black_concrete
fill 221 292 615 221 296 615 minecraft:black_concrete
fill 203 293 641 203 294 641 minecraft:black_concrete
fill 203 293 643 203 294 643 minecraft:black_concrete
fill 203 293 645 203 294 645 minecraft:black_concrete
fill 204 293 642 204 294 642 minecraft:black_concrete
fill 204 293 644 204 294 644 minecraft:black_concrete
fill 205 293 641 205 294 641 minecraft:black_concrete
fill 205 293 643 205 294 643 minecraft:black_concrete
fill 205 293 645 205 294 645 minecraft:black_concrete
fill 206 293 642 206 294 642 minecraft:black_concrete
fill 206 293 644 206 294 644 minecraft:black_concrete
fill 207 293 641 207 294 641 minecraft:black_concrete
fill 207 293 643 207 294 643 minecraft:black_concrete
fill 207 293 645 207 294 645 minecraft:black_concrete
fill 208 293 642 208 294 642 minecraft:black_concrete
fill 208 293 644 208 294 644 minecraft:black_concrete
fill 209 293 641 209 294 641 minecraft:black_concrete
fill 209 293 643 209 294 643 minecraft:black_concrete
fill 209 293 645 209 294 645 minecraft:black_concrete
fill 210 293 642 210 294 642 minecraft:black_concrete
fill 210 293 644 210 294 644 minecraft:black_concrete
fill 211 293 641 211 294 641 minecraft:black_concrete
fill 211 293 643 211 294 643 minecraft:black_concrete
fill 211 293 645 211 294 645 minecraft:black_concrete
fill 217 293 612 217 296 612 minecraft:black_concrete
fill 217 293 615 217 296 615 minecraft:black_concrete
fill 218 293 616 218 296 616 minecraft:black_concrete
fill 219 293 611 220 296 611 minecraft:black_concrete
fill 221 293 616 221 296 616 minecraft:black_concrete
fill 222 293 613 222 296 615 minecraft:black_concrete
fill 189 294 605 189 295 610 minecraft:black_concrete
fill 189 294 613 190 294 618 minecraft:black_concrete
fill 189 294 621 190 294 626 minecraft:black_concrete
fill 189 294 629 190 294 634 minecraft:black_concrete
fill 189 294 637 190 294 642 minecraft:black_concrete
fill 189 294 645 194 295 645 minecraft:black_concrete
fill 190 294 606 190 294 612 minecraft:black_concrete
fill 190 294 619 190 294 620 minecraft:black_concrete
fill 190 294 627 190 294 628 minecraft:black_concrete
fill 190 294 635 190 294 636 minecraft:black_concrete
fill 190 294 643 190 294 644 minecraft:black_concrete
fill 191 294 606 228 294 606 minecraft:black_concrete
fill 191 294 644 202 294 644 minecraft:black_concrete
fill 192 294 605 197 295 605 minecraft:black_concrete
fill 197 294 645 202 295 645 minecraft:black_concrete
fill 200 294 605 205 295 605 minecraft:black_concrete
fill 208 294 605 213 295 605 minecraft:black_concrete
fill 212 294 644 229 294 644 minecraft:black_concrete
fill 213 294 645 218 295 645 minecraft:black_concrete
fill 216 294 605 221 295 605 minecraft:black_concrete
fill 216 294 613 216 296 614 minecraft:black_concrete
fill 217 294 616 217 296 616 minecraft:black_concrete
fill 218 294 611 218 296 611 minecraft:black_concrete
fill 218 294 617 220 296 617 minecraft:black_concrete
fill 221 294 611 221 296 611 minecraft:black_concrete
fill 221 294 645 226 295 645 minecraft:black_concrete
fill 222 294 612 222 296 612 minecraft:black_concrete
fill 222 294 616 222 296 616 minecraft:black_concrete
fill 224 294 605 229 295 605 minecraft:black_concrete
fill 228 294 607 228 294 643 minecraft:black_concrete
fill 229 294 608 229 295 613 minecraft:black_concrete
fill 229 294 616 229 295 621 minecraft:black_concrete
fill 229 294 624 229 295 629 minecraft:black_concrete
fill 229 294 632 229 295 637 minecraft:black_concrete
fill 229 294 640 229 295 643 minecraft:black_concrete
fill 229 294 645 229 295 645 minecraft:black_concrete
fill 189 295 613 189 295 618 minecraft:black_concrete
fill 189 295 621 189 295 626 minecraft:black_concrete
fill 189 295 629 189 295 634 minecraft:black_concrete
fill 189 295 637 189 295 642 minecraft:black_concrete
setblock 191 295 607 minecraft:light[level=14]
setblock 191 295 615 minecraft:light[level=14]
setblock 191 295 623 minecraft:light[level=14]
setblock 191 295 631 minecraft:light[level=14]
setblock 191 295 639 minecraft:light[level=14]
setblock 199 295 607 minecraft:light[level=14]
setblock 199 295 615 minecraft:light[level=14]
setblock 199 295 623 minecraft:light[level=14]
setblock 199 295 631 minecraft:light[level=14]
setblock 199 295 639 minecraft:light[level=14]
setblock 203 295 641 minecraft:sea_lantern
setblock 203 295 643 minecraft:sea_lantern
setblock 203 295 645 minecraft:sea_lantern
setblock 204 295 642 minecraft:sea_lantern
setblock 204 295 644 minecraft:sea_lantern
setblock 205 295 641 minecraft:sea_lantern
setblock 205 295 643 minecraft:sea_lantern
setblock 205 295 645 minecraft:sea_lantern
setblock 206 295 642 minecraft:sea_lantern
setblock 206 295 644 minecraft:sea_lantern
setblock 207 295 607 minecraft:light[level=14]
setblock 207 295 615 minecraft:light[level=14]
setblock 207 295 623 minecraft:light[level=14]
setblock 207 295 631 minecraft:light[level=14]
setblock 207 295 639 minecraft:light[level=14]
setblock 207 295 641 minecraft:sea_lantern
setblock 207 295 643 minecraft:sea_lantern
setblock 207 295 645 minecraft:sea_lantern
setblock 208 295 642 minecraft:sea_lantern
setblock 208 295 644 minecraft:sea_lantern
setblock 209 295 641 minecraft:sea_lantern
setblock 209 295 643 minecraft:sea_lantern
setblock 209 295 645 minecraft:sea_lantern
setblock 210 295 642 minecraft:sea_lantern
setblock 210 295 644 minecraft:sea_lantern
setblock 211 295 641 minecraft:sea_lantern
setblock 211 295 643 minecraft:sea_lantern
setblock 211 295 645 minecraft:sea_lantern
setblock 215 295 607 minecraft:light[level=14]
setblock 215 295 615 minecraft:light[level=14]
setblock 215 295 623 minecraft:light[level=14]
setblock 215 295 631 minecraft:light[level=14]
setblock 215 295 639 minecraft:light[level=14]
fill 216 295 612 216 296 612 minecraft:black_concrete
fill 216 295 615 216 296 616 minecraft:black_concrete
fill 217 295 611 217 296 611 minecraft:black_concrete
fill 217 295 617 217 296 617 minecraft:black_concrete
fill 219 295 610 220 296 610 minecraft:black_concrete
fill 221 295 617 221 296 617 minecraft:black_concrete
fill 221 295 629 223 296 629 minecraft:yellow_concrete
fill 222 295 611 222 296 611 minecraft:black_concrete
fill 222 295 628 223 296 628 minecraft:yellow_concrete
setblock 223 295 607 minecraft:light[level=14]
fill 223 295 613 223 296 615 minecraft:black_concrete
setblock 223 295 623 minecraft:light[level=14]
setblock 223 295 631 minecraft:light[level=14]
setblock 223 295 639 minecraft:light[level=14]
setblock 229 295 644 minecraft:black_concrete
fill 203 296 641 203 297 641 minecraft:black_concrete
fill 203 296 643 203 297 643 minecraft:black_concrete
fill 203 296 645 203 297 645 minecraft:black_concrete
fill 204 296 642 204 297 642 minecraft:black_concrete
fill 204 296 644 204 297 644 minecraft:black_concrete
fill 205 296 641 205 297 641 minecraft:black_concrete
fill 205 296 643 205 297 643 minecraft:black_concrete
fill 205 296 645 205 297 645 minecraft:black_concrete
fill 206 296 642 206 297 642 minecraft:black_concrete
fill 206 296 644 206 297 644 minecraft:black_concrete
fill 207 296 641 207 297 641 minecraft:black_concrete
fill 207 296 643 207 297 643 minecraft:black_concrete
fill 207 296 645 207 297 645 minecraft:black_concrete
fill 208 296 642 208 297 642 minecraft:black_concrete
fill 208 296 644 208 297 644 minecraft:black_concrete
fill 209 296 641 209 297 641 minecraft:black_concrete
fill 209 296 643 209 297 643 minecraft:black_concrete
fill 209 296 645 209 297 645 minecraft:black_concrete
fill 210 296 642 210 297 642 minecraft:black_concrete
fill 210 296 644 210 297 644 minecraft:black_concrete
fill 211 296 641 211 297 641 minecraft:black_concrete
fill 211 296 643 211 297 643 minecraft:black_concrete
fill 211 296 645 211 297 645 minecraft:black_concrete
fill 215 296 613 215 296 614 minecraft:black_concrete
setblock 216 296 611 minecraft:black_concrete
setblock 218 296 610 minecraft:black_concrete
fill 218 296 618 220 296 618 minecraft:black_concrete
setblock 221 296 610 minecraft:black_concrete
fill 221 296 622 221 297 622 minecraft:magenta_concrete
setblock 222 296 617 minecraft:black_concrete
setblock 223 296 612 minecraft:black_concrete
setblock 223 296 616 minecraft:black_concrete
fill 219 297 613 219 297 615 minecraft:white_stained_glass
fill 220 297 613 220 297 614 minecraft:white_stained_glass
fill 188 298 609 188 300 609 minecraft:sea_lantern
fill 188 298 617 188 300 617 minecraft:sea_lantern
fill 188 298 625 188 300 625 minecraft:sea_lantern
fill 188 298 633 188 300 633 minecraft:sea_lantern
fill 188 298 641 188 300 641 minecraft:sea_lantern
fill 191 298 646 191 300 646 minecraft:sea_lantern
fill 195 298 604 195 300 604 minecraft:sea_lantern
fill 199 298 646 199 300 646 minecraft:sea_lantern
fill 203 298 604 203 300 604 minecraft:sea_lantern
setblock 203 298 641 minecraft:sea_lantern
setblock 203 298 643 minecraft:sea_lantern
setblock 203 298 645 minecraft:sea_lantern
setblock 204 298 642 minecraft:sea_lantern
setblock 204 298 644 minecraft:sea_lantern
setblock 205 298 641 minecraft:sea_lantern
setblock 205 298 643 minecraft:sea_lantern
setblock 205 298 645 minecraft:sea_lantern
setblock 206 298 642 minecraft:sea_lantern
setblock 206 298 644 minecraft:sea_lantern
setblock 207 298 641 minecraft:sea_lantern
setblock 207 298 643 minecraft:sea_lantern
fill 207 298 645 207 298 646 minecraft:sea_lantern
setblock 208 298 642 minecraft:sea_lantern
setblock 208 298 644 minecraft:sea_lantern
setblock 209 298 641 minecraft:sea_lantern
setblock 209 298 643 minecraft:sea_lantern
setblock 209 298 645 minecraft:sea_lantern
setblock 210 298 642 minecraft:sea_lantern
setblock 210 298 644 minecraft:sea_lantern
fill 211 298 604 211 300 604 minecraft:sea_lantern
setblock 211 298 641 minecraft:sea_lantern
setblock 211 298 643 minecraft:sea_lantern
setblock 211 298 645 minecraft:sea_lantern
fill 215 298 646 215 300 646 minecraft:sea_lantern
fill 219 298 604 219 300 604 minecraft:sea_lantern
fill 219 298 613 219 298 614 minecraft:white_stained_glass
fill 220 298 614 220 299 614 minecraft:white_stained_glass
fill 223 298 646 223 300 646 minecraft:sea_lantern
fill 227 298 604 227 300 604 minecraft:sea_lantern
fill 230 298 609 230 300 609 minecraft:sea_lantern
fill 230 298 617 230 300 617 minecraft:sea_lantern
fill 230 298 625 230 300 625 minecraft:sea_lantern
fill 230 298 633 230 300 633 minecraft:sea_lantern
fill 230 298 641 230 300 641 minecraft:sea_lantern
fill 203 299 641 203 300 641 minecraft:black_concrete
fill 203 299 643 203 300 643 minecraft:black_concrete
fill 203 299 645 203 300 645 minecraft:black_concrete
fill 204 299 642 204 300 642 minecraft:black_concrete
fill 204 299 644 204 300 644 minecraft:black_concrete
fill 205 299 641 205 300 641 minecraft:black_concrete
fill 205 299 643 205 300 643 minecraft:black_concrete
fill 205 299 645 205 300 645 minecraft:black_concrete
fill 206 299 642 206 300 642 minecraft:black_concrete
fill 206 299 644 206 300 644 minecraft:black_concrete
fill 207 299 641 207 300 641 minecraft:black_concrete
fill 207 299 643 207 300 643 minecraft:black_concrete
fill 207 299 645 207 300 645 minecraft:black_concrete
fill 207 299 646 207 300 646 minecraft:sea_lantern
fill 208 299 642 208 300 642 minecraft:black_concrete
fill 208 299 644 208 300 644 minecraft:black_concrete
fill 209 299 641 209 300 641 minecraft:black_concrete
fill 209 299 643 209 300 643 minecraft:black_concrete
fill 209 299 645 209 300 645 minecraft:black_concrete
fill 210 299 642 210 300 642 minecraft:black_concrete
fill 210 299 644 210 300 644 minecraft:black_concrete
fill 211 299 641 211 300 641 minecraft:black_concrete
fill 211 299 643 211 300 643 minecraft:black_concrete
fill 211 299 645 211 300 645 minecraft:black_concrete
fill 219 299 614 219 300 614 minecraft:white_stained_glass
fill 188 301 609 188 307 609 minecraft:lime_concrete
fill 188 301 617 188 307 617 minecraft:lime_concrete
fill 188 301 625 188 307 625 minecraft:lime_concrete
fill 188 301 633 188 307 633 minecraft:lime_concrete
fill 188 301 641 188 307 641 minecraft:lime_concrete
fill 191 301 646 191 307 646 minecraft:lime_concrete
fill 195 301 604 195 307 604 minecraft:lime_concrete
fill 199 301 646 199 307 646 minecraft:lime_concrete
fill 203 301 604 203 307 604 minecraft:lime_concrete
fill 207 301 646 207 307 646 minecraft:lime_concrete
fill 211 301 604 211 307 604 minecraft:lime_concrete
fill 215 301 646 215 307 646 minecraft:lime_concrete
fill 219 301 604 219 307 604 minecraft:lime_concrete
fill 223 301 646 223 307 646 minecraft:lime_concrete
fill 227 301 604 227 307 604 minecraft:lime_concrete
fill 230 301 609 230 307 609 minecraft:lime_concrete
fill 230 301 617 230 307 617 minecraft:lime_concrete
fill 230 301 625 230 307 625 minecraft:lime_concrete
fill 230 301 633 230 307 633 minecraft:lime_concrete
fill 230 301 641 230 307 641 minecraft:lime_concrete
setblock 191 303 607 minecraft:light[level=14]
setblock 191 303 615 minecraft:light[level=14]
setblock 191 303 623 minecraft:light[level=14]
setblock 191 303 631 minecraft:light[level=14]
setblock 191 303 639 minecraft:light[level=14]
setblock 199 303 607 minecraft:light[level=14]
setblock 199 303 615 minecraft:light[level=14]
setblock 199 303 623 minecraft:light[level=14]
setblock 199 303 631 minecraft:light[level=14]
setblock 199 303 639 minecraft:light[level=14]
setblock 207 303 607 minecraft:light[level=14]
setblock 207 303 615 minecraft:light[level=14]
setblock 207 303 623 minecraft:light[level=14]
setblock 207 303 631 minecraft:light[level=14]
setblock 207 303 639 minecraft:light[level=14]
setblock 215 303 607 minecraft:light[level=14]
setblock 215 303 615 minecraft:light[level=14]
setblock 215 303 623 minecraft:light[level=14]
setblock 215 303 631 minecraft:light[level=14]
setblock 215 303 639 minecraft:light[level=14]
setblock 223 303 607 minecraft:light[level=14]
setblock 223 303 615 minecraft:light[level=14]
setblock 223 303 623 minecraft:light[level=14]
setblock 223 303 631 minecraft:light[level=14]
setblock 223 303 639 minecraft:light[level=14]
