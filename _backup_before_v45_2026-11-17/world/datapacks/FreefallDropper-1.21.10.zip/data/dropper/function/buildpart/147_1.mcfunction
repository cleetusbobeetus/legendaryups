fill 176 162 645 179 162 645 minecraft:iron_block
setblock 178 162 605 minecraft:iron_block
fill 182 162 606 182 162 609 minecraft:iron_block
setblock 182 162 611 minecraft:iron_block
fill 182 162 616 182 162 619 minecraft:iron_block
setblock 182 162 621 minecraft:iron_block
fill 182 162 626 182 162 629 minecraft:iron_block
setblock 182 162 631 minecraft:iron_block
fill 182 162 636 182 162 639 minecraft:iron_block
setblock 182 162 641 minecraft:iron_block
setblock 172 163 606 minecraft:iron_block
setblock 172 163 608 minecraft:iron_block
setblock 174 163 606 minecraft:iron_block
setblock 174 163 608 minecraft:iron_block
fill 141 166 610 141 166 613 minecraft:sea_lantern
fill 141 166 620 141 166 623 minecraft:sea_lantern
fill 141 166 630 141 166 633 minecraft:sea_lantern
fill 141 166 640 141 166 643 minecraft:sea_lantern
fill 144 166 604 147 166 604 minecraft:sea_lantern
fill 145 166 646 148 166 646 minecraft:sea_lantern
fill 154 166 604 157 166 604 minecraft:sea_lantern
fill 155 166 646 158 166 646 minecraft:sea_lantern
fill 164 166 604 167 166 604 minecraft:sea_lantern
fill 165 166 646 168 166 646 minecraft:sea_lantern
fill 173 166 605 173 167 605 minecraft:iron_block
fill 174 166 604 177 166 604 minecraft:sea_lantern
fill 175 166 646 178 166 646 minecraft:sea_lantern
fill 183 166 605 183 166 608 minecraft:sea_lantern
fill 183 166 615 183 166 618 minecraft:sea_lantern
fill 183 166 625 183 166 628 minecraft:sea_lantern
fill 183 166 635 183 166 638 minecraft:sea_lantern
setblock 183 166 645 minecraft:sea_lantern
fill 141 167 610 141 174 613 minecraft:polished_blackstone
fill 141 167 620 141 174 623 minecraft:polished_blackstone
fill 141 167 630 141 174 633 minecraft:polished_blackstone
fill 141 167 640 141 174 643 minecraft:polished_blackstone
fill 144 167 604 147 174 604 minecraft:polished_blackstone
setblock 144 167 607 minecraft:light[level=14]
setblock 144 167 615 minecraft:light[level=14]
setblock 144 167 623 minecraft:light[level=14]
setblock 144 167 631 minecraft:light[level=14]
setblock 144 167 639 minecraft:light[level=14]
fill 145 167 646 148 174 646 minecraft:polished_blackstone
setblock 152 167 607 minecraft:light[level=14]
setblock 152 167 615 minecraft:light[level=14]
setblock 152 167 623 minecraft:light[level=14]
setblock 152 167 631 minecraft:light[level=14]
setblock 152 167 639 minecraft:light[level=14]
fill 154 167 604 157 174 604 minecraft:polished_blackstone
fill 155 167 646 158 174 646 minecraft:polished_blackstone
fill 159 167 606 159 168 607 minecraft:iron_block
setblock 160 167 607 minecraft:light[level=14]
setblock 160 167 615 minecraft:light[level=14]
setblock 160 167 623 minecraft:light[level=14]
setblock 160 167 631 minecraft:light[level=14]
setblock 160 167 639 minecraft:light[level=14]
fill 164 167 604 167 174 604 minecraft:polished_blackstone
fill 165 167 646 168 174 646 minecraft:polished_blackstone
setblock 168 167 607 minecraft:light[level=14]
setblock 168 167 615 minecraft:light[level=14]
setblock 168 167 623 minecraft:light[level=14]
setblock 168 167 631 minecraft:light[level=14]
setblock 168 167 639 minecraft:light[level=14]
setblock 173 167 609 minecraft:sea_lantern
fill 174 167 604 177 174 604 minecraft:polished_blackstone
fill 175 167 646 178 174 646 minecraft:polished_blackstone
setblock 176 167 607 minecraft:light[level=14]
setblock 176 167 615 minecraft:light[level=14]
setblock 176 167 623 minecraft:light[level=14]
setblock 176 167 631 minecraft:light[level=14]
setblock 176 167 639 minecraft:light[level=14]
fill 183 167 605 183 174 608 minecraft:polished_blackstone
fill 183 167 615 183 174 618 minecraft:polished_blackstone
fill 183 167 625 183 174 628 minecraft:polished_blackstone
fill 183 167 635 183 174 638 minecraft:polished_blackstone
fill 183 167 645 183 174 645 minecraft:polished_blackstone
setblock 142 168 607 minecraft:iron_block
setblock 142 168 617 minecraft:iron_block
setblock 142 168 627 minecraft:iron_block
setblock 142 168 637 minecraft:iron_block
setblock 144 168 645 minecraft:iron_block
setblock 148 168 605 minecraft:iron_block
setblock 154 168 645 minecraft:iron_block
setblock 158 168 605 minecraft:iron_block
setblock 164 168 645 minecraft:iron_block
setblock 168 168 605 minecraft:iron_block
setblock 172 168 606 minecraft:iron_block
setblock 172 168 608 minecraft:iron_block
setblock 174 168 606 minecraft:iron_block
setblock 174 168 608 minecraft:iron_block
setblock 174 168 645 minecraft:iron_block
setblock 178 168 605 minecraft:iron_block
setblock 182 168 611 minecraft:iron_block
setblock 182 168 621 minecraft:iron_block
setblock 182 168 631 minecraft:iron_block
setblock 182 168 641 minecraft:iron_block
fill 142 171 609 142 171 612 minecraft:iron_block
fill 142 171 619 142 171 622 minecraft:iron_block
fill 142 171 629 142 171 632 minecraft:iron_block
fill 142 171 639 142 171 642 minecraft:iron_block
fill 143 171 605 146 171 605 minecraft:iron_block
fill 146 171 645 149 171 645 minecraft:iron_block
fill 153 171 605 156 171 605 minecraft:iron_block
fill 156 171 645 159 171 645 minecraft:iron_block
fill 163 171 605 166 171 605 minecraft:iron_block
fill 166 171 645 169 171 645 minecraft:iron_block
fill 173 171 605 176 171 605 minecraft:iron_block
fill 176 171 645 179 171 645 minecraft:iron_block
fill 182 171 606 182 171 609 minecraft:iron_block
fill 182 171 616 182 171 619 minecraft:iron_block
fill 182 171 626 182 171 629 minecraft:iron_block
fill 182 171 636 182 171 639 minecraft:iron_block
setblock 172 173 606 minecraft:iron_block
setblock 172 173 608 minecraft:iron_block
setblock 174 173 606 minecraft:iron_block
setblock 174 173 608 minecraft:iron_block
setblock 142 174 607 minecraft:iron_block
setblock 142 174 617 minecraft:iron_block
setblock 142 174 627 minecraft:iron_block
setblock 142 174 637 minecraft:iron_block
setblock 144 174 645 minecraft:iron_block
setblock 148 174 605 minecraft:iron_block
setblock 154 174 645 minecraft:iron_block
setblock 158 174 605 minecraft:iron_block
setblock 164 174 645 minecraft:iron_block
setblock 168 174 605 minecraft:iron_block
setblock 174 174 645 minecraft:iron_block
setblock 178 174 605 minecraft:iron_block
setblock 182 174 611 minecraft:iron_block
setblock 182 174 621 minecraft:iron_block
setblock 182 174 631 minecraft:iron_block
setblock 182 174 641 minecraft:iron_block
fill 141 175 610 141 175 613 minecraft:sea_lantern
fill 141 175 620 141 175 623 minecraft:sea_lantern
fill 141 175 630 141 175 633 minecraft:sea_lantern
fill 141 175 640 141 175 643 minecraft:sea_lantern
fill 144 175 604 147 175 604 minecraft:sea_lantern
setblock 144 175 607 minecraft:light[level=14]
setblock 144 175 615 minecraft:light[level=14]
setblock 144 175 623 minecraft:light[level=14]
setblock 144 175 631 minecraft:light[level=14]
setblock 144 175 639 minecraft:light[level=14]
fill 145 175 646 148 175 646 minecraft:sea_lantern
setblock 152 175 607 minecraft:light[level=14]
setblock 152 175 615 minecraft:light[level=14]
setblock 152 175 623 minecraft:light[level=14]
setblock 152 175 631 minecraft:light[level=14]
setblock 152 175 639 minecraft:light[level=14]
fill 154 175 604 157 175 604 minecraft:sea_lantern
fill 155 175 646 158 175 646 minecraft:sea_lantern
setblock 160 175 607 minecraft:light[level=14]
setblock 160 175 615 minecraft:light[level=14]
setblock 160 175 623 minecraft:light[level=14]
setblock 160 175 631 minecraft:light[level=14]
setblock 160 175 639 minecraft:light[level=14]
fill 164 175 604 167 175 604 minecraft:sea_lantern
fill 165 175 646 168 175 646 minecraft:sea_lantern
setblock 168 175 607 minecraft:light[level=14]
setblock 168 175 615 minecraft:light[level=14]
setblock 168 175 623 minecraft:light[level=14]
setblock 168 175 631 minecraft:light[level=14]
setblock 168 175 639 minecraft:light[level=14]
fill 174 175 604 177 175 604 minecraft:sea_lantern
fill 175 175 646 178 175 646 minecraft:sea_lantern
setblock 176 175 607 minecraft:light[level=14]
setblock 176 175 615 minecraft:light[level=14]
setblock 176 175 623 minecraft:light[level=14]
setblock 176 175 631 minecraft:light[level=14]
setblock 176 175 639 minecraft:light[level=14]
fill 183 175 605 183 175 608 minecraft:sea_lantern
fill 183 175 615 183 175 618 minecraft:sea_lantern
fill 183 175 625 183 175 628 minecraft:sea_lantern
fill 183 175 635 183 175 638 minecraft:sea_lantern
setblock 183 175 645 minecraft:sea_lantern
fill 141 176 610 141 192 613 minecraft:polished_blackstone
fill 141 176 620 141 192 623 minecraft:polished_blackstone
fill 141 176 630 141 192 633 minecraft:polished_blackstone
fill 141 176 640 141 192 643 minecraft:polished_blackstone
fill 144 176 604 147 192 604 minecraft:polished_blackstone
fill 145 176 646 148 192 646 minecraft:polished_blackstone
fill 154 176 604 157 192 604 minecraft:polished_blackstone
fill 155 176 646 158 192 646 minecraft:polished_blackstone
fill 164 176 604 167 192 604 minecraft:polished_blackstone
fill 165 176 646 168 192 646 minecraft:polished_blackstone
fill 174 176 604 177 192 604 minecraft:polished_blackstone
fill 175 176 646 178 192 646 minecraft:polished_blackstone
fill 183 176 605 183 192 608 minecraft:polished_blackstone
fill 183 176 615 183 192 618 minecraft:polished_blackstone
fill 183 176 625 183 192 628 minecraft:polished_blackstone
fill 183 176 635 183 192 638 minecraft:polished_blackstone
fill 183 176 645 183 192 645 minecraft:polished_blackstone
fill 153 180 622 155 180 624 minecraft:iron_block
fill 153 180 625 155 180 626 minecraft:light_blue_concrete
fill 154 180 620 156 180 621 minecraft:iron_block
fill 154 180 627 156 180 628 minecraft:light_blue_concrete
fill 155 180 618 157 180 619 minecraft:iron_block
fill 155 180 629 157 180 630 minecraft:light_blue_concrete
fill 156 180 617 161 180 617 minecraft:iron_block
fill 156 180 631 162 180 631 minecraft:light_blue_concrete
fill 157 180 620 159 180 622 minecraft:redstone_block
fill 158 180 616 161 184 616 minecraft:iron_block
fill 158 180 618 159 180 618 minecraft:iron_block
fill 158 180 630 159 180 630 minecraft:light_blue_concrete
fill 158 180 632 162 180 632 minecraft:light_blue_concrete
fill 160 180 615 161 184 615 minecraft:iron_block
fill 160 180 633 162 182 633 minecraft:light_blue_concrete
fill 161 180 628 163 180 630 minecraft:redstone_block
fill 162 180 615 164 180 617 minecraft:light_blue_concrete
fill 163 180 631 164 180 633 minecraft:iron_block
fill 165 180 616 166 180 618 minecraft:light_blue_concrete
fill 165 180 630 166 180 632 minecraft:iron_block
fill 166 180 623 168 180 625 minecraft:redstone_block
fill 167 180 617 168 180 619 minecraft:light_blue_concrete
fill 167 180 629 168 180 631 minecraft:iron_block
fill 168 180 620 170 180 621 minecraft:light_blue_concrete
fill 168 180 627 170 180 628 minecraft:iron_block
fill 169 180 618 169 184 619 minecraft:light_blue_concrete
fill 169 180 622 171 180 623 minecraft:light_blue_concrete
fill 169 180 624 171 180 626 minecraft:iron_block
fill 169 180 629 169 184 630 minecraft:iron_block
fill 152 181 623 153 182 624 minecraft:iron_block
fill 152 181 625 154 183 625 minecraft:light_blue_concrete
fill 153 181 620 154 183 622 minecraft:iron_block
fill 153 181 626 154 183 628 minecraft:light_blue_concrete
fill 154 181 618 155 183 619 minecraft:iron_block
fill 154 181 623 154 184 623 minecraft:iron_block
fill 154 181 624 160 181 624 minecraft:light_blue_stained_glass
fill 154 181 629 155 183 630 minecraft:light_blue_concrete
fill 155 181 617 158 183 617 minecraft:iron_block
fill 155 181 620 155 184 620 minecraft:iron_block
fill 155 181 621 156 181 623 minecraft:light_blue_stained_glass
fill 155 181 625 160 181 627 minecraft:light_blue_stained_glass
fill 155 181 628 155 184 628 minecraft:light_blue_concrete
fill 155 181 631 158 183 631 minecraft:light_blue_concrete
fill 156 181 616 157 183 616 minecraft:iron_block
fill 156 181 618 156 184 618 minecraft:iron_block
fill 156 181 619 156 181 620 minecraft:light_blue_stained_glass
fill 156 181 628 160 181 629 minecraft:light_blue_stained_glass
fill 156 181 630 156 184 630 minecraft:light_blue_concrete
fill 156 181 632 161 183 632 minecraft:light_blue_concrete
fill 157 181 618 167 181 619 minecraft:light_blue_stained_glass
fill 157 181 623 160 181 623 minecraft:light_blue_stained_glass
fill 157 181 630 160 181 630 minecraft:light_blue_stained_glass
fill 158 181 615 159 182 615 minecraft:iron_block
fill 158 181 633 159 182 633 minecraft:light_blue_concrete
fill 159 181 617 165 182 617 minecraft:light_blue_stained_glass
fill 159 181 631 165 181 631 minecraft:light_blue_stained_glass
fill 160 181 620 168 181 622 minecraft:light_blue_stained_glass
fill 161 181 614 161 183 614 minecraft:iron_block
fill 161 181 626 169 181 627 minecraft:light_blue_stained_glass
fill 161 181 634 162 183 634 minecraft:light_blue_concrete
fill 162 181 614 163 182 615 minecraft:light_blue_concrete
fill 162 181 616 162 182 616 minecraft:light_blue_stained_glass
fill 162 181 632 162 182 632 minecraft:light_blue_stained_glass
fill 163 181 616 168 183 616 minecraft:light_blue_concrete
fill 163 181 632 163 183 634 minecraft:iron_block
fill 164 181 615 166 182 615 minecraft:light_blue_concrete
fill 164 181 623 165 181 625 minecraft:light_blue_stained_glass
fill 164 181 628 167 181 630 minecraft:light_blue_stained_glass
fill 164 181 632 166 182 633 minecraft:iron_block
fill 166 181 617 169 183 617 minecraft:light_blue_concrete
fill 166 181 631 169 183 631 minecraft:iron_block
fill 167 181 632 168 183 632 minecraft:iron_block
fill 168 181 618 168 184 618 minecraft:light_blue_concrete
fill 168 181 619 168 182 619 minecraft:light_blue_stained_glass
fill 168 181 628 168 182 629 minecraft:light_blue_stained_glass
fill 168 181 630 168 184 630 minecraft:iron_block
fill 169 181 620 171 183 620 minecraft:light_blue_concrete
fill 169 181 621 169 181 625 minecraft:light_blue_stained_glass
fill 169 181 628 171 183 628 minecraft:iron_block
fill 170 181 618 170 183 619 minecraft:light_blue_concrete
fill 170 181 621 171 183 623 minecraft:light_blue_concrete
fill 170 181 624 170 182 624 minecraft:light_blue_stained_glass
fill 170 181 625 171 183 627 minecraft:iron_block
fill 170 181 629 170 183 630 minecraft:iron_block
fill 171 181 624 172 182 624 minecraft:iron_block
fill 172 181 623 172 183 623 minecraft:light_blue_concrete
fill 172 181 625 172 183 625 minecraft:iron_block
fill 142 182 605 151 182 645 minecraft:netherite_block
fill 152 182 605 152 182 621 minecraft:netherite_block
setblock 152 182 622 minecraft:iron_block
setblock 152 182 626 minecraft:light_blue_concrete
fill 152 182 627 152 182 645 minecraft:netherite_block
fill 153 182 605 153 182 618 minecraft:netherite_block
setblock 153 182 619 minecraft:iron_block
setblock 153 182 629 minecraft:light_blue_concrete
fill 153 182 630 153 182 645 minecraft:netherite_block
fill 154 182 605 154 182 617 minecraft:netherite_block
fill 154 182 624 159 182 624 minecraft:light_blue_stained_glass
fill 154 182 631 154 182 645 minecraft:netherite_block
fill 155 182 605 155 182 616 minecraft:netherite_block
fill 155 182 621 155 182 623 minecraft:light_blue_stained_glass
fill 155 182 625 159 182 627 minecraft:light_blue_stained_glass
fill 155 182 632 155 182 645 minecraft:netherite_block
fill 156 182 605 156 182 615 minecraft:netherite_block
fill 156 182 619 156 182 623 minecraft:sea_lantern
fill 156 182 628 159 182 629 minecraft:light_blue_stained_glass
fill 156 182 633 156 182 645 minecraft:netherite_block
fill 157 182 605 159 182 614 minecraft:netherite_block
setblock 157 182 615 minecraft:iron_block
fill 157 182 618 167 182 618 minecraft:light_blue_stained_glass
fill 157 182 619 160 182 619 minecraft:sea_lantern
fill 157 182 620 159 182 622 minecraft:netherite_block
fill 157 182 623 159 182 623 minecraft:sea_lantern
fill 157 182 630 159 182 630 minecraft:light_blue_stained_glass
setblock 157 182 633 minecraft:light_blue_concrete
fill 157 182 634 159 182 645 minecraft:netherite_block
setblock 159 182 631 minecraft:light_blue_stained_glass
fill 160 182 605 182 182 613 minecraft:netherite_block
setblock 160 182 614 minecraft:iron_block
fill 160 182 620 160 182 622 minecraft:sea_lantern
fill 160 182 623 160 182 625 minecraft:ochre_froglight
fill 160 182 626 160 182 631 minecraft:sea_lantern
setblock 160 182 634 minecraft:light_blue_concrete
fill 160 182 635 182 182 645 minecraft:netherite_block
fill 161 182 619 167 182 621 minecraft:light_blue_stained_glass
fill 161 182 622 163 182 622 minecraft:ochre_froglight
fill 161 182 626 163 182 626 minecraft:ochre_froglight
fill 161 182 627 164 182 627 minecraft:sea_lantern
fill 161 182 628 163 182 630 minecraft:netherite_block
fill 161 182 631 164 182 631 minecraft:sea_lantern
setblock 164 182 614 minecraft:light_blue_concrete
fill 164 182 622 169 182 622 minecraft:sea_lantern
fill 164 182 623 164 182 625 minecraft:ochre_froglight
fill 164 182 626 169 182 626 minecraft:sea_lantern
fill 164 182 628 164 182 630 minecraft:sea_lantern
setblock 164 182 634 minecraft:iron_block
fill 165 182 614 182 182 614 minecraft:netherite_block
fill 165 182 623 165 182 625 minecraft:sea_lantern
fill 165 182 627 165 182 631 minecraft:light_blue_stained_glass
fill 165 182 634 182 182 634 minecraft:netherite_block
fill 166 182 623 168 182 625 minecraft:netherite_block
fill 166 182 627 167 182 630 minecraft:light_blue_stained_glass
setblock 167 182 615 minecraft:light_blue_concrete
setblock 167 182 633 minecraft:iron_block
fill 168 182 615 182 182 615 minecraft:netherite_block
fill 168 182 620 168 182 621 minecraft:light_blue_stained_glass
fill 168 182 627 169 182 627 minecraft:light_blue_stained_glass
fill 168 182 633 182 182 633 minecraft:netherite_block
fill 169 182 616 182 182 616 minecraft:netherite_block
setblock 169 182 621 minecraft:light_blue_stained_glass
fill 169 182 623 169 182 625 minecraft:sea_lantern
fill 169 182 632 182 182 632 minecraft:netherite_block
fill 170 182 617 182 182 617 minecraft:netherite_block
fill 170 182 631 182 182 631 minecraft:netherite_block
fill 171 182 618 182 182 618 minecraft:netherite_block
setblock 171 182 619 minecraft:light_blue_concrete
setblock 171 182 629 minecraft:iron_block
fill 171 182 630 182 182 630 minecraft:netherite_block
fill 172 182 619 182 182 621 minecraft:netherite_block
setblock 172 182 622 minecraft:light_blue_concrete
setblock 172 182 626 minecraft:iron_block
fill 172 182 627 182 182 629 minecraft:netherite_block
fill 173 182 622 182 182 626 minecraft:netherite_block
setblock 144 183 607 minecraft:light[level=14]
setblock 144 183 615 minecraft:light[level=14]
setblock 144 183 623 minecraft:light[level=14]
setblock 144 183 631 minecraft:light[level=14]
setblock 144 183 639 minecraft:light[level=14]
setblock 152 183 607 minecraft:light[level=14]
setblock 152 183 615 minecraft:light[level=14]
fill 152 183 623 152 183 624 minecraft:iron_block
setblock 152 183 631 minecraft:light[level=14]
setblock 152 183 639 minecraft:light[level=14]
fill 153 183 615 153 184 615 minecraft:bone_block
fill 153 183 623 153 184 623 minecraft:iron_block
fill 153 183 624 153 193 624 minecraft:bone_block
fill 153 183 633 153 184 633 minecraft:bone_block
fill 154 183 624 155 184 624 minecraft:iron_block
fill 155 183 621 156 183 623 minecraft:iron_block
fill 155 183 625 156 183 627 minecraft:light_blue_concrete
fill 156 183 615 156 184 615 minecraft:bone_block
fill 156 183 619 157 183 620 minecraft:iron_block
fill 156 183 624 156 189 624 minecraft:bone_block
fill 156 183 628 157 183 629 minecraft:light_blue_concrete
fill 156 183 633 156 184 633 minecraft:bone_block
fill 157 183 618 161 183 618 minecraft:iron_block
setblock 157 183 621 minecraft:iron_block
setblock 157 183 627 minecraft:light_blue_concrete
fill 157 183 630 162 183 630 minecraft:light_blue_concrete
setblock 158 183 615 minecraft:iron_block
fill 158 183 619 159 183 619 minecraft:iron_block
fill 158 183 629 159 183 629 minecraft:light_blue_concrete
setblock 158 183 633 minecraft:light_blue_concrete
fill 159 183 615 159 184 615 minecraft:bone_block
fill 159 183 617 161 184 617 minecraft:iron_block
fill 159 183 624 159 189 624 minecraft:bone_block
fill 159 183 631 162 184 631 minecraft:light_blue_concrete
fill 159 183 633 159 184 633 minecraft:bone_block
setblock 160 183 607 minecraft:light[level=14]
setblock 160 183 623 minecraft:light[level=14]
fill 160 183 633 161 184 633 minecraft:light_blue_concrete
setblock 160 183 639 minecraft:light[level=14]
fill 162 183 614 163 183 614 minecraft:light_blue_concrete
fill 162 183 615 162 184 615 minecraft:bone_block
fill 162 183 616 162 183 618 minecraft:light_blue_concrete
fill 162 183 632 162 184 632 minecraft:light_blue_concrete
fill 162 183 633 162 184 633 minecraft:bone_block
fill 163 183 615 164 184 615 minecraft:light_blue_concrete
fill 163 183 617 165 183 618 minecraft:light_blue_concrete
fill 163 183 630 165 183 631 minecraft:iron_block
fill 164 183 632 164 184 633 minecraft:iron_block
fill 165 183 615 165 184 615 minecraft:bone_block
fill 165 183 619 168 183 619 minecraft:light_blue_concrete
fill 165 183 624 165 189 624 minecraft:bone_block
fill 165 183 629 168 183 629 minecraft:iron_block
fill 165 183 632 166 184 632 minecraft:iron_block
fill 165 183 633 165 184 633 minecraft:bone_block
setblock 166 183 615 minecraft:light_blue_concrete
fill 166 183 618 167 184 618 minecraft:light_blue_concrete
fill 166 183 630 167 184 630 minecraft:iron_block
setblock 166 183 633 minecraft:iron_block
fill 167 183 620 168 183 621 minecraft:light_blue_concrete
fill 167 183 627 168 183 628 minecraft:iron_block
setblock 168 183 607 minecraft:light[level=14]
fill 168 183 615 168 184 615 minecraft:bone_block
fill 168 183 622 169 183 623 minecraft:light_blue_concrete
fill 168 183 624 168 189 624 minecraft:bone_block
fill 168 183 625 169 183 626 minecraft:iron_block
fill 168 183 633 168 184 633 minecraft:bone_block
setblock 168 183 639 minecraft:light[level=14]
fill 169 183 621 169 184 621 minecraft:light_blue_concrete
fill 169 183 624 170 184 624 minecraft:iron_block
fill 169 183 627 169 184 627 minecraft:iron_block
fill 171 183 615 171 184 615 minecraft:bone_block
fill 171 183 624 171 189 624 minecraft:bone_block
fill 171 183 633 171 184 633 minecraft:bone_block
setblock 172 183 624 minecraft:iron_block
setblock 176 183 607 minecraft:light[level=14]
setblock 176 183 615 minecraft:light[level=14]
setblock 176 183 623 minecraft:light[level=14]
setblock 176 183 631 minecraft:light[level=14]
setblock 176 183 639 minecraft:light[level=14]
fill 153 184 622 155 184 622 minecraft:iron_block
fill 153 184 625 155 184 626 minecraft:light_blue_concrete
fill 154 184 620 154 184 621 minecraft:iron_block
fill 154 184 627 154 184 628 minecraft:light_blue_concrete
fill 155 184 618 155 184 619 minecraft:iron_block
fill 155 184 621 156 184 621 minecraft:iron_block
setblock 155 184 623 minecraft:iron_block
fill 155 184 627 156 184 627 minecraft:light_blue_concrete
fill 155 184 629 155 184 630 minecraft:light_blue_concrete
fill 156 184 617 158 184 617 minecraft:iron_block
fill 156 184 619 156 184 620 minecraft:iron_block
fill 156 184 628 156 184 629 minecraft:light_blue_concrete
fill 156 184 631 158 184 631 minecraft:light_blue_concrete
fill 157 184 618 157 184 619 minecraft:iron_block
fill 157 184 629 157 184 630 minecraft:light_blue_concrete
fill 158 184 618 159 184 618 minecraft:iron_block
fill 158 184 630 159 184 630 minecraft:light_blue_concrete
fill 158 184 632 161 184 632 minecraft:light_blue_concrete
fill 162 184 616 166 184 617 minecraft:light_blue_concrete
fill 163 184 631 163 184 633 minecraft:iron_block
fill 164 184 631 168 184 631 minecraft:iron_block
setblock 165 184 618 minecraft:light_blue_concrete
setblock 165 184 630 minecraft:iron_block
fill 167 184 617 168 184 617 minecraft:light_blue_concrete
fill 167 184 619 168 184 619 minecraft:light_blue_concrete
fill 167 184 629 168 184 629 minecraft:iron_block
fill 168 184 620 168 184 621 minecraft:light_blue_concrete
fill 168 184 627 168 184 628 minecraft:iron_block
fill 169 184 620 170 184 620 minecraft:light_blue_concrete
fill 169 184 622 171 184 623 minecraft:light_blue_concrete
fill 169 184 625 171 184 626 minecraft:iron_block
fill 169 184 628 170 184 628 minecraft:iron_block
setblock 170 184 621 minecraft:light_blue_concrete
setblock 170 184 627 minecraft:iron_block
fill 153 185 616 153 186 616 minecraft:bone_block
fill 153 185 632 153 186 632 minecraft:bone_block
fill 156 185 616 156 186 616 minecraft:bone_block
fill 156 185 632 156 186 632 minecraft:bone_block
fill 159 185 616 159 186 616 minecraft:bone_block
fill 159 185 632 159 186 632 minecraft:bone_block
fill 162 185 616 162 186 616 minecraft:bone_block
fill 162 185 632 162 186 632 minecraft:bone_block
fill 165 185 616 165 186 616 minecraft:bone_block
fill 165 185 632 165 186 632 minecraft:bone_block
fill 168 185 616 168 186 616 minecraft:bone_block
fill 168 185 632 168 186 632 minecraft:bone_block
fill 171 185 616 171 186 616 minecraft:bone_block
fill 171 185 632 171 186 632 minecraft:bone_block
fill 142 186 606 142 186 607 minecraft:iron_block
fill 142 186 616 142 186 617 minecraft:iron_block
fill 142 186 626 142 186 627 minecraft:iron_block
fill 142 186 636 142 186 637 minecraft:iron_block
fill 143 186 645 144 186 645 minecraft:iron_block
fill 148 186 605 149 186 605 minecraft:iron_block
fill 153 186 645 154 186 645 minecraft:iron_block
fill 156 186 641 158 230 641 minecraft:iron_block
fill 157 186 640 157 230 640 minecraft:iron_block
fill 157 186 642 157 230 642 minecraft:iron_block
fill 158 186 605 159 186 605 minecraft:iron_block
fill 159 186 638 159 190 638 minecraft:iron_block
fill 163 186 645 164 186 645 minecraft:iron_block
fill 168 186 605 169 186 605 minecraft:iron_block
fill 173 186 645 174 186 645 minecraft:iron_block
fill 178 186 605 179 186 605 minecraft:iron_block
fill 182 186 611 182 186 612 minecraft:iron_block
fill 182 186 621 182 186 622 minecraft:iron_block
fill 182 186 631 182 186 632 minecraft:iron_block
fill 182 186 641 182 186 642 minecraft:iron_block
fill 142 187 606 142 230 606 minecraft:iron_block
fill 142 187 616 142 230 616 minecraft:iron_block
fill 142 187 626 142 230 626 minecraft:iron_block
fill 142 187 636 142 230 636 minecraft:iron_block
fill 143 187 645 143 230 645 minecraft:iron_block
fill 147 187 626 148 193 626 minecraft:bone_block
fill 148 187 621 149 192 625 minecraft:bone_block
fill 149 187 605 149 230 605 minecraft:iron_block
fill 150 187 624 151 193 625 minecraft:bone_block
fill 153 187 617 153 188 617 minecraft:bone_block
fill 153 187 631 153 188 631 minecraft:bone_block
fill 153 187 645 153 230 645 minecraft:iron_block
fill 156 187 617 156 188 617 minecraft:bone_block
fill 156 187 631 156 188 631 minecraft:bone_block
fill 159 187 605 159 230 605 minecraft:iron_block
fill 159 187 617 159 188 617 minecraft:bone_block
fill 159 187 631 159 188 631 minecraft:bone_block
fill 162 187 617 162 188 617 minecraft:bone_block
fill 162 187 631 162 188 631 minecraft:bone_block
fill 163 187 645 163 230 645 minecraft:iron_block
fill 165 187 617 165 188 617 minecraft:bone_block
fill 165 187 631 165 188 631 minecraft:bone_block
fill 168 187 617 168 188 617 minecraft:bone_block
fill 168 187 631 168 188 631 minecraft:bone_block
fill 169 187 605 169 230 605 minecraft:iron_block
fill 171 187 617 171 188 617 minecraft:bone_block
fill 171 187 631 171 188 631 minecraft:bone_block
fill 173 187 645 173 230 645 minecraft:iron_block
fill 179 187 605 179 230 605 minecraft:iron_block
fill 182 187 612 182 230 612 minecraft:iron_block
fill 182 187 622 182 230 622 minecraft:iron_block
fill 182 187 632 182 230 632 minecraft:iron_block
fill 182 187 642 182 230 642 minecraft:iron_block
fill 147 188 621 147 191 625 minecraft:bone_block
fill 147 188 627 148 191 627 minecraft:bone_block
fill 148 188 620 148 190 620 minecraft:bone_block
fill 149 188 626 151 193 626 minecraft:bone_block
fill 150 188 622 150 193 623 minecraft:bone_block
fill 151 188 623 151 194 623 minecraft:bone_block
fill 152 188 624 152 192 625 minecraft:bone_block
fill 153 188 618 153 190 618 minecraft:bone_block
fill 153 188 630 153 190 630 minecraft:bone_block
fill 156 188 618 156 190 618 minecraft:bone_block
fill 156 188 630 156 190 630 minecraft:bone_block
setblock 156 188 640 minecraft:iron_block
setblock 156 188 642 minecraft:iron_block
setblock 158 188 640 minecraft:iron_block
setblock 158 188 642 minecraft:iron_block
fill 159 188 618 159 190 618 minecraft:bone_block
fill 159 188 630 159 190 630 minecraft:bone_block
fill 162 188 618 162 190 618 minecraft:bone_block
fill 162 188 630 162 190 630 minecraft:bone_block
fill 165 188 618 165 190 618 minecraft:bone_block
fill 165 188 630 165 190 630 minecraft:bone_block
fill 168 188 618 168 190 618 minecraft:bone_block
fill 168 188 630 168 190 630 minecraft:bone_block
fill 171 188 618 171 190 618 minecraft:bone_block
fill 171 188 630 171 190 630 minecraft:bone_block
fill 142 189 609 142 189 612 minecraft:iron_block
fill 142 189 619 142 189 622 minecraft:iron_block
fill 142 189 629 142 189 632 minecraft:iron_block
fill 142 189 639 142 189 642 minecraft:iron_block
fill 143 189 605 146 189 605 minecraft:iron_block
fill 146 189 625 146 190 627 minecraft:bone_block
fill 146 189 645 149 189 645 minecraft:iron_block
fill 149 189 620 149 190 620 minecraft:bone_block
fill 149 189 627 150 192 627 minecraft:bone_block
fill 150 189 621 150 192 621 minecraft:bone_block
fill 151 189 622 151 193 622 minecraft:bone_block
fill 152 189 623 153 192 623 minecraft:bone_block
fill 152 189 626 152 191 626 minecraft:bone_block
fill 153 189 605 156 189 605 minecraft:iron_block
fill 153 189 625 153 192 625 minecraft:bone_block
fill 156 189 623 156 192 623 minecraft:bone_block
fill 156 189 625 156 192 625 minecraft:bone_block
fill 156 189 645 159 189 645 minecraft:iron_block
fill 159 189 623 159 192 623 minecraft:bone_block
fill 159 189 625 159 192 625 minecraft:bone_block
fill 162 189 623 162 192 623 minecraft:bone_block
fill 163 189 605 166 189 605 minecraft:iron_block
fill 165 189 623 165 192 623 minecraft:bone_block
fill 165 189 625 165 192 625 minecraft:bone_block
fill 166 189 645 169 189 645 minecraft:iron_block
fill 168 189 623 168 192 623 minecraft:bone_block
fill 168 189 625 168 192 625 minecraft:bone_block
fill 171 189 623 171 192 623 minecraft:bone_block
fill 171 189 625 171 192 625 minecraft:bone_block
fill 173 189 605 176 189 605 minecraft:iron_block
fill 176 189 640 176 197 640 minecraft:iron_block
fill 176 189 645 179 189 645 minecraft:iron_block
fill 182 189 606 182 189 609 minecraft:iron_block
fill 182 189 616 182 189 619 minecraft:iron_block
fill 182 189 626 182 189 629 minecraft:iron_block
fill 182 189 636 182 189 639 minecraft:iron_block
fill 146 190 622 146 192 624 minecraft:bone_block
fill 151 190 621 151 192 621 minecraft:bone_block
fill 151 190 627 151 191 627 minecraft:bone_block
fill 152 190 622 152 193 622 minecraft:bone_block
fill 153 190 619 153 191 619 minecraft:bone_block
fill 153 190 629 153 191 629 minecraft:bone_block
fill 156 190 619 156 191 619 minecraft:bone_block
fill 156 190 629 156 191 629 minecraft:bone_block
fill 159 190 619 159 191 619 minecraft:bone_block
fill 159 190 629 159 191 629 minecraft:bone_block
fill 162 190 619 162 191 619 minecraft:bone_block
fill 162 190 629 162 191 629 minecraft:bone_block
fill 165 190 619 165 191 619 minecraft:bone_block
fill 165 190 629 165 191 629 minecraft:bone_block
fill 168 190 619 168 191 619 minecraft:bone_block
fill 168 190 629 168 191 629 minecraft:bone_block
fill 171 190 619 171 191 619 minecraft:bone_block
fill 171 190 629 171 191 629 minecraft:bone_block
setblock 144 191 607 minecraft:light[level=14]
setblock 144 191 615 minecraft:light[level=14]
setblock 144 191 623 minecraft:light[level=14]
setblock 144 191 631 minecraft:light[level=14]
setblock 144 191 639 minecraft:light[level=14]
fill 145 191 624 145 191 625 minecraft:bone_block
fill 146 191 625 146 192 626 minecraft:bone_block
setblock 152 191 607 minecraft:light[level=14]
setblock 152 191 615 minecraft:light[level=14]
setblock 152 191 631 minecraft:light[level=14]
setblock 152 191 639 minecraft:light[level=14]
fill 153 191 620 153 192 620 minecraft:bone_block
fill 153 191 628 153 192 628 minecraft:bone_block
fill 156 191 620 156 192 620 minecraft:bone_block
fill 156 191 628 156 192 628 minecraft:bone_block
fill 159 191 620 159 192 620 minecraft:bone_block
fill 159 191 628 159 192 628 minecraft:bone_block
setblock 160 191 607 minecraft:light[level=14]
setblock 160 191 615 minecraft:light[level=14]
setblock 160 191 623 minecraft:light[level=14]
setblock 160 191 631 minecraft:light[level=14]
setblock 160 191 639 minecraft:light[level=14]
fill 162 191 620 162 192 620 minecraft:bone_block
fill 162 191 628 162 192 628 minecraft:bone_block
fill 165 191 620 165 192 620 minecraft:bone_block
fill 165 191 628 165 192 628 minecraft:bone_block
setblock 168 191 607 minecraft:light[level=14]
setblock 168 191 615 minecraft:light[level=14]
fill 168 191 620 168 192 620 minecraft:bone_block
fill 168 191 628 168 192 628 minecraft:bone_block
setblock 168 191 631 minecraft:light[level=14]
setblock 168 191 639 minecraft:light[level=14]
fill 171 191 620 171 192 620 minecraft:bone_block
fill 171 191 628 171 192 628 minecraft:bone_block
setblock 176 191 607 minecraft:light[level=14]
setblock 176 191 615 minecraft:light[level=14]
setblock 176 191 623 minecraft:light[level=14]
setblock 176 191 631 minecraft:light[level=14]
setblock 176 191 639 minecraft:light[level=14]
setblock 142 192 607 minecraft:iron_block
setblock 142 192 617 minecraft:iron_block
setblock 142 192 627 minecraft:iron_block
setblock 142 192 637 minecraft:iron_block
setblock 144 192 645 minecraft:iron_block
setblock 145 192 624 minecraft:bone_block
fill 147 192 622 147 193 625 minecraft:bone_block
setblock 148 192 605 minecraft:iron_block
setblock 148 192 627 minecraft:bone_block
fill 153 192 621 153 192 622 minecraft:bone_block
fill 153 192 626 153 192 627 minecraft:bone_block
fill 154 192 624 161 193 624 minecraft:bone_block
setblock 154 192 645 minecraft:iron_block
fill 156 192 621 156 192 622 minecraft:bone_block
fill 156 192 626 156 192 627 minecraft:bone_block
setblock 158 192 605 minecraft:iron_block
fill 159 192 621 159 192 622 minecraft:bone_block
fill 159 192 626 159 192 627 minecraft:bone_block
fill 162 192 621 162 192 622 minecraft:bone_block
fill 162 192 626 162 192 627 minecraft:bone_block
fill 164 192 624 173 193 624 minecraft:bone_block
setblock 164 192 645 minecraft:iron_block
fill 165 192 621 165 192 622 minecraft:bone_block
fill 165 192 626 165 192 627 minecraft:bone_block
setblock 168 192 605 minecraft:iron_block
fill 168 192 621 168 192 622 minecraft:bone_block
fill 168 192 626 168 192 627 minecraft:bone_block
fill 171 192 621 171 192 622 minecraft:bone_block
fill 171 192 626 171 192 627 minecraft:bone_block
setblock 174 192 645 minecraft:iron_block
setblock 178 192 605 minecraft:iron_block
setblock 182 192 611 minecraft:iron_block
setblock 182 192 621 minecraft:iron_block
setblock 182 192 631 minecraft:iron_block
setblock 182 192 641 minecraft:iron_block
fill 141 193 610 141 193 613 minecraft:sea_lantern
fill 141 193 620 141 193 623 minecraft:sea_lantern
fill 141 193 630 141 193 633 minecraft:sea_lantern
fill 141 193 640 141 193 643 minecraft:sea_lantern
fill 144 193 604 147 193 604 minecraft:sea_lantern
fill 145 193 646 148 193 646 minecraft:sea_lantern
fill 146 193 623 146 193 625 minecraft:bone_block
fill 148 193 622 149 193 625 minecraft:bone_block
fill 152 193 623 152 193 624 minecraft:bone_block
fill 154 193 604 157 193 604 minecraft:sea_lantern
fill 155 193 646 158 193 646 minecraft:sea_lantern
setblock 156 193 640 minecraft:iron_block
setblock 156 193 642 minecraft:iron_block
setblock 158 193 640 minecraft:iron_block
setblock 158 193 642 minecraft:iron_block
fill 164 193 604 167 193 604 minecraft:sea_lantern
fill 165 193 646 168 193 646 minecraft:sea_lantern
fill 174 193 604 177 193 604 minecraft:sea_lantern
fill 175 193 646 178 193 646 minecraft:sea_lantern
fill 183 193 605 183 193 608 minecraft:sea_lantern
fill 183 193 615 183 193 618 minecraft:sea_lantern
fill 183 193 625 183 193 628 minecraft:sea_lantern
fill 183 193 635 183 193 638 minecraft:sea_lantern
setblock 183 193 645 minecraft:sea_lantern
fill 141 194 610 141 201 613 minecraft:polished_blackstone
fill 141 194 620 141 201 623 minecraft:polished_blackstone
fill 141 194 630 141 201 633 minecraft:polished_blackstone
fill 141 194 640 141 201 643 minecraft:polished_blackstone
fill 144 194 604 147 201 604 minecraft:polished_blackstone
fill 145 194 646 148 201 646 minecraft:polished_blackstone
fill 147 194 624 151 194 624 minecraft:bone_block
fill 148 194 623 150 194 623 minecraft:bone_block
fill 148 194 625 150 194 625 minecraft:bone_block
fill 154 194 604 157 201 604 minecraft:polished_blackstone
fill 155 194 646 158 201 646 minecraft:polished_blackstone
fill 164 194 604 167 201 604 minecraft:polished_blackstone
fill 165 194 646 168 201 646 minecraft:polished_blackstone
fill 174 194 604 177 201 604 minecraft:polished_blackstone
fill 175 194 646 178 201 646 minecraft:polished_blackstone
fill 183 194 605 183 201 608 minecraft:polished_blackstone
fill 183 194 615 183 201 618 minecraft:polished_blackstone
fill 183 194 625 183 201 628 minecraft:polished_blackstone
fill 183 194 635 183 201 638 minecraft:polished_blackstone
fill 183 194 645 183 201 645 minecraft:polished_blackstone
setblock 142 198 607 minecraft:iron_block
fill 142 198 609 142 198 612 minecraft:iron_block
setblock 142 198 617 minecraft:iron_block
fill 142 198 619 142 198 622 minecraft:iron_block
setblock 142 198 627 minecraft:iron_block
fill 142 198 629 142 198 632 minecraft:iron_block
setblock 142 198 637 minecraft:iron_block
fill 142 198 639 142 198 642 minecraft:iron_block
fill 143 198 605 146 198 605 minecraft:iron_block
setblock 144 198 645 minecraft:iron_block
fill 146 198 645 149 198 645 minecraft:iron_block
setblock 148 198 605 minecraft:iron_block
fill 153 198 605 156 198 605 minecraft:iron_block
setblock 154 198 645 minecraft:iron_block
setblock 156 198 640 minecraft:iron_block
setblock 156 198 642 minecraft:iron_block
fill 156 198 645 159 198 645 minecraft:iron_block
setblock 158 198 605 minecraft:iron_block
setblock 158 198 640 minecraft:iron_block
setblock 158 198 642 minecraft:iron_block
fill 163 198 605 166 198 605 minecraft:iron_block
setblock 164 198 645 minecraft:iron_block
fill 166 198 645 169 198 645 minecraft:iron_block
setblock 168 198 605 minecraft:iron_block
fill 173 198 605 176 198 605 minecraft:iron_block
setblock 174 198 645 minecraft:iron_block
fill 176 198 645 179 198 645 minecraft:iron_block
setblock 178 198 605 minecraft:iron_block
fill 182 198 606 182 198 609 minecraft:iron_block
setblock 182 198 611 minecraft:iron_block
fill 182 198 616 182 198 619 minecraft:iron_block
setblock 182 198 621 minecraft:iron_block
fill 182 198 626 182 198 629 minecraft:iron_block
setblock 182 198 631 minecraft:iron_block
fill 182 198 636 182 198 639 minecraft:iron_block
setblock 182 198 641 minecraft:iron_block
setblock 144 199 607 minecraft:light[level=14]
setblock 144 199 615 minecraft:light[level=14]
setblock 144 199 623 minecraft:light[level=14]
setblock 144 199 631 minecraft:light[level=14]
setblock 144 199 639 minecraft:light[level=14]
setblock 152 199 607 minecraft:light[level=14]
setblock 152 199 615 minecraft:light[level=14]
setblock 152 199 623 minecraft:light[level=14]
setblock 152 199 631 minecraft:light[level=14]
setblock 152 199 639 minecraft:light[level=14]
setblock 160 199 607 minecraft:light[level=14]
setblock 160 199 615 minecraft:light[level=14]
setblock 160 199 623 minecraft:light[level=14]
setblock 160 199 631 minecraft:light[level=14]
setblock 160 199 639 minecraft:light[level=14]
setblock 168 199 607 minecraft:light[level=14]
setblock 168 199 615 minecraft:light[level=14]
setblock 168 199 623 minecraft:light[level=14]
setblock 168 199 631 minecraft:light[level=14]
setblock 168 199 639 minecraft:light[level=14]
setblock 176 199 607 minecraft:light[level=14]
setblock 176 199 615 minecraft:light[level=14]
setblock 176 199 623 minecraft:light[level=14]
setblock 176 199 631 minecraft:light[level=14]
setblock 176 199 639 minecraft:light[level=14]
fill 141 202 610 141 202 613 minecraft:sea_lantern
fill 141 202 620 141 202 623 minecraft:sea_lantern
fill 141 202 630 141 202 633 minecraft:sea_lantern
fill 141 202 640 141 202 643 minecraft:sea_lantern
fill 144 202 604 147 202 604 minecraft:sea_lantern
fill 145 202 646 148 202 646 minecraft:sea_lantern
fill 154 202 604 157 202 604 minecraft:sea_lantern
fill 155 202 646 158 202 646 minecraft:sea_lantern
fill 164 202 604 167 202 604 minecraft:sea_lantern
fill 165 202 646 168 202 646 minecraft:sea_lantern
fill 174 202 604 177 202 604 minecraft:sea_lantern
fill 175 202 646 178 202 646 minecraft:sea_lantern
fill 177 202 642 177 203 644 minecraft:iron_block
fill 183 202 605 183 202 608 minecraft:sea_lantern
fill 183 202 615 183 202 618 minecraft:sea_lantern
fill 183 202 625 183 202 628 minecraft:sea_lantern
fill 183 202 635 183 202 638 minecraft:sea_lantern
setblock 183 202 645 minecraft:sea_lantern
fill 141 203 610 141 208 613 minecraft:polished_blackstone
fill 141 203 620 141 208 623 minecraft:polished_blackstone
fill 141 203 630 141 210 633 minecraft:polished_blackstone
fill 141 203 640 141 210 643 minecraft:polished_blackstone
fill 144 203 604 147 209 604 minecraft:polished_blackstone
fill 145 203 646 148 210 646 minecraft:polished_blackstone
fill 154 203 604 157 210 604 minecraft:polished_blackstone
fill 155 203 646 158 208 646 minecraft:polished_blackstone
setblock 156 203 640 minecraft:iron_block
setblock 156 203 642 minecraft:iron_block
setblock 158 203 640 minecraft:iron_block
setblock 158 203 642 minecraft:iron_block
fill 164 203 604 167 210 604 minecraft:polished_blackstone
fill 165 203 646 168 208 646 minecraft:polished_blackstone
fill 174 203 604 177 208 604 minecraft:polished_blackstone
fill 175 203 646 178 210 646 minecraft:polished_blackstone
fill 183 203 605 183 210 608 minecraft:polished_blackstone
fill 183 203 615 183 210 618 minecraft:polished_blackstone
fill 183 203 625 183 209 628 minecraft:polished_blackstone
fill 183 203 635 183 208 638 minecraft:polished_blackstone
fill 183 203 645 183 210 645 minecraft:polished_blackstone
setblock 142 204 607 minecraft:iron_block
setblock 142 204 617 minecraft:iron_block
setblock 142 204 627 minecraft:iron_block
setblock 142 204 637 minecraft:iron_block
setblock 144 204 645 minecraft:iron_block
setblock 148 204 605 minecraft:iron_block
setblock 154 204 645 minecraft:iron_block
setblock 158 204 605 minecraft:iron_block
setblock 164 204 645 minecraft:iron_block
setblock 168 204 605 minecraft:iron_block
setblock 174 204 645 minecraft:iron_block
setblock 178 204 605 minecraft:iron_block
setblock 182 204 611 minecraft:iron_block
setblock 182 204 621 minecraft:iron_block
setblock 182 204 631 minecraft:iron_block
setblock 182 204 641 minecraft:iron_block
fill 152 206 638 155 207 642 minecraft:netherite_block
fill 154 206 643 154 206 644 minecraft:netherite_block
fill 156 206 638 156 207 640 minecraft:netherite_block
fill 156 206 642 156 207 642 minecraft:netherite_block
fill 142 207 609 142 207 612 minecraft:iron_block
fill 142 207 619 142 207 622 minecraft:iron_block
fill 142 207 629 142 207 632 minecraft:iron_block
fill 142 207 639 142 207 642 minecraft:iron_block
fill 143 207 605 146 207 605 minecraft:iron_block
setblock 144 207 607 minecraft:light[level=14]
setblock 144 207 615 minecraft:light[level=14]
setblock 144 207 623 minecraft:light[level=14]
setblock 144 207 631 minecraft:light[level=14]
setblock 144 207 639 minecraft:light[level=14]
fill 146 207 645 149 207 645 minecraft:iron_block
setblock 152 207 607 minecraft:light[level=14]
setblock 152 207 615 minecraft:light[level=14]
setblock 152 207 623 minecraft:light[level=14]
setblock 152 207 631 minecraft:light[level=14]
fill 153 207 605 156 207 605 minecraft:iron_block
fill 156 207 645 159 207 645 minecraft:iron_block
setblock 160 207 607 minecraft:light[level=14]
setblock 160 207 615 minecraft:light[level=14]
setblock 160 207 623 minecraft:light[level=14]
setblock 160 207 631 minecraft:light[level=14]
setblock 160 207 639 minecraft:light[level=14]
fill 163 207 605 166 207 605 minecraft:iron_block
fill 166 207 645 169 207 645 minecraft:iron_block
setblock 168 207 607 minecraft:light[level=14]
setblock 168 207 615 minecraft:light[level=14]
setblock 168 207 623 minecraft:light[level=14]
setblock 168 207 631 minecraft:light[level=14]
setblock 168 207 639 minecraft:light[level=14]
fill 173 207 605 176 207 605 minecraft:iron_block
setblock 176 207 607 minecraft:light[level=14]
setblock 176 207 615 minecraft:light[level=14]
setblock 176 207 623 minecraft:light[level=14]
setblock 176 207 631 minecraft:light[level=14]
setblock 176 207 639 minecraft:light[level=14]
fill 176 207 645 179 207 645 minecraft:iron_block
fill 182 207 606 182 207 609 minecraft:iron_block
fill 182 207 616 182 207 619 minecraft:iron_block
fill 182 207 626 182 207 629 minecraft:iron_block
fill 182 207 636 182 207 639 minecraft:iron_block
setblock 156 208 640 minecraft:iron_block
setblock 156 208 642 minecraft:iron_block
setblock 158 208 640 minecraft:iron_block
setblock 158 208 642 minecraft:iron_block
fill 141 209 610 141 209 611 minecraft:polished_blackstone
fill 141 209 612 141 210 612 minecraft:netherite_block
fill 141 209 613 141 210 616 minecraft:polished_blackstone
fill 141 209 617 141 210 617 minecraft:netherite_block
fill 141 209 620 141 210 620 minecraft:polished_blackstone
fill 141 209 621 141 210 621 minecraft:netherite_block
fill 141 209 622 141 210 623 minecraft:polished_blackstone
fill 141 209 634 141 209 635 minecraft:polished_blackstone
fill 141 209 636 141 210 636 minecraft:netherite_block
fill 141 209 637 141 209 639 minecraft:polished_blackstone
fill 155 209 646 155 210 646 minecraft:polished_blackstone
setblock 156 209 646 minecraft:netherite_block
fill 157 209 646 158 210 646 minecraft:polished_blackstone
setblock 165 209 646 minecraft:netherite_block
fill 166 209 646 168 209 646 minecraft:polished_blackstone
fill 170 209 604 170 210 604 minecraft:netherite_block
fill 171 209 604 173 212 604 minecraft:polished_blackstone
fill 174 209 604 174 210 604 minecraft:netherite_block
fill 175 209 604 177 210 604 minecraft:polished_blackstone
fill 178 209 604 179 209 604 minecraft:netherite_block
fill 180 209 604 183 209 604 minecraft:polished_blackstone
setblock 180 209 646 minecraft:netherite_block
fill 182 209 646 182 212 646 minecraft:polished_blackstone
fill 183 209 621 183 212 621 minecraft:polished_blackstone
setblock 183 209 622 minecraft:netherite_block
fill 183 209 623 183 212 624 minecraft:polished_blackstone
fill 183 209 631 183 212 633 minecraft:polished_blackstone
setblock 183 209 634 minecraft:netherite_block
fill 183 209 635 183 210 637 minecraft:polished_blackstone
setblock 183 209 638 minecraft:netherite_block
fill 183 209 639 183 212 639 minecraft:polished_blackstone
setblock 183 209 640 minecraft:netherite_block
fill 183 209 641 183 212 644 minecraft:polished_blackstone
setblock 183 209 646 minecraft:netherite_block
fill 141 210 604 142 212 604 minecraft:polished_blackstone
setblock 141 210 605 minecraft:netherite_block
setblock 141 210 610 minecraft:polished_blackstone
setblock 141 210 611 minecraft:netherite_block
fill 141 210 634 141 212 634 minecraft:polished_blackstone
fill 141 210 635 141 211 635 minecraft:netherite_block
fill 141 210 637 141 212 637 minecraft:polished_blackstone
setblock 141 210 638 minecraft:netherite_block
setblock 141 210 639 minecraft:polished_blackstone
fill 141 210 646 141 211 646 minecraft:netherite_block
setblock 142 210 607 minecraft:iron_block
setblock 142 210 617 minecraft:iron_block
setblock 142 210 627 minecraft:iron_block
setblock 142 210 637 minecraft:iron_block
setblock 143 210 604 minecraft:netherite_block
fill 144 210 604 146 210 604 minecraft:polished_blackstone
setblock 144 210 645 minecraft:iron_block
setblock 147 210 604 minecraft:netherite_block
setblock 148 210 605 minecraft:iron_block
setblock 154 210 645 minecraft:iron_block
setblock 156 210 646 minecraft:polished_blackstone
setblock 158 210 605 minecraft:iron_block
fill 159 210 646 160 212 646 minecraft:polished_blackstone
setblock 161 210 646 minecraft:netherite_block
setblock 164 210 645 minecraft:iron_block
setblock 165 210 646 minecraft:polished_blackstone
setblock 166 210 646 minecraft:netherite_block
fill 167 210 646 168 210 646 minecraft:polished_blackstone
setblock 168 210 605 minecraft:iron_block
setblock 174 210 645 minecraft:iron_block
fill 178 210 604 182 210 604 minecraft:polished_blackstone
setblock 178 210 605 minecraft:iron_block
fill 180 210 646 180 212 646 minecraft:polished_blackstone
setblock 182 210 611 minecraft:iron_block
setblock 182 210 621 minecraft:iron_block
setblock 182 210 631 minecraft:iron_block
setblock 182 210 641 minecraft:iron_block
setblock 183 210 604 minecraft:netherite_block
fill 183 210 622 183 212 622 minecraft:polished_blackstone
setblock 183 210 625 minecraft:netherite_block
fill 183 210 626 183 210 628 minecraft:polished_blackstone
fill 183 210 634 183 212 634 minecraft:polished_blackstone
setblock 183 210 638 minecraft:polished_blackstone
fill 183 210 640 183 212 640 minecraft:polished_blackstone
fill 183 210 646 183 212 646 minecraft:polished_blackstone
fill 141 211 605 141 212 606 minecraft:polished_blackstone
fill 141 211 607 141 211 609 minecraft:netherite_block
fill 141 211 610 141 211 613 minecraft:sea_lantern
setblock 141 211 614 minecraft:netherite_block
fill 141 211 615 141 212 617 minecraft:polished_blackstone
fill 141 211 620 141 211 623 minecraft:sea_lantern
fill 141 211 630 141 211 633 minecraft:sea_lantern
fill 141 211 636 141 212 636 minecraft:polished_blackstone
fill 141 211 638 141 212 638 minecraft:polished_blackstone
setblock 141 211 639 minecraft:netherite_block
fill 141 211 640 141 211 643 minecraft:sea_lantern
fill 143 211 604 143 212 604 minecraft:polished_blackstone
fill 144 211 604 147 211 604 minecraft:sea_lantern
fill 145 211 646 148 211 646 minecraft:sea_lantern
fill 149 211 604 151 212 604 minecraft:polished_blackstone
fill 149 211 646 150 212 646 minecraft:polished_blackstone
fill 151 211 638 151 212 642 minecraft:iron_block
setblock 151 211 646 minecraft:netherite_block
setblock 152 211 604 minecraft:netherite_block
fill 152 211 637 152 212 638 minecraft:iron_block
fill 152 211 640 156 212 640 minecraft:iron_block
fill 152 211 642 152 212 643 minecraft:iron_block
fill 153 211 637 156 212 637 minecraft:iron_block
fill 153 211 643 156 212 643 minecraft:iron_block
fill 154 211 604 157 211 604 minecraft:sea_lantern
fill 154 211 638 154 212 639 minecraft:iron_block
fill 154 211 641 154 212 642 minecraft:iron_block
fill 155 211 646 158 211 646 minecraft:sea_lantern
fill 156 211 638 157 212 638 minecraft:iron_block
fill 156 211 642 156 213 642 minecraft:iron_block
fill 157 211 639 157 212 639 minecraft:iron_block
fill 158 211 604 159 211 604 minecraft:netherite_block
fill 161 211 646 161 212 646 minecraft:polished_blackstone
fill 164 211 604 167 211 604 minecraft:sea_lantern
fill 165 211 646 168 211 646 minecraft:sea_lantern
setblock 169 211 646 minecraft:netherite_block
fill 170 211 604 170 212 604 minecraft:polished_blackstone
fill 170 211 646 171 212 646 minecraft:polished_blackstone
fill 174 211 604 177 211 604 minecraft:sea_lantern
fill 175 211 646 178 211 646 minecraft:sea_lantern
fill 178 211 604 179 212 604 minecraft:polished_blackstone
setblock 179 211 646 minecraft:netherite_block
setblock 180 211 604 minecraft:netherite_block
fill 181 211 604 183 212 604 minecraft:polished_blackstone
fill 183 211 605 183 211 608 minecraft:sea_lantern
fill 183 211 615 183 211 618 minecraft:sea_lantern
setblock 183 211 620 minecraft:netherite_block
fill 183 211 625 183 211 628 minecraft:sea_lantern
setblock 183 211 630 minecraft:netherite_block
fill 183 211 635 183 211 638 minecraft:sea_lantern
setblock 183 211 645 minecraft:sea_lantern
fill 141 212 607 141 212 614 minecraft:polished_blackstone
fill 141 212 620 141 212 623 minecraft:polished_blackstone
fill 141 212 630 141 212 633 minecraft:polished_blackstone
setblock 141 212 635 minecraft:polished_blackstone
fill 141 212 639 141 212 643 minecraft:polished_blackstone
setblock 141 212 646 minecraft:polished_blackstone
fill 144 212 604 147 212 604 minecraft:polished_blackstone
fill 145 212 646 148 212 646 minecraft:polished_blackstone
fill 151 212 646 151 213 646 minecraft:polished_blackstone
fill 152 212 604 152 213 604 minecraft:polished_blackstone
fill 154 212 604 159 212 604 minecraft:polished_blackstone
fill 155 212 646 158 212 646 minecraft:polished_blackstone
fill 164 212 604 167 212 604 minecraft:polished_blackstone
fill 165 212 646 169 212 646 minecraft:polished_blackstone
fill 174 212 604 177 212 604 minecraft:polished_blackstone
fill 175 212 646 179 212 646 minecraft:polished_blackstone
setblock 180 212 604 minecraft:polished_blackstone
fill 183 212 605 183 212 608 minecraft:polished_blackstone
fill 183 212 615 183 212 618 minecraft:polished_blackstone
setblock 183 212 620 minecraft:polished_blackstone
fill 183 212 625 183 212 628 minecraft:polished_blackstone
setblock 183 212 630 minecraft:polished_blackstone
fill 183 212 635 183 212 638 minecraft:polished_blackstone
setblock 183 212 645 minecraft:polished_blackstone
fill 141 213 604 141 307 605 minecraft:netherite_block
setblock 141 213 606 minecraft:polished_blackstone
fill 141 213 607 141 307 608 minecraft:netherite_block
fill 141 213 609 141 213 610 minecraft:polished_blackstone
fill 141 213 611 141 213 613 minecraft:netherite_block
setblock 141 213 614 minecraft:polished_blackstone
fill 141 213 615 141 219 620 minecraft:netherite_block
fill 141 213 621 141 213 623 minecraft:polished_blackstone
fill 141 213 624 141 219 630 minecraft:netherite_block
setblock 141 213 631 minecraft:polished_blackstone
fill 141 213 632 141 213 642 minecraft:netherite_block
setblock 141 213 643 minecraft:polished_blackstone
fill 141 213 644 141 307 646 minecraft:netherite_block
fill 142 213 604 151 213 604 minecraft:netherite_block
fill 142 213 646 146 214 646 minecraft:netherite_block
setblock 147 213 646 minecraft:polished_blackstone
fill 148 213 646 150 219 646 minecraft:netherite_block
fill 152 213 646 157 219 646 minecraft:netherite_block
fill 153 213 604 177 213 604 minecraft:netherite_block
setblock 156 213 640 minecraft:iron_block
setblock 158 213 640 minecraft:iron_block
setblock 158 213 642 minecraft:iron_block
setblock 158 213 646 minecraft:polished_blackstone
fill 159 213 646 175 213 646 minecraft:netherite_block
fill 176 213 646 177 213 646 minecraft:polished_blackstone
setblock 178 213 604 minecraft:polished_blackstone
fill 178 213 646 183 213 646 minecraft:netherite_block
fill 179 213 604 183 214 604 minecraft:netherite_block
fill 183 213 605 183 213 612 minecraft:netherite_block
fill 183 213 614 183 213 617 minecraft:netherite_block
setblock 183 213 618 minecraft:polished_blackstone
fill 183 213 620 183 214 623 minecraft:netherite_block
setblock 183 213 624 minecraft:polished_blackstone
fill 183 213 625 183 219 627 minecraft:netherite_block
setblock 183 213 628 minecraft:polished_blackstone
fill 183 213 629 183 214 636 minecraft:netherite_block
setblock 183 213 637 minecraft:polished_blackstone
fill 183 213 638 183 213 641 minecraft:netherite_block
setblock 183 213 642 minecraft:polished_blackstone
fill 183 213 643 183 214 645 minecraft:netherite_block
fill 141 214 606 141 307 606 minecraft:netherite_block
setblock 141 214 609 minecraft:netherite_block
fill 141 214 610 141 214 611 minecraft:polished_blackstone
fill 141 214 612 141 219 614 minecraft:netherite_block
fill 141 214 621 141 219 623 minecraft:netherite_block
fill 141 214 631 141 214 637 minecraft:netherite_block
fill 141 214 638 141 214 639 minecraft:polished_blackstone
fill 141 214 640 141 214 643 minecraft:netherite_block
setblock 142 214 604 minecraft:polished_blackstone
fill 143 214 604 147 214 604 minecraft:netherite_block
fill 147 214 646 147 219 646 minecraft:netherite_block
setblock 148 214 604 minecraft:polished_blackstone
fill 149 214 604 155 214 604 minecraft:netherite_block
setblock 151 214 646 minecraft:netherite_block
fill 156 214 604 157 214 604 minecraft:polished_blackstone
fill 158 214 604 161 214 604 minecraft:netherite_block
fill 158 214 646 159 219 646 minecraft:netherite_block
setblock 160 214 646 minecraft:polished_blackstone
fill 161 214 646 162 307 646 minecraft:netherite_block
setblock 162 214 604 minecraft:polished_blackstone
fill 163 214 604 165 214 604 minecraft:netherite_block
setblock 163 214 646 minecraft:polished_blackstone
fill 164 214 646 173 214 646 minecraft:netherite_block
setblock 166 214 604 minecraft:polished_blackstone
fill 167 214 604 178 214 604 minecraft:netherite_block
setblock 174 214 646 minecraft:polished_blackstone
fill 175 214 646 178 219 646 minecraft:netherite_block
fill 179 214 646 180 214 646 minecraft:polished_blackstone
fill 181 214 646 183 307 646 minecraft:netherite_block
fill 183 214 605 183 214 607 minecraft:netherite_block
fill 183 214 608 183 214 609 minecraft:polished_blackstone
fill 183 214 610 183 307 610 minecraft:netherite_block
setblock 183 214 611 minecraft:polished_blackstone
fill 183 214 612 183 214 616 minecraft:netherite_block
setblock 183 214 617 minecraft:polished_blackstone
fill 183 214 618 183 219 619 minecraft:netherite_block
fill 183 214 624 183 307 624 minecraft:netherite_block
fill 183 214 628 183 219 628 minecraft:netherite_block
fill 183 214 637 183 219 637 minecraft:netherite_block
setblock 183 214 638 minecraft:polished_blackstone
fill 183 214 639 183 307 642 minecraft:netherite_block
setblock 141 215 609 minecraft:polished_blackstone
fill 141 215 610 141 219 611 minecraft:netherite_block
fill 141 215 631 141 219 633 minecraft:netherite_block
setblock 141 215 634 minecraft:polished_blackstone
fill 141 215 635 141 219 641 minecraft:netherite_block
setblock 141 215 642 minecraft:polished_blackstone
fill 141 215 643 141 219 643 minecraft:netherite_block
fill 142 215 604 142 307 604 minecraft:netherite_block
fill 142 215 646 143 307 646 minecraft:netherite_block
setblock 143 215 604 minecraft:polished_blackstone
fill 144 215 604 149 219 604 minecraft:netherite_block
setblock 144 215 607 minecraft:light[level=14]
setblock 144 215 615 minecraft:light[level=14]
setblock 144 215 623 minecraft:light[level=14]
setblock 144 215 631 minecraft:light[level=14]
setblock 144 215 639 minecraft:light[level=14]
setblock 144 215 646 minecraft:polished_blackstone
fill 145 215 646 146 219 646 minecraft:netherite_block
setblock 150 215 604 minecraft:polished_blackstone
fill 151 215 604 153 307 604 minecraft:netherite_block
setblock 151 215 646 minecraft:polished_blackstone
setblock 152 215 607 minecraft:light[level=14]
setblock 152 215 615 minecraft:light[level=14]
setblock 152 215 623 minecraft:light[level=14]
setblock 152 215 631 minecraft:light[level=14]
setblock 152 215 639 minecraft:light[level=14]
setblock 154 215 604 minecraft:polished_blackstone
fill 155 215 604 160 219 604 minecraft:netherite_block
setblock 160 215 607 minecraft:light[level=14]
setblock 160 215 615 minecraft:light[level=14]
setblock 160 215 623 minecraft:light[level=14]
setblock 160 215 631 minecraft:light[level=14]
setblock 160 215 639 minecraft:light[level=14]
fill 160 215 646 160 307 646 minecraft:netherite_block
setblock 161 215 604 minecraft:polished_blackstone
fill 162 215 604 164 219 604 minecraft:netherite_block
fill 163 215 646 164 307 646 minecraft:netherite_block
setblock 165 215 604 minecraft:polished_blackstone
setblock 165 215 646 minecraft:polished_blackstone
fill 166 215 604 175 219 604 minecraft:netherite_block
fill 166 215 646 174 219 646 minecraft:netherite_block
setblock 168 215 607 minecraft:light[level=14]
setblock 168 215 615 minecraft:light[level=14]
setblock 168 215 623 minecraft:light[level=14]
setblock 168 215 631 minecraft:light[level=14]
setblock 168 215 639 minecraft:light[level=14]
setblock 176 215 604 minecraft:polished_blackstone
setblock 176 215 607 minecraft:light[level=14]
setblock 176 215 615 minecraft:light[level=14]
setblock 176 215 623 minecraft:light[level=14]
setblock 176 215 631 minecraft:light[level=14]
setblock 176 215 639 minecraft:light[level=14]
fill 177 215 604 178 219 604 minecraft:netherite_block
setblock 179 215 604 minecraft:polished_blackstone
setblock 179 215 646 minecraft:polished_blackstone
fill 180 215 604 183 307 604 minecraft:netherite_block
fill 180 215 646 180 307 646 minecraft:netherite_block
fill 183 215 605 183 219 605 minecraft:netherite_block
setblock 183 215 606 minecraft:polished_blackstone
fill 183 215 607 183 219 608 minecraft:netherite_block
setblock 183 215 609 minecraft:polished_blackstone
fill 183 215 611 183 307 611 minecraft:netherite_block
setblock 183 215 612 minecraft:polished_blackstone
fill 183 215 613 183 219 617 minecraft:netherite_block
fill 183 215 620 183 307 622 minecraft:netherite_block
setblock 183 215 623 minecraft:polished_blackstone
fill 183 215 629 183 307 630 minecraft:netherite_block
setblock 183 215 631 minecraft:polished_blackstone
fill 183 215 632 183 307 633 minecraft:netherite_block
setblock 183 215 634 minecraft:polished_blackstone
fill 183 215 635 183 219 636 minecraft:netherite_block
fill 183 215 638 183 219 638 minecraft:netherite_block
fill 183 215 643 183 307 643 minecraft:netherite_block
setblock 183 215 644 minecraft:polished_blackstone
fill 183 215 645 183 219 645 minecraft:netherite_block
fill 141 216 609 141 307 609 minecraft:netherite_block
fill 141 216 634 141 307 634 minecraft:netherite_block
fill 141 216 642 141 219 642 minecraft:netherite_block
setblock 142 216 607 minecraft:iron_block
fill 142 216 609 142 216 612 minecraft:iron_block
setblock 142 216 617 minecraft:iron_block
fill 142 216 619 142 216 622 minecraft:iron_block
setblock 142 216 627 minecraft:iron_block
fill 142 216 629 142 216 632 minecraft:iron_block
setblock 142 216 637 minecraft:iron_block
fill 142 216 639 142 216 642 minecraft:iron_block
fill 143 216 604 143 307 604 minecraft:netherite_block
fill 143 216 605 146 216 605 minecraft:iron_block
setblock 144 216 645 minecraft:iron_block
fill 144 216 646 144 307 646 minecraft:netherite_block
fill 146 216 645 149 216 645 minecraft:iron_block
setblock 148 216 605 minecraft:iron_block
fill 150 216 604 150 307 604 minecraft:netherite_block
fill 151 216 646 151 307 646 minecraft:netherite_block
fill 153 216 605 156 216 605 minecraft:iron_block
fill 154 216 604 154 219 604 minecraft:netherite_block
setblock 154 216 645 minecraft:iron_block
fill 156 216 645 159 216 645 minecraft:iron_block
fill 157 216 643 157 217 644 minecraft:iron_block
setblock 158 216 605 minecraft:iron_block
fill 161 216 604 161 307 604 minecraft:netherite_block
fill 163 216 605 166 216 605 minecraft:iron_block
setblock 164 216 645 minecraft:iron_block
fill 165 216 604 165 219 604 minecraft:netherite_block
fill 165 216 646 165 219 646 minecraft:netherite_block
fill 166 216 645 169 216 645 minecraft:iron_block
setblock 168 216 605 minecraft:iron_block
fill 173 216 605 176 216 605 minecraft:iron_block
setblock 174 216 645 minecraft:iron_block
fill 176 216 604 176 219 604 minecraft:netherite_block
fill 176 216 645 179 216 645 minecraft:iron_block
setblock 178 216 605 minecraft:iron_block
fill 179 216 604 179 307 604 minecraft:netherite_block
fill 179 216 646 179 307 646 minecraft:netherite_block
fill 182 216 606 182 216 609 minecraft:iron_block
setblock 182 216 611 minecraft:iron_block
fill 182 216 616 182 216 619 minecraft:iron_block
setblock 182 216 621 minecraft:iron_block
fill 182 216 626 182 216 629 minecraft:iron_block
setblock 182 216 631 minecraft:iron_block
fill 182 216 636 182 216 639 minecraft:iron_block
setblock 182 216 641 minecraft:iron_block
fill 183 216 606 183 219 606 minecraft:netherite_block
fill 183 216 609 183 307 609 minecraft:netherite_block
fill 183 216 612 183 307 612 minecraft:netherite_block
fill 183 216 623 183 307 623 minecraft:netherite_block
fill 183 216 631 183 307 631 minecraft:netherite_block
fill 183 216 634 183 307 634 minecraft:netherite_block
fill 183 216 644 183 307 644 minecraft:netherite_block
setblock 157 217 639 minecraft:sea_lantern
setblock 156 218 640 minecraft:iron_block
setblock 156 218 642 minecraft:iron_block
setblock 158 218 640 minecraft:iron_block
setblock 158 218 642 minecraft:iron_block
fill 141 220 610 141 220 613 minecraft:sea_lantern
fill 141 220 614 141 307 619 minecraft:netherite_block
fill 141 220 620 141 220 623 minecraft:sea_lantern
fill 141 220 624 141 307 629 minecraft:netherite_block
fill 141 220 630 141 220 633 minecraft:sea_lantern
fill 141 220 635 141 307 639 minecraft:netherite_block
fill 141 220 640 141 220 643 minecraft:sea_lantern
fill 144 220 604 147 220 604 minecraft:sea_lantern
fill 145 220 646 148 220 646 minecraft:sea_lantern
fill 148 220 604 149 307 604 minecraft:netherite_block
fill 149 220 646 150 307 646 minecraft:netherite_block
fill 152 220 646 154 307 646 minecraft:netherite_block
fill 154 220 604 157 220 604 minecraft:sea_lantern
fill 155 220 646 158 220 646 minecraft:sea_lantern
fill 158 220 604 160 307 604 minecraft:netherite_block
fill 159 220 646 159 307 646 minecraft:netherite_block
fill 162 220 604 163 307 604 minecraft:netherite_block
fill 164 220 604 167 220 604 minecraft:sea_lantern
fill 165 220 646 168 220 646 minecraft:sea_lantern
fill 168 220 604 173 307 604 minecraft:netherite_block
fill 169 220 646 174 307 646 minecraft:netherite_block
fill 174 220 604 177 220 604 minecraft:sea_lantern
fill 175 220 646 178 220 646 minecraft:sea_lantern
fill 178 220 604 178 307 604 minecraft:netherite_block
fill 183 220 605 183 220 608 minecraft:sea_lantern
fill 183 220 613 183 307 614 minecraft:netherite_block
fill 183 220 615 183 220 618 minecraft:sea_lantern
fill 183 220 619 183 307 619 minecraft:netherite_block
fill 183 220 625 183 220 628 minecraft:sea_lantern
fill 183 220 635 183 220 638 minecraft:sea_lantern
setblock 183 220 645 minecraft:sea_lantern
fill 141 221 610 141 228 613 minecraft:netherite_block
fill 141 221 620 141 228 623 minecraft:netherite_block
fill 141 221 630 141 228 633 minecraft:netherite_block
fill 141 221 640 141 228 643 minecraft:netherite_block
fill 144 221 604 147 228 604 minecraft:netherite_block
fill 145 221 646 148 228 646 minecraft:netherite_block
fill 154 221 604 157 228 604 minecraft:netherite_block
fill 155 221 646 158 228 646 minecraft:netherite_block
fill 164 221 604 167 228 604 minecraft:netherite_block
fill 165 221 646 168 228 646 minecraft:netherite_block
fill 174 221 604 177 228 604 minecraft:netherite_block
fill 175 221 646 178 228 646 minecraft:netherite_block
fill 183 221 605 183 228 608 minecraft:netherite_block
fill 183 221 615 183 228 618 minecraft:netherite_block
fill 183 221 625 183 228 628 minecraft:netherite_block
fill 183 221 635 183 228 638 minecraft:netherite_block
fill 183 221 645 183 228 645 minecraft:netherite_block
setblock 142 222 607 minecraft:iron_block
setblock 142 222 617 minecraft:iron_block
setblock 142 222 627 minecraft:iron_block
setblock 142 222 637 minecraft:iron_block
setblock 144 222 645 minecraft:iron_block
setblock 148 222 605 minecraft:iron_block
setblock 154 222 645 minecraft:iron_block
setblock 158 222 605 minecraft:iron_block
setblock 164 222 645 minecraft:iron_block
setblock 168 222 605 minecraft:iron_block
setblock 174 222 645 minecraft:iron_block
fill 175 222 635 179 223 639 minecraft:netherite_block
setblock 178 222 605 minecraft:iron_block
fill 180 222 637 181 222 637 minecraft:netherite_block
setblock 182 222 611 minecraft:iron_block
setblock 182 222 621 minecraft:iron_block
setblock 182 222 631 minecraft:iron_block
setblock 182 222 641 minecraft:iron_block
setblock 144 223 607 minecraft:light[level=14]
setblock 144 223 615 minecraft:light[level=14]
setblock 144 223 623 minecraft:light[level=14]
setblock 144 223 631 minecraft:light[level=14]
setblock 144 223 639 minecraft:light[level=14]
setblock 152 223 607 minecraft:light[level=14]
setblock 152 223 615 minecraft:light[level=14]
setblock 152 223 623 minecraft:light[level=14]
setblock 152 223 631 minecraft:light[level=14]
setblock 152 223 639 minecraft:light[level=14]
setblock 156 223 640 minecraft:iron_block
setblock 156 223 642 minecraft:iron_block
setblock 158 223 640 minecraft:iron_block
setblock 158 223 642 minecraft:iron_block
setblock 160 223 607 minecraft:light[level=14]
setblock 160 223 615 minecraft:light[level=14]
setblock 160 223 623 minecraft:light[level=14]
setblock 160 223 631 minecraft:light[level=14]
setblock 160 223 639 minecraft:light[level=14]
setblock 168 223 607 minecraft:light[level=14]
setblock 168 223 615 minecraft:light[level=14]
setblock 168 223 623 minecraft:light[level=14]
setblock 168 223 631 minecraft:light[level=14]
setblock 168 223 639 minecraft:light[level=14]
setblock 176 223 607 minecraft:light[level=14]
setblock 176 223 615 minecraft:light[level=14]
setblock 176 223 623 minecraft:light[level=14]
setblock 176 223 631 minecraft:light[level=14]
fill 142 225 609 142 225 612 minecraft:iron_block
fill 142 225 619 142 225 622 minecraft:iron_block
fill 142 225 629 142 225 632 minecraft:iron_block
fill 142 225 639 142 225 642 minecraft:iron_block
fill 143 225 605 146 225 605 minecraft:iron_block
fill 146 225 645 149 225 645 minecraft:iron_block
fill 153 225 605 156 225 605 minecraft:iron_block
fill 156 225 645 159 225 645 minecraft:iron_block
fill 163 225 605 166 225 605 minecraft:iron_block
fill 166 225 645 169 225 645 minecraft:iron_block
fill 173 225 605 176 225 605 minecraft:iron_block
fill 176 225 645 179 225 645 minecraft:iron_block
fill 182 225 606 182 225 609 minecraft:iron_block
fill 182 225 616 182 225 619 minecraft:iron_block
fill 182 225 626 182 225 629 minecraft:iron_block
fill 182 225 636 182 225 639 minecraft:iron_block
fill 174 227 635 174 228 639 minecraft:iron_block
fill 175 227 634 175 228 635 minecraft:iron_block
fill 175 227 637 180 228 637 minecraft:iron_block
fill 175 227 639 175 228 640 minecraft:iron_block
fill 176 227 634 179 228 634 minecraft:iron_block
fill 176 227 640 179 228 640 minecraft:iron_block
fill 177 227 635 177 228 636 minecraft:iron_block
fill 177 227 638 177 228 639 minecraft:iron_block
fill 179 227 635 180 228 635 minecraft:iron_block
fill 179 227 639 180 228 639 minecraft:iron_block
fill 180 227 636 180 228 636 minecraft:iron_block
fill 180 227 638 180 228 638 minecraft:iron_block
setblock 142 228 607 minecraft:iron_block
setblock 142 228 617 minecraft:iron_block
setblock 142 228 627 minecraft:iron_block
setblock 142 228 637 minecraft:iron_block
setblock 144 228 645 minecraft:iron_block
setblock 148 228 605 minecraft:iron_block
setblock 154 228 645 minecraft:iron_block
setblock 156 228 640 minecraft:iron_block
setblock 156 228 642 minecraft:iron_block
setblock 158 228 605 minecraft:iron_block
setblock 158 228 640 minecraft:iron_block
setblock 158 228 642 minecraft:iron_block
setblock 164 228 645 minecraft:iron_block
setblock 168 228 605 minecraft:iron_block
setblock 174 228 645 minecraft:iron_block
setblock 178 228 605 minecraft:iron_block
setblock 182 228 611 minecraft:iron_block
setblock 182 228 621 minecraft:iron_block
setblock 182 228 631 minecraft:iron_block
setblock 182 228 641 minecraft:iron_block
fill 141 229 610 141 229 613 minecraft:sea_lantern
fill 141 229 620 141 229 623 minecraft:sea_lantern
fill 141 229 630 141 229 633 minecraft:sea_lantern
fill 141 229 640 141 229 643 minecraft:sea_lantern
fill 144 229 604 147 229 604 minecraft:sea_lantern
fill 145 229 646 148 229 646 minecraft:sea_lantern
fill 154 229 604 157 229 604 minecraft:sea_lantern
fill 155 229 646 158 229 646 minecraft:sea_lantern
fill 164 229 604 167 229 604 minecraft:sea_lantern
fill 165 229 646 168 229 646 minecraft:sea_lantern
fill 174 229 604 177 229 604 minecraft:sea_lantern
fill 175 229 646 178 229 646 minecraft:sea_lantern
fill 183 229 605 183 229 608 minecraft:sea_lantern
fill 183 229 615 183 229 618 minecraft:sea_lantern
fill 183 229 625 183 229 628 minecraft:sea_lantern
fill 183 229 635 183 229 638 minecraft:sea_lantern
setblock 183 229 645 minecraft:sea_lantern
fill 141 230 610 141 246 613 minecraft:netherite_block
fill 141 230 620 141 246 623 minecraft:netherite_block
fill 141 230 630 141 246 633 minecraft:netherite_block
fill 141 230 640 141 246 643 minecraft:netherite_block
fill 144 230 604 147 246 604 minecraft:netherite_block
fill 145 230 646 148 246 646 minecraft:netherite_block
fill 154 230 604 157 246 604 minecraft:netherite_block
fill 155 230 646 158 246 646 minecraft:netherite_block
fill 164 230 604 167 246 604 minecraft:netherite_block
fill 165 230 646 168 246 646 minecraft:netherite_block
fill 174 230 604 177 246 604 minecraft:netherite_block
fill 175 230 646 178 246 646 minecraft:netherite_block
fill 183 230 605 183 246 608 minecraft:netherite_block
fill 183 230 615 183 246 618 minecraft:netherite_block
fill 183 230 625 183 246 628 minecraft:netherite_block
fill 183 230 635 183 246 638 minecraft:netherite_block
fill 183 230 645 183 246 645 minecraft:netherite_block
setblock 144 231 607 minecraft:light[level=14]
setblock 144 231 615 minecraft:light[level=14]
setblock 144 231 623 minecraft:light[level=14]
setblock 144 231 631 minecraft:light[level=14]
setblock 144 231 639 minecraft:light[level=14]
setblock 152 231 607 minecraft:light[level=14]
setblock 152 231 615 minecraft:light[level=14]
setblock 152 231 623 minecraft:light[level=14]
setblock 152 231 631 minecraft:light[level=14]
setblock 152 231 639 minecraft:light[level=14]
setblock 160 231 607 minecraft:light[level=14]
setblock 160 231 615 minecraft:light[level=14]
setblock 160 231 623 minecraft:light[level=14]
setblock 160 231 631 minecraft:light[level=14]
setblock 160 231 639 minecraft:light[level=14]
setblock 168 231 607 minecraft:light[level=14]
setblock 168 231 615 minecraft:light[level=14]
setblock 168 231 623 minecraft:light[level=14]
setblock 168 231 631 minecraft:light[level=14]
setblock 168 231 639 minecraft:light[level=14]
setblock 176 231 607 minecraft:light[level=14]
setblock 176 231 615 minecraft:light[level=14]
setblock 176 231 623 minecraft:light[level=14]
setblock 176 231 631 minecraft:light[level=14]
setblock 176 231 639 minecraft:light[level=14]
fill 158 235 624 160 235 626 minecraft:redstone_block
fill 163 235 619 165 235 621 minecraft:redstone_block
fill 163 235 629 165 235 631 minecraft:redstone_block
fill 142 236 605 142 237 615 minecraft:netherite_block
fill 142 236 616 182 236 616 minecraft:gold_block
fill 142 236 617 142 237 627 minecraft:netherite_block
fill 142 236 628 182 236 628 minecraft:gold_block
fill 142 236 629 142 237 639 minecraft:netherite_block
fill 142 236 640 182 237 640 minecraft:gold_block
fill 142 236 641 142 237 645 minecraft:netherite_block
fill 143 236 605 143 237 615 minecraft:iron_block
fill 143 236 617 143 237 627 minecraft:iron_block
fill 143 236 629 143 237 639 minecraft:iron_block
fill 143 236 641 143 237 645 minecraft:iron_block
fill 144 236 605 144 237 615 minecraft:netherite_block
fill 144 236 617 144 237 627 minecraft:netherite_block
fill 144 236 629 144 237 639 minecraft:netherite_block
fill 144 236 641 144 237 645 minecraft:netherite_block
fill 145 236 605 145 237 615 minecraft:iron_block
fill 145 236 617 145 237 627 minecraft:iron_block
fill 145 236 629 145 237 639 minecraft:iron_block
fill 145 236 641 145 237 645 minecraft:iron_block
fill 146 236 605 146 237 615 minecraft:netherite_block
fill 146 236 617 146 237 627 minecraft:netherite_block
fill 146 236 629 146 237 639 minecraft:netherite_block
fill 146 236 641 146 237 645 minecraft:netherite_block
fill 147 236 605 147 237 615 minecraft:iron_block
fill 147 236 617 147 237 627 minecraft:iron_block
fill 147 236 629 147 237 639 minecraft:iron_block
fill 147 236 641 147 237 645 minecraft:iron_block
fill 148 236 605 148 237 615 minecraft:netherite_block
fill 148 236 617 148 237 627 minecraft:netherite_block
fill 148 236 629 148 237 639 minecraft:netherite_block
fill 148 236 641 148 237 645 minecraft:netherite_block
fill 149 236 605 149 237 615 minecraft:iron_block
fill 149 236 617 149 237 627 minecraft:iron_block
fill 149 236 629 149 237 639 minecraft:iron_block
fill 149 236 641 149 237 645 minecraft:iron_block
fill 150 236 605 150 237 615 minecraft:netherite_block
fill 150 236 617 150 237 627 minecraft:netherite_block
fill 150 236 629 150 237 639 minecraft:netherite_block
fill 150 236 641 150 237 645 minecraft:netherite_block
fill 151 236 605 151 237 615 minecraft:iron_block
fill 151 236 617 151 237 627 minecraft:iron_block
fill 151 236 629 151 237 639 minecraft:iron_block
fill 151 236 641 151 237 645 minecraft:iron_block
fill 152 236 605 152 237 615 minecraft:netherite_block
fill 152 236 617 152 236 627 minecraft:netherite_block
fill 152 236 629 152 236 639 minecraft:netherite_block
fill 152 236 641 152 237 645 minecraft:netherite_block
fill 153 236 605 153 237 615 minecraft:iron_block
fill 153 236 617 153 237 627 minecraft:iron_block
fill 153 236 629 153 237 639 minecraft:iron_block
fill 153 236 641 153 237 645 minecraft:iron_block
fill 154 236 605 154 237 615 minecraft:netherite_block
fill 154 236 617 154 236 627 minecraft:netherite_block
fill 154 236 629 154 236 639 minecraft:netherite_block
fill 154 236 641 154 237 645 minecraft:netherite_block
fill 155 236 605 155 237 615 minecraft:iron_block
fill 155 236 617 155 237 627 minecraft:iron_block
fill 155 236 629 155 237 639 minecraft:iron_block
fill 155 236 641 155 237 645 minecraft:iron_block
fill 156 236 605 156 236 615 minecraft:netherite_block
fill 156 236 617 156 236 627 minecraft:netherite_block
fill 156 236 629 156 236 639 minecraft:netherite_block
fill 156 236 641 156 237 645 minecraft:netherite_block
fill 157 236 605 157 237 615 minecraft:iron_block
fill 157 236 617 157 238 627 minecraft:iron_block
fill 157 236 629 157 237 639 minecraft:iron_block
fill 157 236 641 157 237 645 minecraft:iron_block
fill 158 236 605 158 237 615 minecraft:netherite_block
fill 158 236 617 158 236 623 minecraft:netherite_block
setblock 158 236 627 minecraft:netherite_block
fill 158 236 629 158 236 639 minecraft:netherite_block
fill 158 236 641 158 237 645 minecraft:netherite_block
fill 159 236 605 159 237 615 minecraft:iron_block
fill 159 236 617 159 238 623 minecraft:iron_block
fill 159 236 627 159 238 627 minecraft:iron_block
fill 159 236 629 159 237 639 minecraft:iron_block
fill 159 236 641 159 237 645 minecraft:iron_block
fill 160 236 605 160 236 615 minecraft:netherite_block
fill 160 236 617 160 236 623 minecraft:netherite_block
setblock 160 236 627 minecraft:netherite_block
fill 160 236 629 160 236 639 minecraft:netherite_block
fill 160 236 641 160 237 645 minecraft:netherite_block
fill 161 236 605 161 237 615 minecraft:iron_block
fill 161 236 617 161 236 627 minecraft:iron_block
fill 161 236 629 161 237 639 minecraft:iron_block
fill 161 236 641 161 237 645 minecraft:iron_block
fill 162 236 605 162 236 615 minecraft:netherite_block
fill 162 236 617 162 236 627 minecraft:netherite_block
fill 162 236 629 162 236 639 minecraft:netherite_block
fill 162 236 641 162 237 645 minecraft:netherite_block
fill 163 236 605 163 237 615 minecraft:iron_block
fill 163 236 617 163 238 618 minecraft:iron_block
fill 163 236 622 163 236 623 minecraft:iron_block
setblock 163 236 627 minecraft:iron_block
fill 163 236 632 163 237 639 minecraft:iron_block
fill 163 236 641 163 237 645 minecraft:iron_block
fill 164 236 605 164 236 615 minecraft:netherite_block
fill 164 236 617 164 236 618 minecraft:netherite_block
fill 164 236 622 164 236 623 minecraft:netherite_block
setblock 164 236 627 minecraft:netherite_block
fill 164 236 632 164 236 639 minecraft:netherite_block
fill 164 236 641 164 237 645 minecraft:netherite_block
fill 165 236 605 165 237 615 minecraft:iron_block
fill 165 236 617 165 238 618 minecraft:iron_block
fill 165 236 622 165 236 623 minecraft:iron_block
setblock 165 236 627 minecraft:iron_block
fill 165 236 632 165 237 639 minecraft:iron_block
fill 165 236 641 165 237 645 minecraft:iron_block
fill 166 236 605 166 236 615 minecraft:netherite_block
fill 166 236 617 166 236 627 minecraft:netherite_block
fill 166 236 629 166 236 639 minecraft:netherite_block
fill 166 236 641 166 237 645 minecraft:netherite_block
fill 167 236 605 167 237 615 minecraft:iron_block
fill 167 236 617 167 236 627 minecraft:iron_block
fill 167 236 629 167 237 639 minecraft:iron_block
fill 167 236 641 167 237 645 minecraft:iron_block
fill 168 236 605 168 236 615 minecraft:netherite_block
fill 168 236 617 168 236 627 minecraft:netherite_block
fill 168 236 629 168 236 639 minecraft:netherite_block
fill 168 236 641 168 237 645 minecraft:netherite_block
fill 169 236 605 169 237 615 minecraft:iron_block
fill 169 236 617 169 238 627 minecraft:iron_block
fill 169 236 629 169 237 639 minecraft:iron_block
fill 169 236 641 169 237 645 minecraft:iron_block
fill 170 236 605 170 237 615 minecraft:netherite_block
fill 170 236 617 170 236 627 minecraft:netherite_block
fill 170 236 629 170 236 639 minecraft:netherite_block
fill 170 236 641 170 237 645 minecraft:netherite_block
fill 171 236 605 171 237 615 minecraft:iron_block
fill 171 236 617 171 238 627 minecraft:iron_block
fill 171 236 629 171 237 639 minecraft:iron_block
fill 171 236 641 171 237 645 minecraft:iron_block
fill 172 236 605 172 236 615 minecraft:netherite_block
fill 172 236 617 172 236 627 minecraft:netherite_block
fill 172 236 629 172 236 639 minecraft:netherite_block
fill 172 236 641 172 237 645 minecraft:netherite_block
fill 173 236 605 173 237 615 minecraft:iron_block
fill 173 236 617 173 237 627 minecraft:iron_block
fill 173 236 629 173 237 639 minecraft:iron_block
fill 173 236 641 173 237 645 minecraft:iron_block
fill 174 236 605 174 237 615 minecraft:netherite_block
fill 174 236 617 174 236 627 minecraft:netherite_block
fill 174 236 629 174 236 639 minecraft:netherite_block
fill 174 236 641 174 237 645 minecraft:netherite_block
fill 175 236 605 175 237 615 minecraft:iron_block
fill 175 236 617 175 237 627 minecraft:iron_block
fill 175 236 629 175 237 639 minecraft:iron_block
fill 175 236 641 175 237 645 minecraft:iron_block
fill 176 236 605 176 237 615 minecraft:netherite_block
fill 176 236 617 176 236 627 minecraft:netherite_block
fill 176 236 629 176 236 639 minecraft:netherite_block
fill 176 236 641 176 237 645 minecraft:netherite_block
fill 177 236 605 177 237 615 minecraft:iron_block
fill 177 236 617 177 237 627 minecraft:iron_block
fill 177 236 629 177 237 639 minecraft:iron_block
fill 177 236 641 177 237 645 minecraft:iron_block
fill 178 236 605 178 237 615 minecraft:netherite_block
fill 178 236 617 178 237 627 minecraft:netherite_block
fill 178 236 629 178 237 639 minecraft:netherite_block
fill 178 236 641 178 237 645 minecraft:netherite_block
fill 179 236 605 179 237 615 minecraft:iron_block
fill 179 236 617 179 237 627 minecraft:iron_block
fill 179 236 629 179 237 639 minecraft:iron_block
fill 179 236 641 179 237 645 minecraft:iron_block
fill 180 236 605 180 237 615 minecraft:netherite_block
fill 180 236 617 180 237 627 minecraft:netherite_block
fill 180 236 629 180 237 639 minecraft:netherite_block
fill 180 236 641 180 237 645 minecraft:netherite_block
fill 181 236 605 181 237 615 minecraft:iron_block
fill 181 236 617 181 237 627 minecraft:iron_block
fill 181 236 629 181 237 639 minecraft:iron_block
fill 181 236 641 181 237 645 minecraft:iron_block
fill 182 236 605 182 237 615 minecraft:netherite_block
fill 182 236 617 182 237 627 minecraft:netherite_block
fill 182 236 629 182 237 639 minecraft:netherite_block
fill 182 236 641 182 237 645 minecraft:netherite_block
fill 142 237 616 155 237 616 minecraft:gold_block
fill 142 237 628 153 237 628 minecraft:gold_block
fill 152 237 617 152 237 619 minecraft:netherite_block
fill 152 237 620 152 238 620 minecraft:iron_block
fill 152 237 621 152 237 623 minecraft:netherite_block
fill 152 237 624 152 238 626 minecraft:iron_block
setblock 152 237 627 minecraft:netherite_block
setblock 152 237 629 minecraft:netherite_block
fill 152 237 630 152 238 630 minecraft:iron_block
fill 152 237 631 152 237 639 minecraft:netherite_block
fill 154 237 617 154 237 618 minecraft:netherite_block
fill 154 237 619 154 238 631 minecraft:iron_block
fill 154 237 632 154 237 639 minecraft:netherite_block
fill 155 237 628 163 238 628 minecraft:iron_block
fill 156 237 605 156 237 614 minecraft:netherite_block
fill 156 237 615 156 238 616 minecraft:iron_block
setblock 156 237 617 minecraft:netherite_block
fill 156 237 618 156 238 627 minecraft:iron_block
fill 156 237 629 156 238 632 minecraft:iron_block
setblock 156 237 633 minecraft:netherite_block
fill 156 237 634 156 238 635 minecraft:iron_block
fill 156 237 636 156 237 639 minecraft:netherite_block
fill 157 237 616 172 238 616 minecraft:iron_block
fill 158 237 617 158 238 627 minecraft:iron_block
fill 158 237 629 158 238 634 minecraft:iron_block
fill 158 237 635 158 237 639 minecraft:netherite_block
fill 159 237 624 160 238 626 minecraft:iron_block
fill 160 237 605 160 237 614 minecraft:netherite_block
fill 160 237 615 160 238 615 minecraft:iron_block
fill 160 237 617 161 238 623 minecraft:iron_block
fill 160 237 627 161 238 627 minecraft:iron_block
fill 160 237 629 160 238 635 minecraft:iron_block
fill 160 237 636 160 237 639 minecraft:netherite_block
fill 161 237 624 161 238 624 minecraft:iron_block
fill 161 237 625 162 237 625 minecraft:waxed_copper_block
fill 161 237 626 161 238 626 minecraft:iron_block
fill 162 237 605 162 237 612 minecraft:netherite_block
fill 162 237 613 162 238 615 minecraft:iron_block
fill 162 237 617 162 238 622 minecraft:iron_block
fill 162 237 623 162 238 624 minecraft:waxed_copper_block
fill 162 237 626 162 238 627 minecraft:waxed_copper_block
fill 162 237 629 162 238 637 minecraft:iron_block
fill 162 237 638 162 237 639 minecraft:netherite_block
fill 163 237 619 163 238 622 minecraft:iron_block
fill 163 237 623 166 237 623 minecraft:waxed_copper_block
fill 163 237 627 166 237 627 minecraft:waxed_copper_block
fill 163 237 629 166 238 631 minecraft:iron_block
fill 164 237 605 164 237 613 minecraft:netherite_block
fill 164 237 614 164 238 615 minecraft:iron_block
fill 164 237 617 164 238 621 minecraft:iron_block
fill 164 237 622 164 239 622 minecraft:waxed_copper_block
fill 164 237 628 164 239 628 minecraft:waxed_copper_block
fill 164 237 632 164 238 636 minecraft:iron_block
fill 164 237 637 164 237 639 minecraft:netherite_block
fill 165 237 619 168 238 622 minecraft:iron_block
fill 165 237 628 174 238 628 minecraft:iron_block
fill 166 237 605 166 237 612 minecraft:netherite_block
fill 166 237 613 166 238 615 minecraft:iron_block
fill 166 237 617 168 238 618 minecraft:iron_block
fill 166 237 624 166 237 626 minecraft:waxed_copper_block
fill 166 237 632 166 238 637 minecraft:iron_block
fill 166 237 638 166 237 639 minecraft:netherite_block
fill 167 237 623 168 238 624 minecraft:iron_block
fill 167 237 625 167 239 625 minecraft:waxed_copper_block
fill 167 237 626 168 238 627 minecraft:iron_block
fill 168 237 605 168 237 614 minecraft:netherite_block
fill 168 237 615 168 238 615 minecraft:iron_block
fill 168 237 625 168 238 625 minecraft:iron_block
fill 168 237 629 168 238 635 minecraft:iron_block
fill 168 237 636 168 237 639 minecraft:netherite_block
fill 170 237 617 170 238 627 minecraft:iron_block
fill 170 237 629 170 238 634 minecraft:iron_block
fill 170 237 635 170 237 639 minecraft:netherite_block
fill 172 237 605 172 237 614 minecraft:netherite_block
fill 172 237 615 172 238 615 minecraft:iron_block
setblock 172 237 617 minecraft:netherite_block
fill 172 237 618 172 238 627 minecraft:iron_block
fill 172 237 629 172 238 632 minecraft:iron_block
setblock 172 237 633 minecraft:netherite_block
fill 172 237 634 172 238 635 minecraft:iron_block
fill 172 237 636 172 237 639 minecraft:netherite_block
fill 173 237 616 182 237 616 minecraft:gold_block
fill 174 237 617 174 237 618 minecraft:netherite_block
fill 174 237 619 174 238 627 minecraft:iron_block
fill 174 237 629 174 238 631 minecraft:iron_block
fill 174 237 632 174 237 639 minecraft:netherite_block
fill 175 237 628 182 237 628 minecraft:gold_block
fill 176 237 617 176 237 619 minecraft:netherite_block
fill 176 237 620 176 238 620 minecraft:iron_block
fill 176 237 621 176 237 623 minecraft:netherite_block
fill 176 237 624 176 238 626 minecraft:iron_block
setblock 176 237 627 minecraft:netherite_block
setblock 176 237 629 minecraft:netherite_block
fill 176 237 630 176 238 630 minecraft:iron_block
fill 176 237 631 176 237 639 minecraft:netherite_block
setblock 151 238 625 minecraft:iron_block
fill 153 238 619 153 238 621 minecraft:iron_block
setblock 153 238 625 minecraft:iron_block
fill 153 238 629 153 238 631 minecraft:iron_block
fill 155 238 619 155 238 627 minecraft:iron_block
fill 155 238 629 155 238 631 minecraft:iron_block
setblock 157 238 615 minecraft:iron_block
fill 157 238 629 157 238 635 minecraft:iron_block
fill 159 238 629 159 238 634 minecraft:iron_block
fill 161 238 613 161 238 615 minecraft:iron_block
fill 161 238 625 161 239 625 minecraft:waxed_copper_block
fill 161 238 629 161 238 637 minecraft:iron_block
setblock 163 238 615 minecraft:iron_block
setblock 163 238 623 minecraft:waxed_copper_block
setblock 163 238 627 minecraft:waxed_copper_block
fill 163 238 632 163 238 635 minecraft:iron_block
setblock 165 238 615 minecraft:iron_block
fill 165 238 623 166 238 623 minecraft:waxed_copper_block
fill 165 238 627 166 238 627 minecraft:waxed_copper_block
fill 165 238 632 165 238 635 minecraft:iron_block
setblock 166 238 624 minecraft:waxed_copper_block
setblock 166 238 626 minecraft:waxed_copper_block
fill 167 238 613 167 238 615 minecraft:iron_block
fill 167 238 629 167 238 637 minecraft:iron_block
fill 169 238 629 169 238 634 minecraft:iron_block
setblock 171 238 615 minecraft:iron_block
fill 171 238 629 171 238 635 minecraft:iron_block
fill 173 238 619 173 238 627 minecraft:iron_block
fill 173 238 629 173 238 631 minecraft:iron_block
fill 175 238 619 175 238 621 minecraft:iron_block
setblock 175 238 625 minecraft:iron_block
fill 175 238 629 175 238 631 minecraft:iron_block
setblock 177 238 625 minecraft:iron_block
setblock 144 239 607 minecraft:light[level=14]
setblock 144 239 615 minecraft:light[level=14]
setblock 144 239 623 minecraft:light[level=14]
setblock 144 239 631 minecraft:light[level=14]
setblock 144 239 639 minecraft:light[level=14]
setblock 152 239 607 minecraft:light[level=14]
setblock 152 239 615 minecraft:light[level=14]
setblock 152 239 623 minecraft:light[level=14]
setblock 152 239 631 minecraft:light[level=14]
setblock 152 239 639 minecraft:light[level=14]
fill 157 239 623 157 239 627 minecraft:waxed_oxidized_copper
fill 158 239 621 158 239 622 minecraft:waxed_oxidized_copper
fill 158 239 628 158 239 629 minecraft:waxed_oxidized_copper
setblock 159 239 620 minecraft:waxed_oxidized_copper
setblock 159 239 630 minecraft:waxed_oxidized_copper
setblock 160 239 607 minecraft:light[level=14]
setblock 160 239 615 minecraft:light[level=14]
fill 160 239 619 161 239 619 minecraft:waxed_oxidized_copper
setblock 160 239 623 minecraft:light[level=14]
fill 160 239 631 161 239 631 minecraft:waxed_oxidized_copper
setblock 160 239 639 minecraft:light[level=14]
fill 162 239 618 166 239 618 minecraft:waxed_oxidized_copper
setblock 162 239 623 minecraft:waxed_copper_block
setblock 162 239 627 minecraft:waxed_copper_block
fill 162 239 632 166 239 632 minecraft:waxed_oxidized_copper
setblock 166 239 623 minecraft:waxed_copper_block
setblock 166 239 627 minecraft:waxed_copper_block
fill 167 239 619 168 239 619 minecraft:waxed_oxidized_copper
fill 167 239 631 168 239 631 minecraft:waxed_oxidized_copper
setblock 168 239 607 minecraft:light[level=14]
setblock 168 239 615 minecraft:light[level=14]
setblock 168 239 623 minecraft:light[level=14]
setblock 168 239 639 minecraft:light[level=14]
setblock 169 239 620 minecraft:waxed_oxidized_copper
setblock 169 239 630 minecraft:waxed_oxidized_copper
fill 170 239 621 170 239 622 minecraft:waxed_oxidized_copper
fill 170 239 628 170 239 629 minecraft:waxed_oxidized_copper
fill 171 239 623 171 239 627 minecraft:waxed_oxidized_copper
setblock 176 239 607 minecraft:light[level=14]
setblock 176 239 615 minecraft:light[level=14]
setblock 176 239 623 minecraft:light[level=14]
setblock 176 239 631 minecraft:light[level=14]
setblock 176 239 639 minecraft:light[level=14]
fill 142 241 606 142 273 606 minecraft:iron_block
fill 142 241 616 142 273 616 minecraft:iron_block
fill 142 241 626 142 273 626 minecraft:iron_block
fill 142 241 636 142 273 636 minecraft:iron_block
fill 143 241 645 143 273 645 minecraft:iron_block
fill 145 241 639 145 273 639 minecraft:iron_block
fill 149 241 605 149 273 605 minecraft:iron_block
fill 153 241 645 153 273 645 minecraft:iron_block
fill 159 241 605 159 273 605 minecraft:iron_block
fill 163 241 645 163 273 645 minecraft:iron_block
fill 169 241 605 169 273 605 minecraft:iron_block
fill 172 241 608 172 273 608 minecraft:iron_block
fill 173 241 645 173 273 645 minecraft:iron_block
fill 179 241 605 179 273 605 minecraft:iron_block
fill 182 241 612 182 273 612 minecraft:iron_block
fill 182 241 622 182 273 622 minecraft:iron_block
fill 182 241 632 182 273 632 minecraft:iron_block
fill 182 241 642 182 273 642 minecraft:iron_block
fill 142 243 609 142 243 612 minecraft:iron_block
fill 142 243 619 142 243 622 minecraft:iron_block
fill 142 243 629 142 243 632 minecraft:iron_block
fill 142 243 639 142 243 642 minecraft:iron_block
fill 143 243 605 146 243 605 minecraft:iron_block
fill 144 243 638 144 243 640 minecraft:iron_block
fill 145 243 638 146 243 638 minecraft:iron_block
fill 145 243 640 146 243 640 minecraft:iron_block
setblock 146 243 639 minecraft:iron_block
fill 146 243 645 149 243 645 minecraft:iron_block
fill 153 243 605 156 243 605 minecraft:iron_block
fill 156 243 645 159 243 645 minecraft:iron_block
fill 163 243 605 166 243 605 minecraft:iron_block
fill 166 243 645 169 243 645 minecraft:iron_block
fill 168 243 622 169 244 628 minecraft:waxed_copper_block
fill 169 243 621 177 244 621 minecraft:waxed_copper_block
fill 169 243 629 177 244 629 minecraft:waxed_copper_block
fill 170 243 620 176 244 620 minecraft:waxed_copper_block
fill 170 243 622 170 244 624 minecraft:waxed_copper_block
fill 170 243 626 170 244 628 minecraft:waxed_copper_block
fill 170 243 630 176 244 630 minecraft:waxed_copper_block
fill 171 243 607 171 243 609 minecraft:iron_block
fill 171 243 622 172 244 622 minecraft:waxed_copper_block
fill 171 243 628 172 244 628 minecraft:waxed_copper_block
fill 172 243 607 173 243 607 minecraft:iron_block
fill 172 243 609 173 243 609 minecraft:iron_block
fill 173 243 605 176 243 605 minecraft:iron_block
setblock 173 243 608 minecraft:iron_block
fill 173 243 619 173 244 619 minecraft:waxed_copper_block
fill 173 243 631 173 244 631 minecraft:waxed_copper_block
fill 174 243 622 178 244 622 minecraft:waxed_copper_block
fill 174 243 628 178 244 628 minecraft:waxed_copper_block
fill 176 243 623 178 244 624 minecraft:waxed_copper_block
fill 176 243 626 178 244 627 minecraft:waxed_copper_block
fill 176 243 645 179 243 645 minecraft:iron_block
fill 177 243 625 179 244 625 minecraft:waxed_copper_block
fill 182 243 606 182 243 609 minecraft:iron_block
fill 182 243 616 182 243 619 minecraft:iron_block
fill 182 243 626 182 243 629 minecraft:iron_block
fill 182 243 636 182 243 639 minecraft:iron_block
setblock 142 246 607 minecraft:iron_block
setblock 142 246 617 minecraft:iron_block
setblock 142 246 627 minecraft:iron_block
setblock 142 246 637 minecraft:iron_block
setblock 144 246 645 minecraft:iron_block
setblock 148 246 605 minecraft:iron_block
setblock 154 246 645 minecraft:iron_block
setblock 158 246 605 minecraft:iron_block
setblock 164 246 645 minecraft:iron_block
setblock 168 246 605 minecraft:iron_block
setblock 174 246 645 minecraft:iron_block
setblock 178 246 605 minecraft:iron_block
setblock 182 246 611 minecraft:iron_block
setblock 182 246 621 minecraft:iron_block
setblock 182 246 631 minecraft:iron_block
setblock 182 246 641 minecraft:iron_block
fill 141 247 610 141 247 613 minecraft:sea_lantern
fill 141 247 620 141 247 623 minecraft:sea_lantern
fill 141 247 630 141 247 633 minecraft:sea_lantern
fill 141 247 640 141 247 643 minecraft:sea_lantern
fill 144 247 604 147 247 604 minecraft:sea_lantern
setblock 144 247 607 minecraft:light[level=14]
setblock 144 247 615 minecraft:light[level=14]
setblock 144 247 623 minecraft:light[level=14]
setblock 144 247 631 minecraft:light[level=14]
setblock 144 247 639 minecraft:light[level=14]
fill 145 247 646 148 247 646 minecraft:sea_lantern
setblock 152 247 607 minecraft:light[level=14]
setblock 152 247 615 minecraft:light[level=14]
setblock 152 247 623 minecraft:light[level=14]
setblock 152 247 631 minecraft:light[level=14]
setblock 152 247 639 minecraft:light[level=14]
fill 154 247 604 157 247 604 minecraft:sea_lantern
fill 155 247 646 158 247 646 minecraft:sea_lantern
setblock 160 247 607 minecraft:light[level=14]
setblock 160 247 615 minecraft:light[level=14]
setblock 160 247 623 minecraft:light[level=14]
setblock 160 247 631 minecraft:light[level=14]
setblock 160 247 639 minecraft:light[level=14]
fill 164 247 604 167 247 604 minecraft:sea_lantern
fill 165 247 646 168 247 646 minecraft:sea_lantern
setblock 168 247 607 minecraft:light[level=14]
setblock 168 247 615 minecraft:light[level=14]
setblock 168 247 623 minecraft:light[level=14]
setblock 168 247 631 minecraft:light[level=14]
setblock 168 247 639 minecraft:light[level=14]
fill 174 247 604 177 247 604 minecraft:sea_lantern
fill 175 247 646 178 247 646 minecraft:sea_lantern
setblock 176 247 607 minecraft:light[level=14]
setblock 176 247 615 minecraft:light[level=14]
setblock 176 247 623 minecraft:light[level=14]
setblock 176 247 631 minecraft:light[level=14]
setblock 176 247 639 minecraft:light[level=14]
fill 183 247 605 183 247 608 minecraft:sea_lantern
fill 183 247 615 183 247 618 minecraft:sea_lantern
fill 183 247 625 183 247 628 minecraft:sea_lantern
fill 183 247 635 183 247 638 minecraft:sea_lantern
setblock 183 247 645 minecraft:sea_lantern
fill 141 248 610 141 255 613 minecraft:netherite_block
fill 141 248 620 141 255 623 minecraft:netherite_block
fill 141 248 630 141 255 633 minecraft:netherite_block
fill 141 248 640 141 255 643 minecraft:netherite_block
fill 144 248 604 147 255 604 minecraft:netherite_block
fill 144 248 638 144 248 640 minecraft:iron_block
fill 145 248 638 146 248 638 minecraft:iron_block
fill 145 248 640 146 248 640 minecraft:iron_block
fill 145 248 646 148 255 646 minecraft:netherite_block
setblock 146 248 639 minecraft:iron_block
fill 154 248 604 157 255 604 minecraft:netherite_block
fill 155 248 646 158 255 646 minecraft:netherite_block
fill 164 248 604 167 255 604 minecraft:netherite_block
fill 165 248 646 168 255 646 minecraft:netherite_block
fill 174 248 604 177 255 604 minecraft:netherite_block
fill 175 248 646 178 255 646 minecraft:netherite_block
fill 183 248 605 183 255 608 minecraft:netherite_block
fill 183 248 615 183 255 618 minecraft:netherite_block
fill 183 248 625 183 255 628 minecraft:netherite_block
fill 183 248 635 183 255 638 minecraft:netherite_block
fill 183 248 645 183 255 645 minecraft:netherite_block
fill 148 249 642 148 250 644 minecraft:iron_block
fill 171 250 607 171 250 609 minecraft:iron_block
fill 172 250 607 173 250 607 minecraft:iron_block
fill 172 250 609 173 250 609 minecraft:iron_block
setblock 173 250 608 minecraft:iron_block
setblock 142 252 607 minecraft:iron_block
fill 142 252 609 142 252 612 minecraft:iron_block
setblock 142 252 617 minecraft:iron_block
fill 142 252 619 142 252 622 minecraft:iron_block
setblock 142 252 627 minecraft:iron_block
fill 142 252 629 142 252 632 minecraft:iron_block
setblock 142 252 637 minecraft:iron_block
fill 142 252 639 142 252 642 minecraft:iron_block
fill 143 252 605 146 252 605 minecraft:iron_block
setblock 144 252 645 minecraft:iron_block
fill 146 252 645 149 252 645 minecraft:iron_block
setblock 148 252 605 minecraft:iron_block
fill 153 252 605 156 252 605 minecraft:iron_block
setblock 154 252 645 minecraft:iron_block
fill 156 252 645 159 252 645 minecraft:iron_block
setblock 158 252 605 minecraft:iron_block
fill 163 252 605 166 252 605 minecraft:iron_block
setblock 164 252 645 minecraft:iron_block
fill 166 252 645 169 252 645 minecraft:iron_block
setblock 168 252 605 minecraft:iron_block
fill 173 252 605 176 252 605 minecraft:iron_block
setblock 174 252 645 minecraft:iron_block
fill 176 252 645 179 252 645 minecraft:iron_block
setblock 178 252 605 minecraft:iron_block
fill 182 252 606 182 252 609 minecraft:iron_block
setblock 182 252 611 minecraft:iron_block
fill 182 252 616 182 252 619 minecraft:iron_block
setblock 182 252 621 minecraft:iron_block
fill 182 252 626 182 252 629 minecraft:iron_block
setblock 182 252 631 minecraft:iron_block
fill 182 252 636 182 252 639 minecraft:iron_block
setblock 182 252 641 minecraft:iron_block
fill 144 253 638 144 253 640 minecraft:iron_block
fill 145 253 638 146 253 638 minecraft:iron_block
fill 145 253 640 146 253 640 minecraft:iron_block
setblock 146 253 639 minecraft:iron_block
setblock 144 255 607 minecraft:light[level=14]
setblock 144 255 615 minecraft:light[level=14]
setblock 144 255 623 minecraft:light[level=14]
setblock 144 255 631 minecraft:light[level=14]
setblock 144 255 639 minecraft:light[level=14]
setblock 152 255 607 minecraft:light[level=14]
setblock 152 255 615 minecraft:light[level=14]
setblock 152 255 623 minecraft:light[level=14]
setblock 152 255 631 minecraft:light[level=14]
setblock 152 255 639 minecraft:light[level=14]
setblock 160 255 607 minecraft:light[level=14]
setblock 160 255 615 minecraft:light[level=14]
setblock 160 255 623 minecraft:light[level=14]
setblock 160 255 631 minecraft:light[level=14]
setblock 160 255 639 minecraft:light[level=14]
setblock 168 255 607 minecraft:light[level=14]
setblock 168 255 615 minecraft:light[level=14]
setblock 168 255 623 minecraft:light[level=14]
setblock 168 255 631 minecraft:light[level=14]
setblock 168 255 639 minecraft:light[level=14]
setblock 176 255 607 minecraft:light[level=14]
setblock 176 255 615 minecraft:light[level=14]
setblock 176 255 623 minecraft:light[level=14]
setblock 176 255 631 minecraft:light[level=14]
setblock 176 255 639 minecraft:light[level=14]
fill 141 256 610 141 256 613 minecraft:sea_lantern
fill 141 256 620 141 256 623 minecraft:sea_lantern
fill 141 256 630 141 256 633 minecraft:sea_lantern
fill 141 256 640 141 256 643 minecraft:sea_lantern
fill 144 256 604 147 256 604 minecraft:sea_lantern
fill 145 256 646 148 256 646 minecraft:sea_lantern
fill 154 256 604 157 256 604 minecraft:sea_lantern
fill 155 256 646 158 256 646 minecraft:sea_lantern
fill 164 256 604 167 256 604 minecraft:sea_lantern
fill 165 256 646 168 256 646 minecraft:sea_lantern
fill 174 256 604 177 256 604 minecraft:sea_lantern
fill 175 256 646 178 256 646 minecraft:sea_lantern
fill 183 256 605 183 256 608 minecraft:sea_lantern
fill 183 256 615 183 256 618 minecraft:sea_lantern
fill 183 256 625 183 256 628 minecraft:sea_lantern
fill 183 256 635 183 256 638 minecraft:sea_lantern
setblock 183 256 645 minecraft:sea_lantern
fill 141 257 610 141 264 613 minecraft:netherite_block
fill 141 257 620 141 264 623 minecraft:netherite_block
fill 141 257 630 141 264 633 minecraft:netherite_block
fill 141 257 640 141 264 643 minecraft:netherite_block
fill 144 257 604 147 264 604 minecraft:netherite_block
fill 145 257 646 148 264 646 minecraft:netherite_block
fill 154 257 604 157 264 604 minecraft:netherite_block
fill 155 257 646 158 264 646 minecraft:netherite_block
fill 164 257 604 167 264 604 minecraft:netherite_block
fill 165 257 646 168 264 646 minecraft:netherite_block
fill 171 257 607 171 257 609 minecraft:iron_block
fill 172 257 607 173 257 607 minecraft:iron_block
fill 172 257 609 173 257 609 minecraft:iron_block
setblock 173 257 608 minecraft:iron_block
fill 174 257 604 177 264 604 minecraft:netherite_block
fill 175 257 646 178 264 646 minecraft:netherite_block
fill 183 257 605 183 264 608 minecraft:netherite_block
fill 183 257 615 183 264 618 minecraft:netherite_block
fill 183 257 625 183 264 628 minecraft:netherite_block
fill 183 257 635 183 264 638 minecraft:netherite_block
fill 183 257 645 183 264 645 minecraft:netherite_block
setblock 142 258 607 minecraft:iron_block
setblock 142 258 617 minecraft:iron_block
setblock 142 258 627 minecraft:iron_block
setblock 142 258 637 minecraft:iron_block
fill 144 258 638 144 258 640 minecraft:iron_block
setblock 144 258 645 minecraft:iron_block
fill 145 258 638 146 258 638 minecraft:iron_block
fill 145 258 640 146 258 640 minecraft:iron_block
setblock 146 258 639 minecraft:iron_block
setblock 148 258 605 minecraft:iron_block
setblock 154 258 645 minecraft:iron_block
setblock 158 258 605 minecraft:iron_block
setblock 164 258 645 minecraft:iron_block
setblock 168 258 605 minecraft:iron_block
setblock 174 258 645 minecraft:iron_block
setblock 178 258 605 minecraft:iron_block
setblock 182 258 611 minecraft:iron_block
setblock 182 258 621 minecraft:iron_block
setblock 182 258 631 minecraft:iron_block
setblock 182 258 641 minecraft:iron_block
fill 142 261 609 142 261 612 minecraft:iron_block
fill 142 261 619 142 261 622 minecraft:iron_block
fill 142 261 629 142 261 632 minecraft:iron_block
fill 142 261 639 142 261 642 minecraft:iron_block
fill 143 261 605 143 262 607 minecraft:iron_block
fill 144 261 605 146 261 605 minecraft:iron_block
fill 146 261 645 149 261 645 minecraft:iron_block
fill 153 261 605 156 261 605 minecraft:iron_block
fill 156 261 645 159 261 645 minecraft:iron_block
fill 163 261 605 166 261 605 minecraft:iron_block
fill 166 261 645 169 261 645 minecraft:iron_block
fill 173 261 605 176 261 605 minecraft:iron_block
fill 176 261 645 179 261 645 minecraft:iron_block
fill 182 261 606 182 261 609 minecraft:iron_block
fill 182 261 616 182 261 619 minecraft:iron_block
fill 182 261 626 182 261 629 minecraft:iron_block
fill 182 261 636 182 261 639 minecraft:iron_block
fill 172 262 605 172 263 607 minecraft:iron_block
setblock 144 263 607 minecraft:light[level=14]
setblock 144 263 615 minecraft:light[level=14]
setblock 144 263 623 minecraft:light[level=14]
setblock 144 263 631 minecraft:light[level=14]
fill 144 263 638 144 263 640 minecraft:iron_block
fill 145 263 638 146 263 638 minecraft:iron_block
fill 145 263 640 146 263 640 minecraft:iron_block
setblock 146 263 639 minecraft:iron_block
setblock 152 263 607 minecraft:light[level=14]
setblock 152 263 615 minecraft:light[level=14]
setblock 152 263 623 minecraft:light[level=14]
setblock 152 263 631 minecraft:light[level=14]
setblock 152 263 639 minecraft:light[level=14]
setblock 160 263 607 minecraft:light[level=14]
setblock 160 263 615 minecraft:light[level=14]
setblock 160 263 623 minecraft:light[level=14]
setblock 160 263 631 minecraft:light[level=14]
setblock 160 263 639 minecraft:light[level=14]
setblock 168 263 607 minecraft:light[level=14]
setblock 168 263 615 minecraft:light[level=14]
setblock 168 263 623 minecraft:light[level=14]
setblock 168 263 631 minecraft:light[level=14]
setblock 168 263 639 minecraft:light[level=14]
setblock 172 263 609 minecraft:sea_lantern
setblock 176 263 607 minecraft:light[level=14]
setblock 176 263 615 minecraft:light[level=14]
setblock 176 263 623 minecraft:light[level=14]
setblock 176 263 631 minecraft:light[level=14]
setblock 176 263 639 minecraft:light[level=14]
setblock 142 264 607 minecraft:iron_block
setblock 142 264 617 minecraft:iron_block
setblock 142 264 627 minecraft:iron_block
setblock 142 264 637 minecraft:iron_block
setblock 144 264 645 minecraft:iron_block
setblock 148 264 605 minecraft:iron_block
setblock 154 264 645 minecraft:iron_block
setblock 158 264 605 minecraft:iron_block
setblock 164 264 645 minecraft:iron_block
setblock 168 264 605 minecraft:iron_block
fill 171 264 607 171 264 609 minecraft:iron_block
fill 172 264 607 173 264 607 minecraft:iron_block
fill 172 264 609 173 264 609 minecraft:iron_block
setblock 173 264 608 minecraft:iron_block
setblock 174 264 645 minecraft:iron_block
setblock 178 264 605 minecraft:iron_block
setblock 182 264 611 minecraft:iron_block
setblock 182 264 621 minecraft:iron_block
setblock 182 264 631 minecraft:iron_block
setblock 182 264 641 minecraft:iron_block
fill 141 265 610 141 265 613 minecraft:sea_lantern
fill 141 265 620 141 265 623 minecraft:sea_lantern
fill 141 265 630 141 265 633 minecraft:sea_lantern
fill 141 265 640 141 265 643 minecraft:sea_lantern
fill 144 265 604 147 265 604 minecraft:sea_lantern
fill 145 265 646 148 265 646 minecraft:sea_lantern
fill 154 265 604 157 265 604 minecraft:sea_lantern
fill 155 265 646 158 265 646 minecraft:sea_lantern
fill 164 265 604 167 265 604 minecraft:sea_lantern
fill 165 265 646 168 265 646 minecraft:sea_lantern
fill 174 265 604 177 265 604 minecraft:sea_lantern
fill 175 265 646 178 265 646 minecraft:sea_lantern
fill 183 265 605 183 265 608 minecraft:sea_lantern
fill 183 265 615 183 265 618 minecraft:sea_lantern
fill 183 265 625 183 265 628 minecraft:sea_lantern
fill 183 265 635 183 265 638 minecraft:sea_lantern
setblock 183 265 645 minecraft:sea_lantern
fill 141 266 610 141 291 613 minecraft:netherite_block
fill 141 266 620 141 291 623 minecraft:netherite_block
fill 141 266 630 141 291 633 minecraft:netherite_block
fill 141 266 640 141 291 643 minecraft:netherite_block
fill 144 266 604 147 291 604 minecraft:netherite_block
fill 145 266 646 148 291 646 minecraft:netherite_block
fill 154 266 604 157 291 604 minecraft:netherite_block
fill 155 266 646 158 291 646 minecraft:netherite_block
fill 164 266 604 167 291 604 minecraft:netherite_block
fill 165 266 646 168 291 646 minecraft:netherite_block
fill 174 266 604 177 291 604 minecraft:netherite_block
fill 175 266 646 178 291 646 minecraft:netherite_block
fill 183 266 605 183 291 608 minecraft:netherite_block
fill 183 266 615 183 291 618 minecraft:netherite_block
fill 183 266 625 183 291 628 minecraft:netherite_block
fill 183 266 635 183 291 638 minecraft:netherite_block
fill 183 266 645 183 291 645 minecraft:netherite_block
fill 144 268 638 144 268 640 minecraft:iron_block
fill 145 268 638 146 268 638 minecraft:iron_block
fill 145 268 640 146 268 640 minecraft:iron_block
setblock 146 268 639 minecraft:iron_block
setblock 142 270 607 minecraft:iron_block
fill 142 270 609 142 270 612 minecraft:iron_block
setblock 142 270 617 minecraft:iron_block
fill 142 270 619 142 270 622 minecraft:iron_block
setblock 142 270 627 minecraft:iron_block
fill 142 270 629 142 270 632 minecraft:iron_block
setblock 142 270 637 minecraft:iron_block
fill 142 270 639 142 270 642 minecraft:iron_block
fill 143 270 605 146 270 605 minecraft:iron_block
setblock 144 270 645 minecraft:iron_block
fill 146 270 645 149 270 645 minecraft:iron_block
setblock 148 270 605 minecraft:iron_block
fill 153 270 605 156 270 605 minecraft:iron_block
setblock 154 270 645 minecraft:iron_block
fill 156 270 645 159 270 645 minecraft:iron_block
setblock 158 270 605 minecraft:iron_block
fill 163 270 605 166 270 605 minecraft:iron_block
setblock 164 270 645 minecraft:iron_block
fill 166 270 645 169 270 645 minecraft:iron_block
setblock 168 270 605 minecraft:iron_block
fill 173 270 605 176 270 605 minecraft:iron_block
setblock 174 270 645 minecraft:iron_block
fill 176 270 645 179 270 645 minecraft:iron_block
setblock 178 270 605 minecraft:iron_block
fill 182 270 606 182 270 609 minecraft:iron_block
setblock 182 270 611 minecraft:iron_block
fill 182 270 616 182 270 619 minecraft:iron_block
setblock 182 270 621 minecraft:iron_block
fill 182 270 626 182 270 629 minecraft:iron_block
setblock 182 270 631 minecraft:iron_block
fill 182 270 636 182 270 639 minecraft:iron_block
setblock 182 270 641 minecraft:iron_block
setblock 144 271 607 minecraft:light[level=14]
setblock 144 271 615 minecraft:light[level=14]
setblock 144 271 623 minecraft:light[level=14]
setblock 144 271 631 minecraft:light[level=14]
setblock 144 271 639 minecraft:light[level=14]
setblock 152 271 607 minecraft:light[level=14]
setblock 152 271 615 minecraft:light[level=14]
setblock 152 271 623 minecraft:light[level=14]
setblock 152 271 631 minecraft:light[level=14]
setblock 152 271 639 minecraft:light[level=14]
setblock 160 271 607 minecraft:light[level=14]
setblock 160 271 615 minecraft:light[level=14]
setblock 160 271 623 minecraft:light[level=14]
setblock 160 271 631 minecraft:light[level=14]
setblock 160 271 639 minecraft:light[level=14]
setblock 168 271 607 minecraft:light[level=14]
setblock 168 271 615 minecraft:light[level=14]
setblock 168 271 623 minecraft:light[level=14]
setblock 168 271 631 minecraft:light[level=14]
setblock 168 271 639 minecraft:light[level=14]
fill 171 271 607 171 271 609 minecraft:iron_block
fill 172 271 607 173 271 607 minecraft:iron_block
fill 172 271 609 173 271 609 minecraft:iron_block
setblock 173 271 608 minecraft:iron_block
setblock 176 271 607 minecraft:light[level=14]
setblock 176 271 615 minecraft:light[level=14]
setblock 176 271 623 minecraft:light[level=14]
setblock 176 271 631 minecraft:light[level=14]
setblock 176 271 639 minecraft:light[level=14]
fill 142 272 639 144 273 639 minecraft:iron_block
setblock 146 273 639 minecraft:sea_lantern
fill 158 278 622 160 278 624 minecraft:redstone_block
fill 162 278 627 164 278 629 minecraft:redstone_block
fill 164 278 617 166 278 619 minecraft:redstone_block
fill 168 278 622 170 278 624 minecraft:redstone_block
setblock 144 279 607 minecraft:light[level=14]
setblock 144 279 615 minecraft:light[level=14]
setblock 144 279 623 minecraft:light[level=14]
setblock 144 279 631 minecraft:light[level=14]
setblock 144 279 639 minecraft:light[level=14]
fill 149 279 623 157 279 623 minecraft:gold_block
fill 150 279 619 150 280 620 minecraft:gold_block
fill 150 279 622 157 279 622 minecraft:gold_block
fill 150 279 625 176 279 625 minecraft:gold_block
fill 150 279 628 161 279 628 minecraft:gold_block
fill 151 279 617 163 279 617 minecraft:gold_block
fill 151 279 620 176 279 620 minecraft:gold_block
fill 151 279 627 161 279 627 minecraft:gold_block
fill 151 279 630 174 279 630 minecraft:gold_block
setblock 152 279 607 minecraft:light[level=14]
fill 152 279 614 153 280 614 minecraft:gold_block
setblock 152 279 615 minecraft:light[level=14]
fill 152 279 618 163 279 619 minecraft:gold_block
fill 152 279 621 178 279 621 minecraft:gold_block
fill 152 279 624 157 279 624 minecraft:gold_block
fill 152 279 626 178 279 626 minecraft:gold_block
fill 152 279 631 152 280 631 minecraft:gold_block
setblock 152 279 639 minecraft:light[level=14]
fill 153 279 615 174 279 615 minecraft:gold_block
fill 153 279 629 161 279 629 minecraft:gold_block
fill 153 279 633 154 280 633 minecraft:gold_block
fill 154 279 612 154 280 613 minecraft:gold_block
fill 154 279 616 177 279 616 minecraft:gold_block
fill 154 279 631 173 279 632 minecraft:gold_block
fill 155 279 613 172 279 614 minecraft:gold_block
fill 155 279 634 155 280 635 minecraft:gold_block
fill 156 279 611 157 280 611 minecraft:gold_block
fill 156 279 633 156 280 634 minecraft:gold_block
fill 157 279 610 157 280 610 minecraft:gold_block
fill 157 279 612 170 280 612 minecraft:gold_block
fill 157 279 633 174 280 633 minecraft:gold_block
fill 158 279 634 158 280 636 minecraft:gold_block
fill 159 279 609 159 280 611 minecraft:gold_block
fill 159 279 634 169 280 635 minecraft:gold_block
setblock 160 279 607 minecraft:light[level=14]
fill 160 279 610 160 280 611 minecraft:gold_block
setblock 160 279 623 minecraft:light[level=14]
fill 160 279 637 161 280 637 minecraft:gold_block
setblock 160 279 639 minecraft:light[level=14]
fill 161 279 611 170 280 611 minecraft:gold_block
fill 161 279 622 162 279 624 minecraft:gold_block
fill 161 279 636 161 280 636 minecraft:gold_block
fill 162 279 609 162 280 610 minecraft:gold_block
fill 163 279 636 164 280 637 minecraft:gold_block
fill 164 279 608 164 280 610 minecraft:gold_block
fill 164 279 638 164 280 638 minecraft:gold_block
fill 165 279 609 165 280 610 minecraft:gold_block
fill 165 279 627 176 279 629 minecraft:gold_block
fill 166 279 622 167 279 624 minecraft:gold_block
fill 166 279 636 166 280 637 minecraft:gold_block
fill 167 279 609 167 280 610 minecraft:gold_block
fill 167 279 617 175 279 619 minecraft:gold_block
setblock 168 279 607 minecraft:light[level=14]
fill 168 279 609 168 280 609 minecraft:gold_block
setblock 168 279 623 minecraft:light[level=14]
fill 168 279 636 169 280 636 minecraft:gold_block
setblock 168 279 639 minecraft:light[level=14]
fill 169 279 637 169 280 637 minecraft:gold_block
fill 170 279 610 170 280 610 minecraft:gold_block
fill 170 279 634 171 280 634 minecraft:gold_block
fill 171 279 622 176 279 624 minecraft:gold_block
fill 171 279 635 171 280 636 minecraft:gold_block
fill 172 279 612 173 280 612 minecraft:gold_block
fill 172 279 635 172 280 635 minecraft:gold_block
fill 173 279 611 173 280 611 minecraft:gold_block
fill 173 279 614 174 280 614 minecraft:gold_block
fill 174 279 613 175 280 613 minecraft:gold_block
fill 174 279 631 175 280 631 minecraft:gold_block
fill 174 279 634 174 280 634 minecraft:gold_block
fill 175 279 632 176 280 632 minecraft:gold_block
setblock 176 279 607 minecraft:light[level=14]
fill 176 279 615 176 280 615 minecraft:gold_block
fill 176 279 618 177 280 619 minecraft:gold_block
setblock 176 279 631 minecraft:light[level=14]
setblock 176 279 639 minecraft:light[level=14]
fill 177 279 623 178 280 624 minecraft:gold_block
fill 177 279 629 177 280 629 minecraft:gold_block
fill 178 279 618 178 280 618 minecraft:gold_block
fill 178 279 627 178 280 627 minecraft:gold_block
fill 179 279 623 179 280 623 minecraft:gold_block
fill 142 280 605 148 280 645 minecraft:netherite_block
fill 149 280 605 149 280 622 minecraft:netherite_block
fill 149 280 623 156 280 623 minecraft:gold_block
fill 149 280 624 149 280 645 minecraft:netherite_block
fill 150 280 605 150 280 618 minecraft:netherite_block
fill 150 280 621 151 280 621 minecraft:netherite_block
fill 150 280 622 156 280 622 minecraft:gold_block
fill 150 280 624 151 280 624 minecraft:netherite_block
fill 150 280 625 153 280 625 minecraft:gold_block
fill 150 280 626 150 280 627 minecraft:netherite_block
fill 150 280 628 154 280 628 minecraft:gold_block
fill 150 280 629 150 280 645 minecraft:netherite_block
fill 151 280 605 151 280 616 minecraft:netherite_block
fill 151 280 617 160 280 617 minecraft:gold_block
fill 151 280 618 151 280 619 minecraft:netherite_block
fill 151 280 620 162 280 620 minecraft:gold_block
setblock 151 280 626 minecraft:netherite_block
fill 151 280 627 154 280 627 minecraft:gold_block
fill 151 280 629 152 280 629 minecraft:netherite_block
fill 151 280 630 156 280 630 minecraft:gold_block
fill 151 280 631 151 280 645 minecraft:netherite_block
fill 152 280 605 153 280 613 minecraft:netherite_block
fill 152 280 615 152 280 616 minecraft:netherite_block
fill 152 280 618 161 280 619 minecraft:gold_block
fill 152 280 621 156 280 621 minecraft:gold_block
fill 152 280 624 153 280 624 minecraft:gold_block
fill 152 280 626 153 280 626 minecraft:gold_block
fill 152 280 632 152 280 645 minecraft:netherite_block
fill 153 280 615 159 280 615 minecraft:gold_block
setblock 153 280 616 minecraft:netherite_block
fill 153 280 629 155 280 629 minecraft:gold_block
fill 153 280 631 153 280 632 minecraft:netherite_block
fill 153 280 634 154 280 645 minecraft:netherite_block
fill 154 280 605 155 280 611 minecraft:netherite_block
setblock 154 280 614 minecraft:netherite_block
fill 154 280 616 159 280 616 minecraft:gold_block
fill 154 280 624 156 280 626 minecraft:iron_block
fill 154 280 631 157 280 632 minecraft:gold_block
fill 155 280 612 156 280 612 minecraft:netherite_block
fill 155 280 613 158 280 614 minecraft:gold_block
fill 155 280 627 160 280 628 minecraft:iron_block
setblock 155 280 633 minecraft:netherite_block
fill 155 280 636 157 280 645 minecraft:netherite_block
fill 156 280 605 156 280 610 minecraft:netherite_block
fill 156 280 629 160 280 629 minecraft:iron_block
fill 156 280 635 157 280 635 minecraft:netherite_block
fill 157 280 605 158 280 609 minecraft:netherite_block
fill 157 280 621 157 280 625 minecraft:sea_lantern
fill 157 280 626 160 280 626 minecraft:iron_block
fill 157 280 630 159 280 630 minecraft:iron_block
setblock 157 280 634 minecraft:netherite_block
fill 158 280 610 158 280 611 minecraft:netherite_block
fill 158 280 621 171 280 621 minecraft:sea_lantern
fill 158 280 622 160 280 624 minecraft:netherite_block
fill 158 280 625 171 280 625 minecraft:sea_lantern
fill 158 280 631 159 280 631 minecraft:iron_block
fill 158 280 632 173 280 632 minecraft:gold_block
fill 158 280 637 159 280 645 minecraft:netherite_block
fill 159 280 605 163 280 608 minecraft:netherite_block
fill 159 280 613 160 280 613 minecraft:gold_block
fill 159 280 614 169 280 614 minecraft:iron_block
fill 159 280 636 160 280 636 minecraft:netherite_block
fill 160 280 609 161 280 609 minecraft:netherite_block
fill 160 280 615 162 280 616 minecraft:iron_block
fill 160 280 630 160 280 631 minecraft:gold_block
fill 160 280 638 163 280 645 minecraft:netherite_block
setblock 161 280 610 minecraft:netherite_block
fill 161 280 613 167 280 613 minecraft:iron_block
fill 161 280 617 162 280 617 minecraft:iron_block
fill 161 280 622 162 280 624 minecraft:sea_lantern
fill 161 280 626 161 280 630 minecraft:sea_lantern
fill 161 280 631 168 280 631 minecraft:gold_block
fill 162 280 618 162 280 619 minecraft:iron_block
fill 162 280 626 165 280 626 minecraft:sea_lantern
fill 162 280 627 164 280 629 minecraft:netherite_block
fill 162 280 630 165 280 630 minecraft:sea_lantern
fill 162 280 636 162 280 637 minecraft:netherite_block
fill 163 280 609 163 280 610 minecraft:netherite_block
fill 163 280 615 168 280 615 minecraft:iron_block
fill 163 280 616 163 280 620 minecraft:sea_lantern
fill 164 280 605 182 280 607 minecraft:netherite_block
fill 164 280 616 167 280 616 minecraft:sea_lantern
fill 164 280 617 166 280 619 minecraft:netherite_block
fill 164 280 620 167 280 620 minecraft:sea_lantern
fill 164 280 639 182 280 645 minecraft:netherite_block
fill 165 280 608 182 280 608 minecraft:netherite_block
fill 165 280 627 165 280 629 minecraft:sea_lantern
fill 165 280 636 165 280 638 minecraft:netherite_block
fill 166 280 609 166 280 610 minecraft:netherite_block
fill 166 280 622 167 280 624 minecraft:sea_lantern
fill 166 280 626 174 280 626 minecraft:iron_block
fill 166 280 627 166 280 630 minecraft:gold_block
fill 166 280 638 182 280 638 minecraft:netherite_block
fill 167 280 617 167 280 619 minecraft:sea_lantern
fill 167 280 627 173 280 628 minecraft:iron_block
fill 167 280 629 167 280 630 minecraft:gold_block
fill 167 280 636 167 280 637 minecraft:netherite_block
fill 168 280 610 169 280 610 minecraft:netherite_block
fill 168 280 613 172 280 613 minecraft:gold_block
setblock 168 280 616 minecraft:iron_block
fill 168 280 617 175 280 620 minecraft:gold_block
fill 168 280 622 170 280 624 minecraft:netherite_block
fill 168 280 629 172 280 629 minecraft:iron_block
setblock 168 280 630 minecraft:gold_block
setblock 168 280 637 minecraft:netherite_block
fill 169 280 609 182 280 609 minecraft:netherite_block
fill 169 280 615 174 280 616 minecraft:gold_block
fill 169 280 630 170 280 631 minecraft:iron_block
fill 170 280 614 172 280 614 minecraft:gold_block
fill 170 280 635 170 280 637 minecraft:netherite_block
fill 171 280 610 171 280 612 minecraft:netherite_block
fill 171 280 622 171 280 624 minecraft:sea_lantern
setblock 171 280 630 minecraft:iron_block
fill 171 280 631 173 280 631 minecraft:gold_block
fill 171 280 637 182 280 637 minecraft:netherite_block
fill 172 280 610 172 280 611 minecraft:netherite_block
fill 172 280 621 176 280 622 minecraft:gold_block
fill 172 280 623 174 280 625 minecraft:iron_block
fill 172 280 630 174 280 630 minecraft:gold_block
fill 172 280 634 173 280 634 minecraft:netherite_block
fill 172 280 636 182 280 636 minecraft:netherite_block
fill 173 280 610 182 280 610 minecraft:netherite_block
setblock 173 280 613 minecraft:netherite_block
fill 173 280 629 176 280 629 minecraft:gold_block
fill 173 280 635 182 280 635 minecraft:netherite_block
fill 174 280 611 182 280 612 minecraft:netherite_block
fill 174 280 627 176 280 628 minecraft:gold_block
setblock 174 280 632 minecraft:netherite_block
fill 175 280 614 175 280 615 minecraft:netherite_block
fill 175 280 616 177 280 616 minecraft:gold_block
fill 175 280 623 176 280 626 minecraft:gold_block
fill 175 280 630 182 280 630 minecraft:netherite_block
fill 175 280 633 182 280 634 minecraft:netherite_block
fill 176 280 613 182 280 614 minecraft:netherite_block
fill 176 280 617 182 280 617 minecraft:netherite_block
setblock 176 280 620 minecraft:gold_block
fill 176 280 631 182 280 631 minecraft:netherite_block
fill 177 280 615 182 280 615 minecraft:netherite_block
fill 177 280 620 182 280 620 minecraft:netherite_block
fill 177 280 621 178 280 621 minecraft:gold_block
fill 177 280 622 182 280 622 minecraft:netherite_block
fill 177 280 625 182 280 625 minecraft:netherite_block
fill 177 280 626 178 280 626 minecraft:gold_block
fill 177 280 627 177 280 628 minecraft:netherite_block
fill 177 280 632 182 280 632 minecraft:netherite_block
fill 178 280 616 182 280 616 minecraft:netherite_block
fill 178 280 619 182 280 619 minecraft:netherite_block
fill 178 280 628 182 280 629 minecraft:netherite_block
fill 179 280 618 182 280 618 minecraft:netherite_block
fill 179 280 621 182 280 621 minecraft:netherite_block
fill 179 280 624 182 280 624 minecraft:netherite_block
fill 179 280 626 182 280 627 minecraft:netherite_block
fill 180 280 623 182 280 623 minecraft:netherite_block
fill 142 284 606 142 300 606 minecraft:iron_block
fill 142 284 616 142 300 616 minecraft:iron_block
fill 142 284 626 142 300 626 minecraft:iron_block
fill 142 284 636 142 300 636 minecraft:iron_block
fill 143 284 645 143 300 645 minecraft:iron_block
fill 149 284 605 149 300 605 minecraft:iron_block
fill 153 284 645 153 300 645 minecraft:iron_block
fill 159 284 605 159 300 605 minecraft:iron_block
fill 163 284 645 163 300 645 minecraft:iron_block
fill 169 284 605 169 300 605 minecraft:iron_block
fill 173 284 645 173 300 645 minecraft:iron_block
setblock 177 284 622 minecraft:sea_lantern
fill 177 284 639 179 300 641 minecraft:iron_block
fill 178 284 621 182 284 623 minecraft:iron_block
schedule function dropper:buildpart/147_2 1t
