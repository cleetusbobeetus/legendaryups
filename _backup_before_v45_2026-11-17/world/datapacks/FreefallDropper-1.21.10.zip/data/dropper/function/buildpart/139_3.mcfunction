setblock 333 126 591 minecraft:oak_log
fill 333 126 592 333 129 592 minecraft:green_terracotta
setblock 333 126 596 minecraft:oak_log
fill 333 126 597 333 129 597 minecraft:green_terracotta
setblock 334 126 595 minecraft:oak_log
fill 334 126 596 334 129 596 minecraft:green_terracotta
fill 335 126 595 335 129 595 minecraft:green_terracotta
setblock 336 126 558 minecraft:oak_log
setblock 336 126 598 minecraft:oak_log
setblock 337 126 558 minecraft:oak_leaves[persistent=true]
setblock 337 126 597 minecraft:oak_log
fill 337 126 598 337 129 598 minecraft:green_terracotta
setblock 338 126 596 minecraft:oak_log
fill 338 126 597 338 129 597 minecraft:green_terracotta
setblock 341 126 598 minecraft:oak_log
fill 348 126 598 350 126 598 minecraft:green_terracotta
setblock 350 126 558 minecraft:green_terracotta
setblock 351 126 558 minecraft:oak_log
setblock 351 126 597 minecraft:green_terracotta
setblock 351 126 598 minecraft:oak_log
fill 352 126 558 352 129 558 minecraft:green_terracotta
setblock 352 126 597 minecraft:oak_log
fill 352 126 598 355 126 598 minecraft:green_terracotta
fill 353 126 597 353 129 597 minecraft:green_terracotta
setblock 354 126 559 minecraft:green_terracotta
setblock 355 126 559 minecraft:oak_log
setblock 356 126 558 minecraft:oak_log
fill 356 126 559 356 129 559 minecraft:green_terracotta
setblock 356 126 597 minecraft:green_terracotta
setblock 356 126 598 minecraft:oak_log
fill 357 126 558 357 129 558 minecraft:green_terracotta
setblock 357 126 597 minecraft:oak_log
fill 357 126 598 357 129 598 minecraft:green_terracotta
setblock 360 126 598 minecraft:green_terracotta
setblock 361 126 558 minecraft:oak_log
setblock 361 126 598 minecraft:oak_log
fill 362 126 558 365 126 558 minecraft:green_terracotta
fill 362 126 598 365 126 598 minecraft:green_terracotta
setblock 366 126 558 minecraft:oak_log
setblock 366 126 598 minecraft:oak_log
fill 367 126 558 367 129 558 minecraft:green_terracotta
setblock 367 126 597 minecraft:oak_log
fill 367 126 598 367 129 598 minecraft:green_terracotta
fill 368 126 597 368 129 597 minecraft:green_terracotta
setblock 369 126 559 minecraft:green_terracotta
fill 369 126 568 369 126 569 minecraft:green_terracotta
setblock 369 126 570 minecraft:oak_log
fill 369 126 571 369 129 571 minecraft:green_terracotta
fill 369 126 573 369 126 574 minecraft:green_terracotta
setblock 369 126 590 minecraft:oak_log
fill 369 126 591 369 129 591 minecraft:green_terracotta
fill 369 126 593 369 126 594 minecraft:green_terracotta
setblock 369 126 595 minecraft:oak_log
fill 369 126 596 369 129 596 minecraft:green_terracotta
setblock 370 126 559 minecraft:oak_log
fill 370 126 560 370 129 560 minecraft:green_terracotta
setblock 370 126 564 minecraft:oak_log
fill 370 126 565 370 129 565 minecraft:green_terracotta
setblock 370 126 569 minecraft:oak_log
fill 370 126 570 370 129 570 minecraft:green_terracotta
setblock 370 126 574 minecraft:oak_log
fill 370 126 575 370 129 575 minecraft:green_terracotta
fill 370 126 577 370 127 577 minecraft:green_terracotta
fill 370 126 587 370 126 588 minecraft:green_terracotta
setblock 370 126 589 minecraft:oak_log
fill 370 126 590 370 129 590 minecraft:green_terracotta
setblock 370 126 594 minecraft:oak_log
fill 370 126 595 370 129 595 minecraft:green_terracotta
setblock 330 127 558 minecraft:oak_log
fill 330 127 559 330 130 559 minecraft:green_terracotta
fill 330 127 561 330 127 562 minecraft:green_terracotta
setblock 330 127 563 minecraft:oak_log
fill 330 127 564 330 130 564 minecraft:green_terracotta
setblock 330 127 568 minecraft:oak_log
fill 330 127 569 330 130 569 minecraft:green_terracotta
setblock 330 127 572 minecraft:green_terracotta
setblock 330 127 573 minecraft:oak_log
fill 330 127 574 330 130 574 minecraft:green_terracotta
setblock 330 127 578 minecraft:oak_log
fill 330 127 579 330 127 582 minecraft:green_terracotta
setblock 330 127 583 minecraft:oak_log
fill 330 127 584 331 129 584 minecraft:green_terracotta
setblock 330 127 588 minecraft:oak_log
fill 330 127 589 330 130 589 minecraft:green_terracotta
setblock 330 127 593 minecraft:oak_log
fill 330 127 594 330 129 595 minecraft:green_terracotta
setblock 330 127 598 minecraft:oak_log
fill 331 127 558 331 130 558 minecraft:green_terracotta
setblock 331 127 568 minecraft:green_terracotta
setblock 331 127 572 minecraft:oak_log
fill 331 127 573 332 129 573 minecraft:green_terracotta
setblock 331 127 576 minecraft:green_terracotta
setblock 331 127 577 minecraft:oak_log
fill 331 127 578 331 127 581 minecraft:green_terracotta
setblock 331 127 582 minecraft:oak_log
fill 331 127 583 331 130 583 minecraft:green_terracotta
setblock 331 127 587 minecraft:oak_log
fill 331 127 588 331 130 588 minecraft:green_terracotta
setblock 331 127 592 minecraft:oak_log
fill 331 127 593 331 130 593 minecraft:green_terracotta
fill 331 127 595 332 127 595 minecraft:green_terracotta
setblock 331 127 597 minecraft:oak_log
fill 331 127 598 331 130 598 minecraft:green_terracotta
fill 332 127 572 332 130 572 minecraft:green_terracotta
fill 332 127 574 332 127 575 minecraft:green_terracotta
setblock 332 127 576 minecraft:oak_log
fill 332 127 577 332 130 577 minecraft:green_terracotta
fill 332 127 587 332 130 587 minecraft:green_terracotta
setblock 332 127 590 minecraft:green_terracotta
setblock 332 127 591 minecraft:oak_log
fill 332 127 592 332 130 592 minecraft:green_terracotta
setblock 332 127 596 minecraft:oak_log
fill 332 127 597 332 130 597 minecraft:green_terracotta
setblock 333 127 590 minecraft:oak_log
fill 333 127 591 333 129 591 minecraft:green_terracotta
setblock 333 127 595 minecraft:oak_log
fill 333 127 596 333 130 596 minecraft:green_terracotta
setblock 334 127 558 minecraft:green_terracotta
setblock 334 127 593 minecraft:green_terracotta
setblock 334 127 594 minecraft:oak_log
fill 334 127 595 334 130 595 minecraft:green_terracotta
setblock 335 127 558 minecraft:oak_log
setblock 335 127 598 minecraft:oak_log
fill 336 127 558 336 130 558 minecraft:green_terracotta
setblock 336 127 597 minecraft:oak_log
fill 336 127 598 336 130 598 minecraft:green_terracotta
setblock 337 127 596 minecraft:oak_log
fill 337 127 597 337 130 597 minecraft:green_terracotta
fill 338 127 596 338 128 596 minecraft:green_terracotta
setblock 340 127 597 minecraft:green_terracotta
setblock 340 127 598 minecraft:oak_log
fill 341 127 598 342 129 598 minecraft:green_terracotta
setblock 344 127 598 minecraft:oak_leaves[persistent=true]
fill 346 127 598 349 127 598 minecraft:green_terracotta
setblock 349 127 558 minecraft:green_terracotta
fill 349 127 597 350 127 597 minecraft:green_terracotta
setblock 350 127 558 minecraft:oak_log
setblock 350 127 598 minecraft:oak_log
fill 351 127 558 351 130 558 minecraft:green_terracotta
setblock 351 127 597 minecraft:oak_log
fill 351 127 598 354 127 598 minecraft:green_terracotta
fill 352 127 559 353 127 559 minecraft:green_terracotta
fill 352 127 597 352 130 597 minecraft:green_terracotta
setblock 354 127 558 minecraft:green_terracotta
setblock 354 127 559 minecraft:oak_log
setblock 355 127 558 minecraft:oak_log
fill 355 127 559 355 130 559 minecraft:green_terracotta
setblock 355 127 598 minecraft:oak_log
fill 356 127 558 356 130 558 minecraft:green_terracotta
setblock 356 127 597 minecraft:oak_log
fill 356 127 598 356 130 598 minecraft:green_terracotta
fill 357 127 559 357 128 559 minecraft:green_terracotta
fill 357 127 597 358 129 597 minecraft:green_terracotta
fill 358 127 558 359 127 558 minecraft:green_terracotta
setblock 360 127 558 minecraft:oak_log
setblock 360 127 598 minecraft:oak_log
fill 361 127 558 364 127 558 minecraft:green_terracotta
fill 361 127 598 364 127 598 minecraft:green_terracotta
setblock 365 127 558 minecraft:oak_log
setblock 365 127 597 minecraft:green_terracotta
setblock 365 127 598 minecraft:oak_log
fill 366 127 558 366 130 558 minecraft:green_terracotta
setblock 366 127 597 minecraft:oak_log
fill 366 127 598 366 130 598 minecraft:green_terracotta
fill 367 127 597 367 130 597 minecraft:green_terracotta
setblock 368 127 559 minecraft:green_terracotta
setblock 368 127 594 minecraft:green_terracotta
setblock 368 127 595 minecraft:oak_log
fill 368 127 596 368 130 596 minecraft:green_terracotta
setblock 369 127 559 minecraft:oak_log
fill 369 127 560 369 129 561 minecraft:green_terracotta
fill 369 127 566 369 128 566 minecraft:green_terracotta
setblock 369 127 568 minecraft:green_terracotta
setblock 369 127 569 minecraft:oak_log
fill 369 127 570 369 130 570 minecraft:green_terracotta
setblock 369 127 573 minecraft:green_terracotta
setblock 369 127 574 minecraft:oak_log
fill 369 127 575 369 130 575 minecraft:green_terracotta
fill 369 127 590 369 130 590 minecraft:green_terracotta
setblock 369 127 593 minecraft:green_terracotta
setblock 369 127 594 minecraft:oak_log
fill 369 127 595 369 130 595 minecraft:green_terracotta
setblock 370 127 558 minecraft:oak_log
fill 370 127 559 370 130 559 minecraft:green_terracotta
setblock 370 127 563 minecraft:oak_log
fill 370 127 564 370 130 564 minecraft:green_terracotta
setblock 370 127 568 minecraft:oak_log
fill 370 127 569 370 130 569 minecraft:green_terracotta
setblock 370 127 573 minecraft:oak_log
fill 370 127 574 370 130 574 minecraft:green_terracotta
setblock 370 127 578 minecraft:oak_log
fill 370 127 579 370 130 579 minecraft:green_terracotta
fill 370 127 586 370 127 587 minecraft:green_terracotta
setblock 370 127 588 minecraft:oak_log
fill 370 127 589 370 130 589 minecraft:green_terracotta
setblock 370 127 593 minecraft:oak_log
fill 370 127 594 370 130 594 minecraft:green_terracotta
setblock 370 127 598 minecraft:oak_log
fill 330 128 558 330 131 558 minecraft:green_terracotta
setblock 330 128 561 minecraft:green_terracotta
setblock 330 128 562 minecraft:oak_log
fill 330 128 563 330 131 563 minecraft:green_terracotta
setblock 330 128 567 minecraft:oak_log
fill 330 128 568 330 131 568 minecraft:green_terracotta
setblock 330 128 571 minecraft:green_terracotta
setblock 330 128 572 minecraft:oak_log
fill 330 128 573 330 131 573 minecraft:green_terracotta
setblock 330 128 576 minecraft:green_terracotta
setblock 330 128 577 minecraft:oak_log
fill 330 128 578 330 128 581 minecraft:green_terracotta
setblock 330 128 582 minecraft:oak_log
fill 330 128 583 330 131 583 minecraft:green_terracotta
setblock 330 128 586 minecraft:green_terracotta
setblock 330 128 587 minecraft:oak_log
fill 330 128 588 330 131 588 minecraft:green_terracotta
setblock 330 128 592 minecraft:oak_log
fill 330 128 593 330 131 593 minecraft:green_terracotta
setblock 330 128 597 minecraft:oak_log
fill 330 128 598 330 131 598 minecraft:green_terracotta
fill 331 128 559 332 128 559 minecraft:green_terracotta
setblock 331 128 571 minecraft:oak_log
fill 331 128 572 331 131 572 minecraft:green_terracotta
setblock 331 128 576 minecraft:oak_log
fill 331 128 577 331 128 580 minecraft:green_terracotta
setblock 331 128 581 minecraft:oak_log
fill 331 128 582 331 131 582 minecraft:green_terracotta
setblock 331 128 586 minecraft:oak_log
fill 331 128 587 331 131 587 minecraft:green_terracotta
setblock 331 128 591 minecraft:oak_log
fill 331 128 592 331 131 592 minecraft:green_terracotta
setblock 331 128 595 minecraft:green_terracotta
setblock 331 128 596 minecraft:oak_log
fill 331 128 597 331 131 597 minecraft:green_terracotta
setblock 332 128 560 minecraft:light[level=14]
setblock 332 128 568 minecraft:light[level=14]
setblock 332 128 571 minecraft:green_terracotta
setblock 332 128 574 minecraft:green_terracotta
setblock 332 128 575 minecraft:oak_log
fill 332 128 576 332 131 576 minecraft:green_terracotta
fill 332 128 578 332 128 579 minecraft:green_terracotta
setblock 332 128 584 minecraft:light[level=14]
fill 332 128 586 332 129 586 minecraft:green_terracotta
setblock 332 128 589 minecraft:green_terracotta
setblock 332 128 590 minecraft:oak_log
fill 332 128 591 332 131 591 minecraft:green_terracotta
setblock 332 128 595 minecraft:oak_log
fill 332 128 596 332 131 596 minecraft:green_terracotta
setblock 333 128 559 minecraft:oak_log
fill 333 128 590 333 129 590 minecraft:green_terracotta
setblock 333 128 594 minecraft:oak_log
fill 333 128 595 333 131 595 minecraft:green_terracotta
setblock 334 128 558 minecraft:oak_log
setblock 334 128 598 minecraft:oak_log
fill 335 128 558 335 131 558 minecraft:green_terracotta
setblock 335 128 597 minecraft:oak_log
fill 335 128 598 335 131 598 minecraft:green_terracotta
setblock 336 128 596 minecraft:oak_log
fill 336 128 597 336 131 597 minecraft:green_terracotta
fill 337 128 558 337 129 558 minecraft:green_terracotta
fill 337 128 596 337 130 596 minecraft:green_terracotta
setblock 339 128 598 minecraft:oak_log
setblock 340 128 560 minecraft:light[level=14]
setblock 340 128 568 minecraft:light[level=14]
setblock 340 128 576 minecraft:light[level=14]
setblock 340 128 584 minecraft:light[level=14]
setblock 340 128 592 minecraft:light[level=14]
setblock 340 128 597 minecraft:oak_log
fill 340 128 598 340 131 598 minecraft:green_terracotta
setblock 343 128 598 minecraft:green_terracotta
setblock 344 128 598 minecraft:oak_log
fill 345 128 598 348 128 598 minecraft:green_terracotta
setblock 348 128 558 minecraft:green_terracotta
setblock 348 128 560 minecraft:light[level=14]
setblock 348 128 568 minecraft:light[level=14]
setblock 348 128 576 minecraft:light[level=14]
setblock 348 128 584 minecraft:light[level=14]
setblock 348 128 592 minecraft:light[level=14]
fill 348 128 597 349 128 597 minecraft:green_terracotta
setblock 349 128 558 minecraft:oak_log
setblock 349 128 598 minecraft:oak_log
fill 350 128 558 350 130 559 minecraft:green_terracotta
setblock 350 128 597 minecraft:oak_log
fill 350 128 598 353 128 598 minecraft:green_terracotta
fill 351 128 559 352 128 559 minecraft:green_terracotta
setblock 351 128 596 minecraft:oak_log
fill 351 128 597 351 131 597 minecraft:green_terracotta
fill 352 128 596 354 129 596 minecraft:green_terracotta
setblock 353 128 559 minecraft:oak_log
setblock 354 128 558 minecraft:oak_log
fill 354 128 559 354 131 559 minecraft:green_terracotta
setblock 354 128 597 minecraft:green_terracotta
setblock 354 128 598 minecraft:oak_log
fill 355 128 558 355 131 558 minecraft:green_terracotta
setblock 355 128 597 minecraft:oak_log
fill 355 128 598 355 131 598 minecraft:green_terracotta
setblock 356 128 560 minecraft:light[level=14]
setblock 356 128 568 minecraft:light[level=14]
setblock 356 128 576 minecraft:light[level=14]
setblock 356 128 584 minecraft:light[level=14]
setblock 356 128 592 minecraft:light[level=14]
fill 356 128 597 356 131 597 minecraft:green_terracotta
setblock 358 128 558 minecraft:green_terracotta
setblock 358 128 559 minecraft:oak_log
setblock 358 128 598 minecraft:green_terracotta
setblock 359 128 558 minecraft:oak_log
setblock 359 128 597 minecraft:green_terracotta
setblock 359 128 598 minecraft:oak_log
fill 360 128 558 363 128 558 minecraft:green_terracotta
fill 360 128 598 363 128 598 minecraft:green_terracotta
fill 363 128 597 364 128 597 minecraft:green_terracotta
setblock 364 128 558 minecraft:oak_log
setblock 364 128 560 minecraft:light[level=14]
setblock 364 128 568 minecraft:light[level=14]
setblock 364 128 576 minecraft:light[level=14]
setblock 364 128 584 minecraft:light[level=14]
setblock 364 128 592 minecraft:light[level=14]
setblock 364 128 598 minecraft:oak_log
fill 365 128 558 365 131 558 minecraft:green_terracotta
setblock 365 128 597 minecraft:oak_log
fill 365 128 598 365 131 598 minecraft:green_terracotta
fill 366 128 559 367 128 559 minecraft:green_terracotta
fill 366 128 597 366 131 597 minecraft:green_terracotta
fill 367 128 596 367 131 596 minecraft:green_terracotta
setblock 368 128 559 minecraft:oak_log
setblock 368 128 593 minecraft:green_terracotta
setblock 368 128 594 minecraft:oak_log
fill 368 128 595 368 131 595 minecraft:green_terracotta
setblock 369 128 558 minecraft:oak_log
fill 369 128 559 369 131 559 minecraft:green_terracotta
setblock 369 128 562 minecraft:green_terracotta
setblock 369 128 568 minecraft:oak_log
fill 369 128 569 369 130 569 minecraft:green_terracotta
setblock 369 128 573 minecraft:oak_log
fill 369 128 574 369 131 574 minecraft:green_terracotta
fill 369 128 576 369 128 577 minecraft:green_terracotta
fill 369 128 589 369 131 589 minecraft:green_terracotta
setblock 369 128 593 minecraft:oak_log
fill 369 128 594 369 131 594 minecraft:green_terracotta
setblock 369 128 598 minecraft:oak_log
fill 370 128 558 370 131 558 minecraft:green_terracotta
setblock 370 128 562 minecraft:oak_log
fill 370 128 563 370 131 563 minecraft:green_terracotta
setblock 370 128 567 minecraft:oak_log
fill 370 128 568 370 131 568 minecraft:green_terracotta
setblock 370 128 572 minecraft:oak_log
fill 370 128 573 370 131 573 minecraft:green_terracotta
setblock 370 128 577 minecraft:oak_log
fill 370 128 578 370 131 578 minecraft:green_terracotta
fill 370 128 580 370 128 581 minecraft:green_terracotta
setblock 370 128 582 minecraft:oak_log
fill 370 128 584 370 128 586 minecraft:green_terracotta
setblock 370 128 587 minecraft:oak_log
fill 370 128 588 370 131 588 minecraft:green_terracotta
setblock 370 128 592 minecraft:oak_log
fill 370 128 593 370 131 593 minecraft:green_terracotta
setblock 370 128 597 minecraft:oak_log
fill 370 128 598 370 131 598 minecraft:green_terracotta
setblock 330 129 561 minecraft:oak_log
fill 330 129 562 330 132 562 minecraft:green_terracotta
setblock 330 129 566 minecraft:oak_log
fill 330 129 567 330 131 567 minecraft:green_terracotta
setblock 330 129 571 minecraft:oak_log
fill 330 129 572 330 132 572 minecraft:green_terracotta
setblock 330 129 575 minecraft:green_terracotta
setblock 330 129 576 minecraft:oak_log
fill 330 129 577 330 129 580 minecraft:green_terracotta
setblock 330 129 581 minecraft:oak_log
fill 330 129 582 330 132 582 minecraft:green_terracotta
setblock 330 129 585 minecraft:green_terracotta
setblock 330 129 586 minecraft:oak_log
fill 330 129 587 330 132 587 minecraft:green_terracotta
setblock 330 129 591 minecraft:oak_log
fill 330 129 592 330 132 592 minecraft:green_terracotta
setblock 330 129 596 minecraft:oak_log
fill 330 129 597 330 132 597 minecraft:green_terracotta
setblock 331 129 559 minecraft:green_terracotta
setblock 331 129 560 minecraft:oak_log
setblock 331 129 570 minecraft:oak_log
fill 331 129 571 331 131 571 minecraft:green_terracotta
setblock 331 129 575 minecraft:oak_log
fill 331 129 576 331 129 579 minecraft:green_terracotta
setblock 331 129 580 minecraft:oak_log
fill 331 129 581 332 131 581 minecraft:green_terracotta
setblock 331 129 585 minecraft:oak_log
fill 331 129 586 331 132 586 minecraft:green_terracotta
setblock 331 129 590 minecraft:oak_log
fill 331 129 591 331 132 591 minecraft:green_terracotta
setblock 331 129 595 minecraft:oak_log
fill 331 129 596 331 132 596 minecraft:green_terracotta
setblock 332 129 559 minecraft:oak_log
setblock 332 129 574 minecraft:oak_log
fill 332 129 575 332 132 575 minecraft:green_terracotta
setblock 332 129 578 minecraft:green_terracotta
setblock 332 129 579 minecraft:oak_log
fill 332 129 580 332 132 580 minecraft:green_terracotta
fill 332 129 582 332 130 582 minecraft:green_terracotta
setblock 332 129 589 minecraft:oak_log
fill 332 129 590 332 131 590 minecraft:green_terracotta
setblock 332 129 594 minecraft:oak_log
fill 332 129 595 332 132 595 minecraft:green_terracotta
setblock 333 129 558 minecraft:oak_log
fill 333 129 559 333 131 559 minecraft:green_terracotta
setblock 333 129 593 minecraft:oak_log
fill 333 129 594 333 131 594 minecraft:green_terracotta
setblock 333 129 598 minecraft:oak_log
fill 334 129 558 334 132 558 minecraft:green_terracotta
setblock 334 129 597 minecraft:oak_log
fill 334 129 598 334 132 598 minecraft:green_terracotta
setblock 335 129 596 minecraft:oak_log
fill 335 129 597 335 132 597 minecraft:green_terracotta
fill 336 129 596 336 131 596 minecraft:green_terracotta
setblock 338 129 598 minecraft:oak_log
setblock 339 129 597 minecraft:oak_log
fill 339 129 598 339 132 598 minecraft:green_terracotta
setblock 343 129 598 minecraft:oak_log
setblock 344 129 558 minecraft:oak_leaves[persistent=true]
fill 344 129 598 347 129 598 minecraft:green_terracotta
fill 346 129 558 347 129 558 minecraft:green_terracotta
fill 347 129 597 348 129 597 minecraft:green_terracotta
setblock 348 129 558 minecraft:oak_log
setblock 348 129 598 minecraft:oak_log
fill 349 129 558 349 131 559 minecraft:green_terracotta
setblock 349 129 597 minecraft:oak_log
fill 349 129 598 352 129 598 minecraft:green_terracotta
setblock 350 129 596 minecraft:oak_log
fill 350 129 597 350 132 597 minecraft:green_terracotta
setblock 351 129 559 minecraft:green_terracotta
fill 351 129 596 351 130 596 minecraft:green_terracotta
setblock 352 129 559 minecraft:oak_log
setblock 353 129 558 minecraft:oak_log
fill 353 129 559 353 132 559 minecraft:green_terracotta
setblock 353 129 598 minecraft:oak_log
fill 354 129 558 354 132 558 minecraft:green_terracotta
setblock 354 129 597 minecraft:oak_log
fill 354 129 598 354 132 598 minecraft:green_terracotta
fill 355 129 597 355 132 597 minecraft:green_terracotta
setblock 357 129 559 minecraft:oak_log
setblock 358 129 558 minecraft:oak_log
fill 358 129 559 359 131 559 minecraft:green_terracotta
setblock 358 129 598 minecraft:oak_log
fill 359 129 558 362 129 558 minecraft:green_terracotta
setblock 359 129 597 minecraft:oak_log
fill 359 129 598 362 129 598 minecraft:green_terracotta
fill 362 129 597 363 129 597 minecraft:green_terracotta
setblock 363 129 558 minecraft:oak_log
setblock 363 129 598 minecraft:oak_log
fill 364 129 558 364 131 559 minecraft:green_terracotta
setblock 364 129 597 minecraft:oak_log
fill 364 129 598 364 132 598 minecraft:green_terracotta
fill 365 129 559 366 129 559 minecraft:green_terracotta
fill 365 129 597 365 132 597 minecraft:green_terracotta
fill 366 129 596 366 132 596 minecraft:green_terracotta
setblock 367 129 559 minecraft:oak_log
setblock 368 129 558 minecraft:oak_log
fill 368 129 559 368 132 559 minecraft:green_terracotta
setblock 368 129 592 minecraft:green_terracotta
setblock 368 129 593 minecraft:oak_log
fill 368 129 594 368 132 594 minecraft:green_terracotta
setblock 368 129 598 minecraft:oak_log
fill 369 129 558 369 132 558 minecraft:green_terracotta
setblock 369 129 562 minecraft:oak_log
fill 369 129 563 369 132 563 minecraft:green_terracotta
setblock 369 129 567 minecraft:oak_log
setblock 369 129 568 minecraft:green_terracotta
setblock 369 129 572 minecraft:oak_log
fill 369 129 573 369 132 573 minecraft:green_terracotta
setblock 369 129 576 minecraft:green_terracotta
setblock 369 129 577 minecraft:oak_log
fill 369 129 578 369 132 578 minecraft:green_terracotta
setblock 369 129 592 minecraft:oak_log
fill 369 129 593 369 132 593 minecraft:green_terracotta
setblock 369 129 597 minecraft:oak_log
fill 369 129 598 369 132 598 minecraft:green_terracotta
setblock 370 129 561 minecraft:oak_log
fill 370 129 562 370 132 562 minecraft:green_terracotta
setblock 370 129 566 minecraft:oak_log
fill 370 129 567 370 132 567 minecraft:green_terracotta
setblock 370 129 571 minecraft:oak_log
fill 370 129 572 370 132 572 minecraft:green_terracotta
setblock 370 129 576 minecraft:oak_log
fill 370 129 577 370 132 577 minecraft:green_terracotta
setblock 370 129 580 minecraft:green_terracotta
setblock 370 129 581 minecraft:oak_log
fill 370 129 582 370 129 585 minecraft:green_terracotta
setblock 370 129 586 minecraft:oak_log
fill 370 129 587 370 132 587 minecraft:green_terracotta
setblock 370 129 591 minecraft:oak_log
fill 370 129 592 370 132 592 minecraft:green_terracotta
setblock 370 129 596 minecraft:oak_log
fill 370 129 597 370 132 597 minecraft:green_terracotta
setblock 330 130 560 minecraft:oak_log
fill 330 130 561 330 133 561 minecraft:green_terracotta
setblock 330 130 565 minecraft:oak_log
setblock 330 130 566 minecraft:green_terracotta
setblock 330 130 570 minecraft:oak_log
fill 330 130 571 330 133 571 minecraft:green_terracotta
setblock 330 130 575 minecraft:oak_log
fill 330 130 576 330 130 579 minecraft:green_terracotta
setblock 330 130 580 minecraft:oak_log
fill 330 130 581 330 133 581 minecraft:green_terracotta
setblock 330 130 584 minecraft:green_terracotta
setblock 330 130 585 minecraft:oak_log
fill 330 130 586 330 133 586 minecraft:green_terracotta
setblock 330 130 590 minecraft:oak_log
fill 330 130 591 330 133 591 minecraft:green_terracotta
setblock 330 130 594 minecraft:green_terracotta
setblock 330 130 595 minecraft:oak_log
fill 330 130 596 330 133 596 minecraft:green_terracotta
setblock 331 130 559 minecraft:oak_log
fill 331 130 560 331 132 560 minecraft:green_terracotta
setblock 331 130 570 minecraft:green_terracotta
setblock 331 130 573 minecraft:green_terracotta
setblock 331 130 574 minecraft:oak_log
fill 331 130 575 331 130 578 minecraft:green_terracotta
setblock 331 130 579 minecraft:oak_log
fill 331 130 580 331 133 580 minecraft:green_terracotta
setblock 331 130 584 minecraft:oak_log
fill 331 130 585 331 133 585 minecraft:green_terracotta
setblock 331 130 589 minecraft:oak_log
fill 331 130 590 331 133 590 minecraft:green_terracotta
setblock 331 130 594 minecraft:oak_log
fill 331 130 595 331 133 595 minecraft:green_terracotta
setblock 332 130 558 minecraft:oak_log
fill 332 130 559 332 132 559 minecraft:green_terracotta
setblock 332 130 573 minecraft:oak_log
fill 332 130 574 332 132 574 minecraft:green_terracotta
setblock 332 130 578 minecraft:oak_log
fill 332 130 579 332 133 579 minecraft:green_terracotta
setblock 332 130 583 minecraft:oak_log
setblock 332 130 588 minecraft:oak_log
fill 332 130 589 332 131 589 minecraft:green_terracotta
setblock 332 130 593 minecraft:oak_log
fill 332 130 594 332 133 594 minecraft:green_terracotta
setblock 332 130 598 minecraft:oak_log
fill 333 130 558 333 133 558 minecraft:green_terracotta
setblock 333 130 592 minecraft:oak_log
setblock 333 130 593 minecraft:green_terracotta
setblock 333 130 597 minecraft:oak_log
fill 333 130 598 333 133 598 minecraft:green_terracotta
setblock 334 130 596 minecraft:oak_log
fill 334 130 597 334 133 597 minecraft:green_terracotta
setblock 335 130 595 minecraft:oak_log
fill 335 130 596 335 131 596 minecraft:green_terracotta
setblock 337 130 558 minecraft:oak_log
setblock 337 130 598 minecraft:oak_log
setblock 338 130 558 minecraft:oak_leaves[persistent=true]
setblock 338 130 597 minecraft:oak_log
fill 338 130 598 338 133 598 minecraft:green_terracotta
setblock 339 130 597 minecraft:green_terracotta
setblock 341 130 598 minecraft:green_terracotta
setblock 342 130 598 minecraft:oak_log
fill 343 130 578 343 130 582 minecraft:oak_leaves[persistent=true]
fill 343 130 598 346 130 598 minecraft:green_terracotta
fill 344 130 577 347 130 578 minecraft:oak_leaves[persistent=true]
fill 344 130 581 344 131 582 minecraft:oak_leaves[persistent=true]
fill 345 130 558 346 130 558 minecraft:green_terracotta
fill 345 130 582 346 130 583 minecraft:oak_leaves[persistent=true]
fill 346 130 597 347 130 597 minecraft:green_terracotta
setblock 347 130 558 minecraft:oak_log
fill 347 130 581 348 130 582 minecraft:oak_leaves[persistent=true]
setblock 347 130 598 minecraft:oak_log
fill 348 130 558 348 132 559 minecraft:green_terracotta
fill 348 130 578 348 130 580 minecraft:oak_leaves[persistent=true]
setblock 348 130 597 minecraft:oak_log
fill 348 130 598 351 130 598 minecraft:green_terracotta
fill 349 130 597 349 133 597 minecraft:green_terracotta
setblock 350 130 596 minecraft:green_terracotta
setblock 351 130 559 minecraft:oak_log
setblock 352 130 558 minecraft:oak_log
fill 352 130 559 352 132 560 minecraft:green_terracotta
fill 352 130 596 353 130 596 minecraft:green_terracotta
setblock 352 130 598 minecraft:oak_log
fill 353 130 558 353 133 558 minecraft:green_terracotta
fill 353 130 560 353 131 560 minecraft:green_terracotta
setblock 353 130 597 minecraft:oak_log
fill 353 130 598 353 133 598 minecraft:green_terracotta
fill 354 130 597 354 132 597 minecraft:green_terracotta
setblock 356 130 559 minecraft:oak_log
setblock 357 130 558 minecraft:oak_log
fill 357 130 559 357 133 559 minecraft:green_terracotta
setblock 357 130 597 minecraft:green_terracotta
setblock 357 130 598 minecraft:oak_log
fill 358 130 558 361 130 558 minecraft:green_terracotta
fill 358 130 571 359 131 572 minecraft:glowstone
setblock 358 130 597 minecraft:oak_log
fill 358 130 598 361 130 598 minecraft:green_terracotta
fill 359 130 570 359 131 570 minecraft:glowstone
setblock 359 130 597 minecraft:green_terracotta
setblock 360 130 559 minecraft:green_terracotta
fill 360 130 578 361 131 578 minecraft:glowstone
fill 361 130 586 362 130 587 minecraft:oak_leaves[persistent=true]
fill 361 130 597 362 130 597 minecraft:green_terracotta
setblock 362 130 558 minecraft:oak_log
fill 362 130 559 363 132 559 minecraft:green_terracotta
fill 362 130 584 363 130 585 minecraft:oak_leaves[persistent=true]
fill 362 130 588 363 130 588 minecraft:oak_leaves[persistent=true]
setblock 362 130 598 minecraft:oak_log
fill 363 130 558 363 133 558 minecraft:green_terracotta
fill 363 130 583 366 130 583 minecraft:oak_leaves[persistent=true]
fill 363 130 589 366 130 589 minecraft:oak_leaves[persistent=true]
setblock 363 130 597 minecraft:oak_log
fill 363 130 598 363 133 598 minecraft:green_terracotta
fill 364 130 584 367 130 584 minecraft:oak_leaves[persistent=true]
fill 364 130 597 364 133 597 minecraft:green_terracotta
setblock 365 130 559 minecraft:green_terracotta
fill 365 130 596 365 132 596 minecraft:green_terracotta
setblock 366 130 559 minecraft:oak_log
fill 366 130 588 367 131 588 minecraft:oak_leaves[persistent=true]
setblock 367 130 558 minecraft:oak_log
fill 367 130 559 367 133 559 minecraft:green_terracotta
fill 367 130 585 367 131 587 minecraft:oak_leaves[persistent=true]
setblock 367 130 598 minecraft:oak_log
fill 368 130 558 368 133 558 minecraft:green_terracotta
fill 368 130 560 369 130 560 minecraft:green_terracotta
fill 368 130 586 368 130 587 minecraft:oak_leaves[persistent=true]
setblock 368 130 592 minecraft:oak_log
fill 368 130 593 368 132 593 minecraft:green_terracotta
setblock 368 130 597 minecraft:oak_log
fill 368 130 598 368 133 598 minecraft:green_terracotta
setblock 369 130 561 minecraft:oak_log
fill 369 130 562 369 133 562 minecraft:green_terracotta
setblock 369 130 571 minecraft:oak_log
fill 369 130 572 369 132 572 minecraft:green_terracotta
setblock 369 130 576 minecraft:oak_log
fill 369 130 577 369 133 577 minecraft:green_terracotta
fill 369 130 579 369 131 579 minecraft:green_terracotta
setblock 369 130 591 minecraft:oak_log
fill 369 130 592 369 133 592 minecraft:green_terracotta
setblock 369 130 596 minecraft:oak_log
fill 369 130 597 369 133 597 minecraft:green_terracotta
setblock 370 130 560 minecraft:oak_log
fill 370 130 561 370 133 561 minecraft:green_terracotta
setblock 370 130 565 minecraft:oak_log
fill 370 130 566 370 132 566 minecraft:green_terracotta
setblock 370 130 570 minecraft:oak_log
fill 370 130 571 370 133 571 minecraft:green_terracotta
setblock 370 130 575 minecraft:oak_log
fill 370 130 576 370 133 576 minecraft:green_terracotta
setblock 370 130 580 minecraft:oak_log
fill 370 130 581 370 130 584 minecraft:green_terracotta
setblock 370 130 585 minecraft:oak_log
fill 370 130 586 370 133 586 minecraft:green_terracotta
setblock 370 130 590 minecraft:oak_log
fill 370 130 591 370 133 591 minecraft:green_terracotta
setblock 370 130 595 minecraft:oak_log
fill 370 130 596 370 133 596 minecraft:green_terracotta
setblock 330 131 559 minecraft:oak_log
fill 330 131 560 330 133 560 minecraft:green_terracotta
setblock 330 131 569 minecraft:oak_log
fill 330 131 570 330 133 570 minecraft:green_terracotta
setblock 330 131 574 minecraft:oak_log
fill 330 131 575 330 131 578 minecraft:green_terracotta
setblock 330 131 579 minecraft:oak_log
fill 330 131 580 330 133 580 minecraft:green_terracotta
setblock 330 131 584 minecraft:oak_log
fill 330 131 585 330 133 585 minecraft:green_terracotta
setblock 330 131 589 minecraft:oak_log
fill 330 131 590 330 133 590 minecraft:green_terracotta
setblock 330 131 594 minecraft:oak_log
fill 330 131 595 330 133 595 minecraft:green_terracotta
setblock 331 131 558 minecraft:oak_log
fill 331 131 559 331 133 559 minecraft:green_terracotta
setblock 331 131 573 minecraft:oak_log
fill 331 131 574 331 131 577 minecraft:green_terracotta
setblock 331 131 578 minecraft:oak_log
fill 331 131 579 331 133 579 minecraft:green_terracotta
setblock 331 131 583 minecraft:oak_log
fill 331 131 584 331 133 584 minecraft:green_terracotta
setblock 331 131 588 minecraft:oak_log
fill 331 131 589 331 133 589 minecraft:green_terracotta
setblock 331 131 593 minecraft:oak_log
fill 331 131 594 331 133 594 minecraft:green_terracotta
setblock 331 131 598 minecraft:oak_log
fill 332 131 558 332 133 558 minecraft:green_terracotta
setblock 332 131 573 minecraft:green_terracotta
setblock 332 131 577 minecraft:oak_log
fill 332 131 578 332 133 578 minecraft:green_terracotta
setblock 332 131 582 minecraft:oak_log
fill 332 131 583 332 132 583 minecraft:green_terracotta
setblock 332 131 592 minecraft:oak_log
fill 332 131 593 332 132 593 minecraft:green_terracotta
setblock 332 131 597 minecraft:oak_log
fill 332 131 598 332 133 598 minecraft:green_terracotta
setblock 333 131 596 minecraft:oak_log
fill 333 131 597 333 133 597 minecraft:green_terracotta
fill 334 131 596 334 132 596 minecraft:green_terracotta
setblock 336 131 558 minecraft:oak_log
setblock 336 131 598 minecraft:oak_log
setblock 337 131 597 minecraft:oak_log
fill 337 131 598 337 133 598 minecraft:green_terracotta
setblock 338 131 597 minecraft:green_terracotta
setblock 341 131 598 minecraft:oak_log
fill 342 131 598 345 131 598 minecraft:green_terracotta
fill 343 131 579 343 131 581 minecraft:oak_leaves[persistent=true]
fill 344 131 578 347 132 578 minecraft:oak_leaves[persistent=true]
setblock 345 131 558 minecraft:green_terracotta
fill 345 131 577 346 131 577 minecraft:oak_leaves[persistent=true]
fill 345 131 582 347 131 582 minecraft:oak_leaves[persistent=true]
setblock 346 131 558 minecraft:oak_log
setblock 346 131 597 minecraft:green_terracotta
setblock 346 131 598 minecraft:oak_log
fill 347 131 558 347 133 559 minecraft:green_terracotta
fill 347 131 581 348 131 581 minecraft:oak_leaves[persistent=true]
setblock 347 131 597 minecraft:oak_log
fill 347 131 598 350 131 598 minecraft:green_terracotta
fill 348 131 579 348 131 580 minecraft:oak_leaves[persistent=true]
fill 348 131 597 348 133 597 minecraft:green_terracotta
setblock 350 131 558 minecraft:green_terracotta
setblock 350 131 559 minecraft:oak_log
setblock 351 131 558 minecraft:oak_log
fill 351 131 559 351 133 560 minecraft:green_terracotta
setblock 351 131 598 minecraft:oak_log
fill 352 131 558 352 133 558 minecraft:green_terracotta
setblock 352 131 597 minecraft:oak_log
fill 352 131 598 352 133 598 minecraft:green_terracotta
fill 353 131 562 353 133 562 minecraft:iron_block
fill 353 131 597 353 133 597 minecraft:green_terracotta
setblock 355 131 559 minecraft:oak_log
setblock 356 131 558 minecraft:oak_log
fill 356 131 559 356 133 559 minecraft:green_terracotta
setblock 356 131 598 minecraft:oak_log
fill 357 131 558 360 131 558 minecraft:green_terracotta
setblock 357 131 597 minecraft:oak_log
fill 357 131 598 360 131 598 minecraft:green_terracotta
setblock 360 131 559 minecraft:oak_log
setblock 361 131 558 minecraft:oak_log
fill 361 131 559 361 133 559 minecraft:green_terracotta
setblock 361 131 598 minecraft:oak_log
fill 362 131 558 362 133 558 minecraft:green_terracotta
fill 362 131 585 362 131 587 minecraft:oak_leaves[persistent=true]
setblock 362 131 597 minecraft:oak_log
fill 362 131 598 362 133 598 minecraft:green_terracotta
fill 363 131 584 363 131 585 minecraft:oak_leaves[persistent=true]
fill 363 131 588 363 132 588 minecraft:oak_leaves[persistent=true]
fill 363 131 597 363 133 597 minecraft:green_terracotta
fill 364 131 584 366 131 584 minecraft:oak_leaves[persistent=true]
fill 364 131 589 365 131 589 minecraft:oak_leaves[persistent=true]
setblock 365 131 559 minecraft:oak_log
setblock 366 131 558 minecraft:oak_log
fill 366 131 559 366 133 559 minecraft:green_terracotta
setblock 366 131 598 minecraft:oak_log
fill 367 131 558 367 133 558 minecraft:green_terracotta
setblock 367 131 597 minecraft:oak_log
fill 367 131 598 367 133 598 minecraft:green_terracotta
setblock 368 131 560 minecraft:green_terracotta
setblock 368 131 596 minecraft:oak_log
fill 368 131 597 368 133 597 minecraft:green_terracotta
setblock 369 131 560 minecraft:oak_log
fill 369 131 561 369 133 561 minecraft:green_terracotta
setblock 369 131 570 minecraft:oak_log
setblock 369 131 571 minecraft:green_terracotta
setblock 369 131 575 minecraft:oak_log
fill 369 131 576 369 133 576 minecraft:green_terracotta
setblock 369 131 580 minecraft:oak_log
setblock 369 131 590 minecraft:oak_log
fill 369 131 591 369 133 591 minecraft:green_terracotta
setblock 369 131 595 minecraft:oak_log
fill 369 131 596 369 133 596 minecraft:green_terracotta
setblock 370 131 559 minecraft:oak_log
fill 370 131 560 370 133 560 minecraft:green_terracotta
setblock 370 131 564 minecraft:oak_log
fill 370 131 565 370 133 565 minecraft:green_terracotta
setblock 370 131 569 minecraft:oak_log
fill 370 131 570 370 133 570 minecraft:green_terracotta
setblock 370 131 574 minecraft:oak_log
fill 370 131 575 370 133 575 minecraft:green_terracotta
setblock 370 131 579 minecraft:oak_log
fill 370 131 580 370 131 583 minecraft:green_terracotta
setblock 370 131 584 minecraft:oak_log
fill 370 131 585 370 133 585 minecraft:green_terracotta
setblock 370 131 589 minecraft:oak_log
fill 370 131 590 370 133 590 minecraft:green_terracotta
setblock 370 131 594 minecraft:oak_log
fill 370 131 595 370 133 595 minecraft:green_terracotta
setblock 330 132 558 minecraft:oak_log
fill 330 132 559 330 133 559 minecraft:green_terracotta
setblock 330 132 563 minecraft:oak_log
setblock 330 132 569 minecraft:green_terracotta
setblock 330 132 573 minecraft:oak_log
fill 330 132 574 330 132 577 minecraft:green_terracotta
setblock 330 132 578 minecraft:oak_log
fill 330 132 579 330 133 579 minecraft:green_terracotta
setblock 330 132 583 minecraft:oak_log
fill 330 132 584 330 133 584 minecraft:green_terracotta
setblock 330 132 588 minecraft:oak_log
fill 330 132 589 330 133 589 minecraft:green_terracotta
setblock 330 132 593 minecraft:oak_log
fill 330 132 594 330 133 594 minecraft:green_terracotta
setblock 330 132 598 minecraft:oak_log
fill 331 132 558 331 133 558 minecraft:green_terracotta
setblock 331 132 572 minecraft:oak_log
fill 331 132 573 331 132 576 minecraft:green_terracotta
setblock 331 132 577 minecraft:oak_log
fill 331 132 578 331 133 578 minecraft:green_terracotta
setblock 331 132 581 minecraft:green_terracotta
setblock 331 132 582 minecraft:oak_log
fill 331 132 583 331 133 583 minecraft:green_terracotta
setblock 331 132 587 minecraft:oak_log
fill 331 132 588 331 133 588 minecraft:green_terracotta
setblock 331 132 592 minecraft:oak_log
fill 331 132 593 331 133 593 minecraft:green_terracotta
setblock 331 132 597 minecraft:oak_log
fill 331 132 598 331 133 598 minecraft:green_terracotta
setblock 332 132 576 minecraft:oak_log
fill 332 132 577 332 133 577 minecraft:green_terracotta
setblock 332 132 581 minecraft:oak_log
fill 332 132 582 332 133 582 minecraft:green_terracotta
setblock 332 132 591 minecraft:oak_log
setblock 332 132 592 minecraft:green_terracotta
setblock 332 132 596 minecraft:oak_log
fill 332 132 597 332 133 597 minecraft:green_terracotta
fill 333 132 596 333 133 596 minecraft:green_terracotta
setblock 335 132 558 minecraft:oak_log
setblock 335 132 598 minecraft:oak_log
setblock 336 132 558 minecraft:green_terracotta
setblock 336 132 597 minecraft:oak_log
fill 336 132 598 336 133 598 minecraft:green_terracotta
setblock 340 132 598 minecraft:oak_log
fill 342 132 598 344 132 598 minecraft:green_terracotta
setblock 344 132 558 minecraft:green_terracotta
setblock 344 132 581 minecraft:oak_leaves[persistent=true]
setblock 345 132 558 minecraft:oak_log
fill 345 132 582 346 132 582 minecraft:oak_leaves[persistent=true]
setblock 345 132 598 minecraft:oak_log
fill 346 132 558 346 133 558 minecraft:green_terracotta
fill 346 132 598 349 132 598 minecraft:green_terracotta
setblock 347 132 581 minecraft:oak_leaves[persistent=true]
fill 347 132 597 347 133 597 minecraft:green_terracotta
setblock 349 132 558 minecraft:green_terracotta
setblock 349 132 559 minecraft:oak_log
setblock 350 132 558 minecraft:oak_log
fill 350 132 559 350 133 560 minecraft:green_terracotta
setblock 350 132 598 minecraft:oak_log
fill 351 132 558 351 133 558 minecraft:green_terracotta
setblock 351 132 597 minecraft:oak_log
fill 351 132 598 351 133 598 minecraft:green_terracotta
fill 352 132 597 352 133 597 minecraft:green_terracotta
setblock 353 132 560 minecraft:oak_log
setblock 354 132 559 minecraft:oak_log
setblock 355 132 558 minecraft:oak_log
fill 355 132 559 355 133 559 minecraft:green_terracotta
setblock 355 132 598 minecraft:oak_log
fill 356 132 558 359 132 558 minecraft:green_terracotta
fill 356 132 598 359 132 598 minecraft:green_terracotta
setblock 358 132 559 minecraft:green_terracotta
setblock 359 132 559 minecraft:oak_log
setblock 360 132 558 minecraft:oak_log
fill 360 132 559 360 133 559 minecraft:green_terracotta
setblock 360 132 598 minecraft:oak_log
fill 361 132 558 361 133 558 minecraft:green_terracotta
fill 361 132 598 361 133 598 minecraft:green_terracotta
setblock 362 132 597 minecraft:green_terracotta
setblock 363 132 585 minecraft:oak_leaves[persistent=true]
setblock 364 132 558 minecraft:green_terracotta
setblock 364 132 559 minecraft:oak_log
fill 364 132 584 365 132 584 minecraft:oak_leaves[persistent=true]
setblock 365 132 558 minecraft:oak_log
fill 365 132 559 365 133 559 minecraft:green_terracotta
setblock 365 132 598 minecraft:oak_log
fill 366 132 558 366 133 558 minecraft:green_terracotta
setblock 366 132 588 minecraft:oak_leaves[persistent=true]
setblock 366 132 597 minecraft:oak_log
fill 366 132 598 366 133 598 minecraft:green_terracotta
setblock 367 132 560 minecraft:green_terracotta
setblock 367 132 586 minecraft:oak_leaves[persistent=true]
setblock 367 132 596 minecraft:oak_log
fill 367 132 597 367 133 597 minecraft:green_terracotta
setblock 368 132 560 minecraft:oak_log
setblock 368 132 595 minecraft:oak_log
fill 368 132 596 368 133 596 minecraft:green_terracotta
setblock 369 132 559 minecraft:oak_log
fill 369 132 560 369 133 560 minecraft:green_terracotta
setblock 369 132 574 minecraft:oak_log
fill 369 132 575 369 133 575 minecraft:green_terracotta
setblock 369 132 579 minecraft:oak_log
fill 369 132 580 370 133 581 minecraft:green_terracotta
setblock 369 132 590 minecraft:green_terracotta
setblock 369 132 594 minecraft:oak_log
fill 369 132 595 369 133 595 minecraft:green_terracotta
setblock 370 132 558 minecraft:oak_log
fill 370 132 559 370 133 559 minecraft:green_terracotta
setblock 370 132 563 minecraft:oak_log
fill 370 132 564 370 133 564 minecraft:green_terracotta
setblock 370 132 568 minecraft:oak_log
setblock 370 132 569 minecraft:green_terracotta
setblock 370 132 573 minecraft:oak_log
fill 370 132 574 370 133 574 minecraft:green_terracotta
setblock 370 132 578 minecraft:oak_log
fill 370 132 579 370 133 579 minecraft:green_terracotta
setblock 370 132 582 minecraft:green_terracotta
setblock 370 132 583 minecraft:oak_log
fill 370 132 584 370 133 584 minecraft:green_terracotta
setblock 370 132 588 minecraft:oak_log
fill 370 132 589 370 133 589 minecraft:green_terracotta
setblock 370 132 593 minecraft:oak_log
fill 370 132 594 370 133 594 minecraft:green_terracotta
setblock 370 132 598 minecraft:oak_log
setblock 330 133 558 minecraft:green_terracotta
setblock 330 133 562 minecraft:oak_log
setblock 330 133 572 minecraft:oak_log
fill 330 133 573 330 133 576 minecraft:green_terracotta
setblock 330 133 577 minecraft:oak_log
setblock 330 133 578 minecraft:green_terracotta
setblock 330 133 582 minecraft:oak_log
setblock 330 133 583 minecraft:green_terracotta
setblock 330 133 587 minecraft:oak_log
setblock 330 133 588 minecraft:green_terracotta
setblock 330 133 592 minecraft:oak_log
setblock 330 133 593 minecraft:green_terracotta
setblock 330 133 597 minecraft:oak_log
setblock 330 133 598 minecraft:green_terracotta
fill 331 133 573 331 133 575 minecraft:green_terracotta
setblock 331 133 576 minecraft:oak_log
setblock 331 133 577 minecraft:green_terracotta
setblock 331 133 581 minecraft:oak_log
setblock 331 133 582 minecraft:green_terracotta
setblock 331 133 586 minecraft:oak_log
setblock 331 133 587 minecraft:green_terracotta
setblock 331 133 591 minecraft:oak_log
setblock 331 133 592 minecraft:green_terracotta
setblock 331 133 596 minecraft:oak_log
setblock 331 133 597 minecraft:green_terracotta
setblock 332 133 576 minecraft:green_terracotta
setblock 332 133 580 minecraft:oak_log
setblock 332 133 581 minecraft:green_terracotta
setblock 332 133 595 minecraft:oak_log
setblock 332 133 596 minecraft:green_terracotta
setblock 334 133 558 minecraft:oak_log
setblock 334 133 598 minecraft:oak_log
setblock 335 133 558 minecraft:green_terracotta
setblock 335 133 597 minecraft:oak_log
setblock 335 133 598 minecraft:green_terracotta
setblock 339 133 558 minecraft:oak_leaves[persistent=true]
setblock 343 133 598 minecraft:green_terracotta
setblock 344 133 558 minecraft:oak_log
setblock 344 133 598 minecraft:oak_log
setblock 345 133 558 minecraft:green_terracotta
fill 345 133 598 348 133 598 minecraft:green_terracotta
setblock 346 133 559 minecraft:green_terracotta
setblock 348 133 558 minecraft:green_terracotta
setblock 348 133 559 minecraft:oak_log
setblock 349 133 558 minecraft:oak_log
setblock 349 133 559 minecraft:green_terracotta
setblock 349 133 598 minecraft:oak_log
setblock 350 133 558 minecraft:green_terracotta
setblock 350 133 597 minecraft:oak_log
setblock 350 133 598 minecraft:green_terracotta
setblock 351 133 597 minecraft:green_terracotta
setblock 352 133 559 minecraft:green_terracotta
setblock 352 133 560 minecraft:oak_log
setblock 353 133 559 minecraft:oak_log
setblock 353 133 560 minecraft:green_terracotta
setblock 354 133 558 minecraft:oak_log
setblock 354 133 559 minecraft:green_terracotta
setblock 354 133 598 minecraft:oak_log
fill 355 133 558 358 133 558 minecraft:green_terracotta
fill 355 133 598 358 133 598 minecraft:green_terracotta
setblock 358 133 559 minecraft:oak_log
setblock 359 133 558 minecraft:oak_log
setblock 359 133 559 minecraft:green_terracotta
setblock 359 133 598 minecraft:oak_log
setblock 360 133 558 minecraft:green_terracotta
setblock 360 133 598 minecraft:green_terracotta
setblock 362 133 559 minecraft:green_terracotta
setblock 363 133 559 minecraft:oak_log
setblock 364 133 558 minecraft:oak_log
setblock 364 133 559 minecraft:green_terracotta
setblock 364 133 598 minecraft:oak_log
setblock 365 133 558 minecraft:green_terracotta
setblock 365 133 597 minecraft:oak_log
setblock 365 133 598 minecraft:green_terracotta
setblock 366 133 596 minecraft:oak_log
setblock 366 133 597 minecraft:green_terracotta
setblock 367 133 560 minecraft:oak_log
setblock 367 133 596 minecraft:green_terracotta
setblock 368 133 559 minecraft:oak_log
setblock 368 133 560 minecraft:green_terracotta
setblock 368 133 594 minecraft:oak_log
setblock 368 133 595 minecraft:green_terracotta
setblock 369 133 558 minecraft:oak_log
setblock 369 133 559 minecraft:green_terracotta
setblock 369 133 574 minecraft:green_terracotta
setblock 369 133 578 minecraft:oak_log
setblock 369 133 579 minecraft:green_terracotta
setblock 369 133 582 minecraft:green_terracotta
setblock 369 133 593 minecraft:oak_log
setblock 369 133 594 minecraft:green_terracotta
setblock 369 133 598 minecraft:oak_log
setblock 370 133 558 minecraft:green_terracotta
setblock 370 133 562 minecraft:oak_log
setblock 370 133 563 minecraft:green_terracotta
setblock 370 133 572 minecraft:oak_log
setblock 370 133 573 minecraft:green_terracotta
setblock 370 133 577 minecraft:oak_log
setblock 370 133 578 minecraft:green_terracotta
setblock 370 133 582 minecraft:oak_log
setblock 370 133 583 minecraft:green_terracotta
setblock 370 133 587 minecraft:oak_log
setblock 370 133 588 minecraft:green_terracotta
setblock 370 133 592 minecraft:oak_log
setblock 370 133 593 minecraft:green_terracotta
setblock 370 133 597 minecraft:oak_log
setblock 370 133 598 minecraft:green_terracotta
setblock 332 136 560 minecraft:light[level=14]
setblock 332 136 568 minecraft:light[level=14]
setblock 332 136 576 minecraft:light[level=14]
setblock 332 136 584 minecraft:light[level=14]
setblock 332 136 592 minecraft:light[level=14]
setblock 340 136 560 minecraft:light[level=14]
setblock 340 136 568 minecraft:light[level=14]
setblock 340 136 576 minecraft:light[level=14]
setblock 340 136 584 minecraft:light[level=14]
setblock 340 136 592 minecraft:light[level=14]
setblock 348 136 560 minecraft:light[level=14]
setblock 348 136 568 minecraft:light[level=14]
setblock 348 136 576 minecraft:light[level=14]
setblock 348 136 584 minecraft:light[level=14]
setblock 348 136 592 minecraft:light[level=14]
setblock 356 136 560 minecraft:light[level=14]
setblock 356 136 568 minecraft:light[level=14]
setblock 356 136 576 minecraft:light[level=14]
setblock 356 136 584 minecraft:light[level=14]
setblock 356 136 592 minecraft:light[level=14]
setblock 364 136 560 minecraft:light[level=14]
setblock 364 136 568 minecraft:light[level=14]
setblock 364 136 576 minecraft:light[level=14]
setblock 364 136 584 minecraft:light[level=14]
setblock 364 136 592 minecraft:light[level=14]
fill 345 138 578 347 138 580 minecraft:redstone_block
fill 350 138 573 352 138 575 minecraft:redstone_block
fill 354 138 581 356 138 583 minecraft:redstone_block
fill 335 139 579 340 140 579 minecraft:dirt
fill 336 139 574 336 140 575 minecraft:dark_oak_log
fill 336 139 576 341 140 578 minecraft:dirt
fill 336 139 580 337 140 584 minecraft:dirt
fill 337 139 572 337 140 574 minecraft:dark_oak_log
fill 337 139 575 349 139 575 minecraft:dirt
fill 337 139 585 337 140 586 minecraft:dirt
fill 338 139 570 338 140 573 minecraft:dark_oak_log
fill 338 139 574 349 139 574 minecraft:dirt
fill 338 139 580 338 140 583 minecraft:dirt
fill 338 139 584 341 140 588 minecraft:dark_oak_log
fill 339 139 569 340 140 572 minecraft:dark_oak_log
fill 339 139 573 349 139 573 minecraft:dirt
fill 339 139 580 339 140 580 minecraft:dirt
fill 339 139 581 341 140 583 minecraft:dark_oak_log
fill 339 139 589 341 140 589 minecraft:dark_oak_log
fill 340 139 568 342 140 568 minecraft:dirt
fill 340 139 580 343 140 580 minecraft:dark_oak_log
fill 340 139 590 341 140 590 minecraft:dark_oak_log
fill 341 139 567 354 140 567 minecraft:dirt
fill 341 139 569 348 140 571 minecraft:dark_oak_log
fill 341 139 572 347 140 572 minecraft:dirt
fill 341 139 579 344 139 579 minecraft:dark_oak_log
fill 341 139 591 342 140 591 minecraft:dark_oak_log
fill 342 139 566 353 140 566 minecraft:dirt
fill 342 139 576 342 140 577 minecraft:dirt
fill 342 139 578 344 139 578 minecraft:dark_oak_log
fill 342 139 581 342 140 582 minecraft:dark_oak_log
fill 342 139 583 346 140 590 minecraft:dirt
fill 342 139 592 342 140 592 minecraft:dark_oak_log
fill 343 139 568 344 140 568 minecraft:dark_oak_log
fill 343 139 576 345 140 576 minecraft:dirt
fill 343 139 577 348 139 577 minecraft:dark_oak_log
fill 343 139 581 346 139 582 minecraft:dirt
fill 343 139 591 349 140 592 minecraft:dirt
fill 344 139 565 352 140 565 minecraft:dirt
setblock 344 139 580 minecraft:dirt
fill 344 139 593 351 140 593 minecraft:dirt
fill 345 139 568 355 140 568 minecraft:dirt
fill 346 139 564 350 140 564 minecraft:dirt
fill 346 139 576 346 140 576 minecraft:dark_oak_log
fill 346 139 594 353 140 594 minecraft:dirt
fill 347 139 576 349 139 576 minecraft:dirt
setblock 347 139 581 minecraft:dirt
fill 347 139 582 348 140 587 minecraft:dark_oak_log
fill 347 139 588 347 140 590 minecraft:dirt
fill 348 139 572 351 139 572 minecraft:dark_oak_log
fill 348 139 578 349 140 580 minecraft:ochre_froglight
setblock 348 139 581 minecraft:dark_oak_log
fill 348 139 588 350 140 589 minecraft:dark_oak_log
fill 348 139 590 348 140 590 minecraft:dirt
fill 349 139 569 355 140 569 minecraft:dirt
fill 349 139 570 349 140 571 minecraft:dark_oak_log
fill 349 139 577 353 140 577 minecraft:ochre_froglight
fill 349 139 581 353 140 581 minecraft:ochre_froglight
fill 349 139 582 349 140 584 minecraft:dirt
fill 349 139 585 349 140 587 minecraft:dark_oak_log
fill 349 139 590 353 140 590 minecraft:dark_oak_log
fill 350 139 570 356 140 570 minecraft:dirt
fill 350 139 571 350 140 571 minecraft:dark_oak_log
fill 350 139 576 352 140 576 minecraft:ochre_froglight
fill 350 139 582 352 140 582 minecraft:ochre_froglight
fill 350 139 583 351 140 587 minecraft:dirt
fill 350 139 591 356 140 591 minecraft:dark_oak_log
fill 350 139 592 350 140 592 minecraft:dirt
fill 351 139 563 351 140 564 minecraft:dark_oak_log
fill 351 139 571 356 140 571 minecraft:dirt
fill 351 139 588 364 140 588 minecraft:dirt
fill 351 139 589 351 140 589 minecraft:dark_oak_log
fill 351 139 592 360 140 592 minecraft:dark_oak_log
fill 351 139 595 351 140 595 minecraft:dirt
fill 352 139 564 356 140 564 minecraft:dark_oak_log
fill 352 139 572 356 139 572 minecraft:dirt
fill 352 139 583 353 139 583 minecraft:dark_oak_log
fill 352 139 584 352 140 587 minecraft:dirt
fill 352 139 589 363 140 589 minecraft:dirt
fill 352 139 593 358 140 593 minecraft:dark_oak_log
fill 353 139 565 357 140 565 minecraft:dark_oak_log
fill 353 139 573 355 139 576 minecraft:dirt
fill 353 139 578 354 140 580 minecraft:ochre_froglight
setblock 353 139 582 minecraft:dark_oak_log
fill 353 139 584 362 139 584 minecraft:dark_oak_log
fill 353 139 585 354 140 587 minecraft:dirt
fill 354 139 566 358 140 566 minecraft:dark_oak_log
fill 354 139 577 355 140 577 minecraft:dirt
fill 354 139 590 362 140 590 minecraft:dirt
fill 354 139 594 356 140 594 minecraft:dark_oak_log
fill 355 139 567 358 140 567 minecraft:dark_oak_log
fill 355 139 578 356 140 579 minecraft:dark_oak_log
fill 355 139 580 362 139 580 minecraft:dirt
fill 355 139 585 360 140 585 minecraft:dark_oak_log
fill 355 139 586 364 140 587 minecraft:dirt
fill 356 139 568 359 140 569 minecraft:dark_oak_log
fill 356 139 573 356 140 575 minecraft:dirt
fill 356 139 576 358 140 577 minecraft:dark_oak_log
fill 357 139 570 359 140 575 minecraft:dark_oak_log
fill 357 139 578 357 140 578 minecraft:dark_oak_log
fill 357 139 579 363 140 579 minecraft:dirt
fill 357 139 581 359 139 582 minecraft:dirt
fill 357 139 583 364 139 583 minecraft:dark_oak_log
fill 357 139 591 360 140 591 minecraft:dirt
fill 358 139 565 358 140 565 minecraft:dirt
fill 358 139 578 363 140 578 minecraft:dirt
fill 359 139 566 360 140 567 minecraft:dirt
fill 359 139 576 364 140 577 minecraft:dirt
fill 360 139 568 362 140 575 minecraft:dirt
fill 360 139 581 361 140 581 minecraft:dirt
fill 360 139 582 365 140 582 minecraft:dark_oak_log
fill 361 139 567 361 140 567 minecraft:dirt
fill 361 139 585 365 140 585 minecraft:dirt
fill 361 139 591 361 140 591 minecraft:dark_oak_log
fill 362 139 581 366 140 581 minecraft:dark_oak_log
fill 363 139 569 363 140 575 minecraft:dirt
fill 363 139 580 366 140 580 minecraft:dark_oak_log
fill 363 139 584 366 140 584 minecraft:dirt
fill 364 139 570 364 140 575 minecraft:dirt
fill 364 139 578 366 140 579 minecraft:dark_oak_log
fill 365 139 572 365 140 575 minecraft:dirt
fill 365 139 576 366 140 577 minecraft:dark_oak_log
fill 365 139 583 366 140 583 minecraft:dirt
fill 365 139 586 365 140 586 minecraft:dirt
fill 366 139 574 366 140 575 minecraft:dark_oak_log
fill 366 139 582 366 140 582 minecraft:dirt
fill 367 139 579 367 140 579 minecraft:dark_oak_log
fill 330 140 558 334 140 598 minecraft:dirt
fill 335 140 558 335 140 578 minecraft:dirt
fill 335 140 580 335 140 598 minecraft:dirt
fill 336 140 558 336 140 573 minecraft:dirt
fill 336 140 585 336 140 598 minecraft:dirt
fill 337 140 558 337 140 571 minecraft:dirt
fill 337 140 575 348 140 575 minecraft:dirt
fill 337 140 587 337 140 598 minecraft:dirt
fill 338 140 558 338 140 569 minecraft:dirt
fill 338 140 574 348 140 574 minecraft:dirt
fill 338 140 589 338 140 598 minecraft:dirt
fill 339 140 558 339 140 568 minecraft:dirt
fill 339 140 573 348 140 573 minecraft:dirt
fill 339 140 590 339 140 598 minecraft:dirt
fill 340 140 558 340 140 567 minecraft:dirt
fill 340 140 591 340 140 598 minecraft:dirt
fill 341 140 558 341 140 566 minecraft:dirt
fill 341 140 579 343 140 579 minecraft:dark_oak_log
fill 341 140 592 341 140 598 minecraft:dirt
fill 342 140 558 343 140 565 minecraft:dirt
fill 342 140 578 343 140 578 minecraft:dark_oak_log
fill 342 140 593 343 140 598 minecraft:dirt
setblock 343 140 577 minecraft:dark_oak_log
fill 343 140 581 343 140 582 minecraft:dirt
fill 344 140 558 345 140 564 minecraft:dirt
fill 344 140 577 344 140 581 minecraft:ochre_froglight
fill 344 140 582 346 140 582 minecraft:dirt
fill 344 140 594 345 140 598 minecraft:dirt
fill 345 140 577 348 140 577 minecraft:ochre_froglight
fill 345 140 578 347 140 580 minecraft:dirt
fill 345 140 581 348 140 581 minecraft:ochre_froglight
fill 346 140 558 350 140 563 minecraft:dirt
fill 346 140 595 350 140 598 minecraft:dirt
fill 347 140 576 348 140 576 minecraft:dirt
setblock 348 140 572 minecraft:dark_oak_log
fill 349 140 572 349 140 576 minecraft:ochre_froglight
fill 350 140 572 353 140 572 minecraft:ochre_froglight
fill 350 140 573 352 140 575 minecraft:dirt
fill 351 140 558 370 140 562 minecraft:dirt
fill 351 140 596 370 140 598 minecraft:dirt
fill 352 140 563 370 140 563 minecraft:dirt
setblock 352 140 583 minecraft:dark_oak_log
fill 352 140 595 370 140 595 minecraft:dirt
fill 353 140 573 353 140 576 minecraft:ochre_froglight
fill 353 140 582 353 140 584 minecraft:ochre_froglight
fill 354 140 572 355 140 576 minecraft:dirt
fill 354 140 581 356 140 583 minecraft:dirt
fill 354 140 584 357 140 584 minecraft:ochre_froglight
fill 355 140 580 357 140 580 minecraft:ochre_froglight
setblock 356 140 572 minecraft:dirt
fill 357 140 564 370 140 564 minecraft:dirt
fill 357 140 581 357 140 583 minecraft:ochre_froglight
fill 357 140 594 370 140 594 minecraft:dirt
fill 358 140 580 359 140 582 minecraft:dirt
fill 358 140 583 362 140 584 minecraft:dark_oak_log
fill 359 140 565 370 140 565 minecraft:dirt
fill 359 140 593 370 140 593 minecraft:dirt
fill 360 140 580 362 140 580 minecraft:dirt
fill 361 140 566 370 140 566 minecraft:dirt
fill 361 140 592 370 140 592 minecraft:dirt
fill 362 140 567 370 140 567 minecraft:dirt
fill 362 140 591 370 140 591 minecraft:dirt
fill 363 140 568 370 140 568 minecraft:dirt
fill 363 140 583 364 140 583 minecraft:dark_oak_log
fill 363 140 590 370 140 590 minecraft:dirt
fill 364 140 569 370 140 569 minecraft:dirt
fill 364 140 589 370 140 589 minecraft:dirt
fill 365 140 570 370 140 571 minecraft:dirt
fill 365 140 587 370 140 588 minecraft:dirt
fill 366 140 572 370 140 573 minecraft:dirt
fill 366 140 585 370 140 586 minecraft:dirt
fill 367 140 574 370 140 578 minecraft:dirt
fill 367 140 580 370 140 584 minecraft:dirt
fill 368 140 579 370 140 579 minecraft:dirt
setblock 330 144 560 minecraft:green_terracotta
setblock 330 144 561 minecraft:oak_log
fill 330 144 562 330 144 565 minecraft:green_terracotta
setblock 330 144 566 minecraft:oak_log
fill 330 144 567 330 144 570 minecraft:green_terracotta
setblock 330 144 571 minecraft:oak_log
fill 330 144 574 330 144 575 minecraft:green_terracotta
setblock 330 144 576 minecraft:oak_log
fill 330 144 577 330 144 580 minecraft:green_terracotta
setblock 330 144 581 minecraft:oak_log
fill 330 144 582 330 144 585 minecraft:green_terracotta
setblock 330 144 586 minecraft:oak_log
fill 330 144 587 330 144 590 minecraft:green_terracotta
setblock 330 144 591 minecraft:oak_log
fill 330 144 592 330 144 593 minecraft:green_terracotta
fill 331 144 576 331 145 576 minecraft:oak_leaves[persistent=true]
setblock 331 144 579 minecraft:green_terracotta
setblock 331 144 580 minecraft:oak_log
fill 331 144 581 331 144 584 minecraft:green_terracotta
setblock 331 144 585 minecraft:oak_log
fill 331 144 586 331 144 589 minecraft:green_terracotta
setblock 331 144 590 minecraft:oak_log
setblock 332 144 560 minecraft:light[level=14]
setblock 332 144 568 minecraft:light[level=14]
setblock 332 144 576 minecraft:light[level=14]
setblock 332 144 583 minecraft:green_terracotta
setblock 332 144 584 minecraft:oak_log
fill 332 144 585 332 144 586 minecraft:green_terracotta
setblock 332 144 592 minecraft:light[level=14]
setblock 336 144 558 minecraft:oak_leaves[persistent=true]
setblock 338 144 558 minecraft:oak_log
fill 339 144 558 341 144 559 minecraft:green_terracotta
setblock 339 144 598 minecraft:oak_leaves[persistent=true]
setblock 340 144 560 minecraft:green_terracotta
setblock 340 144 568 minecraft:light[level=14]
setblock 340 144 576 minecraft:light[level=14]
setblock 340 144 584 minecraft:light[level=14]
setblock 340 144 592 minecraft:light[level=14]
setblock 341 144 560 minecraft:oak_log
setblock 342 144 558 minecraft:green_terracotta
setblock 342 144 559 minecraft:oak_log
fill 342 144 560 344 144 561 minecraft:green_terracotta
setblock 342 144 598 minecraft:green_terracotta
setblock 343 144 558 minecraft:oak_log
fill 343 144 559 346 144 559 minecraft:green_terracotta
setblock 343 144 598 minecraft:oak_log
fill 344 144 558 347 144 558 minecraft:green_terracotta
fill 344 144 598 347 144 598 minecraft:green_terracotta
setblock 345 144 560 minecraft:green_terracotta
setblock 345 144 561 minecraft:oak_log
setblock 346 144 560 minecraft:oak_log
fill 346 144 561 348 144 561 minecraft:green_terracotta
setblock 347 144 559 minecraft:oak_log
fill 347 144 560 350 144 560 minecraft:green_terracotta
setblock 348 144 558 minecraft:oak_log
fill 348 144 559 351 144 559 minecraft:green_terracotta
setblock 348 144 568 minecraft:light[level=14]
setblock 348 144 576 minecraft:light[level=14]
setblock 348 144 584 minecraft:light[level=14]
setblock 348 144 592 minecraft:light[level=14]
setblock 348 144 598 minecraft:oak_log
fill 349 144 558 352 144 558 minecraft:green_terracotta
setblock 351 144 560 minecraft:oak_log
setblock 352 144 559 minecraft:oak_log
setblock 353 144 558 minecraft:oak_log
fill 353 144 559 356 144 559 minecraft:green_terracotta
fill 353 144 562 353 148 562 minecraft:iron_block
fill 354 144 558 357 144 558 minecraft:green_terracotta
setblock 356 144 560 minecraft:light[level=14]
setblock 356 144 568 minecraft:light[level=14]
setblock 356 144 576 minecraft:light[level=14]
setblock 356 144 584 minecraft:light[level=14]
setblock 356 144 592 minecraft:light[level=14]
fill 356 144 598 357 144 598 minecraft:green_terracotta
setblock 357 144 559 minecraft:oak_log
fill 357 144 560 360 144 560 minecraft:green_terracotta
setblock 358 144 558 minecraft:oak_log
fill 358 144 559 361 144 559 minecraft:green_terracotta
setblock 358 144 598 minecraft:oak_log
fill 359 144 558 362 144 558 minecraft:green_terracotta
setblock 359 144 597 minecraft:oak_log
fill 359 144 598 362 144 598 minecraft:green_terracotta
fill 360 144 597 363 144 597 minecraft:green_terracotta
setblock 361 144 560 minecraft:oak_log
fill 361 144 561 364 144 561 minecraft:green_terracotta
setblock 362 144 559 minecraft:oak_log
fill 362 144 560 365 144 560 minecraft:green_terracotta
setblock 363 144 558 minecraft:oak_log
fill 363 144 559 366 144 559 minecraft:green_terracotta
fill 363 144 596 364 144 596 minecraft:green_terracotta
setblock 363 144 598 minecraft:oak_log
fill 364 144 558 367 144 558 minecraft:green_terracotta
setblock 364 144 568 minecraft:light[level=14]
setblock 364 144 576 minecraft:light[level=14]
setblock 364 144 584 minecraft:light[level=14]
setblock 364 144 592 minecraft:light[level=14]
setblock 364 144 597 minecraft:oak_log
fill 364 144 598 367 144 598 minecraft:green_terracotta
fill 365 144 594 365 147 594 minecraft:iron_block
setblock 365 144 596 minecraft:oak_log
fill 365 144 597 368 144 597 minecraft:green_terracotta
setblock 366 144 560 minecraft:oak_log
setblock 366 144 596 minecraft:green_terracotta
setblock 367 144 559 minecraft:oak_log
setblock 367 144 560 minecraft:green_terracotta
setblock 367 144 584 minecraft:oak_log
fill 367 144 585 367 144 588 minecraft:green_terracotta
setblock 367 144 589 minecraft:oak_log
setblock 368 144 558 minecraft:oak_log
setblock 368 144 559 minecraft:green_terracotta
setblock 368 144 582 minecraft:green_terracotta
setblock 368 144 583 minecraft:oak_log
fill 368 144 584 368 144 587 minecraft:green_terracotta
setblock 368 144 588 minecraft:oak_log
fill 368 144 589 368 144 592 minecraft:green_terracotta
setblock 368 144 598 minecraft:oak_log
fill 369 144 558 370 144 558 minecraft:green_terracotta
fill 369 144 560 369 144 561 minecraft:green_terracotta
setblock 369 144 562 minecraft:oak_log
fill 369 144 563 370 144 565 minecraft:green_terracotta
fill 369 144 580 369 144 581 minecraft:green_terracotta
setblock 369 144 582 minecraft:oak_log
fill 369 144 583 369 144 586 minecraft:green_terracotta
setblock 369 144 587 minecraft:oak_log
fill 369 144 588 369 144 591 minecraft:green_terracotta
setblock 369 144 592 minecraft:oak_log
fill 369 144 593 370 144 595 minecraft:green_terracotta
fill 369 144 598 370 145 598 minecraft:green_terracotta
fill 370 144 559 370 144 560 minecraft:green_terracotta
setblock 370 144 561 minecraft:oak_log
fill 370 144 562 370 145 562 minecraft:green_terracotta
setblock 370 144 566 minecraft:oak_log
fill 370 144 567 370 144 568 minecraft:green_terracotta
fill 370 144 578 370 144 580 minecraft:green_terracotta
setblock 370 144 581 minecraft:oak_log
fill 370 144 582 370 144 585 minecraft:green_terracotta
setblock 370 144 586 minecraft:oak_log
fill 370 144 587 370 144 590 minecraft:green_terracotta
setblock 370 144 591 minecraft:oak_log
fill 370 144 592 370 147 592 minecraft:green_terracotta
setblock 370 144 596 minecraft:oak_log
fill 370 144 597 370 145 597 minecraft:green_terracotta
fill 330 145 561 330 145 564 minecraft:green_terracotta
setblock 330 145 565 minecraft:oak_log
fill 330 145 566 330 145 569 minecraft:green_terracotta
setblock 330 145 570 minecraft:oak_log
fill 330 145 571 330 148 571 minecraft:green_terracotta
fill 330 145 576 330 145 579 minecraft:green_terracotta
setblock 330 145 580 minecraft:oak_log
fill 330 145 581 330 145 584 minecraft:green_terracotta
setblock 330 145 585 minecraft:oak_log
fill 330 145 586 330 145 589 minecraft:green_terracotta
setblock 330 145 590 minecraft:oak_log
fill 330 145 591 330 147 592 minecraft:green_terracotta
setblock 330 145 594 minecraft:oak_leaves[persistent=true]
fill 331 145 580 331 145 583 minecraft:green_terracotta
setblock 331 145 584 minecraft:oak_log
fill 331 145 585 331 145 588 minecraft:green_terracotta
setblock 331 145 589 minecraft:oak_log
fill 338 145 558 341 145 558 minecraft:green_terracotta
fill 339 145 559 340 145 559 minecraft:green_terracotta
setblock 340 145 560 minecraft:oak_log
setblock 341 145 559 minecraft:oak_log
fill 341 145 560 344 145 560 minecraft:green_terracotta
setblock 342 145 558 minecraft:oak_log
fill 342 145 559 345 145 559 minecraft:green_terracotta
fill 342 145 561 343 145 561 minecraft:green_terracotta
setblock 342 145 598 minecraft:oak_log
fill 343 145 558 346 145 558 minecraft:green_terracotta
fill 343 145 598 346 145 598 minecraft:green_terracotta
setblock 344 145 561 minecraft:oak_log
setblock 345 145 560 minecraft:oak_log
fill 345 145 561 347 145 561 minecraft:green_terracotta
setblock 346 145 559 minecraft:oak_log
fill 346 145 560 349 145 560 minecraft:green_terracotta
setblock 347 145 558 minecraft:oak_log
fill 347 145 559 350 145 559 minecraft:green_terracotta
fill 348 145 558 351 145 558 minecraft:green_terracotta
setblock 351 145 559 minecraft:oak_log
setblock 352 145 558 minecraft:oak_log
fill 352 145 559 355 145 559 minecraft:green_terracotta
fill 353 145 558 356 145 558 minecraft:green_terracotta
setblock 356 145 559 minecraft:oak_log
setblock 356 145 598 minecraft:green_terracotta
setblock 357 145 558 minecraft:oak_log
fill 357 145 559 360 145 559 minecraft:green_terracotta
setblock 357 145 598 minecraft:oak_log
fill 358 145 558 361 145 558 minecraft:green_terracotta
fill 358 145 560 359 145 560 minecraft:green_terracotta
fill 358 145 598 361 145 598 minecraft:green_terracotta
fill 359 145 597 362 145 597 minecraft:green_terracotta
setblock 360 145 560 minecraft:oak_log
setblock 361 145 559 minecraft:oak_log
fill 361 145 560 364 145 560 minecraft:green_terracotta
setblock 362 145 558 minecraft:oak_log
fill 362 145 559 365 145 559 minecraft:green_terracotta
fill 362 145 596 363 145 596 minecraft:green_terracotta
setblock 362 145 598 minecraft:oak_log
fill 363 145 558 366 145 558 minecraft:green_terracotta
setblock 363 145 597 minecraft:oak_log
fill 363 145 598 366 145 598 minecraft:green_terracotta
setblock 364 145 596 minecraft:oak_log
fill 364 145 597 367 145 597 minecraft:green_terracotta
setblock 365 145 560 minecraft:oak_log
setblock 365 145 596 minecraft:green_terracotta
setblock 366 145 559 minecraft:oak_log
setblock 367 145 558 minecraft:oak_log
setblock 367 145 559 minecraft:green_terracotta
fill 367 145 585 367 145 587 minecraft:green_terracotta
setblock 367 145 588 minecraft:oak_log
fill 367 145 589 370 145 589 minecraft:green_terracotta
setblock 367 145 598 minecraft:oak_log
fill 368 145 558 369 145 558 minecraft:green_terracotta
fill 368 145 583 368 145 586 minecraft:green_terracotta
setblock 368 145 587 minecraft:oak_log
fill 368 145 588 370 146 588 minecraft:green_terracotta
fill 368 145 590 368 145 591 minecraft:green_terracotta
setblock 368 145 592 minecraft:oak_log
fill 368 145 598 368 146 598 minecraft:green_terracotta
setblock 369 145 581 minecraft:oak_log
fill 369 145 582 369 145 585 minecraft:green_terracotta
setblock 369 145 586 minecraft:oak_log
fill 369 145 587 370 147 587 minecraft:green_terracotta
setblock 369 145 590 minecraft:green_terracotta
setblock 369 145 591 minecraft:oak_log
fill 369 145 592 369 145 594 minecraft:green_terracotta
setblock 370 145 560 minecraft:oak_log
setblock 370 145 561 minecraft:green_terracotta
fill 370 145 563 370 145 564 minecraft:green_terracotta
setblock 370 145 565 minecraft:oak_log
fill 370 145 566 370 146 567 minecraft:green_terracotta
setblock 370 145 579 minecraft:green_terracotta
setblock 370 145 580 minecraft:oak_log
fill 370 145 581 370 145 584 minecraft:green_terracotta
setblock 370 145 585 minecraft:oak_log
fill 370 145 586 370 148 586 minecraft:green_terracotta
setblock 370 145 590 minecraft:oak_log
fill 370 145 591 370 148 591 minecraft:green_terracotta
fill 370 145 593 370 145 594 minecraft:green_terracotta
setblock 370 145 595 minecraft:oak_log
setblock 370 145 596 minecraft:green_terracotta
setblock 330 146 563 minecraft:green_terracotta
setblock 330 146 564 minecraft:oak_log
fill 330 146 565 330 146 568 minecraft:green_terracotta
setblock 330 146 569 minecraft:oak_log
fill 330 146 570 330 149 570 minecraft:green_terracotta
setblock 330 146 575 minecraft:oak_leaves[persistent=true]
setblock 330 146 578 minecraft:green_terracotta
setblock 330 146 579 minecraft:oak_log
fill 330 146 580 330 146 583 minecraft:green_terracotta
setblock 330 146 584 minecraft:oak_log
fill 330 146 585 330 146 588 minecraft:green_terracotta
setblock 330 146 589 minecraft:oak_log
fill 330 146 590 330 149 590 minecraft:green_terracotta
setblock 331 146 582 minecraft:green_terracotta
setblock 331 146 583 minecraft:oak_log
fill 331 146 584 331 146 587 minecraft:green_terracotta
setblock 331 146 588 minecraft:oak_log
setblock 331 146 589 minecraft:green_terracotta
setblock 332 146 598 minecraft:oak_leaves[persistent=true]
fill 338 146 558 340 146 558 minecraft:green_terracotta
setblock 339 146 559 minecraft:green_terracotta
setblock 340 146 559 minecraft:oak_log
setblock 341 146 558 minecraft:oak_log
fill 341 146 559 343 146 560 minecraft:green_terracotta
fill 342 146 558 345 146 558 minecraft:green_terracotta
setblock 343 146 561 minecraft:oak_log
fill 343 146 598 344 146 598 minecraft:green_terracotta
setblock 344 146 559 minecraft:green_terracotta
setblock 344 146 560 minecraft:oak_log
setblock 344 146 561 minecraft:green_terracotta
setblock 345 146 559 minecraft:oak_log
fill 345 146 560 347 146 560 minecraft:green_terracotta
setblock 346 146 558 minecraft:oak_log
fill 346 146 559 349 146 559 minecraft:green_terracotta
fill 347 146 558 350 146 558 minecraft:green_terracotta
setblock 351 146 558 minecraft:oak_log
setblock 351 146 598 minecraft:oak_leaves[persistent=true]
fill 352 146 558 355 146 558 minecraft:green_terracotta
setblock 356 146 558 minecraft:oak_log
fill 356 146 559 359 146 559 minecraft:green_terracotta
setblock 356 146 598 minecraft:oak_log
fill 357 146 558 360 146 558 minecraft:green_terracotta
fill 357 146 598 360 146 598 minecraft:green_terracotta
fill 359 146 597 361 146 597 minecraft:green_terracotta
setblock 360 146 559 minecraft:oak_log
fill 360 146 560 363 146 560 minecraft:green_terracotta
setblock 361 146 558 minecraft:oak_log
fill 361 146 559 364 146 559 minecraft:green_terracotta
setblock 361 146 598 minecraft:oak_log
fill 362 146 558 365 146 558 minecraft:green_terracotta
setblock 362 146 597 minecraft:oak_log
fill 362 146 598 365 146 598 minecraft:green_terracotta
setblock 363 146 596 minecraft:oak_log
fill 363 146 597 366 146 597 minecraft:green_terracotta
setblock 365 146 559 minecraft:oak_log
setblock 366 146 558 minecraft:oak_log
setblock 366 146 559 minecraft:green_terracotta
setblock 366 146 598 minecraft:oak_log
setblock 367 146 558 minecraft:green_terracotta
setblock 367 146 587 minecraft:oak_log
setblock 367 146 588 minecraft:green_terracotta
fill 367 146 598 367 147 598 minecraft:green_terracotta
setblock 368 146 558 minecraft:oak_leaves[persistent=true]
fill 368 146 584 368 146 585 minecraft:green_terracotta
setblock 368 146 586 minecraft:oak_log
fill 368 146 587 368 148 587 minecraft:green_terracotta
fill 368 146 589 368 146 590 minecraft:green_terracotta
setblock 368 146 591 minecraft:oak_log
fill 369 146 582 369 146 584 minecraft:green_terracotta
setblock 369 146 585 minecraft:oak_log
fill 369 146 586 369 149 586 minecraft:green_terracotta
setblock 369 146 589 minecraft:green_terracotta
setblock 369 146 590 minecraft:oak_log
fill 369 146 591 369 147 593 minecraft:green_terracotta
setblock 369 146 598 minecraft:green_terracotta
setblock 370 146 563 minecraft:green_terracotta
setblock 370 146 564 minecraft:oak_log
setblock 370 146 565 minecraft:green_terracotta
setblock 370 146 575 minecraft:oak_leaves[persistent=true]
fill 370 146 580 370 146 583 minecraft:green_terracotta
setblock 370 146 584 minecraft:oak_log
fill 370 146 585 370 149 585 minecraft:green_terracotta
setblock 370 146 589 minecraft:oak_log
fill 370 146 590 370 149 590 minecraft:green_terracotta
setblock 370 146 593 minecraft:green_terracotta
setblock 370 146 594 minecraft:oak_log
setblock 370 146 595 minecraft:green_terracotta
setblock 330 147 562 minecraft:oak_leaves[persistent=true]
fill 330 147 564 330 147 567 minecraft:green_terracotta
setblock 330 147 568 minecraft:oak_log
fill 330 147 569 330 150 569 minecraft:green_terracotta
fill 330 147 580 330 147 582 minecraft:green_terracotta
setblock 330 147 583 minecraft:oak_log
fill 330 147 584 330 147 587 minecraft:green_terracotta
setblock 330 147 588 minecraft:oak_log
fill 330 147 589 330 150 589 minecraft:green_terracotta
fill 331 147 584 331 147 586 minecraft:green_terracotta
setblock 331 147 587 minecraft:oak_log
setblock 331 147 588 minecraft:green_terracotta
setblock 337 147 558 minecraft:oak_leaves[persistent=true]
fill 337 147 588 337 148 588 minecraft:oak_leaves[persistent=true]
setblock 338 147 598 minecraft:oak_leaves[persistent=true]
setblock 339 147 558 minecraft:green_terracotta
setblock 340 147 558 minecraft:oak_log
fill 340 147 559 343 147 559 minecraft:green_terracotta
fill 341 147 558 344 147 558 minecraft:green_terracotta
setblock 342 147 560 minecraft:green_terracotta
setblock 343 147 560 minecraft:oak_log
setblock 344 147 559 minecraft:oak_log
fill 344 147 560 345 147 560 minecraft:green_terracotta
setblock 345 147 558 minecraft:oak_log
fill 345 147 559 347 147 559 minecraft:green_terracotta
fill 346 147 558 349 147 558 minecraft:green_terracotta
fill 347 147 578 349 188 578 minecraft:oak_log
fill 348 147 577 349 188 577 minecraft:oak_log
fill 348 147 579 349 188 579 minecraft:oak_log
fill 349 147 576 350 188 576 minecraft:oak_log
fill 349 147 580 349 188 580 minecraft:oak_log
setblock 350 147 558 minecraft:oak_log
setblock 351 147 558 minecraft:green_terracotta
setblock 354 147 558 minecraft:green_terracotta
setblock 355 147 558 minecraft:oak_log
fill 356 147 558 359 147 558 minecraft:green_terracotta
fill 356 147 598 359 147 598 minecraft:green_terracotta
setblock 358 147 559 minecraft:green_terracotta
setblock 359 147 559 minecraft:oak_log
fill 359 147 597 360 147 597 minecraft:green_terracotta
setblock 360 147 558 minecraft:oak_log
fill 360 147 559 363 147 559 minecraft:green_terracotta
setblock 360 147 598 minecraft:oak_log
fill 361 147 558 364 147 558 minecraft:green_terracotta
setblock 361 147 597 minecraft:oak_log
fill 361 147 598 364 147 598 minecraft:green_terracotta
fill 362 147 597 365 147 597 minecraft:green_terracotta
setblock 364 147 559 minecraft:oak_log
setblock 365 147 558 minecraft:oak_log
setblock 365 147 598 minecraft:oak_log
setblock 366 147 558 minecraft:green_terracotta
fill 366 147 598 366 149 598 minecraft:green_terracotta
setblock 368 147 585 minecraft:oak_log
setblock 368 147 586 minecraft:green_terracotta
fill 368 147 588 368 147 589 minecraft:green_terracotta
setblock 368 147 590 minecraft:oak_log
setblock 368 147 591 minecraft:green_terracotta
setblock 369 147 583 minecraft:green_terracotta
setblock 369 147 584 minecraft:oak_log
fill 369 147 585 369 148 585 minecraft:green_terracotta
setblock 369 147 588 minecraft:green_terracotta
setblock 369 147 589 minecraft:oak_log
fill 369 147 590 369 150 590 minecraft:green_terracotta
setblock 370 147 569 minecraft:oak_leaves[persistent=true]
fill 370 147 581 370 147 582 minecraft:green_terracotta
setblock 370 147 583 minecraft:oak_log
fill 370 147 584 370 150 584 minecraft:green_terracotta
setblock 370 147 588 minecraft:oak_log
fill 370 147 589 370 150 589 minecraft:green_terracotta
setblock 370 147 593 minecraft:oak_log
fill 370 147 594 370 148 594 minecraft:green_terracotta
fill 330 148 565 330 148 566 minecraft:green_terracotta
setblock 330 148 567 minecraft:oak_log
fill 330 148 568 330 151 568 minecraft:green_terracotta
setblock 330 148 582 minecraft:oak_log
fill 330 148 583 330 148 586 minecraft:green_terracotta
setblock 330 148 587 minecraft:oak_log
fill 330 148 588 330 151 588 minecraft:green_terracotta
setblock 330 148 591 minecraft:green_terracotta
setblock 330 148 593 minecraft:oak_leaves[persistent=true]
setblock 331 148 558 minecraft:oak_leaves[persistent=true]
setblock 339 148 558 minecraft:oak_log
fill 340 148 558 343 148 558 minecraft:green_terracotta
fill 341 148 559 342 148 559 minecraft:green_terracotta
setblock 343 148 559 minecraft:oak_log
setblock 344 148 558 minecraft:oak_log
fill 344 148 559 345 148 559 minecraft:green_terracotta
setblock 344 148 598 minecraft:oak_leaves[persistent=true]
fill 345 148 558 348 148 558 minecraft:green_terracotta
fill 347 148 576 347 149 577 minecraft:dark_oak_log
fill 347 148 579 347 149 580 minecraft:dark_oak_log
fill 348 148 576 348 149 576 minecraft:dark_oak_log
fill 348 148 580 348 149 581 minecraft:dark_oak_log
fill 349 148 575 349 149 575 minecraft:dark_oak_log
fill 349 148 581 350 149 581 minecraft:dark_oak_log
fill 350 148 580 350 188 580 minecraft:oak_log
fill 351 148 576 351 149 576 minecraft:dark_oak_log
fill 355 148 558 358 148 558 minecraft:green_terracotta
fill 356 148 598 358 148 598 minecraft:green_terracotta
setblock 359 148 558 minecraft:oak_log
fill 359 148 559 362 148 559 minecraft:green_terracotta
setblock 359 148 597 minecraft:green_terracotta
setblock 359 148 598 minecraft:oak_log
fill 360 148 558 363 148 558 minecraft:green_terracotta
setblock 360 148 597 minecraft:oak_log
fill 360 148 598 363 148 598 minecraft:green_terracotta
fill 361 148 597 364 148 597 minecraft:green_terracotta
setblock 364 148 558 minecraft:oak_log
setblock 364 148 598 minecraft:oak_log
setblock 365 148 597 minecraft:oak_log
fill 365 148 598 365 151 598 minecraft:green_terracotta
setblock 368 148 588 minecraft:green_terracotta
setblock 368 148 589 minecraft:oak_log
setblock 368 148 590 minecraft:green_terracotta
setblock 369 148 587 minecraft:green_terracotta
setblock 369 148 588 minecraft:oak_log
fill 369 148 589 369 151 589 minecraft:green_terracotta
fill 369 148 591 369 148 592 minecraft:green_terracotta
setblock 369 148 598 minecraft:oak_leaves[persistent=true]
setblock 370 148 563 minecraft:oak_leaves[persistent=true]
setblock 370 148 582 minecraft:oak_log
setblock 370 148 583 minecraft:green_terracotta
setblock 370 148 587 minecraft:oak_log
fill 370 148 588 370 151 588 minecraft:green_terracotta
setblock 370 148 592 minecraft:oak_log
fill 370 148 593 370 151 593 minecraft:green_terracotta
setblock 330 149 566 minecraft:oak_log
fill 330 149 567 330 152 567 minecraft:green_terracotta
setblock 330 149 571 minecraft:oak_log
setblock 330 149 574 minecraft:oak_leaves[persistent=true]
fill 330 149 584 330 149 585 minecraft:green_terracotta
setblock 330 149 586 minecraft:oak_log
fill 330 149 587 330 150 587 minecraft:green_terracotta
setblock 330 149 591 minecraft:oak_log
setblock 331 149 598 minecraft:oak_leaves[persistent=true]
fill 339 149 558 342 149 558 minecraft:green_terracotta
setblock 342 149 559 minecraft:oak_log
setblock 343 149 558 minecraft:oak_log
fill 344 149 558 346 149 558 minecraft:green_terracotta
fill 346 149 576 346 149 580 minecraft:dark_oak_log
fill 347 149 575 348 149 575 minecraft:dark_oak_log
setblock 347 149 581 minecraft:dark_oak_log
setblock 349 149 574 minecraft:dark_oak_log
fill 349 149 582 350 149 582 minecraft:dark_oak_log
setblock 350 149 558 minecraft:oak_leaves[persistent=true]
fill 350 149 575 351 149 575 minecraft:dark_oak_log
setblock 350 149 598 minecraft:oak_leaves[persistent=true]
setblock 351 149 581 minecraft:dark_oak_log
fill 356 149 558 357 149 558 minecraft:green_terracotta
fill 356 149 598 357 149 598 minecraft:green_terracotta
setblock 358 149 558 minecraft:oak_log
setblock 358 149 597 minecraft:green_terracotta
setblock 358 149 598 minecraft:oak_log
fill 359 149 558 362 149 558 minecraft:green_terracotta
setblock 359 149 597 minecraft:oak_log
fill 359 149 598 362 149 598 minecraft:green_terracotta
fill 360 149 597 363 149 597 minecraft:green_terracotta
setblock 363 149 558 minecraft:oak_log
setblock 363 149 598 minecraft:oak_log
setblock 364 149 597 minecraft:oak_log
fill 364 149 598 364 152 598 minecraft:green_terracotta
setblock 369 149 558 minecraft:oak_leaves[persistent=true]
setblock 369 149 587 minecraft:oak_log
fill 369 149 588 369 150 588 minecraft:green_terracotta
setblock 369 149 591 minecraft:green_terracotta
setblock 369 149 592 minecraft:oak_log
setblock 370 149 582 minecraft:oak_leaves[persistent=true]
setblock 370 149 586 minecraft:oak_log
fill 370 149 587 370 152 587 minecraft:green_terracotta
setblock 370 149 591 minecraft:oak_log
fill 370 149 592 370 152 592 minecraft:green_terracotta
setblock 330 150 561 minecraft:oak_leaves[persistent=true]
setblock 330 150 570 minecraft:oak_log
fill 330 150 571 330 152 572 minecraft:green_terracotta
setblock 330 150 580 minecraft:oak_leaves[persistent=true]
setblock 330 150 586 minecraft:green_terracotta
setblock 330 150 590 minecraft:oak_log
setblock 337 150 598 minecraft:oak_leaves[persistent=true]
fill 339 150 558 341 150 558 minecraft:green_terracotta
setblock 342 150 558 minecraft:oak_log
fill 343 150 558 345 150 558 minecraft:green_terracotta
fill 355 150 598 356 150 598 minecraft:green_terracotta
setblock 357 150 558 minecraft:oak_log
setblock 357 150 598 minecraft:oak_log
fill 358 150 558 361 150 558 minecraft:green_terracotta
setblock 358 150 597 minecraft:oak_log
fill 358 150 598 361 150 598 minecraft:green_terracotta
fill 359 150 567 359 151 568 minecraft:oak_leaves[persistent=true]
fill 359 150 597 362 150 597 minecraft:green_terracotta
setblock 362 150 558 minecraft:oak_log
setblock 362 150 598 minecraft:oak_log
setblock 363 150 558 minecraft:oak_leaves[persistent=true]
setblock 363 150 597 minecraft:oak_log
fill 363 150 598 363 153 598 minecraft:green_terracotta
setblock 369 150 587 minecraft:green_terracotta
setblock 369 150 591 minecraft:oak_log
setblock 370 150 576 minecraft:oak_leaves[persistent=true]
setblock 370 150 585 minecraft:oak_log
fill 370 150 586 370 153 586 minecraft:green_terracotta
setblock 370 150 590 minecraft:oak_log
fill 370 150 591 370 153 591 minecraft:green_terracotta
setblock 370 150 595 minecraft:oak_leaves[persistent=true]
setblock 330 151 569 minecraft:oak_log
fill 330 151 570 330 154 570 minecraft:green_terracotta
setblock 330 151 573 minecraft:green_terracotta
setblock 330 151 586 minecraft:oak_leaves[persistent=true]
setblock 330 151 589 minecraft:oak_log
setblock 330 151 590 minecraft:green_terracotta
setblock 338 151 558 minecraft:oak_leaves[persistent=true]
fill 339 151 558 340 151 558 minecraft:green_terracotta
setblock 341 151 558 minecraft:oak_log
fill 342 151 558 344 152 558 minecraft:green_terracotta
setblock 343 151 598 minecraft:oak_leaves[persistent=true]
fill 350 151 577 350 188 577 minecraft:oak_log
setblock 355 151 598 minecraft:green_terracotta
setblock 356 151 558 minecraft:oak_log
setblock 356 151 598 minecraft:oak_log
fill 357 151 558 360 151 558 minecraft:green_terracotta
setblock 357 151 597 minecraft:oak_log
fill 357 151 598 360 151 598 minecraft:green_terracotta
fill 358 151 597 361 151 597 minecraft:green_terracotta
fill 359 151 596 361 152 596 minecraft:green_terracotta
setblock 361 151 558 minecraft:oak_log
setblock 361 151 598 minecraft:oak_log
setblock 362 151 597 minecraft:oak_log
fill 362 151 598 362 154 598 minecraft:green_terracotta
fill 363 151 597 363 154 597 minecraft:green_terracotta
setblock 369 151 590 minecraft:oak_log
fill 369 151 591 369 154 591 minecraft:green_terracotta
setblock 370 151 570 minecraft:oak_leaves[persistent=true]
setblock 370 151 585 minecraft:green_terracotta
setblock 370 151 589 minecraft:oak_log
fill 370 151 590 370 154 590 minecraft:green_terracotta
setblock 370 151 594 minecraft:oak_log
setblock 330 152 568 minecraft:oak_log
fill 330 152 569 330 155 569 minecraft:green_terracotta
setblock 330 152 573 minecraft:oak_log
fill 330 152 574 330 154 575 minecraft:green_terracotta
setblock 330 152 589 minecraft:green_terracotta
setblock 330 152 592 minecraft:oak_leaves[persistent=true]
fill 331 152 570 331 152 571 minecraft:green_terracotta
setblock 332 152 558 minecraft:oak_leaves[persistent=true]
setblock 332 152 560 minecraft:light[level=14]
setblock 332 152 568 minecraft:light[level=14]
setblock 332 152 576 minecraft:light[level=14]
setblock 332 152 584 minecraft:light[level=14]
setblock 332 152 592 minecraft:light[level=14]
fill 338 152 558 339 152 558 minecraft:green_terracotta
setblock 340 152 558 minecraft:oak_log
setblock 340 152 560 minecraft:light[level=14]
setblock 340 152 568 minecraft:light[level=14]
setblock 340 152 576 minecraft:light[level=14]
setblock 340 152 584 minecraft:light[level=14]
setblock 340 152 592 minecraft:light[level=14]
setblock 340 152 598 minecraft:oak_log
fill 341 152 558 341 155 558 minecraft:green_terracotta
setblock 348 152 560 minecraft:light[level=14]
setblock 348 152 568 minecraft:light[level=14]
setblock 348 152 576 minecraft:light[level=14]
setblock 348 152 584 minecraft:light[level=14]
setblock 348 152 592 minecraft:light[level=14]
setblock 349 152 598 minecraft:oak_leaves[persistent=true]
setblock 351 152 558 minecraft:oak_leaves[persistent=true]
fill 353 152 598 354 152 598 minecraft:green_terracotta
setblock 355 152 558 minecraft:oak_log
setblock 355 152 597 minecraft:green_terracotta
setblock 355 152 598 minecraft:oak_log
fill 356 152 558 359 152 558 minecraft:green_terracotta
setblock 356 152 560 minecraft:light[level=14]
setblock 356 152 568 minecraft:light[level=14]
setblock 356 152 576 minecraft:light[level=14]
setblock 356 152 584 minecraft:light[level=14]
setblock 356 152 592 minecraft:light[level=14]
setblock 356 152 597 minecraft:oak_log
fill 356 152 598 359 152 598 minecraft:green_terracotta
setblock 357 152 596 minecraft:oak_log
fill 357 152 597 360 152 597 minecraft:green_terracotta
fill 358 152 596 358 155 596 minecraft:green_terracotta
setblock 360 152 558 minecraft:oak_log
setblock 360 152 598 minecraft:oak_log
fill 361 152 558 361 155 558 minecraft:green_terracotta
setblock 361 152 597 minecraft:oak_log
fill 361 152 598 361 155 598 minecraft:green_terracotta
setblock 362 152 596 minecraft:oak_log
fill 362 152 597 362 155 597 minecraft:green_terracotta
fill 363 152 570 366 188 573 minecraft:oak_log
setblock 364 152 560 minecraft:light[level=14]
setblock 364 152 568 minecraft:light[level=14]
setblock 364 152 576 minecraft:light[level=14]
setblock 364 152 584 minecraft:light[level=14]
setblock 364 152 592 minecraft:light[level=14]
setblock 365 152 598 minecraft:oak_log
setblock 368 152 598 minecraft:oak_leaves[persistent=true]
setblock 369 152 589 minecraft:oak_log
fill 369 152 590 369 155 590 minecraft:green_terracotta
setblock 370 152 564 minecraft:oak_leaves[persistent=true]
setblock 370 152 583 minecraft:oak_leaves[persistent=true]
setblock 370 152 588 minecraft:oak_log
fill 370 152 589 370 155 589 minecraft:green_terracotta
setblock 370 152 593 minecraft:oak_log
fill 370 152 594 370 155 594 minecraft:green_terracotta
setblock 330 153 567 minecraft:oak_log
fill 330 153 568 331 155 568 minecraft:green_terracotta
setblock 330 153 571 minecraft:green_terracotta
setblock 330 153 572 minecraft:oak_log
fill 330 153 573 331 155 573 minecraft:green_terracotta
setblock 330 153 576 minecraft:green_terracotta
setblock 330 153 579 minecraft:oak_leaves[persistent=true]
fill 330 153 590 330 153 591 minecraft:green_terracotta
setblock 330 153 598 minecraft:oak_leaves[persistent=true]
fill 331 153 569 331 153 570 minecraft:green_terracotta
setblock 331 153 571 minecraft:oak_log
fill 331 153 572 331 156 572 minecraft:green_terracotta
fill 331 153 574 331 154 574 minecraft:green_terracotta
fill 337 153 558 338 153 558 minecraft:green_terracotta
fill 337 153 598 338 153 598 minecraft:green_terracotta
setblock 339 153 558 minecraft:oak_log
setblock 339 153 598 minecraft:oak_log
fill 340 153 558 340 156 558 minecraft:green_terracotta
fill 340 153 598 343 153 598 minecraft:green_terracotta
fill 342 153 558 343 153 558 minecraft:green_terracotta
setblock 344 153 558 minecraft:oak_log
setblock 345 153 558 minecraft:oak_leaves[persistent=true]
fill 352 153 598 353 153 598 minecraft:green_terracotta
setblock 354 153 558 minecraft:oak_log
setblock 354 153 597 minecraft:green_terracotta
setblock 354 153 598 minecraft:oak_log
fill 355 153 558 358 153 558 minecraft:green_terracotta
setblock 355 153 597 minecraft:oak_log
fill 355 153 598 358 153 598 minecraft:green_terracotta
setblock 356 153 596 minecraft:oak_log
fill 356 153 597 359 153 597 minecraft:green_terracotta
fill 357 153 596 357 156 596 minecraft:green_terracotta
fill 358 153 595 360 154 595 minecraft:green_terracotta
setblock 359 153 558 minecraft:oak_log
fill 359 153 596 360 153 596 minecraft:green_terracotta
setblock 359 153 598 minecraft:oak_log
fill 360 153 558 360 156 558 minecraft:green_terracotta
setblock 360 153 597 minecraft:oak_log
fill 360 153 598 360 156 598 minecraft:green_terracotta
setblock 361 153 596 minecraft:oak_log
fill 361 153 597 361 156 597 minecraft:green_terracotta
fill 362 153 570 362 154 573 minecraft:dark_oak_log
fill 362 153 596 362 156 596 minecraft:green_terracotta
fill 363 153 569 366 154 569 minecraft:dark_oak_log
fill 363 153 574 366 154 574 minecraft:dark_oak_log
setblock 364 153 597 minecraft:green_terracotta
setblock 364 153 598 minecraft:oak_log
fill 365 153 598 365 156 598 minecraft:green_terracotta
fill 367 153 570 367 154 573 minecraft:dark_oak_log
setblock 369 153 592 minecraft:green_terracotta
setblock 370 153 558 minecraft:oak_leaves[persistent=true]
setblock 370 153 571 minecraft:green_terracotta
setblock 370 153 572 minecraft:oak_log
fill 370 153 573 370 156 573 minecraft:green_terracotta
setblock 370 153 577 minecraft:oak_leaves[persistent=true]
setblock 370 153 587 minecraft:oak_log
fill 370 153 588 370 156 588 minecraft:green_terracotta
setblock 370 153 592 minecraft:oak_log
fill 370 153 593 370 156 593 minecraft:green_terracotta
fill 370 153 595 370 154 595 minecraft:green_terracotta
setblock 330 154 560 minecraft:oak_leaves[persistent=true]
setblock 330 154 566 minecraft:oak_log
fill 330 154 567 330 157 567 minecraft:green_terracotta
setblock 330 154 571 minecraft:oak_log
fill 330 154 572 330 157 572 minecraft:green_terracotta
setblock 330 154 576 minecraft:oak_log
fill 330 154 577 330 156 578 minecraft:green_terracotta
setblock 330 154 585 minecraft:oak_leaves[persistent=true]
fill 330 154 589 330 154 590 minecraft:green_terracotta
setblock 330 154 591 minecraft:oak_log
fill 330 154 592 330 157 592 minecraft:green_terracotta
setblock 331 154 569 minecraft:green_terracotta
setblock 331 154 570 minecraft:oak_log
fill 331 154 571 332 156 571 minecraft:green_terracotta
setblock 331 154 575 minecraft:oak_log
setblock 332 154 569 minecraft:oak_log
fill 332 154 570 332 157 570 minecraft:green_terracotta
fill 332 154 572 332 154 573 minecraft:green_terracotta
fill 335 154 558 337 154 558 minecraft:green_terracotta
fill 335 154 598 337 154 598 minecraft:green_terracotta
setblock 338 154 558 minecraft:oak_log
fill 338 154 559 340 155 559 minecraft:green_terracotta
setblock 338 154 597 minecraft:green_terracotta
setblock 338 154 598 minecraft:oak_log
fill 339 154 558 339 157 558 minecraft:green_terracotta
setblock 339 154 597 minecraft:oak_log
fill 339 154 598 342 154 598 minecraft:green_terracotta
fill 340 154 597 340 157 597 minecraft:green_terracotta
setblock 342 154 558 minecraft:green_terracotta
setblock 343 154 558 minecraft:oak_log
setblock 343 154 598 minecraft:oak_log
fill 344 154 558 345 156 558 minecraft:green_terracotta
fill 344 154 598 345 156 598 minecraft:green_terracotta
fill 349 154 598 352 154 598 minecraft:green_terracotta
setblock 352 154 558 minecraft:green_terracotta
fill 352 154 597 353 154 597 minecraft:green_terracotta
setblock 353 154 558 minecraft:oak_log
setblock 353 154 598 minecraft:oak_log
fill 354 154 558 357 154 558 minecraft:green_terracotta
setblock 354 154 596 minecraft:green_terracotta
setblock 354 154 597 minecraft:oak_log
fill 354 154 598 357 154 598 minecraft:green_terracotta
setblock 355 154 596 minecraft:oak_log
fill 355 154 597 358 154 597 minecraft:green_terracotta
setblock 356 154 595 minecraft:oak_log
fill 356 154 596 356 157 596 minecraft:green_terracotta
fill 357 154 595 357 157 595 minecraft:green_terracotta
setblock 358 154 558 minecraft:oak_log
setblock 358 154 598 minecraft:oak_log
fill 359 154 558 359 157 558 minecraft:green_terracotta
setblock 359 154 596 minecraft:green_terracotta
setblock 359 154 597 minecraft:oak_log
fill 359 154 598 359 157 598 minecraft:green_terracotta
setblock 360 154 596 minecraft:oak_log
fill 360 154 597 360 157 597 minecraft:green_terracotta
fill 361 154 570 361 154 573 minecraft:dark_oak_log
setblock 361 154 595 minecraft:oak_log
fill 361 154 596 361 157 596 minecraft:green_terracotta
fill 362 154 568 362 154 569 minecraft:dark_oak_log
setblock 362 154 574 minecraft:dark_oak_log
fill 363 154 568 367 154 568 minecraft:dark_oak_log
fill 363 154 575 366 154 575 minecraft:dark_oak_log
fill 363 154 596 363 155 596 minecraft:green_terracotta
setblock 363 154 598 minecraft:oak_log
setblock 364 154 558 minecraft:oak_leaves[persistent=true]
setblock 364 154 597 minecraft:oak_log
fill 364 154 598 364 157 598 minecraft:green_terracotta
fill 367 154 569 368 154 569 minecraft:dark_oak_log
fill 367 154 574 368 154 574 minecraft:dark_oak_log
fill 368 154 570 368 154 573 minecraft:dark_oak_log
setblock 369 154 592 minecraft:oak_log
fill 369 154 593 369 157 593 minecraft:green_terracotta
fill 370 154 569 370 154 570 minecraft:green_terracotta
setblock 370 154 571 minecraft:oak_log
fill 370 154 572 370 157 572 minecraft:green_terracotta
fill 370 154 574 370 154 575 minecraft:green_terracotta
setblock 370 154 576 minecraft:oak_log
setblock 370 154 586 minecraft:oak_log
fill 370 154 587 370 157 587 minecraft:green_terracotta
setblock 370 154 591 minecraft:oak_log
fill 370 154 592 370 157 592 minecraft:green_terracotta
setblock 370 154 596 minecraft:oak_log
fill 330 155 566 330 158 566 minecraft:green_terracotta
setblock 330 155 570 minecraft:oak_log
fill 330 155 571 330 158 571 minecraft:green_terracotta
setblock 330 155 574 minecraft:green_terracotta
setblock 330 155 575 minecraft:oak_log
fill 330 155 576 331 157 576 minecraft:green_terracotta
setblock 330 155 579 minecraft:green_terracotta
setblock 330 155 589 minecraft:green_terracotta
setblock 330 155 590 minecraft:oak_log
fill 330 155 591 330 158 591 minecraft:green_terracotta
fill 330 155 593 330 155 594 minecraft:green_terracotta
fill 331 155 567 331 156 567 minecraft:green_terracotta
setblock 331 155 569 minecraft:oak_log
fill 331 155 570 331 158 570 minecraft:green_terracotta
setblock 331 155 574 minecraft:oak_log
fill 331 155 575 332 157 575 minecraft:green_terracotta
fill 331 155 577 331 156 577 minecraft:green_terracotta
setblock 332 155 568 minecraft:oak_log
fill 332 155 569 332 158 569 minecraft:green_terracotta
setblock 332 155 572 minecraft:green_terracotta
setblock 332 155 573 minecraft:oak_log
fill 332 155 574 332 158 574 minecraft:green_terracotta
setblock 333 155 558 minecraft:oak_leaves[persistent=true]
setblock 333 155 571 minecraft:green_terracotta
setblock 333 155 572 minecraft:oak_log
fill 333 155 598 336 155 598 minecraft:green_terracotta
fill 334 155 558 336 155 558 minecraft:green_terracotta
setblock 336 155 559 minecraft:oak_log
fill 336 155 597 337 155 597 minecraft:green_terracotta
setblock 337 155 558 minecraft:oak_log
fill 337 155 559 337 158 559 minecraft:green_terracotta
setblock 337 155 598 minecraft:oak_log
fill 338 155 558 338 158 558 minecraft:green_terracotta
setblock 338 155 597 minecraft:oak_log
fill 338 155 598 341 155 598 minecraft:green_terracotta
fill 339 155 597 339 158 597 minecraft:green_terracotta
setblock 341 155 559 minecraft:oak_log
fill 341 155 597 342 155 597 minecraft:green_terracotta
setblock 342 155 558 minecraft:oak_log
setblock 342 155 598 minecraft:oak_log
fill 343 155 558 343 158 558 minecraft:green_terracotta
fill 343 155 598 343 158 598 minecraft:green_terracotta
setblock 346 155 558 minecraft:green_terracotta
setblock 346 155 598 minecraft:green_terracotta
setblock 347 155 598 minecraft:oak_log
fill 348 155 598 351 155 598 minecraft:green_terracotta
fill 350 155 558 351 155 558 minecraft:green_terracotta
fill 350 155 597 352 155 597 minecraft:green_terracotta
setblock 352 155 558 minecraft:oak_log
fill 352 155 596 353 155 596 minecraft:green_terracotta
setblock 352 155 598 minecraft:oak_log
fill 353 155 558 356 155 558 minecraft:green_terracotta
setblock 353 155 597 minecraft:oak_log
fill 353 155 598 356 155 598 minecraft:green_terracotta
setblock 354 155 595 minecraft:green_terracotta
setblock 354 155 596 minecraft:oak_log
fill 354 155 597 357 155 597 minecraft:green_terracotta
setblock 355 155 595 minecraft:oak_log
fill 355 155 596 355 158 596 minecraft:green_terracotta
fill 356 155 595 356 158 595 minecraft:green_terracotta
setblock 357 155 558 minecraft:oak_log
setblock 357 155 598 minecraft:oak_log
fill 358 155 558 358 158 558 minecraft:green_terracotta
fill 358 155 595 359 155 595 minecraft:green_terracotta
setblock 358 155 597 minecraft:oak_log
fill 358 155 598 358 158 598 minecraft:green_terracotta
setblock 359 155 596 minecraft:oak_log
fill 359 155 597 359 158 597 minecraft:green_terracotta
setblock 360 155 595 minecraft:oak_log
fill 360 155 596 360 158 596 minecraft:green_terracotta
fill 361 155 595 361 158 595 minecraft:green_terracotta
setblock 362 155 598 minecraft:oak_log
setblock 363 155 597 minecraft:oak_log
fill 363 155 598 363 158 598 minecraft:green_terracotta
fill 364 155 597 365 157 597 minecraft:green_terracotta
setblock 366 155 598 minecraft:green_terracotta
setblock 367 155 598 minecraft:oak_leaves[persistent=true]
setblock 369 155 591 minecraft:oak_log
fill 369 155 592 369 158 592 minecraft:green_terracotta
fill 369 155 594 369 156 594 minecraft:green_terracotta
setblock 370 155 565 minecraft:oak_leaves[persistent=true]
setblock 370 155 569 minecraft:green_terracotta
setblock 370 155 570 minecraft:oak_log
fill 370 155 571 370 158 571 minecraft:green_terracotta
setblock 370 155 574 minecraft:green_terracotta
setblock 370 155 575 minecraft:oak_log
fill 370 155 576 370 155 579 minecraft:green_terracotta
setblock 370 155 584 minecraft:oak_leaves[persistent=true]
setblock 370 155 585 minecraft:oak_log
fill 370 155 586 370 158 586 minecraft:green_terracotta
setblock 370 155 590 minecraft:oak_log
fill 370 155 591 370 158 591 minecraft:green_terracotta
setblock 370 155 595 minecraft:oak_log
fill 370 155 596 370 157 597 minecraft:green_terracotta
fill 330 156 565 330 159 565 minecraft:green_terracotta
setblock 330 156 568 minecraft:green_terracotta
setblock 330 156 569 minecraft:oak_log
fill 330 156 570 330 159 570 minecraft:green_terracotta
setblock 330 156 573 minecraft:green_terracotta
setblock 330 156 574 minecraft:oak_log
fill 330 156 575 330 159 575 minecraft:green_terracotta
setblock 330 156 579 minecraft:oak_log
fill 330 156 580 330 158 581 minecraft:green_terracotta
setblock 330 156 589 minecraft:oak_log
fill 330 156 590 330 159 590 minecraft:green_terracotta
setblock 330 156 593 minecraft:green_terracotta
setblock 330 156 594 minecraft:oak_log
fill 330 156 595 330 158 596 minecraft:green_terracotta
setblock 330 156 597 minecraft:oak_leaves[persistent=true]
fill 331 156 566 331 157 566 minecraft:green_terracotta
setblock 331 156 568 minecraft:oak_log
fill 331 156 569 331 159 569 minecraft:green_terracotta
setblock 331 156 573 minecraft:oak_log
fill 331 156 574 331 159 574 minecraft:green_terracotta
setblock 331 156 578 minecraft:oak_log
fill 332 156 558 335 156 558 minecraft:green_terracotta
fill 332 156 568 332 159 568 minecraft:green_terracotta
setblock 332 156 572 minecraft:oak_log
fill 332 156 573 333 158 573 minecraft:green_terracotta
setblock 332 156 576 minecraft:green_terracotta
setblock 332 156 577 minecraft:oak_log
fill 332 156 598 335 156 598 minecraft:green_terracotta
setblock 333 156 570 minecraft:green_terracotta
setblock 333 156 571 minecraft:oak_log
fill 333 156 572 333 159 572 minecraft:green_terracotta
fill 333 156 574 333 156 575 minecraft:green_terracotta
fill 334 156 597 336 156 597 minecraft:green_terracotta
setblock 335 156 559 minecraft:oak_log
setblock 336 156 558 minecraft:oak_log
fill 336 156 559 336 159 559 minecraft:green_terracotta
setblock 336 156 598 minecraft:oak_log
fill 337 156 558 337 159 558 minecraft:green_terracotta
setblock 337 156 596 minecraft:green_terracotta
setblock 337 156 597 minecraft:oak_log
fill 337 156 598 340 156 598 minecraft:green_terracotta
fill 338 156 559 339 156 559 minecraft:green_terracotta
setblock 338 156 596 minecraft:oak_log
fill 338 156 597 338 159 597 minecraft:green_terracotta
fill 339 156 596 339 159 596 minecraft:green_terracotta
setblock 340 156 559 minecraft:oak_log
setblock 341 156 558 minecraft:oak_log
fill 341 156 559 342 158 559 minecraft:green_terracotta
setblock 341 156 597 minecraft:green_terracotta
setblock 341 156 598 minecraft:oak_log
fill 342 156 558 342 159 558 minecraft:green_terracotta
setblock 342 156 597 minecraft:oak_log
fill 342 156 598 342 159 598 minecraft:green_terracotta
fill 343 156 597 344 158 597 minecraft:green_terracotta
setblock 346 156 558 minecraft:oak_log
setblock 346 156 598 minecraft:oak_log
fill 347 156 558 350 156 558 minecraft:green_terracotta
setblock 347 156 597 minecraft:oak_log
fill 347 156 598 350 156 598 minecraft:green_terracotta
fill 348 156 597 351 156 597 minecraft:green_terracotta
setblock 351 156 558 minecraft:oak_log
fill 351 156 596 352 156 596 minecraft:green_terracotta
setblock 351 156 598 minecraft:oak_log
fill 352 156 558 355 156 558 minecraft:green_terracotta
setblock 352 156 597 minecraft:oak_log
fill 352 156 598 355 156 598 minecraft:green_terracotta
setblock 353 156 595 minecraft:green_terracotta
setblock 353 156 596 minecraft:oak_log
fill 353 156 597 356 156 597 minecraft:green_terracotta
setblock 354 156 559 minecraft:green_terracotta
setblock 354 156 595 minecraft:oak_log
fill 354 156 596 354 159 596 minecraft:green_terracotta
setblock 355 156 559 minecraft:oak_log
fill 355 156 595 355 159 595 minecraft:green_terracotta
setblock 356 156 558 minecraft:oak_log
fill 356 156 559 358 157 559 minecraft:green_terracotta
fill 356 156 594 359 156 594 minecraft:green_terracotta
setblock 356 156 598 minecraft:oak_log
fill 357 156 558 357 159 558 minecraft:green_terracotta
setblock 357 156 597 minecraft:oak_log
fill 357 156 598 357 159 598 minecraft:green_terracotta
setblock 358 156 595 minecraft:green_terracotta
setblock 358 156 596 minecraft:oak_log
fill 358 156 597 358 159 597 minecraft:green_terracotta
setblock 359 156 595 minecraft:oak_log
fill 359 156 596 359 159 596 minecraft:green_terracotta
fill 360 156 595 360 159 595 minecraft:green_terracotta
setblock 361 156 558 minecraft:oak_log
setblock 361 156 598 minecraft:oak_log
setblock 362 156 595 minecraft:green_terracotta
setblock 362 156 597 minecraft:oak_log
fill 362 156 598 362 159 598 minecraft:green_terracotta
setblock 363 156 596 minecraft:oak_log
fill 363 156 597 363 159 597 minecraft:green_terracotta
setblock 366 156 598 minecraft:oak_log
fill 367 156 598 370 156 598 minecraft:green_terracotta
fill 369 156 572 369 156 574 minecraft:green_terracotta
setblock 369 156 575 minecraft:oak_log
fill 369 156 576 370 158 576 minecraft:green_terracotta
setblock 369 156 590 minecraft:oak_log
fill 369 156 591 369 158 591 minecraft:green_terracotta
setblock 369 156 595 minecraft:oak_log
setblock 370 156 559 minecraft:oak_leaves[persistent=true]
setblock 370 156 568 minecraft:green_terracotta
setblock 370 156 569 minecraft:oak_log
fill 370 156 570 370 159 570 minecraft:green_terracotta
setblock 370 156 574 minecraft:oak_log
fill 370 156 575 370 159 575 minecraft:green_terracotta
fill 370 156 577 370 156 578 minecraft:green_terracotta
setblock 370 156 579 minecraft:oak_log
fill 370 156 580 370 156 583 minecraft:green_terracotta
setblock 370 156 584 minecraft:oak_log
fill 370 156 585 370 159 585 minecraft:green_terracotta
setblock 370 156 589 minecraft:oak_log
fill 370 156 590 370 159 590 minecraft:green_terracotta
setblock 370 156 594 minecraft:oak_log
fill 370 156 595 370 159 595 minecraft:green_terracotta
setblock 330 157 559 minecraft:oak_leaves[persistent=true]
fill 330 157 564 330 160 564 minecraft:green_terracotta
setblock 330 157 568 minecraft:oak_log
fill 330 157 569 330 160 569 minecraft:green_terracotta
setblock 330 157 573 minecraft:oak_log
fill 330 157 574 330 160 574 minecraft:green_terracotta
setblock 330 157 577 minecraft:green_terracotta
setblock 330 157 578 minecraft:oak_log
fill 330 157 579 331 159 579 minecraft:green_terracotta
setblock 330 157 582 minecraft:green_terracotta
fill 330 157 584 330 158 584 minecraft:oak_leaves[persistent=true]
fill 330 157 589 330 158 589 minecraft:green_terracotta
setblock 330 157 593 minecraft:oak_log
fill 330 157 594 330 160 594 minecraft:green_terracotta
setblock 330 157 597 minecraft:green_terracotta
setblock 330 157 598 minecraft:oak_log
fill 331 157 558 334 157 558 minecraft:green_terracotta
setblock 331 157 567 minecraft:oak_log
fill 331 157 568 331 160 568 minecraft:green_terracotta
setblock 331 157 571 minecraft:green_terracotta
setblock 331 157 572 minecraft:oak_log
fill 331 157 573 331 160 573 minecraft:green_terracotta
setblock 331 157 577 minecraft:oak_log
fill 331 157 578 332 159 578 minecraft:green_terracotta
fill 331 157 580 331 158 580 minecraft:green_terracotta
fill 331 157 598 334 157 598 minecraft:green_terracotta
fill 332 157 567 332 159 567 minecraft:green_terracotta
setblock 332 157 571 minecraft:oak_log
fill 332 157 572 332 160 572 minecraft:green_terracotta
setblock 332 157 576 minecraft:oak_log
fill 332 157 577 332 160 577 minecraft:green_terracotta
fill 332 157 597 335 157 597 minecraft:green_terracotta
setblock 333 157 569 minecraft:green_terracotta
setblock 333 157 570 minecraft:oak_log
fill 333 157 571 333 160 571 minecraft:green_terracotta
setblock 333 157 574 minecraft:green_terracotta
setblock 333 157 575 minecraft:oak_log
fill 333 157 576 333 160 576 minecraft:green_terracotta
setblock 334 157 559 minecraft:oak_log
setblock 335 157 558 minecraft:oak_log
fill 335 157 559 335 160 559 minecraft:green_terracotta
fill 335 157 596 336 157 596 minecraft:green_terracotta
setblock 335 157 598 minecraft:oak_log
fill 336 157 558 336 160 558 minecraft:green_terracotta
setblock 336 157 597 minecraft:oak_log
fill 336 157 598 339 157 598 minecraft:green_terracotta
setblock 337 157 560 minecraft:green_terracotta
setblock 337 157 596 minecraft:oak_log
fill 337 157 597 337 160 597 minecraft:green_terracotta
setblock 338 157 559 minecraft:green_terracotta
setblock 338 157 560 minecraft:oak_log
fill 338 157 596 338 160 596 minecraft:green_terracotta
setblock 339 157 559 minecraft:oak_log
setblock 340 157 558 minecraft:oak_log
fill 340 157 559 340 160 559 minecraft:green_terracotta
fill 340 157 596 340 158 596 minecraft:green_terracotta
setblock 340 157 598 minecraft:oak_log
fill 341 157 558 341 160 558 minecraft:green_terracotta
setblock 341 157 597 minecraft:oak_log
fill 341 157 598 341 160 598 minecraft:green_terracotta
fill 342 157 597 342 160 597 minecraft:green_terracotta
setblock 343 157 559 minecraft:green_terracotta
setblock 344 157 558 minecraft:green_terracotta
setblock 344 157 598 minecraft:green_terracotta
setblock 345 157 558 minecraft:oak_log
setblock 345 157 597 minecraft:green_terracotta
setblock 345 157 598 minecraft:oak_log
fill 346 157 558 349 157 558 minecraft:green_terracotta
setblock 346 157 597 minecraft:oak_log
fill 346 157 598 349 157 598 minecraft:green_terracotta
fill 347 157 597 350 157 597 minecraft:green_terracotta
setblock 350 157 558 minecraft:oak_log
fill 350 157 596 351 157 596 minecraft:green_terracotta
setblock 350 157 598 minecraft:oak_log
fill 351 157 558 354 157 558 minecraft:green_terracotta
setblock 351 157 597 minecraft:oak_log
fill 351 157 598 354 157 598 minecraft:green_terracotta
fill 352 157 559 353 157 559 minecraft:green_terracotta
setblock 352 157 595 minecraft:green_terracotta
setblock 352 157 596 minecraft:oak_log
fill 352 157 597 355 157 597 minecraft:green_terracotta
setblock 353 157 595 minecraft:oak_log
fill 353 157 596 353 160 596 minecraft:green_terracotta
setblock 354 157 559 minecraft:oak_log
fill 354 157 595 354 160 595 minecraft:green_terracotta
setblock 355 157 558 minecraft:oak_log
fill 355 157 559 355 160 559 minecraft:green_terracotta
fill 355 157 594 358 157 594 minecraft:green_terracotta
setblock 355 157 598 minecraft:oak_log
fill 356 157 558 356 160 558 minecraft:green_terracotta
setblock 356 157 597 minecraft:oak_log
fill 356 157 598 356 160 598 minecraft:green_terracotta
setblock 357 157 596 minecraft:oak_log
fill 357 157 597 357 160 597 minecraft:green_terracotta
setblock 358 157 595 minecraft:oak_log
fill 358 157 596 358 160 596 minecraft:green_terracotta
setblock 359 157 594 minecraft:oak_log
fill 359 157 595 359 160 595 minecraft:green_terracotta
setblock 360 157 558 minecraft:oak_log
setblock 360 157 598 minecraft:oak_log
fill 361 157 558 362 158 558 minecraft:green_terracotta
setblock 361 157 597 minecraft:oak_log
fill 361 157 598 361 160 598 minecraft:green_terracotta
setblock 362 157 596 minecraft:oak_log
fill 362 157 597 362 160 597 minecraft:green_terracotta
fill 363 157 596 363 158 596 minecraft:green_terracotta
setblock 365 157 558 minecraft:oak_leaves[persistent=true]
setblock 365 157 598 minecraft:oak_log
setblock 366 157 597 minecraft:oak_log
fill 366 157 598 369 157 598 minecraft:green_terracotta
fill 369 157 571 369 157 573 minecraft:green_terracotta
setblock 369 157 574 minecraft:oak_log
fill 369 157 575 369 160 575 minecraft:green_terracotta
fill 369 157 577 369 157 578 minecraft:green_terracotta
fill 369 157 590 369 158 590 minecraft:green_terracotta
setblock 369 157 594 minecraft:oak_log
fill 369 157 595 369 159 596 minecraft:green_terracotta
setblock 370 157 568 minecraft:oak_log
fill 370 157 569 370 160 569 minecraft:green_terracotta
setblock 370 157 573 minecraft:oak_log
fill 370 157 574 370 160 574 minecraft:green_terracotta
setblock 370 157 577 minecraft:green_terracotta
setblock 370 157 578 minecraft:oak_log
fill 370 157 579 370 157 582 minecraft:green_terracotta
setblock 370 157 583 minecraft:oak_log
fill 370 157 584 370 160 584 minecraft:green_terracotta
setblock 370 157 588 minecraft:oak_log
fill 370 157 589 370 160 589 minecraft:green_terracotta
setblock 370 157 593 minecraft:oak_log
fill 370 157 594 370 160 594 minecraft:green_terracotta
setblock 370 157 598 minecraft:oak_log
fill 330 158 558 330 160 559 minecraft:green_terracotta
fill 330 158 563 330 161 563 minecraft:green_terracotta
setblock 330 158 567 minecraft:oak_log
fill 330 158 568 330 161 568 minecraft:green_terracotta
setblock 330 158 572 minecraft:oak_log
fill 330 158 573 330 161 573 minecraft:green_terracotta
setblock 330 158 576 minecraft:green_terracotta
setblock 330 158 577 minecraft:oak_log
fill 330 158 578 330 161 578 minecraft:green_terracotta
setblock 330 158 582 minecraft:oak_log
fill 330 158 583 330 161 583 minecraft:green_terracotta
setblock 330 158 592 minecraft:oak_log
fill 330 158 593 331 158 593 minecraft:green_terracotta
setblock 330 158 597 minecraft:oak_log
fill 330 158 598 333 158 598 minecraft:green_terracotta
fill 331 158 558 333 158 558 minecraft:green_terracotta
setblock 331 158 566 minecraft:oak_log
fill 331 158 567 331 161 567 minecraft:green_terracotta
setblock 331 158 571 minecraft:oak_log
fill 331 158 572 331 161 572 minecraft:green_terracotta
setblock 331 158 575 minecraft:green_terracotta
setblock 331 158 576 minecraft:oak_log
fill 331 158 577 331 161 577 minecraft:green_terracotta
setblock 331 158 581 minecraft:oak_log
fill 331 158 594 331 158 595 minecraft:green_terracotta
setblock 331 158 596 minecraft:oak_log
fill 331 158 597 334 158 597 minecraft:green_terracotta
setblock 332 158 559 minecraft:green_terracotta
setblock 332 158 570 minecraft:oak_log
fill 332 158 571 332 161 571 minecraft:green_terracotta
setblock 332 158 575 minecraft:oak_log
fill 332 158 576 332 161 576 minecraft:green_terracotta
setblock 332 158 579 minecraft:green_terracotta
setblock 333 158 559 minecraft:oak_log
setblock 333 158 569 minecraft:oak_log
fill 333 158 570 333 160 570 minecraft:green_terracotta
setblock 333 158 574 minecraft:oak_log
fill 333 158 575 333 161 575 minecraft:green_terracotta
fill 333 158 577 333 159 577 minecraft:green_terracotta
setblock 334 158 558 minecraft:oak_log
fill 334 158 559 334 161 559 minecraft:green_terracotta
setblock 334 158 572 minecraft:green_terracotta
setblock 334 158 573 minecraft:oak_log
setblock 334 158 574 minecraft:green_terracotta
fill 334 158 596 335 158 596 minecraft:green_terracotta
setblock 334 158 598 minecraft:oak_log
fill 335 158 558 335 161 558 minecraft:green_terracotta
fill 335 158 560 336 158 560 minecraft:green_terracotta
setblock 335 158 597 minecraft:oak_log
fill 335 158 598 338 158 598 minecraft:green_terracotta
setblock 336 158 596 minecraft:oak_log
fill 336 158 597 336 161 597 minecraft:green_terracotta
setblock 337 158 560 minecraft:oak_log
fill 337 158 596 337 160 596 minecraft:green_terracotta
setblock 338 158 559 minecraft:oak_log
fill 338 158 560 339 159 560 minecraft:green_terracotta
setblock 339 158 558 minecraft:oak_log
fill 339 158 559 339 161 559 minecraft:green_terracotta
setblock 339 158 598 minecraft:oak_log
fill 340 158 558 340 161 558 minecraft:green_terracotta
setblock 340 158 597 minecraft:oak_log
fill 340 158 598 340 161 598 minecraft:green_terracotta
fill 341 158 597 341 161 597 minecraft:green_terracotta
setblock 343 158 559 minecraft:oak_log
setblock 344 158 558 minecraft:oak_log
setblock 344 158 598 minecraft:oak_log
fill 345 158 558 348 158 558 minecraft:green_terracotta
setblock 345 158 597 minecraft:oak_log
fill 345 158 598 348 158 598 minecraft:green_terracotta
fill 346 158 597 349 158 597 minecraft:green_terracotta
setblock 349 158 558 minecraft:oak_log
fill 349 158 596 350 158 596 minecraft:green_terracotta
setblock 349 158 598 minecraft:oak_log
fill 350 158 558 352 158 559 minecraft:green_terracotta
setblock 350 158 597 minecraft:oak_log
fill 350 158 598 353 158 598 minecraft:green_terracotta
setblock 351 158 595 minecraft:green_terracotta
setblock 351 158 596 minecraft:oak_log
fill 351 158 597 354 158 597 minecraft:green_terracotta
setblock 352 158 595 minecraft:oak_log
fill 352 158 596 352 161 596 minecraft:green_terracotta
setblock 353 158 558 minecraft:green_terracotta
setblock 353 158 559 minecraft:oak_log
fill 353 158 595 353 161 595 minecraft:green_terracotta
setblock 354 158 558 minecraft:oak_log
fill 354 158 559 354 161 559 minecraft:green_terracotta
fill 354 158 594 357 158 594 minecraft:green_terracotta
setblock 354 158 598 minecraft:oak_log
fill 355 158 558 355 161 558 minecraft:green_terracotta
setblock 355 158 597 minecraft:oak_log
fill 355 158 598 355 161 598 minecraft:green_terracotta
fill 356 158 559 357 158 559 minecraft:green_terracotta
setblock 356 158 596 minecraft:oak_log
fill 356 158 597 356 161 597 minecraft:green_terracotta
setblock 357 158 595 minecraft:oak_log
fill 357 158 596 357 161 596 minecraft:green_terracotta
setblock 358 158 559 minecraft:oak_log
setblock 358 158 594 minecraft:oak_log
fill 358 158 595 358 161 595 minecraft:green_terracotta
setblock 359 158 558 minecraft:oak_log
setblock 359 158 598 minecraft:oak_log
fill 360 158 558 360 161 558 minecraft:green_terracotta
setblock 360 158 597 minecraft:oak_log
fill 360 158 598 360 161 598 minecraft:green_terracotta
setblock 361 158 596 minecraft:oak_log
fill 361 158 597 361 161 597 minecraft:green_terracotta
fill 362 158 596 362 159 596 minecraft:green_terracotta
setblock 364 158 597 minecraft:green_terracotta
setblock 364 158 598 minecraft:oak_log
setblock 365 158 597 minecraft:oak_log
fill 365 158 598 368 158 598 minecraft:green_terracotta
fill 366 158 597 366 159 597 minecraft:green_terracotta
fill 369 158 571 369 158 572 minecraft:green_terracotta
setblock 369 158 573 minecraft:oak_log
fill 369 158 574 369 161 574 minecraft:green_terracotta
setblock 369 158 577 minecraft:green_terracotta
setblock 369 158 578 minecraft:oak_log
fill 369 158 579 370 159 580 minecraft:green_terracotta
setblock 369 158 593 minecraft:oak_log
fill 369 158 594 369 160 594 minecraft:green_terracotta
setblock 369 158 598 minecraft:oak_log
setblock 370 158 566 minecraft:oak_leaves[persistent=true]
fill 370 158 568 370 161 568 minecraft:green_terracotta
setblock 370 158 572 minecraft:oak_log
fill 370 158 573 370 161 573 minecraft:green_terracotta
setblock 370 158 577 minecraft:oak_log
fill 370 158 578 370 161 578 minecraft:green_terracotta
setblock 370 158 581 minecraft:green_terracotta
setblock 370 158 582 minecraft:oak_log
fill 370 158 583 370 161 583 minecraft:green_terracotta
setblock 370 158 587 minecraft:oak_log
fill 370 158 588 370 161 588 minecraft:green_terracotta
setblock 370 158 592 minecraft:oak_log
fill 370 158 593 370 161 593 minecraft:green_terracotta
setblock 370 158 596 minecraft:green_terracotta
setblock 370 158 597 minecraft:oak_log
fill 370 158 598 370 161 598 minecraft:green_terracotta
setblock 330 159 560 minecraft:green_terracotta
setblock 330 159 561 minecraft:oak_log
fill 330 159 562 330 162 562 minecraft:green_terracotta
setblock 330 159 566 minecraft:oak_log
fill 330 159 567 330 162 567 minecraft:green_terracotta
setblock 330 159 571 minecraft:oak_log
fill 330 159 572 330 162 572 minecraft:green_terracotta
setblock 330 159 576 minecraft:oak_log
fill 330 159 577 330 162 577 minecraft:green_terracotta
setblock 330 159 580 minecraft:green_terracotta
setblock 330 159 581 minecraft:oak_log
fill 330 159 582 330 162 582 minecraft:green_terracotta
setblock 330 159 591 minecraft:oak_log
fill 330 159 592 330 160 593 minecraft:green_terracotta
setblock 330 159 595 minecraft:green_terracotta
setblock 330 159 596 minecraft:oak_log
fill 330 159 597 332 159 598 minecraft:green_terracotta
fill 331 159 558 331 159 559 minecraft:green_terracotta
setblock 331 159 565 minecraft:oak_log
fill 331 159 566 331 162 566 minecraft:green_terracotta
setblock 331 159 570 minecraft:oak_log
schedule function dropper:buildpart/139_4 1t
