fill 133 63 489 135 64 491 minecraft:cyan_stained_glass
fill 131 64 490 132 67 490 minecraft:cyan_stained_glass
fill 132 64 489 132 66 489 minecraft:cyan_stained_glass
fill 132 64 491 132 66 491 minecraft:cyan_stained_glass
fill 133 64 488 135 64 488 minecraft:cyan_stained_glass
fill 133 64 492 135 64 492 minecraft:cyan_stained_glass
fill 95 65 467 95 65 472 minecraft:sculk
fill 95 65 479 95 65 484 minecraft:sculk
fill 95 65 491 95 65 496 minecraft:sculk
fill 95 65 503 95 65 504 minecraft:sculk
fill 96 65 504 99 65 504 minecraft:sculk
fill 99 65 464 104 65 464 minecraft:sculk
fill 106 65 504 111 65 504 minecraft:sculk
fill 111 65 464 116 65 464 minecraft:sculk
fill 118 65 504 123 65 504 minecraft:sculk
fill 123 65 464 128 65 464 minecraft:sculk
fill 130 65 490 130 67 490 minecraft:cyan_stained_glass
fill 130 65 504 135 65 504 minecraft:sculk
fill 131 65 489 131 66 489 minecraft:cyan_stained_glass
fill 131 65 491 131 66 491 minecraft:cyan_stained_glass
fill 133 65 488 134 65 492 minecraft:cyan_stained_glass
fill 135 65 464 135 65 469 minecraft:sculk
fill 135 65 476 135 65 481 minecraft:sculk
fill 135 65 488 135 65 493 minecraft:sculk
fill 135 65 500 135 65 503 minecraft:sculk
fill 94 66 469 94 71 472 minecraft:sea_lantern
fill 94 66 481 94 71 484 minecraft:sea_lantern
fill 94 66 493 94 71 496 minecraft:sea_lantern
fill 94 66 505 97 71 505 minecraft:sea_lantern
fill 101 66 463 104 71 463 minecraft:sea_lantern
fill 106 66 505 109 71 505 minecraft:sea_lantern
fill 113 66 463 116 71 463 minecraft:sea_lantern
fill 118 66 505 121 71 505 minecraft:sea_lantern
fill 125 66 463 128 71 463 minecraft:sea_lantern
fill 129 66 490 129 67 490 minecraft:cyan_stained_glass
setblock 130 66 489 minecraft:cyan_stained_glass
setblock 130 66 491 minecraft:cyan_stained_glass
fill 130 66 505 133 71 505 minecraft:sea_lantern
fill 131 66 465 131 77 465 minecraft:reinforced_deepslate
fill 133 66 489 135 66 491 minecraft:cyan_stained_glass
fill 136 66 464 136 71 467 minecraft:sea_lantern
fill 136 66 476 136 71 479 minecraft:sea_lantern
fill 136 66 488 136 71 491 minecraft:sea_lantern
fill 136 66 500 136 71 503 minecraft:sea_lantern
setblock 128 67 490 minecraft:cyan_stained_glass
setblock 133 67 490 minecraft:cyan_stained_glass
fill 129 69 475 131 70 475 minecraft:cyan_concrete
fill 132 70 475 134 70 475 minecraft:cyan_concrete
setblock 97 71 466 minecraft:light[level=11]
setblock 97 71 474 minecraft:light[level=11]
setblock 97 71 482 minecraft:light[level=11]
setblock 97 71 490 minecraft:light[level=11]
setblock 97 71 498 minecraft:light[level=11]
setblock 105 71 466 minecraft:light[level=11]
setblock 105 71 474 minecraft:light[level=11]
setblock 105 71 482 minecraft:light[level=11]
setblock 105 71 490 minecraft:light[level=11]
setblock 105 71 498 minecraft:light[level=11]
setblock 113 71 466 minecraft:light[level=11]
setblock 113 71 474 minecraft:light[level=11]
setblock 113 71 482 minecraft:light[level=11]
setblock 113 71 490 minecraft:light[level=11]
setblock 113 71 498 minecraft:light[level=11]
setblock 121 71 466 minecraft:light[level=11]
setblock 121 71 474 minecraft:light[level=11]
setblock 121 71 482 minecraft:light[level=11]
setblock 121 71 490 minecraft:light[level=11]
setblock 121 71 498 minecraft:light[level=11]
setblock 129 71 466 minecraft:light[level=11]
setblock 129 71 474 minecraft:light[level=11]
setblock 129 71 482 minecraft:light[level=11]
setblock 129 71 490 minecraft:light[level=11]
setblock 129 71 498 minecraft:light[level=11]
fill 133 71 475 134 71 475 minecraft:cyan_concrete
fill 94 72 469 94 85 469 minecraft:black_concrete
fill 94 72 470 94 72 471 minecraft:sea_lantern
fill 94 72 472 94 85 472 minecraft:black_concrete
fill 94 72 481 94 85 481 minecraft:black_concrete
fill 94 72 482 94 72 483 minecraft:sea_lantern
fill 94 72 484 94 85 484 minecraft:black_concrete
fill 94 72 493 94 85 493 minecraft:black_concrete
fill 94 72 494 94 72 495 minecraft:sea_lantern
fill 94 72 496 94 85 496 minecraft:black_concrete
fill 94 72 505 94 85 505 minecraft:black_concrete
fill 95 72 505 96 72 505 minecraft:sea_lantern
fill 97 72 505 97 85 505 minecraft:black_concrete
fill 101 72 463 101 85 463 minecraft:black_concrete
fill 102 72 463 103 72 463 minecraft:sea_lantern
fill 104 72 463 104 85 463 minecraft:black_concrete
fill 106 72 505 106 85 505 minecraft:black_concrete
fill 107 72 505 108 72 505 minecraft:sea_lantern
fill 109 72 505 109 85 505 minecraft:black_concrete
fill 113 72 463 113 85 463 minecraft:black_concrete
fill 114 72 463 115 72 463 minecraft:sea_lantern
fill 116 72 463 116 85 463 minecraft:black_concrete
fill 118 72 505 118 85 505 minecraft:black_concrete
fill 119 72 505 120 72 505 minecraft:sea_lantern
fill 121 72 505 121 85 505 minecraft:black_concrete
fill 125 72 463 125 85 463 minecraft:black_concrete
fill 126 72 463 127 72 463 minecraft:sea_lantern
fill 128 72 463 128 85 463 minecraft:black_concrete
fill 130 72 505 130 85 505 minecraft:black_concrete
fill 131 72 505 132 72 505 minecraft:sea_lantern
fill 133 72 505 133 85 505 minecraft:black_concrete
fill 136 72 464 136 85 464 minecraft:black_concrete
fill 136 72 465 136 72 466 minecraft:sea_lantern
fill 136 72 467 136 85 467 minecraft:black_concrete
fill 136 72 476 136 85 476 minecraft:black_concrete
fill 136 72 477 136 72 478 minecraft:sea_lantern
fill 136 72 479 136 85 479 minecraft:black_concrete
fill 136 72 488 136 85 488 minecraft:black_concrete
fill 136 72 489 136 72 490 minecraft:sea_lantern
fill 136 72 491 136 85 491 minecraft:black_concrete
fill 136 72 500 136 85 500 minecraft:black_concrete
fill 136 72 501 136 72 502 minecraft:sea_lantern
fill 136 72 503 136 85 503 minecraft:black_concrete
fill 94 73 470 94 85 471 minecraft:black_concrete
fill 94 73 482 94 85 483 minecraft:black_concrete
fill 94 73 494 94 85 495 minecraft:black_concrete
fill 95 73 505 96 85 505 minecraft:black_concrete
fill 102 73 463 103 85 463 minecraft:black_concrete
fill 107 73 505 108 85 505 minecraft:black_concrete
fill 114 73 463 115 85 463 minecraft:black_concrete
fill 119 73 505 120 85 505 minecraft:black_concrete
fill 126 73 463 127 85 463 minecraft:black_concrete
fill 131 73 505 132 85 505 minecraft:black_concrete
fill 136 73 465 136 85 466 minecraft:black_concrete
fill 136 73 477 136 85 478 minecraft:black_concrete
fill 136 73 489 136 85 490 minecraft:black_concrete
fill 136 73 501 136 85 502 minecraft:black_concrete
setblock 97 79 466 minecraft:light[level=11]
setblock 97 79 474 minecraft:light[level=11]
setblock 97 79 482 minecraft:light[level=11]
setblock 97 79 490 minecraft:light[level=11]
setblock 97 79 498 minecraft:light[level=11]
setblock 105 79 466 minecraft:light[level=11]
setblock 105 79 474 minecraft:light[level=11]
setblock 105 79 482 minecraft:light[level=11]
setblock 105 79 490 minecraft:light[level=11]
setblock 105 79 498 minecraft:light[level=11]
setblock 113 79 466 minecraft:light[level=11]
setblock 113 79 474 minecraft:light[level=11]
setblock 113 79 482 minecraft:light[level=11]
setblock 113 79 490 minecraft:light[level=11]
setblock 113 79 498 minecraft:light[level=11]
setblock 121 79 466 minecraft:light[level=11]
setblock 121 79 474 minecraft:light[level=11]
setblock 121 79 482 minecraft:light[level=11]
setblock 121 79 490 minecraft:light[level=11]
setblock 121 79 498 minecraft:light[level=11]
setblock 129 79 466 minecraft:light[level=11]
setblock 129 79 474 minecraft:light[level=11]
setblock 129 79 482 minecraft:light[level=11]
setblock 129 79 490 minecraft:light[level=11]
setblock 129 79 498 minecraft:light[level=11]
fill 96 80 473 96 85 475 minecraft:deepslate_bricks
fill 96 80 485 96 85 487 minecraft:deepslate_bricks
fill 96 80 497 96 85 499 minecraft:deepslate_bricks
fill 102 80 503 104 85 503 minecraft:deepslate_bricks
fill 106 80 465 108 85 465 minecraft:deepslate_bricks
fill 114 80 503 116 85 503 minecraft:deepslate_bricks
fill 118 80 465 120 85 465 minecraft:deepslate_bricks
fill 126 80 503 128 85 503 minecraft:deepslate_bricks
fill 130 80 465 132 85 465 minecraft:deepslate_bricks
fill 134 80 473 134 85 475 minecraft:deepslate_bricks
fill 134 80 485 134 85 487 minecraft:deepslate_bricks
fill 134 80 497 134 85 499 minecraft:deepslate_bricks
fill 123 81 468 123 91 468 minecraft:reinforced_deepslate
fill 95 85 467 95 85 472 minecraft:sculk
fill 95 85 479 95 85 484 minecraft:sculk
fill 95 85 491 95 85 496 minecraft:sculk
fill 95 85 503 95 85 504 minecraft:sculk
fill 96 85 504 99 85 504 minecraft:sculk
fill 99 85 464 104 85 464 minecraft:sculk
fill 106 85 504 111 85 504 minecraft:sculk
fill 111 85 464 116 85 464 minecraft:sculk
fill 118 85 504 123 85 504 minecraft:sculk
fill 123 85 464 128 85 464 minecraft:sculk
fill 130 85 504 135 85 504 minecraft:sculk
fill 135 85 464 135 85 469 minecraft:sculk
fill 135 85 476 135 85 481 minecraft:sculk
fill 135 85 488 135 85 493 minecraft:sculk
fill 135 85 500 135 85 503 minecraft:sculk
fill 94 86 469 94 91 472 minecraft:sea_lantern
fill 94 86 481 94 91 484 minecraft:sea_lantern
fill 94 86 493 94 91 496 minecraft:sea_lantern
fill 94 86 505 97 91 505 minecraft:sea_lantern
fill 101 86 463 104 91 463 minecraft:sea_lantern
fill 106 86 505 109 91 505 minecraft:sea_lantern
fill 113 86 463 116 91 463 minecraft:sea_lantern
fill 118 86 505 121 91 505 minecraft:sea_lantern
fill 125 86 463 128 91 463 minecraft:sea_lantern
fill 130 86 505 133 91 505 minecraft:sea_lantern
fill 136 86 464 136 91 467 minecraft:sea_lantern
fill 136 86 476 136 91 479 minecraft:sea_lantern
fill 136 86 488 136 91 491 minecraft:sea_lantern
fill 136 86 500 136 91 503 minecraft:sea_lantern
setblock 97 87 466 minecraft:light[level=11]
setblock 97 87 474 minecraft:light[level=11]
setblock 97 87 482 minecraft:light[level=11]
setblock 97 87 490 minecraft:light[level=11]
setblock 97 87 498 minecraft:light[level=11]
setblock 105 87 466 minecraft:light[level=11]
setblock 105 87 474 minecraft:light[level=11]
setblock 105 87 482 minecraft:light[level=11]
setblock 105 87 490 minecraft:light[level=11]
setblock 105 87 498 minecraft:light[level=11]
setblock 113 87 466 minecraft:light[level=11]
setblock 113 87 474 minecraft:light[level=11]
setblock 113 87 482 minecraft:light[level=11]
setblock 113 87 490 minecraft:light[level=11]
setblock 113 87 498 minecraft:light[level=11]
setblock 121 87 466 minecraft:light[level=11]
setblock 121 87 474 minecraft:light[level=11]
setblock 121 87 482 minecraft:light[level=11]
setblock 121 87 490 minecraft:light[level=11]
setblock 121 87 498 minecraft:light[level=11]
setblock 129 87 466 minecraft:light[level=11]
setblock 129 87 474 minecraft:light[level=11]
setblock 129 87 482 minecraft:light[level=11]
setblock 129 87 490 minecraft:light[level=11]
setblock 129 87 498 minecraft:light[level=11]
fill 94 92 469 94 116 469 minecraft:black_concrete
fill 94 92 470 94 92 471 minecraft:sea_lantern
fill 94 92 472 94 112 472 minecraft:black_concrete
fill 94 92 481 94 116 481 minecraft:black_concrete
fill 94 92 482 94 92 483 minecraft:sea_lantern
fill 94 92 484 94 116 484 minecraft:black_concrete
fill 94 92 493 94 113 493 minecraft:black_concrete
fill 94 92 494 94 92 495 minecraft:sea_lantern
fill 94 92 496 94 116 496 minecraft:black_concrete
fill 94 92 505 94 116 505 minecraft:black_concrete
fill 95 92 505 96 92 505 minecraft:sea_lantern
fill 97 92 505 97 116 505 minecraft:black_concrete
fill 101 92 463 101 116 463 minecraft:black_concrete
fill 102 92 463 103 92 463 minecraft:sea_lantern
fill 104 92 463 104 117 463 minecraft:black_concrete
fill 106 92 505 106 114 505 minecraft:black_concrete
fill 107 92 505 108 92 505 minecraft:sea_lantern
fill 109 92 505 109 116 505 minecraft:black_concrete
fill 113 92 463 113 112 463 minecraft:black_concrete
fill 114 92 463 115 92 463 minecraft:sea_lantern
fill 116 92 463 116 116 463 minecraft:black_concrete
fill 118 92 505 118 113 505 minecraft:black_concrete
fill 119 92 505 120 92 505 minecraft:sea_lantern
fill 121 92 505 121 116 505 minecraft:black_concrete
fill 125 92 463 125 116 463 minecraft:black_concrete
fill 126 92 463 127 92 463 minecraft:sea_lantern
fill 128 92 463 128 112 463 minecraft:black_concrete
fill 130 92 505 130 114 505 minecraft:black_concrete
fill 131 92 505 132 92 505 minecraft:sea_lantern
fill 133 92 505 133 113 505 minecraft:black_concrete
fill 136 92 464 136 112 464 minecraft:black_concrete
fill 136 92 465 136 92 466 minecraft:sea_lantern
fill 136 92 467 136 116 467 minecraft:black_concrete
fill 136 92 476 136 116 476 minecraft:black_concrete
fill 136 92 477 136 92 478 minecraft:sea_lantern
fill 136 92 479 136 114 479 minecraft:black_concrete
fill 136 92 488 136 116 488 minecraft:black_concrete
fill 136 92 489 136 92 490 minecraft:sea_lantern
fill 136 92 491 136 116 491 minecraft:black_concrete
fill 136 92 500 136 113 500 minecraft:black_concrete
fill 136 92 501 136 92 502 minecraft:sea_lantern
fill 136 92 503 136 116 503 minecraft:black_concrete
fill 94 93 470 94 116 471 minecraft:black_concrete
fill 94 93 482 94 116 483 minecraft:black_concrete
fill 94 93 494 94 116 495 minecraft:black_concrete
fill 95 93 505 96 116 505 minecraft:black_concrete
fill 102 93 463 103 116 463 minecraft:black_concrete
fill 107 93 505 108 116 505 minecraft:black_concrete
fill 114 93 463 115 112 463 minecraft:black_concrete
fill 119 93 505 120 112 505 minecraft:black_concrete
fill 126 93 463 127 116 463 minecraft:black_concrete
fill 131 93 505 132 116 505 minecraft:black_concrete
fill 136 93 465 136 114 466 minecraft:black_concrete
fill 136 93 477 136 116 478 minecraft:black_concrete
fill 136 93 489 136 116 490 minecraft:black_concrete
fill 136 93 501 136 112 502 minecraft:black_concrete
fill 96 95 469 96 95 471 minecraft:cyan_concrete
setblock 97 95 466 minecraft:light[level=11]
fill 97 95 468 97 96 469 minecraft:cyan_concrete
fill 97 95 471 97 96 472 minecraft:cyan_concrete
setblock 97 95 474 minecraft:light[level=11]
setblock 97 95 482 minecraft:light[level=11]
setblock 97 95 490 minecraft:light[level=11]
setblock 97 95 498 minecraft:light[level=11]
fill 98 95 467 99 95 468 minecraft:cyan_concrete
fill 98 95 472 99 95 473 minecraft:cyan_concrete
fill 100 95 468 101 95 469 minecraft:cyan_concrete
fill 100 95 471 100 96 472 minecraft:cyan_concrete
fill 101 95 470 101 96 471 minecraft:cyan_concrete
fill 104 95 499 104 96 501 minecraft:cyan_concrete
setblock 105 95 466 minecraft:light[level=11]
setblock 105 95 474 minecraft:light[level=11]
setblock 105 95 482 minecraft:light[level=11]
setblock 105 95 490 minecraft:light[level=11]
fill 105 95 498 105 96 499 minecraft:cyan_concrete
fill 105 95 502 108 95 502 minecraft:cyan_concrete
fill 106 95 498 108 95 498 minecraft:cyan_concrete
fill 108 95 499 108 96 501 minecraft:cyan_concrete
setblock 109 95 500 minecraft:cyan_concrete
setblock 113 95 466 minecraft:light[level=11]
setblock 113 95 474 minecraft:light[level=11]
setblock 113 95 482 minecraft:light[level=11]
setblock 113 95 490 minecraft:light[level=11]
setblock 113 95 498 minecraft:light[level=11]
fill 117 95 469 118 95 471 minecraft:cyan_concrete
fill 118 95 467 119 95 468 minecraft:cyan_concrete
fill 118 95 472 123 95 472 minecraft:cyan_concrete
fill 119 95 466 122 95 466 minecraft:cyan_concrete
fill 119 95 471 119 97 471 minecraft:cyan_concrete
fill 119 95 473 122 95 473 minecraft:cyan_concrete
fill 120 95 467 123 95 467 minecraft:cyan_concrete
setblock 121 95 474 minecraft:light[level=11]
setblock 121 95 482 minecraft:light[level=11]
setblock 121 95 490 minecraft:light[level=11]
setblock 121 95 498 minecraft:light[level=11]
fill 123 95 468 124 95 471 minecraft:cyan_concrete
setblock 129 95 466 minecraft:light[level=11]
setblock 129 95 474 minecraft:light[level=11]
setblock 129 95 482 minecraft:light[level=11]
setblock 129 95 490 minecraft:light[level=11]
setblock 129 95 498 minecraft:light[level=11]
fill 98 96 468 100 96 468 minecraft:cyan_concrete
fill 98 96 472 99 97 472 minecraft:cyan_concrete
fill 100 96 469 101 96 469 minecraft:cyan_concrete
fill 105 96 502 107 96 502 minecraft:cyan_concrete
fill 106 96 498 107 96 498 minecraft:cyan_concrete
fill 118 96 468 118 96 471 minecraft:cyan_concrete
fill 119 96 467 119 96 468 minecraft:cyan_concrete
fill 119 96 472 123 96 472 minecraft:cyan_concrete
fill 120 96 467 122 96 467 minecraft:cyan_concrete
fill 123 96 468 123 96 471 minecraft:cyan_concrete
fill 124 96 469 124 96 470 minecraft:cyan_concrete
setblock 97 97 469 minecraft:cyan_concrete
setblock 97 97 471 minecraft:cyan_concrete
fill 98 97 468 99 97 468 minecraft:cyan_concrete
setblock 100 97 469 minecraft:cyan_concrete
setblock 100 97 471 minecraft:cyan_concrete
setblock 105 97 499 minecraft:cyan_concrete
setblock 108 97 500 minecraft:cyan_concrete
setblock 118 97 470 minecraft:cyan_concrete
setblock 119 97 468 minecraft:cyan_concrete
fill 120 97 467 121 97 467 minecraft:cyan_concrete
fill 120 97 472 122 97 472 minecraft:cyan_concrete
fill 123 97 469 123 97 471 minecraft:cyan_concrete
setblock 97 103 466 minecraft:light[level=11]
setblock 97 103 474 minecraft:light[level=11]
setblock 97 103 482 minecraft:light[level=11]
setblock 97 103 490 minecraft:light[level=11]
setblock 97 103 498 minecraft:light[level=11]
setblock 105 103 466 minecraft:light[level=11]
setblock 105 103 474 minecraft:light[level=11]
setblock 105 103 482 minecraft:light[level=11]
setblock 105 103 490 minecraft:light[level=11]
setblock 105 103 498 minecraft:light[level=11]
fill 111 103 485 116 103 485 minecraft:sea_lantern
fill 112 103 481 115 103 481 minecraft:sea_lantern
fill 112 103 486 115 103 486 minecraft:sea_lantern
setblock 113 103 466 minecraft:light[level=11]
setblock 113 103 474 minecraft:light[level=11]
setblock 113 103 490 minecraft:light[level=11]
setblock 113 103 498 minecraft:light[level=11]
fill 114 103 482 116 103 484 minecraft:sea_lantern
setblock 121 103 466 minecraft:light[level=11]
setblock 121 103 474 minecraft:light[level=11]
setblock 121 103 482 minecraft:light[level=11]
setblock 121 103 490 minecraft:light[level=11]
setblock 121 103 498 minecraft:light[level=11]
setblock 129 103 466 minecraft:light[level=11]
setblock 129 103 474 minecraft:light[level=11]
setblock 129 103 482 minecraft:light[level=11]
setblock 129 103 490 minecraft:light[level=11]
setblock 129 103 498 minecraft:light[level=11]
fill 110 104 482 110 104 485 minecraft:sea_lantern
setblock 111 104 481 minecraft:sea_lantern
fill 111 104 485 116 108 485 minecraft:cyan_concrete
setblock 111 104 486 minecraft:sea_lantern
fill 112 104 480 115 104 480 minecraft:sea_lantern
fill 112 104 481 115 108 481 minecraft:cyan_concrete
fill 112 104 486 115 108 486 minecraft:cyan_concrete
fill 112 104 487 115 104 487 minecraft:sea_lantern
fill 114 104 482 116 110 484 minecraft:cyan_concrete
setblock 116 104 481 minecraft:sea_lantern
setblock 116 104 486 minecraft:sea_lantern
fill 117 104 482 117 104 485 minecraft:sea_lantern
fill 109 105 482 109 108 485 minecraft:sea_lantern
setblock 110 105 481 minecraft:sea_lantern
fill 110 105 482 110 110 485 minecraft:cyan_concrete
setblock 110 105 486 minecraft:sea_lantern
setblock 111 105 480 minecraft:sea_lantern
fill 111 105 481 111 110 481 minecraft:cyan_concrete
fill 111 105 486 111 110 486 minecraft:cyan_concrete
setblock 111 105 487 minecraft:sea_lantern
fill 112 105 479 115 108 479 minecraft:sea_lantern
fill 112 105 480 115 108 480 minecraft:cyan_concrete
fill 112 105 487 115 108 487 minecraft:cyan_concrete
fill 112 105 488 115 110 488 minecraft:sea_lantern
setblock 116 105 480 minecraft:sea_lantern
fill 116 105 481 116 108 481 minecraft:cyan_concrete
fill 116 105 486 116 108 486 minecraft:cyan_concrete
setblock 116 105 487 minecraft:sea_lantern
setblock 117 105 481 minecraft:sea_lantern
fill 117 105 482 117 108 485 minecraft:cyan_concrete
setblock 117 105 486 minecraft:sea_lantern
fill 118 105 482 118 110 485 minecraft:sea_lantern
fill 109 106 481 109 108 481 minecraft:sea_lantern
fill 109 106 486 109 108 486 minecraft:sea_lantern
fill 110 106 480 110 109 480 minecraft:sea_lantern
fill 110 106 481 110 109 481 minecraft:cyan_concrete
fill 110 106 486 110 109 486 minecraft:cyan_concrete
fill 110 106 487 110 109 487 minecraft:sea_lantern
fill 111 106 479 111 109 479 minecraft:sea_lantern
fill 111 106 480 111 109 480 minecraft:cyan_concrete
fill 111 106 487 111 109 487 minecraft:cyan_concrete
fill 111 106 488 111 109 488 minecraft:sea_lantern
fill 116 106 479 116 108 479 minecraft:sea_lantern
fill 116 106 480 116 108 480 minecraft:cyan_concrete
fill 116 106 487 116 108 487 minecraft:cyan_concrete
fill 116 106 488 116 109 488 minecraft:sea_lantern
fill 117 106 480 117 108 480 minecraft:sea_lantern
fill 117 106 481 117 108 481 minecraft:cyan_concrete
fill 117 106 486 117 108 486 minecraft:cyan_concrete
fill 117 106 487 117 108 487 minecraft:sea_lantern
fill 118 106 481 118 109 481 minecraft:sea_lantern
fill 118 106 486 118 109 486 minecraft:sea_lantern
fill 107 109 479 109 109 481 minecraft:redstone_block
fill 107 109 485 109 109 487 minecraft:redstone_block
fill 109 109 482 109 110 484 minecraft:sea_lantern
fill 111 109 485 114 110 485 minecraft:cyan_concrete
fill 112 109 479 114 110 479 minecraft:sea_lantern
fill 112 109 480 114 110 481 minecraft:cyan_concrete
fill 112 109 486 114 110 487 minecraft:cyan_concrete
fill 115 109 479 117 109 481 minecraft:redstone_block
fill 115 109 485 117 109 487 minecraft:redstone_block
fill 117 109 482 117 110 484 minecraft:cyan_concrete
fill 110 110 481 110 111 481 minecraft:sea_lantern
fill 110 110 486 110 111 486 minecraft:sea_lantern
setblock 111 110 480 minecraft:sea_lantern
setblock 111 110 487 minecraft:sea_lantern
fill 95 111 464 105 111 504 minecraft:deepslate_tiles
fill 106 111 464 135 111 477 minecraft:deepslate_tiles
fill 106 111 478 106 111 482 minecraft:sea_lantern
fill 106 111 483 109 111 483 minecraft:deepslate_tiles
fill 106 111 484 106 111 488 minecraft:sea_lantern
fill 106 111 489 135 111 504 minecraft:deepslate_tiles
fill 107 111 478 110 111 478 minecraft:sea_lantern
fill 107 111 479 109 111 481 minecraft:deepslate_tiles
fill 107 111 482 110 111 482 minecraft:sea_lantern
fill 107 111 484 110 111 484 minecraft:sea_lantern
fill 107 111 485 109 111 487 minecraft:deepslate_tiles
fill 107 111 488 110 111 488 minecraft:sea_lantern
fill 110 111 479 110 111 480 minecraft:sea_lantern
setblock 110 111 483 minecraft:sea_lantern
fill 110 111 485 114 111 485 minecraft:sea_lantern
setblock 110 111 487 minecraft:sea_lantern
fill 111 111 478 111 111 480 minecraft:deepslate_tiles
fill 111 111 481 114 111 481 minecraft:sea_lantern
setblock 111 111 486 minecraft:sea_lantern
fill 111 111 487 111 111 488 minecraft:deepslate_tiles
fill 112 111 478 113 111 479 minecraft:deepslate_tiles
fill 112 111 480 114 111 480 minecraft:sea_lantern
fill 112 111 486 113 111 486 minecraft:cyan_concrete
fill 112 111 487 114 111 487 minecraft:sea_lantern
fill 112 111 488 113 111 488 minecraft:deepslate_tiles
fill 114 111 478 114 111 479 minecraft:sea_lantern
fill 114 111 482 114 112 484 minecraft:sea_lantern
fill 114 111 486 114 112 486 minecraft:sea_lantern
fill 114 111 488 118 111 488 minecraft:sea_lantern
fill 115 111 478 118 111 478 minecraft:sea_lantern
fill 115 111 479 117 111 481 minecraft:deepslate_tiles
fill 115 111 482 118 111 482 minecraft:sea_lantern
fill 115 111 483 116 111 483 minecraft:cyan_concrete
fill 115 111 484 118 111 484 minecraft:sea_lantern
fill 115 111 485 117 111 487 minecraft:deepslate_tiles
setblock 117 111 483 minecraft:sea_lantern
fill 118 111 479 118 111 481 minecraft:sea_lantern
fill 118 111 483 135 111 483 minecraft:deepslate_tiles
fill 118 111 485 118 111 487 minecraft:sea_lantern
fill 119 111 478 135 111 482 minecraft:deepslate_tiles
fill 119 111 484 135 111 488 minecraft:deepslate_tiles
fill 111 112 485 116 112 485 minecraft:sea_lantern
fill 112 112 481 115 112 481 minecraft:sea_lantern
fill 112 112 486 113 112 486 minecraft:sea_lantern
fill 115 112 482 116 112 484 minecraft:sea_lantern
setblock 115 112 486 minecraft:sea_lantern
setblock 94 113 472 minecraft:sculk
fill 94 113 473 94 113 477 minecraft:black_concrete
fill 94 113 478 94 113 479 minecraft:sculk
setblock 94 113 480 minecraft:black_concrete
fill 94 113 485 94 114 489 minecraft:black_concrete
setblock 94 113 490 minecraft:sculk
fill 94 113 491 94 113 492 minecraft:black_concrete
fill 98 113 505 101 116 505 minecraft:black_concrete
setblock 102 113 505 minecraft:sculk
fill 103 113 505 105 116 505 minecraft:black_concrete
fill 105 113 463 107 116 463 minecraft:black_concrete
setblock 108 113 463 minecraft:sculk
fill 109 113 463 111 114 463 minecraft:black_concrete
fill 110 113 505 113 114 505 minecraft:black_concrete
fill 112 113 463 114 113 463 minecraft:sculk
setblock 114 113 505 minecraft:sculk
fill 115 113 463 115 116 463 minecraft:black_concrete
fill 115 113 505 117 114 505 minecraft:black_concrete
fill 117 113 463 120 113 463 minecraft:black_concrete
setblock 119 113 505 minecraft:black_concrete
setblock 120 113 505 minecraft:sculk
fill 121 113 463 122 113 463 minecraft:sculk
fill 122 113 505 122 116 505 minecraft:black_concrete
fill 123 113 463 124 114 463 minecraft:black_concrete
setblock 123 113 505 minecraft:sculk
fill 124 113 505 124 116 505 minecraft:black_concrete
fill 125 113 505 125 114 505 minecraft:sculk
fill 126 113 505 129 114 505 minecraft:black_concrete
fill 128 113 463 129 113 463 minecraft:sculk
fill 130 113 463 136 116 463 minecraft:black_concrete
setblock 136 113 464 minecraft:sculk
setblock 136 113 480 minecraft:sculk
fill 136 113 481 136 113 484 minecraft:black_concrete
setblock 136 113 485 minecraft:sculk
fill 136 113 486 136 114 487 minecraft:black_concrete
fill 136 113 501 136 113 502 minecraft:sculk
setblock 94 114 463 minecraft:sculk
fill 94 114 464 94 116 467 minecraft:black_concrete
setblock 94 114 468 minecraft:sculk
fill 94 114 472 94 116 473 minecraft:black_concrete
setblock 94 114 474 minecraft:sculk
fill 94 114 475 94 116 479 minecraft:black_concrete
setblock 94 114 480 minecraft:sculk
fill 94 114 490 94 116 491 minecraft:black_concrete
fill 94 114 492 94 114 493 minecraft:sculk
fill 102 114 505 102 116 505 minecraft:black_concrete
fill 108 114 463 108 116 463 minecraft:black_concrete
fill 112 114 463 114 114 463 minecraft:black_concrete
fill 114 114 505 114 116 505 minecraft:black_concrete
fill 117 114 463 117 116 463 minecraft:black_concrete
setblock 118 114 463 minecraft:sculk
fill 118 114 505 119 114 505 minecraft:sculk
fill 119 114 463 122 116 463 minecraft:black_concrete
fill 120 114 505 120 116 505 minecraft:black_concrete
fill 123 114 505 123 116 505 minecraft:black_concrete
fill 128 114 463 129 116 463 minecraft:black_concrete
fill 133 114 505 133 115 505 minecraft:sculk
fill 134 114 505 134 117 505 minecraft:black_concrete
setblock 135 114 505 minecraft:sculk
setblock 136 114 464 minecraft:black_concrete
fill 136 114 468 136 116 468 minecraft:black_concrete
fill 136 114 469 136 115 469 minecraft:sculk
fill 136 114 470 136 114 475 minecraft:black_concrete
fill 136 114 480 136 116 480 minecraft:black_concrete
setblock 136 114 481 minecraft:sculk
fill 136 114 482 136 116 485 minecraft:black_concrete
fill 136 114 492 136 114 496 minecraft:black_concrete
fill 136 114 497 136 115 497 minecraft:sculk
fill 136 114 498 136 116 499 minecraft:black_concrete
setblock 136 114 500 minecraft:sculk
fill 136 114 501 136 116 502 minecraft:black_concrete
fill 136 114 505 136 117 505 minecraft:black_concrete
fill 94 115 463 94 116 463 minecraft:black_concrete
fill 94 115 468 94 116 468 minecraft:black_concrete
fill 94 115 474 94 116 474 minecraft:black_concrete
fill 94 115 480 94 117 480 minecraft:black_concrete
fill 94 115 485 94 116 487 minecraft:black_concrete
setblock 94 115 488 minecraft:sculk
fill 94 115 489 94 116 489 minecraft:black_concrete
fill 94 115 492 94 116 492 minecraft:black_concrete
setblock 94 115 493 minecraft:sculk
fill 94 115 497 94 115 498 minecraft:sculk
fill 94 115 499 94 116 503 minecraft:black_concrete
setblock 94 115 504 minecraft:sculk
setblock 95 115 463 minecraft:sculk
fill 95 115 464 97 170 464 minecraft:deepslate_bricks
fill 95 115 474 95 170 476 minecraft:deepslate_bricks
fill 95 115 486 95 170 488 minecraft:deepslate_bricks
fill 95 115 498 95 170 500 minecraft:deepslate_bricks
fill 96 115 463 100 116 463 minecraft:black_concrete
fill 101 115 504 103 170 504 minecraft:deepslate_bricks
fill 103 115 464 111 117 468 minecraft:deepslate_bricks
setblock 106 115 505 minecraft:sculk
setblock 109 115 463 minecraft:sculk
fill 110 115 463 111 116 463 minecraft:black_concrete
fill 110 115 505 112 116 505 minecraft:black_concrete
setblock 112 115 463 minecraft:sculk
fill 113 115 463 114 116 463 minecraft:black_concrete
fill 113 115 504 115 170 504 minecraft:deepslate_bricks
setblock 113 115 505 minecraft:sculk
fill 115 115 505 116 116 505 minecraft:black_concrete
setblock 117 115 505 minecraft:sculk
fill 118 115 463 118 116 463 minecraft:black_concrete
fill 118 115 505 119 116 505 minecraft:black_concrete
fill 119 115 464 121 170 464 minecraft:deepslate_bricks
fill 123 115 463 123 116 463 minecraft:black_concrete
setblock 124 115 463 minecraft:sculk
fill 125 115 504 127 170 504 minecraft:deepslate_bricks
fill 125 115 505 127 116 505 minecraft:black_concrete
setblock 128 115 505 minecraft:sculk
fill 129 115 505 129 116 505 minecraft:black_concrete
setblock 130 115 505 minecraft:sculk
fill 131 115 464 133 170 464 minecraft:deepslate_bricks
fill 135 115 472 135 170 474 minecraft:deepslate_bricks
fill 135 115 484 135 170 486 minecraft:deepslate_bricks
fill 135 115 496 135 170 498 minecraft:deepslate_bricks
fill 135 115 505 135 116 505 minecraft:black_concrete
fill 136 115 464 136 115 465 minecraft:sculk
fill 136 115 466 136 116 466 minecraft:black_concrete
fill 136 115 470 136 116 471 minecraft:black_concrete
setblock 136 115 472 minecraft:sculk
fill 136 115 473 136 116 473 minecraft:black_concrete
setblock 136 115 474 minecraft:sculk
fill 136 115 475 136 116 475 minecraft:black_concrete
setblock 136 115 479 minecraft:sculk
fill 136 115 481 136 116 481 minecraft:black_concrete
fill 136 115 486 136 116 486 minecraft:black_concrete
setblock 136 115 487 minecraft:sculk
fill 136 115 492 136 116 492 minecraft:black_concrete
setblock 136 115 493 minecraft:sculk
fill 136 115 494 136 116 496 minecraft:black_concrete
fill 136 115 500 136 117 500 minecraft:black_concrete
setblock 94 116 488 minecraft:black_concrete
setblock 94 116 493 minecraft:black_concrete
fill 94 116 497 94 116 498 minecraft:black_concrete
fill 94 116 504 94 117 504 minecraft:black_concrete
setblock 95 116 463 minecraft:black_concrete
setblock 106 116 505 minecraft:black_concrete
setblock 109 116 463 minecraft:black_concrete
setblock 112 116 463 minecraft:black_concrete
setblock 113 116 505 minecraft:black_concrete
setblock 117 116 505 minecraft:black_concrete
setblock 124 116 463 minecraft:black_concrete
fill 128 116 505 128 117 505 minecraft:black_concrete
setblock 130 116 505 minecraft:black_concrete
fill 133 116 505 133 117 505 minecraft:black_concrete
fill 136 116 464 136 116 465 minecraft:black_concrete
setblock 136 116 469 minecraft:black_concrete
setblock 136 116 472 minecraft:black_concrete
setblock 136 116 474 minecraft:black_concrete
setblock 136 116 479 minecraft:black_concrete
setblock 136 116 487 minecraft:black_concrete
setblock 136 116 493 minecraft:black_concrete
setblock 136 116 497 minecraft:black_concrete
fill 94 117 463 94 117 476 minecraft:sculk
setblock 94 117 477 minecraft:black_concrete
fill 94 117 478 94 212 479 minecraft:sculk
fill 94 117 481 94 125 481 minecraft:sculk
setblock 94 117 482 minecraft:black_concrete
fill 94 117 483 94 117 498 minecraft:sculk
setblock 94 117 499 minecraft:black_concrete
fill 94 117 500 94 117 503 minecraft:sculk
fill 94 117 505 125 117 505 minecraft:sculk
fill 95 117 463 103 117 463 minecraft:sculk
fill 105 117 463 106 117 463 minecraft:black_concrete
fill 107 117 463 110 208 463 minecraft:sculk
setblock 111 117 463 minecraft:black_concrete
fill 112 117 463 127 117 463 minecraft:sculk
setblock 126 117 505 minecraft:black_concrete
fill 127 117 505 127 212 505 minecraft:sculk
setblock 128 117 463 minecraft:black_concrete
fill 129 117 463 133 117 463 minecraft:sculk
fill 129 117 505 132 117 505 minecraft:sculk
setblock 134 117 463 minecraft:black_concrete
fill 135 117 463 135 212 463 minecraft:sculk
fill 135 117 505 135 212 505 minecraft:sculk
setblock 136 117 463 minecraft:black_concrete
fill 136 117 464 136 117 481 minecraft:sculk
setblock 136 117 482 minecraft:black_concrete
fill 136 117 483 136 117 488 minecraft:sculk
setblock 136 117 489 minecraft:black_concrete
fill 136 117 490 136 117 499 minecraft:sculk
fill 136 117 501 136 117 504 minecraft:sculk
fill 94 118 463 95 118 463 minecraft:black_concrete
fill 94 118 464 94 118 470 minecraft:sculk
setblock 94 118 471 minecraft:black_concrete
fill 94 118 472 94 118 477 minecraft:sculk
setblock 94 118 480 minecraft:sculk
fill 94 118 482 94 125 488 minecraft:sculk
setblock 94 118 489 minecraft:black_concrete
fill 94 118 490 94 118 500 minecraft:sculk
setblock 94 118 501 minecraft:black_concrete
fill 94 118 502 94 125 505 minecraft:sculk
fill 95 118 505 101 118 505 minecraft:sculk
fill 96 118 463 104 118 463 minecraft:sculk
fill 102 118 505 102 119 505 minecraft:black_concrete
setblock 103 118 464 minecraft:sea_lantern
fill 103 118 465 103 134 465 minecraft:deepslate_bricks
setblock 103 118 466 minecraft:sea_lantern
fill 103 118 467 103 134 467 minecraft:deepslate_bricks
setblock 103 118 468 minecraft:sea_lantern
fill 103 118 505 112 118 505 minecraft:sculk
fill 104 118 464 104 124 464 minecraft:deepslate_bricks
setblock 104 118 465 minecraft:sea_lantern
fill 104 118 466 104 134 466 minecraft:deepslate_bricks
setblock 104 118 467 minecraft:sea_lantern
fill 104 118 468 104 134 468 minecraft:deepslate_bricks
setblock 105 118 463 minecraft:black_concrete
setblock 105 118 464 minecraft:sea_lantern
fill 105 118 465 105 134 465 minecraft:deepslate_bricks
setblock 105 118 466 minecraft:sea_lantern
fill 105 118 467 105 134 467 minecraft:deepslate_bricks
setblock 105 118 468 minecraft:sea_lantern
fill 106 118 463 106 209 463 minecraft:sculk
fill 106 118 464 106 134 464 minecraft:deepslate_bricks
setblock 106 118 465 minecraft:sea_lantern
fill 106 118 466 106 134 466 minecraft:deepslate_bricks
setblock 106 118 467 minecraft:sea_lantern
fill 106 118 468 106 134 468 minecraft:deepslate_bricks
setblock 107 118 464 minecraft:sea_lantern
fill 107 118 465 107 134 465 minecraft:deepslate_bricks
setblock 107 118 466 minecraft:sea_lantern
fill 107 118 467 107 134 467 minecraft:deepslate_bricks
setblock 107 118 468 minecraft:sea_lantern
fill 108 118 464 108 170 464 minecraft:deepslate_bricks
setblock 108 118 465 minecraft:sea_lantern
fill 108 118 466 108 134 466 minecraft:deepslate_bricks
setblock 108 118 467 minecraft:sea_lantern
fill 108 118 468 108 134 468 minecraft:deepslate_bricks
setblock 109 118 464 minecraft:sea_lantern
fill 109 118 465 109 134 465 minecraft:deepslate_bricks
setblock 109 118 466 minecraft:sea_lantern
fill 109 118 467 109 134 467 minecraft:deepslate_bricks
setblock 109 118 468 minecraft:sea_lantern
fill 110 118 464 110 134 464 minecraft:deepslate_bricks
setblock 110 118 465 minecraft:sea_lantern
fill 110 118 466 110 134 466 minecraft:deepslate_bricks
setblock 110 118 467 minecraft:sea_lantern
fill 110 118 468 110 134 468 minecraft:deepslate_bricks
fill 111 118 463 122 125 463 minecraft:sculk
setblock 111 118 464 minecraft:sea_lantern
fill 111 118 465 111 134 465 minecraft:deepslate_bricks
setblock 111 118 466 minecraft:sea_lantern
fill 111 118 467 111 134 467 minecraft:deepslate_bricks
setblock 111 118 468 minecraft:sea_lantern
setblock 113 118 505 minecraft:black_concrete
fill 114 118 505 115 210 505 minecraft:sculk
setblock 116 118 505 minecraft:black_concrete
fill 117 118 505 126 125 505 minecraft:sculk
setblock 123 118 463 minecraft:black_concrete
fill 124 118 463 131 118 463 minecraft:sculk
fill 128 118 505 129 210 505 minecraft:sculk
setblock 130 118 505 minecraft:black_concrete
fill 131 118 505 134 125 505 minecraft:sculk
setblock 132 118 463 minecraft:black_concrete
fill 133 118 463 134 212 463 minecraft:sculk
fill 136 118 463 136 118 465 minecraft:sculk
fill 136 118 466 136 118 467 minecraft:black_concrete
fill 136 118 468 136 208 468 minecraft:sculk
setblock 136 118 469 minecraft:black_concrete
fill 136 118 470 136 118 482 minecraft:sculk
setblock 136 118 483 minecraft:black_concrete
fill 136 118 484 136 125 494 minecraft:sculk
setblock 136 118 495 minecraft:black_concrete
fill 136 118 496 136 125 500 minecraft:sculk
setblock 136 118 501 minecraft:black_concrete
fill 136 118 502 136 125 505 minecraft:sculk
fill 94 119 463 94 208 468 minecraft:sculk
setblock 94 119 469 minecraft:black_concrete
fill 94 119 470 94 125 471 minecraft:sculk
setblock 94 119 472 minecraft:black_concrete
fill 94 119 473 94 210 477 minecraft:sculk
setblock 94 119 480 minecraft:black_concrete
fill 94 119 489 94 125 499 minecraft:sculk
setblock 94 119 500 minecraft:black_concrete
fill 94 119 501 94 212 501 minecraft:sculk
fill 95 119 463 98 212 463 minecraft:sculk
setblock 95 119 505 minecraft:black_concrete
fill 96 119 505 99 125 505 minecraft:sculk
setblock 97 119 466 minecraft:light[level=11]
setblock 97 119 474 minecraft:light[level=11]
setblock 97 119 482 minecraft:light[level=11]
setblock 97 119 490 minecraft:light[level=11]
setblock 97 119 498 minecraft:light[level=11]
setblock 99 119 463 minecraft:black_concrete
fill 100 119 463 105 125 463 minecraft:sculk
setblock 100 119 505 minecraft:black_concrete
fill 101 119 505 101 212 505 minecraft:sculk
fill 103 119 464 103 120 464 minecraft:deepslate_bricks
fill 103 119 466 103 120 466 minecraft:deepslate_bricks
fill 103 119 468 103 120 468 minecraft:deepslate_bricks
fill 103 119 505 104 210 505 minecraft:sculk
fill 104 119 465 104 120 465 minecraft:deepslate_bricks
fill 104 119 467 104 120 467 minecraft:deepslate_bricks
fill 105 119 464 105 120 464 minecraft:deepslate_bricks
fill 105 119 466 105 120 466 minecraft:deepslate_bricks
fill 105 119 468 105 120 468 minecraft:deepslate_bricks
setblock 105 119 474 minecraft:light[level=11]
setblock 105 119 482 minecraft:light[level=11]
setblock 105 119 490 minecraft:light[level=11]
setblock 105 119 498 minecraft:light[level=11]
fill 105 119 505 106 119 505 minecraft:black_concrete
fill 106 119 465 106 120 465 minecraft:deepslate_bricks
fill 106 119 467 106 120 467 minecraft:deepslate_bricks
fill 107 119 464 107 120 464 minecraft:deepslate_bricks
fill 107 119 466 107 120 466 minecraft:deepslate_bricks
fill 107 119 468 107 120 468 minecraft:deepslate_bricks
fill 107 119 505 111 125 505 minecraft:sculk
fill 108 119 465 108 120 465 minecraft:deepslate_bricks
fill 108 119 467 108 120 467 minecraft:deepslate_bricks
fill 109 119 464 109 120 464 minecraft:deepslate_bricks
fill 109 119 466 109 120 466 minecraft:deepslate_bricks
fill 109 119 468 109 120 468 minecraft:deepslate_bricks
fill 110 119 465 110 120 465 minecraft:deepslate_bricks
fill 110 119 467 110 120 467 minecraft:deepslate_bricks
fill 111 119 464 111 120 464 minecraft:deepslate_bricks
fill 111 119 466 111 120 466 minecraft:deepslate_bricks
fill 111 119 468 111 120 468 minecraft:deepslate_bricks
setblock 112 119 505 minecraft:black_concrete
setblock 113 119 466 minecraft:light[level=11]
setblock 113 119 474 minecraft:light[level=11]
setblock 113 119 482 minecraft:light[level=11]
setblock 113 119 490 minecraft:light[level=11]
setblock 113 119 498 minecraft:light[level=11]
fill 113 119 505 113 212 505 minecraft:sculk
fill 116 119 505 116 212 505 minecraft:sculk
setblock 121 119 466 minecraft:light[level=11]
setblock 121 119 474 minecraft:light[level=11]
setblock 121 119 482 minecraft:light[level=11]
setblock 121 119 490 minecraft:light[level=11]
setblock 121 119 498 minecraft:light[level=11]
fill 123 119 463 125 125 463 minecraft:sculk
setblock 126 119 463 minecraft:black_concrete
fill 127 119 463 132 125 463 minecraft:sculk
setblock 129 119 466 minecraft:light[level=11]
setblock 129 119 474 minecraft:light[level=11]
setblock 129 119 482 minecraft:light[level=11]
setblock 129 119 490 minecraft:light[level=11]
setblock 129 119 498 minecraft:light[level=11]
fill 130 119 505 130 125 505 minecraft:sculk
fill 136 119 463 136 125 464 minecraft:sculk
setblock 136 119 465 minecraft:black_concrete
fill 136 119 466 136 125 467 minecraft:sculk
fill 136 119 469 136 125 477 minecraft:sculk
setblock 136 119 478 minecraft:black_concrete
fill 136 119 479 136 125 483 minecraft:sculk
fill 136 119 495 136 212 495 minecraft:sculk
fill 136 119 501 136 125 501 minecraft:sculk
fill 94 120 469 94 125 469 minecraft:sculk
fill 94 120 472 94 125 472 minecraft:sculk
fill 94 120 480 94 212 480 minecraft:sculk
fill 94 120 500 94 208 500 minecraft:sculk
fill 95 120 505 95 125 505 minecraft:sculk
fill 96 120 473 96 125 475 minecraft:deepslate_bricks
fill 96 120 485 96 125 487 minecraft:deepslate_bricks
fill 96 120 497 96 125 499 minecraft:deepslate_bricks
fill 99 120 463 99 212 463 minecraft:sculk
fill 100 120 485 100 121 485 minecraft:cyan_concrete
fill 100 120 505 100 210 505 minecraft:sculk
fill 102 120 503 104 125 503 minecraft:deepslate_bricks
fill 102 120 505 102 213 505 minecraft:sculk
fill 105 120 505 106 125 505 minecraft:sculk
fill 112 120 505 112 210 505 minecraft:sculk
fill 114 120 503 116 125 503 minecraft:deepslate_bricks
fill 118 120 465 120 125 465 minecraft:deepslate_bricks
fill 126 120 463 126 125 463 minecraft:sculk
fill 126 120 503 128 125 503 minecraft:deepslate_bricks
fill 130 120 465 132 125 465 minecraft:deepslate_bricks
fill 134 120 473 134 125 475 minecraft:deepslate_bricks
fill 134 120 485 134 125 487 minecraft:deepslate_bricks
fill 134 120 497 134 125 499 minecraft:deepslate_bricks
fill 136 120 465 136 125 465 minecraft:sculk
fill 136 120 478 136 125 478 minecraft:sculk
fill 95 121 485 95 122 485 minecraft:cyan_concrete
fill 97 121 485 99 121 485 minecraft:cyan_concrete
setblock 103 121 464 minecraft:sea_lantern
setblock 103 121 466 minecraft:sea_lantern
setblock 103 121 468 minecraft:sea_lantern
setblock 104 121 465 minecraft:sea_lantern
setblock 104 121 467 minecraft:sea_lantern
setblock 105 121 464 minecraft:sea_lantern
setblock 105 121 466 minecraft:sea_lantern
setblock 105 121 468 minecraft:sea_lantern
setblock 106 121 465 minecraft:sea_lantern
setblock 106 121 467 minecraft:sea_lantern
setblock 107 121 464 minecraft:sea_lantern
setblock 107 121 466 minecraft:sea_lantern
setblock 107 121 468 minecraft:sea_lantern
setblock 108 121 465 minecraft:sea_lantern
setblock 108 121 467 minecraft:sea_lantern
setblock 109 121 464 minecraft:sea_lantern
setblock 109 121 466 minecraft:sea_lantern
setblock 109 121 468 minecraft:sea_lantern
setblock 110 121 465 minecraft:sea_lantern
setblock 110 121 467 minecraft:sea_lantern
setblock 111 121 464 minecraft:sea_lantern
setblock 111 121 466 minecraft:sea_lantern
setblock 111 121 468 minecraft:sea_lantern
setblock 97 122 485 minecraft:cyan_concrete
fill 103 122 464 103 123 464 minecraft:deepslate_bricks
fill 103 122 466 103 123 466 minecraft:deepslate_bricks
fill 103 122 468 103 123 468 minecraft:deepslate_bricks
fill 104 122 465 104 123 465 minecraft:deepslate_bricks
fill 104 122 467 104 123 467 minecraft:deepslate_bricks
fill 105 122 464 105 123 464 minecraft:deepslate_bricks
fill 105 122 466 105 123 466 minecraft:deepslate_bricks
fill 105 122 468 105 123 468 minecraft:deepslate_bricks
fill 106 122 465 106 123 465 minecraft:deepslate_bricks
fill 106 122 467 106 123 467 minecraft:deepslate_bricks
fill 107 122 464 107 123 464 minecraft:deepslate_bricks
fill 107 122 466 107 123 466 minecraft:deepslate_bricks
fill 107 122 468 107 123 468 minecraft:deepslate_bricks
fill 108 122 465 108 123 465 minecraft:deepslate_bricks
fill 108 122 467 108 123 467 minecraft:deepslate_bricks
fill 109 122 464 109 123 464 minecraft:deepslate_bricks
fill 109 122 466 109 123 466 minecraft:deepslate_bricks
fill 109 122 468 109 123 468 minecraft:deepslate_bricks
fill 110 122 465 110 123 465 minecraft:deepslate_bricks
fill 110 122 467 110 123 467 minecraft:deepslate_bricks
fill 111 122 464 111 123 464 minecraft:deepslate_bricks
fill 111 122 466 111 123 466 minecraft:deepslate_bricks
fill 111 122 468 111 123 468 minecraft:deepslate_bricks
setblock 103 124 464 minecraft:sea_lantern
setblock 103 124 466 minecraft:sea_lantern
setblock 103 124 468 minecraft:sea_lantern
setblock 104 124 465 minecraft:sea_lantern
setblock 104 124 467 minecraft:sea_lantern
setblock 105 124 464 minecraft:sea_lantern
setblock 105 124 466 minecraft:sea_lantern
setblock 105 124 468 minecraft:sea_lantern
setblock 106 124 465 minecraft:sea_lantern
setblock 106 124 467 minecraft:sea_lantern
setblock 107 124 464 minecraft:sea_lantern
setblock 107 124 466 minecraft:sea_lantern
setblock 107 124 468 minecraft:sea_lantern
setblock 108 124 465 minecraft:sea_lantern
setblock 108 124 467 minecraft:sea_lantern
setblock 109 124 464 minecraft:sea_lantern
setblock 109 124 466 minecraft:sea_lantern
setblock 109 124 468 minecraft:sea_lantern
setblock 110 124 465 minecraft:sea_lantern
setblock 110 124 467 minecraft:sea_lantern
setblock 111 124 464 minecraft:sea_lantern
setblock 111 124 466 minecraft:sea_lantern
setblock 111 124 468 minecraft:sea_lantern
fill 95 125 467 95 125 472 minecraft:sculk
fill 95 125 479 95 125 484 minecraft:sculk
fill 95 125 491 95 125 496 minecraft:sculk
fill 95 125 503 95 125 504 minecraft:sculk
fill 96 125 504 99 125 504 minecraft:sculk
fill 99 125 464 104 125 464 minecraft:sculk
fill 103 125 466 103 126 466 minecraft:deepslate_bricks
fill 103 125 468 103 126 468 minecraft:deepslate_bricks
fill 104 125 465 104 126 465 minecraft:deepslate_bricks
fill 104 125 467 104 126 467 minecraft:deepslate_bricks
fill 105 125 464 105 126 464 minecraft:deepslate_bricks
fill 105 125 466 105 126 466 minecraft:deepslate_bricks
fill 105 125 468 105 126 468 minecraft:deepslate_bricks
fill 106 125 465 106 126 465 minecraft:deepslate_bricks
fill 106 125 467 106 126 467 minecraft:deepslate_bricks
fill 106 125 504 111 125 504 minecraft:sculk
fill 107 125 464 107 126 464 minecraft:deepslate_bricks
fill 107 125 466 107 126 466 minecraft:deepslate_bricks
fill 107 125 468 107 126 468 minecraft:deepslate_bricks
fill 108 125 465 108 126 465 minecraft:deepslate_bricks
fill 108 125 467 108 126 467 minecraft:deepslate_bricks
fill 109 125 464 109 126 464 minecraft:deepslate_bricks
fill 109 125 466 109 126 466 minecraft:deepslate_bricks
fill 109 125 468 109 126 468 minecraft:deepslate_bricks
fill 110 125 465 110 126 465 minecraft:deepslate_bricks
fill 110 125 467 110 126 467 minecraft:deepslate_bricks
fill 111 125 464 116 125 464 minecraft:sculk
fill 111 125 466 111 126 466 minecraft:deepslate_bricks
fill 111 125 468 111 126 468 minecraft:deepslate_bricks
fill 118 125 504 123 125 504 minecraft:sculk
fill 123 125 464 128 125 464 minecraft:sculk
fill 130 125 504 135 125 504 minecraft:sculk
fill 135 125 464 135 125 469 minecraft:sculk
fill 135 125 476 135 125 481 minecraft:sculk
fill 135 125 488 135 125 493 minecraft:sculk
fill 135 125 500 135 125 503 minecraft:sculk
fill 94 126 469 94 131 472 minecraft:sea_lantern
fill 94 126 481 94 131 484 minecraft:sea_lantern
fill 94 126 485 94 209 492 minecraft:sculk
fill 94 126 493 94 131 496 minecraft:sea_lantern
fill 94 126 497 94 208 499 minecraft:sculk
fill 94 126 502 94 209 504 minecraft:sculk
fill 94 126 505 97 131 505 minecraft:sea_lantern
fill 98 126 505 99 212 505 minecraft:sculk
fill 100 126 463 100 210 463 minecraft:sculk
fill 101 126 463 104 131 463 minecraft:sea_lantern
fill 103 126 464 104 126 464 minecraft:deepslate_bricks
fill 105 126 463 105 210 463 minecraft:sculk
fill 105 126 505 105 212 505 minecraft:sculk
fill 106 126 505 109 131 505 minecraft:sea_lantern
fill 110 126 505 111 208 505 minecraft:sculk
fill 111 126 463 112 212 463 minecraft:sculk
setblock 111 126 464 minecraft:deepslate_bricks
fill 113 126 463 116 131 463 minecraft:sea_lantern
fill 117 126 463 124 209 463 minecraft:sculk
fill 117 126 505 117 212 505 minecraft:sculk
fill 118 126 505 121 131 505 minecraft:sea_lantern
fill 122 126 505 126 208 505 minecraft:sculk
fill 125 126 463 128 131 463 minecraft:sea_lantern
fill 129 126 463 132 208 463 minecraft:sculk
fill 130 126 505 133 131 505 minecraft:sea_lantern
fill 134 126 505 134 212 505 minecraft:sculk
fill 136 126 463 136 210 463 minecraft:sculk
fill 136 126 464 136 131 467 minecraft:sea_lantern
fill 136 126 469 136 209 475 minecraft:sculk
fill 136 126 476 136 131 479 minecraft:sea_lantern
fill 136 126 480 136 210 487 minecraft:sculk
fill 136 126 488 136 131 491 minecraft:sea_lantern
fill 136 126 492 136 210 494 minecraft:sculk
fill 136 126 496 136 208 499 minecraft:sculk
fill 136 126 500 136 131 503 minecraft:sea_lantern
fill 136 126 504 136 208 505 minecraft:sculk
setblock 97 127 466 minecraft:light[level=11]
setblock 97 127 474 minecraft:light[level=11]
setblock 97 127 482 minecraft:light[level=11]
setblock 97 127 490 minecraft:light[level=11]
setblock 97 127 498 minecraft:light[level=11]
setblock 103 127 464 minecraft:sea_lantern
setblock 103 127 466 minecraft:sea_lantern
setblock 103 127 468 minecraft:sea_lantern
fill 104 127 464 104 134 464 minecraft:deepslate_bricks
setblock 104 127 465 minecraft:sea_lantern
setblock 104 127 467 minecraft:sea_lantern
setblock 105 127 464 minecraft:sea_lantern
setblock 105 127 466 minecraft:sea_lantern
setblock 105 127 468 minecraft:sea_lantern
setblock 105 127 474 minecraft:light[level=11]
setblock 105 127 482 minecraft:light[level=11]
setblock 105 127 490 minecraft:light[level=11]
setblock 105 127 498 minecraft:light[level=11]
setblock 106 127 465 minecraft:sea_lantern
setblock 106 127 467 minecraft:sea_lantern
setblock 107 127 464 minecraft:sea_lantern
setblock 107 127 466 minecraft:sea_lantern
setblock 107 127 468 minecraft:sea_lantern
setblock 108 127 465 minecraft:sea_lantern
setblock 108 127 467 minecraft:sea_lantern
setblock 109 127 464 minecraft:sea_lantern
setblock 109 127 466 minecraft:sea_lantern
setblock 109 127 468 minecraft:sea_lantern
setblock 110 127 465 minecraft:sea_lantern
setblock 110 127 467 minecraft:sea_lantern
setblock 111 127 464 minecraft:sea_lantern
setblock 111 127 466 minecraft:sea_lantern
setblock 111 127 468 minecraft:sea_lantern
setblock 113 127 466 minecraft:light[level=11]
setblock 113 127 474 minecraft:light[level=11]
setblock 113 127 482 minecraft:light[level=11]
setblock 113 127 490 minecraft:light[level=11]
setblock 113 127 498 minecraft:light[level=11]
setblock 121 127 466 minecraft:light[level=11]
setblock 121 127 474 minecraft:light[level=11]
setblock 121 127 482 minecraft:light[level=11]
setblock 121 127 490 minecraft:light[level=11]
setblock 121 127 498 minecraft:light[level=11]
fill 123 127 503 123 128 503 minecraft:cyan_concrete
setblock 129 127 466 minecraft:light[level=11]
setblock 129 127 474 minecraft:light[level=11]
setblock 129 127 482 minecraft:light[level=11]
setblock 129 127 490 minecraft:light[level=11]
setblock 129 127 498 minecraft:light[level=11]
fill 103 128 464 103 129 464 minecraft:deepslate_bricks
fill 103 128 466 103 129 466 minecraft:deepslate_bricks
fill 103 128 468 103 129 468 minecraft:deepslate_bricks
fill 104 128 465 104 129 465 minecraft:deepslate_bricks
fill 104 128 467 104 129 467 minecraft:deepslate_bricks
fill 105 128 464 105 129 464 minecraft:deepslate_bricks
fill 105 128 466 105 129 466 minecraft:deepslate_bricks
fill 105 128 468 105 129 468 minecraft:deepslate_bricks
fill 106 128 465 106 129 465 minecraft:deepslate_bricks
fill 106 128 467 106 129 467 minecraft:deepslate_bricks
fill 107 128 464 107 129 464 minecraft:deepslate_bricks
fill 107 128 466 107 129 466 minecraft:deepslate_bricks
fill 107 128 468 107 129 468 minecraft:deepslate_bricks
fill 108 128 465 108 129 465 minecraft:deepslate_bricks
fill 108 128 467 108 129 467 minecraft:deepslate_bricks
fill 109 128 464 109 129 464 minecraft:deepslate_bricks
fill 109 128 466 109 129 466 minecraft:deepslate_bricks
fill 109 128 468 109 129 468 minecraft:deepslate_bricks
fill 110 128 465 110 129 465 minecraft:deepslate_bricks
fill 110 128 467 110 129 467 minecraft:deepslate_bricks
fill 111 128 464 111 129 464 minecraft:deepslate_bricks
fill 111 128 466 111 129 466 minecraft:deepslate_bricks
fill 111 128 468 111 129 468 minecraft:deepslate_bricks
fill 123 128 501 123 128 502 minecraft:cyan_concrete
fill 100 129 467 100 148 467 minecraft:reinforced_deepslate
fill 123 129 499 123 129 501 minecraft:cyan_concrete
setblock 103 130 464 minecraft:sea_lantern
setblock 103 130 466 minecraft:sea_lantern
setblock 103 130 468 minecraft:sea_lantern
setblock 104 130 465 minecraft:sea_lantern
setblock 104 130 467 minecraft:sea_lantern
setblock 105 130 464 minecraft:sea_lantern
setblock 105 130 466 minecraft:sea_lantern
setblock 105 130 468 minecraft:sea_lantern
setblock 106 130 465 minecraft:sea_lantern
setblock 106 130 467 minecraft:sea_lantern
setblock 107 130 464 minecraft:sea_lantern
setblock 107 130 466 minecraft:sea_lantern
setblock 107 130 468 minecraft:sea_lantern
setblock 108 130 465 minecraft:sea_lantern
setblock 108 130 467 minecraft:sea_lantern
setblock 109 130 464 minecraft:sea_lantern
setblock 109 130 466 minecraft:sea_lantern
setblock 109 130 468 minecraft:sea_lantern
setblock 110 130 465 minecraft:sea_lantern
setblock 110 130 467 minecraft:sea_lantern
setblock 111 130 464 minecraft:sea_lantern
setblock 111 130 466 minecraft:sea_lantern
setblock 111 130 468 minecraft:sea_lantern
fill 123 130 498 123 130 500 minecraft:cyan_concrete
fill 103 131 464 103 132 464 minecraft:deepslate_bricks
fill 103 131 466 103 132 466 minecraft:deepslate_bricks
fill 103 131 468 103 132 468 minecraft:deepslate_bricks
fill 104 131 465 104 132 465 minecraft:deepslate_bricks
fill 104 131 467 104 132 467 minecraft:deepslate_bricks
fill 105 131 464 105 132 464 minecraft:deepslate_bricks
fill 105 131 466 105 132 466 minecraft:deepslate_bricks
fill 105 131 468 105 132 468 minecraft:deepslate_bricks
fill 106 131 465 106 132 465 minecraft:deepslate_bricks
fill 106 131 467 106 132 467 minecraft:deepslate_bricks
fill 107 131 464 107 132 464 minecraft:deepslate_bricks
fill 107 131 466 107 132 466 minecraft:deepslate_bricks
fill 107 131 468 107 132 468 minecraft:deepslate_bricks
fill 108 131 465 108 132 465 minecraft:deepslate_bricks
fill 108 131 467 108 132 467 minecraft:deepslate_bricks
fill 109 131 464 109 132 464 minecraft:deepslate_bricks
fill 109 131 466 109 132 466 minecraft:deepslate_bricks
fill 109 131 468 109 132 468 minecraft:deepslate_bricks
fill 110 131 465 110 132 465 minecraft:deepslate_bricks
fill 110 131 467 110 132 467 minecraft:deepslate_bricks
fill 111 131 464 111 132 464 minecraft:deepslate_bricks
fill 111 131 466 111 132 466 minecraft:deepslate_bricks
fill 111 131 468 111 132 468 minecraft:deepslate_bricks
fill 94 132 469 94 145 469 minecraft:sculk
fill 94 132 470 94 132 471 minecraft:sea_lantern
fill 94 132 472 94 145 472 minecraft:sculk
fill 94 132 481 94 145 481 minecraft:sculk
fill 94 132 482 94 132 483 minecraft:sea_lantern
fill 94 132 484 94 145 484 minecraft:sculk
fill 94 132 493 94 145 493 minecraft:sculk
fill 94 132 494 94 132 495 minecraft:sea_lantern
fill 94 132 496 94 145 496 minecraft:sculk
fill 94 132 505 94 145 505 minecraft:sculk
fill 95 132 505 96 132 505 minecraft:sea_lantern
fill 97 132 505 97 145 505 minecraft:sculk
fill 101 132 463 101 145 463 minecraft:sculk
fill 102 132 463 103 132 463 minecraft:sea_lantern
fill 104 132 463 104 145 463 minecraft:sculk
fill 106 132 505 106 145 505 minecraft:sculk
fill 107 132 505 108 132 505 minecraft:sea_lantern
fill 109 132 505 109 145 505 minecraft:sculk
fill 113 132 463 113 145 463 minecraft:sculk
fill 114 132 463 115 132 463 minecraft:sea_lantern
fill 116 132 463 116 145 463 minecraft:sculk
fill 118 132 505 118 145 505 minecraft:sculk
fill 119 132 505 120 132 505 minecraft:sea_lantern
fill 121 132 505 121 145 505 minecraft:sculk
fill 125 132 463 125 145 463 minecraft:sculk
fill 126 132 463 127 132 463 minecraft:sea_lantern
fill 128 132 463 128 145 463 minecraft:sculk
fill 130 132 505 130 145 505 minecraft:sculk
fill 131 132 505 132 132 505 minecraft:sea_lantern
fill 133 132 505 133 145 505 minecraft:sculk
fill 136 132 464 136 145 464 minecraft:sculk
fill 136 132 465 136 132 466 minecraft:sea_lantern
fill 136 132 467 136 145 467 minecraft:sculk
fill 136 132 476 136 145 476 minecraft:sculk
fill 136 132 477 136 132 478 minecraft:sea_lantern
fill 136 132 479 136 145 479 minecraft:sculk
fill 136 132 488 136 145 488 minecraft:sculk
fill 136 132 489 136 132 490 minecraft:sea_lantern
fill 136 132 491 136 145 491 minecraft:sculk
fill 136 132 500 136 145 500 minecraft:sculk
fill 136 132 501 136 132 502 minecraft:sea_lantern
fill 136 132 503 136 145 503 minecraft:sculk
fill 94 133 470 94 145 471 minecraft:sculk
fill 94 133 482 94 145 483 minecraft:sculk
fill 94 133 494 94 145 495 minecraft:sculk
fill 95 133 505 96 145 505 minecraft:sculk
fill 102 133 463 103 145 463 minecraft:sculk
setblock 103 133 464 minecraft:sea_lantern
setblock 103 133 466 minecraft:sea_lantern
setblock 103 133 468 minecraft:sea_lantern
setblock 104 133 465 minecraft:sea_lantern
setblock 104 133 467 minecraft:sea_lantern
setblock 105 133 464 minecraft:sea_lantern
setblock 105 133 466 minecraft:sea_lantern
setblock 105 133 468 minecraft:sea_lantern
setblock 106 133 465 minecraft:sea_lantern
setblock 106 133 467 minecraft:sea_lantern
setblock 107 133 464 minecraft:sea_lantern
setblock 107 133 466 minecraft:sea_lantern
setblock 107 133 468 minecraft:sea_lantern
fill 107 133 505 108 145 505 minecraft:sculk
setblock 108 133 465 minecraft:sea_lantern
setblock 108 133 467 minecraft:sea_lantern
setblock 109 133 464 minecraft:sea_lantern
setblock 109 133 466 minecraft:sea_lantern
setblock 109 133 468 minecraft:sea_lantern
setblock 110 133 465 minecraft:sea_lantern
setblock 110 133 467 minecraft:sea_lantern
setblock 111 133 464 minecraft:sea_lantern
setblock 111 133 466 minecraft:sea_lantern
setblock 111 133 468 minecraft:sea_lantern
fill 114 133 463 115 145 463 minecraft:sculk
fill 119 133 505 120 145 505 minecraft:sculk
fill 126 133 463 127 145 463 minecraft:sculk
fill 131 133 505 132 145 505 minecraft:sculk
fill 136 133 465 136 145 466 minecraft:sculk
fill 136 133 477 136 145 478 minecraft:sculk
fill 136 133 489 136 145 490 minecraft:sculk
fill 136 133 501 136 145 502 minecraft:sculk
setblock 103 134 464 minecraft:deepslate_bricks
setblock 103 134 466 minecraft:deepslate_bricks
setblock 103 134 468 minecraft:deepslate_bricks
setblock 104 134 465 minecraft:deepslate_bricks
setblock 104 134 467 minecraft:deepslate_bricks
setblock 105 134 464 minecraft:deepslate_bricks
setblock 105 134 466 minecraft:deepslate_bricks
setblock 105 134 468 minecraft:deepslate_bricks
setblock 106 134 465 minecraft:deepslate_bricks
setblock 106 134 467 minecraft:deepslate_bricks
fill 107 134 464 107 170 464 minecraft:deepslate_bricks
setblock 107 134 466 minecraft:deepslate_bricks
setblock 107 134 468 minecraft:deepslate_bricks
setblock 108 134 465 minecraft:deepslate_bricks
setblock 108 134 467 minecraft:deepslate_bricks
fill 109 134 464 109 170 464 minecraft:deepslate_bricks
setblock 109 134 466 minecraft:deepslate_bricks
setblock 109 134 468 minecraft:deepslate_bricks
setblock 110 134 465 minecraft:deepslate_bricks
setblock 110 134 467 minecraft:deepslate_bricks
setblock 111 134 464 minecraft:deepslate_bricks
setblock 111 134 466 minecraft:deepslate_bricks
setblock 111 134 468 minecraft:deepslate_bricks
fill 116 134 498 116 134 499 minecraft:cyan_concrete
setblock 97 135 466 minecraft:light[level=11]
setblock 97 135 474 minecraft:light[level=11]
setblock 97 135 482 minecraft:light[level=11]
setblock 97 135 490 minecraft:light[level=11]
setblock 97 135 498 minecraft:light[level=11]
fill 104 135 465 110 135 467 minecraft:cyan_concrete
setblock 105 135 474 minecraft:light[level=11]
setblock 105 135 482 minecraft:light[level=11]
setblock 105 135 490 minecraft:light[level=11]
setblock 105 135 498 minecraft:light[level=11]
setblock 113 135 466 minecraft:light[level=11]
setblock 113 135 474 minecraft:light[level=11]
setblock 113 135 482 minecraft:light[level=11]
setblock 113 135 490 minecraft:light[level=11]
setblock 113 135 498 minecraft:light[level=11]
fill 116 135 499 116 135 500 minecraft:cyan_concrete
setblock 121 135 466 minecraft:light[level=11]
setblock 121 135 474 minecraft:light[level=11]
setblock 121 135 482 minecraft:light[level=11]
setblock 121 135 490 minecraft:light[level=11]
setblock 121 135 498 minecraft:light[level=11]
setblock 129 135 466 minecraft:light[level=11]
setblock 129 135 474 minecraft:light[level=11]
setblock 129 135 482 minecraft:light[level=11]
setblock 129 135 490 minecraft:light[level=11]
setblock 129 135 498 minecraft:light[level=11]
fill 105 136 466 109 136 466 minecraft:cyan_concrete
fill 116 136 500 116 136 502 minecraft:cyan_concrete
fill 106 137 465 108 137 467 minecraft:cyan_concrete
fill 116 137 501 116 137 503 minecraft:cyan_concrete
fill 107 138 465 107 138 468 minecraft:cyan_concrete
setblock 116 138 503 minecraft:cyan_concrete
fill 96 140 473 96 145 475 minecraft:deepslate_bricks
fill 96 140 485 96 145 487 minecraft:deepslate_bricks
fill 96 140 497 96 145 499 minecraft:deepslate_bricks
fill 102 140 503 104 145 503 minecraft:deepslate_bricks
fill 106 140 465 108 145 465 minecraft:deepslate_bricks
fill 114 140 503 116 145 503 minecraft:deepslate_bricks
fill 118 140 465 120 145 465 minecraft:deepslate_bricks
fill 126 140 503 128 145 503 minecraft:deepslate_bricks
fill 130 140 465 132 145 465 minecraft:deepslate_bricks
fill 134 140 473 134 145 475 minecraft:deepslate_bricks
fill 134 140 485 134 145 487 minecraft:deepslate_bricks
fill 134 140 497 134 145 499 minecraft:deepslate_bricks
setblock 97 143 466 minecraft:light[level=11]
setblock 97 143 474 minecraft:light[level=11]
setblock 97 143 482 minecraft:light[level=11]
setblock 97 143 490 minecraft:light[level=11]
setblock 97 143 498 minecraft:light[level=11]
setblock 105 143 466 minecraft:light[level=11]
setblock 105 143 474 minecraft:light[level=11]
setblock 105 143 482 minecraft:light[level=11]
setblock 105 143 490 minecraft:light[level=11]
setblock 105 143 498 minecraft:light[level=11]
setblock 113 143 466 minecraft:light[level=11]
setblock 113 143 474 minecraft:light[level=11]
setblock 113 143 482 minecraft:light[level=11]
setblock 113 143 490 minecraft:light[level=11]
setblock 113 143 498 minecraft:light[level=11]
setblock 121 143 466 minecraft:light[level=11]
setblock 121 143 474 minecraft:light[level=11]
setblock 121 143 482 minecraft:light[level=11]
setblock 121 143 490 minecraft:light[level=11]
setblock 121 143 498 minecraft:light[level=11]
setblock 129 143 466 minecraft:light[level=11]
setblock 129 143 474 minecraft:light[level=11]
setblock 129 143 482 minecraft:light[level=11]
setblock 129 143 490 minecraft:light[level=11]
setblock 129 143 498 minecraft:light[level=11]
fill 95 145 467 95 145 472 minecraft:sculk
fill 95 145 479 95 145 484 minecraft:sculk
fill 95 145 491 95 145 496 minecraft:sculk
fill 95 145 503 95 145 504 minecraft:sculk
fill 96 145 504 99 145 504 minecraft:sculk
fill 99 145 464 104 145 464 minecraft:sculk
fill 106 145 504 111 145 504 minecraft:sculk
fill 111 145 464 116 145 464 minecraft:sculk
fill 118 145 504 123 145 504 minecraft:sculk
fill 123 145 464 128 145 464 minecraft:sculk
fill 130 145 504 135 145 504 minecraft:sculk
fill 135 145 464 135 145 469 minecraft:sculk
fill 135 145 476 135 145 481 minecraft:sculk
fill 135 145 488 135 145 493 minecraft:sculk
fill 135 145 500 135 145 503 minecraft:sculk
fill 94 146 469 94 151 472 minecraft:sea_lantern
fill 94 146 481 94 151 484 minecraft:sea_lantern
fill 94 146 493 94 151 496 minecraft:sea_lantern
fill 94 146 505 97 151 505 minecraft:sea_lantern
fill 101 146 463 104 151 463 minecraft:sea_lantern
fill 106 146 505 109 151 505 minecraft:sea_lantern
fill 113 146 463 116 151 463 minecraft:sea_lantern
fill 118 146 505 121 151 505 minecraft:sea_lantern
fill 125 146 463 128 151 463 minecraft:sea_lantern
fill 130 146 505 133 151 505 minecraft:sea_lantern
fill 136 146 464 136 151 467 minecraft:sea_lantern
fill 136 146 476 136 151 479 minecraft:sea_lantern
fill 136 146 488 136 151 491 minecraft:sea_lantern
fill 136 146 500 136 151 503 minecraft:sea_lantern
setblock 97 151 466 minecraft:light[level=11]
setblock 97 151 474 minecraft:light[level=11]
setblock 97 151 482 minecraft:light[level=11]
setblock 97 151 490 minecraft:light[level=11]
setblock 97 151 498 minecraft:light[level=11]
setblock 105 151 466 minecraft:light[level=11]
setblock 105 151 474 minecraft:light[level=11]
setblock 105 151 482 minecraft:light[level=11]
setblock 105 151 490 minecraft:light[level=11]
setblock 105 151 498 minecraft:light[level=11]
setblock 113 151 466 minecraft:light[level=11]
setblock 113 151 474 minecraft:light[level=11]
setblock 113 151 482 minecraft:light[level=11]
setblock 113 151 490 minecraft:light[level=11]
setblock 113 151 498 minecraft:light[level=11]
setblock 121 151 466 minecraft:light[level=11]
setblock 121 151 474 minecraft:light[level=11]
setblock 121 151 482 minecraft:light[level=11]
setblock 121 151 490 minecraft:light[level=11]
setblock 121 151 498 minecraft:light[level=11]
setblock 129 151 466 minecraft:light[level=11]
setblock 129 151 474 minecraft:light[level=11]
setblock 129 151 482 minecraft:light[level=11]
setblock 129 151 490 minecraft:light[level=11]
setblock 129 151 498 minecraft:light[level=11]
fill 94 152 469 94 165 469 minecraft:sculk
fill 94 152 470 94 152 471 minecraft:sea_lantern
fill 94 152 472 94 165 472 minecraft:sculk
fill 94 152 481 94 165 481 minecraft:sculk
fill 94 152 482 94 152 483 minecraft:sea_lantern
fill 94 152 484 94 165 484 minecraft:sculk
fill 94 152 493 94 165 493 minecraft:sculk
fill 94 152 494 94 152 495 minecraft:sea_lantern
fill 94 152 496 94 165 496 minecraft:sculk
fill 94 152 505 94 165 505 minecraft:sculk
fill 95 152 505 96 152 505 minecraft:sea_lantern
fill 97 152 505 97 165 505 minecraft:sculk
fill 101 152 463 101 165 463 minecraft:sculk
fill 102 152 463 103 152 463 minecraft:sea_lantern
fill 104 152 463 104 165 463 minecraft:sculk
fill 106 152 505 106 165 505 minecraft:sculk
fill 107 152 505 108 152 505 minecraft:sea_lantern
fill 109 152 505 109 165 505 minecraft:sculk
fill 113 152 463 113 165 463 minecraft:sculk
fill 114 152 463 115 152 463 minecraft:sea_lantern
fill 116 152 463 116 165 463 minecraft:sculk
fill 118 152 505 118 165 505 minecraft:sculk
fill 119 152 505 120 152 505 minecraft:sea_lantern
fill 121 152 505 121 165 505 minecraft:sculk
fill 125 152 463 125 165 463 minecraft:sculk
fill 126 152 463 127 152 463 minecraft:sea_lantern
fill 128 152 463 128 165 463 minecraft:sculk
fill 130 152 505 130 165 505 minecraft:sculk
fill 131 152 505 132 152 505 minecraft:sea_lantern
fill 133 152 505 133 165 505 minecraft:sculk
fill 136 152 464 136 165 464 minecraft:sculk
fill 136 152 465 136 152 466 minecraft:sea_lantern
fill 136 152 467 136 165 467 minecraft:sculk
fill 136 152 476 136 165 476 minecraft:sculk
fill 136 152 477 136 152 478 minecraft:sea_lantern
fill 136 152 479 136 165 479 minecraft:sculk
fill 136 152 488 136 165 488 minecraft:sculk
fill 136 152 489 136 152 490 minecraft:sea_lantern
fill 136 152 491 136 165 491 minecraft:sculk
fill 136 152 500 136 165 500 minecraft:sculk
fill 136 152 501 136 152 502 minecraft:sea_lantern
fill 136 152 503 136 165 503 minecraft:sculk
fill 94 153 470 94 165 471 minecraft:sculk
fill 94 153 482 94 165 483 minecraft:sculk
fill 94 153 494 94 165 495 minecraft:sculk
fill 95 153 505 96 165 505 minecraft:sculk
fill 102 153 463 103 165 463 minecraft:sculk
fill 107 153 505 108 165 505 minecraft:sculk
fill 114 153 463 115 165 463 minecraft:sculk
fill 119 153 505 120 165 505 minecraft:sculk
fill 126 153 463 127 165 463 minecraft:sculk
fill 131 153 505 132 165 505 minecraft:sculk
fill 136 153 465 136 165 466 minecraft:sculk
fill 136 153 477 136 165 478 minecraft:sculk
fill 136 153 489 136 165 490 minecraft:sculk
fill 136 153 501 136 165 502 minecraft:sculk
fill 134 154 474 134 155 474 minecraft:cyan_concrete
fill 133 155 474 133 156 474 minecraft:cyan_concrete
fill 131 156 474 132 157 474 minecraft:cyan_concrete
fill 130 157 474 130 158 474 minecraft:cyan_concrete
fill 129 158 474 129 159 474 minecraft:cyan_concrete
setblock 97 159 466 minecraft:light[level=11]
setblock 97 159 474 minecraft:light[level=11]
setblock 97 159 482 minecraft:light[level=11]
setblock 97 159 490 minecraft:light[level=11]
setblock 97 159 498 minecraft:light[level=11]
setblock 105 159 466 minecraft:light[level=11]
setblock 105 159 474 minecraft:light[level=11]
setblock 105 159 482 minecraft:light[level=11]
setblock 105 159 490 minecraft:light[level=11]
setblock 105 159 498 minecraft:light[level=11]
setblock 113 159 466 minecraft:light[level=11]
setblock 113 159 474 minecraft:light[level=11]
setblock 113 159 482 minecraft:light[level=11]
setblock 113 159 490 minecraft:light[level=11]
setblock 113 159 498 minecraft:light[level=11]
setblock 121 159 466 minecraft:light[level=11]
setblock 121 159 474 minecraft:light[level=11]
setblock 121 159 482 minecraft:light[level=11]
setblock 121 159 490 minecraft:light[level=11]
setblock 121 159 498 minecraft:light[level=11]
setblock 129 159 466 minecraft:light[level=11]
setblock 129 159 482 minecraft:light[level=11]
setblock 129 159 490 minecraft:light[level=11]
setblock 129 159 498 minecraft:light[level=11]
fill 96 160 473 96 165 475 minecraft:deepslate_bricks
fill 96 160 485 96 165 487 minecraft:deepslate_bricks
fill 96 160 497 96 165 499 minecraft:deepslate_bricks
fill 102 160 503 104 165 503 minecraft:deepslate_bricks
fill 106 160 465 108 165 465 minecraft:deepslate_bricks
fill 114 160 503 116 165 503 minecraft:deepslate_bricks
fill 118 160 465 120 165 465 minecraft:deepslate_bricks
fill 126 160 503 128 165 503 minecraft:deepslate_bricks
fill 130 160 465 132 165 465 minecraft:deepslate_bricks
fill 134 160 473 134 165 475 minecraft:deepslate_bricks
fill 134 160 485 134 165 487 minecraft:deepslate_bricks
fill 134 160 497 134 165 499 minecraft:deepslate_bricks
fill 95 165 467 95 165 472 minecraft:sculk
fill 95 165 479 95 165 484 minecraft:sculk
fill 95 165 491 95 165 496 minecraft:sculk
fill 95 165 503 95 165 504 minecraft:sculk
fill 96 165 504 99 165 504 minecraft:sculk
fill 99 165 464 104 165 464 minecraft:sculk
fill 106 165 504 111 165 504 minecraft:sculk
fill 111 165 464 116 165 464 minecraft:sculk
fill 118 165 504 123 165 504 minecraft:sculk
fill 123 165 464 128 165 464 minecraft:sculk
fill 130 165 504 135 165 504 minecraft:sculk
fill 135 165 464 135 165 469 minecraft:sculk
fill 135 165 476 135 165 481 minecraft:sculk
fill 135 165 488 135 165 493 minecraft:sculk
fill 135 165 500 135 165 503 minecraft:sculk
fill 94 166 469 94 170 472 minecraft:sea_lantern
fill 94 166 481 94 170 484 minecraft:sea_lantern
fill 94 166 493 94 170 496 minecraft:sea_lantern
fill 94 166 505 97 170 505 minecraft:sea_lantern
fill 101 166 463 104 170 463 minecraft:sea_lantern
fill 106 166 505 109 170 505 minecraft:sea_lantern
fill 113 166 463 116 170 463 minecraft:sea_lantern
fill 118 166 505 121 170 505 minecraft:sea_lantern
fill 125 166 463 128 170 463 minecraft:sea_lantern
fill 130 166 505 133 170 505 minecraft:sea_lantern
fill 136 166 464 136 170 467 minecraft:sea_lantern
fill 136 166 476 136 170 479 minecraft:sea_lantern
fill 136 166 488 136 170 491 minecraft:sea_lantern
fill 136 166 500 136 170 503 minecraft:sea_lantern
setblock 97 167 466 minecraft:light[level=11]
setblock 97 167 474 minecraft:light[level=11]
setblock 97 167 482 minecraft:light[level=11]
setblock 97 167 490 minecraft:light[level=11]
setblock 97 167 498 minecraft:light[level=11]
setblock 105 167 466 minecraft:light[level=11]
setblock 105 167 474 minecraft:light[level=11]
setblock 105 167 482 minecraft:light[level=11]
setblock 105 167 490 minecraft:light[level=11]
setblock 105 167 498 minecraft:light[level=11]
setblock 113 167 466 minecraft:light[level=11]
setblock 113 167 474 minecraft:light[level=11]
setblock 113 167 482 minecraft:light[level=11]
setblock 113 167 490 minecraft:light[level=11]
setblock 113 167 498 minecraft:light[level=11]
setblock 121 167 466 minecraft:light[level=11]
setblock 121 167 474 minecraft:light[level=11]
setblock 121 167 482 minecraft:light[level=11]
setblock 121 167 490 minecraft:light[level=11]
setblock 121 167 498 minecraft:light[level=11]
setblock 129 167 466 minecraft:light[level=11]
setblock 129 167 474 minecraft:light[level=11]
setblock 129 167 482 minecraft:light[level=11]
setblock 129 167 490 minecraft:light[level=11]
setblock 129 167 498 minecraft:light[level=11]
fill 94 171 469 94 185 472 minecraft:sculk
fill 94 171 481 94 185 484 minecraft:sculk
fill 94 171 493 94 185 496 minecraft:sculk
fill 94 171 505 97 185 505 minecraft:sculk
fill 101 171 463 104 185 463 minecraft:sculk
fill 106 171 505 109 185 505 minecraft:sculk
fill 113 171 463 116 185 463 minecraft:sculk
fill 118 171 505 121 185 505 minecraft:sculk
fill 125 171 463 128 185 463 minecraft:sculk
fill 130 171 505 133 185 505 minecraft:sculk
fill 136 171 464 136 185 467 minecraft:sculk
fill 136 171 476 136 185 479 minecraft:sculk
fill 136 171 488 136 185 491 minecraft:sculk
fill 136 171 500 136 185 503 minecraft:sculk
setblock 97 175 466 minecraft:light[level=11]
setblock 97 175 474 minecraft:light[level=11]
setblock 97 175 482 minecraft:light[level=11]
setblock 97 175 490 minecraft:light[level=11]
setblock 97 175 498 minecraft:light[level=11]
setblock 105 175 466 minecraft:light[level=11]
setblock 105 175 474 minecraft:light[level=11]
setblock 105 175 482 minecraft:light[level=11]
setblock 105 175 490 minecraft:light[level=11]
setblock 105 175 498 minecraft:light[level=11]
setblock 113 175 466 minecraft:light[level=11]
setblock 113 175 474 minecraft:light[level=11]
setblock 113 175 482 minecraft:light[level=11]
setblock 113 175 490 minecraft:light[level=11]
setblock 113 175 498 minecraft:light[level=11]
setblock 121 175 466 minecraft:light[level=11]
setblock 121 175 474 minecraft:light[level=11]
setblock 121 175 482 minecraft:light[level=11]
setblock 121 175 490 minecraft:light[level=11]
setblock 121 175 498 minecraft:light[level=11]
setblock 129 175 466 minecraft:light[level=11]
setblock 129 175 474 minecraft:light[level=11]
setblock 129 175 482 minecraft:light[level=11]
setblock 129 175 490 minecraft:light[level=11]
setblock 129 175 498 minecraft:light[level=11]
fill 95 176 464 135 177 477 minecraft:sculk
fill 95 176 478 135 177 478 minecraft:cyan_terracotta
fill 95 176 479 135 177 481 minecraft:sculk
fill 95 176 482 135 176 482 minecraft:cyan_terracotta
fill 95 176 483 110 176 485 minecraft:sculk
fill 95 176 486 111 176 486 minecraft:cyan_terracotta
fill 95 176 487 112 176 489 minecraft:sculk
fill 95 176 490 135 177 490 minecraft:cyan_terracotta
fill 95 176 491 135 177 493 minecraft:sculk
fill 95 176 494 135 177 494 minecraft:cyan_terracotta
fill 95 176 495 135 177 497 minecraft:sculk
fill 95 176 498 135 177 498 minecraft:cyan_terracotta
fill 95 176 499 135 177 501 minecraft:sculk
fill 95 176 502 135 177 502 minecraft:cyan_terracotta
fill 95 176 503 135 177 504 minecraft:sculk
fill 111 176 483 111 176 484 minecraft:sculk
setblock 112 176 483 minecraft:sculk
fill 113 176 488 135 176 489 minecraft:sculk
fill 114 176 483 135 176 483 minecraft:sculk
fill 114 176 487 135 176 487 minecraft:sculk
fill 115 176 484 135 176 484 minecraft:sculk
fill 115 176 486 135 176 486 minecraft:cyan_terracotta
fill 116 176 485 135 176 485 minecraft:sculk
fill 95 177 482 111 177 482 minecraft:cyan_terracotta
fill 95 177 483 109 177 485 minecraft:sculk
fill 95 177 486 109 177 486 minecraft:cyan_terracotta
fill 95 177 487 110 177 489 minecraft:sculk
setblock 110 177 483 minecraft:sculk
fill 110 177 484 110 177 486 minecraft:sea_lantern
fill 111 177 483 111 177 484 minecraft:sea_lantern
fill 111 177 486 111 177 487 minecraft:sea_lantern
fill 111 177 488 111 177 489 minecraft:sculk
fill 112 177 482 112 177 483 minecraft:sea_lantern
fill 112 177 487 112 177 488 minecraft:sea_lantern
fill 112 177 489 135 177 489 minecraft:sculk
fill 113 177 482 114 177 482 minecraft:sea_lantern
fill 113 177 488 114 177 488 minecraft:sea_lantern
fill 114 177 483 115 177 483 minecraft:sea_lantern
fill 114 177 487 115 177 487 minecraft:sea_lantern
fill 115 177 482 135 177 482 minecraft:cyan_terracotta
fill 115 177 484 116 177 484 minecraft:sea_lantern
fill 115 177 486 116 177 486 minecraft:sea_lantern
fill 115 177 488 135 177 488 minecraft:sculk
fill 116 177 483 135 177 483 minecraft:sculk
setblock 116 177 485 minecraft:sea_lantern
fill 116 177 487 135 177 487 minecraft:sculk
fill 117 177 484 135 177 485 minecraft:sculk
fill 117 177 486 135 177 486 minecraft:cyan_terracotta
fill 106 178 478 109 179 493 minecraft:gray_concrete
fill 110 178 478 121 179 481 minecraft:gray_concrete
fill 110 178 490 121 179 493 minecraft:gray_concrete
fill 118 178 482 121 179 489 minecraft:gray_concrete
fill 106 180 478 106 192 478 minecraft:gray_concrete
setblock 106 180 479 minecraft:black_stained_glass
fill 106 180 480 121 193 480 minecraft:gray_concrete
setblock 106 180 481 minecraft:black_stained_glass
fill 106 180 482 109 193 482 minecraft:gray_concrete
setblock 106 180 483 minecraft:black_stained_glass
fill 106 180 484 109 193 484 minecraft:gray_concrete
setblock 106 180 485 minecraft:light_blue_stained_glass
fill 106 180 486 109 193 486 minecraft:gray_concrete
setblock 106 180 487 minecraft:light_blue_stained_glass
fill 106 180 488 109 193 488 minecraft:gray_concrete
setblock 106 180 489 minecraft:black_stained_glass
fill 106 180 490 121 193 490 minecraft:gray_concrete
setblock 106 180 491 minecraft:black_stained_glass
fill 106 180 492 106 193 493 minecraft:gray_concrete
setblock 107 180 478 minecraft:sea_lantern
fill 107 180 479 120 193 479 minecraft:gray_concrete
fill 107 180 481 120 193 481 minecraft:gray_concrete
fill 107 180 483 109 193 483 minecraft:gray_concrete
fill 107 180 485 109 193 485 minecraft:gray_concrete
fill 107 180 487 109 193 487 minecraft:gray_concrete
fill 107 180 489 109 193 489 minecraft:gray_concrete
fill 107 180 491 120 193 492 minecraft:gray_concrete
setblock 107 180 493 minecraft:sea_lantern
fill 108 180 478 108 192 478 minecraft:gray_concrete
fill 108 180 493 108 193 493 minecraft:gray_concrete
setblock 109 180 478 minecraft:black_stained_glass
setblock 109 180 493 minecraft:black_stained_glass
fill 110 180 478 110 192 478 minecraft:gray_concrete
fill 110 180 493 110 193 493 minecraft:gray_concrete
setblock 111 180 478 minecraft:sea_lantern
setblock 111 180 493 minecraft:black_stained_glass
fill 112 180 478 112 192 478 minecraft:gray_concrete
fill 112 180 493 112 193 493 minecraft:gray_concrete
setblock 113 180 478 minecraft:sea_lantern
setblock 113 180 493 minecraft:sea_lantern
fill 114 180 478 114 192 478 minecraft:gray_concrete
fill 114 180 493 114 193 493 minecraft:gray_concrete
setblock 115 180 478 minecraft:black_stained_glass
setblock 115 180 493 minecraft:light_blue_stained_glass
fill 116 180 478 116 192 478 minecraft:gray_concrete
fill 116 180 493 116 193 493 minecraft:gray_concrete
setblock 117 180 478 minecraft:black_stained_glass
setblock 117 180 493 minecraft:sea_lantern
fill 118 180 478 118 192 478 minecraft:gray_concrete
fill 118 180 482 120 193 489 minecraft:gray_concrete
fill 118 180 493 118 193 493 minecraft:gray_concrete
setblock 119 180 478 minecraft:sea_lantern
setblock 119 180 493 minecraft:black_stained_glass
fill 120 180 478 121 192 478 minecraft:gray_concrete
fill 120 180 493 121 193 493 minecraft:gray_concrete
setblock 121 180 479 minecraft:black_stained_glass
setblock 121 180 481 minecraft:sea_lantern
fill 121 180 482 121 193 482 minecraft:gray_concrete
setblock 121 180 483 minecraft:light_blue_stained_glass
fill 121 180 484 121 193 484 minecraft:gray_concrete
setblock 121 180 485 minecraft:black_stained_glass
fill 121 180 486 121 193 486 minecraft:gray_concrete
setblock 121 180 487 minecraft:black_stained_glass
fill 121 180 488 121 193 488 minecraft:gray_concrete
setblock 121 180 489 minecraft:black_stained_glass
setblock 121 180 491 minecraft:sea_lantern
fill 121 180 492 121 193 492 minecraft:gray_concrete
fill 95 181 464 97 228 464 minecraft:deepslate_bricks
fill 95 181 474 95 228 476 minecraft:deepslate_bricks
fill 95 181 483 101 181 489 minecraft:deepslate_bricks
fill 95 181 498 95 228 500 minecraft:deepslate_bricks
fill 96 181 473 96 185 475 minecraft:deepslate_bricks
fill 96 181 497 96 185 499 minecraft:deepslate_bricks
fill 99 181 479 100 181 479 minecraft:cyan_concrete
fill 101 181 504 103 228 504 minecraft:deepslate_bricks
fill 102 181 503 104 185 503 minecraft:deepslate_bricks
fill 106 181 465 108 185 465 minecraft:deepslate_bricks
fill 106 181 479 106 182 479 minecraft:gray_concrete
fill 106 181 481 106 182 481 minecraft:gray_concrete
fill 106 181 483 106 182 483 minecraft:gray_concrete
fill 106 181 485 106 182 485 minecraft:gray_concrete
fill 106 181 487 106 182 487 minecraft:gray_concrete
fill 106 181 489 106 182 489 minecraft:gray_concrete
fill 106 181 491 106 182 491 minecraft:gray_concrete
fill 107 181 464 109 228 464 minecraft:deepslate_bricks
fill 107 181 478 107 182 478 minecraft:gray_concrete
fill 107 181 493 107 182 493 minecraft:gray_concrete
fill 109 181 478 109 182 478 minecraft:gray_concrete
fill 109 181 493 109 182 493 minecraft:gray_concrete
fill 111 181 478 111 182 478 minecraft:gray_concrete
fill 111 181 493 111 182 493 minecraft:gray_concrete
fill 113 181 478 113 182 478 minecraft:gray_concrete
fill 113 181 493 113 182 493 minecraft:gray_concrete
fill 113 181 504 115 228 504 minecraft:deepslate_bricks
fill 114 181 503 116 185 503 minecraft:deepslate_bricks
fill 115 181 478 115 182 478 minecraft:gray_concrete
fill 115 181 493 115 182 493 minecraft:gray_concrete
fill 117 181 478 117 182 478 minecraft:gray_concrete
fill 117 181 493 117 182 493 minecraft:gray_concrete
fill 118 181 465 120 185 465 minecraft:deepslate_bricks
fill 119 181 464 121 228 464 minecraft:deepslate_bricks
fill 119 181 478 119 182 478 minecraft:gray_concrete
fill 119 181 493 119 182 493 minecraft:gray_concrete
fill 121 181 479 121 182 479 minecraft:gray_concrete
fill 121 181 481 121 182 481 minecraft:gray_concrete
fill 121 181 483 121 182 483 minecraft:gray_concrete
fill 121 181 485 121 182 485 minecraft:gray_concrete
fill 121 181 487 121 182 487 minecraft:gray_concrete
fill 121 181 489 121 182 489 minecraft:gray_concrete
fill 121 181 491 121 182 491 minecraft:gray_concrete
fill 125 181 504 127 228 504 minecraft:deepslate_bricks
fill 126 181 503 130 185 503 minecraft:deepslate_bricks
fill 128 181 501 131 207 502 minecraft:deepslate_bricks
fill 129 181 500 130 228 500 minecraft:deepslate_bricks
fill 130 181 465 132 185 465 minecraft:deepslate_bricks
fill 131 181 464 133 228 464 minecraft:deepslate_bricks
fill 134 181 473 134 185 475 minecraft:deepslate_bricks
fill 134 181 485 134 185 487 minecraft:deepslate_bricks
fill 134 181 497 134 185 499 minecraft:deepslate_bricks
fill 135 181 472 135 228 474 minecraft:deepslate_bricks
fill 135 181 484 135 228 486 minecraft:deepslate_bricks
fill 135 181 496 135 228 498 minecraft:deepslate_bricks
fill 95 182 479 98 182 479 minecraft:cyan_concrete
fill 95 182 483 97 183 489 minecraft:deepslate_bricks
fill 98 182 480 99 183 488 minecraft:sculk
fill 98 182 489 98 183 489 minecraft:deepslate_bricks
fill 99 182 477 100 183 479 minecraft:sculk
fill 99 182 489 100 183 491 minecraft:sculk
fill 100 182 475 101 183 476 minecraft:sculk
fill 100 182 480 100 183 480 minecraft:sculk
fill 100 182 483 101 183 487 minecraft:deepslate_bricks
fill 100 182 488 100 183 488 minecraft:sculk
fill 100 182 492 101 183 493 minecraft:sculk
fill 101 182 474 103 183 474 minecraft:sculk
fill 101 182 477 101 183 477 minecraft:sculk
fill 101 182 488 101 183 489 minecraft:deepslate_bricks
fill 101 182 491 101 183 491 minecraft:sculk
fill 101 182 494 103 183 494 minecraft:sculk
fill 102 182 473 104 183 473 minecraft:sculk
fill 102 182 475 102 183 475 minecraft:sculk
fill 102 182 493 102 183 493 minecraft:sculk
fill 102 182 495 104 183 495 minecraft:sculk
fill 103 182 472 105 183 472 minecraft:sculk
fill 103 182 496 105 183 496 minecraft:sculk
fill 104 182 471 106 183 471 minecraft:sculk
fill 104 182 497 106 183 497 minecraft:sculk
fill 105 182 470 108 183 470 minecraft:sculk
fill 105 182 498 108 183 498 minecraft:sculk
fill 106 182 469 111 183 469 minecraft:sculk
fill 106 182 499 111 183 499 minecraft:sculk
fill 108 182 468 122 183 468 minecraft:sculk
fill 108 182 500 122 183 500 minecraft:sculk
fill 111 182 467 119 183 467 minecraft:sculk
fill 111 182 501 119 183 501 minecraft:sculk
fill 119 182 469 124 183 469 minecraft:sculk
fill 119 182 499 124 183 499 minecraft:sculk
fill 122 182 470 125 183 470 minecraft:sculk
fill 122 182 498 125 183 498 minecraft:sculk
fill 124 182 471 126 183 471 minecraft:sculk
fill 124 182 497 126 183 497 minecraft:sculk
fill 125 182 472 127 183 472 minecraft:sculk
fill 125 182 496 127 183 496 minecraft:sculk
fill 126 182 473 128 183 473 minecraft:sculk
fill 126 182 495 128 183 495 minecraft:sculk
fill 127 182 474 129 183 474 minecraft:sculk
fill 127 182 494 129 183 494 minecraft:sculk
fill 128 182 475 130 183 475 minecraft:sculk
fill 128 182 493 130 183 493 minecraft:sculk
fill 128 182 500 128 183 500 minecraft:sculk
fill 129 182 476 130 183 477 minecraft:sculk
fill 129 182 491 130 183 492 minecraft:sculk
fill 130 182 478 131 183 480 minecraft:sculk
fill 130 182 488 131 183 490 minecraft:sculk
fill 131 182 477 131 183 477 minecraft:sculk
fill 131 182 481 132 183 487 minecraft:sculk
fill 131 182 491 131 187 491 minecraft:sculk
fill 131 182 500 131 183 500 minecraft:sculk
fill 131 182 503 131 183 503 minecraft:sculk
fill 132 182 480 132 183 480 minecraft:sculk
fill 132 182 488 132 183 488 minecraft:sculk
fill 95 183 479 96 183 479 minecraft:cyan_concrete
setblock 97 183 466 minecraft:light[level=11]
setblock 97 183 474 minecraft:light[level=11]
setblock 97 183 482 minecraft:light[level=11]
setblock 97 183 490 minecraft:light[level=11]
setblock 97 183 498 minecraft:light[level=11]
setblock 105 183 466 minecraft:light[level=11]
setblock 105 183 474 minecraft:light[level=11]
setblock 105 183 482 minecraft:light[level=11]
setblock 105 183 490 minecraft:light[level=11]
setblock 106 183 479 minecraft:black_stained_glass
setblock 106 183 481 minecraft:black_stained_glass
setblock 106 183 483 minecraft:sea_lantern
setblock 106 183 485 minecraft:black_stained_glass
setblock 106 183 487 minecraft:black_stained_glass
setblock 106 183 489 minecraft:black_stained_glass
setblock 106 183 491 minecraft:black_stained_glass
setblock 107 183 478 minecraft:black_stained_glass
setblock 107 183 493 minecraft:sea_lantern
setblock 109 183 478 minecraft:light_blue_stained_glass
setblock 109 183 493 minecraft:black_stained_glass
setblock 111 183 478 minecraft:sea_lantern
setblock 111 183 493 minecraft:black_stained_glass
setblock 113 183 466 minecraft:light[level=11]
setblock 113 183 474 minecraft:light[level=11]
setblock 113 183 478 minecraft:light_blue_stained_glass
setblock 113 183 493 minecraft:sea_lantern
setblock 113 183 498 minecraft:light[level=11]
setblock 115 183 478 minecraft:black_stained_glass
setblock 115 183 493 minecraft:light_blue_stained_glass
setblock 117 183 478 minecraft:black_stained_glass
setblock 117 183 493 minecraft:black_stained_glass
setblock 119 183 478 minecraft:light_blue_stained_glass
setblock 119 183 493 minecraft:black_stained_glass
setblock 121 183 466 minecraft:light[level=11]
setblock 121 183 474 minecraft:light[level=11]
setblock 121 183 479 minecraft:black_stained_glass
setblock 121 183 481 minecraft:black_stained_glass
setblock 121 183 483 minecraft:light_blue_stained_glass
setblock 121 183 485 minecraft:black_stained_glass
setblock 121 183 487 minecraft:sea_lantern
setblock 121 183 489 minecraft:sea_lantern
setblock 121 183 491 minecraft:black_stained_glass
setblock 121 183 498 minecraft:light[level=11]
fill 127 183 500 127 183 502 minecraft:sculk
fill 128 183 499 131 183 499 minecraft:sculk
fill 128 183 504 131 183 504 minecraft:sculk
setblock 129 183 466 minecraft:light[level=11]
setblock 129 183 482 minecraft:light[level=11]
setblock 129 183 490 minecraft:light[level=11]
setblock 129 183 498 minecraft:light[level=11]
fill 131 183 492 133 210 494 minecraft:deepslate_bricks
fill 132 183 500 132 183 503 minecraft:sculk
setblock 95 184 483 minecraft:deepslate_bricks
setblock 95 184 484 minecraft:sea_lantern
fill 95 184 485 95 198 485 minecraft:deepslate_bricks
setblock 95 184 486 minecraft:sea_lantern
fill 95 184 487 95 228 487 minecraft:deepslate_bricks
setblock 95 184 488 minecraft:sea_lantern
fill 95 184 489 95 198 489 minecraft:deepslate_bricks
setblock 96 184 483 minecraft:sea_lantern
fill 96 184 484 96 198 484 minecraft:deepslate_bricks
setblock 96 184 485 minecraft:sea_lantern
fill 96 184 486 96 198 486 minecraft:deepslate_bricks
setblock 96 184 487 minecraft:sea_lantern
fill 96 184 488 96 198 488 minecraft:deepslate_bricks
setblock 96 184 489 minecraft:sea_lantern
fill 97 184 483 97 198 483 minecraft:deepslate_bricks
setblock 97 184 484 minecraft:sea_lantern
fill 97 184 485 97 198 485 minecraft:deepslate_bricks
setblock 97 184 486 minecraft:sea_lantern
fill 97 184 487 97 198 487 minecraft:deepslate_bricks
setblock 97 184 488 minecraft:sea_lantern
fill 97 184 489 97 198 489 minecraft:deepslate_bricks
setblock 98 184 483 minecraft:sea_lantern
fill 98 184 484 98 185 484 minecraft:deepslate_bricks
setblock 98 184 485 minecraft:sea_lantern
fill 98 184 486 98 185 486 minecraft:deepslate_bricks
setblock 98 184 487 minecraft:sea_lantern
fill 98 184 488 98 185 488 minecraft:deepslate_bricks
setblock 98 184 489 minecraft:sea_lantern
fill 99 184 483 99 185 483 minecraft:deepslate_bricks
setblock 99 184 484 minecraft:sea_lantern
fill 99 184 485 99 185 485 minecraft:deepslate_bricks
setblock 99 184 486 minecraft:sea_lantern
fill 99 184 487 99 185 487 minecraft:deepslate_bricks
setblock 99 184 488 minecraft:sea_lantern
fill 99 184 489 99 185 489 minecraft:deepslate_bricks
setblock 100 184 483 minecraft:sea_lantern
fill 100 184 484 100 198 484 minecraft:deepslate_bricks
setblock 100 184 485 minecraft:sea_lantern
fill 100 184 486 100 198 486 minecraft:deepslate_bricks
setblock 100 184 487 minecraft:sea_lantern
fill 100 184 488 100 185 488 minecraft:deepslate_bricks
setblock 100 184 489 minecraft:sea_lantern
fill 101 184 483 101 198 483 minecraft:deepslate_bricks
setblock 101 184 484 minecraft:sea_lantern
fill 101 184 485 101 198 485 minecraft:deepslate_bricks
setblock 101 184 486 minecraft:sea_lantern
fill 101 184 487 101 198 487 minecraft:deepslate_bricks
setblock 101 184 488 minecraft:sea_lantern
fill 101 184 489 101 198 489 minecraft:deepslate_bricks
fill 106 184 479 106 185 479 minecraft:gray_concrete
fill 106 184 481 106 185 481 minecraft:gray_concrete
fill 106 184 483 106 185 483 minecraft:gray_concrete
fill 106 184 485 106 185 485 minecraft:gray_concrete
fill 106 184 487 106 185 487 minecraft:gray_concrete
fill 106 184 489 106 185 489 minecraft:gray_concrete
fill 106 184 491 106 185 491 minecraft:gray_concrete
fill 107 184 478 107 185 478 minecraft:gray_concrete
fill 107 184 493 107 185 493 minecraft:gray_concrete
fill 109 184 478 109 185 478 minecraft:gray_concrete
fill 109 184 493 109 185 493 minecraft:gray_concrete
fill 111 184 478 111 185 478 minecraft:gray_concrete
fill 111 184 493 111 185 493 minecraft:gray_concrete
fill 113 184 478 113 185 478 minecraft:gray_concrete
fill 113 184 493 113 185 493 minecraft:gray_concrete
fill 115 184 478 115 185 478 minecraft:gray_concrete
fill 115 184 493 115 185 493 minecraft:gray_concrete
fill 117 184 478 117 185 478 minecraft:gray_concrete
fill 117 184 493 117 185 493 minecraft:gray_concrete
fill 119 184 478 119 185 478 minecraft:gray_concrete
fill 119 184 493 119 185 493 minecraft:gray_concrete
fill 121 184 479 121 185 479 minecraft:gray_concrete
fill 121 184 481 121 185 481 minecraft:gray_concrete
fill 121 184 483 121 185 483 minecraft:gray_concrete
fill 121 184 485 121 185 485 minecraft:gray_concrete
fill 121 184 487 121 185 487 minecraft:gray_concrete
fill 121 184 489 121 185 489 minecraft:gray_concrete
fill 121 184 491 121 185 491 minecraft:gray_concrete
fill 130 184 491 130 187 492 minecraft:sculk
fill 130 184 493 130 185 493 minecraft:deepslate_bricks
fill 130 184 494 130 185 494 minecraft:sculk
fill 131 184 495 133 185 495 minecraft:sculk
fill 132 184 491 133 185 491 minecraft:sculk
fill 134 184 492 134 185 494 minecraft:sculk
fill 95 185 467 95 185 472 minecraft:sculk
fill 95 185 479 95 185 484 minecraft:sculk
fill 95 185 486 95 186 486 minecraft:deepslate_bricks
fill 95 185 488 95 186 488 minecraft:deepslate_bricks
fill 95 185 491 95 185 496 minecraft:sculk
fill 95 185 503 95 185 504 minecraft:sculk
fill 96 185 483 96 186 483 minecraft:deepslate_bricks
fill 96 185 485 96 186 485 minecraft:deepslate_bricks
fill 96 185 487 96 186 487 minecraft:deepslate_bricks
fill 96 185 489 96 186 489 minecraft:deepslate_bricks
fill 96 185 504 99 185 504 minecraft:sculk
fill 97 185 484 97 186 484 minecraft:deepslate_bricks
fill 97 185 486 97 186 486 minecraft:deepslate_bricks
fill 97 185 488 97 186 488 minecraft:deepslate_bricks
setblock 98 185 483 minecraft:deepslate_bricks
setblock 98 185 485 minecraft:deepslate_bricks
setblock 98 185 487 minecraft:deepslate_bricks
fill 98 185 489 98 186 489 minecraft:deepslate_bricks
fill 99 185 464 104 185 464 minecraft:sculk
setblock 99 185 484 minecraft:deepslate_bricks
setblock 99 185 486 minecraft:deepslate_bricks
setblock 99 185 488 minecraft:deepslate_bricks
fill 100 185 483 100 186 483 minecraft:deepslate_bricks
fill 100 185 485 100 186 485 minecraft:deepslate_bricks
fill 100 185 487 100 186 487 minecraft:deepslate_bricks
setblock 100 185 489 minecraft:deepslate_bricks
fill 101 185 484 101 186 484 minecraft:deepslate_bricks
fill 101 185 486 101 186 486 minecraft:deepslate_bricks
fill 101 185 488 101 186 488 minecraft:deepslate_bricks
fill 106 185 504 111 185 504 minecraft:sculk
fill 111 185 464 116 185 464 minecraft:sculk
fill 118 185 504 123 185 504 minecraft:sculk
fill 123 185 464 128 185 464 minecraft:sculk
fill 129 185 491 129 187 494 minecraft:sculk
fill 130 185 490 133 185 490 minecraft:sculk
setblock 130 185 495 minecraft:sculk
fill 130 185 504 135 185 504 minecraft:sculk
fill 131 185 496 133 185 496 minecraft:sculk
fill 133 185 500 134 188 500 minecraft:cyan_stained_glass
fill 134 185 491 135 185 491 minecraft:sculk
setblock 134 185 495 minecraft:sculk
fill 134 185 501 134 188 501 minecraft:cyan_stained_glass
fill 135 185 464 135 185 469 minecraft:sculk
fill 135 185 476 135 185 481 minecraft:sculk
fill 135 185 488 135 185 490 minecraft:sculk
fill 135 185 492 135 185 493 minecraft:sculk
fill 135 185 500 135 185 503 minecraft:sculk
fill 94 186 469 94 191 472 minecraft:sea_lantern
fill 94 186 481 94 191 484 minecraft:sea_lantern
fill 94 186 493 94 191 496 minecraft:sea_lantern
fill 94 186 505 97 191 505 minecraft:sea_lantern
fill 95 186 483 95 186 484 minecraft:deepslate_bricks
fill 98 186 480 99 186 488 minecraft:sculk
fill 99 186 477 100 187 479 minecraft:sculk
fill 99 186 489 100 186 491 minecraft:sculk
fill 100 186 475 101 187 476 minecraft:sculk
fill 100 186 480 100 187 480 minecraft:sculk
fill 100 186 488 100 187 488 minecraft:sculk
fill 100 186 492 101 187 493 minecraft:sculk
fill 101 186 463 104 191 463 minecraft:sea_lantern
fill 101 186 474 103 187 474 minecraft:sculk
fill 101 186 477 101 187 477 minecraft:sculk
fill 101 186 491 101 187 491 minecraft:sculk
fill 101 186 494 103 187 494 minecraft:sculk
fill 102 186 473 104 187 473 minecraft:sculk
fill 102 186 475 102 187 475 minecraft:sculk
fill 102 186 493 102 187 493 minecraft:sculk
fill 102 186 495 104 187 495 minecraft:sculk
fill 103 186 472 105 187 472 minecraft:sculk
fill 103 186 496 105 187 496 minecraft:sculk
fill 104 186 471 106 187 471 minecraft:sculk
fill 104 186 497 106 187 497 minecraft:sculk
fill 105 186 470 108 187 470 minecraft:sculk
fill 105 186 498 108 187 498 minecraft:sculk
fill 106 186 469 111 187 469 minecraft:sculk
setblock 106 186 479 minecraft:light_blue_stained_glass
setblock 106 186 481 minecraft:light_blue_stained_glass
setblock 106 186 483 minecraft:black_stained_glass
setblock 106 186 485 minecraft:light_blue_stained_glass
setblock 106 186 487 minecraft:black_stained_glass
setblock 106 186 489 minecraft:black_stained_glass
setblock 106 186 491 minecraft:sea_lantern
fill 106 186 499 111 187 499 minecraft:sculk
fill 106 186 505 109 191 505 minecraft:sea_lantern
setblock 107 186 478 minecraft:black_stained_glass
setblock 107 186 493 minecraft:sea_lantern
fill 108 186 468 122 187 468 minecraft:sculk
fill 108 186 500 122 187 500 minecraft:sculk
setblock 109 186 478 minecraft:light_blue_stained_glass
setblock 109 186 493 minecraft:black_stained_glass
fill 111 186 467 119 187 467 minecraft:sculk
setblock 111 186 478 minecraft:sea_lantern
setblock 111 186 493 minecraft:sea_lantern
fill 111 186 501 119 187 501 minecraft:sculk
fill 113 186 463 116 191 463 minecraft:sea_lantern
setblock 113 186 478 minecraft:black_stained_glass
setblock 113 186 493 minecraft:sea_lantern
setblock 115 186 478 minecraft:black_stained_glass
setblock 115 186 493 minecraft:sea_lantern
setblock 117 186 478 minecraft:light_blue_stained_glass
setblock 117 186 493 minecraft:sea_lantern
fill 118 186 505 121 191 505 minecraft:sea_lantern
fill 119 186 469 124 187 469 minecraft:sculk
setblock 119 186 478 minecraft:light_blue_stained_glass
setblock 119 186 493 minecraft:black_stained_glass
fill 119 186 499 124 187 499 minecraft:sculk
setblock 121 186 479 minecraft:light_blue_stained_glass
setblock 121 186 481 minecraft:light_blue_stained_glass
setblock 121 186 483 minecraft:sea_lantern
setblock 121 186 485 minecraft:black_stained_glass
setblock 121 186 487 minecraft:light_blue_stained_glass
setblock 121 186 489 minecraft:light_blue_stained_glass
setblock 121 186 491 minecraft:sea_lantern
fill 122 186 470 125 187 470 minecraft:sculk
fill 122 186 498 125 187 498 minecraft:sculk
fill 124 186 471 126 187 471 minecraft:sculk
fill 124 186 497 126 187 497 minecraft:sculk
fill 125 186 463 128 191 463 minecraft:sea_lantern
fill 125 186 472 127 187 472 minecraft:sculk
fill 125 186 496 127 187 496 minecraft:sculk
fill 126 186 473 128 187 473 minecraft:sculk
fill 126 186 495 128 187 495 minecraft:sculk
fill 127 186 474 129 187 474 minecraft:sculk
fill 127 186 494 128 187 494 minecraft:sculk
fill 128 186 475 130 187 475 minecraft:sculk
fill 128 186 493 128 187 493 minecraft:sculk
fill 129 186 476 130 187 477 minecraft:sculk
fill 129 186 503 130 228 503 minecraft:deepslate_bricks
fill 130 186 478 131 187 480 minecraft:sculk
fill 130 186 488 131 187 490 minecraft:sculk
fill 130 186 493 130 187 493 minecraft:sculk
fill 130 186 505 133 191 505 minecraft:sea_lantern
fill 131 186 477 131 187 477 minecraft:sculk
fill 131 186 481 132 187 487 minecraft:sculk
fill 132 186 480 132 187 480 minecraft:sculk
fill 132 186 488 132 187 488 minecraft:sculk
fill 132 186 500 132 188 500 minecraft:cyan_stained_glass
fill 133 186 499 135 187 499 minecraft:cyan_stained_glass
fill 133 186 501 133 187 501 minecraft:cyan_stained_glass
fill 135 186 500 135 187 501 minecraft:cyan_stained_glass
fill 136 186 464 136 191 467 minecraft:sea_lantern
fill 136 186 476 136 191 479 minecraft:sea_lantern
fill 136 186 488 136 191 491 minecraft:sea_lantern
fill 136 186 500 136 191 503 minecraft:sea_lantern
fill 95 187 483 95 198 483 minecraft:deepslate_bricks
setblock 95 187 484 minecraft:sea_lantern
setblock 95 187 486 minecraft:sea_lantern
setblock 95 187 488 minecraft:sea_lantern
setblock 96 187 483 minecraft:sea_lantern
setblock 96 187 485 minecraft:sea_lantern
setblock 96 187 487 minecraft:sea_lantern
setblock 96 187 489 minecraft:sea_lantern
setblock 97 187 484 minecraft:sea_lantern
setblock 97 187 486 minecraft:sea_lantern
setblock 97 187 488 minecraft:sea_lantern
fill 98 187 480 99 187 482 minecraft:sculk
setblock 98 187 483 minecraft:sea_lantern
setblock 98 187 484 minecraft:sculk
setblock 98 187 485 minecraft:sea_lantern
setblock 98 187 486 minecraft:sculk
setblock 98 187 487 minecraft:sea_lantern
setblock 98 187 488 minecraft:sculk
setblock 98 187 489 minecraft:sea_lantern
setblock 99 187 483 minecraft:sculk
setblock 99 187 484 minecraft:sea_lantern
setblock 99 187 485 minecraft:sculk
setblock 99 187 486 minecraft:sea_lantern
setblock 99 187 487 minecraft:sculk
setblock 99 187 488 minecraft:sea_lantern
fill 99 187 489 99 187 491 minecraft:sculk
setblock 100 187 483 minecraft:sea_lantern
setblock 100 187 485 minecraft:sea_lantern
setblock 100 187 487 minecraft:sea_lantern
setblock 100 187 489 minecraft:sea_lantern
fill 100 187 490 100 187 491 minecraft:sculk
setblock 101 187 484 minecraft:sea_lantern
setblock 101 187 486 minecraft:sea_lantern
setblock 101 187 488 minecraft:sea_lantern
fill 106 187 479 106 188 479 minecraft:gray_concrete
fill 106 187 481 106 188 481 minecraft:gray_concrete
fill 106 187 483 106 188 483 minecraft:gray_concrete
fill 106 187 485 106 188 485 minecraft:gray_concrete
fill 106 187 487 106 188 487 minecraft:gray_concrete
fill 106 187 489 106 188 489 minecraft:gray_concrete
fill 106 187 491 106 188 491 minecraft:gray_concrete
fill 107 187 478 107 188 478 minecraft:gray_concrete
fill 107 187 493 107 188 493 minecraft:gray_concrete
fill 109 187 478 109 188 478 minecraft:gray_concrete
fill 109 187 493 109 188 493 minecraft:gray_concrete
fill 111 187 478 111 188 478 minecraft:gray_concrete
fill 111 187 493 111 188 493 minecraft:gray_concrete
fill 113 187 478 113 188 478 minecraft:gray_concrete
fill 113 187 493 113 188 493 minecraft:gray_concrete
fill 115 187 478 115 188 478 minecraft:gray_concrete
fill 115 187 493 115 188 493 minecraft:gray_concrete
fill 117 187 478 117 188 478 minecraft:gray_concrete
fill 117 187 493 117 188 493 minecraft:gray_concrete
fill 119 187 478 119 188 478 minecraft:gray_concrete
fill 119 187 493 119 188 493 minecraft:gray_concrete
fill 121 187 479 121 188 479 minecraft:gray_concrete
fill 121 187 481 121 188 481 minecraft:gray_concrete
fill 121 187 483 121 188 483 minecraft:gray_concrete
fill 121 187 485 121 188 485 minecraft:gray_concrete
fill 121 187 487 121 188 487 minecraft:gray_concrete
fill 121 187 489 121 188 489 minecraft:gray_concrete
fill 121 187 491 121 188 491 minecraft:gray_concrete
fill 131 187 500 131 188 500 minecraft:cyan_stained_glass
setblock 132 187 499 minecraft:cyan_stained_glass
setblock 132 187 501 minecraft:cyan_stained_glass
fill 95 188 484 95 189 484 minecraft:deepslate_bricks
fill 95 188 486 95 189 486 minecraft:deepslate_bricks
fill 95 188 488 95 189 488 minecraft:deepslate_bricks
fill 96 188 483 96 189 483 minecraft:deepslate_bricks
fill 96 188 485 96 189 485 minecraft:deepslate_bricks
fill 96 188 487 96 189 487 minecraft:deepslate_bricks
fill 96 188 489 96 189 489 minecraft:deepslate_bricks
fill 97 188 484 99 189 484 minecraft:deepslate_bricks
fill 97 188 486 99 189 486 minecraft:deepslate_bricks
fill 97 188 488 101 189 488 minecraft:deepslate_bricks
fill 98 188 483 100 189 483 minecraft:deepslate_bricks
fill 98 188 485 100 189 485 minecraft:deepslate_bricks
fill 98 188 487 100 189 487 minecraft:deepslate_bricks
fill 98 188 489 100 189 489 minecraft:deepslate_bricks
fill 101 188 484 101 189 484 minecraft:deepslate_bricks
fill 101 188 486 101 189 486 minecraft:deepslate_bricks
fill 130 188 493 130 189 493 minecraft:deepslate_bricks
setblock 134 188 499 minecraft:cyan_stained_glass
setblock 135 188 500 minecraft:cyan_stained_glass
setblock 106 189 479 minecraft:black_stained_glass
setblock 106 189 481 minecraft:black_stained_glass
setblock 106 189 483 minecraft:black_stained_glass
setblock 106 189 485 minecraft:light_blue_stained_glass
setblock 106 189 487 minecraft:sea_lantern
setblock 106 189 489 minecraft:black_stained_glass
setblock 106 189 491 minecraft:sea_lantern
setblock 107 189 478 minecraft:black_stained_glass
setblock 107 189 493 minecraft:light_blue_stained_glass
setblock 109 189 478 minecraft:black_stained_glass
setblock 109 189 493 minecraft:light_blue_stained_glass
setblock 111 189 478 minecraft:sea_lantern
setblock 111 189 493 minecraft:black_stained_glass
setblock 113 189 478 minecraft:sea_lantern
setblock 113 189 493 minecraft:sea_lantern
setblock 115 189 478 minecraft:light_blue_stained_glass
setblock 115 189 493 minecraft:black_stained_glass
setblock 117 189 478 minecraft:light_blue_stained_glass
setblock 117 189 493 minecraft:black_stained_glass
setblock 119 189 478 minecraft:light_blue_stained_glass
setblock 119 189 493 minecraft:light_blue_stained_glass
setblock 121 189 479 minecraft:black_stained_glass
setblock 121 189 481 minecraft:sea_lantern
setblock 121 189 483 minecraft:light_blue_stained_glass
setblock 121 189 485 minecraft:black_stained_glass
setblock 121 189 487 minecraft:sea_lantern
setblock 121 189 489 minecraft:sea_lantern
setblock 121 189 491 minecraft:black_stained_glass
setblock 95 190 484 minecraft:sea_lantern
setblock 95 190 486 minecraft:sea_lantern
setblock 95 190 488 minecraft:sea_lantern
setblock 96 190 483 minecraft:sea_lantern
setblock 96 190 485 minecraft:sea_lantern
setblock 96 190 487 minecraft:sea_lantern
setblock 96 190 489 minecraft:sea_lantern
setblock 97 190 484 minecraft:sea_lantern
setblock 97 190 486 minecraft:sea_lantern
setblock 97 190 488 minecraft:sea_lantern
fill 98 190 480 99 191 482 minecraft:sculk
setblock 98 190 483 minecraft:sea_lantern
fill 98 190 484 98 191 484 minecraft:sculk
setblock 98 190 485 minecraft:sea_lantern
fill 98 190 486 98 191 486 minecraft:sculk
setblock 98 190 487 minecraft:sea_lantern
fill 98 190 488 98 191 488 minecraft:sculk
setblock 98 190 489 minecraft:sea_lantern
fill 99 190 477 100 191 479 minecraft:sculk
fill 99 190 483 99 191 483 minecraft:sculk
setblock 99 190 484 minecraft:sea_lantern
fill 99 190 485 99 191 485 minecraft:sculk
setblock 99 190 486 minecraft:sea_lantern
fill 99 190 487 99 191 487 minecraft:sculk
setblock 99 190 488 minecraft:sea_lantern
fill 99 190 489 99 191 491 minecraft:sculk
fill 100 190 475 101 191 476 minecraft:sculk
fill 100 190 480 100 191 480 minecraft:sculk
setblock 100 190 483 minecraft:sea_lantern
setblock 100 190 485 minecraft:sea_lantern
setblock 100 190 487 minecraft:sea_lantern
fill 100 190 488 100 191 488 minecraft:sculk
setblock 100 190 489 minecraft:sea_lantern
fill 100 190 490 100 191 493 minecraft:sculk
fill 101 190 474 103 191 474 minecraft:sculk
fill 101 190 477 101 191 477 minecraft:sculk
setblock 101 190 484 minecraft:sea_lantern
setblock 101 190 486 minecraft:sea_lantern
setblock 101 190 488 minecraft:sea_lantern
fill 101 190 491 101 191 494 minecraft:sculk
fill 102 190 473 104 191 473 minecraft:sculk
fill 102 190 475 102 191 475 minecraft:sculk
fill 102 190 493 102 191 495 minecraft:sculk
fill 103 190 472 105 191 472 minecraft:sculk
fill 103 190 494 103 191 496 minecraft:sculk
fill 104 190 471 106 191 471 minecraft:sculk
fill 104 190 495 104 191 497 minecraft:sculk
fill 105 190 470 108 191 470 minecraft:sculk
fill 105 190 496 105 191 498 minecraft:sculk
fill 106 190 469 111 191 469 minecraft:sculk
fill 106 190 479 106 193 479 minecraft:gray_concrete
fill 106 190 481 106 193 481 minecraft:gray_concrete
fill 106 190 483 106 193 483 minecraft:gray_concrete
fill 106 190 485 106 193 485 minecraft:gray_concrete
fill 106 190 487 106 193 487 minecraft:gray_concrete
fill 106 190 489 106 193 489 minecraft:gray_concrete
fill 106 190 491 106 193 491 minecraft:gray_concrete
fill 106 190 497 106 191 499 minecraft:sculk
fill 107 190 478 107 192 478 minecraft:gray_concrete
fill 107 190 493 107 193 493 minecraft:gray_concrete
fill 107 190 498 108 191 499 minecraft:sculk
fill 108 190 468 122 191 468 minecraft:sculk
fill 108 190 500 122 191 500 minecraft:sculk
fill 109 190 478 109 192 478 minecraft:gray_concrete
fill 109 190 493 109 193 493 minecraft:gray_concrete
fill 109 190 499 111 191 499 minecraft:sculk
fill 111 190 467 119 191 467 minecraft:sculk
fill 111 190 478 111 192 478 minecraft:gray_concrete
fill 111 190 493 111 193 493 minecraft:gray_concrete
fill 111 190 501 119 191 501 minecraft:sculk
fill 113 190 478 113 192 478 minecraft:gray_concrete
fill 113 190 493 113 193 493 minecraft:gray_concrete
fill 115 190 478 115 192 478 minecraft:gray_concrete
fill 115 190 493 115 193 493 minecraft:gray_concrete
fill 117 190 478 117 192 478 minecraft:gray_concrete
fill 117 190 493 117 193 493 minecraft:gray_concrete
fill 119 190 469 124 191 469 minecraft:sculk
fill 119 190 478 119 192 478 minecraft:gray_concrete
fill 119 190 493 119 193 493 minecraft:gray_concrete
fill 119 190 499 124 191 499 minecraft:sculk
fill 121 190 479 121 193 479 minecraft:gray_concrete
fill 121 190 481 121 193 481 minecraft:gray_concrete
fill 121 190 483 121 193 483 minecraft:gray_concrete
fill 121 190 485 121 193 485 minecraft:gray_concrete
fill 121 190 487 121 193 487 minecraft:gray_concrete
fill 121 190 489 121 193 489 minecraft:gray_concrete
fill 121 190 491 121 193 491 minecraft:gray_concrete
fill 122 190 470 125 191 470 minecraft:sculk
fill 122 190 498 125 191 498 minecraft:sculk
fill 124 190 471 126 191 471 minecraft:sculk
fill 124 190 497 126 191 497 minecraft:sculk
fill 125 190 472 127 191 472 minecraft:sculk
fill 125 190 496 127 191 496 minecraft:sculk
fill 126 190 473 128 191 473 minecraft:sculk
fill 126 190 495 128 191 495 minecraft:sculk
fill 127 190 474 129 191 474 minecraft:sculk
fill 127 190 494 129 191 494 minecraft:sculk
fill 128 190 475 130 191 475 minecraft:sculk
fill 128 190 493 130 191 493 minecraft:sculk
fill 129 190 476 130 191 477 minecraft:sculk
fill 129 190 491 130 191 492 minecraft:sculk
fill 130 190 478 131 191 480 minecraft:sculk
fill 130 190 488 131 191 490 minecraft:sculk
fill 131 190 477 131 191 477 minecraft:sculk
fill 131 190 481 132 191 487 minecraft:sculk
fill 131 190 491 131 191 491 minecraft:sculk
fill 132 190 480 132 191 480 minecraft:sculk
fill 132 190 488 132 191 488 minecraft:sculk
fill 95 191 484 95 192 484 minecraft:deepslate_bricks
fill 95 191 486 95 192 486 minecraft:deepslate_bricks
fill 95 191 488 95 192 488 minecraft:deepslate_bricks
fill 96 191 483 96 192 483 minecraft:deepslate_bricks
fill 96 191 485 96 192 485 minecraft:deepslate_bricks
fill 96 191 487 96 192 487 minecraft:deepslate_bricks
fill 96 191 489 96 192 489 minecraft:deepslate_bricks
setblock 97 191 466 minecraft:light[level=11]
setblock 97 191 474 minecraft:light[level=11]
setblock 97 191 482 minecraft:light[level=11]
fill 97 191 484 97 192 484 minecraft:deepslate_bricks
fill 97 191 486 97 192 486 minecraft:deepslate_bricks
fill 97 191 488 97 192 488 minecraft:deepslate_bricks
setblock 97 191 490 minecraft:light[level=11]
setblock 97 191 498 minecraft:light[level=11]
setblock 98 191 483 minecraft:sculk
setblock 98 191 485 minecraft:sculk
setblock 98 191 487 minecraft:sculk
fill 98 191 489 98 192 489 minecraft:deepslate_bricks
setblock 99 191 484 minecraft:sculk
setblock 99 191 486 minecraft:sculk
setblock 99 191 488 minecraft:sculk
fill 100 191 483 100 192 483 minecraft:deepslate_bricks
fill 100 191 485 100 192 485 minecraft:deepslate_bricks
fill 100 191 487 100 192 487 minecraft:deepslate_bricks
setblock 100 191 489 minecraft:sculk
fill 101 191 484 101 192 484 minecraft:deepslate_bricks
fill 101 191 486 101 192 486 minecraft:deepslate_bricks
fill 101 191 488 101 192 488 minecraft:deepslate_bricks
setblock 105 191 466 minecraft:light[level=11]
setblock 105 191 474 minecraft:light[level=11]
setblock 105 191 482 minecraft:light[level=11]
setblock 105 191 490 minecraft:light[level=11]
setblock 113 191 466 minecraft:light[level=11]
setblock 113 191 474 minecraft:light[level=11]
setblock 113 191 498 minecraft:light[level=11]
setblock 121 191 466 minecraft:light[level=11]
setblock 121 191 474 minecraft:light[level=11]
setblock 121 191 498 minecraft:light[level=11]
setblock 129 191 466 minecraft:light[level=11]
setblock 129 191 482 minecraft:light[level=11]
setblock 129 191 490 minecraft:light[level=11]
setblock 129 191 498 minecraft:light[level=11]
fill 94 192 469 94 205 469 minecraft:sculk
fill 94 192 470 94 192 471 minecraft:sea_lantern
fill 94 192 472 94 205 472 minecraft:sculk
fill 94 192 481 94 205 481 minecraft:sculk
fill 94 192 482 94 192 483 minecraft:sea_lantern
fill 94 192 484 94 205 484 minecraft:sculk
fill 94 192 493 94 205 493 minecraft:sculk
fill 94 192 494 94 192 495 minecraft:sea_lantern
fill 94 192 496 94 205 496 minecraft:sculk
fill 94 192 505 94 205 505 minecraft:sculk
fill 95 192 505 96 192 505 minecraft:sea_lantern
fill 97 192 505 97 205 505 minecraft:sculk
fill 98 192 483 99 192 488 minecraft:deepslate_bricks
fill 99 192 489 100 192 489 minecraft:deepslate_bricks
fill 100 192 488 100 193 488 minecraft:deepslate_bricks
fill 101 192 463 101 205 463 minecraft:sculk
fill 102 192 463 103 192 463 minecraft:sea_lantern
fill 104 192 463 104 205 463 minecraft:sculk
fill 106 192 505 106 205 505 minecraft:sculk
fill 107 192 505 108 192 505 minecraft:sea_lantern
fill 109 192 505 109 205 505 minecraft:sculk
fill 113 192 463 113 205 463 minecraft:sculk
fill 114 192 463 115 192 463 minecraft:sea_lantern
fill 116 192 463 116 205 463 minecraft:sculk
fill 118 192 505 118 205 505 minecraft:sculk
fill 119 192 505 120 192 505 minecraft:sea_lantern
fill 121 192 505 121 205 505 minecraft:sculk
fill 125 192 463 125 205 463 minecraft:sculk
fill 126 192 463 127 192 463 minecraft:sea_lantern
fill 128 192 463 128 205 463 minecraft:sculk
fill 130 192 493 130 193 493 minecraft:deepslate_bricks
fill 130 192 505 130 205 505 minecraft:sculk
fill 131 192 505 132 192 505 minecraft:sea_lantern
fill 133 192 505 133 205 505 minecraft:sculk
fill 136 192 464 136 205 464 minecraft:sculk
fill 136 192 465 136 192 466 minecraft:sea_lantern
fill 136 192 467 136 205 467 minecraft:sculk
fill 136 192 476 136 205 476 minecraft:sculk
fill 136 192 477 136 192 478 minecraft:sea_lantern
fill 136 192 479 136 205 479 minecraft:sculk
fill 136 192 488 136 205 488 minecraft:sculk
fill 136 192 489 136 192 490 minecraft:sea_lantern
fill 136 192 491 136 205 491 minecraft:sculk
fill 136 192 500 136 205 500 minecraft:sculk
fill 136 192 501 136 192 502 minecraft:sea_lantern
fill 136 192 503 136 205 503 minecraft:sculk
fill 94 193 470 94 205 471 minecraft:sculk
fill 94 193 482 94 205 483 minecraft:sculk
fill 94 193 494 94 205 495 minecraft:sculk
setblock 95 193 484 minecraft:sea_lantern
setblock 95 193 486 minecraft:sea_lantern
setblock 95 193 488 minecraft:sea_lantern
fill 95 193 505 96 205 505 minecraft:sculk
setblock 96 193 483 minecraft:sea_lantern
setblock 96 193 485 minecraft:sea_lantern
setblock 96 193 487 minecraft:sea_lantern
setblock 96 193 489 minecraft:sea_lantern
setblock 97 193 484 minecraft:sea_lantern
setblock 97 193 486 minecraft:sea_lantern
setblock 97 193 488 minecraft:sea_lantern
setblock 98 193 483 minecraft:sea_lantern
setblock 98 193 484 minecraft:deepslate_bricks
setblock 98 193 485 minecraft:sea_lantern
setblock 98 193 486 minecraft:deepslate_bricks
setblock 98 193 487 minecraft:sea_lantern
setblock 98 193 488 minecraft:deepslate_bricks
setblock 98 193 489 minecraft:sea_lantern
setblock 99 193 483 minecraft:deepslate_bricks
setblock 99 193 484 minecraft:sea_lantern
setblock 99 193 485 minecraft:deepslate_bricks
setblock 99 193 486 minecraft:sea_lantern
setblock 99 193 487 minecraft:deepslate_bricks
setblock 99 193 488 minecraft:sea_lantern
setblock 99 193 489 minecraft:deepslate_bricks
setblock 100 193 483 minecraft:sea_lantern
setblock 100 193 485 minecraft:sea_lantern
setblock 100 193 487 minecraft:sea_lantern
setblock 100 193 489 minecraft:sea_lantern
setblock 101 193 484 minecraft:sea_lantern
setblock 101 193 486 minecraft:sea_lantern
setblock 101 193 488 minecraft:sea_lantern
fill 102 193 463 103 205 463 minecraft:sculk
fill 106 193 478 121 193 478 minecraft:yellow_concrete
fill 107 193 505 108 205 505 minecraft:sculk
fill 114 193 463 115 205 463 minecraft:sculk
fill 119 193 505 120 205 505 minecraft:sculk
fill 126 193 463 127 205 463 minecraft:sculk
fill 131 193 505 132 205 505 minecraft:sculk
fill 136 193 465 136 205 466 minecraft:sculk
fill 136 193 477 136 205 478 minecraft:sculk
fill 136 193 489 136 205 490 minecraft:sculk
fill 136 193 501 136 205 502 minecraft:sculk
fill 95 194 484 95 195 484 minecraft:deepslate_bricks
fill 95 194 486 95 195 486 minecraft:deepslate_bricks
fill 95 194 488 95 195 488 minecraft:deepslate_bricks
fill 96 194 483 96 195 483 minecraft:deepslate_bricks
fill 96 194 485 96 195 485 minecraft:deepslate_bricks
fill 96 194 487 96 195 487 minecraft:deepslate_bricks
fill 96 194 489 96 195 489 minecraft:deepslate_bricks
fill 97 194 484 97 195 484 minecraft:deepslate_bricks
fill 97 194 486 97 195 486 minecraft:deepslate_bricks
fill 97 194 488 97 195 488 minecraft:deepslate_bricks
fill 98 194 480 99 195 488 minecraft:sculk
fill 98 194 489 98 195 489 minecraft:deepslate_bricks
fill 99 194 477 100 195 479 minecraft:sculk
fill 99 194 489 100 195 491 minecraft:sculk
fill 100 194 475 101 195 476 minecraft:sculk
fill 100 194 480 100 195 480 minecraft:sculk
fill 100 194 483 100 195 483 minecraft:deepslate_bricks
fill 100 194 485 100 195 485 minecraft:deepslate_bricks
fill 100 194 487 100 195 487 minecraft:deepslate_bricks
fill 100 194 488 100 195 488 minecraft:sculk
fill 100 194 492 101 195 493 minecraft:sculk
fill 101 194 474 103 195 474 minecraft:sculk
fill 101 194 477 101 195 477 minecraft:sculk
fill 101 194 484 101 195 484 minecraft:deepslate_bricks
fill 101 194 486 101 195 486 minecraft:deepslate_bricks
fill 101 194 488 101 195 488 minecraft:deepslate_bricks
fill 101 194 491 101 195 491 minecraft:sculk
fill 101 194 494 103 195 494 minecraft:sculk
fill 102 194 473 104 195 473 minecraft:sculk
fill 102 194 475 102 195 475 minecraft:sculk
fill 102 194 493 102 195 493 minecraft:sculk
fill 102 194 495 104 195 495 minecraft:sculk
fill 103 194 472 105 195 472 minecraft:sculk
fill 103 194 496 105 195 496 minecraft:sculk
fill 104 194 471 106 195 471 minecraft:sculk
fill 104 194 497 106 195 497 minecraft:sculk
fill 105 194 470 108 195 470 minecraft:sculk
fill 105 194 498 108 195 498 minecraft:sculk
fill 106 194 469 111 195 469 minecraft:sculk
fill 106 194 499 111 195 499 minecraft:sculk
fill 108 194 468 122 195 468 minecraft:sculk
fill 108 194 500 122 195 500 minecraft:sculk
fill 111 194 467 119 195 467 minecraft:sculk
fill 111 194 501 119 195 501 minecraft:sculk
fill 119 194 469 124 195 469 minecraft:sculk
fill 119 194 499 124 195 499 minecraft:sculk
fill 122 194 470 125 195 470 minecraft:sculk
fill 122 194 498 125 195 498 minecraft:sculk
fill 124 194 471 126 195 471 minecraft:sculk
fill 124 194 497 126 195 497 minecraft:sculk
fill 125 194 472 127 195 472 minecraft:sculk
fill 125 194 496 127 195 496 minecraft:sculk
fill 126 194 473 128 195 473 minecraft:sculk
fill 126 194 495 128 195 495 minecraft:sculk
fill 127 194 474 129 195 474 minecraft:sculk
fill 127 194 494 129 195 494 minecraft:sculk
fill 128 194 475 130 195 475 minecraft:sculk
fill 128 194 493 130 195 493 minecraft:sculk
fill 129 194 476 130 195 477 minecraft:sculk
fill 129 194 491 130 195 492 minecraft:sculk
fill 130 194 478 131 195 480 minecraft:sculk
fill 130 194 488 131 195 490 minecraft:sculk
fill 131 194 477 131 195 477 minecraft:sculk
fill 131 194 481 132 195 487 minecraft:sculk
fill 131 194 491 131 195 491 minecraft:sculk
fill 132 194 480 132 195 480 minecraft:sculk
fill 132 194 488 132 195 488 minecraft:sculk
setblock 95 196 484 minecraft:sea_lantern
setblock 95 196 486 minecraft:sea_lantern
setblock 95 196 488 minecraft:sea_lantern
setblock 96 196 483 minecraft:sea_lantern
setblock 96 196 485 minecraft:sea_lantern
setblock 96 196 487 minecraft:sea_lantern
setblock 96 196 489 minecraft:sea_lantern
setblock 97 196 484 minecraft:sea_lantern
setblock 97 196 486 minecraft:sea_lantern
setblock 97 196 488 minecraft:sea_lantern
setblock 98 196 483 minecraft:sea_lantern
fill 98 196 484 98 197 484 minecraft:deepslate_bricks
setblock 98 196 485 minecraft:sea_lantern
fill 98 196 486 98 197 486 minecraft:deepslate_bricks
setblock 98 196 487 minecraft:sea_lantern
fill 98 196 488 98 197 488 minecraft:deepslate_bricks
setblock 98 196 489 minecraft:sea_lantern
fill 99 196 483 99 197 483 minecraft:deepslate_bricks
setblock 99 196 484 minecraft:sea_lantern
fill 99 196 485 99 197 485 minecraft:deepslate_bricks
setblock 99 196 486 minecraft:sea_lantern
fill 99 196 487 99 197 487 minecraft:deepslate_bricks
setblock 99 196 488 minecraft:sea_lantern
fill 99 196 489 99 197 489 minecraft:deepslate_bricks
setblock 100 196 483 minecraft:sea_lantern
setblock 100 196 485 minecraft:sea_lantern
setblock 100 196 487 minecraft:sea_lantern
fill 100 196 488 100 197 488 minecraft:deepslate_bricks
setblock 100 196 489 minecraft:sea_lantern
schedule function dropper:buildpart/110_2 1t
