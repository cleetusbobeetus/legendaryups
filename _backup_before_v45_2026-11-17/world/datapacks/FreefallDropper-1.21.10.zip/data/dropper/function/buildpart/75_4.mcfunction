fill 182 51 326 182 51 328 minecraft:blue_terracotta
setblock 182 51 329 minecraft:dark_prismarine
fill 182 51 330 182 54 330 minecraft:blue_terracotta
setblock 182 51 334 minecraft:dark_prismarine
fill 182 51 335 182 54 335 minecraft:blue_terracotta
setblock 182 51 339 minecraft:dark_prismarine
fill 182 51 340 182 54 340 minecraft:blue_terracotta
setblock 182 51 344 minecraft:dark_prismarine
fill 182 51 345 182 54 345 minecraft:blue_terracotta
setblock 182 51 349 minecraft:dark_prismarine
fill 182 51 350 182 54 350 minecraft:blue_terracotta
setblock 182 51 354 minecraft:dark_prismarine
fill 182 51 355 182 54 355 minecraft:blue_terracotta
setblock 182 51 359 minecraft:dark_prismarine
fill 182 51 360 182 54 360 minecraft:blue_terracotta
setblock 142 52 323 minecraft:dark_prismarine
fill 142 52 324 142 55 324 minecraft:blue_terracotta
setblock 142 52 328 minecraft:dark_prismarine
fill 142 52 329 142 52 332 minecraft:blue_terracotta
setblock 142 52 333 minecraft:dark_prismarine
fill 142 52 334 142 52 337 minecraft:blue_terracotta
setblock 142 52 338 minecraft:dark_prismarine
fill 142 52 339 142 55 339 minecraft:blue_terracotta
setblock 142 52 343 minecraft:dark_prismarine
fill 142 52 344 142 55 344 minecraft:blue_terracotta
setblock 142 52 354 minecraft:blue_terracotta
setblock 142 52 358 minecraft:dark_prismarine
fill 142 52 359 142 55 359 minecraft:blue_terracotta
fill 142 52 361 142 52 362 minecraft:blue_terracotta
setblock 142 52 363 minecraft:dark_prismarine
fill 143 52 323 143 55 323 minecraft:blue_terracotta
setblock 143 52 327 minecraft:dark_prismarine
fill 143 52 328 143 55 328 minecraft:blue_terracotta
setblock 143 52 332 minecraft:dark_prismarine
fill 143 52 333 143 55 333 minecraft:blue_terracotta
setblock 143 52 337 minecraft:dark_prismarine
fill 143 52 338 143 55 338 minecraft:blue_terracotta
setblock 143 52 342 minecraft:dark_prismarine
fill 143 52 343 143 55 343 minecraft:blue_terracotta
setblock 143 52 357 minecraft:dark_prismarine
fill 143 52 358 143 53 358 minecraft:blue_terracotta
setblock 143 52 362 minecraft:dark_prismarine
fill 143 52 363 143 55 363 minecraft:blue_terracotta
setblock 144 52 336 minecraft:dark_prismarine
fill 144 52 337 144 53 337 minecraft:blue_terracotta
fill 144 52 362 144 55 362 minecraft:blue_terracotta
setblock 147 52 323 minecraft:dark_prismarine
setblock 147 52 363 minecraft:dark_prismarine
fill 148 52 323 148 55 323 minecraft:blue_terracotta
fill 148 52 363 151 52 363 minecraft:blue_terracotta
setblock 152 52 363 minecraft:dark_prismarine
fill 153 52 363 156 52 363 minecraft:blue_terracotta
fill 155 52 362 157 52 362 minecraft:blue_terracotta
setblock 157 52 323 minecraft:dark_prismarine
fill 157 52 361 158 52 361 minecraft:blue_terracotta
setblock 157 52 363 minecraft:dark_prismarine
fill 158 52 323 158 55 323 minecraft:blue_terracotta
setblock 158 52 362 minecraft:dark_prismarine
fill 158 52 363 161 52 363 minecraft:blue_terracotta
setblock 159 52 361 minecraft:dark_prismarine
fill 159 52 362 159 55 362 minecraft:blue_terracotta
setblock 160 52 360 minecraft:dark_prismarine
fill 160 52 361 160 55 361 minecraft:blue_terracotta
fill 161 52 356 161 83 356 minecraft:magenta_terracotta
fill 161 52 360 161 55 360 minecraft:blue_terracotta
setblock 162 52 323 minecraft:dark_prismarine
setblock 162 52 363 minecraft:dark_prismarine
fill 163 52 323 163 55 323 minecraft:blue_terracotta
setblock 163 52 362 minecraft:dark_prismarine
fill 163 52 363 163 55 363 minecraft:blue_terracotta
setblock 164 52 361 minecraft:dark_prismarine
fill 164 52 362 164 55 362 minecraft:blue_terracotta
setblock 165 52 360 minecraft:dark_prismarine
fill 165 52 361 165 55 361 minecraft:blue_terracotta
setblock 167 52 363 minecraft:dark_prismarine
setblock 168 52 362 minecraft:dark_prismarine
fill 168 52 363 168 55 363 minecraft:blue_terracotta
setblock 177 52 323 minecraft:purple_concrete
fill 179 52 363 179 54 363 minecraft:blue_terracotta
setblock 180 52 334 minecraft:blue_terracotta
setblock 180 52 335 minecraft:dark_prismarine
fill 180 52 336 180 55 336 minecraft:blue_terracotta
setblock 180 52 340 minecraft:dark_prismarine
fill 180 52 341 180 55 341 minecraft:blue_terracotta
fill 180 52 343 180 53 343 minecraft:blue_terracotta
setblock 181 52 323 minecraft:blue_terracotta
setblock 181 52 334 minecraft:dark_prismarine
fill 181 52 335 181 55 335 minecraft:blue_terracotta
setblock 181 52 339 minecraft:dark_prismarine
fill 181 52 340 181 55 340 minecraft:blue_terracotta
setblock 181 52 344 minecraft:dark_prismarine
fill 181 52 345 181 55 345 minecraft:blue_terracotta
setblock 181 52 359 minecraft:dark_prismarine
fill 181 52 360 181 55 360 minecraft:blue_terracotta
setblock 182 52 323 minecraft:dark_prismarine
fill 182 52 324 182 52 327 minecraft:blue_terracotta
setblock 182 52 328 minecraft:dark_prismarine
fill 182 52 329 182 55 329 minecraft:blue_terracotta
setblock 182 52 333 minecraft:dark_prismarine
fill 182 52 334 182 55 334 minecraft:blue_terracotta
setblock 182 52 338 minecraft:dark_prismarine
fill 182 52 339 182 55 339 minecraft:blue_terracotta
setblock 182 52 343 minecraft:dark_prismarine
fill 182 52 344 182 55 344 minecraft:blue_terracotta
setblock 182 52 348 minecraft:dark_prismarine
fill 182 52 349 182 55 349 minecraft:blue_terracotta
setblock 182 52 353 minecraft:dark_prismarine
fill 182 52 354 182 54 354 minecraft:blue_terracotta
setblock 182 52 358 minecraft:dark_prismarine
fill 182 52 359 182 55 359 minecraft:blue_terracotta
setblock 182 52 363 minecraft:dark_prismarine
fill 142 53 323 142 56 323 minecraft:blue_terracotta
setblock 142 53 327 minecraft:dark_prismarine
fill 142 53 328 142 53 331 minecraft:blue_terracotta
setblock 142 53 332 minecraft:dark_prismarine
fill 142 53 333 142 53 336 minecraft:blue_terracotta
setblock 142 53 337 minecraft:dark_prismarine
fill 142 53 338 142 56 338 minecraft:blue_terracotta
setblock 142 53 342 minecraft:dark_prismarine
fill 142 53 343 142 56 343 minecraft:blue_terracotta
setblock 142 53 349 minecraft:purple_concrete
setblock 142 53 357 minecraft:dark_prismarine
fill 142 53 358 142 56 358 minecraft:blue_terracotta
setblock 142 53 361 minecraft:blue_terracotta
setblock 142 53 362 minecraft:dark_prismarine
fill 142 53 363 142 56 363 minecraft:blue_terracotta
setblock 143 53 326 minecraft:dark_prismarine
fill 143 53 327 143 56 327 minecraft:blue_terracotta
setblock 143 53 331 minecraft:dark_prismarine
fill 143 53 332 143 55 332 minecraft:blue_terracotta
setblock 143 53 336 minecraft:dark_prismarine
fill 143 53 337 143 56 337 minecraft:blue_terracotta
setblock 143 53 341 minecraft:dark_prismarine
fill 143 53 342 143 56 342 minecraft:blue_terracotta
setblock 143 53 361 minecraft:dark_prismarine
fill 143 53 362 143 56 362 minecraft:blue_terracotta
setblock 144 53 325 minecraft:light[level=13]
setblock 144 53 332 minecraft:light[level=12]
setblock 144 53 333 minecraft:light[level=13]
fill 144 53 335 144 97 335 minecraft:dark_prismarine
setblock 144 53 336 minecraft:blue_terracotta
setblock 144 53 341 minecraft:light[level=13]
setblock 144 53 346 minecraft:light[level=12]
setblock 144 53 349 minecraft:light[level=13]
setblock 144 53 353 minecraft:light[level=12]
setblock 144 53 357 minecraft:light[level=13]
setblock 144 53 360 minecraft:light[level=12]
setblock 145 53 324 minecraft:dark_prismarine
setblock 146 53 323 minecraft:dark_prismarine
setblock 146 53 363 minecraft:dark_prismarine
fill 147 53 323 147 56 323 minecraft:blue_terracotta
setblock 147 53 362 minecraft:dark_prismarine
fill 147 53 363 150 53 363 minecraft:blue_terracotta
setblock 151 53 325 minecraft:light[level=12]
setblock 151 53 332 minecraft:light[level=12]
setblock 151 53 339 minecraft:light[level=12]
setblock 151 53 346 minecraft:light[level=12]
setblock 151 53 353 minecraft:light[level=12]
setblock 151 53 360 minecraft:light[level=12]
setblock 151 53 363 minecraft:dark_prismarine
setblock 152 53 323 minecraft:purple_concrete
setblock 152 53 325 minecraft:light[level=13]
setblock 152 53 333 minecraft:light[level=13]
setblock 152 53 341 minecraft:light[level=13]
setblock 152 53 349 minecraft:light[level=13]
setblock 152 53 357 minecraft:light[level=13]
fill 152 53 363 155 53 363 minecraft:blue_terracotta
fill 154 53 362 156 53 362 minecraft:blue_terracotta
setblock 155 53 323 minecraft:blue_terracotta
setblock 156 53 323 minecraft:dark_prismarine
setblock 156 53 363 minecraft:dark_prismarine
fill 157 53 323 157 56 323 minecraft:blue_terracotta
setblock 157 53 361 minecraft:blue_terracotta
setblock 157 53 362 minecraft:dark_prismarine
fill 157 53 363 160 53 363 minecraft:blue_terracotta
setblock 158 53 325 minecraft:light[level=12]
setblock 158 53 332 minecraft:light[level=12]
setblock 158 53 339 minecraft:light[level=12]
setblock 158 53 346 minecraft:light[level=12]
setblock 158 53 353 minecraft:light[level=12]
setblock 158 53 360 minecraft:light[level=12]
setblock 158 53 361 minecraft:dark_prismarine
fill 158 53 362 158 56 362 minecraft:blue_terracotta
fill 159 53 361 159 56 361 minecraft:blue_terracotta
setblock 160 53 325 minecraft:light[level=13]
fill 160 53 328 161 63 328 minecraft:magenta_terracotta
setblock 160 53 333 minecraft:light[level=13]
setblock 160 53 341 minecraft:light[level=13]
setblock 160 53 349 minecraft:light[level=13]
setblock 160 53 357 minecraft:light[level=13]
fill 160 53 360 160 56 360 minecraft:blue_terracotta
setblock 161 53 323 minecraft:dark_prismarine
setblock 161 53 363 minecraft:dark_prismarine
fill 162 53 323 162 56 323 minecraft:blue_terracotta
setblock 162 53 362 minecraft:dark_prismarine
fill 162 53 363 162 56 363 minecraft:blue_terracotta
fill 163 53 356 164 58 356 minecraft:magenta_terracotta
setblock 163 53 361 minecraft:dark_prismarine
fill 163 53 362 163 56 362 minecraft:blue_terracotta
setblock 164 53 360 minecraft:dark_prismarine
fill 164 53 361 164 56 361 minecraft:blue_terracotta
setblock 165 53 325 minecraft:light[level=12]
setblock 165 53 332 minecraft:light[level=12]
setblock 165 53 339 minecraft:light[level=12]
setblock 165 53 346 minecraft:light[level=12]
setblock 165 53 353 minecraft:light[level=12]
setblock 165 53 360 minecraft:light[level=12]
setblock 166 53 363 minecraft:dark_prismarine
setblock 167 53 362 minecraft:dark_prismarine
fill 167 53 363 167 56 363 minecraft:blue_terracotta
setblock 168 53 325 minecraft:light[level=13]
setblock 168 53 333 minecraft:light[level=13]
setblock 168 53 341 minecraft:light[level=13]
setblock 168 53 349 minecraft:light[level=13]
setblock 168 53 357 minecraft:light[level=13]
setblock 168 53 362 minecraft:blue_terracotta
setblock 171 53 323 minecraft:purple_concrete
setblock 172 53 325 minecraft:light[level=12]
setblock 172 53 332 minecraft:light[level=12]
setblock 172 53 339 minecraft:light[level=12]
setblock 172 53 346 minecraft:light[level=12]
setblock 172 53 353 minecraft:light[level=12]
setblock 172 53 360 minecraft:light[level=12]
setblock 172 53 363 minecraft:purple_concrete
setblock 176 53 325 minecraft:light[level=13]
setblock 176 53 333 minecraft:light[level=13]
setblock 176 53 341 minecraft:light[level=13]
fill 176 53 349 178 58 351 minecraft:magenta_terracotta
setblock 176 53 357 minecraft:light[level=13]
fill 178 53 363 178 55 363 minecraft:blue_terracotta
setblock 179 53 325 minecraft:light[level=12]
setblock 179 53 332 minecraft:light[level=12]
setblock 179 53 339 minecraft:light[level=12]
setblock 179 53 346 minecraft:light[level=12]
fill 179 53 349 179 56 349 minecraft:black_concrete
fill 179 53 350 179 56 351 minecraft:magenta_terracotta
setblock 179 53 353 minecraft:light[level=12]
setblock 179 53 360 minecraft:light[level=12]
setblock 180 53 323 minecraft:blue_terracotta
fill 180 53 335 180 56 335 minecraft:blue_terracotta
setblock 180 53 339 minecraft:dark_prismarine
fill 180 53 340 180 56 340 minecraft:blue_terracotta
fill 180 53 350 180 56 350 minecraft:black_concrete
setblock 181 53 323 minecraft:dark_prismarine
setblock 181 53 333 minecraft:dark_prismarine
fill 181 53 334 181 56 334 minecraft:blue_terracotta
setblock 181 53 338 minecraft:dark_prismarine
fill 181 53 339 181 56 339 minecraft:blue_terracotta
setblock 181 53 343 minecraft:dark_prismarine
fill 181 53 344 181 56 344 minecraft:blue_terracotta
setblock 181 53 358 minecraft:dark_prismarine
fill 181 53 359 181 55 359 minecraft:blue_terracotta
setblock 181 53 363 minecraft:dark_prismarine
fill 182 53 323 182 53 326 minecraft:blue_terracotta
setblock 182 53 327 minecraft:dark_prismarine
fill 182 53 328 182 56 328 minecraft:blue_terracotta
setblock 182 53 332 minecraft:dark_prismarine
fill 182 53 333 182 56 333 minecraft:blue_terracotta
setblock 182 53 337 minecraft:dark_prismarine
fill 182 53 338 182 56 338 minecraft:blue_terracotta
setblock 182 53 342 minecraft:dark_prismarine
fill 182 53 343 182 56 343 minecraft:blue_terracotta
setblock 182 53 347 minecraft:dark_prismarine
fill 182 53 348 182 56 348 minecraft:blue_terracotta
setblock 182 53 352 minecraft:dark_prismarine
setblock 182 53 353 minecraft:blue_terracotta
setblock 182 53 357 minecraft:dark_prismarine
fill 182 53 358 182 56 358 minecraft:blue_terracotta
setblock 182 53 362 minecraft:dark_prismarine
fill 182 53 363 182 56 363 minecraft:blue_terracotta
setblock 142 54 326 minecraft:dark_prismarine
fill 142 54 327 142 54 330 minecraft:blue_terracotta
setblock 142 54 331 minecraft:dark_prismarine
fill 142 54 332 142 54 335 minecraft:blue_terracotta
setblock 142 54 336 minecraft:dark_prismarine
fill 142 54 337 142 57 337 minecraft:blue_terracotta
setblock 142 54 341 minecraft:dark_prismarine
fill 142 54 342 142 57 342 minecraft:blue_terracotta
setblock 142 54 346 minecraft:dark_prismarine
setblock 142 54 355 minecraft:purple_concrete
setblock 142 54 356 minecraft:dark_prismarine
fill 142 54 357 142 57 357 minecraft:blue_terracotta
setblock 142 54 361 minecraft:dark_prismarine
fill 142 54 362 142 57 362 minecraft:blue_terracotta
setblock 143 54 325 minecraft:dark_prismarine
fill 143 54 326 143 57 326 minecraft:blue_terracotta
setblock 143 54 330 minecraft:dark_prismarine
fill 143 54 331 143 55 331 minecraft:blue_terracotta
setblock 143 54 335 minecraft:dark_prismarine
fill 143 54 336 143 57 336 minecraft:blue_terracotta
setblock 143 54 340 minecraft:dark_prismarine
fill 143 54 341 143 57 341 minecraft:blue_terracotta
setblock 143 54 360 minecraft:dark_prismarine
fill 143 54 361 143 57 361 minecraft:blue_terracotta
setblock 144 54 324 minecraft:dark_prismarine
fill 144 54 336 144 97 336 minecraft:dark_prismarine
setblock 145 54 323 minecraft:dark_prismarine
fill 145 54 324 145 57 324 minecraft:blue_terracotta
setblock 145 54 363 minecraft:dark_prismarine
fill 146 54 323 146 57 323 minecraft:blue_terracotta
setblock 146 54 362 minecraft:dark_prismarine
fill 146 54 363 149 54 363 minecraft:blue_terracotta
fill 147 54 362 147 57 362 minecraft:blue_terracotta
setblock 150 54 323 minecraft:dark_prismarine
setblock 150 54 363 minecraft:dark_prismarine
fill 151 54 323 151 57 323 minecraft:blue_terracotta
fill 151 54 363 154 54 363 minecraft:blue_terracotta
fill 153 54 323 154 54 323 minecraft:blue_terracotta
fill 153 54 362 155 54 362 minecraft:blue_terracotta
setblock 155 54 323 minecraft:dark_prismarine
setblock 155 54 363 minecraft:dark_prismarine
fill 156 54 323 156 57 323 minecraft:blue_terracotta
setblock 156 54 361 minecraft:blue_terracotta
setblock 156 54 362 minecraft:dark_prismarine
fill 156 54 363 159 54 363 minecraft:blue_terracotta
setblock 157 54 361 minecraft:dark_prismarine
fill 157 54 362 157 57 362 minecraft:blue_terracotta
fill 158 54 361 158 57 361 minecraft:blue_terracotta
setblock 160 54 323 minecraft:dark_prismarine
setblock 160 54 363 minecraft:dark_prismarine
fill 161 54 323 161 57 323 minecraft:blue_terracotta
setblock 161 54 362 minecraft:dark_prismarine
fill 161 54 363 161 57 363 minecraft:blue_terracotta
fill 162 54 331 162 90 331 minecraft:magenta_terracotta
fill 162 54 357 164 58 357 minecraft:magenta_terracotta
setblock 162 54 361 minecraft:dark_prismarine
fill 162 54 362 162 57 362 minecraft:blue_terracotta
setblock 163 54 360 minecraft:dark_prismarine
fill 163 54 361 163 57 361 minecraft:blue_terracotta
setblock 165 54 323 minecraft:purple_concrete
setblock 165 54 363 minecraft:dark_prismarine
setblock 166 54 362 minecraft:dark_prismarine
fill 166 54 363 166 57 363 minecraft:blue_terracotta
fill 167 54 362 167 57 362 minecraft:blue_terracotta
fill 174 54 337 176 56 337 minecraft:magenta_terracotta
fill 175 54 336 176 72 336 minecraft:magenta_terracotta
fill 177 54 363 177 56 363 minecraft:blue_terracotta
setblock 179 54 323 minecraft:blue_terracotta
setblock 180 54 323 minecraft:dark_prismarine
setblock 180 54 338 minecraft:dark_prismarine
fill 180 54 339 180 57 339 minecraft:blue_terracotta
setblock 180 54 343 minecraft:dark_prismarine
fill 180 54 344 180 57 344 minecraft:blue_terracotta
fill 180 54 349 180 56 349 minecraft:black_concrete
fill 180 54 351 180 56 351 minecraft:black_concrete
setblock 180 54 363 minecraft:dark_prismarine
fill 181 54 323 182 56 323 minecraft:blue_terracotta
setblock 181 54 332 minecraft:dark_prismarine
fill 181 54 333 181 57 333 minecraft:blue_terracotta
setblock 181 54 337 minecraft:dark_prismarine
fill 181 54 338 181 57 338 minecraft:blue_terracotta
setblock 181 54 342 minecraft:dark_prismarine
fill 181 54 343 181 57 343 minecraft:blue_terracotta
setblock 181 54 362 minecraft:dark_prismarine
fill 181 54 363 181 57 363 minecraft:blue_terracotta
fill 182 54 324 182 54 325 minecraft:blue_terracotta
setblock 182 54 326 minecraft:dark_prismarine
fill 182 54 327 182 57 327 minecraft:blue_terracotta
setblock 182 54 331 minecraft:dark_prismarine
fill 182 54 332 182 57 332 minecraft:blue_terracotta
setblock 182 54 336 minecraft:dark_prismarine
fill 182 54 337 182 57 337 minecraft:blue_terracotta
setblock 182 54 341 minecraft:dark_prismarine
fill 182 54 342 182 57 342 minecraft:blue_terracotta
setblock 182 54 346 minecraft:dark_prismarine
fill 182 54 347 182 57 347 minecraft:blue_terracotta
setblock 182 54 356 minecraft:dark_prismarine
fill 182 54 357 182 57 357 minecraft:blue_terracotta
setblock 182 54 361 minecraft:dark_prismarine
fill 182 54 362 182 57 362 minecraft:blue_terracotta
setblock 183 54 338 minecraft:light_blue_wool
fill 183 54 359 183 69 362 minecraft:black_concrete
setblock 183 54 363 minecraft:light_blue_wool
setblock 142 55 325 minecraft:dark_prismarine
fill 142 55 326 142 55 329 minecraft:blue_terracotta
setblock 142 55 330 minecraft:dark_prismarine
fill 142 55 331 142 55 334 minecraft:blue_terracotta
setblock 142 55 335 minecraft:dark_prismarine
fill 142 55 336 142 58 336 minecraft:blue_terracotta
setblock 142 55 340 minecraft:dark_prismarine
fill 142 55 341 142 58 341 minecraft:blue_terracotta
setblock 142 55 345 minecraft:dark_prismarine
fill 142 55 346 142 58 346 minecraft:blue_terracotta
setblock 142 55 356 minecraft:blue_terracotta
setblock 142 55 360 minecraft:dark_prismarine
fill 142 55 361 142 58 361 minecraft:blue_terracotta
setblock 143 55 324 minecraft:dark_prismarine
fill 143 55 325 143 58 325 minecraft:blue_terracotta
setblock 143 55 334 minecraft:dark_prismarine
fill 143 55 335 143 57 335 minecraft:blue_terracotta
setblock 143 55 339 minecraft:dark_prismarine
fill 143 55 340 143 58 340 minecraft:blue_terracotta
setblock 143 55 359 minecraft:dark_prismarine
fill 143 55 360 143 58 360 minecraft:blue_terracotta
setblock 144 55 323 minecraft:dark_prismarine
fill 144 55 324 144 58 324 minecraft:blue_terracotta
setblock 144 55 363 minecraft:dark_prismarine
fill 145 55 323 145 58 323 minecraft:blue_terracotta
setblock 145 55 362 minecraft:dark_prismarine
fill 145 55 363 148 55 363 minecraft:blue_terracotta
fill 146 55 324 146 56 324 minecraft:blue_terracotta
fill 146 55 362 146 58 362 minecraft:blue_terracotta
fill 148 55 362 148 56 362 minecraft:blue_terracotta
setblock 149 55 323 minecraft:dark_prismarine
setblock 149 55 363 minecraft:dark_prismarine
fill 150 55 323 150 58 323 minecraft:blue_terracotta
fill 150 55 363 153 55 363 minecraft:blue_terracotta
fill 152 55 323 153 55 323 minecraft:blue_terracotta
fill 152 55 362 154 55 362 minecraft:blue_terracotta
setblock 154 55 323 minecraft:dark_prismarine
setblock 154 55 363 minecraft:dark_prismarine
fill 155 55 323 155 58 323 minecraft:blue_terracotta
setblock 155 55 362 minecraft:dark_prismarine
fill 155 55 363 158 55 363 minecraft:blue_terracotta
setblock 156 55 361 minecraft:dark_prismarine
fill 156 55 362 156 58 362 minecraft:blue_terracotta
fill 157 55 361 157 58 361 minecraft:blue_terracotta
setblock 159 55 323 minecraft:dark_prismarine
fill 159 55 360 159 57 360 minecraft:blue_terracotta
setblock 159 55 363 minecraft:dark_prismarine
fill 160 55 323 160 58 323 minecraft:blue_terracotta
fill 160 55 330 161 58 330 minecraft:magenta_terracotta
setblock 160 55 362 minecraft:dark_prismarine
fill 160 55 363 160 58 363 minecraft:blue_terracotta
setblock 161 55 361 minecraft:dark_prismarine
fill 161 55 362 161 58 362 minecraft:blue_terracotta
setblock 162 55 360 minecraft:dark_prismarine
fill 162 55 361 162 58 361 minecraft:blue_terracotta
fill 163 55 329 163 84 329 minecraft:magenta_terracotta
setblock 164 55 323 minecraft:dark_prismarine
setblock 164 55 363 minecraft:dark_prismarine
fill 165 55 323 165 58 323 minecraft:blue_terracotta
fill 165 55 354 165 56 354 minecraft:sea_lantern
setblock 165 55 362 minecraft:dark_prismarine
fill 165 55 363 165 58 363 minecraft:blue_terracotta
fill 166 55 362 166 58 362 minecraft:blue_terracotta
setblock 169 55 363 minecraft:dark_prismarine
fill 176 55 363 176 57 363 minecraft:blue_terracotta
setblock 178 55 323 minecraft:blue_terracotta
fill 178 55 336 178 102 336 minecraft:magenta_terracotta
setblock 179 55 323 minecraft:dark_prismarine
fill 179 55 339 179 55 342 minecraft:blue_terracotta
setblock 179 55 362 minecraft:blue_terracotta
setblock 179 55 363 minecraft:dark_prismarine
fill 180 55 323 180 58 323 minecraft:blue_terracotta
setblock 180 55 337 minecraft:dark_prismarine
fill 180 55 338 180 58 338 minecraft:blue_terracotta
setblock 180 55 342 minecraft:dark_prismarine
fill 180 55 343 180 58 343 minecraft:blue_terracotta
fill 180 55 345 180 56 345 minecraft:blue_terracotta
setblock 180 55 362 minecraft:dark_prismarine
fill 180 55 363 180 58 363 minecraft:blue_terracotta
fill 181 55 332 181 58 332 minecraft:blue_terracotta
setblock 181 55 336 minecraft:dark_prismarine
fill 181 55 337 181 58 337 minecraft:blue_terracotta
setblock 181 55 341 minecraft:dark_prismarine
fill 181 55 342 181 58 342 minecraft:blue_terracotta
setblock 181 55 346 minecraft:dark_prismarine
fill 181 55 347 181 58 347 minecraft:blue_terracotta
setblock 181 55 361 minecraft:dark_prismarine
fill 181 55 362 181 58 362 minecraft:blue_terracotta
setblock 182 55 324 minecraft:blue_terracotta
setblock 182 55 325 minecraft:dark_prismarine
fill 182 55 326 182 58 326 minecraft:blue_terracotta
setblock 182 55 330 minecraft:dark_prismarine
fill 182 55 331 182 58 331 minecraft:blue_terracotta
setblock 182 55 335 minecraft:dark_prismarine
fill 182 55 336 182 58 336 minecraft:blue_terracotta
setblock 182 55 340 minecraft:dark_prismarine
fill 182 55 341 182 58 341 minecraft:blue_terracotta
setblock 182 55 345 minecraft:dark_prismarine
fill 182 55 346 182 58 346 minecraft:blue_terracotta
setblock 182 55 350 minecraft:dark_prismarine
setblock 182 55 355 minecraft:dark_prismarine
fill 182 55 356 182 56 356 minecraft:blue_terracotta
setblock 182 55 360 minecraft:dark_prismarine
fill 182 55 361 182 58 361 minecraft:blue_terracotta
fill 183 55 338 183 118 338 minecraft:black_concrete
setblock 183 55 352 minecraft:light_blue_wool
fill 183 55 363 183 131 363 minecraft:black_concrete
setblock 142 56 324 minecraft:dark_prismarine
fill 142 56 325 142 56 328 minecraft:blue_terracotta
setblock 142 56 329 minecraft:dark_prismarine
fill 142 56 330 142 56 333 minecraft:blue_terracotta
setblock 142 56 334 minecraft:dark_prismarine
fill 142 56 335 142 59 335 minecraft:blue_terracotta
setblock 142 56 339 minecraft:dark_prismarine
fill 142 56 340 142 59 340 minecraft:blue_terracotta
setblock 142 56 344 minecraft:dark_prismarine
fill 142 56 345 142 59 345 minecraft:blue_terracotta
fill 142 56 347 142 57 347 minecraft:blue_terracotta
setblock 142 56 348 minecraft:purple_concrete
setblock 142 56 359 minecraft:dark_prismarine
fill 142 56 360 142 59 360 minecraft:blue_terracotta
setblock 143 56 323 minecraft:dark_prismarine
fill 143 56 324 143 59 324 minecraft:blue_terracotta
setblock 143 56 328 minecraft:dark_prismarine
fill 143 56 329 143 59 329 minecraft:blue_terracotta
setblock 143 56 333 minecraft:dark_prismarine
fill 143 56 334 143 57 334 minecraft:blue_terracotta
setblock 143 56 338 minecraft:dark_prismarine
fill 143 56 339 143 59 339 minecraft:blue_terracotta
setblock 143 56 343 minecraft:dark_prismarine
fill 143 56 344 143 59 344 minecraft:blue_terracotta
fill 143 56 359 143 57 359 minecraft:blue_terracotta
setblock 143 56 363 minecraft:dark_prismarine
fill 144 56 323 144 59 323 minecraft:blue_terracotta
setblock 144 56 362 minecraft:dark_prismarine
fill 144 56 363 147 56 363 minecraft:blue_terracotta
fill 145 56 362 145 59 362 minecraft:blue_terracotta
setblock 147 56 324 minecraft:dark_prismarine
setblock 148 56 323 minecraft:dark_prismarine
setblock 148 56 363 minecraft:dark_prismarine
fill 149 56 323 149 59 323 minecraft:blue_terracotta
setblock 149 56 362 minecraft:dark_prismarine
fill 149 56 363 152 56 363 minecraft:blue_terracotta
fill 150 56 362 153 56 362 minecraft:blue_terracotta
setblock 152 56 323 minecraft:blue_terracotta
setblock 153 56 323 minecraft:dark_prismarine
setblock 153 56 363 minecraft:dark_prismarine
fill 154 56 323 154 59 323 minecraft:blue_terracotta
setblock 154 56 362 minecraft:dark_prismarine
fill 154 56 363 157 56 363 minecraft:blue_terracotta
setblock 155 56 361 minecraft:dark_prismarine
fill 155 56 362 155 59 362 minecraft:blue_terracotta
setblock 156 56 324 minecraft:blue_terracotta
fill 156 56 361 156 59 361 minecraft:blue_terracotta
setblock 157 56 324 minecraft:dark_prismarine
setblock 158 56 323 minecraft:dark_prismarine
fill 158 56 324 161 56 324 minecraft:blue_terracotta
fill 158 56 360 158 58 360 minecraft:blue_terracotta
setblock 158 56 363 minecraft:dark_prismarine
fill 159 56 323 159 59 323 minecraft:blue_terracotta
setblock 159 56 362 minecraft:dark_prismarine
fill 159 56 363 159 59 363 minecraft:blue_terracotta
setblock 160 56 361 minecraft:dark_prismarine
fill 160 56 362 160 59 362 minecraft:blue_terracotta
setblock 161 56 360 minecraft:dark_prismarine
fill 161 56 361 161 59 361 minecraft:blue_terracotta
fill 162 56 360 162 57 360 minecraft:blue_terracotta
setblock 163 56 323 minecraft:dark_prismarine
fill 163 56 330 163 83 330 minecraft:magenta_terracotta
setblock 163 56 363 minecraft:dark_prismarine
fill 164 56 323 164 59 323 minecraft:blue_terracotta
setblock 164 56 362 minecraft:dark_prismarine
fill 164 56 363 164 59 363 minecraft:blue_terracotta
setblock 164 56 364 minecraft:light_blue_wool
setblock 165 56 361 minecraft:dark_prismarine
fill 165 56 362 165 59 362 minecraft:blue_terracotta
fill 165 56 364 167 127 364 minecraft:black_concrete
setblock 168 56 363 minecraft:dark_prismarine
fill 169 56 363 169 59 363 minecraft:blue_terracotta
setblock 171 56 363 minecraft:purple_concrete
setblock 172 56 323 minecraft:purple_concrete
fill 174 56 363 175 58 363 minecraft:blue_terracotta
fill 175 56 350 175 102 350 minecraft:magenta_terracotta
fill 176 56 323 177 56 323 minecraft:blue_terracotta
setblock 178 56 323 minecraft:dark_prismarine
setblock 178 56 362 minecraft:blue_terracotta
setblock 178 56 363 minecraft:dark_prismarine
fill 179 56 323 179 58 324 minecraft:blue_terracotta
fill 179 56 338 179 56 341 minecraft:blue_terracotta
setblock 179 56 342 minecraft:dark_prismarine
fill 179 56 343 179 59 343 minecraft:blue_terracotta
setblock 179 56 362 minecraft:dark_prismarine
fill 179 56 363 179 59 363 minecraft:blue_terracotta
fill 180 56 324 181 56 324 minecraft:blue_terracotta
setblock 180 56 336 minecraft:dark_prismarine
fill 180 56 337 180 59 337 minecraft:blue_terracotta
setblock 180 56 341 minecraft:dark_prismarine
fill 180 56 342 180 59 342 minecraft:blue_terracotta
setblock 180 56 346 minecraft:dark_prismarine
fill 180 56 362 180 59 362 minecraft:blue_terracotta
setblock 181 56 325 minecraft:dark_prismarine
fill 181 56 326 181 59 326 minecraft:blue_terracotta
fill 181 56 331 181 59 331 minecraft:blue_terracotta
setblock 181 56 335 minecraft:dark_prismarine
fill 181 56 336 181 59 336 minecraft:blue_terracotta
setblock 181 56 340 minecraft:dark_prismarine
fill 181 56 341 181 59 341 minecraft:blue_terracotta
setblock 181 56 345 minecraft:dark_prismarine
fill 181 56 346 181 59 346 minecraft:blue_terracotta
fill 181 56 348 181 57 348 minecraft:blue_terracotta
setblock 181 56 360 minecraft:dark_prismarine
fill 181 56 361 181 59 361 minecraft:blue_terracotta
setblock 182 56 324 minecraft:dark_prismarine
fill 182 56 325 182 59 325 minecraft:blue_terracotta
setblock 182 56 329 minecraft:dark_prismarine
fill 182 56 330 182 59 330 minecraft:blue_terracotta
setblock 182 56 334 minecraft:dark_prismarine
fill 182 56 335 182 59 335 minecraft:blue_terracotta
setblock 182 56 339 minecraft:dark_prismarine
fill 182 56 340 182 59 340 minecraft:blue_terracotta
setblock 182 56 344 minecraft:dark_prismarine
fill 182 56 345 182 59 345 minecraft:blue_terracotta
setblock 182 56 349 minecraft:dark_prismarine
fill 182 56 350 182 59 350 minecraft:blue_terracotta
setblock 182 56 359 minecraft:dark_prismarine
fill 182 56 360 182 59 360 minecraft:blue_terracotta
fill 183 56 352 183 132 352 minecraft:black_concrete
setblock 142 57 323 minecraft:dark_prismarine
fill 142 57 324 142 57 327 minecraft:blue_terracotta
setblock 142 57 328 minecraft:dark_prismarine
fill 142 57 329 142 57 332 minecraft:blue_terracotta
setblock 142 57 333 minecraft:dark_prismarine
fill 142 57 334 142 60 334 minecraft:blue_terracotta
setblock 142 57 338 minecraft:dark_prismarine
fill 142 57 339 142 60 339 minecraft:blue_terracotta
setblock 142 57 343 minecraft:dark_prismarine
fill 142 57 344 142 60 344 minecraft:blue_terracotta
setblock 142 57 348 minecraft:dark_prismarine
setblock 142 57 354 minecraft:purple_concrete
setblock 142 57 358 minecraft:dark_prismarine
fill 142 57 359 142 60 359 minecraft:blue_terracotta
setblock 142 57 363 minecraft:dark_prismarine
fill 143 57 323 143 60 323 minecraft:blue_terracotta
setblock 143 57 327 minecraft:dark_prismarine
fill 143 57 328 143 60 328 minecraft:blue_terracotta
setblock 143 57 337 minecraft:dark_prismarine
fill 143 57 338 143 59 338 minecraft:blue_terracotta
setblock 143 57 342 minecraft:dark_prismarine
fill 143 57 343 143 60 343 minecraft:blue_terracotta
setblock 143 57 362 minecraft:dark_prismarine
fill 143 57 363 146 57 363 minecraft:blue_terracotta
fill 144 57 362 144 60 362 minecraft:blue_terracotta
setblock 146 57 324 minecraft:dark_prismarine
setblock 147 57 323 minecraft:dark_prismarine
fill 147 57 324 148 59 324 minecraft:blue_terracotta
fill 147 57 349 148 58 351 minecraft:magenta_terracotta
setblock 147 57 363 minecraft:dark_prismarine
fill 148 57 323 148 60 323 minecraft:blue_terracotta
setblock 148 57 362 minecraft:dark_prismarine
fill 148 57 363 151 57 363 minecraft:blue_terracotta
fill 149 57 349 149 71 350 minecraft:magenta_terracotta
fill 149 57 362 152 57 362 minecraft:blue_terracotta
setblock 152 57 323 minecraft:dark_prismarine
setblock 152 57 363 minecraft:dark_prismarine
fill 153 57 323 153 60 323 minecraft:blue_terracotta
setblock 153 57 362 minecraft:dark_prismarine
fill 153 57 363 156 57 363 minecraft:blue_terracotta
fill 154 57 324 155 57 324 minecraft:blue_terracotta
setblock 154 57 361 minecraft:dark_prismarine
fill 154 57 362 154 60 362 minecraft:blue_terracotta
fill 155 57 361 155 60 361 minecraft:blue_terracotta
setblock 156 57 324 minecraft:dark_prismarine
setblock 157 57 323 minecraft:dark_prismarine
fill 157 57 324 160 57 324 minecraft:blue_terracotta
fill 157 57 360 157 59 360 minecraft:blue_terracotta
setblock 157 57 363 minecraft:dark_prismarine
fill 158 57 323 158 60 323 minecraft:blue_terracotta
setblock 158 57 362 minecraft:dark_prismarine
fill 158 57 363 158 60 363 minecraft:blue_terracotta
setblock 159 57 361 minecraft:dark_prismarine
fill 159 57 362 159 60 362 minecraft:blue_terracotta
fill 160 57 329 161 58 329 minecraft:magenta_terracotta
setblock 160 57 360 minecraft:dark_prismarine
fill 160 57 361 160 60 361 minecraft:blue_terracotta
setblock 161 57 324 minecraft:dark_prismarine
fill 161 57 360 161 58 360 minecraft:blue_terracotta
setblock 162 57 323 minecraft:dark_prismarine
fill 162 57 324 162 60 324 minecraft:blue_terracotta
setblock 162 57 363 minecraft:dark_prismarine
fill 163 57 323 163 60 323 minecraft:blue_terracotta
setblock 163 57 362 minecraft:dark_prismarine
fill 163 57 363 163 60 363 minecraft:blue_terracotta
setblock 164 57 361 minecraft:dark_prismarine
fill 164 57 362 164 60 362 minecraft:blue_terracotta
fill 164 57 364 164 128 364 minecraft:black_concrete
fill 165 57 354 165 67 354 minecraft:black_concrete
setblock 166 57 323 minecraft:purple_concrete
setblock 167 57 363 minecraft:dark_prismarine
fill 168 57 363 168 60 363 minecraft:blue_terracotta
fill 170 57 363 171 57 363 minecraft:blue_terracotta
setblock 172 57 363 minecraft:dark_prismarine
fill 173 57 363 173 60 363 minecraft:blue_terracotta
fill 175 57 323 176 57 323 minecraft:blue_terracotta
fill 175 57 337 176 58 337 minecraft:magenta_terracotta
fill 176 57 335 176 67 335 minecraft:magenta_terracotta
setblock 177 57 323 minecraft:dark_prismarine
setblock 177 57 362 minecraft:blue_terracotta
setblock 177 57 363 minecraft:dark_prismarine
fill 178 57 323 178 59 324 minecraft:blue_terracotta
setblock 178 57 362 minecraft:dark_prismarine
fill 178 57 363 178 60 363 minecraft:blue_terracotta
fill 179 57 338 179 57 340 minecraft:blue_terracotta
setblock 179 57 341 minecraft:dark_prismarine
fill 179 57 342 179 60 342 minecraft:blue_terracotta
fill 179 57 344 179 58 344 minecraft:blue_terracotta
fill 179 57 350 179 61 350 minecraft:magenta_terracotta
fill 179 57 362 179 60 362 minecraft:blue_terracotta
setblock 180 57 324 minecraft:blue_terracotta
setblock 180 57 334 minecraft:blue_terracotta
setblock 180 57 335 minecraft:dark_prismarine
fill 180 57 336 180 60 336 minecraft:blue_terracotta
setblock 180 57 340 minecraft:dark_prismarine
fill 180 57 341 180 60 341 minecraft:blue_terracotta
setblock 180 57 345 minecraft:dark_prismarine
fill 180 57 346 180 59 347 minecraft:blue_terracotta
setblock 181 57 323 minecraft:blue_terracotta
setblock 181 57 324 minecraft:dark_prismarine
fill 181 57 325 181 60 325 minecraft:blue_terracotta
fill 181 57 327 181 57 328 minecraft:blue_terracotta
setblock 181 57 329 minecraft:dark_prismarine
fill 181 57 330 181 60 330 minecraft:blue_terracotta
setblock 181 57 334 minecraft:dark_prismarine
fill 181 57 335 181 60 335 minecraft:blue_terracotta
setblock 181 57 339 minecraft:dark_prismarine
fill 181 57 340 181 60 340 minecraft:blue_terracotta
setblock 181 57 344 minecraft:dark_prismarine
fill 181 57 345 181 60 345 minecraft:blue_terracotta
fill 181 57 360 181 59 360 minecraft:blue_terracotta
setblock 182 57 323 minecraft:dark_prismarine
fill 182 57 324 182 60 324 minecraft:blue_terracotta
setblock 182 57 328 minecraft:dark_prismarine
fill 182 57 329 182 60 329 minecraft:blue_terracotta
setblock 182 57 333 minecraft:dark_prismarine
fill 182 57 334 182 60 334 minecraft:blue_terracotta
setblock 182 57 338 minecraft:dark_prismarine
fill 182 57 339 182 60 339 minecraft:blue_terracotta
setblock 182 57 343 minecraft:dark_prismarine
fill 182 57 344 182 60 344 minecraft:blue_terracotta
setblock 182 57 348 minecraft:dark_prismarine
fill 182 57 349 182 60 349 minecraft:blue_terracotta
setblock 182 57 351 minecraft:purple_concrete
setblock 182 57 358 minecraft:dark_prismarine
fill 182 57 359 182 60 359 minecraft:blue_terracotta
setblock 182 57 363 minecraft:dark_prismarine
fill 142 58 323 142 58 326 minecraft:blue_terracotta
setblock 142 58 327 minecraft:dark_prismarine
fill 142 58 328 142 58 331 minecraft:blue_terracotta
setblock 142 58 332 minecraft:dark_prismarine
fill 142 58 333 142 61 333 minecraft:blue_terracotta
setblock 142 58 337 minecraft:dark_prismarine
fill 142 58 338 142 61 338 minecraft:blue_terracotta
setblock 142 58 342 minecraft:dark_prismarine
fill 142 58 343 142 61 343 minecraft:blue_terracotta
setblock 142 58 347 minecraft:dark_prismarine
fill 142 58 348 142 61 348 minecraft:blue_terracotta
setblock 142 58 357 minecraft:dark_prismarine
fill 142 58 358 142 61 358 minecraft:blue_terracotta
setblock 142 58 362 minecraft:dark_prismarine
fill 142 58 363 145 58 363 minecraft:blue_terracotta
setblock 143 58 326 minecraft:dark_prismarine
fill 143 58 327 143 61 327 minecraft:blue_terracotta
setblock 143 58 330 minecraft:blue_terracotta
setblock 143 58 336 minecraft:dark_prismarine
setblock 143 58 337 minecraft:blue_terracotta
setblock 143 58 341 minecraft:dark_prismarine
fill 143 58 342 143 60 342 minecraft:blue_terracotta
setblock 143 58 345 minecraft:blue_terracotta
setblock 143 58 361 minecraft:dark_prismarine
fill 143 58 362 143 61 362 minecraft:blue_terracotta
setblock 144 58 325 minecraft:dark_prismarine
setblock 145 58 324 minecraft:dark_prismarine
setblock 146 58 323 minecraft:dark_prismarine
fill 146 58 324 146 61 324 minecraft:blue_terracotta
fill 146 58 348 146 102 348 minecraft:magenta_terracotta
setblock 146 58 363 minecraft:dark_prismarine
fill 147 58 323 147 61 323 minecraft:blue_terracotta
setblock 147 58 362 minecraft:dark_prismarine
fill 147 58 363 150 58 363 minecraft:blue_terracotta
fill 148 58 362 151 58 362 minecraft:blue_terracotta
setblock 149 58 324 minecraft:blue_terracotta
fill 149 58 336 149 102 336 minecraft:magenta_terracotta
setblock 150 58 324 minecraft:dark_prismarine
setblock 151 58 323 minecraft:dark_prismarine
fill 151 58 324 154 58 324 minecraft:blue_terracotta
fill 151 58 352 151 59 353 minecraft:dark_prismarine
setblock 151 58 363 minecraft:dark_prismarine
fill 152 58 323 152 61 323 minecraft:blue_terracotta
setblock 152 58 362 minecraft:dark_prismarine
fill 152 58 363 155 58 363 minecraft:blue_terracotta
setblock 153 58 361 minecraft:dark_prismarine
fill 153 58 362 153 61 362 minecraft:blue_terracotta
fill 154 58 361 154 61 361 minecraft:blue_terracotta
setblock 155 58 324 minecraft:dark_prismarine
setblock 156 58 323 minecraft:dark_prismarine
fill 156 58 324 159 58 324 minecraft:blue_terracotta
setblock 156 58 363 minecraft:dark_prismarine
fill 157 58 323 157 61 323 minecraft:blue_terracotta
setblock 157 58 362 minecraft:dark_prismarine
fill 157 58 363 157 61 363 minecraft:blue_terracotta
setblock 158 58 361 minecraft:dark_prismarine
fill 158 58 362 158 61 362 minecraft:blue_terracotta
setblock 159 58 360 minecraft:dark_prismarine
fill 159 58 361 159 61 361 minecraft:blue_terracotta
setblock 160 58 324 minecraft:dark_prismarine
fill 160 58 360 160 59 360 minecraft:blue_terracotta
setblock 161 58 323 minecraft:dark_prismarine
fill 161 58 324 161 61 324 minecraft:blue_terracotta
setblock 161 58 363 minecraft:dark_prismarine
fill 162 58 323 162 61 323 minecraft:blue_terracotta
setblock 162 58 362 minecraft:dark_prismarine
fill 162 58 363 162 61 363 minecraft:blue_terracotta
fill 163 58 324 163 59 324 minecraft:blue_terracotta
setblock 163 58 361 minecraft:dark_prismarine
fill 163 58 362 163 61 362 minecraft:blue_terracotta
setblock 164 58 361 minecraft:blue_terracotta
setblock 166 58 323 minecraft:dark_prismarine
setblock 166 58 363 minecraft:dark_prismarine
fill 167 58 363 167 61 363 minecraft:blue_terracotta
setblock 170 58 363 minecraft:blue_terracotta
setblock 171 58 363 minecraft:dark_prismarine
fill 172 58 363 172 61 363 minecraft:blue_terracotta
fill 173 58 323 175 58 323 minecraft:blue_terracotta
setblock 176 58 323 minecraft:dark_prismarine
fill 176 58 324 177 60 324 minecraft:blue_terracotta
setblock 176 58 362 minecraft:blue_terracotta
setblock 176 58 363 minecraft:dark_prismarine
fill 177 58 323 177 61 323 minecraft:blue_terracotta
setblock 177 58 362 minecraft:dark_prismarine
fill 177 58 363 177 61 363 minecraft:blue_terracotta
fill 178 58 362 178 61 362 minecraft:blue_terracotta
setblock 179 58 325 minecraft:dark_prismarine
fill 179 58 337 179 58 339 minecraft:blue_terracotta
setblock 179 58 340 minecraft:dark_prismarine
fill 179 58 341 179 61 341 minecraft:blue_terracotta
setblock 179 58 345 minecraft:dark_prismarine
setblock 180 58 324 minecraft:dark_prismarine
fill 180 58 325 180 60 326 minecraft:blue_terracotta
setblock 180 58 334 minecraft:dark_prismarine
fill 180 58 335 180 61 335 minecraft:blue_terracotta
setblock 180 58 339 minecraft:dark_prismarine
fill 180 58 340 180 61 340 minecraft:blue_terracotta
setblock 180 58 344 minecraft:dark_prismarine
fill 180 58 345 180 61 345 minecraft:blue_terracotta
setblock 181 58 323 minecraft:dark_prismarine
fill 181 58 324 181 61 324 minecraft:blue_terracotta
setblock 181 58 327 minecraft:blue_terracotta
setblock 181 58 328 minecraft:dark_prismarine
fill 181 58 329 181 61 329 minecraft:blue_terracotta
setblock 181 58 333 minecraft:dark_prismarine
fill 181 58 334 181 61 334 minecraft:blue_terracotta
setblock 181 58 338 minecraft:dark_prismarine
fill 181 58 339 181 61 339 minecraft:blue_terracotta
setblock 181 58 343 minecraft:dark_prismarine
fill 181 58 344 181 61 344 minecraft:blue_terracotta
setblock 181 58 348 minecraft:dark_prismarine
fill 181 58 349 181 61 349 minecraft:blue_terracotta
setblock 181 58 363 minecraft:dark_prismarine
fill 182 58 323 182 61 323 minecraft:blue_terracotta
setblock 182 58 327 minecraft:dark_prismarine
fill 182 58 328 182 61 328 minecraft:blue_terracotta
setblock 182 58 332 minecraft:dark_prismarine
fill 182 58 333 182 61 333 minecraft:blue_terracotta
setblock 182 58 337 minecraft:dark_prismarine
fill 182 58 338 182 61 338 minecraft:blue_terracotta
setblock 182 58 342 minecraft:dark_prismarine
fill 182 58 343 182 61 343 minecraft:blue_terracotta
setblock 182 58 347 minecraft:dark_prismarine
fill 182 58 348 182 61 348 minecraft:blue_terracotta
setblock 182 58 351 minecraft:blue_terracotta
setblock 182 58 357 minecraft:dark_prismarine
fill 182 58 358 182 59 358 minecraft:blue_terracotta
setblock 182 58 362 minecraft:dark_prismarine
fill 182 58 363 182 61 363 minecraft:blue_terracotta
fill 142 59 323 142 59 325 minecraft:blue_terracotta
setblock 142 59 326 minecraft:dark_prismarine
fill 142 59 327 142 59 330 minecraft:blue_terracotta
setblock 142 59 331 minecraft:dark_prismarine
fill 142 59 332 142 62 332 minecraft:blue_terracotta
setblock 142 59 336 minecraft:dark_prismarine
fill 142 59 337 142 62 337 minecraft:blue_terracotta
setblock 142 59 341 minecraft:dark_prismarine
fill 142 59 342 142 62 342 minecraft:blue_terracotta
setblock 142 59 346 minecraft:dark_prismarine
fill 142 59 347 142 62 347 minecraft:blue_terracotta
fill 142 59 349 142 60 349 minecraft:blue_terracotta
fill 142 59 357 142 60 357 minecraft:blue_terracotta
setblock 142 59 361 minecraft:dark_prismarine
fill 142 59 362 142 61 363 minecraft:blue_terracotta
setblock 143 59 325 minecraft:dark_prismarine
fill 143 59 326 144 61 326 minecraft:blue_terracotta
setblock 143 59 330 minecraft:dark_prismarine
setblock 143 59 340 minecraft:dark_prismarine
fill 143 59 341 143 60 341 minecraft:blue_terracotta
setblock 143 59 345 minecraft:dark_prismarine
setblock 143 59 360 minecraft:dark_prismarine
fill 143 59 361 143 61 361 minecraft:blue_terracotta
fill 143 59 363 144 59 363 minecraft:blue_terracotta
setblock 144 59 324 minecraft:dark_prismarine
fill 144 59 325 145 61 325 minecraft:blue_terracotta
setblock 144 59 332 minecraft:light[level=12]
setblock 144 59 339 minecraft:light[level=12]
setblock 144 59 346 minecraft:light[level=12]
setblock 144 59 353 minecraft:light[level=12]
setblock 144 59 360 minecraft:light[level=12]
setblock 145 59 323 minecraft:dark_prismarine
fill 145 59 324 145 62 324 minecraft:blue_terracotta
fill 145 59 335 146 60 336 minecraft:magenta_terracotta
setblock 145 59 363 minecraft:dark_prismarine
fill 146 59 323 146 62 323 minecraft:blue_terracotta
setblock 146 59 362 minecraft:dark_prismarine
fill 146 59 363 149 59 363 minecraft:blue_terracotta
fill 147 59 335 147 59 336 minecraft:pink_terracotta
fill 147 59 349 148 59 349 minecraft:pink_terracotta
fill 147 59 350 147 86 351 minecraft:magenta_terracotta
fill 147 59 362 150 59 362 minecraft:blue_terracotta
fill 148 59 335 148 83 336 minecraft:magenta_terracotta
setblock 148 59 350 minecraft:pink_terracotta
fill 148 59 351 148 71 351 minecraft:magenta_terracotta
setblock 149 59 324 minecraft:dark_prismarine
setblock 150 59 323 minecraft:dark_prismarine
fill 150 59 324 153 59 324 minecraft:blue_terracotta
setblock 150 59 363 minecraft:dark_prismarine
fill 151 59 323 151 62 323 minecraft:blue_terracotta
setblock 151 59 325 minecraft:light[level=12]
setblock 151 59 332 minecraft:light[level=12]
setblock 151 59 339 minecraft:light[level=12]
setblock 151 59 346 minecraft:light[level=12]
setblock 151 59 360 minecraft:light[level=12]
setblock 151 59 362 minecraft:dark_prismarine
fill 151 59 363 154 59 363 minecraft:blue_terracotta
fill 152 59 362 152 62 362 minecraft:blue_terracotta
fill 153 59 361 153 62 361 minecraft:blue_terracotta
setblock 154 59 324 minecraft:dark_prismarine
setblock 155 59 323 minecraft:dark_prismarine
fill 155 59 324 158 59 324 minecraft:blue_terracotta
setblock 155 59 363 minecraft:dark_prismarine
fill 156 59 323 156 62 323 minecraft:blue_terracotta
fill 156 59 325 157 59 325 minecraft:blue_terracotta
fill 156 59 360 156 60 360 minecraft:blue_terracotta
setblock 156 59 362 minecraft:dark_prismarine
fill 156 59 363 156 62 363 minecraft:blue_terracotta
setblock 157 59 361 minecraft:dark_prismarine
fill 157 59 362 157 62 362 minecraft:blue_terracotta
setblock 158 59 325 minecraft:dark_prismarine
setblock 158 59 332 minecraft:light[level=12]
setblock 158 59 339 minecraft:light[level=12]
setblock 158 59 346 minecraft:light[level=12]
setblock 158 59 353 minecraft:light[level=12]
setblock 158 59 360 minecraft:dark_prismarine
fill 158 59 361 158 62 361 minecraft:blue_terracotta
setblock 159 59 324 minecraft:dark_prismarine
fill 159 59 325 159 62 325 minecraft:blue_terracotta
fill 159 59 360 159 60 360 minecraft:blue_terracotta
setblock 160 59 323 minecraft:dark_prismarine
fill 160 59 324 160 62 324 minecraft:blue_terracotta
fill 160 59 329 160 69 330 minecraft:magenta_terracotta
setblock 160 59 363 minecraft:dark_prismarine
fill 161 59 323 161 62 323 minecraft:blue_terracotta
fill 161 59 329 161 59 330 minecraft:pink_terracotta
fill 161 59 358 161 94 358 minecraft:magenta_terracotta
setblock 161 59 362 minecraft:dark_prismarine
fill 161 59 363 161 62 363 minecraft:blue_terracotta
setblock 162 59 329 minecraft:pink_terracotta
fill 162 59 356 163 59 357 minecraft:pink_terracotta
setblock 162 59 361 minecraft:dark_prismarine
fill 162 59 362 162 62 362 minecraft:blue_terracotta
fill 163 59 361 163 60 361 minecraft:blue_terracotta
fill 164 59 354 164 67 354 minecraft:black_concrete
fill 164 59 356 164 66 357 minecraft:magenta_terracotta
setblock 165 59 323 minecraft:dark_prismarine
setblock 165 59 325 minecraft:light[level=12]
setblock 165 59 332 minecraft:light[level=12]
setblock 165 59 339 minecraft:light[level=12]
setblock 165 59 346 minecraft:light[level=12]
fill 165 59 353 166 67 353 minecraft:black_concrete
fill 165 59 355 165 67 355 minecraft:black_concrete
setblock 165 59 360 minecraft:light[level=12]
setblock 165 59 363 minecraft:dark_prismarine
fill 166 59 323 166 62 323 minecraft:blue_terracotta
fill 166 59 354 166 67 354 minecraft:black_concrete
setblock 166 59 362 minecraft:dark_prismarine
fill 166 59 363 166 62 363 minecraft:blue_terracotta
setblock 170 59 363 minecraft:dark_prismarine
fill 171 59 323 174 59 323 minecraft:blue_terracotta
fill 171 59 363 171 62 363 minecraft:blue_terracotta
setblock 172 59 325 minecraft:light[level=12]
setblock 172 59 332 minecraft:light[level=12]
setblock 172 59 339 minecraft:light[level=12]
setblock 172 59 346 minecraft:light[level=12]
setblock 172 59 353 minecraft:light[level=12]
setblock 172 59 360 minecraft:light[level=12]
setblock 174 59 324 minecraft:dark_prismarine
setblock 174 59 363 minecraft:blue_terracotta
setblock 175 59 323 minecraft:dark_prismarine
fill 175 59 324 175 62 324 minecraft:blue_terracotta
fill 175 59 337 175 80 337 minecraft:magenta_terracotta
setblock 175 59 362 minecraft:blue_terracotta
setblock 175 59 363 minecraft:dark_prismarine
fill 176 59 323 176 62 323 minecraft:blue_terracotta
fill 176 59 337 177 59 337 minecraft:pink_terracotta
fill 176 59 349 176 61 352 minecraft:magenta_terracotta
setblock 176 59 362 minecraft:dark_prismarine
fill 176 59 363 176 62 363 minecraft:blue_terracotta
setblock 177 59 325 minecraft:blue_terracotta
fill 177 59 335 177 69 336 minecraft:magenta_terracotta
fill 177 59 349 178 76 349 minecraft:magenta_terracotta
fill 177 59 350 177 59 351 minecraft:pink_terracotta
fill 177 59 352 177 76 352 minecraft:magenta_terracotta
fill 177 59 362 177 62 362 minecraft:blue_terracotta
setblock 178 59 325 minecraft:dark_prismarine
fill 178 59 342 178 60 343 minecraft:blue_terracotta
fill 178 59 350 178 78 351 minecraft:magenta_terracotta
setblock 179 59 323 minecraft:blue_terracotta
setblock 179 59 324 minecraft:dark_prismarine
fill 179 59 325 179 62 325 minecraft:blue_terracotta
setblock 179 59 332 minecraft:light[level=12]
fill 179 59 337 179 59 338 minecraft:blue_terracotta
setblock 179 59 339 minecraft:dark_prismarine
fill 179 59 340 179 62 340 minecraft:blue_terracotta
setblock 179 59 344 minecraft:dark_prismarine
fill 179 59 345 179 61 346 minecraft:blue_terracotta
setblock 179 59 353 minecraft:light[level=12]
setblock 179 59 360 minecraft:light[level=12]
setblock 180 59 323 minecraft:dark_prismarine
fill 180 59 324 180 62 324 minecraft:blue_terracotta
setblock 180 59 327 minecraft:blue_terracotta
setblock 180 59 328 minecraft:dark_prismarine
fill 180 59 329 180 62 329 minecraft:blue_terracotta
fill 180 59 334 180 61 334 minecraft:blue_terracotta
setblock 180 59 338 minecraft:dark_prismarine
fill 180 59 339 180 62 339 minecraft:blue_terracotta
setblock 180 59 343 minecraft:dark_prismarine
fill 180 59 344 180 62 344 minecraft:blue_terracotta
setblock 180 59 348 minecraft:dark_prismarine
setblock 180 59 363 minecraft:dark_prismarine
fill 181 59 323 181 62 323 minecraft:blue_terracotta
setblock 181 59 327 minecraft:dark_prismarine
fill 181 59 328 181 62 328 minecraft:blue_terracotta
setblock 181 59 332 minecraft:dark_prismarine
fill 181 59 333 181 62 333 minecraft:blue_terracotta
setblock 181 59 337 minecraft:dark_prismarine
fill 181 59 338 181 62 338 minecraft:blue_terracotta
setblock 181 59 342 minecraft:dark_prismarine
fill 181 59 343 181 62 343 minecraft:blue_terracotta
setblock 181 59 347 minecraft:dark_prismarine
fill 181 59 348 181 62 348 minecraft:blue_terracotta
fill 181 59 350 181 60 350 minecraft:blue_terracotta
setblock 181 59 362 minecraft:dark_prismarine
fill 181 59 363 181 62 363 minecraft:blue_terracotta
setblock 182 59 326 minecraft:dark_prismarine
fill 182 59 327 182 62 327 minecraft:blue_terracotta
setblock 182 59 331 minecraft:dark_prismarine
fill 182 59 332 182 62 332 minecraft:blue_terracotta
setblock 182 59 336 minecraft:dark_prismarine
fill 182 59 337 182 62 337 minecraft:blue_terracotta
setblock 182 59 341 minecraft:dark_prismarine
fill 182 59 342 182 62 342 minecraft:blue_terracotta
setblock 182 59 346 minecraft:dark_prismarine
fill 182 59 347 182 62 347 minecraft:blue_terracotta
setblock 182 59 351 minecraft:dark_prismarine
setblock 182 59 361 minecraft:dark_prismarine
fill 182 59 362 182 62 362 minecraft:blue_terracotta
fill 142 60 323 142 60 324 minecraft:blue_terracotta
setblock 142 60 325 minecraft:dark_prismarine
fill 142 60 326 142 60 329 minecraft:blue_terracotta
setblock 142 60 330 minecraft:dark_prismarine
fill 142 60 331 142 63 331 minecraft:blue_terracotta
setblock 142 60 335 minecraft:dark_prismarine
fill 142 60 336 142 62 336 minecraft:blue_terracotta
setblock 142 60 340 minecraft:dark_prismarine
fill 142 60 341 142 63 341 minecraft:blue_terracotta
setblock 142 60 345 minecraft:dark_prismarine
fill 142 60 346 142 63 346 minecraft:blue_terracotta
setblock 142 60 350 minecraft:dark_prismarine
setblock 142 60 353 minecraft:purple_concrete
setblock 142 60 360 minecraft:dark_prismarine
fill 142 60 361 142 63 361 minecraft:blue_terracotta
setblock 143 60 324 minecraft:dark_prismarine
fill 143 60 325 143 63 325 minecraft:blue_terracotta
setblock 143 60 329 minecraft:dark_prismarine
fill 143 60 330 143 62 330 minecraft:blue_terracotta
setblock 143 60 340 minecraft:blue_terracotta
setblock 143 60 344 minecraft:dark_prismarine
fill 143 60 345 143 61 345 minecraft:blue_terracotta
setblock 143 60 360 minecraft:blue_terracotta
setblock 143 60 363 minecraft:blue_terracotta
setblock 144 60 323 minecraft:dark_prismarine
fill 144 60 324 144 63 324 minecraft:blue_terracotta
setblock 144 60 363 minecraft:dark_prismarine
fill 145 60 323 145 63 323 minecraft:blue_terracotta
setblock 145 60 362 minecraft:dark_prismarine
fill 145 60 363 148 60 363 minecraft:blue_terracotta
fill 146 60 362 149 60 362 minecraft:blue_terracotta
setblock 147 60 324 minecraft:blue_terracotta
fill 147 60 335 147 102 335 minecraft:magenta_terracotta
setblock 147 60 336 minecraft:pink_terracotta
fill 147 60 349 148 83 349 minecraft:magenta_terracotta
setblock 148 60 324 minecraft:dark_prismarine
fill 148 60 350 148 102 350 minecraft:magenta_terracotta
setblock 149 60 323 minecraft:dark_prismarine
fill 149 60 324 152 60 324 minecraft:blue_terracotta
fill 149 60 335 149 102 335 minecraft:magenta_terracotta
setblock 149 60 363 minecraft:dark_prismarine
fill 150 60 323 150 63 323 minecraft:blue_terracotta
setblock 150 60 362 minecraft:dark_prismarine
fill 150 60 363 153 60 363 minecraft:blue_terracotta
fill 151 60 362 151 63 362 minecraft:blue_terracotta
fill 152 60 361 152 62 361 minecraft:blue_terracotta
setblock 153 60 324 minecraft:dark_prismarine
setblock 154 60 323 minecraft:dark_prismarine
fill 154 60 324 156 60 325 minecraft:blue_terracotta
setblock 154 60 363 minecraft:dark_prismarine
fill 155 60 323 155 63 323 minecraft:blue_terracotta
setblock 155 60 362 minecraft:dark_prismarine
fill 155 60 363 155 63 363 minecraft:blue_terracotta
setblock 156 60 361 minecraft:dark_prismarine
fill 156 60 362 156 63 362 minecraft:blue_terracotta
setblock 157 60 324 minecraft:blue_terracotta
setblock 157 60 325 minecraft:dark_prismarine
setblock 157 60 360 minecraft:dark_prismarine
fill 157 60 361 157 63 361 minecraft:blue_terracotta
fill 157 60 364 157 101 364 minecraft:black_concrete
setblock 158 60 324 minecraft:dark_prismarine
fill 158 60 325 158 63 325 minecraft:blue_terracotta
fill 158 60 360 158 61 360 minecraft:blue_terracotta
fill 158 60 364 158 61 364 minecraft:light_blue_wool
setblock 159 60 323 minecraft:dark_prismarine
fill 159 60 324 159 63 324 minecraft:blue_terracotta
setblock 159 60 363 minecraft:dark_prismarine
fill 159 60 364 160 85 364 minecraft:black_concrete
fill 160 60 323 160 63 323 minecraft:blue_terracotta
fill 160 60 325 160 61 325 minecraft:blue_terracotta
setblock 160 60 362 minecraft:dark_prismarine
fill 160 60 363 160 63 363 minecraft:blue_terracotta
setblock 161 60 329 minecraft:pink_terracotta
fill 161 60 330 161 83 330 minecraft:magenta_terracotta
setblock 161 60 361 minecraft:dark_prismarine
fill 161 60 362 161 63 362 minecraft:blue_terracotta
fill 162 60 329 162 95 329 minecraft:magenta_terracotta
fill 162 60 356 163 79 357 minecraft:magenta_terracotta
fill 162 60 361 162 61 361 minecraft:blue_terracotta
setblock 163 60 324 minecraft:dark_prismarine
setblock 164 60 323 minecraft:dark_prismarine
fill 164 60 353 164 67 353 minecraft:black_concrete
fill 164 60 355 164 67 355 minecraft:black_concrete
setblock 164 60 363 minecraft:dark_prismarine
fill 165 60 323 165 62 323 minecraft:blue_terracotta
setblock 165 60 362 minecraft:dark_prismarine
fill 165 60 363 165 62 363 minecraft:blue_terracotta
fill 166 60 355 166 67 355 minecraft:black_concrete
fill 167 60 323 167 61 323 minecraft:blue_terracotta
setblock 169 60 323 minecraft:dark_prismarine
setblock 169 60 363 minecraft:dark_prismarine
fill 170 60 323 173 60 323 minecraft:blue_terracotta
fill 170 60 363 170 61 363 minecraft:blue_terracotta
setblock 173 60 324 minecraft:dark_prismarine
setblock 174 60 323 minecraft:dark_prismarine
fill 174 60 324 174 63 324 minecraft:blue_terracotta
setblock 174 60 363 minecraft:dark_prismarine
fill 175 60 323 175 63 323 minecraft:blue_terracotta
setblock 175 60 362 minecraft:dark_prismarine
fill 175 60 363 175 63 363 minecraft:blue_terracotta
setblock 176 60 325 minecraft:blue_terracotta
setblock 176 60 337 minecraft:pink_terracotta
fill 176 60 362 176 62 362 minecraft:blue_terracotta
setblock 177 60 325 minecraft:dark_prismarine
fill 177 60 337 177 83 337 minecraft:magenta_terracotta
setblock 177 60 350 minecraft:pink_terracotta
fill 177 60 351 177 96 351 minecraft:magenta_terracotta
setblock 178 60 323 minecraft:blue_terracotta
setblock 178 60 324 minecraft:dark_prismarine
fill 178 60 325 178 63 325 minecraft:blue_terracotta
fill 178 60 338 178 102 338 minecraft:magenta_terracotta
setblock 178 60 344 minecraft:dark_prismarine
setblock 179 60 323 minecraft:dark_prismarine
fill 179 60 324 179 63 324 minecraft:blue_terracotta
setblock 179 60 338 minecraft:dark_prismarine
fill 179 60 339 179 61 339 minecraft:blue_terracotta
setblock 179 60 343 minecraft:dark_prismarine
fill 179 60 344 179 63 344 minecraft:blue_terracotta
setblock 179 60 347 minecraft:blue_terracotta
setblock 179 60 363 minecraft:dark_prismarine
fill 180 60 323 180 63 323 minecraft:blue_terracotta
setblock 180 60 327 minecraft:dark_prismarine
fill 180 60 328 180 63 328 minecraft:blue_terracotta
fill 180 60 330 180 60 331 minecraft:blue_terracotta
setblock 180 60 332 minecraft:dark_prismarine
fill 180 60 333 180 61 333 minecraft:blue_terracotta
setblock 180 60 337 minecraft:dark_prismarine
fill 180 60 338 180 62 338 minecraft:blue_terracotta
setblock 180 60 342 minecraft:dark_prismarine
fill 180 60 343 180 63 343 minecraft:blue_terracotta
setblock 180 60 346 minecraft:blue_terracotta
setblock 180 60 347 minecraft:dark_prismarine
fill 180 60 348 180 63 348 minecraft:blue_terracotta
setblock 180 60 362 minecraft:dark_prismarine
fill 180 60 363 180 63 363 minecraft:blue_terracotta
setblock 181 60 326 minecraft:dark_prismarine
fill 181 60 327 181 63 327 minecraft:blue_terracotta
setblock 181 60 331 minecraft:dark_prismarine
fill 181 60 332 181 63 332 minecraft:blue_terracotta
setblock 181 60 336 minecraft:dark_prismarine
fill 181 60 337 181 63 337 minecraft:blue_terracotta
setblock 181 60 341 minecraft:dark_prismarine
fill 181 60 342 181 63 342 minecraft:blue_terracotta
setblock 181 60 346 minecraft:dark_prismarine
fill 181 60 347 181 63 347 minecraft:blue_terracotta
setblock 181 60 361 minecraft:dark_prismarine
fill 181 60 362 181 61 362 minecraft:blue_terracotta
setblock 182 60 325 minecraft:dark_prismarine
fill 182 60 326 182 63 326 minecraft:blue_terracotta
setblock 182 60 330 minecraft:dark_prismarine
fill 182 60 331 182 63 331 minecraft:blue_terracotta
setblock 182 60 335 minecraft:dark_prismarine
fill 182 60 336 182 63 336 minecraft:blue_terracotta
setblock 182 60 340 minecraft:dark_prismarine
fill 182 60 341 182 63 341 minecraft:blue_terracotta
setblock 182 60 345 minecraft:dark_prismarine
fill 182 60 346 182 63 346 minecraft:blue_terracotta
setblock 182 60 350 minecraft:dark_prismarine
fill 182 60 351 182 63 351 minecraft:blue_terracotta
setblock 182 60 358 minecraft:purple_concrete
setblock 182 60 360 minecraft:dark_prismarine
fill 182 60 361 182 62 361 minecraft:blue_terracotta
setblock 142 61 323 minecraft:blue_terracotta
setblock 142 61 324 minecraft:dark_prismarine
fill 142 61 325 142 61 328 minecraft:blue_terracotta
setblock 142 61 329 minecraft:dark_prismarine
fill 142 61 330 142 64 330 minecraft:blue_terracotta
setblock 142 61 334 minecraft:dark_prismarine
fill 142 61 335 142 62 335 minecraft:blue_terracotta
setblock 142 61 339 minecraft:dark_prismarine
fill 142 61 340 142 62 340 minecraft:blue_terracotta
setblock 142 61 344 minecraft:dark_prismarine
fill 142 61 345 142 64 345 minecraft:blue_terracotta
setblock 142 61 349 minecraft:dark_prismarine
fill 142 61 350 142 63 350 minecraft:blue_terracotta
setblock 142 61 359 minecraft:dark_prismarine
fill 142 61 360 142 63 360 minecraft:blue_terracotta
setblock 143 61 323 minecraft:dark_prismarine
fill 143 61 324 143 64 324 minecraft:blue_terracotta
setblock 143 61 328 minecraft:dark_prismarine
fill 143 61 329 143 64 329 minecraft:blue_terracotta
setblock 143 61 343 minecraft:dark_prismarine
setblock 143 61 344 minecraft:blue_terracotta
setblock 143 61 363 minecraft:dark_prismarine
fill 144 61 323 144 64 323 minecraft:blue_terracotta
setblock 144 61 333 minecraft:light[level=13]
setblock 144 61 341 minecraft:light[level=13]
setblock 144 61 349 minecraft:light[level=13]
setblock 144 61 357 minecraft:light[level=13]
setblock 144 61 362 minecraft:dark_prismarine
fill 144 61 363 147 61 363 minecraft:blue_terracotta
fill 145 61 335 145 97 335 minecraft:dark_prismarine
fill 145 61 336 147 61 336 minecraft:magenta_terracotta
fill 145 61 362 148 61 362 minecraft:blue_terracotta
fill 146 61 335 146 83 335 minecraft:magenta_terracotta
setblock 147 61 324 minecraft:dark_prismarine
setblock 148 61 323 minecraft:dark_prismarine
fill 148 61 324 151 61 324 minecraft:blue_terracotta
setblock 148 61 363 minecraft:dark_prismarine
fill 149 61 323 149 64 323 minecraft:blue_terracotta
setblock 149 61 362 minecraft:dark_prismarine
fill 149 61 363 152 61 363 minecraft:blue_terracotta
fill 150 61 362 150 64 362 minecraft:blue_terracotta
setblock 152 61 324 minecraft:dark_prismarine
fill 152 61 325 155 61 325 minecraft:blue_terracotta
setblock 152 61 333 minecraft:light[level=13]
setblock 152 61 341 minecraft:light[level=13]
setblock 152 61 349 minecraft:light[level=13]
setblock 152 61 357 minecraft:light[level=13]
setblock 153 61 323 minecraft:dark_prismarine
fill 153 61 324 156 61 324 minecraft:blue_terracotta
setblock 153 61 363 minecraft:dark_prismarine
fill 154 61 323 154 64 323 minecraft:blue_terracotta
setblock 154 61 362 minecraft:dark_prismarine
fill 154 61 363 154 64 363 minecraft:blue_terracotta
setblock 155 61 361 minecraft:dark_prismarine
fill 155 61 362 155 64 362 minecraft:blue_terracotta
setblock 156 61 325 minecraft:dark_prismarine
fill 156 61 361 156 64 361 minecraft:blue_terracotta
setblock 157 61 324 minecraft:dark_prismarine
fill 157 61 325 157 64 325 minecraft:blue_terracotta
setblock 157 61 360 minecraft:blue_terracotta
setblock 158 61 323 minecraft:dark_prismarine
fill 158 61 324 158 64 324 minecraft:blue_terracotta
setblock 158 61 363 minecraft:dark_prismarine
fill 159 61 323 159 64 323 minecraft:blue_terracotta
setblock 159 61 362 minecraft:dark_prismarine
fill 159 61 363 159 64 363 minecraft:blue_terracotta
setblock 160 61 333 minecraft:light[level=13]
setblock 160 61 341 minecraft:light[level=13]
setblock 160 61 349 minecraft:light[level=13]
setblock 160 61 357 minecraft:light[level=13]
setblock 160 61 361 minecraft:dark_prismarine
fill 160 61 362 160 64 362 minecraft:blue_terracotta
fill 161 61 329 161 82 329 minecraft:magenta_terracotta
fill 161 61 355 161 99 355 minecraft:magenta_terracotta
setblock 161 61 361 minecraft:blue_terracotta
setblock 162 61 324 minecraft:dark_prismarine
setblock 163 61 323 minecraft:dark_prismarine
setblock 163 61 324 minecraft:blue_terracotta
fill 163 61 353 163 67 354 minecraft:black_concrete
fill 163 61 358 163 70 358 minecraft:magenta_terracotta
setblock 163 61 363 minecraft:dark_prismarine
fill 164 61 323 164 63 323 minecraft:blue_terracotta
fill 164 61 352 166 67 352 minecraft:black_concrete
setblock 164 61 362 minecraft:dark_prismarine
fill 164 61 363 164 63 363 minecraft:blue_terracotta
fill 165 61 356 166 67 356 minecraft:black_concrete
fill 167 61 353 167 67 355 minecraft:black_concrete
setblock 168 61 323 minecraft:dark_prismarine
setblock 168 61 325 minecraft:light[level=13]
setblock 168 61 333 minecraft:light[level=13]
setblock 168 61 341 minecraft:light[level=13]
setblock 168 61 349 minecraft:light[level=13]
setblock 168 61 357 minecraft:light[level=13]
setblock 168 61 363 minecraft:dark_prismarine
fill 169 61 323 172 61 323 minecraft:blue_terracotta
setblock 169 61 363 minecraft:blue_terracotta
setblock 172 61 324 minecraft:dark_prismarine
setblock 173 61 323 minecraft:dark_prismarine
fill 173 61 324 173 64 324 minecraft:blue_terracotta
setblock 173 61 363 minecraft:dark_prismarine
fill 174 61 323 174 64 323 minecraft:blue_terracotta
fill 174 61 363 174 64 363 minecraft:blue_terracotta
setblock 175 61 325 minecraft:blue_terracotta
setblock 175 61 362 minecraft:blue_terracotta
setblock 175 61 364 minecraft:cyan_concrete
setblock 176 61 324 minecraft:blue_terracotta
setblock 176 61 325 minecraft:dark_prismarine
setblock 176 61 333 minecraft:light[level=13]
fill 176 61 337 176 102 337 minecraft:magenta_terracotta
setblock 176 61 341 minecraft:light[level=13]
setblock 176 61 357 minecraft:light[level=13]
setblock 177 61 324 minecraft:dark_prismarine
fill 177 61 325 177 64 325 minecraft:blue_terracotta
fill 177 61 350 177 100 350 minecraft:magenta_terracotta
setblock 178 61 323 minecraft:dark_prismarine
fill 178 61 324 178 64 324 minecraft:blue_terracotta
fill 178 61 326 179 61 326 minecraft:blue_terracotta
setblock 178 61 343 minecraft:dark_prismarine
setblock 178 61 363 minecraft:dark_prismarine
fill 179 61 323 179 64 323 minecraft:blue_terracotta
setblock 179 61 327 minecraft:dark_prismarine
setblock 179 61 342 minecraft:dark_prismarine
fill 179 61 343 179 62 343 minecraft:blue_terracotta
setblock 179 61 347 minecraft:dark_prismarine
setblock 179 61 362 minecraft:dark_prismarine
fill 179 61 363 179 64 363 minecraft:blue_terracotta
setblock 180 61 325 minecraft:blue_terracotta
setblock 180 61 326 minecraft:dark_prismarine
fill 180 61 327 180 64 327 minecraft:blue_terracotta
setblock 180 61 330 minecraft:blue_terracotta
setblock 180 61 331 minecraft:dark_prismarine
fill 180 61 332 180 62 332 minecraft:blue_terracotta
setblock 180 61 336 minecraft:dark_prismarine
fill 180 61 337 180 62 337 minecraft:blue_terracotta
setblock 180 61 341 minecraft:dark_prismarine
fill 180 61 342 180 63 342 minecraft:blue_terracotta
setblock 180 61 346 minecraft:dark_prismarine
fill 180 61 347 180 63 347 minecraft:blue_terracotta
fill 180 61 362 180 62 362 minecraft:blue_terracotta
setblock 181 61 325 minecraft:dark_prismarine
fill 181 61 326 181 64 326 minecraft:blue_terracotta
setblock 181 61 330 minecraft:dark_prismarine
fill 181 61 331 181 64 331 minecraft:blue_terracotta
setblock 181 61 335 minecraft:dark_prismarine
fill 181 61 336 181 63 336 minecraft:blue_terracotta
setblock 181 61 340 minecraft:dark_prismarine
fill 181 61 341 181 64 341 minecraft:blue_terracotta
setblock 181 61 345 minecraft:dark_prismarine
fill 181 61 346 181 64 346 minecraft:blue_terracotta
setblock 181 61 350 minecraft:dark_prismarine
setblock 182 61 324 minecraft:dark_prismarine
fill 182 61 325 182 64 325 minecraft:blue_terracotta
setblock 182 61 329 minecraft:dark_prismarine
fill 182 61 330 182 64 330 minecraft:blue_terracotta
setblock 182 61 334 minecraft:dark_prismarine
fill 182 61 335 182 64 335 minecraft:blue_terracotta
setblock 182 61 339 minecraft:dark_prismarine
fill 182 61 340 182 64 340 minecraft:blue_terracotta
setblock 182 61 344 minecraft:dark_prismarine
fill 182 61 345 182 64 345 minecraft:blue_terracotta
setblock 182 61 349 minecraft:dark_prismarine
fill 182 61 350 182 64 350 minecraft:blue_terracotta
setblock 182 61 352 minecraft:purple_concrete
setblock 182 61 360 minecraft:blue_terracotta
setblock 142 62 323 minecraft:dark_prismarine
fill 142 62 324 142 62 327 minecraft:blue_terracotta
setblock 142 62 328 minecraft:dark_prismarine
fill 142 62 329 142 65 329 minecraft:blue_terracotta
setblock 142 62 333 minecraft:dark_prismarine
setblock 142 62 334 minecraft:blue_terracotta
setblock 142 62 338 minecraft:dark_prismarine
setblock 142 62 339 minecraft:blue_terracotta
setblock 142 62 343 minecraft:dark_prismarine
fill 142 62 344 142 64 344 minecraft:blue_terracotta
setblock 142 62 348 minecraft:dark_prismarine
fill 142 62 349 142 64 349 minecraft:blue_terracotta
setblock 142 62 359 minecraft:blue_terracotta
setblock 142 62 362 minecraft:blue_terracotta
setblock 142 62 363 minecraft:dark_prismarine
fill 143 62 323 143 65 323 minecraft:blue_terracotta
setblock 143 62 326 minecraft:blue_terracotta
setblock 143 62 327 minecraft:dark_prismarine
fill 143 62 328 143 65 328 minecraft:blue_terracotta
setblock 143 62 362 minecraft:dark_prismarine
fill 143 62 363 146 62 363 minecraft:blue_terracotta
setblock 144 62 325 minecraft:blue_terracotta
setblock 144 62 326 minecraft:dark_prismarine
fill 144 62 362 147 62 362 minecraft:blue_terracotta
setblock 145 62 325 minecraft:dark_prismarine
fill 145 62 336 145 97 336 minecraft:dark_prismarine
setblock 146 62 324 minecraft:dark_prismarine
fill 146 62 336 147 85 336 minecraft:magenta_terracotta
setblock 147 62 323 minecraft:dark_prismarine
fill 147 62 324 150 62 324 minecraft:blue_terracotta
setblock 147 62 363 minecraft:dark_prismarine
fill 148 62 323 148 65 323 minecraft:blue_terracotta
setblock 148 62 362 minecraft:dark_prismarine
fill 148 62 363 151 62 363 minecraft:blue_terracotta
fill 149 62 362 149 63 362 minecraft:blue_terracotta
setblock 151 62 324 minecraft:dark_prismarine
setblock 152 62 323 minecraft:dark_prismarine
fill 152 62 324 154 62 325 minecraft:blue_terracotta
setblock 152 62 363 minecraft:dark_prismarine
fill 153 62 323 153 65 323 minecraft:blue_terracotta
setblock 153 62 362 minecraft:dark_prismarine
fill 153 62 363 153 65 363 minecraft:blue_terracotta
setblock 154 62 361 minecraft:dark_prismarine
fill 154 62 362 154 65 362 minecraft:blue_terracotta
setblock 155 62 324 minecraft:blue_terracotta
setblock 155 62 325 minecraft:dark_prismarine
fill 155 62 361 155 64 361 minecraft:blue_terracotta
setblock 156 62 324 minecraft:dark_prismarine
fill 156 62 325 156 64 325 minecraft:blue_terracotta
setblock 157 62 323 minecraft:dark_prismarine
fill 157 62 324 157 65 324 minecraft:blue_terracotta
setblock 157 62 363 minecraft:dark_prismarine
fill 158 62 323 158 65 323 minecraft:blue_terracotta
setblock 158 62 362 minecraft:dark_prismarine
fill 158 62 363 158 65 363 minecraft:blue_terracotta
fill 158 62 364 158 117 364 minecraft:black_concrete
setblock 159 62 361 minecraft:dark_prismarine
fill 159 62 362 159 64 362 minecraft:blue_terracotta
setblock 160 62 361 minecraft:blue_terracotta
setblock 161 62 324 minecraft:dark_prismarine
setblock 162 62 323 minecraft:dark_prismarine
setblock 162 62 324 minecraft:blue_terracotta
setblock 162 62 363 minecraft:dark_prismarine
fill 163 62 323 163 63 323 minecraft:blue_terracotta
fill 163 62 352 163 67 352 minecraft:black_concrete
setblock 163 62 362 minecraft:dark_prismarine
fill 163 62 363 163 63 363 minecraft:blue_terracotta
fill 167 62 352 167 67 352 minecraft:black_concrete
fill 167 62 356 167 67 356 minecraft:black_concrete
fill 168 62 323 171 62 323 minecraft:blue_terracotta
setblock 172 62 323 minecraft:dark_prismarine
fill 172 62 324 172 65 324 minecraft:blue_terracotta
setblock 172 62 363 minecraft:dark_prismarine
fill 173 62 323 173 65 323 minecraft:blue_terracotta
fill 173 62 363 173 64 363 minecraft:blue_terracotta
setblock 174 62 325 minecraft:blue_terracotta
setblock 175 62 325 minecraft:dark_prismarine
fill 175 62 364 175 131 364 minecraft:black_concrete
setblock 176 62 324 minecraft:dark_prismarine
fill 176 62 325 176 65 325 minecraft:blue_terracotta
fill 176 62 349 176 83 351 minecraft:magenta_terracotta
setblock 177 62 323 minecraft:dark_prismarine
fill 177 62 324 177 65 324 minecraft:blue_terracotta
fill 177 62 326 178 62 326 minecraft:blue_terracotta
setblock 177 62 363 minecraft:dark_prismarine
fill 178 62 323 178 65 323 minecraft:blue_terracotta
setblock 178 62 362 minecraft:dark_prismarine
fill 178 62 363 178 65 363 minecraft:blue_terracotta
setblock 179 62 326 minecraft:dark_prismarine
fill 179 62 327 179 63 328 minecraft:blue_terracotta
setblock 179 62 341 minecraft:dark_prismarine
setblock 179 62 342 minecraft:blue_terracotta
setblock 179 62 345 minecraft:blue_terracotta
setblock 179 62 346 minecraft:dark_prismarine
setblock 179 62 362 minecraft:blue_terracotta
setblock 180 62 325 minecraft:dark_prismarine
fill 180 62 326 180 65 326 minecraft:blue_terracotta
setblock 180 62 330 minecraft:dark_prismarine
fill 180 62 331 180 64 331 minecraft:blue_terracotta
setblock 180 62 340 minecraft:dark_prismarine
fill 180 62 341 180 63 341 minecraft:blue_terracotta
setblock 180 62 345 minecraft:dark_prismarine
fill 180 62 346 180 64 346 minecraft:blue_terracotta
setblock 181 62 324 minecraft:dark_prismarine
fill 181 62 325 181 65 325 minecraft:blue_terracotta
setblock 181 62 329 minecraft:dark_prismarine
fill 181 62 330 181 65 330 minecraft:blue_terracotta
setblock 181 62 334 minecraft:dark_prismarine
fill 181 62 335 181 63 335 minecraft:blue_terracotta
setblock 181 62 339 minecraft:dark_prismarine
fill 181 62 340 181 63 340 minecraft:blue_terracotta
setblock 181 62 344 minecraft:dark_prismarine
fill 181 62 345 181 64 345 minecraft:blue_terracotta
setblock 181 62 349 minecraft:dark_prismarine
setblock 181 62 350 minecraft:blue_terracotta
setblock 182 62 323 minecraft:dark_prismarine
fill 182 62 324 182 65 324 minecraft:blue_terracotta
setblock 182 62 328 minecraft:dark_prismarine
fill 182 62 329 182 65 329 minecraft:blue_terracotta
setblock 182 62 333 minecraft:dark_prismarine
fill 182 62 334 182 65 334 minecraft:blue_terracotta
setblock 182 62 338 minecraft:dark_prismarine
fill 182 62 339 182 64 339 minecraft:blue_terracotta
setblock 182 62 343 minecraft:dark_prismarine
fill 182 62 344 182 65 344 minecraft:blue_terracotta
setblock 182 62 348 minecraft:dark_prismarine
fill 182 62 349 182 65 349 minecraft:blue_terracotta
setblock 182 62 363 minecraft:dark_prismarine
fill 142 63 323 142 63 326 minecraft:blue_terracotta
setblock 142 63 327 minecraft:dark_prismarine
fill 142 63 328 142 66 328 minecraft:blue_terracotta
setblock 142 63 332 minecraft:dark_prismarine
setblock 142 63 333 minecraft:blue_terracotta
setblock 142 63 342 minecraft:dark_prismarine
setblock 142 63 343 minecraft:blue_terracotta
setblock 142 63 347 minecraft:dark_prismarine
fill 142 63 348 142 64 348 minecraft:blue_terracotta
setblock 142 63 362 minecraft:dark_prismarine
fill 142 63 363 145 63 363 minecraft:blue_terracotta
setblock 143 63 326 minecraft:dark_prismarine
fill 143 63 327 143 66 327 minecraft:blue_terracotta
setblock 144 63 325 minecraft:dark_prismarine
setblock 145 63 324 minecraft:dark_prismarine
setblock 146 63 323 minecraft:dark_prismarine
fill 146 63 324 149 63 324 minecraft:blue_terracotta
setblock 146 63 363 minecraft:dark_prismarine
fill 147 63 323 147 66 323 minecraft:blue_terracotta
fill 147 63 363 150 63 363 minecraft:blue_terracotta
setblock 150 63 324 minecraft:dark_prismarine
setblock 151 63 323 minecraft:dark_prismarine
fill 151 63 324 154 63 324 minecraft:blue_terracotta
setblock 151 63 363 minecraft:dark_prismarine
fill 152 63 323 152 66 323 minecraft:blue_terracotta
fill 152 63 325 153 63 325 minecraft:blue_terracotta
setblock 152 63 362 minecraft:dark_prismarine
fill 152 63 363 152 66 363 minecraft:blue_terracotta
setblock 153 63 361 minecraft:dark_prismarine
fill 153 63 362 153 66 362 minecraft:blue_terracotta
setblock 154 63 325 minecraft:dark_prismarine
fill 154 63 361 154 64 361 minecraft:blue_terracotta
setblock 155 63 324 minecraft:dark_prismarine
fill 155 63 325 155 65 325 minecraft:blue_terracotta
setblock 156 63 323 minecraft:dark_prismarine
fill 156 63 324 156 66 324 minecraft:blue_terracotta
setblock 156 63 363 minecraft:dark_prismarine
fill 157 63 323 157 66 323 minecraft:blue_terracotta
setblock 157 63 362 minecraft:dark_prismarine
fill 157 63 363 157 66 363 minecraft:blue_terracotta
setblock 158 63 361 minecraft:dark_prismarine
fill 158 63 362 158 65 362 minecraft:blue_terracotta
setblock 159 63 361 minecraft:blue_terracotta
setblock 160 63 324 minecraft:dark_prismarine
setblock 161 63 323 minecraft:dark_prismarine
setblock 161 63 324 minecraft:blue_terracotta
setblock 161 63 363 minecraft:dark_prismarine
fill 162 63 323 162 64 323 minecraft:blue_terracotta
fill 162 63 353 162 67 354 minecraft:black_concrete
fill 162 63 363 162 64 363 minecraft:blue_terracotta
fill 163 63 328 163 95 328 minecraft:magenta_terracotta
fill 164 63 351 166 67 351 minecraft:black_concrete
fill 165 63 357 166 67 357 minecraft:black_concrete
fill 168 63 353 168 67 355 minecraft:black_concrete
fill 169 63 323 170 63 323 minecraft:blue_terracotta
setblock 169 63 363 minecraft:purple_concrete
setblock 171 63 323 minecraft:dark_prismarine
fill 172 63 322 172 127 322 minecraft:black_concrete
fill 172 63 323 172 66 323 minecraft:blue_terracotta
setblock 172 63 363 minecraft:blue_terracotta
setblock 173 63 322 minecraft:light_blue_wool
fill 174 63 322 174 131 322 minecraft:black_concrete
setblock 174 63 325 minecraft:dark_prismarine
setblock 175 63 324 minecraft:dark_prismarine
fill 175 63 325 175 66 325 minecraft:blue_terracotta
fill 175 63 351 175 102 351 minecraft:magenta_terracotta
setblock 176 63 323 minecraft:dark_prismarine
fill 176 63 324 176 66 324 minecraft:blue_terracotta
fill 176 63 326 177 63 326 minecraft:blue_terracotta
fill 176 63 352 176 94 352 minecraft:magenta_terracotta
setblock 176 63 363 minecraft:dark_prismarine
fill 177 63 323 177 66 323 minecraft:blue_terracotta
fill 177 63 363 177 65 363 minecraft:blue_terracotta
setblock 178 63 326 minecraft:dark_prismarine
setblock 179 63 325 minecraft:dark_prismarine
fill 179 63 326 179 64 326 minecraft:blue_terracotta
setblock 179 63 345 minecraft:dark_prismarine
setblock 180 63 324 minecraft:dark_prismarine
fill 180 63 325 180 66 325 minecraft:blue_terracotta
setblock 180 63 329 minecraft:dark_prismarine
fill 180 63 330 180 65 330 minecraft:blue_terracotta
setblock 180 63 340 minecraft:blue_terracotta
setblock 180 63 344 minecraft:dark_prismarine
fill 180 63 345 180 64 345 minecraft:blue_terracotta
setblock 181 63 323 minecraft:dark_prismarine
fill 181 63 324 181 66 324 minecraft:blue_terracotta
setblock 181 63 328 minecraft:dark_prismarine
fill 181 63 329 181 66 329 minecraft:blue_terracotta
setblock 181 63 333 minecraft:dark_prismarine
setblock 181 63 334 minecraft:blue_terracotta
setblock 181 63 338 minecraft:dark_prismarine
setblock 181 63 339 minecraft:blue_terracotta
setblock 181 63 343 minecraft:dark_prismarine
fill 181 63 344 181 64 344 minecraft:blue_terracotta
setblock 181 63 348 minecraft:dark_prismarine
setblock 181 63 349 minecraft:blue_terracotta
setblock 181 63 363 minecraft:dark_prismarine
fill 182 63 323 182 66 323 minecraft:blue_terracotta
setblock 182 63 327 minecraft:dark_prismarine
fill 182 63 328 182 66 328 minecraft:blue_terracotta
setblock 182 63 332 minecraft:dark_prismarine
fill 182 63 333 182 66 333 minecraft:blue_terracotta
setblock 182 63 337 minecraft:dark_prismarine
fill 182 63 338 182 64 338 minecraft:blue_terracotta
setblock 182 63 342 minecraft:dark_prismarine
fill 182 63 343 182 65 343 minecraft:blue_terracotta
setblock 182 63 347 minecraft:dark_prismarine
fill 182 63 348 182 65 348 minecraft:blue_terracotta
setblock 182 63 359 minecraft:purple_concrete
setblock 182 63 362 minecraft:dark_prismarine
fill 182 63 363 182 64 363 minecraft:blue_terracotta
fill 142 64 323 142 64 325 minecraft:blue_terracotta
setblock 142 64 326 minecraft:dark_prismarine
fill 142 64 327 142 67 327 minecraft:blue_terracotta
setblock 142 64 331 minecraft:dark_prismarine
setblock 142 64 332 minecraft:blue_terracotta
setblock 142 64 333 minecraft:purple_concrete
setblock 142 64 346 minecraft:dark_prismarine
setblock 142 64 347 minecraft:blue_terracotta
setblock 142 64 352 minecraft:purple_concrete
setblock 142 64 361 minecraft:dark_prismarine
fill 142 64 362 142 64 363 minecraft:blue_terracotta
setblock 143 64 325 minecraft:dark_prismarine
fill 143 64 326 143 66 326 minecraft:blue_terracotta
fill 143 64 363 144 64 363 minecraft:blue_terracotta
setblock 144 64 324 minecraft:dark_prismarine
setblock 145 64 323 minecraft:dark_prismarine
fill 145 64 324 148 64 324 minecraft:blue_terracotta
setblock 145 64 363 minecraft:dark_prismarine
fill 146 64 323 146 67 323 minecraft:blue_terracotta
fill 146 64 363 149 64 363 minecraft:blue_terracotta
setblock 149 64 324 minecraft:dark_prismarine
setblock 150 64 323 minecraft:dark_prismarine
fill 150 64 324 153 64 324 minecraft:blue_terracotta
setblock 150 64 363 minecraft:dark_prismarine
fill 151 64 323 151 67 323 minecraft:blue_terracotta
setblock 151 64 362 minecraft:dark_prismarine
fill 151 64 363 151 67 363 minecraft:blue_terracotta
setblock 152 64 325 minecraft:blue_terracotta
fill 152 64 362 152 67 362 minecraft:blue_terracotta
setblock 153 64 325 minecraft:dark_prismarine
setblock 154 64 324 minecraft:dark_prismarine
fill 154 64 325 154 65 325 minecraft:blue_terracotta
setblock 155 64 323 minecraft:dark_prismarine
fill 155 64 324 155 67 324 minecraft:blue_terracotta
setblock 155 64 363 minecraft:dark_prismarine
fill 156 64 323 156 67 323 minecraft:blue_terracotta
setblock 156 64 362 minecraft:dark_prismarine
fill 156 64 363 156 67 363 minecraft:blue_terracotta
setblock 157 64 361 minecraft:dark_prismarine
fill 157 64 362 157 66 362 minecraft:blue_terracotta
setblock 159 64 324 minecraft:dark_prismarine
setblock 160 64 323 minecraft:dark_prismarine
setblock 160 64 324 minecraft:blue_terracotta
setblock 160 64 363 minecraft:dark_prismarine
fill 161 64 323 161 65 323 minecraft:blue_terracotta
fill 161 64 328 161 73 328 minecraft:magenta_terracotta
fill 161 64 363 161 65 363 minecraft:blue_terracotta
fill 162 64 352 162 67 352 minecraft:black_concrete
fill 163 64 351 163 67 351 minecraft:black_concrete
fill 167 64 351 167 67 351 minecraft:black_concrete
fill 167 64 357 167 67 357 minecraft:black_concrete
setblock 168 64 323 minecraft:purple_concrete
fill 168 64 352 168 67 352 minecraft:black_concrete
fill 168 64 356 168 67 356 minecraft:black_concrete
setblock 170 64 323 minecraft:dark_prismarine
fill 171 64 323 171 67 323 minecraft:blue_terracotta
fill 173 64 322 173 131 322 minecraft:black_concrete
setblock 173 64 325 minecraft:dark_prismarine
setblock 174 64 324 minecraft:dark_prismarine
fill 174 64 325 174 67 325 minecraft:blue_terracotta
setblock 175 64 323 minecraft:dark_prismarine
fill 175 64 324 175 67 324 minecraft:blue_terracotta
setblock 175 64 363 minecraft:dark_prismarine
fill 176 64 323 176 67 323 minecraft:blue_terracotta
setblock 176 64 326 minecraft:blue_terracotta
fill 176 64 363 176 65 363 minecraft:blue_terracotta
setblock 177 64 326 minecraft:dark_prismarine
setblock 178 64 325 minecraft:dark_prismarine
setblock 178 64 326 minecraft:blue_terracotta
setblock 179 64 324 minecraft:dark_prismarine
fill 179 64 325 179 66 325 minecraft:blue_terracotta
setblock 179 64 327 minecraft:blue_terracotta
setblock 180 64 323 minecraft:dark_prismarine
fill 180 64 324 180 67 324 minecraft:blue_terracotta
setblock 180 64 328 minecraft:dark_prismarine
fill 180 64 329 180 67 329 minecraft:blue_terracotta
setblock 180 64 344 minecraft:blue_terracotta
setblock 180 64 363 minecraft:dark_prismarine
fill 181 64 323 181 67 323 minecraft:blue_terracotta
setblock 181 64 327 minecraft:dark_prismarine
fill 181 64 328 181 67 328 minecraft:blue_terracotta
setblock 181 64 332 minecraft:dark_prismarine
setblock 181 64 333 minecraft:blue_terracotta
setblock 181 64 342 minecraft:dark_prismarine
setblock 181 64 343 minecraft:blue_terracotta
setblock 181 64 347 minecraft:dark_prismarine
setblock 181 64 348 minecraft:blue_terracotta
setblock 181 64 363 minecraft:blue_terracotta
setblock 182 64 326 minecraft:dark_prismarine
fill 182 64 327 182 67 327 minecraft:blue_terracotta
setblock 182 64 331 minecraft:dark_prismarine
fill 182 64 332 182 67 332 minecraft:blue_terracotta
setblock 182 64 336 minecraft:dark_prismarine
setblock 182 64 337 minecraft:blue_terracotta
setblock 182 64 341 minecraft:dark_prismarine
fill 182 64 342 182 65 342 minecraft:blue_terracotta
setblock 182 64 346 minecraft:dark_prismarine
fill 182 64 347 182 65 347 minecraft:blue_terracotta
setblock 182 64 353 minecraft:purple_concrete
setblock 142 65 322 minecraft:cyan_concrete
fill 142 65 323 142 65 324 minecraft:blue_terracotta
setblock 142 65 325 minecraft:dark_prismarine
fill 142 65 326 142 68 326 minecraft:blue_terracotta
setblock 142 65 330 minecraft:dark_prismarine
fill 142 65 331 142 66 331 minecraft:blue_terracotta
setblock 142 65 339 minecraft:purple_concrete
setblock 142 65 358 minecraft:purple_concrete
fill 142 65 363 143 65 363 minecraft:blue_terracotta
fill 143 65 322 144 74 322 minecraft:black_concrete
setblock 143 65 324 minecraft:dark_prismarine
fill 143 65 325 143 66 325 minecraft:blue_terracotta
setblock 144 65 323 minecraft:dark_prismarine
fill 144 65 324 147 65 324 minecraft:blue_terracotta
setblock 144 65 325 minecraft:light[level=12]
setblock 144 65 332 minecraft:light[level=12]
setblock 144 65 339 minecraft:light[level=12]
setblock 144 65 346 minecraft:light[level=12]
setblock 144 65 353 minecraft:light[level=12]
setblock 144 65 360 minecraft:light[level=12]
setblock 144 65 363 minecraft:dark_prismarine
fill 145 65 323 145 67 323 minecraft:blue_terracotta
fill 145 65 363 148 65 363 minecraft:blue_terracotta
setblock 148 65 324 minecraft:dark_prismarine
setblock 149 65 323 minecraft:dark_prismarine
fill 149 65 324 152 65 324 minecraft:blue_terracotta
setblock 149 65 363 minecraft:dark_prismarine
fill 150 65 323 150 68 323 minecraft:blue_terracotta
fill 150 65 363 150 68 363 minecraft:blue_terracotta
setblock 151 65 325 minecraft:light[level=12]
setblock 151 65 332 minecraft:light[level=12]
setblock 151 65 339 minecraft:light[level=12]
setblock 151 65 346 minecraft:light[level=12]
setblock 151 65 353 minecraft:light[level=12]
setblock 151 65 360 minecraft:light[level=12]
fill 151 65 362 151 66 362 minecraft:blue_terracotta
setblock 153 65 324 minecraft:dark_prismarine
setblock 153 65 325 minecraft:blue_terracotta
setblock 154 65 323 minecraft:dark_prismarine
fill 154 65 324 154 68 324 minecraft:blue_terracotta
setblock 154 65 363 minecraft:dark_prismarine
fill 155 65 323 155 68 323 minecraft:blue_terracotta
setblock 155 65 362 minecraft:dark_prismarine
fill 155 65 363 155 68 363 minecraft:blue_terracotta
fill 156 65 362 156 66 362 minecraft:blue_terracotta
setblock 158 65 324 minecraft:dark_prismarine
setblock 158 65 325 minecraft:light[level=12]
setblock 158 65 332 minecraft:light[level=12]
setblock 158 65 339 minecraft:light[level=12]
setblock 158 65 346 minecraft:light[level=12]
setblock 158 65 353 minecraft:light[level=12]
setblock 158 65 360 minecraft:light[level=12]
setblock 159 65 323 minecraft:dark_prismarine
setblock 159 65 324 minecraft:blue_terracotta
setblock 159 65 363 minecraft:dark_prismarine
setblock 160 65 323 minecraft:blue_terracotta
setblock 160 65 363 minecraft:blue_terracotta
fill 161 65 353 161 67 354 minecraft:black_concrete
setblock 162 65 323 minecraft:purple_concrete
fill 162 65 351 162 67 351 minecraft:black_concrete
setblock 162 65 363 minecraft:purple_concrete
fill 164 65 350 166 67 350 minecraft:black_concrete
fill 164 65 358 166 67 358 minecraft:black_concrete
setblock 165 65 325 minecraft:light[level=12]
setblock 165 65 332 minecraft:light[level=12]
setblock 165 65 339 minecraft:light[level=12]
setblock 165 65 346 minecraft:light[level=12]
setblock 165 65 360 minecraft:light[level=12]
fill 168 65 351 168 67 351 minecraft:black_concrete
fill 168 65 357 168 67 357 minecraft:black_concrete
fill 169 65 353 169 67 355 minecraft:black_concrete
fill 170 65 323 170 66 323 minecraft:blue_terracotta
setblock 172 65 325 minecraft:light[level=12]
setblock 172 65 332 minecraft:light[level=12]
setblock 172 65 339 minecraft:light[level=12]
setblock 172 65 346 minecraft:light[level=12]
setblock 172 65 353 minecraft:light[level=12]
setblock 172 65 360 minecraft:light[level=12]
setblock 173 65 324 minecraft:dark_prismarine
setblock 173 65 325 minecraft:blue_terracotta
setblock 174 65 323 minecraft:dark_prismarine
fill 174 65 324 174 68 324 minecraft:blue_terracotta
setblock 174 65 363 minecraft:dark_prismarine
fill 175 65 323 175 68 323 minecraft:blue_terracotta
setblock 175 65 363 minecraft:blue_terracotta
setblock 177 65 325 minecraft:dark_prismarine
setblock 177 65 326 minecraft:blue_terracotta
setblock 178 65 324 minecraft:dark_prismarine
fill 178 65 325 178 67 325 minecraft:blue_terracotta
setblock 179 65 323 minecraft:dark_prismarine
fill 179 65 324 179 68 324 minecraft:blue_terracotta
setblock 179 65 332 minecraft:light[level=12]
setblock 179 65 339 minecraft:light[level=12]
setblock 179 65 346 minecraft:light[level=12]
setblock 179 65 353 minecraft:light[level=12]
setblock 179 65 360 minecraft:light[level=12]
setblock 179 65 363 minecraft:dark_prismarine
fill 180 65 323 180 68 323 minecraft:blue_terracotta
setblock 180 65 327 minecraft:dark_prismarine
fill 180 65 328 180 67 328 minecraft:blue_terracotta
setblock 181 65 326 minecraft:dark_prismarine
fill 181 65 327 181 68 327 minecraft:blue_terracotta
setblock 181 65 331 minecraft:dark_prismarine
fill 181 65 332 181 66 332 minecraft:blue_terracotta
setblock 181 65 346 minecraft:dark_prismarine
setblock 181 65 363 minecraft:purple_concrete
setblock 182 65 325 minecraft:dark_prismarine
fill 182 65 326 182 68 326 minecraft:blue_terracotta
setblock 182 65 330 minecraft:dark_prismarine
fill 182 65 331 182 68 331 minecraft:blue_terracotta
setblock 182 65 345 minecraft:dark_prismarine
setblock 182 65 346 minecraft:blue_terracotta
fill 142 66 322 142 76 322 minecraft:black_concrete
setblock 142 66 323 minecraft:blue_terracotta
setblock 142 66 324 minecraft:dark_prismarine
fill 142 66 325 142 69 325 minecraft:blue_terracotta
setblock 142 66 329 minecraft:dark_prismarine
fill 142 66 330 142 69 330 minecraft:blue_terracotta
setblock 142 66 345 minecraft:purple_concrete
setblock 143 66 323 minecraft:dark_prismarine
setblock 143 66 324 minecraft:blue_terracotta
setblock 143 66 363 minecraft:purple_concrete
fill 144 66 323 144 67 323 minecraft:blue_terracotta
setblock 146 66 322 minecraft:light_blue_wool
setblock 147 66 363 minecraft:blue_terracotta
setblock 148 66 323 minecraft:dark_prismarine
setblock 148 66 363 minecraft:dark_prismarine
fill 149 66 323 149 66 324 minecraft:blue_terracotta
fill 149 66 363 149 69 363 minecraft:blue_terracotta
fill 150 66 324 151 66 324 minecraft:blue_terracotta
setblock 152 66 324 minecraft:dark_prismarine
setblock 153 66 323 minecraft:dark_prismarine
fill 153 66 324 153 68 324 minecraft:blue_terracotta
setblock 153 66 363 minecraft:dark_prismarine
fill 154 66 323 154 69 323 minecraft:blue_terracotta
setblock 154 66 362 minecraft:dark_prismarine
fill 154 66 363 154 69 363 minecraft:blue_terracotta
fill 155 66 362 155 67 362 minecraft:blue_terracotta
setblock 157 66 324 minecraft:dark_prismarine
setblock 158 66 323 minecraft:dark_prismarine
setblock 158 66 363 minecraft:dark_prismarine
setblock 159 66 323 minecraft:blue_terracotta
setblock 159 66 363 minecraft:blue_terracotta
fill 161 66 352 161 67 352 minecraft:black_concrete
fill 163 66 331 163 102 331 minecraft:magenta_terracotta
fill 163 66 350 163 67 350 minecraft:black_concrete
fill 167 66 350 167 67 350 minecraft:black_concrete
fill 167 66 358 167 67 358 minecraft:black_concrete
setblock 168 66 363 minecraft:purple_concrete
fill 169 66 352 169 67 352 minecraft:black_concrete
fill 169 66 356 169 67 356 minecraft:black_concrete
setblock 172 66 324 minecraft:dark_prismarine
setblock 173 66 323 minecraft:dark_prismarine
fill 173 66 324 173 69 324 minecraft:blue_terracotta
fill 174 66 323 174 69 323 minecraft:blue_terracotta
fill 175 66 349 175 102 349 minecraft:magenta_terracotta
setblock 176 66 325 minecraft:dark_prismarine
setblock 177 66 324 minecraft:dark_prismarine
fill 177 66 325 177 68 325 minecraft:blue_terracotta
setblock 178 66 323 minecraft:dark_prismarine
fill 178 66 324 178 69 324 minecraft:blue_terracotta
fill 179 66 323 179 69 323 minecraft:blue_terracotta
setblock 180 66 326 minecraft:dark_prismarine
fill 180 66 327 180 67 327 minecraft:blue_terracotta
setblock 181 66 325 minecraft:dark_prismarine
fill 181 66 326 181 69 326 minecraft:blue_terracotta
setblock 181 66 330 minecraft:dark_prismarine
fill 181 66 331 181 69 331 minecraft:blue_terracotta
setblock 182 66 324 minecraft:dark_prismarine
fill 182 66 325 182 69 325 minecraft:blue_terracotta
setblock 182 66 329 minecraft:dark_prismarine
fill 182 66 330 182 69 330 minecraft:blue_terracotta
setblock 182 66 341 minecraft:purple_concrete
fill 182 66 360 182 67 360 minecraft:purple_concrete
setblock 142 67 323 minecraft:dark_prismarine
fill 142 67 324 142 69 324 minecraft:blue_terracotta
setblock 142 67 328 minecraft:dark_prismarine
fill 142 67 329 142 70 329 minecraft:blue_terracotta
setblock 142 67 351 minecraft:purple_concrete
fill 143 67 323 143 68 323 minecraft:blue_terracotta
fill 146 67 322 146 131 322 minecraft:black_concrete
setblock 147 67 323 minecraft:dark_prismarine
fill 148 67 323 149 69 323 minecraft:blue_terracotta
fill 148 67 348 148 102 348 minecraft:magenta_terracotta
fill 148 67 363 148 70 363 minecraft:blue_terracotta
setblock 150 67 324 minecraft:blue_terracotta
setblock 151 67 322 minecraft:cyan_concrete
setblock 151 67 324 minecraft:dark_prismarine
setblock 152 67 323 minecraft:dark_prismarine
fill 152 67 324 152 68 324 minecraft:blue_terracotta
setblock 152 67 363 minecraft:dark_prismarine
fill 153 67 323 153 70 323 minecraft:blue_terracotta
setblock 153 67 362 minecraft:dark_prismarine
fill 153 67 363 153 70 363 minecraft:blue_terracotta
setblock 154 67 362 minecraft:blue_terracotta
setblock 156 67 324 minecraft:dark_prismarine
setblock 157 67 323 minecraft:dark_prismarine
setblock 157 67 363 minecraft:dark_prismarine
setblock 158 67 323 minecraft:blue_terracotta
setblock 158 67 363 minecraft:blue_terracotta
fill 160 67 353 160 67 355 minecraft:black_concrete
fill 160 67 356 160 84 357 minecraft:magenta_terracotta
setblock 161 67 351 minecraft:black_concrete
setblock 162 67 350 minecraft:black_concrete
fill 164 67 349 167 67 349 minecraft:black_concrete
fill 164 67 356 164 67 357 minecraft:black_concrete
fill 164 67 359 166 67 359 minecraft:black_concrete
setblock 168 67 350 minecraft:black_concrete
setblock 168 67 358 minecraft:black_concrete
setblock 169 67 323 minecraft:purple_concrete
setblock 169 67 351 minecraft:black_concrete
setblock 169 67 357 minecraft:black_concrete
fill 170 67 353 170 67 355 minecraft:black_concrete
setblock 172 67 323 minecraft:dark_prismarine
fill 172 67 324 172 70 324 minecraft:blue_terracotta
fill 173 67 323 173 70 323 minecraft:blue_terracotta
setblock 174 67 363 minecraft:purple_concrete
setblock 175 67 325 minecraft:dark_prismarine
setblock 176 67 324 minecraft:dark_prismarine
fill 176 67 325 176 68 325 minecraft:blue_terracotta
setblock 177 67 323 minecraft:dark_prismarine
fill 177 67 324 177 70 324 minecraft:blue_terracotta
fill 178 67 323 178 70 323 minecraft:blue_terracotta
setblock 181 67 324 minecraft:dark_prismarine
fill 181 67 325 181 68 325 minecraft:blue_terracotta
setblock 181 67 329 minecraft:dark_prismarine
fill 181 67 330 181 70 330 minecraft:blue_terracotta
setblock 182 67 323 minecraft:dark_prismarine
fill 182 67 324 182 70 324 minecraft:blue_terracotta
setblock 182 67 328 minecraft:dark_prismarine
fill 182 67 329 182 70 329 minecraft:blue_terracotta
setblock 182 67 333 minecraft:dark_prismarine
setblock 182 67 335 minecraft:purple_concrete
setblock 182 67 354 minecraft:purple_concrete
setblock 142 68 323 minecraft:blue_terracotta
setblock 142 68 327 minecraft:dark_prismarine
fill 142 68 328 142 71 328 minecraft:blue_terracotta
setblock 142 68 332 minecraft:purple_concrete
fill 142 68 338 142 69 338 minecraft:purple_concrete
setblock 142 68 357 minecraft:purple_concrete
setblock 144 68 323 minecraft:purple_concrete
setblock 146 68 323 minecraft:dark_prismarine
fill 147 68 323 147 71 323 minecraft:blue_terracotta
fill 147 68 334 148 86 334 minecraft:magenta_terracotta
fill 151 68 322 151 114 322 minecraft:black_concrete
setblock 151 68 323 minecraft:dark_prismarine
setblock 151 68 324 minecraft:blue_terracotta
setblock 151 68 363 minecraft:dark_prismarine
fill 152 68 323 152 71 323 minecraft:blue_terracotta
fill 152 68 363 152 71 363 minecraft:blue_terracotta
setblock 153 68 362 minecraft:blue_terracotta
setblock 156 68 323 minecraft:dark_prismarine
setblock 156 68 363 minecraft:dark_prismarine
setblock 157 68 323 minecraft:blue_terracotta
setblock 157 68 363 minecraft:blue_terracotta
setblock 161 68 363 minecraft:purple_concrete
setblock 163 68 323 minecraft:purple_concrete
fill 163 68 354 163 71 354 minecraft:dark_prismarine
setblock 165 68 322 minecraft:cyan_concrete
fill 165 68 355 165 71 355 minecraft:dark_prismarine
fill 166 68 353 166 72 353 minecraft:dark_prismarine
setblock 171 68 323 minecraft:dark_prismarine
fill 172 68 323 172 71 323 minecraft:blue_terracotta
setblock 174 68 325 minecraft:dark_prismarine
setblock 175 68 324 minecraft:dark_prismarine
fill 175 68 325 175 69 325 minecraft:blue_terracotta
setblock 176 68 323 minecraft:dark_prismarine
fill 176 68 324 176 71 324 minecraft:blue_terracotta
fill 177 68 323 177 71 323 minecraft:blue_terracotta
fill 177 68 339 177 69 339 minecraft:magenta_terracotta
setblock 180 68 324 minecraft:dark_prismarine
setblock 180 68 363 minecraft:purple_concrete
setblock 181 68 323 minecraft:dark_prismarine
setblock 181 68 328 minecraft:dark_prismarine
fill 181 68 329 181 71 329 minecraft:blue_terracotta
fill 182 68 323 182 69 323 minecraft:blue_terracotta
setblock 182 68 327 minecraft:dark_prismarine
fill 182 68 328 182 71 328 minecraft:blue_terracotta
setblock 182 68 332 minecraft:dark_prismarine
fill 182 68 333 182 71 333 minecraft:blue_terracotta
setblock 182 68 348 minecraft:purple_concrete
setblock 142 69 326 minecraft:dark_prismarine
fill 142 69 327 142 72 327 minecraft:blue_terracotta
setblock 142 69 344 minecraft:purple_concrete
setblock 142 69 363 minecraft:purple_concrete
setblock 144 69 325 minecraft:light[level=13]
setblock 144 69 333 minecraft:light[level=13]
setblock 144 69 341 minecraft:light[level=13]
setblock 144 69 349 minecraft:light[level=13]
setblock 144 69 357 minecraft:light[level=13]
setblock 150 69 323 minecraft:dark_prismarine
setblock 150 69 363 minecraft:dark_prismarine
fill 151 69 323 151 72 323 minecraft:blue_terracotta
fill 151 69 363 151 72 363 minecraft:blue_terracotta
setblock 152 69 325 minecraft:light[level=13]
setblock 152 69 333 minecraft:light[level=13]
setblock 152 69 341 minecraft:light[level=13]
setblock 152 69 349 minecraft:light[level=13]
setblock 152 69 357 minecraft:light[level=13]
setblock 155 69 323 minecraft:dark_prismarine
setblock 155 69 363 minecraft:dark_prismarine
setblock 156 69 363 minecraft:blue_terracotta
setblock 157 69 323 minecraft:purple_concrete
setblock 160 69 325 minecraft:light[level=13]
setblock 160 69 333 minecraft:light[level=13]
setblock 160 69 341 minecraft:light[level=13]
setblock 160 69 349 minecraft:light[level=13]
fill 165 69 322 165 131 322 minecraft:black_concrete
setblock 167 69 363 minecraft:purple_concrete
setblock 168 69 325 minecraft:light[level=13]
setblock 168 69 333 minecraft:light[level=13]
setblock 168 69 341 minecraft:light[level=13]
setblock 168 69 349 minecraft:light[level=13]
setblock 168 69 357 minecraft:light[level=13]
fill 171 69 323 171 72 323 minecraft:blue_terracotta
setblock 174 69 324 minecraft:dark_prismarine
setblock 174 69 325 minecraft:blue_terracotta
setblock 175 69 323 minecraft:dark_prismarine
fill 175 69 324 175 72 324 minecraft:blue_terracotta
fill 176 69 323 176 72 323 minecraft:blue_terracotta
setblock 176 69 325 minecraft:light[level=13]
setblock 176 69 333 minecraft:light[level=13]
setblock 176 69 341 minecraft:light[level=13]
setblock 176 69 357 minecraft:light[level=13]
setblock 180 69 323 minecraft:dark_prismarine
fill 181 69 323 181 70 323 minecraft:blue_terracotta
setblock 181 69 327 minecraft:dark_prismarine
fill 181 69 328 181 72 328 minecraft:blue_terracotta
setblock 181 69 364 minecraft:light_blue_wool
setblock 182 69 326 minecraft:dark_prismarine
fill 182 69 327 182 72 327 minecraft:blue_terracotta
setblock 182 69 331 minecraft:dark_prismarine
fill 182 69 332 182 72 332 minecraft:blue_terracotta
setblock 182 69 342 minecraft:purple_concrete
setblock 142 70 325 minecraft:dark_prismarine
fill 142 70 326 142 73 326 minecraft:blue_terracotta
setblock 142 70 330 minecraft:dark_prismarine
setblock 142 70 350 minecraft:purple_concrete
fill 147 70 363 147 71 363 minecraft:blue_terracotta
setblock 148 70 323 minecraft:blue_terracotta
setblock 149 70 323 minecraft:dark_prismarine
setblock 149 70 363 minecraft:dark_prismarine
fill 150 70 323 150 73 323 minecraft:blue_terracotta
fill 150 70 363 150 73 363 minecraft:blue_terracotta
fill 152 70 362 152 72 362 minecraft:blue_terracotta
setblock 154 70 323 minecraft:dark_prismarine
setblock 154 70 363 minecraft:dark_prismarine
setblock 155 70 323 minecraft:blue_terracotta
fill 155 70 363 155 73 363 minecraft:blue_terracotta
fill 170 70 323 170 73 323 minecraft:blue_terracotta
setblock 173 70 324 minecraft:dark_prismarine
setblock 173 70 363 minecraft:purple_concrete
setblock 174 70 323 minecraft:dark_prismarine
fill 174 70 324 174 73 324 minecraft:blue_terracotta
fill 175 70 323 175 73 323 minecraft:blue_terracotta
fill 177 70 336 177 102 336 minecraft:magenta_terracotta
setblock 178 70 324 minecraft:dark_prismarine
setblock 179 70 323 minecraft:dark_prismarine
fill 180 70 323 180 73 323 minecraft:blue_terracotta
setblock 181 70 326 minecraft:dark_prismarine
fill 181 70 327 181 73 327 minecraft:blue_terracotta
setblock 181 70 331 minecraft:dark_prismarine
fill 181 70 332 181 73 332 minecraft:blue_terracotta
fill 181 70 364 181 131 364 minecraft:black_concrete
setblock 182 70 325 minecraft:dark_prismarine
fill 182 70 326 182 73 326 minecraft:blue_terracotta
setblock 182 70 330 minecraft:dark_prismarine
fill 182 70 331 182 73 331 minecraft:blue_terracotta
setblock 182 70 334 minecraft:blue_terracotta
setblock 182 70 336 minecraft:purple_concrete
setblock 182 70 361 minecraft:purple_concrete
fill 183 70 359 183 127 360 minecraft:black_concrete
setblock 183 70 361 minecraft:light_blue_wool
fill 183 70 362 183 76 362 minecraft:black_concrete
setblock 141 71 336 minecraft:cyan_concrete
setblock 142 71 325 minecraft:blue_terracotta
setblock 142 71 329 minecraft:dark_prismarine
fill 142 71 330 142 73 331 minecraft:blue_terracotta
fill 142 71 351 142 71 353 minecraft:blue_terracotta
setblock 142 71 354 minecraft:dark_prismarine
fill 142 71 355 142 74 355 minecraft:blue_terracotta
setblock 142 71 356 minecraft:purple_concrete
setblock 142 71 364 minecraft:cyan_concrete
setblock 144 71 325 minecraft:light[level=12]
setblock 144 71 332 minecraft:light[level=12]
setblock 144 71 339 minecraft:light[level=12]
setblock 144 71 346 minecraft:light[level=12]
setblock 144 71 353 minecraft:light[level=12]
setblock 144 71 360 minecraft:light[level=12]
setblock 145 71 323 minecraft:purple_concrete
fill 146 71 363 146 72 363 minecraft:blue_terracotta
setblock 148 71 323 minecraft:dark_prismarine
setblock 148 71 363 minecraft:dark_prismarine
fill 149 71 323 149 74 323 minecraft:blue_terracotta
fill 149 71 363 149 74 363 minecraft:blue_terracotta
fill 150 71 362 151 73 362 minecraft:blue_terracotta
setblock 151 71 325 minecraft:light[level=12]
setblock 151 71 332 minecraft:light[level=12]
setblock 151 71 339 minecraft:light[level=12]
setblock 151 71 346 minecraft:light[level=12]
setblock 151 71 353 minecraft:light[level=12]
setblock 151 71 360 minecraft:light[level=12]
setblock 153 71 323 minecraft:dark_prismarine
setblock 153 71 362 minecraft:blue_terracotta
setblock 153 71 363 minecraft:dark_prismarine
setblock 154 71 323 minecraft:blue_terracotta
fill 154 71 363 154 74 363 minecraft:blue_terracotta
setblock 158 71 325 minecraft:light[level=12]
setblock 158 71 332 minecraft:light[level=12]
setblock 158 71 339 minecraft:light[level=12]
setblock 158 71 346 minecraft:light[level=12]
setblock 158 71 353 minecraft:light[level=12]
setblock 158 71 360 minecraft:light[level=12]
fill 159 71 322 160 129 322 minecraft:black_concrete
setblock 161 71 322 minecraft:cyan_concrete
fill 164 71 330 164 102 330 minecraft:magenta_terracotta
setblock 165 71 325 minecraft:light[level=12]
setblock 165 71 332 minecraft:light[level=12]
setblock 165 71 339 minecraft:light[level=12]
setblock 165 71 346 minecraft:light[level=12]
setblock 165 71 353 minecraft:light[level=12]
setblock 165 71 360 minecraft:light[level=12]
setblock 171 71 324 minecraft:blue_terracotta
setblock 172 71 324 minecraft:dark_prismarine
setblock 172 71 325 minecraft:light[level=12]
setblock 172 71 332 minecraft:light[level=12]
setblock 172 71 339 minecraft:light[level=12]
setblock 172 71 346 minecraft:light[level=12]
setblock 172 71 353 minecraft:light[level=12]
setblock 172 71 360 minecraft:light[level=12]
setblock 173 71 323 minecraft:dark_prismarine
fill 173 71 324 173 74 324 minecraft:blue_terracotta
fill 174 71 323 174 74 323 minecraft:blue_terracotta
setblock 177 71 324 minecraft:dark_prismarine
fill 177 71 339 177 102 339 minecraft:magenta_terracotta
setblock 178 71 323 minecraft:dark_prismarine
fill 179 71 323 179 74 323 minecraft:blue_terracotta
setblock 179 71 325 minecraft:light[level=12]
setblock 179 71 332 minecraft:light[level=12]
setblock 179 71 339 minecraft:light[level=12]
setblock 179 71 346 minecraft:light[level=12]
setblock 179 71 353 minecraft:light[level=12]
setblock 179 71 360 minecraft:light[level=12]
setblock 179 71 363 minecraft:purple_concrete
setblock 181 71 330 minecraft:dark_prismarine
fill 181 71 331 181 74 331 minecraft:blue_terracotta
setblock 182 71 324 minecraft:dark_prismarine
fill 182 71 325 182 74 325 minecraft:blue_terracotta
setblock 182 71 329 minecraft:dark_prismarine
fill 182 71 330 182 74 330 minecraft:blue_terracotta
setblock 182 71 334 minecraft:dark_prismarine
setblock 182 71 355 minecraft:purple_concrete
setblock 183 71 351 minecraft:light_blue_wool
fill 183 71 361 183 132 361 minecraft:black_concrete
fill 141 72 336 141 132 336 minecraft:black_concrete
setblock 142 72 328 minecraft:dark_prismarine
fill 142 72 329 142 75 329 minecraft:blue_terracotta
setblock 142 72 332 minecraft:blue_terracotta
setblock 142 72 337 minecraft:purple_concrete
fill 142 72 351 142 72 352 minecraft:blue_terracotta
setblock 142 72 353 minecraft:dark_prismarine
fill 142 72 354 142 75 354 minecraft:blue_terracotta
fill 142 72 356 142 72 357 minecraft:blue_terracotta
setblock 142 72 358 minecraft:dark_prismarine
setblock 142 72 362 minecraft:purple_concrete
fill 142 72 364 142 81 364 minecraft:black_concrete
fill 145 72 363 145 73 363 minecraft:blue_terracotta
setblock 146 72 323 minecraft:blue_terracotta
setblock 147 72 323 minecraft:dark_prismarine
setblock 147 72 363 minecraft:dark_prismarine
fill 148 72 323 148 75 323 minecraft:blue_terracotta
setblock 148 72 362 minecraft:dark_prismarine
fill 148 72 363 148 75 363 minecraft:blue_terracotta
fill 149 72 349 149 77 349 minecraft:magenta_terracotta
fill 149 72 362 149 75 362 minecraft:blue_terracotta
setblock 152 72 323 minecraft:dark_prismarine
setblock 152 72 363 minecraft:dark_prismarine
fill 153 72 323 153 74 323 minecraft:blue_terracotta
fill 153 72 357 153 86 357 minecraft:green_terracotta
setblock 153 72 362 minecraft:dark_prismarine
fill 153 72 363 153 75 363 minecraft:blue_terracotta
setblock 160 72 363 minecraft:purple_concrete
fill 161 72 322 161 131 322 minecraft:black_concrete
setblock 164 72 323 minecraft:purple_concrete
fill 164 72 329 164 102 329 minecraft:magenta_terracotta
fill 169 72 323 169 74 323 minecraft:blue_terracotta
setblock 170 72 324 minecraft:blue_terracotta
setblock 171 72 324 minecraft:dark_prismarine
setblock 172 72 323 minecraft:dark_prismarine
fill 172 72 324 172 75 324 minecraft:blue_terracotta
fill 173 72 323 173 75 323 minecraft:blue_terracotta
fill 173 72 325 173 73 325 minecraft:blue_terracotta
setblock 176 72 324 minecraft:dark_prismarine
setblock 177 72 323 minecraft:dark_prismarine
setblock 177 72 324 minecraft:blue_terracotta
fill 178 72 323 178 75 323 minecraft:blue_terracotta
setblock 181 72 329 minecraft:dark_prismarine
fill 181 72 330 181 75 330 minecraft:blue_terracotta
setblock 181 72 333 minecraft:blue_terracotta
fill 182 72 324 182 75 324 minecraft:blue_terracotta
setblock 182 72 328 minecraft:dark_prismarine
fill 182 72 329 182 75 329 minecraft:blue_terracotta
setblock 182 72 333 minecraft:dark_prismarine
fill 182 72 334 182 74 335 minecraft:blue_terracotta
setblock 182 72 349 minecraft:purple_concrete
fill 183 72 351 183 127 351 minecraft:black_concrete
setblock 141 73 338 minecraft:light_blue_wool
setblock 142 73 324 minecraft:purple_concrete
setblock 142 73 327 minecraft:dark_prismarine
fill 142 73 328 142 76 328 minecraft:blue_terracotta
setblock 142 73 332 minecraft:dark_prismarine
fill 142 73 333 142 76 333 minecraft:blue_terracotta
setblock 142 73 343 minecraft:purple_concrete
fill 142 73 350 142 73 351 minecraft:blue_terracotta
setblock 142 73 352 minecraft:dark_prismarine
fill 142 73 353 143 75 353 minecraft:blue_terracotta
setblock 142 73 356 minecraft:blue_terracotta
setblock 142 73 357 minecraft:dark_prismarine
fill 142 73 358 142 73 361 minecraft:blue_terracotta
fill 143 73 352 143 76 352 minecraft:blue_terracotta
fill 143 73 354 143 73 355 minecraft:blue_terracotta
setblock 143 73 356 minecraft:dark_prismarine
fill 143 73 357 143 75 358 minecraft:blue_terracotta
fill 143 73 363 144 74 363 minecraft:blue_terracotta
setblock 146 73 323 minecraft:dark_prismarine
setblock 146 73 362 minecraft:blue_terracotta
setblock 146 73 363 minecraft:dark_prismarine
fill 147 73 323 147 76 323 minecraft:blue_terracotta
setblock 147 73 362 minecraft:dark_prismarine
fill 147 73 363 147 76 363 minecraft:blue_terracotta
fill 148 73 362 148 76 362 minecraft:blue_terracotta
fill 149 73 361 151 74 361 minecraft:blue_terracotta
setblock 151 73 323 minecraft:dark_prismarine
setblock 151 73 363 minecraft:dark_prismarine
fill 152 73 323 152 75 323 minecraft:blue_terracotta
setblock 152 73 362 minecraft:dark_prismarine
fill 152 73 363 152 76 363 minecraft:blue_terracotta
fill 153 73 362 153 76 362 minecraft:blue_terracotta
setblock 158 73 323 minecraft:purple_concrete
setblock 166 73 363 minecraft:purple_concrete
fill 168 73 323 168 75 323 minecraft:blue_terracotta
setblock 170 73 324 minecraft:dark_prismarine
setblock 171 73 323 minecraft:dark_prismarine
fill 171 73 324 171 76 324 minecraft:blue_terracotta
fill 172 73 323 172 76 323 minecraft:blue_terracotta
fill 172 73 325 172 74 325 minecraft:blue_terracotta
setblock 175 73 324 minecraft:dark_prismarine
setblock 176 73 323 minecraft:dark_prismarine
fill 176 73 324 176 74 324 minecraft:blue_terracotta
fill 176 73 336 176 98 336 minecraft:magenta_terracotta
fill 177 73 323 177 76 323 minecraft:blue_terracotta
fill 179 73 327 179 89 327 minecraft:iron_bars
setblock 181 73 328 minecraft:dark_prismarine
fill 181 73 329 181 76 329 minecraft:blue_terracotta
setblock 181 73 333 minecraft:dark_prismarine
fill 181 73 334 181 76 334 minecraft:blue_terracotta
fill 182 73 323 182 76 323 minecraft:blue_terracotta
setblock 182 73 327 minecraft:dark_prismarine
fill 182 73 328 182 76 328 minecraft:blue_terracotta
setblock 182 73 332 minecraft:dark_prismarine
fill 182 73 333 182 76 333 minecraft:blue_terracotta
setblock 182 73 336 minecraft:blue_terracotta
setblock 182 73 343 minecraft:purple_concrete
fill 182 73 354 182 75 354 minecraft:blue_terracotta
setblock 182 73 362 minecraft:purple_concrete
fill 141 74 338 141 129 338 minecraft:black_concrete
setblock 142 74 326 minecraft:dark_prismarine
fill 142 74 327 142 75 327 minecraft:blue_terracotta
setblock 142 74 330 minecraft:blue_terracotta
setblock 142 74 331 minecraft:dark_prismarine
fill 142 74 332 142 77 332 minecraft:blue_terracotta
fill 142 74 334 142 75 334 minecraft:blue_terracotta
setblock 142 74 349 minecraft:purple_concrete
setblock 142 74 350 minecraft:blue_terracotta
setblock 142 74 351 minecraft:dark_prismarine
fill 142 74 352 142 77 352 minecraft:blue_terracotta
setblock 142 74 356 minecraft:dark_prismarine
fill 142 74 357 142 74 360 minecraft:blue_terracotta
setblock 142 74 361 minecraft:dark_prismarine
fill 142 74 362 142 76 363 minecraft:blue_terracotta
fill 143 74 351 143 77 351 minecraft:blue_terracotta
setblock 143 74 354 minecraft:blue_terracotta
setblock 143 74 355 minecraft:dark_prismarine
fill 143 74 356 144 76 356 minecraft:blue_terracotta
setblock 143 74 359 minecraft:blue_terracotta
setblock 143 74 360 minecraft:dark_prismarine
setblock 144 74 353 minecraft:blue_terracotta
setblock 144 74 354 minecraft:dark_prismarine
fill 144 74 355 144 77 355 minecraft:blue_terracotta
fill 144 74 357 144 75 357 minecraft:blue_terracotta
setblock 145 74 323 minecraft:dark_prismarine
setblock 145 74 362 minecraft:blue_terracotta
setblock 145 74 363 minecraft:dark_prismarine
fill 146 74 323 146 77 323 minecraft:blue_terracotta
setblock 146 74 362 minecraft:dark_prismarine
fill 146 74 363 146 77 363 minecraft:blue_terracotta
setblock 147 74 361 minecraft:dark_prismarine
fill 147 74 362 147 77 362 minecraft:blue_terracotta
fill 148 74 361 148 77 361 minecraft:blue_terracotta
setblock 150 74 323 minecraft:dark_prismarine
setblock 150 74 362 minecraft:blue_terracotta
setblock 150 74 363 minecraft:dark_prismarine
fill 151 74 323 151 76 323 minecraft:blue_terracotta
setblock 151 74 362 minecraft:dark_prismarine
fill 151 74 363 151 77 363 minecraft:blue_terracotta
setblock 152 74 361 minecraft:dark_prismarine
fill 152 74 362 152 77 362 minecraft:blue_terracotta
fill 154 74 362 154 75 362 minecraft:blue_terracotta
setblock 155 74 363 minecraft:dark_prismarine
fill 167 74 323 167 76 323 minecraft:blue_terracotta
setblock 169 74 324 minecraft:dark_prismarine
setblock 170 74 323 minecraft:dark_prismarine
fill 170 74 324 170 77 324 minecraft:blue_terracotta
setblock 170 74 363 minecraft:dark_prismarine
fill 171 74 323 171 77 323 minecraft:blue_terracotta
fill 171 74 363 174 74 363 minecraft:blue_terracotta
setblock 174 74 324 minecraft:dark_prismarine
setblock 175 74 323 minecraft:dark_prismarine
fill 175 74 324 175 75 324 minecraft:blue_terracotta
fill 176 74 323 176 77 323 minecraft:blue_terracotta
setblock 180 74 323 minecraft:dark_prismarine
fill 181 74 323 181 77 323 minecraft:blue_terracotta
setblock 181 74 327 minecraft:dark_prismarine
fill 181 74 328 181 75 328 minecraft:blue_terracotta
setblock 181 74 332 minecraft:dark_prismarine
fill 181 74 333 181 77 333 minecraft:blue_terracotta
setblock 182 74 326 minecraft:dark_prismarine
fill 182 74 327 182 77 327 minecraft:blue_terracotta
setblock 182 74 331 minecraft:dark_prismarine
fill 182 74 332 182 77 332 minecraft:blue_terracotta
setblock 182 74 336 minecraft:dark_prismarine
fill 182 74 337 182 77 337 minecraft:blue_terracotta
fill 182 74 352 182 76 353 minecraft:blue_terracotta
setblock 182 74 355 minecraft:blue_terracotta
setblock 182 74 356 minecraft:dark_prismarine
fill 182 74 357 182 76 358 minecraft:blue_terracotta
fill 141 75 346 141 131 346 minecraft:black_concrete
setblock 141 75 347 minecraft:cyan_concrete
fill 141 75 348 141 131 348 minecraft:black_concrete
setblock 142 75 330 minecraft:dark_prismarine
fill 142 75 331 142 78 331 minecraft:blue_terracotta
setblock 142 75 335 minecraft:dark_prismarine
setblock 142 75 336 minecraft:purple_concrete
setblock 142 75 350 minecraft:dark_prismarine
fill 142 75 351 142 78 351 minecraft:blue_terracotta
setblock 142 75 355 minecraft:dark_prismarine
fill 142 75 356 142 75 359 minecraft:blue_terracotta
setblock 142 75 360 minecraft:dark_prismarine
fill 142 75 361 143 77 361 minecraft:blue_terracotta
setblock 143 75 322 minecraft:light_blue_wool
setblock 143 75 354 minecraft:dark_prismarine
fill 143 75 355 143 78 355 minecraft:blue_terracotta
setblock 143 75 359 minecraft:dark_prismarine
fill 143 75 360 143 78 360 minecraft:blue_terracotta
fill 143 75 362 143 75 363 minecraft:blue_terracotta
fill 144 75 322 144 124 322 minecraft:black_concrete
setblock 144 75 323 minecraft:dark_prismarine
setblock 144 75 352 minecraft:blue_terracotta
setblock 144 75 353 minecraft:dark_prismarine
fill 144 75 354 145 77 354 minecraft:blue_terracotta
setblock 144 75 358 minecraft:dark_prismarine
fill 144 75 359 144 78 359 minecraft:blue_terracotta
setblock 144 75 362 minecraft:blue_terracotta
setblock 144 75 363 minecraft:dark_prismarine
fill 145 75 323 145 78 323 minecraft:blue_terracotta
fill 145 75 355 145 75 356 minecraft:blue_terracotta
setblock 145 75 357 minecraft:dark_prismarine
setblock 145 75 362 minecraft:dark_prismarine
fill 145 75 363 145 78 363 minecraft:blue_terracotta
setblock 146 75 361 minecraft:dark_prismarine
fill 146 75 362 146 78 362 minecraft:blue_terracotta
fill 147 75 361 147 78 361 minecraft:blue_terracotta
fill 148 75 360 150 76 360 minecraft:blue_terracotta
setblock 149 75 323 minecraft:dark_prismarine
fill 149 75 337 149 102 337 minecraft:magenta_terracotta
fill 149 75 361 150 75 361 minecraft:blue_terracotta
setblock 149 75 363 minecraft:dark_prismarine
fill 150 75 323 150 77 323 minecraft:blue_terracotta
setblock 150 75 362 minecraft:dark_prismarine
fill 150 75 363 150 78 363 minecraft:blue_terracotta
setblock 151 75 361 minecraft:dark_prismarine
fill 151 75 362 151 78 362 minecraft:blue_terracotta
fill 152 75 361 152 77 361 minecraft:blue_terracotta
setblock 154 75 363 minecraft:dark_prismarine
fill 155 75 363 155 76 363 minecraft:blue_terracotta
setblock 159 75 363 minecraft:purple_concrete
fill 160 75 355 160 102 355 minecraft:magenta_terracotta
setblock 165 75 323 minecraft:purple_concrete
setblock 168 75 363 minecraft:blue_terracotta
setblock 169 75 323 minecraft:dark_prismarine
fill 169 75 324 169 78 324 minecraft:blue_terracotta
setblock 169 75 363 minecraft:dark_prismarine
fill 170 75 323 170 78 323 minecraft:blue_terracotta
fill 170 75 363 173 75 363 minecraft:blue_terracotta
setblock 173 75 324 minecraft:dark_prismarine
setblock 174 75 323 minecraft:dark_prismarine
fill 174 75 324 174 76 324 minecraft:blue_terracotta
setblock 174 75 363 minecraft:dark_prismarine
fill 175 75 323 175 78 323 minecraft:blue_terracotta
fill 176 75 338 176 102 338 minecraft:magenta_terracotta
setblock 178 75 363 minecraft:purple_concrete
setblock 179 75 323 minecraft:dark_prismarine
fill 180 75 323 180 76 323 minecraft:blue_terracotta
setblock 181 75 331 minecraft:dark_prismarine
fill 181 75 332 181 77 332 minecraft:blue_terracotta
setblock 181 75 335 minecraft:blue_terracotta
setblock 182 75 325 minecraft:dark_prismarine
fill 182 75 326 182 78 326 minecraft:blue_terracotta
setblock 182 75 330 minecraft:dark_prismarine
fill 182 75 331 182 78 331 minecraft:blue_terracotta
setblock 182 75 334 minecraft:blue_terracotta
setblock 182 75 335 minecraft:dark_prismarine
fill 182 75 336 182 78 336 minecraft:blue_terracotta
setblock 182 75 350 minecraft:purple_concrete
setblock 182 75 355 minecraft:dark_prismarine
fill 182 75 356 182 78 356 minecraft:blue_terracotta
setblock 182 75 359 minecraft:blue_terracotta
setblock 182 75 360 minecraft:dark_prismarine
fill 182 75 361 182 78 361 minecraft:blue_terracotta
fill 141 76 347 141 131 347 minecraft:black_concrete
setblock 142 76 329 minecraft:dark_prismarine
fill 142 76 330 142 77 330 minecraft:blue_terracotta
setblock 142 76 334 minecraft:dark_prismarine
fill 142 76 335 142 78 336 minecraft:blue_terracotta
setblock 142 76 342 minecraft:purple_concrete
fill 142 76 350 142 79 350 minecraft:blue_terracotta
setblock 142 76 353 minecraft:blue_terracotta
setblock 142 76 354 minecraft:dark_prismarine
fill 142 76 355 142 76 358 minecraft:blue_terracotta
setblock 142 76 359 minecraft:dark_prismarine
fill 142 76 360 142 79 360 minecraft:blue_terracotta
fill 143 76 322 143 109 322 minecraft:black_concrete
setblock 143 76 353 minecraft:dark_prismarine
fill 143 76 354 143 79 354 minecraft:blue_terracotta
setblock 143 76 357 minecraft:blue_terracotta
setblock 143 76 358 minecraft:dark_prismarine
fill 143 76 359 143 79 359 minecraft:blue_terracotta
setblock 143 76 362 minecraft:blue_terracotta
setblock 143 76 363 minecraft:dark_prismarine
fill 144 76 323 144 78 323 minecraft:blue_terracotta
setblock 144 76 352 minecraft:dark_prismarine
fill 144 76 353 144 79 353 minecraft:blue_terracotta
setblock 144 76 357 minecraft:dark_prismarine
fill 144 76 358 145 78 358 minecraft:blue_terracotta
fill 144 76 360 144 76 361 minecraft:blue_terracotta
setblock 144 76 362 minecraft:dark_prismarine
fill 144 76 363 144 79 363 minecraft:blue_terracotta
setblock 145 76 355 minecraft:blue_terracotta
setblock 145 76 356 minecraft:dark_prismarine
fill 145 76 357 145 79 357 minecraft:blue_terracotta
setblock 145 76 361 minecraft:dark_prismarine
fill 145 76 362 145 79 362 minecraft:blue_terracotta
fill 146 76 361 146 79 361 minecraft:blue_terracotta
fill 147 76 337 148 94 337 minecraft:magenta_terracotta
fill 147 76 360 147 79 360 minecraft:blue_terracotta
setblock 148 76 323 minecraft:dark_prismarine
setblock 148 76 363 minecraft:dark_prismarine
fill 149 76 323 149 78 323 minecraft:blue_terracotta
setblock 149 76 361 minecraft:blue_terracotta
setblock 149 76 362 minecraft:dark_prismarine
fill 149 76 363 149 79 363 minecraft:blue_terracotta
setblock 150 76 361 minecraft:dark_prismarine
fill 150 76 362 150 79 362 minecraft:blue_terracotta
setblock 151 76 360 minecraft:dark_prismarine
fill 151 76 361 151 79 361 minecraft:blue_terracotta
setblock 153 76 363 minecraft:dark_prismarine
fill 154 76 363 154 78 363 minecraft:blue_terracotta
setblock 159 76 323 minecraft:purple_concrete
setblock 165 76 363 minecraft:purple_concrete
fill 166 76 323 166 77 323 minecraft:blue_terracotta
setblock 167 76 363 minecraft:blue_terracotta
setblock 168 76 323 minecraft:dark_prismarine
fill 168 76 324 168 77 324 minecraft:blue_terracotta
setblock 168 76 363 minecraft:dark_prismarine
fill 169 76 323 169 79 323 minecraft:blue_terracotta
fill 169 76 363 172 76 363 minecraft:blue_terracotta
setblock 172 76 324 minecraft:dark_prismarine
setblock 173 76 323 minecraft:dark_prismarine
fill 173 76 324 173 77 324 minecraft:blue_terracotta
setblock 173 76 363 minecraft:dark_prismarine
fill 174 76 323 174 79 323 minecraft:blue_terracotta
fill 174 76 363 175 77 363 minecraft:blue_terracotta
setblock 178 76 323 minecraft:dark_prismarine
setblock 179 76 323 minecraft:blue_terracotta
setblock 181 76 330 minecraft:dark_prismarine
fill 181 76 331 181 77 331 minecraft:blue_terracotta
setblock 181 76 335 minecraft:dark_prismarine
setblock 182 76 324 minecraft:dark_prismarine
fill 182 76 325 182 78 325 minecraft:blue_terracotta
setblock 182 76 329 minecraft:dark_prismarine
fill 182 76 330 182 79 330 minecraft:blue_terracotta
schedule function dropper:buildpart/75_5 1t
