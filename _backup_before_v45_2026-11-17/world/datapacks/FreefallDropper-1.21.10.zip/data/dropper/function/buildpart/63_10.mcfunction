fill 147 280 309 149 285 309 minecraft:basalt
setblock 147 280 310 minecraft:magma_block
setblock 147 280 313 minecraft:magma_block
fill 148 280 277 155 283 277 minecraft:basalt
fill 148 280 280 152 286 280 minecraft:basalt
fill 148 280 283 148 289 283 minecraft:basalt
fill 148 280 307 151 287 307 minecraft:basalt
fill 148 280 310 155 285 310 minecraft:basalt
fill 148 280 313 155 281 313 minecraft:basalt
fill 148 280 315 149 280 315 minecraft:basalt
setblock 150 280 276 minecraft:magma_block
setblock 150 280 279 minecraft:magma_block
setblock 150 280 309 minecraft:magma_block
setblock 150 280 312 minecraft:magma_block
setblock 150 280 315 minecraft:magma_block
fill 150 280 316 155 280 316 minecraft:basalt
fill 151 280 276 158 285 276 minecraft:basalt
fill 151 280 279 155 280 279 minecraft:basalt
setblock 151 280 285 minecraft:light[level=12]
setblock 151 280 292 minecraft:light[level=12]
setblock 151 280 299 minecraft:light[level=12]
setblock 151 280 306 minecraft:light[level=12]
fill 151 280 309 155 280 309 minecraft:basalt
fill 151 280 312 158 285 312 minecraft:basalt
fill 151 280 315 158 281 315 minecraft:basalt
setblock 153 280 278 minecraft:magma_block
setblock 153 280 311 minecraft:magma_block
setblock 153 280 314 minecraft:magma_block
fill 154 280 278 161 288 278 minecraft:basalt
fill 154 280 311 161 287 311 minecraft:basalt
fill 154 280 314 161 283 314 minecraft:basalt
setblock 156 280 277 minecraft:magma_block
setblock 156 280 310 minecraft:magma_block
setblock 156 280 313 minecraft:magma_block
setblock 156 280 316 minecraft:magma_block
fill 157 280 277 164 286 277 minecraft:basalt
fill 157 280 310 164 280 310 minecraft:basalt
fill 157 280 313 164 284 313 minecraft:basalt
fill 157 280 316 164 281 316 minecraft:basalt
setblock 158 280 285 minecraft:light[level=12]
setblock 158 280 299 minecraft:light[level=12]
setblock 158 280 306 minecraft:light[level=12]
setblock 159 280 276 minecraft:magma_block
setblock 159 280 312 minecraft:magma_block
setblock 159 280 315 minecraft:magma_block
fill 160 280 276 167 285 276 minecraft:basalt
fill 160 280 312 167 285 312 minecraft:basalt
fill 160 280 315 167 282 315 minecraft:basalt
setblock 162 280 278 minecraft:magma_block
setblock 162 280 311 minecraft:magma_block
setblock 162 280 314 minecraft:magma_block
fill 163 280 278 170 286 278 minecraft:basalt
fill 163 280 311 170 285 311 minecraft:basalt
fill 163 280 314 170 282 314 minecraft:basalt
setblock 165 280 277 minecraft:magma_block
fill 165 280 279 167 289 279 minecraft:basalt
setblock 165 280 285 minecraft:light[level=12]
setblock 165 280 292 minecraft:light[level=12]
setblock 165 280 299 minecraft:light[level=12]
setblock 165 280 306 minecraft:light[level=12]
fill 165 280 309 167 289 309 minecraft:basalt
setblock 165 280 310 minecraft:magma_block
setblock 165 280 313 minecraft:magma_block
setblock 165 280 316 minecraft:magma_block
fill 166 280 277 173 283 277 minecraft:basalt
fill 166 280 310 173 284 310 minecraft:basalt
fill 166 280 313 173 281 313 minecraft:basalt
fill 166 280 316 170 280 316 minecraft:basalt
setblock 168 280 276 minecraft:magma_block
setblock 168 280 279 minecraft:magma_block
fill 168 280 280 173 286 280 minecraft:basalt
fill 168 280 308 170 288 308 minecraft:basalt
setblock 168 280 309 minecraft:magma_block
setblock 168 280 312 minecraft:magma_block
setblock 168 280 315 minecraft:magma_block
fill 169 280 276 176 280 276 minecraft:basalt
fill 169 280 279 176 283 279 minecraft:basalt
fill 169 280 281 170 289 281 minecraft:basalt
fill 169 280 307 173 286 307 minecraft:basalt
fill 169 280 309 176 283 309 minecraft:basalt
fill 169 280 312 176 280 312 minecraft:basalt
fill 169 280 315 172 280 315 minecraft:basalt
setblock 171 280 278 minecraft:magma_block
setblock 171 280 281 minecraft:magma_block
fill 171 280 282 176 285 282 minecraft:basalt
fill 171 280 306 176 285 306 minecraft:basalt
setblock 171 280 308 minecraft:magma_block
setblock 171 280 311 minecraft:magma_block
setblock 171 280 314 minecraft:magma_block
fill 172 280 278 178 280 278 minecraft:basalt
fill 172 280 281 179 281 281 minecraft:basalt
fill 172 280 283 173 288 283 minecraft:basalt
setblock 172 280 285 minecraft:light[level=12]
setblock 172 280 292 minecraft:light[level=12]
setblock 172 280 299 minecraft:light[level=12]
fill 172 280 305 179 282 305 minecraft:basalt
fill 172 280 308 179 281 308 minecraft:basalt
fill 172 280 311 177 280 311 minecraft:basalt
fill 172 280 314 174 280 314 minecraft:basalt
fill 173 280 284 176 280 285 minecraft:basalt
fill 173 280 303 173 280 304 minecraft:basalt
setblock 174 280 277 minecraft:magma_block
setblock 174 280 280 minecraft:magma_block
setblock 174 280 283 minecraft:magma_block
setblock 174 280 286 minecraft:magma_block
fill 174 280 302 176 286 303 minecraft:basalt
setblock 174 280 304 minecraft:magma_block
setblock 174 280 307 minecraft:magma_block
setblock 174 280 310 minecraft:magma_block
setblock 174 280 313 minecraft:magma_block
fill 175 280 277 177 280 277 minecraft:basalt
fill 175 280 280 180 280 280 minecraft:basalt
fill 175 280 283 181 280 283 minecraft:basalt
fill 175 280 286 176 287 289 minecraft:basalt
fill 175 280 299 176 288 301 minecraft:basalt
fill 175 280 304 182 280 304 minecraft:basalt
fill 175 280 307 180 280 307 minecraft:basalt
fill 175 280 310 178 280 310 minecraft:basalt
setblock 175 280 313 minecraft:basalt
fill 176 280 290 176 280 298 minecraft:basalt
setblock 177 280 279 minecraft:magma_block
setblock 177 280 282 minecraft:magma_block
fill 177 280 284 179 283 284 minecraft:basalt
setblock 177 280 285 minecraft:magma_block
fill 177 280 286 179 284 287 minecraft:basalt
setblock 177 280 288 minecraft:magma_block
fill 177 280 289 179 285 290 minecraft:basalt
setblock 177 280 291 minecraft:magma_block
fill 177 280 292 179 286 293 minecraft:basalt
setblock 177 280 294 minecraft:magma_block
fill 177 280 295 179 286 296 minecraft:basalt
setblock 177 280 297 minecraft:magma_block
fill 177 280 298 179 285 299 minecraft:basalt
setblock 177 280 300 minecraft:magma_block
fill 177 280 301 179 284 302 minecraft:basalt
setblock 177 280 303 minecraft:magma_block
setblock 177 280 306 minecraft:magma_block
setblock 177 280 309 minecraft:magma_block
fill 178 280 279 179 280 279 minecraft:basalt
fill 178 280 282 181 280 282 minecraft:basalt
fill 178 280 285 182 280 285 minecraft:basalt
fill 178 280 288 182 280 288 minecraft:basalt
fill 178 280 291 182 282 291 minecraft:basalt
fill 178 280 294 182 282 294 minecraft:basalt
fill 178 280 297 182 282 297 minecraft:basalt
fill 178 280 300 182 280 300 minecraft:basalt
fill 178 280 303 182 280 303 minecraft:basalt
fill 178 280 306 181 280 306 minecraft:basalt
fill 178 280 309 179 280 309 minecraft:basalt
setblock 179 280 278 minecraft:light[level=12]
setblock 179 280 313 minecraft:light[level=12]
setblock 180 280 281 minecraft:magma_block
setblock 180 280 284 minecraft:magma_block
fill 180 280 286 182 281 286 minecraft:basalt
setblock 180 280 287 minecraft:magma_block
fill 180 280 289 182 282 289 minecraft:basalt
setblock 180 280 290 minecraft:magma_block
fill 180 280 292 182 282 292 minecraft:basalt
setblock 180 280 293 minecraft:magma_block
fill 180 280 295 182 282 295 minecraft:basalt
setblock 180 280 296 minecraft:magma_block
fill 180 280 298 182 282 298 minecraft:basalt
setblock 180 280 299 minecraft:magma_block
fill 180 280 301 182 281 301 minecraft:basalt
setblock 180 280 302 minecraft:magma_block
setblock 180 280 305 minecraft:magma_block
setblock 180 280 308 minecraft:magma_block
setblock 181 280 275 minecraft:white_concrete
fill 181 280 284 182 280 284 minecraft:basalt
fill 181 280 287 182 281 287 minecraft:basalt
fill 181 280 290 182 282 290 minecraft:basalt
fill 181 280 293 182 282 293 minecraft:basalt
fill 181 280 296 182 282 296 minecraft:basalt
fill 181 280 299 182 282 299 minecraft:basalt
fill 181 280 302 182 281 302 minecraft:basalt
setblock 181 280 305 minecraft:basalt
fill 182 280 275 183 295 275 minecraft:snow_block
fill 142 281 279 143 281 309 minecraft:basalt
fill 143 281 278 144 281 278 minecraft:basalt
setblock 143 281 310 minecraft:magma_block
fill 144 281 277 147 281 277 minecraft:basalt
fill 144 281 281 144 284 281 minecraft:basalt
fill 144 281 284 144 286 284 minecraft:basalt
fill 144 281 287 144 288 287 minecraft:basalt
fill 144 281 290 145 288 290 minecraft:basalt
fill 144 281 293 144 288 293 minecraft:basalt
fill 144 281 296 145 281 296 minecraft:basalt
fill 144 281 299 144 288 299 minecraft:basalt
fill 144 281 302 144 287 302 minecraft:basalt
fill 144 281 305 144 285 305 minecraft:basalt
fill 144 281 308 144 283 308 minecraft:basalt
setblock 144 281 311 minecraft:basalt
fill 145 281 276 150 281 276 minecraft:basalt
fill 145 281 291 145 290 292 minecraft:basalt
fill 145 281 297 145 290 298 minecraft:basalt
fill 145 281 312 150 281 312 minecraft:basalt
fill 146 281 287 146 290 287 minecraft:basalt
setblock 146 281 288 minecraft:magma_block
setblock 146 281 300 minecraft:magma_block
fill 146 281 301 146 290 301 minecraft:basalt
fill 146 281 313 147 281 313 minecraft:basalt
fill 147 281 280 147 286 280 minecraft:basalt
fill 147 281 283 147 288 283 minecraft:basalt
fill 147 281 286 147 290 286 minecraft:basalt
fill 147 281 302 147 290 302 minecraft:basalt
fill 147 281 304 148 288 304 minecraft:basalt
fill 147 281 307 147 287 307 minecraft:basalt
fill 147 281 310 147 284 310 minecraft:basalt
fill 148 281 284 148 290 284 minecraft:basalt
setblock 148 281 314 minecraft:basalt
fill 149 281 283 149 290 283 minecraft:basalt
setblock 149 281 305 minecraft:magma_block
setblock 149 281 314 minecraft:magma_block
fill 150 281 279 154 287 279 minecraft:basalt
fill 150 281 282 150 290 282 minecraft:basalt
fill 150 281 306 150 290 306 minecraft:basalt
fill 150 281 309 154 287 309 minecraft:basalt
fill 150 281 314 150 281 315 minecraft:basalt
fill 151 281 314 153 283 314 minecraft:basalt
fill 152 281 281 152 290 281 minecraft:basalt
setblock 152 281 307 minecraft:magma_block
setblock 152 281 316 minecraft:magma_block
fill 153 281 278 153 288 278 minecraft:basalt
fill 153 281 280 154 290 280 minecraft:basalt
fill 153 281 308 154 281 308 minecraft:basalt
fill 153 281 311 153 287 311 minecraft:basalt
fill 153 281 316 156 281 316 minecraft:basalt
setblock 155 281 279 minecraft:magma_block
setblock 155 281 309 minecraft:magma_block
fill 156 281 277 156 288 277 minecraft:basalt
fill 156 281 279 158 290 279 minecraft:basalt
fill 156 281 309 158 288 310 minecraft:basalt
fill 156 281 313 156 285 313 minecraft:basalt
fill 159 281 276 159 287 276 minecraft:basalt
fill 159 281 310 160 289 310 minecraft:basalt
fill 159 281 312 159 287 312 minecraft:basalt
fill 159 281 315 159 284 315 minecraft:basalt
setblock 161 281 310 minecraft:magma_block
fill 162 281 278 162 288 279 minecraft:basalt
fill 162 281 309 162 288 311 minecraft:basalt
fill 162 281 314 162 285 314 minecraft:basalt
fill 163 281 279 163 290 279 minecraft:basalt
fill 163 281 309 163 289 310 minecraft:basalt
setblock 164 281 279 minecraft:magma_block
setblock 164 281 309 minecraft:magma_block
fill 164 281 310 165 288 310 minecraft:basalt
fill 165 281 277 165 287 277 minecraft:basalt
fill 165 281 313 165 285 313 minecraft:basalt
fill 165 281 316 168 281 316 minecraft:basalt
fill 166 281 280 167 281 280 minecraft:basalt
fill 166 281 308 166 290 308 minecraft:basalt
setblock 167 281 308 minecraft:magma_block
fill 168 281 276 175 281 276 minecraft:basalt
fill 168 281 279 168 288 279 minecraft:basalt
fill 168 281 281 168 290 281 minecraft:basalt
fill 168 281 307 168 290 307 minecraft:basalt
fill 168 281 309 168 288 309 minecraft:basalt
fill 168 281 312 175 281 312 minecraft:basalt
fill 168 281 315 170 281 315 minecraft:basalt
fill 170 281 282 170 290 282 minecraft:basalt
fill 170 281 306 170 290 306 minecraft:basalt
fill 171 281 278 177 281 278 minecraft:basalt
fill 171 281 281 171 288 281 minecraft:basalt
fill 171 281 283 171 290 283 minecraft:basalt
fill 171 281 305 171 290 305 minecraft:basalt
fill 171 281 308 171 287 308 minecraft:basalt
fill 171 281 311 175 282 311 minecraft:basalt
fill 171 281 314 172 281 314 minecraft:basalt
fill 172 281 284 176 286 284 minecraft:basalt
fill 172 281 304 181 281 304 minecraft:basalt
setblock 173 281 285 minecraft:magma_block
fill 173 281 286 174 288 286 minecraft:basalt
fill 173 281 302 173 290 302 minecraft:basalt
setblock 173 281 303 minecraft:magma_block
fill 174 281 277 176 281 277 minecraft:basalt
fill 174 281 280 178 282 280 minecraft:basalt
fill 174 281 283 180 281 283 minecraft:basalt
fill 174 281 285 181 281 285 minecraft:basalt
fill 174 281 287 174 290 288 minecraft:basalt
fill 174 281 300 174 290 301 minecraft:basalt
fill 174 281 307 178 282 307 minecraft:basalt
fill 174 281 310 177 281 310 minecraft:basalt
setblock 174 281 313 minecraft:basalt
fill 175 281 290 176 281 292 minecraft:basalt
fill 175 281 296 176 289 298 minecraft:basalt
setblock 176 281 275 minecraft:white_concrete
setblock 176 281 293 minecraft:magma_block
fill 176 281 294 176 289 295 minecraft:basalt
setblock 176 281 311 minecraft:magma_block
fill 177 281 279 178 281 279 minecraft:basalt
fill 177 281 282 180 281 282 minecraft:basalt
fill 177 281 288 181 283 288 minecraft:basalt
fill 177 281 291 177 288 291 minecraft:basalt
fill 177 281 294 177 288 294 minecraft:basalt
fill 177 281 297 177 288 297 minecraft:basalt
fill 177 281 300 181 283 300 minecraft:basalt
fill 177 281 303 181 281 303 minecraft:basalt
fill 177 281 306 180 281 306 minecraft:basalt
fill 177 281 309 178 281 309 minecraft:basalt
setblock 179 281 280 minecraft:magma_block
setblock 179 281 307 minecraft:magma_block
fill 180 281 284 181 281 284 minecraft:basalt
fill 180 281 287 180 283 287 minecraft:basalt
fill 180 281 290 180 284 290 minecraft:basalt
fill 180 281 293 180 285 293 minecraft:basalt
fill 180 281 296 180 285 296 minecraft:basalt
fill 180 281 299 180 284 299 minecraft:basalt
fill 180 281 302 180 283 302 minecraft:basalt
setblock 180 281 305 minecraft:basalt
fill 181 281 275 181 291 275 minecraft:snow_block
setblock 182 281 288 minecraft:magma_block
setblock 182 281 300 minecraft:magma_block
setblock 183 281 302 minecraft:light_blue_concrete
fill 142 282 280 143 282 308 minecraft:basalt
setblock 143 282 279 minecraft:basalt
setblock 143 282 309 minecraft:basalt
setblock 144 282 278 minecraft:basalt
fill 144 282 296 144 288 296 minecraft:basalt
fill 145 282 277 147 282 277 minecraft:basalt
setblock 145 282 293 minecraft:magma_block
fill 145 282 294 145 290 295 minecraft:basalt
setblock 145 282 296 minecraft:magma_block
setblock 145 282 311 minecraft:magma_block
fill 146 282 275 146 302 275 minecraft:snow_block
fill 146 282 276 150 282 276 minecraft:basalt
fill 146 282 288 146 289 290 minecraft:basalt
fill 146 282 298 146 289 300 minecraft:basalt
fill 146 282 311 150 282 312 minecraft:basalt
setblock 147 282 275 minecraft:white_concrete
fill 147 282 287 147 291 287 minecraft:basalt
fill 147 282 301 147 291 301 minecraft:basalt
fill 148 282 275 149 304 275 minecraft:snow_block
fill 148 282 285 148 290 285 minecraft:basalt
fill 148 282 303 148 290 303 minecraft:basalt
setblock 148 282 313 minecraft:magma_block
fill 149 282 284 149 291 284 minecraft:basalt
fill 149 282 304 149 289 305 minecraft:basalt
fill 149 282 313 155 282 313 minecraft:basalt
fill 150 282 283 150 291 283 minecraft:basalt
fill 150 282 305 150 291 305 minecraft:basalt
setblock 150 282 314 minecraft:basalt
setblock 151 282 282 minecraft:magma_block
setblock 151 282 306 minecraft:magma_block
fill 151 282 311 152 286 311 minecraft:basalt
fill 152 282 307 153 289 307 minecraft:basalt
fill 152 282 315 158 282 315 minecraft:basalt
fill 153 282 281 153 291 281 minecraft:basalt
fill 153 282 308 153 290 308 minecraft:basalt
setblock 153 282 317 minecraft:light_blue_concrete
setblock 154 282 308 minecraft:magma_block
fill 154 282 316 156 282 316 minecraft:basalt
fill 154 282 317 154 297 317 minecraft:snow_block
fill 155 282 279 155 289 280 minecraft:basalt
fill 155 282 308 155 289 309 minecraft:basalt
fill 156 282 280 156 291 280 minecraft:basalt
fill 156 282 308 156 291 308 minecraft:basalt
setblock 157 282 316 minecraft:magma_block
fill 158 282 316 165 282 316 minecraft:basalt
fill 159 282 279 159 290 279 minecraft:basalt
fill 159 282 309 159 290 309 minecraft:basalt
setblock 160 282 279 minecraft:magma_block
setblock 160 282 309 minecraft:magma_block
fill 161 282 279 161 290 279 minecraft:basalt
fill 161 282 309 161 289 310 minecraft:basalt
fill 164 282 279 164 289 280 minecraft:basalt
fill 164 282 308 164 289 309 minecraft:basalt
fill 165 282 280 165 291 280 minecraft:basalt
fill 165 282 308 165 291 308 minecraft:basalt
setblock 166 282 280 minecraft:magma_block
fill 166 282 313 172 282 313 minecraft:basalt
setblock 166 282 316 minecraft:magma_block
fill 167 282 280 167 290 281 minecraft:basalt
fill 167 282 307 167 289 308 minecraft:basalt
fill 168 282 276 174 282 276 minecraft:basalt
fill 168 282 312 174 282 312 minecraft:basalt
setblock 168 282 315 minecraft:basalt
setblock 169 282 282 minecraft:magma_block
setblock 169 282 306 minecraft:magma_block
fill 170 282 283 170 291 283 minecraft:basalt
fill 170 282 305 170 291 305 minecraft:basalt
fill 171 282 278 176 282 278 minecraft:basalt
fill 171 282 284 171 291 284 minecraft:basalt
fill 171 282 304 180 282 304 minecraft:basalt
fill 172 282 281 178 282 281 minecraft:basalt
fill 172 282 285 180 283 285 minecraft:basalt
fill 172 282 303 173 289 303 minecraft:basalt
fill 172 282 308 178 282 308 minecraft:basalt
fill 173 282 287 173 291 287 minecraft:basalt
fill 173 282 301 173 291 301 minecraft:basalt
setblock 174 282 277 minecraft:basalt
fill 174 282 283 179 282 283 minecraft:basalt
fill 174 282 289 174 291 290 minecraft:basalt
fill 174 282 298 174 291 299 minecraft:basalt
fill 174 282 310 176 282 310 minecraft:basalt
setblock 175 282 277 minecraft:magma_block
fill 175 282 290 176 289 291 minecraft:basalt
setblock 175 282 292 minecraft:magma_block
fill 175 282 293 175 290 294 minecraft:basalt
setblock 175 282 295 minecraft:magma_block
fill 176 282 275 176 308 275 minecraft:snow_block
fill 176 282 292 176 289 293 minecraft:basalt
setblock 177 282 279 minecraft:basalt
fill 177 282 282 179 282 282 minecraft:basalt
fill 177 282 303 180 283 303 minecraft:basalt
fill 177 282 306 179 282 306 minecraft:basalt
setblock 177 282 309 minecraft:basalt
setblock 180 282 284 minecraft:basalt
fill 180 282 286 181 282 286 minecraft:basalt
fill 180 282 301 181 282 301 minecraft:basalt
setblock 181 282 287 minecraft:magma_block
setblock 181 282 302 minecraft:magma_block
setblock 182 282 288 minecraft:basalt
setblock 182 282 300 minecraft:basalt
setblock 183 282 281 minecraft:white_concrete
setblock 183 282 299 minecraft:light_blue_concrete
fill 183 282 302 183 308 302 minecraft:snow_block
fill 142 283 282 143 283 306 minecraft:basalt
fill 142 283 312 142 283 314 minecraft:packed_ice
setblock 142 283 315 minecraft:snow_block
setblock 143 283 281 minecraft:basalt
setblock 143 283 307 minecraft:basalt
fill 144 283 279 146 283 279 minecraft:basalt
setblock 144 283 280 minecraft:magma_block
fill 144 283 309 146 283 309 minecraft:basalt
fill 145 283 280 146 284 280 minecraft:basalt
fill 145 283 293 146 283 293 minecraft:basalt
fill 145 283 296 146 283 296 minecraft:basalt
fill 145 283 310 146 283 310 minecraft:basalt
fill 146 283 291 146 291 292 minecraft:basalt
fill 146 283 294 146 292 295 minecraft:basalt
fill 146 283 297 146 291 297 minecraft:basalt
fill 147 283 275 147 308 275 minecraft:snow_block
setblock 147 283 277 minecraft:basalt
setblock 147 283 288 minecraft:magma_block
fill 147 283 289 147 292 289 minecraft:basalt
fill 147 283 299 147 292 299 minecraft:basalt
setblock 147 283 300 minecraft:magma_block
fill 147 283 311 150 283 311 minecraft:basalt
fill 148 283 276 150 283 276 minecraft:basalt
fill 148 283 286 148 290 287 minecraft:basalt
fill 148 283 301 148 291 302 minecraft:basalt
fill 148 283 312 150 283 312 minecraft:basalt
fill 149 283 285 149 291 285 minecraft:basalt
fill 149 283 303 149 291 303 minecraft:basalt
fill 149 283 316 150 283 316 minecraft:packed_ice
setblock 150 283 284 minecraft:magma_block
fill 150 283 304 150 291 304 minecraft:basalt
fill 150 283 313 155 283 313 minecraft:basalt
fill 151 283 282 151 290 283 minecraft:basalt
fill 151 283 288 154 286 291 minecraft:packed_ice
fill 151 283 305 151 290 306 minecraft:basalt
setblock 151 283 316 minecraft:snow_block
fill 152 283 282 153 291 282 minecraft:basalt
fill 152 283 292 153 286 292 minecraft:packed_ice
fill 152 283 306 153 291 306 minecraft:basalt
setblock 152 283 315 minecraft:snow_block
fill 152 283 316 155 283 316 minecraft:packed_ice
fill 153 283 315 153 286 315 minecraft:packed_ice
fill 153 283 317 153 308 317 minecraft:snow_block
fill 154 283 281 155 283 281 minecraft:basalt
fill 154 283 307 154 290 308 minecraft:basalt
fill 154 283 315 155 283 315 minecraft:basalt
fill 155 283 289 155 286 290 minecraft:packed_ice
fill 155 283 307 155 292 307 minecraft:basalt
setblock 156 283 315 minecraft:magma_block
setblock 156 283 316 minecraft:snow_block
fill 157 283 280 161 283 280 minecraft:basalt
fill 157 283 308 158 291 308 minecraft:basalt
fill 157 283 315 158 283 315 minecraft:basalt
fill 157 283 316 160 283 316 minecraft:packed_ice
fill 158 283 317 158 308 317 minecraft:snow_block
setblock 159 283 308 minecraft:magma_block
setblock 159 283 317 minecraft:light_blue_concrete
fill 160 283 279 160 290 279 minecraft:basalt
fill 160 283 308 160 290 309 minecraft:basalt
fill 160 283 315 164 283 315 minecraft:basalt
fill 161 283 308 163 290 308 minecraft:basalt
setblock 162 283 280 minecraft:magma_block
fill 163 283 280 163 291 280 minecraft:basalt
fill 163 283 314 167 283 314 minecraft:basalt
fill 165 283 281 166 291 281 minecraft:basalt
fill 165 283 307 166 290 307 minecraft:basalt
setblock 165 283 315 minecraft:magma_block
setblock 165 283 316 minecraft:packed_ice
fill 166 283 280 166 290 280 minecraft:basalt
fill 166 283 313 170 283 313 minecraft:basalt
setblock 166 283 315 minecraft:basalt
setblock 166 283 316 minecraft:snow_block
fill 167 283 282 169 290 282 minecraft:basalt
fill 167 283 306 169 290 306 minecraft:basalt
fill 167 283 316 170 283 316 minecraft:packed_ice
fill 168 283 276 172 283 276 minecraft:basalt
fill 168 283 312 172 283 312 minecraft:basalt
setblock 168 283 314 minecraft:magma_block
fill 168 283 315 171 283 315 minecraft:packed_ice
fill 169 283 283 169 291 283 minecraft:basalt
fill 169 283 305 169 291 305 minecraft:basalt
setblock 169 283 314 minecraft:basalt
fill 170 283 284 170 291 284 minecraft:basalt
fill 170 283 304 179 283 304 minecraft:basalt
fill 170 283 314 172 283 314 minecraft:packed_ice
fill 171 283 278 175 283 278 minecraft:basalt
fill 171 283 285 171 291 285 minecraft:basalt
fill 171 283 303 171 291 303 minecraft:basalt
fill 171 283 311 173 283 311 minecraft:basalt
setblock 171 283 316 minecraft:snow_block
fill 172 283 281 176 284 281 minecraft:basalt
fill 172 283 286 172 291 287 minecraft:basalt
fill 172 283 301 172 290 302 minecraft:basalt
fill 172 283 305 178 283 305 minecraft:basalt
fill 172 283 308 176 283 308 minecraft:basalt
setblock 172 283 315 minecraft:snow_block
fill 172 283 316 175 283 316 minecraft:packed_ice
fill 173 283 276 175 283 276 minecraft:packed_ice
fill 173 283 288 173 291 289 minecraft:basalt
fill 173 283 299 173 283 300 minecraft:basalt
setblock 173 283 314 minecraft:snow_block
fill 173 283 315 176 283 315 minecraft:packed_ice
setblock 174 283 277 minecraft:packed_ice
fill 174 283 280 176 283 280 minecraft:basalt
fill 174 283 283 178 283 283 minecraft:basalt
setblock 174 283 291 minecraft:magma_block
fill 174 283 292 174 291 293 minecraft:basalt
setblock 174 283 294 minecraft:magma_block
fill 174 283 295 174 291 296 minecraft:basalt
setblock 174 283 297 minecraft:magma_block
fill 174 283 307 177 283 307 minecraft:basalt
fill 174 283 310 175 283 310 minecraft:basalt
fill 174 283 314 177 283 314 minecraft:packed_ice
setblock 175 283 277 minecraft:snow_block
fill 175 283 292 175 290 292 minecraft:basalt
fill 175 283 295 175 290 295 minecraft:basalt
setblock 176 283 276 minecraft:snow_block
fill 176 283 277 176 286 277 minecraft:packed_ice
setblock 176 283 316 minecraft:snow_block
fill 177 283 276 179 284 276 minecraft:packed_ice
setblock 177 283 281 minecraft:magma_block
fill 177 283 282 178 283 282 minecraft:basalt
fill 177 283 306 178 283 306 minecraft:basalt
fill 177 283 313 177 288 313 minecraft:snow_block
setblock 177 283 315 minecraft:snow_block
fill 177 283 316 180 283 316 minecraft:packed_ice
fill 178 283 291 181 283 291 minecraft:basalt
fill 178 283 294 181 284 294 minecraft:basalt
fill 178 283 297 181 283 297 minecraft:basalt
setblock 178 283 314 minecraft:snow_block
fill 178 283 315 181 283 315 minecraft:packed_ice
setblock 179 283 314 minecraft:packed_ice
setblock 180 283 286 minecraft:magma_block
fill 180 283 289 181 283 289 minecraft:basalt
fill 180 283 292 181 283 292 minecraft:basalt
fill 180 283 295 181 284 295 minecraft:basalt
fill 180 283 298 181 283 298 minecraft:basalt
setblock 180 283 301 minecraft:magma_block
setblock 181 283 290 minecraft:basalt
fill 181 283 293 181 284 293 minecraft:basalt
setblock 181 283 296 minecraft:basalt
setblock 181 283 299 minecraft:basalt
setblock 181 283 311 minecraft:snow_block
fill 181 283 312 182 283 314 minecraft:packed_ice
setblock 181 283 316 minecraft:snow_block
setblock 182 283 309 minecraft:packed_ice
setblock 182 283 310 minecraft:snow_block
fill 182 283 311 182 286 311 minecraft:packed_ice
setblock 182 283 315 minecraft:snow_block
fill 182 283 316 182 286 316 minecraft:packed_ice
fill 183 283 281 183 308 281 minecraft:snow_block
fill 183 283 299 183 308 299 minecraft:snow_block
fill 142 284 275 142 290 275 minecraft:snow_block
fill 142 284 284 143 284 304 minecraft:basalt
fill 143 284 275 143 285 275 minecraft:light_blue_concrete
setblock 143 284 282 minecraft:magma_block
setblock 143 284 283 minecraft:basalt
setblock 143 284 305 minecraft:basalt
setblock 143 284 306 minecraft:magma_block
setblock 144 284 278 minecraft:light[level=15]
setblock 144 284 310 minecraft:light[level=15]
fill 145 284 293 145 290 293 minecraft:basalt
fill 145 284 296 145 290 296 minecraft:basalt
setblock 146 284 279 minecraft:basalt
setblock 146 284 293 minecraft:magma_block
setblock 146 284 296 minecraft:magma_block
setblock 146 284 309 minecraft:basalt
fill 147 284 278 152 284 278 minecraft:basalt
fill 147 284 288 148 284 288 minecraft:basalt
fill 147 284 290 147 291 291 minecraft:basalt
fill 147 284 297 147 291 298 minecraft:basalt
fill 147 284 300 148 284 300 minecraft:basalt
setblock 148 284 277 minecraft:basalt
fill 148 284 311 150 284 311 minecraft:basalt
fill 148 284 316 149 284 316 minecraft:packed_ice
setblock 149 284 276 minecraft:packed_ice
setblock 149 284 277 minecraft:magma_block
setblock 149 284 286 minecraft:magma_block
fill 149 284 302 149 292 302 minecraft:basalt
fill 150 284 276 150 284 277 minecraft:basalt
fill 150 284 284 150 291 285 minecraft:basalt
fill 150 284 289 150 286 290 minecraft:packed_ice
fill 150 284 303 150 292 303 minecraft:basalt
setblock 150 284 312 minecraft:basalt
setblock 150 284 316 minecraft:snow_block
fill 151 284 277 155 286 277 minecraft:basalt
fill 151 284 284 151 292 284 minecraft:basalt
fill 151 284 292 151 286 292 minecraft:packed_ice
fill 151 284 304 151 292 304 minecraft:basalt
fill 151 284 313 155 284 313 minecraft:basalt
fill 151 284 316 154 284 316 minecraft:packed_ice
fill 152 284 283 152 292 283 minecraft:basalt
setblock 152 284 286 minecraft:light[level=15]
fill 152 284 287 153 286 287 minecraft:packed_ice
setblock 152 284 294 minecraft:light[level=15]
setblock 152 284 302 minecraft:light[level=15]
fill 152 284 305 152 292 305 minecraft:basalt
fill 152 284 315 152 287 315 minecraft:packed_ice
fill 154 284 281 154 290 282 minecraft:basalt
fill 154 284 292 154 286 292 minecraft:packed_ice
fill 154 284 306 154 292 306 minecraft:basalt
setblock 154 284 314 minecraft:basalt
fill 154 284 315 155 284 315 minecraft:packed_ice
setblock 155 284 281 minecraft:magma_block
fill 155 284 288 155 286 288 minecraft:packed_ice
fill 155 284 291 155 286 291 minecraft:packed_ice
setblock 155 284 314 minecraft:magma_block
setblock 155 284 316 minecraft:snow_block
fill 156 284 281 157 292 281 minecraft:basalt
fill 156 284 307 157 292 307 minecraft:basalt
fill 156 284 314 161 284 314 minecraft:basalt
fill 156 284 316 159 284 316 minecraft:packed_ice
fill 157 284 280 157 290 280 minecraft:basalt
setblock 158 284 280 minecraft:magma_block
fill 159 284 280 162 291 280 minecraft:basalt
fill 159 284 308 159 291 308 minecraft:basalt
fill 159 284 317 159 298 317 minecraft:snow_block
setblock 160 284 286 minecraft:light[level=15]
setblock 160 284 302 minecraft:light[level=15]
setblock 160 284 315 minecraft:basalt
setblock 160 284 316 minecraft:snow_block
setblock 161 284 315 minecraft:magma_block
fill 161 284 316 161 287 316 minecraft:packed_ice
fill 163 284 281 163 292 281 minecraft:basalt
fill 163 284 307 164 284 307 minecraft:basalt
setblock 163 284 314 minecraft:basalt
fill 163 284 316 164 284 316 minecraft:packed_ice
setblock 164 284 281 minecraft:magma_block
setblock 164 284 314 minecraft:magma_block
setblock 165 284 275 minecraft:white_concrete
fill 165 284 314 166 284 314 minecraft:basalt
setblock 165 284 316 minecraft:snow_block
fill 166 284 277 172 284 277 minecraft:basalt
setblock 166 284 282 minecraft:basalt
setblock 166 284 306 minecraft:basalt
fill 166 284 313 166 285 313 minecraft:basalt
fill 166 284 316 169 284 316 minecraft:packed_ice
setblock 167 284 313 minecraft:magma_block
fill 167 284 315 170 284 315 minecraft:packed_ice
setblock 167 284 317 minecraft:white_concrete
fill 168 284 276 169 285 276 minecraft:basalt
fill 168 284 283 168 292 283 minecraft:basalt
setblock 168 284 286 minecraft:light[level=15]
setblock 168 284 294 minecraft:light[level=15]
setblock 168 284 302 minecraft:light[level=15]
fill 168 284 305 168 291 305 minecraft:basalt
fill 168 284 312 169 284 313 minecraft:basalt
fill 169 284 279 174 284 279 minecraft:basalt
fill 169 284 284 169 292 284 minecraft:basalt
fill 169 284 304 178 284 304 minecraft:basalt
fill 169 284 309 174 284 309 minecraft:basalt
setblock 170 284 276 minecraft:magma_block
setblock 170 284 285 minecraft:magma_block
setblock 170 284 303 minecraft:magma_block
setblock 170 284 312 minecraft:magma_block
fill 170 284 314 171 284 314 minecraft:packed_ice
setblock 170 284 316 minecraft:snow_block
fill 171 284 276 174 284 276 minecraft:packed_ice
fill 171 284 278 172 285 278 minecraft:basalt
fill 171 284 286 171 291 286 minecraft:basalt
fill 171 284 302 171 292 302 minecraft:basalt
fill 171 284 311 172 284 311 minecraft:basalt
setblock 171 284 315 minecraft:snow_block
fill 171 284 316 174 284 316 minecraft:packed_ice
fill 172 284 285 178 285 285 minecraft:basalt
fill 172 284 288 172 292 288 minecraft:basalt
fill 172 284 300 173 291 300 minecraft:basalt
fill 172 284 305 177 284 305 minecraft:basalt
fill 172 284 308 175 284 308 minecraft:basalt
setblock 172 284 314 minecraft:snow_block
fill 172 284 315 175 284 315 minecraft:packed_ice
setblock 173 284 277 minecraft:packed_ice
setblock 173 284 278 minecraft:magma_block
setblock 173 284 290 minecraft:magma_block
fill 173 284 291 174 291 291 minecraft:basalt
fill 173 284 297 173 292 298 minecraft:basalt
setblock 173 284 299 minecraft:magma_block
fill 173 284 314 176 284 314 minecraft:packed_ice
setblock 174 284 277 minecraft:snow_block
fill 174 284 280 175 284 280 minecraft:basalt
fill 174 284 283 177 284 283 minecraft:basalt
fill 174 284 294 174 291 294 minecraft:basalt
fill 174 284 297 174 291 297 minecraft:basalt
fill 174 284 307 175 285 307 minecraft:basalt
setblock 175 284 276 minecraft:snow_block
fill 175 284 277 175 287 277 minecraft:packed_ice
setblock 175 284 316 minecraft:snow_block
fill 176 284 276 176 287 276 minecraft:packed_ice
setblock 176 284 278 minecraft:light[level=15]
setblock 176 284 307 minecraft:magma_block
setblock 176 284 310 minecraft:light[level=15]
setblock 176 284 315 minecraft:snow_block
fill 176 284 316 179 284 316 minecraft:packed_ice
setblock 177 284 282 minecraft:basalt
fill 177 284 284 178 284 284 minecraft:basalt
fill 177 284 288 180 284 288 minecraft:basalt
fill 177 284 300 180 284 300 minecraft:basalt
fill 177 284 303 178 285 303 minecraft:basalt
setblock 177 284 306 minecraft:basalt
setblock 177 284 314 minecraft:snow_block
fill 177 284 315 180 284 315 minecraft:packed_ice
fill 178 284 291 180 284 291 minecraft:basalt
fill 178 284 297 180 284 297 minecraft:basalt
fill 178 284 314 178 286 314 minecraft:packed_ice
setblock 179 284 285 minecraft:magma_block
setblock 179 284 303 minecraft:magma_block
setblock 180 284 289 minecraft:basalt
fill 180 284 292 180 285 292 minecraft:basalt
setblock 180 284 298 minecraft:basalt
setblock 180 284 316 minecraft:snow_block
fill 181 284 313 181 284 314 minecraft:packed_ice
setblock 181 284 315 minecraft:snow_block
fill 181 284 316 181 287 316 minecraft:packed_ice
fill 182 284 310 182 285 310 minecraft:packed_ice
fill 182 284 312 182 284 313 minecraft:packed_ice
setblock 182 284 314 minecraft:snow_block
fill 182 284 315 182 287 315 minecraft:packed_ice
fill 142 285 285 143 285 286 minecraft:basalt
setblock 142 285 287 minecraft:magma_block
fill 142 285 288 143 285 301 minecraft:basalt
setblock 142 285 302 minecraft:magma_block
fill 142 285 303 143 285 303 minecraft:basalt
setblock 143 285 284 minecraft:basalt
fill 143 285 287 143 286 287 minecraft:basalt
fill 143 285 302 143 286 302 minecraft:basalt
setblock 143 285 304 minecraft:basalt
fill 144 285 306 146 285 306 minecraft:basalt
setblock 145 285 307 minecraft:magma_block
setblock 146 285 280 minecraft:basalt
fill 146 285 293 147 292 293 minecraft:basalt
fill 146 285 296 147 291 296 minecraft:basalt
fill 146 285 307 146 285 308 minecraft:basalt
fill 147 285 288 147 291 288 minecraft:basalt
fill 147 285 292 147 293 292 minecraft:basalt
fill 147 285 294 147 293 295 minecraft:basalt
fill 147 285 300 147 291 300 minecraft:basalt
fill 147 285 308 152 285 308 minecraft:basalt
fill 147 285 316 148 285 316 minecraft:packed_ice
setblock 148 285 276 minecraft:packed_ice
fill 148 285 278 152 285 278 minecraft:basalt
setblock 148 285 288 minecraft:magma_block
fill 148 285 289 148 293 290 minecraft:basalt
fill 148 285 298 148 293 299 minecraft:basalt
setblock 148 285 300 minecraft:magma_block
setblock 149 285 276 minecraft:snow_block
fill 149 285 286 149 292 287 minecraft:basalt
fill 149 285 301 149 292 301 minecraft:basalt
setblock 149 285 316 minecraft:snow_block
fill 150 285 276 150 288 276 minecraft:packed_ice
setblock 150 285 277 minecraft:basalt
fill 150 285 286 150 293 286 minecraft:basalt
fill 150 285 288 150 286 288 minecraft:packed_ice
fill 150 285 291 150 286 291 minecraft:packed_ice
fill 150 285 302 150 293 302 minecraft:basalt
setblock 150 285 311 minecraft:basalt
fill 150 285 316 153 285 316 minecraft:packed_ice
fill 151 285 285 151 293 285 minecraft:basalt
fill 151 285 287 151 286 287 minecraft:packed_ice
fill 151 285 303 151 293 303 minecraft:basalt
fill 151 285 315 151 288 315 minecraft:packed_ice
fill 152 285 284 152 293 284 minecraft:basalt
fill 152 285 293 153 286 293 minecraft:packed_ice
fill 152 285 304 152 293 304 minecraft:basalt
fill 153 285 283 153 293 283 minecraft:basalt
fill 153 285 305 153 293 305 minecraft:basalt
fill 154 285 287 154 286 287 minecraft:packed_ice
setblock 154 285 313 minecraft:magma_block
setblock 154 285 315 minecraft:packed_ice
setblock 154 285 316 minecraft:snow_block
fill 155 285 281 155 292 282 minecraft:basalt
fill 155 285 292 155 286 292 minecraft:packed_ice
fill 155 285 306 156 293 306 minecraft:basalt
setblock 155 285 313 minecraft:basalt
setblock 155 285 315 minecraft:snow_block
fill 155 285 316 158 285 316 minecraft:packed_ice
setblock 155 285 317 minecraft:white_concrete
fill 156 285 282 156 293 282 minecraft:basalt
fill 156 285 289 156 286 290 minecraft:packed_ice
fill 157 285 313 162 285 313 minecraft:basalt
fill 158 285 280 158 291 281 minecraft:basalt
fill 158 285 307 162 291 307 minecraft:basalt
fill 158 285 314 159 285 314 minecraft:basalt
fill 159 285 281 159 293 281 minecraft:basalt
setblock 159 285 316 minecraft:snow_block
setblock 160 285 281 minecraft:magma_block
setblock 160 285 314 minecraft:magma_block
fill 160 285 316 160 288 316 minecraft:packed_ice
fill 161 285 281 162 293 281 minecraft:basalt
setblock 161 285 314 minecraft:basalt
fill 162 285 316 163 285 316 minecraft:packed_ice
setblock 163 285 307 minecraft:magma_block
setblock 163 285 313 minecraft:magma_block
fill 164 285 281 164 292 282 minecraft:basalt
fill 164 285 306 164 292 307 minecraft:basalt
setblock 164 285 313 minecraft:basalt
setblock 164 285 316 minecraft:snow_block
fill 165 285 275 165 308 275 minecraft:snow_block
fill 165 285 282 165 293 282 minecraft:basalt
fill 165 285 306 165 293 306 minecraft:basalt
fill 165 285 316 168 285 316 minecraft:packed_ice
fill 166 285 277 170 285 277 minecraft:basalt
setblock 166 285 282 minecraft:magma_block
setblock 166 285 306 minecraft:magma_block
fill 166 285 310 171 285 310 minecraft:basalt
fill 166 285 315 169 285 315 minecraft:packed_ice
fill 167 285 283 167 292 283 minecraft:basalt
fill 167 285 305 167 293 305 minecraft:basalt
fill 167 285 317 167 308 317 minecraft:snow_block
fill 168 285 284 168 293 284 minecraft:basalt
fill 168 285 304 177 285 304 minecraft:basalt
fill 168 285 312 169 285 312 minecraft:basalt
fill 169 285 279 173 285 279 minecraft:basalt
fill 169 285 285 170 292 285 minecraft:basalt
fill 169 285 303 170 292 303 minecraft:basalt
fill 169 285 309 173 285 309 minecraft:basalt
fill 169 285 314 170 285 314 minecraft:packed_ice
setblock 169 285 316 minecraft:snow_block
fill 170 285 276 173 285 276 minecraft:packed_ice
fill 170 285 286 170 293 286 minecraft:basalt
fill 170 285 302 170 293 302 minecraft:basalt
setblock 170 285 315 minecraft:snow_block
fill 170 285 316 173 285 316 minecraft:packed_ice
fill 171 285 277 172 285 277 minecraft:packed_ice
fill 171 285 287 171 293 287 minecraft:basalt
fill 171 285 301 171 293 301 minecraft:basalt
setblock 171 285 314 minecraft:snow_block
fill 171 285 315 174 285 315 minecraft:packed_ice
fill 172 285 281 175 285 281 minecraft:basalt
setblock 172 285 289 minecraft:magma_block
fill 172 285 290 173 292 290 minecraft:basalt
setblock 172 285 298 minecraft:magma_block
fill 172 285 299 173 292 299 minecraft:basalt
fill 172 285 305 176 285 305 minecraft:basalt
fill 172 285 308 174 285 308 minecraft:basalt
setblock 172 285 310 minecraft:magma_block
fill 172 285 314 175 285 314 minecraft:packed_ice
setblock 173 285 277 minecraft:snow_block
fill 173 285 292 173 292 296 minecraft:basalt
setblock 174 285 276 minecraft:snow_block
fill 174 285 277 174 288 277 minecraft:packed_ice
setblock 174 285 280 minecraft:basalt
fill 174 285 283 176 285 283 minecraft:basalt
setblock 174 285 316 minecraft:snow_block
setblock 175 285 275 minecraft:light_blue_concrete
fill 175 285 276 175 288 276 minecraft:packed_ice
setblock 175 285 315 minecraft:snow_block
fill 175 285 316 178 285 316 minecraft:packed_ice
setblock 176 285 314 minecraft:snow_block
fill 176 285 315 179 285 315 minecraft:packed_ice
fill 177 285 276 177 285 277 minecraft:packed_ice
setblock 177 285 284 minecraft:basalt
fill 177 285 286 177 285 288 minecraft:basalt
fill 177 285 300 177 285 302 minecraft:basalt
fill 177 285 314 177 288 314 minecraft:packed_ice
setblock 178 285 276 minecraft:packed_ice
setblock 178 285 286 minecraft:basalt
setblock 178 285 287 minecraft:magma_block
fill 178 285 288 179 285 288 minecraft:basalt
fill 178 285 291 179 286 291 minecraft:basalt
fill 178 285 294 180 285 294 minecraft:basalt
fill 178 285 297 179 286 297 minecraft:basalt
fill 178 285 300 178 285 301 minecraft:basalt
setblock 178 285 302 minecraft:magma_block
setblock 179 285 276 minecraft:snow_block
setblock 179 285 300 minecraft:basalt
setblock 179 285 316 minecraft:snow_block
fill 180 285 276 180 288 276 minecraft:packed_ice
setblock 180 285 295 minecraft:basalt
setblock 180 285 315 minecraft:snow_block
fill 180 285 316 180 288 316 minecraft:packed_ice
setblock 181 285 314 minecraft:snow_block
fill 181 285 315 181 288 315 minecraft:packed_ice
fill 182 285 295 182 285 297 minecraft:packed_ice
setblock 182 285 312 minecraft:packed_ice
setblock 182 285 313 minecraft:snow_block
fill 182 285 314 182 288 314 minecraft:packed_ice
fill 142 286 288 143 286 300 minecraft:basalt
setblock 142 286 301 minecraft:packed_ice
fill 143 286 275 143 308 275 minecraft:snow_block
fill 143 286 285 143 286 286 minecraft:basalt
fill 143 286 301 143 287 301 minecraft:basalt
setblock 143 286 303 minecraft:basalt
setblock 144 286 278 minecraft:light[level=12]
setblock 144 286 306 minecraft:light[level=12]
setblock 144 286 313 minecraft:light[level=12]
fill 145 286 282 146 286 283 minecraft:basalt
fill 145 286 306 146 286 306 minecraft:basalt
fill 146 286 276 147 286 276 minecraft:packed_ice
fill 146 286 281 151 286 281 minecraft:basalt
setblock 146 286 307 minecraft:basalt
fill 146 286 316 147 286 316 minecraft:packed_ice
setblock 147 286 308 minecraft:magma_block
setblock 148 286 276 minecraft:snow_block
fill 148 286 279 149 286 279 minecraft:basalt
fill 148 286 288 149 292 288 minecraft:basalt
fill 148 286 291 148 293 297 minecraft:basalt
fill 148 286 300 149 292 300 minecraft:basalt
fill 148 286 308 149 286 309 minecraft:basalt
setblock 148 286 316 minecraft:snow_block
fill 149 286 276 149 288 277 minecraft:packed_ice
fill 149 286 289 149 294 289 minecraft:basalt
fill 149 286 290 149 286 291 minecraft:packed_ice
fill 149 286 299 149 294 299 minecraft:basalt
fill 149 286 316 152 286 316 minecraft:packed_ice
fill 150 286 277 150 287 277 minecraft:packed_ice
fill 150 286 278 152 286 278 minecraft:basalt
fill 150 286 287 150 294 287 minecraft:basalt
setblock 150 286 292 minecraft:packed_ice
setblock 150 286 301 minecraft:magma_block
fill 150 286 308 152 288 308 minecraft:basalt
setblock 150 286 310 minecraft:magma_block
fill 150 286 315 150 289 315 minecraft:packed_ice
fill 151 286 276 152 286 276 minecraft:packed_ice
fill 151 286 286 151 294 286 minecraft:basalt
setblock 151 286 293 minecraft:packed_ice
setblock 151 286 299 minecraft:light[level=12]
fill 151 286 302 151 293 302 minecraft:basalt
fill 151 286 310 155 287 310 minecraft:basalt
setblock 151 286 313 minecraft:light[level=12]
fill 152 286 285 152 294 285 minecraft:basalt
fill 152 286 286 153 286 286 minecraft:packed_ice
fill 152 286 303 152 294 303 minecraft:basalt
setblock 153 286 276 minecraft:snow_block
fill 153 286 284 153 294 284 minecraft:basalt
fill 153 286 304 153 294 304 minecraft:basalt
setblock 153 286 316 minecraft:snow_block
fill 154 286 276 158 286 276 minecraft:basalt
fill 154 286 283 155 286 283 minecraft:basalt
setblock 154 286 293 minecraft:packed_ice
fill 154 286 305 155 293 305 minecraft:basalt
fill 154 286 312 158 286 312 minecraft:basalt
setblock 154 286 315 minecraft:snow_block
fill 154 286 316 157 286 316 minecraft:packed_ice
setblock 155 286 287 minecraft:packed_ice
fill 155 286 315 155 288 315 minecraft:packed_ice
fill 155 286 317 155 307 317 minecraft:snow_block
setblock 156 286 288 minecraft:packed_ice
setblock 156 286 291 minecraft:packed_ice
fill 157 286 282 161 286 282 minecraft:basalt
fill 157 286 306 161 286 306 minecraft:basalt
fill 157 286 313 158 286 313 minecraft:basalt
setblock 158 286 285 minecraft:light[level=12]
setblock 158 286 292 minecraft:light[level=12]
setblock 158 286 299 minecraft:light[level=12]
setblock 158 286 316 minecraft:snow_block
setblock 159 286 313 minecraft:magma_block
fill 159 286 316 159 289 316 minecraft:packed_ice
fill 160 286 276 166 286 276 minecraft:basalt
fill 160 286 281 160 293 281 minecraft:basalt
fill 160 286 312 163 286 313 minecraft:basalt
setblock 162 286 282 minecraft:magma_block
setblock 162 286 306 minecraft:magma_block
setblock 162 286 316 minecraft:packed_ice
fill 163 286 282 163 293 282 minecraft:basalt
fill 163 286 306 163 292 307 minecraft:basalt
fill 163 286 311 169 286 311 minecraft:basalt
setblock 163 286 316 minecraft:snow_block
fill 164 286 312 166 286 312 minecraft:basalt
fill 164 286 316 167 286 316 minecraft:packed_ice
fill 165 286 283 166 293 283 minecraft:basalt
setblock 165 286 285 minecraft:light[level=12]
setblock 165 286 292 minecraft:light[level=12]
setblock 165 286 299 minecraft:light[level=12]
setblock 165 286 305 minecraft:magma_block
setblock 165 286 313 minecraft:light[level=12]
fill 166 286 277 167 287 277 minecraft:basalt
fill 166 286 282 166 292 282 minecraft:basalt
fill 166 286 305 166 292 306 minecraft:basalt
fill 166 286 310 170 286 310 minecraft:basalt
fill 166 286 315 168 286 315 minecraft:packed_ice
setblock 167 286 276 minecraft:packed_ice
fill 167 286 284 167 294 284 minecraft:basalt
fill 167 286 304 176 286 304 minecraft:basalt
setblock 168 286 276 minecraft:snow_block
setblock 168 286 277 minecraft:magma_block
fill 168 286 285 168 294 285 minecraft:basalt
fill 168 286 303 168 294 303 minecraft:basalt
setblock 168 286 316 minecraft:snow_block
fill 169 286 276 172 286 276 minecraft:packed_ice
setblock 169 286 277 minecraft:basalt
fill 169 286 279 170 287 279 minecraft:basalt
fill 169 286 286 169 294 286 minecraft:basalt
fill 169 286 302 169 293 302 minecraft:basalt
fill 169 286 309 170 287 309 minecraft:basalt
setblock 169 286 314 minecraft:packed_ice
setblock 169 286 315 minecraft:snow_block
fill 169 286 316 172 286 316 minecraft:packed_ice
fill 170 286 277 171 286 277 minecraft:packed_ice
fill 170 286 287 170 294 287 minecraft:basalt
fill 170 286 301 170 294 301 minecraft:basalt
setblock 170 286 314 minecraft:snow_block
fill 170 286 315 173 286 315 minecraft:packed_ice
setblock 171 286 278 minecraft:snow_block
setblock 171 286 279 minecraft:magma_block
fill 171 286 282 175 286 282 minecraft:basalt
setblock 171 286 288 minecraft:magma_block
fill 171 286 289 172 293 289 minecraft:basalt
fill 171 286 299 171 294 299 minecraft:basalt
setblock 171 286 300 minecraft:magma_block
fill 171 286 306 175 286 306 minecraft:basalt
setblock 171 286 309 minecraft:magma_block
fill 171 286 314 174 286 314 minecraft:packed_ice
setblock 172 286 277 minecraft:snow_block
fill 172 286 278 173 288 278 minecraft:packed_ice
setblock 172 286 279 minecraft:basalt
fill 172 286 281 173 287 281 minecraft:basalt
fill 172 286 285 177 286 285 minecraft:basalt
fill 172 286 291 172 293 298 minecraft:basalt
fill 172 286 305 175 286 305 minecraft:basalt
fill 172 286 308 172 286 309 minecraft:basalt
setblock 172 286 313 minecraft:light[level=12]
setblock 173 286 276 minecraft:snow_block
fill 173 286 277 173 289 277 minecraft:packed_ice
setblock 173 286 308 minecraft:basalt
setblock 173 286 316 minecraft:snow_block
fill 174 286 276 174 289 276 minecraft:packed_ice
setblock 174 286 281 minecraft:magma_block
fill 174 286 283 175 286 283 minecraft:basalt
setblock 174 286 307 minecraft:basalt
setblock 174 286 315 minecraft:snow_block
fill 174 286 316 177 286 316 minecraft:packed_ice
fill 175 286 275 175 287 275 minecraft:snow_block
setblock 175 286 314 minecraft:snow_block
fill 175 286 315 178 286 315 minecraft:packed_ice
fill 176 286 313 176 288 313 minecraft:snow_block
fill 176 286 314 176 289 314 minecraft:packed_ice
setblock 177 286 276 minecraft:packed_ice
setblock 177 286 277 minecraft:snow_block
setblock 177 286 286 minecraft:magma_block
fill 177 286 287 177 287 290 minecraft:basalt
fill 177 286 298 178 286 300 minecraft:basalt
setblock 177 286 301 minecraft:magma_block
fill 177 286 302 177 286 303 minecraft:basalt
fill 177 286 312 177 288 312 minecraft:snow_block
setblock 178 286 276 minecraft:snow_block
fill 178 286 288 178 286 290 minecraft:basalt
fill 178 286 294 179 286 294 minecraft:basalt
fill 178 286 313 178 288 313 minecraft:snow_block
setblock 178 286 316 minecraft:snow_block
fill 179 286 276 179 289 276 minecraft:packed_ice
setblock 179 286 278 minecraft:light[level=12]
setblock 179 286 285 minecraft:light[level=12]
setblock 179 286 299 minecraft:light[level=12]
setblock 179 286 306 minecraft:light[level=12]
setblock 179 286 313 minecraft:light[level=12]
setblock 179 286 315 minecraft:snow_block
fill 179 286 316 179 289 316 minecraft:packed_ice
fill 180 286 315 180 289 315 minecraft:packed_ice
setblock 181 286 314 minecraft:packed_ice
fill 182 286 294 182 286 296 minecraft:packed_ice
setblock 182 286 297 minecraft:snow_block
fill 182 286 298 182 287 300 minecraft:packed_ice
setblock 182 286 312 minecraft:snow_block
fill 182 286 313 182 289 313 minecraft:packed_ice
setblock 183 286 277 minecraft:light_blue_concrete
fill 142 287 291 143 287 297 minecraft:basalt
fill 142 287 298 142 287 300 minecraft:packed_ice
setblock 142 287 301 minecraft:snow_block
fill 142 287 302 142 289 303 minecraft:packed_ice
setblock 143 287 287 minecraft:magma_block
fill 143 287 288 143 287 289 minecraft:basalt
setblock 143 287 290 minecraft:magma_block
fill 143 287 298 143 288 298 minecraft:basalt
setblock 143 287 299 minecraft:magma_block
setblock 143 287 300 minecraft:basalt
fill 144 287 303 146 287 303 minecraft:basalt
fill 144 287 316 146 287 316 minecraft:packed_ice
fill 145 287 276 146 287 276 minecraft:packed_ice
fill 145 287 304 146 287 304 minecraft:basalt
setblock 146 287 283 minecraft:magma_block
fill 146 287 305 148 287 305 minecraft:basalt
setblock 147 287 276 minecraft:snow_block
fill 147 287 281 151 287 281 minecraft:basalt
setblock 147 287 316 minecraft:snow_block
fill 148 287 276 148 289 277 minecraft:packed_ice
fill 148 287 316 151 287 316 minecraft:packed_ice
fill 149 287 280 152 287 280 minecraft:basalt
fill 149 287 290 149 294 290 minecraft:basalt
setblock 149 287 291 minecraft:magma_block
setblock 149 287 297 minecraft:magma_block
fill 149 287 298 149 294 298 minecraft:basalt
setblock 149 287 308 minecraft:basalt
fill 149 287 315 149 290 315 minecraft:packed_ice
setblock 150 287 278 minecraft:snow_block
fill 150 287 288 150 294 288 minecraft:basalt
fill 150 287 300 150 294 301 minecraft:basalt
setblock 151 287 276 minecraft:packed_ice
setblock 151 287 277 minecraft:snow_block
setblock 151 287 278 minecraft:basalt
fill 151 287 287 151 295 287 minecraft:basalt
setblock 151 287 301 minecraft:basalt
setblock 152 287 276 minecraft:snow_block
fill 152 287 277 152 290 277 minecraft:packed_ice
setblock 152 287 278 minecraft:magma_block
fill 152 287 286 152 295 286 minecraft:basalt
fill 152 287 289 153 287 290 minecraft:blue_ice
setblock 152 287 302 minecraft:magma_block
setblock 152 287 316 minecraft:snow_block
fill 153 287 276 156 287 276 minecraft:packed_ice
fill 153 287 277 154 287 277 minecraft:basalt
fill 153 287 285 153 294 285 minecraft:basalt
setblock 153 287 291 minecraft:blue_ice
fill 153 287 303 153 294 303 minecraft:basalt
setblock 153 287 315 minecraft:snow_block
fill 153 287 316 156 287 316 minecraft:packed_ice
fill 154 287 283 154 293 284 minecraft:basalt
setblock 154 287 290 minecraft:blue_ice
fill 154 287 304 154 293 304 minecraft:basalt
fill 154 287 315 154 289 315 minecraft:packed_ice
setblock 155 287 277 minecraft:magma_block
setblock 155 287 283 minecraft:magma_block
fill 156 287 283 157 294 283 minecraft:basalt
fill 156 287 305 157 287 305 minecraft:basalt
fill 157 287 276 157 287 277 minecraft:basalt
fill 157 287 282 157 293 282 minecraft:basalt
fill 157 287 306 157 293 306 minecraft:basalt
setblock 157 287 312 minecraft:basalt
setblock 157 287 316 minecraft:snow_block
setblock 158 287 276 minecraft:magma_block
fill 158 287 277 163 287 277 minecraft:basalt
setblock 158 287 282 minecraft:magma_block
setblock 158 287 306 minecraft:magma_block
setblock 158 287 312 minecraft:magma_block
fill 158 287 316 158 290 316 minecraft:packed_ice
fill 159 287 282 162 294 282 minecraft:basalt
fill 159 287 306 162 294 306 minecraft:basalt
fill 160 287 276 163 287 276 minecraft:basalt
fill 160 287 312 163 287 312 minecraft:basalt
setblock 162 287 316 minecraft:snow_block
fill 163 287 278 169 287 278 minecraft:basalt
fill 163 287 283 163 293 283 minecraft:basalt
fill 163 287 305 165 294 305 minecraft:basalt
fill 163 287 311 167 287 311 minecraft:basalt
fill 163 287 316 166 287 316 minecraft:packed_ice
fill 164 287 276 166 287 276 minecraft:packed_ice
setblock 164 287 277 minecraft:magma_block
setblock 164 287 283 minecraft:magma_block
fill 165 287 315 167 287 315 minecraft:packed_ice
fill 166 287 284 166 294 284 minecraft:basalt
fill 166 287 304 175 287 304 minecraft:basalt
fill 166 287 310 169 287 310 minecraft:basalt
setblock 167 287 276 minecraft:snow_block
setblock 167 287 285 minecraft:magma_block
setblock 167 287 303 minecraft:magma_block
setblock 167 287 316 minecraft:snow_block
fill 168 287 276 170 287 277 minecraft:packed_ice
fill 168 287 280 171 287 280 minecraft:basalt
fill 168 287 286 168 294 286 minecraft:basalt
fill 168 287 302 168 295 302 minecraft:basalt
setblock 168 287 314 minecraft:packed_ice
setblock 168 287 315 minecraft:snow_block
fill 168 287 316 171 287 316 minecraft:packed_ice
fill 169 287 287 169 295 287 minecraft:basalt
setblock 169 287 301 minecraft:basalt
fill 169 287 307 172 287 307 minecraft:basalt
setblock 169 287 314 minecraft:snow_block
fill 169 287 315 172 287 315 minecraft:packed_ice
setblock 170 287 278 minecraft:snow_block
fill 170 287 288 171 293 288 minecraft:basalt
fill 170 287 300 171 293 300 minecraft:basalt
fill 170 287 314 173 287 314 minecraft:packed_ice
setblock 171 287 276 minecraft:packed_ice
setblock 171 287 277 minecraft:snow_block
fill 171 287 278 171 290 278 minecraft:packed_ice
fill 171 287 282 173 287 282 minecraft:basalt
fill 171 287 290 171 294 291 minecraft:basalt
fill 171 287 297 171 294 298 minecraft:basalt
fill 171 287 306 173 287 306 minecraft:basalt
setblock 172 287 276 minecraft:snow_block
fill 172 287 277 172 290 277 minecraft:packed_ice
fill 172 287 284 175 287 285 minecraft:basalt
fill 172 287 305 174 287 305 minecraft:basalt
setblock 172 287 316 minecraft:snow_block
fill 173 287 276 173 290 276 minecraft:packed_ice
setblock 173 287 307 minecraft:magma_block
setblock 173 287 315 minecraft:snow_block
fill 173 287 316 176 287 316 minecraft:packed_ice
setblock 174 287 278 minecraft:packed_ice
setblock 174 287 283 minecraft:basalt
fill 174 287 302 175 287 303 minecraft:basalt
setblock 174 287 314 minecraft:snow_block
fill 174 287 315 177 287 315 minecraft:packed_ice
fill 175 287 314 175 290 314 minecraft:packed_ice
setblock 176 287 277 minecraft:snow_block
setblock 176 287 285 minecraft:magma_block
setblock 176 287 302 minecraft:basalt
setblock 176 287 303 minecraft:magma_block
setblock 177 287 276 minecraft:snow_block
fill 177 287 277 177 290 277 minecraft:packed_ice
fill 177 287 292 178 287 293 minecraft:basalt
fill 177 287 295 178 287 296 minecraft:basalt
fill 177 287 298 177 287 301 minecraft:basalt
setblock 177 287 316 minecraft:snow_block
fill 178 287 276 178 290 276 minecraft:packed_ice
setblock 178 287 291 minecraft:basalt
setblock 178 287 294 minecraft:basalt
setblock 178 287 297 minecraft:basalt
setblock 178 287 315 minecraft:snow_block
fill 178 287 316 178 290 316 minecraft:packed_ice
fill 179 287 315 179 290 315 minecraft:packed_ice
setblock 181 287 276 minecraft:packed_ice
fill 182 287 294 182 287 295 minecraft:packed_ice
setblock 182 287 296 minecraft:snow_block
fill 182 287 297 182 290 297 minecraft:packed_ice
setblock 182 287 301 minecraft:snow_block
fill 182 287 302 182 289 303 minecraft:packed_ice
setblock 182 287 311 minecraft:snow_block
fill 182 287 312 182 290 312 minecraft:packed_ice
setblock 182 287 316 minecraft:snow_block
fill 183 287 277 183 297 277 minecraft:snow_block
setblock 141 288 287 minecraft:light_blue_concrete
fill 142 288 291 142 288 294 minecraft:packed_ice
setblock 142 288 295 minecraft:snow_block
fill 142 288 296 142 288 299 minecraft:packed_ice
setblock 142 288 300 minecraft:snow_block
fill 142 288 301 143 290 301 minecraft:packed_ice
setblock 142 288 304 minecraft:packed_ice
fill 143 288 276 145 288 276 minecraft:packed_ice
fill 143 288 290 143 288 297 minecraft:basalt
setblock 143 288 299 minecraft:snow_block
fill 143 288 300 143 291 300 minecraft:packed_ice
fill 143 288 316 145 288 316 minecraft:packed_ice
setblock 145 288 285 minecraft:magma_block
fill 145 288 286 146 288 286 minecraft:basalt
setblock 145 288 303 minecraft:magma_block
setblock 146 288 276 minecraft:snow_block
fill 146 288 277 147 290 277 minecraft:packed_ice
fill 146 288 284 146 288 285 minecraft:basalt
fill 146 288 303 146 288 304 minecraft:basalt
setblock 146 288 316 minecraft:snow_block
fill 147 288 276 147 291 276 minecraft:packed_ice
fill 147 288 284 147 289 284 minecraft:basalt
fill 147 288 305 148 288 305 minecraft:basalt
fill 147 288 316 150 288 316 minecraft:packed_ice
fill 148 288 282 149 288 282 minecraft:basalt
fill 148 288 306 149 288 306 minecraft:basalt
fill 148 288 315 148 290 315 minecraft:packed_ice
setblock 149 288 278 minecraft:snow_block
fill 149 288 281 151 288 281 minecraft:basalt
fill 149 288 291 149 295 297 minecraft:basalt
fill 149 288 307 151 288 307 minecraft:basalt
setblock 150 288 277 minecraft:snow_block
fill 150 288 278 152 289 278 minecraft:packed_ice
fill 150 288 280 152 288 280 minecraft:basalt
fill 150 288 289 150 294 290 minecraft:basalt
fill 150 288 298 150 294 299 minecraft:basalt
setblock 151 288 276 minecraft:snow_block
fill 151 288 277 151 291 277 minecraft:packed_ice
fill 151 288 279 154 288 279 minecraft:basalt
fill 151 288 288 151 295 288 minecraft:basalt
fill 151 288 300 151 295 300 minecraft:basalt
setblock 151 288 301 minecraft:magma_block
fill 151 288 309 154 288 309 minecraft:basalt
setblock 151 288 316 minecraft:snow_block
fill 152 288 276 155 288 276 minecraft:packed_ice
fill 152 288 290 153 289 290 minecraft:blue_ice
fill 152 288 302 152 295 302 minecraft:basalt
setblock 152 288 315 minecraft:snow_block
fill 152 288 316 155 288 316 minecraft:packed_ice
fill 153 288 277 154 288 277 minecraft:packed_ice
setblock 153 288 289 minecraft:blue_ice
fill 153 288 310 155 288 310 minecraft:basalt
fill 153 288 315 153 290 315 minecraft:packed_ice
setblock 154 288 285 minecraft:magma_block
setblock 154 288 303 minecraft:magma_block
setblock 155 288 277 minecraft:snow_block
fill 155 288 283 155 294 284 minecraft:basalt
fill 155 288 304 156 288 304 minecraft:basalt
setblock 156 288 276 minecraft:snow_block
fill 156 288 284 156 294 284 minecraft:basalt
fill 156 288 305 156 294 305 minecraft:basalt
setblock 156 288 311 minecraft:basalt
setblock 156 288 316 minecraft:snow_block
fill 157 288 276 160 288 276 minecraft:packed_ice
fill 157 288 277 159 288 277 minecraft:basalt
setblock 157 288 305 minecraft:magma_block
setblock 157 288 311 minecraft:magma_block
fill 157 288 316 157 291 316 minecraft:packed_ice
fill 158 288 282 158 294 283 minecraft:basalt
fill 158 288 305 158 294 306 minecraft:basalt
fill 158 288 311 161 288 311 minecraft:basalt
fill 159 288 283 159 294 283 minecraft:basalt
fill 159 288 305 162 295 305 minecraft:basalt
setblock 160 288 277 minecraft:magma_block
setblock 160 288 283 minecraft:magma_block
setblock 161 288 276 minecraft:snow_block
fill 161 288 277 164 288 277 minecraft:basalt
fill 161 288 283 162 295 283 minecraft:basalt
setblock 161 288 316 minecraft:snow_block
fill 162 288 276 165 288 276 minecraft:packed_ice
fill 162 288 316 165 288 316 minecraft:packed_ice
fill 163 288 278 165 288 278 minecraft:basalt
fill 163 288 311 164 288 311 minecraft:basalt
fill 164 288 283 164 294 284 minecraft:basalt
fill 164 288 304 174 288 304 minecraft:basalt
fill 164 288 315 166 288 315 minecraft:packed_ice
setblock 165 288 277 minecraft:snow_block
fill 165 288 284 165 294 284 minecraft:basalt
setblock 166 288 276 minecraft:snow_block
fill 166 288 277 169 288 277 minecraft:packed_ice
setblock 166 288 278 minecraft:magma_block
fill 166 288 285 167 295 285 minecraft:basalt
fill 166 288 303 167 295 303 minecraft:basalt
fill 166 288 310 167 288 310 minecraft:basalt
setblock 166 288 316 minecraft:snow_block
fill 167 288 276 170 288 276 minecraft:packed_ice
setblock 167 288 278 minecraft:basalt
setblock 167 288 314 minecraft:packed_ice
setblock 167 288 315 minecraft:snow_block
fill 167 288 316 170 288 316 minecraft:packed_ice
setblock 168 288 278 minecraft:packed_ice
fill 168 288 280 170 288 280 minecraft:basalt
setblock 168 288 314 minecraft:snow_block
fill 168 288 315 171 288 315 minecraft:packed_ice
setblock 169 288 278 minecraft:snow_block
setblock 169 288 279 minecraft:basalt
fill 169 288 288 169 295 288 minecraft:basalt
fill 169 288 300 169 295 300 minecraft:basalt
setblock 169 288 301 minecraft:magma_block
fill 169 288 307 171 288 307 minecraft:basalt
setblock 169 288 309 minecraft:basalt
fill 169 288 314 172 288 314 minecraft:packed_ice
setblock 170 288 277 minecraft:snow_block
fill 170 288 278 170 291 278 minecraft:packed_ice
fill 170 288 289 170 295 290 minecraft:basalt
fill 170 288 298 170 295 299 minecraft:basalt
setblock 171 288 276 minecraft:snow_block
fill 171 288 277 171 291 277 minecraft:packed_ice
fill 171 288 282 171 289 282 minecraft:basalt
fill 171 288 292 171 288 296 minecraft:basalt
fill 171 288 306 171 289 306 minecraft:basalt
setblock 171 288 316 minecraft:snow_block
fill 172 288 276 172 291 276 minecraft:packed_ice
setblock 172 288 282 minecraft:magma_block
fill 172 288 284 174 288 285 minecraft:basalt
fill 172 288 305 173 288 305 minecraft:basalt
setblock 172 288 306 minecraft:magma_block
setblock 172 288 315 minecraft:snow_block
fill 172 288 316 175 288 316 minecraft:packed_ice
setblock 173 288 314 minecraft:snow_block
fill 173 288 315 176 288 315 minecraft:packed_ice
setblock 174 288 278 minecraft:snow_block
fill 174 288 302 174 289 303 minecraft:basalt
fill 174 288 314 174 291 314 minecraft:packed_ice
setblock 175 288 275 minecraft:white_concrete
setblock 175 288 277 minecraft:snow_block
fill 175 288 285 175 288 289 minecraft:basalt
setblock 175 288 302 minecraft:magma_block
setblock 175 288 303 minecraft:basalt
setblock 176 288 276 minecraft:snow_block
fill 176 288 277 176 291 277 minecraft:packed_ice
fill 176 288 287 176 288 289 minecraft:basalt
setblock 176 288 312 minecraft:snow_block
setblock 176 288 316 minecraft:snow_block
fill 177 288 276 177 291 276 minecraft:packed_ice
setblock 177 288 290 minecraft:basalt
fill 177 288 292 177 288 293 minecraft:basalt
fill 177 288 295 177 288 296 minecraft:basalt
setblock 177 288 298 minecraft:basalt
setblock 177 288 315 minecraft:snow_block
fill 177 288 316 177 291 316 minecraft:packed_ice
setblock 178 288 312 minecraft:snow_block
setblock 178 288 314 minecraft:snow_block
fill 178 288 315 178 290 315 minecraft:packed_ice
setblock 181 288 276 minecraft:snow_block
fill 181 288 297 181 288 300 minecraft:packed_ice
setblock 181 288 316 minecraft:snow_block
fill 182 288 276 182 291 276 minecraft:packed_ice
fill 182 288 293 182 288 294 minecraft:packed_ice
setblock 182 288 295 minecraft:snow_block
fill 182 288 296 182 291 296 minecraft:packed_ice
fill 182 288 298 182 288 299 minecraft:packed_ice
setblock 182 288 300 minecraft:snow_block
fill 182 288 301 182 291 301 minecraft:packed_ice
setblock 182 288 304 minecraft:packed_ice
setblock 182 288 305 minecraft:snow_block
fill 182 288 311 182 291 311 minecraft:packed_ice
setblock 182 288 315 minecraft:snow_block
fill 182 288 316 182 291 316 minecraft:packed_ice
fill 141 289 287 141 308 287 minecraft:snow_block
fill 142 289 276 142 289 278 minecraft:packed_ice
fill 142 289 290 142 289 293 minecraft:packed_ice
setblock 142 289 294 minecraft:snow_block
fill 142 289 295 142 289 298 minecraft:packed_ice
setblock 142 289 299 minecraft:snow_block
fill 142 289 300 142 292 300 minecraft:packed_ice
setblock 142 289 304 minecraft:snow_block
fill 142 289 305 142 292 305 minecraft:packed_ice
fill 143 289 276 144 289 276 minecraft:packed_ice
setblock 143 289 292 minecraft:packed_ice
setblock 143 289 293 minecraft:snow_block
fill 143 289 294 143 289 297 minecraft:packed_ice
setblock 143 289 298 minecraft:snow_block
fill 143 289 299 144 291 299 minecraft:packed_ice
setblock 143 289 302 minecraft:packed_ice
setblock 143 289 303 minecraft:snow_block
fill 143 289 316 144 289 316 minecraft:packed_ice
setblock 144 289 290 minecraft:magma_block
setblock 144 289 293 minecraft:magma_block
setblock 144 289 296 minecraft:magma_block
fill 144 289 300 144 289 301 minecraft:packed_ice
setblock 145 289 276 minecraft:snow_block
fill 145 289 277 145 292 277 minecraft:packed_ice
fill 145 289 288 145 289 290 minecraft:basalt
fill 145 289 300 145 289 301 minecraft:basalt
setblock 145 289 316 minecraft:snow_block
fill 146 289 276 146 292 276 minecraft:packed_ice
fill 146 289 285 146 289 286 minecraft:basalt
fill 146 289 302 146 289 303 minecraft:basalt
fill 146 289 316 149 289 316 minecraft:packed_ice
setblock 147 289 278 minecraft:packed_ice
setblock 147 289 304 minecraft:magma_block
setblock 148 289 278 minecraft:snow_block
fill 148 289 304 148 289 305 minecraft:basalt
setblock 149 289 276 minecraft:packed_ice
setblock 149 289 277 minecraft:snow_block
fill 149 289 278 149 292 278 minecraft:packed_ice
setblock 149 289 282 minecraft:basalt
setblock 149 289 306 minecraft:basalt
setblock 150 289 276 minecraft:snow_block
fill 150 289 277 150 292 277 minecraft:packed_ice
fill 150 289 279 151 289 279 minecraft:packed_ice
fill 150 289 281 151 289 281 minecraft:basalt
setblock 150 289 291 minecraft:magma_block
fill 150 289 292 150 294 292 minecraft:basalt
fill 150 289 296 150 295 296 minecraft:basalt
setblock 150 289 297 minecraft:magma_block
fill 150 289 307 151 289 307 minecraft:basalt
setblock 150 289 316 minecraft:snow_block
fill 151 289 276 154 289 276 minecraft:packed_ice
fill 151 289 280 152 289 280 minecraft:basalt
fill 151 289 289 151 295 289 minecraft:basalt
fill 151 289 299 151 295 299 minecraft:basalt
fill 151 289 301 152 295 301 minecraft:basalt
fill 151 289 308 152 289 308 minecraft:basalt
setblock 151 289 315 minecraft:snow_block
fill 151 289 316 154 289 316 minecraft:packed_ice
setblock 152 289 279 minecraft:snow_block
fill 152 289 287 152 295 287 minecraft:basalt
fill 152 289 315 152 290 315 minecraft:packed_ice
setblock 153 289 275 minecraft:light_blue_concrete
setblock 153 289 277 minecraft:packed_ice
setblock 153 289 278 minecraft:snow_block
fill 153 289 279 154 289 279 minecraft:basalt
fill 153 289 286 153 295 286 minecraft:basalt
setblock 153 289 302 minecraft:magma_block
fill 153 289 309 154 289 309 minecraft:basalt
setblock 154 289 277 minecraft:snow_block
fill 154 289 278 155 291 278 minecraft:packed_ice
fill 154 289 285 155 289 285 minecraft:basalt
fill 154 289 303 155 289 303 minecraft:basalt
setblock 155 289 276 minecraft:snow_block
fill 155 289 277 158 289 277 minecraft:packed_ice
fill 155 289 304 155 295 304 minecraft:basalt
setblock 155 289 316 minecraft:snow_block
fill 156 289 276 159 289 276 minecraft:packed_ice
fill 156 289 278 161 289 278 minecraft:basalt
setblock 156 289 304 minecraft:magma_block
fill 156 289 309 158 290 309 minecraft:basalt
setblock 156 289 310 minecraft:magma_block
fill 156 289 316 156 292 316 minecraft:packed_ice
fill 157 289 284 158 289 284 minecraft:basalt
fill 157 289 304 157 295 305 minecraft:basalt
fill 157 289 310 158 289 310 minecraft:basalt
fill 158 289 304 158 295 304 minecraft:basalt
setblock 159 289 277 minecraft:snow_block
setblock 160 289 276 minecraft:snow_block
fill 160 289 277 163 289 277 minecraft:packed_ice
fill 160 289 283 160 295 283 minecraft:basalt
setblock 160 289 316 minecraft:snow_block
fill 161 289 276 164 289 276 minecraft:packed_ice
fill 161 289 316 164 289 316 minecraft:packed_ice
setblock 162 289 278 minecraft:magma_block
fill 162 289 279 162 290 279 minecraft:basalt
setblock 162 289 284 minecraft:magma_block
fill 162 289 304 173 289 304 minecraft:basalt
fill 162 289 309 162 289 310 minecraft:basalt
fill 163 289 278 164 289 278 minecraft:basalt
fill 163 289 284 163 295 284 minecraft:basalt
setblock 164 289 277 minecraft:snow_block
setblock 164 289 310 minecraft:basalt
fill 164 289 315 165 289 315 minecraft:packed_ice
setblock 165 289 276 minecraft:snow_block
fill 165 289 277 167 289 278 minecraft:packed_ice
fill 165 289 285 165 295 285 minecraft:basalt
fill 165 289 303 165 295 303 minecraft:basalt
setblock 165 289 316 minecraft:snow_block
fill 166 289 276 169 289 276 minecraft:packed_ice
setblock 166 289 315 minecraft:snow_block
fill 166 289 316 169 289 316 minecraft:packed_ice
fill 167 289 286 167 295 286 minecraft:basalt
fill 167 289 302 167 295 302 minecraft:basalt
setblock 167 289 314 minecraft:snow_block
fill 167 289 315 170 289 315 minecraft:packed_ice
setblock 168 289 277 minecraft:packed_ice
setblock 168 289 278 minecraft:snow_block
fill 168 289 279 171 289 279 minecraft:packed_ice
fill 168 289 280 169 289 280 minecraft:basalt
fill 168 289 287 168 295 287 minecraft:basalt
fill 168 289 301 169 294 301 minecraft:basalt
fill 168 289 308 169 289 308 minecraft:basalt
fill 168 289 314 171 289 314 minecraft:packed_ice
setblock 168 289 317 minecraft:light_blue_concrete
setblock 169 289 277 minecraft:snow_block
fill 169 289 278 169 292 278 minecraft:packed_ice
fill 169 289 289 169 295 289 minecraft:basalt
fill 169 289 299 169 295 299 minecraft:basalt
fill 169 289 307 170 289 307 minecraft:basalt
setblock 170 289 276 minecraft:snow_block
fill 170 289 277 170 292 277 minecraft:packed_ice
fill 170 289 291 170 289 292 minecraft:basalt
fill 170 289 296 170 295 297 minecraft:basalt
setblock 170 289 316 minecraft:snow_block
fill 171 289 276 171 292 276 minecraft:packed_ice
fill 171 289 292 171 295 292 minecraft:basalt
setblock 171 289 293 minecraft:magma_block
fill 171 289 294 171 294 296 minecraft:basalt
setblock 171 289 315 minecraft:snow_block
fill 171 289 316 174 289 316 minecraft:packed_ice
setblock 172 289 278 minecraft:packed_ice
fill 172 289 283 172 289 285 minecraft:basalt
setblock 172 289 305 minecraft:basalt
setblock 172 289 314 minecraft:snow_block
fill 172 289 315 175 289 315 minecraft:packed_ice
setblock 173 289 278 minecraft:snow_block
fill 173 289 284 173 289 286 minecraft:basalt
fill 173 289 314 173 291 314 minecraft:packed_ice
setblock 174 289 277 minecraft:snow_block
fill 174 289 278 175 289 278 minecraft:packed_ice
setblock 174 289 285 minecraft:basalt
setblock 174 289 286 minecraft:magma_block
fill 175 289 275 175 289 276 minecraft:snow_block
fill 175 289 277 175 292 277 minecraft:packed_ice
fill 175 289 287 175 289 289 minecraft:basalt
fill 175 289 299 175 289 301 minecraft:basalt
setblock 175 289 316 minecraft:snow_block
fill 176 289 276 176 292 276 minecraft:packed_ice
setblock 176 289 315 minecraft:snow_block
fill 176 289 316 176 292 316 minecraft:packed_ice
fill 177 289 315 177 291 315 minecraft:packed_ice
setblock 180 289 276 minecraft:snow_block
setblock 180 289 316 minecraft:snow_block
fill 181 289 276 181 292 276 minecraft:packed_ice
fill 181 289 296 181 289 299 minecraft:packed_ice
setblock 181 289 300 minecraft:snow_block
fill 181 289 301 181 291 302 minecraft:packed_ice
fill 181 289 316 181 292 316 minecraft:packed_ice
fill 182 289 277 182 290 277 minecraft:packed_ice
setblock 182 289 293 minecraft:packed_ice
setblock 182 289 294 minecraft:snow_block
fill 182 289 295 182 292 295 minecraft:packed_ice
setblock 182 289 298 minecraft:packed_ice
setblock 182 289 299 minecraft:snow_block
fill 182 289 300 182 292 300 minecraft:packed_ice
setblock 182 289 304 minecraft:snow_block
fill 182 289 305 182 290 307 minecraft:packed_ice
fill 182 289 310 182 291 310 minecraft:packed_ice
setblock 182 289 314 minecraft:snow_block
fill 182 289 315 182 292 315 minecraft:packed_ice
fill 142 290 276 142 290 277 minecraft:packed_ice
setblock 142 290 278 minecraft:snow_block
fill 142 290 279 142 291 281 minecraft:packed_ice
fill 142 290 290 142 290 292 minecraft:packed_ice
setblock 142 290 293 minecraft:snow_block
fill 142 290 294 142 290 297 minecraft:packed_ice
setblock 142 290 298 minecraft:snow_block
fill 142 290 299 142 293 299 minecraft:packed_ice
setblock 142 290 302 minecraft:packed_ice
setblock 142 290 303 minecraft:snow_block
fill 142 290 304 142 293 304 minecraft:packed_ice
fill 142 290 306 142 291 306 minecraft:packed_ice
setblock 143 290 276 minecraft:packed_ice
setblock 143 290 292 minecraft:snow_block
fill 143 290 293 143 290 296 minecraft:packed_ice
setblock 143 290 297 minecraft:snow_block
fill 143 290 298 144 292 298 minecraft:packed_ice
setblock 143 290 302 minecraft:snow_block
fill 143 290 303 143 293 303 minecraft:packed_ice
setblock 143 290 316 minecraft:packed_ice
setblock 144 290 276 minecraft:snow_block
fill 144 290 277 144 293 277 minecraft:packed_ice
fill 144 290 293 144 290 295 minecraft:packed_ice
setblock 144 290 296 minecraft:snow_block
fill 144 290 297 144 293 297 minecraft:packed_ice
setblock 144 290 300 minecraft:packed_ice
setblock 144 290 301 minecraft:snow_block
fill 144 290 302 144 293 302 minecraft:packed_ice
setblock 144 290 316 minecraft:snow_block
fill 145 290 276 145 293 276 minecraft:packed_ice
fill 145 290 289 146 290 290 minecraft:basalt
fill 145 290 316 148 290 316 minecraft:packed_ice
setblock 146 290 278 minecraft:packed_ice
setblock 146 290 288 minecraft:magma_block
fill 146 290 298 146 291 299 minecraft:basalt
setblock 146 290 300 minecraft:magma_block
setblock 147 290 278 minecraft:snow_block
setblock 148 290 276 minecraft:packed_ice
setblock 148 290 277 minecraft:snow_block
fill 148 290 278 148 293 278 minecraft:packed_ice
fill 148 290 304 149 290 304 minecraft:basalt
setblock 149 290 276 minecraft:snow_block
fill 149 290 277 149 293 277 minecraft:packed_ice
fill 149 290 279 150 290 279 minecraft:packed_ice
setblock 149 290 305 minecraft:magma_block
setblock 149 290 316 minecraft:snow_block
fill 150 290 276 153 290 276 minecraft:packed_ice
fill 150 290 278 151 290 278 minecraft:packed_ice
fill 150 290 291 151 290 291 minecraft:basalt
fill 150 290 293 150 294 295 minecraft:basalt
fill 150 290 297 151 290 297 minecraft:basalt
setblock 150 290 315 minecraft:snow_block
fill 150 290 316 153 290 316 minecraft:packed_ice
setblock 151 290 279 minecraft:snow_block
setblock 151 290 281 minecraft:basalt
fill 151 290 290 151 295 290 minecraft:basalt
fill 151 290 298 151 295 298 minecraft:basalt
setblock 151 290 307 minecraft:basalt
fill 151 290 315 151 291 315 minecraft:packed_ice
setblock 152 290 278 minecraft:snow_block
fill 152 290 279 154 291 279 minecraft:packed_ice
fill 152 290 288 152 295 288 minecraft:basalt
fill 152 290 300 152 295 300 minecraft:basalt
setblock 152 290 307 minecraft:magma_block
fill 153 290 275 153 307 275 minecraft:snow_block
setblock 153 290 277 minecraft:snow_block
fill 153 290 278 153 293 278 minecraft:packed_ice
fill 153 290 287 153 295 287 minecraft:basalt
setblock 153 290 290 minecraft:blue_ice
fill 153 290 301 153 295 302 minecraft:basalt
fill 153 290 307 153 291 307 minecraft:basalt
setblock 154 290 276 minecraft:snow_block
fill 154 290 277 157 290 277 minecraft:packed_ice
fill 154 290 285 154 295 286 minecraft:basalt
fill 154 290 302 154 295 303 minecraft:basalt
setblock 154 290 316 minecraft:snow_block
fill 155 290 276 158 290 276 minecraft:packed_ice
setblock 155 290 279 minecraft:magma_block
fill 155 290 280 155 291 280 minecraft:basalt
setblock 155 290 285 minecraft:magma_block
setblock 155 290 303 minecraft:magma_block
fill 155 290 308 155 291 308 minecraft:basalt
setblock 155 290 309 minecraft:magma_block
fill 155 290 316 155 292 316 minecraft:packed_ice
setblock 156 290 278 minecraft:packed_ice
fill 156 290 285 157 295 285 minecraft:basalt
fill 156 290 303 156 295 304 minecraft:basalt
setblock 157 290 278 minecraft:snow_block
fill 157 290 284 157 295 284 minecraft:basalt
fill 157 290 303 157 295 303 minecraft:basalt
setblock 158 290 277 minecraft:snow_block
fill 158 290 278 161 290 278 minecraft:packed_ice
setblock 158 290 284 minecraft:magma_block
setblock 159 290 276 minecraft:snow_block
fill 159 290 277 162 290 277 minecraft:packed_ice
fill 159 290 284 162 295 284 minecraft:basalt
fill 159 290 304 160 294 304 minecraft:basalt
setblock 159 290 316 minecraft:snow_block
fill 160 290 276 163 290 276 minecraft:packed_ice
fill 160 290 316 163 290 316 minecraft:packed_ice
setblock 161 290 304 minecraft:magma_block
fill 161 290 309 163 290 309 minecraft:basalt
setblock 162 290 278 minecraft:snow_block
fill 162 290 304 172 290 304 minecraft:basalt
setblock 163 290 277 minecraft:snow_block
fill 163 290 278 166 290 278 minecraft:packed_ice
fill 163 290 285 163 295 285 minecraft:basalt
fill 163 290 303 163 295 303 minecraft:basalt
fill 163 290 315 164 290 315 minecraft:packed_ice
setblock 164 290 276 minecraft:snow_block
fill 164 290 277 167 290 277 minecraft:packed_ice
setblock 164 290 279 minecraft:magma_block
fill 164 290 280 164 291 280 minecraft:basalt
setblock 164 290 285 minecraft:magma_block
setblock 164 290 303 minecraft:magma_block
fill 164 290 308 164 291 308 minecraft:basalt
setblock 164 290 309 minecraft:magma_block
setblock 164 290 316 minecraft:snow_block
fill 165 290 276 168 290 276 minecraft:packed_ice
setblock 165 290 279 minecraft:basalt
setblock 165 290 309 minecraft:basalt
setblock 165 290 315 minecraft:snow_block
fill 165 290 316 168 290 316 minecraft:packed_ice
setblock 166 290 279 minecraft:snow_block
fill 166 290 286 166 295 286 minecraft:basalt
fill 166 290 302 166 295 302 minecraft:basalt
fill 166 290 315 169 290 315 minecraft:packed_ice
setblock 167 290 278 minecraft:snow_block
fill 167 290 279 170 290 279 minecraft:packed_ice
setblock 167 290 287 minecraft:magma_block
fill 167 290 301 167 295 301 minecraft:basalt
fill 167 290 307 167 291 307 minecraft:basalt
setblock 167 290 308 minecraft:magma_block
fill 167 290 314 170 290 314 minecraft:packed_ice
setblock 168 290 277 minecraft:snow_block
fill 168 290 278 168 293 278 minecraft:packed_ice
fill 168 290 288 168 295 288 minecraft:basalt
fill 168 290 300 168 295 300 minecraft:basalt
fill 168 290 317 168 308 317 minecraft:snow_block
setblock 169 290 276 minecraft:snow_block
fill 169 290 277 169 293 277 minecraft:packed_ice
setblock 169 290 281 minecraft:basalt
fill 169 290 290 169 290 291 minecraft:basalt
fill 169 290 297 169 290 298 minecraft:basalt
setblock 169 290 307 minecraft:basalt
setblock 169 290 316 minecraft:snow_block
fill 170 290 276 170 293 276 minecraft:packed_ice
fill 170 290 291 170 295 291 minecraft:basalt
setblock 170 290 292 minecraft:magma_block
fill 170 290 293 170 295 294 minecraft:basalt
setblock 170 290 295 minecraft:magma_block
setblock 170 290 315 minecraft:snow_block
fill 170 290 316 173 290 316 minecraft:packed_ice
setblock 171 290 279 minecraft:snow_block
fill 171 290 293 171 295 293 minecraft:basalt
setblock 171 290 314 minecraft:snow_block
fill 171 290 315 174 290 315 minecraft:packed_ice
setblock 172 290 278 minecraft:snow_block
fill 172 290 284 172 290 285 minecraft:basalt
setblock 172 290 303 minecraft:basalt
fill 172 290 314 172 292 314 minecraft:packed_ice
setblock 173 290 277 minecraft:snow_block
fill 173 290 278 174 291 278 minecraft:packed_ice
setblock 173 290 285 minecraft:magma_block
setblock 173 290 286 minecraft:basalt
setblock 173 290 303 minecraft:magma_block
setblock 174 290 276 minecraft:snow_block
fill 174 290 277 174 293 277 minecraft:packed_ice
setblock 174 290 316 minecraft:snow_block
fill 175 290 275 175 294 275 minecraft:snow_block
fill 175 290 276 175 293 276 minecraft:packed_ice
fill 175 290 289 175 290 291 minecraft:basalt
fill 175 290 296 175 290 299 minecraft:basalt
setblock 175 290 315 minecraft:snow_block
fill 175 290 316 175 293 316 minecraft:packed_ice
fill 176 290 315 176 291 315 minecraft:packed_ice
setblock 179 290 276 minecraft:snow_block
setblock 179 290 316 minecraft:snow_block
fill 180 290 276 180 292 276 minecraft:packed_ice
fill 180 290 316 180 292 316 minecraft:packed_ice
fill 181 290 296 181 290 298 minecraft:packed_ice
setblock 181 290 299 minecraft:snow_block
fill 181 290 300 181 293 300 minecraft:packed_ice
setblock 181 290 303 minecraft:packed_ice
setblock 181 290 304 minecraft:snow_block
setblock 182 290 278 minecraft:snow_block
setblock 182 290 293 minecraft:snow_block
fill 182 290 294 182 293 294 minecraft:packed_ice
setblock 182 290 298 minecraft:snow_block
fill 182 290 299 182 293 299 minecraft:packed_ice
setblock 182 290 302 minecraft:packed_ice
setblock 182 290 303 minecraft:snow_block
fill 182 290 304 182 293 304 minecraft:packed_ice
setblock 182 290 308 minecraft:snow_block
fill 182 290 309 182 293 309 minecraft:packed_ice
setblock 182 290 313 minecraft:snow_block
fill 182 290 314 182 292 314 minecraft:packed_ice
setblock 142 291 275 minecraft:white_concrete
setblock 142 291 276 minecraft:packed_ice
setblock 142 291 277 minecraft:snow_block
fill 142 291 278 143 293 278 minecraft:packed_ice
setblock 142 291 282 minecraft:snow_block
fill 142 291 283 142 294 283 minecraft:packed_ice
fill 142 291 289 142 291 291 minecraft:packed_ice
setblock 142 291 292 minecraft:snow_block
fill 142 291 293 142 291 296 minecraft:packed_ice
setblock 142 291 297 minecraft:snow_block
fill 142 291 298 142 294 298 minecraft:packed_ice
setblock 142 291 301 minecraft:packed_ice
setblock 142 291 302 minecraft:snow_block
fill 142 291 303 142 294 303 minecraft:packed_ice
setblock 143 291 276 minecraft:snow_block
fill 143 291 277 143 294 277 minecraft:packed_ice
fill 143 291 279 143 291 280 minecraft:packed_ice
fill 143 291 292 143 291 295 minecraft:packed_ice
setblock 143 291 296 minecraft:snow_block
fill 143 291 297 143 294 297 minecraft:packed_ice
setblock 143 291 301 minecraft:snow_block
fill 143 291 302 143 294 302 minecraft:packed_ice
fill 143 291 304 143 292 304 minecraft:packed_ice
fill 144 291 276 144 294 276 minecraft:packed_ice
setblock 144 291 294 minecraft:packed_ice
setblock 144 291 295 minecraft:snow_block
fill 144 291 296 145 291 296 minecraft:packed_ice
setblock 144 291 300 minecraft:snow_block
fill 144 291 301 144 294 301 minecraft:packed_ice
fill 144 291 316 147 291 316 minecraft:packed_ice
setblock 144 291 317 minecraft:light_blue_concrete
setblock 145 291 278 minecraft:packed_ice
fill 145 291 297 145 291 298 minecraft:packed_ice
setblock 145 291 299 minecraft:snow_block
fill 145 291 300 145 293 300 minecraft:packed_ice
setblock 146 291 277 minecraft:packed_ice
setblock 146 291 278 minecraft:snow_block
fill 146 291 289 146 291 290 minecraft:basalt
setblock 147 291 277 minecraft:snow_block
fill 147 291 278 147 294 278 minecraft:packed_ice
setblock 148 291 276 minecraft:snow_block
fill 148 291 277 148 294 277 minecraft:packed_ice
fill 148 291 279 149 291 279 minecraft:packed_ice
setblock 148 291 286 minecraft:magma_block
fill 148 291 287 148 292 287 minecraft:basalt
setblock 148 291 316 minecraft:snow_block
fill 149 291 276 152 291 276 minecraft:packed_ice
setblock 149 291 304 minecraft:basalt
setblock 149 291 315 minecraft:snow_block
fill 149 291 316 152 291 316 minecraft:packed_ice
setblock 150 291 278 minecraft:packed_ice
setblock 150 291 279 minecraft:snow_block
fill 150 291 291 150 295 291 minecraft:basalt
fill 150 291 297 150 295 297 minecraft:basalt
setblock 150 291 315 minecraft:packed_ice
setblock 151 291 278 minecraft:snow_block
fill 151 291 279 151 294 279 minecraft:packed_ice
setblock 151 291 283 minecraft:basalt
setblock 151 291 291 minecraft:magma_block
fill 151 291 292 151 295 293 minecraft:basalt
setblock 151 291 294 minecraft:magma_block
fill 151 291 295 151 295 296 minecraft:basalt
setblock 151 291 297 minecraft:magma_block
setblock 151 291 305 minecraft:basalt
setblock 152 291 277 minecraft:snow_block
fill 152 291 278 152 294 278 minecraft:packed_ice
fill 152 291 289 152 295 290 minecraft:basalt
fill 152 291 298 152 295 299 minecraft:basalt
setblock 153 291 276 minecraft:snow_block
fill 153 291 277 156 291 277 minecraft:packed_ice
fill 153 291 288 153 294 288 minecraft:basalt
fill 153 291 300 153 294 300 minecraft:basalt
setblock 153 291 316 minecraft:snow_block
fill 154 291 276 157 291 276 minecraft:packed_ice
setblock 154 291 281 minecraft:magma_block
fill 154 291 282 154 292 282 minecraft:basalt
setblock 154 291 287 minecraft:magma_block
fill 154 291 301 154 295 301 minecraft:basalt
setblock 154 291 307 minecraft:basalt
fill 154 291 316 154 292 316 minecraft:packed_ice
fill 155 291 285 155 295 286 minecraft:basalt
fill 155 291 302 155 295 303 minecraft:basalt
setblock 156 291 278 minecraft:snow_block
fill 156 291 286 156 295 286 minecraft:basalt
fill 156 291 302 156 294 302 minecraft:basalt
setblock 157 291 277 minecraft:snow_block
fill 157 291 278 160 291 278 minecraft:packed_ice
setblock 157 291 280 minecraft:magma_block
setblock 158 291 276 minecraft:snow_block
fill 158 291 277 161 291 277 minecraft:packed_ice
fill 158 291 284 158 295 285 minecraft:basalt
fill 158 291 303 159 295 303 minecraft:basalt
setblock 158 291 316 minecraft:snow_block
fill 159 291 276 162 291 276 minecraft:packed_ice
fill 159 291 285 159 295 285 minecraft:basalt
fill 159 291 316 162 291 316 minecraft:packed_ice
setblock 160 291 285 minecraft:magma_block
setblock 160 291 303 minecraft:magma_block
fill 160 291 308 162 291 308 minecraft:basalt
setblock 161 291 278 minecraft:snow_block
fill 161 291 285 162 294 285 minecraft:basalt
fill 161 291 303 162 294 304 minecraft:basalt
setblock 162 291 277 minecraft:snow_block
fill 162 291 278 165 291 278 minecraft:packed_ice
setblock 163 291 276 minecraft:snow_block
fill 163 291 277 166 291 277 minecraft:packed_ice
fill 163 291 304 171 291 304 minecraft:basalt
setblock 163 291 308 minecraft:magma_block
setblock 163 291 315 minecraft:packed_ice
setblock 163 291 316 minecraft:snow_block
fill 164 291 276 167 291 276 minecraft:packed_ice
fill 164 291 285 164 295 286 minecraft:basalt
fill 164 291 302 164 295 303 minecraft:basalt
setblock 164 291 315 minecraft:snow_block
fill 164 291 316 167 291 316 minecraft:packed_ice
setblock 165 291 279 minecraft:snow_block
fill 165 291 286 165 295 286 minecraft:basalt
fill 165 291 302 165 294 302 minecraft:basalt
fill 165 291 307 165 292 307 minecraft:basalt
fill 165 291 315 168 291 315 minecraft:packed_ice
setblock 166 291 278 minecraft:snow_block
fill 166 291 279 169 291 279 minecraft:packed_ice
fill 166 291 287 167 295 287 minecraft:basalt
setblock 166 291 301 minecraft:magma_block
setblock 166 291 307 minecraft:magma_block
setblock 167 291 277 minecraft:snow_block
fill 167 291 278 167 294 278 minecraft:packed_ice
fill 167 291 281 167 291 282 minecraft:basalt
fill 167 291 288 167 295 288 minecraft:basalt
fill 167 291 300 167 295 300 minecraft:basalt
fill 167 291 306 168 291 306 minecraft:basalt
fill 167 291 314 169 291 314 minecraft:packed_ice
setblock 168 291 276 minecraft:snow_block
fill 168 291 277 168 294 277 minecraft:packed_ice
setblock 168 291 282 minecraft:basalt
fill 168 291 289 168 291 290 minecraft:basalt
fill 168 291 298 168 294 299 minecraft:basalt
setblock 168 291 316 minecraft:snow_block
fill 169 291 276 169 294 276 minecraft:packed_ice
fill 169 291 290 169 295 290 minecraft:basalt
setblock 169 291 291 minecraft:magma_block
fill 169 291 292 169 295 293 minecraft:basalt
setblock 169 291 294 minecraft:magma_block
fill 169 291 295 169 295 296 minecraft:basalt
setblock 169 291 297 minecraft:magma_block
fill 169 291 298 169 295 298 minecraft:basalt
setblock 169 291 315 minecraft:snow_block
fill 169 291 316 172 291 316 minecraft:packed_ice
setblock 170 291 279 minecraft:snow_block
fill 170 291 292 170 295 292 minecraft:basalt
fill 170 291 295 170 295 295 minecraft:basalt
setblock 170 291 314 minecraft:snow_block
fill 170 291 315 173 291 315 minecraft:packed_ice
setblock 171 291 278 minecraft:snow_block
setblock 171 291 279 minecraft:packed_ice
fill 171 291 314 171 292 314 minecraft:packed_ice
setblock 172 291 277 minecraft:snow_block
fill 172 291 278 172 293 278 minecraft:packed_ice
fill 172 291 301 172 292 301 minecraft:basalt
setblock 172 291 302 minecraft:magma_block
setblock 173 291 276 minecraft:snow_block
fill 173 291 277 173 294 277 minecraft:packed_ice
setblock 173 291 316 minecraft:snow_block
fill 174 291 276 174 294 276 minecraft:packed_ice
setblock 174 291 315 minecraft:snow_block
fill 174 291 316 174 294 316 minecraft:packed_ice
fill 175 291 315 175 292 315 minecraft:packed_ice
setblock 178 291 276 minecraft:snow_block
setblock 178 291 316 minecraft:snow_block
fill 179 291 276 179 292 276 minecraft:packed_ice
fill 179 291 316 179 292 316 minecraft:packed_ice
fill 181 291 296 181 291 297 minecraft:packed_ice
setblock 181 291 298 minecraft:snow_block
fill 181 291 299 181 294 299 minecraft:packed_ice
setblock 181 291 303 minecraft:snow_block
fill 181 291 304 181 293 305 minecraft:packed_ice
setblock 182 291 277 minecraft:snow_block
fill 182 291 278 182 293 279 minecraft:packed_ice
fill 182 291 293 182 292 293 minecraft:packed_ice
setblock 182 291 297 minecraft:snow_block
fill 182 291 298 182 294 298 minecraft:packed_ice
setblock 182 291 302 minecraft:snow_block
fill 182 291 303 182 294 303 minecraft:packed_ice
fill 182 291 305 182 291 306 minecraft:packed_ice
setblock 182 291 307 minecraft:snow_block
fill 182 291 308 182 294 308 minecraft:packed_ice
setblock 182 291 312 minecraft:snow_block
setblock 182 291 313 minecraft:packed_ice
setblock 141 292 280 minecraft:light_blue_concrete
fill 141 292 281 142 292 281 minecraft:snow_block
fill 141 292 309 141 308 313 minecraft:snow_block
setblock 141 292 314 minecraft:white_concrete
fill 142 292 275 142 292 276 minecraft:snow_block
fill 142 292 277 142 295 277 minecraft:packed_ice
fill 142 292 279 142 292 280 minecraft:packed_ice
fill 142 292 282 143 294 282 minecraft:packed_ice
fill 142 292 284 142 292 285 minecraft:packed_ice
setblock 142 292 286 minecraft:snow_block
fill 142 292 287 142 292 290 minecraft:packed_ice
setblock 142 292 291 minecraft:snow_block
fill 142 292 292 142 292 295 minecraft:packed_ice
setblock 142 292 296 minecraft:snow_block
fill 142 292 297 142 295 297 minecraft:packed_ice
setblock 142 292 301 minecraft:snow_block
fill 142 292 302 142 295 302 minecraft:packed_ice
setblock 142 292 306 minecraft:snow_block
fill 143 292 276 143 295 276 minecraft:packed_ice
setblock 143 292 279 minecraft:packed_ice
setblock 143 292 280 minecraft:snow_block
fill 143 292 281 143 295 281 minecraft:packed_ice
fill 143 292 292 143 292 294 minecraft:packed_ice
setblock 143 292 295 minecraft:snow_block
fill 143 292 296 144 294 296 minecraft:packed_ice
setblock 143 292 299 minecraft:packed_ice
setblock 143 292 300 minecraft:snow_block
fill 143 292 301 143 295 301 minecraft:packed_ice
setblock 143 292 305 minecraft:snow_block
setblock 144 292 278 minecraft:light[level=15]
setblock 144 292 285 minecraft:light[level=12]
setblock 144 292 286 minecraft:light[level=15]
setblock 144 292 292 minecraft:light[level=12]
setblock 144 292 294 minecraft:snow_block
fill 144 292 295 144 293 295 minecraft:packed_ice
setblock 144 292 299 minecraft:snow_block
fill 144 292 300 144 295 300 minecraft:packed_ice
setblock 144 292 303 minecraft:packed_ice
setblock 144 292 306 minecraft:light[level=12]
setblock 144 292 310 minecraft:light[level=15]
setblock 144 292 313 minecraft:light[level=12]
fill 144 292 316 146 292 316 minecraft:packed_ice
fill 144 292 317 144 308 317 minecraft:snow_block
setblock 145 292 278 minecraft:snow_block
setblock 145 292 297 minecraft:packed_ice
setblock 145 292 298 minecraft:snow_block
fill 145 292 299 145 293 299 minecraft:packed_ice
setblock 145 292 317 minecraft:light_blue_concrete
setblock 146 292 277 minecraft:snow_block
fill 146 292 278 146 295 278 minecraft:packed_ice
fill 146 292 317 150 300 317 minecraft:snow_block
setblock 147 292 276 minecraft:snow_block
fill 147 292 277 147 295 277 minecraft:packed_ice
fill 147 292 279 148 292 279 minecraft:packed_ice
setblock 147 292 290 minecraft:basalt
setblock 147 292 291 minecraft:magma_block
fill 147 292 296 147 293 296 minecraft:basalt
setblock 147 292 297 minecraft:magma_block
setblock 147 292 298 minecraft:basalt
setblock 147 292 316 minecraft:snow_block
fill 148 292 276 151 292 276 minecraft:packed_ice
setblock 148 292 301 minecraft:basalt
fill 148 292 316 151 292 316 minecraft:packed_ice
setblock 149 292 279 minecraft:snow_block
setblock 150 292 278 minecraft:snow_block
fill 150 292 279 150 294 279 minecraft:packed_ice
setblock 150 292 285 minecraft:basalt
setblock 151 292 277 minecraft:snow_block
fill 151 292 278 151 295 278 minecraft:packed_ice
fill 151 292 291 152 295 291 minecraft:basalt
fill 151 292 294 151 295 294 minecraft:basalt
fill 151 292 297 152 295 297 minecraft:basalt
setblock 151 292 306 minecraft:light[level=12]
setblock 151 292 313 minecraft:light[level=12]
setblock 152 292 276 minecraft:snow_block
fill 152 292 277 155 292 277 minecraft:packed_ice
fill 152 292 279 153 292 279 minecraft:packed_ice
fill 152 292 280 154 293 280 minecraft:white_concrete
fill 152 292 292 152 295 292 minecraft:basalt
setblock 152 292 294 minecraft:light[level=15]
fill 152 292 296 152 295 296 minecraft:basalt
setblock 152 292 310 minecraft:light[level=15]
setblock 152 292 316 minecraft:snow_block
fill 153 292 276 156 292 276 minecraft:packed_ice
fill 153 292 281 153 293 281 minecraft:white_concrete
setblock 153 292 282 minecraft:basalt
setblock 153 292 289 minecraft:magma_block
fill 153 292 299 153 295 299 minecraft:basalt
setblock 153 292 306 minecraft:basalt
fill 153 292 316 153 293 316 minecraft:packed_ice
setblock 154 292 278 minecraft:packed_ice
fill 154 292 287 154 295 288 minecraft:basalt
fill 154 292 300 154 295 300 minecraft:basalt
fill 154 292 311 154 296 311 minecraft:packed_ice
setblock 155 292 278 minecraft:snow_block
fill 155 292 287 155 295 287 minecraft:basalt
fill 155 292 301 155 295 301 minecraft:basalt
setblock 156 292 277 minecraft:snow_block
fill 156 292 278 159 292 278 minecraft:packed_ice
setblock 157 292 276 minecraft:snow_block
fill 157 292 277 160 292 277 minecraft:packed_ice
fill 157 292 286 158 292 286 minecraft:basalt
fill 157 292 302 158 295 302 minecraft:basalt
setblock 157 292 316 minecraft:snow_block
fill 158 292 276 161 292 276 minecraft:packed_ice
fill 158 292 281 158 293 281 minecraft:basalt
setblock 158 292 292 minecraft:light[level=12]
setblock 158 292 299 minecraft:light[level=12]
fill 158 292 307 161 292 307 minecraft:basalt
setblock 158 292 313 minecraft:light[level=12]
fill 158 292 316 161 292 316 minecraft:packed_ice
fill 159 292 280 161 292 280 minecraft:basalt
setblock 159 292 308 minecraft:magma_block
setblock 160 292 278 minecraft:snow_block
fill 160 292 285 160 295 285 minecraft:basalt
setblock 160 292 286 minecraft:light[level=15]
setblock 160 292 302 minecraft:light[level=15]
fill 160 292 303 160 295 303 minecraft:basalt
fill 160 292 308 161 292 308 minecraft:basalt
setblock 160 292 310 minecraft:light[level=15]
setblock 161 292 277 minecraft:snow_block
fill 161 292 278 164 292 278 minecraft:packed_ice
setblock 162 292 276 minecraft:snow_block
fill 162 292 277 165 292 277 minecraft:packed_ice
setblock 162 292 286 minecraft:magma_block
fill 162 292 302 163 295 302 minecraft:basalt
setblock 162 292 307 minecraft:magma_block
setblock 162 292 316 minecraft:snow_block
fill 163 292 276 166 292 276 minecraft:packed_ice
fill 163 292 286 163 295 286 minecraft:basalt
fill 163 292 304 169 292 304 minecraft:basalt
fill 163 292 316 166 292 316 minecraft:packed_ice
fill 164 292 315 167 292 315 minecraft:packed_ice
setblock 165 292 278 minecraft:snow_block
fill 165 292 279 168 292 279 minecraft:packed_ice
setblock 165 292 281 minecraft:basalt
fill 165 292 287 165 294 287 minecraft:basalt
setblock 165 292 292 minecraft:light[level=12]
setblock 165 292 299 minecraft:light[level=12]
fill 165 292 301 166 295 301 minecraft:basalt
setblock 165 292 313 minecraft:light[level=12]
setblock 166 292 277 minecraft:snow_block
fill 166 292 278 166 295 278 minecraft:packed_ice
fill 166 292 288 166 295 288 minecraft:basalt
fill 166 292 300 166 295 300 minecraft:basalt
setblock 167 292 276 minecraft:snow_block
fill 167 292 277 167 295 277 minecraft:packed_ice
setblock 167 292 282 minecraft:basalt
fill 167 292 289 168 294 289 minecraft:basalt
fill 167 292 299 167 295 299 minecraft:basalt
setblock 167 292 306 minecraft:basalt
fill 167 292 314 168 292 314 minecraft:packed_ice
setblock 167 292 316 minecraft:snow_block
fill 168 292 276 168 295 276 minecraft:packed_ice
setblock 168 292 290 minecraft:magma_block
fill 168 292 291 168 294 292 minecraft:basalt
setblock 168 292 294 minecraft:light[level=15]
setblock 168 292 296 minecraft:magma_block
fill 168 292 297 169 295 297 minecraft:basalt
setblock 168 292 305 minecraft:magma_block
setblock 168 292 310 minecraft:light[level=15]
setblock 168 292 315 minecraft:snow_block
fill 168 292 316 171 292 316 minecraft:packed_ice
setblock 169 292 279 minecraft:snow_block
fill 169 292 291 169 295 291 minecraft:basalt
fill 169 292 294 169 295 294 minecraft:basalt
setblock 169 292 314 minecraft:snow_block
fill 169 292 315 172 292 315 minecraft:packed_ice
setblock 170 292 278 minecraft:snow_block
setblock 170 292 279 minecraft:packed_ice
fill 170 292 314 170 293 314 minecraft:packed_ice
setblock 171 292 277 minecraft:snow_block
fill 171 292 278 171 294 278 minecraft:packed_ice
setblock 171 292 286 minecraft:magma_block
setblock 172 292 276 minecraft:snow_block
fill 172 292 277 172 294 277 minecraft:packed_ice
setblock 172 292 285 minecraft:light[level=12]
setblock 172 292 287 minecraft:basalt
setblock 172 292 300 minecraft:basalt
setblock 172 292 306 minecraft:light[level=12]
setblock 172 292 313 minecraft:light[level=12]
setblock 172 292 316 minecraft:snow_block
fill 173 292 276 173 295 276 minecraft:packed_ice
setblock 173 292 278 minecraft:packed_ice
setblock 173 292 289 minecraft:basalt
setblock 173 292 291 minecraft:basalt
setblock 173 292 315 minecraft:snow_block
fill 173 292 316 173 295 316 minecraft:packed_ice
setblock 174 292 293 minecraft:basalt
setblock 174 292 294 minecraft:magma_block
setblock 174 292 295 minecraft:basalt
fill 174 292 315 174 293 315 minecraft:packed_ice
setblock 176 292 278 minecraft:light[level=15]
setblock 176 292 286 minecraft:light[level=15]
setblock 176 292 294 minecraft:light[level=15]
setblock 176 292 302 minecraft:light[level=15]
setblock 176 292 310 minecraft:light[level=15]
setblock 177 292 276 minecraft:snow_block
setblock 177 292 316 minecraft:snow_block
setblock 178 292 276 minecraft:packed_ice
fill 178 292 316 178 293 316 minecraft:packed_ice
setblock 179 292 278 minecraft:light[level=12]
setblock 179 292 285 minecraft:light[level=12]
setblock 179 292 292 minecraft:light[level=12]
setblock 179 292 299 minecraft:light[level=12]
setblock 179 292 306 minecraft:light[level=12]
setblock 179 292 313 minecraft:light[level=12]
setblock 181 292 275 minecraft:light_blue_concrete
setblock 181 292 296 minecraft:packed_ice
setblock 181 292 297 minecraft:snow_block
fill 181 292 298 181 295 298 minecraft:packed_ice
setblock 181 292 301 minecraft:packed_ice
setblock 181 292 302 minecraft:snow_block
fill 181 292 303 181 295 303 minecraft:packed_ice
setblock 182 292 276 minecraft:snow_block
fill 182 292 277 182 293 277 minecraft:packed_ice
setblock 182 292 280 minecraft:packed_ice
setblock 182 292 296 minecraft:snow_block
fill 182 292 297 182 295 297 minecraft:packed_ice
setblock 182 292 301 minecraft:snow_block
fill 182 292 302 182 295 302 minecraft:packed_ice
setblock 182 292 305 minecraft:packed_ice
setblock 182 292 306 minecraft:snow_block
fill 182 292 307 182 295 307 minecraft:packed_ice
setblock 182 292 316 minecraft:snow_block
fill 141 293 280 141 302 281 minecraft:snow_block
fill 141 293 314 141 308 314 minecraft:snow_block
fill 142 293 275 142 308 275 minecraft:snow_block
fill 142 293 276 142 295 276 minecraft:packed_ice
setblock 142 293 279 minecraft:packed_ice
setblock 142 293 280 minecraft:snow_block
fill 142 293 281 142 296 281 minecraft:packed_ice
setblock 142 293 284 minecraft:packed_ice
setblock 142 293 285 minecraft:snow_block
fill 142 293 286 142 293 289 minecraft:packed_ice
setblock 142 293 290 minecraft:snow_block
fill 142 293 291 142 293 294 minecraft:packed_ice
setblock 142 293 295 minecraft:snow_block
fill 142 293 296 142 296 296 minecraft:packed_ice
setblock 142 293 300 minecraft:snow_block
fill 142 293 301 142 296 301 minecraft:packed_ice
setblock 142 293 305 minecraft:snow_block
fill 142 293 306 142 295 307 minecraft:packed_ice
setblock 143 293 279 minecraft:snow_block
fill 143 293 280 144 295 280 minecraft:packed_ice
setblock 143 293 283 minecraft:packed_ice
setblock 143 293 284 minecraft:snow_block
fill 143 293 292 143 293 293 minecraft:packed_ice
setblock 143 293 294 minecraft:snow_block
fill 143 293 295 143 296 295 minecraft:packed_ice
setblock 143 293 298 minecraft:packed_ice
setblock 143 293 299 minecraft:snow_block
fill 143 293 300 143 296 300 minecraft:packed_ice
setblock 143 293 304 minecraft:snow_block
fill 143 293 305 143 296 305 minecraft:packed_ice
fill 144 293 281 144 294 281 minecraft:packed_ice
setblock 144 293 298 minecraft:snow_block
fill 144 293 299 144 296 299 minecraft:packed_ice
setblock 144 293 303 minecraft:snow_block
setblock 145 293 277 minecraft:snow_block
fill 145 293 278 145 295 278 minecraft:packed_ice
setblock 145 293 298 minecraft:packed_ice
setblock 145 293 316 minecraft:packed_ice
fill 145 293 317 145 307 317 minecraft:snow_block
setblock 146 293 276 minecraft:snow_block
fill 146 293 277 146 296 277 minecraft:packed_ice
setblock 146 293 316 minecraft:snow_block
fill 147 293 276 150 293 276 minecraft:packed_ice
setblock 147 293 279 minecraft:packed_ice
setblock 147 293 293 minecraft:basalt
fill 147 293 316 150 293 316 minecraft:packed_ice
setblock 148 293 279 minecraft:snow_block
setblock 149 293 278 minecraft:snow_block
fill 149 293 279 149 294 279 minecraft:packed_ice
fill 149 293 287 149 293 288 minecraft:basalt
setblock 149 293 300 minecraft:basalt
setblock 149 293 301 minecraft:magma_block
setblock 150 293 277 minecraft:snow_block
fill 150 293 278 150 296 278 minecraft:packed_ice
setblock 151 293 276 minecraft:snow_block
fill 151 293 277 154 293 277 minecraft:packed_ice
setblock 151 293 316 minecraft:snow_block
fill 152 293 276 155 293 276 minecraft:packed_ice
setblock 152 293 279 minecraft:packed_ice
fill 152 293 293 152 295 293 minecraft:basalt
setblock 152 293 294 minecraft:magma_block
fill 152 293 295 152 295 295 minecraft:basalt
setblock 152 293 316 minecraft:packed_ice
setblock 153 293 279 minecraft:white_concrete
fill 153 293 289 153 294 291 minecraft:basalt
fill 153 293 297 153 294 298 minecraft:basalt
setblock 154 293 278 minecraft:snow_block
fill 154 293 289 154 295 289 minecraft:basalt
fill 154 293 299 154 295 299 minecraft:basalt
setblock 155 293 277 minecraft:snow_block
fill 155 293 278 156 293 278 minecraft:packed_ice
setblock 155 293 282 minecraft:basalt
fill 155 293 288 155 295 288 minecraft:basalt
fill 155 293 300 155 295 300 minecraft:basalt
setblock 156 293 276 minecraft:snow_block
fill 156 293 277 159 293 277 minecraft:packed_ice
fill 156 293 287 157 294 287 minecraft:basalt
fill 156 293 301 157 295 301 minecraft:basalt
fill 157 293 276 160 293 276 minecraft:packed_ice
fill 157 293 286 157 295 286 minecraft:basalt
setblock 158 293 286 minecraft:magma_block
setblock 158 293 307 minecraft:magma_block
fill 159 293 286 162 294 286 minecraft:basalt
fill 159 293 302 161 295 302 minecraft:basalt
fill 159 293 307 162 293 307 minecraft:basalt
setblock 160 293 277 minecraft:snow_block
fill 160 293 278 163 293 278 minecraft:packed_ice
setblock 160 293 316 minecraft:packed_ice
setblock 161 293 276 minecraft:snow_block
fill 161 293 277 164 293 277 minecraft:packed_ice
setblock 161 293 316 minecraft:snow_block
fill 162 293 276 165 293 276 minecraft:packed_ice
fill 162 293 316 165 293 316 minecraft:packed_ice
fill 163 293 287 163 295 287 minecraft:basalt
fill 163 293 301 164 293 301 minecraft:basalt
fill 163 293 304 168 293 304 minecraft:basalt
fill 163 293 306 164 293 306 minecraft:basalt
setblock 164 293 278 minecraft:snow_block
setblock 164 293 282 minecraft:basalt
setblock 164 293 287 minecraft:magma_block
fill 164 293 315 166 293 315 minecraft:packed_ice
setblock 165 293 277 minecraft:snow_block
fill 165 293 278 165 293 279 minecraft:packed_ice
fill 165 293 288 165 295 288 minecraft:basalt
fill 165 293 300 165 295 300 minecraft:basalt
setblock 166 293 276 minecraft:snow_block
fill 166 293 277 166 296 277 minecraft:packed_ice
fill 166 293 279 167 293 279 minecraft:packed_ice
fill 166 293 289 166 295 289 minecraft:basalt
fill 166 293 299 166 295 299 minecraft:basalt
setblock 166 293 305 minecraft:basalt
setblock 166 293 316 minecraft:snow_block
fill 167 293 276 167 296 276 minecraft:packed_ice
setblock 167 293 283 minecraft:magma_block
fill 167 293 290 167 295 291 minecraft:basalt
fill 167 293 297 167 295 297 minecraft:basalt
setblock 167 293 298 minecraft:magma_block
setblock 167 293 315 minecraft:snow_block
fill 167 293 316 170 293 316 minecraft:packed_ice
setblock 168 293 279 minecraft:snow_block
fill 168 293 290 168 295 290 minecraft:basalt
fill 168 293 293 168 294 296 minecraft:basalt
setblock 168 293 314 minecraft:snow_block
fill 168 293 315 171 293 315 minecraft:packed_ice
setblock 169 293 278 minecraft:snow_block
setblock 169 293 279 minecraft:packed_ice
setblock 169 293 285 minecraft:basalt
setblock 169 293 303 minecraft:basalt
setblock 169 293 314 minecraft:packed_ice
setblock 170 293 277 minecraft:snow_block
fill 170 293 278 170 294 278 minecraft:packed_ice
setblock 171 293 276 minecraft:snow_block
fill 171 293 277 171 295 277 minecraft:packed_ice
setblock 171 293 316 minecraft:snow_block
fill 172 293 276 172 296 276 minecraft:packed_ice
setblock 172 293 290 minecraft:basalt
setblock 172 293 299 minecraft:basalt
setblock 172 293 315 minecraft:snow_block
fill 172 293 316 172 296 316 minecraft:packed_ice
setblock 173 293 292 minecraft:basalt
setblock 173 293 293 minecraft:magma_block
fill 173 293 294 173 293 295 minecraft:basalt
setblock 173 293 296 minecraft:magma_block
setblock 173 293 315 minecraft:packed_ice
setblock 176 293 276 minecraft:snow_block
setblock 176 293 316 minecraft:snow_block
setblock 177 293 276 minecraft:packed_ice
setblock 177 293 316 minecraft:packed_ice
setblock 177 293 317 minecraft:white_concrete
fill 181 293 275 181 308 275 minecraft:snow_block
fill 181 293 297 181 294 297 minecraft:packed_ice
setblock 181 293 301 minecraft:snow_block
fill 181 293 302 181 296 302 minecraft:packed_ice
setblock 181 293 306 minecraft:snow_block
setblock 182 293 276 minecraft:packed_ice
setblock 182 293 280 minecraft:snow_block
fill 182 293 281 182 296 281 minecraft:packed_ice
setblock 182 293 295 minecraft:snow_block
fill 182 293 296 182 296 296 minecraft:packed_ice
setblock 182 293 300 minecraft:snow_block
fill 182 293 301 182 296 301 minecraft:packed_ice
setblock 182 293 305 minecraft:snow_block
fill 182 293 306 182 296 306 minecraft:packed_ice
setblock 142 294 278 minecraft:packed_ice
setblock 142 294 279 minecraft:snow_block
fill 142 294 280 142 297 280 minecraft:packed_ice
setblock 142 294 284 minecraft:snow_block
fill 142 294 285 142 294 288 minecraft:packed_ice
setblock 142 294 289 minecraft:snow_block
fill 142 294 290 142 294 293 minecraft:packed_ice
setblock 142 294 294 minecraft:snow_block
fill 142 294 295 142 297 295 minecraft:packed_ice
setblock 142 294 299 minecraft:snow_block
fill 142 294 300 142 297 300 minecraft:packed_ice
setblock 142 294 304 minecraft:snow_block
fill 142 294 305 142 297 305 minecraft:packed_ice
setblock 143 294 278 minecraft:snow_block
fill 143 294 279 143 297 279 minecraft:packed_ice
setblock 143 294 283 minecraft:snow_block
fill 143 294 284 143 295 286 minecraft:packed_ice
setblock 143 294 293 minecraft:snow_block
fill 143 294 294 143 295 294 minecraft:packed_ice
setblock 143 294 298 minecraft:snow_block
fill 143 294 299 143 297 299 minecraft:packed_ice
setblock 143 294 303 minecraft:snow_block
fill 143 294 304 143 297 304 minecraft:packed_ice
setblock 144 294 277 minecraft:snow_block
setblock 144 294 282 minecraft:snow_block
fill 144 294 283 144 297 283 minecraft:packed_ice
setblock 144 294 297 minecraft:snow_block
fill 144 294 298 144 295 298 minecraft:packed_ice
setblock 144 294 302 minecraft:snow_block
fill 144 294 303 144 296 303 minecraft:packed_ice
setblock 145 294 276 minecraft:snow_block
fill 145 294 277 145 297 277 minecraft:packed_ice
fill 146 294 276 149 294 276 minecraft:packed_ice
fill 146 294 316 149 294 316 minecraft:packed_ice
setblock 147 294 279 minecraft:snow_block
setblock 148 294 278 minecraft:snow_block
setblock 148 294 279 minecraft:packed_ice
fill 148 294 292 148 294 293 minecraft:basalt
setblock 148 294 294 minecraft:magma_block
fill 148 294 295 148 294 296 minecraft:basalt
setblock 149 294 277 minecraft:snow_block
fill 149 294 278 149 296 278 minecraft:packed_ice
setblock 150 294 276 minecraft:snow_block
fill 150 294 277 153 294 277 minecraft:packed_ice
setblock 150 294 316 minecraft:snow_block
fill 151 294 276 154 294 276 minecraft:packed_ice
setblock 151 294 302 minecraft:magma_block
setblock 151 294 316 minecraft:packed_ice
fill 152 294 294 153 294 294 minecraft:basalt
setblock 153 294 278 minecraft:snow_block
fill 153 294 292 153 294 293 minecraft:basalt
fill 153 294 295 153 294 296 minecraft:basalt
fill 153 294 311 153 296 311 minecraft:packed_ice
setblock 154 294 277 minecraft:snow_block
setblock 154 294 278 minecraft:packed_ice
setblock 154 294 284 minecraft:basalt
fill 154 294 290 154 295 290 minecraft:basalt
setblock 154 294 298 minecraft:magma_block
setblock 154 294 304 minecraft:magma_block
fill 154 294 310 154 296 310 minecraft:packed_ice
fill 154 294 312 154 296 312 minecraft:packed_ice
setblock 155 294 276 minecraft:snow_block
fill 155 294 277 158 294 277 minecraft:packed_ice
setblock 155 294 289 minecraft:basalt
setblock 155 294 299 minecraft:basalt
setblock 155 294 305 minecraft:basalt
fill 155 294 311 155 296 311 minecraft:packed_ice
fill 156 294 276 159 294 276 minecraft:packed_ice
fill 156 294 288 156 295 288 minecraft:basalt
fill 156 294 300 156 295 300 minecraft:basalt
fill 158 294 286 158 295 287 minecraft:basalt
fill 158 294 301 162 294 301 minecraft:basalt
setblock 159 294 277 minecraft:snow_block
setblock 159 294 287 minecraft:basalt
setblock 160 294 276 minecraft:snow_block
fill 160 294 277 163 294 277 minecraft:packed_ice
fill 160 294 287 160 295 287 minecraft:magma_block
setblock 161 294 275 minecraft:white_concrete
fill 161 294 276 164 294 276 minecraft:packed_ice
fill 161 294 278 162 294 278 minecraft:packed_ice
fill 161 294 287 162 294 287 minecraft:basalt
fill 161 294 316 164 294 316 minecraft:packed_ice
setblock 163 294 278 minecraft:snow_block
setblock 163 294 283 minecraft:magma_block
setblock 163 294 301 minecraft:magma_block
fill 163 294 304 167 294 304 minecraft:basalt
setblock 164 294 277 minecraft:snow_block
fill 164 294 278 165 296 278 minecraft:packed_ice
fill 164 294 287 164 295 288 minecraft:basalt
fill 164 294 300 164 295 301 minecraft:basalt
fill 164 294 315 165 294 315 minecraft:packed_ice
setblock 165 294 276 minecraft:snow_block
fill 165 294 277 165 297 277 minecraft:packed_ice
setblock 165 294 283 minecraft:basalt
setblock 165 294 289 minecraft:basalt
setblock 165 294 299 minecraft:basalt
setblock 165 294 316 minecraft:snow_block
fill 166 294 275 167 298 275 minecraft:snow_block
fill 166 294 276 166 297 276 minecraft:packed_ice
setblock 166 294 279 minecraft:packed_ice
fill 166 294 290 166 295 290 minecraft:basalt
fill 166 294 298 167 295 298 minecraft:basalt
setblock 166 294 315 minecraft:snow_block
fill 166 294 316 169 294 316 minecraft:packed_ice
setblock 167 294 279 minecraft:snow_block
fill 167 294 292 167 294 296 minecraft:basalt
fill 167 294 315 170 294 315 minecraft:packed_ice
setblock 168 294 275 minecraft:white_concrete
setblock 168 294 278 minecraft:snow_block
fill 169 294 275 170 308 275 minecraft:snow_block
setblock 169 294 277 minecraft:snow_block
fill 169 294 278 169 295 278 minecraft:packed_ice
setblock 169 294 302 minecraft:magma_block
setblock 170 294 276 minecraft:snow_block
fill 170 294 277 170 296 277 minecraft:packed_ice
setblock 170 294 288 minecraft:basalt
setblock 170 294 300 minecraft:basalt
setblock 170 294 316 minecraft:snow_block
fill 171 294 276 171 297 276 minecraft:packed_ice
setblock 171 294 289 minecraft:basalt
setblock 171 294 315 minecraft:snow_block
fill 171 294 316 171 297 316 minecraft:packed_ice
setblock 172 294 292 minecraft:magma_block
fill 172 294 293 172 294 294 minecraft:basalt
setblock 172 294 295 minecraft:magma_block
setblock 172 294 296 minecraft:basalt
setblock 172 294 315 minecraft:packed_ice
setblock 173 294 275 minecraft:light_blue_concrete
setblock 175 294 276 minecraft:snow_block
setblock 175 294 316 minecraft:snow_block
fill 177 294 317 177 301 317 minecraft:snow_block
setblock 181 294 300 minecraft:snow_block
fill 181 294 301 181 297 301 minecraft:packed_ice
setblock 181 294 304 minecraft:packed_ice
setblock 181 294 305 minecraft:snow_block
fill 181 294 306 181 297 306 minecraft:packed_ice
setblock 182 294 278 minecraft:packed_ice
setblock 182 294 279 minecraft:snow_block
fill 182 294 280 182 297 280 minecraft:packed_ice
fill 182 294 282 182 295 282 minecraft:packed_ice
setblock 182 294 294 minecraft:snow_block
fill 182 294 295 182 297 295 minecraft:packed_ice
setblock 182 294 299 minecraft:snow_block
fill 182 294 300 182 297 300 minecraft:packed_ice
setblock 182 294 304 minecraft:snow_block
fill 182 294 305 182 297 305 minecraft:packed_ice
setblock 182 294 309 minecraft:snow_block
setblock 183 294 279 minecraft:light_blue_concrete
fill 183 294 280 183 302 280 minecraft:snow_block
setblock 141 295 277 minecraft:light_blue_concrete
setblock 142 295 278 minecraft:snow_block
fill 142 295 279 142 298 279 minecraft:packed_ice
schedule function dropper:buildpart/63_11 1t
