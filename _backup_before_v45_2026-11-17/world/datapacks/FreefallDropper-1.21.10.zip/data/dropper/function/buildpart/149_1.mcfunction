setblock 262 99 615 minecraft:light[level=14]
setblock 262 99 623 minecraft:light[level=14]
setblock 262 99 631 minecraft:light[level=14]
setblock 262 99 639 minecraft:light[level=14]
fill 263 99 628 264 100 629 minecraft:white_concrete
fill 264 99 627 264 100 627 minecraft:white_concrete
setblock 270 99 607 minecraft:light[level=14]
setblock 270 99 615 minecraft:light[level=14]
setblock 270 99 623 minecraft:light[level=14]
setblock 270 99 631 minecraft:light[level=14]
setblock 270 99 639 minecraft:light[level=14]
setblock 276 99 644 minecraft:gray_concrete
fill 235 102 609 235 107 609 minecraft:sea_lantern
fill 235 102 617 235 107 617 minecraft:sea_lantern
fill 235 102 625 235 107 625 minecraft:sea_lantern
fill 235 102 633 235 107 633 minecraft:sea_lantern
fill 235 102 641 235 107 641 minecraft:sea_lantern
fill 238 102 646 238 107 646 minecraft:sea_lantern
fill 242 102 604 242 107 604 minecraft:sea_lantern
fill 246 102 646 246 107 646 minecraft:sea_lantern
fill 250 102 604 250 107 604 minecraft:sea_lantern
fill 254 102 646 254 107 646 minecraft:sea_lantern
fill 258 102 604 258 107 604 minecraft:sea_lantern
fill 262 102 646 262 107 646 minecraft:sea_lantern
fill 266 102 604 266 107 604 minecraft:sea_lantern
fill 270 102 646 270 107 646 minecraft:sea_lantern
fill 274 102 604 274 107 604 minecraft:sea_lantern
fill 277 102 609 277 107 609 minecraft:sea_lantern
fill 277 102 617 277 107 617 minecraft:sea_lantern
fill 277 102 625 277 107 625 minecraft:sea_lantern
fill 277 102 633 277 107 633 minecraft:sea_lantern
fill 277 102 641 277 107 641 minecraft:sea_lantern
fill 269 105 641 269 105 642 minecraft:black_concrete
setblock 270 105 640 minecraft:black_concrete
setblock 270 105 643 minecraft:black_concrete
fill 271 105 639 272 105 639 minecraft:black_concrete
setblock 271 105 644 minecraft:black_concrete
setblock 273 105 640 minecraft:black_concrete
setblock 273 105 643 minecraft:black_concrete
setblock 238 107 607 minecraft:light[level=14]
setblock 238 107 615 minecraft:light[level=14]
setblock 238 107 623 minecraft:light[level=14]
setblock 238 107 631 minecraft:light[level=14]
setblock 238 107 639 minecraft:light[level=14]
setblock 246 107 607 minecraft:light[level=14]
setblock 246 107 615 minecraft:light[level=14]
setblock 246 107 623 minecraft:light[level=14]
setblock 246 107 631 minecraft:light[level=14]
setblock 246 107 639 minecraft:light[level=14]
setblock 254 107 607 minecraft:light[level=14]
setblock 254 107 615 minecraft:light[level=14]
setblock 254 107 631 minecraft:light[level=14]
setblock 254 107 639 minecraft:light[level=14]
setblock 262 107 607 minecraft:light[level=14]
setblock 262 107 615 minecraft:light[level=14]
setblock 262 107 623 minecraft:light[level=14]
setblock 262 107 631 minecraft:light[level=14]
setblock 262 107 639 minecraft:light[level=14]
setblock 270 107 607 minecraft:light[level=14]
setblock 270 107 615 minecraft:light[level=14]
setblock 270 107 623 minecraft:light[level=14]
setblock 270 107 631 minecraft:light[level=14]
setblock 270 107 639 minecraft:light[level=14]
fill 235 108 609 235 115 609 minecraft:gray_concrete
fill 235 108 617 235 115 617 minecraft:gray_concrete
fill 235 108 625 235 115 625 minecraft:gray_concrete
fill 235 108 633 235 115 633 minecraft:gray_concrete
fill 235 108 641 235 115 641 minecraft:gray_concrete
fill 238 108 646 238 115 646 minecraft:gray_concrete
fill 242 108 604 242 115 604 minecraft:gray_concrete
fill 246 108 646 246 115 646 minecraft:gray_concrete
fill 250 108 604 250 115 604 minecraft:gray_concrete
fill 254 108 646 254 115 646 minecraft:gray_concrete
fill 258 108 604 258 115 604 minecraft:gray_concrete
fill 262 108 646 262 115 646 minecraft:gray_concrete
fill 266 108 604 266 115 604 minecraft:gray_concrete
fill 270 108 646 270 115 646 minecraft:gray_concrete
fill 274 108 604 274 115 604 minecraft:gray_concrete
fill 277 108 609 277 115 609 minecraft:gray_concrete
fill 277 108 617 277 115 617 minecraft:gray_concrete
fill 277 108 625 277 115 625 minecraft:gray_concrete
fill 277 108 633 277 115 633 minecraft:gray_concrete
fill 277 108 641 277 115 641 minecraft:gray_concrete
fill 236 112 605 236 113 610 minecraft:gray_concrete
fill 236 112 613 237 112 618 minecraft:gray_concrete
fill 236 112 621 237 112 626 minecraft:gray_concrete
fill 236 112 629 237 112 634 minecraft:gray_concrete
fill 236 112 637 237 112 642 minecraft:gray_concrete
fill 236 112 645 241 113 645 minecraft:gray_concrete
fill 237 112 606 237 112 612 minecraft:gray_concrete
fill 237 112 619 237 112 620 minecraft:gray_concrete
fill 237 112 627 237 112 628 minecraft:gray_concrete
fill 237 112 635 237 112 636 minecraft:gray_concrete
fill 237 112 643 237 112 644 minecraft:gray_concrete
fill 238 112 606 275 112 606 minecraft:gray_concrete
fill 238 112 644 276 112 644 minecraft:gray_concrete
fill 239 112 605 244 113 605 minecraft:gray_concrete
fill 244 112 639 245 113 640 minecraft:white_concrete
fill 244 112 645 249 113 645 minecraft:gray_concrete
fill 246 112 639 246 113 639 minecraft:white_concrete
fill 247 112 605 252 113 605 minecraft:gray_concrete
fill 252 112 645 257 113 645 minecraft:gray_concrete
fill 255 112 605 260 113 605 minecraft:gray_concrete
fill 260 112 645 265 113 645 minecraft:gray_concrete
fill 263 112 605 268 113 605 minecraft:gray_concrete
fill 268 112 645 273 113 645 minecraft:gray_concrete
fill 271 112 605 276 113 605 minecraft:gray_concrete
fill 275 112 607 275 112 643 minecraft:gray_concrete
fill 276 112 608 276 113 613 minecraft:gray_concrete
fill 276 112 616 276 113 621 minecraft:gray_concrete
fill 276 112 624 276 113 629 minecraft:gray_concrete
fill 276 112 632 276 113 637 minecraft:gray_concrete
fill 276 112 640 276 113 643 minecraft:gray_concrete
fill 276 112 645 276 113 645 minecraft:gray_concrete
fill 236 113 613 236 113 618 minecraft:gray_concrete
fill 236 113 621 236 113 626 minecraft:gray_concrete
fill 236 113 629 236 113 634 minecraft:gray_concrete
fill 236 113 637 236 113 642 minecraft:gray_concrete
fill 269 113 641 269 113 642 minecraft:black_concrete
setblock 270 113 640 minecraft:black_concrete
setblock 270 113 643 minecraft:black_concrete
fill 271 113 639 272 113 639 minecraft:black_concrete
setblock 271 113 644 minecraft:black_concrete
setblock 273 113 640 minecraft:black_concrete
setblock 273 113 643 minecraft:black_concrete
setblock 276 113 644 minecraft:gray_concrete
setblock 238 115 607 minecraft:light[level=14]
setblock 238 115 615 minecraft:light[level=14]
setblock 238 115 623 minecraft:light[level=14]
setblock 238 115 631 minecraft:light[level=14]
setblock 238 115 639 minecraft:light[level=14]
setblock 246 115 607 minecraft:light[level=14]
setblock 246 115 615 minecraft:light[level=14]
setblock 246 115 623 minecraft:light[level=14]
setblock 246 115 631 minecraft:light[level=14]
setblock 246 115 639 minecraft:light[level=14]
setblock 254 115 607 minecraft:light[level=14]
setblock 254 115 615 minecraft:light[level=14]
setblock 254 115 631 minecraft:light[level=14]
setblock 254 115 639 minecraft:light[level=14]
setblock 262 115 607 minecraft:light[level=14]
setblock 262 115 615 minecraft:light[level=14]
setblock 262 115 623 minecraft:light[level=14]
setblock 262 115 631 minecraft:light[level=14]
setblock 262 115 639 minecraft:light[level=14]
setblock 270 115 607 minecraft:light[level=14]
setblock 270 115 615 minecraft:light[level=14]
setblock 270 115 623 minecraft:light[level=14]
setblock 270 115 631 minecraft:light[level=14]
setblock 270 115 639 minecraft:light[level=14]
fill 235 116 609 235 121 609 minecraft:sea_lantern
fill 235 116 617 235 121 617 minecraft:sea_lantern
fill 235 116 625 235 121 625 minecraft:sea_lantern
fill 235 116 633 235 121 633 minecraft:sea_lantern
fill 235 116 641 235 121 641 minecraft:sea_lantern
fill 238 116 646 238 121 646 minecraft:sea_lantern
fill 242 116 604 242 121 604 minecraft:sea_lantern
fill 246 116 646 246 121 646 minecraft:sea_lantern
fill 250 116 604 250 121 604 minecraft:sea_lantern
fill 254 116 646 254 121 646 minecraft:sea_lantern
fill 258 116 604 258 121 604 minecraft:sea_lantern
fill 262 116 646 262 121 646 minecraft:sea_lantern
fill 266 116 604 266 121 604 minecraft:sea_lantern
fill 270 116 646 270 121 646 minecraft:sea_lantern
fill 274 116 604 274 121 604 minecraft:sea_lantern
fill 277 116 609 277 121 609 minecraft:sea_lantern
fill 277 116 617 277 121 617 minecraft:sea_lantern
fill 277 116 625 277 121 625 minecraft:sea_lantern
fill 277 116 633 277 121 633 minecraft:sea_lantern
fill 277 116 641 277 121 641 minecraft:sea_lantern
fill 267 118 636 268 119 636 minecraft:gold_block
fill 239 119 619 241 120 619 minecraft:gold_block
fill 240 119 618 240 120 618 minecraft:gold_block
fill 240 119 620 240 120 620 minecraft:gold_block
fill 269 121 641 269 121 642 minecraft:black_concrete
setblock 270 121 640 minecraft:black_concrete
setblock 270 121 643 minecraft:black_concrete
fill 271 121 639 272 121 639 minecraft:black_concrete
setblock 271 121 644 minecraft:black_concrete
setblock 273 121 640 minecraft:black_concrete
setblock 273 121 643 minecraft:black_concrete
fill 235 122 609 235 129 609 minecraft:gray_concrete
fill 235 122 617 235 129 617 minecraft:gray_concrete
fill 235 122 625 235 129 625 minecraft:gray_concrete
fill 235 122 633 235 129 633 minecraft:gray_concrete
fill 235 122 641 235 129 641 minecraft:gray_concrete
fill 238 122 646 238 129 646 minecraft:gray_concrete
fill 242 122 604 242 129 604 minecraft:gray_concrete
fill 246 122 646 246 129 646 minecraft:gray_concrete
fill 250 122 604 250 129 604 minecraft:gray_concrete
fill 254 122 646 254 129 646 minecraft:gray_concrete
fill 258 122 604 258 129 604 minecraft:gray_concrete
fill 262 122 646 262 129 646 minecraft:gray_concrete
fill 266 122 604 266 129 604 minecraft:gray_concrete
fill 270 122 646 270 129 646 minecraft:gray_concrete
fill 274 122 604 274 129 604 minecraft:gray_concrete
fill 277 122 609 277 129 609 minecraft:gray_concrete
fill 277 122 617 277 129 617 minecraft:gray_concrete
fill 277 122 625 277 129 625 minecraft:gray_concrete
fill 277 122 633 277 129 633 minecraft:gray_concrete
fill 277 122 641 277 129 641 minecraft:gray_concrete
setblock 238 123 607 minecraft:light[level=14]
setblock 238 123 615 minecraft:light[level=14]
setblock 238 123 623 minecraft:light[level=14]
setblock 238 123 631 minecraft:light[level=14]
setblock 238 123 639 minecraft:light[level=14]
setblock 246 123 607 minecraft:light[level=14]
setblock 246 123 615 minecraft:light[level=14]
setblock 246 123 623 minecraft:light[level=14]
setblock 246 123 631 minecraft:light[level=14]
setblock 246 123 639 minecraft:light[level=14]
setblock 254 123 607 minecraft:light[level=14]
setblock 254 123 615 minecraft:light[level=14]
setblock 254 123 631 minecraft:light[level=14]
setblock 254 123 639 minecraft:light[level=14]
setblock 262 123 607 minecraft:light[level=14]
setblock 262 123 615 minecraft:light[level=14]
setblock 262 123 623 minecraft:light[level=14]
setblock 262 123 631 minecraft:light[level=14]
setblock 262 123 639 minecraft:light[level=14]
setblock 270 123 607 minecraft:light[level=14]
setblock 270 123 615 minecraft:light[level=14]
setblock 270 123 623 minecraft:light[level=14]
setblock 270 123 631 minecraft:light[level=14]
setblock 270 123 639 minecraft:light[level=14]
fill 257 124 613 258 125 613 minecraft:gold_block
fill 260 124 642 260 125 644 minecraft:iron_block
fill 264 124 635 265 125 635 minecraft:gold_block
fill 236 126 605 236 127 610 minecraft:gray_concrete
fill 236 126 613 237 126 618 minecraft:gray_concrete
fill 236 126 621 237 126 626 minecraft:gray_concrete
fill 236 126 629 237 126 634 minecraft:gray_concrete
fill 236 126 637 237 126 642 minecraft:gray_concrete
fill 236 126 645 241 127 645 minecraft:gray_concrete
fill 237 126 606 237 126 612 minecraft:gray_concrete
fill 237 126 619 237 126 620 minecraft:gray_concrete
fill 237 126 627 237 126 628 minecraft:gray_concrete
fill 237 126 635 237 126 636 minecraft:gray_concrete
fill 237 126 643 237 126 644 minecraft:gray_concrete
fill 238 126 606 275 126 606 minecraft:gray_concrete
fill 238 126 644 276 126 644 minecraft:gray_concrete
fill 239 126 605 244 127 605 minecraft:gray_concrete
fill 244 126 645 249 127 645 minecraft:gray_concrete
fill 247 126 605 252 127 605 minecraft:gray_concrete
fill 252 126 645 257 127 645 minecraft:gray_concrete
fill 255 126 605 260 127 605 minecraft:gray_concrete
fill 260 126 645 265 127 645 minecraft:gray_concrete
fill 263 126 605 268 127 605 minecraft:gray_concrete
fill 268 126 645 273 127 645 minecraft:gray_concrete
fill 271 126 605 276 127 605 minecraft:gray_concrete
fill 275 126 607 275 126 643 minecraft:gray_concrete
fill 276 126 608 276 127 613 minecraft:gray_concrete
fill 276 126 616 276 127 621 minecraft:gray_concrete
fill 276 126 624 276 127 629 minecraft:gray_concrete
fill 276 126 632 276 127 637 minecraft:gray_concrete
fill 276 126 640 276 127 643 minecraft:gray_concrete
fill 276 126 645 276 127 645 minecraft:gray_concrete
fill 236 127 613 236 127 618 minecraft:gray_concrete
fill 236 127 621 236 127 626 minecraft:gray_concrete
fill 236 127 629 236 127 634 minecraft:gray_concrete
fill 236 127 637 236 127 642 minecraft:gray_concrete
setblock 276 127 644 minecraft:gray_concrete
fill 236 129 634 238 130 634 minecraft:iron_block
fill 269 129 641 269 129 642 minecraft:black_concrete
setblock 270 129 640 minecraft:black_concrete
setblock 270 129 643 minecraft:black_concrete
fill 271 129 639 272 129 639 minecraft:black_concrete
setblock 271 129 644 minecraft:black_concrete
setblock 273 129 640 minecraft:black_concrete
setblock 273 129 643 minecraft:black_concrete
fill 235 130 609 235 135 609 minecraft:sea_lantern
fill 235 130 617 235 135 617 minecraft:sea_lantern
fill 235 130 625 235 135 625 minecraft:sea_lantern
fill 235 130 633 235 135 633 minecraft:sea_lantern
fill 235 130 641 235 135 641 minecraft:sea_lantern
fill 238 130 646 238 135 646 minecraft:sea_lantern
fill 242 130 604 242 135 604 minecraft:sea_lantern
fill 246 130 646 246 135 646 minecraft:sea_lantern
fill 250 130 604 250 135 604 minecraft:sea_lantern
fill 254 130 646 254 135 646 minecraft:sea_lantern
fill 258 130 604 258 135 604 minecraft:sea_lantern
fill 262 130 646 262 135 646 minecraft:sea_lantern
fill 266 130 604 266 135 604 minecraft:sea_lantern
fill 270 130 646 270 135 646 minecraft:sea_lantern
fill 274 130 604 274 135 604 minecraft:sea_lantern
fill 277 130 609 277 135 609 minecraft:sea_lantern
fill 277 130 617 277 135 617 minecraft:sea_lantern
fill 277 130 625 277 135 625 minecraft:sea_lantern
fill 277 130 633 277 135 633 minecraft:sea_lantern
fill 277 130 641 277 135 641 minecraft:sea_lantern
setblock 238 131 607 minecraft:light[level=14]
setblock 238 131 615 minecraft:light[level=14]
setblock 238 131 623 minecraft:light[level=14]
setblock 238 131 631 minecraft:light[level=14]
setblock 238 131 639 minecraft:light[level=14]
setblock 246 131 607 minecraft:light[level=14]
setblock 246 131 615 minecraft:light[level=14]
setblock 246 131 623 minecraft:light[level=14]
setblock 246 131 631 minecraft:light[level=14]
setblock 246 131 639 minecraft:light[level=14]
setblock 254 131 607 minecraft:light[level=14]
setblock 254 131 615 minecraft:light[level=14]
setblock 254 131 623 minecraft:light[level=14]
setblock 254 131 631 minecraft:light[level=14]
setblock 254 131 639 minecraft:light[level=14]
setblock 262 131 607 minecraft:light[level=14]
setblock 262 131 615 minecraft:light[level=14]
setblock 262 131 623 minecraft:light[level=14]
setblock 262 131 631 minecraft:light[level=14]
setblock 262 131 639 minecraft:light[level=14]
setblock 270 131 607 minecraft:light[level=14]
setblock 270 131 615 minecraft:light[level=14]
setblock 270 131 623 minecraft:light[level=14]
setblock 270 131 631 minecraft:light[level=14]
setblock 270 131 639 minecraft:light[level=14]
setblock 235 135 610 minecraft:light_gray_concrete
fill 235 135 611 235 138 611 minecraft:gray_concrete
fill 235 135 614 235 138 615 minecraft:gray_concrete
setblock 235 135 616 minecraft:light_gray_concrete
fill 235 135 618 235 138 618 minecraft:gray_concrete
setblock 235 135 619 minecraft:light_gray_concrete
fill 235 135 620 235 138 620 minecraft:gray_concrete
fill 235 135 621 235 136 621 minecraft:light_gray_concrete
fill 235 135 622 235 138 624 minecraft:gray_concrete
fill 235 135 626 235 138 626 minecraft:gray_concrete
fill 235 135 627 235 137 627 minecraft:light_gray_concrete
fill 235 135 634 235 139 634 minecraft:gray_concrete
setblock 235 135 635 minecraft:light_gray_concrete
fill 235 135 636 235 138 639 minecraft:gray_concrete
setblock 235 135 640 minecraft:light_gray_concrete
setblock 235 135 645 minecraft:light_gray_concrete
fill 235 135 646 235 138 646 minecraft:gray_concrete
setblock 237 135 646 minecraft:light_gray_concrete
setblock 239 135 604 minecraft:gray_concrete
fill 239 135 646 240 135 646 minecraft:gray_concrete
fill 240 135 604 240 136 604 minecraft:light_gray_concrete
fill 241 135 604 241 138 604 minecraft:gray_concrete
setblock 241 135 646 minecraft:light_gray_concrete
fill 243 135 646 244 135 646 minecraft:light_gray_concrete
fill 247 135 646 248 135 646 minecraft:gray_concrete
fill 249 135 646 249 136 646 minecraft:light_gray_concrete
fill 250 135 646 251 136 646 minecraft:gray_concrete
fill 251 135 604 251 138 604 minecraft:gray_concrete
setblock 252 135 604 minecraft:light_gray_concrete
fill 252 135 646 253 135 646 minecraft:light_gray_concrete
fill 253 135 604 253 138 604 minecraft:gray_concrete
fill 258 135 646 260 135 646 minecraft:gray_concrete
setblock 259 135 604 minecraft:light_gray_concrete
setblock 261 135 646 minecraft:light_gray_concrete
fill 263 135 646 263 136 646 minecraft:light_gray_concrete
fill 265 135 646 268 136 646 minecraft:gray_concrete
setblock 267 135 604 minecraft:light_gray_concrete
setblock 269 135 604 minecraft:light_gray_concrete
setblock 269 135 646 minecraft:light_gray_concrete
fill 270 135 604 272 138 604 minecraft:gray_concrete
setblock 273 135 604 minecraft:light_gray_concrete
fill 277 135 626 277 138 626 minecraft:gray_concrete
setblock 277 135 627 minecraft:light_gray_concrete
fill 277 135 628 277 136 630 minecraft:gray_concrete
fill 277 135 634 277 138 636 minecraft:gray_concrete
setblock 277 135 637 minecraft:light_gray_concrete
fill 277 135 638 277 138 640 minecraft:gray_concrete
setblock 235 136 606 minecraft:light_gray_concrete
fill 235 136 609 235 138 610 minecraft:gray_concrete
fill 235 136 616 235 138 617 minecraft:gray_concrete
fill 235 136 619 235 138 619 minecraft:gray_concrete
fill 235 136 625 235 138 625 minecraft:gray_concrete
setblock 235 136 628 minecraft:light_gray_concrete
fill 235 136 629 235 138 631 minecraft:gray_concrete
fill 235 136 633 235 138 633 minecraft:gray_concrete
fill 235 136 635 235 139 635 minecraft:gray_concrete
fill 235 136 640 235 138 641 minecraft:gray_concrete
fill 235 136 645 235 138 645 minecraft:gray_concrete
fill 237 136 646 239 138 646 minecraft:gray_concrete
setblock 239 136 604 minecraft:light_gray_concrete
setblock 240 136 646 minecraft:light_gray_concrete
fill 241 136 646 241 138 646 minecraft:gray_concrete
fill 242 136 604 242 138 604 minecraft:gray_concrete
setblock 243 136 604 minecraft:light_gray_concrete
fill 243 136 646 244 138 646 minecraft:gray_concrete
setblock 245 136 604 minecraft:light_gray_concrete
fill 246 136 604 248 136 604 minecraft:gray_concrete
fill 246 136 646 246 139 646 minecraft:gray_concrete
setblock 247 136 646 minecraft:light_gray_concrete
fill 248 136 646 248 139 646 minecraft:gray_concrete
fill 250 136 604 250 138 604 minecraft:gray_concrete
fill 252 136 604 252 138 604 minecraft:gray_concrete
fill 252 136 646 254 138 646 minecraft:gray_concrete
setblock 254 136 604 minecraft:light_gray_concrete
setblock 255 136 646 minecraft:light_gray_concrete
fill 258 136 604 259 138 604 minecraft:gray_concrete
fill 258 136 646 258 138 646 minecraft:gray_concrete
setblock 259 136 646 minecraft:light_gray_concrete
fill 260 136 646 262 136 646 minecraft:gray_concrete
fill 266 136 604 267 138 604 minecraft:gray_concrete
setblock 269 136 604 minecraft:gray_concrete
fill 269 136 646 270 138 646 minecraft:gray_concrete
fill 273 136 604 274 138 604 minecraft:gray_concrete
setblock 276 136 604 minecraft:light_gray_concrete
fill 277 136 609 277 138 610 minecraft:gray_concrete
setblock 277 136 611 minecraft:light_gray_concrete
fill 277 136 612 277 138 616 minecraft:gray_concrete
fill 277 136 617 277 137 617 minecraft:light_gray_concrete
fill 277 136 618 277 138 622 minecraft:gray_concrete
setblock 277 136 623 minecraft:light_gray_concrete
fill 277 136 624 277 138 624 minecraft:gray_concrete
setblock 277 136 625 minecraft:light_gray_concrete
fill 277 136 627 277 138 627 minecraft:gray_concrete
fill 277 136 633 277 138 633 minecraft:gray_concrete
fill 277 136 637 277 139 637 minecraft:gray_concrete
fill 277 136 641 277 138 641 minecraft:gray_concrete
setblock 277 136 645 minecraft:light_gray_concrete
fill 235 137 606 235 138 606 minecraft:gray_concrete
fill 235 137 621 235 138 621 minecraft:gray_concrete
fill 235 137 628 235 138 628 minecraft:gray_concrete
setblock 235 137 643 minecraft:light_gray_concrete
setblock 238 137 604 minecraft:light_gray_concrete
fill 239 137 604 240 138 604 minecraft:gray_concrete
fill 240 137 646 240 138 646 minecraft:gray_concrete
fill 243 137 604 243 139 604 minecraft:gray_concrete
fill 245 137 604 247 138 604 minecraft:gray_concrete
fill 247 137 646 247 138 646 minecraft:gray_concrete
setblock 248 137 604 minecraft:light_gray_concrete
fill 249 137 646 249 138 646 minecraft:gray_concrete
setblock 250 137 646 minecraft:light_gray_concrete
fill 251 137 646 251 138 646 minecraft:gray_concrete
fill 254 137 604 255 138 604 minecraft:gray_concrete
fill 255 137 646 255 138 646 minecraft:gray_concrete
setblock 256 137 604 minecraft:light_gray_concrete
fill 259 137 646 259 138 646 minecraft:gray_concrete
setblock 260 137 646 minecraft:light_gray_concrete
setblock 261 137 604 minecraft:light_gray_concrete
fill 261 137 646 263 138 646 minecraft:gray_concrete
fill 262 137 604 263 138 604 minecraft:gray_concrete
fill 265 137 646 267 138 646 minecraft:gray_concrete
setblock 268 137 646 minecraft:light_gray_concrete
setblock 269 137 604 minecraft:light_gray_concrete
fill 269 137 641 269 137 642 minecraft:black_concrete
setblock 270 137 640 minecraft:black_concrete
setblock 270 137 643 minecraft:black_concrete
fill 271 137 639 272 137 639 minecraft:black_concrete
setblock 271 137 644 minecraft:black_concrete
fill 271 137 646 273 138 646 minecraft:gray_concrete
setblock 273 137 640 minecraft:black_concrete
setblock 273 137 643 minecraft:black_concrete
setblock 274 137 646 minecraft:light_gray_concrete
fill 276 137 604 276 138 604 minecraft:gray_concrete
setblock 277 137 604 minecraft:light_gray_concrete
fill 277 137 611 277 138 611 minecraft:gray_concrete
fill 277 137 623 277 138 623 minecraft:gray_concrete
fill 277 137 625 277 138 625 minecraft:gray_concrete
fill 277 137 628 277 138 629 minecraft:gray_concrete
setblock 277 137 630 minecraft:light_gray_concrete
fill 277 137 645 277 138 645 minecraft:gray_concrete
fill 235 138 627 235 139 627 minecraft:gray_concrete
setblock 235 138 643 minecraft:gray_concrete
setblock 238 138 604 minecraft:gray_concrete
setblock 248 138 604 minecraft:gray_concrete
fill 250 138 646 250 139 646 minecraft:gray_concrete
setblock 256 138 604 minecraft:gray_concrete
setblock 260 138 646 minecraft:gray_concrete
setblock 261 138 604 minecraft:gray_concrete
setblock 268 138 646 minecraft:gray_concrete
setblock 269 138 604 minecraft:gray_concrete
setblock 274 138 646 minecraft:gray_concrete
setblock 277 138 604 minecraft:gray_concrete
setblock 277 138 617 minecraft:gray_concrete
setblock 277 138 630 minecraft:gray_concrete
fill 235 139 605 235 139 626 minecraft:light_gray_concrete
fill 235 139 628 235 140 631 minecraft:light_gray_concrete
fill 235 139 633 235 143 633 minecraft:light_gray_concrete
fill 235 139 636 235 139 646 minecraft:light_gray_concrete
fill 236 139 604 242 139 604 minecraft:light_gray_concrete
fill 236 139 646 245 139 646 minecraft:light_gray_concrete
setblock 238 139 607 minecraft:light[level=14]
setblock 238 139 615 minecraft:light[level=14]
setblock 238 139 623 minecraft:light[level=14]
setblock 238 139 631 minecraft:light[level=14]
setblock 238 139 639 minecraft:light[level=14]
fill 244 139 604 277 139 604 minecraft:light_gray_concrete
setblock 246 139 607 minecraft:light[level=14]
setblock 246 139 615 minecraft:light[level=14]
setblock 246 139 623 minecraft:light[level=14]
setblock 246 139 631 minecraft:light[level=14]
setblock 246 139 639 minecraft:light[level=14]
fill 247 139 646 247 223 646 minecraft:light_gray_concrete
fill 249 139 646 249 223 646 minecraft:light_gray_concrete
fill 251 139 646 252 223 646 minecraft:light_gray_concrete
setblock 253 139 646 minecraft:gray_concrete
setblock 254 139 607 minecraft:light[level=14]
setblock 254 139 615 minecraft:light[level=14]
setblock 254 139 623 minecraft:light[level=14]
setblock 254 139 631 minecraft:light[level=14]
setblock 254 139 639 minecraft:light[level=14]
fill 254 139 646 277 139 646 minecraft:light_gray_concrete
setblock 262 139 607 minecraft:light[level=14]
setblock 262 139 615 minecraft:light[level=14]
setblock 262 139 623 minecraft:light[level=14]
setblock 262 139 631 minecraft:light[level=14]
setblock 262 139 639 minecraft:light[level=14]
setblock 270 139 607 minecraft:light[level=14]
setblock 270 139 615 minecraft:light[level=14]
setblock 270 139 623 minecraft:light[level=14]
setblock 270 139 631 minecraft:light[level=14]
setblock 270 139 639 minecraft:light[level=14]
fill 277 139 605 277 223 605 minecraft:light_gray_concrete
setblock 277 139 606 minecraft:gray_concrete
fill 277 139 607 277 139 615 minecraft:light_gray_concrete
setblock 277 139 616 minecraft:gray_concrete
fill 277 139 617 277 143 618 minecraft:light_gray_concrete
fill 277 139 619 277 139 620 minecraft:gray_concrete
fill 277 139 621 277 139 636 minecraft:light_gray_concrete
fill 277 139 638 277 139 645 minecraft:light_gray_concrete
fill 235 140 604 235 221 608 minecraft:light_gray_concrete
fill 235 140 609 237 140 609 minecraft:gray_concrete
fill 235 140 610 235 220 612 minecraft:light_gray_concrete
fill 235 140 613 237 140 614 minecraft:gray_concrete
fill 235 140 615 235 143 618 minecraft:light_gray_concrete
setblock 235 140 619 minecraft:gray_concrete
fill 235 140 620 235 223 620 minecraft:light_gray_concrete
fill 235 140 621 237 140 621 minecraft:gray_concrete
fill 235 140 622 235 140 627 minecraft:light_gray_concrete
fill 235 140 632 235 223 632 minecraft:light_gray_concrete
fill 235 140 634 235 140 637 minecraft:light_gray_concrete
fill 235 140 638 237 140 638 minecraft:gray_concrete
fill 235 140 639 235 140 641 minecraft:light_gray_concrete
fill 235 140 642 237 140 642 minecraft:gray_concrete
fill 235 140 643 235 223 645 minecraft:light_gray_concrete
setblock 235 140 646 minecraft:gray_concrete
fill 236 140 604 238 220 604 minecraft:light_gray_concrete
fill 236 140 605 236 141 608 minecraft:gray_concrete
fill 236 140 610 237 140 610 minecraft:gray_concrete
fill 236 140 615 237 140 618 minecraft:gray_concrete
fill 236 140 622 237 140 626 minecraft:gray_concrete
fill 236 140 629 237 140 634 minecraft:gray_concrete
fill 236 140 637 237 140 637 minecraft:gray_concrete
fill 236 140 639 237 140 641 minecraft:gray_concrete
fill 236 140 645 241 141 645 minecraft:gray_concrete
fill 236 140 646 240 143 646 minecraft:light_gray_concrete
fill 237 140 606 237 140 608 minecraft:gray_concrete
fill 237 140 611 237 140 612 minecraft:gray_concrete
fill 237 140 619 237 140 620 minecraft:gray_concrete
fill 237 140 627 237 140 628 minecraft:gray_concrete
fill 237 140 635 237 140 636 minecraft:gray_concrete
fill 237 140 643 237 140 644 minecraft:gray_concrete
fill 238 140 606 275 140 606 minecraft:gray_concrete
fill 238 140 644 277 140 644 minecraft:gray_concrete
fill 239 140 604 239 141 605 minecraft:gray_concrete
fill 240 140 604 244 140 604 minecraft:light_gray_concrete
fill 240 140 605 244 141 605 minecraft:gray_concrete
setblock 241 140 646 minecraft:gray_concrete
fill 242 140 646 243 219 646 minecraft:light_gray_concrete
fill 244 140 645 244 140 646 minecraft:gray_concrete
setblock 245 140 604 minecraft:gray_concrete
fill 245 140 645 249 141 645 minecraft:gray_concrete
fill 245 140 646 246 143 646 minecraft:light_gray_concrete
fill 246 140 604 247 223 604 minecraft:light_gray_concrete
fill 247 140 605 252 141 605 minecraft:gray_concrete
setblock 248 140 604 minecraft:gray_concrete
fill 248 140 646 248 224 646 minecraft:light_gray_concrete
fill 249 140 604 258 140 604 minecraft:light_gray_concrete
fill 250 140 646 250 223 646 minecraft:light_gray_concrete
fill 252 140 645 257 141 645 minecraft:gray_concrete
fill 253 140 646 254 143 646 minecraft:light_gray_concrete
fill 255 140 605 260 141 605 minecraft:gray_concrete
setblock 255 140 646 minecraft:gray_concrete
fill 256 140 646 261 140 646 minecraft:light_gray_concrete
setblock 259 140 604 minecraft:gray_concrete
fill 260 140 604 266 140 604 minecraft:light_gray_concrete
fill 260 140 645 265 141 645 minecraft:gray_concrete
setblock 262 140 646 minecraft:gray_concrete
fill 263 140 605 268 141 605 minecraft:gray_concrete
fill 263 140 646 265 220 646 minecraft:light_gray_concrete
fill 266 140 646 266 141 646 minecraft:gray_concrete
setblock 267 140 604 minecraft:gray_concrete
fill 267 140 646 267 223 646 minecraft:light_gray_concrete
fill 268 140 604 277 143 604 minecraft:light_gray_concrete
fill 268 140 645 268 140 646 minecraft:gray_concrete
fill 269 140 645 273 141 645 minecraft:gray_concrete
fill 269 140 646 277 143 646 minecraft:light_gray_concrete
fill 271 140 605 276 141 605 minecraft:gray_concrete
fill 275 140 607 275 140 643 minecraft:gray_concrete
fill 276 140 608 276 141 613 minecraft:gray_concrete
fill 276 140 616 276 141 621 minecraft:gray_concrete
fill 276 140 624 276 141 629 minecraft:gray_concrete
fill 276 140 632 276 141 637 minecraft:gray_concrete
fill 276 140 640 276 141 643 minecraft:gray_concrete
fill 276 140 645 276 141 645 minecraft:gray_concrete
fill 277 140 606 277 143 613 minecraft:light_gray_concrete
fill 277 140 614 277 141 614 minecraft:gray_concrete
fill 277 140 615 277 223 616 minecraft:light_gray_concrete
fill 277 140 619 277 140 631 minecraft:light_gray_concrete
setblock 277 140 632 minecraft:gray_concrete
fill 277 140 633 277 140 642 minecraft:light_gray_concrete
setblock 277 140 643 minecraft:gray_concrete
fill 277 140 645 277 223 645 minecraft:light_gray_concrete
fill 235 141 609 235 143 609 minecraft:light_gray_concrete
fill 235 141 613 235 223 614 minecraft:light_gray_concrete
fill 235 141 619 235 223 619 minecraft:light_gray_concrete
fill 235 141 621 235 143 625 minecraft:light_gray_concrete
fill 235 141 626 236 141 626 minecraft:gray_concrete
fill 235 141 627 235 223 628 minecraft:light_gray_concrete
fill 235 141 629 236 141 630 minecraft:gray_concrete
fill 235 141 631 235 219 631 minecraft:light_gray_concrete
fill 235 141 634 236 141 634 minecraft:gray_concrete
fill 235 141 635 235 219 640 minecraft:light_gray_concrete
fill 235 141 641 236 141 641 minecraft:gray_concrete
fill 235 141 642 235 223 642 minecraft:light_gray_concrete
fill 235 141 646 235 220 646 minecraft:light_gray_concrete
fill 236 141 609 236 141 610 minecraft:gray_concrete
fill 236 141 613 236 141 618 minecraft:gray_concrete
fill 236 141 621 236 141 625 minecraft:gray_concrete
fill 236 141 631 236 141 633 minecraft:gray_concrete
fill 236 141 637 236 141 640 minecraft:gray_concrete
setblock 236 141 642 minecraft:gray_concrete
fill 240 141 604 240 220 604 minecraft:light_gray_concrete
setblock 241 141 604 minecraft:gray_concrete
fill 241 141 646 241 224 646 minecraft:light_gray_concrete
fill 242 141 604 245 143 604 minecraft:light_gray_concrete
setblock 244 141 645 minecraft:gray_concrete
fill 244 141 646 244 223 646 minecraft:light_gray_concrete
fill 248 141 604 255 143 604 minecraft:light_gray_concrete
fill 255 141 646 255 223 646 minecraft:light_gray_concrete
fill 256 141 604 257 141 604 minecraft:gray_concrete
fill 256 141 646 257 141 646 minecraft:gray_concrete
fill 258 141 604 263 143 604 minecraft:light_gray_concrete
fill 258 141 646 262 143 646 minecraft:light_gray_concrete
setblock 264 141 604 minecraft:gray_concrete
fill 265 141 604 267 143 604 minecraft:light_gray_concrete
setblock 268 141 645 minecraft:gray_concrete
fill 268 141 646 268 220 646 minecraft:light_gray_concrete
setblock 276 141 644 minecraft:gray_concrete
fill 277 141 619 277 143 630 minecraft:light_gray_concrete
setblock 277 141 631 minecraft:gray_concrete
fill 277 141 632 277 143 639 minecraft:light_gray_concrete
setblock 277 141 640 minecraft:gray_concrete
fill 277 141 641 277 143 644 minecraft:light_gray_concrete
fill 235 142 626 235 219 626 minecraft:light_gray_concrete
fill 235 142 629 235 223 630 minecraft:light_gray_concrete
fill 235 142 634 235 223 634 minecraft:light_gray_concrete
fill 235 142 641 235 143 641 minecraft:light_gray_concrete
fill 239 142 604 239 219 604 minecraft:light_gray_concrete
fill 241 142 604 241 223 604 minecraft:light_gray_concrete
fill 256 142 604 257 221 604 minecraft:light_gray_concrete
fill 256 142 646 257 220 646 minecraft:light_gray_concrete
fill 264 142 604 264 223 604 minecraft:light_gray_concrete
fill 266 142 646 266 223 646 minecraft:light_gray_concrete
fill 277 142 614 277 225 614 minecraft:light_gray_concrete
fill 277 142 631 277 223 631 minecraft:light_gray_concrete
fill 277 142 640 277 223 640 minecraft:light_gray_concrete
fill 260 143 605 260 144 607 minecraft:iron_block
fill 235 144 609 235 149 609 minecraft:sea_lantern
fill 235 144 615 235 223 616 minecraft:light_gray_concrete
fill 235 144 617 235 149 617 minecraft:sea_lantern
fill 235 144 618 235 221 618 minecraft:light_gray_concrete
fill 235 144 621 235 219 624 minecraft:light_gray_concrete
fill 235 144 625 235 149 625 minecraft:sea_lantern
fill 235 144 633 235 149 633 minecraft:sea_lantern
fill 235 144 641 235 149 641 minecraft:sea_lantern
fill 236 144 646 237 223 646 minecraft:light_gray_concrete
fill 238 144 646 238 149 646 minecraft:sea_lantern
fill 239 144 646 240 223 646 minecraft:light_gray_concrete
fill 242 144 604 242 149 604 minecraft:sea_lantern
fill 243 144 604 245 220 604 minecraft:light_gray_concrete
fill 243 144 605 243 145 607 minecraft:iron_block
fill 245 144 646 245 221 646 minecraft:light_gray_concrete
fill 246 144 646 246 149 646 minecraft:sea_lantern
fill 248 144 604 249 223 604 minecraft:light_gray_concrete
fill 250 144 604 250 149 604 minecraft:sea_lantern
fill 251 144 604 255 223 604 minecraft:light_gray_concrete
fill 253 144 646 253 223 646 minecraft:light_gray_concrete
fill 254 144 646 254 149 646 minecraft:sea_lantern
fill 258 144 604 258 149 604 minecraft:sea_lantern
fill 258 144 646 261 220 646 minecraft:light_gray_concrete
fill 259 144 604 263 220 604 minecraft:light_gray_concrete
fill 262 144 646 262 149 646 minecraft:sea_lantern
fill 265 144 604 265 223 604 minecraft:light_gray_concrete
fill 266 144 604 266 149 604 minecraft:sea_lantern
fill 267 144 604 273 219 604 minecraft:light_gray_concrete
fill 269 144 646 269 223 646 minecraft:light_gray_concrete
fill 270 144 646 270 149 646 minecraft:sea_lantern
fill 271 144 646 277 219 646 minecraft:light_gray_concrete
fill 274 144 604 274 149 604 minecraft:sea_lantern
fill 275 144 604 277 223 604 minecraft:light_gray_concrete
fill 277 144 606 277 219 608 minecraft:light_gray_concrete
fill 277 144 609 277 149 609 minecraft:sea_lantern
fill 277 144 610 277 223 613 minecraft:light_gray_concrete
fill 277 144 617 277 149 617 minecraft:sea_lantern
fill 277 144 618 277 219 624 minecraft:light_gray_concrete
fill 277 144 625 277 149 625 minecraft:sea_lantern
fill 277 144 626 277 219 630 minecraft:light_gray_concrete
fill 277 144 632 277 223 632 minecraft:light_gray_concrete
fill 277 144 633 277 149 633 minecraft:sea_lantern
fill 277 144 634 277 219 639 minecraft:light_gray_concrete
fill 277 144 641 277 149 641 minecraft:sea_lantern
fill 277 144 642 277 223 644 minecraft:light_gray_concrete
fill 269 145 641 269 145 642 minecraft:black_concrete
setblock 270 145 640 minecraft:black_concrete
setblock 270 145 643 minecraft:black_concrete
fill 271 145 639 272 145 639 minecraft:black_concrete
setblock 271 145 644 minecraft:black_concrete
setblock 273 145 640 minecraft:black_concrete
setblock 273 145 643 minecraft:black_concrete
setblock 238 147 607 minecraft:light[level=14]
setblock 238 147 615 minecraft:light[level=14]
setblock 238 147 623 minecraft:light[level=14]
setblock 238 147 631 minecraft:light[level=14]
setblock 238 147 639 minecraft:light[level=14]
setblock 246 147 607 minecraft:light[level=14]
setblock 246 147 615 minecraft:light[level=14]
setblock 246 147 623 minecraft:light[level=14]
setblock 246 147 631 minecraft:light[level=14]
setblock 246 147 639 minecraft:light[level=14]
setblock 254 147 607 minecraft:light[level=14]
setblock 254 147 615 minecraft:light[level=14]
setblock 254 147 623 minecraft:light[level=14]
setblock 254 147 631 minecraft:light[level=14]
setblock 254 147 639 minecraft:light[level=14]
setblock 262 147 607 minecraft:light[level=14]
setblock 262 147 615 minecraft:light[level=14]
setblock 262 147 623 minecraft:light[level=14]
setblock 262 147 631 minecraft:light[level=14]
setblock 262 147 639 minecraft:light[level=14]
setblock 270 147 607 minecraft:light[level=14]
setblock 270 147 615 minecraft:light[level=14]
setblock 270 147 623 minecraft:light[level=14]
setblock 270 147 631 minecraft:light[level=14]
setblock 270 147 639 minecraft:light[level=14]
fill 235 150 609 235 157 609 minecraft:light_gray_concrete
fill 235 150 617 235 157 617 minecraft:light_gray_concrete
fill 235 150 625 235 157 625 minecraft:light_gray_concrete
fill 235 150 633 235 157 633 minecraft:light_gray_concrete
fill 235 150 641 235 157 641 minecraft:light_gray_concrete
fill 238 150 646 238 157 646 minecraft:light_gray_concrete
fill 242 150 604 242 157 604 minecraft:light_gray_concrete
fill 246 150 646 246 157 646 minecraft:light_gray_concrete
fill 250 150 604 250 157 604 minecraft:light_gray_concrete
fill 254 150 646 254 157 646 minecraft:light_gray_concrete
fill 258 150 604 258 157 604 minecraft:light_gray_concrete
fill 262 150 646 262 157 646 minecraft:light_gray_concrete
fill 266 150 604 266 157 604 minecraft:light_gray_concrete
fill 270 150 646 270 157 646 minecraft:light_gray_concrete
fill 274 150 604 274 157 604 minecraft:light_gray_concrete
fill 277 150 609 277 157 609 minecraft:light_gray_concrete
fill 277 150 617 277 157 617 minecraft:light_gray_concrete
fill 277 150 625 277 157 625 minecraft:light_gray_concrete
fill 277 150 633 277 157 633 minecraft:light_gray_concrete
fill 277 150 641 277 157 641 minecraft:light_gray_concrete
fill 269 153 641 269 153 642 minecraft:black_concrete
setblock 270 153 640 minecraft:black_concrete
setblock 270 153 643 minecraft:black_concrete
fill 271 153 639 272 153 639 minecraft:black_concrete
setblock 271 153 644 minecraft:black_concrete
setblock 273 153 640 minecraft:black_concrete
setblock 273 153 643 minecraft:black_concrete
fill 236 154 605 236 155 610 minecraft:gray_concrete
fill 236 154 613 237 154 618 minecraft:gray_concrete
fill 236 154 621 237 154 626 minecraft:gray_concrete
fill 236 154 629 237 154 634 minecraft:gray_concrete
fill 236 154 637 237 154 642 minecraft:gray_concrete
fill 236 154 645 241 155 645 minecraft:gray_concrete
fill 237 154 606 237 154 612 minecraft:gray_concrete
fill 237 154 619 237 154 620 minecraft:gray_concrete
fill 237 154 627 237 154 628 minecraft:gray_concrete
fill 237 154 635 237 154 636 minecraft:gray_concrete
fill 237 154 643 237 154 644 minecraft:gray_concrete
fill 238 154 606 275 154 606 minecraft:gray_concrete
fill 238 154 644 276 154 644 minecraft:gray_concrete
fill 239 154 605 244 155 605 minecraft:gray_concrete
fill 244 154 645 249 155 645 minecraft:gray_concrete
fill 247 154 605 252 155 605 minecraft:gray_concrete
fill 252 154 645 257 155 645 minecraft:gray_concrete
fill 255 154 605 260 155 605 minecraft:gray_concrete
fill 260 154 645 265 155 645 minecraft:gray_concrete
fill 263 154 605 268 155 605 minecraft:gray_concrete
fill 268 154 645 273 155 645 minecraft:gray_concrete
fill 271 154 605 276 155 605 minecraft:gray_concrete
fill 275 154 607 275 154 643 minecraft:gray_concrete
fill 276 154 608 276 155 613 minecraft:gray_concrete
fill 276 154 616 276 155 621 minecraft:gray_concrete
fill 276 154 624 276 155 629 minecraft:gray_concrete
fill 276 154 632 276 155 637 minecraft:gray_concrete
fill 276 154 640 276 155 643 minecraft:gray_concrete
fill 276 154 645 276 155 645 minecraft:gray_concrete
fill 236 155 613 236 155 618 minecraft:gray_concrete
fill 236 155 621 236 155 626 minecraft:gray_concrete
fill 236 155 629 236 155 634 minecraft:gray_concrete
fill 236 155 637 236 155 642 minecraft:gray_concrete
setblock 238 155 607 minecraft:light[level=14]
setblock 238 155 615 minecraft:light[level=14]
setblock 238 155 623 minecraft:light[level=14]
setblock 238 155 631 minecraft:light[level=14]
setblock 238 155 639 minecraft:light[level=14]
setblock 246 155 607 minecraft:light[level=14]
setblock 246 155 615 minecraft:light[level=14]
setblock 246 155 623 minecraft:light[level=14]
setblock 246 155 631 minecraft:light[level=14]
setblock 246 155 639 minecraft:light[level=14]
setblock 254 155 607 minecraft:light[level=14]
setblock 254 155 615 minecraft:light[level=14]
setblock 254 155 623 minecraft:light[level=14]
setblock 254 155 631 minecraft:light[level=14]
setblock 254 155 639 minecraft:light[level=14]
setblock 262 155 607 minecraft:light[level=14]
setblock 262 155 615 minecraft:light[level=14]
setblock 262 155 623 minecraft:light[level=14]
setblock 262 155 631 minecraft:light[level=14]
setblock 262 155 639 minecraft:light[level=14]
setblock 270 155 607 minecraft:light[level=14]
setblock 270 155 615 minecraft:light[level=14]
setblock 270 155 623 minecraft:light[level=14]
setblock 270 155 631 minecraft:light[level=14]
setblock 270 155 639 minecraft:light[level=14]
setblock 276 155 644 minecraft:gray_concrete
fill 235 158 609 235 163 609 minecraft:sea_lantern
fill 235 158 617 235 163 617 minecraft:sea_lantern
fill 235 158 625 235 163 625 minecraft:sea_lantern
fill 235 158 633 235 163 633 minecraft:sea_lantern
fill 235 158 641 235 163 641 minecraft:sea_lantern
fill 238 158 646 238 163 646 minecraft:sea_lantern
fill 242 158 604 242 163 604 minecraft:sea_lantern
fill 246 158 646 246 163 646 minecraft:sea_lantern
fill 250 158 604 250 163 604 minecraft:sea_lantern
fill 254 158 646 254 163 646 minecraft:sea_lantern
fill 258 158 604 258 163 604 minecraft:sea_lantern
fill 262 158 646 262 163 646 minecraft:sea_lantern
fill 266 158 604 266 163 604 minecraft:sea_lantern
fill 270 158 646 270 163 646 minecraft:sea_lantern
fill 274 158 604 274 163 604 minecraft:sea_lantern
fill 277 158 609 277 163 609 minecraft:sea_lantern
fill 277 158 617 277 163 617 minecraft:sea_lantern
fill 277 158 625 277 163 625 minecraft:sea_lantern
fill 277 158 633 277 163 633 minecraft:sea_lantern
fill 277 158 641 277 163 641 minecraft:sea_lantern
fill 269 161 641 269 161 642 minecraft:black_concrete
setblock 270 161 640 minecraft:black_concrete
setblock 270 161 643 minecraft:black_concrete
fill 271 161 639 272 161 639 minecraft:black_concrete
setblock 271 161 644 minecraft:black_concrete
setblock 273 161 640 minecraft:black_concrete
setblock 273 161 643 minecraft:black_concrete
setblock 238 163 607 minecraft:light[level=14]
setblock 238 163 615 minecraft:light[level=14]
setblock 238 163 623 minecraft:light[level=14]
setblock 238 163 631 minecraft:light[level=14]
setblock 238 163 639 minecraft:light[level=14]
setblock 246 163 607 minecraft:light[level=14]
setblock 246 163 615 minecraft:light[level=14]
setblock 246 163 623 minecraft:light[level=14]
setblock 246 163 631 minecraft:light[level=14]
setblock 246 163 639 minecraft:light[level=14]
setblock 254 163 607 minecraft:light[level=14]
setblock 254 163 615 minecraft:light[level=14]
setblock 254 163 623 minecraft:light[level=14]
setblock 254 163 631 minecraft:light[level=14]
setblock 254 163 639 minecraft:light[level=14]
setblock 262 163 607 minecraft:light[level=14]
setblock 262 163 615 minecraft:light[level=14]
setblock 262 163 623 minecraft:light[level=14]
setblock 262 163 631 minecraft:light[level=14]
setblock 262 163 639 minecraft:light[level=14]
setblock 270 163 607 minecraft:light[level=14]
setblock 270 163 615 minecraft:light[level=14]
setblock 270 163 623 minecraft:light[level=14]
setblock 270 163 631 minecraft:light[level=14]
setblock 270 163 639 minecraft:light[level=14]
fill 235 164 609 235 185 609 minecraft:light_gray_concrete
fill 235 164 617 235 185 617 minecraft:light_gray_concrete
fill 235 164 625 235 185 625 minecraft:light_gray_concrete
fill 235 164 633 235 185 633 minecraft:light_gray_concrete
fill 235 164 641 235 185 641 minecraft:light_gray_concrete
fill 238 164 646 238 185 646 minecraft:light_gray_concrete
fill 242 164 604 242 185 604 minecraft:light_gray_concrete
fill 246 164 646 246 185 646 minecraft:light_gray_concrete
fill 250 164 604 250 185 604 minecraft:light_gray_concrete
fill 254 164 646 254 185 646 minecraft:light_gray_concrete
fill 258 164 604 258 185 604 minecraft:light_gray_concrete
fill 262 164 646 262 185 646 minecraft:light_gray_concrete
fill 266 164 604 266 185 604 minecraft:light_gray_concrete
fill 270 164 646 270 185 646 minecraft:light_gray_concrete
fill 274 164 604 274 185 604 minecraft:light_gray_concrete
fill 277 164 609 277 185 609 minecraft:light_gray_concrete
fill 277 164 617 277 185 617 minecraft:light_gray_concrete
fill 277 164 625 277 185 625 minecraft:light_gray_concrete
fill 277 164 633 277 185 633 minecraft:light_gray_concrete
fill 277 164 641 277 185 641 minecraft:light_gray_concrete
fill 269 167 641 269 168 642 minecraft:gold_block
fill 270 167 640 270 168 640 minecraft:gold_block
fill 270 167 643 270 168 643 minecraft:gold_block
fill 273 167 640 273 168 640 minecraft:gold_block
fill 273 167 643 273 168 643 minecraft:gold_block
fill 236 168 605 236 168 610 minecraft:gray_concrete
fill 236 168 613 237 168 618 minecraft:gray_concrete
fill 236 168 621 237 168 626 minecraft:gray_concrete
fill 236 168 629 237 168 634 minecraft:gray_concrete
fill 236 168 637 237 168 642 minecraft:gray_concrete
fill 236 168 645 241 168 645 minecraft:gray_concrete
fill 237 168 606 237 168 612 minecraft:gray_concrete
fill 237 168 619 237 168 620 minecraft:gray_concrete
fill 237 168 627 237 168 628 minecraft:gray_concrete
fill 237 168 635 237 168 636 minecraft:gray_concrete
fill 237 168 643 237 168 644 minecraft:gray_concrete
fill 238 168 606 275 168 606 minecraft:gray_concrete
fill 238 168 644 276 168 644 minecraft:gray_concrete
fill 239 168 605 244 168 605 minecraft:gray_concrete
fill 244 168 645 249 168 645 minecraft:gray_concrete
fill 247 168 605 252 168 605 minecraft:gray_concrete
fill 252 168 645 257 168 645 minecraft:gray_concrete
fill 255 168 605 260 168 605 minecraft:gray_concrete
fill 260 168 645 265 168 645 minecraft:gray_concrete
fill 263 168 605 268 168 605 minecraft:gray_concrete
fill 268 168 645 273 168 645 minecraft:gray_concrete
fill 271 168 605 276 168 605 minecraft:gray_concrete
fill 275 168 607 275 168 643 minecraft:gray_concrete
fill 276 168 608 276 168 613 minecraft:gray_concrete
fill 276 168 616 276 168 621 minecraft:gray_concrete
fill 276 168 624 276 168 629 minecraft:gray_concrete
fill 276 168 632 276 168 637 minecraft:gray_concrete
fill 276 168 640 276 168 643 minecraft:gray_concrete
setblock 276 168 645 minecraft:gray_concrete
setblock 238 171 607 minecraft:light[level=14]
setblock 238 171 615 minecraft:light[level=14]
setblock 238 171 623 minecraft:light[level=14]
setblock 238 171 631 minecraft:light[level=14]
setblock 238 171 639 minecraft:light[level=14]
setblock 246 171 607 minecraft:light[level=14]
setblock 246 171 615 minecraft:light[level=14]
setblock 246 171 623 minecraft:light[level=14]
setblock 246 171 631 minecraft:light[level=14]
setblock 246 171 639 minecraft:light[level=14]
setblock 254 171 607 minecraft:light[level=14]
setblock 254 171 615 minecraft:light[level=14]
setblock 254 171 623 minecraft:light[level=14]
setblock 254 171 631 minecraft:light[level=14]
setblock 254 171 639 minecraft:light[level=14]
setblock 262 171 607 minecraft:light[level=14]
setblock 262 171 615 minecraft:light[level=14]
setblock 262 171 623 minecraft:light[level=14]
setblock 262 171 631 minecraft:light[level=14]
setblock 262 171 639 minecraft:light[level=14]
setblock 270 171 607 minecraft:light[level=14]
setblock 270 171 615 minecraft:light[level=14]
setblock 270 171 623 minecraft:light[level=14]
setblock 270 171 631 minecraft:light[level=14]
setblock 270 171 639 minecraft:light[level=14]
fill 247 173 618 249 173 620 minecraft:redstone_block
fill 247 173 624 249 173 626 minecraft:redstone_block
fill 252 173 616 254 173 618 minecraft:redstone_block
fill 254 173 625 256 173 627 minecraft:redstone_block
fill 237 174 620 246 174 630 minecraft:gray_concrete
fill 238 174 618 246 174 619 minecraft:gray_concrete
fill 238 174 631 274 174 632 minecraft:gray_concrete
fill 239 174 616 251 174 617 minecraft:gray_concrete
fill 239 174 633 273 174 634 minecraft:gray_concrete
fill 240 174 614 272 174 615 minecraft:gray_concrete
fill 240 174 635 272 175 636 minecraft:gray_concrete
fill 241 174 613 271 174 613 minecraft:gray_concrete
fill 241 174 637 271 175 637 minecraft:gray_concrete
fill 242 174 612 270 174 612 minecraft:gray_concrete
fill 242 174 638 270 175 638 minecraft:gray_concrete
fill 243 174 611 269 174 611 minecraft:gray_concrete
fill 243 174 639 269 175 639 minecraft:gray_concrete
fill 244 174 610 268 174 610 minecraft:gray_concrete
fill 244 174 640 268 175 640 minecraft:gray_concrete
fill 245 174 609 267 175 609 minecraft:gray_concrete
fill 245 174 641 267 175 641 minecraft:gray_concrete
fill 247 174 608 265 175 608 minecraft:gray_concrete
fill 247 174 621 250 174 623 minecraft:gray_concrete
fill 247 174 627 253 174 630 minecraft:gray_concrete
fill 247 174 642 265 175 642 minecraft:gray_concrete
fill 249 174 607 263 175 607 minecraft:gray_concrete
fill 249 174 643 263 175 643 minecraft:gray_concrete
fill 250 174 618 251 174 620 minecraft:gray_concrete
fill 250 174 624 251 174 626 minecraft:gray_concrete
fill 251 174 606 261 175 606 minecraft:gray_concrete
fill 251 174 644 261 175 644 minecraft:gray_concrete
fill 252 174 619 274 174 620 minecraft:gray_concrete
fill 252 174 624 253 174 624 minecraft:gold_block
fill 252 174 625 253 174 626 minecraft:gray_concrete
fill 254 174 621 275 174 621 minecraft:gray_concrete
fill 254 174 622 254 174 623 minecraft:gold_block
fill 254 174 624 275 174 624 minecraft:gray_concrete
fill 254 174 628 275 174 630 minecraft:gray_concrete
fill 255 174 616 273 174 618 minecraft:gray_concrete
fill 255 174 622 275 174 623 minecraft:gray_concrete
fill 257 174 625 275 174 627 minecraft:gray_concrete
fill 274 174 618 274 175 618 minecraft:gray_concrete
fill 275 174 620 275 175 620 minecraft:gray_concrete
fill 236 175 605 238 175 645 minecraft:gray_concrete
fill 239 175 605 239 175 621 minecraft:gray_concrete
fill 239 175 622 248 176 622 minecraft:iron_block
fill 239 175 623 239 175 645 minecraft:gray_concrete
fill 240 175 605 240 175 616 minecraft:gray_concrete
fill 240 175 617 264 176 617 minecraft:iron_block
fill 240 175 618 240 177 620 minecraft:gray_concrete
fill 240 175 621 240 176 621 minecraft:iron_block
fill 240 175 623 240 176 623 minecraft:iron_block
fill 240 175 624 240 179 626 minecraft:gray_concrete
fill 240 175 627 264 176 627 minecraft:iron_block
fill 240 175 628 240 176 634 minecraft:gray_concrete
fill 240 175 637 240 175 645 minecraft:gray_concrete
fill 241 175 605 243 175 615 minecraft:gray_concrete
fill 241 175 616 263 176 616 minecraft:iron_block
fill 241 175 618 263 176 618 minecraft:iron_block
fill 241 175 619 241 179 621 minecraft:gray_concrete
fill 241 175 623 241 180 625 minecraft:gray_concrete
fill 241 175 626 263 176 626 minecraft:iron_block
fill 241 175 628 263 176 628 minecraft:iron_block
fill 241 175 629 243 177 634 minecraft:gray_concrete
fill 241 175 638 241 175 645 minecraft:gray_concrete
fill 242 175 619 249 176 621 minecraft:iron_block
fill 242 175 623 249 176 625 minecraft:iron_block
fill 242 175 639 242 175 645 minecraft:gray_concrete
fill 243 175 640 243 175 645 minecraft:gray_concrete
fill 244 175 605 244 175 611 minecraft:gray_concrete
fill 244 175 612 245 176 613 minecraft:iron_block
fill 244 175 614 244 179 614 minecraft:gray_concrete
fill 244 175 615 260 176 615 minecraft:iron_block
fill 244 175 629 260 176 629 minecraft:iron_block
fill 244 175 630 244 182 630 minecraft:gray_concrete
fill 244 175 631 245 176 632 minecraft:iron_block
fill 244 175 633 248 180 634 minecraft:gray_concrete
fill 244 175 641 244 175 645 minecraft:gray_concrete
fill 245 175 605 246 175 608 minecraft:gray_concrete
fill 245 175 610 248 175 611 minecraft:gray_concrete
fill 245 175 614 259 176 614 minecraft:iron_block
fill 245 175 630 259 176 630 minecraft:iron_block
fill 245 175 642 246 175 645 minecraft:gray_concrete
fill 246 175 612 247 179 612 minecraft:gray_concrete
fill 246 175 613 260 176 613 minecraft:iron_block
fill 246 175 631 260 176 631 minecraft:iron_block
fill 246 175 632 247 183 632 minecraft:gray_concrete
fill 247 175 605 248 175 607 minecraft:gray_concrete
fill 247 175 643 248 175 645 minecraft:gray_concrete
fill 248 175 612 256 176 612 minecraft:iron_block
fill 248 175 632 256 176 632 minecraft:iron_block
fill 249 175 605 250 175 606 minecraft:gray_concrete
fill 249 175 610 250 176 611 minecraft:iron_block
fill 249 175 622 250 175 622 minecraft:waxed_copper_block
fill 249 175 633 250 176 634 minecraft:iron_block
fill 249 175 644 250 175 645 minecraft:gray_concrete
fill 250 175 619 251 176 619 minecraft:iron_block
fill 250 175 620 250 176 621 minecraft:waxed_copper_block
fill 250 175 623 250 176 624 minecraft:waxed_copper_block
fill 250 175 625 251 176 625 minecraft:iron_block
fill 251 175 605 276 175 605 minecraft:gray_concrete
fill 251 175 610 251 180 611 minecraft:gray_concrete
fill 251 175 620 254 175 620 minecraft:waxed_copper_block
fill 251 175 624 254 175 624 minecraft:waxed_copper_block
fill 251 175 633 251 183 634 minecraft:gray_concrete
fill 251 175 645 276 175 645 minecraft:gray_concrete
fill 252 175 610 253 180 610 minecraft:gray_concrete
fill 252 175 611 252 176 611 minecraft:iron_block
fill 252 175 619 252 177 619 minecraft:waxed_copper_block
fill 252 175 625 252 177 625 minecraft:waxed_copper_block
fill 252 175 633 252 176 633 minecraft:iron_block
fill 252 175 634 253 183 634 minecraft:gray_concrete
fill 253 175 611 253 181 611 minecraft:gray_concrete
fill 253 175 619 262 176 619 minecraft:iron_block
fill 253 175 625 262 176 625 minecraft:iron_block
fill 253 175 633 253 182 633 minecraft:gray_concrete
fill 254 175 610 255 176 611 minecraft:iron_block
fill 254 175 621 254 175 623 minecraft:waxed_copper_block
fill 254 175 633 255 176 634 minecraft:iron_block
fill 255 175 620 262 176 621 minecraft:iron_block
fill 255 175 622 255 177 622 minecraft:waxed_copper_block
fill 255 175 623 262 176 624 minecraft:iron_block
fill 256 175 610 276 175 611 minecraft:gray_concrete
fill 256 175 622 265 176 622 minecraft:iron_block
fill 256 175 633 276 175 634 minecraft:gray_concrete
fill 257 175 612 258 182 612 minecraft:gray_concrete
fill 257 175 632 258 180 632 minecraft:gray_concrete
fill 259 175 612 260 176 612 minecraft:iron_block
fill 259 175 632 260 176 632 minecraft:iron_block
fill 260 175 614 276 175 614 minecraft:gray_concrete
fill 260 175 630 276 175 630 minecraft:gray_concrete
fill 261 175 612 276 175 613 minecraft:gray_concrete
fill 261 175 615 276 175 615 minecraft:gray_concrete
fill 261 175 629 276 175 629 minecraft:gray_concrete
fill 261 175 631 276 175 632 minecraft:gray_concrete
fill 262 175 606 276 175 606 minecraft:gray_concrete
fill 262 175 644 276 175 644 minecraft:gray_concrete
fill 263 175 619 263 181 621 minecraft:gray_concrete
fill 263 175 623 263 180 625 minecraft:gray_concrete
fill 264 175 607 276 175 607 minecraft:gray_concrete
fill 264 175 616 276 175 616 minecraft:gray_concrete
fill 264 175 618 273 176 620 minecraft:gray_concrete
fill 264 175 621 264 176 621 minecraft:iron_block
fill 264 175 623 264 176 623 minecraft:iron_block
fill 264 175 624 276 175 626 minecraft:gray_concrete
fill 264 175 628 276 175 628 minecraft:gray_concrete
fill 264 175 643 276 175 643 minecraft:gray_concrete
fill 265 175 617 276 175 617 minecraft:gray_concrete
fill 265 175 621 276 175 621 minecraft:gray_concrete
fill 265 175 623 276 175 623 minecraft:gray_concrete
fill 265 175 627 276 175 627 minecraft:gray_concrete
fill 266 175 608 276 175 608 minecraft:gray_concrete
fill 266 175 622 276 175 622 minecraft:gray_concrete
fill 266 175 642 276 175 642 minecraft:gray_concrete
fill 268 175 609 276 175 609 minecraft:gray_concrete
fill 268 175 641 276 175 641 minecraft:gray_concrete
fill 269 175 640 276 175 640 minecraft:gray_concrete
fill 270 175 639 276 175 639 minecraft:gray_concrete
fill 271 175 638 276 175 638 minecraft:gray_concrete
fill 272 175 637 276 175 637 minecraft:gray_concrete
fill 273 175 635 276 175 636 minecraft:gray_concrete
fill 274 175 619 274 175 620 minecraft:gray_concrete
fill 275 175 618 276 175 619 minecraft:gray_concrete
setblock 276 175 620 minecraft:gray_concrete
fill 238 176 621 238 176 629 minecraft:gray_concrete
fill 239 176 618 239 176 621 minecraft:gray_concrete
fill 239 176 623 239 176 632 minecraft:gray_concrete
setblock 240 176 616 minecraft:gray_concrete
fill 241 176 615 243 176 615 minecraft:gray_concrete
fill 241 176 635 271 176 635 minecraft:gray_concrete
fill 242 176 613 243 176 614 minecraft:gray_concrete
fill 242 176 636 270 176 637 minecraft:gray_concrete
setblock 243 176 612 minecraft:gray_concrete
fill 243 176 638 269 176 638 minecraft:gray_concrete
fill 244 176 611 248 176 611 minecraft:gray_concrete
fill 244 176 639 268 176 639 minecraft:gray_concrete
fill 246 176 610 248 176 610 minecraft:gray_concrete
fill 246 176 640 266 176 640 minecraft:gray_concrete
fill 247 176 609 265 176 609 minecraft:gray_concrete
fill 247 176 641 265 176 641 minecraft:gray_concrete
fill 249 176 608 263 176 608 minecraft:gray_concrete
fill 249 176 622 249 177 622 minecraft:waxed_copper_block
fill 249 176 642 263 176 642 minecraft:gray_concrete
setblock 251 176 620 minecraft:waxed_copper_block
setblock 251 176 624 minecraft:waxed_copper_block
fill 252 176 607 260 176 607 minecraft:gray_concrete
fill 252 176 643 260 176 643 minecraft:gray_concrete
fill 253 176 620 254 176 620 minecraft:waxed_copper_block
fill 253 176 624 254 176 624 minecraft:waxed_copper_block
setblock 254 176 621 minecraft:waxed_copper_block
setblock 254 176 623 minecraft:waxed_copper_block
fill 256 176 610 266 176 611 minecraft:gray_concrete
fill 256 176 633 272 176 634 minecraft:gray_concrete
fill 260 176 614 270 177 614 minecraft:gray_concrete
fill 260 176 630 273 177 630 minecraft:gray_concrete
fill 261 176 612 269 176 613 minecraft:gray_concrete
fill 261 176 615 271 176 615 minecraft:gray_concrete
fill 261 176 629 274 176 629 minecraft:gray_concrete
fill 261 176 631 273 176 632 minecraft:gray_concrete
fill 264 176 616 272 176 616 minecraft:gray_concrete
fill 264 176 624 274 176 626 minecraft:gray_concrete
fill 264 176 628 274 176 628 minecraft:gray_concrete
fill 265 176 617 272 177 617 minecraft:gray_concrete
fill 265 176 621 274 176 621 minecraft:gray_concrete
fill 265 176 623 274 176 623 minecraft:gray_concrete
fill 265 176 627 274 176 627 minecraft:gray_concrete
fill 266 176 622 274 176 622 minecraft:gray_concrete
fill 267 176 611 268 176 611 minecraft:gray_concrete
setblock 270 176 613 minecraft:gray_concrete
fill 239 177 620 239 177 630 minecraft:gray_concrete
fill 240 177 617 246 177 617 minecraft:gray_concrete
fill 240 177 621 240 179 623 minecraft:gray_concrete
fill 240 177 627 240 177 633 minecraft:gray_concrete
fill 241 177 616 247 177 616 minecraft:gray_concrete
fill 241 177 618 245 179 618 minecraft:gray_concrete
fill 241 177 622 244 180 622 minecraft:gray_concrete
fill 241 177 626 245 180 628 minecraft:gray_concrete
fill 242 177 614 243 177 615 minecraft:gray_concrete
fill 242 177 619 244 180 621 minecraft:gray_concrete
fill 242 177 623 244 180 625 minecraft:gray_concrete
fill 242 177 635 270 177 636 minecraft:gray_concrete
fill 243 177 613 269 177 613 minecraft:gray_concrete
fill 243 177 637 269 177 637 minecraft:gray_concrete
fill 244 177 612 245 177 612 minecraft:gray_concrete
fill 244 177 615 249 180 615 minecraft:gray_concrete
fill 244 177 629 249 180 629 minecraft:gray_concrete
fill 244 177 631 245 181 632 minecraft:gray_concrete
fill 244 177 638 268 177 638 minecraft:gray_concrete
fill 245 177 611 250 177 611 minecraft:gray_concrete
fill 245 177 614 259 180 614 minecraft:gray_concrete
fill 245 177 619 245 180 619 minecraft:gray_concrete
fill 245 177 620 245 177 624 minecraft:waxed_oxidized_copper
fill 245 177 625 245 180 625 minecraft:gray_concrete
fill 245 177 630 259 179 630 minecraft:gray_concrete
fill 245 177 639 267 177 639 minecraft:gray_concrete
fill 246 177 618 246 177 619 minecraft:waxed_oxidized_copper
fill 246 177 620 248 178 624 minecraft:gray_concrete
fill 246 177 625 246 177 626 minecraft:waxed_oxidized_copper
fill 246 177 627 246 180 628 minecraft:gray_concrete
fill 246 177 631 272 178 631 minecraft:gray_concrete
fill 247 177 610 250 177 610 minecraft:gray_concrete
setblock 247 177 617 minecraft:waxed_oxidized_copper
fill 247 177 618 250 178 619 minecraft:gray_concrete
fill 247 177 625 249 177 626 minecraft:gray_concrete
setblock 247 177 627 minecraft:waxed_oxidized_copper
fill 247 177 628 247 182 628 minecraft:gray_concrete
fill 247 177 640 265 177 640 minecraft:gray_concrete
fill 248 177 609 264 177 609 minecraft:gray_concrete
fill 248 177 612 256 180 612 minecraft:gray_concrete
fill 248 177 616 249 177 616 minecraft:waxed_oxidized_copper
fill 248 177 617 256 179 617 minecraft:gray_concrete
fill 248 177 627 251 177 627 minecraft:gray_concrete
fill 248 177 628 249 177 628 minecraft:waxed_oxidized_copper
fill 248 177 632 256 180 632 minecraft:gray_concrete
fill 248 177 641 264 177 641 minecraft:gray_concrete
fill 249 177 620 249 178 620 minecraft:gray_concrete
setblock 249 177 621 minecraft:gold_block
fill 249 177 623 249 177 624 minecraft:gold_block
fill 249 177 633 250 183 634 minecraft:gray_concrete
fill 250 177 615 254 177 615 minecraft:waxed_oxidized_copper
fill 250 177 616 254 181 616 minecraft:gray_concrete
setblock 250 177 620 minecraft:waxed_copper_block
setblock 250 177 624 minecraft:waxed_copper_block
setblock 250 177 625 minecraft:gold_block
setblock 250 177 626 minecraft:gray_concrete
fill 250 177 628 254 177 628 minecraft:gray_concrete
fill 250 177 629 254 177 629 minecraft:waxed_oxidized_copper
fill 251 177 608 261 177 608 minecraft:gray_concrete
fill 251 177 618 257 177 618 minecraft:gray_concrete
setblock 251 177 619 minecraft:gold_block
setblock 251 177 626 minecraft:gold_block
fill 251 177 642 261 177 642 minecraft:gray_concrete
fill 252 177 611 252 181 611 minecraft:gray_concrete
fill 252 177 627 255 177 627 minecraft:gold_block
fill 252 177 633 252 182 633 minecraft:gray_concrete
fill 253 177 619 255 177 619 minecraft:gold_block
fill 254 177 610 265 177 611 minecraft:gray_concrete
setblock 254 177 620 minecraft:waxed_copper_block
setblock 254 177 624 minecraft:waxed_copper_block
fill 254 177 633 271 177 634 minecraft:gray_concrete
fill 255 177 615 270 178 615 minecraft:gray_concrete
fill 255 177 616 256 177 616 minecraft:waxed_oxidized_copper
fill 255 177 628 256 177 628 minecraft:waxed_oxidized_copper
fill 255 177 629 273 177 629 minecraft:gray_concrete
fill 256 177 619 257 177 619 minecraft:gray_concrete
setblock 256 177 620 minecraft:gold_block
fill 256 177 626 257 177 626 minecraft:gold_block
setblock 256 177 627 minecraft:gray_concrete
fill 257 177 616 271 177 616 minecraft:gray_concrete
setblock 257 177 617 minecraft:waxed_oxidized_copper
fill 257 177 620 258 177 620 minecraft:gray_concrete
fill 257 177 621 257 177 625 minecraft:gold_block
setblock 257 177 627 minecraft:waxed_oxidized_copper
fill 257 177 628 273 178 628 minecraft:gray_concrete
fill 258 177 617 264 180 617 minecraft:gray_concrete
fill 258 177 618 258 177 619 minecraft:waxed_oxidized_copper
fill 258 177 621 258 177 622 minecraft:gray_concrete
fill 258 177 623 258 177 624 minecraft:gold_block
fill 258 177 625 258 177 626 minecraft:waxed_oxidized_copper
fill 258 177 627 273 177 627 minecraft:gray_concrete
fill 259 177 612 268 177 612 minecraft:gray_concrete
fill 259 177 618 262 179 619 minecraft:gray_concrete
fill 259 177 620 259 177 624 minecraft:waxed_oxidized_copper
fill 259 177 625 262 177 626 minecraft:gray_concrete
fill 259 177 632 272 177 632 minecraft:gray_concrete
fill 260 177 620 262 178 624 minecraft:gray_concrete
fill 263 177 618 272 177 618 minecraft:gray_concrete
fill 263 177 622 273 178 622 minecraft:gray_concrete
fill 263 177 626 273 178 626 minecraft:gray_concrete
fill 264 177 619 272 178 621 minecraft:gray_concrete
fill 264 177 623 273 178 625 minecraft:gray_concrete
fill 266 177 611 267 177 611 minecraft:gray_concrete
setblock 272 177 633 minecraft:gray_concrete
fill 273 177 620 273 177 621 minecraft:gray_concrete
fill 239 178 622 239 178 628 minecraft:gray_concrete
fill 240 178 619 240 178 620 minecraft:gray_concrete
fill 240 178 627 240 178 631 minecraft:gray_concrete
fill 241 178 617 247 178 617 minecraft:gray_concrete
fill 241 178 629 243 178 633 minecraft:gray_concrete
fill 242 178 615 243 178 616 minecraft:gray_concrete
fill 242 178 634 243 178 635 minecraft:gray_concrete
setblock 243 178 614 minecraft:gray_concrete
fill 243 178 636 269 178 636 minecraft:gray_concrete
fill 244 178 613 268 178 613 minecraft:gray_concrete
fill 244 178 616 249 180 616 minecraft:gray_concrete
fill 244 178 635 270 178 635 minecraft:gray_concrete
fill 244 178 637 268 178 637 minecraft:gray_concrete
setblock 245 178 612 minecraft:gray_concrete
fill 245 178 620 245 183 624 minecraft:gray_concrete
fill 245 178 638 267 178 638 minecraft:gray_concrete
fill 246 178 611 250 178 611 minecraft:gray_concrete
fill 246 178 618 246 180 619 minecraft:gray_concrete
fill 246 178 625 248 178 626 minecraft:gray_concrete
fill 246 178 639 266 178 639 minecraft:gray_concrete
fill 247 178 627 249 178 627 minecraft:gray_concrete
fill 248 178 610 250 178 610 minecraft:gray_concrete
fill 248 178 628 251 178 628 minecraft:gray_concrete
fill 248 178 640 264 178 640 minecraft:gray_concrete
fill 249 178 621 249 178 625 minecraft:black_concrete
setblock 249 178 626 minecraft:gray_concrete
fill 250 178 609 262 178 609 minecraft:gray_concrete
fill 250 178 615 254 183 615 minecraft:gray_concrete
setblock 250 178 620 minecraft:black_concrete
fill 250 178 626 250 178 627 minecraft:black_concrete
fill 250 178 629 272 178 629 minecraft:gray_concrete
fill 250 178 641 262 178 641 minecraft:gray_concrete
fill 251 178 618 251 179 618 minecraft:gray_concrete
fill 251 178 619 251 179 619 minecraft:black_concrete
setblock 251 178 627 minecraft:black_concrete
fill 252 178 618 255 179 618 minecraft:black_concrete
fill 252 178 628 256 178 628 minecraft:black_concrete
fill 253 178 608 259 178 608 minecraft:gray_concrete
fill 253 178 642 259 178 642 minecraft:gray_concrete
fill 254 178 610 264 178 611 minecraft:gray_concrete
fill 254 178 633 270 178 634 minecraft:gray_concrete
fill 255 178 616 270 178 616 minecraft:gray_concrete
fill 256 178 618 258 178 618 minecraft:gray_concrete
setblock 256 178 619 minecraft:black_concrete
fill 256 178 627 258 178 627 minecraft:black_concrete
fill 257 178 617 257 180 617 minecraft:gray_concrete
fill 257 178 619 258 178 619 minecraft:gray_concrete
fill 257 178 620 258 178 620 minecraft:black_concrete
fill 258 178 621 258 178 622 minecraft:black_concrete
fill 258 178 625 258 178 626 minecraft:black_concrete
fill 259 178 612 267 178 612 minecraft:gray_concrete
fill 259 178 620 259 178 621 minecraft:gray_concrete
fill 259 178 622 259 178 625 minecraft:black_concrete
fill 259 178 626 262 178 627 minecraft:gray_concrete
fill 259 178 632 271 179 632 minecraft:gray_concrete
fill 260 178 614 269 178 614 minecraft:gray_concrete
fill 260 178 625 262 178 625 minecraft:gray_concrete
fill 260 178 630 272 178 630 minecraft:gray_concrete
fill 263 178 618 271 179 618 minecraft:gray_concrete
fill 263 178 627 273 178 627 minecraft:gray_concrete
fill 265 178 611 266 178 611 minecraft:gray_concrete
fill 265 178 617 271 178 617 minecraft:gray_concrete
setblock 271 178 633 minecraft:gray_concrete
fill 236 179 611 236 227 612 minecraft:gray_concrete
fill 236 179 619 236 227 620 minecraft:gray_concrete
fill 236 179 627 236 227 628 minecraft:gray_concrete
fill 236 179 635 236 227 636 minecraft:gray_concrete
fill 236 179 643 236 227 644 minecraft:gray_concrete
fill 237 179 605 238 227 605 minecraft:gray_concrete
setblock 238 179 607 minecraft:light[level=14]
setblock 238 179 615 minecraft:light[level=14]
setblock 238 179 623 minecraft:light[level=14]
setblock 238 179 631 minecraft:light[level=14]
setblock 238 179 639 minecraft:light[level=14]
fill 240 179 627 240 179 629 minecraft:gray_concrete
fill 241 179 629 243 179 632 minecraft:gray_concrete
fill 242 179 617 247 179 617 minecraft:gray_concrete
fill 242 179 633 243 179 633 minecraft:gray_concrete
fill 242 179 645 243 227 645 minecraft:gray_concrete
fill 243 179 615 243 179 616 minecraft:gray_concrete
fill 243 179 634 243 179 635 minecraft:gray_concrete
fill 244 179 635 268 179 636 minecraft:gray_concrete
fill 245 179 605 246 227 605 minecraft:gray_concrete
fill 245 179 613 267 179 613 minecraft:gray_concrete
fill 245 179 637 267 179 637 minecraft:gray_concrete
setblock 246 179 607 minecraft:light[level=14]
fill 246 179 620 247 180 626 minecraft:gray_concrete
fill 246 179 631 271 179 631 minecraft:gray_concrete
fill 246 179 638 266 179 638 minecraft:gray_concrete
setblock 246 179 639 minecraft:light[level=14]
fill 247 179 618 249 180 619 minecraft:gray_concrete
fill 247 179 627 248 180 627 minecraft:gray_concrete
fill 248 179 611 250 179 611 minecraft:gray_concrete
fill 248 179 620 248 179 621 minecraft:gray_concrete
fill 248 179 622 248 179 625 minecraft:black_concrete
setblock 248 179 626 minecraft:gray_concrete
fill 248 179 628 249 179 628 minecraft:gray_concrete
fill 248 179 639 264 179 639 minecraft:gray_concrete
fill 249 179 610 250 179 610 minecraft:gray_concrete
fill 249 179 620 249 179 621 minecraft:black_concrete
fill 249 179 626 249 179 627 minecraft:black_concrete
fill 249 179 640 263 179 640 minecraft:gray_concrete
fill 250 179 618 250 181 618 minecraft:gray_concrete
setblock 250 179 619 minecraft:black_concrete
fill 250 179 628 251 179 628 minecraft:black_concrete
fill 250 179 629 251 179 629 minecraft:gray_concrete
fill 250 179 645 251 227 645 minecraft:gray_concrete
fill 252 179 609 260 179 609 minecraft:gray_concrete
fill 252 179 629 257 179 629 minecraft:black_concrete
fill 252 179 641 260 179 641 minecraft:gray_concrete
fill 253 179 605 254 227 605 minecraft:gray_concrete
setblock 254 179 607 minecraft:light[level=14]
fill 254 179 610 263 179 611 minecraft:gray_concrete
fill 254 179 633 269 180 634 minecraft:gray_concrete
fill 255 179 615 269 179 616 minecraft:gray_concrete
setblock 256 179 618 minecraft:black_concrete
fill 257 179 618 258 179 618 minecraft:gray_concrete
fill 257 179 619 258 179 619 minecraft:black_concrete
fill 257 179 628 258 179 628 minecraft:black_concrete
fill 258 179 629 272 179 629 minecraft:gray_concrete
fill 258 179 645 259 227 645 minecraft:gray_concrete
fill 259 179 612 266 179 612 minecraft:gray_concrete
fill 259 179 620 259 179 621 minecraft:black_concrete
fill 259 179 626 259 179 627 minecraft:black_concrete
fill 259 179 628 272 179 628 minecraft:gray_concrete
fill 260 179 614 268 179 614 minecraft:gray_concrete
fill 260 179 620 262 179 621 minecraft:gray_concrete
fill 260 179 622 260 179 626 minecraft:black_concrete
fill 260 179 627 272 179 627 minecraft:gray_concrete
fill 260 179 630 271 180 630 minecraft:gray_concrete
fill 261 179 605 262 227 605 minecraft:gray_concrete
fill 261 179 622 262 179 626 minecraft:gray_concrete
setblock 262 179 607 minecraft:light[level=14]
fill 263 179 622 272 179 622 minecraft:gray_concrete
fill 263 179 626 272 179 626 minecraft:gray_concrete
setblock 264 179 611 minecraft:gray_concrete
fill 264 179 619 271 179 621 minecraft:gray_concrete
fill 264 179 623 272 179 625 minecraft:gray_concrete
fill 265 179 617 270 179 617 minecraft:gray_concrete
fill 266 179 645 267 227 645 minecraft:gray_concrete
fill 269 179 605 270 227 605 minecraft:gray_concrete
setblock 269 179 635 minecraft:gray_concrete
setblock 270 179 607 minecraft:light[level=14]
setblock 270 179 615 minecraft:light[level=14]
setblock 270 179 633 minecraft:gray_concrete
setblock 270 179 639 minecraft:light[level=14]
setblock 272 179 621 minecraft:gray_concrete
fill 274 179 645 275 227 645 minecraft:gray_concrete
fill 276 179 606 276 227 607 minecraft:gray_concrete
fill 276 179 614 276 227 615 minecraft:gray_concrete
fill 276 179 622 276 227 623 minecraft:gray_concrete
fill 276 179 630 276 227 631 minecraft:gray_concrete
fill 276 179 638 276 227 639 minecraft:gray_concrete
fill 241 180 620 241 180 621 minecraft:gray_concrete
fill 241 180 629 243 180 630 minecraft:gray_concrete
fill 242 180 618 245 180 618 minecraft:gray_concrete
fill 242 180 631 243 180 632 minecraft:gray_concrete
fill 243 180 616 243 180 617 minecraft:gray_concrete
fill 243 180 633 243 180 634 minecraft:gray_concrete
fill 244 180 617 252 180 617 minecraft:gray_concrete
fill 244 180 635 268 180 635 minecraft:gray_concrete
fill 245 180 630 251 180 630 minecraft:gray_concrete
fill 245 180 636 267 180 636 minecraft:gray_concrete
fill 246 180 613 266 180 613 minecraft:gray_concrete
fill 246 180 631 253 180 631 minecraft:gray_concrete
fill 246 180 637 266 180 637 minecraft:gray_concrete
setblock 247 180 612 minecraft:gray_concrete
fill 247 180 638 265 180 638 minecraft:gray_concrete
setblock 248 180 620 minecraft:gray_concrete
fill 248 180 621 248 180 626 minecraft:gold_block
fill 248 180 628 248 181 628 minecraft:gray_concrete
fill 249 180 611 250 180 611 minecraft:gray_concrete
setblock 249 180 620 minecraft:gold_block
fill 249 180 627 249 180 628 minecraft:gold_block
fill 249 180 639 263 180 639 minecraft:gray_concrete
setblock 250 180 619 minecraft:gold_block
fill 250 180 629 251 180 629 minecraft:gold_block
fill 251 180 618 252 180 618 minecraft:gold_block
fill 251 180 640 261 180 640 minecraft:gray_concrete
fill 252 180 630 258 180 630 minecraft:gold_block
fill 253 180 617 256 180 617 minecraft:gold_block
fill 254 180 610 261 180 611 minecraft:gray_concrete
fill 254 180 631 256 180 631 minecraft:gold_block
fill 255 180 615 268 180 616 minecraft:gray_concrete
fill 257 180 618 258 180 618 minecraft:gold_block
fill 257 180 631 270 180 631 minecraft:gray_concrete
fill 258 180 629 259 180 629 minecraft:gold_block
fill 259 180 612 265 180 612 minecraft:gray_concrete
fill 259 180 618 270 180 618 minecraft:gray_concrete
setblock 259 180 619 minecraft:gold_block
fill 259 180 628 260 180 628 minecraft:gold_block
setblock 259 180 630 minecraft:gray_concrete
fill 259 180 632 270 180 632 minecraft:gray_concrete
fill 260 180 614 267 180 614 minecraft:gray_concrete
fill 260 180 619 262 180 619 minecraft:gray_concrete
fill 260 180 620 260 180 621 minecraft:gold_block
fill 260 180 627 261 180 627 minecraft:gold_block
fill 260 180 629 271 180 629 minecraft:gray_concrete
fill 261 180 620 262 180 620 minecraft:gray_concrete
fill 261 180 621 261 180 626 minecraft:gold_block
fill 261 180 628 271 180 628 minecraft:gray_concrete
fill 262 180 611 263 180 611 minecraft:gray_concrete
fill 262 180 621 262 180 627 minecraft:gray_concrete
fill 263 180 622 271 180 622 minecraft:gray_concrete
fill 263 180 626 271 180 627 minecraft:gray_concrete
fill 264 180 619 270 180 621 minecraft:gray_concrete
fill 264 180 623 271 180 625 minecraft:gray_concrete
fill 265 180 617 269 180 617 minecraft:gray_concrete
setblock 269 180 616 minecraft:gray_concrete
fill 271 180 620 271 180 621 minecraft:gray_concrete
fill 237 181 622 239 182 622 minecraft:waxed_copper_block
fill 238 181 619 240 182 621 minecraft:waxed_copper_block
fill 238 181 623 240 182 625 minecraft:waxed_copper_block
fill 239 181 618 247 182 618 minecraft:waxed_copper_block
fill 239 181 626 247 182 626 minecraft:waxed_copper_block
fill 240 181 617 246 182 617 minecraft:waxed_copper_block
fill 240 181 627 246 182 627 minecraft:waxed_copper_block
fill 241 181 619 242 182 619 minecraft:waxed_copper_block
fill 241 181 625 242 182 625 minecraft:waxed_copper_block
fill 242 181 620 244 181 624 minecraft:gray_concrete
fill 242 181 628 242 181 630 minecraft:gray_concrete
fill 243 181 616 243 182 616 minecraft:waxed_copper_block
setblock 243 181 619 minecraft:gray_concrete
fill 243 181 625 243 182 625 minecraft:gray_concrete
fill 243 181 628 243 182 628 minecraft:waxed_copper_block
fill 243 181 629 243 181 632 minecraft:gray_concrete
fill 244 181 619 248 182 619 minecraft:waxed_copper_block
fill 244 181 625 248 182 625 minecraft:waxed_copper_block
fill 244 181 628 246 182 629 minecraft:gray_concrete
fill 244 181 633 248 181 633 minecraft:gray_concrete
fill 245 181 615 249 181 616 minecraft:gray_concrete
fill 245 181 630 249 181 630 minecraft:gray_concrete
fill 245 181 634 248 181 635 minecraft:gray_concrete
fill 246 181 614 266 181 614 minecraft:gray_concrete
fill 246 181 620 248 182 621 minecraft:waxed_copper_block
fill 246 181 622 246 183 622 minecraft:gray_concrete
fill 246 181 623 248 182 624 minecraft:waxed_copper_block
fill 246 181 631 251 181 631 minecraft:gray_concrete
fill 246 181 636 266 181 636 minecraft:gray_concrete
fill 247 181 617 251 182 617 minecraft:gray_concrete
fill 247 181 622 248 182 622 minecraft:waxed_copper_block
setblock 247 181 627 minecraft:gray_concrete
fill 247 181 629 248 181 629 minecraft:gray_concrete
fill 248 181 613 264 181 613 minecraft:gray_concrete
fill 248 181 618 249 183 618 minecraft:gray_concrete
fill 248 181 626 248 181 627 minecraft:black_concrete
fill 248 181 632 253 181 632 minecraft:gray_concrete
fill 248 181 637 264 181 637 minecraft:gray_concrete
fill 249 181 612 256 181 612 minecraft:gray_concrete
setblock 249 181 619 minecraft:gray_concrete
setblock 249 181 620 minecraft:black_concrete
fill 249 181 628 249 181 629 minecraft:black_concrete
fill 249 181 635 267 181 635 minecraft:gray_concrete
fill 249 181 638 263 181 638 minecraft:gray_concrete
setblock 250 181 619 minecraft:black_concrete
fill 250 181 630 251 181 630 minecraft:black_concrete
setblock 251 181 611 minecraft:gray_concrete
fill 251 181 618 251 182 618 minecraft:black_concrete
fill 251 181 639 261 181 639 minecraft:gray_concrete
fill 252 181 617 258 181 617 minecraft:black_concrete
fill 252 181 631 253 181 631 minecraft:black_concrete
fill 254 181 611 261 181 611 minecraft:gray_concrete
fill 254 181 632 257 181 632 minecraft:black_concrete
fill 254 181 633 267 181 634 minecraft:gray_concrete
fill 255 181 615 267 181 616 minecraft:gray_concrete
fill 257 181 631 259 181 631 minecraft:black_concrete
fill 258 181 632 269 181 632 minecraft:gray_concrete
fill 259 181 612 263 181 612 minecraft:gray_concrete
fill 259 181 617 268 181 617 minecraft:gray_concrete
setblock 259 181 618 minecraft:black_concrete
fill 259 181 630 260 181 630 minecraft:black_concrete
fill 260 181 618 269 181 618 minecraft:gray_concrete
setblock 260 181 619 minecraft:black_concrete
fill 260 181 629 261 181 629 minecraft:black_concrete
fill 260 181 631 269 181 631 minecraft:gray_concrete
fill 261 181 619 262 181 619 minecraft:gray_concrete
setblock 261 181 620 minecraft:black_concrete
fill 261 181 628 262 181 628 minecraft:black_concrete
fill 261 181 630 270 181 630 minecraft:gray_concrete
setblock 262 181 620 minecraft:gray_concrete
fill 262 181 621 262 181 627 minecraft:black_concrete
fill 262 181 629 270 181 629 minecraft:gray_concrete
fill 263 181 622 270 181 623 minecraft:gray_concrete
fill 263 181 624 263 181 625 minecraft:black_concrete
fill 263 181 626 270 181 628 minecraft:gray_concrete
fill 264 181 619 269 181 621 minecraft:gray_concrete
fill 264 181 624 270 181 625 minecraft:gray_concrete
setblock 268 181 633 minecraft:gray_concrete
fill 270 181 620 270 181 621 minecraft:gray_concrete
fill 236 182 605 236 183 610 minecraft:gray_concrete
fill 236 182 613 237 182 618 minecraft:gray_concrete
fill 236 182 621 236 183 626 minecraft:gray_concrete
fill 236 182 629 237 182 634 minecraft:gray_concrete
fill 236 182 637 237 182 642 minecraft:gray_concrete
fill 236 182 645 241 183 645 minecraft:gray_concrete
fill 237 182 606 237 182 612 minecraft:gray_concrete
fill 237 182 619 237 182 621 minecraft:gray_concrete
fill 237 182 623 237 182 628 minecraft:gray_concrete
fill 237 182 635 237 182 636 minecraft:gray_concrete
fill 237 182 643 237 182 644 minecraft:gray_concrete
fill 238 182 606 275 182 606 minecraft:gray_concrete
fill 238 182 644 276 182 644 minecraft:gray_concrete
fill 239 182 605 244 183 605 minecraft:gray_concrete
fill 243 182 621 244 182 624 minecraft:gray_concrete
setblock 243 182 629 minecraft:gray_concrete
setblock 244 182 620 minecraft:gray_concrete
fill 244 182 631 249 182 631 minecraft:gray_concrete
fill 244 182 645 249 183 645 minecraft:gray_concrete
fill 245 182 630 248 182 630 minecraft:gray_concrete
fill 245 182 632 245 182 633 minecraft:gray_concrete
fill 246 182 616 253 182 616 minecraft:gray_concrete
fill 246 182 633 248 182 634 minecraft:gray_concrete
fill 247 182 605 252 183 605 minecraft:gray_concrete
fill 247 182 615 249 182 615 minecraft:gray_concrete
setblock 247 182 627 minecraft:black_concrete
fill 247 182 629 247 183 629 minecraft:gray_concrete
fill 247 182 635 265 182 635 minecraft:gray_concrete
fill 248 182 614 264 182 614 minecraft:gray_concrete
fill 248 182 628 248 182 629 minecraft:black_concrete
fill 248 182 632 251 182 632 minecraft:gray_concrete
fill 248 182 636 264 182 636 minecraft:gray_concrete
setblock 249 182 619 minecraft:black_concrete
setblock 249 182 630 minecraft:black_concrete
fill 250 182 613 262 182 613 minecraft:gray_concrete
setblock 250 182 618 minecraft:black_concrete
fill 250 182 631 251 182 631 minecraft:black_concrete
fill 250 182 637 262 182 637 minecraft:gray_concrete
fill 252 182 612 256 182 612 minecraft:gray_concrete
fill 252 182 617 253 182 617 minecraft:black_concrete
fill 252 182 632 253 182 632 minecraft:black_concrete
fill 252 182 638 260 182 638 minecraft:gray_concrete
fill 252 182 645 257 183 645 minecraft:gray_concrete
fill 254 182 616 257 182 616 minecraft:black_concrete
fill 254 182 633 258 182 633 minecraft:black_concrete
fill 254 182 634 266 182 634 minecraft:gray_concrete
fill 255 182 605 260 183 605 minecraft:gray_concrete
fill 255 182 615 265 182 615 minecraft:gray_concrete
fill 258 182 616 266 182 616 minecraft:gray_concrete
fill 258 182 617 259 182 617 minecraft:black_concrete
fill 258 182 632 260 182 632 minecraft:black_concrete
fill 259 182 612 260 182 612 minecraft:gray_concrete
fill 259 182 633 267 182 633 minecraft:gray_concrete
fill 260 182 617 267 182 617 minecraft:gray_concrete
setblock 260 182 618 minecraft:black_concrete
fill 260 182 631 261 182 631 minecraft:black_concrete
fill 260 182 645 265 183 645 minecraft:gray_concrete
fill 261 182 618 267 182 618 minecraft:gray_concrete
fill 261 182 619 262 182 619 minecraft:black_concrete
fill 261 182 630 262 182 630 minecraft:black_concrete
fill 261 182 632 267 182 632 minecraft:gray_concrete
setblock 262 182 620 minecraft:black_concrete
fill 262 182 629 263 182 629 minecraft:black_concrete
fill 262 182 631 268 182 631 minecraft:gray_concrete
fill 263 182 605 268 183 605 minecraft:gray_concrete
fill 263 182 619 268 182 620 minecraft:gray_concrete
fill 263 182 621 263 182 623 minecraft:black_concrete
fill 263 182 626 263 182 628 minecraft:black_concrete
fill 263 182 630 268 182 630 minecraft:gray_concrete
fill 264 182 621 269 182 622 minecraft:gray_concrete
fill 264 182 623 264 182 627 minecraft:black_concrete
fill 264 182 628 269 182 629 minecraft:gray_concrete
fill 265 182 623 269 182 627 minecraft:gray_concrete
fill 268 182 645 273 183 645 minecraft:gray_concrete
fill 271 182 605 276 183 605 minecraft:gray_concrete
fill 275 182 607 275 182 643 minecraft:gray_concrete
fill 276 182 608 276 183 613 minecraft:gray_concrete
fill 276 182 616 276 183 621 minecraft:gray_concrete
fill 276 182 624 276 183 629 minecraft:gray_concrete
fill 276 182 632 276 183 637 minecraft:gray_concrete
fill 276 182 640 276 183 643 minecraft:gray_concrete
fill 276 182 645 276 183 645 minecraft:gray_concrete
fill 236 183 613 236 183 618 minecraft:gray_concrete
fill 236 183 629 236 183 634 minecraft:gray_concrete
fill 236 183 637 236 183 642 minecraft:gray_concrete
fill 244 183 623 244 183 627 minecraft:gray_concrete
fill 245 183 625 246 183 630 minecraft:gray_concrete
fill 246 183 618 247 183 621 minecraft:gray_concrete
fill 246 183 623 246 183 624 minecraft:gray_concrete
fill 246 183 631 248 183 631 minecraft:gray_concrete
fill 247 183 617 250 183 617 minecraft:gray_concrete
fill 247 183 622 247 183 628 minecraft:gold_block
setblock 247 183 630 minecraft:gray_concrete
fill 247 183 633 248 183 633 minecraft:gray_concrete
fill 248 183 616 252 183 616 minecraft:gray_concrete
setblock 248 183 619 minecraft:gray_concrete
fill 248 183 620 248 183 621 minecraft:gold_block
fill 248 183 629 248 183 630 minecraft:gold_block
fill 248 183 632 249 183 632 minecraft:gray_concrete
setblock 248 183 634 minecraft:gray_concrete
setblock 249 183 615 minecraft:gray_concrete
setblock 249 183 619 minecraft:gold_block
setblock 249 183 631 minecraft:gold_block
fill 249 183 635 263 183 635 minecraft:gray_concrete
setblock 250 183 618 minecraft:gold_block
fill 250 183 632 251 183 632 minecraft:gold_block
fill 251 183 614 261 183 614 minecraft:gray_concrete
fill 251 183 617 252 183 617 minecraft:gold_block
fill 251 183 636 261 183 636 minecraft:gray_concrete
fill 252 183 633 253 183 633 minecraft:gold_block
fill 253 183 616 259 183 616 minecraft:gold_block
fill 254 183 613 258 183 613 minecraft:gray_concrete
fill 254 183 634 258 183 634 minecraft:gold_block
fill 254 183 637 258 183 637 minecraft:gray_concrete
fill 255 183 615 263 183 615 minecraft:gray_concrete
fill 259 183 633 260 183 633 minecraft:gold_block
fill 259 183 634 264 183 634 minecraft:gray_concrete
fill 260 183 616 264 183 616 minecraft:gray_concrete
setblock 260 183 617 minecraft:gold_block
fill 261 183 617 265 183 617 minecraft:gray_concrete
fill 261 183 618 262 183 618 minecraft:gold_block
setblock 261 183 632 minecraft:gold_block
fill 261 183 633 265 183 633 minecraft:gray_concrete
setblock 262 183 631 minecraft:gold_block
fill 262 183 632 266 183 632 minecraft:gray_concrete
fill 263 183 618 266 183 618 minecraft:gray_concrete
fill 263 183 619 263 183 620 minecraft:gold_block
setblock 263 183 630 minecraft:gold_block
fill 263 183 631 266 183 631 minecraft:gray_concrete
fill 264 183 619 266 183 620 minecraft:gray_concrete
fill 264 183 621 264 183 622 minecraft:gold_block
fill 264 183 628 264 183 629 minecraft:gold_block
fill 264 183 630 267 183 630 minecraft:gray_concrete
fill 265 183 621 267 183 622 minecraft:gray_concrete
fill 265 183 623 265 183 627 minecraft:gold_block
fill 265 183 628 267 183 629 minecraft:gray_concrete
fill 266 183 623 268 183 627 minecraft:gray_concrete
setblock 267 183 620 minecraft:gray_concrete
setblock 276 183 644 minecraft:gray_concrete
fill 235 186 609 235 191 609 minecraft:sea_lantern
fill 235 186 617 235 191 617 minecraft:sea_lantern
fill 235 186 625 235 191 625 minecraft:sea_lantern
fill 235 186 633 235 191 633 minecraft:sea_lantern
fill 235 186 641 235 191 641 minecraft:sea_lantern
fill 238 186 646 238 191 646 minecraft:sea_lantern
fill 242 186 604 242 191 604 minecraft:sea_lantern
fill 246 186 646 246 191 646 minecraft:sea_lantern
fill 250 186 604 250 191 604 minecraft:sea_lantern
fill 254 186 646 254 191 646 minecraft:sea_lantern
fill 258 186 604 258 191 604 minecraft:sea_lantern
fill 262 186 646 262 191 646 minecraft:sea_lantern
fill 266 186 604 266 191 604 minecraft:sea_lantern
fill 270 186 646 270 191 646 minecraft:sea_lantern
fill 274 186 604 274 191 604 minecraft:sea_lantern
fill 277 186 609 277 191 609 minecraft:sea_lantern
fill 277 186 617 277 191 617 minecraft:sea_lantern
fill 277 186 625 277 191 625 minecraft:sea_lantern
fill 277 186 633 277 191 633 minecraft:sea_lantern
fill 277 186 641 277 191 641 minecraft:sea_lantern
setblock 238 187 607 minecraft:light[level=14]
setblock 238 187 615 minecraft:light[level=14]
setblock 238 187 623 minecraft:light[level=14]
setblock 238 187 631 minecraft:light[level=14]
setblock 238 187 639 minecraft:light[level=14]
setblock 246 187 607 minecraft:light[level=14]
setblock 246 187 615 minecraft:light[level=14]
setblock 246 187 623 minecraft:light[level=14]
setblock 246 187 631 minecraft:light[level=14]
setblock 246 187 639 minecraft:light[level=14]
setblock 254 187 607 minecraft:light[level=14]
setblock 254 187 615 minecraft:light[level=14]
setblock 254 187 623 minecraft:light[level=14]
setblock 254 187 631 minecraft:light[level=14]
setblock 254 187 639 minecraft:light[level=14]
setblock 262 187 607 minecraft:light[level=14]
setblock 262 187 615 minecraft:light[level=14]
setblock 262 187 623 minecraft:light[level=14]
setblock 262 187 631 minecraft:light[level=14]
setblock 262 187 639 minecraft:light[level=14]
setblock 270 187 607 minecraft:light[level=14]
setblock 270 187 615 minecraft:light[level=14]
setblock 270 187 623 minecraft:light[level=14]
setblock 270 187 631 minecraft:light[level=14]
setblock 270 187 639 minecraft:light[level=14]
fill 240 191 605 240 192 607 minecraft:iron_block
fill 235 192 609 235 199 609 minecraft:light_gray_concrete
fill 235 192 617 235 199 617 minecraft:light_gray_concrete
fill 235 192 625 235 199 625 minecraft:light_gray_concrete
fill 235 192 633 235 199 633 minecraft:light_gray_concrete
fill 235 192 641 235 199 641 minecraft:light_gray_concrete
fill 238 192 646 238 199 646 minecraft:light_gray_concrete
fill 242 192 604 242 199 604 minecraft:light_gray_concrete
fill 246 192 646 246 199 646 minecraft:light_gray_concrete
fill 250 192 604 250 199 604 minecraft:light_gray_concrete
fill 254 192 646 254 199 646 minecraft:light_gray_concrete
fill 258 192 604 258 199 604 minecraft:light_gray_concrete
fill 262 192 646 262 199 646 minecraft:light_gray_concrete
fill 266 192 604 266 199 604 minecraft:light_gray_concrete
fill 270 192 646 270 199 646 minecraft:light_gray_concrete
fill 274 192 604 274 199 604 minecraft:light_gray_concrete
fill 277 192 609 277 199 609 minecraft:light_gray_concrete
fill 277 192 617 277 199 617 minecraft:light_gray_concrete
fill 277 192 625 277 199 625 minecraft:light_gray_concrete
fill 277 192 633 277 199 633 minecraft:light_gray_concrete
fill 277 192 641 277 199 641 minecraft:light_gray_concrete
fill 236 194 606 238 195 606 minecraft:iron_block
setblock 238 195 607 minecraft:light[level=14]
setblock 238 195 615 minecraft:light[level=14]
setblock 238 195 623 minecraft:light[level=14]
setblock 238 195 631 minecraft:light[level=14]
setblock 238 195 639 minecraft:light[level=14]
setblock 246 195 607 minecraft:light[level=14]
setblock 246 195 615 minecraft:light[level=14]
setblock 246 195 623 minecraft:light[level=14]
setblock 246 195 631 minecraft:light[level=14]
setblock 246 195 639 minecraft:light[level=14]
setblock 254 195 607 minecraft:light[level=14]
setblock 254 195 615 minecraft:light[level=14]
setblock 254 195 623 minecraft:light[level=14]
setblock 254 195 631 minecraft:light[level=14]
setblock 254 195 639 minecraft:light[level=14]
setblock 262 195 607 minecraft:light[level=14]
setblock 262 195 615 minecraft:light[level=14]
setblock 262 195 623 minecraft:light[level=14]
setblock 262 195 631 minecraft:light[level=14]
setblock 262 195 639 minecraft:light[level=14]
setblock 270 195 607 minecraft:light[level=14]
setblock 270 195 615 minecraft:light[level=14]
setblock 270 195 623 minecraft:light[level=14]
setblock 270 195 631 minecraft:light[level=14]
setblock 270 195 639 minecraft:light[level=14]
fill 236 196 605 236 197 610 minecraft:gray_concrete
fill 236 196 613 237 196 618 minecraft:gray_concrete
fill 236 196 621 237 196 626 minecraft:gray_concrete
fill 236 196 629 237 196 634 minecraft:gray_concrete
fill 236 196 637 237 196 642 minecraft:gray_concrete
fill 236 196 645 241 197 645 minecraft:gray_concrete
fill 237 196 606 237 196 612 minecraft:gray_concrete
fill 237 196 619 237 196 620 minecraft:gray_concrete
fill 237 196 627 237 196 628 minecraft:gray_concrete
fill 237 196 635 237 196 636 minecraft:gray_concrete
fill 237 196 643 237 196 644 minecraft:gray_concrete
fill 238 196 606 275 196 606 minecraft:gray_concrete
fill 238 196 644 276 196 644 minecraft:gray_concrete
fill 239 196 605 244 197 605 minecraft:gray_concrete
fill 244 196 645 249 197 645 minecraft:gray_concrete
fill 247 196 605 252 197 605 minecraft:gray_concrete
fill 252 196 645 257 197 645 minecraft:gray_concrete
fill 255 196 605 260 197 605 minecraft:gray_concrete
fill 260 196 645 265 197 645 minecraft:gray_concrete
fill 263 196 605 268 197 605 minecraft:gray_concrete
fill 268 196 645 273 197 645 minecraft:gray_concrete
fill 271 196 605 276 197 605 minecraft:gray_concrete
fill 275 196 607 275 196 643 minecraft:gray_concrete
fill 276 196 608 276 197 613 minecraft:gray_concrete
fill 276 196 616 276 197 621 minecraft:gray_concrete
fill 276 196 624 276 197 629 minecraft:gray_concrete
fill 276 196 632 276 197 637 minecraft:gray_concrete
fill 276 196 640 276 197 643 minecraft:gray_concrete
fill 276 196 645 276 197 645 minecraft:gray_concrete
fill 236 197 613 236 197 618 minecraft:gray_concrete
fill 236 197 621 236 197 626 minecraft:gray_concrete
fill 236 197 629 236 197 634 minecraft:gray_concrete
fill 236 197 637 236 197 642 minecraft:gray_concrete
setblock 276 197 644 minecraft:gray_concrete
fill 245 199 621 245 200 622 minecraft:gold_block
fill 235 200 609 235 205 609 minecraft:sea_lantern
fill 235 200 617 235 205 617 minecraft:sea_lantern
fill 235 200 625 235 205 625 minecraft:sea_lantern
fill 235 200 633 235 205 633 minecraft:sea_lantern
fill 235 200 641 235 205 641 minecraft:sea_lantern
fill 238 200 646 238 205 646 minecraft:sea_lantern
fill 242 200 604 242 205 604 minecraft:sea_lantern
fill 246 200 646 246 205 646 minecraft:sea_lantern
fill 250 200 604 250 205 604 minecraft:sea_lantern
fill 254 200 646 254 205 646 minecraft:sea_lantern
fill 258 200 604 258 205 604 minecraft:sea_lantern
fill 262 200 646 262 205 646 minecraft:sea_lantern
fill 266 200 604 266 205 604 minecraft:sea_lantern
fill 270 200 646 270 205 646 minecraft:sea_lantern
fill 274 200 604 274 205 604 minecraft:sea_lantern
fill 277 200 609 277 205 609 minecraft:sea_lantern
fill 277 200 617 277 205 617 minecraft:sea_lantern
fill 277 200 625 277 205 625 minecraft:sea_lantern
fill 277 200 633 277 205 633 minecraft:sea_lantern
fill 277 200 641 277 205 641 minecraft:sea_lantern
setblock 238 203 607 minecraft:light[level=14]
setblock 238 203 615 minecraft:light[level=14]
setblock 238 203 623 minecraft:light[level=14]
setblock 238 203 631 minecraft:light[level=14]
setblock 238 203 639 minecraft:light[level=14]
setblock 246 203 607 minecraft:light[level=14]
setblock 246 203 615 minecraft:light[level=14]
setblock 246 203 623 minecraft:light[level=14]
setblock 246 203 631 minecraft:light[level=14]
setblock 246 203 639 minecraft:light[level=14]
setblock 254 203 607 minecraft:light[level=14]
setblock 254 203 615 minecraft:light[level=14]
setblock 254 203 623 minecraft:light[level=14]
setblock 254 203 631 minecraft:light[level=14]
setblock 254 203 639 minecraft:light[level=14]
setblock 262 203 607 minecraft:light[level=14]
setblock 262 203 615 minecraft:light[level=14]
setblock 262 203 623 minecraft:light[level=14]
setblock 262 203 631 minecraft:light[level=14]
setblock 262 203 639 minecraft:light[level=14]
setblock 270 203 607 minecraft:light[level=14]
setblock 270 203 615 minecraft:light[level=14]
setblock 270 203 623 minecraft:light[level=14]
setblock 270 203 631 minecraft:light[level=14]
setblock 270 203 639 minecraft:light[level=14]
fill 235 206 609 235 213 609 minecraft:light_gray_concrete
fill 235 206 617 235 213 617 minecraft:light_gray_concrete
fill 235 206 625 235 213 625 minecraft:light_gray_concrete
fill 235 206 633 235 213 633 minecraft:light_gray_concrete
fill 235 206 641 235 213 641 minecraft:light_gray_concrete
fill 238 206 646 238 213 646 minecraft:light_gray_concrete
fill 242 206 604 242 213 604 minecraft:light_gray_concrete
fill 246 206 646 246 213 646 minecraft:light_gray_concrete
fill 250 206 604 250 213 604 minecraft:light_gray_concrete
fill 254 206 646 254 213 646 minecraft:light_gray_concrete
fill 258 206 604 258 213 604 minecraft:light_gray_concrete
fill 262 206 646 262 213 646 minecraft:light_gray_concrete
fill 266 206 604 266 213 604 minecraft:light_gray_concrete
fill 270 206 646 270 213 646 minecraft:light_gray_concrete
fill 274 206 604 274 213 604 minecraft:light_gray_concrete
fill 277 206 609 277 213 609 minecraft:light_gray_concrete
fill 277 206 617 277 213 617 minecraft:light_gray_concrete
fill 277 206 625 277 213 625 minecraft:light_gray_concrete
fill 277 206 633 277 213 633 minecraft:light_gray_concrete
fill 277 206 641 277 213 641 minecraft:light_gray_concrete
fill 236 210 605 236 211 610 minecraft:gray_concrete
fill 236 210 613 237 210 618 minecraft:gray_concrete
fill 236 210 621 237 210 626 minecraft:gray_concrete
fill 236 210 629 237 210 634 minecraft:gray_concrete
fill 236 210 637 237 210 642 minecraft:gray_concrete
fill 236 210 645 241 211 645 minecraft:gray_concrete
fill 237 210 606 237 210 612 minecraft:gray_concrete
fill 237 210 619 237 210 620 minecraft:gray_concrete
fill 237 210 627 237 210 628 minecraft:gray_concrete
fill 237 210 635 237 210 636 minecraft:gray_concrete
fill 237 210 643 237 210 644 minecraft:gray_concrete
fill 238 210 606 275 210 606 minecraft:gray_concrete
fill 238 210 644 276 210 644 minecraft:gray_concrete
fill 239 210 605 244 211 605 minecraft:gray_concrete
fill 244 210 645 249 211 645 minecraft:gray_concrete
fill 247 210 605 252 211 605 minecraft:gray_concrete
fill 252 210 645 257 211 645 minecraft:gray_concrete
fill 255 210 605 260 211 605 minecraft:gray_concrete
fill 260 210 645 265 211 645 minecraft:gray_concrete
fill 263 210 605 268 211 605 minecraft:gray_concrete
fill 268 210 645 273 211 645 minecraft:gray_concrete
fill 271 210 605 276 211 605 minecraft:gray_concrete
fill 275 210 607 275 210 643 minecraft:gray_concrete
fill 276 210 608 276 211 613 minecraft:gray_concrete
fill 276 210 616 276 211 621 minecraft:gray_concrete
fill 276 210 624 276 211 629 minecraft:gray_concrete
fill 276 210 632 276 211 637 minecraft:gray_concrete
fill 276 210 640 276 211 643 minecraft:gray_concrete
fill 276 210 645 276 211 645 minecraft:gray_concrete
fill 236 211 613 236 211 618 minecraft:gray_concrete
fill 236 211 621 236 211 626 minecraft:gray_concrete
fill 236 211 629 236 211 634 minecraft:gray_concrete
fill 236 211 637 236 211 642 minecraft:gray_concrete
setblock 238 211 607 minecraft:light[level=14]
setblock 238 211 615 minecraft:light[level=14]
setblock 238 211 623 minecraft:light[level=14]
setblock 238 211 631 minecraft:light[level=14]
setblock 238 211 639 minecraft:light[level=14]
setblock 246 211 607 minecraft:light[level=14]
setblock 246 211 615 minecraft:light[level=14]
setblock 246 211 623 minecraft:light[level=14]
setblock 246 211 631 minecraft:light[level=14]
setblock 246 211 639 minecraft:light[level=14]
setblock 254 211 607 minecraft:light[level=14]
setblock 254 211 615 minecraft:light[level=14]
setblock 254 211 623 minecraft:light[level=14]
setblock 254 211 631 minecraft:light[level=14]
setblock 254 211 639 minecraft:light[level=14]
setblock 262 211 607 minecraft:light[level=14]
setblock 262 211 615 minecraft:light[level=14]
setblock 262 211 623 minecraft:light[level=14]
setblock 262 211 631 minecraft:light[level=14]
setblock 262 211 639 minecraft:light[level=14]
setblock 270 211 607 minecraft:light[level=14]
setblock 270 211 615 minecraft:light[level=14]
setblock 270 211 623 minecraft:light[level=14]
setblock 270 211 631 minecraft:light[level=14]
setblock 270 211 639 minecraft:light[level=14]
setblock 276 211 644 minecraft:gray_concrete
fill 243 212 621 244 213 622 minecraft:gold_block
fill 235 214 609 235 219 609 minecraft:sea_lantern
fill 235 214 617 235 219 617 minecraft:sea_lantern
fill 235 214 625 235 219 625 minecraft:sea_lantern
fill 235 214 633 235 219 633 minecraft:sea_lantern
fill 235 214 641 235 219 641 minecraft:sea_lantern
fill 238 214 646 238 219 646 minecraft:sea_lantern
fill 242 214 604 242 219 604 minecraft:sea_lantern
fill 246 214 646 246 219 646 minecraft:sea_lantern
fill 250 214 604 250 219 604 minecraft:sea_lantern
fill 254 214 646 254 219 646 minecraft:sea_lantern
fill 258 214 604 258 219 604 minecraft:sea_lantern
fill 262 214 646 262 219 646 minecraft:sea_lantern
fill 266 214 604 266 219 604 minecraft:sea_lantern
fill 270 214 646 270 219 646 minecraft:sea_lantern
fill 274 214 604 274 219 604 minecraft:sea_lantern
fill 277 214 609 277 219 609 minecraft:sea_lantern
fill 277 214 617 277 219 617 minecraft:sea_lantern
fill 277 214 625 277 219 625 minecraft:sea_lantern
fill 277 214 633 277 219 633 minecraft:sea_lantern
fill 277 214 641 277 219 641 minecraft:sea_lantern
fill 249 215 641 249 216 641 minecraft:black_concrete
fill 261 215 641 261 216 641 minecraft:black_concrete
fill 266 215 608 266 216 608 minecraft:black_concrete
fill 272 215 615 272 216 615 minecraft:black_concrete
fill 272 215 620 272 216 620 minecraft:black_concrete
fill 272 215 623 272 216 623 minecraft:black_concrete
fill 249 216 642 249 217 642 minecraft:black_concrete
fill 261 216 642 261 217 642 minecraft:black_concrete
fill 266 216 607 266 217 607 minecraft:black_concrete
fill 273 216 615 273 217 615 minecraft:black_concrete
fill 273 216 620 273 217 620 minecraft:black_concrete
fill 273 216 623 273 217 623 minecraft:black_concrete
fill 249 217 643 249 218 643 minecraft:black_concrete
fill 261 217 643 261 218 643 minecraft:black_concrete
fill 266 217 606 266 218 606 minecraft:black_concrete
fill 274 217 615 274 218 615 minecraft:black_concrete
fill 274 217 620 274 218 620 minecraft:black_concrete
fill 274 217 623 274 218 623 minecraft:black_concrete
fill 249 218 644 249 219 644 minecraft:black_concrete
fill 261 218 644 261 219 644 minecraft:black_concrete
fill 266 218 605 266 219 605 minecraft:black_concrete
fill 275 218 615 275 219 615 minecraft:black_concrete
fill 275 218 620 275 219 620 minecraft:black_concrete
fill 275 218 623 275 219 623 minecraft:black_concrete
setblock 238 219 607 minecraft:light[level=14]
setblock 238 219 615 minecraft:light[level=14]
setblock 238 219 623 minecraft:light[level=14]
setblock 238 219 631 minecraft:light[level=14]
setblock 238 219 639 minecraft:light[level=14]
setblock 239 219 612 minecraft:sea_lantern
setblock 239 219 618 minecraft:sea_lantern
setblock 239 219 624 minecraft:sea_lantern
setblock 239 219 630 minecraft:sea_lantern
setblock 239 219 636 minecraft:sea_lantern
setblock 239 219 642 minecraft:sea_lantern
setblock 243 219 608 minecraft:sea_lantern
setblock 245 219 642 minecraft:sea_lantern
setblock 246 219 607 minecraft:light[level=14]
setblock 246 219 615 minecraft:light[level=14]
setblock 246 219 623 minecraft:light[level=14]
setblock 246 219 631 minecraft:light[level=14]
setblock 246 219 639 minecraft:light[level=14]
setblock 249 219 608 minecraft:sea_lantern
setblock 251 219 642 minecraft:sea_lantern
setblock 254 219 607 minecraft:light[level=14]
setblock 254 219 615 minecraft:light[level=14]
setblock 254 219 623 minecraft:light[level=14]
setblock 254 219 631 minecraft:light[level=14]
setblock 254 219 639 minecraft:light[level=14]
setblock 255 219 608 minecraft:sea_lantern
setblock 257 219 642 minecraft:sea_lantern
setblock 261 219 608 minecraft:sea_lantern
setblock 262 219 607 minecraft:light[level=14]
setblock 262 219 615 minecraft:light[level=14]
setblock 262 219 623 minecraft:light[level=14]
setblock 262 219 631 minecraft:light[level=14]
setblock 262 219 639 minecraft:light[level=14]
setblock 263 219 642 minecraft:sea_lantern
setblock 267 219 608 minecraft:sea_lantern
setblock 269 219 642 minecraft:sea_lantern
setblock 270 219 607 minecraft:light[level=14]
setblock 270 219 615 minecraft:light[level=14]
setblock 270 219 623 minecraft:light[level=14]
setblock 270 219 631 minecraft:light[level=14]
setblock 270 219 639 minecraft:light[level=14]
setblock 273 219 608 minecraft:sea_lantern
setblock 273 219 614 minecraft:sea_lantern
setblock 273 219 620 minecraft:sea_lantern
setblock 273 219 626 minecraft:sea_lantern
setblock 273 219 632 minecraft:sea_lantern
setblock 273 219 638 minecraft:sea_lantern
fill 235 220 609 235 223 609 minecraft:light_gray_concrete
fill 235 220 617 235 223 617 minecraft:light_gray_concrete
fill 235 220 621 235 220 623 minecraft:light_gray_concrete
setblock 235 220 624 minecraft:white_concrete
fill 235 220 625 235 223 625 minecraft:light_gray_concrete
fill 235 220 626 235 221 626 minecraft:white_concrete
setblock 235 220 631 minecraft:white_concrete
fill 235 220 633 235 224 633 minecraft:light_gray_concrete
setblock 235 220 635 minecraft:light_gray_concrete
setblock 235 220 636 minecraft:white_concrete
fill 235 220 637 235 221 640 minecraft:light_gray_concrete
setblock 235 220 641 minecraft:white_concrete
fill 236 220 605 236 220 610 minecraft:gray_concrete
fill 236 220 613 239 220 618 minecraft:gray_concrete
fill 236 220 621 239 220 626 minecraft:gray_concrete
fill 236 220 629 239 220 634 minecraft:gray_concrete
fill 236 220 637 239 220 642 minecraft:gray_concrete
fill 236 220 645 241 220 645 minecraft:gray_concrete
fill 237 220 606 239 220 612 minecraft:gray_concrete
fill 237 220 619 239 220 620 minecraft:gray_concrete
fill 237 220 627 239 220 628 minecraft:gray_concrete
fill 237 220 635 239 220 636 minecraft:gray_concrete
fill 237 220 643 276 220 644 minecraft:gray_concrete
setblock 238 220 646 minecraft:light_gray_concrete
setblock 239 220 604 minecraft:white_concrete
fill 239 220 605 244 220 605 minecraft:gray_concrete
fill 240 220 606 275 220 608 minecraft:gray_concrete
fill 240 220 642 276 220 642 minecraft:gray_concrete
fill 242 220 604 242 221 604 minecraft:light_gray_concrete
setblock 242 220 646 minecraft:white_concrete
fill 243 220 646 243 223 646 minecraft:light_gray_concrete
fill 244 220 645 249 220 645 minecraft:gray_concrete
setblock 246 220 646 minecraft:white_concrete
fill 247 220 605 252 220 605 minecraft:gray_concrete
fill 250 220 604 250 223 604 minecraft:light_gray_concrete
fill 252 220 645 257 220 645 minecraft:gray_concrete
fill 254 220 646 254 223 646 minecraft:light_gray_concrete
fill 255 220 605 260 220 605 minecraft:gray_concrete
fill 258 220 604 258 223 604 minecraft:light_gray_concrete
fill 260 220 645 265 220 645 minecraft:gray_concrete
fill 262 220 646 262 223 646 minecraft:light_gray_concrete
fill 263 220 605 268 220 605 minecraft:gray_concrete
fill 266 220 604 267 220 604 minecraft:light_gray_concrete
setblock 268 220 604 minecraft:white_concrete
fill 268 220 645 273 220 645 minecraft:gray_concrete
fill 269 220 604 271 223 604 minecraft:light_gray_concrete
fill 270 220 646 270 223 646 minecraft:light_gray_concrete
fill 271 220 605 276 220 605 minecraft:gray_concrete
setblock 271 220 646 minecraft:white_concrete
setblock 272 220 604 minecraft:white_concrete
fill 272 220 646 273 221 646 minecraft:light_gray_concrete
fill 273 220 604 274 223 604 minecraft:light_gray_concrete
fill 273 220 609 275 220 641 minecraft:gray_concrete
setblock 274 220 646 minecraft:white_concrete
fill 275 220 646 277 220 646 minecraft:light_gray_concrete
fill 276 220 608 276 220 613 minecraft:gray_concrete
fill 276 220 616 276 220 621 minecraft:gray_concrete
fill 276 220 624 276 220 629 minecraft:gray_concrete
fill 276 220 632 276 220 637 minecraft:gray_concrete
fill 276 220 640 276 220 641 minecraft:gray_concrete
setblock 276 220 645 minecraft:gray_concrete
fill 277 220 606 277 221 607 minecraft:light_gray_concrete
fill 277 220 608 277 220 609 minecraft:white_concrete
fill 277 220 617 277 220 618 minecraft:light_gray_concrete
setblock 277 220 619 minecraft:white_concrete
fill 277 220 620 277 221 627 minecraft:light_gray_concrete
setblock 277 220 628 minecraft:white_concrete
fill 277 220 629 277 223 630 minecraft:light_gray_concrete
fill 277 220 633 277 220 637 minecraft:light_gray_concrete
setblock 277 220 638 minecraft:white_concrete
fill 277 220 639 277 223 639 minecraft:light_gray_concrete
fill 277 220 641 277 224 641 minecraft:light_gray_concrete
fill 235 221 610 235 221 611 minecraft:light_gray_concrete
setblock 235 221 612 minecraft:white_concrete
fill 235 221 621 235 221 622 minecraft:light_gray_concrete
setblock 235 221 623 minecraft:white_concrete
fill 235 221 624 235 223 624 minecraft:light_gray_concrete
fill 235 221 631 235 223 631 minecraft:light_gray_concrete
setblock 235 221 635 minecraft:white_concrete
fill 235 221 636 235 223 636 minecraft:light_gray_concrete
setblock 235 221 641 minecraft:light_gray_concrete
setblock 235 221 646 minecraft:white_concrete
setblock 236 221 604 minecraft:white_concrete
fill 237 221 604 239 223 604 minecraft:light_gray_concrete
setblock 238 221 646 minecraft:white_concrete
fill 239 221 608 239 221 642 minecraft:gold_block
setblock 240 221 604 minecraft:white_concrete
fill 240 221 608 273 221 608 minecraft:gold_block
fill 240 221 642 273 221 642 minecraft:gold_block
fill 242 221 646 242 224 646 minecraft:light_gray_concrete
fill 243 221 604 244 223 604 minecraft:light_gray_concrete
setblock 245 221 604 minecraft:white_concrete
fill 246 221 646 246 223 646 minecraft:light_gray_concrete
fill 256 221 646 256 222 646 minecraft:white_concrete
fill 257 221 646 259 223 646 minecraft:light_gray_concrete
setblock 259 221 604 minecraft:white_concrete
fill 260 221 604 263 223 604 minecraft:light_gray_concrete
setblock 260 221 646 minecraft:white_concrete
fill 261 221 646 261 223 646 minecraft:light_gray_concrete
fill 263 221 646 263 223 646 minecraft:light_gray_concrete
setblock 264 221 646 minecraft:white_concrete
fill 265 221 646 265 223 646 minecraft:light_gray_concrete
setblock 266 221 604 minecraft:white_concrete
fill 267 221 604 268 223 604 minecraft:light_gray_concrete
setblock 268 221 646 minecraft:white_concrete
setblock 271 221 646 minecraft:light_gray_concrete
fill 272 221 604 272 223 604 minecraft:light_gray_concrete
fill 273 221 609 273 221 641 minecraft:gold_block
fill 274 221 646 276 223 646 minecraft:light_gray_concrete
fill 277 221 608 277 221 609 minecraft:light_gray_concrete
setblock 277 221 617 minecraft:white_concrete
fill 277 221 618 277 223 619 minecraft:light_gray_concrete
fill 277 221 628 277 223 628 minecraft:light_gray_concrete
fill 277 221 633 277 221 635 minecraft:white_concrete
fill 277 221 636 277 223 638 minecraft:light_gray_concrete
fill 277 221 646 277 222 646 minecraft:white_concrete
fill 235 222 604 235 223 607 minecraft:light_gray_concrete
setblock 235 222 608 minecraft:white_concrete
fill 235 222 610 235 223 610 minecraft:light_gray_concrete
setblock 235 222 611 minecraft:white_concrete
fill 235 222 612 235 223 612 minecraft:light_gray_concrete
setblock 235 222 618 minecraft:white_concrete
fill 235 222 621 235 223 621 minecraft:light_gray_concrete
setblock 235 222 622 minecraft:white_concrete
fill 235 222 623 235 223 623 minecraft:light_gray_concrete
fill 235 222 626 235 224 626 minecraft:light_gray_concrete
fill 235 222 635 235 223 635 minecraft:light_gray_concrete
fill 235 222 637 235 223 637 minecraft:light_gray_concrete
setblock 235 222 638 minecraft:white_concrete
fill 235 222 639 235 223 640 minecraft:light_gray_concrete
setblock 235 222 641 minecraft:white_concrete
fill 235 222 646 235 223 646 minecraft:light_gray_concrete
fill 236 222 604 236 224 604 minecraft:light_gray_concrete
fill 238 222 646 238 223 646 minecraft:light_gray_concrete
fill 240 222 604 240 223 604 minecraft:light_gray_concrete
setblock 242 222 604 minecraft:white_concrete
fill 245 222 604 245 223 604 minecraft:light_gray_concrete
setblock 245 222 646 minecraft:white_concrete
setblock 256 222 604 minecraft:white_concrete
fill 257 222 604 257 223 604 minecraft:light_gray_concrete
fill 259 222 604 259 223 604 minecraft:light_gray_concrete
fill 260 222 646 260 223 646 minecraft:light_gray_concrete
fill 264 222 646 264 223 646 minecraft:light_gray_concrete
fill 266 222 604 266 223 604 minecraft:light_gray_concrete
fill 268 222 646 268 223 646 minecraft:light_gray_concrete
fill 271 222 646 272 222 646 minecraft:white_concrete
fill 273 222 646 273 224 646 minecraft:light_gray_concrete
setblock 277 222 606 minecraft:white_concrete
fill 277 222 607 277 223 607 minecraft:light_gray_concrete
setblock 277 222 608 minecraft:white_concrete
fill 277 222 609 277 223 609 minecraft:light_gray_concrete
fill 277 222 617 277 223 617 minecraft:light_gray_concrete
fill 277 222 620 277 223 623 minecraft:light_gray_concrete
setblock 277 222 624 minecraft:white_concrete
fill 277 222 625 277 223 627 minecraft:light_gray_concrete
fill 277 222 633 277 223 635 minecraft:light_gray_concrete
setblock 235 223 608 minecraft:light_gray_concrete
setblock 235 223 611 minecraft:light_gray_concrete
fill 235 223 618 235 224 618 minecraft:light_gray_concrete
setblock 235 223 622 minecraft:light_gray_concrete
setblock 235 223 638 minecraft:light_gray_concrete
setblock 235 223 641 minecraft:light_gray_concrete
setblock 242 223 604 minecraft:light_gray_concrete
setblock 245 223 646 minecraft:light_gray_concrete
setblock 256 223 604 minecraft:light_gray_concrete
setblock 256 223 646 minecraft:light_gray_concrete
fill 271 223 646 272 223 646 minecraft:light_gray_concrete
fill 277 223 606 277 224 606 minecraft:light_gray_concrete
setblock 277 223 608 minecraft:light_gray_concrete
setblock 277 223 624 minecraft:light_gray_concrete
fill 277 223 646 277 224 646 minecraft:light_gray_concrete
setblock 235 224 604 minecraft:light_gray_concrete
fill 235 224 605 235 225 606 minecraft:white_concrete
setblock 235 224 607 minecraft:light_gray_concrete
fill 235 224 608 235 224 617 minecraft:white_concrete
fill 235 224 619 235 224 625 minecraft:white_concrete
fill 235 224 627 235 307 632 minecraft:white_concrete
fill 235 224 634 235 224 646 minecraft:white_concrete
fill 236 224 605 236 225 610 minecraft:gray_concrete
fill 236 224 613 237 224 618 minecraft:gray_concrete
fill 236 224 621 237 224 626 minecraft:gray_concrete
fill 236 224 629 237 224 634 minecraft:gray_concrete
fill 236 224 637 237 224 642 minecraft:gray_concrete
fill 236 224 645 241 225 645 minecraft:gray_concrete
fill 236 224 646 240 225 646 minecraft:white_concrete
fill 237 224 604 253 224 604 minecraft:white_concrete
fill 237 224 606 237 224 612 minecraft:gray_concrete
fill 237 224 619 237 224 620 minecraft:gray_concrete
fill 237 224 627 237 224 628 minecraft:gray_concrete
fill 237 224 635 237 224 636 minecraft:gray_concrete
fill 237 224 643 237 224 644 minecraft:gray_concrete
fill 238 224 606 275 224 606 minecraft:gray_concrete
fill 238 224 644 276 224 644 minecraft:gray_concrete
fill 239 224 605 244 225 605 minecraft:gray_concrete
fill 243 224 646 247 224 646 minecraft:white_concrete
fill 244 224 645 249 225 645 minecraft:gray_concrete
fill 247 224 605 252 225 605 minecraft:gray_concrete
fill 249 224 646 258 224 646 minecraft:white_concrete
fill 252 224 645 257 225 645 minecraft:gray_concrete
setblock 254 224 604 minecraft:light_gray_concrete
fill 255 224 604 260 224 604 minecraft:white_concrete
fill 255 224 605 260 225 605 minecraft:gray_concrete
setblock 259 224 646 minecraft:light_gray_concrete
fill 260 224 645 265 225 645 minecraft:gray_concrete
fill 260 224 646 272 224 646 minecraft:white_concrete
setblock 261 224 604 minecraft:light_gray_concrete
fill 262 224 604 262 307 604 minecraft:white_concrete
fill 263 224 604 263 225 604 minecraft:light_gray_concrete
fill 263 224 605 268 225 605 minecraft:gray_concrete
fill 264 224 604 272 224 604 minecraft:white_concrete
fill 268 224 645 273 225 645 minecraft:gray_concrete
fill 271 224 605 276 225 605 minecraft:gray_concrete
setblock 273 224 604 minecraft:light_gray_concrete
fill 274 224 604 277 241 604 minecraft:white_concrete
fill 274 224 646 275 225 646 minecraft:white_concrete
fill 275 224 607 275 224 643 minecraft:gray_concrete
fill 276 224 608 276 225 613 minecraft:gray_concrete
fill 276 224 616 276 225 621 minecraft:gray_concrete
fill 276 224 624 276 225 629 minecraft:gray_concrete
fill 276 224 632 276 225 637 minecraft:gray_concrete
fill 276 224 640 276 225 643 minecraft:gray_concrete
fill 276 224 645 276 225 645 minecraft:gray_concrete
setblock 276 224 646 minecraft:light_gray_concrete
fill 277 224 605 277 307 605 minecraft:white_concrete
fill 277 224 607 277 225 613 minecraft:white_concrete
fill 277 224 615 277 307 615 minecraft:white_concrete
fill 277 224 616 277 225 616 minecraft:light_gray_concrete
fill 277 224 617 277 241 621 minecraft:white_concrete
setblock 277 224 622 minecraft:light_gray_concrete
fill 277 224 623 277 224 640 minecraft:white_concrete
fill 277 224 642 277 307 643 minecraft:white_concrete
setblock 277 224 644 minecraft:light_gray_concrete
fill 277 224 645 277 307 645 minecraft:white_concrete
fill 235 225 604 247 241 604 minecraft:white_concrete
fill 235 225 607 235 307 608 minecraft:white_concrete
setblock 235 225 609 minecraft:light_gray_concrete
fill 235 225 610 235 307 611 minecraft:white_concrete
setblock 235 225 612 minecraft:light_gray_concrete
fill 235 225 613 235 225 616 minecraft:white_concrete
setblock 235 225 617 minecraft:light_gray_concrete
fill 235 225 618 235 225 623 minecraft:white_concrete
setblock 235 225 624 minecraft:light_gray_concrete
fill 235 225 625 235 241 626 minecraft:white_concrete
fill 235 225 633 235 225 636 minecraft:white_concrete
setblock 235 225 637 minecraft:light_gray_concrete
fill 235 225 638 235 241 646 minecraft:white_concrete
fill 236 225 613 236 225 618 minecraft:gray_concrete
fill 236 225 621 236 225 626 minecraft:gray_concrete
fill 236 225 629 236 225 634 minecraft:gray_concrete
fill 236 225 637 236 225 642 minecraft:gray_concrete
fill 241 225 646 243 307 646 minecraft:white_concrete
setblock 244 225 646 minecraft:light_gray_concrete
fill 245 225 646 255 225 646 minecraft:white_concrete
setblock 248 225 604 minecraft:light_gray_concrete
fill 249 225 604 256 241 604 minecraft:white_concrete
setblock 256 225 646 minecraft:light_gray_concrete
setblock 257 225 604 minecraft:light_gray_concrete
fill 257 225 646 259 307 646 minecraft:white_concrete
fill 258 225 604 261 241 604 minecraft:white_concrete
setblock 260 225 646 minecraft:light_gray_concrete
fill 261 225 646 273 225 646 minecraft:white_concrete
fill 264 225 604 265 225 604 minecraft:white_concrete
setblock 266 225 604 minecraft:light_gray_concrete
fill 267 225 604 268 307 604 minecraft:white_concrete
setblock 269 225 604 minecraft:light_gray_concrete
fill 270 225 604 273 225 604 minecraft:white_concrete
setblock 276 225 644 minecraft:gray_concrete
fill 276 225 646 277 307 646 minecraft:white_concrete
fill 277 225 606 277 307 606 minecraft:white_concrete
fill 277 225 622 277 307 623 minecraft:white_concrete
setblock 277 225 624 minecraft:light_gray_concrete
fill 277 225 625 277 225 641 minecraft:white_concrete
fill 277 225 644 277 307 644 minecraft:white_concrete
fill 235 226 605 235 307 605 minecraft:white_concrete
setblock 235 226 606 minecraft:light_gray_concrete
fill 235 226 609 235 241 609 minecraft:white_concrete
fill 235 226 612 235 307 613 minecraft:white_concrete
setblock 235 226 614 minecraft:light_gray_concrete
fill 235 226 615 235 241 617 minecraft:white_concrete
setblock 235 226 618 minecraft:light_gray_concrete
fill 235 226 619 235 307 624 minecraft:white_concrete
fill 235 226 633 235 241 635 minecraft:white_concrete
setblock 235 226 636 minecraft:light_gray_concrete
fill 235 226 637 235 307 637 minecraft:white_concrete
fill 236 226 646 238 241 646 minecraft:white_concrete
setblock 239 226 646 minecraft:light_gray_concrete
fill 240 226 646 240 307 646 minecraft:white_concrete
fill 244 226 646 247 241 646 minecraft:white_concrete
fill 248 226 604 248 307 604 minecraft:white_concrete
setblock 248 226 646 minecraft:light_gray_concrete
fill 249 226 646 256 241 646 minecraft:white_concrete
fill 257 226 604 257 307 604 minecraft:white_concrete
fill 260 226 646 263 241 646 minecraft:white_concrete
fill 262 226 638 262 227 638 minecraft:white_concrete
fill 263 226 604 264 307 604 minecraft:white_concrete
setblock 264 226 646 minecraft:light_gray_concrete
setblock 265 226 604 minecraft:light_gray_concrete
fill 265 226 646 268 307 646 minecraft:white_concrete
fill 266 226 604 266 241 604 minecraft:white_concrete
fill 269 226 604 271 307 604 minecraft:white_concrete
fill 269 226 646 270 226 646 minecraft:light_gray_concrete
fill 271 226 646 271 307 646 minecraft:white_concrete
setblock 272 226 604 minecraft:light_gray_concrete
setblock 272 226 646 minecraft:light_gray_concrete
fill 273 226 604 273 307 604 minecraft:white_concrete
fill 273 226 646 274 307 646 minecraft:white_concrete
setblock 275 226 646 minecraft:light_gray_concrete
fill 277 226 607 277 241 610 minecraft:white_concrete
setblock 277 226 611 minecraft:light_gray_concrete
fill 277 226 612 277 307 614 minecraft:white_concrete
fill 277 226 616 277 307 616 minecraft:white_concrete
fill 277 226 624 277 307 624 minecraft:white_concrete
setblock 277 226 625 minecraft:light_gray_concrete
fill 277 226 626 277 307 629 minecraft:white_concrete
setblock 277 226 630 minecraft:light_gray_concrete
fill 277 226 631 277 307 631 minecraft:white_concrete
setblock 277 226 632 minecraft:light_gray_concrete
fill 277 226 633 277 241 640 minecraft:white_concrete
setblock 277 226 641 minecraft:light_gray_concrete
fill 235 227 606 235 307 606 minecraft:white_concrete
fill 235 227 614 235 307 614 minecraft:white_concrete
fill 235 227 618 235 307 618 minecraft:white_concrete
fill 235 227 636 235 307 636 minecraft:white_concrete
setblock 238 227 607 minecraft:light[level=14]
setblock 238 227 615 minecraft:light[level=14]
setblock 238 227 623 minecraft:light[level=14]
setblock 238 227 631 minecraft:light[level=14]
setblock 238 227 639 minecraft:light[level=14]
fill 239 227 646 239 307 646 minecraft:white_concrete
setblock 246 227 607 minecraft:light[level=14]
setblock 246 227 615 minecraft:light[level=14]
setblock 246 227 623 minecraft:light[level=14]
setblock 246 227 631 minecraft:light[level=14]
setblock 246 227 639 minecraft:light[level=14]
fill 248 227 646 248 307 646 minecraft:white_concrete
setblock 254 227 607 minecraft:light[level=14]
setblock 254 227 615 minecraft:light[level=14]
setblock 254 227 623 minecraft:light[level=14]
setblock 254 227 631 minecraft:light[level=14]
setblock 254 227 639 minecraft:light[level=14]
setblock 262 227 607 minecraft:light[level=14]
setblock 262 227 615 minecraft:light[level=14]
setblock 262 227 623 minecraft:light[level=14]
setblock 262 227 631 minecraft:light[level=14]
setblock 262 227 639 minecraft:light[level=14]
fill 264 227 646 264 307 646 minecraft:white_concrete
fill 265 227 604 265 307 604 minecraft:white_concrete
fill 269 227 646 270 241 646 minecraft:white_concrete
setblock 270 227 607 minecraft:light[level=14]
setblock 270 227 615 minecraft:light[level=14]
setblock 270 227 623 minecraft:light[level=14]
setblock 270 227 631 minecraft:light[level=14]
setblock 270 227 639 minecraft:light[level=14]
fill 272 227 604 272 307 604 minecraft:white_concrete
fill 272 227 646 272 307 646 minecraft:white_concrete
fill 275 227 646 275 307 646 minecraft:white_concrete
fill 277 227 611 277 307 611 minecraft:white_concrete
fill 277 227 625 277 241 625 minecraft:white_concrete
fill 277 227 630 277 307 630 minecraft:white_concrete
fill 277 227 632 277 307 632 minecraft:white_concrete
fill 277 227 641 277 241 641 minecraft:white_concrete
fill 247 232 619 249 232 621 minecraft:redstone_block
fill 250 232 628 252 232 630 minecraft:redstone_block
fill 255 232 624 257 232 626 minecraft:redstone_block
fill 236 233 615 246 233 635 minecraft:light_gray_concrete
fill 237 233 613 275 234 614 minecraft:light_gray_concrete
fill 237 233 636 275 234 637 minecraft:light_gray_concrete
fill 238 233 612 274 234 612 minecraft:light_gray_concrete
fill 238 233 638 274 234 638 minecraft:light_gray_concrete
fill 239 233 611 273 234 611 minecraft:light_gray_concrete
fill 239 233 639 273 234 639 minecraft:light_gray_concrete
fill 240 233 609 272 234 610 minecraft:light_gray_concrete
fill 240 233 640 272 234 641 minecraft:light_gray_concrete
fill 242 233 608 270 234 608 minecraft:light_gray_concrete
fill 242 233 642 270 234 642 minecraft:light_gray_concrete
fill 243 233 607 269 234 607 minecraft:light_gray_concrete
fill 243 233 643 269 234 643 minecraft:light_gray_concrete
fill 244 233 606 268 234 606 minecraft:light_gray_concrete
fill 244 233 644 268 234 644 minecraft:light_gray_concrete
fill 246 233 605 266 234 605 minecraft:light_gray_concrete
fill 246 233 645 266 234 645 minecraft:light_gray_concrete
fill 247 233 615 276 233 618 minecraft:light_gray_concrete
fill 247 233 622 249 233 635 minecraft:light_gray_concrete
fill 250 233 619 250 233 622 minecraft:light_gray_concrete
fill 250 233 626 250 233 627 minecraft:light_gray_concrete
fill 250 233 631 276 233 635 minecraft:light_gray_concrete
fill 251 233 619 276 233 621 minecraft:light_gray_concrete
fill 251 233 622 252 233 622 minecraft:gray_concrete
fill 251 233 626 252 233 626 minecraft:gray_concrete
fill 251 233 627 276 233 627 minecraft:light_gray_concrete
fill 253 233 622 276 233 622 minecraft:light_gray_concrete
fill 253 233 623 253 233 625 minecraft:gray_concrete
fill 253 233 626 254 233 626 minecraft:light_gray_concrete
fill 253 233 628 276 233 630 minecraft:light_gray_concrete
fill 254 233 623 254 233 625 minecraft:light_gray_concrete
fill 255 233 623 276 233 623 minecraft:light_gray_concrete
fill 258 233 624 276 233 626 minecraft:light_gray_concrete
fill 236 234 605 236 234 645 minecraft:light_gray_concrete
fill 237 234 605 237 234 612 minecraft:light_gray_concrete
fill 237 234 615 245 234 635 minecraft:light_gray_concrete
fill 237 234 638 237 234 645 minecraft:light_gray_concrete
fill 238 234 605 238 234 611 minecraft:light_gray_concrete
fill 238 234 639 238 234 645 minecraft:light_gray_concrete
fill 239 234 605 239 234 610 minecraft:light_gray_concrete
fill 239 234 640 239 234 645 minecraft:light_gray_concrete
fill 240 234 605 241 234 608 minecraft:light_gray_concrete
fill 240 234 642 241 234 645 minecraft:light_gray_concrete
fill 242 234 605 242 234 607 minecraft:light_gray_concrete
fill 242 234 643 242 234 645 minecraft:light_gray_concrete
fill 243 234 605 243 234 606 minecraft:light_gray_concrete
fill 243 234 644 243 234 645 minecraft:light_gray_concrete
fill 244 234 605 245 234 605 minecraft:light_gray_concrete
fill 244 234 645 245 234 645 minecraft:light_gray_concrete
fill 246 234 615 276 234 617 minecraft:light_gray_concrete
fill 246 234 618 246 234 622 minecraft:sea_lantern
fill 246 234 623 248 234 635 minecraft:light_gray_concrete
fill 247 234 618 250 234 618 minecraft:sea_lantern
fill 247 234 619 249 235 621 minecraft:light_gray_concrete
fill 247 234 622 253 234 622 minecraft:sea_lantern
fill 249 234 623 249 234 631 minecraft:sea_lantern
fill 249 234 632 276 234 635 minecraft:light_gray_concrete
fill 250 234 619 250 234 621 minecraft:sea_lantern
fill 250 234 626 254 234 627 minecraft:sea_lantern
fill 250 234 628 252 234 630 minecraft:light_gray_concrete
fill 250 234 631 253 234 631 minecraft:sea_lantern
fill 251 234 618 276 234 620 minecraft:light_gray_concrete
fill 251 234 621 253 234 621 minecraft:gold_block
fill 253 234 623 254 234 625 minecraft:sea_lantern
fill 253 234 628 253 234 630 minecraft:sea_lantern
fill 254 234 621 276 234 621 minecraft:light_gray_concrete
setblock 254 234 622 minecraft:gold_block
fill 254 234 628 276 234 631 minecraft:light_gray_concrete
fill 255 234 622 276 234 622 minecraft:light_gray_concrete
fill 255 234 623 258 234 623 minecraft:sea_lantern
fill 255 234 624 257 234 626 minecraft:light_gray_concrete
fill 255 234 627 258 234 627 minecraft:sea_lantern
fill 258 234 624 258 234 626 minecraft:sea_lantern
fill 259 234 623 276 234 627 minecraft:light_gray_concrete
fill 267 234 605 276 234 605 minecraft:light_gray_concrete
fill 267 234 645 276 234 645 minecraft:light_gray_concrete
fill 269 234 606 276 234 606 minecraft:light_gray_concrete
fill 269 234 644 276 234 644 minecraft:light_gray_concrete
fill 270 234 607 276 234 607 minecraft:light_gray_concrete
fill 270 234 643 276 234 643 minecraft:light_gray_concrete
fill 271 234 608 276 234 608 minecraft:light_gray_concrete
fill 271 234 642 276 234 642 minecraft:light_gray_concrete
fill 273 234 609 276 234 610 minecraft:light_gray_concrete
fill 273 234 640 276 234 641 minecraft:light_gray_concrete
fill 274 234 611 276 234 611 minecraft:light_gray_concrete
fill 274 234 639 276 234 639 minecraft:light_gray_concrete
fill 275 234 612 276 234 612 minecraft:light_gray_concrete
fill 275 234 638 276 234 638 minecraft:light_gray_concrete
fill 276 234 613 276 234 614 minecraft:light_gray_concrete
fill 276 234 636 276 234 637 minecraft:light_gray_concrete
fill 236 235 617 236 235 633 minecraft:light_gray_concrete
fill 237 235 615 237 235 623 minecraft:light_gray_concrete
fill 237 235 624 239 249 624 minecraft:pink_concrete
fill 237 235 625 237 235 635 minecraft:light_gray_concrete
setblock 238 235 607 minecraft:light[level=14]
fill 238 235 614 240 235 622 minecraft:light_gray_concrete
fill 238 235 623 238 249 623 minecraft:pink_concrete
fill 238 235 625 238 249 625 minecraft:pink_concrete
fill 238 235 626 240 235 636 minecraft:light_gray_concrete
setblock 238 235 639 minecraft:light[level=14]
fill 239 235 612 250 235 613 minecraft:light_gray_concrete
fill 239 235 623 247 235 623 minecraft:light_gray_concrete
fill 239 235 625 247 235 625 minecraft:light_gray_concrete
fill 239 235 637 249 235 638 minecraft:light_gray_concrete
fill 240 235 611 249 235 611 minecraft:light_gray_concrete
fill 240 235 624 247 235 624 minecraft:light_gray_concrete
schedule function dropper:buildpart/149_2 1t
