fill 495 247 484 495 247 485 minecraft:magma_block
setblock 497 247 481 minecraft:magma_block
fill 497 247 482 497 247 483 minecraft:basalt
setblock 497 247 484 minecraft:magma_block
setblock 497 247 486 minecraft:basalt
setblock 497 247 487 minecraft:magma_block
setblock 497 247 490 minecraft:magma_block
setblock 498 247 490 minecraft:basalt
fill 499 247 483 499 247 487 minecraft:basalt
fill 507 247 464 507 250 464 minecraft:red_terracotta
setblock 509 247 465 minecraft:red_terracotta
fill 509 247 467 509 250 467 minecraft:red_terracotta
setblock 509 247 470 minecraft:red_terracotta
setblock 509 247 471 minecraft:terracotta
setblock 510 247 465 minecraft:terracotta
fill 510 247 466 510 250 466 minecraft:red_terracotta
setblock 510 247 470 minecraft:terracotta
fill 510 247 471 510 250 471 minecraft:red_terracotta
setblock 510 247 475 minecraft:terracotta
fill 510 247 476 510 250 476 minecraft:red_terracotta
setblock 510 247 485 minecraft:terracotta
fill 510 247 486 510 250 486 minecraft:red_terracotta
setblock 510 247 490 minecraft:terracotta
fill 510 247 491 510 250 491 minecraft:red_terracotta
setblock 511 247 464 minecraft:terracotta
fill 511 247 465 511 250 465 minecraft:red_terracotta
setblock 511 247 469 minecraft:terracotta
fill 511 247 470 511 250 470 minecraft:red_terracotta
setblock 511 247 474 minecraft:terracotta
fill 511 247 475 511 250 475 minecraft:red_terracotta
setblock 511 247 479 minecraft:terracotta
fill 511 247 480 511 250 480 minecraft:red_terracotta
setblock 511 247 484 minecraft:terracotta
fill 511 247 485 511 250 485 minecraft:red_terracotta
setblock 511 247 489 minecraft:terracotta
fill 511 247 490 511 250 490 minecraft:red_terracotta
setblock 511 247 494 minecraft:terracotta
fill 471 248 464 474 248 464 minecraft:red_terracotta
setblock 471 248 468 minecraft:terracotta
fill 471 248 469 471 251 469 minecraft:red_terracotta
setblock 471 248 473 minecraft:terracotta
fill 471 248 474 471 251 474 minecraft:red_terracotta
setblock 471 248 484 minecraft:red_terracotta
setblock 471 248 488 minecraft:terracotta
fill 471 248 489 471 251 489 minecraft:red_terracotta
setblock 471 248 493 minecraft:terracotta
fill 471 248 494 471 251 494 minecraft:red_terracotta
setblock 471 248 497 minecraft:red_terracotta
setblock 471 248 498 minecraft:terracotta
setblock 471 248 503 minecraft:terracotta
fill 471 248 504 474 248 504 minecraft:red_terracotta
setblock 472 248 467 minecraft:terracotta
fill 472 248 468 472 251 468 minecraft:red_terracotta
setblock 472 248 472 minecraft:terracotta
fill 472 248 473 472 251 473 minecraft:red_terracotta
setblock 472 248 492 minecraft:terracotta
fill 472 248 493 472 251 493 minecraft:red_terracotta
setblock 473 248 466 minecraft:terracotta
fill 473 248 467 473 251 467 minecraft:red_terracotta
setblock 473 248 471 minecraft:terracotta
setblock 474 248 465 minecraft:terracotta
fill 474 248 466 474 250 466 minecraft:red_terracotta
setblock 475 248 464 minecraft:terracotta
fill 475 248 465 475 251 465 minecraft:red_terracotta
setblock 475 248 504 minecraft:terracotta
fill 476 248 464 479 248 464 minecraft:red_terracotta
fill 476 248 504 477 249 504 minecraft:red_terracotta
fill 484 248 494 487 273 494 minecraft:terracotta
fill 485 248 493 486 273 493 minecraft:terracotta
fill 487 248 495 487 273 495 minecraft:terracotta
fill 487 248 504 489 248 504 minecraft:red_terracotta
setblock 490 248 464 minecraft:terracotta
setblock 490 248 504 minecraft:terracotta
fill 491 248 464 491 251 464 minecraft:red_terracotta
fill 491 248 504 491 251 504 minecraft:red_terracotta
setblock 509 248 465 minecraft:terracotta
fill 509 248 466 509 251 466 minecraft:red_terracotta
setblock 509 248 470 minecraft:terracotta
fill 509 248 471 509 249 473 minecraft:red_terracotta
setblock 510 248 464 minecraft:terracotta
fill 510 248 465 510 251 465 minecraft:red_terracotta
setblock 510 248 469 minecraft:terracotta
fill 510 248 470 510 251 470 minecraft:red_terracotta
setblock 510 248 474 minecraft:terracotta
fill 510 248 475 510 251 475 minecraft:red_terracotta
fill 510 248 477 510 249 477 minecraft:red_terracotta
setblock 510 248 484 minecraft:terracotta
fill 510 248 485 510 249 485 minecraft:red_terracotta
setblock 510 248 489 minecraft:terracotta
fill 510 248 490 510 251 490 minecraft:red_terracotta
fill 510 248 492 510 249 492 minecraft:red_terracotta
fill 511 248 464 511 251 464 minecraft:red_terracotta
setblock 511 248 468 minecraft:terracotta
fill 511 248 469 511 251 469 minecraft:red_terracotta
setblock 511 248 473 minecraft:terracotta
fill 511 248 474 511 251 474 minecraft:red_terracotta
setblock 511 248 478 minecraft:terracotta
fill 511 248 479 511 251 479 minecraft:red_terracotta
setblock 511 248 483 minecraft:terracotta
fill 511 248 484 511 251 484 minecraft:red_terracotta
setblock 511 248 488 minecraft:terracotta
fill 511 248 489 511 251 489 minecraft:red_terracotta
setblock 511 248 493 minecraft:terracotta
fill 511 248 494 511 250 495 minecraft:red_terracotta
fill 471 249 464 473 249 464 minecraft:red_terracotta
setblock 471 249 467 minecraft:terracotta
fill 471 249 468 471 252 468 minecraft:red_terracotta
setblock 471 249 472 minecraft:terracotta
fill 471 249 473 471 252 473 minecraft:red_terracotta
fill 471 249 475 471 249 476 minecraft:red_terracotta
setblock 471 249 477 minecraft:terracotta
setblock 471 249 487 minecraft:terracotta
fill 471 249 488 471 252 488 minecraft:red_terracotta
setblock 471 249 492 minecraft:terracotta
fill 471 249 493 471 252 493 minecraft:red_terracotta
setblock 471 249 497 minecraft:terracotta
fill 471 249 498 471 250 500 minecraft:red_terracotta
setblock 471 249 502 minecraft:terracotta
fill 471 249 503 471 251 504 minecraft:red_terracotta
setblock 472 249 466 minecraft:terracotta
fill 472 249 467 472 252 467 minecraft:red_terracotta
setblock 472 249 471 minecraft:terracotta
fill 472 249 472 472 252 472 minecraft:red_terracotta
setblock 472 249 491 minecraft:terracotta
fill 472 249 492 472 252 492 minecraft:red_terracotta
fill 472 249 494 472 250 494 minecraft:red_terracotta
fill 472 249 504 473 249 504 minecraft:red_terracotta
setblock 473 249 465 minecraft:terracotta
fill 473 249 466 473 251 466 minecraft:red_terracotta
setblock 473 249 470 minecraft:terracotta
fill 473 249 471 473 252 471 minecraft:red_terracotta
setblock 474 249 464 minecraft:terracotta
fill 474 249 465 474 252 465 minecraft:red_terracotta
setblock 474 249 504 minecraft:terracotta
fill 475 249 464 478 249 464 minecraft:red_terracotta
fill 475 249 504 475 252 504 minecraft:red_terracotta
fill 487 249 504 488 249 504 minecraft:red_terracotta
setblock 489 249 464 minecraft:terracotta
setblock 489 249 504 minecraft:terracotta
fill 490 249 464 490 252 464 minecraft:red_terracotta
fill 490 249 504 490 252 504 minecraft:red_terracotta
setblock 508 249 465 minecraft:terracotta
setblock 509 249 464 minecraft:terracotta
fill 509 249 465 509 252 465 minecraft:red_terracotta
setblock 509 249 468 minecraft:red_terracotta
setblock 509 249 469 minecraft:terracotta
fill 509 249 470 509 252 470 minecraft:red_terracotta
setblock 509 249 474 minecraft:terracotta
fill 510 249 464 510 252 464 minecraft:red_terracotta
setblock 510 249 468 minecraft:terracotta
fill 510 249 469 510 252 469 minecraft:red_terracotta
setblock 510 249 473 minecraft:terracotta
fill 510 249 474 510 252 474 minecraft:red_terracotta
setblock 510 249 478 minecraft:terracotta
setblock 510 249 488 minecraft:terracotta
fill 510 249 489 510 252 489 minecraft:red_terracotta
setblock 510 249 493 minecraft:terracotta
setblock 511 249 467 minecraft:terracotta
fill 511 249 468 511 252 468 minecraft:red_terracotta
setblock 511 249 472 minecraft:terracotta
fill 511 249 473 511 252 473 minecraft:red_terracotta
setblock 511 249 477 minecraft:terracotta
fill 511 249 478 511 252 478 minecraft:red_terracotta
setblock 511 249 482 minecraft:terracotta
fill 511 249 483 511 252 483 minecraft:red_terracotta
setblock 511 249 487 minecraft:terracotta
fill 511 249 488 511 252 488 minecraft:red_terracotta
setblock 511 249 492 minecraft:terracotta
fill 511 249 493 511 252 493 minecraft:red_terracotta
setblock 511 249 496 minecraft:red_terracotta
fill 471 250 464 472 250 464 minecraft:red_terracotta
setblock 471 250 466 minecraft:terracotta
fill 471 250 467 471 253 467 minecraft:red_terracotta
setblock 471 250 471 minecraft:terracotta
fill 471 250 472 471 253 472 minecraft:red_terracotta
setblock 471 250 475 minecraft:red_terracotta
setblock 471 250 476 minecraft:terracotta
fill 471 250 477 471 252 478 minecraft:red_terracotta
setblock 471 250 486 minecraft:terracotta
fill 471 250 487 471 253 487 minecraft:red_terracotta
setblock 471 250 491 minecraft:terracotta
fill 471 250 492 471 253 492 minecraft:red_terracotta
setblock 471 250 495 minecraft:red_terracotta
setblock 471 250 496 minecraft:terracotta
fill 471 250 497 472 252 497 minecraft:red_terracotta
setblock 471 250 501 minecraft:terracotta
fill 471 250 502 471 253 502 minecraft:red_terracotta
setblock 472 250 465 minecraft:terracotta
fill 472 250 466 472 253 466 minecraft:red_terracotta
setblock 472 250 470 minecraft:terracotta
fill 472 250 471 472 253 471 minecraft:red_terracotta
setblock 472 250 475 minecraft:terracotta
setblock 472 250 490 minecraft:terracotta
fill 472 250 491 472 253 491 minecraft:red_terracotta
setblock 472 250 495 minecraft:terracotta
fill 472 250 496 472 253 496 minecraft:red_terracotta
setblock 472 250 504 minecraft:red_terracotta
setblock 473 250 464 minecraft:terracotta
fill 473 250 465 473 253 465 minecraft:red_terracotta
setblock 473 250 469 minecraft:terracotta
fill 473 250 470 473 253 470 minecraft:red_terracotta
fill 473 250 472 473 251 472 minecraft:red_terracotta
setblock 473 250 504 minecraft:terracotta
fill 474 250 464 477 250 464 minecraft:red_terracotta
fill 474 250 504 474 253 504 minecraft:red_terracotta
fill 476 250 504 476 251 504 minecraft:red_terracotta
fill 486 250 504 487 250 504 minecraft:red_terracotta
setblock 488 250 464 minecraft:terracotta
setblock 488 250 504 minecraft:terracotta
fill 489 250 464 489 253 464 minecraft:red_terracotta
fill 489 250 504 489 253 504 minecraft:red_terracotta
fill 506 250 464 506 251 464 minecraft:red_terracotta
setblock 507 250 465 minecraft:terracotta
setblock 508 250 464 minecraft:terracotta
fill 508 250 465 508 253 465 minecraft:red_terracotta
fill 509 250 464 509 253 464 minecraft:red_terracotta
setblock 509 250 468 minecraft:terracotta
fill 509 250 469 509 253 469 minecraft:red_terracotta
fill 509 250 471 509 250 472 minecraft:red_terracotta
setblock 509 250 473 minecraft:terracotta
fill 509 250 474 509 252 475 minecraft:red_terracotta
setblock 510 250 467 minecraft:terracotta
fill 510 250 468 510 253 468 minecraft:red_terracotta
setblock 510 250 472 minecraft:terracotta
fill 510 250 473 510 253 473 minecraft:red_terracotta
setblock 510 250 477 minecraft:terracotta
fill 510 250 478 510 252 479 minecraft:red_terracotta
setblock 510 250 487 minecraft:terracotta
fill 510 250 488 510 253 488 minecraft:red_terracotta
setblock 510 250 492 minecraft:terracotta
fill 510 250 493 510 252 494 minecraft:red_terracotta
setblock 511 250 466 minecraft:terracotta
fill 511 250 467 511 253 467 minecraft:red_terracotta
setblock 511 250 471 minecraft:terracotta
fill 511 250 472 511 253 472 minecraft:red_terracotta
setblock 511 250 476 minecraft:terracotta
fill 511 250 477 511 253 477 minecraft:red_terracotta
setblock 511 250 481 minecraft:terracotta
fill 511 250 482 511 253 482 minecraft:red_terracotta
setblock 511 250 486 minecraft:terracotta
fill 511 250 487 511 253 487 minecraft:red_terracotta
setblock 511 250 491 minecraft:terracotta
fill 511 250 492 511 253 492 minecraft:red_terracotta
setblock 511 250 496 minecraft:terracotta
fill 511 250 497 511 253 497 minecraft:red_terracotta
setblock 471 251 464 minecraft:red_terracotta
setblock 471 251 465 minecraft:terracotta
fill 471 251 466 471 254 466 minecraft:red_terracotta
setblock 471 251 470 minecraft:terracotta
fill 471 251 471 471 254 471 minecraft:red_terracotta
setblock 471 251 475 minecraft:terracotta
fill 471 251 476 471 254 476 minecraft:red_terracotta
setblock 471 251 479 minecraft:red_terracotta
fill 471 251 486 471 253 486 minecraft:red_terracotta
setblock 471 251 490 minecraft:terracotta
fill 471 251 491 471 254 491 minecraft:red_terracotta
setblock 471 251 495 minecraft:terracotta
fill 471 251 496 471 254 496 minecraft:red_terracotta
fill 471 251 498 471 251 499 minecraft:red_terracotta
setblock 471 251 500 minecraft:terracotta
fill 471 251 501 471 254 501 minecraft:red_terracotta
setblock 472 251 464 minecraft:terracotta
fill 472 251 465 472 254 465 minecraft:red_terracotta
setblock 472 251 469 minecraft:terracotta
fill 472 251 470 472 254 470 minecraft:red_terracotta
setblock 472 251 474 minecraft:terracotta
fill 472 251 475 472 254 475 minecraft:red_terracotta
setblock 472 251 489 minecraft:terracotta
fill 472 251 490 472 254 490 minecraft:red_terracotta
setblock 472 251 494 minecraft:terracotta
fill 472 251 495 472 254 495 minecraft:red_terracotta
setblock 472 251 498 minecraft:red_terracotta
setblock 472 251 499 minecraft:terracotta
setblock 472 251 504 minecraft:terracotta
fill 473 251 464 476 251 464 minecraft:red_terracotta
setblock 473 251 468 minecraft:terracotta
fill 473 251 469 473 253 469 minecraft:red_terracotta
fill 473 251 504 473 254 504 minecraft:red_terracotta
setblock 477 251 464 minecraft:terracotta
fill 485 251 504 486 251 504 minecraft:red_terracotta
setblock 487 251 464 minecraft:terracotta
setblock 487 251 504 minecraft:terracotta
fill 488 251 464 488 254 464 minecraft:red_terracotta
fill 488 251 504 488 254 504 minecraft:red_terracotta
setblock 492 251 504 minecraft:terracotta
setblock 507 251 464 minecraft:terracotta
fill 507 251 465 507 254 465 minecraft:red_terracotta
fill 508 251 464 508 254 464 minecraft:red_terracotta
fill 508 251 466 508 252 466 minecraft:red_terracotta
fill 508 251 469 508 251 472 minecraft:red_terracotta
setblock 508 251 473 minecraft:terracotta
setblock 509 251 467 minecraft:terracotta
fill 509 251 468 509 254 468 minecraft:red_terracotta
setblock 509 251 471 minecraft:red_terracotta
setblock 509 251 472 minecraft:terracotta
fill 509 251 473 509 254 473 minecraft:red_terracotta
setblock 509 251 476 minecraft:red_terracotta
setblock 509 251 477 minecraft:terracotta
setblock 510 251 466 minecraft:terracotta
fill 510 251 467 510 254 467 minecraft:red_terracotta
setblock 510 251 471 minecraft:terracotta
fill 510 251 472 510 254 472 minecraft:red_terracotta
setblock 510 251 476 minecraft:terracotta
fill 510 251 477 510 254 477 minecraft:red_terracotta
setblock 510 251 480 minecraft:red_terracotta
setblock 510 251 486 minecraft:terracotta
fill 510 251 487 510 252 487 minecraft:red_terracotta
setblock 510 251 491 minecraft:terracotta
fill 510 251 492 510 254 492 minecraft:red_terracotta
setblock 510 251 495 minecraft:red_terracotta
setblock 511 251 465 minecraft:terracotta
fill 511 251 466 511 254 466 minecraft:red_terracotta
setblock 511 251 470 minecraft:terracotta
fill 511 251 471 511 254 471 minecraft:red_terracotta
setblock 511 251 475 minecraft:terracotta
fill 511 251 476 511 254 476 minecraft:red_terracotta
setblock 511 251 480 minecraft:terracotta
fill 511 251 481 511 254 481 minecraft:red_terracotta
setblock 511 251 485 minecraft:terracotta
fill 511 251 486 511 254 486 minecraft:red_terracotta
setblock 511 251 490 minecraft:terracotta
fill 511 251 491 511 254 491 minecraft:red_terracotta
setblock 511 251 494 minecraft:red_terracotta
setblock 511 251 495 minecraft:terracotta
fill 511 251 496 511 254 496 minecraft:red_terracotta
fill 511 251 498 511 251 499 minecraft:red_terracotta
setblock 511 251 504 minecraft:red_terracotta
setblock 471 252 464 minecraft:terracotta
fill 471 252 465 471 255 465 minecraft:red_terracotta
setblock 471 252 469 minecraft:terracotta
fill 471 252 470 471 255 470 minecraft:red_terracotta
setblock 471 252 474 minecraft:terracotta
fill 471 252 475 471 255 475 minecraft:red_terracotta
setblock 471 252 479 minecraft:terracotta
setblock 471 252 489 minecraft:terracotta
fill 471 252 490 471 255 490 minecraft:red_terracotta
setblock 471 252 494 minecraft:terracotta
fill 471 252 495 471 255 495 minecraft:red_terracotta
setblock 471 252 498 minecraft:red_terracotta
setblock 471 252 499 minecraft:terracotta
fill 471 252 500 472 254 500 minecraft:red_terracotta
setblock 471 252 503 minecraft:red_terracotta
setblock 471 252 504 minecraft:terracotta
fill 472 252 464 475 252 464 minecraft:red_terracotta
setblock 472 252 468 minecraft:terracotta
fill 472 252 469 472 255 469 minecraft:red_terracotta
setblock 472 252 473 minecraft:terracotta
fill 472 252 474 472 255 474 minecraft:red_terracotta
fill 472 252 476 472 253 476 minecraft:red_terracotta
setblock 472 252 493 minecraft:terracotta
fill 472 252 494 472 255 494 minecraft:red_terracotta
setblock 472 252 498 minecraft:terracotta
fill 472 252 499 472 255 499 minecraft:red_terracotta
fill 472 252 501 472 252 502 minecraft:red_terracotta
setblock 472 252 503 minecraft:terracotta
fill 472 252 504 472 255 504 minecraft:red_terracotta
setblock 473 252 467 minecraft:terracotta
fill 473 252 468 473 253 468 minecraft:red_terracotta
setblock 473 252 472 minecraft:terracotta
setblock 476 252 464 minecraft:terracotta
setblock 476 252 504 minecraft:terracotta
fill 477 252 464 477 265 464 minecraft:magma_block
fill 484 252 504 485 252 504 minecraft:red_terracotta
setblock 486 252 504 minecraft:terracotta
fill 487 252 464 487 255 464 minecraft:red_terracotta
fill 487 252 504 487 255 504 minecraft:red_terracotta
setblock 491 252 464 minecraft:terracotta
setblock 491 252 504 minecraft:terracotta
setblock 492 252 504 minecraft:red_terracotta
setblock 505 252 464 minecraft:red_terracotta
setblock 506 252 464 minecraft:terracotta
fill 506 252 465 506 255 465 minecraft:red_terracotta
fill 507 252 464 507 255 464 minecraft:red_terracotta
fill 507 252 466 507 253 466 minecraft:red_terracotta
fill 508 252 468 508 252 471 minecraft:red_terracotta
setblock 508 252 472 minecraft:terracotta
fill 508 252 473 508 253 475 minecraft:red_terracotta
setblock 509 252 466 minecraft:terracotta
fill 509 252 467 509 255 467 minecraft:red_terracotta
setblock 509 252 471 minecraft:terracotta
fill 509 252 472 509 255 472 minecraft:red_terracotta
setblock 509 252 476 minecraft:terracotta
fill 509 252 477 509 254 478 minecraft:red_terracotta
fill 509 252 504 510 252 504 minecraft:red_terracotta
setblock 510 252 465 minecraft:terracotta
fill 510 252 466 510 255 466 minecraft:red_terracotta
setblock 510 252 470 minecraft:terracotta
fill 510 252 471 510 255 471 minecraft:red_terracotta
setblock 510 252 475 minecraft:terracotta
fill 510 252 476 510 255 476 minecraft:red_terracotta
setblock 510 252 480 minecraft:terracotta
fill 510 252 481 510 255 481 minecraft:red_terracotta
setblock 510 252 490 minecraft:terracotta
fill 510 252 491 510 255 491 minecraft:red_terracotta
setblock 510 252 495 minecraft:terracotta
fill 510 252 496 510 254 497 minecraft:red_terracotta
setblock 511 252 464 minecraft:terracotta
fill 511 252 465 511 255 465 minecraft:red_terracotta
setblock 511 252 469 minecraft:terracotta
fill 511 252 470 511 255 470 minecraft:red_terracotta
setblock 511 252 474 minecraft:terracotta
fill 511 252 475 511 255 475 minecraft:red_terracotta
setblock 511 252 479 minecraft:terracotta
fill 511 252 480 511 255 480 minecraft:red_terracotta
setblock 511 252 484 minecraft:terracotta
fill 511 252 485 511 255 485 minecraft:red_terracotta
setblock 511 252 489 minecraft:terracotta
fill 511 252 490 511 255 490 minecraft:red_terracotta
setblock 511 252 494 minecraft:terracotta
fill 511 252 495 511 255 495 minecraft:red_terracotta
setblock 511 252 498 minecraft:red_terracotta
setblock 511 252 499 minecraft:terracotta
fill 511 252 500 511 252 503 minecraft:red_terracotta
setblock 511 252 504 minecraft:terracotta
fill 471 253 464 474 253 464 minecraft:red_terracotta
setblock 471 253 468 minecraft:terracotta
fill 471 253 469 471 256 469 minecraft:red_terracotta
setblock 471 253 473 minecraft:terracotta
fill 471 253 474 471 256 474 minecraft:red_terracotta
setblock 471 253 477 minecraft:red_terracotta
setblock 471 253 478 minecraft:terracotta
fill 471 253 479 471 255 480 minecraft:red_terracotta
setblock 471 253 488 minecraft:terracotta
fill 471 253 489 471 256 489 minecraft:red_terracotta
setblock 471 253 493 minecraft:terracotta
fill 471 253 494 471 256 494 minecraft:red_terracotta
setblock 471 253 497 minecraft:red_terracotta
setblock 471 253 498 minecraft:terracotta
fill 471 253 499 471 256 499 minecraft:red_terracotta
setblock 471 253 503 minecraft:terracotta
fill 471 253 504 471 256 504 minecraft:red_terracotta
setblock 472 253 467 minecraft:terracotta
fill 472 253 468 472 256 468 minecraft:red_terracotta
setblock 472 253 472 minecraft:terracotta
fill 472 253 473 472 256 473 minecraft:red_terracotta
setblock 472 253 492 minecraft:terracotta
fill 472 253 493 472 256 493 minecraft:red_terracotta
setblock 472 253 497 minecraft:terracotta
fill 472 253 498 472 256 498 minecraft:red_terracotta
setblock 472 253 501 minecraft:red_terracotta
setblock 472 253 502 minecraft:terracotta
fill 472 253 503 473 255 503 minecraft:red_terracotta
setblock 473 253 466 minecraft:light[level=14]
setblock 473 253 471 minecraft:terracotta
fill 473 253 472 473 254 472 minecraft:red_terracotta
setblock 473 253 474 minecraft:light[level=14]
setblock 473 253 482 minecraft:light[level=14]
setblock 473 253 490 minecraft:light[level=14]
fill 473 253 494 473 253 495 minecraft:red_terracotta
setblock 473 253 496 minecraft:terracotta
fill 473 253 497 473 256 497 minecraft:red_terracotta
setblock 473 253 498 minecraft:light[level=14]
setblock 474 253 465 minecraft:terracotta
setblock 475 253 464 minecraft:terracotta
setblock 475 253 504 minecraft:terracotta
setblock 476 253 464 minecraft:red_terracotta
fill 476 253 504 477 255 504 minecraft:red_terracotta
setblock 481 253 466 minecraft:light[level=14]
setblock 481 253 474 minecraft:light[level=14]
setblock 481 253 482 minecraft:light[level=14]
setblock 481 253 490 minecraft:light[level=14]
setblock 481 253 498 minecraft:light[level=14]
fill 482 253 504 484 253 504 minecraft:red_terracotta
setblock 485 253 504 minecraft:terracotta
fill 486 253 464 486 256 464 minecraft:red_terracotta
setblock 486 253 503 minecraft:terracotta
fill 486 253 504 486 256 504 minecraft:red_terracotta
fill 487 253 503 489 254 503 minecraft:red_terracotta
setblock 489 253 466 minecraft:light[level=14]
setblock 489 253 474 minecraft:light[level=14]
setblock 489 253 482 minecraft:light[level=14]
setblock 489 253 490 minecraft:light[level=14]
setblock 489 253 498 minecraft:light[level=14]
setblock 490 253 464 minecraft:terracotta
setblock 490 253 504 minecraft:terracotta
fill 491 253 504 491 256 504 minecraft:red_terracotta
setblock 497 253 466 minecraft:light[level=14]
setblock 497 253 474 minecraft:light[level=14]
setblock 497 253 482 minecraft:light[level=14]
setblock 497 253 490 minecraft:light[level=14]
setblock 497 253 498 minecraft:light[level=14]
setblock 504 253 464 minecraft:red_terracotta
setblock 505 253 464 minecraft:terracotta
setblock 505 253 466 minecraft:light[level=14]
setblock 505 253 474 minecraft:light[level=14]
setblock 505 253 482 minecraft:light[level=14]
setblock 505 253 490 minecraft:light[level=14]
setblock 505 253 498 minecraft:light[level=14]
fill 506 253 464 506 256 464 minecraft:red_terracotta
setblock 508 253 466 minecraft:terracotta
fill 508 253 468 508 253 470 minecraft:red_terracotta
setblock 508 253 471 minecraft:terracotta
fill 508 253 472 508 256 472 minecraft:red_terracotta
setblock 508 253 476 minecraft:terracotta
fill 508 253 504 509 253 504 minecraft:red_terracotta
setblock 509 253 465 minecraft:terracotta
fill 509 253 466 509 256 466 minecraft:red_terracotta
setblock 509 253 470 minecraft:terracotta
fill 509 253 471 509 256 471 minecraft:red_terracotta
setblock 509 253 474 minecraft:red_terracotta
setblock 509 253 475 minecraft:terracotta
fill 509 253 476 509 256 476 minecraft:red_terracotta
setblock 509 253 479 minecraft:red_terracotta
fill 509 253 492 509 253 494 minecraft:red_terracotta
setblock 510 253 464 minecraft:terracotta
fill 510 253 465 510 256 465 minecraft:red_terracotta
setblock 510 253 469 minecraft:terracotta
fill 510 253 470 510 256 470 minecraft:red_terracotta
setblock 510 253 474 minecraft:terracotta
fill 510 253 475 510 256 475 minecraft:red_terracotta
setblock 510 253 478 minecraft:red_terracotta
setblock 510 253 479 minecraft:terracotta
fill 510 253 480 510 256 480 minecraft:red_terracotta
setblock 510 253 489 minecraft:terracotta
fill 510 253 490 510 255 490 minecraft:red_terracotta
setblock 510 253 493 minecraft:red_terracotta
setblock 510 253 494 minecraft:terracotta
fill 510 253 495 510 256 495 minecraft:red_terracotta
setblock 510 253 498 minecraft:red_terracotta
setblock 510 253 499 minecraft:terracotta
setblock 510 253 504 minecraft:terracotta
fill 511 253 464 511 256 464 minecraft:red_terracotta
setblock 511 253 468 minecraft:terracotta
fill 511 253 469 511 256 469 minecraft:red_terracotta
setblock 511 253 473 minecraft:terracotta
fill 511 253 474 511 256 474 minecraft:red_terracotta
setblock 511 253 478 minecraft:terracotta
fill 511 253 479 511 256 479 minecraft:red_terracotta
setblock 511 253 483 minecraft:terracotta
fill 511 253 484 511 255 484 minecraft:red_terracotta
setblock 511 253 488 minecraft:terracotta
fill 511 253 489 511 256 489 minecraft:red_terracotta
setblock 511 253 493 minecraft:terracotta
fill 511 253 494 511 256 494 minecraft:red_terracotta
setblock 511 253 498 minecraft:terracotta
fill 511 253 499 511 253 502 minecraft:red_terracotta
setblock 511 253 503 minecraft:terracotta
fill 511 253 504 511 256 504 minecraft:red_terracotta
fill 471 254 464 473 254 464 minecraft:red_terracotta
setblock 471 254 467 minecraft:terracotta
fill 471 254 468 471 257 468 minecraft:red_terracotta
setblock 471 254 472 minecraft:terracotta
fill 471 254 473 471 257 473 minecraft:red_terracotta
setblock 471 254 477 minecraft:terracotta
fill 471 254 478 471 257 478 minecraft:red_terracotta
setblock 471 254 487 minecraft:terracotta
fill 471 254 488 471 255 488 minecraft:red_terracotta
setblock 471 254 492 minecraft:terracotta
fill 471 254 493 471 257 493 minecraft:red_terracotta
setblock 471 254 497 minecraft:terracotta
fill 471 254 498 471 257 498 minecraft:red_terracotta
setblock 471 254 502 minecraft:terracotta
fill 471 254 503 471 257 503 minecraft:red_terracotta
setblock 472 254 466 minecraft:terracotta
fill 472 254 467 472 256 467 minecraft:red_terracotta
setblock 472 254 471 minecraft:terracotta
fill 472 254 472 472 257 472 minecraft:red_terracotta
setblock 472 254 476 minecraft:terracotta
fill 472 254 477 472 256 477 minecraft:red_terracotta
setblock 472 254 491 minecraft:terracotta
fill 472 254 492 472 256 492 minecraft:red_terracotta
setblock 472 254 496 minecraft:terracotta
fill 472 254 497 472 257 497 minecraft:red_terracotta
setblock 472 254 501 minecraft:terracotta
fill 472 254 502 472 257 502 minecraft:red_terracotta
setblock 473 254 465 minecraft:terracotta
setblock 473 254 470 minecraft:terracotta
setblock 473 254 471 minecraft:red_terracotta
setblock 473 254 494 minecraft:red_terracotta
setblock 473 254 495 minecraft:terracotta
fill 473 254 496 473 257 496 minecraft:red_terracotta
fill 473 254 498 473 254 499 minecraft:red_terracotta
setblock 474 254 464 minecraft:terracotta
setblock 474 254 504 minecraft:terracotta
setblock 475 254 464 minecraft:red_terracotta
fill 475 254 504 475 257 504 minecraft:red_terracotta
fill 476 254 464 476 266 464 minecraft:shroomlight
fill 480 254 504 483 254 504 minecraft:red_terracotta
setblock 484 254 503 minecraft:red_terracotta
setblock 484 254 504 minecraft:terracotta
setblock 485 254 503 minecraft:terracotta
fill 485 254 504 485 257 504 minecraft:red_terracotta
fill 486 254 503 486 257 503 minecraft:red_terracotta
setblock 489 254 464 minecraft:terracotta
setblock 489 254 504 minecraft:terracotta
setblock 490 254 464 minecraft:red_terracotta
fill 490 254 504 490 257 504 minecraft:red_terracotta
setblock 504 254 464 minecraft:terracotta
fill 505 254 464 505 256 465 minecraft:red_terracotta
setblock 506 254 466 minecraft:red_terracotta
fill 506 254 504 508 254 504 minecraft:red_terracotta
setblock 507 254 466 minecraft:terracotta
setblock 507 254 471 minecraft:terracotta
fill 507 254 472 507 255 474 minecraft:red_terracotta
setblock 508 254 465 minecraft:terracotta
fill 508 254 466 508 257 466 minecraft:red_terracotta
fill 508 254 468 508 254 469 minecraft:red_terracotta
setblock 508 254 470 minecraft:terracotta
fill 508 254 471 508 257 471 minecraft:red_terracotta
fill 508 254 473 508 254 474 minecraft:red_terracotta
setblock 508 254 475 minecraft:terracotta
fill 508 254 476 508 256 477 minecraft:red_terracotta
setblock 509 254 464 minecraft:terracotta
fill 509 254 465 509 257 465 minecraft:red_terracotta
setblock 509 254 469 minecraft:terracotta
fill 509 254 470 509 257 470 minecraft:red_terracotta
setblock 509 254 474 minecraft:terracotta
fill 509 254 475 509 257 475 minecraft:red_terracotta
setblock 509 254 479 minecraft:terracotta
fill 509 254 492 509 254 493 minecraft:red_terracotta
setblock 509 254 494 minecraft:terracotta
fill 509 254 495 509 256 496 minecraft:red_terracotta
setblock 509 254 504 minecraft:terracotta
fill 510 254 464 510 257 464 minecraft:red_terracotta
setblock 510 254 468 minecraft:terracotta
fill 510 254 469 510 257 469 minecraft:red_terracotta
setblock 510 254 473 minecraft:terracotta
fill 510 254 474 510 257 474 minecraft:red_terracotta
setblock 510 254 478 minecraft:terracotta
fill 510 254 479 510 257 479 minecraft:red_terracotta
setblock 510 254 482 minecraft:red_terracotta
setblock 510 254 489 minecraft:red_terracotta
setblock 510 254 493 minecraft:terracotta
fill 510 254 494 510 257 494 minecraft:red_terracotta
setblock 510 254 498 minecraft:terracotta
fill 510 254 499 511 254 501 minecraft:red_terracotta
fill 510 254 504 510 257 504 minecraft:red_terracotta
setblock 511 254 467 minecraft:terracotta
fill 511 254 468 511 257 468 minecraft:red_terracotta
setblock 511 254 472 minecraft:terracotta
fill 511 254 473 511 257 473 minecraft:red_terracotta
setblock 511 254 477 minecraft:terracotta
fill 511 254 478 511 257 478 minecraft:red_terracotta
setblock 511 254 482 minecraft:terracotta
fill 511 254 483 511 256 483 minecraft:red_terracotta
setblock 511 254 487 minecraft:terracotta
fill 511 254 488 511 255 488 minecraft:red_terracotta
setblock 511 254 492 minecraft:terracotta
fill 511 254 493 511 257 493 minecraft:red_terracotta
setblock 511 254 497 minecraft:terracotta
fill 511 254 498 511 257 498 minecraft:red_terracotta
setblock 511 254 502 minecraft:terracotta
fill 511 254 503 511 257 503 minecraft:red_terracotta
fill 471 255 464 472 255 464 minecraft:red_terracotta
setblock 471 255 466 minecraft:terracotta
fill 471 255 467 471 258 467 minecraft:red_terracotta
setblock 471 255 471 minecraft:terracotta
fill 471 255 472 471 258 472 minecraft:red_terracotta
setblock 471 255 476 minecraft:terracotta
fill 471 255 477 471 258 477 minecraft:red_terracotta
setblock 471 255 481 minecraft:terracotta
setblock 471 255 491 minecraft:terracotta
fill 471 255 492 471 258 492 minecraft:red_terracotta
setblock 471 255 496 minecraft:terracotta
fill 471 255 497 471 258 497 minecraft:red_terracotta
setblock 471 255 500 minecraft:red_terracotta
setblock 471 255 501 minecraft:terracotta
fill 471 255 502 471 258 502 minecraft:red_terracotta
setblock 472 255 465 minecraft:terracotta
setblock 472 255 466 minecraft:red_terracotta
setblock 472 255 470 minecraft:terracotta
fill 472 255 471 472 257 471 minecraft:red_terracotta
setblock 472 255 475 minecraft:terracotta
fill 472 255 476 472 257 476 minecraft:red_terracotta
setblock 472 255 491 minecraft:red_terracotta
setblock 472 255 495 minecraft:terracotta
fill 472 255 496 472 258 496 minecraft:red_terracotta
setblock 472 255 500 minecraft:terracotta
fill 472 255 501 472 258 501 minecraft:red_terracotta
setblock 473 255 464 minecraft:terracotta
setblock 473 255 494 minecraft:terracotta
fill 473 255 495 473 256 495 minecraft:red_terracotta
setblock 473 255 498 minecraft:red_terracotta
setblock 473 255 499 minecraft:terracotta
fill 473 255 500 473 257 500 minecraft:red_terracotta
setblock 473 255 504 minecraft:terracotta
setblock 474 255 464 minecraft:red_terracotta
setblock 474 255 503 minecraft:terracotta
fill 474 255 504 474 258 504 minecraft:red_terracotta
fill 475 255 464 475 266 464 minecraft:magma_block
setblock 478 255 504 minecraft:terracotta
fill 479 255 504 482 255 504 minecraft:red_terracotta
setblock 483 255 503 minecraft:red_terracotta
setblock 483 255 504 minecraft:terracotta
setblock 484 255 503 minecraft:terracotta
fill 484 255 504 484 258 504 minecraft:red_terracotta
setblock 485 255 464 minecraft:red_terracotta
fill 485 255 503 485 258 503 minecraft:red_terracotta
fill 486 255 502 487 257 502 minecraft:red_terracotta
fill 487 255 503 488 255 503 minecraft:red_terracotta
setblock 488 255 464 minecraft:terracotta
setblock 488 255 504 minecraft:terracotta
setblock 489 255 464 minecraft:red_terracotta
setblock 489 255 503 minecraft:terracotta
fill 489 255 504 489 258 504 minecraft:red_terracotta
setblock 490 255 503 minecraft:red_terracotta
setblock 503 255 464 minecraft:terracotta
fill 504 255 464 504 258 464 minecraft:red_terracotta
fill 505 255 504 507 255 504 minecraft:red_terracotta
setblock 506 255 466 minecraft:terracotta
setblock 507 255 465 minecraft:terracotta
fill 507 255 466 507 257 466 minecraft:red_terracotta
setblock 507 255 471 minecraft:red_terracotta
setblock 507 255 475 minecraft:terracotta
setblock 508 255 464 minecraft:terracotta
fill 508 255 465 508 258 465 minecraft:red_terracotta
setblock 508 255 468 minecraft:red_terracotta
setblock 508 255 469 minecraft:terracotta
fill 508 255 470 508 257 470 minecraft:red_terracotta
setblock 508 255 473 minecraft:red_terracotta
setblock 508 255 474 minecraft:terracotta
fill 508 255 475 508 258 475 minecraft:red_terracotta
setblock 508 255 478 minecraft:red_terracotta
setblock 508 255 504 minecraft:terracotta
fill 509 255 464 509 258 464 minecraft:red_terracotta
setblock 509 255 468 minecraft:terracotta
fill 509 255 469 509 258 469 minecraft:red_terracotta
setblock 509 255 473 minecraft:terracotta
fill 509 255 474 509 258 474 minecraft:red_terracotta
setblock 509 255 477 minecraft:red_terracotta
setblock 509 255 478 minecraft:terracotta
fill 509 255 479 509 257 480 minecraft:red_terracotta
setblock 509 255 493 minecraft:terracotta
setblock 509 255 494 minecraft:red_terracotta
setblock 509 255 497 minecraft:red_terracotta
setblock 509 255 503 minecraft:terracotta
fill 509 255 504 509 258 504 minecraft:red_terracotta
setblock 510 255 467 minecraft:terracotta
fill 510 255 468 510 258 468 minecraft:red_terracotta
setblock 510 255 472 minecraft:terracotta
fill 510 255 473 510 258 473 minecraft:red_terracotta
setblock 510 255 477 minecraft:terracotta
fill 510 255 478 510 258 478 minecraft:red_terracotta
setblock 510 255 482 minecraft:terracotta
setblock 510 255 492 minecraft:terracotta
fill 510 255 493 510 257 493 minecraft:red_terracotta
setblock 510 255 496 minecraft:red_terracotta
setblock 510 255 497 minecraft:terracotta
fill 510 255 498 510 255 501 minecraft:red_terracotta
setblock 510 255 502 minecraft:terracotta
fill 510 255 503 510 258 503 minecraft:red_terracotta
setblock 511 255 466 minecraft:terracotta
fill 511 255 467 511 258 467 minecraft:red_terracotta
setblock 511 255 471 minecraft:terracotta
fill 511 255 472 511 258 472 minecraft:red_terracotta
setblock 511 255 476 minecraft:terracotta
fill 511 255 477 511 258 477 minecraft:red_terracotta
setblock 511 255 481 minecraft:terracotta
fill 511 255 482 511 258 482 minecraft:red_terracotta
setblock 511 255 486 minecraft:terracotta
setblock 511 255 487 minecraft:red_terracotta
setblock 511 255 491 minecraft:terracotta
fill 511 255 492 511 257 492 minecraft:red_terracotta
setblock 511 255 496 minecraft:terracotta
fill 511 255 497 511 258 497 minecraft:red_terracotta
fill 511 255 499 511 255 500 minecraft:red_terracotta
setblock 511 255 501 minecraft:terracotta
fill 511 255 502 511 258 502 minecraft:red_terracotta
setblock 471 256 464 minecraft:red_terracotta
setblock 471 256 465 minecraft:terracotta
fill 471 256 466 471 258 466 minecraft:red_terracotta
setblock 471 256 470 minecraft:terracotta
fill 471 256 471 471 259 471 minecraft:red_terracotta
setblock 471 256 475 minecraft:terracotta
fill 471 256 476 471 259 476 minecraft:red_terracotta
setblock 471 256 479 minecraft:red_terracotta
setblock 471 256 480 minecraft:terracotta
setblock 471 256 490 minecraft:terracotta
fill 471 256 491 471 258 491 minecraft:red_terracotta
setblock 471 256 495 minecraft:terracotta
fill 471 256 496 471 259 496 minecraft:red_terracotta
setblock 471 256 500 minecraft:terracotta
fill 471 256 501 471 259 501 minecraft:red_terracotta
setblock 472 256 464 minecraft:terracotta
setblock 472 256 469 minecraft:terracotta
setblock 472 256 470 minecraft:red_terracotta
setblock 472 256 474 minecraft:terracotta
fill 472 256 475 472 257 475 minecraft:red_terracotta
setblock 472 256 494 minecraft:terracotta
fill 472 256 495 472 259 495 minecraft:red_terracotta
setblock 472 256 499 minecraft:terracotta
fill 472 256 500 472 259 500 minecraft:red_terracotta
setblock 472 256 503 minecraft:red_terracotta
setblock 472 256 504 minecraft:terracotta
fill 473 256 464 473 257 464 minecraft:red_terracotta
setblock 473 256 498 minecraft:terracotta
fill 473 256 499 473 258 499 minecraft:red_terracotta
setblock 473 256 503 minecraft:terracotta
fill 473 256 504 473 259 504 minecraft:red_terracotta
fill 474 256 503 474 257 503 minecraft:red_terracotta
setblock 476 256 504 minecraft:red_terracotta
setblock 477 256 504 minecraft:terracotta
fill 478 256 504 481 256 504 minecraft:red_terracotta
setblock 482 256 503 minecraft:red_terracotta
setblock 482 256 504 minecraft:terracotta
setblock 483 256 503 minecraft:terracotta
fill 483 256 504 483 259 504 minecraft:red_terracotta
setblock 484 256 502 minecraft:terracotta
fill 484 256 503 484 259 503 minecraft:red_terracotta
fill 485 256 502 485 259 502 minecraft:red_terracotta
setblock 487 256 464 minecraft:terracotta
setblock 487 256 503 minecraft:red_terracotta
setblock 487 256 504 minecraft:terracotta
setblock 488 256 464 minecraft:red_terracotta
setblock 488 256 503 minecraft:terracotta
fill 488 256 504 488 259 504 minecraft:red_terracotta
fill 489 256 503 489 257 503 minecraft:red_terracotta
fill 503 256 464 503 259 464 minecraft:red_terracotta
fill 504 256 465 504 257 465 minecraft:red_terracotta
fill 505 256 504 506 256 504 minecraft:red_terracotta
setblock 506 256 465 minecraft:terracotta
setblock 506 256 466 minecraft:red_terracotta
setblock 507 256 464 minecraft:terracotta
fill 507 256 465 507 259 465 minecraft:red_terracotta
fill 507 256 472 507 256 473 minecraft:red_terracotta
setblock 507 256 474 minecraft:terracotta
fill 507 256 475 507 256 476 minecraft:red_terracotta
setblock 507 256 503 minecraft:red_terracotta
setblock 507 256 504 minecraft:terracotta
fill 508 256 464 508 259 464 minecraft:red_terracotta
setblock 508 256 468 minecraft:terracotta
fill 508 256 469 508 257 469 minecraft:red_terracotta
setblock 508 256 473 minecraft:terracotta
fill 508 256 474 508 259 474 minecraft:red_terracotta
setblock 508 256 478 minecraft:terracotta
setblock 508 256 503 minecraft:terracotta
fill 508 256 504 508 259 504 minecraft:red_terracotta
setblock 509 256 467 minecraft:terracotta
fill 509 256 468 509 258 468 minecraft:red_terracotta
setblock 509 256 472 minecraft:terracotta
fill 509 256 473 509 259 473 minecraft:red_terracotta
setblock 509 256 477 minecraft:terracotta
fill 509 256 478 509 259 478 minecraft:red_terracotta
setblock 509 256 497 minecraft:terracotta
fill 509 256 498 510 257 498 minecraft:red_terracotta
fill 509 256 503 509 259 503 minecraft:red_terracotta
setblock 510 256 466 minecraft:terracotta
fill 510 256 467 510 259 467 minecraft:red_terracotta
setblock 510 256 471 minecraft:terracotta
fill 510 256 472 510 259 472 minecraft:red_terracotta
setblock 510 256 476 minecraft:terracotta
fill 510 256 477 510 259 477 minecraft:red_terracotta
setblock 510 256 481 minecraft:terracotta
setblock 510 256 491 minecraft:terracotta
setblock 510 256 492 minecraft:red_terracotta
setblock 510 256 496 minecraft:terracotta
fill 510 256 497 510 259 497 minecraft:red_terracotta
fill 510 256 499 510 256 500 minecraft:red_terracotta
setblock 510 256 501 minecraft:terracotta
fill 510 256 502 510 259 502 minecraft:red_terracotta
setblock 511 256 465 minecraft:terracotta
fill 511 256 466 511 259 466 minecraft:red_terracotta
setblock 511 256 470 minecraft:terracotta
fill 511 256 471 511 259 471 minecraft:red_terracotta
setblock 511 256 475 minecraft:terracotta
fill 511 256 476 511 259 476 minecraft:red_terracotta
setblock 511 256 480 minecraft:terracotta
fill 511 256 481 511 259 481 minecraft:red_terracotta
setblock 511 256 490 minecraft:terracotta
fill 511 256 491 511 257 491 minecraft:red_terracotta
setblock 511 256 495 minecraft:terracotta
fill 511 256 496 511 259 496 minecraft:red_terracotta
setblock 511 256 499 minecraft:red_terracotta
setblock 511 256 500 minecraft:terracotta
fill 511 256 501 511 259 501 minecraft:red_terracotta
setblock 471 257 464 minecraft:terracotta
fill 471 257 465 471 258 465 minecraft:red_terracotta
setblock 471 257 469 minecraft:terracotta
fill 471 257 470 471 258 470 minecraft:red_terracotta
setblock 471 257 474 minecraft:terracotta
fill 471 257 475 471 260 475 minecraft:red_terracotta
setblock 471 257 479 minecraft:terracotta
fill 471 257 480 471 258 480 minecraft:red_terracotta
setblock 471 257 490 minecraft:red_terracotta
setblock 471 257 494 minecraft:terracotta
fill 471 257 495 471 260 495 minecraft:red_terracotta
setblock 471 257 499 minecraft:terracotta
fill 471 257 500 471 260 500 minecraft:red_terracotta
setblock 471 257 504 minecraft:terracotta
fill 472 257 464 472 258 464 minecraft:red_terracotta
setblock 472 257 473 minecraft:terracotta
setblock 472 257 474 minecraft:red_terracotta
setblock 472 257 493 minecraft:terracotta
fill 472 257 494 472 258 494 minecraft:red_terracotta
setblock 472 257 498 minecraft:terracotta
fill 472 257 499 472 260 499 minecraft:red_terracotta
setblock 472 257 503 minecraft:terracotta
fill 472 257 504 472 260 504 minecraft:red_terracotta
setblock 473 257 497 minecraft:terracotta
fill 473 257 498 473 258 498 minecraft:red_terracotta
fill 473 257 503 473 259 503 minecraft:red_terracotta
setblock 476 257 504 minecraft:terracotta
fill 477 257 504 480 257 504 minecraft:red_terracotta
setblock 481 257 503 minecraft:red_terracotta
setblock 481 257 504 minecraft:terracotta
setblock 482 257 503 minecraft:terracotta
fill 482 257 504 482 260 504 minecraft:red_terracotta
setblock 483 257 502 minecraft:terracotta
fill 483 257 503 483 260 503 minecraft:red_terracotta
fill 484 257 502 484 260 502 minecraft:red_terracotta
setblock 486 257 504 minecraft:terracotta
setblock 487 257 503 minecraft:terracotta
fill 487 257 504 487 260 504 minecraft:red_terracotta
fill 488 257 503 488 259 503 minecraft:red_terracotta
fill 504 257 504 505 257 504 minecraft:red_terracotta
setblock 505 257 464 minecraft:red_terracotta
setblock 505 257 465 minecraft:terracotta
setblock 506 257 464 minecraft:terracotta
fill 506 257 465 506 260 465 minecraft:red_terracotta
setblock 506 257 503 minecraft:red_terracotta
setblock 506 257 504 minecraft:terracotta
fill 507 257 464 507 260 464 minecraft:red_terracotta
setblock 507 257 473 minecraft:terracotta
fill 507 257 474 507 257 475 minecraft:red_terracotta
setblock 507 257 503 minecraft:terracotta
fill 507 257 504 507 260 504 minecraft:red_terracotta
setblock 508 257 472 minecraft:terracotta
fill 508 257 473 508 258 473 minecraft:red_terracotta
setblock 508 257 476 minecraft:red_terracotta
setblock 508 257 477 minecraft:terracotta
fill 508 257 478 508 258 478 minecraft:red_terracotta
fill 508 257 503 508 260 503 minecraft:red_terracotta
setblock 509 257 466 minecraft:terracotta
setblock 509 257 467 minecraft:red_terracotta
setblock 509 257 471 minecraft:terracotta
fill 509 257 472 509 259 472 minecraft:red_terracotta
setblock 509 257 476 minecraft:terracotta
fill 509 257 477 509 260 477 minecraft:red_terracotta
setblock 509 257 497 minecraft:red_terracotta
setblock 510 257 465 minecraft:terracotta
fill 510 257 466 510 258 466 minecraft:red_terracotta
setblock 510 257 470 minecraft:terracotta
fill 510 257 471 510 260 471 minecraft:red_terracotta
setblock 510 257 475 minecraft:terracotta
fill 510 257 476 510 260 476 minecraft:red_terracotta
setblock 510 257 480 minecraft:terracotta
fill 510 257 481 510 258 481 minecraft:red_terracotta
setblock 510 257 495 minecraft:terracotta
fill 510 257 496 510 259 496 minecraft:red_terracotta
setblock 510 257 499 minecraft:red_terracotta
setblock 510 257 500 minecraft:terracotta
fill 510 257 501 510 260 501 minecraft:red_terracotta
setblock 511 257 464 minecraft:terracotta
fill 511 257 465 511 260 465 minecraft:red_terracotta
setblock 511 257 469 minecraft:terracotta
fill 511 257 470 511 260 470 minecraft:red_terracotta
setblock 511 257 474 minecraft:terracotta
fill 511 257 475 511 260 475 minecraft:red_terracotta
setblock 511 257 479 minecraft:terracotta
fill 511 257 480 511 260 480 minecraft:red_terracotta
setblock 511 257 494 minecraft:terracotta
fill 511 257 495 511 259 495 minecraft:red_terracotta
setblock 511 257 499 minecraft:terracotta
fill 511 257 500 511 260 500 minecraft:red_terracotta
setblock 511 257 504 minecraft:terracotta
fill 471 258 464 471 259 464 minecraft:red_terracotta
setblock 471 258 468 minecraft:terracotta
setblock 471 258 469 minecraft:red_terracotta
setblock 471 258 473 minecraft:terracotta
fill 471 258 474 471 259 474 minecraft:red_terracotta
setblock 471 258 478 minecraft:terracotta
fill 471 258 479 471 259 479 minecraft:red_terracotta
setblock 471 258 493 minecraft:terracotta
fill 471 258 494 471 260 494 minecraft:red_terracotta
setblock 471 258 498 minecraft:terracotta
fill 471 258 499 471 261 499 minecraft:red_terracotta
setblock 471 258 503 minecraft:terracotta
fill 471 258 504 471 261 504 minecraft:red_terracotta
setblock 472 258 497 minecraft:terracotta
fill 472 258 498 472 261 498 minecraft:red_terracotta
setblock 472 258 502 minecraft:terracotta
fill 472 258 503 472 261 503 minecraft:red_terracotta
setblock 475 258 504 minecraft:terracotta
fill 476 258 504 479 258 504 minecraft:red_terracotta
setblock 480 258 503 minecraft:red_terracotta
setblock 480 258 504 minecraft:terracotta
setblock 481 258 503 minecraft:terracotta
fill 481 258 504 481 261 504 minecraft:red_terracotta
fill 482 258 503 482 261 503 minecraft:red_terracotta
fill 483 258 502 483 261 502 minecraft:red_terracotta
setblock 485 258 504 minecraft:terracotta
setblock 486 258 502 minecraft:red_terracotta
setblock 486 258 503 minecraft:terracotta
fill 486 258 504 486 261 504 minecraft:red_terracotta
setblock 487 258 502 minecraft:terracotta
fill 487 258 503 487 261 503 minecraft:red_terracotta
setblock 490 258 504 minecraft:terracotta
fill 502 258 464 502 260 464 minecraft:red_terracotta
fill 503 258 504 504 258 504 minecraft:red_terracotta
setblock 504 258 465 minecraft:terracotta
setblock 505 258 464 minecraft:terracotta
fill 505 258 465 505 261 465 minecraft:red_terracotta
setblock 505 258 504 minecraft:terracotta
fill 506 258 464 506 261 464 minecraft:red_terracotta
setblock 506 258 503 minecraft:terracotta
fill 506 258 504 506 261 504 minecraft:red_terracotta
fill 507 258 503 507 261 503 minecraft:red_terracotta
setblock 508 258 471 minecraft:terracotta
setblock 508 258 472 minecraft:red_terracotta
setblock 508 258 476 minecraft:terracotta
setblock 508 258 477 minecraft:red_terracotta
setblock 509 258 465 minecraft:terracotta
setblock 509 258 470 minecraft:terracotta
fill 509 258 471 509 259 471 minecraft:red_terracotta
setblock 509 258 475 minecraft:terracotta
fill 509 258 476 509 260 476 minecraft:red_terracotta
setblock 509 258 479 minecraft:red_terracotta
setblock 510 258 464 minecraft:terracotta
setblock 510 258 465 minecraft:red_terracotta
setblock 510 258 469 minecraft:terracotta
fill 510 258 470 510 259 470 minecraft:red_terracotta
setblock 510 258 474 minecraft:terracotta
fill 510 258 475 510 261 475 minecraft:red_terracotta
setblock 510 258 479 minecraft:terracotta
fill 510 258 480 510 259 480 minecraft:red_terracotta
setblock 510 258 495 minecraft:red_terracotta
setblock 510 258 498 minecraft:red_terracotta
setblock 510 258 499 minecraft:terracotta
fill 510 258 500 510 261 500 minecraft:red_terracotta
setblock 510 258 504 minecraft:terracotta
fill 511 258 464 511 261 464 minecraft:red_terracotta
setblock 511 258 468 minecraft:terracotta
fill 511 258 469 511 260 469 minecraft:red_terracotta
setblock 511 258 473 minecraft:terracotta
fill 511 258 474 511 261 474 minecraft:red_terracotta
setblock 511 258 478 minecraft:terracotta
fill 511 258 479 511 261 479 minecraft:red_terracotta
setblock 511 258 493 minecraft:terracotta
fill 511 258 494 511 259 494 minecraft:red_terracotta
setblock 511 258 498 minecraft:terracotta
fill 511 258 499 511 261 499 minecraft:red_terracotta
setblock 511 258 503 minecraft:terracotta
fill 511 258 504 511 261 504 minecraft:red_terracotta
setblock 471 259 472 minecraft:terracotta
setblock 471 259 473 minecraft:red_terracotta
setblock 471 259 477 minecraft:terracotta
setblock 471 259 478 minecraft:red_terracotta
setblock 471 259 492 minecraft:terracotta
setblock 471 259 493 minecraft:red_terracotta
setblock 471 259 497 minecraft:terracotta
fill 471 259 498 471 262 498 minecraft:red_terracotta
setblock 471 259 502 minecraft:terracotta
fill 471 259 503 471 262 503 minecraft:red_terracotta
setblock 472 259 496 minecraft:terracotta
fill 472 259 497 472 261 497 minecraft:red_terracotta
setblock 472 259 501 minecraft:terracotta
fill 472 259 502 472 262 502 minecraft:red_terracotta
setblock 474 259 504 minecraft:terracotta
fill 475 259 504 478 259 504 minecraft:red_terracotta
setblock 479 259 504 minecraft:terracotta
setblock 480 259 503 minecraft:terracotta
fill 480 259 504 480 262 504 minecraft:red_terracotta
fill 481 259 503 481 262 503 minecraft:red_terracotta
fill 482 259 502 482 262 502 minecraft:red_terracotta
setblock 484 259 504 minecraft:terracotta
setblock 485 259 503 minecraft:terracotta
fill 485 259 504 485 262 504 minecraft:red_terracotta
setblock 486 259 502 minecraft:terracotta
fill 486 259 503 486 262 503 minecraft:red_terracotta
setblock 489 259 504 minecraft:terracotta
setblock 503 259 504 minecraft:red_terracotta
setblock 504 259 464 minecraft:terracotta
fill 504 259 465 504 262 465 minecraft:red_terracotta
setblock 504 259 504 minecraft:terracotta
fill 505 259 464 505 262 464 minecraft:red_terracotta
setblock 505 259 503 minecraft:terracotta
fill 505 259 504 505 262 504 minecraft:red_terracotta
fill 506 259 503 506 262 503 minecraft:red_terracotta
setblock 508 259 465 minecraft:terracotta
setblock 508 259 475 minecraft:terracotta
setblock 508 259 476 minecraft:red_terracotta
setblock 509 259 464 minecraft:terracotta
setblock 509 259 465 minecraft:red_terracotta
setblock 509 259 474 minecraft:terracotta
fill 509 259 475 509 260 475 minecraft:red_terracotta
setblock 509 259 479 minecraft:terracotta
setblock 509 259 504 minecraft:terracotta
fill 510 259 464 510 262 464 minecraft:red_terracotta
setblock 510 259 468 minecraft:terracotta
setblock 510 259 469 minecraft:red_terracotta
setblock 510 259 473 minecraft:terracotta
fill 510 259 474 510 261 474 minecraft:red_terracotta
setblock 510 259 478 minecraft:terracotta
fill 510 259 479 510 260 479 minecraft:red_terracotta
setblock 510 259 498 minecraft:terracotta
fill 510 259 499 510 260 499 minecraft:red_terracotta
setblock 510 259 503 minecraft:terracotta
fill 510 259 504 510 262 504 minecraft:red_terracotta
setblock 511 259 467 minecraft:terracotta
fill 511 259 468 511 260 468 minecraft:red_terracotta
setblock 511 259 472 minecraft:terracotta
fill 511 259 473 511 261 473 minecraft:red_terracotta
setblock 511 259 477 minecraft:terracotta
fill 511 259 478 511 262 478 minecraft:red_terracotta
setblock 511 259 497 minecraft:terracotta
fill 511 259 498 511 262 498 minecraft:red_terracotta
setblock 511 259 502 minecraft:terracotta
fill 511 259 503 511 262 503 minecraft:red_terracotta
setblock 471 260 476 minecraft:terracotta
setblock 471 260 477 minecraft:red_terracotta
setblock 471 260 496 minecraft:terracotta
fill 471 260 497 471 263 497 minecraft:red_terracotta
setblock 471 260 501 minecraft:terracotta
fill 471 260 502 471 263 502 minecraft:red_terracotta
setblock 472 260 496 minecraft:red_terracotta
setblock 472 260 500 minecraft:terracotta
fill 472 260 501 472 263 501 minecraft:red_terracotta
setblock 473 260 504 minecraft:terracotta
fill 474 260 504 477 260 504 minecraft:red_terracotta
setblock 478 260 504 minecraft:terracotta
setblock 479 260 503 minecraft:terracotta
fill 479 260 504 479 263 504 minecraft:red_terracotta
fill 480 260 503 480 263 503 minecraft:red_terracotta
setblock 483 260 504 minecraft:terracotta
setblock 484 260 503 minecraft:terracotta
fill 484 260 504 484 263 504 minecraft:red_terracotta
setblock 485 260 502 minecraft:terracotta
fill 485 260 503 485 263 503 minecraft:red_terracotta
setblock 488 260 504 minecraft:terracotta
setblock 489 260 504 minecraft:red_terracotta
setblock 502 260 504 minecraft:red_terracotta
setblock 503 260 464 minecraft:terracotta
setblock 503 260 504 minecraft:terracotta
fill 504 260 464 504 263 464 minecraft:red_terracotta
setblock 504 260 503 minecraft:terracotta
fill 504 260 504 504 263 504 minecraft:red_terracotta
fill 505 260 503 505 263 503 minecraft:red_terracotta
setblock 507 260 465 minecraft:terracotta
setblock 508 260 464 minecraft:terracotta
setblock 508 260 465 minecraft:red_terracotta
setblock 508 260 504 minecraft:terracotta
fill 509 260 464 509 263 464 minecraft:red_terracotta
setblock 509 260 474 minecraft:red_terracotta
setblock 509 260 503 minecraft:terracotta
fill 509 260 504 509 263 504 minecraft:red_terracotta
setblock 510 260 472 minecraft:terracotta
setblock 510 260 473 minecraft:red_terracotta
setblock 510 260 477 minecraft:terracotta
fill 510 260 478 510 261 478 minecraft:red_terracotta
setblock 510 260 498 minecraft:red_terracotta
setblock 510 260 502 minecraft:terracotta
setblock 510 260 503 minecraft:red_terracotta
setblock 511 260 466 minecraft:terracotta
setblock 511 260 467 minecraft:red_terracotta
setblock 511 260 471 minecraft:terracotta
fill 511 260 472 511 261 472 minecraft:red_terracotta
setblock 511 260 476 minecraft:terracotta
fill 511 260 477 511 262 477 minecraft:red_terracotta
setblock 511 260 481 minecraft:terracotta
setblock 511 260 496 minecraft:terracotta
fill 511 260 497 511 261 497 minecraft:red_terracotta
setblock 511 260 501 minecraft:terracotta
fill 511 260 502 511 263 502 minecraft:red_terracotta
setblock 471 261 495 minecraft:terracotta
fill 471 261 496 471 263 496 minecraft:red_terracotta
setblock 471 261 500 minecraft:terracotta
fill 471 261 501 471 264 501 minecraft:red_terracotta
setblock 472 261 499 minecraft:terracotta
fill 472 261 500 472 264 500 minecraft:red_terracotta
setblock 472 261 504 minecraft:terracotta
setblock 473 261 466 minecraft:light[level=14]
setblock 473 261 474 minecraft:light[level=14]
setblock 473 261 482 minecraft:light[level=14]
setblock 473 261 490 minecraft:light[level=14]
setblock 473 261 498 minecraft:light[level=14]
fill 473 261 504 476 261 504 minecraft:red_terracotta
setblock 477 261 504 minecraft:terracotta
fill 478 261 504 478 264 504 minecraft:red_terracotta
fill 479 261 503 479 264 503 minecraft:red_terracotta
setblock 481 261 466 minecraft:light[level=14]
setblock 481 261 474 minecraft:light[level=14]
setblock 481 261 482 minecraft:light[level=14]
setblock 481 261 490 minecraft:light[level=14]
setblock 481 261 498 minecraft:light[level=14]
setblock 482 261 504 minecraft:terracotta
setblock 483 261 503 minecraft:terracotta
fill 483 261 504 483 264 504 minecraft:red_terracotta
setblock 484 261 502 minecraft:terracotta
fill 484 261 503 484 264 503 minecraft:red_terracotta
setblock 485 261 502 minecraft:red_terracotta
setblock 487 261 504 minecraft:terracotta
fill 488 261 504 488 264 504 minecraft:red_terracotta
setblock 489 261 466 minecraft:light[level=14]
setblock 489 261 474 minecraft:light[level=14]
setblock 489 261 482 minecraft:light[level=14]
setblock 489 261 490 minecraft:light[level=14]
setblock 489 261 498 minecraft:light[level=14]
setblock 497 261 466 minecraft:light[level=14]
setblock 497 261 474 minecraft:light[level=14]
setblock 497 261 482 minecraft:light[level=14]
setblock 497 261 490 minecraft:light[level=14]
setblock 497 261 498 minecraft:light[level=14]
setblock 501 261 464 minecraft:red_terracotta
setblock 501 261 504 minecraft:red_terracotta
setblock 502 261 464 minecraft:terracotta
setblock 502 261 504 minecraft:terracotta
fill 503 261 464 503 264 464 minecraft:red_terracotta
fill 503 261 504 503 264 504 minecraft:red_terracotta
fill 504 261 503 504 264 503 minecraft:red_terracotta
setblock 505 261 466 minecraft:light[level=14]
setblock 505 261 474 minecraft:light[level=14]
setblock 505 261 482 minecraft:light[level=14]
setblock 505 261 490 minecraft:light[level=14]
setblock 505 261 498 minecraft:light[level=14]
setblock 506 261 465 minecraft:terracotta
setblock 507 261 464 minecraft:terracotta
fill 507 261 465 507 264 465 minecraft:red_terracotta
setblock 507 261 504 minecraft:terracotta
fill 508 261 464 508 264 464 minecraft:red_terracotta
setblock 508 261 503 minecraft:terracotta
fill 508 261 504 508 264 504 minecraft:red_terracotta
fill 509 261 503 509 264 503 minecraft:red_terracotta
setblock 510 261 476 minecraft:terracotta
setblock 510 261 477 minecraft:red_terracotta
setblock 510 261 501 minecraft:terracotta
fill 510 261 502 510 264 502 minecraft:red_terracotta
setblock 511 261 471 minecraft:red_terracotta
setblock 511 261 475 minecraft:terracotta
fill 511 261 476 511 262 476 minecraft:red_terracotta
setblock 511 261 480 minecraft:terracotta
setblock 511 261 500 minecraft:terracotta
fill 511 261 501 511 264 501 minecraft:red_terracotta
setblock 471 262 495 minecraft:red_terracotta
setblock 471 262 499 minecraft:terracotta
fill 471 262 500 471 265 500 minecraft:red_terracotta
setblock 471 262 504 minecraft:terracotta
setblock 472 262 498 minecraft:terracotta
fill 472 262 499 472 263 499 minecraft:red_terracotta
fill 472 262 504 475 262 504 minecraft:red_terracotta
setblock 476 262 504 minecraft:terracotta
fill 477 262 504 477 265 504 minecraft:red_terracotta
fill 478 262 503 478 265 503 minecraft:red_terracotta
fill 481 262 502 481 263 502 minecraft:red_terracotta
setblock 481 262 504 minecraft:terracotta
setblock 482 262 503 minecraft:terracotta
fill 482 262 504 482 265 504 minecraft:red_terracotta
setblock 483 262 502 minecraft:terracotta
fill 483 262 503 483 265 503 minecraft:red_terracotta
fill 484 262 502 484 265 502 minecraft:red_terracotta
setblock 486 262 504 minecraft:terracotta
fill 487 262 504 487 265 504 minecraft:red_terracotta
setblock 500 262 464 minecraft:red_terracotta
setblock 501 262 464 minecraft:terracotta
setblock 501 262 504 minecraft:terracotta
fill 502 262 464 502 265 464 minecraft:red_terracotta
fill 502 262 504 502 265 504 minecraft:red_terracotta
fill 503 262 465 503 263 465 minecraft:red_terracotta
fill 503 262 503 503 265 503 minecraft:red_terracotta
setblock 505 262 465 minecraft:terracotta
setblock 506 262 464 minecraft:terracotta
fill 506 262 465 506 265 465 minecraft:red_terracotta
setblock 506 262 504 minecraft:terracotta
fill 507 262 464 507 265 464 minecraft:red_terracotta
setblock 507 262 503 minecraft:terracotta
fill 507 262 504 507 265 504 minecraft:red_terracotta
fill 508 262 503 508 265 503 minecraft:red_terracotta
setblock 510 262 501 minecraft:red_terracotta
setblock 511 262 464 minecraft:terracotta
setblock 511 262 475 minecraft:red_terracotta
setblock 511 262 479 minecraft:terracotta
setblock 511 262 499 minecraft:terracotta
fill 511 262 500 511 265 500 minecraft:red_terracotta
setblock 511 262 504 minecraft:terracotta
setblock 471 263 498 minecraft:terracotta
fill 471 263 499 471 266 499 minecraft:red_terracotta
setblock 471 263 503 minecraft:terracotta
fill 471 263 504 474 263 504 minecraft:red_terracotta
setblock 472 263 502 minecraft:terracotta
fill 472 263 503 472 266 503 minecraft:red_terracotta
setblock 475 263 504 minecraft:terracotta
setblock 476 263 503 minecraft:terracotta
fill 476 263 504 476 266 504 minecraft:red_terracotta
fill 477 263 503 477 266 503 minecraft:red_terracotta
fill 480 263 502 480 264 502 minecraft:red_terracotta
setblock 480 263 504 minecraft:terracotta
setblock 481 263 503 minecraft:terracotta
fill 481 263 504 481 266 504 minecraft:red_terracotta
setblock 482 263 502 minecraft:terracotta
fill 482 263 503 482 266 503 minecraft:red_terracotta
fill 483 263 502 483 266 502 minecraft:red_terracotta
setblock 485 263 504 minecraft:terracotta
setblock 486 263 503 minecraft:terracotta
fill 486 263 504 486 266 504 minecraft:red_terracotta
setblock 499 263 464 minecraft:red_terracotta
setblock 500 263 464 minecraft:terracotta
setblock 500 263 504 minecraft:terracotta
fill 501 263 464 501 266 464 minecraft:red_terracotta
fill 501 263 504 501 266 504 minecraft:red_terracotta
fill 502 263 465 502 264 465 minecraft:red_terracotta
fill 502 263 503 502 266 503 minecraft:red_terracotta
setblock 504 263 465 minecraft:terracotta
setblock 505 263 464 minecraft:terracotta
fill 505 263 465 505 266 465 minecraft:red_terracotta
setblock 505 263 504 minecraft:terracotta
fill 506 263 464 506 266 464 minecraft:red_terracotta
setblock 506 263 503 minecraft:terracotta
fill 506 263 504 506 266 504 minecraft:red_terracotta
fill 507 263 503 507 266 503 minecraft:red_terracotta
setblock 510 263 464 minecraft:terracotta
setblock 510 263 503 minecraft:red_terracotta
setblock 510 263 504 minecraft:terracotta
fill 511 263 464 511 266 464 minecraft:red_terracotta
setblock 511 263 498 minecraft:terracotta
fill 511 263 499 511 266 499 minecraft:red_terracotta
setblock 511 263 503 minecraft:terracotta
fill 511 263 504 511 266 504 minecraft:red_terracotta
setblock 471 264 497 minecraft:terracotta
fill 471 264 498 471 267 498 minecraft:red_terracotta
setblock 471 264 502 minecraft:terracotta
fill 471 264 503 471 266 504 minecraft:red_terracotta
setblock 472 264 501 minecraft:terracotta
fill 472 264 502 472 267 502 minecraft:red_terracotta
fill 472 264 504 473 264 504 minecraft:red_terracotta
fill 473 264 503 474 264 503 minecraft:red_terracotta
setblock 474 264 504 minecraft:terracotta
setblock 475 264 503 minecraft:terracotta
fill 475 264 504 475 267 504 minecraft:red_terracotta
fill 476 264 503 476 267 503 minecraft:red_terracotta
fill 479 264 502 479 265 502 minecraft:red_terracotta
setblock 479 264 504 minecraft:terracotta
setblock 480 264 503 minecraft:terracotta
fill 480 264 504 480 267 504 minecraft:red_terracotta
setblock 481 264 502 minecraft:terracotta
fill 481 264 503 481 267 503 minecraft:red_terracotta
fill 482 264 464 483 264 464 minecraft:red_terracotta
fill 482 264 502 482 267 502 minecraft:red_terracotta
setblock 484 264 464 minecraft:terracotta
setblock 484 264 504 minecraft:terracotta
setblock 485 264 503 minecraft:terracotta
fill 485 264 504 485 267 504 minecraft:red_terracotta
fill 486 264 503 486 267 503 minecraft:red_terracotta
setblock 498 264 464 minecraft:red_terracotta
setblock 498 264 504 minecraft:red_terracotta
setblock 499 264 464 minecraft:terracotta
setblock 499 264 504 minecraft:terracotta
fill 500 264 464 500 267 464 minecraft:red_terracotta
fill 500 264 504 500 267 504 minecraft:red_terracotta
fill 501 264 465 501 265 465 minecraft:red_terracotta
fill 501 264 503 501 267 503 minecraft:red_terracotta
setblock 503 264 465 minecraft:terracotta
setblock 504 264 464 minecraft:terracotta
fill 504 264 465 504 267 465 minecraft:red_terracotta
setblock 504 264 504 minecraft:terracotta
fill 505 264 464 505 267 464 minecraft:red_terracotta
setblock 505 264 503 minecraft:terracotta
fill 505 264 504 505 267 504 minecraft:red_terracotta
fill 506 264 503 506 267 503 minecraft:red_terracotta
setblock 509 264 464 minecraft:terracotta
setblock 509 264 504 minecraft:terracotta
fill 510 264 464 510 267 464 minecraft:red_terracotta
setblock 510 264 503 minecraft:terracotta
fill 510 264 504 510 267 504 minecraft:red_terracotta
setblock 511 264 502 minecraft:terracotta
fill 511 264 503 511 267 503 minecraft:red_terracotta
fill 471 265 497 471 268 497 minecraft:red_terracotta
setblock 471 265 501 minecraft:terracotta
fill 471 265 502 471 268 502 minecraft:red_terracotta
setblock 472 265 500 minecraft:terracotta
fill 472 265 501 472 268 501 minecraft:red_terracotta
setblock 472 265 504 minecraft:red_terracotta
setblock 473 265 503 minecraft:red_terracotta
setblock 473 265 504 minecraft:terracotta
setblock 474 265 503 minecraft:terracotta
fill 474 265 504 474 268 504 minecraft:red_terracotta
fill 475 265 503 475 268 503 minecraft:red_terracotta
fill 478 265 502 478 266 502 minecraft:red_terracotta
setblock 478 265 504 minecraft:terracotta
fill 479 265 464 482 265 464 minecraft:red_terracotta
setblock 479 265 503 minecraft:terracotta
fill 479 265 504 479 268 504 minecraft:red_terracotta
setblock 480 265 502 minecraft:terracotta
fill 480 265 503 480 268 503 minecraft:red_terracotta
fill 481 265 502 481 268 502 minecraft:red_terracotta
setblock 483 265 464 minecraft:terracotta
setblock 483 265 504 minecraft:terracotta
fill 484 265 464 485 267 464 minecraft:red_terracotta
setblock 484 265 503 minecraft:terracotta
fill 484 265 504 484 268 504 minecraft:red_terracotta
fill 485 265 503 485 268 503 minecraft:red_terracotta
setblock 488 265 504 minecraft:terracotta
setblock 497 265 464 minecraft:red_terracotta
fill 497 265 497 498 266 499 minecraft:orange_concrete
setblock 497 265 504 minecraft:red_terracotta
setblock 498 265 464 minecraft:terracotta
setblock 498 265 504 minecraft:terracotta
fill 499 265 464 499 267 465 minecraft:red_terracotta
setblock 499 265 503 minecraft:terracotta
fill 499 265 504 499 268 504 minecraft:red_terracotta
fill 500 265 465 500 266 465 minecraft:red_terracotta
fill 500 265 503 500 268 503 minecraft:red_terracotta
setblock 502 265 465 minecraft:terracotta
setblock 503 265 464 minecraft:terracotta
fill 503 265 465 503 268 465 minecraft:red_terracotta
fill 503 265 502 504 265 502 minecraft:red_terracotta
setblock 503 265 504 minecraft:terracotta
fill 504 265 464 504 268 464 minecraft:red_terracotta
setblock 504 265 503 minecraft:terracotta
fill 504 265 504 504 268 504 minecraft:red_terracotta
setblock 505 265 502 minecraft:terracotta
fill 505 265 503 505 268 503 minecraft:red_terracotta
setblock 507 265 465 minecraft:terracotta
setblock 508 265 464 minecraft:terracotta
fill 508 265 465 508 268 465 minecraft:red_terracotta
setblock 508 265 504 minecraft:terracotta
fill 509 265 464 509 268 464 minecraft:red_terracotta
setblock 509 265 503 minecraft:terracotta
fill 509 265 504 509 268 504 minecraft:red_terracotta
setblock 510 265 501 minecraft:red_terracotta
setblock 510 265 502 minecraft:terracotta
fill 510 265 503 510 268 503 minecraft:red_terracotta
setblock 511 265 465 minecraft:red_terracotta
setblock 511 265 501 minecraft:terracotta
fill 511 265 502 511 268 502 minecraft:red_terracotta
setblock 471 266 500 minecraft:terracotta
fill 471 266 501 471 269 501 minecraft:red_terracotta
fill 472 266 500 472 269 500 minecraft:red_terracotta
setblock 472 266 504 minecraft:terracotta
setblock 473 266 503 minecraft:terracotta
fill 473 266 504 473 269 504 minecraft:red_terracotta
fill 474 266 503 474 269 503 minecraft:red_terracotta
fill 476 266 502 477 267 502 minecraft:red_terracotta
setblock 477 266 464 minecraft:terracotta
setblock 477 266 504 minecraft:terracotta
fill 478 266 464 481 266 464 minecraft:red_terracotta
setblock 478 266 503 minecraft:terracotta
fill 478 266 504 478 269 504 minecraft:red_terracotta
setblock 479 266 502 minecraft:terracotta
fill 479 266 503 479 269 503 minecraft:red_terracotta
fill 480 266 502 480 269 502 minecraft:red_terracotta
setblock 482 266 464 minecraft:terracotta
setblock 482 266 504 minecraft:terracotta
fill 483 266 464 483 269 464 minecraft:red_terracotta
setblock 483 266 503 minecraft:terracotta
fill 483 266 504 483 269 504 minecraft:red_terracotta
setblock 484 266 502 minecraft:terracotta
fill 484 266 503 484 269 503 minecraft:red_terracotta
setblock 486 266 464 minecraft:red_terracotta
setblock 487 266 504 minecraft:terracotta
fill 488 266 504 488 269 504 minecraft:red_terracotta
fill 495 266 464 496 266 464 minecraft:red_terracotta
setblock 496 266 504 minecraft:red_terracotta
setblock 497 266 464 minecraft:terracotta
setblock 497 266 504 minecraft:terracotta
fill 498 266 464 498 268 465 minecraft:red_terracotta
setblock 498 266 503 minecraft:terracotta
fill 498 266 504 498 269 504 minecraft:red_terracotta
fill 499 266 503 499 269 503 minecraft:red_terracotta
setblock 500 266 466 minecraft:terracotta
setblock 501 266 465 minecraft:terracotta
fill 501 266 466 504 266 466 minecraft:red_terracotta
fill 501 266 502 503 266 502 minecraft:red_terracotta
setblock 502 266 464 minecraft:terracotta
fill 502 266 465 502 269 465 minecraft:red_terracotta
setblock 502 266 504 minecraft:terracotta
fill 503 266 464 503 269 464 minecraft:red_terracotta
setblock 503 266 503 minecraft:terracotta
fill 503 266 504 503 269 504 minecraft:red_terracotta
setblock 504 266 502 minecraft:terracotta
fill 504 266 503 504 269 503 minecraft:red_terracotta
setblock 505 266 466 minecraft:terracotta
fill 505 266 502 506 268 502 minecraft:red_terracotta
setblock 506 266 465 minecraft:terracotta
setblock 507 266 464 minecraft:terracotta
fill 507 266 465 507 269 465 minecraft:red_terracotta
setblock 507 266 504 minecraft:terracotta
fill 508 266 464 508 269 464 minecraft:red_terracotta
setblock 508 266 503 minecraft:terracotta
fill 508 266 504 508 269 504 minecraft:red_terracotta
fill 509 266 465 509 267 465 minecraft:red_terracotta
fill 509 266 503 509 269 503 minecraft:red_terracotta
setblock 510 266 501 minecraft:terracotta
fill 510 266 502 510 269 502 minecraft:red_terracotta
setblock 511 266 465 minecraft:terracotta
fill 511 266 466 511 269 466 minecraft:red_terracotta
setblock 511 266 500 minecraft:terracotta
fill 511 266 501 511 269 501 minecraft:red_terracotta
setblock 471 267 464 minecraft:terracotta
fill 471 267 482 471 267 483 minecraft:red_terracotta
setblock 471 267 484 minecraft:terracotta
fill 471 267 485 471 270 485 minecraft:red_terracotta
setblock 471 267 499 minecraft:terracotta
fill 471 267 500 471 270 500 minecraft:red_terracotta
setblock 471 267 503 minecraft:red_terracotta
setblock 471 267 504 minecraft:terracotta
fill 472 267 464 475 267 464 minecraft:red_terracotta
fill 472 267 499 472 269 499 minecraft:red_terracotta
setblock 472 267 503 minecraft:terracotta
fill 472 267 504 472 270 504 minecraft:red_terracotta
fill 473 267 503 473 270 503 minecraft:red_terracotta
fill 475 267 502 475 269 502 minecraft:red_terracotta
setblock 476 267 464 minecraft:terracotta
setblock 476 267 504 minecraft:terracotta
fill 477 267 464 480 267 464 minecraft:red_terracotta
setblock 477 267 503 minecraft:terracotta
fill 477 267 504 477 270 504 minecraft:red_terracotta
setblock 478 267 502 minecraft:terracotta
fill 478 267 503 478 270 503 minecraft:red_terracotta
fill 479 267 502 479 270 502 minecraft:red_terracotta
setblock 481 267 464 minecraft:terracotta
fill 481 267 465 482 269 465 minecraft:red_terracotta
setblock 481 267 504 minecraft:terracotta
fill 482 267 464 482 270 464 minecraft:red_terracotta
setblock 482 267 503 minecraft:terracotta
fill 482 267 504 482 270 504 minecraft:red_terracotta
setblock 483 267 502 minecraft:terracotta
fill 483 267 503 483 270 503 minecraft:red_terracotta
setblock 484 267 502 minecraft:red_terracotta
setblock 486 267 464 minecraft:terracotta
setblock 486 267 504 minecraft:terracotta
fill 487 267 464 488 269 464 minecraft:red_terracotta
fill 487 267 504 487 270 504 minecraft:red_terracotta
fill 489 267 504 489 268 504 minecraft:red_terracotta
fill 493 267 464 495 267 464 minecraft:red_terracotta
fill 494 267 504 495 267 504 minecraft:red_terracotta
setblock 496 267 464 minecraft:terracotta
fill 496 267 465 497 269 465 minecraft:red_terracotta
setblock 496 267 504 minecraft:terracotta
fill 497 267 464 497 270 464 minecraft:red_terracotta
setblock 497 267 503 minecraft:terracotta
fill 497 267 504 497 270 504 minecraft:red_terracotta
fill 498 267 503 498 270 503 minecraft:red_terracotta
setblock 499 267 466 minecraft:terracotta
setblock 500 267 465 minecraft:terracotta
fill 500 267 466 503 267 466 minecraft:red_terracotta
fill 500 267 502 502 267 502 minecraft:red_terracotta
setblock 501 267 464 minecraft:terracotta
fill 501 267 465 501 270 465 minecraft:red_terracotta
setblock 501 267 504 minecraft:terracotta
fill 502 267 464 502 270 464 minecraft:red_terracotta
setblock 502 267 503 minecraft:terracotta
fill 502 267 504 502 270 504 minecraft:red_terracotta
setblock 503 267 502 minecraft:terracotta
fill 503 267 503 503 270 503 minecraft:red_terracotta
setblock 504 267 466 minecraft:terracotta
fill 504 267 502 504 270 502 minecraft:red_terracotta
setblock 505 267 465 minecraft:terracotta
fill 505 267 466 506 269 466 minecraft:red_terracotta
setblock 506 267 464 minecraft:terracotta
fill 506 267 465 506 270 465 minecraft:red_terracotta
setblock 506 267 504 minecraft:terracotta
fill 507 267 464 507 270 464 minecraft:red_terracotta
setblock 507 267 503 minecraft:terracotta
fill 507 267 504 507 270 504 minecraft:red_terracotta
fill 508 267 503 508 270 503 minecraft:red_terracotta
setblock 510 267 465 minecraft:terracotta
fill 510 267 501 510 269 501 minecraft:red_terracotta
setblock 511 267 464 minecraft:terracotta
fill 511 267 465 511 270 465 minecraft:red_terracotta
setblock 511 267 499 minecraft:terracotta
fill 511 267 500 511 270 500 minecraft:red_terracotta
setblock 511 267 504 minecraft:terracotta
fill 471 268 464 471 270 465 minecraft:red_terracotta
fill 471 268 481 471 268 482 minecraft:red_terracotta
setblock 471 268 483 minecraft:terracotta
fill 471 268 484 471 271 484 minecraft:red_terracotta
fill 471 268 486 471 268 487 minecraft:red_terracotta
setblock 471 268 488 minecraft:terracotta
fill 471 268 496 471 269 496 minecraft:red_terracotta
setblock 471 268 498 minecraft:terracotta
fill 471 268 499 471 271 499 minecraft:red_terracotta
setblock 471 268 503 minecraft:terracotta
fill 471 268 504 471 271 504 minecraft:red_terracotta
fill 472 268 464 474 268 464 minecraft:red_terracotta
setblock 472 268 502 minecraft:terracotta
fill 472 268 503 472 271 503 minecraft:red_terracotta
fill 474 268 502 474 270 502 minecraft:red_terracotta
setblock 475 268 464 minecraft:terracotta
setblock 475 268 504 minecraft:terracotta
fill 476 268 464 479 268 464 minecraft:red_terracotta
setblock 476 268 502 minecraft:red_terracotta
setblock 476 268 503 minecraft:terracotta
fill 476 268 504 476 271 504 minecraft:red_terracotta
setblock 477 268 502 minecraft:terracotta
fill 477 268 503 477 271 503 minecraft:red_terracotta
setblock 478 268 465 minecraft:red_terracotta
fill 478 268 502 478 271 502 minecraft:red_terracotta
setblock 479 268 465 minecraft:terracotta
setblock 480 268 464 minecraft:terracotta
fill 480 268 465 480 271 465 minecraft:red_terracotta
setblock 480 268 504 minecraft:terracotta
fill 481 268 464 481 271 464 minecraft:red_terracotta
setblock 481 268 503 minecraft:terracotta
fill 481 268 504 481 271 504 minecraft:red_terracotta
setblock 482 268 502 minecraft:terracotta
fill 482 268 503 482 271 503 minecraft:red_terracotta
setblock 483 268 465 minecraft:red_terracotta
setblock 483 268 502 minecraft:red_terracotta
setblock 484 268 464 minecraft:red_terracotta
setblock 484 268 465 minecraft:terracotta
setblock 485 268 464 minecraft:terracotta
setblock 485 268 504 minecraft:terracotta
fill 486 268 464 486 271 464 minecraft:red_terracotta
setblock 486 268 503 minecraft:terracotta
fill 486 268 504 486 271 504 minecraft:red_terracotta
setblock 489 268 464 minecraft:red_terracotta
setblock 490 268 464 minecraft:terracotta
fill 491 268 464 494 268 464 minecraft:red_terracotta
fill 493 268 504 494 268 504 minecraft:red_terracotta
setblock 494 268 465 minecraft:terracotta
setblock 495 268 464 minecraft:terracotta
fill 495 268 465 495 271 465 minecraft:red_terracotta
setblock 495 268 504 minecraft:terracotta
fill 496 268 464 496 271 464 minecraft:red_terracotta
setblock 496 268 503 minecraft:terracotta
fill 496 268 504 496 271 504 minecraft:red_terracotta
setblock 497 268 466 minecraft:red_terracotta
fill 497 268 503 497 271 503 minecraft:red_terracotta
setblock 498 268 466 minecraft:terracotta
setblock 499 268 464 minecraft:red_terracotta
setblock 499 268 465 minecraft:terracotta
fill 499 268 466 502 268 466 minecraft:red_terracotta
fill 499 268 502 501 268 502 minecraft:red_terracotta
setblock 500 268 464 minecraft:terracotta
fill 500 268 465 500 271 465 minecraft:red_terracotta
setblock 500 268 504 minecraft:terracotta
fill 501 268 464 501 271 464 minecraft:red_terracotta
setblock 501 268 467 minecraft:red_terracotta
setblock 501 268 503 minecraft:terracotta
fill 501 268 504 501 271 504 minecraft:red_terracotta
setblock 502 268 467 minecraft:terracotta
setblock 502 268 502 minecraft:terracotta
fill 502 268 503 502 271 503 minecraft:red_terracotta
setblock 503 268 466 minecraft:terracotta
fill 503 268 502 503 270 502 minecraft:red_terracotta
setblock 504 268 465 minecraft:terracotta
fill 504 268 466 504 271 466 minecraft:red_terracotta
setblock 505 268 464 minecraft:terracotta
fill 505 268 465 505 271 465 minecraft:red_terracotta
setblock 505 268 504 minecraft:terracotta
fill 506 268 464 506 271 464 minecraft:red_terracotta
setblock 506 268 503 minecraft:terracotta
fill 506 268 504 506 271 504 minecraft:red_terracotta
fill 507 268 503 507 271 503 minecraft:red_terracotta
setblock 509 268 465 minecraft:terracotta
setblock 510 268 464 minecraft:terracotta
fill 510 268 465 510 271 465 minecraft:red_terracotta
setblock 510 268 504 minecraft:terracotta
fill 511 268 464 511 271 464 minecraft:red_terracotta
setblock 511 268 467 minecraft:red_terracotta
fill 511 268 499 511 271 499 minecraft:red_terracotta
setblock 511 268 503 minecraft:terracotta
fill 511 268 504 511 271 504 minecraft:red_terracotta
setblock 471 269 481 minecraft:red_terracotta
setblock 471 269 482 minecraft:terracotta
fill 471 269 483 471 272 483 minecraft:red_terracotta
setblock 471 269 486 minecraft:red_terracotta
setblock 471 269 487 minecraft:terracotta
fill 471 269 488 471 269 491 minecraft:red_terracotta
setblock 471 269 497 minecraft:terracotta
fill 471 269 498 471 272 498 minecraft:red_terracotta
setblock 471 269 502 minecraft:terracotta
fill 471 269 503 471 272 503 minecraft:red_terracotta
fill 472 269 464 473 269 464 minecraft:red_terracotta
fill 472 269 484 472 269 485 minecraft:red_terracotta
setblock 472 269 486 minecraft:terracotta
fill 472 269 487 472 272 487 minecraft:red_terracotta
setblock 472 269 501 minecraft:terracotta
fill 472 269 502 472 272 502 minecraft:red_terracotta
setblock 473 269 466 minecraft:light[level=14]
setblock 473 269 474 minecraft:light[level=14]
setblock 473 269 482 minecraft:light[level=14]
setblock 473 269 490 minecraft:light[level=14]
setblock 473 269 498 minecraft:light[level=14]
setblock 474 269 464 minecraft:terracotta
setblock 474 269 504 minecraft:terracotta
fill 475 269 464 478 269 464 minecraft:red_terracotta
setblock 475 269 503 minecraft:terracotta
fill 475 269 504 475 272 504 minecraft:red_terracotta
fill 476 269 465 477 269 465 minecraft:red_terracotta
setblock 476 269 502 minecraft:terracotta
fill 476 269 503 476 272 503 minecraft:red_terracotta
fill 477 269 502 477 271 502 minecraft:red_terracotta
setblock 478 269 465 minecraft:terracotta
setblock 479 269 464 minecraft:terracotta
fill 479 269 465 479 272 465 minecraft:red_terracotta
setblock 479 269 504 minecraft:terracotta
fill 480 269 464 480 272 464 minecraft:red_terracotta
setblock 480 269 503 minecraft:terracotta
fill 480 269 504 480 272 504 minecraft:red_terracotta
setblock 481 269 466 minecraft:light[level=14]
setblock 481 269 474 minecraft:light[level=14]
setblock 481 269 482 minecraft:light[level=14]
setblock 481 269 490 minecraft:light[level=14]
setblock 481 269 498 minecraft:light[level=14]
setblock 481 269 502 minecraft:terracotta
fill 481 269 503 481 272 503 minecraft:red_terracotta
setblock 482 269 502 minecraft:red_terracotta
setblock 483 269 465 minecraft:terracotta
setblock 484 269 464 minecraft:terracotta
fill 484 269 465 485 271 465 minecraft:red_terracotta
setblock 484 269 504 minecraft:terracotta
fill 485 269 464 485 272 464 minecraft:red_terracotta
setblock 485 269 503 minecraft:terracotta
fill 485 269 504 485 272 504 minecraft:red_terracotta
setblock 489 269 464 minecraft:terracotta
setblock 489 269 466 minecraft:light[level=14]
setblock 489 269 474 minecraft:light[level=14]
setblock 489 269 482 minecraft:light[level=14]
setblock 489 269 490 minecraft:light[level=14]
setblock 489 269 498 minecraft:light[level=14]
setblock 489 269 504 minecraft:terracotta
fill 490 269 464 493 269 464 minecraft:red_terracotta
fill 492 269 504 493 269 504 minecraft:red_terracotta
setblock 493 269 465 minecraft:terracotta
setblock 494 269 464 minecraft:terracotta
fill 494 269 465 494 272 465 minecraft:red_terracotta
setblock 494 269 504 minecraft:terracotta
fill 495 269 464 495 272 464 minecraft:red_terracotta
fill 495 269 504 495 272 504 minecraft:red_terracotta
setblock 496 269 466 minecraft:red_terracotta
fill 496 269 503 496 272 503 minecraft:red_terracotta
setblock 497 269 466 minecraft:terracotta
setblock 497 269 474 minecraft:light[level=14]
setblock 497 269 482 minecraft:light[level=14]
setblock 497 269 490 minecraft:light[level=14]
setblock 497 269 498 minecraft:light[level=14]
setblock 498 269 464 minecraft:red_terracotta
setblock 498 269 465 minecraft:terracotta
fill 498 269 466 501 269 466 minecraft:red_terracotta
setblock 499 269 464 minecraft:terracotta
fill 499 269 465 499 272 465 minecraft:red_terracotta
fill 499 269 467 500 269 467 minecraft:red_terracotta
fill 499 269 502 500 269 502 minecraft:red_terracotta
setblock 499 269 504 minecraft:terracotta
fill 500 269 464 500 272 464 minecraft:red_terracotta
setblock 500 269 503 minecraft:terracotta
fill 500 269 504 500 272 504 minecraft:red_terracotta
setblock 501 269 467 minecraft:terracotta
setblock 501 269 502 minecraft:terracotta
fill 501 269 503 501 272 503 minecraft:red_terracotta
setblock 502 269 466 minecraft:terracotta
fill 502 269 467 503 271 467 minecraft:red_terracotta
fill 502 269 502 502 271 502 minecraft:red_terracotta
setblock 503 269 465 minecraft:terracotta
fill 503 269 466 503 272 466 minecraft:red_terracotta
setblock 504 269 464 minecraft:terracotta
fill 504 269 465 504 272 465 minecraft:red_terracotta
setblock 504 269 504 minecraft:terracotta
fill 505 269 464 505 272 464 minecraft:red_terracotta
setblock 505 269 474 minecraft:light[level=14]
setblock 505 269 482 minecraft:light[level=14]
setblock 505 269 490 minecraft:light[level=14]
setblock 505 269 498 minecraft:light[level=14]
setblock 505 269 502 minecraft:red_terracotta
setblock 505 269 503 minecraft:terracotta
fill 505 269 504 505 272 504 minecraft:red_terracotta
fill 506 269 503 506 272 503 minecraft:red_terracotta
setblock 507 269 466 minecraft:terracotta
setblock 508 269 465 minecraft:terracotta
setblock 509 269 464 minecraft:terracotta
fill 509 269 465 509 272 465 minecraft:red_terracotta
setblock 509 269 504 minecraft:terracotta
fill 510 269 464 510 272 464 minecraft:red_terracotta
fill 510 269 466 510 270 466 minecraft:red_terracotta
setblock 510 269 503 minecraft:terracotta
fill 510 269 504 510 272 504 minecraft:red_terracotta
setblock 511 269 467 minecraft:terracotta
fill 511 269 468 511 272 468 minecraft:red_terracotta
fill 511 269 483 511 270 484 minecraft:red_terracotta
setblock 511 269 502 minecraft:terracotta
fill 511 269 503 511 272 503 minecraft:red_terracotta
setblock 471 270 466 minecraft:terracotta
setblock 471 270 481 minecraft:terracotta
fill 471 270 482 471 273 482 minecraft:red_terracotta
setblock 471 270 486 minecraft:terracotta
fill 471 270 487 471 270 490 minecraft:red_terracotta
setblock 471 270 491 minecraft:terracotta
fill 471 270 492 471 270 495 minecraft:red_terracotta
setblock 471 270 496 minecraft:terracotta
fill 471 270 497 471 273 497 minecraft:red_terracotta
setblock 471 270 501 minecraft:terracotta
fill 471 270 502 471 273 502 minecraft:red_terracotta
setblock 472 270 464 minecraft:red_terracotta
fill 472 270 483 472 270 484 minecraft:red_terracotta
setblock 472 270 485 minecraft:terracotta
fill 472 270 486 472 273 486 minecraft:red_terracotta
fill 472 270 488 472 270 489 minecraft:red_terracotta
setblock 472 270 500 minecraft:terracotta
fill 472 270 501 472 271 501 minecraft:red_terracotta
setblock 473 270 464 minecraft:terracotta
setblock 473 270 504 minecraft:terracotta
fill 474 270 464 477 270 464 minecraft:red_terracotta
setblock 474 270 503 minecraft:terracotta
fill 474 270 504 474 273 504 minecraft:red_terracotta
fill 475 270 465 476 270 465 minecraft:red_terracotta
setblock 475 270 502 minecraft:terracotta
fill 475 270 503 475 273 503 minecraft:red_terracotta
fill 476 270 502 476 271 502 minecraft:red_terracotta
setblock 477 270 465 minecraft:terracotta
setblock 478 270 464 minecraft:terracotta
fill 478 270 465 478 273 465 minecraft:red_terracotta
setblock 478 270 504 minecraft:terracotta
fill 479 270 464 479 273 464 minecraft:red_terracotta
setblock 479 270 503 minecraft:terracotta
fill 479 270 504 479 273 504 minecraft:red_terracotta
setblock 480 270 502 minecraft:terracotta
fill 480 270 503 480 273 503 minecraft:red_terracotta
setblock 481 270 465 minecraft:red_terracotta
setblock 481 270 502 minecraft:red_terracotta
setblock 482 270 465 minecraft:terracotta
fill 482 270 493 483 270 497 minecraft:orange_concrete
setblock 483 270 464 minecraft:terracotta
fill 483 270 465 483 273 465 minecraft:red_terracotta
fill 483 270 492 488 270 492 minecraft:orange_concrete
fill 483 270 498 488 270 498 minecraft:orange_concrete
setblock 483 270 504 minecraft:terracotta
fill 484 270 464 484 273 464 minecraft:red_terracotta
fill 484 270 491 487 270 491 minecraft:orange_concrete
fill 484 270 493 484 272 493 minecraft:orange_concrete
fill 484 270 497 484 272 497 minecraft:orange_concrete
fill 484 270 499 487 270 499 minecraft:orange_concrete
setblock 484 270 503 minecraft:terracotta
fill 484 270 504 484 272 504 minecraft:red_terracotta
setblock 487 270 464 minecraft:red_terracotta
fill 487 270 493 489 270 493 minecraft:orange_concrete
fill 487 270 497 489 270 497 minecraft:orange_concrete
setblock 488 270 464 minecraft:terracotta
fill 488 270 494 489 271 496 minecraft:orange_concrete
setblock 488 270 504 minecraft:terracotta
fill 489 270 464 492 270 464 minecraft:red_terracotta
fill 491 270 504 492 270 504 minecraft:red_terracotta
setblock 492 270 465 minecraft:terracotta
setblock 493 270 464 minecraft:terracotta
fill 493 270 465 493 273 465 minecraft:red_terracotta
setblock 493 270 504 minecraft:terracotta
fill 494 270 464 494 273 464 minecraft:red_terracotta
fill 494 270 504 494 273 504 minecraft:red_terracotta
setblock 495 270 466 minecraft:red_terracotta
fill 495 270 503 495 271 503 minecraft:red_terracotta
setblock 496 270 465 minecraft:red_terracotta
setblock 496 270 466 minecraft:terracotta
setblock 497 270 465 minecraft:terracotta
fill 497 270 466 499 270 467 minecraft:red_terracotta
setblock 498 270 464 minecraft:terracotta
fill 498 270 465 498 273 465 minecraft:red_terracotta
setblock 498 270 504 minecraft:terracotta
fill 499 270 464 499 273 464 minecraft:red_terracotta
setblock 499 270 502 minecraft:red_terracotta
setblock 499 270 503 minecraft:terracotta
fill 499 270 504 499 273 504 minecraft:red_terracotta
setblock 500 270 466 minecraft:red_terracotta
setblock 500 270 467 minecraft:terracotta
setblock 500 270 502 minecraft:terracotta
fill 500 270 503 500 273 503 minecraft:red_terracotta
setblock 501 270 466 minecraft:terracotta
fill 501 270 467 501 273 467 minecraft:red_terracotta
fill 501 270 502 501 271 502 minecraft:red_terracotta
setblock 502 270 465 minecraft:terracotta
fill 502 270 466 502 273 466 minecraft:red_terracotta
setblock 503 270 464 minecraft:terracotta
fill 503 270 465 503 273 465 minecraft:red_terracotta
setblock 503 270 504 minecraft:terracotta
fill 504 270 464 504 273 464 minecraft:red_terracotta
setblock 504 270 503 minecraft:terracotta
fill 504 270 504 504 273 504 minecraft:red_terracotta
setblock 505 270 466 minecraft:red_terracotta
fill 505 270 503 505 272 503 minecraft:red_terracotta
setblock 506 270 466 minecraft:terracotta
setblock 507 270 465 minecraft:terracotta
setblock 507 270 466 minecraft:red_terracotta
setblock 508 270 464 minecraft:terracotta
fill 508 270 465 508 273 465 minecraft:red_terracotta
setblock 508 270 504 minecraft:terracotta
fill 509 270 464 509 273 464 minecraft:red_terracotta
setblock 509 270 503 minecraft:terracotta
fill 509 270 504 509 273 504 minecraft:red_terracotta
setblock 510 270 502 minecraft:terracotta
fill 510 270 503 510 272 503 minecraft:red_terracotta
setblock 511 270 466 minecraft:terracotta
fill 511 270 467 511 273 467 minecraft:red_terracotta
setblock 511 270 485 minecraft:red_terracotta
setblock 511 270 486 minecraft:terracotta
fill 511 270 487 511 273 487 minecraft:red_terracotta
setblock 511 270 501 minecraft:terracotta
fill 511 270 502 511 273 502 minecraft:red_terracotta
setblock 471 271 464 minecraft:red_terracotta
setblock 471 271 465 minecraft:terracotta
fill 471 271 466 471 273 466 minecraft:red_terracotta
setblock 471 271 481 minecraft:red_terracotta
setblock 471 271 485 minecraft:terracotta
fill 471 271 486 471 271 489 minecraft:red_terracotta
setblock 471 271 490 minecraft:terracotta
fill 471 271 491 471 271 494 minecraft:red_terracotta
setblock 471 271 495 minecraft:terracotta
fill 471 271 496 471 273 496 minecraft:red_terracotta
setblock 471 271 500 minecraft:terracotta
fill 471 271 501 471 273 501 minecraft:red_terracotta
setblock 472 271 464 minecraft:terracotta
setblock 472 271 483 minecraft:red_terracotta
setblock 472 271 484 minecraft:terracotta
fill 472 271 485 473 273 485 minecraft:red_terracotta
setblock 472 271 488 minecraft:red_terracotta
setblock 472 271 489 minecraft:terracotta
fill 472 271 490 472 273 491 minecraft:red_terracotta
setblock 472 271 504 minecraft:terracotta
fill 473 271 464 476 271 464 minecraft:red_terracotta
fill 473 271 486 473 271 487 minecraft:red_terracotta
setblock 473 271 488 minecraft:terracotta
setblock 473 271 503 minecraft:terracotta
fill 473 271 504 473 273 504 minecraft:red_terracotta
fill 474 271 465 475 271 465 minecraft:red_terracotta
fill 474 271 503 474 273 503 minecraft:red_terracotta
setblock 475 271 502 minecraft:red_terracotta
setblock 476 271 465 minecraft:terracotta
setblock 477 271 464 minecraft:terracotta
fill 477 271 465 477 273 465 minecraft:red_terracotta
setblock 477 271 504 minecraft:terracotta
fill 478 271 464 478 273 464 minecraft:red_terracotta
setblock 478 271 503 minecraft:terracotta
fill 478 271 504 478 273 504 minecraft:red_terracotta
setblock 479 271 502 minecraft:terracotta
fill 479 271 503 479 273 503 minecraft:red_terracotta
setblock 480 271 502 minecraft:red_terracotta
setblock 481 271 465 minecraft:terracotta
setblock 482 271 464 minecraft:terracotta
fill 482 271 465 482 273 465 minecraft:red_terracotta
fill 482 271 495 483 271 495 minecraft:orange_concrete
setblock 482 271 504 minecraft:terracotta
fill 483 271 464 483 273 464 minecraft:red_terracotta
fill 483 271 493 483 271 494 minecraft:orange_concrete
fill 483 271 496 483 271 497 minecraft:orange_concrete
setblock 483 271 503 minecraft:terracotta
fill 483 271 504 483 273 504 minecraft:red_terracotta
fill 484 271 492 487 271 492 minecraft:orange_concrete
fill 484 271 498 487 271 498 minecraft:orange_concrete
setblock 487 271 464 minecraft:terracotta
fill 487 271 493 488 271 493 minecraft:orange_concrete
fill 487 271 497 488 271 497 minecraft:orange_concrete
fill 488 271 464 491 271 464 minecraft:red_terracotta
setblock 491 271 465 minecraft:terracotta
setblock 492 271 464 minecraft:terracotta
fill 492 271 465 492 273 465 minecraft:red_terracotta
setblock 492 271 504 minecraft:terracotta
fill 493 271 464 493 273 464 minecraft:red_terracotta
fill 493 271 504 493 273 504 minecraft:red_terracotta
setblock 494 271 466 minecraft:red_terracotta
setblock 495 271 466 minecraft:terracotta
setblock 496 271 465 minecraft:terracotta
fill 496 271 466 498 271 467 minecraft:red_terracotta
setblock 497 271 464 minecraft:terracotta
fill 497 271 465 497 273 465 minecraft:red_terracotta
setblock 497 271 504 minecraft:terracotta
fill 498 271 464 498 273 464 minecraft:red_terracotta
setblock 498 271 503 minecraft:terracotta
fill 498 271 504 498 273 504 minecraft:red_terracotta
setblock 499 271 466 minecraft:red_terracotta
setblock 499 271 467 minecraft:terracotta
fill 499 271 503 499 273 503 minecraft:red_terracotta
setblock 500 271 466 minecraft:terracotta
fill 500 271 467 500 273 467 minecraft:red_terracotta
setblock 500 271 502 minecraft:red_terracotta
setblock 501 271 465 minecraft:terracotta
fill 501 271 466 501 273 466 minecraft:red_terracotta
setblock 502 271 464 minecraft:terracotta
fill 502 271 465 502 273 465 minecraft:red_terracotta
setblock 502 271 504 minecraft:terracotta
fill 503 271 464 503 273 464 minecraft:red_terracotta
fill 503 271 474 503 272 474 minecraft:orange_concrete
setblock 503 271 503 minecraft:terracotta
fill 503 271 504 503 273 504 minecraft:red_terracotta
fill 504 271 503 504 273 503 minecraft:red_terracotta
setblock 505 271 466 minecraft:terracotta
setblock 506 271 465 minecraft:terracotta
fill 506 271 466 506 272 466 minecraft:red_terracotta
setblock 507 271 464 minecraft:terracotta
fill 507 271 465 507 273 465 minecraft:red_terracotta
setblock 507 271 504 minecraft:terracotta
fill 508 271 464 508 273 464 minecraft:red_terracotta
setblock 508 271 503 minecraft:terracotta
fill 508 271 504 508 273 504 minecraft:red_terracotta
fill 509 271 503 509 272 503 minecraft:red_terracotta
setblock 510 271 466 minecraft:terracotta
setblock 510 271 502 minecraft:red_terracotta
setblock 511 271 465 minecraft:terracotta
fill 511 271 466 511 273 466 minecraft:red_terracotta
setblock 511 271 484 minecraft:red_terracotta
setblock 511 271 485 minecraft:terracotta
fill 511 271 486 511 273 486 minecraft:red_terracotta
fill 511 271 488 511 272 488 minecraft:red_terracotta
setblock 511 271 500 minecraft:terracotta
fill 511 271 501 511 273 501 minecraft:red_terracotta
setblock 471 272 464 minecraft:terracotta
fill 471 272 465 471 273 465 minecraft:red_terracotta
setblock 471 272 484 minecraft:terracotta
fill 471 272 485 471 272 488 minecraft:red_terracotta
setblock 471 272 489 minecraft:terracotta
fill 471 272 490 471 272 493 minecraft:red_terracotta
setblock 471 272 494 minecraft:terracotta
fill 471 272 495 471 273 495 minecraft:red_terracotta
setblock 471 272 499 minecraft:terracotta
fill 471 272 500 471 273 500 minecraft:red_terracotta
setblock 471 272 504 minecraft:terracotta
fill 472 272 464 475 272 464 minecraft:red_terracotta
setblock 472 272 483 minecraft:terracotta
fill 472 272 484 472 273 484 minecraft:red_terracotta
setblock 472 272 488 minecraft:terracotta
fill 472 272 489 473 273 489 minecraft:red_terracotta
setblock 472 272 492 minecraft:red_terracotta
setblock 472 272 503 minecraft:terracotta
fill 472 272 504 472 273 504 minecraft:red_terracotta
setblock 473 272 486 minecraft:red_terracotta
setblock 473 272 487 minecraft:terracotta
fill 473 272 488 473 273 488 minecraft:red_terracotta
fill 473 272 490 473 273 490 minecraft:red_terracotta
fill 473 272 503 473 273 503 minecraft:red_terracotta
setblock 474 272 465 minecraft:red_terracotta
setblock 475 272 465 minecraft:terracotta
setblock 476 272 464 minecraft:terracotta
fill 476 272 465 476 273 465 minecraft:red_terracotta
setblock 476 272 504 minecraft:terracotta
fill 477 272 464 477 273 464 minecraft:red_terracotta
setblock 477 272 503 minecraft:terracotta
fill 477 272 504 477 273 504 minecraft:red_terracotta
fill 478 272 503 478 273 503 minecraft:red_terracotta
setblock 480 272 465 minecraft:terracotta
setblock 481 272 464 minecraft:terracotta
fill 481 272 465 481 273 465 minecraft:red_terracotta
setblock 481 272 504 minecraft:terracotta
fill 482 272 464 482 273 464 minecraft:red_terracotta
setblock 482 272 503 minecraft:terracotta
fill 482 272 504 482 273 504 minecraft:red_terracotta
fill 483 272 494 483 272 496 minecraft:orange_concrete
setblock 484 272 465 minecraft:red_terracotta
setblock 486 272 464 minecraft:terracotta
fill 487 272 464 490 272 464 minecraft:red_terracotta
setblock 487 272 493 minecraft:orange_concrete
setblock 487 272 497 minecraft:orange_concrete
fill 488 272 494 488 272 496 minecraft:orange_concrete
setblock 491 272 464 minecraft:terracotta
fill 491 272 465 491 273 465 minecraft:red_terracotta
fill 492 272 464 492 273 464 minecraft:red_terracotta
setblock 492 272 504 minecraft:red_terracotta
setblock 493 272 466 minecraft:red_terracotta
setblock 494 272 466 minecraft:terracotta
setblock 495 272 465 minecraft:terracotta
fill 495 272 466 498 272 466 minecraft:red_terracotta
setblock 496 272 464 minecraft:terracotta
fill 496 272 465 496 273 465 minecraft:red_terracotta
fill 496 272 467 497 272 467 minecraft:red_terracotta
setblock 496 272 504 minecraft:terracotta
fill 497 272 464 497 273 464 minecraft:red_terracotta
setblock 497 272 503 minecraft:terracotta
fill 497 272 504 497 273 504 minecraft:red_terracotta
setblock 498 272 467 minecraft:terracotta
fill 498 272 503 498 273 503 minecraft:red_terracotta
setblock 499 272 466 minecraft:terracotta
fill 499 272 467 499 273 467 minecraft:red_terracotta
setblock 500 272 465 minecraft:terracotta
fill 500 272 466 500 273 466 minecraft:red_terracotta
setblock 501 272 464 minecraft:terracotta
fill 501 272 465 501 273 465 minecraft:red_terracotta
setblock 501 272 504 minecraft:terracotta
fill 502 272 464 502 273 464 minecraft:red_terracotta
setblock 502 272 467 minecraft:red_terracotta
setblock 502 272 503 minecraft:terracotta
fill 502 272 504 502 273 504 minecraft:red_terracotta
fill 503 272 503 503 273 503 minecraft:red_terracotta
setblock 504 272 466 minecraft:terracotta
setblock 505 272 465 minecraft:terracotta
fill 505 272 466 505 273 466 minecraft:red_terracotta
setblock 506 272 464 minecraft:terracotta
fill 506 272 465 506 273 465 minecraft:red_terracotta
setblock 506 272 504 minecraft:terracotta
fill 507 272 464 507 273 464 minecraft:red_terracotta
setblock 507 272 503 minecraft:terracotta
fill 507 272 504 507 273 504 minecraft:red_terracotta
setblock 508 272 503 minecraft:red_terracotta
setblock 510 272 465 minecraft:terracotta
fill 510 272 466 510 273 466 minecraft:red_terracotta
setblock 511 272 464 minecraft:terracotta
fill 511 272 465 511 273 465 minecraft:red_terracotta
setblock 511 272 469 minecraft:terracotta
setblock 511 272 484 minecraft:terracotta
fill 511 272 485 511 273 485 minecraft:red_terracotta
setblock 511 272 489 minecraft:terracotta
fill 511 272 490 511 273 490 minecraft:red_terracotta
setblock 511 272 499 minecraft:terracotta
fill 511 272 500 511 273 500 minecraft:red_terracotta
setblock 511 272 504 minecraft:terracotta
fill 471 273 464 474 273 464 minecraft:red_terracotta
setblock 471 273 467 minecraft:red_terracotta
setblock 471 273 483 minecraft:terracotta
fill 471 273 484 471 273 487 minecraft:red_terracotta
setblock 471 273 488 minecraft:terracotta
fill 471 273 489 471 273 492 minecraft:red_terracotta
setblock 471 273 493 minecraft:terracotta
setblock 471 273 494 minecraft:red_terracotta
setblock 471 273 498 minecraft:terracotta
setblock 471 273 499 minecraft:red_terracotta
setblock 471 273 503 minecraft:terracotta
setblock 471 273 504 minecraft:red_terracotta
setblock 472 273 483 minecraft:red_terracotta
setblock 472 273 487 minecraft:terracotta
setblock 472 273 488 minecraft:red_terracotta
setblock 472 273 492 minecraft:terracotta
setblock 472 273 493 minecraft:red_terracotta
setblock 473 273 486 minecraft:terracotta
setblock 473 273 487 minecraft:red_terracotta
setblock 473 273 491 minecraft:terracotta
setblock 474 273 465 minecraft:terracotta
setblock 475 273 464 minecraft:terracotta
setblock 475 273 465 minecraft:red_terracotta
setblock 475 273 504 minecraft:terracotta
setblock 476 273 464 minecraft:red_terracotta
setblock 476 273 503 minecraft:terracotta
setblock 476 273 504 minecraft:red_terracotta
setblock 477 273 503 minecraft:red_terracotta
setblock 479 273 465 minecraft:terracotta
setblock 480 273 464 minecraft:terracotta
setblock 480 273 465 minecraft:red_terracotta
setblock 480 273 504 minecraft:terracotta
setblock 481 273 464 minecraft:red_terracotta
setblock 481 273 504 minecraft:red_terracotta
setblock 485 273 464 minecraft:terracotta
fill 486 273 464 489 273 464 minecraft:red_terracotta
setblock 490 273 464 minecraft:terracotta
setblock 491 273 464 minecraft:red_terracotta
setblock 493 273 466 minecraft:terracotta
setblock 494 273 465 minecraft:terracotta
fill 494 273 466 497 273 466 minecraft:red_terracotta
setblock 495 273 464 minecraft:terracotta
setblock 495 273 465 minecraft:red_terracotta
fill 495 273 467 496 273 467 minecraft:red_terracotta
setblock 495 273 504 minecraft:terracotta
setblock 496 273 464 minecraft:red_terracotta
setblock 496 273 503 minecraft:terracotta
setblock 496 273 504 minecraft:red_terracotta
setblock 497 273 467 minecraft:terracotta
setblock 497 273 503 minecraft:red_terracotta
setblock 498 273 466 minecraft:terracotta
setblock 498 273 467 minecraft:red_terracotta
setblock 499 273 465 minecraft:terracotta
setblock 499 273 466 minecraft:red_terracotta
setblock 500 273 464 minecraft:terracotta
setblock 500 273 465 minecraft:red_terracotta
setblock 500 273 504 minecraft:terracotta
setblock 501 273 464 minecraft:red_terracotta
setblock 501 273 503 minecraft:terracotta
setblock 501 273 504 minecraft:red_terracotta
setblock 502 273 467 minecraft:terracotta
setblock 502 273 503 minecraft:red_terracotta
setblock 503 273 466 minecraft:terracotta
setblock 504 273 465 minecraft:terracotta
setblock 504 273 466 minecraft:red_terracotta
setblock 505 273 464 minecraft:terracotta
setblock 505 273 465 minecraft:red_terracotta
setblock 505 273 504 minecraft:terracotta
setblock 506 273 464 minecraft:red_terracotta
setblock 506 273 504 minecraft:red_terracotta
setblock 509 273 465 minecraft:terracotta
setblock 510 273 464 minecraft:terracotta
setblock 510 273 465 minecraft:red_terracotta
setblock 510 273 504 minecraft:terracotta
setblock 511 273 464 minecraft:red_terracotta
setblock 511 273 468 minecraft:terracotta
setblock 511 273 469 minecraft:red_terracotta
setblock 511 273 488 minecraft:terracotta
setblock 511 273 489 minecraft:red_terracotta
setblock 511 273 491 minecraft:red_terracotta
setblock 511 273 503 minecraft:terracotta
setblock 511 273 504 minecraft:red_terracotta
setblock 473 277 466 minecraft:light[level=14]
setblock 473 277 474 minecraft:light[level=14]
setblock 473 277 482 minecraft:light[level=14]
setblock 473 277 490 minecraft:light[level=14]
setblock 473 277 498 minecraft:light[level=14]
setblock 481 277 466 minecraft:light[level=14]
setblock 481 277 474 minecraft:light[level=14]
setblock 481 277 482 minecraft:light[level=14]
setblock 481 277 490 minecraft:light[level=14]
setblock 481 277 498 minecraft:light[level=14]
setblock 489 277 466 minecraft:light[level=14]
setblock 489 277 474 minecraft:light[level=14]
setblock 489 277 482 minecraft:light[level=14]
setblock 489 277 490 minecraft:light[level=14]
setblock 489 277 498 minecraft:light[level=14]
setblock 497 277 466 minecraft:light[level=14]
setblock 497 277 474 minecraft:light[level=14]
setblock 497 277 482 minecraft:light[level=14]
setblock 497 277 490 minecraft:light[level=14]
setblock 497 277 498 minecraft:light[level=14]
setblock 505 277 466 minecraft:light[level=14]
setblock 505 277 474 minecraft:light[level=14]
setblock 505 277 482 minecraft:light[level=14]
setblock 505 277 490 minecraft:light[level=14]
setblock 505 277 498 minecraft:light[level=14]
fill 471 279 474 488 279 494 minecraft:terracotta
fill 472 279 472 510 279 473 minecraft:terracotta
fill 472 279 495 510 279 496 minecraft:terracotta
fill 473 279 471 509 279 471 minecraft:terracotta
fill 473 279 497 509 279 497 minecraft:terracotta
fill 474 279 470 508 279 470 minecraft:terracotta
fill 474 279 498 508 279 498 minecraft:terracotta
fill 475 279 469 507 279 469 minecraft:terracotta
fill 475 279 499 507 279 499 minecraft:terracotta
fill 476 279 468 506 279 468 minecraft:terracotta
fill 476 279 500 506 279 500 minecraft:terracotta
fill 477 279 467 505 279 467 minecraft:terracotta
fill 477 279 501 505 279 501 minecraft:terracotta
fill 478 279 466 504 279 466 minecraft:terracotta
fill 478 279 502 504 279 502 minecraft:terracotta
fill 479 279 465 503 279 465 minecraft:terracotta
fill 479 279 503 503 279 503 minecraft:terracotta
fill 481 279 464 501 279 464 minecraft:terracotta
fill 481 279 504 501 279 504 minecraft:terracotta
fill 489 279 474 489 279 485 minecraft:terracotta
setblock 489 279 486 minecraft:orange_terracotta
fill 489 279 487 489 279 494 minecraft:terracotta
fill 490 279 474 491 279 483 minecraft:terracotta
fill 490 279 484 490 279 485 minecraft:orange_terracotta
fill 490 279 487 490 279 488 minecraft:orange_terracotta
fill 490 279 489 511 279 494 minecraft:terracotta
setblock 491 279 484 minecraft:orange_terracotta
setblock 491 279 488 minecraft:orange_terracotta
fill 492 279 474 511 279 482 minecraft:terracotta
setblock 492 279 483 minecraft:orange_terracotta
fill 493 279 483 511 279 483 minecraft:terracotta
fill 493 279 484 494 279 484 minecraft:orange_terracotta
setblock 493 279 488 minecraft:orange_terracotta
setblock 494 279 485 minecraft:orange_terracotta
setblock 494 279 487 minecraft:orange_terracotta
fill 494 279 488 511 279 488 minecraft:terracotta
fill 495 279 484 511 279 487 minecraft:terracotta
fill 471 280 464 471 280 474 minecraft:red_terracotta
fill 471 280 475 471 280 493 minecraft:terracotta
fill 471 280 494 471 280 504 minecraft:red_terracotta
fill 472 280 464 472 280 472 minecraft:red_terracotta
fill 472 280 473 472 280 474 minecraft:terracotta
fill 472 280 475 487 280 493 minecraft:red_terracotta
fill 472 280 494 472 280 495 minecraft:terracotta
fill 472 280 496 472 280 504 minecraft:red_terracotta
fill 473 280 464 473 280 471 minecraft:red_terracotta
setblock 473 280 472 minecraft:terracotta
fill 473 280 473 509 280 474 minecraft:red_terracotta
fill 473 280 494 509 280 495 minecraft:red_terracotta
setblock 473 280 496 minecraft:terracotta
fill 473 280 497 473 280 504 minecraft:red_terracotta
fill 474 280 464 474 280 470 minecraft:red_terracotta
setblock 474 280 471 minecraft:terracotta
fill 474 280 472 508 280 472 minecraft:red_terracotta
fill 474 280 496 508 280 496 minecraft:red_terracotta
setblock 474 280 497 minecraft:terracotta
fill 474 280 498 474 280 504 minecraft:red_terracotta
fill 475 280 464 475 280 468 minecraft:red_terracotta
fill 475 280 469 475 280 470 minecraft:terracotta
fill 475 280 471 507 280 471 minecraft:red_terracotta
fill 475 280 497 507 280 497 minecraft:red_terracotta
fill 475 280 498 475 280 499 minecraft:terracotta
fill 475 280 500 475 280 504 minecraft:red_terracotta
fill 476 280 464 477 280 467 minecraft:red_terracotta
fill 476 280 468 477 280 468 minecraft:terracotta
fill 476 280 469 506 280 470 minecraft:red_terracotta
fill 476 280 498 506 280 499 minecraft:red_terracotta
fill 476 280 500 477 280 500 minecraft:terracotta
fill 476 280 501 477 280 504 minecraft:red_terracotta
fill 478 280 464 478 280 466 minecraft:red_terracotta
setblock 478 280 467 minecraft:terracotta
fill 478 280 468 504 280 468 minecraft:red_terracotta
fill 478 280 500 504 280 500 minecraft:red_terracotta
setblock 478 280 501 minecraft:terracotta
fill 478 280 502 478 280 504 minecraft:red_terracotta
fill 479 280 464 479 280 465 minecraft:red_terracotta
setblock 479 280 466 minecraft:terracotta
fill 479 280 467 503 280 467 minecraft:red_terracotta
fill 479 280 501 503 280 501 minecraft:red_terracotta
setblock 479 280 502 minecraft:terracotta
fill 479 280 503 479 280 504 minecraft:red_terracotta
fill 480 280 464 481 280 464 minecraft:red_terracotta
fill 480 280 465 481 280 465 minecraft:terracotta
fill 480 280 466 502 280 466 minecraft:red_terracotta
fill 480 280 502 502 280 502 minecraft:red_terracotta
fill 480 280 503 481 280 503 minecraft:terracotta
fill 480 280 504 481 280 504 minecraft:red_terracotta
fill 482 280 464 500 280 464 minecraft:terracotta
fill 482 280 465 500 280 465 minecraft:red_terracotta
fill 482 280 503 500 280 503 minecraft:red_terracotta
fill 482 280 504 500 280 504 minecraft:terracotta
fill 488 280 475 488 280 483 minecraft:red_terracotta
fill 488 280 484 488 280 488 minecraft:orange_terracotta
fill 488 280 489 488 280 493 minecraft:red_terracotta
fill 489 280 475 489 280 482 minecraft:red_terracotta
fill 489 280 483 489 280 484 minecraft:orange_terracotta
fill 489 280 485 489 280 487 minecraft:shroomlight
fill 489 280 488 489 280 489 minecraft:orange_terracotta
fill 489 280 490 490 280 493 minecraft:red_terracotta
fill 490 280 475 510 280 481 minecraft:red_terracotta
fill 490 280 482 490 280 483 minecraft:orange_terracotta
fill 490 280 484 490 280 485 minecraft:shroomlight
fill 490 280 487 490 280 488 minecraft:shroomlight
setblock 490 280 489 minecraft:orange_terracotta
fill 491 280 482 494 280 482 minecraft:orange_terracotta
fill 491 280 483 491 280 484 minecraft:shroomlight
fill 491 280 488 491 280 489 minecraft:shroomlight
fill 491 280 490 492 280 490 minecraft:orange_terracotta
fill 491 280 491 510 280 493 minecraft:red_terracotta
fill 492 280 483 493 280 483 minecraft:shroomlight
fill 492 280 489 493 280 489 minecraft:shroomlight
fill 493 280 484 494 280 484 minecraft:shroomlight
fill 493 280 488 494 280 488 minecraft:shroomlight
fill 493 280 490 510 280 490 minecraft:red_terracotta
fill 494 280 483 495 280 483 minecraft:orange_terracotta
fill 494 280 485 495 280 485 minecraft:shroomlight
fill 494 280 487 495 280 487 minecraft:shroomlight
setblock 494 280 489 minecraft:orange_terracotta
fill 495 280 482 510 280 482 minecraft:red_terracotta
fill 495 280 484 496 280 484 minecraft:orange_terracotta
setblock 495 280 486 minecraft:shroomlight
setblock 495 280 488 minecraft:orange_terracotta
fill 495 280 489 510 280 489 minecraft:red_terracotta
fill 496 280 483 510 280 483 minecraft:red_terracotta
fill 496 280 485 496 280 487 minecraft:orange_terracotta
fill 496 280 488 510 280 488 minecraft:red_terracotta
fill 497 280 484 510 280 487 minecraft:red_terracotta
fill 501 280 464 511 280 464 minecraft:red_terracotta
fill 501 280 465 502 280 465 minecraft:terracotta
fill 501 280 503 502 280 503 minecraft:terracotta
fill 501 280 504 511 280 504 minecraft:red_terracotta
fill 503 280 465 511 280 465 minecraft:red_terracotta
setblock 503 280 466 minecraft:terracotta
setblock 503 280 502 minecraft:terracotta
fill 503 280 503 511 280 503 minecraft:red_terracotta
fill 504 280 466 511 280 466 minecraft:red_terracotta
setblock 504 280 467 minecraft:terracotta
setblock 504 280 501 minecraft:terracotta
fill 504 280 502 511 280 502 minecraft:red_terracotta
fill 505 280 467 511 280 467 minecraft:red_terracotta
fill 505 280 468 506 280 468 minecraft:terracotta
fill 505 280 500 506 280 500 minecraft:terracotta
fill 505 280 501 511 280 501 minecraft:red_terracotta
fill 507 280 468 511 280 468 minecraft:red_terracotta
fill 507 280 469 507 280 470 minecraft:terracotta
fill 507 280 498 507 280 499 minecraft:terracotta
fill 507 280 500 511 280 500 minecraft:red_terracotta
fill 508 280 469 511 280 470 minecraft:red_terracotta
setblock 508 280 471 minecraft:terracotta
setblock 508 280 497 minecraft:terracotta
fill 508 280 498 511 280 499 minecraft:red_terracotta
fill 509 280 471 511 280 471 minecraft:red_terracotta
setblock 509 280 472 minecraft:terracotta
setblock 509 280 496 minecraft:terracotta
fill 509 280 497 511 280 497 minecraft:red_terracotta
fill 510 280 472 511 280 472 minecraft:red_terracotta
fill 510 280 473 510 280 474 minecraft:terracotta
fill 510 280 494 510 280 495 minecraft:terracotta
fill 510 280 496 511 280 496 minecraft:red_terracotta
fill 511 280 473 511 280 474 minecraft:red_terracotta
fill 511 280 475 511 280 493 minecraft:terracotta
fill 511 280 494 511 280 495 minecraft:red_terracotta
fill 471 281 477 471 281 491 minecraft:terracotta
fill 472 281 475 472 281 476 minecraft:terracotta
fill 472 281 477 485 281 491 minecraft:red_terracotta
fill 472 281 492 472 281 493 minecraft:terracotta
fill 473 281 473 473 281 474 minecraft:terracotta
fill 473 281 475 509 281 476 minecraft:red_terracotta
fill 473 281 492 509 281 493 minecraft:red_terracotta
fill 473 281 494 473 281 495 minecraft:terracotta
setblock 474 281 472 minecraft:terracotta
fill 474 281 473 508 281 474 minecraft:red_terracotta
fill 474 281 494 508 281 495 minecraft:red_terracotta
setblock 474 281 496 minecraft:terracotta
fill 475 281 470 475 281 471 minecraft:terracotta
fill 475 281 472 507 281 472 minecraft:red_terracotta
fill 475 281 496 507 281 496 minecraft:red_terracotta
fill 475 281 497 475 281 498 minecraft:terracotta
setblock 476 281 469 minecraft:terracotta
fill 476 281 470 506 281 471 minecraft:red_terracotta
fill 476 281 497 506 281 498 minecraft:red_terracotta
setblock 476 281 499 minecraft:terracotta
fill 477 281 468 478 281 468 minecraft:terracotta
fill 477 281 469 505 281 469 minecraft:red_terracotta
fill 477 281 499 505 281 499 minecraft:red_terracotta
fill 477 281 500 478 281 500 minecraft:terracotta
setblock 479 281 467 minecraft:terracotta
fill 479 281 468 503 281 468 minecraft:red_terracotta
fill 479 281 500 503 281 500 minecraft:red_terracotta
setblock 479 281 501 minecraft:terracotta
fill 480 281 466 481 281 466 minecraft:terracotta
fill 480 281 467 502 281 467 minecraft:red_terracotta
fill 480 281 501 502 281 501 minecraft:red_terracotta
fill 480 281 502 481 281 502 minecraft:terracotta
fill 482 281 465 483 281 465 minecraft:terracotta
fill 482 281 466 500 281 466 minecraft:red_terracotta
fill 482 281 502 500 281 502 minecraft:red_terracotta
fill 482 281 503 483 281 503 minecraft:terracotta
fill 484 281 464 498 281 464 minecraft:terracotta
fill 484 281 465 498 281 465 minecraft:red_terracotta
fill 484 281 503 498 281 503 minecraft:red_terracotta
fill 484 281 504 498 281 504 minecraft:terracotta
fill 486 281 477 486 281 483 minecraft:red_terracotta
fill 486 281 484 487 281 487 minecraft:orange_terracotta
fill 486 281 488 486 281 491 minecraft:red_terracotta
fill 487 281 477 487 281 481 minecraft:red_terracotta
fill 487 281 482 488 281 483 minecraft:orange_terracotta
fill 487 281 488 487 281 489 minecraft:orange_terracotta
fill 487 281 490 487 281 491 minecraft:red_terracotta
fill 488 281 477 488 281 480 minecraft:red_terracotta
fill 488 281 481 495 281 481 minecraft:orange_terracotta
fill 488 281 489 488 281 490 minecraft:orange_terracotta
fill 488 281 491 489 281 491 minecraft:red_terracotta
fill 489 281 477 510 281 479 minecraft:red_terracotta
fill 489 281 480 494 281 480 minecraft:orange_terracotta
setblock 489 281 482 minecraft:orange_terracotta
fill 489 281 490 490 281 490 minecraft:orange_terracotta
fill 490 281 491 493 281 491 minecraft:orange_terracotta
fill 493 281 490 495 281 490 minecraft:orange_terracotta
fill 494 281 491 510 281 491 minecraft:red_terracotta
fill 495 281 480 510 281 480 minecraft:red_terracotta
fill 495 281 482 496 281 482 minecraft:orange_terracotta
fill 495 281 489 496 281 489 minecraft:orange_terracotta
fill 496 281 481 510 281 481 minecraft:red_terracotta
fill 496 281 483 497 281 483 minecraft:orange_terracotta
fill 496 281 488 497 281 488 minecraft:orange_terracotta
fill 496 281 490 510 281 490 minecraft:red_terracotta
fill 497 281 482 510 281 482 minecraft:red_terracotta
fill 497 281 484 497 281 487 minecraft:orange_terracotta
fill 497 281 489 510 281 489 minecraft:red_terracotta
fill 498 281 483 510 281 488 minecraft:red_terracotta
fill 499 281 465 500 281 465 minecraft:terracotta
fill 499 281 503 500 281 503 minecraft:terracotta
fill 501 281 466 502 281 466 minecraft:terracotta
fill 501 281 502 502 281 502 minecraft:terracotta
setblock 503 281 467 minecraft:terracotta
setblock 503 281 501 minecraft:terracotta
fill 504 281 468 505 281 468 minecraft:terracotta
fill 504 281 500 505 281 500 minecraft:terracotta
setblock 506 281 469 minecraft:terracotta
setblock 506 281 499 minecraft:terracotta
fill 507 281 470 507 281 471 minecraft:terracotta
fill 507 281 497 507 281 498 minecraft:terracotta
setblock 508 281 472 minecraft:terracotta
setblock 508 281 496 minecraft:terracotta
fill 509 281 473 509 281 474 minecraft:terracotta
fill 509 281 494 509 281 495 minecraft:terracotta
fill 510 281 475 510 281 476 minecraft:terracotta
fill 510 281 492 510 281 493 minecraft:terracotta
fill 511 281 477 511 281 491 minecraft:terracotta
fill 471 282 479 471 282 489 minecraft:terracotta
fill 472 282 476 472 282 478 minecraft:terracotta
fill 472 282 479 483 282 489 minecraft:red_terracotta
fill 472 282 490 472 282 492 minecraft:terracotta
fill 473 282 474 473 282 475 minecraft:terracotta
fill 473 282 476 488 282 478 minecraft:red_terracotta
fill 473 282 490 485 282 492 minecraft:red_terracotta
fill 473 282 493 473 282 494 minecraft:terracotta
setblock 474 282 473 minecraft:terracotta
fill 474 282 474 508 282 475 minecraft:red_terracotta
fill 474 282 493 508 282 494 minecraft:red_terracotta
setblock 474 282 495 minecraft:terracotta
fill 475 282 471 475 282 472 minecraft:terracotta
fill 475 282 473 507 282 473 minecraft:red_terracotta
fill 475 282 495 507 282 495 minecraft:red_terracotta
fill 475 282 496 475 282 497 minecraft:terracotta
setblock 476 282 470 minecraft:terracotta
fill 476 282 471 506 282 472 minecraft:red_terracotta
fill 476 282 496 506 282 497 minecraft:red_terracotta
setblock 476 282 498 minecraft:terracotta
setblock 477 282 469 minecraft:terracotta
fill 477 282 470 505 282 470 minecraft:red_terracotta
fill 477 282 498 505 282 498 minecraft:red_terracotta
setblock 477 282 499 minecraft:terracotta
fill 478 282 468 479 282 468 minecraft:terracotta
fill 478 282 469 504 282 469 minecraft:red_terracotta
fill 478 282 499 504 282 499 minecraft:red_terracotta
fill 478 282 500 479 282 500 minecraft:terracotta
setblock 480 282 467 minecraft:terracotta
fill 480 282 468 502 282 468 minecraft:red_terracotta
fill 480 282 500 502 282 500 minecraft:red_terracotta
setblock 480 282 501 minecraft:terracotta
fill 481 282 466 482 282 466 minecraft:terracotta
fill 481 282 467 501 282 467 minecraft:red_terracotta
fill 481 282 501 501 282 501 minecraft:red_terracotta
fill 481 282 502 482 282 502 minecraft:terracotta
fill 483 282 465 485 282 465 minecraft:terracotta
fill 483 282 466 499 282 466 minecraft:red_terracotta
fill 483 282 502 499 282 502 minecraft:red_terracotta
fill 483 282 503 485 282 503 minecraft:terracotta
fill 484 282 479 484 282 483 minecraft:red_terracotta
fill 484 282 484 485 282 486 minecraft:orange_terracotta
fill 484 282 487 484 282 489 minecraft:red_terracotta
fill 485 282 479 485 282 481 minecraft:red_terracotta
fill 485 282 482 486 282 483 minecraft:orange_terracotta
fill 485 282 487 485 282 488 minecraft:orange_terracotta
setblock 485 282 489 minecraft:red_terracotta
fill 486 282 464 496 282 464 minecraft:terracotta
fill 486 282 465 496 282 465 minecraft:red_terracotta
setblock 486 282 479 minecraft:red_terracotta
fill 486 282 480 487 282 481 minecraft:orange_terracotta
fill 486 282 488 486 282 490 minecraft:orange_terracotta
fill 486 282 491 486 282 492 minecraft:red_terracotta
fill 486 282 503 496 282 503 minecraft:red_terracotta
fill 486 282 504 496 282 504 minecraft:terracotta
fill 487 282 479 496 282 479 minecraft:orange_terracotta
fill 487 282 490 487 282 491 minecraft:orange_terracotta
fill 487 282 492 488 282 492 minecraft:red_terracotta
setblock 488 282 480 minecraft:orange_terracotta
fill 488 282 491 489 282 491 minecraft:orange_terracotta
fill 489 282 476 509 282 477 minecraft:red_terracotta
fill 489 282 478 494 282 478 minecraft:orange_terracotta
fill 489 282 492 494 282 492 minecraft:orange_terracotta
fill 494 282 491 496 282 491 minecraft:orange_terracotta
schedule function dropper:buildpart/118_10 1t
