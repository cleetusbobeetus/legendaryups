setblock 292 276 257 minecraft:tuff
fill 292 276 258 293 276 258 minecraft:blackstone
fill 292 276 267 296 276 268 minecraft:blackstone
fill 293 276 231 304 276 231 minecraft:blackstone
setblock 293 276 233 minecraft:tuff
setblock 293 276 239 minecraft:magma_block
setblock 293 276 257 minecraft:magma_block
setblock 293 276 259 minecraft:tuff
fill 294 276 233 305 276 233 minecraft:blackstone
setblock 294 276 235 minecraft:tuff
setblock 294 276 237 minecraft:blackstone
fill 294 276 238 295 276 238 minecraft:magma_block
fill 294 276 258 295 276 258 minecraft:magma_block
fill 294 276 259 295 276 259 minecraft:basalt
setblock 294 276 261 minecraft:tuff
fill 295 276 235 306 276 235 minecraft:blackstone
setblock 295 276 237 minecraft:tuff
fill 295 276 261 306 276 261 minecraft:blackstone
setblock 295 276 263 minecraft:tuff
setblock 296 276 237 minecraft:shroomlight
setblock 296 276 259 minecraft:shroomlight
fill 296 276 262 300 276 263 minecraft:blackstone
setblock 296 276 265 minecraft:tuff
setblock 297 276 237 minecraft:magma_block
setblock 297 276 259 minecraft:magma_block
fill 297 276 265 308 276 265 minecraft:blackstone
setblock 297 276 267 minecraft:tuff
fill 297 276 268 303 277 268 minecraft:blackstone
setblock 298 276 230 minecraft:tuff
fill 298 276 236 300 276 236 minecraft:magma_block
fill 298 276 260 300 276 260 minecraft:magma_block
setblock 298 276 269 minecraft:tuff
fill 299 276 230 310 276 230 minecraft:blackstone
setblock 299 276 232 minecraft:tuff
fill 299 276 269 310 276 269 minecraft:basalt
setblock 300 276 234 minecraft:tuff
fill 301 276 234 312 276 234 minecraft:basalt
setblock 301 276 236 minecraft:shroomlight
setblock 301 276 260 minecraft:shroomlight
setblock 301 276 262 minecraft:tuff
fill 301 276 263 307 277 263 minecraft:blackstone
fill 302 276 236 304 276 236 minecraft:magma_block
fill 302 276 260 304 276 260 minecraft:magma_block
setblock 302 276 264 minecraft:tuff
fill 303 276 264 314 276 264 minecraft:basalt
setblock 303 276 266 minecraft:tuff
setblock 304 276 229 minecraft:tuff
fill 304 276 266 315 276 266 minecraft:blackstone
setblock 304 276 268 minecraft:tuff
fill 305 276 229 316 276 229 minecraft:basalt
setblock 305 276 231 minecraft:tuff
fill 305 276 236 313 276 236 minecraft:blackstone
setblock 305 276 237 minecraft:magma_block
setblock 305 276 259 minecraft:magma_block
fill 305 276 260 312 276 260 minecraft:blackstone
fill 305 276 267 309 276 268 minecraft:blackstone
fill 306 276 231 317 276 231 minecraft:blackstone
setblock 306 276 233 minecraft:tuff
setblock 306 276 237 minecraft:shroomlight
fill 306 276 239 306 276 240 minecraft:blackstone
setblock 306 276 259 minecraft:shroomlight
fill 307 276 232 311 276 233 minecraft:blackstone
setblock 307 276 235 minecraft:tuff
setblock 307 276 237 minecraft:blackstone
fill 307 276 238 308 276 238 minecraft:magma_block
fill 307 276 241 307 276 242 minecraft:blackstone
fill 307 276 258 308 276 258 minecraft:magma_block
fill 307 276 259 318 276 259 minecraft:basalt
setblock 307 276 261 minecraft:tuff
fill 308 276 235 315 276 235 minecraft:blackstone
setblock 308 276 237 minecraft:tuff
fill 308 276 239 308 300 239 minecraft:basalt
fill 308 276 243 311 276 243 minecraft:blackstone
fill 308 276 261 319 276 261 minecraft:blackstone
setblock 308 276 263 minecraft:tuff
setblock 309 276 228 minecraft:magma_block
fill 309 276 237 314 276 238 minecraft:blackstone
setblock 309 276 239 minecraft:magma_block
fill 309 276 240 309 300 240 minecraft:basalt
setblock 309 276 257 minecraft:magma_block
fill 309 276 258 311 276 258 minecraft:blackstone
fill 309 276 262 313 276 263 minecraft:blackstone
setblock 309 276 265 minecraft:tuff
fill 310 276 239 321 276 239 minecraft:basalt
setblock 310 276 240 minecraft:magma_block
fill 310 276 241 310 300 241 minecraft:basalt
setblock 310 276 256 minecraft:magma_block
fill 310 276 257 317 276 257 minecraft:blackstone
fill 310 276 265 317 276 265 minecraft:blackstone
setblock 310 276 267 minecraft:tuff
fill 310 276 268 316 277 268 minecraft:blackstone
setblock 311 276 230 minecraft:tuff
fill 311 276 240 315 276 240 minecraft:blackstone
fill 311 276 241 311 276 242 minecraft:magma_block
fill 311 276 254 311 276 255 minecraft:magma_block
setblock 311 276 256 minecraft:tuff
setblock 311 276 269 minecraft:tuff
fill 312 276 230 319 276 230 minecraft:blackstone
setblock 312 276 232 minecraft:tuff
fill 312 276 233 318 277 233 minecraft:blackstone
fill 312 276 241 316 276 242 minecraft:blackstone
fill 312 276 243 312 276 244 minecraft:magma_block
fill 312 276 252 312 276 253 minecraft:magma_block
fill 312 276 254 322 276 254 minecraft:basalt
fill 312 276 255 316 276 256 minecraft:blackstone
setblock 312 276 258 minecraft:tuff
fill 312 276 269 323 276 269 minecraft:basalt
setblock 313 276 234 minecraft:tuff
fill 313 276 243 323 276 243 minecraft:blackstone
fill 313 276 244 317 276 244 minecraft:basalt
fill 313 276 245 313 277 245 minecraft:shroomlight
fill 313 276 246 313 276 250 minecraft:magma_block
fill 313 276 251 313 277 251 minecraft:shroomlight
fill 313 276 252 315 276 253 minecraft:blackstone
fill 313 276 258 323 276 258 minecraft:blackstone
setblock 313 276 260 minecraft:tuff
fill 314 276 234 323 276 234 minecraft:basalt
setblock 314 276 236 minecraft:tuff
fill 314 276 245 318 276 246 minecraft:blackstone
fill 314 276 248 319 276 248 minecraft:blackstone
setblock 314 276 249 minecraft:tuff
fill 314 276 250 314 276 251 minecraft:blackstone
fill 314 276 260 321 276 260 minecraft:blackstone
setblock 314 276 262 minecraft:tuff
fill 314 276 263 320 277 263 minecraft:blackstone
fill 315 276 236 316 277 237 minecraft:blackstone
setblock 315 276 238 minecraft:tuff
fill 315 276 249 323 276 249 minecraft:basalt
fill 315 276 250 316 276 250 minecraft:blackstone
setblock 315 276 251 minecraft:tuff
setblock 315 276 264 minecraft:tuff
fill 316 276 238 323 276 238 minecraft:blackstone
setblock 316 276 240 minecraft:tuff
setblock 316 276 253 minecraft:tuff
fill 316 276 264 323 276 264 minecraft:basalt
setblock 316 276 266 minecraft:tuff
setblock 317 276 229 minecraft:tuff
fill 317 276 240 320 276 241 minecraft:blackstone
setblock 317 276 242 minecraft:tuff
fill 317 276 252 321 276 253 minecraft:blackstone
setblock 317 276 255 minecraft:tuff
fill 317 276 256 319 277 256 minecraft:blackstone
fill 317 276 266 318 277 266 minecraft:blackstone
setblock 317 276 268 minecraft:tuff
fill 318 276 229 323 276 229 minecraft:basalt
setblock 318 276 231 minecraft:tuff
fill 318 276 237 320 277 237 minecraft:blackstone
fill 318 276 242 323 276 242 minecraft:blackstone
setblock 318 276 244 minecraft:tuff
fill 318 276 255 320 276 255 minecraft:blackstone
setblock 318 276 257 minecraft:tuff
fill 318 276 267 318 278 268 minecraft:blackstone
fill 319 276 231 321 277 231 minecraft:blackstone
setblock 319 276 233 minecraft:tuff
setblock 319 276 235 minecraft:blackstone
fill 319 276 244 323 276 244 minecraft:basalt
fill 319 276 245 320 276 245 minecraft:blackstone
setblock 319 276 246 minecraft:tuff
fill 319 276 257 323 276 257 minecraft:blackstone
setblock 319 276 259 minecraft:tuff
fill 319 276 268 323 276 268 minecraft:blackstone
fill 320 276 232 320 278 233 minecraft:blackstone
setblock 320 276 235 minecraft:tuff
setblock 320 276 248 minecraft:tuff
setblock 320 276 250 minecraft:blackstone
fill 320 276 259 323 276 259 minecraft:basalt
setblock 320 276 261 minecraft:tuff
fill 320 276 267 322 277 267 minecraft:blackstone
fill 321 276 233 323 278 233 minecraft:blackstone
fill 321 276 235 322 276 235 minecraft:blackstone
setblock 321 276 237 minecraft:tuff
fill 321 276 241 322 277 241 minecraft:blackstone
fill 321 276 247 321 278 248 minecraft:blackstone
setblock 321 276 250 minecraft:tuff
fill 321 276 261 322 277 261 minecraft:blackstone
setblock 321 276 263 minecraft:tuff
setblock 321 276 265 minecraft:blackstone
fill 322 276 236 322 277 237 minecraft:blackstone
setblock 322 276 239 minecraft:tuff
fill 322 276 248 323 278 248 minecraft:blackstone
fill 322 276 250 323 276 250 minecraft:blackstone
setblock 322 276 252 minecraft:tuff
fill 322 276 253 323 279 253 minecraft:blackstone
fill 322 276 262 322 278 263 minecraft:blackstone
setblock 322 276 265 minecraft:tuff
fill 323 276 237 323 278 237 minecraft:blackstone
setblock 323 276 239 minecraft:basalt
setblock 323 276 241 minecraft:tuff
fill 323 276 251 323 277 252 minecraft:blackstone
setblock 323 276 254 minecraft:tuff
fill 323 276 263 323 278 263 minecraft:blackstone
setblock 323 276 265 minecraft:blackstone
setblock 323 276 267 minecraft:tuff
fill 282 277 231 283 277 231 minecraft:blackstone
setblock 283 277 229 minecraft:tuff
fill 283 277 230 289 277 230 minecraft:basalt
fill 283 277 232 284 277 234 minecraft:blackstone
fill 283 277 235 285 277 235 minecraft:basalt
fill 283 277 236 286 277 237 minecraft:blackstone
fill 283 277 239 287 278 239 minecraft:blackstone
fill 283 277 240 290 277 240 minecraft:basalt
fill 283 277 241 284 277 241 minecraft:blackstone
setblock 283 277 242 minecraft:tuff
fill 283 277 244 283 280 244 minecraft:blackstone
fill 283 277 245 288 277 245 minecraft:basalt
fill 283 277 246 284 277 249 minecraft:blackstone
fill 283 277 250 286 277 250 minecraft:basalt
fill 283 277 251 287 277 254 minecraft:blackstone
setblock 283 277 255 minecraft:tuff
fill 283 277 256 283 277 257 minecraft:blackstone
fill 283 277 259 284 280 259 minecraft:blackstone
fill 283 277 260 291 277 260 minecraft:basalt
fill 283 277 262 286 277 264 minecraft:blackstone
fill 283 277 265 287 277 265 minecraft:basalt
fill 283 277 266 288 277 267 minecraft:blackstone
setblock 283 277 268 minecraft:tuff
fill 283 277 269 289 278 269 minecraft:blackstone
fill 284 277 229 295 277 229 minecraft:blackstone
setblock 284 277 231 minecraft:tuff
fill 284 277 242 285 278 242 minecraft:blackstone
setblock 284 277 244 minecraft:tuff
fill 284 277 255 289 277 255 minecraft:basalt
fill 284 277 256 289 277 256 minecraft:blackstone
setblock 284 277 257 minecraft:tuff
fill 284 277 261 285 277 261 minecraft:blackstone
fill 285 277 231 290 277 232 minecraft:blackstone
setblock 285 277 233 minecraft:tuff
fill 285 277 234 291 278 234 minecraft:blackstone
fill 285 277 243 285 279 244 minecraft:blackstone
setblock 285 277 246 minecraft:tuff
fill 285 277 247 285 277 249 minecraft:blackstone
fill 285 277 257 291 277 257 minecraft:blackstone
setblock 285 277 259 minecraft:tuff
setblock 286 277 235 minecraft:tuff
fill 286 277 244 288 277 244 minecraft:blackstone
fill 286 277 246 287 277 247 minecraft:blackstone
setblock 286 277 248 minecraft:tuff
fill 286 277 249 287 278 249 minecraft:blackstone
fill 286 277 258 290 277 259 minecraft:blackstone
setblock 286 277 261 minecraft:tuff
fill 287 277 235 298 277 235 minecraft:basalt
fill 287 277 236 292 277 236 minecraft:blackstone
setblock 287 277 237 minecraft:tuff
fill 287 277 241 288 277 243 minecraft:blackstone
fill 287 277 248 287 278 248 minecraft:blackstone
setblock 287 277 250 minecraft:tuff
fill 287 277 261 292 277 262 minecraft:blackstone
setblock 287 277 263 minecraft:tuff
fill 287 277 264 293 278 264 minecraft:blackstone
fill 288 277 237 293 277 237 minecraft:blackstone
setblock 288 277 239 minecraft:tuff
fill 288 277 246 288 278 250 minecraft:netherrack
setblock 288 277 251 minecraft:blackstone
setblock 288 277 252 minecraft:tuff
fill 288 277 253 288 278 254 minecraft:blackstone
setblock 288 277 265 minecraft:tuff
fill 289 277 238 291 277 239 minecraft:blackstone
setblock 289 277 241 minecraft:tuff
setblock 289 277 242 minecraft:blackstone
fill 289 277 243 289 277 244 minecraft:netherrack
fill 289 277 247 289 300 249 minecraft:basalt
fill 289 277 252 289 277 253 minecraft:netherrack
setblock 289 277 254 minecraft:tuff
fill 289 277 265 300 277 265 minecraft:basalt
fill 289 277 266 294 277 266 minecraft:blackstone
setblock 289 277 267 minecraft:tuff
setblock 290 277 230 minecraft:tuff
fill 290 277 241 290 277 242 minecraft:netherrack
fill 290 277 254 290 277 255 minecraft:netherrack
setblock 290 277 256 minecraft:tuff
fill 290 277 267 301 277 267 minecraft:blackstone
setblock 290 277 269 minecraft:tuff
fill 291 277 230 302 277 230 minecraft:basalt
fill 291 277 231 296 277 231 minecraft:blackstone
setblock 291 277 232 minecraft:tuff
setblock 291 277 240 minecraft:shroomlight
setblock 291 277 256 minecraft:shroomlight
setblock 291 277 258 minecraft:tuff
fill 291 277 259 293 277 259 minecraft:blackstone
fill 291 277 268 295 277 269 minecraft:blackstone
setblock 292 277 234 minecraft:tuff
setblock 292 277 238 minecraft:blackstone
setblock 292 277 239 minecraft:netherrack
setblock 292 277 257 minecraft:netherrack
setblock 292 277 258 minecraft:blackstone
setblock 292 277 260 minecraft:tuff
fill 293 277 233 297 277 234 minecraft:blackstone
setblock 293 277 236 minecraft:tuff
setblock 293 277 238 minecraft:netherrack
setblock 293 277 258 minecraft:netherrack
fill 293 277 260 295 277 260 minecraft:basalt
fill 293 277 261 298 277 261 minecraft:blackstone
setblock 293 277 262 minecraft:tuff
fill 294 277 236 295 277 236 minecraft:blackstone
fill 294 277 237 295 277 237 minecraft:netherrack
fill 294 277 259 295 277 259 minecraft:netherrack
fill 294 277 262 305 277 262 minecraft:blackstone
setblock 294 277 264 minecraft:tuff
fill 295 277 263 299 277 264 minecraft:blackstone
setblock 295 277 266 minecraft:tuff
setblock 296 277 229 minecraft:tuff
fill 296 277 236 298 277 236 minecraft:netherrack
fill 296 277 260 298 277 260 minecraft:netherrack
fill 296 277 266 307 277 266 minecraft:blackstone
setblock 296 277 268 minecraft:tuff
fill 296 277 269 302 278 269 minecraft:blackstone
fill 297 277 229 308 277 229 minecraft:blackstone
setblock 297 277 231 minecraft:tuff
fill 298 277 231 309 277 231 minecraft:blackstone
setblock 298 277 233 minecraft:tuff
fill 298 277 234 304 278 234 minecraft:blackstone
fill 299 277 232 303 277 233 minecraft:blackstone
fill 299 277 235 300 278 235 minecraft:netherrack
fill 299 277 261 300 278 261 minecraft:netherrack
setblock 300 277 263 minecraft:tuff
fill 300 277 264 306 278 264 minecraft:blackstone
fill 301 277 235 301 278 235 minecraft:shroomlight
fill 301 277 261 301 278 261 minecraft:shroomlight
setblock 301 277 265 minecraft:tuff
fill 302 277 235 303 278 235 minecraft:netherrack
fill 302 277 261 303 278 261 minecraft:netherrack
fill 302 277 265 313 277 265 minecraft:basalt
setblock 302 277 267 minecraft:tuff
setblock 303 277 230 minecraft:tuff
fill 303 277 267 314 277 267 minecraft:blackstone
setblock 303 277 269 minecraft:tuff
fill 304 277 230 315 277 230 minecraft:basalt
setblock 304 277 232 minecraft:tuff
fill 304 277 233 310 278 233 minecraft:blackstone
fill 304 277 235 311 277 235 minecraft:basalt
fill 304 277 236 306 277 236 minecraft:netherrack
fill 304 277 260 306 277 260 minecraft:netherrack
fill 304 277 261 311 277 261 minecraft:blackstone
fill 304 277 268 308 277 269 minecraft:blackstone
fill 305 277 232 316 277 232 minecraft:blackstone
setblock 305 277 234 minecraft:tuff
setblock 305 277 270 minecraft:magma_block
fill 306 277 234 317 277 234 minecraft:blackstone
setblock 306 277 262 minecraft:tuff
fill 307 277 236 314 277 236 minecraft:blackstone
fill 307 277 237 308 277 237 minecraft:netherrack
fill 307 277 259 308 277 259 minecraft:netherrack
fill 307 277 260 317 277 260 minecraft:basalt
fill 307 277 262 318 277 262 minecraft:blackstone
setblock 307 277 264 minecraft:tuff
fill 308 277 263 312 277 264 minecraft:blackstone
setblock 308 277 266 minecraft:tuff
fill 309 277 228 309 283 228 minecraft:blackstone
setblock 309 277 229 minecraft:tuff
fill 309 277 237 312 277 237 minecraft:blackstone
setblock 309 277 238 minecraft:netherrack
fill 309 277 239 309 300 239 minecraft:basalt
setblock 309 277 258 minecraft:netherrack
fill 309 277 259 310 277 259 minecraft:blackstone
fill 309 277 266 316 277 266 minecraft:blackstone
setblock 309 277 268 minecraft:tuff
fill 309 277 269 315 278 269 minecraft:blackstone
fill 310 277 229 321 277 229 minecraft:blackstone
setblock 310 277 231 minecraft:tuff
fill 310 277 238 319 277 238 minecraft:blackstone
setblock 310 277 239 minecraft:netherrack
fill 310 277 240 310 300 240 minecraft:basalt
setblock 310 277 257 minecraft:netherrack
fill 310 277 258 316 277 258 minecraft:blackstone
fill 311 277 231 318 277 231 minecraft:blackstone
setblock 311 277 233 minecraft:tuff
fill 311 277 239 313 277 239 minecraft:blackstone
setblock 311 277 240 minecraft:shroomlight
fill 311 277 241 311 300 241 minecraft:basalt
setblock 311 277 256 minecraft:shroomlight
fill 311 277 257 322 277 257 minecraft:blackstone
setblock 311 277 259 minecraft:tuff
setblock 312 277 235 minecraft:tuff
fill 312 277 240 320 277 240 minecraft:basalt
fill 312 277 241 312 277 242 minecraft:netherrack
fill 312 277 254 312 277 255 minecraft:netherrack
fill 312 277 256 315 277 256 minecraft:blackstone
fill 312 277 259 323 277 259 minecraft:blackstone
setblock 312 277 261 minecraft:tuff
fill 313 277 235 323 277 235 minecraft:basalt
setblock 313 277 237 minecraft:tuff
fill 313 277 241 314 277 242 minecraft:blackstone
fill 313 277 243 313 277 244 minecraft:netherrack
fill 313 277 252 313 277 253 minecraft:netherrack
fill 313 277 254 314 277 254 minecraft:blackstone
fill 313 277 255 321 277 255 minecraft:basalt
fill 313 277 261 320 277 261 minecraft:blackstone
setblock 313 277 263 minecraft:tuff
fill 313 277 264 319 278 264 minecraft:blackstone
fill 314 277 237 314 278 237 minecraft:blackstone
setblock 314 277 239 minecraft:tuff
fill 314 277 243 315 277 244 minecraft:blackstone
fill 314 277 245 316 277 245 minecraft:basalt
fill 314 277 246 314 278 250 minecraft:netherrack
fill 314 277 251 315 277 251 minecraft:blackstone
setblock 314 277 252 minecraft:tuff
fill 314 277 253 320 278 253 minecraft:blackstone
setblock 314 277 265 minecraft:tuff
fill 315 277 239 323 277 239 minecraft:blackstone
setblock 315 277 241 minecraft:tuff
fill 315 277 242 321 278 242 minecraft:blackstone
fill 315 277 246 317 277 249 minecraft:blackstone
fill 315 277 250 323 277 250 minecraft:basalt
fill 315 277 252 315 278 252 minecraft:blackstone
setblock 315 277 254 minecraft:tuff
fill 315 277 265 323 277 265 minecraft:basalt
setblock 315 277 267 minecraft:tuff
setblock 316 277 230 minecraft:tuff
fill 316 277 241 320 277 241 minecraft:blackstone
setblock 316 277 243 minecraft:tuff
fill 316 277 244 322 278 244 minecraft:blackstone
fill 316 277 254 323 277 254 minecraft:blackstone
setblock 316 277 256 minecraft:tuff
fill 316 277 267 317 278 267 minecraft:blackstone
setblock 316 277 269 minecraft:tuff
fill 317 277 230 323 277 230 minecraft:basalt
setblock 317 277 232 minecraft:tuff
fill 317 277 243 323 277 243 minecraft:blackstone
setblock 317 277 245 minecraft:tuff
fill 317 277 251 319 277 252 minecraft:blackstone
setblock 317 277 258 minecraft:tuff
fill 317 277 268 317 279 269 minecraft:blackstone
fill 318 277 232 319 278 232 minecraft:blackstone
setblock 318 277 234 minecraft:tuff
setblock 318 277 236 minecraft:blackstone
fill 318 277 245 323 277 245 minecraft:basalt
fill 318 277 246 319 277 246 minecraft:blackstone
setblock 318 277 247 minecraft:tuff
fill 318 277 248 318 279 249 minecraft:blackstone
fill 318 277 258 323 277 258 minecraft:blackstone
setblock 318 277 260 minecraft:tuff
fill 318 277 269 323 277 269 minecraft:blackstone
fill 319 277 233 319 279 234 minecraft:blackstone
setblock 319 277 236 minecraft:tuff
fill 319 277 247 320 278 248 minecraft:blackstone
setblock 319 277 249 minecraft:tuff
fill 319 277 260 323 277 260 minecraft:basalt
setblock 319 277 262 minecraft:tuff
fill 319 277 268 321 278 268 minecraft:blackstone
fill 320 277 234 323 277 234 minecraft:blackstone
fill 320 277 236 321 277 236 minecraft:blackstone
setblock 320 277 238 minecraft:tuff
fill 320 277 249 323 279 249 minecraft:blackstone
setblock 320 277 251 minecraft:tuff
fill 320 277 252 322 278 252 minecraft:blackstone
fill 320 277 262 321 278 262 minecraft:blackstone
setblock 320 277 264 minecraft:tuff
setblock 320 277 266 minecraft:blackstone
fill 321 277 237 321 278 238 minecraft:blackstone
setblock 321 277 240 minecraft:tuff
fill 321 277 251 322 277 251 minecraft:blackstone
setblock 321 277 253 minecraft:tuff
fill 321 277 263 321 279 264 minecraft:blackstone
setblock 321 277 266 minecraft:tuff
setblock 322 277 229 minecraft:tuff
setblock 322 277 231 minecraft:blackstone
fill 322 277 238 323 279 238 minecraft:blackstone
fill 322 277 240 323 277 240 minecraft:basalt
setblock 322 277 242 minecraft:tuff
setblock 322 277 255 minecraft:tuff
fill 322 277 264 323 279 264 minecraft:blackstone
fill 322 277 266 323 277 266 minecraft:blackstone
setblock 322 277 268 minecraft:tuff
fill 323 277 229 323 278 229 minecraft:blackstone
setblock 323 277 231 minecraft:tuff
setblock 323 277 236 minecraft:blackstone
fill 323 277 241 323 277 242 minecraft:blackstone
setblock 323 277 244 minecraft:tuff
setblock 323 277 255 minecraft:basalt
setblock 323 277 257 minecraft:tuff
fill 323 277 267 323 278 268 minecraft:blackstone
setblock 324 277 249 minecraft:magma_block
fill 282 278 231 282 283 231 minecraft:blackstone
fill 283 278 229 287 278 230 minecraft:blackstone
fill 283 278 231 288 278 231 minecraft:basalt
setblock 283 278 232 minecraft:tuff
fill 283 278 233 283 278 235 minecraft:blackstone
fill 283 278 236 284 278 236 minecraft:basalt
fill 283 278 237 285 278 238 minecraft:blackstone
fill 283 278 240 286 279 240 minecraft:blackstone
fill 283 278 241 289 278 241 minecraft:basalt
setblock 283 278 242 minecraft:blackstone
setblock 283 278 245 minecraft:tuff
fill 283 278 246 287 278 246 minecraft:basalt
fill 283 278 247 283 278 250 minecraft:blackstone
fill 283 278 251 285 278 251 minecraft:basalt
fill 283 278 252 286 278 255 minecraft:blackstone
fill 283 278 256 289 278 256 minecraft:basalt
fill 283 278 257 288 278 257 minecraft:blackstone
setblock 283 278 258 minecraft:tuff
fill 283 278 260 283 281 260 minecraft:blackstone
fill 283 278 261 290 278 261 minecraft:basalt
fill 283 278 262 284 278 265 minecraft:blackstone
fill 283 278 266 286 278 266 minecraft:basalt
fill 283 278 267 287 278 268 minecraft:blackstone
fill 284 278 232 289 278 233 minecraft:blackstone
setblock 284 278 234 minecraft:tuff
fill 284 278 235 290 279 235 minecraft:blackstone
fill 284 278 244 284 280 245 minecraft:blackstone
setblock 284 278 247 minecraft:tuff
fill 284 278 248 284 278 250 minecraft:blackstone
fill 284 278 258 291 278 258 minecraft:blackstone
setblock 284 278 260 minecraft:tuff
setblock 285 278 236 minecraft:tuff
fill 285 278 245 287 278 245 minecraft:blackstone
fill 285 278 247 286 278 248 minecraft:blackstone
setblock 285 278 249 minecraft:tuff
fill 285 278 250 287 278 250 minecraft:blackstone
fill 285 278 259 289 278 260 minecraft:blackstone
setblock 285 278 262 minecraft:tuff
fill 285 278 263 285 278 265 minecraft:blackstone
fill 286 278 236 294 278 236 minecraft:basalt
fill 286 278 237 291 278 237 minecraft:blackstone
setblock 286 278 238 minecraft:tuff
fill 286 278 244 287 279 244 minecraft:blackstone
setblock 286 278 251 minecraft:tuff
fill 286 278 262 291 278 263 minecraft:blackstone
setblock 286 278 264 minecraft:tuff
fill 286 278 265 292 279 265 minecraft:blackstone
fill 287 278 238 291 278 238 minecraft:blackstone
setblock 287 278 240 minecraft:tuff
fill 287 278 242 287 278 243 minecraft:blackstone
setblock 287 278 247 minecraft:blackstone
setblock 287 278 251 minecraft:basalt
setblock 287 278 252 minecraft:blackstone
setblock 287 278 253 minecraft:tuff
fill 287 278 254 287 280 255 minecraft:blackstone
setblock 287 278 266 minecraft:tuff
setblock 288 278 229 minecraft:tuff
fill 288 278 230 294 279 230 minecraft:blackstone
fill 288 278 239 289 280 240 minecraft:blackstone
setblock 288 278 242 minecraft:tuff
setblock 288 278 243 minecraft:blackstone
fill 288 278 244 288 279 244 minecraft:netherrack
setblock 288 278 245 minecraft:shroomlight
setblock 288 278 251 minecraft:shroomlight
fill 288 278 252 288 279 252 minecraft:netherrack
setblock 288 278 255 minecraft:tuff
fill 288 278 266 299 278 266 minecraft:basalt
fill 288 278 267 293 278 267 minecraft:blackstone
setblock 288 278 268 minecraft:tuff
fill 289 278 229 300 278 229 minecraft:blackstone
setblock 289 278 231 minecraft:tuff
fill 289 278 242 289 278 243 minecraft:netherrack
fill 289 278 253 289 278 254 minecraft:netherrack
setblock 289 278 255 minecraft:blackstone
setblock 289 278 257 minecraft:tuff
fill 289 278 268 300 278 268 minecraft:blackstone
fill 290 278 231 301 278 231 minecraft:basalt
fill 290 278 232 295 278 232 minecraft:blackstone
setblock 290 278 233 minecraft:tuff
setblock 290 278 239 minecraft:blackstone
fill 290 278 240 290 278 241 minecraft:netherrack
fill 290 278 255 290 278 256 minecraft:netherrack
setblock 290 278 257 minecraft:blackstone
setblock 290 278 259 minecraft:tuff
fill 290 278 260 294 278 260 minecraft:blackstone
fill 290 278 269 294 279 269 minecraft:blackstone
fill 291 278 233 302 278 233 minecraft:blackstone
setblock 291 278 235 minecraft:tuff
setblock 291 278 239 minecraft:netherrack
setblock 291 278 257 minecraft:netherrack
fill 291 278 259 292 278 259 minecraft:blackstone
setblock 291 278 261 minecraft:tuff
fill 292 278 234 296 278 235 minecraft:blackstone
setblock 292 278 237 minecraft:tuff
setblock 292 278 238 minecraft:netherrack
setblock 292 278 258 minecraft:netherrack
fill 292 278 261 296 278 261 minecraft:basalt
fill 292 278 262 297 278 262 minecraft:blackstone
setblock 292 278 263 minecraft:tuff
fill 293 278 237 294 278 237 minecraft:netherrack
fill 293 278 259 294 278 259 minecraft:netherrack
fill 293 278 263 304 278 263 minecraft:blackstone
setblock 293 278 265 minecraft:tuff
fill 294 278 264 298 278 265 minecraft:blackstone
setblock 294 278 267 minecraft:tuff
setblock 295 278 230 minecraft:tuff
setblock 295 278 236 minecraft:shroomlight
setblock 295 278 260 minecraft:shroomlight
fill 295 278 267 306 278 267 minecraft:blackstone
setblock 295 278 269 minecraft:tuff
fill 296 278 230 307 278 230 minecraft:blackstone
setblock 296 278 232 minecraft:tuff
setblock 296 278 236 minecraft:netherrack
setblock 296 278 260 minecraft:netherrack
fill 297 278 232 308 278 232 minecraft:blackstone
setblock 297 278 234 minecraft:tuff
fill 297 278 235 298 278 235 minecraft:netherrack
fill 297 278 261 298 278 261 minecraft:netherrack
setblock 298 278 262 minecraft:tuff
fill 299 278 262 310 278 262 minecraft:blackstone
setblock 299 278 264 minecraft:tuff
fill 299 278 265 305 279 265 minecraft:blackstone
setblock 300 278 266 minecraft:tuff
setblock 301 278 229 minecraft:tuff
fill 301 278 266 312 278 266 minecraft:basalt
setblock 301 278 268 minecraft:tuff
fill 302 278 229 313 278 229 minecraft:blackstone
setblock 302 278 231 minecraft:tuff
fill 302 278 268 313 278 268 minecraft:blackstone
fill 303 278 231 314 278 231 minecraft:basalt
setblock 303 278 233 minecraft:tuff
fill 303 278 269 307 279 269 minecraft:blackstone
fill 304 278 235 305 278 235 minecraft:netherrack
fill 304 278 261 305 278 261 minecraft:netherrack
fill 305 278 234 309 279 234 minecraft:blackstone
setblock 305 278 263 minecraft:tuff
fill 305 278 270 305 283 270 minecraft:blackstone
fill 306 278 235 316 278 235 minecraft:blackstone
setblock 306 278 236 minecraft:netherrack
setblock 306 278 260 minecraft:netherrack
fill 306 278 261 316 278 261 minecraft:basalt
fill 306 278 263 317 278 263 minecraft:blackstone
setblock 306 278 265 minecraft:tuff
setblock 307 278 236 minecraft:shroomlight
setblock 307 278 260 minecraft:shroomlight
fill 307 278 264 311 278 265 minecraft:blackstone
setblock 307 278 267 minecraft:tuff
setblock 308 278 230 minecraft:tuff
fill 308 278 236 310 278 236 minecraft:basalt
fill 308 278 237 309 278 237 minecraft:netherrack
fill 308 278 259 309 278 259 minecraft:netherrack
fill 308 278 260 309 278 260 minecraft:blackstone
fill 308 278 267 315 278 267 minecraft:blackstone
setblock 308 278 269 minecraft:tuff
fill 309 278 230 320 278 230 minecraft:blackstone
setblock 309 278 232 minecraft:tuff
fill 309 278 238 309 300 238 minecraft:basalt
fill 310 278 232 317 278 232 minecraft:blackstone
setblock 310 278 234 minecraft:tuff
fill 310 278 237 313 278 237 minecraft:blackstone
setblock 310 278 238 minecraft:netherrack
fill 310 278 239 310 300 239 minecraft:basalt
setblock 310 278 258 minecraft:netherrack
fill 310 278 259 315 278 259 minecraft:blackstone
setblock 310 278 260 minecraft:tuff
fill 311 278 233 315 278 234 minecraft:blackstone
setblock 311 278 236 minecraft:tuff
setblock 311 278 238 minecraft:blackstone
setblock 311 278 239 minecraft:netherrack
fill 311 278 240 311 300 240 minecraft:basalt
setblock 311 278 257 minecraft:netherrack
fill 311 278 258 321 278 258 minecraft:blackstone
fill 311 278 260 322 278 260 minecraft:blackstone
setblock 311 278 262 minecraft:tuff
fill 312 278 236 323 278 236 minecraft:basalt
setblock 312 278 238 minecraft:tuff
fill 312 278 239 318 278 239 minecraft:blackstone
fill 312 278 240 312 278 241 minecraft:netherrack
fill 312 278 255 312 278 256 minecraft:netherrack
fill 312 278 257 314 278 257 minecraft:blackstone
fill 312 278 262 319 278 262 minecraft:blackstone
setblock 312 278 264 minecraft:tuff
fill 312 278 265 318 279 265 minecraft:blackstone
fill 313 278 238 320 278 238 minecraft:blackstone
setblock 313 278 240 minecraft:tuff
fill 313 278 241 319 278 241 minecraft:basalt
fill 313 278 242 313 278 243 minecraft:netherrack
fill 313 278 253 313 278 254 minecraft:netherrack
setblock 313 278 255 minecraft:blackstone
fill 313 278 256 320 278 256 minecraft:basalt
setblock 313 278 266 minecraft:tuff
setblock 314 278 229 minecraft:tuff
fill 314 278 240 323 278 240 minecraft:blackstone
setblock 314 278 242 minecraft:tuff
fill 314 278 243 320 278 243 minecraft:blackstone
fill 314 278 244 314 279 244 minecraft:netherrack
setblock 314 278 245 minecraft:shroomlight
setblock 314 278 251 minecraft:shroomlight
fill 314 278 252 314 279 252 minecraft:netherrack
fill 314 278 254 319 278 254 minecraft:blackstone
setblock 314 278 255 minecraft:tuff
fill 314 278 266 323 278 266 minecraft:basalt
setblock 314 278 268 minecraft:tuff
fill 315 278 229 322 278 229 minecraft:blackstone
setblock 315 278 231 minecraft:tuff
fill 315 278 237 317 278 237 minecraft:blackstone
setblock 315 278 244 minecraft:tuff
fill 315 278 245 321 278 245 minecraft:blackstone
setblock 315 278 246 minecraft:basalt
fill 315 278 247 316 278 250 minecraft:blackstone
fill 315 278 251 323 278 251 minecraft:basalt
fill 315 278 255 323 278 255 minecraft:blackstone
setblock 315 278 257 minecraft:tuff
fill 315 278 268 316 279 268 minecraft:blackstone
fill 316 278 231 323 278 231 minecraft:basalt
setblock 316 278 233 minecraft:tuff
fill 316 278 234 318 280 234 minecraft:blackstone
setblock 316 278 246 minecraft:tuff
fill 316 278 252 318 278 252 minecraft:blackstone
fill 316 278 257 323 278 257 minecraft:blackstone
setblock 316 278 259 minecraft:tuff
fill 316 278 269 316 280 269 minecraft:blackstone
fill 317 278 233 318 279 233 minecraft:blackstone
setblock 317 278 235 minecraft:tuff
fill 317 278 246 323 278 246 minecraft:basalt
fill 317 278 247 318 278 247 minecraft:blackstone
setblock 317 278 248 minecraft:tuff
fill 317 278 249 317 280 250 minecraft:blackstone
fill 317 278 259 323 278 259 minecraft:blackstone
setblock 317 278 261 minecraft:tuff
fill 318 278 235 323 278 235 minecraft:blackstone
setblock 318 278 237 minecraft:tuff
setblock 318 278 250 minecraft:tuff
fill 318 278 261 323 278 261 minecraft:basalt
setblock 318 278 263 minecraft:tuff
fill 318 278 269 320 279 269 minecraft:blackstone
fill 319 278 237 320 278 237 minecraft:blackstone
setblock 319 278 239 minecraft:tuff
fill 319 278 249 319 280 250 minecraft:blackstone
setblock 319 278 252 minecraft:tuff
fill 319 278 263 320 279 263 minecraft:blackstone
setblock 319 278 265 minecraft:tuff
setblock 319 278 267 minecraft:blackstone
fill 320 278 234 322 279 234 minecraft:blackstone
fill 320 278 239 323 280 239 minecraft:blackstone
setblock 320 278 241 minecraft:tuff
fill 320 278 250 323 278 250 minecraft:blackstone
setblock 320 278 254 minecraft:tuff
fill 320 278 264 320 280 265 minecraft:blackstone
setblock 320 278 267 minecraft:tuff
setblock 321 278 230 minecraft:tuff
setblock 321 278 232 minecraft:blackstone
fill 321 278 241 323 278 241 minecraft:basalt
setblock 321 278 243 minecraft:tuff
fill 321 278 253 321 279 254 minecraft:blackstone
setblock 321 278 256 minecraft:tuff
fill 321 278 265 323 279 265 minecraft:blackstone
fill 321 278 267 322 278 267 minecraft:blackstone
setblock 321 278 269 minecraft:tuff
fill 322 278 230 323 278 230 minecraft:blackstone
setblock 322 278 232 minecraft:tuff
setblock 322 278 237 minecraft:blackstone
fill 322 278 242 323 278 243 minecraft:blackstone
setblock 322 278 245 minecraft:tuff
setblock 322 278 247 minecraft:blackstone
fill 322 278 254 323 280 254 minecraft:blackstone
fill 322 278 256 323 278 256 minecraft:basalt
setblock 322 278 258 minecraft:tuff
fill 322 278 268 322 278 269 minecraft:blackstone
setblock 323 278 232 minecraft:blackstone
setblock 323 278 234 minecraft:tuff
fill 323 278 244 323 280 245 minecraft:blackstone
setblock 323 278 247 minecraft:tuff
setblock 323 278 252 minecraft:blackstone
fill 323 278 258 323 279 258 minecraft:blackstone
setblock 323 278 260 minecraft:tuff
setblock 323 278 262 minecraft:blackstone
setblock 323 278 269 minecraft:blackstone
fill 324 278 249 324 283 249 minecraft:blackstone
fill 283 279 231 293 279 231 minecraft:blackstone
fill 283 279 232 287 279 232 minecraft:basalt
fill 283 279 233 288 279 234 minecraft:blackstone
setblock 283 279 235 minecraft:tuff
fill 283 279 236 289 280 236 minecraft:blackstone
setblock 283 279 237 minecraft:basalt
fill 283 279 238 284 279 239 minecraft:blackstone
fill 283 279 241 285 280 241 minecraft:blackstone
fill 283 279 242 288 279 242 minecraft:basalt
fill 283 279 245 283 281 246 minecraft:blackstone
fill 283 279 247 286 279 247 minecraft:basalt
setblock 283 279 248 minecraft:tuff
fill 283 279 249 283 279 251 minecraft:blackstone
fill 283 279 252 284 279 252 minecraft:basalt
fill 283 279 253 285 279 256 minecraft:blackstone
fill 283 279 257 289 279 257 minecraft:basalt
fill 283 279 258 287 279 258 minecraft:blackstone
setblock 283 279 261 minecraft:tuff
fill 283 279 262 289 279 262 minecraft:basalt
fill 283 279 263 283 279 266 minecraft:blackstone
fill 283 279 267 285 279 267 minecraft:basalt
fill 284 279 230 286 279 230 minecraft:blackstone
setblock 284 279 237 minecraft:tuff
fill 284 279 246 286 281 246 minecraft:blackstone
fill 284 279 248 286 279 249 minecraft:blackstone
setblock 284 279 250 minecraft:tuff
fill 284 279 251 286 281 251 minecraft:blackstone
fill 284 279 260 288 279 261 minecraft:blackstone
setblock 284 279 263 minecraft:tuff
fill 284 279 264 284 279 266 minecraft:blackstone
fill 284 279 268 292 279 268 minecraft:blackstone
fill 285 279 229 292 279 229 minecraft:blackstone
fill 285 279 237 291 279 237 minecraft:basalt
fill 285 279 238 290 279 238 minecraft:blackstone
setblock 285 279 239 minecraft:tuff
fill 285 279 245 286 280 245 minecraft:blackstone
fill 285 279 250 286 281 250 minecraft:blackstone
setblock 285 279 252 minecraft:tuff
fill 285 279 259 291 279 259 minecraft:blackstone
fill 285 279 263 290 279 264 minecraft:blackstone
setblock 285 279 265 minecraft:tuff
fill 285 279 266 291 280 266 minecraft:blackstone
fill 285 279 269 286 279 269 minecraft:blackstone
fill 286 279 239 287 280 239 minecraft:blackstone
setblock 286 279 241 minecraft:tuff
setblock 286 279 243 minecraft:blackstone
fill 286 279 252 287 279 252 minecraft:basalt
fill 286 279 253 287 279 253 minecraft:blackstone
setblock 286 279 254 minecraft:tuff
fill 286 279 255 286 281 256 minecraft:blackstone
setblock 286 279 267 minecraft:tuff
fill 287 279 228 288 283 228 minecraft:blackstone
setblock 287 279 230 minecraft:tuff
fill 287 279 240 287 281 241 minecraft:blackstone
setblock 287 279 243 minecraft:tuff
fill 287 279 245 287 280 245 minecraft:shroomlight
fill 287 279 246 287 279 250 minecraft:netherrack
fill 287 279 251 287 280 251 minecraft:shroomlight
setblock 287 279 256 minecraft:tuff
fill 287 279 267 298 279 267 minecraft:basalt
setblock 287 279 269 minecraft:tuff
setblock 288 279 232 minecraft:tuff
fill 288 279 241 288 280 241 minecraft:blackstone
setblock 288 279 243 minecraft:netherrack
fill 288 279 246 288 300 250 minecraft:basalt
fill 288 279 253 288 279 254 minecraft:netherrack
fill 288 279 255 288 279 256 minecraft:blackstone
setblock 288 279 258 minecraft:tuff
fill 288 279 269 289 280 269 minecraft:blackstone
setblock 289 279 228 minecraft:magma_block
fill 289 279 232 300 279 232 minecraft:basalt
fill 289 279 233 294 279 233 minecraft:blackstone
setblock 289 279 234 minecraft:tuff
setblock 289 279 241 minecraft:netherrack
setblock 289 279 255 minecraft:netherrack
setblock 289 279 256 minecraft:blackstone
fill 289 279 258 290 279 258 minecraft:blackstone
setblock 289 279 260 minecraft:tuff
fill 289 279 261 294 279 261 minecraft:blackstone
fill 290 279 234 297 279 234 minecraft:blackstone
setblock 290 279 236 minecraft:tuff
fill 290 279 239 290 280 239 minecraft:shroomlight
setblock 290 279 240 minecraft:netherrack
setblock 290 279 256 minecraft:netherrack
fill 290 279 257 290 280 257 minecraft:shroomlight
fill 290 279 260 293 279 260 minecraft:blackstone
setblock 290 279 262 minecraft:tuff
fill 291 279 235 293 279 236 minecraft:blackstone
setblock 291 279 238 minecraft:netherrack
setblock 291 279 258 minecraft:netherrack
fill 291 279 262 297 279 262 minecraft:basalt
fill 291 279 263 296 279 263 minecraft:blackstone
setblock 291 279 264 minecraft:tuff
fill 292 279 237 293 279 237 minecraft:netherrack
setblock 292 279 238 minecraft:light[level=12]
setblock 292 279 245 minecraft:light[level=12]
setblock 292 279 252 minecraft:light[level=12]
fill 292 279 259 293 279 259 minecraft:netherrack
fill 292 279 264 303 279 264 minecraft:blackstone
setblock 292 279 266 minecraft:tuff
setblock 293 279 229 minecraft:tuff
fill 293 279 265 297 279 266 minecraft:blackstone
setblock 293 279 268 minecraft:tuff
fill 294 279 229 305 279 229 minecraft:blackstone
setblock 294 279 231 minecraft:tuff
fill 294 279 235 294 280 235 minecraft:blackstone
setblock 294 279 236 minecraft:netherrack
setblock 294 279 260 minecraft:netherrack
fill 294 279 268 305 279 268 minecraft:blackstone
fill 295 279 230 299 279 231 minecraft:blackstone
setblock 295 279 233 minecraft:tuff
fill 295 279 235 295 280 235 minecraft:shroomlight
fill 295 279 261 295 280 261 minecraft:shroomlight
fill 295 279 269 299 280 269 minecraft:blackstone
fill 296 279 233 307 279 233 minecraft:blackstone
fill 296 279 235 297 279 235 minecraft:netherrack
fill 296 279 261 297 279 261 minecraft:netherrack
setblock 296 279 270 minecraft:magma_block
setblock 297 279 263 minecraft:tuff
fill 297 279 270 297 283 270 minecraft:blackstone
fill 298 279 234 300 279 234 minecraft:netherrack
fill 298 279 262 300 279 262 minecraft:netherrack
fill 298 279 263 309 279 263 minecraft:blackstone
setblock 298 279 265 minecraft:tuff
fill 298 279 266 304 280 266 minecraft:blackstone
setblock 299 279 238 minecraft:light[level=12]
setblock 299 279 245 minecraft:light[level=12]
setblock 299 279 252 minecraft:light[level=12]
setblock 299 279 259 minecraft:light[level=12]
setblock 299 279 267 minecraft:tuff
setblock 300 279 230 minecraft:tuff
fill 300 279 231 306 280 231 minecraft:blackstone
fill 300 279 267 311 279 267 minecraft:basalt
setblock 300 279 269 minecraft:tuff
fill 301 279 230 312 279 230 minecraft:blackstone
setblock 301 279 232 minecraft:tuff
setblock 301 279 234 minecraft:shroomlight
setblock 301 279 262 minecraft:shroomlight
fill 301 279 269 302 280 269 minecraft:blackstone
fill 302 279 232 313 279 232 minecraft:basalt
fill 302 279 234 304 279 234 minecraft:netherrack
fill 302 279 262 304 279 262 minecraft:netherrack
setblock 304 279 264 minecraft:tuff
fill 305 279 235 306 279 235 minecraft:netherrack
fill 305 279 261 306 279 261 minecraft:netherrack
fill 305 279 262 315 279 262 minecraft:basalt
fill 305 279 264 316 279 264 minecraft:blackstone
setblock 305 279 266 minecraft:tuff
setblock 306 279 229 minecraft:tuff
setblock 306 279 238 minecraft:light[level=12]
setblock 306 279 245 minecraft:light[level=12]
setblock 306 279 252 minecraft:light[level=12]
setblock 306 279 259 minecraft:light[level=12]
fill 306 279 265 310 279 266 minecraft:blackstone
setblock 306 279 268 minecraft:tuff
fill 307 279 229 318 279 229 minecraft:blackstone
setblock 307 279 231 minecraft:tuff
fill 307 279 235 307 280 235 minecraft:shroomlight
fill 307 279 261 307 280 261 minecraft:shroomlight
fill 307 279 268 314 279 268 minecraft:blackstone
fill 308 279 231 319 279 231 minecraft:blackstone
setblock 308 279 233 minecraft:tuff
setblock 308 279 235 minecraft:blackstone
setblock 308 279 236 minecraft:netherrack
setblock 308 279 260 minecraft:netherrack
setblock 308 279 261 minecraft:blackstone
fill 308 279 269 312 280 269 minecraft:blackstone
fill 309 279 233 316 279 233 minecraft:blackstone
setblock 309 279 235 minecraft:tuff
fill 309 279 236 315 279 236 minecraft:blackstone
fill 309 279 237 310 279 237 minecraft:netherrack
fill 309 279 259 310 279 259 minecraft:netherrack
fill 309 279 260 314 279 260 minecraft:blackstone
setblock 309 279 261 minecraft:tuff
fill 310 279 234 314 279 235 minecraft:blackstone
fill 310 279 238 310 300 238 minecraft:basalt
fill 310 279 261 321 279 261 minecraft:blackstone
setblock 310 279 263 minecraft:tuff
fill 311 279 237 322 279 237 minecraft:basalt
setblock 311 279 238 minecraft:netherrack
fill 311 279 239 311 300 239 minecraft:basalt
setblock 311 279 258 minecraft:netherrack
fill 311 279 259 320 279 259 minecraft:blackstone
fill 311 279 263 318 279 263 minecraft:blackstone
setblock 311 279 265 minecraft:tuff
fill 311 279 266 317 280 266 minecraft:blackstone
fill 312 279 238 316 279 238 minecraft:blackstone
fill 312 279 239 312 280 239 minecraft:shroomlight
setblock 312 279 240 minecraft:netherrack
fill 312 279 241 312 300 241 minecraft:basalt
setblock 312 279 256 minecraft:netherrack
fill 312 279 257 312 280 257 minecraft:shroomlight
fill 312 279 258 313 279 258 minecraft:blackstone
setblock 312 279 267 minecraft:tuff
setblock 313 279 230 minecraft:tuff
fill 313 279 239 317 279 240 minecraft:blackstone
setblock 313 279 241 minecraft:netherrack
setblock 313 279 245 minecraft:light[level=12]
setblock 313 279 252 minecraft:light[level=12]
setblock 313 279 255 minecraft:netherrack
setblock 313 279 256 minecraft:tuff
fill 313 279 257 319 279 257 minecraft:basalt
fill 313 279 267 323 279 267 minecraft:basalt
setblock 313 279 269 minecraft:tuff
fill 314 279 230 322 279 230 minecraft:blackstone
setblock 314 279 232 minecraft:tuff
fill 314 279 241 323 279 241 minecraft:blackstone
fill 314 279 242 314 279 243 minecraft:netherrack
fill 314 279 253 314 279 254 minecraft:netherrack
fill 314 279 255 318 279 256 minecraft:blackstone
setblock 314 279 258 minecraft:tuff
fill 314 279 269 315 280 269 minecraft:blackstone
fill 315 279 232 323 279 232 minecraft:basalt
setblock 315 279 234 minecraft:tuff
fill 315 279 235 321 280 235 minecraft:blackstone
fill 315 279 242 318 279 242 minecraft:basalt
fill 315 279 243 319 279 244 minecraft:blackstone
fill 315 279 245 315 280 245 minecraft:shroomlight
fill 315 279 246 315 279 250 minecraft:netherrack
fill 315 279 251 315 280 251 minecraft:shroomlight
fill 315 279 252 323 279 252 minecraft:basalt
fill 315 279 253 317 279 254 minecraft:blackstone
fill 315 279 258 322 279 258 minecraft:blackstone
setblock 315 279 260 minecraft:tuff
setblock 316 279 236 minecraft:tuff
fill 316 279 245 320 279 246 minecraft:blackstone
fill 316 279 247 323 279 247 minecraft:basalt
fill 316 279 248 317 279 248 minecraft:blackstone
setblock 316 279 249 minecraft:tuff
fill 316 279 250 316 279 251 minecraft:blackstone
fill 316 279 260 323 279 260 minecraft:blackstone
setblock 316 279 262 minecraft:tuff
fill 317 279 236 323 279 236 minecraft:blackstone
setblock 317 279 238 minecraft:tuff
setblock 317 279 251 minecraft:tuff
fill 317 279 262 323 279 262 minecraft:basalt
setblock 317 279 264 minecraft:tuff
fill 318 279 238 319 279 239 minecraft:blackstone
setblock 318 279 240 minecraft:tuff
fill 318 279 250 318 281 251 minecraft:blackstone
setblock 318 279 253 minecraft:tuff
fill 318 279 254 320 280 254 minecraft:blackstone
fill 318 279 264 319 280 264 minecraft:blackstone
setblock 318 279 266 minecraft:tuff
setblock 318 279 268 minecraft:blackstone
setblock 319 279 229 minecraft:tuff
fill 319 279 240 323 279 240 minecraft:blackstone
setblock 319 279 242 minecraft:tuff
fill 319 279 248 321 279 248 minecraft:blackstone
fill 319 279 251 323 279 251 minecraft:blackstone
fill 319 279 253 320 279 253 minecraft:blackstone
setblock 319 279 255 minecraft:tuff
fill 319 279 256 323 280 256 minecraft:blackstone
fill 319 279 265 319 281 266 minecraft:blackstone
setblock 319 279 268 minecraft:tuff
fill 320 279 229 321 279 229 minecraft:blackstone
setblock 320 279 231 minecraft:tuff
setblock 320 279 233 minecraft:blackstone
fill 320 279 238 321 279 238 minecraft:blackstone
fill 320 279 242 323 279 242 minecraft:basalt
fill 320 279 243 323 279 243 minecraft:blackstone
setblock 320 279 244 minecraft:tuff
fill 320 279 250 322 280 250 minecraft:blackstone
fill 320 279 255 323 281 255 minecraft:blackstone
setblock 320 279 257 minecraft:tuff
fill 320 279 266 323 279 266 minecraft:blackstone
fill 320 279 268 322 279 268 minecraft:blackstone
fill 321 279 231 324 279 231 minecraft:blackstone
setblock 321 279 233 minecraft:tuff
fill 321 279 244 322 280 245 minecraft:blackstone
setblock 321 279 246 minecraft:tuff
fill 321 279 257 323 279 257 minecraft:basalt
setblock 321 279 259 minecraft:tuff
setblock 321 279 269 minecraft:blackstone
fill 322 279 233 323 279 233 minecraft:blackstone
setblock 322 279 235 minecraft:tuff
fill 322 279 246 323 281 246 minecraft:blackstone
setblock 322 279 248 minecraft:tuff
fill 322 279 259 323 280 259 minecraft:blackstone
setblock 322 279 261 minecraft:tuff
setblock 322 279 263 minecraft:blackstone
fill 323 279 234 323 280 235 minecraft:blackstone
setblock 323 279 237 minecraft:tuff
setblock 323 279 248 minecraft:blackstone
setblock 323 279 250 minecraft:tuff
fill 323 279 261 323 281 261 minecraft:blackstone
setblock 323 279 263 minecraft:tuff
setblock 324 279 232 minecraft:shroomlight
fill 283 280 234 287 280 235 minecraft:blackstone
fill 283 280 237 288 281 237 minecraft:blackstone
setblock 283 280 238 minecraft:tuff
fill 283 280 239 283 280 240 minecraft:blackstone
fill 283 280 242 284 282 242 minecraft:blackstone
fill 283 280 243 287 280 243 minecraft:basalt
fill 283 280 247 286 280 247 minecraft:blackstone
fill 283 280 248 287 280 248 minecraft:basalt
fill 283 280 249 284 280 250 minecraft:blackstone
setblock 283 280 251 minecraft:tuff
fill 283 280 252 286 282 252 minecraft:blackstone
setblock 283 280 253 minecraft:basalt
fill 283 280 254 284 280 257 minecraft:blackstone
fill 283 280 258 289 280 258 minecraft:basalt
fill 283 280 261 287 280 262 minecraft:blackstone
fill 283 280 263 288 280 263 minecraft:basalt
setblock 283 280 264 minecraft:tuff
fill 284 280 233 286 280 233 minecraft:basalt
fill 284 280 238 290 280 238 minecraft:basalt
fill 284 280 239 285 280 239 minecraft:blackstone
setblock 284 280 240 minecraft:tuff
setblock 284 280 253 minecraft:tuff
fill 284 280 260 292 280 260 minecraft:blackstone
fill 284 280 264 289 280 265 minecraft:blackstone
fill 285 280 232 292 280 232 minecraft:blackstone
fill 285 280 240 286 281 240 minecraft:blackstone
setblock 285 280 242 minecraft:tuff
setblock 285 280 244 minecraft:blackstone
fill 285 280 249 286 280 249 minecraft:blackstone
fill 285 280 253 286 280 253 minecraft:basalt
fill 285 280 254 286 280 254 minecraft:blackstone
setblock 285 280 255 minecraft:tuff
fill 285 280 256 285 282 257 minecraft:blackstone
fill 285 280 259 286 280 259 minecraft:blackstone
setblock 286 280 231 minecraft:tuff
fill 286 280 241 286 282 242 minecraft:blackstone
setblock 286 280 244 minecraft:tuff
setblock 286 280 257 minecraft:tuff
fill 286 280 267 290 280 267 minecraft:blackstone
fill 287 280 230 291 280 231 minecraft:blackstone
setblock 287 280 233 minecraft:tuff
fill 287 280 242 288 280 242 minecraft:blackstone
setblock 287 280 244 minecraft:blackstone
fill 287 280 246 287 300 247 minecraft:basalt
fill 287 280 249 287 300 249 minecraft:basalt
fill 287 280 252 287 280 253 minecraft:magma_block
fill 287 280 256 288 281 257 minecraft:blackstone
setblock 287 280 259 minecraft:tuff
fill 287 280 268 297 280 268 minecraft:basalt
fill 288 280 229 297 280 229 minecraft:blackstone
fill 288 280 233 298 280 233 minecraft:basalt
fill 288 280 234 293 280 234 minecraft:blackstone
setblock 288 280 235 minecraft:tuff
fill 288 280 254 288 280 255 minecraft:magma_block
fill 288 280 259 290 280 259 minecraft:blackstone
setblock 288 280 261 minecraft:tuff
fill 288 280 262 294 280 262 minecraft:blackstone
fill 289 280 228 289 283 228 minecraft:blackstone
fill 289 280 235 293 280 235 minecraft:blackstone
setblock 289 280 237 minecraft:tuff
setblock 289 280 256 minecraft:magma_block
setblock 289 280 257 minecraft:blackstone
fill 289 280 261 293 280 261 minecraft:blackstone
setblock 289 280 263 minecraft:tuff
fill 290 280 236 291 281 237 minecraft:blackstone
setblock 290 280 258 minecraft:magma_block
fill 290 280 263 298 280 263 minecraft:basalt
fill 290 280 264 295 280 264 minecraft:blackstone
setblock 290 280 265 minecraft:tuff
fill 290 280 269 291 280 269 minecraft:blackstone
fill 291 280 259 292 280 259 minecraft:magma_block
fill 291 280 265 302 280 265 minecraft:blackstone
setblock 291 280 267 minecraft:tuff
setblock 292 280 230 minecraft:tuff
fill 292 280 231 298 281 231 minecraft:blackstone
fill 292 280 236 292 281 236 minecraft:blackstone
setblock 292 280 237 minecraft:magma_block
fill 292 280 266 296 280 267 minecraft:blackstone
setblock 292 280 269 minecraft:tuff
fill 293 280 230 304 280 230 minecraft:blackstone
setblock 293 280 232 minecraft:tuff
setblock 293 280 236 minecraft:magma_block
setblock 293 280 260 minecraft:magma_block
fill 293 280 269 294 280 269 minecraft:blackstone
fill 294 280 232 305 280 232 minecraft:blackstone
setblock 294 280 234 minecraft:tuff
setblock 294 280 261 minecraft:magma_block
fill 295 280 234 296 280 234 minecraft:blackstone
setblock 295 280 262 minecraft:tuff
fill 296 280 262 298 280 262 minecraft:magma_block
setblock 296 280 264 minecraft:tuff
fill 296 280 270 296 283 270 minecraft:blackstone
fill 297 280 234 298 280 234 minecraft:magma_block
fill 297 280 264 308 280 264 minecraft:blackstone
setblock 297 280 266 minecraft:tuff
fill 297 280 267 303 281 267 minecraft:blackstone
setblock 298 280 229 minecraft:tuff
setblock 298 280 268 minecraft:tuff
fill 299 280 229 310 280 229 minecraft:blackstone
setblock 299 280 231 minecraft:tuff
fill 299 280 233 300 280 233 minecraft:magma_block
fill 299 280 263 300 280 263 minecraft:magma_block
fill 299 280 268 310 280 268 minecraft:basalt
setblock 300 280 269 minecraft:blackstone
setblock 300 280 270 minecraft:magma_block
fill 301 280 233 301 281 233 minecraft:shroomlight
fill 301 280 263 301 281 263 minecraft:shroomlight
fill 302 280 233 303 280 233 minecraft:magma_block
fill 302 280 263 303 280 263 minecraft:magma_block
setblock 303 280 265 minecraft:tuff
fill 303 280 269 304 280 269 minecraft:blackstone
fill 304 280 233 312 280 233 minecraft:basalt
fill 304 280 234 306 280 234 minecraft:magma_block
fill 304 280 262 306 280 262 minecraft:magma_block
fill 304 280 263 314 280 263 minecraft:basalt
fill 304 280 265 315 280 265 minecraft:blackstone
setblock 304 280 267 minecraft:tuff
setblock 305 280 230 minecraft:tuff
fill 305 280 266 309 280 267 minecraft:blackstone
setblock 305 280 269 minecraft:tuff
setblock 306 280 228 minecraft:magma_block
fill 306 280 230 317 280 230 minecraft:blackstone
setblock 306 280 232 minecraft:tuff
fill 306 280 269 307 280 269 minecraft:blackstone
fill 307 280 231 311 280 232 minecraft:blackstone
setblock 307 280 234 minecraft:tuff
setblock 307 280 262 minecraft:blackstone
fill 308 280 234 315 280 234 minecraft:blackstone
setblock 308 280 235 minecraft:magma_block
setblock 308 280 261 minecraft:magma_block
setblock 308 280 262 minecraft:tuff
setblock 308 280 270 minecraft:crying_obsidian
fill 309 280 235 313 280 235 minecraft:blackstone
setblock 309 280 236 minecraft:magma_block
setblock 309 280 260 minecraft:magma_block
fill 309 280 261 313 280 262 minecraft:blackstone
setblock 309 280 264 minecraft:tuff
fill 310 280 236 320 280 236 minecraft:blackstone
fill 310 280 237 311 280 237 minecraft:magma_block
fill 310 280 259 311 280 259 minecraft:magma_block
fill 310 280 260 319 280 260 minecraft:blackstone
fill 310 280 264 317 280 264 minecraft:blackstone
setblock 310 280 266 minecraft:tuff
fill 310 280 267 316 281 267 minecraft:blackstone
setblock 311 280 229 minecraft:tuff
fill 311 280 238 311 300 238 minecraft:basalt
setblock 311 280 268 minecraft:tuff
fill 312 280 229 318 280 229 minecraft:blackstone
setblock 312 280 231 minecraft:tuff
fill 312 280 232 318 281 232 minecraft:blackstone
fill 312 280 237 314 281 237 minecraft:blackstone
setblock 312 280 238 minecraft:magma_block
fill 312 280 240 312 300 240 minecraft:basalt
setblock 312 280 258 minecraft:magma_block
setblock 312 280 259 minecraft:blackstone
fill 312 280 268 319 280 268 minecraft:basalt
fill 313 280 231 320 280 231 minecraft:blackstone
setblock 313 280 233 minecraft:tuff
fill 313 280 238 321 280 238 minecraft:basalt
fill 313 280 239 315 280 239 minecraft:blackstone
setblock 313 280 240 minecraft:magma_block
setblock 313 280 256 minecraft:magma_block
fill 313 280 257 323 280 257 minecraft:blackstone
fill 313 280 258 318 280 258 minecraft:basalt
setblock 313 280 259 minecraft:tuff
setblock 313 280 269 minecraft:blackstone
fill 314 280 233 322 280 233 minecraft:basalt
setblock 314 280 235 minecraft:tuff
fill 314 280 240 322 280 240 minecraft:blackstone
fill 314 280 241 314 280 242 minecraft:magma_block
fill 314 280 254 314 280 255 minecraft:magma_block
fill 314 280 256 317 280 256 minecraft:blackstone
fill 314 280 259 321 280 259 minecraft:blackstone
setblock 314 280 261 minecraft:tuff
fill 314 280 262 320 281 262 minecraft:blackstone
setblock 315 280 237 minecraft:tuff
fill 315 280 241 316 280 242 minecraft:blackstone
fill 315 280 243 315 280 244 minecraft:magma_block
fill 315 280 252 315 280 253 minecraft:magma_block
fill 315 280 254 316 280 255 minecraft:blackstone
fill 315 280 261 322 280 261 minecraft:blackstone
setblock 315 280 263 minecraft:tuff
fill 316 280 237 323 280 237 minecraft:blackstone
setblock 316 280 239 minecraft:tuff
fill 316 280 243 317 280 243 minecraft:basalt
fill 316 280 244 318 280 245 minecraft:blackstone
fill 316 280 246 316 280 250 minecraft:magma_block
fill 316 280 251 317 280 251 minecraft:blackstone
setblock 316 280 252 minecraft:tuff
fill 316 280 253 322 280 253 minecraft:basalt
fill 316 280 263 323 280 263 minecraft:basalt
setblock 316 280 265 minecraft:tuff
fill 317 280 239 319 280 239 minecraft:blackstone
setblock 317 280 241 minecraft:tuff
fill 317 280 242 323 281 242 minecraft:blackstone
fill 317 280 246 319 280 247 minecraft:blackstone
fill 317 280 248 323 280 248 minecraft:basalt
fill 317 280 252 323 280 252 minecraft:blackstone
setblock 317 280 254 minecraft:tuff
fill 317 280 255 319 281 255 minecraft:blackstone
fill 317 280 265 318 281 265 minecraft:blackstone
setblock 317 280 267 minecraft:tuff
setblock 317 280 269 minecraft:blackstone
setblock 318 280 230 minecraft:tuff
fill 318 280 241 323 280 241 minecraft:blackstone
setblock 318 280 243 minecraft:tuff
setblock 318 280 249 minecraft:blackstone
setblock 318 280 256 minecraft:tuff
fill 318 280 266 318 280 267 minecraft:blackstone
setblock 318 280 269 minecraft:tuff
setblock 319 280 230 minecraft:blackstone
setblock 319 280 232 minecraft:tuff
setblock 319 280 234 minecraft:blackstone
fill 319 280 243 323 280 243 minecraft:basalt
fill 319 280 244 320 280 244 minecraft:blackstone
setblock 319 280 245 minecraft:tuff
fill 319 280 251 321 281 251 minecraft:blackstone
setblock 319 280 258 minecraft:tuff
fill 319 280 267 320 280 267 minecraft:blackstone
fill 320 280 232 321 280 232 minecraft:blackstone
setblock 320 280 234 minecraft:tuff
fill 320 280 245 320 281 246 minecraft:blackstone
setblock 320 280 247 minecraft:tuff
setblock 320 280 249 minecraft:blackstone
fill 320 280 258 323 280 258 minecraft:basalt
setblock 320 280 260 minecraft:tuff
fill 320 280 266 321 280 266 minecraft:blackstone
fill 321 280 234 322 280 234 minecraft:blackstone
setblock 321 280 236 minecraft:tuff
fill 321 280 246 321 282 247 minecraft:blackstone
setblock 321 280 249 minecraft:tuff
setblock 321 280 254 minecraft:blackstone
fill 321 280 260 323 281 260 minecraft:blackstone
setblock 321 280 262 minecraft:tuff
fill 321 280 264 321 280 265 minecraft:blackstone
fill 322 280 235 322 280 236 minecraft:blackstone
setblock 322 280 238 minecraft:tuff
fill 322 280 247 323 282 247 minecraft:blackstone
fill 322 280 249 323 280 249 minecraft:blackstone
setblock 322 280 251 minecraft:tuff
fill 322 280 262 323 280 262 minecraft:blackstone
setblock 322 280 264 minecraft:tuff
setblock 322 280 265 minecraft:blackstone
setblock 323 280 236 minecraft:blackstone
setblock 323 280 238 minecraft:basalt
setblock 323 280 240 minecraft:tuff
fill 323 280 250 323 281 251 minecraft:blackstone
setblock 323 280 253 minecraft:tuff
setblock 323 280 264 minecraft:blackstone
fill 324 280 231 324 283 232 minecraft:blackstone
fill 283 281 238 287 281 238 minecraft:blackstone
fill 283 281 239 289 281 239 minecraft:basalt
fill 283 281 240 284 281 240 minecraft:blackstone
setblock 283 281 241 minecraft:tuff
fill 283 281 243 283 282 243 minecraft:blackstone
fill 283 281 244 286 281 244 minecraft:basalt
fill 283 281 247 285 281 248 minecraft:blackstone
fill 283 281 249 286 281 249 minecraft:basalt
fill 283 281 250 283 281 251 minecraft:blackstone
fill 283 281 253 286 282 253 minecraft:blackstone
setblock 283 281 254 minecraft:tuff
fill 283 281 255 283 281 258 minecraft:blackstone
fill 283 281 259 290 281 259 minecraft:basalt
fill 283 281 261 292 281 261 minecraft:blackstone
fill 284 281 236 286 281 236 minecraft:blackstone
fill 284 281 241 285 282 241 minecraft:blackstone
setblock 284 281 243 minecraft:tuff
setblock 284 281 245 minecraft:blackstone
setblock 284 281 250 minecraft:blackstone
fill 284 281 254 287 281 254 minecraft:basalt
fill 284 281 255 285 281 255 minecraft:blackstone
setblock 284 281 256 minecraft:tuff
fill 284 281 257 284 282 258 minecraft:blackstone
fill 284 281 260 285 281 260 minecraft:blackstone
fill 284 281 262 286 281 262 minecraft:blackstone
setblock 285 281 231 minecraft:light[level=12]
fill 285 281 235 292 281 235 minecraft:blackstone
fill 285 281 242 285 283 243 minecraft:blackstone
setblock 285 281 245 minecraft:tuff
setblock 285 281 258 minecraft:tuff
fill 285 281 263 293 281 263 minecraft:blackstone
fill 286 281 233 291 281 233 minecraft:blackstone
setblock 286 281 234 minecraft:tuff
fill 286 281 243 287 281 243 minecraft:blackstone
setblock 286 281 245 minecraft:blackstone
setblock 286 281 247 minecraft:tuff
setblock 286 281 248 minecraft:blackstone
fill 286 281 257 286 283 258 minecraft:blackstone
setblock 286 281 260 minecraft:tuff
fill 286 281 264 287 281 264 minecraft:basalt
fill 286 281 265 294 281 265 minecraft:blackstone
fill 287 281 232 297 281 232 minecraft:blackstone
fill 287 281 234 296 281 234 minecraft:basalt
setblock 287 281 236 minecraft:tuff
setblock 287 281 242 minecraft:blackstone
fill 287 281 248 287 300 248 minecraft:basalt
setblock 287 281 253 minecraft:netherrack
setblock 287 281 255 minecraft:blackstone
fill 287 281 258 289 282 258 minecraft:blackstone
fill 287 281 260 291 281 260 minecraft:blackstone
setblock 287 281 262 minecraft:tuff
fill 287 281 266 288 281 266 minecraft:blackstone
fill 288 281 236 289 282 236 minecraft:blackstone
setblock 288 281 238 minecraft:tuff
setblock 288 281 240 minecraft:blackstone
fill 288 281 262 293 281 262 minecraft:blackstone
setblock 288 281 264 minecraft:tuff
fill 289 281 231 290 281 231 minecraft:blackstone
fill 289 281 237 289 282 238 minecraft:blackstone
setblock 289 281 257 minecraft:shroomlight
fill 289 281 264 300 281 264 minecraft:basalt
setblock 289 281 266 minecraft:tuff
fill 289 281 267 295 281 267 minecraft:blackstone
fill 290 281 230 296 281 230 minecraft:blackstone
setblock 290 281 238 minecraft:blackstone
setblock 290 281 258 minecraft:netherrack
fill 290 281 266 301 281 266 minecraft:blackstone
setblock 290 281 268 minecraft:tuff
fill 291 281 229 302 281 229 minecraft:basalt
setblock 291 281 231 minecraft:tuff
setblock 291 281 259 minecraft:netherrack
fill 291 281 268 302 281 268 minecraft:blackstone
fill 291 281 269 296 281 269 minecraft:basalt
setblock 292 281 233 minecraft:tuff
setblock 292 281 260 minecraft:netherrack
fill 293 281 233 298 281 233 minecraft:blackstone
setblock 293 281 235 minecraft:tuff
setblock 293 281 239 minecraft:light[level=12]
setblock 293 281 247 minecraft:light[level=12]
setblock 293 281 255 minecraft:light[level=12]
setblock 293 281 261 minecraft:netherrack
fill 294 281 262 294 282 262 minecraft:shroomlight
setblock 294 281 263 minecraft:tuff
fill 295 281 262 296 281 262 minecraft:netherrack
fill 295 281 263 296 281 263 minecraft:blackstone
setblock 295 281 265 minecraft:tuff
fill 296 281 265 307 281 265 minecraft:blackstone
setblock 296 281 267 minecraft:tuff
setblock 297 281 230 minecraft:tuff
fill 297 281 263 300 281 263 minecraft:netherrack
setblock 297 281 269 minecraft:tuff
fill 298 281 230 309 281 230 minecraft:blackstone
setblock 298 281 232 minecraft:tuff
fill 298 281 269 309 281 269 minecraft:basalt
fill 299 281 231 303 281 232 minecraft:blackstone
fill 299 281 233 300 281 233 minecraft:netherrack
fill 300 281 270 300 283 270 minecraft:blackstone
setblock 301 281 239 minecraft:light[level=12]
setblock 301 281 255 minecraft:light[level=12]
setblock 301 281 264 minecraft:tuff
fill 302 281 233 305 281 233 minecraft:netherrack
fill 302 281 263 305 281 263 minecraft:netherrack
fill 302 281 264 313 281 264 minecraft:basalt
setblock 302 281 266 minecraft:tuff
setblock 303 281 229 minecraft:tuff
fill 303 281 266 314 281 266 minecraft:blackstone
setblock 303 281 268 minecraft:tuff
fill 304 281 229 315 281 229 minecraft:basalt
setblock 304 281 231 minecraft:tuff
fill 304 281 232 310 282 232 minecraft:blackstone
fill 304 281 267 308 281 268 minecraft:blackstone
fill 305 281 231 316 281 231 minecraft:blackstone
fill 306 281 228 306 283 228 minecraft:blackstone
fill 306 281 233 317 281 233 minecraft:blackstone
fill 306 281 234 307 281 234 minecraft:netherrack
fill 306 281 262 307 281 262 minecraft:netherrack
setblock 306 281 263 minecraft:blackstone
setblock 307 281 263 minecraft:tuff
fill 308 281 234 308 282 234 minecraft:shroomlight
fill 308 281 262 308 282 262 minecraft:shroomlight
fill 308 281 263 319 281 263 minecraft:blackstone
setblock 308 281 265 minecraft:tuff
fill 308 281 270 308 283 270 minecraft:blackstone
fill 309 281 234 311 281 234 minecraft:basalt
setblock 309 281 235 minecraft:netherrack
setblock 309 281 247 minecraft:light[level=12]
setblock 309 281 255 minecraft:light[level=12]
setblock 309 281 261 minecraft:netherrack
fill 309 281 262 312 281 262 minecraft:blackstone
fill 309 281 265 316 281 265 minecraft:blackstone
setblock 309 281 267 minecraft:tuff
fill 309 281 268 315 281 268 minecraft:blackstone
setblock 310 281 230 minecraft:tuff
fill 310 281 235 318 281 235 minecraft:blackstone
setblock 310 281 236 minecraft:netherrack
setblock 310 281 260 minecraft:netherrack
fill 310 281 261 318 281 261 minecraft:blackstone
setblock 310 281 269 minecraft:tuff
fill 311 281 230 316 281 230 minecraft:blackstone
setblock 311 281 232 minecraft:tuff
fill 311 281 236 312 281 236 minecraft:blackstone
setblock 311 281 237 minecraft:netherrack
setblock 311 281 259 minecraft:netherrack
setblock 311 281 260 minecraft:blackstone
fill 311 281 269 315 281 269 minecraft:basalt
setblock 312 281 234 minecraft:tuff
setblock 312 281 238 minecraft:netherrack
fill 312 281 239 312 300 239 minecraft:basalt
setblock 312 281 258 minecraft:netherrack
fill 312 281 259 317 281 259 minecraft:basalt
setblock 312 281 260 minecraft:tuff
fill 313 281 234 320 281 234 minecraft:basalt
setblock 313 281 236 minecraft:tuff
setblock 313 281 238 minecraft:blackstone
setblock 313 281 239 minecraft:shroomlight
setblock 313 281 257 minecraft:shroomlight
fill 313 281 258 323 281 258 minecraft:blackstone
fill 313 281 260 320 281 260 minecraft:blackstone
setblock 313 281 262 minecraft:tuff
fill 314 281 236 322 281 236 minecraft:blackstone
setblock 314 281 238 minecraft:tuff
fill 314 281 239 320 281 239 minecraft:basalt
setblock 314 281 240 minecraft:netherrack
setblock 314 281 256 minecraft:netherrack
fill 314 281 257 316 281 257 minecraft:blackstone
setblock 314 281 264 minecraft:tuff
fill 315 281 237 319 281 238 minecraft:blackstone
setblock 315 281 240 minecraft:tuff
fill 315 281 241 315 281 243 minecraft:netherrack
fill 315 281 253 315 281 255 minecraft:netherrack
fill 315 281 256 322 281 256 minecraft:blackstone
fill 315 281 264 320 281 264 minecraft:basalt
setblock 315 281 266 minecraft:tuff
fill 316 281 240 321 281 241 minecraft:blackstone
setblock 316 281 242 minecraft:tuff
fill 316 281 243 322 281 243 minecraft:blackstone
fill 316 281 244 316 282 244 minecraft:netherrack
setblock 316 281 245 minecraft:shroomlight
fill 316 281 246 316 281 250 minecraft:netherrack
setblock 316 281 251 minecraft:shroomlight
fill 316 281 252 316 282 252 minecraft:netherrack
fill 316 281 253 323 281 253 minecraft:blackstone
fill 316 281 254 321 281 254 minecraft:basalt
setblock 316 281 255 minecraft:tuff
fill 316 281 266 318 281 266 minecraft:blackstone
setblock 316 281 268 minecraft:tuff
setblock 317 281 231 minecraft:tuff
setblock 317 281 244 minecraft:tuff
fill 317 281 245 317 281 248 minecraft:blackstone
fill 317 281 249 323 281 249 minecraft:basalt
fill 317 281 250 317 281 252 minecraft:blackstone
setblock 317 281 257 minecraft:tuff
setblock 317 281 267 minecraft:blackstone
setblock 318 281 233 minecraft:tuff
fill 318 281 244 323 281 244 minecraft:basalt
fill 318 281 245 319 281 245 minecraft:blackstone
setblock 318 281 246 minecraft:tuff
fill 318 281 247 318 282 248 minecraft:blackstone
fill 318 281 252 320 282 252 minecraft:blackstone
fill 318 281 257 323 281 257 minecraft:blackstone
setblock 318 281 259 minecraft:tuff
fill 319 281 232 319 281 233 minecraft:blackstone
setblock 319 281 235 minecraft:tuff
fill 319 281 246 319 282 247 minecraft:blackstone
setblock 319 281 248 minecraft:tuff
setblock 319 281 250 minecraft:blackstone
fill 319 281 259 323 281 259 minecraft:basalt
setblock 319 281 261 minecraft:tuff
setblock 320 281 233 minecraft:blackstone
fill 320 281 235 321 281 235 minecraft:blackstone
setblock 320 281 237 minecraft:tuff
fill 320 281 238 323 281 238 minecraft:blackstone
fill 320 281 247 320 282 248 minecraft:blackstone
setblock 320 281 250 minecraft:tuff
fill 320 281 261 322 281 261 minecraft:blackstone
setblock 320 281 263 minecraft:tuff
setblock 320 281 265 minecraft:blackstone
fill 321 281 237 323 281 237 minecraft:blackstone
setblock 321 281 239 minecraft:tuff
fill 321 281 245 323 281 245 minecraft:blackstone
fill 321 281 248 323 282 248 minecraft:blackstone
fill 321 281 250 322 281 250 minecraft:blackstone
setblock 321 281 252 minecraft:tuff
fill 321 281 262 321 281 263 minecraft:blackstone
fill 322 281 239 323 281 239 minecraft:basalt
fill 322 281 240 324 281 240 minecraft:blackstone
setblock 322 281 241 minecraft:tuff
fill 322 281 251 322 282 252 minecraft:blackstone
setblock 322 281 254 minecraft:tuff
setblock 322 281 262 minecraft:blackstone
fill 323 281 241 324 282 241 minecraft:blackstone
setblock 323 281 243 minecraft:tuff
fill 323 281 252 323 282 252 minecraft:blackstone
setblock 323 281 254 minecraft:basalt
setblock 323 281 256 minecraft:tuff
setblock 324 281 242 minecraft:crying_obsidian
setblock 282 282 241 minecraft:magma_block
setblock 283 282 241 minecraft:blackstone
setblock 283 282 244 minecraft:tuff
fill 283 282 245 285 282 245 minecraft:basalt
fill 283 282 246 283 282 249 minecraft:blackstone
fill 283 282 250 285 282 250 minecraft:basalt
fill 283 282 251 285 282 251 minecraft:blackstone
fill 283 282 254 286 282 254 minecraft:blackstone
fill 283 282 255 287 282 255 minecraft:basalt
fill 283 282 256 284 282 256 minecraft:blackstone
setblock 283 282 257 minecraft:tuff
fill 284 282 239 286 282 239 minecraft:blackstone
fill 284 282 240 287 282 240 minecraft:basalt
fill 284 282 243 284 282 244 minecraft:blackstone
setblock 284 282 246 minecraft:tuff
fill 284 282 247 284 282 249 minecraft:blackstone
setblock 284 282 259 minecraft:tuff
fill 285 282 238 288 282 238 minecraft:blackstone
fill 285 282 244 286 282 244 minecraft:blackstone
fill 285 282 246 285 282 247 minecraft:blackstone
setblock 285 282 248 minecraft:tuff
setblock 285 282 249 minecraft:blackstone
fill 285 282 258 285 282 259 minecraft:blackstone
fill 285 282 260 290 282 260 minecraft:basalt
fill 286 282 236 287 282 236 minecraft:blackstone
setblock 286 282 237 minecraft:tuff
setblock 286 282 243 minecraft:blackstone
fill 286 282 247 286 300 249 minecraft:basalt
fill 286 282 256 287 282 256 minecraft:blackstone
fill 286 282 259 289 282 259 minecraft:blackstone
fill 286 282 261 291 282 262 minecraft:blackstone
fill 287 282 235 292 282 235 minecraft:basalt
fill 287 282 237 288 282 237 minecraft:blackstone
setblock 287 282 239 minecraft:tuff
setblock 287 282 241 minecraft:blackstone
fill 287 282 257 288 282 257 minecraft:blackstone
fill 287 282 263 294 282 263 minecraft:blackstone
fill 288 282 234 290 282 234 minecraft:blackstone
setblock 288 282 239 minecraft:blackstone
fill 288 282 264 292 282 264 minecraft:blackstone
fill 289 282 233 296 282 233 minecraft:blackstone
fill 289 282 265 299 282 265 minecraft:basalt
setblock 290 282 232 minecraft:tuff
fill 290 282 236 290 282 237 minecraft:blackstone
setblock 290 282 259 minecraft:netherrack
fill 290 282 266 293 282 266 minecraft:blackstone
fill 291 282 232 302 282 232 minecraft:blackstone
setblock 291 282 234 minecraft:tuff
setblock 291 282 236 minecraft:blackstone
setblock 291 282 260 minecraft:netherrack
fill 292 282 231 295 282 231 minecraft:blackstone
fill 292 282 234 294 282 234 minecraft:blackstone
fill 292 282 238 293 283 239 minecraft:basalt
setblock 292 282 261 minecraft:netherrack
setblock 292 282 262 minecraft:tuff
fill 292 282 267 300 282 267 minecraft:blackstone
fill 293 282 230 301 282 230 minecraft:basalt
fill 293 282 262 293 283 262 minecraft:netherrack
setblock 293 282 264 minecraft:tuff
fill 293 282 268 294 282 268 minecraft:blackstone
fill 294 282 264 297 282 264 minecraft:blackstone
setblock 294 282 266 minecraft:tuff
setblock 295 282 229 minecraft:tuff
fill 295 282 263 297 282 263 minecraft:netherrack
fill 295 282 266 306 282 266 minecraft:blackstone
setblock 295 282 268 minecraft:tuff
fill 295 282 269 301 282 269 minecraft:blackstone
fill 296 282 229 307 282 229 minecraft:blackstone
setblock 296 282 231 minecraft:tuff
fill 296 282 268 307 282 268 minecraft:blackstone
fill 297 282 231 308 282 231 minecraft:blackstone
setblock 297 282 233 minecraft:tuff
fill 298 282 264 300 282 264 minecraft:netherrack
setblock 300 282 265 minecraft:tuff
setblock 301 282 264 minecraft:shroomlight
fill 301 282 265 312 282 265 minecraft:basalt
setblock 301 282 267 minecraft:tuff
setblock 302 282 230 minecraft:tuff
fill 302 282 264 304 282 264 minecraft:netherrack
fill 302 282 267 313 282 267 minecraft:blackstone
setblock 302 282 269 minecraft:tuff
fill 303 282 230 313 282 230 minecraft:basalt
setblock 303 282 232 minecraft:tuff
fill 303 282 269 311 282 269 minecraft:blackstone
fill 305 282 233 307 282 233 minecraft:netherrack
fill 305 282 263 307 282 263 minecraft:netherrack
setblock 305 282 264 minecraft:blackstone
setblock 306 282 264 minecraft:tuff
fill 307 282 264 318 282 264 minecraft:blackstone
setblock 307 282 266 minecraft:tuff
setblock 308 282 229 minecraft:tuff
fill 308 282 233 309 282 233 minecraft:blackstone
fill 308 282 263 311 282 263 minecraft:blackstone
fill 308 282 266 316 282 266 minecraft:blackstone
setblock 308 282 268 minecraft:tuff
fill 309 282 229 311 282 229 minecraft:blackstone
setblock 309 282 231 minecraft:tuff
fill 309 282 234 309 283 234 minecraft:netherrack
fill 309 282 262 309 283 262 minecraft:netherrack
fill 309 282 268 313 282 268 minecraft:blackstone
fill 310 282 231 314 282 231 minecraft:blackstone
setblock 310 282 233 minecraft:tuff
fill 310 282 234 316 282 234 minecraft:blackstone
setblock 310 282 235 minecraft:netherrack
setblock 310 282 261 minecraft:netherrack
fill 310 282 262 317 282 262 minecraft:blackstone
fill 311 282 232 315 282 233 minecraft:blackstone
setblock 311 282 235 minecraft:tuff
setblock 311 282 236 minecraft:netherrack
setblock 311 282 260 minecraft:netherrack
setblock 311 282 261 minecraft:tuff
fill 312 282 235 319 282 235 minecraft:basalt
fill 312 282 236 317 282 236 minecraft:blackstone
setblock 312 282 237 minecraft:netherrack
fill 312 282 238 312 300 238 minecraft:basalt
setblock 312 282 259 minecraft:netherrack
fill 312 282 260 316 282 260 minecraft:basalt
fill 312 282 261 320 282 261 minecraft:blackstone
setblock 312 282 263 minecraft:tuff
fill 313 282 237 320 282 237 minecraft:blackstone
setblock 313 282 238 minecraft:shroomlight
setblock 313 282 258 minecraft:shroomlight
fill 313 282 259 322 282 259 minecraft:blackstone
fill 313 282 263 319 282 263 minecraft:blackstone
setblock 313 282 265 minecraft:tuff
fill 314 282 238 318 282 238 minecraft:blackstone
setblock 314 282 239 minecraft:netherrack
setblock 314 282 257 minecraft:netherrack
fill 314 282 258 315 282 258 minecraft:blackstone
fill 314 282 265 317 282 265 minecraft:basalt
setblock 314 282 267 minecraft:tuff
fill 315 282 239 322 282 239 minecraft:blackstone
fill 315 282 240 315 282 241 minecraft:netherrack
fill 315 282 255 315 282 256 minecraft:netherrack
fill 315 282 257 321 282 257 minecraft:blackstone
setblock 316 282 232 minecraft:tuff
fill 316 282 233 317 282 233 minecraft:blackstone
fill 316 282 240 319 282 240 minecraft:basalt
fill 316 282 241 322 282 241 minecraft:blackstone
fill 316 282 242 316 282 243 minecraft:netherrack
fill 316 282 253 316 282 254 minecraft:netherrack
fill 316 282 255 320 282 255 minecraft:basalt
fill 316 282 256 323 282 256 minecraft:blackstone
setblock 316 282 258 minecraft:tuff
setblock 317 282 234 minecraft:tuff
fill 317 282 242 320 282 244 minecraft:blackstone
fill 317 282 245 317 282 251 minecraft:netherrack
fill 317 282 252 317 282 254 minecraft:blackstone
fill 317 282 258 322 282 258 minecraft:blackstone
setblock 317 282 260 minecraft:tuff
setblock 318 282 234 minecraft:blackstone
setblock 318 282 236 minecraft:tuff
fill 318 282 245 323 282 245 minecraft:basalt
setblock 318 282 246 minecraft:blackstone
setblock 318 282 249 minecraft:tuff
fill 318 282 250 323 282 250 minecraft:basalt
setblock 318 282 251 minecraft:blackstone
fill 318 282 253 319 282 254 minecraft:blackstone
fill 318 282 260 321 282 260 minecraft:basalt
setblock 318 282 262 minecraft:tuff
fill 319 282 236 320 282 236 minecraft:blackstone
setblock 319 282 238 minecraft:tuff
fill 319 282 248 319 283 249 minecraft:blackstone
setblock 319 282 251 minecraft:tuff
fill 319 282 262 320 282 262 minecraft:blackstone
fill 320 282 238 321 282 238 minecraft:blackstone
setblock 320 282 240 minecraft:tuff
setblock 320 282 246 minecraft:blackstone
fill 320 282 249 323 282 249 minecraft:blackstone
fill 320 282 251 321 282 251 minecraft:blackstone
setblock 320 282 253 minecraft:tuff
fill 320 282 254 323 282 254 minecraft:blackstone
fill 321 282 240 322 282 240 minecraft:basalt
setblock 321 282 242 minecraft:tuff
fill 321 282 243 321 283 244 minecraft:blackstone
fill 321 282 252 321 282 253 minecraft:blackstone
setblock 321 282 255 minecraft:tuff
fill 322 282 242 323 282 243 minecraft:blackstone
setblock 322 282 244 minecraft:tuff
setblock 322 282 246 minecraft:blackstone
fill 322 282 253 323 282 253 minecraft:blackstone
fill 322 282 255 323 282 255 minecraft:basalt
setblock 322 282 257 minecraft:tuff
setblock 323 282 244 minecraft:blackstone
setblock 323 282 246 minecraft:tuff
setblock 323 282 251 minecraft:blackstone
setblock 323 282 257 minecraft:blackstone
fill 324 282 240 324 283 240 minecraft:blackstone
fill 324 282 242 324 283 242 minecraft:blackstone
setblock 282 283 241 minecraft:blackstone
setblock 282 283 255 minecraft:crying_obsidian
setblock 282 283 256 minecraft:blackstone
fill 284 283 244 284 283 245 minecraft:blackstone
setblock 284 283 246 minecraft:basalt
fill 284 283 247 284 283 248 minecraft:blackstone
setblock 284 283 249 minecraft:tuff
setblock 284 283 250 minecraft:blackstone
setblock 284 283 251 minecraft:basalt
fill 284 283 252 284 283 254 minecraft:blackstone
fill 285 283 241 286 283 241 minecraft:basalt
setblock 285 283 244 minecraft:blackstone
fill 285 283 245 285 283 246 minecraft:magma_block
fill 285 283 250 285 283 253 minecraft:magma_block
fill 285 283 254 285 283 255 minecraft:blackstone
setblock 285 283 256 minecraft:basalt
setblock 285 283 257 minecraft:blackstone
fill 286 283 239 287 283 239 minecraft:blackstone
setblock 286 283 240 minecraft:tuff
setblock 286 283 242 minecraft:magma_block
fill 286 283 254 286 283 256 minecraft:magma_block
fill 286 283 259 287 283 259 minecraft:blackstone
fill 287 283 238 288 283 238 minecraft:blackstone
setblock 287 283 240 minecraft:magma_block
fill 287 283 256 287 283 258 minecraft:magma_block
fill 287 283 260 288 283 260 minecraft:blackstone
setblock 288 283 237 minecraft:blackstone
fill 288 283 258 288 283 259 minecraft:magma_block
setblock 288 283 261 minecraft:basalt
setblock 289 283 236 minecraft:basalt
setblock 289 283 237 minecraft:magma_block
fill 289 283 259 289 283 261 minecraft:magma_block
setblock 289 283 262 minecraft:blackstone
setblock 290 283 235 minecraft:tuff
setblock 290 283 236 minecraft:magma_block
fill 290 283 260 290 283 262 minecraft:magma_block
setblock 290 283 263 minecraft:blackstone
fill 291 283 234 292 283 234 minecraft:blackstone
setblock 291 283 235 minecraft:magma_block
fill 291 283 261 291 283 263 minecraft:magma_block
fill 291 283 264 292 283 264 minecraft:blackstone
fill 292 283 233 293 283 233 minecraft:blackstone
fill 292 283 262 292 283 263 minecraft:magma_block
setblock 292 283 265 minecraft:tuff
fill 293 283 232 294 283 232 minecraft:blackstone
setblock 293 283 234 minecraft:magma_block
fill 293 283 263 294 283 264 minecraft:magma_block
setblock 293 283 265 minecraft:blackstone
fill 293 283 266 295 283 266 minecraft:basalt
fill 294 283 233 295 283 233 minecraft:magma_block
fill 294 283 265 298 283 265 minecraft:magma_block
fill 295 283 231 298 283 231 minecraft:basalt
setblock 295 283 232 minecraft:tuff
setblock 295 283 263 minecraft:netherrack
fill 295 283 264 296 284 264 minecraft:magma_block
fill 295 283 267 298 283 267 minecraft:blackstone
fill 296 283 232 299 283 232 minecraft:magma_block
fill 296 283 266 310 283 266 minecraft:magma_block
fill 297 283 264 299 283 264 minecraft:netherrack
fill 298 283 230 306 283 230 minecraft:blackstone
fill 298 283 268 299 283 268 minecraft:blackstone
fill 299 283 231 307 283 231 minecraft:magma_block
setblock 299 283 265 minecraft:blackstone
fill 299 283 267 307 283 267 minecraft:magma_block
setblock 300 283 265 minecraft:netherrack
setblock 300 283 268 minecraft:tuff
fill 301 283 265 301 284 265 minecraft:shroomlight
fill 301 283 268 308 283 268 minecraft:blackstone
setblock 302 283 265 minecraft:netherrack
fill 303 283 232 310 283 232 minecraft:magma_block
fill 303 283 264 306 283 264 minecraft:netherrack
fill 303 283 265 304 283 265 minecraft:blackstone
setblock 305 283 265 minecraft:tuff
fill 306 283 265 307 283 265 minecraft:blackstone
setblock 307 283 230 minecraft:tuff
setblock 307 283 233 minecraft:netherrack
setblock 307 283 263 minecraft:netherrack
fill 307 283 264 309 283 264 minecraft:blackstone
setblock 308 283 230 minecraft:blackstone
fill 308 283 231 311 283 231 minecraft:basalt
fill 308 283 233 312 283 233 minecraft:magma_block
setblock 308 283 263 minecraft:shroomlight
fill 308 283 265 312 283 265 minecraft:magma_block
fill 308 283 267 311 283 267 minecraft:blackstone
fill 309 283 263 311 283 263 minecraft:blackstone
fill 310 283 234 313 283 234 minecraft:magma_block
setblock 310 283 262 minecraft:netherrack
fill 310 283 264 313 283 264 minecraft:magma_block
fill 311 283 232 313 283 232 minecraft:blackstone
setblock 311 283 235 minecraft:netherrack
setblock 311 283 261 minecraft:netherrack
fill 311 283 262 313 283 262 minecraft:blackstone
setblock 311 283 266 minecraft:basalt
fill 312 283 235 315 283 235 minecraft:magma_block
setblock 312 283 236 minecraft:netherrack
setblock 312 283 260 minecraft:netherrack
fill 312 283 261 314 283 261 minecraft:basalt
fill 312 283 263 315 283 263 minecraft:magma_block
setblock 312 283 266 minecraft:tuff
fill 313 283 233 314 283 233 minecraft:blackstone
setblock 313 283 236 minecraft:basalt
setblock 313 283 237 minecraft:netherrack
setblock 313 283 259 minecraft:netherrack
fill 313 283 260 315 283 260 minecraft:blackstone
fill 313 283 265 314 283 265 minecraft:blackstone
setblock 313 283 266 minecraft:basalt
fill 314 283 234 315 283 234 minecraft:blackstone
fill 314 283 236 316 283 236 minecraft:magma_block
setblock 314 283 237 minecraft:blackstone
setblock 314 283 238 minecraft:shroomlight
setblock 314 283 258 minecraft:shroomlight
setblock 314 283 259 minecraft:blackstone
fill 314 283 262 316 283 262 minecraft:magma_block
fill 314 283 264 315 283 264 minecraft:blackstone
fill 315 283 237 317 283 237 minecraft:magma_block
setblock 315 283 238 minecraft:blackstone
fill 315 283 239 315 283 240 minecraft:netherrack
fill 315 283 256 315 283 257 minecraft:netherrack
fill 315 283 258 316 283 258 minecraft:blackstone
setblock 315 283 259 minecraft:tuff
fill 315 283 261 317 283 261 minecraft:magma_block
setblock 316 283 235 minecraft:tuff
fill 316 283 238 317 284 238 minecraft:magma_block
fill 316 283 239 316 283 240 minecraft:blackstone
fill 316 283 241 316 283 242 minecraft:netherrack
fill 316 283 254 316 283 255 minecraft:netherrack
fill 316 283 256 317 283 256 minecraft:basalt
fill 316 283 257 317 283 257 minecraft:blackstone
setblock 316 283 259 minecraft:blackstone
fill 316 283 260 317 284 260 minecraft:magma_block
setblock 316 283 263 minecraft:blackstone
setblock 317 283 236 minecraft:basalt
fill 317 283 239 318 283 240 minecraft:magma_block
setblock 317 283 241 minecraft:basalt
setblock 317 283 242 minecraft:blackstone
setblock 317 283 243 minecraft:netherrack
setblock 317 283 244 minecraft:shroomlight
fill 317 283 245 317 283 246 minecraft:netherrack
fill 317 283 250 317 283 251 minecraft:netherrack
setblock 317 283 252 minecraft:shroomlight
setblock 317 283 253 minecraft:netherrack
fill 317 283 254 318 283 255 minecraft:blackstone
fill 317 283 258 318 283 259 minecraft:magma_block
setblock 317 283 262 minecraft:blackstone
fill 318 283 237 318 283 238 minecraft:blackstone
fill 318 283 241 319 284 242 minecraft:magma_block
fill 318 283 243 318 283 245 minecraft:blackstone
fill 318 283 246 319 283 246 minecraft:basalt
fill 318 283 247 318 283 249 minecraft:netherrack
fill 318 283 250 319 283 250 minecraft:blackstone
fill 318 283 251 319 283 251 minecraft:basalt
setblock 318 283 252 minecraft:tuff
fill 318 283 253 319 283 253 minecraft:blackstone
fill 318 283 256 319 284 257 minecraft:magma_block
fill 318 283 260 319 283 260 minecraft:blackstone
setblock 318 283 261 minecraft:basalt
fill 319 283 238 319 283 239 minecraft:blackstone
setblock 319 283 240 minecraft:magma_block
fill 319 283 243 320 283 244 minecraft:magma_block
setblock 319 283 245 minecraft:blackstone
setblock 319 283 247 minecraft:blackstone
setblock 319 283 252 minecraft:blackstone
fill 319 283 254 320 283 255 minecraft:magma_block
setblock 319 283 258 minecraft:magma_block
fill 319 283 259 320 283 259 minecraft:blackstone
fill 320 283 239 320 283 240 minecraft:blackstone
fill 320 283 241 321 283 241 minecraft:basalt
setblock 320 283 242 minecraft:magma_block
fill 320 283 245 321 283 253 minecraft:magma_block
setblock 320 283 256 minecraft:magma_block
fill 320 283 257 320 283 258 minecraft:blackstone
setblock 321 283 242 minecraft:blackstone
fill 321 283 254 321 283 255 minecraft:blackstone
setblock 321 283 256 minecraft:basalt
setblock 321 283 257 minecraft:blackstone
fill 322 283 244 322 283 245 minecraft:blackstone
setblock 322 283 246 minecraft:basalt
setblock 322 283 247 minecraft:tuff
fill 322 283 248 322 283 250 minecraft:blackstone
setblock 322 283 251 minecraft:basalt
fill 322 283 252 322 283 254 minecraft:blackstone
setblock 324 283 241 minecraft:blackstone
fill 282 284 228 282 284 249 minecraft:brown_terracotta
setblock 282 284 250 minecraft:gray_terracotta
fill 282 284 251 282 285 259 minecraft:brown_terracotta
fill 282 284 260 282 285 260 minecraft:light_gray_terracotta
fill 282 284 261 282 288 270 minecraft:brown_terracotta
fill 283 284 228 288 287 228 minecraft:brown_terracotta
fill 283 284 270 324 284 270 minecraft:brown_terracotta
setblock 289 284 228 minecraft:orange_terracotta
setblock 289 284 260 minecraft:magma_block
fill 290 284 228 300 288 228 minecraft:brown_terracotta
setblock 290 284 261 minecraft:magma_block
setblock 291 284 262 minecraft:magma_block
fill 292 284 263 293 284 263 minecraft:magma_block
setblock 294 284 264 minecraft:magma_block
fill 295 284 265 300 284 265 minecraft:magma_block
fill 298 284 266 308 284 266 minecraft:magma_block
setblock 301 284 228 minecraft:gray_terracotta
fill 302 284 228 317 284 228 minecraft:brown_terracotta
fill 302 284 265 311 284 265 minecraft:magma_block
fill 306 284 232 308 284 232 minecraft:magma_block
fill 306 284 264 308 284 264 minecraft:magma_block
fill 309 284 233 311 284 233 minecraft:magma_block
fill 309 284 263 314 284 263 minecraft:magma_block
setblock 309 284 264 minecraft:shroomlight
fill 310 284 264 312 284 264 minecraft:magma_block
fill 311 284 234 312 284 234 minecraft:magma_block
fill 311 284 262 315 284 262 minecraft:magma_block
fill 312 284 235 314 284 235 minecraft:magma_block
fill 312 284 261 316 284 261 minecraft:magma_block
fill 313 284 236 315 284 236 minecraft:magma_block
fill 313 284 260 315 284 260 minecraft:magma_block
setblock 314 284 237 minecraft:shroomlight
fill 314 284 259 315 284 259 minecraft:shroomlight
fill 315 284 237 315 284 238 minecraft:magma_block
fill 315 284 258 318 284 258 minecraft:magma_block
setblock 316 284 237 minecraft:magma_block
fill 316 284 239 317 284 240 minecraft:magma_block
fill 316 284 256 317 284 257 minecraft:magma_block
fill 316 284 259 317 284 259 minecraft:magma_block
fill 317 284 241 317 284 243 minecraft:magma_block
fill 317 284 253 319 284 255 minecraft:magma_block
setblock 318 284 228 minecraft:orange_terracotta
setblock 318 284 240 minecraft:magma_block
fill 318 284 243 319 284 243 minecraft:magma_block
setblock 318 284 244 minecraft:shroomlight
fill 318 284 245 320 284 251 minecraft:magma_block
fill 318 284 252 319 284 252 minecraft:shroomlight
fill 319 284 228 324 285 228 minecraft:brown_terracotta
fill 319 284 244 320 284 244 minecraft:magma_block
fill 320 284 252 320 284 254 minecraft:magma_block
fill 324 284 229 324 284 241 minecraft:brown_terracotta
setblock 324 284 242 minecraft:gray_terracotta
fill 324 284 243 324 292 243 minecraft:brown_terracotta
setblock 324 284 244 minecraft:orange_terracotta
fill 324 284 245 324 288 246 minecraft:brown_terracotta
setblock 324 284 247 minecraft:light_gray_terracotta
fill 324 284 248 324 288 256 minecraft:brown_terracotta
setblock 324 284 257 minecraft:orange_terracotta
fill 324 284 258 324 286 264 minecraft:brown_terracotta
setblock 324 284 265 minecraft:orange_terracotta
fill 324 284 266 324 286 269 minecraft:brown_terracotta
fill 282 285 228 282 286 231 minecraft:brown_terracotta
setblock 282 285 232 minecraft:orange_terracotta
fill 282 285 233 282 288 245 minecraft:brown_terracotta
setblock 282 285 246 minecraft:orange_terracotta
fill 282 285 247 282 288 250 minecraft:brown_terracotta
fill 283 285 270 310 286 270 minecraft:brown_terracotta
setblock 285 285 231 minecraft:light[level=12]
setblock 285 285 238 minecraft:light[level=12]
setblock 285 285 245 minecraft:light[level=12]
setblock 285 285 252 minecraft:light[level=12]
setblock 285 285 259 minecraft:light[level=12]
setblock 285 285 266 minecraft:light[level=12]
fill 289 285 228 289 290 228 minecraft:brown_terracotta
setblock 292 285 231 minecraft:light[level=12]
setblock 292 285 238 minecraft:light[level=12]
setblock 292 285 245 minecraft:light[level=12]
setblock 292 285 252 minecraft:light[level=12]
setblock 292 285 259 minecraft:light[level=12]
setblock 292 285 266 minecraft:light[level=12]
setblock 299 285 231 minecraft:light[level=12]
setblock 299 285 238 minecraft:light[level=12]
setblock 299 285 245 minecraft:light[level=12]
setblock 299 285 252 minecraft:light[level=12]
setblock 299 285 259 minecraft:light[level=12]
setblock 299 285 266 minecraft:light[level=12]
setblock 301 285 228 minecraft:orange_terracotta
setblock 302 285 228 minecraft:light_gray_terracotta
fill 303 285 228 316 285 228 minecraft:brown_terracotta
setblock 306 285 231 minecraft:light[level=12]
setblock 306 285 238 minecraft:light[level=12]
setblock 306 285 245 minecraft:light[level=12]
setblock 306 285 252 minecraft:light[level=12]
setblock 306 285 259 minecraft:light[level=12]
setblock 306 285 266 minecraft:light[level=12]
setblock 311 285 270 minecraft:light_gray_terracotta
fill 312 285 270 313 288 270 minecraft:brown_terracotta
setblock 313 285 231 minecraft:light[level=12]
setblock 313 285 238 minecraft:light[level=12]
setblock 313 285 245 minecraft:light[level=12]
setblock 313 285 252 minecraft:light[level=12]
setblock 313 285 259 minecraft:light[level=12]
setblock 313 285 266 minecraft:light[level=12]
setblock 314 285 270 minecraft:gray_terracotta
fill 315 285 270 321 285 270 minecraft:brown_terracotta
setblock 317 285 228 minecraft:orange_terracotta
fill 318 285 228 318 290 228 minecraft:brown_terracotta
setblock 320 285 231 minecraft:light[level=12]
setblock 320 285 238 minecraft:light[level=12]
setblock 320 285 245 minecraft:light[level=12]
setblock 320 285 252 minecraft:light[level=12]
setblock 320 285 259 minecraft:light[level=12]
setblock 320 285 266 minecraft:light[level=12]
setblock 322 285 270 minecraft:light_gray_terracotta
fill 323 285 270 324 292 270 minecraft:brown_terracotta
fill 324 285 229 324 292 230 minecraft:brown_terracotta
setblock 324 285 231 minecraft:gray_terracotta
fill 324 285 232 324 285 242 minecraft:brown_terracotta
fill 324 285 244 324 292 244 minecraft:brown_terracotta
fill 324 285 247 324 292 247 minecraft:brown_terracotta
fill 324 285 257 324 286 257 minecraft:brown_terracotta
fill 324 285 265 324 291 265 minecraft:brown_terracotta
fill 282 286 232 282 291 232 minecraft:brown_terracotta
fill 282 286 246 282 292 246 minecraft:brown_terracotta
fill 282 286 251 282 288 256 minecraft:brown_terracotta
setblock 282 286 257 minecraft:light_gray_terracotta
fill 282 286 258 282 287 260 minecraft:brown_terracotta
fill 285 286 254 285 290 254 minecraft:light_gray_wool
fill 301 286 228 303 287 228 minecraft:brown_terracotta
setblock 304 286 228 minecraft:orange_terracotta
fill 305 286 228 313 288 228 minecraft:brown_terracotta
fill 311 286 270 311 292 270 minecraft:brown_terracotta
setblock 314 286 228 minecraft:orange_terracotta
fill 314 286 270 316 289 270 minecraft:brown_terracotta
fill 315 286 228 317 289 228 minecraft:brown_terracotta
fill 317 286 270 317 287 270 minecraft:orange_terracotta
fill 318 286 270 322 288 270 minecraft:brown_terracotta
fill 319 286 228 322 290 228 minecraft:brown_terracotta
fill 320 286 245 322 289 245 minecraft:gray_wool
fill 321 286 244 322 288 244 minecraft:gray_wool
fill 321 286 246 321 289 246 minecraft:gray_wool
setblock 323 286 228 minecraft:orange_terracotta
fill 324 286 228 324 288 228 minecraft:brown_terracotta
fill 324 286 231 324 288 237 minecraft:brown_terracotta
setblock 324 286 238 minecraft:light_gray_terracotta
fill 324 286 239 324 286 242 minecraft:brown_terracotta
fill 282 287 228 282 288 228 minecraft:brown_terracotta
setblock 282 287 229 minecraft:orange_terracotta
fill 282 287 230 282 288 231 minecraft:brown_terracotta
fill 282 287 257 282 292 257 minecraft:brown_terracotta
fill 283 287 254 284 289 254 minecraft:light_gray_wool
fill 283 287 270 286 289 270 minecraft:brown_terracotta
fill 284 287 253 286 290 253 minecraft:light_gray_wool
fill 284 287 255 286 290 255 minecraft:light_gray_wool
fill 285 287 256 285 289 256 minecraft:light_gray_wool
fill 286 287 254 286 290 254 minecraft:light_gray_wool
setblock 287 287 270 minecraft:light_gray_terracotta
fill 288 287 270 288 292 270 minecraft:brown_terracotta
setblock 289 287 270 minecraft:light_gray_terracotta
fill 290 287 270 293 290 270 minecraft:brown_terracotta
setblock 294 287 270 minecraft:orange_terracotta
fill 295 287 270 310 288 270 minecraft:brown_terracotta
fill 304 287 228 304 292 228 minecraft:brown_terracotta
fill 314 287 228 314 292 228 minecraft:brown_terracotta
fill 320 287 244 320 288 244 minecraft:gray_wool
fill 320 287 246 320 289 246 minecraft:gray_wool
setblock 321 287 243 minecraft:gray_wool
fill 322 287 246 322 288 246 minecraft:gray_wool
fill 323 287 228 323 288 228 minecraft:brown_terracotta
fill 324 287 238 324 288 241 minecraft:brown_terracotta
setblock 324 287 242 minecraft:orange_terracotta
setblock 324 287 257 minecraft:light_gray_terracotta
fill 324 287 258 324 290 260 minecraft:brown_terracotta
setblock 324 287 261 minecraft:gray_terracotta
setblock 324 287 262 minecraft:light_gray_terracotta
fill 324 287 263 324 289 264 minecraft:brown_terracotta
fill 324 287 266 324 292 266 minecraft:brown_terracotta
setblock 324 287 267 minecraft:light_gray_terracotta
fill 324 287 268 324 289 269 minecraft:brown_terracotta
fill 282 288 229 282 292 229 minecraft:brown_terracotta
fill 282 288 258 282 288 259 minecraft:brown_terracotta
setblock 282 288 260 minecraft:gray_terracotta
fill 283 288 228 286 289 228 minecraft:brown_terracotta
fill 283 288 253 283 289 253 minecraft:light_gray_wool
fill 284 288 256 284 289 256 minecraft:light_gray_wool
setblock 285 288 231 minecraft:light[level=12]
setblock 285 288 239 minecraft:light[level=12]
setblock 285 288 247 minecraft:light[level=12]
fill 285 288 252 286 289 252 minecraft:light_gray_wool
setblock 285 288 263 minecraft:light[level=12]
fill 286 288 256 286 289 256 minecraft:light_gray_wool
setblock 287 288 228 minecraft:gray_terracotta
fill 287 288 253 287 289 254 minecraft:light_gray_wool
fill 287 288 270 287 292 270 minecraft:brown_terracotta
fill 288 288 228 288 290 228 minecraft:brown_terracotta
fill 289 288 270 289 292 270 minecraft:brown_terracotta
setblock 293 288 231 minecraft:light[level=12]
setblock 293 288 239 minecraft:light[level=12]
setblock 293 288 247 minecraft:light[level=12]
setblock 293 288 255 minecraft:light[level=12]
setblock 293 288 263 minecraft:light[level=12]
fill 294 288 270 294 289 270 minecraft:brown_terracotta
fill 301 288 228 302 288 228 minecraft:brown_terracotta
setblock 301 288 231 minecraft:light[level=12]
setblock 301 288 239 minecraft:light[level=12]
setblock 301 288 255 minecraft:light[level=12]
setblock 301 288 263 minecraft:light[level=12]
setblock 303 288 228 minecraft:light_gray_terracotta
setblock 309 288 231 minecraft:light[level=12]
setblock 309 288 247 minecraft:light[level=12]
setblock 309 288 255 minecraft:light[level=12]
setblock 309 288 263 minecraft:light[level=12]
setblock 317 288 231 minecraft:light[level=12]
setblock 317 288 239 minecraft:light[level=12]
setblock 317 288 247 minecraft:light[level=12]
setblock 317 288 255 minecraft:light[level=12]
setblock 317 288 263 minecraft:light[level=12]
setblock 317 288 270 minecraft:brown_terracotta
fill 319 288 245 319 288 246 minecraft:gray_wool
setblock 323 288 245 minecraft:gray_wool
fill 324 288 242 324 293 242 minecraft:brown_terracotta
fill 324 288 257 324 292 257 minecraft:brown_terracotta
fill 324 288 261 324 289 262 minecraft:brown_terracotta
fill 324 288 267 324 292 267 minecraft:brown_terracotta
fill 282 289 228 282 290 228 minecraft:gray_concrete
fill 282 289 230 282 289 231 minecraft:gray_concrete
setblock 282 289 233 minecraft:gray_concrete
fill 282 289 234 282 290 239 minecraft:brown_terracotta
setblock 282 289 240 minecraft:gray_terracotta
fill 282 289 241 282 289 244 minecraft:brown_terracotta
setblock 282 289 245 minecraft:gray_concrete
setblock 282 289 247 minecraft:light_gray_terracotta
setblock 282 289 248 minecraft:gray_concrete
fill 282 289 249 282 289 254 minecraft:brown_terracotta
setblock 282 289 255 minecraft:gray_concrete
fill 282 289 256 282 292 256 minecraft:brown_terracotta
fill 282 289 258 282 292 258 minecraft:brown_terracotta
fill 282 289 259 282 290 259 minecraft:gray_concrete
fill 282 289 260 282 289 263 minecraft:brown_terracotta
setblock 282 289 264 minecraft:gray_concrete
fill 282 289 265 282 289 270 minecraft:brown_terracotta
setblock 283 289 255 minecraft:light_gray_wool
fill 287 289 228 287 290 228 minecraft:brown_terracotta
fill 287 289 255 287 290 255 minecraft:light_gray_wool
fill 290 289 228 296 289 228 minecraft:brown_terracotta
fill 295 289 270 307 289 270 minecraft:brown_terracotta
setblock 297 289 228 minecraft:gray_concrete
fill 298 289 228 298 292 228 minecraft:brown_terracotta
setblock 299 289 228 minecraft:light_gray_terracotta
fill 300 289 228 300 292 228 minecraft:brown_terracotta
setblock 301 289 228 minecraft:gray_concrete
fill 302 289 228 303 292 228 minecraft:brown_terracotta
fill 305 289 228 312 289 228 minecraft:brown_terracotta
fill 306 289 231 307 293 231 minecraft:gray_wool
setblock 308 289 270 minecraft:gray_terracotta
fill 309 289 270 310 289 270 minecraft:brown_terracotta
setblock 312 289 270 minecraft:gray_concrete
setblock 313 289 228 minecraft:gray_concrete
fill 313 289 270 313 292 270 minecraft:brown_terracotta
setblock 317 289 270 minecraft:orange_terracotta
fill 318 289 270 320 292 270 minecraft:brown_terracotta
setblock 321 289 244 minecraft:gray_wool
fill 321 289 270 321 290 270 minecraft:gray_concrete
setblock 322 289 270 minecraft:brown_terracotta
setblock 323 289 228 minecraft:orange_terracotta
fill 324 289 228 324 290 228 minecraft:gray_concrete
setblock 324 289 231 minecraft:gray_terracotta
setblock 324 289 232 minecraft:gray_concrete
fill 324 289 233 324 290 238 minecraft:brown_terracotta
setblock 324 289 239 minecraft:gray_terracotta
fill 324 289 240 324 292 241 minecraft:brown_terracotta
fill 324 289 245 324 292 245 minecraft:brown_terracotta
setblock 324 289 246 minecraft:gray_concrete
fill 324 289 248 324 292 250 minecraft:brown_terracotta
setblock 324 289 251 minecraft:gray_concrete
fill 324 289 252 324 292 256 minecraft:brown_terracotta
fill 282 290 230 282 290 231 minecraft:brown_terracotta
fill 282 290 233 282 292 233 minecraft:brown_terracotta
fill 282 290 240 282 291 241 minecraft:brown_terracotta
setblock 282 290 242 minecraft:light_gray_terracotta
fill 282 290 243 282 292 245 minecraft:brown_terracotta
setblock 282 290 247 minecraft:gray_concrete
fill 282 290 248 282 292 248 minecraft:brown_terracotta
setblock 282 290 249 minecraft:gray_terracotta
fill 282 290 250 282 290 255 minecraft:brown_terracotta
fill 282 290 260 282 290 261 minecraft:brown_terracotta
fill 282 290 262 282 290 263 minecraft:gray_concrete
fill 282 290 264 282 292 265 minecraft:brown_terracotta
fill 282 290 266 282 290 267 minecraft:gray_concrete
fill 282 290 268 282 292 268 minecraft:brown_terracotta
setblock 282 290 269 minecraft:gray_concrete
fill 282 290 270 282 292 270 minecraft:brown_terracotta
setblock 283 290 228 minecraft:gray_concrete
fill 283 290 270 283 291 270 minecraft:gray_concrete
fill 284 290 228 286 292 228 minecraft:brown_terracotta
setblock 284 290 254 minecraft:light_gray_wool
fill 284 290 270 286 292 270 minecraft:brown_terracotta
setblock 287 290 254 minecraft:light_gray_wool
fill 290 290 228 291 290 228 minecraft:brown_terracotta
setblock 292 290 228 minecraft:gray_concrete
fill 293 290 228 293 292 228 minecraft:brown_terracotta
fill 294 290 228 295 290 228 minecraft:gray_concrete
setblock 294 290 270 minecraft:orange_terracotta
fill 295 290 270 295 292 270 minecraft:brown_terracotta
fill 296 290 228 297 290 228 minecraft:brown_terracotta
fill 296 290 270 296 291 270 minecraft:gray_concrete
fill 297 290 270 305 292 270 minecraft:brown_terracotta
fill 299 290 228 299 292 228 minecraft:brown_terracotta
fill 301 290 228 301 293 228 minecraft:brown_terracotta
setblock 305 290 228 minecraft:light_gray_terracotta
fill 305 290 230 305 293 233 minecraft:gray_wool
fill 306 290 228 307 290 228 minecraft:gray_concrete
fill 306 290 229 307 292 230 minecraft:gray_wool
fill 306 290 232 306 293 233 minecraft:gray_wool
setblock 306 290 270 minecraft:gray_concrete
fill 307 290 232 307 293 232 minecraft:gray_wool
fill 307 290 270 308 292 270 minecraft:brown_terracotta
fill 308 290 228 312 290 228 minecraft:brown_terracotta
setblock 309 290 270 minecraft:light_gray_terracotta
fill 310 290 270 310 292 270 minecraft:brown_terracotta
fill 312 290 270 312 293 270 minecraft:brown_terracotta
setblock 313 290 228 minecraft:light_gray_terracotta
fill 314 290 270 314 292 270 minecraft:brown_terracotta
setblock 315 290 228 minecraft:gray_concrete
setblock 315 290 270 minecraft:gray_concrete
fill 316 290 228 317 293 228 minecraft:brown_terracotta
setblock 316 290 270 minecraft:gray_terracotta
fill 317 290 270 317 292 270 minecraft:brown_terracotta
setblock 322 290 270 minecraft:gray_concrete
fill 323 290 228 323 292 228 minecraft:brown_terracotta
fill 324 290 231 324 292 232 minecraft:brown_terracotta
fill 324 290 239 324 292 239 minecraft:brown_terracotta
fill 324 290 246 324 291 246 minecraft:brown_terracotta
fill 324 290 251 324 292 251 minecraft:brown_terracotta
fill 324 290 261 324 292 261 minecraft:brown_terracotta
setblock 324 290 262 minecraft:gray_concrete
fill 324 290 263 324 292 263 minecraft:brown_terracotta
setblock 324 290 264 minecraft:gray_concrete
setblock 324 290 268 minecraft:gray_concrete
setblock 324 290 269 minecraft:gray_terracotta
fill 282 291 228 283 292 228 minecraft:brown_terracotta
fill 282 291 230 282 292 230 minecraft:brown_terracotta
setblock 282 291 231 minecraft:gray_concrete
fill 282 291 234 282 292 235 minecraft:brown_terracotta
setblock 282 291 236 minecraft:gray_concrete
fill 282 291 237 282 292 239 minecraft:brown_terracotta
fill 282 291 242 282 292 242 minecraft:brown_terracotta
setblock 282 291 247 minecraft:brown_terracotta
fill 282 291 249 282 292 249 minecraft:brown_terracotta
setblock 282 291 250 minecraft:orange_terracotta
fill 282 291 251 282 292 255 minecraft:brown_terracotta
fill 282 291 259 282 292 259 minecraft:brown_terracotta
setblock 282 291 260 minecraft:gray_concrete
fill 282 291 261 282 292 263 minecraft:brown_terracotta
setblock 282 291 266 minecraft:orange_terracotta
setblock 282 291 267 minecraft:gray_concrete
setblock 282 291 269 minecraft:brown_terracotta
setblock 285 291 231 minecraft:light[level=12]
setblock 285 291 238 minecraft:light[level=12]
setblock 285 291 245 minecraft:light[level=12]
setblock 285 291 252 minecraft:light[level=12]
setblock 285 291 259 minecraft:light[level=12]
setblock 285 291 266 minecraft:light[level=12]
setblock 287 291 228 minecraft:light_gray_terracotta
fill 288 291 228 289 291 228 minecraft:gray_concrete
fill 290 291 228 290 292 228 minecraft:brown_terracotta
setblock 290 291 270 minecraft:gray_concrete
setblock 291 291 228 minecraft:gray_concrete
fill 291 291 270 294 292 270 minecraft:brown_terracotta
fill 292 291 228 292 292 228 minecraft:brown_terracotta
setblock 292 291 231 minecraft:light[level=12]
setblock 292 291 238 minecraft:light[level=12]
setblock 292 291 245 minecraft:light[level=12]
setblock 292 291 252 minecraft:light[level=12]
setblock 292 291 259 minecraft:light[level=12]
setblock 292 291 266 minecraft:light[level=12]
fill 294 291 228 296 291 228 minecraft:brown_terracotta
setblock 297 291 228 minecraft:gray_concrete
setblock 299 291 231 minecraft:light[level=12]
setblock 299 291 238 minecraft:light[level=12]
setblock 299 291 245 minecraft:light[level=12]
setblock 299 291 252 minecraft:light[level=12]
setblock 299 291 259 minecraft:light[level=12]
setblock 299 291 266 minecraft:light[level=12]
fill 304 291 230 304 291 231 minecraft:gray_wool
setblock 305 291 228 minecraft:gray_concrete
fill 305 291 229 305 292 229 minecraft:gray_wool
fill 306 291 228 306 292 228 minecraft:brown_terracotta
setblock 306 291 238 minecraft:light[level=12]
setblock 306 291 245 minecraft:light[level=12]
setblock 306 291 252 minecraft:light[level=12]
setblock 306 291 259 minecraft:light[level=12]
setblock 306 291 266 minecraft:light[level=12]
fill 306 291 270 306 292 270 minecraft:brown_terracotta
setblock 307 291 228 minecraft:light_gray_terracotta
fill 307 291 233 307 292 233 minecraft:gray_wool
fill 308 291 228 308 292 228 minecraft:brown_terracotta
fill 308 291 230 308 292 232 minecraft:gray_wool
fill 309 291 228 310 291 228 minecraft:gray_concrete
setblock 309 291 270 minecraft:gray_concrete
fill 311 291 228 313 292 228 minecraft:brown_terracotta
setblock 313 291 231 minecraft:light[level=12]
setblock 313 291 238 minecraft:light[level=12]
setblock 313 291 245 minecraft:light[level=12]
setblock 313 291 252 minecraft:light[level=12]
setblock 313 291 259 minecraft:light[level=12]
setblock 313 291 266 minecraft:light[level=12]
setblock 315 291 228 minecraft:brown_terracotta
fill 315 291 270 316 292 270 minecraft:brown_terracotta
fill 318 291 228 319 291 228 minecraft:gray_concrete
fill 320 291 228 322 292 228 minecraft:brown_terracotta
setblock 320 291 231 minecraft:light[level=12]
setblock 320 291 238 minecraft:light[level=12]
setblock 320 291 245 minecraft:light[level=12]
setblock 320 291 252 minecraft:light[level=12]
setblock 320 291 259 minecraft:light[level=12]
setblock 320 291 266 minecraft:light[level=12]
fill 321 291 270 322 291 270 minecraft:brown_terracotta
fill 324 291 228 324 293 228 minecraft:brown_terracotta
fill 324 291 233 324 292 233 minecraft:brown_terracotta
setblock 324 291 234 minecraft:gray_concrete
fill 324 291 235 324 292 238 minecraft:brown_terracotta
setblock 324 291 258 minecraft:gray_concrete
setblock 324 291 259 minecraft:light_gray_terracotta
setblock 324 291 260 minecraft:gray_concrete
fill 324 291 262 324 292 262 minecraft:brown_terracotta
setblock 324 291 264 minecraft:brown_terracotta
fill 324 291 268 324 292 269 minecraft:brown_terracotta
setblock 282 292 231 minecraft:brown_terracotta
setblock 282 292 232 minecraft:orange_terracotta
setblock 282 292 236 minecraft:brown_terracotta
setblock 282 292 240 minecraft:brown_terracotta
setblock 282 292 241 minecraft:gray_terracotta
setblock 282 292 247 minecraft:light_gray_terracotta
setblock 282 292 250 minecraft:brown_terracotta
setblock 282 292 260 minecraft:brown_terracotta
fill 282 292 266 282 292 267 minecraft:brown_terracotta
setblock 282 292 269 minecraft:light_gray_terracotta
setblock 283 292 270 minecraft:brown_terracotta
fill 287 292 228 289 292 228 minecraft:brown_terracotta
setblock 290 292 270 minecraft:brown_terracotta
setblock 291 292 228 minecraft:brown_terracotta
setblock 294 292 228 minecraft:light_gray_terracotta
fill 295 292 228 297 292 228 minecraft:brown_terracotta
setblock 296 292 270 minecraft:brown_terracotta
fill 304 292 231 304 292 232 minecraft:gray_wool
setblock 305 292 228 minecraft:brown_terracotta
fill 306 292 266 308 295 268 minecraft:light_gray_wool
setblock 307 292 228 minecraft:brown_terracotta
fill 307 292 265 307 297 265 minecraft:light_gray_wool
fill 307 292 269 308 296 269 minecraft:light_gray_wool
setblock 309 292 228 minecraft:orange_terracotta
fill 309 292 268 309 296 268 minecraft:light_gray_wool
fill 309 292 270 309 293 270 minecraft:brown_terracotta
setblock 310 292 228 minecraft:brown_terracotta
setblock 315 292 228 minecraft:light_gray_terracotta
fill 318 292 228 319 292 228 minecraft:brown_terracotta
fill 321 292 270 321 293 270 minecraft:brown_terracotta
setblock 322 292 270 minecraft:light_gray_terracotta
setblock 324 292 234 minecraft:brown_terracotta
setblock 324 292 246 minecraft:orange_terracotta
fill 324 292 258 324 292 260 minecraft:brown_terracotta
setblock 324 292 264 minecraft:light_gray_terracotta
setblock 324 292 265 minecraft:orange_terracotta
setblock 282 293 228 minecraft:brown_terracotta
fill 282 293 229 282 294 238 minecraft:gray_concrete
setblock 282 293 239 minecraft:brown_terracotta
fill 282 293 240 282 300 240 minecraft:gray_concrete
setblock 282 293 241 minecraft:brown_terracotta
fill 282 293 242 282 300 243 minecraft:gray_concrete
setblock 282 293 244 minecraft:brown_terracotta
setblock 282 293 245 minecraft:gray_concrete
setblock 282 293 246 minecraft:gray_terracotta
setblock 282 293 247 minecraft:brown_terracotta
fill 282 293 248 282 293 270 minecraft:gray_concrete
fill 283 293 228 284 294 228 minecraft:gray_concrete
fill 283 293 270 305 293 270 minecraft:gray_concrete
setblock 285 293 228 minecraft:brown_terracotta
fill 286 293 228 287 293 228 minecraft:gray_concrete
setblock 288 293 228 minecraft:gray_terracotta
fill 289 293 228 295 293 228 minecraft:gray_concrete
setblock 296 293 228 minecraft:gray_terracotta
fill 297 293 228 300 294 228 minecraft:gray_concrete
fill 302 293 228 315 293 228 minecraft:gray_concrete
fill 305 293 265 305 295 268 minecraft:light_gray_wool
fill 306 293 229 306 293 230 minecraft:gray_wool
fill 306 293 265 306 296 265 minecraft:light_gray_wool
fill 306 293 269 306 296 269 minecraft:light_gray_wool
setblock 306 293 270 minecraft:light_gray_terracotta
setblock 307 293 230 minecraft:gray_wool
fill 307 293 270 307 295 270 minecraft:light_gray_wool
fill 308 293 265 308 297 265 minecraft:light_gray_wool
setblock 308 293 270 minecraft:gray_concrete
fill 309 293 266 309 297 267 minecraft:light_gray_wool
fill 309 293 269 309 295 269 minecraft:light_gray_wool
fill 310 293 270 311 296 270 minecraft:gray_concrete
fill 313 293 270 315 293 270 minecraft:gray_concrete
setblock 316 293 270 minecraft:light_gray_terracotta
fill 317 293 270 320 293 270 minecraft:gray_concrete
fill 318 293 228 323 294 228 minecraft:gray_concrete
setblock 322 293 270 minecraft:brown_terracotta
fill 323 293 270 323 300 270 minecraft:gray_concrete
fill 324 293 229 324 293 237 minecraft:gray_concrete
fill 324 293 238 324 294 238 minecraft:brown_terracotta
fill 324 293 239 324 294 241 minecraft:gray_concrete
fill 324 293 243 324 293 255 minecraft:gray_concrete
setblock 324 293 256 minecraft:light_gray_terracotta
fill 324 293 257 324 297 259 minecraft:gray_concrete
setblock 324 293 260 minecraft:gray_terracotta
fill 324 293 261 324 297 263 minecraft:gray_concrete
setblock 324 293 264 minecraft:brown_terracotta
setblock 324 293 265 minecraft:light_gray_terracotta
fill 324 293 266 324 293 269 minecraft:gray_concrete
fill 324 293 270 324 294 270 minecraft:brown_terracotta
fill 282 294 228 282 297 228 minecraft:gray_concrete
fill 282 294 239 282 301 239 minecraft:gray_concrete
setblock 282 294 241 minecraft:gray_terracotta
fill 282 294 244 282 300 244 minecraft:gray_concrete
setblock 282 294 245 minecraft:brown_terracotta
fill 282 294 246 282 294 253 minecraft:gray_concrete
setblock 282 294 254 minecraft:light_gray_terracotta
fill 282 294 255 282 294 270 minecraft:gray_concrete
fill 283 294 270 291 294 270 minecraft:gray_concrete
fill 285 294 228 285 300 228 minecraft:gray_concrete
setblock 286 294 228 minecraft:brown_terracotta
fill 287 294 228 289 294 228 minecraft:gray_concrete
setblock 290 294 228 minecraft:light_gray_terracotta
fill 291 294 228 296 294 228 minecraft:gray_concrete
setblock 292 294 270 minecraft:brown_terracotta
fill 293 294 270 305 294 270 minecraft:gray_concrete
fill 301 294 228 311 294 228 minecraft:gray_concrete
fill 304 294 267 304 295 267 minecraft:light_gray_wool
fill 305 294 269 305 296 269 minecraft:light_gray_wool
setblock 306 294 232 minecraft:gray_wool
fill 306 294 264 308 295 264 minecraft:light_gray_wool
fill 306 294 270 306 295 270 minecraft:light_gray_wool
fill 308 294 270 308 295 270 minecraft:light_gray_wool
fill 309 294 265 309 296 265 minecraft:light_gray_wool
fill 309 294 270 309 300 270 minecraft:gray_concrete
fill 310 294 266 310 295 267 minecraft:light_gray_wool
setblock 312 294 228 minecraft:brown_terracotta
fill 312 294 270 313 298 270 minecraft:gray_concrete
fill 313 294 228 316 295 228 minecraft:gray_concrete
setblock 314 294 270 minecraft:orange_terracotta
setblock 315 294 270 minecraft:gray_terracotta
setblock 316 294 270 minecraft:brown_terracotta
setblock 317 294 228 minecraft:brown_terracotta
fill 317 294 270 318 298 270 minecraft:gray_concrete
setblock 319 294 270 minecraft:brown_terracotta
fill 320 294 270 321 300 270 minecraft:gray_concrete
setblock 322 294 270 minecraft:light_gray_terracotta
fill 324 294 228 324 300 231 minecraft:gray_concrete
setblock 324 294 232 minecraft:brown_terracotta
fill 324 294 233 324 294 237 minecraft:gray_concrete
fill 324 294 242 324 296 245 minecraft:gray_concrete
fill 324 294 246 324 295 246 minecraft:brown_terracotta
fill 324 294 247 324 294 251 minecraft:gray_concrete
setblock 324 294 252 minecraft:brown_terracotta
setblock 324 294 253 minecraft:gray_terracotta
setblock 324 294 254 minecraft:brown_terracotta
fill 324 294 255 324 297 256 minecraft:gray_concrete
fill 324 294 260 324 295 260 minecraft:brown_terracotta
fill 324 294 264 324 295 265 minecraft:gray_concrete
setblock 324 294 266 minecraft:light_gray_terracotta
fill 324 294 267 324 294 269 minecraft:gray_concrete
fill 282 295 229 282 296 235 minecraft:gray_concrete
setblock 282 295 236 minecraft:brown_terracotta
fill 282 295 237 282 298 238 minecraft:gray_concrete
setblock 282 295 241 minecraft:brown_terracotta
fill 282 295 245 282 298 245 minecraft:gray_concrete
setblock 282 295 246 minecraft:brown_terracotta
fill 282 295 247 282 299 247 minecraft:gray_concrete
setblock 282 295 248 minecraft:brown_terracotta
fill 282 295 249 282 296 257 minecraft:gray_concrete
fill 282 295 258 282 295 259 minecraft:brown_terracotta
fill 282 295 260 282 296 264 minecraft:gray_concrete
setblock 282 295 265 minecraft:light_gray_terracotta
fill 282 295 266 282 297 266 minecraft:gray_concrete
setblock 282 295 267 minecraft:orange_terracotta
fill 282 295 268 282 300 270 minecraft:gray_concrete
setblock 283 295 228 minecraft:gray_terracotta
fill 283 295 270 284 295 270 minecraft:brown_terracotta
fill 284 295 228 284 300 228 minecraft:gray_concrete
setblock 285 295 231 minecraft:light[level=12]
setblock 285 295 239 minecraft:light[level=12]
setblock 285 295 247 minecraft:light[level=12]
setblock 285 295 255 minecraft:light[level=12]
setblock 285 295 263 minecraft:light[level=12]
fill 285 295 270 286 300 270 minecraft:gray_concrete
fill 286 295 228 288 300 228 minecraft:gray_concrete
setblock 287 295 270 minecraft:brown_terracotta
fill 288 295 270 297 296 270 minecraft:gray_concrete
setblock 289 295 228 minecraft:brown_terracotta
fill 290 295 228 294 296 228 minecraft:gray_concrete
setblock 293 295 231 minecraft:light[level=12]
setblock 293 295 239 minecraft:light[level=12]
setblock 293 295 247 minecraft:light[level=12]
setblock 293 295 255 minecraft:light[level=12]
setblock 293 295 263 minecraft:light[level=12]
setblock 295 295 228 minecraft:light_gray_terracotta
fill 296 295 228 296 300 228 minecraft:gray_concrete
setblock 297 295 228 minecraft:orange_terracotta
setblock 298 295 228 minecraft:gray_terracotta
setblock 298 295 270 minecraft:orange_terracotta
schedule function dropper:buildpart/54_6 1t
