setblock 353 113 251 minecraft:black_concrete
setblock 353 113 255 minecraft:black_concrete
setblock 353 113 256 minecraft:iron_block
fill 353 113 259 354 114 259 minecraft:iron_block
fill 354 113 243 354 113 244 minecraft:black_concrete
setblock 354 113 250 minecraft:black_concrete
setblock 354 113 256 minecraft:black_concrete
fill 354 113 262 354 113 263 minecraft:black_concrete
fill 355 113 243 357 114 244 minecraft:iron_block
fill 355 113 247 355 113 248 minecraft:black_concrete
setblock 355 113 250 minecraft:iron_block
setblock 355 113 256 minecraft:iron_block
fill 355 113 258 355 113 259 minecraft:black_concrete
fill 355 113 262 357 114 263 minecraft:iron_block
fill 356 113 247 356 114 248 minecraft:iron_block
fill 356 113 258 356 114 259 minecraft:iron_block
fill 357 113 247 357 113 248 minecraft:black_concrete
setblock 357 113 250 minecraft:iron_block
setblock 357 113 256 minecraft:iron_block
fill 357 113 258 357 113 259 minecraft:black_concrete
fill 358 113 243 358 113 244 minecraft:black_concrete
fill 358 113 247 359 114 248 minecraft:iron_block
setblock 358 113 250 minecraft:black_concrete
setblock 358 113 256 minecraft:black_concrete
fill 358 113 258 359 114 259 minecraft:iron_block
fill 358 113 262 358 113 263 minecraft:black_concrete
fill 359 113 243 362 113 244 minecraft:iron_block
fill 359 113 250 367 113 250 minecraft:iron_block
setblock 359 113 251 minecraft:black_concrete
fill 359 113 252 360 113 252 minecraft:iron_block
fill 359 113 254 360 113 254 minecraft:iron_block
setblock 359 113 255 minecraft:black_concrete
fill 359 113 256 367 113 256 minecraft:iron_block
fill 359 113 262 362 113 263 minecraft:iron_block
setblock 360 113 247 minecraft:black_concrete
fill 360 113 248 362 114 248 minecraft:iron_block
fill 360 113 251 364 114 251 minecraft:iron_block
fill 360 113 255 364 114 255 minecraft:iron_block
fill 360 113 258 362 114 258 minecraft:iron_block
setblock 360 113 259 minecraft:black_concrete
fill 361 113 245 361 113 246 minecraft:black_concrete
fill 361 113 247 366 113 247 minecraft:iron_block
fill 361 113 252 362 113 252 minecraft:black_concrete
fill 361 113 254 362 113 254 minecraft:black_concrete
fill 361 113 259 366 113 259 minecraft:iron_block
fill 361 113 260 361 113 261 minecraft:black_concrete
fill 362 113 245 364 113 246 minecraft:iron_block
setblock 362 113 249 minecraft:black_concrete
setblock 362 113 257 minecraft:black_concrete
fill 362 113 260 364 113 261 minecraft:iron_block
setblock 363 113 244 minecraft:iron_block
fill 363 113 248 364 113 248 minecraft:black_concrete
fill 363 113 249 367 113 249 minecraft:iron_block
fill 363 113 252 367 113 252 minecraft:iron_block
fill 363 113 254 367 113 254 minecraft:iron_block
fill 363 113 257 367 113 257 minecraft:iron_block
fill 363 113 258 364 113 258 minecraft:black_concrete
setblock 363 113 262 minecraft:iron_block
setblock 365 113 246 minecraft:iron_block
fill 365 113 248 366 113 248 minecraft:iron_block
fill 365 113 251 366 113 251 minecraft:black_concrete
fill 365 113 255 366 113 255 minecraft:black_concrete
fill 365 113 258 366 113 258 minecraft:iron_block
setblock 365 113 260 minecraft:iron_block
setblock 367 113 251 minecraft:iron_block
setblock 367 113 255 minecraft:iron_block
fill 371 113 259 371 280 259 minecraft:stone_bricks
fill 329 114 263 329 123 263 minecraft:stone_bricks
fill 330 114 229 330 114 230 minecraft:stone_bricks
setblock 330 114 231 minecraft:mossy_cobblestone
fill 330 114 232 330 114 234 minecraft:stone_bricks
setblock 330 114 235 minecraft:mossy_cobblestone
fill 330 114 236 330 114 238 minecraft:stone_bricks
setblock 330 114 239 minecraft:mossy_cobblestone
fill 330 114 240 330 114 242 minecraft:stone_bricks
setblock 330 114 243 minecraft:mossy_cobblestone
fill 330 114 244 330 114 246 minecraft:stone_bricks
setblock 330 114 247 minecraft:mossy_cobblestone
fill 330 114 248 330 114 250 minecraft:stone_bricks
setblock 330 114 251 minecraft:mossy_cobblestone
fill 330 114 252 330 114 254 minecraft:stone_bricks
setblock 330 114 255 minecraft:mossy_cobblestone
fill 330 114 256 330 114 258 minecraft:stone_bricks
setblock 330 114 259 minecraft:mossy_cobblestone
fill 330 114 260 330 114 262 minecraft:stone_bricks
setblock 330 114 263 minecraft:mossy_cobblestone
fill 330 114 264 330 114 266 minecraft:stone_bricks
setblock 330 114 267 minecraft:mossy_cobblestone
fill 330 114 268 331 114 269 minecraft:stone_bricks
setblock 331 114 229 minecraft:stone_bricks
setblock 331 114 230 minecraft:mossy_cobblestone
fill 331 114 231 331 114 233 minecraft:stone_bricks
setblock 331 114 234 minecraft:mossy_cobblestone
fill 331 114 235 331 114 237 minecraft:stone_bricks
setblock 331 114 238 minecraft:mossy_cobblestone
fill 331 114 239 331 114 241 minecraft:stone_bricks
setblock 331 114 242 minecraft:mossy_cobblestone
fill 331 114 243 331 114 245 minecraft:stone_bricks
setblock 331 114 246 minecraft:mossy_cobblestone
fill 331 114 247 331 114 249 minecraft:stone_bricks
setblock 331 114 250 minecraft:mossy_cobblestone
fill 331 114 251 331 114 253 minecraft:stone_bricks
setblock 331 114 254 minecraft:mossy_cobblestone
fill 331 114 255 331 114 257 minecraft:stone_bricks
setblock 331 114 258 minecraft:mossy_cobblestone
fill 331 114 259 331 114 261 minecraft:stone_bricks
setblock 331 114 262 minecraft:mossy_cobblestone
fill 331 114 263 331 114 265 minecraft:stone_bricks
setblock 331 114 266 minecraft:mossy_cobblestone
fill 331 114 267 333 114 267 minecraft:stone_bricks
setblock 332 114 229 minecraft:mossy_cobblestone
fill 332 114 230 332 114 232 minecraft:stone_bricks
setblock 332 114 233 minecraft:mossy_cobblestone
fill 332 114 234 332 114 236 minecraft:stone_bricks
setblock 332 114 237 minecraft:mossy_cobblestone
fill 332 114 238 332 114 240 minecraft:stone_bricks
setblock 332 114 241 minecraft:mossy_cobblestone
fill 332 114 242 332 114 244 minecraft:stone_bricks
setblock 332 114 245 minecraft:mossy_cobblestone
fill 332 114 246 332 114 248 minecraft:stone_bricks
setblock 332 114 249 minecraft:mossy_cobblestone
fill 332 114 250 332 114 252 minecraft:stone_bricks
setblock 332 114 253 minecraft:mossy_cobblestone
fill 332 114 254 332 114 256 minecraft:stone_bricks
setblock 332 114 257 minecraft:mossy_cobblestone
fill 332 114 258 332 114 260 minecraft:stone_bricks
setblock 332 114 261 minecraft:mossy_cobblestone
fill 332 114 262 332 114 264 minecraft:stone_bricks
setblock 332 114 265 minecraft:mossy_cobblestone
fill 332 114 266 334 114 266 minecraft:stone_bricks
setblock 332 114 268 minecraft:stone_bricks
setblock 332 114 269 minecraft:mossy_cobblestone
fill 333 114 229 333 114 231 minecraft:stone_bricks
setblock 333 114 232 minecraft:mossy_cobblestone
fill 333 114 233 333 114 235 minecraft:stone_bricks
setblock 333 114 236 minecraft:mossy_cobblestone
fill 333 114 237 333 114 239 minecraft:stone_bricks
setblock 333 114 240 minecraft:mossy_cobblestone
fill 333 114 241 333 114 243 minecraft:stone_bricks
setblock 333 114 244 minecraft:mossy_cobblestone
fill 333 114 245 333 114 247 minecraft:stone_bricks
setblock 333 114 248 minecraft:mossy_cobblestone
fill 333 114 249 333 114 251 minecraft:stone_bricks
setblock 333 114 252 minecraft:mossy_cobblestone
fill 333 114 253 333 114 255 minecraft:stone_bricks
setblock 333 114 256 minecraft:mossy_cobblestone
fill 333 114 257 333 114 259 minecraft:stone_bricks
setblock 333 114 260 minecraft:mossy_cobblestone
fill 333 114 261 333 114 263 minecraft:stone_bricks
setblock 333 114 264 minecraft:mossy_cobblestone
fill 333 114 265 335 114 265 minecraft:stone_bricks
setblock 333 114 268 minecraft:mossy_cobblestone
fill 333 114 269 335 114 269 minecraft:stone_bricks
fill 334 114 229 334 114 230 minecraft:stone_bricks
setblock 334 114 231 minecraft:mossy_cobblestone
fill 334 114 232 334 114 234 minecraft:stone_bricks
setblock 334 114 235 minecraft:mossy_cobblestone
fill 334 114 236 334 114 238 minecraft:stone_bricks
setblock 334 114 239 minecraft:mossy_cobblestone
fill 334 114 240 334 114 242 minecraft:stone_bricks
setblock 334 114 243 minecraft:mossy_cobblestone
fill 334 114 244 334 114 246 minecraft:stone_bricks
setblock 334 114 247 minecraft:mossy_cobblestone
fill 334 114 248 334 114 250 minecraft:stone_bricks
setblock 334 114 251 minecraft:mossy_cobblestone
fill 334 114 252 334 114 254 minecraft:stone_bricks
setblock 334 114 255 minecraft:mossy_cobblestone
fill 334 114 256 334 114 258 minecraft:stone_bricks
setblock 334 114 259 minecraft:mossy_cobblestone
fill 334 114 260 334 114 262 minecraft:stone_bricks
setblock 334 114 263 minecraft:mossy_cobblestone
fill 334 114 264 336 114 264 minecraft:stone_bricks
setblock 334 114 267 minecraft:mossy_cobblestone
fill 334 114 268 336 114 268 minecraft:stone_bricks
setblock 335 114 229 minecraft:stone_bricks
setblock 335 114 230 minecraft:mossy_cobblestone
fill 335 114 231 335 114 233 minecraft:stone_bricks
setblock 335 114 234 minecraft:mossy_cobblestone
fill 335 114 235 335 114 237 minecraft:stone_bricks
setblock 335 114 238 minecraft:mossy_cobblestone
fill 335 114 239 335 114 241 minecraft:stone_bricks
setblock 335 114 242 minecraft:mossy_cobblestone
fill 335 114 243 335 114 245 minecraft:stone_bricks
setblock 335 114 246 minecraft:mossy_cobblestone
fill 335 114 247 335 114 249 minecraft:stone_bricks
setblock 335 114 250 minecraft:mossy_cobblestone
fill 335 114 251 335 114 253 minecraft:stone_bricks
setblock 335 114 254 minecraft:mossy_cobblestone
fill 335 114 255 335 114 257 minecraft:stone_bricks
setblock 335 114 258 minecraft:mossy_cobblestone
fill 335 114 259 335 114 261 minecraft:stone_bricks
setblock 335 114 262 minecraft:mossy_cobblestone
fill 335 114 263 337 114 263 minecraft:stone_bricks
setblock 335 114 266 minecraft:mossy_cobblestone
fill 335 114 267 337 114 267 minecraft:stone_bricks
setblock 336 114 229 minecraft:mossy_cobblestone
fill 336 114 230 336 114 232 minecraft:stone_bricks
setblock 336 114 233 minecraft:mossy_cobblestone
fill 336 114 234 336 114 236 minecraft:stone_bricks
setblock 336 114 237 minecraft:mossy_cobblestone
fill 336 114 238 336 114 240 minecraft:stone_bricks
setblock 336 114 241 minecraft:mossy_cobblestone
fill 336 114 242 336 114 244 minecraft:stone_bricks
setblock 336 114 245 minecraft:mossy_cobblestone
fill 336 114 246 336 114 248 minecraft:stone_bricks
setblock 336 114 249 minecraft:mossy_cobblestone
fill 336 114 250 336 114 252 minecraft:stone_bricks
setblock 336 114 253 minecraft:mossy_cobblestone
fill 336 114 254 336 114 256 minecraft:stone_bricks
setblock 336 114 257 minecraft:mossy_cobblestone
fill 336 114 258 336 114 260 minecraft:stone_bricks
setblock 336 114 261 minecraft:mossy_cobblestone
fill 336 114 262 338 114 262 minecraft:stone_bricks
setblock 336 114 265 minecraft:mossy_cobblestone
fill 336 114 266 338 114 266 minecraft:stone_bricks
setblock 336 114 269 minecraft:mossy_cobblestone
fill 337 114 229 337 114 231 minecraft:stone_bricks
setblock 337 114 232 minecraft:mossy_cobblestone
fill 337 114 233 337 114 235 minecraft:stone_bricks
setblock 337 114 236 minecraft:mossy_cobblestone
fill 337 114 237 337 114 239 minecraft:stone_bricks
setblock 337 114 240 minecraft:mossy_cobblestone
fill 337 114 241 337 114 243 minecraft:stone_bricks
setblock 337 114 244 minecraft:mossy_cobblestone
fill 337 114 245 337 114 247 minecraft:stone_bricks
setblock 337 114 248 minecraft:mossy_cobblestone
fill 337 114 249 337 114 251 minecraft:stone_bricks
setblock 337 114 252 minecraft:mossy_cobblestone
fill 337 114 253 337 114 255 minecraft:stone_bricks
setblock 337 114 256 minecraft:mossy_cobblestone
fill 337 114 257 337 114 259 minecraft:stone_bricks
setblock 337 114 260 minecraft:mossy_cobblestone
fill 337 114 261 339 114 261 minecraft:stone_bricks
setblock 337 114 264 minecraft:mossy_cobblestone
fill 337 114 265 339 114 265 minecraft:stone_bricks
setblock 337 114 268 minecraft:mossy_cobblestone
fill 337 114 269 339 114 269 minecraft:stone_bricks
fill 338 114 229 338 114 230 minecraft:stone_bricks
setblock 338 114 231 minecraft:mossy_cobblestone
fill 338 114 232 338 114 234 minecraft:stone_bricks
setblock 338 114 235 minecraft:mossy_cobblestone
fill 338 114 236 338 114 238 minecraft:stone_bricks
setblock 338 114 239 minecraft:mossy_cobblestone
fill 338 114 240 338 114 242 minecraft:stone_bricks
setblock 338 114 243 minecraft:mossy_cobblestone
fill 338 114 244 338 114 246 minecraft:stone_bricks
setblock 338 114 247 minecraft:mossy_cobblestone
fill 338 114 248 338 114 250 minecraft:stone_bricks
setblock 338 114 251 minecraft:mossy_cobblestone
fill 338 114 252 338 114 254 minecraft:stone_bricks
setblock 338 114 255 minecraft:mossy_cobblestone
fill 338 114 256 338 114 258 minecraft:stone_bricks
setblock 338 114 259 minecraft:mossy_cobblestone
fill 338 114 260 340 114 260 minecraft:stone_bricks
setblock 338 114 263 minecraft:mossy_cobblestone
fill 338 114 264 340 114 264 minecraft:stone_bricks
setblock 338 114 267 minecraft:mossy_cobblestone
fill 338 114 268 340 114 268 minecraft:stone_bricks
setblock 339 114 229 minecraft:stone_bricks
setblock 339 114 230 minecraft:mossy_cobblestone
fill 339 114 231 339 114 233 minecraft:stone_bricks
setblock 339 114 234 minecraft:mossy_cobblestone
fill 339 114 235 339 114 237 minecraft:stone_bricks
setblock 339 114 238 minecraft:mossy_cobblestone
fill 339 114 239 339 114 241 minecraft:stone_bricks
setblock 339 114 242 minecraft:mossy_cobblestone
fill 339 114 243 339 114 245 minecraft:stone_bricks
setblock 339 114 246 minecraft:mossy_cobblestone
fill 339 114 247 339 114 249 minecraft:stone_bricks
setblock 339 114 250 minecraft:mossy_cobblestone
fill 339 114 251 339 114 253 minecraft:stone_bricks
setblock 339 114 254 minecraft:mossy_cobblestone
fill 339 114 255 339 114 257 minecraft:stone_bricks
setblock 339 114 258 minecraft:mossy_cobblestone
fill 339 114 259 341 114 259 minecraft:stone_bricks
setblock 339 114 262 minecraft:mossy_cobblestone
fill 339 114 263 341 114 263 minecraft:stone_bricks
setblock 339 114 266 minecraft:mossy_cobblestone
fill 339 114 267 341 114 267 minecraft:stone_bricks
setblock 340 114 229 minecraft:mossy_cobblestone
fill 340 114 230 340 114 232 minecraft:stone_bricks
setblock 340 114 233 minecraft:mossy_cobblestone
fill 340 114 234 340 114 236 minecraft:stone_bricks
setblock 340 114 237 minecraft:mossy_cobblestone
fill 340 114 238 340 114 240 minecraft:stone_bricks
setblock 340 114 241 minecraft:mossy_cobblestone
fill 340 114 242 340 114 244 minecraft:stone_bricks
setblock 340 114 245 minecraft:mossy_cobblestone
fill 340 114 246 340 114 248 minecraft:stone_bricks
setblock 340 114 249 minecraft:mossy_cobblestone
fill 340 114 250 340 114 252 minecraft:stone_bricks
setblock 340 114 253 minecraft:mossy_cobblestone
fill 340 114 254 340 114 256 minecraft:stone_bricks
setblock 340 114 257 minecraft:mossy_cobblestone
fill 340 114 258 342 114 258 minecraft:stone_bricks
setblock 340 114 261 minecraft:mossy_cobblestone
fill 340 114 262 342 114 262 minecraft:stone_bricks
setblock 340 114 265 minecraft:mossy_cobblestone
fill 340 114 266 342 114 266 minecraft:stone_bricks
setblock 340 114 269 minecraft:mossy_cobblestone
setblock 341 114 229 minecraft:lime_terracotta
fill 341 114 230 341 114 231 minecraft:stone_bricks
setblock 341 114 232 minecraft:mossy_cobblestone
fill 341 114 233 341 114 235 minecraft:stone_bricks
setblock 341 114 236 minecraft:mossy_cobblestone
fill 341 114 237 341 114 239 minecraft:stone_bricks
setblock 341 114 240 minecraft:mossy_cobblestone
fill 341 114 241 341 114 243 minecraft:stone_bricks
setblock 341 114 244 minecraft:mossy_cobblestone
fill 341 114 245 341 114 247 minecraft:stone_bricks
setblock 341 114 248 minecraft:mossy_cobblestone
fill 341 114 249 341 114 251 minecraft:stone_bricks
setblock 341 114 252 minecraft:mossy_cobblestone
fill 341 114 253 341 114 255 minecraft:stone_bricks
setblock 341 114 256 minecraft:mossy_cobblestone
fill 341 114 257 343 114 257 minecraft:stone_bricks
setblock 341 114 260 minecraft:mossy_cobblestone
fill 341 114 261 343 114 261 minecraft:stone_bricks
setblock 341 114 264 minecraft:mossy_cobblestone
fill 341 114 265 343 114 265 minecraft:stone_bricks
setblock 341 114 268 minecraft:mossy_cobblestone
fill 341 114 269 343 114 269 minecraft:stone_bricks
fill 342 114 228 342 114 230 minecraft:stone_bricks
setblock 342 114 231 minecraft:mossy_cobblestone
fill 342 114 232 342 114 234 minecraft:stone_bricks
setblock 342 114 235 minecraft:mossy_cobblestone
fill 342 114 236 342 114 238 minecraft:stone_bricks
setblock 342 114 239 minecraft:mossy_cobblestone
fill 342 114 240 342 114 242 minecraft:stone_bricks
setblock 342 114 243 minecraft:mossy_cobblestone
fill 342 114 244 342 114 246 minecraft:stone_bricks
setblock 342 114 247 minecraft:mossy_cobblestone
fill 342 114 248 342 114 250 minecraft:stone_bricks
setblock 342 114 251 minecraft:mossy_cobblestone
fill 342 114 252 342 114 254 minecraft:stone_bricks
setblock 342 114 255 minecraft:mossy_cobblestone
fill 342 114 256 344 114 256 minecraft:stone_bricks
setblock 342 114 259 minecraft:mossy_cobblestone
fill 342 114 260 344 114 260 minecraft:stone_bricks
setblock 342 114 263 minecraft:mossy_cobblestone
fill 342 114 264 344 114 264 minecraft:stone_bricks
setblock 342 114 267 minecraft:mossy_cobblestone
fill 342 114 268 344 114 268 minecraft:stone_bricks
fill 342 114 270 342 181 270 minecraft:stone_bricks
setblock 343 114 229 minecraft:stone_bricks
setblock 343 114 230 minecraft:mossy_cobblestone
fill 343 114 231 343 114 233 minecraft:stone_bricks
setblock 343 114 234 minecraft:mossy_cobblestone
fill 343 114 235 343 114 237 minecraft:stone_bricks
setblock 343 114 238 minecraft:mossy_cobblestone
fill 343 114 239 343 114 241 minecraft:stone_bricks
setblock 343 114 242 minecraft:mossy_cobblestone
fill 343 114 243 343 114 245 minecraft:stone_bricks
setblock 343 114 246 minecraft:mossy_cobblestone
fill 343 114 247 343 114 249 minecraft:stone_bricks
setblock 343 114 250 minecraft:mossy_cobblestone
fill 343 114 251 343 114 253 minecraft:stone_bricks
setblock 343 114 254 minecraft:mossy_cobblestone
fill 343 114 255 344 114 255 minecraft:stone_bricks
setblock 343 114 258 minecraft:mossy_cobblestone
fill 343 114 259 345 114 259 minecraft:stone_bricks
setblock 343 114 262 minecraft:mossy_cobblestone
fill 343 114 263 345 114 263 minecraft:stone_bricks
setblock 343 114 266 minecraft:mossy_cobblestone
fill 343 114 267 345 114 267 minecraft:stone_bricks
setblock 344 114 229 minecraft:mossy_cobblestone
fill 344 114 230 344 114 232 minecraft:stone_bricks
setblock 344 114 233 minecraft:mossy_cobblestone
fill 344 114 234 344 114 236 minecraft:stone_bricks
setblock 344 114 237 minecraft:mossy_cobblestone
fill 344 114 238 344 114 240 minecraft:stone_bricks
setblock 344 114 241 minecraft:mossy_cobblestone
fill 344 114 242 344 114 244 minecraft:stone_bricks
setblock 344 114 245 minecraft:mossy_cobblestone
fill 344 114 246 344 114 248 minecraft:stone_bricks
setblock 344 114 249 minecraft:mossy_cobblestone
fill 344 114 250 344 114 252 minecraft:stone_bricks
fill 344 114 253 344 115 253 minecraft:gray_concrete
setblock 344 114 254 minecraft:stone_bricks
setblock 344 114 257 minecraft:mossy_cobblestone
fill 344 114 258 345 114 258 minecraft:stone_bricks
setblock 344 114 261 minecraft:mossy_cobblestone
fill 344 114 262 346 114 262 minecraft:stone_bricks
setblock 344 114 265 minecraft:mossy_cobblestone
fill 344 114 266 346 114 266 minecraft:stone_bricks
setblock 344 114 269 minecraft:mossy_cobblestone
fill 345 114 229 345 114 231 minecraft:stone_bricks
setblock 345 114 232 minecraft:mossy_cobblestone
fill 345 114 233 345 114 235 minecraft:stone_bricks
setblock 345 114 236 minecraft:mossy_cobblestone
fill 345 114 237 345 114 239 minecraft:stone_bricks
setblock 345 114 240 minecraft:mossy_cobblestone
fill 345 114 241 345 114 243 minecraft:stone_bricks
setblock 345 114 244 minecraft:mossy_cobblestone
fill 345 114 245 345 114 247 minecraft:stone_bricks
setblock 345 114 248 minecraft:mossy_cobblestone
fill 345 114 249 345 115 252 minecraft:gray_concrete
fill 345 114 253 351 114 253 minecraft:iron_block
fill 345 114 254 345 115 257 minecraft:gray_concrete
setblock 345 114 260 minecraft:mossy_cobblestone
fill 345 114 261 347 114 261 minecraft:stone_bricks
setblock 345 114 264 minecraft:mossy_cobblestone
fill 345 114 265 347 114 265 minecraft:stone_bricks
setblock 345 114 268 minecraft:mossy_cobblestone
fill 345 114 269 347 114 269 minecraft:stone_bricks
fill 346 114 229 346 114 230 minecraft:stone_bricks
setblock 346 114 231 minecraft:mossy_cobblestone
fill 346 114 232 346 114 234 minecraft:stone_bricks
setblock 346 114 235 minecraft:mossy_cobblestone
fill 346 114 236 346 114 238 minecraft:stone_bricks
setblock 346 114 239 minecraft:mossy_cobblestone
fill 346 114 240 346 114 242 minecraft:stone_bricks
setblock 346 114 243 minecraft:mossy_cobblestone
fill 346 114 244 346 114 246 minecraft:stone_bricks
fill 346 114 247 346 115 248 minecraft:gray_concrete
fill 346 114 249 347 114 250 minecraft:iron_block
setblock 346 114 251 minecraft:mossy_cobblestone
setblock 346 114 255 minecraft:mossy_cobblestone
fill 346 114 256 347 114 257 minecraft:iron_block
fill 346 114 258 346 115 259 minecraft:gray_concrete
setblock 346 114 260 minecraft:stone_bricks
setblock 346 114 263 minecraft:mossy_cobblestone
fill 346 114 264 348 114 264 minecraft:stone_bricks
setblock 346 114 267 minecraft:mossy_cobblestone
fill 346 114 268 348 114 268 minecraft:stone_bricks
setblock 347 114 229 minecraft:stone_bricks
setblock 347 114 230 minecraft:mossy_cobblestone
fill 347 114 231 347 114 233 minecraft:stone_bricks
setblock 347 114 234 minecraft:mossy_cobblestone
fill 347 114 235 347 114 237 minecraft:stone_bricks
setblock 347 114 238 minecraft:mossy_cobblestone
fill 347 114 239 347 114 241 minecraft:stone_bricks
setblock 347 114 242 minecraft:mossy_cobblestone
fill 347 114 243 347 114 245 minecraft:stone_bricks
fill 347 114 246 347 115 246 minecraft:gray_concrete
fill 347 114 247 347 114 248 minecraft:iron_block
setblock 347 114 251 minecraft:stone_bricks
setblock 347 114 255 minecraft:stone_bricks
fill 347 114 258 347 114 259 minecraft:iron_block
fill 347 114 260 347 115 260 minecraft:gray_concrete
setblock 347 114 262 minecraft:mossy_cobblestone
fill 347 114 263 349 114 263 minecraft:stone_bricks
setblock 347 114 266 minecraft:mossy_cobblestone
fill 347 114 267 349 114 267 minecraft:stone_bricks
setblock 348 114 229 minecraft:mossy_cobblestone
fill 348 114 230 348 114 232 minecraft:stone_bricks
setblock 348 114 233 minecraft:mossy_cobblestone
fill 348 114 234 348 114 236 minecraft:stone_bricks
setblock 348 114 237 minecraft:mossy_cobblestone
fill 348 114 238 348 114 240 minecraft:stone_bricks
setblock 348 114 241 minecraft:mossy_cobblestone
fill 348 114 242 348 114 244 minecraft:stone_bricks
fill 348 114 245 348 115 245 minecraft:gray_concrete
fill 348 114 246 350 114 246 minecraft:iron_block
setblock 348 114 248 minecraft:stone_bricks
fill 348 114 258 349 114 258 minecraft:stone_bricks
fill 348 114 260 350 114 260 minecraft:iron_block
fill 348 114 261 348 115 261 minecraft:gray_concrete
setblock 348 114 262 minecraft:stone_bricks
setblock 348 114 265 minecraft:mossy_cobblestone
fill 348 114 266 350 114 266 minecraft:stone_bricks
setblock 348 114 269 minecraft:mossy_cobblestone
fill 349 114 229 349 114 231 minecraft:stone_bricks
setblock 349 114 232 minecraft:mossy_cobblestone
fill 349 114 233 349 114 235 minecraft:stone_bricks
setblock 349 114 236 minecraft:mossy_cobblestone
fill 349 114 237 349 114 239 minecraft:stone_bricks
setblock 349 114 240 minecraft:mossy_cobblestone
fill 349 114 241 349 114 243 minecraft:stone_bricks
fill 349 114 244 349 115 244 minecraft:gray_concrete
fill 349 114 245 350 114 245 minecraft:iron_block
setblock 349 114 248 minecraft:mossy_cobblestone
fill 349 114 261 350 114 261 minecraft:iron_block
fill 349 114 262 349 115 262 minecraft:gray_concrete
setblock 349 114 264 minecraft:mossy_cobblestone
fill 349 114 265 351 114 265 minecraft:stone_bricks
setblock 349 114 268 minecraft:mossy_cobblestone
fill 349 114 269 351 114 269 minecraft:stone_bricks
fill 350 114 229 350 114 230 minecraft:stone_bricks
setblock 350 114 231 minecraft:mossy_cobblestone
fill 350 114 232 350 114 234 minecraft:stone_bricks
setblock 350 114 235 minecraft:mossy_cobblestone
fill 350 114 236 350 114 238 minecraft:stone_bricks
setblock 350 114 239 minecraft:mossy_cobblestone
fill 350 114 240 350 114 242 minecraft:stone_bricks
fill 350 114 243 351 115 243 minecraft:gray_concrete
fill 350 114 244 353 114 244 minecraft:iron_block
setblock 350 114 249 minecraft:stone_bricks
fill 350 114 252 351 114 252 minecraft:stone_bricks
setblock 350 114 254 minecraft:stone_bricks
setblock 350 114 257 minecraft:stone_bricks
fill 350 114 262 353 114 262 minecraft:iron_block
fill 350 114 263 351 115 263 minecraft:gray_concrete
fill 350 114 264 351 114 264 minecraft:stone_bricks
setblock 350 114 267 minecraft:mossy_cobblestone
fill 350 114 268 352 114 268 minecraft:stone_bricks
setblock 351 114 229 minecraft:stone_bricks
setblock 351 114 230 minecraft:mossy_cobblestone
fill 351 114 231 351 114 233 minecraft:stone_bricks
setblock 351 114 234 minecraft:mossy_cobblestone
fill 351 114 235 351 114 237 minecraft:stone_bricks
setblock 351 114 238 minecraft:mossy_cobblestone
fill 351 114 239 351 114 241 minecraft:stone_bricks
setblock 351 114 242 minecraft:mossy_cobblestone
setblock 351 114 245 minecraft:stone_bricks
setblock 351 114 246 minecraft:mossy_cobblestone
fill 351 114 249 354 114 249 minecraft:iron_block
setblock 351 114 254 minecraft:mossy_cobblestone
fill 351 114 257 354 114 257 minecraft:iron_block
fill 351 114 260 351 114 261 minecraft:stone_bricks
setblock 351 114 266 minecraft:mossy_cobblestone
fill 351 114 267 353 114 267 minecraft:stone_bricks
fill 352 114 228 352 150 228 minecraft:stone_bricks
setblock 352 114 229 minecraft:mossy_cobblestone
fill 352 114 230 352 114 232 minecraft:stone_bricks
setblock 352 114 233 minecraft:mossy_cobblestone
fill 352 114 234 352 114 236 minecraft:stone_bricks
setblock 352 114 237 minecraft:mossy_cobblestone
fill 352 114 238 352 114 240 minecraft:stone_bricks
setblock 352 114 241 minecraft:mossy_cobblestone
fill 352 114 242 355 115 242 minecraft:gray_concrete
fill 352 114 243 353 114 243 minecraft:iron_block
setblock 352 114 247 minecraft:stone_bricks
fill 352 114 252 352 114 254 minecraft:sea_lantern
setblock 352 114 259 minecraft:stone_bricks
fill 352 114 263 353 114 263 minecraft:iron_block
fill 352 114 264 355 115 264 minecraft:gray_concrete
setblock 352 114 265 minecraft:mossy_cobblestone
fill 352 114 266 354 114 266 minecraft:stone_bricks
setblock 352 114 269 minecraft:mossy_cobblestone
fill 353 114 229 353 114 231 minecraft:stone_bricks
setblock 353 114 232 minecraft:mossy_cobblestone
fill 353 114 233 353 114 235 minecraft:stone_bricks
setblock 353 114 236 minecraft:mossy_cobblestone
fill 353 114 237 353 114 239 minecraft:stone_bricks
setblock 353 114 240 minecraft:mossy_cobblestone
fill 353 114 241 355 114 241 minecraft:stone_bricks
fill 353 114 250 353 114 252 minecraft:sea_lantern
fill 353 114 254 353 114 256 minecraft:sea_lantern
fill 353 114 265 355 114 265 minecraft:stone_bricks
setblock 353 114 268 minecraft:mossy_cobblestone
fill 353 114 269 355 114 269 minecraft:stone_bricks
fill 354 114 229 354 114 230 minecraft:stone_bricks
setblock 354 114 231 minecraft:mossy_cobblestone
fill 354 114 232 354 114 234 minecraft:stone_bricks
setblock 354 114 235 minecraft:mossy_cobblestone
fill 354 114 236 354 114 238 minecraft:stone_bricks
setblock 354 114 239 minecraft:mossy_cobblestone
fill 354 114 240 356 114 240 minecraft:stone_bricks
setblock 354 114 243 minecraft:mossy_cobblestone
setblock 354 114 244 minecraft:stone_bricks
fill 354 114 250 355 114 250 minecraft:sea_lantern
fill 354 114 256 355 114 256 minecraft:sea_lantern
setblock 354 114 262 minecraft:stone_bricks
setblock 354 114 263 minecraft:mossy_cobblestone
setblock 354 114 267 minecraft:mossy_cobblestone
fill 354 114 268 356 114 268 minecraft:stone_bricks
setblock 355 114 229 minecraft:stone_bricks
setblock 355 114 230 minecraft:mossy_cobblestone
fill 355 114 231 355 114 233 minecraft:stone_bricks
setblock 355 114 234 minecraft:mossy_cobblestone
fill 355 114 235 355 114 237 minecraft:stone_bricks
setblock 355 114 238 minecraft:mossy_cobblestone
fill 355 114 239 357 114 239 minecraft:stone_bricks
fill 355 114 247 355 114 248 minecraft:stone_bricks
fill 355 114 249 357 114 249 minecraft:sea_lantern
fill 355 114 257 357 114 257 minecraft:sea_lantern
setblock 355 114 258 minecraft:mossy_cobblestone
setblock 355 114 259 minecraft:stone_bricks
setblock 355 114 266 minecraft:mossy_cobblestone
fill 355 114 267 357 114 267 minecraft:stone_bricks
setblock 356 114 229 minecraft:mossy_cobblestone
fill 356 114 230 356 114 232 minecraft:stone_bricks
setblock 356 114 233 minecraft:mossy_cobblestone
fill 356 114 234 356 114 236 minecraft:stone_bricks
setblock 356 114 237 minecraft:mossy_cobblestone
fill 356 114 238 358 114 238 minecraft:stone_bricks
fill 356 114 241 356 115 241 minecraft:gray_concrete
setblock 356 114 242 minecraft:iron_block
setblock 356 114 264 minecraft:iron_block
fill 356 114 265 356 115 265 minecraft:gray_concrete
fill 356 114 266 358 114 266 minecraft:stone_bricks
setblock 356 114 269 minecraft:mossy_cobblestone
fill 357 114 229 357 114 231 minecraft:stone_bricks
setblock 357 114 232 minecraft:mossy_cobblestone
fill 357 114 233 357 114 235 minecraft:stone_bricks
setblock 357 114 236 minecraft:mossy_cobblestone
fill 357 114 237 359 114 237 minecraft:stone_bricks
setblock 357 114 240 minecraft:mossy_cobblestone
fill 357 114 241 359 114 241 minecraft:stone_bricks
fill 357 114 242 360 115 242 minecraft:gray_concrete
setblock 357 114 247 minecraft:stone_bricks
setblock 357 114 248 minecraft:mossy_cobblestone
fill 357 114 250 359 114 250 minecraft:sea_lantern
fill 357 114 256 359 114 256 minecraft:sea_lantern
fill 357 114 258 357 114 259 minecraft:stone_bricks
fill 357 114 264 360 115 264 minecraft:gray_concrete
fill 357 114 265 359 114 265 minecraft:stone_bricks
setblock 357 114 268 minecraft:mossy_cobblestone
fill 357 114 269 359 114 269 minecraft:stone_bricks
fill 358 114 229 358 114 230 minecraft:stone_bricks
setblock 358 114 231 minecraft:mossy_cobblestone
fill 358 114 232 358 114 234 minecraft:stone_bricks
setblock 358 114 235 minecraft:mossy_cobblestone
fill 358 114 236 360 114 236 minecraft:stone_bricks
setblock 358 114 239 minecraft:mossy_cobblestone
fill 358 114 240 360 114 240 minecraft:stone_bricks
setblock 358 114 243 minecraft:mossy_cobblestone
setblock 358 114 244 minecraft:stone_bricks
fill 358 114 249 361 114 249 minecraft:iron_block
fill 358 114 257 361 114 257 minecraft:iron_block
setblock 358 114 262 minecraft:stone_bricks
setblock 358 114 263 minecraft:mossy_cobblestone
setblock 358 114 267 minecraft:mossy_cobblestone
fill 358 114 268 360 114 268 minecraft:stone_bricks
setblock 359 114 229 minecraft:stone_bricks
setblock 359 114 230 minecraft:mossy_cobblestone
fill 359 114 231 359 114 233 minecraft:stone_bricks
setblock 359 114 234 minecraft:mossy_cobblestone
fill 359 114 235 361 114 235 minecraft:stone_bricks
setblock 359 114 238 minecraft:mossy_cobblestone
fill 359 114 239 361 114 239 minecraft:stone_bricks
fill 359 114 243 360 114 244 minecraft:iron_block
fill 359 114 251 359 114 252 minecraft:sea_lantern
fill 359 114 254 359 114 255 minecraft:sea_lantern
fill 359 114 262 360 114 263 minecraft:iron_block
setblock 359 114 266 minecraft:mossy_cobblestone
fill 359 114 267 361 114 267 minecraft:stone_bricks
setblock 360 114 229 minecraft:mossy_cobblestone
fill 360 114 230 360 114 232 minecraft:stone_bricks
setblock 360 114 233 minecraft:mossy_cobblestone
fill 360 114 234 362 114 234 minecraft:stone_bricks
setblock 360 114 237 minecraft:mossy_cobblestone
fill 360 114 238 362 114 238 minecraft:stone_bricks
setblock 360 114 241 minecraft:mossy_cobblestone
setblock 360 114 247 minecraft:stone_bricks
fill 360 114 250 366 114 250 minecraft:iron_block
fill 360 114 252 360 114 254 minecraft:sea_lantern
fill 360 114 256 366 114 256 minecraft:iron_block
setblock 360 114 259 minecraft:stone_bricks
setblock 360 114 265 minecraft:mossy_cobblestone
fill 360 114 266 362 114 266 minecraft:stone_bricks
setblock 360 114 269 minecraft:mossy_cobblestone
fill 361 114 229 361 114 231 minecraft:stone_bricks
setblock 361 114 232 minecraft:mossy_cobblestone
fill 361 114 233 363 114 233 minecraft:stone_bricks
setblock 361 114 236 minecraft:mossy_cobblestone
fill 361 114 237 363 114 237 minecraft:stone_bricks
setblock 361 114 240 minecraft:mossy_cobblestone
fill 361 114 241 362 114 242 minecraft:stone_bricks
fill 361 114 243 362 115 243 minecraft:gray_concrete
fill 361 114 244 362 114 244 minecraft:iron_block
fill 361 114 245 361 114 246 minecraft:stone_bricks
fill 361 114 247 365 114 247 minecraft:iron_block
setblock 361 114 252 minecraft:mossy_cobblestone
fill 361 114 253 367 114 253 minecraft:iron_block
fill 361 114 254 362 114 254 minecraft:stone_bricks
fill 361 114 259 365 114 259 minecraft:iron_block
setblock 361 114 260 minecraft:mossy_cobblestone
setblock 361 114 261 minecraft:stone_bricks
fill 361 114 262 362 114 262 minecraft:iron_block
fill 361 114 263 362 115 263 minecraft:gray_concrete
setblock 361 114 264 minecraft:mossy_cobblestone
fill 361 114 265 363 114 265 minecraft:stone_bricks
setblock 361 114 268 minecraft:mossy_cobblestone
fill 361 114 269 363 114 269 minecraft:stone_bricks
fill 362 114 229 362 114 230 minecraft:stone_bricks
setblock 362 114 231 minecraft:mossy_cobblestone
fill 362 114 232 364 114 232 minecraft:stone_bricks
setblock 362 114 235 minecraft:mossy_cobblestone
fill 362 114 236 364 114 236 minecraft:stone_bricks
setblock 362 114 239 minecraft:mossy_cobblestone
fill 362 114 240 364 114 240 minecraft:stone_bricks
fill 362 114 245 363 114 246 minecraft:iron_block
setblock 362 114 249 minecraft:stone_bricks
setblock 362 114 252 minecraft:stone_bricks
setblock 362 114 257 minecraft:stone_bricks
fill 362 114 260 363 114 261 minecraft:iron_block
fill 362 114 264 364 114 264 minecraft:stone_bricks
setblock 362 114 267 minecraft:mossy_cobblestone
fill 362 114 268 364 114 268 minecraft:stone_bricks
setblock 363 114 229 minecraft:stone_bricks
setblock 363 114 230 minecraft:mossy_cobblestone
fill 363 114 231 365 114 231 minecraft:stone_bricks
setblock 363 114 234 minecraft:mossy_cobblestone
fill 363 114 235 365 114 235 minecraft:stone_bricks
setblock 363 114 238 minecraft:mossy_cobblestone
fill 363 114 239 365 114 239 minecraft:stone_bricks
setblock 363 114 241 minecraft:stone_bricks
setblock 363 114 242 minecraft:mossy_cobblestone
fill 363 114 243 365 114 243 minecraft:stone_bricks
fill 363 114 244 363 115 244 minecraft:gray_concrete
fill 363 114 248 364 114 248 minecraft:stone_bricks
fill 363 114 249 366 114 249 minecraft:iron_block
fill 363 114 252 366 114 252 minecraft:iron_block
fill 363 114 254 366 114 254 minecraft:iron_block
fill 363 114 257 366 114 257 minecraft:iron_block
setblock 363 114 258 minecraft:mossy_cobblestone
fill 363 114 262 363 115 262 minecraft:gray_concrete
fill 363 114 263 365 114 263 minecraft:stone_bricks
setblock 363 114 266 minecraft:mossy_cobblestone
fill 363 114 267 365 114 267 minecraft:stone_bricks
setblock 364 114 229 minecraft:mossy_cobblestone
fill 364 114 230 366 114 230 minecraft:stone_bricks
setblock 364 114 233 minecraft:mossy_cobblestone
fill 364 114 234 366 114 234 minecraft:stone_bricks
setblock 364 114 237 minecraft:mossy_cobblestone
fill 364 114 238 366 114 238 minecraft:stone_bricks
setblock 364 114 241 minecraft:mossy_cobblestone
fill 364 114 242 366 114 242 minecraft:stone_bricks
setblock 364 114 244 minecraft:stone_bricks
fill 364 114 245 364 115 245 minecraft:gray_concrete
setblock 364 114 246 minecraft:iron_block
setblock 364 114 258 minecraft:stone_bricks
setblock 364 114 260 minecraft:iron_block
fill 364 114 261 364 115 261 minecraft:gray_concrete
fill 364 114 262 366 114 262 minecraft:stone_bricks
setblock 364 114 265 minecraft:mossy_cobblestone
fill 364 114 266 366 114 266 minecraft:stone_bricks
setblock 364 114 269 minecraft:mossy_cobblestone
fill 365 114 229 367 114 229 minecraft:stone_bricks
setblock 365 114 232 minecraft:mossy_cobblestone
fill 365 114 233 367 114 233 minecraft:stone_bricks
setblock 365 114 236 minecraft:mossy_cobblestone
fill 365 114 237 367 114 237 minecraft:stone_bricks
setblock 365 114 240 minecraft:mossy_cobblestone
fill 365 114 241 367 114 241 minecraft:stone_bricks
setblock 365 114 244 minecraft:mossy_cobblestone
fill 365 114 245 367 114 245 minecraft:stone_bricks
fill 365 114 246 365 115 246 minecraft:gray_concrete
setblock 365 114 248 minecraft:iron_block
setblock 365 114 251 minecraft:stone_bricks
setblock 365 114 255 minecraft:stone_bricks
setblock 365 114 258 minecraft:iron_block
fill 365 114 260 365 115 260 minecraft:gray_concrete
fill 365 114 261 367 114 261 minecraft:stone_bricks
setblock 365 114 264 minecraft:mossy_cobblestone
fill 365 114 265 367 114 265 minecraft:stone_bricks
setblock 365 114 268 minecraft:mossy_cobblestone
fill 365 114 269 367 114 269 minecraft:stone_bricks
setblock 366 114 231 minecraft:mossy_cobblestone
fill 366 114 232 368 114 232 minecraft:stone_bricks
setblock 366 114 235 minecraft:mossy_cobblestone
fill 366 114 236 368 114 236 minecraft:stone_bricks
setblock 366 114 239 minecraft:mossy_cobblestone
fill 366 114 240 368 114 240 minecraft:stone_bricks
setblock 366 114 243 minecraft:mossy_cobblestone
fill 366 114 244 368 114 244 minecraft:stone_bricks
setblock 366 114 246 minecraft:stone_bricks
fill 366 114 247 366 115 248 minecraft:gray_concrete
setblock 366 114 251 minecraft:mossy_cobblestone
setblock 366 114 255 minecraft:mossy_cobblestone
fill 366 114 258 366 115 259 minecraft:gray_concrete
fill 366 114 260 368 114 260 minecraft:stone_bricks
setblock 366 114 263 minecraft:mossy_cobblestone
fill 366 114 264 368 114 264 minecraft:stone_bricks
setblock 366 114 267 minecraft:mossy_cobblestone
fill 366 114 268 368 114 268 minecraft:stone_bricks
setblock 367 114 230 minecraft:mossy_cobblestone
fill 367 114 231 369 114 231 minecraft:stone_bricks
setblock 367 114 234 minecraft:mossy_cobblestone
fill 367 114 235 369 114 235 minecraft:stone_bricks
setblock 367 114 238 minecraft:mossy_cobblestone
fill 367 114 239 369 114 239 minecraft:stone_bricks
setblock 367 114 242 minecraft:mossy_cobblestone
fill 367 114 243 369 114 243 minecraft:stone_bricks
setblock 367 114 246 minecraft:mossy_cobblestone
fill 367 114 247 368 114 248 minecraft:stone_bricks
fill 367 114 249 367 115 252 minecraft:gray_concrete
fill 367 114 254 367 115 257 minecraft:gray_concrete
setblock 367 114 258 minecraft:mossy_cobblestone
fill 367 114 259 369 114 259 minecraft:stone_bricks
setblock 367 114 262 minecraft:mossy_cobblestone
fill 367 114 263 369 114 263 minecraft:stone_bricks
setblock 367 114 266 minecraft:mossy_cobblestone
fill 367 114 267 369 114 267 minecraft:stone_bricks
setblock 368 114 229 minecraft:mossy_cobblestone
fill 368 114 230 370 114 230 minecraft:stone_bricks
setblock 368 114 233 minecraft:mossy_cobblestone
fill 368 114 234 370 114 234 minecraft:stone_bricks
setblock 368 114 237 minecraft:mossy_cobblestone
fill 368 114 238 370 114 238 minecraft:stone_bricks
setblock 368 114 241 minecraft:mossy_cobblestone
fill 368 114 242 370 114 242 minecraft:stone_bricks
setblock 368 114 245 minecraft:mossy_cobblestone
fill 368 114 246 370 114 246 minecraft:stone_bricks
setblock 368 114 249 minecraft:mossy_cobblestone
fill 368 114 250 368 114 252 minecraft:stone_bricks
fill 368 114 253 368 115 253 minecraft:gray_concrete
fill 368 114 254 368 114 256 minecraft:stone_bricks
setblock 368 114 257 minecraft:mossy_cobblestone
fill 368 114 258 370 114 258 minecraft:stone_bricks
setblock 368 114 261 minecraft:mossy_cobblestone
fill 368 114 262 370 114 262 minecraft:stone_bricks
setblock 368 114 265 minecraft:mossy_cobblestone
fill 368 114 266 370 114 266 minecraft:stone_bricks
setblock 368 114 269 minecraft:mossy_cobblestone
fill 369 114 229 370 114 229 minecraft:stone_bricks
setblock 369 114 232 minecraft:mossy_cobblestone
fill 369 114 233 370 114 233 minecraft:stone_bricks
setblock 369 114 236 minecraft:mossy_cobblestone
fill 369 114 237 370 114 237 minecraft:stone_bricks
setblock 369 114 240 minecraft:mossy_cobblestone
fill 369 114 241 370 114 241 minecraft:stone_bricks
setblock 369 114 244 minecraft:mossy_cobblestone
fill 369 114 245 370 114 245 minecraft:stone_bricks
setblock 369 114 247 minecraft:stone_bricks
setblock 369 114 248 minecraft:mossy_cobblestone
fill 369 114 249 369 114 251 minecraft:stone_bricks
setblock 369 114 252 minecraft:mossy_cobblestone
fill 369 114 253 369 114 255 minecraft:stone_bricks
setblock 369 114 256 minecraft:mossy_cobblestone
fill 369 114 257 370 114 257 minecraft:stone_bricks
setblock 369 114 260 minecraft:mossy_cobblestone
fill 369 114 261 370 114 261 minecraft:stone_bricks
setblock 369 114 264 minecraft:mossy_cobblestone
fill 369 114 265 370 114 265 minecraft:stone_bricks
setblock 369 114 268 minecraft:mossy_cobblestone
fill 369 114 269 370 114 269 minecraft:stone_bricks
setblock 370 114 231 minecraft:mossy_cobblestone
setblock 370 114 232 minecraft:stone_bricks
setblock 370 114 235 minecraft:mossy_cobblestone
setblock 370 114 236 minecraft:stone_bricks
setblock 370 114 239 minecraft:mossy_cobblestone
setblock 370 114 240 minecraft:stone_bricks
setblock 370 114 243 minecraft:mossy_cobblestone
setblock 370 114 244 minecraft:stone_bricks
setblock 370 114 247 minecraft:mossy_cobblestone
fill 370 114 248 370 114 250 minecraft:stone_bricks
setblock 370 114 251 minecraft:mossy_cobblestone
fill 370 114 252 370 114 254 minecraft:stone_bricks
setblock 370 114 255 minecraft:mossy_cobblestone
setblock 370 114 256 minecraft:stone_bricks
setblock 370 114 259 minecraft:mossy_cobblestone
setblock 370 114 260 minecraft:stone_bricks
setblock 370 114 263 minecraft:mossy_cobblestone
setblock 370 114 264 minecraft:stone_bricks
setblock 370 114 267 minecraft:mossy_cobblestone
setblock 370 114 268 minecraft:stone_bricks
setblock 329 115 255 minecraft:cobblestone
setblock 340 115 270 minecraft:mossy_stone_bricks
fill 342 115 228 342 270 228 minecraft:stone_bricks
setblock 371 115 236 minecraft:mossy_stone_bricks
fill 329 116 255 329 174 255 minecraft:stone_bricks
fill 329 116 267 331 116 267 minecraft:waxed_oxidized_copper
fill 332 116 266 335 119 268 minecraft:gray_concrete
fill 336 116 267 338 116 267 minecraft:waxed_oxidized_copper
fill 339 116 266 342 119 268 minecraft:gray_concrete
fill 340 116 270 340 174 270 minecraft:stone_bricks
fill 343 116 267 345 116 267 minecraft:waxed_oxidized_copper
setblock 345 116 228 minecraft:cobblestone
setblock 345 116 270 minecraft:mossy_cobblestone
fill 346 116 266 349 119 268 minecraft:gray_concrete
fill 350 116 267 352 116 267 minecraft:waxed_oxidized_copper
fill 353 116 266 356 119 268 minecraft:gray_concrete
fill 357 116 267 359 116 267 minecraft:waxed_oxidized_copper
fill 360 116 266 363 119 268 minecraft:gray_concrete
fill 364 116 267 370 116 267 minecraft:waxed_oxidized_copper
fill 371 116 236 371 237 236 minecraft:stone_bricks
setblock 329 117 251 minecraft:mossy_stone_bricks
fill 329 117 266 330 118 268 minecraft:waxed_oxidized_copper
fill 329 117 269 329 147 270 minecraft:stone_bricks
fill 331 117 266 331 118 268 minecraft:gray_concrete
setblock 332 117 231 minecraft:light[level=12]
setblock 332 117 238 minecraft:light[level=12]
setblock 332 117 245 minecraft:light[level=12]
setblock 332 117 252 minecraft:light[level=12]
setblock 332 117 259 minecraft:light[level=12]
fill 332 117 265 335 118 265 minecraft:gray_concrete
fill 332 117 269 335 118 269 minecraft:gray_concrete
fill 336 117 266 336 118 268 minecraft:gray_concrete
fill 337 117 266 337 118 268 minecraft:waxed_oxidized_copper
fill 338 117 266 338 118 268 minecraft:gray_concrete
setblock 339 117 228 minecraft:cobblestone
setblock 339 117 231 minecraft:light[level=12]
setblock 339 117 238 minecraft:light[level=12]
setblock 339 117 245 minecraft:light[level=12]
setblock 339 117 252 minecraft:light[level=12]
setblock 339 117 259 minecraft:light[level=12]
fill 339 117 265 342 118 265 minecraft:gray_concrete
fill 339 117 269 342 118 269 minecraft:gray_concrete
fill 343 117 266 343 118 268 minecraft:gray_concrete
fill 344 117 266 344 118 268 minecraft:waxed_oxidized_copper
fill 345 117 228 345 148 228 minecraft:stone_bricks
fill 345 117 266 345 118 268 minecraft:gray_concrete
fill 345 117 270 345 201 270 minecraft:stone_bricks
setblock 346 117 231 minecraft:light[level=12]
setblock 346 117 238 minecraft:light[level=12]
setblock 346 117 245 minecraft:light[level=12]
setblock 346 117 252 minecraft:light[level=12]
setblock 346 117 259 minecraft:light[level=12]
fill 346 117 265 349 118 265 minecraft:gray_concrete
fill 346 117 269 349 118 269 minecraft:gray_concrete
fill 350 117 266 350 118 268 minecraft:gray_concrete
fill 351 117 266 351 118 268 minecraft:waxed_oxidized_copper
fill 352 117 266 352 118 268 minecraft:gray_concrete
setblock 353 117 231 minecraft:light[level=12]
setblock 353 117 238 minecraft:light[level=12]
setblock 353 117 245 minecraft:light[level=12]
setblock 353 117 252 minecraft:light[level=12]
setblock 353 117 259 minecraft:light[level=12]
fill 353 117 265 356 118 265 minecraft:gray_concrete
fill 353 117 269 356 118 269 minecraft:gray_concrete
fill 357 117 266 357 118 268 minecraft:gray_concrete
fill 358 117 266 358 118 268 minecraft:waxed_oxidized_copper
fill 359 117 266 359 118 268 minecraft:gray_concrete
setblock 360 117 231 minecraft:light[level=12]
setblock 360 117 238 minecraft:light[level=12]
setblock 360 117 245 minecraft:light[level=12]
setblock 360 117 252 minecraft:light[level=12]
setblock 360 117 259 minecraft:light[level=12]
fill 360 117 265 363 118 265 minecraft:gray_concrete
fill 360 117 269 363 118 269 minecraft:gray_concrete
fill 364 117 266 364 118 268 minecraft:gray_concrete
fill 365 117 266 370 118 268 minecraft:waxed_oxidized_copper
setblock 367 117 231 minecraft:light[level=12]
setblock 367 117 238 minecraft:light[level=12]
setblock 367 117 245 minecraft:light[level=12]
setblock 367 117 252 minecraft:light[level=12]
setblock 367 117 259 minecraft:light[level=12]
setblock 371 117 229 minecraft:cobblestone
fill 371 117 230 371 117 231 minecraft:stone_bricks
fill 371 117 267 371 118 267 minecraft:waxed_oxidized_copper
fill 329 118 251 329 197 251 minecraft:stone_bricks
setblock 332 118 231 minecraft:light[level=15]
setblock 332 118 239 minecraft:light[level=15]
setblock 332 118 247 minecraft:light[level=15]
setblock 332 118 255 minecraft:light[level=15]
setblock 332 118 263 minecraft:light[level=15]
fill 332 118 270 332 174 270 minecraft:stone_bricks
setblock 333 118 270 minecraft:cobblestone
fill 339 118 228 339 200 228 minecraft:stone_bricks
setblock 340 118 231 minecraft:light[level=15]
setblock 340 118 239 minecraft:light[level=15]
setblock 340 118 247 minecraft:light[level=15]
setblock 340 118 255 minecraft:light[level=15]
setblock 340 118 263 minecraft:light[level=15]
setblock 348 118 231 minecraft:light[level=15]
setblock 348 118 239 minecraft:light[level=15]
setblock 348 118 247 minecraft:light[level=15]
setblock 348 118 255 minecraft:light[level=15]
setblock 348 118 263 minecraft:light[level=15]
fill 349 118 231 349 192 231 minecraft:iron_block
fill 350 118 265 350 192 265 minecraft:iron_block
setblock 350 118 270 minecraft:mossy_stone_bricks
setblock 356 118 231 minecraft:light[level=15]
setblock 356 118 239 minecraft:light[level=15]
setblock 356 118 247 minecraft:light[level=15]
setblock 356 118 255 minecraft:light[level=15]
setblock 356 118 263 minecraft:light[level=15]
setblock 364 118 231 minecraft:light[level=15]
setblock 364 118 239 minecraft:light[level=15]
setblock 364 118 247 minecraft:light[level=15]
setblock 364 118 255 minecraft:light[level=15]
setblock 364 118 263 minecraft:light[level=15]
fill 366 118 228 368 118 230 minecraft:waxed_oxidized_copper
fill 366 118 231 368 121 234 minecraft:gray_concrete
fill 366 118 235 368 118 237 minecraft:waxed_oxidized_copper
fill 366 118 238 368 121 241 minecraft:gray_concrete
fill 366 118 242 368 118 244 minecraft:waxed_oxidized_copper
fill 366 118 245 368 121 248 minecraft:gray_concrete
fill 366 118 249 368 118 251 minecraft:waxed_oxidized_copper
fill 366 118 252 368 121 255 minecraft:gray_concrete
fill 366 118 256 368 118 258 minecraft:waxed_oxidized_copper
fill 366 118 259 368 121 262 minecraft:gray_concrete
fill 366 118 263 368 118 265 minecraft:waxed_oxidized_copper
fill 366 118 269 368 121 269 minecraft:waxed_oxidized_copper
fill 371 118 229 371 124 230 minecraft:stone_bricks
setblock 371 118 231 minecraft:mossy_stone_bricks
fill 329 119 243 329 226 243 minecraft:stone_bricks
setblock 329 119 244 minecraft:mossy_stone_bricks
fill 329 119 245 329 138 246 minecraft:stone_bricks
fill 329 119 266 329 139 266 minecraft:stone_bricks
fill 329 119 267 331 119 267 minecraft:waxed_oxidized_copper
fill 329 119 268 329 139 268 minecraft:stone_bricks
fill 333 119 270 333 169 270 minecraft:stone_bricks
fill 336 119 267 338 119 267 minecraft:waxed_oxidized_copper
fill 343 119 267 345 119 267 minecraft:waxed_oxidized_copper
fill 348 119 265 349 139 265 minecraft:iron_block
fill 350 119 266 350 139 266 minecraft:iron_block
fill 350 119 267 352 119 267 minecraft:waxed_oxidized_copper
fill 350 119 270 350 150 270 minecraft:stone_bricks
fill 357 119 267 359 119 267 minecraft:waxed_oxidized_copper
fill 364 119 267 370 119 267 minecraft:waxed_oxidized_copper
fill 365 119 231 365 120 234 minecraft:gray_concrete
fill 365 119 238 365 120 241 minecraft:gray_concrete
fill 365 119 245 365 120 248 minecraft:gray_concrete
fill 365 119 252 365 120 255 minecraft:gray_concrete
fill 365 119 259 365 120 262 minecraft:gray_concrete
fill 366 119 228 368 121 229 minecraft:waxed_oxidized_copper
fill 366 119 230 368 120 230 minecraft:gray_concrete
fill 366 119 235 368 120 235 minecraft:gray_concrete
fill 366 119 236 368 121 236 minecraft:waxed_oxidized_copper
fill 366 119 237 368 120 237 minecraft:gray_concrete
fill 366 119 242 368 120 242 minecraft:gray_concrete
fill 366 119 243 368 121 243 minecraft:waxed_oxidized_copper
fill 366 119 244 368 120 244 minecraft:gray_concrete
fill 366 119 249 368 120 249 minecraft:gray_concrete
fill 366 119 250 368 121 250 minecraft:waxed_oxidized_copper
fill 366 119 251 368 120 251 minecraft:gray_concrete
fill 366 119 256 368 120 256 minecraft:gray_concrete
fill 366 119 257 368 121 257 minecraft:waxed_oxidized_copper
fill 366 119 258 368 120 258 minecraft:gray_concrete
fill 366 119 263 368 120 263 minecraft:gray_concrete
fill 366 119 264 368 121 266 minecraft:waxed_oxidized_copper
fill 366 119 268 368 121 268 minecraft:waxed_oxidized_copper
fill 366 119 270 368 120 270 minecraft:waxed_oxidized_copper
fill 369 119 231 369 120 234 minecraft:gray_concrete
fill 369 119 238 369 120 241 minecraft:gray_concrete
fill 369 119 245 369 120 248 minecraft:gray_concrete
fill 369 119 252 369 120 255 minecraft:gray_concrete
fill 369 119 259 369 120 262 minecraft:gray_concrete
fill 371 119 231 371 209 231 minecraft:stone_bricks
setblock 371 119 239 minecraft:mossy_stone_bricks
fill 371 119 240 371 144 240 minecraft:stone_bricks
fill 371 119 267 371 139 267 minecraft:stone_bricks
setblock 329 120 239 minecraft:mossy_cobblestone
setblock 329 120 244 minecraft:mossy_cobblestone
fill 329 120 267 329 138 267 minecraft:stone_bricks
setblock 330 120 229 minecraft:green_concrete
setblock 344 120 228 minecraft:mossy_stone_bricks
fill 347 120 265 347 120 267 minecraft:light_gray_concrete
fill 348 120 230 348 120 232 minecraft:light_gray_concrete
fill 348 120 264 350 120 264 minecraft:light_gray_concrete
fill 348 120 266 349 138 267 minecraft:iron_block
fill 348 120 268 350 120 268 minecraft:light_gray_concrete
fill 349 120 230 350 120 230 minecraft:light_gray_concrete
fill 349 120 232 350 120 232 minecraft:light_gray_concrete
setblock 350 120 231 minecraft:light_gray_concrete
fill 350 120 267 350 138 267 minecraft:iron_block
setblock 351 120 228 minecraft:mossy_stone_bricks
fill 351 120 265 351 120 267 minecraft:light_gray_concrete
fill 365 120 264 365 120 266 minecraft:light_gray_concrete
fill 366 120 267 368 121 267 minecraft:waxed_oxidized_copper
fill 371 120 239 371 182 239 minecraft:stone_bricks
fill 329 121 239 329 129 239 minecraft:stone_bricks
fill 329 121 244 329 127 244 minecraft:stone_bricks
setblock 331 121 270 minecraft:mossy_cobblestone
fill 340 121 232 341 122 233 minecraft:light_blue_stained_glass
fill 341 121 234 341 122 234 minecraft:light_blue_stained_glass
fill 344 121 228 344 131 228 minecraft:stone_bricks
fill 351 121 228 351 280 228 minecraft:stone_bricks
fill 366 121 230 368 121 230 minecraft:waxed_oxidized_copper
fill 366 121 235 368 121 235 minecraft:waxed_oxidized_copper
fill 366 121 237 368 121 237 minecraft:waxed_oxidized_copper
fill 366 121 242 368 121 242 minecraft:waxed_oxidized_copper
fill 366 121 244 368 121 244 minecraft:waxed_oxidized_copper
fill 366 121 249 368 121 249 minecraft:waxed_oxidized_copper
fill 366 121 251 368 121 251 minecraft:waxed_oxidized_copper
fill 366 121 256 368 121 256 minecraft:waxed_oxidized_copper
fill 366 121 258 368 121 258 minecraft:waxed_oxidized_copper
fill 366 121 263 368 121 263 minecraft:waxed_oxidized_copper
fill 366 121 270 368 172 270 minecraft:stone_bricks
setblock 371 121 258 minecraft:cobblestone
fill 331 122 270 331 238 270 minecraft:stone_bricks
fill 366 122 228 368 144 228 minecraft:stone_bricks
fill 366 122 265 366 192 265 minecraft:iron_block
fill 371 122 258 371 125 258 minecraft:stone_bricks
setblock 332 123 231 minecraft:light[level=12]
setblock 332 123 238 minecraft:light[level=12]
setblock 332 123 245 minecraft:light[level=12]
setblock 332 123 252 minecraft:light[level=12]
setblock 332 123 259 minecraft:light[level=12]
setblock 332 123 266 minecraft:light[level=12]
setblock 339 123 231 minecraft:light[level=12]
setblock 339 123 238 minecraft:light[level=12]
setblock 339 123 245 minecraft:light[level=12]
setblock 339 123 252 minecraft:light[level=12]
setblock 339 123 259 minecraft:light[level=12]
setblock 339 123 266 minecraft:light[level=12]
setblock 346 123 231 minecraft:light[level=12]
setblock 346 123 238 minecraft:light[level=12]
setblock 346 123 245 minecraft:light[level=12]
setblock 346 123 252 minecraft:light[level=12]
setblock 346 123 259 minecraft:light[level=12]
setblock 346 123 266 minecraft:light[level=12]
setblock 353 123 231 minecraft:light[level=12]
setblock 353 123 238 minecraft:light[level=12]
setblock 353 123 245 minecraft:light[level=12]
setblock 353 123 252 minecraft:light[level=12]
setblock 353 123 259 minecraft:light[level=12]
setblock 353 123 266 minecraft:light[level=12]
setblock 360 123 231 minecraft:light[level=12]
setblock 360 123 238 minecraft:light[level=12]
setblock 360 123 245 minecraft:light[level=12]
setblock 360 123 252 minecraft:light[level=12]
setblock 360 123 259 minecraft:light[level=12]
setblock 360 123 266 minecraft:light[level=12]
setblock 367 123 231 minecraft:light[level=12]
setblock 367 123 238 minecraft:light[level=12]
setblock 367 123 245 minecraft:light[level=12]
setblock 367 123 252 minecraft:light[level=12]
setblock 367 123 259 minecraft:light[level=12]
setblock 367 123 266 minecraft:light[level=12]
setblock 329 124 263 minecraft:mossy_stone_bricks
setblock 332 124 228 minecraft:mossy_stone_bricks
setblock 329 125 230 minecraft:cobblestone
fill 329 125 263 329 280 263 minecraft:stone_bricks
fill 332 125 228 332 280 228 minecraft:stone_bricks
setblock 332 125 231 minecraft:light[level=15]
setblock 332 125 239 minecraft:light[level=15]
setblock 332 125 247 minecraft:light[level=15]
setblock 332 125 255 minecraft:light[level=15]
setblock 332 125 263 minecraft:light[level=15]
setblock 340 125 231 minecraft:light[level=15]
setblock 340 125 239 minecraft:light[level=15]
setblock 340 125 247 minecraft:light[level=15]
setblock 340 125 255 minecraft:light[level=15]
setblock 340 125 263 minecraft:light[level=15]
setblock 346 125 228 minecraft:mossy_cobblestone
setblock 348 125 231 minecraft:light[level=15]
setblock 348 125 239 minecraft:light[level=15]
setblock 348 125 247 minecraft:light[level=15]
setblock 348 125 255 minecraft:light[level=15]
setblock 348 125 263 minecraft:light[level=15]
setblock 356 125 231 minecraft:light[level=15]
setblock 356 125 239 minecraft:light[level=15]
setblock 356 125 247 minecraft:light[level=15]
setblock 356 125 255 minecraft:light[level=15]
setblock 356 125 263 minecraft:light[level=15]
setblock 364 125 231 minecraft:light[level=15]
setblock 364 125 239 minecraft:light[level=15]
setblock 364 125 247 minecraft:light[level=15]
setblock 364 125 255 minecraft:light[level=15]
setblock 364 125 263 minecraft:light[level=15]
fill 371 125 229 371 167 229 minecraft:stone_bricks
setblock 371 125 230 minecraft:cobblestone
fill 329 126 230 329 233 230 minecraft:stone_bricks
setblock 330 126 270 minecraft:cobblestone
setblock 331 126 228 minecraft:mossy_stone_bricks
fill 346 126 228 346 237 228 minecraft:stone_bricks
fill 365 126 264 365 126 266 minecraft:light_gray_concrete
fill 366 126 264 367 126 264 minecraft:light_gray_concrete
fill 366 126 266 367 126 266 minecraft:light_gray_concrete
setblock 367 126 265 minecraft:light_gray_concrete
fill 371 126 230 371 233 230 minecraft:stone_bricks
setblock 371 126 258 minecraft:cobblestone
fill 330 127 270 330 280 270 minecraft:stone_bricks
fill 331 127 228 331 142 228 minecraft:stone_bricks
setblock 338 127 228 minecraft:mossy_cobblestone
fill 347 127 265 347 127 267 minecraft:light_gray_concrete
fill 348 127 230 348 127 232 minecraft:light_gray_concrete
fill 348 127 264 350 127 264 minecraft:light_gray_concrete
fill 348 127 268 350 127 268 minecraft:light_gray_concrete
fill 349 127 230 350 127 230 minecraft:light_gray_concrete
fill 349 127 232 350 127 232 minecraft:light_gray_concrete
setblock 350 127 231 minecraft:light_gray_concrete
fill 351 127 265 351 127 267 minecraft:light_gray_concrete
fill 371 127 258 371 237 258 minecraft:stone_bricks
setblock 329 128 244 minecraft:cobblestone
fill 338 128 228 338 150 228 minecraft:stone_bricks
setblock 357 128 228 minecraft:mossy_cobblestone
fill 358 128 228 358 141 228 minecraft:stone_bricks
setblock 365 128 228 minecraft:mossy_cobblestone
fill 329 129 244 329 280 244 minecraft:stone_bricks
setblock 330 129 230 minecraft:lime_concrete
setblock 332 129 231 minecraft:light[level=12]
setblock 332 129 238 minecraft:light[level=12]
setblock 332 129 245 minecraft:light[level=12]
setblock 332 129 252 minecraft:light[level=12]
setblock 332 129 259 minecraft:light[level=12]
setblock 332 129 266 minecraft:light[level=12]
setblock 339 129 231 minecraft:light[level=12]
setblock 339 129 238 minecraft:light[level=12]
setblock 339 129 245 minecraft:light[level=12]
setblock 339 129 252 minecraft:light[level=12]
setblock 339 129 259 minecraft:light[level=12]
setblock 339 129 266 minecraft:light[level=12]
setblock 346 129 231 minecraft:light[level=12]
setblock 346 129 238 minecraft:light[level=12]
setblock 346 129 245 minecraft:light[level=12]
setblock 346 129 252 minecraft:light[level=12]
setblock 346 129 259 minecraft:light[level=12]
setblock 346 129 266 minecraft:light[level=12]
setblock 353 129 231 minecraft:light[level=12]
setblock 353 129 238 minecraft:light[level=12]
setblock 353 129 245 minecraft:light[level=12]
setblock 353 129 252 minecraft:light[level=12]
setblock 353 129 259 minecraft:light[level=12]
setblock 353 129 266 minecraft:light[level=12]
setblock 355 129 269 minecraft:lime_terracotta
fill 357 129 228 357 175 228 minecraft:stone_bricks
setblock 360 129 231 minecraft:light[level=12]
setblock 360 129 238 minecraft:light[level=12]
setblock 360 129 245 minecraft:light[level=12]
setblock 360 129 252 minecraft:light[level=12]
setblock 360 129 259 minecraft:light[level=12]
setblock 360 129 266 minecraft:light[level=12]
fill 365 129 228 365 198 228 minecraft:stone_bricks
setblock 367 129 231 minecraft:light[level=12]
setblock 367 129 238 minecraft:light[level=12]
setblock 367 129 245 minecraft:light[level=12]
setblock 367 129 252 minecraft:light[level=12]
setblock 367 129 259 minecraft:light[level=12]
setblock 367 129 266 minecraft:light[level=12]
setblock 370 129 250 minecraft:lime_concrete
setblock 329 130 239 minecraft:cobblestone
setblock 329 130 259 minecraft:mossy_stone_bricks
setblock 334 130 228 minecraft:cobblestone
setblock 334 130 229 minecraft:green_concrete
fill 329 131 239 329 172 239 minecraft:stone_bricks
fill 329 131 259 329 237 259 minecraft:stone_bricks
fill 334 131 228 334 175 228 minecraft:stone_bricks
setblock 355 131 270 minecraft:cobblestone
setblock 332 132 231 minecraft:light[level=15]
setblock 332 132 239 minecraft:light[level=15]
setblock 332 132 247 minecraft:light[level=15]
setblock 332 132 255 minecraft:light[level=15]
setblock 332 132 263 minecraft:light[level=15]
setblock 340 132 231 minecraft:light[level=15]
setblock 340 132 239 minecraft:light[level=15]
setblock 340 132 247 minecraft:light[level=15]
setblock 340 132 255 minecraft:light[level=15]
setblock 340 132 263 minecraft:light[level=15]
setblock 344 132 228 minecraft:mossy_stone_bricks
setblock 344 132 229 minecraft:green_concrete
setblock 348 132 231 minecraft:light[level=15]
setblock 348 132 239 minecraft:light[level=15]
setblock 348 132 247 minecraft:light[level=15]
setblock 348 132 255 minecraft:light[level=15]
setblock 348 132 263 minecraft:light[level=15]
fill 355 132 270 355 197 270 minecraft:stone_bricks
setblock 356 132 231 minecraft:light[level=15]
setblock 356 132 239 minecraft:light[level=15]
setblock 356 132 247 minecraft:light[level=15]
setblock 356 132 255 minecraft:light[level=15]
setblock 356 132 263 minecraft:light[level=15]
setblock 364 132 231 minecraft:light[level=15]
setblock 364 132 239 minecraft:light[level=15]
setblock 364 132 247 minecraft:light[level=15]
setblock 364 132 255 minecraft:light[level=15]
setblock 364 132 263 minecraft:light[level=15]
fill 365 132 264 365 132 266 minecraft:light_gray_concrete
fill 366 132 264 367 132 264 minecraft:light_gray_concrete
fill 366 132 266 367 132 266 minecraft:light_gray_concrete
setblock 367 132 265 minecraft:light_gray_concrete
setblock 371 132 257 minecraft:mossy_stone_bricks
setblock 330 133 251 minecraft:lime_terracotta
fill 344 133 228 344 280 228 minecraft:stone_bricks
setblock 371 133 250 minecraft:mossy_stone_bricks
fill 371 133 251 371 280 251 minecraft:stone_bricks
fill 371 133 257 371 168 257 minecraft:stone_bricks
setblock 329 134 237 minecraft:mossy_cobblestone
fill 347 134 265 347 134 267 minecraft:light_gray_concrete
fill 348 134 230 348 134 232 minecraft:light_gray_concrete
fill 348 134 264 350 134 264 minecraft:light_gray_concrete
fill 348 134 268 350 134 268 minecraft:light_gray_concrete
fill 349 134 230 350 134 230 minecraft:light_gray_concrete
fill 349 134 232 350 134 232 minecraft:light_gray_concrete
setblock 349 134 270 minecraft:mossy_cobblestone
setblock 350 134 231 minecraft:light_gray_concrete
fill 351 134 265 351 134 267 minecraft:light_gray_concrete
setblock 354 134 228 minecraft:mossy_stone_bricks
setblock 354 134 229 minecraft:lime_terracotta
fill 371 134 250 371 141 250 minecraft:stone_bricks
fill 329 135 237 329 183 237 minecraft:stone_bricks
setblock 332 135 231 minecraft:light[level=12]
setblock 332 135 238 minecraft:light[level=12]
setblock 332 135 245 minecraft:light[level=12]
setblock 332 135 252 minecraft:light[level=12]
setblock 332 135 259 minecraft:light[level=12]
setblock 332 135 266 minecraft:light[level=12]
setblock 339 135 231 minecraft:light[level=12]
setblock 339 135 238 minecraft:light[level=12]
setblock 339 135 245 minecraft:light[level=12]
setblock 339 135 252 minecraft:light[level=12]
setblock 339 135 259 minecraft:light[level=12]
setblock 339 135 266 minecraft:light[level=12]
setblock 346 135 231 minecraft:light[level=12]
setblock 346 135 238 minecraft:light[level=12]
setblock 346 135 245 minecraft:light[level=12]
setblock 346 135 252 minecraft:light[level=12]
setblock 346 135 259 minecraft:light[level=12]
setblock 346 135 266 minecraft:light[level=12]
fill 349 135 270 349 280 270 minecraft:stone_bricks
setblock 353 135 231 minecraft:light[level=12]
setblock 353 135 238 minecraft:light[level=12]
setblock 353 135 245 minecraft:light[level=12]
setblock 353 135 252 minecraft:light[level=12]
setblock 353 135 259 minecraft:light[level=12]
setblock 353 135 266 minecraft:light[level=12]
fill 354 135 228 354 280 228 minecraft:stone_bricks
setblock 360 135 231 minecraft:light[level=12]
setblock 360 135 238 minecraft:light[level=12]
setblock 360 135 245 minecraft:light[level=12]
setblock 360 135 252 minecraft:light[level=12]
setblock 360 135 259 minecraft:light[level=12]
setblock 360 135 266 minecraft:light[level=12]
setblock 364 135 228 minecraft:mossy_cobblestone
setblock 367 135 231 minecraft:light[level=12]
setblock 367 135 238 minecraft:light[level=12]
setblock 367 135 245 minecraft:light[level=12]
setblock 367 135 252 minecraft:light[level=12]
setblock 367 135 259 minecraft:light[level=12]
setblock 367 135 266 minecraft:light[level=12]
setblock 370 135 267 minecraft:lime_concrete
setblock 329 136 261 minecraft:mossy_stone_bricks
setblock 349 136 229 minecraft:lime_terracotta
fill 364 136 228 364 197 228 minecraft:stone_bricks
fill 364 136 248 365 137 249 minecraft:light_blue_stained_glass
fill 366 136 249 366 137 249 minecraft:light_blue_stained_glass
setblock 370 136 260 minecraft:green_concrete
setblock 329 137 232 minecraft:mossy_cobblestone
fill 329 137 261 329 239 261 minecraft:stone_bricks
fill 329 138 232 329 167 232 minecraft:stone_bricks
fill 365 138 264 365 138 266 minecraft:light_gray_concrete
fill 366 138 264 367 138 264 minecraft:light_gray_concrete
fill 366 138 266 367 138 266 minecraft:light_gray_concrete
setblock 367 138 265 minecraft:light_gray_concrete
setblock 371 138 246 minecraft:mossy_stone_bricks
setblock 329 139 245 minecraft:cobblestone
fill 329 139 246 329 280 246 minecraft:stone_bricks
setblock 329 139 248 minecraft:mossy_cobblestone
fill 329 139 267 331 139 267 minecraft:waxed_cut_copper
setblock 332 139 231 minecraft:light[level=15]
setblock 332 139 239 minecraft:light[level=15]
setblock 332 139 247 minecraft:light[level=15]
setblock 332 139 255 minecraft:light[level=15]
setblock 332 139 263 minecraft:light[level=15]
fill 332 139 266 335 142 268 minecraft:gray_concrete
fill 336 139 267 338 139 267 minecraft:waxed_cut_copper
fill 339 139 266 342 142 268 minecraft:gray_concrete
setblock 340 139 231 minecraft:light[level=15]
setblock 340 139 239 minecraft:light[level=15]
setblock 340 139 247 minecraft:light[level=15]
setblock 340 139 255 minecraft:light[level=15]
setblock 340 139 263 minecraft:light[level=15]
fill 343 139 267 345 139 267 minecraft:waxed_cut_copper
fill 346 139 266 349 142 268 minecraft:gray_concrete
setblock 348 139 231 minecraft:light[level=15]
setblock 348 139 239 minecraft:light[level=15]
setblock 348 139 247 minecraft:light[level=15]
setblock 348 139 255 minecraft:light[level=15]
setblock 348 139 263 minecraft:light[level=15]
fill 350 139 267 352 139 267 minecraft:waxed_cut_copper
fill 353 139 266 356 142 268 minecraft:gray_concrete
setblock 356 139 231 minecraft:light[level=15]
setblock 356 139 239 minecraft:light[level=15]
setblock 356 139 247 minecraft:light[level=15]
setblock 356 139 255 minecraft:light[level=15]
setblock 356 139 263 minecraft:light[level=15]
fill 357 139 267 359 139 267 minecraft:waxed_cut_copper
fill 360 139 266 363 142 268 minecraft:gray_concrete
setblock 364 139 231 minecraft:light[level=15]
setblock 364 139 239 minecraft:light[level=15]
setblock 364 139 247 minecraft:light[level=15]
setblock 364 139 255 minecraft:light[level=15]
setblock 364 139 263 minecraft:light[level=15]
fill 364 139 267 370 139 267 minecraft:waxed_cut_copper
fill 371 139 246 371 148 246 minecraft:stone_bricks
fill 329 140 245 329 171 245 minecraft:stone_bricks
fill 329 140 248 329 208 248 minecraft:stone_bricks
fill 329 140 266 330 141 268 minecraft:waxed_cut_copper
fill 331 140 266 331 141 266 minecraft:waxed_cut_copper
fill 331 140 267 331 141 267 minecraft:gray_concrete
fill 331 140 268 331 141 268 minecraft:waxed_cut_copper
fill 333 140 265 334 141 265 minecraft:gray_concrete
fill 333 140 269 334 141 269 minecraft:gray_concrete
fill 336 140 266 338 141 266 minecraft:waxed_cut_copper
fill 336 140 267 336 141 267 minecraft:gray_concrete
fill 336 140 268 338 141 268 minecraft:waxed_cut_copper
fill 337 140 267 337 142 267 minecraft:waxed_cut_copper
fill 338 140 267 338 141 267 minecraft:gray_concrete
fill 340 140 265 341 141 265 minecraft:gray_concrete
fill 340 140 269 341 141 269 minecraft:gray_concrete
fill 343 140 266 345 141 266 minecraft:waxed_cut_copper
fill 343 140 267 343 141 267 minecraft:gray_concrete
fill 343 140 268 345 141 268 minecraft:waxed_cut_copper
fill 344 140 267 344 142 267 minecraft:waxed_cut_copper
fill 345 140 267 345 141 267 minecraft:gray_concrete
fill 347 140 265 348 141 265 minecraft:gray_concrete
fill 347 140 269 348 141 269 minecraft:gray_concrete
fill 349 140 265 349 192 265 minecraft:iron_block
fill 350 140 266 352 141 266 minecraft:waxed_cut_copper
fill 350 140 267 350 141 267 minecraft:gray_concrete
fill 350 140 268 352 141 268 minecraft:waxed_cut_copper
fill 351 140 267 351 142 267 minecraft:waxed_cut_copper
fill 352 140 267 352 141 267 minecraft:gray_concrete
fill 354 140 265 355 141 265 minecraft:gray_concrete
fill 354 140 269 355 141 269 minecraft:gray_concrete
fill 357 140 266 359 141 266 minecraft:waxed_cut_copper
fill 357 140 267 357 141 267 minecraft:gray_concrete
fill 357 140 268 359 141 268 minecraft:waxed_cut_copper
fill 358 140 267 358 142 267 minecraft:waxed_cut_copper
fill 359 140 267 359 141 267 minecraft:gray_concrete
fill 361 140 265 362 141 265 minecraft:gray_concrete
fill 361 140 269 362 141 269 minecraft:gray_concrete
fill 364 140 266 370 141 266 minecraft:waxed_cut_copper
fill 364 140 267 364 141 267 minecraft:gray_concrete
fill 364 140 268 370 141 268 minecraft:waxed_cut_copper
fill 365 140 267 371 141 267 minecraft:waxed_cut_copper
setblock 332 141 231 minecraft:light[level=12]
setblock 332 141 238 minecraft:light[level=12]
setblock 332 141 245 minecraft:light[level=12]
setblock 332 141 252 minecraft:light[level=12]
setblock 332 141 259 minecraft:light[level=12]
setblock 339 141 231 minecraft:light[level=12]
setblock 339 141 238 minecraft:light[level=12]
setblock 339 141 245 minecraft:light[level=12]
setblock 339 141 252 minecraft:light[level=12]
setblock 339 141 259 minecraft:light[level=12]
setblock 346 141 231 minecraft:light[level=12]
setblock 346 141 238 minecraft:light[level=12]
setblock 346 141 245 minecraft:light[level=12]
setblock 346 141 252 minecraft:light[level=12]
setblock 346 141 259 minecraft:light[level=12]
fill 348 141 230 348 141 232 minecraft:light_gray_concrete
fill 348 141 264 350 141 264 minecraft:light_gray_concrete
fill 349 141 230 350 141 230 minecraft:light_gray_concrete
fill 349 141 232 350 141 232 minecraft:light_gray_concrete
setblock 350 141 231 minecraft:light_gray_concrete
setblock 351 141 265 minecraft:light_gray_concrete
setblock 353 141 231 minecraft:light[level=12]
setblock 353 141 238 minecraft:light[level=12]
setblock 353 141 245 minecraft:light[level=12]
setblock 353 141 252 minecraft:light[level=12]
setblock 353 141 259 minecraft:light[level=12]
setblock 360 141 231 minecraft:light[level=12]
setblock 360 141 238 minecraft:light[level=12]
setblock 360 141 245 minecraft:light[level=12]
setblock 360 141 252 minecraft:light[level=12]
setblock 360 141 259 minecraft:light[level=12]
setblock 367 141 231 minecraft:light[level=12]
setblock 367 141 238 minecraft:light[level=12]
setblock 367 141 245 minecraft:light[level=12]
setblock 367 141 252 minecraft:light[level=12]
setblock 367 141 259 minecraft:light[level=12]
fill 329 142 266 329 280 266 minecraft:stone_bricks
fill 329 142 267 331 142 267 minecraft:waxed_cut_copper
setblock 329 142 268 minecraft:stone_bricks
setblock 336 142 267 minecraft:waxed_cut_copper
setblock 338 142 267 minecraft:waxed_cut_copper
setblock 343 142 267 minecraft:waxed_cut_copper
setblock 345 142 267 minecraft:waxed_cut_copper
fill 348 142 265 348 192 265 minecraft:iron_block
fill 350 142 266 350 192 266 minecraft:iron_block
setblock 350 142 267 minecraft:waxed_cut_copper
setblock 352 142 267 minecraft:waxed_cut_copper
setblock 357 142 267 minecraft:waxed_cut_copper
setblock 358 142 228 minecraft:cobblestone
setblock 359 142 267 minecraft:waxed_cut_copper
fill 364 142 267 370 142 267 minecraft:waxed_cut_copper
setblock 370 142 251 minecraft:green_concrete
setblock 371 142 250 minecraft:mossy_cobblestone
fill 371 142 267 371 280 267 minecraft:stone_bricks
fill 329 143 267 329 154 267 minecraft:stone_bricks
setblock 329 143 268 minecraft:mossy_stone_bricks
setblock 331 143 228 minecraft:mossy_cobblestone
setblock 337 143 270 minecraft:cobblestone
fill 348 143 266 349 192 267 minecraft:iron_block
fill 350 143 267 350 192 267 minecraft:iron_block
setblock 352 143 229 minecraft:lime_concrete
fill 358 143 228 358 246 228 minecraft:stone_bricks
setblock 359 143 270 minecraft:cobblestone
fill 366 143 266 366 144 268 minecraft:iron_block
setblock 370 143 233 minecraft:lime_terracotta
fill 371 143 243 371 186 244 minecraft:stone_bricks
setblock 371 143 245 minecraft:mossy_stone_bricks
fill 371 143 250 371 198 250 minecraft:stone_bricks
fill 329 144 268 329 168 268 minecraft:stone_bricks
fill 331 144 228 331 235 228 minecraft:stone_bricks
fill 337 144 270 337 280 270 minecraft:stone_bricks
setblock 342 144 269 minecraft:lime_terracotta
fill 359 144 270 359 280 270 minecraft:stone_bricks
fill 365 144 264 365 144 266 minecraft:light_gray_concrete
setblock 366 144 264 minecraft:sea_lantern
fill 367 144 264 367 144 266 minecraft:light_gray_concrete
fill 371 144 245 371 164 245 minecraft:stone_bricks
fill 329 145 234 329 280 235 minecraft:stone_bricks
setblock 329 145 236 minecraft:mossy_cobblestone
setblock 362 145 270 minecraft:mossy_cobblestone
fill 366 145 228 366 155 228 minecraft:stone_bricks
setblock 367 145 228 minecraft:cobblestone
fill 368 145 228 368 197 228 minecraft:stone_bricks
setblock 371 145 240 minecraft:mossy_stone_bricks
fill 329 146 236 329 170 236 minecraft:stone_bricks
setblock 329 146 252 minecraft:cobblestone
setblock 332 146 231 minecraft:light[level=15]
setblock 332 146 239 minecraft:light[level=15]
setblock 332 146 247 minecraft:light[level=15]
setblock 332 146 255 minecraft:light[level=15]
setblock 332 146 263 minecraft:light[level=15]
setblock 340 146 231 minecraft:light[level=15]
setblock 340 146 239 minecraft:light[level=15]
setblock 340 146 247 minecraft:light[level=15]
setblock 340 146 255 minecraft:light[level=15]
setblock 340 146 263 minecraft:light[level=15]
setblock 348 146 231 minecraft:light[level=15]
setblock 348 146 239 minecraft:light[level=15]
setblock 348 146 247 minecraft:light[level=15]
setblock 348 146 255 minecraft:light[level=15]
setblock 348 146 263 minecraft:light[level=15]
setblock 356 146 231 minecraft:light[level=15]
setblock 356 146 239 minecraft:light[level=15]
setblock 356 146 247 minecraft:light[level=15]
setblock 356 146 255 minecraft:light[level=15]
setblock 356 146 263 minecraft:light[level=15]
fill 362 146 270 362 199 270 minecraft:stone_bricks
setblock 364 146 231 minecraft:light[level=15]
setblock 364 146 239 minecraft:light[level=15]
setblock 364 146 247 minecraft:light[level=15]
setblock 364 146 255 minecraft:light[level=15]
setblock 364 146 263 minecraft:light[level=15]
fill 367 146 228 367 176 228 minecraft:stone_bricks
setblock 367 146 269 minecraft:lime_terracotta
fill 371 146 240 371 164 240 minecraft:stone_bricks
setblock 329 147 242 minecraft:mossy_cobblestone
fill 329 147 252 329 234 252 minecraft:stone_bricks
setblock 330 147 245 minecraft:lime_concrete
setblock 332 147 231 minecraft:light[level=12]
setblock 332 147 238 minecraft:light[level=12]
setblock 332 147 245 minecraft:light[level=12]
setblock 332 147 252 minecraft:light[level=12]
setblock 332 147 259 minecraft:light[level=12]
setblock 332 147 266 minecraft:light[level=12]
setblock 333 147 228 minecraft:cobblestone
setblock 339 147 231 minecraft:light[level=12]
setblock 339 147 238 minecraft:light[level=12]
setblock 339 147 245 minecraft:light[level=12]
setblock 339 147 252 minecraft:light[level=12]
setblock 339 147 259 minecraft:light[level=12]
setblock 339 147 266 minecraft:light[level=12]
setblock 346 147 231 minecraft:light[level=12]
setblock 346 147 238 minecraft:light[level=12]
setblock 346 147 245 minecraft:light[level=12]
setblock 346 147 252 minecraft:light[level=12]
setblock 346 147 259 minecraft:light[level=12]
setblock 346 147 266 minecraft:light[level=12]
setblock 353 147 231 minecraft:light[level=12]
setblock 353 147 238 minecraft:light[level=12]
setblock 353 147 245 minecraft:light[level=12]
setblock 353 147 252 minecraft:light[level=12]
setblock 353 147 259 minecraft:light[level=12]
setblock 353 147 266 minecraft:light[level=12]
setblock 360 147 229 minecraft:lime_concrete
setblock 360 147 231 minecraft:light[level=12]
setblock 360 147 238 minecraft:light[level=12]
setblock 360 147 245 minecraft:light[level=12]
setblock 360 147 252 minecraft:light[level=12]
setblock 360 147 259 minecraft:light[level=12]
setblock 360 147 266 minecraft:light[level=12]
setblock 360 147 270 minecraft:mossy_cobblestone
setblock 367 147 231 minecraft:light[level=12]
setblock 367 147 238 minecraft:light[level=12]
setblock 367 147 245 minecraft:light[level=12]
setblock 367 147 252 minecraft:light[level=12]
setblock 367 147 259 minecraft:light[level=12]
setblock 367 147 266 minecraft:light[level=12]
setblock 370 147 263 minecraft:green_concrete
fill 329 148 242 329 201 242 minecraft:stone_bricks
setblock 329 148 269 minecraft:mossy_cobblestone
fill 329 148 270 329 280 270 minecraft:stone_bricks
fill 333 148 228 333 280 228 minecraft:stone_bricks
fill 347 148 265 347 148 267 minecraft:light_gray_concrete
fill 348 148 230 348 148 232 minecraft:light_gray_concrete
fill 348 148 264 350 148 264 minecraft:light_gray_concrete
fill 348 148 268 350 148 268 minecraft:light_gray_concrete
fill 349 148 230 350 148 230 minecraft:light_gray_concrete
fill 349 148 232 350 148 232 minecraft:light_gray_concrete
setblock 350 148 231 minecraft:light_gray_concrete
fill 351 148 265 351 148 267 minecraft:light_gray_concrete
fill 360 148 270 360 223 270 minecraft:stone_bricks
fill 329 149 269 329 280 269 minecraft:stone_bricks
fill 332 149 251 332 150 251 minecraft:light_blue_stained_glass
setblock 336 149 270 minecraft:mossy_stone_bricks
setblock 341 149 270 minecraft:mossy_stone_bricks
setblock 345 149 228 minecraft:mossy_stone_bricks
setblock 371 149 246 minecraft:cobblestone
setblock 330 150 259 minecraft:lime_terracotta
fill 336 150 270 336 179 270 minecraft:stone_bricks
fill 341 150 270 341 280 270 minecraft:stone_bricks
fill 345 150 228 345 236 228 minecraft:stone_bricks
fill 365 150 264 365 150 266 minecraft:light_gray_concrete
fill 366 150 264 367 150 264 minecraft:light_gray_concrete
fill 366 150 266 367 150 266 minecraft:light_gray_concrete
setblock 367 150 265 minecraft:light_gray_concrete
setblock 370 150 255 minecraft:green_concrete
fill 371 150 246 371 204 246 minecraft:stone_bricks
setblock 338 151 228 minecraft:mossy_cobblestone
setblock 350 151 270 minecraft:mossy_stone_bricks
setblock 352 151 228 minecraft:cobblestone
setblock 352 151 229 minecraft:lime_concrete
setblock 371 151 266 minecraft:mossy_cobblestone
fill 338 152 228 338 280 228 minecraft:stone_bricks
fill 350 152 270 350 213 270 minecraft:stone_bricks
fill 352 152 228 352 189 228 minecraft:stone_bricks
fill 371 152 266 371 177 266 minecraft:stone_bricks
setblock 330 153 234 minecraft:lime_concrete
setblock 332 153 231 minecraft:light[level=15]
setblock 332 153 238 minecraft:light[level=12]
setblock 332 153 239 minecraft:light[level=15]
setblock 332 153 245 minecraft:light[level=12]
setblock 332 153 247 minecraft:light[level=15]
setblock 332 153 252 minecraft:light[level=12]
setblock 332 153 255 minecraft:light[level=15]
setblock 332 153 259 minecraft:light[level=12]
setblock 332 153 263 minecraft:light[level=15]
setblock 332 153 266 minecraft:light[level=12]
setblock 339 153 231 minecraft:light[level=12]
setblock 339 153 238 minecraft:light[level=12]
setblock 339 153 245 minecraft:light[level=12]
setblock 339 153 252 minecraft:light[level=12]
setblock 339 153 259 minecraft:light[level=12]
setblock 339 153 266 minecraft:light[level=12]
setblock 340 153 231 minecraft:light[level=15]
setblock 340 153 239 minecraft:light[level=15]
setblock 340 153 247 minecraft:light[level=15]
setblock 340 153 255 minecraft:light[level=15]
setblock 340 153 263 minecraft:light[level=15]
setblock 346 153 231 minecraft:light[level=12]
setblock 346 153 238 minecraft:light[level=12]
setblock 346 153 245 minecraft:light[level=12]
setblock 346 153 252 minecraft:light[level=12]
setblock 346 153 259 minecraft:light[level=12]
setblock 346 153 266 minecraft:light[level=12]
setblock 348 153 231 minecraft:light[level=15]
setblock 348 153 239 minecraft:light[level=15]
setblock 348 153 247 minecraft:light[level=15]
setblock 348 153 255 minecraft:light[level=15]
setblock 348 153 263 minecraft:light[level=15]
setblock 353 153 228 minecraft:cobblestone
setblock 353 153 231 minecraft:light[level=12]
setblock 353 153 238 minecraft:light[level=12]
setblock 353 153 245 minecraft:light[level=12]
setblock 353 153 259 minecraft:light[level=12]
setblock 353 153 266 minecraft:light[level=12]
setblock 356 153 231 minecraft:light[level=15]
setblock 356 153 239 minecraft:light[level=15]
setblock 356 153 247 minecraft:light[level=15]
setblock 356 153 255 minecraft:light[level=15]
setblock 356 153 263 minecraft:light[level=15]
setblock 360 153 231 minecraft:light[level=12]
setblock 360 153 238 minecraft:light[level=12]
setblock 360 153 245 minecraft:light[level=12]
setblock 360 153 252 minecraft:light[level=12]
setblock 360 153 259 minecraft:light[level=12]
setblock 360 153 266 minecraft:light[level=12]
setblock 364 153 231 minecraft:light[level=15]
setblock 364 153 239 minecraft:light[level=15]
setblock 364 153 247 minecraft:light[level=15]
setblock 364 153 255 minecraft:light[level=15]
setblock 364 153 263 minecraft:light[level=15]
setblock 367 153 231 minecraft:light[level=12]
setblock 367 153 238 minecraft:light[level=12]
setblock 367 153 245 minecraft:light[level=12]
setblock 367 153 252 minecraft:light[level=12]
setblock 367 153 259 minecraft:light[level=12]
setblock 367 153 266 minecraft:light[level=12]
setblock 334 154 270 minecraft:mossy_cobblestone
fill 353 154 228 353 215 228 minecraft:stone_bricks
setblock 371 154 233 minecraft:cobblestone
setblock 329 155 267 minecraft:mossy_cobblestone
fill 334 155 270 334 280 270 minecraft:stone_bricks
fill 347 155 265 347 155 267 minecraft:light_gray_concrete
fill 348 155 230 348 155 232 minecraft:light_gray_concrete
fill 348 155 264 350 155 264 minecraft:light_gray_concrete
fill 348 155 268 350 155 268 minecraft:light_gray_concrete
fill 349 155 230 350 155 230 minecraft:light_gray_concrete
fill 349 155 232 350 155 232 minecraft:light_gray_concrete
setblock 350 155 231 minecraft:light_gray_concrete
fill 351 155 265 351 155 267 minecraft:light_gray_concrete
fill 371 155 233 371 194 233 minecraft:stone_bricks
fill 329 156 267 329 157 267 minecraft:stone_bricks
fill 365 156 264 365 156 266 minecraft:light_gray_concrete
setblock 366 156 228 minecraft:cobblestone
fill 366 156 264 367 156 264 minecraft:light_gray_concrete
fill 366 156 266 367 156 266 minecraft:light_gray_concrete
setblock 367 156 265 minecraft:light_gray_concrete
setblock 370 156 261 minecraft:green_concrete
fill 339 157 262 340 158 263 minecraft:light_blue_stained_glass
fill 341 157 262 341 158 262 minecraft:light_blue_stained_glass
setblock 348 157 270 minecraft:mossy_stone_bricks
setblock 360 157 228 minecraft:cobblestone
fill 366 157 228 366 197 228 minecraft:stone_bricks
setblock 329 158 267 minecraft:mossy_cobblestone
fill 348 158 270 348 243 270 minecraft:stone_bricks
fill 351 158 270 351 170 270 minecraft:stone_bricks
setblock 352 158 270 minecraft:mossy_stone_bricks
fill 360 158 228 360 280 228 minecraft:stone_bricks
setblock 366 158 269 minecraft:lime_terracotta
fill 329 159 267 329 175 267 minecraft:stone_bricks
setblock 330 159 239 minecraft:lime_terracotta
setblock 332 159 231 minecraft:light[level=12]
setblock 332 159 238 minecraft:light[level=12]
setblock 332 159 245 minecraft:light[level=12]
setblock 332 159 252 minecraft:light[level=12]
setblock 332 159 259 minecraft:light[level=12]
setblock 332 159 266 minecraft:light[level=12]
setblock 339 159 231 minecraft:light[level=12]
setblock 339 159 238 minecraft:light[level=12]
setblock 339 159 245 minecraft:light[level=12]
setblock 339 159 252 minecraft:light[level=12]
setblock 339 159 259 minecraft:light[level=12]
setblock 339 159 266 minecraft:light[level=12]
setblock 346 159 231 minecraft:light[level=12]
setblock 346 159 238 minecraft:light[level=12]
setblock 346 159 245 minecraft:light[level=12]
setblock 346 159 252 minecraft:light[level=12]
setblock 346 159 259 minecraft:light[level=12]
setblock 346 159 266 minecraft:light[level=12]
fill 352 159 270 352 248 270 minecraft:stone_bricks
setblock 353 159 231 minecraft:light[level=12]
setblock 353 159 238 minecraft:light[level=12]
setblock 353 159 245 minecraft:light[level=12]
setblock 353 159 259 minecraft:light[level=12]
setblock 353 159 266 minecraft:light[level=12]
setblock 360 159 231 minecraft:light[level=12]
setblock 360 159 238 minecraft:light[level=12]
setblock 360 159 245 minecraft:light[level=12]
setblock 360 159 252 minecraft:light[level=12]
setblock 360 159 259 minecraft:light[level=12]
setblock 360 159 266 minecraft:light[level=12]
setblock 367 159 231 minecraft:light[level=12]
setblock 367 159 238 minecraft:light[level=12]
setblock 367 159 245 minecraft:light[level=12]
setblock 367 159 252 minecraft:light[level=12]
setblock 367 159 259 minecraft:light[level=12]
setblock 367 159 266 minecraft:light[level=12]
setblock 332 160 231 minecraft:light[level=15]
setblock 332 160 239 minecraft:light[level=15]
setblock 332 160 247 minecraft:light[level=15]
setblock 332 160 255 minecraft:light[level=15]
setblock 332 160 263 minecraft:light[level=15]
setblock 338 160 269 minecraft:green_concrete
setblock 340 160 231 minecraft:light[level=15]
setblock 340 160 239 minecraft:light[level=15]
setblock 340 160 247 minecraft:light[level=15]
setblock 340 160 255 minecraft:light[level=15]
setblock 340 160 263 minecraft:light[level=15]
setblock 348 160 231 minecraft:light[level=15]
setblock 348 160 239 minecraft:light[level=15]
setblock 348 160 247 minecraft:light[level=15]
setblock 348 160 255 minecraft:light[level=15]
setblock 348 160 263 minecraft:light[level=15]
setblock 356 160 231 minecraft:light[level=15]
setblock 356 160 239 minecraft:light[level=15]
setblock 356 160 247 minecraft:light[level=15]
setblock 356 160 255 minecraft:light[level=15]
setblock 356 160 263 minecraft:light[level=15]
setblock 364 160 231 minecraft:light[level=15]
setblock 364 160 239 minecraft:light[level=15]
setblock 364 160 247 minecraft:light[level=15]
setblock 364 160 255 minecraft:light[level=15]
setblock 364 160 263 minecraft:light[level=15]
fill 337 161 247 339 162 247 minecraft:light_blue_stained_glass
fill 338 161 246 338 162 246 minecraft:light_blue_stained_glass
fill 338 161 248 338 162 248 minecraft:light_blue_stained_glass
fill 339 161 251 340 162 252 minecraft:white_stained_glass
setblock 356 161 228 minecraft:mossy_cobblestone
setblock 330 162 264 minecraft:green_concrete
fill 347 162 265 347 162 267 minecraft:light_gray_concrete
fill 348 162 230 348 162 232 minecraft:light_gray_concrete
fill 348 162 264 350 162 264 minecraft:light_gray_concrete
fill 348 162 268 350 162 268 minecraft:light_gray_concrete
fill 349 162 230 350 162 230 minecraft:light_gray_concrete
fill 349 162 232 350 162 232 minecraft:light_gray_concrete
setblock 350 162 231 minecraft:light_gray_concrete
fill 351 162 265 351 162 267 minecraft:light_gray_concrete
fill 356 162 228 356 203 228 minecraft:stone_bricks
fill 357 162 242 358 163 243 minecraft:white_stained_glass
fill 365 162 264 365 162 266 minecraft:light_gray_concrete
fill 366 162 264 367 162 264 minecraft:light_gray_concrete
fill 366 162 266 367 162 266 minecraft:light_gray_concrete
setblock 367 162 265 minecraft:light_gray_concrete
setblock 371 162 234 minecraft:cobblestone
fill 371 163 234 371 195 234 minecraft:stone_bricks
setblock 371 163 256 minecraft:mossy_cobblestone
fill 356 164 262 358 165 263 minecraft:white_stained_glass
setblock 370 164 255 minecraft:lime_terracotta
setblock 371 164 256 minecraft:cobblestone
setblock 371 164 268 minecraft:mossy_stone_bricks
setblock 332 165 231 minecraft:light[level=12]
setblock 332 165 238 minecraft:light[level=12]
setblock 332 165 245 minecraft:light[level=12]
setblock 332 165 252 minecraft:light[level=12]
setblock 332 165 259 minecraft:light[level=12]
setblock 332 165 266 minecraft:light[level=12]
setblock 339 165 231 minecraft:light[level=12]
setblock 339 165 238 minecraft:light[level=12]
setblock 339 165 245 minecraft:light[level=12]
setblock 339 165 252 minecraft:light[level=12]
setblock 339 165 259 minecraft:light[level=12]
setblock 339 165 266 minecraft:light[level=12]
setblock 346 165 231 minecraft:light[level=12]
setblock 346 165 238 minecraft:light[level=12]
setblock 346 165 245 minecraft:light[level=12]
setblock 346 165 252 minecraft:light[level=12]
setblock 346 165 259 minecraft:light[level=12]
setblock 346 165 266 minecraft:light[level=12]
setblock 353 165 231 minecraft:light[level=12]
setblock 353 165 238 minecraft:light[level=12]
setblock 353 165 245 minecraft:light[level=12]
setblock 353 165 259 minecraft:light[level=12]
setblock 353 165 266 minecraft:light[level=12]
setblock 360 165 231 minecraft:light[level=12]
setblock 360 165 238 minecraft:light[level=12]
setblock 360 165 245 minecraft:light[level=12]
setblock 360 165 252 minecraft:light[level=12]
setblock 360 165 259 minecraft:light[level=12]
setblock 360 165 266 minecraft:light[level=12]
setblock 367 165 231 minecraft:light[level=12]
setblock 367 165 238 minecraft:light[level=12]
setblock 367 165 245 minecraft:light[level=12]
setblock 367 165 252 minecraft:light[level=12]
setblock 367 165 259 minecraft:light[level=12]
setblock 367 165 266 minecraft:light[level=12]
setblock 371 165 240 minecraft:cobblestone
setblock 371 165 245 minecraft:mossy_stone_bricks
fill 371 165 256 371 187 256 minecraft:stone_bricks
fill 371 165 268 371 231 268 minecraft:stone_bricks
setblock 361 166 229 minecraft:lime_terracotta
setblock 366 166 229 minecraft:lime_terracotta
fill 371 166 240 371 172 240 minecraft:stone_bricks
fill 371 166 245 371 192 245 minecraft:stone_bricks
setblock 332 167 231 minecraft:light[level=15]
setblock 332 167 239 minecraft:light[level=15]
setblock 332 167 247 minecraft:light[level=15]
setblock 332 167 255 minecraft:light[level=15]
setblock 332 167 263 minecraft:light[level=15]
setblock 340 167 231 minecraft:light[level=15]
setblock 340 167 239 minecraft:light[level=15]
setblock 340 167 247 minecraft:light[level=15]
setblock 340 167 255 minecraft:light[level=15]
setblock 340 167 263 minecraft:light[level=15]
setblock 348 167 231 minecraft:light[level=15]
setblock 348 167 239 minecraft:light[level=15]
setblock 348 167 247 minecraft:light[level=15]
setblock 348 167 255 minecraft:light[level=15]
setblock 348 167 263 minecraft:light[level=15]
setblock 356 167 231 minecraft:light[level=15]
setblock 356 167 239 minecraft:light[level=15]
setblock 356 167 247 minecraft:light[level=15]
setblock 356 167 255 minecraft:light[level=15]
setblock 356 167 263 minecraft:light[level=15]
setblock 364 167 231 minecraft:light[level=15]
setblock 364 167 239 minecraft:light[level=15]
setblock 364 167 247 minecraft:light[level=15]
setblock 364 167 255 minecraft:light[level=15]
setblock 364 167 263 minecraft:light[level=15]
setblock 329 168 232 minecraft:mossy_cobblestone
setblock 348 168 228 minecraft:mossy_cobblestone
fill 365 168 264 365 168 266 minecraft:light_gray_concrete
fill 366 168 264 367 168 264 minecraft:light_gray_concrete
fill 366 168 266 367 168 266 minecraft:light_gray_concrete
setblock 367 168 265 minecraft:light_gray_concrete
setblock 371 168 229 minecraft:cobblestone
setblock 371 168 232 minecraft:mossy_cobblestone
fill 329 169 232 329 177 232 minecraft:stone_bricks
setblock 329 169 268 minecraft:mossy_stone_bricks
fill 347 169 265 347 169 267 minecraft:light_gray_concrete
fill 348 169 228 348 214 228 minecraft:stone_bricks
fill 348 169 230 348 169 232 minecraft:light_gray_concrete
fill 348 169 264 350 169 264 minecraft:light_gray_concrete
fill 348 169 268 350 169 268 minecraft:light_gray_concrete
fill 349 169 230 350 169 230 minecraft:light_gray_concrete
fill 349 169 232 350 169 232 minecraft:light_gray_concrete
setblock 350 169 231 minecraft:light_gray_concrete
fill 351 169 265 351 169 267 minecraft:light_gray_concrete
fill 371 169 229 371 176 229 minecraft:stone_bricks
fill 371 169 232 371 204 232 minecraft:stone_bricks
setblock 371 169 257 minecraft:mossy_stone_bricks
fill 329 170 268 329 267 268 minecraft:stone_bricks
setblock 333 170 270 minecraft:cobblestone
setblock 340 170 228 minecraft:mossy_cobblestone
fill 371 170 257 371 280 257 minecraft:stone_bricks
setblock 329 171 236 minecraft:mossy_stone_bricks
setblock 332 171 231 minecraft:light[level=12]
setblock 332 171 238 minecraft:light[level=12]
setblock 332 171 245 minecraft:light[level=12]
setblock 332 171 252 minecraft:light[level=12]
setblock 332 171 259 minecraft:light[level=12]
setblock 332 171 266 minecraft:light[level=12]
fill 333 171 270 333 173 270 minecraft:stone_bricks
setblock 339 171 231 minecraft:light[level=12]
setblock 339 171 238 minecraft:light[level=12]
setblock 339 171 245 minecraft:light[level=12]
setblock 339 171 252 minecraft:light[level=12]
setblock 339 171 259 minecraft:light[level=12]
setblock 339 171 266 minecraft:light[level=12]
fill 340 171 228 340 280 228 minecraft:stone_bricks
setblock 346 171 231 minecraft:light[level=12]
setblock 346 171 238 minecraft:light[level=12]
setblock 346 171 245 minecraft:light[level=12]
setblock 346 171 252 minecraft:light[level=12]
setblock 346 171 259 minecraft:light[level=12]
setblock 346 171 266 minecraft:light[level=12]
setblock 347 171 270 minecraft:cobblestone
fill 350 171 239 351 172 239 minecraft:white_stained_glass
setblock 351 171 270 minecraft:mossy_cobblestone
setblock 353 171 231 minecraft:light[level=12]
setblock 353 171 238 minecraft:light[level=12]
setblock 353 171 245 minecraft:light[level=12]
setblock 353 171 259 minecraft:light[level=12]
setblock 353 171 266 minecraft:light[level=12]
setblock 360 171 231 minecraft:light[level=12]
setblock 360 171 238 minecraft:light[level=12]
setblock 360 171 245 minecraft:light[level=12]
setblock 360 171 252 minecraft:light[level=12]
setblock 360 171 259 minecraft:light[level=12]
setblock 360 171 266 minecraft:light[level=12]
setblock 367 171 231 minecraft:light[level=12]
setblock 367 171 238 minecraft:light[level=12]
setblock 367 171 245 minecraft:light[level=12]
setblock 367 171 252 minecraft:light[level=12]
setblock 367 171 259 minecraft:light[level=12]
setblock 367 171 266 minecraft:light[level=12]
setblock 370 171 249 minecraft:green_concrete
fill 329 172 236 329 271 236 minecraft:stone_bricks
setblock 329 172 245 minecraft:mossy_cobblestone
fill 347 172 270 347 180 270 minecraft:stone_bricks
fill 351 172 270 351 215 270 minecraft:stone_bricks
setblock 329 173 239 minecraft:mossy_cobblestone
fill 329 173 245 329 280 245 minecraft:stone_bricks
fill 366 173 270 367 187 270 minecraft:stone_bricks
setblock 368 173 270 minecraft:cobblestone
setblock 371 173 240 minecraft:cobblestone
setblock 329 174 238 minecraft:mossy_stone_bricks
fill 329 174 239 329 280 239 minecraft:stone_bricks
setblock 329 174 250 minecraft:mossy_cobblestone
setblock 332 174 231 minecraft:light[level=15]
setblock 332 174 239 minecraft:light[level=15]
setblock 332 174 247 minecraft:light[level=15]
setblock 332 174 255 minecraft:light[level=15]
setblock 332 174 263 minecraft:light[level=15]
setblock 333 174 270 minecraft:mossy_stone_bricks
setblock 340 174 231 minecraft:light[level=15]
setblock 340 174 239 minecraft:light[level=15]
setblock 340 174 247 minecraft:light[level=15]
setblock 340 174 255 minecraft:light[level=15]
setblock 340 174 263 minecraft:light[level=15]
setblock 348 174 231 minecraft:light[level=15]
setblock 348 174 239 minecraft:light[level=15]
setblock 348 174 247 minecraft:light[level=15]
setblock 348 174 255 minecraft:light[level=15]
setblock 348 174 263 minecraft:light[level=15]
setblock 356 174 231 minecraft:light[level=15]
setblock 356 174 239 minecraft:light[level=15]
setblock 356 174 247 minecraft:light[level=15]
setblock 356 174 255 minecraft:light[level=15]
setblock 356 174 263 minecraft:light[level=15]
setblock 364 174 231 minecraft:light[level=15]
setblock 364 174 239 minecraft:light[level=15]
setblock 364 174 247 minecraft:light[level=15]
setblock 364 174 255 minecraft:light[level=15]
setblock 364 174 263 minecraft:light[level=15]
fill 365 174 264 365 174 266 minecraft:light_gray_concrete
fill 366 174 264 367 174 264 minecraft:light_gray_concrete
fill 366 174 266 367 174 266 minecraft:light_gray_concrete
setblock 367 174 265 minecraft:light_gray_concrete
fill 368 174 270 368 203 270 minecraft:stone_bricks
fill 371 174 240 371 193 240 minecraft:stone_bricks
fill 371 174 261 371 204 261 minecraft:stone_bricks
setblock 371 174 262 minecraft:mossy_cobblestone
fill 329 175 238 329 189 238 minecraft:stone_bricks
setblock 329 175 249 minecraft:mossy_cobblestone
fill 329 175 250 329 280 250 minecraft:stone_bricks
setblock 329 175 255 minecraft:mossy_stone_bricks
setblock 332 175 270 minecraft:mossy_stone_bricks
fill 333 175 270 333 210 270 minecraft:stone_bricks
setblock 340 175 270 minecraft:mossy_stone_bricks
fill 371 175 262 371 280 262 minecraft:stone_bricks
fill 329 176 249 329 195 249 minecraft:stone_bricks
fill 329 176 255 329 249 255 minecraft:stone_bricks
setblock 329 176 267 minecraft:mossy_cobblestone
fill 332 176 270 332 213 270 minecraft:stone_bricks
setblock 334 176 228 minecraft:mossy_cobblestone
setblock 340 176 270 minecraft:cobblestone
fill 347 176 265 347 176 267 minecraft:light_gray_concrete
fill 348 176 230 348 176 232 minecraft:light_gray_concrete
fill 348 176 264 350 176 264 minecraft:light_gray_concrete
fill 348 176 268 350 176 268 minecraft:light_gray_concrete
fill 349 176 230 350 176 230 minecraft:light_gray_concrete
fill 349 176 232 350 176 232 minecraft:light_gray_concrete
setblock 350 176 231 minecraft:light_gray_concrete
fill 351 176 265 351 176 267 minecraft:light_gray_concrete
setblock 357 176 228 minecraft:mossy_stone_bricks
fill 364 176 237 364 177 237 minecraft:white_stained_glass
fill 329 177 267 329 253 267 minecraft:stone_bricks
setblock 332 177 231 minecraft:light[level=12]
setblock 332 177 238 minecraft:light[level=12]
setblock 332 177 245 minecraft:light[level=12]
setblock 332 177 252 minecraft:light[level=12]
setblock 332 177 259 minecraft:light[level=12]
setblock 332 177 266 minecraft:light[level=12]
fill 334 177 228 334 258 228 minecraft:stone_bricks
setblock 339 177 231 minecraft:light[level=12]
setblock 339 177 238 minecraft:light[level=12]
setblock 339 177 245 minecraft:light[level=12]
setblock 339 177 252 minecraft:light[level=12]
setblock 339 177 259 minecraft:light[level=12]
setblock 339 177 266 minecraft:light[level=12]
fill 340 177 270 340 178 270 minecraft:stone_bricks
setblock 346 177 231 minecraft:light[level=12]
setblock 346 177 238 minecraft:light[level=12]
setblock 346 177 245 minecraft:light[level=12]
setblock 346 177 252 minecraft:light[level=12]
setblock 346 177 259 minecraft:light[level=12]
setblock 346 177 266 minecraft:light[level=12]
setblock 353 177 231 minecraft:light[level=12]
setblock 353 177 238 minecraft:light[level=12]
setblock 353 177 245 minecraft:light[level=12]
setblock 353 177 259 minecraft:light[level=12]
setblock 353 177 266 minecraft:light[level=12]
fill 357 177 228 357 182 228 minecraft:stone_bricks
setblock 360 177 231 minecraft:light[level=12]
setblock 360 177 238 minecraft:light[level=12]
setblock 360 177 245 minecraft:light[level=12]
setblock 360 177 252 minecraft:light[level=12]
setblock 360 177 259 minecraft:light[level=12]
setblock 360 177 266 minecraft:light[level=12]
setblock 367 177 228 minecraft:mossy_cobblestone
setblock 367 177 231 minecraft:light[level=12]
setblock 367 177 238 minecraft:light[level=12]
setblock 367 177 245 minecraft:light[level=12]
setblock 367 177 252 minecraft:light[level=12]
setblock 367 177 259 minecraft:light[level=12]
setblock 367 177 266 minecraft:light[level=12]
setblock 371 177 229 minecraft:mossy_cobblestone
setblock 329 178 232 minecraft:cobblestone
setblock 330 178 228 minecraft:cobblestone
fill 367 178 228 367 196 228 minecraft:stone_bricks
fill 371 178 229 371 198 229 minecraft:stone_bricks
setblock 371 178 242 minecraft:cobblestone
setblock 371 178 266 minecraft:cobblestone
fill 329 179 232 329 233 232 minecraft:stone_bricks
fill 330 179 228 330 180 228 minecraft:stone_bricks
setblock 330 179 236 minecraft:lime_concrete
setblock 340 179 270 minecraft:mossy_cobblestone
setblock 343 179 270 minecraft:mossy_cobblestone
fill 344 179 270 344 242 270 minecraft:stone_bricks
setblock 370 179 261 minecraft:lime_terracotta
fill 371 179 242 371 237 242 minecraft:stone_bricks
fill 371 179 266 371 197 266 minecraft:stone_bricks
setblock 336 180 270 minecraft:mossy_cobblestone
fill 340 180 270 340 280 270 minecraft:stone_bricks
fill 343 180 270 343 224 270 minecraft:stone_bricks
fill 365 180 264 365 180 266 minecraft:light_gray_concrete
fill 366 180 264 367 180 264 minecraft:light_gray_concrete
fill 366 180 266 367 180 266 minecraft:light_gray_concrete
setblock 367 180 265 minecraft:light_gray_concrete
setblock 330 181 228 minecraft:mossy_stone_bricks
setblock 332 181 231 minecraft:light[level=15]
setblock 332 181 239 minecraft:light[level=15]
setblock 332 181 247 minecraft:light[level=15]
setblock 332 181 255 minecraft:light[level=15]
setblock 332 181 263 minecraft:light[level=15]
fill 336 181 270 336 280 270 minecraft:stone_bricks
setblock 340 181 231 minecraft:light[level=15]
setblock 340 181 239 minecraft:light[level=15]
setblock 340 181 247 minecraft:light[level=15]
setblock 340 181 255 minecraft:light[level=15]
setblock 340 181 263 minecraft:light[level=15]
setblock 347 181 270 minecraft:mossy_stone_bricks
setblock 348 181 231 minecraft:light[level=15]
setblock 348 181 239 minecraft:light[level=15]
setblock 348 181 247 minecraft:light[level=15]
setblock 348 181 255 minecraft:light[level=15]
setblock 348 181 263 minecraft:light[level=15]
setblock 356 181 231 minecraft:light[level=15]
setblock 356 181 239 minecraft:light[level=15]
setblock 356 181 247 minecraft:light[level=15]
setblock 356 181 255 minecraft:light[level=15]
setblock 356 181 263 minecraft:light[level=15]
setblock 364 181 231 minecraft:light[level=15]
setblock 364 181 239 minecraft:light[level=15]
setblock 364 181 247 minecraft:light[level=15]
setblock 364 181 255 minecraft:light[level=15]
setblock 364 181 263 minecraft:light[level=15]
setblock 365 181 229 minecraft:green_concrete
fill 330 182 228 330 280 228 minecraft:stone_bricks
setblock 342 182 270 minecraft:mossy_stone_bricks
fill 347 182 270 347 212 270 minecraft:stone_bricks
setblock 351 182 229 minecraft:lime_terracotta
setblock 371 182 260 minecraft:cobblestone
setblock 330 183 234 minecraft:green_concrete
setblock 332 183 231 minecraft:light[level=12]
setblock 332 183 238 minecraft:light[level=12]
setblock 332 183 245 minecraft:light[level=12]
setblock 332 183 252 minecraft:light[level=12]
setblock 332 183 259 minecraft:light[level=12]
setblock 332 183 266 minecraft:light[level=12]
setblock 339 183 231 minecraft:light[level=12]
setblock 339 183 238 minecraft:light[level=12]
setblock 339 183 245 minecraft:light[level=12]
setblock 339 183 252 minecraft:light[level=12]
setblock 339 183 259 minecraft:light[level=12]
setblock 339 183 266 minecraft:light[level=12]
fill 342 183 270 342 280 270 minecraft:stone_bricks
setblock 346 183 231 minecraft:light[level=12]
setblock 346 183 238 minecraft:light[level=12]
setblock 346 183 245 minecraft:light[level=12]
setblock 346 183 252 minecraft:light[level=12]
setblock 346 183 259 minecraft:light[level=12]
setblock 346 183 266 minecraft:light[level=12]
fill 347 183 265 347 183 267 minecraft:light_gray_concrete
fill 348 183 230 348 183 232 minecraft:light_gray_concrete
fill 348 183 264 350 183 264 minecraft:light_gray_concrete
fill 348 183 268 350 183 268 minecraft:light_gray_concrete
fill 349 183 230 350 183 230 minecraft:light_gray_concrete
fill 349 183 232 350 183 232 minecraft:light_gray_concrete
setblock 350 183 231 minecraft:light_gray_concrete
fill 351 183 265 351 183 267 minecraft:light_gray_concrete
setblock 353 183 231 minecraft:light[level=12]
setblock 353 183 238 minecraft:light[level=12]
setblock 353 183 245 minecraft:light[level=12]
setblock 353 183 252 minecraft:light[level=12]
setblock 353 183 259 minecraft:light[level=12]
setblock 353 183 266 minecraft:light[level=12]
setblock 357 183 228 minecraft:cobblestone
setblock 360 183 231 minecraft:light[level=12]
setblock 360 183 238 minecraft:light[level=12]
setblock 360 183 245 minecraft:light[level=12]
setblock 360 183 252 minecraft:light[level=12]
setblock 360 183 259 minecraft:light[level=12]
setblock 360 183 266 minecraft:light[level=12]
setblock 360 183 269 minecraft:green_concrete
setblock 367 183 231 minecraft:light[level=12]
setblock 367 183 238 minecraft:light[level=12]
setblock 367 183 245 minecraft:light[level=12]
setblock 367 183 252 minecraft:light[level=12]
setblock 367 183 259 minecraft:light[level=12]
setblock 367 183 266 minecraft:light[level=12]
setblock 371 183 239 minecraft:cobblestone
fill 371 183 260 371 204 260 minecraft:stone_bricks
setblock 329 184 237 minecraft:cobblestone
fill 357 184 228 357 280 228 minecraft:stone_bricks
fill 371 184 239 371 204 239 minecraft:stone_bricks
fill 329 185 237 329 237 237 minecraft:stone_bricks
setblock 353 186 270 minecraft:mossy_stone_bricks
setblock 356 186 229 minecraft:lime_concrete
fill 365 186 264 365 186 266 minecraft:light_gray_concrete
fill 366 186 264 367 186 264 minecraft:light_gray_concrete
fill 366 186 266 367 186 266 minecraft:light_gray_concrete
setblock 367 186 265 minecraft:light_gray_concrete
setblock 339 187 270 minecraft:cobblestone
fill 353 187 270 353 265 270 minecraft:stone_bricks
setblock 355 187 229 minecraft:lime_concrete
setblock 371 187 243 minecraft:cobblestone
fill 371 187 244 371 257 244 minecraft:stone_bricks
setblock 330 188 236 minecraft:green_concrete
setblock 330 188 249 minecraft:green_concrete
setblock 332 188 231 minecraft:light[level=15]
setblock 332 188 239 minecraft:light[level=15]
setblock 332 188 247 minecraft:light[level=15]
setblock 332 188 255 minecraft:light[level=15]
setblock 332 188 263 minecraft:light[level=15]
fill 339 188 270 339 280 270 minecraft:stone_bricks
setblock 340 188 231 minecraft:light[level=15]
setblock 340 188 239 minecraft:light[level=15]
setblock 340 188 247 minecraft:light[level=15]
setblock 340 188 255 minecraft:light[level=15]
setblock 340 188 263 minecraft:light[level=15]
setblock 348 188 231 minecraft:light[level=15]
setblock 348 188 239 minecraft:light[level=15]
setblock 348 188 247 minecraft:light[level=15]
setblock 348 188 255 minecraft:light[level=15]
setblock 348 188 263 minecraft:light[level=15]
fill 349 188 229 349 189 230 minecraft:iron_block
setblock 356 188 231 minecraft:light[level=15]
setblock 356 188 239 minecraft:light[level=15]
setblock 356 188 247 minecraft:light[level=15]
setblock 356 188 255 minecraft:light[level=15]
setblock 356 188 263 minecraft:light[level=15]
setblock 364 188 231 minecraft:light[level=15]
setblock 364 188 239 minecraft:light[level=15]
setblock 364 188 247 minecraft:light[level=15]
setblock 364 188 255 minecraft:light[level=15]
setblock 364 188 263 minecraft:light[level=15]
fill 366 188 270 366 204 270 minecraft:stone_bricks
fill 367 188 253 367 189 253 minecraft:light_blue_stained_glass
setblock 367 188 270 minecraft:cobblestone
fill 371 188 243 371 280 243 minecraft:stone_bricks
setblock 371 188 247 minecraft:mossy_stone_bricks
setblock 371 188 256 minecraft:mossy_cobblestone
setblock 332 189 231 minecraft:light[level=12]
setblock 332 189 238 minecraft:light[level=12]
setblock 332 189 245 minecraft:light[level=12]
setblock 332 189 252 minecraft:light[level=12]
setblock 332 189 259 minecraft:light[level=12]
setblock 332 189 266 minecraft:light[level=12]
setblock 339 189 231 minecraft:light[level=12]
setblock 339 189 238 minecraft:light[level=12]
setblock 339 189 245 minecraft:light[level=12]
setblock 339 189 252 minecraft:light[level=12]
setblock 339 189 259 minecraft:light[level=12]
setblock 339 189 266 minecraft:light[level=12]
setblock 341 189 269 minecraft:lime_concrete
setblock 346 189 231 minecraft:light[level=12]
setblock 346 189 238 minecraft:light[level=12]
setblock 346 189 245 minecraft:light[level=12]
setblock 346 189 252 minecraft:light[level=12]
setblock 346 189 259 minecraft:light[level=12]
setblock 346 189 266 minecraft:light[level=12]
setblock 349 189 232 minecraft:sea_lantern
setblock 353 189 231 minecraft:light[level=12]
setblock 353 189 238 minecraft:light[level=12]
setblock 353 189 245 minecraft:light[level=12]
setblock 353 189 252 minecraft:light[level=12]
setblock 353 189 259 minecraft:light[level=12]
setblock 353 189 266 minecraft:light[level=12]
setblock 356 189 270 minecraft:mossy_stone_bricks
setblock 360 189 231 minecraft:light[level=12]
setblock 360 189 238 minecraft:light[level=12]
setblock 360 189 245 minecraft:light[level=12]
setblock 360 189 252 minecraft:light[level=12]
setblock 360 189 259 minecraft:light[level=12]
setblock 360 189 266 minecraft:light[level=12]
setblock 367 189 231 minecraft:light[level=12]
setblock 367 189 238 minecraft:light[level=12]
setblock 367 189 245 minecraft:light[level=12]
setblock 367 189 252 minecraft:light[level=12]
setblock 367 189 259 minecraft:light[level=12]
setblock 367 189 266 minecraft:light[level=12]
fill 367 189 270 367 197 270 minecraft:stone_bricks
fill 371 189 247 371 204 247 minecraft:stone_bricks
fill 371 189 256 371 280 256 minecraft:stone_bricks
setblock 329 190 238 minecraft:cobblestone
setblock 330 190 243 minecraft:lime_terracotta
fill 347 190 265 347 190 267 minecraft:light_gray_concrete
fill 348 190 230 348 190 232 minecraft:light_gray_concrete
fill 348 190 264 350 190 264 minecraft:light_gray_concrete
fill 348 190 268 350 190 268 minecraft:light_gray_concrete
fill 349 190 230 350 190 230 minecraft:light_gray_concrete
fill 349 190 232 350 190 232 minecraft:light_gray_concrete
setblock 350 190 231 minecraft:light_gray_concrete
fill 351 190 265 351 190 267 minecraft:light_gray_concrete
setblock 351 190 269 minecraft:green_concrete
setblock 352 190 228 minecraft:mossy_stone_bricks
fill 356 190 270 356 280 270 minecraft:stone_bricks
setblock 370 190 251 minecraft:lime_concrete
fill 329 191 238 329 280 238 minecraft:stone_bricks
setblock 330 191 269 minecraft:green_concrete
setblock 343 191 228 minecraft:cobblestone
fill 348 191 268 350 192 269 minecraft:iron_block
fill 352 191 228 352 239 228 minecraft:stone_bricks
setblock 370 191 258 minecraft:lime_concrete
setblock 371 191 252 minecraft:cobblestone
fill 343 192 228 343 211 228 minecraft:stone_bricks
setblock 349 192 264 minecraft:sea_lantern
setblock 355 192 228 minecraft:mossy_stone_bricks
setblock 370 192 260 minecraft:lime_concrete
fill 371 192 252 371 280 252 minecraft:stone_bricks
setblock 332 193 269 minecraft:lime_terracotta
setblock 341 193 228 minecraft:mossy_cobblestone
fill 355 193 228 355 241 228 minecraft:stone_bricks
setblock 371 193 245 minecraft:mossy_cobblestone
fill 341 194 228 341 213 228 minecraft:stone_bricks
setblock 344 194 229 minecraft:lime_concrete
setblock 371 194 240 minecraft:mossy_cobblestone
fill 371 194 245 371 280 245 minecraft:stone_bricks
setblock 332 195 231 minecraft:light[level=15]
setblock 332 195 238 minecraft:light[level=12]
setblock 332 195 239 minecraft:light[level=15]
setblock 332 195 245 minecraft:light[level=12]
setblock 332 195 247 minecraft:light[level=15]
setblock 332 195 252 minecraft:light[level=12]
setblock 332 195 255 minecraft:light[level=15]
setblock 332 195 259 minecraft:light[level=12]
setblock 332 195 263 minecraft:light[level=15]
setblock 332 195 266 minecraft:light[level=12]
setblock 339 195 231 minecraft:light[level=12]
setblock 339 195 238 minecraft:light[level=12]
setblock 339 195 245 minecraft:light[level=12]
setblock 339 195 252 minecraft:light[level=12]
setblock 339 195 259 minecraft:light[level=12]
setblock 339 195 266 minecraft:light[level=12]
setblock 340 195 231 minecraft:light[level=15]
setblock 340 195 239 minecraft:light[level=15]
setblock 340 195 247 minecraft:light[level=15]
setblock 340 195 255 minecraft:light[level=15]
setblock 340 195 263 minecraft:light[level=15]
setblock 346 195 231 minecraft:light[level=12]
setblock 346 195 238 minecraft:light[level=12]
setblock 346 195 245 minecraft:light[level=12]
setblock 346 195 252 minecraft:light[level=12]
setblock 346 195 259 minecraft:light[level=12]
setblock 346 195 266 minecraft:light[level=12]
setblock 348 195 231 minecraft:light[level=15]
setblock 348 195 239 minecraft:light[level=15]
setblock 348 195 247 minecraft:light[level=15]
setblock 348 195 255 minecraft:light[level=15]
setblock 348 195 263 minecraft:light[level=15]
setblock 353 195 231 minecraft:light[level=12]
setblock 353 195 238 minecraft:light[level=12]
setblock 353 195 245 minecraft:light[level=12]
setblock 353 195 252 minecraft:light[level=12]
setblock 353 195 259 minecraft:light[level=12]
setblock 353 195 266 minecraft:light[level=12]
setblock 356 195 231 minecraft:light[level=15]
setblock 356 195 239 minecraft:light[level=15]
setblock 356 195 247 minecraft:light[level=15]
setblock 356 195 255 minecraft:light[level=15]
setblock 356 195 263 minecraft:light[level=15]
setblock 360 195 231 minecraft:light[level=12]
setblock 360 195 238 minecraft:light[level=12]
setblock 360 195 245 minecraft:light[level=12]
setblock 360 195 252 minecraft:light[level=12]
setblock 360 195 259 minecraft:light[level=12]
setblock 360 195 266 minecraft:light[level=12]
setblock 364 195 231 minecraft:light[level=15]
setblock 364 195 239 minecraft:light[level=15]
setblock 364 195 247 minecraft:light[level=15]
setblock 364 195 255 minecraft:light[level=15]
setblock 364 195 263 minecraft:light[level=15]
setblock 367 195 231 minecraft:light[level=12]
setblock 367 195 238 minecraft:light[level=12]
setblock 367 195 245 minecraft:light[level=12]
setblock 367 195 252 minecraft:light[level=12]
setblock 367 195 259 minecraft:light[level=12]
setblock 367 195 266 minecraft:light[level=12]
setblock 369 195 228 minecraft:mossy_stone_bricks
setblock 371 195 233 minecraft:cobblestone
fill 371 195 240 371 204 240 minecraft:stone_bricks
setblock 329 196 249 minecraft:mossy_cobblestone
fill 369 196 228 369 203 228 minecraft:stone_bricks
fill 371 196 233 371 204 233 minecraft:stone_bricks
setblock 371 196 234 minecraft:mossy_stone_bricks
fill 329 197 249 329 214 249 minecraft:stone_bricks
fill 366 197 231 368 200 234 minecraft:gray_concrete
fill 366 197 238 368 200 241 minecraft:gray_concrete
fill 366 197 245 368 200 248 minecraft:gray_concrete
fill 366 197 252 368 200 255 minecraft:gray_concrete
fill 366 197 259 368 200 262 minecraft:gray_concrete
fill 367 197 228 367 197 230 minecraft:iron_block
fill 367 197 235 367 197 237 minecraft:iron_block
fill 367 197 242 367 197 244 minecraft:iron_block
fill 367 197 249 367 197 251 minecraft:iron_block
fill 367 197 256 367 197 258 minecraft:iron_block
fill 367 197 263 367 197 269 minecraft:iron_block
fill 371 197 234 371 235 234 minecraft:stone_bricks
setblock 329 198 251 minecraft:mossy_cobblestone
fill 343 198 247 349 198 253 minecraft:gray_concrete
fill 344 198 245 365 198 246 minecraft:gray_concrete
fill 344 198 254 365 198 255 minecraft:gray_concrete
fill 345 198 244 361 198 244 minecraft:gray_concrete
fill 345 198 256 361 198 256 minecraft:gray_concrete
fill 346 198 243 360 198 243 minecraft:gray_concrete
fill 346 198 257 360 198 257 minecraft:gray_concrete
fill 347 198 242 359 198 242 minecraft:gray_concrete
fill 347 198 258 359 198 258 minecraft:gray_concrete
fill 348 198 241 358 198 241 minecraft:gray_concrete
fill 348 198 259 358 198 259 minecraft:gray_concrete
fill 350 198 240 356 198 240 minecraft:gray_concrete
fill 350 198 247 350 199 248 minecraft:gray_concrete
fill 350 198 252 350 199 253 minecraft:gray_concrete
fill 350 198 260 356 198 260 minecraft:gray_concrete
fill 351 198 247 351 199 247 minecraft:gray_concrete
fill 351 198 253 351 199 253 minecraft:gray_concrete
fill 355 198 247 365 198 247 minecraft:gray_concrete
fill 355 198 253 365 198 253 minecraft:gray_concrete
setblock 355 198 270 minecraft:mossy_stone_bricks
fill 356 198 248 365 198 248 minecraft:gray_concrete
fill 356 198 252 365 198 252 minecraft:gray_concrete
fill 357 198 249 363 198 251 minecraft:gray_concrete
fill 363 198 229 365 198 230 minecraft:waxed_cut_copper
fill 363 198 231 365 201 234 minecraft:gray_concrete
fill 363 198 235 365 198 237 minecraft:waxed_cut_copper
fill 363 198 238 365 200 241 minecraft:gray_concrete
fill 363 198 242 365 198 244 minecraft:waxed_cut_copper
fill 363 198 256 365 198 258 minecraft:waxed_cut_copper
fill 363 198 259 365 200 262 minecraft:gray_concrete
fill 363 198 263 365 198 268 minecraft:waxed_cut_copper
fill 364 198 228 364 201 228 minecraft:waxed_cut_copper
fill 364 198 249 365 198 251 minecraft:waxed_cut_copper
fill 364 198 269 364 201 269 minecraft:waxed_cut_copper
fill 366 198 228 368 199 229 minecraft:iron_block
fill 366 198 230 368 199 230 minecraft:gray_concrete
fill 366 198 235 368 199 235 minecraft:gray_concrete
fill 366 198 236 368 199 236 minecraft:iron_block
fill 366 198 237 368 199 237 minecraft:gray_concrete
fill 366 198 242 368 199 242 minecraft:gray_concrete
fill 366 198 243 368 199 243 minecraft:iron_block
fill 366 198 244 368 199 244 minecraft:gray_concrete
fill 366 198 249 368 199 249 minecraft:gray_concrete
fill 366 198 250 368 199 250 minecraft:iron_block
fill 366 198 251 368 199 251 minecraft:gray_concrete
fill 366 198 256 368 199 256 minecraft:gray_concrete
fill 366 198 257 368 199 257 minecraft:iron_block
fill 366 198 258 368 199 258 minecraft:gray_concrete
fill 366 198 263 368 199 263 minecraft:gray_concrete
fill 366 198 264 368 199 269 minecraft:iron_block
fill 367 198 270 367 199 270 minecraft:iron_block
fill 369 198 231 369 199 234 minecraft:gray_concrete
fill 369 198 238 369 199 241 minecraft:gray_concrete
fill 369 198 245 369 199 248 minecraft:gray_concrete
fill 369 198 252 369 199 255 minecraft:gray_concrete
fill 369 198 259 369 199 262 minecraft:gray_concrete
setblock 371 198 266 minecraft:mossy_cobblestone
fill 329 199 251 329 245 251 minecraft:stone_bricks
fill 343 199 247 343 200 253 minecraft:iron_block
fill 344 199 245 344 200 246 minecraft:iron_block
fill 344 199 247 349 199 253 minecraft:gray_concrete
fill 344 199 254 344 200 255 minecraft:iron_block
fill 345 199 244 345 200 244 minecraft:iron_block
fill 345 199 245 361 199 246 minecraft:gray_concrete
fill 345 199 254 361 199 255 minecraft:gray_concrete
fill 345 199 256 345 200 256 minecraft:iron_block
fill 346 199 243 346 200 243 minecraft:iron_block
fill 346 199 244 360 199 244 minecraft:gray_concrete
fill 346 199 256 360 199 256 minecraft:gray_concrete
fill 346 199 257 346 200 257 minecraft:iron_block
fill 347 199 242 347 200 242 minecraft:iron_block
fill 347 199 243 359 199 243 minecraft:gray_concrete
fill 347 199 257 359 199 257 minecraft:gray_concrete
fill 347 199 258 347 200 258 minecraft:iron_block
fill 348 199 241 349 200 241 minecraft:iron_block
fill 348 199 242 358 199 242 minecraft:gray_concrete
fill 348 199 258 358 199 258 minecraft:gray_concrete
fill 348 199 259 349 200 259 minecraft:iron_block
fill 350 199 240 356 200 240 minecraft:iron_block
fill 350 199 241 356 199 241 minecraft:gray_concrete
fill 350 199 259 356 199 259 minecraft:gray_concrete
fill 350 199 260 356 200 260 minecraft:iron_block
fill 355 199 247 362 199 247 minecraft:gray_concrete
fill 355 199 253 362 199 253 minecraft:gray_concrete
fill 355 199 270 355 253 270 minecraft:stone_bricks
fill 356 199 248 362 199 248 minecraft:gray_concrete
fill 356 199 252 362 199 252 minecraft:gray_concrete
fill 357 199 241 358 200 241 minecraft:iron_block
fill 357 199 249 362 199 251 minecraft:gray_concrete
fill 357 199 259 358 200 259 minecraft:iron_block
fill 359 199 242 359 200 242 minecraft:iron_block
fill 359 199 258 359 200 258 minecraft:iron_block
fill 360 199 243 360 200 243 minecraft:iron_block
fill 360 199 257 360 200 257 minecraft:iron_block
fill 361 199 244 361 200 244 minecraft:iron_block
fill 361 199 256 361 200 256 minecraft:iron_block
fill 362 199 231 362 200 234 minecraft:gray_concrete
fill 362 199 238 362 200 241 minecraft:gray_concrete
fill 362 199 245 362 200 246 minecraft:iron_block
fill 362 199 254 362 200 255 minecraft:iron_block
fill 362 199 259 362 200 262 minecraft:gray_concrete
fill 363 199 228 363 200 229 minecraft:waxed_cut_copper
fill 363 199 230 365 200 230 minecraft:gray_concrete
fill 363 199 235 365 200 235 minecraft:gray_concrete
fill 363 199 236 365 201 236 minecraft:waxed_cut_copper
fill 363 199 237 365 200 237 minecraft:gray_concrete
fill 363 199 242 365 200 242 minecraft:gray_concrete
fill 363 199 243 365 200 243 minecraft:waxed_cut_copper
fill 363 199 244 365 200 246 minecraft:gray_concrete
fill 363 199 247 363 200 253 minecraft:iron_block
fill 363 199 254 365 200 256 minecraft:gray_concrete
fill 363 199 257 365 200 257 minecraft:waxed_cut_copper
fill 363 199 258 365 200 258 minecraft:gray_concrete
fill 363 199 263 365 200 263 minecraft:gray_concrete
fill 363 199 264 363 200 269 minecraft:waxed_cut_copper
fill 364 199 229 365 201 229 minecraft:waxed_cut_copper
fill 364 199 247 365 200 249 minecraft:gray_concrete
fill 364 199 250 365 200 250 minecraft:waxed_cut_copper
fill 364 199 251 365 200 253 minecraft:gray_concrete
fill 364 199 264 365 201 268 minecraft:waxed_cut_copper
fill 364 199 270 364 200 270 minecraft:waxed_cut_copper
fill 365 199 228 365 200 228 minecraft:waxed_cut_copper
fill 365 199 269 365 200 269 minecraft:waxed_cut_copper
setblock 371 199 229 minecraft:cobblestone
setblock 371 199 237 minecraft:mossy_stone_bricks
setblock 371 199 250 minecraft:mossy_stone_bricks
fill 371 199 266 371 213 266 minecraft:stone_bricks
setblock 329 200 240 minecraft:cobblestone
fill 330 200 229 362 200 230 minecraft:stone_bricks
fill 330 200 231 361 200 231 minecraft:mossy_stone_bricks
fill 330 200 232 361 200 233 minecraft:stone_bricks
fill 330 200 234 361 200 234 minecraft:mossy_stone_bricks
fill 330 200 235 362 200 236 minecraft:stone_bricks
fill 330 200 237 362 200 237 minecraft:mossy_stone_bricks
fill 330 200 238 361 200 239 minecraft:stone_bricks
fill 330 200 240 349 200 240 minecraft:mossy_stone_bricks
fill 330 200 241 346 200 242 minecraft:stone_bricks
fill 330 200 243 345 200 243 minecraft:mossy_stone_bricks
fill 330 200 244 343 200 245 minecraft:stone_bricks
fill 330 200 246 343 200 246 minecraft:mossy_stone_bricks
fill 330 200 247 342 200 248 minecraft:stone_bricks
fill 330 200 249 342 200 249 minecraft:mossy_stone_bricks
fill 330 200 250 342 200 251 minecraft:stone_bricks
fill 330 200 252 342 200 252 minecraft:mossy_stone_bricks
fill 330 200 253 342 200 254 minecraft:stone_bricks
fill 330 200 255 343 200 255 minecraft:mossy_stone_bricks
fill 330 200 256 344 200 257 minecraft:stone_bricks
fill 330 200 258 346 200 258 minecraft:mossy_stone_bricks
fill 330 200 259 347 200 260 minecraft:stone_bricks
fill 330 200 261 361 200 261 minecraft:mossy_stone_bricks
fill 330 200 262 361 200 263 minecraft:stone_bricks
fill 330 200 264 362 200 264 minecraft:mossy_stone_bricks
fill 330 200 265 362 200 266 minecraft:stone_bricks
fill 330 200 267 362 200 267 minecraft:mossy_stone_bricks
fill 330 200 268 362 200 269 minecraft:stone_bricks
setblock 343 200 254 minecraft:stone_bricks
setblock 344 200 244 minecraft:stone_bricks
setblock 344 200 247 minecraft:light_gray_concrete
setblock 344 200 248 minecraft:gray_concrete
setblock 344 200 249 minecraft:light_gray_concrete
fill 344 200 250 345 200 250 minecraft:iron_block
setblock 344 200 251 minecraft:light_gray_concrete
setblock 344 200 252 minecraft:gray_concrete
setblock 344 200 253 minecraft:light_gray_concrete
setblock 345 200 245 minecraft:gray_concrete
setblock 345 200 246 minecraft:light_gray_concrete
setblock 345 200 247 minecraft:gray_concrete
setblock 345 200 248 minecraft:light_gray_concrete
setblock 345 200 249 minecraft:gray_concrete
schedule function dropper:buildpart/55_2 1t
